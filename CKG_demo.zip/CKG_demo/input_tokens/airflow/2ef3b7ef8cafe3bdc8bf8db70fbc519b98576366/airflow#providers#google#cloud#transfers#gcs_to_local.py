context['ti'].xcom_push(key=self.store_to_xcom_key, value=file_bytes) 
context['ti'].xcom_push(key=self.store_to_xcom_key, value=str(file_bytes)) 