doc_url = get_docs_url("stable-rest-api/migration.html") 
doc_url = get_docs_url("upgrading-to-2.html#migration-guide-from-experimental-api-to-stable-api-v1") 