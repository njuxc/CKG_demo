self.log.exception(error) 
if isinstance(error, Exception): self.log.exception("Task failed with exception") else: self.log.error("%s", error) 