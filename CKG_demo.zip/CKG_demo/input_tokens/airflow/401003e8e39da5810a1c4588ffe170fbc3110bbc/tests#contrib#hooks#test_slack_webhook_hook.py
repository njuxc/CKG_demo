self.assertEqual(self.expected_message, message) 
self.assertEqual(self.expected_message_dict, json.loads(message)) 