resp(b'404 Not Found', [(b'Content-Type', b'text/plain')]) 
resp(b'404 Not Found', [('Content-Type', 'text/plain')]) 