builder = AirflowDocsBuilder(package_name=package_name, for_production=True) 
builder = AirflowDocsBuilder(package_name=package_name, for_production=True, verbose=False) 