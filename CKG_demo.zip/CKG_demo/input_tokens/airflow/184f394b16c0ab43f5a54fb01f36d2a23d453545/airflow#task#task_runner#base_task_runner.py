self._error_file.close() 
try: self._error_file.close() except FileNotFoundError: # The subprocess has deleted this file before we do # so we ignore pass 