 
# Remove the session from scoped_session registry to avoid # reusing a session with a disconnected connection appbuilder.session.remove() 