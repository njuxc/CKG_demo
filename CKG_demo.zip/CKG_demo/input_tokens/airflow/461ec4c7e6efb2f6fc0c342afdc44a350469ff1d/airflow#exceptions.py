class SerializedDagNotFound(DagNotFound): """Raise when DAG is not found in the serialized_dags table in DB"""   
