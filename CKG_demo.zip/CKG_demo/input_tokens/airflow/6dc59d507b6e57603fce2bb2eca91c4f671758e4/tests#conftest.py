home = os.environ.get("HOME") 
home = os.path.expanduser("~") 