ti._run_finished_callback() 
ti._run_finished_callback(error=e) 