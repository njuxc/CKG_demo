os.chmod(full_path, 0o666) 
try: os.chmod(full_path, 0o666) except OSError: logging.warning("OSError while change ownership of the log file") 