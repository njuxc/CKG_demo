session.flush() 
session.flush() 