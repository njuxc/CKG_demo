self._processor_factory, 
# getattr prevents error while pickling an instance method. getattr(self, "_processor_factory"), 