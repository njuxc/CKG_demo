return self.download(container_name, blob_name, **kwargs).readall() 
return self.download(container_name, blob_name, **kwargs).content_as_text() 