PodGenerator.serialize_pod(obj) 
return PodGenerator.serialize_pod(obj) 