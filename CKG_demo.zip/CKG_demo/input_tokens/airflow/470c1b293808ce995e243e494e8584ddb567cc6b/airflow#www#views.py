return json.dumps(task_instances) 
from airflow.utils import json as utils_json return json.dumps(task_instances, cls=utils_json.AirflowJsonEncoder) 