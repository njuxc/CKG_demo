self._run_mini_scheduler_on_child_tasks(session) 
if not test_mode: self._run_mini_scheduler_on_child_tasks(session) 