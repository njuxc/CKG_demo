self.log.info(s) 
self.log.info("{} with parameters {}".format(s, parameters)) self.log.info(s) 