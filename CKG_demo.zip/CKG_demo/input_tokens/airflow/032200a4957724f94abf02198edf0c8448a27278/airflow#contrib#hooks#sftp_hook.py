conn.mkdir(path, mode) 
conn.makedirs(path, mode) 