import getpass username = getpass.getuser() 
from airflow.utils.platform import getuser username = getuser() 