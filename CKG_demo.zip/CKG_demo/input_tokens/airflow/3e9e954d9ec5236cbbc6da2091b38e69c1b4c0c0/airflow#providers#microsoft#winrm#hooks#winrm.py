import getpass self.username = getpass.getuser() 
try: from airflow.utils.platform import getuser except ImportError: from getpass import getuser  self.username = getuser() 