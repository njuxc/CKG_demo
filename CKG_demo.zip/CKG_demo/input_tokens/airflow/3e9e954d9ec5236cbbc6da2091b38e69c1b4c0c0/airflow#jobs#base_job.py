import getpass self.unixname = getpass.getuser() 
from airflow.utils.platform import getuser self.unixname = getuser() 