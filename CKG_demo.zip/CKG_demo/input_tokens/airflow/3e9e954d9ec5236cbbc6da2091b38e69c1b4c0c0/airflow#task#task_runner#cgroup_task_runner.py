import getpass self._cur_user = getpass.getuser() 
from airflow.utils.platform import getuser self._cur_user = getuser() 