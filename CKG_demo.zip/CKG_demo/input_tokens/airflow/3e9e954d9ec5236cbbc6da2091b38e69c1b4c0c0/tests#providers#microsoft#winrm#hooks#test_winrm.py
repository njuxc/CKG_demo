@patch('airflow.providers.microsoft.winrm.hooks.winrm.getpass.getuser', return_value='user') 
@patch('airflow.providers.microsoft.winrm.hooks.winrm.getuser', return_value='user') 