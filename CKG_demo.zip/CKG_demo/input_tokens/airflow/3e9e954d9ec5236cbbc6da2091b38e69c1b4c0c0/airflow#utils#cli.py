import getpass from airflow.utils.platform import is_terminal_support_colors 'user': getpass.getuser(), 
from airflow.utils.platform import getuser, is_terminal_support_colors 'user': getuser(), 