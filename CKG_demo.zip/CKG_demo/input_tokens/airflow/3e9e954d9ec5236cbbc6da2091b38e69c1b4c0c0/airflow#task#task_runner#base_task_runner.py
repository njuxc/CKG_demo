import getpass if self.run_as_user and (self.run_as_user != getpass.getuser()): 
from airflow.utils.platform import getuser if self.run_as_user and (self.run_as_user != getuser()): 