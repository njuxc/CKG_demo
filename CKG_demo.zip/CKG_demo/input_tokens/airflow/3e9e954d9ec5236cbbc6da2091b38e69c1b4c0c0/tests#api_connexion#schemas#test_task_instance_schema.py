import getpass "unixname": getpass.getuser(), "unixname": getpass.getuser(), 
from airflow.utils.platform import getuser "unixname": getuser(), "unixname": getuser(), 