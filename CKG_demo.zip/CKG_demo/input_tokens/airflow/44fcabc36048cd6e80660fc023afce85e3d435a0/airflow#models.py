DagModel.is_paused.is_(True))] qry = qry.filter(DR.external_trigger.is_(False)) 
DagModel.is_paused.__eq__(True))] qry = qry.filter(DR.external_trigger.__eq__(False)) 