execute_interactive(["sqlite3", url.database]).wait() 
execute_interactive(["sqlite3", url.database]) 