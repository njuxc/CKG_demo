log.exception(e) log.error('Failed to import plugin %s', file_path) 
log.exception('Failed to import plugin %s', file_path) 