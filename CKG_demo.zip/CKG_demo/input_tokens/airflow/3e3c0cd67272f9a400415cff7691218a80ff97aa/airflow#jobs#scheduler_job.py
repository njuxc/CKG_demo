self._manager.shutdown() 
