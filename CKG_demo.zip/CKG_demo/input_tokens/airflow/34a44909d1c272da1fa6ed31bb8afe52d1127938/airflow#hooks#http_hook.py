if self.method not in ['GET', 'HEAD']: self.log.error(response.text) 
self.log.error(response.text) 