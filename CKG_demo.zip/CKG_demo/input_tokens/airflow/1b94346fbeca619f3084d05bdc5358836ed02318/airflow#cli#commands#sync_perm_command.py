dags = DagBag(read_dags_from_db=True).dags.values() 
dagbag = DagBag(read_dags_from_db=True) dagbag.collect_dags_from_db() dags = dagbag.dags.values() 