jdbc = ['jaydebeapi>=0.2.0'] 
jdbc = ['jaydebeapi>=1.1.1'] 