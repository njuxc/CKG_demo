
self.assertEqual(len(dagbag.dags), 0) 