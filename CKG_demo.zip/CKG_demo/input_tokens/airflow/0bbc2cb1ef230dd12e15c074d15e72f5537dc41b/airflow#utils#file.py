return zipfile.ZipFile(archive, mode=mode).open(filename) 
import io return io.TextIOWrapper(zipfile.ZipFile(archive, mode=mode).open(filename)) 