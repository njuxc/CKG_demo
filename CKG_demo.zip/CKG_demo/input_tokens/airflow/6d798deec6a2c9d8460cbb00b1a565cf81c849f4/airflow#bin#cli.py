app, _ = create_app(None, testing=conf.get('core', 'unit_test_mode')) 
app, _ = create_app(None, testing=conf.getboolean('core', 'unit_test_mode')) 