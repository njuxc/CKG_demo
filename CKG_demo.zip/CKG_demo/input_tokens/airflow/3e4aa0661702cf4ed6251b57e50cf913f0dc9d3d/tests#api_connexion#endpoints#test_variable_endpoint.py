assert response.status_code == 204 response = self.client.get("/api/v1/variables/var1", environ_overrides={'REMOTE_USER': "test"}) 
assert response.status_code == 200 