return Response(status=204) 
return variable_schema.dump(data) 