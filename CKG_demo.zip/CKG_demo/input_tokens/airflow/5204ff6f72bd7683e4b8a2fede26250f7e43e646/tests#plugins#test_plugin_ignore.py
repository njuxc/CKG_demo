
os.mkdir(os.path.join(self.plugin_folder_path, "subdir3")) ["subdir3/test_notload_sub3.py", 'raise Exception("This file should have been ignored!")'], 