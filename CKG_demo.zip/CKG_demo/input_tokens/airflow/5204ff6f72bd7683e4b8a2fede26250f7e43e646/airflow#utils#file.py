patterns_by_dir = {os.path.join(root, sd): patterns.copy() for sd in dirs} 
patterns_by_dir.update({os.path.join(root, sd): patterns.copy() for sd in dirs}) 