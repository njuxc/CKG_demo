 conf.validate()  
conf.validate() 