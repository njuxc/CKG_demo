initialize_config() 
conf = initialize_config() conf.validate() 