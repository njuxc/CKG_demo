self.databricks_conn = self.get_connection(databricks_conn_id) 
self.databricks_conn = None self.databricks_conn = self.get_connection(self.databricks_conn_id)  