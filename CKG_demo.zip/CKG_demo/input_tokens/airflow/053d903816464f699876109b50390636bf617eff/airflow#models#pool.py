return ( ) or 0 return ( ) or 0 return ( ) or 0 
return int( or 0 ) return int( or 0 ) return int( or 0 ) 