with conf_vars({('sentry', 'sentry_on'): 'True'}): 
with conf_vars({('sentry', 'sentry_on'): 'True', ('sentry', 'default_integrations'): 'False'}): 