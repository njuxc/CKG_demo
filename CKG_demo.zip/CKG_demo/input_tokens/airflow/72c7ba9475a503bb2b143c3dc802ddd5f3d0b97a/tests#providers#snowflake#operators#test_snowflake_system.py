extra=json.dumps(extra)) 
conn_type='snowflake', extra=json.dumps(extra)) 