self.scheduler_job._run_scheduler_loop() 
session = settings.Session() self.scheduler_job._start_queued_dagruns(session) session.flush() 