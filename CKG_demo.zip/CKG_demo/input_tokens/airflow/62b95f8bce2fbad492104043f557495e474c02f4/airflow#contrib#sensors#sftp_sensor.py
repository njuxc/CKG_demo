self.hook = SFTPHook(sftp_conn_id=sftp_conn_id) 
self.hook = SFTPHook(sftp_conn_id) 