Variable.delete(key) 
Variable.delete(key, session=session) 