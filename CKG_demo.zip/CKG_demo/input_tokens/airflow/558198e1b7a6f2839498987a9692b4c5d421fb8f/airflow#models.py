import inspect self.fileloc = inspect.getsourcefile(inspect.stack()[1][0]) 
self.fileloc = sys._getframe().f_back.f_code.co_filename 