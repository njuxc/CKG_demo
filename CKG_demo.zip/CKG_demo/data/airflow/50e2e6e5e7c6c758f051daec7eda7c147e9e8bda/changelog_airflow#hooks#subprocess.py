===
match
---
name: command [2962,2969]
name: command [3203,3210]
===
match
---
name: env [3090,3093]
name: env [3331,3334]
===
match
---
atom_expr [3870,3929]
atom_expr [4111,4170]
===
match
---
name: line [3218,3222]
name: line [3459,3463]
===
match
---
trailer [3339,3356]
trailer [3580,3597]
===
match
---
name: cwd [1466,1469]
name: cwd [1466,1469]
===
match
---
name: self [3582,3586]
name: self [3823,3827]
===
match
---
atom_expr [3256,3299]
atom_expr [3497,3540]
===
match
---
name: hasattr [3824,3831]
name: hasattr [4065,4072]
===
match
---
name: os [2836,2838]
name: os [3077,3079]
===
match
---
atom [3097,3099]
atom [3338,3340]
===
match
---
name: TemporaryDirectory [926,944]
name: TemporaryDirectory [926,944]
===
match
---
name: sub_process [3808,3819]
name: sub_process [4049,4060]
===
match
---
atom_expr [2920,2936]
atom_expr [3161,3177]
===
match
---
name: self [3421,3425]
name: self [3662,3666]
===
match
---
name: contextlib [792,802]
name: contextlib [792,802]
===
match
---
param [1380,1417]
param [1380,1417]
===
match
---
operator: = [3322,3323]
operator: = [3563,3564]
===
match
---
name: signal [2790,2796]
name: signal [3031,3037]
===
match
---
name: SubprocessResult [3555,3571]
name: SubprocessResult [3796,3812]
===
match
---
trailer [2515,2536]
trailer [2756,2777]
===
match
---
arglist [2962,3153]
arglist [3203,3394]
===
match
---
suite [2698,2820]
suite [2939,3061]
===
match
---
name: str [1471,1474]
name: str [1471,1474]
===
match
---
operator: , [3848,3849]
operator: , [4089,4090]
===
match
---
name: PIPE [885,889]
name: PIPE [885,889]
===
match
---
name: info [3190,3194]
name: info [3431,3435]
===
match
---
name: gettempdir [946,956]
name: gettempdir [946,956]
===
match
---
trailer [2924,2936]
trailer [3165,3177]
===
match
---
atom_expr [3421,3444]
atom_expr [3662,3685]
===
match
---
trailer [3442,3444]
trailer [3683,3685]
===
match
---
import_name [813,826]
import_name [813,826]
===
match
---
operator: , [2998,2999]
operator: , [3239,3240]
===
match
---
operator: = [1056,1057]
operator: = [1056,1057]
===
match
---
for_stmt [2654,2820]
for_stmt [2895,3061]
===
match
---
name: tempfile [910,918]
name: tempfile [910,918]
===
match
---
operator: , [3152,3153]
operator: , [3393,3394]
===
match
---
simple_stmt [813,827]
simple_stmt [813,827]
===
match
---
operator: , [1456,1457]
operator: , [1456,1457]
===
match
---
name: cwd [3051,3054]
name: cwd [3292,3295]
===
match
---
name: List [1361,1365]
name: List [1361,1365]
===
match
---
parameters [2563,2565]
parameters [2804,2806]
===
match
---
arglist [3261,3298]
arglist [3502,3539]
===
match
---
name: base [1017,1021]
name: base [1017,1021]
===
match
---
string: 'SubprocessResult' [1069,1087]
string: 'SubprocessResult' [1069,1087]
===
match
---
dotted_name [1003,1021]
dotted_name [1003,1021]
===
match
---
name: self [3382,3386]
name: self [3623,3627]
===
match
---
atom_expr [1361,1370]
atom_expr [1361,1370]
===
match
---
suite [1248,1308]
suite [1248,1308]
===
match
---
string: 'SIGXFZ' [2677,2685]
string: 'SIGXFZ' [2918,2926]
===
match
---
operator: = [2993,2994]
operator: = [3234,3235]
===
match
---
name: self [3832,3836]
name: self [4073,4077]
===
match
---
argument [3072,3115]
argument [3313,3356]
===
match
---
if_stmt [3800,3930]
if_stmt [4041,4171]
===
match
---
trailer [3284,3293]
trailer [3525,3534]
===
match
---
trailer [2496,2537]
trailer [2737,2778]
===
match
---
name: sub_process [2925,2936]
name: sub_process [3166,3177]
===
match
---
import_name [785,802]
import_name [785,802]
===
match
---
operator: = [3617,3618]
operator: = [3858,3859]
===
match
---
name: SubprocessHook [1122,1136]
name: SubprocessHook [1122,1136]
===
match
---
name: stdout [2987,2993]
name: stdout [3228,3234]
===
match
---
argument [2516,2535]
argument [2757,2776]
===
match
---
trailer [1296,1305]
trailer [1296,1305]
===
match
---
trailer [3586,3598]
trailer [3827,3839]
===
match
---
tfpdef [1426,1446]
tfpdef [1426,1446]
===
match
---
simple_stmt [2321,2381]
simple_stmt [2562,2622]
===
match
---
name: contextlib [2394,2404]
name: contextlib [2635,2645]
===
match
---
name: STDOUT [3023,3029]
name: STDOUT [3264,3270]
===
match
---
comparison [3090,3099]
comparison [3331,3340]
===
match
---
operator: , [2675,2676]
operator: , [2916,2917]
===
match
---
operator: , [2796,2797]
operator: , [3037,3038]
===
match
---
name: log [3740,3743]
name: log [3981,3984]
===
match
---
operator: , [3508,3509]
operator: , [3749,3750]
===
match
---
operator: , [1370,1371]
operator: , [1370,1371]
===
match
---
tfpdef [1380,1409]
tfpdef [1380,1409]
===
match
---
simple_stmt [827,862]
simple_stmt [827,862]
===
match
---
name: raw_line [3324,3332]
name: raw_line [3565,3573]
===
match
---
atom_expr [2321,2380]
atom_expr [2562,2621]
===
match
---
name: os [810,812]
name: os [810,812]
===
match
---
suite [1147,3930]
suite [1147,4171]
===
match
---
name: Optional [1385,1393]
name: Optional [1385,1393]
===
match
---
operator: = [1410,1411]
operator: = [1410,1411]
===
match
---
operator: , [980,981]
operator: , [980,981]
===
match
---
argument [2987,2998]
argument [3228,3239]
===
match
---
trailer [3895,3907]
trailer [4136,4148]
===
match
---
funcdef [2551,2848]
funcdef [2792,3089]
===
match
---
trailer [2869,2874]
trailer [3110,3115]
===
match
---
name: stack [2420,2425]
name: stack [2661,2666]
===
match
---
trailer [3260,3299]
trailer [3501,3540]
===
match
---
name: sub_process [3266,3277]
name: sub_process [3507,3518]
===
match
---
string: '' [3225,3227]
string: '' [3466,3468]
===
match
---
trailer [3386,3390]
trailer [3627,3631]
===
match
---
name: super [1289,1294]
name: super [1289,1294]
===
match
---
import_from [827,861]
import_from [827,861]
===
match
---
atom_expr [1385,1409]
atom_expr [1385,1409]
===
match
---
simple_stmt [1518,2313]
simple_stmt [1518,2554]
===
match
---
simple_stmt [1289,1308]
simple_stmt [1289,1308]
===
match
---
string: 'Output:' [3195,3204]
string: 'Output:' [3436,3445]
===
match
---
trailer [3872,3879]
trailer [4113,4120]
===
match
---
name: namedtuple [851,861]
name: namedtuple [851,861]
===
match
---
name: signal [3914,3920]
name: signal [4155,4161]
===
match
---
operator: , [2365,2366]
operator: , [2606,2607]
===
match
---
name: os [3105,3107]
name: os [3346,3348]
===
match
---
trailer [3395,3407]
trailer [3636,3648]
===
match
---
trailer [3462,3466]
trailer [3703,3707]
===
match
---
operator: , [3400,3401]
operator: , [3641,3642]
===
match
---
operator: -> [1489,1491]
operator: -> [1489,1491]
===
match
---
name: info [2330,2334]
name: info [2571,2575]
===
match
---
expr_stmt [2920,3167]
expr_stmt [3161,3408]
===
match
---
string: """         Execute the command.          If ``cwd`` is None, execute the command in a temporary directory which will be cleaned afterwards.         If ``env`` is not supplied, ``os.environ`` is passed          :param command: the command to run         :param env: Optional dict containing environment variables to be made available to the shell             environment in which ``command`` will be executed.  If omitted, ``os.environ`` will be used.         :param output_encoding: encoding to use for decoding stdout         :param cwd: Working directory to run the command in.             If None (default), the command is run in a temporary directory.         :return: :class:`namedtuple` containing ``exit_code`` and ``output``, the last line from stderr             or stdout         """ [1518,2312]
string: """         Execute the command.          If ``cwd`` is None, execute the command in a temporary directory which will be cleaned afterwards.         If ``env`` is not supplied, ``os.environ`` is passed          :param command: the command to run         :param env: Optional dict containing environment variables to be made available to the shell             environment in which ``command`` will be executed.  If omitted, ``os.environ`` will be used.             Note, that in case you have Sentry configured, original variables from the environment             will also be passed to the subprocess with ``SUBPROCESS_`` prefix. See             :doc:`/logging-monitoring/errors` for details.         :param output_encoding: encoding to use for decoding stdout         :param cwd: Working directory to run the command in.             If None (default), the command is run in a temporary directory.         :return: :class:`namedtuple` containing ``exit_code`` and ``output``, the last line from stderr             or stdout         """ [1518,2553]
===
match
---
simple_stmt [1257,1281]
simple_stmt [1257,1281]
===
match
---
operator: == [3094,3096]
operator: == [3335,3337]
===
match
---
name: self [3261,3265]
name: self [3502,3506]
===
match
---
argument [3572,3609]
argument [3813,3850]
===
match
---
atom_expr [2477,2537]
atom_expr [2718,2778]
===
match
---
name: TemporaryDirectory [2497,2515]
name: TemporaryDirectory [2738,2756]
===
match
---
name: wait [3438,3442]
name: wait [3679,3683]
===
match
---
name: BaseHook [1029,1037]
name: BaseHook [1029,1037]
===
match
---
arglist [3880,3928]
arglist [4121,4169]
===
match
---
with_stmt [2389,3539]
with_stmt [2630,3780]
===
match
---
atom_expr [2782,2802]
atom_expr [3023,3043]
===
match
---
name: killpg [3873,3879]
name: killpg [4114,4120]
===
match
---
trailer [1305,1307]
trailer [1305,1307]
===
match
---
name: self [1338,1342]
name: self [1338,1342]
===
match
---
param [1466,1482]
param [1466,1482]
===
match
---
name: sub_process [1262,1273]
name: sub_process [1262,1273]
===
match
---
operator: = [2937,2938]
operator: = [3178,3179]
===
match
---
name: env [3072,3075]
name: env [3313,3316]
===
match
---
operator: = [3075,3076]
operator: = [3316,3317]
===
match
---
name: getattr [2782,2789]
name: getattr [3023,3030]
===
match
---
operator: } [3098,3099]
operator: } [3339,3340]
===
match
---
name: pre_exec [3144,3152]
name: pre_exec [3385,3393]
===
match
---
name: SubprocessResult [1039,1055]
name: SubprocessResult [1039,1055]
===
match
---
name: pre_exec [2555,2563]
name: pre_exec [2796,2804]
===
match
---
name: info [3467,3471]
name: info [3708,3712]
===
match
---
name: line [3618,3622]
name: line [3859,3863]
===
match
---
operator: , [3912,3913]
operator: , [4153,4154]
===
match
---
name: returncode [3527,3537]
name: returncode [3768,3778]
===
match
---
name: BaseHook [1137,1145]
name: BaseHook [1137,1145]
===
match
---
trailer [3356,3363]
trailer [3597,3604]
===
match
---
trailer [3107,3115]
trailer [3348,3356]
===
match
---
simple_stmt [2836,2848]
simple_stmt [3077,3089]
===
match
---
operator: , [2969,2970]
operator: , [3210,3211]
===
match
---
name: SIGTERM [3921,3928]
name: SIGTERM [4162,4169]
===
match
---
string: """Hook for running processes with the ``subprocess`` module""" [1152,1215]
string: """Hook for running processes with the ``subprocess`` module""" [1152,1215]
===
match
---
trailer [3471,3538]
trailer [3712,3779]
===
match
---
operator: = [1475,1476]
operator: = [1475,1476]
===
match
---
operator: , [3293,3294]
operator: , [3534,3535]
===
match
---
operator: = [3143,3144]
operator: = [3384,3385]
===
match
---
atom_expr [3735,3791]
atom_expr [3976,4032]
===
match
---
operator: , [2736,2737]
operator: , [2977,2978]
===
match
---
name: self [3646,3650]
name: self [3887,3891]
===
match
---
operator: , [1402,1403]
operator: , [1402,1403]
===
match
---
name: iter [3256,3260]
name: iter [3497,3501]
===
match
---
name: send_sigterm [3633,3645]
name: send_sigterm [3874,3886]
===
match
---
atom_expr [1394,1408]
atom_expr [1394,1408]
===
match
---
name: signal [2775,2781]
name: signal [3016,3022]
===
match
---
name: sig [2658,2661]
name: sig [2899,2902]
===
match
---
arglist [2875,2905]
arglist [3116,3146]
===
match
---
trailer [3514,3526]
trailer [3755,3767]
===
match
---
trailer [3526,3537]
trailer [3767,3778]
===
match
---
trailer [1393,1409]
trailer [1393,1409]
===
match
---
simple_stmt [3317,3366]
simple_stmt [3558,3607]
===
match
---
return_stmt [3548,3623]
return_stmt [3789,3864]
===
match
---
import_name [803,812]
import_name [803,812]
===
match
---
funcdef [1221,1308]
funcdef [1221,1308]
===
match
---
trailer [3807,3819]
trailer [4048,4060]
===
match
---
comparison [2442,2453]
comparison [2683,2694]
===
match
---
name: log [3387,3390]
name: log [3628,3631]
===
match
---
name: output_encoding [1426,1441]
name: output_encoding [1426,1441]
===
match
---
name: info [3391,3395]
name: info [3632,3636]
===
match
---
string: "%s" [3396,3400]
string: "%s" [3637,3641]
===
match
---
trailer [1365,1370]
trailer [1365,1370]
===
match
---
tfpdef [1466,1474]
tfpdef [1466,1474]
===
match
---
trailer [2838,2845]
trailer [3079,3086]
===
match
---
name: self [3181,3185]
name: self [3422,3426]
===
match
---
trailer [2377,2379]
trailer [2618,2620]
===
match
---
name: cwd [3047,3050]
name: cwd [3288,3291]
===
match
---
tfpdef [1352,1370]
tfpdef [1352,1370]
===
match
---
arglist [3572,3622]
arglist [3813,3863]
===
match
---
trailer [3363,3365]
trailer [3604,3606]
===
match
---
simple_stmt [3421,3445]
simple_stmt [3662,3686]
===
match
---
test [3076,3115]
test [3317,3356]
===
match
---
name: str [1399,1402]
name: str [1399,1402]
===
match
---
name: preexec_fn [3133,3143]
name: preexec_fn [3374,3384]
===
match
---
if_stmt [2719,2820]
if_stmt [2960,3061]
===
match
---
funcdef [3629,3930]
funcdef [3870,4171]
===
match
---
name: stderr [3016,3022]
name: stderr [3257,3263]
===
match
---
name: self [3803,3807]
name: self [4044,4048]
===
match
---
name: pid [3908,3911]
name: pid [4149,4152]
===
match
---
param [1234,1238]
param [1234,1238]
===
match
---
testlist_comp [2666,2696]
testlist_comp [2907,2937]
===
match
---
name: env [3076,3079]
name: env [3317,3320]
===
match
---
trailer [1398,1408]
trailer [1398,1408]
===
match
---
subscriptlist [1399,1407]
subscriptlist [1399,1407]
===
match
---
operator: , [3115,3116]
operator: , [3356,3357]
===
match
---
name: hasattr [2722,2729]
name: hasattr [2963,2970]
===
match
---
name: env [3083,3086]
name: env [3324,3327]
===
match
---
atom_expr [3832,3848]
atom_expr [4073,4089]
===
match
---
name: getpgid [3883,3890]
name: getpgid [4124,4131]
===
match
---
name: List [982,986]
name: List [982,986]
===
match
---
operator: , [1481,1482]
operator: , [1481,1482]
===
match
---
name: environ [3108,3115]
name: environ [3349,3356]
===
match
---
trailer [2414,2416]
trailer [2655,2657]
===
match
---
operator: , [1342,1343]
operator: , [1342,1343]
===
match
---
trailer [3907,3911]
trailer [4148,4152]
===
match
---
name: log [3186,3189]
name: log [3427,3430]
===
match
---
operator: , [986,987]
operator: , [986,987]
===
match
---
argument [3016,3029]
argument [3257,3270]
===
match
---
name: STDOUT [891,897]
name: STDOUT [891,897]
===
match
---
name: line [3317,3321]
name: line [3558,3562]
===
match
---
if_stmt [2439,2538]
if_stmt [2680,2779]
===
match
---
name: os [3880,3882]
name: os [4121,4123]
===
match
---
atom_expr [3891,3911]
atom_expr [4132,4152]
===
match
---
arglist [3396,3406]
arglist [3637,3647]
===
match
---
expr_stmt [2471,2537]
expr_stmt [2712,2778]
===
match
---
simple_stmt [2861,2907]
simple_stmt [3102,3148]
===
match
---
trailer [3920,3928]
trailer [4161,4169]
===
match
---
trailer [1261,1273]
trailer [1261,1273]
===
match
---
name: command [1352,1359]
name: command [1352,1359]
===
match
---
atom_expr [1257,1273]
atom_expr [1257,1273]
===
match
---
string: 'Command exited with return code %s' [3472,3508]
string: 'Command exited with return code %s' [3713,3749]
===
match
---
name: signal [2804,2810]
name: signal [3045,3051]
===
match
---
trailer [3743,3748]
trailer [3984,3989]
===
match
---
atom_expr [1289,1307]
atom_expr [1289,1307]
===
match
---
testlist_comp [1090,1111]
testlist_comp [1090,1111]
===
match
---
arglist [2790,2801]
arglist [3031,3042]
===
match
---
atom_expr [3105,3115]
atom_expr [3346,3356]
===
match
---
trailer [2774,2781]
trailer [3015,3022]
===
match
---
name: env [1380,1383]
name: env [1380,1383]
===
match
---
atom_expr [3555,3623]
atom_expr [3796,3864]
===
match
---
operator: , [3609,3610]
operator: , [3850,3851]
===
match
---
name: self [3891,3895]
name: self [4132,4136]
===
match
---
trailer [3332,3339]
trailer [3573,3580]
===
match
---
name: gettempdir [2367,2377]
name: gettempdir [2608,2618]
===
match
---
name: self [1257,1261]
name: self [1257,1261]
===
match
---
name: collections [832,843]
name: collections [832,843]
===
match
---
atom_expr [3261,3293]
atom_expr [3502,3534]
===
match
---
string: 'Sending SIGTERM signal to process group' [3749,3790]
string: 'Sending SIGTERM signal to process group' [3990,4031]
===
match
---
trailer [2325,2329]
trailer [2566,2570]
===
match
---
name: str [1443,1446]
name: str [1443,1446]
===
match
---
name: os [3870,3872]
name: os [4111,4113]
===
match
---
param [1426,1457]
param [1426,1457]
===
match
---
simple_stmt [3548,3624]
simple_stmt [3789,3865]
===
match
---
trailer [3466,3471]
trailer [3707,3712]
===
match
---
import_as_names [885,904]
import_as_names [885,904]
===
match
---
atom_expr [2497,2536]
atom_expr [2738,2777]
===
match
---
name: stack [2477,2482]
name: stack [2718,2723]
===
match
---
atom_expr [2722,2742]
atom_expr [2963,2983]
===
match
---
parameters [1328,1488]
parameters [1328,1488]
===
match
---
trailer [2482,2496]
trailer [2723,2737]
===
match
---
name: ExitStack [2405,2414]
name: ExitStack [2646,2655]
===
match
---
simple_stmt [2768,2820]
simple_stmt [3009,3061]
===
match
---
trailer [3836,3848]
trailer [4077,4089]
===
match
---
operator: -> [1240,1242]
operator: -> [1240,1242]
===
match
---
operator: = [3581,3582]
operator: = [3822,3823]
===
match
---
trailer [3571,3623]
trailer [3812,3864]
===
match
---
import_from [998,1037]
import_from [998,1037]
===
match
---
name: enter_context [2483,2496]
name: enter_context [2724,2737]
===
match
---
simple_stmt [803,813]
simple_stmt [803,813]
===
match
---
string: 'utf-8' [1449,1456]
string: 'utf-8' [1449,1456]
===
match
---
simple_stmt [2920,3168]
simple_stmt [3161,3409]
===
match
---
name: cwd [2442,2445]
name: cwd [2683,2686]
===
match
---
trailer [1294,1296]
trailer [1294,1296]
===
match
---
operator: { [3097,3098]
operator: { [3338,3339]
===
match
---
argument [3611,3622]
argument [3852,3863]
===
match
---
arglist [3832,3855]
arglist [4073,4096]
===
match
---
name: Dict [976,980]
name: Dict [976,980]
===
match
---
name: line [3402,3406]
name: line [3643,3647]
===
match
---
param [3646,3650]
param [3887,3891]
===
match
---
expr_stmt [1039,1113]
expr_stmt [1039,1113]
===
match
---
simple_stmt [998,1038]
simple_stmt [998,1038]
===
match
---
operator: , [1416,1417]
operator: , [1416,1417]
===
match
---
string: 'Tmp dir root location: \n %s' [2335,2365]
string: 'Tmp dir root location: \n %s' [2576,2606]
===
match
---
name: sub_process [3587,3598]
name: sub_process [3828,3839]
===
match
---
name: log [2866,2869]
name: log [3107,3110]
===
match
---
or_test [3083,3099]
or_test [3324,3340]
===
match
---
atom_expr [3880,3912]
atom_expr [4121,4153]
===
match
---
simple_stmt [3458,3539]
simple_stmt [3699,3780]
===
match
---
name: typing [962,968]
name: typing [962,968]
===
match
---
suite [2454,2538]
suite [2695,2779]
===
match
---
arglist [2782,2818]
arglist [3023,3059]
===
match
---
argument [3133,3152]
argument [3374,3393]
===
match
---
trailer [3265,3277]
trailer [3506,3518]
===
match
---
name: self [2321,2325]
name: self [2562,2566]
===
match
---
and_test [3803,3856]
and_test [4044,4097]
===
match
---
name: exit_code [3572,3581]
name: exit_code [3813,3822]
===
match
---
simple_stmt [3870,3930]
simple_stmt [4111,4171]
===
match
---
atom_expr [2836,2847]
atom_expr [3077,3088]
===
match
---
name: run_command [1317,1328]
name: run_command [1317,1328]
===
match
---
atom_expr [2861,2906]
atom_expr [3102,3147]
===
match
---
operator: , [889,890]
operator: , [889,890]
===
match
---
name: __init__ [1225,1233]
name: __init__ [1225,1233]
===
match
---
trailer [3879,3929]
trailer [4120,4170]
===
match
---
string: b'' [3295,3298]
string: b'' [3536,3539]
===
match
---
name: info [2870,2874]
name: info [3111,3115]
===
match
---
name: sub_process [3837,3848]
name: sub_process [4078,4089]
===
match
---
name: output [3611,3617]
name: output [3852,3858]
===
match
---
trailer [3890,3912]
trailer [4131,4153]
===
match
---
expr_stmt [3317,3365]
expr_stmt [3558,3606]
===
match
---
trailer [3277,3284]
trailer [3518,3525]
===
match
---
simple_stmt [1152,1216]
simple_stmt [1152,1216]
===
match
---
name: self [3510,3514]
name: self [3751,3755]
===
match
---
name: namedtuple [1058,1068]
name: namedtuple [1058,1068]
===
match
---
import_as_names [926,956]
import_as_names [926,956]
===
match
---
simple_stmt [3735,3792]
simple_stmt [3976,4033]
===
match
---
atom [1089,1112]
atom [1089,1112]
===
match
---
arglist [2335,2379]
arglist [2576,2620]
===
match
---
name: Dict [1394,1398]
name: Dict [1394,1398]
===
match
---
name: output_encoding [3340,3355]
name: output_encoding [3581,3596]
===
match
---
name: Popen [899,904]
name: Popen [899,904]
===
match
---
name: signal [2768,2774]
name: signal [3009,3015]
===
match
---
trailer [2865,2869]
trailer [3106,3110]
===
match
---
operator: , [944,945]
operator: , [944,945]
===
match
---
name: sub_process [3426,3437]
name: sub_process [3667,3678]
===
match
---
name: str [1366,1369]
name: str [1366,1369]
===
match
---
name: self [3735,3739]
name: self [3976,3980]
===
match
---
operator: = [3050,3051]
operator: = [3291,3292]
===
match
---
operator: = [3223,3224]
operator: = [3464,3465]
===
match
---
operator: , [2802,2803]
operator: , [3043,3044]
===
match
---
operator: , [3054,3055]
operator: , [3295,3296]
===
match
---
simple_stmt [3181,3206]
simple_stmt [3422,3447]
===
match
---
param [1338,1343]
param [1338,1343]
===
match
---
name: raw_line [3244,3252]
name: raw_line [3485,3493]
===
match
---
atom_expr [2768,2819]
atom_expr [3009,3060]
===
match
---
atom_expr [3382,3407]
atom_expr [3623,3648]
===
match
---
name: __init__ [1297,1305]
name: __init__ [1297,1305]
===
match
---
name: rstrip [3357,3363]
name: rstrip [3598,3604]
===
match
---
trailer [3437,3442]
trailer [3678,3683]
===
match
---
simple_stmt [3382,3408]
simple_stmt [3623,3649]
===
match
---
import_as_names [976,996]
import_as_names [976,996]
===
match
---
atom_expr [2939,3167]
atom_expr [3180,3408]
===
match
---
atom_expr [3324,3365]
atom_expr [3565,3606]
===
match
---
name: sig [2798,2801]
name: sig [3039,3042]
===
match
---
trailer [3189,3194]
trailer [3430,3435]
===
match
---
arglist [2730,2741]
arglist [2971,2982]
===
match
---
name: self [1234,1238]
name: self [1234,1238]
===
match
---
param [1352,1371]
param [1352,1371]
===
match
---
simple_stmt [3218,3228]
simple_stmt [3459,3469]
===
match
---
trailer [2329,2334]
trailer [2570,2575]
===
match
---
suite [2426,3539]
suite [2667,3780]
===
match
---
string: 'Running command: %s' [2875,2896]
string: 'Running command: %s' [3116,3137]
===
match
---
suite [3652,3930]
suite [3893,4171]
===
match
---
name: cwd [2471,2474]
name: cwd [2712,2715]
===
match
---
name: command [2898,2905]
name: command [3139,3146]
===
match
---
suite [2743,2820]
suite [2984,3061]
===
match
---
operator: = [2522,2523]
operator: = [2763,2764]
===
match
---
trailer [3831,3856]
trailer [4072,4097]
===
match
---
name: Optional [988,996]
name: Optional [988,996]
===
match
---
atom_expr [1058,1113]
atom_expr [1058,1113]
===
match
---
arglist [1069,1112]
arglist [1069,1112]
===
match
---
string: 'airflowtmp' [2523,2535]
string: 'airflowtmp' [2764,2776]
===
match
---
atom_expr [3510,3537]
atom_expr [3751,3778]
===
match
---
name: SIG_DFL [2811,2818]
name: SIG_DFL [3052,3059]
===
match
---
name: log [3463,3466]
name: log [3704,3707]
===
match
---
name: prefix [2516,2522]
name: prefix [2757,2763]
===
match
---
trailer [3194,3205]
trailer [3435,3446]
===
match
---
name: hooks [1011,1016]
name: hooks [1011,1016]
===
match
---
simple_stmt [2471,2538]
simple_stmt [2712,2779]
===
match
---
operator: , [1101,1102]
operator: , [1101,1102]
===
match
---
atom_expr [2394,2416]
atom_expr [2635,2657]
===
match
---
name: Popen [2939,2944]
name: Popen [3180,3185]
===
match
---
trailer [3185,3189]
trailer [3426,3430]
===
match
---
trailer [2334,2380]
trailer [2575,2621]
===
match
---
operator: = [1447,1448]
operator: = [1447,1448]
===
match
---
atom_expr [2804,2818]
atom_expr [3045,3059]
===
match
---
name: sub_process [3896,3907]
name: sub_process [4137,4148]
===
match
---
atom_expr [2367,2379]
atom_expr [2608,2620]
===
match
---
name: readline [3285,3293]
name: readline [3526,3534]
===
match
---
trailer [2810,2818]
trailer [3051,3059]
===
match
---
trailer [3425,3437]
trailer [3666,3678]
===
match
---
string: 'output' [1103,1111]
string: 'output' [1103,1111]
===
match
---
trailer [2781,2819]
trailer [3022,3060]
===
match
---
suite [3300,3408]
suite [3541,3649]
===
match
---
atom_expr [3824,3856]
atom_expr [4065,4097]
===
match
---
simple_stmt [905,957]
simple_stmt [905,957]
===
match
---
name: signal [820,826]
name: signal [820,826]
===
match
---
classdef [1116,3930]
classdef [1116,4171]
===
match
---
with_item [2394,2425]
with_item [2635,2666]
===
match
---
trailer [2404,2414]
trailer [2645,2655]
===
match
---
atom_expr [3458,3538]
atom_expr [3699,3779]
===
match
---
simple_stmt [862,905]
simple_stmt [862,905]
===
match
---
name: self [3458,3462]
name: self [3699,3703]
===
match
---
atom_expr [3582,3609]
atom_expr [3823,3850]
===
match
---
trailer [2944,3167]
trailer [3185,3408]
===
match
---
string: 'pid' [3850,3855]
string: 'pid' [4091,4096]
===
match
---
file_input [785,3930]
file_input [785,4171]
===
match
---
trailer [3882,3890]
trailer [4123,4131]
===
match
---
operator: , [3029,3030]
operator: , [3270,3271]
===
match
---
string: """Sends SIGTERM signal to ``self.sub_process`` if one exists.""" [3661,3726]
string: """Sends SIGTERM signal to ``self.sub_process`` if one exists.""" [3902,3967]
===
match
---
trailer [3598,3609]
trailer [3839,3850]
===
match
---
trailer [1068,1113]
trailer [1068,1113]
===
match
---
name: subprocess [867,877]
name: subprocess [867,877]
===
match
---
simple_stmt [957,997]
simple_stmt [957,997]
===
match
---
string: 'SIGPIPE' [2666,2675]
string: 'SIGPIPE' [2907,2916]
===
match
---
simple_stmt [1039,1114]
simple_stmt [1039,1114]
===
match
---
trailer [2845,2847]
trailer [3086,3088]
===
match
---
name: PIPE [2994,2998]
name: PIPE [3235,3239]
===
match
---
suite [1509,3624]
suite [1509,3865]
===
match
---
import_from [957,996]
import_from [957,996]
===
match
---
name: self [2861,2865]
name: self [3102,3106]
===
match
---
name: SubprocessResult [1492,1508]
name: SubprocessResult [1492,1508]
===
match
---
import_from [862,904]
import_from [862,904]
===
match
---
name: self [2920,2924]
name: self [3161,3165]
===
match
---
name: sub_process [3515,3526]
name: sub_process [3756,3767]
===
match
---
suite [2566,2848]
suite [2807,3089]
===
match
---
name: str [1404,1407]
name: str [1404,1407]
===
match
---
name: returncode [3599,3609]
name: returncode [3840,3850]
===
match
---
funcdef [1313,3624]
funcdef [1313,3865]
===
match
---
operator: , [897,898]
operator: , [897,898]
===
match
---
expr_stmt [1257,1280]
expr_stmt [1257,1280]
===
match
---
simple_stmt [785,803]
simple_stmt [785,803]
===
match
---
trailer [2874,2906]
trailer [3115,3147]
===
match
---
operator: , [1087,1088]
operator: , [1087,1088]
===
match
---
atom_expr [3803,3819]
atom_expr [4044,4060]
===
match
---
atom_expr [3914,3928]
atom_expr [4155,4169]
===
match
---
name: setsid [2839,2845]
name: setsid [3080,3086]
===
match
---
trailer [3390,3395]
trailer [3631,3636]
===
match
---
trailer [3748,3791]
trailer [3989,4032]
===
match
---
for_stmt [3240,3408]
for_stmt [3481,3649]
===
match
---
arglist [3472,3537]
arglist [3713,3778]
===
match
---
argument [3047,3054]
argument [3288,3295]
===
match
---
atom_expr [3181,3205]
atom_expr [3422,3446]
===
match
---
operator: , [2685,2686]
operator: , [2926,2927]
===
match
---
string: 'SIGXFSZ' [2687,2696]
string: 'SIGXFSZ' [2928,2937]
===
match
---
expr_stmt [3218,3227]
expr_stmt [3459,3468]
===
match
---
trailer [2729,2742]
trailer [2970,2983]
===
match
---
operator: , [2896,2897]
operator: , [3137,3138]
===
match
---
operator: = [3022,3023]
operator: = [3263,3264]
===
match
---
operator: = [1274,1275]
operator: = [1274,1275]
===
match
---
name: info [3744,3748]
name: info [3985,3989]
===
match
---
suite [3857,3930]
suite [4098,4171]
===
match
---
name: signal [2730,2736]
name: signal [2971,2977]
===
match
---
import_from [905,956]
import_from [905,956]
===
match
---
name: airflow [1003,1010]
name: airflow [1003,1010]
===
match
---
name: log [2326,2329]
name: log [2567,2570]
===
match
---
trailer [3739,3743]
trailer [3980,3984]
===
match
---
name: stdout [3278,3284]
name: stdout [3519,3525]
===
match
---
parameters [1233,1239]
parameters [1233,1239]
===
match
---
name: sig [2738,2741]
name: sig [2979,2982]
===
match
---
name: decode [3333,3339]
name: decode [3574,3580]
===
match
---
parameters [3645,3651]
parameters [3886,3892]
===
match
---
simple_stmt [3661,3727]
simple_stmt [3902,3968]
===
match
---
string: 'exit_code' [1090,1101]
string: 'exit_code' [1090,1101]
===
match
---
atom [2665,2697]
atom [2906,2938]
===
match
---
trailer [2789,2802]
trailer [3030,3043]
===
match
---
operator: = [2475,2476]
operator: = [2716,2717]
===
update-node
---
string: """         Execute the command.          If ``cwd`` is None, execute the command in a temporary directory which will be cleaned afterwards.         If ``env`` is not supplied, ``os.environ`` is passed          :param command: the command to run         :param env: Optional dict containing environment variables to be made available to the shell             environment in which ``command`` will be executed.  If omitted, ``os.environ`` will be used.         :param output_encoding: encoding to use for decoding stdout         :param cwd: Working directory to run the command in.             If None (default), the command is run in a temporary directory.         :return: :class:`namedtuple` containing ``exit_code`` and ``output``, the last line from stderr             or stdout         """ [1518,2312]
replace """         Execute the command.          If ``cwd`` is None, execute the command in a temporary directory which will be cleaned afterwards.         If ``env`` is not supplied, ``os.environ`` is passed          :param command: the command to run         :param env: Optional dict containing environment variables to be made available to the shell             environment in which ``command`` will be executed.  If omitted, ``os.environ`` will be used.         :param output_encoding: encoding to use for decoding stdout         :param cwd: Working directory to run the command in.             If None (default), the command is run in a temporary directory.         :return: :class:`namedtuple` containing ``exit_code`` and ``output``, the last line from stderr             or stdout         """ by """         Execute the command.          If ``cwd`` is None, execute the command in a temporary directory which will be cleaned afterwards.         If ``env`` is not supplied, ``os.environ`` is passed          :param command: the command to run         :param env: Optional dict containing environment variables to be made available to the shell             environment in which ``command`` will be executed.  If omitted, ``os.environ`` will be used.             Note, that in case you have Sentry configured, original variables from the environment             will also be passed to the subprocess with ``SUBPROCESS_`` prefix. See             :doc:`/logging-monitoring/errors` for details.         :param output_encoding: encoding to use for decoding stdout         :param cwd: Working directory to run the command in.             If None (default), the command is run in a temporary directory.         :return: :class:`namedtuple` containing ``exit_code`` and ``output``, the last line from stderr             or stdout         """
