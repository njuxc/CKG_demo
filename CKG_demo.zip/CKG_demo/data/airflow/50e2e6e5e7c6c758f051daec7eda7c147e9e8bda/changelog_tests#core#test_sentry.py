===
match
---
name: reload [2293,2299]
name: reload [2338,2344]
===
match
---
param [2414,2427]
param [2459,2472]
===
match
---
expr_stmt [1187,1201]
expr_stmt [1187,1201]
===
match
---
name: value [2598,2603]
name: value [2643,2648]
===
match
---
name: isoformat [2705,2714]
name: isoformat [2750,2759]
===
match
---
name: datetime [795,803]
name: datetime [795,803]
===
match
---
operator: } [1675,1676]
operator: } [1675,1676]
===
match
---
trailer [2618,2624]
trailer [2663,2669]
===
match
---
name: timezone [988,996]
name: timezone [988,996]
===
match
---
operator: { [1393,1394]
operator: { [1393,1394]
===
match
---
suite [2429,2676]
suite [2474,2721]
===
match
---
trailer [1215,1223]
trailer [1215,1223]
===
match
---
name: airflow [967,974]
name: airflow [967,974]
===
match
---
name: importlib [811,820]
name: importlib [811,820]
===
match
---
trailer [2848,2860]
trailer [2893,2905]
===
match
---
dictorsetmaker [1243,1378]
dictorsetmaker [1243,1378]
===
match
---
atom [2196,2219]
atom [2196,2219]
===
match
---
operator: @ [2681,2682]
operator: @ [2726,2727]
===
match
---
name: dag_maker [2100,2109]
name: dag_maker [2100,2109]
===
match
---
operator: , [1629,1630]
operator: , [1629,1630]
===
match
---
simple_stmt [1965,1991]
simple_stmt [1965,1991]
===
match
---
trailer [2292,2299]
trailer [2337,2344]
===
match
---
simple_stmt [2024,2039]
simple_stmt [2024,2039]
===
match
---
atom [2195,2228]
atom [2195,2273]
===
match
---
expr_stmt [1159,1186]
expr_stmt [1159,1186]
===
match
---
operator: @ [2134,2135]
operator: @ [2134,2135]
===
match
---
param [1743,1748]
param [1743,1748]
===
match
---
suite [2576,2676]
suite [2621,2721]
===
match
---
expr_stmt [1224,1380]
expr_stmt [1224,1380]
===
match
---
import_from [2243,2269]
import_from [2288,2314]
===
match
---
name: sentry [2842,2848]
name: sentry [2887,2893]
===
match
---
operator: = [2874,2875]
operator: = [2919,2920]
===
match
---
name: pytest [1706,1712]
name: pytest [1706,1712]
===
match
---
name: sentry [2326,2332]
name: sentry [2371,2377]
===
match
---
operator: , [1259,1260]
operator: , [1259,1260]
===
match
---
number: 0 [1988,1989]
number: 0 [1988,1989]
===
match
---
atom_expr [1210,1223]
atom_expr [1210,1223]
===
match
---
name: task_instance [2521,2534]
name: task_instance [2566,2579]
===
match
---
simple_stmt [1035,1081]
simple_stmt [1035,1081]
===
match
---
name: config [1057,1063]
name: config [1057,1063]
===
match
---
operator: , [2205,2206]
operator: , [2205,2206]
===
match
---
simple_stmt [1159,1187]
simple_stmt [1159,1187]
===
match
---
name: task_instances [1973,1987]
name: task_instances [1973,1987]
===
match
---
suite [2627,2676]
suite [2672,2721]
===
match
---
name: PythonOperator [1835,1849]
name: PythonOperator [1835,1849]
===
match
---
name: EXECUTION_DATE [1307,1321]
name: EXECUTION_DATE [1307,1321]
===
match
---
name: task [1828,1832]
name: task [1828,1832]
===
match
---
operator: , [2751,2752]
operator: , [2796,2797]
===
match
---
simple_stmt [1137,1159]
simple_stmt [1137,1159]
===
match
---
atom_expr [3017,3041]
atom_expr [3062,3086]
===
match
---
name: state [2002,2007]
name: state [2002,2007]
===
match
---
yield_expr [2320,2339]
yield_expr [2365,2384]
===
match
---
name: utils [1010,1015]
name: utils [1010,1015]
===
match
---
name: test_add_tagging [2383,2399]
name: test_add_tagging [2428,2444]
===
match
---
name: sentry [2366,2372]
name: sentry [2411,2417]
===
match
---
name: key [2662,2665]
name: key [2707,2710]
===
match
---
name: execution_date [1926,1940]
name: execution_date [1926,1940]
===
match
---
name: airflow [2248,2255]
name: airflow [2293,2300]
===
match
---
operator: { [1237,1238]
operator: { [1237,1238]
===
match
---
operator: @ [1705,1706]
operator: @ [1705,1706]
===
match
---
simple_stmt [2320,2340]
simple_stmt [2365,2385]
===
match
---
expr_stmt [1965,1990]
expr_stmt [1965,1990]
===
match
---
name: test_crumb [3070,3080]
name: test_crumb [3115,3125]
===
match
---
import_from [910,961]
import_from [910,961]
===
match
---
number: 15 [1530,1532]
number: 15 [1530,1532]
===
match
---
simple_stmt [1202,1224]
simple_stmt [1202,1224]
===
match
---
name: task_id [1850,1857]
name: task_id [1850,1857]
===
match
---
name: TASK_ID [1137,1144]
name: TASK_ID [1137,1144]
===
match
---
operator: , [2412,2413]
operator: , [2457,2458]
===
match
---
trailer [2001,2007]
trailer [2001,2007]
===
match
---
trailer [2109,2117]
trailer [2109,2117]
===
match
---
atom_expr [2349,2373]
atom_expr [2394,2418]
===
match
---
atom_expr [2185,2229]
atom_expr [2185,2274]
===
match
---
name: task_instance [2935,2948]
name: task_instance [2980,2993]
===
match
---
import_name [822,835]
import_name [822,835]
===
match
---
simple_stmt [2349,2374]
simple_stmt [2394,2419]
===
match
---
parameters [2164,2170]
parameters [2164,2170]
===
match
---
atom_expr [2694,2716]
atom_expr [2739,2761]
===
match
---
string: "PythonOperator" [1170,1186]
string: "PythonOperator" [1170,1186]
===
match
---
operator: } [1379,1380]
operator: } [1379,1380]
===
match
---
name: CRUMB_DATE [1490,1500]
name: CRUMB_DATE [1490,1500]
===
match
---
operator: , [1525,1526]
operator: , [1525,1526]
===
match
---
decorated [2134,2374]
decorated [2134,2419]
===
match
---
trailer [1806,1814]
trailer [1806,1814]
===
match
---
name: sentry [2300,2306]
name: sentry [2345,2351]
===
match
---
name: conf_vars [2185,2194]
name: conf_vars [2185,2194]
===
match
---
operator: } [2227,2228]
operator: } [2272,2273]
===
match
---
name: dr [1970,1972]
name: dr [1970,1972]
===
match
---
name: OPERATOR [1455,1463]
name: OPERATOR [1455,1463]
===
match
---
argument [1867,1886]
argument [1867,1886]
===
match
---
trailer [2624,2626]
trailer [2669,2671]
===
match
---
atom_expr [2651,2666]
atom_expr [2696,2711]
===
match
---
name: scope [2607,2612]
name: scope [2652,2657]
===
match
---
param [2753,2760]
param [2798,2805]
===
match
---
name: CRUMB [3061,3066]
name: CRUMB [3106,3111]
===
match
---
name: TEST_SCOPE [1224,1234]
name: TEST_SCOPE [1224,1234]
===
match
---
expr_stmt [1490,1533]
expr_stmt [1490,1533]
===
match
---
assert_stmt [3054,3080]
assert_stmt [3099,3125]
===
match
---
exprlist [2593,2603]
exprlist [2638,2648]
===
match
---
operator: = [1198,1199]
operator: = [1198,1199]
===
match
---
file_input [788,3081]
file_input [788,3126]
===
match
---
atom [1237,1380]
atom [1237,1380]
===
match
---
operator: , [1571,1572]
operator: , [1571,1572]
===
match
---
atom_expr [2488,2535]
atom_expr [2533,2580]
===
match
---
name: task_instance [2761,2774]
name: task_instance [2806,2819]
===
match
---
name: sentry [2898,2904]
name: sentry [2943,2949]
===
match
---
string: """         Test adding breadcrumbs.         """ [2785,2833]
string: """         Test adding breadcrumbs.         """ [2830,2878]
===
match
---
operator: { [1542,1543]
operator: { [1542,1543]
===
match
---
import_name [804,820]
import_name [804,820]
===
match
---
name: scope [3017,3022]
name: scope [3062,3067]
===
match
---
name: task_instance [2414,2427]
name: task_instance [2459,2472]
===
match
---
assert_stmt [2644,2675]
assert_stmt [2689,2720]
===
match
---
operator: , [1652,1653]
operator: , [1652,1653]
===
match
---
trailer [1911,1925]
trailer [1911,1925]
===
match
---
name: EXECUTION_DATE [1941,1955]
name: EXECUTION_DATE [1941,1955]
===
match
---
name: task_instance [2861,2874]
name: task_instance [2906,2919]
===
match
---
trailer [1849,1887]
trailer [1849,1887]
===
match
---
decorated [1705,2129]
decorated [1705,2129]
===
match
---
yield_expr [2082,2090]
yield_expr [2082,2090]
===
match
---
number: 1 [1200,1201]
number: 1 [1200,1201]
===
match
---
name: STATE [1202,1207]
name: STATE [1202,1207]
===
match
---
name: conf_vars [1071,1080]
name: conf_vars [1071,1080]
===
match
---
simple_stmt [804,821]
simple_stmt [804,821]
===
match
---
trailer [3039,3041]
trailer [3084,3086]
===
match
---
name: sentry [2263,2269]
name: sentry [2308,2314]
===
match
---
parameters [2399,2428]
parameters [2444,2473]
===
match
---
param [2400,2405]
param [2445,2450]
===
match
---
name: ti [2088,2090]
name: ti [2088,2090]
===
match
---
string: """         Test adding tags.         """ [2438,2479]
string: """         Test adding tags.         """ [2483,2524]
===
match
---
operator: { [2195,2196]
operator: { [2195,2196]
===
match
---
operator: = [2520,2521]
operator: = [2565,2566]
===
match
---
name: DAG_ID [1253,1259]
name: DAG_ID [1253,1259]
===
match
---
trailer [1972,1987]
trailer [1972,1987]
===
match
---
trailer [2920,2949]
trailer [2965,2994]
===
match
---
dotted_name [1706,1720]
dotted_name [1706,1720]
===
match
---
name: scope [2985,2990]
name: scope [3030,3035]
===
match
---
funcdef [2722,3081]
funcdef [2767,3126]
===
match
---
name: sentry [2488,2494]
name: sentry [2533,2539]
===
match
---
operator: = [1391,1392]
operator: = [1391,1392]
===
match
---
trailer [2299,2307]
trailer [2344,2352]
===
match
---
argument [2921,2948]
argument [2966,2993]
===
match
---
name: OPERATOR [1159,1167]
name: OPERATOR [1159,1167]
===
match
---
name: value [2670,2675]
name: value [2715,2720]
===
match
---
name: task_instance [2507,2520]
name: task_instance [2552,2565]
===
match
---
import_from [836,869]
import_from [836,869]
===
match
---
name: task [2034,2038]
name: task [2034,2038]
===
match
---
atom_expr [1099,1116]
atom_expr [1099,1116]
===
match
---
arglist [1521,1532]
arglist [1521,1532]
===
match
---
name: items [2619,2624]
name: items [2664,2669]
===
match
---
expr_stmt [1082,1116]
expr_stmt [1082,1116]
===
match
---
atom_expr [1503,1533]
atom_expr [1503,1533]
===
match
---
name: flush [2065,2070]
name: flush [2065,2070]
===
match
---
simple_stmt [1999,2016]
simple_stmt [1999,2016]
===
match
---
operator: , [1485,1486]
operator: , [1485,1486]
===
match
---
atom_expr [2964,2981]
atom_expr [3009,3026]
===
match
---
trailer [2979,2981]
trailer [3024,3026]
===
match
---
operator: = [1501,1502]
operator: = [1501,1502]
===
match
---
operator: = [1124,1125]
operator: = [1124,1125]
===
match
---
string: "category" [1600,1610]
string: "category" [1600,1610]
===
match
---
operator: , [1377,1378]
operator: , [1377,1378]
===
match
---
simple_stmt [1082,1117]
simple_stmt [1082,1117]
===
match
---
dotted_name [967,980]
dotted_name [967,980]
===
match
---
name: int [1883,1886]
name: int [1883,1886]
===
match
---
name: sentry [2753,2759]
name: sentry [2798,2804]
===
match
---
import_from [1035,1080]
import_from [1035,1080]
===
match
---
param [2761,2774]
param [2806,2819]
===
match
---
simple_stmt [2785,2834]
simple_stmt [2830,2879]
===
match
---
simple_stmt [1187,1202]
simple_stmt [1187,1202]
===
match
---
import_name [788,803]
import_name [788,803]
===
match
---
dictorsetmaker [1399,1486]
dictorsetmaker [1399,1486]
===
match
---
atom_expr [2549,2566]
atom_expr [2594,2611]
===
match
---
operator: , [1594,1595]
operator: , [1594,1595]
===
match
---
testlist_comp [2197,2218]
testlist_comp [2197,2218]
===
match
---
simple_stmt [870,909]
simple_stmt [870,909]
===
match
---
name: TASK_DATA [1643,1652]
name: TASK_DATA [1643,1652]
===
match
---
parameters [2746,2775]
parameters [2791,2820]
===
match
---
atom_expr [2842,2889]
atom_expr [2887,2934]
===
match
---
name: self [2400,2404]
name: self [2445,2449]
===
match
---
trailer [1520,1533]
trailer [1520,1533]
===
match
---
argument [2507,2534]
argument [2552,2579]
===
match
---
expr_stmt [2024,2038]
expr_stmt [2024,2038]
===
match
---
funcdef [2379,2676]
funcdef [2424,2721]
===
match
---
name: Sentry [2333,2339]
name: Sentry [2378,2384]
===
match
---
import_from [962,996]
import_from [962,996]
===
match
---
expr_stmt [3004,3041]
expr_stmt [3049,3086]
===
match
---
atom_expr [1999,2007]
atom_expr [1999,2007]
===
match
---
operator: , [2404,2405]
operator: , [2449,2450]
===
match
---
trailer [1511,1520]
trailer [1511,1520]
===
match
---
with_stmt [2180,2340]
with_stmt [2180,2385]
===
match
---
name: datetime [1512,1520]
name: datetime [1512,1520]
===
match
---
name: add_tagging [2495,2506]
name: add_tagging [2540,2551]
===
match
---
name: ti [2024,2026]
name: ti [2024,2026]
===
match
---
name: sentry [2406,2412]
name: sentry [2451,2457]
===
match
---
name: airflow [1002,1009]
name: airflow [1002,1009]
===
match
---
name: DAG_ID [1807,1813]
name: DAG_ID [1807,1813]
===
match
---
operator: = [1168,1169]
operator: = [1168,1169]
===
match
---
trailer [2494,2506]
trailer [2539,2551]
===
match
---
operator: , [1865,1866]
operator: , [1865,1866]
===
match
---
simple_stmt [822,836]
simple_stmt [822,836]
===
match
---
name: sentry [2158,2164]
name: sentry [2158,2164]
===
match
---
trailer [2564,2566]
trailer [2609,2611]
===
match
---
suite [1815,1888]
suite [1815,1888]
===
match
---
trailer [2332,2339]
trailer [2377,2384]
===
match
---
operator: , [1747,1748]
operator: , [1747,1748]
===
match
---
decorator [2681,2718]
decorator [2726,2763]
===
match
---
operator: = [1882,1883]
operator: = [1882,1883]
===
match
---
suite [2776,3081]
suite [2821,3126]
===
match
---
operator: = [1900,1901]
operator: = [1900,1901]
===
match
---
operator: , [1417,1418]
operator: , [1417,1418]
===
match
---
name: pop [3036,3039]
name: pop [3081,3084]
===
match
---
simple_stmt [1117,1137]
simple_stmt [1117,1137]
===
match
---
name: _breadcrumbs [3023,3035]
name: _breadcrumbs [3068,3080]
===
match
---
operator: = [2934,2935]
operator: = [2979,2980]
===
match
---
trailer [2126,2128]
trailer [2126,2128]
===
match
---
name: importlib [2349,2358]
name: importlib [2394,2403]
===
match
---
comparison [3061,3080]
comparison [3106,3125]
===
match
---
name: OPERATOR [1339,1347]
name: OPERATOR [1339,1347]
===
match
---
atom_expr [2100,2128]
atom_expr [2100,2128]
===
match
---
simple_stmt [2488,2536]
simple_stmt [2533,2581]
===
match
---
trailer [2064,2070]
trailer [2064,2070]
===
match
---
name: pytest [829,835]
name: pytest [829,835]
===
match
---
string: "completed_tasks" [1612,1629]
string: "completed_tasks" [1612,1629]
===
match
---
name: python [933,939]
name: python [933,939]
===
match
---
name: TestSentryHook [1685,1699]
name: TestSentryHook [1685,1699]
===
match
---
name: CRUMB_DATE [2694,2704]
name: CRUMB_DATE [2739,2749]
===
match
---
string: "default" [1585,1594]
string: "default" [1585,1594]
===
match
---
trailer [3035,3039]
trailer [3080,3084]
===
match
---
operator: = [1235,1236]
operator: = [1235,1236]
===
match
---
simple_stmt [2644,2676]
simple_stmt [2689,2721]
===
match
---
trailer [2365,2373]
trailer [2410,2418]
===
match
---
name: CRUMB [1534,1539]
name: CRUMB [1534,1539]
===
match
---
dotted_name [1040,1063]
dotted_name [1040,1063]
===
match
---
name: TRY_NUMBER [1187,1197]
name: TRY_NUMBER [1187,1197]
===
match
---
simple_stmt [1490,1534]
simple_stmt [1490,1534]
===
match
---
operator: , [1528,1529]
operator: , [1528,1529]
===
match
---
name: add_breadcrumbs [2905,2920]
name: add_breadcrumbs [2950,2965]
===
match
---
parameters [1742,1759]
parameters [1742,1759]
===
match
---
operator: = [1940,1941]
operator: = [1940,1941]
===
match
---
name: create_dagrun [1912,1925]
name: create_dagrun [1912,1925]
===
match
---
atom_expr [2024,2031]
atom_expr [2024,2031]
===
match
---
decorated [2681,3081]
decorated [2726,3126]
===
match
---
trailer [1925,1956]
trailer [1925,1956]
===
match
---
name: TASK_ID [1858,1865]
name: TASK_ID [1858,1865]
===
match
---
name: dag_maker [2047,2056]
name: dag_maker [2047,2056]
===
match
---
name: state [1016,1021]
name: state [1016,1021]
===
match
---
operator: = [3015,3016]
operator: = [3060,3061]
===
match
---
string: "info" [1667,1673]
string: "info" [1667,1673]
===
match
---
string: "data" [1635,1641]
string: "data" [1635,1641]
===
match
---
expr_stmt [1828,1887]
expr_stmt [1828,1887]
===
match
---
argument [1926,1955]
argument [1926,1955]
===
match
---
simple_stmt [997,1035]
simple_stmt [997,1035]
===
match
---
name: test_utils [1046,1056]
name: test_utils [1046,1056]
===
match
---
name: configure_scope [893,908]
name: configure_scope [893,908]
===
match
---
simple_stmt [1897,1957]
simple_stmt [1897,1957]
===
match
---
operator: == [3067,3069]
operator: == [3112,3114]
===
match
---
simple_stmt [2438,2480]
simple_stmt [2483,2525]
===
match
---
name: PythonOperator [947,961]
name: PythonOperator [947,961]
===
match
---
dotted_name [1002,1021]
dotted_name [1002,1021]
===
match
---
name: dag_maker [1797,1806]
name: dag_maker [1797,1806]
===
match
---
simple_stmt [2842,2890]
simple_stmt [2887,2935]
===
match
---
operator: = [1097,1098]
operator: = [1097,1098]
===
match
---
string: "dag_id" [1243,1251]
string: "dag_id" [1243,1251]
===
match
---
simple_stmt [910,962]
simple_stmt [910,962]
===
match
---
number: 5 [1527,1528]
number: 5 [1527,1528]
===
match
---
name: CRUMB_DATE [1561,1571]
name: CRUMB_DATE [1561,1571]
===
match
---
dotted_name [915,939]
dotted_name [915,939]
===
match
---
string: "operator" [1443,1453]
string: "operator" [1443,1453]
===
match
---
trailer [2194,2229]
trailer [2194,2274]
===
match
---
param [2406,2413]
param [2451,2458]
===
match
---
name: task_instance [2875,2888]
name: task_instance [2920,2933]
===
match
---
with_stmt [1792,1888]
with_stmt [1792,1888]
===
match
---
expr_stmt [1897,1956]
expr_stmt [1897,1956]
===
match
---
simple_stmt [2082,2091]
simple_stmt [2082,2091]
===
match
---
trailer [2506,2535]
trailer [2551,2580]
===
match
---
comparison [2651,2675]
comparison [2696,2720]
===
match
---
expr_stmt [1534,1676]
expr_stmt [1534,1676]
===
match
---
param [2165,2169]
param [2165,2169]
===
match
---
string: "level" [1658,1665]
string: "level" [1658,1665]
===
match
---
name: fixture [2142,2149]
name: fixture [2142,2149]
===
match
---
atom [1393,1488]
atom [1393,1488]
===
match
---
dictorsetmaker [2196,2227]
dictorsetmaker [2196,2272]
===
match
---
string: "state" [1423,1430]
string: "state" [1423,1430]
===
match
---
name: self [1743,1747]
name: self [1743,1747]
===
match
---
suite [2991,3081]
suite [3036,3126]
===
match
---
expr_stmt [1117,1136]
expr_stmt [1117,1136]
===
match
---
operator: , [1463,1464]
operator: , [1463,1464]
===
match
---
name: State [1029,1034]
name: State [1029,1034]
===
match
---
classdef [1679,3081]
classdef [1679,3126]
===
match
---
decorator [1705,1721]
decorator [1705,1721]
===
match
---
string: "test_dag" [1126,1136]
string: "test_dag" [1126,1136]
===
match
---
name: TEST_SCOPE [2651,2661]
name: TEST_SCOPE [2696,2706]
===
match
---
with_item [2964,2990]
with_item [3009,3035]
===
match
---
name: TASK_ID [1276,1283]
name: TASK_ID [1276,1283]
===
match
---
name: State [1210,1215]
name: State [1210,1215]
===
match
---
trailer [1114,1116]
trailer [1114,1116]
===
match
---
string: "operator" [1327,1337]
string: "operator" [1327,1337]
===
match
---
string: "timestamp" [1548,1559]
string: "timestamp" [1548,1559]
===
match
---
name: datetime [1503,1511]
name: datetime [1503,1511]
===
match
---
trailer [2714,2716]
trailer [2759,2761]
===
match
---
name: dag_maker [1749,1758]
name: dag_maker [1749,1758]
===
match
---
name: session [2057,2064]
name: session [2057,2064]
===
match
---
operator: , [1437,1438]
operator: , [1437,1438]
===
match
---
name: SUCCESS [1216,1223]
name: SUCCESS [1216,1223]
===
match
---
trailer [2860,2889]
trailer [2905,2934]
===
match
---
decorator [2134,2150]
decorator [2134,2150]
===
match
---
name: freezegun [841,850]
name: freezegun [841,850]
===
match
---
funcdef [2154,2374]
funcdef [2154,2419]
===
match
---
string: 'sentry' [2197,2205]
string: 'sentry' [2197,2205]
===
match
---
atom_expr [2607,2626]
atom_expr [2652,2671]
===
match
---
trailer [2117,2126]
trailer [2117,2126]
===
match
---
string: 'sentry_on' [2207,2218]
string: 'sentry_on' [2207,2218]
===
match
---
with_stmt [2544,2676]
with_stmt [2589,2721]
===
match
---
simple_stmt [788,804]
simple_stmt [788,804]
===
match
---
name: _tags [2613,2618]
name: _tags [2658,2663]
===
match
---
trailer [2056,2064]
trailer [2056,2064]
===
match
---
name: self [2747,2751]
name: self [2792,2796]
===
match
---
expr_stmt [1202,1223]
expr_stmt [1202,1223]
===
match
---
name: test_add_breadcrumbs [2726,2746]
name: test_add_breadcrumbs [2771,2791]
===
match
---
argument [2861,2888]
argument [2906,2933]
===
match
---
param [2747,2752]
param [2792,2797]
===
match
---
atom_expr [1797,1814]
atom_expr [1797,1814]
===
match
---
simple_stmt [2283,2308]
simple_stmt [2328,2353]
===
match
---
name: freeze_time [2682,2693]
name: freeze_time [2727,2738]
===
match
---
name: session [2110,2117]
name: session [2110,2117]
===
match
---
name: scope [2570,2575]
name: scope [2615,2620]
===
match
---
name: task [2027,2031]
name: task [2027,2031]
===
match
---
name: test_crumb [3004,3014]
name: test_crumb [3049,3059]
===
match
---
name: key [2593,2596]
name: key [2638,2641]
===
match
---
simple_stmt [836,870]
simple_stmt [836,870]
===
match
---
atom [1542,1676]
atom [1542,1676]
===
match
---
name: python_callable [1867,1882]
name: python_callable [1867,1882]
===
match
---
operator: } [1487,1488]
operator: } [1487,1488]
===
match
---
name: timezone [1099,1107]
name: timezone [1099,1107]
===
match
---
atom_expr [1902,1956]
atom_expr [1902,1956]
===
match
---
name: sentry_sdk [875,885]
name: sentry_sdk [875,885]
===
match
---
atom_expr [2047,2072]
atom_expr [2047,2072]
===
match
---
suite [1700,3081]
suite [1700,3126]
===
match
---
operator: = [1968,1969]
operator: = [1968,1969]
===
match
---
import_from [997,1034]
import_from [997,1034]
===
match
---
simple_stmt [1828,1888]
simple_stmt [1828,1888]
===
match
---
string: "task_id" [1265,1274]
string: "task_id" [1265,1274]
===
match
---
string: "execution_date" [1289,1305]
string: "execution_date" [1289,1305]
===
match
---
atom_expr [1970,1990]
atom_expr [1970,1990]
===
match
---
with_stmt [2959,3081]
with_stmt [3004,3126]
===
match
---
name: TASK_DATA [1381,1390]
name: TASK_DATA [1381,1390]
===
match
---
trailer [2904,2920]
trailer [2949,2965]
===
match
---
name: ti [1965,1967]
name: ti [1965,1967]
===
match
---
for_stmt [2589,2676]
for_stmt [2634,2721]
===
match
---
atom_expr [1835,1887]
atom_expr [1835,1887]
===
match
---
name: dr [1897,1899]
name: dr [1897,1899]
===
match
---
string: "try_number" [1353,1365]
string: "try_number" [1353,1365]
===
match
---
argument [1850,1865]
argument [1850,1865]
===
match
---
atom_expr [2283,2307]
atom_expr [2328,2352]
===
match
---
name: configure_scope [2549,2564]
name: configure_scope [2594,2609]
===
match
---
dictorsetmaker [1548,1674]
dictorsetmaker [1548,1674]
===
match
---
name: tests [1040,1045]
name: tests [1040,1045]
===
match
---
name: rollback [2118,2126]
name: rollback [2118,2126]
===
match
---
string: 'True' [2221,2227]
string: 'True' [2221,2227]
===
match
---
string: "type" [1577,1583]
string: "type" [1577,1583]
===
match
---
operator: == [2667,2669]
operator: == [2712,2714]
===
match
---
expr_stmt [1381,1488]
expr_stmt [1381,1488]
===
match
---
name: add_tagging [2849,2860]
name: add_tagging [2894,2905]
===
match
---
name: TRY_NUMBER [1367,1377]
name: TRY_NUMBER [1367,1377]
===
match
---
trailer [2070,2072]
trailer [2070,2072]
===
match
---
name: DAG_ID [1117,1123]
name: DAG_ID [1117,1123]
===
match
---
name: utils [975,980]
name: utils [975,980]
===
match
---
simple_stmt [1381,1489]
simple_stmt [1381,1489]
===
match
---
name: fixture [1713,1720]
name: fixture [1713,1720]
===
match
---
arglist [1850,1886]
arglist [1850,1886]
===
match
---
operator: = [1857,1858]
operator: = [1857,1858]
===
match
---
simple_stmt [2898,2950]
simple_stmt [2943,2995]
===
match
---
simple_stmt [1224,1381]
simple_stmt [1224,1381]
===
match
---
atom_expr [2898,2949]
atom_expr [2943,2994]
===
match
---
suite [2171,2374]
suite [2171,2419]
===
match
---
operator: , [1673,1674]
operator: , [1673,1674]
===
match
---
name: importlib [2283,2292]
name: importlib [2328,2337]
===
match
---
dotted_name [2135,2149]
dotted_name [2135,2149]
===
match
---
operator: = [1145,1146]
operator: = [1145,1146]
===
match
---
name: utcnow [1108,1114]
name: utcnow [1108,1114]
===
match
---
name: airflow [915,922]
name: airflow [915,922]
===
match
---
operator: , [1283,1284]
operator: , [1283,1284]
===
match
---
simple_stmt [1534,1677]
simple_stmt [1534,1677]
===
match
---
name: task_instance [1729,1742]
name: task_instance [1729,1742]
===
match
---
name: ti [1999,2001]
name: ti [1999,2001]
===
match
---
suite [2230,2340]
suite [2275,2385]
===
match
---
name: TASK_ID [1410,1417]
name: TASK_ID [1410,1417]
===
match
---
atom_expr [2326,2339]
atom_expr [2371,2384]
===
match
---
suite [1760,2129]
suite [1760,2129]
===
match
---
name: STATE [1432,1437]
name: STATE [1432,1437]
===
match
---
funcdef [1725,2129]
funcdef [1725,2129]
===
match
---
simple_stmt [2243,2270]
simple_stmt [2288,2315]
===
match
---
name: configure_scope [2964,2979]
name: configure_scope [3009,3024]
===
match
---
trailer [1987,1990]
trailer [1987,1990]
===
match
---
number: 2019 [1521,1525]
number: 2019 [1521,1525]
===
match
---
name: operators [923,932]
name: operators [923,932]
===
match
---
param [1749,1758]
param [1749,1758]
===
match
---
trailer [3022,3035]
trailer [3067,3080]
===
match
---
simple_stmt [962,997]
simple_stmt [962,997]
===
match
---
string: "duration" [1469,1479]
string: "duration" [1469,1479]
===
match
---
operator: , [1321,1322]
operator: , [1321,1322]
===
match
---
name: self [2165,2169]
name: self [2165,2169]
===
match
---
string: "task_id" [1399,1408]
string: "task_id" [1399,1408]
===
match
---
operator: , [2759,2760]
operator: , [2804,2805]
===
match
---
name: reload [2359,2365]
name: reload [2404,2410]
===
match
---
trailer [2612,2618]
trailer [2657,2663]
===
match
---
name: task_instance [2921,2934]
name: task_instance [2966,2979]
===
match
---
string: "test_task" [1147,1158]
string: "test_task" [1147,1158]
===
match
---
with_item [2549,2575]
with_item [2594,2620]
===
match
---
operator: = [2008,2009]
operator: = [2008,2009]
===
match
---
name: STATE [2010,2015]
name: STATE [2010,2015]
===
match
---
operator: , [2596,2597]
operator: , [2641,2642]
===
match
---
trailer [2026,2031]
trailer [2026,2031]
===
match
---
import_from [870,908]
import_from [870,908]
===
match
---
expr_stmt [1137,1158]
expr_stmt [1137,1158]
===
match
---
simple_stmt [3054,3081]
simple_stmt [3099,3126]
===
match
---
trailer [2358,2365]
trailer [2403,2410]
===
match
---
name: pytest [2135,2141]
name: pytest [2135,2141]
===
match
---
operator: = [2032,2033]
operator: = [2032,2033]
===
match
---
operator: = [1208,1209]
operator: = [1208,1209]
===
match
---
operator: = [1833,1834]
operator: = [1833,1834]
===
match
---
operator: = [1540,1541]
operator: = [1540,1541]
===
match
---
name: freeze_time [858,869]
name: freeze_time [858,869]
===
match
---
trailer [2661,2666]
trailer [2706,2711]
===
match
---
simple_stmt [3004,3042]
simple_stmt [3049,3087]
===
match
---
simple_stmt [2047,2073]
simple_stmt [2047,2073]
===
match
---
trailer [2704,2714]
trailer [2749,2759]
===
match
---
name: EXECUTION_DATE [1082,1096]
name: EXECUTION_DATE [1082,1096]
===
match
---
trailer [1107,1114]
trailer [1107,1114]
===
match
---
operator: , [1347,1348]
operator: , [1347,1348]
===
match
---
expr_stmt [1999,2015]
expr_stmt [1999,2015]
===
match
---
simple_stmt [2100,2129]
simple_stmt [2100,2129]
===
match
---
name: dag_maker [1902,1911]
name: dag_maker [1902,1911]
===
insert-node
---
operator: , [2227,2228]
to
dictorsetmaker [2196,2227]
at 2
===
insert-tree
---
atom [2229,2263]
    testlist_comp [2230,2262]
        string: 'sentry' [2230,2238]
        operator: , [2238,2239]
        string: 'default_integrations' [2240,2262]
to
dictorsetmaker [2196,2227]
at 3
===
insert-node
---
string: 'False' [2265,2272]
to
dictorsetmaker [2196,2227]
at 4
