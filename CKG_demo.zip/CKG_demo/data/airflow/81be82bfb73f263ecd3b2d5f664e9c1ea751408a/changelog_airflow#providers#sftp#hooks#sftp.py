===
match
---
simple_stmt [7447,7473]
simple_stmt [7447,7473]
===
match
---
comparison [2615,2637]
comparison [2615,2637]
===
match
---
simple_stmt [6022,6040]
simple_stmt [6022,6040]
===
match
---
atom_expr [4621,4667]
atom_expr [4621,4667]
===
match
---
name: warnings [2804,2812]
name: warnings [2804,2812]
===
match
---
operator: -> [6840,6842]
operator: -> [6840,6842]
===
match
---
name: warn [2899,2903]
name: warn [2899,2903]
===
match
---
name: tenacity [4558,4566]
name: tenacity [4558,4566]
===
match
---
name: close [6032,6037]
name: close [6032,6037]
===
match
---
simple_stmt [8924,8968]
simple_stmt [8771,8815]
===
match
---
name: self [5409,5413]
name: self [5409,5413]
===
match
---
simple_stmt [5238,5273]
simple_stmt [5238,5273]
===
match
---
name: conn_name_attr [1803,1817]
name: conn_name_attr [1803,1817]
===
match
---
if_stmt [10366,10446]
if_stmt [10213,10293]
===
match
---
simple_stmt [11508,11605]
simple_stmt [11355,11452]
===
match
---
name: _is_path_match [11555,11569]
name: _is_path_match [11402,11416]
===
match
---
string: 'sftp' [1889,1895]
string: 'sftp' [1889,1895]
===
match
---
name: pysftp [5847,5853]
name: pysftp [5847,5853]
===
match
---
string: 'true' [4243,4249]
string: 'true' [4243,4249]
===
match
---
name: hostkeys [5026,5034]
name: hostkeys [5026,5034]
===
match
---
name: path [11652,11656]
name: path [11499,11503]
===
match
---
operator: , [4596,4597]
operator: , [4596,4597]
===
match
---
name: ciphers [4323,4330]
name: ciphers [4323,4330]
===
match
---
name: conn [8303,8307]
name: conn [8231,8235]
===
match
---
atom_expr [2671,2688]
atom_expr [2671,2688]
===
match
---
name: cnopts [4912,4918]
name: cnopts [4912,4918]
===
match
---
name: append_matching_path_callback [11680,11709]
name: append_matching_path_callback [11527,11556]
===
match
---
name: self [5638,5642]
name: self [5638,5642]
===
match
---
param [9240,9249]
param [9087,9096]
===
match
---
tfpdef [2152,2168]
tfpdef [2152,2168]
===
match
---
atom_expr [2513,2529]
atom_expr [2513,2529]
===
match
---
simple_stmt [1877,1896]
simple_stmt [1877,1896]
===
match
---
string: 'private_key_pass' [2833,2851]
string: 'private_key_pass' [2833,2851]
===
match
---
trailer [6697,6705]
trailer [6697,6705]
===
match
---
name: password [5614,5622]
name: password [5614,5622]
===
match
---
operator: , [5055,5056]
operator: , [5055,5056]
===
match
---
atom_expr [4333,4357]
atom_expr [4333,4357]
===
match
---
name: host_key [5062,5070]
name: host_key [5062,5070]
===
match
---
trailer [5306,5314]
trailer [5306,5314]
===
match
---
name: self [4430,4434]
name: self [4430,4434]
===
match
---
name: conn [7416,7420]
name: conn [7416,7420]
===
match
---
expr_stmt [6395,6417]
expr_stmt [6395,6417]
===
match
---
trailer [2312,2317]
trailer [2312,2317]
===
match
---
operator: = [5300,5301]
operator: = [5300,5301]
===
match
---
name: stop [4509,4513]
name: stop [4509,4513]
===
match
---
operator: , [5495,5496]
operator: , [5495,5496]
===
match
---
name: tenacity [4485,4493]
name: tenacity [4485,4493]
===
match
---
dotted_name [4485,4499]
dotted_name [4485,4499]
===
match
---
name: files [6603,6608]
name: files [6603,6608]
===
match
---
atom_expr [9170,9185]
atom_expr [9017,9032]
===
match
---
operator: , [9871,9872]
operator: , [9718,9719]
===
match
---
simple_stmt [9401,9424]
simple_stmt [9248,9271]
===
match
---
trailer [4805,4810]
trailer [4805,4810]
===
match
---
name: port [5414,5418]
name: port [5414,5418]
===
match
---
name: conn [5992,5996]
name: conn [5992,5996]
===
match
---
name: CnOpts [4848,4854]
name: CnOpts [4848,4854]
===
match
---
name: path [9577,9581]
name: path [9424,9428]
===
match
---
trailer [4729,4740]
trailer [4729,4740]
===
match
---
expr_stmt [2370,2389]
expr_stmt [2370,2389]
===
match
---
parameters [6096,6113]
parameters [6096,6113]
===
match
---
comparison [4801,4818]
comparison [4801,4818]
===
match
---
name: extra_options [2855,2868]
name: extra_options [2855,2868]
===
match
---
operator: , [8475,8476]
operator: , [8322,8323]
===
match
---
operator: = [1887,1888]
operator: = [1887,1888]
===
match
---
param [2187,2193]
param [2187,2193]
===
match
---
trailer [2374,2382]
trailer [2374,2382]
===
match
---
name: self [7133,7137]
name: self [7133,7137]
===
match
---
name: conn [9163,9167]
name: conn [9010,9014]
===
match
---
arglist [2929,3317]
arglist [2929,3317]
===
match
---
name: kwargs [2291,2297]
name: kwargs [2291,2297]
===
match
---
operator: , [11897,11898]
operator: , [11744,11745]
===
match
---
name: retry_if_exception_type [4630,4653]
name: retry_if_exception_type [4630,4653]
===
match
---
name: files [6466,6471]
name: files [6466,6471]
===
match
---
name: staticmethod [1925,1937]
name: staticmethod [1925,1937]
===
match
---
operator: } [2115,2116]
operator: } [2115,2116]
===
match
---
atom_expr [5800,5821]
atom_expr [5800,5821]
===
match
---
strings [3628,3822]
strings [3628,3822]
===
match
---
name: get_tree_map [10567,10579]
name: get_tree_map [10414,10426]
===
match
---
expr_stmt [4912,4934]
expr_stmt [4912,4934]
===
match
---
suite [5566,5623]
suite [5566,5623]
===
match
---
name: get_conn [7428,7436]
name: get_conn [7428,7436]
===
match
---
name: cnopts [5238,5244]
name: cnopts [5238,5244]
===
match
---
string: 'type' [6676,6682]
string: 'type' [6676,6682]
===
match
---
name: extra_options [4333,4346]
name: extra_options [4333,4346]
===
match
---
name: prefix [10369,10375]
name: prefix [10216,10222]
===
match
---
atom_expr [8207,8222]
atom_expr [8207,8222]
===
match
---
if_stmt [5523,5623]
if_stmt [5523,5623]
===
match
---
operator: = [5798,5799]
operator: = [5798,5799]
===
match
---
name: f [6649,6650]
name: f [6649,6650]
===
match
---
string: 'sftp_default' [1858,1872]
string: 'sftp_default' [1858,1872]
===
match
---
name: get_conn [11350,11358]
name: get_conn [11197,11205]
===
match
---
atom_expr [6127,6141]
atom_expr [6127,6141]
===
match
---
import_from [853,899]
import_from [853,899]
===
match
---
expr_stmt [9401,9423]
expr_stmt [9248,9270]
===
match
---
trailer [9775,9784]
trailer [9622,9631]
===
match
---
trailer [5061,5070]
trailer [5061,5070]
===
match
---
argument [5865,5878]
argument [5865,5878]
===
match
---
operator: , [6827,6828]
operator: , [6827,6828]
===
match
---
simple_stmt [9023,9155]
simple_stmt [8870,9002]
===
match
---
atom_expr [5727,5748]
atom_expr [5727,5748]
===
match
---
name: self [7035,7039]
name: self [7035,7039]
===
match
---
trailer [5853,5864]
trailer [5853,5864]
===
match
---
atom_expr [4558,4605]
atom_expr [4558,4605]
===
match
---
name: private_key_pass [3361,3377]
name: private_key_pass [3361,3377]
===
match
---
name: conn [7447,7451]
name: conn [7447,7451]
===
match
---
name: delimiter [10501,10510]
name: delimiter [10348,10357]
===
match
---
comparison [10457,10478]
comparison [10304,10325]
===
match
---
operator: = [1818,1819]
operator: = [1818,1819]
===
match
---
arglist [7461,7471]
arglist [7461,7471]
===
match
---
name: bool [9591,9595]
name: bool [9438,9442]
===
match
---
name: item [11541,11545]
name: item [11388,11392]
===
match
---
suite [2212,4479]
suite [2212,4479]
===
match
---
string: 'ciphers' [4270,4279]
string: 'ciphers' [4270,4279]
===
match
---
name: path [9240,9244]
name: path [9087,9091]
===
match
---
simple_stmt [5766,5822]
simple_stmt [5766,5822]
===
match
---
name: ftp_conn_id [2245,2256]
name: ftp_conn_id [2245,2256]
===
match
---
operator: = [9406,9407]
operator: = [9253,9254]
===
match
---
trailer [4016,4047]
trailer [4016,4047]
===
match
---
trailer [10411,10419]
trailer [10258,10266]
===
match
---
name: self [7423,7427]
name: self [7423,7427]
===
match
---
operator: = [2355,2356]
operator: = [2355,2356]
===
match
---
expr_stmt [11369,11403]
expr_stmt [11216,11250]
===
match
---
atom [11393,11395]
atom [11240,11242]
===
match
---
operator: = [10628,10629]
operator: = [10475,10476]
===
match
---
name: str [9254,9257]
name: str [9101,9104]
===
match
---
atom_expr [4723,4740]
atom_expr [4723,4740]
===
match
---
simple_stmt [2890,3340]
simple_stmt [2890,3340]
===
match
---
atom_expr [2615,2625]
atom_expr [2615,2625]
===
match
---
trailer [3397,3500]
trailer [3397,3500]
===
match
---
name: local_full_path [8933,8948]
name: local_full_path [8780,8795]
===
match
---
name: self [6402,6406]
name: self [6402,6406]
===
match
---
string: "relabeling" [2050,2062]
string: "relabeling" [2050,2062]
===
match
---
suite [4895,4935]
suite [4895,4935]
===
match
---
simple_stmt [2265,2299]
simple_stmt [2265,2299]
===
match
---
simple_stmt [10725,11330]
simple_stmt [10572,11177]
===
match
---
name: extra_options [3554,3567]
name: extra_options [3554,3567]
===
match
---
operator: = [5257,5258]
operator: = [5257,5258]
===
match
---
simple_stmt [9953,10358]
simple_stmt [9800,10205]
===
match
---
expr_stmt [4430,4478]
expr_stmt [4430,4478]
===
match
---
name: st_mode [6708,6715]
name: st_mode [6708,6715]
===
match
---
name: kwargs [2221,2227]
name: kwargs [2221,2227]
===
match
---
name: extra_options [3445,3458]
name: extra_options [3445,3458]
===
match
---
name: get_conn [8905,8913]
name: get_conn [8752,8760]
===
match
---
name: conn_params [5327,5338]
name: conn_params [5327,5338]
===
match
---
trailer [11618,11627]
trailer [11465,11474]
===
match
---
comp_op [5997,6003]
comp_op [5997,6003]
===
match
---
trailer [6056,6061]
trailer [6056,6061]
===
match
---
name: ftp_conn_id [2152,2163]
name: ftp_conn_id [2152,2163]
===
match
---
operator: = [11651,11652]
operator: = [11498,11499]
===
match
---
simple_stmt [9267,9393]
simple_stmt [9114,9240]
===
match
---
parameters [7498,7515]
parameters [7498,7515]
===
match
---
simple_stmt [9163,9186]
simple_stmt [9010,9033]
===
match
---
atom_expr [6022,6039]
atom_expr [6022,6039]
===
match
---
funcdef [9217,9550]
funcdef [9064,9397]
===
match
---
suite [11495,11605]
suite [11342,11452]
===
match
---
operator: , [7465,7466]
operator: , [7465,7466]
===
match
---
name: self [8989,8993]
name: self [8836,8840]
===
match
---
atom_expr [2308,2317]
atom_expr [2308,2317]
===
match
---
string: 'file' [6722,6728]
string: 'file' [6722,6728]
===
match
---
trailer [4002,4048]
trailer [4002,4048]
===
match
---
operator: , [11399,11400]
operator: , [11246,11247]
===
match
---
parameters [9233,9250]
parameters [9080,9097]
===
match
---
name: path [9862,9866]
name: path [9709,9713]
===
match
---
suite [2638,4479]
suite [2638,4479]
===
match
---
suite [8507,8968]
suite [8354,8815]
===
match
---
name: Dict [6117,6121]
name: Dict [6117,6121]
===
match
---
trailer [11709,11716]
trailer [11556,11563]
===
match
---
suite [3568,4089]
suite [3568,4089]
===
match
---
trailer [6415,6417]
trailer [6415,6417]
===
match
---
return_stmt [7094,7106]
return_stmt [7094,7106]
===
match
---
simple_stmt [2333,2362]
simple_stmt [2333,2362]
===
match
---
argument [3892,3904]
argument [3892,3904]
===
match
---
operator: @ [1924,1925]
operator: @ [1924,1925]
===
match
---
parameters [9861,9935]
parameters [9708,9782]
===
match
---
name: st_mtime [9459,9467]
name: st_mtime [9306,9314]
===
match
---
name: retry [4615,4620]
name: retry [4615,4620]
===
match
---
name: password [5531,5539]
name: password [5531,5539]
===
match
---
operator: , [9901,9902]
operator: , [9748,9749]
===
match
---
atom_expr [7728,7744]
atom_expr [7728,7744]
===
match
---
operator: -> [7516,7518]
operator: -> [7516,7518]
===
match
---
name: retrieve_file [7754,7767]
name: retrieve_file [7754,7767]
===
match
---
name: self [7768,7772]
name: self [7768,7772]
===
match
---
suite [4952,5225]
suite [4952,5225]
===
match
---
name: self [4318,4322]
name: self [4318,4322]
===
match
---
trailer [6610,6619]
trailer [6610,6619]
===
match
---
name: delimiter [11584,11593]
name: delimiter [11431,11440]
===
match
---
operator: , [9575,9576]
operator: , [9422,9423]
===
match
---
operator: , [882,883]
operator: , [882,883]
===
match
---
name: tenacity [922,930]
name: tenacity [922,930]
===
match
---
operator: , [11380,11381]
operator: , [11227,11228]
===
match
---
name: fcallback [11670,11679]
name: fcallback [11517,11526]
===
match
---
atom_expr [5895,5904]
atom_expr [5895,5904]
===
match
---
name: key_file [4435,4443]
name: key_file [4435,4443]
===
match
---
trailer [7738,7744]
trailer [7738,7744]
===
match
---
name: st_mtime [6556,6564]
name: st_mtime [6556,6564]
===
match
---
simple_stmt [2221,2257]
simple_stmt [2221,2257]
===
match
---
name: remote_host [5372,5383]
name: remote_host [5372,5383]
===
match
---
decorated [1924,2128]
decorated [1924,2128]
===
match
---
name: local_full_path [8477,8492]
name: local_full_path [8324,8339]
===
match
---
trailer [5613,5622]
trailer [5613,5622]
===
match
---
simple_stmt [5948,5976]
simple_stmt [5948,5976]
===
match
---
import_from [931,964]
import_from [931,964]
===
match
---
param [5925,5929]
param [5925,5929]
===
match
---
comparison [5987,6008]
comparison [5987,6008]
===
match
---
name: path [10487,10491]
name: path [10334,10338]
===
match
---
test [6684,6728]
test [6684,6728]
===
match
---
operator: = [6062,6063]
operator: = [6062,6063]
===
match
---
name: compress [5264,5272]
name: compress [5264,5272]
===
match
---
return_stmt [10546,10557]
return_stmt [10393,10404]
===
match
---
atom_expr [4801,4810]
atom_expr [4801,4810]
===
match
---
string: 'password' [5595,5605]
string: 'password' [5595,5605]
===
match
---
funcdef [9843,10558]
funcdef [9690,10405]
===
match
---
trailer [6031,6037]
trailer [6031,6037]
===
match
---
name: rmdir [7733,7738]
name: rmdir [7733,7738]
===
match
---
name: Optional [10614,10622]
name: Optional [10461,10469]
===
match
---
trailer [10687,10692]
trailer [10534,10539]
===
match
---
atom_expr [10396,10419]
atom_expr [10243,10266]
===
match
---
operator: = [3378,3379]
operator: = [3378,3379]
===
match
---
import_name [901,914]
import_name [901,914]
===
match
---
name: self [2513,2517]
name: self [2513,2517]
===
match
---
atom_expr [5057,5081]
atom_expr [5057,5081]
===
match
---
atom_expr [5544,5565]
atom_expr [5544,5565]
===
match
---
operator: = [5607,5608]
operator: = [5607,5608]
===
match
---
operator: , [3234,3235]
operator: , [3234,3235]
===
match
---
atom_expr [9881,9894]
atom_expr [9728,9741]
===
match
---
simple_stmt [7836,8192]
simple_stmt [7836,8192]
===
match
---
name: self [6052,6056]
name: self [6052,6056]
===
match
---
lambdef [11515,11604]
lambdef [11362,11451]
===
match
---
atom_expr [11680,11716]
atom_expr [11527,11563]
===
match
---
name: prefix [10606,10612]
name: prefix [10453,10459]
===
match
---
operator: , [11903,11904]
operator: , [11750,11751]
===
match
---
operator: = [11391,11392]
operator: = [11238,11239]
===
match
---
atom_expr [4446,4478]
atom_expr [4446,4478]
===
match
---
simple_stmt [841,853]
simple_stmt [841,853]
===
match
---
name: path [7739,7743]
name: path [7739,7743]
===
match
---
trailer [9514,9524]
trailer [9361,9371]
===
match
---
testlist_star_expr [11393,11403]
testlist_star_expr [11240,11250]
===
match
---
expr_stmt [4832,4856]
expr_stmt [4832,4856]
===
match
---
string: '%Y%m%d%H%M%S' [6575,6589]
string: '%Y%m%d%H%M%S' [6575,6589]
===
match
---
and_test [5526,5565]
and_test [5526,5565]
===
match
---
tfpdef [9240,9249]
tfpdef [9087,9096]
===
match
---
trailer [6530,6539]
trailer [6530,6539]
===
match
---
name: str [7814,7817]
name: str [7814,7817]
===
match
---
name: ssh_conn_id [2518,2529]
name: ssh_conn_id [2518,2529]
===
match
---
trailer [2898,2903]
trailer [2898,2903]
===
match
---
operator: == [4057,4059]
operator: == [4057,4059]
===
match
---
trailer [2566,2581]
trailer [2566,2581]
===
match
---
simple_stmt [6513,6591]
simple_stmt [6513,6591]
===
match
---
name: str [9583,9586]
name: str [9430,9433]
===
match
---
name: self [2308,2312]
name: self [2308,2312]
===
match
---
name: get_conn [8212,8220]
name: get_conn [8212,8220]
===
match
---
trailer [2586,2598]
trailer [2586,2598]
===
match
---
param [7133,7138]
param [7133,7138]
===
match
---
name: conn [6027,6031]
name: conn [6027,6031]
===
match
---
simple_stmt [5285,5315]
simple_stmt [5285,5315]
===
match
---
trailer [5291,5299]
trailer [5291,5299]
===
match
---
name: private_key_pass [2338,2354]
name: private_key_pass [2338,2354]
===
match
---
comparison [2513,2541]
comparison [2513,2541]
===
match
---
operator: , [8993,8994]
operator: , [8840,8841]
===
match
---
name: self [5057,5061]
name: self [5057,5061]
===
match
---
param [7499,7504]
param [7499,7504]
===
match
---
simple_stmt [3589,3928]
simple_stmt [3589,3928]
===
match
---
string: 'ignore_hostkey_verification' [4017,4046]
string: 'ignore_hostkey_verification' [4017,4046]
===
match
---
name: conn [7728,7732]
name: conn [7728,7732]
===
match
---
trailer [8220,8222]
trailer [8220,8222]
===
match
---
argument [4598,4604]
argument [4598,4604]
===
match
---
arglist [8312,8345]
arglist [8240,8273]
===
match
---
name: str [9246,9249]
name: str [9093,9096]
===
match
---
decorated [4484,5905]
decorated [4484,5905]
===
match
---
if_stmt [10454,10538]
if_stmt [10301,10385]
===
match
---
trailer [9806,9813]
trailer [9653,9660]
===
match
---
suite [4819,5880]
suite [4819,5880]
===
match
---
atom_expr [4841,4856]
atom_expr [4841,4856]
===
match
---
operator: = [6472,6473]
operator: = [6472,6473]
===
match
---
string: 'SFTP' [1912,1918]
string: 'SFTP' [1912,1918]
===
match
---
operator: , [10692,10693]
operator: , [10539,10540]
===
match
---
trailer [11349,11358]
trailer [11196,11205]
===
match
---
parameters [6822,6839]
parameters [6822,6839]
===
match
---
atom_expr [2221,2242]
atom_expr [2221,2242]
===
match
---
operator: * [2282,2283]
operator: * [2282,2283]
===
match
---
name: path [7505,7509]
name: path [7505,7509]
===
match
---
name: makedirs [7452,7460]
name: makedirs [7452,7460]
===
match
---
trailer [6438,6451]
trailer [6438,6451]
===
match
---
name: extra [2620,2625]
name: extra [2620,2625]
===
match
---
operator: , [3443,3444]
operator: , [3443,3444]
===
match
---
name: no_host_key_check [2475,2492]
name: no_host_key_check [2475,2492]
===
match
---
operator: , [6658,6659]
operator: , [6658,6659]
===
match
---
operator: = [9895,9896]
operator: = [9742,9743]
===
match
---
simple_stmt [7184,7408]
simple_stmt [7184,7408]
===
match
---
if_stmt [4375,4479]
if_stmt [4375,4479]
===
match
---
expr_stmt [9163,9185]
expr_stmt [9010,9032]
===
match
---
name: conn_params [5583,5594]
name: conn_params [5583,5594]
===
match
---
param [10606,10635]
param [10453,10482]
===
match
---
atom_expr [11550,11594]
atom_expr [11397,11441]
===
match
---
operator: = [6400,6401]
operator: = [6400,6401]
===
match
---
simple_stmt [2655,2689]
simple_stmt [2655,2689]
===
match
---
dictorsetmaker [2082,2102]
dictorsetmaker [2082,2102]
===
match
---
expr_stmt [5285,5314]
expr_stmt [5285,5314]
===
match
---
name: private_key_pass [5805,5821]
name: private_key_pass [5805,5821]
===
match
---
if_stmt [3518,4089]
if_stmt [3518,4089]
===
match
---
simple_stmt [5583,5623]
simple_stmt [5583,5623]
===
match
---
name: item [11570,11574]
name: item [11417,11421]
===
match
---
trailer [4522,4539]
trailer [4522,4539]
===
match
---
operator: = [1856,1857]
operator: = [1856,1857]
===
match
---
name: self [9771,9775]
name: self [9618,9622]
===
match
---
name: stat [848,852]
name: stat [848,852]
===
match
---
comp_op [10467,10473]
comp_op [10314,10320]
===
match
---
trailer [5038,5097]
trailer [5038,5097]
===
match
---
name: extra_options [2655,2668]
name: extra_options [2655,2668]
===
match
---
name: extra_dejson [2676,2688]
name: extra_dejson [2676,2688]
===
match
---
comp_op [2530,2536]
comp_op [2530,2536]
===
match
---
arglist [11570,11593]
arglist [11417,11440]
===
match
---
atom_expr [5766,5797]
atom_expr [5766,5797]
===
match
---
operator: = [3314,3315]
operator: = [3314,3315]
===
match
---
decorated [9825,10558]
decorated [9672,10405]
===
match
---
trailer [5642,5651]
trailer [5642,5651]
===
match
---
name: f [6609,6610]
name: f [6609,6610]
===
match
---
name: self [8207,8211]
name: self [8207,8211]
===
match
---
trailer [6608,6620]
trailer [6608,6620]
===
match
---
atom [2064,2116]
atom [2064,2116]
===
match
---
name: mode [7467,7471]
name: mode [7467,7471]
===
match
---
trailer [9458,9467]
trailer [9305,9314]
===
match
---
name: max [4598,4601]
name: max [4598,4601]
===
match
---
operator: = [1910,1911]
operator: = [1910,1911]
===
match
---
trailer [5263,5272]
trailer [5263,5272]
===
match
---
for_stmt [6485,6778]
for_stmt [6485,6778]
===
match
---
name: self [9571,9575]
name: self [9418,9422]
===
match
---
operator: , [11716,11717]
operator: , [11563,11564]
===
match
---
name: conn [8924,8928]
name: conn [8771,8775]
===
match
---
trailer [2270,2272]
trailer [2270,2272]
===
match
---
name: unknowns [11829,11837]
name: unknowns [11676,11684]
===
match
---
string: 'The old option `private_key_pass` will be removed in Airflow 2.1' [3168,3234]
string: 'The old option `private_key_pass` will be removed in Airflow 2.1' [3168,3234]
===
match
---
name: files [11710,11715]
name: files [11557,11562]
===
match
---
atom_expr [4912,4927]
atom_expr [4912,4927]
===
match
---
name: self [5987,5991]
name: self [5987,5991]
===
match
---
trailer [4231,4237]
trailer [4231,4237]
===
match
---
trailer [10491,10500]
trailer [10338,10347]
===
match
---
trailer [7460,7472]
trailer [7460,7472]
===
match
---
operator: , [10604,10605]
operator: , [10451,10452]
===
match
---
argument [4615,4667]
argument [4615,4667]
===
match
---
funcdef [6074,6799]
funcdef [6074,6799]
===
match
---
trailer [8311,8346]
trailer [8239,8274]
===
match
---
trailer [5530,5539]
trailer [5530,5539]
===
match
---
name: stop_after_delay [4523,4539]
name: stop_after_delay [4523,4539]
===
match
---
trailer [7717,7719]
trailer [7717,7719]
===
match
---
trailer [2581,2599]
trailer [2581,2599]
===
match
---
comparison [10369,10387]
comparison [10216,10234]
===
match
---
trailer [6026,6031]
trailer [6026,6031]
===
match
---
simple_stmt [6603,6778]
simple_stmt [6603,6778]
===
match
---
trailer [2474,2492]
trailer [2474,2492]
===
match
---
trailer [11358,11360]
trailer [11205,11207]
===
match
---
name: ciphers [2375,2382]
name: ciphers [2375,2382]
===
match
---
return_stmt [5888,5904]
return_stmt [5888,5904]
===
match
---
arglist [5039,5096]
arglist [5039,5096]
===
match
---
string: """         Removes a file on the FTP Server          :param path: full path to the remote file         :type path: str         """ [9023,9154]
string: """         Removes a file on the FTP Server          :param path: full path to the remote file         :type path: str         """ [8870,9001]
===
match
---
atom_expr [2265,2298]
atom_expr [2265,2298]
===
match
---
classdef [1020,11914]
classdef [1020,11761]
===
match
---
atom_expr [11345,11360]
atom_expr [11192,11207]
===
match
---
atom [6474,6476]
atom [6474,6476]
===
match
---
name: self [5367,5371]
name: self [5367,5371]
===
match
---
operator: = [2318,2319]
operator: = [2318,2319]
===
match
---
name: str [4192,4195]
name: str [4192,4195]
===
match
---
trailer [4459,4463]
trailer [4459,4463]
===
match
---
trailer [10500,10511]
trailer [10347,10358]
===
match
---
suite [6500,6778]
suite [6500,6778]
===
match
---
atom_expr [6522,6590]
atom_expr [6522,6590]
===
match
---
name: get_conn [4705,4713]
name: get_conn [4705,4713]
===
match
---
name: Connection [4730,4740]
name: Connection [4730,4740]
===
match
---
param [6103,6112]
param [6103,6112]
===
match
---
name: self [3356,3360]
name: self [3356,3360]
===
match
---
not_test [10483,10511]
not_test [10330,10358]
===
match
---
atom_expr [5039,5055]
atom_expr [5039,5055]
===
match
---
operator: , [8452,8453]
operator: , [8299,8300]
===
match
---
trailer [9533,9549]
trailer [9380,9396]
===
match
---
string: """Returns an SFTP connection object""" [4750,4789]
string: """Returns an SFTP connection object""" [4750,4789]
===
match
---
trailer [11769,11775]
trailer [11616,11622]
===
match
---
simple_stmt [8893,8916]
simple_stmt [8740,8763]
===
match
---
comp_op [2626,2632]
comp_op [2626,2632]
===
match
---
name: self [4972,4976]
name: self [4972,4976]
===
match
---
simple_stmt [7533,7689]
simple_stmt [7533,7689]
===
match
---
trailer [11828,11838]
trailer [11675,11685]
===
match
---
comparison [3999,4066]
comparison [3999,4066]
===
match
---
expr_stmt [7059,7085]
expr_stmt [7059,7085]
===
match
---
name: retry [4494,4499]
name: retry [4494,4499]
===
match
---
comparison [4192,4249]
comparison [4192,4249]
===
match
---
operator: , [8328,8329]
operator: , [8256,8257]
===
match
---
trailer [2619,2625]
trailer [2619,2625]
===
match
---
name: delete_file [8977,8988]
name: delete_file [8824,8835]
===
match
---
operator: = [4839,4840]
operator: = [4839,4840]
===
match
---
suite [7524,7745]
suite [7524,7745]
===
match
---
name: self [5835,5839]
name: self [5835,5839]
===
match
---
name: append_matching_path_callback [11799,11828]
name: append_matching_path_callback [11646,11675]
===
match
---
expr_stmt [7697,7719]
expr_stmt [7697,7719]
===
match
---
name: str [6132,6135]
name: str [6132,6135]
===
match
---
trailer [6037,6039]
trailer [6037,6039]
===
match
---
funcdef [7750,8428]
funcdef [7750,8275]
===
match
---
string: """         Returns modification time.          :param path: full path to the remote file         :type path: str         """ [9267,9392]
string: """         Returns modification time.          :param path: full path to the remote file         :type path: str         """ [9114,9239]
===
match
---
argument [4553,4605]
argument [4553,4605]
===
match
---
atom_expr [2370,2382]
atom_expr [2370,2382]
===
match
---
name: ftp_mdtm [9432,9440]
name: ftp_mdtm [9279,9287]
===
match
---
atom_expr [4972,4985]
atom_expr [4972,4985]
===
match
---
trailer [5413,5418]
trailer [5413,5418]
===
match
---
string: "hidden_fields" [2009,2024]
string: "hidden_fields" [2009,2024]
===
match
---
name: datetime [9492,9500]
name: datetime [9339,9347]
===
match
---
name: str [10710,10713]
name: str [10557,10560]
===
match
---
trailer [7039,7048]
trailer [7039,7048]
===
match
---
expr_stmt [5766,5821]
expr_stmt [5766,5821]
===
match
---
name: tenacity [4621,4629]
name: tenacity [4621,4629]
===
match
---
trailer [5087,5096]
trailer [5087,5096]
===
match
---
atom [1995,2127]
atom [1995,2127]
===
match
---
if_stmt [5984,6069]
if_stmt [5984,6069]
===
match
---
simple_stmt [6395,6418]
simple_stmt [6395,6418]
===
match
---
trailer [5991,5996]
trailer [5991,5996]
===
match
---
trailer [4322,4330]
trailer [4322,4330]
===
match
---
name: airflow [971,978]
name: airflow [971,978]
===
match
---
name: self [4872,4876]
name: self [4872,4876]
===
match
---
trailer [5680,5695]
trailer [5680,5695]
===
match
---
name: f [6554,6555]
name: f [6554,6555]
===
match
---
expr_stmt [6603,6777]
expr_stmt [6603,6777]
===
match
---
param [2194,2202]
param [2194,2202]
===
match
---
expr_stmt [2470,2500]
expr_stmt [2470,2500]
===
match
---
operator: { [2064,2065]
operator: { [2064,2065]
===
match
---
name: datetime [832,840]
name: datetime [832,840]
===
match
---
name: flist [6426,6431]
name: flist [6426,6431]
===
match
---
param [11488,11493]
param [11335,11340]
===
match
---
param [8477,8497]
param [8324,8344]
===
match
---
simple_stmt [6426,6458]
simple_stmt [6426,6458]
===
match
---
name: str [7145,7148]
name: str [7145,7148]
===
match
---
trailer [4054,4056]
trailer [4054,4056]
===
match
---
trailer [6705,6716]
trailer [6705,6716]
===
match
---
trailer [3462,3482]
trailer [3462,3482]
===
match
---
trailer [6553,6565]
trailer [6553,6565]
===
match
---
atom_expr [4318,4330]
atom_expr [4318,4330]
===
match
---
subscriptlist [6122,6141]
subscriptlist [6122,6141]
===
match
---
operator: = [11343,11344]
operator: = [11190,11191]
===
match
---
arglist [11641,11865]
arglist [11488,11712]
===
match
---
and_test [10457,10511]
and_test [10304,10358]
===
match
---
atom_expr [3356,3377]
atom_expr [3356,3377]
===
match
---
name: str [9923,9926]
name: str [9770,9773]
===
match
---
name: remote_host [5044,5055]
name: remote_host [5044,5055]
===
match
---
name: self [7704,7708]
name: self [7704,7708]
===
match
---
atom_expr [10694,10703]
atom_expr [10541,10550]
===
match
---
trailer [6707,6715]
trailer [6707,6715]
===
match
---
operator: , [2185,2186]
operator: , [2185,2186]
===
match
---
if_stmt [4267,4358]
if_stmt [4267,4358]
===
match
---
param [7797,7817]
param [7797,7817]
===
match
---
operator: ** [5865,5867]
operator: ** [5865,5867]
===
match
---
number: 777 [7162,7165]
number: 777 [7162,7165]
===
match
---
suite [1044,11914]
suite [1044,11761]
===
match
---
suite [9596,9820]
suite [9443,9667]
===
match
---
trailer [6131,6141]
trailer [6131,6141]
===
match
---
trailer [9491,9500]
trailer [9338,9347]
===
match
---
operator: { [1995,1996]
operator: { [1995,1996]
===
match
---
name: conn [2671,2675]
name: conn [2671,2675]
===
match
---
trailer [4539,4543]
trailer [4539,4543]
===
match
---
operator: = [4601,4602]
operator: = [4601,4602]
===
match
---
operator: ** [2289,2291]
operator: ** [2289,2291]
===
match
---
name: put [8929,8932]
name: put [8776,8779]
===
match
---
name: path [10595,10599]
name: path [10442,10446]
===
match
---
operator: = [4190,4191]
operator: = [4190,4191]
===
match
---
name: paramiko [936,944]
name: paramiko [936,944]
===
match
---
operator: , [2116,2117]
operator: , [2116,2117]
===
match
---
name: self [7499,7503]
name: self [7499,7503]
===
match
---
string: 'true' [4060,4066]
string: 'true' [4060,4066]
===
match
---
atom_expr [5638,5651]
atom_expr [5638,5651]
===
match
---
expr_stmt [6426,6457]
expr_stmt [6426,6457]
===
match
---
if_stmt [2612,4479]
if_stmt [2612,4479]
===
match
---
name: self [9234,9238]
name: self [9081,9085]
===
match
---
trailer [10655,10660]
trailer [10502,10507]
===
match
---
name: Optional [10647,10655]
name: Optional [10494,10502]
===
match
---
comparison [4972,4997]
comparison [4972,4997]
===
match
---
name: pysftp [4841,4847]
name: pysftp [4841,4847]
===
match
---
operator: , [2287,2288]
operator: , [2287,2288]
===
match
---
operator: { [6474,6475]
operator: { [6474,6475]
===
match
---
atom_expr [11799,11838]
atom_expr [11646,11685]
===
match
---
name: password [5549,5557]
name: password [5549,5557]
===
match
---
atom_expr [3999,4056]
atom_expr [3999,4056]
===
match
---
name: flist [6494,6499]
name: flist [6494,6499]
===
match
---
name: args [2188,2192]
name: args [2188,2192]
===
match
---
atom_expr [9443,9467]
atom_expr [9290,9314]
===
match
---
if_stmt [4106,4250]
if_stmt [4106,4250]
===
match
---
name: conn [11614,11618]
name: conn [11461,11465]
===
match
---
operator: , [3904,3905]
operator: , [3904,3905]
===
match
---
name: dcallback [11730,11739]
name: dcallback [11577,11586]
===
match
---
trailer [8904,8913]
trailer [8751,8760]
===
match
---
name: stacklevel [3304,3314]
name: stacklevel [3304,3314]
===
match
---
name: self [2470,2474]
name: self [2470,2474]
===
match
---
name: strip [5558,5563]
name: strip [5558,5563]
===
match
---
name: str [9890,9893]
name: str [9737,9740]
===
match
---
argument [4584,4596]
argument [4584,4596]
===
match
---
string: 'no_host_key_check' [4109,4128]
string: 'no_host_key_check' [4109,4128]
===
match
---
return_stmt [6786,6798]
return_stmt [6786,6798]
===
match
---
operator: = [7702,7703]
operator: = [7702,7703]
===
match
---
name: conn [9802,9806]
name: conn [9649,9653]
===
match
---
trailer [6121,6142]
trailer [6121,6142]
===
match
---
string: 'Extra option `ignore_hostkey_verification` is deprecated.' [3628,3687]
string: 'Extra option `ignore_hostkey_verification` is deprecated.' [3628,3687]
===
match
---
name: path [7461,7465]
name: path [7461,7465]
===
match
---
simple_stmt [9194,9212]
simple_stmt [9041,9059]
===
match
---
atom_expr [6649,6658]
atom_expr [6649,6658]
===
match
---
name: int [7156,7159]
name: int [7156,7159]
===
match
---
import_as_names [872,899]
import_as_names [872,899]
===
match
---
trailer [8307,8311]
trailer [8235,8239]
===
match
---
simple_stmt [4318,4358]
simple_stmt [4318,4358]
===
match
---
param [8448,8453]
param [8295,8300]
===
match
---
name: hooks [993,998]
name: hooks [993,998]
===
match
---
name: stat [9448,9452]
name: stat [9295,9299]
===
match
---
operator: = [4331,4332]
operator: = [4331,4332]
===
match
---
number: 10 [4540,4542]
number: 10 [4540,4542]
===
match
---
name: str [10699,10702]
name: str [10546,10549]
===
match
---
atom_expr [6693,6716]
atom_expr [6693,6716]
===
match
---
string: 'sftp_default' [2171,2185]
string: 'sftp_default' [2171,2185]
===
match
---
name: listdir [7072,7079]
name: listdir [7072,7079]
===
match
---
name: Dict [6127,6131]
name: Dict [6127,6131]
===
match
---
trailer [9174,9183]
trailer [9021,9030]
===
match
---
trailer [4918,4927]
trailer [4918,4927]
===
match
---
atom_expr [2333,2354]
atom_expr [2333,2354]
===
match
---
operator: = [7065,7066]
operator: = [7065,7066]
===
match
---
decorator [9825,9839]
decorator [9672,9686]
===
match
---
atom_expr [9483,9549]
atom_expr [9330,9396]
===
match
---
name: f [6706,6707]
name: f [6706,6707]
===
match
---
trailer [7071,7079]
trailer [7071,7079]
===
match
---
tfpdef [10636,10660]
tfpdef [10483,10507]
===
match
---
name: dirs [11770,11774]
name: dirs [11617,11621]
===
match
---
funcdef [5910,6069]
funcdef [5910,6069]
===
match
---
name: extra_options [3380,3393]
name: extra_options [3380,3393]
===
match
---
atom_expr [5083,5096]
atom_expr [5083,5096]
===
match
---
name: path [7139,7143]
name: path [7139,7143]
===
match
---
name: kwargs [2196,2202]
name: kwargs [2196,2202]
===
match
---
name: extra_options [4132,4145]
name: extra_options [4132,4145]
===
match
---
expr_stmt [4167,4249]
expr_stmt [4167,4249]
===
match
---
operator: , [10634,10635]
operator: , [10481,10482]
===
match
---
trailer [8932,8967]
trailer [8779,8814]
===
match
---
trailer [6565,6574]
trailer [6565,6574]
===
match
---
name: warnings [2890,2898]
name: warnings [2890,2898]
===
match
---
number: 2 [3315,3316]
number: 2 [3315,3316]
===
match
---
trailer [9421,9423]
trailer [9268,9270]
===
match
---
comp_op [4986,4992]
comp_op [4986,4992]
===
match
---
operator: , [5081,5082]
operator: , [5081,5082]
===
match
---
simple_stmt [5140,5225]
simple_stmt [5140,5225]
===
match
---
param [7150,7165]
param [7150,7165]
===
match
---
name: self [5302,5306]
name: self [5302,5306]
===
match
---
name: conn [9194,9198]
name: conn [9041,9045]
===
match
---
trailer [2675,2688]
trailer [2675,2688]
===
match
---
name: SSHException [4654,4666]
name: SSHException [4654,4666]
===
match
---
name: self [5609,5613]
name: self [5609,5613]
===
match
---
name: append_matching_path_callback [11740,11769]
name: append_matching_path_callback [11587,11616]
===
match
---
operator: , [11395,11396]
operator: , [11242,11243]
===
match
---
atom_expr [10677,10715]
atom_expr [10524,10562]
===
match
---
atom_expr [6843,6852]
atom_expr [6843,6852]
===
match
---
comparison [2833,2868]
comparison [2833,2868]
===
match
---
operator: = [10661,10662]
operator: = [10508,10509]
===
match
---
argument [11641,11656]
argument [11488,11503]
===
match
---
param [6097,6102]
param [6097,6102]
===
match
---
string: 'host' [5359,5365]
string: 'host' [5359,5365]
===
match
---
comparison [4378,4408]
comparison [4378,4408]
===
match
---
name: strftime [9525,9533]
name: strftime [9372,9380]
===
match
---
name: cnopts [5489,5495]
name: cnopts [5489,5495]
===
match
---
param [11522,11526]
param [11369,11373]
===
match
---
string: 'ssh_conn_id' [2228,2241]
string: 'ssh_conn_id' [2228,2241]
===
match
---
name: lower [4232,4237]
name: lower [4232,4237]
===
match
---
simple_stmt [11885,11914]
simple_stmt [11732,11761]
===
match
---
atom_expr [5698,5711]
atom_expr [5698,5711]
===
match
---
name: list_directory [6808,6822]
name: list_directory [6808,6822]
===
match
---
tfpdef [7150,7159]
tfpdef [7150,7159]
===
match
---
name: delete_directory [7482,7498]
name: delete_directory [7482,7498]
===
match
---
name: List [878,882]
name: List [878,882]
===
match
---
name: __init__ [2137,2145]
name: __init__ [2137,2145]
===
match
---
trailer [3602,3927]
trailer [3602,3927]
===
match
---
trailer [6555,6564]
trailer [6555,6564]
===
match
---
name: no_host_key_check [4172,4189]
name: no_host_key_check [4172,4189]
===
match
---
name: conn_params [5669,5680]
name: conn_params [5669,5680]
===
match
---
trailer [5777,5797]
trailer [5777,5797]
===
match
---
name: path [9814,9818]
name: path [9661,9665]
===
match
---
name: self [6823,6827]
name: self [6823,6827]
===
match
---
operator: @ [4484,4485]
operator: @ [4484,4485]
===
match
---
string: """         Creates a directory on the remote system.          :param path: full path to the remote directory to create         :type path: str         :param mode: int representation of octal mode for directory         """ [7184,7407]
string: """         Creates a directory on the remote system.          :param path: full path to the remote directory to create         :type path: str         :param mode: int representation of octal mode for directory         """ [7184,7407]
===
match
---
simple_stmt [8516,8885]
simple_stmt [8363,8732]
===
match
---
trailer [5070,5079]
trailer [5070,5079]
===
match
---
trailer [7436,7438]
trailer [7436,7438]
===
match
---
operator: = [4620,4621]
operator: = [4620,4621]
===
match
---
trailer [8913,8915]
trailer [8760,8762]
===
match
---
name: S_ISDIR [6698,6705]
name: S_ISDIR [6698,6705]
===
match
---
tfpdef [6103,6112]
tfpdef [6103,6112]
===
match
---
name: extra_options [4446,4459]
name: extra_options [4446,4459]
===
match
---
name: path_exists [9559,9570]
name: path_exists [9406,9417]
===
match
---
name: datetime [9483,9491]
name: datetime [9330,9338]
===
match
---
string: 'private_key' [4464,4477]
string: 'private_key' [4464,4477]
===
match
---
param [7139,7149]
param [7139,7149]
===
match
---
name: remove [9199,9205]
name: remove [9046,9052]
===
match
---
name: pysftp [4723,4729]
name: pysftp [4723,4729]
===
match
---
expr_stmt [4318,4357]
expr_stmt [4318,4357]
===
match
---
name: get_conn [9413,9421]
name: get_conn [9260,9268]
===
match
---
name: unknowns [11905,11913]
name: unknowns [11752,11760]
===
match
---
trailer [11627,11875]
trailer [11474,11722]
===
match
---
simple_stmt [2797,2813]
simple_stmt [2797,2813]
===
match
---
name: strftime [6566,6574]
name: strftime [6566,6574]
===
match
---
name: hook_name [1900,1909]
name: hook_name [1900,1909]
===
match
---
name: path [6103,6107]
name: path [6103,6107]
===
match
---
trailer [8928,8932]
trailer [8775,8779]
===
match
---
trailer [4976,4985]
trailer [4976,4985]
===
match
---
funcdef [2133,4479]
funcdef [2133,4479]
===
match
---
string: 'Please use `no_host_key_check` instead.' [3712,3753]
string: 'Please use `no_host_key_check` instead.' [3712,3753]
===
match
---
name: get_connection [2567,2581]
name: get_connection [2567,2581]
===
match
---
tfpdef [9873,9894]
tfpdef [9720,9741]
===
match
---
name: prefix [9873,9879]
name: prefix [9720,9726]
===
match
---
operator: -> [7819,7821]
operator: -> [7819,7821]
===
match
---
operator: , [8948,8949]
operator: , [8795,8796]
===
match
---
trailer [3952,3970]
trailer [3952,3970]
===
match
---
name: conn [4806,4810]
name: conn [4806,4810]
===
match
---
operator: , [2036,2037]
operator: , [2036,2037]
===
match
---
trailer [9500,9514]
trailer [9347,9361]
===
match
---
name: remote_full_path [7774,7790]
name: remote_full_path [7774,7790]
===
match
---
atom_expr [6402,6417]
atom_expr [6402,6417]
===
match
---
name: self [6097,6101]
name: self [6097,6101]
===
match
---
name: f [6489,6490]
name: f [6489,6490]
===
match
---
trailer [5452,5461]
trailer [5452,5461]
===
match
---
atom_expr [10487,10511]
atom_expr [10334,10358]
===
match
---
string: 'ignore_hostkey_verification' [3521,3550]
string: 'ignore_hostkey_verification' [3521,3550]
===
match
---
operator: @ [9825,9826]
operator: @ [9672,9673]
===
match
---
tfpdef [8454,8475]
tfpdef [8301,8322]
===
match
---
name: startswith [10401,10411]
name: startswith [10248,10258]
===
match
---
name: dirs [11899,11903]
name: dirs [11746,11750]
===
match
---
param [9571,9576]
param [9418,9423]
===
match
---
param [4714,4718]
param [4714,4718]
===
match
---
expr_stmt [2221,2256]
expr_stmt [2221,2256]
===
match
---
name: str [9868,9871]
name: str [9715,9718]
===
match
---
operator: , [6762,6763]
operator: , [6762,6763]
===
match
---
simple_stmt [915,931]
simple_stmt [915,931]
===
match
---
funcdef [8433,8968]
funcdef [8280,8815]
===
match
---
trailer [3360,3377]
trailer [3360,3377]
===
match
---
atom_expr [5448,5461]
atom_expr [5448,5461]
===
match
---
operator: } [5509,5510]
operator: } [5509,5510]
===
match
---
operator: , [3866,3867]
operator: , [3866,3867]
===
match
---
argument [4509,4543]
argument [4509,4543]
===
match
---
if_stmt [4869,5225]
if_stmt [4869,5225]
===
match
---
simple_stmt [4750,4790]
simple_stmt [4750,4790]
===
match
---
name: datetime [6531,6539]
name: datetime [6531,6539]
===
match
---
string: 'private_key' [5681,5694]
string: 'private_key' [5681,5694]
===
match
---
name: default_conn_name [1838,1855]
name: default_conn_name [1838,1855]
===
match
---
return_stmt [9476,9549]
return_stmt [9323,9396]
===
match
---
name: str [10656,10659]
name: str [10503,10506]
===
match
---
name: path [8995,8999]
name: path [8842,8846]
===
match
---
atom_expr [10614,10627]
atom_expr [10461,10474]
===
match
---
name: get_conn [7040,7048]
name: get_conn [7040,7048]
===
match
---
trailer [5594,5606]
trailer [5594,5606]
===
match
---
name: self [6022,6026]
name: self [6022,6026]
===
match
---
name: conn [2555,2559]
name: conn [2555,2559]
===
match
---
atom_expr [9408,9423]
atom_expr [9255,9270]
===
match
---
suite [5939,6069]
suite [5939,6069]
===
match
---
trailer [9922,9927]
trailer [9769,9774]
===
match
---
string: """         Returns True if a remote entity exists          :param path: full path to the remote file or directory         :type path: str         """ [9605,9755]
string: """         Returns True if a remote entity exists          :param path: full path to the remote file or directory         :type path: str         """ [9452,9602]
===
match
---
argument [3304,3316]
argument [3304,3316]
===
match
---
name: ssh_conn_id [2587,2598]
name: ssh_conn_id [2587,2598]
===
match
---
test [11528,11604]
test [11375,11451]
===
match
---
name: remote_full_path [8312,8328]
name: remote_full_path [8240,8256]
===
match
---
expr_stmt [9764,9786]
expr_stmt [9611,9633]
===
match
---
expr_stmt [8893,8915]
expr_stmt [8740,8762]
===
match
---
subscriptlist [6132,6140]
subscriptlist [6132,6140]
===
match
---
atom_expr [6603,6620]
atom_expr [6603,6620]
===
match
---
name: super [2265,2270]
name: super [2265,2270]
===
match
---
operator: { [5341,5342]
operator: { [5341,5342]
===
match
---
operator: , [10593,10594]
operator: , [10440,10441]
===
match
---
funcdef [1942,2128]
funcdef [1942,2128]
===
match
---
expr_stmt [8200,8222]
expr_stmt [8200,8222]
===
match
---
name: path [9206,9210]
name: path [9053,9057]
===
match
---
simple_stmt [7059,7086]
simple_stmt [7059,7086]
===
match
---
name: self [5083,5087]
name: self [5083,5087]
===
match
---
decorator [1924,1938]
decorator [1924,1938]
===
match
---
name: get_mod_time [9221,9233]
name: get_mod_time [9068,9080]
===
match
---
operator: -> [9006,9008]
operator: -> [8853,8855]
===
match
---
name: username [5453,5461]
name: username [5453,5461]
===
match
---
trailer [5557,5563]
trailer [5557,5563]
===
match
---
name: self [5448,5452]
name: self [5448,5452]
===
match
---
operator: , [6125,6126]
operator: , [6125,6126]
===
match
---
operator: = [8205,8206]
operator: = [8205,8206]
===
match
---
param [8454,8476]
param [8301,8323]
===
match
---
trailer [11540,11546]
trailer [11387,11393]
===
match
---
arglist [3419,3482]
arglist [3419,3482]
===
match
---
name: files [11892,11897]
name: files [11739,11744]
===
match
---
trailer [2281,2298]
trailer [2281,2298]
===
match
---
atom_expr [9802,9819]
atom_expr [9649,9666]
===
match
---
name: files [7059,7064]
name: files [7059,7064]
===
match
---
name: path [10396,10400]
name: path [10243,10247]
===
match
---
operator: , [6135,6136]
operator: , [6135,6136]
===
match
---
name: str [6122,6125]
name: str [6122,6125]
===
match
---
name: store_file [8437,8447]
name: store_file [8284,8294]
===
match
---
operator: , [10703,10704]
operator: , [10550,10551]
===
match
---
operator: , [11838,11839]
operator: , [11685,11686]
===
match
---
if_stmt [5724,5822]
if_stmt [5724,5822]
===
match
---
dotted_name [971,1002]
dotted_name [971,1002]
===
match
---
operator: , [11574,11575]
operator: , [11421,11422]
===
match
---
name: key_file [5643,5651]
name: key_file [5643,5651]
===
match
---
atom_expr [10705,10714]
atom_expr [10552,10561]
===
match
---
simple_stmt [4430,4479]
simple_stmt [4430,4479]
===
match
---
name: List [6843,6847]
name: List [6843,6847]
===
match
---
atom_expr [4003,4047]
atom_expr [4003,4047]
===
match
---
parameters [11487,11494]
parameters [11334,11341]
===
match
---
operator: = [7160,7161]
operator: = [7160,7161]
===
match
---
operator: , [3316,3317]
operator: , [3316,3317]
===
match
---
tfpdef [6829,6838]
tfpdef [6829,6838]
===
match
---
atom_expr [5367,5383]
atom_expr [5367,5383]
===
match
---
operator: = [3971,3972]
operator: = [3971,3972]
===
match
---
atom_expr [11740,11775]
atom_expr [11587,11622]
===
match
---
name: delimiter [9903,9912]
name: delimiter [9750,9759]
===
match
---
name: SSHHook [1010,1017]
name: SSHHook [1010,1017]
===
match
---
trailer [7451,7460]
trailer [7451,7460]
===
match
---
name: self [2333,2337]
name: self [2333,2337]
===
match
---
atom_expr [5609,5622]
atom_expr [5609,5622]
===
match
---
string: 'size' [6641,6647]
string: 'size' [6641,6647]
===
match
---
param [9862,9872]
param [9709,9719]
===
match
---
simple_stmt [9605,9756]
simple_stmt [9452,9603]
===
match
---
name: endswith [10492,10500]
name: endswith [10339,10347]
===
match
---
name: conn [9764,9768]
name: conn [9611,9615]
===
match
---
simple_stmt [901,915]
simple_stmt [901,915]
===
match
---
string: 'Username' [2091,2101]
string: 'Username' [2091,2101]
===
match
---
name: conn_type [1877,1886]
name: conn_type [1877,1886]
===
match
---
name: hostkeys [4919,4927]
name: hostkeys [4919,4927]
===
match
---
funcdef [7112,7473]
funcdef [7112,7473]
===
match
---
tfpdef [9903,9927]
tfpdef [9750,9774]
===
match
---
name: reraise [4677,4684]
name: reraise [4677,4684]
===
match
---
expr_stmt [3356,3500]
expr_stmt [3356,3500]
===
match
---
name: get [3394,3397]
name: get [3394,3397]
===
match
---
subscriptlist [10683,10714]
subscriptlist [10530,10561]
===
match
---
string: '%Y%m%d%H%M%S' [9534,9548]
string: '%Y%m%d%H%M%S' [9381,9395]
===
match
---
simple_stmt [9432,9468]
simple_stmt [9279,9315]
===
match
---
atom_expr [9914,9927]
atom_expr [9761,9774]
===
match
---
name: modify [6756,6762]
name: modify [6756,6762]
===
match
---
suite [5652,5712]
suite [5652,5712]
===
match
---
name: self [3948,3952]
name: self [3948,3952]
===
match
---
simple_stmt [8200,8223]
simple_stmt [8200,8223]
===
match
---
strings [2929,3234]
strings [2929,3234]
===
match
---
simple_stmt [5019,5098]
simple_stmt [5019,5098]
===
match
---
name: ssh [999,1002]
name: ssh [999,1002]
===
match
---
atom_expr [5019,5097]
atom_expr [5019,5097]
===
match
---
name: stacklevel [3892,3902]
name: stacklevel [3892,3902]
===
match
---
name: Optional [9914,9922]
name: Optional [9761,9769]
===
match
---
param [10589,10594]
param [10436,10441]
===
match
---
name: path [9453,9457]
name: path [9300,9304]
===
match
---
operator: , [4543,4544]
operator: , [4543,4544]
===
match
---
trailer [5079,5081]
trailer [5079,5081]
===
match
---
name: Dict [872,876]
name: Dict [872,876]
===
match
---
simple_stmt [2308,2325]
simple_stmt [2308,2325]
===
match
---
simple_stmt [3948,4089]
simple_stmt [3948,4089]
===
match
---
name: str [3999,4002]
name: str [3999,4002]
===
match
---
atom [3973,4088]
atom [3973,4088]
===
match
---
return_stmt [10433,10445]
return_stmt [10280,10292]
===
match
---
operator: == [4240,4242]
operator: == [4240,4242]
===
match
---
name: recurse [11852,11859]
name: recurse [11699,11706]
===
match
---
simple_stmt [2555,2600]
simple_stmt [2555,2600]
===
match
---
atom_expr [2470,2492]
atom_expr [2470,2492]
===
match
---
expr_stmt [2333,2361]
expr_stmt [2333,2361]
===
match
---
trailer [10709,10714]
trailer [10556,10561]
===
match
---
funcdef [11454,11605]
funcdef [11301,11452]
===
match
---
trailer [11533,11540]
trailer [11380,11387]
===
match
---
suite [4998,5098]
suite [4998,5098]
===
match
---
simple_stmt [5835,5880]
simple_stmt [5835,5880]
===
match
---
parameters [7767,7818]
parameters [7767,7818]
===
match
---
string: """         Deletes a directory on the remote system.          :param path: full path to the remote directory to delete         :type path: str         """ [7533,7688]
string: """         Deletes a directory on the remote system.          :param path: full path to the remote directory to delete         :type path: str         """ [7533,7688]
===
match
---
dictorsetmaker [6641,6763]
dictorsetmaker [6641,6763]
===
match
---
number: 1 [4595,4596]
number: 1 [4595,4596]
===
match
---
expr_stmt [2308,2324]
expr_stmt [2308,2324]
===
match
---
name: close_conn [5914,5924]
name: close_conn [5914,5924]
===
match
---
name: prefix [11576,11582]
name: prefix [11423,11429]
===
match
---
trailer [6847,6852]
trailer [6847,6852]
===
match
---
testlist [11892,11913]
testlist [11739,11760]
===
match
---
name: extra_options [4196,4209]
name: extra_options [4196,4209]
===
match
---
atom_expr [4514,4543]
atom_expr [4514,4543]
===
match
---
import_name [825,840]
import_name [825,840]
===
match
---
string: 'port' [5401,5407]
string: 'port' [5401,5407]
===
match
---
operator: ** [2194,2196]
operator: ** [2194,2196]
===
match
---
simple_stmt [5669,5712]
simple_stmt [5669,5712]
===
match
---
trailer [9447,9452]
trailer [9294,9299]
===
match
---
simple_stmt [9795,9820]
simple_stmt [9642,9667]
===
match
---
comp_op [10376,10382]
comp_op [10223,10229]
===
match
---
trailer [4434,4443]
trailer [4434,4443]
===
match
---
atom_expr [5847,5879]
atom_expr [5847,5879]
===
match
---
trailer [7079,7085]
trailer [7079,7085]
===
match
---
argument [4677,4689]
argument [4677,4689]
===
match
---
if_stmt [4969,5225]
if_stmt [4969,5225]
===
match
---
operator: -> [8499,8501]
operator: -> [8346,8348]
===
match
---
name: filename [6611,6619]
name: filename [6611,6619]
===
match
---
atom_expr [6434,6457]
atom_expr [6434,6457]
===
match
---
operator: = [2560,2561]
operator: = [2560,2561]
===
match
---
name: conn [11338,11342]
name: conn [11185,11189]
===
match
---
name: compression [5245,5256]
name: compression [5245,5256]
===
match
---
simple_stmt [7728,7745]
simple_stmt [7728,7745]
===
match
---
trailer [5563,5565]
trailer [5563,5565]
===
match
---
comparison [4109,4145]
comparison [4109,4145]
===
match
---
import_name [841,852]
import_name [841,852]
===
match
---
parameters [4713,4719]
parameters [4713,4719]
===
match
---
parameters [1968,1970]
parameters [1968,1970]
===
match
---
name: delimiter [10636,10645]
name: delimiter [10483,10492]
===
match
---
simple_stmt [5327,5511]
simple_stmt [5327,5511]
===
match
---
expr_stmt [6513,6590]
expr_stmt [6513,6590]
===
match
---
name: ciphers [5292,5299]
name: ciphers [5292,5299]
===
match
---
atom_expr [3380,3500]
atom_expr [3380,3500]
===
match
---
string: 'private_key_passphrase' [3419,3443]
string: 'private_key_passphrase' [3419,3443]
===
match
---
operator: -> [4720,4722]
operator: -> [4720,4722]
===
match
---
operator: = [9168,9169]
operator: = [9015,9016]
===
match
---
trailer [5371,5383]
trailer [5371,5383]
===
match
---
suite [9944,10558]
suite [9791,10405]
===
match
---
trailer [5025,5034]
trailer [5025,5034]
===
match
---
name: fromtimestamp [9501,9514]
name: fromtimestamp [9348,9361]
===
match
---
trailer [3458,3462]
trailer [3458,3462]
===
match
---
tfpdef [10606,10627]
tfpdef [10453,10474]
===
match
---
operator: , [6101,6102]
operator: , [6101,6102]
===
match
---
name: __init__ [2273,2281]
name: __init__ [2273,2281]
===
match
---
trailer [9813,9819]
trailer [9660,9666]
===
match
---
trailer [9198,9205]
trailer [9045,9052]
===
match
---
suite [10716,11914]
suite [10563,11761]
===
match
---
comparison [3521,3567]
comparison [3521,3567]
===
match
---
not_test [10392,10419]
not_test [10239,10266]
===
match
---
trailer [2227,2242]
trailer [2227,2242]
===
match
---
operator: = [5696,5697]
operator: = [5696,5697]
===
match
---
import_from [966,1017]
import_from [966,1017]
===
match
---
simple_stmt [1838,1873]
simple_stmt [1838,1873]
===
match
---
expr_stmt [1803,1833]
expr_stmt [1803,1833]
===
match
---
operator: = [4684,4685]
operator: = [4684,4685]
===
match
---
name: conn [7697,7701]
name: conn [7697,7701]
===
match
---
name: self [4714,4718]
name: self [4714,4718]
===
match
---
name: Tuple [894,899]
name: Tuple [894,899]
===
match
---
name: self [5698,5702]
name: self [5698,5702]
===
match
---
name: item [11522,11526]
name: item [11369,11373]
===
match
---
operator: -> [9936,9938]
operator: -> [9783,9785]
===
match
---
trailer [3393,3397]
trailer [3393,3397]
===
match
---
name: tenacity [4514,4522]
name: tenacity [4514,4522]
===
match
---
trailer [6406,6415]
trailer [6406,6415]
===
match
---
trailer [4629,4653]
trailer [4629,4653]
===
match
---
expr_stmt [3948,4088]
expr_stmt [3948,4088]
===
match
---
atom_expr [2562,2599]
atom_expr [2562,2599]
===
match
---
trailer [4171,4189]
trailer [4171,4189]
===
match
---
operator: = [2243,2244]
operator: = [2243,2244]
===
match
---
atom_expr [2890,3339]
atom_expr [2890,3339]
===
match
---
atom_expr [3589,3927]
atom_expr [3589,3927]
===
match
---
simple_stmt [2470,2501]
simple_stmt [2470,2501]
===
match
---
trailer [5899,5904]
trailer [5899,5904]
===
match
---
number: 10 [4602,4604]
number: 10 [4602,4604]
===
match
---
trailer [7732,7738]
trailer [7732,7738]
===
match
---
string: 'dir' [6684,6689]
string: 'dir' [6684,6689]
===
match
---
name: self [2582,2586]
name: self [2582,2586]
===
match
---
operator: , [11582,11583]
operator: , [11429,11430]
===
match
---
trailer [7427,7436]
trailer [7427,7436]
===
match
---
param [9873,9902]
param [9720,9749]
===
match
---
operator: = [7033,7034]
operator: = [7033,7034]
===
match
---
trailer [9889,9894]
trailer [9736,9741]
===
match
---
name: local_full_path [7797,7812]
name: local_full_path [7797,7812]
===
match
---
simple_stmt [3356,3501]
simple_stmt [3356,3501]
===
match
---
atom_expr [11528,11546]
atom_expr [11375,11393]
===
match
---
name: extra_options [4283,4296]
name: extra_options [4283,4296]
===
match
---
name: self [11345,11349]
name: self [11192,11196]
===
match
---
name: prefix [10412,10418]
name: prefix [10259,10265]
===
match
---
trailer [6451,6457]
trailer [6451,6457]
===
match
---
funcdef [10563,11914]
funcdef [10410,11761]
===
match
---
name: ucallback [11789,11798]
name: ucallback [11636,11645]
===
match
---
name: describe_directory [6078,6096]
name: describe_directory [6078,6096]
===
match
---
operator: * [2187,2188]
operator: * [2187,2188]
===
match
---
name: str [10688,10691]
name: str [10535,10538]
===
match
---
arglist [4509,4690]
arglist [4509,4690]
===
match
---
atom_expr [6052,6061]
atom_expr [6052,6061]
===
match
---
operator: , [7772,7773]
operator: , [7772,7773]
===
match
---
operator: = [8898,8899]
operator: = [8745,8746]
===
match
---
atom_expr [4430,4443]
atom_expr [4430,4443]
===
match
---
atom_expr [7423,7438]
atom_expr [7423,7438]
===
match
---
operator: -> [2204,2206]
operator: -> [2204,2206]
===
match
---
name: mode [7150,7154]
name: mode [7150,7154]
===
match
---
name: str [8472,8475]
name: str [8319,8322]
===
match
---
name: self [10589,10593]
name: self [10436,10440]
===
match
---
suite [10420,10446]
suite [10267,10293]
===
match
---
operator: , [7503,7504]
operator: , [7503,7504]
===
match
---
name: self [4801,4805]
name: self [4801,4805]
===
match
---
name: conn_params [5867,5878]
name: conn_params [5867,5878]
===
match
---
operator: = [3902,3903]
operator: = [3902,3903]
===
match
---
simple_stmt [4912,4935]
simple_stmt [4912,4935]
===
match
---
param [9577,9586]
param [9424,9433]
===
match
---
trailer [4653,4667]
trailer [4653,4667]
===
match
---
trailer [4854,4856]
trailer [4854,4856]
===
match
---
string: 'private_key_pass' [5778,5796]
string: 'private_key_pass' [5778,5796]
===
match
---
simple_stmt [1988,2128]
simple_stmt [1988,2128]
===
match
---
dictorsetmaker [5359,5496]
dictorsetmaker [5359,5496]
===
match
---
string: """         Returns a dictionary of {filename: {attributes}} for all files         on the remote system (where the MLSD command is supported).          :param path: full path to the remote directory         :type path: str         """ [6152,6386]
string: """         Returns a dictionary of {filename: {attributes}} for all files         on the remote system (where the MLSD command is supported).          :param path: full path to the remote directory         :type path: str         """ [6152,6386]
===
match
---
trailer [11554,11569]
trailer [11401,11416]
===
match
---
atom_expr [5259,5272]
atom_expr [5259,5272]
===
match
---
operator: = [6621,6622]
operator: = [6621,6622]
===
match
---
name: wait_exponential [4567,4583]
name: wait_exponential [4567,4583]
===
match
---
expr_stmt [5583,5622]
expr_stmt [5583,5622]
===
match
---
trailer [10622,10627]
trailer [10469,10474]
===
match
---
operator: } [6475,6476]
operator: } [6475,6476]
===
match
---
atom_expr [6609,6619]
atom_expr [6609,6619]
===
match
---
arglist [8933,8966]
arglist [8780,8813]
===
match
---
operator: , [9238,9239]
operator: , [9085,9086]
===
match
---
param [6829,6838]
param [6829,6838]
===
match
---
param [10636,10667]
param [10483,10514]
===
match
---
simple_stmt [825,841]
simple_stmt [825,841]
===
match
---
name: append [11534,11540]
name: append [11381,11387]
===
match
---
name: conn [7028,7032]
name: conn [7028,7032]
===
match
---
atom_expr [8900,8915]
atom_expr [8747,8762]
===
match
---
if_stmt [2830,3340]
if_stmt [2830,3340]
===
match
---
trailer [9524,9533]
trailer [9371,9380]
===
match
---
trailer [4876,4894]
trailer [4876,4894]
===
match
---
operator: = [11859,11860]
operator: = [11706,11707]
===
match
---
name: cnopts [5019,5025]
name: cnopts [5019,5025]
===
match
---
atom_expr [7447,7472]
atom_expr [7447,7472]
===
match
---
atom_expr [4872,4894]
atom_expr [4872,4894]
===
match
---
operator: -> [9251,9253]
operator: -> [9098,9100]
===
match
---
trailer [5034,5038]
trailer [5034,5038]
===
match
---
expr_stmt [7028,7050]
expr_stmt [7028,7050]
===
match
---
operator: , [11775,11776]
operator: , [11622,11623]
===
match
---
simple_stmt [4167,4250]
simple_stmt [4167,4250]
===
match
---
name: str [2165,2168]
name: str [2165,2168]
===
match
---
tfpdef [8477,8497]
tfpdef [8324,8344]
===
match
---
expr_stmt [6466,6476]
expr_stmt [6466,6476]
===
match
---
simple_stmt [7697,7720]
simple_stmt [7697,7720]
===
match
---
simple_stmt [5888,5905]
simple_stmt [5888,5905]
===
match
---
operator: -> [10674,10676]
operator: -> [10521,10523]
===
match
---
trailer [4566,4583]
trailer [4566,4583]
===
match
---
operator: , [6728,6729]
operator: , [6728,6729]
===
match
---
name: get [3459,3462]
name: get [3459,3462]
===
match
---
operator: = [4513,4514]
operator: = [4513,4514]
===
match
---
argument [2282,2287]
argument [2282,2287]
===
match
---
import_name [915,930]
import_name [915,930]
===
match
---
expr_stmt [5238,5272]
expr_stmt [5238,5272]
===
match
---
atom_expr [5583,5606]
atom_expr [5583,5606]
===
match
---
atom_expr [4167,4189]
atom_expr [4167,4189]
===
match
---
name: dirs [11376,11380]
name: dirs [11223,11227]
===
match
---
atom_expr [3948,3970]
atom_expr [3948,3970]
===
match
---
name: str [6835,6838]
name: str [6835,6838]
===
match
---
name: get_conn [9175,9183]
name: get_conn [9022,9030]
===
match
---
operator: = [9441,9442]
operator: = [9288,9289]
===
match
---
atom_expr [4196,4230]
atom_expr [4196,4230]
===
match
---
trailer [5548,5557]
trailer [5548,5557]
===
match
---
operator: = [11739,11740]
operator: = [11586,11587]
===
match
---
name: self [5259,5263]
name: self [5259,5263]
===
match
---
return_stmt [10525,10537]
return_stmt [10372,10384]
===
match
---
trailer [9183,9185]
trailer [9030,9032]
===
match
---
name: extra_options [4003,4016]
name: extra_options [4003,4016]
===
match
---
operator: , [2192,2193]
operator: , [2192,2193]
===
match
---
trailer [2272,2281]
trailer [2272,2281]
===
match
---
name: delimiter [10457,10466]
name: delimiter [10304,10313]
===
match
---
name: conn [6057,6061]
name: conn [6057,6061]
===
match
---
trailer [5804,5821]
trailer [5804,5821]
===
match
---
name: conn [6395,6399]
name: conn [6395,6399]
===
match
---
trailer [4346,4357]
trailer [4346,4357]
===
match
---
operator: } [2126,2127]
operator: } [2126,2127]
===
match
---
trailer [6650,6658]
trailer [6650,6658]
===
match
---
operator: , [3822,3823]
operator: , [3822,3823]
===
match
---
operator: -> [7167,7169]
operator: -> [7167,7169]
===
match
---
operator: -> [5931,5933]
operator: -> [5931,5933]
===
match
---
atom_expr [8924,8967]
atom_expr [8771,8814]
===
match
---
atom_expr [4192,4239]
atom_expr [4192,4239]
===
match
---
suite [2869,3340]
suite [2869,3340]
===
match
---
atom [11401,11403]
atom [11248,11250]
===
match
---
string: """Closes the connection""" [5948,5975]
string: """Closes the connection""" [5948,5975]
===
match
---
string: """         Returns a list of files on the remote system.          :param path: full path to the remote directory to list         :type path: str         """ [6862,7019]
string: """         Returns a list of files on the remote system.          :param path: full path to the remote directory to list         :type path: str         """ [6862,7019]
===
match
---
testlist_star_expr [11369,11390]
testlist_star_expr [11216,11237]
===
match
---
name: warn [3598,3602]
name: warn [3598,3602]
===
match
---
operator: , [7137,7138]
operator: , [7137,7138]
===
match
---
name: get_conn [7709,7717]
name: get_conn [7709,7717]
===
match
---
atom_expr [5987,5996]
atom_expr [5987,5996]
===
match
---
suite [6009,6069]
suite [6009,6069]
===
match
---
trailer [4048,4054]
trailer [4048,4054]
===
match
---
name: host_key [5088,5096]
name: host_key [5088,5096]
===
match
---
name: staticmethod [9826,9838]
name: staticmethod [9673,9685]
===
match
---
operator: } [6776,6777]
operator: } [6776,6777]
===
match
---
name: Optional [884,892]
name: Optional [884,892]
===
match
---
name: self [2146,2150]
name: self [2146,2150]
===
match
---
expr_stmt [5327,5510]
expr_stmt [5327,5510]
===
match
---
suite [1979,2128]
suite [1979,2128]
===
match
---
parameters [8988,9005]
parameters [8835,8852]
===
match
---
name: get_conn [9776,9784]
name: get_conn [9623,9631]
===
match
---
name: get_name [5071,5079]
name: get_name [5071,5079]
===
match
---
tfpdef [10595,10604]
tfpdef [10442,10451]
===
match
---
name: get_ui_field_behaviour [1946,1968]
name: get_ui_field_behaviour [1946,1968]
===
match
---
string: 'private_key' [4378,4391]
string: 'private_key' [4378,4391]
===
match
---
parameters [2145,2203]
parameters [2145,2203]
===
match
---
atom_expr [10647,10660]
atom_expr [10494,10507]
===
match
---
name: files [7101,7106]
name: files [7101,7106]
===
match
---
simple_stmt [1900,1919]
simple_stmt [1900,1919]
===
match
---
argument [11730,11775]
argument [11577,11622]
===
match
---
param [7774,7796]
param [7774,7796]
===
match
---
suite [4741,5905]
suite [4741,5905]
===
match
---
suite [2542,4479]
suite [2542,4479]
===
match
---
operator: -> [6114,6116]
operator: -> [6114,6116]
===
match
---
simple_stmt [6466,6477]
simple_stmt [6466,6477]
===
match
---
name: extra_options [4395,4408]
name: extra_options [4395,4408]
===
match
---
operator: = [4594,4595]
operator: = [4594,4595]
===
match
---
trailer [7708,7717]
trailer [7708,7717]
===
match
---
operator: , [5461,5462]
operator: , [5461,5462]
===
match
---
name: self [5526,5530]
name: self [5526,5530]
===
match
---
suite [5749,5822]
suite [5749,5822]
===
match
---
trailer [5839,5844]
trailer [5839,5844]
===
match
---
operator: = [4444,4445]
operator: = [4444,4445]
===
match
---
argument [11789,11838]
argument [11636,11685]
===
match
---
return_stmt [11885,11913]
return_stmt [11732,11760]
===
match
---
name: remote_full_path [8950,8966]
name: remote_full_path [8797,8813]
===
match
---
name: DeprecationWarning [3848,3866]
name: DeprecationWarning [3848,3866]
===
match
---
trailer [8211,8220]
trailer [8211,8220]
===
match
---
name: str [6848,6851]
name: str [6848,6851]
===
match
---
parameters [9570,9587]
parameters [9417,9434]
===
match
---
operator: -> [1971,1973]
operator: -> [1971,1973]
===
match
---
atom_expr [5526,5539]
atom_expr [5526,5539]
===
match
---
name: self [9408,9412]
name: self [9255,9259]
===
match
---
name: str [9001,9004]
name: str [8848,8851]
===
match
---
name: unknowns [11382,11390]
name: unknowns [11229,11237]
===
match
---
operator: , [4667,4668]
operator: , [4667,4668]
===
match
---
name: self [9170,9174]
name: self [9017,9021]
===
match
---
name: conn [5900,5904]
name: conn [5900,5904]
===
match
---
name: Optional [9881,9889]
name: Optional [9728,9736]
===
match
---
name: self [5544,5548]
name: self [5544,5548]
===
match
---
funcdef [8973,9212]
funcdef [8820,9059]
===
match
---
trailer [9412,9421]
trailer [9259,9268]
===
match
---
name: st_size [6651,6658]
name: st_size [6651,6658]
===
match
---
parameters [7132,7166]
parameters [7132,7166]
===
match
---
operator: , [892,893]
operator: , [892,893]
===
match
---
suite [7175,7473]
suite [7175,7473]
===
match
---
trailer [11569,11594]
trailer [11416,11441]
===
match
---
atom_expr [5238,5256]
atom_expr [5238,5256]
===
match
---
name: list_ [11488,11493]
name: list_ [11335,11340]
===
match
---
expr_stmt [1877,1895]
expr_stmt [1877,1895]
===
match
---
name: conn [9401,9405]
name: conn [9248,9252]
===
match
---
trailer [5702,5711]
trailer [5702,5711]
===
match
---
trailer [2337,2354]
trailer [2337,2354]
===
match
---
expr_stmt [9432,9467]
expr_stmt [9279,9314]
===
match
---
suite [7827,8428]
suite [7827,8275]
===
match
---
suite [9258,9550]
suite [9105,9397]
===
match
---
name: self [8448,8452]
name: self [8295,8299]
===
match
---
tfpdef [7139,7148]
tfpdef [7139,7148]
===
match
---
atom_expr [9194,9211]
atom_expr [9041,9058]
===
match
---
simple_stmt [11614,11876]
simple_stmt [11461,11723]
===
match
---
operator: , [2150,2151]
operator: , [2150,2151]
===
match
---
name: self [4167,4171]
name: self [4167,4171]
===
match
---
trailer [9784,9786]
trailer [9631,9633]
===
match
---
name: path [7080,7084]
name: path [7080,7084]
===
match
---
name: path [6829,6833]
name: path [6829,6833]
===
match
---
operator: , [5383,5384]
operator: , [5383,5384]
===
match
---
simple_stmt [10525,10538]
simple_stmt [10372,10385]
===
match
---
trailer [4195,4231]
trailer [4195,4231]
===
match
---
operator: = [7421,7422]
operator: = [7421,7422]
===
match
---
funcdef [9555,9820]
funcdef [9402,9667]
===
match
---
trailer [9205,9211]
trailer [9052,9058]
===
match
---
atom_expr [6706,6715]
atom_expr [6706,6715]
===
match
---
operator: , [2101,2102]
operator: , [2101,2102]
===
match
---
tfpdef [8995,9004]
tfpdef [8842,8851]
===
match
---
trailer [2517,2529]
trailer [2517,2529]
===
match
---
name: str [8494,8497]
name: str [8341,8344]
===
match
---
param [2152,2186]
param [2152,2186]
===
match
---
name: no_host_key_check [3953,3970]
name: no_host_key_check [3953,3970]
===
match
---
suite [10512,10538]
suite [10359,10385]
===
match
---
name: no_host_key_check [4877,4894]
name: no_host_key_check [4877,4894]
===
match
---
name: conn [6434,6438]
name: conn [6434,6438]
===
match
---
name: create_directory [7116,7132]
name: create_directory [7116,7132]
===
match
---
name: private_key_pass [5732,5748]
name: private_key_pass [5732,5748]
===
match
---
tfpdef [7797,7817]
tfpdef [7797,7817]
===
match
---
name: _is_path_match [9847,9861]
name: _is_path_match [9694,9708]
===
match
---
atom_expr [5285,5299]
atom_expr [5285,5299]
===
match
---
argument [11670,11716]
argument [11517,11563]
===
match
---
if_stmt [2510,4479]
if_stmt [2510,4479]
===
match
---
name: files [6793,6798]
name: files [6793,6798]
===
match
---
name: self [2562,2566]
name: self [2562,2566]
===
match
---
trailer [7048,7050]
trailer [7048,7050]
===
match
---
operator: = [2169,2170]
operator: = [2169,2170]
===
match
---
name: str [7511,7514]
name: str [7511,7514]
===
match
---
operator: = [2383,2384]
operator: = [2383,2384]
===
match
---
name: conn [9443,9447]
name: conn [9290,9294]
===
match
---
name: datetime [6522,6530]
name: datetime [6522,6530]
===
match
---
atom_expr [7035,7050]
atom_expr [7035,7050]
===
match
---
name: key_file [5703,5711]
name: key_file [5703,5711]
===
match
---
return_stmt [9795,9819]
return_stmt [9642,9666]
===
match
---
param [8995,9004]
param [8842,8851]
===
match
---
string: '`private_key_passphrase` will precede if both options are specified.' [3073,3143]
string: '`private_key_passphrase` will precede if both options are specified.' [3073,3143]
===
match
---
name: remote_full_path [8454,8470]
name: remote_full_path [8301,8317]
===
match
---
trailer [5731,5748]
trailer [5731,5748]
===
match
---
name: self [5039,5043]
name: self [5039,5043]
===
match
---
file_input [787,11914]
file_input [787,11761]
===
match
---
name: self [5925,5929]
name: self [5925,5929]
===
match
---
string: 'Please use `private_key_passphrase` instead.' [3002,3048]
string: 'Please use `private_key_passphrase` instead.' [3002,3048]
===
match
---
if_stmt [5635,5712]
if_stmt [5635,5712]
===
match
---
tfpdef [9862,9871]
tfpdef [9709,9718]
===
match
---
operator: , [876,877]
operator: , [876,877]
===
match
---
name: get [4460,4463]
name: get [4460,4463]
===
match
---
name: self [2370,2374]
name: self [2370,2374]
===
match
---
suite [4297,4358]
suite [4297,4358]
===
match
---
tfpdef [9577,9586]
tfpdef [9424,9433]
===
match
---
trailer [4847,4854]
trailer [4847,4854]
===
match
---
simple_stmt [966,1018]
simple_stmt [966,1018]
===
match
---
suite [4146,4250]
suite [4146,4250]
===
match
---
name: wait [4553,4557]
name: wait [4553,4557]
===
match
---
trailer [5244,5256]
trailer [5244,5256]
===
match
---
simple_stmt [6152,6387]
simple_stmt [6152,6387]
===
match
---
atom_expr [6554,6564]
atom_expr [6554,6564]
===
match
---
param [8989,8994]
param [8836,8841]
===
match
---
funcdef [4701,5905]
funcdef [4701,5905]
===
match
---
trailer [3597,3602]
trailer [3597,3602]
===
match
---
name: self [8900,8904]
name: self [8747,8751]
===
match
---
atom_expr [5409,5418]
atom_expr [5409,5418]
===
match
---
funcdef [6804,7107]
funcdef [6804,7107]
===
match
---
simple_stmt [853,900]
simple_stmt [853,900]
===
match
---
param [6823,6828]
param [6823,6828]
===
match
---
name: conn [2615,2619]
name: conn [2615,2619]
===
match
---
name: conn [8200,8204]
name: conn [8200,8204]
===
match
---
trailer [4209,4230]
trailer [4209,4230]
===
match
---
simple_stmt [11369,11445]
simple_stmt [11216,11292]
===
match
---
operator: = [2669,2670]
operator: = [2669,2670]
===
match
---
expr_stmt [1900,1918]
expr_stmt [1900,1918]
===
match
---
operator: = [5845,5846]
operator: = [5845,5846]
===
match
---
operator: = [4557,4558]
operator: = [4557,4558]
===
match
---
name: host_key [4977,4985]
name: host_key [4977,4985]
===
match
---
simple_stmt [7416,7439]
simple_stmt [7416,7439]
===
match
---
name: stat [6693,6697]
name: stat [6693,6697]
===
match
---
arglist [2282,2297]
arglist [2282,2297]
===
match
---
parameters [5924,5930]
parameters [5924,5930]
===
match
---
string: 'Extra option `private_key_pass` is deprecated.' [2929,2977]
string: 'Extra option `private_key_pass` is deprecated.' [2929,2977]
===
match
---
string: 'cnopts' [5479,5487]
string: 'cnopts' [5479,5487]
===
match
---
decorator [4484,4697]
decorator [4484,4697]
===
match
---
param [2146,2151]
param [2146,2151]
===
match
---
name: files [11369,11374]
name: files [11216,11221]
===
match
---
simple_stmt [6862,7020]
simple_stmt [6862,7020]
===
match
---
name: self [11550,11554]
name: self [11397,11401]
===
match
---
tfpdef [7505,7514]
tfpdef [7505,7514]
===
match
---
comparison [4270,4296]
comparison [4270,4296]
===
match
---
name: List [10683,10687]
name: List [10530,10534]
===
match
---
atom_expr [11614,11875]
atom_expr [11461,11722]
===
match
---
name: self [5800,5804]
name: self [5800,5804]
===
match
---
string: """         Return True if given path starts with prefix (if set) and ends with delimiter (if set).          :param path: path to be checked         :type path: str         :param prefix: if set path will be checked is starting with prefix         :type prefix: str         :param delimiter: if set path will be checked is ending with suffix         :type delimiter: str         :return: bool         """ [9953,10357]
string: """         Return True if given path starts with prefix (if set) and ends with delimiter (if set).          :param path: path to be checked         :type path: str         :param prefix: if set path will be checked is starting with prefix         :type prefix: str         :param delimiter: if set path will be checked is ending with suffix         :type delimiter: str         :return: bool         """ [9800,10204]
===
match
---
simple_stmt [10433,10446]
simple_stmt [10280,10293]
===
match
---
param [9234,9239]
param [9081,9086]
===
match
---
name: walktree [11619,11627]
name: walktree [11466,11474]
===
match
---
operator: = [11679,11680]
operator: = [11526,11527]
===
match
---
simple_stmt [8303,8347]
simple_stmt [8231,8275]
===
match
---
operator: -> [9588,9590]
operator: -> [9435,9437]
===
match
---
atom_expr [5669,5695]
atom_expr [5669,5695]
===
match
---
name: local_full_path [8330,8345]
name: local_full_path [8258,8273]
===
match
---
name: str [10601,10604]
name: str [10448,10451]
===
match
---
operator: , [11374,11375]
operator: , [11221,11222]
===
match
---
return_stmt [1988,2127]
return_stmt [1988,2127]
===
match
---
atom_expr [9771,9786]
atom_expr [9618,9633]
===
match
---
atom [11397,11399]
atom [11244,11246]
===
match
---
expr_stmt [5669,5711]
expr_stmt [5669,5711]
===
match
---
trailer [6539,6553]
trailer [6539,6553]
===
match
---
atom_expr [8303,8346]
atom_expr [8231,8274]
===
match
---
name: append_matching_path_callback [11458,11487]
name: append_matching_path_callback [11305,11334]
===
match
---
expr_stmt [2655,2688]
expr_stmt [2655,2688]
===
match
---
name: conn_params [5766,5777]
name: conn_params [5766,5777]
===
match
---
operator: , [3278,3279]
operator: , [3278,3279]
===
match
---
atom_expr [5302,5314]
atom_expr [5302,5314]
===
match
---
expr_stmt [6052,6068]
expr_stmt [6052,6068]
===
match
---
string: 'ciphers' [4347,4356]
string: 'ciphers' [4347,4356]
===
match
---
trailer [4463,4478]
trailer [4463,4478]
===
match
---
parameters [10579,10673]
parameters [10426,10520]
===
match
---
trailer [4237,4239]
trailer [4237,4239]
===
match
---
name: str [6109,6112]
name: str [6109,6112]
===
match
---
name: multiplier [4584,4594]
name: multiplier [4584,4594]
===
match
---
name: remotepath [11641,11651]
name: remotepath [11488,11498]
===
match
---
atom_expr [2582,2598]
atom_expr [2582,2598]
===
match
---
name: providers [979,988]
name: providers [979,988]
===
match
---
string: 'modify' [6746,6754]
string: 'modify' [6746,6754]
===
match
---
simple_stmt [6052,6069]
simple_stmt [6052,6069]
===
match
---
tfpdef [7774,7795]
tfpdef [7774,7795]
===
match
---
operator: , [11864,11865]
operator: , [11711,11712]
===
match
---
name: conn [5840,5844]
name: conn [5840,5844]
===
match
---
name: args [2283,2287]
name: args [2283,2287]
===
match
---
argument [2289,2297]
argument [2289,2297]
===
match
---
argument [11852,11864]
argument [11699,11711]
===
match
---
name: get [8308,8311]
name: get [8236,8239]
===
match
---
operator: { [6623,6624]
operator: { [6623,6624]
===
match
---
simple_stmt [2370,2390]
simple_stmt [2370,2390]
===
match
---
arglist [4584,4604]
arglist [4584,4604]
===
match
---
string: 'This option will be removed in Airflow 2.1' [3778,3822]
string: 'This option will be removed in Airflow 2.1' [3778,3822]
===
match
---
param [10595,10605]
param [10442,10452]
===
match
---
name: DeprecationWarning [3260,3278]
name: DeprecationWarning [3260,3278]
===
match
---
simple_stmt [7028,7051]
simple_stmt [7028,7051]
===
match
---
name: path [6452,6456]
name: path [6452,6456]
===
match
---
simple_stmt [9476,9550]
simple_stmt [9323,9397]
===
match
---
operator: = [11798,11799]
operator: = [11645,11646]
===
match
---
operator: = [9769,9770]
operator: = [9616,9617]
===
match
---
name: conn [8893,8897]
name: conn [8740,8744]
===
match
---
name: ciphers [5307,5314]
name: ciphers [5307,5314]
===
match
---
string: 'ftp_conn_id' [1820,1833]
string: 'ftp_conn_id' [1820,1833]
===
match
---
simple_stmt [931,965]
simple_stmt [931,965]
===
match
---
suite [9014,9212]
suite [8861,9059]
===
match
---
funcdef [7478,7745]
funcdef [7478,7745]
===
match
---
name: list_ [11528,11533]
name: list_ [11375,11380]
===
match
---
string: 'private_key_pass' [3463,3481]
string: 'private_key_pass' [3463,3481]
===
match
---
simple_stmt [9764,9787]
simple_stmt [9611,9634]
===
match
---
simple_stmt [6786,6799]
simple_stmt [6786,6799]
===
match
---
name: Connection [5854,5864]
name: Connection [5854,5864]
===
match
---
name: conn [7067,7071]
name: conn [7067,7071]
===
match
---
name: self [5895,5899]
name: self [5895,5899]
===
match
---
atom_expr [6117,6142]
atom_expr [6117,6142]
===
match
---
param [7505,7514]
param [7505,7514]
===
match
---
operator: , [5418,5419]
operator: , [5418,5419]
===
match
---
simple_stmt [1803,1834]
simple_stmt [1803,1834]
===
match
---
name: str [6137,6140]
name: str [6137,6140]
===
match
---
operator: = [2493,2494]
operator: = [2493,2494]
===
match
---
string: """         Transfers the remote file to a local location.         If local_full_path is a string path, the file will be put         at that location          :param remote_full_path: full path to the remote file         :type remote_full_path: str         :param local_full_path: full path to the local file         :type local_full_path: str         """ [7836,8191]
string: """         Transfers the remote file to a local location.         If local_full_path is a string path, the file will be put         at that location          :param remote_full_path: full path to the remote file         :type remote_full_path: str         :param local_full_path: full path to the local file         :type local_full_path: str         """ [7836,8191]
===
match
---
name: SSHException [952,964]
name: SSHException [952,964]
===
match
---
simple_stmt [7094,7107]
simple_stmt [7094,7107]
===
match
---
return_stmt [11508,11604]
return_stmt [11355,11451]
===
match
---
number: 2 [3903,3904]
number: 2 [3903,3904]
===
match
---
expr_stmt [11338,11360]
expr_stmt [11185,11207]
===
match
---
trailer [9452,9458]
trailer [9299,9305]
===
match
---
operator: , [4605,4606]
operator: , [4605,4606]
===
match
---
param [7768,7773]
param [7768,7773]
===
match
---
name: self [5727,5731]
name: self [5727,5731]
===
match
---
name: ssh [989,992]
name: ssh [989,992]
===
match
---
simple_stmt [10546,10558]
simple_stmt [10393,10405]
===
match
---
string: 'no_host_key_check' [4210,4229]
string: 'no_host_key_check' [4210,4229]
===
match
---
name: str [7792,7795]
name: str [7792,7795]
===
match
---
operator: = [5339,5340]
operator: = [5339,5340]
===
match
---
name: get_conn [6407,6415]
name: get_conn [6407,6415]
===
match
---
operator: , [7148,7149]
operator: , [7148,7149]
===
match
---
simple_stmt [4832,4857]
simple_stmt [4832,4857]
===
match
---
name: conn [2313,2317]
name: conn [2313,2317]
===
match
---
param [9903,9934]
param [9750,9781]
===
match
---
arglist [3628,3905]
arglist [3628,3905]
===
match
---
name: ftp_mdtm [9515,9523]
name: ftp_mdtm [9362,9370]
===
match
---
name: Dict [1974,1978]
name: Dict [1974,1978]
===
match
---
atom [5341,5510]
atom [5341,5510]
===
match
---
expr_stmt [1838,1872]
expr_stmt [1838,1872]
===
match
---
name: modify [6513,6519]
name: modify [6513,6519]
===
match
---
suite [5119,5225]
suite [5119,5225]
===
match
---
atom_expr [3445,3482]
atom_expr [3445,3482]
===
match
---
trailer [10698,10703]
trailer [10545,10550]
===
match
---
parameters [8447,8498]
parameters [8294,8345]
===
match
---
and_test [10369,10419]
and_test [10216,10266]
===
match
---
atom [2026,2036]
atom [2026,2036]
===
match
---
suite [4409,4479]
suite [4409,4479]
===
match
---
dictorsetmaker [2009,2117]
dictorsetmaker [2009,2117]
===
match
---
atom_expr [7067,7085]
atom_expr [7067,7085]
===
match
---
trailer [2903,3339]
trailer [2903,3339]
===
match
---
atom_expr [7704,7719]
atom_expr [7704,7719]
===
match
---
name: Tuple [10677,10682]
name: Tuple [10524,10529]
===
match
---
operator: = [9928,9929]
operator: = [9775,9776]
===
match
---
operator: , [7795,7796]
operator: , [7795,7796]
===
match
---
name: cnopts [5285,5291]
name: cnopts [5285,5291]
===
match
---
trailer [4583,4605]
trailer [4583,4605]
===
match
---
atom_expr [5835,5844]
atom_expr [5835,5844]
===
match
---
string: 'schema' [2027,2035]
string: 'schema' [2027,2035]
===
match
---
name: listdir_attr [6439,6451]
name: listdir_attr [6439,6451]
===
match
---
operator: , [4689,4690]
operator: , [4689,4690]
===
match
---
trailer [5864,5879]
trailer [5864,5879]
===
match
---
import_name [2797,2812]
import_name [2797,2812]
===
match
---
name: List [10694,10698]
name: List [10541,10545]
===
match
---
suite [6853,7107]
suite [6853,7107]
===
match
---
operator: , [11656,11657]
operator: , [11503,11504]
===
match
---
name: bool [9939,9943]
name: bool [9786,9790]
===
match
---
atom_expr [10683,10692]
atom_expr [10530,10539]
===
match
---
operator: = [6432,6433]
operator: = [6432,6433]
===
match
---
name: exists [9807,9813]
name: exists [9654,9660]
===
match
---
suite [6143,6799]
suite [6143,6799]
===
match
---
string: 'login' [2082,2089]
string: 'login' [2082,2089]
===
match
---
name: typing [858,864]
name: typing [858,864]
===
match
---
name: lower [4049,4054]
name: lower [4049,4054]
===
match
---
string: """         Transfers a local file to the remote location.         If local_full_path_or_buffer is a string path, the file will be read         from that location          :param remote_full_path: full path to the remote file         :type remote_full_path: str         :param local_full_path: full path to the local file         :type local_full_path: str         """ [8516,8884]
string: """         Transfers a local file to the remote location.         If local_full_path_or_buffer is a string path, the file will be read         from that location          :param remote_full_path: full path to the remote file         :type remote_full_path: str         :param local_full_path: full path to the local file         :type local_full_path: str         """ [8363,8731]
===
match
---
simple_stmt [11338,11361]
simple_stmt [11185,11208]
===
match
---
trailer [5043,5055]
trailer [5043,5055]
===
match
---
name: List [10705,10709]
name: List [10552,10556]
===
match
---
operator: = [6520,6521]
operator: = [6520,6521]
===
match
---
operator: = [4928,4929]
operator: = [4928,4929]
===
match
---
trailer [10400,10411]
trailer [10247,10258]
===
match
---
string: 'username' [5436,5446]
string: 'username' [5436,5446]
===
match
---
if_stmt [4798,5880]
if_stmt [4798,5880]
===
match
---
name: cnopts [4832,4838]
name: cnopts [4832,4838]
===
match
---
name: add [5035,5038]
name: add [5035,5038]
===
match
---
name: fromtimestamp [6540,6553]
name: fromtimestamp [6540,6553]
===
match
---
name: str [10623,10626]
name: str [10470,10473]
===
match
---
string: """         Return tuple with recursive lists of files, directories and unknown paths from given path.         It is possible to filter results by giving prefix and/or delimiter parameters.          :param path: path from which tree will be built         :type path: str         :param prefix: if set paths will be added if start with prefix         :type prefix: str         :param delimiter: if set paths will be added if end with delimiter         :type delimiter: str         :return: tuple with list of files, dirs and unknown items         :rtype: Tuple[List[str], List[str], List[str]]         """ [10725,11329]
string: """         Return tuple with recursive lists of files, directories and unknown paths from given path.         It is possible to filter results by giving prefix and/or delimiter parameters.          :param path: path from which tree will be built         :type path: str         :param prefix: if set paths will be added if start with prefix         :type prefix: str         :param delimiter: if set paths will be added if end with delimiter         :type delimiter: str         :return: tuple with list of files, dirs and unknown items         :rtype: Tuple[List[str], List[str], List[str]]         """ [10572,11176]
===
match
---
expr_stmt [2555,2599]
expr_stmt [2555,2599]
===
match
---
trailer [10682,10715]
trailer [10529,10562]
===
match
---
expr_stmt [5835,5879]
expr_stmt [5835,5879]
===
match
---
atom [6623,6777]
atom [6623,6777]
===
match
---
name: warnings [3589,3597]
name: warnings [3589,3597]
===
match
---
trailer [6574,6590]
trailer [6574,6590]
===
match
---
name: pysftp [908,914]
name: pysftp [908,914]
===
match
---
expr_stmt [7416,7438]
expr_stmt [7416,7438]
===
insert-tree
---
simple_stmt [787,825]
    string: """This module contains SFTP hook.""" [787,824]
to
file_input [787,11914]
at 0
===
insert-node
---
name: SFTPHook [1026,1034]
to
classdef [1020,11914]
at 0
===
insert-node
---
name: SSHHook [1035,1042]
to
classdef [1020,11914]
at 1
===
insert-tree
---
simple_stmt [1049,1798]
    string: """     This hook is inherited from SSH hook. Please refer to SSH hook for the input     arguments.      Interact with SFTP. Aims to be interchangeable with FTPHook.      :Pitfalls::          - In contrast with FTPHook describe_directory only returns size, type and           modify. It doesn't return unix.owner, unix.mode, perm, unix.group and           unique.         - retrieve_file and store_file only take a local full path and not a            buffer.         - If no mode is passed to create_directory it will be created with 777           permissions.      Errors that may occur throughout but should be handled downstream.      :param sftp_conn_id: The :ref:`sftp connection id<howto/connection:sftp>`     :type sftp_conn_id: str     """ [1049,1797]
to
suite [1044,11914]
at 0
===
delete-tree
---
simple_stmt [787,825]
    string: """This module contains SFTP hook.""" [787,824]
===
delete-node
---
name: SFTPHook [1026,1034]
===
===
delete-node
---
name: SSHHook [1035,1042]
===
===
delete-tree
---
simple_stmt [1049,1798]
    string: """     This hook is inherited from SSH hook. Please refer to SSH hook for the input     arguments.      Interact with SFTP. Aims to be interchangeable with FTPHook.      :Pitfalls::          - In contrast with FTPHook describe_directory only returns size, type and           modify. It doesn't return unix.owner, unix.mode, perm, unix.group and           unique.         - retrieve_file and store_file only take a local full path and not a            buffer.         - If no mode is passed to create_directory it will be created with 777           permissions.      Errors that may occur throughout but should be handled downstream.      :param sftp_conn_id: The :ref:`sftp connection id<howto/connection:sftp>`     :type sftp_conn_id: str     """ [1049,1797]
===
delete-tree
---
simple_stmt [8231,8295]
    atom_expr [8231,8294]
        name: self [8231,8235]
        trailer [8235,8239]
            name: log [8236,8239]
        trailer [8239,8244]
            name: info [8240,8244]
        trailer [8244,8294]
            arglist [8245,8293]
                string: 'Retrieving file from FTP: %s' [8245,8275]
                operator: , [8275,8276]
                name: remote_full_path [8277,8293]
===
delete-tree
---
simple_stmt [8355,8428]
    atom_expr [8355,8427]
        name: self [8355,8359]
        trailer [8359,8363]
            name: log [8360,8363]
        trailer [8363,8368]
            name: info [8364,8368]
        trailer [8368,8427]
            arglist [8369,8426]
                string: 'Finished retrieving file from FTP: %s' [8369,8408]
                operator: , [8408,8409]
                name: remote_full_path [8410,8426]
