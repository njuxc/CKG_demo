===
match
---
suite [16866,16998]
suite [16963,17095]
===
match
---
name: self [11891,11895]
name: self [11891,11895]
===
match
---
string: '\n\t' [19822,19828]
string: '\n\t' [19919,19925]
===
match
---
operator: , [11947,11948]
operator: , [11947,11948]
===
match
---
atom_expr [3113,3140]
atom_expr [3113,3140]
===
match
---
operator: , [1440,1441]
operator: , [1440,1441]
===
match
---
simple_stmt [12884,12941]
simple_stmt [12884,12941]
===
match
---
trailer [4253,4258]
trailer [4253,4258]
===
match
---
trailer [7913,7915]
trailer [7913,7915]
===
match
---
import_name [6733,6754]
import_name [6733,6754]
===
match
---
trailer [11034,11039]
trailer [11034,11039]
===
match
---
arglist [6014,6041]
arglist [6014,6041]
===
match
---
exprlist [19202,19231]
exprlist [19299,19328]
===
match
---
expr_stmt [24653,24792]
expr_stmt [24750,24889]
===
match
---
arglist [24718,24777]
arglist [24815,24874]
===
match
---
name: log [4843,4846]
name: log [4843,4846]
===
match
---
operator: , [16671,16672]
operator: , [16768,16769]
===
match
---
trailer [24991,25035]
trailer [25088,25132]
===
match
---
name: airflow [1733,1740]
name: airflow [1733,1740]
===
match
---
name: bulk_state_fetcher [18982,19000]
name: bulk_state_fetcher [19079,19097]
===
match
---
name: Optional [17131,17139]
name: Optional [17228,17236]
===
match
---
trailer [9589,9610]
trailer [9589,9610]
===
match
---
tfpdef [17424,17447]
tfpdef [17521,17544]
===
match
---
atom_expr [2980,3026]
atom_expr [2980,3026]
===
match
---
atom_expr [5746,5825]
atom_expr [5746,5825]
===
match
---
operator: = [23385,23386]
operator: = [23482,23483]
===
match
---
name: _ [9409,9410]
name: _ [9409,9410]
===
match
---
name: task_publish_max_retries [10491,10515]
name: task_publish_max_retries [10491,10515]
===
match
---
operator: , [24092,24093]
operator: , [24189,24190]
===
match
---
simple_stmt [3781,3827]
simple_stmt [3781,3827]
===
match
---
name: e [4927,4928]
name: e [4927,4928]
===
match
---
name: info [25370,25374]
name: info [25467,25471]
===
match
---
name: task_publish_max_retries [8436,8460]
name: task_publish_max_retries [8436,8460]
===
match
---
name: mget [22692,22696]
name: mget [22789,22793]
===
match
---
name: self [12095,12099]
name: self [12095,12099]
===
match
---
simple_stmt [16477,16519]
simple_stmt [16574,16616]
===
match
---
name: __init__ [7453,7461]
name: __init__ [7453,7461]
===
match
---
simple_stmt [4579,4603]
simple_stmt [4579,4603]
===
match
---
name: self [16946,16950]
name: self [17043,17047]
===
match
---
name: CELERY_SEND_ERR_MSG_HEADER [11130,11156]
name: CELERY_SEND_ERR_MSG_HEADER [11130,11156]
===
match
---
simple_stmt [4428,4447]
simple_stmt [4428,4447]
===
match
---
expr_stmt [19099,19111]
expr_stmt [19196,19208]
===
match
---
name: self [12416,12420]
name: self [12416,12420]
===
match
---
string: """Updates states of the tasks.""" [15295,15329]
string: """Updates states of the tasks.""" [15392,15426]
===
match
---
name: range [9334,9339]
name: range [9334,9339]
===
match
---
name: math [980,984]
name: math [980,984]
===
match
---
operator: = [19107,19108]
operator: = [19204,19205]
===
match
---
name: change_state [15784,15796]
name: change_state [15881,15893]
===
match
---
name: async_tasks [22483,22494]
name: async_tasks [22580,22591]
===
match
---
name: result [19281,19287]
name: result [19378,19384]
===
match
---
annassign [8138,8196]
annassign [8138,8196]
===
match
---
trailer [14741,14754]
trailer [14838,14851]
===
match
---
simple_stmt [14409,14683]
simple_stmt [14506,14780]
===
match
---
operator: = [12497,12498]
operator: = [12497,12498]
===
match
---
simple_stmt [6078,6151]
simple_stmt [6078,6151]
===
match
---
name: MutableMapping [24834,24848]
name: MutableMapping [24931,24945]
===
match
---
operator: , [5868,5869]
operator: , [5868,5869]
===
match
---
string: "status" [24028,24036]
string: "status" [24125,24133]
===
match
---
name: Any [20132,20135]
name: Any [20229,20232]
===
match
---
name: CalledProcessError [4810,4828]
name: CalledProcessError [4810,4828]
===
match
---
simple_stmt [23913,23964]
simple_stmt [24010,24061]
===
match
---
atom_expr [22193,22238]
atom_expr [22290,22335]
===
match
---
tfpdef [4498,4526]
tfpdef [4498,4526]
===
match
---
name: adopted_task_timeouts [15951,15972]
name: adopted_task_timeouts [16048,16069]
===
match
---
operator: , [9354,9355]
operator: , [9354,9355]
===
match
---
suite [4625,4679]
suite [4625,4679]
===
match
---
name: AsyncResult [20069,20080]
name: AsyncResult [20166,20177]
===
match
---
name: app [22141,22144]
name: app [22238,22241]
===
match
---
trailer [23950,23954]
trailer [24047,24051]
===
match
---
dotted_name [6982,6999]
dotted_name [6982,6999]
===
match
---
trailer [11895,11913]
trailer [11895,11913]
===
match
---
name: log [16628,16631]
name: log [16725,16728]
===
match
---
import_from [3781,3826]
import_from [3781,3826]
===
match
---
simple_stmt [25383,25417]
simple_stmt [25480,25514]
===
match
---
name: key [19698,19701]
name: key [19795,19798]
===
match
---
name: List [12022,12026]
name: List [12022,12026]
===
match
---
comparison [12062,12091]
comparison [12062,12091]
===
match
---
atom_expr [14967,14977]
atom_expr [15064,15074]
===
match
---
simple_stmt [12483,12553]
simple_stmt [12483,12553]
===
match
---
arglist [24992,25034]
arglist [25089,25131]
===
match
---
simple_stmt [18950,19090]
simple_stmt [19047,19187]
===
match
---
name: subprocess [4744,4754]
name: subprocess [4744,4754]
===
match
---
name: chunksize [12744,12753]
name: chunksize [12744,12753]
===
match
---
simple_stmt [1145,1183]
simple_stmt [1145,1183]
===
match
---
trailer [18981,19000]
trailer [19078,19097]
===
match
---
operator: -> [4566,4568]
operator: -> [4566,4568]
===
match
---
param [9018,9033]
param [9018,9033]
===
match
---
name: traceback [11198,11207]
name: traceback [11198,11207]
===
match
---
name: _execute_in_subprocess [4475,4497]
name: _execute_in_subprocess [4475,4497]
===
match
---
name: celery_task_id [4156,4170]
name: celery_task_id [4156,4170]
===
match
---
name: send_task_to_executor [12700,12721]
name: send_task_to_executor [12700,12721]
===
match
---
name: state [16043,16048]
name: state [16140,16145]
===
match
---
name: Any [16061,16064]
name: Any [16158,16161]
===
match
---
suite [6069,6215]
suite [6069,6215]
===
match
---
trailer [2687,2697]
trailer [2687,2697]
===
match
---
name: __name__ [2276,2284]
name: __name__ [2276,2284]
===
match
---
name: settings [1645,1653]
name: settings [1645,1653]
===
match
---
atom_expr [7955,7995]
atom_expr [7955,7995]
===
match
---
simple_stmt [5981,6043]
simple_stmt [5981,6043]
===
match
---
trailer [19068,19075]
trailer [19165,19172]
===
match
---
trailer [19040,19051]
trailer [19137,19148]
===
match
---
suite [13643,13793]
suite [13740,13890]
===
match
---
simple_stmt [3254,3310]
simple_stmt [3254,3310]
===
match
---
operator: = [10082,10083]
operator: = [10082,10083]
===
match
---
operator: , [9482,9483]
operator: , [9482,9483]
===
match
---
comparison [16149,16179]
comparison [16246,16276]
===
match
---
name: self [14967,14971]
name: self [15064,15068]
===
match
---
name: key [6227,6230]
name: key [6227,6230]
===
match
---
name: key [14699,14702]
name: key [14796,14799]
===
match
---
operator: = [11339,11340]
operator: = [11339,11340]
===
match
---
trailer [4754,4761]
trailer [4754,4761]
===
match
---
name: task_results [23543,23555]
name: task_results [23640,23652]
===
match
---
trailer [3344,3377]
trailer [3344,3377]
===
match
---
name: log [8568,8571]
name: log [8568,8571]
===
match
---
name: self [8431,8435]
name: self [8431,8435]
===
match
---
name: Set [1254,1257]
name: Set [1254,1257]
===
match
---
trailer [16994,16997]
trailer [17091,17094]
===
match
---
simple_stmt [2209,2251]
simple_stmt [2209,2251]
===
match
---
trailer [21116,21124]
trailer [21213,21221]
===
match
---
suite [21638,21716]
suite [21735,21813]
===
match
---
trailer [24442,24460]
trailer [24539,24557]
===
match
---
name: task_tuples_to_send [12001,12020]
name: task_tuples_to_send [12001,12020]
===
match
---
atom_expr [19652,19658]
atom_expr [19749,19755]
===
match
---
atom_expr [14760,14772]
atom_expr [14857,14869]
===
match
---
simple_stmt [8205,8345]
simple_stmt [8205,8345]
===
match
---
argument [9863,9896]
argument [9863,9896]
===
match
---
name: ExceptionWithTraceback [21126,21148]
name: ExceptionWithTraceback [21223,21245]
===
match
---
name: READY_STATES [16921,16933]
name: READY_STATES [17018,17030]
===
match
---
trailer [10473,10477]
trailer [10473,10477]
===
match
---
try_stmt [3768,4469]
try_stmt [3768,4469]
===
match
---
trailer [15870,15872]
trailer [15967,15969]
===
match
---
operator: { [23487,23488]
operator: { [23584,23585]
===
match
---
name: AirflowException [3643,3659]
name: AirflowException [3643,3659]
===
match
---
import_from [3717,3750]
import_from [3717,3750]
===
match
---
subscriptlist [22507,22532]
subscriptlist [22604,22629]
===
match
---
trailer [10970,10983]
trailer [10970,10983]
===
match
---
arglist [10654,10846]
arglist [10654,10846]
===
match
---
arglist [22940,22973]
arglist [23037,23070]
===
match
---
suite [23273,23363]
suite [23370,23460]
===
match
---
atom_expr [4917,4936]
atom_expr [4917,4936]
===
match
---
name: self [7753,7757]
name: self [7753,7757]
===
match
---
operator: = [8181,8182]
operator: = [8181,8182]
===
match
---
trailer [17301,17344]
trailer [17398,17441]
===
match
---
comp_op [9578,9584]
comp_op [9578,9584]
===
match
---
name: pop [11031,11034]
name: pop [11031,11034]
===
match
---
operator: , [5767,5768]
operator: , [5767,5768]
===
match
---
name: environ [4588,4595]
name: environ [4588,4595]
===
match
---
simple_stmt [18574,18592]
simple_stmt [18671,18689]
===
match
---
simple_stmt [19672,19716]
simple_stmt [19769,19813]
===
match
---
name: EventBufferValueType [24369,24389]
name: EventBufferValueType [24466,24486]
===
match
---
atom_expr [5016,5037]
atom_expr [5016,5037]
===
match
---
tfpdef [15803,15823]
tfpdef [15900,15920]
===
match
---
simple_stmt [15865,15904]
simple_stmt [15962,16001]
===
match
---
name: celery [1479,1485]
name: celery [1479,1485]
===
match
---
expr_stmt [9263,9315]
expr_stmt [9263,9315]
===
match
---
return_stmt [6220,6247]
return_stmt [6220,6247]
===
match
---
trailer [24495,24520]
trailer [24592,24617]
===
match
---
trailer [14364,14369]
trailer [14461,14466]
===
match
---
trailer [5032,5037]
trailer [5032,5037]
===
match
---
name: connect [6273,6280]
name: connect [6273,6280]
===
match
---
trailer [3856,3864]
trailer [3856,3864]
===
match
---
name: state [16673,16678]
name: state [16770,16775]
===
match
---
name: self [5356,5360]
name: self [5356,5360]
===
match
---
name: len [24418,24421]
name: len [24515,24518]
===
match
---
operator: , [2508,2509]
operator: , [2508,2509]
===
match
---
expr_stmt [23286,23362]
expr_stmt [23383,23459]
===
match
---
parameters [16800,16833]
parameters [16897,16930]
===
match
---
trailer [3153,3190]
trailer [3153,3190]
===
match
---
atom_expr [23194,23234]
atom_expr [23291,23331]
===
match
---
trailer [19868,19992]
trailer [19965,20089]
===
match
---
import_from [1728,1766]
import_from [1728,1766]
===
match
---
name: Union [5782,5787]
name: Union [5782,5787]
===
match
---
operator: = [9422,9423]
operator: = [9422,9423]
===
match
---
trailer [11030,11034]
trailer [11030,11034]
===
match
---
name: task_result [23488,23499]
name: task_result [23585,23596]
===
match
---
name: self [23572,23576]
name: self [23669,23673]
===
match
---
operator: = [19142,19143]
operator: = [19239,19240]
===
match
---
name: error [25066,25071]
name: error [25163,25168]
===
match
---
funcdef [8666,8989]
funcdef [8666,8989]
===
match
---
operator: = [24014,24015]
operator: = [24111,24112]
===
match
---
subscriptlist [23773,23798]
subscriptlist [23870,23895]
===
match
---
operator: + [25125,25126]
operator: + [25222,25223]
===
match
---
simple_stmt [3756,3764]
simple_stmt [3756,3764]
===
match
---
name: EventBufferValueType [1906,1926]
name: EventBufferValueType [1906,1926]
===
match
---
operator: , [5360,5361]
operator: , [5360,5361]
===
match
---
expr_stmt [18713,18795]
expr_stmt [18810,18892]
===
match
---
name: result [6159,6165]
name: result [6159,6165]
===
match
---
expr_stmt [19120,19188]
expr_stmt [19217,19285]
===
match
---
operator: { [19745,19746]
operator: { [19842,19843]
===
match
---
atom_expr [12022,12048]
atom_expr [12022,12048]
===
match
---
simple_stmt [4316,4368]
simple_stmt [4316,4368]
===
match
---
operator: = [15841,15842]
operator: = [15938,15939]
===
match
---
trailer [7876,7894]
trailer [7876,7894]
===
match
---
dotted_name [2034,2065]
dotted_name [2034,2065]
===
match
---
argument [24496,24519]
argument [24593,24616]
===
match
---
simple_stmt [8112,8197]
simple_stmt [8112,8197]
===
match
---
name: exception_traceback [6078,6097]
name: exception_traceback [6078,6097]
===
match
---
name: task_tuples_to_send [9728,9747]
name: task_tuples_to_send [9728,9747]
===
match
---
name: import_modules [1539,1553]
name: import_modules [1539,1553]
===
match
---
name: CommandType [3418,3429]
name: CommandType [3418,3429]
===
match
---
atom_expr [24356,24390]
atom_expr [24453,24487]
===
match
---
name: num_processes [12483,12496]
name: num_processes [12483,12496]
===
match
---
atom_expr [14963,14978]
atom_expr [15060,15075]
===
match
---
operator: , [16019,16020]
operator: , [16116,16117]
===
match
---
name: base_executor [1858,1871]
name: base_executor [1858,1871]
===
match
---
string: 'celery' [2479,2487]
string: 'celery' [2479,2487]
===
match
---
name: hasattr [20866,20873]
name: hasattr [20963,20970]
===
match
---
argument [4763,4777]
argument [4763,4777]
===
match
---
operator: } [8018,8019]
operator: } [8018,8019]
===
match
---
operator: = [2463,2464]
operator: = [2463,2464]
===
match
---
expr_stmt [23913,23963]
expr_stmt [24010,24060]
===
match
---
if_stmt [13620,13793]
if_stmt [13717,13890]
===
match
---
trailer [8242,8252]
trailer [8242,8252]
===
match
---
operator: , [21172,21173]
operator: , [21269,21270]
===
match
---
parameters [21846,21867]
parameters [21943,21964]
===
match
---
name: ti [19652,19654]
name: ti [19749,19751]
===
match
---
name: TaskInstanceKey [5752,5767]
name: TaskInstanceKey [5752,5767]
===
match
---
name: celery_tasks [19294,19306]
name: celery_tasks [19391,19403]
===
match
---
except_clause [4792,4833]
except_clause [4792,4833]
===
match
---
trailer [18728,18749]
trailer [18825,18846]
===
match
---
name: info [16215,16219]
name: info [16312,16316]
===
match
---
name: TaskInstance [17434,17446]
name: TaskInstance [17531,17543]
===
match
---
import_name [1011,1028]
import_name [1011,1028]
===
match
---
trailer [10983,10987]
trailer [10983,10987]
===
match
---
arglist [19032,19077]
arglist [19129,19174]
===
match
---
name: _sync_parallelism [12534,12551]
name: _sync_parallelism [12534,12551]
===
match
---
name: result [22435,22441]
name: result [22532,22538]
===
match
---
arglist [15353,15405]
arglist [15450,15502]
===
match
---
name: send_pool [12686,12695]
name: send_pool [12686,12695]
===
match
---
name: python [6818,6824]
name: python [6818,6824]
===
match
---
name: ext [6671,6674]
name: ext [6671,6674]
===
match
---
name: v [22760,22761]
name: v [22857,22858]
===
match
---
name: tasks [8009,8014]
name: tasks [8009,8014]
===
match
---
atom_expr [10486,10515]
atom_expr [10486,10515]
===
match
---
trailer [3890,3898]
trailer [3890,3898]
===
match
---
param [17094,17115]
param [17191,17212]
===
match
---
trailer [2275,2285]
trailer [2275,2285]
===
match
---
arglist [8924,8987]
arglist [8924,8987]
===
match
---
import_from [1145,1182]
import_from [1145,1182]
===
match
---
name: datetime [8162,8170]
name: datetime [8162,8170]
===
match
---
suite [2655,2733]
suite [2655,2733]
===
match
---
operator: , [20130,20131]
operator: , [20227,20228]
===
match
---
import_name [942,957]
import_name [942,957]
===
match
---
atom_expr [5653,5666]
atom_expr [5653,5666]
===
match
---
string: 'task_adoption_timeout' [8296,8319]
string: 'task_adoption_timeout' [8296,8319]
===
match
---
simple_stmt [9708,9749]
simple_stmt [9708,9749]
===
match
---
suite [17471,20025]
suite [17568,20122]
===
match
---
name: backends [1342,1350]
name: backends [1342,1350]
===
match
---
not_test [24069,24101]
not_test [24166,24198]
===
match
---
tfpdef [17094,17114]
tfpdef [17191,17211]
===
match
---
string: """         Overwrite trigger_tasks function from BaseExecutor          :param open_slots: Number of open slots         :return:         """ [9052,9192]
string: """         Overwrite trigger_tasks function from BaseExecutor          :param open_slots: Number of open slots         :return:         """ [9052,9192]
===
match
---
operator: = [8461,8462]
operator: = [8461,8462]
===
match
---
name: conf [2604,2608]
name: conf [2604,2608]
===
match
---
name: key [11914,11917]
name: key [11914,11917]
===
match
---
name: ti [18660,18662]
name: ti [18757,18759]
===
match
---
atom_expr [21064,21086]
atom_expr [21161,21183]
===
match
---
operator: , [16213,16214]
operator: , [16310,16311]
===
match
---
name: query [23302,23307]
name: query [23399,23404]
===
match
---
name: kwargs [6319,6325]
name: kwargs [6319,6325]
===
match
---
operator: , [23776,23777]
operator: , [23873,23874]
===
match
---
name: ti [18726,18728]
name: ti [18823,18825]
===
match
---
name: exception [25183,25192]
name: exception [25280,25289]
===
match
---
name: utcnow [13501,13507]
name: utcnow [13501,13507]
===
match
---
simple_stmt [23076,23129]
simple_stmt [23173,23226]
===
match
---
name: key [16210,16213]
name: key [16307,16310]
===
match
---
exprlist [24897,24930]
exprlist [24994,25027]
===
match
---
name: key [11035,11038]
name: key [11035,11038]
===
match
---
name: conf [2802,2806]
name: conf [2802,2806]
===
match
---
operator: = [4380,4381]
operator: = [4380,4381]
===
match
---
name: airflow [6701,6708]
name: airflow [6701,6708]
===
match
---
name: next [19144,19148]
name: next [19241,19245]
===
match
---
number: 1 [24563,24564]
number: 1 [24660,24661]
===
match
---
string: "\n\t" [14624,14630]
string: "\n\t" [14721,14727]
===
match
---
trailer [24421,24436]
trailer [24518,24533]
===
match
---
name: taskinstance [1947,1959]
name: taskinstance [1947,1959]
===
match
---
name: self [10966,10970]
name: self [10966,10970]
===
match
---
name: max_workers [24496,24507]
name: max_workers [24593,24604]
===
match
---
name: timedout_keys [13519,13532]
name: timedout_keys [13622,13635]
===
match
---
and_test [10243,10368]
and_test [10243,10368]
===
match
---
expr_stmt [4376,4383]
expr_stmt [4376,4383]
===
match
---
name: info [24054,24058]
name: info [24151,24155]
===
match
---
atom_expr [10448,10482]
atom_expr [10448,10482]
===
match
---
name: task_tuple [9547,9557]
name: task_tuple [9547,9557]
===
match
---
simple_stmt [3096,3141]
simple_stmt [3096,3141]
===
match
---
operator: , [3429,3430]
operator: , [3429,3430]
===
match
---
name: str [20091,20094]
name: str [20188,20191]
===
match
---
simple_stmt [15513,15552]
simple_stmt [15610,15649]
===
match
---
name: self [24438,24442]
name: self [24535,24539]
===
match
---
name: __init__ [21600,21608]
name: __init__ [21697,21705]
===
match
---
if_stmt [3196,3378]
if_stmt [3196,3378]
===
match
---
dotted_name [1335,1355]
dotted_name [1335,1355]
===
match
---
trailer [12695,12699]
trailer [12695,12699]
===
match
---
name: info [20838,20842]
name: info [20935,20939]
===
match
---
simple_stmt [10140,10174]
simple_stmt [10140,10174]
===
match
---
decorator [6250,6281]
decorator [6250,6281]
===
match
---
trailer [22696,22702]
trailer [22793,22799]
===
match
---
dotted_name [6800,6824]
dotted_name [6800,6824]
===
match
---
trailer [19306,19322]
trailer [19403,19419]
===
match
---
name: config_templates [1667,1683]
name: config_templates [1667,1683]
===
match
---
name: tasks [19600,19605]
name: tasks [19697,19702]
===
match
---
operator: , [16666,16667]
operator: , [16763,16764]
===
match
---
simple_stmt [19281,19323]
simple_stmt [19378,19420]
===
match
---
name: celery_configuration [2743,2763]
name: celery_configuration [2743,2763]
===
match
---
operator: , [3583,3584]
operator: , [3583,3584]
===
match
---
suite [16842,17018]
suite [16939,17115]
===
match
---
name: AirflowTaskTimeout [10336,10354]
name: AirflowTaskTimeout [10336,10354]
===
match
---
atom_expr [15170,15228]
atom_expr [15267,15325]
===
match
---
tfpdef [16043,16053]
tfpdef [16140,16150]
===
match
---
trailer [17433,17447]
trailer [17530,17544]
===
match
---
trailer [4463,4468]
trailer [4463,4468]
===
match
---
parameters [12829,12835]
parameters [12829,12835]
===
match
---
dictorsetmaker [23488,23555]
dictorsetmaker [23585,23652]
===
match
---
atom_expr [12567,12613]
atom_expr [12567,12613]
===
match
---
name: __init__ [5347,5355]
name: __init__ [5347,5355]
===
match
---
atom_expr [14992,15021]
atom_expr [15089,15118]
===
match
---
suite [4834,5038]
suite [4834,5038]
===
match
---
trailer [19859,19863]
trailer [19956,19960]
===
match
---
name: state [16349,16354]
name: state [16446,16451]
===
match
---
if_stmt [16851,16998]
if_stmt [16948,17095]
===
match
---
name: info [24207,24211]
name: info [24304,24308]
===
match
---
operator: { [6125,6126]
operator: { [6125,6126]
===
match
---
trailer [3034,3039]
trailer [3034,3039]
===
match
---
trailer [3579,3587]
trailer [3579,3587]
===
match
---
trailer [18725,18750]
trailer [18822,18847]
===
match
---
import_name [6694,6728]
import_name [6694,6728]
===
match
---
dotted_name [1733,1754]
dotted_name [1733,1754]
===
match
---
name: x [14648,14649]
name: x [14745,14746]
===
match
---
trailer [9727,9748]
trailer [9727,9748]
===
match
---
simple_stmt [11379,11401]
simple_stmt [11379,11401]
===
match
---
name: Exception [5373,5382]
name: Exception [5373,5382]
===
match
---
name: task_results_by_task_id [22950,22973]
name: task_results_by_task_id [23047,23070]
===
match
---
operator: , [1264,1265]
operator: , [1264,1265]
===
match
---
fstring_start: f" [4193,4195]
fstring_start: f" [4193,4195]
===
match
---
sync_comp_for [14644,14666]
sync_comp_for [14741,14763]
===
match
---
operator: = [16825,16826]
operator: = [16922,16923]
===
match
---
string: "task_id" [23500,23509]
string: "task_id" [23597,23606]
===
match
---
trailer [12864,12870]
trailer [12864,12870]
===
match
---
operator: = [9311,9312]
operator: = [9311,9312]
===
match
---
import_as_names [1425,1473]
import_as_names [1425,1473]
===
match
---
name: Any [1202,1205]
name: Any [1202,1205]
===
match
---
simple_stmt [22786,22882]
simple_stmt [22883,22979]
===
match
---
trailer [17186,17191]
trailer [17283,17288]
===
match
---
name: session_cleanup [23248,23263]
name: session_cleanup [23345,23360]
===
match
---
operator: - [7916,7917]
operator: - [7916,7917]
===
match
---
trailer [12222,12271]
trailer [12222,12271]
===
match
---
operator: = [23925,23926]
operator: = [24022,24023]
===
match
---
operator: } [19748,19749]
operator: } [19845,19846]
===
match
---
name: signals [1524,1531]
name: signals [1524,1531]
===
match
---
suite [16180,16221]
suite [16277,16318]
===
match
---
operator: = [24059,24060]
operator: = [24156,24157]
===
match
---
atom_expr [15637,15695]
atom_expr [15734,15792]
===
match
---
trailer [23091,23115]
trailer [23188,23212]
===
match
---
name: get_many [15474,15482]
name: get_many [15571,15579]
===
match
---
tfpdef [16055,16064]
tfpdef [16152,16161]
===
match
---
argument [5941,5966]
argument [5941,5966]
===
match
---
name: max [8920,8923]
name: max [8920,8923]
===
match
---
file_input [787,25417]
file_input [787,25514]
===
match
---
atom_expr [15734,15774]
atom_expr [15831,15871]
===
match
---
name: self [19635,19639]
name: self [19732,19736]
===
match
---
suite [21218,25417]
suite [21315,25514]
===
match
---
name: state_info [23809,23819]
name: state_info [23906,23916]
===
match
---
operator: = [13533,13534]
operator: = [13636,13637]
===
match
---
name: ResultSession [23159,23172]
name: ResultSession [23256,23269]
===
match
---
dotted_as_name [1625,1653]
dotted_as_name [1625,1653]
===
match
---
comp_if [22772,22776]
comp_if [22869,22873]
===
match
---
operator: = [21027,21028]
operator: = [21124,21125]
===
match
---
name: e [6067,6068]
name: e [6067,6068]
===
match
---
tfpdef [5384,5408]
tfpdef [5384,5408]
===
match
---
name: celery_states [24169,24182]
name: celery_states [24266,24279]
===
match
---
operator: , [14758,14759]
operator: , [14855,14856]
===
match
---
name: task_publish_retries [10453,10473]
name: task_publish_retries [10453,10473]
===
match
---
atom_expr [5782,5824]
atom_expr [5782,5824]
===
match
---
atom_expr [15912,15937]
atom_expr [16009,16034]
===
match
---
suite [14396,14774]
suite [14493,14871]
===
match
---
param [5362,5383]
param [5362,5383]
===
match
---
trailer [19031,19078]
trailer [19128,19175]
===
match
---
name: CommandType [1893,1904]
name: CommandType [1893,1904]
===
match
---
import_name [6829,6860]
import_name [6829,6860]
===
match
---
atom_expr [21771,21779]
atom_expr [21868,21876]
===
match
---
name: queue [9484,9489]
name: queue [9484,9489]
===
match
---
import_as_names [1202,1271]
import_as_names [1202,1271]
===
match
---
suite [3319,3378]
suite [3319,3378]
===
match
---
name: output [4929,4935]
name: output [4929,4935]
===
match
---
testlist_star_expr [9394,9421]
testlist_star_expr [9394,9421]
===
match
---
name: exceptions [1780,1790]
name: exceptions [1780,1790]
===
match
---
operator: } [6148,6149]
operator: } [6148,6149]
===
match
---
operator: = [4081,4082]
operator: = [4081,4082]
===
match
---
name: states [1306,1312]
name: states [1306,1312]
===
match
---
name: map [14992,14995]
name: map [15089,15092]
===
match
---
simple_stmt [23286,23363]
simple_stmt [23383,23460]
===
match
---
operator: , [11774,11775]
operator: , [11774,11775]
===
match
---
expr_stmt [5454,5490]
expr_stmt [5454,5490]
===
match
---
simple_stmt [1927,1997]
simple_stmt [1927,1997]
===
match
---
arglist [7790,7818]
arglist [7790,7818]
===
match
---
name: v [22753,22754]
name: v [22850,22851]
===
match
---
name: airflow [2002,2009]
name: airflow [2002,2009]
===
match
---
simple_stmt [4128,4171]
simple_stmt [4128,4171]
===
match
---
trailer [3844,3851]
trailer [3844,3851]
===
match
---
operator: = [18975,18976]
operator: = [19072,19073]
===
match
---
dotted_name [6251,6280]
dotted_name [6251,6280]
===
match
---
operator: , [10334,10335]
operator: , [10334,10335]
===
match
---
operator: = [5988,5989]
operator: = [5988,5989]
===
match
---
name: adopted [19099,19106]
name: adopted [19196,19203]
===
match
---
trailer [9220,9251]
trailer [9220,9251]
===
match
---
simple_stmt [1654,1728]
simple_stmt [1654,1728]
===
match
---
name: self [9628,9632]
name: self [9628,9632]
===
match
---
expr_stmt [7872,7920]
expr_stmt [7872,7920]
===
match
---
arglist [3580,3586]
arglist [3580,3586]
===
match
---
trailer [24686,24792]
trailer [24783,24889]
===
match
---
arglist [3040,3090]
arglist [3040,3090]
===
match
---
atom_expr [22554,22595]
atom_expr [22651,22692]
===
match
---
fstring_string: \n [6123,6125]
fstring_string: \n [6123,6125]
===
match
---
trailer [15454,15473]
trailer [15551,15570]
===
match
---
import_from [2167,2208]
import_from [2167,2208]
===
match
---
simple_stmt [8004,8020]
simple_stmt [8004,8020]
===
match
---
name: self [12968,12972]
name: self [12968,12972]
===
match
---
name: ret [4464,4467]
name: ret [4464,4467]
===
match
---
fstring_expr [3172,3188]
fstring_expr [3172,3188]
===
match
---
string: "Error syncing the Celery executor, ignoring it." [16737,16786]
string: "Error syncing the Celery executor, ignoring it." [16834,16883]
===
match
---
name: BaseExecutor [2980,2992]
name: BaseExecutor [2980,2992]
===
match
---
simple_stmt [985,1001]
simple_stmt [985,1001]
===
match
---
name: celery_tasks [18873,18885]
name: celery_tasks [18970,18982]
===
match
---
name: states_by_celery_task_id [19235,19259]
name: states_by_celery_task_id [19332,19356]
===
match
---
atom_expr [24107,24126]
atom_expr [24204,24223]
===
match
---
simple_stmt [11891,11964]
simple_stmt [11891,11964]
===
match
---
trailer [22730,22738]
trailer [22827,22835]
===
match
---
trailer [15738,15756]
trailer [15835,15853]
===
match
---
name: get_hostname [4987,4999]
name: get_hostname [4987,4999]
===
match
---
with_item [12567,12626]
with_item [12567,12626]
===
match
---
param [9012,9017]
param [9012,9017]
===
match
---
trailer [10490,10515]
trailer [10490,10515]
===
match
---
return_stmt [8913,8988]
return_stmt [8913,8988]
===
match
---
trailer [16636,16679]
trailer [16733,16776]
===
match
---
name: logging [2258,2265]
name: logging [2258,2265]
===
match
---
trailer [3929,3931]
trailer [3929,3931]
===
match
---
with_item [24476,24533]
with_item [24573,24630]
===
match
---
operator: , [21150,21151]
operator: , [21247,21248]
===
match
---
simple_stmt [19502,19583]
simple_stmt [19599,19680]
===
match
---
operator: , [15760,15761]
operator: , [15857,15858]
===
match
---
string: """         See if any of the tasks we adopted from another Executor run have not         progressed after the configured timeout.          If they haven't, they likely never made it to Celery, and we should         just resend them. We do that by clearing the state and letting the         normal scheduler loop deal with that         """ [13147,13486]
string: """         See if any of the tasks we adopted from another Executor run have not         progressed after the configured timeout.          If they haven't, they likely never made it to Celery, and we should         just resend them. We do that by clearing the state and letting the         normal scheduler loop deal with that         """ [13147,13486]
===
match
---
name: info [24260,24264]
name: info [24357,24361]
===
match
---
suite [7468,8525]
suite [7468,8525]
===
match
---
simple_stmt [18930,18941]
simple_stmt [19027,19038]
===
match
---
string: 'operation_timeout' [2489,2508]
string: 'operation_timeout' [2489,2508]
===
match
---
trailer [10144,10148]
trailer [10144,10148]
===
match
---
name: info [16326,16330]
name: info [16423,16427]
===
match
---
atom_expr [7831,7853]
atom_expr [7831,7853]
===
match
---
trailer [23835,23862]
trailer [23932,23959]
===
match
---
name: task_result [23512,23523]
name: task_result [23609,23620]
===
match
---
trailer [2619,2654]
trailer [2619,2654]
===
match
---
subscriptlist [21879,21904]
subscriptlist [21976,22001]
===
match
---
trailer [15521,15527]
trailer [15618,15624]
===
match
---
name: _sync_parallelism [21679,21696]
name: _sync_parallelism [21776,21793]
===
match
---
arglist [12700,12763]
arglist [12700,12763]
===
match
---
trailer [14423,14682]
trailer [14520,14779]
===
match
---
operator: , [15111,15112]
operator: , [15208,15209]
===
match
---
name: _send_tasks_to_celery [11973,11994]
name: _send_tasks_to_celery [11973,11994]
===
match
---
name: async_result [15674,15686]
name: async_result [15771,15783]
===
match
---
atom_expr [22071,22116]
atom_expr [22168,22213]
===
match
---
simple_stmt [942,958]
simple_stmt [942,958]
===
match
---
trailer [22348,22419]
trailer [22445,22516]
===
match
---
operator: { [24878,24879]
operator: { [24975,24976]
===
match
---
atom_expr [11379,11400]
atom_expr [11379,11400]
===
match
---
name: ExceptionWithTraceback [20107,20129]
name: ExceptionWithTraceback [20204,20226]
===
match
---
param [21853,21866]
param [21950,21963]
===
match
---
name: celery [1278,1284]
name: celery [1278,1284]
===
match
---
name: self [13572,13576]
name: self [13557,13561]
===
match
---
simple_stmt [14907,15033]
simple_stmt [15004,15130]
===
match
---
atom_expr [3875,3900]
atom_expr [3875,3900]
===
match
---
atom_expr [17429,17447]
atom_expr [17526,17544]
===
match
---
name: celery_task_id [4664,4678]
name: celery_task_id [4664,4678]
===
match
---
name: ret [4273,4276]
name: ret [4273,4276]
===
match
---
funcdef [15245,15775]
funcdef [15342,15872]
===
match
---
name: TaskInstanceInCelery [5719,5739]
name: TaskInstanceInCelery [5719,5739]
===
match
---
atom_expr [24559,24639]
atom_expr [24656,24736]
===
match
---
trailer [24027,24037]
trailer [24124,24134]
===
match
---
simple_stmt [21915,21988]
simple_stmt [22012,22085]
===
match
---
name: cli_parser [3798,3808]
name: cli_parser [3798,3808]
===
match
---
name: self [17050,17054]
name: self [17147,17151]
===
match
---
name: _prepare_state_and_info_by_task_dict [23577,23613]
name: _prepare_state_and_info_by_task_dict [23674,23710]
===
match
---
name: self [17418,17422]
name: self [17515,17519]
===
match
---
operator: = [9659,9660]
operator: = [9659,9660]
===
match
---
name: queue [5879,5884]
name: queue [5879,5884]
===
match
---
arglist [15068,15229]
arglist [15165,15326]
===
match
---
tfpdef [16807,16824]
tfpdef [16904,16921]
===
match
---
expr_stmt [5419,5445]
expr_stmt [5419,5445]
===
match
---
arglist [15757,15773]
arglist [15854,15870]
===
match
---
operator: , [9777,9778]
operator: , [9777,9778]
===
match
---
name: traceback [21064,21073]
name: traceback [21161,21170]
===
match
---
name: DEFAULT_CELERY_CONFIG [2766,2787]
name: DEFAULT_CELERY_CONFIG [2766,2787]
===
match
---
expr_stmt [8353,8422]
expr_stmt [8353,8422]
===
match
---
name: info [24926,24930]
name: info [25023,25027]
===
match
---
trailer [22691,22696]
trailer [22788,22793]
===
match
---
name: values [22671,22677]
name: values [22768,22774]
===
match
---
operator: = [4558,4559]
operator: = [4558,4559]
===
match
---
simple_stmt [2980,3027]
simple_stmt [2980,3027]
===
match
---
trailer [8641,8659]
trailer [8641,8659]
===
match
---
expr_stmt [6159,6214]
expr_stmt [6159,6214]
===
match
---
dotted_name [1932,1959]
dotted_name [1932,1959]
===
match
---
operator: , [1298,1299]
operator: , [1298,1299]
===
match
---
name: backend [23206,23213]
name: backend [23303,23310]
===
match
---
atom_expr [15585,15609]
atom_expr [15682,15706]
===
match
---
name: state [15825,15830]
name: state [15922,15927]
===
match
---
if_stmt [21996,22326]
if_stmt [22093,22423]
===
match
---
name: adopted [19951,19958]
name: adopted [20048,20055]
===
match
---
return_stmt [21789,21828]
return_stmt [21886,21925]
===
match
---
name: state_and_info_by_celery_task_id [15415,15447]
name: state_and_info_by_celery_task_id [15512,15544]
===
match
---
fstring_start: f" [6100,6102]
fstring_start: f" [6100,6102]
===
match
---
trailer [14911,14915]
trailer [15008,15012]
===
match
---
name: command_to_exec [4029,4044]
name: command_to_exec [4029,4044]
===
match
---
atom_expr [8563,8660]
atom_expr [8563,8660]
===
match
---
simple_stmt [14344,14370]
simple_stmt [14441,14467]
===
match
---
simple_stmt [23137,23175]
simple_stmt [23234,23272]
===
match
---
arglist [8578,8659]
arglist [8578,8659]
===
match
---
operator: , [15388,15389]
operator: , [15485,15486]
===
match
---
name: sync_pool [24524,24533]
name: sync_pool [24621,24630]
===
match
---
atom [11250,11270]
atom [11250,11270]
===
match
---
testlist_star_expr [3558,3566]
testlist_star_expr [3558,3566]
===
match
---
exprlist [13550,13568]
exprlist [13653,13671]
===
match
---
atom_expr [4360,4366]
atom_expr [4360,4366]
===
match
---
name: fetch_celery_task_state [20031,20054]
name: fetch_celery_task_state [20128,20151]
===
match
---
funcdef [15780,15988]
funcdef [15877,16085]
===
match
---
trailer [7971,7995]
trailer [7971,7995]
===
match
---
arglist [2811,2838]
arglist [2811,2838]
===
match
---
atom_expr [14344,14369]
atom_expr [14441,14466]
===
match
---
arglist [2620,2653]
arglist [2620,2653]
===
match
---
simple_stmt [6975,7014]
simple_stmt [6975,7014]
===
match
---
name: self [15734,15738]
name: self [15831,15835]
===
match
---
simple_stmt [1029,1041]
simple_stmt [1029,1041]
===
match
---
name: operators [6844,6853]
name: operators [6844,6853]
===
match
---
comparison [16889,16933]
comparison [16986,17030]
===
match
---
trailer [19654,19658]
trailer [19751,19755]
===
match
---
name: State [11762,11767]
name: State [11762,11767]
===
match
---
name: repr [15186,15190]
name: repr [15283,15287]
===
match
---
name: tasks [14972,14977]
name: tasks [15069,15074]
===
match
---
trailer [3276,3309]
trailer [3276,3309]
===
match
---
operator: , [21124,21125]
operator: , [21221,21222]
===
match
---
trailer [11782,11790]
trailer [11782,11790]
===
match
---
name: command [6232,6239]
name: command [6232,6239]
===
match
---
atom_expr [4405,4419]
atom_expr [4405,4419]
===
match
---
subscriptlist [23040,23065]
subscriptlist [23137,23162]
===
match
---
simple_stmt [1767,1835]
simple_stmt [1767,1835]
===
match
---
number: 1 [9661,9662]
number: 1 [9661,9662]
===
match
---
suite [14808,15240]
suite [14905,15337]
===
match
---
name: update_task_state [15739,15756]
name: update_task_state [15836,15853]
===
match
---
name: self [21609,21613]
name: self [21706,21710]
===
match
---
atom_expr [9340,9379]
atom_expr [9340,9379]
===
match
---
operator: == [12118,12120]
operator: == [12118,12120]
===
match
---
name: send_task_to_executor [12227,12248]
name: send_task_to_executor [12227,12248]
===
match
---
atom_expr [18830,18856]
atom_expr [18927,18953]
===
match
---
operator: , [10260,10261]
operator: , [10260,10261]
===
match
---
name: TaskInstanceInCelery [5594,5614]
name: TaskInstanceInCelery [5594,5614]
===
match
---
atom_expr [4428,4446]
atom_expr [4428,4446]
===
match
---
trailer [12533,12551]
trailer [12533,12551]
===
match
---
atom_expr [22141,22152]
atom_expr [22238,22249]
===
match
---
name: min [12499,12502]
name: min [12499,12502]
===
match
---
name: DEFAULT_CELERY_CONFIG [1706,1727]
name: DEFAULT_CELERY_CONFIG [1706,1727]
===
match
---
atom_expr [9858,9897]
atom_expr [9858,9897]
===
match
---
with_stmt [24471,25375]
with_stmt [24568,25472]
===
match
---
dotted_name [1099,1117]
dotted_name [1099,1117]
===
match
---
annassign [8378,8422]
annassign [8378,8422]
===
match
---
string: """     Wrapper class used to propagate exceptions to parent processes from subprocesses.      :param exception: The exception to wrap     :type exception: Exception     :param exception_traceback: The stacktrace to wrap     :type exception_traceback: str     """ [5074,5337]
string: """     Wrapper class used to propagate exceptions to parent processes from subprocesses.      :param exception: The exception to wrap     :type exception: Exception     :param exception_traceback: The stacktrace to wrap     :type exception_traceback: str     """ [5074,5337]
===
match
---
name: task_to_run [5886,5897]
name: task_to_run [5886,5897]
===
match
---
simple_stmt [16984,16998]
simple_stmt [17081,17095]
===
match
---
name: update_task_state [15997,16014]
name: update_task_state [16094,16111]
===
match
---
trailer [7933,7952]
trailer [7933,7952]
===
match
---
name: self [12830,12834]
name: self [12830,12834]
===
match
---
operator: , [12721,12722]
operator: , [12721,12722]
===
match
---
string: 'Starting Celery Executor using %s processes for syncing' [8578,8635]
string: 'Starting Celery Executor using %s processes for syncing' [8578,8635]
===
match
---
simple_stmt [10555,10595]
simple_stmt [10555,10595]
===
match
---
trailer [19051,19054]
trailer [19148,19151]
===
match
---
trailer [16627,16631]
trailer [16724,16728]
===
match
---
simple_stmt [15415,15504]
simple_stmt [15512,15601]
===
match
---
trailer [9436,9440]
trailer [9436,9440]
===
match
---
name: airflow [1625,1632]
name: airflow [1625,1632]
===
match
---
operator: == [16542,16544]
operator: == [16639,16641]
===
match
---
operator: = [7953,7954]
operator: = [7953,7954]
===
match
---
tfpdef [5362,5382]
tfpdef [5362,5382]
===
match
---
name: ti [19529,19531]
name: ti [19626,19628]
===
match
---
simple_stmt [4917,4937]
simple_stmt [4917,4937]
===
match
---
name: log [12889,12892]
name: log [12889,12892]
===
match
---
arglist [23202,23233]
arglist [23299,23330]
===
match
---
suite [16705,16788]
suite [16802,16885]
===
match
---
expr_stmt [22265,22325]
expr_stmt [22362,22422]
===
match
---
name: self [16197,16201]
name: self [16294,16298]
===
match
---
name: isinstance [10290,10300]
name: isinstance [10290,10300]
===
match
---
name: command [6020,6027]
name: command [6020,6027]
===
match
---
trailer [19541,19553]
trailer [19638,19650]
===
match
---
trailer [21073,21084]
trailer [21170,21181]
===
match
---
operator: } [3187,3188]
operator: } [3187,3188]
===
match
---
name: Tuple [5746,5751]
name: Tuple [5746,5751]
===
match
---
import_as_name [1539,1578]
import_as_name [1539,1578]
===
match
---
name: int [8402,8405]
name: int [8402,8405]
===
match
---
name: task_publish_retries [9590,9610]
name: task_publish_retries [9590,9610]
===
match
---
operator: , [8400,8401]
operator: , [8400,8401]
===
match
---
dotted_name [2880,2888]
dotted_name [2880,2888]
===
match
---
import_from [1330,1387]
import_from [1330,1387]
===
match
---
name: app [23202,23205]
name: app [23299,23302]
===
match
---
number: 1 [7918,7919]
number: 1 [7918,7919]
===
match
---
name: os [3569,3571]
name: os [3569,3571]
===
match
---
number: 1 [12090,12091]
number: 1 [12090,12091]
===
match
---
annassign [24832,24880]
annassign [24929,24977]
===
match
---
atom_expr [20096,20130]
atom_expr [20193,20227]
===
match
---
param [9773,9778]
param [9773,9778]
===
match
---
exprlist [10187,10201]
exprlist [10187,10201]
===
match
---
operator: , [5651,5652]
operator: , [5651,5652]
===
match
---
or_test [12062,12122]
or_test [12062,12122]
===
match
---
name: task_publish_retries [9633,9653]
name: task_publish_retries [9633,9653]
===
match
---
name: net [2105,2108]
name: net [2105,2108]
===
match
---
name: celery [1393,1399]
name: celery [1393,1399]
===
match
---
name: tasks [23446,23451]
name: tasks [23543,23548]
===
match
---
operator: , [22510,22511]
operator: , [22607,22608]
===
match
---
operator: , [8635,8636]
operator: , [8635,8636]
===
match
---
atom_expr [15129,15155]
atom_expr [15226,15252]
===
match
---
name: async_tasks [23016,23027]
name: async_tasks [23113,23124]
===
match
---
name: engine [3845,3851]
name: engine [3845,3851]
===
match
---
name: State [14760,14765]
name: State [14857,14862]
===
match
---
name: in_ [23342,23345]
name: in_ [23439,23442]
===
match
---
name: pid [3558,3561]
name: pid [3558,3561]
===
match
---
comp_op [18684,18690]
comp_op [18781,18787]
===
match
---
simple_stmt [4004,4050]
simple_stmt [4004,4050]
===
match
---
operator: , [1814,1815]
operator: , [1814,1815]
===
match
---
expr_stmt [19595,19622]
expr_stmt [19692,19719]
===
match
---
trailer [22390,22398]
trailer [22487,22495]
===
match
---
sync_comp_for [22849,22880]
sync_comp_for [22946,22977]
===
match
---
name: key [9574,9577]
name: key [9574,9577]
===
match
---
return_stmt [21097,21178]
return_stmt [21194,21275]
===
match
---
operator: , [23730,23731]
operator: , [23827,23828]
===
match
---
argument [12744,12763]
argument [12744,12763]
===
match
---
trailer [15950,15972]
trailer [16047,16069]
===
match
---
atom_expr [9800,9826]
atom_expr [9800,9826]
===
match
---
decorated [23654,24291]
decorated [23751,24388]
===
match
---
trailer [16201,16209]
trailer [16298,16306]
===
match
---
trailer [12502,12552]
trailer [12502,12552]
===
match
---
name: info [16632,16636]
name: info [16729,16733]
===
match
---
name: terminate [17354,17363]
name: terminate [17451,17460]
===
match
---
name: ProcessPoolExecutor [12567,12586]
name: ProcessPoolExecutor [12567,12586]
===
match
---
name: celery_task_id [3096,3110]
name: celery_task_id [3096,3110]
===
match
---
name: session [23294,23301]
name: session [23391,23398]
===
match
---
name: backend [22684,22691]
name: backend [22781,22788]
===
match
---
name: cached_celery_backend [19352,19373]
name: cached_celery_backend [19449,19470]
===
match
---
name: getimport [2688,2697]
name: getimport [2688,2697]
===
match
---
name: add [19648,19651]
name: add [19745,19748]
===
match
---
name: min [24414,24417]
name: min [24511,24514]
===
match
---
trailer [10623,10628]
trailer [10623,10628]
===
match
---
atom_expr [22274,22325]
atom_expr [22371,22422]
===
match
---
parameters [23009,23028]
parameters [23106,23125]
===
match
---
argument [16889,16965]
argument [16986,17062]
===
match
---
simple_stmt [8563,8661]
simple_stmt [8563,8661]
===
match
---
operator: , [17198,17199]
operator: , [17295,17296]
===
match
---
name: task_id [15687,15694]
name: task_id [15784,15791]
===
match
---
trailer [16320,16331]
trailer [16417,16428]
===
match
---
name: Tuple [5617,5622]
name: Tuple [5617,5622]
===
match
---
name: exception [16727,16736]
name: exception [16824,16833]
===
match
---
atom_expr [17452,17470]
atom_expr [17549,17567]
===
match
---
name: debug [22343,22348]
name: debug [22440,22445]
===
match
---
arglist [8475,8523]
arglist [8475,8523]
===
match
---
name: len [22387,22390]
name: len [22484,22487]
===
match
---
name: key [19609,19612]
name: key [19706,19709]
===
match
---
name: not_adopted_tis [20009,20024]
name: not_adopted_tis [20106,20121]
===
match
---
operator: , [14667,14668]
operator: , [14764,14765]
===
match
---
trailer [7493,7495]
trailer [7493,7495]
===
match
---
name: args [4259,4263]
name: args [4259,4263]
===
match
---
trailer [10756,10761]
trailer [10756,10761]
===
match
---
name: log [2252,2255]
name: log [2252,2255]
===
match
---
trailer [11740,11753]
trailer [11740,11753]
===
match
---
trailer [11119,11123]
trailer [11119,11123]
===
match
---
trailer [15045,15049]
trailer [15142,15146]
===
match
---
name: collections [1063,1074]
name: collections [1063,1074]
===
match
---
atom_expr [19635,19659]
atom_expr [19732,19756]
===
match
---
if_stmt [23976,24219]
if_stmt [24073,24316]
===
match
---
name: state_or_exception [24906,24924]
name: state_or_exception [25003,25021]
===
match
---
name: self [15946,15950]
name: self [16043,16047]
===
match
---
simple_stmt [16083,16121]
simple_stmt [16180,16218]
===
match
---
simple_stmt [11736,11792]
simple_stmt [11736,11792]
===
match
---
atom_expr [10889,10919]
atom_expr [10889,10919]
===
match
---
name: join [14631,14635]
name: join [14728,14732]
===
match
---
name: list [12218,12222]
name: list [12218,12222]
===
match
---
arglist [15927,15936]
arglist [16024,16033]
===
match
---
name: external_executor_id [18663,18683]
name: external_executor_id [18760,18780]
===
match
---
expr_stmt [2252,2285]
expr_stmt [2252,2285]
===
match
---
name: STARTED [16372,16379]
name: STARTED [16469,16476]
===
match
---
atom_expr [15946,15987]
atom_expr [16043,16084]
===
match
---
name: session_cleanup [1458,1473]
name: session_cleanup [1458,1473]
===
match
---
name: change_state [15873,15885]
name: change_state [15970,15982]
===
match
---
name: utils [2099,2104]
name: utils [2099,2104]
===
match
---
fstring_end: " [19766,19767]
fstring_end: " [19863,19864]
===
match
---
number: 0 [3585,3586]
number: 0 [3585,3586]
===
match
---
return_stmt [12787,12815]
return_stmt [12787,12815]
===
match
---
return_stmt [18930,18940]
return_stmt [19027,19037]
===
match
---
name: airflow [3722,3729]
name: airflow [3722,3729]
===
match
---
simple_stmt [9394,9444]
simple_stmt [9394,9444]
===
match
---
name: timedout_keys [14382,14395]
name: timedout_keys [14479,14492]
===
match
---
name: app [22727,22730]
name: app [22824,22827]
===
match
---
name: ret [3563,3566]
name: ret [3563,3566]
===
match
---
atom_expr [8004,8014]
atom_expr [8004,8014]
===
match
---
name: len [19947,19950]
name: len [20044,20047]
===
match
---
suite [16294,16332]
suite [16391,16429]
===
match
---
param [23722,23731]
param [23819,23828]
===
match
---
simple_stmt [23461,23557]
simple_stmt [23558,23654]
===
match
---
name: k [22648,22649]
name: k [22745,22746]
===
match
---
trailer [23417,23433]
trailer [23514,23530]
===
match
---
atom_expr [8963,8985]
atom_expr [8963,8985]
===
match
---
simple_stmt [11115,11209]
simple_stmt [11115,11209]
===
match
---
trailer [9364,9377]
trailer [9364,9377]
===
match
---
name: bool [16820,16824]
name: bool [16917,16921]
===
match
---
atom_expr [9284,9310]
atom_expr [9284,9310]
===
match
---
name: waitpid [3572,3579]
name: waitpid [3572,3579]
===
match
---
operator: = [19292,19293]
operator: = [19389,19390]
===
match
---
atom_expr [4058,4080]
atom_expr [4058,4080]
===
match
---
name: key [9470,9473]
name: key [9470,9473]
===
match
---
expr_stmt [5981,6042]
expr_stmt [5981,6042]
===
match
---
atom_expr [5617,5673]
atom_expr [5617,5673]
===
match
---
trailer [17456,17470]
trailer [17553,17567]
===
match
---
suite [18644,18857]
suite [18741,18954]
===
match
---
name: queued_dttm [19542,19553]
name: queued_dttm [19639,19650]
===
match
---
import_name [1618,1653]
import_name [1618,1653]
===
match
---
simple_stmt [20838,20906]
simple_stmt [20935,21003]
===
match
---
atom_expr [20866,20895]
atom_expr [20963,20992]
===
match
---
name: info [15898,15902]
name: info [15995,15999]
===
match
---
name: STDOUT [4755,4761]
name: STDOUT [4755,4761]
===
match
---
operator: , [25010,25011]
operator: , [25107,25108]
===
match
---
atom_expr [11055,11097]
atom_expr [11055,11097]
===
match
---
expr_stmt [4273,4280]
expr_stmt [4273,4280]
===
match
---
string: 'celery' [8286,8294]
string: 'celery' [8286,8294]
===
match
---
simple_stmt [15338,15407]
simple_stmt [15435,15504]
===
match
---
operator: } [19765,19766]
operator: } [19862,19863]
===
match
---
atom_expr [4799,4828]
atom_expr [4799,4828]
===
match
---
name: task_publish_max_retries [10792,10816]
name: task_publish_max_retries [10792,10816]
===
match
---
if_stmt [11052,11964]
if_stmt [11052,11964]
===
match
---
name: task_instance_str [19961,19978]
name: task_instance_str [20058,20075]
===
match
---
trailer [19000,19009]
trailer [19097,19106]
===
match
---
name: items [19260,19265]
name: items [19357,19362]
===
match
---
name: get_hostname [3696,3708]
name: get_hostname [3696,3708]
===
match
---
name: celery_configuration [2855,2875]
name: celery_configuration [2855,2875]
===
match
---
trailer [11391,11395]
trailer [11391,11395]
===
match
---
simple_stmt [6759,6789]
simple_stmt [6759,6789]
===
match
---
trailer [9653,9658]
trailer [9653,9658]
===
match
---
name: task_id [23955,23962]
name: task_id [24052,24059]
===
match
---
trailer [14995,15021]
trailer [15092,15118]
===
match
---
name: conf [2465,2469]
name: conf [2465,2469]
===
match
---
operator: = [4772,4773]
operator: = [4772,4773]
===
match
---
name: ExceptionWithTraceback [10262,10284]
name: ExceptionWithTraceback [10262,10284]
===
match
---
operator: , [1257,1258]
operator: , [1257,1258]
===
match
---
for_stmt [24893,25375]
for_stmt [24990,25472]
===
match
---
name: airflow [1932,1939]
name: airflow [1932,1939]
===
match
---
operator: -> [8724,8726]
operator: -> [8724,8726]
===
match
---
operator: , [13553,13554]
operator: , [13656,13657]
===
match
---
trailer [2265,2275]
trailer [2265,2275]
===
match
---
name: self [24332,24336]
name: self [24429,24433]
===
match
---
name: env [4783,4786]
name: env [4783,4786]
===
match
---
operator: , [14961,14962]
operator: , [15058,15059]
===
match
---
funcdef [3380,4469]
funcdef [3380,4469]
===
match
---
trailer [9632,9653]
trailer [9632,9653]
===
match
---
name: x [14641,14642]
name: x [14738,14739]
===
match
---
operator: { [21047,21048]
operator: { [21144,21145]
===
match
---
name: ceil [8936,8940]
name: ceil [8936,8940]
===
match
---
name: async_results [22311,22324]
name: async_results [22408,22421]
===
match
---
suite [15717,15775]
suite [15814,15872]
===
match
---
name: async_result [15569,15581]
name: async_result [15666,15678]
===
match
---
operator: , [1242,1243]
operator: , [1242,1243]
===
match
---
atom_expr [3488,3497]
atom_expr [3488,3497]
===
match
---
name: queued_tasks [9365,9377]
name: queued_tasks [9365,9377]
===
match
---
name: EventBufferValueType [21884,21904]
name: EventBufferValueType [21981,22001]
===
match
---
name: info [19710,19714]
name: info [19807,19811]
===
match
---
string: """Executes command.""" [2952,2975]
string: """Executes command.""" [2952,2975]
===
match
---
operator: , [9397,9398]
operator: , [9397,9398]
===
match
---
try_stmt [20634,21179]
try_stmt [20731,21276]
===
match
---
funcdef [22447,22975]
funcdef [22544,23072]
===
match
---
expr_stmt [12483,12552]
expr_stmt [12483,12552]
===
match
---
name: result [10195,10201]
name: result [10195,10201]
===
match
---
atom_expr [22400,22418]
atom_expr [22497,22515]
===
match
---
trailer [3883,3890]
trailer [3883,3890]
===
match
---
trailer [4637,4661]
trailer [4637,4661]
===
match
---
name: CELERY_FETCH_ERR_MSG_HEADER [2321,2348]
name: CELERY_FETCH_ERR_MSG_HEADER [2321,2348]
===
match
---
trailer [23341,23345]
trailer [23438,23442]
===
match
---
name: str [23836,23839]
name: str [23933,23936]
===
match
---
operator: { [8017,8018]
operator: { [8017,8018]
===
match
---
funcdef [6281,7051]
funcdef [6281,7051]
===
match
---
trailer [6190,6214]
trailer [6190,6214]
===
match
---
atom_expr [23325,23355]
atom_expr [23422,23452]
===
match
---
operator: = [23863,23864]
operator: = [23960,23961]
===
match
---
name: Stats [2023,2028]
name: Stats [2023,2028]
===
match
---
name: logging_mixin [2052,2065]
name: logging_mixin [2052,2065]
===
match
---
comparison [10389,10421]
comparison [10389,10421]
===
match
---
comparison [16349,16379]
comparison [16446,16476]
===
match
---
name: task_result [23979,23990]
name: task_result [24076,24087]
===
match
---
trailer [19560,19582]
trailer [19657,19679]
===
match
---
operator: , [24258,24259]
operator: , [24355,24356]
===
match
---
param [23732,23755]
param [23829,23852]
===
match
---
expr_stmt [24231,24264]
expr_stmt [24328,24361]
===
match
---
operator: = [2854,2855]
operator: = [2854,2855]
===
match
---
trailer [24618,24636]
trailer [24715,24733]
===
match
---
trailer [23430,23432]
trailer [23527,23529]
===
match
---
trailer [4856,4908]
trailer [4856,4908]
===
match
---
name: ImportError [6931,6942]
name: ImportError [6931,6942]
===
match
---
expr_stmt [8004,8019]
expr_stmt [8004,8019]
===
match
---
string: "Adopted tasks were still pending after %s, assuming they never made it to celery and " [14441,14528]
string: "Adopted tasks were still pending after %s, assuming they never made it to celery and " [14538,14625]
===
match
---
fstring_expr [19759,19766]
fstring_expr [19856,19863]
===
match
---
name: any [16885,16888]
name: any [16982,16985]
===
match
---
atom_expr [20925,20945]
atom_expr [21022,21042]
===
match
---
expr_stmt [24054,24126]
expr_stmt [24151,24223]
===
match
---
trailer [18852,18856]
trailer [18949,18953]
===
match
---
import_from [2086,2128]
import_from [2086,2128]
===
match
---
argument [12587,12612]
argument [12587,12612]
===
match
---
name: _sync_parallelism [7836,7853]
name: _sync_parallelism [7836,7853]
===
match
---
trailer [10148,10154]
trailer [10148,10154]
===
match
---
param [22483,22494]
param [22580,22591]
===
match
---
subscriptlist [5752,5824]
subscriptlist [5752,5824]
===
match
---
number: 1 [4382,4383]
number: 1 [4382,4383]
===
match
---
atom_expr [19606,19612]
atom_expr [19703,19709]
===
match
---
name: send_pool [12617,12626]
name: send_pool [12617,12626]
===
match
---
dotted_name [1625,1641]
dotted_name [1625,1641]
===
match
---
simple_stmt [23809,23868]
simple_stmt [23906,23965]
===
match
---
operator: , [2839,2840]
operator: , [2839,2840]
===
match
---
name: args [4004,4008]
name: args [4004,4008]
===
match
---
name: debug [15522,15527]
name: debug [15619,15624]
===
match
---
import_as_names [1292,1329]
import_as_names [1292,1329]
===
match
---
simple_stmt [19635,19660]
simple_stmt [19732,19757]
===
match
---
trailer [7835,7853]
trailer [7835,7853]
===
match
---
tfpdef [20055,20080]
tfpdef [20152,20177]
===
match
---
trailer [8940,8986]
trailer [8940,8986]
===
match
---
string: 'Error fetching Celery task state' [2351,2385]
string: 'Error fetching Celery task state' [2351,2385]
===
match
---
operator: * [24591,24592]
operator: * [24688,24689]
===
match
---
name: key [15564,15567]
name: key [15661,15664]
===
match
---
atom [11761,11791]
atom [11761,11791]
===
match
---
operator: = [23192,23193]
operator: = [23289,23290]
===
match
---
name: values [19167,19173]
name: values [19264,19270]
===
match
---
name: key [5865,5868]
name: key [5865,5868]
===
match
---
expr_stmt [24400,24461]
expr_stmt [24497,24558]
===
match
---
operator: , [14978,14979]
operator: , [15075,15076]
===
match
---
name: self [16801,16805]
name: self [16898,16902]
===
match
---
expr_stmt [2789,2876]
expr_stmt [2789,2876]
===
match
---
testlist_star_expr [25350,25374]
testlist_star_expr [25447,25471]
===
match
---
number: 600 [8330,8333]
number: 600 [8330,8333]
===
match
---
simple_stmt [24054,24127]
simple_stmt [24151,24224]
===
match
---
trailer [19647,19651]
trailer [19744,19748]
===
match
---
atom_expr [24231,24250]
atom_expr [24328,24347]
===
match
---
atom_expr [4744,4761]
atom_expr [4744,4761]
===
match
---
name: Any [17187,17190]
name: Any [17284,17287]
===
match
---
atom_expr [23572,23648]
atom_expr [23669,23745]
===
match
---
name: state [24253,24258]
name: state [24350,24355]
===
match
---
fstring [3154,3189]
fstring [3154,3189]
===
match
---
simple_stmt [14737,14774]
simple_stmt [14834,14871]
===
match
---
atom_expr [23765,23799]
atom_expr [23862,23896]
===
match
---
operator: -> [9828,9830]
operator: -> [9828,9830]
===
match
---
funcdef [21596,21716]
funcdef [21693,21813]
===
match
---
return_stmt [24273,24290]
return_stmt [24370,24387]
===
match
---
atom_expr [21647,21665]
atom_expr [21744,21762]
===
match
---
operator: , [5884,5885]
operator: , [5884,5885]
===
match
---
name: command_to_exec [3277,3292]
name: command_to_exec [3277,3292]
===
match
---
expr_stmt [23372,23452]
expr_stmt [23469,23549]
===
match
---
trailer [24581,24586]
trailer [24678,24683]
===
match
---
atom_expr [25218,25246]
atom_expr [25315,25343]
===
match
---
trailer [9712,9727]
trailer [9712,9727]
===
match
---
atom_expr [11736,11758]
atom_expr [11736,11758]
===
match
---
import_from [1388,1473]
import_from [1388,1473]
===
match
---
name: sleep [16989,16994]
name: sleep [17086,17091]
===
match
---
arglist [12227,12269]
arglist [12227,12269]
===
match
---
name: len [12449,12452]
name: len [12449,12452]
===
match
---
trailer [21652,21654]
trailer [21749,21751]
===
match
---
funcdef [21721,21829]
funcdef [21818,21926]
===
match
---
operator: == [7854,7856]
operator: == [7854,7856]
===
match
---
name: self [18977,18981]
name: self [19074,19078]
===
match
---
suite [4687,4788]
suite [4687,4788]
===
match
---
param [8704,8722]
param [8704,8722]
===
match
---
operator: , [8294,8295]
operator: , [8294,8295]
===
match
---
param [6317,6325]
param [6317,6325]
===
match
---
dotted_name [2134,2153]
dotted_name [2134,2153]
===
match
---
simple_stmt [1728,1767]
simple_stmt [1728,1767]
===
match
---
trailer [8935,8940]
trailer [8935,8940]
===
match
---
simple_stmt [22265,22326]
simple_stmt [22362,22423]
===
match
---
name: OPERATION_TIMEOUT [20668,20685]
name: OPERATION_TIMEOUT [20765,20782]
===
match
---
parameters [9011,9034]
parameters [9011,9034]
===
match
---
name: pid [3482,3485]
name: pid [3482,3485]
===
match
---
name: os [4455,4457]
name: os [4455,4457]
===
match
---
name: update_all_task_states [12973,12995]
name: update_all_task_states [12973,12995]
===
match
---
name: task_results_by_task_id [23927,23950]
name: task_results_by_task_id [24024,24047]
===
match
---
simple_stmt [11417,11442]
simple_stmt [11417,11442]
===
match
---
atom_expr [12968,12997]
atom_expr [12968,12997]
===
match
---
name: operator [992,1000]
name: operator [992,1000]
===
match
---
name: get [23951,23954]
name: get [24048,24051]
===
match
---
testlist_comp [22612,22661]
testlist_comp [22709,22758]
===
match
---
for_stmt [18630,18857]
for_stmt [18727,18954]
===
match
---
trailer [14991,15022]
trailer [15088,15119]
===
match
---
operator: -> [5743,5745]
operator: -> [5743,5745]
===
match
---
suite [17206,17345]
suite [17303,17442]
===
match
---
name: task_tuples_to_send [9877,9896]
name: task_tuples_to_send [9877,9896]
===
match
---
trailer [19009,19089]
trailer [19106,19186]
===
match
---
atom_expr [17131,17144]
atom_expr [17228,17241]
===
match
---
name: airflow [3786,3793]
name: airflow [3786,3793]
===
match
---
name: task_cls [23183,23191]
name: task_cls [23280,23288]
===
match
---
suite [16967,16998]
suite [17064,17095]
===
match
---
simple_stmt [9201,9254]
simple_stmt [9201,9254]
===
match
---
trailer [13604,13606]
trailer [13589,13591]
===
match
---
atom_expr [14624,14667]
atom_expr [14721,14764]
===
match
---
operator: = [4743,4744]
operator: = [4743,4744]
===
match
---
operator: , [23043,23044]
operator: , [23140,23141]
===
match
---
suite [9836,11964]
suite [9836,11964]
===
match
---
simple_stmt [6733,6755]
simple_stmt [6733,6755]
===
match
---
name: super [14878,14883]
name: super [14975,14980]
===
match
---
name: List [17452,17456]
name: List [17549,17553]
===
match
---
operator: , [25192,25193]
operator: , [25289,25290]
===
match
---
atom_expr [8274,8334]
atom_expr [8274,8334]
===
match
---
name: state [24008,24013]
name: state [24105,24110]
===
match
---
name: __init__ [7485,7493]
name: __init__ [7485,7493]
===
match
---
operator: = [24876,24877]
operator: = [24973,24974]
===
match
---
expr_stmt [20838,20905]
expr_stmt [20935,21002]
===
match
---
name: state [15762,15767]
name: state [15859,15864]
===
match
---
trailer [19639,19647]
trailer [19736,19744]
===
match
---
except_clause [16688,16704]
except_clause [16785,16801]
===
match
---
name: self [11225,11229]
name: self [11225,11229]
===
match
---
atom_expr [24418,24436]
atom_expr [24515,24533]
===
match
---
name: len [15125,15128]
name: len [15222,15225]
===
match
---
name: running [11384,11391]
name: running [11384,11391]
===
match
---
atom_expr [5933,5967]
atom_expr [5933,5967]
===
match
---
simple_stmt [16718,16788]
simple_stmt [16815,16885]
===
match
---
name: map [19028,19031]
name: map [19125,19128]
===
match
---
name: _ [10192,10193]
name: _ [10192,10193]
===
match
---
atom_expr [19023,19079]
atom_expr [19120,19176]
===
match
---
name: OrderedDict [1082,1093]
name: OrderedDict [1082,1093]
===
match
---
name: backend [19181,19188]
name: backend [19278,19285]
===
match
---
trailer [11229,11242]
trailer [11229,11242]
===
match
---
name: adopted_task_timeouts [13015,13036]
name: adopted_task_timeouts [13015,13036]
===
match
---
name: TaskInstance [1967,1979]
name: TaskInstance [1967,1979]
===
match
---
name: Sentry [4405,4411]
name: Sentry [4405,4411]
===
match
---
expr_stmt [9628,9662]
expr_stmt [9628,9662]
===
match
---
name: backend [22616,22623]
name: backend [22713,22720]
===
match
---
name: info [14916,14920]
name: info [15013,15017]
===
match
---
name: cpu_count [1173,1182]
name: cpu_count [1173,1182]
===
match
---
trailer [19173,19175]
trailer [19270,19272]
===
match
---
simple_stmt [8740,8905]
simple_stmt [8740,8905]
===
match
---
atom_expr [8409,8422]
atom_expr [8409,8422]
===
match
---
atom_expr [22813,22835]
atom_expr [22910,22932]
===
match
---
trailer [16950,16956]
trailer [17047,17053]
===
match
---
name: self [16718,16722]
name: self [16815,16819]
===
match
---
fstring [21029,21088]
fstring [21126,21185]
===
match
---
name: list [19023,19027]
name: list [19120,19124]
===
match
---
operator: = [19350,19351]
operator: = [19447,19448]
===
match
---
if_stmt [15708,15775]
if_stmt [15805,15872]
===
match
---
name: setproctitle [1584,1596]
name: setproctitle [1584,1596]
===
match
---
suite [19268,19769]
suite [19365,19866]
===
match
---
expr_stmt [11324,11362]
expr_stmt [11324,11362]
===
match
---
name: self [10787,10791]
name: self [10787,10791]
===
match
---
string: "executor.adopted_task_timeouts (%d)\n\t%s" [15068,15111]
string: "executor.adopted_task_timeouts (%d)\n\t%s" [15165,15208]
===
match
---
name: join [19829,19833]
name: join [19926,19930]
===
match
---
suite [12123,12272]
suite [12123,12272]
===
match
---
simple_stmt [1512,1579]
simple_stmt [1512,1579]
===
match
---
testlist_comp [9470,9506]
testlist_comp [9470,9506]
===
match
---
name: chunksize [24547,24556]
name: chunksize [24644,24653]
===
match
---
name: pop [16504,16507]
name: pop [16601,16604]
===
match
---
trailer [4926,4936]
trailer [4926,4936]
===
match
---
with_stmt [5928,6043]
with_stmt [5928,6043]
===
match
---
name: len [9356,9359]
name: len [9356,9359]
===
match
---
name: getint [8468,8474]
name: getint [8468,8474]
===
match
---
trailer [7789,7819]
trailer [7789,7819]
===
match
---
simple_stmt [1183,1272]
simple_stmt [1183,1272]
===
match
---
param [15803,15824]
param [15900,15921]
===
match
---
atom_expr [19855,19992]
atom_expr [19952,20089]
===
match
---
name: settings [1633,1641]
name: settings [1633,1641]
===
match
---
name: args [4249,4253]
name: args [4249,4253]
===
match
---
fstring_expr [21063,21087]
fstring_expr [21160,21184]
===
match
---
trailer [20959,20965]
trailer [21056,21062]
===
match
---
fstring_string: Celery task ID:  [3156,3172]
fstring_string: Celery task ID:  [3156,3172]
===
match
---
simple_stmt [4180,4240]
simple_stmt [4180,4240]
===
match
---
argument [20660,20685]
argument [20757,20782]
===
match
---
testlist_star_expr [15623,15634]
testlist_star_expr [15720,15731]
===
match
---
trailer [19531,19535]
trailer [19628,19632]
===
match
---
suite [23800,24291]
suite [23897,24388]
===
match
---
name: adopted_task_timeouts [19507,19528]
name: adopted_task_timeouts [19604,19625]
===
match
---
name: Mapping [23032,23039]
name: Mapping [23129,23136]
===
match
---
atom_expr [11191,11207]
atom_expr [11191,11207]
===
match
---
name: self [13132,13136]
name: self [13132,13136]
===
match
---
operator: , [8925,8926]
operator: , [8925,8926]
===
match
---
name: task_tuple [5900,5910]
name: task_tuple [5900,5910]
===
match
---
trailer [19027,19079]
trailer [19124,19176]
===
match
---
name: list [24682,24686]
name: list [24779,24783]
===
match
---
name: task_id [20938,20945]
name: task_id [21035,21042]
===
match
---
name: Dict [8380,8384]
name: Dict [8380,8384]
===
match
---
name: key [10915,10918]
name: key [10915,10918]
===
match
---
atom_expr [23294,23362]
atom_expr [23391,23459]
===
match
---
trailer [23613,23648]
trailer [23710,23745]
===
match
---
name: self [12884,12888]
name: self [12884,12888]
===
match
---
name: pool [3852,3856]
name: pool [3852,3856]
===
match
---
name: airflow [2214,2221]
name: airflow [2214,2221]
===
match
---
param [13132,13136]
param [13132,13136]
===
match
---
name: CELERY_FETCH_ERR_MSG_HEADER [25097,25124]
name: CELERY_FETCH_ERR_MSG_HEADER [25194,25221]
===
match
---
trailer [14883,14885]
trailer [14980,14982]
===
match
---
simple_stmt [4945,5002]
simple_stmt [4945,5002]
===
match
---
name: self [10889,10893]
name: self [10889,10893]
===
match
---
name: stderr [4737,4743]
name: stderr [4737,4743]
===
match
---
trailer [22738,22752]
trailer [22835,22849]
===
match
---
name: _get_many_from_db_backend [22984,23009]
name: _get_many_from_db_backend [23081,23106]
===
match
---
name: min [9340,9343]
name: min [9340,9343]
===
match
---
simple_stmt [15734,15775]
simple_stmt [15831,15872]
===
match
---
suite [16133,16680]
suite [16230,16777]
===
match
---
trailer [16284,16292]
trailer [16381,16389]
===
match
---
name: try_adopt_task_instances [17393,17417]
name: try_adopt_task_instances [17490,17514]
===
match
---
name: iter [19149,19153]
name: iter [19246,19250]
===
match
---
name: info [15630,15634]
name: info [15727,15731]
===
match
---
operator: = [2349,2350]
operator: = [2349,2350]
===
match
---
operator: <= [10483,10485]
operator: <= [10483,10485]
===
match
---
parameters [15796,15847]
parameters [15893,15944]
===
match
---
trailer [10400,10421]
trailer [10400,10421]
===
match
---
atom_expr [7872,7894]
atom_expr [7872,7894]
===
match
---
name: event_buffer [11741,11753]
name: event_buffer [11741,11753]
===
match
---
name: floor [24571,24576]
name: floor [24668,24673]
===
match
---
suite [20687,20972]
suite [20784,21069]
===
match
---
param [12830,12834]
param [12830,12834]
===
match
---
funcdef [13095,14774]
funcdef [13095,14871]
===
match
---
if_stmt [9571,9663]
if_stmt [9571,9663]
===
match
---
name: fetch_celery_task_state [24718,24741]
name: fetch_celery_task_state [24815,24838]
===
match
---
name: self [8698,8702]
name: self [8698,8702]
===
match
---
trailer [11383,11391]
trailer [11383,11391]
===
match
---
expr_stmt [19335,19373]
expr_stmt [19432,19470]
===
match
---
string: 'celery_config_options' [2630,2653]
string: 'celery_config_options' [2630,2653]
===
match
---
name: queue [17124,17129]
name: queue [17221,17226]
===
match
---
operator: = [2764,2765]
operator: = [2764,2765]
===
match
---
trailer [14971,14977]
trailer [15068,15074]
===
match
---
param [17364,17368]
param [17461,17465]
===
match
---
simple_stmt [6793,6825]
simple_stmt [6793,6825]
===
match
---
simple_stmt [3910,3932]
simple_stmt [3910,3932]
===
match
---
if_stmt [12853,12960]
if_stmt [12853,12960]
===
match
---
name: task_results [22868,22880]
name: task_results [22965,22977]
===
match
---
with_stmt [12562,12779]
with_stmt [12562,12779]
===
match
---
name: all [23357,23360]
name: all [23454,23457]
===
match
---
trailer [12420,12448]
trailer [12420,12448]
===
match
---
name: key [19532,19535]
name: key [19629,19632]
===
match
---
operator: } [21060,21061]
operator: } [21157,21158]
===
match
---
name: result [22184,22190]
name: result [22281,22287]
===
match
---
atom_expr [8205,8231]
atom_expr [8205,8231]
===
match
---
arith_expr [7904,7919]
arith_expr [7904,7919]
===
match
---
name: info [10624,10628]
name: info [10624,10628]
===
match
---
simple_stmt [2167,2209]
simple_stmt [2167,2209]
===
match
---
trailer [22101,22116]
trailer [22198,22213]
===
match
---
import_name [985,1000]
import_name [985,1000]
===
match
---
atom_expr [19695,19701]
atom_expr [19792,19798]
===
match
---
string: "Inquiring about %s celery task(s)" [15353,15388]
string: "Inquiring about %s celery task(s)" [15450,15485]
===
match
---
operator: , [15767,15768]
operator: , [15864,15865]
===
match
---
name: key [10187,10190]
name: key [10187,10190]
===
match
---
operator: , [24367,24368]
operator: , [24464,24465]
===
match
---
trailer [8435,8460]
trailer [8435,8460]
===
match
---
name: task_tuples_to_send [9520,9539]
name: task_tuples_to_send [9520,9539]
===
match
---
atom_expr [11919,11931]
atom_expr [11919,11931]
===
match
---
trailer [24848,24875]
trailer [24945,24972]
===
match
---
name: t [9872,9873]
name: t [9872,9873]
===
match
---
operator: = [23145,23146]
operator: = [23242,23243]
===
match
---
name: pop [15973,15976]
name: pop [16070,16073]
===
match
---
name: task_ids [23076,23084]
name: task_ids [23173,23181]
===
match
---
param [14794,14798]
param [14891,14895]
===
match
---
operator: > [13637,13638]
operator: > [13734,13735]
===
match
---
atom_expr [10555,10594]
atom_expr [10555,10594]
===
match
---
name: order_queued_tasks_by_priority [9221,9251]
name: order_queued_tasks_by_priority [9221,9251]
===
match
---
comparison [13623,13642]
comparison [13720,13739]
===
match
---
name: key [19655,19658]
name: key [19752,19755]
===
match
---
suite [10534,10954]
suite [10534,10954]
===
match
---
operator: , [1252,1253]
operator: , [1252,1253]
===
match
---
name: pid [3580,3583]
name: pid [3580,3583]
===
match
---
name: AirflowException [17285,17301]
name: AirflowException [17382,17398]
===
match
---
name: exception [10325,10334]
name: exception [10325,10334]
===
match
---
trailer [22824,22835]
trailer [22921,22932]
===
match
---
operator: , [9473,9474]
operator: , [9473,9474]
===
match
---
name: TaskInstanceKey [1981,1996]
name: TaskInstanceKey [1981,1996]
===
match
---
name: self [19855,19859]
name: self [19952,19956]
===
match
---
name: LoggingMixin [21204,21216]
name: LoggingMixin [21301,21313]
===
match
---
name: self [8540,8544]
name: self [8540,8544]
===
match
---
name: _get_many_using_multiprocessing [24300,24331]
name: _get_many_using_multiprocessing [24397,24428]
===
match
---
name: state_or_exception [25164,25182]
name: state_or_exception [25261,25279]
===
match
---
trailer [22342,22348]
trailer [22439,22445]
===
match
---
operator: -> [3469,3471]
operator: -> [3469,3471]
===
match
---
name: now [13495,13498]
name: now [13495,13498]
===
match
---
operator: , [3292,3293]
operator: , [3292,3293]
===
match
---
operator: , [9410,9411]
operator: , [9410,9411]
===
match
---
name: task_publish_retries [11010,11030]
name: task_publish_retries [11010,11030]
===
match
---
name: tasks [15595,15600]
name: tasks [15692,15697]
===
match
---
testlist_star_expr [24253,24264]
testlist_star_expr [24350,24361]
===
match
---
expr_stmt [11417,11441]
expr_stmt [11417,11441]
===
match
---
name: log [4316,4319]
name: log [4316,4319]
===
match
---
parameters [7461,7467]
parameters [7461,7467]
===
match
---
atom_expr [10318,10334]
atom_expr [10318,10334]
===
match
---
name: ExceptionWithTraceback [5801,5823]
name: ExceptionWithTraceback [5801,5823]
===
match
---
name: adopted_task_timeouts [15197,15218]
name: adopted_task_timeouts [15294,15315]
===
match
---
trailer [3455,3460]
trailer [3455,3460]
===
match
---
operator: { [6118,6119]
operator: { [6118,6119]
===
match
---
simple_stmt [3328,3378]
simple_stmt [3328,3378]
===
match
---
simple_stmt [14878,14899]
simple_stmt [14975,14996]
===
match
---
atom_expr [3569,3587]
atom_expr [3569,3587]
===
match
---
trailer [20101,20130]
trailer [20198,20227]
===
match
---
simple_stmt [7046,7051]
simple_stmt [7046,7051]
===
match
---
name: max [24559,24562]
name: max [24656,24659]
===
match
---
atom_expr [4316,4367]
atom_expr [4316,4367]
===
match
---
import_as_name [1306,1329]
import_as_name [1306,1329]
===
match
---
argument [14636,14666]
argument [14733,14763]
===
match
---
expr_stmt [3558,3587]
expr_stmt [3558,3587]
===
match
---
operator: = [7776,7777]
operator: = [7776,7777]
===
match
---
trailer [11913,11963]
trailer [11913,11963]
===
match
---
trailer [22939,22974]
trailer [23036,23071]
===
match
---
return_stmt [23565,23648]
return_stmt [23662,23745]
===
match
---
simple_stmt [19120,19189]
simple_stmt [19217,19286]
===
match
---
name: task_tuples_to_send [9779,9798]
name: task_tuples_to_send [9779,9798]
===
match
---
trailer [8567,8571]
trailer [8567,8571]
===
match
---
trailer [11395,11400]
trailer [11395,11400]
===
match
---
name: self [12860,12864]
name: self [12860,12864]
===
match
---
name: math [8931,8935]
name: math [8931,8935]
===
match
---
name: task_tuples_to_send [9675,9694]
name: task_tuples_to_send [9675,9694]
===
match
---
trailer [3116,3129]
trailer [3116,3129]
===
match
---
trailer [15972,15976]
trailer [16069,16073]
===
match
---
name: airflow [6836,6843]
name: airflow [6836,6843]
===
match
---
name: executor_config [17161,17176]
name: executor_config [17258,17273]
===
match
---
trailer [21798,21806]
trailer [21895,21903]
===
match
---
string: 'Sent all tasks.' [10155,10172]
string: 'Sent all tasks.' [10155,10172]
===
match
---
name: ProcessPoolExecutor [1125,1144]
name: ProcessPoolExecutor [1125,1144]
===
match
---
trailer [22902,22939]
trailer [22999,23036]
===
match
---
name: self [15912,15916]
name: self [16009,16013]
===
match
---
name: _check_for_stalled_adopted_tasks [13055,13087]
name: _check_for_stalled_adopted_tasks [13055,13087]
===
match
---
param [21847,21852]
param [21944,21949]
===
match
---
operator: , [5739,5740]
operator: , [5739,5740]
===
match
---
atom_expr [12529,12551]
atom_expr [12529,12551]
===
match
---
atom_expr [16477,16518]
atom_expr [16574,16615]
===
match
---
suite [10227,11964]
suite [10227,11964]
===
match
---
name: BaseKeyValueStoreBackend [22023,22047]
name: BaseKeyValueStoreBackend [22120,22144]
===
match
---
operator: = [24167,24168]
operator: = [24264,24265]
===
match
---
trailer [15133,15155]
trailer [15230,15252]
===
match
---
name: task_publish_retries [10736,10756]
name: task_publish_retries [10736,10756]
===
match
---
name: command [9475,9482]
name: command [9475,9482]
===
match
---
name: self [10084,10088]
name: self [10084,10088]
===
match
---
string: """Called in response to SIGUSR2 by the scheduler""" [14817,14869]
string: """Called in response to SIGUSR2 by the scheduler""" [14914,14966]
===
match
---
operator: , [17114,17115]
operator: , [17211,17212]
===
match
---
number: 0 [19178,19179]
number: 0 [19275,19276]
===
match
---
operator: , [10761,10762]
operator: , [10761,10762]
===
match
---
expr_stmt [6078,6150]
expr_stmt [6078,6150]
===
match
---
arith_expr [11130,11171]
arith_expr [11130,11171]
===
match
---
trailer [23333,23341]
trailer [23430,23438]
===
match
---
suite [20998,21179]
suite [21095,21276]
===
match
---
trailer [22623,22640]
trailer [22720,22737]
===
match
---
name: info [19864,19868]
name: info [19961,19965]
===
match
---
if_stmt [24978,25375]
if_stmt [25075,25472]
===
match
---
operator: = [23485,23486]
operator: = [23582,23583]
===
match
---
comparison [12095,12122]
comparison [12095,12122]
===
match
---
name: result [11288,11294]
name: result [11288,11294]
===
match
---
fstring [6100,6150]
fstring [6100,6150]
===
match
---
name: debug [15347,15352]
name: debug [15444,15449]
===
match
---
expr_stmt [18950,19089]
expr_stmt [19047,19186]
===
match
---
operator: , [20945,20946]
operator: , [21042,21043]
===
match
---
trailer [24080,24101]
trailer [24177,24198]
===
match
---
if_stmt [10240,10954]
if_stmt [10240,10954]
===
match
---
name: Sentry [3744,3750]
name: Sentry [3744,3750]
===
match
---
atom [9399,9421]
atom [9399,9421]
===
match
---
name: task_ids [23722,23730]
name: task_ids [23819,23827]
===
match
---
import_from [1835,1926]
import_from [1835,1926]
===
match
---
name: key [6119,6122]
name: key [6119,6122]
===
match
---
fstring [19743,19767]
fstring [19840,19864]
===
match
---
operator: , [22948,22949]
operator: , [23045,23046]
===
match
---
trailer [19608,19612]
trailer [19705,19709]
===
match
---
operator: = [22678,22679]
operator: = [22775,22776]
===
match
---
trailer [15012,15018]
trailer [15109,15115]
===
match
---
trailer [4920,4926]
trailer [4920,4926]
===
match
---
name: celery_states [16545,16558]
name: celery_states [16642,16655]
===
match
---
trailer [11427,11432]
trailer [11427,11432]
===
match
---
name: task_tuples_to_send [12453,12472]
name: task_tuples_to_send [12453,12472]
===
match
---
tfpdef [15825,15835]
tfpdef [15922,15932]
===
match
---
simple_stmt [2129,2167]
simple_stmt [2129,2167]
===
match
---
annassign [23819,23867]
annassign [23916,23964]
===
match
---
atom_expr [10084,10131]
atom_expr [10084,10131]
===
match
---
name: _process_tasks [9713,9727]
name: _process_tasks [9713,9727]
===
match
---
name: self [22193,22197]
name: self [22290,22294]
===
match
---
name: update_all_task_states [15249,15271]
name: update_all_task_states [15346,15368]
===
match
---
with_stmt [23243,23363]
with_stmt [23340,23460]
===
match
---
expr_stmt [12404,12474]
expr_stmt [12404,12474]
===
match
---
atom_expr [19728,19768]
atom_expr [19825,19865]
===
match
---
atom_expr [19556,19582]
atom_expr [19653,19679]
===
match
---
atom_expr [19502,19536]
atom_expr [19599,19633]
===
match
---
name: super [21647,21652]
name: super [21744,21749]
===
match
---
operator: = [5469,5470]
operator: = [5469,5470]
===
match
---
sync_comp_for [23434,23451]
sync_comp_for [23531,23548]
===
match
---
trailer [15517,15521]
trailer [15614,15618]
===
match
---
trailer [7976,7994]
trailer [7976,7994]
===
match
---
atom_expr [19672,19715]
atom_expr [19769,19812]
===
match
---
atom [23387,23452]
atom [23484,23549]
===
match
---
name: key [10757,10760]
name: key [10757,10760]
===
match
---
trailer [24570,24576]
trailer [24667,24673]
===
match
---
atom_expr [4128,4153]
atom_expr [4128,4153]
===
match
---
suite [3509,3712]
suite [3509,3712]
===
match
---
operator: , [22021,22022]
operator: , [22118,22119]
===
match
---
name: update_task_state [19677,19694]
name: update_task_state [19774,19791]
===
match
---
atom_expr [5454,5468]
atom_expr [5454,5468]
===
match
---
operator: = [6098,6099]
operator: = [6098,6099]
===
match
---
trailer [19676,19694]
trailer [19773,19791]
===
match
---
name: self [14794,14798]
name: self [14891,14895]
===
match
---
name: conf [1762,1766]
name: conf [1762,1766]
===
match
---
name: _sync_parallelism [8642,8659]
name: _sync_parallelism [8642,8659]
===
match
---
name: execute_async [17027,17040]
name: execute_async [17124,17137]
===
match
---
operator: , [17151,17152]
operator: , [17248,17249]
===
match
---
trailer [4928,4935]
trailer [4928,4935]
===
match
---
return_stmt [22428,22441]
return_stmt [22525,22538]
===
match
---
atom_expr [24476,24520]
atom_expr [24573,24617]
===
match
---
name: to_send_count [8704,8717]
name: to_send_count [8704,8717]
===
match
---
funcdef [5343,5491]
funcdef [5343,5491]
===
match
---
name: super [15865,15870]
name: super [15962,15967]
===
match
---
dotted_name [3722,3736]
dotted_name [3722,3736]
===
match
---
classdef [7053,20025]
classdef [7053,20122]
===
match
---
name: airflow [2172,2179]
name: airflow [2172,2179]
===
match
---
trailer [18845,18852]
trailer [18942,18949]
===
match
---
name: bulk_state_fetcher [15455,15473]
name: bulk_state_fetcher [15552,15570]
===
match
---
name: BulkStateFetcher [7955,7971]
name: BulkStateFetcher [7955,7971]
===
match
---
operator: , [16805,16806]
operator: , [16902,16903]
===
match
---
atom_expr [7753,7775]
atom_expr [7753,7775]
===
match
---
name: itemgetter [19041,19051]
name: itemgetter [19138,19148]
===
match
---
name: self [8963,8967]
name: self [8963,8967]
===
match
---
expr_stmt [11225,11270]
expr_stmt [11225,11270]
===
match
---
simple_stmt [12640,12779]
simple_stmt [12640,12779]
===
match
---
operator: , [19287,19288]
operator: , [19384,19385]
===
match
---
atom_expr [12503,12527]
atom_expr [12503,12527]
===
match
---
if_stmt [18657,18857]
if_stmt [18754,18954]
===
match
---
argument [2841,2875]
argument [2841,2875]
===
match
---
subscriptlist [23836,23861]
subscriptlist [23933,23958]
===
match
---
subscriptlist [8385,8405]
subscriptlist [8385,8405]
===
match
---
trailer [3148,3153]
trailer [3148,3153]
===
match
---
name: adopted_task_timeouts [13577,13598]
name: adopted_task_timeouts [13562,13583]
===
match
---
operator: , [6315,6316]
operator: , [6315,6316]
===
match
---
name: PENDING [16559,16566]
name: PENDING [16656,16663]
===
match
---
with_stmt [20647,20972]
with_stmt [20744,21069]
===
match
---
atom [18618,18620]
atom [18715,18717]
===
match
---
name: sync [17011,17015]
name: sync [17108,17112]
===
match
---
name: kubernetes [6982,6992]
name: kubernetes [6982,6992]
===
match
---
name: sync_parallelism [21615,21631]
name: sync_parallelism [21712,21728]
===
match
---
name: getfloat [2470,2478]
name: getfloat [2470,2478]
===
match
---
arglist [11941,11961]
arglist [11941,11961]
===
match
---
trailer [3864,3866]
trailer [3864,3866]
===
match
---
operator: , [24756,24757]
operator: , [24853,24854]
===
match
---
atom_expr [4585,4602]
atom_expr [4585,4602]
===
match
---
simple_stmt [16623,16680]
simple_stmt [16720,16777]
===
match
---
classdef [21181,25417]
classdef [21278,25514]
===
match
---
simple_stmt [25057,25270]
simple_stmt [25154,25367]
===
match
---
expr_stmt [8431,8524]
expr_stmt [8431,8524]
===
match
---
number: 1 [3762,3763]
number: 1 [3762,3763]
===
match
---
operator: = [24767,24768]
operator: = [24864,24865]
===
match
---
name: self [15041,15045]
name: self [15138,15142]
===
match
---
name: utcnow [2244,2250]
name: utcnow [2244,2250]
===
match
---
name: os [4585,4587]
name: os [4585,4587]
===
match
---
name: self [25057,25061]
name: self [25154,25158]
===
match
---
name: datetime [8171,8179]
name: datetime [8171,8179]
===
match
---
simple_stmt [1618,1654]
simple_stmt [1618,1654]
===
match
---
operator: = [4277,4278]
operator: = [4277,4278]
===
match
---
trailer [16371,16379]
trailer [16468,16476]
===
match
---
name: celery_states [16271,16284]
name: celery_states [16368,16381]
===
match
---
expr_stmt [22671,22702]
expr_stmt [22768,22799]
===
match
---
name: timeout [20652,20659]
name: timeout [20749,20756]
===
match
---
name: key [10842,10845]
name: key [10842,10845]
===
match
---
name: num_processes [12599,12612]
name: num_processes [12599,12612]
===
match
---
funcdef [4471,5038]
funcdef [4471,5038]
===
match
---
subscript [4045,4047]
subscript [4045,4047]
===
match
---
funcdef [22980,23649]
funcdef [23077,23746]
===
match
---
name: _sync_parallelism [8968,8985]
name: _sync_parallelism [8968,8985]
===
match
---
name: concurrent [1099,1109]
name: concurrent [1099,1109]
===
match
---
sync_comp_for [9868,9896]
sync_comp_for [9868,9896]
===
match
---
simple_stmt [7929,7996]
simple_stmt [7929,7996]
===
match
---
name: id [3138,3140]
name: id [3138,3140]
===
match
---
operator: } [18590,18591]
operator: } [18687,18688]
===
match
---
name: Optional [4544,4552]
name: Optional [4544,4552]
===
match
---
arith_expr [25097,25138]
arith_expr [25194,25235]
===
match
---
name: task_publish_retries [8358,8378]
name: task_publish_retries [8358,8378]
===
match
---
name: OPERATION_TIMEOUT [5949,5966]
name: OPERATION_TIMEOUT [5949,5966]
===
match
---
operator: = [4154,4155]
operator: = [4154,4155]
===
match
---
sync_comp_for [22644,22661]
sync_comp_for [22741,22758]
===
match
---
test [20845,20905]
test [20942,21002]
===
match
---
name: debug_dump [14783,14793]
name: debug_dump [14880,14890]
===
match
---
name: sync_pool [24704,24713]
name: sync_pool [24801,24810]
===
match
---
name: int [9030,9033]
name: int [9030,9033]
===
match
---
trailer [12898,12940]
trailer [12898,12940]
===
match
---
arglist [21149,21171]
arglist [21246,21268]
===
match
---
trailer [8252,8344]
trailer [8252,8344]
===
match
---
if_stmt [7828,7921]
if_stmt [7828,7921]
===
match
---
number: 1.0 [8941,8944]
number: 1.0 [8941,8944]
===
match
---
operator: , [16269,16270]
operator: , [16366,16367]
===
match
---
testlist_comp [11251,11269]
testlist_comp [11251,11269]
===
match
---
simple_stmt [20918,20972]
simple_stmt [21015,21069]
===
match
---
atom_expr [14636,14643]
atom_expr [14733,14740]
===
match
---
trailer [8384,8406]
trailer [8384,8406]
===
match
---
name: ExceptionWithTraceback [25012,25034]
name: ExceptionWithTraceback [25109,25131]
===
match
---
atom_expr [25057,25269]
atom_expr [25154,25366]
===
match
---
param [20055,20080]
param [20152,20177]
===
match
---
trailer [10088,10110]
trailer [10088,10110]
===
match
---
operator: = [19614,19615]
operator: = [19711,19712]
===
match
---
trailer [19694,19715]
trailer [19791,19812]
===
match
---
trailer [8144,8180]
trailer [8144,8180]
===
match
---
name: session [23137,23144]
name: session [23234,23241]
===
match
---
trailer [19863,19868]
trailer [19960,19965]
===
match
---
param [16021,16042]
param [16118,16139]
===
match
---
operator: , [15889,15890]
operator: , [15986,15987]
===
match
---
trailer [23150,23158]
trailer [23247,23255]
===
match
---
import_as_names [1879,1926]
import_as_names [1879,1926]
===
match
---
operator: -> [14800,14802]
operator: -> [14897,14899]
===
match
---
name: ti [18792,18794]
name: ti [18889,18891]
===
match
---
name: airflow [2034,2041]
name: airflow [2034,2041]
===
match
---
expr_stmt [22184,22238]
expr_stmt [22281,22335]
===
match
---
atom_expr [12062,12086]
atom_expr [12062,12086]
===
match
---
name: task_id_to_states_and_info [24653,24679]
name: task_id_to_states_and_info [24750,24776]
===
match
---
atom_expr [9708,9748]
atom_expr [9708,9748]
===
match
---
atom_expr [10615,10868]
atom_expr [10615,10868]
===
match
---
if_stmt [2601,2788]
if_stmt [2601,2788]
===
match
---
return_stmt [22891,22974]
return_stmt [22988,23071]
===
match
---
name: map [24714,24717]
name: map [24811,24814]
===
match
---
operator: -> [12836,12838]
operator: -> [12836,12838]
===
match
---
operator: , [8483,8484]
operator: , [8483,8484]
===
match
---
expr_stmt [5594,5673]
expr_stmt [5594,5673]
===
match
---
return_stmt [20002,20024]
return_stmt [20099,20121]
===
match
---
operator: , [10816,10817]
operator: , [10816,10817]
===
match
---
name: state [15891,15896]
name: state [15988,15993]
===
match
---
name: TaskDb [1450,1456]
name: TaskDb [1450,1456]
===
match
---
name: cli [3794,3797]
name: cli [3794,3797]
===
match
---
name: execute_command [9491,9506]
name: execute_command [9491,9506]
===
match
---
name: _ [9329,9330]
name: _ [9329,9330]
===
match
---
name: values [16957,16963]
name: values [17054,17060]
===
match
---
trailer [19735,19742]
trailer [19832,19839]
===
match
---
name: self [15002,15006]
name: self [15099,15103]
===
match
---
name: TaskInstanceKey [5623,5638]
name: TaskInstanceKey [5623,5638]
===
match
---
atom_expr [16946,16965]
atom_expr [17043,17062]
===
match
---
name: e [6191,6192]
name: e [6191,6192]
===
match
---
name: Optional [1244,1252]
name: Optional [1244,1252]
===
match
---
operator: , [24436,24437]
operator: , [24533,24534]
===
match
---
trailer [22506,22533]
trailer [22603,22630]
===
match
---
suite [11307,11964]
suite [11307,11964]
===
match
---
trailer [8278,8285]
trailer [8278,8285]
===
match
---
if_stmt [13007,13090]
if_stmt [13007,13090]
===
match
---
string: """     Gets status for many Celery tasks using the best method available      If BaseKeyValueStoreBackend is used as result backend, the mget method is used.     If DatabaseBackend is used as result backend, the SELECT ...WHERE task_id IN (...) query is used     Otherwise, multiprocessing.Pool will be used. Each task status will be downloaded individually.     """ [21223,21590]
string: """     Gets status for many Celery tasks using the best method available      If BaseKeyValueStoreBackend is used as result backend, the mget method is used.     If DatabaseBackend is used as result backend, the SELECT ...WHERE task_id IN (...) query is used     Otherwise, multiprocessing.Pool will be used. Each task status will be downloaded individually.     """ [21320,21687]
===
match
---
name: celery [1517,1523]
name: celery [1517,1523]
===
match
---
operator: , [5638,5639]
operator: , [5638,5639]
===
match
---
expr_stmt [22604,22662]
expr_stmt [22701,22759]
===
match
---
operator: = [24507,24508]
operator: = [24604,24605]
===
match
---
atom_expr [3696,3710]
atom_expr [3696,3710]
===
match
---
name: operators [6774,6783]
name: operators [6774,6783]
===
match
---
trailer [23324,23356]
trailer [23421,23453]
===
match
---
tfpdef [16021,16041]
tfpdef [16118,16138]
===
match
---
name: command [5870,5877]
name: command [5870,5877]
===
match
---
argument [2510,2522]
argument [2510,2522]
===
match
---
trailer [15224,15226]
trailer [15321,15323]
===
match
---
atom_expr [12223,12270]
atom_expr [12223,12270]
===
match
---
simple_stmt [6159,6215]
simple_stmt [6159,6215]
===
match
---
dotted_name [1659,1698]
dotted_name [1659,1698]
===
match
---
param [24332,24337]
param [24429,24434]
===
match
---
name: BaseExecutor [1879,1891]
name: BaseExecutor [1879,1891]
===
match
---
operator: , [20886,20887]
operator: , [20983,20984]
===
match
---
name: close_fds [4763,4772]
name: close_fds [4763,4772]
===
match
---
name: self [23087,23091]
name: self [23184,23188]
===
match
---
name: TaskInstanceInCelery [9805,9825]
name: TaskInstanceInCelery [9805,9825]
===
match
---
atom_expr [4927,4935]
atom_expr [4927,4935]
===
match
---
trailer [24241,24250]
trailer [24338,24347]
===
match
---
trailer [10560,10565]
trailer [10560,10565]
===
match
---
trailer [13014,13036]
trailer [13014,13036]
===
match
---
dotted_name [1840,1871]
dotted_name [1840,1871]
===
match
---
name: TaskInstanceInCelery [12027,12047]
name: TaskInstanceInCelery [12027,12047]
===
match
---
name: append [14358,14364]
name: append [14455,14461]
===
match
---
string: """Do not allow async execution for Celery executor.""" [17215,17270]
string: """Do not allow async execution for Celery executor.""" [17312,17367]
===
match
---
operator: { [18589,18590]
operator: { [18686,18687]
===
match
---
name: async_result [21104,21116]
name: async_result [21201,21213]
===
match
---
name: send_task_to_executor [5680,5701]
name: send_task_to_executor [5680,5701]
===
match
---
try_stmt [6962,7051]
try_stmt [6962,7051]
===
match
---
name: conf [7778,7782]
name: conf [7778,7782]
===
match
---
name: env [4779,4782]
name: env [4779,4782]
===
match
---
trailer [2469,2478]
trailer [2469,2478]
===
match
---
name: int [8727,8730]
name: int [8727,8730]
===
match
---
simple_stmt [24653,24793]
simple_stmt [24750,24890]
===
match
---
fstring_start: f" [19743,19745]
fstring_start: f" [19840,19842]
===
match
---
trailer [23360,23362]
trailer [23457,23459]
===
match
---
simple_stmt [4249,4265]
simple_stmt [4249,4265]
===
match
---
param [17064,17085]
param [17161,17182]
===
match
---
trailer [13576,13598]
trailer [13561,13583]
===
match
---
atom_expr [10032,10050]
atom_expr [10032,10050]
===
match
---
name: _tasks_list_to_task_ids [23092,23115]
name: _tasks_list_to_task_ids [23189,23212]
===
match
---
name: operator [19032,19040]
name: operator [19129,19137]
===
match
---
comparison [7831,7858]
comparison [7831,7858]
===
match
---
tfpdef [4528,4557]
tfpdef [4528,4557]
===
match
---
for_stmt [15560,15775]
for_stmt [15657,15872]
===
match
---
trailer [21878,21905]
trailer [21975,22002]
===
match
---
operator: = [3111,3112]
operator: = [3111,3112]
===
match
---
name: _sync_parallelism [24443,24460]
name: _sync_parallelism [24540,24557]
===
match
---
suite [14720,14774]
suite [14817,14871]
===
match
---
name: request [3130,3137]
name: request [3130,3137]
===
match
---
trailer [6001,6013]
trailer [6001,6013]
===
match
---
except_clause [6924,6942]
except_clause [6924,6942]
===
match
---
arglist [24081,24100]
arglist [24178,24197]
===
match
---
expr_stmt [4945,5001]
expr_stmt [4945,5001]
===
match
---
trailer [21084,21086]
trailer [21181,21183]
===
match
---
name: FAILED [14766,14772]
name: FAILED [14863,14869]
===
match
---
trailer [24417,24461]
trailer [24514,24558]
===
match
---
parameters [5701,5742]
parameters [5701,5742]
===
match
---
suite [7088,20025]
suite [7088,20122]
===
match
---
trailer [4719,4787]
trailer [4719,4787]
===
match
---
trailer [14896,14898]
trailer [14993,14995]
===
match
---
dotted_name [6664,6674]
dotted_name [6664,6674]
===
match
---
name: traceback [6126,6135]
name: traceback [6126,6135]
===
match
---
simple_stmt [3145,3191]
simple_stmt [3145,3191]
===
match
---
parameters [22476,22495]
parameters [22573,22592]
===
match
---
operator: = [8232,8233]
operator: = [8232,8233]
===
match
---
name: self [11417,11421]
name: self [11417,11421]
===
match
---
dotted_name [3786,3808]
dotted_name [3786,3808]
===
match
---
number: 0 [19052,19053]
number: 0 [19149,19150]
===
match
---
name: airflow [6800,6807]
name: airflow [6800,6807]
===
match
---
operator: = [24251,24252]
operator: = [24348,24349]
===
match
---
simple_stmt [5831,5861]
simple_stmt [5831,5861]
===
match
---
name: key [16021,16024]
name: key [16118,16121]
===
match
---
name: error [4921,4926]
name: error [4921,4926]
===
match
---
atom_expr [2604,2654]
atom_expr [2604,2654]
===
match
---
name: task_adoption_timeout [14585,14606]
name: task_adoption_timeout [14682,14703]
===
match
---
operator: -> [20082,20084]
operator: -> [20179,20181]
===
match
---
simple_stmt [10008,10051]
simple_stmt [10008,10051]
===
match
---
operator: + [11157,11158]
operator: + [11157,11158]
===
match
---
atom_expr [8140,8180]
atom_expr [8140,8180]
===
match
---
name: values [15494,15500]
name: values [15591,15597]
===
match
---
atom_expr [19235,19267]
atom_expr [19332,19364]
===
match
---
name: isinstance [11055,11065]
name: isinstance [11055,11065]
===
match
---
simple_stmt [18830,18857]
simple_stmt [18927,18954]
===
match
---
trailer [2608,2619]
trailer [2608,2619]
===
match
---
name: result [22062,22068]
name: result [22159,22165]
===
match
---
name: self [15338,15342]
name: self [15435,15439]
===
match
---
name: result [22391,22397]
name: result [22488,22494]
===
match
---
atom_expr [20085,20136]
atom_expr [20182,20233]
===
match
---
name: filter [23318,23324]
name: filter [23415,23421]
===
match
---
trailer [4809,4828]
trailer [4809,4828]
===
match
---
atom_expr [21797,21806]
atom_expr [21894,21903]
===
match
---
name: task_cls [23325,23333]
name: task_cls [23422,23430]
===
match
---
name: default_celery [1684,1698]
name: default_celery [1684,1698]
===
match
---
name: incr [10561,10565]
name: incr [10561,10565]
===
match
---
name: keys [22604,22608]
name: keys [22701,22705]
===
match
---
atom_expr [15394,15404]
atom_expr [15491,15501]
===
match
---
name: exception [4320,4329]
name: exception [4320,4329]
===
match
---
name: app [23388,23391]
name: app [23485,23488]
===
match
---
name: key [16668,16671]
name: key [16765,16768]
===
match
---
atom_expr [14409,14682]
atom_expr [14506,14779]
===
match
---
number: 1.0 [24587,24590]
number: 1.0 [24684,24687]
===
match
---
atom_expr [23418,23432]
atom_expr [23515,23529]
===
match
---
atom_expr [19529,19535]
atom_expr [19626,19632]
===
match
---
name: tasks [16951,16956]
name: tasks [17048,17053]
===
match
---
operator: = [2793,2794]
operator: = [2793,2794]
===
match
---
simple_stmt [3836,3867]
simple_stmt [3836,3867]
===
match
---
name: result [19616,19622]
name: result [19713,19719]
===
match
---
operator: , [17054,17055]
operator: , [17151,17152]
===
match
---
expr_stmt [5865,5910]
expr_stmt [5865,5910]
===
match
---
trailer [4017,4028]
trailer [4017,4028]
===
match
---
atom_expr [15182,15227]
atom_expr [15279,15324]
===
match
---
name: self [16477,16481]
name: self [16574,16578]
===
match
---
suite [8554,8661]
suite [8554,8661]
===
match
---
name: next [9858,9862]
name: next [9858,9862]
===
match
---
dotted_name [6740,6754]
dotted_name [6740,6754]
===
match
---
trailer [6013,6042]
trailer [6013,6042]
===
match
---
arglist [14934,15022]
arglist [15031,15119]
===
match
---
name: queue [6036,6041]
name: queue [6036,6041]
===
match
---
trailer [16315,16320]
trailer [16412,16417]
===
match
---
operator: = [17192,17193]
operator: = [17289,17290]
===
match
---
name: self [8205,8209]
name: self [8205,8209]
===
match
---
name: List [1213,1217]
name: List [1213,1217]
===
match
---
name: EventBufferValueType [23045,23065]
name: EventBufferValueType [23142,23162]
===
match
---
name: items [15219,15224]
name: items [15316,15321]
===
match
---
trailer [2810,2839]
trailer [2810,2839]
===
match
---
name: TaskInstanceKey [15808,15823]
name: TaskInstanceKey [15905,15920]
===
match
---
trailer [16171,16179]
trailer [16268,16276]
===
match
---
fstring_end: " [3188,3189]
fstring_end: " [3188,3189]
===
match
---
atom_expr [17285,17344]
atom_expr [17382,17441]
===
match
---
atom_expr [9520,9558]
atom_expr [9520,9558]
===
match
---
for_stmt [9325,9663]
for_stmt [9325,9663]
===
match
---
name: Mapping [21871,21878]
name: Mapping [21968,21975]
===
match
---
trailer [22075,22101]
trailer [22172,22198]
===
match
---
simple_stmt [16584,16589]
simple_stmt [16681,16686]
===
match
---
trailer [9339,9380]
trailer [9339,9380]
===
match
---
name: TaskInstanceKey [8385,8400]
name: TaskInstanceKey [8385,8400]
===
match
---
trailer [15196,15218]
trailer [15293,15315]
===
match
---
dotted_name [2172,2193]
dotted_name [2172,2193]
===
match
---
name: get [15670,15673]
name: get [15767,15770]
===
match
---
atom_expr [10966,10992]
atom_expr [10966,10992]
===
match
---
operator: -> [24353,24355]
operator: -> [24450,24452]
===
match
---
atom_expr [9334,9380]
atom_expr [9334,9380]
===
match
---
operator: , [14562,14563]
operator: , [14659,14660]
===
match
---
name: e [4305,4306]
name: e [4305,4306]
===
match
---
string: "\n\t" [14980,14986]
string: "\n\t" [15077,15083]
===
match
---
testlist [21104,21178]
testlist [21201,21275]
===
match
---
name: queued_tasks [10971,10983]
name: queued_tasks [10971,10983]
===
match
---
name: adopted [19781,19788]
name: adopted [19878,19885]
===
match
---
operator: { [4220,4221]
operator: { [4220,4221]
===
match
---
atom_expr [11115,11208]
atom_expr [11115,11208]
===
match
---
term [24587,24636]
term [24684,24733]
===
match
---
dictorsetmaker [21797,21827]
dictorsetmaker [21894,21924]
===
match
---
arglist [20874,20894]
arglist [20971,20991]
===
match
---
expr_stmt [19802,19842]
expr_stmt [19899,19939]
===
match
---
atom_expr [3919,3931]
atom_expr [3919,3931]
===
match
---
simple_stmt [22334,22420]
simple_stmt [22431,22517]
===
match
---
suite [11098,11271]
suite [11098,11271]
===
match
---
name: self [24614,24618]
name: self [24711,24715]
===
match
---
atom_expr [23202,23213]
atom_expr [23299,23310]
===
match
---
operator: , [20965,20966]
operator: , [21062,21063]
===
match
---
name: key [11754,11757]
name: key [11754,11757]
===
match
---
trailer [5787,5824]
trailer [5787,5824]
===
match
---
name: airflow [6766,6773]
name: airflow [6766,6773]
===
match
---
trailer [12892,12898]
trailer [12892,12898]
===
match
---
name: repr [14996,15000]
name: repr [15093,15097]
===
match
---
name: _get_many_from_kv_backend [22451,22476]
name: _get_many_from_kv_backend [22548,22573]
===
match
---
name: parser [3910,3916]
name: parser [3910,3916]
===
match
---
param [15797,15802]
param [15894,15899]
===
match
---
import_from [1183,1271]
import_from [1183,1271]
===
match
---
simple_stmt [9628,9663]
simple_stmt [9628,9663]
===
match
---
atom_expr [19149,19176]
atom_expr [19246,19273]
===
match
---
operator: , [18790,18791]
operator: , [18887,18888]
===
match
---
atom_expr [19032,19054]
atom_expr [19129,19151]
===
match
---
name: airflow [2134,2141]
name: airflow [2134,2141]
===
match
---
name: num_process [24508,24519]
name: num_process [24605,24616]
===
match
---
trailer [12448,12474]
trailer [12448,12474]
===
match
---
name: _prepare_state_and_info_by_task_dict [23676,23712]
name: _prepare_state_and_info_by_task_dict [23773,23809]
===
match
---
funcdef [7449,8525]
funcdef [7449,8525]
===
match
---
name: typing [1188,1194]
name: typing [1188,1194]
===
match
---
operator: { [3172,3173]
operator: { [3172,3173]
===
match
---
trailer [22009,22048]
trailer [22106,22145]
===
match
---
operator: , [2706,2707]
operator: , [2706,2707]
===
match
---
name: _get_many_from_kv_backend [22076,22101]
name: _get_many_from_kv_backend [22173,22198]
===
match
---
simple_stmt [22671,22703]
simple_stmt [22768,22800]
===
match
---
operator: -> [9035,9037]
operator: -> [9035,9037]
===
match
---
name: get_parser [3919,3929]
name: get_parser [3919,3929]
===
match
---
trailer [25071,25269]
trailer [25168,25366]
===
match
---
name: models [1940,1946]
name: models [1940,1946]
===
match
---
if_stmt [4607,4679]
if_stmt [4607,4679]
===
match
---
name: backend [22014,22021]
name: backend [22111,22118]
===
match
---
trailer [7757,7775]
trailer [7757,7775]
===
match
---
parameters [15271,15277]
parameters [15368,15374]
===
match
---
operator: , [24924,24925]
operator: , [25021,25022]
===
match
---
operator: / [24612,24613]
operator: / [24709,24710]
===
match
---
name: external_executor_id [18729,18749]
name: external_executor_id [18826,18846]
===
match
---
trailer [15218,15224]
trailer [15315,15321]
===
match
---
not_test [12856,12870]
not_test [12856,12870]
===
match
---
simple_stmt [12404,12475]
simple_stmt [12404,12475]
===
match
---
name: traceback [25237,25246]
name: traceback [25334,25343]
===
match
---
string: "Fetched %d state(s) for %d task(s)" [22349,22385]
string: "Fetched %d state(s) for %d task(s)" [22446,22482]
===
match
---
operator: , [22481,22482]
operator: , [22578,22579]
===
match
---
name: task [2884,2888]
name: task [2884,2888]
===
match
---
name: append [19736,19742]
name: append [19833,19839]
===
match
---
name: task [23438,23442]
name: task [23535,23539]
===
match
---
name: command [9400,9407]
name: command [9400,9407]
===
match
---
comparison [9574,9610]
comparison [9574,9610]
===
match
---
arglist [8286,8333]
arglist [8286,8333]
===
match
---
trailer [10253,10285]
trailer [10253,10285]
===
match
---
name: isinstance [21999,22009]
name: isinstance [22096,22106]
===
match
---
expr_stmt [2743,2787]
expr_stmt [2743,2787]
===
match
---
name: task [23418,23422]
name: task [23515,23519]
===
match
---
trailer [11129,11208]
trailer [11129,11208]
===
match
---
name: task_results_by_task_id [23732,23755]
name: task_results_by_task_id [23829,23852]
===
match
---
arglist [3277,3308]
arglist [3277,3308]
===
match
---
fstring_string: \n [21061,21063]
fstring_string: \n [21158,21160]
===
match
---
atom_expr [11417,11432]
atom_expr [11417,11432]
===
match
---
trailer [3898,3900]
trailer [3898,3900]
===
match
---
atom_expr [8380,8406]
atom_expr [8380,8406]
===
match
---
string: 'info' [20888,20894]
string: 'info' [20985,20991]
===
match
---
operator: , [8160,8161]
operator: , [8160,8161]
===
match
---
operator: += [10920,10922]
operator: += [10920,10922]
===
match
---
param [5707,5740]
param [5707,5740]
===
match
---
name: key [14755,14758]
name: key [14852,14855]
===
match
---
operator: , [21613,21614]
operator: , [21710,21711]
===
match
---
simple_stmt [22891,22975]
simple_stmt [22988,23072]
===
match
---
operator: , [9417,9418]
operator: , [9417,9418]
===
match
---
name: sync [12825,12829]
name: sync [12825,12829]
===
match
---
simple_stmt [17215,17271]
simple_stmt [17312,17368]
===
match
---
name: debug [10149,10154]
name: debug [10149,10154]
===
match
---
name: self [7831,7835]
name: self [7831,7835]
===
match
---
subscriptlist [8145,8179]
subscriptlist [8145,8179]
===
match
---
name: backend [23392,23399]
name: backend [23489,23496]
===
match
---
name: traceback [1048,1057]
name: traceback [1048,1057]
===
match
---
atom_expr [9360,9377]
atom_expr [9360,9377]
===
match
---
name: env [4579,4582]
name: env [4579,4582]
===
match
---
name: meta_from_decoded [23400,23417]
name: meta_from_decoded [23497,23514]
===
match
---
arith_expr [19539,19582]
arith_expr [19636,19679]
===
match
---
name: BaseKeyValueStoreBackend [1363,1387]
name: BaseKeyValueStoreBackend [1363,1387]
===
match
---
string: 'celery' [7790,7798]
string: 'celery' [7790,7798]
===
match
---
funcdef [8994,9749]
funcdef [8994,9749]
===
match
---
trailer [17015,17017]
trailer [17112,17114]
===
match
---
param [23010,23015]
param [23107,23112]
===
match
---
name: celery_tasks [18713,18725]
name: celery_tasks [18810,18822]
===
match
---
name: local_task_job [6714,6728]
name: local_task_job [6714,6728]
===
match
---
operator: , [19701,19702]
operator: , [19798,19799]
===
match
---
name: celery_states [1316,1329]
name: celery_states [1316,1329]
===
match
---
atom_expr [10731,10761]
atom_expr [10731,10761]
===
match
---
trailer [10914,10919]
trailer [10914,10919]
===
match
---
operator: , [1456,1457]
operator: , [1456,1457]
===
match
---
operator: -> [22496,22498]
operator: -> [22593,22595]
===
match
---
name: super [7477,7482]
name: super [7477,7482]
===
match
---
simple_stmt [19802,19843]
simple_stmt [19899,19940]
===
match
---
operator: , [24852,24853]
operator: , [24949,24950]
===
match
---
name: ret [3756,3759]
name: ret [3756,3759]
===
match
---
name: celery_task_id [19307,19321]
name: celery_task_id [19404,19418]
===
match
---
parameters [21608,21637]
parameters [21705,21734]
===
match
---
param [16043,16054]
param [16140,16151]
===
match
---
parameters [9772,9827]
parameters [9772,9827]
===
match
---
name: EventBufferValueType [23778,23798]
name: EventBufferValueType [23875,23895]
===
match
---
arglist [25097,25247]
arglist [25194,25344]
===
match
---
name: bulk_state_fetcher [7934,7952]
name: bulk_state_fetcher [7934,7952]
===
match
---
try_stmt [16129,16788]
try_stmt [16226,16885]
===
match
---
operator: = [8521,8522]
operator: = [8521,8522]
===
match
---
simple_stmt [15623,15696]
simple_stmt [15720,15793]
===
match
---
name: state_and_info_by_celery_task_id [15637,15669]
name: state_and_info_by_celery_task_id [15734,15766]
===
match
---
atom [10426,10533]
atom [10426,10533]
===
match
---
expr_stmt [24161,24190]
expr_stmt [24258,24287]
===
match
---
operator: = [4583,4584]
operator: = [4583,4584]
===
match
---
trailer [21663,21665]
trailer [21760,21762]
===
match
---
simple_stmt [10060,10132]
simple_stmt [10060,10132]
===
match
---
dotted_name [6766,6788]
dotted_name [6766,6788]
===
match
---
operator: , [21882,21883]
operator: , [21979,21980]
===
match
---
atom [6019,6028]
atom [6019,6028]
===
match
---
name: celery_configuration [2660,2680]
name: celery_configuration [2660,2680]
===
match
---
trailer [3708,3710]
trailer [3708,3710]
===
match
---
name: List [9800,9804]
name: List [9800,9804]
===
match
---
comparison [11288,11306]
comparison [11288,11306]
===
match
---
suite [5919,6043]
suite [5919,6043]
===
match
---
expr_stmt [23183,23234]
expr_stmt [23280,23331]
===
match
---
operator: = [12662,12663]
operator: = [12662,12663]
===
match
---
name: now [13639,13642]
name: now [13736,13739]
===
match
---
name: self [14737,14741]
name: self [14834,14838]
===
match
---
trailer [15756,15774]
trailer [15853,15871]
===
match
---
name: str [23040,23043]
name: str [23137,23140]
===
match
---
simple_stmt [3717,3751]
simple_stmt [3717,3751]
===
match
---
name: task_to_run [5990,6001]
name: task_to_run [5990,6001]
===
match
---
atom_expr [25312,25347]
atom_expr [25409,25444]
===
match
---
name: task_result [24081,24092]
name: task_result [24178,24189]
===
match
---
name: self [7462,7466]
name: self [7462,7466]
===
match
---
name: seconds [8266,8273]
name: seconds [8266,8273]
===
match
---
string: 'task_publish_max_retries' [8485,8511]
string: 'task_publish_max_retries' [8485,8511]
===
match
---
name: celery_task_id [19202,19216]
name: celery_task_id [19299,19313]
===
match
---
simple_stmt [2445,2524]
simple_stmt [2445,2524]
===
match
---
name: tasks [15007,15012]
name: tasks [15104,15109]
===
match
---
simple_stmt [23565,23649]
simple_stmt [23662,23746]
===
match
---
suite [18696,18796]
suite [18793,18893]
===
match
---
name: celery_states [16907,16920]
name: celery_states [17004,17017]
===
match
---
name: tis [18937,18940]
name: tis [19034,19037]
===
match
---
simple_stmt [24547,24640]
simple_stmt [24644,24737]
===
match
---
name: TaskInstance [17457,17469]
name: TaskInstance [17554,17566]
===
match
---
suite [23991,24127]
suite [24088,24224]
===
match
---
simple_stmt [8353,8423]
simple_stmt [8353,8423]
===
match
---
trailer [23399,23417]
trailer [23496,23514]
===
match
---
expr_stmt [3096,3140]
expr_stmt [3096,3140]
===
match
---
operator: , [25138,25139]
operator: , [25235,25236]
===
match
---
name: self [7972,7976]
name: self [7972,7976]
===
match
---
name: List [9284,9288]
name: List [9284,9288]
===
match
---
name: cpu_count [7904,7913]
name: cpu_count [7904,7913]
===
match
---
trailer [11330,11338]
trailer [11330,11338]
===
match
---
funcdef [17350,17384]
funcdef [17447,17481]
===
match
---
name: join [14987,14991]
name: join [15084,15088]
===
match
---
simple_stmt [8913,8989]
simple_stmt [8913,8989]
===
match
---
number: 3 [9865,9866]
number: 3 [9865,9866]
===
match
---
simple_stmt [24161,24191]
simple_stmt [24258,24288]
===
match
---
simple_stmt [20002,20025]
simple_stmt [20099,20122]
===
match
---
subscriptlist [5788,5823]
subscriptlist [5788,5823]
===
match
---
trailer [21678,21696]
trailer [21775,21793]
===
match
---
sync_comp_for [21807,21827]
sync_comp_for [21904,21924]
===
match
---
trailer [22338,22342]
trailer [22435,22439]
===
match
---
simple_stmt [12953,12960]
simple_stmt [12953,12960]
===
match
---
atom [18753,18795]
atom [18850,18892]
===
match
---
operator: = [2518,2519]
operator: = [2518,2519]
===
match
---
operator: , [7798,7799]
operator: , [7798,7799]
===
match
---
trailer [12972,12995]
trailer [12972,12995]
===
match
---
simple_stmt [9263,9316]
simple_stmt [9263,9316]
===
match
---
expr_stmt [7929,7995]
expr_stmt [7929,7995]
===
match
---
operator: = [8407,8408]
operator: = [8407,8408]
===
match
---
name: ti [19289,19291]
name: ti [19386,19388]
===
match
---
expr_stmt [9845,9897]
expr_stmt [9845,9897]
===
match
---
name: args [4128,4132]
name: args [4128,4132]
===
match
---
trailer [7484,7493]
trailer [7484,7493]
===
match
---
suite [16074,16788]
suite [16171,16885]
===
match
---
name: math [24577,24581]
name: math [24674,24678]
===
match
---
name: config_source [2841,2854]
name: config_source [2841,2854]
===
match
---
name: key [9394,9397]
name: key [9394,9397]
===
match
---
operator: -> [23029,23031]
operator: -> [23126,23128]
===
match
---
arglist [19695,19714]
arglist [19792,19811]
===
match
---
subscriptlist [24849,24874]
subscriptlist [24946,24971]
===
match
---
atom_expr [22499,22533]
atom_expr [22596,22630]
===
match
---
suite [23067,23649]
suite [23164,23746]
===
match
---
arglist [16508,16517]
arglist [16605,16614]
===
match
---
name: values [19069,19075]
name: values [19166,19172]
===
match
---
name: celery_task_id [3362,3376]
name: celery_task_id [3362,3376]
===
match
---
name: CommandType [17103,17114]
name: CommandType [17200,17211]
===
match
---
name: not_adopted_tis [18600,18615]
name: not_adopted_tis [18697,18712]
===
match
---
argument [4779,4786]
argument [4779,4786]
===
match
---
trailer [23356,23360]
trailer [23453,23457]
===
match
---
import_from [1927,1996]
import_from [1927,1996]
===
match
---
name: self [15394,15398]
name: self [15491,15495]
===
match
---
if_stmt [3596,3628]
if_stmt [3596,3628]
===
match
---
atom_expr [9356,9378]
atom_expr [9356,9378]
===
match
---
trailer [10565,10594]
trailer [10565,10594]
===
match
---
trailer [10893,10914]
trailer [10893,10914]
===
match
---
name: isinstance [22130,22140]
name: isinstance [22227,22237]
===
match
---
dotted_name [6836,6860]
dotted_name [6836,6860]
===
match
---
testlist_star_expr [5865,5897]
testlist_star_expr [5865,5897]
===
match
---
trailer [8467,8474]
trailer [8467,8474]
===
match
---
atom_expr [8931,8986]
atom_expr [8931,8986]
===
match
---
funcdef [23672,24291]
funcdef [23769,24388]
===
match
---
simple_stmt [2321,2386]
simple_stmt [2321,2386]
===
match
---
name: pid [3505,3508]
name: pid [3505,3508]
===
match
---
name: state [15711,15716]
name: state [15808,15813]
===
match
---
parameters [16014,16065]
parameters [16111,16162]
===
match
---
operator: , [16324,16325]
operator: , [16421,16422]
===
match
---
tfpdef [17064,17084]
tfpdef [17161,17181]
===
match
---
operator: -> [16066,16068]
operator: -> [16163,16165]
===
match
---
name: bash [6784,6788]
name: bash [6784,6788]
===
match
---
operator: , [11931,11932]
operator: , [11931,11932]
===
match
---
name: subprocess [1018,1028]
name: subprocess [1018,1028]
===
match
---
arglist [15886,15902]
arglist [15983,15999]
===
match
---
name: log [11120,11123]
name: log [11120,11123]
===
match
---
suite [24391,25417]
suite [24488,25514]
===
match
---
name: map [12696,12699]
name: map [12696,12699]
===
match
---
param [17124,17152]
param [17221,17249]
===
match
---
atom_expr [19028,19078]
atom_expr [19125,19175]
===
match
---
simple_stmt [4058,4089]
simple_stmt [4058,4089]
===
match
---
trailer [22140,22170]
trailer [22237,22267]
===
match
---
for_stmt [10183,11964]
for_stmt [10183,11964]
===
match
---
number: 0 [7857,7858]
number: 0 [7857,7858]
===
match
---
param [12001,12048]
param [12001,12048]
===
match
---
name: task_results [22711,22723]
name: task_results [22808,22820]
===
match
---
operator: ** [6317,6319]
operator: ** [6317,6319]
===
match
---
simple_stmt [4273,4281]
simple_stmt [4273,4281]
===
match
---
name: timezone [2228,2236]
name: timezone [2228,2236]
===
match
---
operator: , [17422,17423]
operator: , [17519,17520]
===
match
---
import_from [1094,1144]
import_from [1094,1144]
===
match
---
string: 'celery' [2698,2706]
string: 'celery' [2698,2706]
===
match
---
name: self [13010,13014]
name: self [13010,13014]
===
match
---
name: add [11392,11395]
name: add [11392,11395]
===
match
---
expr_stmt [10008,10050]
expr_stmt [10008,10050]
===
match
---
expr_stmt [24008,24037]
expr_stmt [24105,24134]
===
match
---
dotted_name [2214,2236]
dotted_name [2214,2236]
===
match
---
suite [24534,25375]
suite [24631,25472]
===
match
---
trailer [6135,6146]
trailer [6135,6146]
===
match
---
operator: + [4985,4986]
operator: + [4985,4986]
===
match
---
atom [9469,9507]
atom [9469,9507]
===
match
---
name: conf [2683,2687]
name: conf [2683,2687]
===
match
---
name: subdag [6854,6860]
name: subdag [6854,6860]
===
match
---
name: command_to_exec [3075,3090]
name: command_to_exec [3075,3090]
===
match
---
name: str [21775,21778]
name: str [21872,21875]
===
match
---
operator: -> [21868,21870]
operator: -> [21965,21967]
===
match
---
name: task_results_by_task_id [22786,22809]
name: task_results_by_task_id [22883,22906]
===
match
---
name: seconds [5941,5948]
name: seconds [5941,5948]
===
match
---
name: shut_down_logging [4063,4080]
name: shut_down_logging [4063,4080]
===
match
---
name: str [15832,15835]
name: str [15929,15932]
===
match
---
name: backend [22145,22152]
name: backend [22242,22249]
===
match
---
expr_stmt [22543,22595]
expr_stmt [22640,22692]
===
match
---
simple_stmt [13519,13538]
simple_stmt [13622,13641]
===
match
---
atom_expr [3447,3460]
atom_expr [3447,3460]
===
match
---
name: task_ids [23614,23622]
name: task_ids [23711,23719]
===
match
---
argument [8321,8333]
argument [8321,8333]
===
match
---
operator: -> [17449,17451]
operator: -> [17546,17548]
===
match
---
name: key [13550,13553]
name: key [13653,13656]
===
match
---
trailer [15594,15600]
trailer [15691,15697]
===
match
---
trailer [10110,10131]
trailer [10110,10131]
===
match
---
operator: } [6122,6123]
operator: } [6122,6123]
===
match
---
trailer [16726,16736]
trailer [16823,16833]
===
match
---
trailer [23205,23213]
trailer [23302,23310]
===
match
---
name: math [24566,24570]
name: math [24663,24667]
===
match
---
trailer [20873,20895]
trailer [20970,20992]
===
match
---
atom_expr [12449,12473]
atom_expr [12449,12473]
===
match
---
name: first_task [9845,9855]
name: first_task [9845,9855]
===
match
---
trailer [22223,22238]
trailer [22320,22335]
===
match
---
string: "Adopted the following %d tasks from a dead executor\n\t%s" [19886,19945]
string: "Adopted the following %d tasks from a dead executor\n\t%s" [19983,20042]
===
match
---
name: e [4364,4365]
name: e [4364,4365]
===
match
---
name: copy [4596,4600]
name: copy [4596,4600]
===
match
---
name: getLogger [2266,2275]
name: getLogger [2266,2275]
===
match
---
operator: , [15930,15931]
operator: , [16027,16028]
===
match
---
atom_expr [7778,7819]
atom_expr [7778,7819]
===
match
---
number: 5 [16995,16996]
number: 5 [17092,17093]
===
match
---
operator: = [19537,19538]
operator: = [19634,19635]
===
match
---
suite [12627,12779]
suite [12627,12779]
===
match
---
name: log [3031,3034]
name: log [3031,3034]
===
match
---
trailer [7782,7789]
trailer [7782,7789]
===
match
---
trailer [23158,23172]
trailer [23255,23269]
===
match
---
name: app [2789,2792]
name: app [2789,2792]
===
match
---
operator: , [20094,20095]
operator: , [20191,20192]
===
match
---
suite [9695,9749]
suite [9695,9749]
===
match
---
name: self [9360,9364]
name: self [9360,9364]
===
match
---
atom_expr [13050,13089]
atom_expr [13050,13089]
===
match
---
name: celery_tasks [18574,18586]
name: celery_tasks [18671,18683]
===
match
---
operator: = [15635,15636]
operator: = [15732,15733]
===
match
---
atom_expr [7929,7952]
atom_expr [7929,7952]
===
match
---
trailer [3851,3856]
trailer [3851,3856]
===
match
---
trailer [15398,15404]
trailer [15495,15501]
===
match
---
name: Mapping [23765,23772]
name: Mapping [23862,23869]
===
match
---
name: backends [1400,1408]
name: backends [1400,1408]
===
match
---
atom_expr [19335,19349]
atom_expr [19432,19446]
===
match
---
suite [3608,3628]
suite [3608,3628]
===
match
---
fstring_string: airflow task supervisor:  [4195,4220]
fstring_string: airflow task supervisor:  [4195,4220]
===
match
---
exprlist [15564,15581]
exprlist [15661,15678]
===
match
---
simple_stmt [25312,25375]
simple_stmt [25409,25472]
===
match
---
name: self [11995,11999]
name: self [11995,11999]
===
match
---
simple_stmt [17279,17345]
simple_stmt [17376,17442]
===
match
---
operator: = [21697,21698]
operator: = [21794,21795]
===
match
---
trailer [3659,3711]
trailer [3659,3711]
===
match
---
atom_expr [10787,10816]
atom_expr [10787,10816]
===
match
---
atom_expr [23032,23066]
atom_expr [23129,23163]
===
match
---
trailer [16558,16566]
trailer [16655,16663]
===
match
---
name: TaskInstanceKey [8145,8160]
name: TaskInstanceKey [8145,8160]
===
match
---
arglist [11066,11096]
arglist [11066,11096]
===
match
---
name: result [6241,6247]
name: result [6241,6247]
===
match
---
name: ceil [24582,24586]
name: ceil [24679,24683]
===
match
---
annassign [9282,9315]
annassign [9282,9315]
===
match
---
name: self [11005,11009]
name: self [11005,11009]
===
match
---
funcdef [16793,17018]
funcdef [16890,17115]
===
match
---
trailer [22197,22223]
trailer [22294,22320]
===
match
---
simple_stmt [9456,9508]
simple_stmt [9456,9508]
===
match
---
name: fallback [8321,8329]
name: fallback [8321,8329]
===
match
---
arglist [16637,16678]
arglist [16734,16775]
===
match
---
operator: , [11917,11918]
operator: , [11917,11918]
===
match
---
name: task_ids [22543,22551]
name: task_ids [22640,22648]
===
match
---
simple_stmt [19728,19769]
simple_stmt [19825,19866]
===
match
---
name: airflow [1772,1779]
name: airflow [1772,1779]
===
match
---
atom_expr [15002,15020]
atom_expr [15099,15117]
===
match
---
name: task_id [23880,23887]
name: task_id [23977,23984]
===
match
---
testlist_star_expr [19281,19291]
testlist_star_expr [19378,19388]
===
match
---
name: synchronous [16807,16818]
name: synchronous [16904,16915]
===
match
---
name: celery_import_modules [1557,1578]
name: celery_import_modules [1557,1578]
===
match
---
trailer [22310,22325]
trailer [22407,22422]
===
match
---
name: TaskInstanceKey [16026,16041]
name: TaskInstanceKey [16123,16138]
===
match
---
name: execute_command [2893,2908]
name: execute_command [2893,2908]
===
match
---
arglist [12503,12551]
arglist [12503,12551]
===
match
---
string: """Updates state of a single task.""" [16083,16120]
string: """Updates state of a single task.""" [16180,16217]
===
match
---
operator: , [3561,3562]
operator: , [3561,3562]
===
match
---
name: get_hostname [2116,2128]
name: get_hostname [2116,2128]
===
match
---
parameters [21748,21767]
parameters [21845,21864]
===
match
---
simple_stmt [5865,5911]
simple_stmt [5865,5911]
===
match
---
trailer [4457,4463]
trailer [4457,4463]
===
match
---
funcdef [5676,6248]
funcdef [5676,6248]
===
match
---
trailer [16481,16503]
trailer [16578,16600]
===
match
---
name: command_to_exec [2909,2924]
name: command_to_exec [2909,2924]
===
match
---
simple_stmt [10966,10993]
simple_stmt [10966,10993]
===
match
---
parameters [23712,23761]
parameters [23809,23858]
===
match
---
simple_stmt [4696,4788]
simple_stmt [4696,4788]
===
match
---
name: str [20102,20105]
name: str [20199,20202]
===
match
---
operator: , [11072,11073]
operator: , [11072,11073]
===
match
---
simple_stmt [23183,23235]
simple_stmt [23280,23332]
===
match
---
name: external_executor_id [18769,18789]
name: external_executor_id [18866,18886]
===
match
---
trailer [4600,4602]
trailer [4600,4602]
===
match
---
simple_stmt [12968,12998]
simple_stmt [12968,12998]
===
match
---
operator: = [18616,18617]
operator: = [18713,18714]
===
match
---
atom_expr [21126,21172]
atom_expr [21223,21269]
===
match
---
trailer [15393,15405]
trailer [15490,15502]
===
match
---
atom_expr [5419,5433]
atom_expr [5419,5433]
===
match
---
suite [2738,2788]
suite [2738,2788]
===
match
---
parameters [20054,20081]
parameters [20151,20178]
===
match
---
name: task_results_by_task_id [23624,23647]
name: task_results_by_task_id [23721,23744]
===
match
---
simple_stmt [2743,2788]
simple_stmt [2743,2788]
===
match
---
operator: } [23555,23556]
operator: } [23652,23653]
===
match
---
name: key_and_async_results [12794,12815]
name: key_and_async_results [12794,12815]
===
match
---
tfpdef [17124,17144]
tfpdef [17221,17241]
===
match
---
atom_expr [2465,2523]
atom_expr [2465,2523]
===
match
---
simple_stmt [1997,2029]
simple_stmt [1997,2029]
===
match
---
trailer [11065,11097]
trailer [11065,11097]
===
match
---
param [22477,22482]
param [22574,22579]
===
match
---
trailer [4846,4856]
trailer [4846,4856]
===
match
---
expr_stmt [18600,18620]
expr_stmt [18697,18717]
===
match
---
atom_expr [15390,15405]
atom_expr [15487,15502]
===
match
---
operator: , [15628,15629]
operator: , [15725,15726]
===
match
---
funcdef [8530,8661]
funcdef [8530,8661]
===
match
---
trailer [21148,21172]
trailer [21245,21269]
===
match
---
name: tis [18640,18643]
name: tis [18737,18740]
===
match
---
name: pop [9437,9440]
name: pop [9437,9440]
===
match
---
name: max [7897,7900]
name: max [7897,7900]
===
match
---
trailer [22640,22643]
trailer [22737,22740]
===
match
---
name: debug [12893,12898]
name: debug [12893,12898]
===
match
---
name: adopted_task_timeouts [15134,15155]
name: adopted_task_timeouts [15231,15252]
===
match
---
name: QUEUED [11768,11774]
name: QUEUED [11768,11774]
===
match
---
trailer [12099,12117]
trailer [12099,12117]
===
match
---
operator: } [4236,4237]
operator: } [4236,4237]
===
match
---
parameters [17363,17369]
parameters [17460,17466]
===
match
---
operator: = [6166,6167]
operator: = [6166,6167]
===
match
---
string: "No Async execution for Celery executor." [17302,17343]
string: "No Async execution for Celery executor." [17399,17440]
===
match
---
param [11995,12000]
param [11995,12000]
===
match
---
name: setproctitle [1604,1616]
name: setproctitle [1604,1616]
===
match
---
name: task_id [21117,21124]
name: task_id [21214,21221]
===
match
---
name: logging [4428,4435]
name: logging [4428,4435]
===
match
---
name: append [18846,18852]
name: append [18943,18949]
===
match
---
operator: = [13499,13500]
operator: = [13499,13500]
===
match
---
suite [3477,4469]
suite [3477,4469]
===
match
---
subscriptlist [20091,20135]
subscriptlist [20188,20232]
===
match
---
testlist [20925,20971]
testlist [21022,21068]
===
match
---
name: os [1008,1010]
name: os [1008,1010]
===
match
---
operator: , [19224,19225]
operator: , [19321,19322]
===
match
---
name: self [15590,15594]
name: self [15687,15691]
===
match
---
atom [13535,13537]
atom [13638,13640]
===
match
---
trailer [11197,11207]
trailer [11197,11207]
===
match
---
trailer [23172,23174]
trailer [23269,23271]
===
match
---
trailer [11256,11263]
trailer [11256,11263]
===
match
---
trailer [23391,23399]
trailer [23488,23496]
===
match
---
name: ti [18853,18855]
name: ti [18950,18952]
===
match
---
expr_stmt [9456,9507]
expr_stmt [9456,9507]
===
match
---
name: stalled_after [13555,13568]
name: stalled_after [13658,13671]
===
match
---
trailer [19528,19536]
trailer [19625,19633]
===
match
---
operator: { [19759,19760]
operator: { [19856,19857]
===
match
---
name: str [24364,24367]
name: str [24461,24464]
===
match
---
name: _execute_in_fork [3328,3344]
name: _execute_in_fork [3328,3344]
===
match
---
string: ":%s\n%s\n" [25127,25138]
string: ":%s\n%s\n" [25224,25235]
===
match
---
name: OPERATION_TIMEOUT [2445,2462]
name: OPERATION_TIMEOUT [2445,2462]
===
match
---
string: "info" [24094,24100]
string: "info" [24191,24197]
===
match
---
trailer [19950,19959]
trailer [20047,20056]
===
match
---
name: app [22612,22615]
name: app [22709,22712]
===
match
---
atom_expr [21999,22048]
atom_expr [22096,22145]
===
match
---
arglist [2802,2875]
arglist [2802,2875]
===
match
---
operator: , [17084,17085]
operator: , [17181,17182]
===
match
---
operator: , [1891,1892]
operator: , [1891,1892]
===
match
---
simple_stmt [2660,2733]
simple_stmt [2660,2733]
===
match
---
trailer [11753,11758]
trailer [11753,11758]
===
match
---
name: self [9012,9016]
name: self [9012,9016]
===
match
---
simple_stmt [9520,9559]
simple_stmt [9520,9559]
===
match
---
param [7462,7466]
param [7462,7466]
===
match
---
number: 3 [8522,8523]
number: 3 [8522,8523]
===
match
---
name: state [24161,24166]
name: state [24258,24263]
===
match
---
simple_stmt [3621,3628]
simple_stmt [3621,3628]
===
match
---
try_stmt [5915,6215]
try_stmt [5915,6215]
===
match
---
suite [2947,3378]
suite [2947,3378]
===
match
---
name: _get_many_from_db_backend [22198,22223]
name: _get_many_from_db_backend [22295,22320]
===
match
---
trailer [19599,19605]
trailer [19696,19702]
===
match
---
import_name [6793,6824]
import_name [6793,6824]
===
match
---
name: settings [3199,3207]
name: settings [3199,3207]
===
match
---
atom_expr [16311,16331]
atom_expr [16408,16428]
===
match
---
suite [16606,16680]
suite [16703,16777]
===
match
---
name: key [11243,11246]
name: key [11243,11246]
===
match
---
operator: = [22810,22811]
operator: = [22907,22908]
===
match
---
operator: , [24564,24565]
operator: , [24661,24662]
===
match
---
dotted_name [1479,1492]
dotted_name [1479,1492]
===
match
---
operator: , [20105,20106]
operator: , [20202,20203]
===
match
---
operator: = [22191,22192]
operator: = [22288,22289]
===
match
---
name: PENDING [24183,24190]
name: PENDING [24280,24287]
===
match
---
atom_expr [24169,24190]
atom_expr [24266,24287]
===
match
---
name: ti [19746,19748]
name: ti [19843,19845]
===
match
---
simple_stmt [3637,3712]
simple_stmt [3637,3712]
===
match
---
name: self [12529,12533]
name: self [12529,12533]
===
match
---
expr_stmt [4634,4678]
expr_stmt [4634,4678]
===
match
---
simple_stmt [18600,18621]
simple_stmt [18697,18718]
===
match
---
comp_op [16900,16906]
comp_op [16997,17003]
===
match
---
operator: } [23866,23867]
operator: } [23963,23964]
===
match
---
name: key [11428,11431]
name: key [11428,11431]
===
match
---
number: 1.0 [2519,2522]
number: 1.0 [2519,2522]
===
match
---
trailer [9862,9897]
trailer [9862,9897]
===
match
---
trailer [15589,15609]
trailer [15686,15706]
===
match
---
expr_stmt [24806,24880]
expr_stmt [24903,24977]
===
match
---
atom_expr [9424,9443]
atom_expr [9424,9443]
===
match
---
atom_expr [2802,2839]
atom_expr [2802,2839]
===
match
---
name: backend [11331,11338]
name: backend [11331,11338]
===
match
---
suite [10369,10954]
suite [10369,10954]
===
match
---
operator: , [3073,3074]
operator: , [3073,3074]
===
match
---
atom_expr [10396,10421]
atom_expr [10396,10421]
===
match
---
except_clause [7018,7036]
except_clause [7018,7036]
===
match
---
name: app [23147,23150]
name: app [23244,23247]
===
match
---
name: task_id [25339,25346]
name: task_id [25436,25443]
===
match
---
atom_expr [19595,19613]
atom_expr [19692,19710]
===
match
---
name: key [16508,16511]
name: key [16605,16608]
===
match
---
simple_stmt [24207,24219]
simple_stmt [24304,24316]
===
match
---
name: info [15050,15054]
name: info [15147,15151]
===
match
---
param [5384,5408]
param [5384,5408]
===
match
---
name: _num_tasks_per_send_process [12421,12448]
name: _num_tasks_per_send_process [12421,12448]
===
match
---
atom_expr [24593,24611]
atom_expr [24690,24708]
===
match
---
trailer [23772,23799]
trailer [23869,23896]
===
match
---
import_name [958,972]
import_name [958,972]
===
match
---
atom_expr [4249,4264]
atom_expr [4249,4264]
===
match
---
atom_expr [24834,24875]
atom_expr [24931,24972]
===
match
---
expr_stmt [2387,2443]
expr_stmt [2387,2443]
===
match
---
operator: { [21063,21064]
operator: { [21160,21161]
===
match
---
name: format_exc [21074,21084]
name: format_exc [21171,21181]
===
match
---
atom_expr [4843,4908]
atom_expr [4843,4908]
===
match
---
name: task_adoption_timeout [19561,19582]
name: task_adoption_timeout [19658,19679]
===
match
---
trailer [16722,16726]
trailer [16819,16823]
===
match
---
atom_expr [24577,24637]
atom_expr [24674,24734]
===
match
---
operator: , [1304,1305]
operator: , [1304,1305]
===
match
---
expr_stmt [23076,23128]
expr_stmt [23173,23225]
===
match
---
simple_stmt [13787,13793]
simple_stmt [13884,13890]
===
match
---
name: pop [10984,10987]
name: pop [10984,10987]
===
match
---
operator: = [12753,12754]
operator: = [12753,12754]
===
match
---
simple_stmt [24008,24038]
simple_stmt [24105,24135]
===
match
---
trailer [10452,10473]
trailer [10452,10473]
===
match
---
operator: , [25368,25369]
operator: , [25465,25466]
===
match
---
name: self [10486,10490]
name: self [10486,10490]
===
match
---
trailer [8008,8014]
trailer [8008,8014]
===
match
---
operator: , [4526,4527]
operator: , [4526,4527]
===
match
---
string: "executor.tasks (%d)\n\t%s" [14934,14961]
string: "executor.tasks (%d)\n\t%s" [15031,15058]
===
match
---
operator: = [21631,21632]
operator: = [21728,21729]
===
match
---
arith_expr [3660,3710]
arith_expr [3660,3710]
===
match
---
simple_stmt [1001,1011]
simple_stmt [1001,1011]
===
match
---
name: self [22071,22075]
name: self [22168,22172]
===
match
---
import_as_names [1967,1996]
import_as_names [1967,1996]
===
match
---
trailer [25182,25192]
trailer [25279,25289]
===
match
---
atom_expr [11933,11962]
atom_expr [11933,11962]
===
match
---
simple_stmt [6694,6729]
simple_stmt [6694,6729]
===
match
---
expr_stmt [8205,8344]
expr_stmt [8205,8344]
===
match
---
name: TaskInstanceInCelery [9289,9309]
name: TaskInstanceInCelery [9289,9309]
===
match
---
atom_expr [16623,16679]
atom_expr [16720,16776]
===
match
---
atom_expr [21871,21905]
atom_expr [21968,22002]
===
match
---
name: self [13050,13054]
name: self [13050,13054]
===
match
---
name: func [4254,4258]
name: func [4254,4258]
===
match
---
atom_expr [11891,11963]
atom_expr [11891,11963]
===
match
---
name: self [7929,7933]
name: self [7929,7933]
===
match
---
name: async_results [24743,24756]
name: async_results [24840,24853]
===
match
---
operator: @ [2879,2880]
operator: @ [2879,2880]
===
match
---
atom_expr [15450,15503]
atom_expr [15547,15600]
===
match
---
trailer [16956,16963]
trailer [17053,17060]
===
match
---
name: values [22765,22771]
name: values [22862,22868]
===
match
---
string: 'Celery command failed on host: ' [3660,3693]
string: 'Celery command failed on host: ' [3660,3693]
===
match
---
operator: = [2414,2415]
operator: = [2414,2415]
===
match
---
operator: , [11263,11264]
operator: , [11263,11264]
===
match
---
arglist [16210,16219]
arglist [16307,16316]
===
match
---
name: result [22265,22271]
name: result [22362,22368]
===
match
---
trailer [15054,15239]
trailer [15151,15336]
===
match
---
name: self [9216,9220]
name: self [9216,9220]
===
match
---
string: ": %s\n%s\n" [11159,11171]
string: ": %s\n%s\n" [11159,11171]
===
match
---
trailer [12668,12778]
trailer [12668,12778]
===
match
---
name: celery_states [16158,16171]
name: celery_states [16255,16268]
===
match
---
atom_expr [3254,3309]
atom_expr [3254,3309]
===
match
---
dotted_name [1517,1531]
dotted_name [1517,1531]
===
match
---
operator: , [23622,23623]
operator: , [23719,23720]
===
match
---
import_name [6759,6788]
import_name [6759,6788]
===
match
---
trailer [23263,23272]
trailer [23360,23369]
===
match
---
trailer [15176,15181]
trailer [15273,15278]
===
match
---
return_stmt [20918,20971]
return_stmt [21015,21068]
===
match
---
trailer [19148,19177]
trailer [19245,19274]
===
match
---
import_as_names [1798,1834]
import_as_names [1798,1834]
===
match
---
trailer [2806,2810]
trailer [2806,2810]
===
match
---
name: utils [2180,2185]
name: utils [2180,2185]
===
match
---
simple_stmt [17379,17384]
simple_stmt [17476,17481]
===
match
---
suite [21906,22442]
suite [22003,22539]
===
match
---
param [24338,24351]
param [24435,24448]
===
match
---
name: exception_traceback [5384,5403]
name: exception_traceback [5384,5403]
===
match
---
name: MutableMapping [1228,1242]
name: MutableMapping [1228,1242]
===
match
---
param [16801,16806]
param [16898,16903]
===
match
---
operator: , [10705,10706]
operator: , [10705,10706]
===
match
---
arglist [11130,11207]
arglist [11130,11207]
===
match
---
import_from [2029,2085]
import_from [2029,2085]
===
match
---
fstring [4193,4238]
fstring [4193,4238]
===
match
---
atom_expr [16197,16220]
atom_expr [16294,16317]
===
match
---
name: debug_dump [14886,14896]
name: debug_dump [14983,14993]
===
match
---
name: async_results [24597,24610]
name: async_results [24694,24707]
===
match
---
trailer [11179,11189]
trailer [11179,11189]
===
match
---
comparison [3599,3607]
comparison [3599,3607]
===
match
---
testlist_comp [9400,9420]
testlist_comp [9400,9420]
===
match
---
name: self [8563,8567]
name: self [8563,8567]
===
match
---
suite [13037,13090]
suite [13037,13090]
===
match
---
name: join [15177,15181]
name: join [15274,15278]
===
match
---
atom_expr [2683,2732]
atom_expr [2683,2732]
===
match
---
name: command_to_exec [3010,3025]
name: command_to_exec [3010,3025]
===
match
---
name: task_ids [23346,23354]
name: task_ids [23443,23451]
===
match
---
trailer [19651,19659]
trailer [19748,19756]
===
match
---
arglist [4330,4366]
arglist [4330,4366]
===
match
---
trailer [3571,3579]
trailer [3571,3579]
===
match
---
param [15272,15276]
param [15369,15373]
===
match
---
name: getattr [11933,11940]
name: getattr [11933,11940]
===
match
---
suite [6884,6920]
suite [6884,6920]
===
match
---
operator: = [19820,19821]
operator: = [19917,19918]
===
match
---
name: state_or_exception [24992,25010]
name: state_or_exception [25089,25107]
===
match
---
trailer [3129,3137]
trailer [3129,3137]
===
match
---
if_stmt [9672,9749]
if_stmt [9672,9749]
===
match
---
arith_expr [4951,5001]
arith_expr [4951,5001]
===
match
---
name: error [14418,14423]
name: error [14515,14520]
===
match
---
parameters [6309,6326]
parameters [6309,6326]
===
match
---
name: has_option [2609,2619]
name: has_option [2609,2619]
===
match
---
name: celery_states [16248,16261]
name: celery_states [16345,16358]
===
match
---
name: AirflowException [5016,5032]
name: AirflowException [5016,5032]
===
match
---
name: Mapping [24356,24363]
name: Mapping [24453,24460]
===
match
---
tfpdef [2909,2937]
tfpdef [2909,2937]
===
match
---
name: ExceptionWithTraceback [11074,11096]
name: ExceptionWithTraceback [11074,11096]
===
match
---
name: subprocess [4799,4809]
name: subprocess [4799,4809]
===
match
---
trailer [14986,14991]
trailer [15083,15088]
===
match
---
operator: , [6192,6193]
operator: , [6192,6193]
===
match
---
trailer [20937,20945]
trailer [21034,21042]
===
match
---
operator: , [22398,22399]
operator: , [22495,22496]
===
match
---
name: self [8637,8641]
name: self [8637,8641]
===
match
---
atom_expr [22387,22398]
atom_expr [22484,22495]
===
match
---
trailer [10735,10756]
trailer [10735,10756]
===
match
---
trailer [10042,10050]
trailer [10042,10050]
===
match
---
param [16807,16832]
param [16904,16929]
===
match
---
name: Union [1266,1271]
name: Union [1266,1271]
===
match
---
operator: -> [15278,15280]
operator: -> [15375,15377]
===
match
---
name: self [8353,8357]
name: self [8353,8357]
===
match
---
trailer [12065,12086]
trailer [12065,12086]
===
match
---
trailer [24118,24126]
trailer [24215,24223]
===
match
---
name: open_slots [9018,9028]
name: open_slots [9018,9028]
===
match
---
trailer [10477,10482]
trailer [10477,10482]
===
match
---
simple_stmt [16311,16332]
simple_stmt [16408,16429]
===
match
---
name: task_results [23372,23384]
name: task_results [23469,23481]
===
match
---
simple_stmt [1835,1927]
simple_stmt [1835,1927]
===
match
---
name: list [12664,12668]
name: list [12664,12668]
===
match
---
trailer [16631,16636]
trailer [16728,16733]
===
match
---
funcdef [21834,22442]
funcdef [21931,22539]
===
match
---
trailer [23422,23430]
trailer [23519,23527]
===
match
---
name: len [12503,12506]
name: len [12503,12506]
===
match
---
operator: = [10030,10031]
operator: = [10030,10031]
===
match
---
trailer [23201,23234]
trailer [23298,23331]
===
match
---
subscriptlist [20102,20129]
subscriptlist [20199,20226]
===
match
---
simple_stmt [19855,19993]
simple_stmt [19952,20090]
===
match
---
name: Optional [5653,5661]
name: Optional [5653,5661]
===
match
---
tfpdef [3431,3460]
tfpdef [3431,3460]
===
match
---
operator: , [8511,8512]
operator: , [8511,8512]
===
match
---
name: async_result [20055,20067]
name: async_result [20152,20164]
===
match
---
for_stmt [13546,14370]
for_stmt [13649,14467]
===
match
---
atom_expr [22334,22419]
atom_expr [22431,22516]
===
match
---
trailer [22403,22418]
trailer [22500,22515]
===
match
---
name: TaskDb [23227,23233]
name: TaskDb [23324,23330]
===
match
---
suite [6966,7014]
suite [6966,7014]
===
match
---
name: result [11191,11197]
name: result [11191,11197]
===
match
---
operator: -> [16834,16836]
operator: -> [16931,16933]
===
match
---
name: fallback [2510,2518]
name: fallback [2510,2518]
===
match
---
atom [19109,19111]
atom [19206,19208]
===
match
---
suite [24144,24219]
suite [24241,24316]
===
match
---
simple_stmt [5594,5674]
simple_stmt [5594,5674]
===
match
---
atom_expr [14878,14898]
atom_expr [14975,14995]
===
match
---
operator: , [15000,15001]
operator: , [15097,15098]
===
match
---
name: task_result [22813,22824]
name: task_result [22910,22921]
===
match
---
atom_expr [19947,19959]
atom_expr [20044,20056]
===
match
---
trailer [23307,23317]
trailer [23404,23414]
===
match
---
trailer [15916,15922]
trailer [16013,16019]
===
match
---
name: states_and_info_by_task_id [24806,24832]
name: states_and_info_by_task_id [24903,24929]
===
match
---
expr_stmt [2660,2732]
expr_stmt [2660,2732]
===
match
---
operator: , [24336,24337]
operator: , [24433,24434]
===
match
---
operator: = [2256,2257]
operator: = [2256,2257]
===
match
---
name: len [15390,15393]
name: len [15487,15490]
===
match
---
name: result [19335,19341]
name: result [19432,19438]
===
match
---
name: Dict [8140,8144]
name: Dict [8140,8144]
===
match
---
atom_expr [3031,3091]
atom_expr [3031,3091]
===
match
---
simple_stmt [10945,10954]
simple_stmt [10945,10954]
===
match
---
atom_expr [13501,13509]
atom_expr [13501,13509]
===
match
---
parameters [17417,17448]
parameters [17514,17545]
===
match
---
name: async_result [20845,20857]
name: async_result [20942,20954]
===
match
---
operator: , [16511,16512]
operator: , [16608,16609]
===
match
---
name: traceback [5459,5468]
name: traceback [5459,5468]
===
match
---
atom_expr [18660,18683]
atom_expr [18757,18780]
===
match
---
name: ti [19695,19697]
name: ti [19792,19794]
===
match
---
atom_expr [7904,7915]
atom_expr [7904,7915]
===
match
---
simple_stmt [15295,15330]
simple_stmt [15392,15427]
===
match
---
operator: = [12598,12599]
operator: = [12598,12599]
===
match
---
name: settings [3875,3883]
name: settings [3875,3883]
===
match
---
name: Set [21771,21774]
name: Set [21868,21871]
===
match
---
name: get [2807,2810]
name: get [2807,2810]
===
match
---
param [15825,15836]
param [15922,15933]
===
match
---
operator: = [22724,22725]
operator: = [22821,22822]
===
match
---
trailer [24586,24637]
trailer [24683,24734]
===
match
---
trailer [4595,4600]
trailer [4595,4600]
===
match
---
name: _send_tasks_to_celery [10089,10110]
name: _send_tasks_to_celery [10089,10110]
===
match
---
atom_expr [23388,23433]
atom_expr [23485,23530]
===
match
---
name: self [14907,14911]
name: self [15004,15008]
===
match
---
expr_stmt [19502,19582]
expr_stmt [19599,19679]
===
match
---
arglist [2698,2731]
arglist [2698,2731]
===
match
---
trailer [19259,19265]
trailer [19356,19362]
===
match
---
name: Task [5668,5672]
name: Task [5668,5672]
===
match
---
name: keys [22697,22701]
name: keys [22794,22798]
===
match
---
trailer [8209,8231]
trailer [8209,8231]
===
match
---
trailer [8577,8660]
trailer [8577,8660]
===
match
---
name: log [15518,15521]
name: log [15615,15618]
===
match
---
expr_stmt [4579,4602]
expr_stmt [4579,4602]
===
match
---
comparison [16238,16293]
comparison [16335,16390]
===
match
---
suite [5410,5491]
suite [5410,5491]
===
match
---
atom_expr [8183,8196]
atom_expr [8183,8196]
===
match
---
expr_stmt [18574,18591]
expr_stmt [18671,18688]
===
match
---
trailer [4999,5001]
trailer [4999,5001]
===
match
---
name: log [15046,15049]
name: log [15143,15146]
===
match
---
suite [5069,5491]
suite [5069,5491]
===
match
---
atom_expr [19294,19322]
atom_expr [19391,19419]
===
match
---
trailer [8420,8422]
trailer [8420,8422]
===
match
---
operator: = [20843,20844]
operator: = [20940,20941]
===
match
---
name: timeout [2186,2193]
name: timeout [2186,2193]
===
match
---
name: command_to_exec [4498,4513]
name: command_to_exec [4498,4513]
===
match
---
name: states_and_info_by_task_id [25390,25416]
name: states_and_info_by_task_id [25487,25513]
===
match
---
arglist [16321,16330]
arglist [16418,16427]
===
match
---
string: "external_executor_id" [4638,4660]
string: "external_executor_id" [4638,4660]
===
match
---
funcdef [11969,12816]
funcdef [11969,12816]
===
match
---
name: numpy [6900,6905]
name: numpy [6900,6905]
===
match
---
name: self [15483,15487]
name: self [15580,15584]
===
match
---
operator: * [6310,6311]
operator: * [6310,6311]
===
match
---
simple_stmt [958,973]
simple_stmt [958,973]
===
match
---
atom_expr [3145,3190]
atom_expr [3145,3190]
===
match
---
suite [18813,18857]
suite [18910,18954]
===
match
---
suite [13138,14774]
suite [13138,14871]
===
match
---
atom_expr [12860,12870]
atom_expr [12860,12870]
===
match
---
name: ret [4376,4379]
name: ret [4376,4379]
===
match
---
name: str [4360,4363]
name: str [4360,4363]
===
match
---
atom_expr [19539,19553]
atom_expr [19636,19650]
===
match
---
name: msg [5033,5036]
name: msg [5033,5036]
===
match
---
dotted_name [6701,6728]
dotted_name [6701,6728]
===
match
---
name: backend [23151,23158]
name: backend [23248,23255]
===
match
---
arglist [14755,14772]
arglist [14852,14869]
===
match
---
atom_expr [24614,24636]
atom_expr [24711,24733]
===
match
---
name: items [15013,15018]
name: items [15110,15115]
===
match
---
trailer [6146,6148]
trailer [6146,6148]
===
match
---
trailer [15049,15054]
trailer [15146,15151]
===
match
---
name: self [5454,5458]
name: self [5454,5458]
===
match
---
simple_stmt [3875,3901]
simple_stmt [3875,3901]
===
match
---
atom [16247,16293]
atom [16344,16390]
===
match
---
operator: = [11759,11760]
operator: = [11759,11760]
===
match
---
trailer [15527,15551]
trailer [15624,15648]
===
match
---
trailer [15673,15695]
trailer [15770,15792]
===
match
---
classdef [5040,5491]
classdef [5040,5491]
===
match
---
trailer [19166,19173]
trailer [19263,19270]
===
match
---
name: parser [4011,4017]
name: parser [4011,4017]
===
match
---
operator: = [5948,5949]
operator: = [5948,5949]
===
match
---
import_name [6657,6674]
import_name [6657,6674]
===
match
---
name: stats [2010,2015]
name: stats [2010,2015]
===
match
---
name: task_result [23528,23539]
name: task_result [23625,23636]
===
match
---
operator: , [1226,1227]
operator: , [1226,1227]
===
match
---
name: getattr [23194,23201]
name: getattr [23291,23298]
===
match
---
suite [25036,25270]
suite [25133,25367]
===
match
---
name: timedout_keys [14653,14666]
name: timedout_keys [14750,14763]
===
match
---
atom_expr [4987,5001]
atom_expr [4987,5001]
===
match
---
name: states_by_celery_task_id [18950,18974]
name: states_by_celery_task_id [19047,19071]
===
match
---
atom_expr [11762,11774]
atom_expr [11762,11774]
===
match
---
trailer [3009,3026]
trailer [3009,3026]
===
match
---
atom [24878,24880]
atom [24975,24977]
===
match
---
string: "\n\t" [15170,15176]
string: "\n\t" [15267,15273]
===
match
---
trailer [5622,5673]
trailer [5622,5673]
===
match
---
atom_expr [18726,18749]
atom_expr [18823,18846]
===
match
---
number: 1 [12121,12122]
number: 1 [12121,12122]
===
match
---
arglist [22349,22418]
arglist [22446,22515]
===
match
---
name: AirflowException [1798,1814]
name: AirflowException [1798,1814]
===
match
---
name: airflow [2091,2098]
name: airflow [2091,2098]
===
match
---
import_name [6975,6999]
import_name [6975,6999]
===
match
---
atom_expr [3643,3711]
atom_expr [3643,3711]
===
match
---
name: self [22898,22902]
name: self [22995,22999]
===
match
---
simple_stmt [5074,5338]
simple_stmt [5074,5338]
===
match
---
number: 1 [8924,8925]
number: 1 [8924,8925]
===
match
---
suite [25291,25375]
suite [25388,25472]
===
match
---
name: settings [3836,3844]
name: settings [3836,3844]
===
match
---
simple_stmt [1058,1094]
simple_stmt [1058,1094]
===
match
---
trailer [14920,15032]
trailer [15017,15129]
===
match
---
name: k [22641,22642]
name: k [22738,22739]
===
match
---
name: self [15272,15276]
name: self [15369,15373]
===
match
---
name: len [14963,14966]
name: len [15060,15063]
===
match
---
trailer [9546,9558]
trailer [9546,9558]
===
match
---
name: tasks [15917,15922]
name: tasks [16014,16019]
===
match
---
dictorsetmaker [22813,22880]
dictorsetmaker [22910,22977]
===
match
---
atom_expr [8234,8344]
atom_expr [8234,8344]
===
match
---
name: exception_traceback [6194,6213]
name: exception_traceback [6194,6213]
===
match
---
atom_expr [11225,11247]
atom_expr [11225,11247]
===
match
---
name: task_result [22853,22864]
name: task_result [22950,22961]
===
match
---
name: t [9863,9864]
name: t [9863,9864]
===
match
---
tfpdef [5707,5739]
tfpdef [5707,5739]
===
match
---
string: "[Try %s of %s] Task Timeout Error for Task: (%s)." [10654,10705]
string: "[Try %s of %s] Task Timeout Error for Task: (%s)." [10654,10705]
===
match
---
simple_stmt [2086,2129]
simple_stmt [2086,2129]
===
match
---
atom_expr [8463,8524]
atom_expr [8463,8524]
===
match
---
expr_stmt [21007,21088]
expr_stmt [21104,21185]
===
match
---
name: success [16202,16209]
name: success [16299,16306]
===
match
---
atom_expr [8162,8179]
atom_expr [8162,8179]
===
match
---
if_stmt [12059,12272]
if_stmt [12059,12272]
===
match
---
name: state_or_exception [25218,25236]
name: state_or_exception [25315,25333]
===
match
---
suite [6327,7051]
suite [6327,7051]
===
match
---
operator: = [4662,4663]
operator: = [4662,4663]
===
match
---
name: state [20960,20965]
name: state [21057,21062]
===
match
---
name: state [16536,16541]
name: state [16633,16638]
===
match
---
name: sync_parallelism [21699,21715]
name: sync_parallelism [21796,21812]
===
match
---
suite [16380,16519]
suite [16477,16616]
===
match
---
name: celery_task_id [3431,3445]
name: celery_task_id [3431,3445]
===
match
---
operator: = [24212,24213]
operator: = [24309,24310]
===
match
---
simple_stmt [12787,12816]
simple_stmt [12787,12816]
===
match
---
name: Exception [6054,6063]
name: Exception [6054,6063]
===
match
---
import_name [973,984]
import_name [973,984]
===
match
---
trailer [16920,16933]
trailer [17017,17030]
===
match
---
argument [6014,6028]
argument [6014,6028]
===
match
---
name: key [15977,15980]
name: key [16074,16077]
===
match
---
atom_expr [8920,8988]
atom_expr [8920,8988]
===
match
---
trailer [10154,10173]
trailer [10154,10173]
===
match
---
name: airflow [6740,6747]
name: airflow [6740,6747]
===
match
---
name: timedelta [8243,8252]
name: timedelta [8243,8252]
===
match
---
param [15837,15846]
param [15934,15943]
===
match
---
trailer [10324,10334]
trailer [10324,10334]
===
match
---
name: _get_many_using_multiprocessing [22279,22310]
name: _get_many_using_multiprocessing [22376,22407]
===
match
---
expr_stmt [4004,4049]
expr_stmt [4004,4049]
===
match
---
name: start [8534,8539]
name: start [8534,8539]
===
match
---
name: celery_task_id [4610,4624]
name: celery_task_id [4610,4624]
===
match
---
name: key [15757,15760]
name: key [15854,15857]
===
match
---
decorated [6250,7051]
decorated [6250,7051]
===
match
---
simple_stmt [22428,22442]
simple_stmt [22525,22539]
===
match
---
string: 'info' [11949,11955]
string: 'info' [11949,11955]
===
match
---
suite [4307,4384]
suite [4307,4384]
===
match
---
param [23016,23027]
param [23113,23124]
===
match
---
trailer [3039,3091]
trailer [3039,3091]
===
match
---
sync_comp_for [22756,22776]
sync_comp_for [22853,22873]
===
match
---
name: getint [8279,8285]
name: getint [8279,8285]
===
match
---
operator: = [24412,24413]
operator: = [24509,24510]
===
match
---
name: chunksize [12754,12763]
name: chunksize [12754,12763]
===
match
---
atom [18589,18591]
atom [18686,18688]
===
match
---
name: tis [17424,17427]
name: tis [17521,17524]
===
match
---
suite [22252,22326]
suite [22349,22423]
===
match
---
if_stmt [4097,4171]
if_stmt [4097,4171]
===
match
---
name: flush [4412,4417]
name: flush [4412,4417]
===
match
---
name: self [14580,14584]
name: self [14677,14681]
===
match
---
operator: = [23085,23086]
operator: = [23182,23183]
===
match
---
name: airflow [1659,1666]
name: airflow [1659,1666]
===
match
---
atom_expr [25164,25192]
atom_expr [25261,25289]
===
match
---
simple_stmt [9052,9193]
simple_stmt [9052,9193]
===
match
---
name: task_result [22837,22848]
name: task_result [22934,22945]
===
match
---
trailer [15473,15482]
trailer [15570,15579]
===
match
---
name: command_to_exec [3345,3360]
name: command_to_exec [3345,3360]
===
match
---
trailer [5661,5666]
trailer [5661,5666]
===
match
---
simple_stmt [18713,18796]
simple_stmt [18810,18893]
===
match
---
operator: = [9214,9215]
operator: = [9214,9215]
===
match
---
suite [12871,12960]
suite [12871,12960]
===
match
---
name: info [15837,15841]
name: info [15934,15938]
===
match
---
expr_stmt [15623,15695]
expr_stmt [15720,15792]
===
match
---
simple_stmt [15041,15240]
simple_stmt [15138,15337]
===
match
---
trailer [7482,7484]
trailer [7482,7484]
===
match
---
name: log [14414,14417]
name: log [14511,14514]
===
match
---
name: info [3035,3039]
name: info [3035,3039]
===
match
---
trailer [16988,16994]
trailer [17085,17091]
===
match
---
string: """     Fetch and return the state of the given celery task. The scope of this function is     global so that it can be called by subprocesses in the pool.      :param async_result: a tuple of the Celery task key and the async Celery object used         to fetch the task's state     :type async_result: tuple(str, celery.result.AsyncResult)     :return: a tuple of the Celery task key and the Celery state and the celery info         of the task     :rtype: tuple[str, str, str]     """ [20142,20629]
string: """     Fetch and return the state of the given celery task. The scope of this function is     global so that it can be called by subprocesses in the pool.      :param async_result: a tuple of the Celery task key and the async Celery object used         to fetch the task's state     :type async_result: tuple(str, celery.result.AsyncResult)     :return: a tuple of the Celery task key and the Celery state and the celery info         of the task     :rtype: tuple[str, str, str]     """ [20239,20726]
===
match
---
name: State [2161,2166]
name: State [2161,2166]
===
match
---
atom_expr [15125,15156]
atom_expr [15222,15253]
===
match
---
operator: , [1904,1905]
operator: , [1904,1905]
===
match
---
operator: , [11171,11172]
operator: , [11171,11172]
===
match
---
trailer [2801,2876]
trailer [2801,2876]
===
match
---
simple_stmt [4376,4384]
simple_stmt [4376,4384]
===
match
---
name: tasks [12865,12870]
name: tasks [12865,12870]
===
match
---
atom [22812,22881]
atom [22909,22978]
===
match
---
operator: , [12527,12528]
operator: , [12527,12528]
===
match
---
name: result [11066,11072]
name: result [11066,11072]
===
match
---
name: __init__ [21655,21663]
name: __init__ [21752,21760]
===
match
---
trailer [16963,16965]
trailer [17060,17062]
===
match
---
name: e [4832,4833]
name: e [4832,4833]
===
match
---
name: log [10620,10623]
name: log [10620,10623]
===
match
---
operator: , [8319,8320]
operator: , [8319,8320]
===
match
---
name: subprocess [4696,4706]
name: subprocess [4696,4706]
===
match
---
name: _tasks_list_to_task_ids [22559,22582]
name: _tasks_list_to_task_ids [22656,22679]
===
match
---
name: adopted [19728,19735]
name: adopted [19825,19832]
===
match
---
trailer [15606,15608]
trailer [15703,15705]
===
match
---
name: app [22010,22013]
name: app [22107,22110]
===
match
---
name: self [9708,9712]
name: self [9708,9712]
===
match
---
simple_stmt [2252,2286]
simple_stmt [2252,2286]
===
match
---
suite [8731,8989]
suite [8731,8989]
===
match
---
atom_expr [4696,4787]
atom_expr [4696,4787]
===
match
---
name: logging [965,972]
name: logging [965,972]
===
match
---
name: str [17140,17143]
name: str [17237,17240]
===
match
---
decorator [23654,23668]
decorator [23751,23765]
===
match
---
operator: , [5877,5878]
operator: , [5877,5878]
===
match
---
name: celery_task_id [3173,3187]
name: celery_task_id [3173,3187]
===
match
---
operator: = [15448,15449]
operator: = [15545,15546]
===
match
---
operator: , [19054,19055]
operator: , [19151,19152]
===
match
---
atom_expr [4455,4468]
atom_expr [4455,4468]
===
match
---
name: ti [19606,19608]
name: ti [19703,19705]
===
match
---
expr_stmt [10060,10131]
expr_stmt [10060,10131]
===
match
---
atom_expr [10290,10368]
atom_expr [10290,10368]
===
match
---
name: self [21674,21678]
name: self [21771,21775]
===
match
---
name: v [22775,22776]
name: v [22872,22873]
===
match
---
name: self [15797,15801]
name: self [15894,15898]
===
match
---
name: args [6014,6018]
name: args [6014,6018]
===
match
---
param [21749,21754]
param [21846,21851]
===
match
---
strings [14441,14562]
strings [14538,14659]
===
match
---
operator: , [19959,19960]
operator: , [20056,20057]
===
match
---
name: backend [22731,22738]
name: backend [22828,22835]
===
match
---
name: CommandType [5640,5651]
name: CommandType [5640,5651]
===
match
---
testlist_comp [23388,23451]
testlist_comp [23485,23548]
===
match
---
name: current_task [3117,3129]
name: current_task [3117,3129]
===
match
---
operator: , [23839,23840]
operator: , [23936,23937]
===
match
---
operator: == [12087,12089]
operator: == [12087,12089]
===
match
---
atom_expr [2258,2285]
atom_expr [2258,2285]
===
match
---
name: state [15623,15628]
name: state [15720,15725]
===
match
---
atom_expr [19056,19077]
atom_expr [19153,19174]
===
match
---
simple_stmt [6893,6920]
simple_stmt [6893,6920]
===
match
---
trailer [5458,5468]
trailer [5458,5468]
===
match
---
operator: , [5666,5667]
operator: , [5666,5667]
===
match
---
name: key [15803,15806]
name: key [15900,15903]
===
match
---
simple_stmt [2029,2086]
simple_stmt [2029,2086]
===
match
---
name: celery [1335,1341]
name: celery [1335,1341]
===
match
---
name: AirflowTaskTimeout [1816,1834]
name: AirflowTaskTimeout [1816,1834]
===
match
---
name: synchronous [16854,16865]
name: synchronous [16951,16962]
===
match
---
atom_expr [7972,7994]
atom_expr [7972,7994]
===
match
---
return_stmt [12211,12271]
return_stmt [12211,12271]
===
match
---
number: 0 [4279,4280]
number: 0 [4279,4280]
===
match
---
param [16015,16020]
param [16112,16117]
===
match
---
trailer [15926,15937]
trailer [16023,16034]
===
match
---
name: self [11379,11383]
name: self [11379,11383]
===
match
---
atom_expr [16718,16787]
atom_expr [16815,16884]
===
match
---
name: str [23773,23776]
name: str [23870,23873]
===
match
---
trailer [2697,2732]
trailer [2697,2732]
===
match
---
operator: , [16041,16042]
operator: , [16138,16139]
===
match
---
atom_expr [22898,22974]
atom_expr [22995,23071]
===
match
---
name: self [11115,11119]
name: self [11115,11119]
===
match
---
arglist [15186,15226]
arglist [15283,15323]
===
match
---
name: async_result [20874,20886]
name: async_result [20971,20983]
===
match
---
trailer [14413,14417]
trailer [14510,14514]
===
match
---
atom_expr [8927,8987]
atom_expr [8927,8987]
===
match
---
name: debug [8572,8577]
name: debug [8572,8577]
===
match
---
simple_stmt [20142,20630]
simple_stmt [20239,20727]
===
match
---
operator: , [2819,2820]
operator: , [2819,2820]
===
match
---
name: exception_traceback [5471,5490]
name: exception_traceback [5471,5490]
===
match
---
name: conf [8274,8278]
name: conf [8274,8278]
===
match
---
name: task_results_by_task_id [23461,23484]
name: task_results_by_task_id [23558,23581]
===
match
---
arglist [22141,22169]
arglist [22238,22266]
===
match
---
suite [7859,7921]
suite [7859,7921]
===
match
---
atom_expr [8353,8378]
atom_expr [8353,8378]
===
match
---
name: ti [18766,18768]
name: ti [18863,18865]
===
match
---
name: self [8112,8116]
name: self [8112,8116]
===
match
---
name: adopted_task_timeouts [16482,16503]
name: adopted_task_timeouts [16579,16600]
===
match
---
trailer [12506,12527]
trailer [12506,12527]
===
match
---
trailer [4363,4366]
trailer [4363,4366]
===
match
---
simple_stmt [21007,21089]
simple_stmt [21104,21186]
===
match
---
simple_stmt [1094,1145]
simple_stmt [1094,1145]
===
match
---
name: key [9654,9657]
name: key [9654,9657]
===
match
---
name: ret [3599,3602]
name: ret [3599,3602]
===
match
---
atom_expr [24981,25035]
atom_expr [25078,25132]
===
match
---
operator: , [12248,12249]
operator: , [12248,12249]
===
match
---
name: Mapping [1219,1226]
name: Mapping [1219,1226]
===
match
---
name: self [10396,10400]
name: self [10396,10400]
===
match
---
expr_stmt [3910,3931]
expr_stmt [3910,3931]
===
match
---
operator: , [22385,22386]
operator: , [22482,22483]
===
match
---
name: command [17094,17101]
name: command [17191,17198]
===
match
---
atom_expr [22612,22643]
atom_expr [22709,22740]
===
match
---
import_from [1767,1834]
import_from [1767,1834]
===
match
---
operator: { [23865,23866]
operator: { [23962,23963]
===
match
---
name: key [11396,11399]
name: key [11396,11399]
===
match
---
name: _execute_in_fork [3384,3400]
name: _execute_in_fork [3384,3400]
===
match
---
simple_stmt [2789,2877]
simple_stmt [2789,2877]
===
match
---
trailer [15181,15228]
trailer [15278,15325]
===
match
---
name: jobs [6709,6713]
name: jobs [6709,6713]
===
match
---
suite [18886,18941]
suite [18983,19038]
===
match
---
name: EXECUTE_TASKS_NEW_PYTHON_INTERPRETER [3208,3244]
name: EXECUTE_TASKS_NEW_PYTHON_INTERPRETER [3208,3244]
===
match
---
name: running [19640,19647]
name: running [19737,19744]
===
match
---
atom_expr [9628,9658]
atom_expr [9628,9658]
===
match
---
import_from [1579,1616]
import_from [1579,1616]
===
match
---
suite [6943,6957]
suite [6943,6957]
===
match
---
atom_expr [14980,15022]
atom_expr [15077,15119]
===
match
---
simple_stmt [24400,24462]
simple_stmt [24497,24559]
===
match
---
name: _sync_parallelism [7758,7775]
name: _sync_parallelism [7758,7775]
===
match
---
name: str [4553,4556]
name: str [4553,4556]
===
match
---
operator: = [5898,5899]
operator: = [5898,5899]
===
match
---
trailer [8930,8987]
trailer [8930,8987]
===
match
---
operator: = [24680,24681]
operator: = [24777,24778]
===
match
---
atom_expr [18754,18790]
atom_expr [18851,18887]
===
match
---
name: e [21149,21150]
name: e [21246,21247]
===
match
---
trailer [14357,14364]
trailer [14454,14461]
===
match
---
name: state [11926,11931]
name: state [11926,11931]
===
match
---
simple_stmt [4634,4679]
simple_stmt [4634,4679]
===
match
---
atom_expr [22130,22170]
atom_expr [22227,22267]
===
match
---
atom_expr [11251,11263]
atom_expr [11251,11263]
===
match
---
trailer [3490,3495]
trailer [3490,3495]
===
match
---
suite [15610,15775]
suite [15707,15872]
===
match
---
name: info [15769,15773]
name: info [15866,15870]
===
match
---
name: num_process [24400,24411]
name: num_process [24497,24508]
===
match
---
trailer [4062,4080]
trailer [4062,4080]
===
match
---
name: tasks [15488,15493]
name: tasks [15585,15590]
===
match
---
simple_stmt [1579,1617]
simple_stmt [1579,1617]
===
match
---
trailer [24562,24639]
trailer [24659,24736]
===
match
---
simple_stmt [4843,4909]
simple_stmt [4843,4909]
===
match
---
name: a [21797,21798]
name: a [21894,21895]
===
match
---
atom_expr [4029,4048]
atom_expr [4029,4048]
===
match
---
trailer [8357,8378]
trailer [8357,8378]
===
match
---
dotted_name [2002,2015]
dotted_name [2002,2015]
===
match
---
name: async_results [24422,24435]
name: async_results [24519,24532]
===
match
---
atom_expr [15674,15694]
atom_expr [15771,15791]
===
match
---
name: result [11919,11925]
name: result [11919,11925]
===
match
---
operator: -> [21768,21770]
operator: -> [21865,21867]
===
match
---
simple_stmt [21223,21591]
simple_stmt [21320,21688]
===
match
---
name: result [11776,11782]
name: result [11776,11782]
===
match
---
name: _sync_parallelism [24619,24636]
name: _sync_parallelism [24716,24733]
===
match
---
atom_expr [16248,16269]
atom_expr [16345,16366]
===
match
---
name: FAILED [11257,11263]
name: FAILED [11257,11263]
===
match
---
name: not_adopted_tis [18830,18845]
name: not_adopted_tis [18927,18942]
===
match
---
name: log [15343,15346]
name: log [15440,15443]
===
match
---
name: result [1486,1492]
name: result [1486,1492]
===
match
---
name: getint [7783,7789]
name: getint [7783,7789]
===
match
---
testlist_comp [22727,22776]
testlist_comp [22824,22873]
===
match
---
atom_expr [14580,14606]
atom_expr [14677,14703]
===
match
---
string: "info" [24119,24125]
string: "info" [24216,24222]
===
match
---
trailer [22752,22755]
trailer [22849,22852]
===
match
---
name: info [20858,20862]
name: info [20955,20959]
===
match
---
comparison [16536,16566]
comparison [16633,16663]
===
match
---
name: backend [19342,19349]
name: backend [19439,19446]
===
match
---
name: format_exc [6136,6146]
name: format_exc [6136,6146]
===
match
---
simple_stmt [10889,10925]
simple_stmt [10889,10925]
===
match
---
name: state [19219,19224]
name: state [19316,19321]
===
match
---
atom_expr [9863,9867]
atom_expr [9863,9867]
===
match
---
parameters [3400,3468]
parameters [3400,3468]
===
match
---
name: log [10145,10148]
name: log [10145,10148]
===
match
---
name: state_info [24280,24290]
name: state_info [24377,24387]
===
match
---
name: state [16894,16899]
name: state [16991,16996]
===
match
---
trailer [9343,9379]
trailer [9343,9379]
===
match
---
name: log [4917,4920]
name: log [4917,4920]
===
match
---
name: MutableMapping [23821,23835]
name: MutableMapping [23918,23932]
===
match
---
name: args [4058,4062]
name: args [4058,4062]
===
match
---
param [4498,4527]
param [4498,4527]
===
match
---
trailer [3137,3140]
trailer [3137,3140]
===
match
---
name: BulkStateFetcher [21187,21203]
name: BulkStateFetcher [21284,21300]
===
match
---
name: Exception [20983,20992]
name: Exception [21080,21089]
===
match
---
name: chunksize [12404,12413]
name: chunksize [12404,12413]
===
match
---
suite [22049,22117]
suite [22146,22214]
===
match
---
suite [12844,13090]
suite [12844,13090]
===
match
---
operator: { [21796,21797]
operator: { [21893,21894]
===
match
---
expr_stmt [4128,4170]
expr_stmt [4128,4170]
===
match
---
name: decode_result [22739,22752]
name: decode_result [22836,22849]
===
match
---
simple_stmt [2952,2976]
simple_stmt [2952,2976]
===
match
---
trailer [14915,14920]
trailer [15012,15017]
===
match
---
name: self [15513,15517]
name: self [15610,15614]
===
match
---
simple_stmt [2387,2444]
simple_stmt [2387,2444]
===
match
---
name: task_cls [23308,23316]
name: task_cls [23405,23413]
===
match
---
if_stmt [18866,18941]
if_stmt [18963,19038]
===
match
---
trailer [5940,5967]
trailer [5940,5967]
===
match
---
import_as_name [1442,1456]
import_as_name [1442,1456]
===
match
---
atom_expr [12499,12552]
atom_expr [12499,12552]
===
match
---
fstring_end: " [21087,21088]
fstring_end: " [21184,21185]
===
match
---
argument [24758,24777]
argument [24855,24874]
===
match
---
atom_expr [12416,12474]
atom_expr [12416,12474]
===
match
---
trailer [15482,15503]
trailer [15579,15600]
===
match
---
trailer [22683,22691]
trailer [22780,22788]
===
match
---
simple_stmt [24273,24291]
simple_stmt [24370,24388]
===
match
---
name: macros [6748,6754]
name: macros [6748,6754]
===
match
---
trailer [2478,2523]
trailer [2478,2523]
===
match
---
tfpdef [9779,9826]
tfpdef [9779,9826]
===
match
---
name: async_results [22404,22417]
name: async_results [22501,22514]
===
match
---
name: result [10254,10260]
name: result [10254,10260]
===
match
---
operator: , [6239,6240]
operator: , [6239,6240]
===
match
---
operator: , [6028,6029]
operator: , [6028,6029]
===
match
---
name: app [22680,22683]
name: app [22777,22780]
===
match
---
trailer [23301,23307]
trailer [23398,23404]
===
match
---
name: _sync_parallelism [7877,7894]
name: _sync_parallelism [7877,7894]
===
match
---
trailer [15487,15493]
trailer [15584,15590]
===
match
---
simple_stmt [1041,1058]
simple_stmt [1041,1058]
===
match
---
name: task_result [23913,23924]
name: task_result [24010,24021]
===
match
---
suite [9043,9749]
suite [9043,9749]
===
match
---
trailer [19180,19188]
trailer [19277,19285]
===
match
---
fstring_expr [19745,19749]
fstring_expr [19842,19846]
===
match
---
name: CommandType [2926,2937]
name: CommandType [2926,2937]
===
match
---
operator: , [21851,21852]
operator: , [21948,21949]
===
match
---
import_name [1001,1010]
import_name [1001,1010]
===
match
---
trailer [25065,25071]
trailer [25162,25168]
===
match
---
trailer [18765,18790]
trailer [18862,18887]
===
match
---
number: 1 [7901,7902]
number: 1 [7901,7902]
===
match
---
name: key [10389,10392]
name: key [10389,10392]
===
match
---
import_from [2209,2250]
import_from [2209,2250]
===
match
---
operator: = [5615,5616]
operator: = [5615,5616]
===
match
---
operator: , [23213,23214]
operator: , [23310,23311]
===
match
---
comparison [10448,10515]
comparison [10448,10515]
===
match
---
name: task_id [23334,23341]
name: task_id [23431,23438]
===
match
---
atom_expr [12664,12778]
atom_expr [12664,12778]
===
match
---
simple_stmt [19595,19623]
simple_stmt [19692,19720]
===
match
---
name: str [3456,3459]
name: str [3456,3459]
===
match
---
simple_stmt [22604,22663]
simple_stmt [22701,22760]
===
match
---
trailer [5751,5825]
trailer [5751,5825]
===
match
---
name: end [16797,16800]
name: end [16894,16897]
===
match
---
name: DatabaseBackend [22154,22169]
name: DatabaseBackend [22251,22266]
===
match
---
atom_expr [11005,11039]
atom_expr [11005,11039]
===
match
---
trailer [14417,14423]
trailer [14514,14520]
===
match
---
name: str [5405,5408]
name: str [5405,5408]
===
match
---
simple_stmt [5419,5446]
simple_stmt [5419,5446]
===
match
---
suite [16567,16589]
suite [16664,16686]
===
match
---
name: dispose [3857,3864]
name: dispose [3857,3864]
===
match
---
operator: , [11999,12000]
operator: , [11999,12000]
===
match
---
operator: , [4358,4359]
operator: , [4358,4359]
===
match
---
name: datetime [8234,8242]
name: datetime [8234,8242]
===
match
---
operator: = [24557,24558]
operator: = [24654,24655]
===
match
---
suite [17370,17384]
suite [17467,17481]
===
match
---
if_stmt [16146,16680]
if_stmt [16243,16777]
===
match
---
funcdef [17023,17345]
funcdef [17120,17442]
===
match
---
name: self [10731,10735]
name: self [10731,10735]
===
match
---
if_stmt [3502,3712]
if_stmt [3502,3712]
===
match
---
trailer [15872,15885]
trailer [15969,15982]
===
match
---
name: int [8719,8722]
name: int [8719,8722]
===
match
---
operator: = [3486,3487]
operator: = [3486,3487]
===
match
---
operator: , [9016,9017]
operator: , [9016,9017]
===
match
---
name: conf [8463,8467]
name: conf [8463,8467]
===
match
---
name: result [11324,11330]
name: result [11324,11330]
===
match
---
atom_expr [19154,19175]
atom_expr [19251,19272]
===
match
---
string: """     Preload some "expensive" airflow modules so that every task process doesn't have to import it again and     again.      Loading these for each task adds 0.3-0.5s *per task* before the task can run. For long running tasks this     doesn't matter, but for short tasks this starts to be a noticeable impact.     """ [6332,6652]
string: """     Preload some "expensive" airflow modules so that every task process doesn't have to import it again and     again.      Loading these for each task adds 0.3-0.5s *per task* before the task can run. For long running tasks this     doesn't matter, but for short tasks this starts to be a noticeable impact.     """ [6332,6652]
===
match
---
trailer [8967,8985]
trailer [8967,8985]
===
match
---
for_stmt [19198,19769]
for_stmt [19295,19866]
===
match
---
suite [3772,4281]
suite [3772,4281]
===
match
---
name: parse_args [4018,4028]
name: parse_args [4018,4028]
===
match
---
string: 'SYNC_PARALLELISM' [7800,7818]
string: 'SYNC_PARALLELISM' [7800,7818]
===
match
---
subscriptlist [5623,5672]
subscriptlist [5623,5672]
===
match
---
name: log [16723,16726]
name: log [16820,16823]
===
match
---
trailer [10987,10992]
trailer [10987,10992]
===
match
---
param [2909,2937]
param [2909,2937]
===
match
---
name: client [6993,6999]
name: client [6993,6999]
===
match
---
dotted_name [1393,1417]
dotted_name [1393,1417]
===
match
---
operator: , [1979,1980]
operator: , [1979,1980]
===
match
---
trailer [4435,4444]
trailer [4435,4444]
===
match
---
name: key [16321,16324]
name: key [16418,16421]
===
match
---
atom_expr [22010,22021]
atom_expr [22107,22118]
===
match
---
trailer [23499,23510]
trailer [23596,23607]
===
match
---
expr_stmt [22786,22881]
expr_stmt [22883,22978]
===
match
---
name: Task [1442,1446]
name: Task [1442,1446]
===
match
---
atom_expr [8112,8138]
atom_expr [8112,8138]
===
match
---
comp_op [11295,11301]
comp_op [11295,11301]
===
match
---
name: self [23010,23014]
name: self [23107,23111]
===
match
---
name: time [1036,1040]
name: time [1036,1040]
===
match
---
atom_expr [16271,16292]
atom_expr [16368,16389]
===
match
---
trailer [10300,10368]
trailer [10300,10368]
===
match
---
name: fork [3491,3495]
name: fork [3491,3495]
===
match
---
trailer [19833,19842]
trailer [19930,19939]
===
match
---
atom [8017,8019]
atom [8017,8019]
===
match
---
atom_expr [4544,4557]
atom_expr [4544,4557]
===
match
---
name: _process_tasks [9758,9772]
name: _process_tasks [9758,9772]
===
match
---
atom_expr [23248,23272]
atom_expr [23345,23369]
===
match
---
name: _exit [4458,4463]
name: _exit [4458,4463]
===
match
---
trailer [4258,4264]
trailer [4258,4264]
===
match
---
operator: = [4782,4783]
operator: = [4782,4783]
===
match
---
name: timeout [2201,2208]
name: timeout [2201,2208]
===
match
---
trailer [10628,10868]
trailer [10628,10868]
===
match
---
trailer [21654,21663]
trailer [21751,21760]
===
match
---
arglist [19886,19978]
arglist [19983,20075]
===
match
---
name: exception_traceback [21152,21171]
name: exception_traceback [21249,21268]
===
match
---
operator: , [15980,15981]
operator: , [16077,16078]
===
match
---
trailer [10619,10623]
trailer [10619,10623]
===
match
---
atom_expr [24016,24037]
atom_expr [24113,24134]
===
match
---
operator: = [25348,25349]
operator: = [25445,25446]
===
match
---
simple_stmt [3482,3498]
simple_stmt [3482,3498]
===
match
---
operator: @ [23654,23655]
operator: @ [23751,23752]
===
match
---
name: str [5662,5665]
name: str [5662,5665]
===
match
---
argument [8266,8334]
argument [8266,8334]
===
match
---
trailer [19075,19077]
trailer [19172,19174]
===
match
---
string: "task_id" [22825,22834]
string: "task_id" [22922,22931]
===
match
---
simple_stmt [22184,22239]
simple_stmt [22281,22336]
===
match
---
name: log [3145,3148]
name: log [3145,3148]
===
match
---
atom_expr [14737,14773]
atom_expr [14834,14870]
===
match
---
suite [9381,9663]
suite [9381,9663]
===
match
---
name: validate_command [2993,3009]
name: validate_command [2993,3009]
===
match
---
operator: , [11189,11190]
operator: , [11189,11190]
===
match
---
param [21609,21614]
param [21706,21711]
===
match
---
name: exception [4847,4856]
name: exception [4847,4856]
===
match
---
trailer [4552,4557]
trailer [4552,4557]
===
match
---
name: _prepare_state_and_info_by_task_dict [22903,22939]
name: _prepare_state_and_info_by_task_dict [23000,23036]
===
match
---
name: sorted_queue [9201,9213]
name: sorted_queue [9201,9213]
===
match
---
trailer [16736,16787]
trailer [16833,16884]
===
match
---
name: items [15601,15606]
name: items [15698,15703]
===
match
---
name: state [19703,19708]
name: state [19800,19805]
===
match
---
trailer [19742,19768]
trailer [19839,19865]
===
match
---
operator: , [3360,3361]
operator: , [3360,3361]
===
match
---
name: time [16984,16988]
name: time [17081,17085]
===
match
---
atom_expr [14907,15032]
atom_expr [15004,15129]
===
match
---
name: get_many [21838,21846]
name: get_many [21935,21943]
===
match
---
name: Optional [3447,3455]
name: Optional [3447,3455]
===
match
---
trailer [4028,4049]
trailer [4028,4049]
===
match
---
parameters [11994,12049]
parameters [11994,12049]
===
match
---
name: _sync_parallelism [12100,12117]
name: _sync_parallelism [12100,12117]
===
match
---
name: key [10988,10991]
name: key [10988,10991]
===
match
---
trailer [11123,11129]
trailer [11123,11129]
===
match
---
name: celery_task_id [4528,4542]
name: celery_task_id [4528,4542]
===
match
---
trailer [9359,9378]
trailer [9359,9378]
===
match
---
simple_stmt [4455,4469]
simple_stmt [4455,4469]
===
match
---
simple_stmt [19099,19112]
simple_stmt [19196,19209]
===
match
---
atom_expr [17006,17017]
atom_expr [17103,17114]
===
match
---
name: _ [9419,9420]
name: _ [9419,9420]
===
match
---
atom_expr [18713,18750]
atom_expr [18810,18847]
===
match
---
dotted_name [1772,1790]
dotted_name [1772,1790]
===
match
---
operator: } [22880,22881]
operator: } [22977,22978]
===
match
---
trailer [15669,15673]
trailer [15766,15770]
===
match
---
simple_stmt [4405,4420]
simple_stmt [4405,4420]
===
match
---
trailer [17010,17015]
trailer [17107,17112]
===
match
---
name: key_and_async_results [10205,10226]
name: key_and_async_results [10205,10226]
===
match
---
trailer [21774,21779]
trailer [21871,21876]
===
match
---
expr_stmt [3482,3497]
expr_stmt [3482,3497]
===
match
---
atom [23487,23556]
atom [23584,23653]
===
match
---
atom_expr [3328,3377]
atom_expr [3328,3377]
===
match
---
simple_stmt [6829,6875]
simple_stmt [6829,6875]
===
match
---
trailer [4319,4329]
trailer [4319,4329]
===
match
---
for_stmt [23876,24265]
for_stmt [23973,24362]
===
match
---
name: Celery [1292,1298]
name: Celery [1292,1298]
===
match
---
name: Stats [10555,10560]
name: Stats [10555,10560]
===
match
---
name: len [24593,24596]
name: len [24690,24693]
===
match
---
trailer [19341,19349]
trailer [19438,19446]
===
match
---
name: fail [16316,16320]
name: fail [16413,16417]
===
match
---
string: """Sends task to executor.""" [5831,5860]
string: """Sends task to executor.""" [5831,5860]
===
match
---
name: command_to_exec [3401,3416]
name: command_to_exec [3401,3416]
===
match
---
expr_stmt [23137,23174]
expr_stmt [23234,23271]
===
match
---
name: sorted_queue [9424,9436]
name: sorted_queue [9424,9436]
===
match
---
string: "task_cls" [23215,23225]
string: "task_cls" [23312,23322]
===
match
---
atom_expr [24414,24461]
atom_expr [24511,24558]
===
match
---
operator: , [23225,23226]
operator: , [23322,23323]
===
match
---
string: 'celery' [2620,2628]
string: 'celery' [2620,2628]
===
match
---
simple_stmt [13050,13090]
simple_stmt [13050,13090]
===
match
---
operator: = [8329,8330]
operator: = [8329,8330]
===
match
---
suite [20638,20972]
suite [20735,21069]
===
match
---
suite [15856,15988]
suite [15953,16085]
===
match
---
suite [13607,14370]
suite [13704,14467]
===
match
---
trailer [15493,15500]
trailer [15590,15597]
===
match
---
atom_expr [23087,23128]
atom_expr [23184,23225]
===
match
---
name: self [11736,11740]
name: self [11736,11740]
===
match
---
operator: = [18751,18752]
operator: = [18848,18849]
===
match
---
atom_expr [23927,23963]
atom_expr [24024,24060]
===
match
---
name: self [21749,21753]
name: self [21846,21850]
===
match
---
name: hasattr [24073,24080]
name: hasattr [24170,24177]
===
match
---
simple_stmt [23372,23453]
simple_stmt [23469,23550]
===
match
---
name: exception_traceback [21007,21026]
name: exception_traceback [21104,21123]
===
match
---
name: DatabaseBackend [1425,1440]
name: DatabaseBackend [1425,1440]
===
match
---
name: self [22477,22481]
name: self [22574,22578]
===
match
---
if_stmt [10386,10954]
if_stmt [10386,10954]
===
match
---
name: cached_celery_backend [19120,19141]
name: cached_celery_backend [19217,19238]
===
match
---
atom_expr [11324,11338]
atom_expr [11324,11338]
===
match
---
name: task_id [11783,11790]
name: task_id [11783,11790]
===
match
---
arglist [22010,22047]
arglist [22107,22144]
===
match
---
name: Celery [2795,2801]
name: Celery [2795,2801]
===
match
---
name: app [3113,3116]
name: app [3113,3116]
===
match
---
expr_stmt [11736,11791]
expr_stmt [11736,11791]
===
match
---
number: 1 [4045,4046]
number: 1 [4045,4046]
===
match
---
name: ti [19539,19541]
name: ti [19636,19638]
===
match
---
fstring_start: f" [21029,21031]
fstring_start: f" [21126,21128]
===
match
---
trailer [15128,15156]
trailer [15225,15253]
===
match
---
suite [5826,6248]
suite [5826,6248]
===
match
---
operator: == [3603,3605]
operator: == [3603,3605]
===
match
---
name: Exception [16695,16704]
name: Exception [16792,16801]
===
match
---
name: configuration [1741,1754]
name: configuration [1741,1754]
===
match
---
expr_stmt [2321,2385]
expr_stmt [2321,2385]
===
match
---
name: CELERY_SEND_ERR_MSG_HEADER [2387,2413]
name: CELERY_SEND_ERR_MSG_HEADER [2387,2413]
===
match
---
arglist [10318,10354]
arglist [10318,10354]
===
match
---
name: self [16311,16315]
name: self [16408,16412]
===
match
---
trailer [15500,15502]
trailer [15597,15599]
===
match
---
operator: = [22552,22553]
operator: = [22649,22650]
===
match
---
name: self [7872,7876]
name: self [7872,7876]
===
match
---
simple_stmt [8431,8525]
simple_stmt [8431,8525]
===
match
---
arglist [10254,10284]
arglist [10254,10284]
===
match
---
arglist [11914,11962]
arglist [11914,11962]
===
match
---
name: log [14912,14915]
name: log [15009,15012]
===
match
---
operator: = [11433,11434]
operator: = [11433,11434]
===
match
---
suite [22534,22975]
suite [22631,23072]
===
match
---
name: ProcessPoolExecutor [24476,24495]
name: ProcessPoolExecutor [24573,24592]
===
match
---
trailer [24576,24638]
trailer [24673,24735]
===
match
---
trailer [9251,9253]
trailer [9251,9253]
===
match
---
trailer [23345,23355]
trailer [23442,23452]
===
match
---
simple_stmt [21674,21716]
simple_stmt [21771,21813]
===
match
---
name: to_dict [23423,23430]
name: to_dict [23520,23527]
===
match
---
trailer [4329,4367]
trailer [4329,4367]
===
match
---
string: 'Celery command failed on host: ' [4951,4984]
string: 'Celery command failed on host: ' [4951,4984]
===
match
---
name: task_ids [22940,22948]
name: task_ids [23037,23045]
===
match
---
name: self [21847,21851]
name: self [21944,21948]
===
match
---
name: _num_tasks_per_send_process [8670,8697]
name: _num_tasks_per_send_process [8670,8697]
===
match
---
atom_expr [3836,3866]
atom_expr [3836,3866]
===
match
---
name: self [9773,9777]
name: self [9773,9777]
===
match
---
operator: , [15835,15836]
operator: , [15932,15933]
===
match
---
name: jinja2 [6664,6670]
name: jinja2 [6664,6670]
===
match
---
simple_stmt [7753,7820]
simple_stmt [7753,7820]
===
match
---
param [17418,17423]
param [17515,17520]
===
match
---
name: Union [20096,20101]
name: Union [20193,20198]
===
match
---
atom_expr [4634,4661]
atom_expr [4634,4661]
===
match
---
trailer [11925,11931]
trailer [11925,11931]
===
match
---
trailer [11940,11962]
trailer [11940,11962]
===
match
---
name: base [1351,1355]
name: base [1351,1355]
===
match
---
name: executors [1848,1857]
name: executors [1848,1857]
===
match
---
name: self [16015,16019]
name: self [16112,16116]
===
match
---
comparison [18660,18695]
comparison [18757,18792]
===
match
---
funcdef [20027,21179]
funcdef [20124,21276]
===
match
---
name: key [15886,15889]
name: key [15983,15986]
===
match
---
trailer [7900,7920]
trailer [7900,7920]
===
match
---
trailer [8194,8196]
trailer [8194,8196]
===
match
---
name: utils [2042,2047]
name: utils [2042,2047]
===
match
---
trailer [20659,20686]
trailer [20756,20783]
===
match
---
operator: , [7902,7903]
operator: , [7902,7903]
===
match
---
name: adopted_task_timeouts [8117,8138]
name: adopted_task_timeouts [8117,8138]
===
match
---
operator: == [16155,16157]
operator: == [16252,16254]
===
match
---
atom_expr [13010,13036]
atom_expr [13010,13036]
===
match
---
name: state [16149,16154]
name: state [16246,16251]
===
match
---
return_stmt [25383,25416]
return_stmt [25480,25513]
===
match
---
operator: , [19945,19946]
operator: , [20042,20043]
===
match
---
name: external_executor_id [4133,4153]
name: external_executor_id [4133,4153]
===
match
---
funcdef [9754,11964]
funcdef [9754,11964]
===
match
---
operator: , [15801,15802]
operator: , [15898,15899]
===
match
---
atom_expr [21104,21124]
atom_expr [21201,21221]
===
match
---
simple_stmt [17006,17018]
simple_stmt [17103,17115]
===
match
---
atom_expr [11776,11790]
atom_expr [11776,11790]
===
match
---
parameters [13131,13137]
parameters [13131,13137]
===
match
---
name: task [16938,16942]
name: task [17035,17039]
===
match
---
trailer [9440,9443]
trailer [9440,9443]
===
match
---
name: command_to_exec [4720,4735]
name: command_to_exec [4720,4735]
===
match
---
name: event_buffer [11230,11242]
name: event_buffer [11230,11242]
===
match
---
trailer [12452,12473]
trailer [12452,12473]
===
match
---
operator: = [5434,5435]
operator: = [5434,5435]
===
match
---
name: env [4634,4637]
name: env [4634,4637]
===
match
---
param [21755,21766]
param [21852,21863]
===
match
---
testlist [6227,6247]
testlist [6227,6247]
===
match
---
raise_stmt [3637,3711]
raise_stmt [3637,3711]
===
match
---
operator: -> [2939,2941]
operator: -> [2939,2941]
===
match
---
name: Mapping [22499,22506]
name: Mapping [22596,22603]
===
match
---
simple_stmt [6952,6957]
simple_stmt [6952,6957]
===
match
---
name: log [19860,19863]
name: log [19957,19960]
===
match
---
name: first_task [10032,10042]
name: first_task [10032,10042]
===
match
---
trailer [22582,22595]
trailer [22679,22692]
===
match
---
atom_expr [16358,16379]
atom_expr [16455,16476]
===
match
---
param [6310,6316]
param [6310,6316]
===
match
---
arglist [4720,4786]
arglist [4720,4786]
===
match
---
simple_stmt [16197,16221]
simple_stmt [16294,16318]
===
match
---
operator: = [8015,8016]
operator: = [8015,8016]
===
match
---
trailer [3495,3497]
trailer [3495,3497]
===
match
---
fstring_end: " [4237,4238]
fstring_end: " [4237,4238]
===
match
---
name: self [15192,15196]
name: self [15289,15293]
===
match
---
operator: , [19708,19709]
operator: , [19805,19806]
===
match
---
operator: = [22272,22273]
operator: = [22369,22370]
===
match
---
operator: = [22609,22610]
operator: = [22706,22707]
===
match
---
arglist [24563,24638]
arglist [24660,24735]
===
match
---
operator: = [3567,3568]
operator: = [3567,3568]
===
match
---
name: self [10140,10144]
name: self [10140,10144]
===
match
---
operator: = [3917,3918]
operator: = [3917,3918]
===
match
---
operator: , [1211,1212]
operator: , [1211,1212]
===
match
---
name: a [21811,21812]
name: a [21908,21909]
===
match
---
trailer [13087,13089]
trailer [13087,13089]
===
match
---
operator: @ [6250,6251]
operator: @ [6250,6251]
===
match
---
name: task_id_to_states_and_info [24934,24960]
name: task_id_to_states_and_info [25031,25057]
===
match
---
except_clause [4285,4306]
except_clause [4285,4306]
===
match
---
string: "Inquiries completed." [15528,15550]
string: "Inquiries completed." [15625,15647]
===
match
---
simple_stmt [21647,21666]
simple_stmt [21744,21763]
===
match
---
name: str [21879,21882]
name: str [21976,21979]
===
match
---
operator: { [22812,22813]
operator: { [22909,22910]
===
match
---
atom_expr [11173,11189]
atom_expr [11173,11189]
===
match
---
trailer [11421,11427]
trailer [11421,11427]
===
match
---
name: sentry [3730,3736]
name: sentry [3730,3736]
===
match
---
atom_expr [4180,4239]
atom_expr [4180,4239]
===
match
---
operator: = [18587,18588]
operator: = [18684,18685]
===
match
---
trailer [15686,15694]
trailer [15783,15791]
===
match
---
trailer [24596,24611]
trailer [24693,24708]
===
match
---
simple_stmt [12211,12272]
simple_stmt [12211,12272]
===
match
---
operator: , [12742,12743]
operator: , [12742,12743]
===
match
---
trailer [18662,18683]
trailer [18759,18780]
===
match
---
name: list [15585,15589]
name: list [15682,15686]
===
match
---
param [16055,16064]
param [16152,16161]
===
match
---
simple_stmt [21097,21179]
simple_stmt [21194,21276]
===
match
---
operator: + [19554,19555]
operator: + [19651,19652]
===
match
---
name: self [22334,22338]
name: self [22431,22435]
===
match
---
operator: = [9856,9857]
operator: = [9856,9857]
===
match
---
atom [22611,22662]
atom [22708,22759]
===
match
---
name: celery_tasks [19154,19166]
name: celery_tasks [19251,19263]
===
match
---
string: "No task to query celery, skipping sync" [12899,12939]
string: "No task to query celery, skipping sync" [12899,12939]
===
match
---
name: task_id [21799,21806]
name: task_id [21896,21903]
===
match
---
name: state [19760,19765]
name: state [19857,19862]
===
match
---
atom_expr [15192,15226]
atom_expr [15289,15323]
===
match
---
trailer [4192,4239]
trailer [4192,4239]
===
match
---
string: 'execute_command encountered a CalledProcessError' [4857,4907]
string: 'execute_command encountered a CalledProcessError' [4857,4907]
===
match
---
trailer [12586,12613]
trailer [12586,12613]
===
match
---
fstring_string: Celery Task ID:  [21031,21047]
fstring_string: Celery Task ID:  [21128,21144]
===
match
---
operator: , [15156,15157]
operator: , [15253,15254]
===
match
---
atom_expr [4011,4049]
atom_expr [4011,4049]
===
match
---
trailer [15885,15903]
trailer [15982,16000]
===
match
---
atom_expr [2795,2876]
atom_expr [2795,2876]
===
match
---
name: self [15450,15454]
name: self [15547,15551]
===
match
---
name: Task [1300,1304]
name: Task [1300,1304]
===
match
---
name: self [19595,19599]
name: self [19692,19696]
===
match
---
name: result [10318,10324]
name: result [10318,10324]
===
match
---
sync_comp_for [16934,16965]
sync_comp_for [17031,17062]
===
match
---
operator: , [15823,15824]
operator: , [15920,15921]
===
match
---
operator: , [19216,19217]
operator: , [19313,19314]
===
match
---
trailer [13598,13604]
trailer [13583,13589]
===
match
---
decorator [2879,2889]
decorator [2879,2889]
===
match
---
operator: , [1217,1218]
operator: , [1217,1218]
===
match
---
arglist [6191,6213]
arglist [6191,6213]
===
match
---
parameters [14793,14799]
parameters [14890,14896]
===
match
---
name: adopted [19834,19841]
name: adopted [19931,19938]
===
match
---
name: shutdown [4436,4444]
name: shutdown [4436,4444]
===
match
---
name: state_or_exception [25350,25368]
name: state_or_exception [25447,25465]
===
match
---
trailer [19506,19528]
trailer [19603,19625]
===
match
---
expr_stmt [8112,8196]
expr_stmt [8112,8196]
===
match
---
name: info [19226,19230]
name: info [19323,19327]
===
match
---
dotted_name [2091,2108]
dotted_name [2091,2108]
===
match
---
expr_stmt [10889,10924]
expr_stmt [10889,10924]
===
match
---
operator: } [21086,21087]
operator: } [21183,21184]
===
match
---
name: task_tuples_to_send [9263,9282]
name: task_tuples_to_send [9263,9282]
===
match
---
name: self [10615,10619]
name: self [10615,10619]
===
match
---
operator: = [22069,22070]
operator: = [22166,22167]
===
match
---
trailer [14754,14773]
trailer [14851,14870]
===
match
---
param [21615,21636]
param [21712,21733]
===
match
---
name: states_and_info_by_task_id [25312,25338]
name: states_and_info_by_task_id [25409,25435]
===
match
---
not_test [18869,18885]
not_test [18966,18982]
===
match
---
atom [9313,9315]
atom [9313,9315]
===
match
---
name: state_info [24231,24241]
name: state_info [24328,24338]
===
match
---
param [17424,17447]
param [17521,17544]
===
match
---
name: task_tuples_to_send [10111,10130]
name: task_tuples_to_send [10111,10130]
===
match
---
name: utils [2142,2147]
name: utils [2142,2147]
===
match
---
import_from [1273,1329]
import_from [1273,1329]
===
match
---
name: self [9585,9589]
name: self [9585,9589]
===
match
---
name: info [3149,3153]
name: info [3149,3153]
===
match
---
name: repr [14636,14640]
name: repr [14733,14737]
===
match
---
trailer [23039,23066]
trailer [23136,23163]
===
match
---
simple_stmt [1388,1474]
simple_stmt [1388,1474]
===
match
---
name: trigger_tasks [8998,9011]
name: trigger_tasks [8998,9011]
===
match
---
while_stmt [16879,16998]
while_stmt [16976,17095]
===
match
---
expr_stmt [15415,15503]
expr_stmt [15512,15600]
===
match
---
funcdef [14779,15240]
funcdef [14876,15337]
===
match
---
param [17161,17199]
param [17258,17296]
===
match
---
name: map [15182,15185]
name: map [15279,15282]
===
match
---
name: exception [5436,5445]
name: exception [5436,5445]
===
match
---
name: tasks [15399,15404]
name: tasks [15496,15501]
===
match
---
name: self [16623,16627]
name: self [16720,16724]
===
match
---
name: celery_tasks [19056,19068]
name: celery_tasks [19153,19165]
===
match
---
simple_stmt [5010,5038]
simple_stmt [5010,5038]
===
match
---
name: get [10474,10477]
name: get [10474,10477]
===
match
---
string: 'CELERY_APP_NAME' [2821,2838]
string: 'CELERY_APP_NAME' [2821,2838]
===
match
---
number: 0 [9441,9442]
number: 0 [9441,9442]
===
match
---
simple_stmt [13147,13487]
simple_stmt [13147,13487]
===
match
---
atom_expr [23488,23510]
atom_expr [23585,23607]
===
match
---
simple_stmt [22062,22117]
simple_stmt [22159,22214]
===
match
---
operator: = [3760,3761]
operator: = [3760,3761]
===
match
---
simple_stmt [19335,19374]
simple_stmt [19432,19471]
===
match
---
operator: , [11955,11956]
operator: , [11955,11956]
===
match
---
name: cached_celery_backend [10008,10029]
name: cached_celery_backend [10008,10029]
===
match
---
param [3431,3467]
param [3431,3467]
===
match
---
expr_stmt [21674,21715]
expr_stmt [21771,21812]
===
match
---
string: "Failed to execute task %s." [4330,4358]
string: "Failed to execute task %s." [4330,4358]
===
match
---
name: task_ids [23891,23899]
name: task_ids [23988,23996]
===
match
---
funcdef [2889,3378]
funcdef [2889,3378]
===
match
---
trailer [12888,12892]
trailer [12888,12892]
===
match
---
arglist [7901,7919]
arglist [7901,7919]
===
match
---
trailer [15922,15926]
trailer [16019,16023]
===
match
---
expr_stmt [22062,22116]
expr_stmt [22159,22213]
===
match
---
simple_stmt [24806,24881]
simple_stmt [24903,24978]
===
match
---
operator: , [5382,5383]
operator: , [5382,5383]
===
match
---
name: task_ids [22653,22661]
name: task_ids [22750,22758]
===
match
---
operator: , [15190,15191]
operator: , [15287,15288]
===
match
---
arglist [15977,15986]
arglist [16074,16083]
===
match
---
atom_expr [19144,19188]
atom_expr [19241,19285]
===
match
---
suite [4115,4171]
suite [4115,4171]
===
match
---
name: async_results [22102,22115]
name: async_results [22199,22212]
===
match
---
import_from [1997,2028]
import_from [1997,2028]
===
match
---
name: self [22554,22558]
name: self [22651,22655]
===
match
---
simple_stmt [22543,22596]
simple_stmt [22640,22693]
===
match
---
trailer [16507,16518]
trailer [16604,16615]
===
match
---
trailer [17139,17144]
trailer [17236,17241]
===
match
---
operator: , [22152,22153]
operator: , [22249,22250]
===
match
---
fstring_string: Celery Task ID:  [6102,6118]
fstring_string: Celery Task ID:  [6102,6118]
===
match
---
operator: , [21753,21754]
operator: , [21850,21851]
===
match
---
atom_expr [22727,22755]
atom_expr [22824,22852]
===
match
---
trailer [22013,22021]
trailer [22110,22118]
===
match
---
name: REVOKED [16285,16292]
name: REVOKED [16382,16389]
===
match
---
except_clause [6047,6068]
except_clause [6047,6068]
===
match
---
name: self [19556,19560]
name: self [19653,19657]
===
match
---
operator: , [16053,16054]
operator: , [16150,16151]
===
match
---
simple_stmt [22711,22778]
simple_stmt [22808,22875]
===
match
---
trailer [19177,19180]
trailer [19274,19277]
===
match
---
name: backend [10043,10050]
name: backend [10043,10050]
===
match
---
operator: = [23292,23293]
operator: = [23389,23390]
===
match
---
name: task_tuples_to_send [12250,12269]
name: task_tuples_to_send [12250,12269]
===
match
---
except_clause [20976,20997]
except_clause [21073,21094]
===
match
---
operator: , [10190,10191]
operator: , [10190,10191]
===
match
---
operator: * [8945,8946]
operator: * [8945,8946]
===
match
---
trailer [14966,14978]
trailer [15063,15075]
===
match
---
name: ti [18634,18636]
name: ti [18731,18733]
===
match
---
operator: , [23014,23015]
operator: , [23111,23112]
===
match
---
trailer [19265,19267]
trailer [19362,19364]
===
match
---
expr_stmt [9394,9443]
expr_stmt [9394,9443]
===
match
---
term [8941,8985]
term [8941,8985]
===
match
---
expr_stmt [23809,23867]
expr_stmt [23906,23964]
===
match
---
simple_stmt [6332,6653]
simple_stmt [6332,6653]
===
match
---
name: isinstance [24981,24991]
name: isinstance [25078,25088]
===
match
---
suite [7037,7051]
suite [7037,7051]
===
match
---
name: task_publish_retries [10401,10421]
name: task_publish_retries [10401,10421]
===
match
---
param [8540,8544]
param [8540,8544]
===
match
---
name: Tuple [1259,1264]
name: Tuple [1259,1264]
===
match
---
expr_stmt [25312,25374]
expr_stmt [25409,25471]
===
match
---
trailer [14630,14635]
trailer [14727,14732]
===
match
---
fstring_expr [4220,4237]
fstring_expr [4220,4237]
===
match
---
argument [4737,4761]
argument [4737,4761]
===
match
---
operator: -> [15848,15850]
operator: -> [15945,15947]
===
match
---
trailer [11009,11030]
trailer [11009,11030]
===
match
---
testlist_comp [11762,11790]
testlist_comp [11762,11790]
===
match
---
trailer [19697,19701]
trailer [19794,19798]
===
match
---
atom_expr [24438,24460]
atom_expr [24535,24557]
===
match
---
trailer [8571,8577]
trailer [8571,8577]
===
match
---
trailer [8116,8138]
trailer [8116,8138]
===
match
---
name: timeout [5933,5940]
name: timeout [5933,5940]
===
match
---
trailer [18768,18789]
trailer [18865,18886]
===
match
---
atom_expr [12218,12271]
atom_expr [12218,12271]
===
match
---
atom_expr [10140,10173]
atom_expr [10140,10173]
===
match
---
operator: , [5780,5781]
operator: , [5780,5781]
===
match
---
trailer [24182,24190]
trailer [24279,24287]
===
match
---
trailer [11242,11247]
trailer [11242,11247]
===
match
---
trailer [15342,15346]
trailer [15439,15443]
===
match
---
suite [21780,21829]
suite [21877,21926]
===
match
---
suite [4574,5038]
suite [4574,5038]
===
match
---
trailer [14635,14667]
trailer [14732,14764]
===
match
---
tfpdef [17161,17191]
tfpdef [17258,17288]
===
match
---
name: check_output [4707,4719]
name: check_output [4707,4719]
===
match
---
name: max_workers [12587,12598]
name: max_workers [12587,12598]
===
match
---
param [3401,3430]
param [3401,3430]
===
match
---
name: task_instance_str [19802,19819]
name: task_instance_str [19899,19916]
===
match
---
name: task_tuple [5707,5717]
name: task_tuple [5707,5717]
===
match
---
name: dispose [3891,3898]
name: dispose [3891,3898]
===
match
---
name: to_send_count [8947,8960]
name: to_send_count [8947,8960]
===
match
---
operator: = [2681,2682]
operator: = [2681,2682]
===
match
---
name: map [12223,12226]
name: map [12223,12226]
===
match
---
name: async_tasks [22583,22594]
name: async_tasks [22680,22691]
===
match
---
trailer [12026,12048]
trailer [12026,12048]
===
match
---
name: celery_states [16358,16371]
name: celery_states [16455,16468]
===
match
---
operator: , [24904,24905]
operator: , [25001,25002]
===
match
---
name: setproctitle [4180,4192]
name: setproctitle [4180,4192]
===
match
---
atom [23865,23867]
atom [23962,23964]
===
match
---
operator: , [24741,24742]
operator: , [24838,24839]
===
match
---
atom_expr [24704,24778]
atom_expr [24801,24875]
===
match
---
name: os [3488,3490]
name: os [3488,3490]
===
match
---
name: key [15927,15930]
name: key [16024,16027]
===
match
---
simple_stmt [3558,3588]
simple_stmt [3558,3588]
===
match
---
atom_expr [7477,7495]
atom_expr [7477,7495]
===
match
---
trailer [4587,4595]
trailer [4587,4595]
===
match
---
operator: , [4735,4736]
operator: , [4735,4736]
===
match
---
name: ExceptionWithTraceback [5046,5068]
name: ExceptionWithTraceback [5046,5068]
===
match
---
param [5356,5361]
param [5356,5361]
===
match
---
name: self [14409,14413]
name: self [14506,14510]
===
match
---
trailer [8923,8988]
trailer [8923,8988]
===
match
---
name: SUCCESS [16172,16179]
name: SUCCESS [16269,16276]
===
match
---
string: """Gets status for many Celery tasks using the best method available.""" [21915,21987]
string: """Gets status for many Celery tasks using the best method available.""" [22012,22084]
===
match
---
name: queue [9412,9417]
name: queue [9412,9417]
===
match
---
operator: , [2628,2629]
operator: , [2628,2629]
===
match
---
atom_expr [15865,15903]
atom_expr [15962,16000]
===
match
---
simple_stmt [1330,1388]
simple_stmt [1330,1388]
===
match
---
trailer [20857,20862]
trailer [20954,20959]
===
match
---
parameters [24331,24352]
parameters [24428,24449]
===
match
---
expr_stmt [24207,24218]
expr_stmt [24304,24315]
===
match
---
testlist_comp [18754,18794]
testlist_comp [18851,18891]
===
match
---
simple_stmt [13495,13510]
simple_stmt [13495,13510]
===
match
---
simple_stmt [14817,14870]
simple_stmt [14914,14967]
===
match
---
raise_stmt [5010,5037]
raise_stmt [5010,5037]
===
match
---
trailer [16893,16899]
trailer [16990,16996]
===
match
---
operator: = [6035,6036]
operator: = [6035,6036]
===
match
---
operator: , [1205,1206]
operator: , [1205,1206]
===
match
---
argument [6030,6041]
argument [6030,6041]
===
match
---
atom_expr [15041,15239]
atom_expr [15138,15336]
===
match
---
param [17050,17055]
param [17147,17152]
===
match
---
operator: , [2487,2488]
operator: , [2487,2488]
===
match
---
atom_expr [16907,16933]
atom_expr [17004,17030]
===
match
---
trailer [5423,5433]
trailer [5423,5433]
===
match
---
simple_stmt [973,985]
simple_stmt [973,985]
===
match
---
atom_expr [15338,15406]
atom_expr [15435,15503]
===
match
---
name: get_key_for_task [22624,22640]
name: get_key_for_task [22721,22737]
===
match
---
operator: = [17145,17146]
operator: = [17242,17243]
===
match
---
atom_expr [5990,6042]
atom_expr [5990,6042]
===
match
---
simple_stmt [6220,6248]
simple_stmt [6220,6248]
===
match
---
suite [24961,25375]
suite [25058,25472]
===
match
---
parameters [5355,5409]
parameters [5355,5409]
===
match
---
atom_expr [18766,18789]
atom_expr [18863,18886]
===
match
---
expr_stmt [12640,12778]
expr_stmt [12640,12778]
===
match
---
trailer [20090,20136]
trailer [20187,20233]
===
match
---
name: tasks [11422,11427]
name: tasks [11422,11427]
===
match
---
name: cached_celery_backend [11341,11362]
name: cached_celery_backend [11341,11362]
===
match
---
parameters [17040,17205]
parameters [17137,17302]
===
match
---
atom_expr [7897,7920]
atom_expr [7897,7920]
===
match
---
trailer [16888,16966]
trailer [16985,17063]
===
match
---
import_name [1029,1040]
import_name [1029,1040]
===
match
---
trailer [8285,8334]
trailer [8285,8334]
===
match
---
simple_stmt [10615,10869]
simple_stmt [10615,10869]
===
match
---
name: celery_task_id [4100,4114]
name: celery_task_id [4100,4114]
===
match
---
simple_stmt [11324,11363]
simple_stmt [11324,11363]
===
match
---
operator: } [24879,24880]
operator: } [24976,24977]
===
match
---
string: 'celery' [8475,8483]
string: 'celery' [8475,8483]
===
match
---
name: task_publish_retries [10894,10914]
name: task_publish_retries [10894,10914]
===
match
---
arglist [14441,14668]
arglist [14538,14765]
===
match
---
name: FAILURE [16262,16269]
name: FAILURE [16359,16366]
===
match
---
operator: = [4949,4950]
operator: = [4949,4950]
===
match
---
string: 'celery_config_options' [2708,2731]
string: 'celery_config_options' [2708,2731]
===
match
---
expr_stmt [13519,13537]
expr_stmt [13622,13640]
===
match
---
name: int [8927,8930]
name: int [8927,8930]
===
match
---
fstring_end: " [6149,6150]
fstring_end: " [6149,6150]
===
match
---
name: result [11173,11179]
name: result [11173,11179]
===
match
---
operator: , [15896,15897]
operator: , [15993,15994]
===
match
---
string: "Executing command in Celery: %s" [3040,3073]
string: "Executing command in Celery: %s" [3040,3073]
===
match
---
atom_expr [19822,19842]
atom_expr [19919,19939]
===
match
---
atom_expr [13572,13606]
atom_expr [13557,13591]
===
match
---
name: self [22274,22278]
name: self [22371,22375]
===
match
---
operator: -> [23762,23764]
operator: -> [23859,23861]
===
match
---
trailer [24363,24390]
trailer [24460,24487]
===
match
---
name: _tasks_list_to_task_ids [21725,21748]
name: _tasks_list_to_task_ids [21822,21845]
===
match
---
name: fallback [8513,8521]
name: fallback [8513,8521]
===
match
---
import_name [6893,6905]
import_name [6893,6905]
===
match
---
trailer [16503,16507]
trailer [16600,16604]
===
match
---
name: isinstance [10243,10253]
name: isinstance [10243,10253]
===
match
---
atom_expr [9585,9610]
atom_expr [9585,9610]
===
match
---
testlist_comp [19219,19230]
testlist_comp [19316,19327]
===
match
---
try_stmt [4683,5038]
try_stmt [4683,5038]
===
match
---
name: task [16889,16893]
name: task [16986,16990]
===
match
---
name: self [5419,5423]
name: self [5419,5423]
===
match
---
atom [19218,19231]
atom [19315,19328]
===
match
---
suite [12050,12816]
suite [12050,12816]
===
match
---
trailer [22615,22623]
trailer [22712,22720]
===
match
---
atom_expr [23147,23174]
atom_expr [23244,23271]
===
match
---
suite [3245,3310]
suite [3245,3310]
===
match
---
and_test [10389,10533]
and_test [10389,10533]
===
match
---
operator: , [8702,8703]
operator: , [8702,8703]
===
match
---
arglist [24418,24460]
arglist [24515,24557]
===
match
---
trailer [8170,8179]
trailer [8170,8179]
===
match
---
trailer [14885,14896]
trailer [14982,14993]
===
match
---
trailer [25236,25246]
trailer [25333,25343]
===
match
---
name: task_result [24107,24118]
name: task_result [24204,24215]
===
match
---
name: AsyncResult [18754,18765]
name: AsyncResult [18851,18862]
===
match
---
arglist [2479,2522]
arglist [2479,2522]
===
match
---
expr_stmt [19281,19322]
expr_stmt [19378,19419]
===
match
---
import_from [2129,2166]
import_from [2129,2166]
===
match
---
atom_expr [16984,16997]
atom_expr [17081,17094]
===
match
---
name: celery_import_modules [6251,6272]
name: celery_import_modules [6251,6272]
===
match
---
fstring_string:  in state  [19749,19759]
fstring_string:  in state  [19846,19856]
===
match
---
name: async_result [20925,20937]
name: async_result [21022,21034]
===
match
---
if_stmt [19778,19993]
if_stmt [19875,20090]
===
match
---
simple_stmt [11225,11271]
simple_stmt [11225,11271]
===
match
---
trailer [4044,4048]
trailer [4044,4048]
===
match
---
operator: = [6018,6019]
operator: = [6018,6019]
===
match
---
name: pop [15923,15926]
name: pop [16020,16023]
===
match
---
operator: , [10193,10194]
operator: , [10193,10194]
===
match
---
trailer [15018,15020]
trailer [15115,15117]
===
match
---
name: CommandType [4515,4526]
name: CommandType [4515,4526]
===
match
---
name: _execute_in_subprocess [3254,3276]
name: _execute_in_subprocess [3254,3276]
===
match
---
operator: = [8273,8274]
operator: = [8273,8274]
===
match
---
name: database [1409,1417]
name: database [1409,1417]
===
match
---
atom_expr [9216,9253]
atom_expr [9216,9253]
===
match
---
trailer [22144,22152]
trailer [22241,22249]
===
match
---
trailer [19153,19176]
trailer [19250,19273]
===
match
---
parameters [8539,8545]
parameters [8539,8545]
===
match
---
atom_expr [15590,15608]
atom_expr [15687,15705]
===
match
---
fstring_expr [6125,6149]
fstring_expr [6125,6149]
===
match
---
funcdef [17389,20025]
funcdef [17486,20122]
===
match
---
trailer [25338,25347]
trailer [25435,25444]
===
match
---
name: exception [11180,11189]
name: exception [11180,11189]
===
match
---
name: tasks [23286,23291]
name: tasks [23383,23388]
===
match
---
trailer [3207,3244]
trailer [3207,3244]
===
match
---
arglist [3345,3376]
arglist [3345,3376]
===
match
---
fstring_expr [21047,21061]
fstring_expr [21144,21158]
===
match
---
name: utils [2222,2227]
name: utils [2222,2227]
===
match
---
trailer [15006,15012]
trailer [15103,15109]
===
match
---
name: exception [5424,5433]
name: exception [5424,5433]
===
match
---
atom_expr [23821,23862]
atom_expr [23918,23959]
===
match
---
name: celery_task_id [3294,3308]
name: celery_task_id [3294,3308]
===
match
---
suite [4396,4469]
suite [4396,4469]
===
match
---
name: seconds [20660,20667]
name: seconds [20757,20764]
===
match
---
try_stmt [6880,6957]
try_stmt [6880,6957]
===
match
---
raise_stmt [17279,17344]
raise_stmt [17376,17441]
===
match
---
operator: , [5799,5800]
operator: , [5799,5800]
===
match
---
name: append [9540,9546]
name: append [9540,9546]
===
match
---
import_name [1041,1057]
import_name [1041,1057]
===
match
---
name: datetime [949,957]
name: datetime [949,957]
===
match
---
name: ExceptionWithTraceback [6168,6190]
name: ExceptionWithTraceback [6168,6190]
===
match
---
trailer [14584,14606]
trailer [14681,14703]
===
match
---
name: on_celery_import_modules [6285,6309]
name: on_celery_import_modules [6285,6309]
===
match
---
import_from [1058,1093]
import_from [1058,1093]
===
match
---
testlist_comp [16248,16292]
testlist_comp [16345,16389]
===
match
---
operator: , [6230,6231]
operator: , [6230,6231]
===
match
---
suite [22171,22239]
suite [22268,22336]
===
match
---
name: futures [1110,1117]
name: futures [1110,1117]
===
match
---
name: key [17064,17067]
name: key [17161,17164]
===
match
---
name: error [11124,11129]
name: error [11124,11129]
===
match
---
operator: , [25246,25247]
operator: , [25343,25344]
===
match
---
name: app [2880,2883]
name: app [2880,2883]
===
match
---
param [4528,4564]
param [4528,4564]
===
match
---
name: EventBufferValueType [22512,22532]
name: EventBufferValueType [22609,22629]
===
match
---
trailer [10791,10816]
trailer [10791,10816]
===
match
---
simple_stmt [6657,6689]
simple_stmt [6657,6689]
===
match
---
name: task_result [24016,24027]
name: task_result [24113,24124]
===
match
---
number: 0 [3606,3607]
number: 0 [3606,3607]
===
match
---
name: State [11251,11256]
name: State [11251,11256]
===
match
---
trailer [15185,15227]
trailer [15282,15324]
===
match
---
name: state [2148,2153]
name: state [2148,2153]
===
match
---
simple_stmt [24231,24265]
simple_stmt [24328,24362]
===
match
---
suite [19789,19993]
suite [19886,20090]
===
match
---
operator: -> [8546,8548]
operator: -> [8546,8548]
===
match
---
expr_stmt [7753,7819]
expr_stmt [7753,7819]
===
match
---
name: task_tuples_to_send [12723,12742]
name: task_tuples_to_send [12723,12742]
===
match
---
operator: = [11248,11249]
operator: = [11248,11249]
===
match
---
name: command_to_exec [4221,4236]
name: command_to_exec [4221,4236]
===
match
---
name: Exception [4292,4301]
name: Exception [4292,4301]
===
match
---
arglist [14996,15020]
arglist [15093,15117]
===
match
---
name: chunksize [24758,24767]
name: chunksize [24855,24864]
===
match
---
string: 'celery' [2811,2819]
string: 'celery' [2811,2819]
===
match
---
atom_expr [22680,22702]
atom_expr [22777,22799]
===
match
---
number: 1 [10923,10924]
number: 1 [10923,10924]
===
match
---
name: open_slots [9344,9354]
name: open_slots [9344,9354]
===
match
---
name: task_adoption_timeout [8210,8231]
name: task_adoption_timeout [8210,8231]
===
match
---
operator: , [4761,4762]
operator: , [4761,4762]
===
match
---
simple_stmt [11005,11040]
simple_stmt [11005,11040]
===
match
---
parameters [2908,2938]
parameters [2908,2938]
===
match
---
trailer [8474,8524]
trailer [8474,8524]
===
match
---
atom_expr [17178,17191]
atom_expr [17275,17288]
===
match
---
test [24061,24126]
test [24158,24223]
===
match
---
tfpdef [9018,9033]
tfpdef [9018,9033]
===
match
---
operator: , [10845,10846]
operator: , [10845,10846]
===
match
---
operator: , [4777,4778]
operator: , [4777,4778]
===
match
---
trailer [15346,15352]
trailer [15443,15449]
===
match
---
simple_stmt [21789,21829]
simple_stmt [21886,21926]
===
match
---
trailer [23317,23324]
trailer [23414,23421]
===
match
---
atom_expr [21674,21696]
atom_expr [21771,21793]
===
match
---
expr_stmt [2445,2523]
expr_stmt [2445,2523]
===
match
---
import_from [1654,1727]
import_from [1654,1727]
===
match
---
atom_expr [16885,16966]
atom_expr [16982,17063]
===
match
---
name: timedout_keys [14706,14719]
name: timedout_keys [14803,14816]
===
match
---
simple_stmt [1273,1330]
simple_stmt [1273,1330]
===
match
---
atom_expr [16158,16179]
atom_expr [16255,16276]
===
match
---
name: ImportError [7025,7036]
name: ImportError [7025,7036]
===
match
---
trailer [4411,4417]
trailer [4411,4417]
===
match
---
fstring_expr [6118,6123]
fstring_expr [6118,6123]
===
match
---
operator: / [8961,8962]
operator: / [8961,8962]
===
match
---
expr_stmt [9201,9253]
expr_stmt [9201,9253]
===
match
---
name: EventBufferValueType [24854,24874]
name: EventBufferValueType [24951,24971]
===
match
---
suite [5968,6043]
suite [5968,6043]
===
match
---
name: self [8004,8008]
name: self [8004,8008]
===
match
---
name: len [12062,12065]
name: len [12062,12065]
===
match
---
trailer [16261,16269]
trailer [16358,16366]
===
match
---
atom_expr [8431,8460]
atom_expr [8431,8460]
===
match
---
atom_expr [20652,20686]
atom_expr [20749,20783]
===
match
---
atom [21796,21828]
atom [21893,21925]
===
match
---
trailer [13054,13087]
trailer [13054,13087]
===
match
---
name: engine [3884,3890]
name: engine [3884,3890]
===
match
---
name: task_tuple [9456,9466]
name: task_tuple [9456,9466]
===
match
---
trailer [9864,9867]
trailer [9864,9867]
===
match
---
trailer [4444,4446]
trailer [4444,4446]
===
match
---
name: key [14365,14368]
name: key [14462,14465]
===
match
---
name: chunksize [24768,24777]
name: chunksize [24865,24874]
===
match
---
name: List [17429,17433]
name: List [17526,17530]
===
match
---
trailer [22558,22582]
trailer [22655,22679]
===
match
---
trailer [14765,14772]
trailer [14862,14869]
===
match
---
expr_stmt [22711,22777]
expr_stmt [22808,22874]
===
match
---
name: multiprocessing [1150,1165]
name: multiprocessing [1150,1165]
===
match
---
name: Dict [1207,1211]
name: Dict [1207,1211]
===
match
---
trailer [23576,23613]
trailer [23673,23710]
===
match
---
name: log [2048,2051]
name: log [2048,2051]
===
match
---
operator: == [16355,16357]
operator: == [16452,16454]
===
match
---
atom_expr [18977,19089]
atom_expr [19074,19186]
===
match
---
name: get_parser [3816,3826]
name: get_parser [3816,3826]
===
match
---
operator: = [12414,12415]
operator: = [12414,12415]
===
match
---
if_stmt [14379,14774]
if_stmt [14476,14871]
===
match
---
suite [15286,15775]
suite [15383,15872]
===
match
---
operator: + [3694,3695]
operator: + [3694,3695]
===
match
---
name: async_results [21853,21866]
name: async_results [21950,21963]
===
match
---
name: result [5981,5987]
name: result [5981,5987]
===
match
---
suite [20137,21179]
suite [20234,21276]
===
match
---
trailer [9288,9310]
trailer [9288,9310]
===
match
---
name: self [19672,19676]
name: self [19769,19773]
===
match
---
name: OrderedDict [8409,8420]
name: OrderedDict [8409,8420]
===
match
---
operator: = [3461,3462]
operator: = [3461,3462]
===
match
---
atom_expr [12686,12764]
atom_expr [12686,12764]
===
match
---
parameters [8697,8723]
parameters [8697,8723]
===
match
---
name: CommandType [5769,5780]
name: CommandType [5769,5780]
===
match
---
trailer [2992,3009]
trailer [2992,3009]
===
match
---
trailer [11767,11774]
trailer [11767,11774]
===
match
---
operator: , [9407,9408]
operator: , [9407,9408]
===
match
---
trailer [22278,22310]
trailer [22375,22407]
===
match
---
name: key_and_async_results [12640,12661]
name: key_and_async_results [12640,12661]
===
match
---
operator: , [14606,14607]
operator: , [14703,14704]
===
match
---
arglist [23614,23647]
arglist [23711,23744]
===
match
---
name: task_tuples_to_send [12507,12526]
name: task_tuples_to_send [12507,12526]
===
match
---
import_from [1474,1511]
import_from [1474,1511]
===
match
---
trailer [4706,4719]
trailer [4706,4719]
===
match
---
simple_stmt [1474,1512]
simple_stmt [1474,1512]
===
match
---
name: async_tasks [21755,21766]
name: async_tasks [21852,21863]
===
match
---
trailer [23954,23963]
trailer [24051,24060]
===
match
---
operator: = [20667,20668]
operator: = [20764,20765]
===
match
---
string: 'Error sending Celery task' [2416,2443]
string: 'Error sending Celery task' [2416,2443]
===
match
---
suite [9611,9663]
suite [9611,9663]
===
match
---
simple_stmt [7872,7921]
simple_stmt [7872,7921]
===
match
---
atom_expr [24682,24792]
atom_expr [24779,24889]
===
match
---
name: self [10448,10452]
name: self [10448,10452]
===
match
---
fstring_start: f" [3154,3156]
fstring_start: f" [3154,3156]
===
match
---
name: async_tasks [23116,23127]
name: async_tasks [23213,23224]
===
match
---
trailer [19828,19833]
trailer [19925,19930]
===
match
---
tfpdef [3401,3429]
tfpdef [3401,3429]
===
match
---
atom_expr [16545,16566]
atom_expr [16642,16663]
===
match
---
name: get_many [19001,19009]
name: get_many [19098,19106]
===
match
---
atom_expr [16889,16899]
atom_expr [16986,16996]
===
match
---
decorated [2879,3378]
decorated [2879,3378]
===
match
---
name: update_task_state [11896,11913]
name: update_task_state [11896,11913]
===
match
---
operator: , [15228,15229]
operator: , [15325,15326]
===
match
---
name: len [22400,22403]
name: len [22497,22500]
===
match
---
trailer [15600,15606]
trailer [15697,15703]
===
match
---
trailer [23115,23128]
trailer [23212,23225]
===
match
---
trailer [9804,9826]
trailer [9804,9826]
===
match
---
suite [23900,24265]
suite [23997,24362]
===
match
---
atom_expr [24566,24638]
atom_expr [24663,24735]
===
match
---
atom_expr [24073,24101]
atom_expr [24170,24198]
===
match
---
name: OrderedDict [8183,8194]
name: OrderedDict [8183,8194]
===
match
---
name: args [6311,6315]
name: args [6311,6315]
===
match
---
trailer [24717,24778]
trailer [24814,24875]
===
match
---
name: task_tuples_to_send [12066,12085]
name: task_tuples_to_send [12066,12085]
===
match
---
string: "clearing:\n\t%s" [14545,14562]
string: "clearing:\n\t%s" [14642,14659]
===
match
---
name: async_result [21048,21060]
name: async_result [21145,21157]
===
match
---
simple_stmt [7477,7496]
simple_stmt [7477,7496]
===
match
---
atom_expr [3199,3244]
atom_expr [3199,3244]
===
match
---
name: Tuple [20085,20090]
name: Tuple [20182,20187]
===
match
---
string: "Unexpected state for %s: %s" [16637,16666]
string: "Unexpected state for %s: %s" [16734,16763]
===
match
---
name: str [16050,16053]
name: str [16147,16150]
===
match
---
funcdef [15993,16788]
funcdef [16090,16885]
===
match
---
trailer [12226,12270]
trailer [12226,12270]
===
match
---
name: _check_for_stalled_adopted_tasks [13099,13131]
name: _check_for_stalled_adopted_tasks [13099,13131]
===
match
---
simple_stmt [15912,15938]
simple_stmt [16009,16035]
===
match
---
atom_expr [8637,8659]
atom_expr [8637,8659]
===
match
---
trailer [13507,13509]
trailer [13507,13509]
===
match
---
trailer [15352,15406]
trailer [15449,15503]
===
match
---
name: self [17364,17368]
name: self [17461,17465]
===
match
---
name: items [13599,13604]
name: items [13584,13589]
===
match
---
trailer [15976,15987]
trailer [16073,16084]
===
match
---
name: AsyncResult [1500,1511]
name: AsyncResult [1500,1511]
===
match
---
atom_expr [6168,6214]
atom_expr [6168,6214]
===
match
---
tfpdef [8704,8722]
tfpdef [8704,8722]
===
match
---
name: str [24849,24852]
name: str [24946,24949]
===
match
---
name: info [16055,16059]
name: info [16152,16156]
===
match
---
trailer [25061,25065]
trailer [25158,25162]
===
match
---
trailer [19605,19613]
trailer [19702,19710]
===
match
---
name: airflow [1840,1847]
name: airflow [1840,1847]
===
match
---
name: info [20967,20971]
name: info [21064,21068]
===
match
---
atom_expr [12095,12117]
atom_expr [12095,12117]
===
match
---
name: timedout_keys [14344,14357]
name: timedout_keys [14441,14454]
===
match
---
name: apply_async [6002,6013]
name: apply_async [6002,6013]
===
match
---
name: state [16238,16243]
name: state [16335,16340]
===
match
---
expr_stmt [13495,13509]
expr_stmt [13495,13509]
===
match
---
string: "celery.task_timeout_error" [10566,10593]
string: "celery.task_timeout_error" [10566,10593]
===
match
---
expr_stmt [3756,3763]
expr_stmt [3756,3763]
===
match
---
trailer [9539,9546]
trailer [9539,9546]
===
match
---
atom_expr [12884,12940]
atom_expr [12884,12940]
===
match
---
name: self [19502,19506]
name: self [19599,19603]
===
match
---
trailer [16209,16220]
trailer [16306,16317]
===
match
---
funcdef [12821,13090]
funcdef [12821,13090]
===
match
---
trailer [24713,24717]
trailer [24810,24814]
===
match
---
atom_expr [20845,20862]
atom_expr [20942,20959]
===
match
---
subscriptlist [24364,24389]
subscriptlist [24461,24486]
===
match
---
simple_stmt [9845,9898]
simple_stmt [9845,9898]
===
match
---
atom_expr [6126,6148]
atom_expr [6126,6148]
===
match
---
trailer [12995,12997]
trailer [12995,12997]
===
match
---
name: key_and_async_results [10060,10081]
name: key_and_async_results [10060,10081]
===
match
---
sync_comp_for [23524,23555]
sync_comp_for [23621,23652]
===
match
---
name: result [11435,11441]
name: result [11435,11441]
===
match
---
operator: , [9489,9490]
operator: , [9489,9490]
===
match
---
atom_expr [20947,20965]
atom_expr [21044,21062]
===
match
---
for_stmt [14695,14774]
for_stmt [14792,14871]
===
match
---
name: operators [6808,6817]
name: operators [6808,6817]
===
match
---
name: async_result [20947,20959]
name: async_result [21044,21056]
===
match
---
simple_stmt [15946,15988]
simple_stmt [16043,16085]
===
match
---
expr_stmt [4058,4088]
expr_stmt [4058,4088]
===
match
---
name: log [22339,22342]
name: log [22436,22439]
===
match
---
string: """         How many Celery tasks should each worker process send.          :return: Number of tasks that should be sent per process         :rtype: int         """ [8740,8904]
string: """         How many Celery tasks should each worker process send.          :return: Number of tasks that should be sent per process         :rtype: int         """ [8740,8904]
===
match
---
name: queue [6030,6035]
name: queue [6030,6035]
===
match
---
name: session [23264,23271]
name: session [23361,23368]
===
match
---
expr_stmt [23461,23556]
expr_stmt [23558,23653]
===
match
---
trailer [4132,4153]
trailer [4132,4153]
===
match
---
name: task_id [24242,24249]
name: task_id [24339,24346]
===
match
---
name: stalled_after [13623,13636]
name: stalled_after [13720,13733]
===
match
---
trailer [12699,12764]
trailer [12699,12764]
===
match
---
import_from [1512,1578]
import_from [1512,1578]
===
match
---
name: Optional [17178,17186]
name: Optional [17275,17283]
===
match
---
arglist [9344,9378]
arglist [9344,9378]
===
match
---
name: msg [4945,4948]
name: msg [4945,4948]
===
match
---
name: async_results [24338,24351]
name: async_results [24435,24448]
===
match
---
name: async_tasks [21816,21827]
name: async_tasks [21913,21924]
===
match
---
trailer [14640,14643]
trailer [14737,14740]
===
match
---
name: EventBufferValueType [23841,23861]
name: EventBufferValueType [23938,23958]
===
match
---
operator: = [7895,7896]
operator: = [7895,7896]
===
match
---
simple_stmt [1011,1029]
simple_stmt [1011,1029]
===
match
---
name: exception [5362,5371]
name: exception [5362,5371]
===
match
---
name: e [20996,20997]
name: e [21093,21094]
===
match
---
param [8698,8703]
param [8698,8703]
===
match
---
name: str [22507,22510]
name: str [22604,22607]
===
match
---
parameters [4497,4565]
parameters [4497,4565]
===
match
---
operator: } [21827,21828]
operator: } [21924,21925]
===
match
---
name: staticmethod [23655,23667]
name: staticmethod [23752,23764]
===
match
---
funcdef [24296,25417]
funcdef [24393,25514]
===
match
---
name: result [11941,11947]
name: result [11941,11947]
===
match
---
atom_expr [15513,15551]
atom_expr [15610,15648]
===
match
---
name: task_id [24897,24904]
name: task_id [24994,25001]
===
match
---
atom_expr [10243,10285]
atom_expr [10243,10285]
===
match
---
name: AsyncResult [5788,5799]
name: AsyncResult [5788,5799]
===
match
---
expr_stmt [24547,24639]
expr_stmt [24644,24736]
===
match
---
operator: = [4009,4010]
operator: = [4009,4010]
===
match
---
atom [22726,22777]
atom [22823,22874]
===
match
---
name: LoggingMixin [2073,2085]
name: LoggingMixin [2073,2085]
===
match
---
trailer [4417,4419]
trailer [4417,4419]
===
match
---
name: change_state [14742,14754]
name: change_state [14839,14851]
===
match
---
argument [8513,8523]
argument [8513,8523]
===
match
---
name: async_results [22224,22237]
name: async_results [22321,22334]
===
match
---
name: self [15129,15133]
name: self [15226,15230]
===
match
---
operator: , [15567,15568]
operator: , [15664,15665]
===
match
---
simple_stmt [5454,5491]
simple_stmt [5454,5491]
===
match
---
tfpdef [12001,12048]
tfpdef [12001,12048]
===
match
---
name: self [17006,17010]
name: self [17103,17107]
===
match
---
simple_stmt [3031,3092]
simple_stmt [3031,3092]
===
match
---
name: _sync_parallelism [7977,7994]
name: _sync_parallelism [7977,7994]
===
match
---
name: TaskInstanceKey [17069,17084]
name: TaskInstanceKey [17166,17181]
===
match
---
name: log [25062,25065]
name: log [25159,25162]
===
match
---
atom_expr [15483,15502]
atom_expr [15580,15599]
===
match
---
param [9779,9826]
param [9779,9826]
===
match
---
name: key [10478,10481]
name: key [10478,10481]
===
match
---
operator: = [9467,9468]
operator: = [9467,9468]
===
insert-tree
---
simple_stmt [787,942]
    string: """CeleryExecutor  .. seealso::     For more information on how the CeleryExecutor works, take a look at the guide:     :ref:`executor:CeleryExecutor` """ [787,941]
to
file_input [787,25417]
at 0
===
insert-tree
---
simple_stmt [2525,2600]
    string: ''' To start the celery worker, run the command: airflow celery worker ''' [2525,2599]
to
file_input [787,25417]
at 36
===
insert-node
---
name: CeleryExecutor [7059,7073]
to
classdef [7053,20025]
at 0
===
insert-node
---
name: BaseExecutor [7074,7086]
to
classdef [7053,20025]
at 1
===
insert-tree
---
simple_stmt [7093,7444]
    string: """     CeleryExecutor is recommended for production use of Airflow. It allows     distributing the execution of task instances to multiple worker nodes.      Celery is a simple, flexible and reliable distributed system to process     vast amounts of messages, while providing operations with the tools     required to maintain such a system.     """ [7093,7443]
to
suite [7088,20025]
at 0
===
insert-node
---
simple_stmt [13519,13613]
to
suite [13138,14774]
at 2
===
insert-node
---
expr_stmt [13519,13612]
to
simple_stmt [13519,13613]
at 0
===
insert-node
---
name: sorted_adopted_task_timeouts [13675,13703]
to
for_stmt [13546,14370]
at 1
===
insert-node
---
atom_expr [13550,13612]
to
expr_stmt [13519,13612]
at 2
===
insert-node
---
trailer [13556,13612]
to
atom_expr [13550,13612]
at 1
===
insert-node
---
arglist [13557,13611]
to
trailer [13556,13612]
at 0
===
move-tree
---
atom_expr [13572,13606]
    name: self [13572,13576]
    trailer [13576,13598]
        name: adopted_task_timeouts [13577,13598]
    trailer [13598,13604]
        name: items [13599,13604]
    trailer [13604,13606]
to
arglist [13557,13611]
at 0
===
delete-tree
---
simple_stmt [787,942]
    string: """CeleryExecutor  .. seealso::     For more information on how the CeleryExecutor works, take a look at the guide:     :ref:`executor:CeleryExecutor` """ [787,941]
===
delete-tree
---
simple_stmt [2525,2600]
    string: ''' To start the celery worker, run the command: airflow celery worker ''' [2525,2599]
===
delete-node
---
name: CeleryExecutor [7059,7073]
===
===
delete-node
---
name: BaseExecutor [7074,7086]
===
===
delete-tree
---
simple_stmt [7093,7444]
    string: """     CeleryExecutor is recommended for production use of Airflow. It allows     distributing the execution of task instances to multiple worker nodes.      Celery is a simple, flexible and reliable distributed system to process     vast amounts of messages, while providing operations with the tools     required to maintain such a system.     """ [7093,7443]
