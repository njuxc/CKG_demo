===
match
---
name: ti2 [14210,14213]
name: ti2 [14210,14213]
===
match
---
trailer [9660,9673]
trailer [9660,9673]
===
match
---
operator: @ [13457,13458]
operator: @ [13457,13458]
===
match
---
name: key [9836,9839]
name: key [9836,9839]
===
match
---
argument [4260,4288]
argument [4260,4288]
===
match
---
simple_stmt [15589,15662]
simple_stmt [15589,15662]
===
match
---
name: executor [9884,9892]
name: executor [9884,9892]
===
match
---
name: assert_not_called [12643,12660]
name: assert_not_called [12643,12660]
===
match
---
name: mock [11644,11648]
name: mock [11644,11648]
===
match
---
atom_expr [5040,5098]
atom_expr [5040,5098]
===
match
---
trailer [6739,6769]
trailer [6739,6769]
===
match
---
simple_stmt [9075,9130]
simple_stmt [9075,9130]
===
match
---
operator: , [20573,20574]
operator: , [21950,21951]
===
match
---
trailer [15172,15174]
trailer [15172,15174]
===
match
---
name: state [1869,1874]
name: state [1869,1874]
===
match
---
assert_stmt [19565,19700]
assert_stmt [20942,21077]
===
match
---
decorator [19706,19740]
decorator [21083,21117]
===
match
---
name: ti1 [14007,14010]
name: ti1 [14007,14010]
===
match
---
simple_stmt [3628,3647]
simple_stmt [3628,3647]
===
match
---
expr_stmt [19916,19967]
expr_stmt [21293,21344]
===
match
---
atom_expr [12527,12567]
atom_expr [12527,12567]
===
match
---
simple_stmt [6301,6340]
simple_stmt [6301,6340]
===
match
---
string: 'fail' [7373,7379]
string: 'fail' [7373,7379]
===
match
---
string: "redis" [3814,3821]
string: "redis" [3814,3821]
===
match
---
comparison [5951,6036]
comparison [5951,6036]
===
match
---
if_stmt [4143,4221]
if_stmt [4143,4221]
===
match
---
name: tasks [16167,16172]
name: tasks [16167,16172]
===
match
---
dictorsetmaker [15770,15887]
dictorsetmaker [15770,15887]
===
match
---
name: get_many [20265,20273]
name: get_many [21642,21650]
===
match
---
assert_stmt [16228,16271]
assert_stmt [16228,16271]
===
match
---
operator: = [15754,15755]
operator: = [15754,15755]
===
match
---
comparison [18135,18197]
comparison [19512,19574]
===
match
---
operator: = [13329,13330]
operator: = [13329,13330]
===
match
---
name: now [8633,8636]
name: now [8633,8636]
===
match
---
string: "DEBUG" [18919,18926]
string: "DEBUG" [20296,20303]
===
match
---
import_name [852,867]
import_name [852,867]
===
match
---
string: "runid" [15641,15648]
string: "runid" [15641,15648]
===
match
---
trailer [15165,15172]
trailer [15165,15172]
===
match
---
atom_expr [14057,14069]
atom_expr [14057,14069]
===
match
---
operator: = [20210,20211]
operator: = [21587,21588]
===
match
---
name: executor [5821,5829]
name: executor [5821,5829]
===
match
---
string: "mysql" [17236,17243]
string: "mysql" [18613,18620]
===
match
---
name: executor [14735,14743]
name: executor [14735,14743]
===
match
---
trailer [21001,21003]
trailer [22378,22380]
===
match
---
operator: = [4530,4531]
operator: = [4530,4531]
===
match
---
operator: = [13773,13774]
operator: = [13773,13774]
===
match
---
name: executor [14269,14277]
name: executor [14269,14277]
===
match
---
trailer [16127,16134]
trailer [16127,16134]
===
match
---
operator: == [9151,9153]
operator: == [9151,9153]
===
match
---
parameters [2173,2179]
parameters [2173,2179]
===
match
---
assert_stmt [16052,16142]
assert_stmt [16052,16142]
===
match
---
trailer [16011,16018]
trailer [16011,16018]
===
match
---
name: queued_tasks [6409,6421]
name: queued_tasks [6409,6421]
===
match
---
name: task_adoption_timeout [14879,14900]
name: task_adoption_timeout [14879,14900]
===
match
---
operator: = [2326,2327]
operator: = [2326,2327]
===
match
---
string: "task_1" [13229,13237]
string: "task_1" [13229,13237]
===
match
---
atom [7193,7353]
atom [7193,7353]
===
match
---
atom [6425,6427]
atom [6425,6427]
===
match
---
operator: , [7695,7696]
operator: , [7695,7696]
===
match
---
dotted_name [16976,16986]
dotted_name [18353,18363]
===
match
---
dotted_name [10607,10626]
dotted_name [10607,10626]
===
match
---
operator: = [5419,5420]
operator: = [5419,5420]
===
match
---
trailer [21638,21646]
trailer [23015,23023]
===
match
---
simple_stmt [21443,21506]
simple_stmt [22820,22883]
===
match
---
atom [14945,14999]
atom [14945,14999]
===
match
---
string: "postgres" [15072,15082]
string: "postgres" [15072,15082]
===
match
---
name: parameterized [11779,11792]
name: parameterized [11779,11792]
===
match
---
decorator [19785,19827]
decorator [21162,21204]
===
match
---
argument [20430,20443]
argument [21807,21820]
===
match
---
with_item [18843,18933]
with_item [20220,20310]
===
match
---
testlist_comp [21967,21989]
testlist_comp [23344,23366]
===
match
---
operator: = [13991,13992]
operator: = [13991,13992]
===
match
---
atom_expr [18678,18697]
atom_expr [20055,20074]
===
match
---
parameters [16792,16805]
parameters [18169,18182]
===
match
---
name: try_number [13675,13685]
name: try_number [13675,13685]
===
match
---
string: """Test that Airflow retries publishing tasks to Celery Broker at least 3 times""" [7902,7984]
string: """Test that Airflow retries publishing tasks to Celery Broker at least 3 times""" [7902,7984]
===
match
---
expr_stmt [13271,13316]
expr_stmt [13271,13316]
===
match
---
name: start_date [13817,13827]
name: start_date [13817,13827]
===
match
---
name: CeleryExecutor [21899,21913]
name: CeleryExecutor [23276,23290]
===
match
---
suite [16746,16777]
suite [18123,18154]
===
match
---
name: key_2 [15835,15840]
name: key_2 [15835,15840]
===
match
---
name: url [18699,18702]
name: url [20076,20079]
===
match
---
operator: = [7074,7075]
operator: = [7074,7075]
===
match
---
name: event_buffer [9661,9673]
name: event_buffer [9661,9673]
===
match
---
operator: -> [3584,3586]
operator: -> [3584,3586]
===
match
---
name: unittest [859,867]
name: unittest [859,867]
===
match
---
atom_expr [20212,20231]
atom_expr [21589,21608]
===
match
---
name: any [10990,10993]
name: any [10990,10993]
===
match
---
operator: == [14697,14699]
operator: == [14697,14699]
===
match
---
name: key_2 [14708,14713]
name: key_2 [14708,14713]
===
match
---
trailer [10081,10094]
trailer [10081,10094]
===
match
---
trailer [14935,14941]
trailer [14935,14941]
===
match
---
name: mock_backend [19916,19928]
name: mock_backend [21293,21305]
===
match
---
trailer [6272,6275]
trailer [6272,6275]
===
match
---
trailer [13931,13957]
trailer [13931,13957]
===
match
---
name: utils [1828,1833]
name: utils [1828,1833]
===
match
---
param [21772,21788]
param [23149,23165]
===
match
---
name: FAILED [6285,6291]
name: FAILED [6285,6291]
===
match
---
expr_stmt [13766,13828]
expr_stmt [13766,13828]
===
match
---
atom_expr [13092,13109]
atom_expr [13092,13109]
===
match
---
comparison [9231,9258]
comparison [9231,9258]
===
match
---
number: 1 [13663,13664]
number: 1 [13663,13664]
===
match
---
string: 'executor.open_slots' [11563,11584]
string: 'executor.open_slots' [11563,11584]
===
match
---
operator: , [897,898]
operator: , [897,898]
===
match
---
operator: = [2872,2873]
operator: = [2872,2873]
===
match
---
atom_expr [2899,2932]
atom_expr [2899,2932]
===
match
---
dotted_name [11779,11799]
dotted_name [11779,11799]
===
match
---
name: try_adopt_task_instances [14478,14502]
name: try_adopt_task_instances [14478,14502]
===
match
---
name: unittest [914,922]
name: unittest [914,922]
===
match
---
argument [4483,4498]
argument [4483,4498]
===
match
---
name: execute_command [5140,5155]
name: execute_command [5140,5155]
===
match
---
name: key_1 [15966,15971]
name: key_1 [15966,15971]
===
match
---
atom [20537,20554]
atom [21914,21931]
===
match
---
comparison [6400,6427]
comparison [6400,6427]
===
match
---
comp_op [6362,6368]
comp_op [6362,6368]
===
match
---
name: exceptions [1425,1435]
name: exceptions [1425,1435]
===
match
---
name: executor [4406,4414]
name: executor [4406,4414]
===
match
---
trailer [8305,8307]
trailer [8305,8307]
===
match
---
operator: == [13445,13447]
operator: == [13445,13447]
===
match
---
simple_stmt [3268,3302]
simple_stmt [3268,3302]
===
match
---
name: event_buffer [10082,10094]
name: event_buffer [10082,10094]
===
match
---
name: self [11947,11951]
name: self [11947,11951]
===
match
---
trailer [21624,21631]
trailer [23001,23008]
===
match
---
name: output [9429,9435]
name: output [9429,9435]
===
match
---
arglist [13932,13956]
arglist [13932,13956]
===
match
---
dotted_name [18348,18358]
dotted_name [19725,19735]
===
match
---
name: app [4458,4461]
name: app [4458,4461]
===
match
---
arglist [14619,14663]
arglist [14619,14663]
===
match
---
comparison [5821,5909]
comparison [5821,5909]
===
match
---
name: pytest [6501,6507]
name: pytest [6501,6507]
===
match
---
trailer [14336,14344]
trailer [14336,14344]
===
match
---
simple_stmt [1043,1069]
simple_stmt [1043,1069]
===
match
---
operator: = [21323,21324]
operator: = [22700,22701]
===
match
---
number: 0 [10549,10550]
number: 0 [10549,10550]
===
match
---
trailer [19295,19304]
trailer [20672,20681]
===
match
---
trailer [14688,14696]
trailer [14688,14696]
===
match
---
name: bulk_state_fetcher [10898,10916]
name: bulk_state_fetcher [10898,10916]
===
match
---
name: signal [21666,21672]
name: signal [23043,23049]
===
match
---
trailer [5496,5501]
trailer [5496,5501]
===
match
---
name: key_2 [15933,15938]
name: key_2 [15933,15938]
===
match
---
trailer [8162,8170]
trailer [8162,8170]
===
match
---
name: signal [21332,21338]
name: signal [22709,22715]
===
match
---
operator: , [14254,14255]
operator: , [14254,14255]
===
match
---
trailer [8588,8590]
trailer [8588,8590]
===
match
---
import_name [787,804]
import_name [787,804]
===
match
---
string: "redis" [7750,7757]
string: "redis" [7750,7757]
===
match
---
operator: == [18329,18331]
operator: == [19706,19708]
===
match
---
simple_stmt [2076,2120]
simple_stmt [2076,2120]
===
match
---
arglist [2094,2116]
arglist [2094,2116]
===
match
---
operator: , [17048,17049]
operator: , [18425,18426]
===
match
---
name: executor [8892,8900]
name: executor [8892,8900]
===
match
---
name: ti [8770,8772]
name: ti [8770,8772]
===
match
---
trailer [17549,17560]
trailer [18926,18937]
===
match
---
comparison [17995,18066]
comparison [19372,19443]
===
match
---
expr_stmt [14045,14069]
expr_stmt [14045,14069]
===
match
---
testlist_comp [4635,4679]
testlist_comp [4635,4679]
===
match
---
atom_expr [5467,5501]
atom_expr [5467,5501]
===
match
---
trailer [7481,7502]
trailer [7481,7502]
===
match
---
name: pytest [3790,3796]
name: pytest [3790,3796]
===
match
---
trailer [9060,9062]
trailer [9060,9062]
===
match
---
name: ClassWithCustomAttributes [20321,20346]
name: ClassWithCustomAttributes [21698,21723]
===
match
---
operator: = [13795,13796]
operator: = [13795,13796]
===
match
---
name: execute_date [6000,6012]
name: execute_date [6000,6012]
===
match
---
atom_expr [10949,10972]
atom_expr [10949,10972]
===
match
---
string: "task_id" [19179,19188]
string: "task_id" [20556,20565]
===
match
---
expr_stmt [15671,15714]
expr_stmt [15671,15714]
===
match
---
name: task_2 [14102,14108]
name: task_2 [14102,14108]
===
match
---
name: State [7707,7712]
name: State [7707,7712]
===
match
---
name: pytest [7726,7732]
name: pytest [7726,7732]
===
match
---
name: dict [9924,9928]
name: dict [9924,9928]
===
match
---
suite [13186,13262]
suite [13186,13262]
===
match
---
parameters [11946,11981]
parameters [11946,11981]
===
match
---
name: mock [19352,19356]
name: mock [20729,20733]
===
match
---
decorator [12979,13021]
decorator [12979,13021]
===
match
---
argument [14110,14121]
argument [14110,14121]
===
match
---
name: integration [6551,6562]
name: integration [6551,6562]
===
match
---
string: 'airflow.executors.celery_executor.CeleryExecutor.trigger_tasks' [11221,11285]
string: 'airflow.executors.celery_executor.CeleryExecutor.trigger_tasks' [11221,11285]
===
match
---
atom_expr [3628,3646]
atom_expr [3628,3646]
===
match
---
testlist_comp [12939,12970]
testlist_comp [12939,12970]
===
match
---
simple_stmt [19279,19478]
simple_stmt [20656,20855]
===
match
---
string: 'tasks' [3999,4006]
string: 'tasks' [3999,4006]
===
match
---
expr_stmt [15589,15661]
expr_stmt [15589,15661]
===
match
---
name: set [17995,17998]
name: set [19372,19375]
===
match
---
operator: = [14156,14157]
operator: = [14156,14157]
===
match
---
name: CeleryExecutor [4337,4351]
name: CeleryExecutor [4337,4351]
===
match
---
name: task_id [17841,17848]
name: task_id [19218,19225]
===
match
---
param [13537,13541]
param [13537,13541]
===
match
---
suite [12506,12568]
suite [12506,12568]
===
match
---
name: task_id [20347,20354]
name: task_id [21724,21731]
===
match
---
name: executor [13346,13354]
name: executor [13346,13354]
===
match
---
name: heartbeat [9051,9060]
name: heartbeat [9051,9060]
===
match
---
trailer [18334,18341]
trailer [19711,19718]
===
match
---
operator: @ [18421,18422]
operator: @ [19798,19799]
===
match
---
comparison [6443,6494]
comparison [6443,6494]
===
match
---
with_stmt [19981,20503]
with_stmt [21358,21880]
===
match
---
decorated [6500,7720]
decorated [6500,7720]
===
match
---
string: 'airflow.executors.celery_executor.Celery.backend' [18763,18813]
string: 'airflow.executors.celery_executor.Celery.backend' [20140,20190]
===
match
---
name: test_should_support_db_backend [18550,18580]
name: test_should_support_db_backend [19927,19957]
===
match
---
trailer [19996,20092]
trailer [21373,21469]
===
match
---
dotted_name [1531,1564]
dotted_name [1531,1564]
===
match
---
atom_expr [12378,12390]
atom_expr [12378,12390]
===
match
---
name: command [12939,12946]
name: command [12939,12946]
===
match
---
name: event_buffer [6110,6122]
name: event_buffer [6110,6122]
===
match
---
atom [11873,11900]
atom [11873,11900]
===
match
---
simple_stmt [6436,6495]
simple_stmt [6436,6495]
===
match
---
name: output [11061,11067]
name: output [11061,11067]
===
match
---
name: running [14689,14696]
name: running [14689,14696]
===
match
---
name: mock [11703,11707]
name: mock [11703,11707]
===
match
---
decorator [7725,7759]
decorator [7725,7759]
===
match
---
atom [4933,4976]
atom [4933,4976]
===
match
---
operator: = [4491,4492]
operator: = [4491,4492]
===
match
---
arglist [15458,15497]
arglist [15458,15497]
===
match
---
trailer [19356,19366]
trailer [20733,20743]
===
match
---
atom_expr [5392,5418]
atom_expr [5392,5418]
===
match
---
atom [11809,11908]
atom [11809,11908]
===
match
---
name: self [3942,3946]
name: self [3942,3946]
===
match
---
trailer [14559,14567]
trailer [14559,14567]
===
match
---
funcdef [20887,20944]
funcdef [22264,22321]
===
match
---
atom [19157,19196]
atom [20534,20573]
===
match
---
operator: == [14942,14944]
operator: == [14942,14944]
===
match
---
comparison [10073,10100]
comparison [10073,10100]
===
match
---
trailer [2791,2858]
trailer [2791,2858]
===
match
---
trailer [12297,12351]
trailer [12297,12351]
===
match
---
testlist_comp [3988,4039]
testlist_comp [3988,4039]
===
match
---
name: _send_tasks_to_celery [22174,22195]
name: _send_tasks_to_celery [23551,23572]
===
match
---
operator: = [13936,13937]
operator: = [13936,13937]
===
match
---
expr_stmt [5392,5446]
expr_stmt [5392,5446]
===
match
---
name: key_1 [15508,15513]
name: key_1 [15508,15513]
===
match
---
name: broker_url [3948,3958]
name: broker_url [3948,3958]
===
match
---
name: celery_executor [18678,18693]
name: celery_executor [20055,20070]
===
match
---
return_stmt [2239,2255]
return_stmt [2239,2255]
===
match
---
trailer [5546,5567]
trailer [5546,5567]
===
match
---
name: SIGINT [21346,21352]
name: SIGINT [22723,22729]
===
match
---
atom_expr [16595,16620]
atom_expr [17972,17997]
===
match
---
trailer [10916,10948]
trailer [10916,10948]
===
match
---
atom_expr [20321,20378]
atom_expr [21698,21755]
===
match
---
string: "mysql" [10627,10634]
string: "mysql" [10627,10634]
===
match
---
atom_expr [13966,13990]
atom_expr [13966,13990]
===
match
---
string: 'fake_simple_ti' [6135,6151]
string: 'fake_simple_ti' [6135,6151]
===
match
---
string: "test_check_for_stalled_adopted_tasks" [15301,15339]
string: "test_check_for_stalled_adopted_tasks" [15301,15339]
===
match
---
operator: , [3345,3346]
operator: , [3345,3346]
===
match
---
trailer [5972,6017]
trailer [5972,6017]
===
match
---
testlist_comp [7211,7339]
testlist_comp [7211,7339]
===
match
---
name: queued_tasks [8901,8913]
name: queued_tasks [8901,8913]
===
match
---
assert_stmt [6348,6383]
assert_stmt [6348,6383]
===
match
---
string: "232" [14992,14997]
string: "232" [14992,14997]
===
match
---
name: unittest [16951,16959]
name: unittest [18328,18336]
===
match
---
name: conf [2365,2369]
name: conf [2365,2369]
===
match
---
name: TaskInstanceKey [1751,1766]
name: TaskInstanceKey [1751,1766]
===
match
---
simple_stmt [6997,7133]
simple_stmt [6997,7133]
===
match
---
name: task_id [15383,15390]
name: task_id [15383,15390]
===
match
---
funcdef [6668,6713]
funcdef [6668,6713]
===
match
---
expr_stmt [17355,17419]
expr_stmt [18732,18796]
===
match
---
name: task [5342,5346]
name: task [5342,5346]
===
match
---
atom_expr [8624,8638]
atom_expr [8624,8638]
===
match
---
name: test_gauge_executor_metrics [11358,11385]
name: test_gauge_executor_metrics [11358,11385]
===
match
---
name: run_id [7325,7331]
name: run_id [7325,7331]
===
match
---
import_from [909,934]
import_from [909,934]
===
match
---
name: executor [7569,7577]
name: executor [7569,7577]
===
match
---
name: self [2224,2228]
name: self [2224,2228]
===
match
---
operator: , [5439,5440]
operator: , [5439,5440]
===
match
---
simple_stmt [14451,14508]
simple_stmt [14451,14508]
===
match
---
atom [21966,21990]
atom [23343,23367]
===
match
---
operator: = [13599,13600]
operator: = [13599,13600]
===
match
---
atom_expr [13645,13665]
atom_expr [13645,13665]
===
match
---
trailer [5616,5618]
trailer [5616,5618]
===
match
---
operator: , [3896,3897]
operator: , [3896,3897]
===
match
---
operator: , [5998,5999]
operator: , [5998,5999]
===
match
---
operator: } [14404,14405]
operator: } [14404,14405]
===
match
---
arglist [18859,18926]
arglist [20236,20303]
===
match
---
operator: = [7331,7332]
operator: = [7331,7332]
===
match
---
name: timedelta [13112,13121]
name: timedelta [13112,13121]
===
match
---
trailer [5829,5842]
trailer [5829,5842]
===
match
---
atom_expr [14421,14435]
atom_expr [14421,14435]
===
match
---
operator: } [9678,9679]
operator: } [9678,9679]
===
match
---
simple_stmt [6094,6191]
simple_stmt [6094,6191]
===
match
---
operator: = [21259,21260]
operator: = [22636,22637]
===
match
---
name: patch_app [3336,3345]
name: patch_app [3336,3345]
===
match
---
operator: == [18013,18015]
operator: == [19390,19392]
===
match
---
operator: , [6607,6608]
operator: , [6607,6608]
===
match
---
param [18581,18586]
param [19958,19963]
===
match
---
operator: , [6133,6134]
operator: , [6133,6134]
===
match
---
with_item [20094,20184]
with_item [21471,21561]
===
match
---
trailer [21404,21438]
trailer [22781,22815]
===
match
---
name: result [17698,17704]
name: result [19075,19081]
===
match
---
with_stmt [3331,3517]
with_stmt [3331,3517]
===
match
---
name: test_should_support_base_backend [19835,19867]
name: test_should_support_base_backend [21212,21244]
===
match
---
assert_stmt [9075,9129]
assert_stmt [9075,9129]
===
match
---
name: patch [12081,12086]
name: patch [12081,12086]
===
match
---
name: DatabaseBackend [1177,1192]
name: DatabaseBackend [1177,1192]
===
match
---
simple_stmt [6708,6713]
simple_stmt [6708,6713]
===
match
---
name: timedelta [6443,6452]
name: timedelta [6443,6452]
===
match
---
name: task_id [19422,19429]
name: task_id [20799,20806]
===
match
---
name: signal [21572,21578]
name: signal [22949,22955]
===
match
---
expr_stmt [19279,19477]
expr_stmt [20656,20854]
===
match
---
string: "abcdef-124215-abcdef" [12393,12415]
string: "abcdef-124215-abcdef" [12393,12415]
===
match
---
atom_expr [8892,8918]
atom_expr [8892,8918]
===
match
---
name: MagicMock [19357,19366]
name: MagicMock [20734,20743]
===
match
---
name: queued_dttm [15842,15853]
name: queued_dttm [15842,15853]
===
match
---
name: signal [21405,21411]
name: signal [22782,22788]
===
match
---
operator: = [8474,8475]
operator: = [8474,8475]
===
match
---
name: backends [1152,1160]
name: backends [1152,1160]
===
match
---
operator: = [15368,15369]
operator: = [15368,15369]
===
match
---
trailer [18847,18858]
trailer [20224,20235]
===
match
---
atom_expr [8576,8590]
atom_expr [8576,8590]
===
match
---
trailer [3781,3783]
trailer [3781,3783]
===
match
---
trailer [4247,4289]
trailer [4247,4289]
===
match
---
name: apply_async [20891,20902]
name: apply_async [22268,22279]
===
match
---
atom_expr [21928,21938]
atom_expr [23305,23315]
===
match
---
name: celery_executor [2491,2506]
name: celery_executor [2491,2506]
===
match
---
name: fetcher [19288,19295]
name: fetcher [20665,20672]
===
match
---
atom [10516,10551]
atom [10516,10551]
===
match
---
operator: == [4388,4390]
operator: == [4388,4390]
===
match
---
atom [14403,14405]
atom [14403,14405]
===
match
---
import_from [868,908]
import_from [868,908]
===
match
---
suite [22036,22290]
suite [23413,23667]
===
match
---
name: task_publish_retries [8336,8356]
name: task_publish_retries [8336,8356]
===
match
---
operator: @ [6538,6539]
operator: @ [6538,6539]
===
match
---
operator: , [17243,17244]
operator: , [18620,18621]
===
match
---
trailer [6967,6982]
trailer [6967,6982]
===
match
---
operator: , [10634,10635]
operator: , [10634,10635]
===
match
---
trailer [13594,13602]
trailer [13594,13602]
===
match
---
name: executor [10832,10840]
name: executor [10832,10840]
===
match
---
name: clear_db_runs [3604,3617]
name: clear_db_runs [3604,3617]
===
match
---
name: quarantined [10590,10601]
name: quarantined [10590,10601]
===
match
---
arglist [14541,14585]
arglist [14541,14585]
===
match
---
sync_comp_for [2016,2070]
sync_comp_for [2016,2070]
===
match
---
simple_stmt [14210,14235]
simple_stmt [14210,14235]
===
match
---
operator: = [8546,8547]
operator: = [8546,8547]
===
match
---
atom [10384,10386]
atom [10384,10386]
===
match
---
atom_expr [16122,16134]
atom_expr [16122,16134]
===
match
---
name: backend [2864,2871]
name: backend [2864,2871]
===
match
---
name: event_buffer [5960,5972]
name: event_buffer [5960,5972]
===
match
---
parameters [2223,2229]
parameters [2223,2229]
===
match
---
trailer [12558,12567]
trailer [12558,12567]
===
match
---
atom_expr [18332,18341]
atom_expr [19709,19718]
===
match
---
assert_stmt [15008,15036]
assert_stmt [15008,15036]
===
match
---
trailer [16098,16105]
trailer [16098,16105]
===
match
---
atom [12937,12973]
atom [12937,12973]
===
match
---
strings [10138,10264]
strings [10138,10264]
===
match
---
name: TaskInstanceKey [15597,15612]
name: TaskInstanceKey [15597,15612]
===
match
---
simple_stmt [14007,14037]
simple_stmt [14007,14037]
===
match
---
string: "postgres" [13487,13497]
string: "postgres" [13487,13497]
===
match
---
fstring_start: f" [20989,20991]
fstring_start: f" [22366,22368]
===
match
---
expr_stmt [14210,14234]
expr_stmt [14210,14234]
===
match
---
trailer [16202,16210]
trailer [16202,16210]
===
match
---
trailer [19034,19040]
trailer [20411,20417]
===
match
---
atom [11835,11857]
atom [11835,11857]
===
match
---
name: AirflowException [4196,4212]
name: AirflowException [4196,4212]
===
match
---
testlist_comp [2010,2014]
testlist_comp [2010,2014]
===
match
---
testlist_comp [6124,6168]
testlist_comp [6124,6168]
===
match
---
parameters [6692,6694]
parameters [6692,6694]
===
match
---
simple_stmt [12527,12568]
simple_stmt [12527,12568]
===
match
---
name: orig_sigint [21601,21612]
name: orig_sigint [22978,22989]
===
match
---
param [3942,3947]
param [3942,3947]
===
match
---
atom_expr [9463,9483]
atom_expr [9463,9483]
===
match
---
name: test_operation_timeout_config [16278,16307]
name: test_operation_timeout_config [17655,17684]
===
match
---
arglist [17561,17628]
arglist [18938,19005]
===
match
---
string: "redis" [6525,6532]
string: "redis" [6525,6532]
===
match
---
operator: , [11595,11596]
operator: , [11595,11596]
===
match
---
operator: , [21599,21600]
operator: , [22976,22977]
===
match
---
operator: = [14188,14189]
operator: = [14188,14189]
===
match
---
decorated [18347,19701]
decorated [19724,21078]
===
match
---
atom_expr [12633,12662]
atom_expr [12633,12662]
===
match
---
trailer [13220,13261]
trailer [13220,13261]
===
match
---
simple_stmt [9884,9905]
simple_stmt [9884,9905]
===
match
---
name: kombu [1291,1296]
name: kombu [1291,1296]
===
match
---
name: BaseKeyValueStoreBackend [17370,17394]
name: BaseKeyValueStoreBackend [18747,18771]
===
match
---
name: executor [7420,7428]
name: executor [7420,7428]
===
match
---
name: call_args [17970,17979]
name: call_args [19347,19356]
===
match
---
name: celery_executor [5040,5055]
name: celery_executor [5040,5055]
===
match
---
operator: + [14803,14804]
operator: + [14803,14804]
===
match
---
name: app [18694,18697]
name: app [20071,20074]
===
match
---
assert_stmt [11077,11130]
assert_stmt [11077,11130]
===
match
---
atom_expr [14553,14567]
atom_expr [14553,14567]
===
match
---
name: ResultSession [3286,3299]
name: ResultSession [3286,3299]
===
match
---
name: assertLogs [18848,18858]
name: assertLogs [20225,20235]
===
match
---
operator: = [2658,2659]
operator: = [2658,2659]
===
match
---
trailer [17723,17896]
trailer [19100,19273]
===
match
---
name: __wrapped__ [2455,2466]
name: __wrapped__ [2455,2466]
===
match
---
name: backend [2883,2890]
name: backend [2883,2890]
===
match
---
operator: == [20526,20528]
operator: == [21903,21905]
===
match
---
trailer [7568,7591]
trailer [7568,7591]
===
match
---
with_item [15297,15347]
with_item [15297,15347]
===
match
---
trailer [2703,2709]
trailer [2703,2709]
===
match
---
trailer [10873,10875]
trailer [10873,10875]
===
match
---
name: executor [10494,10502]
name: executor [10494,10502]
===
match
---
suite [18601,19701]
suite [19978,21078]
===
match
---
trailer [21411,21419]
trailer [22788,22796]
===
match
---
atom_expr [17826,17855]
atom_expr [19203,19232]
===
match
---
name: sys [4471,4474]
name: sys [4471,4474]
===
match
---
operator: = [17368,17369]
operator: = [18745,18746]
===
match
---
name: pytest [21081,21087]
name: pytest [22458,22464]
===
match
---
operator: @ [11778,11779]
operator: @ [11778,11779]
===
match
---
simple_stmt [16315,16361]
simple_stmt [17692,17738]
===
match
---
name: return_value [18993,19005]
name: return_value [20370,20382]
===
match
---
atom_expr [21666,21709]
atom_expr [23043,23086]
===
match
---
operator: = [15279,15280]
operator: = [15279,15280]
===
match
---
name: now [8585,8588]
name: now [8585,8588]
===
match
---
argument [20347,20360]
argument [21724,21737]
===
match
---
name: pytest [7805,7811]
name: pytest [7805,7811]
===
match
---
name: _exit_gracefully [21421,21437]
name: _exit_gracefully [22798,22814]
===
match
---
operator: , [12946,12947]
operator: , [12946,12947]
===
match
---
simple_stmt [6348,6384]
simple_stmt [6348,6384]
===
match
---
simple_stmt [12378,12416]
simple_stmt [12378,12416]
===
match
---
name: task [6997,7001]
name: task [6997,7001]
===
match
---
parameters [16523,16539]
parameters [17900,17916]
===
match
---
name: tis [13448,13451]
name: tis [13448,13451]
===
match
---
dotted_name [1291,1309]
dotted_name [1291,1309]
===
match
---
arglist [4454,4498]
arglist [4454,4498]
===
match
---
trailer [14062,14069]
trailer [14062,14069]
===
match
---
operator: , [13302,13303]
operator: , [13302,13303]
===
match
---
name: backend [12992,12999]
name: backend [12992,12999]
===
match
---
name: ValueError [11859,11869]
name: ValueError [11859,11869]
===
match
---
expr_stmt [11531,11723]
expr_stmt [11531,11723]
===
match
---
name: ti [7298,7300]
name: ti [7298,7300]
===
match
---
string: "INFO:airflow.executors.celery_executor.CeleryExecutor:" [10138,10194]
string: "INFO:airflow.executors.celery_executor.CeleryExecutor:" [10138,10194]
===
match
---
atom_expr [17995,18012]
atom_expr [19372,19389]
===
match
---
operator: , [9601,9602]
operator: , [9601,9602]
===
match
---
import_from [1888,1919]
import_from [1888,1919]
===
match
---
simple_stmt [817,827]
simple_stmt [817,827]
===
match
---
name: success_command [4706,4721]
name: success_command [4706,4721]
===
match
---
suite [17342,17897]
suite [18719,19274]
===
match
---
name: executor [14369,14377]
name: executor [14369,14377]
===
match
---
testlist_comp [11553,11713]
testlist_comp [11553,11713]
===
match
---
operator: @ [11209,11210]
operator: @ [11209,11210]
===
match
---
atom_expr [6279,6291]
atom_expr [6279,6291]
===
match
---
name: pytest [6539,6545]
name: pytest [6539,6545]
===
match
---
name: dag [8543,8546]
name: dag [8543,8546]
===
match
---
operator: , [20547,20548]
operator: , [21924,21925]
===
match
---
operator: == [6422,6424]
operator: == [6422,6424]
===
match
---
atom_expr [13144,13185]
atom_expr [13144,13185]
===
match
---
simple_stmt [1850,1888]
simple_stmt [1850,1888]
===
match
---
name: integration [3840,3851]
name: integration [3840,3851]
===
match
---
operator: , [4885,4886]
operator: , [4885,4886]
===
match
---
name: url [2010,2013]
name: url [2010,2013]
===
match
---
atom_expr [19691,19700]
atom_expr [21068,21077]
===
match
---
with_stmt [4230,6085]
with_stmt [4230,6085]
===
match
---
trailer [17082,17123]
trailer [18459,18500]
===
match
---
atom [11834,11870]
atom [11834,11870]
===
match
---
name: task_2 [15436,15442]
name: task_2 [15436,15442]
===
match
---
trailer [2438,2454]
trailer [2438,2454]
===
match
---
name: celery [1074,1080]
name: celery [1074,1080]
===
match
---
operator: , [5324,5325]
operator: , [5324,5325]
===
match
---
or_test [12810,12973]
or_test [12810,12973]
===
match
---
expr_stmt [15906,15939]
expr_stmt [15906,15939]
===
match
---
param [2224,2228]
param [2224,2228]
===
match
---
comparison [4373,4393]
comparison [4373,4393]
===
match
---
name: baseoperator [1609,1621]
name: baseoperator [1609,1621]
===
match
---
comparison [4146,4172]
comparison [4146,4172]
===
match
---
name: pytest [21713,21719]
name: pytest [23090,23096]
===
match
---
string: 'fake_simple_ti' [6237,6253]
string: 'fake_simple_ti' [6237,6253]
===
match
---
decorator [10577,10602]
decorator [10577,10602]
===
match
---
suite [18934,19478]
suite [20311,20855]
===
match
---
atom_expr [16235,16265]
atom_expr [16235,16265]
===
match
---
atom_expr [9652,9673]
atom_expr [9652,9673]
===
match
---
suite [17313,18342]
suite [18690,19719]
===
match
---
trailer [2709,2760]
trailer [2709,2760]
===
match
---
arglist [14097,14121]
arglist [14097,14121]
===
match
---
simple_stmt [15008,15037]
simple_stmt [15008,15037]
===
match
---
name: start_date [13079,13089]
name: start_date [13079,13089]
===
match
---
trailer [8632,8636]
trailer [8632,8636]
===
match
---
atom_expr [7565,7591]
atom_expr [7565,7591]
===
match
---
simple_stmt [15436,15499]
simple_stmt [15436,15499]
===
match
---
atom_expr [3601,3619]
atom_expr [3601,3619]
===
match
---
name: airflow [1485,1492]
name: airflow [1485,1492]
===
match
---
name: mock_trigger_tasks [11410,11428]
name: mock_trigger_tasks [11410,11428]
===
match
---
atom [19326,19459]
atom [20703,20836]
===
match
---
operator: , [15070,15071]
operator: , [15070,15071]
===
match
---
name: signal [21339,21345]
name: signal [22716,22722]
===
match
---
name: _prepare_app [10704,10716]
name: _prepare_app [10704,10716]
===
match
---
simple_stmt [2765,2859]
simple_stmt [2765,2859]
===
match
---
operator: = [19091,19092]
operator: = [20468,20469]
===
match
---
name: now [4541,4544]
name: now [4541,4544]
===
match
---
name: execute_date [6255,6267]
name: execute_date [6255,6267]
===
match
---
operator: , [3997,3998]
operator: , [3997,3998]
===
match
---
operator: { [8360,8361]
operator: { [8360,8361]
===
match
---
trailer [20988,21056]
trailer [22365,22433]
===
match
---
trailer [4783,4805]
trailer [4783,4805]
===
match
---
trailer [18627,18629]
trailer [20004,20006]
===
match
---
decorators [18347,18542]
decorators [19724,19919]
===
match
---
name: tasks [14430,14435]
name: tasks [14430,14435]
===
match
---
name: __str__ [16630,16637]
name: __str__ [18007,18014]
===
match
---
name: test_config [2533,2544]
name: test_config [2533,2544]
===
match
---
import_from [1767,1814]
import_from [1767,1814]
===
match
---
name: datetime [889,897]
name: datetime [889,897]
===
match
---
name: signal [21465,21471]
name: signal [22842,22848]
===
match
---
comparison [10345,10386]
comparison [10345,10386]
===
match
---
operator: , [14651,14652]
operator: , [14651,14652]
===
match
---
name: execute [2674,2681]
name: execute [2674,2681]
===
match
---
name: self [16704,16708]
name: self [18081,18085]
===
match
---
decorator [21712,21737]
decorator [23089,23114]
===
match
---
operator: , [16874,16875]
operator: , [18251,18252]
===
match
---
operator: , [19813,19814]
operator: , [21190,21191]
===
match
---
name: executor [9463,9471]
name: executor [9463,9471]
===
match
---
testlist_comp [21966,22009]
testlist_comp [23343,23386]
===
match
---
name: self [16603,16607]
name: self [17980,17984]
===
match
---
number: 1 [7238,7239]
number: 1 [7238,7239]
===
match
---
operator: = [14116,14117]
operator: = [14116,14117]
===
match
---
atom_expr [9996,10022]
atom_expr [9996,10022]
===
match
---
name: mock [11292,11296]
name: mock [11292,11296]
===
match
---
name: executor [5951,5959]
name: executor [5951,5959]
===
match
---
arglist [13863,13902]
arglist [13863,13902]
===
match
---
trailer [11671,11676]
trailer [11671,11676]
===
match
---
decorated [2258,3517]
decorated [2258,3517]
===
match
---
atom_expr [20257,20502]
atom_expr [21634,21879]
===
match
---
trailer [19411,19421]
trailer [20788,20798]
===
match
---
operator: , [18841,18842]
operator: , [20218,20219]
===
match
---
simple_stmt [16653,16722]
simple_stmt [18030,18099]
===
match
---
dotted_name [11137,11147]
dotted_name [11137,11147]
===
match
---
arglist [7314,7336]
arglist [7314,7336]
===
match
---
name: pytest [18422,18428]
name: pytest [19799,19805]
===
match
---
name: QUEUED [5903,5909]
name: QUEUED [5903,5909]
===
match
---
name: pytest [3869,3875]
name: pytest [3869,3875]
===
match
---
string: "456" [20438,20443]
string: "456" [21815,21820]
===
match
---
simple_stmt [10338,10387]
simple_stmt [10338,10387]
===
match
---
name: ti2 [14172,14175]
name: ti2 [14172,14175]
===
match
---
trailer [16337,16355]
trailer [17714,17732]
===
match
---
operator: } [15938,15939]
operator: } [15938,15939]
===
match
---
operator: , [2749,2750]
operator: , [2749,2750]
===
match
---
trailer [8030,8051]
trailer [8030,8051]
===
match
---
name: orig_sigterm [21261,21273]
name: orig_sigterm [22638,22650]
===
match
---
name: dag [14541,14544]
name: dag [14541,14544]
===
match
---
operator: , [5655,5656]
operator: , [5655,5656]
===
match
---
with_stmt [19883,20503]
with_stmt [21260,21880]
===
match
---
arglist [17236,17255]
arglist [18613,18632]
===
match
---
decorator [17215,17257]
decorator [18592,18634]
===
match
---
simple_stmt [13766,13829]
simple_stmt [13766,13829]
===
match
---
suite [4130,4221]
suite [4130,4221]
===
match
---
name: task_id [14638,14645]
name: task_id [14638,14645]
===
match
---
testlist_comp [11873,11906]
testlist_comp [11873,11906]
===
match
---
trailer [12387,12390]
trailer [12387,12390]
===
match
---
atom_expr [7279,7338]
atom_expr [7279,7338]
===
match
---
name: mget_args [17945,17954]
name: mget_args [19322,19331]
===
match
---
operator: } [2577,2578]
operator: } [2577,2578]
===
match
---
name: contrib [1205,1212]
name: contrib [1205,1212]
===
match
---
fstring [16660,16721]
fstring [18037,18098]
===
match
---
arith_expr [13565,13602]
arith_expr [13565,13602]
===
match
---
name: kwargs [16532,16538]
name: kwargs [17909,17915]
===
match
---
or_test [2412,2466]
or_test [2412,2466]
===
match
---
testlist_comp [11811,11831]
testlist_comp [11811,11831]
===
match
---
atom_expr [10000,10021]
atom_expr [10000,10021]
===
match
---
trailer [11476,11491]
trailer [11476,11491]
===
match
---
testlist_comp [16093,16111]
testlist_comp [16093,16111]
===
match
---
atom_expr [14603,14664]
atom_expr [14603,14664]
===
match
---
name: AirflowException [1443,1459]
name: AirflowException [1443,1459]
===
match
---
name: mock [17771,17775]
name: mock [19148,19152]
===
match
---
name: dag_id [14623,14629]
name: dag_id [14623,14629]
===
match
---
name: get [2370,2373]
name: get [2370,2373]
===
match
---
name: task_id [19367,19374]
name: task_id [20744,20751]
===
match
---
assert_stmt [9271,9449]
assert_stmt [9271,9449]
===
match
---
name: os [1981,1983]
name: os [1981,1983]
===
match
---
operator: @ [15042,15043]
operator: @ [15042,15043]
===
match
---
argument [15401,15422]
argument [15401,15422]
===
match
---
name: set [16214,16217]
name: set [16214,16217]
===
match
---
trailer [11765,11772]
trailer [11765,11772]
===
match
---
name: executor [21872,21880]
name: executor [23249,23257]
===
match
---
simple_stmt [1193,1248]
simple_stmt [1193,1248]
===
match
---
operator: , [5178,5179]
operator: , [5178,5179]
===
match
---
operator: , [12184,12185]
operator: , [12184,12185]
===
match
---
operator: , [1459,1460]
operator: , [1459,1460]
===
match
---
operator: == [14436,14438]
operator: == [14436,14438]
===
match
---
argument [7071,7091]
argument [7071,7091]
===
match
---
name: patch [2704,2709]
name: patch [2704,2709]
===
match
---
funcdef [21737,22290]
funcdef [23114,23667]
===
match
---
name: BashOperator [7004,7016]
name: BashOperator [7004,7016]
===
match
---
trailer [14227,14234]
trailer [14227,14234]
===
match
---
name: _get_many_using_multiprocessing [10917,10948]
name: _get_many_using_multiprocessing [10917,10948]
===
match
---
name: executor [9579,9587]
name: executor [9579,9587]
===
match
---
name: len [10411,10414]
name: len [10411,10414]
===
match
---
atom [10098,10100]
atom [10098,10100]
===
match
---
name: running [15915,15922]
name: running [15915,15922]
===
match
---
trailer [4420,4422]
trailer [4420,4422]
===
match
---
atom [16092,16112]
atom [16092,16112]
===
match
---
name: signal [21325,21331]
name: signal [22702,22708]
===
match
---
assert_stmt [9645,9679]
assert_stmt [9645,9679]
===
match
---
param [11953,11961]
param [11953,11961]
===
match
---
decorator [2150,2160]
decorator [2150,2160]
===
match
---
atom_expr [17663,17681]
atom_expr [19040,19058]
===
match
---
simple_stmt [787,805]
simple_stmt [787,805]
===
match
---
name: mark [3876,3880]
name: mark [3876,3880]
===
match
---
operator: { [9963,9964]
operator: { [9963,9964]
===
match
---
arglist [2710,2759]
arglist [2710,2759]
===
match
---
operator: , [10523,10524]
operator: , [10523,10524]
===
match
---
argument [13239,13260]
argument [13239,13260]
===
match
---
operator: == [14767,14769]
operator: == [14767,14769]
===
match
---
operator: , [14835,14836]
operator: , [14835,14836]
===
match
---
name: executor [6206,6214]
name: executor [6206,6214]
===
match
---
name: task_id [8506,8513]
name: task_id [8506,8513]
===
match
---
expr_stmt [13611,13665]
expr_stmt [13611,13665]
===
match
---
param [2174,2178]
param [2174,2178]
===
match
---
trailer [14991,14998]
trailer [14991,14998]
===
match
---
name: self [16740,16744]
name: self [18117,18121]
===
match
---
dictorsetmaker [14946,14998]
dictorsetmaker [14946,14998]
===
match
---
name: days [13595,13599]
name: days [13595,13599]
===
match
---
arglist [8147,8240]
arglist [8147,8240]
===
match
---
trailer [19304,19477]
trailer [20681,20854]
===
match
---
name: datetime [7152,7160]
name: datetime [7152,7160]
===
match
---
number: 0 [5689,5690]
number: 0 [5689,5690]
===
match
---
name: call_args [12924,12933]
name: call_args [12924,12933]
===
match
---
argument [20445,20460]
argument [21822,21837]
===
match
---
simple_stmt [14321,14354]
simple_stmt [14321,14354]
===
match
---
atom_expr [2781,2858]
atom_expr [2781,2858]
===
match
---
atom_expr [5124,5155]
atom_expr [5124,5155]
===
match
---
simple_stmt [12584,12617]
simple_stmt [12584,12617]
===
match
---
name: timedelta [899,908]
name: timedelta [899,908]
===
match
---
operator: , [14629,14630]
operator: , [14629,14630]
===
match
---
simple_stmt [8651,8826]
simple_stmt [8651,8826]
===
match
---
name: executor [6369,6377]
name: executor [6369,6377]
===
match
---
name: self [3578,3582]
name: self [3578,3582]
===
match
---
name: execute [2402,2409]
name: execute [2402,2409]
===
match
---
name: celery_executor [13357,13372]
name: celery_executor [13357,13372]
===
match
---
name: stdout [4475,4481]
name: stdout [4475,4481]
===
match
---
trailer [21069,21077]
trailer [22446,22454]
===
match
---
trailer [5139,5155]
trailer [5139,5155]
===
match
---
string: "abcdef-124215-abcdef" [12948,12970]
string: "abcdef-124215-abcdef" [12948,12970]
===
match
---
trailer [10735,10756]
trailer [10735,10756]
===
match
---
simple_stmt [14045,14070]
simple_stmt [14045,14070]
===
match
---
atom_expr [12697,12737]
atom_expr [12697,12737]
===
match
---
operator: , [17855,17856]
operator: , [19232,19233]
===
match
---
name: clear_db_jobs [3631,3644]
name: clear_db_jobs [3631,3644]
===
match
---
return_stmt [16815,16853]
return_stmt [18192,18230]
===
match
---
atom_expr [3310,3325]
atom_expr [3310,3325]
===
match
---
operator: , [8520,8521]
operator: , [8520,8521]
===
match
---
atom [20597,20712]
atom [21974,22089]
===
match
---
simple_stmt [10776,10820]
simple_stmt [10776,10820]
===
match
---
operator: = [21274,21275]
operator: = [22651,22652]
===
match
---
trailer [4381,4387]
trailer [4381,4387]
===
match
---
trailer [20273,20502]
trailer [21650,21879]
===
match
---
name: task_1 [14553,14559]
name: task_1 [14553,14559]
===
match
---
operator: , [5738,5739]
operator: , [5738,5739]
===
match
---
decorator [3827,3864]
decorator [3827,3864]
===
match
---
string: 'fake_simple_ti' [5722,5738]
string: 'fake_simple_ti' [5722,5738]
===
match
---
simple_stmt [4049,4087]
simple_stmt [4049,4087]
===
match
---
operator: == [14400,14402]
operator: == [14400,14402]
===
match
---
expr_stmt [17945,17979]
expr_stmt [19322,19356]
===
match
---
trailer [5055,5076]
trailer [5055,5076]
===
match
---
expr_stmt [15144,15194]
expr_stmt [15144,15194]
===
match
---
atom [2008,2071]
atom [2008,2071]
===
match
---
name: dict [14730,14734]
name: dict [14730,14734]
===
match
---
name: integration [19757,19768]
name: integration [21134,21145]
===
match
---
operator: , [15931,15932]
operator: , [15931,15932]
===
match
---
trailer [21936,21938]
trailer [23313,23315]
===
match
---
name: dag_id [15536,15542]
name: dag_id [15536,15542]
===
match
---
name: adopted_task_timeouts [15732,15753]
name: adopted_task_timeouts [15732,15753]
===
match
---
trailer [8019,8030]
trailer [8019,8030]
===
match
---
trailer [8390,8415]
trailer [8390,8415]
===
match
---
operator: - [13643,13644]
operator: - [13643,13644]
===
match
---
operator: , [14706,14707]
operator: , [14706,14707]
===
match
---
decorator [3868,3910]
decorator [3868,3910]
===
match
---
name: self [13064,13068]
name: self [13064,13068]
===
match
---
name: cm [9847,9849]
name: cm [9847,9849]
===
match
---
simple_stmt [15906,15940]
simple_stmt [15906,15940]
===
match
---
operator: } [18196,18197]
operator: } [19573,19574]
===
match
---
name: return_value [17058,17070]
name: return_value [18435,18447]
===
match
---
atom_expr [14631,14645]
atom_expr [14631,14645]
===
match
---
atom_expr [10350,10379]
atom_expr [10350,10379]
===
match
---
suite [17636,17897]
suite [19013,19274]
===
match
---
dotted_name [11210,11220]
dotted_name [11210,11220]
===
match
---
trailer [21672,21679]
trailer [23049,23056]
===
match
---
trailer [18084,18108]
trailer [19461,19485]
===
match
---
trailer [1983,1991]
trailer [1983,1991]
===
match
---
atom_expr [6101,6173]
atom_expr [6101,6173]
===
match
---
simple_stmt [16052,16143]
simple_stmt [16052,16143]
===
match
---
operator: , [11428,11429]
operator: , [11428,11429]
===
match
---
operator: , [13007,13008]
operator: , [13007,13008]
===
match
---
trailer [10817,10819]
trailer [10817,10819]
===
match
---
not_test [16899,16921]
not_test [18276,18298]
===
match
---
trailer [17441,17447]
trailer [18818,18824]
===
match
---
dotted_name [3790,3813]
dotted_name [3790,3813]
===
match
---
name: SIG_DFL [21298,21305]
name: SIG_DFL [22675,22682]
===
match
---
name: mark [18508,18512]
name: mark [19885,19889]
===
match
---
name: airflow [1820,1827]
name: airflow [1820,1827]
===
match
---
simple_stmt [7902,7985]
simple_stmt [7902,7985]
===
match
---
name: log [8047,8050]
name: log [8047,8050]
===
match
---
dotted_name [18460,18483]
dotted_name [19837,19860]
===
match
---
name: session [3310,3317]
name: session [3310,3317]
===
match
---
name: key_1 [14946,14951]
name: key_1 [14946,14951]
===
match
---
simple_stmt [3601,3620]
simple_stmt [3601,3620]
===
match
---
operator: , [21352,21353]
operator: , [22729,22730]
===
match
---
atom_expr [16059,16080]
atom_expr [16059,16080]
===
match
---
comparison [15015,15036]
comparison [15015,15036]
===
match
---
name: broker_url [4248,4258]
name: broker_url [4248,4258]
===
match
---
trailer [18008,18011]
trailer [19385,19388]
===
match
---
name: backend [17228,17235]
name: backend [18605,18612]
===
match
---
atom_expr [10704,10718]
atom_expr [10704,10718]
===
match
---
trailer [14502,14507]
trailer [14502,14507]
===
match
---
operator: } [16018,16019]
operator: } [16018,16019]
===
match
---
name: executor [10889,10897]
name: executor [10889,10897]
===
match
---
operator: = [19242,19243]
operator: = [20619,20620]
===
match
---
expr_stmt [15723,15897]
expr_stmt [15723,15897]
===
match
---
name: SimpleTaskInstance [8751,8769]
name: SimpleTaskInstance [8751,8769]
===
match
---
name: self [16822,16826]
name: self [18199,18203]
===
match
---
argument [17615,17628]
argument [18992,19005]
===
match
---
name: State [14222,14227]
name: State [14222,14227]
===
match
---
name: AsyncResult [15973,15984]
name: AsyncResult [15973,15984]
===
match
---
operator: = [14601,14602]
operator: = [14601,14602]
===
match
---
trailer [7441,7446]
trailer [7441,7446]
===
match
---
expr_stmt [2687,2760]
expr_stmt [2687,2760]
===
match
---
suite [20978,21078]
suite [22355,22455]
===
match
---
arith_expr [13625,13665]
arith_expr [13625,13665]
===
match
---
name: airflow [1594,1601]
name: airflow [1594,1601]
===
match
---
name: task_adoption_timeout [15865,15886]
name: task_adoption_timeout [15865,15886]
===
match
---
testlist_comp [5974,6015]
testlist_comp [5974,6015]
===
match
---
name: self [16870,16874]
name: self [18247,18251]
===
match
---
operator: , [5853,5854]
operator: , [5853,5854]
===
match
---
return_stmt [16892,16921]
return_stmt [18269,18298]
===
match
---
operator: { [10849,10850]
operator: { [10849,10850]
===
match
---
trailer [13580,13582]
trailer [13580,13582]
===
match
---
atom_expr [21618,21661]
atom_expr [22995,23038]
===
match
---
testlist_comp [4608,5179]
testlist_comp [4608,5179]
===
match
---
operator: , [11653,11654]
operator: , [11653,11654]
===
match
---
name: task [8786,8790]
name: task [8786,8790]
===
match
---
name: orig_sigusr2 [21696,21708]
name: orig_sigusr2 [23073,23085]
===
match
---
assert_stmt [9563,9632]
assert_stmt [9563,9632]
===
match
---
name: dag_id [15617,15623]
name: dag_id [15617,15623]
===
match
---
name: key [9122,9125]
name: key [9122,9125]
===
match
---
atom_expr [10305,10325]
atom_expr [10305,10325]
===
match
---
expr_stmt [7179,7353]
expr_stmt [7179,7353]
===
match
---
name: FakeCeleryResult [10857,10873]
name: FakeCeleryResult [10857,10873]
===
match
---
atom_expr [18735,18841]
atom_expr [20112,20218]
===
match
---
name: self [19868,19872]
name: self [21245,21249]
===
match
---
suite [7893,10572]
suite [7893,10572]
===
match
---
arglist [2907,2931]
arglist [2907,2931]
===
match
---
name: key [9543,9546]
name: key [9543,9546]
===
match
---
atom [8844,8879]
atom [8844,8879]
===
match
---
name: signal [21579,21585]
name: signal [22956,22962]
===
match
---
name: queued_dttm [14791,14802]
name: queued_dttm [14791,14802]
===
match
---
funcdef [7850,10572]
funcdef [7850,10572]
===
match
---
comparison [6101,6190]
comparison [6101,6190]
===
match
---
name: key_2 [16114,16119]
name: key_2 [16114,16119]
===
match
---
operator: , [21694,21695]
operator: , [23071,23072]
===
match
---
trailer [20994,21001]
trailer [22371,22378]
===
match
---
name: self [7887,7891]
name: self [7887,7891]
===
match
---
assert_stmt [9917,9971]
assert_stmt [9917,9971]
===
match
---
operator: @ [7763,7764]
operator: @ [7763,7764]
===
match
---
param [13064,13068]
param [13064,13068]
===
match
---
with_stmt [15292,15499]
with_stmt [15292,15499]
===
match
---
string: "Exception" [11088,11099]
string: "Exception" [11088,11099]
===
match
---
name: url [2020,2023]
name: url [2020,2023]
===
match
---
param [3665,3669]
param [3665,3669]
===
match
---
operator: , [6267,6268]
operator: , [6267,6268]
===
match
---
operator: , [2102,2103]
operator: , [2102,2103]
===
match
---
operator: = [13295,13296]
operator: = [13295,13296]
===
match
---
operator: , [21419,21420]
operator: , [22796,22797]
===
match
---
name: mock_mget [17302,17311]
name: mock_mget [18679,18688]
===
match
---
suite [1992,2072]
suite [1992,2072]
===
match
---
operator: , [5333,5334]
operator: , [5333,5334]
===
match
---
name: start_date [13552,13562]
name: start_date [13552,13562]
===
match
---
parameters [20966,20977]
parameters [22343,22354]
===
match
---
dotted_name [18501,18520]
dotted_name [19878,19897]
===
match
---
simple_stmt [18206,18342]
simple_stmt [19583,19719]
===
match
---
name: pytest [17175,17181]
name: pytest [18552,18558]
===
match
---
string: 'SUCCESS' [18154,18163]
string: 'SUCCESS' [19531,19540]
===
match
---
operator: , [7671,7672]
operator: , [7671,7672]
===
match
---
atom [9121,9129]
atom [9121,9129]
===
match
---
arglist [13291,13315]
arglist [13291,13315]
===
match
---
name: queued_dttm [14176,14187]
name: queued_dttm [14176,14187]
===
match
---
name: task_1 [13199,13205]
name: task_1 [13199,13205]
===
match
---
atom [2009,2015]
atom [2009,2015]
===
match
---
name: backend [10619,10626]
name: backend [10619,10626]
===
match
---
trailer [11510,11520]
trailer [11510,11520]
===
match
---
name: clear_db_runs [3691,3704]
name: clear_db_runs [3691,3704]
===
match
---
name: try_adopt_task_instances [13415,13439]
name: try_adopt_task_instances [13415,13439]
===
match
---
testlist_comp [20538,20553]
testlist_comp [21915,21930]
===
match
---
operator: = [13623,13624]
operator: = [13623,13624]
===
match
---
operator: , [5980,5981]
operator: , [5980,5981]
===
match
---
trailer [6066,6084]
trailer [6066,6084]
===
match
---
expr_stmt [10776,10819]
expr_stmt [10776,10819]
===
match
---
atom_expr [4471,4481]
atom_expr [4471,4481]
===
match
---
trailer [22030,22035]
trailer [23407,23412]
===
match
---
trailer [22173,22195]
trailer [23550,23572]
===
match
---
operator: @ [7804,7805]
operator: @ [7804,7805]
===
match
---
argument [13932,13943]
argument [13932,13943]
===
match
---
atom_expr [19931,19967]
atom_expr [21308,21344]
===
match
---
atom_expr [9082,9117]
atom_expr [9082,9117]
===
match
---
name: mock [11667,11671]
name: mock [11667,11671]
===
match
---
trailer [5611,5616]
trailer [5611,5616]
===
match
---
suite [2333,3517]
suite [2333,3517]
===
match
---
operator: = [15254,15255]
operator: = [15254,15255]
===
match
---
comparison [11088,11107]
comparison [11088,11107]
===
match
---
name: ti1 [13966,13969]
name: ti1 [13966,13969]
===
match
---
operator: = [8803,8804]
operator: = [8803,8804]
===
match
---
comparison [9082,9129]
comparison [9082,9129]
===
match
---
name: timezone [13565,13573]
name: timezone [13565,13573]
===
match
---
assert_stmt [6301,6339]
assert_stmt [6301,6339]
===
match
---
dotted_name [10578,10601]
dotted_name [10578,10601]
===
match
---
trailer [2089,2093]
trailer [2089,2093]
===
match
---
name: mock_fork [12276,12285]
name: mock_fork [12276,12285]
===
match
---
simple_stmt [9496,9551]
simple_stmt [9496,9551]
===
match
---
name: fake_execute_command [6748,6768]
name: fake_execute_command [6748,6768]
===
match
---
operator: @ [3868,3869]
operator: @ [3868,3869]
===
match
---
with_stmt [18730,19478]
with_stmt [20107,20855]
===
match
---
fstring [10211,10264]
fstring [10211,10264]
===
match
---
simple_stmt [3969,4041]
simple_stmt [3969,4041]
===
match
---
name: adopted_task_timeouts [16244,16265]
name: adopted_task_timeouts [16244,16265]
===
match
---
operator: , [13943,13944]
operator: , [13943,13944]
===
match
---
operator: = [8513,8514]
operator: = [8513,8514]
===
match
---
name: mark [6508,6512]
name: mark [6508,6512]
===
match
---
funcdef [19831,20726]
funcdef [21208,22103]
===
match
---
name: id [12388,12390]
name: id [12388,12390]
===
match
---
trailer [7542,7544]
trailer [7542,7544]
===
match
---
decorator [15042,15084]
decorator [15042,15084]
===
match
---
name: try_number [15650,15660]
name: try_number [15650,15660]
===
match
---
name: executors [1493,1502]
name: executors [1493,1502]
===
match
---
operator: ** [19130,19132]
operator: ** [20507,20509]
===
match
---
expr_stmt [13966,13998]
expr_stmt [13966,13998]
===
match
---
assert_stmt [10066,10100]
assert_stmt [10066,10100]
===
match
---
funcdef [1922,2120]
funcdef [1922,2120]
===
match
---
string: "rabbitmq" [3852,3862]
string: "rabbitmq" [3852,3862]
===
match
---
name: SIGINT [21593,21599]
name: SIGINT [22970,22976]
===
match
---
suite [21119,21710]
suite [22496,23087]
===
match
---
name: executor [7642,7650]
name: executor [7642,7650]
===
match
---
name: other [16839,16844]
name: other [18216,18221]
===
match
---
atom_expr [2699,2760]
atom_expr [2699,2760]
===
match
---
name: broker_url [2567,2577]
name: broker_url [2567,2577]
===
match
---
decorator [6500,6534]
decorator [6500,6534]
===
match
---
number: 1 [20942,20943]
number: 1 [22319,22320]
===
match
---
argument [13291,13302]
argument [13291,13302]
===
match
---
name: self [16638,16642]
name: self [18015,18019]
===
match
---
atom_expr [10994,11037]
atom_expr [10994,11037]
===
match
---
name: command [4121,4128]
name: command [4121,4128]
===
match
---
name: run_id [13304,13310]
name: run_id [13304,13310]
===
match
---
operator: - [15175,15176]
operator: - [15175,15176]
===
match
---
name: task [21985,21989]
name: task [23362,23366]
===
match
---
trailer [16959,16968]
trailer [18336,18345]
===
match
---
name: tasks [14936,14941]
name: tasks [14936,14941]
===
match
---
string: "Assert Default Max Retries is 3" [8422,8455]
string: "Assert Default Max Retries is 3" [8422,8455]
===
match
---
trailer [16907,16914]
trailer [18284,18291]
===
match
---
string: 'airflow.executors.base_executor.Stats.gauge' [11303,11348]
string: 'airflow.executors.base_executor.Stats.gauge' [11303,11348]
===
match
---
atom_expr [13850,13903]
atom_expr [13850,13903]
===
match
---
trailer [7112,7116]
trailer [7112,7116]
===
match
---
name: mock_mget [18075,18084]
name: mock_mget [19452,19461]
===
match
---
simple_stmt [18643,18717]
simple_stmt [20020,20094]
===
match
---
simple_stmt [5392,5447]
simple_stmt [5392,5447]
===
match
---
string: "rabbitmq" [6563,6573]
string: "rabbitmq" [6563,6573]
===
match
---
string: 'tasks' [11885,11892]
string: 'tasks' [11885,11892]
===
match
---
string: b'celery-task-meta-123' [18042,18065]
string: b'celery-task-meta-123' [19419,19442]
===
match
---
operator: = [18656,18657]
operator: = [20033,20034]
===
match
---
name: adopted_task_timeouts [14378,14399]
name: adopted_task_timeouts [14378,14399]
===
match
---
expr_stmt [4517,4546]
expr_stmt [4517,4546]
===
match
---
argument [8551,8562]
argument [8551,8562]
===
match
---
fstring [20989,21055]
fstring [22366,22432]
===
match
---
name: mock [18735,18739]
name: mock [20112,20116]
===
match
---
name: celery_executor [10787,10802]
name: celery_executor [10787,10802]
===
match
---
name: return_value [19078,19090]
name: return_value [20455,20467]
===
match
---
name: backend [18513,18520]
name: backend [19890,19897]
===
match
---
name: return_value [19041,19053]
name: return_value [20418,20430]
===
match
---
string: 'airflow.executors.celery_executor._execute_in_fork' [12210,12262]
string: 'airflow.executors.celery_executor._execute_in_fork' [12210,12262]
===
match
---
operator: , [19548,19549]
operator: , [20925,20926]
===
match
---
testlist_comp [18180,18195]
testlist_comp [19557,19572]
===
match
---
operator: = [14023,14024]
operator: = [14023,14024]
===
match
---
name: self [15129,15133]
name: self [15129,15133]
===
match
---
argument [7050,7069]
argument [7050,7069]
===
match
---
name: command [5326,5333]
name: command [5326,5333]
===
match
---
atom_expr [21472,21486]
atom_expr [22849,22863]
===
match
---
name: any [11084,11087]
name: any [11084,11087]
===
match
---
operator: = [14220,14221]
operator: = [14220,14221]
===
match
---
testlist_comp [22244,22288]
testlist_comp [23621,23665]
===
match
---
name: self [18843,18847]
name: self [20220,20224]
===
match
---
atom [6228,6271]
atom [6228,6271]
===
match
---
operator: == [16173,16175]
operator: == [16173,16175]
===
match
---
funcdef [13025,13452]
funcdef [13025,13452]
===
match
---
operator: == [15031,15033]
operator: == [15031,15033]
===
match
---
atom_expr [4831,4862]
atom_expr [4831,4862]
===
match
---
name: start_date [15401,15411]
name: start_date [15401,15411]
===
match
---
simple_stmt [8375,8456]
simple_stmt [8375,8456]
===
match
---
operator: @ [16975,16976]
operator: @ [18352,18353]
===
match
---
trailer [16041,16043]
trailer [16041,16043]
===
match
---
testlist_comp [20321,20462]
testlist_comp [21698,21839]
===
match
---
name: FakeCeleryResult [2128,2144]
name: FakeCeleryResult [2128,2144]
===
match
---
name: tasks [10841,10846]
name: tasks [10841,10846]
===
match
---
import_from [1677,1766]
import_from [1677,1766]
===
match
---
trailer [4474,4481]
trailer [4474,4481]
===
match
---
param [18587,18599]
param [19964,19976]
===
match
---
trailer [12190,12196]
trailer [12190,12196]
===
match
---
name: mock_sync [11430,11439]
name: mock_sync [11430,11439]
===
match
---
trailer [2544,2551]
trailer [2544,2551]
===
match
---
operator: , [7239,7240]
operator: , [7239,7240]
===
match
---
atom_expr [10857,10875]
atom_expr [10857,10875]
===
match
---
operator: , [4805,4806]
operator: , [4805,4806]
===
match
---
name: celery_executor [21883,21898]
name: celery_executor [23260,23275]
===
match
---
trailer [7650,7663]
trailer [7650,7663]
===
match
---
trailer [7116,7118]
trailer [7116,7118]
===
match
---
name: db [3688,3690]
name: db [3688,3690]
===
match
---
operator: - [15235,15236]
operator: - [15235,15236]
===
match
---
testlist_comp [19513,19528]
testlist_comp [20890,20905]
===
match
---
dictorsetmaker [2553,2577]
dictorsetmaker [2553,2577]
===
match
---
name: len [9575,9578]
name: len [9575,9578]
===
match
---
argument [17841,17854]
argument [19218,19231]
===
match
---
name: executor [6464,6472]
name: executor [6464,6472]
===
match
---
arglist [20430,20460]
arglist [21807,21837]
===
match
---
operator: } [19196,19197]
operator: } [20573,20574]
===
match
---
operator: { [10098,10099]
operator: { [10098,10099]
===
match
---
simple_stmt [14172,14202]
simple_stmt [14172,14202]
===
match
---
atom_expr [15532,15542]
atom_expr [15532,15542]
===
match
---
param [11962,11980]
param [11962,11980]
===
match
---
simple_stmt [20202,20232]
simple_stmt [21579,21609]
===
match
---
operator: { [15965,15966]
operator: { [15965,15966]
===
match
---
testlist_comp [5646,5690]
testlist_comp [5646,5690]
===
match
---
atom_expr [18843,18927]
atom_expr [20220,20304]
===
match
---
atom_expr [10889,10973]
atom_expr [10889,10973]
===
match
---
trailer [19053,19060]
trailer [20430,20437]
===
match
---
name: TaskInstance [13919,13931]
name: TaskInstance [13919,13931]
===
match
---
trailer [7428,7441]
trailer [7428,7441]
===
match
---
decorator [18421,18455]
decorator [19798,19832]
===
match
---
trailer [19077,19090]
trailer [20454,20467]
===
match
---
trailer [4351,4353]
trailer [4351,4353]
===
match
---
arglist [21632,21660]
arglist [23009,23037]
===
match
---
operator: , [18528,18529]
operator: , [19905,19906]
===
match
---
name: mock [8059,8063]
name: mock [8059,8063]
===
match
---
trailer [10515,10552]
trailer [10515,10552]
===
match
---
atom_expr [19115,19198]
atom_expr [20492,20575]
===
match
---
number: 0 [10553,10554]
number: 0 [10553,10554]
===
match
---
operator: , [20443,20444]
operator: , [21820,21821]
===
match
---
atom_expr [4441,4499]
atom_expr [4441,4499]
===
match
---
simple_stmt [18128,18198]
simple_stmt [19505,19575]
===
match
---
atom [19504,19556]
atom [20881,20933]
===
match
---
atom_expr [3715,3733]
atom_expr [3715,3733]
===
match
---
name: self [20094,20098]
name: self [21471,21475]
===
match
---
name: test_celery_integration [3918,3941]
name: test_celery_integration [3918,3941]
===
match
---
operator: } [9549,9550]
operator: } [9549,9550]
===
match
---
fstring_end: " [9842,9843]
fstring_end: " [9842,9843]
===
match
---
name: executor [14328,14336]
name: executor [14328,14336]
===
match
---
name: task_adoption_timeout [14814,14835]
name: task_adoption_timeout [14814,14835]
===
match
---
comparison [14927,14999]
comparison [14927,14999]
===
match
---
atom_expr [10559,10571]
atom_expr [10559,10571]
===
match
---
name: operators [1780,1789]
name: operators [1780,1789]
===
match
---
name: celery_executor [4831,4846]
name: celery_executor [4831,4846]
===
match
---
trailer [6284,6291]
trailer [6284,6291]
===
match
---
name: task_id [13863,13870]
name: task_id [13863,13870]
===
match
---
atom_expr [7524,7544]
atom_expr [7524,7544]
===
match
---
name: keys [5612,5616]
name: keys [5612,5616]
===
match
---
arglist [6600,6619]
arglist [6600,6619]
===
match
---
dotted_name [2259,2284]
dotted_name [2259,2284]
===
match
---
simple_stmt [1888,1920]
simple_stmt [1888,1920]
===
match
---
atom_expr [7642,7703]
atom_expr [7642,7703]
===
match
---
simple_stmt [16815,16854]
simple_stmt [18192,18231]
===
match
---
atom_expr [22025,22035]
atom_expr [23402,23412]
===
match
---
expr_stmt [13079,13129]
expr_stmt [13079,13129]
===
match
---
simple_stmt [20935,20944]
simple_stmt [22312,22321]
===
match
---
trailer [2204,2206]
trailer [2204,2206]
===
match
---
atom_expr [12810,12832]
atom_expr [12810,12832]
===
match
---
argument [18699,18715]
argument [20076,20092]
===
match
---
simple_stmt [15203,15259]
simple_stmt [15203,15259]
===
match
---
name: dict [9503,9507]
name: dict [9503,9507]
===
match
---
assert_stmt [12803,12973]
assert_stmt [12803,12973]
===
match
---
decorator [2258,2285]
decorator [2258,2285]
===
match
---
operator: = [18702,18703]
operator: = [20079,20080]
===
match
---
name: TaskInstanceKey [15516,15531]
name: TaskInstanceKey [15516,15531]
===
match
---
decorator [17136,17170]
decorator [18513,18547]
===
match
---
name: executor [6054,6062]
name: executor [6054,6062]
===
match
---
comparison [10138,10277]
comparison [10138,10277]
===
match
---
trailer [20264,20273]
trailer [21641,21650]
===
match
---
name: key [7442,7445]
name: key [7442,7445]
===
match
---
operator: = [8220,8221]
operator: = [8220,8221]
===
match
---
string: 'success' [6308,6317]
string: 'success' [6308,6317]
===
match
---
name: tasks [15957,15962]
name: tasks [15957,15962]
===
match
---
testlist_comp [7373,7406]
testlist_comp [7373,7406]
===
match
---
decorator [11136,11205]
decorator [11136,11205]
===
match
---
trailer [17840,17855]
trailer [19217,19232]
===
match
---
trailer [14310,14312]
trailer [14310,14312]
===
match
---
trailer [13121,13129]
trailer [13121,13129]
===
match
---
trailer [14134,14155]
trailer [14134,14155]
===
match
---
atom_expr [21572,21613]
atom_expr [22949,22990]
===
match
---
atom_expr [13919,13957]
atom_expr [13919,13957]
===
match
---
trailer [17679,17681]
trailer [19056,19058]
===
match
---
trailer [8063,8069]
trailer [8063,8069]
===
match
---
name: _prepare_app [6727,6739]
name: _prepare_app [6727,6739]
===
match
---
simple_stmt [9984,10054]
simple_stmt [9984,10054]
===
match
---
name: BaseOperator [15370,15382]
name: BaseOperator [15370,15382]
===
match
---
string: 'fail' [5974,5980]
string: 'fail' [5974,5980]
===
match
---
atom_expr [20094,20178]
atom_expr [21471,21555]
===
match
---
name: list [5592,5596]
name: list [5592,5596]
===
match
---
arglist [18763,18827]
arglist [20140,20204]
===
match
---
atom [4586,5197]
atom [4586,5197]
===
match
---
arglist [19806,19825]
arglist [21183,21202]
===
match
---
number: 500 [22031,22034]
number: 500 [23408,23411]
===
match
---
expr_stmt [2765,2858]
expr_stmt [2765,2858]
===
match
---
operator: } [10875,10876]
operator: } [10875,10876]
===
match
---
name: db [3628,3630]
name: db [3628,3630]
===
match
---
name: event_buffer [9240,9252]
name: event_buffer [9240,9252]
===
match
---
trailer [19260,19262]
trailer [20637,20639]
===
match
---
name: dict [10345,10349]
name: dict [10345,10349]
===
match
---
trailer [9481,9483]
trailer [9481,9483]
===
match
---
assert_stmt [20512,20581]
assert_stmt [21889,21958]
===
match
---
name: executor [16158,16166]
name: executor [16158,16166]
===
match
---
trailer [3644,3646]
trailer [3644,3646]
===
match
---
name: tasks [6334,6339]
name: tasks [6334,6339]
===
match
---
number: 3 [8419,8420]
number: 3 [8419,8420]
===
match
---
comp_op [6318,6324]
comp_op [6318,6324]
===
match
---
name: value_tuple [7179,7190]
name: value_tuple [7179,7190]
===
match
---
name: airflow [1855,1862]
name: airflow [1855,1862]
===
match
---
operator: == [9253,9255]
operator: == [9253,9255]
===
match
---
testlist_comp [12858,12892]
testlist_comp [12858,12892]
===
match
---
name: expected_exception [12431,12449]
name: expected_exception [12431,12449]
===
match
---
operator: @ [2150,2151]
operator: @ [2150,2151]
===
match
---
name: pytest [3828,3834]
name: pytest [3828,3834]
===
match
---
name: mark [17144,17148]
name: mark [18521,18525]
===
match
---
name: queued_tasks [10009,10021]
name: queued_tasks [10009,10021]
===
match
---
simple_stmt [2239,2256]
simple_stmt [2239,2256]
===
match
---
trailer [6472,6494]
trailer [6472,6494]
===
match
---
comparison [7560,7591]
comparison [7560,7591]
===
match
---
operator: , [5752,5753]
operator: , [5752,5753]
===
match
---
trailer [17414,17418]
trailer [18791,18795]
===
match
---
operator: = [14278,14279]
operator: = [14278,14279]
===
match
---
name: celery [1048,1054]
name: celery [1048,1054]
===
match
---
name: fixture [21088,21095]
name: fixture [22465,22472]
===
match
---
atom_expr [6325,6339]
atom_expr [6325,6339]
===
match
---
with_stmt [10699,10974]
with_stmt [10699,10974]
===
match
---
name: patch_app [2687,2696]
name: patch_app [2687,2696]
===
match
---
trailer [21686,21694]
trailer [23063,23071]
===
match
---
name: mark [10585,10589]
name: mark [10585,10589]
===
match
---
simple_stmt [16028,16044]
simple_stmt [16028,16044]
===
match
---
fstring_string: ). [9419,9421]
fstring_string: ). [9419,9421]
===
match
---
argument [8797,8808]
argument [8797,8808]
===
match
---
assert_stmt [10338,10386]
assert_stmt [10338,10386]
===
match
---
name: pytest [13458,13464]
name: pytest [13458,13464]
===
match
---
operator: { [14770,14771]
operator: { [14770,14771]
===
match
---
simple_stmt [1815,1850]
simple_stmt [1815,1850]
===
match
---
trailer [13414,13439]
trailer [13414,13439]
===
match
---
atom_expr [19407,19436]
atom_expr [20784,20813]
===
match
---
operator: } [21053,21054]
operator: } [22430,22431]
===
match
---
name: state [14049,14054]
name: state [14049,14054]
===
match
---
simple_stmt [20512,20582]
simple_stmt [21889,21959]
===
match
---
operator: = [13276,13277]
operator: = [13276,13277]
===
match
---
testlist_comp [5844,5888]
testlist_comp [5844,5888]
===
match
---
trailer [16243,16265]
trailer [16243,16265]
===
match
---
operator: , [4680,4681]
operator: , [4680,4681]
===
match
---
simple_stmt [1642,1677]
simple_stmt [1642,1677]
===
match
---
atom_expr [7707,7719]
atom_expr [7707,7719]
===
match
---
string: "mysql" [13478,13485]
string: "mysql" [13478,13485]
===
match
---
operator: , [4481,4482]
operator: , [4481,4482]
===
match
---
atom_expr [15597,15661]
atom_expr [15597,15661]
===
match
---
atom_expr [11644,11652]
atom_expr [11644,11652]
===
match
---
expr_stmt [21247,21305]
expr_stmt [22624,22682]
===
match
---
name: _ [22264,22265]
name: _ [23641,23642]
===
match
---
assert_stmt [4366,4393]
assert_stmt [4366,4393]
===
match
---
operator: , [11584,11585]
operator: , [11584,11585]
===
match
---
number: 26 [22006,22008]
number: 26 [23383,23385]
===
match
---
operator: = [2627,2628]
operator: = [2627,2628]
===
match
---
atom_expr [10736,10755]
atom_expr [10736,10755]
===
match
---
operator: , [18585,18586]
operator: , [19962,19963]
===
match
---
name: self [10720,10724]
name: self [10720,10724]
===
match
---
name: fetcher [17653,17660]
name: fetcher [19030,19037]
===
match
---
string: "Task should remain in queue" [9182,9211]
string: "Task should remain in queue" [9182,9211]
===
match
---
with_item [12287,12364]
with_item [12287,12364]
===
match
---
name: queued_tasks [7578,7590]
name: queued_tasks [7578,7590]
===
match
---
operator: = [20450,20451]
operator: = [21827,21828]
===
match
---
name: executor [6325,6333]
name: executor [6325,6333]
===
match
---
operator: , [15821,15822]
operator: , [15821,15822]
===
match
---
operator: == [19688,19690]
operator: == [21065,21067]
===
match
---
atom [16121,16141]
atom [16121,16141]
===
match
---
operator: , [22249,22250]
operator: , [23626,23627]
===
match
---
atom [5713,5756]
atom [5713,5756]
===
match
---
operator: , [8869,8870]
operator: , [8869,8870]
===
match
---
name: mget_args [17999,18008]
name: mget_args [19376,19385]
===
match
---
name: mark [18429,18433]
name: mark [19806,19810]
===
match
---
name: try_number [15569,15579]
name: try_number [15569,15579]
===
match
---
suite [12680,12974]
suite [12680,12974]
===
match
---
name: patch [11215,11220]
name: patch [11215,11220]
===
match
---
argument [7093,7118]
argument [7093,7118]
===
match
---
operator: , [12285,12286]
operator: , [12285,12286]
===
match
---
name: patch [19991,19996]
name: patch [21368,21373]
===
match
---
assert_stmt [9984,10053]
assert_stmt [9984,10053]
===
match
---
name: QUEUED [14063,14069]
name: QUEUED [14063,14069]
===
match
---
testlist_comp [8845,8878]
testlist_comp [8845,8878]
===
match
---
operator: = [13917,13918]
operator: = [13917,13918]
===
match
---
atom_expr [17327,17341]
atom_expr [18704,18718]
===
match
---
operator: , [17613,17614]
operator: , [18990,18991]
===
match
---
name: start_date [13239,13249]
name: start_date [13239,13249]
===
match
---
name: mock [2699,2703]
name: mock [2699,2703]
===
match
---
name: task_id [15632,15639]
name: task_id [15632,15639]
===
match
---
string: 'ResultSession' [2916,2931]
string: 'ResultSession' [2916,2931]
===
match
---
trailer [3510,3516]
trailer [3510,3516]
===
match
---
atom_expr [5897,5909]
atom_expr [5897,5909]
===
match
---
number: 0 [6453,6454]
number: 0 [6453,6454]
===
match
---
dotted_name [15043,15062]
dotted_name [15043,15062]
===
match
---
expr_stmt [2645,2682]
expr_stmt [2645,2682]
===
match
---
name: now [7113,7116]
name: now [7113,7116]
===
match
---
operator: = [8622,8623]
operator: = [8622,8623]
===
match
---
number: 0 [7697,7698]
number: 0 [7697,7698]
===
match
---
operator: , [8563,8564]
operator: , [8563,8564]
===
match
---
atom [4907,5178]
atom [4907,5178]
===
match
---
name: start_date [15476,15486]
name: start_date [15476,15486]
===
match
---
comparison [9570,9601]
comparison [9570,9601]
===
match
---
assert_stmt [19487,19556]
assert_stmt [20864,20933]
===
match
---
trailer [15799,15821]
trailer [15799,15821]
===
match
---
atom_expr [15723,15753]
atom_expr [15723,15753]
===
match
---
name: range [22025,22030]
name: range [23402,23407]
===
match
---
name: command [12559,12566]
name: command [12559,12566]
===
match
---
name: db [3715,3717]
name: db [3715,3717]
===
match
---
decorator [3789,3823]
decorator [3789,3823]
===
match
---
operator: @ [19706,19707]
operator: @ [21083,21084]
===
match
---
number: 1 [7510,7511]
number: 1 [7510,7511]
===
match
---
name: heartbeat [9472,9481]
name: heartbeat [9472,9481]
===
match
---
name: test_exception_propagation [10656,10682]
name: test_exception_propagation [10656,10682]
===
match
---
operator: } [14440,14441]
operator: } [14440,14441]
===
match
---
atom [7372,7407]
atom [7372,7407]
===
match
---
atom_expr [14541,14551]
atom_expr [14541,14551]
===
match
---
operator: == [10095,10097]
operator: == [10095,10097]
===
match
---
simple_stmt [21376,21439]
simple_stmt [22753,22816]
===
match
---
atom_expr [6952,6984]
atom_expr [6952,6984]
===
match
---
name: self [11386,11390]
name: self [11386,11390]
===
match
---
trailer [12596,12614]
trailer [12596,12614]
===
match
---
trailer [17447,17543]
trailer [18824,18920]
===
match
---
operator: } [14998,14999]
operator: } [14998,14999]
===
match
---
name: mock [18109,18113]
name: mock [19486,19490]
===
match
---
operator: , [14900,14901]
operator: , [14900,14901]
===
match
---
name: celery_executor [10736,10751]
name: celery_executor [10736,10751]
===
match
---
string: """     Register the same signals as scheduler does to test celery_executor to make sure it does not     hang.     """ [21124,21242]
string: """     Register the same signals as scheduler does to test celery_executor to make sure it does not     hang.     """ [22501,22619]
===
match
---
funcdef [16782,16854]
funcdef [18159,18231]
===
match
---
operator: = [5502,5503]
operator: = [5502,5503]
===
match
---
operator: , [4976,4977]
operator: , [4976,4977]
===
match
---
trailer [8769,8810]
trailer [8769,8810]
===
match
---
simple_stmt [1029,1043]
simple_stmt [1029,1043]
===
match
---
fstring_string: ) [16719,16720]
fstring_string: ) [18096,18097]
===
match
---
name: mock [930,934]
name: mock [930,934]
===
match
---
simple_stmt [10983,11069]
simple_stmt [10983,11069]
===
match
---
trailer [2369,2373]
trailer [2369,2373]
===
match
---
name: patch_execute [2765,2778]
name: patch_execute [2765,2778]
===
match
---
name: task_publish_max_retries [8391,8415]
name: task_publish_max_retries [8391,8415]
===
match
---
operator: , [19177,19178]
operator: , [20554,20555]
===
match
---
atom_expr [5821,5893]
atom_expr [5821,5893]
===
match
---
trailer [15731,15753]
trailer [15731,15753]
===
match
---
name: parameterized [3740,3753]
name: parameterized [3740,3753]
===
match
---
assert_stmt [9692,9870]
assert_stmt [9692,9870]
===
match
---
operator: @ [19785,19786]
operator: @ [21162,21163]
===
match
---
name: task_id [15458,15465]
name: task_id [15458,15465]
===
match
---
name: side_effect [8209,8220]
name: side_effect [8209,8220]
===
match
---
trailer [17785,17800]
trailer [19162,19177]
===
match
---
atom_expr [16158,16172]
atom_expr [16158,16172]
===
match
---
atom_expr [7999,8013]
atom_expr [7999,8013]
===
match
---
atom_expr [17707,17896]
atom_expr [19084,19273]
===
match
---
name: task_publish_retries [9938,9958]
name: task_publish_retries [9938,9958]
===
match
---
dotted_name [1417,1435]
dotted_name [1417,1435]
===
match
---
expr_stmt [8651,8825]
expr_stmt [8651,8825]
===
match
---
name: DAG [13144,13147]
name: DAG [13144,13147]
===
match
---
string: "task_id" [2246,2255]
string: "task_id" [2246,2255]
===
match
---
trailer [10948,10973]
trailer [10948,10973]
===
match
---
trailer [8636,8638]
trailer [8636,8638]
===
match
---
dotted_name [6501,6524]
dotted_name [6501,6524]
===
match
---
operator: , [2013,2014]
operator: , [2013,2014]
===
match
---
name: executor [7473,7481]
name: executor [7473,7481]
===
match
---
argument [8543,8563]
argument [8543,8563]
===
match
---
argument [15458,15474]
argument [15458,15474]
===
match
---
with_stmt [17432,17897]
with_stmt [18809,19274]
===
match
---
trailer [13439,13444]
trailer [13439,13444]
===
match
---
with_stmt [12467,12568]
with_stmt [12467,12568]
===
match
---
operator: , [13485,13486]
operator: , [13485,13486]
===
match
---
atom_expr [10494,10555]
atom_expr [10494,10555]
===
match
---
simple_stmt [14595,14665]
simple_stmt [14595,14665]
===
match
---
operator: , [15399,15400]
operator: , [15399,15400]
===
match
---
operator: , [15567,15568]
operator: , [15567,15568]
===
match
---
name: MagicMock [19120,19129]
name: MagicMock [20497,20506]
===
match
---
name: mock_backend [20066,20078]
name: mock_backend [21443,21455]
===
match
---
param [16870,16875]
param [18247,18252]
===
match
---
param [20916,20924]
param [22293,22301]
===
match
---
name: signal [21391,21397]
name: signal [22768,22774]
===
match
---
name: start_worker [4441,4453]
name: start_worker [4441,4453]
===
match
---
atom [13331,13337]
atom [13331,13337]
===
match
---
trailer [9050,9060]
trailer [9050,9060]
===
match
---
name: Celery [2595,2601]
name: Celery [2595,2601]
===
match
---
name: all [19074,19077]
name: all [20451,20454]
===
match
---
trailer [9507,9538]
trailer [9507,9538]
===
match
---
operator: = [15215,15216]
operator: = [15215,15216]
===
match
---
name: ANY [11708,11711]
name: ANY [11708,11711]
===
match
---
atom_expr [4532,4546]
atom_expr [4532,4546]
===
match
---
operator: = [8534,8535]
operator: = [8534,8535]
===
match
---
name: state [20362,20367]
name: state [21739,21744]
===
match
---
name: queued_tasks [10424,10436]
name: queued_tasks [10424,10436]
===
match
---
operator: * [20909,20910]
operator: * [22286,22287]
===
match
---
dictorsetmaker [16085,16141]
dictorsetmaker [16085,16141]
===
match
---
operator: , [11819,11820]
operator: , [11819,11820]
===
match
---
argument [4454,4461]
argument [4454,4461]
===
match
---
number: 4 [9969,9970]
number: 4 [9969,9970]
===
match
---
return_stmt [2001,2071]
return_stmt [2001,2071]
===
match
---
expr_stmt [21943,22010]
expr_stmt [23320,23387]
===
match
---
name: executor [15948,15956]
name: executor [15948,15956]
===
match
---
operator: = [7085,7086]
operator: = [7085,7086]
===
match
---
name: MagicMock [19412,19421]
name: MagicMock [20789,20798]
===
match
---
trailer [11707,11711]
trailer [11707,11711]
===
match
---
argument [7298,7337]
argument [7298,7337]
===
match
---
trailer [3717,3731]
trailer [3717,3731]
===
match
---
arglist [21586,21612]
arglist [22963,22989]
===
match
---
atom_expr [1981,1991]
atom_expr [1981,1991]
===
match
---
string: 'fake_simple_ti' [4646,4662]
string: 'fake_simple_ti' [4646,4662]
===
match
---
atom [9677,9679]
atom [9677,9679]
===
match
---
name: self [17545,17549]
name: self [18922,18926]
===
match
---
string: "celery.backends.database.DatabaseBackend.ResultSession" [18359,18415]
string: "celery.backends.database.DatabaseBackend.ResultSession" [19736,19792]
===
match
---
operator: } [6426,6427]
operator: } [6426,6427]
===
match
---
trailer [8046,8050]
trailer [8046,8050]
===
match
---
trailer [14618,14664]
trailer [14618,14664]
===
match
---
name: dag [15613,15616]
name: dag [15613,15616]
===
match
---
comparison [9503,9550]
comparison [9503,9550]
===
match
---
simple_stmt [12633,12663]
simple_stmt [12633,12663]
===
match
---
comparison [7642,7719]
comparison [7642,7719]
===
match
---
arglist [3889,3908]
arglist [3889,3908]
===
match
---
operator: = [4267,4268]
operator: = [4267,4268]
===
match
---
with_stmt [7994,10572]
with_stmt [7994,10572]
===
match
---
atom_expr [7004,7132]
atom_expr [7004,7132]
===
match
---
simple_stmt [7420,7461]
simple_stmt [7420,7461]
===
match
---
name: value [16558,16563]
name: value [17935,17940]
===
match
---
atom_expr [8382,8415]
atom_expr [8382,8415]
===
match
---
trailer [7164,7166]
trailer [7164,7166]
===
match
---
with_item [17545,17635]
with_item [18922,19012]
===
match
---
name: mark [7812,7816]
name: mark [7812,7816]
===
match
---
operator: , [12891,12892]
operator: , [12891,12892]
===
match
---
operator: , [16105,16106]
operator: , [16105,16106]
===
match
---
name: setattr [16595,16602]
name: setattr [17972,17979]
===
match
---
name: fetcher [20257,20264]
name: fetcher [21634,21641]
===
match
---
atom_expr [14980,14998]
atom_expr [14980,14998]
===
match
---
operator: } [21003,21004]
operator: } [22380,22381]
===
match
---
expr_stmt [8469,8604]
expr_stmt [8469,8604]
===
match
---
fstring_expr [16699,16719]
fstring_expr [18076,18096]
===
match
---
name: ResultSession [18979,18992]
name: ResultSession [20356,20369]
===
match
---
trailer [10358,10379]
trailer [10358,10379]
===
match
---
argument [8786,8795]
argument [8786,8795]
===
match
---
name: tis [13440,13443]
name: tis [13440,13443]
===
match
---
assert_stmt [8320,8362]
assert_stmt [8320,8362]
===
match
---
expr_stmt [15948,16019]
expr_stmt [15948,16019]
===
match
---
name: key [9964,9967]
name: key [9964,9967]
===
match
---
expr_stmt [7366,7407]
expr_stmt [7366,7407]
===
match
---
import_from [1850,1887]
import_from [1850,1887]
===
match
---
name: task [8791,8795]
name: task [8791,8795]
===
match
---
name: expand [11793,11799]
name: expand [11793,11799]
===
match
---
number: 1 [9149,9150]
number: 1 [9149,9150]
===
match
---
simple_stmt [18075,18119]
simple_stmt [19452,19496]
===
match
---
name: TestCase [3553,3561]
name: TestCase [3553,3561]
===
match
---
name: integration [17149,17160]
name: integration [18526,18537]
===
match
---
parameters [13536,13542]
parameters [13536,13542]
===
match
---
trailer [19900,19902]
trailer [21277,21279]
===
match
---
atom [18213,18328]
atom [19590,19705]
===
match
---
trailer [14734,14766]
trailer [14734,14766]
===
match
---
fstring_expr [9414,9419]
fstring_expr [9414,9419]
===
match
---
atom [11810,11832]
atom [11810,11832]
===
match
---
name: broker_url [2351,2361]
name: broker_url [2351,2361]
===
match
---
number: 0 [6273,6274]
number: 0 [6273,6274]
===
match
---
operator: , [22255,22256]
operator: , [23632,23633]
===
match
---
argument [18913,18926]
argument [20290,20303]
===
match
---
name: task [8469,8473]
name: task [8469,8473]
===
match
---
import_from [1526,1588]
import_from [1526,1588]
===
match
---
operator: = [13310,13311]
operator: = [13310,13311]
===
match
---
name: pytest [18501,18507]
name: pytest [19878,19884]
===
match
---
atom_expr [12287,12351]
atom_expr [12287,12351]
===
match
---
name: ValueError [11821,11831]
name: ValueError [11821,11831]
===
match
---
atom_expr [11058,11067]
atom_expr [11058,11067]
===
match
---
trailer [17560,17629]
trailer [18937,19006]
===
match
---
atom [10849,10876]
atom [10849,10876]
===
match
---
operator: @ [17215,17216]
operator: @ [18592,18593]
===
match
---
fstring_end: " [10263,10264]
fstring_end: " [10263,10264]
===
match
---
name: ti1 [14045,14048]
name: ti1 [14045,14048]
===
match
---
name: key_1 [16085,16090]
name: key_1 [16085,16090]
===
match
---
import_from [1642,1676]
import_from [1642,1676]
===
match
---
operator: == [9539,9541]
operator: == [9539,9541]
===
match
---
name: executor [14927,14935]
name: executor [14927,14935]
===
match
---
name: celery [1198,1204]
name: celery [1198,1204]
===
match
---
simple_stmt [909,935]
simple_stmt [909,935]
===
match
---
with_stmt [18610,19478]
with_stmt [19987,20855]
===
match
---
name: utcnow [15226,15232]
name: utcnow [15226,15232]
===
match
---
simple_stmt [8320,8363]
simple_stmt [8320,8363]
===
match
---
parameters [3941,3959]
parameters [3941,3959]
===
match
---
param [16793,16798]
param [18170,18175]
===
match
---
string: "232" [16012,16017]
string: "232" [16012,16017]
===
match
---
parameters [2301,2332]
parameters [2301,2332]
===
match
---
name: mock_mget [17960,17969]
name: mock_mget [19337,19346]
===
match
---
operator: + [14868,14869]
operator: + [14868,14869]
===
match
---
trailer [11009,11037]
trailer [11009,11037]
===
match
---
operator: = [10785,10786]
operator: = [10785,10786]
===
match
---
operator: , [10718,10719]
operator: , [10718,10719]
===
match
---
operator: == [10556,10558]
operator: == [10556,10558]
===
match
---
import_from [1069,1139]
import_from [1069,1139]
===
match
---
string: "PENDING" [18180,18189]
string: "PENDING" [19557,19566]
===
match
---
simple_stmt [2533,2580]
simple_stmt [2533,2580]
===
match
---
testlist_comp [5321,5346]
testlist_comp [5321,5346]
===
match
---
name: executor [10949,10957]
name: executor [10949,10957]
===
match
---
atom [16084,16142]
atom [16084,16142]
===
match
---
name: result [18135,18141]
name: result [19512,19518]
===
match
---
operator: = [8790,8791]
operator: = [8790,8791]
===
match
---
simple_stmt [19487,19557]
simple_stmt [20864,20934]
===
match
---
name: mock [11553,11557]
name: mock [11553,11557]
===
match
---
comparison [1957,1991]
comparison [1957,1991]
===
match
---
fstring_string: ( [16698,16699]
fstring_string: ( [18075,18076]
===
match
---
trailer [10963,10970]
trailer [10963,10970]
===
match
---
dotted_name [1893,1909]
dotted_name [1893,1909]
===
match
---
testlist_comp [11810,11907]
testlist_comp [11810,11907]
===
match
---
name: tasks [10958,10963]
name: tasks [10958,10963]
===
match
---
operator: == [9960,9962]
operator: == [9960,9962]
===
match
---
trailer [12542,12558]
trailer [12542,12558]
===
match
---
operator: , [14645,14646]
operator: , [14645,14646]
===
match
---
atom_expr [7301,7337]
atom_expr [7301,7337]
===
match
---
name: when [7399,7403]
name: when [7399,7403]
===
match
---
name: State [14057,14062]
name: State [14057,14062]
===
match
---
trailer [15631,15639]
trailer [15631,15639]
===
match
---
atom_expr [16951,16968]
atom_expr [18328,18345]
===
match
---
testlist_comp [19352,19437]
testlist_comp [20729,20814]
===
match
---
trailer [7532,7542]
trailer [7532,7542]
===
match
---
operator: == [12934,12936]
operator: == [12934,12936]
===
match
---
name: integration [7738,7749]
name: integration [7738,7749]
===
match
---
string: 'celery' [2094,2102]
string: 'celery' [2094,2102]
===
match
---
name: base [1090,1094]
name: base [1090,1094]
===
match
---
name: event_buffer [6215,6227]
name: event_buffer [6215,6227]
===
match
---
name: execute_command [2439,2454]
name: execute_command [2439,2454]
===
match
---
operator: , [5155,5156]
operator: , [5155,5156]
===
match
---
expr_stmt [14172,14201]
expr_stmt [14172,14201]
===
match
---
atom [4634,4680]
atom [4634,4680]
===
match
---
atom_expr [6369,6383]
atom_expr [6369,6383]
===
match
---
string: 'fake_simple_ti' [7673,7689]
string: 'fake_simple_ti' [7673,7689]
===
match
---
name: executor [9231,9239]
name: executor [9231,9239]
===
match
---
name: airflow [1682,1689]
name: airflow [1682,1689]
===
match
---
name: pytest [10607,10613]
name: pytest [10607,10613]
===
match
---
name: AsyncResult [14953,14964]
name: AsyncResult [14953,14964]
===
match
---
argument [6067,6083]
argument [6067,6083]
===
match
---
name: patch [12191,12196]
name: patch [12191,12196]
===
match
---
suite [18630,19478]
suite [20007,20855]
===
match
---
string: 'fail' [5714,5720]
string: 'fail' [5714,5720]
===
match
---
name: celery_executor [4321,4336]
name: celery_executor [4321,4336]
===
match
---
expr_stmt [14131,14163]
expr_stmt [14131,14163]
===
match
---
name: backend [6592,6599]
name: backend [6592,6599]
===
match
---
name: airflow [1647,1654]
name: airflow [1647,1654]
===
match
---
name: _ [21995,21996]
name: _ [23372,23373]
===
match
---
atom_expr [6054,6084]
atom_expr [6054,6084]
===
match
---
simple_stmt [14362,14406]
simple_stmt [14362,14406]
===
match
---
atom_expr [7075,7091]
atom_expr [7075,7091]
===
match
---
name: when [10543,10547]
name: when [10543,10547]
===
match
---
name: success_command [3969,3984]
name: success_command [3969,3984]
===
match
---
fstring_expr [9835,9840]
fstring_expr [9835,9840]
===
match
---
operator: @ [11291,11292]
operator: @ [11291,11292]
===
match
---
name: mark [19714,19718]
name: mark [21091,21095]
===
match
---
arglist [13788,13827]
arglist [13788,13827]
===
match
---
name: setUp [3572,3577]
name: setUp [3572,3577]
===
match
---
classdef [16924,20726]
classdef [18301,22103]
===
match
---
name: MagicMock [19936,19945]
name: MagicMock [21313,21322]
===
match
---
assert_stmt [5792,5927]
assert_stmt [5792,5927]
===
match
---
name: BulkStateFetcher [1572,1588]
name: BulkStateFetcher [1572,1588]
===
match
---
decorator [19744,19781]
decorator [21121,21158]
===
match
---
simple_stmt [10305,10326]
simple_stmt [10305,10326]
===
match
---
atom_expr [7104,7118]
atom_expr [7104,7118]
===
match
---
argument [13788,13804]
argument [13788,13804]
===
match
---
argument [19946,19966]
argument [21323,21343]
===
match
---
operator: , [15623,15624]
operator: , [15623,15624]
===
match
---
expr_stmt [15361,15423]
expr_stmt [15361,15423]
===
match
---
expr_stmt [5467,5505]
expr_stmt [5467,5505]
===
match
---
simple_stmt [1412,1480]
simple_stmt [1412,1480]
===
match
---
name: call [11672,11676]
name: call [11672,11676]
===
match
---
name: os [20992,20994]
name: os [22369,22371]
===
match
---
name: set_event_loop [3496,3510]
name: set_event_loop [3496,3510]
===
match
---
string: "rabbitmq" [17199,17209]
string: "rabbitmq" [18576,18586]
===
match
---
trailer [15531,15580]
trailer [15531,15580]
===
match
---
name: range [22000,22005]
name: range [23377,23382]
===
match
---
simple_stmt [8838,8880]
simple_stmt [8838,8880]
===
match
---
operator: = [15923,15924]
operator: = [15923,15924]
===
match
---
name: signal [834,840]
name: signal [834,840]
===
match
---
decorated [10577,11131]
decorated [10577,11131]
===
match
---
trailer [11491,11493]
trailer [11491,11493]
===
match
---
string: "airflow.executors.celery_executor.BulkStateFetcher" [17561,17613]
string: "airflow.executors.celery_executor.BulkStateFetcher" [18938,18990]
===
match
---
name: when [7691,7695]
name: when [7691,7695]
===
match
---
trailer [7160,7164]
trailer [7160,7164]
===
match
---
argument [8209,8239]
argument [8209,8239]
===
match
---
name: celery_configuration [5056,5076]
name: celery_configuration [5056,5076]
===
match
---
expr_stmt [4310,4353]
expr_stmt [4310,4353]
===
match
---
atom_expr [6024,6036]
atom_expr [6024,6036]
===
match
---
dictorsetmaker [15926,15938]
dictorsetmaker [15926,15938]
===
match
---
comparison [16235,16271]
comparison [16235,16271]
===
match
---
string: "test_try_adopt_task_instances_none" [13708,13744]
string: "test_try_adopt_task_instances_none" [13708,13744]
===
match
---
trailer [19990,19996]
trailer [21367,21373]
===
match
---
operator: , [5687,5688]
operator: , [5687,5688]
===
match
---
dictorsetmaker [20530,20580]
dictorsetmaker [21907,21957]
===
match
---
arglist [11563,11594]
arglist [11563,11594]
===
match
---
dotted_name [17175,17198]
dotted_name [18552,18575]
===
match
---
expr_stmt [22155,22216]
expr_stmt [23532,23593]
===
match
---
name: executor [9929,9937]
name: executor [9929,9937]
===
match
---
trailer [19693,19700]
trailer [21070,21077]
===
match
---
name: utcnow [13101,13107]
name: utcnow [13101,13107]
===
match
---
arglist [15532,15579]
arglist [15532,15579]
===
match
---
name: execute_command [12713,12728]
name: execute_command [12713,12728]
===
match
---
arglist [21339,21370]
arglist [22716,22747]
===
match
---
simple_stmt [5585,5776]
simple_stmt [5585,5776]
===
match
---
trailer [4762,4783]
trailer [4762,4783]
===
match
---
name: task_2 [15625,15631]
name: task_2 [15625,15631]
===
match
---
trailer [7663,7700]
trailer [7663,7700]
===
match
---
simple_stmt [3496,3517]
simple_stmt [3496,3517]
===
match
---
atom [9278,9449]
atom [9278,9449]
===
match
---
name: results [22232,22239]
name: results [23609,23616]
===
match
---
atom_expr [21586,21599]
atom_expr [22963,22976]
===
match
---
testlist_comp [5714,5755]
testlist_comp [5714,5755]
===
match
---
name: mock [19931,19935]
name: mock [21308,21312]
===
match
---
trailer [19945,19967]
trailer [21322,21344]
===
match
---
atom_expr [21883,21915]
atom_expr [23260,23292]
===
match
---
comparison [8327,8362]
comparison [8327,8362]
===
match
---
dictorsetmaker [10850,10875]
dictorsetmaker [10850,10875]
===
match
---
name: values [10964,10970]
name: values [10964,10970]
===
match
---
name: command [5422,5429]
name: command [5422,5429]
===
match
---
name: MagicMock [17776,17785]
name: MagicMock [19153,19162]
===
match
---
name: test_try_adopt_task_instances [13507,13536]
name: test_try_adopt_task_instances [13507,13536]
===
match
---
arglist [2792,2857]
arglist [2792,2857]
===
match
---
name: integration [7776,7787]
name: integration [7776,7787]
===
match
---
operator: = [17793,17794]
operator: = [19170,19171]
===
match
---
arglist [15613,15660]
arglist [15613,15660]
===
match
---
string: "celery.app.task.Task.request" [12311,12341]
string: "celery.app.task.Task.request" [12311,12341]
===
match
---
atom [9963,9971]
atom [9963,9971]
===
match
---
name: task_1 [15361,15367]
name: task_1 [15361,15367]
===
match
---
assert_stmt [6199,6291]
assert_stmt [6199,6291]
===
match
---
trailer [15984,15991]
trailer [15984,15991]
===
match
---
operator: } [16270,16271]
operator: } [16270,16271]
===
match
---
string: 'info' [4492,4498]
string: 'info' [4492,4498]
===
match
---
trailer [16774,16776]
trailer [18151,18153]
===
match
---
operator: } [14713,14714]
operator: } [14713,14714]
===
match
---
comparison [19572,19700]
comparison [20949,21077]
===
match
---
param [15129,15133]
param [15129,15133]
===
match
---
string: "postgres" [3898,3908]
string: "postgres" [3898,3908]
===
match
---
number: 1 [8710,8711]
number: 1 [8710,8711]
===
match
---
simple_stmt [868,909]
simple_stmt [868,909]
===
match
---
operator: , [17515,17516]
operator: , [18892,18893]
===
match
---
decorated [19706,20726]
decorated [21083,22103]
===
match
---
atom_expr [12584,12616]
atom_expr [12584,12616]
===
match
---
operator: , [5871,5872]
operator: , [5871,5872]
===
match
---
simple_stmt [13611,13666]
simple_stmt [13611,13666]
===
match
---
name: utcnow [13574,13580]
name: utcnow [13574,13580]
===
match
---
operator: , [8810,8811]
operator: , [8810,8811]
===
match
---
string: "rabbitmq" [7788,7798]
string: "rabbitmq" [7788,7798]
===
match
---
trailer [9902,9904]
trailer [9902,9904]
===
match
---
operator: @ [11136,11137]
operator: @ [11136,11137]
===
match
---
decorator [3739,3785]
decorator [3739,3785]
===
match
---
name: task_id [13221,13228]
name: task_id [13221,13228]
===
match
---
trailer [14295,14310]
trailer [14295,14310]
===
match
---
name: line [11041,11045]
name: line [11041,11045]
===
match
---
name: key [10257,10260]
name: key [10257,10260]
===
match
---
trailer [13633,13640]
trailer [13633,13640]
===
match
---
expr_stmt [14269,14312]
expr_stmt [14269,14312]
===
match
---
suite [15135,16272]
suite [15135,16272]
===
match
---
string: 'run' [11894,11899]
string: 'run' [11894,11899]
===
match
---
operator: @ [6500,6501]
operator: @ [6500,6501]
===
match
---
operator: = [19286,19287]
operator: = [20663,20664]
===
match
---
string: "celery.backends.base.BaseKeyValueStoreBackend.mget" [16996,17048]
string: "celery.backends.base.BaseKeyValueStoreBackend.mget" [18373,18425]
===
match
---
trailer [15300,15340]
trailer [15300,15340]
===
match
---
simple_stmt [15361,15424]
simple_stmt [15361,15424]
===
match
---
name: key [9415,9418]
name: key [9415,9418]
===
match
---
atom_expr [5597,5618]
atom_expr [5597,5618]
===
match
---
trailer [12822,12832]
trailer [12822,12832]
===
match
---
name: AsyncResult [16000,16011]
name: AsyncResult [16000,16011]
===
match
---
name: event_buffer [10503,10515]
name: event_buffer [10503,10515]
===
match
---
operator: , [14551,14552]
operator: , [14551,14552]
===
match
---
name: utcnow [13634,13640]
name: utcnow [13634,13640]
===
match
---
string: "task_id" [17105,17114]
string: "task_id" [18482,18491]
===
match
---
name: test_check_for_stalled_adopted_tasks [15092,15128]
name: test_check_for_stalled_adopted_tasks [15092,15128]
===
match
---
trailer [19366,19381]
trailer [20743,20758]
===
match
---
name: conf [2085,2089]
name: conf [2085,2089]
===
match
---
name: executor [6941,6949]
name: executor [6941,6949]
===
match
---
operator: , [18040,18041]
operator: , [19417,19418]
===
match
---
string: 'airflow.executors.celery_executor.execute_command' [2792,2843]
string: 'airflow.executors.celery_executor.execute_command' [2792,2843]
===
match
---
name: task_id [20430,20437]
name: task_id [21807,21814]
===
match
---
operator: , [4006,4007]
operator: , [4006,4007]
===
match
---
simple_stmt [10487,10572]
simple_stmt [10487,10572]
===
match
---
atom_expr [14805,14835]
atom_expr [14805,14835]
===
match
---
atom [11872,11907]
atom [11872,11907]
===
match
---
atom_expr [13585,13602]
atom_expr [13585,13602]
===
match
---
name: key_2 [15993,15998]
name: key_2 [15993,15998]
===
match
---
argument [19130,19197]
argument [20507,20574]
===
match
---
name: mock_task [12355,12364]
name: mock_task [12355,12364]
===
match
---
assert_stmt [22225,22289]
assert_stmt [23602,23666]
===
match
---
name: task_1 [13937,13943]
name: task_1 [13937,13943]
===
match
---
name: get_many [17715,17723]
name: get_many [19092,19100]
===
match
---
atom_expr [8059,8250]
atom_expr [8059,8250]
===
match
---
number: 2 [15192,15193]
number: 2 [15192,15193]
===
match
---
operator: = [14055,14056]
operator: = [14055,14056]
===
match
---
trailer [19060,19073]
trailer [20437,20450]
===
match
---
operator: = [8663,8664]
operator: = [8663,8664]
===
match
---
atom [12836,12910]
atom [12836,12910]
===
match
---
arith_expr [15777,15821]
arith_expr [15777,15821]
===
match
---
name: mock [12287,12291]
name: mock [12287,12291]
===
match
---
operator: { [14700,14701]
operator: { [14700,14701]
===
match
---
name: sys [848,851]
name: sys [848,851]
===
match
---
name: value_tuple [7449,7460]
name: value_tuple [7449,7460]
===
match
---
operator: == [6021,6023]
operator: == [6021,6023]
===
match
---
name: orig_sigint [21311,21322]
name: orig_sigint [22688,22699]
===
match
---
number: 1 [20229,20230]
number: 1 [21606,21607]
===
match
---
string: "true" [7063,7069]
string: "true" [7063,7069]
===
match
---
name: execute_date [4664,4676]
name: execute_date [4664,4676]
===
match
---
operator: = [13951,13952]
operator: = [13951,13952]
===
match
---
expr_stmt [3969,4040]
expr_stmt [3969,4040]
===
match
---
simple_stmt [7553,7627]
simple_stmt [7553,7627]
===
match
---
simple_stmt [19565,19701]
simple_stmt [20942,21078]
===
match
---
name: cm [11058,11060]
name: cm [11058,11060]
===
match
---
trailer [18113,18117]
trailer [19490,19494]
===
match
---
string: 'executor.queued_tasks' [11619,11642]
string: 'executor.queued_tasks' [11619,11642]
===
match
---
name: task [7314,7318]
name: task [7314,7318]
===
match
---
simple_stmt [14131,14164]
simple_stmt [14131,14164]
===
match
---
name: timedelta [15237,15246]
name: timedelta [15237,15246]
===
match
---
expr_stmt [8264,8307]
expr_stmt [8264,8307]
===
match
---
atom [17745,17878]
atom [19122,19255]
===
match
---
string: 'fail' [6355,6361]
string: 'fail' [6355,6361]
===
match
---
name: celery_configuration [4763,4783]
name: celery_configuration [4763,4783]
===
match
---
atom_expr [13704,13745]
atom_expr [13704,13745]
===
match
---
atom [2552,2578]
atom [2552,2578]
===
match
---
funcdef [16626,16722]
funcdef [18003,18099]
===
match
---
operator: , [4258,4259]
operator: , [4258,4259]
===
match
---
name: get_many [19296,19304]
name: get_many [20673,20681]
===
match
---
trailer [21631,21661]
trailer [23008,23038]
===
match
---
suite [4297,6085]
suite [4297,6085]
===
match
---
atom [20563,20580]
atom [21940,21957]
===
match
---
operator: , [7048,7049]
operator: , [7048,7049]
===
match
---
name: level [18913,18918]
name: level [20290,20295]
===
match
---
simple_stmt [14078,14123]
simple_stmt [14078,14123]
===
match
---
operator: = [21289,21290]
operator: = [22666,22667]
===
match
---
trailer [21679,21709]
trailer [23056,23086]
===
match
---
atom_expr [19244,19262]
atom_expr [20621,20639]
===
match
---
simple_stmt [20248,20503]
simple_stmt [21625,21880]
===
match
---
number: 1 [15281,15282]
number: 1 [15281,15282]
===
match
---
operator: = [13891,13892]
operator: = [13891,13892]
===
match
---
operator: == [9993,9995]
operator: == [9993,9995]
===
match
---
name: self [6653,6657]
name: self [6653,6657]
===
match
---
string: 'airflow' [11836,11845]
string: 'airflow' [11836,11845]
===
match
---
name: executor [4310,4318]
name: executor [4310,4318]
===
match
---
suite [16970,20726]
suite [18347,22103]
===
match
---
name: executor [5523,5531]
name: executor [5523,5531]
===
match
---
name: executor [9508,9516]
name: executor [9508,9516]
===
match
---
name: executor [16194,16202]
name: executor [16194,16202]
===
match
---
decorators [11136,11350]
decorators [11136,11350]
===
match
---
trailer [6377,6383]
trailer [6377,6383]
===
match
---
name: CeleryExecutor [6968,6982]
name: CeleryExecutor [6968,6982]
===
match
---
trailer [19073,19077]
trailer [20450,20454]
===
match
---
string: 'SUCCESS' [20368,20377]
string: 'SUCCESS' [21745,21754]
===
match
---
operator: , [2843,2844]
operator: , [2843,2844]
===
match
---
trailer [14048,14054]
trailer [14048,14054]
===
match
---
comparison [14421,14441]
comparison [14421,14441]
===
match
---
simple_stmt [21511,21517]
simple_stmt [22888,22894]
===
match
---
trailer [21913,21915]
trailer [23290,23292]
===
match
---
number: 30 [15255,15257]
number: 30 [15255,15257]
===
match
---
name: AirflowTaskTimeout [8221,8239]
name: AirflowTaskTimeout [8221,8239]
===
match
---
atom_expr [9154,9180]
atom_expr [9154,9180]
===
match
---
atom [5421,5446]
atom [5421,5446]
===
match
---
trailer [2490,2528]
trailer [2490,2528]
===
match
---
decorators [10577,10648]
decorators [10577,10648]
===
match
---
name: dict [9082,9086]
name: dict [9082,9086]
===
match
---
atom_expr [6206,6275]
atom_expr [6206,6275]
===
match
---
name: executor [14421,14429]
name: executor [14421,14429]
===
match
---
trailer [16703,16718]
trailer [18080,18095]
===
match
---
expr_stmt [2338,2397]
expr_stmt [2338,2397]
===
match
---
atom_expr [16903,16921]
atom_expr [18280,18298]
===
match
---
simple_stmt [21921,21939]
simple_stmt [23298,23316]
===
match
---
string: b'celery-task-meta-456' [18017,18040]
string: b'celery-task-meta-456' [19394,19417]
===
match
---
name: external_executor_id [13970,13990]
name: external_executor_id [13970,13990]
===
match
---
name: key [16553,16556]
name: key [17930,17933]
===
match
---
operator: } [18065,18066]
operator: } [19442,19443]
===
match
---
argument [13595,13601]
argument [13595,13601]
===
match
---
testlist_comp [16122,16140]
testlist_comp [16122,16140]
===
match
---
atom [8665,8825]
atom [8665,8825]
===
match
---
string: "123" [17116,17121]
string: "123" [18493,18498]
===
match
---
operator: , [2382,2383]
operator: , [2382,2383]
===
match
---
simple_stmt [11732,11773]
simple_stmt [11732,11773]
===
match
---
operator: { [18145,18146]
operator: { [19522,19523]
===
match
---
trailer [3617,3619]
trailer [3617,3619]
===
match
---
expr_stmt [21443,21505]
expr_stmt [22820,22882]
===
match
---
atom [19512,19529]
atom [20889,20906]
===
match
---
operator: , [18163,18164]
operator: , [19540,19541]
===
match
---
name: assertLogs [10725,10735]
name: assertLogs [10725,10735]
===
match
---
atom_expr [14280,14312]
atom_expr [14280,14312]
===
match
---
suite [11982,12974]
suite [11982,12974]
===
match
---
name: patch [11142,11147]
name: patch [11142,11147]
===
match
---
string: 'key' [10850,10855]
string: 'key' [10850,10855]
===
match
---
argument [7314,7323]
argument [7314,7323]
===
match
---
name: ClassWithCustomAttributes [20404,20429]
name: ClassWithCustomAttributes [21781,21806]
===
match
---
name: executor [11450,11458]
name: executor [11450,11458]
===
match
---
comparison [10406,10437]
comparison [10406,10437]
===
match
---
fstring_string:  Exiting gracefully upon receiving signal  [21004,21046]
fstring_string:  Exiting gracefully upon receiving signal  [22381,22423]
===
match
---
name: key_2 [14595,14600]
name: key_2 [14595,14600]
===
match
---
trailer [15186,15194]
trailer [15186,15194]
===
match
---
atom_expr [8147,8170]
atom_expr [8147,8170]
===
match
---
operator: } [16177,16178]
operator: } [16177,16178]
===
match
---
argument [6740,6768]
argument [6740,6768]
===
match
---
string: "PENDING" [20564,20573]
string: "PENDING" [21941,21950]
===
match
---
string: "Task should remain in queue" [10024,10053]
string: "Task should remain in queue" [10024,10053]
===
match
---
trailer [20718,20725]
trailer [22095,22102]
===
match
---
atom_expr [15948,15962]
atom_expr [15948,15962]
===
match
---
param [20975,20976]
param [22352,22353]
===
match
---
name: queued_tasks [7429,7441]
name: queued_tasks [7429,7441]
===
match
---
number: 1 [5504,5505]
number: 1 [5504,5505]
===
match
---
argument [15383,15399]
argument [15383,15399]
===
match
---
dotted_name [1253,1266]
dotted_name [1253,1266]
===
match
---
simple_stmt [17698,17897]
simple_stmt [19075,19274]
===
match
---
operator: } [15896,15897]
operator: } [15896,15897]
===
match
---
string: "Task should no longer be in queue" [10439,10474]
string: "Task should no longer be in queue" [10439,10474]
===
match
---
name: mock_subproc [12172,12184]
name: mock_subproc [12172,12184]
===
match
---
name: FAILED [7713,7719]
name: FAILED [7713,7719]
===
match
---
name: backend [3278,3285]
name: backend [3278,3285]
===
match
---
name: tasks [4382,4387]
name: tasks [4382,4387]
===
match
---
atom_expr [7473,7507]
atom_expr [7473,7507]
===
match
---
dotted_name [3740,3760]
dotted_name [3740,3760]
===
match
---
argument [13221,13237]
argument [13221,13237]
===
match
---
name: value [16614,16619]
name: value [17991,17996]
===
match
---
name: event_buffer [16068,16080]
name: event_buffer [16068,16080]
===
match
---
name: __dict__ [16709,16717]
name: __dict__ [18086,18094]
===
match
---
comparison [16194,16219]
comparison [16194,16219]
===
match
---
name: dag [1662,1665]
name: dag [1662,1665]
===
match
---
operator: , [13237,13238]
operator: , [13237,13238]
===
match
---
operator: , [5720,5721]
operator: , [5720,5721]
===
match
---
atom_expr [15217,15234]
atom_expr [15217,15234]
===
match
---
trailer [10423,10436]
trailer [10423,10436]
===
match
---
name: backends [1081,1089]
name: backends [1081,1089]
===
match
---
trailer [2668,2673]
trailer [2668,2673]
===
match
---
expr_stmt [8892,8932]
expr_stmt [8892,8932]
===
match
---
string: "to_dict.return_value" [19133,19155]
string: "to_dict.return_value" [20510,20532]
===
match
---
operator: = [13228,13229]
operator: = [13228,13229]
===
match
---
trailer [21478,21486]
trailer [22855,22863]
===
match
---
operator: , [11701,11702]
operator: , [11701,11702]
===
match
---
simple_stmt [10113,10292]
simple_stmt [10113,10292]
===
match
---
trailer [15864,15886]
trailer [15864,15886]
===
match
---
simple_stmt [21311,21372]
simple_stmt [22688,22749]
===
match
---
trailer [8900,8913]
trailer [8900,8913]
===
match
---
sync_comp_for [11108,11129]
sync_comp_for [11108,11129]
===
match
---
trailer [11613,11618]
trailer [11613,11618]
===
match
---
operator: { [9121,9122]
operator: { [9121,9122]
===
match
---
string: '123' [19505,19510]
string: '123' [20882,20887]
===
match
---
exprlist [16553,16563]
exprlist [17930,17940]
===
match
---
name: task_tuples_to_send [22196,22215]
name: task_tuples_to_send [23573,23592]
===
match
---
name: cm [11120,11122]
name: cm [11120,11122]
===
match
---
operator: , [11408,11409]
operator: , [11408,11409]
===
match
---
name: key_1 [15926,15931]
name: key_1 [15926,15931]
===
match
---
trailer [16844,16853]
trailer [18221,18230]
===
match
---
name: BaseOperator [15445,15457]
name: BaseOperator [15445,15457]
===
match
---
operator: == [9118,9120]
operator: == [9118,9120]
===
match
---
simple_stmt [15723,15898]
simple_stmt [15723,15898]
===
match
---
string: "PENDING" [19539,19548]
string: "PENDING" [20916,20925]
===
match
---
simple_stmt [17945,17980]
simple_stmt [19322,19357]
===
match
---
import_from [1332,1371]
import_from [1332,1371]
===
match
---
operator: == [9572,9574]
operator: == [9572,9574]
===
match
---
operator: = [20354,20355]
operator: = [21731,21732]
===
match
---
name: dag [15344,15347]
name: dag [15344,15347]
===
match
---
expr_stmt [6941,6984]
expr_stmt [6941,6984]
===
match
---
name: celery_executor [12697,12712]
name: celery_executor [12697,12712]
===
match
---
fstring_string: [Try 3 of 3] Task Timeout Error for Task: ( [10213,10256]
fstring_string: [Try 3 of 3] Task Timeout Error for Task: ( [10213,10256]
===
match
---
name: TestCase [16960,16968]
name: TestCase [18337,18345]
===
match
---
param [11392,11409]
param [11392,11409]
===
match
---
trailer [7700,7703]
trailer [7700,7703]
===
match
---
name: BaseOperator [1629,1641]
name: BaseOperator [1629,1641]
===
match
---
dotted_name [3828,3851]
dotted_name [3828,3851]
===
match
---
arglist [6453,6459]
arglist [6453,6459]
===
match
---
simple_stmt [6199,6292]
simple_stmt [6199,6292]
===
match
---
comparison [6355,6383]
comparison [6355,6383]
===
match
---
name: executor [15856,15864]
name: executor [15856,15864]
===
match
---
name: contextlib [2259,2269]
name: contextlib [2259,2269]
===
match
---
argument [19367,19380]
argument [20744,20757]
===
match
---
simple_stmt [14920,15000]
simple_stmt [14920,15000]
===
match
---
decorator [18500,18542]
decorator [19877,19919]
===
match
---
decorated [12979,13452]
decorated [12979,13452]
===
match
---
import_from [1286,1331]
import_from [1286,1331]
===
match
---
atom_expr [4373,4387]
atom_expr [4373,4387]
===
match
---
operator: { [16662,16663]
operator: { [18039,18040]
===
match
---
name: key_1 [14517,14522]
name: key_1 [14517,14522]
===
match
---
operator: } [16718,16719]
operator: } [18095,18096]
===
match
---
name: integration [17187,17198]
name: integration [18564,18575]
===
match
---
trailer [13107,13109]
trailer [13107,13109]
===
match
---
name: celery_executor [15682,15697]
name: celery_executor [15682,15697]
===
match
---
param [11410,11429]
param [11410,11429]
===
match
---
atom_expr [19986,20092]
atom_expr [21363,21469]
===
match
---
operator: = [12391,12392]
operator: = [12391,12392]
===
match
---
name: start_date [13806,13816]
name: start_date [13806,13816]
===
match
---
operator: } [16697,16698]
operator: } [18074,18075]
===
match
---
string: 'success' [4635,4644]
string: 'success' [4635,4644]
===
match
---
param [2302,2318]
param [2302,2318]
===
match
---
suite [19874,20726]
suite [21251,22103]
===
match
---
atom [19538,19555]
atom [20915,20932]
===
match
---
atom_expr [15791,15821]
atom_expr [15791,15821]
===
match
---
operator: , [6151,6152]
operator: , [6151,6152]
===
match
---
operator: , [10437,10438]
operator: , [10437,10438]
===
match
---
name: assert_not_called [12597,12614]
name: assert_not_called [12597,12614]
===
match
---
name: queued_dttm [14856,14867]
name: queued_dttm [14856,14867]
===
match
---
trailer [20109,20178]
trailer [21486,21555]
===
match
---
name: other [16876,16881]
name: other [18253,18258]
===
match
---
decorator [16975,17132]
decorator [18352,18509]
===
match
---
name: fail_command [4049,4061]
name: fail_command [4049,4061]
===
match
---
sync_comp_for [11046,11067]
sync_comp_for [11046,11067]
===
match
---
operator: , [18189,18190]
operator: , [19566,19567]
===
match
---
expr_stmt [13325,13337]
expr_stmt [13325,13337]
===
match
---
operator: = [15390,15391]
operator: = [15390,15391]
===
match
---
operator: @ [3789,3790]
operator: @ [3789,3790]
===
match
---
name: tasks [5606,5611]
name: tasks [5606,5611]
===
match
---
trailer [8488,8604]
trailer [8488,8604]
===
match
---
fstring_expr [16662,16698]
fstring_expr [18039,18075]
===
match
---
trailer [14540,14586]
trailer [14540,14586]
===
match
---
simple_stmt [15144,15195]
simple_stmt [15144,15195]
===
match
---
operator: , [18170,18171]
operator: , [19547,19548]
===
match
---
assert_stmt [9142,9211]
assert_stmt [9142,9211]
===
match
---
arglist [18521,18540]
arglist [19898,19917]
===
match
---
with_stmt [4436,6085]
with_stmt [4436,6085]
===
match
---
simple_stmt [21247,21306]
simple_stmt [22624,22683]
===
match
---
atom_expr [9508,9537]
atom_expr [9508,9537]
===
match
---
operator: , [15558,15559]
operator: , [15558,15559]
===
match
---
operator: = [15191,15192]
operator: = [15191,15192]
===
match
---
param [11386,11391]
param [11386,11391]
===
match
---
operator: , [5691,5692]
operator: , [5691,5692]
===
match
---
name: timedelta [15177,15186]
name: timedelta [15177,15186]
===
match
---
comparison [22232,22289]
comparison [23609,23666]
===
match
---
operator: , [5432,5433]
operator: , [5432,5433]
===
match
---
name: when [8871,8875]
name: when [8871,8875]
===
match
---
expr_stmt [20248,20502]
expr_stmt [21625,21879]
===
match
---
simple_stmt [21666,21710]
simple_stmt [23043,23087]
===
match
---
string: 'fake_simple_ti' [10525,10541]
string: 'fake_simple_ti' [10525,10541]
===
match
---
string: 'airflow.executors.celery_executor.Celery.backend' [17465,17515]
string: 'airflow.executors.celery_executor.Celery.backend' [18842,18892]
===
match
---
simple_stmt [13346,13390]
simple_stmt [13346,13390]
===
match
---
name: execute_command [12543,12558]
name: execute_command [12543,12558]
===
match
---
operator: = [7447,7448]
operator: = [7447,7448]
===
match
---
assert_stmt [8375,8455]
assert_stmt [8375,8455]
===
match
---
trailer [15956,15962]
trailer [15956,15962]
===
match
---
string: 'task_default_queue' [4784,4804]
string: 'task_default_queue' [4784,4804]
===
match
---
operator: , [5429,5430]
operator: , [5429,5430]
===
match
---
string: '123' [18146,18151]
string: '123' [19523,19528]
===
match
---
name: pytest [12472,12478]
name: pytest [12472,12478]
===
match
---
name: TaskInstance [13278,13290]
name: TaskInstance [13278,13290]
===
match
---
name: BaseOperator [13775,13787]
name: BaseOperator [13775,13787]
===
match
---
testlist_comp [18154,18169]
testlist_comp [19531,19546]
===
match
---
name: log [10752,10755]
name: log [10752,10755]
===
match
---
assert_stmt [14414,14441]
assert_stmt [14414,14441]
===
match
---
operator: , [4721,4722]
operator: , [4721,4722]
===
match
---
decorated [11136,11773]
decorated [11136,11773]
===
match
---
assert_stmt [14362,14405]
assert_stmt [14362,14405]
===
match
---
name: level [17615,17620]
name: level [18992,18997]
===
match
---
atom [6123,6169]
atom [6123,6169]
===
match
---
atom_expr [6727,6769]
atom_expr [6727,6769]
===
match
---
trailer [10993,11068]
trailer [10993,11068]
===
match
---
operator: = [7300,7301]
operator: = [7300,7301]
===
match
---
name: TaskInstance [8773,8785]
name: TaskInstance [8773,8785]
===
match
---
string: 'fake_simple_ti' [8853,8869]
string: 'fake_simple_ti' [8853,8869]
===
match
---
simple_stmt [9917,9972]
simple_stmt [9917,9972]
===
match
---
name: mock [16976,16980]
name: mock [18353,18357]
===
match
---
operator: = [15443,15444]
operator: = [15443,15444]
===
match
---
expr_stmt [4564,5197]
expr_stmt [4564,5197]
===
match
---
atom_expr [11120,11129]
atom_expr [11120,11129]
===
match
---
name: mark [19793,19797]
name: mark [21170,21174]
===
match
---
name: executors [1539,1548]
name: executors [1539,1548]
===
match
---
string: "postgres" [10636,10646]
string: "postgres" [10636,10646]
===
match
---
name: FAILED [16128,16134]
name: FAILED [16128,16134]
===
match
---
testlist_comp [10517,10550]
testlist_comp [10517,10550]
===
match
---
expr_stmt [2864,2890]
expr_stmt [2864,2890]
===
match
---
name: self [8015,8019]
name: self [8015,8019]
===
match
---
name: self [18581,18585]
name: self [19958,19962]
===
match
---
name: mock [19986,19990]
name: mock [21363,21367]
===
match
---
name: celery_executor [5124,5139]
name: celery_executor [5124,5139]
===
match
---
operator: , [2914,2915]
operator: , [2914,2915]
===
match
---
number: 0 [5891,5892]
number: 0 [5891,5892]
===
match
---
trailer [15232,15234]
trailer [15232,15234]
===
match
---
argument [2614,2639]
argument [2614,2639]
===
match
---
atom_expr [2660,2682]
atom_expr [2660,2682]
===
match
---
name: start_date [8565,8575]
name: start_date [8565,8575]
===
match
---
name: mock_backend [18966,18978]
name: mock_backend [20343,20355]
===
match
---
trailer [13787,13828]
trailer [13787,13828]
===
match
---
name: FAILED [10565,10571]
name: FAILED [10565,10571]
===
match
---
name: celery_executor [8275,8290]
name: celery_executor [8275,8290]
===
match
---
simple_stmt [6941,6985]
simple_stmt [6941,6985]
===
match
---
param [16638,16642]
param [18015,18019]
===
match
---
comparison [20597,20725]
comparison [21974,22102]
===
match
---
operator: = [14467,14468]
operator: = [14467,14468]
===
match
---
name: get [2090,2093]
name: get [2090,2093]
===
match
---
name: cm [8055,8057]
name: cm [8055,8057]
===
match
---
fstring_string: [Try 1 of 3] Task Timeout Error for Task: ( [9371,9414]
fstring_string: [Try 1 of 3] Task Timeout Error for Task: ( [9371,9414]
===
match
---
operator: , [20461,20462]
operator: , [21838,21839]
===
match
---
name: MagicMock [17831,17840]
name: MagicMock [19208,19217]
===
match
---
name: try_number [15268,15278]
name: try_number [15268,15278]
===
match
---
import_as_names [1717,1766]
import_as_names [1717,1766]
===
match
---
name: airflow [1417,1424]
name: airflow [1417,1424]
===
match
---
name: signal [21632,21638]
name: signal [23009,23015]
===
match
---
string: 'airflow.executors.celery_executor.app' [2710,2749]
string: 'airflow.executors.celery_executor.app' [2710,2749]
===
match
---
name: BulkStateFetcher [17663,17679]
name: BulkStateFetcher [19040,19056]
===
match
---
trailer [2093,2117]
trailer [2093,2117]
===
match
---
string: '456' [20556,20561]
string: '456' [21933,21938]
===
match
---
name: level [20164,20169]
name: level [21541,21546]
===
match
---
operator: = [18918,18919]
operator: = [20295,20296]
===
match
---
trailer [4540,4544]
trailer [4540,4544]
===
match
---
comparison [5592,5775]
comparison [5592,5775]
===
match
---
suite [3679,3734]
suite [3679,3734]
===
match
---
name: execute_date [5873,5885]
name: execute_date [5873,5885]
===
match
---
name: State [1882,1887]
name: State [1882,1887]
===
match
---
simple_stmt [1140,1193]
simple_stmt [1140,1193]
===
match
---
fstring_string: ). [10261,10263]
fstring_string: ). [10261,10263]
===
match
---
name: patch [18353,18358]
name: patch [19730,19735]
===
match
---
name: executor [6101,6109]
name: executor [6101,6109]
===
match
---
testlist_comp [14251,14259]
testlist_comp [14251,14259]
===
match
---
number: 0 [6269,6270]
number: 0 [6269,6270]
===
match
---
string: "123" [19375,19380]
string: "123" [20752,20757]
===
match
---
string: 'fake_simple_ti' [5982,5998]
string: 'fake_simple_ti' [5982,5998]
===
match
---
trailer [18739,18745]
trailer [20116,20122]
===
match
---
string: 'success' [5646,5655]
string: 'success' [5646,5655]
===
match
---
atom [18153,18170]
atom [19530,19547]
===
match
---
arglist [4248,4288]
arglist [4248,4288]
===
match
---
string: 'airflow.executors.celery_executor.Celery.backend' [20014,20064]
string: 'airflow.executors.celery_executor.Celery.backend' [21391,21441]
===
match
---
atom [5320,5347]
atom [5320,5347]
===
match
---
operator: = [13206,13207]
operator: = [13206,13207]
===
match
---
operator: , [5014,5015]
operator: , [5014,5015]
===
match
---
name: cm [9426,9428]
name: cm [9426,9428]
===
match
---
simple_stmt [1332,1372]
simple_stmt [1332,1372]
===
match
---
atom [10120,10291]
atom [10120,10291]
===
match
---
operator: == [7562,7564]
operator: == [7562,7564]
===
match
---
operator: , [8195,8196]
operator: , [8195,8196]
===
match
---
atom_expr [18966,19005]
atom_expr [20343,20382]
===
match
---
name: timezone [15217,15225]
name: timezone [15217,15225]
===
match
---
trailer [13573,13580]
trailer [13573,13580]
===
match
---
string: "123" [20355,20360]
string: "123" [21732,21737]
===
match
---
name: conf [1407,1411]
name: conf [1407,1411]
===
match
---
name: kwargs [16567,16573]
name: kwargs [17944,17950]
===
match
---
name: __ne__ [16863,16869]
name: __ne__ [18240,18246]
===
match
---
name: command [12729,12736]
name: command [12729,12736]
===
match
---
operator: , [6165,6166]
operator: , [6165,6166]
===
match
---
operator: , [4013,4014]
operator: , [4013,4014]
===
match
---
atom_expr [4747,4805]
atom_expr [4747,4805]
===
match
---
trailer [15616,15623]
trailer [15616,15623]
===
match
---
comparison [12810,12910]
comparison [12810,12910]
===
match
---
operator: = [15680,15681]
operator: = [15680,15681]
===
match
---
string: "test_try_adopt_task_instances_none" [13148,13184]
string: "test_try_adopt_task_instances_none" [13148,13184]
===
match
---
trailer [5076,5098]
trailer [5076,5098]
===
match
---
name: execute_date [5740,5752]
name: execute_date [5740,5752]
===
match
---
name: mark [10614,10618]
name: mark [10614,10618]
===
match
---
trailer [8069,8076]
trailer [8069,8076]
===
match
---
trailer [11557,11562]
trailer [11557,11562]
===
match
---
operator: = [4584,4585]
operator: = [4584,4585]
===
match
---
trailer [2906,2932]
trailer [2906,2932]
===
match
---
operator: == [19501,19503]
operator: == [20878,20880]
===
match
---
trailer [12196,12272]
trailer [12196,12272]
===
match
---
operator: } [16141,16142]
operator: } [16141,16142]
===
match
---
argument [13304,13315]
argument [13304,13315]
===
match
---
simple_stmt [17653,17682]
simple_stmt [19030,19059]
===
match
---
trailer [10970,10972]
trailer [10970,10972]
===
match
---
dotted_name [19786,19805]
dotted_name [21163,21182]
===
match
---
name: patch [16981,16986]
name: patch [18358,18363]
===
match
---
arith_expr [15842,15886]
arith_expr [15842,15886]
===
match
---
expr_stmt [17698,17896]
expr_stmt [19075,19273]
===
match
---
simple_stmt [21061,21078]
simple_stmt [22438,22455]
===
match
---
atom_expr [6400,6421]
atom_expr [6400,6421]
===
match
---
operator: = [4470,4471]
operator: = [4470,4471]
===
match
---
simple_stmt [7366,7408]
simple_stmt [7366,7408]
===
match
---
name: QUEUED [6030,6036]
name: QUEUED [6030,6036]
===
match
---
name: run_id [13945,13951]
name: run_id [13945,13951]
===
match
---
atom_expr [18109,18117]
atom_expr [19486,19494]
===
match
---
name: mock_task [12378,12387]
name: mock_task [12378,12387]
===
match
---
string: 'BROKER_URL' [2384,2396]
string: 'BROKER_URL' [2384,2396]
===
match
---
atom_expr [2027,2070]
atom_expr [2027,2070]
===
match
---
name: key1 [13271,13275]
name: key1 [13271,13275]
===
match
---
testlist_comp [8683,8811]
testlist_comp [8683,8811]
===
match
---
atom_expr [15370,15423]
atom_expr [15370,15423]
===
match
---
string: 'fail' [8845,8851]
string: 'fail' [8845,8851]
===
match
---
name: __repr__ [16731,16739]
name: __repr__ [18108,18116]
===
match
---
operator: = [7002,7003]
operator: = [7002,7003]
===
match
---
trailer [20429,20461]
trailer [21806,21838]
===
match
---
atom [5843,5889]
atom [5843,5889]
===
match
---
assert_stmt [7635,7719]
assert_stmt [7635,7719]
===
match
---
string: "rabbitmq" [18484,18494]
string: "rabbitmq" [19861,19871]
===
match
---
suite [21790,22290]
suite [23167,23667]
===
match
---
if_stmt [1954,2072]
if_stmt [1954,2072]
===
match
---
operator: = [2697,2698]
operator: = [2697,2698]
===
match
---
name: mock [2781,2785]
name: mock [2781,2785]
===
match
---
name: print [20983,20988]
name: print [22360,22365]
===
match
---
operator: = [7318,7319]
operator: = [7318,7319]
===
match
---
name: hasattr [2899,2906]
name: hasattr [2899,2906]
===
match
---
operator: = [6950,6951]
operator: = [6950,6951]
===
match
---
string: "INFO:airflow.executors.celery_executor.CeleryExecutor:" [9717,9773]
string: "INFO:airflow.executors.celery_executor.CeleryExecutor:" [9717,9773]
===
match
---
string: 'command' [7211,7220]
string: 'command' [7211,7220]
===
match
---
name: pytest [7764,7770]
name: pytest [7764,7770]
===
match
---
number: 2 [9127,9128]
number: 2 [9127,9128]
===
match
---
string: "123" [19190,19195]
string: "123" [20567,20572]
===
match
---
name: datetime [873,881]
name: datetime [873,881]
===
match
---
simple_stmt [16151,16179]
simple_stmt [16151,16179]
===
match
---
name: key [7366,7369]
name: key [7366,7369]
===
match
---
trailer [6333,6339]
trailer [6333,6339]
===
match
---
atom_expr [11502,11522]
atom_expr [11502,11522]
===
match
---
parameters [16739,16745]
parameters [18116,18122]
===
match
---
name: executor [8382,8390]
name: executor [8382,8390]
===
match
---
trailer [4846,4862]
trailer [4846,4862]
===
match
---
atom_expr [14680,14696]
atom_expr [14680,14696]
===
match
---
parameters [17295,17312]
parameters [18672,18689]
===
match
---
string: "mysql" [6600,6607]
string: "mysql" [6600,6607]
===
match
---
operator: { [15756,15757]
operator: { [15756,15757]
===
match
---
atom_expr [11667,11712]
atom_expr [11667,11712]
===
match
---
operator: = [7103,7104]
operator: = [7103,7104]
===
match
---
simple_stmt [5944,6037]
simple_stmt [5944,6037]
===
match
---
atom_expr [7152,7166]
atom_expr [7152,7166]
===
match
---
expr_stmt [14517,14586]
expr_stmt [14517,14586]
===
match
---
operator: == [12833,12835]
operator: == [12833,12835]
===
match
---
assert_stmt [9496,9550]
assert_stmt [9496,9550]
===
match
---
operator: , [8239,8240]
operator: , [8239,8240]
===
match
---
trailer [18745,18841]
trailer [20122,20218]
===
match
---
operator: , [7091,7092]
operator: , [7091,7092]
===
match
---
operator: = [19374,19375]
operator: = [20751,20752]
===
match
---
operator: , [11845,11846]
operator: , [11845,11846]
===
match
---
name: days [15187,15191]
name: days [15187,15191]
===
match
---
name: TaskInstance [14084,14096]
name: TaskInstance [14084,14096]
===
match
---
name: executor [13406,13414]
name: executor [13406,13414]
===
match
---
trailer [14477,14502]
trailer [14477,14502]
===
match
---
trailer [7016,7132]
trailer [7016,7132]
===
match
---
name: _prepare_app [4235,4247]
name: _prepare_app [4235,4247]
===
match
---
operator: , [16528,16529]
operator: , [17905,17906]
===
match
---
name: key [16609,16612]
name: key [17986,17989]
===
match
---
argument [17395,17418]
argument [18772,18795]
===
match
---
atom [20529,20581]
atom [21906,21958]
===
match
---
simple_stmt [11531,11724]
simple_stmt [11531,11724]
===
match
---
name: testing [1213,1220]
name: testing [1213,1220]
===
match
---
return_stmt [16755,16776]
return_stmt [18132,18153]
===
match
---
name: json [17072,17076]
name: json [18449,18453]
===
match
---
simple_stmt [21872,21916]
simple_stmt [23249,23293]
===
match
---
operator: , [20907,20908]
operator: , [22284,22285]
===
match
---
string: "redis" [18446,18453]
string: "redis" [19823,19830]
===
match
---
atom [5623,5775]
atom [5623,5775]
===
match
---
atom [5973,6016]
atom [5973,6016]
===
match
---
atom_expr [2595,2640]
atom_expr [2595,2640]
===
match
---
name: executor [8327,8335]
name: executor [8327,8335]
===
match
---
operator: , [11832,11833]
operator: , [11832,11833]
===
match
---
dotted_name [1594,1621]
dotted_name [1594,1621]
===
match
---
testlist_star_expr [17945,17957]
testlist_star_expr [19322,19334]
===
match
---
operator: , [19436,19437]
operator: , [20813,20814]
===
match
---
trailer [22195,22216]
trailer [23572,23593]
===
match
---
assert_stmt [14920,14999]
assert_stmt [14920,14999]
===
match
---
name: object [8070,8076]
name: object [8070,8076]
===
match
---
param [16799,16804]
param [18176,18181]
===
match
---
suite [13543,15037]
suite [13543,15037]
===
match
---
dotted_name [1145,1169]
dotted_name [1145,1169]
===
match
---
operator: , [13804,13805]
operator: , [13804,13805]
===
match
---
name: celery_executor [1510,1525]
name: celery_executor [1510,1525]
===
match
---
parameters [7886,7892]
parameters [7886,7892]
===
match
---
operator: , [4662,4663]
operator: , [4662,4663]
===
match
---
name: running [14337,14344]
name: running [14337,14344]
===
match
---
name: executor [15723,15731]
name: executor [15723,15731]
===
match
---
trailer [10751,10755]
trailer [10751,10755]
===
match
---
dotted_name [1682,1709]
dotted_name [1682,1709]
===
match
---
atom_expr [4196,4220]
atom_expr [4196,4220]
===
match
---
operator: , [4676,4677]
operator: , [4676,4677]
===
match
---
operator: , [17800,17801]
operator: , [19177,19178]
===
match
---
name: expected_exception [11962,11980]
name: expected_exception [11962,11980]
===
match
---
name: MockTask [21928,21936]
name: MockTask [23305,23313]
===
match
---
string: "mysql" [3889,3896]
string: "mysql" [3889,3896]
===
match
---
name: executor [16028,16036]
name: executor [16028,16036]
===
match
---
trailer [13290,13316]
trailer [13290,13316]
===
match
---
name: command [12859,12866]
name: command [12859,12866]
===
match
---
number: 0 [6014,6015]
number: 0 [6014,6015]
===
match
---
name: test_execute [2645,2657]
name: test_execute [2645,2657]
===
match
---
string: 'task_default_queue' [5077,5097]
string: 'task_default_queue' [5077,5097]
===
match
---
name: mock [11210,11214]
name: mock [11210,11214]
===
match
---
simple_stmt [2402,2467]
simple_stmt [2402,2467]
===
match
---
string: "postgres" [18530,18540]
string: "postgres" [19907,19917]
===
match
---
trailer [9849,9856]
trailer [9849,9856]
===
match
---
parameters [10682,10688]
parameters [10682,10688]
===
match
---
string: 'CELERY_BROKER_URLS' [2038,2058]
string: 'CELERY_BROKER_URLS' [2038,2058]
===
match
---
atom_expr [11609,11653]
atom_expr [11609,11653]
===
match
---
operator: { [2552,2553]
operator: { [2552,2553]
===
match
---
operator: , [20162,20163]
operator: , [21539,21540]
===
match
---
assert_stmt [14673,14714]
assert_stmt [14673,14714]
===
match
---
simple_stmt [7473,7512]
simple_stmt [7473,7512]
===
match
---
dotted_name [1772,1794]
dotted_name [1772,1794]
===
match
---
return_stmt [2076,2119]
return_stmt [2076,2119]
===
match
---
operator: , [8795,8796]
operator: , [8795,8796]
===
match
---
expr_stmt [17653,17681]
expr_stmt [19030,19058]
===
match
---
dotted_name [1647,1665]
dotted_name [1647,1665]
===
match
---
number: 1 [5431,5432]
number: 1 [5431,5432]
===
match
---
atom_expr [9087,9116]
atom_expr [9087,9116]
===
match
---
operator: , [11960,11961]
operator: , [11960,11961]
===
match
---
operator: { [19504,19505]
operator: { [20881,20882]
===
match
---
expr_stmt [13199,13261]
expr_stmt [13199,13261]
===
match
---
atom_expr [9042,9062]
atom_expr [9042,9062]
===
match
---
decorated [13457,15037]
decorated [13457,15037]
===
match
---
name: self [16793,16797]
name: self [18170,18174]
===
match
---
simple_stmt [13399,13452]
simple_stmt [13399,13452]
===
match
---
testlist_comp [5645,5757]
testlist_comp [5645,5757]
===
match
---
name: db [3601,3603]
name: db [3601,3603]
===
match
---
simple_stmt [9692,9871]
simple_stmt [9692,9871]
===
match
---
trailer [17076,17082]
trailer [18453,18459]
===
match
---
name: celery_executor [10994,11009]
name: celery_executor [10994,11009]
===
match
---
name: mark [12987,12991]
name: mark [12987,12991]
===
match
---
operator: { [10256,10257]
operator: { [10256,10257]
===
match
---
argument [18674,18697]
argument [20051,20074]
===
match
---
operator: @ [10606,10607]
operator: @ [10606,10607]
===
match
---
trailer [14175,14187]
trailer [14175,14187]
===
match
---
name: task_id [14560,14567]
name: task_id [14560,14567]
===
match
---
atom_expr [16839,16853]
atom_expr [18216,18230]
===
match
---
name: test_execute [2845,2857]
name: test_execute [2845,2857]
===
match
---
name: CeleryExecutor [15698,15712]
name: CeleryExecutor [15698,15712]
===
match
---
name: executor [16235,16243]
name: executor [16235,16243]
===
match
---
atom [4064,4086]
atom [4064,4086]
===
match
---
atom_expr [14953,14971]
atom_expr [14953,14971]
===
match
---
name: backend [2907,2914]
name: backend [2907,2914]
===
match
---
name: environ [1984,1991]
name: environ [1984,1991]
===
match
---
suite [13070,13452]
suite [13070,13452]
===
match
---
name: BashOperator [1802,1814]
name: BashOperator [1802,1814]
===
match
---
atom_expr [20404,20461]
atom_expr [21781,21838]
===
match
---
name: minutes [15247,15254]
name: minutes [15247,15254]
===
match
---
assert_stmt [16187,16219]
assert_stmt [16187,16219]
===
match
---
funcdef [2212,2256]
funcdef [2212,2256]
===
match
---
decorated [11778,12974]
decorated [11778,12974]
===
match
---
fstring_expr [21046,21054]
fstring_expr [22423,22431]
===
match
---
string: 'version' [4076,4085]
string: 'version' [4076,4085]
===
match
---
simple_stmt [8892,8933]
simple_stmt [8892,8933]
===
match
---
operator: @ [18500,18501]
operator: @ [19877,19878]
===
match
---
operator: = [13870,13871]
operator: = [13870,13871]
===
match
---
operator: = [21963,21964]
operator: = [23340,23341]
===
match
---
trailer [9095,9116]
trailer [9095,9116]
===
match
---
trailer [17830,17840]
trailer [19207,19217]
===
match
---
name: SUCCESS [6183,6190]
name: SUCCESS [6183,6190]
===
match
---
argument [13806,13827]
argument [13806,13827]
===
match
---
simple_stmt [12803,12974]
simple_stmt [12803,12974]
===
match
---
simple_stmt [6054,6085]
simple_stmt [6054,6085]
===
match
---
trailer [21331,21338]
trailer [22708,22715]
===
match
---
string: 'celery' [2374,2382]
string: 'celery' [2374,2382]
===
match
---
name: OPERATION_TIMEOUT [16338,16355]
name: OPERATION_TIMEOUT [17715,17732]
===
match
---
atom_expr [14525,14586]
atom_expr [14525,14586]
===
match
---
operator: = [15155,15156]
operator: = [15155,15156]
===
match
---
operator: = [21881,21882]
operator: = [23258,23259]
===
match
---
operator: @ [18459,18460]
operator: @ [19836,19837]
===
match
---
name: TaskInstanceKey [14525,14540]
name: TaskInstanceKey [14525,14540]
===
match
---
name: mock [18348,18352]
name: mock [19725,19729]
===
match
---
name: self [3665,3669]
name: self [3665,3669]
===
match
---
operator: = [7370,7371]
operator: = [7370,7371]
===
match
---
suite [3960,6495]
suite [3960,6495]
===
match
---
simple_stmt [827,841]
simple_stmt [827,841]
===
match
---
trailer [9086,9117]
trailer [9086,9117]
===
match
---
decorated [16975,18342]
decorated [18352,19719]
===
match
---
trailer [14010,14022]
trailer [14010,14022]
===
match
---
trailer [6029,6036]
trailer [6029,6036]
===
match
---
trailer [2373,2397]
trailer [2373,2397]
===
match
---
simple_stmt [2645,2683]
simple_stmt [2645,2683]
===
match
---
funcdef [3652,3734]
funcdef [3652,3734]
===
match
---
trailer [21338,21371]
trailer [22715,22748]
===
match
---
name: end [6063,6066]
name: end [6063,6066]
===
match
---
trailer [13372,13387]
trailer [13372,13387]
===
match
---
string: 'fake_simple_ti' [4942,4958]
string: 'fake_simple_ti' [4942,4958]
===
match
---
decorator [17174,17211]
decorator [18551,18588]
===
match
---
trailer [12712,12728]
trailer [12712,12728]
===
match
---
name: task_publish_retries [10359,10379]
name: task_publish_retries [10359,10379]
===
match
---
name: queued_tasks [9588,9600]
name: queued_tasks [9588,9600]
===
match
---
trailer [14743,14765]
trailer [14743,14765]
===
match
---
atom_expr [15625,15639]
atom_expr [15625,15639]
===
match
---
trailer [11618,11653]
trailer [11618,11653]
===
match
---
name: _exit_gracefully [21354,21370]
name: _exit_gracefully [22731,22747]
===
match
---
testlist_comp [11874,11899]
testlist_comp [11874,11899]
===
match
---
name: task_publish_retries [7482,7502]
name: task_publish_retries [7482,7502]
===
match
---
simple_stmt [14673,14715]
simple_stmt [14673,14715]
===
match
---
name: SIGUSR2 [21687,21694]
name: SIGUSR2 [23064,23071]
===
match
---
atom_expr [21325,21371]
atom_expr [22702,22748]
===
match
---
name: self [2174,2178]
name: self [2174,2178]
===
match
---
trailer [6227,6272]
trailer [6227,6272]
===
match
---
trailer [21397,21404]
trailer [22774,22781]
===
match
---
operator: ** [20916,20918]
operator: ** [22293,22295]
===
match
---
operator: = [21926,21927]
operator: = [23303,23304]
===
match
---
atom [22243,22289]
atom [23620,23666]
===
match
---
name: raises [12479,12485]
name: raises [12479,12485]
===
match
---
operator: { [16269,16270]
operator: { [16269,16270]
===
match
---
name: testing [1001,1008]
name: testing [1001,1008]
===
match
---
operator: = [2593,2594]
operator: = [2593,2594]
===
match
---
name: SIGTERM [21412,21419]
name: SIGTERM [22789,22796]
===
match
---
assert_stmt [9224,9258]
assert_stmt [9224,9258]
===
match
---
name: mock [17826,17830]
name: mock [19203,19207]
===
match
---
string: "INFO:airflow.executors.celery_executor.CeleryExecutor:" [9296,9352]
string: "INFO:airflow.executors.celery_executor.CeleryExecutor:" [9296,9352]
===
match
---
dictorsetmaker [18146,18196]
dictorsetmaker [19523,19573]
===
match
---
testlist_comp [6229,6270]
testlist_comp [6229,6270]
===
match
---
assert_stmt [13399,13451]
assert_stmt [13399,13451]
===
match
---
trailer [10724,10735]
trailer [10724,10735]
===
match
---
trailer [11087,11130]
trailer [11087,11130]
===
match
---
string: "SUCCESS" [19168,19177]
string: "SUCCESS" [20545,20554]
===
match
---
operator: = [4457,4458]
operator: = [4457,4458]
===
match
---
arglist [20014,20078]
arglist [21391,21455]
===
match
---
atom_expr [16093,16105]
atom_expr [16093,16105]
===
match
---
param [3948,3958]
param [3948,3958]
===
match
---
name: cm [18931,18933]
name: cm [20308,20310]
===
match
---
operator: = [13563,13564]
operator: = [13563,13564]
===
match
---
dotted_name [17137,17160]
dotted_name [18514,18537]
===
match
---
fstring_start: f" [16660,16662]
fstring_start: f" [18037,18039]
===
match
---
name: mock [12076,12080]
name: mock [12076,12080]
===
match
---
argument [7325,7336]
argument [7325,7336]
===
match
---
suite [12365,12974]
suite [12365,12974]
===
match
---
expr_stmt [14451,14507]
expr_stmt [14451,14507]
===
match
---
number: 1 [9570,9571]
number: 1 [9570,9571]
===
match
---
operator: = [13090,13091]
operator: = [13090,13091]
===
match
---
operator: @ [3739,3740]
operator: @ [3739,3740]
===
match
---
name: datetime [4532,4540]
name: datetime [4532,4540]
===
match
---
operator: == [5894,5896]
operator: == [5894,5896]
===
match
---
trailer [18978,18992]
trailer [20355,20369]
===
match
---
trailer [2059,2065]
trailer [2059,2065]
===
match
---
string: "PENDING" [20451,20460]
string: "PENDING" [21828,21837]
===
match
---
parameters [4120,4129]
parameters [4120,4129]
===
match
---
operator: , [16797,16798]
operator: , [18174,18175]
===
match
---
atom_expr [10832,10846]
atom_expr [10832,10846]
===
match
---
name: celery_executor [6952,6967]
name: celery_executor [6952,6967]
===
match
---
operator: { [4391,4392]
operator: { [4391,4392]
===
match
---
name: signum [20967,20973]
name: signum [22344,22350]
===
match
---
name: DAG [1673,1676]
name: DAG [1673,1676]
===
match
---
operator: } [9257,9258]
operator: } [9257,9258]
===
match
---
name: app [17395,17398]
name: app [18772,18775]
===
match
---
operator: = [19429,19430]
operator: = [20806,20807]
===
match
---
atom_expr [9924,9959]
atom_expr [9924,9959]
===
match
---
atom [21965,22010]
atom [23342,23387]
===
match
---
name: __eq__ [16786,16792]
name: __eq__ [18163,18169]
===
match
---
expr_stmt [19022,19216]
expr_stmt [20399,20593]
===
match
---
trailer [18992,19005]
trailer [20369,20382]
===
match
---
operator: == [16266,16268]
operator: == [16266,16268]
===
match
---
simple_stmt [11077,11131]
simple_stmt [11077,11131]
===
match
---
name: split [2060,2065]
name: split [2060,2065]
===
match
---
name: AsyncResult [14980,14991]
name: AsyncResult [14980,14991]
===
match
---
expr_stmt [13841,13903]
expr_stmt [13841,13903]
===
match
---
name: State [6024,6029]
name: State [6024,6029]
===
match
---
operator: = [14248,14249]
operator: = [14248,14249]
===
match
---
trailer [18673,18716]
trailer [20050,20093]
===
match
---
atom [9542,9550]
atom [9542,9550]
===
match
---
string: 'true' [4015,4021]
string: 'true' [4015,4021]
===
match
---
name: celery_executor [8147,8162]
name: celery_executor [8147,8162]
===
match
---
expr_stmt [2584,2640]
expr_stmt [2584,2640]
===
match
---
name: pytest [19745,19751]
name: pytest [21122,21128]
===
match
---
operator: = [13355,13356]
operator: = [13355,13356]
===
match
---
trailer [12080,12086]
trailer [12080,12086]
===
match
---
trailer [9428,9435]
trailer [9428,9435]
===
match
---
atom_expr [8547,8563]
atom_expr [8547,8563]
===
match
---
atom_expr [4235,4289]
atom_expr [4235,4289]
===
match
---
operator: = [8557,8558]
operator: = [8557,8558]
===
match
---
trailer [7078,7091]
trailer [7078,7091]
===
match
---
name: task_id [17786,17793]
name: task_id [19163,19170]
===
match
---
name: cm [20182,20184]
name: cm [21559,21561]
===
match
---
simple_stmt [10832,10877]
simple_stmt [10832,10877]
===
match
---
atom_expr [21061,21077]
atom_expr [22438,22454]
===
match
---
atom_expr [19022,19090]
atom_expr [20399,20467]
===
match
---
name: heartbeat [10314,10323]
name: heartbeat [10314,10323]
===
match
---
suite [16310,16361]
suite [17687,17738]
===
match
---
operator: } [14910,14911]
operator: } [14910,14911]
===
match
---
string: 'SUCCESS' [19513,19522]
string: 'SUCCESS' [20890,20899]
===
match
---
funcdef [18546,19701]
funcdef [19923,21078]
===
match
---
arglist [21680,21708]
arglist [23057,23085]
===
match
---
operator: , [11642,11643]
operator: , [11642,11643]
===
match
---
string: "rabbitmq" [19769,19779]
string: "rabbitmq" [21146,21156]
===
match
---
simple_stmt [7145,7167]
simple_stmt [7145,7167]
===
match
---
name: orig_sigint [21247,21258]
name: orig_sigint [22624,22635]
===
match
---
name: orig_sigusr2 [21276,21288]
name: orig_sigusr2 [22653,22665]
===
match
---
atom_expr [14007,14022]
atom_expr [14007,14022]
===
match
---
trailer [10802,10817]
trailer [10802,10817]
===
match
---
name: Celery [1062,1068]
name: Celery [1062,1068]
===
match
---
name: result [19494,19500]
name: result [20871,20877]
===
match
---
trailer [7297,7338]
trailer [7297,7338]
===
match
---
operator: = [17705,17706]
operator: = [19082,19083]
===
match
---
import_as_names [1443,1479]
import_as_names [1443,1479]
===
match
---
trailer [8913,8918]
trailer [8913,8918]
===
match
---
name: timezone [1841,1849]
name: timezone [1841,1849]
===
match
---
name: patch [18740,18745]
name: patch [20117,20122]
===
match
---
trailer [8584,8588]
trailer [8584,8588]
===
match
---
name: fetcher [20202,20209]
name: fetcher [21579,21586]
===
match
---
name: datetime [8624,8632]
name: datetime [8624,8632]
===
match
---
operator: , [5340,5341]
operator: , [5340,5341]
===
match
---
with_stmt [13699,13904]
with_stmt [13699,13904]
===
match
---
simple_stmt [10066,10101]
simple_stmt [10066,10101]
===
match
---
operator: , [10547,10548]
operator: , [10547,10548]
===
match
---
atom [2083,2119]
atom [2083,2119]
===
match
---
name: mark [21720,21724]
name: mark [23097,23101]
===
match
---
trailer [16708,16717]
trailer [18085,18094]
===
match
---
if_stmt [12428,12974]
if_stmt [12428,12974]
===
match
---
operator: , [20092,20093]
operator: , [21469,21470]
===
match
---
fstring [9790,9843]
fstring [9790,9843]
===
match
---
name: fake_execute_command [6672,6692]
name: fake_execute_command [6672,6692]
===
match
---
name: key [5497,5500]
name: key [5497,5500]
===
match
---
name: BaseOperator [13208,13220]
name: BaseOperator [13208,13220]
===
match
---
parameters [3577,3583]
parameters [3577,3583]
===
match
---
operator: = [15514,15515]
operator: = [15514,15515]
===
match
---
name: running [16203,16210]
name: running [16203,16210]
===
match
---
operator: , [16612,16613]
operator: , [17989,17990]
===
match
---
operator: , [12866,12867]
operator: , [12866,12867]
===
match
---
trailer [11648,11652]
trailer [11648,11652]
===
match
---
atom_expr [16000,16018]
atom_expr [16000,16018]
===
match
---
name: executor [9652,9660]
name: executor [9652,9660]
===
match
---
operator: , [5098,5099]
operator: , [5098,5099]
===
match
---
name: pytest [19707,19713]
name: pytest [21084,21090]
===
match
---
string: 'some_parameter' [4023,4039]
string: 'some_parameter' [4023,4039]
===
match
---
atom_expr [2423,2466]
atom_expr [2423,2466]
===
match
---
name: celery_executor [14280,14295]
name: celery_executor [14280,14295]
===
match
---
name: mock_backend [17355,17367]
name: mock_backend [18732,18744]
===
match
---
atom [2084,2118]
atom [2084,2118]
===
match
---
name: when [7145,7149]
name: when [7145,7149]
===
match
---
fstring_start: f" [9369,9371]
fstring_start: f" [9369,9371]
===
match
---
trailer [3323,3325]
trailer [3323,3325]
===
match
---
comparison [16822,16853]
comparison [18199,18230]
===
match
---
trailer [10323,10325]
trailer [10323,10325]
===
match
---
with_stmt [13139,13262]
with_stmt [13139,13262]
===
match
---
name: len [9154,9157]
name: len [9154,9157]
===
match
---
name: TaskInstance [1737,1749]
name: TaskInstance [1737,1749]
===
match
---
atom_expr [3278,3301]
atom_expr [3278,3301]
===
match
---
trailer [4414,4420]
trailer [4414,4420]
===
match
---
name: dag_id [14545,14551]
name: dag_id [14545,14551]
===
match
---
decorator [18459,18496]
decorator [19836,19873]
===
match
---
trailer [15382,15423]
trailer [15382,15423]
===
match
---
suite [6770,7545]
suite [6770,7545]
===
match
---
simple_stmt [17988,18067]
simple_stmt [19365,19444]
===
match
---
operator: } [10385,10386]
operator: } [10385,10386]
===
match
---
operator: == [22240,22242]
operator: == [23617,23619]
===
match
---
trailer [6452,6460]
trailer [6452,6460]
===
match
---
arglist [13000,13019]
arglist [13000,13019]
===
match
---
trailer [12086,12168]
trailer [12086,12168]
===
match
---
import_as_names [1102,1139]
import_as_names [1102,1139]
===
match
---
operator: = [21389,21390]
operator: = [22766,22767]
===
match
---
suite [16644,16722]
suite [18021,18099]
===
match
---
operator: { [19132,19133]
operator: { [20509,20510]
===
match
---
assert_stmt [16315,16360]
assert_stmt [17692,17737]
===
match
---
decorators [6500,6621]
decorators [6500,6621]
===
match
---
string: '232' [14158,14163]
string: '232' [14158,14163]
===
match
---
atom_expr [8773,8809]
atom_expr [8773,8809]
===
match
---
comparison [9149,9180]
comparison [9149,9180]
===
match
---
name: loglevel [4483,4491]
name: loglevel [4483,4491]
===
match
---
name: executor [15791,15799]
name: executor [15791,15799]
===
match
---
arith_expr [15157,15194]
arith_expr [15157,15194]
===
match
---
name: ANY [11591,11594]
name: ANY [11591,11594]
===
match
---
simple_stmt [3310,3326]
simple_stmt [3310,3326]
===
match
---
number: 1 [9991,9992]
number: 1 [9991,9992]
===
match
---
string: '456' [19531,19536]
string: '456' [20908,20913]
===
match
---
trailer [9166,9179]
trailer [9166,9179]
===
match
---
name: os [2027,2029]
name: os [2027,2029]
===
match
---
simple_stmt [13325,13338]
simple_stmt [13325,13338]
===
match
---
name: TaskInstanceKey [14603,14618]
name: TaskInstanceKey [14603,14618]
===
match
---
atom [12858,12891]
atom [12858,12891]
===
match
---
simple_stmt [10399,10475]
simple_stmt [10399,10475]
===
match
---
name: executor [14469,14477]
name: executor [14469,14477]
===
match
---
suite [4173,4221]
suite [4173,4221]
===
match
---
trailer [18108,18118]
trailer [19485,19495]
===
match
---
trailer [10897,10916]
trailer [10897,10916]
===
match
---
name: mock_stats_gauge [11732,11748]
name: mock_stats_gauge [11732,11748]
===
match
---
testlist_comp [2009,2070]
testlist_comp [2009,2070]
===
match
---
name: broker_url [2302,2312]
name: broker_url [2302,2312]
===
match
---
fstring_start: f" [9790,9792]
fstring_start: f" [9790,9792]
===
match
---
argument [7034,7048]
argument [7034,7048]
===
match
---
simple_stmt [15508,15581]
simple_stmt [15508,15581]
===
match
---
name: output [11123,11129]
name: output [11123,11129]
===
match
---
operator: = [19929,19930]
operator: = [21306,21307]
===
match
---
name: key_2 [15589,15594]
name: key_2 [15589,15594]
===
match
---
name: app [4293,4296]
name: app [4293,4296]
===
match
---
name: backend [3881,3888]
name: backend [3881,3888]
===
match
---
operator: = [14082,14083]
operator: = [14082,14083]
===
match
---
trailer [21464,21471]
trailer [22841,22848]
===
match
---
operator: @ [6579,6580]
operator: @ [6579,6580]
===
match
---
trailer [14429,14435]
trailer [14429,14435]
===
match
---
yield_expr [3387,3401]
yield_expr [3387,3401]
===
match
---
operator: , [14108,14109]
operator: , [14108,14109]
===
match
---
operator: { [19157,19158]
operator: { [20534,20535]
===
match
---
operator: , [4074,4075]
operator: , [4074,4075]
===
match
---
name: task_publish_retries [9096,9116]
name: task_publish_retries [9096,9116]
===
match
---
trailer [13969,13990]
trailer [13969,13990]
===
match
---
assert_stmt [10113,10291]
assert_stmt [10113,10291]
===
match
---
operator: , [11900,11901]
operator: , [11900,11901]
===
match
---
atom_expr [3688,3706]
atom_expr [3688,3706]
===
match
---
testlist_comp [22245,22258]
testlist_comp [23622,23635]
===
match
---
name: self [16903,16907]
name: self [18280,18284]
===
match
---
trailer [14637,14645]
trailer [14637,14645]
===
match
---
simple_stmt [16892,16922]
simple_stmt [18269,18299]
===
match
---
operator: + [15789,15790]
operator: + [15789,15790]
===
match
---
arglist [8786,8808]
arglist [8786,8808]
===
match
---
operator: = [8273,8274]
operator: = [8273,8274]
===
match
---
atom_expr [14172,14187]
atom_expr [14172,14187]
===
match
---
decorator [6538,6575]
decorator [6538,6575]
===
match
---
operator: , [2317,2318]
operator: , [2317,2318]
===
match
---
operator: , [5673,5674]
operator: , [5673,5674]
===
match
---
assert_stmt [14723,14911]
assert_stmt [14723,14911]
===
match
---
expr_stmt [18951,19005]
expr_stmt [20328,20382]
===
match
---
trailer [13100,13107]
trailer [13100,13107]
===
match
---
expr_stmt [8617,8638]
expr_stmt [8617,8638]
===
match
---
param [20967,20974]
param [22344,22351]
===
match
---
assert_stmt [18128,18197]
assert_stmt [19505,19574]
===
match
---
simple_stmt [805,817]
simple_stmt [805,817]
===
match
---
operator: , [1735,1736]
operator: , [1735,1736]
===
match
---
suite [3592,3647]
suite [3592,3647]
===
match
---
suite [16582,16621]
suite [17959,17998]
===
match
---
string: '456' [18172,18177]
string: '456' [19549,19554]
===
match
---
trailer [14964,14971]
trailer [14964,14971]
===
match
---
simple_stmt [8264,8308]
simple_stmt [8264,8308]
===
match
---
string: "456" [17849,17854]
string: "456" [19226,19231]
===
match
---
name: task_tuples_to_send [21943,21962]
name: task_tuples_to_send [23320,23339]
===
match
---
arglist [13478,13497]
arglist [13478,13497]
===
match
---
name: timedelta [13645,13654]
name: timedelta [13645,13654]
===
match
---
param [20903,20908]
param [22280,22285]
===
match
---
operator: , [5885,5886]
operator: , [5885,5886]
===
match
---
trailer [21898,21913]
trailer [23275,23290]
===
match
---
name: __dict__ [16845,16853]
name: __dict__ [18222,18230]
===
match
---
trailer [16914,16921]
trailer [18291,18298]
===
match
---
atom_expr [17960,17979]
atom_expr [19337,19356]
===
match
---
operator: , [7069,7070]
operator: , [7069,7070]
===
match
---
simple_stmt [9224,9259]
simple_stmt [9224,9259]
===
match
---
name: utcnow [15166,15172]
name: utcnow [15166,15172]
===
match
---
name: queued_dttm [14190,14201]
name: queued_dttm [14190,14201]
===
match
---
string: 'run' [4008,4013]
string: 'run' [4008,4013]
===
match
---
operator: { [6425,6426]
operator: { [6425,6426]
===
match
---
operator: = [18964,18965]
operator: = [20341,20342]
===
match
---
simple_stmt [979,1029]
simple_stmt [979,1029]
===
match
---
operator: } [9970,9971]
operator: } [9970,9971]
===
match
---
fstring_expr [10256,10261]
fstring_expr [10256,10261]
===
match
---
name: app [17415,17418]
name: app [18792,18795]
===
match
---
expr_stmt [13552,13602]
expr_stmt [13552,13602]
===
match
---
atom [18016,18066]
atom [19393,19443]
===
match
---
name: backend [7817,7824]
name: backend [7817,7824]
===
match
---
operator: = [15486,15487]
operator: = [15486,15487]
===
match
---
name: mark [19752,19756]
name: mark [21129,21133]
===
match
---
name: not_adopted_tis [14451,14466]
name: not_adopted_tis [14451,14466]
===
match
---
atom [19132,19197]
atom [20509,20574]
===
match
---
import_from [1480,1525]
import_from [1480,1525]
===
match
---
arglist [2374,2396]
arglist [2374,2396]
===
match
---
param [10683,10687]
param [10683,10687]
===
match
---
testlist_comp [5422,5445]
testlist_comp [5422,5445]
===
match
---
raise_stmt [4190,4220]
raise_stmt [4190,4220]
===
match
---
number: 0 [8877,8878]
number: 0 [8877,8878]
===
match
---
name: signal [21398,21404]
name: signal [22775,22781]
===
match
---
name: State [5897,5902]
name: State [5897,5902]
===
match
---
operator: = [22163,22164]
operator: = [23540,23541]
===
match
---
name: sys [21061,21064]
name: sys [22438,22441]
===
match
---
name: db [1917,1919]
name: db [1917,1919]
===
match
---
operator: = [6078,6079]
operator: = [6078,6079]
===
match
---
assert_stmt [10983,11068]
assert_stmt [10983,11068]
===
match
---
name: fail_command [5002,5014]
name: fail_command [5002,5014]
===
match
---
name: execute [2319,2326]
name: execute [2319,2326]
===
match
---
import_name [827,840]
import_name [827,840]
===
match
---
name: patch [11297,11302]
name: patch [11297,11302]
===
match
---
param [16524,16529]
param [17901,17906]
===
match
---
string: 'airflow.executors.celery_executor._execute_in_subprocess' [12100,12158]
string: 'airflow.executors.celery_executor._execute_in_subprocess' [12100,12158]
===
match
---
dotted_name [1198,1227]
dotted_name [1198,1227]
===
match
---
atom_expr [15157,15174]
atom_expr [15157,15174]
===
match
---
param [17296,17301]
param [18673,18678]
===
match
---
dictorsetmaker [19505,19555]
dictorsetmaker [20882,20932]
===
match
---
string: "task_1" [13796,13804]
string: "task_1" [13796,13804]
===
match
---
atom_expr [8327,8356]
atom_expr [8327,8356]
===
match
---
atom [18145,18197]
atom [19522,19574]
===
match
---
trailer [9999,10022]
trailer [9999,10022]
===
match
---
trailer [10716,10718]
trailer [10716,10718]
===
match
---
simple_stmt [14517,14587]
simple_stmt [14517,14587]
===
match
---
operator: @ [10577,10578]
operator: @ [10577,10578]
===
match
---
operator: = [13662,13663]
operator: = [13662,13663]
===
match
---
string: "postgres" [17245,17255]
string: "postgres" [18622,18632]
===
match
---
simple_stmt [5523,5568]
simple_stmt [5523,5568]
===
match
---
trailer [14622,14629]
trailer [14622,14629]
===
match
---
atom_expr [2533,2579]
atom_expr [2533,2579]
===
match
---
atom_expr [13775,13828]
atom_expr [13775,13828]
===
match
---
name: patch_execute [3347,3360]
name: patch_execute [3347,3360]
===
match
---
atom_expr [16322,16355]
atom_expr [17699,17732]
===
match
---
trailer [3704,3706]
trailer [3704,3706]
===
match
---
name: executor [5467,5475]
name: executor [5467,5475]
===
match
---
trailer [15712,15714]
trailer [15712,15714]
===
match
---
operator: , [6012,6013]
operator: , [6012,6013]
===
match
---
argument [14097,14108]
argument [14097,14108]
===
match
---
name: executor [10305,10313]
name: executor [10305,10313]
===
match
---
name: mock_fork [12914,12923]
name: mock_fork [12914,12923]
===
match
---
arglist [10627,10646]
arglist [10627,10646]
===
match
---
operator: , [5756,5757]
operator: , [5756,5757]
===
match
---
simple_stmt [22155,22217]
simple_stmt [23532,23594]
===
match
---
name: BaseBackend [1102,1113]
name: BaseBackend [1102,1113]
===
match
---
operator: = [13686,13687]
operator: = [13686,13687]
===
match
---
trailer [20228,20231]
trailer [21605,21608]
===
match
---
simple_stmt [20983,21057]
simple_stmt [22360,22434]
===
match
---
name: BaseOperator [13850,13862]
name: BaseOperator [13850,13862]
===
match
---
decorated [15042,16272]
decorated [15042,16272]
===
match
---
string: "test" [7042,7048]
string: "test" [7042,7048]
===
match
---
name: test_config [2472,2483]
name: test_config [2472,2483]
===
match
---
name: pytest [6580,6586]
name: pytest [6580,6586]
===
match
---
operator: @ [21712,21713]
operator: @ [23089,23090]
===
match
---
trailer [15697,15712]
trailer [15697,15712]
===
match
---
operator: = [4319,4320]
operator: = [4319,4320]
===
match
---
comparison [6206,6291]
comparison [6206,6291]
===
match
---
trailer [12614,12616]
trailer [12614,12616]
===
match
---
name: database [1161,1169]
name: database [1161,1169]
===
match
---
atom_expr [16194,16210]
atom_expr [16194,16210]
===
match
---
atom_expr [15297,15340]
atom_expr [15297,15340]
===
match
---
name: calls [11766,11771]
name: calls [11766,11771]
===
match
---
name: cm [10760,10762]
name: cm [10760,10762]
===
match
---
name: run_id [14110,14116]
name: run_id [14110,14116]
===
match
---
suite [6695,6713]
suite [6695,6713]
===
match
---
string: "123" [17794,17799]
string: "123" [19171,19176]
===
match
---
name: orig_sigterm [21648,21660]
name: orig_sigterm [23025,23037]
===
match
---
testlist_comp [19539,19554]
testlist_comp [20916,20931]
===
match
---
atom_expr [10268,10277]
atom_expr [10268,10277]
===
match
---
operator: , [11857,11858]
operator: , [11857,11858]
===
match
---
trailer [10313,10323]
trailer [10313,10323]
===
match
---
name: tests [1893,1898]
name: tests [1893,1898]
===
match
---
dotted_name [11292,11302]
dotted_name [11292,11302]
===
match
---
try_stmt [3370,3517]
try_stmt [3370,3517]
===
match
---
atom_expr [9575,9601]
atom_expr [9575,9601]
===
match
---
name: update [2545,2551]
name: update [2545,2551]
===
match
---
name: task [2669,2673]
name: task [2669,2673]
===
match
---
classdef [20728,20944]
classdef [22105,22321]
===
match
---
atom_expr [6464,6494]
atom_expr [6464,6494]
===
match
---
expr_stmt [11450,11493]
expr_stmt [11450,11493]
===
match
---
operator: { [20529,20530]
operator: { [21906,21907]
===
match
---
simple_stmt [3688,3707]
simple_stmt [3688,3707]
===
match
---
param [6653,6657]
param [6653,6657]
===
match
---
trailer [14377,14399]
trailer [14377,14399]
===
match
---
operator: @ [18347,18348]
operator: @ [19724,19725]
===
match
---
name: AsyncResult [1274,1285]
name: AsyncResult [1274,1285]
===
match
---
operator: = [17848,17849]
operator: = [19225,19226]
===
match
---
trailer [19935,19945]
trailer [21312,21322]
===
match
---
simple_stmt [21618,21662]
simple_stmt [22995,23039]
===
match
---
trailer [14096,14122]
trailer [14096,14122]
===
match
---
operator: == [6276,6278]
operator: == [6276,6278]
===
match
---
atom_expr [9579,9600]
atom_expr [9579,9600]
===
match
---
name: success_command [4157,4172]
name: success_command [4157,4172]
===
match
---
string: "mysql" [19806,19813]
string: "mysql" [21183,21190]
===
match
---
operator: { [10384,10385]
operator: { [10384,10385]
===
match
---
arith_expr [15217,15258]
arith_expr [15217,15258]
===
match
---
atom_expr [13625,13642]
atom_expr [13625,13642]
===
match
---
string: 'success' [6124,6133]
string: 'success' [6124,6133]
===
match
---
atom [14770,14911]
atom [14770,14911]
===
match
---
param [16876,16881]
param [18253,18258]
===
match
---
string: "mysql" [13000,13007]
string: "mysql" [13000,13007]
===
match
---
parameters [13063,13069]
parameters [13063,13069]
===
match
---
name: dag [7071,7074]
name: dag [7071,7074]
===
match
---
string: ',' [2066,2069]
string: ',' [2066,2069]
===
match
---
name: start_date [15412,15422]
name: start_date [15412,15422]
===
match
---
operator: , [17543,17544]
operator: , [18920,18921]
===
match
---
trailer [12923,12933]
trailer [12923,12933]
===
match
---
simple_stmt [15671,15715]
simple_stmt [15671,15715]
===
match
---
trailer [7577,7590]
trailer [7577,7590]
===
match
---
string: "airflow.executors.celery_executor.BulkStateFetcher" [20110,20162]
string: "airflow.executors.celery_executor.BulkStateFetcher" [21487,21539]
===
match
---
decorator [11209,11287]
decorator [11209,11287]
===
match
---
parameters [21771,21789]
parameters [23148,23166]
===
match
---
operator: , [10022,10023]
operator: , [10022,10023]
===
match
---
operator: @ [17174,17175]
operator: @ [18551,18552]
===
match
---
operator: = [2312,2313]
operator: = [2312,2313]
===
match
---
atom_expr [10073,10094]
atom_expr [10073,10094]
===
match
---
name: _prepare_test_bodies [3761,3781]
name: _prepare_test_bodies [3761,3781]
===
match
---
arglist [7825,7844]
arglist [7825,7844]
===
match
---
name: celery_executor [17399,17414]
name: celery_executor [18776,18791]
===
match
---
trailer [5531,5546]
trailer [5531,5546]
===
match
---
trailer [15914,15922]
trailer [15914,15922]
===
match
---
funcdef [11919,12974]
funcdef [11919,12974]
===
match
---
simple_stmt [15948,16020]
simple_stmt [15948,16020]
===
match
---
trailer [9239,9252]
trailer [9239,9252]
===
match
---
name: patch [17442,17447]
name: patch [18819,18824]
===
match
---
operator: , [8170,8171]
operator: , [8170,8171]
===
match
---
name: result [20248,20254]
name: result [21625,21631]
===
match
---
operator: = [8772,8773]
operator: = [8772,8773]
===
match
---
simple_stmt [852,868]
simple_stmt [852,868]
===
match
---
name: event_buffer [5830,5842]
name: event_buffer [5830,5842]
===
match
---
operator: @ [21080,21081]
operator: @ [22457,22458]
===
match
---
simple_stmt [16187,16220]
simple_stmt [16187,16220]
===
match
---
trailer [3317,3323]
trailer [3317,3323]
===
match
---
name: queue [5434,5439]
name: queue [5434,5439]
===
match
---
name: key_1 [14701,14706]
name: key_1 [14701,14706]
===
match
---
trailer [20098,20109]
trailer [21475,21486]
===
match
---
string: "postgres" [6609,6619]
string: "postgres" [6609,6619]
===
match
---
trailer [13862,13903]
trailer [13862,13903]
===
match
---
name: task_tuples_to_send [22269,22288]
name: task_tuples_to_send [23646,23665]
===
match
---
name: exit [21065,21069]
name: exit [22442,22446]
===
match
---
name: airflow [1772,1779]
name: airflow [1772,1779]
===
match
---
name: getpid [20995,21001]
name: getpid [22372,22378]
===
match
---
name: self [20903,20907]
name: self [22280,22284]
===
match
---
name: queued_dttm [15777,15788]
name: queued_dttm [15777,15788]
===
match
---
name: query [19035,19040]
name: query [20412,20417]
===
match
---
parameters [3664,3670]
parameters [3664,3670]
===
match
---
decorator [11778,11915]
decorator [11778,11915]
===
match
---
operator: = [7191,7192]
operator: = [7191,7192]
===
match
---
name: ti1 [14251,14254]
name: ti1 [14251,14254]
===
match
---
operator: } [20580,20581]
operator: } [21957,21958]
===
match
---
operator: , [8013,8014]
operator: , [8013,8014]
===
match
---
name: len [7565,7568]
name: len [7565,7568]
===
match
---
comparison [8382,8420]
comparison [8382,8420]
===
match
---
name: execute [6740,6747]
name: execute [6740,6747]
===
match
---
name: task_tuples_to_send [5547,5566]
name: task_tuples_to_send [5547,5566]
===
match
---
name: start_worker [1235,1247]
name: start_worker [1235,1247]
===
match
---
operator: , [8541,8542]
operator: , [8541,8542]
===
match
---
operator: == [16836,16838]
operator: == [18213,18215]
===
match
---
param [11430,11439]
param [11430,11439]
===
match
---
operator: , [14567,14568]
operator: , [14567,14568]
===
match
---
operator: = [13816,13817]
operator: = [13816,13817]
===
match
---
name: test_app [2751,2759]
name: test_app [2751,2759]
===
match
---
funcdef [3568,3647]
funcdef [3568,3647]
===
match
---
name: TestBulkStateFetcher [16930,16950]
name: TestBulkStateFetcher [18307,18327]
===
match
---
operator: } [9839,9840]
operator: } [9839,9840]
===
match
---
atom_expr [11703,11711]
atom_expr [11703,11711]
===
match
---
name: cm [17633,17635]
name: cm [19010,19012]
===
match
---
string: "fail" [4213,4219]
string: "fail" [4213,4219]
===
match
---
argument [15187,15193]
argument [15187,15193]
===
match
---
simple_stmt [17355,17420]
simple_stmt [18732,18797]
===
match
---
name: executor [5597,5605]
name: executor [5597,5605]
===
match
---
expr_stmt [19234,19262]
expr_stmt [20611,20639]
===
match
---
name: tearDown [3656,3664]
name: tearDown [3656,3664]
===
match
---
number: 0 [6018,6019]
number: 0 [6018,6019]
===
match
---
atom_expr [5951,6020]
atom_expr [5951,6020]
===
match
---
trailer [16067,16080]
trailer [16067,16080]
===
match
---
simple_stmt [16228,16272]
simple_stmt [16228,16272]
===
match
---
suite [16806,16854]
suite [18183,18231]
===
match
---
name: calls [11531,11536]
name: calls [11531,11536]
===
match
---
funcdef [2164,2207]
funcdef [2164,2207]
===
match
---
operator: , [21486,21487]
operator: , [22863,22864]
===
match
---
name: fetcher [17707,17714]
name: fetcher [19084,19091]
===
match
---
name: timedelta [13585,13594]
name: timedelta [13585,13594]
===
match
---
operator: , [20064,20065]
operator: , [21441,21442]
===
match
---
atom_expr [13112,13129]
atom_expr [13112,13129]
===
match
---
atom_expr [15613,15623]
atom_expr [15613,15623]
===
match
---
name: mock [17437,17441]
name: mock [18814,18818]
===
match
---
trailer [2454,2466]
trailer [2454,2466]
===
match
---
argument [4463,4481]
argument [4463,4481]
===
match
---
trailer [13654,13665]
trailer [13654,13665]
===
match
---
trailer [6109,6122]
trailer [6109,6122]
===
match
---
operator: = [13126,13127]
operator: = [13126,13127]
===
match
---
name: start_date [15487,15497]
name: start_date [15487,15497]
===
match
---
trailer [12642,12660]
trailer [12642,12660]
===
match
---
decorators [7725,7846]
decorators [7725,7846]
===
match
---
name: config_source [2614,2627]
name: config_source [2614,2627]
===
match
---
trailer [10270,10277]
trailer [10270,10277]
===
match
---
name: task_tuples_to_send [4564,4583]
name: task_tuples_to_send [4564,4583]
===
match
---
atom_expr [21458,21505]
atom_expr [22835,22882]
===
match
---
trailer [4212,4220]
trailer [4212,4220]
===
match
---
atom_expr [14328,14344]
atom_expr [14328,14344]
===
match
---
operator: , [21983,21984]
operator: , [23360,23361]
===
match
---
name: _prepare_app [2289,2301]
name: _prepare_app [2289,2301]
===
match
---
atom_expr [10345,10380]
atom_expr [10345,10380]
===
match
---
expr_stmt [12378,12415]
expr_stmt [12378,12415]
===
match
---
trailer [9157,9180]
trailer [9157,9180]
===
match
---
atom_expr [12076,12168]
atom_expr [12076,12168]
===
match
---
name: celery [1145,1151]
name: celery [1145,1151]
===
match
---
name: mock_fork [12633,12642]
name: mock_fork [12633,12642]
===
match
---
operator: = [17398,17399]
operator: = [18775,18776]
===
match
---
name: key_2 [14973,14978]
name: key_2 [14973,14978]
===
match
---
name: executor [9087,9095]
name: executor [9087,9095]
===
match
---
trailer [10564,10571]
trailer [10564,10571]
===
match
---
name: CeleryExecutor [14296,14310]
name: CeleryExecutor [14296,14310]
===
match
---
string: '231' [13993,13998]
string: '231' [13993,13998]
===
match
---
atom_expr [8751,8810]
atom_expr [8751,8810]
===
match
---
operator: == [5620,5622]
operator: == [5620,5622]
===
match
---
operator: , [13879,13880]
operator: , [13879,13880]
===
match
---
dictorsetmaker [17084,17121]
dictorsetmaker [18461,18498]
===
match
---
name: CELERY_FETCH_ERR_MSG_HEADER [11010,11037]
name: CELERY_FETCH_ERR_MSG_HEADER [11010,11037]
===
match
---
name: broker_url [2602,2612]
name: broker_url [2602,2612]
===
match
---
trailer [16688,16697]
trailer [18065,18074]
===
match
---
funcdef [3914,6495]
funcdef [3914,6495]
===
match
---
string: "231" [15985,15990]
string: "231" [15985,15990]
===
match
---
operator: == [16211,16213]
operator: == [16211,16213]
===
match
---
simple_stmt [1480,1526]
simple_stmt [1480,1526]
===
match
---
assert_stmt [7553,7626]
assert_stmt [7553,7626]
===
match
---
string: "task_2" [13871,13879]
string: "task_2" [13871,13879]
===
match
---
atom_expr [21680,21694]
atom_expr [23057,23071]
===
match
---
string: 'fake_simple_ti' [7381,7397]
string: 'fake_simple_ti' [7381,7397]
===
match
---
name: pytest [18460,18466]
name: pytest [19837,19843]
===
match
---
operator: = [20437,20438]
operator: = [21814,21815]
===
match
---
name: executor [4373,4381]
name: executor [4373,4381]
===
match
---
name: execute [2412,2419]
name: execute [2412,2419]
===
match
---
name: tasks [6378,6383]
name: tasks [6378,6383]
===
match
---
name: Exception [2195,2204]
name: Exception [2195,2204]
===
match
---
operator: = [10847,10848]
operator: = [10847,10848]
===
match
---
trailer [8290,8305]
trailer [8290,8305]
===
match
---
string: "test" [8514,8520]
string: "test" [8514,8520]
===
match
---
name: configuration [1386,1399]
name: configuration [1386,1399]
===
match
---
atom_expr [17370,17419]
atom_expr [18747,18796]
===
match
---
number: 0 [7701,7702]
number: 0 [7701,7702]
===
match
---
simple_stmt [20590,20726]
simple_stmt [21967,22103]
===
match
---
name: ClassWithCustomAttributes [16369,16394]
name: ClassWithCustomAttributes [17746,17771]
===
match
---
arglist [21472,21504]
arglist [22849,22881]
===
match
---
atom_expr [13565,13582]
atom_expr [13565,13582]
===
match
---
with_stmt [17322,17897]
with_stmt [18699,19274]
===
match
---
trailer [13640,13642]
trailer [13640,13642]
===
match
---
operator: == [18142,18144]
operator: == [19519,19521]
===
match
---
name: fake_execute_command [4268,4288]
name: fake_execute_command [4268,4288]
===
match
---
expr_stmt [18643,18716]
expr_stmt [20020,20093]
===
match
---
atom_expr [14730,14766]
atom_expr [14730,14766]
===
match
---
dotted_name [1485,1502]
dotted_name [1485,1502]
===
match
---
name: test_config [2628,2639]
name: test_config [2628,2639]
===
match
---
simple_stmt [6393,6428]
simple_stmt [6393,6428]
===
match
---
name: task_id [7034,7041]
name: task_id [7034,7041]
===
match
---
name: test_utils [1899,1909]
name: test_utils [1899,1909]
===
match
---
name: minutes [13655,13662]
name: minutes [13655,13662]
===
match
---
trailer [7712,7719]
trailer [7712,7719]
===
match
---
simple_stmt [841,852]
simple_stmt [841,852]
===
match
---
operator: { [14403,14404]
operator: { [14403,14404]
===
match
---
string: "postgres" [13009,13019]
string: "postgres" [13009,13019]
===
match
---
atom_expr [14210,14219]
atom_expr [14210,14219]
===
match
---
for_stmt [5316,5506]
for_stmt [5316,5506]
===
match
---
name: key_1 [14784,14789]
name: key_1 [14784,14789]
===
match
---
trailer [11676,11712]
trailer [11676,11712]
===
match
---
trailer [2785,2791]
trailer [2785,2791]
===
match
---
string: "postgres" [7834,7844]
string: "postgres" [7834,7844]
===
match
---
trailer [9471,9481]
trailer [9471,9481]
===
match
---
import_from [1043,1068]
import_from [1043,1068]
===
match
---
parameters [18580,18600]
parameters [19957,19977]
===
match
---
name: tis [14503,14506]
name: tis [14503,14506]
===
match
---
simple_stmt [2864,2891]
simple_stmt [2864,2891]
===
match
---
name: mock_backend [17517,17529]
name: mock_backend [18894,18906]
===
match
---
dictorsetmaker [9122,9128]
dictorsetmaker [9122,9128]
===
match
---
atom_expr [10411,10437]
atom_expr [10411,10437]
===
match
---
simple_stmt [22225,22290]
simple_stmt [23602,23667]
===
match
---
operator: = [21456,21457]
operator: = [22833,22834]
===
match
---
operator: , [7591,7592]
operator: , [7591,7592]
===
match
---
name: dag [14619,14622]
name: dag [14619,14622]
===
match
---
operator: , [21977,21978]
operator: , [23354,23355]
===
match
---
atom_expr [12186,12272]
atom_expr [12186,12272]
===
match
---
dotted_name [1074,1094]
dotted_name [1074,1094]
===
match
---
trailer [5596,5619]
trailer [5596,5619]
===
match
---
comparison [18213,18341]
comparison [19590,19718]
===
match
---
param [16740,16744]
param [18117,18121]
===
match
---
name: execute_command [4847,4862]
name: execute_command [4847,4862]
===
match
---
string: 'fake_simple_ti' [5657,5673]
string: 'fake_simple_ti' [5657,5673]
===
match
---
name: State [6177,6182]
name: State [6177,6182]
===
match
---
string: "task_2" [15466,15474]
string: "task_2" [15466,15474]
===
match
---
atom_expr [15906,15922]
atom_expr [15906,15922]
===
match
---
name: queued_tasks [5401,5413]
name: queued_tasks [5401,5413]
===
match
---
operator: { [21046,21047]
operator: { [22423,22424]
===
match
---
string: "231" [14965,14970]
string: "231" [14965,14970]
===
match
---
import_from [1140,1192]
import_from [1140,1192]
===
match
---
decorator [21080,21096]
decorator [22457,22473]
===
match
---
simple_stmt [1589,1642]
simple_stmt [1589,1642]
===
match
---
operator: , [16112,16113]
operator: , [16112,16113]
===
match
---
dotted_name [3869,3888]
dotted_name [3869,3888]
===
match
---
trailer [2029,2037]
trailer [2029,2037]
===
match
---
suite [19903,20503]
suite [21280,21880]
===
match
---
name: task_1 [15544,15550]
name: task_1 [15544,15550]
===
match
---
name: key_2 [14849,14854]
name: key_2 [14849,14854]
===
match
---
name: result [1260,1266]
name: result [1260,1266]
===
match
---
string: 'id' [8558,8562]
string: 'id' [8558,8562]
===
match
---
operator: , [11390,11391]
operator: , [11390,11391]
===
match
---
suite [16883,16922]
suite [18260,18299]
===
match
---
operator: , [7338,7339]
operator: , [7338,7339]
===
match
---
operator: @ [17136,17137]
operator: @ [18513,18514]
===
match
---
dotted_name [12980,12999]
dotted_name [12980,12999]
===
match
---
name: DatabaseBackend [18658,18673]
name: DatabaseBackend [20035,20050]
===
match
---
atom_expr [9503,9538]
atom_expr [9503,9538]
===
match
---
name: BaseKeyValueStoreBackend [1115,1139]
name: BaseKeyValueStoreBackend [1115,1139]
===
match
---
funcdef [16274,16361]
funcdef [17651,17738]
===
match
---
assert_stmt [10399,10474]
assert_stmt [10399,10474]
===
match
---
with_stmt [6722,7545]
with_stmt [6722,7545]
===
match
---
operator: , [6253,6254]
operator: , [6253,6254]
===
match
---
simple_stmt [4406,4423]
simple_stmt [4406,4423]
===
match
---
simple_stmt [10889,10974]
simple_stmt [10889,10974]
===
match
---
name: mark [3835,3839]
name: mark [3835,3839]
===
match
---
name: signal [21680,21686]
name: signal [23057,23063]
===
match
---
name: bash_command [7050,7062]
name: bash_command [7050,7062]
===
match
---
operator: } [10099,10100]
operator: } [10099,10100]
===
match
---
operator: } [19195,19196]
operator: } [20572,20573]
===
match
---
operator: , [4644,4645]
operator: , [4644,4645]
===
match
---
suite [13753,13904]
suite [13753,13904]
===
match
---
name: state [20445,20450]
name: state [21822,21827]
===
match
---
simple_stmt [7635,7720]
simple_stmt [7635,7720]
===
match
---
atom [19572,19687]
atom [20949,21064]
===
match
---
atom_expr [15237,15258]
atom_expr [15237,15258]
===
match
---
trailer [6170,6173]
trailer [6170,6173]
===
match
---
atom_expr [21339,21352]
atom_expr [22716,22729]
===
match
---
import_name [841,851]
import_name [841,851]
===
match
---
strings [9717,9843]
strings [9717,9843]
===
match
---
simple_stmt [13841,13904]
simple_stmt [13841,13904]
===
match
---
funcdef [16727,16777]
funcdef [18104,18154]
===
match
---
comparison [9296,9435]
comparison [9296,9435]
===
match
---
name: pytest [1036,1042]
name: pytest [1036,1042]
===
match
---
operator: , [2612,2613]
operator: , [2612,2613]
===
match
---
operator: = [2779,2780]
operator: = [2779,2780]
===
match
---
simple_stmt [19234,19263]
simple_stmt [20611,20640]
===
match
---
trailer [11520,11522]
trailer [11520,11522]
===
match
---
operator: = [15465,15466]
operator: = [15465,15466]
===
match
---
atom_expr [2486,2528]
atom_expr [2486,2528]
===
match
---
name: register_signals [21772,21788]
name: register_signals [23149,23165]
===
match
---
name: backend [15055,15062]
name: backend [15055,15062]
===
match
---
trailer [19421,19436]
trailer [20798,20813]
===
match
---
expr_stmt [14007,14036]
expr_stmt [14007,14036]
===
match
---
operator: , [16556,16557]
operator: , [17933,17934]
===
match
---
name: celery_executor [11461,11476]
name: celery_executor [11461,11476]
===
match
---
name: execute_date [5675,5687]
name: execute_date [5675,5687]
===
match
---
atom_expr [14369,14399]
atom_expr [14369,14399]
===
match
---
name: result [19279,19285]
name: result [20656,20662]
===
match
---
trailer [2673,2682]
trailer [2673,2682]
===
match
---
atom [9699,9870]
atom [9699,9870]
===
match
---
name: __init__ [16515,16523]
name: __init__ [17892,17900]
===
match
---
atom_expr [15682,15714]
atom_expr [15682,15714]
===
match
---
trailer [10502,10515]
trailer [10502,10515]
===
match
---
simple_stmt [9645,9680]
simple_stmt [9645,9680]
===
match
---
operator: } [19555,19556]
operator: } [20932,20933]
===
match
---
simple_stmt [3387,3402]
simple_stmt [3387,3402]
===
match
---
fstring [9369,9422]
fstring [9369,9422]
===
match
---
trailer [6214,6227]
trailer [6214,6227]
===
match
---
operator: = [2349,2350]
operator: = [2349,2350]
===
match
---
trailer [9928,9959]
trailer [9928,9959]
===
match
---
number: 0 [4678,4679]
number: 0 [4678,4679]
===
match
---
operator: , [17300,17301]
operator: , [18677,18678]
===
match
---
name: SIGUSR2 [21479,21486]
name: SIGUSR2 [22856,22863]
===
match
---
name: mock_session [18951,18963]
name: mock_session [20328,20340]
===
match
---
trailer [17339,17341]
trailer [18716,18718]
===
match
---
name: executor [22165,22173]
name: executor [23542,23550]
===
match
---
trailer [21064,21069]
trailer [22441,22446]
===
match
---
suite [10689,11131]
suite [10689,11131]
===
match
---
string: 'version' [11847,11856]
string: 'version' [11847,11856]
===
match
---
name: key [8838,8841]
name: key [8838,8841]
===
match
---
name: contrib [993,1000]
name: contrib [993,1000]
===
match
---
argument [15247,15257]
argument [15247,15257]
===
match
---
operator: = [15963,15964]
operator: = [15963,15964]
===
match
---
name: timeout [8163,8170]
name: timeout [8163,8170]
===
match
---
name: MockTask [20734,20742]
name: MockTask [22111,22119]
===
match
---
operator: } [8361,8362]
operator: } [8361,8362]
===
match
---
name: mock [19115,19119]
name: mock [20492,20496]
===
match
---
name: tis [14244,14247]
name: tis [14244,14247]
===
match
---
operator: = [13249,13250]
operator: = [13249,13250]
===
match
---
atom_expr [14045,14054]
atom_expr [14045,14054]
===
match
---
name: _prepare_app [18615,18627]
name: _prepare_app [19992,20004]
===
match
---
name: heartbeat [11511,11520]
name: heartbeat [11511,11520]
===
match
---
expr_stmt [13675,13689]
expr_stmt [13675,13689]
===
match
---
trailer [15535,15542]
trailer [15535,15542]
===
match
---
simple_stmt [4310,4354]
simple_stmt [4310,4354]
===
match
---
comparison [10494,10571]
comparison [10494,10571]
===
match
---
name: unittest [3544,3552]
name: unittest [3544,3552]
===
match
---
atom_expr [14870,14900]
atom_expr [14870,14900]
===
match
---
name: State [16122,16127]
name: State [16122,16127]
===
match
---
operator: { [16699,16700]
operator: { [18076,18077]
===
match
---
name: mock_subproc [12584,12596]
name: mock_subproc [12584,12596]
===
match
---
operator: , [15542,15543]
operator: , [15542,15543]
===
match
---
for_stmt [16549,16621]
for_stmt [17926,17998]
===
match
---
atom_expr [11553,11595]
atom_expr [11553,11595]
===
match
---
name: _prepare_app [17327,17339]
name: _prepare_app [18704,18716]
===
match
---
param [4121,4128]
param [4121,4128]
===
match
---
trailer [10008,10021]
trailer [10008,10021]
===
match
---
name: celery_configuration [2507,2527]
name: celery_configuration [2507,2527]
===
match
---
simple_stmt [21795,21868]
simple_stmt [23172,23245]
===
match
---
operator: { [18016,18017]
operator: { [19393,19394]
===
match
---
string: 'fail' [6229,6235]
string: 'fail' [6229,6235]
===
match
---
name: result [20519,20525]
name: result [21896,21902]
===
match
---
trailer [9892,9902]
trailer [9892,9902]
===
match
---
operator: { [14945,14946]
operator: { [14945,14946]
===
match
---
name: signal [21291,21297]
name: signal [22668,22674]
===
match
---
name: integration [19719,19730]
name: integration [21096,21107]
===
match
---
trailer [14878,14900]
trailer [14878,14900]
===
match
---
simple_stmt [2472,2529]
simple_stmt [2472,2529]
===
match
---
name: mark [17223,17227]
name: mark [18600,18604]
===
match
---
atom [19093,19216]
atom [20470,20593]
===
match
---
operator: = [6747,6748]
operator: = [6747,6748]
===
match
---
operator: = [3985,3986]
operator: = [3985,3986]
===
match
---
name: celery_executor [8031,8046]
name: celery_executor [8031,8046]
===
match
---
name: other [16915,16920]
name: other [18292,18297]
===
match
---
name: FAILED [16099,16105]
name: FAILED [16099,16105]
===
match
---
argument [8506,8520]
argument [8506,8520]
===
match
---
name: command [11953,11960]
name: command [11953,11960]
===
match
---
string: 'DEBUG:airflow.executors.celery_executor.BulkStateFetcher:Fetched 2 state(s) for 2 task(s)' [20611,20702]
string: 'DEBUG:airflow.executors.celery_executor.BulkStateFetcher:Fetched 2 state(s) for 2 task(s)' [21988,22079]
===
match
---
name: pytest [17216,17222]
name: pytest [18593,18599]
===
match
---
number: 0 [18009,18010]
number: 0 [19386,19387]
===
match
---
testlist_comp [4934,4975]
testlist_comp [4934,4975]
===
match
---
name: test_send_tasks_to_celery_hang [21741,21771]
name: test_send_tasks_to_celery_hang [23118,23148]
===
match
---
operator: = [2484,2485]
operator: = [2484,2485]
===
match
---
trailer [18693,18697]
trailer [20070,20074]
===
match
---
operator: - [13110,13111]
operator: - [13110,13111]
===
match
---
dotted_name [1855,1874]
dotted_name [1855,1874]
===
match
---
trailer [11060,11067]
trailer [11060,11067]
===
match
---
funcdef [4096,4221]
funcdef [4096,4221]
===
match
---
operator: = [15411,15412]
operator: = [15411,15412]
===
match
---
arglist [16603,16619]
arglist [17980,17996]
===
match
---
trailer [12478,12485]
trailer [12478,12485]
===
match
---
atom_expr [15177,15194]
atom_expr [15177,15194]
===
match
---
name: BaseBackend [19955,19966]
name: BaseBackend [21332,21343]
===
match
---
operator: == [6174,6176]
operator: == [6174,6176]
===
match
---
operator: , [4972,4973]
operator: , [4972,4973]
===
match
---
name: dag_id [8551,8557]
name: dag_id [8551,8557]
===
match
---
string: 'id' [7086,7090]
string: 'id' [7086,7090]
===
match
---
name: queued_dttm [13611,13622]
name: queued_dttm [13611,13622]
===
match
---
string: "runid" [15560,15567]
string: "runid" [15560,15567]
===
match
---
operator: , [17954,17955]
operator: , [19331,19332]
===
match
---
operator: = [8575,8576]
operator: = [8575,8576]
===
match
---
atom_expr [18075,18118]
atom_expr [19452,19495]
===
match
---
name: SimpleTaskInstance [1717,1735]
name: SimpleTaskInstance [1717,1735]
===
match
---
name: CeleryExecutor [10803,10817]
name: CeleryExecutor [10803,10817]
===
match
---
name: args [20910,20914]
name: args [22287,22291]
===
match
---
operator: , [17103,17104]
operator: , [18480,18481]
===
match
---
atom [20295,20484]
atom [21672,21861]
===
match
---
name: external_executor_id [14135,14155]
name: external_executor_id [14135,14155]
===
match
---
name: self [16762,16766]
name: self [18139,18143]
===
match
---
simple_stmt [9042,9063]
simple_stmt [9042,9063]
===
match
---
name: signal [21458,21464]
name: signal [22835,22841]
===
match
---
comparison [16322,16360]
comparison [17699,17737]
===
match
---
name: celery_executor [16322,16337]
name: celery_executor [17699,17714]
===
match
---
name: models [1655,1661]
name: models [1655,1661]
===
match
---
decorator [11291,11350]
decorator [11291,11350]
===
match
---
comparison [14680,14714]
comparison [14680,14714]
===
match
---
name: assert_has_calls [11749,11765]
name: assert_has_calls [11749,11765]
===
match
---
name: _process_tasks [5532,5546]
name: _process_tasks [5532,5546]
===
match
---
name: mock [19407,19411]
name: mock [20784,20788]
===
match
---
name: orig_sigterm [21376,21388]
name: orig_sigterm [22753,22765]
===
match
---
suite [2933,3326]
suite [2933,3326]
===
match
---
simple_stmt [1248,1286]
simple_stmt [1248,1286]
===
match
---
trailer [8785,8809]
trailer [8785,8809]
===
match
---
suite [1949,2120]
suite [1949,2120]
===
match
---
decorator [7763,7800]
decorator [7763,7800]
===
match
---
name: heartbeat [7533,7542]
name: heartbeat [7533,7542]
===
match
---
return_stmt [20935,20943]
return_stmt [22312,22320]
===
match
---
arith_expr [13092,13129]
arith_expr [13092,13129]
===
match
---
trailer [5842,5890]
trailer [5842,5890]
===
match
---
atom_expr [9426,9435]
atom_expr [9426,9435]
===
match
---
number: 600 [6456,6459]
number: 600 [6456,6459]
===
match
---
name: test_error_sending_task [6629,6652]
name: test_error_sending_task [6629,6652]
===
match
---
operator: , [7689,7690]
operator: , [7689,7690]
===
match
---
name: utils [1863,1868]
name: utils [1863,1868]
===
match
---
name: contextlib [794,804]
name: contextlib [794,804]
===
match
---
operator: = [11459,11460]
operator: = [11459,11460]
===
match
---
name: celery_executor [4747,4762]
name: celery_executor [4747,4762]
===
match
---
name: timezone [13625,13633]
name: timezone [13625,13633]
===
match
---
import_from [1589,1641]
import_from [1589,1641]
===
match
---
name: key [8914,8917]
name: key [8914,8917]
===
match
---
string: 'airflow' [4065,4074]
string: 'airflow' [4065,4074]
===
match
---
name: DAG [7075,7078]
name: DAG [7075,7078]
===
match
---
trailer [15457,15498]
trailer [15457,15498]
===
match
---
atom_expr [9847,9856]
atom_expr [9847,9856]
===
match
---
suite [12450,12663]
suite [12450,12663]
===
match
---
suite [2180,2207]
suite [2180,2207]
===
match
---
atom_expr [20983,21056]
atom_expr [22360,22433]
===
match
---
name: ClassWithCustomAttributes [16663,16688]
name: ClassWithCustomAttributes [18040,18065]
===
match
---
name: output [18335,18341]
name: output [19712,19718]
===
match
---
trailer [17394,17419]
trailer [18771,18796]
===
match
---
atom_expr [16214,16219]
atom_expr [16214,16219]
===
match
---
name: heartbeat [9893,9902]
name: heartbeat [9893,9902]
===
match
---
trailer [5400,5413]
trailer [5400,5413]
===
match
---
operator: , [15648,15649]
operator: , [15648,15649]
===
match
---
operator: { [9414,9415]
operator: { [9414,9415]
===
match
---
name: State [16093,16098]
name: State [16093,16098]
===
match
---
operator: = [17620,17621]
operator: = [18997,18998]
===
match
---
name: expected_exception [12486,12504]
name: expected_exception [12486,12504]
===
match
---
trailer [15246,15258]
trailer [15246,15258]
===
match
---
atom_expr [3496,3516]
atom_expr [3496,3516]
===
match
---
argument [8522,8541]
argument [8522,8541]
===
match
---
name: _prepare_test_bodies [1926,1946]
name: _prepare_test_bodies [1926,1946]
===
match
---
name: mark [13465,13469]
name: mark [13465,13469]
===
match
---
suite [5371,5506]
suite [5371,5506]
===
match
---
trailer [13707,13745]
trailer [13707,13745]
===
match
---
atom_expr [8015,8051]
atom_expr [8015,8051]
===
match
---
trailer [17969,17979]
trailer [19346,19356]
===
match
---
name: task_id [2216,2223]
name: task_id [2216,2223]
===
match
---
argument [15476,15497]
argument [15476,15497]
===
match
---
name: ANY [11649,11652]
name: ANY [11649,11652]
===
match
---
simple_stmt [13966,13999]
simple_stmt [13966,13999]
===
match
---
operator: , [1113,1114]
operator: , [1113,1114]
===
match
---
argument [8770,8809]
argument [8770,8809]
===
match
---
name: State [10559,10564]
name: State [10559,10564]
===
match
---
name: self [13537,13541]
name: self [13537,13541]
===
match
---
trailer [21345,21352]
trailer [22722,22729]
===
match
---
with_item [8015,8057]
with_item [8015,8057]
===
match
---
operator: , [8733,8734]
operator: , [8733,8734]
===
match
---
operator: , [18813,18814]
operator: , [20190,20191]
===
match
---
suite [20185,20503]
suite [21562,21880]
===
match
---
name: kwargs [20918,20924]
name: kwargs [22295,22301]
===
match
---
name: mark [18467,18471]
name: mark [19844,19848]
===
match
---
argument [13655,13664]
argument [13655,13664]
===
match
---
assert_stmt [5585,5775]
assert_stmt [5585,5775]
===
match
---
name: executor [6400,6408]
name: executor [6400,6408]
===
match
---
operator: { [15925,15926]
operator: { [15925,15926]
===
match
---
comparison [16158,16178]
comparison [16158,16178]
===
match
---
atom_expr [17437,17543]
atom_expr [18814,18920]
===
match
---
name: __str__ [16767,16774]
name: __str__ [18144,18151]
===
match
---
atom_expr [4321,4353]
atom_expr [4321,4353]
===
match
---
atom_expr [21632,21646]
atom_expr [23009,23023]
===
match
---
name: task [13291,13295]
name: task [13291,13295]
===
match
---
operator: != [4154,4156]
operator: != [4154,4156]
===
match
---
operator: , [9180,9181]
operator: , [9180,9181]
===
match
---
string: 'fail' [10517,10523]
string: 'fail' [10517,10523]
===
match
---
name: queued_dttm [14011,14022]
name: queued_dttm [14011,14022]
===
match
---
name: dag [13749,13752]
name: dag [13749,13752]
===
match
---
atom_expr [17545,17629]
atom_expr [18922,19006]
===
match
---
name: days [13122,13126]
name: days [13122,13126]
===
match
---
name: models [1602,1608]
name: models [1602,1608]
===
match
---
operator: = [15595,15596]
operator: = [15595,15596]
===
match
---
arglist [2602,2639]
arglist [2602,2639]
===
match
---
argument [10994,11067]
argument [10994,11067]
===
match
---
name: line [11050,11054]
name: line [11050,11054]
===
match
---
name: logfile [4463,4470]
name: logfile [4463,4470]
===
match
---
comparison [14328,14353]
comparison [14328,14353]
===
match
---
name: len [9996,9999]
name: len [9996,9999]
===
match
---
simple_stmt [16595,16621]
simple_stmt [17972,17998]
===
match
---
param [20909,20915]
param [22286,22292]
===
match
---
parameters [15128,15134]
parameters [15128,15134]
===
match
---
atom_expr [11461,11493]
atom_expr [11461,11493]
===
match
---
name: try_number [14653,14663]
name: try_number [14653,14663]
===
match
---
name: adopted_task_timeouts [14744,14765]
name: adopted_task_timeouts [14744,14765]
===
match
---
operator: = [8919,8920]
operator: = [8919,8920]
===
match
---
operator: } [9128,9129]
operator: } [9128,9129]
===
match
---
name: DAG [13704,13707]
name: DAG [13704,13707]
===
match
---
atom_expr [13278,13316]
atom_expr [13278,13316]
===
match
---
atom_expr [2195,2206]
atom_expr [2195,2206]
===
match
---
trailer [6408,6421]
trailer [6408,6421]
===
match
---
atom_expr [14348,14353]
atom_expr [14348,14353]
===
match
---
expr_stmt [13346,13389]
expr_stmt [13346,13389]
===
match
---
trailer [6122,6170]
trailer [6122,6170]
===
match
---
name: pytest [12980,12986]
name: pytest [12980,12986]
===
match
---
arglist [17465,17529]
arglist [18842,18906]
===
match
---
name: test_app [2660,2668]
name: test_app [2660,2668]
===
match
---
expr_stmt [15203,15258]
expr_stmt [15203,15258]
===
match
---
decorated [2150,2207]
decorated [2150,2207]
===
match
---
trailer [14351,14353]
trailer [14351,14353]
===
match
---
atom_expr [15445,15498]
atom_expr [15445,15498]
===
match
---
simple_stmt [8469,8605]
simple_stmt [8469,8605]
===
match
---
name: self [16524,16528]
name: self [17901,17905]
===
match
---
suite [20926,20944]
suite [22303,22321]
===
match
---
operator: { [16176,16177]
operator: { [16176,16177]
===
match
---
string: 'DEBUG:airflow.executors.celery_executor.BulkStateFetcher:Fetched 2 state(s) for 2 task(s)' [18227,18318]
string: 'DEBUG:airflow.executors.celery_executor.BulkStateFetcher:Fetched 2 state(s) for 2 task(s)' [19604,19695]
===
match
---
name: app [4454,4457]
name: app [4454,4457]
===
match
---
expr_stmt [6997,7132]
expr_stmt [6997,7132]
===
match
---
operator: , [15474,15475]
operator: , [15474,15475]
===
match
---
operator: , [11712,11713]
operator: , [11712,11713]
===
match
---
arglist [18674,18715]
arglist [20051,20092]
===
match
---
operator: , [7261,7262]
operator: , [7261,7262]
===
match
---
atom_expr [15516,15580]
atom_expr [15516,15580]
===
match
---
name: value_tuple [8651,8662]
name: value_tuple [8651,8662]
===
match
---
operator: , [19522,19523]
operator: , [20899,20900]
===
match
---
name: self [10683,10687]
name: self [10683,10687]
===
match
---
name: task_id [15551,15558]
name: task_id [15551,15558]
===
match
---
name: _ [20975,20976]
name: _ [22352,22353]
===
match
---
operator: , [20378,20379]
operator: , [21755,21756]
===
match
---
string: """     A picklable object used to mock tasks sent to Celery. Can't use the mock library     here because it's not picklable.     """ [20748,20881]
string: """     A picklable object used to mock tasks sent to Celery. Can't use the mock library     here because it's not picklable.     """ [22125,22258]
===
match
---
atom_expr [16028,16043]
atom_expr [16028,16043]
===
match
---
suite [3563,16272]
suite [3563,17649]
===
match
---
trailer [17775,17785]
trailer [19152,19162]
===
match
---
atom_expr [13357,13389]
atom_expr [13357,13389]
===
match
---
name: _ [17956,17957]
name: _ [19333,19334]
===
match
---
name: fetcher [19234,19241]
name: fetcher [20611,20618]
===
match
---
operator: = [17958,17959]
operator: = [19335,19336]
===
match
---
atom [14439,14441]
atom [14439,14441]
===
match
---
testlist_comp [12859,12890]
testlist_comp [12859,12890]
===
match
---
atom [5645,5691]
atom [5645,5691]
===
match
---
sync_comp_for [21991,22009]
sync_comp_for [23368,23386]
===
match
---
dotted_name [7726,7749]
dotted_name [7726,7749]
===
match
---
simple_stmt [1526,1589]
simple_stmt [1526,1589]
===
match
---
name: dict [2486,2490]
name: dict [2486,2490]
===
match
---
trailer [17714,17723]
trailer [19091,19100]
===
match
---
simple_stmt [9563,9633]
simple_stmt [9563,9633]
===
match
---
name: execute_date [6153,6165]
name: execute_date [6153,6165]
===
match
---
operator: , [18697,18698]
operator: , [20074,20075]
===
match
---
suite [16395,16922]
suite [17772,18299]
===
match
---
operator: , [18911,18912]
operator: , [20288,20289]
===
match
---
name: ANY [18114,18117]
name: ANY [19491,19494]
===
match
---
funcdef [15088,16272]
funcdef [15088,16272]
===
match
---
dotted_name [21081,21095]
dotted_name [22458,22472]
===
match
---
atom_expr [9884,9904]
atom_expr [9884,9904]
===
match
---
decorators [16975,17257]
decorators [18352,18634]
===
match
---
name: DAG [8547,8550]
name: DAG [8547,8550]
===
match
---
assert_stmt [6436,6494]
assert_stmt [6436,6494]
===
match
---
fstring_end: " [9421,9422]
fstring_end: " [9421,9422]
===
match
---
comparison [9652,9679]
comparison [9652,9679]
===
match
---
atom_expr [15544,15558]
atom_expr [15544,15558]
===
match
---
atom_expr [16663,16697]
atom_expr [18040,18074]
===
match
---
with_item [12076,12184]
with_item [12076,12184]
===
match
---
name: execute [4260,4267]
name: execute [4260,4267]
===
match
---
number: 3 [9548,9549]
number: 3 [9548,9549]
===
match
---
simple_stmt [11502,11523]
simple_stmt [11502,11523]
===
match
---
suite [10763,10974]
suite [10763,10974]
===
match
---
funcdef [21096,21710]
funcdef [22473,23087]
===
match
---
trailer [10349,10380]
trailer [10349,10380]
===
match
---
name: start_date [15144,15154]
name: start_date [15144,15154]
===
match
---
operator: = [20367,20368]
operator: = [21744,21745]
===
match
---
name: environ [2030,2037]
name: environ [2030,2037]
===
match
---
trailer [3630,3644]
trailer [3630,3644]
===
match
---
name: celery_executor [12527,12542]
name: celery_executor [12527,12542]
===
match
---
name: datetime [7104,7112]
name: datetime [7104,7112]
===
match
---
expr_stmt [7145,7166]
expr_stmt [7145,7166]
===
match
---
name: bash_command [8522,8534]
name: bash_command [8522,8534]
===
match
---
operator: , [20973,20974]
operator: , [22350,22351]
===
match
---
atom_expr [2491,2527]
atom_expr [2491,2527]
===
match
---
name: dumps [17077,17082]
name: dumps [18454,18459]
===
match
---
testlist_comp [4933,5156]
testlist_comp [4933,5156]
===
match
---
simple_stmt [5792,5928]
simple_stmt [5792,5928]
===
match
---
arglist [8506,8590]
arglist [8506,8590]
===
match
---
operator: , [15991,15992]
operator: , [15991,15992]
===
match
---
operator: { [9677,9678]
operator: { [9677,9678]
===
match
---
name: executor [10000,10008]
name: executor [10000,10008]
===
match
---
operator: { [9542,9543]
operator: { [9542,9543]
===
match
---
atom [17071,17124]
atom [18448,18501]
===
match
---
atom_expr [19352,19381]
atom_expr [20729,20758]
===
match
---
simple_stmt [3715,3734]
simple_stmt [3715,3734]
===
match
---
comparison [19494,19556]
comparison [20871,20933]
===
match
---
trailer [13147,13185]
trailer [13147,13185]
===
match
---
dictorsetmaker [15966,16018]
dictorsetmaker [15966,16018]
===
match
---
name: assert_called_once_with [18085,18108]
name: assert_called_once_with [19462,19485]
===
match
---
import_from [1373,1411]
import_from [1373,1411]
===
match
---
atom [18179,18196]
atom [19556,19573]
===
match
---
expr_stmt [15268,15282]
expr_stmt [15268,15282]
===
match
---
atom_expr [11732,11772]
atom_expr [11732,11772]
===
match
---
atom_expr [14084,14122]
atom_expr [14084,14122]
===
match
---
name: assertLogs [17550,17560]
name: assertLogs [18927,18937]
===
match
---
simple_stmt [15268,15283]
simple_stmt [15268,15283]
===
match
---
trailer [16602,16620]
trailer [17979,17997]
===
match
---
trailer [7502,7507]
trailer [7502,7507]
===
match
---
string: 'airflow.executors.celery_executor.CeleryExecutor.sync' [11148,11203]
string: 'airflow.executors.celery_executor.CeleryExecutor.sync' [11148,11203]
===
match
---
name: assertLogs [8020,8030]
name: assertLogs [8020,8030]
===
match
---
name: worker [1221,1227]
name: worker [1221,1227]
===
match
---
suite [6659,7720]
suite [6659,7720]
===
match
---
atom [4608,4885]
atom [4608,4885]
===
match
---
trailer [5902,5909]
trailer [5902,5909]
===
match
---
simple_stmt [21943,22011]
simple_stmt [23320,23388]
===
match
---
name: task_2 [13841,13847]
name: task_2 [13841,13847]
===
match
---
comparison [9717,9856]
comparison [9717,9856]
===
match
---
fstring_string: [Try 2 of 3] Task Timeout Error for Task: ( [9792,9835]
fstring_string: [Try 2 of 3] Task Timeout Error for Task: ( [9792,9835]
===
match
---
simple_stmt [14414,14442]
simple_stmt [14414,14442]
===
match
---
name: patch [12292,12297]
name: patch [12292,12297]
===
match
---
name: patch [2786,2791]
name: patch [2786,2791]
===
match
---
name: synchronous [6067,6078]
name: synchronous [6067,6078]
===
match
---
decorated [21712,22290]
decorated [23089,23667]
===
match
---
name: mark [7771,7775]
name: mark [7771,7775]
===
match
---
operator: , [4958,4959]
operator: , [4958,4959]
===
match
---
name: task_publish_retries [5476,5496]
name: task_publish_retries [5476,5496]
===
match
---
suite [4500,6085]
suite [4500,6085]
===
match
---
trailer [22005,22009]
trailer [23382,23386]
===
match
---
number: 0 [4974,4975]
number: 0 [4974,4975]
===
match
---
name: key [5414,5417]
name: key [5414,5417]
===
match
---
name: session [3268,3275]
name: session [3268,3275]
===
match
---
name: call_args [12823,12832]
name: call_args [12823,12832]
===
match
---
expr_stmt [3268,3301]
expr_stmt [3268,3301]
===
match
---
name: BulkStateFetcher [20212,20228]
name: BulkStateFetcher [21589,21605]
===
match
---
simple_stmt [13552,13603]
simple_stmt [13552,13603]
===
match
---
trailer [11562,11595]
trailer [11562,11595]
===
match
---
decorated [7725,10572]
decorated [7725,10572]
===
match
---
operator: == [7704,7706]
operator: == [7704,7706]
===
match
---
expr_stmt [21311,21371]
expr_stmt [22688,22748]
===
match
---
operator: == [14345,14347]
operator: == [14345,14347]
===
match
---
string: "Task should remain in queue" [9603,9632]
string: "Task should remain in queue" [9603,9632]
===
match
---
string: """     Test that celery_executor does not hang after many runs.     """ [21795,21867]
string: """     Test that celery_executor does not hang after many runs.     """ [23172,23244]
===
match
---
simple_stmt [14269,14313]
simple_stmt [14269,14313]
===
match
---
name: CeleryExecutor [13373,13387]
name: CeleryExecutor [13373,13387]
===
match
---
simple_stmt [13913,13958]
simple_stmt [13913,13958]
===
match
---
atom [9256,9258]
atom [9256,9258]
===
match
---
atom_expr [14927,14941]
atom_expr [14927,14941]
===
match
---
name: json [812,816]
name: json [812,816]
===
match
---
operator: = [13848,13849]
operator: = [13848,13849]
===
match
---
string: """Class for testing purpose: allows to create objects with custom attributes in one single statement.""" [16400,16505]
string: """Class for testing purpose: allows to create objects with custom attributes in one single statement.""" [17777,17882]
===
match
---
param [11947,11952]
param [11947,11952]
===
match
---
trailer [2065,2070]
trailer [2065,2070]
===
match
---
name: fake_execute_command [4100,4120]
name: fake_execute_command [4100,4120]
===
match
---
arglist [16996,17125]
arglist [18373,18502]
===
match
---
operator: = [7062,7063]
operator: = [7062,7063]
===
match
---
funcdef [13503,15037]
funcdef [13503,15037]
===
match
---
name: executor [8264,8272]
name: executor [8264,8272]
===
match
---
string: "status" [17084,17092]
string: "status" [18461,18469]
===
match
---
name: executor [15906,15914]
name: executor [15906,15914]
===
match
---
operator: { [20991,20992]
operator: { [22368,22369]
===
match
---
dotted_name [6580,6599]
dotted_name [6580,6599]
===
match
---
name: start_date [13892,13902]
name: start_date [13892,13902]
===
match
---
trailer [3299,3301]
trailer [3299,3301]
===
match
---
name: task_tuples_to_send [5351,5370]
name: task_tuples_to_send [5351,5370]
===
match
---
parameters [1946,1948]
parameters [1946,1948]
===
match
---
arglist [11619,11652]
arglist [11619,11652]
===
match
---
name: dag [15532,15535]
name: dag [15532,15535]
===
match
---
name: executor [10415,10423]
name: executor [10415,10423]
===
match
---
comparison [10994,11045]
comparison [10994,11045]
===
match
---
atom_expr [16822,16835]
atom_expr [18199,18212]
===
match
---
operator: } [17121,17122]
operator: } [18498,18499]
===
match
---
argument [19422,19435]
argument [20799,20812]
===
match
---
simple_stmt [2001,2072]
simple_stmt [2001,2072]
===
match
---
atom [8360,8362]
atom [8360,8362]
===
match
---
name: mock_stats_gauge [11392,11408]
name: mock_stats_gauge [11392,11408]
===
match
---
string: "task_1" [15391,15399]
string: "task_1" [15391,15399]
===
match
---
arglist [15063,15082]
arglist [15063,15082]
===
match
---
import_from [1248,1285]
import_from [1248,1285]
===
match
---
trailer [16573,16579]
trailer [17950,17956]
===
match
---
comparison [12914,12973]
comparison [12914,12973]
===
match
---
dotted_name [6539,6562]
dotted_name [6539,6562]
===
match
---
atom_expr [19888,19902]
atom_expr [21265,21279]
===
match
---
arglist [11677,11711]
arglist [11677,11711]
===
match
---
trailer [2551,2579]
trailer [2551,2579]
===
match
---
trailer [10552,10555]
trailer [10552,10555]
===
match
---
parameters [16637,16643]
parameters [18014,18020]
===
match
---
atom_expr [17399,17418]
atom_expr [18776,18795]
===
match
---
atom_expr [9158,9179]
atom_expr [9158,9179]
===
match
---
trailer [9516,9537]
trailer [9516,9537]
===
match
---
string: 'BROKER_URL' [2104,2116]
string: 'BROKER_URL' [2104,2116]
===
match
---
atom_expr [11586,11594]
atom_expr [11586,11594]
===
match
---
trailer [6017,6020]
trailer [6017,6020]
===
match
---
simple_stmt [2687,2761]
simple_stmt [2687,2761]
===
match
---
operator: , [19529,19530]
operator: , [20906,20907]
===
match
---
dictorsetmaker [14784,14901]
dictorsetmaker [14784,14901]
===
match
---
dotted_name [1820,1833]
dotted_name [1820,1833]
===
match
---
assert_stmt [6094,6190]
assert_stmt [6094,6190]
===
match
---
simple_stmt [2584,2641]
simple_stmt [2584,2641]
===
match
---
trailer [2882,2890]
trailer [2882,2890]
===
match
---
trailer [21297,21305]
trailer [22674,22682]
===
match
---
name: executor [10776,10784]
name: executor [10776,10784]
===
match
---
funcdef [16859,16922]
funcdef [18236,18299]
===
match
---
trailer [8076,8250]
trailer [8076,8250]
===
match
---
operator: , [17124,17125]
operator: , [18501,18502]
===
match
---
operator: == [6461,6463]
operator: == [6461,6463]
===
match
---
trailer [12728,12737]
trailer [12728,12737]
===
match
---
atom_expr [16567,16581]
atom_expr [17944,17958]
===
match
---
argument [11088,11129]
argument [11088,11129]
===
match
---
expr_stmt [15436,15498]
expr_stmt [15436,15498]
===
match
---
atom_expr [10415,10436]
atom_expr [10415,10436]
===
match
---
trailer [11590,11594]
trailer [11590,11594]
===
match
---
name: queued_dttm [14025,14036]
name: queued_dttm [14025,14036]
===
match
---
name: not_adopted_tis [15015,15030]
name: not_adopted_tis [15015,15030]
===
match
---
name: register_signals [21100,21116]
name: register_signals [22477,22493]
===
match
---
operator: == [10381,10383]
operator: == [10381,10383]
===
match
---
simple_stmt [11450,11494]
simple_stmt [11450,11494]
===
match
---
dotted_name [7764,7787]
dotted_name [7764,7787]
===
match
---
with_stmt [12071,12974]
with_stmt [12071,12974]
===
match
---
name: celery_executor [2423,2438]
name: celery_executor [2423,2438]
===
match
---
trailer [16166,16172]
trailer [16166,16172]
===
match
---
name: SimpleTaskInstance [7279,7297]
name: SimpleTaskInstance [7279,7297]
===
match
---
expr_stmt [10832,10876]
expr_stmt [10832,10876]
===
match
---
string: "true" [8535,8541]
string: "true" [8535,8541]
===
match
---
name: ti2 [14256,14259]
name: ti2 [14256,14259]
===
match
---
import_from [1193,1247]
import_from [1193,1247]
===
match
---
import_name [979,1014]
import_name [979,1014]
===
match
---
name: executor [15671,15679]
name: executor [15671,15679]
===
match
---
atom_expr [14131,14155]
atom_expr [14131,14155]
===
match
---
operator: , [15886,15887]
operator: , [15886,15887]
===
match
---
operator: , [4021,4022]
operator: , [4021,4022]
===
match
---
name: celery [1253,1259]
name: celery [1253,1259]
===
match
---
operator: , [11892,11893]
operator: , [11892,11893]
===
match
---
trailer [9937,9958]
trailer [9937,9958]
===
match
---
name: backend [13470,13477]
name: backend [13470,13477]
===
match
---
name: mark [15050,15054]
name: mark [15050,15054]
===
match
---
simple_stmt [2189,2207]
simple_stmt [2189,2207]
===
match
---
expr_stmt [20202,20231]
expr_stmt [21579,21608]
===
match
---
atom_expr [10720,10756]
atom_expr [10720,10756]
===
match
---
name: executor [5392,5400]
name: executor [5392,5400]
===
match
---
name: tasks [1009,1014]
name: tasks [1009,1014]
===
match
---
name: test_try_adopt_task_instances_none [13029,13063]
name: test_try_adopt_task_instances_none [13029,13063]
===
match
---
operator: = [8842,8843]
operator: = [8842,8843]
===
match
---
atom_expr [21291,21305]
atom_expr [22668,22682]
===
match
---
simple_stmt [13199,13262]
simple_stmt [13199,13262]
===
match
---
operator: , [8711,8712]
operator: , [8711,8712]
===
match
---
atom_expr [16704,16717]
atom_expr [18081,18094]
===
match
---
operator: , [21646,21647]
operator: , [23023,23024]
===
match
---
operator: , [10541,10542]
operator: , [10541,10542]
===
match
---
operator: = [20169,20170]
operator: = [21546,21547]
===
match
---
operator: , [6235,6236]
operator: , [6235,6236]
===
match
---
arglist [13221,13260]
arglist [13221,13260]
===
match
---
name: filter [19054,19060]
name: filter [20431,20437]
===
match
---
assert_stmt [5944,6036]
assert_stmt [5944,6036]
===
match
---
trailer [8335,8356]
trailer [8335,8356]
===
match
---
name: contextmanager [2270,2284]
name: contextmanager [2270,2284]
===
match
---
operator: , [7220,7221]
operator: , [7220,7221]
===
match
---
name: integration [3802,3813]
name: integration [3802,3813]
===
match
---
trailer [4336,4351]
trailer [4336,4351]
===
match
---
name: signal [21586,21592]
name: signal [22963,22969]
===
match
---
operator: = [17661,17662]
operator: = [19038,19039]
===
match
---
simple_stmt [1373,1412]
simple_stmt [1373,1412]
===
match
---
simple_stmt [13079,13130]
simple_stmt [13079,13130]
===
match
---
trailer [14213,14219]
trailer [14213,14219]
===
match
---
operator: = [2410,2411]
operator: = [2410,2411]
===
match
---
classdef [16363,16922]
classdef [17740,18299]
===
match
---
expr_stmt [15508,15580]
expr_stmt [15508,15580]
===
match
---
operator: , [7403,7404]
operator: , [7403,7404]
===
match
---
number: 0 [10406,10407]
number: 0 [10406,10407]
===
match
---
import_name [817,826]
import_name [817,826]
===
match
---
file_input [787,22290]
file_input [787,23667]
===
match
---
expr_stmt [2402,2466]
expr_stmt [2402,2466]
===
match
---
param [3578,3582]
param [3578,3582]
===
match
---
assert_stmt [6393,6427]
assert_stmt [6393,6427]
===
match
---
name: task [14097,14101]
name: task [14097,14101]
===
match
---
simple_stmt [8617,8639]
simple_stmt [8617,8639]
===
match
---
name: mock [12186,12190]
name: mock [12186,12190]
===
match
---
trailer [13387,13389]
trailer [13387,13389]
===
match
---
trailer [3731,3733]
trailer [3731,3733]
===
match
---
name: cm [18332,18334]
name: cm [19709,19711]
===
match
---
atom_expr [16700,16718]
atom_expr [18077,18095]
===
match
---
name: celery_executor [1549,1564]
name: celery_executor [1549,1564]
===
match
---
funcdef [10652,11131]
funcdef [10652,11131]
===
match
---
fstring_string: ). [9840,9842]
fstring_string: ). [9840,9842]
===
match
---
suite [8251,10572]
suite [8251,10572]
===
match
---
parameters [20902,20925]
parameters [22279,22302]
===
match
---
dotted_name [1378,1399]
dotted_name [1378,1399]
===
match
---
trailer [11748,11765]
trailer [11748,11765]
===
match
---
name: app [18674,18677]
name: app [20051,20054]
===
match
---
operator: = [4062,4063]
operator: = [4062,4063]
===
match
---
simple_stmt [12697,12738]
simple_stmt [12697,12738]
===
match
---
name: execute_date [4960,4972]
name: execute_date [4960,4972]
===
match
---
string: "mysql" [7825,7832]
string: "mysql" [7825,7832]
===
match
---
name: str [16700,16703]
name: str [18077,18080]
===
match
---
dotted_name [19745,19768]
dotted_name [21122,21145]
===
match
---
parameters [16307,16309]
parameters [17684,17686]
===
match
---
name: mark [17182,17186]
name: mark [18559,18563]
===
match
---
comparison [16059,16142]
comparison [16059,16142]
===
match
---
trailer [10414,10437]
trailer [10414,10437]
===
match
---
trailer [8011,8013]
trailer [8011,8013]
===
match
---
atom_expr [6443,6460]
atom_expr [6443,6460]
===
match
---
atom [11539,11723]
atom [11539,11723]
===
match
---
fstring_end: " [16720,16721]
fstring_end: " [18097,18098]
===
match
---
comparison [14369,14405]
comparison [14369,14405]
===
match
---
atom [17083,17122]
atom [18460,18499]
===
match
---
atom_expr [17072,17123]
atom_expr [18449,18500]
===
match
---
fstring_end: " [21054,21055]
fstring_end: " [22431,22432]
===
match
---
operator: , [7379,7380]
operator: , [7379,7380]
===
match
---
atom_expr [16762,16776]
atom_expr [18139,18153]
===
match
---
trailer [15225,15232]
trailer [15225,15232]
===
match
---
atom [11811,11819]
atom [11811,11819]
===
match
---
assert_stmt [16151,16178]
assert_stmt [16151,16178]
===
match
---
simple_stmt [16400,16506]
simple_stmt [17777,17883]
===
match
---
param [17302,17311]
param [18679,18688]
===
match
---
name: __name__ [16689,16697]
name: __name__ [18066,18074]
===
match
---
name: _exit_gracefully [20950,20966]
name: _exit_gracefully [22327,22343]
===
match
---
name: output [20719,20725]
name: output [22096,22102]
===
match
---
atom_expr [10787,10819]
atom_expr [10787,10819]
===
match
---
name: test_app [2874,2882]
name: test_app [2874,2882]
===
match
---
funcdef [17261,18342]
funcdef [18638,19719]
===
match
---
name: task_adoption_timeout [6473,6494]
name: task_adoption_timeout [6473,6494]
===
match
---
name: timezone [15157,15165]
name: timezone [15157,15165]
===
match
---
atom [16269,16271]
atom [16269,16271]
===
match
---
atom_expr [8275,8307]
atom_expr [8275,8307]
===
match
---
atom_expr [17999,18011]
atom_expr [19376,19388]
===
match
---
arith_expr [14856,14900]
arith_expr [14856,14900]
===
match
---
name: parameterized [1358,1371]
name: parameterized [1358,1371]
===
match
---
operator: , [15639,15640]
operator: , [15639,15640]
===
match
---
operator: == [8416,8418]
operator: == [8416,8418]
===
match
---
atom [7664,7699]
atom [7664,7699]
===
match
---
name: executor [10073,10081]
name: executor [10073,10081]
===
match
---
trailer [6062,6066]
trailer [6062,6066]
===
match
---
string: "DEBUG" [17621,17628]
string: "DEBUG" [18998,19005]
===
match
---
name: pytest [10578,10584]
name: pytest [10578,10584]
===
match
---
atom [15965,16019]
atom [15965,16019]
===
match
---
name: task_1 [13296,13302]
name: task_1 [13296,13302]
===
match
---
name: event_buffer [7651,7663]
name: event_buffer [7651,7663]
===
match
---
name: mock_session [18587,18599]
name: mock_session [19964,19976]
===
match
---
funcdef [6625,7720]
funcdef [6625,7720]
===
match
---
simple_stmt [19916,19968]
simple_stmt [21293,21345]
===
match
---
name: dag_id [7079,7085]
name: dag_id [7079,7085]
===
match
---
argument [8565,8590]
argument [8565,8590]
===
match
---
name: try_number [14575,14585]
name: try_number [14575,14585]
===
match
---
name: integration [6513,6524]
name: integration [6513,6524]
===
match
---
argument [20164,20177]
argument [21541,21554]
===
match
---
operator: == [16081,16083]
operator: == [16081,16083]
===
match
---
trailer [21578,21585]
trailer [22955,22962]
===
match
---
name: mock [11609,11613]
name: mock [11609,11613]
===
match
---
name: ti1 [13913,13916]
name: ti1 [13913,13916]
===
match
---
operator: @ [7725,7726]
operator: @ [7725,7726]
===
match
---
name: executor [9042,9050]
name: executor [9042,9050]
===
match
---
trailer [9578,9601]
trailer [9578,9601]
===
match
---
atom_expr [10990,11068]
atom_expr [10990,11068]
===
match
---
atom_expr [19288,19477]
atom_expr [20665,20854]
===
match
---
atom_expr [14619,14629]
atom_expr [14619,14629]
===
match
---
trailer [5413,5418]
trailer [5413,5418]
===
match
---
comparison [20519,20581]
comparison [21896,21958]
===
match
---
trailer [6182,6190]
trailer [6182,6190]
===
match
---
arith_expr [14791,14835]
arith_expr [14791,14835]
===
match
---
operator: == [8357,8359]
operator: == [8357,8359]
===
match
---
arglist [20347,20377]
arglist [21724,21754]
===
match
---
simple_stmt [19022,19217]
simple_stmt [20399,20594]
===
match
---
operator: { [9256,9257]
operator: { [9256,9257]
===
match
---
name: task_adoption_timeout [15800,15821]
name: task_adoption_timeout [15800,15821]
===
match
---
name: broker_url [2338,2348]
name: broker_url [2338,2348]
===
match
---
param [16530,16538]
param [17907,17915]
===
match
---
name: task_1 [13766,13772]
name: task_1 [13766,13772]
===
match
---
trailer [21585,21613]
trailer [22962,22990]
===
match
---
number: 0 [7405,7406]
number: 0 [7405,7406]
===
match
---
name: start_date [13881,13891]
name: start_date [13881,13891]
===
match
---
atom [15034,15036]
atom [15034,15036]
===
match
---
suite [20743,20944]
suite [22120,22321]
===
match
---
trailer [11122,11129]
trailer [11122,11129]
===
match
---
operator: = [20255,20256]
operator: = [21632,21633]
===
match
---
parameters [11385,11440]
parameters [11385,11440]
===
match
---
testlist_comp [7665,7698]
testlist_comp [7665,7698]
===
match
---
atom_expr [14469,14507]
atom_expr [14469,14507]
===
match
---
name: executor [14805,14813]
name: executor [14805,14813]
===
match
---
string: "SUCCESS" [17094,17103]
string: "SUCCESS" [18471,18480]
===
match
---
atom [14700,14714]
atom [14700,14714]
===
match
---
atom_expr [20992,21003]
atom_expr [22369,22380]
===
match
---
param [19868,19872]
param [21245,21249]
===
match
---
name: mock [11586,11590]
name: mock [11586,11590]
===
match
---
atom_expr [18658,18716]
atom_expr [20035,20093]
===
match
---
dotted_name [19707,19730]
dotted_name [21084,21107]
===
match
---
name: cm [19691,19693]
name: cm [21068,21070]
===
match
---
import_name [1029,1042]
import_name [1029,1042]
===
match
---
name: test_retry_on_error_sending_task [7854,7886]
name: test_retry_on_error_sending_task [7854,7886]
===
match
---
string: 'CELERY_BROKER_URLS' [1957,1977]
string: 'CELERY_BROKER_URLS' [1957,1977]
===
match
---
simple_stmt [4564,5198]
simple_stmt [4564,5198]
===
match
---
name: task_id [13788,13795]
name: task_id [13788,13795]
===
match
---
expr_stmt [13913,13957]
expr_stmt [13913,13957]
===
match
---
atom_expr [12914,12933]
atom_expr [12914,12933]
===
match
---
atom [12938,12971]
atom [12938,12971]
===
match
---
name: orig_sigusr2 [21443,21455]
name: orig_sigusr2 [22820,22832]
===
match
---
atom_expr [7569,7590]
atom_expr [7569,7590]
===
match
---
trailer [3285,3299]
trailer [3285,3299]
===
match
---
return_stmt [16653,16721]
return_stmt [18030,18098]
===
match
---
name: key1 [13332,13336]
name: key1 [13332,13336]
===
match
---
operator: { [14439,14440]
operator: { [14439,14440]
===
match
---
name: mark [7733,7737]
name: mark [7733,7737]
===
match
---
simple_stmt [1677,1767]
simple_stmt [1677,1767]
===
match
---
name: key_1 [15770,15775]
name: key_1 [15770,15775]
===
match
---
atom_expr [22165,22216]
atom_expr [23542,23593]
===
match
---
trailer [19129,19198]
trailer [20506,20575]
===
match
---
name: mock_session [19022,19034]
name: mock_session [20399,20411]
===
match
---
number: 0 [6167,6168]
number: 0 [6167,6168]
===
match
---
atom_expr [3544,3561]
atom_expr [3544,3561]
===
match
---
dictorsetmaker [9964,9970]
dictorsetmaker [9964,9970]
===
match
---
operator: = [14101,14102]
operator: = [14101,14102]
===
match
---
expr_stmt [14244,14260]
expr_stmt [14244,14260]
===
match
---
name: cm [20716,20718]
name: cm [22093,22095]
===
match
---
name: asynchronous [1297,1309]
name: asynchronous [1297,1309]
===
match
---
operator: == [20713,20715]
operator: == [22090,22092]
===
match
---
atom_expr [15856,15886]
atom_expr [15856,15886]
===
match
---
name: output [10271,10277]
name: output [10271,10277]
===
match
---
trailer [7313,7337]
trailer [7313,7337]
===
match
---
string: 'airflow' [3988,3997]
string: 'airflow' [3988,3997]
===
match
---
atom [14250,14260]
atom [14250,14260]
===
match
---
number: 1 [16359,16360]
number: 1 [17736,17737]
===
match
---
dotted_name [21713,21736]
dotted_name [23090,23113]
===
match
---
simple_stmt [2338,2398]
simple_stmt [2338,2398]
===
match
---
string: "redis" [17161,17168]
string: "redis" [18538,18545]
===
match
---
operator: , [7397,7398]
operator: , [7397,7398]
===
match
---
operator: , [20554,20555]
operator: , [21931,21932]
===
match
---
name: test_command_validation [11923,11946]
name: test_command_validation [11923,11946]
===
match
---
name: _prepare_app [19888,19900]
name: _prepare_app [21265,21277]
===
match
---
testlist_comp [12938,12972]
testlist_comp [12938,12972]
===
match
---
atom_expr [6177,6190]
atom_expr [6177,6190]
===
match
---
name: models [1690,1696]
name: models [1690,1696]
===
match
---
name: task [21921,21925]
name: task [23298,23302]
===
match
---
name: task_publish_retries [9517,9537]
name: task_publish_retries [9517,9537]
===
match
---
simple_stmt [9463,9484]
simple_stmt [9463,9484]
===
match
---
name: TaskInstance [7301,7313]
name: TaskInstance [7301,7313]
===
match
---
operator: , [4940,4941]
operator: , [4940,4941]
===
match
---
atom_expr [14222,14234]
atom_expr [14222,14234]
===
match
---
name: pytest [15043,15049]
name: pytest [15043,15049]
===
match
---
trailer [12485,12505]
trailer [12485,12505]
===
match
---
trailer [5605,5611]
trailer [5605,5611]
===
match
---
operator: , [8692,8693]
operator: , [8692,8693]
===
match
---
operator: = [11537,11538]
operator: = [11537,11538]
===
match
---
operator: } [9418,9419]
operator: } [9418,9419]
===
match
---
string: "postgres" [19815,19825]
string: "postgres" [21192,21202]
===
match
---
string: 'fake_simple_ti' [5855,5871]
string: 'fake_simple_ti' [5855,5871]
===
match
---
operator: , [8851,8852]
operator: , [8851,8852]
===
match
---
trailer [21471,21505]
trailer [22848,22882]
===
match
---
suite [3418,3517]
suite [3418,3517]
===
match
---
name: ti2 [14078,14081]
name: ti2 [14078,14081]
===
match
---
operator: = [14523,14524]
operator: = [14523,14524]
===
match
---
atom_expr [21405,21419]
atom_expr [22782,22796]
===
match
---
string: "Task should no longer be queued" [7593,7626]
string: "Task should no longer be queued" [7593,7626]
===
match
---
operator: , [11870,11871]
operator: , [11870,11871]
===
match
---
name: executor [9158,9166]
name: executor [9158,9166]
===
match
---
decorator [7804,7846]
decorator [7804,7846]
===
match
---
with_item [4235,4296]
with_item [4235,4296]
===
match
---
decorator [13457,13499]
decorator [13457,13499]
===
match
---
expr_stmt [21872,21915]
expr_stmt [23249,23292]
===
match
---
trailer [16826,16835]
trailer [18203,18212]
===
match
---
string: "mysql" [18521,18528]
string: "mysql" [19898,19905]
===
match
---
dictorsetmaker [19158,19195]
dictorsetmaker [20535,20572]
===
match
---
name: bash [1790,1794]
name: bash [1790,1794]
===
match
---
trailer [5890,5893]
trailer [5890,5893]
===
match
---
operator: = [7041,7042]
operator: = [7041,7042]
===
match
---
atom [15756,15897]
atom [15756,15897]
===
match
---
name: signum [21047,21053]
name: signum [22424,22430]
===
match
---
name: BashOperator [8476,8488]
name: BashOperator [8476,8488]
===
match
---
name: mark [3797,3801]
name: mark [3797,3801]
===
match
---
name: celery [986,992]
name: celery [986,992]
===
match
---
argument [13863,13879]
argument [13863,13879]
===
match
---
atom_expr [15973,15991]
atom_expr [15973,15991]
===
match
---
simple_stmt [14244,14261]
simple_stmt [14244,14261]
===
match
---
operator: == [16356,16358]
operator: == [17733,17735]
===
match
---
dotted_name [986,1014]
dotted_name [986,1014]
===
match
---
dictorsetmaker [14701,14713]
dictorsetmaker [14701,14713]
===
match
---
name: pytest [17137,17143]
name: pytest [18514,18520]
===
match
---
argument [17786,17799]
argument [19163,19176]
===
match
---
atom_expr [4406,4422]
atom_expr [4406,4422]
===
match
---
trailer [8550,8563]
trailer [8550,8563]
===
match
---
suite [15348,15499]
suite [15348,15499]
===
match
---
simple_stmt [7524,7545]
simple_stmt [7524,7545]
===
match
---
name: BulkStateFetcher [19244,19260]
name: BulkStateFetcher [20621,20637]
===
match
---
simple_stmt [5467,5506]
simple_stmt [5467,5506]
===
match
---
comparison [9991,10022]
comparison [9991,10022]
===
match
---
name: assertLogs [20099,20109]
name: assertLogs [21476,21486]
===
match
---
simple_stmt [18951,19006]
simple_stmt [20328,20383]
===
match
---
number: 0 [6171,6172]
number: 0 [6171,6172]
===
match
---
atom [3987,4040]
atom [3987,4040]
===
match
---
decorator [10606,10648]
decorator [10606,10648]
===
match
---
operator: @ [2258,2259]
operator: @ [2258,2259]
===
match
---
assert_stmt [14321,14353]
assert_stmt [14321,14353]
===
match
---
name: mark [6546,6550]
name: mark [6546,6550]
===
match
---
atom_expr [11084,11130]
atom_expr [11084,11130]
===
match
---
atom [22244,22259]
atom [23621,23636]
===
match
---
name: line [11103,11107]
name: line [11103,11107]
===
match
---
atom_expr [9231,9252]
atom_expr [9231,9252]
===
match
---
name: CeleryExecutor [11477,11491]
name: CeleryExecutor [11477,11491]
===
match
---
trailer [15550,15558]
trailer [15550,15558]
===
match
---
assert_stmt [20590,20725]
assert_stmt [21967,22102]
===
match
---
operator: , [7832,7833]
operator: , [7832,7833]
===
match
---
classdef [3519,16272]
classdef [3519,17649]
===
match
---
operator: , [8420,8421]
operator: , [8420,8421]
===
match
---
name: cm [10268,10270]
name: cm [10268,10270]
===
match
---
number: 1 [13688,13689]
number: 1 [13688,13689]
===
match
---
name: start [4415,4420]
name: start [4415,4420]
===
match
---
atom_expr [5592,5619]
atom_expr [5592,5619]
===
match
---
name: output [9850,9856]
name: output [9850,9856]
===
match
---
name: queued_dttm [15203,15214]
name: queued_dttm [15203,15214]
===
match
---
number: 2 [13127,13128]
number: 2 [13127,13128]
===
match
---
simple_stmt [16755,16777]
simple_stmt [18132,18154]
===
match
---
operator: , [6454,6455]
operator: , [6454,6455]
===
match
---
operator: , [14573,14574]
operator: , [14573,14574]
===
match
---
name: test_app [2584,2592]
name: test_app [2584,2592]
===
match
---
testlist_comp [11835,11869]
testlist_comp [11835,11869]
===
match
---
decorated [3739,6495]
decorated [3739,6495]
===
match
---
string: "DEBUG" [20170,20177]
string: "DEBUG" [21547,21554]
===
match
---
atom [15925,15939]
atom [15925,15939]
===
match
---
name: queued_tasks [9167,9179]
name: queued_tasks [9167,9179]
===
match
---
trailer [17998,18012]
trailer [19375,19389]
===
match
---
operator: } [4392,4393]
operator: } [4392,4393]
===
match
---
operator: , [4461,4462]
operator: , [4461,4462]
===
match
---
parameters [21116,21118]
parameters [22493,22495]
===
match
---
name: start_date [7093,7103]
name: start_date [7093,7103]
===
match
---
operator: } [10260,10261]
operator: } [10260,10261]
===
match
---
import_name [805,816]
import_name [805,816]
===
match
---
atom_expr [18615,18629]
atom_expr [19992,20006]
===
match
---
trailer [4453,4499]
trailer [4453,4499]
===
match
---
suite [2145,2256]
suite [2145,2256]
===
match
---
for_stmt [22016,22290]
for_stmt [23393,23667]
===
match
---
arglist [7034,7118]
arglist [7034,7118]
===
match
---
expr_stmt [7473,7511]
expr_stmt [7473,7511]
===
match
---
argument [20362,20377]
argument [21739,21754]
===
match
---
atom_expr [3761,3783]
atom_expr [3761,3783]
===
match
---
atom_expr [12472,12505]
atom_expr [12472,12505]
===
match
---
number: 2 [13600,13601]
number: 2 [13600,13601]
===
match
---
operator: , [11883,11884]
operator: , [11883,11884]
===
match
---
name: _exit_gracefully [21488,21504]
name: _exit_gracefully [22865,22881]
===
match
---
decorator [6579,6621]
decorator [6579,6621]
===
match
---
simple_stmt [7179,7354]
simple_stmt [7179,7354]
===
match
---
suite [3374,3402]
suite [3374,3402]
===
match
---
operator: , [11951,11952]
operator: , [11951,11952]
===
match
---
trailer [16766,16774]
trailer [18143,18151]
===
match
---
name: now [7161,7164]
name: now [7161,7164]
===
match
---
name: task [7319,7323]
name: task [7319,7323]
===
match
---
simple_stmt [9142,9212]
simple_stmt [9142,9212]
===
match
---
arglist [20110,20177]
arglist [21487,21554]
===
match
---
expr_stmt [4049,4086]
expr_stmt [4049,4086]
===
match
---
with_item [13704,13752]
with_item [13704,13752]
===
match
---
operator: = [17070,17071]
operator: = [18447,18448]
===
match
---
name: run_id [8797,8803]
name: run_id [8797,8803]
===
match
---
parameters [6652,6658]
parameters [6652,6658]
===
match
---
name: mock_backend [18815,18827]
name: mock_backend [20192,20204]
===
match
---
trailer [2037,2059]
trailer [2037,2059]
===
match
---
strings [9296,9422]
strings [9296,9422]
===
match
---
operator: == [10408,10410]
operator: == [10408,10410]
===
match
---
trailer [16217,16219]
trailer [16217,16219]
===
match
---
funcdef [2285,3517]
funcdef [2285,3517]
===
match
---
trailer [19040,19053]
trailer [20417,20430]
===
match
---
name: line [11112,11116]
name: line [11112,11116]
===
match
---
expr_stmt [14595,14664]
expr_stmt [14595,14664]
===
match
---
testlist_comp [4634,4863]
testlist_comp [4634,4863]
===
match
---
import_from [1815,1849]
import_from [1815,1849]
===
match
---
simple_stmt [9271,9450]
simple_stmt [9271,9450]
===
match
---
name: call [11614,11618]
name: call [11614,11618]
===
match
---
string: 'executor.running_tasks' [11677,11701]
string: 'executor.running_tasks' [11677,11701]
===
match
---
fstring_start: f" [10211,10213]
fstring_start: f" [10211,10213]
===
match
---
string: "redis" [19731,19738]
string: "redis" [21108,21115]
===
match
---
operator: , [16134,16135]
operator: , [16134,16135]
===
match
---
with_item [12186,12285]
with_item [12186,12285]
===
match
---
dotted_name [17216,17235]
dotted_name [18593,18612]
===
match
---
operator: , [8875,8876]
operator: , [8875,8876]
===
match
---
simple_stmt [13271,13317]
simple_stmt [13271,13317]
===
match
---
atom_expr [5523,5567]
atom_expr [5523,5567]
===
match
---
name: task [13932,13936]
name: task [13932,13936]
===
match
---
name: value_tuple [8921,8932]
name: value_tuple [8921,8932]
===
match
---
testlist_comp [4065,4085]
testlist_comp [4065,4085]
===
match
---
string: 'success' [5844,5853]
string: 'success' [5844,5853]
===
match
---
expr_stmt [7420,7460]
expr_stmt [7420,7460]
===
match
---
trailer [18858,18927]
trailer [20235,20304]
===
match
---
name: datetime [13092,13100]
name: datetime [13092,13100]
===
match
---
expr_stmt [8838,8879]
expr_stmt [8838,8879]
===
match
---
argument [13945,13956]
argument [13945,13956]
===
match
---
or_test [2351,2397]
or_test [2351,2397]
===
match
---
operator: ** [16530,16532]
operator: ** [17907,17909]
===
match
---
dictorsetmaker [18017,18065]
dictorsetmaker [19394,19442]
===
match
---
name: airflow [1378,1385]
name: airflow [1378,1385]
===
match
---
operator: , [3946,3947]
operator: , [3946,3947]
===
match
---
operator: - [13583,13584]
operator: - [13583,13584]
===
match
---
name: state [14214,14219]
name: state [14214,14219]
===
match
---
trailer [3690,3704]
trailer [3690,3704]
===
match
---
name: signal [21625,21631]
name: signal [23002,23008]
===
match
---
simple_stmt [1286,1332]
simple_stmt [1286,1332]
===
match
---
operator: = [3276,3277]
operator: = [3276,3277]
===
match
---
argument [7079,7090]
argument [7079,7090]
===
match
---
name: property [2151,2159]
name: property [2151,2159]
===
match
---
string: 'true' [11812,11818]
string: 'true' [11812,11818]
===
match
---
string: 'fail' [7665,7671]
string: 'fail' [7665,7671]
===
match
---
argument [13122,13128]
argument [13122,13128]
===
match
---
name: backend [19798,19805]
name: backend [21175,21182]
===
match
---
string: '123' [20530,20535]
string: '123' [21907,21912]
===
match
---
name: queue [5335,5340]
name: queue [5335,5340]
===
match
---
simple_stmt [14723,14912]
simple_stmt [14723,14912]
===
match
---
name: test_app [3393,3401]
name: test_app [3393,3401]
===
match
---
atom [5799,5927]
atom [5799,5927]
===
match
---
atom_expr [22000,22009]
atom_expr [23377,23386]
===
match
---
suite [16540,16621]
suite [17917,17998]
===
match
---
string: "abcdef-124215-abcdef" [12868,12890]
string: "abcdef-124215-abcdef" [12868,12890]
===
match
---
funcdef [11354,11773]
funcdef [11354,11773]
===
match
---
comparison [13406,13451]
comparison [13406,13451]
===
match
---
string: "__enter__" [8184,8195]
string: "__enter__" [8184,8195]
===
match
---
raise_stmt [2189,2206]
raise_stmt [2189,2206]
===
match
---
operator: @ [12979,12980]
operator: @ [12979,12980]
===
match
---
operator: @ [19744,19745]
operator: @ [21121,21122]
===
match
---
trailer [5959,5972]
trailer [5959,5972]
===
match
---
operator: { [17083,17084]
operator: { [18460,18461]
===
match
---
name: signal [21673,21679]
name: signal [23050,23056]
===
match
---
name: test_should_support_kv_backend [17265,17295]
name: test_should_support_kv_backend [18642,18672]
===
match
---
suite [2230,2256]
suite [2230,2256]
===
match
---
name: set_event_loop [1317,1331]
name: set_event_loop [1317,1331]
===
match
---
dotted_name [18422,18445]
dotted_name [19799,19822]
===
match
---
simple_stmt [4517,4547]
simple_stmt [4517,4547]
===
match
---
fstring_expr [20991,21004]
fstring_expr [22368,22381]
===
match
---
name: State [6279,6284]
name: State [6279,6284]
===
match
---
name: mock [11137,11141]
name: mock [11137,11141]
===
match
---
name: executor [14870,14878]
name: executor [14870,14878]
===
match
---
decorated [21080,21710]
decorated [22457,23087]
===
match
---
param [2319,2331]
param [2319,2331]
===
match
---
atom_expr [2085,2117]
atom_expr [2085,2117]
===
match
---
operator: , [16607,16608]
operator: , [17984,17985]
===
match
---
string: 'SUCCESS' [20538,20547]
string: 'SUCCESS' [21915,21924]
===
match
---
operator: , [21971,21972]
operator: , [23348,23349]
===
match
---
atom_expr [13208,13261]
atom_expr [13208,13261]
===
match
---
trailer [10957,10963]
trailer [10957,10963]
===
match
---
number: 0 [5754,5755]
number: 0 [5754,5755]
===
match
---
operator: , [20914,20915]
operator: , [22291,22292]
===
match
---
operator: , [1749,1750]
operator: , [1749,1750]
===
match
---
name: key [7503,7506]
name: key [7503,7506]
===
match
---
trailer [20346,20378]
trailer [21723,21755]
===
match
---
name: command [4146,4153]
name: command [4146,4153]
===
match
---
trailer [9587,9600]
trailer [9587,9600]
===
match
---
name: tis [13325,13328]
name: tis [13325,13328]
===
match
---
name: __dict__ [16827,16835]
name: __dict__ [18204,18212]
===
match
---
operator: { [16084,16085]
operator: { [16084,16085]
===
match
---
name: taskinstance [1697,1709]
name: taskinstance [1697,1709]
===
match
---
simple_stmt [21572,21614]
simple_stmt [22949,22991]
===
match
---
name: integration [18434,18445]
name: integration [19811,19822]
===
match
---
operator: , [14971,14972]
operator: , [14971,14972]
===
match
---
comparison [9924,9971]
comparison [9924,9971]
===
match
---
argument [13881,13902]
argument [13881,13902]
===
match
---
simple_stmt [1767,1815]
simple_stmt [1767,1815]
===
match
---
funcdef [16511,16621]
funcdef [17888,17998]
===
match
---
string: "sqlite3://" [18703,18715]
string: "sqlite3://" [20080,20092]
===
match
---
name: _ [22020,22021]
name: _ [23397,23398]
===
match
---
operator: = [7150,7151]
operator: = [7150,7151]
===
match
---
operator: @ [3827,3828]
operator: @ [3827,3828]
===
match
---
operator: , [4862,4863]
operator: , [4862,4863]
===
match
---
string: 'DEBUG:airflow.executors.celery_executor.BulkStateFetcher:Fetched 2 state(s) for 2 task(s)' [19586,19677]
string: 'DEBUG:airflow.executors.celery_executor.BulkStateFetcher:Fetched 2 state(s) for 2 task(s)' [20963,21054]
===
match
---
name: datetime [8576,8584]
name: datetime [8576,8584]
===
match
---
simple_stmt [4366,4394]
simple_stmt [4366,4394]
===
match
---
atom_expr [17771,17800]
atom_expr [19148,19177]
===
match
---
dotted_name [13458,13477]
dotted_name [13458,13477]
===
match
---
simple_stmt [20748,20882]
simple_stmt [22125,22259]
===
match
---
trailer [16036,16041]
trailer [16036,16041]
===
match
---
name: signum [21070,21076]
name: signum [22447,22453]
===
match
---
comparison [6308,6339]
comparison [6308,6339]
===
match
---
name: QUEUED [14228,14234]
name: QUEUED [14228,14234]
===
match
---
classdef [2122,2256]
classdef [2122,2256]
===
match
---
operator: == [9674,9676]
operator: == [9674,9676]
===
match
---
assert_stmt [10487,10571]
assert_stmt [10487,10571]
===
match
---
name: __eq__ [16908,16914]
name: __eq__ [18285,18291]
===
match
---
trailer [2601,2640]
trailer [2601,2640]
===
match
---
testlist_comp [17771,17856]
testlist_comp [19148,19233]
===
match
---
operator: , [8057,8058]
operator: , [8057,8058]
===
match
---
operator: = [18677,18678]
operator: = [20054,20055]
===
match
---
string: "456" [19430,19435]
string: "456" [20807,20812]
===
match
---
string: "airflow.executors.celery_executor.BulkStateFetcher" [18859,18911]
string: "airflow.executors.celery_executor.BulkStateFetcher" [20236,20288]
===
match
---
trailer [5475,5496]
trailer [5475,5496]
===
match
---
name: mark [6587,6591]
name: mark [6587,6591]
===
match
---
decorators [19706,19827]
decorators [21083,21204]
===
match
---
comparison [14730,14911]
comparison [14730,14911]
===
match
---
name: signal [21472,21478]
name: signal [22849,22855]
===
match
---
simple_stmt [21124,21243]
simple_stmt [22501,22620]
===
match
---
trailer [4544,4546]
trailer [4544,4546]
===
match
---
name: DAG [15297,15300]
name: DAG [15297,15300]
===
match
---
atom [4391,4393]
atom [4391,4393]
===
match
---
arglist [15383,15422]
arglist [15383,15422]
===
match
---
expr_stmt [21921,21938]
expr_stmt [23298,23315]
===
match
---
trailer [3603,3617]
trailer [3603,3617]
===
match
---
atom_expr [2874,2890]
atom_expr [2874,2890]
===
match
---
funcdef [20946,21078]
funcdef [22323,22455]
===
match
---
trailer [14813,14835]
trailer [14813,14835]
===
match
---
name: clear_db_jobs [3718,3731]
name: clear_db_jobs [3718,3731]
===
match
---
dotted_name [7805,7824]
dotted_name [7805,7824]
===
match
---
name: task_2 [14631,14637]
name: task_2 [14631,14637]
===
match
---
arglist [21405,21437]
arglist [22782,22814]
===
match
---
atom_expr [2365,2397]
atom_expr [2365,2397]
===
match
---
expr_stmt [21376,21438]
expr_stmt [22753,22815]
===
match
---
name: ti2 [14131,14134]
name: ti2 [14131,14134]
===
match
---
name: _prepare_app [7999,8011]
name: _prepare_app [7999,8011]
===
match
---
atom_expr [9929,9958]
atom_expr [9929,9958]
===
match
---
string: 'airflow' [11874,11883]
string: 'airflow' [11874,11883]
===
match
---
name: executor [7524,7532]
name: executor [7524,7532]
===
match
---
name: pytest [19786,19792]
name: pytest [21163,21169]
===
match
---
if_stmt [2896,3326]
if_stmt [2896,3326]
===
match
---
name: autospec [19946,19954]
name: autospec [21323,21331]
===
match
---
trailer [10840,10846]
trailer [10840,10846]
===
match
---
trailer [12291,12297]
trailer [12291,12297]
===
match
---
name: parameterized [1337,1350]
name: parameterized [1337,1350]
===
match
---
atom_expr [14735,14765]
atom_expr [14735,14765]
===
match
---
name: AirflowTaskTimeout [1461,1479]
name: AirflowTaskTimeout [1461,1479]
===
match
---
testlist_comp [20564,20579]
testlist_comp [21941,21956]
===
match
---
suite [3361,3517]
suite [3361,3517]
===
match
---
atom_expr [21391,21438]
atom_expr [22768,22815]
===
match
---
string: 'command' [8683,8692]
string: 'command' [8683,8692]
===
match
---
name: airflow [1531,1538]
name: airflow [1531,1538]
===
match
---
name: expand [3754,3760]
name: expand [3754,3760]
===
match
---
trailer [12660,12662]
trailer [12660,12662]
===
match
---
with_item [10720,10762]
with_item [10720,10762]
===
match
---
operator: + [15854,15855]
operator: + [15854,15855]
===
match
---
name: close [3318,3323]
name: close [3318,3323]
===
match
---
simple_stmt [1069,1140]
simple_stmt [1069,1140]
===
match
---
name: output [19694,19700]
name: output [21071,21077]
===
match
---
name: results [22155,22162]
name: results [23532,23539]
===
match
---
string: "mysql" [15063,15070]
string: "mysql" [15063,15070]
===
match
---
string: "status" [19158,19166]
string: "status" [20535,20543]
===
match
---
name: patch [8064,8069]
name: patch [8064,8069]
===
match
---
testlist_comp [11836,11856]
testlist_comp [11836,11856]
===
match
---
name: mock_subproc [12810,12822]
name: mock_subproc [12810,12822]
===
match
---
name: CeleryExecutor [8291,8305]
name: CeleryExecutor [8291,8305]
===
match
---
decorator [18347,18417]
decorator [19724,19794]
===
match
---
dictorsetmaker [9543,9549]
dictorsetmaker [9543,9549]
===
match
---
decorators [3739,3910]
decorators [3739,3910]
===
match
---
number: 1 [22257,22258]
number: 1 [23634,23635]
===
match
---
name: signal [21618,21624]
name: signal [22995,23001]
===
match
---
trailer [6982,6984]
trailer [6982,6984]
===
match
---
sync_comp_for [22260,22288]
sync_comp_for [23637,23665]
===
match
---
param [7887,7891]
param [7887,7891]
===
match
---
operator: -> [3671,3673]
operator: -> [3671,3673]
===
match
---
name: executor [11502,11510]
name: executor [11502,11510]
===
match
---
parameters [16869,16882]
parameters [18246,18259]
===
match
---
number: 0 [7560,7561]
number: 0 [7560,7561]
===
match
---
atom_expr [20716,20725]
atom_expr [22093,22102]
===
match
---
assert_stmt [17988,18066]
assert_stmt [19365,19443]
===
match
---
assert_stmt [18206,18341]
assert_stmt [19583,19718]
===
match
---
name: call [11558,11562]
name: call [11558,11562]
===
match
---
name: return_value [19061,19073]
name: return_value [20438,20450]
===
match
---
import_from [1412,1479]
import_from [1412,1479]
===
match
---
name: sync [16037,16041]
name: sync [16037,16041]
===
match
---
import_as_names [889,908]
import_as_names [889,908]
===
match
---
trailer [14544,14551]
trailer [14544,14551]
===
match
---
atom_expr [7420,7446]
atom_expr [7420,7446]
===
match
---
name: start_date [13250,13260]
name: start_date [13250,13260]
===
match
---
trailer [15612,15661]
trailer [15612,15661]
===
match
---
expr_stmt [14078,14122]
expr_stmt [14078,14122]
===
match
---
dictorsetmaker [19133,19196]
dictorsetmaker [20510,20573]
===
match
---
name: items [16574,16579]
name: items [17951,17956]
===
match
---
trailer [21592,21599]
trailer [22969,22976]
===
match
---
name: mock_backend [18643,18655]
name: mock_backend [20020,20032]
===
match
---
string: 'fail' [4934,4940]
string: 'fail' [4934,4940]
===
match
---
name: quarantined [21725,21736]
name: quarantined [23102,23113]
===
match
---
operator: , [12971,12972]
operator: , [12971,12972]
===
match
---
trailer [3552,3561]
trailer [3552,3561]
===
match
---
operator: = [7508,7509]
operator: = [7508,7509]
===
match
---
argument [17058,17124]
argument [18435,18501]
===
match
---
simple_stmt [13675,13690]
simple_stmt [13675,13690]
===
match
---
trailer [16579,16581]
trailer [17956,17958]
===
match
---
name: integration [18472,18483]
name: integration [19849,19860]
===
match
---
trailer [19119,19129]
trailer [20496,20506]
===
match
---
operator: { [9835,9836]
operator: { [9835,9836]
===
match
---
trailer [2506,2527]
trailer [2506,2527]
===
match
---
parameters [19867,19873]
parameters [21244,21250]
===
match
---
atom_expr [8476,8604]
atom_expr [8476,8604]
===
match
---
operator: , [20360,20361]
operator: , [21737,21738]
===
match
---
name: executor [16059,16067]
name: executor [16059,16067]
===
match
---
atom [16176,16178]
atom [16176,16178]
===
match
---
operator: , [19381,19382]
operator: , [20758,20759]
===
match
---
suite [11441,11773]
suite [11441,11773]
===
match
---
name: self [17296,17300]
name: self [18673,18677]
===
match
---
name: execute_date [4517,4529]
name: execute_date [4517,4529]
===
match
---
name: state [2168,2173]
name: state [2168,2173]
===
match
---
name: SIGTERM [21639,21646]
name: SIGTERM [23016,23023]
===
match
---
number: 0 [5887,5888]
number: 0 [5887,5888]
===
match
---
name: other [16799,16804]
name: other [18176,18181]
===
match
---
name: executor [10350,10358]
name: executor [10350,10358]
===
match
---
string: 'broker_url' [2553,2565]
string: 'broker_url' [2553,2565]
===
match
---
name: os [824,826]
name: os [824,826]
===
match
---
name: executor [14680,14688]
name: executor [14680,14688]
===
match
---
name: set [14348,14351]
name: set [14348,14351]
===
match
---
simple_stmt [4190,4221]
simple_stmt [4190,4221]
===
match
---
name: key [5321,5324]
name: key [5321,5324]
===
match
---
operator: , [7323,7324]
operator: , [7323,7324]
===
match
---
operator: = [19954,19955]
operator: = [21331,21332]
===
match
---
expr_stmt [2472,2528]
expr_stmt [2472,2528]
===
match
---
atom_expr [8031,8050]
atom_expr [8031,8050]
===
match
---
name: when [8617,8621]
name: when [8617,8621]
===
match
---
atom_expr [13406,13444]
atom_expr [13406,13444]
===
insert-node
---
name: TestCeleryExecutor [3525,3543]
to
classdef [3519,16272]
at 0
===
insert-tree
---
decorated [16277,17649]
    decorator [16277,16319]
        operator: @ [16277,16278]
        dotted_name [16278,16297]
            name: pytest [16278,16284]
            name: mark [16285,16289]
            name: backend [16290,16297]
        arglist [16298,16317]
            string: "mysql" [16298,16305]
            operator: , [16305,16306]
            string: "postgres" [16307,16317]
    funcdef [16323,17649]
        name: test_check_for_stalled_adopted_tasks_goes_in_ordered_fashion [16327,16387]
        parameters [16387,16393]
            param [16388,16392]
                name: self [16388,16392]
        suite [16394,17649]
            simple_stmt [16403,16454]
                expr_stmt [16403,16453]
                    name: start_date [16403,16413]
                    operator: = [16414,16415]
                    arith_expr [16416,16453]
                        atom_expr [16416,16433]
                            name: timezone [16416,16424]
                            trailer [16424,16431]
                                name: utcnow [16425,16431]
                            trailer [16431,16433]
                        operator: - [16434,16435]
                        atom_expr [16436,16453]
                            name: timedelta [16436,16445]
                            trailer [16445,16453]
                                argument [16446,16452]
                                    name: days [16446,16450]
                                    operator: = [16450,16451]
                                    number: 2 [16451,16452]
            simple_stmt [16462,16518]
                expr_stmt [16462,16517]
                    name: queued_dttm [16462,16473]
                    operator: = [16474,16475]
                    arith_expr [16476,16517]
                        atom_expr [16476,16493]
                            name: timezone [16476,16484]
                            trailer [16484,16491]
                                name: utcnow [16485,16491]
                            trailer [16491,16493]
                        operator: - [16494,16495]
                        atom_expr [16496,16517]
                            name: timedelta [16496,16505]
                            trailer [16505,16517]
                                argument [16506,16516]
                                    name: minutes [16506,16513]
                                    operator: = [16513,16514]
                                    number: 30 [16514,16516]
            simple_stmt [16526,16583]
                expr_stmt [16526,16582]
                    name: queued_dttm_2 [16526,16539]
                    operator: = [16540,16541]
                    arith_expr [16542,16582]
                        atom_expr [16542,16559]
                            name: timezone [16542,16550]
                            trailer [16550,16557]
                                name: utcnow [16551,16557]
                            trailer [16557,16559]
                        operator: - [16560,16561]
                        atom_expr [16562,16582]
                            name: timedelta [16562,16571]
                            trailer [16571,16582]
                                argument [16572,16581]
                                    name: minutes [16572,16579]
                                    operator: = [16579,16580]
                                    number: 4 [16580,16581]
            simple_stmt [16592,16607]
                expr_stmt [16592,16606]
                    name: try_number [16592,16602]
                    operator: = [16603,16604]
                    number: 1 [16605,16606]
            with_stmt [16616,16823]
                with_item [16621,16671]
                    atom_expr [16621,16664]
                        name: DAG [16621,16624]
                        trailer [16624,16664]
                            string: "test_check_for_stalled_adopted_tasks" [16625,16663]
                    name: dag [16668,16671]
                suite [16672,16823]
                    simple_stmt [16685,16748]
                        expr_stmt [16685,16747]
                            name: task_1 [16685,16691]
                            operator: = [16692,16693]
                            atom_expr [16694,16747]
                                name: BaseOperator [16694,16706]
                                trailer [16706,16747]
                                    arglist [16707,16746]
                                        argument [16707,16723]
                                            name: task_id [16707,16714]
                                            operator: = [16714,16715]
                                            string: "task_1" [16715,16723]
                                        operator: , [16723,16724]
                                        argument [16725,16746]
                                            name: start_date [16725,16735]
                                            operator: = [16735,16736]
                                            name: start_date [16736,16746]
                    simple_stmt [16760,16823]
                        expr_stmt [16760,16822]
                            name: task_2 [16760,16766]
                            operator: = [16767,16768]
                            atom_expr [16769,16822]
                                name: BaseOperator [16769,16781]
                                trailer [16781,16822]
                                    arglist [16782,16821]
                                        argument [16782,16798]
                                            name: task_id [16782,16789]
                                            operator: = [16789,16790]
                                            string: "task_2" [16790,16798]
                                        operator: , [16798,16799]
                                        argument [16800,16821]
                                            name: start_date [16800,16810]
                                            operator: = [16810,16811]
                                            name: start_date [16811,16821]
            simple_stmt [16832,16905]
                expr_stmt [16832,16904]
                    name: key_1 [16832,16837]
                    operator: = [16838,16839]
                    atom_expr [16840,16904]
                        name: TaskInstanceKey [16840,16855]
                        trailer [16855,16904]
                            arglist [16856,16903]
                                atom_expr [16856,16866]
                                    name: dag [16856,16859]
                                    trailer [16859,16866]
                                        name: dag_id [16860,16866]
                                operator: , [16866,16867]
                                atom_expr [16868,16882]
                                    name: task_1 [16868,16874]
                                    trailer [16874,16882]
                                        name: task_id [16875,16882]
                                operator: , [16882,16883]
                                string: "runid" [16884,16891]
                                operator: , [16891,16892]
                                name: try_number [16893,16903]
            simple_stmt [16913,16986]
                expr_stmt [16913,16985]
                    name: key_2 [16913,16918]
                    operator: = [16919,16920]
                    atom_expr [16921,16985]
                        name: TaskInstanceKey [16921,16936]
                        trailer [16936,16985]
                            arglist [16937,16984]
                                atom_expr [16937,16947]
                                    name: dag [16937,16940]
                                    trailer [16940,16947]
                                        name: dag_id [16941,16947]
                                operator: , [16947,16948]
                                atom_expr [16949,16963]
                                    name: task_2 [16949,16955]
                                    trailer [16955,16963]
                                        name: task_id [16956,16963]
                                operator: , [16963,16964]
                                string: "runid" [16965,16972]
                                operator: , [16972,16973]
                                name: try_number [16974,16984]
            simple_stmt [16995,17039]
                expr_stmt [16995,17038]
                    name: executor [16995,17003]
                    operator: = [17004,17005]
                    atom_expr [17006,17038]
                        name: celery_executor [17006,17021]
                        trailer [17021,17036]
                            name: CeleryExecutor [17022,17036]
                        trailer [17036,17038]
            simple_stmt [17047,17224]
                expr_stmt [17047,17223]
                    atom_expr [17047,17077]
                        name: executor [17047,17055]
                        trailer [17055,17077]
                            name: adopted_task_timeouts [17056,17077]
                    operator: = [17078,17079]
                    atom [17080,17223]
                        operator: { [17080,17081]
                        dictorsetmaker [17094,17213]
                            name: key_2 [17094,17099]
                            arith_expr [17101,17147]
                                name: queued_dttm_2 [17101,17114]
                                operator: + [17115,17116]
                                atom_expr [17117,17147]
                                    name: executor [17117,17125]
                                    trailer [17125,17147]
                                        name: task_adoption_timeout [17126,17147]
                            operator: , [17147,17148]
                            name: key_1 [17161,17166]
                            arith_expr [17168,17212]
                                name: queued_dttm [17168,17179]
                                operator: + [17180,17181]
                                atom_expr [17182,17212]
                                    name: executor [17182,17190]
                                    trailer [17190,17212]
                                        name: task_adoption_timeout [17191,17212]
                            operator: , [17212,17213]
                        operator: } [17222,17223]
            simple_stmt [17232,17266]
                expr_stmt [17232,17265]
                    atom_expr [17232,17248]
                        name: executor [17232,17240]
                        trailer [17240,17248]
                            name: running [17241,17248]
                    operator: = [17249,17250]
                    atom [17251,17265]
                        operator: { [17251,17252]
                        dictorsetmaker [17252,17264]
                            name: key_1 [17252,17257]
                            operator: , [17257,17258]
                            name: key_2 [17259,17264]
                        operator: } [17264,17265]
            simple_stmt [17274,17346]
                expr_stmt [17274,17345]
                    atom_expr [17274,17288]
                        name: executor [17274,17282]
                        trailer [17282,17288]
                            name: tasks [17283,17288]
                    operator: = [17289,17290]
                    atom [17291,17345]
                        operator: { [17291,17292]
                        dictorsetmaker [17292,17344]
                            name: key_1 [17292,17297]
                            atom_expr [17299,17317]
                                name: AsyncResult [17299,17310]
                                trailer [17310,17317]
                                    string: "231" [17311,17316]
                            operator: , [17317,17318]
                            name: key_2 [17319,17324]
                            atom_expr [17326,17344]
                                name: AsyncResult [17326,17337]
                                trailer [17337,17344]
                                    string: "232" [17338,17343]
                        operator: } [17344,17345]
            simple_stmt [17354,17370]
                atom_expr [17354,17369]
                    name: executor [17354,17362]
                    trailer [17362,17367]
                        name: sync [17363,17367]
                    trailer [17367,17369]
            simple_stmt [17378,17440]
                assert_stmt [17378,17439]
                    comparison [17385,17439]
                        atom_expr [17385,17406]
                            name: executor [17385,17393]
                            trailer [17393,17406]
                                name: event_buffer [17394,17406]
                        operator: == [17407,17409]
                        atom [17410,17439]
                            operator: { [17410,17411]
                            dictorsetmaker [17411,17438]
                                name: key_1 [17411,17416]
                                atom [17418,17438]
                                    testlist_comp [17419,17437]
                                        atom_expr [17419,17431]
                                            name: State [17419,17424]
                                            trailer [17424,17431]
                                                name: FAILED [17425,17431]
                                        operator: , [17431,17432]
                            operator: } [17438,17439]
            simple_stmt [17448,17501]
                assert_stmt [17448,17500]
                    comparison [17455,17500]
                        atom_expr [17455,17469]
                            name: executor [17455,17463]
                            trailer [17463,17469]
                                name: tasks [17464,17469]
                        operator: == [17470,17472]
                        atom [17473,17500]
                            operator: { [17473,17474]
                            dictorsetmaker [17474,17499]
                                name: key_2 [17474,17479]
                                atom_expr [17481,17499]
                                    name: AsyncResult [17481,17492]
                                    trailer [17492,17499]
                                        string: '232' [17493,17498]
                            operator: } [17499,17500]
            simple_stmt [17509,17544]
                assert_stmt [17509,17543]
                    comparison [17516,17543]
                        atom_expr [17516,17532]
                            name: executor [17516,17524]
                            trailer [17524,17532]
                                name: running [17525,17532]
                        operator: == [17533,17535]
                        atom [17536,17543]
                            operator: { [17536,17537]
                            name: key_2 [17537,17542]
                            operator: } [17542,17543]
            simple_stmt [17552,17649]
                assert_stmt [17552,17648]
                    comparison [17559,17648]
                        atom_expr [17559,17589]
                            name: executor [17559,17567]
                            trailer [17567,17589]
                                name: adopted_task_timeouts [17568,17589]
                        operator: == [17590,17592]
                        atom [17593,17648]
                            operator: { [17593,17594]
                            dictorsetmaker [17594,17647]
                                name: key_2 [17594,17599]
                                arith_expr [17601,17647]
                                    name: queued_dttm_2 [17601,17614]
                                    operator: + [17615,17616]
                                    atom_expr [17617,17647]
                                        name: executor [17617,17625]
                                        trailer [17625,17647]
                                            name: task_adoption_timeout [17626,17647]
                            operator: } [17647,17648]
to
suite [3563,16272]
at 11
===
delete-node
---
name: TestCeleryExecutor [3525,3543]
===
