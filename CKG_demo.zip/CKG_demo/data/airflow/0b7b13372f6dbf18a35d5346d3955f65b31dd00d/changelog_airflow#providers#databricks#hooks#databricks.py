===
match
---
simple_stmt [10695,10758]
simple_stmt [10737,10800]
===
match
---
name: method [7046,7052]
name: method [7088,7094]
===
match
---
string: 'job_id' [10139,10147]
string: 'job_id' [10181,10189]
===
match
---
tfpdef [2094,2112]
tfpdef [2094,2112]
===
match
---
simple_stmt [7149,7179]
simple_stmt [7191,7221]
===
match
---
trailer [11183,11215]
trailer [11225,11257]
===
match
---
raise_stmt [7205,7264]
raise_stmt [7247,7306]
===
match
---
string: """Utility class for the run state concept of Databricks runs.""" [1962,2027]
string: """Utility class for the run state concept of Databricks runs.""" [1962,2027]
===
match
---
string: 'POST' [1901,1907]
string: 'POST' [1901,1907]
===
match
---
testlist_comp [12479,12543]
testlist_comp [12521,12585]
===
match
---
operator: , [3070,3071]
operator: , [3070,3071]
===
match
---
parameters [2881,2887]
parameters [2881,2887]
===
match
---
arglist [12361,12390]
arglist [12403,12432]
===
match
---
name: _retryable_error [7841,7857]
name: _retryable_error [7883,7899]
===
match
---
name: e [8048,8049]
name: e [8090,8091]
===
match
---
trailer [8455,8467]
trailer [8497,8509]
===
match
---
name: token [12973,12978]
name: token [13015,13020]
===
match
---
trailer [6846,6855]
trailer [6888,6897]
===
match
---
atom_expr [2724,2745]
atom_expr [2724,2745]
===
match
---
atom_expr [8147,8186]
atom_expr [8189,8228]
===
match
---
name: life_cycle_state [2052,2068]
name: life_cycle_state [2052,2068]
===
match
---
name: host [6897,6901]
name: host [6939,6943]
===
match
---
name: json [10974,10978]
name: json [11016,11020]
===
match
---
simple_stmt [8972,9025]
simple_stmt [9014,9067]
===
match
---
name: post [7100,7104]
name: post [7142,7146]
===
match
---
comp_op [2400,2406]
comp_op [2400,2406]
===
match
---
name: attempt_num [8171,8182]
name: attempt_num [8213,8224]
===
match
---
name: __repr__ [3327,3335]
name: __repr__ [3327,3335]
===
match
---
name: response [12567,12575]
name: response [12609,12617]
===
match
---
operator: , [9083,9084]
operator: , [9125,9126]
===
match
---
atom_expr [4386,4404]
atom_expr [4386,4404]
===
match
---
simple_stmt [1528,1580]
simple_stmt [1528,1580]
===
match
---
operator: = [7162,7163]
operator: = [7204,7205]
===
match
---
name: str [9832,9835]
name: str [9874,9877]
===
match
---
trailer [3293,3307]
trailer [3293,3307]
===
match
---
trailer [2780,2797]
trailer [2780,2797]
===
match
---
dotted_name [1063,1075]
dotted_name [1063,1075]
===
match
---
string: 'TERMINATED' [2802,2814]
string: 'TERMINATED' [2802,2814]
===
match
---
param [3009,3014]
param [3009,3014]
===
match
---
operator: , [1145,1146]
operator: , [1145,1146]
===
match
---
expr_stmt [10648,10686]
expr_stmt [10690,10728]
===
match
---
simple_stmt [11508,11628]
simple_stmt [11550,11670]
===
match
---
param [11245,11255]
param [11287,11297]
===
match
---
funcdef [2998,3318]
funcdef [2998,3318]
===
match
---
if_stmt [5559,5774]
if_stmt [5524,5739]
===
match
---
name: self [3146,3150]
name: self [3146,3150]
===
match
---
name: get_run_page_url [9488,9504]
name: get_run_page_url [9530,9546]
===
match
---
trailer [5535,5541]
trailer [5500,5506]
===
match
---
name: urlparse [5527,5535]
name: urlparse [5492,5500]
===
match
---
simple_stmt [11989,12036]
simple_stmt [12031,12078]
===
match
---
operator: = [1600,1601]
operator: = [1600,1601]
===
match
---
simple_stmt [1181,1216]
simple_stmt [1181,1216]
===
match
---
operator: >= [12631,12633]
operator: >= [12673,12675]
===
match
---
name: state_message [2242,2255]
name: state_message [2242,2255]
===
match
---
suite [3082,3117]
suite [3082,3117]
===
match
---
atom_expr [10130,10148]
atom_expr [10172,10190]
===
match
---
operator: = [1768,1769]
operator: = [1768,1769]
===
match
---
operator: -> [2297,2299]
operator: -> [2297,2299]
===
match
---
fstring_expr [6952,6962]
fstring_expr [6994,7004]
===
match
---
operator: = [2198,2199]
operator: = [2198,2199]
===
match
---
trailer [11402,11415]
trailer [11444,11457]
===
match
---
trailer [13052,13060]
trailer [13094,13102]
===
match
---
name: error [8521,8526]
name: error [8563,8568]
===
match
---
operator: , [8519,8520]
operator: , [8561,8562]
===
match
---
trailer [2225,2239]
trailer [2225,2239]
===
match
---
atom_expr [7164,7178]
atom_expr [7206,7220]
===
match
---
name: _retryable_error [12398,12414]
name: _retryable_error [12440,12456]
===
match
---
name: self [8451,8455]
name: self [8493,8497]
===
match
---
name: str [9100,9103]
name: str [9142,9145]
===
match
---
arglist [11416,11444]
arglist [11458,11486]
===
match
---
name: life_cycle_state [10477,10493]
name: life_cycle_state [10519,10535]
===
match
---
expr_stmt [1580,1638]
expr_stmt [1580,1638]
===
match
---
atom [9678,9696]
atom [9720,9738]
===
match
---
name: AirflowException [7211,7227]
name: AirflowException [7253,7269]
===
match
---
name: start_cluster [11225,11238]
name: start_cluster [11267,11280]
===
match
---
name: endpoint_info [5802,5815]
name: endpoint_info [5767,5780]
===
match
---
trailer [8371,8383]
trailer [8413,8425]
===
match
---
operator: -> [2114,2116]
operator: -> [2114,2116]
===
match
---
name: method [6293,6299]
name: method [6258,6264]
===
match
---
name: self [4727,4731]
name: self [4692,4696]
===
match
---
name: str [10186,10189]
name: str [10228,10231]
===
match
---
name: _do_api_call [10398,10410]
name: _do_api_call [10440,10452]
===
match
---
operator: { [9678,9679]
operator: { [9720,9721]
===
match
---
tfpdef [12931,12941]
tfpdef [12973,12983]
===
match
---
name: extra_dejson [6552,6564]
name: extra_dejson [6594,6606]
===
match
---
operator: , [1554,1555]
operator: , [1554,1555]
===
match
---
trailer [2382,2399]
trailer [2382,2399]
===
match
---
name: other [3231,3236]
name: other [3231,3236]
===
match
---
trailer [10669,10686]
trailer [10711,10728]
===
match
---
operator: -> [2888,2890]
operator: -> [2888,2890]
===
match
---
name: timeout_seconds [4560,4575]
name: timeout_seconds [4525,4540]
===
match
---
name: self [9818,9822]
name: self [9860,9864]
===
match
---
name: urllib [1063,1069]
name: urllib [1063,1069]
===
match
---
trailer [10939,10952]
trailer [10981,10994]
===
match
---
name: life_cycle_state [3151,3167]
name: life_cycle_state [3151,3167]
===
match
---
param [12931,12941]
param [12973,12983]
===
match
---
name: __version__ [1237,1248]
name: __version__ [1237,1248]
===
match
---
name: retry_delay [4337,4348]
name: retry_delay [4337,4348]
===
match
---
atom_expr [13051,13077]
atom_expr [13093,13119]
===
match
---
simple_stmt [7689,7717]
simple_stmt [7731,7759]
===
match
---
name: terminate_cluster [11455,11472]
name: terminate_cluster [11497,11514]
===
match
---
name: json [12386,12390]
name: json [12428,12432]
===
match
---
number: 500 [12634,12637]
number: 500 [12676,12679]
===
match
---
expr_stmt [1812,1873]
expr_stmt [1812,1873]
===
match
---
testlist_comp [2802,2843]
testlist_comp [2802,2843]
===
match
---
param [12997,13002]
param [13039,13044]
===
match
---
simple_stmt [11166,11216]
simple_stmt [11208,11258]
===
match
---
name: state_message [10743,10756]
name: state_message [10785,10798]
===
match
---
expr_stmt [7274,7289]
expr_stmt [7316,7331]
===
match
---
name: _TokenAuth [12759,12769]
name: _TokenAuth [12801,12811]
===
match
---
parameters [12054,12072]
parameters [12096,12114]
===
match
---
funcdef [12984,13120]
funcdef [13026,13162]
===
match
---
operator: = [9714,9715]
operator: = [9756,9757]
===
match
---
simple_stmt [1962,2028]
simple_stmt [1962,2028]
===
match
---
name: log [6401,6404]
name: log [6443,6446]
===
match
---
atom_expr [10702,10757]
atom_expr [10744,10799]
===
match
---
name: UNINSTALL_LIBS_ENDPOINT [12361,12384]
name: UNINSTALL_LIBS_ENDPOINT [12403,12426]
===
match
---
name: life_cycle_state [10711,10727]
name: life_cycle_state [10753,10769]
===
match
---
fstring_string: Response:  [8037,8047]
fstring_string: Response:  [8079,8089]
===
match
---
atom_expr [9400,9444]
atom_expr [9442,9486]
===
match
---
expr_stmt [6869,6901]
expr_stmt [6911,6943]
===
match
---
comparison [12600,12637]
comparison [12642,12679]
===
match
---
funcdef [12912,12979]
funcdef [12954,13021]
===
match
---
name: json [9439,9443]
name: json [9481,9485]
===
match
---
return_stmt [9766,9797]
return_stmt [9808,9839]
===
match
---
name: GET_RUN_ENDPOINT [1639,1655]
name: GET_RUN_ENDPOINT [1639,1655]
===
match
---
trailer [6694,6710]
trailer [6736,6752]
===
match
---
atom_expr [10664,10686]
atom_expr [10706,10728]
===
match
---
atom_expr [11398,11445]
atom_expr [11440,11487]
===
match
---
trailer [7697,7714]
trailer [7739,7756]
===
match
---
trailer [7753,7755]
trailer [7795,7797]
===
match
---
operator: = [7417,7418]
operator: = [7459,7460]
===
match
---
trailer [12609,12618]
trailer [12651,12660]
===
match
---
trailer [2184,2197]
trailer [2184,2197]
===
match
---
trailer [7172,7178]
trailer [7214,7220]
===
match
---
operator: == [7053,7055]
operator: == [7095,7097]
===
match
---
expr_stmt [6444,6505]
expr_stmt [6486,6547]
===
match
---
name: requests_exceptions [12516,12535]
name: requests_exceptions [12558,12577]
===
match
---
name: self [11636,11640]
name: self [11678,11682]
===
match
---
simple_stmt [10382,10435]
simple_stmt [10424,10477]
===
match
---
atom_expr [2378,2399]
atom_expr [2378,2399]
===
match
---
simple_stmt [9453,9479]
simple_stmt [9495,9521]
===
match
---
operator: , [7603,7604]
operator: , [7645,7646]
===
match
---
string: 'token' [6496,6503]
string: 'token' [6538,6545]
===
match
---
simple_stmt [2905,2947]
simple_stmt [2905,2947]
===
match
---
import_as_names [1130,1180]
import_as_names [1130,1180]
===
match
---
name: retry_delay [4746,4757]
name: retry_delay [4711,4722]
===
match
---
simple_stmt [10028,10054]
simple_stmt [10070,10096]
===
match
---
trailer [9417,9444]
trailer [9459,9486]
===
match
---
trailer [6461,6505]
trailer [6503,6547]
===
match
---
operator: , [12476,12477]
operator: , [12518,12519]
===
match
---
tfpdef [3015,3028]
tfpdef [3015,3028]
===
match
---
trailer [8084,8093]
trailer [8126,8135]
===
match
---
name: response [10130,10138]
name: response [10172,10180]
===
match
---
name: exceptions [1262,1272]
name: exceptions [1262,1272]
===
match
---
param [9085,9095]
param [9127,9137]
===
match
---
simple_stmt [9705,9758]
simple_stmt [9747,9800]
===
match
---
simple_stmt [8147,8187]
simple_stmt [8189,8229]
===
match
---
trailer [12618,12630]
trailer [12660,12672]
===
match
---
operator: = [7286,7287]
operator: = [7328,7329]
===
match
---
expr_stmt [1874,1939]
expr_stmt [1874,1939]
===
match
---
simple_stmt [1750,1811]
simple_stmt [1750,1811]
===
match
---
name: dict [8677,8681]
name: dict [8719,8723]
===
match
---
atom_expr [7841,7860]
atom_expr [7883,7902]
===
match
---
operator: -> [4369,4371]
operator: -> [4369,4371]
===
match
---
name: result_state [10729,10741]
name: result_state [10771,10783]
===
match
---
operator: , [12691,12692]
operator: , [12733,12734]
===
match
---
name: self [11239,11243]
name: self [11281,11285]
===
match
---
expr_stmt [10028,10053]
expr_stmt [10070,10095]
===
match
---
operator: , [8669,8670]
operator: , [8711,8712]
===
match
---
operator: = [6688,6689]
operator: = [6730,6731]
===
match
---
trailer [9733,9757]
trailer [9775,9799]
===
match
---
name: requests_exceptions [7775,7794]
name: requests_exceptions [7817,7836]
===
match
---
comparison [12557,12587]
comparison [12599,12629]
===
match
---
name: request_func [7076,7088]
name: request_func [7118,7130]
===
match
---
simple_stmt [4727,4758]
simple_stmt [4692,4723]
===
match
---
suite [12434,12644]
suite [12476,12686]
===
match
---
trailer [13096,13102]
trailer [13138,13144]
===
match
---
operator: , [8182,8183]
operator: , [8224,8225]
===
match
---
if_stmt [6518,6716]
if_stmt [6560,6758]
===
match
---
comparison [4587,4602]
comparison [4552,4567]
===
match
---
trailer [11653,11687]
trailer [11695,11729]
===
match
---
trailer [12347,12360]
trailer [12389,12402]
===
match
---
name: dict [11251,11255]
name: dict [11293,11297]
===
match
---
name: self [6589,6593]
name: self [6631,6635]
===
match
---
name: run_id [10178,10184]
name: run_id [10220,10226]
===
match
---
name: str [8528,8531]
name: str [8570,8573]
===
match
---
simple_stmt [4413,4458]
simple_stmt [4413,4458]
===
match
---
funcdef [4781,5774]
funcdef [4746,5739]
===
match
---
operator: , [2092,2093]
operator: , [2092,2093]
===
match
---
name: life_cycle_state [3177,3193]
name: life_cycle_state [3177,3193]
===
match
---
simple_stmt [4036,4074]
simple_stmt [4036,4074]
===
match
---
atom [10908,10926]
atom [10950,10968]
===
match
---
name: self [10778,10782]
name: self [10820,10824]
===
match
---
fstring_expr [1795,1808]
fstring_expr [1795,1808]
===
match
---
raise_stmt [2442,2760]
raise_stmt [2442,2760]
===
match
---
name: databricks_conn [6881,6896]
name: databricks_conn [6923,6938]
===
match
---
name: _do_api_call [11994,12006]
name: _do_api_call [12036,12048]
===
match
---
fstring_expr [8082,8106]
fstring_expr [8124,8148]
===
match
---
name: RUN_LIFE_CYCLE_STATES [12646,12667]
name: RUN_LIFE_CYCLE_STATES [12688,12709]
===
match
---
name: sleep [8445,8450]
name: sleep [8487,8492]
===
match
---
atom_expr [7740,7755]
atom_expr [7782,7797]
===
match
---
name: _log_request_error [8152,8170]
name: _log_request_error [8194,8212]
===
match
---
name: r [13003,13004]
name: r [13045,13046]
===
match
---
name: exceptions [1147,1157]
name: exceptions [1147,1157]
===
match
---
string: 'POST' [1837,1843]
string: 'POST' [1837,1843]
===
match
---
name: run_id [10919,10925]
name: run_id [10961,10967]
===
match
---
param [11711,11721]
param [11753,11763]
===
match
---
name: response [9040,9048]
name: response [9082,9090]
===
match
---
name: self [9400,9404]
name: self [9442,9446]
===
match
---
name: isinstance [3054,3064]
name: isinstance [3054,3064]
===
match
---
classdef [12753,13120]
classdef [12795,13162]
===
match
---
name: exception [12415,12424]
name: exception [12457,12466]
===
match
---
name: other [3288,3293]
name: other [3288,3293]
===
match
---
trailer [10090,10114]
trailer [10132,10156]
===
match
---
atom_expr [10073,10114]
atom_expr [10115,10156]
===
match
---
classdef [3386,12392]
classdef [3386,12434]
===
match
---
expr_stmt [4537,4575]
expr_stmt [4502,4540]
===
match
---
operator: , [10107,10108]
operator: , [10149,10150]
===
match
---
operator: , [9822,9823]
operator: , [9864,9865]
===
match
---
name: response [9773,9781]
name: response [9815,9823]
===
match
---
import_from [1035,1057]
import_from [1035,1057]
===
match
---
comparison [2962,2992]
comparison [2962,2992]
===
match
---
name: state_message [2226,2239]
name: state_message [2226,2239]
===
match
---
trailer [3270,3284]
trailer [3270,3284]
===
match
---
simple_stmt [3422,4031]
simple_stmt [3422,4031]
===
match
---
simple_stmt [1874,1940]
simple_stmt [1874,1940]
===
match
---
testlist_comp [1901,1938]
testlist_comp [1901,1938]
===
match
---
string: 'run_id' [10909,10917]
string: 'run_id' [10951,10959]
===
match
---
operator: , [7391,7392]
operator: , [7433,7434]
===
match
---
name: method [7500,7506]
name: method [7542,7548]
===
match
---
trailer [6404,6409]
trailer [6446,6451]
===
match
---
simple_stmt [10062,10115]
simple_stmt [10104,10157]
===
match
---
name: str [9519,9522]
name: str [9561,9564]
===
match
---
name: super [4386,4391]
name: super [4386,4391]
===
match
---
name: life_cycle_state [2781,2797]
name: life_cycle_state [2781,2797]
===
match
---
comparison [3210,3249]
comparison [3210,3249]
===
match
---
name: state_message [3271,3284]
name: state_message [3271,3284]
===
match
---
comparison [6338,6382]
comparison [6380,6424]
===
match
---
parameters [4194,4368]
parameters [4194,4368]
===
match
---
simple_stmt [8699,8964]
simple_stmt [8741,9006]
===
match
---
name: airflow [1254,1261]
name: airflow [1254,1261]
===
match
---
number: 3 [4326,4327]
number: 3 [4326,4327]
===
match
---
name: e [7858,7859]
name: e [7900,7901]
===
match
---
arglist [8171,8185]
arglist [8213,8227]
===
match
---
arglist [7388,7654]
arglist [7430,7696]
===
match
---
simple_stmt [8416,8433]
simple_stmt [8458,8475]
===
match
---
trailer [7748,7753]
trailer [7790,7795]
===
match
---
name: get_run_state [10158,10171]
name: get_run_state [10200,10213]
===
match
---
simple_stmt [6911,6964]
simple_stmt [6953,7006]
===
match
---
operator: } [10925,10926]
operator: } [10967,10968]
===
match
---
suite [4815,5774]
suite [4780,5739]
===
match
---
name: json [7749,7753]
name: json [7791,7795]
===
match
---
name: property [2262,2270]
name: property [2262,2270]
===
match
---
operator: -> [11723,11725]
operator: -> [11765,11767]
===
match
---
operator: == [3168,3170]
operator: == [3168,3170]
===
match
---
comp_op [12576,12582]
comp_op [12618,12624]
===
match
---
string: "POST" [1366,1372]
string: "POST" [1366,1372]
===
match
---
operator: = [6915,6916]
operator: = [6957,6958]
===
match
---
trailer [4393,4402]
trailer [4393,4402]
===
match
---
simple_stmt [7205,7265]
simple_stmt [7247,7307]
===
match
---
simple_stmt [6742,6778]
simple_stmt [6784,6820]
===
match
---
operator: , [4327,4328]
operator: , [4327,4328]
===
match
---
expr_stmt [7005,7032]
expr_stmt [7047,7074]
===
match
---
name: AuthBase [1207,1215]
name: AuthBase [1207,1215]
===
match
---
name: response [8972,8980]
name: response [9014,9022]
===
match
---
operator: , [11243,11244]
operator: , [11285,11286]
===
match
---
arglist [10953,10978]
arglist [10995,11020]
===
match
---
trailer [7028,7032]
trailer [7070,7074]
===
match
---
expr_stmt [10477,10521]
expr_stmt [10519,10563]
===
match
---
atom [1900,1939]
atom [1900,1939]
===
match
---
atom_expr [2962,2979]
atom_expr [2962,2979]
===
match
---
operator: == [2980,2982]
operator: == [2980,2982]
===
match
---
simple_stmt [11398,11446]
simple_stmt [11440,11488]
===
match
---
string: 'api/2.0/jobs/runs/cancel' [1722,1748]
string: 'api/2.0/jobs/runs/cancel' [1722,1748]
===
match
---
string: 'TERMINATING' [12693,12706]
string: 'TERMINATING' [12735,12748]
===
match
---
atom [2801,2844]
atom [2801,2844]
===
match
---
comparison [6521,6564]
comparison [6563,6606]
===
match
---
name: databricks_conn [6695,6710]
name: databricks_conn [6737,6752]
===
match
---
operator: { [10908,10909]
operator: { [10950,10951]
===
match
---
name: CANCEL_RUN_ENDPOINT [10953,10972]
name: CANCEL_RUN_ENDPOINT [10995,11014]
===
match
---
name: str [2070,2073]
name: str [2070,2073]
===
match
---
name: self [11005,11009]
name: self [11047,11051]
===
match
---
atom_expr [12600,12630]
atom_expr [12642,12672]
===
match
---
name: _do_api_call [9721,9733]
name: _do_api_call [9763,9775]
===
match
---
while_stmt [7298,8469]
while_stmt [7340,8511]
===
match
---
decorator [2261,2271]
decorator [2261,2271]
===
match
---
parameters [2290,2296]
parameters [2290,2296]
===
match
---
operator: , [6299,6300]
operator: , [6264,6265]
===
match
---
simple_stmt [8445,8469]
simple_stmt [8487,8511]
===
match
---
string: 'GET' [7510,7515]
string: 'GET' [7552,7557]
===
match
---
name: retry_limit [4587,4598]
name: retry_limit [4552,4563]
===
match
---
operator: , [7653,7654]
operator: , [7695,7696]
===
match
---
suite [11031,11216]
suite [11073,11258]
===
match
---
name: _do_api_call [9405,9417]
name: _do_api_call [9447,9459]
===
match
---
atom [1427,1461]
atom [1427,1461]
===
match
---
param [8503,8520]
param [8545,8562]
===
match
---
parameters [10777,10796]
parameters [10819,10838]
===
match
---
trailer [10710,10757]
trailer [10752,10799]
===
match
---
name: airflow [1302,1309]
name: airflow [1302,1309]
===
match
---
trailer [8554,8558]
trailer [8596,8600]
===
match
---
simple_stmt [7076,7105]
simple_stmt [7118,7147]
===
match
---
atom_expr [6451,6505]
atom_expr [6493,6547]
===
match
---
testlist_comp [1714,1748]
testlist_comp [1714,1748]
===
match
---
name: timeout_seconds [4542,4557]
name: timeout_seconds [4507,4522]
===
match
---
param [9818,9823]
param [9860,9865]
===
match
---
simple_stmt [1217,1249]
simple_stmt [1217,1249]
===
match
---
arglist [10618,10638]
arglist [10660,10680]
===
match
---
name: conn_type [4123,4132]
name: conn_type [4123,4132]
===
match
---
expr_stmt [4152,4176]
expr_stmt [4152,4176]
===
match
---
number: 1 [7288,7289]
number: 1 [7330,7331]
===
match
---
atom_expr [3266,3284]
atom_expr [3266,3284]
===
match
---
name: attempt_num [8628,8639]
name: attempt_num [8670,8681]
===
match
---
name: request_func [7354,7366]
name: request_func [7396,7408]
===
match
---
fstring_expr [8047,8067]
fstring_expr [8089,8109]
===
match
---
simple_stmt [11636,11688]
simple_stmt [11678,11730]
===
match
---
trailer [9781,9797]
trailer [9823,9839]
===
match
---
operator: = [7089,7090]
operator: = [7131,7132]
===
match
---
operator: = [10391,10392]
operator: = [10433,10434]
===
match
---
name: self [2962,2966]
name: self [2962,2966]
===
match
---
operator: -> [12943,12945]
operator: -> [12985,12987]
===
match
---
trailer [6482,6495]
trailer [6524,6537]
===
match
---
name: retry_delay [4732,4743]
name: retry_delay [4697,4708]
===
match
---
trailer [3236,3249]
trailer [3236,3249]
===
match
---
trailer [8058,8066]
trailer [8100,8108]
===
match
---
return_stmt [5656,5676]
return_stmt [5621,5641]
===
match
---
expr_stmt [13051,13102]
expr_stmt [13093,13144]
===
match
---
trailer [10459,10468]
trailer [10501,10510]
===
match
---
name: life_cycle_state [2729,2745]
name: life_cycle_state [2729,2745]
===
match
---
name: requests [7091,7099]
name: requests [7133,7141]
===
match
---
operator: == [7125,7127]
operator: == [7167,7169]
===
match
---
name: __init__ [4394,4402]
name: __init__ [4394,4402]
===
match
---
name: str [8686,8689]
name: str [8728,8731]
===
match
---
name: response [8050,8058]
name: response [8092,8100]
===
match
---
parameters [12924,12942]
parameters [12966,12984]
===
match
---
name: databricks_conn [6354,6369]
name: databricks_conn [6396,6411]
===
match
---
funcdef [8653,9059]
funcdef [8695,9101]
===
match
---
parameters [3335,3341]
parameters [3335,3341]
===
match
---
trailer [11993,12006]
trailer [12035,12048]
===
match
---
parameters [8664,8682]
parameters [8706,8724]
===
match
---
name: _do_api_call [10940,10952]
name: _do_api_call [10982,10994]
===
match
---
atom_expr [11989,12035]
atom_expr [12031,12077]
===
match
---
expr_stmt [10382,10434]
expr_stmt [10424,10476]
===
match
---
operator: , [10741,10742]
operator: , [10783,10784]
===
match
---
name: staticmethod [4764,4776]
name: staticmethod [4729,4741]
===
match
---
operator: , [2073,2074]
operator: , [2073,2074]
===
match
---
number: 1 [8431,8432]
number: 1 [8473,8474]
===
match
---
return_stmt [2955,2992]
return_stmt [2955,2992]
===
match
---
import_from [1181,1215]
import_from [1181,1215]
===
match
---
if_stmt [8200,8403]
if_stmt [8242,8445]
===
match
---
name: response [9705,9713]
name: response [9747,9755]
===
match
---
name: requests_exceptions [12479,12498]
name: requests_exceptions [12521,12540]
===
match
---
name: response [9460,9468]
name: response [9502,9510]
===
match
---
dictorsetmaker [9679,9695]
dictorsetmaker [9721,9737]
===
match
---
atom [8296,8359]
atom [8338,8401]
===
match
---
name: method [7257,7263]
name: method [7299,7305]
===
match
---
name: self [5796,5800]
name: self [5761,5765]
===
match
---
name: e [8184,8185]
name: e [8226,8227]
===
match
---
name: life_cycle_state [2383,2399]
name: life_cycle_state [2383,2399]
===
match
---
simple_stmt [10123,10149]
simple_stmt [10165,10191]
===
match
---
atom_expr [6826,6855]
atom_expr [6868,6897]
===
match
---
tfpdef [4307,4323]
tfpdef [4307,4323]
===
match
---
name: self [8550,8554]
name: self [8592,8596]
===
match
---
arglist [10711,10756]
arglist [10753,10798]
===
match
---
atom_expr [7354,7672]
atom_expr [7396,7714]
===
match
---
name: self [8983,8987]
name: self [9025,9029]
===
match
---
name: str [2089,2092]
name: str [2089,2092]
===
match
---
name: self [4204,4208]
name: self [4204,4208]
===
match
---
expr_stmt [8972,9024]
expr_stmt [9014,9066]
===
match
---
funcdef [12394,12644]
funcdef [12436,12686]
===
match
---
param [11005,11010]
param [11047,11052]
===
match
---
trailer [3176,3193]
trailer [3176,3193]
===
match
---
name: urlparse_host [5663,5676]
name: urlparse_host [5628,5641]
===
match
---
string: """         Retrieves run_page_url.          :param run_id: id of the run         :return: URL of the run page         """ [9540,9662]
string: """         Retrieves run_page_url.          :param run_id: id of the run         :return: URL of the run page         """ [9582,9704]
===
match
---
name: json [10901,10905]
name: json [10943,10947]
===
match
---
param [5802,5816]
param [5767,5781]
===
match
---
operator: = [7018,7019]
operator: = [7060,7061]
===
match
---
operator: = [1898,1899]
operator: = [1898,1899]
===
match
---
suite [11731,12036]
suite [11773,12078]
===
match
---
atom [1713,1749]
atom [1713,1749]
===
match
---
atom_expr [7689,7716]
atom_expr [7731,7758]
===
match
---
name: START_CLUSTER_ENDPOINT [11416,11438]
name: START_CLUSTER_ENDPOINT [11458,11480]
===
match
---
tfpdef [13003,13021]
tfpdef [13045,13063]
===
match
---
simple_stmt [2769,2845]
simple_stmt [2769,2845]
===
match
---
name: attempt_num [7274,7285]
name: attempt_num [7316,7327]
===
match
---
return_stmt [9453,9478]
return_stmt [9495,9520]
===
match
---
trailer [7637,7653]
trailer [7679,7695]
===
match
---
name: endpoint [6301,6309]
name: endpoint [6266,6274]
===
match
---
not_test [3050,3081]
not_test [3050,3081]
===
match
---
name: json [11245,11249]
name: json [11287,11291]
===
match
---
name: self [6798,6802]
name: self [6840,6844]
===
match
---
param [10172,10177]
param [10214,10219]
===
match
---
name: json [8671,8675]
name: json [8713,8717]
===
match
---
name: auth [1195,1199]
name: auth [1195,1199]
===
match
---
arglist [9001,9023]
arglist [9043,9065]
===
match
---
atom [1365,1401]
atom [1365,1401]
===
match
---
number: 1.0 [4358,4361]
number: 1.0 [4358,4361]
===
match
---
name: life_cycle_state [2155,2171]
name: life_cycle_state [2155,2171]
===
match
---
name: result_state [2200,2212]
name: result_state [2200,2212]
===
match
---
operator: = [13078,13079]
operator: = [13120,13121]
===
match
---
raise_stmt [4616,4679]
raise_stmt [4581,4644]
===
match
---
name: self [6396,6400]
name: self [6438,6442]
===
match
---
return_stmt [2769,2844]
return_stmt [2769,2844]
===
match
---
atom [1491,1526]
atom [1491,1526]
===
match
---
expr_stmt [5511,5550]
expr_stmt [5476,5515]
===
match
---
atom_expr [2221,2239]
atom_expr [2221,2239]
===
match
---
parameters [8496,8532]
parameters [8538,8574]
===
match
---
trailer [8222,8234]
trailer [8264,8276]
===
match
---
atom [12446,12643]
atom [12488,12685]
===
match
---
expr_stmt [7076,7104]
expr_stmt [7118,7146]
===
match
---
name: run_now [8657,8664]
name: run_now [8699,8706]
===
match
---
atom_expr [2482,2746]
atom_expr [2482,2746]
===
match
---
atom_expr [8983,9024]
atom_expr [9025,9066]
===
match
---
param [10784,10795]
param [10826,10837]
===
match
---
atom_expr [8296,8384]
atom_expr [8338,8426]
===
match
---
simple_stmt [6683,6716]
simple_stmt [6725,6758]
===
match
---
operator: = [4487,4488]
operator: = [4487,4488]
===
match
---
tfpdef [12061,12071]
tfpdef [12103,12113]
===
match
---
name: host [5536,5540]
name: host [5501,5505]
===
match
---
testlist_comp [6798,6855]
testlist_comp [6840,6897]
===
match
---
expr_stmt [4123,4147]
expr_stmt [4123,4147]
===
match
---
param [11011,11021]
param [11053,11063]
===
match
---
suite [7063,7105]
suite [7105,7147]
===
match
---
dictorsetmaker [1771,1809]
dictorsetmaker [1771,1809]
===
match
---
string: 'PENDING' [12671,12680]
string: 'PENDING' [12713,12722]
===
match
---
atom_expr [9773,9797]
atom_expr [9815,9839]
===
match
---
name: is_terminal [2279,2290]
name: is_terminal [2279,2290]
===
match
---
operator: , [10782,10783]
operator: , [10824,10825]
===
match
---
atom_expr [12960,12970]
atom_expr [13002,13012]
===
match
---
trailer [8274,8402]
trailer [8316,8444]
===
match
---
name: str [10792,10795]
name: str [10834,10837]
===
match
---
expr_stmt [4727,4757]
expr_stmt [4692,4722]
===
match
---
operator: , [11477,11478]
operator: , [11519,11520]
===
match
---
operator: , [1907,1908]
operator: , [1907,1908]
===
match
---
name: status_code [12619,12630]
name: status_code [12661,12672]
===
match
---
name: host [5769,5773]
name: host [5734,5738]
===
match
---
name: _do_api_call [11403,11415]
name: _do_api_call [11445,11457]
===
match
---
atom_expr [4688,4704]
atom_expr [4653,4669]
===
match
---
trailer [2464,2760]
trailer [2464,2760]
===
match
---
name: RunState [3072,3080]
name: RunState [3072,3080]
===
match
---
dictorsetmaker [10356,10372]
dictorsetmaker [10398,10414]
===
match
---
name: str [4803,4806]
name: str [4768,4771]
===
match
---
tfpdef [8671,8681]
tfpdef [8713,8723]
===
match
---
operator: = [7585,7586]
operator: = [7627,7628]
===
match
---
param [12055,12060]
param [12097,12102]
===
match
---
name: __init__ [12916,12924]
name: __init__ [12958,12966]
===
match
---
name: state_message [2094,2107]
name: state_message [2094,2107]
===
match
---
operator: @ [2850,2851]
operator: @ [2850,2851]
===
match
---
operator: = [10353,10354]
operator: = [10395,10396]
===
match
---
name: GET_RUN_ENDPOINT [10091,10107]
name: GET_RUN_ENDPOINT [10133,10149]
===
match
---
suite [11499,11688]
suite [11541,11730]
===
match
---
return_stmt [10123,10148]
return_stmt [10165,10190]
===
match
---
trailer [6896,6901]
trailer [6938,6943]
===
match
---
name: json [10429,10433]
name: json [10471,10475]
===
match
---
string: """True if the current state is a terminal state.""" [2314,2366]
string: """True if the current state is a terminal state.""" [2314,2366]
===
match
---
simple_stmt [9766,9798]
simple_stmt [9808,9840]
===
match
---
return_stmt [3358,3383]
return_stmt [3358,3383]
===
match
---
name: run_id [9689,9695]
name: run_id [9731,9737]
===
match
---
name: self [11705,11709]
name: self [11747,11751]
===
match
---
simple_stmt [11740,11981]
simple_stmt [11782,12023]
===
match
---
simple_stmt [9389,9445]
simple_stmt [9431,9487]
===
match
---
expr_stmt [1691,1749]
expr_stmt [1691,1749]
===
match
---
name: response [10382,10390]
name: response [10424,10432]
===
match
---
name: dict [11017,11021]
name: dict [11059,11063]
===
match
---
operator: , [11680,11681]
operator: , [11722,11723]
===
match
---
if_stmt [7834,8130]
if_stmt [7876,8172]
===
match
---
parameters [12414,12425]
parameters [12456,12467]
===
match
---
arglist [11654,11686]
arglist [11696,11728]
===
match
---
string: 'life_cycle_state' [10502,10520]
string: 'life_cycle_state' [10544,10562]
===
match
---
suite [6729,6902]
suite [6771,6944]
===
match
---
name: str [9840,9843]
name: str [9882,9885]
===
match
---
trailer [6466,6482]
trailer [6508,6524]
===
match
---
parameters [11704,11722]
parameters [11746,11764]
===
match
---
trailer [6880,6896]
trailer [6922,6938]
===
match
---
simple_stmt [13111,13120]
simple_stmt [13153,13162]
===
match
---
name: self [7633,7637]
name: self [7675,7679]
===
match
---
name: status_code [8094,8105]
name: status_code [8136,8147]
===
match
---
atom_expr [6396,6431]
atom_expr [6438,6473]
===
match
---
name: self [2776,2780]
name: self [2776,2780]
===
match
---
string: """         Cancels the run.          :param run_id: id of the run         """ [10814,10892]
string: """         Cancels the run.          :param run_id: id of the run         """ [10856,10934]
===
match
---
operator: , [7525,7526]
operator: , [7567,7568]
===
match
---
string: """         Retrieves job_id from run_id.          :param run_id: id of the run         :type run_id: str         :return: Job id for given Databricks run         """ [9853,10019]
string: """         Retrieves job_id from run_id.          :param run_id: id of the run         :type run_id: str         :return: Job id for given Databricks run         """ [9895,10061]
===
match
---
operator: -> [9097,9099]
operator: -> [9139,9141]
===
match
---
name: password [6847,6855]
name: password [6889,6897]
===
match
---
fstring_end: ' [1808,1809]
fstring_end: ' [1808,1809]
===
match
---
name: self [12997,13001]
name: self [13039,13043]
===
match
---
trailer [10613,10617]
trailer [10655,10659]
===
match
---
atom_expr [4727,4743]
atom_expr [4692,4708]
===
match
---
expr_stmt [6911,6963]
expr_stmt [6953,7005]
===
match
---
param [11473,11478]
param [11515,11520]
===
match
---
name: host [4797,4801]
name: host [4762,4766]
===
match
---
atom [10355,10373]
atom [10397,10415]
===
match
---
comparison [7118,7135]
comparison [7160,7177]
===
match
---
operator: { [6952,6953]
operator: { [6994,6995]
===
match
---
suite [5690,5774]
suite [5655,5739]
===
match
---
param [2075,2093]
param [2075,2093]
===
match
---
string: "api/2.0/clusters/start" [1436,1460]
string: "api/2.0/clusters/start" [1436,1460]
===
match
---
name: ConnectionError [12499,12514]
name: ConnectionError [12541,12556]
===
match
---
name: response [7343,7351]
name: response [7385,7393]
===
match
---
atom [6797,6856]
atom [6839,6898]
===
match
---
trailer [10410,10434]
trailer [10452,10476]
===
match
---
atom_expr [6742,6777]
atom_expr [6784,6819]
===
match
---
funcdef [3323,3384]
funcdef [3323,3384]
===
match
---
name: TERMINATE_CLUSTER_ENDPOINT [11654,11680]
name: TERMINATE_CLUSTER_ENDPOINT [11696,11722]
===
match
---
comparison [7046,7062]
comparison [7088,7104]
===
match
---
name: exception [12557,12566]
name: exception [12599,12608]
===
match
---
string: 'POST' [7437,7443]
string: 'POST' [7479,7485]
===
match
---
testlist_comp [7437,7452]
testlist_comp [7479,7494]
===
match
---
simple_stmt [9671,9697]
simple_stmt [9713,9739]
===
match
---
name: AirflowException [2448,2464]
name: AirflowException [2448,2464]
===
match
---
param [2291,2295]
param [2291,2295]
===
match
---
string: "POST" [1428,1434]
string: "POST" [1428,1434]
===
match
---
operator: = [6310,6311]
operator: = [6275,6276]
===
match
---
name: AirflowException [8258,8274]
name: AirflowException [8300,8316]
===
match
---
trailer [3214,3227]
trailer [3214,3227]
===
match
---
operator: { [1770,1771]
operator: { [1770,1771]
===
match
---
name: self [8665,8669]
name: self [8707,8711]
===
match
---
expr_stmt [6683,6715]
expr_stmt [6725,6757]
===
match
---
name: requests [1186,1194]
name: requests [1186,1194]
===
match
---
simple_stmt [9113,9381]
simple_stmt [9155,9423]
===
match
---
trailer [4692,4704]
trailer [4657,4669]
===
match
---
name: self [6742,6746]
name: self [6784,6788]
===
match
---
string: 'run_page_url' [9782,9796]
string: 'run_page_url' [9824,9838]
===
match
---
name: e [8083,8084]
name: e [8125,8126]
===
match
---
trailer [6932,6944]
trailer [6974,6986]
===
match
---
atom_expr [6606,6647]
atom_expr [6648,6689]
===
match
---
operator: , [8639,8640]
operator: , [8681,8682]
===
match
---
name: attempt_num [8203,8214]
name: attempt_num [8245,8256]
===
match
---
name: exception [12467,12476]
name: exception [12509,12518]
===
match
---
trailer [6353,6369]
trailer [6395,6411]
===
match
---
operator: = [1711,1712]
operator: = [1711,1712]
===
match
---
operator: == [3228,3230]
operator: == [3228,3230]
===
match
---
simple_stmt [1093,1109]
simple_stmt [1093,1109]
===
match
---
name: self [2046,2050]
name: self [2046,2050]
===
match
---
operator: = [1834,1835]
operator: = [1834,1835]
===
match
---
name: log [6747,6750]
name: log [6789,6792]
===
match
---
name: run_id [10046,10052]
name: run_id [10088,10094]
===
match
---
suite [10805,10980]
suite [10847,11022]
===
match
---
name: token [13097,13102]
name: token [13139,13144]
===
match
---
suite [6565,6649]
suite [6607,6691]
===
match
---
operator: , [10727,10728]
operator: , [10769,10770]
===
match
---
string: 'api/2.0/jobs/runs/submit' [1611,1637]
string: 'api/2.0/jobs/runs/submit' [1611,1637]
===
match
---
name: airflow [1222,1229]
name: airflow [1222,1229]
===
match
---
atom_expr [10608,10639]
atom_expr [10650,10681]
===
match
---
atom [1836,1873]
atom [1836,1873]
===
match
---
name: conn_name_attr [4036,4050]
name: conn_name_attr [4036,4050]
===
match
---
name: restart_cluster [10989,11004]
name: restart_cluster [11031,11046]
===
match
---
atom_expr [6876,6901]
atom_expr [6918,6943]
===
match
---
name: TERMINATE_CLUSTER_ENDPOINT [1462,1488]
name: TERMINATE_CLUSTER_ENDPOINT [1462,1488]
===
match
---
name: state [10443,10448]
name: state [10485,10490]
===
match
---
name: retry_limit [4707,4718]
name: retry_limit [4672,4683]
===
match
---
import_from [1058,1091]
import_from [1058,1091]
===
match
---
simple_stmt [5762,5774]
simple_stmt [5727,5739]
===
match
---
tfpdef [8521,8531]
tfpdef [8563,8573]
===
match
---
operator: = [7551,7552]
operator: = [7593,7594]
===
match
---
tfpdef [9824,9835]
tfpdef [9866,9877]
===
match
---
name: dict [9091,9095]
name: dict [9133,9137]
===
match
---
string: """         Uninstall libraries on the cluster.          Utility function to call the ``2.0/libraries/uninstall`` endpoint.          :param json: json dictionary containing cluster_id and an array of library         :type json: dict         """ [12090,12334]
string: """         Uninstall libraries on the cluster.          Utility function to call the ``2.0/libraries/uninstall`` endpoint.          :param json: json dictionary containing cluster_id and an array of library         :type json: dict         """ [12132,12376]
===
match
---
parameters [11472,11490]
parameters [11514,11532]
===
match
---
testlist_comp [1603,1637]
testlist_comp [1603,1637]
===
match
---
name: RUN_LIFE_CYCLE_STATES [2407,2428]
name: RUN_LIFE_CYCLE_STATES [2407,2428]
===
match
---
suite [11265,11446]
suite [11307,11488]
===
match
---
suite [8541,8648]
suite [8583,8690]
===
match
---
name: dict [12067,12071]
name: dict [12109,12113]
===
match
---
name: self [4466,4470]
name: self [4466,4470]
===
match
---
simple_stmt [1639,1691]
simple_stmt [1639,1691]
===
match
---
param [4797,4806]
param [4762,4771]
===
match
---
simple_stmt [9853,10020]
simple_stmt [9895,10062]
===
match
---
param [8671,8681]
param [8713,8723]
===
match
---
simple_stmt [12090,12335]
simple_stmt [12132,12377]
===
match
---
comparison [7426,7453]
comparison [7468,7495]
===
match
---
name: retry_limit [8223,8234]
name: retry_limit [8265,8276]
===
match
---
decorated [4763,5774]
decorated [4728,5739]
===
match
---
trailer [6409,6431]
trailer [6451,6473]
===
match
---
decorated [2850,2993]
decorated [2850,2993]
===
match
---
trailer [10501,10521]
trailer [10543,10563]
===
match
---
name: response [9389,9397]
name: response [9431,9439]
===
match
---
trailer [6750,6755]
trailer [6792,6797]
===
match
---
string: 'Using basic auth. ' [6756,6776]
string: 'Using basic auth. ' [6798,6818]
===
match
---
test [7418,7463]
test [7460,7505]
===
match
---
operator: , [12514,12515]
operator: , [12556,12557]
===
match
---
tfpdef [11711,11721]
tfpdef [11753,11763]
===
match
---
suite [7192,7265]
suite [7234,7307]
===
match
---
trailer [6369,6382]
trailer [6411,6424]
===
match
---
string: 'run_id' [9049,9057]
string: 'run_id' [9091,9099]
===
match
---
operator: , [1664,1665]
operator: , [1664,1665]
===
match
---
string: 'Unexpected life cycle state: {}: If the state has ' [2504,2556]
string: 'Unexpected life cycle state: {}: If the state has ' [2504,2556]
===
match
---
string: 'INTERNAL_ERROR' [2827,2843]
string: 'INTERNAL_ERROR' [2827,2843]
===
match
---
operator: = [9676,9677]
operator: = [9718,9719]
===
match
---
operator: -> [8533,8535]
operator: -> [8575,8577]
===
match
---
name: is_successful [2868,2881]
name: is_successful [2868,2881]
===
match
---
expr_stmt [10593,10639]
expr_stmt [10635,10681]
===
match
---
param [4307,4328]
param [4307,4328]
===
match
---
parameters [3008,3029]
parameters [3008,3029]
===
match
---
name: RUN_NOW_ENDPOINT [1528,1544]
name: RUN_NOW_ENDPOINT [1528,1544]
===
match
---
name: method [7118,7124]
name: method [7160,7166]
===
match
---
simple_stmt [2131,2172]
simple_stmt [2131,2172]
===
match
---
atom_expr [3288,3307]
atom_expr [3288,3307]
===
match
---
name: self [8218,8222]
name: self [8260,8264]
===
match
---
except_clause [7768,7816]
except_clause [7810,7858]
===
match
---
name: DatabricksHook [3392,3406]
name: DatabricksHook [3392,3406]
===
match
---
argument [7485,7525]
argument [7527,7567]
===
match
---
arglist [11184,11214]
arglist [11226,11256]
===
match
---
name: request_func [7149,7161]
name: request_func [7191,7203]
===
match
---
string: 'PATCH' [7445,7452]
string: 'PATCH' [7487,7494]
===
match
---
operator: } [8105,8106]
operator: } [8147,8148]
===
match
---
name: headers [13053,13060]
name: headers [13095,13102]
===
match
---
suite [3038,3318]
suite [3038,3318]
===
match
---
name: hook_name [4152,4161]
name: hook_name [4152,4161]
===
match
---
simple_stmt [5511,5551]
simple_stmt [5476,5516]
===
match
---
atom_expr [3146,3167]
atom_expr [3146,3167]
===
match
---
suite [7861,8130]
suite [7903,8172]
===
match
---
name: SUBMIT_RUN_ENDPOINT [9418,9437]
name: SUBMIT_RUN_ENDPOINT [9460,9479]
===
match
---
trailer [8987,9000]
trailer [9029,9042]
===
match
---
name: self [6826,6830]
name: self [6868,6872]
===
match
---
name: format [8360,8366]
name: format [8402,8408]
===
match
---
trailer [3368,3383]
trailer [3368,3383]
===
match
---
operator: -> [11023,11025]
operator: -> [11065,11067]
===
match
---
expr_stmt [9671,9696]
expr_stmt [9713,9738]
===
match
---
name: result_state [10593,10605]
name: result_state [10635,10647]
===
match
---
fstring_expr [6927,6951]
fstring_expr [6969,6993]
===
match
---
expr_stmt [12646,12750]
expr_stmt [12688,12792]
===
match
---
name: time [1040,1044]
name: time [1040,1044]
===
match
---
name: databricks_conn [6536,6551]
name: databricks_conn [6578,6593]
===
match
---
operator: , [11709,11710]
operator: , [11751,11752]
===
match
---
operator: = [6795,6796]
operator: = [6837,6838]
===
match
---
simple_stmt [3358,3384]
simple_stmt [3358,3384]
===
match
---
name: self [12925,12929]
name: self [12967,12971]
===
match
---
string: """         Restarts the cluster.          :param json: json dictionary containing cluster specification.         """ [11040,11157]
string: """         Restarts the cluster.          :param json: json dictionary containing cluster specification.         """ [11082,11199]
===
match
---
tfpdef [4271,4291]
tfpdef [4271,4291]
===
match
---
operator: = [4242,4243]
operator: = [4242,4243]
===
match
---
atom_expr [5527,5550]
atom_expr [5492,5515]
===
match
---
string: 'result_state' [10618,10632]
string: 'result_state' [10660,10674]
===
match
---
number: 1 [4601,4602]
number: 1 [4566,4567]
===
match
---
operator: = [4558,4559]
operator: = [4523,4524]
===
match
---
simple_stmt [12439,12644]
simple_stmt [12481,12686]
===
match
---
operator: , [2814,2815]
operator: , [2814,2815]
===
match
---
string: 'state_message' [10670,10685]
string: 'state_message' [10712,10727]
===
match
---
param [2094,2112]
param [2094,2112]
===
match
---
atom [12478,12544]
atom [12520,12586]
===
match
---
operator: -> [9837,9839]
operator: -> [9879,9881]
===
match
---
arith_expr [13080,13102]
arith_expr [13122,13144]
===
match
---
parameters [10171,10190]
parameters [10213,10232]
===
match
---
expr_stmt [4078,4118]
expr_stmt [4078,4118]
===
match
---
operator: , [9509,9510]
operator: , [9551,9552]
===
match
---
tfpdef [4797,4806]
tfpdef [4762,4771]
===
match
---
param [10178,10189]
param [10220,10231]
===
match
---
atom_expr [10496,10521]
atom_expr [10538,10563]
===
match
---
atom [1547,1579]
atom [1547,1579]
===
match
---
name: result_state [2185,2197]
name: result_state [2185,2197]
===
match
---
name: self [6876,6880]
name: self [6918,6922]
===
match
---
string: 'GET' [1659,1664]
string: 'GET' [1659,1664]
===
match
---
expr_stmt [8416,8432]
expr_stmt [8458,8474]
===
match
---
operator: = [4133,4134]
operator: = [4133,4134]
===
match
---
trailer [8093,8105]
trailer [8135,8147]
===
match
---
string: 'PATCH' [7128,7135]
string: 'PATCH' [7170,7177]
===
match
---
operator: } [6961,6962]
operator: } [7003,7004]
===
match
---
name: json [11711,11715]
name: json [11753,11757]
===
match
---
operator: += [8428,8430]
operator: += [8470,8472]
===
match
---
string: 'Bearer ' [13080,13089]
string: 'Bearer ' [13122,13131]
===
match
---
trailer [12498,12514]
trailer [12540,12556]
===
match
---
atom [2482,2716]
atom [2482,2716]
===
match
---
simple_stmt [4466,4529]
simple_stmt [4466,4494]
===
match
---
classdef [1942,3384]
classdef [1942,3384]
===
match
---
simple_stmt [6582,6649]
simple_stmt [6624,6691]
===
match
---
name: request_func [7005,7017]
name: request_func [7047,7059]
===
match
---
simple_stmt [1297,1337]
simple_stmt [1297,1337]
===
match
---
simple_stmt [6293,6326]
simple_stmt [6258,6291]
===
match
---
suite [9531,9798]
suite [9573,9840]
===
match
---
trailer [12535,12543]
trailer [12577,12585]
===
match
---
name: extra_dejson [6627,6639]
name: extra_dejson [6669,6681]
===
match
---
decorated [2261,2845]
decorated [2261,2845]
===
match
---
operator: } [10372,10373]
operator: } [10414,10415]
===
match
---
operator: -> [4808,4810]
operator: -> [4773,4775]
===
match
---
atom_expr [11636,11687]
atom_expr [11678,11729]
===
match
---
trailer [13060,13077]
trailer [13102,13119]
===
match
---
dotted_name [1186,1199]
dotted_name [1186,1199]
===
match
---
return_stmt [3125,3317]
return_stmt [3125,3317]
===
match
---
trailer [6495,6504]
trailer [6537,6546]
===
match
---
simple_stmt [1691,1750]
simple_stmt [1691,1750]
===
match
---
string: "POST" [1492,1498]
string: "POST" [1492,1498]
===
match
---
name: retry_limit [8372,8383]
name: retry_limit [8414,8425]
===
match
---
atom_expr [6928,6950]
atom_expr [6970,6992]
===
match
---
operator: } [1807,1808]
operator: } [1807,1808]
===
match
---
operator: = [4292,4293]
operator: = [4292,4293]
===
match
---
expr_stmt [2180,2212]
expr_stmt [2180,2212]
===
match
---
trailer [9404,9417]
trailer [9446,9459]
===
match
---
operator: { [10035,10036]
operator: { [10077,10078]
===
match
---
simple_stmt [1058,1092]
simple_stmt [1058,1092]
===
match
---
param [8521,8531]
param [8563,8573]
===
match
---
simple_stmt [1109,1181]
simple_stmt [1109,1181]
===
match
---
trailer [6400,6404]
trailer [6442,6446]
===
match
---
funcdef [10154,10758]
funcdef [10196,10800]
===
match
---
param [8665,8670]
param [8707,8712]
===
match
---
name: NotImplemented [3102,3116]
name: NotImplemented [3102,3116]
===
match
---
trailer [3150,3167]
trailer [3150,3167]
===
match
---
atom_expr [6589,6648]
atom_expr [6631,6690]
===
match
---
expr_stmt [9705,9757]
expr_stmt [9747,9799]
===
match
---
name: hostname [5542,5550]
name: hostname [5507,5515]
===
match
---
suite [2305,2845]
suite [2305,2845]
===
match
---
expr_stmt [2221,2255]
expr_stmt [2221,2255]
===
match
---
operator: , [1372,1373]
operator: , [1372,1373]
===
match
---
atom_expr [3365,3383]
atom_expr [3365,3383]
===
match
---
simple_stmt [13051,13103]
simple_stmt [13093,13145]
===
match
---
operator: < [4599,4600]
operator: < [4564,4565]
===
match
---
parameters [4796,4807]
parameters [4761,4772]
===
match
---
operator: , [7443,7444]
operator: , [7485,7486]
===
match
---
operator: , [12720,12721]
operator: , [12762,12763]
===
match
---
name: url [7388,7391]
name: url [7430,7433]
===
match
---
name: error [8641,8646]
name: error [8683,8688]
===
match
---
name: self [12055,12059]
name: self [12097,12101]
===
match
---
name: self [3266,3270]
name: self [3266,3270]
===
match
---
name: UNINSTALL_LIBS_ENDPOINT [1874,1897]
name: UNINSTALL_LIBS_ENDPOINT [1874,1897]
===
match
---
operator: == [6983,6985]
operator: == [7025,7027]
===
match
---
fstring_start: f' [6917,6919]
fstring_start: f' [6959,6961]
===
match
---
operator: = [1656,1657]
operator: = [1656,1657]
===
match
---
name: _do_api_call [10078,10090]
name: _do_api_call [10120,10132]
===
match
---
atom_expr [4466,4486]
atom_expr [4466,4486]
===
match
---
name: _do_api_call [8988,9000]
name: _do_api_call [9030,9042]
===
match
---
name: self [6349,6353]
name: self [6391,6395]
===
match
---
name: get [7029,7032]
name: get [7071,7074]
===
match
---
tfpdef [9511,9522]
tfpdef [9553,9564]
===
match
---
raise_stmt [7987,8129]
raise_stmt [8029,8171]
===
match
---
operator: , [11009,11010]
operator: , [11051,11052]
===
match
---
or_test [12456,12637]
or_test [12498,12679]
===
match
---
name: self [11473,11477]
name: self [11515,11519]
===
match
---
string: """         Install libraries on the cluster.          Utility function to call the ``2.0/libraries/install`` endpoint.          :param json: json dictionary containing cluster_id and an array of library         :type json: dict         """ [11740,11980]
string: """         Install libraries on the cluster.          Utility function to call the ``2.0/libraries/install`` endpoint.          :param json: json dictionary containing cluster_id and an array of library         :type json: dict         """ [11782,12022]
===
match
---
atom_expr [9460,9478]
atom_expr [9502,9520]
===
match
---
operator: -> [3030,3032]
operator: -> [3030,3032]
===
match
---
suite [7326,7756]
suite [7368,7798]
===
match
---
operator: -> [10191,10193]
operator: -> [10233,10235]
===
match
---
name: json [5817,5821]
name: json [5782,5786]
===
match
---
simple_stmt [10935,10980]
simple_stmt [10977,11022]
===
match
---
string: 'POST' [1548,1554]
string: 'POST' [1548,1554]
===
match
---
param [12061,12071]
param [12103,12113]
===
match
---
decorator [2850,2860]
decorator [2850,2860]
===
match
---
tfpdef [10178,10189]
tfpdef [10220,10231]
===
match
---
and_test [12557,12637]
and_test [12599,12679]
===
match
---
string: 'databricks_default' [4098,4118]
string: 'databricks_default' [4098,4118]
===
match
---
operator: , [12731,12732]
operator: , [12773,12774]
===
match
---
atom [3132,3317]
atom [3132,3317]
===
match
---
name: result_state [3215,3227]
name: result_state [3215,3227]
===
match
---
parameters [9504,9523]
parameters [9546,9565]
===
match
---
simple_stmt [3125,3318]
simple_stmt [3125,3318]
===
match
---
name: r [13118,13119]
name: r [13160,13161]
===
match
---
atom_expr [4622,4679]
atom_expr [4587,4644]
===
match
---
name: self [10935,10939]
name: self [10977,10981]
===
match
---
testlist_comp [1492,1525]
testlist_comp [1492,1525]
===
match
---
fstring_start: f' [8035,8037]
fstring_start: f' [8077,8079]
===
match
---
name: auth [6444,6448]
name: auth [6486,6490]
===
match
---
name: self [8367,8371]
name: self [8409,8413]
===
match
---
expr_stmt [1402,1461]
expr_stmt [1402,1461]
===
match
---
name: json [12061,12065]
name: json [12103,12107]
===
match
---
trailer [9048,9058]
trailer [9090,9100]
===
match
---
param [11479,11489]
param [11521,11531]
===
match
---
return_stmt [13111,13119]
return_stmt [13153,13161]
===
match
---
name: retry_delay [8456,8467]
name: retry_delay [8498,8509]
===
match
---
name: endpoint [6953,6961]
name: endpoint [6995,7003]
===
match
---
name: auth [7552,7556]
name: auth [7594,7598]
===
match
---
arith_expr [8297,8358]
arith_expr [8339,8400]
===
match
---
name: __dict__ [3374,3382]
name: __dict__ [3374,3382]
===
match
---
operator: , [1843,1844]
operator: , [1843,1844]
===
match
---
operator: , [10427,10428]
operator: , [10469,10470]
===
match
---
name: content [8059,8066]
name: content [8101,8108]
===
match
---
param [3336,3340]
param [3336,3340]
===
match
---
operator: , [7556,7557]
operator: , [7598,7599]
===
match
---
name: requests [1114,1122]
name: requests [1114,1122]
===
match
---
name: RESTART_CLUSTER_ENDPOINT [11184,11208]
name: RESTART_CLUSTER_ENDPOINT [11226,11250]
===
match
---
atom_expr [6690,6715]
atom_expr [6732,6757]
===
match
---
suite [7817,8187]
suite [7859,8229]
===
match
---
name: state [10608,10613]
name: state [10650,10655]
===
match
---
name: extra_dejson [6370,6382]
name: extra_dejson [6412,6424]
===
match
---
name: self [11166,11170]
name: self [11208,11212]
===
match
---
if_stmt [3047,3117]
if_stmt [3047,3117]
===
match
---
string: 'host' [6640,6646]
string: 'host' [6682,6688]
===
match
---
atom_expr [8218,8234]
atom_expr [8260,8276]
===
match
---
simple_stmt [4152,4177]
simple_stmt [4152,4177]
===
match
---
param [4218,4262]
param [4218,4262]
===
match
---
atom_expr [10451,10468]
atom_expr [10493,10510]
===
match
---
name: RunState [10702,10710]
name: RunState [10744,10752]
===
match
---
simple_stmt [11274,11390]
simple_stmt [11316,11432]
===
match
---
operator: == [3285,3287]
operator: == [3285,3287]
===
match
---
import_from [1217,1248]
import_from [1217,1248]
===
match
---
simple_stmt [4537,4576]
simple_stmt [4502,4541]
===
match
---
if_stmt [4584,4680]
if_stmt [4549,4645]
===
match
---
name: self [10393,10397]
name: self [10435,10439]
===
match
---
name: GET_RUN_ENDPOINT [9734,9750]
name: GET_RUN_ENDPOINT [9776,9792]
===
match
---
atom_expr [9040,9058]
atom_expr [9082,9100]
===
match
---
atom_expr [8451,8467]
atom_expr [8493,8509]
===
match
---
suite [2429,2761]
suite [2429,2761]
===
match
---
funcdef [9484,9798]
funcdef [9526,9840]
===
match
---
simple_stmt [4123,4148]
simple_stmt [4123,4148]
===
match
---
name: self [2131,2135]
name: self [2131,2135]
===
match
---
simple_stmt [6396,6432]
simple_stmt [6438,6474]
===
match
---
simple_stmt [6444,6506]
simple_stmt [6486,6548]
===
match
---
test [7492,7525]
test [7534,7567]
===
match
---
name: urlparse_host [5511,5524]
name: urlparse_host [5476,5489]
===
match
---
string: 'api/2.0/jobs/runs/get' [1666,1689]
string: 'api/2.0/jobs/runs/get' [1666,1689]
===
match
---
parameters [5795,5822]
parameters [5760,5787]
===
match
---
atom [10035,10053]
atom [10077,10095]
===
match
---
name: self [3336,3340]
name: self [3336,3340]
===
match
---
trailer [6626,6639]
trailer [6668,6681]
===
match
---
funcdef [10763,10980]
funcdef [10805,11022]
===
match
---
trailer [7227,7264]
trailer [7269,7306]
===
match
---
trailer [9000,9024]
trailer [9042,9066]
===
match
---
string: 'guide for troubleshooting information' [2659,2698]
string: 'guide for troubleshooting information' [2659,2698]
===
match
---
operator: = [10449,10450]
operator: = [10491,10492]
===
match
---
trailer [2716,2723]
trailer [2716,2723]
===
match
---
trailer [6593,6605]
trailer [6635,6647]
===
match
---
simple_stmt [7274,7290]
simple_stmt [7316,7332]
===
match
---
suite [7309,8469]
suite [7351,8511]
===
match
---
simple_stmt [8550,8648]
simple_stmt [8592,8690]
===
match
---
operator: @ [4763,4764]
operator: @ [4728,4729]
===
match
---
return_stmt [5762,5773]
return_stmt [5727,5738]
===
match
---
name: url [6911,6914]
name: url [6953,6956]
===
match
---
operator: , [2825,2826]
operator: , [2825,2826]
===
match
---
operator: = [4051,4052]
operator: = [4051,4052]
===
match
---
operator: , [4361,4362]
operator: , [4361,4362]
===
match
---
parameters [11238,11256]
parameters [11280,11298]
===
match
---
name: self [6606,6610]
name: self [6648,6652]
===
match
---
name: host [6683,6687]
name: host [6725,6729]
===
match
---
suite [6666,6716]
suite [6708,6758]
===
match
---
name: databricks_conn [6831,6846]
name: databricks_conn [6873,6888]
===
match
---
operator: , [8501,8502]
operator: , [8543,8544]
===
match
---
operator: + [8344,8345]
operator: + [8386,8387]
===
match
---
comparison [6976,6991]
comparison [7018,7033]
===
match
---
trailer [4632,4679]
trailer [4597,4644]
===
match
---
name: CANCEL_RUN_ENDPOINT [1691,1710]
name: CANCEL_RUN_ENDPOINT [1691,1710]
===
match
---
testlist_comp [1837,1872]
testlist_comp [1837,1872]
===
match
---
operator: -> [11257,11259]
operator: -> [11299,11301]
===
match
---
name: headers [7578,7585]
name: headers [7620,7627]
===
match
---
name: RequestException [7795,7811]
name: RequestException [7837,7853]
===
match
---
trailer [8009,8129]
trailer [8051,8171]
===
match
---
name: log [8555,8558]
name: log [8597,8600]
===
match
---
string: 'been introduced recently, please check the Databricks user ' [2577,2638]
string: 'been introduced recently, please check the Databricks user ' [2577,2638]
===
match
---
suite [12951,12979]
suite [12993,13021]
===
match
---
tfpdef [10784,10795]
tfpdef [10826,10837]
===
match
---
funcdef [11693,12036]
funcdef [11735,12078]
===
match
---
name: json [12030,12034]
name: json [12072,12076]
===
match
---
tfpdef [2052,2073]
tfpdef [2052,2073]
===
match
---
param [11239,11244]
param [11281,11286]
===
match
---
suite [3417,12392]
suite [3417,12434]
===
match
---
name: response [10062,10070]
name: response [10104,10112]
===
match
---
operator: } [8066,8067]
operator: } [8108,8109]
===
match
---
operator: , [11208,11209]
operator: , [11250,11251]
===
match
---
atom_expr [8367,8383]
atom_expr [8409,8425]
===
match
---
trailer [6818,6824]
trailer [6860,6866]
===
match
---
suite [5576,5677]
suite [5541,5642]
===
match
---
fstring_string: / [6951,6952]
fstring_string: / [6993,6994]
===
match
---
name: json [11011,11015]
name: json [11053,11057]
===
match
---
arglist [3065,3080]
arglist [3065,3080]
===
match
---
name: self [6928,6932]
name: self [6970,6974]
===
match
---
expr_stmt [9389,9444]
expr_stmt [9431,9486]
===
match
---
operator: -> [3342,3344]
operator: -> [3342,3344]
===
match
---
operator: = [4705,4706]
operator: = [4670,4671]
===
match
---
fstring [1785,1809]
fstring [1785,1809]
===
match
---
import_as_name [1147,1180]
import_as_name [1147,1180]
===
match
---
operator: = [12971,12972]
operator: = [13013,13014]
===
match
---
simple_stmt [12343,12392]
simple_stmt [12385,12434]
===
match
---
atom_expr [2131,2152]
atom_expr [2131,2152]
===
match
---
atom_expr [2448,2760]
atom_expr [2448,2760]
===
match
---
name: bool [12429,12433]
name: bool [12471,12475]
===
match
---
trailer [12006,12035]
trailer [12048,12077]
===
match
---
import_from [1297,1336]
import_from [1297,1336]
===
match
---
string: 'GET' [6986,6991]
string: 'GET' [7028,7033]
===
match
---
atom_expr [7633,7653]
atom_expr [7675,7695]
===
match
---
suite [2896,2993]
suite [2896,2993]
===
match
---
operator: = [10906,10907]
operator: = [10948,10949]
===
match
---
atom_expr [3231,3249]
atom_expr [3231,3249]
===
match
---
trailer [6746,6750]
trailer [6788,6792]
===
match
---
name: response [10451,10459]
name: response [10493,10501]
===
match
---
simple_stmt [2180,2213]
simple_stmt [2180,2213]
===
match
---
operator: = [8981,8982]
operator: = [9023,9024]
===
match
---
param [5796,5801]
param [5761,5766]
===
match
---
param [5817,5821]
param [5782,5786]
===
match
---
suite [10203,10758]
suite [10245,10800]
===
match
---
name: method [7426,7432]
name: method [7468,7474]
===
match
---
operator: = [4744,4745]
operator: = [4709,4710]
===
match
---
operator: , [3013,3014]
operator: , [3013,3014]
===
match
---
expr_stmt [1338,1401]
expr_stmt [1338,1401]
===
match
---
string: 'SUCCESS' [2983,2992]
string: 'SUCCESS' [2983,2992]
===
match
---
tfpdef [4218,4241]
tfpdef [4218,4241]
===
match
---
name: info [6405,6409]
name: info [6447,6451]
===
match
---
operator: = [6449,6450]
operator: = [6491,6492]
===
match
---
name: self [2180,2184]
name: self [2180,2184]
===
match
---
name: json [9752,9756]
name: json [9794,9798]
===
match
---
name: SUBMIT_RUN_ENDPOINT [1580,1599]
name: SUBMIT_RUN_ENDPOINT [1580,1599]
===
match
---
atom_expr [3054,3081]
atom_expr [3054,3081]
===
match
---
trailer [2723,2746]
trailer [2723,2746]
===
match
---
name: str [4811,4814]
name: str [4776,4779]
===
match
---
atom_expr [6462,6504]
atom_expr [6504,6546]
===
match
---
trailer [7366,7672]
trailer [7408,7714]
===
match
---
string: 'Authorization' [13061,13076]
string: 'Authorization' [13103,13118]
===
match
---
string: """     Interact with Databricks.      :param databricks_conn_id: Reference to the :ref:`Databricks connection <howto/connection:databricks>`.     :type databricks_conn_id: str     :param timeout_seconds: The amount of time in seconds the requests library         will wait before timing-out.     :type timeout_seconds: int     :param retry_limit: The number of times to retry the connection in case of         service outages.     :type retry_limit: int     :param retry_delay: The number of seconds to wait between retries (it         might be a floating point number).     :type retry_delay: float     """ [3422,4030]
string: """     Interact with Databricks.      :param databricks_conn_id: Reference to the :ref:`Databricks connection <howto/connection:databricks>`.     :type databricks_conn_id: str     :param timeout_seconds: The amount of time in seconds the requests library         will wait before timing-out.     :type timeout_seconds: int     :param retry_limit: The number of times to retry the connection in case of         service outages.     :type retry_limit: int     :param retry_delay: The number of seconds to wait between retries (it         might be a floating point number).     :type retry_delay: float     """ [3422,4030]
===
match
---
string: 'run_id' [9469,9477]
string: 'run_id' [9511,9519]
===
match
---
fstring [6917,6963]
fstring [6959,7005]
===
match
---
operator: = [1545,1546]
operator: = [1545,1546]
===
match
---
name: USER_AGENT_HEADER [7586,7603]
name: USER_AGENT_HEADER [7628,7645]
===
match
---
name: extra_dejson [6483,6495]
name: extra_dejson [6525,6537]
===
match
---
arglist [9418,9443]
arglist [9460,9485]
===
match
---
name: str [3365,3368]
name: str [3365,3368]
===
match
---
name: GET_RUN_ENDPOINT [10411,10427]
name: GET_RUN_ENDPOINT [10453,10469]
===
match
---
simple_stmt [1462,1527]
simple_stmt [1462,1527]
===
match
---
operator: } [9695,9696]
operator: } [9737,9738]
===
match
---
trailer [12360,12391]
trailer [12402,12433]
===
match
---
trailer [2135,2152]
trailer [2135,2152]
===
match
---
operator: -> [10797,10799]
operator: -> [10839,10841]
===
match
---
atom_expr [2180,2197]
atom_expr [2180,2197]
===
match
---
testlist_comp [12671,12749]
testlist_comp [12713,12791]
===
match
---
atom_expr [3369,3382]
atom_expr [3369,3382]
===
match
---
simple_stmt [7987,8130]
simple_stmt [8029,8172]
===
match
---
string: 'Using token auth. ' [6410,6430]
string: 'Using token auth. ' [6452,6472]
===
match
---
simple_stmt [5656,5677]
simple_stmt [5621,5642]
===
match
---
trailer [11640,11653]
trailer [11682,11695]
===
match
---
name: str [2109,2112]
name: str [2109,2112]
===
match
---
trailer [6610,6626]
trailer [6652,6668]
===
match
---
name: _do_api_call [5783,5795]
name: _do_api_call [5748,5760]
===
match
---
suite [6992,7033]
suite [7034,7075]
===
match
---
name: auth [6790,6794]
name: auth [6832,6836]
===
match
---
operator: , [9437,9438]
operator: , [9479,9480]
===
match
---
name: patch [7173,7178]
name: patch [7215,7220]
===
match
---
string: 'host' [6521,6527]
string: 'host' [6563,6569]
===
match
---
operator: = [4324,4325]
operator: = [4324,4325]
===
match
---
name: json [11440,11444]
name: json [11482,11486]
===
match
---
trailer [9720,9733]
trailer [9762,9775]
===
match
---
operator: -> [13023,13025]
operator: -> [13065,13067]
===
match
---
tfpdef [2075,2092]
tfpdef [2075,2092]
===
match
---
dictorsetmaker [10909,10925]
dictorsetmaker [10951,10967]
===
match
---
param [9824,9835]
param [9866,9877]
===
match
---
name: requests [7020,7028]
name: requests [7062,7070]
===
match
---
fstring_string: , Status Code:  [8067,8082]
fstring_string: , Status Code:  [8109,8124]
===
match
---
name: state [10664,10669]
name: state [10706,10711]
===
match
---
name: databricks_conn_id [4439,4457]
name: databricks_conn_id [4439,4457]
===
match
---
simple_stmt [1249,1297]
simple_stmt [1249,1297]
===
match
---
name: databricks_conn [4471,4486]
name: databricks_conn [4471,4486]
===
match
---
simple_stmt [1035,1058]
simple_stmt [1035,1058]
===
match
---
suite [6383,6716]
suite [6425,6758]
===
match
---
atom_expr [7993,8129]
atom_expr [8035,8171]
===
match
---
name: host [6869,6873]
name: host [6911,6915]
===
match
---
name: timeout_seconds [7638,7653]
name: timeout_seconds [7680,7695]
===
match
---
name: base [1316,1320]
name: base [1316,1320]
===
match
---
if_stmt [6335,6902]
if_stmt [6377,6944]
===
match
---
raise_stmt [8252,8402]
raise_stmt [8294,8444]
===
match
---
name: r [13051,13052]
name: r [13093,13094]
===
match
---
suite [9104,9479]
suite [9146,9521]
===
match
---
operator: == [7507,7509]
operator: == [7549,7551]
===
match
---
trailer [5541,5550]
trailer [5506,5515]
===
match
---
dotted_name [1254,1272]
dotted_name [1254,1272]
===
match
---
name: isinstance [12456,12466]
name: isinstance [12498,12508]
===
match
---
name: PreparedRequest [1130,1145]
name: PreparedRequest [1130,1145]
===
match
---
operator: = [10662,10663]
operator: = [10704,10705]
===
match
---
operator: = [9398,9399]
operator: = [9440,9441]
===
match
---
operator: = [10606,10607]
operator: = [10648,10649]
===
match
---
string: "api/2.0/clusters/delete" [1500,1525]
string: "api/2.0/clusters/delete" [1500,1525]
===
match
---
trailer [8564,8647]
trailer [8606,8689]
===
match
---
try_stmt [7322,8187]
try_stmt [7364,8229]
===
match
---
param [4271,4298]
param [4271,4298]
===
match
---
import_name [1093,1108]
import_name [1093,1108]
===
match
---
operator: = [2240,2241]
operator: = [2240,2241]
===
match
---
operator: , [13001,13002]
operator: , [13043,13044]
===
match
---
name: _parse_host [6594,6605]
name: _parse_host [6636,6647]
===
match
---
name: self [2378,2382]
name: self [2378,2382]
===
match
---
suite [5823,8469]
suite [5788,8511]
===
match
---
suite [2122,2256]
suite [2122,2256]
===
match
---
name: bool [2300,2304]
name: bool [2300,2304]
===
match
---
operator: , [12929,12930]
operator: , [12971,12972]
===
match
---
expr_stmt [10348,10373]
expr_stmt [10390,10415]
===
match
---
name: bool [3033,3037]
name: bool [3033,3037]
===
match
---
operator: -> [11491,11493]
operator: -> [11533,11535]
===
match
---
atom_expr [8048,8066]
atom_expr [8090,8108]
===
match
---
string: """True if the result state is SUCCESS""" [2905,2946]
string: """True if the result state is SUCCESS""" [2905,2946]
===
match
---
file_input [787,13120]
file_input [787,13162]
===
match
---
arglist [12007,12034]
arglist [12049,12076]
===
match
---
name: __init__ [2037,2045]
name: __init__ [2037,2045]
===
match
---
string: 'Retry limit must be greater than equal to 1' [4633,4678]
string: 'Retry limit must be greater than equal to 1' [4598,4643]
===
match
---
suite [8690,9059]
suite [8732,9101]
===
match
---
name: result_state [3237,3249]
name: result_state [3237,3249]
===
match
---
suite [4377,4758]
suite [4377,4723]
===
match
---
argument [7413,7463]
argument [7455,7505]
===
match
---
name: endpoint_info [6312,6325]
name: endpoint_info [6277,6290]
===
match
---
name: self [11989,11993]
name: self [12031,12035]
===
match
---
fstring_string: airflow- [1787,1795]
fstring_string: airflow- [1787,1795]
===
match
---
atom_expr [12516,12543]
atom_expr [12558,12585]
===
match
---
trailer [12566,12575]
trailer [12608,12617]
===
match
---
atom_expr [11166,11215]
atom_expr [11208,11257]
===
match
---
name: json [7418,7422]
name: json [7460,7464]
===
match
---
funcdef [12041,12392]
funcdef [12083,12434]
===
match
---
fstring [8035,8107]
fstring [8077,8149]
===
match
---
operator: , [4297,4298]
operator: , [4297,4298]
===
match
---
operator: = [4437,4438]
operator: = [4437,4438]
===
match
---
trailer [12466,12545]
trailer [12508,12587]
===
match
---
expr_stmt [7149,7178]
expr_stmt [7191,7220]
===
match
---
simple_stmt [9540,9663]
simple_stmt [9582,9705]
===
match
---
string: """         The purpose of this function is to be robust to improper connections         settings provided by users, specifically in the host field.          For example -- when users supply ``https://xx.cloud.databricks.com`` as the         host, we must strip out the protocol to get the host.::              h = DatabricksHook()             assert h._parse_host('https://xx.cloud.databricks.com') == \                 'xx.cloud.databricks.com'          In the case where users supply the correct ``xx.cloud.databricks.com`` as the         host, this function is a no-op.::              assert h._parse_host('xx.cloud.databricks.com') == 'xx.cloud.databricks.com'          """ [4824,5502]
string: """         The purpose of this function is to be robust to improper connections         settings provided by users, specifically in the host field.          For example -- when users supply ``https://xx.cloud.databricks.com`` as the         host, we must strip out the protocol to get the host.::              h = DatabricksHook()             assert h._parse_host('https://xx.cloud.databricks.com') == \                 'xx.cloud.databricks.com'          In the case where users supply the correct ``xx.cloud.databricks.com`` as the         host, this function is a no-op.::              assert h._parse_host('xx.cloud.databricks.com') == 'xx.cloud.databricks.com'          """ [4789,5467]
===
match
---
if_stmt [2375,2761]
if_stmt [2375,2761]
===
match
---
string: 'Giving up.' [8346,8358]
string: 'Giving up.' [8388,8400]
===
match
---
name: format [2717,2723]
name: format [2717,2723]
===
match
---
name: USER_AGENT_HEADER [1750,1767]
name: USER_AGENT_HEADER [1750,1767]
===
match
---
return_stmt [10695,10757]
return_stmt [10737,10799]
===
match
---
simple_stmt [2314,2367]
simple_stmt [2314,2367]
===
match
---
name: exception [12600,12609]
name: exception [12642,12651]
===
match
---
name: self [2724,2728]
name: self [2724,2728]
===
match
---
atom [1770,1810]
atom [1770,1810]
===
match
---
name: databricks_conn_id [4418,4436]
name: databricks_conn_id [4418,4436]
===
match
---
suite [8235,8403]
suite [8277,8445]
===
match
---
trailer [6755,6777]
trailer [6797,6819]
===
match
---
tfpdef [9085,9095]
tfpdef [9127,9137]
===
match
---
param [12415,12424]
param [12457,12466]
===
match
---
testlist_star_expr [6293,6309]
testlist_star_expr [6258,6274]
===
match
---
name: run_id [10784,10790]
name: run_id [10826,10832]
===
match
---
param [13003,13021]
param [13045,13063]
===
match
---
trailer [4541,4557]
trailer [4506,4522]
===
match
---
atom_expr [9716,9757]
atom_expr [9758,9799]
===
match
---
operator: , [7463,7464]
operator: , [7505,7506]
===
match
---
funcdef [2033,2256]
funcdef [2033,2256]
===
match
---
name: json [10028,10032]
name: json [10070,10074]
===
match
---
name: self [6462,6466]
name: self [6504,6508]
===
match
---
name: urlparse_host [5562,5575]
name: urlparse_host [5527,5540]
===
match
---
operator: = [1425,1426]
operator: = [1425,1426]
===
match
---
atom_expr [8445,8468]
atom_expr [8487,8510]
===
match
---
param [2882,2886]
param [2882,2886]
===
match
---
comparison [3266,3307]
comparison [3266,3307]
===
match
---
simple_stmt [6790,6857]
simple_stmt [6832,6899]
===
match
---
return_stmt [7733,7755]
return_stmt [7775,7797]
===
match
---
name: databricks_conn [6611,6626]
name: databricks_conn [6653,6668]
===
match
---
name: _do_api_call [11171,11183]
name: _do_api_call [11213,11225]
===
match
---
string: 'POST' [1603,1609]
string: 'POST' [1603,1609]
===
match
---
name: self [4688,4692]
name: self [4653,4657]
===
match
---
name: databricks_conn [6803,6818]
name: databricks_conn [6845,6860]
===
match
---
tfpdef [8503,8519]
tfpdef [8545,8561]
===
match
---
name: self [3210,3214]
name: self [3210,3214]
===
match
---
operator: == [8215,8217]
operator: == [8257,8259]
===
match
---
simple_stmt [2955,2993]
simple_stmt [2955,2993]
===
match
---
name: error [8559,8564]
name: error [8601,8606]
===
match
---
operator: , [1609,1610]
operator: , [1609,1610]
===
match
---
name: self [6690,6694]
name: self [6732,6736]
===
match
---
string: """         Utility function to call the ``api/2.0/jobs/runs/submit`` endpoint.          :param json: The data used in the body of the request to the ``submit`` endpoint.         :type json: dict         :return: the run_id as a string         :rtype: str         """ [9113,9380]
string: """         Utility function to call the ``api/2.0/jobs/runs/submit`` endpoint.          :param json: The data used in the body of the request to the ``submit`` endpoint.         :type json: dict         :return: the run_id as a string         :rtype: str         """ [9155,9422]
===
match
---
trailer [9468,9478]
trailer [9510,9520]
===
match
---
string: 'run_id' [9679,9687]
string: 'run_id' [9721,9729]
===
match
---
name: AirflowException [1280,1296]
name: AirflowException [1280,1296]
===
match
---
name: str [12938,12941]
name: str [12980,12983]
===
match
---
string: """         Terminates the cluster.          :param json: json dictionary containing cluster specification.         """ [11508,11627]
string: """         Terminates the cluster.          :param json: json dictionary containing cluster specification.         """ [11550,11669]
===
match
---
name: parse [1070,1075]
name: parse [1070,1075]
===
match
---
arglist [10411,10433]
arglist [10453,10475]
===
match
---
name: get_job_id [9807,9817]
name: get_job_id [9849,9859]
===
match
---
name: host [6582,6586]
name: host [6624,6628]
===
match
---
name: get [10614,10617]
name: get [10656,10659]
===
match
---
name: _parse_host [6933,6944]
name: _parse_host [6975,6986]
===
match
---
trailer [10077,10090]
trailer [10119,10132]
===
match
---
atom_expr [12479,12514]
atom_expr [12521,12556]
===
match
---
atom_expr [6798,6824]
atom_expr [6840,6866]
===
match
---
string: """         Utility function to call the ``api/2.0/jobs/run-now`` endpoint.          :param json: The data used in the body of the request to the ``run-now`` endpoint.         :type json: dict         :return: the run_id as a string         :rtype: str         """ [8699,8963]
string: """         Utility function to call the ``api/2.0/jobs/run-now`` endpoint.          :param json: The data used in the body of the request to the ``run-now`` endpoint.         :type json: dict         :return: the run_id as a string         :rtype: str         """ [8741,9005]
===
match
---
name: requests [7164,7172]
name: requests [7206,7214]
===
match
---
name: json [9019,9023]
name: json [9061,9065]
===
match
---
simple_stmt [4616,4680]
simple_stmt [4581,4645]
===
match
---
trailer [7794,7811]
trailer [7836,7853]
===
match
---
arglist [10091,10113]
arglist [10133,10155]
===
match
---
name: self [4413,4417]
name: self [4413,4417]
===
match
---
name: raise_for_status [7698,7714]
name: raise_for_status [7740,7756]
===
match
---
trailer [6535,6551]
trailer [6577,6593]
===
match
---
operator: = [10494,10495]
operator: = [10536,10537]
===
match
---
expr_stmt [10901,10926]
expr_stmt [10943,10968]
===
match
---
name: self [4537,4541]
name: self [4502,4506]
===
match
---
name: json [10109,10113]
name: json [10151,10155]
===
match
---
trailer [10138,10148]
trailer [10180,10190]
===
match
---
trailer [6710,6715]
trailer [6752,6757]
===
match
---
name: property [2851,2859]
name: property [2851,2859]
===
match
---
simple_stmt [1812,1874]
simple_stmt [1812,1874]
===
match
---
dictorsetmaker [10036,10052]
dictorsetmaker [10078,10094]
===
match
---
operator: = [12668,12669]
operator: = [12710,12711]
===
match
---
parameters [9078,9096]
parameters [9120,9138]
===
match
---
operator: = [4096,4097]
operator: = [4096,4097]
===
match
---
param [3015,3028]
param [3015,3028]
===
match
---
simple_stmt [10348,10374]
simple_stmt [10390,10416]
===
match
---
operator: , [5815,5816]
operator: , [5780,5781]
===
match
---
operator: , [12680,12681]
operator: , [12722,12723]
===
match
---
string: 'SKIPPED' [2816,2825]
string: 'SKIPPED' [2816,2825]
===
match
---
expr_stmt [7343,7672]
expr_stmt [7385,7714]
===
match
---
name: RunState [10194,10202]
name: RunState [10236,10244]
===
match
---
string: """         Utility function to perform an API call with retries          :param endpoint_info: Tuple of method and endpoint         :type endpoint_info: tuple[string, string]         :param json: Parameters for this API call.         :type json: dict         :return: If the api call returns a OK status code,             this function returns the response in JSON. Otherwise,             we throw an AirflowException.         :rtype: dict         """ [5832,6284]
string: """         Utility function to perform an API call with retries          :param endpoint_info: Tuple of method and endpoint         :type endpoint_info: tuple[string, string]         :param json: Parameters for this API call.         :type json: dict         :return: If the api call returns a OK status code,             this function returns the response in JSON. Otherwise,             we throw an AirflowException.         :rtype: dict         """ [5797,6249]
===
match
---
operator: = [4162,4163]
operator: = [4162,4163]
===
match
---
name: __version__ [1796,1807]
name: __version__ [1796,1807]
===
match
---
name: sleep [1052,1057]
name: sleep [1052,1057]
===
match
---
operator: , [4261,4262]
operator: , [4261,4262]
===
match
---
operator: , [5800,5801]
operator: , [5765,5766]
===
match
---
atom [7436,7453]
atom [7478,7495]
===
match
---
name: _do_api_call [12348,12360]
name: _do_api_call [12390,12402]
===
match
---
name: self [9716,9720]
name: self [9758,9762]
===
match
---
simple_stmt [1580,1639]
simple_stmt [1580,1639]
===
match
---
comparison [8203,8234]
comparison [8245,8276]
===
match
---
simple_stmt [2221,2256]
simple_stmt [2221,2256]
===
match
---
trailer [4402,4404]
trailer [4402,4404]
===
match
---
atom_expr [13092,13102]
atom_expr [13134,13144]
===
match
---
expr_stmt [6293,6325]
expr_stmt [6258,6290]
===
match
---
string: 'Databricks' [4164,4176]
string: 'Databricks' [4164,4176]
===
match
---
name: json [9671,9675]
name: json [9713,9717]
===
match
---
name: int [8516,8519]
name: int [8558,8561]
===
match
---
param [2052,2074]
param [2052,2074]
===
match
---
simple_stmt [10901,10927]
simple_stmt [10943,10969]
===
match
---
and_test [3146,3307]
and_test [3146,3307]
===
match
---
name: other [3171,3176]
name: other [3171,3176]
===
match
---
string: """     Helper class for requests Auth field. AuthBase requires you to implement the __call__     magic function.     """ [12785,12906]
string: """     Helper class for requests Auth field. AuthBase requires you to implement the __call__     magic function.     """ [12827,12948]
===
match
---
name: self [12960,12964]
name: self [13002,13006]
===
match
---
arglist [8565,8646]
arglist [8607,8688]
===
match
---
name: requests_exceptions [1161,1180]
name: requests_exceptions [1161,1180]
===
match
---
simple_stmt [8252,8403]
simple_stmt [8294,8445]
===
match
---
trailer [8366,8384]
trailer [8408,8426]
===
match
---
name: Timeout [12536,12543]
name: Timeout [12578,12585]
===
match
---
operator: = [6587,6588]
operator: = [6629,6630]
===
match
---
simple_stmt [9033,9059]
simple_stmt [9075,9101]
===
match
---
trailer [10952,10979]
trailer [10994,11021]
===
match
---
name: json [11210,11214]
name: json [11252,11256]
===
match
---
name: int [4320,4323]
name: int [4320,4323]
===
match
---
name: self [8497,8501]
name: self [8539,8543]
===
match
---
simple_stmt [10212,10340]
simple_stmt [10254,10382]
===
match
---
atom_expr [3171,3193]
atom_expr [3171,3193]
===
match
---
name: run_id [9511,9517]
name: run_id [9553,9559]
===
match
---
atom [1658,1690]
atom [1658,1690]
===
match
---
operator: } [6950,6951]
operator: } [6992,6993]
===
match
---
string: 'SKIPPED' [12722,12731]
string: 'SKIPPED' [12764,12773]
===
match
---
name: response [7740,7748]
name: response [7782,7790]
===
match
---
expr_stmt [2131,2171]
expr_stmt [2131,2171]
===
match
---
atom [1602,1638]
atom [1602,1638]
===
match
---
name: PreparedRequest [13026,13041]
name: PreparedRequest [13068,13083]
===
match
---
name: BaseHook [3407,3415]
name: BaseHook [3407,3415]
===
match
---
atom_expr [3210,3227]
atom_expr [3210,3227]
===
match
---
simple_stmt [4386,4405]
simple_stmt [4386,4405]
===
match
---
if_stmt [6973,7265]
if_stmt [7015,7307]
===
match
---
string: 'Attempt %s API Request to Databricks failed with reason: %s' [8565,8626]
string: 'Attempt %s API Request to Databricks failed with reason: %s' [8607,8668]
===
match
---
testlist_comp [1659,1689]
testlist_comp [1659,1689]
===
match
---
parameters [9817,9836]
parameters [9859,9878]
===
match
---
string: 'user-agent' [1771,1783]
string: 'user-agent' [1771,1783]
===
match
---
simple_stmt [10477,10522]
simple_stmt [10519,10564]
===
match
---
suite [4603,4680]
suite [4568,4645]
===
match
---
atom [12670,12750]
atom [12712,12792]
===
match
---
expr_stmt [4466,4528]
expr_stmt [4466,4493]
===
match
---
trailer [4470,4486]
trailer [4470,4486]
===
match
---
trailer [10617,10639]
trailer [10659,10681]
===
match
---
operator: { [6927,6928]
operator: { [6969,6970]
===
match
---
trailer [8049,8058]
trailer [8091,8100]
===
match
---
name: self [2882,2886]
name: self [2882,2886]
===
match
---
fstring_end: ' [6962,6963]
fstring_end: ' [7004,7005]
===
match
---
not_test [7837,7860]
not_test [7879,7902]
===
match
---
trailer [8450,8468]
trailer [8492,8510]
===
match
---
expr_stmt [1639,1690]
expr_stmt [1639,1690]
===
match
---
name: self [3369,3373]
name: self [3369,3373]
===
match
---
string: """         Starts the cluster.          :param json: json dictionary containing cluster specification.         """ [11274,11389]
string: """         Starts the cluster.          :param json: json dictionary containing cluster specification.         """ [11316,11431]
===
match
---
operator: , [4208,4209]
operator: , [4208,4209]
===
match
---
expr_stmt [4688,4718]
expr_stmt [4653,4683]
===
match
---
name: default_conn_name [4244,4261]
name: default_conn_name [4244,4261]
===
match
---
name: response [12610,12618]
name: response [12652,12660]
===
match
---
operator: = [1489,1490]
operator: = [1489,1490]
===
match
---
name: state [10496,10501]
name: state [10538,10543]
===
match
---
return_stmt [9033,9058]
return_stmt [9075,9100]
===
match
---
expr_stmt [1528,1579]
expr_stmt [1528,1579]
===
match
---
operator: { [8082,8083]
operator: { [8124,8125]
===
match
---
operator: , [9750,9751]
operator: , [9792,9793]
===
match
---
param [9079,9084]
param [9121,9126]
===
match
---
expr_stmt [6790,6856]
expr_stmt [6832,6898]
===
match
---
atom_expr [12343,12391]
atom_expr [12385,12433]
===
match
---
trailer [11170,11183]
trailer [11212,11225]
===
match
---
trailer [3064,3081]
trailer [3064,3081]
===
match
---
trailer [6802,6818]
trailer [6844,6860]
===
match
---
name: state_message [10648,10661]
name: state_message [10690,10703]
===
match
---
funcdef [8474,8648]
funcdef [8516,8690]
===
match
---
testlist_comp [1548,1578]
testlist_comp [1548,1578]
===
match
---
name: databricks_conn_id [4218,4236]
name: databricks_conn_id [4218,4236]
===
match
---
param [4337,4362]
param [4337,4362]
===
match
---
suite [9844,10149]
suite [9886,10191]
===
match
---
trailer [10397,10410]
trailer [10439,10452]
===
match
---
string: 'TERMINATED' [12708,12720]
string: 'TERMINATED' [12750,12762]
===
match
---
trailer [4391,4393]
trailer [4391,4393]
===
match
---
operator: -> [12426,12428]
operator: -> [12468,12470]
===
match
---
name: self [9079,9083]
name: self [9121,9125]
===
match
---
trailer [6639,6647]
trailer [6681,6689]
===
match
---
comparison [2378,2428]
comparison [2378,2428]
===
match
---
dotted_name [1302,1320]
dotted_name [1302,1320]
===
match
---
string: 'state' [10460,10467]
string: 'state' [10502,10509]
===
match
---
simple_stmt [12785,12907]
simple_stmt [12827,12949]
===
match
---
simple_stmt [12646,12751]
simple_stmt [12688,12793]
===
match
---
trailer [2966,2979]
trailer [2966,2979]
===
match
---
trailer [8151,8170]
trailer [8193,8212]
===
match
---
operator: , [1720,1721]
operator: , [1720,1721]
===
match
---
operator: } [10052,10053]
operator: } [10094,10095]
===
match
---
simple_stmt [7005,7033]
simple_stmt [7047,7075]
===
match
---
operator: , [12059,12060]
operator: , [12101,12102]
===
match
---
name: json [9085,9089]
name: json [9127,9131]
===
match
---
string: 'databricks' [4135,4147]
string: 'databricks' [4135,4147]
===
match
---
param [10778,10783]
param [10820,10825]
===
match
---
fstring_start: f' [1785,1787]
fstring_start: f' [1785,1787]
===
match
---
operator: , [11438,11439]
operator: , [11480,11481]
===
match
---
name: retry_limit [4693,4704]
name: retry_limit [4658,4669]
===
match
---
testlist_comp [1366,1400]
testlist_comp [1366,1400]
===
match
---
name: uninstall [12045,12054]
name: uninstall [12087,12096]
===
match
---
trailer [3373,3382]
trailer [3373,3382]
===
match
---
operator: , [12706,12707]
operator: , [12748,12749]
===
match
---
operator: + [7255,7256]
operator: + [7297,7298]
===
match
---
operator: , [1498,1499]
operator: , [1498,1499]
===
match
---
suite [12780,13120]
suite [12822,13162]
===
match
---
name: str [4238,4241]
name: str [4238,4241]
===
match
---
comparison [2776,2844]
comparison [2776,2844]
===
match
---
trailer [4731,4743]
trailer [4696,4708]
===
match
---
name: self [10073,10077]
name: self [10115,10119]
===
match
---
string: 'Unexpected HTTP Method: ' [7228,7254]
string: 'Unexpected HTTP Method: ' [7270,7296]
===
match
---
name: state_message [3294,3307]
name: state_message [3294,3307]
===
match
---
string: 'databricks_conn_id' [4053,4073]
string: 'databricks_conn_id' [4053,4073]
===
match
---
simple_stmt [4688,4719]
simple_stmt [4653,4684]
===
match
---
name: self [10172,10176]
name: self [10214,10218]
===
match
---
trailer [11415,11445]
trailer [11457,11487]
===
match
---
operator: = [6874,6875]
operator: = [6916,6917]
===
match
---
arglist [9734,9756]
arglist [9776,9798]
===
match
---
name: self [2291,2295]
name: self [2291,2295]
===
match
---
funcdef [11451,11688]
funcdef [11493,11730]
===
match
---
name: info [6751,6755]
name: info [6793,6797]
===
match
---
name: RunState [1948,1956]
name: RunState [1948,1956]
===
match
---
name: bool [2891,2895]
name: bool [2891,2895]
===
match
---
name: dict [11485,11489]
name: dict [11527,11531]
===
match
---
param [11705,11710]
param [11747,11752]
===
match
---
string: 'RUNNING' [12682,12691]
string: 'RUNNING' [12724,12733]
===
match
---
operator: = [2153,2154]
operator: = [2153,2154]
===
match
---
name: self [6531,6535]
name: self [6573,6577]
===
match
---
arglist [12467,12544]
arglist [12509,12586]
===
match
---
name: other [3065,3070]
name: other [3065,3070]
===
match
---
funcdef [9064,9479]
funcdef [9106,9521]
===
match
---
funcdef [11221,11446]
funcdef [11263,11488]
===
match
---
simple_stmt [11040,11158]
simple_stmt [11082,11200]
===
match
---
string: 'POST' [7056,7062]
string: 'POST' [7098,7104]
===
match
---
atom_expr [10935,10979]
atom_expr [10977,11021]
===
match
---
param [9511,9522]
param [9553,9564]
===
match
---
name: login [6819,6824]
name: login [6861,6866]
===
match
---
name: int [4288,4291]
name: int [4288,4291]
===
match
---
name: response [7689,7697]
name: response [7731,7739]
===
match
---
param [8497,8502]
param [8539,8544]
===
match
---
trailer [7099,7104]
trailer [7141,7146]
===
match
---
name: __init__ [4186,4194]
name: __init__ [4186,4194]
===
match
---
name: attempt_num [8416,8427]
name: attempt_num [8458,8469]
===
match
---
name: token [12965,12970]
name: token [13007,13012]
===
match
---
suite [1957,3384]
suite [1957,3384]
===
match
---
strings [2504,2698]
strings [2504,2698]
===
match
---
operator: , [10632,10633]
operator: , [10674,10675]
===
match
---
name: run_id [9824,9830]
name: run_id [9866,9872]
===
match
---
name: START_CLUSTER_ENDPOINT [1402,1424]
name: START_CLUSTER_ENDPOINT [1402,1424]
===
match
---
fstring_string: https:// [6919,6927]
fstring_string: https:// [6961,6969]
===
match
---
operator: = [10071,10072]
operator: = [10113,10114]
===
match
---
arith_expr [7228,7263]
arith_expr [7270,7305]
===
match
---
comparison [3146,3193]
comparison [3146,3193]
===
match
---
operator: = [5525,5526]
operator: = [5490,5491]
===
match
---
name: submit_run [9068,9078]
name: submit_run [9110,9120]
===
match
---
name: float [4350,4355]
name: float [4350,4355]
===
match
---
trailer [7714,7716]
trailer [7756,7758]
===
match
---
atom_expr [4413,4436]
atom_expr [4413,4436]
===
match
---
operator: { [8047,8048]
operator: { [8089,8090]
===
match
---
trailer [8558,8564]
trailer [8600,8606]
===
match
---
name: cancel_run [10767,10777]
name: cancel_run [10809,10819]
===
match
---
simple_stmt [6869,6902]
simple_stmt [6911,6944]
===
match
---
comparison [7500,7515]
comparison [7542,7557]
===
match
---
atom_expr [8083,8105]
atom_expr [8125,8147]
===
match
---
name: token [12931,12936]
name: token [12973,12978]
===
match
---
atom_expr [12557,12575]
atom_expr [12599,12617]
===
match
---
name: response [8085,8093]
name: response [8127,8135]
===
match
---
trailer [8170,8186]
trailer [8212,8228]
===
match
---
funcdef [10985,11216]
funcdef [11027,11258]
===
match
---
suite [3349,3384]
suite [3349,3384]
===
match
---
tfpdef [11011,11021]
tfpdef [11053,11063]
===
match
---
operator: = [7352,7353]
operator: = [7394,7395]
===
match
---
simple_stmt [7733,7756]
simple_stmt [7775,7798]
===
match
---
name: attempt_num [8503,8514]
name: attempt_num [8545,8556]
===
match
---
name: json [10348,10352]
name: json [10390,10394]
===
match
---
atom_expr [7775,7811]
atom_expr [7817,7853]
===
match
---
name: str [3345,3348]
name: str [3345,3348]
===
match
---
string: "api/2.0/clusters/restart" [1374,1400]
string: "api/2.0/clusters/restart" [1374,1400]
===
match
---
operator: , [10972,10973]
operator: , [11014,11015]
===
match
---
name: e [7815,7816]
name: e [7857,7858]
===
match
---
atom_expr [7091,7104]
atom_expr [7133,7146]
===
match
---
param [12925,12930]
param [12967,12972]
===
match
---
atom_expr [6349,6382]
atom_expr [6391,6424]
===
match
---
name: __eq__ [3002,3008]
name: __eq__ [3002,3008]
===
match
---
import_from [1249,1296]
import_from [1249,1296]
===
match
---
name: urlparse [1083,1091]
name: urlparse [1083,1091]
===
match
---
operator: , [10176,10177]
operator: , [10218,10219]
===
match
---
string: 'api/2.0/jobs/run-now' [1556,1578]
string: 'api/2.0/jobs/run-now' [1556,1578]
===
match
---
trailer [6830,6846]
trailer [6872,6888]
===
match
---
operator: + [13090,13091]
operator: + [13132,13133]
===
match
---
operator: , [2050,2051]
operator: , [2050,2051]
===
match
---
name: INSTALL_LIBS_ENDPOINT [1812,1833]
name: INSTALL_LIBS_ENDPOINT [1812,1833]
===
match
---
fstring_end: ' [8106,8107]
fstring_end: ' [8148,8149]
===
match
---
atom_expr [7020,7032]
atom_expr [7062,7074]
===
match
---
simple_stmt [10443,10469]
simple_stmt [10485,10511]
===
match
---
operator: = [10033,10034]
operator: = [10075,10076]
===
match
---
string: 'api/2.0/libraries/uninstall' [1909,1938]
string: 'api/2.0/libraries/uninstall' [1909,1938]
===
match
---
operator: , [8626,8627]
operator: , [8668,8669]
===
match
---
trailer [8359,8366]
trailer [8401,8408]
===
match
---
trailer [12964,12970]
trailer [13006,13012]
===
match
---
testlist_comp [1428,1460]
testlist_comp [1428,1460]
===
match
---
operator: , [1434,1435]
operator: , [1434,1435]
===
match
---
string: 'API requests to Databricks failed {} times. ' [8297,8343]
string: 'API requests to Databricks failed {} times. ' [8339,8385]
===
match
---
parameters [11004,11022]
parameters [11046,11064]
===
match
---
operator: , [12028,12029]
operator: , [12070,12071]
===
match
---
name: self [11398,11402]
name: self [11440,11444]
===
match
---
param [2046,2051]
param [2046,2051]
===
match
---
expr_stmt [6582,6648]
expr_stmt [6624,6690]
===
match
---
simple_stmt [7343,7673]
simple_stmt [7385,7715]
===
match
---
string: 'token' [6338,6345]
string: 'token' [6380,6387]
===
match
---
name: self [9505,9509]
name: self [9547,9551]
===
match
---
trailer [4417,4436]
trailer [4417,4436]
===
match
---
name: BaseHook [1328,1336]
name: BaseHook [1328,1336]
===
match
---
name: _parse_host [4785,4796]
name: _parse_host [4750,4761]
===
match
---
name: str [9527,9530]
name: str [9569,9572]
===
match
---
atom_expr [8258,8402]
atom_expr [8300,8444]
===
match
---
atom_expr [12456,12545]
atom_expr [12498,12587]
===
match
---
name: self [3009,3013]
name: self [3009,3013]
===
match
---
operator: , [12384,12385]
operator: , [12426,12427]
===
match
---
operator: -> [8683,8685]
operator: -> [8725,8727]
===
match
---
simple_stmt [1338,1402]
simple_stmt [1338,1402]
===
match
---
string: 'INTERNAL_ERROR' [12733,12749]
string: 'INTERNAL_ERROR' [12775,12791]
===
match
---
name: AirflowException [7993,8009]
name: AirflowException [8035,8051]
===
match
---
funcdef [9803,10149]
funcdef [9845,10191]
===
match
---
name: databricks_conn [6467,6482]
name: databricks_conn [6509,6524]
===
match
---
string: 'run_id' [10036,10044]
string: 'run_id' [10078,10086]
===
match
---
name: __call__ [12988,12996]
name: __call__ [13030,13038]
===
match
---
suite [12081,12392]
suite [12123,12434]
===
match
---
name: PreparedRequest [13006,13021]
name: PreparedRequest [13048,13063]
===
match
---
name: self [13092,13096]
name: self [13134,13138]
===
match
---
name: requests [1100,1108]
name: requests [1100,1108]
===
match
---
simple_stmt [3095,3117]
simple_stmt [3095,3117]
===
match
---
simple_stmt [1402,1462]
simple_stmt [1402,1462]
===
match
---
tfpdef [11479,11489]
tfpdef [11521,11531]
===
match
---
string: 'POST' [1714,1720]
string: 'POST' [1714,1720]
===
match
---
operator: { [1795,1796]
operator: { [1795,1796]
===
match
---
name: self [12343,12347]
name: self [12385,12389]
===
match
---
trailer [7857,7860]
trailer [7899,7902]
===
match
---
trailer [6605,6648]
trailer [6647,6690]
===
match
---
operator: = [7632,7633]
operator: = [7674,7675]
===
match
---
decorator [4763,4777]
decorator [4728,4742]
===
match
---
name: result_state [2075,2087]
name: result_state [2075,2087]
===
match
---
atom_expr [8550,8647]
atom_expr [8592,8689]
===
match
---
name: AuthBase [12770,12778]
name: AuthBase [12812,12820]
===
match
---
expr_stmt [10443,10468]
expr_stmt [10485,10510]
===
match
---
param [4204,4209]
param [4204,4209]
===
match
---
operator: , [6824,6825]
operator: , [6866,6867]
===
match
---
name: retry_limit [4307,4318]
name: retry_limit [4307,4318]
===
match
---
name: other [3015,3020]
name: other [3015,3020]
===
match
---
name: _do_api_call [11641,11653]
name: _do_api_call [11683,11695]
===
match
---
simple_stmt [10593,10640]
simple_stmt [10635,10682]
===
match
---
name: timeout_seconds [4271,4286]
name: timeout_seconds [4271,4286]
===
match
---
operator: @ [2261,2262]
operator: @ [2261,2262]
===
match
---
tfpdef [11245,11255]
tfpdef [11287,11297]
===
match
---
simple_stmt [4078,4119]
simple_stmt [4078,4119]
===
match
---
trailer [6551,6564]
trailer [6593,6606]
===
match
---
name: RUN_NOW_ENDPOINT [9001,9017]
name: RUN_NOW_ENDPOINT [9043,9059]
===
match
---
simple_stmt [4824,5503]
simple_stmt [4789,5468]
===
match
---
string: """         Retrieves run state of the run.          :param run_id: id of the run         :return: state of the run         """ [10212,10339]
string: """         Retrieves run state of the run.          :param run_id: id of the run         :return: state of the run         """ [10254,10381]
===
match
---
operator: -> [9524,9526]
operator: -> [9566,9568]
===
match
---
funcdef [5779,8469]
funcdef [5744,8511]
===
match
---
name: object [3022,3028]
name: object [3022,3028]
===
match
---
suite [13042,13120]
suite [13084,13162]
===
match
---
name: RESTART_CLUSTER_ENDPOINT [1338,1362]
name: RESTART_CLUSTER_ENDPOINT [1338,1362]
===
match
---
funcdef [2864,2993]
funcdef [2864,2993]
===
match
---
name: default_conn_name [4078,4095]
name: default_conn_name [4078,4095]
===
match
---
name: _TokenAuth [6451,6461]
name: _TokenAuth [6493,6503]
===
match
---
name: auth [7547,7551]
name: auth [7589,7593]
===
match
---
expr_stmt [1462,1526]
expr_stmt [1462,1526]
===
match
---
funcdef [4182,4758]
funcdef [4182,4723]
===
match
---
string: 'run_id' [10356,10364]
string: 'run_id' [10398,10406]
===
match
---
import_from [1109,1180]
import_from [1109,1180]
===
match
---
operator: { [10355,10356]
operator: { [10397,10398]
===
match
---
operator: } [1809,1810]
operator: } [1809,1810]
===
match
---
operator: -> [12073,12075]
operator: -> [12115,12117]
===
match
---
atom_expr [7211,7264]
atom_expr [7253,7306]
===
match
---
simple_stmt [10814,10893]
simple_stmt [10856,10935]
===
match
---
name: params [7485,7491]
name: params [7527,7533]
===
match
---
name: _log_request_error [8478,8496]
name: _log_request_error [8520,8538]
===
match
---
name: result_state [2967,2979]
name: result_state [2967,2979]
===
match
---
atom_expr [4537,4557]
atom_expr [4502,4522]
===
match
---
name: host [6945,6949]
name: host [6987,6991]
===
match
---
string: 'api/2.0/libraries/install' [1845,1872]
string: 'api/2.0/libraries/install' [1845,1872]
===
match
---
parameters [2045,2113]
parameters [2045,2113]
===
match
---
operator: , [9017,9018]
operator: , [9059,9060]
===
match
---
expr_stmt [12960,12978]
expr_stmt [13002,13020]
===
match
---
number: 180 [4294,4297]
number: 180 [4294,4297]
===
match
---
name: run_id [10366,10372]
name: run_id [10408,10414]
===
match
---
name: hooks [1310,1315]
name: hooks [1310,1315]
===
match
---
name: life_cycle_state [2136,2152]
name: life_cycle_state [2136,2152]
===
match
---
parameters [12996,13022]
parameters [13038,13064]
===
match
---
suite [7136,7179]
suite [7178,7221]
===
match
---
argument [7547,7556]
argument [7589,7598]
===
match
---
trailer [6944,6950]
trailer [6986,6992]
===
match
---
expr_stmt [4413,4457]
expr_stmt [4413,4457]
===
match
---
name: self [8147,8151]
name: self [8189,8193]
===
match
---
name: json [7492,7496]
name: json [7534,7538]
===
match
---
name: json [11682,11686]
name: json [11724,11728]
===
match
---
name: json [11479,11483]
name: json [11521,11525]
===
match
---
tfpdef [4337,4355]
tfpdef [4337,4355]
===
match
---
atom_expr [10393,10434]
atom_expr [10435,10476]
===
match
---
param [9505,9510]
param [9547,9552]
===
match
---
expr_stmt [4036,4073]
expr_stmt [4036,4073]
===
match
---
operator: = [4356,4357]
operator: = [4356,4357]
===
match
---
expr_stmt [1750,1810]
expr_stmt [1750,1810]
===
match
---
name: host [6711,6715]
name: host [6753,6757]
===
match
---
return_stmt [12439,12643]
return_stmt [12481,12685]
===
match
---
name: timeout [7625,7632]
name: timeout [7667,7674]
===
match
---
atom_expr [2776,2797]
atom_expr [2776,2797]
===
match
---
argument [7578,7603]
argument [7620,7645]
===
match
---
operator: = [1363,1364]
operator: = [1363,1364]
===
match
---
simple_stmt [2442,2761]
simple_stmt [2442,2761]
===
match
---
return_stmt [3095,3116]
return_stmt [3095,3116]
===
match
---
name: self [2221,2225]
name: self [2221,2225]
===
match
---
funcdef [2275,2845]
funcdef [2275,2845]
===
match
---
simple_stmt [5832,6285]
simple_stmt [5797,6250]
===
match
---
trailer [2728,2745]
trailer [2728,2745]
===
match
---
name: install [11697,11704]
name: install [11739,11746]
===
match
---
name: json [7413,7417]
name: json [7455,7459]
===
match
---
argument [7625,7653]
argument [7667,7695]
===
match
---
name: method [6976,6982]
name: method [7018,7024]
===
match
---
operator: = [7491,7492]
operator: = [7533,7534]
===
match
---
simple_stmt [12960,12979]
simple_stmt [13002,13021]
===
match
---
name: INSTALL_LIBS_ENDPOINT [12007,12028]
name: INSTALL_LIBS_ENDPOINT [12049,12070]
===
match
---
atom_expr [6531,6564]
atom_expr [6573,6606]
===
match
---
name: ValueError [4622,4632]
name: ValueError [4587,4597]
===
match
---
name: dict [11717,11721]
name: dict [11759,11763]
===
match
---
expr_stmt [10062,10114]
expr_stmt [10104,10156]
===
match
---
simple_stmt [10648,10687]
simple_stmt [10690,10729]
===
insert-tree
---
simple_stmt [787,1035]
    string: """ Databricks hook.  This hook enable the submitting and running of jobs to the Databricks platform. Internally the operators talk to the ``api/2.0/jobs/runs/submit`` `endpoint <https://docs.databricks.com/api/latest/jobs.html#runs-submit>`_. """ [787,1034]
to
file_input [787,13120]
at 0
===
insert-tree
---
simple_stmt [6300,6368]
    expr_stmt [6300,6367]
        atom_expr [6300,6320]
            name: self [6300,6304]
            trailer [6304,6320]
                name: databricks_conn [6305,6320]
        operator: = [6321,6322]
        atom_expr [6323,6367]
            name: self [6323,6327]
            trailer [6327,6342]
                name: get_connection [6328,6342]
            trailer [6342,6367]
                atom_expr [6343,6366]
                    name: self [6343,6347]
                    trailer [6347,6366]
                        name: databricks_conn_id [6348,6366]
to
suite [5823,8469]
at 2
===
delete-tree
---
simple_stmt [787,1035]
    string: """ Databricks hook.  This hook enable the submitting and running of jobs to the Databricks platform. Internally the operators talk to the ``api/2.0/jobs/runs/submit`` `endpoint <https://docs.databricks.com/api/latest/jobs.html#runs-submit>`_. """ [787,1034]
===
delete-tree
---
atom_expr [4489,4528]
    name: self [4489,4493]
    trailer [4493,4508]
        name: get_connection [4494,4508]
    trailer [4508,4528]
        name: databricks_conn_id [4509,4527]
