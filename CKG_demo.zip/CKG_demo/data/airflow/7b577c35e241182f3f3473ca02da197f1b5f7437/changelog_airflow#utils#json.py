===
match
---
name: date [1460,1464]
name: date [1460,1464]
===
match
---
atom_expr [1735,1743]
atom_expr [1735,1743]
===
match
---
except_clause [933,951]
except_clause [933,951]
===
match
---
name: int8 [1661,1665]
name: int8 [1661,1665]
===
match
---
atom_expr [1658,1665]
atom_expr [1658,1665]
===
match
---
atom_expr [1988,2116]
atom_expr [1988,2116]
===
match
---
simple_stmt [1149,1183]
simple_stmt [1149,1183]
===
match
---
operator: , [1691,1692]
operator: , [1691,1692]
===
match
---
atom_expr [1841,1850]
atom_expr [1841,1850]
===
match
---
param [1256,1259]
param [1256,1259]
===
match
---
name: __init__ [1157,1165]
name: __init__ [1157,1165]
===
match
---
trailer [2094,2105]
trailer [2094,2105]
===
match
---
name: obj [1396,1399]
name: obj [1396,1399]
===
match
---
suite [952,968]
suite [952,968]
===
match
---
dotted_name [849,859]
dotted_name [849,859]
===
match
---
atom_expr [1583,1590]
atom_expr [1583,1590]
===
match
---
name: self [1206,1210]
name: self [1206,1210]
===
match
---
name: complex64 [2081,2090]
name: complex64 [2081,2090]
===
match
---
trailer [2378,2388]
trailer [2408,2418]
===
match
---
trailer [1969,1974]
trailer [1969,1974]
===
match
---
name: uint16 [1790,1796]
name: uint16 [1790,1796]
===
match
---
import_name [825,843]
import_name [825,843]
===
match
---
operator: , [1458,1459]
operator: , [1458,1459]
===
match
---
atom_expr [1524,1876]
atom_expr [1524,1876]
===
match
---
operator: , [2090,2091]
operator: , [2090,2091]
===
match
---
atom_expr [2053,2063]
atom_expr [2053,2063]
===
match
---
atom_expr [1965,1974]
atom_expr [1965,1974]
===
match
---
raise_stmt [2340,2426]
raise_stmt [2370,2456]
===
match
---
atom_expr [1709,1717]
atom_expr [1709,1717]
===
match
---
name: obj [1256,1259]
name: obj [1256,1259]
===
match
---
name: uint32 [1817,1823]
name: uint32 [1817,1823]
===
match
---
operator: , [1796,1797]
operator: , [1796,1797]
===
match
---
operator: , [1128,1129]
operator: , [1128,1129]
===
match
---
atom_expr [2029,2039]
atom_expr [2029,2039]
===
match
---
name: json [855,859]
name: json [855,859]
===
match
---
atom_expr [2092,2105]
atom_expr [2092,2105]
===
match
---
simple_stmt [788,824]
simple_stmt [788,824]
===
match
---
atom_expr [1683,1691]
atom_expr [1683,1691]
===
match
---
name: V1Pod [2201,2206]
name: V1Pod [2202,2207]
===
match
---
name: np [2065,2067]
name: np [2065,2067]
===
match
---
trailer [1489,1498]
trailer [1489,1498]
===
match
---
simple_stmt [957,968]
simple_stmt [957,968]
===
match
---
name: pod_generator [2245,2258]
name: pod_generator [2275,2288]
===
match
---
simple_stmt [1479,1511]
simple_stmt [1479,1511]
===
match
---
atom_expr [2018,2027]
atom_expr [2018,2027]
===
match
---
name: datetime [1366,1374]
name: datetime [1366,1374]
===
match
---
parameters [1116,1139]
parameters [1116,1139]
===
match
---
simple_stmt [825,844]
simple_stmt [825,844]
===
match
---
name: np [1683,1685]
name: np [1683,1685]
===
match
---
name: obj [2326,2329]
name: obj [2356,2359]
===
match
---
name: obj [1548,1551]
name: obj [1548,1551]
===
match
---
name: obj [1361,1364]
name: obj [1361,1364]
===
match
---
suite [2117,2148]
suite [2117,2148]
===
match
---
argument [1166,1171]
argument [1166,1171]
===
match
---
operator: , [1640,1641]
operator: , [1640,1641]
===
match
---
name: np [1761,1763]
name: np [1761,1763]
===
match
---
trailer [1843,1850]
trailer [1843,1850]
===
match
---
operator: , [2039,2040]
operator: , [2039,2040]
===
match
---
name: np [2029,2031]
name: np [2029,2031]
===
match
---
string: """Custom Airflow json encoder implementation.""" [1049,1098]
string: """Custom Airflow json encoder implementation.""" [1049,1098]
===
match
---
name: obj [1930,1933]
name: obj [1930,1933]
===
match
---
arglist [1548,1866]
arglist [1548,1866]
===
match
---
import_as_name [919,932]
import_as_name [919,932]
===
match
---
name: obj [1901,1904]
name: obj [1901,1904]
===
match
---
name: airflow [2226,2233]
name: airflow [2256,2263]
===
match
---
atom [2017,2106]
atom [2017,2106]
===
match
---
trailer [2067,2076]
trailer [2067,2076]
===
match
---
fstring_string: Object of type ' [2358,2374]
fstring_string: Object of type ' [2388,2404]
===
match
---
simple_stmt [889,933]
simple_stmt [889,933]
===
match
---
name: date [809,813]
name: date [809,813]
===
match
---
operator: , [1171,1172]
operator: , [1171,1172]
===
match
---
operator: , [1717,1718]
operator: , [1717,1718]
===
match
---
trailer [1816,1823]
trailer [1816,1823]
===
match
---
simple_stmt [1191,1220]
simple_stmt [1191,1220]
===
match
---
name: np [2092,2094]
name: np [2092,2094]
===
match
---
name: JSONEncoder [867,878]
name: JSONEncoder [867,878]
===
match
---
atom_expr [1396,1430]
atom_expr [1396,1430]
===
match
---
name: isinstance [1919,1929]
name: isinstance [1919,1929]
===
match
---
name: isinstance [1988,1998]
name: isinstance [1988,1998]
===
match
---
name: self [1191,1195]
name: self [1191,1195]
===
match
---
atom_expr [1935,1943]
atom_expr [1935,1943]
===
match
---
atom_expr [1486,1510]
atom_expr [1486,1510]
===
match
---
return_stmt [1479,1510]
return_stmt [1479,1510]
===
match
---
dotted_name [2226,2258]
dotted_name [2256,2288]
===
match
---
name: isinstance [2181,2191]
name: isinstance [2181,2191]
===
match
---
operator: = [1204,1205]
operator: = [1204,1205]
===
match
---
operator: ** [1173,1175]
operator: ** [1173,1175]
===
match
---
dotted_as_name [832,843]
dotted_as_name [832,843]
===
match
---
name: np [1841,1843]
name: np [1841,1843]
===
match
---
suite [1261,2427]
suite [1261,2457]
===
match
---
atom_expr [1761,1769]
atom_expr [1761,1769]
===
match
---
atom_expr [2181,2207]
atom_expr [2181,2237]
===
match
---
trailer [1610,1615]
trailer [1610,1615]
===
match
---
name: np [1658,1660]
name: np [1658,1660]
===
match
---
suite [1466,1511]
suite [1466,1511]
===
match
---
name: float32 [2044,2051]
name: float32 [2044,2051]
===
match
---
name: obj [2012,2015]
name: obj [2012,2015]
===
match
---
atom_expr [2299,2330]
atom_expr [2329,2360]
===
match
---
name: k8s [929,932]
name: k8s [929,932]
===
match
---
trailer [1900,1905]
trailer [1900,1905]
===
match
---
name: __class__ [2379,2388]
name: __class__ [2409,2418]
===
match
---
name: TypeError [2346,2355]
name: TypeError [2376,2385]
===
match
---
file_input [788,2427]
file_input [788,2457]
===
match
---
arglist [1930,1943]
arglist [1930,1943]
===
match
---
testlist_comp [1583,1851]
testlist_comp [1583,1851]
===
match
---
name: np [1583,1585]
name: np [1583,1585]
===
match
---
simple_stmt [844,879]
simple_stmt [844,879]
===
match
---
name: _default [1211,1219]
name: _default [1211,1219]
===
match
---
name: int32 [1712,1717]
name: int32 [1712,1717]
===
match
---
operator: , [1590,1591]
operator: , [1590,1591]
===
match
---
name: intp [1636,1640]
name: intp [1636,1640]
===
match
---
atom [1565,1865]
atom [1565,1865]
===
match
---
name: np [2018,2020]
name: np [2018,2020]
===
match
---
import_from [2221,2278]
import_from [2251,2308]
===
match
---
trailer [1360,1375]
trailer [1360,1375]
===
match
---
trailer [2325,2330]
trailer [2355,2360]
===
match
---
atom_expr [1149,1182]
atom_expr [1149,1182]
===
match
---
name: __name__ [2389,2397]
name: __name__ [2419,2427]
===
match
---
operator: , [1933,1934]
operator: , [1933,1934]
===
match
---
suite [884,933]
suite [884,933]
===
match
---
funcdef [1243,2427]
funcdef [1243,2457]
===
match
---
trailer [2055,2063]
trailer [2055,2063]
===
match
---
arglist [1166,1181]
arglist [1166,1181]
===
match
---
param [1117,1122]
param [1117,1122]
===
match
---
argument [1173,1181]
argument [1173,1181]
===
match
---
atom_expr [1350,1375]
atom_expr [1350,1375]
===
match
---
name: super [1149,1154]
name: super [1149,1154]
===
match
---
trailer [1156,1165]
trailer [1156,1165]
===
match
---
operator: @ [1225,1226]
operator: @ [1225,1226]
===
match
---
atom_expr [2346,2426]
atom_expr [2376,2456]
===
match
---
name: AirflowJsonEncoder [1012,1030]
name: AirflowJsonEncoder [1012,1030]
===
match
---
name: int_ [1586,1590]
name: int_ [1586,1590]
===
match
---
operator: ** [1130,1132]
operator: ** [1130,1132]
===
match
---
testlist_comp [2018,2105]
testlist_comp [2018,2105]
===
match
---
classdef [1006,2427]
classdef [1006,2457]
===
match
---
trailer [1454,1465]
trailer [1454,1465]
===
match
---
trailer [1210,1219]
trailer [1210,1219]
===
match
---
trailer [1763,1769]
trailer [1763,1769]
===
match
---
operator: = [961,962]
operator: = [961,962]
===
match
---
trailer [2388,2397]
trailer [2418,2427]
===
match
---
name: args [1124,1128]
name: args [1124,1128]
===
match
---
comparison [2161,2176]
comparison [2161,2176]
===
match
---
return_stmt [2130,2147]
return_stmt [2130,2147]
===
match
---
atom_expr [2197,2206]
atom_expr [2198,2207]
===
match
---
name: kwargs [1132,1138]
name: kwargs [1132,1138]
===
match
---
trailer [1737,1743]
trailer [1737,1743]
===
match
---
name: float64 [2056,2063]
name: float64 [2056,2063]
===
match
---
name: int64 [1738,1743]
name: int64 [1738,1743]
===
match
---
import_from [844,878]
import_from [844,878]
===
match
---
name: bool_ [1938,1943]
name: bool_ [1938,1943]
===
match
---
atom_expr [2078,2090]
atom_expr [2078,2090]
===
match
---
name: ImportError [940,951]
name: ImportError [940,951]
===
match
---
name: args [1167,1171]
name: args [1167,1171]
===
match
---
trailer [2200,2206]
trailer [2201,2207]
===
match
---
name: np [1814,1816]
name: np [1814,1816]
===
match
---
trailer [2080,2090]
trailer [2080,2090]
===
match
---
name: complex128 [2095,2105]
name: complex128 [2095,2105]
===
match
---
name: obj [2143,2146]
name: obj [2143,2146]
===
match
---
atom_expr [2041,2051]
atom_expr [2041,2051]
===
match
---
name: np [841,843]
name: np [841,843]
===
match
---
simple_stmt [2340,2427]
simple_stmt [2370,2457]
===
match
---
fstring_expr [2374,2398]
fstring_expr [2404,2428]
===
match
---
trailer [1685,1691]
trailer [1685,1691]
===
match
---
atom_expr [1444,1465]
atom_expr [1444,1465]
===
match
---
operator: , [2027,2028]
operator: , [2027,2028]
===
match
---
name: isinstance [1444,1454]
name: isinstance [1444,1454]
===
match
---
name: isinstance [1350,1360]
name: isinstance [1350,1360]
===
match
---
import_from [889,932]
import_from [889,932]
===
match
---
dotted_name [894,911]
dotted_name [894,911]
===
match
---
operator: { [2374,2375]
operator: { [2404,2405]
===
match
---
simple_stmt [1389,1431]
simple_stmt [1389,1431]
===
match
---
expr_stmt [957,967]
expr_stmt [957,967]
===
match
---
name: numpy [832,837]
name: numpy [832,837]
===
match
---
param [1130,1138]
param [1130,1138]
===
match
---
name: __init__ [1108,1116]
name: __init__ [1108,1116]
===
match
---
name: float16 [2032,2039]
name: float16 [2032,2039]
===
match
---
and_test [2161,2207]
and_test [2161,2237]
===
match
---
name: complex_ [2068,2076]
name: complex_ [2068,2076]
===
match
---
trailer [2043,2051]
trailer [2043,2051]
===
match
---
arglist [1455,1464]
arglist [1455,1464]
===
match
---
arglist [1361,1374]
arglist [1361,1374]
===
match
---
param [1123,1129]
param [1123,1129]
===
match
---
operator: , [1743,1744]
operator: , [1743,1744]
===
match
---
operator: , [1665,1666]
operator: , [1665,1666]
===
match
---
name: obj [1486,1489]
name: obj [1486,1489]
===
match
---
operator: } [2397,2398]
operator: } [2427,2428]
===
match
---
import_from [788,823]
import_from [788,823]
===
match
---
return_stmt [1389,1430]
return_stmt [1389,1430]
===
match
---
simple_stmt [2221,2279]
simple_stmt [2251,2309]
===
match
---
name: uint8 [1764,1769]
name: uint8 [1764,1769]
===
match
---
expr_stmt [1191,1219]
expr_stmt [1191,1219]
===
match
---
name: np [1709,1711]
name: np [1709,1711]
===
match
---
fstring_end: " [2424,2425]
fstring_end: " [2454,2455]
===
match
---
fstring_start: f" [2356,2358]
fstring_start: f" [2386,2388]
===
match
---
atom_expr [1191,1203]
atom_expr [1191,1203]
===
match
---
name: datetime [815,823]
name: datetime [815,823]
===
match
---
trailer [1195,1203]
trailer [1195,1203]
===
match
---
atom_expr [1919,1944]
atom_expr [1919,1944]
===
match
---
name: strftime [1490,1498]
name: strftime [1490,1498]
===
match
---
name: float [2137,2142]
name: float [2137,2142]
===
match
---
name: np [2041,2043]
name: np [2041,2043]
===
match
---
name: np [1633,1635]
name: np [1633,1635]
===
match
---
trailer [1165,1182]
trailer [1165,1182]
===
match
---
name: np [1608,1610]
name: np [1608,1610]
===
match
---
operator: , [2051,2052]
operator: , [2051,2052]
===
match
---
fstring [2356,2425]
fstring [2386,2455]
===
match
---
trailer [2191,2207]
trailer [2191,2237]
===
match
---
simple_stmt [1890,1906]
simple_stmt [1890,1906]
===
match
---
trailer [1937,1943]
trailer [1937,1943]
===
match
---
name: _default [1247,1255]
name: _default [1247,1255]
===
match
---
simple_stmt [1049,1099]
simple_stmt [1049,1099]
===
match
---
atom_expr [1608,1615]
atom_expr [1608,1615]
===
match
---
suite [1877,1906]
suite [1877,1906]
===
match
---
name: default [1196,1203]
name: default [1196,1203]
===
match
---
name: np [1787,1789]
name: np [1787,1789]
===
match
---
suite [1376,1431]
suite [1376,1431]
===
match
---
atom_expr [2065,2076]
atom_expr [2065,2076]
===
match
---
decorator [1225,1239]
decorator [1225,1239]
===
match
---
trailer [1660,1665]
trailer [1660,1665]
===
match
---
name: k8s [2161,2164]
name: k8s [2161,2164]
===
match
---
operator: , [1823,1824]
operator: , [1823,1824]
===
match
---
name: obj [1455,1458]
name: obj [1455,1458]
===
match
---
arglist [2192,2206]
arglist [2192,2236]
===
match
---
operator: , [1551,1552]
operator: , [1551,1552]
===
match
---
name: int16 [1686,1691]
name: int16 [1686,1691]
===
match
---
name: PodGenerator [2299,2311]
name: PodGenerator [2329,2341]
===
match
---
name: uint64 [1844,1850]
name: uint64 [1844,1850]
===
match
---
trailer [1399,1408]
trailer [1399,1408]
===
match
---
operator: , [1121,1122]
operator: , [1121,1122]
===
match
---
atom_expr [1787,1796]
atom_expr [1787,1796]
===
match
---
name: serialize_pod [2312,2325]
name: serialize_pod [2342,2355]
===
match
---
string: '%Y-%m-%d' [1499,1509]
string: '%Y-%m-%d' [1499,1509]
===
match
---
suite [1945,1975]
suite [1945,1975]
===
match
---
name: isinstance [1524,1534]
name: isinstance [1524,1534]
===
match
---
atom_expr [1814,1823]
atom_expr [1814,1823]
===
match
---
name: int [1897,1900]
name: int [1897,1900]
===
match
---
suite [1044,2427]
suite [1044,2457]
===
match
---
name: kubernetes [894,904]
name: kubernetes [894,904]
===
match
---
try_stmt [880,968]
try_stmt [880,968]
===
match
---
atom_expr [1633,1640]
atom_expr [1633,1640]
===
match
---
operator: , [813,814]
operator: , [813,814]
===
match
---
name: bool [1965,1969]
name: bool [1965,1969]
===
match
---
funcdef [1104,1220]
funcdef [1104,1220]
===
match
---
simple_stmt [2292,2331]
simple_stmt [2322,2361]
===
match
---
trailer [1408,1430]
trailer [1408,1430]
===
match
---
name: kubernetes [2234,2244]
name: kubernetes [2264,2274]
===
match
---
simple_stmt [1270,1339]
simple_stmt [1270,1339]
===
match
---
operator: , [2015,2016]
operator: , [2015,2016]
===
match
---
trailer [1929,1944]
trailer [1929,1944]
===
match
---
trailer [1498,1510]
trailer [1498,1510]
===
match
---
name: flask [849,854]
name: flask [849,854]
===
match
---
atom_expr [1897,1905]
atom_expr [1897,1905]
===
match
---
name: client [905,911]
name: client [905,911]
===
match
---
operator: , [1364,1365]
operator: , [1364,1365]
===
match
---
name: intc [1611,1615]
name: intc [1611,1615]
===
match
---
trailer [1635,1640]
trailer [1635,1640]
===
match
---
operator: , [1615,1616]
operator: , [1615,1616]
===
match
---
operator: , [1850,1851]
operator: , [1850,1851]
===
match
---
arglist [2012,2106]
arglist [2012,2106]
===
match
---
import_as_names [809,823]
import_as_names [809,823]
===
match
---
name: obj [1970,1973]
name: obj [1970,1973]
===
match
---
suite [2208,2331]
suite [2238,2361]
===
match
---
name: staticmethod [1226,1238]
name: staticmethod [1226,1238]
===
match
---
name: np [1935,1937]
name: np [1935,1937]
===
match
---
name: models [919,925]
name: models [919,925]
===
match
---
operator: , [2195,2196]
operator: , [2195,2196]
===
match
---
trailer [2020,2027]
trailer [2020,2027]
===
match
---
trailer [1711,1717]
trailer [1711,1717]
===
match
---
name: strftime [1400,1408]
name: strftime [1400,1408]
===
match
---
name: datetime [793,801]
name: datetime [793,801]
===
match
---
string: """Convert dates and numpy objects in a json serializable format.""" [1270,1338]
string: """Convert dates and numpy objects in a json serializable format.""" [1270,1338]
===
match
---
name: np [2053,2055]
name: np [2053,2055]
===
match
---
parameters [1255,1260]
parameters [1255,1260]
===
match
---
operator: * [1123,1124]
operator: * [1123,1124]
===
match
---
trailer [1154,1156]
trailer [1154,1156]
===
match
---
name: float_ [2021,2027]
name: float_ [2021,2027]
===
match
---
name: PodGenerator [2266,2278]
name: PodGenerator [2296,2308]
===
match
---
trailer [2311,2325]
trailer [2341,2355]
===
match
---
name: self [1117,1121]
name: self [1117,1121]
===
match
---
trailer [1998,2116]
trailer [1998,2116]
===
match
---
simple_stmt [1958,1975]
simple_stmt [1958,1975]
===
match
---
atom_expr [1206,1219]
atom_expr [1206,1219]
===
match
---
operator: , [2063,2064]
operator: , [2063,2064]
===
match
---
return_stmt [1958,1974]
return_stmt [1958,1974]
===
match
---
suite [1140,1220]
suite [1140,1220]
===
match
---
name: obj [2192,2195]
name: obj [2192,2195]
===
match
---
operator: , [2076,2077]
operator: , [2076,2077]
===
match
---
string: '%Y-%m-%dT%H:%M:%SZ' [1409,1429]
string: '%Y-%m-%dT%H:%M:%SZ' [1409,1429]
===
match
---
simple_stmt [2130,2148]
simple_stmt [2130,2148]
===
match
---
name: k8s [2197,2200]
name: k8s [2198,2201]
===
match
---
return_stmt [2292,2330]
return_stmt [2322,2360]
===
match
---
trailer [1534,1876]
trailer [1534,1876]
===
match
---
atom_expr [2137,2147]
atom_expr [2137,2147]
===
match
---
fstring_string: ' is not JSON serializable [2398,2424]
fstring_string: ' is not JSON serializable [2428,2454]
===
match
---
trailer [2031,2039]
trailer [2031,2039]
===
match
---
name: obj [2375,2378]
name: obj [2405,2408]
===
match
---
name: k8s [957,960]
name: k8s [957,960]
===
match
---
name: np [1735,1737]
name: np [1735,1737]
===
match
---
trailer [2355,2426]
trailer [2385,2456]
===
match
---
name: kwargs [1175,1181]
name: kwargs [1175,1181]
===
match
---
trailer [2142,2147]
trailer [2142,2147]
===
match
---
trailer [1585,1590]
trailer [1585,1590]
===
match
---
trailer [1789,1796]
trailer [1789,1796]
===
match
---
operator: , [1865,1866]
operator: , [1865,1866]
===
match
---
if_stmt [1347,2331]
if_stmt [1347,2361]
===
match
---
name: JSONEncoder [1031,1042]
name: JSONEncoder [1031,1042]
===
match
---
comp_op [2165,2171]
comp_op [2165,2171]
===
match
---
return_stmt [1890,1905]
return_stmt [1890,1905]
===
match
---
atom_expr [2375,2397]
atom_expr [2405,2427]
===
match
---
operator: , [1769,1770]
operator: , [1769,1770]
===
match
---
name: np [2078,2080]
name: np [2078,2080]
===
match
---
decorated [1225,2427]
decorated [1225,2457]
===
match
---
operator: * [1166,1167]
operator: * [1166,1167]
===
insert-node
---
atom [2197,2236]
to
arglist [2192,2206]
at 2
===
insert-node
---
testlist_comp [2198,2235]
to
atom [2197,2236]
at 0
===
move-tree
---
atom_expr [2197,2206]
    name: k8s [2197,2200]
    trailer [2200,2206]
        name: V1Pod [2201,2206]
to
testlist_comp [2198,2235]
at 0
