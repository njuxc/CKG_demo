===
match
---
string: 'google-cloud-videointelligence' [3096,3128]
string: 'google-cloud-videointelligence' [3095,3127]
===
match
---
string: 'google-cloud-pubsub' [2479,2500]
string: 'google-cloud-pubsub' [2478,2499]
===
match
---
expr_stmt [786,3263]
expr_stmt [786,3262]
===
match
---
string: 'google-cloud-language' [2319,2342]
string: 'google-cloud-language' [2318,2341]
===
match
---
string: 'google-cloud-bigtable' [1773,1796]
string: 'google-cloud-bigtable' [1772,1795]
===
match
---
string: 'https://googleapis.dev/python/texttospeech/latest' [2957,3008]
string: 'https://googleapis.dev/python/texttospeech/latest' [2956,3007]
===
match
---
string: 'google-cloud-redis' [2553,2573]
string: 'google-cloud-redis' [2552,2572]
===
match
---
string: 'google-cloud-storage' [2775,2797]
string: 'google-cloud-storage' [2774,2796]
===
match
---
string: 'mongodb' [1061,1070]
string: 'mongodb' [1061,1070]
===
match
---
string: 'google-cloud-core' [1931,1950]
string: 'google-cloud-core' [1930,1949]
===
match
---
string: 'https://googleapis.dev/python/spanner/latest' [2649,2695]
string: 'https://googleapis.dev/python/spanner/latest' [2648,2694]
===
match
---
string: 'https://pymongo.readthedocs.io/en/stable/' [1072,1115]
string: 'https://pymongo.readthedocs.io/en/3.11.3' [1072,1114]
===
match
---
operator: , [2695,2696]
operator: , [2694,2695]
===
match
---
file_input [786,3264]
file_input [786,3263]
===
match
---
string: 'google-cloud-bigquery' [1499,1522]
string: 'google-cloud-bigquery' [1498,1521]
===
match
---
operator: , [3260,3261]
operator: , [3259,3260]
===
match
---
string: 'google-cloud-bigquery-datatransfer' [1577,1613]
string: 'google-cloud-bigquery-datatransfer' [1576,1612]
===
match
---
operator: , [2845,2846]
operator: , [2844,2845]
===
match
---
string: 'https://googleapis.dev/python/bigquery/latest' [1524,1571]
string: 'https://googleapis.dev/python/bigquery/latest' [1523,1570]
===
match
---
operator: , [1493,1494]
operator: , [1492,1493]
===
match
---
operator: , [1674,1675]
operator: , [1673,1674]
===
match
---
atom [808,3263]
atom [808,3262]
===
match
---
operator: , [2547,2548]
operator: , [2546,2547]
===
match
---
operator: , [938,939]
operator: , [938,939]
===
match
---
string: 'https://googleapis.dev/python/redis/latest' [2575,2619]
string: 'https://googleapis.dev/python/redis/latest' [2574,2618]
===
match
---
string: 'https://googleapis.dev/python/videointelligence/latest' [3130,3186]
string: 'https://googleapis.dev/python/videointelligence/latest' [3129,3185]
===
match
---
string: 'https://googleapis.dev/python/dlp/latest' [2198,2240]
string: 'https://googleapis.dev/python/dlp/latest' [2197,2239]
===
match
---
string: 'https://googleapis.dev/python/google-api-core/latest' [1365,1419]
string: 'https://googleapis.dev/python/google-api-core/latest' [1364,1418]
===
match
---
string: 'https://hdfscli.readthedocs.io/en/latest' [952,994]
string: 'https://hdfscli.readthedocs.io/en/latest' [952,994]
===
match
---
string: 'https://googleapis.dev/python/cloudtasks/latest' [2873,2922]
string: 'https://googleapis.dev/python/cloudtasks/latest' [2872,2921]
===
match
---
string: 'boto3' [814,821]
string: 'boto3' [814,821]
===
match
---
string: 'google-cloud-spanner' [2625,2647]
string: 'google-cloud-spanner' [2624,2646]
===
match
---
string: 'https://docs.sqlalchemy.org/en/latest' [1301,1340]
string: 'https://docs.sqlalchemy.org/en/latest' [1300,1339]
===
match
---
string: 'https://boto3.amazonaws.com/v1/documentation/api/latest' [823,880]
string: 'https://boto3.amazonaws.com/v1/documentation/api/latest' [823,880]
===
match
---
name: THIRD_PARTY_INDEXES [786,805]
name: THIRD_PARTY_INDEXES [786,805]
===
match
---
string: 'https://googleapis.dev/python/cloudkms/latest' [2266,2313]
string: 'https://googleapis.dev/python/cloudkms/latest' [2265,2312]
===
match
---
operator: , [1845,1846]
operator: , [1844,1845]
===
match
---
string: 'google-cloud-kms' [2246,2264]
string: 'google-cloud-kms' [2245,2263]
===
match
---
string: 'https://googleapis.dev/python/pubsub/latest' [2502,2547]
string: 'https://googleapis.dev/python/pubsub/latest' [2501,2546]
===
match
---
string: 'google-cloud-automl' [1425,1446]
string: 'google-cloud-automl' [1424,1445]
===
match
---
operator: , [1281,1282]
operator: , [1280,1281]
===
match
---
string: 'https://googleapis.dev/python/datastore/latest' [2124,2172]
string: 'https://googleapis.dev/python/datastore/latest' [2123,2171]
===
match
---
operator: , [2473,2474]
operator: , [2472,2473]
===
match
---
string: 'https://docs.celeryproject.org/en/stable' [896,938]
string: 'https://docs.celeryproject.org/en/stable' [896,938]
===
match
---
string: 'google-cloud-container' [1851,1875]
string: 'google-cloud-container' [1850,1874]
===
match
---
string: 'https://googleapis.dev/python/storage/latest' [2799,2845]
string: 'https://googleapis.dev/python/storage/latest' [2798,2844]
===
match
---
string: 'https://googleapis.dev/python/translation/latest' [3040,3090]
string: 'https://googleapis.dev/python/translation/latest' [3039,3089]
===
match
---
string: 'https://googleapis.dev/python/bigtable/latest' [1798,1845]
string: 'https://googleapis.dev/python/bigtable/latest' [1797,1844]
===
match
---
string: 'google-cloud-monitoring' [2397,2422]
string: 'google-cloud-monitoring' [2396,2421]
===
match
---
operator: , [2008,2009]
operator: , [2007,2008]
===
match
---
string: 'sqlalchemy' [1287,1299]
string: 'sqlalchemy' [1286,1298]
===
match
---
string: 'https://googleapis.dev/python/monitoring/latest' [2424,2473]
string: 'https://googleapis.dev/python/monitoring/latest' [2423,2472]
===
match
---
string: 'https://requests.readthedocs.io/en/master' [1238,1281]
string: 'https://requests.readthedocs.io/en/master' [1237,1280]
===
match
---
operator: = [806,807]
operator: = [806,807]
===
match
---
string: 'google-api-core' [1346,1363]
string: 'google-api-core' [1345,1362]
===
match
---
string: 'https://googleapis.dev/python/speech/latest' [2724,2769]
string: 'https://googleapis.dev/python/speech/latest' [2723,2768]
===
match
---
string: 'google-cloud-speech' [2701,2722]
string: 'google-cloud-speech' [2700,2721]
===
match
---
operator: , [2769,2770]
operator: , [2768,2769]
===
match
---
operator: , [994,995]
operator: , [994,995]
===
match
---
string: 'google-cloud-tasks' [2851,2871]
string: 'google-cloud-tasks' [2850,2870]
===
match
---
string: 'https://jinja.palletsprojects.com/en/master' [1010,1055]
string: 'https://jinja.palletsprojects.com/en/master' [1010,1055]
===
match
---
operator: { [808,809]
operator: { [808,809]
===
match
---
string: 'https://docs.python.org/3' [1193,1220]
string: 'https://docs.python.org/3' [1192,1219]
===
match
---
operator: , [1220,1221]
operator: , [1219,1220]
===
match
---
simple_stmt [786,3264]
simple_stmt [786,3263]
===
match
---
operator: , [1925,1926]
operator: , [1924,1925]
===
match
---
operator: , [2092,2093]
operator: , [2091,2092]
===
match
---
string: 'https://googleapis.dev/python/container/latest' [1877,1925]
string: 'https://googleapis.dev/python/container/latest' [1876,1924]
===
match
---
operator: , [2391,2392]
operator: , [2390,2391]
===
match
---
operator: , [2922,2923]
operator: , [2921,2922]
===
match
---
operator: , [3090,3091]
operator: , [3089,3090]
===
match
---
string: 'https://googleapis.dev/python/google-cloud-core/latest' [1952,2008]
string: 'https://googleapis.dev/python/google-cloud-core/latest' [1951,2007]
===
match
---
string: 'google-cloud-dlp' [2178,2196]
string: 'google-cloud-dlp' [2177,2195]
===
match
---
string: 'google-cloud-datacatalog' [2014,2040]
string: 'google-cloud-datacatalog' [2013,2039]
===
match
---
string: 'jinja2' [1000,1008]
string: 'jinja2' [1000,1008]
===
match
---
string: 'https://googleapis.dev/python/automl/latest' [1448,1493]
string: 'https://googleapis.dev/python/automl/latest' [1447,1492]
===
match
---
operator: , [1571,1572]
operator: , [1570,1571]
===
match
---
string: 'celery' [886,894]
string: 'celery' [886,894]
===
match
---
string: 'https://googleapis.dev/python/datacatalog/latest' [2042,2092]
string: 'https://googleapis.dev/python/datacatalog/latest' [2041,2091]
===
match
---
operator: , [3008,3009]
operator: , [3007,3008]
===
match
---
operator: , [1767,1768]
operator: , [1766,1767]
===
match
---
operator: , [2240,2241]
operator: , [2239,2240]
===
match
---
string: 'https://pandas.pydata.org/pandas-docs/stable' [1131,1177]
string: 'https://pandas.pydata.org/pandas-docs/stable' [1130,1176]
===
match
---
operator: , [1419,1420]
operator: , [1418,1419]
===
match
---
operator: , [2313,2314]
operator: , [2312,2313]
===
match
---
string: 'https://googleapis.dev/python/language/latest' [2344,2391]
string: 'https://googleapis.dev/python/language/latest' [2343,2390]
===
match
---
string: 'google-cloud-vision' [3192,3213]
string: 'google-cloud-vision' [3191,3212]
===
match
---
string: 'google-cloud-translate' [3014,3038]
string: 'google-cloud-translate' [3013,3037]
===
match
---
string: 'google-cloud-texttospeech' [2928,2955]
string: 'google-cloud-texttospeech' [2927,2954]
===
match
---
string: 'pandas' [1121,1129]
string: 'pandas' [1120,1128]
===
match
---
string: 'python' [1183,1191]
string: 'python' [1182,1190]
===
match
---
operator: , [2619,2620]
operator: , [2618,2619]
===
match
---
operator: , [1055,1056]
operator: , [1055,1056]
===
match
---
operator: } [3262,3263]
operator: } [3261,3262]
===
match
---
string: 'google-cloud-bigquery-storage' [1680,1711]
string: 'google-cloud-bigquery-storage' [1679,1710]
===
match
---
operator: , [1115,1116]
operator: , [1114,1115]
===
match
---
string: 'https://googleapis.dev/python/bigquerystorage/latest' [1713,1767]
string: 'https://googleapis.dev/python/bigquerystorage/latest' [1712,1766]
===
match
---
string: 'requests' [1226,1236]
string: 'requests' [1225,1235]
===
match
---
operator: , [2172,2173]
operator: , [2171,2172]
===
match
---
operator: , [1340,1341]
operator: , [1339,1340]
===
match
---
operator: , [880,881]
operator: , [880,881]
===
match
---
string: 'hdfs' [944,950]
string: 'hdfs' [944,950]
===
match
---
operator: , [3186,3187]
operator: , [3185,3186]
===
match
---
operator: , [1177,1178]
operator: , [1176,1177]
===
match
---
string: 'https://googleapis.dev/python/bigquerydatatransfer/latest' [1615,1674]
string: 'https://googleapis.dev/python/bigquerydatatransfer/latest' [1614,1673]
===
match
---
string: 'https://googleapis.dev/python/vision/latest' [3215,3260]
string: 'https://googleapis.dev/python/vision/latest' [3214,3259]
===
match
---
dictorsetmaker [814,3261]
dictorsetmaker [814,3260]
===
match
---
string: 'google-cloud-datastore' [2098,2122]
string: 'google-cloud-datastore' [2097,2121]
===
update-node
---
string: 'https://pymongo.readthedocs.io/en/stable/' [1072,1115]
replace 'https://pymongo.readthedocs.io/en/stable/' by 'https://pymongo.readthedocs.io/en/3.11.3'
