===
match
---
atom_expr [4017,4035]
atom_expr [4017,4035]
===
match
---
name: print [2434,2439]
name: print [2434,2439]
===
match
---
operator: = [2139,2140]
operator: = [2139,2140]
===
match
---
name: exists [2549,2555]
name: exists [2549,2555]
===
match
---
atom [4830,4843]
atom [4831,4844]
===
match
---
name: Tuple [4311,4316]
name: Tuple [4311,4316]
===
match
---
simple_stmt [3500,3711]
simple_stmt [3500,3711]
===
match
---
operator: , [4839,4840]
operator: , [4840,4841]
===
match
---
operator: = [1791,1792]
operator: = [1791,1792]
===
match
---
expr_stmt [1338,1424]
expr_stmt [1338,1424]
===
match
---
name: join [1373,1377]
name: join [1373,1377]
===
match
---
atom_expr [1929,1945]
atom_expr [1929,1945]
===
match
---
name: pardir [1416,1422]
name: pardir [1416,1422]
===
match
---
fstring_end: " [2466,2467]
fstring_end: " [2466,2467]
===
match
---
operator: = [3950,3951]
operator: = [3950,3951]
===
match
---
string: "http://apache-airflow-docs.s3-website.eu-central-1.amazonaws.com" [1621,1687]
string: "http://apache-airflow-docs.s3-website.eu-central-1.amazonaws.com" [1621,1687]
===
match
---
fstring_expr [2213,2218]
fstring_expr [2213,2218]
===
match
---
name: format [3109,3115]
name: format [3109,3115]
===
match
---
exprlist [4822,4843]
exprlist [4823,4844]
===
match
---
name: shutil [2394,2400]
name: shutil [2394,2400]
===
match
---
sync_comp_for [4940,4970]
sync_comp_for [4941,4971]
===
match
---
name: S3_DOC_URL [1793,1803]
name: S3_DOC_URL [1793,1803]
===
match
---
name: datetime [2595,2603]
name: datetime [2595,2603]
===
match
---
name: decode_content [2364,2378]
name: decode_content [2364,2378]
===
match
---
trailer [2363,2378]
trailer [2363,2378]
===
match
---
exprlist [4439,4453]
exprlist [4439,4453]
===
match
---
expr_stmt [1522,1606]
expr_stmt [1522,1606]
===
match
---
operator: , [2248,2249]
operator: , [2248,2249]
===
match
---
atom_expr [4784,4809]
atom_expr [4785,4810]
===
match
---
arglist [2855,2896]
arglist [2855,2896]
===
match
---
testlist_comp [4931,4970]
testlist_comp [4932,4971]
===
match
---
operator: , [4655,4656]
operator: , [4655,4656]
===
match
---
import_as_names [1138,1171]
import_as_names [1138,1171]
===
match
---
simple_stmt [2083,2146]
simple_stmt [2083,2146]
===
match
---
operator: -> [1926,1928]
operator: -> [1926,1928]
===
match
---
name: pkg_name [4426,4434]
name: pkg_name [4426,4434]
===
match
---
name: path [2656,2660]
name: path [2656,2660]
===
match
---
name: pkg_no [4822,4828]
name: pkg_no [4823,4829]
===
match
---
atom_expr [2621,2676]
atom_expr [2621,2676]
===
match
---
name: package_name [1886,1898]
name: package_name [1886,1898]
===
match
---
name: len [4715,4718]
name: len [4716,4719]
===
match
---
exprlist [4492,4501]
exprlist [4492,4501]
===
match
---
operator: , [4625,4626]
operator: , [4625,4626]
===
match
---
fstring_start: f" [4121,4123]
fstring_start: f" [4121,4123]
===
match
---
name: exts [1184,1188]
name: exts [1184,1188]
===
match
---
trailer [3511,3518]
trailer [3511,3518]
===
match
---
name: THIRD_PARTY_INDEXES [3899,3918]
name: THIRD_PARTY_INDEXES [3899,3918]
===
match
---
name: pkg_name [4944,4952]
name: pkg_name [4945,4953]
===
match
---
name: dirname [1320,1327]
name: dirname [1320,1327]
===
match
---
return_stmt [2571,2582]
return_stmt [2571,2582]
===
match
---
name: str [4317,4320]
name: str [4317,4320]
===
match
---
simple_stmt [2261,2311]
simple_stmt [2261,2311]
===
match
---
name: path [2544,2548]
name: path [2544,2548]
===
match
---
expr_stmt [1425,1466]
expr_stmt [1425,1466]
===
match
---
name: url [3989,3992]
name: url [3989,3992]
===
match
---
name: to_download [4398,4409]
name: to_download [4398,4409]
===
match
---
string: "Failed packages:" [4790,4808]
string: "Failed packages:" [4791,4809]
===
match
---
atom_expr [4211,4266]
atom_expr [4211,4266]
===
match
---
import_name [830,845]
import_name [830,845]
===
match
---
simple_stmt [3012,3219]
simple_stmt [3012,3219]
===
match
---
atom_expr [2434,2468]
atom_expr [2434,2468]
===
match
---
fstring_string: / [3661,3662]
fstring_string: / [3661,3662]
===
match
---
operator: = [3620,3621]
operator: = [3620,3621]
===
match
---
trailer [4316,4327]
trailer [4316,4327]
===
match
---
fstring_string: , success  [4728,4738]
fstring_string:  success,  [4729,4739]
===
match
---
name: str [2524,2527]
name: str [2524,2527]
===
match
---
name: _is_outdated [2505,2517]
name: _is_outdated [2505,2517]
===
match
---
trailer [2857,2862]
trailer [2857,2862]
===
match
---
name: os [1365,1367]
name: os [1365,1367]
===
match
---
fstring_expr [3158,3169]
fstring_expr [3158,3169]
===
match
---
name: url [2214,2217]
name: url [2214,2217]
===
match
---
name: os [2261,2263]
name: os [2261,2263]
===
match
---
atom_expr [2653,2675]
atom_expr [2653,2675]
===
match
---
simple_stmt [4923,4972]
simple_stmt [4924,4973]
===
match
---
simple_stmt [1174,1297]
simple_stmt [1174,1297]
===
match
---
simple_stmt [1766,1841]
simple_stmt [1766,1841]
===
match
---
trailer [2660,2669]
trailer [2660,2669]
===
match
---
atom_expr [3576,3630]
atom_expr [3576,3630]
===
match
---
expr_stmt [1467,1521]
expr_stmt [1467,1521]
===
match
---
trailer [1491,1521]
trailer [1491,1521]
===
match
---
name: path [4547,4551]
name: path [4547,4551]
===
match
---
simple_stmt [2229,2256]
simple_stmt [2229,2256]
===
match
---
suite [2169,2256]
suite [2169,2256]
===
match
---
operator: , [3408,3409]
operator: , [3408,3409]
===
match
---
operator: { [4895,4896]
operator: { [4896,4897]
===
match
---
string: 'docker-stack' [3475,3489]
string: 'docker-stack' [3475,3489]
===
match
---
fstring_end: " [4915,4916]
fstring_end: " [4916,4917]
===
match
---
import_from [870,898]
import_from [870,898]
===
match
---
argument [2133,2144]
argument [2133,2144]
===
match
---
arglist [4611,4643]
arglist [4611,4643]
===
match
---
name: os [1402,1404]
name: os [1402,1404]
===
match
---
name: exts [1059,1063]
name: exts [1059,1063]
===
match
---
trailer [1415,1422]
trailer [1415,1422]
===
match
---
testlist [2236,2255]
testlist [2236,2255]
===
match
---
name: pkg_name [3757,3765]
name: pkg_name [3757,3765]
===
match
---
atom [4425,4469]
atom [4425,4469]
===
match
---
name: print [4069,4074]
name: print [4069,4074]
===
match
---
operator: } [4750,4751]
operator: } [4751,4752]
===
match
---
name: repeat [4378,4384]
name: repeat [4378,4384]
===
match
---
trailer [4120,4169]
trailer [4120,4169]
===
match
---
operator: , [1500,1501]
operator: , [1500,1501]
===
match
---
trailer [2183,2220]
trailer [2183,2220]
===
match
---
trailer [2101,2105]
trailer [2101,2105]
===
match
---
import_from [899,939]
import_from [899,939]
===
match
---
name: Iterator [4302,4310]
name: Iterator [4302,4310]
===
match
---
operator: { [3158,3159]
operator: { [3158,3159]
===
match
---
with_stmt [4175,4579]
with_stmt [4175,4579]
===
match
---
with_stmt [2315,2430]
with_stmt [2315,2430]
===
match
---
operator: { [3170,3171]
operator: { [3170,3171]
===
match
---
trailer [2543,2548]
trailer [2543,2548]
===
match
---
trailer [1557,1606]
trailer [1557,1606]
===
match
---
simple_stmt [1467,1522]
simple_stmt [1467,1522]
===
match
---
fstring_string: /objects.inv [3841,3853]
fstring_string: /objects.inv [3841,3853]
===
match
---
fstring_string: /objects.inv [3790,3802]
fstring_string: /objects.inv [3790,3802]
===
match
---
dotted_name [962,979]
dotted_name [962,979]
===
match
---
name: List [2915,2919]
name: List [2915,2919]
===
match
---
trailer [1393,1400]
trailer [1393,1400]
===
match
---
trailer [2845,2854]
trailer [2845,2854]
===
match
---
trailer [4335,4339]
trailer [4335,4339]
===
match
---
tfpdef [1915,1924]
tfpdef [1915,1924]
===
match
---
trailer [1481,1486]
trailer [1481,1486]
===
match
---
expr_stmt [1608,1687]
expr_stmt [1608,1687]
===
match
---
parameters [2517,2528]
parameters [2517,2528]
===
match
---
trailer [2612,2616]
trailer [2612,2616]
===
match
---
return_stmt [4923,4971]
return_stmt [4924,4972]
===
match
---
exprlist [3878,3895]
exprlist [3878,3895]
===
match
---
name: print [4698,4703]
name: print [4699,4704]
===
match
---
operator: = [2092,2093]
operator: = [2092,2093]
===
match
---
name: fromtimestamp [2639,2652]
name: fromtimestamp [2639,2652]
===
match
---
name: ROOT_DIR [1449,1457]
name: ROOT_DIR [1449,1457]
===
match
---
argument [4865,4872]
argument [4866,4873]
===
match
---
fstring_expr [3650,3661]
fstring_expr [3650,3661]
===
match
---
fstring_string: /objects.inv [3672,3684]
fstring_string: /objects.inv [3672,3684]
===
match
---
operator: = [3128,3129]
operator: = [3128,3129]
===
match
---
sync_comp_for [3874,3926]
sync_comp_for [3874,3926]
===
match
---
operator: , [4542,4543]
operator: , [4542,4543]
===
match
---
argument [3323,3352]
argument [3323,3352]
===
match
---
atom [3532,3700]
atom [3532,3700]
===
match
---
simple_stmt [846,856]
simple_stmt [846,856]
===
match
---
trailer [4622,4625]
trailer [4622,4625]
===
match
---
name: concurrent [811,821]
name: concurrent [811,821]
===
match
---
name: len [4136,4139]
name: len [4136,4139]
===
match
---
simple_stmt [830,846]
simple_stmt [830,846]
===
match
---
name: os [1545,1547]
name: os [1545,1547]
===
match
---
funcdef [2501,2725]
funcdef [2501,2725]
===
match
---
operator: = [2720,2721]
operator: = [2720,2721]
===
match
---
operator: = [1347,1348]
operator: = [1347,1348]
===
match
---
operator: = [1619,1620]
operator: = [1619,1620]
===
match
---
exprlist [4541,4551]
exprlist [4541,4551]
===
match
---
name: print [4115,4120]
name: print [4115,4120]
===
match
---
operator: , [1903,1904]
operator: , [1903,1904]
===
match
---
trailer [1486,1491]
trailer [1486,1491]
===
match
---
name: start [4865,4870]
name: start [4866,4871]
===
match
---
name: pkg_name [3878,3886]
name: pkg_name [3878,3886]
===
match
---
name: f [2340,2341]
name: f [2340,2341]
===
match
---
name: os [2541,2543]
name: os [2541,2543]
===
match
---
name: get_available_providers_packages [1138,1170]
name: get_available_providers_packages [1138,1170]
===
match
---
name: join [1487,1491]
name: join [1487,1491]
===
match
---
simple_stmt [1005,1049]
simple_stmt [1005,1049]
===
match
---
fstring_start: f" [4893,4895]
fstring_start: f" [4894,4896]
===
match
---
operator: { [2213,2214]
operator: { [2213,2214]
===
match
---
operator: = [4665,4666]
operator: = [4665,4666]
===
match
---
atom [3743,3865]
atom [3743,3865]
===
match
---
atom_expr [2855,2881]
atom_expr [2855,2881]
===
match
---
operator: , [3193,3194]
operator: , [3193,3194]
===
match
---
trailer [3924,3926]
trailer [3924,3926]
===
match
---
name: now [2613,2616]
name: now [2613,2616]
===
match
---
name: enumerate [4847,4856]
name: enumerate [4848,4857]
===
match
---
trailer [4384,4411]
trailer [4384,4411]
===
match
---
operator: , [3765,3766]
operator: , [3765,3766]
===
match
---
fstring_end: ' [3853,3854]
fstring_end: ' [3853,3854]
===
match
---
atom_expr [4715,4727]
atom_expr [4716,4728]
===
match
---
expr_stmt [3938,4036]
expr_stmt [3938,4036]
===
match
---
simple_stmt [2473,2499]
simple_stmt [2473,2499]
===
match
---
testlist_comp [3954,3973]
testlist_comp [3954,3973]
===
match
---
operator: } [2217,2218]
operator: } [2217,2218]
===
match
---
simple_stmt [941,957]
simple_stmt [941,957]
===
match
---
argument [3608,3629]
argument [3608,3629]
===
match
---
trailer [1443,1448]
trailer [1443,1448]
===
match
---
operator: , [1913,1914]
operator: , [1913,1914]
===
match
---
operator: = [3335,3336]
operator: = [3335,3336]
===
match
---
trailer [1319,1327]
trailer [1319,1327]
===
match
---
exprlist [3979,3998]
exprlist [3979,3998]
===
match
---
arglist [4857,4872]
arglist [4858,4873]
===
match
---
suite [4874,4918]
suite [4875,4919]
===
match
---
atom_expr [2696,2724]
atom_expr [2696,2724]
===
match
---
name: doc_url [3782,3789]
name: doc_url [3782,3789]
===
match
---
expr_stmt [2902,2946]
expr_stmt [2902,2946]
===
match
---
name: join [1553,1557]
name: join [1553,1557]
===
match
---
fstring_start: f" [4704,4706]
fstring_start: f" [4705,4707]
===
match
---
testlist_comp [4426,4468]
testlist_comp [4426,4468]
===
match
---
suite [2529,2725]
suite [2529,2725]
===
match
---
name: path [4532,4536]
name: path [4532,4536]
===
match
---
trailer [1367,1372]
trailer [1367,1372]
===
match
---
fstring_string: /objects.inv [3180,3192]
fstring_string: /objects.inv [3180,3192]
===
match
---
atom_expr [4069,4091]
atom_expr [4069,4091]
===
match
---
name: CURRENT_DIR [1378,1389]
name: CURRENT_DIR [1378,1389]
===
match
---
arglist [2413,2428]
arglist [2413,2428]
===
match
---
operator: = [2891,2892]
operator: = [2891,2892]
===
match
---
operator: , [3630,3631]
operator: , [3630,3631]
===
match
---
name: failed [4583,4589]
name: failed [4583,4589]
===
match
---
trailer [4703,4760]
trailer [4704,4761]
===
match
---
atom [2944,2946]
atom [2944,2946]
===
match
---
arglist [1378,1422]
arglist [1378,1422]
===
match
---
trailer [3918,3924]
trailer [3918,3924]
===
match
---
operator: = [2304,2305]
operator: = [2304,2305]
===
match
---
return_stmt [2473,2498]
return_stmt [2473,2498]
===
match
---
name: str [1910,1913]
name: str [1910,1913]
===
match
---
name: failed [4672,4678]
name: failed [4672,4678]
===
match
---
name: os [2843,2845]
name: os [2843,2845]
===
match
---
import_as_names [918,939]
import_as_names [918,939]
===
match
---
not_test [2153,2168]
not_test [2153,2168]
===
match
---
suite [3003,3219]
suite [3003,3219]
===
match
---
param [1859,1885]
param [1859,1885]
===
match
---
name: typing [904,910]
name: typing [904,910]
===
match
---
operator: { [3650,3651]
operator: { [3650,3651]
===
match
---
testlist_comp [4532,4566]
testlist_comp [4532,4566]
===
match
---
name: hours [2715,2720]
name: hours [2715,2720]
===
match
---
name: str [2931,2934]
name: str [2931,2934]
===
match
---
dotted_name [811,829]
dotted_name [811,829]
===
match
---
atom [3953,3974]
atom [3953,3974]
===
match
---
fstring_string: / [3169,3170]
fstring_string: / [3169,3170]
===
match
---
expr_stmt [4583,4644]
expr_stmt [4583,4644]
===
match
---
name: pkg_name [3171,3179]
name: pkg_name [3171,3179]
===
match
---
atom_expr [2413,2425]
atom_expr [2413,2425]
===
match
---
name: pkg_name [3832,3840]
name: pkg_name [3832,3840]
===
match
---
name: to_download [3500,3511]
name: to_download [3500,3511]
===
match
---
trailer [1327,1337]
trailer [1327,1337]
===
match
---
operator: , [4411,4412]
operator: , [4411,4412]
===
match
---
trailer [1314,1319]
trailer [1314,1319]
===
match
---
trailer [4685,4693]
trailer [4685,4694]
===
match
---
name: repeat [892,898]
name: repeat [892,898]
===
match
---
simple_stmt [3938,4037]
simple_stmt [3938,4037]
===
match
---
operator: } [3660,3661]
operator: } [3660,3661]
===
match
---
name: failed [4649,4655]
name: failed [4649,4655]
===
match
---
name: THIRD_PARTY_INDEXES [1274,1293]
name: THIRD_PARTY_INDEXES [1274,1293]
===
match
---
fstring [3648,3685]
fstring [3648,3685]
===
match
---
expr_stmt [2587,2676]
expr_stmt [2587,2676]
===
match
---
operator: , [1938,1939]
operator: , [1938,1939]
===
match
---
atom_expr [2351,2378]
atom_expr [2351,2378]
===
match
---
expr_stmt [1688,1765]
expr_stmt [1688,1765]
===
match
---
arglist [2106,2144]
arglist [2106,2144]
===
match
---
annassign [2913,2946]
annassign [2913,2946]
===
match
---
operator: , [3803,3804]
operator: , [3803,3804]
===
match
---
name: requests [948,956]
name: requests [948,956]
===
match
---
parameters [1858,1925]
parameters [1858,1925]
===
match
---
name: ThreadPoolExecutor [4230,4248]
name: ThreadPoolExecutor [4230,4248]
===
match
---
operator: = [2379,2380]
operator: = [2379,2380]
===
match
---
trailer [2669,2675]
trailer [2669,2675]
===
match
---
testlist_star_expr [4583,4598]
testlist_star_expr [4583,4598]
===
match
---
operator: , [3962,3963]
operator: , [3962,3963]
===
match
---
name: _fetch_file [4353,4364]
name: _fetch_file [4353,4364]
===
match
---
for_stmt [4818,4918]
for_stmt [4819,4919]
===
match
---
operator: , [4828,4829]
operator: , [4829,4830]
===
match
---
trailer [2555,2561]
trailer [2555,2561]
===
match
---
fstring_end: " [3802,3803]
fstring_end: " [3802,3803]
===
match
---
name: _fetch_file [1847,1858]
name: _fetch_file [1847,1858]
===
match
---
fstring_expr [3819,3830]
fstring_expr [3819,3830]
===
match
---
testlist_comp [3062,3194]
testlist_comp [3062,3194]
===
match
---
name: package_name [2236,2248]
name: package_name [2236,2248]
===
match
---
operator: , [2425,2426]
operator: , [2425,2426]
===
match
---
name: path [2276,2280]
name: path [2276,2280]
===
match
---
file_input [786,4972]
file_input [786,4973]
===
match
---
atom_expr [4136,4152]
atom_expr [4136,4152]
===
match
---
suite [2751,4972]
suite [2751,4973]
===
match
---
suite [4775,4918]
suite [4776,4919]
===
match
---
name: path [2325,2329]
name: path [2325,2329]
===
match
---
fstring_string: /apache-airflow/objects.inv [3380,3407]
fstring_string: /apache-airflow/objects.inv [3380,3407]
===
match
---
name: concurrent [4211,4221]
name: concurrent [4211,4221]
===
match
---
simple_stmt [856,870]
simple_stmt [856,870]
===
match
---
fstring_expr [3170,3180]
fstring_expr [3170,3180]
===
match
---
simple_stmt [4100,4110]
simple_stmt [4100,4110]
===
match
---
name: path [3969,3973]
name: path [3969,3973]
===
match
---
trailer [4742,4750]
trailer [4743,4751]
===
match
---
name: pkg_name [3129,3137]
name: pkg_name [3129,3137]
===
match
---
name: success [4719,4726]
name: success [4720,4727]
===
match
---
expr_stmt [2083,2145]
expr_stmt [2083,2145]
===
match
---
name: docs_build [1064,1074]
name: docs_build [1064,1074]
===
match
---
name: os [1312,1314]
name: os [1312,1314]
===
match
---
operator: , [1411,1412]
operator: , [1411,1412]
===
match
---
name: package_name [3608,3620]
name: package_name [3608,3620]
===
match
---
simple_stmt [1049,1174]
simple_stmt [1049,1174]
===
match
---
name: pkg_name [3434,3442]
name: pkg_name [3434,3442]
===
match
---
fstring_string: / [3830,3831]
fstring_string: / [3830,3831]
===
match
---
string: 'apache-airflow' [3336,3352]
string: 'apache-airflow' [3336,3352]
===
match
---
name: extend [3727,3733]
name: extend [3727,3733]
===
match
---
name: datetime [2630,2638]
name: datetime [2630,2638]
===
match
---
name: path [2858,2862]
name: path [2858,2862]
===
match
---
trailer [4610,4644]
trailer [4610,4644]
===
match
---
trailer [2629,2638]
trailer [2629,2638]
===
match
---
simple_stmt [1425,1467]
simple_stmt [1425,1467]
===
match
---
arglist [2325,2335]
arglist [2325,2335]
===
match
---
name: response [2413,2421]
name: response [2413,2421]
===
match
---
testlist [2480,2498]
testlist [2480,2498]
===
match
---
fstring_expr [4135,4153]
fstring_expr [4135,4153]
===
match
---
trailer [3108,3115]
trailer [3108,3115]
===
match
---
name: response [2157,2165]
name: response [2157,2165]
===
match
---
operator: , [4517,4518]
operator: , [4517,4518]
===
match
---
operator: , [1457,1458]
operator: , [1457,1458]
===
match
---
fstring [3779,3803]
fstring [3779,3803]
===
match
---
fstring_start: f" [2184,2186]
fstring_start: f" [2184,2186]
===
match
---
trailer [3241,3425]
trailer [3241,3425]
===
match
---
name: append [3235,3241]
name: append [3235,3241]
===
match
---
trailer [2616,2618]
trailer [2616,2618]
===
match
---
string: "/docs/{package_name}/latest/objects.inv" [1724,1765]
string: "/docs/{package_name}/latest/objects.inv" [1724,1765]
===
match
---
expr_stmt [4649,4693]
expr_stmt [4649,4694]
===
match
---
if_stmt [4041,4110]
if_stmt [4041,4110]
===
match
---
operator: , [4589,4590]
operator: , [4589,4590]
===
match
---
name: failed [4686,4692]
name: success [4686,4693]
===
match
---
name: dirname [2281,2288]
name: dirname [2281,2288]
===
match
---
atom_expr [1402,1411]
atom_expr [1402,1411]
===
match
---
dotted_name [1010,1031]
dotted_name [1010,1031]
===
match
---
operator: , [926,927]
operator: , [926,927]
===
match
---
operator: , [2131,2132]
operator: , [2131,2132]
===
match
---
trailer [1552,1557]
trailer [1552,1557]
===
match
---
fstring_expr [2461,2466]
fstring_expr [2461,2466]
===
match
---
import_from [1005,1048]
import_from [1005,1048]
===
match
---
name: CACHE_DIR [3820,3829]
name: CACHE_DIR [3820,3829]
===
match
---
name: path [1439,1443]
name: path [1439,1443]
===
match
---
name: _ [4452,4453]
name: _ [4452,4453]
===
match
---
name: bool [4322,4326]
name: bool [4322,4326]
===
match
---
atom [3952,4036]
atom [3952,4036]
===
match
---
subscriptlist [1935,1944]
subscriptlist [1935,1944]
===
match
---
operator: , [2294,2295]
operator: , [2294,2295]
===
match
---
name: timedelta [2705,2714]
name: timedelta [2705,2714]
===
match
---
trailer [2421,2425]
trailer [2421,2425]
===
match
---
name: utils [1018,1023]
name: utils [1018,1023]
===
match
---
fstring_start: f' [3367,3369]
fstring_start: f' [3367,3369]
===
match
---
expr_stmt [4284,4578]
expr_stmt [4284,4578]
===
match
---
return_stmt [4100,4109]
return_stmt [4100,4109]
===
match
---
arith_expr [1793,1840]
arith_expr [1793,1840]
===
match
---
operator: , [4447,4448]
operator: , [4447,4448]
===
match
---
name: DEFAULT_POOLSIZE [4249,4265]
name: DEFAULT_POOLSIZE [4249,4265]
===
match
---
name: open [2320,2324]
name: open [2320,2324]
===
match
---
simple_stmt [4284,4579]
simple_stmt [4284,4579]
===
match
---
atom_expr [3223,3425]
atom_expr [3223,3425]
===
match
---
name: S3_DOC_URL_VERSIONED [1688,1708]
name: S3_DOC_URL_VERSIONED [1688,1708]
===
match
---
suite [4060,4110]
suite [4060,4110]
===
match
---
operator: = [4599,4600]
operator: = [4599,4600]
===
match
---
name: package_name [3116,3128]
name: package_name [3116,3128]
===
match
---
subscriptlist [2926,2939]
subscriptlist [2926,2939]
===
match
---
name: to_download [4555,4566]
name: to_download [4555,4566]
===
match
---
trailer [2165,2168]
trailer [2165,2168]
===
match
---
name: to_download [3012,3023]
name: to_download [3012,3023]
===
match
---
fstring_string: Result:  [4706,4714]
fstring_string: Result:  [4707,4715]
===
match
---
trailer [4671,4679]
trailer [4671,4679]
===
match
---
simple_stmt [3223,3426]
simple_stmt [3223,3426]
===
match
---
atom_expr [2273,2294]
atom_expr [2273,2294]
===
match
---
name: pkg_name [3062,3070]
name: pkg_name [3062,3070]
===
match
---
fstring [4121,4168]
fstring [4121,4168]
===
match
---
operator: , [4469,4470]
operator: , [4469,4470]
===
match
---
name: status [4954,4960]
name: status [4955,4961]
===
match
---
name: partition [4601,4610]
name: partition [4601,4610]
===
match
---
name: Tuple [934,939]
name: Tuple [934,939]
===
match
---
arglist [1492,1520]
arglist [1492,1520]
===
match
---
operator: , [3281,3282]
operator: , [3281,3282]
===
match
---
name: _is_outdated [4017,4029]
name: _is_outdated [4017,4029]
===
match
---
number: 1 [4871,4872]
number: 1 [4872,4873]
===
match
---
testlist_comp [3265,3409]
testlist_comp [3265,3409]
===
match
---
atom_expr [1413,1422]
atom_expr [1413,1422]
===
match
---
trailer [4856,4873]
trailer [4857,4874]
===
match
---
simple_stmt [2902,2947]
simple_stmt [2902,2947]
===
match
---
name: path [2518,2522]
name: path [2518,2522]
===
match
---
expr_stmt [2351,2385]
expr_stmt [2351,2385]
===
match
---
atom_expr [1349,1424]
atom_expr [1349,1424]
===
match
---
name: _ [4841,4842]
name: _ [4842,4843]
===
match
---
name: Session [1877,1884]
name: Session [1877,1884]
===
match
---
sync_comp_for [3975,4035]
sync_comp_for [3975,4035]
===
match
---
import_from [1174,1296]
import_from [1174,1296]
===
match
---
testlist_comp [3757,3855]
testlist_comp [3757,3855]
===
match
---
name: pool [4331,4335]
name: pool [4331,4335]
===
match
---
atom [4107,4109]
atom [4107,4109]
===
match
---
simple_stmt [3715,3933]
simple_stmt [3715,3933]
===
match
---
name: download_results [4627,4643]
name: download_results [4627,4643]
===
match
---
arglist [1449,1465]
arglist [1449,1465]
===
match
---
operator: , [3987,3988]
operator: , [3987,3988]
===
match
---
name: raw [2360,2363]
name: raw [2360,2363]
===
match
---
simple_stmt [1338,1425]
simple_stmt [1338,1425]
===
match
---
name: get [2102,2105]
name: get [2102,2105]
===
match
---
name: stream [2133,2139]
name: stream [2133,2139]
===
match
---
import_from [1049,1173]
import_from [1049,1173]
===
match
---
fstring_end: ' [3684,3685]
fstring_end: ' [3684,3685]
===
match
---
trailer [2324,2336]
trailer [2324,2336]
===
match
---
testlist_comp [4484,4516]
testlist_comp [4484,4516]
===
match
---
arglist [2273,2309]
arglist [2273,2309]
===
match
---
param [1905,1914]
param [1905,1914]
===
match
---
name: pardir [1405,1411]
name: pardir [1405,1411]
===
match
---
name: get_available_providers_packages [2968,3000]
name: get_available_providers_packages [2968,3000]
===
match
---
name: d [4621,4622]
name: d [4621,4622]
===
match
---
name: Tuple [2920,2925]
name: Tuple [2920,2925]
===
match
---
fstring_string:  failed [4751,4758]
fstring_string:  failed [4752,4759]
===
match
---
name: url [1905,1908]
name: url [1905,1908]
===
match
---
simple_stmt [4583,4645]
simple_stmt [4583,4645]
===
match
---
atom_expr [2157,2168]
atom_expr [2157,2168]
===
match
---
name: getmtime [2661,2669]
name: getmtime [2661,2669]
===
match
---
operator: = [1543,1544]
operator: = [1543,1544]
===
match
---
operator: , [1293,1294]
operator: , [1293,1294]
===
match
---
atom_expr [1545,1606]
atom_expr [1545,1606]
===
match
---
testlist_star_expr [4649,4664]
testlist_star_expr [4649,4664]
===
match
---
simple_stmt [2178,2221]
simple_stmt [2178,2221]
===
match
---
operator: , [2329,2330]
operator: , [2329,2330]
===
match
---
atom_expr [3715,3932]
atom_expr [3715,3932]
===
match
---
name: datetime [2621,2629]
name: datetime [2621,2629]
===
match
---
name: list [4681,4685]
name: list [4681,4685]
===
match
---
name: docs_build [1189,1199]
name: docs_build [1189,1199]
===
match
---
if_stmt [2534,2583]
if_stmt [2534,2583]
===
match
---
operator: } [3179,3180]
operator: } [3179,3180]
===
match
---
fstring_start: f' [3648,3650]
fstring_start: f' [3648,3650]
===
match
---
name: datetime [2604,2612]
name: datetime [2604,2612]
===
match
---
suite [1946,2499]
suite [1946,2499]
===
match
---
operator: , [3558,3559]
operator: , [3558,3559]
===
match
---
name: str [1900,1903]
name: str [1900,1903]
===
match
---
operator: } [4727,4728]
operator: } [4728,4729]
===
match
---
atom_expr [2843,2897]
atom_expr [2843,2897]
===
match
---
not_test [4044,4059]
not_test [4044,4059]
===
match
---
fstring [4893,4916]
fstring [4894,4917]
===
match
---
simple_stmt [4887,4918]
simple_stmt [4888,4919]
===
match
---
atom_expr [2394,2429]
atom_expr [2394,2429]
===
match
---
trailer [3023,3030]
trailer [3023,3030]
===
match
---
number: 12 [2721,2723]
number: 12 [2721,2723]
===
match
---
atom_expr [2320,2336]
atom_expr [2320,2336]
===
match
---
not_test [2537,2561]
not_test [2537,2561]
===
match
---
operator: } [3168,3169]
operator: } [3168,3169]
===
match
---
atom [3251,3419]
atom [3251,3419]
===
match
---
operator: , [4392,4393]
operator: , [4392,4393]
===
match
---
name: _ [4541,4542]
name: _ [4541,4542]
===
match
---
lambdef [4611,4625]
lambdef [4611,4625]
===
match
---
trailer [4221,4229]
trailer [4221,4229]
===
match
---
suite [2562,2583]
suite [2562,2583]
===
match
---
trailer [2263,2272]
trailer [2263,2272]
===
match
---
string: "expiration-date" [1588,1605]
string: "expiration-date" [1588,1605]
===
match
---
name: dirname [2863,2870]
name: dirname [2863,2870]
===
match
---
name: futures [822,829]
name: futures [822,829]
===
match
---
trailer [1351,1356]
trailer [1351,1356]
===
match
---
name: pkg_name [3954,3962]
name: pkg_name [3954,3962]
===
match
---
operator: { [4905,4906]
operator: { [4906,4907]
===
match
---
name: CACHE_DIR [2871,2880]
name: CACHE_DIR [2871,2880]
===
match
---
name: url [2106,2109]
name: url [2106,2109]
===
match
---
simple_stmt [1688,1766]
simple_stmt [1688,1766]
===
match
---
operator: , [4498,4499]
operator: , [4498,4499]
===
match
---
operator: , [3886,3887]
operator: , [3886,3887]
===
match
---
sync_comp_for [4488,4516]
sync_comp_for [4488,4516]
===
match
---
trailer [4229,4248]
trailer [4229,4248]
===
match
---
name: to_download [4140,4151]
name: to_download [4140,4151]
===
match
---
parameters [2748,2750]
parameters [2748,2750]
===
match
---
name: print [2178,2183]
name: print [2178,2183]
===
match
---
name: len [4394,4397]
name: len [4394,4397]
===
match
---
name: pkg_no [4896,4902]
name: pkg_no [4897,4903]
===
match
---
atom_expr [3899,3926]
atom_expr [3899,3926]
===
match
---
name: bool [1940,1944]
name: bool [1940,1944]
===
match
---
atom_expr [1365,1423]
atom_expr [1365,1423]
===
match
---
tfpdef [1886,1903]
tfpdef [1886,1903]
===
match
---
name: docs [1179,1183]
name: docs [1179,1183]
===
match
---
trailer [1438,1443]
trailer [1438,1443]
===
match
---
trailer [4248,4266]
trailer [4248,4266]
===
match
---
name: pkg_name [4831,4839]
name: pkg_name [4832,4840]
===
match
---
param [2518,2527]
param [2518,2527]
===
match
---
testlist_comp [3550,3686]
testlist_comp [3550,3686]
===
match
---
operator: , [3138,3139]
operator: , [3138,3139]
===
match
---
simple_stmt [2843,2898]
simple_stmt [2843,2898]
===
match
---
name: Tuple [1929,1934]
name: Tuple [1929,1934]
===
match
---
fstring_expr [3369,3380]
fstring_expr [3369,3380]
===
match
---
tfpdef [1859,1884]
tfpdef [1859,1884]
===
match
---
simple_stmt [957,1004]
simple_stmt [957,1004]
===
match
---
operator: , [1389,1390]
operator: , [1389,1390]
===
match
---
name: docs_builder [1075,1087]
name: docs_builder [1075,1087]
===
match
---
operator: { [3369,3370]
operator: { [3369,3370]
===
match
---
trailer [4718,4727]
trailer [4719,4728]
===
match
---
atom_expr [4115,4169]
atom_expr [4115,4169]
===
match
---
trailer [4029,4035]
trailer [4029,4035]
===
match
---
simple_stmt [899,940]
simple_stmt [899,940]
===
match
---
trailer [3115,3138]
trailer [3115,3138]
===
match
---
name: len [4739,4742]
name: len [4740,4743]
===
match
---
name: path [3994,3998]
name: path [3994,3998]
===
match
---
trailer [2638,2652]
trailer [2638,2652]
===
match
---
trailer [2714,2724]
trailer [2714,2724]
===
match
---
operator: , [932,933]
operator: , [932,933]
===
match
---
operator: , [1566,1567]
operator: , [1566,1567]
===
match
---
trailer [2862,2870]
trailer [2862,2870]
===
match
---
name: CACHE_DIR [3651,3660]
name: CACHE_DIR [3651,3660]
===
match
---
operator: , [2881,2882]
operator: , [2881,2882]
===
match
---
name: str [1921,1924]
name: str [1921,1924]
===
match
---
operator: } [4902,4903]
operator: } [4903,4904]
===
match
---
name: DOCS_DIR [1558,1566]
name: DOCS_DIR [1558,1566]
===
match
---
trailer [3315,3322]
trailer [3315,3322]
===
match
---
name: response [2351,2359]
name: response [2351,2359]
===
match
---
name: os [2273,2275]
name: os [2273,2275]
===
match
---
string: '_inventory_cache' [1568,1586]
string: '_inventory_cache' [1568,1586]
===
match
---
trailer [2548,2555]
trailer [2548,2555]
===
match
---
simple_stmt [2681,2725]
simple_stmt [2681,2725]
===
match
---
fstring_string:  inventorie(s) [4153,4167]
fstring_string:  inventorie(s) [4153,4167]
===
match
---
name: pkg_name [2956,2964]
name: pkg_name [2956,2964]
===
match
---
operator: , [4952,4953]
operator: , [4953,4954]
===
match
---
operator: , [1586,1587]
operator: , [1586,1587]
===
match
---
operator: , [4493,4494]
operator: , [4493,4494]
===
match
---
if_stmt [4765,4918]
if_stmt [4766,4919]
===
match
---
name: exist_ok [2296,2304]
name: exist_ok [2296,2304]
===
match
---
name: raw [2422,2425]
name: raw [2422,2425]
===
match
---
operator: = [4329,4330]
operator: = [4329,4330]
===
match
---
trailer [3607,3630]
trailer [3607,3630]
===
match
---
name: pkg_name [4906,4914]
name: pkg_name [4907,4915]
===
match
---
simple_stmt [786,804]
simple_stmt [786,804]
===
match
---
atom_expr [1868,1884]
atom_expr [1868,1884]
===
match
---
operator: } [3379,3380]
operator: } [3379,3380]
===
match
---
operator: { [4738,4739]
operator: { [4739,4740]
===
match
---
name: abspath [1357,1364]
name: abspath [1357,1364]
===
match
---
operator: { [4135,4136]
operator: { [4135,4136]
===
match
---
name: airflow [1010,1017]
name: airflow [1010,1017]
===
match
---
fstring [3817,3854]
fstring [3817,3854]
===
match
---
operator: } [2465,2466]
operator: } [2465,2466]
===
match
---
atom_expr [1391,1400]
atom_expr [1391,1400]
===
match
---
import_as_names [1274,1294]
import_as_names [1274,1294]
===
match
---
tfpdef [2518,2527]
tfpdef [2518,2527]
===
match
---
name: path [4030,4034]
name: path [4030,4034]
===
match
---
fstring_expr [4738,4751]
fstring_expr [4739,4752]
===
match
---
param [1886,1904]
param [1886,1904]
===
match
---
name: copyfileobj [2401,2412]
name: copyfileobj [2401,2412]
===
match
---
name: to_download [4048,4059]
name: to_download [4048,4059]
===
match
---
operator: , [3967,3968]
operator: , [3967,3968]
===
match
---
name: success [4591,4598]
name: success [4591,4598]
===
match
---
name: path [2289,2293]
name: path [2289,2293]
===
match
---
atom_expr [1436,1466]
atom_expr [1436,1466]
===
match
---
name: append [3512,3518]
name: append [3512,3518]
===
match
---
name: failed [4857,4863]
name: failed [4858,4864]
===
match
---
testlist_star_expr [4667,4693]
testlist_star_expr [4667,4694]
===
match
---
name: download_results [4284,4300]
name: download_results [4284,4300]
===
match
---
name: session [2094,2101]
name: session [2094,2101]
===
match
---
name: print [4887,4892]
name: print [4888,4893]
===
match
---
name: itertools [875,884]
name: itertools [875,884]
===
match
---
expr_stmt [1766,1840]
expr_stmt [1766,1840]
===
match
---
atom_expr [1312,1337]
atom_expr [1312,1337]
===
match
---
name: failed [4768,4774]
name: failed [4769,4775]
===
match
---
operator: } [3840,3841]
operator: } [3840,3841]
===
match
---
atom [3044,3208]
atom [3044,3208]
===
match
---
operator: , [4863,4864]
operator: , [4864,4865]
===
match
---
name: to_download [3223,3234]
name: to_download [3223,3234]
===
match
---
atom_expr [2541,2561]
atom_expr [2541,2561]
===
match
---
sync_comp_for [4435,4468]
sync_comp_for [4435,4468]
===
match
---
import_name [786,803]
import_name [786,803]
===
match
---
operator: , [3473,3474]
operator: , [3473,3474]
===
match
---
string: 'wb' [2331,2335]
string: 'wb' [2331,2335]
===
match
---
sync_comp_for [4537,4566]
sync_comp_for [4537,4566]
===
match
---
fstring_end: " [4758,4759]
fstring_end: " [4759,4760]
===
match
---
trailer [1448,1466]
trailer [1448,1466]
===
match
---
name: delta [2688,2693]
name: delta [2688,2693]
===
match
---
name: os [853,855]
name: os [853,855]
===
match
---
atom [4483,4517]
atom [4483,4517]
===
match
---
fstring_end: ' [3407,3408]
fstring_end: ' [3407,3408]
===
match
---
trailer [3518,3710]
trailer [3518,3710]
===
match
---
operator: { [4714,4715]
operator: { [4715,4716]
===
match
---
atom_expr [4311,4327]
atom_expr [4311,4327]
===
match
---
operator: { [3819,3820]
operator: { [3819,3820]
===
match
---
arglist [4353,4568]
arglist [4353,4568]
===
match
---
name: os [1349,1351]
name: os [1349,1351]
===
match
---
testlist_comp [3447,3489]
testlist_comp [3447,3489]
===
match
---
trailer [2412,2429]
trailer [2412,2429]
===
match
---
atom_expr [2595,2618]
atom_expr [2595,2618]
===
match
---
operator: , [3070,3071]
operator: , [3070,3071]
===
match
---
name: S3_DOC_URL_NON_VERSIONED [1766,1790]
name: S3_DOC_URL_NON_VERSIONED [1766,1790]
===
match
---
name: package_name [2480,2492]
name: package_name [2480,2492]
===
match
---
operator: , [3854,3855]
operator: , [3854,3855]
===
match
---
name: os [1391,1393]
name: os [1391,1393]
===
match
---
operator: = [2593,2594]
operator: = [2593,2594]
===
match
---
name: EXPIRATION_DATE_PATH [1522,1542]
name: EXPIRATION_DATE_PATH [1522,1542]
===
match
---
operator: , [4209,4210]
operator: , [4209,4210]
===
match
---
name: path [1548,1552]
name: path [1548,1552]
===
match
---
argument [3743,3926]
argument [3743,3926]
===
match
---
name: path [1352,1356]
name: path [1352,1356]
===
match
---
atom_expr [4667,4679]
atom_expr [4667,4679]
===
match
---
name: path [1315,1319]
name: path [1315,1319]
===
match
---
name: S3_DOC_URL_NON_VERSIONED [3576,3600]
name: S3_DOC_URL_NON_VERSIONED [3576,3600]
===
match
---
atom_expr [4887,4917]
atom_expr [4888,4918]
===
match
---
name: d [4618,4619]
name: d [4618,4619]
===
match
---
name: S3_DOC_URL [1711,1721]
name: S3_DOC_URL [1711,1721]
===
match
---
param [4618,4619]
param [4618,4619]
===
match
---
fstring_end: ' [3192,3193]
fstring_end: ' [3192,3193]
===
match
---
name: package_name [3323,3335]
name: package_name [3323,3335]
===
match
---
simple_stmt [2394,2430]
simple_stmt [2394,2430]
===
match
---
name: requests [962,970]
name: requests [962,970]
===
match
---
argument [2111,2131]
argument [2111,2131]
===
match
---
string: """     Download a file and returns status information as a tuple with package     name and success status(bool value).     """ [1951,2078]
string: """     Download a file and returns status information as a tuple with package     name and success status(bool value).     """ [1951,2078]
===
match
---
name: url [4495,4498]
name: url [4495,4498]
===
match
---
trailer [2652,2676]
trailer [2652,2676]
===
match
---
argument [3116,3137]
argument [3116,3137]
===
match
---
trailer [3600,3607]
trailer [3600,3607]
===
match
---
fstring_start: f" [3779,3781]
fstring_start: f" [3779,3781]
===
match
---
name: makedirs [2846,2854]
name: makedirs [2846,2854]
===
match
---
operator: } [4152,4153]
operator: } [4152,4153]
===
match
---
trailer [1372,1377]
trailer [1372,1377]
===
match
---
fstring [2440,2467]
fstring [2440,2467]
===
match
---
name: _ [4544,4545]
name: _ [4544,4545]
===
match
---
name: list [4667,4671]
name: list [4667,4671]
===
match
---
trailer [2925,2940]
trailer [2925,2940]
===
match
---
name: ok [2166,2168]
name: ok [2166,2168]
===
match
---
fstring_string: Failed to fetch inventory:  [2186,2213]
fstring_string: Failed to fetch inventory:  [2186,2213]
===
match
---
operator: , [3992,3993]
operator: , [3992,3993]
===
match
---
operator: , [4567,4568]
operator: , [4567,4568]
===
match
---
simple_stmt [1298,1338]
simple_stmt [1298,1338]
===
match
---
trailer [1364,1424]
trailer [1364,1424]
===
match
---
name: session [4202,4209]
name: session [4202,4209]
===
match
---
name: allow_redirects [2111,2126]
name: allow_redirects [2111,2126]
===
match
---
simple_stmt [1608,1688]
simple_stmt [1608,1688]
===
match
---
name: str [2926,2929]
name: str [2926,2929]
===
match
---
simple_stmt [2351,2386]
simple_stmt [2351,2386]
===
match
---
funcdef [1843,2499]
funcdef [1843,2499]
===
match
---
operator: = [2942,2943]
operator: = [2942,2943]
===
match
---
name: requests [1868,1876]
name: requests [1868,1876]
===
match
---
fstring_end: " [2218,2219]
fstring_end: " [2218,2219]
===
match
---
simple_stmt [870,899]
simple_stmt [870,899]
===
match
---
trailer [4196,4198]
trailer [4196,4198]
===
match
---
operator: = [1709,1710]
operator: = [1709,1710]
===
match
---
name: concurrent [793,803]
name: concurrent [793,803]
===
match
---
name: response [2083,2091]
name: response [2083,2091]
===
match
---
fstring_start: f' [3817,3819]
fstring_start: f' [3817,3819]
===
match
---
string: "apache-airflow" [3265,3281]
string: "apache-airflow" [3265,3281]
===
match
---
trailer [2439,2468]
trailer [2439,2468]
===
match
---
atom_expr [4621,4625]
atom_expr [4621,4625]
===
match
---
trailer [2400,2412]
trailer [2400,2412]
===
match
---
simple_stmt [1522,1607]
simple_stmt [1522,1607]
===
match
---
param [1915,1924]
param [1915,1924]
===
match
---
name: os [1479,1481]
name: os [1479,1481]
===
match
---
name: path [2556,2560]
name: path [2556,2560]
===
match
---
comp_if [4014,4035]
comp_if [4014,4035]
===
match
---
name: _ [4449,4450]
name: _ [4449,4450]
===
match
---
trailer [2280,2288]
trailer [2280,2288]
===
match
---
simple_stmt [2571,2583]
simple_stmt [2571,2583]
===
match
---
trailer [4074,4091]
trailer [4074,4091]
===
match
---
name: List [928,932]
name: List [928,932]
===
match
---
name: pkg_name [3663,3671]
name: pkg_name [3663,3671]
===
match
---
operator: , [4450,4451]
operator: , [4450,4451]
===
match
---
name: pkg_name [3621,3629]
name: pkg_name [3621,3629]
===
match
---
atom [4930,4971]
atom [4931,4972]
===
match
---
simple_stmt [804,830]
simple_stmt [804,830]
===
match
---
operator: = [4870,4871]
operator: = [4871,4872]
===
match
---
name: str [2936,2939]
name: str [2936,2939]
===
match
---
if_stmt [2150,2256]
if_stmt [2150,2256]
===
match
---
fstring_expr [4714,4728]
fstring_expr [4715,4729]
===
match
---
string: '_inventory_cache' [1502,1520]
string: '_inventory_cache' [1502,1520]
===
match
---
exprlist [4944,4960]
exprlist [4945,4961]
===
match
---
trailer [4188,4196]
trailer [4188,4196]
===
match
---
simple_stmt [4784,4810]
simple_stmt [4785,4811]
===
match
---
name: CACHE_DIR [1467,1476]
name: CACHE_DIR [1467,1476]
===
match
---
operator: { [3831,3832]
operator: { [3831,3832]
===
match
---
atom_expr [2968,3002]
atom_expr [2968,3002]
===
match
---
name: datetime [837,845]
name: datetime [837,845]
===
match
---
for_stmt [3430,3711]
for_stmt [3430,3711]
===
match
---
operator: , [2929,2930]
operator: , [2929,2930]
===
match
---
atom_expr [4698,4760]
atom_expr [4699,4761]
===
match
---
name: map [4336,4339]
name: map [4336,4339]
===
match
---
fstring_end: " [4167,4168]
fstring_end: " [4167,4168]
===
match
---
operator: , [4364,4365]
operator: , [4364,4365]
===
match
---
name: DOCS_DIR [1425,1433]
name: DOCS_DIR [1425,1433]
===
match
---
name: to_download [4505,4516]
name: to_download [4505,4516]
===
match
---
for_stmt [2952,3219]
for_stmt [2952,3219]
===
match
---
trailer [3234,3241]
trailer [3234,3241]
===
match
---
trailer [4310,4328]
trailer [4310,4328]
===
match
---
name: Iterator [918,926]
name: Iterator [918,926]
===
match
---
name: adapters [971,979]
name: adapters [971,979]
===
match
---
trailer [4789,4809]
trailer [4790,4810]
===
match
---
name: third_party_inventories [1200,1223]
name: third_party_inventories [1200,1223]
===
match
---
name: url [2462,2465]
name: url [2462,2465]
===
match
---
fstring_expr [3831,3841]
fstring_expr [3831,3841]
===
match
---
simple_stmt [4115,4170]
simple_stmt [4115,4170]
===
match
---
arith_expr [1711,1765]
arith_expr [1711,1765]
===
match
---
operator: , [1884,1885]
operator: , [1884,1885]
===
match
---
atom_expr [2178,2220]
atom_expr [2178,2220]
===
match
---
name: items [3919,3924]
name: items [3919,3924]
===
match
---
with_item [4180,4209]
with_item [4180,4209]
===
match
---
operator: , [3685,3686]
operator: , [3685,3686]
===
match
---
operator: , [2934,2935]
operator: , [2934,2935]
===
match
---
fstring_string: .  [4903,4905]
fstring_string: .  [4904,4906]
===
match
---
name: delta [2587,2592]
name: delta [2587,2592]
===
match
---
testlist_comp [4831,4842]
testlist_comp [4832,4843]
===
match
---
name: makedirs [2264,2272]
name: makedirs [2264,2272]
===
match
---
simple_stmt [4649,4694]
simple_stmt [4649,4695]
===
match
---
atom_expr [4394,4410]
atom_expr [4394,4410]
===
match
---
name: path [1482,1486]
name: path [1482,1486]
===
match
---
atom_expr [4601,4644]
atom_expr [4601,4644]
===
match
---
name: pkg_name [4439,4447]
name: pkg_name [4439,4447]
===
match
---
trailer [3000,3002]
trailer [3000,3002]
===
match
---
trailer [1547,1552]
trailer [1547,1552]
===
match
---
trailer [2272,2310]
trailer [2272,2310]
===
match
---
fstring_start: f' [3156,3158]
fstring_start: f' [3156,3158]
===
match
---
import_name [846,855]
import_name [846,855]
===
match
---
number: 1 [4623,4624]
number: 1 [4623,4624]
===
match
---
atom_expr [3012,3218]
atom_expr [3012,3218]
===
match
---
arith_expr [2595,2676]
arith_expr [2595,2676]
===
match
---
trailer [4339,4578]
trailer [4339,4578]
===
match
---
name: append [3024,3030]
name: append [3024,3030]
===
match
---
name: to_download [2902,2913]
name: to_download [2902,2913]
===
match
---
trailer [1377,1423]
trailer [1377,1423]
===
match
---
operator: - [2619,2620]
operator: - [2619,2620]
===
match
---
name: failed [4743,4749]
name: failed [4744,4750]
===
match
---
name: path [1915,1919]
name: path [1915,1919]
===
match
---
atom_expr [2261,2310]
atom_expr [2261,2310]
===
match
---
trailer [2275,2280]
trailer [2275,2280]
===
match
---
return_stmt [2229,2255]
return_stmt [2229,2255]
===
match
---
name: str [1935,1938]
name: str [1935,1938]
===
match
---
name: to_download [4457,4468]
name: to_download [4457,4468]
===
match
---
name: pardir [1394,1400]
name: pardir [1394,1400]
===
match
---
operator: = [1434,1435]
operator: = [1434,1435]
===
match
---
trailer [4892,4917]
trailer [4893,4918]
===
match
---
annassign [4300,4578]
annassign [4300,4578]
===
match
---
name: to_download [4002,4013]
name: to_download [4002,4013]
===
match
---
operator: { [3662,3663]
operator: { [3662,3663]
===
match
---
name: url [4484,4487]
name: url [4484,4487]
===
match
---
name: path [2670,2674]
name: path [2670,2674]
===
match
---
name: session [4385,4392]
name: session [4385,4392]
===
match
---
atom_expr [2094,2145]
atom_expr [2094,2145]
===
match
---
fstring_expr [3662,3672]
fstring_expr [3662,3672]
===
match
---
string: "Nothing to do" [4075,4090]
string: "Nothing to do" [4075,4090]
===
match
---
trailer [3733,3932]
trailer [3733,3932]
===
match
---
name: shutil [863,869]
name: shutil [863,869]
===
match
---
funcdef [2727,4972]
funcdef [2727,4973]
===
match
---
name: futures [4222,4229]
name: futures [4222,4229]
===
match
---
name: failed [4964,4970]
name: failed [4965,4971]
===
match
---
operator: } [3789,3790]
operator: } [3789,3790]
===
match
---
trailer [2288,2294]
trailer [2288,2294]
===
match
---
name: print [4784,4789]
name: print [4785,4790]
===
match
---
name: success [4657,4664]
name: success [4657,4664]
===
match
---
with_item [4211,4274]
with_item [4211,4274]
===
match
---
string: "/docs/{package_name}/objects.inv" [1806,1840]
string: "/docs/{package_name}/objects.inv" [1806,1840]
===
match
---
name: os [1436,1438]
name: os [1436,1438]
===
match
---
arglist [4385,4410]
arglist [4385,4410]
===
match
---
simple_stmt [1951,2079]
simple_stmt [1951,2079]
===
match
---
atom_expr [4331,4578]
atom_expr [4331,4578]
===
match
---
comparison [2688,2724]
comparison [2688,2724]
===
match
---
trailer [2854,2897]
trailer [2854,2897]
===
match
---
trailer [2919,2941]
trailer [2919,2941]
===
match
---
name: f [2427,2428]
name: f [2427,2428]
===
match
---
atom_expr [4378,4411]
atom_expr [4378,4411]
===
match
---
name: partition [1039,1048]
name: partition [1039,1048]
===
match
---
name: CACHE_DIR [3159,3168]
name: CACHE_DIR [3159,3168]
===
match
---
operator: = [2126,2127]
operator: = [2126,2127]
===
match
---
name: pkg_name [3979,3987]
name: pkg_name [3979,3987]
===
match
---
trailer [2704,2714]
trailer [2704,2714]
===
match
---
name: doc_url [3888,3895]
name: doc_url [3888,3895]
===
match
---
name: __file__ [1328,1336]
name: __file__ [1328,1336]
===
match
---
tfpdef [1905,1913]
tfpdef [1905,1913]
===
match
---
simple_stmt [2434,2469]
simple_stmt [2434,2469]
===
match
---
simple_stmt [2756,2839]
simple_stmt [2756,2839]
===
match
---
trailer [2655,2660]
trailer [2655,2660]
===
match
---
trailer [2359,2363]
trailer [2359,2363]
===
match
---
operator: > [2694,2695]
operator: > [2694,2695]
===
match
---
operator: = [1477,1478]
operator: = [1477,1478]
===
match
---
name: requests [4180,4188]
name: requests [4180,4188]
===
match
---
name: path [1368,1372]
name: path [1368,1372]
===
match
---
atom_expr [2920,2940]
atom_expr [2920,2940]
===
match
---
operator: { [3781,3782]
operator: { [3781,3782]
===
match
---
trailer [3322,3353]
trailer [3322,3353]
===
match
---
operator: , [1400,1401]
operator: , [1400,1401]
===
match
---
trailer [3030,3218]
trailer [3030,3218]
===
match
---
name: S3_DOC_URL_VERSIONED [3088,3108]
name: S3_DOC_URL_VERSIONED [3088,3108]
===
match
---
suite [3491,3711]
suite [3491,3711]
===
match
---
name: format [3601,3607]
name: format [3601,3607]
===
match
---
fstring [2184,2219]
fstring [2184,2219]
===
match
---
atom_expr [2915,2941]
atom_expr [2915,2941]
===
match
---
trailer [1404,1411]
trailer [1404,1411]
===
match
---
name: S3_DOC_URL [1608,1618]
name: S3_DOC_URL [1608,1618]
===
match
---
return_stmt [2681,2724]
return_stmt [2681,2724]
===
match
---
name: datetime [2696,2704]
name: datetime [2696,2704]
===
match
---
name: os [2855,2857]
name: os [2855,2857]
===
match
---
name: url [3964,3967]
name: url [3964,3967]
===
match
---
atom [4531,4567]
atom [4531,4567]
===
match
---
trailer [2603,2612]
trailer [2603,2612]
===
match
---
atom_expr [1479,1521]
atom_expr [1479,1521]
===
match
---
name: os [2653,2655]
name: os [2653,2655]
===
match
---
name: exist_ok [2883,2891]
name: exist_ok [2883,2891]
===
match
---
name: DOCS_DIR [1492,1500]
name: DOCS_DIR [1492,1500]
===
match
---
name: to_download [3938,3949]
name: to_download [3938,3949]
===
match
---
atom_expr [4739,4750]
atom_expr [4740,4751]
===
match
---
name: _ [4492,4493]
name: _ [4492,4493]
===
match
---
operator: { [2461,2462]
operator: { [2461,2462]
===
match
---
name: os [1413,1415]
name: os [1413,1415]
===
match
---
name: DEFAULT_POOLSIZE [987,1003]
name: DEFAULT_POOLSIZE [987,1003]
===
match
---
trailer [1876,1884]
trailer [1876,1884]
===
match
---
name: session [1859,1866]
name: session [1859,1866]
===
match
---
testlist_comp [3953,4035]
testlist_comp [3953,4035]
===
match
---
fstring_string: Fetched inventory:  [2442,2461]
fstring_string: Fetched inventory:  [2442,2461]
===
match
---
simple_stmt [4069,4092]
simple_stmt [4069,4092]
===
match
---
name: _ [4500,4501]
name: _ [4500,4501]
===
match
---
simple_stmt [2587,2677]
simple_stmt [2587,2677]
===
match
---
name: Session [4189,4196]
name: Session [4189,4196]
===
match
---
with_item [2320,2341]
with_item [2320,2341]
===
match
---
operator: + [1722,1723]
operator: + [1722,1723]
===
match
---
argument [2883,2896]
argument [2883,2896]
===
match
---
operator: , [2109,2110]
operator: , [2109,2110]
===
match
---
subscriptlist [4317,4326]
subscriptlist [4317,4326]
===
match
---
trailer [4397,4410]
trailer [4397,4410]
===
match
---
trailer [1356,1364]
trailer [1356,1364]
===
match
---
trailer [2870,2881]
trailer [2870,2881]
===
match
---
simple_stmt [4698,4761]
simple_stmt [4699,4762]
===
match
---
suite [4275,4579]
suite [4275,4579]
===
match
---
fstring_expr [3781,3790]
fstring_expr [3781,3790]
===
match
---
name: pkg_name [4931,4939]
name: pkg_name [4932,4940]
===
match
---
string: 'docs' [1459,1465]
string: 'docs' [1459,1465]
===
match
---
atom_expr [4302,4328]
atom_expr [4302,4328]
===
match
---
name: ROOT_DIR [1338,1346]
name: ROOT_DIR [1338,1346]
===
match
---
operator: = [1310,1311]
operator: = [1310,1311]
===
match
---
argument [2296,2309]
argument [2296,2309]
===
match
---
dotted_name [1179,1223]
dotted_name [1179,1223]
===
match
---
operator: , [2492,2493]
operator: , [2492,2493]
===
match
---
argument [2715,2723]
argument [2715,2723]
===
match
---
import_from [957,1003]
import_from [957,1003]
===
match
---
operator: } [3671,3672]
operator: } [3671,3672]
===
match
---
name: to_download [3715,3726]
name: to_download [3715,3726]
===
match
---
trailer [4139,4152]
trailer [4139,4152]
===
match
---
operator: , [4679,4680]
operator: , [4679,4680]
===
match
---
arglist [1558,1605]
arglist [1558,1605]
===
match
---
operator: } [4914,4915]
operator: } [4915,4916]
===
match
---
suite [2342,2430]
suite [2342,2430]
===
match
---
name: fetch_inventories [2731,2748]
name: fetch_inventories [2731,2748]
===
match
---
fstring [3367,3408]
fstring [3367,3408]
===
match
---
trailer [1934,1945]
trailer [1934,1945]
===
match
---
atom_expr [3500,3710]
atom_expr [3500,3710]
===
match
---
name: pool [4270,4274]
name: pool [4270,4274]
===
match
---
operator: } [3829,3830]
operator: } [3829,3830]
===
match
---
atom_expr [3295,3353]
atom_expr [3295,3353]
===
match
---
atom [3446,3490]
atom [3446,3490]
===
match
---
trailer [3726,3733]
trailer [3726,3733]
===
match
---
fstring_start: f" [2440,2442]
fstring_start: f" [2440,2442]
===
match
---
atom_expr [4681,4693]
atom_expr [4681,4694]
===
match
---
fstring_expr [4905,4915]
fstring_expr [4906,4916]
===
match
---
fstring_expr [4895,4903]
fstring_expr [4896,4904]
===
match
---
operator: , [3353,3354]
operator: , [3353,3354]
===
match
---
import_name [941,956]
import_name [941,956]
===
match
---
atom_expr [4180,4198]
atom_expr [4180,4198]
===
match
---
import_name [856,869]
import_name [856,869]
===
match
---
string: 'apache-airflow-providers' [3447,3473]
string: 'apache-airflow-providers' [3447,3473]
===
match
---
name: format [3316,3322]
name: format [3316,3322]
===
match
---
atom_expr [3088,3138]
atom_expr [3088,3138]
===
match
---
name: join [1444,1448]
name: join [1444,1448]
===
match
---
fstring_string: To download  [4123,4135]
fstring_string: To download  [4123,4135]
===
match
---
fstring [3156,3193]
fstring [3156,3193]
===
match
---
operator: , [1170,1171]
operator: , [1170,1171]
===
match
---
operator: , [4320,4321]
operator: , [4320,4321]
===
match
---
trailer [2105,2145]
trailer [2105,2145]
===
match
---
name: helpers [1024,1031]
name: helpers [1024,1031]
===
match
---
name: docs [1054,1058]
name: docs [1054,1058]
===
match
---
name: CURRENT_DIR [1298,1309]
name: CURRENT_DIR [1298,1309]
===
match
---
name: CACHE_DIR [3370,3379]
name: CACHE_DIR [3370,3379]
===
match
---
string: """Fetch all inventories for Airflow documentation packages and store in cache.""" [2756,2838]
string: """Fetch all inventories for Airflow documentation packages and store in cache.""" [2756,2838]
===
match
---
name: pkg_name [3550,3558]
name: pkg_name [3550,3558]
===
match
---
import_name [804,829]
import_name [804,829]
===
match
---
atom_expr [4847,4873]
atom_expr [4848,4874]
===
match
---
operator: , [4545,4546]
operator: , [4545,4546]
===
match
---
dotted_name [1054,1087]
dotted_name [1054,1087]
===
match
---
expr_stmt [1298,1337]
expr_stmt [1298,1337]
===
match
---
name: S3_DOC_URL_VERSIONED [3295,3315]
name: S3_DOC_URL_VERSIONED [3295,3315]
===
match
---
operator: + [1804,1805]
operator: + [1804,1805]
===
match
---
fstring [4704,4759]
fstring [4705,4760]
===
update-node
---
fstring_string: , success  [4728,4738]
replace , success  by  success, 
===
update-node
---
name: failed [4686,4692]
replace failed by success
