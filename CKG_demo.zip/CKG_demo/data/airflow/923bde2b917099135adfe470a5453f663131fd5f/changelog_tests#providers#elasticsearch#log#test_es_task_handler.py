===
match
---
not_test [9899,9929]
not_test [9918,9948]
===
match
---
name: join [11778,11782]
name: join [11797,11801]
===
match
---
string: 'offset' [9965,9973]
string: 'offset' [9984,9992]
===
match
---
name: ts [5460,5462]
name: ts [5479,5481]
===
match
---
comparison [8358,8385]
comparison [8377,8404]
===
match
---
name: es_task_handler [13037,13052]
name: es_task_handler [13056,13071]
===
match
---
name: ti [11289,11291]
name: ti [11308,11310]
===
match
---
name: self [7495,7499]
name: self [7514,7518]
===
match
---
simple_stmt [9207,9270]
simple_stmt [9226,9289]
===
match
---
string: 'log_id' [10824,10832]
string: 'log_id' [10843,10851]
===
match
---
simple_stmt [11710,11739]
simple_stmt [11729,11758]
===
match
---
string: 'exception' [9360,9371]
string: 'exception' [9379,9390]
===
match
---
atom_expr [6845,6852]
atom_expr [6864,6871]
===
match
---
name: format [12484,12490]
name: format [12503,12509]
===
match
---
operator: = [1899,1900]
operator: = [1899,1900]
===
match
---
dotted_name [15195,15215]
dotted_name [15214,15234]
===
match
---
suite [8676,9270]
suite [8695,9289]
===
match
---
name: ts [4108,4110]
name: ts [4108,4110]
===
match
---
trailer [5826,5829]
trailer [5845,5848]
===
match
---
dictorsetmaker [4781,4851]
dictorsetmaker [4781,4851]
===
match
---
operator: , [3779,3780]
operator: , [3779,3780]
===
match
---
trailer [5248,5252]
trailer [5267,5271]
===
match
---
operator: = [3398,3399]
operator: = [3398,3399]
===
match
---
with_item [11752,11874]
with_item [11771,11893]
===
match
---
operator: = [2791,2792]
operator: = [2791,2792]
===
match
---
trailer [2818,2863]
trailer [2818,2863]
===
match
---
operator: == [9949,9951]
operator: == [9968,9970]
===
match
---
trailer [12215,12231]
trailer [12234,12250]
===
match
---
dotted_name [874,886]
dotted_name [874,886]
===
match
---
trailer [5092,5096]
trailer [5094,5098]
===
match
---
atom_expr [9489,9513]
atom_expr [9508,9532]
===
match
---
operator: = [2594,2595]
operator: = [2594,2595]
===
match
---
name: dag [2924,2927]
name: dag [2924,2927]
===
match
---
name: self [7448,7452]
name: self [7467,7471]
===
match
---
trailer [4688,4696]
trailer [4688,4696]
===
match
---
simple_stmt [12286,12305]
simple_stmt [12305,12324]
===
match
---
trailer [12290,12293]
trailer [12309,12312]
===
match
---
number: 5 [8080,8081]
number: 5 [8099,8100]
===
match
---
simple_stmt [3971,3991]
simple_stmt [3971,3991]
===
match
---
simple_stmt [11380,11479]
simple_stmt [11399,11498]
===
match
---
number: 0 [9056,9057]
number: 0 [9075,9076]
===
match
---
operator: = [4736,4737]
operator: = [4736,4737]
===
match
---
assert_stmt [13764,13798]
assert_stmt [13783,13817]
===
match
---
operator: , [8249,8250]
operator: , [8268,8269]
===
match
---
atom_expr [3100,3114]
atom_expr [3100,3114]
===
match
---
name: json_format [10728,10739]
name: json_format [10747,10758]
===
match
---
name: index_name [6196,6206]
name: index_name [6215,6225]
===
match
---
name: ElasticsearchTaskHandler [1177,1201]
name: ElasticsearchTaskHandler [1177,1201]
===
match
---
name: es_task_handler [11613,11628]
name: es_task_handler [11632,11647]
===
match
---
name: self [10378,10382]
name: self [10397,10401]
===
match
---
arglist [13983,14051]
arglist [14002,14070]
===
match
---
name: json_fields [2330,2341]
name: json_fields [2330,2341]
===
match
---
name: timezone [9214,9222]
name: timezone [9233,9241]
===
match
---
simple_stmt [8914,8936]
simple_stmt [8933,8955]
===
match
---
name: read [12121,12125]
name: read [12140,12144]
===
match
---
string: 'end_of_log' [11341,11353]
string: 'end_of_log' [11360,11372]
===
match
---
trailer [12159,12175]
trailer [12178,12194]
===
match
---
name: state [3054,3059]
name: state [3054,3059]
===
match
---
arglist [11284,11361]
arglist [11303,11380]
===
match
---
name: index [6185,6190]
name: index [6204,6209]
===
match
---
operator: } [7553,7554]
operator: } [7572,7573]
===
match
---
string: "Could not read log with log_id:" [9737,9770]
string: "Could not read log with log_id:" [9756,9789]
===
match
---
atom_expr [13629,13672]
atom_expr [13648,13691]
===
match
---
atom_expr [2230,2250]
atom_expr [2230,2250]
===
match
---
atom_expr [12112,12135]
atom_expr [12131,12154]
===
match
---
operator: , [3844,3845]
operator: , [3844,3845]
===
match
---
atom_expr [2712,2794]
atom_expr [2712,2794]
===
match
---
simple_stmt [6942,6985]
simple_stmt [6961,7004]
===
match
---
expr_stmt [10519,10538]
expr_stmt [10538,10557]
===
match
---
name: Exception [9516,9525]
name: Exception [9535,9544]
===
match
---
atom_expr [12753,12760]
atom_expr [12772,12779]
===
match
---
testlist_star_expr [4984,4999]
testlist_star_expr [4984,4999]
===
match
---
trailer [10463,10466]
trailer [10482,10485]
===
match
---
atom_expr [11783,11806]
atom_expr [11802,11825]
===
match
---
name: len [8333,8336]
name: len [8352,8355]
===
match
---
name: self [14773,14777]
name: self [14792,14796]
===
match
---
name: _render_log_id [14900,14914]
name: _render_log_id [14919,14933]
===
match
---
name: metadatas [6252,6261]
name: metadatas [6271,6280]
===
match
---
testlist_star_expr [6801,6816]
testlist_star_expr [6820,6835]
===
match
---
name: self [4017,4021]
name: self [4017,4021]
===
match
---
simple_stmt [9071,9109]
simple_stmt [9090,9128]
===
match
---
trailer [5554,5559]
trailer [5573,5578]
===
match
---
name: Formatter [10204,10213]
name: Formatter [10223,10232]
===
match
---
atom_expr [12211,12238]
atom_expr [12230,12257]
===
match
---
trailer [12627,12634]
trailer [12646,12653]
===
match
---
name: operators [1076,1085]
name: operators [1076,1085]
===
match
---
name: es_task_handler [4022,4037]
name: es_task_handler [4022,4037]
===
match
---
number: 11 [15112,15114]
number: 11 [15131,15133]
===
match
---
atom [15225,15489]
atom [15244,15508]
===
match
---
string: 'last_log_timestamp' [7973,7993]
string: 'last_log_timestamp' [7992,8012]
===
match
---
string: '{dag_id}-{task_id}-{execution_date}-{try_number}' [1819,1869]
string: '{dag_id}-{task_id}-{execution_date}-{try_number}' [1819,1869]
===
match
---
name: end_of_log_mark [12553,12568]
name: end_of_log_mark [12572,12587]
===
match
---
arglist [15093,15118]
arglist [15112,15137]
===
match
---
operator: , [11201,11202]
operator: , [11220,11221]
===
match
---
name: len [4190,4193]
name: len [4190,4193]
===
match
---
string: 'levelname' [11053,11064]
string: 'levelname' [11072,11083]
===
match
---
name: logs [11465,11469]
name: logs [11484,11488]
===
match
---
trailer [5727,5741]
trailer [5746,5760]
===
match
---
comparison [13716,13755]
comparison [13735,13774]
===
match
---
name: logs [6910,6914]
name: logs [6929,6933]
===
match
---
name: shutil [820,826]
name: shutil [820,826]
===
match
---
operator: == [5146,5148]
operator: == [5165,5167]
===
match
---
atom_expr [6560,6582]
atom_expr [6579,6601]
===
match
---
name: self [2732,2736]
name: self [2732,2736]
===
match
---
name: self [15628,15632]
name: self [15647,15651]
===
match
---
trailer [13577,13683]
trailer [13596,13702]
===
match
---
trailer [3155,3162]
trailer [3155,3162]
===
match
---
name: index [4875,4880]
name: index [4875,4880]
===
match
---
trailer [12681,12697]
trailer [12700,12716]
===
match
---
trailer [3326,3340]
trailer [3326,3340]
===
match
---
trailer [13462,13471]
trailer [13481,13490]
===
match
---
expr_stmt [10656,10698]
expr_stmt [10675,10717]
===
match
---
operator: == [4284,4286]
operator: == [4284,4286]
===
match
---
atom_expr [6881,6890]
atom_expr [6900,6909]
===
match
---
operator: } [8301,8302]
operator: } [8320,8321]
===
match
---
simple_stmt [2872,2929]
simple_stmt [2872,2929]
===
match
---
parameters [6757,6763]
parameters [6776,6782]
===
match
---
name: self [2264,2268]
name: self [2264,2268]
===
match
---
name: self [10656,10660]
name: self [10675,10679]
===
match
---
testlist_comp [15435,15477]
testlist_comp [15454,15496]
===
match
---
assert_stmt [6500,6537]
assert_stmt [6519,6556]
===
match
---
trailer [7016,7030]
trailer [7035,7049]
===
match
---
trailer [15333,15341]
trailer [15352,15360]
===
match
---
name: self [2123,2127]
name: self [2123,2127]
===
match
---
name: index [4869,4874]
name: index [4869,4874]
===
match
---
trailer [8117,8128]
trailer [8136,8147]
===
match
---
simple_stmt [13480,13523]
simple_stmt [13499,13542]
===
match
---
trailer [10282,10298]
trailer [10301,10317]
===
match
---
name: formatter [10311,10320]
name: formatter [10330,10339]
===
match
---
string: 'https://localhost:5601/' [15293,15318]
string: 'https://localhost:5601/' [15312,15337]
===
match
---
dotted_name [1068,1091]
dotted_name [1068,1091]
===
match
---
operator: == [7573,7575]
operator: == [7592,7594]
===
match
---
dotted_name [1280,1302]
dotted_name [1280,1302]
===
match
---
string: 'offset' [5777,5785]
string: 'offset' [5796,5804]
===
match
---
atom_expr [10837,10848]
atom_expr [10856,10867]
===
match
---
atom_expr [8951,8960]
atom_expr [8970,8979]
===
match
---
trailer [5595,5601]
trailer [5614,5620]
===
match
---
trailer [2164,2182]
trailer [2164,2182]
===
match
---
expr_stmt [1958,1982]
expr_stmt [1958,1982]
===
match
---
operator: = [11848,11849]
operator: = [11867,11868]
===
match
---
simple_stmt [13032,13074]
simple_stmt [13051,13093]
===
match
---
atom_expr [9903,9929]
atom_expr [9922,9948]
===
match
---
fstring_string: - [1578,1579]
fstring_string: - [1578,1579]
===
match
---
assert_stmt [8914,8935]
assert_stmt [8933,8954]
===
match
---
operator: = [3060,3061]
operator: = [3060,3061]
===
match
---
name: ts [4461,4463]
name: ts [4461,4463]
===
match
---
comparison [4233,4250]
comparison [4233,4250]
===
match
---
trailer [8756,8905]
trailer [8775,8924]
===
match
---
comparison [9169,9198]
comparison [9188,9217]
===
match
---
operator: - [5692,5693]
operator: - [5711,5712]
===
match
---
name: try_number [3023,3033]
name: try_number [3023,3033]
===
match
---
trailer [13203,13222]
trailer [13222,13241]
===
match
---
simple_stmt [2937,3007]
simple_stmt [2937,3007]
===
match
---
name: DAG_ID [4644,4650]
name: DAG_ID [4644,4650]
===
match
---
simple_stmt [12363,12392]
simple_stmt [12382,12411]
===
match
---
decorator [15194,15496]
decorator [15213,15515]
===
match
---
operator: , [14615,14616]
operator: , [14634,14635]
===
match
---
name: TestElasticsearchTaskHandler [4660,4688]
name: TestElasticsearchTaskHandler [4660,4688]
===
match
---
operator: , [8777,8778]
operator: , [8796,8797]
===
match
---
name: len [12960,12963]
name: len [12979,12982]
===
match
---
name: log_file [14119,14127]
name: log_file [14138,14146]
===
match
---
number: 1 [6406,6407]
number: 1 [6425,6426]
===
match
---
trailer [9582,9598]
trailer [9601,9617]
===
match
---
name: metadatas [9124,9133]
name: metadatas [9143,9152]
===
match
---
expr_stmt [1559,1617]
expr_stmt [1559,1617]
===
match
---
atom_expr [11092,11133]
atom_expr [11111,11152]
===
match
---
parameters [3374,3380]
parameters [3374,3380]
===
match
---
name: mock [9409,9413]
name: mock [9428,9432]
===
match
---
trailer [7013,7016]
trailer [7032,7035]
===
match
---
atom_expr [2758,2771]
atom_expr [2758,2771]
===
match
---
name: es_conf [3390,3397]
name: es_conf [3390,3397]
===
match
---
operator: == [6878,6880]
operator: == [6897,6899]
===
match
---
param [10169,10173]
param [10188,10192]
===
match
---
name: test_read_with_none_metadata [5472,5500]
name: test_read_with_none_metadata [5491,5519]
===
match
---
trailer [9338,9354]
trailer [9357,9373]
===
match
---
funcdef [10473,11479]
funcdef [10492,11498]
===
match
---
arglist [4875,4945]
arglist [4875,4945]
===
match
---
name: set_context [10447,10458]
name: set_context [10466,10477]
===
match
---
operator: == [8628,8630]
operator: == [8647,8649]
===
match
---
fstring_string: - [10849,10850]
fstring_string: - [10868,10869]
===
match
---
argument [11203,11217]
argument [11222,11236]
===
match
---
operator: = [6817,6818]
operator: = [6836,6837]
===
match
---
operator: } [1587,1588]
operator: } [1587,1588]
===
match
---
operator: , [4003,4004]
operator: , [4003,4004]
===
match
---
string: 'end_of_log' [9916,9928]
string: 'end_of_log' [9935,9947]
===
match
---
trailer [3984,3988]
trailer [3984,3988]
===
match
---
trailer [12837,12842]
trailer [12856,12861]
===
match
---
string: '0' [8532,8535]
string: '0' [8551,8554]
===
match
---
number: 1 [13670,13671]
number: 1 [13689,13690]
===
match
---
name: self [8028,8032]
name: self [8047,8051]
===
match
---
name: getsection [3410,3420]
name: getsection [3410,3420]
===
match
---
name: local_log_location [13204,13222]
name: local_log_location [13223,13241]
===
match
---
operator: , [15114,15115]
operator: , [15133,15134]
===
match
---
assert_stmt [6993,7030]
assert_stmt [7012,7049]
===
match
---
string: 'end_of_log' [5333,5345]
string: 'end_of_log' [5352,5364]
===
match
---
operator: = [9691,9692]
operator: = [9710,9711]
===
match
---
trailer [12872,12890]
trailer [12891,12909]
===
match
---
simple_stmt [13304,13337]
simple_stmt [13323,13356]
===
match
---
name: filename_template [1749,1766]
name: filename_template [1749,1766]
===
match
---
name: timezone [8577,8585]
name: timezone [8596,8604]
===
match
---
name: read [11266,11270]
name: read [11285,11289]
===
match
---
param [11499,11503]
param [11518,11522]
===
match
---
trailer [2109,2352]
trailer [2109,2352]
===
match
---
atom_expr [4190,4199]
atom_expr [4190,4199]
===
match
---
simple_stmt [843,869]
simple_stmt [843,869]
===
match
---
atom_expr [15943,15950]
atom_expr [15962,15969]
===
match
---
name: self [4907,4911]
name: self [4907,4911]
===
match
---
expr_stmt [14531,14861]
expr_stmt [14550,14880]
===
match
---
name: test_message [2653,2665]
name: test_message [2653,2665]
===
match
---
string: 'offset' [4840,4848]
string: 'offset' [4840,4848]
===
match
---
assert_stmt [4401,4463]
assert_stmt [4401,4463]
===
match
---
simple_stmt [3266,3342]
simple_stmt [3266,3342]
===
match
---
name: self [8225,8229]
name: self [8244,8248]
===
match
---
name: ti [11130,11132]
name: ti [11149,11151]
===
match
---
trailer [3404,3446]
trailer [3404,3446]
===
match
---
name: pendulum [8690,8698]
name: pendulum [8709,8717]
===
match
---
simple_stmt [12948,12981]
simple_stmt [12967,13000]
===
match
---
trailer [13598,13603]
trailer [13617,13622]
===
match
---
name: filename_template [14634,14651]
name: filename_template [14653,14670]
===
match
---
string: 'last_log_timestamp' [5435,5455]
string: 'last_log_timestamp' [5454,5474]
===
match
---
operator: , [15950,15951]
operator: , [15969,15970]
===
match
---
trailer [13956,14062]
trailer [13975,14081]
===
match
---
operator: } [8893,8894]
operator: } [8912,8913]
===
match
---
trailer [12790,12796]
trailer [12809,12815]
===
match
---
funcdef [12986,13380]
funcdef [13005,13399]
===
match
---
trailer [3862,3874]
trailer [3862,3874]
===
match
---
name: len [5187,5190]
name: len [5206,5209]
===
match
---
number: 1 [8234,8235]
number: 1 [8253,8254]
===
match
---
with_item [9316,9390]
with_item [9335,9409]
===
match
---
simple_stmt [1924,1950]
simple_stmt [1924,1950]
===
match
---
trailer [1693,1712]
trailer [1693,1712]
===
match
---
name: ti [8775,8777]
name: ti [8794,8796]
===
match
---
operator: , [8818,8819]
operator: , [8837,8838]
===
match
---
number: 8 [15102,15103]
number: 8 [15121,15122]
===
match
---
trailer [9320,9326]
trailer [9339,9345]
===
match
---
operator: , [15345,15346]
operator: , [15364,15365]
===
match
---
name: log_file [14066,14074]
name: log_file [14085,14093]
===
match
---
number: 0 [6326,6327]
number: 0 [6345,6346]
===
match
---
trailer [6670,6676]
trailer [6689,6695]
===
match
---
name: Formatter [10567,10576]
name: Formatter [10586,10595]
===
match
---
name: patch [9414,9419]
name: patch [9433,9438]
===
match
---
name: metadatas [6511,6520]
name: metadatas [6530,6539]
===
match
---
trailer [11124,11133]
trailer [11143,11152]
===
match
---
name: airflow [984,991]
name: airflow [984,991]
===
match
---
name: es_task_handler [12368,12383]
name: es_task_handler [12387,12402]
===
match
---
argument [8072,8081]
argument [8091,8100]
===
match
---
operator: , [9358,9359]
operator: , [9377,9378]
===
match
---
name: clear [3109,3114]
name: clear [3109,3114]
===
match
---
name: ti [7526,7528]
name: ti [7545,7547]
===
match
---
atom_expr [4961,4975]
atom_expr [4961,4975]
===
match
---
name: ti [15948,15950]
name: ti [15967,15969]
===
match
---
operator: == [5589,5591]
operator: == [5608,5610]
===
match
---
number: 1 [11476,11477]
number: 1 [11495,11496]
===
match
---
atom_expr [7676,7702]
atom_expr [7695,7721]
===
match
---
testlist_comp [15266,15352]
testlist_comp [15285,15371]
===
match
---
trailer [4416,4422]
trailer [4416,4422]
===
match
---
expr_stmt [1878,1915]
expr_stmt [1878,1915]
===
match
---
operator: = [1767,1768]
operator: = [1767,1768]
===
match
---
name: test_message [2581,2593]
name: test_message [2581,2593]
===
match
---
expr_stmt [12286,12304]
expr_stmt [12305,12323]
===
match
---
trailer [12589,12591]
trailer [12608,12610]
===
match
---
name: logs [5178,5182]
name: logs [5197,5201]
===
match
---
simple_stmt [13082,13118]
simple_stmt [13101,13137]
===
match
---
argument [8154,8158]
argument [8173,8177]
===
match
---
simple_stmt [1275,1319]
simple_stmt [1275,1319]
===
match
---
name: test_set_context_w_json_format_and_write_stdout [10121,10168]
name: test_set_context_w_json_format_and_write_stdout [10140,10187]
===
match
---
atom_expr [9409,9455]
atom_expr [9428,9474]
===
match
---
number: 1 [6982,6983]
number: 1 [7001,7002]
===
match
---
trailer [15083,15120]
trailer [15102,15139]
===
match
---
name: LOG_ID [2682,2688]
name: LOG_ID [2682,2688]
===
match
---
name: ts [4956,4958]
name: ts [4956,4958]
===
match
---
comparison [5587,5601]
comparison [5606,5620]
===
match
---
name: local_log_location [12848,12866]
name: local_log_location [12867,12885]
===
match
---
number: 0 [5774,5775]
number: 0 [5793,5794]
===
match
---
simple_stmt [4522,4707]
simple_stmt [4522,4707]
===
match
---
atom_expr [15952,15970]
atom_expr [15971,15989]
===
match
---
trailer [11533,11543]
trailer [11552,11562]
===
match
---
trailer [4973,4975]
trailer [4973,4975]
===
match
---
trailer [10430,10446]
trailer [10449,10465]
===
match
---
trailer [8954,8960]
trailer [8973,8979]
===
match
---
name: ts [5093,5095]
name: ts [5095,5097]
===
match
---
atom_expr [7614,7628]
atom_expr [7633,7647]
===
match
---
operator: { [10768,10769]
operator: { [10787,10788]
===
match
---
operator: { [2636,2637]
operator: { [2636,2637]
===
match
---
name: pendulum [5925,5933]
name: pendulum [5944,5952]
===
match
---
arglist [7521,7554]
arglist [7540,7573]
===
match
---
name: metadatas [8174,8183]
name: metadatas [8193,8202]
===
match
---
name: self [14206,14210]
name: self [14225,14229]
===
match
---
assert_stmt [9864,9883]
assert_stmt [9883,9902]
===
match
---
trailer [6676,6712]
trailer [6695,6731]
===
match
---
atom [8401,8405]
atom [8420,8424]
===
match
---
trailer [5022,5027]
trailer [5022,5027]
===
match
---
string: 'end_of_log' [6524,6536]
string: 'end_of_log' [6543,6555]
===
match
---
name: metadatas [9176,9185]
name: metadatas [9195,9204]
===
match
---
simple_stmt [4984,5129]
simple_stmt [4984,5148]
===
match
---
assert_stmt [15980,16006]
assert_stmt [15999,16025]
===
match
---
operator: = [7447,7448]
operator: = [7466,7467]
===
match
---
name: timezone [5407,5415]
name: timezone [5426,5434]
===
match
---
operator: = [10411,10412]
operator: = [10430,10431]
===
match
---
name: log [9355,9358]
name: log [9374,9377]
===
match
---
string: 'local/log/location' [1715,1735]
string: 'local/log/location' [1715,1735]
===
match
---
atom_expr [1796,1816]
atom_expr [1796,1816]
===
match
---
atom_expr [4056,4063]
atom_expr [4056,4063]
===
match
---
atom_expr [6970,6984]
atom_expr [6989,7003]
===
match
---
trailer [12383,12389]
trailer [12402,12408]
===
match
---
trailer [3288,3304]
trailer [3288,3304]
===
match
---
name: self [15943,15947]
name: self [15962,15966]
===
match
---
trailer [12757,12760]
trailer [12776,12779]
===
match
---
trailer [4587,4594]
trailer [4587,4594]
===
match
---
import_name [922,937]
import_name [922,937]
===
match
---
argument [2960,2969]
argument [2960,2969]
===
match
---
funcdef [11484,12239]
funcdef [11503,12258]
===
match
---
operator: != [5289,5291]
operator: != [5308,5310]
===
match
---
atom_expr [15327,15351]
atom_expr [15346,15370]
===
match
---
trailer [2234,2250]
trailer [2234,2250]
===
match
---
name: filename_template [15670,15687]
name: filename_template [15689,15706]
===
match
---
operator: , [7437,7438]
operator: , [7456,7457]
===
match
---
name: self [1958,1962]
name: self [1958,1962]
===
match
---
comparison [4160,4174]
comparison [4160,4174]
===
match
---
number: 0 [5725,5726]
number: 0 [5744,5745]
===
match
---
argument [2971,3005]
argument [2971,3005]
===
match
---
simple_stmt [3149,3230]
simple_stmt [3149,3230]
===
match
---
name: self [9578,9582]
name: self [9597,9601]
===
match
---
atom_expr [6511,6537]
atom_expr [6530,6556]
===
match
---
comparison [9635,9665]
comparison [9654,9684]
===
match
---
name: ts [8846,8848]
name: ts [8865,8867]
===
match
---
name: elasticmock [1624,1635]
name: elasticmock [1624,1635]
===
match
---
file_input [788,16007]
file_input [788,16026]
===
match
---
trailer [7405,7408]
trailer [7424,7427]
===
match
---
trailer [4594,4706]
trailer [4594,4706]
===
match
---
name: len [7614,7617]
name: len [7633,7636]
===
match
---
trailer [10036,10048]
trailer [10055,10067]
===
match
---
operator: == [6967,6969]
operator: == [6986,6988]
===
match
---
trailer [10458,10467]
trailer [10477,10486]
===
match
---
suite [4513,5463]
suite [4513,5482]
===
match
---
comparison [4266,4301]
comparison [4266,4301]
===
match
---
operator: , [5096,5097]
operator: , [5098,5099]
===
match
---
trailer [4042,4143]
trailer [4042,4143]
===
match
---
name: read [5023,5027]
name: read [5023,5027]
===
match
---
name: self [2576,2580]
name: self [2576,2580]
===
match
---
string: 'last_log_timestamp' [9242,9262]
string: 'last_log_timestamp' [9261,9281]
===
match
---
atom_expr [8577,8627]
atom_expr [8596,8646]
===
match
---
name: execution_date [2971,2985]
name: execution_date [2971,2985]
===
match
---
atom_expr [5174,5183]
atom_expr [5193,5202]
===
match
---
trailer [10760,10765]
trailer [10779,10784]
===
match
---
name: test_read_with_json_format [10477,10503]
name: test_read_with_json_format [10496,10522]
===
match
---
name: doc_type [8144,8152]
name: doc_type [8163,8171]
===
match
---
operator: , [2341,2342]
operator: , [2341,2342]
===
match
---
operator: , [2688,2689]
operator: , [2688,2689]
===
match
---
string: 'filename' [10983,10993]
string: 'filename' [11002,11012]
===
match
---
trailer [6884,6890]
trailer [6903,6909]
===
match
---
name: self [8139,8143]
name: self [8158,8162]
===
match
---
atom_expr [7960,7994]
atom_expr [7979,8013]
===
match
---
string: 'log' [2562,2567]
string: 'log' [2562,2567]
===
match
---
arglist [13199,13267]
arglist [13218,13286]
===
match
---
simple_stmt [5920,5940]
simple_stmt [5939,5959]
===
match
---
operator: , [4812,4813]
operator: , [4812,4813]
===
match
---
string: 'last_log_timestamp' [7301,7321]
string: 'last_log_timestamp' [7320,7340]
===
match
---
testlist_star_expr [8168,8183]
testlist_star_expr [8187,8202]
===
match
---
atom_expr [15628,15651]
atom_expr [15647,15670]
===
match
---
name: expected_log_id [14942,14957]
name: expected_log_id [14961,14976]
===
match
---
string: '1' [7107,7110]
string: '1' [7126,7129]
===
match
---
string: 'last_log_timestamp' [5067,5087]
string: 'last_log_timestamp' [5069,5089]
===
match
---
number: 1 [5250,5251]
number: 1 [5269,5270]
===
match
---
simple_stmt [7401,7469]
simple_stmt [7420,7488]
===
match
---
trailer [9831,9837]
trailer [9850,9856]
===
match
---
operator: == [12957,12959]
operator: == [12976,12978]
===
match
---
name: ts [8043,8045]
name: ts [8062,8064]
===
match
---
operator: = [10522,10523]
operator: = [10541,10542]
===
match
---
operator: , [10969,10970]
operator: , [10988,10989]
===
match
---
atom_expr [11332,11339]
atom_expr [11351,11358]
===
match
---
operator: , [8152,8153]
operator: , [8171,8172]
===
match
---
trailer [2127,2146]
trailer [2127,2146]
===
match
---
trailer [12816,12922]
trailer [12835,12941]
===
match
---
arglist [11156,11224]
arglist [11175,11243]
===
match
---
name: try_number [15960,15970]
name: try_number [15979,15989]
===
match
---
atom_expr [2372,2498]
atom_expr [2372,2498]
===
match
---
arglist [8770,8895]
arglist [8789,8914]
===
match
---
atom_expr [6778,6792]
atom_expr [6797,6811]
===
match
---
operator: { [8237,8238]
operator: { [8256,8257]
===
match
---
operator: = [14877,14878]
operator: = [14896,14897]
===
match
---
argument [4875,4896]
argument [4875,4896]
===
match
---
name: metadatas [4321,4330]
name: metadatas [4321,4330]
===
match
---
comparison [4408,4463]
comparison [4408,4463]
===
match
---
name: open [11752,11756]
name: open [11771,11775]
===
match
---
string: 'end_of_log' [8442,8454]
string: 'end_of_log' [8461,8473]
===
match
---
trailer [3108,3114]
trailer [3108,3114]
===
match
---
trailer [3727,3745]
trailer [3727,3745]
===
match
---
name: len [4203,4206]
name: len [4203,4206]
===
match
---
name: ti [10054,10056]
name: ti [10073,10075]
===
match
---
fstring_start: f' [1568,1570]
fstring_start: f' [1568,1570]
===
match
---
trailer [9608,9611]
trailer [9627,9630]
===
match
---
operator: = [6262,6263]
operator: = [6281,6282]
===
match
---
comparison [3562,3586]
comparison [3562,3586]
===
match
---
operator: = [2731,2732]
operator: = [2731,2732]
===
match
---
atom_expr [11465,11478]
atom_expr [11484,11497]
===
match
---
name: ti [13070,13072]
name: ti [13089,13091]
===
match
---
name: self [12211,12215]
name: self [12230,12234]
===
match
---
trailer [9326,9333]
trailer [9345,9352]
===
match
---
operator: = [3974,3975]
operator: = [3974,3975]
===
match
---
string: ' ' [15347,15350]
string: ' ' [15366,15369]
===
match
---
trailer [15045,15061]
trailer [15064,15080]
===
match
---
trailer [4868,4874]
trailer [4868,4874]
===
match
---
argument [2445,2488]
argument [2445,2488]
===
match
---
number: 1 [5569,5570]
number: 1 [5588,5589]
===
match
---
trailer [2385,2399]
trailer [2385,2399]
===
match
---
trailer [11772,11777]
trailer [11791,11796]
===
match
---
operator: , [5048,5049]
operator: , [5048,5049]
===
match
---
name: es_task_handler [11665,11680]
name: es_task_handler [11684,11699]
===
match
---
number: 1 [6235,6236]
number: 1 [6254,6255]
===
match
---
atom_expr [8770,8777]
atom_expr [8789,8796]
===
match
---
number: 1 [10918,10919]
number: 1 [10937,10938]
===
match
---
trailer [13977,13982]
trailer [13996,14001]
===
match
---
expr_stmt [4956,4975]
expr_stmt [4956,4975]
===
match
---
atom_expr [2085,2352]
atom_expr [2085,2352]
===
match
---
atom_expr [9803,9812]
atom_expr [9822,9831]
===
match
---
trailer [8190,8206]
trailer [8209,8225]
===
match
---
assert_stmt [8987,9011]
assert_stmt [9006,9030]
===
match
---
name: path [13594,13598]
name: path [13613,13617]
===
match
---
name: test_close_no_mark_end [12248,12270]
name: test_close_no_mark_end [12267,12289]
===
match
---
name: Elasticsearch [3327,3340]
name: Elasticsearch [3327,3340]
===
match
---
name: metadatas [5715,5724]
name: metadatas [5734,5743]
===
match
---
atom_expr [2843,2862]
atom_expr [2843,2862]
===
match
---
simple_stmt [10426,10468]
simple_stmt [10445,10487]
===
match
---
operator: , [12459,12460]
operator: , [12478,12479]
===
match
---
with_item [12812,12934]
with_item [12831,12953]
===
match
---
name: es_task_handler [11097,11112]
name: es_task_handler [11116,11131]
===
match
---
operator: == [7111,7113]
operator: == [7130,7132]
===
match
---
name: kwargs [9684,9690]
name: kwargs [9703,9709]
===
match
---
atom [15434,15478]
atom [15453,15497]
===
match
---
trailer [13893,13899]
trailer [13912,13918]
===
match
---
atom_expr [8333,8342]
atom_expr [8352,8361]
===
match
---
name: self [13910,13914]
name: self [13929,13933]
===
match
---
suite [11875,12196]
suite [11894,12215]
===
match
---
trailer [11192,11201]
trailer [11211,11220]
===
match
---
operator: == [6484,6486]
operator: == [6503,6505]
===
match
---
name: index_name [8118,8128]
name: index_name [8137,8147]
===
match
---
trailer [11475,11478]
trailer [11494,11497]
===
match
---
trailer [2299,2311]
trailer [2299,2311]
===
match
---
parameters [12270,12276]
parameters [12289,12295]
===
match
---
import_from [1018,1062]
import_from [1018,1062]
===
match
---
atom_expr [11284,11291]
atom_expr [11303,11310]
===
match
---
atom_expr [3046,3059]
atom_expr [3046,3059]
===
match
---
not_test [4317,4347]
not_test [4317,4347]
===
match
---
name: json_fields [3893,3904]
name: json_fields [3893,3904]
===
match
---
trailer [9915,9929]
trailer [9934,9948]
===
match
---
suite [10007,10112]
suite [10026,10131]
===
match
---
name: es_frontend [15869,15880]
name: es_frontend [15888,15899]
===
match
---
name: hosts [2445,2450]
name: hosts [2445,2450]
===
match
---
assert_stmt [3555,3586]
assert_stmt [3555,3586]
===
match
---
simple_stmt [13345,13380]
simple_stmt [13364,13399]
===
match
---
string: 'last_log_timestamp' [6690,6710]
string: 'last_log_timestamp' [6709,6729]
===
match
---
atom [7644,7648]
atom [7663,7667]
===
match
---
trailer [11628,11638]
trailer [11647,11657]
===
match
---
name: json_format [1963,1974]
name: json_format [1963,1974]
===
match
---
trailer [10053,10056]
trailer [10072,10075]
===
match
---
name: EXECUTION_DATE [2991,3005]
name: EXECUTION_DATE [2991,3005]
===
match
---
name: tearDown [3125,3133]
name: tearDown [3125,3133]
===
match
---
argument [2773,2787]
argument [2773,2787]
===
match
---
comparison [6436,6463]
comparison [6455,6482]
===
match
---
atom_expr [1958,1974]
atom_expr [1958,1974]
===
match
---
trailer [3283,3341]
trailer [3283,3341]
===
match
---
trailer [9188,9198]
trailer [9207,9217]
===
match
---
name: EXECUTION_DATE [2848,2862]
name: EXECUTION_DATE [2848,2862]
===
match
---
assert_stmt [12148,12195]
assert_stmt [12167,12214]
===
match
---
operator: = [15868,15869]
operator: = [15887,15888]
===
match
---
simple_stmt [3555,3587]
simple_stmt [3555,3587]
===
match
---
expr_stmt [15900,15971]
expr_stmt [15919,15990]
===
match
---
atom_expr [2901,2913]
atom_expr [2901,2913]
===
match
---
name: mock_exception [9376,9390]
name: mock_exception [9395,9409]
===
match
---
number: 1 [4299,4300]
number: 1 [4299,4300]
===
match
---
atom_expr [7114,7136]
atom_expr [7133,7155]
===
match
---
operator: = [12705,12706]
operator: = [12724,12725]
===
match
---
comparison [5144,5158]
comparison [5163,5177]
===
match
---
argument [2749,2771]
argument [2749,2771]
===
match
---
atom_expr [11693,11700]
atom_expr [11712,11719]
===
match
---
name: self [5217,5221]
name: self [5236,5240]
===
match
---
atom_expr [6436,6445]
atom_expr [6455,6464]
===
match
---
trailer [4060,4063]
trailer [4060,4063]
===
match
---
name: index [2726,2731]
name: index [2726,2731]
===
match
---
operator: , [3208,3209]
operator: , [3208,3209]
===
match
---
dictorsetmaker [2637,2701]
dictorsetmaker [2637,2701]
===
match
---
arglist [7416,7467]
arglist [7435,7486]
===
match
---
name: join [12838,12842]
name: join [12857,12861]
===
match
---
name: mock [9316,9320]
name: mock [9335,9339]
===
match
---
string: 'offset' [2690,2698]
string: 'offset' [2690,2698]
===
match
---
name: object [9327,9333]
name: object [9346,9352]
===
match
---
operator: , [2216,2217]
operator: , [2216,2217]
===
match
---
atom_expr [13952,14062]
atom_expr [13971,14081]
===
match
---
trailer [3053,3059]
trailer [3053,3059]
===
match
---
name: join [13978,13982]
name: join [13997,14001]
===
match
---
string: 'offset' [10908,10916]
string: 'offset' [10927,10935]
===
match
---
name: self [3134,3138]
name: self [3134,3138]
===
match
---
trailer [13812,13828]
trailer [13831,13847]
===
match
---
trailer [12697,12704]
trailer [12716,12723]
===
match
---
operator: , [2281,2282]
operator: , [2281,2282]
===
match
---
name: join [13194,13198]
name: join [13213,13217]
===
match
---
with_stmt [13947,14135]
with_stmt [13966,14154]
===
match
---
simple_stmt [14531,14862]
simple_stmt [14550,14881]
===
match
---
number: 1 [8791,8792]
number: 1 [8810,8811]
===
match
---
trailer [8060,8062]
trailer [8079,8081]
===
match
---
trailer [8336,8342]
trailer [8355,8361]
===
match
---
name: metadatas [7960,7969]
name: metadatas [7979,7988]
===
match
---
name: LOG_ID [15327,15333]
name: LOG_ID [15346,15352]
===
match
---
simple_stmt [1467,1513]
simple_stmt [1467,1513]
===
match
---
name: test_message [5665,5677]
name: test_message [5684,5696]
===
match
---
trailer [2652,2665]
trailer [2652,2665]
===
match
---
number: 1 [14438,14439]
number: 1 [14457,14458]
===
match
---
number: 0 [8439,8440]
number: 0 [8458,8459]
===
match
---
name: ti [5046,5048]
name: ti [5046,5048]
===
match
---
simple_stmt [15572,15892]
simple_stmt [15591,15911]
===
match
---
argument [7416,7437]
argument [7435,7456]
===
match
---
trailer [2990,3005]
trailer [2990,3005]
===
match
---
name: self [13716,13720]
name: self [13735,13739]
===
match
---
name: formatter [11514,11523]
name: formatter [11533,11542]
===
match
---
atom_expr [9952,9974]
atom_expr [9971,9993]
===
match
---
operator: = [6190,6191]
operator: = [6209,6210]
===
match
---
trailer [11680,11692]
trailer [11699,11711]
===
match
---
simple_stmt [11142,11226]
simple_stmt [11161,11245]
===
match
---
trailer [11756,11862]
trailer [11775,11881]
===
match
---
expr_stmt [10184,10269]
expr_stmt [10203,10288]
===
match
---
trailer [4206,4217]
trailer [4206,4217]
===
match
---
trailer [4330,4333]
trailer [4330,4333]
===
match
---
operator: { [1570,1571]
operator: { [1570,1571]
===
match
---
trailer [14914,14926]
trailer [14933,14945]
===
match
---
atom_expr [7576,7585]
atom_expr [7595,7604]
===
match
---
trailer [5027,5128]
trailer [5027,5147]
===
match
---
assert_stmt [9207,9269]
assert_stmt [9226,9288]
===
match
---
assert_stmt [9892,9929]
assert_stmt [9911,9948]
===
match
---
fstring_end: ' [1616,1617]
fstring_end: ' [1616,1617]
===
match
---
name: self [10837,10841]
name: self [10856,10860]
===
match
---
name: self [2819,2823]
name: self [2819,2823]
===
match
---
trailer [8206,8211]
trailer [8225,8230]
===
match
---
assert_stmt [4183,4217]
assert_stmt [4183,4217]
===
match
---
name: len [5617,5620]
name: len [5636,5639]
===
match
---
simple_stmt [6246,6391]
simple_stmt [6265,6410]
===
match
---
operator: , [8792,8793]
operator: , [8811,8812]
===
match
---
atom_expr [12155,12183]
atom_expr [12174,12202]
===
match
---
name: mock_exception [9635,9649]
name: mock_exception [9654,9668]
===
match
---
operator: } [3545,3546]
operator: } [3545,3546]
===
match
---
name: index_name [4886,4896]
name: index_name [4886,4896]
===
match
---
operator: = [8729,8730]
operator: = [8748,8749]
===
match
---
assert_stmt [13345,13379]
assert_stmt [13364,13398]
===
match
---
name: stream [13887,13893]
name: stream [13906,13912]
===
match
---
operator: , [1048,1049]
operator: , [1048,1049]
===
match
---
string: 'Failed to read' [9526,9542]
string: 'Failed to read' [9545,9561]
===
match
---
simple_stmt [14221,14376]
simple_stmt [14240,14395]
===
match
---
name: test_client_with_config [3351,3374]
name: test_client_with_config [3351,3374]
===
match
---
expr_stmt [3455,3546]
expr_stmt [3455,3546]
===
match
---
operator: == [11462,11464]
operator: == [11481,11483]
===
match
---
operator: == [8536,8538]
operator: == [8555,8557]
===
match
---
trailer [12796,12798]
trailer [12815,12817]
===
match
---
simple_stmt [1878,1916]
simple_stmt [1878,1916]
===
match
---
argument [7463,7467]
argument [7482,7486]
===
match
---
trailer [11730,11736]
trailer [11749,11755]
===
match
---
atom_expr [6662,6712]
atom_expr [6681,6731]
===
match
---
name: local_log_location [1694,1712]
name: local_log_location [1694,1712]
===
match
---
name: expected_log_id [14221,14236]
name: expected_log_id [14240,14255]
===
match
---
trailer [7604,7610]
trailer [7623,7629]
===
match
---
trailer [15669,15687]
trailer [15688,15706]
===
match
---
name: ti [4061,4063]
name: ti [4061,4063]
===
match
---
argument [13254,13266]
argument [13273,13285]
===
match
---
trailer [12890,12897]
trailer [12909,12916]
===
match
---
name: metadatas [7114,7123]
name: metadatas [7133,7142]
===
match
---
simple_stmt [7938,8001]
simple_stmt [7957,8020]
===
match
---
name: url [16003,16006]
name: url [16022,16025]
===
match
---
trailer [3797,3813]
trailer [3797,3813]
===
match
---
number: 1 [14924,14925]
number: 1 [14943,14944]
===
match
---
trailer [2550,2559]
trailer [2550,2559]
===
match
---
operator: == [7649,7651]
operator: == [7668,7670]
===
match
---
operator: , [1550,1551]
operator: , [1550,1551]
===
match
---
atom [2451,2488]
atom [2451,2488]
===
match
---
name: len [6919,6922]
name: len [6938,6941]
===
match
---
simple_stmt [8321,8343]
simple_stmt [8340,8362]
===
match
---
name: logs [8713,8717]
name: logs [8732,8736]
===
match
---
atom_expr [10049,10056]
atom_expr [10068,10075]
===
match
---
name: set_context [11681,11692]
name: set_context [11700,11711]
===
match
---
atom_expr [7448,7461]
atom_expr [7467,7480]
===
match
---
simple_stmt [14088,14135]
simple_stmt [14107,14154]
===
match
---
operator: = [9514,9515]
operator: = [9533,9534]
===
match
---
name: metadatas [5320,5329]
name: metadatas [5339,5348]
===
match
---
atom_expr [8139,8152]
atom_expr [8158,8171]
===
match
---
name: ts [8631,8633]
name: ts [8650,8652]
===
match
---
name: mock_exception [9693,9707]
name: mock_exception [9712,9726]
===
match
---
assert_stmt [7637,7656]
assert_stmt [7656,7675]
===
match
---
atom_expr [6351,6358]
atom_expr [6370,6377]
===
match
---
simple_stmt [11514,11600]
simple_stmt [11533,11619]
===
match
---
simple_stmt [9162,9199]
simple_stmt [9181,9218]
===
match
---
assert_stmt [9162,9198]
assert_stmt [9181,9217]
===
match
---
atom_expr [5320,5346]
atom_expr [5339,5365]
===
match
---
dictorsetmaker [3485,3536]
dictorsetmaker [3485,3536]
===
match
---
trailer [13152,13154]
trailer [13171,13173]
===
match
---
atom_expr [2778,2787]
atom_expr [2778,2787]
===
match
---
name: logs [9560,9564]
name: logs [9579,9583]
===
match
---
expr_stmt [1744,1787]
expr_stmt [1744,1787]
===
match
---
name: metadatas [7483,7492]
name: metadatas [7502,7511]
===
match
---
trailer [8735,8751]
trailer [8754,8770]
===
match
---
name: formatter [10184,10193]
name: formatter [10203,10212]
===
match
---
simple_stmt [10378,10418]
simple_stmt [10397,10437]
===
match
---
comparison [7571,7585]
comparison [7590,7604]
===
match
---
operator: = [14237,14238]
operator: = [14256,14257]
===
match
---
name: ts [8277,8279]
name: ts [8296,8298]
===
match
---
import_from [1113,1201]
import_from [1113,1201]
===
match
---
simple_stmt [4401,4464]
simple_stmt [4401,4464]
===
match
---
name: self [13032,13036]
name: self [13051,13055]
===
match
---
name: self [12662,12666]
name: self [12681,12685]
===
match
---
operator: = [1532,1533]
operator: = [1532,1533]
===
match
---
expr_stmt [8713,8905]
expr_stmt [8732,8924]
===
match
---
name: logs [6246,6250]
name: logs [6265,6269]
===
match
---
trailer [12333,12345]
trailer [12352,12364]
===
match
---
operator: = [5532,5533]
operator: = [5551,5552]
===
match
---
comparison [6662,6718]
comparison [6681,6737]
===
match
---
name: metadatas [9952,9961]
name: metadatas [9971,9980]
===
match
---
fstring [10834,10894]
fstring [10853,10913]
===
match
---
trailer [11787,11806]
trailer [11806,11825]
===
match
---
operator: , [2146,2147]
operator: , [2146,2147]
===
match
---
operator: , [5051,5052]
operator: , [5051,5052]
===
match
---
expr_stmt [2937,3006]
expr_stmt [2937,3006]
===
match
---
name: logs [8362,8366]
name: logs [8381,8385]
===
match
---
atom [3471,3546]
atom [3471,3546]
===
match
---
atom_expr [2295,2311]
atom_expr [2295,2311]
===
match
---
atom_expr [8113,8128]
atom_expr [8132,8147]
===
match
---
simple_stmt [5795,5870]
simple_stmt [5814,5889]
===
match
---
atom_expr [6449,6463]
atom_expr [6468,6482]
===
match
---
name: len [5630,5633]
name: len [5649,5652]
===
match
---
trailer [3167,3186]
trailer [3167,3186]
===
match
---
simple_stmt [3390,3447]
simple_stmt [3390,3447]
===
match
---
expr_stmt [6801,6860]
expr_stmt [6820,6879]
===
match
---
trailer [12440,12459]
trailer [12459,12478]
===
match
---
string: '%(asctime)s - %(name)s - %(levelname)s - %(message)s' [11544,11598]
string: '%(asctime)s - %(name)s - %(levelname)s - %(message)s' [11563,11617]
===
match
---
string: 'last_log_timestamp' [5830,5850]
string: 'last_log_timestamp' [5849,5869]
===
match
---
name: metadatas [4370,4379]
name: metadatas [4370,4379]
===
match
---
name: self [14429,14433]
name: self [14448,14452]
===
match
---
name: ElasticsearchTaskHandler [3648,3672]
name: ElasticsearchTaskHandler [3648,3672]
===
match
---
name: self [1991,1995]
name: self [1991,1995]
===
match
---
suite [3140,3230]
suite [3140,3230]
===
match
---
not_test [6507,6537]
not_test [6526,6556]
===
match
---
trailer [8601,8604]
trailer [8620,8623]
===
match
---
expr_stmt [6246,6390]
expr_stmt [6265,6409]
===
match
---
trailer [15804,15816]
trailer [15823,15835]
===
match
---
number: 1 [6876,6877]
number: 1 [6895,6896]
===
match
---
atom [7645,7647]
atom [7664,7666]
===
match
---
simple_stmt [2576,2616]
simple_stmt [2576,2616]
===
match
---
operator: , [8232,8233]
operator: , [8251,8252]
===
match
---
name: Elasticsearch [2386,2399]
name: Elasticsearch [2386,2399]
===
match
---
suite [3257,3342]
suite [3257,3342]
===
match
---
trailer [9419,9455]
trailer [9438,9474]
===
match
---
trailer [13246,13253]
trailer [13265,13272]
===
match
---
trailer [6980,6984]
trailer [6999,7003]
===
match
---
name: open [13952,13956]
name: open [13971,13975]
===
match
---
atom_expr [5407,5457]
atom_expr [5426,5476]
===
match
---
name: self [13415,13419]
name: self [13434,13438]
===
match
---
name: self [15701,15705]
name: self [15720,15724]
===
match
---
name: shutil [3149,3155]
name: shutil [3149,3155]
===
match
---
suite [15009,15189]
suite [15028,15208]
===
match
---
name: test_clean_execution_date [14977,15002]
name: test_clean_execution_date [14996,15021]
===
match
---
trailer [7617,7628]
trailer [7636,7647]
===
match
---
name: ts [3971,3973]
name: ts [3971,3973]
===
match
---
atom_expr [7401,7468]
atom_expr [7420,7487]
===
match
---
trailer [11777,11782]
trailer [11796,11801]
===
match
---
atom_expr [14095,14115]
atom_expr [14114,14134]
===
match
---
name: format [13652,13658]
name: format [13671,13677]
===
match
---
expr_stmt [11514,11599]
expr_stmt [11533,11618]
===
match
---
name: end_of_log_mark [14744,14759]
name: end_of_log_mark [14763,14778]
===
match
---
name: self [5534,5538]
name: self [5553,5557]
===
match
---
name: body [11213,11217]
name: body [11232,11236]
===
match
---
suite [8034,8634]
suite [8053,8653]
===
match
---
name: EXECUTION_DATE [1517,1531]
name: EXECUTION_DATE [1517,1531]
===
match
---
simple_stmt [8570,8634]
simple_stmt [8589,8653]
===
match
---
atom_expr [2362,2369]
atom_expr [2362,2369]
===
match
---
name: es_task_handler [10334,10349]
name: es_task_handler [10353,10368]
===
match
---
name: filename_template [12873,12890]
name: filename_template [12892,12909]
===
match
---
atom_expr [12964,12979]
atom_expr [12983,12998]
===
match
---
name: os [13970,13972]
name: os [13989,13991]
===
match
---
name: self [3723,3727]
name: self [3723,3727]
===
match
---
atom_expr [6949,6966]
atom_expr [6968,6985]
===
match
---
assert_stmt [9071,9108]
assert_stmt [9090,9127]
===
match
---
name: test_message [5222,5234]
name: test_message [5241,5253]
===
match
---
name: try_number [13254,13264]
name: try_number [13273,13283]
===
match
---
name: parse [6671,6676]
name: parse [6690,6695]
===
match
---
name: es_task_handler [1154,1169]
name: es_task_handler [1154,1169]
===
match
---
comparison [9871,9883]
comparison [9890,9902]
===
match
---
assert_stmt [7772,7808]
assert_stmt [7791,7827]
===
match
---
simple_stmt [1202,1237]
simple_stmt [1202,1237]
===
match
---
simple_stmt [1237,1275]
simple_stmt [1237,1275]
===
match
---
trailer [10676,10686]
trailer [10695,10705]
===
match
---
name: id [6232,6234]
name: id [6251,6253]
===
match
---
fstring_expr [1579,1588]
fstring_expr [1579,1588]
===
match
---
trailer [9091,9094]
trailer [9110,9113]
===
match
---
expr_stmt [14870,14926]
expr_stmt [14889,14945]
===
match
---
simple_stmt [1665,1681]
simple_stmt [1665,1681]
===
match
---
assert_stmt [8944,8978]
assert_stmt [8963,8997]
===
match
---
name: task_id [4652,4659]
name: task_id [4652,4659]
===
match
---
atom_expr [11526,11599]
atom_expr [11545,11618]
===
match
---
trailer [13633,13651]
trailer [13652,13670]
===
match
---
trailer [13886,13893]
trailer [13905,13912]
===
match
---
assert_stmt [6546,6582]
assert_stmt [6565,6601]
===
match
---
trailer [6823,6839]
trailer [6842,6858]
===
match
---
string: 'T' [15342,15345]
string: 'T' [15361,15364]
===
match
---
trailer [4021,4037]
trailer [4021,4037]
===
match
---
number: 0 [7970,7971]
number: 0 [7989,7990]
===
match
---
name: TaskInstance [1050,1062]
name: TaskInstance [1050,1062]
===
match
---
string: 'offset' [11297,11305]
string: 'offset' [11316,11324]
===
match
---
arith_expr [15293,15352]
arith_expr [15312,15371]
===
match
---
operator: , [4920,4921]
operator: , [4920,4921]
===
match
---
name: clean_execution_date [15018,15038]
name: clean_execution_date [15037,15057]
===
match
---
string: 'offset' [6573,6581]
string: 'offset' [6592,6600]
===
match
---
trailer [11837,11851]
trailer [11856,11870]
===
match
---
atom_expr [9578,9615]
atom_expr [9597,9634]
===
match
---
simple_stmt [1018,1063]
simple_stmt [1018,1063]
===
match
---
trailer [8099,8106]
trailer [8118,8125]
===
match
---
atom_expr [8186,8312]
atom_expr [8205,8331]
===
match
---
trailer [4037,4042]
trailer [4037,4042]
===
match
---
trailer [2366,2369]
trailer [2366,2369]
===
match
---
funcdef [10117,10468]
funcdef [10136,10487]
===
match
---
expr_stmt [10756,11083]
expr_stmt [10775,11102]
===
match
---
trailer [13130,13146]
trailer [13149,13165]
===
match
---
operator: , [8717,8718]
operator: , [8736,8737]
===
match
---
name: self [2804,2808]
name: self [2804,2808]
===
match
---
suite [13291,13337]
suite [13310,13356]
===
match
---
trailer [6284,6289]
trailer [6303,6308]
===
match
---
operator: == [6713,6715]
operator: == [6732,6734]
===
match
---
number: 1 [8328,8329]
number: 1 [8347,8348]
===
match
---
simple_stmt [13430,13472]
simple_stmt [13449,13491]
===
match
---
simple_stmt [15129,15189]
simple_stmt [15148,15208]
===
match
---
operator: == [6916,6918]
operator: == [6935,6937]
===
match
---
name: self [2843,2847]
name: self [2843,2847]
===
match
---
name: logs [5621,5625]
name: logs [5640,5644]
===
match
---
name: self [2546,2550]
name: self [2546,2550]
===
match
---
name: client [3305,3311]
name: client [3305,3311]
===
match
---
number: 1 [5587,5588]
number: 1 [5606,5607]
===
match
---
atom_expr [4233,4245]
atom_expr [4233,4245]
===
match
---
number: 0 [7796,7797]
number: 0 [7815,7816]
===
match
---
operator: } [10863,10864]
operator: } [10882,10883]
===
match
---
number: 1 [7530,7531]
number: 1 [7549,7550]
===
match
---
operator: , [11072,11073]
operator: , [11091,11092]
===
match
---
with_stmt [12807,12981]
with_stmt [12826,13000]
===
match
---
string: 'end_of_log' [8282,8294]
string: 'end_of_log' [8301,8313]
===
match
---
simple_stmt [8422,8456]
simple_stmt [8441,8475]
===
match
---
trailer [5152,5158]
trailer [5171,5177]
===
match
---
with_stmt [9311,9782]
with_stmt [9330,9801]
===
match
---
string: 'last_log_timestamp' [8251,8271]
string: 'last_log_timestamp' [8270,8290]
===
match
---
simple_stmt [1418,1463]
simple_stmt [1418,1463]
===
match
---
name: dag_id [4608,4614]
name: dag_id [4608,4614]
===
match
---
atom_expr [4165,4174]
atom_expr [4165,4174]
===
match
---
simple_stmt [2362,2499]
simple_stmt [2362,2499]
===
match
---
simple_stmt [9892,9930]
simple_stmt [9911,9949]
===
match
---
name: self [6217,6221]
name: self [6236,6240]
===
match
---
atom_expr [5855,5869]
atom_expr [5874,5888]
===
match
---
name: pendulum [929,937]
name: pendulum [929,937]
===
match
---
trailer [11335,11339]
trailer [11354,11358]
===
match
---
atom_expr [15590,15891]
atom_expr [15609,15910]
===
match
---
operator: , [3904,3905]
operator: , [3904,3905]
===
match
---
atom_expr [7786,7808]
atom_expr [7805,7827]
===
match
---
number: 0 [12955,12956]
number: 0 [12974,12975]
===
match
---
trailer [13982,14052]
trailer [14001,14071]
===
match
---
atom_expr [12436,12459]
atom_expr [12455,12478]
===
match
---
name: self [10001,10005]
name: self [10020,10024]
===
match
---
string: 'last_log_timestamp' [4436,4456]
string: 'last_log_timestamp' [4436,4456]
===
match
---
name: test_message [10798,10810]
name: test_message [10817,10829]
===
match
---
name: es_task_handler [5539,5554]
name: es_task_handler [5558,5573]
===
match
---
trailer [8967,8978]
trailer [8986,8997]
===
match
---
operator: , [14759,14760]
operator: , [14778,14779]
===
match
---
name: TASK_ID [1580,1587]
name: TASK_ID [1580,1587]
===
match
---
atom_expr [3313,3340]
atom_expr [3313,3340]
===
match
---
trailer [7123,7126]
trailer [7142,7145]
===
match
---
operator: == [9007,9009]
operator: == [9026,9028]
===
match
---
atom_expr [2677,2688]
atom_expr [2677,2688]
===
match
---
name: self [12607,12611]
name: self [12626,12630]
===
match
---
operator: , [6206,6207]
operator: , [6225,6226]
===
match
---
name: self [2758,2762]
name: self [2758,2762]
===
match
---
assert_stmt [13709,13755]
assert_stmt [13728,13774]
===
match
---
name: ti [15957,15959]
name: ti [15976,15978]
===
match
---
decorator [1623,1636]
decorator [1623,1636]
===
match
---
trailer [4241,4244]
trailer [4241,4244]
===
match
---
expr_stmt [4765,4852]
expr_stmt [4765,4852]
===
match
---
name: open [13168,13172]
name: open [13187,13191]
===
match
---
number: 0 [4242,4243]
number: 0 [4242,4243]
===
match
---
atom_expr [2507,2522]
atom_expr [2507,2522]
===
match
---
name: pendulum [10524,10532]
name: pendulum [10543,10551]
===
match
---
atom_expr [4615,4650]
atom_expr [4615,4650]
===
match
---
operator: , [8172,8173]
operator: , [8191,8192]
===
match
---
atom_expr [13740,13755]
atom_expr [13759,13774]
===
match
---
name: len [4165,4168]
name: len [4165,4168]
===
match
---
atom_expr [3793,3813]
atom_expr [3793,3813]
===
match
---
atom_expr [6191,6206]
atom_expr [6210,6225]
===
match
---
atom_expr [10707,10739]
atom_expr [10726,10758]
===
match
---
trailer [11146,11149]
trailer [11165,11168]
===
match
---
trailer [5685,5688]
trailer [5704,5707]
===
match
---
name: es_conf [3562,3569]
name: es_conf [3562,3569]
===
match
---
string: 'asctime,filename,lineno,levelname,message' [2010,2053]
string: 'asctime,filename,lineno,levelname,message' [2010,2053]
===
match
---
simple_stmt [7665,7703]
simple_stmt [7684,7722]
===
match
---
atom_expr [1744,1766]
atom_expr [1744,1766]
===
match
---
name: self [14915,14919]
name: self [14934,14938]
===
match
---
number: 0 [5686,5687]
number: 0 [5705,5706]
===
match
---
name: local_log_location [14597,14615]
name: local_log_location [14616,14634]
===
match
---
atom_expr [11125,11132]
atom_expr [11144,11151]
===
match
---
name: local_log_location [3168,3186]
name: local_log_location [3168,3186]
===
match
---
trailer [13356,13372]
trailer [13375,13391]
===
match
---
import_from [1275,1318]
import_from [1275,1318]
===
match
---
name: parse [5811,5816]
name: parse [5830,5835]
===
match
---
trailer [5045,5048]
trailer [5045,5048]
===
match
---
name: read [13329,13333]
name: read [13348,13352]
===
match
---
assert_stmt [7594,7628]
assert_stmt [7613,7647]
===
match
---
simple_stmt [938,978]
simple_stmt [938,978]
===
match
---
argument [4941,4945]
argument [4941,4945]
===
match
---
argument [2893,2913]
argument [2893,2913]
===
match
---
atom_expr [4203,4217]
atom_expr [4203,4217]
===
match
---
trailer [9707,9717]
trailer [9726,9736]
===
match
---
name: self [11245,11249]
name: self [11264,11268]
===
match
---
expr_stmt [15572,15891]
expr_stmt [15591,15910]
===
match
---
assert_stmt [7938,8000]
assert_stmt [7957,8019]
===
match
---
operator: , [15353,15354]
operator: , [15372,15373]
===
match
---
name: es_task_handler [14884,14899]
name: es_task_handler [14903,14918]
===
match
---
name: State [3062,3067]
name: State [3062,3067]
===
match
---
trailer [3763,3779]
trailer [3763,3779]
===
match
---
trailer [12231,12238]
trailer [12250,12257]
===
match
---
funcdef [3942,4464]
funcdef [3942,4464]
===
match
---
atom_expr [11808,11851]
atom_expr [11827,11870]
===
match
---
with_item [13168,13290]
with_item [13187,13309]
===
match
---
name: len [8964,8967]
name: len [8983,8986]
===
match
---
simple_stmt [5653,5696]
simple_stmt [5672,5715]
===
match
---
expr_stmt [11608,11650]
expr_stmt [11627,11669]
===
match
---
comparison [11387,11478]
comparison [11406,11497]
===
match
---
simple_stmt [1320,1357]
simple_stmt [1320,1357]
===
match
---
name: parse [9223,9228]
name: parse [9242,9247]
===
match
---
name: metadatas [8375,8384]
name: metadatas [8394,8403]
===
match
---
funcdef [3235,3342]
funcdef [3235,3342]
===
match
---
trailer [3088,3099]
trailer [3088,3099]
===
match
---
name: index [2720,2725]
name: index [2720,2725]
===
match
---
atom_expr [2264,2281]
atom_expr [2264,2281]
===
match
---
expr_stmt [4522,4706]
expr_stmt [4522,4706]
===
match
---
simple_stmt [14935,14968]
simple_stmt [14954,14987]
===
match
---
atom_expr [8926,8935]
atom_expr [8945,8954]
===
match
---
name: logs [7477,7481]
name: logs [7496,7500]
===
match
---
number: 0 [5243,5244]
number: 0 [5262,5263]
===
match
---
trailer [1800,1816]
trailer [1800,1816]
===
match
---
name: closed [12698,12704]
name: closed [12717,12723]
===
match
---
operator: , [11339,11340]
operator: , [11358,11359]
===
match
---
atom_expr [12677,12704]
atom_expr [12696,12723]
===
match
---
name: logs [4287,4291]
name: logs [4287,4291]
===
match
---
trailer [11692,11701]
trailer [11711,11720]
===
match
---
simple_stmt [6500,6538]
simple_stmt [6519,6557]
===
match
---
param [3251,3255]
param [3251,3255]
===
match
---
trailer [2782,2787]
trailer [2782,2787]
===
match
---
name: index [8107,8112]
name: index [8126,8131]
===
match
---
suite [6764,8001]
suite [6783,8020]
===
match
---
atom_expr [13316,13336]
atom_expr [13335,13355]
===
match
---
atom_expr [13352,13379]
atom_expr [13371,13398]
===
match
---
comparison [6949,6984]
comparison [6968,7003]
===
match
---
trailer [13333,13335]
trailer [13352,13354]
===
match
---
string: '0' [7779,7782]
string: '0' [7798,7801]
===
match
---
not_test [7672,7702]
not_test [7691,7721]
===
match
---
atom_expr [8964,8978]
atom_expr [8983,8997]
===
match
---
name: expected_dict [3573,3586]
name: expected_dict [3573,3586]
===
match
---
operator: == [9838,9840]
operator: == [9857,9859]
===
match
---
number: 0 [5689,5690]
number: 0 [5708,5709]
===
match
---
name: timezone [5802,5810]
name: timezone [5821,5829]
===
match
---
name: now [5864,5867]
name: now [5883,5886]
===
match
---
simple_stmt [13531,13560]
simple_stmt [13550,13579]
===
match
---
operator: , [15880,15881]
operator: , [15899,15900]
===
match
---
funcdef [14973,15189]
funcdef [14992,15208]
===
match
---
name: self [11208,11212]
name: self [11227,11231]
===
match
---
dictorsetmaker [4069,4132]
dictorsetmaker [4069,4132]
===
match
---
name: self [9027,9031]
name: self [9046,9050]
===
match
---
argument [2915,2927]
argument [2915,2927]
===
match
---
name: logs [6801,6805]
name: logs [6820,6824]
===
match
---
atom_expr [11660,11701]
atom_expr [11679,11720]
===
match
---
argument [6185,6206]
argument [6204,6225]
===
match
---
trailer [6174,6177]
trailer [6193,6196]
===
match
---
trailer [1748,1766]
trailer [1748,1766]
===
match
---
number: 1 [1549,1550]
number: 1 [1549,1550]
===
match
---
number: 0 [8248,8249]
number: 0 [8267,8268]
===
match
---
simple_stmt [6546,6583]
simple_stmt [6565,6602]
===
match
---
trailer [2941,2944]
trailer [2941,2944]
===
match
---
name: test_message [6954,6966]
name: test_message [6973,6985]
===
match
---
trailer [7408,7415]
trailer [7427,7434]
===
match
---
trailer [5329,5332]
trailer [5348,5351]
===
match
---
comparison [5217,5252]
comparison [5236,5271]
===
match
---
argument [4652,4696]
argument [4652,4696]
===
match
---
name: metadatas [6560,6569]
name: metadatas [6579,6588]
===
match
---
trailer [9844,9855]
trailer [9863,9874]
===
match
---
trailer [8276,8280]
trailer [8295,8299]
===
match
---
arglist [2893,2927]
arglist [2893,2927]
===
match
---
not_test [5711,5741]
not_test [5730,5760]
===
match
---
name: es_task_handler [12612,12627]
name: es_task_handler [12631,12646]
===
match
---
expr_stmt [14221,14375]
expr_stmt [14240,14394]
===
match
---
comparison [14942,14967]
comparison [14961,14986]
===
match
---
operator: , [14790,14791]
operator: , [14809,14810]
===
match
---
comparison [5617,5644]
comparison [5636,5663]
===
match
---
name: self [10049,10053]
name: self [10068,10072]
===
match
---
name: id [4941,4943]
name: id [4941,4943]
===
match
---
name: format [12891,12897]
name: format [12910,12916]
===
match
---
number: 1 [12909,12910]
number: 1 [12928,12929]
===
match
---
assert_stmt [6899,6933]
assert_stmt [6918,6952]
===
match
---
trailer [13172,13278]
trailer [13191,13297]
===
match
---
name: logs [9048,9052]
name: logs [9067,9071]
===
match
---
name: try_number [11838,11848]
name: try_number [11857,11867]
===
match
---
trailer [8774,8777]
trailer [8793,8796]
===
match
---
atom [6315,6380]
atom [6334,6399]
===
match
---
comparison [7601,7628]
comparison [7620,7647]
===
match
---
atom_expr [12461,12504]
atom_expr [12480,12523]
===
match
---
trailer [3022,3033]
trailer [3022,3033]
===
match
---
simple_stmt [8944,8979]
simple_stmt [8963,8998]
===
match
---
trailer [12842,12912]
trailer [12861,12931]
===
match
---
atom_expr [5089,5096]
atom_expr [5091,5098]
===
match
---
simple_stmt [6472,6492]
simple_stmt [6491,6511]
===
match
---
name: path [13189,13193]
name: path [13208,13212]
===
match
---
assert_stmt [5580,5601]
assert_stmt [5599,5620]
===
match
---
simple_stmt [2712,2795]
simple_stmt [2712,2795]
===
match
---
operator: , [9611,9612]
operator: , [9630,9631]
===
match
---
trailer [5933,5937]
trailer [5952,5956]
===
match
---
operator: = [8688,8689]
operator: = [8707,8708]
===
match
---
atom_expr [5534,5571]
atom_expr [5553,5590]
===
match
---
atom_expr [13199,13222]
atom_expr [13218,13241]
===
match
---
expr_stmt [12677,12711]
expr_stmt [12696,12730]
===
match
---
atom [15265,15353]
atom [15284,15372]
===
match
---
name: now [8057,8060]
name: now [8076,8079]
===
match
---
atom_expr [13430,13471]
atom_expr [13449,13490]
===
match
---
simple_stmt [5210,5253]
simple_stmt [5229,5272]
===
match
---
trailer [6268,6284]
trailer [6287,6303]
===
match
---
operator: { [10850,10851]
operator: { [10869,10870]
===
match
---
name: index [11150,11155]
name: index [11169,11174]
===
match
---
trailer [7126,7136]
trailer [7145,7155]
===
match
---
arglist [12843,12911]
arglist [12862,12930]
===
match
---
argument [11838,11850]
argument [11857,11869]
===
match
---
operator: < [5853,5854]
operator: < [5872,5873]
===
match
---
factor [6981,6983]
factor [7000,7002]
===
match
---
simple_stmt [4715,4756]
simple_stmt [4715,4756]
===
match
---
arglist [11783,11851]
arglist [11802,11870]
===
match
---
atom_expr [4408,4458]
atom_expr [4408,4458]
===
match
---
name: metadatas [9845,9854]
name: metadatas [9864,9873]
===
match
---
expr_stmt [14384,14440]
expr_stmt [14403,14459]
===
match
---
name: read [9599,9603]
name: read [9618,9622]
===
match
---
atom_expr [13224,13267]
atom_expr [13243,13286]
===
match
---
name: self [6303,6307]
name: self [6322,6326]
===
match
---
trailer [13603,13673]
trailer [13622,13692]
===
match
---
atom_expr [3084,3115]
atom_expr [3084,3115]
===
match
---
name: metadatas [8539,8548]
name: metadatas [8558,8567]
===
match
---
trailer [15947,15950]
trailer [15966,15969]
===
match
---
suite [14075,14135]
suite [14094,14154]
===
match
---
operator: == [9876,9878]
operator: == [9895,9897]
===
match
---
atom_expr [7004,7030]
atom_expr [7023,7049]
===
match
---
trailer [12724,12740]
trailer [12743,12759]
===
match
---
name: len [6411,6414]
name: len [6430,6433]
===
match
---
simple_stmt [1113,1202]
simple_stmt [1113,1202]
===
match
---
simple_stmt [803,813]
simple_stmt [803,813]
===
match
---
operator: = [8112,8113]
operator: = [8131,8132]
===
match
---
name: self [11284,11288]
name: self [11303,11307]
===
match
---
atom_expr [15800,15816]
atom_expr [15819,15835]
===
match
---
operator: = [13111,13112]
operator: = [13130,13131]
===
match
---
name: pendulum [5855,5863]
name: pendulum [5874,5882]
===
match
---
comparison [14456,14481]
comparison [14475,14500]
===
match
---
string: '%(asctime)s - %(name)s - %(levelname)s - %(message)s' [10214,10268]
string: '%(asctime)s - %(name)s - %(levelname)s - %(message)s' [10233,10287]
===
match
---
operator: = [4537,4538]
operator: = [4537,4538]
===
match
---
name: self [13841,13845]
name: self [13860,13864]
===
match
---
string: "verify_certs" [3515,3529]
string: "verify_certs" [3515,3529]
===
match
---
trailer [11096,11112]
trailer [11115,11131]
===
match
---
atom_expr [3015,3033]
atom_expr [3015,3033]
===
match
---
name: formatter [11629,11638]
name: formatter [11648,11657]
===
match
---
name: self [12753,12757]
name: self [12772,12776]
===
match
---
trailer [15739,15755]
trailer [15758,15774]
===
match
---
operator: , [3925,3926]
operator: , [3925,3926]
===
match
---
atom_expr [14629,14651]
atom_expr [14648,14670]
===
match
---
import_from [1063,1112]
import_from [1063,1112]
===
match
---
name: write_stdout [3832,3844]
name: write_stdout [3832,3844]
===
match
---
trailer [7972,7994]
trailer [7991,8013]
===
match
---
atom [2452,2487]
atom [2452,2487]
===
match
---
name: os [13591,13593]
name: os [13610,13612]
===
match
---
string: 'log_id' [2667,2675]
string: 'log_id' [2667,2675]
===
match
---
comparison [6876,6890]
comparison [6895,6909]
===
match
---
assert_stmt [12204,12238]
assert_stmt [12223,12257]
===
match
---
name: self [6845,6849]
name: self [6864,6868]
===
match
---
name: end_of_log_mark [12160,12175]
name: end_of_log_mark [12179,12194]
===
match
---
name: id [11219,11221]
name: id [11238,11240]
===
match
---
name: es_task_handler [13485,13500]
name: es_task_handler [13504,13519]
===
match
---
atom_expr [7601,7610]
atom_expr [7620,7629]
===
match
---
name: self [12436,12440]
name: self [12455,12459]
===
match
---
trailer [13753,13755]
trailer [13772,13774]
===
match
---
expr_stmt [6773,6792]
expr_stmt [6792,6811]
===
match
---
operator: { [4780,4781]
operator: { [4780,4781]
===
match
---
trailer [10841,10848]
trailer [10860,10867]
===
match
---
name: self [11710,11714]
name: self [11729,11733]
===
match
---
operator: = [7465,7466]
operator: = [7484,7485]
===
match
---
argument [11156,11177]
argument [11175,11196]
===
match
---
assert_stmt [5167,5201]
assert_stmt [5186,5220]
===
match
---
trailer [13878,13886]
trailer [13897,13905]
===
match
---
name: self [13983,13987]
name: self [14002,14006]
===
match
---
atom_expr [4907,4920]
atom_expr [4907,4920]
===
match
---
simple_stmt [9020,9063]
simple_stmt [9039,9082]
===
match
---
trailer [3988,3990]
trailer [3988,3990]
===
match
---
operator: } [1577,1578]
operator: } [1577,1578]
===
match
---
simple_stmt [5610,5645]
simple_stmt [5629,5664]
===
match
---
name: self [10426,10430]
name: self [10445,10449]
===
match
---
trailer [8604,8626]
trailer [8623,8645]
===
match
---
trailer [5867,5869]
trailer [5886,5888]
===
match
---
funcdef [3347,3937]
funcdef [3347,3937]
===
match
---
atom_expr [15041,15120]
atom_expr [15060,15139]
===
match
---
import_from [843,868]
import_from [843,868]
===
match
---
name: test_close_with_no_handler [12990,13016]
name: test_close_with_no_handler [13009,13035]
===
match
---
trailer [9241,9263]
trailer [9260,9282]
===
match
---
operator: } [10848,10849]
operator: } [10867,10868]
===
match
---
simple_stmt [6399,6421]
simple_stmt [6418,6440]
===
match
---
comparison [8328,8342]
comparison [8347,8361]
===
match
---
operator: = [6234,6235]
operator: = [6253,6254]
===
match
---
argument [11179,11201]
argument [11198,11220]
===
match
---
atom_expr [2624,2633]
atom_expr [2624,2633]
===
match
---
name: metadatas [7618,7627]
name: metadatas [7637,7646]
===
match
---
name: utils [1288,1293]
name: utils [1288,1293]
===
match
---
name: self [4266,4270]
name: self [4266,4270]
===
match
---
assert_stmt [11380,11478]
assert_stmt [11399,11497]
===
match
---
atom_expr [4881,4896]
atom_expr [4881,4896]
===
match
---
name: read [7516,7520]
name: read [7535,7539]
===
match
---
not_test [9078,9108]
not_test [9097,9127]
===
match
---
comparison [6553,6582]
comparison [6572,6601]
===
match
---
name: set_context [12741,12752]
name: set_context [12760,12771]
===
match
---
name: TestCase [1403,1411]
name: TestCase [1403,1411]
===
match
---
trailer [4885,4896]
trailer [4885,4896]
===
match
---
name: path [3196,3200]
name: path [3196,3200]
===
match
---
string: "use_ssl" [3485,3494]
string: "use_ssl" [3485,3494]
===
match
---
simple_stmt [13858,13902]
simple_stmt [13877,13921]
===
match
---
number: 1 [6854,6855]
number: 1 [6873,6874]
===
match
---
trailer [6439,6445]
trailer [6458,6464]
===
match
---
number: 0 [4292,4293]
number: 0 [4292,4293]
===
match
---
simple_stmt [15900,15972]
simple_stmt [15919,15991]
===
match
---
name: metadatas [8429,8438]
name: metadatas [8448,8457]
===
match
---
atom_expr [2986,3005]
atom_expr [2986,3005]
===
match
---
trailer [12977,12979]
trailer [12996,12998]
===
match
---
arglist [6303,6380]
arglist [6322,6399]
===
match
---
atom_expr [5630,5644]
atom_expr [5649,5663]
===
match
---
name: parse [8586,8591]
name: parse [8605,8610]
===
match
---
name: self [3100,3104]
name: self [3100,3104]
===
match
---
name: es_task_handler [10021,10036]
name: es_task_handler [10040,10055]
===
match
---
import_as_names [1045,1062]
import_as_names [1045,1062]
===
match
---
operator: , [11239,11240]
operator: , [11258,11259]
===
match
---
simple_stmt [8092,8160]
simple_stmt [8111,8179]
===
match
---
name: logs [11235,11239]
name: logs [11254,11258]
===
match
---
atom_expr [7495,7555]
atom_expr [7514,7574]
===
match
---
name: read [8207,8211]
name: read [8226,8230]
===
match
---
comparison [5174,5201]
comparison [5193,5220]
===
match
---
operator: == [6557,6559]
operator: == [6576,6578]
===
match
---
atom_expr [5764,5786]
atom_expr [5783,5805]
===
match
---
trailer [13319,13336]
trailer [13338,13355]
===
match
---
simple_stmt [10547,10648]
simple_stmt [10566,10667]
===
match
---
fstring_start: f' [10834,10836]
fstring_start: f' [10853,10855]
===
match
---
atom_expr [3163,3208]
atom_expr [3163,3208]
===
match
---
assert_stmt [8321,8342]
assert_stmt [8340,8361]
===
match
---
simple_stmt [8713,8906]
simple_stmt [8732,8925]
===
match
---
trailer [2847,2862]
trailer [2847,2862]
===
match
---
string: 'https://localhost:5601' [15453,15477]
string: 'https://localhost:5601' [15472,15496]
===
match
---
name: logs [5516,5520]
name: logs [5535,5539]
===
match
---
name: es_task_handler [13357,13372]
name: es_task_handler [13376,13391]
===
match
---
name: self [7401,7405]
name: self [7420,7424]
===
match
---
simple_stmt [9560,9616]
simple_stmt [9579,9635]
===
match
---
comparison [7107,7136]
comparison [7126,7155]
===
match
---
name: es_task_handler [12682,12697]
name: es_task_handler [12701,12716]
===
match
---
operator: = [7493,7494]
operator: = [7512,7513]
===
match
---
atom_expr [6264,6390]
atom_expr [6283,6409]
===
match
---
name: replace [15334,15341]
name: replace [15353,15360]
===
match
---
trailer [9413,9419]
trailer [9432,9438]
===
match
---
name: stream [13509,13515]
name: stream [13528,13534]
===
match
---
atom_expr [13771,13798]
atom_expr [13790,13817]
===
match
---
atom_expr [14554,14861]
atom_expr [14573,14880]
===
match
---
argument [14038,14050]
argument [14057,14069]
===
match
---
name: doc_type [11193,11201]
name: doc_type [11212,11220]
===
match
---
trailer [8106,8159]
trailer [8125,8178]
===
match
---
suite [12935,12981]
suite [12954,13000]
===
match
---
suite [13023,13380]
suite [13042,13399]
===
match
---
string: '2016_07_08T09_10_11_000012' [15136,15164]
string: '2016_07_08T09_10_11_000012' [15155,15183]
===
match
---
name: setUp [1673,1678]
name: setUp [1673,1678]
===
match
---
comparison [5757,5786]
comparison [5776,5805]
===
match
---
name: airflow [1207,1214]
name: airflow [1207,1214]
===
match
---
number: 9 [15105,15106]
number: 9 [15124,15125]
===
match
---
argument [8130,8152]
argument [8149,8171]
===
match
---
name: test_render_log_id [14187,14205]
name: test_render_log_id [14206,14224]
===
match
---
assert_stmt [6399,6420]
assert_stmt [6418,6439]
===
match
---
comparison [8951,8978]
comparison [8970,8997]
===
match
---
simple_stmt [5309,5347]
simple_stmt [5328,5366]
===
match
---
assert_stmt [3266,3341]
assert_stmt [3266,3341]
===
match
---
trailer [12430,12435]
trailer [12449,12454]
===
match
---
trailer [5381,5391]
trailer [5400,5410]
===
match
---
arglist [3284,3340]
arglist [3284,3340]
===
match
---
atom_expr [8690,8704]
atom_expr [8709,8723]
===
match
---
trailer [12293,12297]
trailer [12312,12316]
===
match
---
name: self [1878,1882]
name: self [1878,1882]
===
match
---
name: self [10016,10020]
name: self [10035,10039]
===
match
---
name: self [6758,6762]
name: self [6777,6781]
===
match
---
number: 1 [9010,9011]
number: 1 [9029,9030]
===
match
---
trailer [12897,12911]
trailer [12916,12930]
===
match
---
atom_expr [8429,8455]
atom_expr [8448,8474]
===
match
---
assert_stmt [4310,4347]
assert_stmt [4310,4347]
===
match
---
param [15003,15007]
param [15022,15026]
===
match
---
atom_expr [5617,5626]
atom_expr [5636,5645]
===
match
---
atom_expr [6303,6310]
atom_expr [6322,6329]
===
match
---
expr_stmt [3999,4143]
expr_stmt [3999,4143]
===
match
---
trailer [12774,12790]
trailer [12793,12809]
===
match
---
trailer [8071,8082]
trailer [8090,8101]
===
match
---
string: 'end_of_log' [4334,4346]
string: 'end_of_log' [4334,4346]
===
match
---
name: try_number [13659,13669]
name: try_number [13678,13688]
===
match
---
name: ti [13846,13848]
name: ti [13865,13867]
===
match
---
name: self [14592,14596]
name: self [14611,14615]
===
match
---
testlist_star_expr [6246,6261]
testlist_star_expr [6265,6280]
===
match
---
trailer [15921,15942]
trailer [15940,15961]
===
match
---
name: self [1924,1928]
name: self [1924,1928]
===
match
---
name: log_file [12576,12584]
name: log_file [12595,12603]
===
match
---
trailer [6849,6852]
trailer [6868,6871]
===
match
---
name: ti [13468,13470]
name: ti [13487,13489]
===
match
---
name: es_task_handler [13536,13551]
name: es_task_handler [13555,13570]
===
match
---
operator: , [14651,14652]
operator: , [14670,14671]
===
match
---
atom_expr [1878,1898]
atom_expr [1878,1898]
===
match
---
operator: , [3501,3502]
operator: , [3501,3502]
===
match
---
operator: { [1579,1580]
operator: { [1579,1580]
===
match
---
simple_stmt [15980,16007]
simple_stmt [15999,16026]
===
match
---
name: split [3187,3192]
name: split [3187,3192]
===
match
---
simple_stmt [8351,8386]
simple_stmt [8370,8405]
===
match
---
number: 0 [6687,6688]
number: 0 [6706,6707]
===
match
---
trailer [6221,6230]
trailer [6240,6249]
===
match
---
arglist [6185,6236]
arglist [6204,6255]
===
match
---
name: os [810,812]
name: os [810,812]
===
match
---
name: logs [4237,4241]
name: logs [4237,4241]
===
match
---
trailer [8361,8367]
trailer [8380,8386]
===
match
---
atom_expr [2062,2082]
atom_expr [2062,2082]
===
match
---
operator: , [3311,3312]
operator: , [3311,3312]
===
match
---
trailer [5773,5776]
trailer [5792,5795]
===
match
---
testlist_star_expr [3999,4014]
testlist_star_expr [3999,4014]
===
match
---
string: 'offset' [4383,4391]
string: 'offset' [4383,4391]
===
match
---
name: local_log_location [11788,11806]
name: local_log_location [11807,11825]
===
match
---
trailer [2628,2633]
trailer [2628,2633]
===
match
---
operator: == [7783,7785]
operator: == [7802,7804]
===
match
---
suite [1413,16007]
suite [1413,16026]
===
match
---
simple_stmt [12600,12635]
simple_stmt [12619,12654]
===
match
---
simple_stmt [788,803]
simple_stmt [788,803]
===
match
---
name: try_number [14038,14048]
name: try_number [14057,14067]
===
match
---
argument [4898,4920]
argument [4898,4920]
===
match
---
argument [12898,12910]
argument [12917,12929]
===
match
---
name: ts [6355,6357]
name: ts [6374,6376]
===
match
---
atom_expr [10851,10863]
atom_expr [10870,10882]
===
match
---
atom_expr [9229,9263]
atom_expr [9248,9282]
===
match
---
string: 'message' [4781,4790]
string: 'message' [4781,4790]
===
match
---
atom_expr [12346,12353]
atom_expr [12365,12372]
===
match
---
atom_expr [5817,5851]
atom_expr [5836,5870]
===
match
---
name: self [3759,3763]
name: self [3759,3763]
===
match
---
atom_expr [5149,5158]
atom_expr [5168,5177]
===
match
---
name: es_task_handler [13435,13450]
name: es_task_handler [13454,13469]
===
match
---
trailer [11469,11472]
trailer [11488,11491]
===
match
---
name: call_args [9708,9717]
name: call_args [9727,9736]
===
match
---
operator: , [4939,4940]
operator: , [4939,4940]
===
match
---
operator: , [11294,11295]
operator: , [11313,11314]
===
match
---
parameters [15002,15008]
parameters [15021,15027]
===
match
---
name: self [4507,4511]
name: self [4507,4511]
===
match
---
trailer [1962,1974]
trailer [1962,1974]
===
match
---
assert_stmt [4356,4392]
assert_stmt [4356,4392]
===
match
---
number: 1 [4850,4851]
number: 1 [4850,4851]
===
match
---
operator: , [6313,6314]
operator: , [6332,6333]
===
match
---
simple_stmt [9489,9544]
simple_stmt [9508,9563]
===
match
---
simple_stmt [14384,14441]
simple_stmt [14403,14460]
===
match
---
name: local_log_location [15633,15651]
name: local_log_location [15652,15670]
===
match
---
number: 0 [5330,5331]
number: 0 [5349,5350]
===
match
---
arglist [3163,3228]
arglist [3163,3228]
===
match
---
trailer [12465,12483]
trailer [12484,12502]
===
match
---
operator: , [15451,15452]
operator: , [15470,15471]
===
match
---
simple_stmt [7266,7329]
simple_stmt [7285,7348]
===
match
---
trailer [7795,7798]
trailer [7814,7817]
===
match
---
name: index_name [11167,11177]
name: index_name [11186,11196]
===
match
---
expr_stmt [1689,1735]
expr_stmt [1689,1735]
===
match
---
operator: = [10557,10558]
operator: = [10576,10577]
===
match
---
string: 'another message' [4738,4755]
string: 'another message' [4738,4755]
===
match
---
atom_expr [9214,9264]
atom_expr [9233,9283]
===
match
---
operator: = [10740,10741]
operator: = [10759,10760]
===
match
---
trailer [11212,11217]
trailer [11231,11236]
===
match
---
import_from [979,1017]
import_from [979,1017]
===
match
---
trailer [14099,14115]
trailer [14118,14134]
===
match
---
trailer [3304,3311]
trailer [3304,3311]
===
match
---
atom_expr [9828,9837]
atom_expr [9847,9856]
===
match
---
string: 'lineno' [11026,11034]
string: 'lineno' [11045,11053]
===
match
---
name: json_format [3863,3874]
name: json_format [3863,3874]
===
match
---
expr_stmt [9489,9543]
expr_stmt [9508,9562]
===
match
---
trailer [13328,13333]
trailer [13347,13352]
===
match
---
name: log_line [12187,12195]
name: log_line [12206,12214]
===
match
---
atom_expr [4370,4392]
atom_expr [4370,4392]
===
match
---
name: self [2196,2200]
name: self [2196,2200]
===
match
---
name: TASK_ID [2906,2913]
name: TASK_ID [2906,2913]
===
match
---
trailer [13467,13470]
trailer [13486,13489]
===
match
---
name: self [12677,12681]
name: self [12696,12700]
===
match
---
operator: , [15786,15787]
operator: , [15805,15806]
===
match
---
simple_stmt [1559,1618]
simple_stmt [1559,1618]
===
match
---
name: dict [3400,3404]
name: dict [3400,3404]
===
match
---
argument [8107,8128]
argument [8126,8147]
===
match
---
name: logs [9807,9811]
name: logs [9826,9830]
===
match
---
name: es_task_handler [8736,8751]
name: es_task_handler [8755,8770]
===
match
---
name: es_task_handler [14155,14170]
name: es_task_handler [14174,14189]
===
match
---
name: ignore_errors [3210,3223]
name: ignore_errors [3210,3223]
===
match
---
name: self [2919,2923]
name: self [2919,2923]
===
match
---
operator: , [1547,1548]
operator: , [1547,1548]
===
match
---
trailer [13914,13930]
trailer [13933,13949]
===
match
---
trailer [8997,9006]
trailer [9016,9025]
===
match
---
trailer [13450,13462]
trailer [13469,13481]
===
match
---
atom_expr [10016,10057]
atom_expr [10035,10076]
===
match
---
name: es_task_handler [3289,3304]
name: es_task_handler [3289,3304]
===
match
---
trailer [3831,3844]
trailer [3831,3844]
===
match
---
name: self [13463,13467]
name: self [13482,13486]
===
match
---
number: 1 [4944,4945]
number: 1 [4944,4945]
===
match
---
param [12271,12275]
param [12290,12294]
===
match
---
suite [5911,6719]
suite [5930,6738]
===
match
---
name: self [13065,13069]
name: self [13084,13088]
===
match
---
name: metadatas [5191,5200]
name: metadatas [5210,5219]
===
match
---
atom_expr [12868,12911]
atom_expr [12887,12930]
===
match
---
operator: = [2083,2084]
operator: = [2083,2084]
===
match
---
name: args [9774,9778]
name: args [9793,9797]
===
match
---
name: log_file [12926,12934]
name: log_file [12945,12953]
===
match
---
atom_expr [7945,7995]
atom_expr [7964,8014]
===
match
---
atom_expr [8731,8905]
atom_expr [8750,8924]
===
match
---
funcdef [14183,14968]
funcdef [14202,14987]
===
match
---
atom [14239,14375]
atom [14258,14394]
===
match
---
name: self [11693,11697]
name: self [11712,11716]
===
match
---
operator: = [4614,4615]
operator: = [4614,4615]
===
match
---
assert_stmt [8525,8561]
assert_stmt [8544,8580]
===
match
---
number: 0 [4380,4381]
number: 0 [4380,4381]
===
match
---
name: es [8097,8099]
name: es [8116,8118]
===
match
---
atom_expr [3284,3311]
atom_expr [3284,3311]
===
match
---
name: filename_template [11813,11830]
name: filename_template [11832,11849]
===
match
---
trailer [13228,13246]
trailer [13247,13265]
===
match
---
name: TestElasticsearchTaskHandler [4615,4643]
name: TestElasticsearchTaskHandler [4615,4643]
===
match
---
string: 'some random stuff' [2596,2615]
string: 'some random stuff' [2596,2615]
===
match
---
string: '[%(asctime)s] {%(filename)s:%(lineno)d} %(levelname)s - %(message)s' [10577,10646]
string: '[%(asctime)s] {%(filename)s:%(lineno)d} %(levelname)s - %(message)s' [10596,10665]
===
match
---
atom_expr [8842,8849]
atom_expr [8861,8868]
===
match
---
name: ts [6773,6775]
name: ts [6792,6794]
===
match
---
trailer [12483,12490]
trailer [12502,12509]
===
match
---
simple_stmt [2804,2864]
simple_stmt [2804,2864]
===
match
---
name: self [10329,10333]
name: self [10348,10352]
===
match
---
atom_expr [3149,3229]
atom_expr [3149,3229]
===
match
---
trailer [10077,10093]
trailer [10096,10112]
===
match
---
trailer [15956,15959]
trailer [15975,15978]
===
match
---
atom_expr [6217,6230]
atom_expr [6236,6249]
===
match
---
trailer [8698,8702]
trailer [8717,8721]
===
match
---
fstring_end: ' [10893,10894]
fstring_end: ' [10912,10913]
===
match
---
name: self [12843,12847]
name: self [12862,12866]
===
match
---
string: '0' [9945,9948]
string: '0' [9964,9967]
===
match
---
atom_expr [3723,3745]
atom_expr [3723,3745]
===
match
---
expr_stmt [1924,1949]
expr_stmt [1924,1949]
===
match
---
trailer [1678,1680]
trailer [1678,1680]
===
match
---
expr_stmt [4715,4755]
expr_stmt [4715,4755]
===
match
---
simple_stmt [9628,9666]
simple_stmt [9647,9685]
===
match
---
trailer [5937,5939]
trailer [5956,5958]
===
match
---
param [1650,1654]
param [1650,1654]
===
match
---
comparison [12548,12591]
comparison [12567,12610]
===
match
---
name: test_read_as_download_logs [8643,8669]
name: test_read_as_download_logs [8662,8688]
===
match
---
name: mock_execute [9459,9471]
name: mock_execute [9478,9490]
===
match
---
simple_stmt [10329,10370]
simple_stmt [10348,10389]
===
match
---
string: '1' [5757,5760]
string: '1' [5776,5779]
===
match
---
atom [4780,4852]
atom [4780,4852]
===
match
---
name: self [10169,10173]
name: self [10188,10192]
===
match
---
expr_stmt [2624,2702]
expr_stmt [2624,2702]
===
match
---
testlist_star_expr [8713,8728]
testlist_star_expr [8732,8747]
===
match
---
operator: == [4200,4202]
operator: == [4200,4202]
===
match
---
number: 1 [9060,9061]
number: 1 [9079,9080]
===
match
---
factor [9059,9061]
factor [9078,9080]
===
match
---
comparison [5660,5695]
comparison [5679,5714]
===
match
---
name: test_read_timeout [8010,8027]
name: test_read_timeout [8029,8046]
===
match
---
atom_expr [6819,6860]
atom_expr [6838,6879]
===
match
---
operator: @ [15194,15195]
operator: @ [15213,15214]
===
match
---
trailer [11472,11475]
trailer [11491,11494]
===
match
---
name: test_set_context [9984,10000]
name: test_set_context [10003,10019]
===
match
---
trailer [4294,4297]
trailer [4294,4297]
===
match
---
arglist [2726,2793]
arglist [2726,2793]
===
match
---
arglist [5041,5118]
arglist [5041,5137]
===
match
---
name: metadatas [8592,8601]
name: metadatas [8611,8620]
===
match
---
name: expected_url [15549,15561]
name: expected_url [15568,15580]
===
match
---
operator: , [14820,14821]
operator: , [14839,14840]
===
match
---
atom_expr [9048,9062]
atom_expr [9067,9081]
===
match
---
arglist [15628,15881]
arglist [15647,15900]
===
match
---
parameters [13414,13420]
parameters [13433,13439]
===
match
---
operator: , [11217,11218]
operator: , [11236,11237]
===
match
---
string: 'message' [2637,2646]
string: 'message' [2637,2646]
===
match
---
atom_expr [2937,2944]
atom_expr [2937,2944]
===
match
---
trailer [5810,5816]
trailer [5829,5835]
===
match
---
assert_stmt [9938,9974]
assert_stmt [9957,9993]
===
match
---
with_stmt [9404,9616]
with_stmt [9423,9635]
===
match
---
trailer [14743,14759]
trailer [14762,14778]
===
match
---
trailer [9222,9228]
trailer [9241,9247]
===
match
---
atom_expr [11188,11201]
atom_expr [11207,11220]
===
match
---
name: read [5555,5559]
name: read [5574,5578]
===
match
---
trailer [14433,14436]
trailer [14452,14455]
===
match
---
atom [9872,9874]
atom [9891,9893]
===
match
---
trailer [14132,14134]
trailer [14151,14153]
===
match
---
suite [9391,9782]
suite [9410,9801]
===
match
---
argument [2789,2793]
argument [2789,2793]
===
match
---
name: TASK_ID [4689,4696]
name: TASK_ID [4689,4696]
===
match
---
atom_expr [3648,3936]
atom_expr [3648,3936]
===
match
---
trailer [4168,4174]
trailer [4168,4174]
===
match
---
atom_expr [9635,9660]
atom_expr [9654,9679]
===
match
---
dictorsetmaker [8807,8893]
dictorsetmaker [8826,8912]
===
match
---
name: parse [7282,7287]
name: parse [7301,7306]
===
match
---
comparison [9737,9781]
comparison [9756,9800]
===
match
---
name: es_task_handler [11715,11730]
name: es_task_handler [11734,11749]
===
match
---
arglist [8107,8158]
arglist [8126,8177]
===
match
---
atom_expr [2196,2216]
atom_expr [2196,2216]
===
match
---
operator: = [13264,13265]
operator: = [13283,13284]
===
match
---
name: id [8154,8156]
name: id [8173,8175]
===
match
---
atom_expr [4539,4706]
atom_expr [4539,4706]
===
match
---
name: self [5560,5564]
name: self [5579,5583]
===
match
---
expr_stmt [13082,13117]
expr_stmt [13101,13136]
===
match
---
trailer [10660,10676]
trailer [10679,10695]
===
match
---
name: doc_type [6208,6216]
name: doc_type [6227,6235]
===
match
---
trailer [3195,3200]
trailer [3195,3200]
===
match
---
name: self [2362,2366]
name: self [2362,2366]
===
match
---
trailer [13845,13848]
trailer [13864,13867]
===
match
---
name: self [11499,11503]
name: self [11518,11522]
===
match
---
argument [6232,6236]
argument [6251,6255]
===
match
---
operator: = [2900,2901]
operator: = [2900,2901]
===
match
---
name: delete [7409,7415]
name: delete [7428,7434]
===
match
---
trailer [15614,15891]
trailer [15633,15910]
===
match
---
name: es_conf [3918,3925]
name: es_conf [3918,3925]
===
match
---
trailer [12425,12430]
trailer [12444,12449]
===
match
---
name: elasticsearch [3313,3326]
name: elasticsearch [3313,3326]
===
match
---
atom_expr [2546,2559]
atom_expr [2546,2559]
===
match
---
trailer [13198,13268]
trailer [13217,13287]
===
match
---
funcdef [5875,6719]
funcdef [5894,6738]
===
match
---
trailer [4236,4245]
trailer [4236,4245]
===
match
---
assert_stmt [6942,6984]
assert_stmt [6961,7003]
===
match
---
name: self [14150,14154]
name: self [14169,14173]
===
match
---
name: delete [8100,8106]
name: delete [8119,8125]
===
match
---
not_test [5316,5346]
not_test [5335,5365]
===
match
---
assert_stmt [4153,4174]
assert_stmt [4153,4174]
===
match
---
name: join [13599,13603]
name: join [13618,13622]
===
match
---
name: timezone [7945,7953]
name: timezone [7964,7972]
===
match
---
trailer [15834,15846]
trailer [15853,15865]
===
match
---
name: try_number [12491,12501]
name: try_number [12510,12520]
===
match
---
name: log_file [13740,13748]
name: log_file [13759,13767]
===
match
---
trailer [4911,4920]
trailer [4911,4920]
===
match
---
name: index_name [2512,2522]
name: index_name [2512,2522]
===
match
---
number: 0 [5827,5828]
number: 0 [5846,5847]
===
match
---
assert_stmt [5704,5741]
assert_stmt [5723,5760]
===
match
---
number: 1 [1552,1553]
number: 1 [1552,1553]
===
match
---
expr_stmt [10278,10320]
expr_stmt [10297,10339]
===
match
---
operator: = [2008,2009]
operator: = [2008,2009]
===
match
---
import_name [788,802]
import_name [788,802]
===
match
---
operator: - [9059,9060]
operator: - [9078,9079]
===
match
---
expr_stmt [10329,10369]
expr_stmt [10348,10388]
===
match
---
operator: , [14922,14923]
operator: , [14941,14942]
===
match
---
string: 'offset' [8238,8246]
string: 'offset' [8257,8265]
===
match
---
name: write_stdout [10350,10362]
name: write_stdout [10369,10381]
===
match
---
atom_expr [8371,8385]
atom_expr [8390,8404]
===
match
---
operator: , [15478,15479]
operator: , [15497,15498]
===
match
---
arglist [14429,14439]
arglist [14448,14458]
===
match
---
name: es_task_handler [15046,15061]
name: es_task_handler [15065,15080]
===
match
---
name: self [15769,15773]
name: self [15788,15792]
===
match
---
name: closed [13792,13798]
name: closed [13811,13817]
===
match
---
name: airflow [1242,1249]
name: airflow [1242,1249]
===
match
---
simple_stmt [15018,15121]
simple_stmt [15037,15140]
===
match
---
simple_stmt [7477,7556]
simple_stmt [7496,7575]
===
match
---
name: metadatas [8968,8977]
name: metadatas [8987,8996]
===
match
---
name: strip [12128,12133]
name: strip [12147,12152]
===
match
---
number: 0 [5379,5380]
number: 0 [5398,5399]
===
match
---
expr_stmt [2062,2352]
expr_stmt [2062,2352]
===
match
---
string: '2020-12-24 19:25:00,962' [10944,10969]
string: '2020-12-24 19:25:00,962' [10963,10988]
===
match
---
name: Formatter [11534,11543]
name: Formatter [11553,11562]
===
match
---
name: self [14804,14808]
name: self [14823,14827]
===
match
---
number: 0 [6975,6976]
number: 0 [6994,6995]
===
match
---
operator: == [5366,5368]
operator: == [5385,5387]
===
match
---
number: 0 [9092,9093]
number: 0 [9111,9112]
===
match
---
trailer [2066,2082]
trailer [2066,2082]
===
match
---
operator: , [6230,6231]
operator: , [6249,6250]
===
match
---
dictorsetmaker [8238,8301]
dictorsetmaker [8257,8320]
===
match
---
suite [10510,11479]
suite [10529,11498]
===
match
---
simple_stmt [13910,13939]
simple_stmt [13929,13958]
===
match
---
name: os [13186,13188]
name: os [13205,13207]
===
match
---
atom_expr [5681,5695]
atom_expr [5700,5714]
===
match
---
name: self [3793,3797]
name: self [3793,3797]
===
match
---
trailer [2200,2216]
trailer [2200,2216]
===
match
---
name: parameterized [15195,15208]
name: parameterized [15214,15227]
===
match
---
name: ts [6716,6718]
name: ts [6735,6737]
===
match
---
arglist [4608,4696]
arglist [4608,4696]
===
match
---
operator: - [4298,4299]
operator: - [4298,4299]
===
match
---
simple_stmt [6801,6861]
simple_stmt [6820,6880]
===
match
---
expr_stmt [2507,2537]
expr_stmt [2507,2537]
===
match
---
trailer [13052,13064]
trailer [13071,13083]
===
match
---
atom_expr [15906,15971]
atom_expr [15925,15990]
===
match
---
name: DAG_ID [2824,2830]
name: DAG_ID [2824,2830]
===
match
---
trailer [5633,5644]
trailer [5652,5663]
===
match
---
trailer [1928,1941]
trailer [1928,1941]
===
match
---
trailer [6184,6237]
trailer [6203,6256]
===
match
---
dictorsetmaker [2453,2486]
dictorsetmaker [2453,2486]
===
match
---
name: self [2507,2511]
name: self [2507,2511]
===
match
---
trailer [11714,11730]
trailer [11733,11749]
===
match
---
trailer [7281,7287]
trailer [7300,7306]
===
match
---
simple_stmt [8168,8313]
simple_stmt [8187,8332]
===
match
---
operator: , [2787,2788]
operator: , [2787,2788]
===
match
---
name: self [13531,13535]
name: self [13550,13554]
===
match
---
operator: = [15039,15040]
operator: = [15058,15059]
===
match
---
name: super [1665,1670]
name: super [1665,1670]
===
match
---
atom_expr [13841,13848]
atom_expr [13860,13867]
===
match
---
name: metadatas [7004,7013]
name: metadatas [7023,7032]
===
match
---
string: 'end_of_log' [5098,5110]
string: 'end_of_log' [5100,5112]
===
match
---
trailer [11812,11830]
trailer [11831,11849]
===
match
---
operator: , [6855,6856]
operator: , [6874,6875]
===
match
---
fstring_string: -2016_01_01T00_00_00_000000-1 [10864,10893]
fstring_string: -2016_01_01T00_00_00_000000-1 [10883,10912]
===
match
---
name: delete [6178,6184]
name: delete [6197,6203]
===
match
---
trailer [6689,6711]
trailer [6708,6730]
===
match
---
name: body [10761,10765]
name: body [10780,10784]
===
match
---
trailer [3192,3205]
trailer [3192,3205]
===
match
---
assert_stmt [5653,5695]
assert_stmt [5672,5714]
===
match
---
atom_expr [5041,5048]
atom_expr [5041,5048]
===
match
---
operator: , [5065,5066]
operator: , [5067,5068]
===
match
---
operator: , [15687,15688]
operator: , [15706,15707]
===
match
---
name: local_log_location [2128,2146]
name: local_log_location [2128,2146]
===
match
---
name: write_stdout [2269,2281]
name: write_stdout [2269,2281]
===
match
---
name: read [12973,12977]
name: read [12992,12996]
===
match
---
name: format [4588,4594]
name: format [4588,4594]
===
match
---
atom_expr [4104,4111]
atom_expr [4104,4111]
===
match
---
name: es_task_handler [5007,5022]
name: es_task_handler [5007,5022]
===
match
---
operator: , [8235,8236]
operator: , [8254,8255]
===
match
---
name: try_number [12898,12908]
name: try_number [12917,12927]
===
match
---
name: es_task_handler [10712,10727]
name: es_task_handler [10731,10746]
===
match
---
trailer [13748,13753]
trailer [13767,13772]
===
match
---
trailer [15092,15119]
trailer [15111,15138]
===
match
---
trailer [14883,14899]
trailer [14902,14918]
===
match
---
name: index_name [7427,7437]
name: index_name [7446,7456]
===
match
---
name: dag [3105,3108]
name: dag [3105,3108]
===
match
---
simple_stmt [12720,12762]
simple_stmt [12739,12781]
===
match
---
trailer [4333,4347]
trailer [4333,4347]
===
match
---
arglist [2960,3005]
arglist [2960,3005]
===
match
---
number: 0 [8602,8603]
number: 0 [8621,8622]
===
match
---
expr_stmt [1991,2053]
expr_stmt [1991,2053]
===
match
---
trailer [10093,10111]
trailer [10112,10130]
===
match
---
comparison [7273,7328]
comparison [7292,7347]
===
match
---
assert_stmt [9020,9062]
assert_stmt [9039,9081]
===
match
---
trailer [5688,5691]
trailer [5707,5710]
===
match
---
atom_expr [10793,10810]
atom_expr [10812,10829]
===
match
---
atom_expr [13910,13938]
atom_expr [13929,13957]
===
match
---
name: closed [12232,12238]
name: closed [12251,12257]
===
match
---
operator: == [4367,4369]
operator: == [4367,4369]
===
match
---
trailer [10711,10727]
trailer [10730,10746]
===
match
---
operator: , [15291,15292]
operator: , [15310,15311]
===
match
---
operator: = [12501,12502]
operator: = [12520,12521]
===
match
---
operator: = [12110,12111]
operator: = [12129,12130]
===
match
---
simple_stmt [12148,12196]
simple_stmt [12167,12215]
===
match
---
trailer [6569,6572]
trailer [6588,6591]
===
match
---
operator: , [2771,2772]
operator: , [2771,2772]
===
match
---
trailer [13936,13938]
trailer [13955,13957]
===
match
---
trailer [5378,5381]
trailer [5397,5400]
===
match
---
number: 1 [5693,5694]
number: 1 [5712,5713]
===
match
---
atom_expr [9841,9855]
atom_expr [9860,9874]
===
match
---
trailer [6523,6537]
trailer [6542,6556]
===
match
---
string: 'offset' [4069,4077]
string: 'offset' [4069,4077]
===
match
---
name: test_read_with_empty_metadata [6728,6757]
name: test_read_with_empty_metadata [6747,6776]
===
match
---
simple_stmt [4310,4348]
simple_stmt [4310,4348]
===
match
---
simple_stmt [2624,2703]
simple_stmt [2624,2703]
===
match
---
assert_stmt [5261,5299]
assert_stmt [5280,5318]
===
match
---
name: self [13224,13228]
name: self [13243,13247]
===
match
---
import_name [827,842]
import_name [827,842]
===
match
---
trailer [3104,3108]
trailer [3104,3108]
===
match
---
name: DummyOperator [1099,1112]
name: DummyOperator [1099,1112]
===
match
---
number: 0 [7014,7015]
number: 0 [7033,7034]
===
match
---
trailer [3050,3053]
trailer [3050,3053]
===
match
---
name: self [9334,9338]
name: self [9353,9357]
===
match
---
operator: = [11207,11208]
operator: = [11226,11227]
===
match
---
name: self [3163,3167]
name: self [3163,3167]
===
match
---
trailer [2268,2281]
trailer [2268,2281]
===
match
---
name: logs [7652,7656]
name: logs [7671,7675]
===
match
---
assert_stmt [7665,7702]
assert_stmt [7684,7721]
===
match
---
operator: = [1566,1567]
operator: = [1566,1567]
===
match
---
trailer [4382,4392]
trailer [4382,4392]
===
match
---
string: 'host' [2453,2459]
string: 'host' [2453,2459]
===
match
---
name: logs [8955,8959]
name: logs [8974,8978]
===
match
---
name: set_context [12334,12345]
name: set_context [12353,12364]
===
match
---
expr_stmt [1796,1869]
expr_stmt [1796,1869]
===
match
---
simple_stmt [12677,12712]
simple_stmt [12696,12731]
===
match
---
simple_stmt [2507,2538]
simple_stmt [2507,2538]
===
match
---
atom [8402,8404]
atom [8421,8423]
===
match
---
operator: = [1425,1426]
operator: = [1425,1426]
===
match
---
trailer [11155,11225]
trailer [11174,11244]
===
match
---
simple_stmt [1958,1983]
simple_stmt [1958,1983]
===
match
---
with_stmt [13568,13756]
with_stmt [13587,13775]
===
match
---
operator: , [14436,14437]
operator: , [14455,14456]
===
match
---
trailer [2511,2522]
trailer [2511,2522]
===
match
---
trailer [2719,2725]
trailer [2719,2725]
===
match
---
name: self [14531,14535]
name: self [14550,14554]
===
match
---
simple_stmt [6773,6793]
simple_stmt [6792,6812]
===
match
---
number: 0 [8549,8550]
number: 0 [8568,8569]
===
match
---
operator: == [16000,16002]
operator: == [16019,16021]
===
match
---
name: log [1150,1153]
name: log [1150,1153]
===
match
---
operator: = [2757,2758]
operator: = [2757,2758]
===
match
---
trailer [3409,3420]
trailer [3409,3420]
===
match
---
expr_stmt [3015,3037]
expr_stmt [3015,3037]
===
match
---
name: doc_type [8130,8138]
name: doc_type [8149,8157]
===
match
---
assert_stmt [9821,9855]
assert_stmt [9840,9874]
===
match
---
simple_stmt [1517,1555]
simple_stmt [1517,1555]
===
match
---
param [13017,13021]
param [13036,13040]
===
match
---
comparison [14095,14134]
comparison [14114,14153]
===
match
---
name: self [8670,8674]
name: self [8689,8693]
===
match
---
trailer [5190,5201]
trailer [5209,5220]
===
match
---
name: es_task_handler [14536,14551]
name: es_task_handler [14555,14570]
===
match
---
name: os [12423,12425]
name: os [12442,12444]
===
match
---
name: self [14629,14633]
name: self [14648,14652]
===
match
---
number: 0 [5297,5298]
number: 0 [5316,5317]
===
match
---
atom_expr [12960,12980]
atom_expr [12979,12999]
===
match
---
trailer [10727,10739]
trailer [10746,10758]
===
match
---
trailer [11288,11291]
trailer [11307,11310]
===
match
---
atom_expr [4660,4696]
atom_expr [4660,4696]
===
match
---
name: args [9678,9682]
name: args [9697,9701]
===
match
---
name: open [12405,12409]
name: open [12424,12428]
===
match
---
atom [4068,4133]
atom [4068,4133]
===
match
---
name: formatter [11641,11650]
name: formatter [11660,11669]
===
match
---
name: self [12548,12552]
name: self [12567,12571]
===
match
---
trailer [4107,4111]
trailer [4107,4111]
===
match
---
operator: , [8894,8895]
operator: , [8913,8914]
===
match
---
name: test_message [9032,9044]
name: test_message [9051,9063]
===
match
---
name: self [11188,11192]
name: self [11207,11211]
===
match
---
name: formatter [10689,10698]
name: formatter [10708,10717]
===
match
---
trailer [11612,11628]
trailer [11631,11647]
===
match
---
suite [5507,5870]
suite [5526,5889]
===
match
---
simple_stmt [1063,1113]
simple_stmt [1063,1113]
===
match
---
number: 1 [5144,5145]
number: 1 [5163,5164]
===
match
---
argument [12491,12503]
argument [12510,12522]
===
match
---
trailer [9333,9372]
trailer [9352,9391]
===
match
---
name: self [4881,4885]
name: self [4881,4885]
===
match
---
name: ti [8230,8232]
name: ti [8249,8251]
===
match
---
operator: , [15547,15548]
operator: , [15566,15567]
===
match
---
comparison [12955,12980]
comparison [12974,12999]
===
match
---
name: log_file [11866,11874]
name: log_file [11885,11893]
===
match
---
trailer [5296,5299]
trailer [5315,5318]
===
match
---
name: es_task_handler [12775,12790]
name: es_task_handler [12794,12809]
===
match
---
number: 1 [5050,5051]
number: 1 [5050,5051]
===
match
---
name: self [13017,13021]
name: self [13036,13040]
===
match
---
operator: = [7421,7422]
operator: = [7440,7441]
===
match
---
atom [7533,7554]
atom [7552,7573]
===
match
---
name: self [2160,2164]
name: self [2160,2164]
===
match
---
name: ti [12758,12760]
name: ti [12777,12779]
===
match
---
name: log_id_template [3764,3779]
name: log_id_template [3764,3779]
===
match
---
trailer [9778,9781]
trailer [9797,9800]
===
match
---
dotted_name [1207,1220]
dotted_name [1207,1220]
===
match
---
operator: , [7528,7529]
operator: , [7547,7548]
===
match
---
param [5501,5505]
param [5520,5524]
===
match
---
simple_stmt [1744,1788]
simple_stmt [1744,1788]
===
match
---
name: filename_template [2165,2182]
name: filename_template [2165,2182]
===
match
---
operator: , [6250,6251]
operator: , [6269,6270]
===
match
---
name: set_context [13053,13064]
name: set_context [13072,13083]
===
match
---
operator: , [11012,11013]
operator: , [11031,11032]
===
match
---
operator: == [9661,9663]
operator: == [9680,9682]
===
match
---
string: 'end_of_log' [6360,6372]
string: 'end_of_log' [6379,6391]
===
match
---
name: doc_type [7439,7447]
name: doc_type [7458,7466]
===
match
---
name: self [3686,3690]
name: self [3686,3690]
===
match
---
atom_expr [13858,13901]
atom_expr [13877,13920]
===
match
---
parameters [8669,8675]
parameters [8688,8694]
===
match
---
name: self [5905,5909]
name: self [5924,5928]
===
match
---
string: 'asctime' [10933,10942]
string: 'asctime' [10952,10961]
===
match
---
trailer [4969,4973]
trailer [4969,4973]
===
match
---
name: handler [13501,13508]
name: handler [13520,13527]
===
match
---
trailer [13253,13267]
trailer [13272,13286]
===
match
---
trailer [3099,3115]
trailer [3099,3115]
===
match
---
assert_stmt [6655,6718]
assert_stmt [6674,6737]
===
match
---
name: close [12791,12796]
name: close [12810,12815]
===
match
---
comparison [9214,9269]
comparison [9233,9288]
===
match
---
comparison [7945,8000]
comparison [7964,8019]
===
match
---
name: self [12346,12350]
name: self [12365,12369]
===
match
---
number: 1 [14049,14050]
number: 1 [14068,14069]
===
match
---
operator: = [14552,14553]
operator: = [14571,14572]
===
match
---
trailer [15959,15970]
trailer [15978,15989]
===
match
---
trailer [13500,13508]
trailer [13519,13527]
===
match
---
trailer [14037,14051]
trailer [14056,14070]
===
match
---
name: local_log_location [13609,13627]
name: local_log_location [13628,13646]
===
match
---
name: end_of_log_mark [2235,2250]
name: end_of_log_mark [2235,2250]
===
match
---
name: self [3046,3050]
name: self [3046,3050]
===
match
---
parameters [3955,3961]
parameters [3955,3961]
===
match
---
atom_expr [5292,5299]
atom_expr [5311,5318]
===
match
---
name: self [12286,12290]
name: self [12305,12309]
===
match
---
trailer [1882,1898]
trailer [1882,1898]
===
match
---
number: 1 [8921,8922]
number: 1 [8940,8941]
===
match
---
number: 0 [6521,6522]
number: 0 [6540,6541]
===
match
---
dotted_name [1023,1037]
dotted_name [1023,1037]
===
match
---
operator: = [11161,11162]
operator: = [11180,11181]
===
match
---
operator: = [4015,4016]
operator: = [4015,4016]
===
match
---
number: 0 [3206,3207]
number: 0 [3206,3207]
===
match
---
name: logs [6415,6419]
name: logs [6434,6438]
===
match
---
with_item [13573,13695]
with_item [13592,13714]
===
match
---
trailer [6289,6390]
trailer [6308,6409]
===
match
---
name: ti [11698,11700]
name: ti [11717,11719]
===
match
---
name: es_task_handler [13131,13146]
name: es_task_handler [13150,13165]
===
match
---
name: self [4861,4865]
name: self [4861,4865]
===
match
---
simple_stmt [8394,8414]
simple_stmt [8413,8433]
===
match
---
number: 0 [11470,11471]
number: 0 [11489,11490]
===
match
---
simple_stmt [3015,3038]
simple_stmt [3015,3038]
===
match
---
string: 'dag_for_testing_file_task_handler' [1427,1462]
string: 'dag_for_testing_file_task_handler' [1427,1462]
===
match
---
atom_expr [10329,10362]
atom_expr [10348,10381]
===
match
---
trailer [11166,11177]
trailer [11185,11196]
===
match
---
name: self [2230,2234]
name: self [2230,2234]
===
match
---
name: formatter [10547,10556]
name: formatter [10566,10575]
===
match
---
trailer [2892,2928]
trailer [2892,2928]
===
match
---
name: str [8273,8276]
name: str [8292,8295]
===
match
---
suite [15563,16007]
suite [15582,16026]
===
match
---
name: another_body [4765,4777]
name: another_body [4765,4777]
===
match
---
name: metadatas [9566,9575]
name: metadatas [9585,9594]
===
match
---
trailer [4379,4382]
trailer [4379,4382]
===
match
---
assert_stmt [14449,14481]
assert_stmt [14468,14500]
===
match
---
name: unittest [1394,1402]
name: unittest [1394,1402]
===
match
---
trailer [9603,9615]
trailer [9622,9634]
===
match
---
dictorsetmaker [6316,6379]
dictorsetmaker [6335,6398]
===
match
---
name: models [1031,1037]
name: models [1031,1037]
===
match
---
name: len [5149,5152]
name: len [5168,5171]
===
match
---
atom [2636,2702]
atom [2636,2702]
===
match
---
trailer [13372,13379]
trailer [13391,13398]
===
match
---
assert_stmt [9730,9781]
assert_stmt [9749,9800]
===
match
---
name: now [6787,6790]
name: now [6806,6809]
===
match
---
assert_stmt [5750,5786]
assert_stmt [5769,5805]
===
match
---
param [4507,4511]
param [4507,4511]
===
match
---
name: logs [4984,4988]
name: logs [4984,4988]
===
match
---
trailer [8591,8627]
trailer [8610,8646]
===
match
---
expr_stmt [3971,3990]
expr_stmt [3971,3990]
===
match
---
atom_expr [13168,13278]
atom_expr [13187,13297]
===
match
---
name: es_task_handler [13776,13791]
name: es_task_handler [13795,13810]
===
match
---
name: log_id [14870,14876]
name: log_id [14889,14895]
===
match
---
param [3956,3960]
param [3956,3960]
===
match
---
simple_stmt [12204,12239]
simple_stmt [12223,12258]
===
match
---
operator: > [7996,7997]
operator: > [8015,8016]
===
match
---
name: str [4104,4107]
name: str [4104,4107]
===
match
---
arglist [9604,9614]
arglist [9623,9633]
===
match
---
assert_stmt [7564,7585]
assert_stmt [7583,7604]
===
match
---
operator: == [9045,9047]
operator: == [9064,9066]
===
match
---
name: index [7416,7421]
name: index [7435,7440]
===
match
---
name: es_task_handler [12725,12740]
name: es_task_handler [12744,12759]
===
match
---
trailer [8096,8099]
trailer [8115,8118]
===
match
---
name: ts [5920,5922]
name: ts [5939,5941]
===
match
---
trailer [13188,13193]
trailer [13207,13212]
===
match
---
name: open [12812,12816]
name: open [12831,12835]
===
match
---
number: 0 [4079,4080]
number: 0 [4079,4080]
===
match
---
name: join [12431,12435]
name: join [12450,12454]
===
match
---
operator: = [11243,11244]
operator: = [11262,11263]
===
match
---
arglist [9334,9371]
arglist [9353,9390]
===
match
---
name: mock_execute [9489,9501]
name: mock_execute [9508,9520]
===
match
---
name: es_task_handler [6269,6284]
name: es_task_handler [6288,6303]
===
match
---
name: formatter [10299,10308]
name: formatter [10318,10327]
===
match
---
name: self [12770,12774]
name: self [12789,12793]
===
match
---
assert_stmt [5137,5158]
assert_stmt [5156,5177]
===
match
---
operator: } [5117,5118]
operator: } [5136,5137]
===
match
---
name: json_format [15805,15816]
name: json_format [15824,15835]
===
match
---
name: self [3956,3960]
name: self [3956,3960]
===
match
---
atom_expr [4017,4143]
atom_expr [4017,4143]
===
match
---
atom_expr [4237,4244]
atom_expr [4237,4244]
===
match
---
name: metadatas [5817,5826]
name: metadatas [5836,5845]
===
match
---
name: json_format [10399,10410]
name: json_format [10418,10429]
===
match
---
name: set_context [10037,10048]
name: set_context [10056,10067]
===
match
---
name: self [3284,3288]
name: self [3284,3288]
===
match
---
simple_stmt [4183,4218]
simple_stmt [4183,4218]
===
match
---
expr_stmt [9678,9717]
expr_stmt [9697,9736]
===
match
---
name: self [12868,12872]
name: self [12887,12891]
===
match
---
trailer [14127,14132]
trailer [14146,14151]
===
match
---
name: self [13352,13356]
name: self [13371,13375]
===
match
---
name: ti [6308,6310]
name: ti [6327,6329]
===
match
---
atom [5053,5118]
atom [5053,5137]
===
match
---
comparison [5802,5869]
comparison [5821,5888]
===
match
---
simple_stmt [979,1018]
simple_stmt [979,1018]
===
match
---
name: ti [10464,10466]
name: ti [10483,10485]
===
match
---
name: es [2717,2719]
name: es [2717,2719]
===
match
---
atom_expr [3888,3904]
atom_expr [3888,3904]
===
match
---
name: self [12720,12724]
name: self [12739,12743]
===
match
---
simple_stmt [13808,13850]
simple_stmt [13827,13869]
===
match
---
trailer [6786,6790]
trailer [6805,6809]
===
match
---
trailer [10298,10308]
trailer [10317,10327]
===
match
---
atom_expr [14773,14790]
atom_expr [14792,14809]
===
match
---
name: logs [5292,5296]
name: logs [5311,5315]
===
match
---
operator: , [11291,11292]
operator: , [11310,11311]
===
match
---
name: self [1689,1693]
name: self [1689,1693]
===
match
---
name: es_task_handler [10661,10676]
name: es_task_handler [10680,10695]
===
match
---
simple_stmt [4765,4853]
simple_stmt [4765,4853]
===
match
---
comparison [8577,8633]
comparison [8596,8652]
===
match
---
name: path [11773,11777]
name: path [11792,11796]
===
match
---
name: read [12585,12589]
name: read [12604,12608]
===
match
---
atom_expr [5002,5128]
atom_expr [5002,5147]
===
match
---
string: 'last_log_timestamp' [8605,8625]
string: 'last_log_timestamp' [8624,8644]
===
match
---
string: 'offset' [9189,9197]
string: 'offset' [9208,9216]
===
match
---
name: test_close_closed [12644,12661]
name: test_close_closed [12663,12680]
===
match
---
name: frontend [15860,15868]
name: frontend [15879,15887]
===
match
---
name: ElasticsearchTaskHandler [2085,2109]
name: ElasticsearchTaskHandler [2085,2109]
===
match
---
name: self [15735,15739]
name: self [15754,15758]
===
match
---
assert_stmt [5210,5252]
assert_stmt [5229,5271]
===
match
---
name: local_log_location [13988,14006]
name: local_log_location [14007,14025]
===
match
---
name: logs [8409,8413]
name: logs [8428,8432]
===
match
---
trailer [9133,9136]
trailer [9152,9155]
===
match
---
operator: , [15534,15535]
operator: , [15553,15554]
===
match
---
name: body [2773,2777]
name: body [2773,2777]
===
match
---
name: len [4233,4236]
name: len [4233,4236]
===
match
---
atom_expr [3759,3779]
atom_expr [3759,3779]
===
match
---
trailer [5434,5456]
trailer [5453,5475]
===
match
---
trailer [7959,7995]
trailer [7978,8014]
===
match
---
name: metadatas [5764,5773]
name: metadatas [5783,5792]
===
match
---
trailer [4270,4283]
trailer [4270,4283]
===
match
---
simple_stmt [1991,2054]
simple_stmt [1991,2054]
===
match
---
assert_stmt [4259,4301]
assert_stmt [4259,4301]
===
match
---
assert_stmt [6472,6491]
assert_stmt [6491,6510]
===
match
---
atom_expr [10426,10467]
atom_expr [10445,10486]
===
match
---
operator: == [6408,6410]
operator: == [6427,6429]
===
match
---
operator: = [9576,9577]
operator: = [9595,9596]
===
match
---
atom_expr [7288,7322]
atom_expr [7307,7341]
===
match
---
name: self [12461,12465]
name: self [12480,12484]
===
match
---
number: 0 [6570,6571]
number: 0 [6589,6590]
===
match
---
operator: = [6776,6777]
operator: = [6795,6796]
===
match
---
suite [3962,4464]
suite [3962,4464]
===
match
---
atom_expr [2804,2812]
atom_expr [2804,2812]
===
match
---
trailer [15705,15721]
trailer [15724,15740]
===
match
---
name: id [11222,11224]
name: id [11241,11243]
===
match
---
param [9296,9300]
param [9315,9319]
===
match
---
trailer [6686,6689]
trailer [6705,6708]
===
match
---
name: self [2624,2628]
name: self [2624,2628]
===
match
---
trailer [6572,6582]
trailer [6591,6601]
===
match
---
name: log_id_template [1801,1816]
name: log_id_template [1801,1816]
===
match
---
name: es_task_handler [7500,7515]
name: es_task_handler [7519,7534]
===
match
---
number: 1 [7571,7572]
number: 1 [7590,7591]
===
match
---
name: body [11203,11207]
name: body [11222,11226]
===
match
---
name: len [8951,8954]
name: len [8970,8973]
===
match
---
funcdef [15500,16007]
funcdef [15519,16026]
===
match
---
name: log_file [12112,12120]
name: log_file [12131,12139]
===
match
---
trailer [5177,5183]
trailer [5196,5202]
===
match
---
trailer [7287,7323]
trailer [7306,7342]
===
match
---
simple_stmt [5355,5392]
simple_stmt [5374,5411]
===
match
---
operator: , [2969,2970]
operator: , [2969,2970]
===
match
---
atom_expr [5660,5677]
atom_expr [5679,5696]
===
match
---
name: logs [6440,6444]
name: logs [6459,6463]
===
match
---
trailer [13146,13152]
trailer [13165,13171]
===
match
---
trailer [14170,14177]
trailer [14189,14196]
===
match
---
name: doc_type [6222,6230]
name: doc_type [6241,6249]
===
match
---
trailer [6354,6358]
trailer [6373,6377]
===
match
---
comparison [9828,9855]
comparison [9847,9874]
===
match
---
simple_stmt [10278,10321]
simple_stmt [10297,10340]
===
match
---
assert_stmt [10066,10111]
assert_stmt [10085,10130]
===
match
---
atom_expr [2160,2182]
atom_expr [2160,2182]
===
match
---
trailer [5829,5851]
trailer [5848,5870]
===
match
---
name: conf [3405,3409]
name: conf [3405,3409]
===
match
---
name: local_log_location [3691,3709]
name: local_log_location [3691,3709]
===
match
---
string: '{{ ti.dag_id }}-{{ ti.task_id }}-{{ ts }}-{{ try_number }}' [14665,14725]
string: '{{ ti.dag_id }}-{{ ti.task_id }}-{{ ts }}-{{ try_number }}' [14684,14744]
===
match
---
name: str [11332,11335]
name: str [11351,11354]
===
match
---
number: 1 [4065,4066]
number: 1 [4065,4066]
===
match
---
trailer [5776,5786]
trailer [5795,5805]
===
match
---
trailer [12133,12135]
trailer [12152,12154]
===
match
---
name: path [13973,13977]
name: path [13992,13996]
===
match
---
operator: , [2311,2312]
operator: , [2311,2312]
===
match
---
comp_op [12569,12575]
comp_op [12588,12594]
===
match
---
name: elasticsearch [1136,1149]
name: elasticsearch [1136,1149]
===
match
---
name: es_task_handler [13915,13930]
name: es_task_handler [13934,13949]
===
match
---
atom_expr [10756,10765]
atom_expr [10775,10784]
===
match
---
name: self [15800,15804]
name: self [15819,15823]
===
match
---
name: len [9828,9831]
name: len [9847,9850]
===
match
---
trailer [13036,13052]
trailer [13055,13071]
===
match
---
atom_expr [15084,15119]
atom_expr [15103,15138]
===
match
---
name: index_name [2737,2747]
name: index_name [2737,2747]
===
match
---
name: close [13894,13899]
name: close [13913,13918]
===
match
---
param [15549,15561]
param [15568,15580]
===
match
---
arglist [4056,4133]
arglist [4056,4133]
===
match
---
testlist_star_expr [9678,9690]
testlist_star_expr [9697,9709]
===
match
---
name: id [7463,7465]
name: id [7482,7484]
===
match
---
name: logs [9879,9883]
name: logs [9898,9902]
===
match
---
import_from [1202,1236]
import_from [1202,1236]
===
match
---
assert_stmt [7100,7136]
assert_stmt [7119,7155]
===
match
---
atom_expr [8358,8367]
atom_expr [8377,8386]
===
match
---
trailer [8062,8071]
trailer [8081,8090]
===
match
---
arglist [2819,2862]
arglist [2819,2862]
===
match
---
with_item [12405,12527]
with_item [12424,12546]
===
match
---
simple_stmt [9730,9782]
simple_stmt [9749,9801]
===
match
---
assert_stmt [4226,4250]
assert_stmt [4226,4250]
===
match
---
simple_stmt [9821,9856]
simple_stmt [9840,9875]
===
match
---
trailer [9055,9058]
trailer [9074,9077]
===
match
---
trailer [4291,4294]
trailer [4291,4294]
===
match
---
atom_expr [12286,12297]
atom_expr [12305,12316]
===
match
---
operator: , [15816,15817]
operator: , [15835,15836]
===
match
---
operator: , [13222,13223]
operator: , [13241,13242]
===
match
---
name: closed [13373,13379]
name: closed [13392,13398]
===
match
---
comparison [15987,16006]
comparison [16006,16025]
===
match
---
trailer [5431,5434]
trailer [5450,5453]
===
match
---
trailer [8751,8756]
trailer [8770,8775]
===
match
---
atom_expr [11752,11862]
atom_expr [11771,11881]
===
match
---
name: len [8994,8997]
name: len [9013,9016]
===
match
---
expr_stmt [7477,7555]
expr_stmt [7496,7574]
===
match
---
trailer [1402,1411]
trailer [1402,1411]
===
match
---
trailer [7452,7461]
trailer [7471,7480]
===
match
---
trailer [6307,6310]
trailer [6326,6329]
===
match
---
trailer [12127,12133]
trailer [12146,12152]
===
match
---
comparison [12155,12195]
comparison [12174,12214]
===
match
---
name: self [13858,13862]
name: self [13877,13881]
===
match
---
name: filename_template [3728,3745]
name: filename_template [3728,3745]
===
match
---
trailer [5664,5677]
trailer [5683,5696]
===
match
---
number: 12 [15116,15118]
number: 12 [15135,15137]
===
match
---
name: self [10756,10760]
name: self [10775,10779]
===
match
---
name: airflow [1118,1125]
name: airflow [1118,1125]
===
match
---
name: test_message [4271,4283]
name: test_message [4271,4283]
===
match
---
operator: , [15846,15847]
operator: , [15865,15866]
===
match
---
name: es [4866,4868]
name: es [4866,4868]
===
match
---
atom_expr [11142,11225]
atom_expr [11161,11244]
===
match
---
trailer [11249,11265]
trailer [11268,11284]
===
match
---
trailer [13840,13849]
trailer [13859,13868]
===
match
---
number: 0 [9913,9914]
number: 0 [9932,9933]
===
match
---
atom_expr [13186,13268]
atom_expr [13205,13287]
===
match
---
name: len [9803,9806]
name: len [9822,9825]
===
match
---
number: 10 [15108,15110]
number: 10 [15127,15129]
===
match
---
trailer [2681,2688]
trailer [2681,2688]
===
match
---
operator: , [2747,2748]
operator: , [2747,2748]
===
match
---
trailer [10797,10810]
trailer [10816,10829]
===
match
---
operator: = [14048,14049]
operator: = [14067,14068]
===
match
---
name: parameterized [943,956]
name: parameterized [943,956]
===
match
---
simple_stmt [827,843]
simple_stmt [827,843]
===
match
---
operator: = [1475,1476]
operator: = [1475,1476]
===
match
---
string: 'offset' [5382,5390]
string: 'offset' [5401,5409]
===
match
---
trailer [14578,14861]
trailer [14597,14880]
===
match
---
atom_expr [1665,1680]
atom_expr [1665,1680]
===
match
---
parameters [5500,5506]
parameters [5519,5525]
===
match
---
param [12662,12666]
param [12681,12685]
===
match
---
trailer [4435,4457]
trailer [4435,4457]
===
match
---
simple_stmt [5580,5602]
simple_stmt [5599,5621]
===
match
---
operator: = [4778,4779]
operator: = [4778,4779]
===
match
---
name: self [13771,13775]
name: self [13790,13794]
===
match
---
trailer [2580,2593]
trailer [2580,2593]
===
match
---
trailer [11270,11371]
trailer [11289,11390]
===
match
---
operator: , [6327,6328]
operator: , [6346,6347]
===
match
---
trailer [5006,5022]
trailer [5006,5022]
===
match
---
atom_expr [8048,8082]
atom_expr [8067,8101]
===
match
---
simple_stmt [9938,9975]
simple_stmt [9957,9994]
===
match
---
name: self [14879,14883]
name: self [14898,14902]
===
match
---
name: close [12384,12389]
name: close [12403,12408]
===
match
---
name: logs [8930,8934]
name: logs [8949,8953]
===
match
---
operator: = [13516,13517]
operator: = [13535,13536]
===
match
---
expr_stmt [2872,2928]
expr_stmt [2872,2928]
===
match
---
name: closed [12628,12634]
name: closed [12647,12653]
===
match
---
trailer [11664,11680]
trailer [11683,11699]
===
match
---
atom_expr [10559,10647]
atom_expr [10578,10666]
===
match
---
trailer [13608,13627]
trailer [13627,13646]
===
match
---
name: ts [11336,11338]
name: ts [11355,11357]
===
match
---
trailer [15341,15351]
trailer [15360,15370]
===
match
---
atom [6479,6483]
atom [6498,6502]
===
match
---
comparison [9945,9974]
comparison [9964,9993]
===
match
---
trailer [9961,9964]
trailer [9980,9983]
===
match
---
trailer [7300,7322]
trailer [7319,7341]
===
match
---
name: another_test_message [4792,4812]
name: another_test_message [4792,4812]
===
match
---
atom_expr [13480,13515]
atom_expr [13499,13534]
===
match
---
name: len [6436,6439]
name: len [6455,6458]
===
match
---
param [10001,10005]
param [10020,10024]
===
match
---
name: es_task_handler [13087,13102]
name: es_task_handler [13106,13121]
===
match
---
trailer [12832,12837]
trailer [12851,12856]
===
match
---
decorated [15194,16007]
decorated [15213,16026]
===
match
---
name: urllib [874,880]
name: urllib [874,880]
===
match
---
trailer [13987,14006]
trailer [14006,14025]
===
match
---
import_from [938,977]
import_from [938,977]
===
match
---
atom_expr [12830,12912]
atom_expr [12849,12931]
===
match
---
name: timezone [4408,4416]
name: timezone [4408,4416]
===
match
---
atom_expr [13983,14006]
atom_expr [14002,14025]
===
match
---
parameters [11498,11504]
parameters [11517,11523]
===
match
---
name: metadatas [8719,8728]
name: metadatas [8738,8747]
===
match
---
dictorsetmaker [10782,11073]
dictorsetmaker [10801,11092]
===
match
---
trailer [11129,11132]
trailer [11148,11151]
===
match
---
param [10504,10508]
param [10523,10527]
===
match
---
trailer [12367,12383]
trailer [12386,12402]
===
match
---
name: handler [13879,13886]
name: handler [13898,13905]
===
match
---
name: self [15530,15534]
name: self [15549,15553]
===
match
---
name: self [10793,10797]
name: self [10812,10816]
===
match
---
operator: , [11039,11040]
operator: , [11058,11059]
===
match
---
string: "elasticsearch_configs" [3421,3444]
string: "elasticsearch_configs" [3421,3444]
===
match
---
name: read [6285,6289]
name: read [6304,6308]
===
match
---
parameters [8027,8033]
parameters [8046,8052]
===
match
---
atom_expr [7422,7437]
atom_expr [7441,7456]
===
match
---
string: 'end_of_log' [7534,7546]
string: 'end_of_log' [7553,7565]
===
match
---
trailer [3420,3445]
trailer [3420,3445]
===
match
---
atom_expr [14429,14436]
atom_expr [14448,14455]
===
match
---
atom_expr [3062,3075]
atom_expr [3062,3075]
===
match
---
assert_stmt [9117,9153]
assert_stmt [9136,9172]
===
match
---
string: 'test_index' [2525,2537]
string: 'test_index' [2525,2537]
===
match
---
name: self [2986,2990]
name: self [2986,2990]
===
match
---
name: another_body [4927,4939]
name: another_body [4927,4939]
===
match
---
funcdef [12244,12635]
funcdef [12263,12654]
===
match
---
name: another_test_message [5268,5288]
name: another_test_message [5287,5307]
===
match
---
name: elasticsearch [908,921]
name: elasticsearch [908,921]
===
match
---
trailer [12584,12589]
trailer [12603,12608]
===
match
---
trailer [8551,8561]
trailer [8570,8580]
===
match
---
name: test_read_with_match_phrase_query [4473,4506]
name: test_read_with_match_phrase_query [4473,4506]
===
match
---
trailer [15942,15971]
trailer [15961,15990]
===
match
---
atom [9871,9875]
atom [9890,9894]
===
match
---
trailer [10382,10398]
trailer [10401,10417]
===
match
---
name: expand [15209,15215]
name: expand [15228,15234]
===
match
---
trailer [9354,9358]
trailer [9373,9377]
===
match
---
name: es_task_handler [10431,10446]
name: es_task_handler [10450,10465]
===
match
---
string: 'end_of_log' [5728,5740]
string: 'end_of_log' [5747,5759]
===
match
---
operator: } [2486,2487]
operator: } [2486,2487]
===
match
---
number: 0 [9779,9780]
number: 0 [9798,9799]
===
match
---
name: ts [9267,9269]
name: ts [9286,9288]
===
match
---
name: ts [10519,10521]
name: ts [10538,10540]
===
match
---
atom_expr [9604,9611]
atom_expr [9623,9630]
===
match
---
trailer [13862,13878]
trailer [13881,13897]
===
match
---
trailer [7688,7702]
trailer [7707,7721]
===
match
---
name: metadatas [5422,5431]
name: metadatas [5441,5450]
===
match
---
trailer [14397,14413]
trailer [14416,14432]
===
match
---
atom_expr [14739,14759]
atom_expr [14758,14778]
===
match
---
simple_stmt [6993,7031]
simple_stmt [7012,7050]
===
match
---
name: ts [7998,8000]
name: ts [8017,8019]
===
match
---
name: self [8770,8774]
name: self [8789,8793]
===
match
---
name: len [6906,6909]
name: len [6925,6928]
===
match
---
atom [8237,8302]
atom [8256,8321]
===
match
---
assert_stmt [8570,8633]
assert_stmt [8589,8652]
===
match
---
number: 7 [15099,15100]
number: 7 [15118,15119]
===
match
---
trailer [11830,11837]
trailer [11849,11856]
===
match
---
expr_stmt [4984,5128]
expr_stmt [4984,5147]
===
match
---
trailer [13651,13658]
trailer [13670,13677]
===
match
---
operator: == [15165,15167]
operator: == [15184,15186]
===
match
---
name: self [13126,13130]
name: self [13145,13149]
===
match
---
trailer [8702,8704]
trailer [8721,8723]
===
match
---
arglist [15342,15350]
arglist [15361,15369]
===
match
---
operator: , [3813,3814]
operator: , [3813,3814]
===
match
---
simple_stmt [11608,11651]
simple_stmt [11627,11670]
===
match
---
name: log_line [12101,12109]
name: log_line [12120,12128]
===
match
---
trailer [2725,2794]
trailer [2725,2794]
===
match
---
operator: > [9265,9266]
operator: > [9284,9285]
===
match
---
operator: { [3471,3472]
operator: { [3471,3472]
===
match
---
operator: , [10919,10920]
operator: , [10938,10939]
===
match
---
trailer [5221,5234]
trailer [5240,5253]
===
match
---
param [8670,8674]
param [8689,8693]
===
match
---
trailer [9185,9188]
trailer [9204,9207]
===
match
---
import_from [1320,1356]
import_from [1320,1356]
===
match
---
atom_expr [14393,14440]
atom_expr [14412,14459]
===
match
---
name: ts [8685,8687]
name: ts [8704,8706]
===
match
---
simple_stmt [10656,10699]
simple_stmt [10675,10718]
===
match
---
trailer [9912,9915]
trailer [9931,9934]
===
match
---
operator: , [4896,4897]
operator: , [4896,4897]
===
match
---
string: 'offset' [6316,6324]
string: 'offset' [6335,6343]
===
match
---
simple_stmt [1796,1870]
simple_stmt [1796,1870]
===
match
---
name: read [4038,4042]
name: read [4038,4042]
===
match
---
trailer [13535,13551]
trailer [13554,13570]
===
match
---
parameters [5904,5910]
parameters [5923,5929]
===
match
---
argument [2726,2747]
argument [2726,2747]
===
match
---
name: now [8699,8702]
name: now [8718,8721]
===
match
---
name: end_of_log_mark [13721,13736]
name: end_of_log_mark [13740,13755]
===
match
---
name: logs [8998,9002]
name: logs [9017,9021]
===
match
---
atom_expr [9774,9781]
atom_expr [9793,9800]
===
match
---
operator: , [7481,7482]
operator: , [7500,7501]
===
match
---
trailer [1542,1554]
trailer [1542,1554]
===
match
---
trailer [12490,12504]
trailer [12509,12523]
===
match
---
name: json_fields [14839,14850]
name: json_fields [14858,14869]
===
match
---
name: logs [7580,7584]
name: logs [7599,7603]
===
match
---
operator: = [11524,11525]
operator: = [11543,11544]
===
match
---
name: dag [2915,2918]
name: dag [2915,2918]
===
match
---
name: metadatas [9229,9238]
name: metadatas [9248,9257]
===
match
---
name: self [8113,8117]
name: self [8132,8136]
===
match
---
name: len [8358,8361]
name: len [8377,8380]
===
match
---
trailer [5691,5695]
trailer [5710,5714]
===
match
---
expr_stmt [13480,13522]
expr_stmt [13499,13541]
===
match
---
trailer [11782,11852]
trailer [11801,11871]
===
match
---
name: self [12313,12317]
name: self [12332,12336]
===
match
---
atom_expr [14834,14850]
atom_expr [14853,14869]
===
match
---
simple_stmt [13764,13799]
simple_stmt [13783,13818]
===
match
---
atom_expr [14531,14551]
atom_expr [14550,14570]
===
match
---
trailer [14919,14922]
trailer [14938,14941]
===
match
---
trailer [12181,12183]
trailer [12200,12202]
===
match
---
operator: { [6315,6316]
operator: { [6334,6335]
===
match
---
suite [13421,14178]
suite [13440,14197]
===
match
---
name: self [6264,6268]
name: self [6283,6287]
===
match
---
trailer [7579,7585]
trailer [7598,7604]
===
match
---
expr_stmt [9560,9615]
expr_stmt [9579,9634]
===
match
---
comparison [9798,9812]
comparison [9817,9831]
===
match
---
name: str [8842,8845]
name: str [8861,8864]
===
match
---
atom_expr [14879,14926]
atom_expr [14898,14945]
===
match
---
number: 0 [9134,9135]
number: 0 [9153,9154]
===
match
---
name: addCleanup [3089,3099]
name: addCleanup [3089,3099]
===
match
---
name: airflow [1280,1287]
name: airflow [1280,1287]
===
match
---
trailer [5816,5852]
trailer [5835,5871]
===
match
---
operator: = [2777,2778]
operator: = [2777,2778]
===
match
---
atom_expr [3858,3874]
atom_expr [3858,3874]
===
match
---
atom_expr [13808,13849]
atom_expr [13827,13868]
===
match
---
dotted_name [1242,1261]
dotted_name [1242,1261]
===
match
---
name: elasticsearch [2372,2385]
name: elasticsearch [2372,2385]
===
match
---
param [14206,14210]
param [14225,14229]
===
match
---
name: self [14095,14099]
name: self [14114,14118]
===
match
---
param [8028,8032]
param [8047,8051]
===
match
---
suite [13696,13756]
suite [13715,13775]
===
match
---
simple_stmt [10016,10058]
simple_stmt [10035,10077]
===
match
---
atom_expr [5715,5741]
atom_expr [5734,5760]
===
match
---
suite [3381,3937]
suite [3381,3937]
===
match
---
atom_expr [13126,13154]
atom_expr [13145,13173]
===
match
---
suite [12277,12635]
suite [12296,12654]
===
match
---
string: 'last_log_timestamp' [4082,4102]
string: 'last_log_timestamp' [4082,4102]
===
match
---
name: es_task_handler [15906,15921]
name: es_task_handler [15925,15940]
===
match
---
atom_expr [14119,14134]
atom_expr [14138,14153]
===
match
---
name: len [6881,6884]
name: len [6900,6903]
===
match
---
number: 0 [4295,4296]
number: 0 [4295,4296]
===
match
---
atom_expr [9516,9543]
atom_expr [9535,9562]
===
match
---
argument [4922,4939]
argument [4922,4939]
===
match
---
name: metadatas [5369,5378]
name: metadatas [5388,5397]
===
match
---
name: write_stdout [15774,15786]
name: write_stdout [15793,15805]
===
match
---
atom_expr [13591,13673]
atom_expr [13610,13692]
===
match
---
param [5905,5909]
param [5924,5928]
===
match
---
operator: = [5923,5924]
operator: = [5942,5943]
===
match
---
operator: { [4068,4069]
operator: { [4068,4069]
===
match
---
name: self [7521,7525]
name: self [7540,7544]
===
match
---
name: self [14834,14838]
name: self [14853,14857]
===
match
---
atom_expr [2919,2927]
atom_expr [2919,2927]
===
match
---
atom_expr [1689,1712]
atom_expr [1689,1712]
===
match
---
name: call_count [9650,9660]
name: call_count [9669,9679]
===
match
---
dictorsetmaker [5054,5117]
dictorsetmaker [5054,5136]
===
match
---
simple_stmt [6899,6934]
simple_stmt [6918,6953]
===
match
---
name: ti [5565,5567]
name: ti [5584,5586]
===
match
---
operator: = [14391,14392]
operator: = [14410,14411]
===
match
---
operator: , [4650,4651]
operator: , [4650,4651]
===
match
---
name: log_id_template [15706,15721]
name: log_id_template [15725,15740]
===
match
---
string: 'download_logs' [9137,9152]
string: 'download_logs' [9156,9171]
===
match
---
atom_expr [15830,15846]
atom_expr [15849,15865]
===
match
---
atom_expr [2325,2341]
atom_expr [2325,2341]
===
match
---
suite [14212,14968]
suite [14231,14987]
===
match
---
atom_expr [9027,9044]
atom_expr [9046,9063]
===
match
---
import_from [869,899]
import_from [869,899]
===
match
---
name: self [13808,13812]
name: self [13827,13831]
===
match
---
simple_stmt [7100,7137]
simple_stmt [7119,7156]
===
match
---
trailer [5620,5626]
trailer [5639,5645]
===
match
---
trailer [8845,8849]
trailer [8864,8868]
===
match
---
operator: = [10363,10364]
operator: = [10382,10383]
===
match
---
atom_expr [5217,5234]
atom_expr [5236,5253]
===
match
---
atom_expr [4321,4347]
atom_expr [4321,4347]
===
match
---
name: es_task_handler [13863,13878]
name: es_task_handler [13882,13897]
===
match
---
atom_expr [1924,1941]
atom_expr [1924,1941]
===
match
---
atom_expr [12607,12634]
atom_expr [12626,12653]
===
match
---
name: metadatas [7288,7297]
name: metadatas [7307,7316]
===
match
---
string: 'end_of_log' [4113,4125]
string: 'end_of_log' [4113,4125]
===
match
---
trailer [6909,6915]
trailer [6928,6934]
===
match
---
name: metadatas [4990,4999]
name: metadatas [4990,4999]
===
match
---
name: es_task_handler [8191,8206]
name: es_task_handler [8210,8225]
===
match
---
number: 2016 [1543,1547]
number: 2016 [1543,1547]
===
match
---
string: 'last_log_timestamp' [6329,6349]
string: 'last_log_timestamp' [6348,6368]
===
match
---
simple_stmt [4356,4393]
simple_stmt [4356,4393]
===
match
---
name: es [6175,6177]
name: es [6194,6196]
===
match
---
trailer [6977,6980]
trailer [6996,6999]
===
match
---
operator: == [13313,13315]
operator: == [13332,13334]
===
match
---
name: mock [864,868]
name: mock [864,868]
===
match
---
trailer [13086,13102]
trailer [13105,13121]
===
match
---
operator: == [9800,9802]
operator: == [9819,9821]
===
match
---
trailer [12611,12627]
trailer [12630,12646]
===
match
---
simple_stmt [12770,12799]
simple_stmt [12789,12818]
===
match
---
simple_stmt [813,827]
simple_stmt [813,827]
===
match
---
name: ti [3051,3053]
name: ti [3051,3053]
===
match
---
simple_stmt [4259,4302]
simple_stmt [4259,4302]
===
match
---
trailer [1995,2007]
trailer [1995,2007]
===
match
---
string: 'taskinstance.py' [10995,11012]
string: 'taskinstance.py' [11014,11031]
===
match
---
number: 1 [4160,4161]
number: 1 [4160,4161]
===
match
---
operator: = [12908,12909]
operator: = [12927,12928]
===
match
---
trailer [14154,14170]
trailer [14173,14189]
===
match
---
operator: = [15904,15905]
operator: = [15923,15924]
===
match
---
name: log_file [13687,13695]
name: log_file [13706,13714]
===
match
---
operator: = [8138,8139]
operator: = [8157,8158]
===
match
---
trailer [4874,4946]
trailer [4874,4946]
===
match
---
operator: , [5520,5521]
operator: , [5539,5540]
===
match
---
simple_stmt [6655,6719]
simple_stmt [6674,6738]
===
match
---
parameters [10168,10174]
parameters [10187,10193]
===
match
---
name: format [14031,14037]
name: format [14050,14056]
===
match
---
name: self [5041,5045]
name: self [5041,5045]
===
match
---
parameters [3250,3256]
parameters [3250,3256]
===
match
---
operator: == [14472,14474]
operator: == [14491,14493]
===
match
---
simple_stmt [3046,3076]
simple_stmt [3046,3076]
===
match
---
trailer [4297,4301]
trailer [4297,4301]
===
match
---
operator: == [4246,4248]
operator: == [4246,4248]
===
match
---
argument [4608,4650]
argument [4608,4650]
===
match
---
operator: = [10194,10195]
operator: = [10213,10214]
===
match
---
trailer [14535,14551]
trailer [14554,14570]
===
match
---
name: metadatas [7786,7795]
name: metadatas [7805,7814]
===
match
---
string: 'localhost' [2461,2472]
string: 'localhost' [2461,2472]
===
match
---
trailer [1670,1672]
trailer [1670,1672]
===
match
---
name: logs [5681,5685]
name: logs [5700,5704]
===
match
---
operator: } [11360,11361]
operator: } [11379,11380]
===
match
---
atom_expr [13716,13736]
atom_expr [13735,13755]
===
match
---
trailer [10855,10863]
trailer [10874,10882]
===
match
---
name: parse [4417,4422]
name: parse [4417,4422]
===
match
---
expr_stmt [5516,5571]
expr_stmt [5535,5590]
===
match
---
name: es_task_handler [12216,12231]
name: es_task_handler [12235,12250]
===
match
---
operator: = [8079,8080]
operator: = [8098,8099]
===
match
---
comparison [8401,8413]
comparison [8420,8432]
===
match
---
name: elasticmock [1345,1356]
name: elasticmock [1345,1356]
===
match
---
atom_expr [6411,6420]
atom_expr [6430,6439]
===
match
---
import_name [803,812]
import_name [803,812]
===
match
---
simple_stmt [5167,5202]
simple_stmt [5186,5221]
===
match
---
assert_stmt [12948,12980]
assert_stmt [12967,12999]
===
match
---
name: end_of_log_mark [14100,14115]
name: end_of_log_mark [14119,14134]
===
match
---
trailer [2736,2747]
trailer [2736,2747]
===
match
---
trailer [9094,9108]
trailer [9113,9127]
===
match
---
assert_stmt [5610,5644]
assert_stmt [5629,5663]
===
match
---
funcdef [13385,14178]
funcdef [13404,14197]
===
match
---
simple_stmt [12313,12355]
simple_stmt [12332,12374]
===
match
---
simple_stmt [8685,8705]
simple_stmt [8704,8724]
===
match
---
import_from [1237,1274]
import_from [1237,1274]
===
match
---
name: metadatas [4423,4432]
name: metadatas [4423,4432]
===
match
---
comparison [7779,7808]
comparison [7798,7827]
===
match
---
string: 'dag_for_testing_file_task_handler-' [14253,14289]
string: 'dag_for_testing_file_task_handler-' [14272,14308]
===
match
---
string: 'end_of_log' [7689,7701]
string: 'end_of_log' [7708,7720]
===
match
---
name: logs [5596,5600]
name: logs [5615,5619]
===
match
---
name: DAG_ID [1571,1577]
name: DAG_ID [1571,1577]
===
match
---
name: logs [3999,4003]
name: logs [3999,4003]
===
match
---
atom_expr [13970,14052]
atom_expr [13989,14071]
===
match
---
assert_stmt [7266,7328]
assert_stmt [7285,7347]
===
match
---
name: logs [6885,6889]
name: logs [6904,6908]
===
match
---
trailer [10446,10458]
trailer [10465,10477]
===
match
---
atom_expr [4423,4457]
atom_expr [4423,4457]
===
match
---
trailer [13102,13110]
trailer [13121,13129]
===
match
---
name: doc_type [7453,7461]
name: doc_type [7472,7480]
===
match
---
atom_expr [5238,5252]
atom_expr [5257,5271]
===
match
---
operator: = [12298,12299]
operator: = [12317,12318]
===
match
---
operator: = [1713,1714]
operator: = [1713,1714]
===
match
---
name: utils [1250,1255]
name: utils [1250,1255]
===
match
---
name: self [15041,15045]
name: self [15060,15064]
===
match
---
name: self [2677,2681]
name: self [2677,2681]
===
match
---
atom_expr [12423,12505]
atom_expr [12442,12524]
===
match
---
name: len [7601,7604]
name: len [7620,7623]
===
match
---
operator: , [8872,8873]
operator: , [8891,8892]
===
match
---
simple_stmt [4226,4251]
simple_stmt [4226,4251]
===
match
---
atom_expr [5187,5201]
atom_expr [5206,5220]
===
match
---
string: 'last_log_timestamp' [8820,8840]
string: 'last_log_timestamp' [8839,8859]
===
match
---
string: 'offset' [7799,7807]
string: 'offset' [7818,7826]
===
match
---
string: '{task_id}-{dag_id}-2016-01-01T00:00:00+00:00-1' [4539,4587]
string: '{task_id}-{dag_id}-2016-01-01T00:00:00+00:00-1' [4539,4587]
===
match
---
parameters [13016,13022]
parameters [13035,13041]
===
match
---
operator: == [5627,5629]
operator: == [5646,5648]
===
match
---
fstring_expr [10850,10864]
fstring_expr [10869,10883]
===
match
---
name: self [13629,13633]
name: self [13648,13652]
===
match
---
trailer [7969,7972]
trailer [7988,7991]
===
match
---
arglist [14592,14851]
arglist [14611,14870]
===
match
---
suite [12668,12981]
suite [12687,13000]
===
match
---
trailer [10566,10576]
trailer [10585,10595]
===
match
---
name: now [3985,3988]
name: now [3985,3988]
===
match
---
atom_expr [12548,12568]
atom_expr [12567,12587]
===
match
---
arglist [2123,2342]
arglist [2123,2342]
===
match
---
atom_expr [8225,8232]
atom_expr [8244,8251]
===
match
---
trailer [9598,9603]
trailer [9617,9622]
===
match
---
trailer [7515,7520]
trailer [7534,7539]
===
match
---
string: 'message' [10782,10791]
string: 'message' [10801,10810]
===
match
---
trailer [4193,4199]
trailer [4193,4199]
===
match
---
name: self [13430,13434]
name: self [13449,13453]
===
match
---
name: state [1256,1261]
name: state [1256,1261]
===
match
---
operator: = [2842,2843]
operator: = [2842,2843]
===
match
---
comparison [7644,7656]
comparison [7663,7675]
===
match
---
simple_stmt [6170,6238]
simple_stmt [6189,6257]
===
match
---
parameters [10000,10006]
parameters [10019,10025]
===
match
---
atom_expr [7273,7323]
atom_expr [7292,7342]
===
match
---
simple_stmt [2062,2353]
simple_stmt [2062,2353]
===
match
---
expr_stmt [11235,11371]
expr_stmt [11254,11390]
===
match
---
name: log_id [14384,14390]
name: log_id [14403,14409]
===
match
---
assert_stmt [8394,8413]
assert_stmt [8413,8432]
===
match
---
trailer [13484,13500]
trailer [13503,13519]
===
match
---
name: self [4056,4060]
name: self [4056,4060]
===
match
---
name: metadatas [9082,9091]
name: metadatas [9101,9110]
===
match
---
name: self [11608,11612]
name: self [11627,11631]
===
match
---
string: 'task_for_testing_file_log_handler' [1477,1512]
string: 'task_for_testing_file_log_handler' [1477,1512]
===
match
---
assert_stmt [15129,15188]
assert_stmt [15148,15207]
===
match
---
operator: , [15110,15111]
operator: , [15129,15130]
===
match
---
name: self [3888,3892]
name: self [3888,3892]
===
match
---
name: ti [12291,12293]
name: ti [12310,12312]
===
match
---
name: dummy [1086,1091]
name: dummy [1086,1091]
===
match
---
comparison [6906,6933]
comparison [6925,6952]
===
match
---
name: LOG_ID [1559,1565]
name: LOG_ID [1559,1565]
===
match
---
operator: , [14725,14726]
operator: , [14744,14745]
===
match
---
name: test_get_external_log_url [15504,15529]
name: test_get_external_log_url [15523,15548]
===
match
---
operator: = [6216,6217]
operator: = [6235,6236]
===
match
---
name: pendulum [4961,4969]
name: pendulum [4961,4969]
===
match
---
name: utils [1215,1220]
name: utils [1215,1220]
===
match
---
number: 1 [11849,11850]
number: 1 [11868,11869]
===
match
---
name: log_id [14475,14481]
name: log_id [14494,14500]
===
match
---
number: 1 [8157,8158]
number: 1 [8176,8177]
===
match
---
operator: , [3709,3710]
operator: , [3709,3710]
===
match
---
assert_stmt [6869,6890]
assert_stmt [6888,6909]
===
match
---
factor [4298,4300]
factor [4298,4300]
===
match
---
name: self [3375,3379]
name: self [3375,3379]
===
match
---
number: 0 [9962,9963]
number: 0 [9981,9982]
===
match
---
name: self [6191,6195]
name: self [6210,6214]
===
match
---
operator: , [4080,4081]
operator: , [4080,4081]
===
match
---
operator: == [8961,8963]
operator: == [8980,8982]
===
match
---
trailer [13658,13672]
trailer [13677,13691]
===
match
---
trailer [2823,2830]
trailer [2823,2830]
===
match
---
fstring_expr [1570,1578]
fstring_expr [1570,1578]
===
match
---
name: metadatas [6677,6686]
name: metadatas [6696,6705]
===
match
---
funcdef [9275,9975]
funcdef [9294,9994]
===
match
---
name: ti [2942,2944]
name: ti [2942,2944]
===
match
---
name: es_task_handler [11250,11265]
name: es_task_handler [11269,11284]
===
match
---
string: 'end_of_log' [8874,8886]
string: 'end_of_log' [8893,8905]
===
match
---
argument [2832,2862]
argument [2832,2862]
===
match
---
name: log_file [13320,13328]
name: log_file [13339,13347]
===
match
---
trailer [12125,12127]
trailer [12144,12146]
===
match
---
atom_expr [15769,15786]
atom_expr [15788,15805]
===
match
---
atom_expr [2947,3006]
atom_expr [2947,3006]
===
match
---
trailer [13775,13791]
trailer [13794,13810]
===
match
---
name: set_context [11113,11124]
name: set_context [11132,11143]
===
match
---
suite [12528,12592]
suite [12547,12611]
===
match
---
name: self [13199,13203]
name: self [13218,13222]
===
match
---
name: now [4970,4973]
name: now [4970,4973]
===
match
---
operator: } [6379,6380]
operator: } [6398,6399]
===
match
---
simple_stmt [5261,5300]
simple_stmt [5280,5319]
===
match
---
trailer [9228,9264]
trailer [9247,9283]
===
match
---
name: self [3827,3831]
name: self [3827,3831]
===
match
---
trailer [3690,3709]
trailer [3690,3709]
===
match
---
name: self [6170,6174]
name: self [6189,6193]
===
match
---
name: logs [4169,4173]
name: logs [4169,4173]
===
match
---
param [15530,15535]
param [15549,15554]
===
match
---
assert_stmt [14143,14177]
assert_stmt [14162,14196]
===
match
---
trailer [10333,10349]
trailer [10352,10368]
===
match
---
funcdef [8006,8634]
funcdef [8025,8653]
===
match
---
number: 1 [12502,12503]
number: 1 [12521,12522]
===
match
---
atom_expr [1991,2007]
atom_expr [1991,2007]
===
match
---
number: 0 [9053,9054]
number: 0 [9072,9073]
===
match
---
name: str [6351,6354]
name: str [6370,6373]
===
match
---
trailer [12552,12568]
trailer [12571,12587]
===
match
---
operator: = [11639,11640]
operator: = [11658,11659]
===
match
---
trailer [12175,12181]
trailer [12194,12200]
===
match
---
trailer [2923,2927]
trailer [2923,2927]
===
match
---
expr_stmt [12101,12135]
expr_stmt [12120,12154]
===
match
---
trailer [13930,13936]
trailer [13949,13955]
===
match
---
name: self [13604,13608]
name: self [13623,13627]
===
match
---
suite [11505,12239]
suite [11524,12258]
===
match
---
operator: = [3034,3035]
operator: = [3034,3035]
===
match
---
fstring_expr [10836,10849]
fstring_expr [10855,10868]
===
match
---
name: len [8371,8374]
name: len [8390,8393]
===
match
---
name: datetime [1310,1318]
name: datetime [1310,1318]
===
match
---
argument [3210,3228]
argument [3210,3228]
===
match
---
string: '1' [9169,9172]
string: '1' [9188,9191]
===
match
---
name: task [2965,2969]
name: task [2965,2969]
===
match
---
argument [11219,11224]
argument [11238,11243]
===
match
---
name: len [5174,5177]
name: len [5193,5196]
===
match
---
name: es_task_handler [9339,9354]
name: es_task_handler [9358,9373]
===
match
---
name: len [9841,9844]
name: len [9860,9863]
===
match
---
operator: , [6805,6806]
operator: , [6824,6825]
===
match
---
operator: > [4459,4460]
operator: > [4459,4460]
===
match
---
atom_expr [9124,9153]
atom_expr [9143,9172]
===
match
---
name: now [5934,5937]
name: now [5953,5956]
===
match
---
name: self [2648,2652]
name: self [2648,2652]
===
match
---
name: es_task_handler [15572,15587]
name: es_task_handler [15591,15606]
===
match
---
name: self [13082,13086]
name: self [13101,13105]
===
match
---
name: dag [2809,2812]
name: dag [2809,2812]
===
match
---
number: 851 [11036,11039]
number: 851 [11055,11058]
===
match
---
trailer [6790,6792]
trailer [6809,6811]
===
match
---
dotted_name [984,1005]
dotted_name [984,1005]
===
match
---
name: log_file [12964,12972]
name: log_file [12983,12991]
===
match
---
trailer [13720,13736]
trailer [13739,13755]
===
match
---
comparison [5407,5462]
comparison [5426,5481]
===
match
---
trailer [2399,2498]
trailer [2399,2498]
===
match
---
name: self [9604,9608]
name: self [9623,9627]
===
match
---
atom_expr [5560,5567]
atom_expr [5579,5586]
===
match
---
trailer [14777,14790]
trailer [14796,14809]
===
match
---
atom_expr [7521,7528]
atom_expr [7540,7547]
===
match
---
name: self [15952,15956]
name: self [15971,15975]
===
match
---
operator: = [3223,3224]
operator: = [3223,3224]
===
match
---
atom_expr [12313,12354]
atom_expr [12332,12373]
===
match
---
trailer [7953,7959]
trailer [7972,7978]
===
match
---
name: index [11156,11161]
name: index [11175,11180]
===
match
---
name: self [3084,3088]
name: self [3084,3088]
===
match
---
comparison [8994,9011]
comparison [9013,9030]
===
match
---
simple_stmt [12541,12592]
simple_stmt [12560,12611]
===
match
---
simple_stmt [10707,10747]
simple_stmt [10726,10766]
===
match
---
name: log_file [12519,12527]
name: log_file [12538,12546]
===
match
---
name: clean_execution_date [15168,15188]
name: clean_execution_date [15187,15207]
===
match
---
atom_expr [3827,3844]
atom_expr [3827,3844]
===
match
---
classdef [1359,16007]
classdef [1359,16026]
===
match
---
atom_expr [3686,3709]
atom_expr [3686,3709]
===
match
---
number: 1 [9613,9614]
number: 1 [9632,9633]
===
match
---
name: self [15665,15669]
name: self [15684,15688]
===
match
---
name: elasticmock [1326,1337]
name: elasticmock [1326,1337]
===
match
---
trailer [2905,2913]
trailer [2905,2913]
===
match
---
trailer [9136,9153]
trailer [9155,9172]
===
match
---
simple_stmt [11235,11372]
simple_stmt [11254,11391]
===
match
---
name: es_task_handler [2067,2082]
name: es_task_handler [2067,2082]
===
match
---
atom_expr [2819,2830]
atom_expr [2819,2830]
===
match
---
name: self [2937,2941]
name: self [2937,2941]
===
match
---
operator: = [2945,2946]
operator: = [2945,2946]
===
match
---
string: 'localhost:5601/{log_id}' [15266,15291]
string: 'localhost:5601/{log_id}' [15285,15310]
===
match
---
trailer [2808,2812]
trailer [2808,2812]
===
match
---
simple_stmt [13709,13756]
simple_stmt [13728,13775]
===
match
---
comparison [4363,4392]
comparison [4363,4392]
===
match
---
name: logging [795,802]
name: logging [795,802]
===
match
---
trailer [4432,4435]
trailer [4432,4435]
===
match
---
name: set_context [13451,13462]
name: set_context [13470,13481]
===
match
---
operator: } [11082,11083]
operator: } [11101,11102]
===
match
---
expr_stmt [8685,8704]
expr_stmt [8704,8723]
===
match
---
comparison [6479,6491]
comparison [6498,6510]
===
match
---
string: 'log_id' [4814,4822]
string: 'log_id' [4814,4822]
===
match
---
name: parse [881,886]
name: parse [881,886]
===
match
---
name: logs [6487,6491]
name: logs [6506,6510]
===
match
---
operator: > [7324,7325]
operator: > [7343,7344]
===
match
---
name: now [10533,10536]
name: now [10552,10555]
===
match
---
simple_stmt [7594,7629]
simple_stmt [7613,7648]
===
match
---
operator: == [7611,7613]
operator: == [7630,7632]
===
match
---
name: handler [13103,13110]
name: handler [13122,13129]
===
match
---
trailer [3162,3229]
trailer [3162,3229]
===
match
---
name: local_log_location [12441,12459]
name: local_log_location [12460,12478]
===
match
---
operator: = [3469,3470]
operator: = [3469,3470]
===
match
---
name: conf [1013,1017]
name: conf [1013,1017]
===
match
---
assert_stmt [14935,14967]
assert_stmt [14954,14986]
===
match
---
name: es_task_handler [10383,10398]
name: es_task_handler [10402,10417]
===
match
---
parameters [10503,10509]
parameters [10522,10528]
===
match
---
trailer [4865,4868]
trailer [4865,4868]
===
match
---
number: 1 [2792,2793]
number: 1 [2792,2793]
===
match
---
operator: , [8128,8129]
operator: , [8147,8148]
===
match
---
operator: == [5184,5186]
operator: == [5203,5205]
===
match
---
trailer [14030,14037]
trailer [14049,14056]
===
match
---
simple_stmt [4956,4976]
simple_stmt [4956,4976]
===
match
---
name: self [5002,5006]
name: self [5002,5006]
===
match
---
name: ElasticsearchTaskHandler [15590,15614]
name: ElasticsearchTaskHandler [15609,15633]
===
match
---
simple_stmt [2546,2568]
simple_stmt [2546,2568]
===
match
---
funcdef [9980,10112]
funcdef [9999,10131]
===
match
---
number: 1 [6312,6313]
number: 1 [6331,6332]
===
match
---
atom_expr [2815,2863]
atom_expr [2815,2863]
===
match
---
number: 1 [7466,7467]
number: 1 [7485,7486]
===
match
---
operator: = [2450,2451]
operator: = [2450,2451]
===
match
---
operator: { [11296,11297]
operator: { [11315,11316]
===
match
---
name: self [10073,10077]
name: self [10092,10096]
===
match
---
simple_stmt [922,938]
simple_stmt [922,938]
===
match
---
simple_stmt [13126,13155]
simple_stmt [13145,13174]
===
match
---
operator: } [6858,6859]
operator: } [6877,6878]
===
match
---
atom_expr [1534,1554]
atom_expr [1534,1554]
===
match
---
simple_stmt [14143,14178]
simple_stmt [14162,14197]
===
match
---
atom [6857,6859]
atom [6876,6878]
===
match
---
name: quote [894,899]
name: quote [894,899]
===
match
---
atom_expr [13320,13335]
atom_expr [13339,13354]
===
match
---
trailer [13064,13073]
trailer [13083,13092]
===
match
---
operator: == [8923,8925]
operator: == [8942,8944]
===
match
---
trailer [5242,5245]
trailer [5261,5264]
===
match
---
expr_stmt [8043,8082]
expr_stmt [8062,8101]
===
match
---
name: logging [10196,10203]
name: logging [10215,10222]
===
match
---
name: logs [8168,8172]
name: logs [8187,8191]
===
match
---
trailer [7685,7688]
trailer [7704,7707]
===
match
---
assert_stmt [13304,13336]
assert_stmt [13323,13355]
===
match
---
atom_expr [1394,1411]
atom_expr [1394,1411]
===
match
---
trailer [5559,5571]
trailer [5578,5590]
===
match
---
number: 0 [6978,6979]
number: 0 [6997,6998]
===
match
---
name: test_close [11488,11498]
name: test_close [11507,11517]
===
match
---
atom_expr [5925,5939]
atom_expr [5944,5958]
===
match
---
name: raw [12294,12297]
name: raw [12313,12316]
===
match
---
name: es_task_handler [6824,6839]
name: es_task_handler [6843,6858]
===
match
---
operator: - [6981,6982]
operator: - [7000,7001]
===
match
---
atom_expr [2648,2665]
atom_expr [2648,2665]
===
match
---
operator: = [2918,2919]
operator: = [2918,2919]
===
match
---
operator: , [15100,15101]
operator: , [15119,15120]
===
match
---
name: logs [7605,7609]
name: logs [7624,7628]
===
match
---
name: mark_end_on_close [10094,10111]
name: mark_end_on_close [10113,10130]
===
match
---
number: 1 [9664,9665]
number: 1 [9683,9684]
===
match
---
operator: , [11177,11178]
operator: , [11196,11197]
===
match
---
dictorsetmaker [7534,7553]
dictorsetmaker [7553,7572]
===
match
---
trailer [15326,15352]
trailer [15345,15371]
===
match
---
name: ti [14434,14436]
name: ti [14453,14455]
===
match
---
name: unittest [834,842]
name: unittest [834,842]
===
match
---
number: 1 [9798,9799]
number: 1 [9817,9818]
===
match
---
atom_expr [9693,9717]
atom_expr [9712,9736]
===
match
---
number: 1 [2700,2701]
number: 1 [2700,2701]
===
match
---
name: logs [5238,5242]
name: logs [5257,5261]
===
match
---
atom [10768,11083]
atom [10787,11102]
===
match
---
operator: { [8806,8807]
operator: { [8825,8826]
===
match
---
argument [7439,7461]
argument [7458,7480]
===
match
---
name: doc_type [11179,11187]
name: doc_type [11198,11206]
===
match
---
name: filename_template [14013,14030]
name: filename_template [14032,14049]
===
match
---
atom_expr [9082,9108]
atom_expr [9101,9127]
===
match
---
with_stmt [11747,12196]
with_stmt [11766,12215]
===
match
---
simple_stmt [9678,9718]
simple_stmt [9697,9737]
===
match
---
string: '1' [5362,5365]
string: '1' [5381,5384]
===
match
---
name: task_id [2893,2900]
name: task_id [2893,2900]
===
match
---
atom [11296,11361]
atom [11315,11380]
===
match
---
name: test_read_raises [9279,9295]
name: test_read_raises [9298,9314]
===
match
---
name: similar_log_id [4824,4838]
name: similar_log_id [4824,4838]
===
match
---
trailer [3186,3192]
trailer [3186,3192]
===
match
---
param [6758,6762]
param [6777,6781]
===
match
---
operator: = [8184,8185]
operator: = [8203,8204]
===
match
---
arglist [3686,3926]
arglist [3686,3926]
===
match
---
name: _render_log_id [14414,14428]
name: _render_log_id [14433,14447]
===
match
---
param [3134,3138]
param [3134,3138]
===
match
---
name: filename_template [12466,12483]
name: filename_template [12485,12502]
===
match
---
name: self [6949,6953]
name: self [6968,6972]
===
match
---
testlist_star_expr [9560,9575]
testlist_star_expr [9579,9594]
===
match
---
name: test_close_with_no_stream [13389,13414]
name: test_close_with_no_stream [13408,13433]
===
match
---
trailer [6953,6966]
trailer [6972,6985]
===
match
---
operator: == [8330,8332]
operator: == [8349,8351]
===
match
---
expr_stmt [2546,2567]
expr_stmt [2546,2567]
===
match
---
name: ts [7326,7328]
name: ts [7345,7347]
===
match
---
operator: , [15651,15652]
operator: , [15670,15671]
===
match
---
testlist_comp [15265,15479]
testlist_comp [15284,15498]
===
match
---
name: doc_type [4898,4906]
name: doc_type [4898,4906]
===
match
---
operator: == [6446,6448]
operator: == [6465,6467]
===
match
---
operator: = [1942,1943]
operator: = [1942,1943]
===
match
---
expr_stmt [2576,2615]
expr_stmt [2576,2615]
===
match
---
trailer [14633,14651]
trailer [14652,14670]
===
match
---
trailer [13557,13559]
trailer [13576,13578]
===
match
---
operator: , [11308,11309]
operator: , [11327,11328]
===
match
---
operator: , [11806,11807]
operator: , [11825,11826]
===
match
---
operator: , [2472,2473]
operator: , [2472,2473]
===
match
---
operator: , [3874,3875]
operator: , [3874,3875]
===
match
---
operator: , [14006,14007]
operator: , [14025,14026]
===
match
---
simple_stmt [7564,7586]
simple_stmt [7583,7605]
===
match
---
trailer [13828,13840]
trailer [13847,13859]
===
match
---
name: minutes [8072,8079]
name: minutes [8091,8098]
===
match
---
trailer [7297,7300]
trailer [7316,7319]
===
match
---
trailer [12847,12866]
trailer [12866,12885]
===
match
---
simple_stmt [4153,4175]
simple_stmt [4153,4175]
===
match
---
name: ti [12351,12353]
name: ti [12370,12372]
===
match
---
name: timezone [1294,1302]
name: timezone [1294,1302]
===
match
---
arglist [15943,15970]
arglist [15962,15989]
===
match
---
trailer [3067,3075]
trailer [3067,3075]
===
match
---
name: format [11831,11837]
name: format [11850,11856]
===
match
---
atom_expr [10656,10686]
atom_expr [10675,10705]
===
match
---
name: metadatas [7676,7685]
name: metadatas [7695,7704]
===
match
---
operator: } [4132,4133]
operator: } [4132,4133]
===
match
---
operator: = [8156,8157]
operator: = [8175,8176]
===
match
---
expr_stmt [5920,5939]
expr_stmt [5939,5958]
===
match
---
atom [6480,6482]
atom [6499,6501]
===
match
---
comparison [8532,8561]
comparison [8551,8580]
===
match
---
name: path [12426,12430]
name: path [12445,12449]
===
match
---
trailer [13899,13901]
trailer [13918,13920]
===
match
---
name: id [2789,2791]
name: id [2789,2791]
===
match
---
atom_expr [12405,12515]
atom_expr [12424,12534]
===
match
---
operator: = [5000,5001]
operator: = [5000,5001]
===
match
---
operator: = [2634,2635]
operator: = [2634,2635]
===
match
---
trailer [11112,11124]
trailer [11131,11143]
===
match
---
name: providers [1126,1135]
name: providers [1126,1135]
===
match
---
name: close [13147,13152]
name: close [13166,13171]
===
match
---
name: self [3015,3019]
name: self [3015,3019]
===
match
---
expr_stmt [2362,2498]
expr_stmt [2362,2498]
===
match
---
name: es_task_handler [10078,10093]
name: es_task_handler [10097,10112]
===
match
---
expr_stmt [8168,8312]
expr_stmt [8187,8331]
===
match
---
number: 0 [9186,9187]
number: 0 [9205,9206]
===
match
---
comparison [4190,4217]
comparison [4190,4217]
===
match
---
name: self [5501,5505]
name: self [5520,5524]
===
match
---
number: 0 [5246,5247]
number: 0 [5265,5266]
===
match
---
name: logging [11526,11533]
name: logging [11545,11552]
===
match
---
string: 'offset' [5054,5062]
string: 'offset' [5054,5062]
===
match
---
name: filename_template [13634,13651]
name: filename_template [13653,13670]
===
match
---
name: len [6449,6452]
name: len [6468,6471]
===
match
---
name: pendulum [3976,3984]
name: pendulum [3976,3984]
===
match
---
expr_stmt [10707,10746]
expr_stmt [10726,10765]
===
match
---
atom_expr [15701,15721]
atom_expr [15720,15740]
===
match
---
factor [5692,5694]
factor [5711,5713]
===
match
---
name: es_task_handler [9583,9598]
name: es_task_handler [9602,9617]
===
match
---
trailer [9052,9055]
trailer [9071,9074]
===
match
---
atom_expr [14915,14922]
atom_expr [14934,14941]
===
match
---
assert_stmt [8351,8385]
assert_stmt [8370,8404]
===
match
---
operator: , [2665,2666]
operator: , [2665,2666]
===
match
---
name: DAG_ID [1418,1424]
name: DAG_ID [1418,1424]
===
match
---
name: ti [6850,6852]
name: ti [6869,6871]
===
match
---
operator: == [8368,8370]
operator: == [8387,8389]
===
match
---
name: read [6840,6844]
name: read [6859,6863]
===
match
---
name: self [11808,11812]
name: self [11827,11831]
===
match
---
name: self [2325,2329]
name: self [2325,2329]
===
match
---
name: url [15900,15903]
name: url [15919,15922]
===
match
---
name: isinstance [3273,3283]
name: isinstance [3273,3283]
===
match
---
trailer [13434,13450]
trailer [13453,13469]
===
match
---
name: body [2629,2633]
name: body [2629,2633]
===
match
---
name: RUNNING [3068,3075]
name: RUNNING [3068,3075]
===
match
---
with_stmt [13163,13337]
with_stmt [13182,13356]
===
match
---
name: self [11660,11664]
name: self [11679,11683]
===
match
---
trailer [13791,13798]
trailer [13810,13817]
===
match
---
name: len [13316,13319]
name: len [13335,13338]
===
match
---
atom_expr [8539,8561]
atom_expr [8558,8580]
===
match
---
name: self [11162,11166]
name: self [11181,11185]
===
match
---
name: metadatas [6923,6932]
name: metadatas [6942,6951]
===
match
---
trailer [8374,8385]
trailer [8393,8404]
===
match
---
atom_expr [13032,13073]
atom_expr [13051,13092]
===
match
---
name: _clean_execution_date [15062,15083]
name: _clean_execution_date [15081,15102]
===
match
---
trailer [11149,11155]
trailer [11168,11174]
===
match
---
name: DAG [1045,1048]
name: DAG [1045,1048]
===
match
---
assert_stmt [9791,9812]
assert_stmt [9810,9831]
===
match
---
comparison [8921,8935]
comparison [8940,8954]
===
match
---
simple_stmt [3999,4144]
simple_stmt [3999,4144]
===
match
---
atom_expr [11770,11852]
atom_expr [11789,11871]
===
match
---
number: 9200 [2482,2486]
number: 9200 [2482,2486]
===
match
---
number: 0 [5432,5433]
number: 0 [5451,5452]
===
match
---
operator: , [4838,4839]
operator: , [4838,4839]
===
match
---
name: airflow [1068,1075]
name: airflow [1068,1075]
===
match
---
name: sep [3201,3204]
name: sep [3201,3204]
===
match
---
operator: , [4066,4067]
operator: , [4066,4067]
===
match
---
trailer [5724,5727]
trailer [5743,5746]
===
match
---
operator: + [15319,15320]
operator: + [15338,15339]
===
match
---
atom_expr [6919,6933]
atom_expr [6938,6952]
===
match
---
funcdef [12640,12981]
funcdef [12659,13000]
===
match
---
operator: , [13627,13628]
operator: , [13646,13647]
===
match
---
trailer [9525,9543]
trailer [9544,9562]
===
match
---
string: 'INFO' [11066,11072]
string: 'INFO' [11085,11091]
===
match
---
funcdef [4469,5463]
funcdef [4469,5482]
===
match
---
expr_stmt [3046,3075]
expr_stmt [3046,3075]
===
match
---
name: self [5660,5664]
name: self [5679,5683]
===
match
---
operator: == [4162,4164]
operator: == [4162,4164]
===
match
---
with_item [9409,9471]
with_item [9428,9490]
===
match
---
name: similar_log_id [4522,4536]
name: similar_log_id [4522,4536]
===
match
---
operator: , [9564,9565]
operator: , [9583,9584]
===
match
---
name: State [1269,1274]
name: State [1269,1274]
===
match
---
atom_expr [6677,6711]
atom_expr [6696,6730]
===
match
---
simple_stmt [8525,8562]
simple_stmt [8544,8581]
===
match
---
arglist [5560,5570]
arglist [5579,5589]
===
match
---
name: self [15003,15007]
name: self [15022,15026]
===
match
---
trailer [8585,8591]
trailer [8604,8610]
===
match
---
atom_expr [15321,15352]
atom_expr [15340,15371]
===
match
---
name: self [15830,15834]
name: self [15849,15853]
===
match
---
trailer [12120,12125]
trailer [12139,12144]
===
match
---
comparison [13311,13336]
comparison [13330,13355]
===
match
---
number: 0 [7686,7687]
number: 0 [7705,7706]
===
match
---
name: json_fields [1996,2007]
name: json_fields [1996,2007]
===
match
---
string: 'offset' [8552,8560]
string: 'offset' [8571,8579]
===
match
---
comparison [5362,5391]
comparison [5381,5410]
===
match
---
atom_expr [12720,12761]
atom_expr [12739,12780]
===
match
---
param [15536,15548]
param [15555,15567]
===
match
---
name: self [11783,11787]
name: self [11802,11806]
===
match
---
name: json_format [14809,14820]
name: json_format [14828,14839]
===
match
---
atom_expr [12363,12391]
atom_expr [12382,12410]
===
match
---
atom_expr [5369,5391]
atom_expr [5388,5410]
===
match
---
atom_expr [5422,5456]
atom_expr [5441,5475]
===
match
---
atom_expr [14008,14051]
atom_expr [14027,14070]
===
match
---
name: test_read_nonexistent_log [5879,5904]
name: test_read_nonexistent_log [5898,5923]
===
match
---
operator: { [5053,5054]
operator: { [5053,5054]
===
match
---
trailer [8056,8060]
trailer [8075,8079]
===
match
---
atom_expr [5592,5601]
atom_expr [5611,5620]
===
match
---
parameters [12661,12667]
parameters [12680,12686]
===
match
---
operator: @ [1623,1624]
operator: @ [1623,1624]
===
match
---
name: self [7422,7426]
name: self [7441,7445]
===
match
---
name: str [5089,5092]
name: str [5091,5094]
===
match
---
name: rmtree [3156,3162]
name: rmtree [3156,3162]
===
match
---
name: doc_type [2763,2771]
name: doc_type [2763,2771]
===
match
---
trailer [6974,6977]
trailer [6993,6996]
===
match
---
trailer [3200,3204]
trailer [3200,3204]
===
match
---
name: self [1650,1654]
name: self [1650,1654]
===
match
---
trailer [11543,11599]
trailer [11562,11618]
===
match
---
atom_expr [4266,4283]
atom_expr [4266,4283]
===
match
---
string: 'end_of_log' [7017,7029]
string: 'end_of_log' [7036,7048]
===
match
---
trailer [8929,8935]
trailer [8948,8954]
===
match
---
string: '1' [4363,4366]
string: '1' [4363,4366]
===
match
---
operator: == [12184,12186]
operator: == [12203,12205]
===
match
---
simple_stmt [3648,3937]
simple_stmt [3648,3937]
===
match
---
trailer [5245,5248]
trailer [5264,5267]
===
match
---
operator: > [5458,5459]
operator: > [5477,5478]
===
match
---
trailer [9031,9044]
trailer [9050,9063]
===
match
---
not_test [7000,7030]
not_test [7019,7049]
===
match
---
atom_expr [4861,4946]
atom_expr [4861,4946]
===
match
---
name: strip [12176,12181]
name: strip [12195,12200]
===
match
---
factor [5249,5251]
factor [5268,5270]
===
match
---
strings [14253,14365]
strings [14272,14384]
===
match
---
trailer [9501,9513]
trailer [9520,9532]
===
match
---
name: self [3858,3862]
name: self [3858,3862]
===
match
---
name: ti [3020,3022]
name: ti [3020,3022]
===
match
---
trailer [13593,13598]
trailer [13612,13617]
===
match
---
trailer [8211,8312]
trailer [8230,8331]
===
match
---
operator: , [15106,15107]
operator: , [15125,15126]
===
match
---
atom_expr [11710,11738]
atom_expr [11729,11757]
===
match
---
arglist [6845,6859]
arglist [6864,6878]
===
match
---
name: read [14128,14132]
name: read [14147,14151]
===
match
---
trailer [13193,13198]
trailer [13212,13217]
===
match
---
simple_stmt [11660,11702]
simple_stmt [11679,11721]
===
match
---
operator: , [2250,2251]
operator: , [2250,2251]
===
match
---
name: read [8752,8756]
name: read [8771,8775]
===
match
---
simple_stmt [6869,6891]
simple_stmt [6888,6910]
===
match
---
assert_stmt [9628,9665]
assert_stmt [9647,9684]
===
match
---
operator: , [3745,3746]
operator: , [3745,3746]
===
match
---
trailer [12345,12354]
trailer [12364,12373]
===
match
---
string: 'task_for_testing_file_log_handler-2016-01-01T00:00:00+00:00-1' [14302,14365]
string: 'task_for_testing_file_log_handler-2016-01-01T00:00:00+00:00-1' [14321,14384]
===
match
---
name: self [11142,11146]
name: self [11161,11165]
===
match
---
testlist_star_expr [5516,5531]
testlist_star_expr [5535,5550]
===
match
---
arglist [1543,1553]
arglist [1543,1553]
===
match
---
simple_stmt [6429,6464]
simple_stmt [6448,6483]
===
match
---
trailer [14413,14428]
trailer [14432,14447]
===
match
---
operator: { [2452,2453]
operator: { [2452,2453]
===
match
---
number: 0 [7124,7125]
number: 0 [7143,7144]
===
match
---
assert_stmt [12600,12634]
assert_stmt [12619,12653]
===
match
---
name: expected_dict [3455,3468]
name: expected_dict [3455,3468]
===
match
---
trailer [8438,8441]
trailer [8457,8460]
===
match
---
name: self [12363,12367]
name: self [12382,12386]
===
match
---
name: logging [10559,10566]
name: logging [10578,10585]
===
match
---
operator: = [8046,8047]
operator: = [8065,8066]
===
match
---
name: ti [9609,9611]
name: ti [9628,9630]
===
match
---
atom_expr [9176,9198]
atom_expr [9195,9217]
===
match
---
atom_expr [10196,10269]
atom_expr [10215,10288]
===
match
---
arglist [14915,14925]
arglist [14934,14944]
===
match
---
trailer [9238,9241]
trailer [9257,9260]
===
match
---
number: 1 [13265,13266]
number: 1 [13284,13285]
===
match
---
operator: , [2830,2831]
operator: , [2830,2831]
===
match
---
string: 'offset' [7127,7135]
string: 'offset' [7146,7154]
===
match
---
expr_stmt [1467,1512]
expr_stmt [1467,1512]
===
match
---
trailer [6177,6184]
trailer [6196,6203]
===
match
---
suite [9302,9975]
suite [9321,9994]
===
match
---
fstring [1568,1617]
fstring [1568,1617]
===
match
---
trailer [10213,10269]
trailer [10232,10288]
===
match
---
testlist_star_expr [11235,11242]
testlist_star_expr [11254,11261]
===
match
---
name: self [10278,10282]
name: self [10297,10301]
===
match
---
name: self [14393,14397]
name: self [14412,14416]
===
match
---
trailer [7798,7808]
trailer [7817,7827]
===
match
---
name: es [11147,11149]
name: es [11166,11168]
===
match
---
atom_expr [5802,5852]
atom_expr [5821,5871]
===
match
---
atom_expr [9316,9372]
atom_expr [9335,9391]
===
match
---
operator: = [2560,2561]
operator: = [2560,2561]
===
match
---
trailer [10203,10213]
trailer [10222,10232]
===
match
---
name: os [3193,3195]
name: os [3193,3195]
===
match
---
number: 0 [9239,9240]
number: 0 [9258,9259]
===
match
---
name: filename_template [13229,13246]
name: filename_template [13248,13265]
===
match
---
name: get_external_log_url [15922,15942]
name: get_external_log_url [15941,15961]
===
match
---
name: patch [9321,9326]
name: patch [9340,9345]
===
match
---
atom_expr [9334,9358]
atom_expr [9353,9377]
===
match
---
trailer [8229,8232]
trailer [8248,8251]
===
match
---
number: 1 [11293,11294]
number: 1 [11312,11313]
===
match
---
trailer [12317,12333]
trailer [12336,12352]
===
match
---
name: self [2295,2299]
name: self [2295,2299]
===
match
---
trailer [12963,12980]
trailer [12982,12999]
===
match
---
atom_expr [14150,14177]
atom_expr [14169,14196]
===
match
---
operator: == [9173,9175]
operator: == [9192,9194]
===
match
---
suite [9472,9616]
suite [9491,9635]
===
match
---
trailer [2762,2771]
trailer [2762,2771]
===
match
---
trailer [14808,14820]
trailer [14827,14839]
===
match
---
trailer [15632,15651]
trailer [15651,15670]
===
match
---
trailer [5564,5567]
trailer [5583,5586]
===
match
---
name: write_stdout [14778,14790]
name: write_stdout [14797,14809]
===
match
---
assert_stmt [5355,5391]
assert_stmt [5374,5410]
===
match
---
atom_expr [14592,14615]
atom_expr [14611,14634]
===
match
---
trailer [9002,9005]
trailer [9021,9024]
===
match
---
trailer [8143,8152]
trailer [8162,8171]
===
match
---
name: doc_type [4912,4920]
name: doc_type [4912,4920]
===
match
---
string: "elasticsearch_dsl.Search.execute" [9420,9454]
string: "elasticsearch_dsl.Search.execute" [9439,9473]
===
match
---
name: body [2783,2787]
name: body [2783,2787]
===
match
---
expr_stmt [1418,1462]
expr_stmt [1418,1462]
===
match
---
simple_stmt [5137,5159]
simple_stmt [5156,5178]
===
match
---
simple_stmt [3455,3547]
simple_stmt [3455,3547]
===
match
---
string: '0' [6553,6556]
string: '0' [6572,6575]
===
match
---
name: end_of_log_mark [15740,15755]
name: end_of_log_mark [15759,15774]
===
match
---
simple_stmt [12101,12136]
simple_stmt [12120,12155]
===
match
---
name: logs [9832,9836]
name: logs [9851,9855]
===
match
---
trailer [12740,12752]
trailer [12759,12771]
===
match
---
trailer [5415,5421]
trailer [5434,5440]
===
match
---
atom_expr [6906,6915]
atom_expr [6925,6934]
===
match
---
trailer [11736,11738]
trailer [11755,11757]
===
match
---
assert_stmt [12541,12591]
assert_stmt [12560,12610]
===
match
---
name: airflow [1023,1030]
name: airflow [1023,1030]
===
match
---
name: DummyOperator [2879,2892]
name: DummyOperator [2879,2892]
===
match
---
name: metadatas [6807,6816]
name: metadatas [6826,6835]
===
match
---
trailer [7520,7555]
trailer [7539,7574]
===
match
---
operator: , [10894,10895]
operator: , [10913,10914]
===
match
---
trailer [3672,3936]
trailer [3672,3936]
===
match
---
name: log_file [13282,13290]
name: log_file [13301,13309]
===
match
---
trailer [11265,11270]
trailer [11284,11289]
===
match
---
trailer [15061,15083]
trailer [15080,15102]
===
match
---
parameters [15529,15562]
parameters [15548,15581]
===
match
---
atom_expr [14804,14820]
atom_expr [14823,14839]
===
match
---
name: len [7576,7579]
name: len [7595,7598]
===
match
---
atom_expr [8998,9005]
atom_expr [9017,9024]
===
match
---
operator: , [4988,4989]
operator: , [4988,4989]
===
match
---
atom_expr [12576,12591]
atom_expr [12595,12610]
===
match
---
name: logs [5153,5157]
name: logs [5172,5176]
===
match
---
name: self [8092,8096]
name: self [8111,8115]
===
match
---
operator: , [4063,4064]
operator: , [4063,4064]
===
match
---
name: configuration [992,1005]
name: configuration [992,1005]
===
match
---
simple_stmt [8987,9012]
simple_stmt [9006,9031]
===
match
---
atom_expr [10459,10466]
atom_expr [10478,10485]
===
match
---
atom_expr [3976,3990]
atom_expr [3976,3990]
===
match
---
simple_stmt [5516,5572]
simple_stmt [5535,5591]
===
match
---
arglist [13604,13672]
arglist [13623,13691]
===
match
---
operator: } [2701,2702]
operator: } [2701,2702]
===
match
---
atom_expr [12770,12798]
atom_expr [12789,12817]
===
match
---
operator: , [12866,12867]
operator: , [12885,12886]
===
match
---
string: 'end_of_log\n' [1901,1915]
string: 'end_of_log\n' [1901,1915]
===
match
---
funcdef [8639,9270]
funcdef [8658,9289]
===
match
---
expr_stmt [1517,1554]
expr_stmt [1517,1554]
===
match
---
name: start_date [2832,2842]
name: start_date [2832,2842]
===
match
---
assert_stmt [8422,8455]
assert_stmt [8441,8474]
===
match
---
name: log_id [14961,14967]
name: log_id [14980,14986]
===
match
---
string: "[2020-12-24 19:25:00,962] {taskinstance.py:851} INFO - some random stuff" [11387,11461]
string: "[2020-12-24 19:25:00,962] {taskinstance.py:851} INFO - some random stuff" [11406,11480]
===
match
---
comparison [15136,15188]
comparison [15155,15207]
===
match
---
atom_expr [3273,3341]
atom_expr [3273,3341]
===
match
---
name: TASK_ID [1467,1474]
name: TASK_ID [1467,1474]
===
match
---
atom_expr [6170,6237]
atom_expr [6189,6256]
===
match
---
trailer [12972,12977]
trailer [12991,12996]
===
match
---
trailer [6195,6206]
trailer [6214,6225]
===
match
---
number: 0 [9003,9004]
number: 0 [9022,9023]
===
match
---
atom_expr [12812,12922]
atom_expr [12831,12941]
===
match
---
name: task [2960,2964]
name: task [2960,2964]
===
match
---
trailer [7415,7468]
trailer [7434,7487]
===
match
---
name: datetime [1534,1542]
name: datetime [1534,1542]
===
match
---
name: self [1796,1800]
name: self [1796,1800]
===
match
---
name: self [10504,10508]
name: self [10523,10527]
===
match
---
name: end_of_log_mark [3798,3813]
name: end_of_log_mark [3798,3813]
===
match
---
name: timezone [1228,1236]
name: timezone [1228,1236]
===
match
---
trailer [10576,10647]
trailer [10595,10666]
===
match
---
name: metadatas [5522,5531]
name: metadatas [5541,5550]
===
match
---
operator: , [2913,2914]
operator: , [2913,2914]
===
match
---
operator: = [4659,4660]
operator: = [4659,4660]
===
match
---
name: self [2778,2782]
name: self [2778,2782]
===
match
---
simple_stmt [10066,10112]
simple_stmt [10085,10131]
===
match
---
name: len [8926,8929]
name: len [8945,8948]
===
match
---
name: es_task_handler [14398,14413]
name: es_task_handler [14417,14432]
===
match
---
testlist_star_expr [7477,7492]
testlist_star_expr [7496,7511]
===
match
---
trailer [3019,3022]
trailer [3019,3022]
===
match
---
funcdef [3121,3230]
funcdef [3121,3230]
===
match
---
trailer [5538,5554]
trailer [5557,5573]
===
match
---
operator: = [4943,4944]
operator: = [4943,4944]
===
match
---
name: datetime [15084,15092]
name: datetime [15103,15111]
===
match
---
atom [8806,8894]
atom [8825,8913]
===
match
---
arglist [8225,8302]
arglist [8244,8321]
===
match
---
trailer [14899,14914]
trailer [14918,14933]
===
match
---
name: self [6819,6823]
name: self [6838,6842]
===
match
---
trailer [1672,1678]
trailer [1672,1678]
===
match
---
expr_stmt [10378,10417]
expr_stmt [10397,10436]
===
match
---
string: 'localhost:5601' [15435,15451]
string: 'localhost:5601' [15454,15470]
===
match
---
simple_stmt [10184,10270]
simple_stmt [10203,10289]
===
match
---
trailer [4422,4458]
trailer [4422,4458]
===
match
---
name: subtract [8063,8071]
name: subtract [8082,8090]
===
match
---
operator: = [11187,11188]
operator: = [11206,11207]
===
match
---
atom_expr [11245,11371]
atom_expr [11264,11390]
===
match
---
name: set_context [13829,13840]
name: set_context [13848,13859]
===
match
---
operator: == [14958,14960]
operator: == [14977,14979]
===
match
---
comparison [5268,5299]
comparison [5287,5318]
===
match
---
trailer [12389,12391]
trailer [12408,12410]
===
match
---
assert_stmt [5400,5462]
assert_stmt [5419,5481]
===
match
---
atom_expr [8273,8280]
atom_expr [8292,8299]
===
match
---
suite [1656,3116]
suite [1656,3116]
===
match
---
simple_stmt [9864,9884]
simple_stmt [9883,9903]
===
match
---
name: side_effect [9502,9513]
name: side_effect [9521,9532]
===
match
---
name: write_stdout [1929,1941]
name: write_stdout [1929,1941]
===
match
---
atom_expr [10378,10410]
atom_expr [10397,10429]
===
match
---
trailer [8548,8551]
trailer [8567,8570]
===
match
---
argument [15860,15880]
argument [15879,15899]
===
match
---
operator: = [4906,4907]
operator: = [4906,4907]
===
match
---
simple_stmt [9791,9813]
simple_stmt [9810,9832]
===
match
---
trailer [3205,3208]
trailer [3205,3208]
===
match
---
operator: = [1817,1818]
operator: = [1817,1818]
===
match
---
atom_expr [8994,9006]
atom_expr [9013,9025]
===
match
---
operator: = [11221,11222]
operator: = [11240,11241]
===
match
---
atom_expr [15665,15687]
atom_expr [15684,15706]
===
match
---
trailer [13069,13072]
trailer [13088,13091]
===
match
---
name: self [11092,11096]
name: self [11111,11115]
===
match
---
name: self [9296,9300]
name: self [9315,9319]
===
match
---
simple_stmt [3084,3116]
simple_stmt [3084,3116]
===
match
---
name: self [3251,3255]
name: self [3251,3255]
===
match
---
simple_stmt [869,900]
simple_stmt [869,900]
===
match
---
name: self [14739,14743]
name: self [14758,14762]
===
match
---
operator: , [2182,2183]
operator: , [2182,2183]
===
match
---
name: expected_log_id [14456,14471]
name: expected_log_id [14475,14490]
===
match
---
operator: , [6310,6311]
operator: , [6329,6330]
===
match
---
name: es_frontend [15536,15547]
name: es_frontend [15555,15566]
===
match
---
name: self [12155,12159]
name: self [12174,12178]
===
match
---
atom_expr [8092,8159]
atom_expr [8111,8178]
===
match
---
simple_stmt [10756,11084]
simple_stmt [10775,11103]
===
match
---
expr_stmt [2804,2863]
expr_stmt [2804,2863]
===
match
---
trailer [10398,10410]
trailer [10417,10429]
===
match
---
operator: , [7461,7462]
operator: , [7480,7481]
===
match
---
trailer [12350,12353]
trailer [12369,12372]
===
match
---
name: read [13749,13753]
name: read [13768,13772]
===
match
---
with_item [13952,14074]
with_item [13971,14093]
===
match
---
operator: == [8406,8408]
operator: == [8425,8427]
===
match
---
name: metadatas [6453,6462]
name: metadatas [6472,6481]
===
match
---
name: self [10707,10711]
name: self [10726,10730]
===
match
---
simple_stmt [11092,11134]
simple_stmt [11111,11153]
===
match
---
funcdef [1640,3116]
funcdef [1640,3116]
===
match
---
trailer [7426,7437]
trailer [7445,7456]
===
match
---
operator: = [10309,10310]
operator: = [10328,10329]
===
match
---
name: parse [7954,7959]
name: parse [7973,7978]
===
match
---
parameters [1649,1655]
parameters [1649,1655]
===
match
---
name: unittest [848,856]
name: unittest [848,856]
===
match
---
atom_expr [4287,4301]
atom_expr [4287,4301]
===
match
---
name: test_read [3946,3955]
name: test_read [3946,3955]
===
match
---
name: formatter [10677,10686]
name: formatter [10696,10705]
===
match
---
decorated [1623,3116]
decorated [1623,3116]
===
match
---
funcdef [6724,8001]
funcdef [6743,8020]
===
match
---
name: metadatas [9903,9912]
name: metadatas [9922,9931]
===
match
---
trailer [14428,14440]
trailer [14447,14459]
===
match
---
expr_stmt [15018,15120]
expr_stmt [15037,15139]
===
match
---
simple_stmt [5750,5787]
simple_stmt [5769,5806]
===
match
---
trailer [6452,6463]
trailer [6471,6482]
===
match
---
operator: , [6358,6359]
operator: , [6377,6378]
===
match
---
name: close [13552,13557]
name: close [13571,13576]
===
match
---
trailer [10048,10057]
trailer [10067,10076]
===
match
---
trailer [11697,11700]
trailer [11716,11719]
===
match
---
atom_expr [2123,2146]
atom_expr [2123,2146]
===
match
---
atom_expr [2732,2747]
atom_expr [2732,2747]
===
match
---
operator: == [5235,5237]
operator: == [5254,5256]
===
match
---
assert_stmt [14088,14134]
assert_stmt [14107,14153]
===
match
---
name: json_format [2300,2311]
name: json_format [2300,2311]
===
match
---
parameters [9295,9301]
parameters [9314,9320]
===
match
---
atom_expr [13065,13072]
atom_expr [13084,13091]
===
match
---
name: self [11125,11129]
name: self [11144,11148]
===
match
---
atom_expr [11608,11638]
atom_expr [11627,11657]
===
match
---
name: DAG [2815,2818]
name: DAG [2815,2818]
===
match
---
number: 2016 [15093,15097]
number: 2016 [15112,15116]
===
match
---
trailer [10536,10538]
trailer [10555,10557]
===
match
---
atom_expr [3193,3204]
atom_expr [3193,3204]
===
match
---
atom_expr [2879,2928]
atom_expr [2879,2928]
===
match
---
string: 'download_logs' [8851,8866]
string: 'download_logs' [8870,8885]
===
match
---
name: metadatas [4207,4216]
name: metadatas [4207,4216]
===
match
---
name: json_fields [15835,15846]
name: json_fields [15854,15865]
===
match
---
trailer [10532,10536]
trailer [10551,10555]
===
match
---
trailer [8441,8455]
trailer [8460,8474]
===
match
---
simple_stmt [14449,14482]
simple_stmt [14468,14501]
===
match
---
operator: } [4851,4852]
operator: } [4851,4852]
===
match
---
trailer [13508,13515]
trailer [13527,13534]
===
match
---
operator: = [1975,1976]
operator: = [1975,1976]
===
match
---
name: quote [15321,15326]
name: quote [15340,15345]
===
match
---
fstring_string: -2016-01-01T00:00:00+00:00-1 [1588,1616]
fstring_string: -2016-01-01T00:00:00+00:00-1 [1588,1616]
===
match
---
operator: = [2964,2965]
operator: = [2964,2965]
===
match
---
name: DAG_ID [10842,10848]
name: DAG_ID [10861,10867]
===
match
---
param [3375,3379]
param [3375,3379]
===
match
---
atom_expr [3405,3445]
atom_expr [3405,3445]
===
match
---
funcdef [5468,5870]
funcdef [5487,5889]
===
match
---
string: 'last_log_timestamp' [11310,11330]
string: 'last_log_timestamp' [11329,11349]
===
match
---
param [13415,13419]
param [13434,13438]
===
match
---
parameters [3133,3139]
parameters [3133,3139]
===
match
---
operator: , [5567,5568]
operator: , [5586,5587]
===
match
---
operator: == [5761,5763]
operator: == [5780,5782]
===
match
---
assert_stmt [5795,5869]
assert_stmt [5814,5888]
===
match
---
name: close [13931,13936]
name: close [13950,13955]
===
match
---
name: expected_url [15987,15999]
name: expected_url [16006,16018]
===
match
---
operator: = [2370,2371]
operator: = [2370,2371]
===
match
---
name: self [13480,13484]
name: self [13499,13503]
===
match
---
atom_expr [13082,13110]
atom_expr [13101,13129]
===
match
---
name: logs [6970,6974]
name: logs [6989,6993]
===
match
---
trailer [12409,12515]
trailer [12428,12534]
===
match
---
name: ElasticsearchTaskHandler [14554,14578]
name: ElasticsearchTaskHandler [14573,14597]
===
match
---
argument [13659,13671]
argument [13678,13690]
===
match
---
operator: = [2877,2878]
operator: = [2877,2878]
===
match
---
name: close [11731,11736]
name: close [11750,11755]
===
match
---
expr_stmt [3390,3446]
expr_stmt [3390,3446]
===
match
---
name: TaskInstance [2947,2959]
name: TaskInstance [2947,2959]
===
match
---
number: 0 [4331,4332]
number: 0 [4331,4332]
===
match
---
name: ti [14920,14922]
name: ti [14939,14941]
===
match
---
number: 0 [7298,7299]
number: 0 [7317,7318]
===
match
---
operator: , [6852,6853]
operator: , [6871,6872]
===
match
---
operator: , [15755,15756]
operator: , [15774,15775]
===
match
---
string: 'offset' [8807,8815]
string: 'offset' [8826,8834]
===
match
---
atom_expr [12843,12866]
atom_expr [12862,12885]
===
match
---
trailer [13551,13557]
trailer [13570,13576]
===
match
---
trailer [9649,9660]
trailer [9668,9679]
===
match
---
trailer [6844,6860]
trailer [6863,6879]
===
match
---
operator: == [3570,3572]
operator: == [3570,3572]
===
match
---
import_name [901,921]
import_name [901,921]
===
match
---
trailer [14012,14030]
trailer [14031,14049]
===
match
---
operator: , [8849,8850]
operator: , [8868,8869]
===
match
---
name: pendulum [6778,6786]
name: pendulum [6797,6805]
===
match
---
trailer [6520,6523]
trailer [6539,6542]
===
match
---
name: pendulum [8048,8056]
name: pendulum [8067,8075]
===
match
---
trailer [7499,7515]
trailer [7518,7534]
===
match
---
name: path [12833,12837]
name: path [12852,12856]
===
match
---
number: 1 [4249,4250]
number: 1 [4249,4250]
===
match
---
operator: , [3535,3536]
operator: , [3535,3536]
===
match
---
import_name [813,826]
import_name [813,826]
===
match
---
simple_stmt [4861,4947]
simple_stmt [4861,4947]
===
match
---
operator: = [2813,2814]
operator: = [2813,2814]
===
match
---
trailer [5863,5867]
trailer [5882,5886]
===
match
---
trailer [6414,6420]
trailer [6433,6439]
===
match
---
number: 0 [8817,8818]
number: 0 [8836,8837]
===
match
---
operator: = [15588,15589]
operator: = [15607,15608]
===
match
---
trailer [6839,6844]
trailer [6858,6863]
===
match
---
atom_expr [2576,2593]
atom_expr [2576,2593]
===
match
---
number: 1 [3036,3037]
number: 1 [3036,3037]
===
match
---
atom_expr [13573,13683]
atom_expr [13592,13702]
===
match
---
trailer [2329,2341]
trailer [2329,2341]
===
match
---
atom_expr [10524,10538]
atom_expr [10543,10557]
===
match
---
trailer [6922,6933]
trailer [6941,6952]
===
match
---
operator: { [7533,7534]
operator: { [7552,7553]
===
match
---
atom_expr [11162,11177]
atom_expr [11181,11196]
===
match
---
operator: = [13669,13670]
operator: = [13688,13689]
===
match
---
dictorsetmaker [11297,11360]
dictorsetmaker [11316,11379]
===
match
---
operator: , [4111,4112]
operator: , [4111,4112]
===
match
---
name: self [1744,1748]
name: self [1744,1748]
===
match
---
simple_stmt [5400,5463]
simple_stmt [5419,5482]
===
match
---
trailer [9806,9812]
trailer [9825,9831]
===
match
---
simple_stmt [8043,8083]
simple_stmt [8062,8102]
===
match
---
operator: , [15721,15722]
operator: , [15740,15741]
===
match
---
trailer [5332,5346]
trailer [5351,5365]
===
match
---
number: 0 [13311,13312]
number: 0 [13330,13331]
===
match
---
string: '{try_number}.log' [1769,1787]
string: '{try_number}.log' [1769,1787]
===
match
---
trailer [10020,10036]
trailer [10039,10055]
===
match
---
name: os [11770,11772]
name: os [11789,11791]
===
match
---
trailer [4643,4650]
trailer [4643,4650]
===
match
---
name: self [2712,2716]
name: self [2712,2716]
===
match
---
number: 0 [11473,11474]
number: 0 [11492,11493]
===
match
---
name: log_id_template [2201,2216]
name: log_id_template [2201,2216]
===
match
---
atom_expr [11208,11217]
atom_expr [11227,11236]
===
match
---
name: setUp [1644,1649]
name: setUp [1644,1649]
===
match
---
name: logs [8337,8341]
name: logs [8356,8360]
===
match
---
atom_expr [15735,15755]
atom_expr [15754,15774]
===
match
---
atom_expr [13463,13470]
atom_expr [13482,13489]
===
match
---
trailer [9058,9062]
trailer [9077,9081]
===
match
---
operator: = [4926,4927]
operator: = [4926,4927]
===
match
---
operator: = [2985,2986]
operator: = [2985,2986]
===
match
---
trailer [12435,12505]
trailer [12454,12524]
===
match
---
operator: { [6857,6858]
operator: { [6876,6877]
===
match
---
name: self [10851,10855]
name: self [10870,10874]
===
match
---
name: timezone [6662,6670]
name: timezone [6681,6689]
===
match
---
suite [10175,10468]
suite [10194,10487]
===
match
---
operator: , [10810,10811]
operator: , [10829,10830]
===
match
---
simple_stmt [1689,1736]
simple_stmt [1689,1736]
===
match
---
simple_stmt [9117,9154]
simple_stmt [9136,9173]
===
match
---
operator: , [9682,9683]
operator: , [9701,9702]
===
match
---
string: 'port' [2474,2480]
string: 'port' [2474,2480]
===
match
---
name: os [12830,12832]
name: os [12849,12851]
===
match
---
simple_stmt [901,922]
simple_stmt [901,922]
===
match
---
name: format [13247,13253]
name: format [13266,13272]
===
match
---
arglist [12436,12504]
arglist [12455,12523]
===
match
---
atom_expr [13604,13627]
atom_expr [13623,13646]
===
match
---
name: es_task_handler [12318,12333]
name: es_task_handler [12337,12352]
===
match
---
name: es [2367,2369]
name: es [2367,2369]
===
match
---
atom_expr [10278,10308]
atom_expr [10297,10327]
===
match
---
name: parse [5416,5421]
name: parse [5435,5440]
===
match
---
name: doc_type [2551,2559]
name: doc_type [2551,2559]
===
match
---
operator: , [14850,14851]
operator: , [14869,14870]
===
match
---
trailer [14596,14615]
trailer [14615,14634]
===
match
---
trailer [14838,14850]
trailer [14857,14869]
===
match
---
name: body [4922,4926]
name: body [4922,4926]
===
match
---
assert_stmt [5309,5346]
assert_stmt [5328,5365]
===
match
---
trailer [7525,7528]
trailer [7544,7547]
===
match
---
atom_expr [10073,10111]
atom_expr [10092,10130]
===
match
---
name: self [2062,2066]
name: self [2062,2066]
===
match
---
name: self [8186,8190]
name: self [8205,8209]
===
match
---
operator: = [10687,10688]
operator: = [10706,10707]
===
match
---
operator: = [10766,10767]
operator: = [10785,10786]
===
match
---
parameters [4506,4512]
parameters [4506,4512]
===
match
---
simple_stmt [7637,7657]
simple_stmt [7656,7676]
===
match
---
trailer [15773,15786]
trailer [15792,15805]
===
match
---
with_stmt [12400,12592]
with_stmt [12419,12611]
===
match
---
operator: , [15103,15104]
operator: , [15122,15123]
===
match
---
operator: , [7531,7532]
operator: , [7550,7551]
===
match
---
simple_stmt [14870,14927]
simple_stmt [14889,14946]
===
match
---
name: end_of_log_mark [1883,1898]
name: end_of_log_mark [1883,1898]
===
match
---
name: parameterized [964,977]
name: parameterized [964,977]
===
match
---
operator: { [10836,10837]
operator: { [10855,10856]
===
match
---
operator: = [2523,2524]
operator: = [2523,2524]
===
match
---
name: _ [11241,11242]
name: _ [11260,11261]
===
match
---
name: logs [4194,4198]
name: logs [4194,4198]
===
match
---
name: open [13573,13577]
name: open [13592,13596]
===
match
---
trailer [9964,9974]
trailer [9983,9993]
===
match
---
operator: == [5678,5680]
operator: == [5697,5699]
===
match
---
string: 'end_of_log' [9095,9107]
string: 'end_of_log' [9114,9126]
===
match
---
name: self [2901,2905]
name: self [2901,2905]
===
match
---
expr_stmt [10547,10647]
expr_stmt [10566,10666]
===
match
---
atom_expr [3400,3446]
atom_expr [3400,3446]
===
match
---
name: es_task_handler [13813,13828]
name: es_task_handler [13832,13847]
===
match
---
name: doc_type [2749,2757]
name: doc_type [2749,2757]
===
match
---
trailer [5421,5457]
trailer [5440,5476]
===
match
---
name: timezone [7273,7281]
name: timezone [7292,7300]
===
match
---
trailer [10349,10362]
trailer [10368,10381]
===
match
---
comparison [6406,6420]
comparison [6425,6439]
===
match
---
number: 0 [4433,4434]
number: 0 [4433,4434]
===
match
---
trailer [2716,2719]
trailer [2716,2719]
===
match
---
comparison [9027,9062]
comparison [9046,9081]
===
match
---
argument [6208,6230]
argument [6227,6249]
===
match
---
simple_stmt [10519,10539]
simple_stmt [10538,10558]
===
match
---
name: task [2872,2876]
name: task [2872,2876]
===
match
---
trailer [12752,12761]
trailer [12771,12780]
===
match
---
name: test_client [3239,3250]
name: test_client [3239,3250]
===
match
---
operator: , [15097,15098]
operator: , [15116,15117]
===
match
---
number: 0 [11307,11308]
number: 0 [11326,11327]
===
match
---
operator: = [4880,4881]
operator: = [4880,4881]
===
match
---
parameters [14205,14211]
parameters [14224,14230]
===
match
---
assert_stmt [6429,6463]
assert_stmt [6448,6482]
===
match
---
trailer [3892,3904]
trailer [3892,3904]
===
match
---
name: metadatas [4005,4014]
name: metadatas [4005,4014]
===
match
---
atom_expr [8592,8626]
atom_expr [8611,8645]
===
match
---
simple_stmt [5704,5742]
simple_stmt [5723,5761]
===
match
---
name: self [12271,12275]
name: self [12290,12294]
===
match
---
operator: = [4959,4960]
operator: = [4959,4960]
===
match
---
simple_stmt [7772,7809]
simple_stmt [7791,7828]
===
match
---
operator: , [8280,8281]
operator: , [8299,8300]
===
match
---
name: TASK_ID [10856,10863]
name: TASK_ID [10875,10882]
===
match
---
dotted_name [1118,1169]
dotted_name [1118,1169]
===
match
---
name: es [7406,7408]
name: es [7425,7427]
===
match
---
operator: - [5249,5250]
operator: - [5268,5269]
===
match
---
name: len [5592,5595]
name: len [5611,5614]
===
match
---
name: self [8731,8735]
name: self [8750,8754]
===
match
---
trailer [2959,3006]
trailer [2959,3006]
===
match
---
name: metadatas [5634,5643]
name: metadatas [5653,5662]
===
match
---
atom_expr [13531,13559]
atom_expr [13550,13578]
===
match
---
name: es_task_handler [10283,10298]
name: es_task_handler [10302,10317]
===
match
---
name: self [14008,14012]
name: self [14027,14031]
===
match
---
trailer [13972,13977]
trailer [13991,13996]
===
match
---
name: closed [14171,14177]
name: closed [14190,14196]
===
match
---
name: another_test_message [4715,4735]
name: another_test_message [4715,4735]
===
match
---
name: self [10459,10463]
name: self [10478,10482]
===
insert-node
---
name: TestElasticsearchTaskHandler [1365,1393]
to
classdef [1359,16007]
at 0
===
insert-node
---
string: '0' [5064,5067]
to
dictorsetmaker [5054,5117]
at 1
===
insert-node
---
operator: , [5119,5120]
to
dictorsetmaker [5054,5117]
at 8
===
insert-node
---
string: 'max_offset' [5121,5133]
to
dictorsetmaker [5054,5117]
at 9
===
insert-node
---
number: 2 [5135,5136]
to
dictorsetmaker [5054,5117]
at 10
===
delete-node
---
name: TestElasticsearchTaskHandler [1365,1393]
===
===
delete-node
---
number: 0 [5064,5065]
===
