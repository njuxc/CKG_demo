===
match
---
comparison [6685,6737]
comparison [6685,6737]
===
match
---
name: raw [10484,10487]
name: raw [10504,10507]
===
match
---
name: end_of_log_mark [6714,6729]
name: end_of_log_mark [6714,6729]
===
match
---
operator: = [7525,7526]
operator: = [7545,7546]
===
match
---
tfpdef [10289,10305]
tfpdef [10309,10325]
===
match
---
trailer [12378,12386]
trailer [12398,12406]
===
match
---
name: self [11320,11324]
name: self [11340,11344]
===
match
---
trailer [3324,3331]
trailer [3324,3331]
===
match
---
name: task_instance [12954,12967]
name: task_instance [12974,12987]
===
match
---
parameters [8036,8052]
parameters [8056,8072]
===
match
---
try_stmt [8337,8570]
try_stmt [8357,8590]
===
match
---
if_stmt [3803,4011]
if_stmt [3803,4011]
===
match
---
atom_expr [10869,10886]
atom_expr [10889,10906]
===
match
---
atom_expr [8461,8479]
atom_expr [8481,8499]
===
match
---
atom_expr [10452,10474]
atom_expr [10472,10494]
===
match
---
trailer [6697,6705]
trailer [6697,6705]
===
match
---
name: dag_id [10747,10753]
name: dag_id [10767,10773]
===
match
---
simple_stmt [11554,11578]
simple_stmt [11574,11598]
===
match
---
name: execution_date [4053,4067]
name: execution_date [4053,4067]
===
match
---
operator: = [12434,12435]
operator: = [12454,12455]
===
match
---
atom_expr [10927,10940]
atom_expr [10947,10960]
===
match
---
operator: , [10941,10942]
operator: , [10961,10962]
===
match
---
comparison [9936,9953]
comparison [9956,9973]
===
match
---
name: logs [6119,6123]
name: logs [6119,6123]
===
match
---
operator: ** [13927,13929]
operator: ** [13947,13949]
===
match
---
string: """         :param base_log_folder: base folder to store logs locally         :param log_id_template: log id template         :param host: Elasticsearch host name         """ [2912,3086]
string: """         :param base_log_folder: base folder to store logs locally         :param log_id_template: log id template         :param host: Elasticsearch host name         """ [2912,3086]
===
match
---
name: task_id [4274,4281]
name: task_id [4274,4281]
===
match
---
trailer [6807,6822]
trailer [6807,6822]
===
match
---
sync_comp_for [3624,3659]
sync_comp_for [3624,3659]
===
match
---
argument [10655,10683]
argument [10675,10703]
===
match
---
operator: = [10707,10708]
operator: = [10727,10728]
===
match
---
parameters [13920,13936]
parameters [13940,13956]
===
match
---
trailer [12785,12787]
trailer [12805,12807]
===
match
---
trailer [7830,7835]
trailer [7850,7855]
===
match
---
trailer [3555,3567]
trailer [3555,3567]
===
match
---
trailer [10596,10601]
trailer [10616,10621]
===
match
---
atom_expr [3862,3887]
atom_expr [3862,3887]
===
match
---
name: _open [12449,12454]
name: _open [12469,12474]
===
match
---
name: self [10500,10504]
name: self [10520,10524]
===
match
---
comparison [9573,9589]
comparison [9593,9609]
===
match
---
factor [9671,9673]
factor [9691,9693]
===
match
---
name: parse_template_string [1289,1310]
name: parse_template_string [1289,1310]
===
match
---
simple_stmt [4891,4924]
simple_stmt [4891,4924]
===
match
---
name: ti [10744,10746]
name: ti [10764,10766]
===
match
---
name: level [11435,11440]
name: level [11455,11460]
===
match
---
try_stmt [9967,10241]
try_stmt [9987,10261]
===
match
---
name: self [5989,5993]
name: self [5989,5993]
===
match
---
param [12983,12998]
param [13003,13018]
===
match
---
name: parse_template_string [3272,3293]
name: parse_template_string [3272,3293]
===
match
---
trailer [11367,11378]
trailer [11387,11398]
===
match
---
name: log [1453,1456]
name: log [1453,1456]
===
match
---
trailer [5159,5185]
trailer [5159,5185]
===
match
---
name: i [7868,7869]
name: i [7888,7889]
===
match
---
import_name [1066,1086]
import_name [1066,1086]
===
match
---
name: execution_date [4100,4114]
name: execution_date [4100,4114]
===
match
---
name: json_format [2694,2705]
name: json_format [2694,2705]
===
match
---
operator: , [13605,13606]
operator: , [13625,13626]
===
match
---
name: self [7762,7766]
name: self [7782,7786]
===
match
---
suite [12861,12918]
suite [12881,12938]
===
match
---
name: self [10003,10007]
name: self [10023,10027]
===
match
---
expr_stmt [6036,6081]
expr_stmt [6036,6081]
===
match
---
parameters [7688,7695]
parameters [7708,7715]
===
match
---
name: offset [7313,7319]
name: offset [7317,7323]
===
match
---
atom_expr [3590,3606]
atom_expr [3590,3606]
===
match
---
operator: = [13449,13450]
operator: = [13469,13470]
===
match
---
operator: , [2626,2627]
operator: , [2626,2627]
===
match
---
name: self [13402,13406]
name: self [13422,13426]
===
match
---
operator: = [3484,3485]
operator: = [3484,3485]
===
match
---
trailer [10002,10063]
trailer [10022,10083]
===
match
---
expr_stmt [7709,7806]
expr_stmt [7729,7826]
===
match
---
simple_stmt [13016,13385]
simple_stmt [13036,13405]
===
match
---
number: 0 [9952,9953]
number: 0 [9972,9973]
===
match
---
simple_stmt [5196,5210]
simple_stmt [5196,5210]
===
match
---
name: getattr [4967,4974]
name: getattr [4967,4974]
===
match
---
trailer [3514,3527]
trailer [3514,3527]
===
match
---
name: host [3363,3367]
name: host [3363,3367]
===
match
---
arglist [10578,11086]
arglist [10598,11106]
===
match
---
atom_expr [7494,7524]
atom_expr [7514,7544]
===
match
---
atom_expr [6685,6705]
atom_expr [6685,6705]
===
match
---
if_stmt [4020,4189]
if_stmt [4020,4189]
===
match
---
operator: , [5135,5136]
operator: , [5135,5136]
===
match
---
name: str [1555,1558]
name: str [1555,1558]
===
match
---
name: int [11043,11046]
name: int [11063,11066]
===
match
---
param [12954,12982]
param [12974,13002]
===
match
---
string: 'download_logs' [9445,9460]
string: 'download_logs' [9465,9480]
===
match
---
simple_stmt [11993,12012]
simple_stmt [12013,12032]
===
match
---
tfpdef [5330,5354]
tfpdef [5330,5354]
===
match
---
atom_expr [12637,12657]
atom_expr [12657,12677]
===
match
---
name: self [3960,3964]
name: self [3960,3964]
===
match
---
name: format [8438,8444]
name: format [8458,8464]
===
match
---
suite [12401,12493]
suite [12421,12513]
===
match
---
operator: ** [8459,8461]
operator: ** [8479,8481]
===
match
---
operator: = [6049,6050]
operator: = [6049,6050]
===
match
---
name: handler [12348,12355]
name: handler [12368,12375]
===
match
---
classdef [13708,13975]
classdef [13728,13995]
===
match
---
term [10003,10037]
term [10023,10057]
===
match
---
name: json_format [4028,4039]
name: json_format [4028,4039]
===
match
---
number: 1 [6691,6692]
number: 1 [6691,6692]
===
match
---
atom_expr [7854,7862]
atom_expr [7874,7882]
===
match
---
suite [8548,8570]
suite [8568,8590]
===
match
---
name: es_read [8676,8683]
name: es_read [8696,8703]
===
match
---
trailer [5993,6001]
trailer [5993,6001]
===
match
---
name: parse [7135,7140]
name: parse [7135,7140]
===
match
---
trailer [12751,12762]
trailer [12771,12782]
===
match
---
param [8716,8730]
param [8736,8750]
===
match
---
name: self [3221,3225]
name: self [3221,3225]
===
match
---
trailer [4224,4231]
trailer [4224,4231]
===
match
---
name: self [3463,3467]
name: self [3463,3467]
===
match
---
simple_stmt [1066,1087]
simple_stmt [1066,1087]
===
match
---
trailer [4795,4804]
trailer [4795,4804]
===
match
---
name: MAX_LINE_PER_PAGE [10045,10062]
name: MAX_LINE_PER_PAGE [10065,10082]
===
match
---
name: offset [9386,9392]
name: offset [9406,9412]
===
match
---
name: formatter [8421,8430]
name: formatter [8441,8450]
===
match
---
name: TaskInstance [1207,1219]
name: TaskInstance [1207,1219]
===
match
---
name: to_dict [8470,8477]
name: to_dict [8490,8497]
===
match
---
trailer [7788,7790]
trailer [7808,7810]
===
match
---
trailer [9485,9502]
trailer [9505,9522]
===
match
---
expr_stmt [2409,2433]
expr_stmt [2409,2433]
===
match
---
string: 'end_of_log' [6765,6777]
string: 'end_of_log' [6765,6777]
===
match
---
funcdef [7673,7892]
funcdef [7693,7912]
===
match
---
name: get_template_context [3865,3885]
name: get_template_context [3865,3885]
===
match
---
name: self [11496,11500]
name: self [11516,11520]
===
match
---
name: self [12134,12138]
name: self [12154,12158]
===
match
---
operator: = [3332,3333]
operator: = [3332,3333]
===
match
---
atom_expr [3192,3203]
atom_expr [3192,3203]
===
match
---
operator: = [2401,2402]
operator: = [2401,2402]
===
match
---
operator: = [12146,12147]
operator: = [12166,12167]
===
match
---
trailer [13429,13616]
trailer [13449,13636]
===
match
---
name: closed [11914,11920]
name: closed [11934,11940]
===
match
---
name: self [5289,5293]
name: self [5289,5293]
===
match
---
name: str [2753,2756]
name: str [2753,2756]
===
match
---
expr_stmt [12414,12456]
expr_stmt [12434,12476]
===
match
---
name: end_of_log_mark [2636,2651]
name: end_of_log_mark [2636,2651]
===
match
---
name: time [11047,11051]
name: time [11067,11071]
===
match
---
name: self [12374,12378]
name: self [12394,12398]
===
match
---
string: "%Y_%m_%dT%H_%M_%S_%f" [4805,4827]
string: "%Y_%m_%dT%H_%M_%S_%f" [4805,4827]
===
match
---
name: key [4961,4964]
name: key [4961,4964]
===
match
---
name: int [12995,12998]
name: int [13015,13018]
===
match
---
name: log_id_template [3294,3309]
name: log_id_template [3294,3309]
===
match
---
trailer [3225,3241]
trailer [3225,3241]
===
match
---
name: ti [10927,10929]
name: ti [10947,10949]
===
match
---
name: handler [11413,11420]
name: handler [11433,11440]
===
match
---
name: setFormatter [11483,11495]
name: setFormatter [11503,11515]
===
match
---
name: metadata [5838,5846]
name: metadata [5838,5846]
===
match
---
simple_stmt [788,803]
simple_stmt [788,803]
===
match
---
name: closed [12394,12400]
name: closed [12414,12420]
===
match
---
import_from [1434,1490]
import_from [1434,1490]
===
match
---
simple_stmt [4961,5004]
simple_stmt [4961,5004]
===
match
---
operator: , [5179,5180]
operator: , [5179,5180]
===
match
---
parameters [5279,5367]
parameters [5279,5367]
===
match
---
name: MAX_LINE_PER_PAGE [2409,2426]
name: MAX_LINE_PER_PAGE [2409,2426]
===
match
---
trailer [4254,4261]
trailer [4254,4261]
===
match
---
operator: = [4068,4069]
operator: = [4068,4069]
===
match
---
trailer [7930,7942]
trailer [7950,7962]
===
match
---
name: query [9275,9280]
name: query [9295,9300]
===
match
---
atom_expr [6649,6656]
atom_expr [6649,6656]
===
match
---
string: "localhost:9200" [2759,2775]
string: "localhost:9200" [2759,2775]
===
match
---
tfpdef [2666,2684]
tfpdef [2666,2684]
===
match
---
name: quote [968,973]
name: quote [968,973]
===
match
---
atom_expr [12374,12400]
atom_expr [12394,12420]
===
match
---
name: closed [3197,3203]
name: closed [3197,3203]
===
match
---
name: self [3243,3247]
name: self [3243,3247]
===
match
---
trailer [11051,11053]
trailer [11071,11073]
===
match
---
trailer [6429,6439]
trailer [6429,6439]
===
match
---
name: strftime [4796,4804]
name: strftime [4796,4804]
===
match
---
decorator [12821,12831]
decorator [12841,12851]
===
match
---
decorated [4834,5210]
decorated [4834,5210]
===
match
---
operator: = [13400,13401]
operator: = [13420,13421]
===
match
---
operator: = [3568,3569]
operator: = [3568,3569]
===
match
---
operator: + [13642,13643]
operator: + [13662,13663]
===
match
---
argument [3370,3381]
argument [3370,3381]
===
match
---
name: getattr [5152,5159]
name: getattr [5152,5159]
===
match
---
name: self [12848,12852]
name: self [12868,12872]
===
match
---
trailer [12636,12658]
trailer [12656,12678]
===
match
---
tfpdef [2636,2656]
tfpdef [2636,2656]
===
match
---
name: handler [12707,12714]
name: handler [12727,12734]
===
match
---
or_test [3107,3122]
or_test [3107,3122]
===
match
---
trailer [11474,11482]
trailer [11494,11502]
===
match
---
name: label [3628,3633]
name: label [3628,3633]
===
match
---
subscriptlist [1550,1558]
subscriptlist [1550,1558]
===
match
---
testlist_comp [7913,7942]
testlist_comp [7933,7962]
===
match
---
return_stmt [8409,8481]
return_stmt [8429,8501]
===
match
---
name: try_number [13595,13605]
name: try_number [13615,13625]
===
match
---
operator: = [9747,9748]
operator: = [9767,9768]
===
match
---
name: execution_date [10872,10886]
name: execution_date [10892,10906]
===
match
---
import_from [814,849]
import_from [814,849]
===
match
---
name: end_of_log_mark [3486,3501]
name: end_of_log_mark [3486,3501]
===
match
---
name: urllib [948,954]
name: urllib [948,954]
===
match
---
expr_stmt [3669,3688]
expr_stmt [3669,3688]
===
match
---
operator: - [9656,9657]
operator: - [9676,9677]
===
match
---
atom_expr [10003,10025]
atom_expr [10023,10045]
===
match
---
trailer [10456,10474]
trailer [10476,10494]
===
match
---
param [3770,3785]
param [3770,3785]
===
match
---
name: render [3987,3993]
name: render [3987,3993]
===
match
---
name: write_stdout [12676,12688]
name: write_stdout [12696,12708]
===
match
---
expr_stmt [5928,5972]
expr_stmt [5928,5972]
===
match
---
dotted_name [1316,1351]
dotted_name [1316,1351]
===
match
---
comp_op [5831,5837]
comp_op [5831,5837]
===
match
---
trailer [10746,10753]
trailer [10766,10773]
===
match
---
if_stmt [12340,12493]
if_stmt [12360,12513]
===
match
---
string: """         Endpoint for streaming log.          :param ti: task instance object         :param try_number: try_number of the task instance         :param metadata: log metadata,                          can be used for steaming log reading and auto-tailing.         :return: a list of tuple with host and log documents, metadata.         """ [5406,5748]
string: """         Endpoint for streaming log.          :param ti: task instance object         :param try_number: try_number of the task instance         :param metadata: log metadata,                          can be used for steaming log reading and auto-tailing.         :return: a list of tuple with host and log documents, metadata.         """ [5406,5748]
===
match
---
arglist [13443,13606]
arglist [13463,13626]
===
match
---
name: e [10237,10238]
name: e [10257,10258]
===
match
---
name: search [9996,10002]
name: search [10016,10022]
===
match
---
operator: = [3682,3683]
operator: = [3682,3683]
===
match
---
name: log [4936,4939]
name: log [4936,4939]
===
match
---
name: self [3669,3673]
name: self [3669,3673]
===
match
---
atom_expr [10481,10487]
atom_expr [10501,10507]
===
match
---
operator: = [4324,4325]
operator: = [4324,4325]
===
match
---
name: logging [795,802]
name: logging [795,802]
===
match
---
comparison [6804,6827]
comparison [6804,6827]
===
match
---
expr_stmt [3463,3501]
expr_stmt [3463,3501]
===
match
---
name: airflow [1146,1153]
name: airflow [1146,1153]
===
match
---
name: strip [7783,7788]
name: strip [7803,7808]
===
match
---
operator: , [10887,10888]
operator: , [10907,10908]
===
match
---
name: logs_by_host [6036,6048]
name: logs_by_host [6036,6048]
===
match
---
name: kv [5148,5150]
name: kv [5148,5150]
===
match
---
name: context_set [11152,11163]
name: context_set [11172,11183]
===
match
---
name: sys [12748,12751]
name: sys [12768,12771]
===
match
---
name: dag_id [13443,13449]
name: dag_id [13463,13469]
===
match
---
name: self [5238,5242]
name: self [5238,5242]
===
match
---
expr_stmt [7377,7406]
expr_stmt [7387,7416]
===
match
---
operator: = [10581,10582]
operator: = [10601,10602]
===
match
---
tfpdef [2606,2626]
tfpdef [2606,2626]
===
match
---
testlist_comp [3610,3659]
testlist_comp [3610,3659]
===
match
---
string: 'try_number' [10909,10921]
string: 'try_number' [10929,10941]
===
match
---
trailer [3913,3927]
trailer [3913,3927]
===
match
---
operator: - [6690,6691]
operator: - [6690,6691]
===
match
---
tfpdef [4395,4419]
tfpdef [4395,4419]
===
match
---
simple_stmt [3697,3722]
simple_stmt [3697,3722]
===
match
---
import_from [1311,1374]
import_from [1311,1374]
===
match
---
atom_expr [9249,9326]
atom_expr [9269,9346]
===
match
---
operator: = [2799,2800]
operator: = [2799,2800]
===
match
---
operator: , [4281,4282]
operator: , [4281,4282]
===
match
---
name: es_kwargs [3372,3381]
name: es_kwargs [3372,3381]
===
match
---
name: property [12822,12830]
name: property [12842,12850]
===
match
---
parameters [2482,2902]
parameters [2482,2902]
===
match
---
operator: , [3368,3369]
operator: , [3368,3369]
===
match
---
string: 'Elasticsearch' [2449,2464]
string: 'Elasticsearch' [2449,2464]
===
match
---
name: json_fields [10672,10683]
name: json_fields [10692,10703]
===
match
---
param [4395,4419]
param [4395,4419]
===
match
---
trailer [6858,6860]
trailer [6858,6860]
===
match
---
operator: -> [4421,4423]
operator: -> [4421,4423]
===
match
---
name: handler [12379,12386]
name: handler [12399,12406]
===
match
---
name: ti [4097,4099]
name: ti [4097,4099]
===
match
---
param [10283,10288]
param [10303,10308]
===
match
---
name: ti [10791,10793]
name: ti [10811,10813]
===
match
---
param [2530,2535]
param [2530,2535]
===
match
---
string: 'offset' [5798,5806]
string: 'offset' [5798,5806]
===
match
---
name: closed [12139,12145]
name: closed [12159,12165]
===
match
---
or_test [12343,12400]
or_test [12363,12420]
===
match
---
name: self [3551,3555]
name: self [3551,3555]
===
match
---
name: metadata [6756,6764]
name: metadata [6756,6764]
===
match
---
atom_expr [6804,6822]
atom_expr [6804,6822]
===
match
---
parameters [12847,12853]
parameters [12867,12873]
===
match
---
testlist [7998,8015]
testlist [8018,8035]
===
match
---
name: offset [7419,7425]
name: offset [7433,7439]
===
match
---
name: json_fields [3595,3606]
name: json_fields [3595,3606]
===
match
---
name: Tuple [1544,1549]
name: Tuple [1544,1549]
===
match
---
expr_stmt [6756,6827]
expr_stmt [6756,6827]
===
match
---
trailer [9385,9393]
trailer [9405,9413]
===
match
---
atom_expr [13402,13616]
atom_expr [13422,13636]
===
match
---
name: get_external_log_url [12927,12947]
name: get_external_log_url [12947,12967]
===
match
---
operator: = [5106,5107]
operator: = [5106,5107]
===
match
---
operator: = [9374,9375]
operator: = [9394,9395]
===
match
---
name: log_id [9898,9904]
name: log_id [9918,9924]
===
match
---
atom_expr [13542,13570]
atom_expr [13562,13590]
===
match
---
name: range [7873,7878]
name: range [7893,7898]
===
match
---
name: dag_id [4245,4251]
name: dag_id [4245,4251]
===
match
---
name: message [6698,6705]
name: message [6698,6705]
===
match
---
param [13921,13926]
param [13941,13946]
===
match
---
name: try_number [4325,4335]
name: try_number [4325,4335]
===
match
---
name: mark_end_on_close [10457,10474]
name: mark_end_on_close [10477,10494]
===
match
---
argument [3994,4009]
argument [3994,4009]
===
match
---
operator: - [9671,9672]
operator: - [9691,9692]
===
match
---
comp_if [6682,6737]
comp_if [6682,6737]
===
match
---
simple_stmt [4053,4116]
simple_stmt [4053,4116]
===
match
---
operator: , [4986,4987]
operator: , [4986,4987]
===
match
---
import_from [1255,1310]
import_from [1255,1310]
===
match
---
argument [10701,11085]
argument [10721,11105]
===
match
---
name: close [12715,12720]
name: close [12735,12740]
===
match
---
name: now [6855,6858]
name: now [6855,6858]
===
match
---
name: self [10028,10032]
name: self [10048,10052]
===
match
---
name: Search [9249,9255]
name: Search [9269,9275]
===
match
---
param [5238,5242]
param [5238,5242]
===
match
---
simple_stmt [12611,12659]
simple_stmt [12631,12679]
===
match
---
arglist [9281,9310]
arglist [9301,9330]
===
match
---
trailer [8437,8444]
trailer [8457,8464]
===
match
---
atom_expr [8650,8666]
atom_expr [8670,8686]
===
match
---
trailer [3293,3310]
trailer [3293,3310]
===
match
---
simple_stmt [10324,10444]
simple_stmt [10344,10464]
===
match
---
tfpdef [2747,2756]
tfpdef [2747,2756]
===
match
---
name: self [3192,3196]
name: self [3192,3196]
===
match
---
operator: , [9295,9296]
operator: , [9315,9316]
===
match
---
string: 'https://' [13631,13641]
string: 'https://' [13651,13661]
===
match
---
operator: , [8701,8702]
operator: , [8721,8722]
===
match
---
import_from [850,879]
import_from [850,879]
===
match
---
trailer [3810,3832]
trailer [3810,3832]
===
match
---
atom_expr [9724,9746]
atom_expr [9744,9766]
===
match
---
operator: >= [7320,7322]
operator: >= [7325,7327]
===
match
---
atom_expr [4204,4345]
atom_expr [4204,4345]
===
match
---
atom_expr [3697,3713]
atom_expr [3697,3713]
===
match
---
name: set_context [10271,10282]
name: set_context [10291,10302]
===
match
---
simple_stmt [11934,11941]
simple_stmt [11954,11961]
===
match
---
name: handler [12441,12448]
name: handler [12461,12468]
===
match
---
operator: = [7124,7125]
operator: = [7124,7125]
===
match
---
simple_stmt [12772,12788]
simple_stmt [12792,12808]
===
match
---
tfpdef [5295,5311]
tfpdef [5295,5311]
===
match
---
arglist [4245,4335]
arglist [4245,4335]
===
match
---
name: last_log_ts [7112,7123]
name: last_log_ts [7112,7123]
===
match
---
name: cur_ts [6837,6843]
name: cur_ts [6837,6843]
===
match
---
operator: , [935,936]
operator: , [935,936]
===
match
---
comparison [7419,7440]
comparison [7429,7460]
===
match
---
name: handler [12616,12623]
name: handler [12636,12643]
===
match
---
simple_stmt [3221,3311]
simple_stmt [3221,3311]
===
match
---
argument [9297,9310]
argument [9317,9330]
===
match
---
trailer [2859,2870]
trailer [2859,2870]
===
match
---
trailer [7502,7524]
trailer [7522,7544]
===
match
---
name: ti [4159,4161]
name: ti [4159,4161]
===
match
---
name: utils [1268,1273]
name: utils [1268,1273]
===
match
---
atom_expr [10997,11010]
atom_expr [11017,11030]
===
match
---
name: _group_logs_by_host [4856,4875]
name: _group_logs_by_host [4856,4875]
===
match
---
param [2747,2776]
param [2747,2776]
===
match
---
operator: != [6706,6708]
operator: != [6706,6708]
===
match
---
name: json_format [10505,10516]
name: json_format [10525,10536]
===
match
---
expr_stmt [3510,3542]
expr_stmt [3510,3542]
===
match
---
name: message [8659,8666]
name: message [8679,8686]
===
match
---
operator: = [3607,3608]
operator: = [3607,3608]
===
match
---
return_stmt [5196,5209]
return_stmt [5196,5209]
===
match
---
name: base_log_folder [2544,2559]
name: base_log_folder [2544,2559]
===
match
---
trailer [5028,5033]
trailer [5028,5033]
===
match
---
name: self [12904,12908]
name: self [12924,12928]
===
match
---
trailer [8458,8480]
trailer [8478,8500]
===
match
---
name: self [11147,11151]
name: self [11167,11171]
===
match
---
argument [4263,4281]
argument [4263,4281]
===
match
---
operator: , [8041,8042]
operator: , [8061,8062]
===
match
---
string: 'range' [9359,9366]
string: 'range' [9379,9386]
===
match
---
name: _render_log_id [3731,3745]
name: _render_log_id [3731,3745]
===
match
---
trailer [3396,3405]
trailer [3396,3405]
===
match
---
param [12848,12852]
param [12868,12872]
===
match
---
param [2636,2657]
param [2636,2657]
===
match
---
dotted_name [1260,1281]
dotted_name [1260,1281]
===
match
---
name: pendulum [1094,1102]
name: pendulum [1094,1102]
===
match
---
trailer [3673,3681]
trailer [3673,3681]
===
match
---
name: models [1193,1199]
name: models [1193,1199]
===
match
---
atom_expr [12414,12433]
atom_expr [12434,12453]
===
match
---
tfpdef [8690,8701]
tfpdef [8710,8721]
===
match
---
trailer [6764,6778]
trailer [6764,6778]
===
match
---
name: ti [11574,11576]
name: ti [11594,11596]
===
match
---
trailer [13648,13657]
trailer [13668,13677]
===
match
---
name: str [12857,12860]
name: str [12877,12880]
===
match
---
string: 'Could not read log with log_id: %s, error: %s' [10176,10223]
string: 'Could not read log with log_id: %s, error: %s' [10196,10243]
===
match
---
trailer [10165,10175]
trailer [10185,10195]
===
match
---
trailer [10483,10487]
trailer [10503,10507]
===
match
---
atom_expr [11957,11979]
atom_expr [11977,11999]
===
match
---
atom_expr [7837,7863]
atom_expr [7857,7883]
===
match
---
argument [4245,4261]
argument [4245,4261]
===
match
---
try_stmt [9549,9906]
try_stmt [9569,9926]
===
match
---
param [4876,4880]
param [4876,4880]
===
match
---
atom_expr [4159,4188]
atom_expr [4159,4188]
===
match
---
trailer [3648,3654]
trailer [3648,3654]
===
match
---
test [6781,6827]
test [6781,6827]
===
match
---
operator: , [3768,3769]
operator: , [3768,3769]
===
match
---
name: task_id [10794,10801]
name: task_id [10814,10821]
===
match
---
param [8703,8715]
param [8723,8735]
===
match
---
operator: = [2757,2758]
operator: = [2757,2758]
===
match
---
simple_stmt [2912,3087]
simple_stmt [2912,3087]
===
match
---
name: item [6649,6653]
name: item [6649,6653]
===
match
---
simple_stmt [7991,8016]
simple_stmt [8011,8036]
===
match
---
comparison [7206,7248]
comparison [7206,7248]
===
match
---
name: kwargs [13967,13973]
name: kwargs [13987,13993]
===
match
---
or_test [7206,7345]
or_test [7206,7355]
===
match
---
atom_expr [4023,4039]
atom_expr [4023,4039]
===
match
---
arith_expr [9643,9659]
arith_expr [9663,9679]
===
match
---
name: super [3131,3136]
name: super [3131,3136]
===
match
---
atom_expr [4252,4261]
atom_expr [4252,4261]
===
match
---
trailer [7835,7891]
trailer [7855,7911]
===
match
---
parameters [5237,5243]
parameters [5237,5243]
===
match
---
name: bool [2680,2684]
name: bool [2680,2684]
===
match
---
name: format [13423,13429]
name: format [13443,13449]
===
match
---
suite [13007,13706]
suite [13027,13726]
===
match
---
trailer [10071,10073]
trailer [10091,10093]
===
match
---
operator: , [10231,10232]
operator: , [10251,10252]
===
match
---
name: json_fields [2721,2732]
name: json_fields [2721,2732]
===
match
---
atom_expr [10547,11100]
atom_expr [10567,11120]
===
match
---
name: write [12631,12636]
name: write [12651,12656]
===
match
---
simple_stmt [1434,1491]
simple_stmt [1434,1491]
===
match
---
trailer [3654,3659]
trailer [3654,3659]
===
match
---
simple_stmt [5982,6028]
simple_stmt [5982,6028]
===
match
---
import_as_names [921,942]
import_as_names [921,942]
===
match
---
operator: , [8714,8715]
operator: , [8734,8735]
===
match
---
trailer [5941,5956]
trailer [5941,5956]
===
match
---
string: "localhost:5601" [2801,2817]
string: "localhost:5601" [2801,2817]
===
match
---
expr_stmt [11586,11609]
expr_stmt [11606,11629]
===
match
---
trailer [6001,6027]
trailer [6001,6027]
===
match
---
simple_stmt [5016,5046]
simple_stmt [5016,5046]
===
match
---
comparison [7268,7292]
comparison [7268,7292]
===
match
---
atom_expr [6442,6458]
atom_expr [6442,6458]
===
match
---
expr_stmt [4961,5003]
expr_stmt [4961,5003]
===
match
---
expr_stmt [4142,4188]
expr_stmt [4142,4188]
===
match
---
atom_expr [12134,12145]
atom_expr [12154,12165]
===
match
---
atom_expr [7323,7345]
atom_expr [7332,7354]
===
match
---
atom_expr [3637,3659]
atom_expr [3637,3659]
===
match
---
name: logs_by_host [6669,6681]
name: logs_by_host [6669,6681]
===
match
---
trailer [13950,13959]
trailer [13970,13979]
===
match
---
name: log_line [8043,8051]
name: log_line [8063,8071]
===
match
---
operator: @ [12821,12822]
operator: @ [12841,12842]
===
match
---
operator: , [13570,13571]
operator: , [13590,13591]
===
match
---
string: 'try_number' [3914,3926]
string: 'try_number' [3914,3926]
===
match
---
name: len [6804,6807]
name: len [6804,6807]
===
match
---
if_stmt [11144,11307]
if_stmt [11164,11327]
===
match
---
suite [4882,5210]
suite [4882,5210]
===
match
---
suite [9553,9751]
suite [9573,9771]
===
match
---
trailer [4027,4039]
trailer [4027,4039]
===
match
---
trailer [6445,6458]
trailer [6445,6458]
===
match
---
atom_expr [11430,11440]
atom_expr [11450,11460]
===
match
---
name: kwargs [13929,13935]
name: kwargs [13949,13955]
===
match
---
sync_comp_for [7864,7889]
sync_comp_for [7884,7909]
===
match
---
import_from [943,973]
import_from [943,973]
===
match
---
name: es_kwargs [3095,3104]
name: es_kwargs [3095,3104]
===
match
---
atom_expr [8307,8323]
atom_expr [8327,8343]
===
match
---
expr_stmt [1524,1560]
expr_stmt [1524,1560]
===
match
---
expr_stmt [6091,6144]
expr_stmt [6091,6144]
===
match
---
atom_expr [3806,3832]
atom_expr [3806,3832]
===
match
---
name: self [13921,13925]
name: self [13941,13945]
===
match
---
arglist [5115,5185]
arglist [5115,5185]
===
match
---
name: airflow [1316,1323]
name: airflow [1316,1323]
===
match
---
simple_stmt [3425,3455]
simple_stmt [3425,3455]
===
match
---
expr_stmt [3221,3310]
expr_stmt [3221,3310]
===
match
---
name: offset [9675,9681]
name: offset [9695,9701]
===
match
---
atom_expr [5115,5135]
atom_expr [5115,5135]
===
match
---
comparison [9445,9472]
comparison [9465,9492]
===
match
---
trailer [12908,12917]
trailer [12928,12937]
===
match
---
name: using [9256,9261]
name: using [9276,9281]
===
match
---
name: metadata [5901,5909]
name: metadata [5901,5909]
===
match
---
operator: , [9896,9897]
operator: , [9916,9917]
===
match
---
name: search [9240,9246]
name: search [9260,9266]
===
match
---
simple_stmt [2396,2405]
simple_stmt [2396,2405]
===
match
---
atom_expr [10157,10240]
atom_expr [10177,10260]
===
match
---
atom_expr [12772,12787]
atom_expr [12792,12807]
===
match
---
name: task_instance [13542,13555]
name: task_instance [13562,13575]
===
match
---
argument [13443,13470]
argument [13463,13490]
===
match
---
trailer [9668,9670]
trailer [9688,9690]
===
match
---
name: str [3790,3793]
name: str [3790,3793]
===
match
---
string: 'task_id' [10776,10785]
string: 'task_id' [10796,10805]
===
match
---
funcdef [2470,3722]
funcdef [2470,3722]
===
match
---
expr_stmt [10530,11100]
expr_stmt [10550,11120]
===
match
---
import_name [803,813]
import_name [803,813]
===
match
---
suite [1625,13706]
suite [1625,13726]
===
match
---
name: append [5034,5040]
name: append [5034,5040]
===
match
---
operator: = [4270,4271]
operator: = [4270,4271]
===
match
---
simple_stmt [2409,2434]
simple_stmt [2409,2434]
===
match
---
name: metadata [7284,7292]
name: metadata [7284,7292]
===
match
---
decorated [12821,12918]
decorated [12841,12938]
===
match
---
expr_stmt [3590,3660]
expr_stmt [3590,3660]
===
match
---
name: metadata [9724,9732]
name: metadata [9744,9752]
===
match
---
trailer [10846,10868]
trailer [10866,10888]
===
match
---
name: log_id_jinja_template [3248,3269]
name: log_id_jinja_template [3248,3269]
===
match
---
parameters [10282,10306]
parameters [10302,10326]
===
match
---
name: str [2623,2626]
name: str [2623,2626]
===
match
---
dotted_name [1185,1199]
dotted_name [1185,1199]
===
match
---
comparison [7444,7480]
comparison [7464,7500]
===
match
---
name: list [8735,8739]
name: list [8755,8759]
===
match
---
trailer [9255,9274]
trailer [9275,9294]
===
match
---
operator: = [9247,9248]
operator: = [9267,9268]
===
match
---
name: log [1330,1333]
name: log [1330,1333]
===
match
---
name: defaultdict [838,849]
name: defaultdict [838,849]
===
match
---
trailer [5127,5133]
trailer [5127,5133]
===
match
---
operator: = [5899,5900]
operator: = [5899,5900]
===
match
---
string: """Format ES Record to match settings.LOG_FORMAT when used with json_format""" [8062,8140]
string: """Format ES Record to match settings.LOG_FORMAT when used with json_format""" [8082,8160]
===
match
---
number: 1 [7735,7736]
number: 1 [7755,7756]
===
match
---
name: execution_date [4395,4409]
name: execution_date [4395,4409]
===
match
---
simple_stmt [6756,6828]
simple_stmt [6756,6828]
===
match
---
operator: , [4312,4313]
operator: , [4312,4313]
===
match
---
name: __init__ [13912,13920]
name: __init__ [13932,13940]
===
match
---
name: logs_by_host [7968,7980]
name: logs_by_host [7988,8000]
===
match
---
atom_expr [3221,3241]
atom_expr [3221,3241]
===
match
---
return_stmt [4197,4345]
return_stmt [4197,4345]
===
match
---
name: write_stdout [2666,2678]
name: write_stdout [2666,2678]
===
match
---
atom_expr [7126,7172]
atom_expr [7126,7172]
===
match
---
trailer [10790,10802]
trailer [10810,10822]
===
match
---
name: bool [2707,2711]
name: bool [2707,2711]
===
match
---
operator: = [6633,6634]
operator: = [6633,6634]
===
match
---
lambdef [5141,5185]
lambdef [5141,5185]
===
match
---
trailer [11434,11440]
trailer [11454,11460]
===
match
---
string: 'match_phrase' [9281,9295]
string: 'match_phrase' [9301,9315]
===
match
---
string: 'max_offset' [9733,9745]
string: 'max_offset' [9753,9765]
===
match
---
number: 0 [9588,9589]
number: 0 [9608,9609]
===
match
---
operator: , [4978,4979]
operator: , [4978,4979]
===
match
---
name: self [10157,10161]
name: self [10177,10181]
===
match
---
name: EsLogMsgType [1524,1536]
name: EsLogMsgType [1524,1536]
===
match
---
trailer [10560,11100]
trailer [10580,11120]
===
match
---
name: log [1394,1397]
name: log [1394,1397]
===
match
---
suite [11164,11307]
suite [11184,11327]
===
match
---
operator: , [12952,12953]
operator: , [12972,12973]
===
match
---
tfpdef [2574,2596]
tfpdef [2574,2596]
===
match
---
trailer [1543,1560]
trailer [1543,1560]
===
match
---
suite [4948,5046]
suite [4948,5046]
===
match
---
simple_stmt [12702,12723]
simple_stmt [12722,12743]
===
match
---
name: hosted_log [7931,7941]
name: hosted_log [7951,7961]
===
match
---
parameters [4875,4881]
parameters [4875,4881]
===
match
---
name: str [1550,1553]
name: str [1550,1553]
===
match
---
name: try_number [12983,12993]
name: try_number [13003,13013]
===
match
---
atom_expr [11586,11602]
atom_expr [11606,11622]
===
match
---
simple_stmt [5892,5920]
simple_stmt [5892,5920]
===
match
---
atom_expr [5937,5972]
atom_expr [5937,5972]
===
match
---
name: JSONFormatter [10547,10560]
name: JSONFormatter [10567,10580]
===
match
---
param [8043,8051]
param [8063,8071]
===
match
---
param [12948,12953]
param [12968,12973]
===
match
---
atom_expr [10500,10516]
atom_expr [10520,10536]
===
match
---
atom [6635,6747]
atom [6635,6747]
===
match
---
trailer [9316,9326]
trailer [9336,9346]
===
match
---
name: end_of_log_mark [12642,12657]
name: end_of_log_mark [12662,12677]
===
match
---
param [8684,8689]
param [8704,8709]
===
match
---
operator: , [5959,5960]
operator: , [5959,5960]
===
match
---
name: len [7796,7799]
name: len [7816,7819]
===
match
---
trailer [4804,4828]
trailer [4804,4828]
===
match
---
suite [11921,11941]
suite [11941,11961]
===
match
---
sync_comp_for [6657,6737]
sync_comp_for [6657,6737]
===
match
---
atom_expr [5371,5396]
atom_expr [5371,5396]
===
match
---
name: Optional [5340,5348]
name: Optional [5340,5348]
===
match
---
simple_stmt [814,850]
simple_stmt [814,850]
===
match
---
name: url [13702,13705]
name: url [13722,13725]
===
match
---
operator: = [5879,5880]
operator: = [5879,5880]
===
match
---
suite [8053,8667]
suite [8073,8687]
===
match
---
dictorsetmaker [9376,9393]
dictorsetmaker [9396,9413]
===
match
---
name: metadata [7472,7480]
name: metadata [7492,7500]
===
match
---
trailer [7212,7217]
trailer [7212,7217]
===
match
---
name: pendulum [6846,6854]
name: pendulum [6846,6854]
===
match
---
argument [4283,4312]
argument [4283,4312]
===
match
---
name: log_id [13665,13671]
name: log_id [13685,13691]
===
match
---
name: try_number [3930,3940]
name: try_number [3930,3940]
===
match
---
name: metadata [9464,9472]
name: metadata [9484,9492]
===
match
---
operator: != [9949,9951]
operator: != [9969,9971]
===
match
---
operator: = [3860,3861]
operator: = [3860,3861]
===
match
---
name: self [3697,3701]
name: self [3697,3701]
===
match
---
name: end_of_log_mark [7767,7782]
name: end_of_log_mark [7787,7802]
===
match
---
atom_expr [10744,10753]
atom_expr [10764,10773]
===
match
---
atom [10708,11085]
atom [10728,11105]
===
match
---
arith_expr [7722,7736]
arith_expr [7742,7756]
===
match
---
atom_expr [11147,11163]
atom_expr [11167,11183]
===
match
---
name: offset [6105,6111]
name: offset [6105,6111]
===
match
---
suite [8324,8570]
suite [8344,8590]
===
match
---
name: TaskInstance [10293,10305]
name: TaskInstance [10313,10325]
===
match
---
atom_expr [11470,11511]
atom_expr [11490,11531]
===
match
---
number: 5 [7247,7248]
number: 5 [7247,7248]
===
match
---
operator: == [6823,6825]
operator: == [6823,6825]
===
match
---
trailer [10044,10062]
trailer [10064,10082]
===
match
---
name: jinja_context [3996,4009]
name: jinja_context [3996,4009]
===
match
---
arglist [4975,5002]
arglist [4975,5002]
===
match
---
simple_stmt [7112,7173]
simple_stmt [7112,7173]
===
match
---
if_stmt [8304,8570]
if_stmt [8324,8590]
===
match
---
name: str [10233,10236]
name: str [10253,10256]
===
match
---
simple_stmt [3953,4011]
simple_stmt [3953,4011]
===
match
---
trailer [6729,6735]
trailer [6729,6735]
===
match
---
name: int [5325,5328]
name: int [5325,5328]
===
match
---
import_name [788,802]
import_name [788,802]
===
match
---
name: MAX_LINE_PER_PAGE [10008,10025]
name: MAX_LINE_PER_PAGE [10028,10045]
===
match
---
operator: , [2684,2685]
operator: , [2684,2685]
===
match
---
trailer [4074,4096]
trailer [4074,4096]
===
match
---
atom_expr [10028,10037]
atom_expr [10048,10057]
===
match
---
name: metadata [5786,5794]
name: metadata [5786,5794]
===
match
---
operator: = [6844,6845]
operator: = [6844,6845]
===
match
---
name: last_log_ts [7218,7229]
name: last_log_ts [7218,7229]
===
match
---
operator: , [2534,2535]
operator: , [2534,2535]
===
match
---
name: datetime [4411,4419]
name: datetime [4411,4419]
===
match
---
arglist [5957,5971]
arglist [5957,5971]
===
match
---
name: grouped_logs [5016,5028]
name: grouped_logs [5016,5028]
===
match
---
name: self [11470,11474]
name: self [11490,11494]
===
match
---
tfpdef [2694,2711]
tfpdef [2694,2711]
===
match
---
number: 0 [5166,5167]
number: 0 [5166,5167]
===
match
---
simple_stmt [8749,9166]
simple_stmt [8769,9186]
===
match
---
return_stmt [12897,12917]
return_stmt [12917,12937]
===
match
---
trailer [13463,13470]
trailer [13483,13490]
===
match
---
operator: @ [4834,4835]
operator: @ [4834,4835]
===
match
---
operator: = [9261,9262]
operator: = [9281,9282]
===
match
---
atom_expr [12611,12658]
atom_expr [12631,12678]
===
match
---
name: log_id [5928,5934]
name: log_id [5928,5934]
===
match
---
trailer [13406,13422]
trailer [13426,13442]
===
match
---
simple_stmt [12414,12493]
simple_stmt [12434,12513]
===
match
---
name: lines [7726,7731]
name: lines [7746,7751]
===
match
---
atom_expr [6129,6144]
atom_expr [6129,6144]
===
match
---
atom_expr [9419,9433]
atom_expr [9439,9453]
===
match
---
or_test [7419,7480]
or_test [7429,7500]
===
match
---
if_stmt [11906,11941]
if_stmt [11926,11961]
===
match
---
expr_stmt [7494,7538]
expr_stmt [7514,7558]
===
match
---
operator: , [6008,6009]
operator: , [6008,6009]
===
match
---
arglist [3148,3182]
arglist [3148,3182]
===
match
---
trailer [5162,5165]
trailer [5162,5165]
===
match
---
simple_stmt [9829,9906]
simple_stmt [9849,9926]
===
match
---
expr_stmt [5982,6027]
expr_stmt [5982,6027]
===
match
---
trailer [9266,9273]
trailer [9286,9293]
===
match
---
operator: , [5328,5329]
operator: , [5328,5329]
===
match
---
simple_stmt [943,974]
simple_stmt [943,974]
===
match
---
expr_stmt [2438,2464]
expr_stmt [2438,2464]
===
match
---
name: self [11113,11117]
name: self [11133,11137]
===
match
---
atom_expr [2855,2895]
atom_expr [2855,2895]
===
match
---
expr_stmt [6421,6458]
expr_stmt [6421,6458]
===
match
---
atom_expr [10973,11011]
atom_expr [10993,11031]
===
match
---
expr_stmt [3320,3382]
expr_stmt [3320,3382]
===
match
---
trailer [10175,10240]
trailer [10195,10260]
===
match
---
string: 'host' [4980,4986]
string: 'host' [4980,4986]
===
match
---
name: ti [5957,5959]
name: ti [5957,5959]
===
match
---
name: _format_msg [7842,7853]
name: _format_msg [7862,7873]
===
match
---
trailer [7217,7230]
trailer [7217,7230]
===
match
---
if_stmt [9442,9906]
if_stmt [9462,9926]
===
match
---
name: airflow [1260,1267]
name: airflow [1260,1267]
===
match
---
simple_stmt [4774,4829]
simple_stmt [4774,4829]
===
match
---
trailer [3347,3361]
trailer [3347,3361]
===
match
---
atom_expr [11408,11441]
atom_expr [11428,11461]
===
match
---
simple_stmt [7709,7807]
simple_stmt [7729,7827]
===
match
---
trailer [7746,7750]
trailer [7766,7770]
===
match
---
suite [7099,7407]
suite [7099,7417]
===
match
---
string: 'download_logs' [9486,9501]
string: 'download_logs' [9506,9521]
===
match
---
simple_stmt [3320,3383]
simple_stmt [3320,3383]
===
match
---
atom_expr [6846,6860]
atom_expr [6846,6860]
===
match
---
name: self [4023,4027]
name: self [4023,4027]
===
match
---
name: parse [955,960]
name: parse [955,960]
===
match
---
not_test [5760,5772]
not_test [5760,5772]
===
match
---
name: frontend [2785,2793]
name: frontend [2785,2793]
===
match
---
name: __dict__ [13951,13959]
name: __dict__ [13971,13979]
===
match
---
comparison [7313,7345]
comparison [7313,7355]
===
match
---
funcdef [13908,13975]
funcdef [13928,13995]
===
match
---
expr_stmt [3095,3122]
expr_stmt [3095,3122]
===
match
---
name: self [3425,3429]
name: self [3425,3429]
===
match
---
name: str [6442,6445]
name: str [6442,6445]
===
match
---
string: 'message' [5170,5179]
string: 'message' [5170,5179]
===
match
---
suite [10517,11101]
suite [10537,11121]
===
match
---
trailer [11420,11429]
trailer [11440,11449]
===
match
---
simple_stmt [803,814]
simple_stmt [803,814]
===
match
---
atom_expr [11909,11920]
atom_expr [11929,11940]
===
match
---
name: PAGE [10033,10037]
name: PAGE [10053,10057]
===
match
---
operator: , [5311,5312]
operator: , [5311,5312]
===
match
---
suite [8341,8482]
suite [8361,8502]
===
match
---
name: try_number [11000,11010]
name: try_number [11020,11030]
===
match
---
string: 'offset' [5910,5918]
string: 'offset' [5910,5918]
===
match
---
operator: -> [3787,3789]
operator: -> [3787,3789]
===
match
---
suite [4129,4189]
suite [4129,4189]
===
match
---
name: context_set [11591,11602]
name: context_set [11611,11622]
===
match
---
name: super [12772,12777]
name: super [12792,12797]
===
match
---
simple_stmt [10157,10241]
simple_stmt [10177,10261]
===
match
---
name: exception [10166,10175]
name: exception [10186,10195]
===
match
---
trailer [4096,4115]
trailer [4096,4115]
===
match
---
operator: ** [3370,3372]
operator: ** [3370,3372]
===
match
---
trailer [8430,8437]
trailer [8450,8457]
===
match
---
name: utils [1388,1393]
name: utils [1388,1393]
===
match
---
trailer [12426,12433]
trailer [12446,12453]
===
match
---
name: sort [9312,9316]
name: sort [9332,9336]
===
match
---
expr_stmt [13625,13686]
expr_stmt [13645,13706]
===
match
---
name: timezone [7126,7134]
name: timezone [7126,7134]
===
match
---
comparison [7066,7098]
comparison [7066,7098]
===
match
---
simple_stmt [12897,12918]
simple_stmt [12917,12938]
===
match
---
simple_stmt [11320,11396]
simple_stmt [11340,11416]
===
match
---
name: task_instance [13450,13463]
name: task_instance [13470,13483]
===
match
---
name: filename_template [3165,3182]
name: filename_template [3165,3182]
===
match
---
name: max_log_line [9936,9948]
name: max_log_line [9956,9968]
===
match
---
trailer [11961,11979]
trailer [11981,11999]
===
match
---
operator: = [6440,6441]
operator: = [6440,6441]
===
match
---
operator: , [5389,5390]
operator: , [5389,5390]
===
match
---
trailer [3885,3887]
trailer [3885,3887]
===
match
---
name: stream [12427,12433]
name: stream [12447,12453]
===
match
---
expr_stmt [9240,9326]
expr_stmt [9260,9346]
===
match
---
name: str [10740,10743]
name: str [10760,10763]
===
match
---
simple_stmt [3551,3582]
simple_stmt [3551,3582]
===
match
---
suite [7696,7892]
suite [7716,7912]
===
match
---
return_stmt [13695,13705]
return_stmt [13715,13725]
===
match
---
simple_stmt [1180,1220]
simple_stmt [1180,1220]
===
match
---
trailer [8469,8477]
trailer [8489,8497]
===
match
---
name: Tuple [5371,5376]
name: Tuple [5371,5376]
===
match
---
comparison [12100,12120]
comparison [12120,12140]
===
match
---
operator: } [5809,5810]
operator: } [5809,5810]
===
match
---
simple_stmt [4197,4346]
simple_stmt [4197,4346]
===
match
---
atom_expr [7377,7399]
atom_expr [7387,7409]
===
match
---
operator: = [11603,11604]
operator: = [11623,11624]
===
match
---
string: 'offset' [6430,6438]
string: 'offset' [6430,6438]
===
match
---
name: jinja_context [3846,3859]
name: jinja_context [3846,3859]
===
match
---
name: lines [7689,7694]
name: lines [7709,7714]
===
match
---
name: log [10162,10165]
name: log [10182,10185]
===
match
---
atom_expr [10923,10941]
atom_expr [10943,10961]
===
match
---
atom [7912,7943]
atom [7932,7963]
===
match
---
comparison [5822,5846]
comparison [5822,5846]
===
match
---
name: formatter [11501,11510]
name: formatter [11521,11530]
===
match
---
simple_stmt [3463,3502]
simple_stmt [3463,3502]
===
match
---
expr_stmt [12797,12815]
expr_stmt [12817,12835]
===
match
---
simple_stmt [6091,6145]
simple_stmt [6091,6145]
===
match
---
name: log_id [9297,9303]
name: log_id [9317,9323]
===
match
---
name: self [10283,10287]
name: self [10303,10307]
===
match
---
suite [5397,8016]
suite [5397,8036]
===
match
---
atom_expr [6421,6439]
atom_expr [6421,6439]
===
match
---
trailer [10534,10544]
trailer [10554,10564]
===
match
---
operator: , [8688,8689]
operator: , [8708,8709]
===
match
---
atom_expr [11320,11332]
atom_expr [11340,11352]
===
match
---
operator: -> [12854,12856]
operator: -> [12874,12876]
===
match
---
number: 1000 [2429,2433]
number: 1000 [2429,2433]
===
match
---
name: self [13946,13950]
name: self [13966,13970]
===
match
---
number: 1 [6695,6696]
number: 1 [6695,6696]
===
match
---
name: TaskInstance [3756,3768]
name: TaskInstance [3756,3768]
===
match
---
atom_expr [3334,3382]
atom_expr [3334,3382]
===
match
---
name: base_log_folder [3148,3163]
name: base_log_folder [3148,3163]
===
match
---
name: next_offset [7429,7440]
name: next_offset [7448,7459]
===
match
---
atom [9922,9924]
atom [9942,9944]
===
match
---
name: self [12702,12706]
name: self [12722,12726]
===
match
---
exprlist [7948,7964]
exprlist [7968,7984]
===
match
---
operator: } [3121,3122]
operator: } [3121,3122]
===
match
---
name: stream [11357,11363]
name: stream [11377,11383]
===
match
---
trailer [12418,12426]
trailer [12438,12446]
===
match
---
number: 1 [5163,5164]
number: 1 [5163,5164]
===
match
---
name: json_format [8312,8323]
name: json_format [8332,8343]
===
match
---
name: log [5041,5044]
name: log [5041,5044]
===
match
---
tfpdef [12954,12981]
tfpdef [12974,13001]
===
match
---
name: execution_date [13527,13541]
name: execution_date [13547,13561]
===
match
---
name: metadata [9611,9619]
name: metadata [9631,9639]
===
match
---
operator: = [13594,13595]
operator: = [13614,13615]
===
match
---
name: set_context [11562,11573]
name: set_context [11582,11593]
===
match
---
atom_expr [5901,5919]
atom_expr [5901,5919]
===
match
---
factor [6694,6696]
factor [6694,6696]
===
match
---
name: stream [12387,12393]
name: stream [12407,12413]
===
match
---
suite [9536,9906]
suite [9556,9926]
===
match
---
expr_stmt [4891,4923]
expr_stmt [4891,4923]
===
match
---
operator: , [9366,9367]
operator: , [9386,9387]
===
match
---
number: 0 [6654,6655]
number: 0 [6654,6655]
===
match
---
name: self [11993,11997]
name: self [12013,12017]
===
match
---
trailer [12386,12393]
trailer [12406,12413]
===
match
---
classdef [1563,13706]
classdef [1563,13726]
===
match
---
name: FileTaskHandler [1359,1374]
name: FileTaskHandler [1359,1374]
===
match
---
trailer [12714,12720]
trailer [12734,12740]
===
match
---
name: close [12780,12785]
name: close [12800,12805]
===
match
---
suite [10315,11610]
suite [10335,11630]
===
match
---
name: write_stdout [3530,3542]
name: write_stdout [3530,3542]
===
match
---
tfpdef [8703,8714]
tfpdef [8723,8734]
===
match
---
name: defaultdict [4906,4917]
name: defaultdict [4906,4917]
===
match
---
suite [5847,5883]
suite [5847,5883]
===
match
---
simple_stmt [13946,13975]
simple_stmt [13966,13995]
===
match
---
expr_stmt [5786,5810]
expr_stmt [5786,5810]
===
match
---
name: split [3649,3654]
name: split [3649,3654]
===
match
---
name: diff [7213,7217]
name: diff [7213,7217]
===
match
---
name: format [4225,4231]
name: format [4225,4231]
===
match
---
trailer [13966,13974]
trailer [13986,13994]
===
match
---
name: try_number [13584,13594]
name: try_number [13604,13614]
===
match
---
operator: = [3928,3929]
operator: = [3928,3929]
===
match
---
if_stmt [11110,11578]
if_stmt [11130,11598]
===
match
---
name: next_offset [6446,6457]
name: next_offset [6446,6457]
===
match
---
string: 'max_offset' [7268,7280]
string: 'max_offset' [7268,7280]
===
match
---
funcdef [11615,12816]
funcdef [11635,12836]
===
match
---
trailer [1549,1559]
trailer [1549,1559]
===
match
---
simple_stmt [12024,12031]
simple_stmt [12044,12051]
===
match
---
expr_stmt [7112,7172]
expr_stmt [7112,7172]
===
match
---
atom_expr [7796,7806]
atom_expr [7816,7826]
===
match
---
operator: @ [4351,4352]
operator: @ [4351,4352]
===
match
---
operator: = [11333,11334]
operator: = [11353,11354]
===
match
---
name: next_offset [6091,6102]
name: next_offset [6091,6102]
===
match
---
trailer [10063,10071]
trailer [10083,10091]
===
match
---
param [8037,8042]
param [8057,8062]
===
match
---
operator: = [5140,5141]
operator: = [5140,5141]
===
match
---
name: self [4204,4208]
name: self [4204,4208]
===
match
---
name: frontend [3408,3416]
name: frontend [3408,3416]
===
match
---
expr_stmt [9724,9750]
expr_stmt [9744,9770]
===
match
---
name: dag_id [13464,13470]
name: dag_id [13484,13490]
===
match
---
trailer [9358,9395]
trailer [9378,9415]
===
match
---
simple_stmt [10250,10262]
simple_stmt [10270,10282]
===
match
---
trailer [13677,13685]
trailer [13697,13705]
===
match
---
number: 1 [6135,6136]
number: 1 [6135,6136]
===
match
---
trailer [9837,9847]
trailer [9857,9867]
===
match
---
operator: , [10223,10224]
operator: , [10243,10244]
===
match
---
atom_expr [10667,10683]
atom_expr [10687,10703]
===
match
---
operator: = [2853,2854]
operator: = [2853,2854]
===
match
---
atom_expr [3425,3447]
atom_expr [3425,3447]
===
match
---
name: dag_id [4255,4261]
name: dag_id [4255,4261]
===
match
---
simple_stmt [9611,9682]
simple_stmt [9631,9702]
===
match
---
atom_expr [2838,2852]
atom_expr [2838,2852]
===
match
---
name: _read [5274,5279]
name: _read [5274,5279]
===
match
---
name: mark_end_on_close [3430,3447]
name: mark_end_on_close [3430,3447]
===
match
---
name: update [13960,13966]
name: update [13980,13986]
===
match
---
return_stmt [5253,5264]
return_stmt [5253,5264]
===
match
---
atom_expr [1539,1560]
atom_expr [1539,1560]
===
match
---
name: sorted [5108,5114]
name: sorted [5108,5114]
===
match
---
name: self [3806,3810]
name: self [3806,3810]
===
match
---
expr_stmt [3551,3581]
expr_stmt [3551,3581]
===
match
---
name: TaskInstance [12969,12981]
name: TaskInstance [12989,13001]
===
match
---
operator: , [2817,2818]
operator: , [2817,2818]
===
match
---
atom_expr [7527,7538]
atom_expr [7547,7558]
===
match
---
simple_stmt [4437,4766]
simple_stmt [4437,4766]
===
match
---
name: key [5029,5032]
name: key [5029,5032]
===
match
---
name: Elasticsearch [3348,3361]
name: Elasticsearch [3348,3361]
===
match
---
string: """Helper class to read ES Logs and re-format it to match settings.LOG_FORMAT""" [13733,13813]
string: """Helper class to read ES Logs and re-format it to match settings.LOG_FORMAT""" [13753,13833]
===
match
---
name: context_set [3702,3713]
name: context_set [3702,3713]
===
match
---
operator: -> [10307,10309]
operator: -> [10327,10329]
===
match
---
funcdef [5270,8016]
funcdef [5270,8036]
===
match
---
atom_expr [7741,7758]
atom_expr [7761,7778]
===
match
---
atom_expr [10233,10239]
atom_expr [10253,10259]
===
match
---
trailer [3138,3147]
trailer [3138,3147]
===
match
---
name: cur_ts [7206,7212]
name: cur_ts [7206,7212]
===
match
---
name: self [10530,10534]
name: self [10550,10554]
===
match
---
simple_stmt [13733,13814]
simple_stmt [13753,13834]
===
match
---
name: str [2795,2798]
name: str [2795,2798]
===
match
---
name: metadata [5764,5772]
name: metadata [5764,5772]
===
match
---
name: self [12948,12952]
name: self [12968,12972]
===
match
---
trailer [5040,5045]
trailer [5040,5045]
===
match
---
atom_expr [13644,13686]
atom_expr [13664,13706]
===
match
---
simple_stmt [3510,3543]
simple_stmt [3510,3543]
===
match
---
trailer [3594,3606]
trailer [3594,3606]
===
match
---
operator: = [6103,6104]
operator: = [6103,6104]
===
match
---
name: utils [1447,1452]
name: utils [1447,1452]
===
match
---
name: execute [9661,9668]
name: execute [9681,9688]
===
match
---
and_test [7268,7345]
and_test [7268,7355]
===
match
---
atom_expr [3392,3405]
atom_expr [3392,3405]
===
match
---
name: grouped_logs [5115,5127]
name: grouped_logs [5115,5127]
===
match
---
simple_stmt [7377,7407]
simple_stmt [7387,7417]
===
match
---
atom_expr [10787,10802]
atom_expr [10807,10822]
===
match
---
name: str [13003,13006]
name: str [13023,13026]
===
match
---
atom_expr [11335,11379]
atom_expr [11355,11399]
===
match
---
name: formatter [10587,10596]
name: formatter [10607,10616]
===
match
---
trailer [10671,10683]
trailer [10691,10703]
===
match
---
operator: , [2711,2712]
operator: , [2711,2712]
===
match
---
operator: = [7400,7401]
operator: = [7410,7411]
===
match
---
name: dict [2847,2851]
name: dict [2847,2851]
===
match
---
argument [5137,5185]
argument [5137,5185]
===
match
---
expr_stmt [6619,6747]
expr_stmt [6619,6747]
===
match
---
param [2666,2685]
param [2666,2685]
===
match
---
name: self [8684,8688]
name: self [8704,8708]
===
match
---
name: metadata [6018,6026]
name: metadata [6018,6026]
===
match
---
simple_stmt [9989,10074]
simple_stmt [10009,10094]
===
match
---
trailer [12347,12355]
trailer [12367,12375]
===
match
---
atom_expr [12904,12917]
atom_expr [12924,12937]
===
match
---
name: self [3590,3594]
name: self [3590,3594]
===
match
---
name: log_id_jinja_template [3965,3986]
name: log_id_jinja_template [3965,3986]
===
match
---
operator: = [3714,3715]
operator: = [3714,3715]
===
match
---
name: ti [10997,10999]
name: ti [11017,11019]
===
match
---
atom_expr [3243,3269]
atom_expr [3243,3269]
===
match
---
name: metadata [7141,7149]
name: metadata [7141,7149]
===
match
---
atom [3362,3368]
atom [3362,3368]
===
match
---
trailer [7750,7758]
trailer [7770,7778]
===
match
---
name: offset [9368,9374]
name: offset [9388,9394]
===
match
---
simple_stmt [9404,9434]
simple_stmt [9424,9454]
===
match
---
string: 'max_offset' [7332,7344]
string: 'max_offset' [7341,7353]
===
match
---
suite [2903,3722]
suite [2903,3722]
===
match
---
name: Exception [8501,8510]
name: Exception [8521,8530]
===
match
---
subscriptlist [5377,5395]
subscriptlist [5377,5395]
===
match
---
simple_stmt [6036,6082]
simple_stmt [6036,6082]
===
match
---
trailer [6735,6737]
trailer [6735,6737]
===
match
---
not_test [11953,11979]
not_test [11973,11999]
===
match
---
trailer [11500,11510]
trailer [11520,11530]
===
match
---
name: max_log_line [9404,9416]
name: max_log_line [9424,9436]
===
match
---
operator: , [11085,11086]
operator: , [11105,11106]
===
match
---
atom_expr [9477,9502]
atom_expr [9497,9522]
===
match
---
operator: = [12746,12747]
operator: = [12766,12767]
===
match
---
if_stmt [7185,7407]
if_stmt [7185,7417]
===
match
---
number: 9 [11063,11064]
number: 9 [11083,11084]
===
match
---
operator: = [4297,4298]
operator: = [4297,4298]
===
match
---
atom_expr [11364,11378]
atom_expr [11384,11398]
===
match
---
trailer [4273,4281]
trailer [4273,4281]
===
match
---
name: _group_logs_by_host [6056,6075]
name: _group_logs_by_host [6056,6075]
===
match
---
funcdef [5215,5265]
funcdef [5215,5265]
===
match
---
trailer [4099,4114]
trailer [4099,4114]
===
match
---
name: handler [11325,11332]
name: handler [11345,11352]
===
match
---
comparison [12343,12370]
comparison [12363,12390]
===
match
---
operator: * [10026,10027]
operator: * [10046,10047]
===
match
---
operator: , [13513,13514]
operator: , [13533,13534]
===
match
---
name: fmt [10578,10581]
name: fmt [10598,10601]
===
match
---
simple_stmt [7494,7539]
simple_stmt [7514,7559]
===
match
---
name: self [3510,3514]
name: self [3510,3514]
===
match
---
suite [3794,4346]
suite [3794,4346]
===
match
---
atom_expr [12797,12808]
atom_expr [12817,12828]
===
match
---
suite [9812,9906]
suite [9832,9926]
===
match
---
name: self [6051,6055]
name: self [6051,6055]
===
match
---
operator: = [3204,3205]
operator: = [3204,3205]
===
match
---
name: write_stdout [3515,3527]
name: write_stdout [3515,3527]
===
match
---
name: helpers [1274,1281]
name: helpers [1274,1281]
===
match
---
name: str [7527,7530]
name: str [7547,7550]
===
match
---
expr_stmt [12735,12762]
expr_stmt [12755,12782]
===
match
---
tfpdef [5313,5328]
tfpdef [5313,5328]
===
match
---
operator: , [3750,3751]
operator: , [3750,3751]
===
match
---
trailer [7230,7241]
trailer [7230,7241]
===
match
---
testlist_comp [7912,7980]
testlist_comp [7932,8000]
===
match
---
name: len [7722,7725]
name: len [7742,7745]
===
match
---
name: str [8698,8701]
name: str [8718,8721]
===
match
---
operator: , [2737,2738]
operator: , [2737,2738]
===
match
---
operator: , [11011,11012]
operator: , [11031,11032]
===
match
---
trailer [11913,11920]
trailer [11933,11940]
===
match
---
operator: = [9417,9418]
operator: = [9437,9438]
===
match
---
dotted_name [948,960]
dotted_name [948,960]
===
match
---
atom_expr [7722,7732]
atom_expr [7742,7752]
===
match
---
suite [11639,12816]
suite [11659,12836]
===
match
---
atom_expr [7826,7891]
atom_expr [7846,7911]
===
match
---
name: json_format [3570,3581]
name: json_format [3570,3581]
===
match
---
name: try_number [10930,10940]
name: try_number [10950,10960]
===
match
---
atom_expr [3320,3331]
atom_expr [3320,3331]
===
match
---
operator: , [2656,2657]
operator: , [2656,2657]
===
match
---
dictorsetmaker [5798,5809]
dictorsetmaker [5798,5809]
===
match
---
name: dict [5349,5353]
name: dict [5349,5353]
===
match
---
name: message [7751,7758]
name: message [7771,7778]
===
match
---
trailer [5956,5972]
trailer [5956,5972]
===
match
---
param [10289,10305]
param [10309,10325]
===
match
---
name: List [921,925]
name: List [921,925]
===
match
---
name: logs [9989,9993]
name: logs [10009,10013]
===
match
---
trailer [7149,7171]
trailer [7149,7171]
===
match
---
name: json_format [3556,3567]
name: json_format [3556,3567]
===
match
---
operator: = [13541,13542]
operator: = [13561,13562]
===
match
---
name: self [8307,8311]
name: self [8327,8331]
===
match
---
name: stream [12624,12630]
name: stream [12644,12650]
===
match
---
operator: { [9375,9376]
operator: { [9395,9396]
===
match
---
atom_expr [4070,4115]
atom_expr [4070,4115]
===
match
---
if_stmt [12668,12763]
if_stmt [12688,12783]
===
match
---
name: JSONFormatter [1420,1433]
name: JSONFormatter [1420,1433]
===
match
---
simple_stmt [4142,4189]
simple_stmt [4142,4189]
===
match
---
atom_expr [9262,9273]
atom_expr [9282,9293]
===
match
---
trailer [12779,12785]
trailer [12799,12805]
===
match
---
name: kv [5160,5162]
name: kv [5160,5162]
===
match
---
name: _clean_execution_date [4075,4096]
name: _clean_execution_date [4075,4096]
===
match
---
name: sys [810,813]
name: sys [810,813]
===
match
---
factor [6134,6136]
factor [6134,6136]
===
match
---
name: max_log_line [9643,9655]
name: max_log_line [9663,9675]
===
match
---
trailer [10743,10754]
trailer [10763,10774]
===
match
---
atom_expr [12671,12688]
atom_expr [12691,12708]
===
match
---
operator: , [7917,7918]
operator: , [7937,7938]
===
match
---
name: List [1539,1543]
name: List [1539,1543]
===
match
---
trailer [11117,11130]
trailer [11137,11150]
===
match
---
atom_expr [12343,12362]
atom_expr [12363,12382]
===
match
---
atom_expr [12436,12456]
atom_expr [12456,12476]
===
match
---
name: self [5937,5941]
name: self [5937,5941]
===
match
---
atom_expr [4097,4114]
atom_expr [4097,4114]
===
match
---
import_from [1103,1139]
import_from [1103,1139]
===
match
---
name: _format_msg [8025,8036]
name: _format_msg [8045,8056]
===
match
---
name: metadata [6421,6429]
name: metadata [6421,6429]
===
match
---
trailer [12738,12745]
trailer [12758,12765]
===
match
---
expr_stmt [11993,12011]
expr_stmt [12013,12031]
===
match
---
argument [9256,9273]
argument [9276,9293]
===
match
---
import_from [1375,1433]
import_from [1375,1433]
===
match
---
expr_stmt [5892,5919]
expr_stmt [5892,5919]
===
match
---
simple_stmt [1375,1434]
simple_stmt [1375,1434]
===
match
---
expr_stmt [3900,3940]
expr_stmt [3900,3940]
===
match
---
trailer [6137,6144]
trailer [6137,6144]
===
match
---
if_stmt [9570,9751]
if_stmt [9590,9771]
===
match
---
expr_stmt [3192,3211]
expr_stmt [3192,3211]
===
match
---
simple_stmt [1220,1255]
simple_stmt [1220,1255]
===
match
---
name: ti [10481,10483]
name: ti [10501,10503]
===
match
---
trailer [11412,11420]
trailer [11432,11440]
===
match
---
parameters [4394,4420]
parameters [4394,4420]
===
match
---
atom_expr [3463,3483]
atom_expr [3463,3483]
===
match
---
argument [13665,13685]
argument [13685,13705]
===
match
---
name: str [10787,10790]
name: str [10807,10810]
===
match
---
import_from [880,901]
import_from [880,901]
===
match
---
name: task_instance [13492,13505]
name: task_instance [13512,13525]
===
match
---
if_stmt [7063,7407]
if_stmt [7063,7417]
===
match
---
name: int [3782,3785]
name: int [3782,3785]
===
match
---
operator: , [5168,5169]
operator: , [5168,5169]
===
match
---
expr_stmt [3392,3416]
expr_stmt [3392,3416]
===
match
---
name: filename_template [2574,2591]
name: filename_template [2574,2591]
===
match
---
name: metadata [5330,5338]
name: metadata [5330,5338]
===
match
---
trailer [12630,12636]
trailer [12650,12656]
===
match
---
simple_stmt [11300,11307]
simple_stmt [11320,11327]
===
match
---
param [2721,2738]
param [2721,2738]
===
match
---
name: frontend [13649,13657]
name: frontend [13669,13677]
===
match
---
suite [12121,12172]
suite [12141,12192]
===
match
---
tfpdef [2785,2798]
tfpdef [2785,2798]
===
match
---
tfpdef [2721,2737]
tfpdef [2721,2737]
===
match
---
operator: = [3270,3271]
operator: = [3270,3271]
===
match
---
operator: , [13470,13471]
operator: , [13490,13491]
===
match
---
name: _fmt [10597,10601]
name: _fmt [10617,10621]
===
match
---
trailer [11482,11495]
trailer [11502,11515]
===
match
---
simple_stmt [1141,1180]
simple_stmt [1141,1180]
===
match
---
simple_stmt [5099,5187]
simple_stmt [5099,5187]
===
match
---
param [2544,2565]
param [2544,2565]
===
match
---
operator: , [925,926]
operator: , [925,926]
===
match
---
atom_expr [12100,12112]
atom_expr [12120,12132]
===
match
---
trailer [13959,13966]
trailer [13979,13986]
===
match
---
name: TaskInstance [5299,5311]
name: TaskInstance [5299,5311]
===
match
---
name: EsLogMsgType [5377,5389]
name: EsLogMsgType [5377,5389]
===
match
---
atom_expr [3510,3527]
atom_expr [3510,3527]
===
match
---
name: self [8037,8041]
name: self [8057,8061]
===
match
---
except_clause [8494,8510]
except_clause [8514,8530]
===
match
---
tfpdef [3752,3768]
tfpdef [3752,3768]
===
match
---
comparison [9507,9535]
comparison [9527,9555]
===
match
---
string: '_' [5181,5184]
string: '_' [5181,5184]
===
match
---
name: self [10667,10671]
name: self [10687,10691]
===
match
---
name: logs [6794,6798]
name: logs [6794,6798]
===
match
---
name: label [3610,3615]
name: label [3610,3615]
===
match
---
name: __stdout__ [11368,11378]
name: __stdout__ [11388,11398]
===
match
---
operator: , [2895,2896]
operator: , [2895,2896]
===
match
---
name: metadata [7377,7385]
name: metadata [7387,7395]
===
match
---
import_name [1087,1102]
import_name [1087,1102]
===
match
---
name: dict [5391,5395]
name: dict [5391,5395]
===
match
---
string: 'last_log_timestamp' [7503,7523]
string: 'last_log_timestamp' [7523,7543]
===
match
---
dotted_name [1439,1470]
dotted_name [1439,1470]
===
match
---
suite [5244,5265]
suite [5244,5265]
===
match
---
argument [13527,13570]
argument [13547,13590]
===
match
---
name: stdout [12739,12745]
name: stdout [12759,12765]
===
match
---
name: item [6661,6665]
name: item [6661,6665]
===
match
---
name: Exception [9770,9779]
name: Exception [9790,9799]
===
match
---
number: 10 [11057,11059]
number: 10 [11077,11079]
===
match
---
trailer [12777,12779]
trailer [12797,12799]
===
match
---
trailer [5376,5396]
trailer [5376,5396]
===
match
---
trailer [10929,10940]
trailer [10949,10960]
===
match
---
name: elasticsearch_dsl [1108,1125]
name: elasticsearch_dsl [1108,1125]
===
match
---
parameters [8683,8731]
parameters [8703,8751]
===
match
---
name: self [9262,9266]
name: self [9282,9286]
===
match
---
name: metadata [7323,7331]
name: metadata [7332,7340]
===
match
---
name: self [10452,10456]
name: self [10472,10476]
===
match
---
name: self [4070,4074]
name: self [4070,4074]
===
match
---
name: try_number [5961,5971]
name: try_number [5961,5971]
===
match
---
operator: = [10666,10667]
operator: = [10686,10687]
===
match
---
operator: , [10683,10684]
operator: , [10703,10704]
===
match
---
name: in_minutes [7231,7241]
name: in_minutes [7231,7241]
===
match
---
tfpdef [3770,3785]
tfpdef [3770,3785]
===
match
---
name: result [5099,5105]
name: result [5099,5105]
===
match
---
name: es_read [5994,6001]
name: es_read [5994,6001]
===
match
---
trailer [2870,2895]
trailer [2870,2895]
===
match
---
funcdef [4369,4829]
funcdef [4369,4829]
===
match
---
atom_expr [9996,10073]
atom_expr [10016,10093]
===
match
---
atom_expr [7206,7243]
atom_expr [7206,7243]
===
match
---
factor [6690,6692]
factor [6690,6692]
===
match
---
operator: = [1537,1538]
operator: = [1537,1538]
===
match
---
name: configuration [1154,1167]
name: configuration [1154,1167]
===
match
---
operator: = [5987,5988]
operator: = [5987,5988]
===
match
---
name: self [11909,11913]
name: self [11929,11933]
===
match
---
simple_stmt [880,902]
simple_stmt [880,902]
===
match
---
name: logs [9915,9919]
name: logs [9935,9939]
===
match
---
name: conf [2855,2859]
name: conf [2855,2859]
===
match
---
trailer [9425,9431]
trailer [9445,9451]
===
match
---
trailer [3136,3138]
trailer [3136,3138]
===
match
---
atom_expr [6051,6081]
atom_expr [6051,6081]
===
match
---
name: logs [4943,4947]
name: logs [4943,4947]
===
match
---
trailer [8311,8323]
trailer [8331,8343]
===
match
---
name: logs [6129,6133]
name: logs [6129,6133]
===
match
---
operator: , [5293,5294]
operator: , [5293,5294]
===
match
---
trailer [6693,6697]
trailer [6693,6697]
===
match
---
trailer [9660,9668]
trailer [9680,9688]
===
match
---
operator: * [11054,11055]
operator: * [11074,11075]
===
match
---
operator: - [7733,7734]
operator: - [7753,7754]
===
match
---
simple_stmt [11470,11528]
simple_stmt [11490,11548]
===
match
---
name: try_number [4314,4324]
name: try_number [4314,4324]
===
match
---
return_stmt [7819,7891]
return_stmt [7839,7911]
===
match
---
name: log_id_template [13407,13422]
name: log_id_template [13427,13442]
===
match
---
operator: , [2596,2597]
operator: , [2596,2597]
===
match
---
operator: - [6694,6695]
operator: - [6694,6695]
===
match
---
atom_expr [6709,6737]
atom_expr [6709,6737]
===
match
---
simple_stmt [8409,8482]
simple_stmt [8429,8502]
===
match
---
operator: = [7719,7720]
operator: = [7739,7740]
===
match
---
name: self [2530,2534]
name: self [2530,2534]
===
match
---
name: metadata [5860,5868]
name: metadata [5860,5868]
===
match
---
funcdef [12923,13706]
funcdef [12943,13726]
===
match
---
atom_expr [11554,11577]
atom_expr [11574,11597]
===
match
---
number: 0 [6826,6827]
number: 0 [6826,6827]
===
match
---
name: loading_hosts [6808,6821]
name: loading_hosts [6808,6821]
===
match
---
name: log_id_template [4209,4224]
name: log_id_template [4209,4224]
===
match
---
atom_expr [11047,11053]
atom_expr [11067,11073]
===
match
---
name: _read_grouped_logs [5219,5237]
name: _read_grouped_logs [5219,5237]
===
match
---
atom_expr [13492,13513]
atom_expr [13512,13533]
===
match
---
simple_stmt [8643,8667]
simple_stmt [8663,8687]
===
match
---
name: _render_log_id [5942,5956]
name: _render_log_id [5942,5956]
===
match
---
simple_stmt [8565,8570]
simple_stmt [8585,8590]
===
match
---
arglist [9359,9394]
arglist [9379,9414]
===
match
---
string: 'last_log_timestamp' [7066,7086]
string: 'last_log_timestamp' [7066,7086]
===
match
---
operator: -> [5368,5370]
operator: -> [5368,5370]
===
match
---
suite [10140,10241]
suite [10160,10261]
===
match
---
funcdef [8021,8667]
funcdef [8041,8687]
===
match
---
name: datetime [871,879]
name: datetime [871,879]
===
match
---
name: self [11408,11412]
name: self [11428,11432]
===
match
---
atom_expr [4781,4828]
atom_expr [4781,4828]
===
match
---
trailer [6653,6656]
trailer [6653,6656]
===
match
---
operator: , [12981,12982]
operator: , [13001,13002]
===
match
---
name: stream [12356,12362]
name: stream [12376,12382]
===
match
---
arglist [5160,5184]
arglist [5160,5184]
===
match
---
name: self [12797,12801]
name: self [12817,12821]
===
match
---
name: self [12671,12675]
name: self [12691,12695]
===
match
---
trailer [7241,7243]
trailer [7241,7243]
===
match
---
operator: = [9343,9344]
operator: = [9363,9364]
===
match
---
comp_op [9520,9526]
comp_op [9540,9546]
===
match
---
expr_stmt [2396,2404]
expr_stmt [2396,2404]
===
match
---
name: formatter [10535,10544]
name: formatter [10555,10564]
===
match
---
testlist_comp [7837,7889]
testlist_comp [7857,7909]
===
match
---
name: offset [6010,6016]
name: offset [6010,6016]
===
match
---
name: typing [907,913]
name: typing [907,913]
===
match
---
trailer [13422,13429]
trailer [13442,13449]
===
match
---
suite [3833,4011]
suite [3833,4011]
===
match
---
name: task_id [4263,4270]
name: task_id [4263,4270]
===
match
---
trailer [10586,10596]
trailer [10606,10616]
===
match
---
expr_stmt [6837,6860]
expr_stmt [6837,6860]
===
match
---
trailer [10793,10801]
trailer [10813,10821]
===
match
---
dotted_name [1225,1238]
dotted_name [1225,1238]
===
match
---
expr_stmt [9336,9395]
expr_stmt [9356,9415]
===
match
---
trailer [6689,6693]
trailer [6689,6693]
===
match
---
trailer [10032,10037]
trailer [10052,10057]
===
match
---
param [5289,5294]
param [5289,5294]
===
match
---
operator: , [3241,3242]
operator: , [3241,3242]
===
match
---
name: lines [7741,7746]
name: lines [7761,7766]
===
match
---
operator: = [7909,7910]
operator: = [7929,7930]
===
match
---
name: log_range [7879,7888]
name: log_range [7899,7908]
===
match
---
simple_stmt [12797,12816]
simple_stmt [12817,12836]
===
match
---
trailer [4176,4186]
trailer [4176,4186]
===
match
---
trailer [11324,11332]
trailer [11344,11352]
===
match
---
atom_expr [9636,9681]
atom_expr [9656,9701]
===
match
---
operator: = [4251,4252]
operator: = [4251,4252]
===
match
---
name: items [5128,5133]
name: items [5128,5133]
===
match
---
name: log_range [7709,7718]
name: log_range [7729,7738]
===
match
---
if_stmt [10497,11101]
if_stmt [10517,11121]
===
match
---
arglist [10993,11010]
arglist [11013,11030]
===
match
---
trailer [9619,9633]
trailer [9639,9653]
===
match
---
not_test [6115,6123]
not_test [6115,6123]
===
match
---
operator: } [9393,9394]
operator: } [9413,9414]
===
match
---
suite [9703,9751]
suite [9723,9771]
===
match
---
string: 'dag_id' [10730,10738]
string: 'dag_id' [10750,10758]
===
match
---
name: json_formatter [1398,1412]
name: json_formatter [1398,1412]
===
match
---
simple_stmt [11586,11610]
simple_stmt [11606,11630]
===
match
---
operator: = [5935,5936]
operator: = [5935,5936]
===
match
---
name: self [12611,12615]
name: self [12631,12635]
===
match
---
operator: = [12809,12810]
operator: = [12829,12830]
===
match
---
number: 1 [9658,9659]
number: 1 [9678,9679]
===
match
---
trailer [5909,5919]
trailer [5909,5919]
===
match
---
operator: != [7426,7428]
operator: != [7441,7443]
===
match
---
name: ti [3862,3864]
name: ti [3862,3864]
===
match
---
name: offset [6138,6144]
name: offset [6138,6144]
===
match
---
name: log [9834,9837]
name: log [9854,9857]
===
match
---
atom_expr [3669,3681]
atom_expr [3669,3681]
===
match
---
trailer [9274,9280]
trailer [9294,9300]
===
match
---
name: self [11957,11961]
name: self [11977,11981]
===
match
---
trailer [7859,7862]
trailer [7879,7882]
===
match
---
param [5148,5150]
param [5148,5150]
===
match
---
name: _ESJsonLogFmt [8445,8458]
name: _ESJsonLogFmt [8465,8478]
===
match
---
import_from [902,942]
import_from [902,942]
===
match
---
trailer [10926,10941]
trailer [10946,10961]
===
match
---
string: """         Clean up an execution date so that it is safe to query in elasticsearch         by removing reserved characters.         # https://www.elastic.co/guide/en/elasticsearch/reference/current/query-dsl-query-string-query.html#_reserved_characters          :param execution_date: execution date of the dag run.         """ [4437,4765]
string: """         Clean up an execution date so that it is safe to query in elasticsearch         by removing reserved characters.         # https://www.elastic.co/guide/en/elasticsearch/reference/current/query-dsl-query-string-query.html#_reserved_characters          :param execution_date: execution date of the dag run.         """ [4437,4765]
===
match
---
suite [11980,12031]
suite [12000,12051]
===
match
---
trailer [12448,12454]
trailer [12468,12474]
===
match
---
except_clause [10086,10107]
except_clause [10106,10127]
===
match
---
trailer [2846,2852]
trailer [2846,2852]
===
match
---
simple_stmt [13695,13706]
simple_stmt [13715,13726]
===
match
---
trailer [7766,7782]
trailer [7786,7802]
===
match
---
atom [7911,7981]
atom [7931,8001]
===
match
---
atom_expr [7919,7942]
atom_expr [7939,7962]
===
match
---
string: 'max_offset' [9620,9632]
string: 'max_offset' [9640,9652]
===
match
---
simple_stmt [3192,3212]
simple_stmt [3192,3212]
===
match
---
simple_stmt [12735,12763]
simple_stmt [12755,12783]
===
match
---
name: list [4918,4922]
name: list [4918,4922]
===
match
---
simple_stmt [9336,9396]
simple_stmt [9356,9416]
===
match
---
trailer [13657,13664]
trailer [13677,13684]
===
match
---
name: Search [1133,1139]
name: Search [1133,1139]
===
match
---
trailer [3615,3621]
trailer [3615,3621]
===
match
---
trailer [9280,9311]
trailer [9300,9331]
===
match
---
suite [11541,11578]
suite [11561,11598]
===
match
---
return_stmt [7991,8015]
return_stmt [8011,8035]
===
match
---
string: 'default_host' [4988,5002]
string: 'default_host' [4988,5002]
===
match
---
atom_expr [10791,10801]
atom_expr [10811,10821]
===
match
---
operator: >= [7244,7246]
operator: >= [7244,7246]
===
match
---
name: elasticsearch [3334,3347]
name: elasticsearch [3334,3347]
===
match
---
trailer [11429,11441]
trailer [11449,11461]
===
match
---
trailer [4186,4188]
trailer [4186,4188]
===
match
---
param [5295,5312]
param [5295,5312]
===
match
---
name: _ESJsonLogFmt [13714,13727]
name: _ESJsonLogFmt [13734,13747]
===
match
---
operator: -> [8732,8734]
operator: -> [8752,8754]
===
match
---
atom_expr [3960,4010]
atom_expr [3960,4010]
===
match
---
atom_expr [5860,5878]
atom_expr [5860,5878]
===
match
---
dotted_name [1146,1167]
dotted_name [1146,1167]
===
match
---
name: self [11430,11434]
name: self [11450,11454]
===
match
---
simple_stmt [850,880]
simple_stmt [850,880]
===
match
---
name: frontend [3397,3405]
name: frontend [3397,3405]
===
match
---
if_stmt [12097,12172]
if_stmt [12117,12192]
===
match
---
suite [4428,4829]
suite [4428,4829]
===
match
---
name: lines [7854,7859]
name: lines [7874,7879]
===
match
---
subscript [10003,10062]
subscript [10023,10082]
===
match
---
name: staticmethod [4835,4847]
name: staticmethod [4835,4847]
===
match
---
name: str [2734,2737]
name: str [2734,2737]
===
match
---
operator: -> [11631,11633]
operator: -> [11651,11653]
===
match
---
string: 'Could not get current log size with log_id: %s' [9848,9896]
string: 'Could not get current log size with log_id: %s' [9868,9916]
===
match
---
import_from [1180,1219]
import_from [1180,1219]
===
match
---
atom_expr [9382,9393]
atom_expr [9402,9413]
===
match
---
expr_stmt [9404,9433]
expr_stmt [9424,9453]
===
match
---
name: __init__ [3139,3147]
name: __init__ [3139,3147]
===
match
---
trailer [5114,5186]
trailer [5114,5186]
===
match
---
atom_expr [7873,7889]
atom_expr [7893,7909]
===
match
---
name: logs [6076,6080]
name: logs [6076,6080]
===
match
---
operator: , [10754,10755]
operator: , [10774,10775]
===
match
---
name: utils [1233,1238]
name: utils [1233,1238]
===
match
---
atom_expr [5340,5354]
atom_expr [5340,5354]
===
match
---
simple_stmt [3095,3123]
simple_stmt [3095,3123]
===
match
---
simple_stmt [6837,6861]
simple_stmt [6837,6861]
===
match
---
name: mark_end_on_close [11962,11979]
name: mark_end_on_close [11982,11999]
===
match
---
name: log [4975,4978]
name: log [4975,4978]
===
match
---
funcdef [3727,4346]
funcdef [3727,4346]
===
match
---
name: _render_log_id [10978,10992]
name: _render_log_id [10998,11012]
===
match
---
trailer [9833,9837]
trailer [9853,9857]
===
match
---
name: log_id [9304,9310]
name: log_id [9324,9330]
===
match
---
trailer [4974,5003]
trailer [4974,5003]
===
match
---
operator: ** [3994,3996]
operator: ** [3994,3996]
===
match
---
operator: = [6779,6780]
operator: = [6779,6780]
===
match
---
trailer [5868,5878]
trailer [5868,5878]
===
match
---
string: 'execution_date' [10824,10840]
string: 'execution_date' [10844,10860]
===
match
---
trailer [10977,10992]
trailer [10997,11012]
===
match
---
trailer [3196,3203]
trailer [3196,3203]
===
match
---
name: exception [9838,9847]
name: exception [9858,9867]
===
match
---
trailer [10236,10239]
trailer [10256,10259]
===
match
---
operator: } [11084,11085]
operator: } [11104,11105]
===
match
---
atom_expr [11496,11510]
atom_expr [11516,11530]
===
match
---
name: strip [6730,6735]
name: strip [6730,6735]
===
match
---
atom_expr [5016,5045]
atom_expr [5016,5045]
===
match
---
name: join [7831,7835]
name: join [7851,7855]
===
match
---
name: count [9426,9431]
name: count [9446,9451]
===
match
---
operator: = [11363,11364]
operator: = [11383,11384]
===
match
---
trailer [3467,3483]
trailer [3467,3483]
===
match
---
trailer [12641,12657]
trailer [12661,12677]
===
match
---
name: self [11586,11590]
name: self [11606,11610]
===
match
---
trailer [9847,9905]
trailer [9867,9925]
===
match
---
name: host [7948,7952]
name: host [7968,7972]
===
match
---
expr_stmt [3425,3454]
expr_stmt [3425,3454]
===
match
---
string: 'offset' [9317,9325]
string: 'offset' [9337,9345]
===
match
---
atom [7721,7737]
atom [7741,7757]
===
match
---
name: ti [4271,4273]
name: ti [4271,4273]
===
match
---
operator: = [9920,9921]
operator: = [9940,9941]
===
match
---
arglist [6002,6026]
arglist [6002,6026]
===
match
---
atom_expr [5989,6027]
atom_expr [5989,6027]
===
match
---
atom_expr [3900,3927]
atom_expr [3900,3927]
===
match
---
string: 'log_id' [10963,10971]
string: 'log_id' [10983,10991]
===
match
---
suite [9971,10074]
suite [9991,10094]
===
match
---
trailer [3964,3986]
trailer [3964,3986]
===
match
---
string: 'max_offset' [9507,9519]
string: 'max_offset' [9527,9539]
===
match
---
argument [13484,13513]
argument [13504,13533]
===
match
---
atom_expr [13946,13974]
atom_expr [13966,13994]
===
match
---
atom_expr [9829,9905]
atom_expr [9849,9925]
===
match
---
argument [10578,10601]
argument [10598,10621]
===
match
---
name: int [9382,9385]
name: int [9402,9405]
===
match
---
name: ti [3752,3754]
name: ti [3752,3754]
===
match
---
atom_expr [8445,8480]
atom_expr [8465,8500]
===
match
---
name: self [6709,6713]
name: self [6709,6713]
===
match
---
operator: , [13925,13926]
operator: , [13945,13946]
===
match
---
name: self [7837,7841]
name: self [7857,7861]
===
match
---
trailer [3993,4010]
trailer [3993,4010]
===
match
---
param [2785,2818]
param [2785,2818]
===
match
---
funcdef [10267,11610]
funcdef [10287,11630]
===
match
---
simple_stmt [9240,9327]
simple_stmt [9260,9347]
===
match
---
name: json_fields [10655,10666]
name: json_fields [10675,10686]
===
match
---
name: quote [13672,13677]
name: quote [13692,13697]
===
match
---
trailer [6133,6137]
trailer [6133,6137]
===
match
---
name: StreamHandler [11343,11356]
name: StreamHandler [11363,11376]
===
match
---
operator: , [1553,1554]
operator: , [1553,1554]
===
match
---
simple_stmt [902,943]
simple_stmt [902,943]
===
match
---
name: try_number [5313,5323]
name: try_number [5313,5323]
===
match
---
expr_stmt [3846,3887]
expr_stmt [3846,3887]
===
match
---
param [3752,3769]
param [3752,3769]
===
match
---
name: hosted_log [7954,7964]
name: hosted_log [7974,7984]
===
match
---
operator: = [13491,13492]
operator: = [13511,13512]
===
match
---
name: closed [11998,12004]
name: closed [12018,12024]
===
match
---
simple_stmt [7901,7982]
simple_stmt [7921,8002]
===
match
---
name: logging [11335,11342]
name: logging [11355,11362]
===
match
---
name: self [3392,3396]
name: self [3392,3396]
===
match
---
name: ti [5295,5297]
name: ti [5295,5297]
===
match
---
name: sys [11364,11367]
name: sys [11384,11387]
===
match
---
name: execution_date [4283,4297]
name: execution_date [4283,4297]
===
match
---
operator: { [10708,10709]
operator: { [10728,10729]
===
match
---
name: self [10582,10586]
name: self [10602,10606]
===
match
---
trailer [7385,7399]
trailer [7395,7409]
===
match
---
simple_stmt [7819,7892]
simple_stmt [7839,7912]
===
match
---
trailer [4231,4345]
trailer [4231,4345]
===
match
---
number: 0 [5808,5809]
number: 0 [5808,5809]
===
match
---
name: handler [11475,11482]
name: handler [11495,11502]
===
match
---
trailer [12355,12362]
trailer [12375,12382]
===
match
---
name: loading_hosts [6619,6632]
name: loading_hosts [6619,6632]
===
match
---
sync_comp_for [7944,7980]
sync_comp_for [7964,8000]
===
match
---
trailer [13555,13570]
trailer [13575,13590]
===
match
---
expr_stmt [5860,5882]
expr_stmt [5860,5882]
===
match
---
trailer [7878,7889]
trailer [7898,7909]
===
match
---
name: handler [3674,3681]
name: handler [3674,3681]
===
match
---
trailer [12675,12688]
trailer [12695,12708]
===
match
---
atom_expr [4906,4923]
atom_expr [4906,4923]
===
match
---
name: max_log_line [9573,9585]
name: max_log_line [9593,9605]
===
match
---
operator: = [2427,2428]
operator: = [2427,2428]
===
match
---
import_from [1220,1254]
import_from [1220,1254]
===
match
---
trailer [10992,11011]
trailer [11012,11031]
===
match
---
trailer [11356,11379]
trailer [11376,11399]
===
match
---
trailer [11342,11356]
trailer [11362,11376]
===
match
---
operator: , [6016,6017]
operator: , [6016,6017]
===
match
---
simple_stmt [3846,3888]
simple_stmt [3846,3888]
===
match
---
name: self [3746,3750]
name: self [3746,3750]
===
match
---
atom_expr [12702,12722]
atom_expr [12722,12742]
===
match
---
arith_expr [13631,13686]
arith_expr [13651,13706]
===
match
---
name: airflow [1225,1232]
name: airflow [1225,1232]
===
match
---
operator: = [3448,3449]
operator: = [3448,3449]
===
match
---
operator: -> [13000,13002]
operator: -> [13020,13022]
===
match
---
name: i [7860,7861]
name: i [7880,7881]
===
match
---
name: concat_logs [7677,7688]
name: concat_logs [7697,7708]
===
match
---
name: str [2593,2596]
name: str [2593,2596]
===
match
---
atom_expr [8416,8481]
atom_expr [8436,8501]
===
match
---
name: super [11554,11559]
name: super [11574,11579]
===
match
---
name: log_id_template [2606,2621]
name: log_id_template [2606,2621]
===
match
---
string: 'offset' [5869,5877]
string: 'offset' [5869,5877]
===
match
---
string: """The log name""" [12870,12888]
string: """The log name""" [12890,12908]
===
match
---
trailer [11151,11163]
trailer [11171,11183]
===
match
---
trailer [8658,8666]
trailer [8678,8686]
===
match
---
trailer [9732,9746]
trailer [9752,9766]
===
match
---
operator: = [9994,9995]
operator: = [10014,10015]
===
match
---
file_input [788,13975]
file_input [788,13995]
===
match
---
trailer [11495,11511]
trailer [11515,11531]
===
match
---
name: self [11625,11629]
name: self [11645,11649]
===
match
---
simple_stmt [1255,1311]
simple_stmt [1255,1311]
===
match
---
argument [13584,13605]
argument [13604,13625]
===
match
---
simple_stmt [5928,5973]
simple_stmt [5928,5973]
===
match
---
simple_stmt [5406,5749]
simple_stmt [5406,5749]
===
match
---
name: airflow [1380,1387]
name: airflow [1380,1387]
===
match
---
expr_stmt [3697,3721]
expr_stmt [3697,3721]
===
match
---
simple_stmt [1103,1140]
simple_stmt [1103,1140]
===
match
---
number: 0 [5881,5882]
number: 0 [5881,5882]
===
match
---
trailer [4161,4176]
trailer [4161,4176]
===
match
---
trailer [11997,12004]
trailer [12017,12024]
===
match
---
trailer [11559,11561]
trailer [11579,11581]
===
match
---
string: """         Returns the logs matching log_id in Elasticsearch and next offset.         Returns '' if no log is found or there was an error.          :param log_id: the log_id of the log to read.         :type log_id: str         :param offset: the offset start to read log from.         :type offset: str         :param metadata: log metadata, used for steaming log download.         :type metadata: dict         """ [8749,9165]
string: """         Returns the logs matching log_id in Elasticsearch and next offset.         Returns '' if no log is found or there was an error.          :param log_id: the log_id of the log to read.         :type log_id: str         :param offset: the offset start to read log from.         :type offset: str         :param metadata: log metadata, used for steaming log download.         :type metadata: dict         """ [8769,9185]
===
match
---
trailer [7530,7538]
trailer [7550,7558]
===
match
---
name: self [10842,10846]
name: self [10862,10866]
===
match
---
tfpdef [8716,8730]
tfpdef [8736,8750]
===
match
---
simple_stmt [2438,2465]
simple_stmt [2438,2465]
===
match
---
name: grouped_logs [4891,4903]
name: grouped_logs [4891,4903]
===
match
---
trailer [4208,4224]
trailer [4208,4224]
===
match
---
name: concat_logs [7919,7930]
name: concat_logs [7939,7950]
===
match
---
name: self [10973,10977]
name: self [10993,10997]
===
match
---
name: PAGE [2396,2400]
name: PAGE [2396,2400]
===
match
---
atom_expr [12735,12745]
atom_expr [12755,12765]
===
match
---
name: log_id [13393,13399]
name: log_id [13413,13419]
===
match
---
argument [9368,9394]
argument [9388,9414]
===
match
---
expr_stmt [7901,7981]
expr_stmt [7921,8001]
===
match
---
import_from [1141,1179]
import_from [1141,1179]
===
match
---
name: __stdout__ [12752,12762]
name: __stdout__ [12772,12782]
===
match
---
atom_expr [10842,10887]
atom_expr [10862,10907]
===
match
---
param [11625,11629]
param [11645,11649]
===
match
---
expr_stmt [10452,10487]
expr_stmt [10472,10507]
===
match
---
name: sys [12735,12738]
name: sys [12755,12758]
===
match
---
name: es_kwargs [2827,2836]
name: es_kwargs [2827,2836]
===
match
---
trailer [12104,12112]
trailer [12124,12132]
===
match
---
name: self [8416,8420]
name: self [8436,8440]
===
match
---
name: LOG_NAME [12909,12917]
name: LOG_NAME [12929,12937]
===
match
---
param [3746,3751]
param [3746,3751]
===
match
---
trailer [9351,9358]
trailer [9371,9378]
===
match
---
name: log_name [12839,12847]
name: log_name [12859,12867]
===
match
---
expr_stmt [11320,11379]
expr_stmt [11340,11399]
===
match
---
trailer [12615,12623]
trailer [12635,12643]
===
match
---
trailer [11561,11573]
trailer [11581,11593]
===
match
---
name: metadata [7090,7098]
name: metadata [7090,7098]
===
match
---
name: url [13625,13628]
name: url [13645,13648]
===
match
---
tfpdef [12983,12998]
tfpdef [13003,13018]
===
match
---
atom_expr [10040,10062]
atom_expr [10060,10082]
===
match
---
tfpdef [2544,2564]
tfpdef [2544,2564]
===
match
---
arglist [3362,3381]
arglist [3362,3381]
===
match
---
name: metadata [9477,9485]
name: metadata [9497,9505]
===
match
---
number: 1 [7748,7749]
number: 1 [7768,7769]
===
match
---
simple_stmt [10530,11101]
simple_stmt [10550,11121]
===
match
---
simple_stmt [3900,3941]
simple_stmt [3900,3941]
===
match
---
name: time [885,889]
name: time [885,889]
===
match
---
operator: , [8005,8006]
operator: , [8025,8026]
===
match
---
atom_expr [11043,11066]
atom_expr [11063,11086]
===
match
---
name: execution_date [4781,4795]
name: execution_date [4781,4795]
===
match
---
operator: = [10545,10546]
operator: = [10565,10566]
===
match
---
name: host [7913,7917]
name: host [7933,7937]
===
match
---
param [2606,2627]
param [2606,2627]
===
match
---
atom_expr [11113,11130]
atom_expr [11133,11150]
===
match
---
simple_stmt [5253,5265]
simple_stmt [5253,5265]
===
match
---
operator: ** [11060,11062]
operator: ** [11080,11082]
===
match
---
string: "elasticsearch_configs" [2871,2894]
string: "elasticsearch_configs" [2871,2894]
===
match
---
name: Optional [927,935]
name: Optional [927,935]
===
match
---
name: json_fields [3637,3648]
name: json_fields [3637,3648]
===
match
---
trailer [6055,6075]
trailer [6055,6075]
===
match
---
trailer [10868,10887]
trailer [10888,10907]
===
match
---
name: ti [4252,4254]
name: ti [4252,4254]
===
match
---
atom [7836,7890]
atom [7856,7910]
===
match
---
name: str [2561,2564]
name: str [2561,2564]
===
match
---
name: self [13644,13648]
name: self [13664,13668]
===
match
---
trailer [5133,5135]
trailer [5133,5135]
===
match
---
name: self [12637,12641]
name: self [12657,12661]
===
match
---
trailer [9674,9681]
trailer [9694,9701]
===
match
---
atom_expr [7141,7171]
atom_expr [7141,7171]
===
match
---
atom_expr [10530,10544]
atom_expr [10550,10564]
===
match
---
name: strip [3616,3621]
name: strip [3616,3621]
===
match
---
name: str [4424,4427]
name: str [4424,4427]
===
match
---
operator: = [2447,2448]
operator: = [2447,2448]
===
match
---
trailer [11590,11602]
trailer [11610,11622]
===
match
---
name: Tuple [937,942]
name: Tuple [937,942]
===
match
---
argument [4314,4335]
argument [4314,4335]
===
match
---
operator: - [6134,6135]
operator: - [6134,6135]
===
match
---
suite [8740,10262]
suite [8760,10282]
===
match
---
name: metadata [7494,7502]
name: metadata [7514,7522]
===
match
---
name: logs [10257,10261]
name: logs [10277,10281]
===
match
---
name: closed [12802,12808]
name: closed [12822,12828]
===
match
---
operator: = [10475,10476]
operator: = [10495,10496]
===
match
---
trailer [8420,8430]
trailer [8440,8450]
===
match
---
suite [9954,10241]
suite [9974,10261]
===
match
---
atom [5797,5810]
atom [5797,5810]
===
match
---
atom_expr [5152,5185]
atom_expr [5152,5185]
===
match
---
string: """         Creates an address for an external log collecting service.          :param task_instance: task instance object         :type: task_instance: TaskInstance         :param try_number: task instance try_number to read logs from.         :type try_number: Optional[int]         :return: URL to the external log collection service         :rtype: str         """ [13016,13384]
string: """         Creates an address for an external log collecting service.          :param task_instance: task instance object         :type: task_instance: TaskInstance         :param try_number: task instance try_number to read logs from.         :type try_number: Optional[int]         :return: URL to the external log collection service         :rtype: str         """ [13036,13404]
===
match
---
funcdef [8672,10262]
funcdef [8692,10282]
===
match
---
string: '\n' [7826,7830]
string: '\n' [7846,7850]
===
match
---
trailer [12454,12456]
trailer [12474,12476]
===
match
---
expr_stmt [5099,5186]
expr_stmt [5099,5186]
===
match
---
trailer [12393,12400]
trailer [12413,12420]
===
match
---
trailer [12623,12630]
trailer [12643,12650]
===
match
---
arglist [9848,9904]
arglist [9868,9924]
===
match
---
operator: , [2775,2776]
operator: , [2775,2776]
===
match
---
operator: = [4904,4905]
operator: = [4904,4905]
===
match
---
arglist [10176,10239]
arglist [10196,10259]
===
match
---
simple_stmt [13393,13617]
simple_stmt [13413,13637]
===
match
---
decorator [4351,4365]
decorator [4351,4365]
===
match
---
operator: , [10601,10602]
operator: , [10621,10622]
===
match
---
name: metadata [8716,8724]
name: metadata [8736,8744]
===
match
---
operator: = [3406,3407]
operator: = [3406,3407]
===
match
---
tfpdef [2827,2852]
tfpdef [2827,2852]
===
match
---
trailer [13505,13513]
trailer [13525,13533]
===
match
---
trailer [10504,10516]
trailer [10524,10536]
===
match
---
atom_expr [9611,9633]
atom_expr [9631,9653]
===
match
---
trailer [11046,11066]
trailer [11066,11086]
===
match
---
name: Optional [2838,2846]
name: Optional [2838,2846]
===
match
---
name: time [897,901]
name: time [897,901]
===
match
---
name: message [7901,7908]
name: message [7921,7928]
===
match
---
operator: = [4965,4966]
operator: = [4965,4966]
===
match
---
operator: = [3105,3106]
operator: = [3105,3106]
===
match
---
expr_stmt [4053,4115]
expr_stmt [4053,4115]
===
match
---
simple_stmt [12870,12889]
simple_stmt [12890,12909]
===
match
---
operator: = [5795,5796]
operator: = [5795,5796]
===
match
---
simple_stmt [3131,3184]
simple_stmt [3131,3184]
===
match
---
operator: , [4261,4262]
operator: , [4261,4262]
===
match
---
atom_expr [10740,10754]
atom_expr [10760,10774]
===
match
---
name: file_task_handler [1334,1351]
name: file_task_handler [1334,1351]
===
match
---
name: _clean_execution_date [10847,10868]
name: _clean_execution_date [10867,10888]
===
match
---
expr_stmt [9989,10073]
expr_stmt [10009,10093]
===
match
---
dictorsetmaker [10730,11067]
dictorsetmaker [10750,11087]
===
match
---
name: ti [10869,10871]
name: ti [10889,10891]
===
match
---
operator: = [9303,9304]
operator: = [9323,9324]
===
match
---
name: self [12436,12440]
name: self [12456,12460]
===
match
---
trailer [3864,3885]
trailer [3864,3885]
===
match
---
trailer [7782,7788]
trailer [7802,7808]
===
match
---
name: logs [5982,5986]
name: logs [5982,5986]
===
match
---
name: ti [10289,10291]
name: ti [10309,10311]
===
match
---
atom_expr [11993,12004]
atom_expr [12013,12024]
===
match
---
atom_expr [1544,1559]
atom_expr [1544,1559]
===
match
---
name: execution_date [4298,4312]
name: execution_date [4298,4312]
===
match
---
simple_stmt [3590,3661]
simple_stmt [3590,3661]
===
match
---
trailer [12706,12714]
trailer [12726,12734]
===
match
---
name: try_number [3770,3780]
name: try_number [3770,3780]
===
match
---
trailer [10999,11010]
trailer [11019,11030]
===
match
---
trailer [9311,9316]
trailer [9331,9336]
===
match
---
decorator [4834,4848]
decorator [4834,4848]
===
match
---
name: isoformat [4177,4186]
name: isoformat [4177,4186]
===
match
---
operator: = [5355,5356]
operator: = [5355,5356]
===
match
---
name: search [9345,9351]
name: search [9365,9371]
===
match
---
trailer [3701,3713]
trailer [3701,3713]
===
match
---
name: setLevel [11421,11429]
name: setLevel [11441,11449]
===
match
---
name: log_line [8650,8658]
name: log_line [8670,8678]
===
match
---
term [11047,11065]
term [11067,11085]
===
match
---
suite [12689,12763]
suite [12709,12783]
===
match
---
number: 1 [9672,9673]
number: 1 [9692,9693]
===
match
---
name: offset [8703,8709]
name: offset [8723,8729]
===
match
---
simple_stmt [9915,9925]
simple_stmt [9935,9945]
===
match
---
suite [13728,13975]
suite [13748,13995]
===
match
---
expr_stmt [12134,12152]
expr_stmt [12154,12172]
===
match
---
trailer [3986,3993]
trailer [3986,3993]
===
match
---
name: search [9336,9342]
name: search [9356,9362]
===
match
---
name: offset [5892,5898]
name: offset [5892,5898]
===
match
---
trailer [12138,12145]
trailer [12158,12165]
===
match
---
simple_stmt [5786,5811]
simple_stmt [5786,5811]
===
match
---
param [8690,8702]
param [8710,8722]
===
match
---
return_stmt [4774,4828]
return_stmt [4774,4828]
===
match
---
simple_stmt [12165,12172]
simple_stmt [12185,12192]
===
match
---
name: self [12343,12347]
name: self [12363,12367]
===
match
---
name: ti [10993,10995]
name: ti [11013,11015]
===
match
---
atom [3609,3660]
atom [3609,3660]
===
match
---
operator: = [12005,12006]
operator: = [12025,12026]
===
match
---
name: handler [12419,12426]
name: handler [12439,12446]
===
match
---
expr_stmt [9611,9681]
expr_stmt [9631,9701]
===
match
---
simple_stmt [13625,13687]
simple_stmt [13645,13707]
===
match
---
trailer [4917,4923]
trailer [4917,4923]
===
match
---
operator: > [9586,9587]
operator: > [9606,9607]
===
match
---
param [2827,2896]
param [2827,2896]
===
match
---
trailer [9431,9433]
trailer [9451,9453]
===
match
---
name: execute [10064,10071]
name: execute [10084,10091]
===
match
---
name: self [12414,12418]
name: self [12434,12438]
===
match
---
if_stmt [7416,7539]
if_stmt [7426,7559]
===
match
---
trailer [7140,7172]
trailer [7140,7172]
===
match
---
simple_stmt [6421,6459]
simple_stmt [6421,6459]
===
match
---
return_stmt [8643,8666]
return_stmt [8663,8686]
===
match
---
param [2694,2712]
param [2694,2712]
===
match
---
operator: = [13671,13672]
operator: = [13691,13692]
===
match
---
atom_expr [10582,10601]
atom_expr [10602,10621]
===
match
---
name: collections [819,830]
name: collections [819,830]
===
match
---
simple_stmt [10452,10488]
simple_stmt [10472,10508]
===
match
---
argument [11357,11378]
argument [11377,11398]
===
match
---
parameters [3745,3786]
parameters [3745,3786]
===
match
---
name: str [8711,8714]
name: str [8731,8734]
===
match
---
return_stmt [10250,10261]
return_stmt [10270,10281]
===
match
---
name: task_id [13484,13491]
name: task_id [13504,13511]
===
match
---
suite [9590,9682]
suite [9610,9702]
===
match
---
simple_stmt [11408,11458]
simple_stmt [11428,11478]
===
match
---
name: execution_date [4142,4156]
name: execution_date [4142,4156]
===
match
---
trailer [6075,6081]
trailer [6075,6081]
===
match
---
trailer [7799,7806]
trailer [7819,7826]
===
match
---
name: client [3325,3331]
name: client [3325,3331]
===
match
---
simple_stmt [1524,1561]
simple_stmt [1524,1561]
===
match
---
operator: = [4157,4158]
operator: = [4157,4158]
===
match
---
except_clause [9763,9779]
except_clause [9783,9799]
===
match
---
name: log_id [6002,6008]
name: log_id [6002,6008]
===
match
---
name: LOG_NAME [2438,2446]
name: LOG_NAME [2438,2446]
===
match
---
string: 'last_log_timestamp' [7444,7464]
string: 'last_log_timestamp' [7464,7484]
===
match
---
expr_stmt [9915,9924]
expr_stmt [9935,9944]
===
match
---
operator: , [7952,7953]
operator: , [7972,7973]
===
match
---
param [13927,13935]
param [13947,13955]
===
match
---
name: execution_date [4162,4176]
name: execution_date [4162,4176]
===
match
---
trailer [3247,3269]
trailer [3247,3269]
===
match
---
name: log_id_jinja_template [3811,3832]
name: log_id_jinja_template [3811,3832]
===
match
---
name: self [9829,9833]
name: self [9849,9853]
===
match
---
funcdef [4852,5210]
funcdef [4852,5210]
===
match
---
comp_op [7465,7471]
comp_op [7485,7491]
===
match
---
atom_expr [9345,9395]
atom_expr [9365,9415]
===
match
---
decorated [4351,4829]
decorated [4351,4829]
===
match
---
name: logs [4876,4880]
name: logs [4876,4880]
===
match
---
trailer [10161,10165]
trailer [10181,10185]
===
match
---
name: airflow [1439,1446]
name: airflow [1439,1446]
===
match
---
trailer [9670,9674]
trailer [9690,9694]
===
match
---
trailer [3147,3183]
trailer [3147,3183]
===
match
---
atom_expr [13450,13470]
atom_expr [13470,13490]
===
match
---
name: metadata [8007,8015]
name: metadata [8027,8035]
===
match
---
number: 0 [9749,9750]
number: 0 [9769,9770]
===
match
---
atom [11056,11065]
atom [11076,11085]
===
match
---
atom_expr [3131,3183]
atom_expr [3131,3183]
===
match
---
testlist_comp [6649,6737]
testlist_comp [6649,6737]
===
match
---
trailer [12440,12448]
trailer [12460,12468]
===
match
---
trailer [3361,3382]
trailer [3361,3382]
===
match
---
name: _clean_execution_date [4373,4394]
name: _clean_execution_date [4373,4394]
===
match
---
name: self [10040,10044]
name: self [10060,10064]
===
match
---
trailer [12801,12808]
trailer [12821,12828]
===
match
---
operator: { [5797,5798]
operator: { [5797,5798]
===
match
---
atom_expr [3272,3310]
atom_expr [3272,3310]
===
match
---
operator: = [13629,13630]
operator: = [13649,13650]
===
match
---
string: 'offset' [5822,5830]
string: 'offset' [5822,5830]
===
match
---
simple_stmt [12134,12153]
simple_stmt [12154,12173]
===
match
---
name: airflow [1185,1192]
name: airflow [1185,1192]
===
match
---
simple_stmt [1311,1375]
simple_stmt [1311,1375]
===
match
---
name: metadata [9527,9535]
name: metadata [9547,9555]
===
match
---
operator: = [3528,3529]
operator: = [3528,3529]
===
match
---
string: 'gt' [9376,9380]
string: 'gt' [9396,9400]
===
match
---
dotted_name [1380,1412]
dotted_name [1380,1412]
===
match
---
name: task_id [13506,13513]
name: task_id [13526,13533]
===
match
---
name: extras [10701,10707]
name: extras [10721,10727]
===
match
---
string: 'offset' [11033,11041]
string: 'offset' [11053,11061]
===
match
---
test [6105,6144]
test [6105,6144]
===
match
---
atom_expr [6756,6778]
atom_expr [6756,6778]
===
match
---
param [2574,2597]
param [2574,2597]
===
match
---
name: es_kwargs [3107,3116]
name: es_kwargs [3107,3116]
===
match
---
operator: { [3120,3121]
operator: { [3120,3121]
===
match
---
return_stmt [3953,4010]
return_stmt [3953,4010]
===
match
---
simple_stmt [6619,6748]
simple_stmt [6619,6748]
===
match
---
if_stmt [5819,5883]
if_stmt [5819,5883]
===
match
---
name: item [6685,6689]
name: item [6685,6689]
===
match
---
name: filter [9352,9358]
name: filter [9372,9378]
===
match
---
name: log_id [10225,10231]
name: log_id [10245,10251]
===
match
---
atom_expr [5160,5168]
atom_expr [5160,5168]
===
match
---
operator: , [2564,2565]
operator: , [2564,2565]
===
match
---
param [5313,5329]
param [5313,5329]
===
match
---
operator: - [7747,7748]
operator: - [7767,7768]
===
match
---
operator: , [10287,10288]
operator: , [10307,10308]
===
match
---
name: end_of_log_mark [3468,3483]
name: end_of_log_mark [3468,3483]
===
match
---
atom [7188,7359]
atom [7188,7369]
===
match
---
operator: , [10802,10803]
operator: , [10822,10823]
===
match
---
if_stmt [11950,12031]
if_stmt [11970,12051]
===
match
---
atom_expr [3610,3623]
atom_expr [3610,3623]
===
match
---
name: handler [12105,12112]
name: handler [12125,12132]
===
match
---
name: cur_ts [7531,7537]
name: cur_ts [7551,7557]
===
match
---
atom_expr [4271,4281]
atom_expr [4271,4281]
===
match
---
name: logging_mixin [1457,1470]
name: logging_mixin [1457,1470]
===
match
---
suite [5773,5811]
suite [5773,5811]
===
match
---
name: staticmethod [4352,4364]
name: staticmethod [4352,4364]
===
match
---
atom [9375,9394]
atom [9395,9414]
===
match
---
name: _style [8431,8437]
name: _style [8451,8457]
===
match
---
trailer [7725,7732]
trailer [7745,7752]
===
match
---
simple_stmt [3392,3417]
simple_stmt [3392,3417]
===
match
---
expr_stmt [13393,13616]
expr_stmt [13413,13636]
===
match
---
suite [4040,4116]
suite [4040,4116]
===
match
---
trailer [8444,8481]
trailer [8464,8501]
===
match
---
trailer [8477,8479]
trailer [8497,8499]
===
match
---
if_stmt [5757,5811]
if_stmt [5757,5811]
===
match
---
trailer [11573,11577]
trailer [11593,11597]
===
match
---
funcdef [12835,12918]
funcdef [12855,12938]
===
match
---
for_stmt [4932,5046]
for_stmt [4932,5046]
===
match
---
trailer [5165,5168]
trailer [5165,5168]
===
match
---
name: result [5203,5209]
name: result [5203,5209]
===
match
---
string: 'end_of_log' [7386,7398]
string: 'end_of_log' [7396,7408]
===
match
---
trailer [7331,7345]
trailer [7340,7354]
===
match
---
simple_stmt [3669,3689]
simple_stmt [3669,3689]
===
match
---
test [7721,7806]
test [7741,7826]
===
match
---
simple_stmt [5860,5883]
simple_stmt [5860,5883]
===
match
---
operator: , [11066,11067]
operator: , [11086,11087]
===
match
---
name: search [9419,9425]
name: search [9439,9445]
===
match
---
trailer [7841,7853]
trailer [7861,7873]
===
match
---
string: """         Provide task_instance context to airflow task handler.          :param ti: task instance object         """ [10324,10443]
string: """         Provide task_instance context to airflow task handler.          :param ti: task instance object         """ [10344,10463]
===
match
---
argument [8459,8479]
argument [8479,8499]
===
match
---
simple_stmt [9724,9751]
simple_stmt [9744,9771]
===
match
---
atom_expr [13672,13685]
atom_expr [13692,13705]
===
match
---
factor [7747,7749]
factor [7767,7769]
===
match
---
trailer [12720,12722]
trailer [12740,12742]
===
match
---
name: utils [1324,1329]
name: utils [1324,1329]
===
match
---
name: datetime [855,863]
name: datetime [855,863]
===
match
---
parameters [11624,11630]
parameters [11644,11650]
===
match
---
name: str [2653,2656]
name: str [2653,2656]
===
match
---
trailer [6854,6858]
trailer [6854,6858]
===
match
---
string: 'last_log_timestamp' [7150,7170]
string: 'last_log_timestamp' [7150,7170]
===
match
---
suite [7360,7407]
suite [7370,7417]
===
match
---
simple_stmt [8062,8141]
simple_stmt [8082,8161]
===
match
---
trailer [5348,5354]
trailer [5348,5354]
===
match
---
name: execution_date [13556,13570]
name: execution_date [13576,13590]
===
match
---
operator: == [7759,7761]
operator: == [7779,7781]
===
match
---
trailer [3621,3623]
trailer [3621,3623]
===
match
---
trailer [7853,7863]
trailer [7873,7883]
===
match
---
suite [7481,7539]
suite [7501,7559]
===
match
---
testlist_star_expr [3221,3269]
testlist_star_expr [3221,3269]
===
match
---
name: conf [1175,1179]
name: conf [1175,1179]
===
match
---
name: format [13658,13664]
name: format [13678,13684]
===
match
---
trailer [7134,7140]
trailer [7134,7140]
===
match
---
name: dict [8726,8730]
name: dict [8746,8750]
===
match
---
name: log_id_template [3226,3241]
name: log_id_template [3226,3241]
===
match
---
not_test [10477,10487]
not_test [10497,10507]
===
match
---
atom_expr [3551,3567]
atom_expr [3551,3567]
===
match
---
atom [3120,3122]
atom [3120,3122]
===
match
---
trailer [13664,13686]
trailer [13684,13706]
===
match
---
param [7689,7694]
param [7709,7714]
===
match
---
name: e [10106,10107]
name: e [10126,10127]
===
match
---
name: write_stdout [11118,11130]
name: write_stdout [11138,11150]
===
match
---
name: host [2747,2751]
name: host [2747,2751]
===
match
---
operator: , [3163,3164]
operator: , [3163,3164]
===
match
---
atom_expr [12748,12762]
atom_expr [12768,12782]
===
match
---
simple_stmt [1087,1103]
simple_stmt [1087,1103]
===
match
---
name: log_id [8690,8696]
name: log_id [8710,8716]
===
match
---
suite [11131,11528]
suite [11151,11548]
===
match
---
name: lines [7800,7805]
name: lines [7820,7825]
===
match
---
operator: , [10995,10996]
operator: , [11015,11016]
===
match
---
string: "," [3655,3658]
string: "," [3655,3658]
===
match
---
name: search [9636,9642]
name: search [9656,9662]
===
match
---
and_test [9445,9535]
and_test [9465,9555]
===
match
---
operator: = [9634,9635]
operator: = [9654,9655]
===
match
---
name: Exception [10093,10102]
name: Exception [10113,10122]
===
match
---
name: timezone [1246,1254]
name: timezone [1246,1254]
===
match
---
trailer [3429,3447]
trailer [3429,3447]
===
match
---
parameters [12947,12999]
parameters [12967,13019]
===
match
---
name: log_id [13678,13684]
name: log_id [13698,13704]
===
match
---
power [11057,11064]
power [11077,11084]
===
match
---
number: 0 [2403,2404]
number: 0 [2403,2404]
===
match
---
trailer [9642,9660]
trailer [9662,9680]
===
match
---
name: self [3320,3324]
name: self [3320,3324]
===
match
---
atom_expr [7762,7790]
atom_expr [7782,7810]
===
match
---
trailer [6713,6729]
trailer [6713,6729]
===
match
---
atom_expr [5108,5186]
atom_expr [5108,5186]
===
match
---
name: log_line [8461,8469]
name: log_line [8481,8489]
===
match
---
name: message [7998,8005]
name: message [8018,8025]
===
match
---
param [5330,5361]
param [5330,5361]
===
match
---
suite [13937,13975]
suite [13957,13995]
===
match
---
name: elasticsearch [1073,1086]
name: elasticsearch [1073,1086]
===
match
---
name: LoggingMixin [1478,1490]
name: LoggingMixin [1478,1490]
===
match
---
trailer [10007,10025]
trailer [10027,10045]
===
match
---
name: client [9267,9273]
name: client [9287,9293]
===
match
---
name: __init__ [2474,2482]
name: __init__ [2474,2482]
===
match
---
name: jinja_context [3900,3913]
name: jinja_context [3900,3913]
===
match
---
name: key [5137,5140]
name: key [5137,5140]
===
match
---
name: str [10923,10926]
name: str [10943,10946]
===
match
---
name: getsection [2860,2870]
name: getsection [2860,2870]
===
match
---
trailer [10871,10886]
trailer [10891,10906]
===
match
---
atom_expr [4967,5003]
atom_expr [4967,5003]
===
match
---
trailer [5033,5040]
trailer [5033,5040]
===
match
---
comparison [7741,7790]
comparison [7761,7810]
===
match
---
name: close [11619,11624]
name: close [11639,11644]
===
match
---
not_test [6790,6798]
not_test [6790,6798]
===
match
---
name: self [12100,12104]
name: self [12120,12124]
===
match
---
if_stmt [9933,10241]
if_stmt [9953,10261]
===
insert-node
---
name: ElasticsearchTaskHandler [1569,1593]
to
classdef [1563,13706]
at 0
===
insert-tree
---
arglist [1594,1623]
    name: FileTaskHandler [1594,1609]
    operator: , [1609,1610]
    name: LoggingMixin [1611,1623]
to
classdef [1563,13706]
at 1
===
insert-tree
---
simple_stmt [1630,2391]
    string: """     ElasticsearchTaskHandler is a python log handler that     reads logs from Elasticsearch. Note logs are not directly     indexed into Elasticsearch. Instead, it flushes logs     into local files. Additional software setup is required     to index the log into Elasticsearch, such as using     Filebeat and Logstash.     To efficiently query and sort Elasticsearch results, we assume each     log message has a field `log_id` consists of ti primary keys:     `log_id = {dag_id}-{task_id}-{execution_date}-{try_number}`     Log messages with specific log_id are sorted based on `offset`,     which is a unique integer indicates log message's order.     Timestamp here are unreliable because multiple log messages     might have the same timestamp.     """ [1630,2390]
to
suite [1625,13706]
at 0
===
insert-node
---
atom_expr [7429,7440]
to
comparison [7419,7440]
at 0
===
insert-node
---
atom_expr [7444,7460]
to
comparison [7419,7440]
at 3
===
insert-node
---
trailer [7432,7440]
to
atom_expr [7429,7440]
at 1
===
insert-node
---
trailer [7447,7460]
to
atom_expr [7444,7460]
at 1
===
move-tree
---
name: offset [7419,7425]
to
trailer [7432,7440]
at 0
===
move-tree
---
name: next_offset [7429,7440]
to
trailer [7447,7460]
at 0
===
insert-node
---
atom_expr [7313,7324]
to
comparison [7313,7345]
at 0
===
insert-node
---
atom_expr [7328,7355]
to
comparison [7313,7345]
at 3
===
insert-node
---
trailer [7316,7324]
to
atom_expr [7313,7324]
at 1
===
insert-node
---
trailer [7331,7355]
to
atom_expr [7328,7355]
at 1
===
move-tree
---
name: offset [7313,7319]
to
trailer [7316,7324]
at 0
===
move-tree
---
atom_expr [7323,7345]
    name: metadata [7323,7331]
    trailer [7331,7345]
        string: 'max_offset' [7332,7344]
to
trailer [7331,7355]
at 0
===
delete-node
---
name: ElasticsearchTaskHandler [1569,1593]
===
===
delete-tree
---
arglist [1594,1623]
    name: FileTaskHandler [1594,1609]
    operator: , [1609,1610]
    name: LoggingMixin [1611,1623]
===
delete-tree
---
simple_stmt [1630,2391]
    string: """     ElasticsearchTaskHandler is a python log handler that     reads logs from Elasticsearch. Note logs are not directly     indexed into Elasticsearch. Instead, it flushes logs     into local files. Additional software setup is required     to index the log into Elasticsearch, such as using     Filebeat and Logstash.     To efficiently query and sort Elasticsearch results, we assume each     log message has a field `log_id` consists of ti primary keys:     `log_id = {dag_id}-{task_id}-{execution_date}-{try_number}`     Log messages with specific log_id are sorted based on `offset`,     which is a unique integer indicates log message's order.     Timestamp here are unreliable because multiple log messages     might have the same timestamp.     """ [1630,2390]
