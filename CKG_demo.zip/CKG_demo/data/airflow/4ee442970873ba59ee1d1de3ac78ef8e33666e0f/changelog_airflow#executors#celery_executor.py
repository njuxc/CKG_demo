===
match
---
name: self [8107,8111]
name: self [8107,8111]
===
match
---
name: environ [4379,4386]
name: environ [4379,4386]
===
match
---
fstring_end: " [3998,3999]
fstring_end: " [3998,3999]
===
match
---
operator: = [4507,4508]
operator: = [4507,4508]
===
match
---
trailer [3021,3038]
trailer [3021,3038]
===
match
---
argument [4543,4550]
argument [4543,4550]
===
match
---
number: 1.0 [2531,2534]
number: 1.0 [2531,2534]
===
match
---
name: _sync_parallelism [24979,24996]
name: _sync_parallelism [24981,24998]
===
match
---
name: state [21460,21465]
name: state [21466,21471]
===
match
---
tfpdef [5560,5592]
tfpdef [5560,5592]
===
match
---
name: ti [19232,19234]
name: ti [19232,19234]
===
match
---
operator: = [23681,23682]
operator: = [23683,23684]
===
match
---
name: pid [3325,3328]
name: pid [3325,3328]
===
match
---
name: len [12057,12060]
name: len [12057,12060]
===
match
---
number: 1 [12116,12117]
number: 1 [12116,12117]
===
match
---
trailer [7815,7817]
trailer [7815,7817]
===
match
---
trailer [23892,23896]
trailer [23894,23898]
===
match
---
name: len [12498,12501]
name: len [12498,12501]
===
match
---
expr_stmt [2457,2535]
expr_stmt [2457,2535]
===
match
---
atom_expr [13380,13406]
atom_expr [13380,13406]
===
match
---
atom_expr [6056,6102]
atom_expr [6056,6102]
===
match
---
name: operator [19533,19541]
name: operator [19538,19546]
===
match
---
simple_stmt [16946,16988]
simple_stmt [16946,16988]
===
match
---
operator: @ [2891,2892]
operator: @ [2891,2892]
===
match
---
arglist [12887,12917]
arglist [12887,12917]
===
match
---
parameters [6229,6246]
parameters [6229,6246]
===
match
---
name: backend [23272,23279]
name: backend [23269,23276]
===
match
---
trailer [20139,20147]
trailer [20145,20153]
===
match
---
name: command [9302,9309]
name: command [9302,9309]
===
match
---
parameters [17546,17711]
parameters [17546,17711]
===
match
---
trailer [7873,7897]
trailer [7873,7897]
===
match
---
name: SIGTERM [12836,12843]
name: SIGTERM [12836,12843]
===
match
---
name: celery_states [16740,16753]
name: celery_states [16740,16753]
===
match
---
simple_stmt [21855,22223]
simple_stmt [21761,22129]
===
match
---
operator: = [11754,11755]
operator: = [11754,11755]
===
match
---
simple_stmt [15286,15339]
simple_stmt [15286,15339]
===
match
---
dictorsetmaker [23354,23421]
dictorsetmaker [23351,23418]
===
match
---
name: self [15263,15267]
name: self [15263,15267]
===
match
---
operator: { [24023,24024]
operator: { [24025,24026]
===
match
---
name: task [23974,23978]
name: task [23976,23980]
===
match
---
subscriptlist [20591,20635]
subscriptlist [20597,20641]
===
match
---
dotted_name [2146,2165]
dotted_name [2146,2165]
===
match
---
operator: , [8196,8197]
operator: , [8196,8197]
===
match
---
trailer [19358,19362]
trailer [19358,19362]
===
match
---
name: async_results [25116,25129]
name: async_results [25118,25131]
===
match
---
name: next [19644,19648]
name: next [19650,19654]
===
match
---
trailer [15942,15951]
trailer [15942,15951]
===
match
---
name: traceback [25786,25795]
name: traceback [25788,25797]
===
match
---
name: queue [5886,5891]
name: queue [5886,5891]
===
match
---
atom_expr [19649,19676]
atom_expr [19655,19682]
===
match
---
name: timedout_keys [14752,14765]
name: timedout_keys [14752,14765]
===
match
---
atom [11245,11265]
atom [11245,11265]
===
match
---
atom_expr [3412,3430]
atom_expr [3412,3430]
===
match
---
trailer [21648,21656]
trailer [21654,21662]
===
match
---
name: app [22684,22687]
name: app [22679,22682]
===
match
---
funcdef [23521,24185]
funcdef [23518,24187]
===
match
---
name: synchronous [17313,17324]
name: synchronous [17313,17324]
===
match
---
simple_stmt [12399,12470]
simple_stmt [12399,12470]
===
match
---
name: initializer [12963,12974]
name: initializer [12963,12974]
===
match
---
atom_expr [9262,9279]
atom_expr [9262,9279]
===
match
---
simple_stmt [2333,2398]
simple_stmt [2333,2398]
===
match
---
number: 1 [7803,7804]
number: 1 [7803,7804]
===
match
---
atom_expr [9186,9212]
atom_expr [9186,9212]
===
match
---
trailer [10930,10951]
trailer [10930,10951]
===
match
---
trailer [4256,4261]
trailer [4256,4261]
===
match
---
atom [15134,15154]
atom [15134,15154]
===
match
---
trailer [25887,25896]
trailer [25889,25898]
===
match
---
trailer [7384,7386]
trailer [7384,7386]
===
match
---
name: self [10887,10891]
name: self [10887,10891]
===
match
---
simple_stmt [2221,2263]
simple_stmt [2221,2263]
===
match
---
for_stmt [9227,9584]
for_stmt [9227,9584]
===
match
---
operator: = [5754,5755]
operator: = [5754,5755]
===
match
---
trailer [4386,4391]
trailer [4386,4391]
===
match
---
atom_expr [23861,23891]
atom_expr [23863,23893]
===
match
---
param [17556,17561]
param [17556,17561]
===
match
---
operator: , [12843,12844]
operator: , [12843,12844]
===
match
---
expr_stmt [3847,3892]
expr_stmt [3847,3892]
===
match
---
atom_expr [4829,4850]
atom_expr [4829,4850]
===
match
---
name: str [23581,23584]
name: str [23578,23581]
===
match
---
trailer [12501,12522]
trailer [12501,12522]
===
match
---
simple_stmt [13338,13368]
simple_stmt [13338,13368]
===
match
---
trailer [7737,7755]
trailer [7737,7755]
===
match
---
simple_stmt [1429,1467]
simple_stmt [1429,1467]
===
match
---
if_stmt [13377,13460]
if_stmt [13377,13460]
===
match
---
name: TaskInstanceKey [1993,2008]
name: TaskInstanceKey [1993,2008]
===
match
---
atom_expr [25494,25548]
atom_expr [25496,25550]
===
match
---
atom_expr [21779,21788]
atom_expr [22335,22344]
===
match
---
name: os [4248,4250]
name: os [4248,4250]
===
match
---
simple_stmt [24936,24998]
simple_stmt [24938,25000]
===
match
---
name: TaskDb [1405,1411]
name: TaskDb [1405,1411]
===
match
---
name: config_templates [1659,1675]
name: config_templates [1659,1675]
===
match
---
tfpdef [17313,17330]
tfpdef [17313,17330]
===
match
---
name: operator [992,1000]
name: operator [992,1000]
===
match
---
operator: , [15857,15858]
operator: , [15857,15858]
===
match
---
param [20555,20580]
param [20561,20586]
===
match
---
operator: = [21559,21560]
operator: = [21565,21566]
===
match
---
operator: , [23555,23556]
operator: , [23552,23553]
===
match
---
name: LoggingMixin [21836,21848]
name: LoggingMixin [21742,21754]
===
match
---
argument [13115,13134]
argument [13115,13134]
===
match
---
expr_stmt [19620,19688]
expr_stmt [19626,19694]
===
match
---
name: airflow [2184,2191]
name: airflow [2184,2191]
===
match
---
name: chunksize [25272,25281]
name: chunksize [25274,25283]
===
match
---
name: command_to_exec [3242,3257]
name: command_to_exec [3242,3257]
===
match
---
testlist_comp [19719,19730]
testlist_comp [19725,19736]
===
match
---
trailer [2822,2851]
trailer [2822,2851]
===
match
---
name: BaseKeyValueStoreBackend [1318,1342]
name: BaseKeyValueStoreBackend [1318,1342]
===
match
---
name: AirflowException [4829,4845]
name: AirflowException [4829,4845]
===
match
---
name: time [17490,17494]
name: time [17490,17494]
===
match
---
trailer [23237,23243]
trailer [23234,23240]
===
match
---
trailer [20333,20342]
trailer [20339,20348]
===
match
---
name: _sync_parallelism [7738,7755]
name: _sync_parallelism [7738,7755]
===
match
---
dotted_name [6717,6739]
dotted_name [6717,6739]
===
match
---
dotted_name [1434,1447]
dotted_name [1434,1447]
===
match
---
operator: { [23353,23354]
operator: { [23350,23351]
===
match
---
operator: , [16738,16739]
operator: , [16738,16739]
===
match
---
name: task_results [23409,23421]
name: task_results [23406,23418]
===
match
---
name: math [8833,8837]
name: math [8833,8837]
===
match
---
name: task_publish_retries [8260,8280]
name: task_publish_retries [8260,8280]
===
match
---
simple_stmt [1343,1429]
simple_stmt [1343,1429]
===
match
---
if_stmt [10161,10875]
if_stmt [10161,10875]
===
match
---
import_name [1610,1645]
import_name [1610,1645]
===
match
---
name: settings [3718,3726]
name: settings [3718,3726]
===
match
---
parameters [15740,15746]
parameters [15740,15746]
===
match
---
param [16484,16489]
param [16484,16489]
===
match
---
name: AirflowException [1790,1806]
name: AirflowException [1790,1806]
===
match
---
name: getint [8181,8187]
name: getint [8181,8187]
===
match
---
name: ti [20106,20108]
name: ti [20112,20114]
===
match
---
name: state_info [24816,24826]
name: state_info [24818,24828]
===
match
---
name: join [15001,15005]
name: join [15001,15005]
===
match
---
name: jobs [6660,6664]
name: jobs [6660,6664]
===
match
---
trailer [24718,24726]
trailer [24720,24728]
===
match
---
name: state_info [24767,24777]
name: state_info [24769,24779]
===
match
---
name: FAILED [11252,11258]
name: FAILED [11252,11258]
===
match
---
comparison [19166,19201]
comparison [19166,19201]
===
match
---
name: ti [20195,20197]
name: ti [20201,20203]
===
match
---
parameters [16265,16316]
parameters [16265,16316]
===
match
---
simple_stmt [8465,8563]
simple_stmt [8465,8563]
===
match
---
name: self [7831,7835]
name: self [7831,7835]
===
match
---
try_stmt [21134,21711]
try_stmt [21140,21717]
===
match
---
import_name [1011,1028]
import_name [1011,1028]
===
match
---
string: """         See if any of the tasks we adopted from another Executor run have not         progressed after the configured timeout.          If they haven't, they likely never made it to Celery, and we should         just resend them. We do that by clearing the state and letting the         normal scheduler loop deal with that         """ [13517,13856]
string: """         See if any of the tasks we adopted from another Executor run have not         progressed after the configured timeout.          If they haven't, they likely never made it to Celery, and we should         just resend them. We do that by clearing the state and letting the         normal scheduler loop deal with that         """ [13517,13856]
===
match
---
trailer [19532,19579]
trailer [19537,19584]
===
match
---
atom_expr [19232,19255]
atom_expr [19232,19255]
===
match
---
operator: , [12901,12902]
operator: , [12901,12902]
===
match
---
param [7364,7368]
param [7364,7368]
===
match
---
name: state [17005,17010]
name: state [17005,17010]
===
match
---
name: dispose [3734,3741]
name: dispose [3734,3741]
===
match
---
name: self [9549,9553]
name: self [9549,9553]
===
match
---
simple_stmt [8014,8099]
simple_stmt [8014,8099]
===
match
---
name: log [14784,14787]
name: log [14784,14787]
===
match
---
atom_expr [14994,15039]
atom_expr [14994,15039]
===
match
---
name: CalledProcessError [4623,4641]
name: CalledProcessError [4623,4641]
===
match
---
name: CELERY_FETCH_ERR_MSG_HEADER [25646,25673]
name: CELERY_FETCH_ERR_MSG_HEADER [25648,25675]
===
match
---
simple_stmt [17490,17504]
simple_stmt [17490,17504]
===
match
---
expr_stmt [2264,2297]
expr_stmt [2264,2297]
===
match
---
atom_expr [25347,25388]
atom_expr [25349,25390]
===
match
---
atom_expr [8014,8040]
atom_expr [8014,8040]
===
match
---
atom_expr [8865,8887]
atom_expr [8865,8887]
===
match
---
param [17630,17658]
param [17630,17658]
===
match
---
name: all [23893,23896]
name: all [23895,23898]
===
match
---
sync_comp_for [23185,23202]
sync_comp_for [23182,23199]
===
match
---
atom_expr [9629,9669]
atom_expr [9629,9669]
===
match
---
operator: , [1207,1208]
operator: , [1207,1208]
===
match
---
name: self [8465,8469]
name: self [8465,8469]
===
match
---
name: TaskInstanceKey [8047,8062]
name: TaskInstanceKey [8047,8062]
===
match
---
atom_expr [3112,3157]
atom_expr [3112,3157]
===
match
---
trailer [16419,16441]
trailer [16419,16441]
===
match
---
number: 0 [4040,4041]
number: 0 [4040,4041]
===
match
---
name: configuration [1733,1746]
name: configuration [1733,1746]
===
match
---
name: SIG_DFL [12910,12917]
name: SIG_DFL [12910,12917]
===
match
---
sync_comp_for [23297,23317]
sync_comp_for [23294,23314]
===
match
---
trailer [19231,19256]
trailer [19231,19256]
===
match
---
import_name [6684,6705]
import_name [6684,6705]
===
match
---
import_name [6744,6775]
import_name [6744,6775]
===
match
---
trailer [19666,19673]
trailer [19672,19679]
===
match
---
simple_stmt [12731,12745]
simple_stmt [12731,12745]
===
match
---
decorated [24190,24827]
decorated [24192,24829]
===
match
---
operator: , [9256,9257]
operator: , [9256,9257]
===
match
---
param [8914,8919]
param [8914,8919]
===
match
---
name: signal [12758,12764]
name: signal [12758,12764]
===
match
---
name: state [24789,24794]
name: state [24791,24796]
===
match
---
name: self [5232,5236]
name: self [5232,5236]
===
match
---
name: debug_dump [15355,15365]
name: debug_dump [15355,15365]
===
match
---
name: k [23189,23190]
name: k [23186,23187]
===
match
---
suite [17211,17294]
suite [17211,17294]
===
match
---
sync_comp_for [17440,17471]
sync_comp_for [17440,17471]
===
match
---
atom_expr [19654,19675]
atom_expr [19660,19681]
===
match
---
expr_stmt [3901,3931]
expr_stmt [3901,3931]
===
match
---
expr_stmt [25066,25158]
expr_stmt [25068,25160]
===
match
---
trailer [14954,14976]
trailer [14954,14976]
===
match
---
string: 'info' [21388,21394]
string: 'info' [21394,21400]
===
match
---
name: async_result [20555,20567]
name: async_result [20561,20573]
===
match
---
name: log [2264,2267]
name: log [2264,2267]
===
match
---
fstring_end: " [21619,21620]
fstring_end: " [21625,21626]
===
match
---
operator: = [17331,17332]
operator: = [17331,17332]
===
match
---
name: typing [1143,1149]
name: typing [1143,1149]
===
match
---
operator: } [24402,24403]
operator: } [24404,24405]
===
match
---
trailer [9510,9531]
trailer [9510,9531]
===
match
---
trailer [4812,4814]
trailer [4812,4814]
===
match
---
name: celery [1348,1354]
name: celery [1348,1354]
===
match
---
name: exception_traceback [5197,5216]
name: exception_traceback [5197,5216]
===
match
---
name: MutableMapping [1183,1197]
name: MutableMapping [1183,1197]
===
match
---
suite [7761,7823]
suite [7761,7823]
===
match
---
operator: } [21618,21619]
operator: } [21624,21625]
===
match
---
operator: , [1160,1161]
operator: , [1160,1161]
===
match
---
name: List [9186,9190]
name: List [9186,9190]
===
match
---
name: fetch_celery_task_state [25232,25255]
name: fetch_celery_task_state [25234,25257]
===
match
---
tfpdef [16512,16522]
tfpdef [16512,16522]
===
match
---
atom_expr [10476,10515]
atom_expr [10476,10515]
===
match
---
trailer [3726,3733]
trailer [3726,3733]
===
match
---
name: SIGUSR2 [12894,12901]
name: SIGUSR2 [12894,12901]
===
match
---
arglist [3423,3429]
arglist [3423,3429]
===
match
---
atom_expr [7799,7822]
atom_expr [7799,7822]
===
match
---
trailer [17232,17242]
trailer [17232,17242]
===
match
---
atom_expr [2695,2744]
atom_expr [2695,2744]
===
match
---
trailer [16972,16976]
trailer [16972,16976]
===
match
---
operator: = [5891,5892]
operator: = [5891,5892]
===
match
---
name: ti [19166,19168]
name: ti [19166,19168]
===
match
---
trailer [13457,13459]
trailer [13457,13459]
===
match
---
name: get_many [22357,22365]
name: get_many [22376,22384]
===
match
---
expr_stmt [11220,11265]
expr_stmt [11220,11265]
===
match
---
subscriptlist [23053,23078]
subscriptlist [23045,23070]
===
match
---
trailer [15969,15971]
trailer [15969,15971]
===
match
---
operator: -> [23042,23044]
operator: -> [23034,23036]
===
match
---
trailer [5640,5677]
trailer [5640,5677]
===
match
---
name: Optional [5506,5514]
name: Optional [5506,5514]
===
match
---
arglist [11909,11957]
arglist [11909,11957]
===
match
---
name: traceback [21596,21605]
name: traceback [21602,21611]
===
match
---
simple_stmt [20135,20160]
simple_stmt [20141,20166]
===
match
---
operator: , [17657,17658]
operator: , [17657,17658]
===
match
---
trailer [6023,6034]
trailer [6023,6034]
===
match
---
string: "Inquiring about %s celery task(s)" [15822,15857]
string: "Inquiring about %s celery task(s)" [15822,15857]
===
match
---
name: adopted_task_timeouts [13947,13968]
name: adopted_task_timeouts [13947,13968]
===
match
---
name: map [25211,25214]
name: map [25213,25216]
===
match
---
operator: , [21682,21683]
operator: , [21688,21689]
===
match
---
string: 'task_publish_max_retries' [8387,8413]
string: 'task_publish_max_retries' [8387,8413]
===
match
---
simple_stmt [1534,1609]
simple_stmt [1534,1609]
===
match
---
expr_stmt [4169,4176]
expr_stmt [4169,4176]
===
match
---
name: logging [4221,4228]
name: logging [4221,4228]
===
match
---
simple_stmt [23327,23423]
simple_stmt [23324,23420]
===
match
---
if_stmt [16615,17149]
if_stmt [16615,17149]
===
match
---
name: tis [17930,17933]
name: tis [17930,17933]
===
match
---
comparison [17005,17035]
comparison [17005,17035]
===
match
---
name: self [8333,8337]
name: self [8333,8337]
===
match
---
expr_stmt [9296,9353]
expr_stmt [9296,9353]
===
match
---
name: format_exc [6024,6034]
name: format_exc [6024,6034]
===
match
---
suite [25549,25819]
suite [25551,25821]
===
match
---
trailer [16753,16761]
trailer [16753,16761]
===
match
---
atom_expr [8365,8426]
atom_expr [8365,8426]
===
match
---
suite [4402,4552]
suite [4402,4552]
===
match
---
operator: , [17135,17136]
operator: , [17135,17136]
===
match
---
operator: = [2693,2694]
operator: = [2693,2694]
===
match
---
arglist [8480,8561]
arglist [8480,8561]
===
match
---
subscriptlist [5456,5525]
subscriptlist [5456,5525]
===
match
---
operator: , [8918,8919]
operator: , [8918,8919]
===
match
---
name: log [17229,17232]
name: log [17229,17232]
===
match
---
name: signal [12772,12778]
name: signal [12772,12778]
===
match
---
name: super [16334,16339]
name: super [16334,16339]
===
match
---
name: celery_configuration [2672,2692]
name: celery_configuration [2672,2692]
===
match
---
trailer [12447,12468]
trailer [12447,12468]
===
match
---
trailer [19234,19255]
trailer [19234,19255]
===
match
---
operator: = [2426,2427]
operator: = [2426,2427]
===
match
---
trailer [25100,25105]
trailer [25102,25107]
===
match
---
operator: , [23489,23490]
operator: , [23486,23487]
===
match
---
name: Task [5521,5525]
name: Task [5521,5525]
===
match
---
trailer [19673,19675]
trailer [19679,19681]
===
match
---
name: executors [1840,1849]
name: executors [1840,1849]
===
match
---
name: backend [23742,23749]
name: backend [23744,23751]
===
match
---
name: self [9629,9633]
name: self [9629,9633]
===
match
---
simple_stmt [5267,5304]
simple_stmt [5267,5304]
===
match
---
if_stmt [19163,19363]
if_stmt [19163,19363]
===
match
---
operator: = [2268,2269]
operator: = [2268,2269]
===
match
---
name: backend [19842,19849]
name: backend [19848,19855]
===
match
---
atom_expr [25096,25156]
atom_expr [25098,25158]
===
match
---
name: queued_tasks [9267,9279]
name: queued_tasks [9267,9279]
===
match
---
string: "executor.adopted_task_timeouts (%d)\n\t%s" [15537,15580]
string: "executor.adopted_task_timeouts (%d)\n\t%s" [15537,15580]
===
match
---
trailer [20099,20105]
trailer [20105,20111]
===
match
---
import_name [942,957]
import_name [942,957]
===
match
---
atom_expr [2992,3038]
atom_expr [2992,3038]
===
match
---
for_stmt [24412,24801]
for_stmt [24414,24803]
===
match
---
simple_stmt [942,958]
simple_stmt [942,958]
===
match
---
testlist_star_expr [16092,16103]
testlist_star_expr [16092,16103]
===
match
---
name: task_tuples_to_send [9649,9668]
name: task_tuples_to_send [9649,9668]
===
match
---
exprlist [10108,10122]
exprlist [10108,10122]
===
match
---
name: command_to_exec [3190,3205]
name: command_to_exec [3190,3205]
===
match
---
expr_stmt [8333,8426]
expr_stmt [8333,8426]
===
match
---
trailer [23052,23079]
trailer [23044,23071]
===
match
---
name: items [19760,19765]
name: items [19766,19771]
===
match
---
number: 1.0 [8843,8846]
number: 1.0 [8843,8846]
===
match
---
atom [11756,11786]
atom [11756,11786]
===
match
---
operator: , [5633,5634]
operator: , [5633,5634]
===
match
---
name: pid [3423,3426]
name: pid [3423,3426]
===
match
---
trailer [4156,4159]
trailer [4156,4159]
===
match
---
name: airflow [3629,3636]
name: airflow [3629,3636]
===
match
---
trailer [23881,23891]
trailer [23883,23893]
===
match
---
operator: , [3404,3405]
operator: , [3404,3405]
===
match
---
string: "\n\t" [15639,15645]
string: "\n\t" [15639,15645]
===
match
---
string: "info" [24630,24636]
string: "info" [24632,24638]
===
match
---
simple_stmt [8107,8247]
simple_stmt [8107,8247]
===
match
---
name: ti [20039,20041]
name: ti [20045,20047]
===
match
---
operator: = [9951,9952]
operator: = [9951,9952]
===
match
---
name: Task [1397,1401]
name: Task [1397,1401]
===
match
---
trailer [15389,15501]
trailer [15389,15501]
===
match
---
name: adopted_task_timeouts [16951,16972]
name: adopted_task_timeouts [16951,16972]
===
match
---
name: sync_pool [25201,25210]
name: sync_pool [25203,25212]
===
match
---
name: conf [2477,2481]
name: conf [2477,2481]
===
match
---
name: local_task_job [6665,6679]
name: local_task_job [6665,6679]
===
match
---
operator: , [22401,22402]
operator: , [22420,22421]
===
match
---
atom_expr [15449,15491]
atom_expr [15449,15491]
===
match
---
name: get_key_for_task [23165,23181]
name: get_key_for_task [23162,23178]
===
match
---
name: _process_tasks [9679,9693]
name: _process_tasks [9679,9693]
===
match
---
arith_expr [7806,7821]
arith_expr [7806,7821]
===
match
---
simple_stmt [4034,4042]
simple_stmt [4034,4042]
===
match
---
trailer [23953,23969]
trailer [23955,23971]
===
match
---
expr_stmt [8107,8246]
expr_stmt [8107,8246]
===
match
---
operator: = [9377,9378]
operator: = [9377,9378]
===
match
---
comparison [17395,17439]
comparison [17395,17439]
===
match
---
name: command_to_exec [2921,2936]
name: command_to_exec [2921,2936]
===
match
---
arglist [24617,24636]
arglist [24619,24638]
===
match
---
name: self [17224,17228]
name: self [17224,17228]
===
match
---
name: str [5515,5518]
name: str [5515,5518]
===
match
---
name: conf [1754,1758]
name: conf [1754,1758]
===
match
---
trailer [23224,23232]
trailer [23221,23229]
===
match
---
import_from [1138,1226]
import_from [1138,1226]
===
match
---
simple_stmt [20355,20493]
simple_stmt [20361,20499]
===
match
---
decorator [24190,24204]
decorator [24192,24206]
===
match
---
operator: , [16270,16271]
operator: , [16270,16271]
===
match
---
trailer [8842,8888]
trailer [8842,8888]
===
match
---
trailer [24953,24997]
trailer [24955,24999]
===
match
---
name: app [23221,23224]
name: app [23218,23221]
===
match
---
name: OrderedDict [8085,8096]
name: OrderedDict [8085,8096]
===
match
---
name: airflow [6691,6698]
name: airflow [6691,6698]
===
match
---
argument [2522,2534]
argument [2522,2534]
===
match
---
name: exception [25732,25741]
name: exception [25734,25743]
===
match
---
suite [23608,24185]
suite [23605,24187]
===
match
---
atom_expr [15651,15696]
atom_expr [15651,15696]
===
match
---
operator: = [4536,4537]
operator: = [4536,4537]
===
match
---
simple_stmt [8815,8891]
simple_stmt [8815,8891]
===
match
---
name: result [11914,11920]
name: result [11914,11920]
===
match
---
name: key [6115,6118]
name: key [6115,6118]
===
match
---
name: self [8442,8446]
name: self [8442,8446]
===
match
---
operator: , [21465,21466]
operator: , [21471,21472]
===
match
---
name: task_results_by_task_id [24160,24183]
name: task_results_by_task_id [24162,24185]
===
match
---
name: TaskInstanceInCelery [9191,9211]
name: TaskInstanceInCelery [9191,9211]
===
match
---
name: args [3901,3905]
name: args [3901,3905]
===
match
---
trailer [2631,2666]
trailer [2631,2666]
===
match
---
suite [9283,9584]
suite [9283,9584]
===
match
---
name: self [22241,22245]
name: self [22147,22151]
===
match
---
name: key [16355,16358]
name: key [16355,16358]
===
match
---
name: self [16059,16063]
name: self [16059,16063]
===
match
---
dotted_name [1651,1690]
dotted_name [1651,1690]
===
match
---
arglist [13071,13134]
arglist [13071,13134]
===
match
---
name: self [13942,13946]
name: self [13942,13946]
===
match
---
simple_stmt [22306,22348]
simple_stmt [22212,22254]
===
match
---
name: pool [3695,3699]
name: pool [3695,3699]
===
match
---
name: debug [10070,10075]
name: debug [10070,10075]
===
match
---
operator: -> [8937,8939]
operator: -> [8937,8939]
===
match
---
arglist [16396,16405]
arglist [16396,16405]
===
match
---
operator: = [19122,19123]
operator: = [19122,19123]
===
match
---
operator: , [11912,11913]
operator: , [11912,11913]
===
match
---
param [17313,17338]
param [17313,17338]
===
match
---
funcdef [24208,24827]
funcdef [24210,24829]
===
match
---
trailer [9350,9353]
trailer [9350,9353]
===
match
---
name: update_all_task_states [15718,15740]
name: update_all_task_states [15718,15740]
===
match
---
atom_expr [20106,20112]
atom_expr [20112,20118]
===
match
---
trailer [12909,12917]
trailer [12909,12917]
===
match
---
operator: , [15039,15040]
operator: , [15039,15040]
===
match
---
name: task_ids [23194,23202]
name: task_ids [23191,23199]
===
match
---
name: _check_for_stalled_adopted_tasks [13425,13457]
name: _check_for_stalled_adopted_tasks [13425,13457]
===
match
---
expr_stmt [5232,5258]
expr_stmt [5232,5258]
===
match
---
name: AsyncResult [5641,5652]
name: AsyncResult [5641,5652]
===
match
---
name: self [10317,10321]
name: self [10317,10321]
===
match
---
arglist [2823,2850]
arglist [2823,2850]
===
match
---
string: """         How many Celery tasks should each worker process send.          :return: Number of tasks that should be sent per process         :rtype: int         """ [8642,8806]
string: """         How many Celery tasks should each worker process send.          :return: Number of tasks that should be sent per process         :rtype: int         """ [8642,8806]
===
match
---
import_as_name [1261,1284]
import_as_name [1261,1284]
===
match
---
name: self [7874,7878]
name: self [7874,7878]
===
match
---
name: task_results [23252,23264]
name: task_results [23249,23261]
===
match
---
operator: , [25365,25366]
operator: , [25367,25368]
===
match
---
atom_expr [17413,17439]
atom_expr [17413,17439]
===
match
---
param [24874,24887]
param [24876,24889]
===
match
---
fstring [5988,6038]
fstring [5988,6038]
===
match
---
parameters [9693,9748]
parameters [9693,9748]
===
match
---
atom_expr [8465,8562]
atom_expr [8465,8562]
===
match
---
simple_stmt [4370,4394]
simple_stmt [4370,4394]
===
match
---
name: str [24309,24312]
name: str [24311,24314]
===
match
---
parameters [17923,17954]
parameters [17923,17954]
===
match
---
name: OPERATION_TIMEOUT [21168,21185]
name: OPERATION_TIMEOUT [21174,21191]
===
match
---
expr_stmt [23617,23664]
expr_stmt [23614,23666]
===
match
---
name: update_task_state [11891,11908]
name: update_task_state [11891,11908]
===
match
---
atom_expr [8311,8324]
atom_expr [8311,8324]
===
match
---
name: Mapping [24892,24899]
name: Mapping [24894,24901]
===
match
---
tfpdef [17600,17620]
tfpdef [17600,17620]
===
match
---
trailer [13342,13365]
trailer [13342,13365]
===
match
---
name: to_send_count [8849,8862]
name: to_send_count [8849,8862]
===
match
---
atom_expr [20039,20053]
atom_expr [20045,20059]
===
match
---
name: chunksize [13125,13134]
name: chunksize [13125,13134]
===
match
---
trailer [19648,19677]
trailer [19654,19683]
===
match
---
name: error [25579,25584]
name: error [25581,25586]
===
match
---
atom_expr [19557,19578]
atom_expr [19562,19583]
===
match
---
operator: -> [15269,15271]
operator: -> [15269,15271]
===
match
---
arglist [21374,21394]
arglist [21380,21400]
===
match
---
name: task_result [24617,24628]
name: task_result [24619,24630]
===
match
---
comparison [12090,12117]
comparison [12090,12117]
===
match
---
suite [2959,3259]
suite [2959,3259]
===
match
---
name: result [11319,11325]
name: result [11319,11325]
===
match
---
trailer [17394,17472]
trailer [17394,17472]
===
match
---
atom [23353,23422]
atom [23350,23419]
===
match
---
atom_expr [19483,19589]
atom_expr [19529,19585]
===
match
---
name: list [16054,16058]
name: list [16054,16058]
===
match
---
annassign [24355,24403]
annassign [24357,24405]
===
match
---
operator: } [21592,21593]
operator: } [21598,21599]
===
match
---
operator: = [22734,22735]
operator: = [22729,22730]
===
match
---
trailer [25210,25214]
trailer [25212,25216]
===
match
---
suite [3158,3207]
suite [3158,3207]
===
match
---
name: int [8629,8632]
name: int [8629,8632]
===
match
---
dotted_name [2892,2900]
dotted_name [2892,2900]
===
match
---
simple_stmt [23212,23244]
simple_stmt [23209,23241]
===
match
---
trailer [13262,13268]
trailer [13262,13268]
===
match
---
suite [3352,3555]
suite [3352,3555]
===
match
---
name: _ [9311,9312]
name: _ [9311,9312]
===
match
---
name: os [4376,4378]
name: os [4376,4378]
===
match
---
name: task_id [11778,11785]
name: task_id [11778,11785]
===
match
---
atom_expr [22306,22328]
atom_expr [22212,22234]
===
match
---
operator: = [7917,7918]
operator: = [7917,7918]
===
match
---
name: repr [15655,15659]
name: repr [15655,15659]
===
match
---
subscriptlist [22398,22423]
subscriptlist [22417,22442]
===
match
---
name: task_id_to_states_and_info [25447,25473]
name: task_id_to_states_and_info [25449,25475]
===
match
---
name: self [20135,20139]
name: self [20141,20145]
===
match
---
name: stalled_after [13925,13938]
name: stalled_after [13925,13938]
===
match
---
name: task_id [23870,23877]
name: task_id [23872,23879]
===
match
---
name: debug [15816,15821]
name: debug [15816,15821]
===
match
---
operator: , [17704,17705]
operator: , [17704,17705]
===
match
---
name: airflow [1617,1624]
name: airflow [1617,1624]
===
match
---
simple_stmt [3480,3555]
simple_stmt [3480,3555]
===
match
---
name: sync_parallelism [22331,22347]
name: sync_parallelism [22237,22253]
===
match
---
simple_stmt [9441,9480]
simple_stmt [9441,9480]
===
match
---
name: Union [20596,20601]
name: Union [20602,20607]
===
match
---
trailer [13268,13310]
trailer [13268,13310]
===
match
---
name: Optional [1199,1207]
name: Optional [1199,1207]
===
match
---
simple_stmt [19781,19823]
simple_stmt [19787,19829]
===
match
---
trailer [23935,23953]
trailer [23937,23955]
===
match
---
test [21345,21405]
test [21351,21411]
===
match
---
simple_stmt [9103,9156]
simple_stmt [9103,9156]
===
match
---
name: macros [6699,6705]
name: macros [6699,6705]
===
match
---
name: getint [8370,8376]
name: getint [8370,8376]
===
match
---
name: log [10541,10544]
name: log [10541,10544]
===
match
---
atom_expr [16106,16164]
atom_expr [16106,16164]
===
match
---
atom_expr [10239,10255]
atom_expr [10239,10255]
===
match
---
name: import_modules [1494,1508]
name: import_modules [1494,1508]
===
match
---
name: t [9784,9785]
name: t [9784,9785]
===
match
---
simple_stmt [22279,22298]
simple_stmt [22185,22204]
===
match
---
atom_expr [10810,10840]
atom_expr [10810,10840]
===
match
---
if_stmt [19372,19447]
if_stmt [19372,19447]
===
match
---
arith_expr [11108,11149]
arith_expr [11108,11149]
===
match
---
operator: , [23584,23585]
operator: , [23581,23582]
===
match
---
trailer [12443,12469]
trailer [12443,12469]
===
match
---
atom_expr [20355,20492]
atom_expr [20361,20498]
===
match
---
simple_stmt [1058,1094]
simple_stmt [1058,1094]
===
match
---
trailer [10486,10515]
trailer [10486,10515]
===
match
---
name: Exception [5910,5919]
name: Exception [5910,5919]
===
match
---
trailer [8018,8040]
trailer [8018,8040]
===
match
---
trailer [4741,4748]
trailer [4741,4748]
===
match
---
name: Optional [17637,17645]
name: Optional [17637,17645]
===
match
---
name: self [16946,16950]
name: self [16946,16950]
===
match
---
trailer [7659,7677]
trailer [7659,7677]
===
match
---
argument [25017,25038]
argument [25019,25040]
===
match
---
funcdef [17299,17524]
funcdef [17299,17524]
===
match
---
trailer [12879,12886]
trailer [12879,12886]
===
match
---
name: TaskInstance [17963,17975]
name: TaskInstance [17963,17975]
===
match
---
trailer [9261,9280]
trailer [9261,9280]
===
match
---
string: "[Try %s of %s] Task Timeout Error for Task: (%s)." [10575,10626]
string: "[Try %s of %s] Task Timeout Error for Task: (%s)." [10575,10626]
===
match
---
tfpdef [17570,17590]
tfpdef [17570,17590]
===
match
---
name: key [6007,6010]
name: key [6007,6010]
===
match
---
name: airflow [6751,6758]
name: airflow [6751,6758]
===
match
---
trailer [16840,16848]
trailer [16840,16848]
===
match
---
param [17924,17929]
param [17924,17929]
===
match
---
name: send_pool [12993,13002]
name: send_pool [12993,13002]
===
match
---
argument [9784,9817]
argument [9784,9817]
===
match
---
name: datetime [8073,8081]
name: datetime [8073,8081]
===
match
---
operator: , [24266,24267]
operator: , [24268,24269]
===
match
---
name: _sync_parallelism [22311,22328]
name: _sync_parallelism [22217,22234]
===
match
---
trailer [15179,15185]
trailer [15179,15185]
===
match
---
name: SUCCESS [16641,16648]
name: SUCCESS [16641,16648]
===
match
---
operator: = [12492,12493]
operator: = [12492,12493]
===
match
---
name: key [11749,11752]
name: key [11749,11752]
===
match
---
expr_stmt [11731,11786]
expr_stmt [11731,11786]
===
match
---
operator: , [1991,1992]
operator: , [1991,1992]
===
match
---
decorator [2891,2901]
decorator [2891,2901]
===
match
---
name: task_ids [23481,23489]
name: task_ids [23478,23486]
===
match
---
name: READY_STATES [17427,17439]
name: READY_STATES [17427,17439]
===
match
---
name: exception [5237,5246]
name: exception [5237,5246]
===
match
---
simple_stmt [5966,6039]
simple_stmt [5966,6039]
===
match
---
operator: , [16449,16450]
operator: , [16449,16450]
===
match
---
if_stmt [16177,16244]
if_stmt [16177,16244]
===
match
---
string: "Adopted tasks were still pending after %s, assuming they never made it to celery and " [14811,14898]
string: "Adopted tasks were still pending after %s, assuming they never made it to celery and " [14811,14898]
===
match
---
atom_expr [10652,10682]
atom_expr [10652,10682]
===
match
---
name: log [4109,4112]
name: log [4109,4112]
===
match
---
name: self [10369,10373]
name: self [10369,10373]
===
match
---
name: key [16033,16036]
name: key [16033,16036]
===
match
---
if_stmt [17357,17504]
if_stmt [17357,17504]
===
match
---
expr_stmt [4758,4814]
expr_stmt [4758,4814]
===
match
---
dotted_name [2226,2248]
dotted_name [2226,2248]
===
match
---
trailer [23123,23136]
trailer [23120,23133]
===
match
---
name: chunksize [25282,25291]
name: chunksize [25284,25293]
===
match
---
name: info [16367,16371]
name: info [16367,16371]
===
match
---
name: task_result [23394,23405]
name: task_result [23391,23402]
===
match
---
atom_expr [15982,16020]
atom_expr [15982,16020]
===
match
---
trailer [2277,2287]
trailer [2277,2287]
===
match
---
arglist [22529,22566]
arglist [22548,22585]
===
match
---
simple_stmt [24590,24663]
simple_stmt [24592,24665]
===
match
---
atom_expr [25085,25157]
atom_expr [25087,25159]
===
match
---
simple_stmt [2009,2041]
simple_stmt [2009,2041]
===
match
---
with_stmt [23779,23899]
with_stmt [23781,23901]
===
match
---
fstring_start: f" [21561,21563]
fstring_start: f" [21567,21569]
===
match
---
simple_stmt [4887,5151]
simple_stmt [4887,5151]
===
match
---
simple_stmt [25319,25394]
simple_stmt [25321,25396]
===
match
---
trailer [8376,8426]
trailer [8376,8426]
===
match
---
operator: , [5740,5741]
operator: , [5740,5741]
===
match
---
expr_stmt [22306,22347]
expr_stmt [22212,22253]
===
match
---
simple_stmt [1094,1138]
simple_stmt [1094,1138]
===
match
---
suite [5679,6136]
suite [5679,6136]
===
match
---
trailer [8144,8154]
trailer [8144,8154]
===
match
---
name: engine [3727,3733]
name: engine [3727,3733]
===
match
---
name: CommandType [4344,4355]
name: CommandType [4344,4355]
===
match
---
atom_expr [10005,10052]
atom_expr [10005,10052]
===
match
---
name: msg [4846,4849]
name: msg [4846,4849]
===
match
---
import_as_names [1247,1284]
import_as_names [1247,1284]
===
match
---
operator: = [4374,4375]
operator: = [4374,4375]
===
match
---
name: sleep [17495,17500]
name: sleep [17495,17500]
===
match
---
number: 1.0 [25106,25109]
number: 1.0 [25108,25111]
===
match
---
operator: = [16310,16311]
operator: = [16310,16311]
===
match
---
name: self [17924,17928]
name: self [17924,17928]
===
match
---
trailer [4669,4721]
trailer [4669,4721]
===
match
---
name: self [22306,22310]
name: self [22212,22216]
===
match
---
name: _ [10113,10114]
name: _ [10113,10114]
===
match
---
suite [25840,25924]
suite [25842,25926]
===
match
---
name: task_result [24048,24059]
name: task_result [24050,24061]
===
match
---
trailer [13234,13240]
trailer [13234,13240]
===
match
---
name: self [20002,20006]
name: self [20008,20012]
===
match
---
number: 1 [4175,4176]
number: 1 [4175,4176]
===
match
---
operator: / [25131,25132]
operator: / [25133,25134]
===
match
---
atom_expr [10887,10913]
atom_expr [10887,10913]
===
match
---
name: self [15376,15380]
name: self [15376,15380]
===
match
---
simple_stmt [4169,4177]
simple_stmt [4169,4177]
===
match
---
name: airflow [1764,1771]
name: airflow [1764,1771]
===
match
---
dotted_name [1617,1633]
dotted_name [1617,1633]
===
match
---
arglist [5870,5897]
arglist [5870,5897]
===
match
---
trailer [16670,16678]
trailer [16670,16678]
===
match
---
name: backend [23157,23164]
name: backend [23154,23161]
===
match
---
simple_stmt [13016,13149]
simple_stmt [13016,13149]
===
match
---
simple_stmt [8255,8325]
simple_stmt [8255,8325]
===
match
---
param [22372,22385]
param [22391,22404]
===
match
---
simple_stmt [21539,21621]
simple_stmt [21545,21627]
===
match
---
name: getfloat [2482,2490]
name: getfloat [2482,2490]
===
match
---
operator: } [23421,23422]
operator: } [23418,23419]
===
match
---
trailer [20147,20151]
trailer [20153,20157]
===
match
---
name: timeout [2198,2205]
name: timeout [2198,2205]
===
match
---
trailer [23860,23892]
trailer [23862,23894]
===
match
---
for_stmt [16029,16244]
for_stmt [16029,16244]
===
match
---
comp_if [23313,23317]
comp_if [23310,23314]
===
match
---
name: fetch_celery_task_state [20531,20554]
name: fetch_celery_task_state [20537,20560]
===
match
---
expr_stmt [23822,23898]
expr_stmt [23824,23900]
===
match
---
name: exception_traceback [21539,21558]
name: exception_traceback [21545,21564]
===
match
---
import_name [958,972]
import_name [958,972]
===
match
---
atom_expr [3539,3553]
atom_expr [3539,3553]
===
match
---
atom_expr [7831,7854]
atom_expr [7831,7854]
===
match
---
atom_expr [22825,22876]
atom_expr [22812,22863]
===
match
---
name: pop [16442,16445]
name: pop [16442,16445]
===
match
---
parameters [8599,8625]
parameters [8599,8625]
===
match
---
name: isinstance [10976,10986]
name: isinstance [10976,10986]
===
match
---
operator: , [2640,2641]
operator: , [2640,2641]
===
match
---
trailer [20028,20036]
trailer [20034,20042]
===
match
---
trailer [23694,23708]
trailer [23696,23710]
===
match
---
name: sentry [3573,3579]
name: sentry [3573,3579]
===
match
---
name: _execute_in_subprocess [3167,3189]
name: _execute_in_subprocess [3167,3189]
===
match
---
simple_stmt [15510,15709]
simple_stmt [15510,15709]
===
match
---
atom_expr [12887,12901]
atom_expr [12887,12901]
===
match
---
comparison [16707,16762]
comparison [16707,16762]
===
match
---
trailer [19541,19552]
trailer [19546,19557]
===
match
---
name: info [16684,16688]
name: info [16684,16688]
===
match
---
trailer [22936,22944]
trailer [22928,22936]
===
match
---
simple_stmt [8333,8427]
simple_stmt [8333,8427]
===
match
---
arglist [16446,16455]
arglist [16446,16455]
===
match
---
name: info [21467,21471]
name: info [21473,21477]
===
match
---
atom_expr [24609,24637]
atom_expr [24611,24639]
===
match
---
trailer [23651,23664]
trailer [23653,23666]
===
match
---
operator: , [12243,12244]
operator: , [12243,12244]
===
match
---
simple_stmt [973,985]
simple_stmt [973,985]
===
match
---
atom_expr [15175,15190]
atom_expr [15175,15190]
===
match
---
atom_expr [19794,19822]
atom_expr [19800,19828]
===
match
---
atom_expr [4221,4239]
atom_expr [4221,4239]
===
match
---
trailer [15650,15697]
trailer [15650,15697]
===
match
---
trailer [19569,19576]
trailer [19574,19581]
===
match
---
operator: , [25417,25418]
operator: , [25419,25420]
===
match
---
operator: , [4525,4526]
operator: , [4525,4526]
===
match
---
import_name [6613,6625]
import_name [6613,6625]
===
match
---
comparison [11283,11301]
comparison [11283,11301]
===
match
---
atom_expr [23439,23515]
atom_expr [23436,23512]
===
match
---
name: t [9793,9794]
name: t [9793,9794]
===
match
---
name: state [16294,16299]
name: state [16294,16299]
===
match
---
name: command [17600,17607]
name: command [17600,17607]
===
match
---
param [15741,15745]
param [15741,15745]
===
match
---
operator: { [19095,19096]
operator: { [19095,19096]
===
match
---
atom_expr [15436,15446]
atom_expr [15436,15446]
===
match
---
expr_stmt [24590,24662]
expr_stmt [24592,24664]
===
match
---
name: state [17142,17147]
name: state [17142,17147]
===
match
---
suite [17712,17851]
suite [17712,17851]
===
match
---
trailer [15487,15489]
trailer [15487,15489]
===
match
---
atom [25391,25393]
atom [25393,25395]
===
match
---
suite [3615,4042]
suite [3615,4042]
===
match
---
name: result [11151,11157]
name: result [11151,11157]
===
match
---
not_test [19375,19391]
not_test [19375,19391]
===
match
---
name: map [19529,19532]
name: map [19534,19537]
===
match
---
name: client [6862,6868]
name: client [6862,6868]
===
match
---
operator: = [15132,15133]
operator: = [15132,15133]
===
match
---
simple_stmt [15207,15243]
simple_stmt [15207,15243]
===
match
---
name: airflow [6787,6794]
name: airflow [6787,6794]
===
match
---
string: 'celery_config_options' [2642,2665]
string: 'celery_config_options' [2642,2665]
===
match
---
trailer [23869,23877]
trailer [23871,23879]
===
match
---
suite [22425,22988]
suite [22444,22980]
===
match
---
trailer [3004,3021]
trailer [3004,3021]
===
match
---
name: debug [8474,8479]
name: debug [8474,8479]
===
match
---
trailer [11748,11753]
trailer [11748,11753]
===
match
---
simple_stmt [3464,3471]
simple_stmt [3464,3471]
===
match
---
simple_stmt [3718,3744]
simple_stmt [3718,3744]
===
match
---
if_stmt [9593,9670]
if_stmt [9593,9670]
===
match
---
name: log [15381,15384]
name: log [15381,15384]
===
match
---
trailer [20194,20215]
trailer [20200,20221]
===
match
---
name: result [10987,10993]
name: result [10987,10993]
===
match
---
name: key [16272,16275]
name: key [16272,16275]
===
match
---
name: datetime [8136,8144]
name: datetime [8136,8144]
===
match
---
atom_expr [23100,23136]
atom_expr [23092,23133]
===
match
---
operator: , [6127,6128]
operator: , [6127,6128]
===
match
---
name: super [22279,22284]
name: super [22185,22190]
===
match
---
atom_expr [23924,23969]
atom_expr [23926,23971]
===
match
---
atom_expr [4198,4212]
atom_expr [4198,4212]
===
match
---
name: int [8621,8624]
name: int [8621,8624]
===
match
---
trailer [16976,16987]
trailer [16976,16987]
===
match
---
arglist [11108,11185]
arglist [11108,11185]
===
match
---
trailer [16784,16789]
trailer [16784,16789]
===
match
---
atom_expr [11151,11167]
atom_expr [11151,11167]
===
match
---
atom_expr [3679,3709]
atom_expr [3679,3709]
===
match
---
string: "Failed to execute task %s." [4123,4151]
string: "Failed to execute task %s." [4123,4151]
===
match
---
trailer [23232,23237]
trailer [23229,23234]
===
match
---
name: Any [20632,20635]
name: Any [20638,20641]
===
match
---
atom_expr [25012,25039]
atom_expr [25014,25041]
===
match
---
simple_stmt [20228,20269]
simple_stmt [20234,20275]
===
match
---
name: _prepare_state_and_info_by_task_dict [24113,24149]
name: _prepare_state_and_info_by_task_dict [24115,24151]
===
match
---
trailer [15811,15815]
trailer [15811,15815]
===
match
---
name: LoggingMixin [2085,2097]
name: LoggingMixin [2085,2097]
===
match
---
name: ti [19298,19300]
name: ti [19298,19300]
===
match
---
name: first_task [9766,9776]
name: first_task [9766,9776]
===
match
---
name: command [5876,5883]
name: command [5876,5883]
===
match
---
trailer [3694,3699]
trailer [3694,3699]
===
match
---
trailer [9241,9282]
trailer [9241,9282]
===
match
---
expr_stmt [12478,12547]
expr_stmt [12478,12547]
===
match
---
name: key [15127,15130]
name: key [15127,15130]
===
match
---
import_from [1285,1342]
import_from [1285,1342]
===
match
---
name: airflow [2046,2053]
name: airflow [2046,2053]
===
match
---
fstring_string:  in state  [20249,20259]
fstring_string:  in state  [20255,20265]
===
match
---
string: "task_cls" [23751,23761]
string: "task_cls" [23753,23763]
===
match
---
name: task_ids [24150,24158]
name: task_ids [24152,24160]
===
match
---
atom_expr [15109,15131]
atom_expr [15109,15131]
===
match
---
operator: , [17140,17141]
operator: , [17140,17141]
===
match
---
name: self [15807,15811]
name: self [15807,15811]
===
match
---
trailer [23966,23968]
trailer [23968,23970]
===
match
---
trailer [15126,15131]
trailer [15126,15131]
===
match
---
atom_expr [4612,4641]
atom_expr [4612,4641]
===
match
---
atom [15006,15038]
atom [15006,15038]
===
match
---
name: task_id [25410,25417]
name: task_id [25412,25419]
===
match
---
name: setproctitle [3941,3953]
name: setproctitle [3941,3953]
===
match
---
atom_expr [24643,24662]
atom_expr [24645,24664]
===
match
---
trailer [15645,15650]
trailer [15645,15650]
===
match
---
string: "No task to query celery, skipping sync" [13269,13309]
string: "No task to query celery, skipping sync" [13269,13309]
===
match
---
name: task_id [24778,24785]
name: task_id [24780,24787]
===
match
---
name: states_and_info_by_task_id [25939,25965]
name: states_and_info_by_task_id [25941,25967]
===
match
---
trailer [11777,11785]
trailer [11777,11785]
===
match
---
operator: = [24595,24596]
operator: = [24597,24598]
===
match
---
fstring_expr [21595,21619]
fstring_expr [21601,21625]
===
match
---
simple_stmt [4109,4161]
simple_stmt [4109,4161]
===
match
---
name: DEFAULT_CELERY_CONFIG [2778,2799]
name: DEFAULT_CELERY_CONFIG [2778,2799]
===
match
---
dotted_name [6851,6868]
dotted_name [6851,6868]
===
match
---
name: numpy [6620,6625]
name: numpy [6620,6625]
===
match
---
name: key [11423,11426]
name: key [11423,11426]
===
match
---
simple_stmt [6252,6573]
simple_stmt [6252,6573]
===
match
---
name: append [14728,14734]
name: append [14728,14734]
===
match
---
trailer [19274,19295]
trailer [19274,19295]
===
match
---
name: info [25919,25923]
name: info [25921,25925]
===
match
---
atom_expr [8085,8098]
atom_expr [8085,8098]
===
match
---
operator: , [25687,25688]
operator: , [25689,25690]
===
match
---
trailer [24616,24637]
trailer [24618,24639]
===
match
---
name: waitpid [3415,3422]
name: waitpid [3415,3422]
===
match
---
parameters [24867,24888]
parameters [24869,24890]
===
match
---
name: conf [2814,2818]
name: conf [2814,2818]
===
match
---
name: chunksize [13115,13124]
name: chunksize [13115,13124]
===
match
---
simple_stmt [4198,4213]
simple_stmt [4198,4213]
===
match
---
name: key [16977,16980]
name: key [16977,16980]
===
match
---
name: info [17101,17105]
name: info [17101,17105]
===
match
---
name: Sentry [3587,3593]
name: Sentry [3587,3593]
===
match
---
name: not_adopted_tis [19106,19121]
name: not_adopted_tis [19106,19121]
===
match
---
name: x [15019,15020]
name: x [15019,15020]
===
match
---
operator: == [7756,7758]
operator: == [7756,7758]
===
match
---
operator: , [12522,12523]
operator: , [12522,12523]
===
match
---
operator: = [19257,19258]
operator: = [19257,19258]
===
match
---
trailer [25016,25039]
trailer [25018,25041]
===
match
---
try_stmt [16598,17294]
try_stmt [16598,17294]
===
match
---
name: get_many [15943,15951]
name: get_many [15943,15951]
===
match
---
operator: , [23056,23057]
operator: , [23048,23049]
===
match
---
atom_expr [3941,4000]
atom_expr [3941,4000]
===
match
---
name: max [7799,7802]
name: max [7799,7802]
===
match
---
fstring [20243,20267]
fstring [20249,20273]
===
match
---
name: external_executor_id [19235,19255]
name: external_executor_id [19235,19255]
===
match
---
name: exception [4113,4122]
name: exception [4113,4122]
===
match
---
name: self [13380,13384]
name: self [13380,13384]
===
match
---
expr_stmt [3401,3430]
expr_stmt [3401,3430]
===
match
---
simple_stmt [24767,24801]
simple_stmt [24769,24803]
===
match
---
expr_stmt [23089,23136]
expr_stmt [23081,23133]
===
match
---
param [5175,5196]
param [5175,5196]
===
match
---
trailer [20363,20368]
trailer [20369,20374]
===
match
---
operator: -> [5596,5598]
operator: -> [5596,5598]
===
match
---
name: values [19570,19576]
name: values [19575,19581]
===
match
---
name: range [9236,9241]
name: range [9236,9241]
===
match
---
param [9694,9699]
param [9694,9699]
===
match
---
operator: , [1166,1167]
operator: , [1166,1167]
===
match
---
expr_stmt [7774,7822]
expr_stmt [7774,7822]
===
match
---
trailer [20006,20028]
trailer [20012,20034]
===
match
---
trailer [8837,8842]
trailer [8837,8842]
===
match
---
name: len [12444,12447]
name: len [12444,12447]
===
match
---
operator: = [5247,5248]
operator: = [5247,5248]
===
match
---
operator: = [13903,13904]
operator: = [13903,13904]
===
match
---
trailer [15821,15875]
trailer [15821,15875]
===
match
---
comparison [9495,9531]
comparison [9495,9531]
===
match
---
operator: = [7797,7798]
operator: = [7797,7798]
===
match
---
for_stmt [19136,19363]
for_stmt [19136,19363]
===
match
---
name: get_hostname [4800,4812]
name: get_hostname [4800,4812]
===
match
---
name: celery_tasks [19557,19569]
name: celery_tasks [19562,19574]
===
match
---
atom_expr [23221,23243]
atom_expr [23218,23240]
===
match
---
name: now [14009,14012]
name: now [14009,14012]
===
match
---
atom_expr [11036,11203]
atom_expr [11036,11203]
===
match
---
name: __init__ [22287,22295]
name: __init__ [22193,22201]
===
match
---
name: task_id [16156,16163]
name: task_id [16156,16163]
===
match
---
name: int [8829,8832]
name: int [8829,8832]
===
match
---
trailer [15352,15354]
trailer [15352,15354]
===
match
---
name: task_result [24515,24526]
name: task_result [24517,24528]
===
match
---
simple_stmt [25932,25966]
simple_stmt [25934,25968]
===
match
---
trailer [10549,10789]
trailer [10549,10789]
===
match
---
name: parser [3854,3860]
name: parser [3854,3860]
===
match
---
name: async_results [22950,22963]
name: async_results [22942,22955]
===
match
---
atom [23267,23318]
atom [23264,23315]
===
match
---
simple_stmt [19599,19612]
simple_stmt [19605,19618]
===
match
---
atom_expr [11220,11242]
atom_expr [11220,11242]
===
match
---
name: EventBufferValueType [23586,23606]
name: EventBufferValueType [23583,23603]
===
match
---
expr_stmt [19835,19873]
expr_stmt [19841,19879]
===
match
---
operator: , [11167,11168]
operator: , [11167,11168]
===
match
---
name: str [17646,17649]
name: str [17646,17649]
===
match
---
expr_stmt [7655,7721]
expr_stmt [7655,7721]
===
match
---
expr_stmt [5837,5898]
expr_stmt [5837,5898]
===
match
---
atom [19095,19097]
atom [19095,19097]
===
match
---
name: sorted_queue [9103,9115]
name: sorted_queue [9103,9115]
===
match
---
trailer [21616,21618]
trailer [21622,21624]
===
match
---
name: self [8865,8869]
name: self [8865,8869]
===
match
---
trailer [17456,17462]
trailer [17456,17462]
===
match
---
name: _sync_parallelism [8544,8561]
name: _sync_parallelism [8544,8561]
===
match
---
name: self [9118,9122]
name: self [9118,9122]
===
match
---
trailer [8322,8324]
trailer [8322,8324]
===
match
---
name: Tuple [20585,20590]
name: Tuple [20591,20596]
===
match
---
atom_expr [20056,20082]
atom_expr [20062,20088]
===
match
---
name: meta_from_decoded [23936,23953]
name: meta_from_decoded [23938,23955]
===
match
---
atom_expr [9242,9281]
atom_expr [9242,9281]
===
match
---
operator: = [3603,3604]
operator: = [3603,3604]
===
match
---
name: execute_command [9412,9427]
name: execute_command [9412,9427]
===
match
---
except_clause [6887,6905]
except_clause [6887,6905]
===
match
---
name: key [9380,9383]
name: key [9380,9383]
===
match
---
operator: , [5173,5174]
operator: , [5173,5174]
===
match
---
or_test [12057,12117]
or_test [12057,12117]
===
match
---
name: jinja2 [6584,6590]
name: jinja2 [6584,6590]
===
match
---
simple_stmt [7831,7898]
simple_stmt [7831,7898]
===
match
---
name: _ [5723,5724]
name: _ [5723,5724]
===
match
---
fstring_string: \n [21593,21595]
fstring_string: \n [21599,21601]
===
match
---
name: task_cls [23719,23727]
name: task_cls [23721,23729]
===
match
---
name: shut_down_logging [3906,3923]
name: shut_down_logging [3906,3923]
===
match
---
operator: = [8134,8135]
operator: = [8134,8135]
===
match
---
trailer [9266,9279]
trailer [9266,9279]
===
match
---
atom_expr [13254,13310]
atom_expr [13254,13310]
===
match
---
operator: } [25392,25393]
operator: } [25394,25395]
===
match
---
suite [22568,22662]
suite [22587,22655]
===
match
---
trailer [21357,21362]
trailer [21363,21368]
===
match
---
testlist_star_expr [19781,19791]
testlist_star_expr [19787,19797]
===
match
---
operator: = [11243,11244]
operator: = [11243,11244]
===
match
---
trailer [12893,12901]
trailer [12893,12901]
===
match
---
name: ceil [25101,25105]
name: ceil [25103,25107]
===
match
---
name: cli_parser [3641,3651]
name: cli_parser [3641,3651]
===
match
---
atom_expr [22885,22965]
atom_expr [22872,22957]
===
match
---
atom [19124,19126]
atom [19124,19126]
===
match
---
name: open_slots [8920,8930]
name: open_slots [8920,8930]
===
match
---
parameters [5168,5222]
parameters [5168,5222]
===
match
---
string: """Do not allow async execution for Celery executor.""" [17721,17776]
string: """Do not allow async execution for Celery executor.""" [17721,17776]
===
match
---
name: state_and_info_by_celery_task_id [16106,16138]
name: state_and_info_by_celery_task_id [16106,16138]
===
match
---
name: e [5923,5924]
name: e [5923,5924]
===
match
---
name: engine [3688,3694]
name: engine [3688,3694]
===
match
---
name: async_result [21345,21357]
name: async_result [21351,21363]
===
match
---
suite [14013,14163]
suite [14013,14163]
===
match
---
simple_stmt [2141,2179]
simple_stmt [2141,2179]
===
match
---
operator: = [5844,5845]
operator: = [5844,5845]
===
match
---
string: """     Gets status for many Celery tasks using the best method available      If BaseKeyValueStoreBackend is used as result backend, the mget method is used.     If DatabaseBackend is used as result backend, the SELECT ...WHERE task_id IN (...) query is used     Otherwise, multiprocessing.Pool will be used. Each task status will be downloaded individually.     """ [21855,22222]
string: """     Gets status for many Celery tasks using the best method available      If BaseKeyValueStoreBackend is used as result backend, the mget method is used.     If DatabaseBackend is used as result backend, the SELECT ...WHERE task_id IN (...) query is used     Otherwise, multiprocessing.Pool will be used. Each task status will be downloaded individually.     """ [21761,22128]
===
match
---
tfpdef [11996,12043]
tfpdef [11996,12043]
===
match
---
name: async_result [16143,16155]
name: async_result [16143,16155]
===
match
---
param [4327,4355]
param [4327,4355]
===
match
---
name: self [16415,16419]
name: self [16415,16419]
===
match
---
tfpdef [3282,3310]
tfpdef [3282,3310]
===
match
---
argument [12963,12988]
argument [12963,12988]
===
match
---
trailer [9574,9579]
trailer [9574,9579]
===
match
---
name: terminate [17860,17869]
name: terminate [17860,17869]
===
match
---
atom_expr [8064,8081]
atom_expr [8064,8081]
===
match
---
simple_stmt [17512,17524]
simple_stmt [17512,17524]
===
match
---
atom_expr [12829,12843]
atom_expr [12829,12843]
===
match
---
name: celery_states [16627,16640]
name: celery_states [16627,16640]
===
match
---
name: self [9262,9266]
name: self [9262,9266]
===
match
---
trailer [3707,3709]
trailer [3707,3709]
===
match
---
operator: , [9383,9384]
operator: , [9383,9384]
===
match
---
name: self [7733,7737]
name: self [7733,7737]
===
match
---
name: EventBufferValueType [22403,22423]
name: EventBufferValueType [22422,22442]
===
match
---
operator: , [6118,6119]
operator: , [6118,6119]
===
match
---
simple_stmt [6744,6776]
simple_stmt [6744,6776]
===
match
---
operator: , [9410,9411]
operator: , [9410,9411]
===
match
---
name: settings [3112,3120]
name: settings [3112,3120]
===
match
---
trailer [22683,22713]
trailer [22678,22708]
===
match
---
simple_stmt [6915,6920]
simple_stmt [6915,6920]
===
match
---
trailer [15215,15237]
trailer [15215,15237]
===
match
---
for_stmt [10104,11959]
for_stmt [10104,11959]
===
match
---
name: task_tuples_to_send [9441,9460]
name: task_tuples_to_send [9441,9460]
===
match
---
atom_expr [10164,10206]
atom_expr [10164,10206]
===
match
---
suite [13003,13149]
suite [13003,13149]
===
match
---
operator: , [1253,1254]
operator: , [1253,1254]
===
match
---
funcdef [6201,6920]
funcdef [6201,6920]
===
match
---
parameters [11989,12044]
parameters [11989,12044]
===
match
---
trailer [15481,15487]
trailer [15481,15487]
===
match
---
name: SIGINT [12779,12785]
name: SIGINT [12779,12785]
===
match
---
trailer [17939,17953]
trailer [17939,17953]
===
match
---
name: log [2060,2063]
name: log [2060,2063]
===
match
---
trailer [4518,4525]
trailer [4518,4525]
===
match
---
trailer [8259,8280]
trailer [8259,8280]
===
match
---
param [23557,23568]
param [23554,23565]
===
match
---
trailer [10174,10206]
trailer [10174,10206]
===
match
---
sync_comp_for [24060,24091]
sync_comp_for [24062,24093]
===
match
---
name: exception [10246,10255]
name: exception [10246,10255]
===
match
---
name: info [21358,21362]
name: info [21364,21368]
===
match
---
trailer [13365,13367]
trailer [13365,13367]
===
match
---
operator: = [7678,7679]
operator: = [7678,7679]
===
match
---
trailer [13877,13879]
trailer [13877,13879]
===
match
---
suite [16602,17149]
suite [16602,17149]
===
match
---
name: Tuple [5450,5455]
name: Tuple [5450,5455]
===
match
---
atom_expr [15863,15873]
atom_expr [15863,15873]
===
match
---
operator: > [14007,14008]
operator: > [14007,14008]
===
match
---
atom_expr [10976,11018]
atom_expr [10976,11018]
===
match
---
name: info [25439,25443]
name: info [25441,25445]
===
match
---
name: task_id [24491,24498]
name: task_id [24493,24500]
===
match
---
name: task_id_to_states_and_info [25172,25198]
name: task_id_to_states_and_info [25174,25200]
===
match
---
name: self [22736,22740]
name: self [22731,22735]
===
match
---
atom [9215,9217]
atom [9215,9217]
===
match
---
suite [17977,20525]
suite [17977,20531]
===
match
---
string: "Adopted the following %d tasks from a dead executor\n\t%s" [20386,20445]
string: "Adopted the following %d tasks from a dead executor\n\t%s" [20392,20451]
===
match
---
name: result [22727,22733]
name: result [22722,22728]
===
match
---
name: len [15859,15862]
name: len [15859,15862]
===
match
---
name: _ [9231,9232]
name: _ [9231,9232]
===
match
---
trailer [15435,15447]
trailer [15435,15447]
===
match
---
name: add [11387,11390]
name: add [11387,11390]
===
match
---
trailer [17096,17100]
trailer [17096,17100]
===
match
---
simple_stmt [17885,17890]
simple_stmt [17885,17890]
===
match
---
trailer [12886,12918]
trailer [12886,12918]
===
match
---
name: result [6129,6135]
name: result [6129,6135]
===
match
---
operator: , [1126,1127]
operator: , [1126,1127]
===
match
---
name: adopted_task_timeouts [13385,13406]
name: adopted_task_timeouts [13385,13406]
===
match
---
name: tasks [15441,15446]
name: tasks [15441,15446]
===
match
---
operator: = [6054,6055]
operator: = [6054,6055]
===
match
---
operator: , [17560,17561]
operator: , [17560,17561]
===
match
---
atom_expr [16415,16456]
atom_expr [16415,16456]
===
match
---
number: 600 [8232,8235]
number: 600 [8232,8235]
===
match
---
simple_stmt [25570,25819]
simple_stmt [25572,25821]
===
match
---
trailer [8046,8082]
trailer [8046,8082]
===
match
---
trailer [23741,23749]
trailer [23743,23751]
===
match
---
atom_expr [7733,7755]
atom_expr [7733,7755]
===
match
---
suite [16325,16457]
suite [16325,16457]
===
match
---
name: adopted_task_timeouts [15216,15237]
name: adopted_task_timeouts [15216,15237]
===
match
---
param [5560,5593]
param [5560,5593]
===
match
---
trailer [4733,4739]
trailer [4733,4739]
===
match
---
arglist [16977,16986]
arglist [16977,16986]
===
match
---
trailer [12778,12785]
trailer [12778,12785]
===
match
---
atom_expr [15639,15697]
atom_expr [15639,15697]
===
match
---
name: info [16524,16528]
name: info [16524,16528]
===
match
---
name: open_slots [9246,9256]
name: open_slots [9246,9256]
===
match
---
operator: , [20630,20631]
operator: , [20636,20637]
===
match
---
arglist [22900,22964]
arglist [22887,22956]
===
match
---
trailer [12415,12443]
trailer [12415,12443]
===
match
---
param [22366,22371]
param [22385,22390]
===
match
---
trailer [3699,3707]
trailer [3699,3707]
===
match
---
trailer [23896,23898]
trailer [23898,23900]
===
match
---
sync_comp_for [21789,21809]
sync_comp_for [22345,22365]
===
match
---
simple_stmt [9629,9670]
simple_stmt [9629,9670]
===
match
---
number: 4 [9786,9787]
number: 4 [9786,9787]
===
match
---
name: log [20360,20363]
name: log [20366,20369]
===
match
---
trailer [13049,13053]
trailer [13049,13053]
===
match
---
param [8600,8605]
param [8600,8605]
===
match
---
trailer [13424,13457]
trailer [13424,13457]
===
match
---
name: celery_task_id [19807,19821]
name: celery_task_id [19813,19827]
===
match
---
suite [13407,13460]
suite [13407,13460]
===
match
---
operator: , [5884,5885]
operator: , [5884,5885]
===
match
---
simple_stmt [3325,3341]
simple_stmt [3325,3341]
===
match
---
name: a [21793,21794]
name: a [22349,22350]
===
match
---
name: CELERY_FETCH_ERR_MSG_HEADER [2333,2360]
name: CELERY_FETCH_ERR_MSG_HEADER [2333,2360]
===
match
---
atom_expr [5267,5281]
atom_expr [5267,5281]
===
match
---
operator: * [25110,25111]
operator: * [25112,25113]
===
match
---
number: 0 [19553,19554]
number: 0 [19558,19559]
===
match
---
expr_stmt [11412,11436]
expr_stmt [11412,11436]
===
match
---
arith_expr [4764,4814]
arith_expr [4764,4814]
===
match
---
arglist [25232,25291]
arglist [25234,25293]
===
match
---
name: command_to_exec [3282,3297]
name: command_to_exec [3282,3297]
===
match
---
exprlist [13920,13938]
exprlist [13920,13938]
===
match
---
atom [16716,16762]
atom [16716,16762]
===
match
---
arglist [11936,11956]
arglist [11936,11956]
===
match
---
string: 'task_adoption_timeout' [8198,8221]
string: 'task_adoption_timeout' [8198,8221]
===
match
---
operator: , [8604,8605]
operator: , [8604,8605]
===
match
---
simple_stmt [13420,13460]
simple_stmt [13420,13460]
===
match
---
suite [3451,3471]
suite [3451,3471]
===
match
---
trailer [22284,22286]
trailer [22190,22192]
===
match
---
simple_stmt [15807,15876]
simple_stmt [15807,15876]
===
match
---
name: pid [3401,3404]
name: pid [3401,3404]
===
match
---
operator: = [20320,20321]
operator: = [20326,20327]
===
match
---
name: append [20236,20242]
name: append [20242,20248]
===
match
---
atom_expr [9784,9788]
atom_expr [9784,9788]
===
match
---
atom_expr [4010,4025]
atom_expr [4010,4025]
===
match
---
operator: } [24091,24092]
operator: } [24093,24094]
===
match
---
simple_stmt [23997,24093]
simple_stmt [23999,24095]
===
match
---
atom_expr [2814,2851]
atom_expr [2814,2851]
===
match
---
name: List [17958,17962]
name: List [17958,17962]
===
match
---
name: Stats [2035,2040]
name: Stats [2035,2040]
===
match
---
atom_expr [7857,7897]
atom_expr [7857,7897]
===
match
---
name: send_pool [13040,13049]
name: send_pool [13040,13049]
===
match
---
operator: = [25897,25898]
operator: = [25899,25900]
===
match
---
atom_expr [16780,16800]
atom_expr [16780,16800]
===
match
---
operator: = [21167,21168]
operator: = [21173,21174]
===
match
---
funcdef [22228,22348]
funcdef [22134,22254]
===
match
---
trailer [14783,14787]
trailer [14783,14787]
===
match
---
trailer [4019,4025]
trailer [4019,4025]
===
match
---
parameters [20554,20581]
parameters [20560,20587]
===
match
---
trailer [24978,24996]
trailer [24980,24998]
===
match
---
name: EXECUTE_TASKS_NEW_PYTHON_INTERPRETER [3121,3157]
name: EXECUTE_TASKS_NEW_PYTHON_INTERPRETER [3121,3157]
===
match
---
expr_stmt [24936,24997]
expr_stmt [24938,24999]
===
match
---
parameters [23022,23041]
parameters [23014,23033]
===
match
---
operator: , [16236,16237]
operator: , [16236,16237]
===
match
---
name: get_hostname [3539,3551]
name: get_hostname [3539,3551]
===
match
---
tfpdef [8920,8935]
tfpdef [8920,8935]
===
match
---
arith_expr [3503,3553]
arith_expr [3503,3553]
===
match
---
param [16306,16315]
param [16306,16315]
===
match
---
atom [21778,21810]
atom [22334,22366]
===
match
---
name: exception [5175,5184]
name: exception [5175,5184]
===
match
---
name: items [13969,13974]
name: items [13969,13974]
===
match
---
name: key_and_async_results [13016,13037]
name: key_and_async_results [13016,13037]
===
match
---
atom_expr [13420,13459]
atom_expr [13420,13459]
===
match
---
number: 1 [12085,12086]
number: 1 [12085,12086]
===
match
---
trailer [16678,16689]
trailer [16678,16689]
===
match
---
fstring_end: " [20266,20267]
fstring_end: " [20272,20273]
===
match
---
trailer [8473,8479]
trailer [8473,8479]
===
match
---
name: operators [6759,6768]
name: operators [6759,6768]
===
match
---
name: result [22816,22822]
name: result [22803,22809]
===
match
---
operator: , [17620,17621]
operator: , [17620,17621]
===
match
---
name: seconds [5797,5804]
name: seconds [5797,5804]
===
match
---
tfpdef [5175,5195]
tfpdef [5175,5195]
===
match
---
atom_expr [12758,12802]
atom_expr [12758,12802]
===
match
---
name: error [4734,4739]
name: error [4734,4739]
===
match
---
trailer [7878,7896]
trailer [7878,7896]
===
match
---
fstring_expr [20259,20266]
fstring_expr [20265,20272]
===
match
---
comparison [7733,7760]
comparison [7733,7760]
===
match
---
atom_expr [11886,11958]
atom_expr [11886,11958]
===
match
---
tfpdef [16272,16292]
tfpdef [16272,16292]
===
match
---
simple_stmt [25861,25924]
simple_stmt [25863,25926]
===
match
---
trailer [22295,22297]
trailer [22201,22203]
===
match
---
name: backends [1297,1305]
name: backends [1297,1305]
===
match
---
name: celery_configuration [2755,2775]
name: celery_configuration [2755,2775]
===
match
---
operator: == [16824,16826]
operator: == [16824,16826]
===
match
---
trailer [19680,19688]
trailer [19686,19694]
===
match
---
parameters [22240,22269]
parameters [22146,22175]
===
match
---
name: result [5837,5843]
name: result [5837,5843]
===
match
---
name: result [20116,20122]
name: result [20122,20128]
===
match
---
suite [14766,15243]
suite [14766,15243]
===
match
---
name: async_tasks [23557,23568]
name: async_tasks [23554,23565]
===
match
---
string: "task_id" [23366,23375]
string: "task_id" [23363,23372]
===
match
---
operator: , [23027,23028]
operator: , [23019,23020]
===
match
---
simple_stmt [20095,20123]
simple_stmt [20101,20129]
===
match
---
name: async_result [21374,21386]
name: async_result [21380,21392]
===
match
---
import_name [1001,1010]
import_name [1001,1010]
===
match
---
name: CommandType [1885,1896]
name: CommandType [1885,1896]
===
match
---
trailer [2481,2490]
trailer [2481,2490]
===
match
---
name: datetime [949,957]
name: datetime [949,957]
===
match
---
suite [12118,12267]
suite [12118,12267]
===
match
---
atom_expr [13871,13879]
atom_expr [13871,13879]
===
match
---
trailer [20359,20363]
trailer [20365,20369]
===
match
---
if_stmt [3439,3471]
if_stmt [3439,3471]
===
match
---
operator: , [8385,8386]
operator: , [8385,8386]
===
match
---
name: result [6047,6053]
name: result [6047,6053]
===
match
---
trailer [4845,4850]
trailer [4845,4850]
===
match
---
operator: , [5620,5621]
operator: , [5620,5621]
===
match
---
name: executor_config [17667,17682]
name: executor_config [17667,17682]
===
match
---
string: 'celery' [2491,2499]
string: 'celery' [2491,2499]
===
match
---
suite [19392,19447]
suite [19392,19447]
===
match
---
name: Mapping [22390,22397]
name: Mapping [22409,22416]
===
match
---
dotted_name [6171,6200]
dotted_name [6171,6200]
===
match
---
trailer [3551,3553]
trailer [3551,3553]
===
match
---
name: bulk_state_fetcher [19488,19506]
name: bulk_state_fetcher [19488,19506]
===
match
---
atom_expr [10926,10960]
atom_expr [10926,10960]
===
match
---
operator: , [16488,16489]
operator: , [16488,16489]
===
match
---
atom_expr [21447,21465]
atom_expr [21453,21471]
===
match
---
arglist [20195,20214]
arglist [20201,20220]
===
match
---
simple_stmt [1228,1285]
simple_stmt [1228,1285]
===
match
---
trailer [10835,10840]
trailer [10835,10840]
===
match
---
atom_expr [15859,15874]
atom_expr [15859,15874]
===
match
---
name: get_parser [3762,3772]
name: get_parser [3762,3772]
===
match
---
simple_stmt [15982,16021]
simple_stmt [15982,16021]
===
match
---
name: self [22366,22370]
name: self [22385,22389]
===
match
---
name: celery_tasks [19794,19806]
name: celery_tasks [19800,19812]
===
match
---
atom_expr [9549,9579]
atom_expr [9549,9579]
===
match
---
atom_expr [16740,16761]
atom_expr [16740,16761]
===
match
---
argument [2853,2887]
argument [2853,2887]
===
match
---
atom_expr [4460,4551]
atom_expr [4460,4551]
===
match
---
expr_stmt [12399,12469]
expr_stmt [12399,12469]
===
match
---
operator: , [15580,15581]
operator: , [15580,15581]
===
match
---
name: Pool [1122,1126]
name: Pool [1122,1126]
===
match
---
name: self [16381,16385]
name: self [16381,16385]
===
match
---
atom_expr [15135,15147]
atom_expr [15135,15147]
===
match
---
trailer [16341,16354]
trailer [16341,16354]
===
match
---
name: log [4656,4659]
name: log [4656,4659]
===
match
---
operator: , [25270,25271]
operator: , [25272,25273]
===
match
---
name: add [20148,20151]
name: add [20154,20157]
===
match
---
trailer [25584,25818]
trailer [25586,25820]
===
match
---
operator: , [25255,25256]
operator: , [25257,25258]
===
match
---
trailer [3733,3741]
trailer [3733,3741]
===
match
---
name: running [20140,20147]
name: running [20146,20153]
===
match
---
atom_expr [8833,8888]
atom_expr [8833,8888]
===
match
---
operator: , [24628,24629]
operator: , [24630,24631]
===
match
---
simple_stmt [13517,13857]
simple_stmt [13517,13857]
===
match
---
arith_expr [20039,20082]
arith_expr [20045,20088]
===
match
---
operator: , [11942,11943]
operator: , [11942,11943]
===
match
---
trailer [2818,2822]
trailer [2818,2822]
===
match
---
trailer [5271,5281]
trailer [5271,5281]
===
match
---
name: task_results_by_task_id [23997,24020]
name: task_results_by_task_id [23999,24022]
===
match
---
name: args [4020,4024]
name: args [4020,4024]
===
match
---
trailer [10069,10075]
trailer [10069,10075]
===
match
---
trailer [15354,15365]
trailer [15354,15365]
===
match
---
trailer [9467,9479]
trailer [9467,9479]
===
match
---
arglist [12772,12801]
arglist [12772,12801]
===
match
---
trailer [11050,11203]
trailer [11050,11203]
===
match
---
name: task_results_by_task_id [24463,24486]
name: task_results_by_task_id [24465,24488]
===
match
---
name: Task [1255,1259]
name: Task [1255,1259]
===
match
---
trailer [23279,23293]
trailer [23276,23290]
===
match
---
name: celery_tasks [19219,19231]
name: celery_tasks [19219,19231]
===
match
---
trailer [16207,16225]
trailer [16207,16225]
===
match
---
name: queue [9405,9410]
name: queue [9405,9410]
===
match
---
operator: , [20445,20446]
operator: , [20451,20452]
===
match
---
suite [6990,20525]
suite [6990,20531]
===
match
---
operator: = [25076,25077]
operator: = [25078,25079]
===
match
---
name: str [20591,20594]
name: str [20597,20600]
===
match
---
trailer [20031,20035]
trailer [20037,20041]
===
match
---
trailer [12937,12989]
trailer [12937,12989]
===
match
---
name: task_tuples_to_send [10032,10051]
name: task_tuples_to_send [10032,10051]
===
match
---
name: task_result [24449,24460]
name: task_result [24451,24462]
===
match
---
while_stmt [17385,17504]
while_stmt [17385,17504]
===
match
---
name: states [1261,1267]
name: states [1261,1267]
===
match
---
atom_expr [4730,4749]
atom_expr [4730,4749]
===
match
---
not_test [24605,24637]
not_test [24607,24639]
===
match
---
simple_stmt [1001,1011]
simple_stmt [1001,1011]
===
match
---
name: timeout [5789,5796]
name: timeout [5789,5796]
===
match
---
import_from [1827,1918]
import_from [1827,1918]
===
match
---
name: chunksize [25066,25075]
name: chunksize [25068,25077]
===
match
---
operator: = [5986,5987]
operator: = [5986,5987]
===
match
---
arglist [15655,15695]
arglist [15655,15695]
===
match
---
name: TaskDb [23763,23769]
name: TaskDb [23765,23771]
===
match
---
string: "status" [24564,24572]
string: "status" [24566,24574]
===
match
---
atom_expr [21152,21186]
atom_expr [21158,21192]
===
match
---
trailer [4391,4393]
trailer [4391,4393]
===
match
---
name: change_state [16253,16265]
name: change_state [16253,16265]
===
match
---
name: bash [6735,6739]
name: bash [6735,6739]
===
match
---
trailer [19653,19676]
trailer [19659,19682]
===
match
---
name: key [15186,15189]
name: key [15186,15189]
===
match
---
operator: = [23351,23352]
operator: = [23348,23349]
===
match
---
trailer [20368,20492]
trailer [20374,20498]
===
match
---
operator: , [2520,2521]
operator: , [2520,2521]
===
match
---
name: stalled_after [13993,14006]
name: stalled_after [13993,14006]
===
match
---
param [17930,17953]
param [17930,17953]
===
match
---
simple_stmt [3043,3104]
simple_stmt [3043,3104]
===
match
---
testlist_comp [15135,15153]
testlist_comp [15135,15153]
===
match
---
name: ExceptionWithTraceback [5654,5676]
name: ExceptionWithTraceback [5654,5676]
===
match
---
simple_stmt [6108,6136]
simple_stmt [6108,6136]
===
match
---
name: key [10399,10402]
name: key [10399,10402]
===
match
---
name: ti [19789,19791]
name: ti [19795,19797]
===
match
---
operator: = [5874,5875]
operator: = [5874,5875]
===
match
---
operator: = [19607,19608]
operator: = [19613,19614]
===
match
---
for_stmt [15067,15243]
for_stmt [15067,15243]
===
match
---
atom [23152,23203]
atom [23149,23200]
===
match
---
name: Stats [10476,10481]
name: Stats [10476,10481]
===
match
---
name: signal [12880,12886]
name: signal [12880,12886]
===
match
---
name: tasks [23982,23987]
name: tasks [23984,23989]
===
match
---
name: result [19835,19841]
name: result [19841,19847]
===
match
---
name: task_publish_max_retries [10713,10737]
name: task_publish_max_retries [10713,10737]
===
match
---
trailer [9346,9350]
trailer [9346,9350]
===
match
---
simple_stmt [9929,9972]
simple_stmt [9929,9972]
===
match
---
name: info [20210,20214]
name: info [20216,20220]
===
match
---
name: get [2819,2822]
name: get [2819,2822]
===
match
---
operator: , [19724,19725]
operator: , [19730,19731]
===
match
---
simple_stmt [4730,4750]
simple_stmt [4730,4750]
===
match
---
fstring_end: " [6037,6038]
fstring_end: " [6037,6038]
===
match
---
operator: -> [3312,3314]
operator: -> [3312,3314]
===
match
---
name: adopted [20228,20235]
name: adopted [20234,20241]
===
match
---
name: bool [17326,17330]
name: bool [17326,17330]
===
match
---
name: append [19352,19358]
name: append [19352,19358]
===
match
---
name: celery_tasks [19080,19092]
name: celery_tasks [19080,19092]
===
match
---
atom_expr [11412,11427]
atom_expr [11412,11427]
===
match
---
operator: = [4038,4039]
operator: = [4038,4039]
===
match
---
trailer [12497,12547]
trailer [12497,12547]
===
match
---
dotted_name [6652,6679]
dotted_name [6652,6679]
===
match
---
expr_stmt [23997,24092]
expr_stmt [23999,24094]
===
match
---
suite [20289,20493]
suite [20295,20499]
===
match
---
suite [17348,17524]
suite [17348,17524]
===
match
---
trailer [15962,15969]
trailer [15962,15969]
===
match
---
atom_expr [13338,13367]
atom_expr [13338,13367]
===
match
---
operator: , [9299,9300]
operator: , [9299,9300]
===
match
---
trailer [19841,19849]
trailer [19847,19855]
===
match
---
testlist_star_expr [24789,24800]
testlist_star_expr [24791,24802]
===
match
---
testlist_comp [23268,23317]
testlist_comp [23265,23314]
===
match
---
name: kubernetes [6851,6861]
name: kubernetes [6851,6861]
===
match
---
name: Exception [5186,5195]
name: Exception [5186,5195]
===
match
---
atom_expr [17391,17472]
atom_expr [17391,17472]
===
match
---
subscript [3888,3890]
subscript [3888,3890]
===
match
---
name: self [16266,16270]
name: self [16266,16270]
===
match
---
simple_stmt [3679,3710]
simple_stmt [3679,3710]
===
match
---
atom_expr [11731,11753]
atom_expr [11731,11753]
===
match
---
trailer [9725,9747]
trailer [9725,9747]
===
match
---
name: bulk_state_fetcher [7836,7854]
name: bulk_state_fetcher [7836,7854]
===
match
---
operator: = [23828,23829]
operator: = [23830,23831]
===
match
---
operator: , [20459,20460]
operator: , [20465,20466]
===
match
---
trailer [23580,23607]
trailer [23577,23604]
===
match
---
strings [14811,14932]
strings [14811,14932]
===
match
---
atom_expr [22673,22713]
atom_expr [22668,22708]
===
match
---
suite [8945,9670]
suite [8945,9670]
===
match
---
classdef [21813,25966]
classdef [21719,25968]
===
match
---
name: state [19719,19724]
name: state [19725,19730]
===
match
---
name: TaskInstance [17940,17952]
name: TaskInstance [17940,17952]
===
match
---
name: task_publish_retries [10931,10951]
name: task_publish_retries [10931,10951]
===
match
---
expr_stmt [15884,15972]
expr_stmt [15884,15972]
===
match
---
parameters [8441,8447]
parameters [8441,8447]
===
match
---
string: "\n\t" [15449,15455]
string: "\n\t" [15449,15455]
===
match
---
name: parse_args [3861,3871]
name: parse_args [3861,3871]
===
match
---
expr_stmt [3599,3606]
expr_stmt [3599,3606]
===
match
---
atom_expr [3486,3554]
atom_expr [3486,3554]
===
match
---
name: isinstance [10164,10174]
name: isinstance [10164,10174]
===
match
---
expr_stmt [24345,24403]
expr_stmt [24347,24405]
===
match
---
name: ext [6591,6594]
name: ext [6591,6594]
===
match
---
suite [15277,15709]
suite [15277,15709]
===
match
---
name: info [16099,16103]
name: info [16099,16103]
===
match
---
operator: { [21579,21580]
operator: { [21585,21586]
===
match
---
trailer [3741,3743]
trailer [3741,3743]
===
match
---
param [6230,6236]
param [6230,6236]
===
match
---
atom_expr [20228,20268]
atom_expr [20234,20274]
===
match
---
operator: , [1883,1884]
operator: , [1883,1884]
===
match
---
subscriptlist [23581,23606]
subscriptlist [23578,23603]
===
match
---
subscriptlist [24900,24925]
subscriptlist [24902,24927]
===
match
---
name: task_result [24552,24563]
name: task_result [24554,24565]
===
match
---
trailer [10712,10737]
trailer [10712,10737]
===
match
---
name: parser [3753,3759]
name: parser [3753,3759]
===
match
---
operator: , [24312,24313]
operator: , [24314,24315]
===
match
---
operator: -> [17340,17342]
operator: -> [17340,17342]
===
match
---
expr_stmt [3753,3774]
expr_stmt [3753,3774]
===
match
---
trailer [4659,4669]
trailer [4659,4669]
===
match
---
operator: = [2475,2476]
operator: = [2475,2476]
===
match
---
name: task_results_by_task_id [23491,23514]
name: task_results_by_task_id [23488,23511]
===
match
---
fstring_string: Celery Task ID:  [5990,6006]
fstring_string: Celery Task ID:  [5990,6006]
===
match
---
name: e [6079,6080]
name: e [6079,6080]
===
match
---
simple_stmt [15347,15368]
simple_stmt [15347,15368]
===
match
---
atom_expr [7874,7896]
atom_expr [7874,7896]
===
match
---
simple_stmt [11220,11266]
simple_stmt [11220,11266]
===
match
---
name: settings [1625,1633]
name: settings [1625,1633]
===
match
---
expr_stmt [13889,13907]
expr_stmt [13889,13907]
===
match
---
trailer [23164,23181]
trailer [23161,23178]
===
match
---
trailer [15000,15005]
trailer [15000,15005]
===
match
---
trailer [24777,24786]
trailer [24779,24788]
===
match
---
name: MutableMapping [24357,24371]
name: MutableMapping [24359,24373]
===
match
---
suite [13241,13330]
suite [13241,13330]
===
match
---
trailer [16058,16078]
trailer [16058,16078]
===
match
---
fstring [21561,21620]
fstring [21567,21626]
===
match
---
name: datetime [8064,8072]
name: datetime [8064,8072]
===
match
---
string: """     Fetch and return the state of the given celery task. The scope of this function is     global so that it can be called by subprocesses in the pool.      :param async_result: a tuple of the Celery task key and the async Celery object used         to fetch the task's state     :type async_result: tuple(str, celery.result.AsyncResult)     :return: a tuple of the Celery task key and the Celery state and the celery info         of the task     :rtype: tuple[str, str, str]     """ [20642,21129]
string: """     Fetch and return the state of the given celery task. The scope of this function is     global so that it can be called by subprocesses in the pool.      :param async_result: a tuple of the Celery task key and the async Celery object used         to fetch the task's state     :type async_result: tuple(str, celery.result.AsyncResult)     :return: a tuple of the Celery task key and the Celery state and the celery info         of the task     :rtype: tuple[str, str, str]     """ [20648,21135]
===
match
---
name: utils [2192,2197]
name: utils [2192,2197]
===
match
---
trailer [14734,14739]
trailer [14734,14739]
===
match
---
trailer [21780,21788]
trailer [22336,22344]
===
match
---
trailer [22893,22899]
trailer [22880,22886]
===
match
---
name: os [3412,3414]
name: os [3412,3414]
===
match
---
trailer [17105,17148]
trailer [17105,17148]
===
match
---
param [5169,5174]
param [5169,5174]
===
match
---
expr_stmt [9103,9155]
expr_stmt [9103,9155]
===
match
---
name: key [16679,16682]
name: key [16679,16682]
===
match
---
name: command_to_exec [3087,3102]
name: command_to_exec [3087,3102]
===
match
---
annassign [8040,8098]
annassign [8040,8098]
===
match
---
atom_expr [5450,5526]
atom_expr [5450,5526]
===
match
---
name: session [23830,23837]
name: session [23832,23839]
===
match
---
parameters [23550,23569]
parameters [23547,23566]
===
match
---
name: self [17092,17096]
name: self [17092,17096]
===
match
---
name: TaskInstanceKey [8287,8302]
name: TaskInstanceKey [8287,8302]
===
match
---
name: task_tuple [5756,5766]
name: task_tuple [5756,5766]
===
match
---
name: key_and_async_results [10126,10147]
name: key_and_async_results [10126,10147]
===
match
---
operator: , [1172,1173]
operator: , [1172,1173]
===
match
---
argument [4501,4525]
argument [4501,4525]
===
match
---
name: queue [17630,17635]
name: queue [17630,17635]
===
match
---
atom_expr [12213,12266]
atom_expr [12213,12266]
===
match
---
name: State [2173,2178]
name: State [2173,2178]
===
match
---
name: task_cls [23844,23852]
name: task_cls [23846,23854]
===
match
---
trailer [12528,12546]
trailer [12528,12546]
===
match
---
funcdef [24832,25966]
funcdef [24834,25968]
===
match
---
trailer [16730,16738]
trailer [16730,16738]
===
match
---
return_stmt [24809,24826]
return_stmt [24811,24828]
===
match
---
atom_expr [12218,12265]
atom_expr [12218,12265]
===
match
---
expr_stmt [9766,9818]
expr_stmt [9766,9818]
===
match
---
suite [5824,5899]
suite [5824,5899]
===
match
---
name: __init__ [7355,7363]
name: __init__ [7355,7363]
===
match
---
funcdef [12557,12919]
funcdef [12557,12919]
===
match
---
operator: , [21704,21705]
operator: , [21710,21711]
===
match
---
atom_expr [15510,15708]
atom_expr [15510,15708]
===
match
---
funcdef [13191,13460]
funcdef [13191,13460]
===
match
---
name: processes [25017,25026]
name: processes [25019,25028]
===
match
---
name: to_dict [23959,23966]
name: to_dict [23961,23968]
===
match
---
expr_stmt [2755,2799]
expr_stmt [2755,2799]
===
match
---
simple_stmt [11731,11787]
simple_stmt [11731,11787]
===
match
---
atom_expr [21757,21765]
atom_expr [22309,22317]
===
match
---
fstring_expr [20245,20249]
fstring_expr [20251,20255]
===
match
---
funcdef [3261,4298]
funcdef [3261,4298]
===
match
---
name: utils [2234,2239]
name: utils [2234,2239]
===
match
---
param [16272,16293]
param [16272,16293]
===
match
---
if_stmt [14749,15243]
if_stmt [14749,15243]
===
match
---
argument [5870,5884]
argument [5870,5884]
===
match
---
import_as_names [1122,1137]
import_as_names [1122,1137]
===
match
---
except_clause [21476,21497]
except_clause [21482,21503]
===
match
---
trailer [3051,3103]
trailer [3051,3103]
===
match
---
suite [17036,17058]
suite [17036,17058]
===
match
---
name: SimpleTaskInstance [1959,1977]
name: SimpleTaskInstance [1959,1977]
===
match
---
simple_stmt [12758,12803]
simple_stmt [12758,12803]
===
match
---
name: self [16666,16670]
name: self [16666,16670]
===
match
---
arglist [23481,23514]
arglist [23478,23511]
===
match
---
name: task_tuples_to_send [13094,13113]
name: task_tuples_to_send [13094,13113]
===
match
---
suite [24927,25966]
suite [24929,25968]
===
match
---
trailer [11422,11427]
trailer [11422,11427]
===
match
---
simple_stmt [4656,4722]
simple_stmt [4656,4722]
===
match
---
name: self [12090,12094]
name: self [12090,12094]
===
match
---
arglist [25505,25547]
arglist [25507,25549]
===
match
---
name: _get_many_using_multiprocessing [22830,22861]
name: _get_many_using_multiprocessing [22817,22848]
===
match
---
name: str [16519,16522]
name: str [16519,16522]
===
match
---
name: info [21338,21342]
name: info [21344,21348]
===
match
---
simple_stmt [14714,14740]
simple_stmt [14714,14740]
===
match
---
suite [2750,2800]
suite [2750,2800]
===
match
---
atom_expr [22529,22540]
atom_expr [22548,22559]
===
match
---
expr_stmt [23212,23243]
expr_stmt [23209,23240]
===
match
---
arglist [16679,16688]
arglist [16679,16688]
===
match
---
atom_expr [12524,12546]
atom_expr [12524,12546]
===
match
---
name: _sync_parallelism [12529,12546]
name: _sync_parallelism [12529,12546]
===
match
---
simple_stmt [2098,2141]
simple_stmt [2098,2141]
===
match
---
name: info [19726,19730]
name: info [19732,19736]
===
match
---
name: settings [3679,3687]
name: settings [3679,3687]
===
match
---
operator: = [3760,3761]
operator: = [3760,3761]
===
match
---
trailer [15460,15491]
trailer [15460,15491]
===
match
---
atom_expr [21658,21704]
atom_expr [21664,21710]
===
match
---
atom_expr [16381,16406]
atom_expr [16381,16406]
===
match
---
name: ret [4034,4037]
name: ret [4034,4037]
===
match
---
name: backends [1355,1363]
name: backends [1355,1363]
===
match
---
trailer [15011,15014]
trailer [15011,15014]
===
match
---
trailer [16391,16395]
trailer [16391,16395]
===
match
---
name: Mapping [23573,23580]
name: Mapping [23570,23577]
===
match
---
name: str [5218,5221]
name: str [5218,5221]
===
match
---
name: self [15471,15475]
name: self [15471,15475]
===
match
---
name: exception [4660,4669]
name: exception [4660,4669]
===
match
---
not_test [13226,13240]
not_test [13226,13240]
===
match
---
name: AsyncResult [20569,20580]
name: AsyncResult [20575,20586]
===
match
---
simple_stmt [10926,10961]
simple_stmt [10926,10961]
===
match
---
trailer [12060,12081]
trailer [12060,12081]
===
match
---
atom_expr [17935,17953]
atom_expr [17935,17953]
===
match
---
atom_expr [20172,20215]
atom_expr [20178,20221]
===
match
---
funcdef [8432,8563]
funcdef [8432,8563]
===
match
---
name: tis [19443,19446]
name: tis [19443,19446]
===
match
---
name: _sync_parallelism [12095,12112]
name: _sync_parallelism [12095,12112]
===
match
---
trailer [2490,2535]
trailer [2490,2535]
===
match
---
trailer [16789,16800]
trailer [16789,16800]
===
match
---
operator: = [4173,4174]
operator: = [4173,4174]
===
match
---
arglist [4123,4159]
arglist [4123,4159]
===
match
---
fstring_start: f" [20243,20245]
fstring_start: f" [20249,20251]
===
match
---
name: x [15012,15013]
name: x [15012,15013]
===
match
---
name: env [4547,4550]
name: env [4547,4550]
===
match
---
param [17570,17591]
param [17570,17591]
===
match
---
atom_expr [23045,23079]
atom_expr [23037,23071]
===
match
---
operator: , [2831,2832]
operator: , [2831,2832]
===
match
---
name: state_or_exception [25767,25785]
name: state_or_exception [25769,25787]
===
match
---
name: fallback [8223,8231]
name: fallback [8223,8231]
===
match
---
atom_expr [3872,3891]
atom_expr [3872,3891]
===
match
---
name: task_tuples_to_send [9700,9719]
name: task_tuples_to_send [9700,9719]
===
match
---
name: flush [4205,4210]
name: flush [4205,4210]
===
match
---
string: 'celery' [8188,8196]
string: 'celery' [8188,8196]
===
match
---
trailer [17462,17469]
trailer [17462,17469]
===
match
---
trailer [8832,8889]
trailer [8832,8889]
===
match
---
name: _process_tasks [9634,9648]
name: _process_tasks [9634,9648]
===
match
---
trailer [11251,11258]
trailer [11251,11258]
===
match
---
expr_stmt [20302,20342]
expr_stmt [20308,20348]
===
match
---
operator: -> [16535,16537]
operator: -> [16535,16537]
===
match
---
name: _get_many_from_db_backend [22741,22766]
name: _get_many_from_db_backend [22736,22761]
===
match
---
string: 'Sent all tasks.' [10076,10093]
string: 'Sent all tasks.' [10076,10093]
===
match
---
trailer [4210,4212]
trailer [4210,4212]
===
match
---
name: self [11374,11378]
name: self [11374,11378]
===
match
---
atom_expr [2270,2297]
atom_expr [2270,2297]
===
match
---
operator: , [15697,15698]
operator: , [15697,15698]
===
match
---
operator: = [24748,24749]
operator: = [24750,24751]
===
match
---
subscriptlist [5605,5677]
subscriptlist [5605,5677]
===
match
---
trailer [8543,8561]
trailer [8543,8561]
===
match
---
name: database [1364,1372]
name: database [1364,1372]
===
match
---
operator: = [12974,12975]
operator: = [12974,12975]
===
match
---
name: Set [1209,1212]
name: Set [1209,1212]
===
match
---
name: self [10061,10065]
name: self [10061,10065]
===
match
---
trailer [17426,17439]
trailer [17426,17439]
===
match
---
atom_expr [4153,4159]
atom_expr [4153,4159]
===
match
---
if_stmt [9492,9584]
if_stmt [9492,9584]
===
match
---
suite [5223,5304]
suite [5223,5304]
===
match
---
simple_stmt [7774,7823]
simple_stmt [7774,7823]
===
match
---
arglist [16355,16371]
arglist [16355,16371]
===
match
---
name: self [15211,15215]
name: self [15211,15215]
===
match
---
name: BulkStateFetcher [7857,7873]
name: BulkStateFetcher [7857,7873]
===
match
---
operator: , [9394,9395]
operator: , [9394,9395]
===
match
---
atom_expr [20152,20158]
atom_expr [20158,20164]
===
match
---
expr_stmt [2333,2397]
expr_stmt [2333,2397]
===
match
---
operator: , [5195,5196]
operator: , [5195,5196]
===
match
---
annassign [25345,25393]
annassign [25347,25395]
===
match
---
parameters [13501,13507]
parameters [13501,13507]
===
match
---
name: PENDING [17028,17035]
name: PENDING [17028,17035]
===
match
---
trailer [12851,12859]
trailer [12851,12859]
===
match
---
operator: , [5733,5734]
operator: , [5733,5734]
===
match
---
trailer [21159,21186]
trailer [21165,21192]
===
match
---
trailer [7778,7796]
trailer [7778,7796]
===
match
---
string: "executor.tasks (%d)\n\t%s" [15403,15430]
string: "executor.tasks (%d)\n\t%s" [15403,15430]
===
match
---
name: List [1168,1172]
name: List [1168,1172]
===
match
---
atom [13905,13907]
atom [13905,13907]
===
match
---
atom_expr [12057,12081]
atom_expr [12057,12081]
===
match
---
number: 1 [3888,3889]
number: 1 [3888,3889]
===
match
---
name: celery_import_modules [6171,6192]
name: celery_import_modules [6171,6192]
===
match
---
atom_expr [24974,24996]
atom_expr [24976,24998]
===
match
---
fstring_string: \n [6011,6013]
fstring_string: \n [6011,6013]
===
match
---
name: adopted_task_timeouts [8019,8040]
name: adopted_task_timeouts [8019,8040]
===
match
---
suite [21850,25966]
suite [21756,25968]
===
match
---
name: utils [2111,2116]
name: utils [2111,2116]
===
match
---
operator: , [16358,16359]
operator: , [16358,16359]
===
match
---
dotted_name [2184,2205]
dotted_name [2184,2205]
===
match
---
operator: = [21343,21344]
operator: = [21349,21350]
===
match
---
name: models [1932,1938]
name: models [1932,1938]
===
match
---
trailer [16142,16164]
trailer [16142,16164]
===
match
---
trailer [10540,10544]
trailer [10540,10544]
===
match
---
name: validate_command [3005,3021]
name: validate_command [3005,3021]
===
match
---
dotted_as_name [1617,1645]
dotted_as_name [1617,1645]
===
match
---
name: isinstance [22673,22683]
name: isinstance [22668,22678]
===
match
---
trailer [3046,3051]
trailer [3046,3051]
===
match
---
name: key_and_async_results [13164,13185]
name: key_and_async_results [13164,13185]
===
match
---
operator: , [5721,5722]
operator: , [5721,5722]
===
match
---
atom [9301,9331]
atom [9301,9331]
===
match
---
name: _sync_parallelism [7879,7896]
name: _sync_parallelism [7879,7896]
===
match
---
operator: -> [15747,15749]
operator: -> [15747,15749]
===
match
---
name: task_tuples_to_send [9596,9615]
name: task_tuples_to_send [9596,9615]
===
match
---
name: SIG_DFL [12852,12859]
name: SIG_DFL [12852,12859]
===
match
---
arglist [7692,7720]
arglist [7692,7720]
===
match
---
name: e [4740,4741]
name: e [4740,4741]
===
match
---
operator: , [5504,5505]
operator: , [5504,5505]
===
match
---
trailer [15654,15696]
trailer [15654,15696]
===
match
---
name: task [17395,17399]
name: task [17395,17399]
===
match
---
arglist [3052,3102]
arglist [3052,3102]
===
match
---
trailer [11224,11237]
trailer [11224,11237]
===
match
---
name: TaskInstanceKey [16495,16510]
name: TaskInstanceKey [16495,16510]
===
match
---
name: len [20447,20450]
name: len [20453,20456]
===
match
---
name: self [17556,17560]
name: self [17556,17560]
===
match
---
name: timeout [2213,2220]
name: timeout [2213,2220]
===
match
---
atom_expr [5635,5677]
atom_expr [5635,5677]
===
match
---
operator: , [9403,9404]
operator: , [9403,9404]
===
match
---
argument [12938,12961]
argument [12938,12961]
===
match
---
import_as_names [1380,1428]
import_as_names [1380,1428]
===
match
---
operator: = [7855,7856]
operator: = [7855,7856]
===
match
---
operator: = [8363,8364]
operator: = [8363,8364]
===
match
---
atom_expr [23738,23749]
atom_expr [23740,23751]
===
match
---
funcdef [17856,17890]
funcdef [17856,17890]
===
match
---
name: cpu_count [1128,1137]
name: cpu_count [1128,1137]
===
match
---
name: ti [19359,19361]
name: ti [19359,19361]
===
match
---
name: task_id [21649,21656]
name: task_id [21655,21662]
===
match
---
simple_stmt [16092,16165]
simple_stmt [16092,16165]
===
match
---
name: pid [3348,3351]
name: pid [3348,3351]
===
match
---
atom [19259,19301]
atom [19259,19301]
===
match
---
name: self [13230,13234]
name: self [13230,13234]
===
match
---
name: conf [8365,8369]
name: conf [8365,8369]
===
match
---
simple_stmt [10810,10846]
simple_stmt [10810,10846]
===
match
---
atom_expr [15952,15971]
atom_expr [15952,15971]
===
match
---
trailer [11157,11167]
trailer [11157,11167]
===
match
---
simple_stmt [19080,19098]
simple_stmt [19080,19098]
===
match
---
name: self [8539,8543]
name: self [8539,8543]
===
match
---
arglist [7803,7821]
arglist [7803,7821]
===
match
---
name: get [10395,10398]
name: get [10395,10398]
===
match
---
expr_stmt [19080,19097]
expr_stmt [19080,19097]
===
match
---
name: e [4157,4158]
name: e [4157,4158]
===
match
---
name: ti [20152,20154]
name: ti [20158,20160]
===
match
---
trailer [11378,11386]
trailer [11378,11386]
===
match
---
trailer [15990,15996]
trailer [15990,15996]
===
match
---
name: max [25078,25081]
name: max [25080,25083]
===
match
---
operator: , [6235,6236]
operator: , [6235,6236]
===
match
---
name: task_ids [23882,23890]
name: task_ids [23884,23892]
===
match
---
param [11996,12043]
param [11996,12043]
===
match
---
string: """     Preload some "expensive" airflow modules so that every task process doesn't have to import it again and     again.      Loading these for each task adds 0.3-0.5s *per task* before the task can run. For long running tasks this     doesn't matter, but for short tasks this starts to be a noticeable impact.     """ [6252,6572]
string: """     Preload some "expensive" airflow modules so that every task process doesn't have to import it again and     again.      Loading these for each task adds 0.3-0.5s *per task* before the task can run. For long running tasks this     doesn't matter, but for short tasks this starts to be a noticeable impact.     """ [6252,6572]
===
match
---
operator: + [3537,3538]
operator: + [3537,3538]
===
match
---
operator: , [8221,8222]
operator: , [8221,8222]
===
match
---
name: self [17512,17516]
name: self [17512,17516]
===
match
---
name: TaskInstanceKey [17575,17590]
name: TaskInstanceKey [17575,17590]
===
match
---
trailer [3687,3694]
trailer [3687,3694]
===
match
---
operator: } [6010,6011]
operator: } [6010,6011]
===
match
---
name: num_processes [12948,12961]
name: num_processes [12948,12961]
===
match
---
name: AirflowException [17791,17807]
name: AirflowException [17791,17807]
===
match
---
simple_stmt [9981,10053]
simple_stmt [9981,10053]
===
match
---
import_from [2009,2040]
import_from [2009,2040]
===
match
---
name: task_ids [23089,23097]
name: task_ids [23081,23089]
===
match
---
name: exceptions [1772,1782]
name: exceptions [1772,1782]
===
match
---
name: task_tuple [5560,5570]
name: task_tuple [5560,5570]
===
match
---
name: session [23673,23680]
name: session [23675,23682]
===
match
---
operator: + [4798,4799]
operator: + [4798,4799]
===
match
---
param [17307,17312]
param [17307,17312]
===
match
---
atom [23923,23988]
atom [23925,23990]
===
match
---
name: command [6120,6127]
name: command [6120,6127]
===
match
---
param [16490,16511]
param [16490,16511]
===
match
---
trailer [8825,8890]
trailer [8825,8890]
===
match
---
simple_stmt [16334,16373]
simple_stmt [16334,16373]
===
match
---
atom_expr [10061,10094]
atom_expr [10061,10094]
===
match
---
suite [4882,5304]
suite [4882,5304]
===
match
---
name: debug_dump [15252,15262]
name: debug_dump [15252,15262]
===
match
---
name: error [14788,14793]
name: error [14788,14793]
===
match
---
trailer [2620,2631]
trailer [2620,2631]
===
match
---
trailer [3189,3206]
trailer [3189,3206]
===
match
---
suite [13508,15243]
suite [13508,15243]
===
match
---
atom_expr [15376,15501]
atom_expr [15376,15501]
===
match
---
operator: , [2851,2852]
operator: , [2851,2852]
===
match
---
atom_expr [25767,25795]
atom_expr [25769,25797]
===
match
---
name: self [10536,10540]
name: self [10536,10540]
===
match
---
trailer [10814,10835]
trailer [10814,10835]
===
match
---
name: query [23838,23843]
name: query [23840,23845]
===
match
---
operator: , [25795,25796]
operator: , [25797,25798]
===
match
---
operator: , [16682,16683]
operator: , [16682,16683]
===
match
---
name: _tasks_list_to_task_ids [21717,21740]
name: _tasks_list_to_task_ids [22263,22286]
===
match
---
trailer [10031,10052]
trailer [10031,10052]
===
match
---
atom_expr [24357,24398]
atom_expr [24359,24400]
===
match
---
name: sync_parallelism [22247,22263]
name: sync_parallelism [22153,22169]
===
match
---
suite [19150,19363]
suite [19150,19363]
===
match
---
name: self [9506,9510]
name: self [9506,9510]
===
match
---
trailer [25785,25795]
trailer [25787,25797]
===
match
---
atom_expr [23730,23770]
atom_expr [23732,23772]
===
match
---
suite [25053,25924]
suite [25055,25926]
===
match
---
param [17870,17874]
param [17870,17874]
===
match
---
atom_expr [19166,19189]
atom_expr [19166,19189]
===
match
---
fstring [3954,3999]
fstring [3954,3999]
===
match
---
name: self [24108,24112]
name: self [24110,24114]
===
match
---
name: len [24954,24957]
name: len [24956,24959]
===
match
---
name: external_executor_id [19275,19295]
name: external_executor_id [19275,19295]
===
match
---
operator: , [11994,11995]
operator: , [11994,11995]
===
match
---
trailer [10394,10398]
trailer [10394,10398]
===
match
---
fstring_expr [3981,3998]
fstring_expr [3981,3998]
===
match
---
name: Any [17693,17696]
name: Any [17693,17696]
===
match
---
string: "task_id" [24036,24045]
string: "task_id" [24038,24047]
===
match
---
name: self [11036,11040]
name: self [11036,11040]
===
match
---
name: ti [19272,19274]
name: ti [19272,19274]
===
match
---
atom_expr [15432,15447]
atom_expr [15432,15447]
===
match
---
if_stmt [12054,12267]
if_stmt [12054,12267]
===
match
---
trailer [16445,16456]
trailer [16445,16456]
===
match
---
name: _execute_in_subprocess [4304,4326]
name: _execute_in_subprocess [4304,4326]
===
match
---
with_stmt [12928,13149]
with_stmt [12928,13149]
===
match
---
param [15263,15267]
param [15263,15267]
===
match
---
trailer [5604,5678]
trailer [5604,5678]
===
match
---
name: self [22825,22829]
name: self [22812,22816]
===
match
---
operator: , [9698,9699]
operator: , [9698,9699]
===
match
---
name: self [11220,11224]
name: self [11220,11224]
===
match
---
name: Optional [17684,17692]
name: Optional [17684,17692]
===
match
---
simple_stmt [14779,15055]
simple_stmt [14779,15055]
===
match
---
suite [8633,8891]
suite [8633,8891]
===
match
---
trailer [19552,19555]
trailer [19557,19560]
===
match
---
number: 0 [19678,19679]
number: 0 [19684,19685]
===
match
---
if_stmt [13223,13330]
if_stmt [13223,13330]
===
match
---
import_from [2179,2220]
import_from [2179,2220]
===
match
---
name: self [15863,15867]
name: self [15863,15867]
===
match
---
name: logging [2270,2277]
name: logging [2270,2277]
===
match
---
name: _get_many_from_db_backend [23525,23550]
name: _get_many_from_db_backend [23522,23547]
===
match
---
simple_stmt [6844,6883]
simple_stmt [6844,6883]
===
match
---
funcdef [4300,4851]
funcdef [4300,4851]
===
match
---
simple_stmt [8642,8807]
simple_stmt [8642,8807]
===
match
---
simple_stmt [3167,3207]
simple_stmt [3167,3207]
===
match
---
name: task_publish_retries [10657,10677]
name: task_publish_retries [10657,10677]
===
match
---
name: task_publish_retries [10815,10835]
name: task_publish_retries [10815,10835]
===
match
---
name: result [11430,11436]
name: result [11430,11436]
===
match
---
name: state_or_exception [25505,25523]
name: state_or_exception [25507,25525]
===
match
---
operator: = [17698,17699]
operator: = [17698,17699]
===
match
---
import_name [12731,12744]
import_name [12731,12744]
===
match
---
name: exception [5249,5258]
name: exception [5249,5258]
===
match
---
atom_expr [7379,7397]
atom_expr [7379,7397]
===
match
---
name: self [10708,10712]
name: self [10708,10712]
===
match
---
suite [21138,21472]
suite [21144,21478]
===
match
---
name: state_and_info_by_celery_task_id [15884,15916]
name: state_and_info_by_celery_task_id [15884,15916]
===
match
---
name: num_processes [12478,12491]
name: num_processes [12478,12491]
===
match
---
name: TaskInstanceInCelery [12022,12042]
name: TaskInstanceInCelery [12022,12042]
===
match
---
name: exception [17233,17242]
name: exception [17233,17242]
===
match
---
simple_stmt [10061,10095]
simple_stmt [10061,10095]
===
match
---
operator: , [2499,2500]
operator: , [2499,2500]
===
match
---
name: signal [12787,12793]
name: signal [12787,12793]
===
match
---
operator: + [11135,11136]
operator: + [11135,11136]
===
match
---
name: key [11238,11241]
name: key [11238,11241]
===
match
---
expr_stmt [22581,22635]
expr_stmt [22600,22654]
===
match
---
name: command_to_exec [3872,3887]
name: command_to_exec [3872,3887]
===
match
---
simple_stmt [6613,6640]
simple_stmt [6613,6640]
===
match
---
name: app [23268,23271]
name: app [23265,23268]
===
match
---
atom_expr [19529,19579]
atom_expr [19534,19584]
===
match
---
string: """Updates state of a single task.""" [16552,16589]
string: """Updates state of a single task.""" [16552,16589]
===
match
---
simple_stmt [20002,20083]
simple_stmt [20008,20089]
===
match
---
trailer [10656,10677]
trailer [10656,10677]
===
match
---
simple_stmt [6577,6609]
simple_stmt [6577,6609]
===
match
---
name: not_adopted_tis [19336,19351]
name: not_adopted_tis [19336,19351]
===
match
---
name: ImportError [6894,6905]
name: ImportError [6894,6905]
===
match
---
name: Celery [1247,1253]
name: Celery [1247,1253]
===
match
---
atom_expr [20447,20459]
atom_expr [20453,20465]
===
match
---
expr_stmt [19456,19589]
expr_stmt [19456,19595]
===
match
---
tfpdef [17667,17697]
tfpdef [17667,17697]
===
match
---
name: success [16671,16678]
name: success [16671,16678]
===
match
---
arglist [21681,21703]
arglist [21687,21709]
===
match
---
import_name [1029,1040]
import_name [1029,1040]
===
match
---
simple_stmt [12873,12919]
simple_stmt [12873,12919]
===
match
---
name: DatabaseBackend [22697,22712]
name: DatabaseBackend [22692,22707]
===
match
---
operator: , [10114,10115]
operator: , [10114,10115]
===
match
---
return_stmt [19436,19446]
return_stmt [19436,19446]
===
match
---
trailer [23293,23296]
trailer [23290,23293]
===
match
---
atom_expr [2477,2535]
atom_expr [2477,2535]
===
match
---
name: _check_for_stalled_adopted_tasks [13469,13501]
name: _check_for_stalled_adopted_tasks [13469,13501]
===
match
---
name: result [19781,19787]
name: result [19787,19793]
===
match
---
atom_expr [21345,21362]
atom_expr [21351,21368]
===
match
---
name: ExceptionWithTraceback [21658,21680]
name: ExceptionWithTraceback [21664,21686]
===
match
---
operator: ** [6237,6239]
operator: ** [6237,6239]
===
match
---
operator: = [5282,5283]
operator: = [5282,5283]
===
match
---
name: state_or_exception [25899,25917]
name: state_or_exception [25901,25919]
===
match
---
name: utils [2154,2159]
name: utils [2154,2159]
===
match
---
suite [6247,6920]
suite [6247,6920]
===
match
---
import_from [3560,3593]
import_from [3560,3593]
===
match
---
name: task_publish_max_retries [8338,8362]
name: task_publish_max_retries [8338,8362]
===
match
---
suite [21187,21472]
suite [21193,21478]
===
match
---
funcdef [20527,21711]
funcdef [20533,21717]
===
match
---
operator: , [8302,8303]
operator: , [8302,8303]
===
match
---
name: TaskInstanceKey [16277,16292]
name: TaskInstanceKey [16277,16292]
===
match
---
atom_expr [17224,17293]
atom_expr [17224,17293]
===
match
---
parameters [5554,5595]
parameters [5554,5595]
===
match
---
name: args [3847,3851]
name: args [3847,3851]
===
match
---
fstring_start: f" [5988,5990]
fstring_start: f" [5988,5990]
===
match
---
operator: , [20201,20202]
operator: , [20207,20208]
===
match
---
operator: } [20265,20266]
operator: } [20271,20272]
===
match
---
except_clause [4605,4646]
except_clause [4605,4646]
===
match
---
testlist_comp [11246,11264]
testlist_comp [11246,11264]
===
match
---
name: str [22398,22401]
name: str [22417,22420]
===
match
---
name: str [20602,20605]
name: str [20608,20611]
===
match
---
fstring_string: airflow task supervisor:  [3956,3981]
fstring_string: airflow task supervisor:  [3956,3981]
===
match
---
simple_stmt [15376,15502]
simple_stmt [15376,15502]
===
match
---
atom_expr [12411,12469]
atom_expr [12411,12469]
===
match
---
name: info [24796,24800]
name: info [24798,24802]
===
match
---
operator: , [3426,3427]
operator: , [3426,3427]
===
match
---
name: key [10108,10111]
name: key [10108,10111]
===
match
---
import_as_name [1397,1411]
import_as_name [1397,1411]
===
match
---
del_stmt [15171,15190]
del_stmt [15171,15190]
===
match
---
param [8920,8935]
param [8920,8935]
===
match
---
name: signal [12738,12744]
name: signal [12738,12744]
===
match
---
expr_stmt [21539,21620]
expr_stmt [21545,21626]
===
match
---
name: celery [1290,1296]
name: celery [1290,1296]
===
match
---
comparison [16818,16848]
comparison [16818,16848]
===
match
---
name: BulkStateFetcher [21819,21835]
name: BulkStateFetcher [21725,21741]
===
match
---
operator: , [16229,16230]
operator: , [16229,16230]
===
match
---
operator: , [22245,22246]
operator: , [22151,22152]
===
match
---
atom_expr [20095,20113]
atom_expr [20101,20119]
===
match
---
atom_expr [9334,9353]
atom_expr [9334,9353]
===
match
---
name: state [2160,2165]
name: state [2160,2165]
===
match
---
operator: , [10181,10182]
operator: , [10181,10182]
===
match
---
name: map [15651,15654]
name: map [15651,15654]
===
match
---
name: celery_task_id [19702,19716]
name: celery_task_id [19708,19722]
===
match
---
name: Tuple [5599,5604]
name: Tuple [5599,5604]
===
match
---
operator: , [15447,15448]
operator: , [15447,15448]
===
match
---
name: info [10545,10549]
name: info [10545,10549]
===
match
---
name: backend [23687,23694]
name: backend [23689,23696]
===
match
---
name: fallback [8415,8423]
name: fallback [8415,8423]
===
match
---
operator: = [19481,19482]
operator: = [19481,19482]
===
match
---
expr_stmt [24767,24800]
expr_stmt [24769,24802]
===
match
---
del_stmt [15207,15242]
del_stmt [15207,15242]
===
match
---
name: adopted [20281,20288]
name: adopted [20287,20294]
===
match
---
name: async_tasks [23029,23040]
name: async_tasks [23021,23032]
===
match
---
param [23023,23028]
param [23015,23020]
===
match
---
atom_expr [13040,13148]
atom_expr [13040,13148]
===
match
---
simple_stmt [16415,16457]
simple_stmt [16415,16457]
===
match
---
operator: , [22944,22945]
operator: , [22936,22937]
===
match
---
argument [25272,25291]
argument [25274,25293]
===
match
---
atom_expr [22684,22695]
atom_expr [22679,22690]
===
match
---
trailer [22310,22328]
trailer [22216,22234]
===
match
---
operator: -> [16317,16319]
operator: -> [16317,16319]
===
match
---
atom_expr [24767,24786]
atom_expr [24769,24788]
===
match
---
return_stmt [13157,13185]
return_stmt [13157,13185]
===
match
---
name: signal [12815,12821]
name: signal [12815,12821]
===
match
---
testlist_comp [9302,9330]
testlist_comp [9302,9330]
===
match
---
atom_expr [20596,20630]
atom_expr [20602,20636]
===
match
---
param [16524,16533]
param [16524,16533]
===
match
---
name: self [19483,19487]
name: list [19529,19533]
===
match
---
arglist [16790,16799]
arglist [16790,16799]
===
match
---
operator: = [3329,3330]
operator: = [3329,3330]
===
match
---
if_stmt [20278,20493]
if_stmt [20284,20499]
===
match
---
name: List [9721,9725]
name: List [9721,9725]
===
match
---
name: operators [6725,6734]
name: operators [6725,6734]
===
match
---
except_clause [17157,17173]
except_clause [17157,17173]
===
match
---
name: conf [8176,8180]
name: conf [8176,8180]
===
match
---
simple_stmt [13323,13330]
simple_stmt [13323,13330]
===
match
---
trailer [2287,2297]
trailer [2287,2297]
===
match
---
operator: , [16980,16981]
operator: , [16980,16981]
===
match
---
name: min [9242,9245]
name: min [9242,9245]
===
match
---
trailer [16640,16648]
trailer [16640,16648]
===
match
---
name: kwargs [6239,6245]
name: kwargs [6239,6245]
===
match
---
name: BaseExecutor [2992,3004]
name: BaseExecutor [2992,3004]
===
match
---
name: signal [12765,12771]
name: signal [12765,12771]
===
match
---
fstring_expr [21579,21593]
fstring_expr [21585,21599]
===
match
---
atom_expr [25713,25741]
atom_expr [25715,25743]
===
match
---
trailer [21459,21465]
trailer [21465,21471]
===
match
---
trailer [20328,20333]
trailer [20334,20339]
===
match
---
sync_comp_for [23390,23421]
sync_comp_for [23387,23418]
===
match
---
simple_stmt [1610,1646]
simple_stmt [1610,1646]
===
match
---
suite [17876,17890]
suite [17876,17890]
===
match
---
operator: , [13923,13924]
operator: , [13923,13924]
===
match
---
name: multiprocessing [1099,1114]
name: multiprocessing [1099,1114]
===
match
---
operator: = [9332,9333]
operator: = [9332,9333]
===
match
---
param [21741,21752]
param [22293,22304]
===
match
---
trailer [4122,4160]
trailer [4122,4160]
===
match
---
operator: , [15469,15470]
operator: , [15469,15470]
===
match
---
with_item [12933,13002]
with_item [12933,13002]
===
match
---
arglist [10239,10275]
arglist [10239,10275]
===
match
---
atom_expr [10407,10436]
atom_expr [10407,10436]
===
match
---
trailer [11044,11050]
trailer [11044,11050]
===
match
---
name: async_results [22862,22875]
name: async_results [22849,22862]
===
match
---
string: "Error syncing the Celery executor, ignoring it." [17243,17292]
string: "Error syncing the Celery executor, ignoring it." [17243,17292]
===
match
---
name: Tuple [1214,1219]
name: Tuple [1214,1219]
===
match
---
simple_stmt [21338,21406]
simple_stmt [21344,21412]
===
match
---
atom_expr [15461,15490]
atom_expr [15461,15490]
===
match
---
atom_expr [22736,22781]
atom_expr [22731,22776]
===
match
---
arith_expr [25646,25687]
arith_expr [25648,25689]
===
match
---
name: Exception [21483,21492]
name: Exception [21489,21498]
===
match
---
name: state [16707,16712]
name: state [16707,16712]
===
match
---
trailer [3414,3422]
trailer [3414,3422]
===
match
---
name: key [15238,15241]
name: key [15238,15241]
===
match
---
name: str [24900,24903]
name: str [24902,24905]
===
match
---
name: ExceptionWithTraceback [20607,20629]
name: ExceptionWithTraceback [20613,20635]
===
match
---
name: DEFAULT_CELERY_CONFIG [1698,1719]
name: DEFAULT_CELERY_CONFIG [1698,1719]
===
match
---
name: _send_tasks_to_celery [11968,11989]
name: _send_tasks_to_celery [11968,11989]
===
match
---
name: _tasks_list_to_task_ids [23628,23651]
name: _tasks_list_to_task_ids [23630,23653]
===
match
---
name: self [5169,5173]
name: self [5169,5173]
===
match
---
operator: = [23265,23266]
operator: = [23262,23263]
===
match
---
name: str [16301,16304]
name: str [16301,16304]
===
match
---
atom_expr [3762,3774]
atom_expr [3762,3774]
===
match
---
name: chunksize [12399,12408]
name: chunksize [12399,12408]
===
match
---
atom_expr [11246,11258]
atom_expr [11246,11258]
===
match
---
atom_expr [16334,16372]
atom_expr [16334,16372]
===
match
---
name: session_cleanup [23784,23799]
name: session_cleanup [23786,23801]
===
match
---
name: cached_celery_backend [19620,19641]
name: cached_celery_backend [19626,19647]
===
match
---
expr_stmt [19106,19126]
expr_stmt [19106,19126]
===
match
---
operator: } [6036,6037]
operator: } [6036,6037]
===
match
---
simple_stmt [17092,17149]
simple_stmt [17092,17149]
===
match
---
name: self [7774,7778]
name: self [7774,7778]
===
match
---
operator: @ [6170,6171]
operator: @ [6170,6171]
===
match
---
trailer [5236,5246]
trailer [5236,5246]
===
match
---
name: debug [15991,15996]
name: debug [15991,15996]
===
match
---
name: task_result [24643,24654]
name: task_result [24645,24656]
===
match
---
name: task_id [25888,25895]
name: task_id [25890,25897]
===
match
---
trailer [20154,20158]
trailer [20160,20164]
===
match
---
operator: { [20259,20260]
operator: { [20265,20266]
===
match
---
number: 1 [10844,10845]
number: 1 [10844,10845]
===
match
---
operator: , [5652,5653]
operator: , [5652,5653]
===
match
---
operator: , [12961,12962]
operator: , [12961,12962]
===
match
---
simple_stmt [16780,16801]
simple_stmt [16780,16801]
===
match
---
comparison [13993,14012]
comparison [13993,14012]
===
match
---
suite [6835,6883]
suite [6835,6883]
===
match
---
simple_stmt [1646,1720]
simple_stmt [1646,1720]
===
match
---
atom_expr [24552,24573]
atom_expr [24554,24575]
===
match
---
trailer [22286,22295]
trailer [22192,22201]
===
match
---
name: async_results [22372,22385]
name: async_results [22391,22404]
===
match
---
name: backend [23928,23935]
name: backend [23930,23937]
===
match
---
fstring_expr [6013,6037]
fstring_expr [6013,6037]
===
match
---
operator: , [15625,15626]
operator: , [15625,15626]
===
match
---
name: default_celery [1676,1690]
name: default_celery [1676,1690]
===
match
---
name: TaskInstanceKey [5605,5620]
name: TaskInstanceKey [5605,5620]
===
match
---
trailer [4483,4551]
trailer [4483,4551]
===
match
---
name: queue [5892,5897]
name: queue [5892,5897]
===
match
---
atom_expr [15007,15014]
atom_expr [15007,15014]
===
match
---
suite [19319,19363]
suite [19319,19363]
===
match
---
trailer [9553,9574]
trailer [9553,9574]
===
match
---
name: str [23053,23056]
name: str [23045,23048]
===
match
---
simple_stmt [6047,6103]
simple_stmt [6047,6103]
===
match
---
name: self [13420,13424]
name: self [13420,13424]
===
match
---
name: utcnow [2256,2262]
name: utcnow [2256,2262]
===
match
---
simple_stmt [10866,10875]
simple_stmt [10866,10875]
===
match
---
operator: = [19792,19793]
operator: = [19798,19799]
===
match
---
atom_expr [21366,21395]
atom_expr [21372,21401]
===
match
---
trailer [11762,11769]
trailer [11762,11769]
===
match
---
trailer [5455,5526]
trailer [5455,5526]
===
match
---
name: Pool [25012,25016]
name: Pool [25014,25018]
===
match
---
name: OPERATION_TIMEOUT [5805,5822]
name: OPERATION_TIMEOUT [5805,5822]
===
match
---
name: STARTED [16841,16848]
name: STARTED [16841,16848]
===
match
---
trailer [5869,5898]
trailer [5869,5898]
===
match
---
suite [23080,23516]
suite [23072,23513]
===
match
---
name: async_results [22767,22780]
name: async_results [22762,22775]
===
match
---
name: info [20364,20368]
name: info [20370,20374]
===
match
---
import_from [2098,2140]
import_from [2098,2140]
===
match
---
arglist [9246,9280]
arglist [9246,9280]
===
match
---
argument [5797,5822]
argument [5797,5822]
===
match
---
name: getLogger [2278,2287]
name: getLogger [2278,2287]
===
match
---
trailer [17399,17405]
trailer [17399,17405]
===
match
---
trailer [7910,7916]
trailer [7910,7916]
===
match
---
arglist [2814,2887]
arglist [2814,2887]
===
match
---
import_name [985,1000]
import_name [985,1000]
===
match
---
simple_stmt [5684,5714]
simple_stmt [5684,5714]
===
match
---
simple_stmt [2992,3039]
simple_stmt [2992,3039]
===
match
---
atom [10347,10454]
atom [10347,10454]
===
match
---
simple_stmt [10536,10790]
simple_stmt [10536,10790]
===
match
---
name: state [11921,11926]
name: state [11921,11926]
===
match
---
name: send_task_to_executor [13071,13092]
name: send_task_to_executor [13071,13092]
===
match
---
operator: , [24872,24873]
operator: , [24874,24875]
===
match
---
string: "clearing:\n\t%s" [14915,14932]
string: "clearing:\n\t%s" [14915,14932]
===
match
---
name: queued_tasks [10892,10904]
name: queued_tasks [10892,10904]
===
match
---
simple_stmt [11319,11358]
simple_stmt [11319,11358]
===
match
---
simple_stmt [1827,1919]
simple_stmt [1827,1919]
===
match
---
simple_stmt [24449,24500]
simple_stmt [24451,24502]
===
match
---
simple_stmt [6780,6826]
simple_stmt [6780,6826]
===
match
---
name: state [16618,16623]
name: state [16618,16623]
===
match
---
name: pop [16973,16976]
name: pop [16973,16976]
===
match
---
name: self [16203,16207]
name: self [16203,16207]
===
match
---
name: states_by_celery_task_id [19735,19759]
name: states_by_celery_task_id [19741,19765]
===
match
---
name: any [17391,17394]
name: any [17391,17394]
===
match
---
name: to_send_count [8606,8619]
name: to_send_count [8606,8619]
===
match
---
name: key [16446,16449]
name: key [16446,16449]
===
match
---
name: BaseExecutor [1871,1883]
name: BaseExecutor [1871,1883]
===
match
---
name: self [23551,23555]
name: self [23548,23552]
===
match
---
import_from [1759,1826]
import_from [1759,1826]
===
match
---
trailer [10955,10960]
trailer [10955,10960]
===
match
---
name: Exception [4053,4062]
name: Exception [4053,4062]
===
match
---
name: floor [25090,25095]
name: floor [25092,25097]
===
match
---
suite [7370,8427]
suite [7370,8427]
===
match
---
arglist [15822,15874]
arglist [15822,15874]
===
match
---
trailer [15113,15126]
trailer [15113,15126]
===
match
---
name: timeout [21152,21159]
name: timeout [21158,21165]
===
match
---
annassign [8280,8324]
annassign [8280,8324]
===
match
---
simple_stmt [3560,3594]
simple_stmt [3560,3594]
===
match
---
trailer [22889,22893]
trailer [22876,22880]
===
match
---
tfpdef [2921,2949]
tfpdef [2921,2949]
===
match
---
argument [21160,21185]
argument [21166,21191]
===
match
---
trailer [16395,16406]
trailer [16395,16406]
===
match
---
atom_expr [17512,17523]
atom_expr [17512,17523]
===
match
---
simple_stmt [958,973]
simple_stmt [958,973]
===
match
---
tfpdef [17930,17953]
tfpdef [17930,17953]
===
match
---
operator: , [25917,25918]
operator: , [25919,25920]
===
match
---
expr_stmt [23145,23203]
expr_stmt [23142,23200]
===
match
---
atom_expr [17014,17035]
atom_expr [17014,17035]
===
match
---
param [22241,22246]
param [22147,22152]
===
match
---
name: e [21496,21497]
name: e [21502,21503]
===
match
---
name: CommandType [17609,17620]
name: CommandType [17609,17620]
===
match
---
trailer [15996,16020]
trailer [15996,16020]
===
match
---
name: trigger_tasks [8900,8913]
name: trigger_tasks [8900,8913]
===
match
---
argument [4527,4541]
argument [4527,4541]
===
match
---
comparison [3442,3450]
comparison [3442,3450]
===
match
---
expr_stmt [24697,24726]
expr_stmt [24699,24728]
===
match
---
arglist [24954,24996]
arglist [24956,24998]
===
match
---
atom_expr [16143,16163]
atom_expr [16143,16163]
===
match
---
simple_stmt [12815,12861]
simple_stmt [12815,12861]
===
match
---
param [13502,13506]
param [13502,13506]
===
match
---
name: result [10239,10245]
name: result [10239,10245]
===
match
---
name: PENDING [24719,24726]
name: PENDING [24721,24728]
===
match
---
trailer [20235,20242]
trailer [20241,20248]
===
match
---
operator: , [16304,16305]
operator: , [16304,16305]
===
match
---
atom_expr [23830,23898]
atom_expr [23832,23900]
===
match
---
trailer [21680,21704]
trailer [21686,21710]
===
match
---
atom_expr [19260,19296]
atom_expr [19260,19296]
===
match
---
number: 5 [17501,17502]
number: 5 [17501,17502]
===
match
---
param [11990,11995]
param [11990,11995]
===
match
---
string: ":%s\n%s\n" [25676,25687]
string: ":%s\n%s\n" [25678,25689]
===
match
---
expr_stmt [19219,19301]
expr_stmt [19219,19301]
===
match
---
funcdef [7351,8427]
funcdef [7351,8427]
===
match
---
trailer [10951,10955]
trailer [10951,10955]
===
match
---
operator: = [2805,2806]
operator: = [2805,2806]
===
match
---
operator: == [16624,16626]
operator: == [16624,16626]
===
match
---
trailer [23877,23881]
trailer [23879,23883]
===
match
---
simple_stmt [4460,4552]
simple_stmt [4460,4552]
===
match
---
expr_stmt [11319,11357]
expr_stmt [11319,11357]
===
match
---
trailer [3860,3871]
trailer [3860,3871]
===
match
---
name: str [25362,25365]
name: str [25364,25367]
===
match
---
tfpdef [9700,9747]
tfpdef [9700,9747]
===
match
---
string: """Called in response to SIGUSR2 by the scheduler""" [15286,15338]
string: """Called in response to SIGUSR2 by the scheduler""" [15286,15338]
===
match
---
expr_stmt [9165,9217]
expr_stmt [9165,9217]
===
match
---
operator: = [3410,3411]
operator: = [3410,3411]
===
match
---
operator: = [8083,8084]
operator: = [8083,8084]
===
match
---
simple_stmt [11036,11204]
simple_stmt [11036,11204]
===
match
---
name: DatabaseBackend [1380,1395]
name: DatabaseBackend [1380,1395]
===
match
---
name: self [15598,15602]
name: self [15598,15602]
===
match
---
operator: = [22588,22589]
operator: = [22607,22608]
===
match
---
dotted_name [1290,1310]
dotted_name [1290,1310]
===
match
---
name: info [24590,24594]
name: info [24592,24596]
===
match
---
name: state_or_exception [25419,25437]
name: state_or_exception [25421,25439]
===
match
---
param [23551,23556]
param [23548,23553]
===
match
---
name: AirflowTaskTimeout [10257,10275]
name: AirflowTaskTimeout [10257,10275]
===
match
---
operator: = [12947,12948]
operator: = [12947,12948]
===
match
---
name: join [15456,15460]
name: join [15456,15460]
===
match
---
operator: = [25199,25200]
operator: = [25201,25202]
===
match
---
funcdef [13465,15243]
funcdef [13465,15243]
===
match
---
dotted_name [2014,2027]
dotted_name [2014,2027]
===
match
---
name: _get_many_from_kv_backend [22595,22620]
name: _get_many_from_kv_backend [22614,22639]
===
match
---
name: tis [19146,19149]
name: tis [19146,19149]
===
match
---
import_name [6844,6868]
import_name [6844,6868]
===
match
---
atom_expr [7680,7721]
atom_expr [7680,7721]
===
match
---
simple_stmt [1029,1041]
simple_stmt [1029,1041]
===
match
---
funcdef [22993,23516]
funcdef [22985,23513]
===
match
---
trailer [19271,19296]
trailer [19271,19296]
===
match
---
operator: , [16399,16400]
operator: , [16399,16400]
===
match
---
suite [13214,13460]
suite [13214,13460]
===
match
---
simple_stmt [7379,7398]
simple_stmt [7379,7398]
===
match
---
expr_stmt [22727,22781]
expr_stmt [22722,22776]
===
match
---
atom_expr [17092,17148]
atom_expr [17092,17148]
===
match
---
name: log [15987,15990]
name: log [15987,15990]
===
match
---
param [24268,24291]
param [24270,24293]
===
match
---
simple_stmt [2041,2098]
simple_stmt [2041,2098]
===
match
---
dotted_name [6787,6811]
dotted_name [6787,6811]
===
match
---
name: airflow [6717,6724]
name: airflow [6717,6724]
===
match
---
name: try_adopt_task_instances [17899,17923]
name: try_adopt_task_instances [17899,17923]
===
match
---
expr_stmt [6047,6102]
expr_stmt [6047,6102]
===
match
---
name: Dict [1162,1166]
name: Dict [1162,1166]
===
match
---
simple_stmt [24101,24185]
simple_stmt [24103,24187]
===
match
---
testlist_comp [19260,19300]
testlist_comp [19260,19300]
===
match
---
name: event_buffer [11225,11237]
name: event_buffer [11225,11237]
===
match
---
operator: - [7818,7819]
operator: - [7818,7819]
===
match
---
operator: -> [22387,22389]
operator: -> [22406,22408]
===
match
---
suite [17075,17149]
suite [17075,17149]
===
match
---
name: self [15982,15986]
name: self [15982,15986]
===
match
---
name: __init__ [22232,22240]
name: __init__ [22138,22146]
===
match
---
decorated [6170,6920]
decorated [6170,6920]
===
match
---
trailer [17100,17105]
trailer [17100,17105]
===
match
---
name: v [23316,23317]
name: v [23313,23314]
===
match
---
atom_expr [21425,21445]
atom_expr [21431,21451]
===
match
---
trailer [11416,11422]
trailer [11416,11422]
===
match
---
trailer [22829,22861]
trailer [22816,22848]
===
match
---
expr_stmt [9929,9971]
expr_stmt [9929,9971]
===
match
---
suite [4365,4851]
suite [4365,4851]
===
match
---
atom_expr [24024,24046]
atom_expr [24026,24048]
===
match
---
name: async_results [24958,24971]
name: async_results [24960,24973]
===
match
---
name: items [15482,15487]
name: items [15482,15487]
===
match
---
name: task [17444,17448]
name: task [17444,17448]
===
match
---
simple_stmt [13865,13880]
simple_stmt [13865,13880]
===
match
---
atom_expr [15807,15875]
atom_expr [15807,15875]
===
match
---
atom_expr [25133,25155]
atom_expr [25135,25157]
===
match
---
simple_stmt [13254,13311]
simple_stmt [13254,13311]
===
match
---
trailer [24486,24490]
trailer [24488,24492]
===
match
---
atom_expr [22390,22424]
atom_expr [22409,22443]
===
match
---
import_from [1720,1758]
import_from [1720,1758]
===
match
---
trailer [3338,3340]
trailer [3338,3340]
===
match
---
atom_expr [16203,16243]
atom_expr [16203,16243]
===
match
---
dictorsetmaker [21779,21809]
dictorsetmaker [22335,22365]
===
match
---
name: key [16396,16399]
name: key [16396,16399]
===
match
---
name: backend [22533,22540]
name: backend [22552,22559]
===
match
---
param [6237,6245]
param [6237,6245]
===
match
---
atom_expr [22946,22964]
atom_expr [22938,22956]
===
match
---
name: self [13254,13258]
name: self [13254,13258]
===
match
---
atom_expr [2807,2888]
atom_expr [2807,2888]
===
match
---
string: 'Celery command failed on host: ' [3503,3536]
string: 'Celery command failed on host: ' [3503,3536]
===
match
---
operator: = [3924,3925]
operator: = [3924,3925]
===
match
---
expr_stmt [9549,9583]
expr_stmt [9549,9583]
===
match
---
import_from [1429,1466]
import_from [1429,1466]
===
match
---
trailer [12764,12771]
trailer [12764,12771]
===
match
---
name: Any [1157,1160]
name: Any [1157,1160]
===
match
---
operator: , [9309,9310]
operator: , [9309,9310]
===
match
---
atom_expr [4109,4160]
atom_expr [4109,4160]
===
match
---
name: key [11391,11394]
name: key [11391,11394]
===
match
---
name: self [10652,10656]
name: self [10652,10656]
===
match
---
expr_stmt [2399,2455]
expr_stmt [2399,2455]
===
match
---
name: traceback [6014,6023]
name: traceback [6014,6023]
===
match
---
operator: , [24158,24159]
operator: , [24160,24161]
===
match
---
operator: -> [17955,17957]
operator: -> [17955,17957]
===
match
---
simple_stmt [5232,5259]
simple_stmt [5232,5259]
===
match
---
operator: , [8413,8414]
operator: , [8413,8414]
===
match
---
name: os [1008,1010]
name: os [1008,1010]
===
match
---
suite [25474,25924]
suite [25476,25926]
===
match
---
string: 'CELERY_APP_NAME' [2833,2850]
string: 'CELERY_APP_NAME' [2833,2850]
===
match
---
operator: , [20594,20595]
operator: , [20600,20601]
===
match
---
name: state [16818,16823]
name: state [16818,16823]
===
match
---
name: sorted_queue [9334,9346]
name: sorted_queue [9334,9346]
===
match
---
name: state [24697,24702]
name: state [24699,24704]
===
match
---
operator: = [13038,13039]
operator: = [13038,13039]
===
match
---
name: len [22946,22949]
name: len [22938,22941]
===
match
---
name: pop [10952,10955]
name: pop [10952,10955]
===
match
---
dotted_name [3629,3651]
dotted_name [3629,3651]
===
match
---
name: CommandType [5622,5633]
name: CommandType [5622,5633]
===
match
---
simple_stmt [3225,3259]
simple_stmt [3225,3259]
===
match
---
name: task_results [23908,23920]
name: task_results [23910,23922]
===
match
---
funcdef [22353,22988]
funcdef [22372,22980]
===
match
---
trailer [23843,23853]
trailer [23845,23855]
===
match
---
name: isinstance [22518,22528]
name: isinstance [22537,22547]
===
match
---
operator: , [11926,11927]
operator: , [11926,11927]
===
match
---
name: base_executor [1850,1863]
name: base_executor [1850,1863]
===
match
---
trailer [4622,4641]
trailer [4622,4641]
===
match
---
simple_stmt [1041,1058]
simple_stmt [1041,1058]
===
match
---
name: self [10926,10930]
name: self [10926,10930]
===
match
---
simple_stmt [9366,9429]
simple_stmt [9366,9429]
===
match
---
name: pop [9347,9350]
name: pop [9347,9350]
===
match
---
atom_expr [3901,3923]
atom_expr [3901,3923]
===
match
---
operator: = [24703,24704]
operator: = [24705,24706]
===
match
---
if_stmt [22515,22662]
if_stmt [22534,22864]
===
match
---
name: __init__ [7387,7395]
name: __init__ [7387,7395]
===
match
---
simple_stmt [17053,17058]
simple_stmt [17053,17058]
===
match
---
operator: = [23626,23627]
operator: = [23623,23624]
===
match
---
operator: = [8175,8176]
operator: = [8175,8176]
===
match
---
trailer [9153,9155]
trailer [9153,9155]
===
match
---
name: task_instance_str [20461,20478]
name: task_instance_str [20467,20484]
===
match
---
operator: , [1219,1220]
operator: , [1219,1220]
===
match
---
import_as_names [1790,1826]
import_as_names [1790,1826]
===
match
---
suite [16186,16244]
suite [16186,16244]
===
match
---
arglist [12222,12264]
arglist [12222,12264]
===
match
---
name: v [23301,23302]
name: v [23298,23299]
===
match
---
name: CELERY_SEND_ERR_MSG_HEADER [2399,2425]
name: CELERY_SEND_ERR_MSG_HEADER [2399,2425]
===
match
---
name: join [20329,20333]
name: join [20335,20339]
===
match
---
trailer [20041,20053]
trailer [20047,20059]
===
match
---
string: """Executes command.""" [2964,2987]
string: """Executes command.""" [2964,2987]
===
match
---
trailer [20060,20082]
trailer [20066,20088]
===
match
---
trailer [15693,15695]
trailer [15693,15695]
===
match
---
suite [5775,5899]
suite [5775,5899]
===
match
---
name: tasks [16386,16391]
name: tasks [16386,16391]
===
match
---
trailer [12828,12860]
trailer [12828,12860]
===
match
---
simple_stmt [3624,3670]
simple_stmt [3624,3670]
===
match
---
trailer [23799,23808]
trailer [23801,23810]
===
match
---
expr_stmt [9366,9428]
expr_stmt [9366,9428]
===
match
---
name: next [9779,9783]
name: next [9779,9783]
===
match
---
name: staticmethod [24191,24203]
name: staticmethod [24193,24205]
===
match
---
name: task_tuples_to_send [11996,12015]
name: task_tuples_to_send [11996,12015]
===
match
---
parameters [8913,8936]
parameters [8913,8936]
===
match
---
suite [15755,16244]
suite [15755,16244]
===
match
---
name: self [24974,24978]
name: self [24976,24980]
===
match
---
name: task_tuples_to_send [12245,12264]
name: task_tuples_to_send [12245,12264]
===
match
---
atom_expr [5846,5898]
atom_expr [5846,5898]
===
match
---
name: cpu_count [7806,7815]
name: cpu_count [7806,7815]
===
match
---
number: 1 [3605,3606]
number: 1 [3605,3606]
===
match
---
param [8606,8624]
param [8606,8624]
===
match
---
name: EventBufferValueType [1898,1918]
name: EventBufferValueType [1898,1918]
===
match
---
name: exception_traceback [5966,5985]
name: exception_traceback [5966,5985]
===
match
---
trailer [16339,16341]
trailer [16339,16341]
===
match
---
operator: = [25281,25282]
operator: = [25283,25284]
===
match
---
trailer [19168,19189]
trailer [19168,19189]
===
match
---
trailer [9245,9281]
trailer [9245,9281]
===
match
---
trailer [20105,20113]
trailer [20111,20119]
===
match
---
trailer [12835,12843]
trailer [12835,12843]
===
match
---
atom_expr [20135,20159]
atom_expr [20141,20165]
===
match
---
atom_expr [21596,21618]
atom_expr [21602,21624]
===
match
---
dotted_name [1924,1951]
dotted_name [1924,1951]
===
match
---
name: get_many [19507,19515]
name: get_many [19507,19515]
===
match
---
atom_expr [4800,4814]
atom_expr [4800,4814]
===
match
---
suite [10148,11959]
suite [10148,11959]
===
match
---
simple_stmt [24743,24755]
simple_stmt [24745,24757]
===
match
---
simple_stmt [22581,22636]
simple_stmt [22600,22655]
===
match
---
name: self [10810,10814]
name: self [10810,10814]
===
match
---
expr_stmt [5267,5303]
expr_stmt [5267,5303]
===
match
---
atom_expr [12772,12785]
atom_expr [12772,12785]
===
match
---
arglist [4484,4550]
arglist [4484,4550]
===
match
---
trailer [5514,5519]
trailer [5514,5519]
===
match
---
name: self [16484,16488]
name: self [16484,16488]
===
match
---
trailer [25731,25741]
trailer [25733,25743]
===
match
---
trailer [23853,23860]
trailer [23855,23862]
===
match
---
atom_expr [10536,10789]
atom_expr [10536,10789]
===
match
---
name: keys [23145,23149]
name: keys [23142,23146]
===
match
---
with_stmt [25007,25924]
with_stmt [25009,25926]
===
match
---
trailer [4378,4386]
trailer [4378,4386]
===
match
---
suite [21530,21711]
suite [21536,21717]
===
match
---
return_stmt [12206,12266]
return_stmt [12206,12266]
===
match
---
name: len [22933,22936]
name: len [22925,22928]
===
match
---
name: async_result [16038,16050]
name: async_result [16038,16050]
===
match
---
argument [8223,8235]
argument [8223,8235]
===
match
---
name: key [11909,11912]
name: key [11909,11912]
===
match
---
expr_stmt [24743,24754]
expr_stmt [24745,24756]
===
match
---
trailer [5857,5869]
trailer [5857,5869]
===
match
---
name: BaseKeyValueStoreBackend [22542,22566]
name: BaseKeyValueStoreBackend [22561,22585]
===
match
---
name: self [15510,15514]
name: self [15510,15514]
===
match
---
expr_stmt [2672,2744]
expr_stmt [2672,2744]
===
match
---
trailer [10986,11018]
trailer [10986,11018]
===
match
---
trailer [9783,9818]
trailer [9783,9818]
===
match
---
trailer [25578,25584]
trailer [25580,25586]
===
match
---
return_stmt [20502,20524]
return_stmt [20508,20530]
===
match
---
name: self [23023,23027]
name: self [23015,23019]
===
match
---
dictorsetmaker [24024,24091]
dictorsetmaker [24026,24093]
===
match
---
name: conf [2616,2620]
name: conf [2616,2620]
===
match
---
import_from [1228,1284]
import_from [1228,1284]
===
match
---
name: info [15519,15523]
name: info [15519,15523]
===
match
---
import_name [6780,6811]
import_name [6780,6811]
===
match
---
atom_expr [5599,5678]
atom_expr [5599,5678]
===
match
---
operator: -> [8448,8450]
operator: -> [8448,8450]
===
match
---
name: first_task [9953,9963]
name: first_task [9953,9963]
===
match
---
trailer [19677,19680]
trailer [19683,19686]
===
match
---
name: EventBufferValueType [25367,25387]
name: EventBufferValueType [25369,25389]
===
match
---
string: 'Error sending Celery task' [2428,2455]
string: 'Error sending Celery task' [2428,2455]
===
match
---
trailer [24371,24398]
trailer [24373,24400]
===
match
---
arglist [10575,10767]
arglist [10575,10767]
===
match
---
comp_op [9499,9505]
comp_op [9499,9505]
===
match
---
name: _prepare_state_and_info_by_task_dict [24212,24248]
name: _prepare_state_and_info_by_task_dict [24214,24250]
===
match
---
atom_expr [8829,8889]
atom_expr [8829,8889]
===
match
---
operator: , [8062,8063]
operator: , [8062,8063]
===
match
---
name: key [20198,20201]
name: key [20204,20207]
===
match
---
trailer [19351,19358]
trailer [19351,19358]
===
match
---
tfpdef [20555,20580]
tfpdef [20561,20586]
===
match
---
atom_expr [15347,15367]
atom_expr [15347,15367]
===
match
---
name: min [24950,24953]
name: min [24952,24955]
===
match
---
string: 'celery' [2632,2640]
string: 'celery' [2632,2640]
===
match
---
atom_expr [4740,4748]
atom_expr [4740,4748]
===
match
---
trailer [12021,12043]
trailer [12021,12043]
===
match
---
name: setproctitle [1559,1571]
name: setproctitle [1559,1571]
===
match
---
trailer [24654,24662]
trailer [24656,24664]
===
match
---
atom_expr [23268,23296]
atom_expr [23265,23293]
===
match
---
expr_stmt [23327,23422]
expr_stmt [23324,23419]
===
match
---
operator: = [2361,2362]
operator: = [2361,2362]
===
match
---
trailer [9963,9971]
trailer [9963,9971]
===
match
---
number: 3 [8424,8425]
number: 3 [8424,8425]
===
match
---
name: execute_command [2905,2920]
name: execute_command [2905,2920]
===
match
---
decorator [6170,6201]
decorator [6170,6201]
===
match
---
atom_expr [3718,3743]
atom_expr [3718,3743]
===
match
---
arglist [25082,25157]
arglist [25084,25159]
===
match
---
name: hasattr [24609,24616]
name: hasattr [24611,24618]
===
match
---
operator: = [15917,15918]
operator: = [15917,15918]
===
match
---
name: command_to_exec [4484,4499]
name: command_to_exec [4484,4499]
===
match
---
simple_stmt [5718,5767]
simple_stmt [5718,5767]
===
match
---
name: command_to_exec [3982,3997]
name: command_to_exec [3982,3997]
===
match
---
name: task_tuples_to_send [12502,12521]
name: task_tuples_to_send [12502,12521]
===
match
---
name: log [3043,3046]
name: log [3043,3046]
===
match
---
operator: , [17928,17929]
operator: , [17928,17929]
===
match
---
atom_expr [7906,7916]
atom_expr [7906,7916]
===
match
---
import_as_name [1494,1533]
import_as_name [1494,1533]
===
match
---
name: _sync_parallelism [8870,8887]
name: _sync_parallelism [8870,8887]
===
match
---
trailer [8369,8376]
trailer [8369,8376]
===
match
---
string: 'celery' [2710,2718]
string: 'celery' [2710,2718]
===
match
---
trailer [22397,22424]
trailer [22416,22443]
===
match
---
expr_stmt [8014,8098]
expr_stmt [8014,8098]
===
match
---
name: task_publish_retries [9511,9531]
name: task_publish_retries [9511,9531]
===
match
---
trailer [22594,22620]
trailer [22613,22639]
===
match
---
atom_expr [19272,19295]
atom_expr [19272,19295]
===
match
---
trailer [7802,7822]
trailer [7802,7822]
===
match
---
name: self [17870,17874]
name: self [17870,17874]
===
match
---
name: values [17463,17469]
name: values [17463,17469]
===
match
---
trailer [19506,19515]
trailer [19506,19515]
===
match
---
name: exception [11158,11167]
name: exception [11158,11167]
===
match
---
trailer [23480,23515]
trailer [23477,23512]
===
match
---
operator: , [11149,11150]
operator: , [11149,11150]
===
match
---
simple_stmt [22885,22966]
simple_stmt [22872,22958]
===
match
---
operator: , [20208,20209]
operator: , [20214,20215]
===
match
---
name: get_hostname [2128,2140]
name: get_hostname [2128,2140]
===
match
---
trailer [8072,8081]
trailer [8072,8081]
===
match
---
term [8843,8887]
term [8843,8887]
===
match
---
name: self [15919,15923]
name: self [15919,15923]
===
match
---
simple_stmt [16666,16690]
simple_stmt [16666,16690]
===
match
---
simple_stmt [23617,23665]
simple_stmt [23614,23667]
===
match
---
name: queue [9314,9319]
name: queue [9314,9319]
===
match
---
trailer [25504,25548]
trailer [25506,25550]
===
match
---
name: key [20109,20112]
name: key [20115,20118]
===
match
---
expr_stmt [23908,23988]
expr_stmt [23910,23990]
===
match
---
name: on_celery_import_modules [6205,6229]
name: on_celery_import_modules [6205,6229]
===
match
---
trailer [19515,19589]
trailer [19533,19585]
===
match
---
name: _get_many_from_kv_backend [22997,23022]
name: _get_many_from_kv_backend [22989,23014]
===
match
---
name: task_cls [23861,23869]
name: task_cls [23863,23871]
===
match
---
suite [10455,10875]
suite [10455,10875]
===
match
---
import_name [6577,6594]
import_name [6577,6594]
===
match
---
name: airflow [2103,2110]
name: airflow [2103,2110]
===
match
---
trailer [16441,16445]
trailer [16441,16445]
===
match
---
simple_stmt [1011,1029]
simple_stmt [1011,1029]
===
match
---
name: func [4015,4019]
name: func [4015,4019]
===
match
---
trailer [4228,4237]
trailer [4228,4237]
===
match
---
name: task_ids [24427,24435]
name: task_ids [24429,24437]
===
match
---
name: key [16790,16793]
name: key [16790,16793]
===
match
---
simple_stmt [2179,2221]
simple_stmt [2179,2221]
===
match
---
trailer [11040,11044]
trailer [11040,11044]
===
match
---
name: result [11169,11175]
name: result [11169,11175]
===
match
---
name: start [8436,8441]
name: start [8436,8441]
===
match
---
name: queue [5735,5740]
name: queue [5735,5740]
===
match
---
operator: { [21778,21779]
operator: { [22334,22335]
===
match
---
trailer [8096,8098]
trailer [8096,8098]
===
match
---
operator: , [1212,1213]
operator: , [1212,1213]
===
match
---
name: iter [19649,19653]
name: iter [19655,19659]
===
match
---
name: simple_ti [9321,9330]
name: simple_ti [9321,9330]
===
match
---
simple_stmt [19620,19689]
simple_stmt [19626,19695]
===
match
---
name: log [4730,4733]
name: log [4730,4733]
===
match
---
param [9700,9747]
param [9700,9747]
===
match
---
name: result [11936,11942]
name: result [11936,11942]
===
match
---
suite [4100,4177]
suite [4100,4177]
===
match
---
string: 'Starting Celery Executor using %s processes for syncing' [8480,8537]
string: 'Starting Celery Executor using %s processes for syncing' [8480,8537]
===
match
---
name: key [15071,15074]
name: key [15071,15074]
===
match
---
name: send_task_to_executor [12222,12243]
name: send_task_to_executor [12222,12243]
===
match
---
argument [8415,8425]
argument [8415,8425]
===
match
---
name: key [9495,9498]
name: key [9495,9498]
===
match
---
name: log [15812,15815]
name: log [15812,15815]
===
match
---
trailer [15986,15990]
trailer [15986,15990]
===
match
---
name: ret [3442,3445]
name: ret [3442,3445]
===
match
---
operator: , [21656,21657]
operator: , [21662,21663]
===
match
---
param [2921,2949]
param [2921,2949]
===
match
---
name: ti [19140,19142]
name: ti [19140,19142]
===
match
---
atom_expr [16827,16848]
atom_expr [16827,16848]
===
match
---
name: session [23800,23807]
name: session [23802,23809]
===
match
---
simple_stmt [24345,24404]
simple_stmt [24347,24406]
===
match
---
string: "Unexpected state for %s: %s" [17106,17135]
string: "Unexpected state for %s: %s" [17106,17135]
===
match
---
trailer [3772,3774]
trailer [3772,3774]
===
match
---
name: async_result [21447,21459]
name: async_result [21453,21465]
===
match
---
name: bulk_state_fetcher [15924,15942]
name: bulk_state_fetcher [15924,15942]
===
match
---
suite [22714,22808]
suite [22709,22777]
===
match
---
trailer [17645,17650]
trailer [17645,17650]
===
match
---
trailer [10321,10342]
trailer [10321,10342]
===
match
---
name: ExceptionWithTraceback [4859,4881]
name: ExceptionWithTraceback [4859,4881]
===
match
---
arglist [14811,15040]
arglist [14811,15040]
===
match
---
name: QUEUED [11763,11769]
name: QUEUED [11763,11769]
===
match
---
name: self [11990,11994]
name: self [11990,11994]
===
match
---
name: self [7364,7368]
name: self [7364,7368]
===
match
---
atom_expr [19735,19767]
atom_expr [19741,19773]
===
match
---
name: args [6231,6235]
name: args [6231,6235]
===
match
---
simple_stmt [4758,4815]
simple_stmt [4758,4815]
===
match
---
raise_stmt [3480,3554]
raise_stmt [3480,3554]
===
match
---
name: map [15461,15464]
name: map [15461,15464]
===
match
---
simple_stmt [3401,3431]
simple_stmt [3401,3431]
===
match
---
atom_expr [4248,4261]
atom_expr [4248,4261]
===
match
---
testlist_comp [11757,11785]
testlist_comp [11757,11785]
===
match
---
tfpdef [16490,16510]
tfpdef [16490,16510]
===
match
---
name: task_result [23378,23389]
name: task_result [23375,23386]
===
match
---
operator: = [16104,16105]
operator: = [16104,16105]
===
match
---
name: airflow [2146,2153]
name: airflow [2146,2153]
===
match
---
name: conf [2695,2699]
name: conf [2695,2699]
===
match
---
param [24258,24267]
param [24260,24269]
===
match
---
name: subprocess [1018,1028]
name: subprocess [1018,1028]
===
match
---
operator: == [17011,17013]
operator: == [17011,17013]
===
match
---
atom [7919,7921]
atom [7919,7921]
===
match
---
operator: = [9777,9778]
operator: = [9777,9778]
===
match
---
name: app [23153,23156]
name: app [23150,23153]
===
match
---
trailer [3422,3430]
trailer [3422,3430]
===
match
---
atom_expr [16717,16738]
atom_expr [16717,16738]
===
match
---
subscriptlist [24372,24397]
subscriptlist [24374,24399]
===
match
---
name: ret [4257,4260]
name: ret [4257,4260]
===
match
---
name: signal [12845,12851]
name: signal [12845,12851]
===
match
---
name: app [23924,23927]
name: app [23926,23929]
===
match
---
atom_expr [7655,7677]
atom_expr [7655,7677]
===
match
---
funcdef [8896,9670]
funcdef [8896,9670]
===
match
---
name: key [5718,5721]
name: key [5718,5721]
===
match
---
trailer [16069,16075]
trailer [16069,16075]
===
match
---
name: TaskInstanceInCelery [5427,5447]
name: TaskInstanceInCelery [5427,5447]
===
match
---
simple_stmt [23673,23711]
simple_stmt [23675,23713]
===
match
---
string: "Executing command in Celery: %s" [3052,3085]
string: "Executing command in Celery: %s" [3052,3085]
===
match
---
atom_expr [13230,13240]
atom_expr [13230,13240]
===
match
---
string: 'operation_timeout' [2501,2520]
string: 'operation_timeout' [2501,2520]
===
match
---
name: math [25096,25100]
name: math [25098,25102]
===
match
---
name: math [25085,25089]
name: math [25087,25091]
===
match
---
dotted_name [3565,3579]
dotted_name [3565,3579]
===
match
---
name: self [8014,8018]
name: self [8014,8018]
===
match
---
operator: , [5519,5520]
operator: , [5519,5520]
===
match
---
name: pop [16392,16395]
name: pop [16392,16395]
===
match
---
operator: , [22695,22696]
operator: , [22690,22691]
===
match
---
suite [12045,13186]
suite [12045,13186]
===
match
---
name: TaskInstanceInCelery [9726,9746]
name: TaskInstanceInCelery [9726,9746]
===
match
---
comp_op [17406,17412]
comp_op [17406,17412]
===
match
---
atom_expr [9779,9818]
atom_expr [9779,9818]
===
match
---
name: EventBufferValueType [24314,24334]
name: EventBufferValueType [24316,24336]
===
match
---
simple_stmt [23252,23319]
simple_stmt [23249,23316]
===
match
---
atom_expr [17637,17650]
atom_expr [17637,17650]
===
match
---
name: getimport [2700,2709]
name: getimport [2700,2709]
===
match
---
atom_expr [22933,22944]
atom_expr [22925,22936]
===
match
---
parameters [4326,4356]
parameters [4326,4356]
===
match
---
trailer [16138,16142]
trailer [16138,16142]
===
match
---
operator: = [22263,22264]
operator: = [22169,22170]
===
match
---
parameters [21740,21753]
parameters [22286,22305]
===
match
---
decorated [2891,3259]
decorated [2891,3259]
===
match
---
param [3282,3310]
param [3282,3310]
===
match
---
atom_expr [17791,17850]
atom_expr [17791,17850]
===
match
---
operator: , [13092,13093]
operator: , [13092,13093]
===
match
---
trailer [19487,19506]
trailer [19487,19506]
===
match
---
name: CommandType [5493,5504]
name: CommandType [5493,5504]
===
match
---
name: OrderedDict [8311,8322]
name: OrderedDict [8311,8322]
===
match
---
import_name [6710,6739]
import_name [6710,6739]
===
match
---
operator: , [8827,8828]
operator: , [8827,8828]
===
match
---
name: adopted_task_timeouts [16420,16441]
name: adopted_task_timeouts [16420,16441]
===
match
---
name: self [12524,12528]
name: self [12524,12528]
===
match
---
name: backend [23225,23232]
name: backend [23222,23229]
===
match
---
name: tasks [7911,7916]
name: tasks [7911,7916]
===
match
---
name: self [13338,13342]
name: self [13338,13342]
===
match
---
name: command_to_exec [4327,4342]
name: command_to_exec [4327,4342]
===
match
---
funcdef [2901,3259]
funcdef [2901,3259]
===
match
---
name: _num_tasks_per_send_process [12416,12443]
name: _num_tasks_per_send_process [12416,12443]
===
match
---
atom_expr [9953,9971]
atom_expr [9953,9971]
===
match
---
name: self [15436,15440]
name: self [15436,15440]
===
match
---
name: Sentry [4198,4204]
name: Sentry [4198,4204]
===
match
---
trailer [17228,17232]
trailer [17228,17232]
===
match
---
name: task_result [24064,24075]
name: task_result [24066,24077]
===
match
---
name: CELERY_SEND_ERR_MSG_HEADER [11108,11134]
name: CELERY_SEND_ERR_MSG_HEADER [11108,11134]
===
match
---
operator: = [25389,25390]
operator: = [25391,25392]
===
match
---
exprlist [25410,25443]
exprlist [25412,25445]
===
match
---
atom_expr [15598,15624]
atom_expr [15598,15624]
===
match
---
name: task_to_run [5742,5753]
name: task_to_run [5742,5753]
===
match
---
name: celery_states [24705,24718]
name: celery_states [24707,24720]
===
match
---
name: adopted [19599,19606]
name: adopted [19605,19612]
===
match
---
trailer [23156,23164]
trailer [23153,23161]
===
match
---
trailer [13968,13974]
trailer [13968,13974]
===
match
---
name: SIG_DFL [12794,12801]
name: SIG_DFL [12794,12801]
===
match
---
name: task_results_by_task_id [23327,23350]
name: task_results_by_task_id [23324,23347]
===
match
---
param [17600,17621]
param [17600,17621]
===
match
---
simple_stmt [1285,1343]
simple_stmt [1285,1343]
===
match
---
string: 'Celery command failed on host: ' [4764,4797]
string: 'Celery command failed on host: ' [4764,4797]
===
match
---
name: async_tasks [23124,23135]
name: async_tasks [23121,23132]
===
match
---
name: tasks [11417,11422]
name: tasks [11417,11422]
===
match
---
atom_expr [15919,15972]
atom_expr [15919,15972]
===
match
---
simple_stmt [4823,4851]
simple_stmt [4823,4851]
===
match
---
name: celery_configuration [2867,2887]
name: celery_configuration [2867,2887]
===
match
---
name: timedout_keys [15078,15091]
name: timedout_keys [15078,15091]
===
match
---
trailer [11935,11957]
trailer [11935,11957]
===
match
---
operator: , [16510,16511]
operator: , [16510,16511]
===
match
---
trailer [17469,17471]
trailer [17469,17471]
===
match
---
name: task_id [21781,21788]
name: task_id [22337,22344]
===
match
---
name: celery_tasks [19379,19391]
name: celery_tasks [19379,19391]
===
match
---
name: AirflowTaskTimeout [1808,1826]
name: AirflowTaskTimeout [1808,1826]
===
match
---
atom_expr [12873,12918]
atom_expr [12873,12918]
===
match
---
trailer [20197,20201]
trailer [20203,20207]
===
match
---
atom_expr [22518,22567]
atom_expr [22537,22586]
===
match
---
name: REVOKED [16754,16761]
name: REVOKED [16754,16761]
===
match
---
atom_expr [15594,15625]
atom_expr [15594,15625]
===
match
---
suite [2667,2745]
suite [2667,2745]
===
match
---
name: e [21681,21682]
name: e [21687,21688]
===
match
---
operator: , [12785,12786]
operator: , [12785,12786]
===
match
---
name: TaskInstanceKey [5456,5471]
name: TaskInstanceKey [5456,5471]
===
match
---
name: self [7655,7659]
name: self [7655,7659]
===
match
---
simple_stmt [23822,23899]
simple_stmt [23824,23901]
===
match
---
trailer [10245,10255]
trailer [10245,10255]
===
match
---
sync_comp_for [23970,23987]
sync_comp_for [23972,23989]
===
match
---
suite [24436,24801]
suite [24438,24803]
===
match
---
atom [9379,9428]
atom [9379,9428]
===
match
---
name: task_result [24024,24035]
name: task_result [24026,24037]
===
match
---
operator: , [17311,17312]
operator: , [17311,17312]
===
match
---
argument [5886,5897]
argument [5886,5897]
===
match
---
trailer [8180,8187]
trailer [8180,8187]
===
match
---
atom_expr [23683,23710]
atom_expr [23685,23712]
===
match
---
name: FAILED [15141,15147]
name: FAILED [15141,15147]
===
match
---
atom_expr [13942,13976]
atom_expr [13942,13976]
===
match
---
operator: , [19787,19788]
operator: , [19793,19794]
===
match
---
name: TaskInstanceInCelery [5572,5592]
name: TaskInstanceInCelery [5572,5592]
===
match
---
operator: , [15659,15660]
operator: , [15659,15660]
===
match
---
name: state [16512,16517]
name: state [16512,16517]
===
match
---
atom_expr [14950,14976]
atom_expr [14950,14976]
===
match
---
operator: = [20037,20038]
operator: = [20043,20044]
===
match
---
suite [11019,11266]
suite [11019,11266]
===
match
---
simple_stmt [17721,17777]
simple_stmt [17721,17777]
===
match
---
atom [24023,24092]
atom [24025,24094]
===
match
---
name: super [7379,7384]
name: super [7379,7384]
===
match
---
operator: = [22329,22330]
operator: = [22235,22236]
===
match
---
name: traceback [11176,11185]
name: traceback [11176,11185]
===
match
---
classdef [4853,5304]
classdef [4853,5304]
===
match
---
atom_expr [4508,4525]
atom_expr [4508,4525]
===
match
---
simple_stmt [25066,25159]
simple_stmt [25068,25161]
===
match
---
tfpdef [16294,16304]
tfpdef [16294,16304]
===
match
---
operator: -> [2951,2953]
operator: -> [2951,2953]
===
match
---
trailer [11908,11958]
trailer [11908,11958]
===
match
---
suite [16543,17294]
suite [16543,17294]
===
match
---
operator: = [9580,9581]
operator: = [9580,9581]
===
match
---
trailer [17027,17035]
trailer [17027,17035]
===
match
---
atom_expr [16946,16987]
atom_expr [16946,16987]
===
match
---
if_stmt [10973,11959]
if_stmt [10973,11959]
===
match
---
name: async_results [24874,24887]
name: async_results [24876,24889]
===
match
---
name: len [25112,25115]
name: len [25114,25117]
===
match
---
trailer [23737,23770]
trailer [23739,23772]
===
match
---
name: change_state [16342,16354]
name: change_state [16342,16354]
===
match
---
name: str [4153,4156]
name: str [4153,4156]
===
match
---
trailer [12771,12802]
trailer [12771,12802]
===
match
---
name: ExceptionWithTraceback [25525,25547]
name: ExceptionWithTraceback [25527,25549]
===
match
---
operator: , [11950,11951]
operator: , [11950,11951]
===
match
---
atom_expr [16059,16077]
atom_expr [16059,16077]
===
match
---
name: result [1441,1447]
name: result [1441,1447]
===
match
---
name: shutdown [4229,4237]
name: shutdown [4229,4237]
===
match
---
name: Exception [17164,17173]
name: Exception [17164,17173]
===
match
---
trailer [25574,25578]
trailer [25576,25580]
===
match
---
operator: = [2530,2531]
operator: = [2530,2531]
===
match
---
name: self [14950,14954]
name: self [14950,14954]
===
match
---
name: state [16231,16236]
name: state [16231,16236]
===
match
---
suite [9757,11959]
suite [9757,11959]
===
match
---
operator: , [20605,20606]
operator: , [20611,20612]
===
match
---
name: celery [1472,1478]
name: celery [1472,1478]
===
match
---
name: CommandType [2938,2949]
name: CommandType [2938,2949]
===
match
---
name: self [8255,8259]
name: self [8255,8259]
===
match
---
simple_stmt [19106,19127]
simple_stmt [19106,19127]
===
match
---
simple_stmt [15884,15973]
simple_stmt [15884,15973]
===
match
---
trailer [9785,9788]
trailer [9785,9788]
===
match
---
atom_expr [5232,5246]
atom_expr [5232,5246]
===
match
---
name: not_adopted_tis [20509,20524]
name: not_adopted_tis [20515,20530]
===
match
---
trailer [17521,17523]
trailer [17521,17523]
===
match
---
trailer [25095,25157]
trailer [25097,25159]
===
match
---
name: fallback [2522,2530]
name: fallback [2522,2530]
===
match
---
atom_expr [11928,11957]
atom_expr [11928,11957]
===
match
---
name: AsyncResult [19260,19271]
name: AsyncResult [19260,19271]
===
match
---
name: result [10175,10181]
name: result [10175,10181]
===
match
---
operator: = [8231,8232]
operator: = [8231,8232]
===
match
---
operator: , [7804,7805]
operator: , [7804,7805]
===
match
---
name: update_task_state [20177,20194]
name: update_task_state [20183,20200]
===
match
---
comparison [16618,16648]
comparison [16618,16648]
===
match
---
trailer [7684,7691]
trailer [7684,7691]
===
match
---
operator: = [11334,11335]
operator: = [11334,11335]
===
match
---
trailer [3871,3892]
trailer [3871,3892]
===
match
---
arglist [16226,16242]
arglist [16226,16242]
===
match
---
operator: , [10682,10683]
operator: , [10682,10683]
===
match
---
name: List [17935,17939]
name: List [17935,17939]
===
match
---
simple_stmt [23719,23771]
simple_stmt [23721,23773]
===
match
---
for_stmt [13916,14740]
for_stmt [13916,14740]
===
match
---
name: conf [7680,7684]
name: conf [7680,7684]
===
match
---
simple_stmt [15764,15799]
simple_stmt [15764,15799]
===
match
---
trailer [6078,6102]
trailer [6078,6102]
===
match
---
name: operators [6795,6804]
name: operators [6795,6804]
===
match
---
name: reset_signals [12975,12988]
name: reset_signals [12975,12988]
===
match
---
atom_expr [3167,3206]
atom_expr [3167,3206]
===
match
---
operator: , [16036,16037]
operator: , [16036,16037]
===
match
---
name: Set [21757,21760]
name: Set [22309,22312]
===
match
---
expr_stmt [25172,25305]
expr_stmt [25174,25307]
===
match
---
name: get_parser [3659,3669]
name: get_parser [3659,3669]
===
match
---
operator: , [19716,19717]
operator: , [19722,19723]
===
match
---
name: adopted_task_timeouts [20007,20028]
name: adopted_task_timeouts [20013,20034]
===
match
---
trailer [10221,10289]
trailer [10221,10289]
===
match
---
atom_expr [11914,11926]
atom_expr [11914,11926]
===
match
---
atom_expr [14779,15054]
atom_expr [14779,15054]
===
match
---
name: app [23683,23686]
name: app [23685,23688]
===
match
---
trailer [15380,15384]
trailer [15380,15384]
===
match
---
suite [10290,10875]
suite [10290,10875]
===
match
---
expr_stmt [23719,23770]
expr_stmt [23721,23772]
===
match
---
trailer [4112,4122]
trailer [4112,4122]
===
match
---
simple_stmt [11886,11959]
simple_stmt [11886,11959]
===
match
---
simple_stmt [4221,4240]
simple_stmt [4221,4240]
===
match
---
operator: * [6230,6231]
operator: * [6230,6231]
===
match
---
atom_expr [3043,3103]
atom_expr [3043,3103]
===
match
---
operator: = [9116,9117]
operator: = [9116,9117]
===
match
---
funcdef [21713,21811]
funcdef [22259,22367]
===
match
---
atom_expr [23628,23664]
atom_expr [23625,23666]
===
match
---
trailer [15815,15821]
trailer [15815,15821]
===
match
---
name: info [16238,16242]
name: info [16238,16242]
===
match
---
trailer [21760,21765]
trailer [22312,22317]
===
match
---
expr_stmt [5718,5766]
expr_stmt [5718,5766]
===
match
---
suite [24336,24827]
suite [24338,24829]
===
match
---
simple_stmt [4248,4298]
simple_stmt [4248,4298]
===
match
---
trailer [14787,14793]
trailer [14787,14793]
===
match
---
atom_expr [8333,8362]
atom_expr [8333,8362]
===
match
---
trailer [15597,15625]
trailer [15597,15625]
===
match
---
operator: { [25391,25392]
operator: { [25393,25394]
===
match
---
atom_expr [8107,8133]
atom_expr [8107,8133]
===
match
---
fstring_string: Celery Task ID:  [21563,21579]
fstring_string: Celery Task ID:  [21569,21585]
===
match
---
trailer [24112,24149]
trailer [24114,24151]
===
match
---
operator: = [25026,25027]
operator: = [25028,25029]
===
match
---
import_from [1343,1428]
import_from [1343,1428]
===
match
---
name: adopted_task_timeouts [15666,15687]
name: adopted_task_timeouts [15666,15687]
===
match
---
expr_stmt [15109,15154]
expr_stmt [15109,15154]
===
match
---
name: self [20355,20359]
name: self [20361,20365]
===
match
---
name: self [8600,8604]
name: self [8600,8604]
===
match
---
name: self [8914,8918]
name: self [8914,8918]
===
match
---
operator: , [1395,1396]
operator: , [1395,1396]
===
match
---
expr_stmt [19599,19611]
expr_stmt [19605,19617]
===
match
---
operator: , [19296,19297]
operator: , [19296,19297]
===
match
---
operator: = [10003,10004]
operator: = [10003,10004]
===
match
---
dotted_name [1472,1486]
dotted_name [1472,1486]
===
match
---
trailer [13974,13976]
trailer [13974,13976]
===
match
---
trailer [23365,23376]
trailer [23362,23373]
===
match
---
atom_expr [17958,17976]
atom_expr [17958,17976]
===
match
---
funcdef [5156,5304]
funcdef [5156,5304]
===
match
---
name: state_info [24345,24355]
name: state_info [24347,24357]
===
match
---
name: Any [16530,16533]
name: Any [16530,16533]
===
match
---
import_name [6645,6679]
import_name [6645,6679]
===
match
---
simple_stmt [10887,10914]
simple_stmt [10887,10914]
===
match
---
name: hasattr [21366,21373]
name: hasattr [21372,21379]
===
match
---
suite [16649,16690]
suite [16649,16690]
===
match
---
name: self [13200,13204]
name: self [13200,13204]
===
match
---
testlist [21636,21710]
testlist [21642,21716]
===
match
---
name: airflow [2014,2021]
name: airflow [2014,2021]
===
match
---
trailer [25089,25095]
trailer [25091,25097]
===
match
---
simple_stmt [2457,2536]
simple_stmt [2457,2536]
===
match
---
trailer [19576,19578]
trailer [19581,19583]
===
match
---
string: "info" [24655,24661]
string: "info" [24657,24663]
===
match
---
arglist [12498,12546]
arglist [12498,12546]
===
match
---
number: 1 [8826,8827]
number: 1 [8826,8827]
===
match
---
name: task_adoption_timeout [20061,20082]
name: task_adoption_timeout [20067,20088]
===
match
---
atom_expr [17684,17697]
atom_expr [17684,17697]
===
match
---
string: ": %s\n%s\n" [11137,11149]
string: ": %s\n%s\n" [11137,11149]
===
match
---
name: items [15688,15693]
name: items [15688,15693]
===
match
---
trailer [6034,6036]
trailer [6034,6036]
===
match
---
trailer [11390,11395]
trailer [11390,11395]
===
match
---
trailer [25361,25388]
trailer [25363,25390]
===
match
---
name: order_queued_tasks_by_priority [9123,9153]
name: order_queued_tasks_by_priority [9123,9153]
===
match
---
arglist [20386,20478]
arglist [20392,20484]
===
match
---
operator: , [24375,24376]
operator: , [24377,24378]
===
match
---
simple_stmt [2801,2889]
simple_stmt [2801,2889]
===
match
---
name: backend [9964,9971]
name: backend [9964,9971]
===
match
---
name: send_task_to_executor [5533,5554]
name: send_task_to_executor [5533,5554]
===
match
---
name: debug [13263,13268]
name: debug [13263,13268]
===
match
---
name: _execute_in_fork [3225,3241]
name: _execute_in_fork [3225,3241]
===
match
---
name: dispose [3700,3707]
name: dispose [3700,3707]
===
match
---
operator: , [19555,19556]
operator: , [19560,19561]
===
match
---
string: """Updates states of the tasks.""" [15764,15798]
string: """Updates states of the tasks.""" [15764,15798]
===
match
---
operator: , [5724,5725]
operator: , [5724,5725]
===
match
---
parameters [17869,17875]
parameters [17869,17875]
===
match
---
name: task_publish_retries [9554,9574]
name: task_publish_retries [9554,9574]
===
match
---
with_stmt [21147,21472]
with_stmt [21153,21478]
===
match
---
name: TaskInstance [1979,1991]
name: TaskInstance [1979,1991]
===
match
---
expr_stmt [13016,13148]
expr_stmt [13016,13148]
===
match
---
if_stmt [13990,14163]
if_stmt [13990,14163]
===
match
---
name: task_tuples_to_send [12061,12080]
name: task_tuples_to_send [12061,12080]
===
match
---
name: math [980,984]
name: math [980,984]
===
match
---
name: states_and_info_by_task_id [25319,25345]
name: states_and_info_by_task_id [25321,25347]
===
match
---
name: check_output [4471,4483]
name: check_output [4471,4483]
===
match
---
trailer [7386,7395]
trailer [7386,7395]
===
match
---
operator: += [10841,10843]
operator: += [10841,10843]
===
match
---
name: app [22529,22532]
name: app [22548,22551]
===
match
---
simple_stmt [24544,24574]
simple_stmt [24546,24576]
===
match
---
name: key [16226,16229]
name: key [16226,16229]
===
match
---
operator: , [22370,22371]
operator: , [22389,22390]
===
match
---
name: key [9575,9578]
name: key [9575,9578]
===
match
---
name: self [24868,24872]
name: self [24870,24874]
===
match
---
trailer [16075,16077]
trailer [16075,16077]
===
match
---
simple_stmt [1467,1534]
simple_stmt [1467,1534]
===
match
---
dotted_name [1832,1863]
dotted_name [1832,1863]
===
match
---
atom_expr [7806,7817]
atom_expr [7806,7817]
===
match
---
funcdef [17895,20525]
funcdef [17895,20531]
===
match
---
trailer [10398,10403]
trailer [10398,10403]
===
match
---
import_from [2221,2262]
import_from [2221,2262]
===
match
---
atom_expr [16666,16689]
atom_expr [16666,16689]
===
match
---
operator: = [8309,8310]
operator: = [8309,8310]
===
match
---
trailer [9633,9648]
trailer [9633,9648]
===
match
---
suite [22270,22348]
suite [22176,22254]
===
match
---
name: subprocess [4460,4470]
name: subprocess [4460,4470]
===
match
---
atom_expr [10317,10342]
atom_expr [10317,10342]
===
match
---
trailer [10075,10094]
trailer [10075,10094]
===
match
---
name: env [4370,4373]
name: env [4370,4373]
===
match
---
comparison [12057,12086]
comparison [12057,12086]
===
match
---
trailer [15384,15389]
trailer [15384,15389]
===
match
---
arglist [2710,2743]
arglist [2710,2743]
===
match
---
operator: , [22540,22541]
operator: , [22559,22560]
===
match
---
name: tasks [13235,13240]
name: tasks [13235,13240]
===
match
---
trailer [15956,15962]
trailer [15956,15962]
===
match
---
name: e [4645,4646]
name: e [4645,4646]
===
match
---
name: seconds [21160,21167]
name: seconds [21166,21173]
===
match
---
atom_expr [11771,11785]
atom_expr [11771,11785]
===
match
---
name: getattr [23730,23737]
name: getattr [23732,23739]
===
match
---
operator: , [9319,9320]
operator: , [9319,9320]
===
match
---
trailer [11890,11908]
trailer [11890,11908]
===
match
---
suite [23809,23899]
suite [23811,23901]
===
match
---
number: 0 [3449,3450]
number: 0 [3449,3450]
===
match
---
name: state [17400,17405]
name: state [17400,17405]
===
match
---
name: ti [20246,20248]
name: ti [20252,20254]
===
match
---
name: fork [3334,3338]
name: fork [3334,3338]
===
match
---
file_input [787,25966]
file_input [787,25968]
===
match
---
operator: , [1806,1807]
operator: , [1806,1807]
===
match
---
name: EventBufferValueType [24377,24397]
name: EventBufferValueType [24379,24399]
===
match
---
expr_stmt [19781,19822]
expr_stmt [19787,19828]
===
match
---
trailer [9460,9467]
trailer [9460,9467]
===
match
---
name: seconds [8168,8175]
name: seconds [8168,8175]
===
match
---
expr_stmt [25861,25923]
expr_stmt [25863,25925]
===
match
---
trailer [7835,7854]
trailer [7835,7854]
===
match
---
string: """         Overwrite trigger_tasks function from BaseExecutor          :param open_slots: Number of open slots         :return:         """ [8954,9094]
string: """         Overwrite trigger_tasks function from BaseExecutor          :param open_slots: Number of open slots         :return:         """ [8954,9094]
===
match
---
param [24868,24873]
param [24870,24875]
===
match
---
name: _exit [4251,4256]
name: _exit [4251,4256]
===
match
---
name: info [3047,3051]
name: info [3047,3051]
===
match
---
name: log [10066,10069]
name: log [10066,10069]
===
match
---
operator: , [10737,10738]
operator: , [10737,10738]
===
match
---
arglist [2491,2534]
arglist [2491,2534]
===
match
---
name: task_publish_retries [10374,10394]
name: task_publish_retries [10374,10394]
===
match
---
trailer [24899,24926]
trailer [24901,24928]
===
match
---
name: self [11886,11890]
name: self [11886,11890]
===
match
---
trailer [22949,22964]
trailer [22941,22956]
===
match
---
operator: = [4762,4763]
operator: = [4762,4763]
===
match
---
operator: , [16097,16098]
operator: , [16097,16098]
===
match
---
operator: , [8537,8538]
operator: , [8537,8538]
===
match
---
simple_stmt [1720,1759]
simple_stmt [1720,1759]
===
match
---
trailer [13258,13262]
trailer [13258,13262]
===
match
---
trailer [13053,13148]
trailer [13053,13148]
===
match
---
name: env [4543,4546]
name: env [4543,4546]
===
match
---
name: list [12213,12217]
name: list [12213,12217]
===
match
---
trailer [16063,16069]
trailer [16063,16069]
===
match
---
name: event_buffer [11736,11748]
name: event_buffer [11736,11748]
===
match
---
atom_expr [9441,9479]
atom_expr [9441,9479]
===
match
---
operator: , [5592,5593]
operator: , [5592,5593]
===
match
---
simple_stmt [23145,23204]
simple_stmt [23142,23201]
===
match
---
name: Mapping [1174,1181]
name: Mapping [1174,1181]
===
match
---
trailer [15185,15190]
trailer [15185,15190]
===
match
---
trailer [11175,11185]
trailer [11175,11185]
===
match
---
atom_expr [20002,20036]
atom_expr [20008,20042]
===
match
---
trailer [17500,17503]
trailer [17500,17503]
===
match
---
name: ResultSession [23695,23708]
name: ResultSession [23697,23710]
===
match
---
trailer [11735,11748]
trailer [11735,11748]
===
match
---
trailer [8479,8562]
trailer [8479,8562]
===
match
---
simple_stmt [21418,21472]
simple_stmt [21424,21478]
===
match
---
name: items [16070,16075]
name: items [16070,16075]
===
match
---
simple_stmt [1138,1227]
simple_stmt [1138,1227]
===
match
---
name: async_tasks [23652,23663]
name: async_tasks [23654,23665]
===
match
---
atom_expr [15661,15695]
atom_expr [15661,15695]
===
match
---
trailer [9190,9212]
trailer [9190,9212]
===
match
---
operator: , [25523,25524]
operator: , [25525,25526]
===
match
---
suite [3320,4298]
suite [3320,4298]
===
match
---
simple_stmt [3901,3932]
simple_stmt [3901,3932]
===
match
---
trailer [22620,22635]
trailer [22639,22654]
===
match
---
name: incr [10482,10486]
name: incr [10482,10486]
===
match
---
name: exception_traceback [5284,5303]
name: exception_traceback [5284,5303]
===
match
---
suite [12577,12919]
suite [12577,12919]
===
match
---
parameters [13199,13205]
parameters [13199,13205]
===
match
---
trailer [15514,15518]
trailer [15514,15518]
===
match
---
name: task_id [21438,21445]
name: task_id [21444,21451]
===
match
---
name: self [20056,20060]
name: self [20062,20066]
===
match
---
trailer [5796,5823]
trailer [5796,5823]
===
match
---
suite [4189,4298]
suite [4189,4298]
===
match
---
import_from [1058,1093]
import_from [1058,1093]
===
match
---
name: self [20095,20099]
name: self [20101,20105]
===
match
---
operator: = [19093,19094]
operator: = [19093,19094]
===
match
---
name: result [22981,22987]
name: result [22973,22979]
===
match
---
try_stmt [3611,4298]
try_stmt [3611,4298]
===
match
---
operator: = [24461,24462]
operator: = [24463,24464]
===
match
---
arglist [15465,15489]
arglist [15465,15489]
===
match
---
atom_expr [11374,11395]
atom_expr [11374,11395]
===
match
---
name: signal [12887,12893]
name: signal [12887,12893]
===
match
---
subscriptlist [8047,8081]
subscriptlist [8047,8081]
===
match
---
name: pop [10905,10908]
name: pop [10905,10908]
===
match
---
simple_stmt [19219,19302]
simple_stmt [19219,19302]
===
match
---
name: signals [1479,1486]
name: signals [1479,1486]
===
match
---
parameters [24248,24297]
parameters [24250,24299]
===
match
---
name: task_ids [24258,24266]
name: task_ids [24260,24268]
===
match
---
trailer [23837,23843]
trailer [23839,23845]
===
match
---
tfpdef [17630,17650]
tfpdef [17630,17650]
===
match
---
operator: , [25083,25084]
operator: , [25085,25086]
===
match
---
param [16512,16523]
param [16512,16523]
===
match
---
trailer [17962,17976]
trailer [17962,17976]
===
match
---
name: base [1306,1310]
name: base [1306,1310]
===
match
---
simple_stmt [23908,23989]
simple_stmt [23910,23991]
===
match
---
name: state [20203,20208]
name: state [20209,20214]
===
match
---
operator: = [24550,24551]
operator: = [24552,24553]
===
match
---
trailer [15005,15039]
trailer [15005,15039]
===
match
---
name: timedout_keys [13889,13902]
name: timedout_keys [13889,13902]
===
match
---
if_stmt [24512,24755]
if_stmt [24514,24757]
===
match
---
if_stmt [25491,25924]
if_stmt [25493,25926]
===
match
---
suite [16763,16801]
suite [16763,16801]
===
match
---
string: '\n\t' [20322,20328]
string: '\n\t' [20328,20334]
===
match
---
name: _execute_in_fork [3265,3281]
name: _execute_in_fork [3265,3281]
===
match
---
name: SimpleTaskInstance [5473,5491]
name: SimpleTaskInstance [5473,5491]
===
match
---
name: key [14735,14738]
name: key [14735,14738]
===
match
---
expr_stmt [3325,3340]
expr_stmt [3325,3340]
===
match
---
name: execute_async [17533,17546]
name: execute_async [17533,17546]
===
match
---
trailer [17807,17850]
trailer [17807,17850]
===
match
---
expr_stmt [21338,21405]
expr_stmt [21344,21411]
===
match
---
trailer [4204,4210]
trailer [4204,4210]
===
match
---
tfpdef [8606,8624]
tfpdef [8606,8624]
===
match
---
name: external_executor_id [19169,19189]
name: external_executor_id [19169,19189]
===
match
---
name: self [22590,22594]
name: self [22609,22613]
===
match
---
try_stmt [5771,6103]
try_stmt [5771,6103]
===
match
---
name: STDOUT [4519,4525]
name: STDOUT [4519,4525]
===
match
---
name: self [5267,5271]
name: self [5267,5271]
===
match
---
name: self [25133,25137]
name: self [25135,25139]
===
match
---
trailer [23927,23935]
trailer [23929,23937]
===
match
---
name: key [10678,10681]
name: key [10678,10681]
===
match
---
dotted_name [6691,6705]
dotted_name [6691,6705]
===
match
---
classdef [6955,20525]
classdef [6955,20531]
===
match
---
trailer [11920,11926]
trailer [11920,11926]
===
match
---
operator: = [4546,4547]
operator: = [4546,4547]
===
match
---
return_stmt [21629,21710]
return_stmt [21635,21716]
===
match
---
simple_stmt [20302,20343]
simple_stmt [20308,20349]
===
match
---
operator: , [16292,16293]
operator: , [16292,16293]
===
match
---
name: airflow [1725,1732]
name: airflow [1725,1732]
===
match
---
simple_stmt [2755,2800]
simple_stmt [2755,2800]
===
match
---
atom_expr [20029,20035]
atom_expr [20035,20041]
===
match
---
expr_stmt [24544,24573]
expr_stmt [24546,24575]
===
match
---
name: args [4010,4014]
name: args [4010,4014]
===
match
---
name: format_exc [21606,21616]
name: format_exc [21612,21622]
===
match
---
import_as_names [1959,2008]
import_as_names [1959,2008]
===
match
---
simple_stmt [15171,15191]
simple_stmt [15171,15191]
===
match
---
param [8442,8446]
param [8442,8446]
===
match
---
atom_expr [25201,25305]
atom_expr [25203,25307]
===
match
---
with_item [25012,25052]
with_item [25014,25054]
===
match
---
name: _sync_parallelism [7779,7796]
name: _sync_parallelism [7779,7796]
===
match
---
name: str [24372,24375]
name: str [24374,24377]
===
match
---
atom_expr [20195,20201]
atom_expr [20201,20207]
===
match
---
arglist [10175,10205]
arglist [10175,10205]
===
match
---
except_clause [4046,4067]
except_clause [4046,4067]
===
match
---
operator: , [15147,15148]
operator: , [15147,15148]
===
match
---
trailer [20176,20194]
trailer [20182,20200]
===
match
---
atom_expr [9258,9280]
atom_expr [9258,9280]
===
match
---
arglist [12829,12859]
arglist [12829,12859]
===
match
---
name: get [24487,24490]
name: get [24489,24492]
===
match
---
name: subdag [6805,6811]
name: subdag [6805,6811]
===
match
---
trailer [4237,4239]
trailer [4237,4239]
===
match
---
operator: , [16522,16523]
operator: , [16522,16523]
===
match
---
operator: = [19642,19643]
operator: = [19648,19649]
===
match
---
string: 'info' [11944,11950]
string: 'info' [11944,11950]
===
match
---
name: key [10909,10912]
name: key [10909,10912]
===
match
---
operator: , [3085,3086]
operator: , [3085,3086]
===
match
---
atom_expr [15471,15489]
atom_expr [15471,15489]
===
match
---
arglist [22684,22712]
arglist [22679,22707]
===
match
---
return_stmt [25932,25965]
return_stmt [25934,25967]
===
match
---
name: task [2896,2900]
name: task [2896,2900]
===
match
---
return_stmt [21771,21810]
return_stmt [22327,22366]
===
match
---
operator: , [10111,10112]
operator: , [10111,10112]
===
match
---
number: 1 [7820,7821]
number: 1 [7820,7821]
===
match
---
operator: , [1977,1978]
operator: , [1977,1978]
===
match
---
atom [19609,19611]
atom [19615,19617]
===
match
---
name: self [25570,25574]
name: self [25572,25576]
===
match
---
operator: -> [8626,8628]
operator: -> [8626,8628]
===
match
---
name: task_results [24079,24091]
name: task_results [24081,24093]
===
match
---
trailer [16225,16243]
trailer [16225,16243]
===
match
---
operator: = [3852,3853]
operator: = [3852,3853]
===
match
---
trailer [3887,3891]
trailer [3887,3891]
===
match
---
name: AsyncResult [1455,1466]
name: AsyncResult [1455,1466]
===
match
---
atom_expr [8255,8280]
atom_expr [8255,8280]
===
match
---
name: output [4742,4748]
name: output [4742,4748]
===
match
---
name: debug [22894,22899]
name: debug [22881,22886]
===
match
---
simple_stmt [10476,10516]
simple_stmt [10476,10516]
===
match
---
expr_stmt [24449,24499]
expr_stmt [24451,24501]
===
match
---
operator: , [22931,22932]
operator: , [22923,22924]
===
match
---
string: "No Async execution for Celery executor." [17808,17849]
string: "No Async execution for Celery executor." [17808,17849]
===
match
---
trailer [24035,24046]
trailer [24037,24048]
===
match
---
comp_op [19190,19196]
comp_op [19190,19196]
===
match
---
simple_stmt [19336,19363]
simple_stmt [19336,19363]
===
match
---
name: taskinstance [1939,1951]
name: taskinstance [1939,1951]
===
match
---
testlist_star_expr [25899,25923]
testlist_star_expr [25901,25925]
===
match
---
simple_stmt [25172,25306]
simple_stmt [25174,25308]
===
match
---
atom_expr [19644,19688]
atom_expr [19650,19694]
===
match
---
name: Dict [8282,8286]
name: Dict [8282,8286]
===
match
---
name: v [23294,23295]
name: v [23291,23292]
===
match
---
simple_stmt [17224,17294]
simple_stmt [17224,17294]
===
match
---
subscriptlist [25362,25387]
subscriptlist [25364,25389]
===
match
---
simple_stmt [19436,19447]
simple_stmt [19436,19447]
===
match
---
param [22247,22268]
param [22153,22174]
===
match
---
term [25106,25155]
term [25108,25157]
===
match
---
subscriptlist [8287,8307]
subscriptlist [8287,8307]
===
match
---
atom_expr [19835,19849]
atom_expr [19841,19855]
===
match
---
arglist [24150,24183]
arglist [24152,24185]
===
match
---
name: task_publish_retries [10322,10342]
name: task_publish_retries [10322,10342]
===
match
---
trailer [24490,24499]
trailer [24492,24501]
===
match
---
name: airflow [6652,6659]
name: airflow [6652,6659]
===
match
---
name: celery_states [1271,1284]
name: celery_states [1271,1284]
===
match
---
subscriptlist [5641,5676]
subscriptlist [5641,5676]
===
match
---
atom_expr [25078,25158]
atom_expr [25080,25160]
===
match
---
simple_stmt [9165,9218]
simple_stmt [9165,9218]
===
match
---
suite [5957,6103]
suite [5957,6103]
===
match
---
trailer [20151,20159]
trailer [20157,20165]
===
match
---
atom_expr [12017,12043]
atom_expr [12017,12043]
===
match
---
operator: == [3446,3448]
operator: == [3446,3448]
===
match
---
testlist_comp [23924,23987]
testlist_comp [23926,23989]
===
match
---
name: processes [12938,12947]
name: processes [12938,12947]
===
match
---
operator: { [24401,24402]
operator: { [24403,24404]
===
match
---
simple_stmt [16381,16407]
simple_stmt [16381,16407]
===
match
---
name: values [23306,23312]
name: values [23303,23309]
===
match
---
name: collections [1063,1074]
name: collections [1063,1074]
===
match
---
number: 1 [9582,9583]
number: 1 [9582,9583]
===
match
---
name: OrderedDict [1082,1093]
name: OrderedDict [1082,1093]
===
match
---
arglist [8377,8425]
arglist [8377,8425]
===
match
---
string: 'Error fetching Celery task state' [2363,2397]
string: 'Error fetching Celery task state' [2363,2397]
===
match
---
atom_expr [16627,16648]
atom_expr [16627,16648]
===
match
---
simple_stmt [20502,20525]
simple_stmt [20508,20531]
===
match
---
name: log [15515,15518]
name: log [15515,15518]
===
match
---
operator: , [14976,14977]
operator: , [14976,14977]
===
match
---
suite [21766,21811]
suite [22318,22367]
===
match
---
suite [16079,16244]
suite [16079,16244]
===
match
---
trailer [16354,16372]
trailer [16354,16372]
===
match
---
name: logging_mixin [2064,2077]
name: logging_mixin [2064,2077]
===
match
---
operator: = [23098,23099]
operator: = [23090,23091]
===
match
---
trailer [15464,15490]
trailer [15464,15490]
===
match
---
trailer [17242,17293]
trailer [17242,17293]
===
match
---
operator: = [9213,9214]
operator: = [9213,9214]
===
match
---
if_stmt [10307,10875]
if_stmt [10307,10875]
===
match
---
name: key [9296,9299]
name: key [9296,9299]
===
match
---
name: connect [6193,6200]
name: connect [6193,6200]
===
match
---
operator: , [4541,4542]
operator: , [4541,4542]
===
match
---
trailer [11237,11242]
trailer [11237,11242]
===
match
---
name: queued_dttm [20042,20053]
name: queued_dttm [20048,20059]
===
match
---
name: celery_tasks [19654,19666]
name: celery_tasks [19660,19672]
===
match
---
atom_expr [20322,20342]
atom_expr [20328,20348]
===
match
---
atom_expr [4376,4393]
atom_expr [4376,4393]
===
match
---
trailer [10677,10682]
trailer [10677,10682]
===
match
---
name: sync [17517,17521]
name: sync [17517,17521]
===
match
---
name: command_to_exec [3022,3037]
name: command_to_exec [3022,3037]
===
match
---
name: utils [2054,2059]
name: utils [2054,2059]
===
match
---
name: timezone [2240,2248]
name: timezone [2240,2248]
===
match
---
name: airflow [3565,3572]
name: airflow [3565,3572]
===
match
---
sync_comp_for [9789,9817]
sync_comp_for [9789,9817]
===
match
---
name: repr [15465,15469]
name: repr [15465,15469]
===
match
---
arglist [12938,12988]
arglist [12938,12988]
===
match
---
suite [24680,24755]
suite [24682,24757]
===
match
---
name: _num_tasks_per_send_process [8572,8599]
name: _num_tasks_per_send_process [8572,8599]
===
match
---
name: OPERATION_TIMEOUT [2457,2474]
name: OPERATION_TIMEOUT [2457,2474]
===
match
---
simple_stmt [5837,5899]
simple_stmt [5837,5899]
===
match
---
name: task_to_run [5846,5857]
name: task_to_run [5846,5857]
===
match
---
name: ti [20029,20031]
name: ti [20035,20037]
===
match
---
operator: = [23921,23922]
operator: = [23923,23924]
===
match
---
expr_stmt [16092,16164]
expr_stmt [16092,16164]
===
match
---
atom_expr [11319,11333]
atom_expr [11319,11333]
===
match
---
operator: , [21386,21387]
operator: , [21392,21393]
===
match
---
name: celery_states [16717,16730]
name: celery_states [16717,16730]
===
match
---
expr_stmt [20002,20082]
expr_stmt [20008,20088]
===
match
---
try_stmt [4398,4851]
try_stmt [4398,4851]
===
match
---
name: msg [4758,4761]
name: msg [4758,4761]
===
match
---
import_from [2041,2097]
import_from [2041,2097]
===
match
---
comp_op [11290,11296]
comp_op [11290,11296]
===
match
---
name: settings [1637,1645]
name: settings [1637,1645]
===
match
---
operator: , [1896,1897]
operator: , [1896,1897]
===
match
---
arglist [25646,25796]
arglist [25648,25798]
===
match
---
operator: } [19096,19097]
operator: } [19096,19097]
===
match
---
name: ExceptionWithTraceback [10183,10205]
name: ExceptionWithTraceback [10183,10205]
===
match
---
dotted_name [6584,6594]
dotted_name [6584,6594]
===
match
---
trailer [25081,25158]
trailer [25083,25160]
===
match
---
name: info [15385,15389]
name: info [15385,15389]
===
match
---
trailer [15665,15687]
trailer [15665,15687]
===
match
---
name: self [7906,7910]
name: self [7906,7910]
===
match
---
param [16266,16271]
param [16266,16271]
===
match
---
trailer [10481,10486]
trailer [10481,10486]
===
match
---
expr_stmt [13865,13879]
expr_stmt [13865,13879]
===
match
---
operator: , [17590,17591]
operator: , [17590,17591]
===
match
---
name: log [22890,22893]
name: log [22877,22880]
===
match
---
name: adopted_task_timeouts [15603,15624]
name: adopted_task_timeouts [15603,15624]
===
match
---
name: self [15175,15179]
name: self [15175,15179]
===
match
---
operator: , [14932,14933]
operator: , [14932,14933]
===
match
---
atom_expr [5506,5519]
atom_expr [5506,5519]
===
match
---
suite [20637,21711]
suite [20643,21717]
===
match
---
name: celery_states [16827,16840]
name: celery_states [16827,16840]
===
match
---
simple_stmt [985,1001]
simple_stmt [985,1001]
===
match
---
trailer [7395,7397]
trailer [7395,7397]
===
match
---
trailer [4470,4483]
trailer [4470,4483]
===
match
---
operator: , [4499,4500]
operator: , [4499,4500]
===
match
---
trailer [8337,8362]
trailer [8337,8362]
===
match
---
tfpdef [5197,5221]
tfpdef [5197,5221]
===
match
---
dotted_name [1348,1372]
dotted_name [1348,1372]
===
match
---
arglist [17106,17147]
arglist [17106,17147]
===
match
---
funcdef [15248,15709]
funcdef [15248,15709]
===
match
---
name: repr [15007,15011]
name: repr [15007,15011]
===
match
---
simple_stmt [23432,23516]
simple_stmt [23429,23513]
===
match
---
name: async_result [21425,21437]
name: async_result [21431,21443]
===
match
---
parameters [16483,16534]
parameters [16483,16534]
===
match
---
operator: -> [20582,20584]
operator: -> [20588,20590]
===
match
---
parameters [22365,22386]
parameters [22384,22405]
===
match
---
operator: , [21445,21446]
operator: , [21451,21452]
===
match
---
name: async_result [21636,21648]
name: async_result [21642,21654]
===
match
---
name: traceback [1048,1057]
name: traceback [1048,1057]
===
match
---
trailer [22766,22781]
trailer [22761,22776]
===
match
---
operator: , [15430,15431]
operator: , [15430,15431]
===
match
---
import_name [1041,1057]
import_name [1041,1057]
===
match
---
atom_expr [12845,12859]
atom_expr [12845,12859]
===
match
---
name: e [4066,4067]
name: e [4066,4067]
===
match
---
trailer [15523,15708]
trailer [15523,15708]
===
match
---
name: EventBufferValueType [24905,24925]
name: EventBufferValueType [24907,24927]
===
match
---
funcdef [8568,8891]
funcdef [8568,8891]
===
match
---
name: self [14779,14783]
name: self [14779,14783]
===
match
---
name: len [15432,15435]
name: len [15432,15435]
===
match
---
atom_expr [8282,8308]
atom_expr [8282,8308]
===
match
---
expr_stmt [4370,4393]
expr_stmt [4370,4393]
===
match
---
simple_stmt [1759,1827]
simple_stmt [1759,1827]
===
match
---
arglist [8188,8235]
arglist [8188,8235]
===
match
---
expr_stmt [2801,2888]
expr_stmt [2801,2888]
===
match
---
operator: , [7700,7701]
operator: , [7700,7701]
===
match
---
name: async_tasks [21798,21809]
name: async_tasks [22354,22365]
===
match
---
operator: -> [23570,23572]
operator: -> [23567,23569]
===
match
---
name: Mapping [24301,24308]
name: Mapping [24303,24310]
===
match
---
simple_stmt [7655,7722]
simple_stmt [7655,7722]
===
match
---
comparison [10310,10342]
comparison [10310,10342]
===
match
---
atom_expr [17490,17503]
atom_expr [17490,17503]
===
match
---
atom_expr [24705,24726]
atom_expr [24707,24728]
===
match
---
name: async_results [22621,22634]
name: async_results [22640,22653]
===
match
---
name: State [11246,11251]
name: State [11246,11251]
===
match
---
name: command [5726,5733]
name: command [5726,5733]
===
match
---
expr_stmt [4034,4041]
expr_stmt [4034,4041]
===
match
---
name: net [2117,2120]
name: net [2117,2120]
===
match
---
name: cached_celery_backend [11336,11357]
name: cached_celery_backend [11336,11357]
===
match
---
name: task [23954,23958]
name: task [23956,23960]
===
match
---
expr_stmt [5427,5526]
expr_stmt [5427,5526]
===
match
---
string: 'celery' [7692,7700]
string: 'celery' [7692,7700]
===
match
---
arglist [2632,2665]
arglist [2632,2665]
===
match
---
trailer [21605,21616]
trailer [21611,21622]
===
match
---
name: state [24544,24549]
name: state [24546,24551]
===
match
---
operator: , [24972,24973]
operator: , [24974,24975]
===
match
---
name: task_result [23354,23365]
name: task_result [23351,23362]
===
match
---
name: _send_tasks_to_celery [10010,10031]
name: _send_tasks_to_celery [10010,10031]
===
match
---
atom_expr [3854,3892]
atom_expr [3854,3892]
===
match
---
arglist [10987,11017]
arglist [10987,11017]
===
match
---
name: running [11379,11386]
name: running [11379,11386]
===
match
---
name: airflow [1832,1839]
name: airflow [1832,1839]
===
match
---
test [24597,24662]
test [24599,24664]
===
match
---
suite [19768,20269]
suite [19774,20275]
===
match
---
trailer [17692,17697]
trailer [17692,17697]
===
match
---
name: max [8822,8825]
name: max [8822,8825]
===
match
---
name: self [10407,10411]
name: self [10407,10411]
===
match
---
testlist_comp [23153,23202]
testlist_comp [23150,23199]
===
match
---
operator: * [8847,8848]
operator: * [8847,8848]
===
match
---
atom_expr [12494,12547]
atom_expr [12494,12547]
===
match
---
name: num_process [25027,25038]
name: num_process [25029,25040]
===
match
---
name: get [16139,16142]
name: get [16139,16142]
===
match
---
and_test [10164,10289]
and_test [10164,10289]
===
match
---
trailer [10544,10549]
trailer [10544,10549]
===
match
---
name: getattr [11928,11935]
name: getattr [11928,11935]
===
match
---
import_from [1534,1571]
import_from [1534,1571]
===
match
---
trailer [20450,20459]
trailer [20456,20465]
===
match
---
operator: = [24787,24788]
operator: = [24789,24790]
===
match
---
name: num_process [24936,24947]
name: num_process [24938,24949]
===
match
---
name: celery_states [17014,17027]
name: celery_states [17014,17027]
===
match
---
atom_expr [22279,22297]
atom_expr [22185,22203]
===
match
---
name: List [12017,12021]
name: List [12017,12021]
===
match
---
atom_expr [24108,24184]
atom_expr [24110,24186]
===
match
---
name: key [17137,17140]
name: key [17137,17140]
===
match
---
name: state [16180,16185]
name: state [16180,16185]
===
match
---
import_from [1646,1719]
import_from [1646,1719]
===
match
---
simple_stmt [3599,3607]
simple_stmt [3599,3607]
===
match
---
name: log [11041,11044]
name: log [11041,11044]
===
match
---
dotted_name [1764,1782]
dotted_name [1764,1782]
===
match
---
trailer [11386,11390]
trailer [11386,11390]
===
match
---
parameters [3281,3311]
parameters [3281,3311]
===
match
---
trailer [22861,22876]
trailer [22848,22863]
===
match
---
operator: <= [10404,10406]
operator: <= [10404,10406]
===
match
---
simple_stmt [3941,4001]
simple_stmt [3941,4001]
===
match
---
trailer [10009,10031]
trailer [10009,10031]
===
match
---
atom_expr [24950,24997]
atom_expr [24952,24999]
===
match
---
expr_stmt [7831,7897]
expr_stmt [7831,7897]
===
match
---
string: """Gets status for many Celery tasks using the best method available.""" [22434,22506]
string: """Gets status for many Celery tasks using the best method available.""" [22453,22525]
===
match
---
name: cached_celery_backend [9929,9950]
name: cached_celery_backend [9929,9950]
===
match
---
raise_stmt [17785,17850]
raise_stmt [17785,17850]
===
match
---
testlist_comp [15007,15037]
testlist_comp [15007,15037]
===
match
---
trailer [17516,17521]
trailer [17516,17521]
===
match
---
atom_expr [16054,16078]
atom_expr [16054,16078]
===
match
---
expr_stmt [5966,6038]
expr_stmt [5966,6038]
===
match
---
import_from [3624,3669]
import_from [3624,3669]
===
match
---
name: key [20032,20035]
name: key [20038,20041]
===
match
---
trailer [8187,8236]
trailer [8187,8236]
===
match
---
trailer [14793,15054]
trailer [14793,15054]
===
match
---
atom_expr [3331,3340]
atom_expr [3331,3340]
===
match
---
atom_expr [8042,8082]
atom_expr [8042,8082]
===
match
---
name: Union [1221,1226]
name: Union [1221,1226]
===
match
---
arglist [8826,8889]
arglist [8826,8889]
===
match
---
name: tasks [17457,17462]
name: tasks [17457,17462]
===
match
---
atom_expr [4656,4721]
atom_expr [4656,4721]
===
match
---
trailer [4014,4019]
trailer [4014,4019]
===
match
---
trailer [25137,25155]
trailer [25139,25157]
===
match
---
name: signal [12829,12835]
name: signal [12829,12835]
===
match
---
trailer [3502,3554]
trailer [3502,3554]
===
match
---
simple_stmt [21629,21711]
simple_stmt [21635,21717]
===
match
---
if_stmt [3345,3555]
if_stmt [3345,3555]
===
match
---
for_stmt [25406,25924]
for_stmt [25408,25926]
===
match
---
operator: } [20248,20249]
operator: } [20254,20255]
===
match
---
operator: + [25674,25675]
operator: + [25676,25677]
===
match
---
name: self [20172,20176]
name: self [20178,20182]
===
match
---
expr_stmt [10810,10845]
expr_stmt [10810,10845]
===
match
---
name: backend [22688,22695]
name: backend [22683,22690]
===
match
---
name: result [10116,10122]
name: result [10116,10122]
===
match
---
trailer [12821,12828]
trailer [12821,12828]
===
match
---
name: log [13259,13262]
name: log [13259,13262]
===
match
---
operator: , [25741,25742]
operator: , [25743,25744]
===
match
---
name: simple_ti [9385,9394]
name: simple_ti [9385,9394]
===
match
---
suite [16849,16988]
suite [16849,16988]
===
match
---
trailer [19759,19765]
trailer [19765,19771]
===
match
---
trailer [15867,15873]
trailer [15867,15873]
===
match
---
except_clause [5903,5924]
except_clause [5903,5924]
===
match
---
atom_expr [19533,19555]
atom_expr [19538,19560]
===
match
---
if_stmt [3109,3259]
if_stmt [3109,3259]
===
match
---
name: values [23212,23218]
name: values [23209,23215]
===
match
---
name: info [16306,16310]
name: info [16306,16310]
===
match
---
simple_stmt [5427,5527]
simple_stmt [5427,5527]
===
match
---
operator: , [25437,25438]
operator: , [25439,25440]
===
match
---
trailer [8111,8133]
trailer [8111,8133]
===
match
---
name: join [15646,15650]
name: join [15646,15650]
===
match
---
exprlist [16033,16050]
exprlist [16033,16050]
===
match
---
funcdef [5529,6136]
funcdef [5529,6136]
===
match
---
operator: , [6080,6081]
operator: , [6080,6081]
===
match
---
expr_stmt [9981,10052]
expr_stmt [9981,10052]
===
match
---
trailer [24308,24335]
trailer [24310,24337]
===
match
---
string: "Inquiries completed." [15997,16019]
string: "Inquiries completed." [15997,16019]
===
match
---
name: filter [23854,23860]
name: filter [23856,23862]
===
match
---
name: str [21761,21764]
name: str [22313,22316]
===
match
---
operator: { [7919,7920]
operator: { [7919,7920]
===
match
---
trailer [20108,20112]
trailer [20114,20118]
===
match
---
name: __init__ [5160,5168]
name: __init__ [5160,5168]
===
match
---
name: app [2801,2804]
name: app [2801,2804]
===
match
---
simple_stmt [6684,6706]
simple_stmt [6684,6706]
===
match
---
name: key [10763,10766]
name: key [10763,10766]
===
match
---
simple_stmt [24809,24827]
simple_stmt [24811,24829]
===
match
---
number: 0 [3428,3429]
number: 0 [3428,3429]
===
match
---
name: subprocess [4508,4518]
name: subprocess [4508,4518]
===
match
---
dotted_name [2103,2120]
dotted_name [2103,2120]
===
match
---
name: task_id [24416,24423]
name: task_id [24418,24425]
===
match
---
atom_expr [10211,10289]
atom_expr [10211,10289]
===
match
---
number: 1 [25082,25083]
number: 1 [25084,25085]
===
match
---
name: task_tuples_to_send [9165,9184]
name: task_tuples_to_send [9165,9184]
===
match
---
name: result [22581,22587]
name: result [22600,22606]
===
match
---
operator: = [22823,22824]
operator: = [22810,22811]
===
match
---
trailer [21437,21445]
trailer [21443,21451]
===
match
---
suite [15092,15243]
suite [15092,15243]
===
match
---
operator: , [10766,10767]
operator: , [10766,10767]
===
match
---
trailer [12221,12265]
trailer [12221,12265]
===
match
---
operator: @ [24190,24191]
operator: @ [24192,24193]
===
match
---
operator: = [11428,11429]
operator: = [11428,11429]
===
match
---
name: self [10005,10009]
name: self [10005,10009]
===
match
---
trailer [15140,15147]
trailer [15140,15147]
===
match
---
name: values [19667,19673]
name: values [19673,19679]
===
match
---
atom_expr [24892,24926]
atom_expr [24894,24928]
===
match
---
name: _tasks_list_to_task_ids [23100,23123]
name: _tasks_list_to_task_ids [23097,23120]
===
match
---
name: key [10836,10839]
name: key [10836,10839]
===
match
---
name: int [8304,8307]
name: int [8304,8307]
===
match
---
trailer [11325,11333]
trailer [11325,11333]
===
match
---
suite [11302,11959]
suite [11302,11959]
===
match
---
atom_expr [23784,23808]
atom_expr [23786,23810]
===
match
---
name: ExceptionWithTraceback [6056,6078]
name: ExceptionWithTraceback [6056,6078]
===
match
---
trailer [10904,10908]
trailer [10904,10908]
===
match
---
operator: -> [21754,21756]
operator: -> [22306,22308]
===
match
---
name: synchronous [17360,17371]
name: synchronous [17360,17371]
===
match
---
return_stmt [23432,23515]
return_stmt [23429,23512]
===
match
---
and_test [10310,10454]
and_test [10310,10454]
===
match
---
name: result [11771,11777]
name: result [11771,11777]
===
match
---
atom_expr [10708,10737]
atom_expr [10708,10737]
===
match
---
operator: = [2776,2777]
operator: = [2776,2777]
===
match
---
name: self [17307,17311]
name: self [17307,17311]
===
match
---
name: ret [3599,3602]
name: ret [3599,3602]
===
match
---
name: session_cleanup [1413,1428]
name: session_cleanup [1413,1428]
===
match
---
atom_expr [11757,11769]
atom_expr [11757,11769]
===
match
---
name: CommandType [3299,3310]
name: CommandType [3299,3310]
===
match
---
exprlist [19702,19731]
exprlist [19708,19737]
===
match
---
name: log [8470,8473]
name: log [8470,8473]
===
match
---
trailer [19806,19822]
trailer [19812,19828]
===
match
---
atom_expr [14714,14739]
atom_expr [14714,14739]
===
match
---
raise_stmt [4823,4850]
raise_stmt [4823,4850]
===
match
---
name: log [17097,17100]
name: log [17097,17100]
===
match
---
param [16294,16305]
param [16294,16305]
===
match
---
testlist_star_expr [3401,3409]
testlist_star_expr [3401,3409]
===
match
---
expr_stmt [23252,23318]
expr_stmt [23249,23315]
===
match
---
simple_stmt [14157,14163]
simple_stmt [14157,14163]
===
match
---
name: int [8932,8935]
name: int [8932,8935]
===
match
---
operator: , [5471,5472]
operator: , [5471,5472]
===
match
---
atom_expr [12498,12522]
atom_expr [12498,12522]
===
match
---
atom_expr [5789,5823]
atom_expr [5789,5823]
===
match
---
expr_stmt [20095,20122]
expr_stmt [20101,20128]
===
match
---
trailer [15518,15523]
trailer [15518,15523]
===
match
---
name: ceil [8838,8842]
name: ceil [8838,8842]
===
match
---
atom_expr [12815,12860]
atom_expr [12815,12860]
===
match
---
trailer [15602,15624]
trailer [15602,15624]
===
match
---
arglist [15403,15491]
arglist [15403,15491]
===
match
---
operator: , [23749,23750]
operator: , [23751,23752]
===
match
---
atom_expr [24954,24972]
atom_expr [24956,24974]
===
match
---
if_stmt [7730,7823]
if_stmt [7730,7823]
===
match
---
name: task_adoption_timeout [14955,14976]
name: task_adoption_timeout [14955,14976]
===
match
---
atom_expr [19219,19256]
atom_expr [19219,19256]
===
match
---
tfpdef [4327,4355]
tfpdef [4327,4355]
===
match
---
simple_stmt [3847,3893]
simple_stmt [3847,3893]
===
match
---
trailer [9648,9669]
trailer [9648,9669]
===
match
---
atom_expr [23354,23376]
atom_expr [23351,23373]
===
match
---
atom_expr [21636,21656]
atom_expr [21642,21662]
===
match
---
name: map [13050,13053]
name: map [13050,13053]
===
match
---
operator: -> [13206,13208]
operator: -> [13206,13208]
===
match
---
trailer [24149,24184]
trailer [24151,24186]
===
match
---
trailer [19765,19767]
trailer [19771,19773]
===
match
---
name: signal [12903,12909]
name: signal [12903,12909]
===
match
---
number: 0 [9351,9352]
number: 0 [9351,9352]
===
match
---
operator: } [21809,21810]
operator: } [22365,22366]
===
match
---
name: self [15952,15956]
name: self [15952,15956]
===
match
---
comparison [10369,10436]
comparison [10369,10436]
===
match
---
import_from [2141,2178]
import_from [2141,2178]
===
match
---
trailer [15440,15446]
trailer [15440,15446]
===
match
---
operator: , [23761,23762]
operator: , [23763,23764]
===
match
---
name: exception_traceback [6082,6101]
name: exception_traceback [6082,6101]
===
match
---
trailer [7691,7721]
trailer [7691,7721]
===
match
---
operator: = [24399,24400]
operator: = [24401,24402]
===
match
---
name: _prepare_state_and_info_by_task_dict [23444,23480]
name: _prepare_state_and_info_by_task_dict [23441,23477]
===
match
---
operator: { [3981,3982]
operator: { [3981,3982]
===
match
---
name: signal [12873,12879]
name: signal [12873,12879]
===
match
---
param [17667,17705]
param [17667,17705]
===
match
---
name: timedout_keys [14714,14727]
name: timedout_keys [14714,14727]
===
match
---
operator: = [8423,8424]
operator: = [8423,8424]
===
match
---
simple_stmt [11374,11396]
simple_stmt [11374,11396]
===
match
---
trailer [23958,23966]
trailer [23960,23968]
===
match
---
simple_stmt [12478,12548]
simple_stmt [12478,12548]
===
match
---
operator: = [24948,24949]
operator: = [24950,24951]
===
match
---
trailer [9122,9153]
trailer [9122,9153]
===
match
---
simple_stmt [12206,12267]
simple_stmt [12206,12267]
===
match
---
atom_expr [12090,12112]
atom_expr [12090,12112]
===
match
---
suite [24527,24663]
suite [24529,24665]
===
match
---
name: self [15109,15113]
name: self [15109,15113]
===
match
---
trailer [24563,24573]
trailer [24565,24575]
===
match
---
subscriptlist [20602,20629]
subscriptlist [20608,20635]
===
match
---
parameters [7363,7369]
parameters [7363,7369]
===
match
---
string: 'SYNC_PARALLELISM' [7702,7720]
string: 'SYNC_PARALLELISM' [7702,7720]
===
match
---
atom_expr [23153,23184]
atom_expr [23150,23181]
===
match
---
name: k [23182,23183]
name: k [23179,23180]
===
match
---
import_from [1467,1533]
import_from [1467,1533]
===
match
---
trailer [13946,13968]
trailer [13946,13968]
===
match
---
name: has_option [2621,2631]
name: has_option [2621,2631]
===
match
---
operator: , [10626,10627]
operator: , [10626,10627]
===
match
---
name: decode_result [23280,23293]
name: decode_result [23277,23290]
===
match
---
string: 'celery' [8377,8385]
string: 'celery' [8377,8385]
===
match
---
string: "\n\t" [14994,15000]
string: "\n\t" [14994,15000]
===
match
---
funcdef [16249,16457]
funcdef [16249,16457]
===
match
---
name: task_tuple [9468,9478]
name: task_tuple [9468,9478]
===
match
---
name: task_tuple [9366,9376]
name: task_tuple [9366,9376]
===
match
---
import_name [973,984]
import_name [973,984]
===
match
---
string: 'execute_command encountered a CalledProcessError' [4670,4720]
string: 'execute_command encountered a CalledProcessError' [4670,4720]
===
match
---
simple_stmt [2264,2298]
simple_stmt [2264,2298]
===
match
---
operator: } [7920,7921]
operator: } [7920,7921]
===
match
---
argument [8168,8236]
argument [8168,8236]
===
match
---
parameters [17306,17339]
parameters [17306,17339]
===
match
---
return_stmt [8815,8890]
return_stmt [8815,8890]
===
match
---
trailer [23708,23710]
trailer [23710,23712]
===
match
---
simple_stmt [9766,9819]
simple_stmt [9766,9819]
===
match
---
operator: { [6006,6007]
operator: { [6006,6007]
===
match
---
operator: , [1197,1198]
operator: , [1197,1198]
===
match
---
atom_expr [8176,8236]
atom_expr [8176,8236]
===
match
---
operator: -> [24298,24300]
operator: -> [24300,24302]
===
match
---
simple_stmt [22816,22877]
simple_stmt [22803,22864]
===
match
---
trailer [15951,15972]
trailer [15951,15972]
===
match
---
name: super [15347,15352]
name: super [15347,15352]
===
match
---
name: self [11412,11416]
name: self [11412,11416]
===
match
---
arglist [6079,6101]
arglist [6079,6101]
===
match
---
simple_stmt [13157,13186]
simple_stmt [13157,13186]
===
match
---
suite [17473,17504]
suite [17473,17504]
===
match
---
name: min [12494,12497]
name: min [12494,12497]
===
match
---
trailer [23181,23184]
trailer [23178,23181]
===
match
---
param [13200,13204]
param [13200,13204]
===
match
---
trailer [22899,22965]
trailer [22886,22957]
===
match
---
name: adopted [20451,20458]
name: adopted [20457,20464]
===
match
---
trailer [15455,15460]
trailer [15455,15460]
===
match
---
name: adopted [20334,20341]
name: adopted [20340,20347]
===
match
---
trailer [15365,15367]
trailer [15365,15367]
===
match
---
fstring_expr [6006,6011]
fstring_expr [6006,6011]
===
match
---
testlist [21425,21471]
testlist [21431,21477]
===
match
---
atom_expr [8136,8246]
atom_expr [8136,8246]
===
match
---
dotted_name [1725,1746]
dotted_name [1725,1746]
===
match
---
simple_stmt [16552,16590]
simple_stmt [16552,16590]
===
match
---
simple_stmt [20172,20216]
simple_stmt [20178,20222]
===
match
---
operator: -> [24889,24891]
operator: -> [24891,24893]
===
match
---
name: task_instance_str [20302,20319]
name: task_instance_str [20308,20325]
===
match
---
atom_expr [12444,12468]
atom_expr [12444,12468]
===
match
---
name: fail [16785,16789]
name: fail [16785,16789]
===
match
---
name: state [20260,20265]
name: state [20266,20271]
===
match
---
name: celery_import_modules [1512,1533]
name: celery_import_modules [1512,1533]
===
match
---
string: 'celery_config_options' [2720,2743]
string: 'celery_config_options' [2720,2743]
===
match
---
expr_stmt [7906,7921]
expr_stmt [7906,7921]
===
match
---
suite [13977,14740]
suite [13977,14740]
===
match
---
name: celery_states [17413,17426]
name: celery_states [17413,17426]
===
match
---
name: setproctitle [1539,1551]
name: setproctitle [1539,1551]
===
match
---
sync_comp_for [15015,15037]
sync_comp_for [15015,15037]
===
match
---
simple_stmt [2964,2988]
simple_stmt [2964,2988]
===
match
---
operator: } [3997,3998]
operator: } [3997,3998]
===
match
---
simple_stmt [1919,2009]
simple_stmt [1919,2009]
===
match
---
operator: , [10993,10994]
operator: , [10993,10994]
===
match
---
suite [6906,6920]
suite [6906,6920]
===
match
---
suite [9532,9584]
suite [9532,9584]
===
match
---
operator: , [10255,10256]
operator: , [10255,10256]
===
match
---
name: info [16795,16799]
name: info [16795,16799]
===
match
---
testlist_star_expr [5718,5753]
testlist_star_expr [5718,5753]
===
match
---
name: stats [2022,2027]
name: stats [2022,2027]
===
match
---
name: cached_celery_backend [19852,19873]
name: cached_celery_backend [19858,19879]
===
match
---
arglist [19533,19578]
arglist [19538,19583]
===
match
---
trailer [3333,3338]
trailer [3333,3338]
===
match
---
name: _sync_parallelism [7660,7677]
name: _sync_parallelism [7660,7677]
===
match
---
trailer [8154,8246]
trailer [8154,8246]
===
match
---
name: task_results_by_task_id [24268,24291]
name: task_results_by_task_id [24270,24293]
===
match
---
name: os [3331,3333]
name: os [3331,3333]
===
match
---
simple_stmt [11412,11437]
simple_stmt [11412,11437]
===
match
---
trailer [16385,16391]
trailer [16385,16391]
===
match
---
trailer [3241,3258]
trailer [3241,3258]
===
match
---
operator: + [20054,20055]
operator: + [20060,20061]
===
match
---
name: utcnow [13871,13877]
name: utcnow [13871,13877]
===
match
---
suite [9616,9670]
suite [9616,9670]
===
match
---
name: exception_traceback [21684,21703]
name: exception_traceback [21690,21709]
===
match
---
trailer [4739,4749]
trailer [4739,4749]
===
match
---
atom_expr [12787,12801]
atom_expr [12787,12801]
===
match
---
operator: , [9312,9313]
operator: , [9312,9313]
===
match
---
name: sync [13195,13199]
name: sync [13195,13199]
===
match
---
operator: , [1181,1182]
operator: , [1181,1182]
===
match
---
name: ret [3406,3409]
name: ret [3406,3409]
===
match
---
trailer [15862,15874]
trailer [15862,15874]
===
match
---
expr_stmt [8255,8324]
expr_stmt [8255,8324]
===
match
---
operator: / [8863,8864]
operator: / [8863,8864]
===
match
---
trailer [3905,3923]
trailer [3905,3923]
===
match
---
trailer [3953,4000]
trailer [3953,4000]
===
match
---
name: a [21779,21780]
name: a [22335,22336]
===
match
---
name: airflow [2226,2233]
name: airflow [2226,2233]
===
match
---
simple_stmt [19456,19590]
simple_stmt [19456,19596]
===
match
---
trailer [23686,23694]
trailer [23688,23696]
===
match
---
simple_stmt [15109,15155]
simple_stmt [15109,15155]
===
match
---
simple_stmt [19835,19874]
simple_stmt [19841,19880]
===
match
---
operator: -> [9749,9751]
operator: -> [9749,9751]
===
match
---
import_from [1919,2008]
import_from [1919,2008]
===
match
---
name: celery [1233,1239]
name: celery [1233,1239]
===
match
---
tfpdef [16524,16533]
tfpdef [16524,16533]
===
match
---
name: close_fds [4527,4536]
name: close_fds [4527,4536]
===
match
---
name: log [25575,25578]
name: log [25577,25580]
===
match
---
trailer [10891,10904]
trailer [10891,10904]
===
match
---
name: backend [19681,19688]
name: backend [19687,19694]
===
match
---
simple_stmt [16203,16244]
simple_stmt [16203,16244]
===
match
---
name: Mapping [23045,23052]
name: Mapping [23037,23044]
===
match
---
argument [17395,17471]
argument [17395,17471]
===
match
---
funcdef [9675,11959]
funcdef [9675,11959]
===
match
---
name: signal [12822,12828]
name: signal [12822,12828]
===
match
---
simple_stmt [21771,21811]
simple_stmt [22327,22367]
===
match
---
trailer [8469,8473]
trailer [8469,8473]
===
match
---
atom_expr [3225,3258]
atom_expr [3225,3258]
===
match
---
name: celery [1434,1440]
name: celery [1434,1440]
===
match
---
operator: = [5804,5805]
operator: = [5804,5805]
===
match
---
atom_expr [9721,9747]
atom_expr [9721,9747]
===
match
---
atom_expr [24301,24335]
atom_expr [24303,24337]
===
match
---
simple_stmt [8954,9095]
simple_stmt [8954,9095]
===
match
---
operator: , [1259,1260]
operator: , [1259,1260]
===
match
---
trailer [25105,25156]
trailer [25107,25158]
===
match
---
string: """Sends task to executor.""" [5684,5713]
string: """Sends task to executor.""" [5684,5713]
===
match
---
name: self [13502,13506]
name: self [13502,13506]
===
match
---
name: Pool [12933,12937]
name: Pool [12933,12937]
===
match
---
operator: = [2866,2867]
operator: = [2866,2867]
===
match
---
name: traceback [5272,5281]
name: traceback [5272,5281]
===
match
---
name: ret [4169,4172]
name: ret [4169,4172]
===
match
---
name: self [17452,17456]
name: self [17452,17456]
===
match
---
arglist [23738,23769]
arglist [23740,23771]
===
match
---
trailer [8869,8887]
trailer [8869,8887]
===
match
---
atom [5875,5884]
atom [5875,5884]
===
match
---
trailer [2709,2744]
trailer [2709,2744]
===
match
---
trailer [17494,17500]
trailer [17494,17500]
===
match
---
trailer [10908,10913]
trailer [10908,10913]
===
match
---
name: args [5870,5874]
name: args [5870,5874]
===
match
---
operator: { [6013,6014]
operator: { [6013,6014]
===
match
---
atom_expr [19336,19362]
atom_expr [19336,19362]
===
match
---
trailer [12793,12801]
trailer [12793,12801]
===
match
---
name: result [22937,22943]
name: result [22929,22935]
===
match
---
name: airflow [1924,1931]
name: airflow [1924,1931]
===
match
---
name: result [11283,11289]
name: result [11283,11289]
===
match
---
trailer [20242,20268]
trailer [20248,20274]
===
match
---
operator: , [5491,5492]
operator: , [5491,5492]
===
match
---
name: len [9258,9261]
name: len [9258,9261]
===
match
---
simple_stmt [24697,24727]
simple_stmt [24699,24729]
===
match
---
trailer [22532,22540]
trailer [22551,22559]
===
match
---
name: key_and_async_results [9981,10002]
name: key_and_async_results [9981,10002]
===
match
---
name: tasks [15868,15873]
name: tasks [15868,15873]
===
match
---
testlist_comp [9380,9427]
testlist_comp [9380,9427]
===
match
---
fstring_start: f" [3954,3956]
fstring_start: f" [3954,3956]
===
match
---
simple_stmt [23089,23137]
simple_stmt [23081,23134]
===
match
---
simple_stmt [20642,21130]
simple_stmt [20648,21136]
===
match
---
trailer [22528,22567]
trailer [22547,22586]
===
match
---
trailer [24957,24972]
trailer [24959,24974]
===
match
---
name: sync_pool [25043,25052]
name: sync_pool [25045,25054]
===
match
---
name: self [9694,9698]
name: self [9694,9698]
===
match
---
trailer [12217,12266]
trailer [12217,12266]
===
match
---
string: """     Wrapper class used to propagate exceptions to parent processes from subprocesses.      :param exception: The exception to wrap     :type exception: Exception     :param exception_traceback: The stacktrace to wrap     :type exception_traceback: str     """ [4887,5150]
string: """     Wrapper class used to propagate exceptions to parent processes from subprocesses.      :param exception: The exception to wrap     :type exception: Exception     :param exception_traceback: The stacktrace to wrap     :type exception_traceback: str     """ [4887,5150]
===
match
---
name: self [11731,11735]
name: self [11731,11735]
===
match
---
name: time [1036,1040]
name: time [1036,1040]
===
match
---
name: states_and_info_by_task_id [25861,25887]
name: states_and_info_by_task_id [25863,25889]
===
match
---
name: key [16490,16493]
name: key [16490,16493]
===
match
---
number: 0 [7759,7760]
number: 0 [7759,7760]
===
match
---
suite [19202,19302]
suite [19202,19302]
===
match
---
atom_expr [22590,22635]
atom_expr [22609,22654]
===
match
---
name: self [16780,16784]
name: self [16780,16784]
===
match
---
return_stmt [6108,6135]
return_stmt [6108,6135]
===
match
---
simple_stmt [9296,9354]
simple_stmt [9296,9354]
===
match
---
name: isinstance [25494,25504]
name: isinstance [25496,25506]
===
match
---
operator: { [20245,20246]
operator: { [20251,20252]
===
match
---
atom_expr [7774,7796]
atom_expr [7774,7796]
===
match
---
name: tasks [15957,15962]
name: tasks [15957,15962]
===
match
---
atom_expr [10369,10403]
atom_expr [10369,10403]
===
match
---
atom_expr [8539,8561]
atom_expr [8539,8561]
===
match
---
name: isinstance [10211,10221]
name: isinstance [10211,10221]
===
match
---
import_as_names [1157,1226]
import_as_names [1157,1226]
===
match
---
operator: , [4151,4152]
operator: , [4151,4152]
===
match
---
name: task_adoption_timeout [8112,8133]
name: task_adoption_timeout [8112,8133]
===
match
---
name: keys [23238,23242]
name: keys [23235,23239]
===
match
---
if_stmt [2613,2800]
if_stmt [2613,2800]
===
match
---
atom_expr [2616,2666]
atom_expr [2616,2666]
===
match
---
with_stmt [5784,5899]
with_stmt [5784,5899]
===
match
---
atom_expr [25112,25130]
atom_expr [25114,25132]
===
match
---
suite [17372,17504]
suite [17372,17504]
===
match
---
trailer [14727,14734]
trailer [14727,14734]
===
match
---
atom_expr [25570,25818]
atom_expr [25572,25820]
===
match
---
name: self [12411,12415]
name: self [12411,12415]
===
match
---
operator: , [13113,13114]
operator: , [13113,13114]
===
match
---
operator: { [21595,21596]
operator: { [21601,21602]
===
match
---
operator: , [2718,2719]
operator: , [2718,2719]
===
match
---
name: FAILURE [16731,16738]
name: FAILURE [16731,16738]
===
match
---
trailer [10373,10394]
trailer [10373,10394]
===
match
---
operator: = [23150,23151]
operator: = [23147,23148]
===
match
---
operator: = [17651,17652]
operator: = [17651,17652]
===
match
---
name: Celery [2807,2813]
name: Celery [2807,2813]
===
match
---
import_from [1094,1137]
import_from [1094,1137]
===
match
---
name: _sync_parallelism [25138,25155]
name: _sync_parallelism [25140,25157]
===
match
---
name: MutableMapping [25347,25361]
name: MutableMapping [25349,25363]
===
match
---
name: map [12218,12221]
name: map [12218,12221]
===
match
---
trailer [16950,16972]
trailer [16950,16972]
===
match
---
name: backend [11326,11333]
name: backend [11326,11333]
===
match
---
name: self [15741,15745]
name: self [15741,15745]
===
match
---
name: State [11757,11762]
name: State [11757,11762]
===
match
---
trailer [25214,25305]
trailer [25216,25307]
===
match
---
atom_expr [8822,8890]
atom_expr [8822,8890]
===
match
---
dotted_name [6751,6775]
dotted_name [6751,6775]
===
match
---
atom_expr [20585,20636]
atom_expr [20591,20642]
===
match
---
atom_expr [23954,23968]
atom_expr [23956,23970]
===
match
---
name: update_all_task_states [13343,13365]
name: update_all_task_states [13343,13365]
===
match
---
name: key [17570,17573]
name: key [17570,17573]
===
match
---
trailer [15923,15942]
trailer [15923,15942]
===
match
---
funcdef [11964,13186]
funcdef [11964,13186]
===
match
---
name: info [24743,24747]
name: info [24745,24749]
===
match
---
name: async_tasks [21741,21752]
name: async_tasks [22293,22304]
===
match
---
string: "celery.task_timeout_error" [10487,10514]
string: "celery.task_timeout_error" [10487,10514]
===
match
---
operator: = [13124,13125]
operator: = [13124,13125]
===
match
---
simple_stmt [2399,2456]
simple_stmt [2399,2456]
===
match
---
name: state_or_exception [25713,25731]
name: state_or_exception [25715,25733]
===
match
---
simple_stmt [3753,3775]
simple_stmt [3753,3775]
===
match
---
testlist_comp [16717,16761]
testlist_comp [16717,16761]
===
match
---
atom_expr [24463,24499]
atom_expr [24465,24501]
===
match
---
param [23029,23040]
param [23021,23032]
===
match
---
name: now [13865,13868]
name: now [13865,13868]
===
match
---
atom_expr [12903,12917]
atom_expr [12903,12917]
===
match
---
name: app [2892,2895]
name: app [2892,2895]
===
match
---
operator: -> [4357,4359]
operator: -> [4357,4359]
===
match
---
trailer [23271,23279]
trailer [23268,23276]
===
match
---
name: ExceptionWithTraceback [10995,11017]
name: ExceptionWithTraceback [10995,11017]
===
match
---
string: "Fetched %d states for %d task" [22900,22931]
string: "Fetched %d state(s) for %d task(s)" [22887,22923]
===
match
---
name: app [23738,23741]
name: app [23740,23743]
===
match
---
name: python [6769,6775]
name: python [6769,6775]
===
match
---
name: subprocess [4612,4622]
name: subprocess [4612,4622]
===
match
---
name: getint [7685,7691]
name: getint [7685,7691]
===
match
---
funcdef [17529,17851]
funcdef [17529,17851]
===
match
---
name: key [10310,10313]
name: key [10310,10313]
===
match
---
atom_expr [9236,9282]
atom_expr [9236,9282]
===
match
---
name: apply_async [5858,5869]
name: apply_async [5858,5869]
===
match
---
name: itemgetter [19542,19552]
name: itemgetter [19547,19557]
===
match
---
trailer [21373,21395]
trailer [21379,21401]
===
match
---
operator: == [12082,12084]
operator: == [12082,12084]
===
match
---
name: tasks [20100,20105]
name: tasks [20106,20111]
===
match
---
trailer [3120,3157]
trailer [3120,3157]
===
match
---
operator: , [16365,16366]
operator: , [16365,16366]
===
match
---
simple_stmt [4010,4026]
simple_stmt [4010,4026]
===
match
---
atom [24401,24403]
atom [24403,24405]
===
match
---
name: tasks [23822,23827]
name: tasks [23824,23829]
===
match
---
arglist [15537,15698]
arglist [15537,15698]
===
match
---
trailer [13384,13406]
trailer [13384,13406]
===
match
---
name: timedelta [8145,8154]
name: timedelta [8145,8154]
===
match
---
funcdef [16462,17294]
funcdef [16462,17294]
===
match
---
name: copy [4387,4391]
name: copy [4387,4391]
===
match
---
trailer [10065,10069]
trailer [10065,10069]
===
match
---
atom_expr [11169,11185]
atom_expr [11169,11185]
===
match
---
simple_stmt [22434,22507]
simple_stmt [22453,22526]
===
match
---
name: update_task_state [16208,16225]
name: update_task_state [16208,16225]
===
match
---
name: state [16360,16365]
name: state [16360,16365]
===
match
---
simple_stmt [22974,22988]
simple_stmt [22966,22980]
===
match
---
atom_expr [15211,15242]
atom_expr [15211,15242]
===
match
---
annassign [9184,9217]
annassign [9184,9217]
===
match
---
import_as_names [1871,1918]
import_as_names [1871,1918]
===
match
---
testlist_star_expr [9296,9331]
testlist_star_expr [9296,9331]
===
match
---
name: update_task_state [16466,16483]
name: update_task_state [16466,16483]
===
match
---
operator: = [5448,5449]
operator: = [5448,5449]
===
match
---
operator: == [12113,12115]
operator: == [12113,12115]
===
match
---
name: task_ids [23617,23625]
name: task_ids [23614,23622]
===
match
---
operator: = [23728,23729]
operator: = [23730,23731]
===
match
---
return_stmt [22974,22987]
return_stmt [22966,22979]
===
match
---
trailer [20601,20630]
trailer [20607,20636]
===
match
---
suite [3216,3259]
suite [3216,3259]
===
match
---
name: self [23439,23443]
name: self [23436,23440]
===
match
---
name: in_ [23878,23881]
name: in_ [23880,23883]
===
match
---
atom_expr [23573,23607]
atom_expr [23570,23604]
===
match
---
operator: , [1411,1412]
operator: , [1411,1412]
===
match
---
funcdef [15714,16244]
funcdef [15714,16244]
===
match
---
name: timedout_keys [15024,15037]
name: timedout_keys [15024,15037]
===
match
---
trailer [23443,23480]
trailer [23440,23477]
===
match
---
name: values [15963,15969]
name: values [15963,15969]
===
match
---
parameters [15262,15268]
parameters [15262,15268]
===
match
---
name: Dict [8042,8046]
name: Dict [8042,8046]
===
match
---
name: State [15135,15140]
name: State [15135,15140]
===
match
---
suite [4647,4851]
suite [4647,4851]
===
match
---
atom_expr [17452,17471]
atom_expr [17452,17471]
===
match
---
simple_stmt [13889,13908]
simple_stmt [13889,13908]
===
match
---
operator: = [12409,12410]
operator: = [12409,12410]
===
match
---
name: airflow [1651,1658]
name: airflow [1651,1658]
===
match
---
name: reset_signals [12561,12574]
name: reset_signals [12561,12574]
===
match
---
name: cli [3637,3640]
name: cli [3637,3640]
===
match
---
param [5197,5221]
param [5197,5221]
===
match
---
operator: = [24021,24022]
operator: = [24023,24024]
===
match
---
expr_stmt [25319,25393]
expr_stmt [25321,25395]
===
match
---
expr_stmt [23673,23710]
expr_stmt [23675,23712]
===
match
---
trailer [2699,2709]
trailer [2699,2709]
===
match
---
name: key [20155,20158]
name: key [20161,20164]
===
match
---
operator: , [24794,24795]
operator: , [24796,24797]
===
match
---
name: config_source [2853,2866]
name: config_source [2853,2866]
===
match
---
expr_stmt [22816,22876]
expr_stmt [22803,22863]
===
match
---
name: AirflowException [3486,3502]
name: AirflowException [3486,3502]
===
match
---
simple_stmt [2672,2745]
simple_stmt [2672,2745]
===
match
---
for_stmt [19698,20269]
for_stmt [19704,20275]
===
match
---
trailer [12094,12112]
trailer [12094,12112]
===
match
---
name: len [15594,15597]
name: len [15594,15597]
===
match
---
simple_stmt [9549,9584]
simple_stmt [9549,9584]
===
match
---
trailer [15237,15242]
trailer [15237,15242]
===
match
---
atom_expr [17395,17405]
atom_expr [17395,17405]
===
match
---
trailer [22740,22766]
trailer [22735,22761]
===
match
---
atom [19718,19731]
atom [19724,19737]
===
match
---
simple_stmt [6710,6740]
simple_stmt [6710,6740]
===
match
---
dotted_name [2046,2077]
dotted_name [2046,2077]
===
match
---
string: 'celery' [2823,2831]
string: 'celery' [2823,2831]
===
match
---
name: mget [23233,23237]
name: mget [23230,23234]
===
match
---
name: Union [5635,5640]
name: Union [5635,5640]
===
match
---
name: event_buffer [15114,15126]
name: event_buffer [15114,15126]
===
match
---
name: states_by_celery_task_id [19456,19480]
name: states_by_celery_task_id [19456,19480]
===
match
---
name: _get_many_using_multiprocessing [24836,24867]
name: _get_many_using_multiprocessing [24838,24869]
===
match
---
name: error [11045,11050]
name: error [11045,11050]
===
match
---
name: key [13920,13923]
name: key [13920,13923]
===
match
---
name: end [17303,17306]
name: end [17303,17306]
===
match
---
suite [8456,8563]
suite [8456,8563]
===
match
---
simple_stmt [6645,6680]
simple_stmt [6645,6680]
===
match
---
operator: , [24903,24904]
operator: , [24905,24906]
===
match
---
name: command [9396,9403]
name: command [9396,9403]
===
match
---
name: async_results [25257,25270]
name: async_results [25259,25272]
===
match
---
name: EventBufferValueType [23058,23078]
name: EventBufferValueType [23050,23070]
===
match
---
testlist [6115,6135]
testlist [6115,6135]
===
match
---
atom_expr [25861,25896]
atom_expr [25863,25898]
===
match
---
return_stmt [24101,24184]
return_stmt [24103,24186]
===
match
---
simple_stmt [7906,7922]
simple_stmt [7906,7922]
===
match
---
atom_expr [9506,9531]
atom_expr [9506,9531]
===
match
---
trailer [10411,10436]
trailer [10411,10436]
===
match
---
name: self [15661,15665]
name: self [15661,15665]
===
match
---
operator: = [23219,23220]
operator: = [23216,23217]
===
match
---
atom_expr [9118,9155]
atom_expr [9118,9155]
===
match
---
return_stmt [21418,21471]
return_stmt [21424,21477]
===
match
---
simple_stmt [22727,22782]
simple_stmt [22722,22777]
===
match
---
trailer [15687,15693]
trailer [15687,15693]
===
match
---
name: logging [965,972]
name: logging [965,972]
===
match
---
operator: = [13869,13870]
operator: = [13869,13870]
===
match
---
operator: , [11258,11259]
operator: , [11258,11259]
===
match
---
trailer [4250,4256]
trailer [4250,4256]
===
match
---
name: task_publish_max_retries [10412,10436]
name: task_publish_max_retries [10412,10436]
===
match
---
try_stmt [6831,6920]
try_stmt [6831,6920]
===
match
---
name: append [9461,9467]
name: append [9461,9467]
===
match
---
name: stderr [4501,4507]
name: stderr [4501,4507]
===
match
---
name: state [16092,16097]
name: state [16092,16097]
===
match
---
name: task_tuples_to_send [12448,12467]
name: task_tuples_to_send [12448,12467]
===
match
---
operator: = [19850,19851]
operator: = [19856,19857]
===
match
---
atom_expr [12933,12989]
atom_expr [12933,12989]
===
match
---
name: self [22885,22889]
name: self [22872,22876]
===
match
---
trailer [15475,15481]
trailer [15475,15481]
===
match
---
name: __name__ [2288,2296]
name: __name__ [2288,2296]
===
match
---
name: tasks [15476,15481]
name: tasks [15476,15481]
===
match
---
simple_stmt [17785,17851]
simple_stmt [17785,17851]
===
match
---
operator: , [11769,11770]
operator: , [11769,11770]
===
match
---
trailer [20590,20636]
trailer [20596,20642]
===
match
---
trailer [25115,25130]
trailer [25117,25132]
===
match
---
trailer [22687,22695]
trailer [22682,22690]
===
match
---
operator: , [16793,16794]
operator: , [16793,16794]
===
match
---
name: key [10956,10959]
name: key [10956,10959]
===
match
---
name: task_tuples_to_send [9798,9817]
name: task_tuples_to_send [9798,9817]
===
match
---
trailer [16155,16163]
trailer [16155,16163]
===
match
---
subscriptlist [24309,24334]
subscriptlist [24311,24336]
===
match
---
trailer [8286,8308]
trailer [8286,8308]
===
match
---
parameters [2920,2950]
parameters [2920,2950]
===
match
---
name: async_result [21580,21592]
name: async_result [21586,21598]
===
match
---
atom_expr [6014,6036]
atom_expr [6014,6036]
===
match
---
parameters [12574,12576]
parameters [12574,12576]
===
match
---
name: tasks [16064,16069]
name: tasks [16064,16069]
===
match
---
name: tasks [15180,15185]
name: tasks [15180,15185]
===
match
---
operator: = [20114,20115]
operator: = [20120,20121]
===
match
---
trailer [2813,2888]
trailer [2813,2888]
===
insert-tree
---
simple_stmt [787,942]
    string: """CeleryExecutor  .. seealso::     For more information on how the CeleryExecutor works, take a look at the guide:     :ref:`executor:CeleryExecutor` """ [787,941]
to
file_input [787,25966]
at 0
===
insert-tree
---
simple_stmt [2537,2612]
    string: ''' To start the celery worker, run the command: airflow celery worker ''' [2537,2611]
to
file_input [787,25966]
at 35
===
insert-node
---
name: CeleryExecutor [6961,6975]
to
classdef [6955,20525]
at 0
===
insert-node
---
name: BaseExecutor [6976,6988]
to
classdef [6955,20525]
at 1
===
insert-tree
---
simple_stmt [6995,7346]
    string: """     CeleryExecutor is recommended for production use of Airflow. It allows     distributing the execution of task instances to multiple worker nodes.      Celery is a simple, flexible and reliable distributed system to process     vast amounts of messages, while providing operations with the tools     required to maintain such a system.     """ [6995,7345]
to
suite [6990,20525]
at 0
===
move-tree
---
funcdef [21713,21811]
    name: _tasks_list_to_task_ids [21717,21740]
    parameters [21740,21753]
        param [21741,21752]
            name: async_tasks [21741,21752]
    operator: -> [21754,21756]
    atom_expr [21757,21765]
        name: Set [21757,21760]
        trailer [21760,21765]
            name: str [21761,21764]
    suite [21766,21811]
        simple_stmt [21771,21811]
            return_stmt [21771,21810]
                atom [21778,21810]
                    operator: { [21778,21779]
                    dictorsetmaker [21779,21809]
                        atom_expr [21779,21788]
                            name: a [21779,21780]
                            trailer [21780,21788]
                                name: task_id [21781,21788]
                        sync_comp_for [21789,21809]
                            name: a [21793,21794]
                            name: async_tasks [21798,21809]
                    operator: } [21809,21810]
to
suite [21850,25966]
at 2
===
insert-tree
---
param [22287,22292]
    name: self [22287,22291]
    operator: , [22291,22292]
to
parameters [21740,21753]
at 0
===
move-tree
---
atom_expr [22673,22713]
    name: isinstance [22673,22683]
    trailer [22683,22713]
        arglist [22684,22712]
            atom_expr [22684,22695]
                name: app [22684,22687]
                trailer [22687,22695]
                    name: backend [22688,22695]
            operator: , [22695,22696]
            name: DatabaseBackend [22697,22712]
to
if_stmt [22515,22662]
at 2
===
move-tree
---
suite [22714,22808]
    simple_stmt [22727,22782]
        expr_stmt [22727,22781]
            name: result [22727,22733]
            operator: = [22734,22735]
            atom_expr [22736,22781]
                name: self [22736,22740]
                trailer [22740,22766]
                    name: _get_many_from_db_backend [22741,22766]
                trailer [22766,22781]
                    name: async_results [22767,22780]
    simple_stmt [22794,22808]
        return_stmt [22794,22807]
            name: result [22801,22807]
to
if_stmt [22515,22662]
at 3
===
insert-node
---
suite [22790,22864]
to
if_stmt [22515,22662]
at 4
===
insert-node
---
atom_expr [19483,19595]
to
expr_stmt [19456,19589]
at 2
===
move-tree
---
simple_stmt [22816,22877]
    expr_stmt [22816,22876]
        name: result [22816,22822]
        operator: = [22823,22824]
        atom_expr [22825,22876]
            name: self [22825,22829]
            trailer [22829,22861]
                name: _get_many_using_multiprocessing [22830,22861]
            trailer [22861,22876]
                name: async_results [22862,22875]
to
suite [22790,22864]
at 0
===
move-tree
---
trailer [19487,19506]
    name: bulk_state_fetcher [19488,19506]
to
atom_expr [19483,19595]
at 1
===
move-tree
---
trailer [19506,19515]
    name: get_many [19507,19515]
to
atom_expr [19483,19595]
at 2
===
insert-node
---
trailer [19515,19595]
to
atom_expr [19483,19595]
at 3
===
insert-node
---
name: self [23092,23096]
to
atom_expr [23100,23136]
at 0
===
insert-node
---
trailer [23096,23120]
to
atom_expr [23100,23136]
at 1
===
insert-node
---
name: self [23625,23629]
to
atom_expr [23628,23664]
at 0
===
insert-node
---
trailer [23629,23653]
to
atom_expr [23628,23664]
at 1
===
move-tree
---
atom_expr [19483,19589]
    name: self [19483,19487]
    trailer [19487,19506]
        name: bulk_state_fetcher [19488,19506]
    trailer [19506,19515]
        name: get_many [19507,19515]
    trailer [19515,19589]
        atom_expr [19529,19579]
            name: map [19529,19532]
            trailer [19532,19579]
                arglist [19533,19578]
                    atom_expr [19533,19555]
                        name: operator [19533,19541]
                        trailer [19541,19552]
                            name: itemgetter [19542,19552]
                        trailer [19552,19555]
                            number: 0 [19553,19554]
                    operator: , [19555,19556]
                    atom_expr [19557,19578]
                        name: celery_tasks [19557,19569]
                        trailer [19569,19576]
                            name: values [19570,19576]
                        trailer [19576,19578]
to
trailer [19515,19595]
at 0
===
update-node
---
string: "Fetched %d states for %d task" [22900,22931]
replace "Fetched %d states for %d task" by "Fetched %d state(s) for %d task(s)"
===
move-tree
---
name: _tasks_list_to_task_ids [23100,23123]
to
trailer [23096,23120]
at 0
===
move-tree
---
name: _tasks_list_to_task_ids [23628,23651]
to
trailer [23629,23653]
at 0
===
update-node
---
name: self [19483,19487]
replace self by list
===
delete-tree
---
simple_stmt [787,942]
    string: """CeleryExecutor  .. seealso::     For more information on how the CeleryExecutor works, take a look at the guide:     :ref:`executor:CeleryExecutor` """ [787,941]
===
delete-tree
---
simple_stmt [2537,2612]
    string: ''' To start the celery worker, run the command: airflow celery worker ''' [2537,2611]
===
delete-node
---
name: CeleryExecutor [6961,6975]
===
===
delete-node
---
name: BaseExecutor [6976,6988]
===
===
delete-tree
---
simple_stmt [6995,7346]
    string: """     CeleryExecutor is recommended for production use of Airflow. It allows     distributing the execution of task instances to multiple worker nodes.      Celery is a simple, flexible and reliable distributed system to process     vast amounts of messages, while providing operations with the tools     required to maintain such a system.     """ [6995,7345]
===
delete-tree
---
simple_stmt [22648,22662]
    return_stmt [22648,22661]
        name: result [22655,22661]
===
delete-tree
---
simple_stmt [22794,22808]
    return_stmt [22794,22807]
        name: result [22801,22807]
===
delete-node
---
if_stmt [22670,22808]
===
