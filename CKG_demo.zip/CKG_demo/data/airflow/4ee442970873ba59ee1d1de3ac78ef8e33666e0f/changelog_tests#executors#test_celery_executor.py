===
match
---
name: mock [11714,11718]
name: mock [11714,11718]
===
match
---
operator: ** [16511,16513]
operator: ** [16511,16513]
===
match
---
name: executor [10993,11001]
name: executor [10993,11001]
===
match
---
expr_stmt [10993,11037]
expr_stmt [10993,11037]
===
match
---
name: State [1906,1911]
name: State [1906,1911]
===
match
---
name: SUCCESS [6308,6315]
name: SUCCESS [6308,6315]
===
match
---
argument [14118,14142]
argument [14118,14142]
===
match
---
trailer [6247,6295]
trailer [6247,6295]
===
match
---
testlist_comp [7808,7841]
testlist_comp [7808,7841]
===
match
---
trailer [15761,15776]
trailer [15761,15776]
===
match
---
name: pytest [7907,7913]
name: pytest [7907,7913]
===
match
---
assert_stmt [9385,9419]
assert_stmt [9385,9419]
===
match
---
expr_stmt [19463,19492]
expr_stmt [20173,20202]
===
match
---
atom [12847,12857]
atom [12847,12857]
===
match
---
funcdef [12080,12900]
funcdef [12080,12900]
===
match
---
comparison [11155,11206]
comparison [11155,11206]
===
match
---
atom_expr [11050,11134]
atom_expr [11050,11134]
===
match
---
name: fetcher [17553,17560]
name: fetcher [17675,17682]
===
match
---
name: task [8612,8616]
name: task [8612,8616]
===
match
---
string: "mysql" [10788,10795]
string: "mysql" [10788,10795]
===
match
---
atom_expr [14541,14555]
atom_expr [14541,14555]
===
match
---
name: fetcher [19518,19525]
name: fetcher [20228,20235]
===
match
---
number: 1 [15341,15342]
number: 1 [15341,15342]
===
match
---
name: self [16803,16807]
name: self [16803,16807]
===
match
---
name: value [16539,16544]
name: value [16539,16544]
===
match
---
operator: , [7838,7839]
operator: , [7838,7839]
===
match
---
import_from [1397,1435]
import_from [1397,1435]
===
match
---
simple_stmt [6069,6162]
simple_stmt [6069,6162]
===
match
---
operator: , [13261,13262]
operator: , [13261,13262]
===
match
---
string: "redis" [18148,18155]
string: "redis" [18414,18421]
===
match
---
trailer [13608,13610]
trailer [13608,13610]
===
match
---
trailer [10431,10438]
trailer [10431,10438]
===
match
---
operator: , [17029,17030]
operator: , [17029,17030]
===
match
---
testlist_comp [12847,12858]
testlist_comp [12847,12858]
===
match
---
atom_expr [14612,14622]
atom_expr [14612,14622]
===
match
---
atom_expr [10993,11007]
atom_expr [10993,11007]
===
match
---
operator: , [5552,5553]
operator: , [5552,5553]
===
match
---
name: app [18471,18474]
name: app [18737,18740]
===
match
---
funcdef [3592,3671]
funcdef [3592,3671]
===
match
---
assert_stmt [6069,6161]
assert_stmt [6069,6161]
===
match
---
name: task_2 [14624,14630]
name: task_2 [14624,14630]
===
match
---
suite [2204,2231]
suite [2204,2231]
===
match
---
name: ti2 [14152,14155]
name: ti2 [14152,14155]
===
match
---
name: QUEUED [6028,6034]
name: QUEUED [6028,6034]
===
match
---
name: utils [1852,1857]
name: utils [1852,1857]
===
match
---
name: loglevel [4507,4515]
name: loglevel [4507,4515]
===
match
---
argument [8649,8663]
argument [8649,8663]
===
match
---
name: asynchronous [1321,1333]
name: asynchronous [1321,1333]
===
match
---
operator: = [4494,4495]
operator: = [4494,4495]
===
match
---
trailer [9327,9340]
trailer [9327,9340]
===
match
---
operator: } [18792,18793]
operator: } [19180,19181]
===
match
---
simple_stmt [3292,3326]
simple_stmt [3292,3326]
===
match
---
name: dict [10506,10510]
name: dict [10506,10510]
===
match
---
name: ti1 [14048,14051]
name: ti1 [14048,14051]
===
match
---
assert_stmt [14309,14341]
assert_stmt [14309,14341]
===
match
---
string: 'airflow' [4089,4098]
string: 'airflow' [4089,4098]
===
match
---
name: queued_tasks [9062,9074]
name: queued_tasks [9062,9074]
===
match
---
operator: = [17639,17640]
operator: = [17761,17762]
===
match
---
suite [17294,18044]
suite [17294,18310]
===
match
---
simple_stmt [12537,12578]
simple_stmt [12537,12578]
===
match
---
operator: , [2406,2407]
operator: , [2406,2407]
===
match
---
name: clear_db_runs [3628,3641]
name: clear_db_runs [3628,3641]
===
match
---
name: event_buffer [5955,5967]
name: event_buffer [5955,5967]
===
match
---
operator: = [13208,13209]
operator: = [13208,13209]
===
match
---
atom_expr [8719,8733]
atom_expr [8719,8733]
===
match
---
string: "task_2" [15526,15534]
string: "task_2" [15526,15534]
===
match
---
operator: , [14242,14243]
operator: , [14242,14243]
===
match
---
simple_stmt [7066,7110]
simple_stmt [7066,7110]
===
match
---
simple_stmt [10274,10453]
simple_stmt [10274,10453]
===
match
---
argument [15184,15194]
argument [15184,15194]
===
match
---
name: execute [2343,2350]
name: execute [2343,2350]
===
match
---
trailer [14010,14031]
trailer [14010,14031]
===
match
---
funcdef [16840,16903]
funcdef [16840,16903]
===
match
---
operator: } [9839,9840]
operator: } [9839,9840]
===
match
---
trailer [17451,17455]
trailer [17451,17455]
===
match
---
atom_expr [16303,16336]
atom_expr [16303,16336]
===
match
---
dictorsetmaker [17992,18042]
dictorsetmaker [18114,18164]
===
match
---
name: configuration [1410,1423]
name: configuration [1410,1423]
===
match
---
comparison [6331,6416]
comparison [6331,6416]
===
match
---
atom_expr [16548,16562]
atom_expr [16548,16562]
===
match
---
name: executor [14357,14365]
name: executor [14357,14365]
===
match
---
name: cm [11219,11221]
name: cm [11219,11221]
===
match
---
operator: == [19041,19043]
operator: == [19485,19487]
===
match
---
operator: @ [2282,2283]
operator: @ [2282,2283]
===
match
---
expr_stmt [4334,4377]
expr_stmt [4334,4377]
===
match
---
name: Exception [2219,2228]
name: Exception [2219,2228]
===
match
---
name: start_date [13580,13590]
name: start_date [13580,13590]
===
match
---
trailer [18470,18474]
trailer [18736,18740]
===
match
---
with_stmt [6847,7688]
with_stmt [6847,7688]
===
match
---
name: set [14336,14339]
name: set [14336,14339]
===
match
---
name: MagicMock [18968,18977]
name: MagicMock [19396,19405]
===
match
---
name: adopted_task_timeouts [14366,14387]
name: adopted_task_timeouts [14366,14387]
===
match
---
string: 'executor.open_slots' [11724,11745]
string: 'executor.open_slots' [11724,11745]
===
match
---
name: test_operation_timeout_config [16259,16288]
name: test_operation_timeout_config [16259,16288]
===
match
---
expr_stmt [14505,14579]
expr_stmt [14505,14579]
===
match
---
name: dag [15675,15678]
name: dag [15675,15678]
===
match
---
trailer [8912,8971]
trailer [8912,8971]
===
match
---
name: mock_trigger_tasks [11571,11589]
name: mock_trigger_tasks [11571,11589]
===
match
---
simple_stmt [5592,5631]
simple_stmt [5592,5631]
===
match
---
name: running [14325,14332]
name: running [14325,14332]
===
match
---
name: self [10844,10848]
name: self [10844,10848]
===
match
---
dotted_name [15041,15060]
dotted_name [15041,15060]
===
match
---
name: unittest [845,853]
name: unittest [845,853]
===
match
---
name: success_command [3993,4008]
name: success_command [3993,4008]
===
match
---
simple_stmt [13519,13572]
simple_stmt [13519,13572]
===
match
---
name: mock_mget [17806,17815]
name: mock_mget [17928,17937]
===
match
---
testlist_comp [2034,2038]
testlist_comp [2034,2038]
===
match
---
testlist_comp [2033,2094]
testlist_comp [2033,2094]
===
match
---
name: logfile [4487,4494]
name: logfile [4487,4494]
===
match
---
name: call [11833,11837]
name: call [11833,11837]
===
match
---
simple_stmt [817,827]
simple_stmt [817,827]
===
match
---
expr_stmt [2789,2882]
expr_stmt [2789,2882]
===
match
---
trailer [17435,17481]
trailer [17435,17481]
===
match
---
fstring_string: [Try 3 of 3] Task Timeout Error for Task: ( [10374,10417]
fstring_string: [Try 3 of 3] Task Timeout Error for Task: ( [10374,10417]
===
match
---
strings [9457,9583]
strings [9457,9583]
===
match
---
name: contextlib [794,804]
name: contextlib [794,804]
===
match
---
trailer [4564,4568]
trailer [4564,4568]
===
match
---
operator: -> [3695,3697]
operator: -> [3695,3697]
===
match
---
atom_expr [3568,3585]
atom_expr [3568,3585]
===
match
---
assert_stmt [11238,11291]
assert_stmt [11238,11291]
===
match
---
name: mock [2805,2809]
name: mock [2805,2809]
===
match
---
decorator [17155,17192]
decorator [17155,17192]
===
match
---
name: executor [11050,11058]
name: executor [11050,11058]
===
match
---
atom_expr [9587,9596]
atom_expr [9587,9596]
===
match
---
operator: , [6732,6733]
operator: , [6732,6733]
===
match
---
trailer [3668,3670]
trailer [3668,3670]
===
match
---
simple_stmt [9203,9224]
simple_stmt [9203,9224]
===
match
---
name: event_buffer [7794,7806]
name: event_buffer [7794,7806]
===
match
---
operator: = [8656,8657]
operator: = [8656,8657]
===
match
---
string: "postgres" [17226,17236]
string: "postgres" [17226,17236]
===
match
---
name: tis [13415,13418]
name: tis [13415,13418]
===
match
---
expr_stmt [13230,13283]
expr_stmt [13230,13283]
===
match
---
name: mock [18916,18920]
name: mock [19336,19340]
===
match
---
operator: = [8617,8618]
operator: = [8617,8618]
===
match
---
name: OPERATION_TIMEOUT [16319,16336]
name: OPERATION_TIMEOUT [16319,16336]
===
match
---
name: integration [3826,3837]
name: integration [3826,3837]
===
match
---
trailer [17959,17963]
trailer [18081,18085]
===
match
---
testlist_comp [12848,12856]
testlist_comp [12848,12856]
===
match
---
simple_stmt [3625,3644]
simple_stmt [3625,3644]
===
match
---
dotted_name [11453,11463]
dotted_name [11453,11463]
===
match
---
trailer [15678,15685]
trailer [15678,15685]
===
match
---
raise_stmt [2213,2230]
raise_stmt [2213,2230]
===
match
---
name: fetcher [18868,18875]
name: fetcher [19272,19279]
===
match
---
trailer [6015,6018]
trailer [6015,6018]
===
match
---
with_stmt [13098,13221]
with_stmt [13098,13221]
===
match
---
atom_expr [4220,4244]
atom_expr [4220,4244]
===
match
---
argument [4487,4505]
argument [4487,4505]
===
match
---
operator: = [17349,17350]
operator: = [17349,17350]
===
match
---
operator: = [17804,17805]
operator: = [17926,17927]
===
match
---
arglist [4272,4312]
arglist [4272,4312]
===
match
---
name: executor [16216,16224]
name: executor [16216,16224]
===
match
---
arglist [15592,15641]
arglist [15592,15641]
===
match
---
atom_expr [8619,8747]
atom_expr [8619,8747]
===
match
---
string: "rabbitmq" [18186,18196]
string: "rabbitmq" [18452,18462]
===
match
---
exprlist [16534,16544]
exprlist [16534,16544]
===
match
---
name: datetime [13012,13020]
name: datetime [13012,13020]
===
match
---
name: start_date [15204,15214]
name: start_date [15204,15214]
===
match
---
number: 0 [6139,6140]
number: 0 [6139,6140]
===
match
---
simple_stmt [6518,6553]
simple_stmt [6518,6553]
===
match
---
name: command [4170,4177]
name: command [4170,4177]
===
match
---
trailer [3576,3585]
trailer [3576,3585]
===
match
---
name: executor [16180,16188]
name: executor [16180,16188]
===
match
---
name: exec_date [15703,15712]
name: exec_date [15703,15712]
===
match
---
classdef [16344,16903]
classdef [16344,16903]
===
match
---
name: ResultSession [18546,18559]
name: ResultSession [18934,18947]
===
match
---
comp_op [6443,6449]
comp_op [6443,6449]
===
match
---
name: not_adopted_tis [15013,15028]
name: not_adopted_tis [15013,15028]
===
match
---
name: celery_executor [1534,1549]
name: celery_executor [1534,1549]
===
match
---
suite [12996,13419]
suite [12996,13419]
===
match
---
atom_expr [18380,18399]
atom_expr [18646,18665]
===
match
---
name: success_command [4181,4196]
name: success_command [4181,4196]
===
match
---
name: url [2044,2047]
name: url [2044,2047]
===
match
---
simple_stmt [10145,10215]
simple_stmt [10145,10215]
===
match
---
operator: @ [19102,19103]
operator: @ [19690,19691]
===
match
---
name: executors [1517,1526]
name: executors [1517,1526]
===
match
---
name: mark [18169,18173]
name: mark [18435,18439]
===
match
---
decorator [7906,7943]
decorator [7906,7943]
===
match
---
simple_stmt [8999,9041]
simple_stmt [8999,9041]
===
match
---
name: integration [17168,17179]
name: integration [17168,17179]
===
match
---
trailer [5954,5967]
trailer [5954,5967]
===
match
---
string: 'run' [12055,12060]
string: 'run' [12055,12060]
===
match
---
atom_expr [17436,17455]
atom_expr [17436,17455]
===
match
---
atom_expr [9736,9762]
atom_expr [9736,9762]
===
match
---
atom_expr [16115,16127]
atom_expr [16115,16127]
===
match
---
simple_stmt [2100,2144]
simple_stmt [2100,2144]
===
match
---
trailer [17395,17399]
trailer [17395,17399]
===
match
---
atom [4961,5262]
atom [4961,5262]
===
match
---
dotted_name [10768,10787]
dotted_name [10768,10787]
===
match
---
operator: , [13452,13453]
operator: , [13452,13453]
===
match
---
operator: == [16817,16819]
operator: == [16817,16819]
===
match
---
atom_expr [9740,9761]
atom_expr [9740,9761]
===
match
---
simple_stmt [15142,15196]
simple_stmt [15142,15196]
===
match
---
name: clear_db_jobs [3742,3755]
name: clear_db_jobs [3742,3755]
===
match
---
name: cm [8198,8200]
name: cm [8198,8200]
===
match
---
with_stmt [15352,15559]
with_stmt [15352,15559]
===
match
---
simple_stmt [2557,2604]
simple_stmt [2557,2604]
===
match
---
assert_stmt [14350,14393]
assert_stmt [14350,14393]
===
match
---
suite [5491,5631]
suite [5491,5631]
===
match
---
atom_expr [4430,4446]
atom_expr [4430,4446]
===
match
---
parameters [16773,16786]
parameters [16773,16786]
===
match
---
trailer [15360,15400]
trailer [15360,15400]
===
match
---
operator: , [19621,19622]
operator: , [20331,20332]
===
match
---
name: pytest [6626,6632]
name: pytest [6626,6632]
===
match
---
trailer [14962,14969]
trailer [14962,14969]
===
match
---
name: ti2 [14193,14196]
name: ti2 [14193,14196]
===
match
---
operator: , [2867,2868]
operator: , [2867,2868]
===
match
---
argument [15247,15253]
argument [15247,15253]
===
match
---
atom [10124,10132]
atom [10124,10132]
===
match
---
name: task_adoption_timeout [15929,15950]
name: task_adoption_timeout [15929,15950]
===
match
---
atom_expr [9392,9413]
atom_expr [9392,9413]
===
match
---
assert_stmt [15006,15034]
assert_stmt [15006,15034]
===
match
---
expr_stmt [15787,15961]
expr_stmt [15787,15961]
===
match
---
name: mark [3859,3863]
name: mark [3859,3863]
===
match
---
dictorsetmaker [9704,9710]
dictorsetmaker [9704,9710]
===
match
---
operator: , [14622,14623]
operator: , [14622,14623]
===
match
---
atom_expr [13947,13998]
atom_expr [13947,13998]
===
match
---
name: patch [18442,18447]
name: patch [18708,18713]
===
match
---
name: executor [14316,14324]
name: executor [14316,14324]
===
match
---
name: utcnow [13021,13027]
name: utcnow [13021,13027]
===
match
---
with_stmt [18432,18813]
with_stmt [18698,19462]
===
match
---
operator: == [8559,8561]
operator: == [8559,8561]
===
match
---
name: mark [3821,3825]
name: mark [3821,3825]
===
match
---
trailer [16684,16699]
trailer [16684,16699]
===
match
---
name: queued_tasks [9749,9761]
name: queued_tasks [9749,9761]
===
match
---
name: datetime [7229,7237]
name: datetime [7229,7237]
===
match
---
name: CeleryExecutor [11638,11652]
name: CeleryExecutor [11638,11652]
===
match
---
simple_stmt [14257,14301]
simple_stmt [14257,14301]
===
match
---
trailer [19525,19534]
trailer [20235,20244]
===
match
---
operator: @ [18161,18162]
operator: @ [18427,18428]
===
match
---
name: pytest [18203,18209]
name: pytest [18469,18475]
===
match
---
testlist_comp [11996,12030]
testlist_comp [11996,12030]
===
match
---
string: 'celery' [2398,2406]
string: 'celery' [2398,2406]
===
match
---
name: executor [7066,7074]
name: executor [7066,7074]
===
match
---
name: State [6022,6027]
name: State [6022,6027]
===
match
---
name: mock [19327,19331]
name: mock [19915,19919]
===
match
---
expr_stmt [19312,19363]
expr_stmt [19900,19951]
===
match
---
trailer [5223,5239]
trailer [5223,5239]
===
match
---
name: tasks [11002,11007]
name: tasks [11002,11007]
===
match
---
expr_stmt [15970,16041]
expr_stmt [15970,16041]
===
match
---
operator: = [8954,8955]
operator: = [8954,8955]
===
match
---
comparison [14925,14997]
comparison [14925,14997]
===
match
---
operator: = [7651,7652]
operator: = [7651,7652]
===
match
---
name: patch_app [2711,2720]
name: patch_app [2711,2720]
===
match
---
trailer [9211,9221]
trailer [9211,9221]
===
match
---
simple_stmt [14671,14713]
simple_stmt [14671,14713]
===
match
---
name: datetime [13051,13059]
name: datetime [13051,13059]
===
match
---
assert_stmt [16074,16164]
assert_stmt [16074,16164]
===
match
---
atom_expr [15855,15885]
atom_expr [15855,15885]
===
match
---
atom_expr [2923,2956]
atom_expr [2923,2956]
===
match
---
fstring_expr [16680,16700]
fstring_expr [16680,16700]
===
match
---
param [2198,2202]
param [2198,2202]
===
match
---
arith_expr [13593,13630]
arith_expr [13593,13630]
===
match
---
operator: { [14943,14944]
operator: { [14943,14944]
===
match
---
name: when [9032,9036]
name: when [9032,9036]
===
match
---
trailer [4498,4505]
trailer [4498,4505]
===
match
---
atom [10259,10261]
atom [10259,10261]
===
match
---
name: backend [3905,3912]
name: backend [3905,3912]
===
match
---
name: backend [12918,12925]
name: backend [12918,12925]
===
match
---
atom_expr [18963,18992]
atom_expr [19391,19420]
===
match
---
import_as_names [1118,1155]
import_as_names [1118,1155]
===
match
---
comparison [14409,14429]
comparison [14409,14429]
===
match
---
trailer [12247,12329]
trailer [12247,12329]
===
match
---
name: QUEUED [6155,6161]
name: QUEUED [6155,6161]
===
match
---
string: "mysql" [12926,12933]
string: "mysql" [12926,12933]
===
match
---
string: "task_2" [13899,13907]
string: "task_2" [13899,13907]
===
match
---
name: pytest [10739,10745]
name: pytest [10739,10745]
===
match
---
return_stmt [16796,16834]
return_stmt [16796,16834]
===
match
---
expr_stmt [14086,14143]
expr_stmt [14086,14143]
===
match
---
trailer [12488,12495]
trailer [12488,12495]
===
match
---
suite [3385,3541]
suite [3385,3541]
===
match
---
operator: = [7199,7200]
operator: = [7199,7200]
===
match
---
decorator [7868,7902]
decorator [7868,7902]
===
match
---
name: timedelta [15174,15183]
name: timedelta [15174,15183]
===
match
---
name: tasks [15979,15984]
name: tasks [15979,15984]
===
match
---
argument [13909,13930]
argument [13909,13930]
===
match
---
atom [15820,15961]
atom [15820,15961]
===
match
---
name: queued_dttm [15841,15852]
name: queued_dttm [15841,15852]
===
match
---
string: 'fail' [4988,4994]
string: 'fail' [4988,4994]
===
match
---
arglist [2931,2955]
arglist [2931,2955]
===
match
---
name: log [10913,10916]
name: log [10913,10916]
===
match
---
name: timezone [13593,13601]
name: timezone [13593,13601]
===
match
---
argument [18978,18991]
argument [19406,19419]
===
match
---
trailer [14365,14387]
trailer [14365,14387]
===
match
---
number: 0 [7548,7549]
number: 0 [7548,7549]
===
match
---
name: call [11775,11779]
name: call [11775,11779]
===
match
---
name: State [6404,6409]
name: State [6404,6409]
===
match
---
simple_stmt [13794,13857]
simple_stmt [13794,13857]
===
match
---
name: executor [14257,14265]
name: executor [14257,14265]
===
match
---
string: 'fail' [7808,7814]
string: 'fail' [7808,7814]
===
match
---
trailer [13027,13029]
trailer [13027,13029]
===
match
---
operator: = [2373,2374]
operator: = [2373,2374]
===
match
---
name: pytest [18124,18130]
name: pytest [18390,18396]
===
match
---
name: task_id [18978,18985]
name: task_id [19406,19413]
===
match
---
atom [4610,5281]
atom [4610,5281]
===
match
---
trailer [18441,18447]
trailer [18707,18713]
===
match
---
operator: = [2508,2509]
operator: = [2508,2509]
===
match
---
name: State [6302,6307]
name: State [6302,6307]
===
match
---
string: 'SUCCESS' [19053,19062]
string: 'SUCCESS' [19497,19506]
===
match
---
trailer [17815,17825]
trailer [17937,17947]
===
match
---
number: 1 [19490,19491]
number: 1 [20200,20201]
===
match
---
for_stmt [16530,16602]
for_stmt [16530,16602]
===
match
---
atom_expr [9669,9698]
atom_expr [9669,9698]
===
match
---
name: integration [17130,17141]
name: integration [17130,17141]
===
match
---
atom [5924,6052]
atom [5924,6052]
===
match
---
name: heartbeat [7676,7685]
name: heartbeat [7676,7685]
===
match
---
operator: , [6258,6259]
operator: , [6258,6259]
===
match
---
fstring_expr [10417,10422]
fstring_expr [10417,10422]
===
match
---
simple_stmt [5512,5572]
simple_stmt [5512,5572]
===
match
---
operator: { [17064,17065]
operator: { [17064,17065]
===
match
---
trailer [5730,5736]
trailer [5730,5736]
===
match
---
name: key [10418,10421]
name: key [10418,10421]
===
match
---
parameters [10843,10849]
parameters [10843,10849]
===
match
---
trailer [11718,11723]
trailer [11718,11723]
===
match
---
name: executor [6331,6339]
name: executor [6331,6339]
===
match
---
simple_stmt [15421,15484]
simple_stmt [15421,15484]
===
match
---
argument [8708,8733]
argument [8708,8733]
===
match
---
comparison [14316,14341]
comparison [14316,14341]
===
match
---
name: integration [18174,18185]
name: integration [18440,18451]
===
match
---
name: executor [11611,11619]
name: executor [11611,11619]
===
match
---
atom_expr [7277,7291]
atom_expr [7277,7291]
===
match
---
name: timedelta [6568,6577]
name: timedelta [6568,6577]
===
match
---
argument [18401,18417]
argument [18667,18683]
===
match
---
name: bash_command [8665,8677]
name: bash_command [8665,8677]
===
match
---
name: date [13005,13009]
name: date [13005,13009]
===
match
---
trailer [5736,5741]
trailer [5736,5741]
===
match
---
operator: , [19209,19210]
operator: , [19797,19798]
===
match
---
name: BulkStateFetcher [19473,19489]
name: BulkStateFetcher [20183,20199]
===
match
---
trailer [3534,3540]
trailer [3534,3540]
===
match
---
operator: , [12121,12122]
operator: , [12121,12122]
===
match
---
atom [5404,5442]
atom [5404,5442]
===
match
---
name: other [16820,16825]
name: other [16820,16825]
===
match
---
string: "sqlite3://" [18405,18417]
string: "sqlite3://" [18671,18683]
===
match
---
trailer [13890,13931]
trailer [13890,13931]
===
match
---
trailer [18636,18649]
trailer [19024,19037]
===
match
---
name: set_event_loop [3520,3534]
name: set_event_loop [3520,3534]
===
match
---
name: patch [18055,18060]
name: patch [18321,18326]
===
match
---
atom_expr [5512,5538]
atom_expr [5512,5538]
===
match
---
atom_expr [15920,15950]
atom_expr [15920,15950]
===
match
---
operator: , [18009,18010]
operator: , [18131,18132]
===
match
---
string: 'id' [7211,7215]
string: 'id' [7211,7215]
===
match
---
name: mock_subproc [12820,12832]
name: mock_subproc [12820,12832]
===
match
---
trailer [16825,16834]
trailer [16825,16834]
===
match
---
name: call_args [12833,12842]
name: call_args [12833,12842]
===
match
---
atom_expr [9243,9278]
atom_expr [9243,9278]
===
match
---
arglist [11724,11755]
arglist [11724,11755]
===
match
---
arglist [3913,3932]
arglist [3913,3932]
===
match
---
string: "mysql" [18223,18230]
string: "mysql" [18489,18496]
===
match
---
argument [7196,7216]
argument [7196,7216]
===
match
---
trailer [9668,9699]
trailer [9668,9699]
===
match
---
operator: , [12031,12032]
operator: , [12031,12032]
===
match
---
atom_expr [9813,9834]
atom_expr [9813,9834]
===
match
---
name: task_id [19691,19698]
name: task_id [20401,20408]
===
match
---
trailer [6142,6145]
trailer [6142,6145]
===
match
---
name: backend [2931,2938]
name: backend [2931,2938]
===
match
---
name: BashOperator [1826,1838]
name: BashOperator [1826,1838]
===
match
---
string: 'backend' [19421,19430]
string: 'backend' [20009,20018]
===
match
---
expr_stmt [2669,2706]
expr_stmt [2669,2706]
===
match
---
arglist [11780,11813]
arglist [11780,11813]
===
match
---
import_name [787,804]
import_name [787,804]
===
match
---
operator: = [13714,13715]
operator: = [13714,13715]
===
match
---
trailer [17954,17964]
trailer [18076,18086]
===
match
---
comparison [7703,7734]
comparison [7703,7734]
===
match
---
name: executor [10466,10474]
name: executor [10466,10474]
===
match
---
decorated [18049,19097]
decorated [18315,19685]
===
match
---
trailer [16318,16336]
trailer [16318,16336]
===
match
---
string: 'fake_simple_ti' [4996,5012]
string: 'fake_simple_ti' [4996,5012]
===
match
---
trailer [11283,11290]
trailer [11283,11290]
===
match
---
suite [2957,3350]
suite [2957,3350]
===
match
---
name: task [7439,7443]
name: task [7439,7443]
===
match
---
atom_expr [13103,13144]
atom_expr [13103,13144]
===
match
---
simple_stmt [11238,11292]
simple_stmt [11238,11292]
===
match
---
operator: = [14032,14033]
operator: = [14032,14033]
===
match
---
trailer [9589,9596]
trailer [9589,9596]
===
match
---
operator: = [19471,19472]
operator: = [20181,20182]
===
match
---
arglist [15443,15482]
arglist [15443,15482]
===
match
---
assert_stmt [9853,10031]
assert_stmt [9853,10031]
===
match
---
name: mock [17955,17959]
name: mock [18077,18081]
===
match
---
string: "123" [17640,17645]
string: "123" [17762,17767]
===
match
---
trailer [17930,17954]
trailer [18052,18076]
===
match
---
name: command [5542,5549]
name: command [5542,5549]
===
match
---
trailer [18545,18559]
trailer [18933,18947]
===
match
---
trailer [8433,8448]
trailer [8433,8448]
===
match
---
name: ti1 [14239,14242]
name: ti1 [14239,14242]
===
match
---
operator: , [4686,4687]
operator: , [4686,4687]
===
match
---
atom_expr [15154,15171]
atom_expr [15154,15171]
===
match
---
simple_stmt [1912,1944]
simple_stmt [1912,1944]
===
match
---
string: '456' [18018,18023]
string: '456' [18140,18145]
===
match
---
operator: , [10702,10703]
operator: , [10702,10703]
===
match
---
atom_expr [15592,15602]
atom_expr [15592,15602]
===
match
---
parameters [3688,3694]
parameters [3688,3694]
===
match
---
name: CeleryExecutor [10964,10978]
name: CeleryExecutor [10964,10978]
===
match
---
name: executor [7563,7571]
name: executor [7563,7571]
===
match
---
operator: = [4481,4482]
operator: = [4481,4482]
===
match
---
operator: , [18287,18288]
operator: , [18553,18554]
===
match
---
simple_stmt [9724,9794]
simple_stmt [9724,9794]
===
match
---
name: parameterized [11940,11953]
name: parameterized [11940,11953]
===
match
---
trailer [10912,10916]
trailer [10912,10916]
===
match
---
trailer [12738,12747]
trailer [12738,12747]
===
match
---
simple_stmt [1701,1791]
simple_stmt [1701,1791]
===
match
---
number: 0 [7840,7841]
number: 0 [7840,7841]
===
match
---
testlist_comp [17617,17702]
testlist_comp [17739,17824]
===
match
---
trailer [4271,4313]
trailer [4271,4313]
===
match
---
with_stmt [17303,17743]
with_stmt [17303,17865]
===
match
---
name: when [7542,7546]
name: when [7542,7546]
===
match
---
name: BaseBackend [1118,1129]
name: BaseBackend [1118,1129]
===
match
---
name: celery_executor [4885,4900]
name: celery_executor [4885,4900]
===
match
---
name: mock [17617,17621]
name: mock [17739,17743]
===
match
---
name: _prepare_app [19284,19296]
name: _prepare_app [19872,19884]
===
match
---
atom_expr [7563,7589]
atom_expr [7563,7589]
===
match
---
name: executor [6450,6458]
name: executor [6450,6458]
===
match
---
name: len [10157,10160]
name: len [10157,10160]
===
match
---
operator: + [15853,15854]
operator: + [15853,15854]
===
match
---
atom [8808,8986]
atom [8808,8986]
===
match
---
simple_stmt [1356,1396]
simple_stmt [1356,1396]
===
match
---
atom_expr [14007,14031]
atom_expr [14007,14031]
===
match
---
trailer [14528,14579]
trailer [14528,14579]
===
match
---
atom_expr [3785,3807]
atom_expr [3785,3807]
===
match
---
comparison [10152,10183]
comparison [10152,10183]
===
match
---
operator: @ [15040,15041]
operator: @ [15040,15041]
===
match
---
atom_expr [18711,18794]
atom_expr [19099,19182]
===
match
---
atom_expr [11151,11229]
atom_expr [11151,11229]
===
match
---
operator: = [19711,19712]
operator: = [20421,20422]
===
match
---
parameters [16504,16520]
parameters [16504,16520]
===
match
---
atom_expr [8202,8393]
atom_expr [8202,8393]
===
match
---
name: AsyncResult [14978,14989]
name: AsyncResult [14978,14989]
===
match
---
name: task_id [13180,13187]
name: task_id [13180,13187]
===
match
---
expr_stmt [17336,17400]
expr_stmt [17336,17400]
===
match
---
name: timezone [13653,13661]
name: timezone [13653,13661]
===
match
---
name: tasks [14418,14423]
name: tasks [14418,14423]
===
match
---
operator: == [16247,16249]
operator: == [16247,16249]
===
match
---
comparison [8470,8505]
comparison [8470,8505]
===
match
---
trailer [13179,13220]
trailer [13179,13220]
===
match
---
funcdef [16763,16835]
funcdef [16763,16835]
===
match
---
operator: } [19841,19842]
operator: } [20551,20552]
===
match
---
operator: , [11589,11590]
operator: , [11589,11590]
===
match
---
arglist [2816,2881]
arglist [2816,2881]
===
match
---
trailer [5160,5182]
trailer [5160,5182]
===
match
---
name: mock_backend [19432,19444]
name: mock_backend [20020,20032]
===
match
---
decorator [11297,11366]
decorator [11297,11366]
===
match
---
trailer [12606,12624]
trailer [12606,12624]
===
match
---
atom_expr [7616,7650]
atom_expr [7616,7650]
===
match
---
name: broker_url [3972,3982]
name: broker_url [3972,3982]
===
match
---
name: key_2 [15899,15904]
name: key_2 [15899,15904]
===
match
---
name: command [12569,12576]
name: command [12569,12576]
===
match
---
atom_expr [19473,19492]
atom_expr [20183,20202]
===
match
---
operator: , [5428,5429]
operator: , [5428,5429]
===
match
---
argument [15518,15534]
argument [15518,15534]
===
match
---
atom_expr [18455,18474]
atom_expr [18721,18740]
===
match
---
name: ResultSession [3310,3323]
name: ResultSession [3310,3323]
===
match
---
operator: = [7075,7076]
operator: = [7075,7076]
===
match
---
operator: , [12855,12856]
operator: , [12855,12856]
===
match
---
trailer [4837,4859]
trailer [4837,4859]
===
match
---
operator: } [14392,14393]
operator: } [14392,14393]
===
match
---
simple_stmt [895,921]
simple_stmt [895,921]
===
match
---
assert_stmt [6426,6464]
assert_stmt [6426,6464]
===
match
---
name: tearDown [3680,3688]
name: tearDown [3680,3688]
===
match
---
name: executor [9053,9061]
name: executor [9053,9061]
===
match
---
decorator [16956,17113]
decorator [16956,17113]
===
match
---
arglist [2398,2420]
arglist [2398,2420]
===
match
---
name: self [16774,16778]
name: self [16774,16778]
===
match
---
expr_stmt [15568,15642]
expr_stmt [15568,15642]
===
match
---
atom_expr [16022,16040]
atom_expr [16022,16040]
===
match
---
operator: = [7443,7444]
operator: = [7443,7444]
===
match
---
name: task_1 [15604,15610]
name: task_1 [15604,15610]
===
match
---
name: models [1626,1632]
name: models [1626,1632]
===
match
---
comparison [17841,17912]
comparison [17963,18034]
===
match
---
operator: = [7166,7167]
operator: = [7166,7167]
===
match
---
operator: = [10946,10947]
operator: = [10946,10947]
===
match
---
simple_stmt [19773,19843]
simple_stmt [20483,20553]
===
match
---
name: task_id [15694,15701]
name: task_id [15694,15701]
===
match
---
atom [13298,13304]
atom [13298,13304]
===
match
---
name: pytest [13425,13431]
name: pytest [13425,13431]
===
match
---
atom_expr [16144,16156]
atom_expr [16144,16156]
===
match
---
comparison [10234,10261]
comparison [10234,10261]
===
match
---
operator: - [15295,15296]
operator: - [15295,15296]
===
match
---
name: start_date [15461,15471]
name: start_date [15461,15471]
===
match
---
name: airflow [1844,1851]
name: airflow [1844,1851]
===
match
---
name: key1 [13299,13303]
name: key1 [13299,13303]
===
match
---
atom_expr [16884,16902]
atom_expr [16884,16902]
===
match
---
string: 'fake_simple_ti' [10686,10702]
string: 'fake_simple_ti' [10686,10702]
===
match
---
string: "status" [18754,18762]
string: "status" [19142,19150]
===
match
---
atom [15987,16041]
atom [15987,16041]
===
match
---
operator: = [14594,14595]
operator: = [14594,14595]
===
match
---
string: "task_1" [13188,13196]
string: "task_1" [13188,13196]
===
match
---
name: task_publish_retries [5601,5621]
name: task_publish_retries [5601,5621]
===
match
---
name: db [1941,1943]
name: db [1941,1943]
===
match
---
atom_expr [10157,10183]
atom_expr [10157,10183]
===
match
---
operator: = [2721,2722]
operator: = [2721,2722]
===
match
---
atom_expr [9248,9277]
atom_expr [9248,9277]
===
match
---
operator: } [17102,17103]
operator: } [17102,17103]
===
match
---
name: celery_executor [5208,5223]
name: celery_executor [5208,5223]
===
match
---
name: side_effect [8352,8363]
name: side_effect [8352,8363]
===
match
---
operator: = [15503,15504]
operator: = [15503,15504]
===
match
---
trailer [7720,7733]
trailer [7720,7733]
===
match
---
name: execute_command [4901,4916]
name: execute_command [4901,4916]
===
match
---
name: line [11211,11215]
name: line [11211,11215]
===
match
---
name: heartbeat [11672,11681]
name: heartbeat [11672,11681]
===
match
---
simple_stmt [9432,9611]
simple_stmt [9432,9611]
===
match
---
argument [7204,7215]
argument [7204,7215]
===
match
---
name: test_command_validation [12084,12107]
name: test_command_validation [12084,12107]
===
match
---
simple_stmt [14505,14580]
simple_stmt [14505,14580]
===
match
---
name: mark [17163,17167]
name: mark [17163,17167]
===
match
---
trailer [7107,7109]
trailer [7107,7109]
===
match
---
name: MagicMock [17677,17686]
name: MagicMock [17799,17808]
===
match
---
suite [4197,4245]
suite [4197,4245]
===
match
---
number: 3 [9709,9710]
number: 3 [9709,9710]
===
match
---
trailer [11652,11654]
trailer [11652,11654]
===
match
---
decorator [17196,17238]
decorator [17196,17238]
===
match
---
name: self [12990,12994]
name: self [12990,12994]
===
match
---
name: self [3689,3693]
name: self [3689,3693]
===
match
---
atom_expr [15505,15558]
atom_expr [15505,15558]
===
match
---
name: BaseOperator [13878,13890]
name: BaseOperator [13878,13890]
===
match
---
comparison [9457,9596]
comparison [9457,9596]
===
match
---
name: executors [1563,1572]
name: executors [1563,1572]
===
match
---
name: dag_id [15679,15685]
name: dag_id [15679,15685]
===
match
---
simple_stmt [4073,4111]
simple_stmt [4073,4111]
===
match
---
comparison [5946,6034]
comparison [5946,6034]
===
match
---
operator: = [9003,9004]
operator: = [9003,9004]
===
match
---
name: db [3739,3741]
name: db [3739,3741]
===
match
---
trailer [6027,6034]
trailer [6027,6034]
===
match
---
operator: = [8765,8766]
operator: = [8765,8766]
===
match
---
atom [17591,17724]
atom [17713,17846]
===
match
---
name: AsyncResult [15995,16006]
name: AsyncResult [15995,16006]
===
match
---
atom_expr [2219,2230]
atom_expr [2219,2230]
===
match
---
operator: - [15235,15236]
operator: - [15235,15236]
===
match
---
assert_stmt [6561,6619]
assert_stmt [6561,6619]
===
match
---
name: days [13081,13085]
name: days [13081,13085]
===
match
---
name: executor [14803,14811]
name: executor [14803,14811]
===
match
---
with_stmt [13727,13932]
with_stmt [13727,13932]
===
match
---
argument [13180,13196]
argument [13180,13196]
===
match
---
name: ti [7423,7425]
name: ti [7423,7425]
===
match
---
trailer [5967,6015]
trailer [5967,6015]
===
match
---
trailer [13560,13571]
trailer [13560,13571]
===
match
---
atom [19790,19842]
atom [20500,20552]
===
match
---
name: success_command [4760,4775]
name: success_command [4760,4775]
===
match
---
param [6778,6782]
param [6778,6782]
===
match
---
param [2326,2342]
param [2326,2342]
===
match
---
simple_stmt [965,1045]
simple_stmt [965,1045]
===
match
---
name: pytest [19182,19188]
name: pytest [19770,19776]
===
match
---
name: command [12739,12746]
name: command [12739,12746]
===
match
---
string: '123' [19791,19796]
string: '123' [20501,20506]
===
match
---
decorated [11297,11934]
decorated [11297,11934]
===
match
---
parameters [19263,19269]
parameters [19851,19857]
===
match
---
name: patch [16962,16967]
name: patch [16962,16967]
===
match
---
atom_expr [15297,15318]
atom_expr [15297,15318]
===
match
---
testlist_comp [16144,16162]
testlist_comp [16144,16162]
===
match
---
fstring [16641,16702]
fstring [16641,16702]
===
match
---
operator: = [2803,2804]
operator: = [2803,2804]
===
match
---
name: pytest [7869,7875]
name: pytest [7869,7875]
===
match
---
name: executor [9740,9748]
name: executor [9740,9748]
===
match
---
simple_stmt [1839,1874]
simple_stmt [1839,1874]
===
match
---
trailer [3641,3643]
trailer [3641,3643]
===
match
---
decorator [13424,13466]
decorator [13424,13466]
===
match
---
suite [8036,10733]
suite [8036,10733]
===
match
---
operator: , [14649,14650]
operator: , [14649,14650]
===
match
---
name: task_publish_retries [10099,10119]
name: task_publish_retries [10099,10119]
===
match
---
string: "mysql" [19202,19209]
string: "mysql" [19790,19797]
===
match
---
argument [13198,13219]
argument [13198,13219]
===
match
---
name: fetcher [19463,19470]
name: fetcher [20173,20180]
===
match
---
atom [14943,14997]
atom [14943,14997]
===
match
---
name: event_buffer [10664,10676]
name: event_buffer [10664,10676]
===
match
---
operator: = [13165,13166]
operator: = [13165,13166]
===
match
---
string: """Class for testing purpose: allows to create objects with custom attributes in one single statement.""" [16381,16486]
string: """Class for testing purpose: allows to create objects with custom attributes in one single statement.""" [16381,16486]
===
match
---
atom_expr [2109,2141]
atom_expr [2109,2141]
===
match
---
operator: , [7345,7346]
operator: , [7345,7346]
===
match
---
name: start_date [15547,15557]
name: start_date [15547,15557]
===
match
---
name: TaskInstanceKey [14596,14611]
name: TaskInstanceKey [14596,14611]
===
match
---
simple_stmt [5648,5693]
simple_stmt [5648,5693]
===
match
---
simple_stmt [15263,15319]
simple_stmt [15263,15319]
===
match
---
operator: , [18474,18475]
operator: , [18740,18741]
===
match
---
fstring [9530,9583]
fstring [9530,9583]
===
match
---
param [3602,3606]
param [3602,3606]
===
match
---
trailer [7092,7107]
trailer [7092,7107]
===
match
---
trailer [7203,7216]
trailer [7203,7216]
===
match
---
atom_expr [19582,19639]
atom_expr [20292,20349]
===
match
---
name: task_publish_retries [8479,8499]
name: task_publish_retries [8479,8499]
===
match
---
name: mock [18050,18054]
name: mock [18316,18320]
===
match
---
name: ANY [11752,11755]
name: ANY [11752,11755]
===
match
---
simple_stmt [4430,4447]
simple_stmt [4430,4447]
===
match
---
name: exec_date [14557,14566]
name: exec_date [14557,14566]
===
match
---
name: celery [972,978]
name: celery [972,978]
===
match
---
string: "SUCCESS" [17075,17084]
string: "SUCCESS" [17075,17084]
===
match
---
number: 2 [9288,9289]
number: 2 [9288,9289]
===
match
---
atom_expr [7404,7481]
atom_expr [7404,7481]
===
match
---
trailer [18848,18850]
trailer [19244,19246]
===
match
---
atom_expr [2723,2784]
atom_expr [2723,2784]
===
match
---
atom_expr [7712,7733]
atom_expr [7712,7733]
===
match
---
sync_comp_for [11207,11228]
sync_comp_for [11207,11228]
===
match
---
dotted_name [12906,12925]
dotted_name [12906,12925]
===
match
---
if_stmt [1978,2096]
if_stmt [1978,2096]
===
match
---
name: ClassWithCustomAttributes [19665,19690]
name: ClassWithCustomAttributes [20375,20400]
===
match
---
argument [13081,13087]
argument [13081,13087]
===
match
---
operator: , [14555,14556]
operator: , [14555,14556]
===
match
---
trailer [6458,6464]
trailer [6458,6464]
===
match
---
name: key [9704,9707]
name: key [9704,9707]
===
match
---
argument [4507,4522]
argument [4507,4522]
===
match
---
assert_stmt [9432,9610]
assert_stmt [9432,9610]
===
match
---
operator: } [18042,18043]
operator: } [18164,18165]
===
match
---
name: AsyncResult [14951,14962]
name: AsyncResult [14951,14962]
===
match
---
name: output [10432,10438]
name: output [10432,10438]
===
match
---
name: celery [1277,1283]
name: celery [1277,1283]
===
match
---
name: heartbeat [9633,9642]
name: heartbeat [9633,9642]
===
match
---
atom_expr [13593,13610]
atom_expr [13593,13610]
===
match
---
name: broker_url [2375,2385]
name: broker_url [2375,2385]
===
match
---
name: celery_executor [8418,8433]
name: celery_executor [8418,8433]
===
match
---
trailer [7793,7806]
trailer [7793,7806]
===
match
---
operator: = [9080,9081]
operator: = [9080,9081]
===
match
---
expr_stmt [13005,13029]
expr_stmt [13005,13029]
===
match
---
expr_stmt [13703,13717]
expr_stmt [13703,13717]
===
match
---
param [17283,17292]
param [17283,17292]
===
match
---
atom [17991,18043]
atom [18113,18165]
===
match
---
expr_stmt [10937,10980]
expr_stmt [10937,10980]
===
match
---
operator: = [14132,14133]
operator: = [14132,14133]
===
match
---
assert_stmt [10274,10452]
assert_stmt [10274,10452]
===
match
---
import_from [1504,1549]
import_from [1504,1549]
===
match
---
operator: } [4416,4417]
operator: } [4416,4417]
===
match
---
name: timeout [8306,8313]
name: timeout [8306,8313]
===
match
---
operator: = [15985,15986]
operator: = [15985,15986]
===
match
---
operator: = [13296,13297]
operator: = [13296,13297]
===
match
---
argument [19342,19362]
argument [19930,19950]
===
match
---
param [11547,11552]
param [11547,11552]
===
match
---
name: fail_command [4073,4085]
name: fail_command [4073,4085]
===
match
---
trailer [12357,12411]
trailer [12357,12411]
===
match
---
name: mock_session [18618,18630]
name: mock_session [19006,19018]
===
match
---
atom_expr [16216,16246]
atom_expr [16216,16246]
===
match
---
trailer [17621,17631]
trailer [17743,17753]
===
match
---
param [17277,17282]
param [17277,17282]
===
match
---
name: ti2 [14244,14247]
name: ti2 [14244,14247]
===
match
---
arith_expr [14789,14833]
arith_expr [14789,14833]
===
match
---
name: heartbeat [9212,9221]
name: heartbeat [9212,9221]
===
match
---
name: executor [5648,5656]
name: executor [5648,5656]
===
match
---
name: SimpleTaskInstance [7404,7422]
name: SimpleTaskInstance [7404,7422]
===
match
---
atom [9860,10031]
atom [9860,10031]
===
match
---
trailer [9400,9413]
trailer [9400,9413]
===
match
---
decorated [13424,15035]
decorated [13424,15035]
===
match
---
trailer [11109,11134]
trailer [11109,11134]
===
match
---
name: DAG [7200,7203]
name: DAG [7200,7203]
===
match
---
suite [13145,13221]
suite [13145,13221]
===
match
---
trailer [12241,12247]
trailer [12241,12247]
===
match
---
operator: == [16103,16105]
operator: == [16103,16105]
===
match
---
param [13504,13508]
param [13504,13508]
===
match
---
name: state [19623,19628]
name: state [20333,20338]
===
match
---
string: 'airflow.executors.celery_executor.app' [2734,2773]
string: 'airflow.executors.celery_executor.app' [2734,2773]
===
match
---
comparison [19034,19096]
comparison [19478,19540]
===
match
---
fstring_expr [9996,10001]
fstring_expr [9996,10001]
===
match
---
assert_stmt [6518,6552]
assert_stmt [6518,6552]
===
match
---
string: 'fail' [9006,9012]
string: 'fail' [9006,9012]
===
match
---
operator: , [12044,12045]
operator: , [12044,12045]
===
match
---
operator: - [13549,13550]
operator: - [13549,13550]
===
match
---
atom [16106,16164]
atom [16106,16164]
===
match
---
dotted_name [1402,1423]
dotted_name [1402,1423]
===
match
---
name: test_execute [2869,2881]
name: test_execute [2869,2881]
===
match
---
operator: , [8854,8855]
operator: , [8854,8855]
===
match
---
name: celery_executor [10948,10963]
name: celery_executor [10948,10963]
===
match
---
param [16851,16856]
param [16851,16856]
===
match
---
suite [4524,6210]
suite [4524,6210]
===
match
---
parameters [6817,6819]
parameters [6817,6819]
===
match
---
param [4145,4152]
param [4145,4152]
===
match
---
param [16780,16785]
param [16780,16785]
===
match
---
name: executor [5946,5954]
name: executor [5946,5954]
===
match
---
name: query [18631,18636]
name: query [19019,19024]
===
match
---
operator: , [5996,5997]
operator: , [5996,5997]
===
match
---
decorators [11297,11511]
decorators [11297,11511]
===
match
---
testlist_comp [12034,12067]
testlist_comp [12034,12067]
===
match
---
atom [6353,6396]
atom [6353,6396]
===
match
---
name: url [2034,2037]
name: url [2034,2037]
===
match
---
name: key_2 [14847,14852]
name: key_2 [14847,14852]
===
match
---
simple_stmt [3993,4065]
simple_stmt [3993,4065]
===
match
---
operator: , [4045,4046]
operator: , [4045,4046]
===
match
---
number: 1 [5551,5552]
number: 1 [5551,5552]
===
match
---
import_name [817,826]
import_name [817,826]
===
match
---
string: "rabbitmq" [3876,3886]
string: "rabbitmq" [3876,3886]
===
match
---
name: TestCase [3577,3585]
name: TestCase [3577,3585]
===
match
---
number: 1 [16340,16341]
number: 1 [16340,16341]
===
match
---
trailer [4360,4375]
trailer [4360,4375]
===
match
---
number: 600 [6581,6584]
number: 600 [6581,6584]
===
match
---
with_stmt [8137,10733]
with_stmt [8137,10733]
===
match
---
atom_expr [11245,11291]
atom_expr [11245,11291]
===
match
---
name: execution_date [8940,8954]
name: execution_date [8940,8954]
===
match
---
trailer [10725,10732]
trailer [10725,10732]
===
match
---
name: start_date [15472,15482]
name: start_date [15472,15482]
===
match
---
name: sys [834,837]
name: sys [834,837]
===
match
---
atom_expr [11219,11228]
atom_expr [11219,11228]
===
match
---
name: tests [1917,1922]
name: tests [1917,1922]
===
match
---
number: 4 [10130,10131]
number: 4 [10130,10131]
===
match
---
argument [13683,13692]
argument [13683,13692]
===
match
---
atom_expr [8525,8558]
atom_expr [8525,8558]
===
match
---
name: ClassWithCustomAttributes [16644,16669]
name: ClassWithCustomAttributes [16644,16669]
===
match
---
testlist_comp [4988,5029]
testlist_comp [4988,5029]
===
match
---
arglist [14529,14578]
arglist [14529,14578]
===
match
---
trailer [16747,16755]
trailer [16747,16755]
===
match
---
name: task [7444,7448]
name: task [7444,7448]
===
match
---
operator: , [11756,11757]
operator: , [11756,11757]
===
match
---
name: FakeCeleryResult [11018,11034]
name: FakeCeleryResult [11018,11034]
===
match
---
name: patch [12242,12247]
name: patch [12242,12247]
===
match
---
name: kwargs [16513,16519]
name: kwargs [16513,16519]
===
match
---
trailer [16224,16246]
trailer [16224,16246]
===
match
---
name: queued_dttm [15906,15917]
name: queued_dttm [15906,15917]
===
match
---
suite [3398,3426]
suite [3398,3426]
===
match
---
string: 'fail' [7516,7522]
string: 'fail' [7516,7522]
===
match
---
decorator [3763,3809]
decorator [3763,3809]
===
match
---
trailer [12832,12842]
trailer [12832,12842]
===
match
---
operator: , [5881,5882]
operator: , [5881,5882]
===
match
---
operator: , [5408,5409]
operator: , [5408,5409]
===
match
---
arglist [19608,19638]
arglist [20318,20348]
===
match
---
name: mock [19382,19386]
name: mock [19970,19974]
===
match
---
name: CeleryExecutor [7093,7107]
name: CeleryExecutor [7093,7107]
===
match
---
operator: , [12895,12896]
operator: , [12895,12896]
===
match
---
simple_stmt [13158,13221]
simple_stmt [13158,13221]
===
match
---
name: task_id [18931,18938]
name: task_id [19351,19358]
===
match
---
suite [16951,19843]
suite [16951,20697]
===
match
---
name: executor [10655,10663]
name: executor [10655,10663]
===
match
---
string: "test_try_adopt_task_instances_none" [13736,13772]
string: "test_try_adopt_task_instances_none" [13736,13772]
===
match
---
arith_expr [13531,13571]
arith_expr [13531,13571]
===
match
---
operator: = [11008,11009]
operator: = [11008,11009]
===
match
---
name: executor [10937,10945]
name: executor [10937,10945]
===
match
---
name: mock_session [18289,18301]
name: mock_session [18555,18567]
===
match
---
testlist_comp [5969,6013]
testlist_comp [5969,6013]
===
match
---
name: event_buffer [10243,10255]
name: event_buffer [10243,10255]
===
match
---
operator: , [19062,19063]
operator: , [19506,19507]
===
match
---
suite [12143,12900]
suite [12143,12900]
===
match
---
name: executor [10161,10169]
name: executor [10161,10169]
===
match
---
operator: , [8684,8685]
operator: , [8684,8685]
===
match
---
operator: , [16537,16538]
operator: , [16537,16538]
===
match
---
name: utcnow [13540,13546]
name: utcnow [13540,13546]
===
match
---
string: 'ResultSession' [2940,2955]
string: 'ResultSession' [2940,2955]
===
match
---
operator: , [12933,12934]
operator: , [12933,12934]
===
match
---
name: key [7509,7512]
name: key [7509,7512]
===
match
---
arglist [18376,18417]
arglist [18642,18683]
===
match
---
name: cm [10921,10923]
name: cm [10921,10923]
===
match
---
operator: @ [7947,7948]
operator: @ [7947,7948]
===
match
---
operator: , [1759,1760]
operator: , [1759,1760]
===
match
---
operator: , [4775,4776]
operator: , [4775,4776]
===
match
---
operator: , [12061,12062]
operator: , [12061,12062]
===
match
---
name: utcnow [13602,13608]
name: utcnow [13602,13608]
===
match
---
name: executor [6589,6597]
name: executor [6589,6597]
===
match
---
trailer [14490,14495]
trailer [14490,14495]
===
match
---
decorated [2174,2231]
decorated [2174,2231]
===
match
---
trailer [19386,19392]
trailer [19974,19980]
===
match
---
dotted_name [3764,3784]
dotted_name [3764,3784]
===
match
---
string: "456" [17695,17700]
string: "456" [17817,17822]
===
match
---
name: pytest [3893,3899]
name: pytest [3893,3899]
===
match
---
simple_stmt [7616,7655]
simple_stmt [7616,7655]
===
match
---
trailer [10053,10063]
trailer [10053,10063]
===
match
---
comparison [9310,9341]
comparison [9310,9341]
===
match
---
atom_expr [12863,12882]
atom_expr [12863,12882]
===
match
---
trailer [18375,18418]
trailer [18641,18684]
===
match
---
trailer [4375,4377]
trailer [4375,4377]
===
match
---
name: event_buffer [6340,6352]
name: event_buffer [6340,6352]
===
match
---
param [8030,8034]
param [8030,8034]
===
match
---
parameters [1970,1972]
parameters [1970,1972]
===
match
---
name: celery_executor [8290,8305]
name: celery_executor [8290,8305]
===
match
---
expr_stmt [2496,2552]
expr_stmt [2496,2552]
===
match
---
name: start_date [13845,13855]
name: start_date [13845,13855]
===
match
---
operator: @ [12905,12906]
operator: @ [12905,12906]
===
match
---
name: task_2 [13869,13875]
name: task_2 [13869,13875]
===
match
---
operator: , [17224,17225]
operator: , [17224,17225]
===
match
---
name: celery_configuration [2531,2551]
name: celery_configuration [2531,2551]
===
match
---
fstring_string: ). [10422,10424]
fstring_string: ). [10422,10424]
===
match
---
decorated [7868,10733]
decorated [7868,10733]
===
match
---
assert_stmt [9236,9290]
assert_stmt [9236,9290]
===
match
---
name: key [10125,10128]
name: key [10125,10128]
===
match
---
name: object [18448,18454]
name: object [18714,18720]
===
match
---
decorator [3813,3847]
decorator [3813,3847]
===
match
---
name: key_1 [15988,15993]
name: key_1 [15988,15993]
===
match
---
name: self [19264,19268]
name: self [19852,19856]
===
match
---
name: timezone [15217,15225]
name: timezone [15217,15225]
===
match
---
assert_stmt [14721,14909]
assert_stmt [14721,14909]
===
match
---
fstring [9951,10004]
fstring [9951,10004]
===
match
---
atom_expr [17806,17825]
atom_expr [17928,17947]
===
match
---
name: dict [14728,14732]
name: dict [14728,14732]
===
match
---
name: result [19780,19786]
name: result [20490,20496]
===
match
---
name: expand [11954,11960]
name: expand [11954,11960]
===
match
---
atom_expr [6226,6298]
atom_expr [6226,6298]
===
match
---
classdef [2146,2280]
classdef [2146,2280]
===
match
---
string: "postgres" [10797,10807]
string: "postgres" [10797,10807]
===
match
---
atom [17862,17912]
atom [17984,18034]
===
match
---
atom_expr [3520,3540]
atom_expr [3520,3540]
===
match
---
trailer [2692,2697]
trailer [2692,2697]
===
match
---
name: executor [15787,15795]
name: executor [15787,15795]
===
match
---
name: task [13960,13964]
name: task [13960,13964]
===
match
---
name: command [12848,12855]
name: command [12848,12855]
===
match
---
name: clear_db_runs [3715,3728]
name: clear_db_runs [3715,3728]
===
match
---
trailer [19341,19363]
trailer [19929,19951]
===
match
---
param [11591,11600]
param [11591,11600]
===
match
---
name: celery_configuration [5140,5160]
name: celery_configuration [5140,5160]
===
match
---
name: executor [7785,7793]
name: executor [7785,7793]
===
match
---
assert_stmt [6473,6508]
assert_stmt [6473,6508]
===
match
---
string: "mysql" [6725,6732]
string: "mysql" [6725,6732]
===
match
---
operator: } [8504,8505]
operator: } [8504,8505]
===
match
---
trailer [13106,13144]
trailer [13106,13144]
===
match
---
import_from [1701,1790]
import_from [1701,1790]
===
match
---
expr_stmt [13794,13856]
expr_stmt [13794,13856]
===
match
---
name: execute [2426,2433]
name: execute [2426,2433]
===
match
---
suite [3703,3758]
suite [3703,3758]
===
match
---
operator: , [17281,17282]
operator: , [17281,17282]
===
match
---
trailer [10885,10896]
trailer [10885,10896]
===
match
---
operator: , [8313,8314]
operator: , [8313,8314]
===
match
---
operator: = [18404,18405]
operator: = [18670,18671]
===
match
---
trailer [13546,13548]
trailer [13546,13548]
===
match
---
sync_comp_for [2040,2094]
sync_comp_for [2040,2094]
===
match
---
simple_stmt [4334,4378]
simple_stmt [4334,4378]
===
match
---
operator: = [18531,18532]
operator: = [18919,18920]
===
match
---
trailer [10575,10598]
trailer [10575,10598]
===
match
---
fstring_end: " [9582,9583]
fstring_end: " [9582,9583]
===
match
---
name: queued_dttm [14211,14222]
name: queued_dttm [14211,14222]
===
match
---
comparison [16803,16834]
comparison [16803,16834]
===
match
---
name: datetime [8767,8775]
name: datetime [8767,8775]
===
match
---
atom [11970,12069]
atom [11970,12069]
===
match
---
name: dict [10085,10089]
name: dict [10085,10089]
===
match
---
name: dag [14529,14532]
name: dag [14529,14532]
===
match
---
name: mock [16957,16961]
name: mock [16957,16961]
===
match
---
trailer [13735,13773]
trailer [13735,13773]
===
match
---
trailer [10978,10980]
trailer [10978,10980]
===
match
---
string: b'celery-task-meta-456' [17863,17886]
string: b'celery-task-meta-456' [17985,18008]
===
match
---
trailer [6397,6400]
trailer [6397,6400]
===
match
---
name: adopted_task_timeouts [15796,15817]
name: adopted_task_timeouts [15796,15817]
===
match
---
simple_stmt [5917,6053]
simple_stmt [5917,6053]
===
match
---
operator: == [6299,6301]
operator: == [6299,6301]
===
match
---
trailer [13682,13693]
trailer [13682,13693]
===
match
---
name: fake_execute_command [4292,4312]
name: fake_execute_command [4292,4312]
===
match
---
atom_expr [7667,7687]
atom_expr [7667,7687]
===
match
---
operator: , [8835,8836]
operator: , [8835,8836]
===
match
---
atom_expr [3334,3349]
atom_expr [3334,3349]
===
match
---
dotted_name [972,1000]
dotted_name [972,1000]
===
match
---
string: 'broker_url' [2577,2589]
string: 'broker_url' [2577,2589]
===
match
---
trailer [10098,10119]
trailer [10098,10119]
===
match
---
dotted_name [1169,1193]
dotted_name [1169,1193]
===
match
---
import_as_names [1467,1503]
import_as_names [1467,1503]
===
match
---
name: executor [5592,5600]
name: executor [5592,5600]
===
match
---
trailer [8963,8967]
trailer [8963,8967]
===
match
---
operator: , [14539,14540]
operator: , [14539,14540]
===
match
---
atom_expr [9319,9340]
atom_expr [9319,9340]
===
match
---
fstring_string: [Try 1 of 3] Task Timeout Error for Task: ( [9532,9575]
fstring_string: [Try 1 of 3] Task Timeout Error for Task: ( [9532,9575]
===
match
---
number: 0 [6012,6013]
number: 0 [6012,6013]
===
match
---
expr_stmt [15263,15318]
expr_stmt [15263,15318]
===
match
---
operator: = [19698,19699]
operator: = [20408,20409]
===
match
---
trailer [16888,16895]
trailer [16888,16895]
===
match
---
name: environ [2008,2015]
name: environ [2008,2015]
===
match
---
operator: , [10684,10685]
operator: , [10684,10685]
===
match
---
funcdef [2236,2280]
funcdef [2236,2280]
===
match
---
atom_expr [16743,16757]
atom_expr [16743,16757]
===
match
---
trailer [7438,7480]
trailer [7438,7480]
===
match
---
operator: , [13907,13908]
operator: , [13907,13908]
===
match
---
operator: , [2341,2342]
operator: , [2341,2342]
===
match
---
trailer [18649,18656]
trailer [19037,19044]
===
match
---
atom [19556,19745]
atom [20266,20455]
===
match
---
trailer [19296,19298]
trailer [19884,19886]
===
match
---
fstring_string: ). [9580,9582]
fstring_string: ). [9580,9582]
===
match
---
comparison [4170,4196]
comparison [4170,4196]
===
match
---
trailer [3627,3641]
trailer [3627,3641]
===
match
---
name: len [7708,7711]
name: len [7708,7711]
===
match
---
param [16857,16862]
param [16857,16862]
===
match
---
name: key [5405,5408]
name: key [5405,5408]
===
match
---
trailer [8727,8731]
trailer [8727,8731]
===
match
---
dotted_name [1917,1933]
dotted_name [1917,1933]
===
match
---
expr_stmt [15496,15558]
expr_stmt [15496,15558]
===
match
---
operator: @ [11297,11298]
operator: @ [11297,11298]
===
match
---
name: sys [4495,4498]
name: sys [4495,4498]
===
match
---
string: 'version' [12008,12017]
string: 'version' [12008,12017]
===
match
---
name: __str__ [16748,16755]
name: __str__ [16748,16755]
===
match
---
simple_stmt [9385,9420]
simple_stmt [9385,9420]
===
match
---
expr_stmt [13580,13630]
expr_stmt [13580,13630]
===
match
---
import_from [1310,1355]
import_from [1310,1355]
===
match
---
suite [4154,4245]
suite [4154,4245]
===
match
---
name: self [6778,6782]
name: self [6778,6782]
===
match
---
name: key [9075,9078]
name: key [9075,9078]
===
match
---
operator: = [15450,15451]
operator: = [15450,15451]
===
match
---
atom_expr [19400,19419]
atom_expr [19988,20007]
===
match
---
trailer [18395,18399]
trailer [18661,18665]
===
match
---
name: test_celery_integration [3942,3965]
name: test_celery_integration [3942,3965]
===
match
---
name: celery [1064,1070]
name: celery [1064,1070]
===
match
---
operator: , [6105,6106]
operator: , [6105,6106]
===
match
---
with_stmt [10860,11135]
with_stmt [10860,11135]
===
match
---
name: task_id [17632,17639]
name: task_id [17754,17761]
===
match
---
testlist_comp [5405,5441]
testlist_comp [5405,5441]
===
match
---
import_from [1874,1911]
import_from [1874,1911]
===
match
---
operator: = [4554,4555]
operator: = [4554,4555]
===
match
---
operator: == [10154,10156]
operator: == [10154,10156]
===
match
---
atom_expr [13167,13220]
atom_expr [13167,13220]
===
match
---
simple_stmt [1791,1839]
simple_stmt [1791,1839]
===
match
---
atom [16198,16200]
atom [16198,16200]
===
match
---
suite [3616,3671]
suite [3616,3671]
===
match
---
operator: == [8500,8502]
operator: == [8500,8502]
===
match
---
number: 0 [10714,10715]
number: 0 [10714,10715]
===
match
---
name: __wrapped__ [2479,2490]
name: __wrapped__ [2479,2490]
===
match
---
operator: , [5026,5027]
operator: , [5026,5027]
===
match
---
trailer [9821,9834]
trailer [9821,9834]
===
match
---
operator: , [5780,5781]
operator: , [5780,5781]
===
match
---
expr_stmt [19509,19763]
expr_stmt [20219,20473]
===
match
---
comparison [1981,2015]
comparison [1981,2015]
===
match
---
operator: @ [19181,19182]
operator: @ [19769,19770]
===
match
---
operator: , [4668,4669]
operator: , [4668,4669]
===
match
---
atom_expr [11018,11036]
atom_expr [11018,11036]
===
match
---
expr_stmt [4588,5281]
expr_stmt [4588,5281]
===
match
---
trailer [7571,7584]
trailer [7571,7584]
===
match
---
name: task_2 [15496,15502]
name: task_2 [15496,15502]
===
match
---
name: log [8190,8193]
name: log [8190,8193]
===
match
---
name: assertLogs [10886,10896]
name: assertLogs [10886,10896]
===
match
---
suite [3587,16253]
suite [3587,16253]
===
match
---
simple_stmt [6426,6465]
simple_stmt [6426,6465]
===
match
---
number: 2 [15252,15253]
number: 2 [15252,15253]
===
match
---
string: 'task_default_queue' [5161,5181]
string: 'task_default_queue' [5161,5181]
===
match
---
atom_expr [17380,17399]
atom_expr [17380,17399]
===
match
---
operator: = [13187,13188]
operator: = [13187,13188]
===
match
---
name: fail_command [5086,5098]
name: fail_command [5086,5098]
===
match
---
name: output [11222,11228]
name: output [11222,11228]
===
match
---
arglist [8649,8733]
arglist [8649,8733]
===
match
---
dictorsetmaker [17065,17102]
dictorsetmaker [17065,17102]
===
match
---
name: output [11284,11290]
name: output [11284,11290]
===
match
---
name: get_many [18876,18884]
name: get_many [19280,19288]
===
match
---
dotted_name [16957,16967]
dotted_name [16957,16967]
===
match
---
string: 'fake_simple_ti' [6107,6123]
string: 'fake_simple_ti' [6107,6123]
===
match
---
argument [8352,8382]
argument [8352,8382]
===
match
---
name: queued_dttm [15263,15274]
name: queued_dttm [15263,15274]
===
match
---
name: timezone [13531,13539]
name: timezone [13531,13539]
===
match
---
name: patch_execute [3371,3384]
name: patch_execute [3371,3384]
===
match
---
name: executor [4430,4438]
name: executor [4430,4438]
===
match
---
trailer [13020,13027]
trailer [13020,13027]
===
match
---
argument [13623,13629]
argument [13623,13629]
===
match
---
arglist [18223,18242]
arglist [18489,18508]
===
match
---
atom_expr [13012,13029]
atom_expr [13012,13029]
===
match
---
trailer [6339,6352]
trailer [6339,6352]
===
match
---
trailer [6352,6397]
trailer [6352,6397]
===
match
---
argument [4478,4485]
argument [4478,4485]
===
match
---
with_stmt [4460,6210]
with_stmt [4460,6210]
===
match
---
name: test_config [2496,2507]
name: test_config [2496,2507]
===
match
---
simple_stmt [11050,11135]
simple_stmt [11050,11135]
===
match
---
expr_stmt [3993,4064]
expr_stmt [3993,4064]
===
match
---
operator: @ [13424,13425]
operator: @ [13424,13425]
===
match
---
name: mock_backend [18345,18357]
name: mock_backend [18611,18623]
===
match
---
string: 'fake_simple_ti' [4670,4686]
string: 'fake_simple_ti' [4670,4686]
===
match
---
name: self [16505,16509]
name: self [16505,16509]
===
match
---
with_item [13732,13780]
with_item [13732,13780]
===
match
---
simple_stmt [9853,10032]
simple_stmt [9853,10032]
===
match
---
name: environ [2054,2061]
name: environ [2054,2061]
===
match
---
trailer [13249,13283]
trailer [13249,13283]
===
match
---
operator: = [13651,13652]
operator: = [13651,13652]
===
match
---
operator: , [4282,4283]
operator: , [4282,4283]
===
match
---
atom_expr [13878,13931]
atom_expr [13878,13931]
===
match
---
operator: == [7705,7707]
operator: == [7705,7707]
===
match
---
operator: { [14698,14699]
operator: { [14698,14699]
===
match
---
dotted_name [1222,1251]
dotted_name [1222,1251]
===
match
---
name: call_args [17816,17825]
name: call_args [17938,17947]
===
match
---
trailer [17844,17858]
trailer [17966,17980]
===
match
---
decorators [10738,10809]
decorators [10738,10809]
===
match
---
assert_stmt [5710,5900]
assert_stmt [5710,5900]
===
match
---
name: test_execute [2669,2681]
name: test_execute [2669,2681]
===
match
---
simple_stmt [6324,6417]
simple_stmt [6324,6417]
===
match
---
dotted_name [1509,1526]
dotted_name [1509,1526]
===
match
---
operator: == [9279,9281]
operator: == [9279,9281]
===
match
---
arglist [15675,15724]
arglist [15675,15724]
===
match
---
testlist_comp [5771,5815]
testlist_comp [5771,5815]
===
match
---
name: key [9283,9286]
name: key [9283,9286]
===
match
---
name: line [11202,11206]
name: line [11202,11206]
===
match
---
simple_stmt [1666,1701]
simple_stmt [1666,1701]
===
match
---
name: executor [8470,8478]
name: executor [8470,8478]
===
match
---
string: "mysql" [15061,15068]
string: "mysql" [15061,15068]
===
match
---
dotted_name [6626,6649]
dotted_name [6626,6649]
===
match
---
operator: = [15152,15153]
operator: = [15152,15153]
===
match
---
testlist_star_expr [17791,17803]
testlist_star_expr [17913,17925]
===
match
---
atom_expr [7465,7479]
atom_expr [7465,7479]
===
match
---
simple_stmt [1504,1550]
simple_stmt [1504,1550]
===
match
---
operator: == [14695,14697]
operator: == [14695,14697]
===
match
---
trailer [17854,17857]
trailer [17976,17979]
===
match
---
simple_stmt [17974,18044]
simple_stmt [18096,18166]
===
match
---
trailer [12872,12882]
trailer [12872,12882]
===
match
---
simple_stmt [2711,2785]
simple_stmt [2711,2785]
===
match
---
atom_expr [2619,2664]
atom_expr [2619,2664]
===
match
---
name: mark [19148,19152]
name: mark [19736,19740]
===
match
---
trailer [16063,16065]
trailer [16063,16065]
===
match
---
trailer [13406,13411]
trailer [13406,13411]
===
match
---
atom [19044,19096]
atom [19488,19540]
===
match
---
name: CeleryExecutor [8434,8448]
name: CeleryExecutor [8434,8448]
===
match
---
trailer [2462,2478]
trailer [2462,2478]
===
match
---
trailer [19607,19639]
trailer [20317,20349]
===
match
---
name: airflow [1402,1409]
name: airflow [1402,1409]
===
match
---
arglist [13250,13282]
arglist [13250,13282]
===
match
---
funcdef [7993,10733]
funcdef [7993,10733]
===
match
---
parameters [6777,6783]
parameters [6777,6783]
===
match
---
operator: = [8689,8690]
operator: = [8689,8690]
===
match
---
operator: , [7546,7547]
operator: , [7546,7547]
===
match
---
name: task_adoption_timeout [6598,6619]
name: task_adoption_timeout [6598,6619]
===
match
---
string: 'command' [7336,7345]
string: 'command' [7336,7345]
===
match
---
simple_stmt [2608,2665]
simple_stmt [2608,2665]
===
match
---
return_stmt [2100,2143]
return_stmt [2100,2143]
===
match
---
atom_expr [15430,15483]
atom_expr [15430,15483]
===
match
---
simple_stmt [11611,11655]
simple_stmt [11611,11655]
===
match
---
name: key_2 [14971,14976]
name: key_2 [14971,14976]
===
match
---
trailer [14104,14143]
trailer [14104,14143]
===
match
---
name: self [16851,16855]
name: self [16851,16855]
===
match
---
operator: , [3970,3971]
operator: , [3970,3971]
===
match
---
atom_expr [19327,19363]
atom_expr [19915,19951]
===
match
---
name: queued_tasks [9328,9340]
name: queued_tasks [9328,9340]
===
match
---
name: calls [11927,11932]
name: calls [11927,11932]
===
match
---
trailer [7237,7241]
trailer [7237,7241]
===
match
---
atom_expr [6022,6034]
atom_expr [6022,6034]
===
match
---
assert_stmt [10499,10547]
assert_stmt [10499,10547]
===
match
---
operator: , [5549,5550]
operator: , [5549,5550]
===
match
---
testlist_comp [12888,12896]
testlist_comp [12888,12896]
===
match
---
dotted_name [17156,17179]
dotted_name [17156,17179]
===
match
---
name: dag [13777,13780]
name: dag [13777,13780]
===
match
---
dotted_name [3814,3837]
dotted_name [3814,3837]
===
match
---
name: command [12888,12895]
name: command [12888,12895]
===
match
---
trailer [15169,15171]
trailer [15169,15171]
===
match
---
string: "test_check_for_stalled_adopted_tasks" [15361,15399]
string: "test_check_for_stalled_adopted_tasks" [15361,15399]
===
match
---
name: contrib [979,986]
name: contrib [979,986]
===
match
---
operator: , [6137,6138]
operator: , [6137,6138]
===
match
---
atom_expr [4885,4916]
atom_expr [4885,4916]
===
match
---
name: bash_command [7175,7187]
name: bash_command [7175,7187]
===
match
---
simple_stmt [9236,9291]
simple_stmt [9236,9291]
===
match
---
dictorsetmaker [19791,19841]
dictorsetmaker [20501,20551]
===
match
---
name: _prepare_app [18317,18329]
name: _prepare_app [18583,18595]
===
match
---
name: AirflowException [1467,1483]
name: AirflowException [1467,1483]
===
match
---
argument [13561,13570]
argument [13561,13570]
===
match
---
operator: = [15546,15547]
operator: = [15546,15547]
===
match
---
operator: , [12053,12054]
operator: , [12053,12054]
===
match
---
simple_stmt [14007,14040]
simple_stmt [14007,14040]
===
match
---
simple_stmt [2496,2553]
simple_stmt [2496,2553]
===
match
---
name: executor [15970,15978]
name: executor [15970,15978]
===
match
---
name: ValueError [11982,11992]
name: ValueError [11982,11992]
===
match
---
arglist [14612,14661]
arglist [14612,14661]
===
match
---
trailer [19415,19419]
trailer [20003,20007]
===
match
---
name: DatabaseBackend [18360,18375]
name: DatabaseBackend [18626,18641]
===
match
---
name: now [4565,4568]
name: now [4565,4568]
===
match
---
name: test_should_support_base_backend [19231,19263]
name: test_should_support_base_backend [19819,19851]
===
match
---
operator: == [17988,17990]
operator: == [18110,18112]
===
match
---
atom [9703,9711]
atom [9703,9711]
===
match
---
simple_stmt [10466,10487]
simple_stmt [10466,10487]
===
match
---
import_from [1791,1838]
import_from [1791,1838]
===
match
---
expr_stmt [2888,2914]
expr_stmt [2888,2914]
===
match
---
operator: == [6146,6148]
operator: == [6146,6148]
===
match
---
trailer [15183,15195]
trailer [15183,15195]
===
match
---
atom [2108,2142]
atom [2108,2142]
===
match
---
argument [18726,18793]
argument [19114,19181]
===
match
---
name: now [8776,8779]
name: now [8776,8779]
===
match
---
atom_expr [14193,14208]
atom_expr [14193,14208]
===
match
---
dictorsetmaker [9283,9289]
dictorsetmaker [9283,9289]
===
match
---
argument [19608,19621]
argument [20318,20331]
===
match
---
trailer [7685,7687]
trailer [7685,7687]
===
match
---
simple_stmt [14721,14910]
simple_stmt [14721,14910]
===
match
---
operator: } [19095,19096]
operator: } [19539,19540]
===
match
---
trailer [2697,2706]
trailer [2697,2706]
===
match
---
parameters [2197,2203]
parameters [2197,2203]
===
match
---
operator: , [18230,18231]
operator: , [18496,18497]
===
match
---
funcdef [6793,6838]
funcdef [6793,6838]
===
match
---
name: task_id [17687,17694]
name: task_id [17809,17816]
===
match
---
simple_stmt [805,817]
simple_stmt [805,817]
===
match
---
trailer [10963,10978]
trailer [10963,10978]
===
match
---
trailer [16120,16127]
trailer [16120,16127]
===
match
---
operator: , [2037,2038]
operator: , [2037,2038]
===
match
---
operator: { [14391,14392]
operator: { [14391,14392]
===
match
---
name: os [2051,2053]
name: os [2051,2053]
===
match
---
operator: = [18358,18359]
operator: = [18624,18625]
===
match
---
simple_stmt [8045,8128]
simple_stmt [8045,8128]
===
match
---
atom_expr [19665,19722]
atom_expr [20375,20432]
===
match
---
trailer [12722,12738]
trailer [12722,12738]
===
match
---
operator: , [14566,14567]
operator: , [14566,14567]
===
match
---
trailer [7624,7645]
trailer [7624,7645]
===
match
---
operator: , [6378,6379]
operator: , [6378,6379]
===
match
---
name: self [16884,16888]
name: self [16884,16888]
===
match
---
atom_expr [15675,15685]
atom_expr [15675,15685]
===
match
---
simple_stmt [7778,7863]
simple_stmt [7778,7863]
===
match
---
name: celery_executor [8174,8189]
name: celery_executor [8174,8189]
===
match
---
operator: , [9012,9013]
operator: , [9012,9013]
===
match
---
name: State [6149,6154]
name: State [6149,6154]
===
match
---
assert_stmt [8463,8505]
assert_stmt [8463,8505]
===
match
---
name: start_date [13198,13208]
name: start_date [13198,13208]
===
match
---
operator: } [16699,16700]
operator: } [16699,16700]
===
match
---
name: celery_executor [16303,16318]
name: celery_executor [16303,16318]
===
match
---
dotted_name [1090,1110]
dotted_name [1090,1110]
===
match
---
name: execute_date [6125,6137]
name: execute_date [6125,6137]
===
match
---
argument [6192,6208]
argument [6192,6208]
===
match
---
simple_stmt [3712,3731]
simple_stmt [3712,3731]
===
match
---
arith_expr [13051,13088]
arith_expr [13051,13088]
===
match
---
operator: { [10417,10418]
operator: { [10417,10418]
===
match
---
name: queued_tasks [7721,7733]
name: queued_tasks [7721,7733]
===
match
---
dotted_name [19141,19164]
dotted_name [19729,19752]
===
match
---
trailer [2906,2914]
trailer [2906,2914]
===
match
---
arglist [16977,17106]
arglist [16977,17106]
===
match
---
trailer [6187,6191]
trailer [6187,6191]
===
match
---
atom [11972,11980]
atom [11972,11980]
===
match
---
operator: , [7814,7815]
operator: , [7814,7815]
===
match
---
name: dict [9664,9668]
name: dict [9664,9668]
===
match
---
operator: = [13987,13988]
operator: = [13987,13988]
===
match
---
atom_expr [8916,8970]
atom_expr [8916,8970]
===
match
---
string: "status" [17065,17073]
string: "status" [17065,17073]
===
match
---
dotted_name [17118,17141]
dotted_name [17118,17141]
===
match
---
arglist [19202,19221]
arglist [19790,19809]
===
match
---
name: key_2 [16015,16020]
name: key_2 [16015,16020]
===
match
---
trailer [11909,11926]
trailer [11909,11926]
===
match
---
name: conf [2389,2393]
name: conf [2389,2393]
===
match
---
string: 'info' [4516,4522]
string: 'info' [4516,4522]
===
match
---
name: task_publish_retries [7625,7645]
name: task_publish_retries [7625,7645]
===
match
---
name: __str__ [16611,16618]
name: __str__ [16611,16618]
===
match
---
expr_stmt [7066,7109]
expr_stmt [7066,7109]
===
match
---
simple_stmt [10045,10066]
simple_stmt [10045,10066]
===
match
---
name: CeleryExecutor [4361,4375]
name: CeleryExecutor [4361,4375]
===
match
---
argument [15307,15317]
argument [15307,15317]
===
match
---
string: 'airflow.executors.base_executor.Stats.gauge' [11464,11509]
string: 'airflow.executors.base_executor.Stats.gauge' [11464,11509]
===
match
---
name: backends [1097,1105]
name: backends [1097,1105]
===
match
---
name: patch [11458,11463]
name: patch [11458,11463]
===
match
---
operator: , [19419,19420]
operator: , [20007,20008]
===
match
---
atom_expr [10161,10182]
atom_expr [10161,10182]
===
match
---
dotted_name [11940,11960]
dotted_name [11940,11960]
===
match
---
yield_expr [3411,3425]
yield_expr [3411,3425]
===
match
---
atom_expr [14457,14495]
atom_expr [14457,14495]
===
match
---
name: DAG [1697,1700]
name: DAG [1697,1700]
===
match
---
suite [16376,16903]
suite [16376,16903]
===
match
---
name: mock [11453,11457]
name: mock [11453,11457]
===
match
---
testlist_comp [19582,19723]
testlist_comp [20292,20433]
===
match
---
suite [19299,19764]
suite [19887,20474]
===
match
---
operator: , [16013,16014]
operator: , [16013,16014]
===
match
---
assert_stmt [6324,6416]
assert_stmt [6324,6416]
===
match
---
classdef [16905,19843]
classdef [16905,20697]
===
match
---
name: operators [1804,1813]
name: operators [1804,1813]
===
match
---
atom_expr [2051,2094]
atom_expr [2051,2094]
===
match
---
operator: == [6547,6549]
operator: == [6547,6549]
===
match
---
funcdef [16492,16602]
funcdef [16492,16602]
===
match
---
name: adopted_task_timeouts [16225,16246]
name: adopted_task_timeouts [16225,16246]
===
match
---
operator: @ [6704,6705]
operator: @ [6704,6705]
===
match
---
string: 'executor.queued_tasks' [11780,11803]
string: 'executor.queued_tasks' [11780,11803]
===
match
---
name: self [2248,2252]
name: self [2248,2252]
===
match
---
atom_expr [17845,17857]
atom_expr [17967,17979]
===
match
---
name: integration [6676,6687]
name: integration [6676,6687]
===
match
---
atom_expr [14978,14996]
atom_expr [14978,14996]
===
match
---
name: TaskInstance [8916,8928]
name: TaskInstance [8916,8928]
===
match
---
operator: , [19069,19070]
operator: , [19513,19514]
===
match
---
string: 'backend' [18476,18485]
string: 'backend' [18742,18751]
===
match
---
expr_stmt [8794,8986]
expr_stmt [8794,8986]
===
match
---
operator: = [15314,15315]
operator: = [15314,15315]
===
match
---
trailer [17063,17104]
trailer [17063,17104]
===
match
---
name: queue [5430,5435]
name: queue [5430,5435]
===
match
---
trailer [7241,7243]
trailer [7241,7243]
===
match
---
name: celery [1222,1228]
name: celery [1222,1228]
===
match
---
comparison [8525,8563]
comparison [8525,8563]
===
match
---
name: mock_backend [17336,17348]
name: mock_backend [17336,17348]
===
match
---
parameters [3601,3607]
parameters [3601,3607]
===
match
---
fstring_expr [9575,9580]
fstring_expr [9575,9580]
===
match
---
name: config_source [2638,2651]
name: config_source [2638,2651]
===
match
---
arglist [18455,18499]
arglist [18721,18765]
===
match
---
name: exceptions [1449,1459]
name: exceptions [1449,1459]
===
match
---
arglist [13180,13219]
arglist [13180,13219]
===
match
---
string: "rabbitmq" [6688,6698]
string: "rabbitmq" [6688,6698]
===
match
---
operator: -> [3608,3610]
operator: -> [3608,3610]
===
match
---
expr_stmt [2608,2664]
expr_stmt [2608,2664]
===
match
---
atom_expr [14048,14063]
atom_expr [14048,14063]
===
match
---
name: len [9315,9318]
name: len [9315,9318]
===
match
---
simple_stmt [2263,2280]
simple_stmt [2263,2280]
===
match
---
name: when [7834,7838]
name: when [7834,7838]
===
match
---
atom [14391,14393]
atom [14391,14393]
===
match
---
name: self [15127,15131]
name: self [15127,15131]
===
match
---
simple_stmt [16173,16201]
simple_stmt [16173,16201]
===
match
---
name: mock [11805,11809]
name: mock [11805,11809]
===
match
---
name: BaseOperator [15505,15517]
name: BaseOperator [15505,15517]
===
match
---
name: self [18283,18287]
name: self [18549,18553]
===
match
---
atom_expr [13673,13693]
atom_expr [13673,13693]
===
match
---
name: mark [17204,17208]
name: mark [17204,17208]
===
match
---
atom_expr [6179,6209]
atom_expr [6179,6209]
===
match
---
operator: = [17379,17380]
operator: = [17379,17380]
===
match
---
comparison [6480,6508]
comparison [6480,6508]
===
match
---
trailer [9318,9341]
trailer [9318,9341]
===
match
---
operator: = [13235,13236]
operator: = [13235,13236]
===
match
---
name: airflow [1618,1625]
name: airflow [1618,1625]
===
match
---
simple_stmt [787,805]
simple_stmt [787,805]
===
match
---
name: executor [5722,5730]
name: executor [5722,5730]
===
match
---
name: app [18396,18399]
name: app [18662,18665]
===
match
---
trailer [15863,15885]
trailer [15863,15885]
===
match
---
operator: = [15339,15340]
operator: = [15339,15340]
===
match
---
comparison [9878,10017]
comparison [9878,10017]
===
match
---
operator: { [17862,17863]
operator: { [17984,17985]
===
match
---
operator: , [4994,4995]
operator: , [4994,4995]
===
match
---
string: '123' [17992,17997]
string: '123' [18114,18119]
===
match
---
atom_expr [7129,7257]
atom_expr [7129,7257]
===
match
---
trailer [8206,8212]
trailer [8206,8212]
===
match
---
funcdef [10813,11292]
funcdef [10813,11292]
===
match
---
operator: @ [16956,16957]
operator: @ [16956,16957]
===
match
---
operator: , [19722,19723]
operator: , [20432,20433]
===
match
---
operator: , [1483,1484]
operator: , [1483,1484]
===
match
---
name: get_many [17561,17569]
name: get_many [17683,17691]
===
match
---
name: execute_date [6278,6290]
name: execute_date [6278,6290]
===
match
---
with_item [12237,12345]
with_item [12237,12345]
===
match
---
operator: == [9733,9735]
operator: == [9733,9735]
===
match
---
trailer [4405,4411]
trailer [4405,4411]
===
match
---
argument [13891,13907]
argument [13891,13907]
===
match
---
name: backend [19194,19201]
name: backend [19782,19789]
===
match
---
name: BaseKeyValueStoreBackend [1131,1155]
name: BaseKeyValueStoreBackend [1131,1155]
===
match
---
simple_stmt [13639,13694]
simple_stmt [13639,13694]
===
match
---
decorator [3892,3934]
decorator [3892,3934]
===
match
---
operator: = [14090,14091]
operator: = [14090,14091]
===
match
---
operator: , [18992,18993]
operator: , [19420,19421]
===
match
---
string: 'fake_simple_ti' [5782,5798]
string: 'fake_simple_ti' [5782,5798]
===
match
---
atom_expr [15217,15234]
atom_expr [15217,15234]
===
match
---
operator: = [15574,15575]
operator: = [15574,15575]
===
match
---
operator: , [17105,17106]
operator: , [17105,17106]
===
match
---
name: ValueError [12020,12030]
name: ValueError [12020,12030]
===
match
---
decorator [17117,17151]
decorator [17117,17151]
===
match
---
dictorsetmaker [11011,11036]
dictorsetmaker [11011,11036]
===
match
---
decorated [19102,19843]
decorated [19690,20697]
===
match
---
trailer [8154,8156]
trailer [8154,8156]
===
match
---
name: execute_command [12723,12738]
name: execute_command [12723,12738]
===
match
---
comparison [9243,9290]
comparison [9243,9290]
===
match
---
trailer [13381,13406]
trailer [13381,13406]
===
match
---
arglist [4478,4522]
arglist [4478,4522]
===
match
---
comparison [10085,10132]
comparison [10085,10132]
===
match
---
operator: = [15525,15526]
operator: = [15525,15526]
===
match
---
trailer [2007,2015]
trailer [2007,2015]
===
match
---
operator: , [9341,9342]
operator: , [9341,9342]
===
match
---
name: other [16857,16862]
name: other [16857,16862]
===
match
---
assert_stmt [16173,16200]
assert_stmt [16173,16200]
===
match
---
string: """Test that Airflow retries publishing tasks to Celery Broker at least 3 times""" [8045,8127]
string: """Test that Airflow retries publishing tasks to Celery Broker at least 3 times""" [8045,8127]
===
match
---
name: app [18376,18379]
name: app [18642,18645]
===
match
---
operator: , [8663,8664]
operator: , [8663,8664]
===
match
---
simple_stmt [7122,7258]
simple_stmt [7122,7258]
===
match
---
atom_expr [13551,13571]
atom_expr [13551,13571]
===
match
---
number: 2 [13086,13087]
number: 2 [13086,13087]
===
match
---
name: queue [5554,5559]
name: queue [5554,5559]
===
match
---
simple_stmt [9624,9645]
simple_stmt [9624,9645]
===
match
---
name: pytest [12906,12912]
name: pytest [12906,12912]
===
match
---
name: airflow [1796,1803]
name: airflow [1796,1803]
===
match
---
trailer [8305,8313]
trailer [8305,8313]
===
match
---
trailer [5671,5692]
trailer [5671,5692]
===
match
---
or_test [2436,2490]
or_test [2436,2490]
===
match
---
name: _prepare_app [8142,8154]
name: _prepare_app [8142,8154]
===
match
---
string: "true" [8678,8684]
string: "true" [8678,8684]
===
match
---
name: celery_executor [13324,13339]
name: celery_executor [13324,13339]
===
match
---
string: '231' [14034,14039]
string: '231' [14034,14039]
===
match
---
expr_stmt [15142,15195]
expr_stmt [15142,15195]
===
match
---
strings [9878,10004]
strings [9878,10004]
===
match
---
atom_expr [4397,4411]
atom_expr [4397,4411]
===
match
---
trailer [16689,16698]
trailer [16689,16698]
===
match
---
name: patch [17423,17428]
name: patch [17423,17428]
===
match
---
operator: , [13832,13833]
operator: , [13832,13833]
===
match
---
classdef [3543,16253]
classdef [3543,16253]
===
match
---
name: execute_command [5224,5239]
name: execute_command [5224,5239]
===
match
---
trailer [9221,9223]
trailer [9221,9223]
===
match
---
name: BaseOperator [13803,13815]
name: BaseOperator [13803,13815]
===
match
---
suite [8394,10733]
suite [8394,10733]
===
match
---
name: __eq__ [16889,16895]
name: __eq__ [16889,16895]
===
match
---
atom_expr [17841,17858]
atom_expr [17963,17980]
===
match
---
dotted_name [19103,19126]
dotted_name [19691,19714]
===
match
---
name: executor [6226,6234]
name: executor [6226,6234]
===
match
---
operator: = [15428,15429]
operator: = [15428,15429]
===
match
---
name: key_1 [15834,15839]
name: key_1 [15834,15839]
===
match
---
suite [12516,12578]
suite [12516,12578]
===
match
---
trailer [13080,13088]
trailer [13080,13088]
===
match
---
atom [17064,17103]
atom [17064,17103]
===
match
---
name: FakeCeleryResult [2152,2168]
name: FakeCeleryResult [2152,2168]
===
match
---
simple_stmt [1272,1310]
simple_stmt [1272,1310]
===
match
---
funcdef [16708,16758]
funcdef [16708,16758]
===
match
---
name: datetime [4556,4564]
name: datetime [4556,4564]
===
match
---
comparison [9813,9840]
comparison [9813,9840]
===
match
---
name: DAG [13732,13735]
name: DAG [13732,13735]
===
match
---
operator: , [5435,5436]
operator: , [5435,5436]
===
match
---
atom_expr [2447,2490]
atom_expr [2447,2490]
===
match
---
string: 'backend' [17457,17466]
string: 'backend' [17457,17466]
===
match
---
trailer [4900,4916]
trailer [4900,4916]
===
match
---
operator: , [8876,8877]
operator: , [8876,8877]
===
match
---
atom_expr [8418,8450]
atom_expr [8418,8450]
===
match
---
trailer [10713,10716]
trailer [10713,10716]
===
match
---
simple_stmt [18345,18419]
simple_stmt [18611,18685]
===
match
---
with_stmt [4254,6210]
with_stmt [4254,6210]
===
match
---
suite [16291,16342]
suite [16291,16342]
===
match
---
string: "Exception" [11249,11260]
string: "Exception" [11249,11260]
===
match
---
trailer [16089,16102]
trailer [16089,16102]
===
match
---
operator: @ [3892,3893]
operator: @ [3892,3893]
===
match
---
atom_expr [16180,16194]
atom_expr [16180,16194]
===
match
---
operator: { [9703,9704]
operator: { [9703,9704]
===
match
---
name: app [4482,4485]
name: app [4482,4485]
===
match
---
atom [4011,4064]
atom [4011,4064]
===
match
---
operator: , [17886,17887]
operator: , [18008,18009]
===
match
---
name: len [10572,10575]
name: len [10572,10575]
===
match
---
simple_stmt [2025,2096]
simple_stmt [2025,2096]
===
match
---
name: task_1 [13965,13971]
name: task_1 [13965,13971]
===
match
---
name: executor [15855,15863]
name: executor [15855,15863]
===
match
---
name: dict [2510,2514]
name: dict [2510,2514]
===
match
---
name: backends [1176,1184]
name: backends [1176,1184]
===
match
---
name: _prepare_test_bodies [1950,1970]
name: _prepare_test_bodies [1950,1970]
===
match
---
atom_expr [19518,19763]
atom_expr [20228,20473]
===
match
---
name: fetcher [17499,17506]
name: fetcher [17621,17628]
===
match
---
operator: , [8706,8707]
operator: , [8706,8707]
===
match
---
name: patch [2810,2815]
name: patch [2810,2815]
===
match
---
number: 1 [5629,5630]
number: 1 [5629,5630]
===
match
---
atom_expr [16081,16102]
atom_expr [16081,16102]
===
match
---
name: os [2005,2007]
name: os [2005,2007]
===
match
---
operator: == [17859,17861]
operator: == [17981,17983]
===
match
---
name: now [8964,8967]
name: now [8964,8967]
===
match
---
operator: , [19808,19809]
operator: , [20518,20519]
===
match
---
name: calls [11692,11697]
name: calls [11692,11697]
===
match
---
expr_stmt [14048,14077]
expr_stmt [14048,14077]
===
match
---
name: app [19416,19419]
name: app [20004,20007]
===
match
---
operator: , [15618,15619]
operator: , [15618,15619]
===
match
---
decorated [12905,13419]
decorated [12905,13419]
===
match
---
argument [13263,13282]
argument [13263,13282]
===
match
---
name: key_2 [14588,14593]
name: key_2 [14588,14593]
===
match
---
operator: , [14898,14899]
operator: , [14898,14899]
===
match
---
atom [2576,2602]
atom [2576,2602]
===
match
---
name: test_app [3417,3425]
name: test_app [3417,3425]
===
match
---
name: key1 [13230,13234]
name: key1 [13230,13234]
===
match
---
operator: = [2336,2337]
operator: = [2336,2337]
===
match
---
trailer [11832,11837]
trailer [11832,11837]
===
match
---
expr_stmt [15328,15342]
expr_stmt [15328,15342]
===
match
---
name: dag [8686,8689]
name: dag [8686,8689]
===
match
---
trailer [13339,13354]
trailer [13339,13354]
===
match
---
atom_expr [17418,17481]
atom_expr [17418,17481]
===
match
---
name: event_buffer [16090,16102]
name: event_buffer [16090,16102]
===
match
---
operator: , [5559,5560]
operator: , [5559,5560]
===
match
---
expr_stmt [14232,14248]
expr_stmt [14232,14248]
===
match
---
atom_expr [16685,16698]
atom_expr [16685,16698]
===
match
---
simple_stmt [8463,8506]
simple_stmt [8463,8506]
===
match
---
atom_expr [10948,10980]
atom_expr [10948,10980]
===
match
---
name: utcnow [13060,13066]
name: utcnow [13060,13066]
===
match
---
operator: , [1129,1130]
operator: , [1129,1130]
===
match
---
atom [17999,18016]
atom [18121,18138]
===
match
---
name: contrib [1229,1236]
name: contrib [1229,1236]
===
match
---
trailer [10089,10120]
trailer [10089,10120]
===
match
---
argument [17039,17105]
argument [17039,17105]
===
match
---
atom_expr [19382,19445]
atom_expr [19970,20033]
===
match
---
name: end [6188,6191]
name: end [6188,6191]
===
match
---
testlist_comp [12887,12898]
testlist_comp [12887,12898]
===
match
---
trailer [19331,19341]
trailer [19919,19929]
===
match
---
name: mock_subproc [12594,12606]
name: mock_subproc [12594,12606]
===
match
---
string: 'SUCCESS' [19629,19638]
string: 'SUCCESS' [20339,20348]
===
match
---
name: execute [4284,4291]
name: execute [4284,4291]
===
match
---
string: 'celery' [2118,2126]
string: 'celery' [2118,2126]
===
match
---
name: execute_command [12553,12568]
name: execute_command [12553,12568]
===
match
---
atom_expr [4495,4505]
atom_expr [4495,4505]
===
match
---
string: "task_id" [2270,2279]
string: "task_id" [2270,2279]
===
match
---
trailer [10242,10255]
trailer [10242,10255]
===
match
---
name: executor [9248,9256]
name: executor [9248,9256]
===
match
---
name: sync [16059,16063]
name: sync [16059,16063]
===
match
---
atom_expr [5648,5692]
atom_expr [5648,5692]
===
match
---
simple_stmt [6561,6620]
simple_stmt [6561,6620]
===
match
---
expr_stmt [13941,13998]
expr_stmt [13941,13998]
===
match
---
decorator [3851,3888]
decorator [3851,3888]
===
match
---
name: app [17452,17455]
name: app [17452,17455]
===
match
---
name: executor [11110,11118]
name: executor [11110,11118]
===
match
---
name: patch [8207,8212]
name: patch [8207,8212]
===
match
---
arglist [13891,13930]
arglist [13891,13930]
===
match
---
suite [2169,2280]
suite [2169,2280]
===
match
---
trailer [11774,11779]
trailer [11774,11779]
===
match
---
trailer [3654,3668]
trailer [3654,3668]
===
match
---
trailer [3714,3728]
trailer [3714,3728]
===
match
---
param [15127,15131]
param [15127,15131]
===
match
---
operator: , [11873,11874]
operator: , [11873,11874]
===
match
---
argument [8913,8970]
argument [8913,8970]
===
match
---
operator: , [19639,19640]
operator: , [20349,20350]
===
match
---
name: timezone [1865,1873]
name: timezone [1865,1873]
===
match
---
operator: = [18938,18939]
operator: = [19358,19359]
===
match
---
testlist_comp [12035,12060]
testlist_comp [12035,12060]
===
match
---
atom_expr [14733,14763]
atom_expr [14733,14763]
===
match
---
name: task_1 [13158,13164]
name: task_1 [13158,13164]
===
match
---
dictorsetmaker [15834,15951]
dictorsetmaker [15834,15951]
===
match
---
name: execute_date [6380,6392]
name: execute_date [6380,6392]
===
match
---
decorator [11452,11511]
decorator [11452,11511]
===
match
---
expr_stmt [5512,5571]
expr_stmt [5512,5571]
===
match
---
suite [2254,2280]
suite [2254,2280]
===
match
---
name: update [2569,2575]
name: update [2569,2575]
===
match
---
param [16774,16779]
param [16774,16779]
===
match
---
operator: { [10545,10546]
operator: { [10545,10546]
===
match
---
name: task_1 [13794,13800]
name: task_1 [13794,13800]
===
match
---
trailer [16560,16562]
trailer [16560,16562]
===
match
---
operator: { [9575,9576]
operator: { [9575,9576]
===
match
---
simple_stmt [16074,16165]
simple_stmt [16074,16165]
===
match
---
name: quarantined [10751,10762]
name: quarantined [10751,10762]
===
match
---
expr_stmt [18859,19017]
expr_stmt [19263,19461]
===
match
---
atom_expr [14678,14694]
atom_expr [14678,14694]
===
match
---
operator: @ [19140,19141]
operator: @ [19728,19729]
===
match
---
operator: , [17466,17467]
operator: , [17466,17467]
===
match
---
simple_stmt [2789,2883]
simple_stmt [2789,2883]
===
match
---
name: mark [3900,3904]
name: mark [3900,3904]
===
match
---
simple_stmt [4214,4245]
simple_stmt [4214,4245]
===
match
---
assert_stmt [16296,16341]
assert_stmt [16296,16341]
===
match
---
argument [7175,7194]
argument [7175,7194]
===
match
---
name: value [16595,16600]
name: value [16595,16600]
===
match
---
operator: , [13971,13972]
operator: , [13971,13972]
===
match
---
atom [14768,14909]
atom [14768,14909]
===
match
---
number: 0 [10567,10568]
number: 0 [10567,10568]
===
match
---
dictorsetmaker [16107,16163]
dictorsetmaker [16107,16163]
===
match
---
suite [17323,17743]
suite [17323,17865]
===
match
---
suite [13510,15035]
suite [13510,15035]
===
match
---
atom_expr [6404,6416]
atom_expr [6404,6416]
===
match
---
trailer [15225,15232]
trailer [15225,15232]
===
match
---
trailer [15232,15234]
trailer [15232,15234]
===
match
---
name: conf [2109,2113]
name: conf [2109,2113]
===
match
---
name: execute_date [5998,6010]
name: execute_date [5998,6010]
===
match
---
operator: { [10124,10125]
operator: { [10124,10125]
===
match
---
testlist_comp [19825,19840]
testlist_comp [20535,20550]
===
match
---
trailer [14465,14490]
trailer [14465,14490]
===
match
---
name: pytest [1052,1058]
name: pytest [1052,1058]
===
match
---
string: "rabbitmq" [19165,19175]
string: "rabbitmq" [19753,19763]
===
match
---
trailer [2727,2733]
trailer [2727,2733]
===
match
---
name: timedelta [13673,13682]
name: timedelta [13673,13682]
===
match
---
funcdef [19227,19843]
funcdef [19815,20697]
===
match
---
atom_expr [3712,3730]
atom_expr [3712,3730]
===
match
---
atom [8503,8505]
atom [8503,8505]
===
match
---
atom [2107,2143]
atom [2107,2143]
===
match
---
operator: } [9579,9580]
operator: } [9579,9580]
===
match
---
operator: ** [18726,18728]
operator: ** [19114,19116]
===
match
---
trailer [13059,13066]
trailer [13059,13066]
===
match
---
name: patch_app [3360,3369]
name: patch_app [3360,3369]
===
match
---
atom_expr [10881,10917]
atom_expr [10881,10917]
===
match
---
operator: = [17507,17508]
operator: = [17629,17630]
===
match
---
name: all [18670,18673]
name: all [19058,19061]
===
match
---
decorators [6625,6746]
decorators [6625,6746]
===
match
---
assert_stmt [14918,14997]
assert_stmt [14918,14997]
===
match
---
assert_stmt [14671,14712]
assert_stmt [14671,14712]
===
match
---
operator: = [2350,2351]
operator: = [2350,2351]
===
match
---
comparison [10655,10732]
comparison [10655,10732]
===
match
---
with_item [4259,4320]
with_item [4259,4320]
===
match
---
name: when [8760,8764]
name: when [8760,8764]
===
match
---
name: mock_session [18518,18530]
name: mock_session [18906,18918]
===
match
---
name: AsyncResult [1298,1309]
name: AsyncResult [1298,1309]
===
match
---
parameters [16288,16290]
parameters [16288,16290]
===
match
---
operator: } [16678,16679]
operator: } [16678,16679]
===
match
---
operator: == [10121,10123]
operator: == [10121,10123]
===
match
---
atom_expr [11110,11133]
atom_expr [11110,11133]
===
match
---
operator: { [15987,15988]
operator: { [15987,15988]
===
match
---
comparison [16216,16252]
comparison [16216,16252]
===
match
---
suite [2357,3541]
suite [2357,3541]
===
match
---
simple_stmt [16576,16602]
simple_stmt [16576,16602]
===
match
---
name: key_1 [14505,14510]
name: key_1 [14505,14510]
===
match
---
operator: , [7448,7449]
operator: , [7448,7449]
===
match
---
atom_expr [17553,17742]
atom_expr [17675,17864]
===
match
---
simple_stmt [14588,14663]
simple_stmt [14588,14663]
===
match
---
atom_expr [17053,17104]
atom_expr [17053,17104]
===
match
---
name: task_id [14631,14638]
name: task_id [14631,14638]
===
match
---
name: BaseBackend [19351,19362]
name: BaseBackend [19939,19950]
===
match
---
testlist_comp [11714,11874]
testlist_comp [11714,11874]
===
match
---
name: external_executor_id [14156,14176]
name: external_executor_id [14156,14176]
===
match
---
argument [11249,11290]
argument [11249,11290]
===
match
---
name: executor [4397,4405]
name: executor [4397,4405]
===
match
---
expr_stmt [3292,3325]
expr_stmt [3292,3325]
===
match
---
import_from [895,920]
import_from [895,920]
===
match
---
name: tasks [4406,4411]
name: tasks [4406,4411]
===
match
---
operator: @ [17155,17156]
operator: @ [17155,17156]
===
match
---
trailer [14630,14638]
trailer [14630,14638]
===
match
---
number: 0 [5879,5880]
number: 0 [5879,5880]
===
match
---
comparison [6076,6161]
comparison [6076,6161]
===
match
---
trailer [13539,13546]
trailer [13539,13546]
===
match
---
string: 'CELERY_BROKER_URLS' [2062,2082]
string: 'CELERY_BROKER_URLS' [2062,2082]
===
match
---
name: stdout [4499,4505]
name: stdout [4499,4505]
===
match
---
dotted_name [6705,6724]
dotted_name [6705,6724]
===
match
---
name: __init__ [16496,16504]
name: __init__ [16496,16504]
===
match
---
assert_stmt [5917,6052]
assert_stmt [5917,6052]
===
match
---
trailer [9247,9278]
trailer [9247,9278]
===
match
---
operator: , [16156,16157]
operator: , [16156,16157]
===
match
---
fstring_end: " [10424,10425]
fstring_end: " [10424,10425]
===
match
---
trailer [11077,11109]
trailer [11077,11109]
===
match
---
name: execute_date [5014,5026]
name: execute_date [5014,5026]
===
match
---
arglist [7968,7987]
arglist [7968,7987]
===
match
---
operator: { [9417,9418]
operator: { [9417,9418]
===
match
---
name: assert_not_called [12653,12670]
name: assert_not_called [12653,12670]
===
match
---
trailer [15674,15725]
trailer [15674,15725]
===
match
---
operator: = [13049,13050]
operator: = [13049,13050]
===
match
---
trailer [10010,10017]
trailer [10010,10017]
===
match
---
name: TaskInstanceKey [15576,15591]
name: TaskInstanceKey [15576,15591]
===
match
---
operator: , [11993,11994]
operator: , [11993,11994]
===
match
---
string: "postgres" [19211,19221]
string: "postgres" [19799,19809]
===
match
---
operator: + [14866,14867]
operator: + [14866,14867]
===
match
---
trailer [3341,3347]
trailer [3341,3347]
===
match
---
operator: , [2773,2774]
operator: , [2773,2774]
===
match
---
operator: = [11620,11621]
operator: = [11620,11621]
===
match
---
operator: == [9312,9314]
operator: == [9312,9314]
===
match
---
string: "232" [16034,16039]
string: "232" [16034,16039]
===
match
---
trailer [7675,7685]
trailer [7675,7685]
===
match
---
name: exec_date [13519,13528]
name: exec_date [13519,13528]
===
match
---
operator: , [10708,10709]
operator: , [10708,10709]
===
match
---
name: test_config [2557,2568]
name: test_config [2557,2568]
===
match
---
number: 40 [15192,15194]
number: 40 [15192,15194]
===
match
---
string: 'fail' [6480,6486]
string: 'fail' [6480,6486]
===
match
---
dictorsetmaker [18729,18792]
dictorsetmaker [19117,19180]
===
match
---
name: patch [11376,11381]
name: patch [11376,11381]
===
match
---
operator: , [10183,10184]
operator: , [10183,10184]
===
match
---
trailer [2625,2664]
trailer [2625,2664]
===
match
---
comparison [9731,9762]
comparison [9731,9762]
===
match
---
operator: } [9418,9419]
operator: } [9418,9419]
===
match
---
param [12114,12122]
param [12114,12122]
===
match
---
name: dag_id [14533,14539]
name: dag_id [14533,14539]
===
match
---
fstring [10372,10425]
fstring [10372,10425]
===
match
---
name: key_2 [16136,16141]
name: key_2 [16136,16141]
===
match
---
name: exec_date [15620,15629]
name: exec_date [15620,15629]
===
match
---
trailer [13959,13998]
trailer [13959,13998]
===
match
---
name: mock [12347,12351]
name: mock [12347,12351]
===
match
---
simple_stmt [10078,10133]
simple_stmt [10078,10133]
===
match
---
operator: = [4291,4292]
operator: = [4291,4292]
===
match
---
string: "celery.backends.base.BaseKeyValueStoreBackend.mget" [16977,17029]
string: "celery.backends.base.BaseKeyValueStoreBackend.mget" [16977,17029]
===
match
---
simple_stmt [8612,8748]
simple_stmt [8612,8748]
===
match
---
assert_stmt [14402,14429]
assert_stmt [14402,14429]
===
match
---
atom_expr [15277,15294]
atom_expr [15277,15294]
===
match
---
trailer [8779,8781]
trailer [8779,8781]
===
match
---
funcdef [16255,16342]
funcdef [16255,16342]
===
match
---
name: datetime [875,883]
name: datetime [875,883]
===
match
---
expr_stmt [4541,4570]
expr_stmt [4541,4570]
===
match
---
operator: , [16134,16135]
operator: , [16134,16135]
===
match
---
suite [10924,11135]
suite [10924,11135]
===
match
---
string: "231" [14963,14968]
string: "231" [14963,14968]
===
match
---
import_name [965,1000]
import_name [965,1000]
===
match
---
name: executor [7616,7624]
name: executor [7616,7624]
===
match
---
name: mock [11864,11868]
name: mock [11864,11868]
===
match
---
simple_stmt [4588,5282]
simple_stmt [4588,5282]
===
match
---
name: exec_date [13988,13997]
name: exec_date [13988,13997]
===
match
---
operator: , [15950,15951]
operator: , [15950,15951]
===
match
---
trailer [15292,15294]
trailer [15292,15294]
===
match
---
expr_stmt [14257,14300]
expr_stmt [14257,14300]
===
match
---
atom_expr [2005,2015]
atom_expr [2005,2015]
===
match
---
name: any [11245,11248]
name: any [11245,11248]
===
match
---
name: get [2114,2117]
name: get [2114,2117]
===
match
---
atom_expr [8690,8706]
atom_expr [8690,8706]
===
match
---
simple_stmt [13703,13718]
simple_stmt [13703,13718]
===
match
---
name: _prepare_app [4259,4271]
name: _prepare_app [4259,4271]
===
match
---
name: unittest [900,908]
name: unittest [900,908]
===
match
---
name: try_number [13703,13713]
name: try_number [13703,13713]
===
match
---
name: celery_executor [12707,12722]
name: celery_executor [12707,12722]
===
match
---
trailer [11837,11873]
trailer [11837,11873]
===
match
---
simple_stmt [7563,7604]
simple_stmt [7563,7604]
===
match
---
name: celery_executor [11622,11637]
name: celery_executor [11622,11637]
===
match
---
string: 'airflow.executors.celery_executor._execute_in_fork' [12358,12410]
string: 'airflow.executors.celery_executor._execute_in_fork' [12358,12410]
===
match
---
name: __dict__ [16808,16816]
name: __dict__ [16808,16816]
===
match
---
operator: == [16337,16339]
operator: == [16337,16339]
===
match
---
expr_stmt [7270,7291]
expr_stmt [7270,7291]
===
match
---
expr_stmt [14588,14662]
expr_stmt [14588,14662]
===
match
---
name: celery_executor [5124,5139]
name: celery_executor [5124,5139]
===
match
---
atom_expr [9664,9699]
atom_expr [9664,9699]
===
match
---
name: execute [2698,2705]
name: execute [2698,2705]
===
match
---
operator: = [8700,8701]
operator: = [8700,8701]
===
match
---
operator: = [19628,19629]
operator: = [20338,20339]
===
match
---
operator: , [7216,7217]
operator: , [7216,7217]
===
match
---
trailer [2575,2603]
trailer [2575,2603]
===
match
---
dotted_name [7948,7967]
dotted_name [7948,7967]
===
match
---
name: task_adoption_timeout [14877,14898]
name: task_adoption_timeout [14877,14898]
===
match
---
name: parameterized [1382,1395]
name: parameterized [1382,1395]
===
match
---
trailer [16755,16757]
trailer [16755,16757]
===
match
---
name: mock_subproc [12333,12345]
name: mock_subproc [12333,12345]
===
match
---
argument [6865,6893]
argument [6865,6893]
===
match
---
name: integration [19153,19164]
name: integration [19741,19752]
===
match
---
trailer [18715,18725]
trailer [19103,19113]
===
match
---
decorated [3763,6620]
decorated [3763,6620]
===
match
---
trailer [12624,12626]
trailer [12624,12626]
===
match
---
name: TaskInstance [7426,7438]
name: TaskInstance [7426,7438]
===
match
---
trailer [11671,11681]
trailer [11671,11681]
===
match
---
trailer [5741,5743]
trailer [5741,5743]
===
match
---
name: celery [1169,1175]
name: celery [1169,1175]
===
match
---
expr_stmt [14152,14184]
expr_stmt [14152,14184]
===
match
---
operator: = [15275,15276]
operator: = [15275,15276]
===
match
---
operator: , [7194,7195]
operator: , [7194,7195]
===
match
---
decorators [16956,17238]
decorators [16956,17238]
===
match
---
atom_expr [10572,10598]
atom_expr [10572,10598]
===
match
---
name: executor [9624,9632]
name: executor [9624,9632]
===
match
---
operator: = [15657,15658]
operator: = [15657,15658]
===
match
---
atom_expr [14357,14387]
atom_expr [14357,14387]
===
match
---
operator: == [10569,10571]
operator: == [10569,10571]
===
match
---
operator: = [18687,18688]
operator: = [19075,19076]
===
match
---
name: try_number [15631,15641]
name: try_number [15631,15641]
===
match
---
name: mock_stats_gauge [11553,11569]
name: mock_stats_gauge [11553,11569]
===
match
---
atom_expr [14596,14662]
atom_expr [14596,14662]
===
match
---
name: start_date [7218,7228]
name: start_date [7218,7228]
===
match
---
decorator [10738,10763]
decorator [10738,10763]
===
match
---
name: key [9576,9579]
name: key [9576,9579]
===
match
---
decorator [11370,11448]
decorator [11370,11448]
===
match
---
trailer [14051,14063]
trailer [14051,14063]
===
match
---
name: task_id [15611,15618]
name: task_id [15611,15618]
===
match
---
operator: , [4704,4705]
operator: , [4704,4705]
===
match
---
trailer [18884,19017]
trailer [19288,19461]
===
match
---
trailer [8731,8733]
trailer [8731,8733]
===
match
---
atom_expr [4556,4570]
atom_expr [4556,4570]
===
match
---
string: "celery.backends.database.DatabaseBackend.ResultSession" [18061,18117]
string: "celery.backends.database.DatabaseBackend.ResultSession" [18327,18383]
===
match
---
dotted_name [10739,10762]
dotted_name [10739,10762]
===
match
---
atom_expr [3739,3757]
atom_expr [3739,3757]
===
match
---
name: try_number [14568,14578]
name: try_number [14568,14578]
===
match
---
atom_expr [16644,16678]
atom_expr [16644,16678]
===
match
---
name: _prepare_app [17308,17320]
name: _prepare_app [17308,17320]
===
match
---
name: task_id [13891,13898]
name: task_id [13891,13898]
===
match
---
operator: = [13919,13920]
operator: = [13919,13920]
===
match
---
trailer [11001,11007]
trailer [11001,11007]
===
match
---
expr_stmt [7616,7654]
expr_stmt [7616,7654]
===
match
---
dictorsetmaker [17863,17911]
dictorsetmaker [17985,18033]
===
match
---
string: "PENDING" [19079,19088]
string: "PENDING" [19523,19532]
===
match
---
string: "123" [18786,18791]
string: "123" [19174,19179]
===
match
---
dotted_name [1706,1733]
dotted_name [1706,1733]
===
match
---
suite [18332,18813]
suite [18598,19462]
===
match
---
with_stmt [18312,18813]
with_stmt [18578,19462]
===
match
---
name: start_date [13209,13219]
name: start_date [13209,13219]
===
match
---
name: datetime [859,867]
name: datetime [859,867]
===
match
---
name: test_should_support_db_backend [18252,18282]
name: test_should_support_db_backend [18518,18548]
===
match
---
name: expected_exception [12496,12514]
name: expected_exception [12496,12514]
===
match
---
name: mark [7914,7918]
name: mark [7914,7918]
===
match
---
atom_expr [9053,9079]
atom_expr [9053,9079]
===
match
---
operator: , [8938,8939]
operator: , [8938,8939]
===
match
---
trailer [2061,2083]
trailer [2061,2083]
===
match
---
string: "postgres" [7977,7987]
string: "postgres" [7977,7987]
===
match
---
simple_stmt [16050,16066]
simple_stmt [16050,16066]
===
match
---
name: kombu [1315,1320]
name: kombu [1315,1320]
===
match
---
name: minutes [15307,15314]
name: minutes [15307,15314]
===
match
---
name: tasks [995,1000]
name: tasks [995,1000]
===
match
---
operator: , [19088,19089]
operator: , [19532,19533]
===
match
---
number: 0 [5028,5029]
number: 0 [5028,5029]
===
match
---
simple_stmt [854,895]
simple_stmt [854,895]
===
match
---
dotted_name [1844,1857]
dotted_name [1844,1857]
===
match
---
atom_expr [7850,7862]
atom_expr [7850,7862]
===
match
---
name: mark [10746,10750]
name: mark [10746,10750]
===
match
---
operator: } [16251,16252]
operator: } [16251,16252]
===
match
---
string: 'task_default_queue' [4838,4858]
string: 'task_default_queue' [4838,4858]
===
match
---
atom_expr [5946,6018]
atom_expr [5946,6018]
===
match
---
operator: { [18728,18729]
operator: { [19116,19117]
===
match
---
simple_stmt [13941,13999]
simple_stmt [13941,13999]
===
match
---
arith_expr [15277,15318]
arith_expr [15277,15318]
===
match
---
suite [12690,12900]
suite [12690,12900]
===
match
---
trailer [12351,12357]
trailer [12351,12357]
===
match
---
operator: = [5627,5628]
operator: = [5627,5628]
===
match
---
operator: , [18773,18774]
operator: , [19161,19162]
===
match
---
simple_stmt [19463,19493]
simple_stmt [20173,20203]
===
match
---
name: celery_executor [7077,7092]
name: celery_executor [7077,7092]
===
match
---
simple_stmt [827,838]
simple_stmt [827,838]
===
match
---
dictorsetmaker [14699,14711]
dictorsetmaker [14699,14711]
===
match
---
name: pytest [19103,19109]
name: pytest [19691,19697]
===
match
---
name: mock [11371,11375]
name: mock [11371,11375]
===
match
---
testlist_comp [6099,6140]
testlist_comp [6099,6140]
===
match
---
simple_stmt [14439,14496]
simple_stmt [14439,14496]
===
match
---
atom [16143,16163]
atom [16143,16163]
===
match
---
expr_stmt [14007,14039]
expr_stmt [14007,14039]
===
match
---
atom_expr [7077,7109]
atom_expr [7077,7109]
===
match
---
testlist_comp [18916,18993]
testlist_comp [19336,19421]
===
match
---
name: celery_executor [18380,18395]
name: celery_executor [18646,18661]
===
match
---
atom_expr [8955,8969]
atom_expr [8955,8969]
===
match
---
name: utcnow [15163,15169]
name: utcnow [15163,15169]
===
match
---
operator: { [9996,9997]
operator: { [9996,9997]
===
match
---
name: now [7286,7289]
name: now [7286,7289]
===
match
---
name: task_id [13816,13823]
name: task_id [13816,13823]
===
match
---
name: TestCase [16941,16949]
name: TestCase [16941,16949]
===
match
---
trailer [16807,16816]
trailer [16807,16816]
===
match
---
operator: , [3920,3921]
operator: , [3920,3921]
===
match
---
operator: , [18035,18036]
operator: , [18157,18158]
===
match
---
decorator [7947,7989]
decorator [7947,7989]
===
match
---
fstring_start: f" [16641,16643]
fstring_start: f" [16641,16643]
===
match
---
expr_stmt [18345,18418]
expr_stmt [18611,18684]
===
match
---
name: execution_date [13263,13277]
name: execution_date [13263,13277]
===
match
---
testlist_comp [7336,7482]
testlist_comp [7336,7482]
===
match
---
name: SimpleTaskInstance [8894,8912]
name: SimpleTaskInstance [8894,8912]
===
match
---
suite [3984,6620]
suite [3984,6620]
===
match
---
trailer [11248,11291]
trailer [11248,11291]
===
match
---
name: executor [15920,15928]
name: executor [15920,15928]
===
match
---
arith_expr [15841,15885]
arith_expr [15841,15885]
===
match
---
arglist [15061,15080]
arglist [15061,15080]
===
match
---
string: 'fake_simple_ti' [7816,7832]
string: 'fake_simple_ti' [7816,7832]
===
match
---
name: keys [5737,5741]
name: keys [5737,5741]
===
match
---
name: output [9590,9596]
name: output [9590,9596]
===
match
---
comparison [17981,18043]
comparison [18103,18165]
===
match
---
trailer [14876,14898]
trailer [14876,14898]
===
match
---
not_test [16880,16902]
not_test [16880,16902]
===
match
---
simple_stmt [6833,6838]
simple_stmt [6833,6838]
===
match
---
operator: = [7228,7229]
operator: = [7228,7229]
===
match
---
name: mark [15048,15052]
name: mark [15048,15052]
===
match
---
name: task_tuples_to_send [5672,5691]
name: task_tuples_to_send [5672,5691]
===
match
---
operator: = [19615,19616]
operator: = [20325,20326]
===
match
---
trailer [3805,3807]
trailer [3805,3807]
===
match
---
decorator [18049,18119]
decorator [18315,18385]
===
match
---
name: try_number [14651,14661]
name: try_number [14651,14661]
===
match
---
operator: { [16250,16251]
operator: { [16250,16251]
===
match
---
operator: , [12112,12113]
operator: , [12112,12113]
===
match
---
param [18289,18301]
param [18555,18567]
===
match
---
comparison [13373,13418]
comparison [13373,13418]
===
match
---
atom [10281,10452]
atom [10281,10452]
===
match
---
string: 'success' [6249,6258]
string: 'success' [6249,6258]
===
match
---
name: executor [16050,16058]
name: executor [16050,16058]
===
match
---
operator: == [14388,14390]
operator: == [14388,14390]
===
match
---
name: testing [987,994]
name: testing [987,994]
===
match
---
name: contextlib [2283,2293]
name: contextlib [2283,2293]
===
match
---
for_stmt [5400,5631]
for_stmt [5400,5631]
===
match
---
simple_stmt [14193,14223]
simple_stmt [14193,14223]
===
match
---
parameters [11546,11601]
parameters [11546,11601]
===
match
---
trailer [17631,17646]
trailer [17753,17768]
===
match
---
assert_stmt [9303,9372]
assert_stmt [9303,9372]
===
match
---
trailer [18447,18454]
trailer [18713,18720]
===
match
---
name: CELERY_FETCH_ERR_MSG_HEADER [11171,11198]
name: CELERY_FETCH_ERR_MSG_HEADER [11171,11198]
===
match
---
argument [13250,13261]
argument [13250,13261]
===
match
---
trailer [18725,18794]
trailer [19113,19182]
===
match
---
name: tasks [6459,6464]
name: tasks [6459,6464]
===
match
---
string: 'version' [4100,4109]
string: 'version' [4100,4109]
===
match
---
name: queued_dttm [13639,13650]
name: queued_dttm [13639,13650]
===
match
---
name: timezone [15154,15162]
name: timezone [15154,15162]
===
match
---
name: BulkStateFetcher [17509,17525]
name: BulkStateFetcher [17631,17647]
===
match
---
simple_stmt [15568,15643]
simple_stmt [15568,15643]
===
match
---
trailer [17422,17428]
trailer [17422,17428]
===
match
---
suite [6895,7688]
suite [6895,7688]
===
match
---
trailer [14732,14764]
trailer [14732,14764]
===
match
---
name: CeleryExecutor [13340,13354]
name: CeleryExecutor [13340,13354]
===
match
---
name: ti2 [14086,14089]
name: ti2 [14086,14089]
===
match
---
name: TaskInstanceKey [15659,15674]
name: TaskInstanceKey [15659,15674]
===
match
---
operator: = [4086,4087]
operator: = [4086,4087]
===
match
---
parameters [12989,12995]
parameters [12989,12995]
===
match
---
assert_stmt [10227,10261]
assert_stmt [10227,10261]
===
match
---
name: key [8999,9002]
name: key [8999,9002]
===
match
---
atom_expr [15659,15725]
atom_expr [15659,15725]
===
match
---
import_from [1085,1155]
import_from [1085,1155]
===
match
---
expr_stmt [15735,15778]
expr_stmt [15735,15778]
===
match
---
trailer [7473,7477]
trailer [7473,7477]
===
match
---
atom_expr [13531,13548]
atom_expr [13531,13548]
===
match
---
name: list [5717,5721]
name: list [5717,5721]
===
match
---
operator: @ [17196,17197]
operator: @ [17196,17197]
===
match
---
name: mget_args [17845,17854]
name: mget_args [17967,17976]
===
match
---
simple_stmt [14048,14078]
simple_stmt [14048,14078]
===
match
---
trailer [16006,16013]
trailer [16006,16013]
===
match
---
name: ti [8913,8915]
name: ti [8913,8915]
===
match
---
expr_stmt [13869,13931]
expr_stmt [13869,13931]
===
match
---
name: executor [14457,14465]
name: executor [14457,14465]
===
match
---
atom_expr [11828,11873]
atom_expr [11828,11873]
===
match
---
number: 30 [15315,15317]
number: 30 [15315,15317]
===
match
---
trailer [3755,3757]
trailer [3755,3757]
===
match
---
atom_expr [5592,5626]
atom_expr [5592,5626]
===
match
---
trailer [6307,6315]
trailer [6307,6315]
===
match
---
name: _prepare_app [2313,2325]
name: _prepare_app [2313,2325]
===
match
---
expr_stmt [11611,11654]
expr_stmt [11611,11654]
===
match
---
operator: = [17694,17695]
operator: = [17816,17817]
===
match
---
name: State [16115,16120]
name: State [16115,16120]
===
match
---
comparison [19780,19842]
comparison [20490,20552]
===
match
---
atom_expr [2557,2603]
atom_expr [2557,2603]
===
match
---
comparison [6226,6315]
comparison [6226,6315]
===
match
---
trailer [10160,10183]
trailer [10160,10183]
===
match
---
operator: , [10598,10599]
operator: , [10598,10599]
===
match
---
name: taskinstance [1721,1733]
name: taskinstance [1721,1733]
===
match
---
or_test [2375,2421]
or_test [2375,2421]
===
match
---
arith_expr [15154,15195]
arith_expr [15154,15195]
===
match
---
decorator [19140,19177]
decorator [19728,19765]
===
match
---
operator: { [16643,16644]
operator: { [16643,16644]
===
match
---
arglist [14105,14142]
arglist [14105,14142]
===
match
---
name: key_1 [16107,16112]
name: key_1 [16107,16112]
===
match
---
trailer [11779,11814]
trailer [11779,11814]
===
match
---
string: 'fake_simple_ti' [6260,6276]
string: 'fake_simple_ti' [6260,6276]
===
match
---
name: dag_id [7204,7210]
name: dag_id [7204,7210]
===
match
---
operator: == [5745,5747]
operator: == [5745,5747]
===
match
---
atom_expr [7426,7480]
atom_expr [7426,7480]
===
match
---
name: return_value [18674,18686]
name: return_value [19062,19074]
===
match
---
name: integration [7919,7930]
name: integration [7919,7930]
===
match
---
operator: } [9710,9711]
operator: } [9710,9711]
===
match
---
operator: } [11036,11037]
operator: } [11036,11037]
===
match
---
name: result [19034,19040]
name: result [19478,19484]
===
match
---
operator: = [13876,13877]
operator: = [13876,13877]
===
match
---
name: ti1 [13941,13944]
name: ti1 [13941,13944]
===
match
---
dictorsetmaker [15988,16040]
dictorsetmaker [15988,16040]
===
match
---
arith_expr [15217,15254]
arith_expr [15217,15254]
===
match
---
trailer [17320,17322]
trailer [17320,17322]
===
match
---
decorator [6663,6700]
decorator [6663,6700]
===
match
---
name: executor [4334,4342]
name: executor [4334,4342]
===
match
---
name: execution_date [13973,13987]
name: execution_date [13973,13987]
===
match
---
operator: - [13611,13612]
operator: - [13611,13612]
===
match
---
trailer [5533,5538]
trailer [5533,5538]
===
match
---
name: mark [19110,19114]
name: mark [19698,19702]
===
match
---
atom [11010,11037]
atom [11010,11037]
===
match
---
string: "456" [18986,18991]
string: "456" [19414,19419]
===
match
---
name: start_date [8708,8718]
name: start_date [8708,8718]
===
match
---
trailer [14532,14539]
trailer [14532,14539]
===
match
---
funcdef [3676,3758]
funcdef [3676,3758]
===
match
---
atom_expr [10466,10486]
atom_expr [10466,10486]
===
match
---
simple_stmt [19027,19097]
simple_stmt [19471,19541]
===
match
---
sync_comp_for [11269,11290]
sync_comp_for [11269,11290]
===
match
---
name: queued_tasks [7572,7584]
name: queued_tasks [7572,7584]
===
match
---
trailer [11170,11198]
trailer [11170,11198]
===
match
---
atom_expr [8290,8313]
atom_expr [8290,8313]
===
match
---
operator: , [5798,5799]
operator: , [5798,5799]
===
match
---
operator: = [18985,18986]
operator: = [19413,19414]
===
match
---
atom [14427,14429]
atom [14427,14429]
===
match
---
import_as_names [875,894]
import_as_names [875,894]
===
match
---
name: timedelta [13071,13080]
name: timedelta [13071,13080]
===
match
---
number: 2 [13628,13629]
number: 2 [13628,13629]
===
match
---
dotted_name [1879,1898]
dotted_name [1879,1898]
===
match
---
name: mock [18963,18967]
name: mock [19391,19395]
===
match
---
name: celery_executor [10897,10912]
name: celery_executor [10897,10912]
===
match
---
name: self [11547,11551]
name: self [11547,11551]
===
match
---
string: "redis" [17142,17149]
string: "redis" [17142,17149]
===
match
---
operator: , [4021,4022]
operator: , [4021,4022]
===
match
---
atom_expr [6589,6619]
atom_expr [6589,6619]
===
match
---
argument [7439,7448]
argument [7439,7448]
===
match
---
dotted_name [1441,1459]
dotted_name [1441,1459]
===
match
---
operator: { [15820,15821]
operator: { [15820,15821]
===
match
---
string: b'celery-task-meta-123' [17888,17911]
string: b'celery-task-meta-123' [18010,18033]
===
match
---
name: mark [17125,17129]
name: mark [17125,17129]
===
match
---
atom_expr [4465,4523]
atom_expr [4465,4523]
===
match
---
operator: , [5012,5013]
operator: , [5012,5013]
===
match
---
argument [19706,19721]
argument [20416,20431]
===
match
---
name: ti1 [14007,14010]
name: ti1 [14007,14010]
===
match
---
string: "rabbitmq" [17180,17190]
string: "rabbitmq" [17180,17190]
===
match
---
name: executor [7712,7720]
name: executor [7712,7720]
===
match
---
atom [16250,16252]
atom [16250,16252]
===
match
---
name: split [2084,2089]
name: split [2084,2089]
===
match
---
suite [17482,17743]
suite [17604,17865]
===
match
---
name: executor [9319,9327]
name: executor [9319,9327]
===
match
---
trailer [16188,16194]
trailer [16188,16194]
===
match
---
atom [4632,4939]
atom [4632,4939]
===
match
---
expr_stmt [13639,13693]
expr_stmt [13639,13693]
===
match
---
string: "redis" [7893,7900]
string: "redis" [7893,7900]
===
match
---
name: get [2394,2397]
name: get [2394,2397]
===
match
---
atom_expr [18360,18418]
atom_expr [18626,18684]
===
match
---
name: mock_mget [17921,17930]
name: mock_mget [18043,18052]
===
match
---
string: "PENDING" [19712,19721]
string: "PENDING" [20422,20431]
===
match
---
name: task_publish_retries [9257,9277]
name: task_publish_retries [9257,9277]
===
match
---
name: backend [17209,17216]
name: backend [17209,17216]
===
match
---
atom_expr [2805,2882]
atom_expr [2805,2882]
===
match
---
atom_expr [14513,14579]
atom_expr [14513,14579]
===
match
---
atom_expr [10234,10255]
atom_expr [10234,10255]
===
match
---
name: broker_url [2326,2336]
name: broker_url [2326,2336]
===
match
---
operator: == [9835,9837]
operator: == [9835,9837]
===
match
---
name: test_error_sending_task [6754,6777]
name: test_error_sending_task [6754,6777]
===
match
---
number: 1 [9310,9311]
number: 1 [9310,9311]
===
match
---
atom_expr [15970,15984]
atom_expr [15970,15984]
===
match
---
trailer [6597,6619]
trailer [6597,6619]
===
match
---
string: '456' [19071,19076]
string: '456' [19515,19520]
===
match
---
operator: , [8200,8201]
operator: , [8200,8201]
===
match
---
atom_expr [9203,9223]
atom_expr [9203,9223]
===
match
---
name: CeleryExecutor [14284,14298]
name: CeleryExecutor [14284,14298]
===
match
---
expr_stmt [8999,9040]
expr_stmt [8999,9040]
===
match
---
operator: , [17701,17702]
operator: , [17823,17824]
===
match
---
atom_expr [14268,14300]
atom_expr [14268,14300]
===
match
---
name: try_number [15328,15338]
name: try_number [15328,15338]
===
match
---
trailer [11681,11683]
trailer [11681,11683]
===
match
---
decorators [18049,18244]
decorators [18315,18510]
===
match
---
name: __dict__ [16826,16834]
name: __dict__ [16826,16834]
===
match
---
trailer [16058,16063]
trailer [16058,16063]
===
match
---
atom_expr [14316,14332]
atom_expr [14316,14332]
===
match
---
name: dict [9243,9247]
name: dict [9243,9247]
===
match
---
name: fake_execute_command [6873,6893]
name: fake_execute_command [6873,6893]
===
match
---
number: 1 [13691,13692]
number: 1 [13691,13692]
===
match
---
trailer [2809,2815]
trailer [2809,2815]
===
match
---
trailer [3728,3730]
trailer [3728,3730]
===
match
---
string: "postgres" [13454,13464]
string: "postgres" [13454,13464]
===
match
---
name: now [7474,7477]
name: now [7474,7477]
===
match
---
operator: == [12883,12885]
operator: == [12883,12885]
===
match
---
name: pytest [15041,15047]
name: pytest [15041,15047]
===
match
---
simple_stmt [15735,15779]
simple_stmt [15735,15779]
===
match
---
name: task_1 [15421,15427]
name: task_1 [15421,15427]
===
match
---
string: 'true' [4039,4045]
string: 'true' [4039,4045]
===
match
---
operator: = [17051,17052]
operator: = [17051,17052]
===
match
---
name: pytest [7948,7954]
name: pytest [7948,7954]
===
match
---
name: BaseKeyValueStoreBackend [17351,17375]
name: BaseKeyValueStoreBackend [17351,17375]
===
match
---
name: ClassWithCustomAttributes [19582,19607]
name: ClassWithCustomAttributes [20292,20317]
===
match
---
operator: = [8915,8916]
operator: = [8915,8916]
===
match
---
trailer [14339,14341]
trailer [14339,14341]
===
match
---
simple_stmt [2888,2915]
simple_stmt [2888,2915]
===
match
---
name: airflow [1706,1713]
name: airflow [1706,1713]
===
match
---
trailer [2083,2089]
trailer [2083,2089]
===
match
---
name: models [1679,1685]
name: models [1679,1685]
===
match
---
atom_expr [17308,17322]
atom_expr [17308,17322]
===
match
---
string: "test" [7167,7173]
string: "test" [7167,7173]
===
match
---
atom_expr [11893,11933]
atom_expr [11893,11933]
===
match
---
name: patch_execute [2789,2802]
name: patch_execute [2789,2802]
===
match
---
name: backend [2907,2914]
name: backend [2907,2914]
===
match
---
name: broker_url [2362,2372]
name: broker_url [2362,2372]
===
match
---
dictorsetmaker [2577,2601]
dictorsetmaker [2577,2601]
===
match
---
simple_stmt [14402,14430]
simple_stmt [14402,14430]
===
match
---
assert_stmt [7778,7862]
assert_stmt [7778,7862]
===
match
---
operator: , [2938,2939]
operator: , [2938,2939]
===
match
---
import_from [1912,1943]
import_from [1912,1943]
===
match
---
string: "test_try_adopt_task_instances_none" [13107,13143]
string: "test_try_adopt_task_instances_none" [13107,13143]
===
match
---
atom_expr [15357,15400]
atom_expr [15357,15400]
===
match
---
atom_expr [7708,7734]
atom_expr [7708,7734]
===
match
---
name: task_id [15518,15525]
name: task_id [15518,15525]
===
match
---
operator: == [19787,19789]
operator: == [20497,20499]
===
match
---
operator: = [15744,15745]
operator: = [15744,15745]
===
match
---
operator: = [19350,19351]
operator: = [19938,19939]
===
match
---
assert_stmt [7696,7769]
assert_stmt [7696,7769]
===
match
---
operator: , [6276,6277]
operator: , [6276,6277]
===
match
---
suite [16563,16602]
suite [16563,16602]
===
match
---
atom [11995,12031]
atom [11995,12031]
===
match
---
atom_expr [11864,11872]
atom_expr [11864,11872]
===
match
---
atom [7515,7550]
atom [7515,7550]
===
match
---
string: 'run' [4032,4037]
string: 'run' [4032,4037]
===
match
---
atom_expr [14152,14176]
atom_expr [14152,14176]
===
match
---
trailer [11637,11652]
trailer [11637,11652]
===
match
---
operator: , [11803,11804]
operator: , [11803,11804]
===
match
---
param [12108,12113]
param [12108,12113]
===
match
---
funcdef [18248,19097]
funcdef [18514,19685]
===
match
---
trailer [8162,8173]
trailer [8162,8173]
===
match
---
atom_expr [10897,10916]
atom_expr [10897,10916]
===
match
---
operator: @ [7906,7907]
operator: @ [7906,7907]
===
match
---
trailer [10474,10484]
trailer [10474,10484]
===
match
---
name: len [9736,9739]
name: len [9736,9739]
===
match
---
simple_stmt [14232,14249]
simple_stmt [14232,14249]
===
match
---
trailer [17057,17063]
trailer [17057,17063]
===
match
---
atom [19078,19095]
atom [19522,19539]
===
match
---
trailer [6234,6247]
trailer [6234,6247]
===
match
---
name: cm [11281,11283]
name: cm [11281,11283]
===
match
---
operator: = [14109,14110]
operator: = [14109,14110]
===
match
---
arglist [15518,15557]
arglist [15518,15557]
===
match
---
trailer [18630,18636]
trailer [19018,19024]
===
match
---
name: fetcher [18822,18829]
name: fetcher [19218,19225]
===
match
---
operator: , [15068,15069]
operator: , [15068,15069]
===
match
---
atom_expr [10576,10597]
atom_expr [10576,10597]
===
match
---
parameters [2247,2253]
parameters [2247,2253]
===
match
---
trailer [2397,2421]
trailer [2397,2421]
===
match
---
operator: == [14765,14767]
operator: == [14765,14767]
===
match
---
expr_stmt [7122,7257]
expr_stmt [7122,7257]
===
match
---
atom [12033,12068]
atom [12033,12068]
===
match
---
suite [10850,11292]
suite [10850,11292]
===
match
---
dotted_name [7869,7892]
dotted_name [7869,7892]
===
match
---
operator: , [4859,4860]
operator: , [4859,4860]
===
match
---
atom [4415,4417]
atom [4415,4417]
===
match
---
testlist_comp [4012,4063]
testlist_comp [4012,4063]
===
match
---
name: task [5437,5441]
name: task [5437,5441]
===
match
---
string: 'tasks' [4023,4030]
string: 'tasks' [4023,4030]
===
match
---
funcdef [12951,13419]
funcdef [12951,13419]
===
match
---
testlist_comp [18026,18041]
testlist_comp [18148,18163]
===
match
---
suite [1973,2144]
suite [1973,2144]
===
match
---
name: setattr [16576,16583]
name: setattr [16576,16583]
===
match
---
operator: , [5816,5817]
operator: , [5816,5817]
===
match
---
arglist [11838,11872]
arglist [11838,11872]
===
match
---
operator: @ [11452,11453]
operator: @ [11452,11453]
===
match
---
atom_expr [15787,15817]
atom_expr [15787,15817]
===
match
---
simple_stmt [12813,12900]
simple_stmt [12813,12900]
===
match
---
name: BaseOperator [13167,13179]
name: BaseOperator [13167,13179]
===
match
---
name: try_number [15714,15724]
name: try_number [15714,15724]
===
match
---
trailer [19489,19492]
trailer [20199,20202]
===
match
---
atom_expr [6149,6161]
atom_expr [6149,6161]
===
match
---
atom [7807,7842]
atom [7807,7842]
===
match
---
trailer [4444,4446]
trailer [4444,4446]
===
match
---
suite [2016,2096]
suite [2016,2096]
===
match
---
atom [19052,19069]
atom [19496,19513]
===
match
---
string: 'BROKER_URL' [2128,2140]
string: 'BROKER_URL' [2128,2140]
===
match
---
name: execute_date [4688,4700]
name: execute_date [4688,4700]
===
match
---
name: task_tuples_to_send [5446,5465]
name: task_tuples_to_send [5446,5465]
===
match
---
import_from [1666,1700]
import_from [1666,1700]
===
match
---
name: backend [18215,18222]
name: backend [18481,18488]
===
match
---
name: TaskInstanceKey [1775,1790]
name: TaskInstanceKey [1775,1790]
===
match
---
expr_stmt [2711,2784]
expr_stmt [2711,2784]
===
match
---
atom_expr [6076,6145]
atom_expr [6076,6145]
===
match
---
comparison [12820,12859]
comparison [12820,12859]
===
match
---
name: mock [2723,2727]
name: mock [2723,2727]
===
match
---
name: celery_executor [12537,12552]
name: celery_executor [12537,12552]
===
match
---
trailer [18930,18945]
trailer [19350,19365]
===
match
---
trailer [18875,18884]
trailer [19279,19288]
===
match
---
name: key [9997,10000]
name: key [9997,10000]
===
match
---
argument [7218,7243]
argument [7218,7243]
===
match
---
simple_stmt [15496,15559]
simple_stmt [15496,15559]
===
match
---
name: mock_backend [17468,17480]
name: mock_backend [17468,17480]
===
match
---
trailer [5621,5626]
trailer [5621,5626]
===
match
---
name: patch [12352,12357]
name: patch [12352,12357]
===
match
---
name: assert_has_calls [11910,11926]
name: assert_has_calls [11910,11926]
===
match
---
trailer [15595,15602]
trailer [15595,15602]
===
match
---
operator: } [10421,10422]
operator: } [10421,10422]
===
match
---
expr_stmt [7509,7550]
expr_stmt [7509,7550]
===
match
---
operator: , [11569,11570]
operator: , [11569,11570]
===
match
---
operator: { [19044,19045]
operator: { [19488,19489]
===
match
---
string: 'airflow' [4012,4021]
string: 'airflow' [4012,4021]
===
match
---
simple_stmt [14086,14144]
simple_stmt [14086,14144]
===
match
---
name: mock_fork [12863,12872]
name: mock_fork [12863,12872]
===
match
---
operator: = [13591,13592]
operator: = [13591,13592]
===
match
---
operator: @ [2174,2175]
operator: @ [2174,2175]
===
match
---
with_stmt [19279,19764]
with_stmt [19867,20474]
===
match
---
name: State [10720,10725]
name: State [10720,10725]
===
match
---
simple_stmt [9303,9373]
simple_stmt [9303,9373]
===
match
---
comparison [5717,5900]
comparison [5717,5900]
===
match
---
operator: @ [11939,11940]
operator: @ [11939,11940]
===
match
---
atom_expr [16932,16949]
atom_expr [16932,16949]
===
match
---
dotted_name [18162,18185]
dotted_name [18428,18451]
===
match
---
name: celery_executor [1573,1588]
name: celery_executor [1573,1588]
===
match
---
atom_expr [10045,10065]
atom_expr [10045,10065]
===
match
---
name: queued_tasks [5521,5533]
name: queued_tasks [5521,5533]
===
match
---
number: 1 [7653,7654]
number: 1 [7653,7654]
===
match
---
simple_stmt [17834,17913]
simple_stmt [17956,18035]
===
match
---
name: event_buffer [9822,9834]
name: event_buffer [9822,9834]
===
match
---
testlist_comp [11971,12068]
testlist_comp [11971,12068]
===
match
---
dotted_name [1671,1689]
dotted_name [1671,1689]
===
match
---
expr_stmt [13038,13088]
expr_stmt [13038,13088]
===
match
---
operator: , [9762,9763]
operator: , [9762,9763]
===
match
---
trailer [5600,5621]
trailer [5600,5621]
===
match
---
operator: == [10717,10719]
operator: == [10717,10719]
===
match
---
testlist_comp [16115,16133]
testlist_comp [16115,16133]
===
match
---
operator: = [13010,13011]
operator: = [13010,13011]
===
match
---
name: assert_called_once_with [17931,17954]
name: assert_called_once_with [18053,18076]
===
match
---
name: airflow [1879,1886]
name: airflow [1879,1886]
===
match
---
trailer [19690,19722]
trailer [20400,20432]
===
match
---
operator: = [14266,14267]
operator: = [14266,14267]
===
match
---
operator: = [13085,13086]
operator: = [13085,13086]
===
match
---
trailer [9632,9642]
trailer [9632,9642]
===
match
---
funcdef [11515,11934]
funcdef [11515,11934]
===
match
---
parameters [12107,12142]
parameters [12107,12142]
===
match
---
operator: @ [3813,3814]
operator: @ [3813,3814]
===
match
---
comparison [9664,9711]
comparison [9664,9711]
===
match
---
import_from [1059,1084]
import_from [1059,1084]
===
match
---
name: raises [12489,12495]
name: raises [12489,12495]
===
match
---
name: worker [1245,1251]
name: worker [1245,1251]
===
match
---
atom_expr [18317,18331]
atom_expr [18583,18597]
===
match
---
assert_stmt [10560,10635]
assert_stmt [10560,10635]
===
match
---
atom_expr [10720,10732]
atom_expr [10720,10732]
===
match
---
name: line [11273,11277]
name: line [11273,11277]
===
match
---
atom [15032,15034]
atom [15032,15034]
===
match
---
operator: = [13690,13691]
operator: = [13690,13691]
===
match
---
trailer [13815,13856]
trailer [13815,13856]
===
match
---
operator: { [2576,2577]
operator: { [2576,2577]
===
match
---
name: dag_id [15596,15602]
name: dag_id [15596,15602]
===
match
---
string: "mysql" [17217,17224]
string: "mysql" [17217,17224]
===
match
---
atom_expr [2898,2914]
atom_expr [2898,2914]
===
match
---
number: 0 [6016,6017]
number: 0 [6016,6017]
===
match
---
trailer [3741,3755]
trailer [3741,3755]
===
match
---
name: celery_configuration [4817,4837]
name: celery_configuration [4817,4837]
===
match
---
number: 0 [6394,6395]
number: 0 [6394,6395]
===
match
---
operator: == [15029,15031]
operator: == [15029,15031]
===
match
---
argument [8929,8938]
argument [8929,8938]
===
match
---
string: 'fake_simple_ti' [9014,9030]
string: 'fake_simple_ti' [9014,9030]
===
match
---
name: mock_sync [11591,11600]
name: mock_sync [11591,11600]
===
match
---
name: BulkStateFetcher [18832,18848]
name: BulkStateFetcher [19228,19244]
===
match
---
string: 'airflow.executors.celery_executor.CeleryExecutor.sync' [11309,11364]
string: 'airflow.executors.celery_executor.CeleryExecutor.sync' [11309,11364]
===
match
---
name: executor [9392,9400]
name: executor [9392,9400]
===
match
---
param [11571,11590]
param [11571,11590]
===
match
---
atom_expr [9315,9341]
atom_expr [9315,9341]
===
match
---
name: execute [6865,6872]
name: execute [6865,6872]
===
match
---
trailer [6097,6142]
trailer [6097,6142]
===
match
---
atom [9838,9840]
atom [9838,9840]
===
match
---
atom_expr [15687,15701]
atom_expr [15687,15701]
===
match
---
name: mark [6633,6637]
name: mark [6633,6637]
===
match
---
with_stmt [12232,12900]
with_stmt [12232,12900]
===
match
---
name: queued_dttm [14854,14865]
name: queued_dttm [14854,14865]
===
match
---
name: state [1893,1898]
name: state [1893,1898]
===
match
---
string: 'airflow' [12035,12044]
string: 'airflow' [12035,12044]
===
match
---
operator: @ [18202,18203]
operator: @ [18468,18469]
===
match
---
operator: @ [18049,18050]
operator: @ [18315,18316]
===
match
---
trailer [5520,5533]
trailer [5520,5533]
===
match
---
comparison [15013,15034]
comparison [15013,15034]
===
match
---
parameters [16618,16624]
parameters [16618,16624]
===
match
---
assert_stmt [11144,11229]
assert_stmt [11144,11229]
===
match
---
string: "231" [16007,16012]
string: "231" [16007,16012]
===
match
---
operator: , [7173,7174]
operator: , [7173,7174]
===
match
---
operator: == [6401,6403]
operator: == [6401,6403]
===
match
---
trailer [3309,3323]
trailer [3309,3323]
===
match
---
atom_expr [8158,8194]
atom_expr [8158,8194]
===
match
---
atom_expr [8470,8499]
atom_expr [8470,8499]
===
match
---
argument [8686,8706]
argument [8686,8706]
===
match
---
simple_stmt [13038,13089]
simple_stmt [13038,13089]
===
match
---
fstring_string: ). [10001,10003]
fstring_string: ). [10001,10003]
===
match
---
trailer [14611,14662]
trailer [14611,14662]
===
match
---
simple_stmt [9657,9712]
simple_stmt [9657,9712]
===
match
---
number: 0 [7844,7845]
number: 0 [7844,7845]
===
match
---
trailer [14615,14622]
trailer [14615,14622]
===
match
---
argument [15536,15557]
argument [15536,15557]
===
match
---
operator: } [16199,16200]
operator: } [16199,16200]
===
match
---
operator: , [7540,7541]
operator: , [7540,7541]
===
match
---
atom_expr [19284,19298]
atom_expr [19872,19886]
===
match
---
operator: } [2601,2602]
operator: } [2601,2602]
===
match
---
operator: , [11862,11863]
operator: , [11862,11863]
===
match
---
name: executor [6525,6533]
name: executor [6525,6533]
===
match
---
operator: , [14638,14639]
operator: , [14638,14639]
===
match
---
name: event_buffer [6235,6247]
name: event_buffer [6235,6247]
===
match
---
operator: = [13823,13824]
operator: = [13823,13824]
===
match
---
param [2248,2252]
param [2248,2252]
===
match
---
dotted_name [18124,18147]
dotted_name [18390,18413]
===
match
---
simple_stmt [6219,6316]
simple_stmt [6219,6316]
===
match
---
dictorsetmaker [14782,14899]
dictorsetmaker [14782,14899]
===
match
---
arglist [6725,6744]
arglist [6725,6744]
===
match
---
simple_stmt [15328,15343]
simple_stmt [15328,15343]
===
match
---
strings [10299,10425]
strings [10299,10425]
===
match
---
operator: = [14236,14237]
operator: = [14236,14237]
===
match
---
atom_expr [14868,14898]
atom_expr [14868,14898]
===
match
---
operator: , [18016,18017]
operator: , [18138,18139]
===
match
---
atom_expr [14925,14939]
atom_expr [14925,14939]
===
match
---
dotted_name [3852,3875]
dotted_name [3852,3875]
===
match
---
atom [6248,6294]
atom [6248,6294]
===
match
---
simple_stmt [1874,1912]
simple_stmt [1874,1912]
===
match
---
suite [18303,19097]
suite [18569,19685]
===
match
---
simple_stmt [15006,15035]
simple_stmt [15006,15035]
===
match
---
trailer [2089,2094]
trailer [2089,2094]
===
match
---
argument [15461,15482]
argument [15461,15482]
===
match
---
atom_expr [6302,6315]
atom_expr [6302,6315]
===
match
---
param [11553,11570]
param [11553,11570]
===
match
---
argument [18931,18944]
argument [19351,19364]
===
match
---
trailer [2393,2397]
trailer [2393,2397]
===
match
---
param [2343,2355]
param [2343,2355]
===
match
---
operator: { [19790,19791]
operator: { [20500,20501]
===
match
---
atom_expr [11714,11756]
atom_expr [11714,11756]
===
match
---
simple_stmt [17791,17826]
simple_stmt [17913,17948]
===
match
---
argument [13973,13997]
argument [13973,13997]
===
match
---
atom_expr [10506,10541]
atom_expr [10506,10541]
===
match
---
name: date [13278,13282]
name: date [13278,13282]
===
match
---
trailer [16033,16040]
trailer [16033,16040]
===
match
---
name: mark [12913,12917]
name: mark [12913,12917]
===
match
---
operator: } [14428,14429]
operator: } [14428,14429]
===
match
---
operator: = [13322,13323]
operator: = [13322,13323]
===
match
---
trailer [8478,8499]
trailer [8478,8499]
===
match
---
name: integration [6638,6649]
name: integration [6638,6649]
===
match
---
argument [13960,13971]
argument [13960,13971]
===
match
---
atom_expr [18868,19017]
atom_expr [19272,19461]
===
match
---
testlist_comp [6354,6395]
testlist_comp [6354,6395]
===
match
---
name: TaskInstance [1761,1773]
name: TaskInstance [1761,1773]
===
match
---
name: tasks [6503,6508]
name: tasks [6503,6508]
===
match
---
name: when [7270,7274]
name: when [7270,7274]
===
match
---
if_stmt [2920,3350]
if_stmt [2920,3350]
===
match
---
name: app [4317,4320]
name: app [4317,4320]
===
match
---
atom_expr [2515,2551]
atom_expr [2515,2551]
===
match
---
operator: , [16778,16779]
operator: , [16778,16779]
===
match
---
trailer [15517,15558]
trailer [15517,15558]
===
match
---
string: "postgres" [12935,12945]
string: "postgres" [12935,12945]
===
match
---
name: executor [15735,15743]
name: executor [15735,15743]
===
match
---
operator: == [7847,7849]
operator: == [7847,7849]
===
match
---
number: 0 [7703,7704]
number: 0 [7703,7704]
===
match
---
simple_stmt [12643,12673]
simple_stmt [12643,12673]
===
match
---
trailer [17569,17742]
trailer [17691,17864]
===
match
---
string: 'fake_simple_ti' [5847,5863]
string: 'fake_simple_ti' [5847,5863]
===
match
---
name: task_id [7159,7166]
name: task_id [7159,7166]
===
match
---
atom_expr [15174,15195]
atom_expr [15174,15195]
===
match
---
atom_expr [17955,17963]
atom_expr [18077,18085]
===
match
---
name: pytest [19141,19147]
name: pytest [19729,19735]
===
match
---
name: command [4145,4152]
name: command [4145,4152]
===
match
---
suite [16787,16835]
suite [16787,16835]
===
match
---
simple_stmt [13366,13419]
simple_stmt [13366,13419]
===
match
---
name: start_worker [4465,4477]
name: start_worker [4465,4477]
===
match
---
name: executor [10045,10053]
name: executor [10045,10053]
===
match
---
trailer [6864,6894]
trailer [6864,6894]
===
match
---
expr_stmt [8612,8747]
expr_stmt [8612,8747]
===
match
---
name: executor [11663,11671]
name: executor [11663,11671]
===
match
---
name: value_tuple [9082,9093]
name: value_tuple [9082,9093]
===
match
---
atom [11996,12018]
atom [11996,12018]
===
match
---
trailer [19392,19399]
trailer [19980,19987]
===
match
---
number: 0 [6143,6144]
number: 0 [6143,6144]
===
match
---
dotted_name [11298,11308]
dotted_name [11298,11308]
===
match
---
operator: = [15818,15819]
operator: = [15818,15819]
===
match
---
atom_expr [5717,5744]
atom_expr [5717,5744]
===
match
---
atom_expr [13051,13068]
atom_expr [13051,13068]
===
match
---
number: 0 [6292,6293]
number: 0 [6292,6293]
===
match
---
operator: , [6290,6291]
operator: , [6290,6291]
===
match
---
name: celery_executor [14268,14283]
name: celery_executor [14268,14283]
===
match
---
name: celery_executor [18455,18470]
name: celery_executor [18721,18736]
===
match
---
trailer [8928,8970]
trailer [8928,8970]
===
match
---
name: executor [13373,13381]
name: executor [13373,13381]
===
match
---
testlist_comp [4632,5263]
testlist_comp [4632,5263]
===
match
---
atom_expr [17921,17964]
atom_expr [18043,18086]
===
match
---
simple_stmt [16296,16342]
simple_stmt [16296,16342]
===
match
---
trailer [11034,11036]
trailer [11034,11036]
===
match
---
name: call [11719,11723]
name: call [11719,11723]
===
match
---
atom_expr [2510,2552]
atom_expr [2510,2552]
===
match
---
operator: = [7187,7188]
operator: = [7187,7188]
===
match
---
operator: , [6579,6580]
operator: , [6579,6580]
===
match
---
string: 'success' [5969,5978]
string: 'success' [5969,5978]
===
match
---
simple_stmt [18859,19018]
simple_stmt [19263,19462]
===
match
---
number: 0 [6398,6399]
number: 0 [6398,6399]
===
match
---
trailer [19534,19763]
trailer [20244,20473]
===
match
---
import_from [1550,1612]
import_from [1550,1612]
===
match
---
comparison [14728,14909]
comparison [14728,14909]
===
match
---
trailer [17686,17701]
trailer [17808,17823]
===
match
---
simple_stmt [1045,1059]
simple_stmt [1045,1059]
===
match
---
suite [12460,12673]
suite [12460,12673]
===
match
---
trailer [15978,15984]
trailer [15978,15984]
===
match
---
name: queued_tasks [10585,10597]
name: queued_tasks [10585,10597]
===
match
---
suite [16727,16758]
suite [16727,16758]
===
match
---
funcdef [13470,15035]
funcdef [13470,15035]
===
match
---
name: BaseOperator [1653,1665]
name: BaseOperator [1653,1665]
===
match
---
name: heartbeat [10475,10484]
name: heartbeat [10475,10484]
===
match
---
number: 0 [4702,4703]
number: 0 [4702,4703]
===
match
---
atom_expr [6568,6585]
atom_expr [6568,6585]
===
match
---
trailer [8212,8219]
trailer [8212,8219]
===
match
---
trailer [17560,17569]
trailer [17682,17691]
===
match
---
fstring_start: f" [9951,9953]
fstring_start: f" [9951,9953]
===
match
---
trailer [11118,11124]
trailer [11118,11124]
===
match
---
name: timedelta [13551,13560]
name: timedelta [13551,13560]
===
match
---
operator: = [14209,14210]
operator: = [14209,14210]
===
match
---
name: parameterized [1361,1374]
name: parameterized [1361,1374]
===
match
---
name: backend [10780,10787]
name: backend [10780,10787]
===
match
---
expr_stmt [18518,18572]
expr_stmt [18906,18960]
===
match
---
name: expected_exception [12441,12459]
name: expected_exception [12441,12459]
===
match
---
simple_stmt [10648,10733]
simple_stmt [10648,10733]
===
match
---
suite [4321,6210]
suite [4321,6210]
===
match
---
atom_expr [12537,12577]
atom_expr [12537,12577]
===
match
---
name: DatabaseBackend [1201,1216]
name: DatabaseBackend [1201,1216]
===
match
---
name: tasks [5731,5736]
name: tasks [5731,5736]
===
match
---
simple_stmt [19312,19364]
simple_stmt [19900,19952]
===
match
---
string: 'success' [5771,5780]
string: 'success' [5771,5780]
===
match
---
param [16721,16725]
param [16721,16725]
===
match
---
simple_stmt [7270,7292]
simple_stmt [7270,7292]
===
match
---
simple_stmt [10560,10636]
simple_stmt [10560,10636]
===
match
---
name: dag_id [8694,8700]
name: dag_id [8694,8700]
===
match
---
trailer [10896,10917]
trailer [10896,10917]
===
match
---
operator: == [13412,13414]
operator: == [13412,13414]
===
match
---
dictorsetmaker [18754,18791]
dictorsetmaker [19142,19179]
===
match
---
operator: , [10795,10796]
operator: , [10795,10796]
===
match
---
suite [19270,19843]
suite [19858,20697]
===
match
---
number: 0 [6296,6297]
number: 0 [6296,6297]
===
match
---
trailer [14547,14555]
trailer [14547,14555]
===
match
---
atom [2032,2095]
atom [2032,2095]
===
match
---
string: "__enter__" [8327,8338]
string: "__enter__" [8327,8338]
===
match
---
decorator [12905,12947]
decorator [12905,12947]
===
match
---
atom [5770,5816]
atom [5770,5816]
===
match
---
name: any [11151,11154]
name: any [11151,11154]
===
match
---
import_name [827,837]
import_name [827,837]
===
match
---
trailer [7422,7481]
trailer [7422,7481]
===
match
---
operator: == [10542,10544]
operator: == [10542,10544]
===
match
---
operator: } [15960,15961]
operator: } [15960,15961]
===
match
---
operator: == [10256,10258]
operator: == [10256,10258]
===
match
---
atom [9282,9290]
atom [9282,9290]
===
match
---
atom_expr [4259,4313]
atom_expr [4259,4313]
===
match
---
trailer [12552,12568]
trailer [12552,12568]
===
match
---
atom_expr [15995,16013]
atom_expr [15995,16013]
===
match
---
simple_stmt [9053,9094]
simple_stmt [9053,9094]
===
match
---
name: celery [1090,1096]
name: celery [1090,1096]
===
match
---
operator: = [7464,7465]
operator: = [7464,7465]
===
match
---
suite [15133,16253]
suite [15133,16253]
===
match
---
atom [12887,12897]
atom [12887,12897]
===
match
---
decorated [6625,7863]
decorated [6625,7863]
===
match
---
trailer [14196,14208]
trailer [14196,14208]
===
match
---
assert_stmt [17834,17912]
assert_stmt [17956,18034]
===
match
---
operator: , [4485,4486]
operator: , [4485,4486]
===
match
---
trailer [18673,18686]
trailer [19061,19074]
===
match
---
arglist [10788,10807]
arglist [10788,10807]
===
match
---
trailer [5656,5671]
trailer [5656,5671]
===
match
---
parameters [15126,15132]
parameters [15126,15132]
===
match
---
decorator [2282,2309]
decorator [2282,2309]
===
match
---
name: get_many [19526,19534]
name: get_many [20236,20244]
===
match
---
atom_expr [12707,12747]
atom_expr [12707,12747]
===
match
---
dotted_name [18203,18222]
dotted_name [18469,18488]
===
match
---
operator: , [8563,8564]
operator: , [8563,8564]
===
match
---
arith_expr [13653,13693]
arith_expr [13653,13693]
===
match
---
name: state [2192,2197]
name: state [2192,2197]
===
match
---
name: key [7646,7649]
name: key [7646,7649]
===
match
---
operator: , [11814,11815]
operator: , [11814,11815]
===
match
---
operator: = [14511,14512]
operator: = [14511,14512]
===
match
---
funcdef [2188,2231]
funcdef [2188,2231]
===
match
---
name: parameterized [3764,3777]
name: parameterized [3764,3777]
===
match
---
operator: } [10546,10547]
operator: } [10546,10547]
===
match
---
atom [11971,11993]
atom [11971,11993]
===
match
---
string: "mysql" [13445,13452]
string: "mysql" [13445,13452]
===
match
---
simple_stmt [11692,11885]
simple_stmt [11692,11885]
===
match
---
arglist [12926,12945]
arglist [12926,12945]
===
match
---
string: "to_dict.return_value" [18729,18751]
string: "to_dict.return_value" [19117,19139]
===
match
---
name: mock_backend [19312,19324]
name: mock_backend [19900,19912]
===
match
---
name: pytest [6664,6670]
name: pytest [6664,6670]
===
match
---
suite [16521,16602]
suite [16521,16602]
===
match
---
name: execute_date [4541,4553]
name: execute_date [4541,4553]
===
match
---
testlist_comp [11972,11992]
testlist_comp [11972,11992]
===
match
---
operator: , [5262,5263]
operator: , [5262,5263]
===
match
---
simple_stmt [16873,16903]
simple_stmt [16873,16903]
===
match
---
assert_stmt [8518,8598]
assert_stmt [8518,8598]
===
match
---
operator: , [11745,11746]
operator: , [11745,11746]
===
match
---
simple_stmt [18822,18851]
simple_stmt [19218,19247]
===
match
---
name: test_config [2652,2663]
name: test_config [2652,2663]
===
match
---
operator: @ [6663,6664]
operator: @ [6663,6664]
===
match
---
assert_stmt [10145,10214]
assert_stmt [10145,10214]
===
match
---
name: database [1185,1193]
name: database [1185,1193]
===
match
---
simple_stmt [10937,10981]
simple_stmt [10937,10981]
===
match
---
atom [5541,5571]
atom [5541,5571]
===
match
---
simple_stmt [12707,12748]
simple_stmt [12707,12748]
===
match
---
name: self [12108,12112]
name: self [12108,12112]
===
match
---
operator: = [5539,5540]
operator: = [5539,5540]
===
match
---
testlist_comp [11997,12017]
testlist_comp [11997,12017]
===
match
---
name: result [17981,17987]
name: result [18103,18109]
===
match
---
atom_expr [17672,17701]
atom_expr [17794,17823]
===
match
---
arglist [8929,8969]
arglist [8929,8969]
===
match
---
expr_stmt [11692,11884]
expr_stmt [11692,11884]
===
match
---
simple_stmt [17544,17743]
simple_stmt [17666,17865]
===
match
---
name: Celery [2619,2625]
name: Celery [2619,2625]
===
match
---
atom_expr [15576,15642]
atom_expr [15576,15642]
===
match
---
name: items [16555,16560]
name: items [16555,16560]
===
match
---
name: self [17277,17281]
name: self [17277,17281]
===
match
---
testlist_comp [19053,19068]
testlist_comp [19497,19512]
===
match
---
name: State [7850,7855]
name: State [7850,7855]
===
match
---
param [3689,3693]
param [3689,3693]
===
match
---
trailer [8219,8393]
trailer [8219,8393]
===
match
---
string: 'airflow.executors.celery_executor._execute_in_subprocess' [12261,12319]
string: 'airflow.executors.celery_executor._execute_in_subprocess' [12261,12319]
===
match
---
atom_expr [18437,18500]
atom_expr [18703,18766]
===
match
---
operator: = [11698,11699]
operator: = [11698,11699]
===
match
---
name: os [824,826]
name: os [824,826]
===
match
---
simple_stmt [9806,9841]
simple_stmt [9806,9841]
===
match
---
comparison [16303,16341]
comparison [16303,16341]
===
match
---
string: '123' [19045,19050]
string: '123' [19489,19494]
===
match
---
operator: { [8503,8504]
operator: { [8503,8504]
===
match
---
name: airflow [1671,1678]
name: airflow [1671,1678]
===
match
---
name: setUp [3596,3601]
name: setUp [3596,3601]
===
match
---
name: executor [9669,9677]
name: executor [9669,9677]
===
match
---
atom [6550,6552]
atom [6550,6552]
===
match
---
trailer [3347,3349]
trailer [3347,3349]
===
match
---
atom_expr [15746,15778]
atom_expr [15746,15778]
===
match
---
operator: } [16163,16164]
operator: } [16163,16164]
===
match
---
operator: { [14427,14428]
operator: { [14427,14428]
===
match
---
name: mget_args [17791,17800]
name: mget_args [17913,17922]
===
match
---
operator: } [10260,10261]
operator: } [10260,10261]
===
match
---
assert_stmt [10648,10732]
assert_stmt [10648,10732]
===
match
---
atom_expr [3302,3325]
atom_expr [3302,3325]
===
match
---
atom [4987,5030]
atom [4987,5030]
===
match
---
name: state [19706,19711]
name: state [20416,20421]
===
match
---
argument [7450,7479]
argument [7450,7479]
===
match
---
trailer [11809,11813]
trailer [11809,11813]
===
match
---
name: call_args [12873,12882]
name: call_args [12873,12882]
===
match
---
trailer [10877,10879]
trailer [10877,10879]
===
match
---
operator: = [13254,13255]
operator: = [13254,13255]
===
match
---
expr_stmt [2426,2490]
expr_stmt [2426,2490]
===
match
---
name: result [17544,17550]
name: result [17666,17672]
===
match
---
or_test [12820,12899]
or_test [12820,12899]
===
match
---
name: executor [14733,14741]
name: executor [14733,14741]
===
match
---
parameters [16720,16726]
parameters [16720,16726]
===
match
---
operator: = [8718,8719]
operator: = [8718,8719]
===
match
---
name: event_buffer [6085,6097]
name: event_buffer [6085,6097]
===
match
---
name: BashOperator [8619,8631]
name: BashOperator [8619,8631]
===
match
---
name: key [7585,7588]
name: key [7585,7588]
===
match
---
simple_stmt [6179,6210]
simple_stmt [6179,6210]
===
match
---
operator: , [5060,5061]
operator: , [5060,5061]
===
match
---
trailer [15246,15254]
trailer [15246,15254]
===
match
---
expr_stmt [13292,13304]
expr_stmt [13292,13304]
===
match
---
name: mock [11747,11751]
name: mock [11747,11751]
===
match
---
return_stmt [2025,2095]
return_stmt [2025,2095]
===
match
---
name: BashOperator [7129,7141]
name: BashOperator [7129,7141]
===
match
---
operator: == [4412,4414]
operator: == [4412,4414]
===
match
---
name: ANY [11869,11872]
name: ANY [11869,11872]
===
match
---
string: 'tasks' [12046,12053]
string: 'tasks' [12046,12053]
===
match
---
simple_stmt [1310,1356]
simple_stmt [1310,1356]
===
match
---
operator: , [17646,17647]
operator: , [17768,17769]
===
match
---
atom_expr [13373,13411]
atom_expr [13373,13411]
===
match
---
string: "true" [7188,7194]
string: "true" [7188,7194]
===
match
---
name: timedelta [885,894]
name: timedelta [885,894]
===
match
---
name: return_value [18637,18649]
name: return_value [19025,19037]
===
match
---
simple_stmt [3652,3671]
simple_stmt [3652,3671]
===
match
---
atom_expr [15604,15618]
atom_expr [15604,15618]
===
match
---
operator: = [6872,6873]
operator: = [6872,6873]
===
match
---
string: "INFO:airflow.executors.celery_executor.CeleryExecutor:" [9878,9934]
string: "INFO:airflow.executors.celery_executor.CeleryExecutor:" [9878,9934]
===
match
---
atom_expr [12237,12329]
atom_expr [12237,12329]
===
match
---
trailer [13622,13630]
trailer [13622,13630]
===
match
---
param [19264,19268]
param [19852,19856]
===
match
---
string: 'CELERY_BROKER_URLS' [1981,2001]
string: 'CELERY_BROKER_URLS' [1981,2001]
===
match
---
testlist_comp [4089,4109]
testlist_comp [4089,4109]
===
match
---
decorator [6625,6659]
decorator [6625,6659]
===
match
---
name: test_try_adopt_task_instances [13474,13503]
name: test_try_adopt_task_instances [13474,13503]
===
match
---
assert_stmt [16209,16252]
assert_stmt [16209,16252]
===
match
---
trailer [8967,8969]
trailer [8967,8969]
===
match
---
string: 'fail' [5839,5845]
string: 'fail' [5839,5845]
===
match
---
name: _prepare_app [10865,10877]
name: _prepare_app [10865,10877]
===
match
---
name: baseoperator [1633,1645]
name: baseoperator [1633,1645]
===
match
---
operator: , [19704,19705]
operator: , [20414,20415]
===
match
---
simple_stmt [3334,3350]
simple_stmt [3334,3350]
===
match
---
operator: @ [10738,10739]
operator: @ [10738,10739]
===
match
---
name: executor [14925,14933]
name: executor [14925,14933]
===
match
---
name: backend [6717,6724]
name: backend [6717,6724]
===
match
---
name: conf [1431,1435]
name: conf [1431,1435]
===
match
---
string: "Task should no longer be in queue" [10600,10635]
string: "Task should no longer be in queue" [10600,10635]
===
match
---
string: "PENDING" [18026,18035]
string: "PENDING" [18148,18157]
===
match
---
name: executor [5512,5520]
name: executor [5512,5520]
===
match
---
comparison [12863,12899]
comparison [12863,12899]
===
match
---
name: pytest [3852,3858]
name: pytest [3852,3858]
===
match
---
decorators [19102,19223]
decorators [19690,19811]
===
match
---
trailer [12568,12577]
trailer [12568,12577]
===
match
---
decorator [2174,2184]
decorator [2174,2184]
===
match
---
trailer [10169,10182]
trailer [10169,10182]
===
match
---
funcdef [15086,16253]
funcdef [15086,16253]
===
match
---
simple_stmt [10227,10262]
simple_stmt [10227,10262]
===
match
---
name: line [11264,11268]
name: line [11264,11268]
===
match
---
simple_stmt [15651,15726]
simple_stmt [15651,15726]
===
match
---
dotted_name [3893,3912]
dotted_name [3893,3912]
===
match
---
name: adopted_task_timeouts [14742,14763]
name: adopted_task_timeouts [14742,14763]
===
match
---
with_item [12347,12424]
with_item [12347,12424]
===
match
---
operator: , [8382,8383]
operator: , [8382,8383]
===
match
---
trailer [2568,2575]
trailer [2568,2575]
===
match
---
trailer [10584,10597]
trailer [10584,10597]
===
match
---
operator: = [3300,3301]
operator: = [3300,3301]
===
match
---
simple_stmt [2426,2491]
simple_stmt [2426,2491]
===
match
---
name: try_adopt_task_instances [13382,13406]
name: try_adopt_task_instances [13382,13406]
===
match
---
param [10844,10848]
param [10844,10848]
===
match
---
atom_expr [14803,14833]
atom_expr [14803,14833]
===
match
---
atom_expr [8142,8156]
atom_expr [8142,8156]
===
match
---
operator: = [2651,2652]
operator: = [2651,2652]
===
match
---
simple_stmt [1436,1504]
simple_stmt [1436,1504]
===
match
---
name: DAG [13103,13106]
name: DAG [13103,13106]
===
match
---
dotted_name [1555,1588]
dotted_name [1555,1588]
===
match
---
operator: @ [11370,11371]
operator: @ [11370,11371]
===
match
---
atom_expr [14336,14341]
atom_expr [14336,14341]
===
match
---
atom_expr [10429,10438]
atom_expr [10429,10438]
===
match
---
expr_stmt [17499,17527]
expr_stmt [17621,17649]
===
match
---
operator: } [6551,6552]
operator: } [6551,6552]
===
match
---
name: patch [19387,19392]
name: patch [19975,19980]
===
match
---
operator: = [13568,13569]
operator: = [13568,13569]
===
match
---
operator: , [17084,17085]
operator: , [17084,17085]
===
match
---
operator: , [12857,12858]
operator: , [12857,12858]
===
match
---
name: self [8030,8034]
name: self [8030,8034]
===
match
---
string: "123" [18939,18944]
string: "123" [19359,19364]
===
match
---
simple_stmt [17921,17965]
simple_stmt [18043,18087]
===
match
---
return_stmt [16873,16902]
return_stmt [16873,16902]
===
match
---
trailer [11131,11133]
trailer [11131,11133]
===
match
---
name: object [17429,17435]
name: object [17429,17435]
===
match
---
trailer [6409,6416]
trailer [6409,6416]
===
match
---
trailer [16940,16949]
trailer [16940,16949]
===
match
---
operator: = [4009,4010]
operator: = [4009,4010]
===
match
---
trailer [13354,13356]
trailer [13354,13356]
===
match
---
comparison [14357,14393]
comparison [14357,14393]
===
match
---
simple_stmt [16736,16758]
simple_stmt [16736,16758]
===
match
---
trailer [7855,7862]
trailer [7855,7862]
===
match
---
expr_stmt [7563,7603]
expr_stmt [7563,7603]
===
match
---
trailer [2815,2882]
trailer [2815,2882]
===
match
---
name: integration [18136,18147]
name: integration [18402,18413]
===
match
---
name: clear_db_jobs [3655,3668]
name: clear_db_jobs [3655,3668]
===
match
---
arglist [13960,13997]
arglist [13960,13997]
===
match
---
trailer [17676,17686]
trailer [17798,17808]
===
match
---
string: 'success' [4659,4668]
string: 'success' [4659,4668]
===
match
---
operator: } [9289,9290]
operator: } [9289,9290]
===
match
---
fstring_start: f" [10372,10374]
fstring_start: f" [10372,10374]
===
match
---
assert_stmt [13366,13418]
assert_stmt [13366,13418]
===
match
---
name: utcnow [13662,13668]
name: utcnow [13662,13668]
===
match
---
comparison [4397,4417]
comparison [4397,4417]
===
match
---
name: start_date [15536,15546]
name: start_date [15536,15546]
===
match
---
name: TestCeleryExecutor [3549,3567]
name: TestCeleryExecutor [3549,3567]
===
match
---
name: task_adoption_timeout [14812,14833]
name: task_adoption_timeout [14812,14833]
===
match
---
operator: , [7364,7365]
operator: , [7364,7365]
===
match
---
name: value_tuple [7592,7603]
name: value_tuple [7592,7603]
===
match
---
dotted_name [2283,2308]
dotted_name [2283,2308]
===
match
---
name: MagicMock [18716,18725]
name: MagicMock [19104,19113]
===
match
---
operator: , [19815,19816]
operator: , [20525,20526]
===
match
---
operator: , [12897,12898]
operator: , [12897,12898]
===
match
---
name: pytest [17118,17124]
name: pytest [17118,17124]
===
match
---
name: dag [15404,15407]
name: dag [15404,15407]
===
match
---
string: 'fake_simple_ti' [5980,5996]
string: 'fake_simple_ti' [5980,5996]
===
match
---
atom_expr [16803,16816]
atom_expr [16803,16816]
===
match
---
string: "232" [14990,14995]
string: "232" [14990,14995]
===
match
---
trailer [11058,11077]
trailer [11058,11077]
===
match
---
simple_stmt [8518,8599]
simple_stmt [8518,8599]
===
match
---
suite [16625,16703]
suite [16625,16703]
===
match
---
name: Celery [1078,1084]
name: Celery [1078,1084]
===
match
---
simple_stmt [11893,11934]
simple_stmt [11893,11934]
===
match
---
name: mark [18131,18135]
name: mark [18397,18401]
===
match
---
name: executor [9813,9821]
name: executor [9813,9821]
===
match
---
comparison [10567,10598]
comparison [10567,10598]
===
match
---
operator: , [4939,4940]
operator: , [4939,4940]
===
match
---
operator: = [4515,4516]
operator: = [4515,4516]
===
match
---
name: close [3342,3347]
name: close [3342,3347]
===
match
---
trailer [2530,2551]
trailer [2530,2551]
===
match
---
operator: , [15701,15702]
operator: , [15701,15702]
===
match
---
name: celery_executor [15746,15761]
name: celery_executor [15746,15761]
===
match
---
operator: , [8338,8339]
operator: , [8338,8339]
===
match
---
name: task_id [14548,14555]
name: task_id [14548,14555]
===
match
---
assert_stmt [10078,10132]
assert_stmt [10078,10132]
===
match
---
trailer [2117,2141]
trailer [2117,2141]
===
match
---
name: dag [14612,14615]
name: dag [14612,14615]
===
match
---
simple_stmt [16381,16487]
simple_stmt [16381,16487]
===
match
---
name: mark [6712,6716]
name: mark [6712,6716]
===
match
---
trailer [15591,15642]
trailer [15591,15642]
===
match
---
name: integration [19115,19126]
name: integration [19703,19714]
===
match
---
trailer [18977,18992]
trailer [19405,19420]
===
match
---
operator: , [8971,8972]
operator: , [8971,8972]
===
match
---
operator: , [7734,7735]
operator: , [7734,7735]
===
match
---
operator: , [2636,2637]
operator: , [2636,2637]
===
match
---
trailer [8189,8193]
trailer [8189,8193]
===
match
---
operator: = [8677,8678]
operator: = [8677,8678]
===
match
---
name: cm [10008,10010]
name: cm [10008,10010]
===
match
---
operator: , [12018,12019]
operator: , [12018,12019]
===
match
---
operator: , [15712,15713]
operator: , [15712,15713]
===
match
---
name: models [1714,1720]
name: models [1714,1720]
===
match
---
atom [18753,18792]
atom [19141,19180]
===
match
---
number: 0 [5814,5815]
number: 0 [5814,5815]
===
match
---
arglist [13816,13855]
arglist [13816,13855]
===
match
---
trailer [9074,9079]
trailer [9074,9079]
===
match
---
simple_stmt [15970,16042]
simple_stmt [15970,16042]
===
match
---
atom_expr [14092,14143]
atom_expr [14092,14143]
===
match
---
expr_stmt [8760,8781]
expr_stmt [8760,8781]
===
match
---
atom_expr [13732,13773]
atom_expr [13732,13773]
===
match
---
parameters [13503,13509]
parameters [13503,13509]
===
match
---
decorators [7868,7989]
decorators [7868,7989]
===
match
---
operator: = [8806,8807]
operator: = [8806,8807]
===
match
---
name: dag [1686,1689]
name: dag [1686,1689]
===
match
---
name: key_2 [15651,15656]
name: key_2 [15651,15656]
===
match
---
operator: + [15918,15919]
operator: + [15918,15919]
===
match
---
name: contextmanager [2294,2308]
name: contextmanager [2294,2308]
===
match
---
trailer [9748,9761]
trailer [9748,9761]
===
match
---
name: mock [17672,17676]
name: mock [17794,17798]
===
match
---
name: unittest [16932,16940]
name: unittest [16932,16940]
===
match
---
trailer [2733,2784]
trailer [2733,2784]
===
match
---
name: heartbeat [10054,10063]
name: heartbeat [10054,10063]
===
match
---
import_name [805,816]
import_name [805,816]
===
match
---
name: __name__ [16670,16678]
name: __name__ [16670,16678]
===
match
---
atom_expr [18533,18572]
atom_expr [18921,18960]
===
match
---
name: start_worker [1259,1271]
name: start_worker [1259,1271]
===
match
---
argument [15443,15459]
argument [15443,15459]
===
match
---
name: result [19509,19515]
name: result [20219,20225]
===
match
---
name: dumps [17058,17063]
name: dumps [17058,17063]
===
match
---
name: start [4439,4444]
name: start [4439,4444]
===
match
---
atom_expr [14728,14764]
atom_expr [14728,14764]
===
match
---
operator: , [7832,7833]
operator: , [7832,7833]
===
match
---
parameters [17276,17293]
parameters [17276,17293]
===
match
---
string: "redis" [19127,19134]
string: "redis" [19715,19722]
===
match
---
trailer [16554,16560]
trailer [16554,16560]
===
match
---
name: exec_date [14133,14142]
name: exec_date [14133,14142]
===
match
---
trailer [11723,11756]
trailer [11723,11756]
===
match
---
name: FAILED [16150,16156]
name: FAILED [16150,16156]
===
match
---
operator: = [8363,8364]
operator: = [8363,8364]
===
match
---
name: pytest [3814,3820]
name: pytest [3814,3820]
===
match
---
comparison [10299,10438]
comparison [10299,10438]
===
match
---
operator: { [16680,16681]
operator: { [16680,16681]
===
match
---
parameters [16850,16863]
parameters [16850,16863]
===
match
---
expr_stmt [13519,13571]
expr_stmt [13519,13571]
===
match
---
atom_expr [16820,16834]
atom_expr [16820,16834]
===
match
---
name: celery_executor [17380,17395]
name: celery_executor [17380,17395]
===
match
---
operator: , [15602,15603]
operator: , [15602,15603]
===
match
---
trailer [7645,7650]
trailer [7645,7650]
===
match
---
name: backend [3302,3309]
name: backend [3302,3309]
===
match
---
name: return_value [18657,18669]
name: return_value [19045,19057]
===
match
---
simple_stmt [17499,17528]
simple_stmt [17621,17650]
===
match
---
with_stmt [17413,17743]
with_stmt [17413,17865]
===
match
---
parameters [4144,4153]
parameters [4144,4153]
===
match
---
name: self [16584,16588]
name: self [16584,16588]
===
match
---
atom [5838,5881]
atom [5838,5881]
===
match
---
trailer [10063,10065]
trailer [10063,10065]
===
match
---
operator: = [2896,2897]
operator: = [2896,2897]
===
match
---
name: datetime [7277,7285]
name: datetime [7277,7285]
===
match
---
atom_expr [10085,10120]
atom_expr [10085,10120]
===
match
---
name: mark [18210,18214]
name: mark [18476,18480]
===
match
---
operator: = [13627,13628]
operator: = [13627,13628]
===
match
---
simple_stmt [1085,1164]
simple_stmt [1085,1164]
===
match
---
dictorsetmaker [14944,14996]
dictorsetmaker [14944,14996]
===
match
---
operator: , [11551,11552]
operator: , [11551,11552]
===
match
---
trailer [14324,14332]
trailer [14324,14332]
===
match
---
name: FAILED [7856,7862]
name: FAILED [7856,7862]
===
match
---
name: value_tuple [8794,8805]
name: value_tuple [8794,8805]
===
match
---
trailer [13668,13670]
trailer [13668,13670]
===
match
---
funcdef [16607,16703]
funcdef [16607,16703]
===
match
---
param [12123,12141]
param [12123,12141]
===
match
---
trailer [7843,7846]
trailer [7843,7846]
===
match
---
operator: , [5030,5031]
operator: , [5030,5031]
===
match
---
name: self [16743,16747]
name: self [16743,16747]
===
match
---
argument [19623,19638]
argument [20333,20348]
===
match
---
name: airflow [1441,1448]
name: airflow [1441,1448]
===
match
---
simple_stmt [10499,10548]
simple_stmt [10499,10548]
===
match
---
operator: = [13801,13802]
operator: = [13801,13802]
===
match
---
trailer [7584,7589]
trailer [7584,7589]
===
match
---
name: executor [10511,10519]
name: executor [10511,10519]
===
match
---
name: mark [13432,13436]
name: mark [13432,13436]
===
match
---
name: execute_date [5865,5877]
name: execute_date [5865,5877]
===
match
---
atom [17052,17105]
atom [17052,17105]
===
match
---
argument [7159,7173]
argument [7159,7173]
===
match
---
name: url [18401,18404]
name: url [18667,18670]
===
match
---
trailer [6154,6161]
trailer [6154,6161]
===
match
---
operator: == [16195,16197]
operator: == [16195,16197]
===
match
---
name: task_adoption_timeout [15864,15885]
name: task_adoption_timeout [15864,15885]
===
match
---
name: patch [11303,11308]
name: patch [11303,11308]
===
match
---
name: task_id [19608,19615]
name: task_id [20318,20325]
===
match
---
funcdef [4120,4245]
funcdef [4120,4245]
===
match
---
name: start_date [13834,13844]
name: start_date [13834,13844]
===
match
---
name: utils [1887,1892]
name: utils [1887,1892]
===
match
---
name: command [5421,5428]
name: command [5421,5428]
===
match
---
name: start_date [13909,13919]
name: start_date [13909,13919]
===
match
---
operator: == [12843,12845]
operator: == [12843,12845]
===
match
---
string: "Assert Default Max Retries is 3" [8565,8598]
string: "Assert Default Max Retries is 3" [8565,8598]
===
match
---
operator: { [10259,10260]
operator: { [10259,10260]
===
match
---
atom_expr [11663,11683]
atom_expr [11663,11683]
===
match
---
comparison [16180,16200]
comparison [16180,16200]
===
match
---
string: 'airflow.executors.celery_executor.execute_command' [2816,2867]
string: 'airflow.executors.celery_executor.execute_command' [2816,2867]
===
match
---
operator: { [9838,9839]
operator: { [9838,9839]
===
match
---
trailer [13661,13668]
trailer [13661,13668]
===
match
---
trailer [10510,10541]
trailer [10510,10541]
===
match
---
name: integration [3864,3875]
name: integration [3864,3875]
===
match
---
operator: , [9036,9037]
operator: , [9036,9037]
===
match
---
name: mock_backend [18487,18499]
name: mock_backend [18753,18765]
===
match
---
name: task_publish_retries [9678,9698]
name: task_publish_retries [9678,9698]
===
match
---
with_stmt [12477,12578]
with_stmt [12477,12578]
===
match
---
trailer [14417,14423]
trailer [14417,14423]
===
match
---
dotted_name [1315,1333]
dotted_name [1315,1333]
===
match
---
atom_expr [11747,11755]
atom_expr [11747,11755]
===
match
---
atom [4658,4704]
atom [4658,4704]
===
match
---
decorator [18123,18157]
decorator [18389,18423]
===
match
---
atom_expr [11155,11198]
atom_expr [11155,11198]
===
match
---
expr_stmt [13158,13220]
expr_stmt [13158,13220]
===
match
---
trailer [17375,17400]
trailer [17375,17400]
===
match
---
return_stmt [2263,2279]
return_stmt [2263,2279]
===
match
---
name: TestBulkStateFetcher [16911,16931]
name: TestBulkStateFetcher [16911,16931]
===
match
---
import_from [1164,1216]
import_from [1164,1216]
===
match
---
arglist [7439,7479]
arglist [7439,7479]
===
match
---
operator: , [18399,18400]
operator: , [18665,18666]
===
match
---
simple_stmt [13292,13305]
simple_stmt [13292,13305]
===
match
---
name: datetime [8719,8727]
name: datetime [8719,8727]
===
match
---
trailer [2113,2117]
trailer [2113,2117]
===
match
---
atom [5968,6014]
atom [5968,6014]
===
match
---
name: executor [10090,10098]
name: executor [10090,10098]
===
match
---
param [18283,18288]
param [18549,18554]
===
match
---
name: task_2 [14110,14116]
name: task_2 [14110,14116]
===
match
---
operator: , [13196,13197]
operator: , [13196,13197]
===
match
---
trailer [14298,14300]
trailer [14298,14300]
===
match
---
operator: @ [17117,17118]
operator: @ [17117,17118]
===
match
---
testlist_comp [4987,5240]
testlist_comp [4987,5240]
===
match
---
name: self [16619,16623]
name: self [16619,16623]
===
match
---
name: mark [6671,6675]
name: mark [6671,6675]
===
match
---
number: 3 [8562,8563]
number: 3 [8562,8563]
===
match
---
number: 1 [8853,8854]
number: 1 [8853,8854]
===
match
---
expr_stmt [17791,17825]
expr_stmt [17913,17947]
===
match
---
name: ANY [11810,11813]
name: ANY [11810,11813]
===
match
---
testlist_comp [5839,5880]
testlist_comp [5839,5880]
===
match
---
trailer [14283,14298]
trailer [14283,14298]
===
match
---
name: task_id [15443,15450]
name: task_id [15443,15450]
===
match
---
trailer [14155,14176]
trailer [14155,14176]
===
match
---
parameters [8029,8035]
parameters [8029,8035]
===
match
---
arglist [7159,7243]
arglist [7159,7243]
===
match
---
return_stmt [16736,16757]
return_stmt [16736,16757]
===
match
---
operator: == [14333,14335]
operator: == [14333,14335]
===
match
---
operator: == [6019,6021]
operator: == [6019,6021]
===
match
---
fstring_end: " [16701,16702]
fstring_end: " [16701,16702]
===
match
---
trailer [12670,12672]
trailer [12670,12672]
===
match
---
trailer [8448,8450]
trailer [8448,8450]
===
match
---
simple_stmt [4390,4418]
simple_stmt [4390,4418]
===
match
---
name: mock [12237,12241]
name: mock [12237,12241]
===
match
---
name: timedelta [13613,13622]
name: timedelta [13613,13622]
===
match
---
argument [7423,7480]
argument [7423,7480]
===
match
---
atom_expr [16050,16065]
atom_expr [16050,16065]
===
match
---
testlist_comp [6249,6293]
testlist_comp [6249,6293]
===
match
---
name: mock [11298,11302]
name: mock [11298,11302]
===
match
---
fstring_end: " [10003,10004]
fstring_end: " [10003,10004]
===
match
---
trailer [11124,11131]
trailer [11124,11131]
===
match
---
name: mark [19189,19193]
name: mark [19777,19781]
===
match
---
atom_expr [9624,9644]
atom_expr [9624,9644]
===
match
---
dotted_name [1796,1818]
dotted_name [1796,1818]
===
match
---
operator: , [2126,2127]
operator: , [2126,2127]
===
match
---
raise_stmt [4214,4244]
raise_stmt [4214,4244]
===
match
---
atom [6098,6141]
atom [6098,6141]
===
match
---
name: _ [17802,17803]
name: _ [17924,17925]
===
match
---
expr_stmt [14193,14222]
expr_stmt [14193,14222]
===
match
---
name: key_1 [14782,14787]
name: key_1 [14782,14787]
===
match
---
name: dag [15592,15595]
name: dag [15592,15595]
===
match
---
expr_stmt [13313,13356]
expr_stmt [13313,13356]
===
match
---
name: ClassWithCustomAttributes [16350,16375]
name: ClassWithCustomAttributes [16350,16375]
===
match
---
operator: = [2434,2435]
operator: = [2434,2435]
===
match
---
string: 'command' [8826,8835]
string: 'command' [8826,8835]
===
match
---
operator: = [13844,13845]
operator: = [13844,13845]
===
match
---
simple_stmt [1397,1436]
simple_stmt [1397,1436]
===
match
---
name: airflow [1555,1562]
name: airflow [1555,1562]
===
match
---
name: _get_many_using_multiprocessing [11078,11109]
name: _get_many_using_multiprocessing [11078,11109]
===
match
---
arglist [2118,2140]
arglist [2118,2140]
===
match
---
atom_expr [6494,6508]
atom_expr [6494,6508]
===
match
---
name: TaskInstance [13237,13249]
name: TaskInstance [13237,13249]
===
match
---
fstring_string: [Try 2 of 3] Task Timeout Error for Task: ( [9953,9996]
fstring_string: [Try 2 of 3] Task Timeout Error for Task: ( [9953,9996]
===
match
---
name: __ne__ [16844,16850]
name: __ne__ [16844,16850]
===
match
---
dotted_name [7907,7930]
dotted_name [7907,7930]
===
match
---
argument [11155,11228]
argument [11155,11228]
===
match
---
comparison [16081,16164]
comparison [16081,16164]
===
match
---
simple_stmt [2213,2231]
simple_stmt [2213,2231]
===
match
---
name: key [5622,5625]
name: key [5622,5625]
===
match
---
comparison [11249,11268]
comparison [11249,11268]
===
match
---
simple_stmt [8407,8451]
simple_stmt [8407,8451]
===
match
---
name: kwargs [16548,16554]
name: kwargs [16548,16554]
===
match
---
name: simple_ti [5561,5570]
name: simple_ti [5561,5570]
===
match
---
name: self [13504,13508]
name: self [13504,13508]
===
match
---
trailer [5721,5744]
trailer [5721,5744]
===
match
---
name: tasks [14934,14939]
name: tasks [14934,14939]
===
match
---
arglist [13445,13464]
arglist [13445,13464]
===
match
---
string: "SUCCESS" [18764,18773]
string: "SUCCESS" [19152,19161]
===
match
---
simple_stmt [15787,15962]
simple_stmt [15787,15962]
===
match
---
atom_expr [3625,3643]
atom_expr [3625,3643]
===
match
---
simple_stmt [2669,2707]
simple_stmt [2669,2707]
===
match
---
operator: @ [18123,18124]
operator: @ [18389,18390]
===
match
---
operator: , [15534,15535]
operator: , [15534,15535]
===
match
---
trailer [16583,16601]
trailer [16583,16601]
===
match
---
fstring_start: f" [9530,9532]
fstring_start: f" [9530,9532]
===
match
---
decorated [16956,18044]
decorated [16956,18310]
===
match
---
name: pytest [6705,6711]
name: pytest [6705,6711]
===
match
---
operator: = [2682,2683]
operator: = [2682,2683]
===
match
---
string: "INFO:airflow.executors.celery_executor.CeleryExecutor:" [9457,9513]
string: "INFO:airflow.executors.celery_executor.CeleryExecutor:" [9457,9513]
===
match
---
operator: , [5419,5420]
operator: , [5419,5420]
===
match
---
operator: == [14424,14426]
operator: == [14424,14426]
===
match
---
comparison [9392,9419]
comparison [9392,9419]
===
match
---
name: result [18859,18865]
name: result [19263,19269]
===
match
---
name: assertLogs [8163,8173]
name: assertLogs [8163,8173]
===
match
---
name: mock_stats_gauge [11893,11909]
name: mock_stats_gauge [11893,11909]
===
match
---
trailer [16149,16156]
trailer [16149,16156]
===
match
---
atom [9417,9419]
atom [9417,9419]
===
match
---
name: queued_dttm [14052,14063]
name: queued_dttm [14052,14063]
===
match
---
dotted_name [18050,18060]
dotted_name [18316,18326]
===
match
---
trailer [15442,15483]
trailer [15442,15483]
===
match
---
operator: } [18791,18792]
operator: } [19179,19180]
===
match
---
trailer [6084,6097]
trailer [6084,6097]
===
match
---
dotted_name [1277,1290]
dotted_name [1277,1290]
===
match
---
string: "fail" [4237,4243]
string: "fail" [4237,4243]
===
match
---
atom_expr [4801,4859]
atom_expr [4801,4859]
===
match
---
trailer [15306,15318]
trailer [15306,15318]
===
match
---
name: executor [6494,6502]
name: executor [6494,6502]
===
match
---
trailer [18669,18673]
trailer [19057,19061]
===
match
---
operator: = [15471,15472]
operator: = [15471,15472]
===
match
---
trailer [19399,19445]
trailer [19987,20033]
===
match
---
name: celery_executor [4345,4360]
name: celery_executor [4345,4360]
===
match
---
funcdef [17242,18044]
funcdef [17242,18310]
===
match
---
name: app [4478,4481]
name: app [4478,4481]
===
match
---
atom [10677,10712]
atom [10677,10712]
===
match
---
name: __dict__ [16690,16698]
name: __dict__ [16690,16698]
===
match
---
name: AirflowTaskTimeout [8364,8382]
name: AirflowTaskTimeout [8364,8382]
===
match
---
name: return_value [17039,17051]
name: return_value [17039,17051]
===
match
---
operator: = [13964,13965]
operator: = [13964,13965]
===
match
---
operator: { [18753,18754]
operator: { [19141,19142]
===
match
---
name: executor [16081,16089]
name: executor [16081,16089]
===
match
---
testlist_comp [8826,8972]
testlist_comp [8826,8972]
===
match
---
name: minutes [13683,13690]
name: minutes [13683,13690]
===
match
---
string: 'fail' [10678,10684]
string: 'fail' [10678,10684]
===
match
---
trailer [7285,7289]
trailer [7285,7289]
===
match
---
atom_expr [2389,2421]
atom_expr [2389,2421]
===
match
---
atom_expr [7229,7243]
atom_expr [7229,7243]
===
match
---
atom_expr [13237,13283]
atom_expr [13237,13283]
===
match
---
operator: = [14177,14178]
operator: = [14177,14178]
===
match
---
operator: - [13069,13070]
operator: - [13069,13070]
===
match
---
name: test_try_adopt_task_instances_none [12955,12989]
name: test_try_adopt_task_instances_none [12955,12989]
===
match
---
decorated [2282,3541]
decorated [2282,3541]
===
match
---
trailer [16895,16902]
trailer [16895,16902]
===
match
---
name: result [1284,1290]
name: result [1284,1290]
===
match
---
name: DAG [15357,15360]
name: DAG [15357,15360]
===
match
---
assert_stmt [19027,19096]
assert_stmt [19471,19540]
===
match
---
simple_stmt [16634,16703]
simple_stmt [16634,16703]
===
match
---
dotted_name [1618,1645]
dotted_name [1618,1645]
===
match
---
name: backend [15053,15060]
name: backend [15053,15060]
===
match
---
simple_stmt [3739,3758]
simple_stmt [3739,3758]
===
match
---
name: celery_executor [2447,2462]
name: celery_executor [2447,2462]
===
match
---
trailer [10519,10540]
trailer [10519,10540]
===
match
---
name: tis [13292,13295]
name: tis [13292,13295]
===
match
---
name: TaskInstanceKey [14513,14528]
name: TaskInstanceKey [14513,14528]
===
match
---
name: executor [10576,10584]
name: executor [10576,10584]
===
match
---
operator: , [14704,14705]
operator: , [14704,14705]
===
match
---
dotted_name [19182,19201]
dotted_name [19770,19789]
===
match
---
trailer [18920,18930]
trailer [19340,19350]
===
match
---
trailer [18656,18669]
trailer [19044,19057]
===
match
---
name: FAILED [16121,16127]
name: FAILED [16121,16127]
===
match
---
simple_stmt [15204,15255]
simple_stmt [15204,15255]
===
match
---
simple_stmt [13230,13284]
simple_stmt [13230,13284]
===
match
---
funcdef [1946,2144]
funcdef [1946,2144]
===
match
---
name: task_1 [14541,14547]
name: task_1 [14541,14547]
===
match
---
string: "redis" [6650,6657]
string: "redis" [6650,6657]
===
match
---
operator: , [7481,7482]
operator: , [7481,7482]
===
match
---
name: db [3652,3654]
name: db [3652,3654]
===
match
---
operator: = [18866,18867]
operator: = [19270,19271]
===
match
---
name: test_app [2775,2783]
name: test_app [2775,2783]
===
match
---
name: execute_date [5800,5812]
name: execute_date [5800,5812]
===
match
---
atom_expr [10511,10540]
atom_expr [10511,10540]
===
match
---
atom_expr [14624,14638]
atom_expr [14624,14638]
===
match
---
trailer [15776,15778]
trailer [15776,15778]
===
match
---
name: self [16721,16725]
name: self [16721,16725]
===
match
---
funcdef [2309,3541]
funcdef [2309,3541]
===
match
---
operator: = [13898,13899]
operator: = [13898,13899]
===
match
---
name: key_1 [15568,15573]
name: key_1 [15568,15573]
===
match
---
operator: , [15885,15886]
operator: , [15885,15886]
===
match
---
operator: == [9414,9416]
operator: == [9414,9416]
===
match
---
argument [8694,8705]
argument [8694,8705]
===
match
---
trailer [10484,10486]
trailer [10484,10486]
===
match
---
name: queued_dttm [14197,14208]
name: queued_dttm [14197,14208]
===
match
---
atom_expr [14409,14423]
atom_expr [14409,14423]
===
match
---
atom_expr [4345,4377]
atom_expr [4345,4377]
===
match
---
name: tis [13407,13410]
name: tis [13407,13410]
===
match
---
simple_stmt [14350,14394]
simple_stmt [14350,14394]
===
match
---
trailer [15285,15292]
trailer [15285,15292]
===
match
---
operator: { [16198,16199]
operator: { [16198,16199]
===
match
---
atom [18689,18812]
atom [19077,19200]
===
match
---
with_item [8158,8200]
with_item [8158,8200]
===
match
---
operator: @ [6625,6626]
operator: @ [6625,6626]
===
match
---
atom [9439,9610]
atom [9439,9610]
===
match
---
arglist [6578,6584]
arglist [6578,6584]
===
match
---
trailer [15795,15817]
trailer [15795,15817]
===
match
---
name: MagicMock [17622,17631]
name: MagicMock [17744,17753]
===
match
---
suite [13781,13932]
suite [13781,13932]
===
match
---
assert_stmt [12813,12899]
assert_stmt [12813,12899]
===
match
---
operator: , [16127,16128]
operator: , [16127,16128]
===
match
---
operator: } [14711,14712]
operator: } [14711,14712]
===
match
---
atom [2033,2039]
atom [2033,2039]
===
match
---
trailer [9642,9644]
trailer [9642,9644]
===
match
---
atom [7318,7496]
atom [7318,7496]
===
match
---
operator: , [4098,4099]
operator: , [4098,4099]
===
match
---
name: task [7122,7126]
name: task [7122,7126]
===
match
---
name: dag_id [14616,14622]
name: dag_id [14616,14622]
===
match
---
name: fake_execute_command [4124,4144]
name: fake_execute_command [4124,4144]
===
match
---
name: executor [6076,6084]
name: executor [6076,6084]
===
match
---
atom_expr [10655,10716]
atom_expr [10655,10716]
===
match
---
simple_stmt [16209,16253]
simple_stmt [16209,16253]
===
match
---
name: test_utils [1923,1933]
name: test_utils [1923,1933]
===
match
---
trailer [8693,8706]
trailer [8693,8706]
===
match
---
string: "mysql" [7968,7975]
string: "mysql" [7968,7975]
===
match
---
atom [10545,10547]
atom [10545,10547]
===
match
---
atom [19824,19841]
atom [20534,20551]
===
match
---
name: executor [14868,14876]
name: executor [14868,14876]
===
match
---
name: test_should_support_kv_backend [17246,17276]
name: test_should_support_kv_backend [17246,17276]
===
match
---
name: executor [6179,6187]
name: executor [6179,6187]
===
match
---
name: try_adopt_task_instances [14466,14490]
name: try_adopt_task_instances [14466,14490]
===
match
---
expr_stmt [15421,15483]
expr_stmt [15421,15483]
===
match
---
string: "Task should remain in queue" [9343,9372]
string: "Task should remain in queue" [9343,9372]
===
match
---
operator: , [19834,19835]
operator: , [20544,20545]
===
match
---
expr_stmt [4073,4110]
expr_stmt [4073,4110]
===
match
---
name: queued_tasks [6534,6546]
name: queued_tasks [6534,6546]
===
match
---
name: FAILED [6410,6416]
name: FAILED [6410,6416]
===
match
---
import_from [1272,1309]
import_from [1272,1309]
===
match
---
name: executor [7667,7675]
name: executor [7667,7675]
===
match
---
name: task_1 [13255,13261]
name: task_1 [13255,13261]
===
match
---
atom_expr [17351,17400]
atom_expr [17351,17400]
===
match
---
comparison [6568,6619]
comparison [6568,6619]
===
match
---
trailer [6577,6585]
trailer [6577,6585]
===
match
---
operator: = [7316,7317]
operator: = [7316,7317]
===
match
---
name: SimpleTaskInstance [1741,1759]
name: SimpleTaskInstance [1741,1759]
===
match
---
operator: @ [3763,3764]
operator: @ [3763,3764]
===
match
---
name: queued_dttm [14066,14077]
name: queued_dttm [14066,14077]
===
match
---
trailer [14741,14763]
trailer [14741,14763]
===
match
---
operator: , [18945,18946]
operator: , [19365,19366]
===
match
---
atom_expr [13613,13630]
atom_expr [13613,13630]
===
match
---
param [3972,3982]
param [3972,3982]
===
match
---
suite [18501,18813]
suite [18889,19462]
===
match
---
name: timedelta [15237,15246]
name: timedelta [15237,15246]
===
match
---
trailer [7711,7734]
trailer [7711,7734]
===
match
---
name: key [16590,16593]
name: key [16590,16593]
===
match
---
name: BulkStateFetcher [1596,1612]
name: BulkStateFetcher [1596,1612]
===
match
---
operator: , [5845,5846]
operator: , [5845,5846]
===
match
---
atom_expr [13803,13856]
atom_expr [13803,13856]
===
match
---
string: "123" [19616,19621]
string: "123" [20326,20331]
===
match
---
arglist [2734,2783]
arglist [2734,2783]
===
match
---
name: backend [7960,7967]
name: backend [7960,7967]
===
match
---
name: DAG [8690,8693]
name: DAG [8690,8693]
===
match
---
name: filter [18650,18656]
name: filter [19038,19044]
===
match
---
string: "456" [19699,19704]
string: "456" [20409,20414]
===
match
---
operator: = [4608,4609]
operator: = [4608,4609]
===
match
---
name: mock [8202,8206]
name: mock [8202,8206]
===
match
---
name: timezone [15277,15285]
name: timezone [15277,15285]
===
match
---
funcdef [3938,6620]
funcdef [3938,6620]
===
match
---
string: "123" [17097,17102]
string: "123" [17097,17102]
===
match
---
atom_expr [3652,3670]
atom_expr [3652,3670]
===
match
---
operator: , [16593,16594]
operator: , [16593,16594]
===
match
---
name: test_retry_on_error_sending_task [7997,8029]
name: test_retry_on_error_sending_task [7997,8029]
===
match
---
name: execution_date [14118,14132]
name: execution_date [14118,14132]
===
match
---
atom_expr [2684,2706]
atom_expr [2684,2706]
===
match
---
comparison [6525,6552]
comparison [6525,6552]
===
match
---
operator: , [15685,15686]
operator: , [15685,15686]
===
match
---
atom_expr [17509,17527]
atom_expr [17631,17649]
===
match
---
param [16505,16510]
param [16505,16510]
===
match
---
trailer [4568,4570]
trailer [4568,4570]
===
match
---
name: bash [1814,1818]
name: bash [1814,1818]
===
match
---
operator: = [13277,13278]
operator: = [13277,13278]
===
match
---
name: integration [7881,7892]
name: integration [7881,7892]
===
match
---
operator: , [14833,14834]
operator: , [14833,14834]
===
match
---
decorator [15040,15082]
decorator [15040,15082]
===
match
---
string: 'SUCCESS' [19799,19808]
string: 'SUCCESS' [20509,20518]
===
match
---
name: queued_dttm [14789,14800]
name: queued_dttm [14789,14800]
===
match
---
name: patch [2728,2733]
name: patch [2728,2733]
===
match
---
operator: = [14455,14456]
operator: = [14455,14456]
===
match
---
name: now [7238,7241]
name: now [7238,7241]
===
match
---
testlist_comp [14239,14247]
testlist_comp [14239,14247]
===
match
---
operator: = [7590,7591]
operator: = [7590,7591]
===
match
---
import_from [1356,1395]
import_from [1356,1395]
===
match
---
argument [8940,8969]
argument [8940,8969]
===
match
---
string: "postgres" [6734,6744]
string: "postgres" [6734,6744]
===
match
---
expr_stmt [18618,18812]
expr_stmt [19006,19200]
===
match
---
number: 0 [6578,6579]
number: 0 [6578,6579]
===
match
---
name: db [3625,3627]
name: db [3625,3627]
===
match
---
trailer [9739,9762]
trailer [9739,9762]
===
match
---
suite [3442,3541]
suite [3442,3541]
===
match
---
trailer [6533,6546]
trailer [6533,6546]
===
match
---
simple_stmt [1217,1272]
simple_stmt [1217,1272]
===
match
---
atom_expr [15237,15254]
atom_expr [15237,15254]
===
match
---
name: BaseOperator [15430,15442]
name: BaseOperator [15430,15442]
===
match
---
string: "Task should remain in queue" [10185,10214]
string: "Task should remain in queue" [10185,10214]
===
match
---
simple_stmt [18618,18813]
simple_stmt [19006,19201]
===
match
---
operator: , [4916,4917]
operator: , [4916,4917]
===
match
---
name: TaskInstance [13947,13959]
name: TaskInstance [13947,13959]
===
match
---
name: self [3966,3970]
name: self [3966,3970]
===
match
---
name: mock_backend [18533,18545]
name: mock_backend [18921,18933]
===
match
---
testlist_comp [19799,19814]
testlist_comp [20509,20524]
===
match
---
name: tasks [11119,11124]
name: tasks [11119,11124]
===
match
---
name: fake_execute_command [6797,6817]
name: fake_execute_command [6797,6817]
===
match
---
name: mock_fork [12415,12424]
name: mock_fork [12415,12424]
===
match
---
operator: , [12345,12346]
operator: , [12345,12346]
===
match
---
operator: , [5812,5813]
operator: , [5812,5813]
===
match
---
assert_stmt [19773,19842]
assert_stmt [20483,20552]
===
match
---
expr_stmt [7304,7496]
expr_stmt [7304,7496]
===
match
---
expr_stmt [5592,5630]
expr_stmt [5592,5630]
===
match
---
simple_stmt [7304,7497]
simple_stmt [7304,7497]
===
match
---
atom_expr [5124,5182]
atom_expr [5124,5182]
===
match
---
trailer [6191,6209]
trailer [6191,6209]
===
match
---
atom [11700,11884]
atom [11700,11884]
===
match
---
trailer [4236,4244]
trailer [4236,4244]
===
match
---
operator: != [4178,4180]
operator: != [4178,4180]
===
match
---
name: execution_date [7450,7464]
name: execution_date [7450,7464]
===
match
---
atom_expr [11622,11654]
atom_expr [11622,11654]
===
match
---
decorated [11939,12900]
decorated [11939,12900]
===
match
---
argument [14105,14116]
argument [14105,14116]
===
match
---
name: executor [8525,8533]
name: executor [8525,8533]
===
match
---
dotted_name [13425,13444]
dotted_name [13425,13444]
===
match
---
if_stmt [4167,4245]
if_stmt [4167,4245]
===
match
---
atom_expr [12482,12515]
atom_expr [12482,12515]
===
match
---
trailer [5139,5160]
trailer [5139,5160]
===
match
---
dotted_name [6664,6687]
dotted_name [6664,6687]
===
match
---
operator: = [13945,13946]
operator: = [13945,13946]
===
match
---
arglist [17436,17480]
arglist [17436,17480]
===
match
---
string: 'fail' [6099,6105]
string: 'fail' [6099,6105]
===
match
---
trailer [11926,11933]
trailer [11926,11933]
===
match
---
atom_expr [12820,12842]
atom_expr [12820,12842]
===
match
---
name: test_exception_propagation [10817,10843]
name: test_exception_propagation [10817,10843]
===
match
---
argument [17687,17700]
argument [17809,17822]
===
match
---
import_from [1217,1271]
import_from [1217,1271]
===
match
---
name: external_executor_id [14011,14031]
name: external_executor_id [14011,14031]
===
match
---
operator: = [15215,15216]
operator: = [15215,15216]
===
match
---
string: "task_id" [18775,18784]
string: "task_id" [19163,19172]
===
match
---
operator: , [7975,7976]
operator: , [7975,7976]
===
match
---
string: 'id' [8701,8705]
string: 'id' [8701,8705]
===
match
---
atom_expr [8174,8193]
atom_expr [8174,8193]
===
match
---
expr_stmt [15204,15254]
expr_stmt [15204,15254]
===
match
---
testlist_comp [9006,9039]
testlist_comp [9006,9039]
===
match
---
operator: = [17551,17552]
operator: = [17673,17674]
===
match
---
name: json [812,816]
name: json [812,816]
===
match
---
name: task_id [2240,2247]
name: task_id [2240,2247]
===
match
---
operator: , [9030,9031]
operator: , [9030,9031]
===
match
---
name: task_publish_max_retries [8534,8558]
name: task_publish_max_retries [8534,8558]
===
match
---
operator: , [5877,5878]
operator: , [5877,5878]
===
match
---
trailer [15693,15701]
trailer [15693,15701]
===
match
---
name: task [8929,8933]
name: task [8929,8933]
===
match
---
name: broker_url [2626,2636]
name: broker_url [2626,2636]
===
match
---
name: task_tuples_to_send [4588,4607]
name: task_tuples_to_send [4588,4607]
===
match
---
simple_stmt [6473,6509]
simple_stmt [6473,6509]
===
match
---
simple_stmt [8794,8987]
simple_stmt [8794,8987]
===
match
---
assert_stmt [9806,9840]
assert_stmt [9806,9840]
===
match
---
operator: , [5182,5183]
operator: , [5182,5183]
===
match
---
operator: , [17800,17801]
operator: , [17922,17923]
===
match
---
operator: , [4030,4031]
operator: , [4030,4031]
===
match
---
name: not_adopted_tis [14439,14454]
name: not_adopted_tis [14439,14454]
===
match
---
operator: , [6010,6011]
operator: , [6010,6011]
===
match
---
name: object [8213,8219]
name: object [8213,8219]
===
match
---
number: 1 [13716,13717]
number: 1 [13716,13717]
===
match
---
operator: == [14940,14942]
operator: == [14940,14942]
===
match
---
string: 'fake_simple_ti' [6362,6378]
string: 'fake_simple_ti' [6362,6378]
===
match
---
operator: = [19516,19517]
operator: = [20226,20227]
===
match
---
name: app [17396,17399]
name: app [17396,17399]
===
match
---
param [16511,16519]
param [16511,16519]
===
match
---
operator: , [7386,7387]
operator: , [7386,7387]
===
match
---
name: key [5534,5537]
name: key [5534,5537]
===
match
---
try_stmt [3394,3541]
try_stmt [3394,3541]
===
match
---
operator: , [4505,4506]
operator: , [4505,4506]
===
match
---
expr_stmt [8407,8450]
expr_stmt [8407,8450]
===
match
---
atom_expr [11770,11814]
atom_expr [11770,11814]
===
match
---
name: assert_not_called [12607,12624]
name: assert_not_called [12607,12624]
===
match
---
name: days [15247,15251]
name: days [15247,15251]
===
match
---
string: "redis" [3838,3845]
string: "redis" [3838,3845]
===
match
---
name: unittest [3568,3576]
name: unittest [3568,3576]
===
match
---
atom_expr [17617,17646]
atom_expr [17739,17768]
===
match
---
name: app [17376,17379]
name: app [17376,17379]
===
match
---
string: "rabbitmq" [7931,7941]
string: "rabbitmq" [7931,7941]
===
match
---
trailer [8775,8779]
trailer [8775,8779]
===
match
---
simple_stmt [3411,3426]
simple_stmt [3411,3426]
===
match
---
simple_stmt [14918,14998]
simple_stmt [14918,14998]
===
match
---
with_item [10881,10923]
with_item [10881,10923]
===
match
---
param [12990,12994]
param [12990,12994]
===
match
---
name: autospec [19342,19350]
name: autospec [19930,19938]
===
match
---
argument [4284,4312]
argument [4284,4312]
===
match
---
string: 'executor.running_tasks' [11838,11862]
string: 'executor.running_tasks' [11838,11862]
===
match
---
assert_stmt [6219,6315]
assert_stmt [6219,6315]
===
match
---
decorated [10738,11292]
decorated [10738,11292]
===
match
---
simple_stmt [13313,13357]
simple_stmt [13313,13357]
===
match
---
operator: , [17455,17456]
operator: , [17455,17456]
===
match
---
arglist [16584,16600]
arglist [16584,16600]
===
match
---
decorator [19102,19136]
decorator [19690,19724]
===
match
---
simple_stmt [13869,13932]
simple_stmt [13869,13932]
===
match
---
trailer [10676,10713]
trailer [10676,10713]
===
match
---
simple_stmt [13580,13631]
simple_stmt [13580,13631]
===
match
---
number: 2 [13569,13570]
number: 2 [13569,13570]
===
match
---
name: datetime [7465,7473]
name: datetime [7465,7473]
===
match
---
name: celery_executor [11155,11170]
name: celery_executor [11155,11170]
===
match
---
name: utcnow [15286,15292]
name: utcnow [15286,15292]
===
match
---
name: task_id [8649,8656]
name: task_id [8649,8656]
===
match
---
string: "task_1" [15451,15459]
string: "task_1" [15451,15459]
===
match
---
operator: @ [10767,10768]
operator: @ [10767,10768]
===
match
---
operator: , [6360,6361]
operator: , [6360,6361]
===
match
---
name: AsyncResult [16022,16033]
name: AsyncResult [16022,16033]
===
match
---
parameters [3965,3983]
parameters [3965,3983]
===
match
---
decorators [3763,3934]
decorators [3763,3934]
===
match
---
name: session [3292,3299]
name: session [3292,3299]
===
match
---
trailer [17525,17527]
trailer [17647,17649]
===
match
---
simple_stmt [8760,8782]
simple_stmt [8760,8782]
===
match
---
name: other [16896,16901]
name: other [16896,16901]
===
match
---
string: "Task should remain in queue" [9764,9793]
string: "Task should remain in queue" [9764,9793]
===
match
---
testlist_comp [10678,10711]
testlist_comp [10678,10711]
===
match
---
trailer [12652,12670]
trailer [12652,12670]
===
match
---
simple_stmt [1550,1613]
simple_stmt [1550,1613]
===
match
---
name: celery_executor [2515,2530]
name: celery_executor [2515,2530]
===
match
---
name: expected_exception [12123,12141]
name: expected_exception [12123,12141]
===
match
---
name: self [8158,8162]
name: self [8158,8162]
===
match
---
string: 'airflow' [11997,12006]
string: 'airflow' [11997,12006]
===
match
---
operator: , [8156,8157]
operator: , [8156,8157]
===
match
---
expr_stmt [9053,9093]
expr_stmt [9053,9093]
===
match
---
name: celery_executor [17436,17451]
name: celery_executor [17436,17451]
===
match
---
dictorsetmaker [19045,19095]
dictorsetmaker [19489,19539]
===
match
---
string: 'fake_simple_ti' [7524,7540]
string: 'fake_simple_ti' [7524,7540]
===
match
---
suite [6820,6838]
suite [6820,6838]
===
match
---
trailer [14989,14996]
trailer [14989,14996]
===
match
---
simple_stmt [838,854]
simple_stmt [838,854]
===
match
---
number: 0 [10710,10711]
number: 0 [10710,10711]
===
match
---
name: object [19393,19399]
name: object [19981,19987]
===
match
---
atom_expr [12643,12672]
atom_expr [12643,12672]
===
match
---
operator: = [7210,7211]
operator: = [7210,7211]
===
match
---
name: value_tuple [7304,7315]
name: value_tuple [7304,7315]
===
match
---
name: command [12114,12121]
name: command [12114,12121]
===
match
---
atom_expr [8767,8781]
atom_expr [8767,8781]
===
match
---
atom_expr [8894,8971]
atom_expr [8894,8971]
===
match
---
arglist [19691,19721]
arglist [20401,20431]
===
match
---
operator: , [5098,5099]
operator: , [5098,5099]
===
match
---
simple_stmt [1059,1085]
simple_stmt [1059,1085]
===
match
---
trailer [2228,2230]
trailer [2228,2230]
===
match
---
trailer [9677,9698]
trailer [9677,9698]
===
match
---
name: property [2175,2183]
name: property [2175,2183]
===
match
---
expr_stmt [18822,18850]
expr_stmt [19218,19246]
===
match
---
string: "postgres" [15070,15080]
string: "postgres" [15070,15080]
===
match
---
name: mark [7955,7959]
name: mark [7955,7959]
===
match
---
name: queued_tasks [10170,10182]
name: queued_tasks [10170,10182]
===
match
---
expr_stmt [2362,2421]
expr_stmt [2362,2421]
===
match
---
name: tasks [16189,16194]
name: tasks [16189,16194]
===
match
---
name: tis [14491,14494]
name: tis [14491,14494]
===
match
---
name: executor [10234,10242]
name: executor [10234,10242]
===
match
---
name: task_publish_retries [10520,10540]
name: task_publish_retries [10520,10540]
===
match
---
suite [11602,11934]
suite [11602,11934]
===
match
---
atom [19798,19815]
atom [20508,20525]
===
match
---
name: base [1106,1110]
name: base [1106,1110]
===
match
---
name: executor [13313,13321]
name: executor [13313,13321]
===
match
---
name: __eq__ [16767,16773]
name: __eq__ [16767,16773]
===
match
---
trailer [4477,4523]
trailer [4477,4523]
===
match
---
trailer [3323,3325]
trailer [3323,3325]
===
match
---
file_input [787,19843]
file_input [787,20697]
===
match
---
atom [18728,18793]
atom [19116,19181]
===
match
---
name: days [13623,13627]
name: days [13623,13627]
===
match
---
name: __repr__ [16712,16720]
name: __repr__ [16712,16720]
===
match
---
name: task [8934,8938]
name: task [8934,8938]
===
match
---
trailer [2930,2956]
trailer [2930,2956]
===
match
---
atom_expr [10090,10119]
atom_expr [10090,10119]
===
match
---
trailer [7141,7257]
trailer [7141,7257]
===
match
---
trailer [11868,11872]
trailer [11868,11872]
===
match
---
parameters [2325,2356]
parameters [2325,2356]
===
match
---
string: ',' [2090,2093]
string: ',' [2090,2093]
===
match
---
atom_expr [16576,16601]
atom_expr [16576,16601]
===
match
---
name: MagicMock [19332,19341]
name: MagicMock [19920,19929]
===
match
---
operator: = [4343,4344]
operator: = [4343,4344]
===
match
---
operator: , [5239,5240]
operator: , [5239,5240]
===
match
---
operator: , [10879,10880]
operator: , [10879,10880]
===
match
---
name: start_date [13038,13048]
name: start_date [13038,13048]
===
match
---
string: "Task should no longer be queued" [7736,7769]
string: "Task should no longer be queued" [7736,7769]
===
match
---
name: self [16685,16689]
name: self [16685,16689]
===
match
---
string: 'fail' [6354,6360]
string: 'fail' [6354,6360]
===
match
---
trailer [12495,12515]
trailer [12495,12515]
===
match
---
assert_stmt [17974,18043]
assert_stmt [18096,18165]
===
match
---
atom [18898,19007]
atom [19310,19443]
===
match
---
name: utcnow [15226,15232]
name: utcnow [15226,15232]
===
match
---
operator: { [17991,17992]
operator: { [18113,18114]
===
match
---
name: celery_executor [19400,19415]
name: celery_executor [19988,20003]
===
match
---
trailer [11751,11755]
trailer [11751,11755]
===
match
---
atom_expr [13653,13670]
atom_expr [13653,13670]
===
match
---
argument [17632,17645]
argument [17754,17767]
===
match
---
comparison [14678,14712]
comparison [14678,14712]
===
match
---
name: test_gauge_executor_metrics [11519,11546]
name: test_gauge_executor_metrics [11519,11546]
===
match
---
name: broker_url [2591,2601]
name: broker_url [2591,2601]
===
match
---
operator: == [9700,9702]
operator: == [9700,9702]
===
match
---
string: 'some_parameter' [4047,4063]
string: 'some_parameter' [4047,4063]
===
match
---
string: "task_id" [17086,17095]
string: "task_id" [17086,17095]
===
match
---
name: other [16780,16785]
name: other [16780,16785]
===
match
---
operator: = [7275,7276]
operator: = [7275,7276]
===
match
---
name: simple_ti [5410,5419]
name: simple_ti [5410,5419]
===
match
---
return_stmt [16634,16702]
return_stmt [16634,16702]
===
match
---
arglist [17217,17236]
arglist [17217,17236]
===
match
---
name: tis [14232,14235]
name: tis [14232,14235]
===
match
---
expr_stmt [15651,15725]
expr_stmt [15651,15725]
===
match
---
fstring_string: ( [16679,16680]
fstring_string: ( [16679,16680]
===
match
---
atom_expr [18916,18945]
atom_expr [19336,19365]
===
match
---
name: airflow [1509,1516]
name: airflow [1509,1516]
===
match
---
atom [5748,5900]
atom [5748,5900]
===
match
---
name: start_date [13920,13930]
name: start_date [13920,13930]
===
match
---
name: dag [7196,7199]
name: dag [7196,7199]
===
match
---
string: "mysql" [3913,3920]
string: "mysql" [3913,3920]
===
match
---
name: cm [10429,10431]
name: cm [10429,10431]
===
match
---
trailer [18967,18977]
trailer [19395,19405]
===
match
---
import_from [1436,1503]
import_from [1436,1503]
===
match
---
decorated [15040,16253]
decorated [15040,16253]
===
match
---
simple_stmt [4541,4571]
simple_stmt [4541,4571]
===
match
---
atom_expr [18618,18686]
atom_expr [19006,19074]
===
match
---
atom_expr [11805,11813]
atom_expr [11805,11813]
===
match
---
name: executor [14409,14417]
name: executor [14409,14417]
===
match
---
expr_stmt [17544,17742]
expr_stmt [17666,17864]
===
match
---
atom_expr [12594,12626]
atom_expr [12594,12626]
===
match
---
name: mock [18437,18441]
name: mock [18703,18707]
===
match
---
trailer [15610,15618]
trailer [15610,15618]
===
match
---
atom_expr [6525,6546]
atom_expr [6525,6546]
===
match
---
arglist [19400,19444]
arglist [19988,20032]
===
match
---
suite [19446,19764]
suite [20156,20474]
===
match
---
trailer [11154,11229]
trailer [11154,11229]
===
match
---
trailer [16669,16678]
trailer [16669,16678]
===
match
---
operator: - [13671,13672]
operator: - [13671,13672]
===
match
---
operator: , [4037,4038]
operator: , [4037,4038]
===
match
---
suite [6784,7863]
suite [6784,7863]
===
match
---
testlist_comp [4658,4917]
testlist_comp [4658,4917]
===
match
---
name: task [13250,13254]
name: task [13250,13254]
===
match
---
param [3966,3971]
param [3966,3971]
===
match
---
dictorsetmaker [10125,10131]
dictorsetmaker [10125,10131]
===
match
---
name: test_app [2684,2692]
name: test_app [2684,2692]
===
match
---
simple_stmt [11144,11230]
simple_stmt [11144,11230]
===
match
---
name: execute_command [2463,2478]
name: execute_command [2463,2478]
===
match
---
simple_stmt [13005,13030]
simple_stmt [13005,13030]
===
match
---
name: task_2 [15687,15693]
name: task_2 [15687,15693]
===
match
---
with_stmt [3355,3541]
with_stmt [3355,3541]
===
match
---
atom_expr [16681,16699]
atom_expr [16681,16699]
===
match
---
operator: , [1773,1774]
operator: , [1773,1774]
===
match
---
operator: = [7513,7514]
operator: = [7513,7514]
===
match
---
import_from [854,894]
import_from [854,894]
===
match
---
name: _process_tasks [5657,5671]
name: _process_tasks [5657,5671]
===
match
---
atom_expr [6450,6464]
atom_expr [6450,6464]
===
match
---
name: State [16144,16149]
name: State [16144,16149]
===
match
---
name: mock [11828,11832]
name: mock [11828,11832]
===
match
---
name: key_1 [14944,14949]
name: key_1 [14944,14949]
===
match
---
operator: } [17911,17912]
operator: } [18033,18034]
===
match
---
testlist_comp [5542,5570]
testlist_comp [5542,5570]
===
match
---
operator: = [7127,7128]
operator: = [7127,7128]
===
match
---
assert_stmt [9724,9793]
assert_stmt [9724,9793]
===
match
---
name: AirflowTaskTimeout [1485,1503]
name: AirflowTaskTimeout [1485,1503]
===
match
---
atom_expr [10008,10017]
atom_expr [10008,10017]
===
match
---
atom_expr [7785,7846]
atom_expr [7785,7846]
===
match
---
simple_stmt [7509,7551]
simple_stmt [7509,7551]
===
match
---
simple_stmt [11663,11684]
simple_stmt [11663,11684]
===
match
---
string: 'success' [6433,6442]
string: 'success' [6433,6442]
===
match
---
operator: , [18485,18486]
operator: , [18751,18752]
===
match
---
fstring_string: ) [16700,16701]
fstring_string: ) [16700,16701]
===
match
---
fstring_expr [16643,16679]
fstring_expr [16643,16679]
===
match
---
atom_expr [14951,14969]
atom_expr [14951,14969]
===
match
---
name: executor [8407,8415]
name: executor [8407,8415]
===
match
---
name: now [8728,8731]
name: now [8728,8731]
===
match
---
number: 1 [7363,7364]
number: 1 [7363,7364]
===
match
---
name: AirflowException [4220,4236]
name: AirflowException [4220,4236]
===
match
---
arith_expr [14854,14898]
arith_expr [14854,14898]
===
match
---
operator: = [14064,14065]
operator: = [14064,14065]
===
match
---
trailer [2053,2061]
trailer [2053,2061]
===
match
---
name: mock [17418,17422]
name: mock [17418,17422]
===
match
---
name: set [17841,17844]
name: set [17963,17966]
===
match
---
operator: , [16509,16510]
operator: , [16509,16510]
===
match
---
name: minutes [15184,15191]
name: minutes [15184,15191]
===
match
---
atom [14238,14248]
atom [14238,14248]
===
match
---
operator: } [14908,14909]
operator: } [14908,14909]
===
match
---
operator: @ [3851,3852]
operator: @ [3851,3852]
===
match
---
string: "postgres" [18232,18242]
string: "postgres" [18498,18508]
===
match
---
trailer [4438,4444]
trailer [4438,4444]
===
match
---
name: db [3712,3714]
name: db [3712,3714]
===
match
---
trailer [14811,14833]
trailer [14811,14833]
===
match
---
name: synchronous [6192,6203]
name: synchronous [6192,6203]
===
match
---
operator: + [14801,14802]
operator: + [14801,14802]
===
match
---
with_stmt [19377,19764]
with_stmt [19965,20474]
===
match
---
import_name [1045,1058]
import_name [1045,1058]
===
match
---
name: json [17053,17057]
name: json [17053,17057]
===
match
---
simple_stmt [1164,1217]
simple_stmt [1164,1217]
===
match
---
operator: = [8933,8934]
operator: = [8933,8934]
===
match
---
trailer [8631,8747]
trailer [8631,8747]
===
match
---
string: "task_1" [13824,13832]
string: "task_1" [13824,13832]
===
match
---
atom_expr [5208,5239]
atom_expr [5208,5239]
===
match
---
operator: , [12006,12007]
operator: , [12006,12007]
===
match
---
arglist [8290,8383]
arglist [8290,8383]
===
match
---
simple_stmt [10993,11038]
simple_stmt [10993,11038]
===
match
---
trailer [14933,14939]
trailer [14933,14939]
===
match
---
operator: = [18379,18380]
operator: = [18645,18646]
===
match
---
argument [13834,13855]
argument [13834,13855]
===
match
---
name: exec_date [14640,14649]
name: exec_date [14640,14649]
===
match
---
string: '232' [14179,14184]
string: '232' [14179,14184]
===
match
---
operator: = [15251,15252]
operator: = [15251,15252]
===
match
---
string: 'SUCCESS' [18000,18009]
string: 'SUCCESS' [18122,18131]
===
match
---
trailer [8173,8194]
trailer [8173,8194]
===
match
---
name: execute [2436,2443]
name: execute [2436,2443]
===
match
---
operator: { [4415,4416]
operator: { [4415,4416]
===
match
---
simple_stmt [7696,7770]
simple_stmt [7696,7770]
===
match
---
funcdef [6750,7863]
funcdef [6750,7863]
===
match
---
name: key_2 [14706,14711]
name: key_2 [14706,14711]
===
match
---
suite [15408,15559]
suite [15408,15559]
===
match
---
decorator [18202,18244]
decorator [18468,18510]
===
match
---
expr_stmt [14439,14495]
expr_stmt [14439,14495]
===
match
---
atom_expr [6852,6894]
atom_expr [6852,6894]
===
match
---
name: bulk_state_fetcher [11059,11077]
name: bulk_state_fetcher [11059,11077]
===
match
---
name: _prepare_app [6852,6864]
name: _prepare_app [6852,6864]
===
match
---
number: 1 [10152,10153]
number: 1 [10152,10153]
===
match
---
atom_expr [13071,13088]
atom_expr [13071,13088]
===
match
---
trailer [7289,7291]
trailer [7289,7291]
===
match
---
operator: = [8416,8417]
operator: = [8416,8417]
===
match
---
trailer [9256,9277]
trailer [9256,9277]
===
match
---
operator: = [7425,7426]
operator: = [7425,7426]
===
match
---
dotted_name [11371,11381]
dotted_name [11371,11381]
===
match
---
operator: , [11980,11981]
operator: , [11980,11981]
===
match
---
decorator [19181,19223]
decorator [19769,19811]
===
match
---
name: ANY [17960,17963]
name: ANY [18082,18085]
===
match
---
trailer [8533,8558]
trailer [8533,8558]
===
match
---
name: executor [9203,9211]
name: executor [9203,9211]
===
match
---
atom_expr [11281,11290]
atom_expr [11281,11290]
===
match
---
name: exec_date [15142,15151]
name: exec_date [15142,15151]
===
match
---
assert_stmt [9657,9711]
assert_stmt [9657,9711]
===
match
---
import_from [1613,1665]
import_from [1613,1665]
===
match
---
atom [12846,12859]
atom [12846,12859]
===
match
---
trailer [13066,13068]
trailer [13066,13068]
===
match
---
name: self [2198,2202]
name: self [2198,2202]
===
match
---
decorator [10767,10809]
decorator [10767,10809]
===
match
---
arith_expr [15906,15950]
arith_expr [15906,15950]
===
match
---
atom_expr [18832,18850]
atom_expr [19228,19246]
===
match
---
name: pytest [18162,18168]
name: pytest [18428,18434]
===
match
---
operator: , [7522,7523]
operator: , [7522,7523]
===
match
---
name: mark [7876,7880]
name: mark [7876,7880]
===
match
---
with_item [15357,15407]
with_item [15357,15407]
===
match
---
name: when [10704,10708]
name: when [10704,10708]
===
match
---
operator: == [6586,6588]
operator: == [6586,6588]
===
match
---
operator: , [4700,4701]
operator: , [4700,4701]
===
match
---
string: 'airflow.executors.celery_executor.CeleryExecutor.trigger_tasks' [11382,11446]
string: 'airflow.executors.celery_executor.CeleryExecutor.trigger_tasks' [11382,11446]
===
match
---
string: 'BROKER_URL' [2408,2420]
string: 'BROKER_URL' [2408,2420]
===
match
---
trailer [6295,6298]
trailer [6295,6298]
===
match
---
suite [16864,16903]
suite [16864,16903]
===
match
---
simple_stmt [7667,7688]
simple_stmt [7667,7688]
===
match
---
trailer [18329,18331]
trailer [18595,18597]
===
match
---
name: testing [1237,1244]
name: testing [1237,1244]
===
match
---
argument [13816,13832]
argument [13816,13832]
===
match
---
argument [18376,18399]
argument [18642,18665]
===
match
---
name: datetime [8955,8963]
name: datetime [8955,8963]
===
match
---
atom [4088,4110]
atom [4088,4110]
===
match
---
operator: , [3369,3370]
operator: , [3369,3370]
===
match
---
testlist_comp [18000,18015]
testlist_comp [18122,18137]
===
match
---
simple_stmt [14309,14342]
simple_stmt [14309,14342]
===
match
---
simple_stmt [1613,1666]
simple_stmt [1613,1666]
===
match
---
operator: , [4734,4735]
operator: , [4734,4735]
===
match
---
name: timedelta [15297,15306]
name: timedelta [15297,15306]
===
match
---
name: CeleryExecutor [15762,15776]
name: CeleryExecutor [15762,15776]
===
match
---
testlist_comp [7516,7549]
testlist_comp [7516,7549]
===
match
---
trailer [2478,2490]
trailer [2478,2490]
===
match
---
trailer [10663,10676]
trailer [10663,10676]
===
match
---
assert_stmt [4390,4417]
assert_stmt [4390,4417]
===
match
---
atom_expr [12347,12411]
atom_expr [12347,12411]
===
match
---
atom_expr [13324,13356]
atom_expr [13324,13356]
===
match
---
operator: } [14996,14997]
operator: } [14996,14997]
===
match
---
operator: = [18830,18831]
operator: = [19226,19227]
===
match
---
name: mock [916,920]
name: mock [916,920]
===
match
---
atom_expr [14529,14539]
atom_expr [14529,14539]
===
match
---
name: event_buffer [9401,9413]
name: event_buffer [9401,9413]
===
match
---
atom [16114,16134]
atom [16114,16134]
===
match
---
operator: } [10000,10001]
operator: } [10000,10001]
===
match
---
atom [12886,12899]
atom [12886,12899]
===
match
---
simple_stmt [17336,17401]
simple_stmt [17336,17401]
===
match
---
name: key [16534,16537]
name: key [16534,16537]
===
match
---
trailer [4816,4837]
trailer [4816,4837]
===
match
---
name: mock_mget [17283,17292]
name: mock_mget [17283,17292]
===
match
---
name: _prepare_test_bodies [3785,3805]
name: _prepare_test_bodies [3785,3805]
===
match
---
operator: { [6550,6551]
operator: { [6550,6551]
===
match
---
simple_stmt [14152,14185]
simple_stmt [14152,14185]
===
match
---
operator: , [5863,5864]
operator: , [5863,5864]
===
match
---
comparison [6433,6464]
comparison [6433,6464]
===
match
---
trailer [7477,7479]
trailer [7477,7479]
===
match
---
atom [12034,12061]
atom [12034,12061]
===
match
---
operator: } [16040,16041]
operator: } [16040,16041]
===
match
---
atom [18025,18042]
atom [18147,18164]
===
match
---
name: str [16681,16684]
name: str [16681,16684]
===
match
---
name: session [3334,3341]
name: session [3334,3341]
===
match
---
name: return_value [18560,18572]
name: return_value [18948,18960]
===
match
---
import_as_names [1741,1790]
import_as_names [1741,1790]
===
match
---
name: task [2693,2697]
name: task [2693,2697]
===
match
---
operator: , [15459,15460]
operator: , [15459,15460]
===
match
---
string: '456' [19817,19822]
string: '456' [20527,20532]
===
match
---
operator: , [16855,16856]
operator: , [16855,16856]
===
match
---
name: FAILED [10726,10732]
name: FAILED [10726,10732]
===
match
---
name: test_check_for_stalled_adopted_tasks [15090,15126]
name: test_check_for_stalled_adopted_tasks [15090,15126]
===
match
---
string: "postgres" [3922,3932]
string: "postgres" [3922,3932]
===
match
---
argument [19691,19704]
argument [20401,20414]
===
match
---
simple_stmt [2362,2422]
simple_stmt [2362,2422]
===
match
---
operator: { [9282,9283]
operator: { [9282,9283]
===
match
---
name: celery_executor [4801,4816]
name: celery_executor [4801,4816]
===
match
---
operator: , [19430,19431]
operator: , [20018,20019]
===
match
---
name: hasattr [2923,2930]
name: hasattr [2923,2930]
===
match
---
operator: { [11010,11011]
operator: { [11010,11011]
===
match
---
simple_stmt [16796,16835]
simple_stmt [16796,16835]
===
match
---
testlist_comp [4659,4703]
testlist_comp [4659,4703]
===
match
---
operator: - [15172,15173]
operator: - [15172,15173]
===
match
---
name: backend [2888,2895]
name: backend [2888,2895]
===
match
---
import_from [1839,1873]
import_from [1839,1873]
===
match
---
name: running [14687,14694]
name: running [14687,14694]
===
match
---
trailer [7806,7843]
trailer [7806,7843]
===
match
---
trailer [13601,13608]
trailer [13601,13608]
===
match
---
name: mock [11770,11774]
name: mock [11770,11774]
===
match
---
operator: } [10131,10132]
operator: } [10131,10132]
===
match
---
arglist [2626,2663]
arglist [2626,2663]
===
match
---
comp_op [6487,6493]
comp_op [6487,6493]
===
match
---
name: test_app [2898,2906]
name: test_app [2898,2906]
===
match
---
string: 'key' [11011,11016]
string: 'key' [11011,11016]
===
match
---
atom [14698,14712]
atom [14698,14712]
===
match
---
name: self [3602,3606]
name: self [3602,3606]
===
match
---
name: values [11125,11131]
name: values [11125,11131]
===
match
---
name: cm [9587,9589]
name: cm [9587,9589]
===
match
---
name: backend [13437,13444]
name: backend [13437,13444]
===
match
---
number: 0 [9038,9039]
number: 0 [9038,9039]
===
match
---
trailer [11221,11228]
trailer [11221,11228]
===
match
---
simple_stmt [18518,18602]
simple_stmt [18906,18990]
===
match
---
atom_expr [7200,7216]
atom_expr [7200,7216]
===
match
---
operator: , [16588,16589]
operator: , [16588,16589]
===
match
---
name: pytest [12482,12488]
name: pytest [12482,12488]
===
match
---
trailer [2514,2552]
trailer [2514,2552]
===
match
---
operator: , [6123,6124]
operator: , [6123,6124]
===
match
---
string: "PENDING" [19825,19834]
string: "PENDING" [20535,20544]
===
match
---
comparison [10506,10547]
comparison [10506,10547]
===
match
---
suite [12425,12900]
suite [12425,12900]
===
match
---
name: test_app [2608,2616]
name: test_app [2608,2616]
===
match
---
import_name [838,853]
import_name [838,853]
===
match
---
decorator [11939,12076]
decorator [11939,12076]
===
match
---
string: "test" [8657,8663]
string: "test" [8657,8663]
===
match
---
string: "INFO:airflow.executors.celery_executor.CeleryExecutor:" [10299,10355]
string: "INFO:airflow.executors.celery_executor.CeleryExecutor:" [10299,10355]
===
match
---
operator: = [15191,15192]
operator: = [15191,15192]
===
match
---
operator: = [19325,19326]
operator: = [19913,19914]
===
match
---
trailer [9061,9074]
trailer [9061,9074]
===
match
---
operator: = [2617,2618]
operator: = [2617,2618]
===
match
---
operator: = [13529,13530]
operator: = [13529,13530]
===
match
---
operator: @ [7868,7869]
operator: @ [7868,7869]
===
match
---
atom_expr [10865,10879]
atom_expr [10865,10879]
===
match
---
testlist_comp [19079,19094]
testlist_comp [19523,19538]
===
match
---
name: output [10011,10017]
name: output [10011,10017]
===
match
---
operator: , [5978,5979]
operator: , [5978,5979]
===
match
---
param [16619,16623]
param [16619,16623]
===
match
---
name: self [10881,10885]
name: self [10881,10885]
===
match
---
operator: , [883,884]
operator: , [883,884]
===
match
---
name: mock [18711,18715]
name: mock [19099,19103]
===
match
---
name: TaskInstance [14092,14104]
name: TaskInstance [14092,14104]
===
match
---
operator: { [14768,14769]
operator: { [14768,14769]
===
match
---
trailer [18454,18500]
trailer [18720,18766]
===
match
---
argument [8665,8684]
argument [8665,8684]
===
match
---
name: executor [14678,14686]
name: executor [14678,14686]
===
match
---
decorator [18161,18198]
decorator [18427,18464]
===
match
---
name: mark [10775,10779]
name: mark [10775,10779]
===
match
---
testlist_comp [5770,5882]
testlist_comp [5770,5882]
===
match
---
operator: , [15629,15630]
operator: , [15629,15630]
===
match
---
simple_stmt [19509,19764]
simple_stmt [20219,20474]
===
match
---
operator: , [6392,6393]
operator: , [6392,6393]
===
match
---
comparison [7785,7862]
comparison [7785,7862]
===
match
---
simple_stmt [3520,3541]
simple_stmt [3520,3541]
===
match
---
number: 1 [9731,9732]
number: 1 [9731,9732]
===
match
---
if_stmt [12438,12900]
if_stmt [12438,12900]
===
match
---
name: minutes [13561,13568]
name: minutes [13561,13568]
===
match
---
parameters [18282,18302]
parameters [18548,18568]
===
match
---
trailer [15928,15950]
trailer [15928,15950]
===
match
---
name: task [14105,14109]
name: task [14105,14109]
===
match
---
argument [2638,2663]
argument [2638,2663]
===
match
---
trailer [6502,6508]
trailer [6502,6508]
===
match
---
decorator [6704,6746]
decorator [6704,6746]
===
match
---
name: pytest [10768,10774]
name: pytest [10768,10774]
===
match
---
name: broker_url [4272,4282]
name: broker_url [4272,4282]
===
match
---
trailer [15162,15169]
trailer [15162,15169]
===
match
---
name: pytest [17156,17162]
name: pytest [17156,17162]
===
match
---
name: pytest [17197,17203]
name: pytest [17197,17203]
===
match
---
operator: { [16106,16107]
operator: { [16106,16107]
===
match
---
atom_expr [6331,6400]
atom_expr [6331,6400]
===
match
---
name: mock_fork [12643,12652]
name: mock_fork [12643,12652]
===
match
---
operator: , [14116,14117]
operator: , [14116,14117]
===
match
---
trailer [18559,18572]
trailer [18947,18960]
===
match
---
dotted_name [17197,17216]
dotted_name [17197,17216]
===
match
---
name: expand [3778,3784]
name: expand [3778,3784]
===
match
---
atom_expr [5722,5743]
atom_expr [5722,5743]
===
match
---
name: set_event_loop [1341,1355]
name: set_event_loop [1341,1355]
===
match
---
name: MagicMock [18921,18930]
name: MagicMock [19341,19350]
===
match
---
string: 'true' [11973,11979]
string: 'true' [11973,11979]
===
match
---
trailer [14686,14694]
trailer [14686,14694]
===
match
---
simple_stmt [5710,5901]
simple_stmt [5710,5901]
===
match
---
argument [17376,17399]
argument [17376,17399]
===
match
---
simple_stmt [12594,12627]
simple_stmt [12594,12627]
===
match
---
name: key_1 [14699,14704]
name: key_1 [14699,14704]
===
match
---
trailer [17428,17435]
trailer [17428,17435]
===
match
---
operator: = [6203,6204]
operator: = [6203,6204]
===
match
---
number: 0 [17855,17856]
number: 0 [17977,17978]
===
match
---
operator: , [14969,14970]
operator: , [14969,14970]
===
match
---
atom [9005,9040]
atom [9005,9040]
===
insert-tree
---
simple_stmt [18174,18310]
    assert_stmt [18174,18309]
        comparison [18181,18309]
            atom [18181,18296]
                string: 'DEBUG:airflow.executors.celery_executor.BulkStateFetcher:Fetched 2 state(s) for 2 task(s)' [18195,18286]
            operator: == [18297,18299]
            atom_expr [18300,18309]
                name: cm [18300,18302]
                trailer [18302,18309]
                    name: output [18303,18309]
to
suite [17294,18044]
at 5
===
insert-tree
---
simple_stmt [19549,19685]
    assert_stmt [19549,19684]
        comparison [19556,19684]
            atom [19556,19671]
                string: 'DEBUG:airflow.executors.celery_executor.BulkStateFetcher:Fetched 2 state(s) for 2 task(s)' [19570,19661]
            operator: == [19672,19674]
            atom_expr [19675,19684]
                name: cm [19675,19677]
                trailer [19677,19684]
                    name: output [19678,19684]
to
suite [18303,19097]
at 4
===
insert-tree
---
simple_stmt [20561,20697]
    assert_stmt [20561,20696]
        comparison [20568,20696]
            atom [20568,20683]
                string: 'DEBUG:airflow.executors.celery_executor.BulkStateFetcher:Fetched 2 state(s) for 2 task(s)' [20582,20673]
            operator: == [20684,20686]
            atom_expr [20687,20696]
                name: cm [20687,20689]
                trailer [20689,20696]
                    name: output [20690,20696]
to
suite [19270,19843]
at 2
===
insert-node
---
operator: , [17481,17482]
to
with_stmt [17413,17743]
at 1
===
insert-tree
---
with_item [17483,17603]
    atom_expr [17483,17597]
        name: self [17483,17487]
        trailer [17487,17498]
            name: assertLogs [17488,17498]
        trailer [17498,17597]
            arglist [17516,17583]
                string: "airflow.executors.celery_executor.BulkStateFetcher" [17516,17568]
                operator: , [17568,17569]
                argument [17570,17583]
                    name: level [17570,17575]
                    operator: = [17575,17576]
                    string: "DEBUG" [17576,17583]
    name: cm [17601,17603]
to
with_stmt [17413,17743]
at 2
===
insert-node
---
operator: , [18766,18767]
to
with_stmt [18432,18813]
at 1
===
insert-tree
---
with_item [18768,18888]
    atom_expr [18768,18882]
        name: self [18768,18772]
        trailer [18772,18783]
            name: assertLogs [18773,18783]
        trailer [18783,18882]
            arglist [18801,18868]
                string: "airflow.executors.celery_executor.BulkStateFetcher" [18801,18853]
                operator: , [18853,18854]
                argument [18855,18868]
                    name: level [18855,18860]
                    operator: = [18860,18861]
                    string: "DEBUG" [18861,18868]
    name: cm [18886,18888]
to
with_stmt [18432,18813]
at 2
===
insert-node
---
operator: , [20033,20034]
to
with_stmt [19377,19764]
at 1
===
insert-tree
---
with_item [20035,20155]
    atom_expr [20035,20149]
        name: self [20035,20039]
        trailer [20039,20050]
            name: assertLogs [20040,20050]
        trailer [20050,20149]
            arglist [20068,20135]
                string: "airflow.executors.celery_executor.BulkStateFetcher" [20068,20120]
                operator: , [20120,20121]
                argument [20122,20135]
                    name: level [20122,20127]
                    operator: = [20127,20128]
                    string: "DEBUG" [20128,20135]
    name: cm [20153,20155]
to
with_stmt [19377,19764]
at 2
===
move-tree
---
simple_stmt [18822,18851]
    expr_stmt [18822,18850]
        name: fetcher [18822,18829]
        operator: = [18830,18831]
        atom_expr [18832,18850]
            name: BulkStateFetcher [18832,18848]
            trailer [18848,18850]
to
suite [18501,18813]
at 2
===
move-tree
---
simple_stmt [18859,19018]
    expr_stmt [18859,19017]
        name: result [18859,18865]
        operator: = [18866,18867]
        atom_expr [18868,19017]
            name: fetcher [18868,18875]
            trailer [18875,18884]
                name: get_many [18876,18884]
            trailer [18884,19017]
                atom [18898,19007]
                    testlist_comp [18916,18993]
                        atom_expr [18916,18945]
                            name: mock [18916,18920]
                            trailer [18920,18930]
                                name: MagicMock [18921,18930]
                            trailer [18930,18945]
                                argument [18931,18944]
                                    name: task_id [18931,18938]
                                    operator: = [18938,18939]
                                    string: "123" [18939,18944]
                        operator: , [18945,18946]
                        atom_expr [18963,18992]
                            name: mock [18963,18967]
                            trailer [18967,18977]
                                name: MagicMock [18968,18977]
                            trailer [18977,18992]
                                argument [18978,18991]
                                    name: task_id [18978,18985]
                                    operator: = [18985,18986]
                                    string: "456" [18986,18991]
                        operator: , [18992,18993]
to
suite [18501,18813]
at 3
