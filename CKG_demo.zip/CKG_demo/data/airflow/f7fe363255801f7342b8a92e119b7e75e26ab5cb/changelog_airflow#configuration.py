===
match
---
operator: - [32901,32902]
operator: - [32901,32902]
===
match
---
fstring_expr [19372,19377]
fstring_expr [19372,19377]
===
match
---
atom [5440,5470]
atom [5440,5470]
===
match
---
raise_stmt [18122,18309]
raise_stmt [18122,18309]
===
match
---
testlist_comp [5540,5563]
testlist_comp [5540,5563]
===
match
---
param [15275,15279]
param [15275,15279]
===
match
---
name: section_prefix [21549,21563]
name: section_prefix [21549,21563]
===
match
---
trailer [28867,28883]
trailer [28867,28883]
===
match
---
atom [5608,5637]
atom [5608,5637]
===
match
---
name: self [26121,26125]
name: self [26121,26125]
===
match
---
name: section [30166,30173]
name: section [30166,30173]
===
match
---
if_stmt [12355,12556]
if_stmt [12355,12556]
===
match
---
operator: = [13860,13861]
operator: = [13860,13861]
===
match
---
trailer [15989,16025]
trailer [15989,16025]
===
match
---
name: kwargs [38435,38441]
name: kwargs [38439,38445]
===
match
---
operator: = [31520,31521]
operator: = [31520,31521]
===
match
---
string: 'core' [4525,4531]
string: 'core' [4525,4531]
===
match
---
suite [25805,25855]
suite [25805,25855]
===
match
---
string: 'of {current_value!r}. This value has been changed to {new_value!r} in the ' [11499,11575]
string: 'of {current_value!r}. This value has been changed to {new_value!r} in the ' [11499,11575]
===
match
---
atom_expr [1569,1596]
atom_expr [1569,1596]
===
match
---
trailer [35916,35927]
trailer [35916,35927]
===
match
---
trailer [31062,31147]
trailer [31062,31147]
===
match
---
suite [21126,21200]
suite [21126,21200]
===
match
---
trailer [17534,17536]
trailer [17534,17536]
===
match
---
expr_stmt [10412,10465]
expr_stmt [10412,10465]
===
match
---
string: 'mp_start_method' [10447,10464]
string: 'mp_start_method' [10447,10464]
===
match
---
trailer [19039,19043]
trailer [19039,19043]
===
match
---
name: os [32379,32381]
name: os [32379,32381]
===
match
---
trailer [25587,25601]
trailer [25587,25601]
===
match
---
name: display_sensitive [27028,27045]
name: display_sensitive [27028,27045]
===
match
---
parameters [10883,10909]
parameters [10883,10909]
===
match
---
name: expand_env_var [12202,12216]
name: expand_env_var [12202,12216]
===
match
---
operator: , [17350,17351]
operator: , [17350,17351]
===
match
---
atom_expr [29782,30273]
atom_expr [29782,30273]
===
match
---
atom_expr [22732,22809]
atom_expr [22732,22809]
===
match
---
trailer [26570,26579]
trailer [26570,26579]
===
match
---
trailer [39756,39791]
trailer [39760,39795]
===
match
---
trailer [14854,14871]
trailer [14854,14871]
===
match
---
name: deprecated_key [16836,16850]
name: deprecated_key [16836,16850]
===
match
---
arith_expr [26580,26592]
arith_expr [26580,26592]
===
match
---
operator: } [15168,15169]
operator: } [15168,15169]
===
match
---
trailer [32910,32912]
trailer [32910,32912]
===
match
---
operator: , [22224,22225]
operator: , [22224,22225]
===
match
---
name: self [21711,21715]
name: self [21711,21715]
===
match
---
trailer [11225,11229]
trailer [11225,11229]
===
match
---
atom_expr [22482,22501]
atom_expr [22482,22501]
===
match
---
name: config [28405,28411]
name: config [28405,28411]
===
match
---
name: key [21704,21707]
name: key [21704,21707]
===
match
---
operator: , [8741,8742]
operator: , [8741,8742]
===
match
---
simple_stmt [14639,14653]
simple_stmt [14639,14653]
===
match
---
operator: , [36781,36782]
operator: , [36781,36782]
===
match
---
name: is_executor_without_sqlite_support [9574,9608]
name: is_executor_without_sqlite_support [9574,9608]
===
match
---
operator: , [13373,13374]
operator: , [13373,13374]
===
match
---
operator: , [25443,25444]
operator: , [25443,25444]
===
match
---
subscript [21640,21643]
subscript [21640,21643]
===
match
---
simple_stmt [27704,27773]
simple_stmt [27704,27773]
===
match
---
trailer [21116,21125]
trailer [21116,21125]
===
match
---
name: key [19065,19068]
name: key [19065,19068]
===
match
---
trailer [11177,11191]
trailer [11177,11191]
===
match
---
arglist [16716,16764]
arglist [16716,16764]
===
match
---
string: '%%' [26453,26457]
string: '%%' [26453,26457]
===
match
---
string: '2.1' [7912,7917]
string: '2.1' [7912,7917]
===
match
---
trailer [3772,3777]
trailer [3772,3777]
===
match
---
name: option [20161,20167]
name: option [20161,20167]
===
match
---
name: conf [37566,37570]
name: conf [37570,37574]
===
match
---
name: kwargs [37169,37175]
name: kwargs [37173,37179]
===
match
---
simple_stmt [15667,15681]
simple_stmt [15667,15681]
===
match
---
trailer [18444,18449]
trailer [18444,18449]
===
match
---
fstring_end: ' [19466,19467]
fstring_end: ' [19466,19467]
===
match
---
return_stmt [22185,22200]
return_stmt [22185,22200]
===
match
---
operator: , [4659,4660]
operator: , [4659,4660]
===
match
---
name: key [13998,14001]
name: key [13998,14001]
===
match
---
atom_expr [22078,22089]
atom_expr [22078,22089]
===
match
---
atom_expr [31050,31147]
atom_expr [31050,31147]
===
match
---
testlist_comp [22004,22015]
testlist_comp [22004,22015]
===
match
---
name: str [24650,24653]
name: str [24650,24653]
===
match
---
expr_stmt [17477,17536]
expr_stmt [17477,17536]
===
match
---
trailer [20484,20486]
trailer [20484,20486]
===
match
---
simple_stmt [22600,22681]
simple_stmt [22600,22681]
===
match
---
atom_expr [2168,2180]
atom_expr [2168,2180]
===
match
---
trailer [33671,33679]
trailer [33671,33679]
===
match
---
simple_stmt [14484,14498]
simple_stmt [14484,14498]
===
match
---
trailer [39565,39569]
trailer [39569,39573]
===
match
---
name: opt [26373,26376]
name: opt [26373,26376]
===
match
---
operator: = [17481,17482]
operator: = [17481,17482]
===
match
---
operator: = [28425,28426]
operator: = [28425,28426]
===
match
---
operator: = [2438,2439]
operator: = [2438,2439]
===
match
---
string: '2.1' [7553,7558]
string: '2.1' [7553,7558]
===
match
---
name: opt [25934,25937]
name: opt [25934,25937]
===
match
---
name: split [32879,32884]
name: split [32879,32884]
===
match
---
number: 0 [17593,17594]
number: 0 [17593,17594]
===
match
---
operator: , [30568,30569]
operator: , [30568,30569]
===
match
---
param [16230,16245]
param [16230,16245]
===
match
---
simple_stmt [39220,39248]
simple_stmt [39224,39252]
===
match
---
atom_expr [22765,22797]
atom_expr [22765,22797]
===
match
---
argument [38801,38813]
argument [38805,38817]
===
match
---
name: self [26169,26173]
name: self [26169,26173]
===
match
---
if_stmt [3004,3047]
if_stmt [3004,3047]
===
match
---
funcdef [22815,25397]
funcdef [22815,25397]
===
match
---
simple_stmt [33180,33196]
simple_stmt [33180,33196]
===
match
---
name: self [20530,20534]
name: self [20530,20534]
===
match
---
trailer [21024,21036]
trailer [21024,21036]
===
match
---
comparison [30492,30526]
comparison [30492,30526]
===
match
---
simple_stmt [3366,3403]
simple_stmt [3366,3403]
===
match
---
name: section [11727,11734]
name: section [11727,11734]
===
match
---
name: start_method_options [10580,10600]
name: start_method_options [10580,10600]
===
match
---
name: setdefault [25886,25896]
name: setdefault [25886,25896]
===
match
---
funcdef [11311,11854]
funcdef [11311,11854]
===
match
---
simple_stmt [30450,30485]
simple_stmt [30450,30485]
===
match
---
atom_expr [3885,3900]
atom_expr [3885,3900]
===
match
---
name: is_validated [9345,9357]
name: is_validated [9345,9357]
===
match
---
name: v [31852,31853]
name: v [31852,31853]
===
match
---
expr_stmt [19013,19079]
expr_stmt [19013,19079]
===
match
---
argument [9194,9221]
argument [9194,9221]
===
match
---
trailer [36741,36758]
trailer [36741,36758]
===
match
---
operator: , [7120,7121]
operator: , [7120,7121]
===
match
---
arglist [18382,18404]
arglist [18382,18404]
===
match
---
name: file_path [3890,3899]
name: file_path [3890,3899]
===
match
---
atom_expr [2618,2636]
atom_expr [2618,2636]
===
match
---
atom_expr [14516,14595]
atom_expr [14516,14595]
===
match
---
name: read [29196,29200]
name: read [29196,29200]
===
match
---
fstring_string: Failed to convert value to float. Please check " [18537,18585]
fstring_string: Failed to convert value to float. Please check " [18537,18585]
===
match
---
parameters [36775,36792]
parameters [36775,36792]
===
match
---
atom [7048,7082]
atom [7048,7082]
===
match
---
name: key [21763,21766]
name: key [21763,21766]
===
match
---
operator: , [35933,35934]
operator: , [35933,35934]
===
match
---
name: new_value [9247,9256]
name: new_value [9247,9256]
===
match
---
name: conf [39396,39400]
name: conf [39400,39404]
===
match
---
testlist_comp [5441,5469]
testlist_comp [5441,5469]
===
match
---
trailer [32341,32346]
trailer [32341,32346]
===
match
---
param [13375,13378]
param [13375,13378]
===
match
---
argument [30923,30936]
argument [30923,30936]
===
match
---
name: _env_var_name [11178,11191]
name: _env_var_name [11178,11191]
===
match
---
name: kwargs [17985,17991]
name: kwargs [17985,17991]
===
match
---
operator: , [20079,20080]
operator: , [20079,20080]
===
match
---
name: DEFAULT_CONFIG_FILE_PATH [3421,3445]
name: DEFAULT_CONFIG_FILE_PATH [3421,3445]
===
match
---
name: remove_option [20132,20145]
name: remove_option [20132,20145]
===
match
---
name: config_sources [25151,25165]
name: config_sources [25151,25165]
===
match
---
testlist_comp [5879,5915]
testlist_comp [5879,5915]
===
match
---
if_stmt [20527,20665]
if_stmt [20527,20665]
===
match
---
param [10884,10889]
param [10884,10889]
===
match
---
trailer [17317,17367]
trailer [17317,17367]
===
match
---
param [18698,18703]
param [18698,18703]
===
match
---
expr_stmt [2277,2299]
expr_stmt [2277,2299]
===
match
---
operator: , [20725,20726]
operator: , [20725,20726]
===
match
---
name: filterwarnings [1766,1780]
name: filterwarnings [1766,1780]
===
match
---
name: deprecated_section [17332,17350]
name: deprecated_section [17332,17350]
===
match
---
atom_expr [18439,18449]
atom_expr [18439,18449]
===
match
---
operator: , [24742,24743]
operator: , [24742,24743]
===
match
---
simple_stmt [813,836]
simple_stmt [813,836]
===
match
---
if_stmt [14293,14342]
if_stmt [14293,14342]
===
match
---
operator: , [4725,4726]
operator: , [4725,4726]
===
match
---
trailer [18377,18381]
trailer [18377,18381]
===
match
---
param [13813,13818]
param [13813,13818]
===
match
---
name: _replace_config_with_display_sources [24803,24839]
name: _replace_config_with_display_sources [24803,24839]
===
match
---
strings [29813,29995]
strings [29813,29995]
===
match
---
string: "Accessing configuration method 'getint' directly from the configuration module is " [36457,36541]
string: "Accessing configuration method 'getint' directly from the configuration module is " [36457,36541]
===
match
---
atom_expr [20717,20756]
atom_expr [20717,20756]
===
match
---
return_stmt [35490,35522]
return_stmt [35490,35522]
===
match
---
name: key [27762,27765]
name: key [27762,27765]
===
match
---
name: _include_commands [25133,25150]
name: _include_commands [25133,25150]
===
match
---
arglist [35506,35521]
arglist [35506,35521]
===
match
---
operator: = [11726,11727]
operator: = [11726,11727]
===
match
---
name: super [19653,19658]
name: super [19653,19658]
===
match
---
string: 'AIRFLOW_HOME' [33388,33402]
string: 'AIRFLOW_HOME' [33388,33402]
===
match
---
operator: , [38791,38792]
operator: , [38795,38796]
===
match
---
operator: , [29294,29295]
operator: , [29294,29295]
===
match
---
trailer [34816,35107]
trailer [34816,35107]
===
match
---
arglist [15601,15649]
arglist [15601,15649]
===
match
---
atom [28498,28516]
atom [28498,28516]
===
match
---
name: self [16065,16069]
name: self [16065,16069]
===
match
---
suite [21964,22145]
suite [21964,22145]
===
match
---
atom_expr [11397,11853]
atom_expr [11397,11853]
===
match
---
if_stmt [24959,25062]
if_stmt [24959,25062]
===
match
---
operator: ** [17458,17460]
operator: ** [17458,17460]
===
match
---
param [17444,17452]
param [17444,17452]
===
match
---
name: section [14109,14116]
name: section [14109,14116]
===
match
---
simple_stmt [15472,15541]
simple_stmt [15472,15541]
===
match
---
atom_expr [34290,34322]
atom_expr [34290,34322]
===
match
---
param [14771,14776]
param [14771,14776]
===
match
---
expr_stmt [32486,32540]
expr_stmt [32486,32540]
===
match
---
string: 'logging' [5879,5888]
string: 'logging' [5879,5888]
===
match
---
fstring_start: f' [11925,11927]
fstring_start: f' [11925,11927]
===
match
---
suite [39170,39216]
suite [39174,39220]
===
match
---
testlist_comp [5147,5175]
testlist_comp [5147,5175]
===
match
---
trailer [36442,36447]
trailer [36442,36447]
===
match
---
name: self [18698,18702]
name: self [18698,18702]
===
match
---
simple_stmt [8911,8955]
simple_stmt [8911,8955]
===
match
---
name: deprecated_key [15525,15539]
name: deprecated_key [15525,15539]
===
match
---
atom_expr [19983,20025]
atom_expr [19983,20025]
===
match
---
name: _warn_deprecate [16700,16715]
name: _warn_deprecate [16700,16715]
===
match
---
trailer [24649,24670]
trailer [24649,24670]
===
match
---
name: os [32169,32171]
name: os [32169,32171]
===
match
---
name: BaseSecretsBackend [39852,39870]
name: BaseSecretsBackend [39856,39874]
===
match
---
name: conf [33334,33338]
name: conf [33334,33338]
===
match
---
operator: = [19521,19522]
operator: = [19521,19522]
===
match
---
simple_stmt [1337,1376]
simple_stmt [1337,1376]
===
match
---
expr_stmt [26163,26203]
expr_stmt [26163,26203]
===
match
---
operator: , [33053,33054]
operator: , [33053,33054]
===
match
---
trailer [3759,3764]
trailer [3759,3764]
===
match
---
operator: , [6461,6462]
operator: , [6461,6462]
===
match
---
name: sqlite3 [10003,10010]
name: sqlite3 [10003,10010]
===
match
---
testlist_comp [20066,20095]
testlist_comp [20066,20095]
===
match
---
funcdef [17952,18310]
funcdef [17952,18310]
===
match
---
arith_expr [34244,34281]
arith_expr [34244,34281]
===
match
---
if_stmt [16331,16577]
if_stmt [16331,16577]
===
match
---
try_stmt [21888,22145]
try_stmt [21888,22145]
===
match
---
operator: , [1299,1300]
operator: , [1299,1300]
===
match
---
fstring_string: .  [2756,2758]
fstring_string: .  [2756,2758]
===
match
---
name: custom_secret_backend [40062,40083]
name: custom_secret_backend [40066,40087]
===
match
---
simple_stmt [33077,33120]
simple_stmt [33077,33120]
===
match
---
operator: { [19443,19444]
operator: { [19443,19444]
===
match
---
atom_expr [34637,34660]
atom_expr [34637,34660]
===
match
---
param [13366,13374]
param [13366,13374]
===
match
---
string: 'cmd' [26385,26390]
string: 'cmd' [26385,26390]
===
match
---
operator: = [2520,2521]
operator: = [2520,2521]
===
match
---
param [22985,23005]
param [22985,23005]
===
match
---
param [22836,22841]
param [22836,22841]
===
match
---
name: self [8848,8852]
name: self [8848,8852]
===
match
---
trailer [13244,13267]
trailer [13244,13267]
===
match
---
trailer [13302,13311]
trailer [13302,13311]
===
match
---
comparison [40062,40095]
comparison [40066,40099]
===
match
---
atom [7593,7692]
atom [7593,7692]
===
match
---
name: sensitive_config_values [4450,4473]
name: sensitive_config_values [4450,4473]
===
match
---
trailer [31374,31379]
trailer [31374,31379]
===
match
---
name: __init__ [8301,8309]
name: __init__ [8301,8309]
===
match
---
name: section [8610,8617]
name: section [8610,8617]
===
match
---
operator: = [19051,19052]
operator: = [19051,19052]
===
match
---
name: deprecated_section [15758,15776]
name: deprecated_section [15758,15776]
===
match
---
operator: , [22870,22871]
operator: , [22870,22871]
===
match
---
simple_stmt [35608,35901]
simple_stmt [35608,35901]
===
match
---
operator: , [16277,16278]
operator: , [16277,16278]
===
match
---
simple_stmt [31237,31291]
simple_stmt [31237,31291]
===
match
---
trailer [32874,32913]
trailer [32874,32913]
===
match
---
or_test [14850,14920]
or_test [14850,14920]
===
match
---
testlist_comp [4525,4545]
testlist_comp [4525,4545]
===
match
---
operator: , [11237,11238]
operator: , [11237,11238]
===
match
---
atom_expr [18495,18678]
atom_expr [18495,18678]
===
match
---
name: old [29570,29573]
name: old [29570,29573]
===
match
---
operator: , [16923,16924]
operator: , [16923,16924]
===
match
---
trailer [3191,3196]
trailer [3191,3196]
===
match
---
name: self [17963,17967]
name: self [17963,17967]
===
match
---
name: TEST_CONFIG_FILE_PATH [3510,3531]
name: TEST_CONFIG_FILE_PATH [3510,3531]
===
match
---
operator: -> [23012,23014]
operator: -> [23012,23014]
===
match
---
operator: { [9929,9930]
operator: { [9929,9930]
===
match
---
simple_stmt [21661,21679]
simple_stmt [21661,21679]
===
match
---
atom_expr [19173,19207]
atom_expr [19173,19207]
===
match
---
argument [2456,2478]
argument [2456,2478]
===
match
---
operator: , [30228,30229]
operator: , [30228,30229]
===
match
---
name: output [2505,2511]
name: output [2505,2511]
===
match
---
string: 'logging' [5648,5657]
string: 'logging' [5648,5657]
===
match
---
name: deprecated_key [14391,14405]
name: deprecated_key [14391,14405]
===
match
---
name: deprecated_name [29574,29589]
name: deprecated_name [29574,29589]
===
match
---
return_stmt [11918,11969]
return_stmt [11918,11969]
===
match
---
operator: , [25506,25507]
operator: , [25506,25507]
===
match
---
trailer [28345,28356]
trailer [28345,28356]
===
match
---
atom_expr [31084,31127]
atom_expr [31084,31127]
===
match
---
if_stmt [10161,10344]
if_stmt [10161,10344]
===
match
---
argument [38382,38394]
argument [38386,38398]
===
match
---
operator: , [3391,3392]
operator: , [3391,3392]
===
match
---
return_stmt [14161,14174]
return_stmt [14161,14174]
===
match
---
trailer [19186,19207]
trailer [19186,19207]
===
match
---
trailer [40401,40403]
trailer [40405,40407]
===
match
---
if_stmt [13530,13780]
if_stmt [13530,13780]
===
match
---
trailer [32381,32386]
trailer [32381,32386]
===
match
---
name: env_var [12673,12680]
name: env_var [12673,12680]
===
match
---
fstring_end: " [9959,9960]
fstring_end: " [9959,9960]
===
match
---
trailer [3889,3900]
trailer [3889,3900]
===
match
---
name: args [38427,38431]
name: args [38431,38435]
===
match
---
funcdef [36761,37177]
funcdef [36761,37181]
===
match
---
atom_expr [3757,3816]
atom_expr [3757,3816]
===
match
---
atom_expr [15034,15102]
atom_expr [15034,15102]
===
match
---
operator: , [21563,21564]
operator: , [21563,21564]
===
match
---
name: config_file [3947,3958]
name: config_file [3947,3958]
===
match
---
name: replacement [8619,8630]
name: replacement [8619,8630]
===
match
---
trailer [19256,19262]
trailer [19256,19262]
===
match
---
name: _get_secret_option [15351,15369]
name: _get_secret_option [15351,15369]
===
match
---
trailer [8504,8517]
trailer [8504,8517]
===
match
---
fstring_string: " key in " [18221,18231]
fstring_string: " key in " [18221,18231]
===
match
---
name: section [28426,28433]
name: section [28426,28433]
===
match
---
return_stmt [12195,12237]
return_stmt [12195,12237]
===
match
---
arglist [33206,33250]
arglist [33206,33250]
===
match
---
trailer [11257,11261]
trailer [11257,11261]
===
match
---
atom_expr [14669,14729]
atom_expr [14669,14729]
===
match
---
trailer [22769,22780]
trailer [22769,22780]
===
match
---
atom [4524,4546]
atom [4524,4546]
===
match
---
trailer [8869,8889]
trailer [8869,8889]
===
match
---
name: re [8923,8925]
name: re [8923,8925]
===
match
---
name: self [17487,17491]
name: self [17487,17491]
===
match
---
atom_expr [28405,28443]
atom_expr [28405,28443]
===
match
---
atom_expr [36026,36314]
atom_expr [36026,36314]
===
match
---
operator: , [27860,27861]
operator: , [27860,27861]
===
match
---
param [37619,37625]
param [37623,37629]
===
match
---
operator: , [28265,28266]
operator: , [28265,28266]
===
match
---
trailer [30555,30584]
trailer [30555,30584]
===
match
---
arglist [32776,32797]
arglist [32776,32797]
===
match
---
comparison [10934,10971]
comparison [10934,10971]
===
match
---
funcdef [39250,39808]
funcdef [39254,39812]
===
match
---
expr_stmt [9340,9364]
expr_stmt [9340,9364]
===
match
---
operator: = [9017,9018]
operator: = [9017,9018]
===
match
---
name: include_cmds [22958,22970]
name: include_cmds [22958,22970]
===
match
---
trailer [10944,10959]
trailer [10944,10959]
===
match
---
name: _get_secret_option [13341,13359]
name: _get_secret_option [13341,13359]
===
match
---
operator: , [28281,28282]
operator: , [28281,28282]
===
match
---
trailer [12120,12134]
trailer [12120,12134]
===
match
---
subscriptlist [24660,24668]
subscriptlist [24660,24668]
===
match
---
operator: + [12681,12682]
operator: + [12681,12682]
===
match
---
name: key [17071,17074]
name: key [17071,17074]
===
match
---
name: key [26948,26951]
name: key [26948,26951]
===
match
---
funcdef [11877,11970]
funcdef [11877,11970]
===
match
---
name: section [25499,25506]
name: section [25499,25506]
===
match
---
trailer [2156,2167]
trailer [2156,2167]
===
match
---
trailer [17486,17520]
trailer [17486,17520]
===
match
---
name: key [18026,18029]
name: key [18026,18029]
===
match
---
name: NoOptionError [20066,20079]
name: NoOptionError [20066,20079]
===
match
---
name: str [13897,13900]
name: str [13897,13900]
===
match
---
simple_stmt [2505,2610]
simple_stmt [2505,2610]
===
match
---
name: option [15910,15916]
name: option [15910,15916]
===
match
---
operator: , [15608,15609]
operator: , [15608,15609]
===
match
---
for_stmt [21418,21750]
for_stmt [21418,21750]
===
match
---
comparison [10164,10237]
comparison [10164,10237]
===
match
---
operator: , [28364,28365]
operator: , [28364,28365]
===
match
---
funcdef [16191,16883]
funcdef [16191,16883]
===
match
---
suite [24974,25062]
suite [24974,25062]
===
match
---
argument [11736,11763]
argument [11736,11763]
===
match
---
trailer [14977,14981]
trailer [14977,14981]
===
match
---
param [19729,19734]
param [19729,19734]
===
match
---
param [12989,12994]
param [12989,12994]
===
match
---
name: AirflowConfigException [9870,9892]
name: AirflowConfigException [9870,9892]
===
match
---
atom_expr [20530,20579]
atom_expr [20530,20579]
===
match
---
operator: , [38813,38814]
operator: , [38817,38818]
===
match
---
simple_stmt [2277,2300]
simple_stmt [2277,2300]
===
match
---
string: 'colored_log_format' [5847,5867]
string: 'colored_log_format' [5847,5867]
===
match
---
name: DeprecationWarning [35438,35456]
name: DeprecationWarning [35438,35456]
===
match
---
simple_stmt [12106,12149]
simple_stmt [12106,12149]
===
match
---
name: kwargs [14998,15004]
name: kwargs [14998,15004]
===
match
---
with_stmt [32766,32914]
with_stmt [32766,32914]
===
match
---
atom_expr [31919,31946]
atom_expr [31919,31946]
===
match
---
operator: = [3182,3183]
operator: = [3182,3183]
===
match
---
simple_stmt [32677,32762]
simple_stmt [32677,32762]
===
match
---
name: section [18704,18711]
name: section [18704,18711]
===
match
---
return_stmt [16174,16185]
return_stmt [16174,16185]
===
match
---
suite [21459,21750]
suite [21459,21750]
===
match
---
param [27853,27861]
param [27853,27861]
===
match
---
testlist_star_expr [26851,26866]
testlist_star_expr [26851,26866]
===
match
---
arglist [14982,15004]
arglist [14982,15004]
===
match
---
name: current_value [9194,9207]
name: current_value [9194,9207]
===
match
---
operator: , [14082,14083]
operator: , [14082,14083]
===
match
---
operator: , [16360,16361]
operator: , [16360,16361]
===
match
---
trailer [33103,33119]
trailer [33103,33119]
===
match
---
argument [35928,35933]
argument [35928,35933]
===
match
---
name: _sections [22709,22718]
name: _sections [22709,22718]
===
match
---
atom [6734,6762]
atom [6734,6762]
===
match
---
name: getint [17956,17962]
name: getint [17956,17962]
===
match
---
name: class_name [40157,40167]
name: class_name [40161,40171]
===
match
---
name: env_var [11230,11237]
name: env_var [11230,11237]
===
match
---
comparison [17615,17640]
comparison [17615,17640]
===
match
---
suite [18736,19482]
suite [18736,19482]
===
match
---
simple_stmt [17119,17133]
simple_stmt [17119,17133]
===
match
---
trailer [21317,21351]
trailer [21317,21351]
===
match
---
parameters [37193,37210]
parameters [37197,37214]
===
match
---
simple_stmt [16871,16883]
simple_stmt [16871,16883]
===
match
---
atom_expr [26121,26149]
atom_expr [26121,26149]
===
match
---
name: get [39566,39569]
name: get [39570,39573]
===
match
---
atom [4476,4769]
atom [4476,4769]
===
match
---
operator: , [30054,30055]
operator: , [30054,30055]
===
match
---
param [17438,17443]
param [17438,17443]
===
match
---
operator: = [27171,27172]
operator: = [27171,27172]
===
match
---
atom_expr [20612,20664]
atom_expr [20612,20664]
===
match
---
name: re [7529,7531]
name: re [7529,7531]
===
match
---
name: key [30129,30132]
name: key [30129,30132]
===
match
---
arglist [33703,33735]
arglist [33703,33735]
===
match
---
simple_stmt [24629,24676]
simple_stmt [24629,24676]
===
match
---
name: display_sensitive [26050,26067]
name: display_sensitive [26050,26067]
===
match
---
name: str [20700,20703]
name: str [20700,20703]
===
match
---
param [26623,26638]
param [26623,26638]
===
match
---
name: AIRFLOW_HOME [31588,31600]
name: AIRFLOW_HOME [31588,31600]
===
match
---
name: section_prefix [21361,21375]
name: section_prefix [21361,21375]
===
match
---
operator: , [22903,22904]
operator: , [22903,22904]
===
match
---
trailer [31465,31472]
trailer [31465,31472]
===
match
---
suite [8196,8222]
suite [8196,8222]
===
match
---
simple_stmt [16152,16166]
simple_stmt [16152,16166]
===
match
---
param [36776,36782]
param [36776,36782]
===
match
---
string: 'config_templates' [3797,3815]
string: 'config_templates' [3797,3815]
===
match
---
suite [25737,25780]
suite [25737,25780]
===
match
---
name: self [13551,13555]
name: self [13551,13555]
===
match
---
name: alternative_secrets_config_dict [39684,39715]
name: alternative_secrets_config_dict [39688,39719]
===
match
---
operator: , [33386,33387]
operator: , [33386,33387]
===
match
---
name: conf [37148,37152]
name: conf [37148,37152]
===
match
---
string: """Runs command and returns stdout""" [2332,2369]
string: """Runs command and returns stdout""" [2332,2369]
===
match
---
trailer [14067,14117]
trailer [14067,14117]
===
match
---
operator: , [16269,16270]
operator: , [16269,16270]
===
match
---
suite [3026,3047]
suite [3026,3047]
===
match
---
trailer [3152,3162]
trailer [3152,3162]
===
match
---
param [19627,19642]
param [19627,19642]
===
match
---
name: k [31849,31850]
name: k [31849,31850]
===
match
---
param [18328,18333]
param [18328,18333]
===
match
---
simple_stmt [18367,18406]
simple_stmt [18367,18406]
===
match
---
arglist [16552,16574]
arglist [16552,16574]
===
match
---
trailer [28933,29002]
trailer [28933,29002]
===
match
---
name: expand_env_var [14941,14955]
name: expand_env_var [14941,14955]
===
match
---
name: self [16919,16923]
name: self [16919,16923]
===
match
---
name: encoding [19571,19579]
name: encoding [19571,19579]
===
match
---
name: self [9404,9408]
name: self [9404,9408]
===
match
---
operator: = [39716,39717]
operator: = [39720,39721]
===
match
---
name: sect [28324,28328]
name: sect [28324,28328]
===
match
---
name: config_sources [25382,25396]
name: config_sources [25382,25396]
===
match
---
name: option [14335,14341]
name: option [14335,14341]
===
match
---
name: cfg [32816,32819]
name: cfg [32816,32819]
===
match
---
name: section [16716,16723]
name: section [16716,16723]
===
match
---
name: read_dict [19599,19608]
name: read_dict [19599,19608]
===
match
---
simple_stmt [27110,27129]
simple_stmt [27110,27129]
===
match
---
atom [5472,5499]
atom [5472,5499]
===
match
---
trailer [17041,17061]
trailer [17041,17061]
===
match
---
trailer [32965,33024]
trailer [32965,33024]
===
match
---
name: warnings [35608,35616]
name: warnings [35608,35616]
===
match
---
string: """     Expands (potentially nested) env vars by repeatedly applying     `expandvars` and `expanduser` until interpolation stops having     any effect.     """ [1888,2047]
string: """     Expands (potentially nested) env vars by repeatedly applying     `expandvars` and `expanduser` until interpolation stops having     any effect.     """ [1888,2047]
===
match
---
name: has_option [37183,37193]
name: has_option [37187,37197]
===
match
---
name: items [8657,8662]
name: items [8657,8662]
===
match
---
atom_expr [33295,33331]
atom_expr [33295,33331]
===
match
---
operator: , [9022,9023]
operator: , [9022,9023]
===
match
---
suite [17106,17133]
suite [17106,17133]
===
match
---
param [10997,11002]
param [10997,11002]
===
match
---
name: TEMPLATE_START [33144,33158]
name: TEMPLATE_START [33144,33158]
===
match
---
argument [8373,8378]
argument [8373,8378]
===
match
---
trailer [3473,3496]
trailer [3473,3496]
===
match
---
name: exist_ok [30923,30931]
name: exist_ok [30923,30931]
===
match
---
string: 'utf-8' [32532,32539]
string: 'utf-8' [32532,32539]
===
match
---
operator: + [10759,10760]
operator: + [10759,10760]
===
match
---
param [22913,22923]
param [22913,22923]
===
match
---
operator: , [4531,4532]
operator: , [4531,4532]
===
match
---
atom_expr [11956,11967]
atom_expr [11956,11967]
===
match
---
name: deprecated_options [13965,13983]
name: deprecated_options [13965,13983]
===
match
---
name: backend_list [39979,39991]
name: backend_list [39983,39995]
===
match
---
name: kwargs [38462,38468]
name: kwargs [38466,38472]
===
match
---
suite [31495,31543]
suite [31495,31543]
===
match
---
operator: * [37160,37161]
operator: * [37164,37165]
===
match
---
name: get [17492,17495]
name: get [17492,17495]
===
match
---
string: "deprecated. Please access the configuration from the 'configuration.conf' object via " [38232,38319]
string: "deprecated. Please access the configuration from the 'configuration.conf' object via " [38236,38323]
===
match
---
operator: , [25904,25905]
operator: , [25904,25905]
===
match
---
operator: , [37959,37960]
operator: , [37963,37964]
===
match
---
name: _include_secrets [25406,25422]
name: _include_secrets [25406,25422]
===
match
---
simple_stmt [10255,10344]
simple_stmt [10255,10344]
===
match
---
operator: = [22864,22865]
operator: = [22864,22865]
===
match
---
name: List [38891,38895]
name: List [38895,38899]
===
match
---
simple_stmt [25375,25397]
simple_stmt [25375,25397]
===
match
---
if_stmt [9970,10344]
if_stmt [9970,10344]
===
match
---
operator: , [12142,12143]
operator: , [12142,12143]
===
match
---
return_stmt [36723,36758]
return_stmt [36723,36758]
===
match
---
expr_stmt [4450,4769]
expr_stmt [4450,4769]
===
match
---
atom_expr [10164,10201]
atom_expr [10164,10201]
===
match
---
atom [26379,26391]
atom [26379,26391]
===
match
---
operator: , [36689,36690]
operator: , [36689,36690]
===
match
---
simple_stmt [3248,3299]
simple_stmt [3248,3299]
===
match
---
name: val [21768,21771]
name: val [21768,21771]
===
match
---
arglist [31068,31145]
arglist [31068,31145]
===
match
---
expr_stmt [31030,31147]
expr_stmt [31030,31147]
===
match
---
operator: - [33160,33161]
operator: - [33160,33161]
===
match
---
atom_expr [34438,34494]
atom_expr [34438,34494]
===
match
---
operator: = [28438,28439]
operator: = [28438,28439]
===
match
---
name: self [13960,13964]
name: self [13960,13964]
===
match
---
trailer [21334,21340]
trailer [21334,21340]
===
match
---
name: stacklevel [29728,29738]
name: stacklevel [29728,29738]
===
match
---
name: _validate_config_dependencies [9374,9403]
name: _validate_config_dependencies [9374,9403]
===
match
---
name: warn [38551,38555]
name: warn [38555,38559]
===
match
---
operator: , [34612,34613]
operator: , [34612,34613]
===
match
---
name: val [28499,28502]
name: val [28499,28502]
===
match
---
operator: ** [14791,14793]
operator: ** [14791,14793]
===
match
---
string: "deprecated. Please access the configuration from the 'configuration.conf' object via " [36550,36637]
string: "deprecated. Please access the configuration from the 'configuration.conf' object via " [36550,36637]
===
match
---
operator: , [15253,15254]
operator: , [15253,15254]
===
match
---
name: self [12989,12993]
name: self [12989,12993]
===
match
---
simple_stmt [31655,31833]
simple_stmt [31655,31833]
===
match
---
name: join [32107,32111]
name: join [32107,32111]
===
match
---
name: module [1835,1841]
name: module [1835,1841]
===
match
---
name: update [27754,27760]
name: update [27754,27760]
===
match
---
trailer [31070,31075]
trailer [31070,31075]
===
match
---
string: 'Specifying airflow_home in the config file is deprecated. As you ' [33831,33898]
string: 'Specifying airflow_home in the config file is deprecated. As you ' [33831,33898]
===
match
---
import_name [9996,10010]
import_name [9996,10010]
===
match
---
decorator [27778,27792]
decorator [27778,27792]
===
match
---
string: 'logging' [6365,6374]
string: 'logging' [6365,6374]
===
match
---
simple_stmt [15415,15429]
simple_stmt [15415,15429]
===
match
---
simple_stmt [40264,40307]
simple_stmt [40268,40311]
===
match
---
operator: , [19569,19570]
operator: , [19569,19570]
===
match
---
operator: -> [20705,20707]
operator: -> [20705,20707]
===
match
---
atom_expr [31897,31906]
atom_expr [31897,31906]
===
match
---
argument [38841,38846]
argument [38845,38850]
===
match
---
name: WEBSERVER_CONFIG [34305,34321]
name: WEBSERVER_CONFIG [34305,34321]
===
match
---
atom_expr [40388,40403]
atom_expr [40392,40407]
===
match
---
operator: , [7917,7918]
operator: , [7917,7918]
===
match
---
name: join [31583,31587]
name: join [31583,31587]
===
match
---
name: val [17615,17618]
name: val [17615,17618]
===
match
---
funcdef [18315,18679]
funcdef [18315,18679]
===
match
---
fstring_string: " key in " [17858,17868]
fstring_string: " key in " [17858,17868]
===
match
---
for_stmt [26099,26594]
for_stmt [26099,26594]
===
match
---
string: 'default' [1788,1797]
string: 'default' [1788,1797]
===
match
---
operator: , [26383,26384]
operator: , [26383,26384]
===
match
---
decorator [29224,29238]
decorator [29224,29238]
===
match
---
name: os_environment [26736,26750]
name: os_environment [26736,26750]
===
match
---
name: path [31053,31057]
name: path [31053,31057]
===
match
---
not_test [32375,32409]
not_test [32375,32409]
===
match
---
trailer [17587,17592]
trailer [17587,17592]
===
match
---
name: opt [26163,26166]
name: opt [26163,26166]
===
match
---
trailer [3946,3959]
trailer [3946,3959]
===
match
---
trailer [26938,26952]
trailer [26938,26952]
===
match
---
operator: , [19692,19693]
operator: , [19692,19693]
===
match
---
operator: , [13190,13191]
operator: , [13190,13191]
===
match
---
fstring [19324,19408]
fstring [19324,19408]
===
match
---
name: file [34549,34553]
name: file [34549,34553]
===
match
---
operator: , [6172,6173]
operator: , [6172,6173]
===
match
---
name: val [22173,22176]
name: val [22173,22176]
===
match
---
simple_stmt [35490,35523]
simple_stmt [35490,35523]
===
match
---
name: kwargs [16854,16860]
name: kwargs [16854,16860]
===
match
---
operator: { [24673,24674]
operator: { [24673,24674]
===
match
---
name: AIRFLOW_HOME [30862,30874]
name: AIRFLOW_HOME [30862,30874]
===
match
---
trailer [14040,14067]
trailer [14040,14067]
===
match
---
trailer [12219,12227]
trailer [12219,12227]
===
match
---
trailer [8852,8869]
trailer [8852,8869]
===
match
---
name: airflow_defaults [20617,20633]
name: airflow_defaults [20617,20633]
===
match
---
simple_stmt [22157,22177]
simple_stmt [22157,22177]
===
match
---
name: env_var_secret_path [12651,12670]
name: env_var_secret_path [12651,12670]
===
match
---
atom [5963,5988]
atom [5963,5988]
===
match
---
name: key [21588,21591]
name: key [21588,21591]
===
match
---
operator: = [19033,19034]
operator: = [19033,19034]
===
match
---
name: str [3153,3156]
name: str [3153,3156]
===
match
---
name: _get_secret_option [25569,25587]
name: _get_secret_option [25569,25587]
===
match
---
fstring_expr [18216,18221]
fstring_expr [18216,18221]
===
match
---
trailer [29200,29218]
trailer [29200,29218]
===
match
---
name: stacklevel [37535,37545]
name: stacklevel [37539,37549]
===
match
---
name: file_name [3128,3137]
name: file_name [3128,3137]
===
match
---
fstring_start: f' [19324,19326]
fstring_start: f' [19324,19326]
===
match
---
name: delimiter [22456,22465]
name: delimiter [22456,22465]
===
match
---
string: 'SequentialExecutor' [9690,9710]
string: 'SequentialExecutor' [9690,9710]
===
match
---
name: version [11786,11793]
name: version [11786,11793]
===
match
---
name: _get_option_from_secrets [15208,15232]
name: _get_option_from_secrets [15208,15232]
===
match
---
trailer [13182,13205]
trailer [13182,13205]
===
match
---
name: option [17087,17093]
name: option [17087,17093]
===
match
---
name: default_config_yaml [3586,3605]
name: default_config_yaml [3586,3605]
===
match
---
trailer [31472,31494]
trailer [31472,31494]
===
match
---
atom_expr [12202,12237]
atom_expr [12202,12237]
===
match
---
name: _defaults [22651,22660]
name: _defaults [22651,22660]
===
match
---
trailer [39142,39164]
trailer [39146,39168]
===
match
---
name: airflow_defaults [14961,14977]
name: airflow_defaults [14961,14977]
===
match
---
operator: , [5156,5157]
operator: , [5156,5157]
===
match
---
name: env_var_secret_path [12704,12723]
name: env_var_secret_path [12704,12723]
===
match
---
argument [8310,8315]
argument [8310,8315]
===
match
---
name: secrets_backend_cls [40208,40227]
name: secrets_backend_cls [40212,40231]
===
match
---
trailer [33343,33359]
trailer [33343,33359]
===
match
---
atom_expr [27992,28161]
atom_expr [27992,28161]
===
match
---
param [13828,13832]
param [13828,13832]
===
match
---
name: len [39139,39142]
name: len [39143,39146]
===
match
---
dictorsetmaker [27762,27770]
dictorsetmaker [27762,27770]
===
match
---
trailer [19306,19481]
trailer [19306,19481]
===
match
---
name: raw [25057,25060]
name: raw [25057,25060]
===
match
---
name: old [8870,8873]
name: old [8870,8873]
===
match
---
name: env_var [12330,12337]
name: env_var [12330,12337]
===
match
---
if_stmt [14449,14498]
if_stmt [14449,14498]
===
match
---
param [36377,36385]
param [36377,36385]
===
match
---
strings [38565,38763]
strings [38569,38767]
===
match
---
expr_stmt [24629,24675]
expr_stmt [24629,24675]
===
match
---
operator: , [29710,29711]
operator: , [29710,29711]
===
match
---
operator: , [5584,5585]
operator: , [5584,5585]
===
match
---
trailer [32449,32456]
trailer [32449,32456]
===
match
---
funcdef [8227,8526]
funcdef [8227,8526]
===
match
---
trailer [31158,31165]
trailer [31158,31165]
===
match
---
trailer [8594,8596]
trailer [8594,8596]
===
match
---
trailer [38018,38035]
trailer [38022,38039]
===
match
---
arglist [15990,16024]
arglist [15990,16024]
===
match
---
name: super [20430,20435]
name: super [20430,20435]
===
match
---
name: current_value [9208,9221]
name: current_value [9208,9221]
===
match
---
operator: , [31137,31138]
operator: , [31137,31138]
===
match
---
argument [18031,18039]
argument [18031,18039]
===
match
---
atom_expr [25832,25854]
atom_expr [25832,25854]
===
match
---
name: has_option [19718,19728]
name: has_option [19718,19728]
===
match
---
suite [3357,3403]
suite [3357,3403]
===
match
---
name: os [32509,32511]
name: os [32509,32511]
===
match
---
parameters [9403,9409]
parameters [9403,9409]
===
match
---
argument [34194,34221]
argument [34194,34221]
===
match
---
name: kwargs [8382,8388]
name: kwargs [8382,8388]
===
match
---
string: "Accessing configuration method 'set' directly from the configuration module is " [38565,38646]
string: "Accessing configuration method 'set' directly from the configuration module is " [38569,38650]
===
match
---
suite [33795,34101]
suite [33795,34101]
===
match
---
name: get [35502,35505]
name: get [35502,35505]
===
match
---
operator: , [11377,11378]
operator: , [11377,11378]
===
match
---
name: stacklevel [38801,38811]
name: stacklevel [38805,38815]
===
match
---
suite [2327,2839]
suite [2327,2839]
===
match
---
atom_expr [21302,21351]
atom_expr [21302,21351]
===
match
---
string: "Overriding settings with defaults from %s" [28751,28794]
string: "Overriding settings with defaults from %s" [28751,28794]
===
match
---
suite [35177,35523]
suite [35177,35523]
===
match
---
fstring_expr [17924,17929]
fstring_expr [17924,17929]
===
match
---
string: 'log_processor_filename_template' [6320,6353]
string: 'log_processor_filename_template' [6320,6353]
===
match
---
argument [1835,1851]
argument [1835,1851]
===
match
---
simple_stmt [9065,9331]
simple_stmt [9065,9331]
===
match
---
number: 1 [33161,33162]
number: 1 [33161,33162]
===
match
---
trailer [8474,8490]
trailer [8474,8490]
===
match
---
name: self [15580,15584]
name: self [15580,15584]
===
match
---
return_stmt [8205,8221]
return_stmt [8205,8221]
===
match
---
name: path [32924,32928]
name: path [32924,32928]
===
match
---
name: section [11719,11726]
name: section [11719,11726]
===
match
---
trailer [12729,12737]
trailer [12729,12737]
===
match
---
operator: , [29655,29656]
operator: , [29655,29656]
===
match
---
comp_op [9640,9646]
comp_op [9640,9646]
===
match
---
operator: = [34242,34243]
operator: = [34242,34243]
===
match
---
suite [3163,3403]
suite [3163,3403]
===
match
---
simple_stmt [24987,25062]
simple_stmt [24987,25062]
===
match
---
name: _read_default_config_file [3534,3559]
name: _read_default_config_file [3534,3559]
===
match
---
simple_stmt [28830,28885]
simple_stmt [28830,28885]
===
match
---
trailer [36039,36314]
trailer [36039,36314]
===
match
---
name: section [21280,21287]
name: section [21280,21287]
===
match
---
trailer [33200,33205]
trailer [33200,33205]
===
match
---
simple_stmt [34637,34661]
simple_stmt [34637,34661]
===
match
---
name: path [31071,31075]
name: path [31071,31075]
===
match
---
name: self [11253,11257]
name: self [11253,11257]
===
match
---
name: replace [25836,25843]
name: replace [25836,25843]
===
match
---
trailer [2540,2559]
trailer [2540,2559]
===
match
---
name: include_cmds [25102,25114]
name: include_cmds [25102,25114]
===
match
---
operator: , [35871,35872]
operator: , [35871,35872]
===
match
---
trailer [33169,33171]
trailer [33169,33171]
===
match
---
funcdef [28548,29219]
funcdef [28548,29219]
===
match
---
string: '_SECRET' [12683,12692]
string: '_SECRET' [12683,12692]
===
match
---
parameters [17437,17467]
parameters [17437,17467]
===
match
---
atom_expr [12116,12148]
atom_expr [12116,12148]
===
match
---
string: 'plugins' [31602,31611]
string: 'plugins' [31602,31611]
===
match
---
operator: , [25462,25463]
operator: , [25462,25463]
===
match
---
string: 'metrics' [6603,6612]
string: 'metrics' [6603,6612]
===
match
---
name: self [14771,14775]
name: self [14771,14775]
===
match
---
trailer [32447,32449]
trailer [32447,32449]
===
match
---
trailer [15504,15540]
trailer [15504,15540]
===
match
---
argument [19070,19078]
argument [19070,19078]
===
match
---
operator: , [14585,14586]
operator: , [14585,14586]
===
match
---
operator: = [14191,14192]
operator: = [14191,14192]
===
match
---
name: opt [26908,26911]
name: opt [26908,26911]
===
match
---
simple_stmt [2231,2251]
simple_stmt [2231,2251]
===
match
---
decorated [11859,11970]
decorated [11859,11970]
===
match
---
string: '_cmd' [26586,26592]
string: '_cmd' [26586,26592]
===
match
---
operator: == [2207,2209]
operator: == [2207,2209]
===
match
---
trailer [29027,29062]
trailer [29027,29062]
===
match
---
simple_stmt [13721,13780]
simple_stmt [13721,13780]
===
match
---
suite [27883,28162]
suite [27883,28162]
===
match
---
operator: = [39592,39593]
operator: = [39596,39597]
===
match
---
testlist_comp [5964,5987]
testlist_comp [5964,5987]
===
match
---
operator: , [8617,8618]
operator: , [8617,8618]
===
match
---
string: 'remote_base_log_folder' [5369,5393]
string: 'remote_base_log_folder' [5369,5393]
===
match
---
name: sensitive_config_values [12825,12848]
name: sensitive_config_values [12825,12848]
===
match
---
trailer [32168,32203]
trailer [32168,32203]
===
match
---
simple_stmt [32206,32263]
simple_stmt [32206,32263]
===
match
---
arglist [3770,3815]
arglist [3770,3815]
===
match
---
expr_stmt [15828,15871]
expr_stmt [15828,15871]
===
match
---
operator: -> [8189,8191]
operator: -> [8189,8191]
===
match
---
argument [19550,19569]
argument [19550,19569]
===
match
---
trailer [13765,13779]
trailer [13765,13779]
===
match
---
arith_expr [13463,13478]
arith_expr [13463,13478]
===
match
---
operator: , [17325,17326]
operator: , [17325,17326]
===
match
---
funcdef [26006,26594]
funcdef [26006,26594]
===
match
---
trailer [40392,40401]
trailer [40396,40405]
===
match
---
name: split [26877,26882]
name: split [26877,26882]
===
match
---
number: 1 [32902,32903]
number: 1 [32902,32903]
===
match
---
atom_expr [34549,34585]
atom_expr [34549,34585]
===
match
---
name: warn [11406,11410]
name: warn [11406,11410]
===
match
---
name: val [17477,17480]
name: val [17477,17480]
===
match
---
trailer [14364,14390]
trailer [14364,14390]
===
match
---
operator: , [29618,29619]
operator: , [29618,29619]
===
match
---
import_from [1507,1561]
import_from [1507,1561]
===
match
---
simple_stmt [1563,1597]
simple_stmt [1563,1597]
===
match
---
name: section [14883,14890]
name: section [14883,14890]
===
match
---
suite [15890,15917]
suite [15890,15917]
===
match
---
arglist [13183,13204]
arglist [13183,13204]
===
match
---
trailer [10434,10438]
trailer [10434,10438]
===
match
---
name: self [15233,15237]
name: self [15233,15237]
===
match
---
name: compile [7627,7634]
name: compile [7627,7634]
===
match
---
operator: , [11784,11785]
operator: , [11784,11785]
===
match
---
name: get_airflow_config [30843,30861]
name: get_airflow_config [30843,30861]
===
match
---
name: upper [21398,21403]
name: upper [21398,21403]
===
match
---
string: 'airflow_home' [33763,33777]
string: 'airflow_home' [33763,33777]
===
match
---
name: opt [26436,26439]
name: opt [26436,26439]
===
match
---
string: """Historical getsection""" [36812,36839]
string: """Historical getsection""" [36812,36839]
===
match
---
atom_expr [12911,12942]
atom_expr [12911,12942]
===
match
---
argument [30024,30054]
argument [30024,30054]
===
match
---
name: key [16095,16098]
name: key [16095,16098]
===
match
---
name: section [12449,12456]
name: section [12449,12456]
===
match
---
simple_stmt [21826,21841]
simple_stmt [21826,21841]
===
match
---
atom_expr [38000,38035]
atom_expr [38004,38039]
===
match
---
name: _get_environment_variables [14041,14067]
name: _get_environment_variables [14041,14067]
===
match
---
operator: = [2128,2129]
operator: = [2128,2129]
===
match
---
operator: , [15377,15378]
operator: , [15377,15378]
===
match
---
name: Fernet [32428,32434]
name: Fernet [32428,32434]
===
match
---
parameters [2882,2894]
parameters [2882,2894]
===
match
---
fstring_string: / [15169,15170]
fstring_string: / [15169,15170]
===
match
---
simple_stmt [34225,34282]
simple_stmt [34225,34282]
===
match
---
name: warn [34812,34816]
name: warn [34812,34816]
===
match
---
simple_stmt [17297,17368]
simple_stmt [17297,17368]
===
match
---
operator: = [17576,17577]
operator: = [17576,17577]
===
match
---
comparison [9611,9721]
comparison [9611,9721]
===
match
---
trailer [22486,22498]
trailer [22486,22498]
===
match
---
string: 'remote_base_log_folder' [5405,5429]
string: 'remote_base_log_folder' [5405,5429]
===
match
---
operator: , [8171,8172]
operator: , [8171,8172]
===
match
---
string: """Historical get""" [35182,35202]
string: """Historical get""" [35182,35202]
===
match
---
try_stmt [19149,19482]
try_stmt [19149,19482]
===
match
---
string: """Historical load_test_config""" [34765,34798]
string: """Historical load_test_config""" [34765,34798]
===
match
---
trailer [20616,20633]
trailer [20616,20633]
===
match
---
name: kwargs [14268,14274]
name: kwargs [14268,14274]
===
match
---
name: args [36777,36781]
name: args [36777,36781]
===
match
---
trailer [32653,32671]
trailer [32653,32671]
===
match
---
name: warnings [1757,1765]
name: warnings [1757,1765]
===
match
---
param [2318,2325]
param [2318,2325]
===
match
---
param [26034,26049]
param [26034,26049]
===
match
---
name: section [21390,21397]
name: section [21390,21397]
===
match
---
trailer [34811,34816]
trailer [34811,34816]
===
match
---
name: isfile [32347,32353]
name: isfile [32347,32353]
===
match
---
name: key [26580,26583]
name: key [26580,26583]
===
match
---
name: safe_load [3937,3946]
name: safe_load [3937,3946]
===
match
---
trailer [33379,33403]
trailer [33379,33403]
===
match
---
name: has_option [13604,13614]
name: has_option [13604,13614]
===
match
---
name: _get_cmd_option [26174,26189]
name: _get_cmd_option [26174,26189]
===
match
---
name: min_sqlite_version [10119,10137]
name: min_sqlite_version [10119,10137]
===
match
---
name: airflow_defaults [21008,21024]
name: airflow_defaults [21008,21024]
===
match
---
atom_expr [33083,33119]
atom_expr [33083,33119]
===
match
---
return_stmt [17654,17665]
return_stmt [17654,17665]
===
match
---
operator: = [29614,29615]
operator: = [29614,29615]
===
match
---
name: warn [35216,35220]
name: warn [35216,35220]
===
match
---
name: info [28929,28933]
name: info [28929,28933]
===
match
---
trailer [9762,9790]
trailer [9762,9790]
===
match
---
trailer [25843,25854]
trailer [25843,25854]
===
match
---
return_stmt [15689,15700]
return_stmt [15689,15700]
===
match
---
name: self [17297,17301]
name: self [17297,17301]
===
match
---
simple_stmt [15034,15103]
simple_stmt [15034,15103]
===
match
---
string: 'default_airflow.cfg' [3474,3495]
string: 'default_airflow.cfg' [3474,3495]
===
match
---
atom_expr [34328,34403]
atom_expr [34328,34403]
===
match
---
atom_expr [3770,3795]
atom_expr [3770,3795]
===
match
---
operator: , [37525,37526]
operator: , [37529,37530]
===
match
---
name: _get_cmd_option [15842,15857]
name: _get_cmd_option [15842,15857]
===
match
---
simple_stmt [27992,28162]
simple_stmt [27992,28162]
===
match
---
name: warn [36443,36447]
name: warn [36443,36447]
===
match
---
name: _create_future_warning [9070,9092]
name: _create_future_warning [9070,9092]
===
match
---
operator: , [8873,8874]
operator: , [8873,8874]
===
match
---
name: self [19609,19613]
name: self [19609,19613]
===
match
---
operator: , [6794,6795]
operator: , [6794,6795]
===
match
---
simple_stmt [26908,26953]
simple_stmt [26908,26953]
===
match
---
name: conf [36326,36330]
name: conf [36326,36330]
===
match
---
name: category [34062,34070]
name: category [34062,34070]
===
match
---
atom_expr [30516,30526]
atom_expr [30516,30526]
===
match
---
trailer [32171,32179]
trailer [32171,32179]
===
match
---
testlist_comp [6541,6563]
testlist_comp [6541,6563]
===
match
---
trailer [20716,20757]
trailer [20716,20757]
===
match
---
name: startswith [26783,26793]
name: startswith [26783,26793]
===
match
---
expr_stmt [30792,30825]
expr_stmt [30792,30825]
===
match
---
testlist_comp [6096,6133]
testlist_comp [6096,6133]
===
match
---
name: fallback [20009,20017]
name: fallback [20009,20017]
===
match
---
param [22932,22949]
param [22932,22949]
===
match
---
param [35146,35152]
param [35146,35152]
===
match
---
atom [6960,6997]
atom [6960,6997]
===
match
---
name: os [31084,31086]
name: os [31084,31086]
===
match
---
simple_stmt [1507,1562]
simple_stmt [1507,1562]
===
match
---
simple_stmt [7455,7951]
simple_stmt [7455,7951]
===
match
---
trailer [40384,40386]
trailer [40388,40390]
===
match
---
with_stmt [3303,3403]
with_stmt [3303,3403]
===
match
---
string: "mp_start_method should not be " [10668,10700]
string: "mp_start_method should not be " [10668,10700]
===
match
---
string: 'base_log_folder' [5158,5175]
string: 'base_log_folder' [5158,5175]
===
match
---
name: opt [26223,26226]
name: opt [26223,26226]
===
match
---
dictorsetmaker [31849,31906]
dictorsetmaker [31849,31906]
===
match
---
string: 'unittests.cfg' [32126,32141]
string: 'unittests.cfg' [32126,32141]
===
match
---
string: 'statsd_prefix' [6746,6761]
string: 'statsd_prefix' [6746,6761]
===
match
---
argument [39570,39587]
argument [39574,39591]
===
match
---
strings [35631,35843]
strings [35631,35843]
===
match
---
param [1874,1881]
param [1874,1881]
===
match
---
except_clause [19216,19239]
except_clause [19216,19239]
===
match
---
string: 'colored_console_log' [5771,5792]
string: 'colored_console_log' [5771,5792]
===
match
---
name: key [27674,27677]
name: key [27674,27677]
===
match
---
name: section [13534,13541]
name: section [13534,13541]
===
match
---
operator: = [3446,3447]
operator: = [3446,3447]
===
match
---
name: expand_env_var [1859,1873]
name: expand_env_var [1859,1873]
===
match
---
operator: , [36711,36712]
operator: , [36711,36712]
===
match
---
trailer [3936,3946]
trailer [3936,3946]
===
match
---
argument [16852,16860]
argument [16852,16860]
===
match
---
name: section [18601,18608]
name: section [18601,18608]
===
match
---
name: lower [13875,13880]
name: lower [13875,13880]
===
match
---
return_stmt [2076,2090]
return_stmt [2076,2090]
===
match
---
if_stmt [33361,34223]
if_stmt [33361,34223]
===
match
---
name: os [11215,11217]
name: os [11215,11217]
===
match
---
name: StrictVersion [10204,10217]
name: StrictVersion [10204,10217]
===
match
---
name: self [29191,29195]
name: self [29191,29195]
===
match
---
trailer [9344,9357]
trailer [9344,9357]
===
match
---
atom_expr [29118,29182]
atom_expr [29118,29182]
===
match
---
trailer [3764,3769]
trailer [3764,3769]
===
match
---
string: 'statsd_allow_list' [6816,6835]
string: 'statsd_allow_list' [6816,6835]
===
match
---
string: """Get Config option values from Secret Backend""" [13389,13439]
string: """Get Config option values from Secret Backend""" [13389,13439]
===
match
---
operator: = [39619,39620]
operator: = [39623,39624]
===
match
---
param [2883,2893]
param [2883,2893]
===
match
---
name: sub [8926,8929]
name: sub [8926,8929]
===
match
---
name: DeprecationWarning [38354,38372]
name: DeprecationWarning [38358,38376]
===
match
---
name: warnings [36844,36852]
name: warnings [36844,36852]
===
match
---
arglist [16816,16860]
arglist [16816,16860]
===
match
---
arglist [26883,26890]
arglist [26883,26890]
===
match
---
name: warnings [36026,36034]
name: warnings [36026,36034]
===
match
---
name: kwargs [14914,14920]
name: kwargs [14914,14920]
===
match
---
trailer [26756,26764]
trailer [26756,26764]
===
match
---
param [11338,11343]
param [11338,11343]
===
match
---
name: section [25975,25982]
name: section [25975,25982]
===
match
---
operator: , [6085,6086]
operator: , [6085,6086]
===
match
---
import_name [871,883]
import_name [871,883]
===
match
---
raise_stmt [19278,19481]
raise_stmt [19278,19481]
===
match
---
atom [12802,12816]
atom [12802,12816]
===
match
---
suite [21892,21930]
suite [21892,21930]
===
match
---
atom_expr [26471,26539]
atom_expr [26471,26539]
===
match
---
name: warnings [35207,35215]
name: warnings [35207,35215]
===
match
---
trailer [30613,30621]
trailer [30613,30621]
===
match
---
trailer [2679,2819]
trailer [2679,2819]
===
match
---
arglist [32966,33023]
arglist [32966,33023]
===
match
---
string: """         Load the unit test configuration.          Note: this is not reversible.         """ [28584,28680]
string: """         Load the unit test configuration.          Note: this is not reversible.         """ [28584,28680]
===
match
---
argument [30154,30173]
argument [30154,30173]
===
match
---
name: source [19694,19700]
name: source [19694,19700]
===
match
---
param [35960,35966]
param [35960,35966]
===
match
---
operator: , [38055,38056]
operator: , [38059,38060]
===
match
---
name: kwargs [16568,16574]
name: kwargs [16568,16574]
===
match
---
operator: , [29589,29590]
operator: , [29589,29590]
===
match
---
name: config [28078,28084]
name: config [28078,28084]
===
match
---
operator: , [30390,30391]
operator: , [30390,30391]
===
match
---
trailer [10812,10817]
trailer [10812,10817]
===
match
---
operator: , [7894,7895]
operator: , [7894,7895]
===
match
---
trailer [7762,7770]
trailer [7762,7770]
===
match
---
arglist [36457,36712]
arglist [36457,36712]
===
match
---
return_stmt [18432,18449]
return_stmt [18432,18449]
===
match
---
name: section [15161,15168]
name: section [15161,15168]
===
match
---
operator: , [20007,20008]
operator: , [20007,20008]
===
match
---
name: staticmethod [11860,11872]
name: staticmethod [11860,11872]
===
match
---
trailer [12134,12148]
trailer [12134,12148]
===
match
---
name: os [30543,30545]
name: os [30543,30545]
===
match
---
name: config_file [3373,3384]
name: config_file [3373,3384]
===
match
---
string: 'secrets' [39578,39587]
string: 'secrets' [39582,39591]
===
match
---
operator: * [35540,35541]
operator: * [35540,35541]
===
match
---
name: self [8544,8548]
name: self [8544,8548]
===
match
---
name: display_sensitive [25445,25462]
name: display_sensitive [25445,25462]
===
match
---
atom_expr [34134,34166]
atom_expr [34134,34166]
===
match
---
simple_stmt [3821,3875]
simple_stmt [3821,3875]
===
match
---
name: PIPE [2474,2478]
name: PIPE [2474,2478]
===
match
---
testlist_comp [6839,6871]
testlist_comp [6839,6871]
===
match
---
name: opt [26307,26310]
name: opt [26307,26310]
===
match
---
fstring [18269,18295]
fstring [18269,18295]
===
match
---
operator: , [6642,6643]
operator: , [6642,6643]
===
match
---
trailer [33754,33778]
trailer [33754,33778]
===
match
---
name: staticmethod [27779,27791]
name: staticmethod [27779,27791]
===
match
---
name: current_value [11750,11763]
name: current_value [11750,11763]
===
match
---
name: join [3268,3272]
name: join [3268,3272]
===
match
---
testlist_comp [5804,5835]
testlist_comp [5804,5835]
===
match
---
atom_expr [13670,13704]
atom_expr [13670,13704]
===
match
---
expr_stmt [22133,22144]
expr_stmt [22133,22144]
===
match
---
if_stmt [25638,25703]
if_stmt [25638,25703]
===
match
---
try_stmt [19761,20123]
try_stmt [19761,20123]
===
match
---
comparison [14129,14147]
comparison [14129,14147]
===
match
---
comp_op [8416,8422]
comp_op [8416,8422]
===
match
---
trailer [19991,20025]
trailer [19991,20025]
===
match
---
string: 'AIRFLOW_CONFIG' [30492,30508]
string: 'AIRFLOW_CONFIG' [30492,30508]
===
match
---
operator: , [33706,33707]
operator: , [33706,33707]
===
match
---
atom_expr [10178,10200]
atom_expr [10178,10200]
===
match
---
name: deprecated_options [5047,5065]
name: deprecated_options [5047,5065]
===
match
---
trailer [13123,13147]
trailer [13123,13147]
===
match
---
name: has_section [20974,20985]
name: has_section [20974,20985]
===
match
---
fstring_string: AIRFLOW__ [21380,21389]
fstring_string: AIRFLOW__ [21380,21389]
===
match
---
trailer [22474,22481]
trailer [22474,22481]
===
match
---
name: deprecated_section [13923,13941]
name: deprecated_section [13923,13941]
===
match
---
simple_stmt [913,929]
simple_stmt [913,929]
===
match
---
if_stmt [31148,31291]
if_stmt [31148,31291]
===
match
---
name: _warn_deprecate [16070,16085]
name: _warn_deprecate [16070,16085]
===
match
---
param [27878,27881]
param [27878,27881]
===
match
---
funcdef [25402,26001]
funcdef [25402,26001]
===
match
---
trailer [11965,11967]
trailer [11965,11967]
===
match
---
name: option [14129,14135]
name: option [14129,14135]
===
match
---
operator: , [19613,19614]
operator: , [19613,19614]
===
match
---
operator: = [39394,39395]
operator: = [39398,39399]
===
match
---
comp_op [30509,30515]
comp_op [30509,30515]
===
match
---
name: remove_option [37605,37618]
name: remove_option [37609,37622]
===
match
---
simple_stmt [35182,35203]
simple_stmt [35182,35203]
===
match
---
name: self [24798,24802]
name: self [24798,24802]
===
match
---
trailer [37159,37176]
trailer [37163,37180]
===
match
---
name: get_custom_secret_backend [39254,39279]
name: get_custom_secret_backend [39258,39283]
===
match
---
operator: { [19387,19388]
operator: { [19387,19388]
===
match
---
parameters [17962,17992]
parameters [17962,17992]
===
match
---
testlist_comp [5358,5393]
testlist_comp [5358,5393]
===
match
---
operator: , [6227,6228]
operator: , [6227,6228]
===
match
---
trailer [29126,29182]
trailer [29126,29182]
===
match
---
trailer [31075,31083]
trailer [31075,31083]
===
match
---
string: 'colored_formatter_class' [5890,5915]
string: 'colored_formatter_class' [5890,5915]
===
match
---
atom_expr [21832,21840]
atom_expr [21832,21840]
===
match
---
operator: , [26852,26853]
operator: , [26852,26853]
===
match
---
parameters [36369,36386]
parameters [36369,36386]
===
match
---
number: 2 [36306,36307]
number: 2 [36306,36307]
===
match
---
operator: = [15479,15480]
operator: = [15479,15480]
===
match
---
trailer [26447,26458]
trailer [26447,26458]
===
match
---
simple_stmt [22133,22145]
simple_stmt [22133,22145]
===
match
---
return_stmt [3925,3959]
return_stmt [3925,3959]
===
match
---
name: os [26754,26756]
name: os [26754,26756]
===
match
---
string: """Historical getboolean""" [35576,35603]
string: """Historical getboolean""" [35576,35603]
===
match
---
name: os [32072,32074]
name: os [32072,32074]
===
match
---
name: file [33063,33067]
name: file [33063,33067]
===
match
---
string: 'core' [5397,5403]
string: 'core' [5397,5403]
===
match
---
operator: , [27737,27738]
operator: , [27737,27738]
===
match
---
arglist [38841,38856]
arglist [38845,38860]
===
match
---
fstring_expr [11936,11953]
fstring_expr [11936,11953]
===
match
---
arglist [13988,14016]
arglist [13988,14016]
===
match
---
operator: = [8358,8359]
operator: = [8358,8359]
===
match
---
simple_stmt [3497,3580]
simple_stmt [3497,3580]
===
match
---
suite [14921,15007]
suite [14921,15007]
===
match
---
operator: , [5716,5717]
operator: , [5716,5717]
===
match
---
simple_stmt [35207,35486]
simple_stmt [35207,35486]
===
match
---
atom [6415,6461]
atom [6415,6461]
===
match
---
name: option [14491,14497]
name: option [14491,14497]
===
match
---
name: remove_default [20169,20183]
name: remove_default [20169,20183]
===
match
---
arglist [20449,20464]
arglist [20449,20464]
===
match
---
name: deprecated_section [17210,17228]
name: deprecated_section [17210,17228]
===
match
---
atom_expr [34504,34531]
atom_expr [34504,34531]
===
match
---
atom_expr [25906,25919]
atom_expr [25906,25919]
===
match
---
operator: = [1567,1568]
operator: = [1567,1568]
===
match
---
string: """Historical remove_option""" [37655,37685]
string: """Historical remove_option""" [37659,37689]
===
match
---
param [18334,18342]
param [18334,18342]
===
match
---
operator: , [14002,14003]
operator: , [14002,14003]
===
match
---
simple_stmt [20612,20665]
simple_stmt [20612,20665]
===
match
---
operator: , [7038,7039]
operator: , [7038,7039]
===
match
---
name: airflow_defaults [20535,20551]
name: airflow_defaults [20535,20551]
===
match
---
name: Dict [24645,24649]
name: Dict [24645,24649]
===
match
---
atom_expr [32822,32855]
atom_expr [32822,32855]
===
match
---
trailer [28377,28379]
trailer [28377,28379]
===
match
---
parameters [18327,18357]
parameters [18327,18357]
===
match
---
trailer [25917,25919]
trailer [25917,25919]
===
match
---
trailer [2744,2755]
trailer [2744,2755]
===
match
---
expr_stmt [10119,10148]
expr_stmt [10119,10148]
===
match
---
atom_expr [38542,38820]
atom_expr [38546,38824]
===
match
---
argument [28418,28433]
argument [28418,28433]
===
match
---
operator: = [39531,39532]
operator: = [39535,39536]
===
match
---
atom_expr [16623,16677]
atom_expr [16623,16677]
===
match
---
simple_stmt [12651,12693]
simple_stmt [12651,12693]
===
match
---
operator: , [11342,11343]
operator: , [11342,11343]
===
match
---
param [19502,19512]
param [19502,19512]
===
match
---
string: "Accessing configuration method 'get' directly from the configuration module is " [35230,35311]
string: "Accessing configuration method 'get' directly from the configuration module is " [35230,35311]
===
match
---
suite [16048,16166]
suite [16048,16166]
===
match
---
trailer [30518,30526]
trailer [30518,30526]
===
match
---
trailer [12227,12236]
trailer [12227,12236]
===
match
---
name: Dict [20717,20721]
name: Dict [20717,20721]
===
match
---
arglist [19992,20024]
arglist [19992,20024]
===
match
---
operator: , [24653,24654]
operator: , [24653,24654]
===
match
---
operator: ** [36783,36785]
operator: ** [36783,36785]
===
match
---
operator: , [17451,17452]
operator: , [17451,17452]
===
match
---
name: os [32339,32341]
name: os [32339,32341]
===
match
---
trailer [33750,33754]
trailer [33750,33754]
===
match
---
name: _get_option_from_default_config [14674,14705]
name: _get_option_from_default_config [14674,14705]
===
match
---
name: _warn_deprecate [15585,15600]
name: _warn_deprecate [15585,15600]
===
match
---
dotted_name [1342,1361]
dotted_name [1342,1361]
===
match
---
atom_expr [16065,16135]
atom_expr [16065,16135]
===
match
---
name: pathlib [30876,30883]
name: pathlib [30876,30883]
===
match
---
name: section [27611,27618]
name: section [27611,27618]
===
match
---
if_stmt [12701,12944]
if_stmt [12701,12944]
===
match
---
operator: , [17699,17700]
operator: , [17699,17700]
===
match
---
name: args [36341,36345]
name: args [36341,36345]
===
match
---
name: section [19044,19051]
name: section [19044,19051]
===
match
---
name: os [12373,12375]
name: os [12373,12375]
===
match
---
trailer [32775,32798]
trailer [32775,32798]
===
match
---
funcdef [8531,9365]
funcdef [8531,9365]
===
match
---
name: isfile [32387,32393]
name: isfile [32387,32393]
===
match
---
string: 'scheduler' [7173,7184]
string: 'scheduler' [7173,7184]
===
match
---
trailer [32519,32523]
trailer [32519,32523]
===
match
---
arglist [34509,34530]
arglist [34509,34530]
===
match
---
trailer [11690,11815]
trailer [11690,11815]
===
match
---
raise_stmt [17758,17946]
raise_stmt [17758,17946]
===
match
---
string: """     * import secrets backend classes     * instantiate them and return them in a list     """ [39877,39974]
string: """     * import secrets backend classes     * instantiate them and return them in a list     """ [39881,39978]
===
match
---
string: 'Creating new Airflow config file in: %s' [32966,33007]
string: 'Creating new Airflow config file in: %s' [32966,33007]
===
match
---
name: option [15395,15401]
name: option [15395,15401]
===
match
---
argument [38848,38856]
argument [38852,38860]
===
match
---
operator: , [29274,29275]
operator: , [29274,29275]
===
match
---
name: section [26854,26861]
name: section [26854,26861]
===
match
---
name: pop [11226,11229]
name: pop [11226,11229]
===
match
---
parameters [19728,19751]
parameters [19728,19751]
===
match
---
operator: , [25020,25021]
operator: , [25020,25021]
===
match
---
simple_stmt [32864,32914]
simple_stmt [32864,32914]
===
match
---
name: deprecated_section [16642,16660]
name: deprecated_section [16642,16660]
===
match
---
suite [26227,26253]
suite [26227,26253]
===
match
---
name: airflow_defaults [14855,14871]
name: airflow_defaults [14855,14871]
===
match
---
arglist [16642,16676]
arglist [16642,16676]
===
match
---
operator: , [15087,15088]
operator: , [15087,15088]
===
match
---
name: filenames [19560,19569]
name: filenames [19560,19569]
===
match
---
trailer [36857,37136]
trailer [36857,37136]
===
match
---
operator: , [25595,25596]
operator: , [25595,25596]
===
match
---
parameters [8543,8549]
parameters [8543,8549]
===
match
---
name: deprecated_section [15990,16008]
name: deprecated_section [15990,16008]
===
match
---
if_stmt [27021,27196]
if_stmt [27021,27196]
===
match
---
atom_expr [21083,21125]
atom_expr [21083,21125]
===
match
---
strings [36457,36661]
strings [36457,36661]
===
match
---
trailer [13169,13171]
trailer [13169,13171]
===
match
---
name: opt [27767,27770]
name: opt [27767,27770]
===
match
---
name: section [20152,20159]
name: section [20152,20159]
===
match
---
name: mp_start_method [10557,10572]
name: mp_start_method [10557,10572]
===
match
---
trailer [27296,27302]
trailer [27296,27302]
===
match
---
name: display_source [26069,26083]
name: display_source [26069,26083]
===
match
---
operator: , [22763,22764]
operator: , [22763,22764]
===
match
---
suite [21871,22145]
suite [21871,22145]
===
match
---
simple_stmt [31837,31908]
simple_stmt [31837,31908]
===
match
---
atom [24694,24788]
atom [24694,24788]
===
match
---
simple_stmt [21527,21569]
simple_stmt [21527,21569]
===
match
---
trailer [21703,21708]
trailer [21703,21708]
===
match
---
atom_expr [2657,2819]
atom_expr [2657,2819]
===
match
---
operator: , [34384,34385]
operator: , [34384,34385]
===
match
---
suite [18358,18679]
suite [18358,18679]
===
match
---
string: """Historical getint""" [36406,36429]
string: """Historical getint""" [36406,36429]
===
match
---
funcdef [20128,20665]
funcdef [20128,20665]
===
match
---
atom [25498,25512]
atom [25498,25512]
===
match
---
expr_stmt [25558,25601]
expr_stmt [25558,25601]
===
match
---
name: key [14892,14895]
name: key [14892,14895]
===
match
---
name: os_environment [26768,26782]
name: os_environment [26768,26782]
===
match
---
name: deprecated_section [14243,14261]
name: deprecated_section [14243,14261]
===
match
---
suite [38081,38443]
suite [38085,38447]
===
match
---
name: templates_dir [3846,3859]
name: templates_dir [3846,3859]
===
match
---
trailer [3186,3191]
trailer [3186,3191]
===
match
---
atom [5574,5606]
atom [5574,5606]
===
match
---
with_item [3885,3915]
with_item [3885,3915]
===
match
---
suite [21809,21841]
suite [21809,21841]
===
match
---
operator: = [24692,24693]
operator: = [24692,24693]
===
match
---
expr_stmt [27279,27304]
expr_stmt [27279,27304]
===
match
---
operator: , [8812,8813]
operator: , [8812,8813]
===
match
---
operator: , [1833,1834]
operator: , [1833,1834]
===
match
---
name: stacklevel [35088,35098]
name: stacklevel [35088,35098]
===
match
---
dictorsetmaker [7607,7682]
dictorsetmaker [7607,7682]
===
match
---
name: section [19992,19999]
name: section [19992,19999]
===
match
---
name: k [28394,28395]
name: k [28394,28395]
===
match
---
name: AIRFLOW_CONFIG [30826,30840]
name: AIRFLOW_CONFIG [30826,30840]
===
match
---
atom [6136,6172]
atom [6136,6172]
===
match
---
expr_stmt [8336,8389]
expr_stmt [8336,8389]
===
match
---
name: key [13463,13466]
name: key [13463,13466]
===
match
---
name: encoding [3324,3332]
name: encoding [3324,3332]
===
match
---
name: AIRFLOW_HOME [34244,34256]
name: AIRFLOW_HOME [34244,34256]
===
match
---
name: self [22704,22708]
name: self [22704,22708]
===
match
---
name: items [8708,8713]
name: items [8708,8713]
===
match
---
name: sensitive_config_values [13124,13147]
name: sensitive_config_values [13124,13147]
===
match
---
import_name [786,797]
import_name [786,797]
===
match
---
suite [36401,36759]
suite [36401,36759]
===
match
---
suite [3916,3960]
suite [3916,3960]
===
match
---
arglist [17062,17074]
arglist [17062,17074]
===
match
---
comparison [22078,22107]
comparison [22078,22107]
===
match
---
trailer [13614,13637]
trailer [13614,13637]
===
match
---
atom [26703,26816]
atom [26703,26816]
===
match
---
operator: * [36742,36743]
operator: * [36742,36743]
===
match
---
trailer [14197,14226]
trailer [14197,14226]
===
match
---
return_stmt [3051,3095]
return_stmt [3051,3095]
===
match
---
name: args [35929,35933]
name: args [35929,35933]
===
match
---
fstring_expr [17853,17858]
fstring_expr [17853,17858]
===
match
---
operator: , [36307,36308]
operator: , [36307,36308]
===
match
---
dictorsetmaker [7485,7944]
dictorsetmaker [7485,7944]
===
match
---
name: args [8268,8272]
name: args [8268,8272]
===
match
---
atom_expr [25871,25939]
atom_expr [25871,25939]
===
match
---
string: "Accessing configuration method 'remove_option' directly from the configuration module is " [37713,37804]
string: "Accessing configuration method 'remove_option' directly from the configuration module is " [37717,37808]
===
match
---
return_stmt [2231,2250]
return_stmt [2231,2250]
===
match
---
name: module_loading [1526,1540]
name: module_loading [1526,1540]
===
match
---
if_stmt [14847,15199]
if_stmt [14847,15199]
===
match
---
simple_stmt [26307,26326]
simple_stmt [26307,26326]
===
match
---
atom_expr [22646,22668]
atom_expr [22646,22668]
===
match
---
trailer [38555,38820]
trailer [38559,38824]
===
match
---
simple_stmt [30339,30406]
simple_stmt [30339,30406]
===
match
---
operator: , [25184,25185]
operator: , [25184,25185]
===
match
---
name: typing [1275,1281]
name: typing [1275,1281]
===
match
---
operator: , [3156,3157]
operator: , [3156,3157]
===
match
---
name: open [33034,33038]
name: open [33034,33038]
===
match
---
argument [8996,9011]
argument [8996,9011]
===
match
---
name: str [20722,20725]
name: str [20722,20725]
===
match
---
comparison [2618,2641]
comparison [2618,2641]
===
match
---
fstring_string: Cannot execute  [2695,2710]
fstring_string: Cannot execute  [2695,2710]
===
match
---
operator: , [8938,8939]
operator: , [8938,8939]
===
match
---
number: 16 [32520,32522]
number: 16 [32520,32522]
===
match
---
trailer [20551,20562]
trailer [20551,20562]
===
match
---
operator: , [28295,28296]
operator: , [28295,28296]
===
match
---
trailer [32346,32353]
trailer [32346,32353]
===
match
---
name: DEFAULT_CONFIG [33104,33118]
name: DEFAULT_CONFIG [33104,33118]
===
match
---
trailer [22081,22087]
trailer [22081,22087]
===
match
---
operator: { [25928,25929]
operator: { [25928,25929]
===
match
---
trailer [20633,20647]
trailer [20633,20647]
===
match
---
atom_expr [3197,3222]
atom_expr [3197,3222]
===
match
---
name: deprecated_section [15255,15273]
name: deprecated_section [15255,15273]
===
match
---
atom_expr [30611,30639]
atom_expr [30611,30639]
===
match
---
name: deprecated_values [8639,8656]
name: deprecated_values [8639,8656]
===
match
---
string: r'airflow.providers.sendgrid.utils.emailer.send_email' [7840,7894]
string: r'airflow.providers.sendgrid.utils.emailer.send_email' [7840,7894]
===
match
---
simple_stmt [17654,17666]
simple_stmt [17654,17666]
===
match
---
trailer [19658,19660]
trailer [19658,19660]
===
match
---
operator: , [22007,22008]
operator: , [22007,22008]
===
match
---
atom_expr [26768,26806]
atom_expr [26768,26806]
===
match
---
return_stmt [3035,3046]
return_stmt [3035,3046]
===
match
---
fstring_string: ". [17929,17931]
fstring_string: ". [17929,17931]
===
match
---
string: 'core' [9939,9945]
string: 'core' [9939,9945]
===
match
---
simple_stmt [21695,21750]
simple_stmt [21695,21750]
===
match
---
arglist [31372,31452]
arglist [31372,31452]
===
match
---
operator: , [7214,7215]
operator: , [7214,7215]
===
match
---
operator: , [8315,8316]
operator: , [8315,8316]
===
match
---
fstring_expr [19387,19396]
fstring_expr [19387,19396]
===
match
---
comparison [21988,22016]
comparison [21988,22016]
===
match
---
suite [19752,20123]
suite [19752,20123]
===
match
---
name: _TEST_DAGS_FOLDER [31166,31183]
name: _TEST_DAGS_FOLDER [31166,31183]
===
match
---
operator: , [37981,37982]
operator: , [37985,37986]
===
match
---
name: args [35147,35151]
name: args [35147,35151]
===
match
---
string: "deprecated. Please access the configuration from the 'configuration.conf' object via " [37382,37469]
string: "deprecated. Please access the configuration from the 'configuration.conf' object via " [37386,37473]
===
match
---
param [18343,18347]
param [18343,18347]
===
match
---
operator: = [32426,32427]
operator: = [32426,32427]
===
match
---
trailer [21789,21791]
trailer [21789,21791]
===
match
---
funcdef [16888,17418]
funcdef [16888,17418]
===
match
---
operator: } [7294,7295]
operator: } [7294,7295]
===
match
---
name: deprecated_key [16750,16764]
name: deprecated_key [16750,16764]
===
match
---
name: str [23035,23038]
name: str [23035,23038]
===
match
---
operator: { [7475,7476]
operator: { [7475,7476]
===
match
---
trailer [27689,27691]
trailer [27689,27691]
===
match
---
fstring_string: " section.  [17877,17888]
fstring_string: " section.  [17877,17888]
===
match
---
name: val [18288,18291]
name: val [18288,18291]
===
match
---
operator: , [26111,26112]
operator: , [26111,26112]
===
match
---
operator: == [39165,39167]
operator: == [39169,39171]
===
match
---
trailer [22708,22718]
trailer [22708,22718]
===
match
---
trailer [26173,26189]
trailer [26173,26189]
===
match
---
param [15742,15757]
param [15742,15757]
===
match
---
trailer [13865,13874]
trailer [13865,13874]
===
match
---
trailer [31390,31395]
trailer [31390,31395]
===
match
---
trailer [26782,26793]
trailer [26782,26793]
===
match
---
name: conf [33364,33368]
name: conf [33364,33368]
===
match
---
string: 'remote_log_conn_id' [5294,5314]
string: 'remote_log_conn_id' [5294,5314]
===
match
---
simple_stmt [21630,21645]
simple_stmt [21630,21645]
===
match
---
arglist [30909,30936]
arglist [30909,30936]
===
match
---
simple_stmt [28925,29003]
simple_stmt [28925,29003]
===
match
---
string: 'flower_basic_auth' [4601,4620]
string: 'flower_basic_auth' [4601,4620]
===
match
---
atom [6056,6085]
atom [6056,6085]
===
match
---
trailer [39543,39639]
trailer [39547,39643]
===
match
---
fstring_string: Current value: " [17908,17924]
fstring_string: Current value: " [17908,17924]
===
match
---
operator: ** [37167,37169]
operator: ** [37171,37173]
===
match
---
argument [9292,9307]
argument [9292,9307]
===
match
---
suite [32083,32143]
suite [32083,32143]
===
match
---
atom_expr [10808,10839]
atom_expr [10808,10839]
===
match
---
if_stmt [2615,2820]
if_stmt [2615,2820]
===
match
---
atom_expr [40357,40386]
atom_expr [40361,40390]
===
match
---
name: configs [24684,24691]
name: configs [24684,24691]
===
match
---
name: args [35507,35511]
name: args [35507,35511]
===
match
---
atom [5282,5315]
atom [5282,5315]
===
match
---
name: __file__ [31421,31429]
name: __file__ [31421,31429]
===
match
---
name: BaseSecretsBackend [38896,38914]
name: BaseSecretsBackend [38900,38918]
===
match
---
atom_expr [20430,20465]
atom_expr [20430,20465]
===
match
---
return_stmt [25375,25396]
return_stmt [25375,25396]
===
match
---
atom_expr [28847,28883]
atom_expr [28847,28883]
===
match
---
atom_expr [24798,24885]
atom_expr [24798,24885]
===
match
---
atom_expr [2587,2608]
atom_expr [2587,2608]
===
match
---
trailer [17061,17075]
trailer [17061,17075]
===
match
---
trailer [22165,22170]
trailer [22165,22170]
===
match
---
name: args [38454,38458]
name: args [38458,38462]
===
match
---
simple_stmt [38086,38111]
simple_stmt [38090,38115]
===
match
---
atom_expr [33364,33403]
atom_expr [33364,33403]
===
match
---
return_stmt [37559,37598]
return_stmt [37563,37602]
===
match
---
trailer [2606,2608]
trailer [2606,2608]
===
match
---
operator: , [5637,5638]
operator: , [5637,5638]
===
match
---
testlist_comp [2523,2608]
testlist_comp [2523,2608]
===
match
---
operator: , [14241,14242]
operator: , [14241,14242]
===
match
---
name: section [29648,29655]
name: section [29648,29655]
===
match
---
simple_stmt [21302,21352]
simple_stmt [21302,21352]
===
match
---
return_stmt [18067,18082]
return_stmt [18067,18082]
===
match
---
name: fallback_key [13192,13204]
name: fallback_key [13192,13204]
===
match
---
decorator [28167,28181]
decorator [28167,28181]
===
match
---
subscriptlist [20733,20754]
subscriptlist [20733,20754]
===
match
---
expr_stmt [27674,27691]
expr_stmt [27674,27691]
===
match
---
operator: = [32223,32224]
operator: = [32223,32224]
===
match
---
trailer [17301,17317]
trailer [17301,17317]
===
match
---
trailer [26189,26203]
trailer [26189,26203]
===
match
---
simple_stmt [13320,13332]
simple_stmt [13320,13332]
===
match
---
operator: = [30256,30257]
operator: = [30256,30257]
===
match
---
simple_stmt [40312,40332]
simple_stmt [40316,40336]
===
match
---
operator: , [14580,14581]
operator: , [14580,14581]
===
match
---
operator: = [38811,38812]
operator: = [38815,38816]
===
match
---
name: strip [33164,33169]
name: strip [33164,33169]
===
match
---
name: self [8167,8171]
name: self [8167,8171]
===
match
---
subscriptlist [24650,24669]
subscriptlist [24650,24669]
===
match
---
if_stmt [13161,13312]
if_stmt [13161,13312]
===
match
---
name: deprecated_section [16100,16118]
name: deprecated_section [16100,16118]
===
match
---
fstring_string: " section.  [18240,18251]
fstring_string: " section.  [18240,18251]
===
match
---
trailer [30621,30639]
trailer [30621,30639]
===
match
---
trailer [37270,37275]
trailer [37274,37279]
===
match
---
trailer [8995,9044]
trailer [8995,9044]
===
match
---
argument [8814,8827]
argument [8814,8827]
===
match
---
atom [7742,7932]
atom [7742,7932]
===
match
---
name: self [8790,8794]
name: self [8790,8794]
===
match
---
operator: , [25847,25848]
operator: , [25847,25848]
===
match
---
name: command [2422,2429]
name: command [2422,2429]
===
match
---
testlist_comp [4591,4620]
testlist_comp [4591,4620]
===
match
---
operator: , [24777,24778]
operator: , [24777,24778]
===
match
---
name: deprecated_key [14546,14560]
name: deprecated_key [14546,14560]
===
match
---
operator: , [25200,25201]
operator: , [25200,25201]
===
match
---
name: AirflowConfigException [19284,19306]
name: AirflowConfigException [19284,19306]
===
match
---
operator: , [14425,14426]
operator: , [14425,14426]
===
match
---
name: has_option [13172,13182]
name: has_option [13172,13182]
===
match
---
trailer [17601,17603]
trailer [17601,17603]
===
match
---
argument [36347,36355]
argument [36347,36355]
===
match
---
arglist [13682,13703]
arglist [13682,13703]
===
match
---
name: expandvars [2157,2167]
name: expandvars [2157,2167]
===
match
---
suite [27226,27266]
suite [27226,27266]
===
match
---
suite [20758,22201]
suite [20758,22201]
===
match
---
name: warnoptions [1647,1658]
name: warnoptions [1647,1658]
===
match
---
trailer [29121,29126]
trailer [29121,29126]
===
match
---
funcdef [14735,15199]
funcdef [14735,15199]
===
match
---
name: warnings [11397,11405]
name: warnings [11397,11405]
===
match
---
operator: , [18341,18342]
operator: , [18341,18342]
===
match
---
import_as_names [1117,1168]
import_as_names [1117,1168]
===
match
---
parameters [16918,16974]
parameters [16918,16974]
===
match
---
name: option [17028,17034]
name: option [17028,17034]
===
match
---
atom_expr [17764,17946]
atom_expr [17764,17946]
===
match
---
atom_expr [15580,15650]
atom_expr [15580,15650]
===
match
---
operator: , [31890,31891]
operator: , [31890,31891]
===
match
---
name: opt [26534,26537]
name: opt [26534,26537]
===
match
---
name: display_source [28460,28474]
name: display_source [28460,28474]
===
match
---
trailer [30371,30375]
trailer [30371,30375]
===
match
---
return_stmt [31912,31946]
return_stmt [31912,31946]
===
match
---
atom_expr [2537,2561]
atom_expr [2537,2561]
===
match
---
operator: , [18702,18703]
operator: , [18702,18703]
===
match
---
trailer [25896,25920]
trailer [25896,25920]
===
match
---
operator: , [10888,10889]
operator: , [10888,10889]
===
match
---
operator: , [4546,4547]
operator: , [4546,4547]
===
match
---
trailer [13874,13880]
trailer [13874,13880]
===
match
---
name: get [16548,16551]
name: get [16548,16551]
===
match
---
name: environ [33672,33679]
name: environ [33672,33679]
===
match
---
string: '[{new_section}] - the old setting has been used, but please update your config.' [29914,29995]
string: '[{new_section}] - the old setting has been used, but please update your config.' [29914,29995]
===
match
---
parameters [3127,3143]
parameters [3127,3143]
===
match
---
atom_expr [21263,21288]
atom_expr [21263,21288]
===
match
---
simple_stmt [18067,18083]
simple_stmt [18067,18083]
===
match
---
simple_stmt [18745,19005]
simple_stmt [18745,19005]
===
match
---
name: os [31404,31406]
name: os [31404,31406]
===
match
---
string: 'fernet_key' [4533,4545]
string: 'fernet_key' [4533,4545]
===
match
---
trailer [32111,32142]
trailer [32111,32142]
===
match
---
fstring_string: Current value: " [18271,18287]
fstring_string: Current value: " [18271,18287]
===
match
---
suite [28444,28543]
suite [28444,28543]
===
match
---
atom [24756,24777]
atom [24756,24777]
===
match
---
name: deprecated_key [17352,17366]
name: deprecated_key [17352,17366]
===
match
---
name: val [17578,17581]
name: val [17578,17581]
===
match
---
return_stmt [13284,13311]
return_stmt [13284,13311]
===
match
---
trailer [22795,22797]
trailer [22795,22797]
===
match
---
name: old_section [30024,30035]
name: old_section [30024,30035]
===
match
---
operator: , [12003,12004]
operator: , [12003,12004]
===
match
---
trailer [26517,26519]
trailer [26517,26519]
===
match
---
operator: , [5185,5186]
operator: , [5185,5186]
===
match
---
expr_stmt [31553,31612]
expr_stmt [31553,31612]
===
match
---
comparison [14900,14920]
comparison [14900,14920]
===
match
---
string: '# ----------------------- TEMPLATE BEGINS HERE -----------------------' [32559,32631]
string: '# ----------------------- TEMPLATE BEGINS HERE -----------------------' [32559,32631]
===
match
---
operator: , [9266,9267]
operator: , [9266,9267]
===
match
---
operator: = [26434,26435]
operator: = [26434,26435]
===
match
---
param [25423,25428]
param [25423,25428]
===
match
---
string: 'logging' [5964,5973]
string: 'logging' [5964,5973]
===
match
---
operator: , [14989,14990]
operator: , [14989,14990]
===
match
---
number: 0 [22499,22500]
number: 0 [22499,22500]
===
match
---
param [18713,18717]
param [18713,18717]
===
match
---
name: open [34504,34508]
name: open [34504,34508]
===
match
---
with_item [32771,32806]
with_item [32771,32806]
===
match
---
trailer [33338,33343]
trailer [33338,33343]
===
match
---
name: mp_start_method [10723,10738]
name: mp_start_method [10723,10738]
===
match
---
trailer [36734,36741]
trailer [36734,36741]
===
match
---
arglist [12135,12147]
arglist [12135,12147]
===
match
---
arglist [31269,31289]
arglist [31269,31289]
===
match
---
trailer [20973,20985]
trailer [20973,20985]
===
match
---
operator: - [21641,21642]
operator: - [21641,21642]
===
match
---
trailer [40117,40124]
trailer [40121,40128]
===
match
---
arglist [33380,33402]
arglist [33380,33402]
===
match
---
name: is_executor_without_sqlite_support [9816,9850]
name: is_executor_without_sqlite_support [9816,9850]
===
match
---
name: kwargs [18720,18726]
name: kwargs [18720,18726]
===
match
---
operator: , [5845,5846]
operator: , [5845,5846]
===
match
---
funcdef [3582,3960]
funcdef [3582,3960]
===
match
---
operator: , [14890,14891]
operator: , [14890,14891]
===
match
---
atom_expr [39139,39164]
atom_expr [39143,39168]
===
match
---
string: "deprecated. Please access the configuration from the 'configuration.conf' object via " [36964,37051]
string: "deprecated. Please access the configuration from the 'configuration.conf' object via " [36964,37051]
===
match
---
suite [32952,33196]
suite [32952,33196]
===
match
---
trailer [2400,2500]
trailer [2400,2500]
===
match
---
operator: , [37107,37108]
operator: , [37107,37108]
===
match
---
string: 'parsing_processes' [7238,7257]
string: 'parsing_processes' [7238,7257]
===
match
---
operator: ** [35153,35155]
operator: ** [35153,35155]
===
match
---
operator: = [34132,34133]
operator: = [34132,34133]
===
match
---
import_name [798,812]
import_name [798,812]
===
match
---
atom_expr [36730,36758]
atom_expr [36730,36758]
===
match
---
string: '_cmd' [13039,13045]
string: '_cmd' [13039,13045]
===
match
---
operator: , [14560,14561]
operator: , [14560,14561]
===
match
---
simple_stmt [35996,36022]
simple_stmt [35996,36022]
===
match
---
string: 'metrics' [6805,6814]
string: 'metrics' [6805,6814]
===
match
---
name: val [18002,18005]
name: val [18002,18005]
===
match
---
name: config_sources [25429,25443]
name: config_sources [25429,25443]
===
match
---
operator: { [15160,15161]
operator: { [15160,15161]
===
match
---
if_stmt [14604,14653]
if_stmt [14604,14653]
===
match
---
simple_stmt [21139,21200]
simple_stmt [21139,21200]
===
match
---
name: config_key [2883,2893]
name: config_key [2883,2893]
===
match
---
testlist_comp [31864,31883]
testlist_comp [31864,31883]
===
match
---
trailer [7531,7539]
trailer [7531,7539]
===
match
---
and_test [20530,20598]
and_test [20530,20598]
===
match
---
name: DeprecationWarning [36267,36285]
name: DeprecationWarning [36267,36285]
===
match
---
operator: = [38392,38393]
operator: = [38396,38397]
===
match
---
name: DEFAULT_WEBSERVER_CONFIG [34408,34432]
name: DEFAULT_WEBSERVER_CONFIG [34408,34432]
===
match
---
operator: { [7493,7494]
operator: { [7493,7494]
===
match
---
name: key [13543,13546]
name: key [13543,13546]
===
match
---
fstring_string: " key in " [18590,18600]
fstring_string: " key in " [18590,18600]
===
match
---
operator: = [3332,3333]
operator: = [3332,3333]
===
match
---
if_stmt [39450,39792]
if_stmt [39454,39796]
===
match
---
string: '__' [26883,26887]
string: '__' [26883,26887]
===
match
---
trailer [8707,8713]
trailer [8707,8713]
===
match
---
arglist [9118,9308]
arglist [9118,9308]
===
match
---
suite [28315,28543]
suite [28315,28543]
===
match
---
simple_stmt [16174,16186]
simple_stmt [16174,16186]
===
match
---
name: section [29262,29269]
name: section [29262,29269]
===
match
---
trailer [38425,38442]
trailer [38429,38446]
===
match
---
expr_stmt [33253,33332]
expr_stmt [33253,33332]
===
match
---
simple_stmt [27279,27305]
simple_stmt [27279,27305]
===
match
---
name: section [11895,11902]
name: section [11895,11902]
===
match
---
operator: , [8686,8687]
operator: , [8686,8687]
===
match
---
operator: = [9122,9123]
operator: = [9122,9123]
===
match
---
operator: = [19559,19560]
operator: = [19559,19560]
===
match
---
operator: , [15633,15634]
operator: , [15633,15634]
===
match
---
name: DEFAULT_WEBSERVER_CONFIG [34560,34584]
name: DEFAULT_WEBSERVER_CONFIG [34560,34584]
===
match
---
param [25445,25463]
param [25445,25463]
===
match
---
param [22958,22976]
param [22958,22976]
===
match
---
if_stmt [25614,26001]
if_stmt [25614,26001]
===
match
---
argument [37535,37547]
argument [37539,37551]
===
match
---
name: version [9292,9299]
name: version [9292,9299]
===
match
---
fstring [17804,17889]
fstring [17804,17889]
===
match
---
trailer [39851,39871]
trailer [39855,39875]
===
match
---
name: get [9759,9762]
name: get [9759,9762]
===
match
---
string: 'Creating new Airflow config file for unit tests in: %s' [32686,32742]
string: 'Creating new Airflow config file for unit tests in: %s' [32686,32742]
===
match
---
name: section [8996,9003]
name: section [8996,9003]
===
match
---
operator: = [3831,3832]
operator: = [3831,3832]
===
match
---
expr_stmt [9730,9790]
expr_stmt [9730,9790]
===
match
---
name: self [11999,12003]
name: self [11999,12003]
===
match
---
name: _write_section [22605,22619]
name: _write_section [22605,22619]
===
match
---
string: 'mp_start_method' [10380,10397]
string: 'mp_start_method' [10380,10397]
===
match
---
name: section [8799,8806]
name: section [8799,8806]
===
match
---
arglist [37713,37982]
arglist [37717,37986]
===
match
---
arglist [19044,19078]
arglist [19044,19078]
===
match
---
simple_stmt [21059,21071]
simple_stmt [21059,21071]
===
match
---
name: category [1706,1714]
name: category [1706,1714]
===
match
---
simple_stmt [39319,39370]
simple_stmt [39323,39374]
===
match
---
operator: , [16098,16099]
operator: , [16098,16099]
===
match
---
trailer [40303,40305]
trailer [40307,40309]
===
match
---
operator: , [3795,3796]
operator: , [3795,3796]
===
match
---
operator: ** [38026,38028]
operator: ** [38030,38032]
===
match
---
atom_expr [30807,30825]
atom_expr [30807,30825]
===
match
---
name: kwargs [18033,18039]
name: kwargs [18033,18039]
===
match
---
operator: } [19376,19377]
operator: } [19376,19377]
===
match
---
atom_expr [40230,40255]
atom_expr [40234,40259]
===
match
---
operator: ** [35935,35937]
operator: ** [35935,35937]
===
match
---
dotted_name [1382,1400]
dotted_name [1382,1400]
===
match
---
name: as_dict [38042,38049]
name: as_dict [38046,38053]
===
match
---
funcdef [9370,10858]
funcdef [9370,10858]
===
match
---
comparison [17261,17279]
comparison [17261,17279]
===
match
---
atom_expr [24720,24741]
atom_expr [24720,24741]
===
match
---
param [22226,22254]
param [22226,22254]
===
match
---
trailer [14226,14284]
trailer [14226,14284]
===
match
---
trailer [20647,20664]
trailer [20647,20664]
===
match
---
name: section [15858,15865]
name: section [15858,15865]
===
match
---
fstring_expr [21389,21406]
fstring_expr [21389,21406]
===
match
---
trailer [34331,34336]
trailer [34331,34336]
===
match
---
trailer [40276,40283]
trailer [40280,40287]
===
match
---
operator: , [7551,7552]
operator: , [7551,7552]
===
match
---
name: args [38051,38055]
name: args [38055,38059]
===
match
---
operator: = [22046,22047]
operator: = [22046,22047]
===
match
---
arglist [11230,11243]
arglist [11230,11243]
===
match
---
trailer [13983,13987]
trailer [13983,13987]
===
match
---
name: deprecated_name [30084,30099]
name: deprecated_name [30084,30099]
===
match
---
trailer [28533,28536]
trailer [28533,28536]
===
match
---
operator: { [17868,17869]
operator: { [17868,17869]
===
match
---
name: option [20657,20663]
name: option [20657,20663]
===
match
---
trailer [15584,15600]
trailer [15584,15600]
===
match
---
operator: = [9033,9034]
operator: = [9033,9034]
===
match
---
trailer [31116,31126]
trailer [31116,31126]
===
match
---
operator: , [32124,32125]
operator: , [32124,32125]
===
match
---
name: _get_env_var_option [11979,11998]
name: _get_env_var_option [11979,11998]
===
match
---
name: section [13615,13622]
name: section [13615,13622]
===
match
---
operator: = [34070,34071]
operator: = [34070,34071]
===
match
---
name: section [39570,39577]
name: section [39574,39581]
===
match
---
fstring_start: f' [17906,17908]
fstring_start: f' [17906,17908]
===
match
---
arglist [15858,15870]
arglist [15858,15870]
===
match
---
name: args [36743,36747]
name: args [36743,36747]
===
match
---
arglist [2410,2494]
arglist [2410,2494]
===
match
---
simple_stmt [1325,1337]
simple_stmt [1325,1337]
===
match
---
suite [39473,39792]
suite [39477,39796]
===
match
---
operator: , [20748,20749]
operator: , [20748,20749]
===
match
---
name: _section [21226,21234]
name: _section [21226,21234]
===
match
---
strings [34826,35050]
strings [34826,35050]
===
match
---
atom_expr [10356,10398]
atom_expr [10356,10398]
===
match
---
string: 'secret' [25770,25778]
string: 'secret' [25770,25778]
===
match
---
param [29262,29270]
param [29262,29270]
===
match
---
name: kwargs [37628,37634]
name: kwargs [37632,37638]
===
match
---
name: config_file [3345,3356]
name: config_file [3345,3356]
===
match
---
expr_stmt [34119,34166]
expr_stmt [34119,34166]
===
match
---
string: 'remote_log_conn_id' [5326,5346]
string: 'remote_log_conn_id' [5326,5346]
===
match
---
name: self [8500,8504]
name: self [8500,8504]
===
match
---
operator: ** [17510,17512]
operator: ** [17510,17512]
===
match
---
name: read_string [28835,28846]
name: read_string [28835,28846]
===
match
---
name: staticmethod [11294,11306]
name: staticmethod [11294,11306]
===
match
---
trailer [9934,9938]
trailer [9934,9938]
===
match
---
atom [5918,5953]
atom [5918,5953]
===
match
---
trailer [19262,19265]
trailer [19262,19265]
===
match
---
trailer [21493,21509]
trailer [21493,21509]
===
match
---
name: section [11937,11944]
name: section [11937,11944]
===
match
---
name: __file__ [31117,31125]
name: __file__ [31117,31125]
===
match
---
strings [36049,36257]
strings [36049,36257]
===
match
---
name: os [3770,3772]
name: os [3770,3772]
===
match
---
operator: = [11171,11172]
operator: = [11171,11172]
===
match
---
except_clause [21946,21963]
except_clause [21946,21963]
===
match
---
argument [16566,16574]
argument [16566,16574]
===
match
---
operator: = [9358,9359]
operator: = [9358,9359]
===
match
---
name: items [22661,22666]
name: items [22661,22666]
===
match
---
operator: } [17928,17929]
operator: } [17928,17929]
===
match
---
name: is_sqlite [9730,9739]
name: is_sqlite [9730,9739]
===
match
---
name: path [2133,2137]
name: path [2133,2137]
===
match
---
parameters [18697,18727]
parameters [18697,18727]
===
match
---
name: exists [31159,31165]
name: exists [31159,31165]
===
match
---
atom_expr [8923,8954]
atom_expr [8923,8954]
===
match
---
trailer [9758,9762]
trailer [9758,9762]
===
match
---
trailer [15369,15383]
trailer [15369,15383]
===
match
---
atom_expr [39186,39215]
atom_expr [39190,39219]
===
match
---
operator: , [9011,9012]
operator: , [9011,9012]
===
match
---
operator: } [2718,2719]
operator: } [2718,2719]
===
match
---
testlist_comp [6365,6412]
testlist_comp [6365,6412]
===
match
---
string: 'core' [9763,9769]
string: 'core' [9763,9769]
===
match
---
name: log [32677,32680]
name: log [32677,32680]
===
match
---
name: str [24665,24668]
name: str [24665,24668]
===
match
---
testlist_comp [6472,6500]
testlist_comp [6472,6500]
===
match
---
name: name [11338,11342]
name: name [11338,11342]
===
match
---
name: self [15481,15485]
name: self [15481,15485]
===
match
---
trailer [32680,32685]
trailer [32680,32685]
===
match
---
operator: , [8736,8737]
operator: , [8736,8737]
===
match
---
operator: { [10321,10322]
operator: { [10321,10322]
===
match
---
name: backend_list [40264,40276]
name: backend_list [40268,40280]
===
match
---
if_stmt [20962,21071]
if_stmt [20962,21071]
===
match
---
operator: , [11001,11002]
operator: , [11001,11002]
===
match
---
argument [29640,29655]
argument [29640,29655]
===
match
---
operator: , [25344,25345]
operator: , [25344,25345]
===
match
---
name: format [29996,30002]
name: format [29996,30002]
===
match
---
name: self [14956,14960]
name: self [14956,14960]
===
match
---
string: 'logging' [5283,5292]
string: 'logging' [5283,5292]
===
match
---
string: 'logging_level' [5548,5563]
string: 'logging_level' [5548,5563]
===
match
---
name: encoding [19513,19521]
name: encoding [19513,19521]
===
match
---
simple_stmt [2115,2183]
simple_stmt [2115,2183]
===
match
---
trailer [20448,20465]
trailer [20448,20465]
===
match
---
name: section [20501,20508]
name: section [20501,20508]
===
match
---
operator: , [6481,6482]
operator: , [6481,6482]
===
match
---
string: 'statsd_on' [6552,6563]
string: 'statsd_on' [6552,6563]
===
match
---
operator: , [15865,15866]
operator: , [15865,15866]
===
match
---
operator: , [17330,17331]
operator: , [17330,17331]
===
match
---
fstring_string: " section.  [18609,18620]
fstring_string: " section.  [18609,18620]
===
match
---
name: path [31259,31263]
name: path [31259,31263]
===
match
---
suite [25545,26001]
suite [25545,26001]
===
match
---
arglist [28357,28379]
arglist [28357,28379]
===
match
---
name: open [3308,3312]
name: open [3308,3312]
===
match
---
trailer [16551,16575]
trailer [16551,16575]
===
match
---
name: default_config [33280,33294]
name: default_config [33280,33294]
===
match
---
arglist [32112,32141]
arglist [32112,32141]
===
match
---
name: msg [33409,33412]
name: msg [33409,33412]
===
match
---
simple_stmt [3405,3497]
simple_stmt [3405,3497]
===
match
---
name: Popen [2395,2400]
name: Popen [2395,2400]
===
match
---
testlist_comp [7173,7213]
testlist_comp [7173,7213]
===
match
---
number: 0 [22558,22559]
number: 0 [22558,22559]
===
match
---
exprlist [31889,31893]
exprlist [31889,31893]
===
match
---
operator: , [14266,14267]
operator: , [14266,14267]
===
match
---
operator: , [28286,28287]
operator: , [28286,28287]
===
match
---
argument [1799,1833]
argument [1799,1833]
===
match
---
name: key [13033,13036]
name: key [13033,13036]
===
match
---
operator: = [14034,14035]
operator: = [14034,14035]
===
match
---
name: key [12458,12461]
name: key [12458,12461]
===
match
---
argument [9247,9266]
argument [9247,9266]
===
match
---
name: self [21162,21166]
name: self [21162,21166]
===
match
---
atom_expr [30843,30875]
atom_expr [30843,30875]
===
match
---
testlist_comp [5216,5243]
testlist_comp [5216,5243]
===
match
---
testlist_comp [12449,12461]
testlist_comp [12449,12461]
===
match
---
simple_stmt [33409,33644]
simple_stmt [33409,33644]
===
match
---
operator: = [9256,9257]
operator: = [9256,9257]
===
match
---
name: env_var [21475,21482]
name: env_var [21475,21482]
===
match
---
name: join [31058,31062]
name: join [31058,31062]
===
match
---
name: DeprecationWarning [35853,35871]
name: DeprecationWarning [35853,35871]
===
match
---
atom_expr [3260,3298]
atom_expr [3260,3298]
===
match
---
name: sections [27964,27972]
name: sections [27964,27972]
===
match
---
trailer [27750,27752]
trailer [27750,27752]
===
match
---
decorated [28167,28543]
decorated [28167,28543]
===
match
---
operator: , [7673,7674]
operator: , [7673,7674]
===
match
---
name: log [28925,28928]
name: log [28925,28928]
===
match
---
suite [16975,17418]
suite [16975,17418]
===
match
---
param [26050,26068]
param [26050,26068]
===
match
---
operator: , [5953,5954]
operator: , [5953,5954]
===
match
---
name: environ [11218,11225]
name: environ [11218,11225]
===
match
---
name: environ [30614,30621]
name: environ [30614,30621]
===
match
---
param [35547,35555]
param [35547,35555]
===
match
---
name: getLogger [1577,1586]
name: getLogger [1577,1586]
===
match
---
suite [31185,31227]
suite [31185,31227]
===
match
---
name: base64 [934,940]
name: base64 [934,940]
===
match
---
arglist [1781,1851]
arglist [1781,1851]
===
match
---
operator: = [32557,32558]
operator: = [32557,32558]
===
match
---
name: output [2783,2789]
name: output [2783,2789]
===
match
---
return_stmt [17384,17397]
return_stmt [17384,17397]
===
match
---
name: float [21919,21924]
name: float [21919,21924]
===
match
---
expr_stmt [28492,28516]
expr_stmt [28492,28516]
===
match
---
name: secrets_backend_cls [39737,39756]
name: secrets_backend_cls [39741,39760]
===
match
---
suite [13380,13800]
suite [13380,13800]
===
match
---
name: version [1200,1207]
name: version [1200,1207]
===
match
---
atom_expr [8500,8517]
atom_expr [8500,8517]
===
match
---
operator: , [19500,19501]
operator: , [19500,19501]
===
match
---
simple_stmt [29368,29756]
simple_stmt [29368,29756]
===
match
---
simple_stmt [14351,14441]
simple_stmt [14351,14441]
===
match
---
atom_expr [19253,19265]
atom_expr [19253,19265]
===
match
---
atom_expr [38891,38915]
atom_expr [38895,38919]
===
match
---
name: getimport [18688,18697]
name: getimport [18688,18697]
===
match
---
name: ConfigParser [8360,8372]
name: ConfigParser [8360,8372]
===
match
---
name: load_test_config [35117,35133]
name: load_test_config [35117,35133]
===
match
---
fstring_string: . Error code is:  [2719,2736]
fstring_string: . Error code is:  [2719,2736]
===
match
---
name: TEST_PLUGINS_FOLDER [31500,31519]
name: TEST_PLUGINS_FOLDER [31500,31519]
===
match
---
string: 'colored_console_log' [5738,5759]
string: 'colored_console_log' [5738,5759]
===
match
---
trailer [21340,21349]
trailer [21340,21349]
===
match
---
name: _get_environment_variables [16892,16918]
name: _get_environment_variables [16892,16918]
===
match
---
name: self [10997,11001]
name: self [10997,11001]
===
match
---
string: '%' [26448,26451]
string: '%' [26448,26451]
===
match
---
name: expand_env_var [16525,16539]
name: expand_env_var [16525,16539]
===
match
---
simple_stmt [9340,9365]
simple_stmt [9340,9365]
===
match
---
operator: , [15740,15741]
operator: , [15740,15741]
===
match
---
trailer [10646,10857]
trailer [10646,10857]
===
match
---
name: v [31892,31893]
name: v [31892,31893]
===
match
---
trailer [35220,35485]
trailer [35220,35485]
===
match
---
operator: { [17924,17925]
operator: { [17924,17925]
===
match
---
name: path [32382,32386]
name: path [32382,32386]
===
match
---
operator: , [4747,4748]
operator: , [4747,4748]
===
match
---
operator: } [9958,9959]
operator: } [9958,9959]
===
match
---
operator: , [6105,6106]
operator: , [6105,6106]
===
match
---
string: 'core' [5179,5185]
string: 'core' [5179,5185]
===
match
---
operator: , [11366,11367]
operator: , [11366,11367]
===
match
---
param [22222,22225]
param [22222,22225]
===
match
---
suite [26413,26459]
suite [26413,26459]
===
match
---
trailer [32393,32409]
trailer [32393,32409]
===
match
---
name: getboolean [17427,17437]
name: getboolean [17427,17437]
===
match
---
operator: = [22916,22917]
operator: = [22916,22917]
===
match
---
expr_stmt [34408,34494]
expr_stmt [34408,34494]
===
match
---
number: 2 [37128,37129]
number: 2 [37128,37129]
===
match
---
return_stmt [30589,30640]
return_stmt [30589,30640]
===
match
---
name: option [17391,17397]
name: option [17391,17397]
===
match
---
atom_expr [39561,39625]
atom_expr [39565,39629]
===
match
---
trailer [17528,17534]
trailer [17528,17534]
===
match
---
parameters [22826,23011]
parameters [22826,23011]
===
match
---
string: 'secret_key' [4749,4761]
string: 'secret_key' [4749,4761]
===
match
---
simple_stmt [12512,12556]
simple_stmt [12512,12556]
===
match
---
dictorsetmaker [25929,25937]
dictorsetmaker [25929,25937]
===
match
---
name: os [2130,2132]
name: os [2130,2132]
===
match
---
param [3128,3142]
param [3128,3142]
===
match
---
if_stmt [12157,12238]
if_stmt [12157,12238]
===
match
---
atom [13988,14002]
atom [13988,14002]
===
match
---
trailer [14882,14896]
trailer [14882,14896]
===
match
---
operator: , [7692,7693]
operator: , [7692,7693]
===
match
---
name: display_source [28102,28116]
name: display_source [28102,28116]
===
match
---
string: 'colored_log_format' [5815,5835]
string: 'colored_log_format' [5815,5835]
===
match
---
name: deprecated_key [14068,14082]
name: deprecated_key [14068,14082]
===
match
---
name: kwargs [17512,17518]
name: kwargs [17512,17518]
===
match
---
string: 'dags' [31283,31289]
string: 'dags' [31283,31289]
===
match
---
name: deprecated_key [16662,16676]
name: deprecated_key [16662,16676]
===
match
---
suite [27975,28162]
suite [27975,28162]
===
match
---
name: default_config [8246,8260]
name: default_config [8246,8260]
===
match
---
funcdef [19487,19590]
funcdef [19487,19590]
===
match
---
string: '_secret' [25990,25999]
string: '_secret' [25990,25999]
===
match
---
name: secrets_backend_cls [40284,40303]
name: secrets_backend_cls [40288,40307]
===
match
---
suite [32410,32459]
suite [32410,32459]
===
match
---
trailer [32928,32935]
trailer [32928,32935]
===
match
---
simple_stmt [17406,17418]
simple_stmt [17406,17418]
===
match
---
suite [17641,17666]
suite [17641,17666]
===
match
---
file_input [786,40404]
file_input [786,40408]
===
match
---
operator: , [35151,35152]
operator: , [35151,35152]
===
match
---
trailer [29015,29027]
trailer [29015,29027]
===
match
---
name: decoder [1239,1246]
name: decoder [1239,1246]
===
match
---
name: split [17582,17587]
name: split [17582,17587]
===
match
---
string: 'true' [22009,22015]
string: 'true' [22009,22015]
===
match
---
string: 'core' [5110,5116]
string: 'core' [5110,5116]
===
match
---
name: interpolated [2287,2299]
name: interpolated [2287,2299]
===
match
---
argument [38026,38034]
argument [38030,38038]
===
match
---
trailer [31403,31431]
trailer [31403,31431]
===
match
---
and_test [27024,27092]
and_test [27024,27092]
===
match
---
atom [6095,6134]
atom [6095,6134]
===
match
---
name: AirflowConfigException [18128,18150]
name: AirflowConfigException [18128,18150]
===
match
---
suite [20190,20665]
suite [20190,20665]
===
match
---
simple_stmt [36844,37137]
simple_stmt [36844,37137]
===
match
---
name: conf [38832,38836]
name: conf [38836,38840]
===
match
---
name: kwargs [14722,14728]
name: kwargs [14722,14728]
===
match
---
operator: < [10202,10203]
operator: < [10202,10203]
===
match
---
operator: * [37582,37583]
operator: * [37586,37587]
===
match
---
name: key [19061,19064]
name: key [19061,19064]
===
match
---
string: "deprecated. Please access the configuration from the 'configuration.conf' object via " [38655,38742]
string: "deprecated. Please access the configuration from the 'configuration.conf' object via " [38659,38746]
===
match
---
operator: , [32792,32793]
operator: , [32792,32793]
===
match
---
name: current_value [11353,11366]
name: current_value [11353,11366]
===
match
---
trailer [14520,14545]
trailer [14520,14545]
===
match
---
name: deprecated_section [16730,16748]
name: deprecated_section [16730,16748]
===
match
---
trailer [22498,22501]
trailer [22498,22501]
===
match
---
for_stmt [27892,28162]
for_stmt [27892,28162]
===
match
---
simple_stmt [15828,15872]
simple_stmt [15828,15872]
===
match
---
simple_stmt [32486,32541]
simple_stmt [32486,32541]
===
match
---
operator: , [2454,2455]
operator: , [2454,2455]
===
match
---
fstring_start: f' [18168,18170]
fstring_start: f' [18168,18170]
===
match
---
string: 'The {old} option in [{section}] has been renamed to {new} - the old ' [29399,29469]
string: 'The {old} option in [{section}] has been renamed to {new} - the old ' [29399,29469]
===
match
---
trailer [15600,15650]
trailer [15600,15650]
===
match
---
atom_expr [21588,21608]
atom_expr [21588,21608]
===
match
---
name: shlex [878,883]
name: shlex [878,883]
===
match
---
name: section [13852,13859]
name: section [13852,13859]
===
match
---
trailer [32960,32965]
trailer [32960,32965]
===
match
---
name: secrets [1444,1451]
name: secrets [1444,1451]
===
match
---
name: section [15370,15377]
name: section [15370,15377]
===
match
---
name: self [13813,13817]
name: self [13813,13817]
===
match
---
name: locals [31875,31881]
name: locals [31875,31881]
===
match
---
name: warn [34184,34188]
name: warn [34184,34188]
===
match
---
name: cfg [32875,32878]
name: cfg [32875,32878]
===
match
---
string: '0' [17701,17704]
string: '0' [17701,17704]
===
match
---
name: new_value [9024,9033]
name: new_value [9024,9033]
===
match
---
string: 'f' [17687,17690]
string: 'f' [17687,17690]
===
match
---
name: write [32869,32874]
name: write [32869,32874]
===
match
---
trailer [8340,8357]
trailer [8340,8357]
===
match
---
name: open [32771,32775]
name: open [32771,32775]
===
match
---
atom_expr [25516,25544]
atom_expr [25516,25544]
===
match
---
arglist [26497,26519]
arglist [26497,26519]
===
match
---
string: 'smtp' [4701,4707]
string: 'smtp' [4701,4707]
===
match
---
name: section [12005,12012]
name: section [12005,12012]
===
match
---
expr_stmt [2374,2500]
expr_stmt [2374,2500]
===
match
---
name: section [11344,11351]
name: section [11344,11351]
===
match
---
return_stmt [17406,17417]
return_stmt [17406,17417]
===
match
---
exprlist [21763,21771]
exprlist [21763,21771]
===
match
---
name: self [10430,10434]
name: self [10430,10434]
===
match
---
name: environ [32075,32082]
name: environ [32075,32082]
===
match
---
name: key [22166,22169]
name: key [22166,22169]
===
match
---
atom_expr [28830,28884]
atom_expr [28830,28884]
===
match
---
name: AirflowConfigException [1408,1430]
name: AirflowConfigException [1408,1430]
===
match
---
trailer [16628,16630]
trailer [16628,16630]
===
match
---
name: AirflowConfigParser [3968,3987]
name: AirflowConfigParser [3968,3987]
===
match
---
trailer [8638,8656]
trailer [8638,8656]
===
match
---
trailer [8929,8954]
trailer [8929,8954]
===
match
---
arglist [21549,21567]
arglist [21549,21567]
===
match
---
operator: , [26032,26033]
operator: , [26032,26033]
===
match
---
name: env_var_cmd [12358,12369]
name: env_var_cmd [12358,12369]
===
match
---
atom_expr [40284,40305]
atom_expr [40288,40309]
===
match
---
simple_stmt [27167,27196]
simple_stmt [27167,27196]
===
match
---
argument [1735,1751]
argument [1735,1751]
===
match
---
suite [30527,30585]
suite [30527,30585]
===
match
---
string: '_secret' [13469,13478]
string: '_secret' [13469,13478]
===
match
---
operator: , [39428,39429]
operator: , [39432,39433]
===
match
---
trailer [29048,29061]
trailer [29048,29061]
===
match
---
param [12005,12013]
param [12005,12013]
===
match
---
atom_expr [24987,25061]
atom_expr [24987,25061]
===
match
---
name: search [10938,10944]
name: search [10938,10944]
===
match
---
name: DEFAULT_CONFIG [28868,28882]
name: DEFAULT_CONFIG [28868,28882]
===
match
---
atom [5762,5793]
atom [5762,5793]
===
match
---
operator: ** [19070,19072]
operator: ** [19070,19072]
===
match
---
operator: , [31432,31433]
operator: , [31432,31433]
===
match
---
funcdef [18684,19482]
funcdef [18684,19482]
===
match
---
atom_expr [2972,2999]
atom_expr [2972,2999]
===
match
---
simple_stmt [2076,2091]
simple_stmt [2076,2091]
===
match
---
simple_stmt [36812,36840]
simple_stmt [36812,36840]
===
match
---
tfpdef [8173,8187]
tfpdef [8173,8187]
===
match
---
name: args [8311,8315]
name: args [8311,8315]
===
match
---
suite [36807,37177]
suite [36807,37181]
===
match
---
name: warnings [34803,34811]
name: warnings [34803,34811]
===
match
---
simple_stmt [14507,14596]
simple_stmt [14507,14596]
===
match
---
atom_expr [22704,22718]
atom_expr [22704,22718]
===
match
---
expr_stmt [28324,28380]
expr_stmt [28324,28380]
===
match
---
atom_expr [40026,40053]
atom_expr [40030,40057]
===
match
---
name: kwargs [35155,35161]
name: kwargs [35155,35161]
===
match
---
name: key [21636,21639]
name: key [21636,21639]
===
match
---
operator: ** [35513,35515]
operator: ** [35513,35515]
===
match
---
name: airflow_home [30431,30443]
name: airflow_home [30431,30443]
===
match
---
atom_expr [37262,37554]
atom_expr [37266,37558]
===
match
---
trailer [16811,16815]
trailer [16811,16815]
===
match
---
name: section [17496,17503]
name: section [17496,17503]
===
match
---
trailer [20985,20994]
trailer [20985,20994]
===
match
---
name: msg [34189,34192]
name: msg [34189,34192]
===
match
---
name: secrets_backend_cls [39453,39472]
name: secrets_backend_cls [39457,39476]
===
match
---
trailer [34658,34660]
trailer [34658,34660]
===
match
---
atom_expr [2439,2454]
atom_expr [2439,2454]
===
match
---
atom_expr [31100,31126]
atom_expr [31100,31126]
===
match
---
string: "'conf.getint'" [36646,36661]
string: "'conf.getint'" [36646,36661]
===
match
---
name: getboolean [34595,34605]
name: getboolean [34595,34605]
===
match
---
simple_stmt [15903,15917]
simple_stmt [15903,15917]
===
match
---
trailer [21442,21450]
trailer [21442,21450]
===
match
---
suite [29355,29756]
suite [29355,29756]
===
match
---
atom [5317,5347]
atom [5317,5347]
===
match
---
fstring [10284,10342]
fstring [10284,10342]
===
match
---
name: key [21745,21748]
name: key [21745,21748]
===
match
---
expr_stmt [21695,21749]
expr_stmt [21695,21749]
===
match
---
name: k [31889,31890]
name: k [31889,31890]
===
match
---
name: environ [12220,12227]
name: environ [12220,12227]
===
match
---
and_test [20965,21045]
and_test [20965,21045]
===
match
---
name: key [26113,26116]
name: key [26113,26116]
===
match
---
name: opt [27167,27170]
name: opt [27167,27170]
===
match
---
name: kwargs [14793,14799]
name: kwargs [14793,14799]
===
match
---
simple_stmt [10478,10541]
simple_stmt [10478,10541]
===
match
---
name: os [31256,31258]
name: os [31256,31258]
===
match
---
testlist_comp [5179,5204]
testlist_comp [5179,5204]
===
match
---
string: 't' [17623,17626]
string: 't' [17623,17626]
===
match
---
operator: , [19625,19626]
operator: , [19625,19626]
===
match
---
operator: , [38458,38459]
operator: , [38462,38463]
===
match
---
atom_expr [39737,39791]
atom_expr [39741,39795]
===
match
---
argument [19694,19707]
argument [19694,19707]
===
match
---
operator: , [38846,38847]
operator: , [38850,38851]
===
match
---
operator: , [5888,5889]
operator: , [5888,5889]
===
match
---
trailer [32878,32884]
trailer [32878,32884]
===
match
---
expr_stmt [33128,33171]
expr_stmt [33128,33171]
===
match
---
name: path [31578,31582]
name: path [31578,31582]
===
match
---
suite [13580,13780]
suite [13580,13780]
===
match
---
expr_stmt [12316,12346]
expr_stmt [12316,12346]
===
match
---
name: getboolean [35529,35539]
name: getboolean [35529,35539]
===
match
---
param [8274,8282]
param [8274,8282]
===
match
---
name: self [20612,20616]
name: self [20612,20616]
===
match
---
name: str [3139,3142]
name: str [3139,3142]
===
match
---
expr_stmt [8733,8757]
expr_stmt [8733,8757]
===
match
---
trailer [20486,20500]
trailer [20486,20500]
===
match
---
suite [17706,17732]
suite [17706,17732]
===
match
---
simple_stmt [25758,25780]
simple_stmt [25758,25780]
===
match
---
atom_expr [32957,33024]
atom_expr [32957,33024]
===
match
---
operator: , [7096,7097]
operator: , [7096,7097]
===
match
---
name: super [16334,16339]
name: super [16334,16339]
===
match
---
param [28569,28573]
param [28569,28573]
===
match
---
argument [37167,37175]
argument [37171,37179]
===
match
---
operator: = [26167,26168]
operator: = [26167,26168]
===
match
---
name: os [2149,2151]
name: os [2149,2151]
===
match
---
name: self [15969,15973]
name: self [15969,15973]
===
match
---
atom_expr [31372,31432]
atom_expr [31372,31432]
===
match
---
operator: , [26451,26452]
operator: , [26451,26452]
===
match
---
operator: , [28502,28503]
operator: , [28502,28503]
===
match
---
simple_stmt [1270,1324]
simple_stmt [1270,1324]
===
match
---
string: 'statsd_datadog_enabled' [6972,6996]
string: 'statsd_datadog_enabled' [6972,6996]
===
match
---
suite [33404,34223]
suite [33404,34223]
===
match
---
operator: , [17981,17982]
operator: , [17981,17982]
===
match
---
name: import_string [40230,40243]
name: import_string [40234,40247]
===
match
---
trailer [27729,27753]
trailer [27729,27753]
===
match
---
name: msg [33703,33706]
name: msg [33703,33706]
===
match
---
arglist [35230,35479]
arglist [35230,35479]
===
match
---
name: WEBSERVER_CONFIG [34386,34402]
name: WEBSERVER_CONFIG [34386,34402]
===
match
---
fstring_expr [9929,9959]
fstring_expr [9929,9959]
===
match
---
trailer [16715,16765]
trailer [16715,16765]
===
match
---
name: b64encode [948,957]
name: b64encode [948,957]
===
match
---
name: _section [21695,21703]
name: _section [21695,21703]
===
match
---
param [14786,14790]
param [14786,14790]
===
match
---
string: 'core' [5473,5479]
string: 'core' [5473,5479]
===
match
---
operator: = [40024,40025]
operator: = [40028,40029]
===
match
---
suite [10601,10858]
suite [10601,10858]
===
match
---
atom_expr [21433,21458]
atom_expr [21433,21458]
===
match
---
operator: { [2782,2783]
operator: { [2782,2783]
===
match
---
atom_expr [8441,8490]
atom_expr [8441,8490]
===
match
---
trailer [3769,3816]
trailer [3769,3816]
===
match
---
operator: , [22220,22221]
operator: , [22220,22221]
===
match
---
trailer [2625,2636]
trailer [2625,2636]
===
match
---
name: args [8374,8378]
name: args [8374,8378]
===
match
---
string: 'core' [5685,5691]
string: 'core' [5685,5691]
===
match
---
name: key [14104,14107]
name: key [14104,14107]
===
match
---
atom_expr [24645,24670]
atom_expr [24645,24670]
===
match
---
name: args [37620,37624]
name: args [37624,37628]
===
match
---
name: kwargs [36785,36791]
name: kwargs [36785,36791]
===
match
---
name: _get_option_from_commands [14365,14390]
name: _get_option_from_commands [14365,14390]
===
match
---
name: deprecated_section [14084,14102]
name: deprecated_section [14084,14102]
===
match
---
param [17963,17968]
param [17963,17968]
===
match
---
param [36783,36791]
param [36783,36791]
===
match
---
atom_expr [33334,33359]
atom_expr [33334,33359]
===
match
---
name: section [13183,13190]
name: section [13183,13190]
===
match
---
operator: , [25325,25326]
operator: , [25325,25326]
===
match
---
suite [31232,31291]
suite [31232,31291]
===
match
---
simple_stmt [34549,34586]
simple_stmt [34549,34586]
===
match
---
name: env_var [21422,21429]
name: env_var [21422,21429]
===
match
---
trailer [1687,1752]
trailer [1687,1752]
===
match
---
operator: , [8265,8266]
operator: , [8265,8266]
===
match
---
name: _get_option_from_default_config [14739,14770]
name: _get_option_from_default_config [14739,14770]
===
match
---
name: env_var [12160,12167]
name: env_var [12160,12167]
===
match
---
simple_stmt [29782,30274]
simple_stmt [29782,30274]
===
match
---
name: backend_list [40105,40117]
name: backend_list [40109,40121]
===
match
---
fstring_string: Failed to convert value to int. Please check " [18170,18216]
fstring_string: Failed to convert value to int. Please check " [18170,18216]
===
match
---
operator: , [6318,6319]
operator: , [6318,6319]
===
match
---
operator: , [19742,19743]
operator: , [19742,19743]
===
match
---
argument [30909,30921]
argument [30909,30921]
===
match
---
fstring_start: f' [21378,21380]
fstring_start: f' [21378,21380]
===
match
---
trailer [21548,21568]
trailer [21548,21568]
===
match
---
if_stmt [9799,9962]
if_stmt [9799,9962]
===
match
---
name: _update_env_var [10981,10996]
name: _update_env_var [10981,10996]
===
match
---
operator: , [7288,7289]
operator: , [7288,7289]
===
match
---
expr_stmt [13018,13045]
expr_stmt [13018,13045]
===
match
---
trailer [33137,33143]
trailer [33137,33143]
===
match
---
trailer [15485,15504]
trailer [15485,15504]
===
match
---
simple_stmt [35905,35945]
simple_stmt [35905,35945]
===
match
---
return_stmt [14639,14652]
return_stmt [14639,14652]
===
match
---
operator: , [4514,4515]
operator: , [4514,4515]
===
match
---
operator: , [1316,1317]
operator: , [1316,1317]
===
match
---
atom_expr [37148,37176]
atom_expr [37148,37180]
===
match
---
param [29271,29275]
param [29271,29275]
===
match
---
string: 'core' [34143,34149]
string: 'core' [34143,34149]
===
match
---
name: self [9754,9758]
name: self [9754,9758]
===
match
---
string: 'logging' [5216,5225]
string: 'logging' [5216,5225]
===
match
---
trailer [21183,21189]
trailer [21183,21189]
===
match
---
atom_expr [2130,2182]
atom_expr [2130,2182]
===
match
---
name: key [13901,13904]
name: key [13901,13904]
===
match
---
return_stmt [15667,15680]
return_stmt [15667,15680]
===
match
---
string: 'w' [34527,34530]
string: 'w' [34527,34530]
===
match
---
trailer [38417,38425]
trailer [38421,38429]
===
match
---
operator: , [11269,11270]
operator: , [11269,11270]
===
match
---
name: display_source [25041,25055]
name: display_source [25041,25055]
===
match
---
for_stmt [25494,26001]
for_stmt [25494,26001]
===
match
---
string: 'logging' [6264,6273]
string: 'logging' [6264,6273]
===
match
---
name: key [13004,13007]
name: key [13004,13007]
===
match
---
string: 'false' [22099,22106]
string: 'false' [22099,22106]
===
match
---
name: new_value [11765,11774]
name: new_value [11765,11774]
===
match
---
name: section [22756,22763]
name: section [22756,22763]
===
match
---
arglist [15505,15539]
arglist [15505,15539]
===
match
---
name: config_sources [26556,26570]
name: config_sources [26556,26570]
===
match
---
simple_stmt [26244,26253]
simple_stmt [26244,26253]
===
match
---
number: 2 [36710,36711]
number: 2 [36710,36711]
===
match
---
simple_stmt [30536,30585]
simple_stmt [30536,30585]
===
match
---
string: 'logging' [5727,5736]
string: 'logging' [5727,5736]
===
match
---
name: super [13164,13169]
name: super [13164,13169]
===
match
---
name: all_vars [31837,31845]
name: all_vars [31837,31845]
===
match
---
operator: = [21917,21918]
operator: = [21917,21918]
===
match
---
operator: , [22668,22669]
operator: , [22668,22669]
===
match
---
name: conf [35112,35116]
name: conf [35112,35116]
===
match
---
string: 'AIRFLOW_CONFIG' [30622,30638]
string: 'AIRFLOW_CONFIG' [30622,30638]
===
match
---
name: section [39411,39418]
name: section [39415,39422]
===
match
---
trailer [10217,10237]
trailer [10217,10237]
===
match
---
trailer [1672,1687]
trailer [1672,1687]
===
match
---
trailer [13900,13905]
trailer [13900,13905]
===
match
---
arglist [3273,3297]
arglist [3273,3297]
===
match
---
name: key [39589,39592]
name: key [39593,39596]
===
match
---
not_test [20965,20994]
not_test [20965,20994]
===
match
---
simple_stmt [38921,39059]
simple_stmt [38925,39063]
===
match
---
name: self [13119,13123]
name: self [13119,13123]
===
match
---
name: key [15778,15781]
name: key [15778,15781]
===
match
---
operator: , [5450,5451]
operator: , [5450,5451]
===
match
---
trailer [8300,8309]
trailer [8300,8309]
===
match
---
name: setdefault [27719,27729]
name: setdefault [27719,27729]
===
match
---
operator: = [8921,8922]
operator: = [8921,8922]
===
match
---
name: str [17483,17486]
name: str [17483,17486]
===
match
---
fstring_start: f" [2693,2695]
fstring_start: f" [2693,2695]
===
match
---
simple_stmt [19983,20026]
simple_stmt [19983,20026]
===
match
---
name: display_source [26658,26672]
name: display_source [26658,26672]
===
match
---
string: "_CMD" [21601,21607]
string: "_CMD" [21601,21607]
===
match
---
parameters [28568,28574]
parameters [28568,28574]
===
match
---
operator: , [5205,5206]
operator: , [5205,5206]
===
match
---
arith_expr [12330,12346]
arith_expr [12330,12346]
===
match
---
name: TEST_CONFIG_FILE [32206,32222]
name: TEST_CONFIG_FILE [32206,32222]
===
match
---
trailer [2394,2400]
trailer [2394,2400]
===
match
---
string: "'conf.getfloat'" [36240,36257]
string: "'conf.getfloat'" [36240,36257]
===
match
---
name: source_name [28297,28308]
name: source_name [28297,28308]
===
match
---
return_stmt [14934,15006]
return_stmt [14934,15006]
===
match
---
operator: , [15278,15279]
operator: , [15278,15279]
===
match
---
name: process [2618,2625]
name: process [2618,2625]
===
match
---
name: warnings [920,928]
name: warnings [920,928]
===
match
---
operator: } [26537,26538]
operator: } [26537,26538]
===
match
---
name: os [31151,31153]
name: os [31151,31153]
===
match
---
operator: , [6678,6679]
operator: , [6678,6679]
===
match
---
name: parameterized_config [28847,28867]
name: parameterized_config [28847,28867]
===
match
---
arglist [34337,34402]
arglist [34337,34402]
===
match
---
name: warn [36035,36039]
name: warn [36035,36039]
===
match
---
arglist [3197,3242]
arglist [3197,3242]
===
match
---
trailer [39537,39543]
trailer [39541,39547]
===
match
---
name: super [8293,8298]
name: super [8293,8298]
===
match
---
name: getdefaultencoding [2541,2559]
name: getdefaultencoding [2541,2559]
===
match
---
name: os [12531,12533]
name: os [12531,12533]
===
match
---
atom_expr [22157,22170]
atom_expr [22157,22170]
===
match
---
not_test [25641,25662]
not_test [25641,25662]
===
match
---
testlist_comp [6735,6761]
testlist_comp [6735,6761]
===
match
---
trailer [11217,11225]
trailer [11217,11225]
===
match
---
name: os [31050,31052]
name: os [31050,31052]
===
match
---
name: remove_default [20584,20598]
name: remove_default [20584,20598]
===
match
---
simple_stmt [22732,22810]
simple_stmt [22732,22810]
===
match
---
simple_stmt [25871,25940]
simple_stmt [25871,25940]
===
match
---
operator: = [30035,30036]
operator: = [30035,30036]
===
match
---
trailer [37570,37581]
trailer [37574,37585]
===
match
---
name: _ [34434,34435]
name: _ [34434,34435]
===
match
---
atom [6916,6950]
atom [6916,6950]
===
match
---
operator: , [9626,9627]
operator: , [9626,9627]
===
match
---
string: 'core' [6137,6143]
string: 'core' [6137,6143]
===
match
---
name: os [31388,31390]
name: os [31388,31390]
===
match
---
parameters [14770,14800]
parameters [14770,14800]
===
match
---
trailer [34292,34297]
trailer [34292,34297]
===
match
---
expr_stmt [21913,21929]
expr_stmt [21913,21929]
===
match
---
param [26658,26673]
param [26658,26673]
===
match
---
simple_stmt [1888,2048]
simple_stmt [1888,2048]
===
match
---
name: get [30372,30375]
name: get [30372,30375]
===
match
---
testlist_comp [5727,5759]
testlist_comp [5727,5759]
===
match
---
operator: } [39719,39720]
operator: } [39723,39724]
===
match
---
name: lower [17521,17526]
name: lower [17521,17526]
===
match
---
name: warnings [38542,38550]
name: warnings [38546,38554]
===
match
---
trailer [31395,31403]
trailer [31395,31403]
===
match
---
operator: , [11734,11735]
operator: , [11734,11735]
===
match
---
string: 'result_backend' [4642,4658]
string: 'result_backend' [4642,4658]
===
match
---
atom_expr [8696,8715]
atom_expr [8696,8715]
===
match
---
not_test [32917,32951]
not_test [32917,32951]
===
match
---
string: 'email' [7702,7709]
string: 'email' [7702,7709]
===
match
---
simple_stmt [36723,36759]
simple_stmt [36723,36759]
===
match
---
operator: } [18220,18221]
operator: } [18220,18221]
===
match
---
name: start_method_options [10818,10838]
name: start_method_options [10818,10838]
===
match
---
suite [26290,26326]
suite [26290,26326]
===
match
---
operator: + [25988,25989]
operator: + [25988,25989]
===
match
---
trailer [26882,26891]
trailer [26882,26891]
===
match
---
if_stmt [8845,9331]
if_stmt [8845,9331]
===
match
---
operator: , [20159,20160]
operator: , [20159,20160]
===
match
---
operator: , [5087,5088]
operator: , [5087,5088]
===
match
---
operator: = [11749,11750]
operator: = [11749,11750]
===
match
---
name: warn [33698,33702]
name: warn [33698,33702]
===
match
---
arglist [17318,17366]
arglist [17318,17366]
===
match
---
import_from [1431,1506]
import_from [1431,1506]
===
match
---
name: Tuple [1311,1316]
name: Tuple [1311,1316]
===
match
---
string: """         Validate that config values aren't invalid given other config values         or system-level limitations and requirements.         """ [9419,9565]
string: """         Validate that config values aren't invalid given other config values         or system-level limitations and requirements.         """ [9419,9565]
===
match
---
operator: = [34436,34437]
operator: = [34436,34437]
===
match
---
trailer [36330,36339]
trailer [36330,36339]
===
match
---
funcdef [13337,13800]
funcdef [13337,13800]
===
match
---
name: warnings [29782,29790]
name: warnings [29782,29790]
===
match
---
comparison [14607,14625]
comparison [14607,14625]
===
match
---
simple_stmt [38406,38443]
simple_stmt [38410,38447]
===
match
---
arglist [8996,9043]
arglist [8996,9043]
===
match
---
name: sys [909,912]
name: sys [909,912]
===
match
---
operator: , [12012,12013]
operator: , [12012,12013]
===
match
---
string: 'airflow' [1742,1751]
string: 'airflow' [1742,1751]
===
match
---
name: key [25929,25932]
name: key [25929,25932]
===
match
---
operator: = [11774,11775]
operator: = [11774,11775]
===
match
---
arglist [18017,18039]
arglist [18017,18039]
===
match
---
trailer [38836,38840]
trailer [38840,38844]
===
match
---
param [28288,28296]
param [28288,28296]
===
match
---
arglist [8310,8325]
arglist [8310,8325]
===
match
---
operator: } [17876,17877]
operator: } [17876,17877]
===
match
---
name: compile [7763,7770]
name: compile [7763,7770]
===
match
---
operator: , [6012,6013]
operator: , [6012,6013]
===
match
---
operator: , [19059,19060]
operator: , [19059,19060]
===
match
---
suite [22108,22145]
suite [22108,22145]
===
match
---
name: fernet [1355,1361]
name: fernet [1355,1361]
===
match
---
name: config_sources [27837,27851]
name: config_sources [27837,27851]
===
match
---
trailer [22666,22668]
trailer [22666,22668]
===
match
---
string: 'core' [5247,5253]
string: 'core' [5247,5253]
===
match
---
name: option [20510,20516]
name: option [20510,20516]
===
match
---
trailer [2473,2478]
trailer [2473,2478]
===
match
---
simple_stmt [1229,1270]
simple_stmt [1229,1270]
===
match
---
suite [25485,26001]
suite [25485,26001]
===
match
---
atom_expr [9065,9330]
atom_expr [9065,9330]
===
match
---
name: lower [27684,27689]
name: lower [27684,27689]
===
match
---
simple_stmt [21226,21251]
simple_stmt [21226,21251]
===
match
---
name: os [31068,31070]
name: os [31068,31070]
===
match
---
name: os [34290,34292]
name: os [34290,34292]
===
match
---
trailer [14960,14977]
trailer [14960,14977]
===
match
---
name: file_path [3393,3402]
name: file_path [3393,3402]
===
match
---
atom [7130,7170]
atom [7130,7170]
===
match
---
string: 't' [22004,22007]
string: 't' [22004,22007]
===
match
---
string: 'in the config file is deprecated. Please use only the AIRFLOW_HOME ' [33503,33572]
string: 'in the config file is deprecated. Please use only the AIRFLOW_HOME ' [33503,33572]
===
match
---
trailer [8564,8594]
trailer [8564,8594]
===
match
---
operator: , [32742,32743]
operator: , [32742,32743]
===
match
---
param [31985,31997]
param [31985,31997]
===
match
---
suite [20466,20518]
suite [20466,20518]
===
match
---
trailer [1765,1780]
trailer [1765,1780]
===
match
---
arglist [34826,35101]
arglist [34826,35101]
===
match
---
atom_expr [18008,18040]
atom_expr [18008,18040]
===
match
---
name: kwargs [38059,38065]
name: kwargs [38063,38069]
===
match
---
trailer [17786,17946]
trailer [17786,17946]
===
match
---
name: val [17679,17682]
name: val [17679,17682]
===
match
---
string: 'logging' [6472,6481]
string: 'logging' [6472,6481]
===
match
---
name: _get_config_value_from_secret_backend [12873,12910]
name: _get_config_value_from_secret_backend [12873,12910]
===
match
---
operator: , [8806,8807]
operator: , [8806,8807]
===
match
---
operator: , [34048,34049]
operator: , [34048,34049]
===
match
---
name: section [16086,16093]
name: section [16086,16093]
===
match
---
operator: , [17967,17968]
operator: , [17967,17968]
===
match
---
arglist [38019,38034]
arglist [38023,38038]
===
match
---
string: 'f' [22094,22097]
string: 'f' [22094,22097]
===
match
---
name: raw [28439,28442]
name: raw [28439,28442]
===
match
---
name: version [8743,8750]
name: version [8743,8750]
===
match
---
name: path [31391,31395]
name: path [31391,31395]
===
match
---
trailer [10283,10343]
trailer [10283,10343]
===
match
---
simple_stmt [13788,13800]
simple_stmt [13788,13800]
===
match
---
name: key [13111,13114]
name: key [13111,13114]
===
match
---
suite [27929,28162]
suite [27929,28162]
===
match
---
string: 'stat_name_handler' [6894,6913]
string: 'stat_name_handler' [6894,6913]
===
match
---
operator: , [17976,17977]
operator: , [17976,17977]
===
match
---
name: TEST_CONFIG [32843,32854]
name: TEST_CONFIG [32843,32854]
===
match
---
suite [12849,12944]
suite [12849,12944]
===
match
---
name: update [25921,25927]
name: update [25921,25927]
===
match
---
name: current_value [11736,11749]
name: current_value [11736,11749]
===
match
---
name: section [17969,17976]
name: section [17969,17976]
===
match
---
name: ValueError [26972,26982]
name: ValueError [26972,26982]
===
match
---
string: '< hidden >' [27116,27128]
string: '< hidden >' [27116,27128]
===
match
---
if_stmt [2191,2300]
if_stmt [2191,2300]
===
match
---
operator: , [5691,5692]
operator: , [5691,5692]
===
match
---
atom_expr [12217,12236]
atom_expr [12217,12236]
===
match
---
argument [20009,20024]
argument [20009,20024]
===
match
---
testlist_star_expr [3497,3531]
testlist_star_expr [3497,3531]
===
match
---
operator: , [39609,39610]
operator: , [39613,39614]
===
match
---
simple_stmt [39796,39808]
simple_stmt [39800,39812]
===
match
---
operator: , [19068,19069]
operator: , [19068,19069]
===
match
---
atom_expr [21636,21644]
atom_expr [21636,21644]
===
match
---
for_stmt [26688,27773]
for_stmt [26688,27773]
===
match
---
atom_expr [7529,7545]
atom_expr [7529,7545]
===
match
---
operator: = [10138,10139]
operator: = [10138,10139]
===
match
---
trailer [26125,26149]
trailer [26125,26149]
===
match
---
name: join [31264,31268]
name: join [31264,31268]
===
match
---
expr_stmt [12651,12692]
expr_stmt [12651,12692]
===
match
---
suite [26983,27009]
suite [26983,27009]
===
match
---
trailer [38550,38555]
trailer [38554,38559]
===
match
---
name: airflow_defaults [24725,24741]
name: airflow_defaults [24725,24741]
===
match
---
name: stderr [2513,2519]
name: stderr [2513,2519]
===
match
---
name: command [13303,13310]
name: command [13303,13310]
===
match
---
trailer [12913,12921]
trailer [12913,12921]
===
match
---
name: deprecated_key [17230,17244]
name: deprecated_key [17230,17244]
===
match
---
name: backend_list [40319,40331]
name: backend_list [40323,40335]
===
match
---
name: staticmethod [28168,28180]
name: staticmethod [28168,28180]
===
match
---
operator: = [35098,35099]
operator: = [35098,35099]
===
match
---
operator: == [33779,33781]
operator: == [33779,33781]
===
match
---
trailer [16069,16085]
trailer [16069,16085]
===
match
---
name: e [19263,19264]
name: e [19263,19264]
===
match
---
param [15758,15777]
param [15758,15777]
===
match
---
name: config_sources [27704,27718]
name: config_sources [27704,27718]
===
match
---
name: section [17444,17451]
name: section [17444,17451]
===
match
---
operator: , [2430,2431]
operator: , [2430,2431]
===
match
---
name: DEFAULT_CONFIG_FILE_PATH [28796,28820]
name: DEFAULT_CONFIG_FILE_PATH [28796,28820]
===
match
---
testlist_comp [4736,4761]
testlist_comp [4736,4761]
===
match
---
name: getsection [20674,20684]
name: getsection [20674,20684]
===
match
---
trailer [17595,17601]
trailer [17595,17601]
===
match
---
if_stmt [26216,26253]
if_stmt [26216,26253]
===
match
---
trailer [20562,20579]
trailer [20562,20579]
===
match
---
for_stmt [27942,28162]
for_stmt [27942,28162]
===
match
---
operator: = [17035,17036]
operator: = [17035,17036]
===
match
---
parameters [11998,12018]
parameters [11998,12018]
===
match
---
trailer [9092,9330]
trailer [9092,9330]
===
match
---
suite [25621,26001]
suite [25621,26001]
===
match
---
expr_stmt [25826,25854]
expr_stmt [25826,25854]
===
match
---
atom [39994,39996]
atom [39998,40000]
===
match
---
name: has_option [16631,16641]
name: has_option [16631,16641]
===
match
---
name: get_airflow_config [30412,30430]
name: get_airflow_config [30412,30430]
===
match
---
parameters [39841,39843]
parameters [39845,39847]
===
match
---
operator: , [22840,22841]
operator: , [22840,22841]
===
match
---
param [25480,25483]
param [25480,25483]
===
match
---
name: self [15346,15350]
name: self [15346,15350]
===
match
---
name: e [19238,19239]
name: e [19238,19239]
===
match
---
name: path [31103,31107]
name: path [31103,31107]
===
match
---
argument [33280,33331]
argument [33280,33331]
===
match
---
name: os [31100,31102]
name: os [31100,31102]
===
match
---
name: env_var [27050,27057]
name: env_var [27050,27057]
===
match
---
operator: ** [36347,36349]
operator: ** [36347,36349]
===
match
---
name: open [3885,3889]
name: open [3885,3889]
===
match
---
name: append [40118,40124]
name: append [40122,40128]
===
match
---
import_name [846,860]
import_name [846,860]
===
match
---
simple_stmt [24684,24789]
simple_stmt [24684,24789]
===
match
---
name: key [25984,25987]
name: key [25984,25987]
===
match
---
name: globals [31864,31871]
name: globals [31864,31871]
===
match
---
name: section [16966,16973]
name: section [16966,16973]
===
match
---
trailer [19544,19549]
trailer [19544,19549]
===
match
---
trailer [39400,39410]
trailer [39404,39414]
===
match
---
operator: , [6422,6423]
operator: , [6422,6423]
===
match
---
name: opt [25826,25829]
name: opt [25826,25829]
===
match
---
operator: , [14994,14995]
operator: , [14994,14995]
===
match
---
string: 'logging_level' [5521,5536]
string: 'logging_level' [5521,5536]
===
match
---
name: conf [35912,35916]
name: conf [35912,35916]
===
match
---
atom [13533,13547]
atom [13533,13547]
===
match
---
operator: = [10499,10500]
operator: = [10499,10500]
===
match
---
atom_expr [29011,29062]
atom_expr [29011,29062]
===
match
---
atom_expr [1664,1752]
atom_expr [1664,1752]
===
match
---
suite [18476,18679]
suite [18476,18679]
===
match
---
or_test [32335,32409]
or_test [32335,32409]
===
match
---
classdef [3962,30274]
classdef [3962,30274]
===
match
---
operator: , [10893,10894]
operator: , [10893,10894]
===
match
---
name: self [16695,16699]
name: self [16695,16699]
===
match
---
operator: , [13364,13365]
operator: , [13364,13365]
===
match
---
trailer [2167,2181]
trailer [2167,2181]
===
match
---
trailer [10516,10538]
trailer [10516,10538]
===
match
---
string: "Accessing configuration method 'getboolean' directly from the configuration module is " [35631,35719]
string: "Accessing configuration method 'getboolean' directly from the configuration module is " [35631,35719]
===
match
---
string: 'simple_log_format' [6034,6053]
string: 'simple_log_format' [6034,6053]
===
match
---
operator: = [39433,39434]
operator: = [39437,39438]
===
match
---
name: val [28397,28400]
name: val [28397,28400]
===
match
---
simple_stmt [18489,18679]
simple_stmt [18489,18679]
===
match
---
name: current_value [10895,10908]
name: current_value [10895,10908]
===
match
---
expr_stmt [21630,21644]
expr_stmt [21630,21644]
===
match
---
atom_expr [21330,21349]
atom_expr [21330,21349]
===
match
---
name: kwargs [16271,16277]
name: kwargs [16271,16277]
===
match
---
parameters [3605,3607]
parameters [3605,3607]
===
match
---
funcdef [34723,35136]
funcdef [34723,35136]
===
match
---
strings [36867,37079]
strings [36867,37079]
===
match
---
trailer [13880,13882]
trailer [13880,13882]
===
match
---
simple_stmt [37559,37599]
simple_stmt [37563,37603]
===
match
---
simple_stmt [37262,37555]
simple_stmt [37266,37559]
===
match
---
name: re [7760,7762]
name: re [7760,7762]
===
match
---
trailer [21482,21493]
trailer [21482,21493]
===
match
---
trailer [36852,36857]
trailer [36852,36857]
===
match
---
operator: , [31873,31874]
operator: , [31873,31874]
===
match
---
parameters [38049,38066]
parameters [38053,38070]
===
match
---
name: path [31407,31411]
name: path [31407,31411]
===
match
---
name: int [21832,21835]
name: int [21832,21835]
===
match
---
name: section [29325,29332]
name: section [29325,29332]
===
match
---
operator: , [20655,20656]
operator: , [20655,20656]
===
match
---
funcdef [30276,30406]
funcdef [30276,30406]
===
match
---
operator: == [29333,29335]
operator: == [29333,29335]
===
match
---
trailer [13675,13677]
trailer [13675,13677]
===
match
---
operator: * [8310,8311]
operator: * [8310,8311]
===
match
---
name: stdout [2432,2438]
name: stdout [2432,2438]
===
match
---
trailer [31057,31062]
trailer [31057,31062]
===
match
---
atom_expr [39533,39639]
atom_expr [39537,39643]
===
match
---
fstring_expr [2782,2790]
fstring_expr [2782,2790]
===
match
---
simple_stmt [28742,28822]
simple_stmt [28742,28822]
===
match
---
operator: , [16008,16009]
operator: , [16008,16009]
===
match
---
name: info [33201,33205]
name: info [33201,33205]
===
match
---
expr_stmt [15337,15383]
expr_stmt [15337,15383]
===
match
---
operator: , [16959,16960]
operator: , [16959,16960]
===
match
---
except_clause [21853,21870]
except_clause [21853,21870]
===
match
---
name: self [22482,22486]
name: self [22482,22486]
===
match
---
name: env_var [26692,26699]
name: env_var [26692,26699]
===
match
---
try_stmt [18415,18679]
try_stmt [18415,18679]
===
match
---
name: DEFAULT_CONFIG [3405,3419]
name: DEFAULT_CONFIG [3405,3419]
===
match
---
trailer [10937,10944]
trailer [10937,10944]
===
match
---
if_stmt [16620,16863]
if_stmt [16620,16863]
===
match
---
name: warnings [36434,36442]
name: warnings [36434,36442]
===
match
---
name: dict [3611,3615]
name: dict [3611,3615]
===
match
---
suite [11388,11854]
suite [11388,11854]
===
match
---
parameters [13812,13842]
parameters [13812,13842]
===
match
---
string: 'email_backend' [7725,7740]
string: 'email_backend' [7725,7740]
===
match
---
trailer [31898,31904]
trailer [31898,31904]
===
match
---
atom [5684,5716]
atom [5684,5716]
===
match
---
trailer [10438,10465]
trailer [10438,10465]
===
match
---
if_stmt [26338,26459]
if_stmt [26338,26459]
===
match
---
comp_op [14303,14309]
comp_op [14303,14309]
===
match
---
name: startswith [21483,21493]
name: startswith [21483,21493]
===
match
---
arglist [25897,25919]
arglist [25897,25919]
===
match
---
suite [12384,12556]
suite [12384,12556]
===
match
---
simple_stmt [26373,26392]
simple_stmt [26373,26392]
===
match
---
name: cfg [33077,33080]
name: cfg [33077,33080]
===
match
---
suite [16367,16577]
suite [16367,16577]
===
match
---
trailer [32904,32910]
trailer [32904,32910]
===
match
---
name: os [30361,30363]
name: os [30361,30363]
===
match
---
operator: = [1741,1742]
operator: = [1741,1742]
===
match
---
name: self [15837,15841]
name: self [15837,15841]
===
match
---
name: log [33197,33200]
name: log [33197,33200]
===
match
---
operator: = [21634,21635]
operator: = [21634,21635]
===
match
---
name: shlex [2410,2415]
name: shlex [2410,2415]
===
match
---
name: templates_dir [3741,3754]
name: templates_dir [3741,3754]
===
match
---
simple_stmt [37230,37258]
simple_stmt [37234,37262]
===
match
---
operator: = [5066,5067]
operator: = [5066,5067]
===
match
---
operator: ** [31935,31937]
operator: ** [31935,31937]
===
match
---
string: """     Ensure that all secrets backends are loaded.     If the secrets_backend_list contains only 2 default backends, reload it.     """ [38921,39058]
string: """     Ensure that all secrets backends are loaded.     If the secrets_backend_list contains only 2 default backends, reload it.     """ [38925,39062]
===
match
---
trailer [16630,16641]
trailer [16630,16641]
===
match
---
param [10890,10894]
param [10890,10894]
===
match
---
param [10895,10908]
param [10895,10908]
===
match
---
simple_stmt [958,994]
simple_stmt [958,994]
===
match
---
name: warnings [1664,1672]
name: warnings [1664,1672]
===
match
---
name: path [34293,34297]
name: path [34293,34297]
===
match
---
fstring_end: ' [17888,17889]
fstring_end: ' [17888,17889]
===
match
---
param [17978,17982]
param [17978,17982]
===
match
---
param [16246,16265]
param [16246,16265]
===
match
---
name: _ [26851,26852]
name: _ [26851,26852]
===
match
---
simple_stmt [8441,8491]
simple_stmt [8441,8491]
===
match
---
name: key [18217,18220]
name: key [18217,18220]
===
match
---
operator: , [35456,35457]
operator: , [35456,35457]
===
match
---
name: decode [2530,2536]
name: decode [2530,2536]
===
match
---
name: airflow_defaults [8446,8462]
name: airflow_defaults [8446,8462]
===
match
---
name: endswith [21592,21600]
name: endswith [21592,21600]
===
match
---
dotted_name [1512,1540]
dotted_name [1512,1540]
===
match
---
expr_stmt [12106,12148]
expr_stmt [12106,12148]
===
match
---
expr_stmt [28529,28542]
expr_stmt [28529,28542]
===
match
---
operator: = [30128,30129]
operator: = [30128,30129]
===
match
---
string: 'logging_config_class' [5693,5715]
string: 'logging_config_class' [5693,5715]
===
match
---
name: self [21330,21334]
name: self [21330,21334]
===
match
---
arglist [37160,37175]
arglist [37164,37179]
===
match
---
name: _get_env_var_option [17190,17209]
name: _get_env_var_option [17190,17209]
===
match
---
atom_expr [21988,21999]
atom_expr [21988,21999]
===
match
---
name: delimiter [22529,22538]
name: delimiter [22529,22538]
===
match
---
name: raw [25480,25483]
name: raw [25480,25483]
===
match
---
strings [38138,38344]
strings [38142,38348]
===
match
---
name: key [15610,15613]
name: key [15610,15613]
===
match
---
string: 'scheduler' [7085,7096]
string: 'scheduler' [7085,7096]
===
match
---
parameters [20145,20189]
parameters [20145,20189]
===
match
---
atom_expr [25289,25366]
atom_expr [25289,25366]
===
match
---
name: path [3836,3840]
name: path [3836,3840]
===
match
---
name: mp_start_method [10412,10427]
name: mp_start_method [10412,10427]
===
match
---
suite [21046,21071]
suite [21046,21071]
===
match
---
trailer [14955,15006]
trailer [14955,15006]
===
match
---
name: path [31357,31361]
name: path [31357,31361]
===
match
---
funcdef [38038,38443]
funcdef [38042,38447]
===
match
---
suite [8284,8526]
suite [8284,8526]
===
match
---
trailer [26579,26593]
trailer [26579,26593]
===
match
---
string: 'core' [10439,10445]
string: 'core' [10439,10445]
===
match
---
name: env_var [12228,12235]
name: env_var [12228,12235]
===
match
---
return_stmt [16782,16862]
return_stmt [16782,16862]
===
match
---
operator: = [25830,25831]
operator: = [25830,25831]
===
match
---
operator: , [18332,18333]
operator: , [18332,18333]
===
match
---
name: opt [27243,27246]
name: opt [27243,27246]
===
match
---
operator: { [18287,18288]
operator: { [18287,18288]
===
match
---
name: opt [26380,26383]
name: opt [26380,26383]
===
match
---
string: '~/airflow' [30392,30403]
string: '~/airflow' [30392,30403]
===
match
---
trailer [31406,31411]
trailer [31406,31411]
===
match
---
trailer [2536,2572]
trailer [2536,2572]
===
match
---
name: section [26104,26111]
name: section [26104,26111]
===
match
---
parameters [29261,29312]
parameters [29261,29312]
===
match
---
operator: , [5615,5616]
operator: , [5615,5616]
===
match
---
operator: = [37127,37128]
operator: = [37127,37128]
===
match
---
simple_stmt [13389,13440]
simple_stmt [13389,13440]
===
match
---
name: display_source [25346,25360]
name: display_source [25346,25360]
===
match
---
param [14777,14785]
param [14777,14785]
===
match
---
comp_op [14459,14465]
comp_op [14459,14465]
===
match
---
parameters [1873,1882]
parameters [1873,1882]
===
match
---
param [19496,19501]
param [19496,19501]
===
match
---
trailer [18012,18016]
trailer [18012,18016]
===
match
---
param [22880,22904]
param [22880,22904]
===
match
---
string: 'core' [5991,5997]
string: 'core' [5991,5997]
===
match
---
param [18348,18356]
param [18348,18356]
===
match
---
fstring_string: ". [19464,19466]
fstring_string: ". [19464,19466]
===
match
---
return_stmt [21059,21070]
return_stmt [21059,21070]
===
match
---
param [11904,11907]
param [11904,11907]
===
match
---
name: logging [805,812]
name: logging [805,812]
===
match
---
name: join [3841,3845]
name: join [3841,3845]
===
match
---
suite [9983,10344]
suite [9983,10344]
===
match
---
string: 'webserver' [7580,7591]
string: 'webserver' [7580,7591]
===
match
---
expr_stmt [40334,40386]
expr_stmt [40338,40390]
===
match
---
name: update [21311,21317]
name: update [21311,21317]
===
match
---
trailer [21329,21350]
trailer [21329,21350]
===
match
---
atom [5109,5136]
atom [5109,5136]
===
match
---
atom_expr [16540,16575]
atom_expr [16540,16575]
===
match
---
name: self [12466,12470]
name: self [12466,12470]
===
match
---
atom [22003,22016]
atom [22003,22016]
===
match
---
atom [6364,6413]
atom [6364,6413]
===
match
---
funcdef [19714,20123]
funcdef [19714,20123]
===
match
---
operator: ** [18348,18350]
operator: ** [18348,18350]
===
match
---
trailer [3196,3243]
trailer [3196,3243]
===
match
---
trailer [7653,7664]
trailer [7653,7664]
===
match
---
trailer [21036,21045]
trailer [21036,21045]
===
match
---
suite [23041,25397]
suite [23041,25397]
===
match
---
name: StrictVersion [10164,10177]
name: StrictVersion [10164,10177]
===
match
---
name: file [32864,32868]
name: file [32864,32868]
===
match
---
simple_stmt [13284,13312]
simple_stmt [13284,13312]
===
match
---
trailer [30902,30908]
trailer [30902,30908]
===
match
---
name: interpolated [2115,2127]
name: interpolated [2115,2127]
===
match
---
name: os [31575,31577]
name: os [31575,31577]
===
match
---
expr_stmt [3741,3816]
expr_stmt [3741,3816]
===
match
---
name: name [8682,8686]
name: name [8682,8686]
===
match
---
argument [35466,35478]
argument [35466,35478]
===
match
---
arglist [36742,36757]
arglist [36742,36757]
===
match
---
name: _create_future_warning [11315,11337]
name: _create_future_warning [11315,11337]
===
match
---
name: log [15034,15037]
name: log [15034,15037]
===
match
---
atom [6311,6354]
atom [6311,6354]
===
match
---
operator: , [3286,3287]
operator: , [3286,3287]
===
match
---
operator: , [26197,26198]
operator: , [26197,26198]
===
match
---
operator: , [25055,25056]
operator: , [25055,25056]
===
match
---
trailer [20435,20437]
trailer [20435,20437]
===
match
---
operator: @ [11859,11860]
operator: @ [11859,11860]
===
match
---
fstring_string: ". [18292,18294]
fstring_string: ". [18292,18294]
===
match
---
name: lower [21992,21997]
name: lower [21992,21997]
===
match
---
name: is_sqlite [9802,9811]
name: is_sqlite [9802,9811]
===
match
---
name: env_var [12106,12113]
name: env_var [12106,12113]
===
match
---
trailer [31934,31946]
trailer [31934,31946]
===
match
---
operator: , [18711,18712]
operator: , [18711,18712]
===
match
---
operator: ** [8380,8382]
operator: ** [8380,8382]
===
match
---
name: command [2711,2718]
name: command [2711,2718]
===
match
---
atom_expr [21162,21198]
atom_expr [21162,21198]
===
match
---
string: "deprecated. Please access the configuration from the 'configuration.conf' object via " [36144,36231]
string: "deprecated. Please access the configuration from the 'configuration.conf' object via " [36144,36231]
===
match
---
operator: = [19064,19065]
operator: = [19064,19065]
===
match
---
comparison [9742,9790]
comparison [9742,9790]
===
match
---
name: raw [27146,27149]
name: raw [27146,27149]
===
match
---
name: _TEST_PLUGINS_FOLDER [31331,31351]
name: _TEST_PLUGINS_FOLDER [31331,31351]
===
match
---
suite [12495,12556]
suite [12495,12556]
===
match
---
trailer [29790,29795]
trailer [29790,29795]
===
match
---
name: _get_env_var_option [21716,21735]
name: _get_env_var_option [21716,21735]
===
match
---
trailer [23029,23039]
trailer [23029,23039]
===
match
---
param [12014,12017]
param [12014,12017]
===
match
---
suite [20097,20123]
suite [20097,20123]
===
match
---
simple_stmt [14161,14175]
simple_stmt [14161,14175]
===
match
---
expr_stmt [31190,31226]
expr_stmt [31190,31226]
===
match
---
name: deprecated_section [16941,16959]
name: deprecated_section [16941,16959]
===
match
---
name: getboolean [35917,35927]
name: getboolean [35917,35927]
===
match
---
name: AIRFLOW_CONFIG [33039,33053]
name: AIRFLOW_CONFIG [33039,33053]
===
match
---
name: section [11192,11199]
name: section [11192,11199]
===
match
---
expr_stmt [39374,39444]
expr_stmt [39378,39448]
===
match
---
param [15783,15790]
param [15783,15790]
===
match
---
param [18718,18726]
param [18718,18726]
===
match
---
funcdef [28185,28543]
funcdef [28185,28543]
===
match
---
trailer [40124,40147]
trailer [40128,40151]
===
match
---
name: key [14991,14994]
name: key [14991,14994]
===
match
---
testlist [3373,3402]
testlist [3373,3402]
===
match
---
name: AIRFLOW_HOME [31269,31281]
name: AIRFLOW_HOME [31269,31281]
===
match
---
simple_stmt [10412,10466]
simple_stmt [10412,10466]
===
match
---
operator: , [26946,26947]
operator: , [26946,26947]
===
match
---
trailer [28928,28933]
trailer [28928,28933]
===
match
---
name: section [18017,18024]
name: section [18017,18024]
===
match
---
testlist_star_expr [8733,8750]
testlist_star_expr [8733,8750]
===
match
---
operator: { [26528,26529]
operator: { [26528,26529]
===
match
---
atom [25764,25779]
atom [25764,25779]
===
match
---
atom [27896,27917]
atom [27896,27917]
===
match
---
simple_stmt [13852,13883]
simple_stmt [13852,13883]
===
match
---
string: 'default' [24709,24718]
string: 'default' [24709,24718]
===
match
---
except_clause [39648,39670]
except_clause [39652,39674]
===
match
---
name: ImportError [19223,19234]
name: ImportError [19223,19234]
===
match
---
arglist [25844,25853]
arglist [25844,25853]
===
match
---
atom_expr [39847,39871]
atom_expr [39851,39875]
===
match
---
atom_expr [21237,21250]
atom_expr [21237,21250]
===
match
---
name: stderr [2801,2807]
name: stderr [2801,2807]
===
match
---
if_stmt [8398,8491]
if_stmt [8398,8491]
===
match
---
operator: , [17442,17443]
operator: , [17442,17443]
===
match
---
trailer [15841,15857]
trailer [15841,15857]
===
match
---
argument [18396,18404]
argument [18396,18404]
===
match
---
trailer [36339,36356]
trailer [36339,36356]
===
match
---
suite [34110,34223]
suite [34110,34223]
===
match
---
operator: = [25762,25763]
operator: = [25762,25763]
===
match
---
string: 'statsd_prefix' [6778,6793]
string: 'statsd_prefix' [6778,6793]
===
match
---
trailer [32106,32111]
trailer [32106,32111]
===
match
---
operator: , [15273,15274]
operator: , [15273,15274]
===
match
---
simple_stmt [10119,10149]
simple_stmt [10119,10149]
===
match
---
return_stmt [39179,39215]
return_stmt [39183,39219]
===
match
---
suite [15289,15701]
suite [15289,15701]
===
match
---
atom_expr [11424,11815]
atom_expr [11424,11815]
===
match
---
suite [39314,39808]
suite [39318,39812]
===
match
---
simple_stmt [9574,9722]
simple_stmt [9574,9722]
===
match
---
name: kwargs [19072,19078]
name: kwargs [19072,19078]
===
match
---
name: AIRFLOW_CONFIG [33009,33023]
name: AIRFLOW_CONFIG [33009,33023]
===
match
---
atom_expr [25128,25206]
atom_expr [25128,25206]
===
match
---
atom_expr [26556,26593]
atom_expr [26556,26593]
===
match
---
string: '/webserver_config.py' [34259,34281]
string: '/webserver_config.py' [34259,34281]
===
match
---
operator: , [9945,9946]
operator: , [9945,9946]
===
match
---
operator: , [11199,11200]
operator: , [11199,11200]
===
match
---
suite [21289,21352]
suite [21289,21352]
===
match
---
operator: { [18656,18657]
operator: { [18656,18657]
===
match
---
operator: , [5769,5770]
operator: , [5769,5770]
===
match
---
trailer [31460,31465]
trailer [31460,31465]
===
match
---
name: version [11794,11801]
name: version [11794,11801]
===
match
---
name: option [15337,15343]
name: option [15337,15343]
===
match
---
trailer [7539,7545]
trailer [7539,7545]
===
match
---
atom_expr [2149,2181]
atom_expr [2149,2181]
===
match
---
trailer [16352,16366]
trailer [16352,16366]
===
match
---
string: 'remote_logging' [5227,5243]
string: 'remote_logging' [5227,5243]
===
match
---
expr_stmt [22456,22502]
expr_stmt [22456,22502]
===
match
---
name: key [13375,13378]
name: key [13375,13378]
===
match
---
param [17453,17457]
param [17453,17457]
===
match
---
trailer [31587,31612]
trailer [31587,31612]
===
match
---
atom_expr [9754,9790]
atom_expr [9754,9790]
===
match
---
operator: , [11275,11276]
operator: , [11275,11276]
===
match
---
name: stacklevel [35466,35476]
name: stacklevel [35466,35476]
===
match
---
argument [19061,19068]
argument [19061,19068]
===
match
---
funcdef [19595,19709]
funcdef [19595,19709]
===
match
---
operator: , [28395,28396]
operator: , [28395,28396]
===
match
---
parameters [38885,38887]
parameters [38889,38891]
===
match
---
expr_stmt [30826,30875]
expr_stmt [30826,30875]
===
match
---
name: parameterized_config [31619,31639]
name: parameterized_config [31619,31639]
===
match
---
name: self [21263,21267]
name: self [21263,21267]
===
match
---
operator: } [2789,2790]
operator: } [2789,2790]
===
match
---
atom [4669,4690]
atom [4669,4690]
===
match
---
name: deprecated_key [16230,16244]
name: deprecated_key [16230,16244]
===
match
---
atom_expr [30876,30937]
atom_expr [30876,30937]
===
match
---
name: old_key [30076,30083]
name: old_key [30076,30083]
===
match
---
arglist [33831,34090]
arglist [33831,34090]
===
match
---
name: val [17572,17575]
name: val [17572,17575]
===
match
---
atom [4556,4580]
atom [4556,4580]
===
match
---
arglist [17210,17244]
arglist [17210,17244]
===
match
---
parameters [19608,19643]
parameters [19608,19643]
===
match
---
string: 'stat_name_handler' [6930,6949]
string: 'stat_name_handler' [6930,6949]
===
match
---
if_stmt [26265,26326]
if_stmt [26265,26326]
===
match
---
name: DeprecationWarning [36671,36689]
name: DeprecationWarning [36671,36689]
===
match
---
simple_stmt [33689,33737]
simple_stmt [33689,33737]
===
match
---
string: 'core' [7485,7491]
string: 'core' [7485,7491]
===
match
---
parameters [31639,31649]
parameters [31639,31649]
===
match
---
string: 'AIRFLOW__' [26794,26805]
string: 'AIRFLOW__' [26794,26805]
===
match
---
exprlist [8682,8692]
exprlist [8682,8692]
===
match
---
simple_stmt [19013,19080]
simple_stmt [19013,19080]
===
match
---
testlist_comp [6669,6693]
testlist_comp [6669,6693]
===
match
---
name: info [8688,8692]
name: info [8688,8692]
===
match
---
name: getfloat [18319,18327]
name: getfloat [18319,18327]
===
match
---
operator: = [22171,22172]
operator: = [22171,22172]
===
match
---
operator: = [31352,31353]
operator: = [31352,31353]
===
match
---
name: IGNORECASE [7654,7664]
name: IGNORECASE [7654,7664]
===
match
---
argument [3324,3340]
argument [3324,3340]
===
match
---
name: DeprecationWarning [33717,33735]
name: DeprecationWarning [33717,33735]
===
match
---
name: lower [13906,13911]
name: lower [13906,13911]
===
match
---
simple_stmt [8774,8829]
simple_stmt [8774,8829]
===
match
---
string: "deprecated. Please access the configuration from the 'configuration.conf' object via " [34929,35016]
string: "deprecated. Please access the configuration from the 'configuration.conf' object via " [34929,35016]
===
match
---
atom_expr [32379,32409]
atom_expr [32379,32409]
===
match
---
atom_expr [33180,33195]
atom_expr [33180,33195]
===
match
---
if_stmt [10353,10858]
if_stmt [10353,10858]
===
match
---
parameters [27836,27882]
parameters [27836,27882]
===
match
---
trailer [8794,8798]
trailer [8794,8798]
===
match
---
name: val [28539,28542]
name: val [28539,28542]
===
match
---
trailer [22557,22560]
trailer [22557,22560]
===
match
---
string: 'false' [17692,17699]
string: 'false' [17692,17699]
===
match
---
name: read [19491,19495]
name: read [19491,19495]
===
match
---
parameters [28233,28314]
parameters [28233,28314]
===
match
---
name: upper [11945,11950]
name: upper [11945,11950]
===
match
---
expr_stmt [13448,13478]
expr_stmt [13448,13478]
===
match
---
fstring [17906,17932]
fstring [17906,17932]
===
match
---
string: '{}' [39620,39624]
string: '{}' [39624,39628]
===
match
---
decorator [11293,11307]
decorator [11293,11307]
===
match
---
simple_stmt [13655,13705]
simple_stmt [13655,13705]
===
match
---
suite [22719,22810]
suite [22719,22810]
===
match
---
string: 'log_filename_template' [6194,6217]
string: 'log_filename_template' [6194,6217]
===
match
---
name: has_option [37571,37581]
name: has_option [37575,37585]
===
match
---
name: option [19744,19750]
name: option [19744,19750]
===
match
---
operator: = [21148,21149]
operator: = [21148,21149]
===
match
---
simple_stmt [32816,32856]
simple_stmt [32816,32856]
===
match
---
operator: , [24718,24719]
operator: , [24718,24719]
===
match
---
string: "Accessing configuration method 'getfloat' directly from the configuration module is " [36049,36135]
string: "Accessing configuration method 'getfloat' directly from the configuration module is " [36049,36135]
===
match
---
name: returncode [2745,2755]
name: returncode [2745,2755]
===
match
---
name: environ [32172,32179]
name: environ [32172,32179]
===
match
---
argument [1706,1733]
argument [1706,1733]
===
match
---
suite [22256,22810]
suite [22256,22810]
===
match
---
name: _TEST_PLUGINS_FOLDER [31522,31542]
name: _TEST_PLUGINS_FOLDER [31522,31542]
===
match
---
string: 'The {name} setting in [{section}] has the old default value ' [11424,11486]
string: 'The {name} setting in [{section}] has the old default value ' [11424,11486]
===
match
---
testlist_comp [5839,5867]
testlist_comp [5839,5867]
===
match
---
operator: -> [39844,39846]
operator: -> [39848,39850]
===
match
---
atom_expr [23015,23040]
atom_expr [23015,23040]
===
match
---
import_name [902,912]
import_name [902,912]
===
match
---
name: opt [25765,25768]
name: opt [25765,25768]
===
match
---
name: name [11713,11717]
name: name [11713,11717]
===
match
---
arglist [3313,3340]
arglist [3313,3340]
===
match
---
name: val [21913,21916]
name: val [21913,21916]
===
match
---
strings [37285,37497]
strings [37289,37501]
===
match
---
trailer [31165,31184]
trailer [31165,31184]
===
match
---
trailer [16339,16341]
trailer [16339,16341]
===
match
---
expr_stmt [21361,21409]
expr_stmt [21361,21409]
===
match
---
simple_stmt [32469,32485]
simple_stmt [32469,32485]
===
match
---
name: stacklevel [37969,37979]
name: stacklevel [37973,37983]
===
match
---
trailer [8372,8389]
trailer [8372,8389]
===
match
---
try_stmt [21805,22145]
try_stmt [21805,22145]
===
match
---
string: 'log_processor_filename_template' [6275,6308]
string: 'log_processor_filename_template' [6275,6308]
===
match
---
name: upper [11960,11965]
name: upper [11960,11965]
===
match
---
string: 'default_test.cfg' [3560,3578]
string: 'default_test.cfg' [3560,3578]
===
match
---
operator: = [2462,2463]
operator: = [2462,2463]
===
match
---
suite [28475,28517]
suite [28475,28517]
===
match
---
trailer [33205,33251]
trailer [33205,33251]
===
match
---
trailer [32508,32524]
trailer [32508,32524]
===
match
---
suite [15402,15429]
suite [15402,15429]
===
match
---
name: _TEST_DAGS_FOLDER [31209,31226]
name: _TEST_DAGS_FOLDER [31209,31226]
===
match
---
operator: , [14784,14785]
operator: , [14784,14785]
===
match
---
testlist_star_expr [3405,3445]
testlist_star_expr [3405,3445]
===
match
---
name: option [14452,14458]
name: option [14452,14458]
===
match
---
operator: , [6776,6777]
operator: , [6776,6777]
===
match
---
trailer [25920,25927]
trailer [25920,25927]
===
match
---
suite [35571,35945]
suite [35571,35945]
===
match
---
operator: = [1841,1842]
operator: = [1841,1842]
===
match
---
trailer [40051,40053]
trailer [40055,40057]
===
match
---
atom [22093,22107]
atom [22093,22107]
===
match
---
operator: } [27770,27771]
operator: } [27770,27771]
===
match
---
param [28297,28308]
param [28297,28308]
===
match
---
name: set [38449,38452]
name: set [38453,38456]
===
match
---
string: 'metrics' [6961,6970]
string: 'metrics' [6961,6970]
===
match
---
suite [22443,22503]
suite [22443,22503]
===
match
---
import_name [861,870]
import_name [861,870]
===
match
---
return_stmt [14484,14497]
return_stmt [14484,14497]
===
match
---
trailer [16641,16677]
trailer [16641,16677]
===
match
---
trailer [21189,21198]
trailer [21189,21198]
===
match
---
testlist_comp [6264,6308]
testlist_comp [6264,6308]
===
match
---
name: os [12911,12913]
name: os [12911,12913]
===
match
---
name: DeprecationWarning [34203,34221]
name: DeprecationWarning [34203,34221]
===
match
---
simple_stmt [4450,4770]
simple_stmt [4450,4770]
===
match
---
atom_expr [9870,9961]
atom_expr [9870,9961]
===
match
---
suite [14471,14498]
suite [14471,14498]
===
match
---
trailer [30823,30825]
trailer [30823,30825]
===
match
---
operator: = [13895,13896]
operator: = [13895,13896]
===
match
---
string: 'core' [5919,5925]
string: 'core' [5919,5925]
===
match
---
name: items [21784,21789]
name: items [21784,21789]
===
match
---
trailer [33038,33059]
trailer [33038,33059]
===
match
---
operator: = [4474,4475]
operator: = [4474,4475]
===
match
---
name: int [18074,18077]
name: int [18074,18077]
===
match
---
argument [36699,36711]
argument [36699,36711]
===
match
---
name: getsection [36765,36775]
name: getsection [36765,36775]
===
match
---
param [13833,13841]
param [13833,13841]
===
match
---
string: 'celery' [4591,4599]
string: 'celery' [4591,4599]
===
match
---
name: section [26190,26197]
name: section [26190,26197]
===
match
---
fstring_end: " [10341,10342]
fstring_end: " [10341,10342]
===
match
---
name: source_name [27897,27908]
name: source_name [27897,27908]
===
match
---
atom [6668,6694]
atom [6668,6694]
===
match
---
trailer [31927,31934]
trailer [31927,31934]
===
match
---
except_clause [18091,18108]
except_clause [18091,18108]
===
match
---
name: opt [25832,25835]
name: opt [25832,25835]
===
match
---
name: opt [27173,27176]
name: opt [27173,27176]
===
match
---
trailer [13601,13603]
trailer [13601,13603]
===
match
---
name: ValueError [21860,21870]
name: ValueError [21860,21870]
===
match
---
atom [7260,7288]
atom [7260,7288]
===
match
---
fstring_string: __ [21406,21408]
fstring_string: __ [21406,21408]
===
match
---
atom [4590,4621]
atom [4590,4621]
===
match
---
subscriptlist [3153,3161]
subscriptlist [3153,3161]
===
match
---
trailer [21676,21678]
trailer [21676,21678]
===
match
---
operator: , [10378,10379]
operator: , [10378,10379]
===
match
---
name: os [3260,3262]
name: os [3260,3262]
===
match
---
name: validate [8535,8543]
name: validate [8535,8543]
===
match
---
name: DEFAULT_SECRETS_SEARCH_PATH [1459,1486]
name: DEFAULT_SECRETS_SEARCH_PATH [1459,1486]
===
match
---
string: 'airflow.cfg' [24757,24770]
string: 'airflow.cfg' [24757,24770]
===
match
---
string: 'core' [5318,5324]
string: 'core' [5318,5324]
===
match
---
trailer [25568,25587]
trailer [25568,25587]
===
match
---
name: set [11258,11261]
name: set [11258,11261]
===
match
---
atom_expr [21318,21350]
atom_expr [21318,21350]
===
match
---
atom_expr [31575,31612]
atom_expr [31575,31612]
===
match
---
atom_expr [25564,25601]
atom_expr [25564,25601]
===
match
---
name: _replace_section_config_with_display_sources [28189,28233]
name: _replace_section_config_with_display_sources [28189,28233]
===
match
---
trailer [12375,12383]
trailer [12375,12383]
===
match
---
string: 'log_format' [5975,5987]
string: 'log_format' [5975,5987]
===
match
---
name: compile [7532,7539]
name: compile [7532,7539]
===
match
---
atom_expr [13596,13637]
atom_expr [13596,13637]
===
match
---
name: subprocess [2439,2449]
name: subprocess [2439,2449]
===
match
---
trailer [32434,32447]
trailer [32434,32447]
===
match
---
trailer [2148,2182]
trailer [2148,2182]
===
match
---
name: has_option [14872,14882]
name: has_option [14872,14882]
===
match
---
operator: -> [3144,3146]
operator: -> [3144,3146]
===
match
---
arglist [17496,17518]
arglist [17496,17518]
===
match
---
trailer [17189,17209]
trailer [17189,17209]
===
match
---
suite [30445,30641]
suite [30445,30641]
===
match
---
name: self [17438,17442]
name: self [17438,17442]
===
match
---
trailer [21783,21789]
trailer [21783,21789]
===
match
---
operator: = [33413,33414]
operator: = [33413,33414]
===
match
---
trailer [10177,10201]
trailer [10177,10201]
===
match
---
trailer [20500,20517]
trailer [20500,20517]
===
match
---
name: display_sensitive [25022,25039]
name: display_sensitive [25022,25039]
===
match
---
trailer [1780,1852]
trailer [1780,1852]
===
match
---
return_stmt [37993,38035]
return_stmt [37997,38039]
===
match
---
trailer [8979,8995]
trailer [8979,8995]
===
match
---
string: """Get Config option values from Secret Backend""" [2900,2950]
string: """Get Config option values from Secret Backend""" [2900,2950]
===
match
---
operator: , [27188,27189]
operator: , [27188,27189]
===
match
---
funcdef [30408,30641]
funcdef [30408,30641]
===
match
---
name: generate_key [32435,32447]
name: generate_key [32435,32447]
===
match
---
name: key [15379,15382]
name: key [15379,15382]
===
match
---
string: 'statsd_allow_list' [6852,6871]
string: 'statsd_allow_list' [6852,6871]
===
match
---
name: getint [36363,36369]
name: getint [36363,36369]
===
match
---
operator: = [39992,39993]
operator: = [39996,39997]
===
match
---
name: log [1563,1566]
name: log [1563,1566]
===
match
---
name: get_airflow_home [30280,30296]
name: get_airflow_home [30280,30296]
===
match
---
arglist [19671,19707]
arglist [19671,19707]
===
match
---
parameters [35959,35976]
parameters [35959,35976]
===
match
---
operator: , [25360,25361]
operator: , [25360,25361]
===
match
---
operator: , [6970,6971]
operator: , [6970,6971]
===
match
---
atom_expr [7760,7822]
atom_expr [7760,7822]
===
match
---
suite [14315,14342]
suite [14315,14342]
===
match
---
atom_expr [21667,21678]
atom_expr [21667,21678]
===
match
---
trailer [13603,13614]
trailer [13603,13614]
===
match
---
atom_expr [10934,10959]
atom_expr [10934,10959]
===
match
---
name: warn [29791,29795]
name: warn [29791,29795]
===
match
---
name: section [12135,12142]
name: section [12135,12142]
===
match
---
string: '%' [27185,27188]
string: '%' [27185,27188]
===
match
---
funcdef [29242,30274]
funcdef [29242,30274]
===
match
---
expr_stmt [2115,2182]
expr_stmt [2115,2182]
===
match
---
trailer [3384,3389]
trailer [3384,3389]
===
match
---
fstring [18535,18621]
fstring [18535,18621]
===
match
---
operator: , [6892,6893]
operator: , [6892,6893]
===
match
---
operator: , [15776,15777]
operator: , [15776,15777]
===
match
---
string: 'environment variable and remove the config file entry.' [33581,33637]
string: 'environment variable and remove the config file entry.' [33581,33637]
===
match
---
string: ", " [10808,10812]
string: ", " [10808,10812]
===
match
---
suite [37650,38036]
suite [37654,38040]
===
match
---
arglist [10372,10397]
arglist [10372,10397]
===
match
---
name: section [21736,21743]
name: section [21736,21743]
===
match
---
return_stmt [17119,17132]
return_stmt [17119,17132]
===
match
---
arglist [30556,30583]
arglist [30556,30583]
===
match
---
operator: , [6273,6274]
operator: , [6273,6274]
===
match
---
name: raw [25801,25804]
name: raw [25801,25804]
===
match
---
name: env_var_cmd [12316,12327]
name: env_var_cmd [12316,12327]
===
match
---
name: option [20458,20464]
name: option [20458,20464]
===
match
---
del_stmt [26552,26593]
del_stmt [26552,26593]
===
match
---
operator: , [11010,11011]
operator: , [11010,11011]
===
match
---
name: items [22790,22795]
name: items [22790,22795]
===
match
---
name: deprecated_values [7455,7472]
name: deprecated_values [7455,7472]
===
match
---
string: r'.' [7547,7551]
string: r'.' [7547,7551]
===
match
---
operator: , [15096,15097]
operator: , [15096,15097]
===
match
---
name: get [18013,18016]
name: get [18013,18016]
===
match
---
name: name [8808,8812]
name: name [8808,8812]
===
match
---
comp_op [14614,14620]
comp_op [14614,14620]
===
match
---
comp_if [26765,26806]
comp_if [26765,26806]
===
match
---
operator: = [21376,21377]
operator: = [21376,21377]
===
match
---
suite [14801,15199]
suite [14801,15199]
===
match
---
trailer [16547,16551]
trailer [16547,16551]
===
match
---
trailer [27753,27760]
trailer [27753,27760]
===
match
---
string: 'default_webserver_config.py' [34464,34493]
string: 'default_webserver_config.py' [34464,34493]
===
match
---
operator: , [6850,6851]
operator: , [6850,6851]
===
match
---
atom_expr [27289,27304]
atom_expr [27289,27304]
===
match
---
name: dictionary [19682,19692]
name: dictionary [19682,19692]
===
match
---
if_stmt [21080,21251]
if_stmt [21080,21251]
===
match
---
if_stmt [2052,2091]
if_stmt [2052,2091]
===
match
---
name: get [8795,8798]
name: get [8795,8798]
===
match
---
name: kwargs [36379,36385]
name: kwargs [36379,36385]
===
match
---
string: 'celery' [4632,4640]
string: 'celery' [4632,4640]
===
match
---
operator: = [9003,9004]
operator: = [9003,9004]
===
match
---
atom_expr [15481,15540]
atom_expr [15481,15540]
===
match
---
name: log [32957,32960]
name: log [32957,32960]
===
match
---
operator: , [5225,5226]
operator: , [5225,5226]
===
match
---
trailer [21540,21548]
trailer [21540,21548]
===
match
---
trailer [21161,21199]
trailer [21161,21199]
===
match
---
name: sensitive_config_values [13556,13579]
name: sensitive_config_values [13556,13579]
===
match
---
name: super [16623,16628]
name: super [16623,16628]
===
match
---
name: _section [21139,21147]
name: _section [21139,21147]
===
match
---
argument [31935,31945]
argument [31935,31945]
===
match
---
param [16266,16270]
param [16266,16270]
===
match
---
name: ConfigParser [3988,4000]
name: ConfigParser [3988,4000]
===
match
---
name: name [11201,11205]
name: name [11201,11205]
===
match
---
name: WEBSERVER_CONFIG [34225,34241]
name: WEBSERVER_CONFIG [34225,34241]
===
match
---
testlist_comp [6416,6460]
testlist_comp [6416,6460]
===
match
---
name: kwargs [8276,8282]
name: kwargs [8276,8282]
===
match
---
del_stmt [25956,26000]
del_stmt [25956,26000]
===
match
---
simple_stmt [14662,14730]
simple_stmt [14662,14730]
===
match
---
name: os [12217,12219]
name: os [12217,12219]
===
match
---
simple_stmt [31190,31227]
simple_stmt [31190,31227]
===
match
---
name: info [34332,34336]
name: info [34332,34336]
===
match
---
name: _read_default_config_file [3102,3127]
name: _read_default_config_file [3102,3127]
===
match
---
trailer [27176,27184]
trailer [27176,27184]
===
match
---
name: path [32102,32106]
name: path [32102,32106]
===
match
---
atom_expr [21919,21929]
atom_expr [21919,21929]
===
match
---
operator: , [35545,35546]
operator: , [35545,35546]
===
match
---
trailer [15857,15871]
trailer [15857,15871]
===
match
---
name: deprecated_section [16246,16264]
name: deprecated_section [16246,16264]
===
match
---
subscriptlist [23030,23038]
subscriptlist [23030,23038]
===
match
---
name: current_value [8774,8787]
name: current_value [8774,8787]
===
match
---
name: os [12171,12173]
name: os [12171,12173]
===
match
---
trailer [14545,14595]
trailer [14545,14595]
===
match
---
except_clause [18458,18475]
except_clause [18458,18475]
===
match
---
atom_expr [8790,8828]
atom_expr [8790,8828]
===
match
---
return_stmt [17719,17731]
return_stmt [17719,17731]
===
match
---
name: encoding [19580,19588]
name: encoding [19580,19588]
===
match
---
name: source_name [28504,28515]
name: source_name [28504,28515]
===
match
---
suite [1883,2300]
suite [1883,2300]
===
match
---
name: DeprecationWarning [37089,37107]
name: DeprecationWarning [37089,37107]
===
match
---
name: option [15828,15834]
name: option [15828,15834]
===
match
---
if_stmt [32632,32914]
if_stmt [32632,32914]
===
match
---
operator: , [23033,23034]
operator: , [23033,23034]
===
match
---
operator: , [37165,37166]
operator: , [37169,37170]
===
match
---
name: read [19545,19549]
name: read [19545,19549]
===
match
---
arglist [26190,26202]
arglist [26190,26202]
===
match
---
argument [8317,8325]
argument [8317,8325]
===
match
---
comparison [17087,17105]
comparison [17087,17105]
===
match
---
expr_stmt [31500,31542]
expr_stmt [31500,31542]
===
match
---
suite [17993,18310]
suite [17993,18310]
===
match
---
string: 'backend_kwargs' [39593,39609]
string: 'backend_kwargs' [39597,39613]
===
match
---
name: dirname [31380,31387]
name: dirname [31380,31387]
===
match
---
name: new_section [30154,30165]
name: new_section [30154,30165]
===
match
---
string: 'plugins' [31443,31452]
string: 'plugins' [31443,31452]
===
match
---
string: 'fab_logging_level' [5617,5636]
string: 'fab_logging_level' [5617,5636]
===
match
---
arglist [24840,24884]
arglist [24840,24884]
===
match
---
operator: , [7559,7560]
operator: , [7559,7560]
===
match
---
trailer [21403,21405]
trailer [21403,21405]
===
match
---
parameters [15735,15791]
parameters [15735,15791]
===
match
---
name: val [18078,18081]
name: val [18078,18081]
===
match
---
atom_expr [10624,10857]
atom_expr [10624,10857]
===
match
---
param [13360,13365]
param [13360,13365]
===
match
---
arglist [26939,26951]
arglist [26939,26951]
===
match
---
atom [17622,17640]
atom [17622,17640]
===
match
---
operator: , [36661,36662]
operator: , [36661,36662]
===
match
---
name: _section [22192,22200]
name: _section [22192,22200]
===
match
---
operator: , [6374,6375]
operator: , [6374,6375]
===
match
---
string: 'utf-8' [3333,3340]
string: 'utf-8' [3333,3340]
===
match
---
operator: , [35478,35479]
operator: , [35478,35479]
===
match
---
number: 3 [30257,30258]
number: 3 [30257,30258]
===
match
---
parameters [34743,34745]
parameters [34743,34745]
===
match
---
raise_stmt [2651,2819]
raise_stmt [2651,2819]
===
match
---
argument [9024,9043]
argument [9024,9043]
===
match
---
name: _replace_section_config_with_display_sources [28012,28056]
name: _replace_section_config_with_display_sources [28012,28056]
===
match
---
name: old [10934,10937]
name: old [10934,10937]
===
match
---
simple_stmt [16065,16136]
simple_stmt [16065,16136]
===
match
---
simple_stmt [29011,29063]
simple_stmt [29011,29063]
===
match
---
argument [35513,35521]
argument [35513,35521]
===
match
---
name: super [16804,16809]
name: super [16804,16809]
===
match
---
expr_stmt [21226,21250]
expr_stmt [21226,21250]
===
match
---
name: warnings [34175,34183]
name: warnings [34175,34183]
===
match
---
name: category [34194,34202]
name: category [34194,34202]
===
match
---
arglist [34606,34630]
arglist [34606,34630]
===
match
---
name: NoSectionError [1154,1168]
name: NoSectionError [1154,1168]
===
match
---
arglist [9620,9638]
arglist [9620,9638]
===
match
---
name: ValueError [18465,18475]
name: ValueError [18465,18475]
===
match
---
operator: ** [36377,36379]
operator: ** [36377,36379]
===
match
---
testlist_comp [6504,6529]
testlist_comp [6504,6529]
===
match
---
name: collections [963,974]
name: collections [963,974]
===
match
---
name: TEMPLATE_START [32885,32899]
name: TEMPLATE_START [32885,32899]
===
match
---
return_stmt [2825,2838]
return_stmt [2825,2838]
===
match
---
atom [27761,27771]
atom [27761,27771]
===
match
---
operator: = [31573,31574]
operator: = [31573,31574]
===
match
---
testlist_comp [6805,6835]
testlist_comp [6805,6835]
===
match
---
name: format [11684,11690]
name: format [11684,11690]
===
match
---
string: '<dict>' [19634,19642]
string: '<dict>' [19634,19642]
===
match
---
atom_expr [13291,13311]
atom_expr [13291,13311]
===
match
---
fstring_expr [2710,2719]
fstring_expr [2710,2719]
===
match
---
string: 'celery' [5079,5087]
string: 'celery' [5079,5087]
===
match
---
param [11353,11367]
param [11353,11367]
===
match
---
expr_stmt [8500,8525]
expr_stmt [8500,8525]
===
match
---
trailer [21279,21288]
trailer [21279,21288]
===
match
---
return_stmt [38406,38442]
return_stmt [38410,38446]
===
match
---
name: self [20685,20689]
name: self [20685,20689]
===
match
---
operator: , [14107,14108]
operator: , [14107,14108]
===
match
---
trailer [39213,39215]
trailer [39217,39219]
===
match
---
name: stacklevel [36295,36305]
name: stacklevel [36295,36305]
===
match
---
operator: = [22970,22971]
operator: = [22970,22971]
===
match
---
string: 'AIRFLOW_TEST_CONFIG' [32043,32064]
string: 'AIRFLOW_TEST_CONFIG' [32043,32064]
===
match
---
parameters [35539,35556]
parameters [35539,35556]
===
match
---
operator: = [2285,2286]
operator: = [2285,2286]
===
match
---
testlist_comp [26104,26116]
testlist_comp [26104,26116]
===
match
---
atom_expr [35207,35485]
atom_expr [35207,35485]
===
match
---
atom_expr [8360,8389]
atom_expr [8360,8389]
===
match
---
name: run_command [13291,13302]
name: run_command [13291,13302]
===
match
---
arglist [11424,11843]
arglist [11424,11843]
===
match
---
name: new_value [11018,11027]
name: new_value [11018,11027]
===
match
---
expr_stmt [9574,9721]
expr_stmt [9574,9721]
===
match
---
simple_stmt [15689,15701]
simple_stmt [15689,15701]
===
match
---
return_stmt [16518,16576]
return_stmt [16518,16576]
===
match
---
name: int [20738,20741]
name: int [20738,20741]
===
match
---
atom_expr [16789,16862]
atom_expr [16789,16862]
===
match
---
if_stmt [17545,17604]
if_stmt [17545,17604]
===
match
---
trailer [28834,28846]
trailer [28834,28846]
===
match
---
name: secrets_client [3058,3072]
name: secrets_client [3058,3072]
===
match
---
if_stmt [1636,1853]
if_stmt [1636,1853]
===
match
---
string: 'log_format' [5999,6011]
string: 'log_format' [5999,6011]
===
match
---
name: new_value [8911,8920]
name: new_value [8911,8920]
===
match
---
suite [30299,30406]
suite [30299,30406]
===
match
---
name: section [17062,17069]
name: section [17062,17069]
===
match
---
fstring_string: Current value: " [19427,19443]
fstring_string: Current value: " [19427,19443]
===
match
---
name: _warn_deprecate [17302,17317]
name: _warn_deprecate [17302,17317]
===
match
---
trailer [10185,10200]
trailer [10185,10200]
===
match
---
param [16919,16924]
param [16919,16924]
===
match
---
parameters [26616,26678]
parameters [26616,26678]
===
match
---
operator: = [9299,9300]
operator: = [9299,9300]
===
match
---
operator: ** [16566,16568]
operator: ** [16566,16568]
===
match
---
operator: = [8788,8789]
operator: = [8788,8789]
===
match
---
param [15255,15274]
param [15255,15274]
===
match
---
trailer [27683,27689]
trailer [27683,27689]
===
match
---
name: AIRFLOW_HOME [32249,32261]
name: AIRFLOW_HOME [32249,32261]
===
match
---
comp_op [10960,10966]
comp_op [10960,10966]
===
match
---
arglist [16086,16134]
arglist [16086,16134]
===
match
---
param [29276,29295]
param [29276,29295]
===
match
---
name: key [14427,14430]
name: key [14427,14430]
===
match
---
name: _get_cmd_option [15974,15989]
name: _get_cmd_option [15974,15989]
===
match
---
if_stmt [29322,30274]
if_stmt [29322,30274]
===
match
---
trailer [30363,30371]
trailer [30363,30371]
===
match
---
operator: , [1309,1310]
operator: , [1309,1310]
===
match
---
operator: , [5136,5137]
operator: , [5136,5137]
===
match
---
simple_stmt [1377,1431]
simple_stmt [1377,1431]
===
match
---
string: 'colored_formatter_class' [5927,5952]
string: 'colored_formatter_class' [5927,5952]
===
match
---
arglist [30024,30174]
arglist [30024,30174]
===
match
---
trailer [3840,3845]
trailer [3840,3845]
===
match
---
name: raw [28435,28438]
name: raw [28435,28438]
===
match
---
name: AirflowConfigParser [27992,28011]
name: AirflowConfigParser [27992,28011]
===
match
---
parameters [2317,2326]
parameters [2317,2326]
===
match
---
fstring_string: Output:  [2774,2782]
fstring_string: Output:  [2774,2782]
===
match
---
trailer [9619,9639]
trailer [9619,9639]
===
match
---
name: section [21190,21197]
name: section [21190,21197]
===
match
---
if_stmt [25099,25207]
if_stmt [25099,25207]
===
match
---
fstring_expr [18287,18292]
fstring_expr [18287,18292]
===
match
---
trailer [3072,3083]
trailer [3072,3083]
===
match
---
trailer [11261,11287]
trailer [11261,11287]
===
match
---
trailer [22660,22666]
trailer [22660,22666]
===
match
---
atom_expr [22541,22560]
atom_expr [22541,22560]
===
match
---
atom [6540,6564]
atom [6540,6564]
===
match
---
atom [6696,6724]
atom [6696,6724]
===
match
---
operator: , [7272,7273]
operator: , [7272,7273]
===
match
---
comparison [12448,12494]
comparison [12448,12494]
===
match
---
if_stmt [17141,17398]
if_stmt [17141,17398]
===
match
---
atom_expr [36434,36718]
atom_expr [36434,36718]
===
match
---
name: conf [38413,38417]
name: conf [38417,38421]
===
match
---
name: self [22624,22628]
name: self [22624,22628]
===
match
---
name: warning [15038,15045]
name: warning [15038,15045]
===
match
---
operator: = [15835,15836]
operator: = [15835,15836]
===
match
---
expr_stmt [39979,39996]
expr_stmt [39983,40000]
===
match
---
trailer [26527,26539]
trailer [26527,26539]
===
match
---
suite [21609,21645]
suite [21609,21645]
===
match
---
operator: , [22975,22976]
operator: , [22975,22976]
===
match
---
arglist [27185,27194]
arglist [27185,27194]
===
match
---
name: config_sources [25960,25974]
name: config_sources [25960,25974]
===
match
---
name: path [31087,31091]
name: path [31087,31091]
===
match
---
name: opt [25558,25561]
name: opt [25558,25561]
===
match
---
operator: , [12456,12457]
operator: , [12456,12457]
===
match
---
name: key [21661,21664]
name: key [21661,21664]
===
match
---
atom_expr [29399,29674]
atom_expr [29399,29674]
===
match
---
arglist [14391,14439]
arglist [14391,14439]
===
match
---
name: deprecated_key [16010,16024]
name: deprecated_key [16010,16024]
===
match
---
string: "Accessing configuration method 'getsection' directly from the configuration module is " [36867,36955]
string: "Accessing configuration method 'getsection' directly from the configuration module is " [36867,36955]
===
match
---
operator: , [16660,16661]
operator: , [16660,16661]
===
match
---
name: strip [17596,17601]
name: strip [17596,17601]
===
match
---
name: stacklevel [38382,38392]
name: stacklevel [38386,38396]
===
match
---
operator: { [2736,2737]
operator: { [2736,2737]
===
match
---
return_stmt [13788,13799]
return_stmt [13788,13799]
===
match
---
name: self [15736,15740]
name: self [15736,15740]
===
match
---
operator: * [35506,35507]
operator: * [35506,35507]
===
match
---
fstring_expr [10321,10341]
fstring_expr [10321,10341]
===
match
---
param [11999,12004]
param [11999,12004]
===
match
---
name: write [22210,22215]
name: write [22210,22215]
===
match
---
atom_expr [40105,40147]
atom_expr [40109,40151]
===
match
---
name: section [14587,14594]
name: section [14587,14594]
===
match
---
atom_expr [8336,8357]
atom_expr [8336,8357]
===
match
---
name: key [17978,17981]
name: key [17978,17981]
===
match
---
simple_stmt [10618,10858]
simple_stmt [10618,10858]
===
match
---
atom_expr [32864,32913]
atom_expr [32864,32913]
===
match
---
testlist_comp [24709,24741]
testlist_comp [24709,24741]
===
match
---
operator: } [7569,7570]
operator: } [7569,7570]
===
match
---
operator: , [21766,21767]
operator: , [21766,21767]
===
match
---
atom_expr [22624,22644]
atom_expr [22624,22644]
===
match
---
arglist [8373,8388]
arglist [8373,8388]
===
match
---
operator: , [37587,37588]
operator: , [37591,37592]
===
match
---
name: kwargs [17460,17466]
name: kwargs [17460,17466]
===
match
---
name: AIRFLOW_CONFIG [33236,33250]
name: AIRFLOW_CONFIG [33236,33250]
===
match
---
simple_stmt [15580,15651]
simple_stmt [15580,15651]
===
match
---
operator: { [39718,39719]
operator: { [39722,39723]
===
match
---
operator: , [16964,16965]
operator: , [16964,16965]
===
match
---
operator: , [35078,35079]
operator: , [35078,35079]
===
match
---
operator: , [18716,18717]
operator: , [18716,18717]
===
match
---
simple_stmt [26552,26594]
simple_stmt [26552,26594]
===
match
---
simple_stmt [8733,8758]
simple_stmt [8733,8758]
===
match
---
name: _env_var_name [12121,12134]
name: _env_var_name [12121,12134]
===
match
---
comparison [33746,33794]
comparison [33746,33794]
===
match
---
suite [13206,13312]
suite [13206,13312]
===
match
---
name: self [14516,14520]
name: self [14516,14520]
===
match
---
atom_expr [31354,31454]
atom_expr [31354,31454]
===
match
---
name: items [21335,21340]
name: items [21335,21340]
===
match
---
name: sensitive_config_values [25521,25544]
name: sensitive_config_values [25521,25544]
===
match
---
trailer [24802,24839]
trailer [24802,24839]
===
match
---
string: 'tests' [31434,31441]
string: 'tests' [31434,31441]
===
match
---
string: 'scheduler' [7000,7011]
string: 'scheduler' [7000,7011]
===
match
---
name: log [29118,29121]
name: log [29118,29121]
===
match
---
trailer [28745,28750]
trailer [28745,28750]
===
match
---
import_name [913,928]
import_name [913,928]
===
match
---
operator: @ [11293,11294]
operator: @ [11293,11294]
===
match
---
operator: , [16728,16729]
operator: , [16728,16729]
===
match
---
operator: = [36305,36306]
operator: = [36305,36306]
===
match
---
name: subprocess [2384,2394]
name: subprocess [2384,2394]
===
match
---
expr_stmt [24684,24788]
expr_stmt [24684,24788]
===
match
---
name: _warn_deprecate [29246,29261]
name: _warn_deprecate [29246,29261]
===
match
---
name: self [8975,8979]
name: self [8975,8979]
===
match
---
simple_stmt [846,861]
simple_stmt [846,861]
===
match
---
operator: , [13109,13110]
operator: , [13109,13110]
===
match
---
param [35153,35161]
param [35153,35161]
===
match
---
string: "deprecated. Please access the configuration from the 'configuration.conf' object via " [35320,35407]
string: "deprecated. Please access the configuration from the 'configuration.conf' object via " [35320,35407]
===
match
---
name: DeprecationWarning [37507,37525]
name: DeprecationWarning [37511,37529]
===
match
---
operator: , [3222,3223]
operator: , [3222,3223]
===
match
---
name: JSONDecodeError [39655,39670]
name: JSONDecodeError [39659,39674]
===
match
---
operator: , [30921,30922]
operator: , [30921,30922]
===
match
---
argument [35506,35511]
argument [35506,35511]
===
match
---
trailer [31577,31582]
trailer [31577,31582]
===
match
---
atom [5509,5537]
atom [5509,5537]
===
match
---
trailer [39569,39625]
trailer [39573,39629]
===
match
---
name: stream [2523,2529]
name: stream [2523,2529]
===
match
---
operator: , [4621,4622]
operator: , [4621,4622]
===
match
---
atom_expr [9930,9958]
atom_expr [9930,9958]
===
match
---
operator: , [30258,30259]
operator: , [30258,30259]
===
match
---
atom_expr [20708,20757]
atom_expr [20708,20757]
===
match
---
atom_expr [27704,27772]
atom_expr [27704,27772]
===
match
---
simple_stmt [3035,3047]
simple_stmt [3035,3047]
===
match
---
parameters [22215,22255]
parameters [22215,22255]
===
match
---
simple_stmt [39730,39792]
simple_stmt [39734,39796]
===
match
---
funcdef [17423,17947]
funcdef [17423,17947]
===
match
---
name: get [13678,13681]
name: get [13678,13681]
===
match
---
atom_expr [31068,31128]
atom_expr [31068,31128]
===
match
---
operator: , [7011,7012]
operator: , [7011,7012]
===
match
---
string: 'Creating new FAB webserver config file in: %s' [34337,34384]
string: 'Creating new FAB webserver config file in: %s' [34337,34384]
===
match
---
expr_stmt [25684,25702]
expr_stmt [25684,25702]
===
match
---
name: key [15867,15870]
name: key [15867,15870]
===
match
---
except_clause [20058,20096]
except_clause [20058,20096]
===
match
---
operator: } [7949,7950]
operator: } [7949,7950]
===
match
---
operator: = [33294,33295]
operator: = [33294,33295]
===
match
---
atom_expr [21711,21749]
atom_expr [21711,21749]
===
match
---
name: section [13866,13873]
name: section [13866,13873]
===
match
---
not_test [27024,27045]
not_test [27024,27045]
===
match
---
name: args [35541,35545]
name: args [35541,35545]
===
match
---
trailer [3083,3095]
trailer [3083,3095]
===
match
---
name: key [39430,39433]
name: key [39434,39437]
===
match
---
trailer [30375,30404]
trailer [30375,30404]
===
match
---
name: Union [1318,1323]
name: Union [1318,1323]
===
match
---
name: deprecated_section [16816,16834]
name: deprecated_section [16816,16834]
===
match
---
import_from [1270,1323]
import_from [1270,1323]
===
match
---
name: alternative_secrets_config_dict [39499,39530]
name: alternative_secrets_config_dict [39503,39534]
===
match
---
trailer [19670,19708]
trailer [19670,19708]
===
match
---
testlist_comp [26717,26806]
testlist_comp [26717,26806]
===
match
---
name: sensitive_config_values [12471,12494]
name: sensitive_config_values [12471,12494]
===
match
---
string: 'base_log_folder' [5187,5204]
string: 'base_log_folder' [5187,5204]
===
match
---
fstring_string: , Stderr:  [2790,2800]
fstring_string: , Stderr:  [2790,2800]
===
match
---
operator: , [9307,9308]
operator: , [9307,9308]
===
match
---
string: 'secrets' [39419,39428]
string: 'secrets' [39423,39432]
===
match
---
suite [40199,40307]
suite [40203,40311]
===
match
---
name: sqlite3 [10178,10185]
name: sqlite3 [10178,10185]
===
match
---
name: raw [22913,22916]
name: raw [22913,22916]
===
match
---
operator: , [11815,11816]
operator: , [11815,11816]
===
match
---
not_test [32635,32671]
not_test [32635,32671]
===
match
---
name: OrderedDict [21150,21161]
name: OrderedDict [21150,21161]
===
match
---
operator: ** [38433,38435]
operator: ** [38437,38439]
===
match
---
simple_stmt [19128,19140]
simple_stmt [19128,19140]
===
match
---
name: join [3765,3769]
name: join [3765,3769]
===
match
---
return_stmt [38825,38857]
return_stmt [38829,38861]
===
match
---
name: section [26939,26946]
name: section [26939,26946]
===
match
---
operator: ** [14720,14722]
operator: ** [14720,14722]
===
match
---
atom_expr [19653,19708]
atom_expr [19653,19708]
===
match
---
name: display_source [22850,22864]
name: display_source [22850,22864]
===
match
---
simple_stmt [3051,3096]
simple_stmt [3051,3096]
===
match
---
string: 'config_templates' [3224,3242]
string: 'config_templates' [3224,3242]
===
match
---
parameters [39279,39281]
parameters [39283,39285]
===
match
---
name: deprecated_key [15239,15253]
name: deprecated_key [15239,15253]
===
match
---
atom [6630,6658]
atom [6630,6658]
===
match
---
testlist_comp [6765,6793]
testlist_comp [6765,6793]
===
match
---
parameters [8239,8283]
parameters [8239,8283]
===
match
---
param [11379,11386]
param [11379,11386]
===
match
---
name: custom_secret_backend [40125,40146]
name: custom_secret_backend [40129,40150]
===
match
---
operator: , [1137,1138]
operator: , [1137,1138]
===
match
---
name: fallback_key [13691,13703]
name: fallback_key [13691,13703]
===
match
---
operator: , [2478,2479]
operator: , [2478,2479]
===
match
---
string: 'metrics' [7049,7058]
string: 'metrics' [7049,7058]
===
match
---
operator: , [22644,22645]
operator: , [22644,22645]
===
match
---
trailer [25835,25843]
trailer [25835,25843]
===
match
---
trailer [27760,27772]
trailer [27760,27772]
===
match
---
atom_expr [7624,7665]
atom_expr [7624,7665]
===
match
---
name: TEST_CONFIG [29049,29060]
name: TEST_CONFIG [29049,29060]
===
match
---
simple_stmt [884,902]
simple_stmt [884,902]
===
match
---
operator: , [13002,13003]
operator: , [13002,13003]
===
match
---
name: old [8930,8933]
name: old [8930,8933]
===
match
---
operator: , [16559,16560]
operator: , [16559,16560]
===
match
---
return_stmt [16871,16882]
return_stmt [16871,16882]
===
match
---
arglist [34143,34165]
arglist [34143,34165]
===
match
---
name: isfile [34298,34304]
name: isfile [34298,34304]
===
match
---
name: new_value [11775,11784]
name: new_value [11775,11784]
===
match
---
name: FERNET_KEY [32415,32425]
name: FERNET_KEY [32415,32425]
===
match
---
param [8544,8548]
param [8544,8548]
===
match
---
name: AirflowConfigException [10261,10283]
name: AirflowConfigException [10261,10283]
===
match
---
name: template [31919,31927]
name: template [31919,31927]
===
match
---
arglist [20501,20516]
arglist [20501,20516]
===
match
---
atom_expr [2737,2755]
atom_expr [2737,2755]
===
match
---
atom_expr [30361,30404]
atom_expr [30361,30404]
===
match
---
atom_expr [23025,23039]
atom_expr [23025,23039]
===
match
---
operator: , [7140,7141]
operator: , [7140,7141]
===
match
---
operator: { [18231,18232]
operator: { [18231,18232]
===
match
---
operator: = [13958,13959]
operator: = [13958,13959]
===
match
---
trailer [18517,18678]
trailer [18517,18678]
===
match
---
operator: , [38372,38373]
operator: , [38376,38377]
===
match
---
string: 'core' [33380,33386]
string: 'core' [33380,33386]
===
match
---
trailer [2594,2606]
trailer [2594,2606]
===
match
---
operator: , [15781,15782]
operator: , [15781,15782]
===
match
---
suite [19528,19590]
suite [19528,19590]
===
match
---
atom_expr [21695,21708]
atom_expr [21695,21708]
===
match
---
simple_stmt [17719,17732]
simple_stmt [17719,17732]
===
match
---
funcdef [20670,22201]
funcdef [20670,22201]
===
match
---
name: OrderedDict [27739,27750]
name: OrderedDict [27739,27750]
===
match
---
funcdef [15204,15701]
funcdef [15204,15701]
===
match
---
name: section [15783,15790]
name: section [15783,15790]
===
match
---
name: read_string [8463,8474]
name: read_string [8463,8474]
===
match
---
trailer [11944,11950]
trailer [11944,11950]
===
match
---
string: """     Generates a configuration from the provided template + variables defined in     current scope      :param template: a config content templated with {{variables}}     """ [31655,31832]
string: """     Generates a configuration from the provided template + variables defined in     current scope      :param template: a config content templated with {{variables}}     """ [31655,31832]
===
match
---
atom_expr [14941,15006]
atom_expr [14941,15006]
===
match
---
simple_stmt [22042,22053]
simple_stmt [22042,22053]
===
match
---
arglist [14546,14594]
arglist [14546,14594]
===
match
---
name: run_command [12519,12530]
name: run_command [12519,12530]
===
match
---
name: deprecated_key [16925,16939]
name: deprecated_key [16925,16939]
===
match
---
operator: , [34192,34193]
operator: , [34192,34193]
===
match
---
if_stmt [16038,16166]
if_stmt [16038,16166]
===
match
---
operator: + [13467,13468]
operator: + [13467,13468]
===
match
---
atom_expr [33746,33778]
atom_expr [33746,33778]
===
match
---
argument [9013,9022]
argument [9013,9022]
===
match
---
testlist_comp [5575,5605]
testlist_comp [5575,5605]
===
match
---
argument [37969,37981]
argument [37973,37985]
===
match
---
operator: , [17626,17627]
operator: , [17626,17627]
===
match
---
atom_expr [13233,13267]
atom_expr [13233,13267]
===
match
---
name: key [13828,13831]
name: key [13828,13831]
===
match
---
string: "'conf.as_dict'" [38328,38344]
string: "'conf.as_dict'" [38332,38348]
===
match
---
simple_stmt [34119,34167]
simple_stmt [34119,34167]
===
match
---
operator: , [11016,11017]
operator: , [11016,11017]
===
match
---
name: display_source [27862,27876]
name: display_source [27862,27876]
===
match
---
simple_stmt [20038,20050]
simple_stmt [20038,20050]
===
match
---
name: TEST_DAGS_FOLDER [31190,31206]
name: TEST_DAGS_FOLDER [31190,31206]
===
match
---
name: kwargs [36751,36757]
name: kwargs [36751,36757]
===
match
---
string: 'metrics' [6541,6550]
string: 'metrics' [6541,6550]
===
match
---
arglist [13245,13266]
arglist [13245,13266]
===
match
---
name: dirname [31396,31403]
name: dirname [31396,31403]
===
match
---
name: self [8336,8340]
name: self [8336,8340]
===
match
---
trailer [25927,25939]
trailer [25927,25939]
===
match
---
name: Fernet [1369,1375]
name: Fernet [1369,1375]
===
match
---
param [28243,28250]
param [28243,28250]
===
match
---
operator: , [16264,16265]
operator: , [16264,16265]
===
match
---
string: 'celery' [4557,4565]
string: 'celery' [4557,4565]
===
match
---
operator: = [24671,24672]
operator: = [24671,24672]
===
match
---
comparison [2194,2217]
comparison [2194,2217]
===
match
---
atom_expr [11937,11952]
atom_expr [11937,11952]
===
match
---
name: min_sqlite_version [10322,10340]
name: min_sqlite_version [10322,10340]
===
match
---
string: 'kubernetes_environment_variables' [27622,27656]
string: 'kubernetes_environment_variables' [27622,27656]
===
match
---
name: deprecated_section [14407,14425]
name: deprecated_section [14407,14425]
===
match
---
name: self [25128,25132]
name: self [25128,25132]
===
match
---
operator: , [4493,4494]
operator: , [4493,4494]
===
match
---
funcdef [31957,32204]
funcdef [31957,32204]
===
match
---
simple_stmt [39877,39975]
simple_stmt [39881,39979]
===
match
---
testlist_comp [7131,7169]
testlist_comp [7131,7169]
===
match
---
operator: , [14713,14714]
operator: , [14713,14714]
===
match
---
name: getsection [22770,22780]
name: getsection [22770,22780]
===
match
---
name: key [16561,16564]
name: key [16561,16564]
===
match
---
trailer [32353,32371]
trailer [32353,32371]
===
match
---
testlist_comp [5473,5498]
testlist_comp [5473,5498]
===
match
---
simple_stmt [3168,3244]
simple_stmt [3168,3244]
===
match
---
name: environ [30519,30526]
name: environ [30519,30526]
===
match
---
trailer [36034,36039]
trailer [36034,36039]
===
match
---
name: re [7624,7626]
name: re [7624,7626]
===
match
---
operator: = [18006,18007]
operator: = [18006,18007]
===
match
---
string: 'tests' [31130,31137]
string: 'tests' [31130,31137]
===
match
---
name: option [14184,14190]
name: option [14184,14190]
===
match
---
testlist_comp [5991,6011]
testlist_comp [5991,6011]
===
match
---
string: "Accessing configuration method 'as_dict' directly from the configuration module is " [38138,38223]
string: "Accessing configuration method 'as_dict' directly from the configuration module is " [38142,38227]
===
match
---
name: section [25588,25595]
name: section [25588,25595]
===
match
---
operator: = [9160,9161]
operator: = [9160,9161]
===
match
---
trailer [17592,17595]
trailer [17592,17595]
===
match
---
name: warnings [37690,37698]
name: warnings [37694,37702]
===
match
---
name: str [2168,2171]
name: str [2168,2171]
===
match
---
atom_expr [19284,19481]
atom_expr [19284,19481]
===
match
---
name: display_sensitive [25167,25184]
name: display_sensitive [25167,25184]
===
match
---
name: self [19729,19733]
name: self [19729,19733]
===
match
---
operator: , [7236,7237]
operator: , [7236,7237]
===
match
---
suite [26090,26594]
suite [26090,26594]
===
match
---
name: config_sources [28251,28265]
name: config_sources [28251,28265]
===
match
---
trailer [24724,24741]
trailer [24724,24741]
===
match
---
operator: = [35476,35477]
operator: = [35476,35477]
===
match
---
decorated [27778,28162]
decorated [27778,28162]
===
match
---
trailer [21670,21676]
trailer [21670,21676]
===
match
---
name: _delimiters [22487,22498]
name: _delimiters [22487,22498]
===
match
---
simple_stmt [15116,15199]
simple_stmt [15116,15199]
===
match
---
atom_expr [40264,40306]
atom_expr [40268,40310]
===
match
---
name: has_option [20552,20562]
name: has_option [20552,20562]
===
match
---
operator: = [22539,22540]
operator: = [22539,22540]
===
match
---
operator: , [35511,35512]
operator: , [35511,35512]
===
match
---
operator: , [26672,26673]
operator: , [26672,26673]
===
match
---
suite [13148,13312]
suite [13148,13312]
===
match
---
operator: , [14261,14262]
operator: , [14261,14262]
===
match
---
testlist_comp [6567,6591]
testlist_comp [6567,6591]
===
match
---
decorated [11293,11854]
decorated [11293,11854]
===
match
---
name: class_name [40244,40254]
name: class_name [40248,40258]
===
match
---
if_stmt [21260,21352]
if_stmt [21260,21352]
===
match
---
name: space_around_delimiters [22419,22442]
name: space_around_delimiters [22419,22442]
===
match
---
simple_stmt [26471,26540]
simple_stmt [26471,26540]
===
match
---
atom_expr [14036,14117]
atom_expr [14036,14117]
===
match
---
simple_stmt [31030,31148]
simple_stmt [31030,31148]
===
match
---
trailer [37581,37598]
trailer [37585,37602]
===
match
---
trailer [15144,15198]
trailer [15144,15198]
===
match
---
string: """Custom Airflow Configparser supporting defaults and deprecated options""" [4045,4121]
string: """Custom Airflow Configparser supporting defaults and deprecated options""" [4045,4121]
===
match
---
name: _update_env_var [8980,8995]
name: _update_env_var [8980,8995]
===
match
---
fstring_end: ' [18620,18621]
fstring_end: ' [18620,18621]
===
match
---
name: section [27730,27737]
name: section [27730,27737]
===
match
---
atom [31848,31907]
atom [31848,31907]
===
match
---
string: 'The {old_key} option in [{old_section}] has been moved to the {new_key} option in ' [29813,29897]
string: 'The {old_key} option in [{old_section}] has been moved to the {new_key} option in ' [29813,29897]
===
match
---
string: 'broker_url' [4567,4579]
string: 'broker_url' [4567,4579]
===
match
---
name: templates_dir [3168,3181]
name: templates_dir [3168,3181]
===
match
---
simple_stmt [8500,8526]
simple_stmt [8500,8526]
===
match
---
name: self [17185,17189]
name: self [17185,17189]
===
match
---
strings [18535,18664]
strings [18535,18664]
===
match
---
atom [12448,12462]
atom [12448,12462]
===
match
---
param [16966,16973]
param [16966,16973]
===
match
---
suite [33068,33196]
suite [33068,33196]
===
match
---
operator: = [33716,33717]
operator: = [33716,33717]
===
match
---
name: self [22836,22840]
name: self [22836,22840]
===
match
---
testlist_comp [12803,12815]
testlist_comp [12803,12815]
===
match
---
name: dictionary [19671,19681]
name: dictionary [19671,19681]
===
match
---
trailer [21087,21104]
trailer [21087,21104]
===
match
---
simple_stmt [929,958]
simple_stmt [929,958]
===
match
---
name: new [8935,8938]
name: new [8935,8938]
===
match
---
operator: = [19681,19682]
operator: = [19681,19682]
===
match
---
expr_stmt [8911,8954]
expr_stmt [8911,8954]
===
match
---
name: str [20733,20736]
name: str [20733,20736]
===
match
---
return_stmt [39730,39791]
return_stmt [39734,39795]
===
match
---
name: section [14982,14989]
name: section [14982,14989]
===
match
---
name: configs [27853,27860]
name: configs [27853,27860]
===
match
---
simple_stmt [33197,33252]
simple_stmt [33197,33252]
===
match
---
testlist_comp [4557,4579]
testlist_comp [4557,4579]
===
match
---
string: r':' [7540,7544]
string: r':' [7540,7544]
===
match
---
name: get [19040,19043]
name: get [19040,19043]
===
match
---
try_stmt [26830,27009]
try_stmt [26830,27009]
===
match
---
name: key [16961,16964]
name: key [16961,16964]
===
match
---
name: DeprecationWarning [35060,35078]
name: DeprecationWarning [35060,35078]
===
match
---
argument [33708,33735]
argument [33708,33735]
===
match
---
arglist [34189,34221]
arglist [34189,34221]
===
match
---
funcdef [37601,38036]
funcdef [37605,38040]
===
match
---
expr_stmt [33077,33119]
expr_stmt [33077,33119]
===
match
---
expr_stmt [17028,17075]
expr_stmt [17028,17075]
===
match
---
testlist_comp [27250,27264]
testlist_comp [27250,27264]
===
match
---
trailer [14705,14729]
trailer [14705,14729]
===
match
---
name: _get_config_value_from_secret_backend [2845,2882]
name: _get_config_value_from_secret_backend [2845,2882]
===
match
---
name: raw [27878,27881]
name: raw [27878,27881]
===
match
---
simple_stmt [15960,16026]
simple_stmt [15960,16026]
===
match
---
operator: { [7711,7712]
operator: { [7711,7712]
===
match
---
name: environ [12376,12383]
name: environ [12376,12383]
===
match
---
name: expand_env_var [30346,30360]
name: expand_env_var [30346,30360]
===
match
---
operator: , [6143,6144]
operator: , [6143,6144]
===
match
---
operator: , [5367,5368]
operator: , [5367,5368]
===
match
---
operator: , [20167,20168]
operator: , [20167,20168]
===
match
---
name: key [21630,21633]
name: key [21630,21633]
===
match
---
name: kwargs [13835,13841]
name: kwargs [13835,13841]
===
match
---
simple_stmt [33128,33172]
simple_stmt [33128,33172]
===
match
---
operator: , [3322,3323]
operator: , [3322,3323]
===
match
---
argument [35881,35893]
argument [35881,35893]
===
match
---
name: _env_var_name [11881,11894]
name: _env_var_name [11881,11894]
===
match
---
expr_stmt [31237,31290]
expr_stmt [31237,31290]
===
match
---
name: _UNSET [20018,20024]
name: _UNSET [20018,20024]
===
match
---
name: JSONDecodeError [1254,1269]
name: JSONDecodeError [1254,1269]
===
match
---
string: 'w' [33055,33058]
string: 'w' [33055,33058]
===
match
---
atom [14004,14016]
atom [14004,14016]
===
match
---
operator: * [35928,35929]
operator: * [35928,35929]
===
match
---
if_stmt [17258,17398]
if_stmt [17258,17398]
===
match
---
name: split [33138,33143]
name: split [33138,33143]
===
match
---
name: key [25597,25600]
name: key [25597,25600]
===
match
---
name: fallback_key [13018,13030]
name: fallback_key [13018,13030]
===
match
---
suite [31650,31955]
suite [31650,31955]
===
match
---
import_from [1377,1430]
import_from [1377,1430]
===
match
---
name: getfloat [36331,36339]
name: getfloat [36331,36339]
===
match
---
name: environ [12174,12181]
name: environ [12174,12181]
===
match
---
expr_stmt [22529,22560]
expr_stmt [22529,22560]
===
match
---
simple_stmt [17572,17604]
simple_stmt [17572,17604]
===
match
---
trailer [34142,34166]
trailer [34142,34166]
===
match
---
trailer [38128,38401]
trailer [38132,38405]
===
match
---
trailer [33163,33169]
trailer [33163,33169]
===
match
---
string: 'smtp_password' [4709,4724]
string: 'smtp_password' [4709,4724]
===
match
---
name: default_config [8475,8489]
name: default_config [8475,8489]
===
match
---
atom_expr [30596,30640]
atom_expr [30596,30640]
===
match
---
dictorsetmaker [5078,7289]
dictorsetmaker [5078,7289]
===
match
---
expr_stmt [8774,8828]
expr_stmt [8774,8828]
===
match
---
comp_op [32065,32071]
comp_op [32065,32071]
===
match
---
name: option [17261,17267]
name: option [17261,17267]
===
match
---
trailer [37152,37159]
trailer [37152,37163]
===
match
---
name: TEST_CONFIG_FILE [29201,29217]
name: TEST_CONFIG_FILE [29201,29217]
===
match
---
name: key [14715,14718]
name: key [14715,14718]
===
match
---
operator: , [17690,17691]
operator: , [17690,17691]
===
match
---
try_stmt [18050,18310]
try_stmt [18050,18310]
===
match
---
name: environ [26757,26764]
name: environ [26757,26764]
===
match
---
fstring_string: error: cannot use sqlite with the  [9895,9929]
fstring_string: error: cannot use sqlite with the  [9895,9929]
===
match
---
operator: , [15523,15524]
operator: , [15523,15524]
===
match
---
name: current_value [10945,10958]
name: current_value [10945,10958]
===
match
---
name: val [22133,22136]
name: val [22133,22136]
===
match
---
string: '%%' [27190,27194]
string: '%%' [27190,27194]
===
match
---
name: deprecated_section [29276,29294]
name: deprecated_section [29276,29294]
===
match
---
trailer [14981,15005]
trailer [14981,15005]
===
match
---
operator: = [9609,9610]
operator: = [9609,9610]
===
match
---
fstring_end: ' [18251,18252]
fstring_end: ' [18251,18252]
===
match
---
suite [26150,26594]
suite [26150,26594]
===
match
---
operator: , [7681,7682]
operator: , [7681,7682]
===
match
---
operator: = [40228,40229]
operator: = [40232,40233]
===
match
---
operator: , [37129,37130]
operator: , [37129,37130]
===
match
---
string: 'scheduler' [6839,6850]
string: 'scheduler' [6839,6850]
===
match
---
fstring_expr [11955,11968]
fstring_expr [11955,11968]
===
match
---
atom_expr [3058,3095]
atom_expr [3058,3095]
===
match
---
expr_stmt [39684,39720]
expr_stmt [39688,39724]
===
match
---
operator: = [12114,12115]
operator: = [12114,12115]
===
match
---
name: source [19627,19633]
name: source [19627,19633]
===
match
---
testlist_comp [5318,5346]
testlist_comp [5318,5346]
===
match
---
operator: , [28084,28085]
operator: , [28084,28085]
===
match
---
operator: , [14274,14275]
operator: , [14274,14275]
===
match
---
name: section [14777,14784]
name: section [14777,14784]
===
match
---
name: option [15674,15680]
name: option [15674,15680]
===
match
---
atom_expr [3308,3341]
atom_expr [3308,3341]
===
match
---
trailer [16809,16811]
trailer [16809,16811]
===
match
---
simple_stmt [36406,36430]
simple_stmt [36406,36430]
===
match
---
string: "core" [9620,9626]
string: "core" [9620,9626]
===
match
---
name: super [13233,13238]
name: super [13233,13238]
===
match
---
operator: , [11351,11352]
operator: , [11351,11352]
===
match
---
fstring_string: section/key [ [15147,15160]
fstring_string: section/key [ [15147,15160]
===
match
---
string: 'metrics' [7131,7140]
string: 'metrics' [7131,7140]
===
match
---
operator: } [17857,17858]
operator: } [17857,17858]
===
match
---
trailer [31582,31587]
trailer [31582,31587]
===
match
---
name: option [15422,15428]
name: option [15422,15428]
===
match
---
expr_stmt [3821,3874]
expr_stmt [3821,3874]
===
match
---
trailer [37275,37554]
trailer [37279,37558]
===
match
---
not_test [2055,2066]
not_test [2055,2066]
===
match
---
simple_stmt [38542,38821]
simple_stmt [38546,38825]
===
match
---
atom_expr [28366,28379]
atom_expr [28366,28379]
===
match
---
operator: = [1694,1695]
operator: = [1694,1695]
===
match
---
trailer [37703,37988]
trailer [37707,37992]
===
match
---
name: re [868,870]
name: re [868,870]
===
match
---
simple_stmt [5047,7296]
simple_stmt [5047,7296]
===
match
---
param [8240,8245]
param [8240,8245]
===
match
---
raise_stmt [10255,10343]
raise_stmt [10255,10343]
===
match
---
simple_stmt [26851,26892]
simple_stmt [26851,26892]
===
match
---
suite [34760,35136]
suite [34760,35136]
===
match
---
testlist_comp [5648,5681]
testlist_comp [5648,5681]
===
match
---
if_stmt [25258,25367]
if_stmt [25258,25367]
===
match
---
operator: { [31848,31849]
operator: { [31848,31849]
===
match
---
string: 'env var' [27255,27264]
string: 'env var' [27255,27264]
===
match
---
string: 'statsd_datadog_tags' [7098,7119]
string: 'statsd_datadog_tags' [7098,7119]
===
match
---
testlist_comp [9661,9711]
testlist_comp [9661,9711]
===
match
---
string: "executor" [9628,9638]
string: "executor" [9628,9638]
===
match
---
string: "'conf.getsection'" [37060,37079]
string: "'conf.getsection'" [37060,37079]
===
match
---
name: join [3192,3196]
name: join [3192,3196]
===
match
---
suite [22516,22561]
suite [22516,22561]
===
match
---
param [27862,27877]
param [27862,27877]
===
match
---
name: staticmethod [29225,29237]
name: staticmethod [29225,29237]
===
match
---
operator: , [24863,24864]
operator: , [24863,24864]
===
match
---
trailer [31107,31116]
trailer [31107,31116]
===
match
---
name: path [3200,3204]
name: path [3200,3204]
===
match
---
operator: , [18029,18030]
operator: , [18029,18030]
===
match
---
trailer [13238,13240]
trailer [13238,13240]
===
match
---
string: """Get path to Airflow Home""" [30304,30334]
string: """Get path to Airflow Home""" [30304,30334]
===
match
---
name: DeprecationWarning [37941,37959]
name: DeprecationWarning [37945,37963]
===
match
---
trailer [30861,30875]
trailer [30861,30875]
===
match
---
name: TEST_CONFIG_FILE_PATH [28980,29001]
name: TEST_CONFIG_FILE_PATH [28980,29001]
===
match
---
suite [20599,20665]
suite [20599,20665]
===
match
---
operator: { [18585,18586]
operator: { [18585,18586]
===
match
---
param [16961,16965]
param [16961,16965]
===
match
---
suite [40096,40148]
suite [40100,40152]
===
match
---
fstring [19425,19467]
fstring [19425,19467]
===
match
---
argument [9153,9168]
argument [9153,9168]
===
match
---
operator: , [5253,5254]
operator: , [5253,5254]
===
match
---
trailer [15045,15102]
trailer [15045,15102]
===
match
---
operator: } [2755,2756]
operator: } [2755,2756]
===
match
---
trailer [34138,34142]
trailer [34138,34142]
===
match
---
if_stmt [10554,10858]
if_stmt [10554,10858]
===
match
---
name: self [14669,14673]
name: self [14669,14673]
===
match
---
name: str [23020,23023]
name: str [23020,23023]
===
match
---
trailer [31052,31057]
trailer [31052,31057]
===
match
---
operator: { [11955,11956]
operator: { [11955,11956]
===
match
---
atom [5146,5176]
atom [5146,5176]
===
match
---
trailer [34553,34559]
trailer [34553,34559]
===
match
---
param [15239,15254]
param [15239,15254]
===
match
---
param [28267,28282]
param [28267,28282]
===
match
---
name: conf [34590,34594]
name: conf [34590,34594]
===
match
---
trailer [39410,39444]
trailer [39414,39448]
===
match
---
name: os [32099,32101]
name: os [32099,32101]
===
match
---
trailer [8445,8462]
trailer [8445,8462]
===
match
---
name: self [26914,26918]
name: self [26914,26918]
===
match
---
expr_stmt [11163,11206]
expr_stmt [11163,11206]
===
match
---
operator: { [17853,17854]
operator: { [17853,17854]
===
match
---
argument [37589,37597]
argument [37593,37601]
===
match
---
string: """Get Path to airflow.cfg path""" [30450,30484]
string: """Get Path to airflow.cfg path""" [30450,30484]
===
match
---
trailer [3777,3785]
trailer [3777,3785]
===
match
---
trailer [24659,24669]
trailer [24659,24669]
===
match
---
string: 'DebugExecutor' [9661,9676]
string: 'DebugExecutor' [9661,9676]
===
match
---
parameters [26027,26089]
parameters [26027,26089]
===
match
---
operator: , [6063,6064]
operator: , [6063,6064]
===
match
---
name: os [12727,12729]
name: os [12727,12729]
===
match
---
parameters [38452,38469]
parameters [38456,38473]
===
match
---
name: remove_option [20487,20500]
name: remove_option [20487,20500]
===
match
---
name: get_custom_secret_backend [2972,2997]
name: get_custom_secret_backend [2972,2997]
===
match
---
name: self [10356,10360]
name: self [10356,10360]
===
match
---
param [37626,37634]
param [37630,37638]
===
match
---
name: name [9013,9017]
name: name [9013,9017]
===
match
---
import_from [1229,1269]
import_from [1229,1269]
===
match
---
expr_stmt [13852,13882]
expr_stmt [13852,13882]
===
match
---
operator: = [36709,36710]
operator: = [36709,36710]
===
match
---
comp_op [10573,10579]
comp_op [10573,10579]
===
match
---
try_stmt [39482,39721]
try_stmt [39486,39725]
===
match
---
trailer [32074,32082]
trailer [32074,32082]
===
match
---
testlist_comp [26380,26390]
testlist_comp [26380,26390]
===
match
---
name: info [32961,32965]
name: info [32961,32965]
===
match
---
operator: , [33007,33008]
operator: , [33007,33008]
===
match
---
name: conf [19035,19039]
name: conf [19035,19039]
===
match
---
simple_stmt [32092,32143]
simple_stmt [32092,32143]
===
match
---
fstring_start: f' [17804,17806]
fstring_start: f' [17804,17806]
===
match
---
trailer [32842,32855]
trailer [32842,32855]
===
match
---
atom_expr [3184,3243]
atom_expr [3184,3243]
===
match
---
simple_stmt [32415,32459]
simple_stmt [32415,32459]
===
match
---
fstring_string: error: cannot use sqlite version <  [10286,10321]
fstring_string: error: cannot use sqlite version <  [10286,10321]
===
match
---
arglist [1688,1751]
arglist [1688,1751]
===
match
---
argument [39589,39609]
argument [39593,39613]
===
match
---
operator: * [8373,8374]
operator: * [8373,8374]
===
match
---
atom_expr [36326,36356]
atom_expr [36326,36356]
===
match
---
name: display_source [28267,28281]
name: display_source [28267,28281]
===
match
---
number: 2 [38812,38813]
number: 2 [38816,38817]
===
match
---
trailer [31091,31099]
trailer [31091,31099]
===
match
---
name: display_source [24865,24879]
name: display_source [24865,24879]
===
match
---
if_stmt [14126,14175]
if_stmt [14126,14175]
===
match
---
simple_stmt [25289,25367]
simple_stmt [25289,25367]
===
match
---
name: env_var [2210,2217]
name: env_var [2210,2217]
===
match
---
operator: { [4476,4477]
operator: { [4476,4477]
===
match
---
atom_expr [20727,20755]
atom_expr [20727,20755]
===
match
---
name: version [9300,9307]
name: version [9300,9307]
===
match
---
suite [34632,34661]
suite [34632,34661]
===
match
---
name: self [11173,11177]
name: self [11173,11177]
===
match
---
atom_expr [32099,32142]
atom_expr [32099,32142]
===
match
---
operator: * [36776,36777]
operator: * [36776,36777]
===
match
---
name: deprecated_key [16120,16134]
name: deprecated_key [16120,16134]
===
match
---
name: key [18391,18394]
name: key [18391,18394]
===
match
---
operator: = [1787,1788]
operator: = [1787,1788]
===
match
---
param [22850,22871]
param [22850,22871]
===
match
---
operator: = [3532,3533]
operator: = [3532,3533]
===
match
---
string: 'core' [5839,5845]
string: 'core' [5839,5845]
===
match
---
string: 'dag_processor_manager_log_location' [6424,6460]
string: 'dag_processor_manager_log_location' [6424,6460]
===
match
---
name: section [13245,13252]
name: section [13245,13252]
===
match
---
dotted_name [1190,1207]
dotted_name [1190,1207]
===
match
---
simple_stmt [40334,40387]
simple_stmt [40338,40391]
===
match
---
return_stmt [30339,30405]
return_stmt [30339,30405]
===
match
---
testlist_comp [6961,6996]
testlist_comp [6961,6996]
===
match
---
name: key [12144,12147]
name: key [12144,12147]
===
match
---
suite [26834,26953]
suite [26834,26953]
===
match
---
trailer [29376,29381]
trailer [29376,29381]
===
match
---
parameters [10996,11028]
parameters [10996,11028]
===
match
---
string: "config.yml" [3861,3873]
string: "config.yml" [3861,3873]
===
match
---
testlist_comp [5510,5536]
testlist_comp [5510,5536]
===
match
---
name: exists [31466,31472]
name: exists [31466,31472]
===
match
---
atom_expr [16334,16366]
atom_expr [16334,16366]
===
match
---
name: section [14432,14439]
name: section [14432,14439]
===
match
---
name: join [30551,30555]
name: join [30551,30555]
===
match
---
name: os [30611,30613]
name: os [30611,30613]
===
match
---
trailer [25974,25983]
trailer [25974,25983]
===
match
---
not_test [32335,32371]
not_test [32335,32371]
===
match
---
if_stmt [21472,21750]
if_stmt [21472,21750]
===
match
---
if_stmt [22569,22681]
if_stmt [22569,22681]
===
match
---
operator: = [22466,22467]
operator: = [22466,22467]
===
match
---
expr_stmt [3405,3496]
expr_stmt [3405,3496]
===
match
---
name: update [26521,26527]
name: update [26521,26527]
===
match
---
string: 'scheduler' [6765,6776]
string: 'scheduler' [6765,6776]
===
match
---
name: Optional [1301,1309]
name: Optional [1301,1309]
===
match
---
trailer [12530,12555]
trailer [12530,12555]
===
match
---
atom_expr [13862,13882]
atom_expr [13862,13882]
===
match
---
trailer [21997,21999]
trailer [21997,21999]
===
match
---
operator: , [5430,5431]
operator: , [5430,5431]
===
match
---
name: option [16041,16047]
name: option [16041,16047]
===
match
---
name: start_method_options [10478,10498]
name: start_method_options [10478,10498]
===
match
---
string: "section/key [%s/%s] not found in config" [15046,15087]
string: "section/key [%s/%s] not found in config" [15046,15087]
===
match
---
name: display_source [25464,25478]
name: display_source [25464,25478]
===
match
---
string: 'core' [33755,33761]
string: 'core' [33755,33761]
===
match
---
parameters [19495,19527]
parameters [19495,19527]
===
match
---
simple_stmt [8205,8222]
simple_stmt [8205,8222]
===
match
---
trailer [26496,26520]
trailer [26496,26520]
===
match
---
operator: , [13252,13253]
operator: , [13252,13253]
===
match
---
trailer [22604,22619]
trailer [22604,22619]
===
match
---
simple_stmt [39499,39640]
simple_stmt [39503,39644]
===
match
---
testlist_comp [5079,5106]
testlist_comp [5079,5106]
===
match
---
name: _defaults [22577,22586]
name: _defaults [22577,22586]
===
match
---
trailer [32531,32540]
trailer [32531,32540]
===
match
---
operator: , [7184,7185]
operator: , [7184,7185]
===
match
---
argument [30076,30099]
argument [30076,30099]
===
match
---
name: config_sources [24629,24643]
name: config_sources [24629,24643]
===
match
---
string: 'simple_log_format' [6065,6084]
string: 'simple_log_format' [6065,6084]
===
match
---
name: lower [27297,27302]
name: lower [27297,27302]
===
match
---
name: get_airflow_test_config [31961,31984]
name: get_airflow_test_config [31961,31984]
===
match
---
name: self [14360,14364]
name: self [14360,14364]
===
match
---
testlist_comp [4670,4689]
testlist_comp [4670,4689]
===
match
---
name: self [24720,24724]
name: self [24720,24724]
===
match
---
tfpdef [20691,20703]
tfpdef [20691,20703]
===
match
---
name: b64encode [32499,32508]
name: b64encode [32499,32508]
===
match
---
name: TEST_CONFIG [3497,3508]
name: TEST_CONFIG [3497,3508]
===
match
---
operator: , [3508,3509]
operator: , [3508,3509]
===
match
---
suite [29313,30274]
suite [29313,30274]
===
match
---
name: include_env [24962,24973]
name: include_env [24962,24973]
===
match
---
expr_stmt [15472,15540]
expr_stmt [15472,15540]
===
match
---
name: source [19701,19707]
name: source [19701,19707]
===
match
---
operator: = [30931,30932]
operator: = [30931,30932]
===
match
---
operator: , [8933,8934]
operator: , [8933,8934]
===
match
---
name: section [21341,21348]
name: section [21341,21348]
===
match
---
name: TEST_PLUGINS_FOLDER [31553,31572]
name: TEST_PLUGINS_FOLDER [31553,31572]
===
match
---
for_stmt [8606,9331]
for_stmt [8606,9331]
===
match
---
trailer [27718,27729]
trailer [27718,27729]
===
match
---
testlist_comp [6183,6217]
testlist_comp [6183,6217]
===
match
---
trailer [24839,24885]
trailer [24839,24885]
===
match
---
operator: , [26887,26888]
operator: , [26887,26888]
===
match
---
name: source_name [28132,28143]
name: source_name [28132,28143]
===
match
---
name: parameterized_config [32822,32842]
name: parameterized_config [32822,32842]
===
match
---
name: all_vars [31937,31945]
name: all_vars [31937,31945]
===
match
---
trailer [17495,17519]
trailer [17495,17519]
===
match
---
simple_stmt [29191,29219]
simple_stmt [29191,29219]
===
match
---
atom_expr [14193,14284]
atom_expr [14193,14284]
===
match
---
if_stmt [30489,30585]
if_stmt [30489,30585]
===
match
---
name: key [11956,11959]
name: key [11956,11959]
===
match
---
name: environ [12914,12921]
name: environ [12914,12921]
===
match
---
atom_expr [33134,33171]
atom_expr [33134,33171]
===
match
---
operator: , [6814,6815]
operator: , [6814,6815]
===
match
---
simple_stmt [9864,9962]
simple_stmt [9864,9962]
===
match
---
argument [30121,30132]
argument [30121,30132]
===
match
---
name: environ [12730,12737]
name: environ [12730,12737]
===
match
---
trailer [35616,35621]
trailer [35616,35621]
===
match
---
string: '' [32482,32484]
string: '' [32482,32484]
===
match
---
name: error [19257,19262]
name: error [19257,19262]
===
match
---
name: kwargs [35549,35555]
name: kwargs [35549,35555]
===
match
---
name: DeprecationWarning [30210,30228]
name: DeprecationWarning [30210,30228]
===
match
---
trailer [31379,31387]
trailer [31379,31387]
===
match
---
operator: , [4640,4641]
operator: , [4640,4641]
===
match
---
name: section [15601,15608]
name: section [15601,15608]
===
match
---
trailer [29541,29548]
trailer [29541,29548]
===
match
---
name: key [26529,26532]
name: key [26529,26532]
===
match
---
name: include_secret [22985,22999]
name: include_secret [22985,22999]
===
match
---
operator: , [21743,21744]
operator: , [21743,21744]
===
match
---
name: airflow_defaults [21088,21104]
name: airflow_defaults [21088,21104]
===
match
---
operator: , [13826,13827]
operator: , [13826,13827]
===
match
---
trailer [3267,3272]
trailer [3267,3272]
===
match
---
name: urandom [32512,32519]
name: urandom [32512,32519]
===
match
---
string: 'core' [5763,5769]
string: 'core' [5763,5769]
===
match
---
trailer [10371,10398]
trailer [10371,10398]
===
match
---
arglist [35631,35894]
arglist [35631,35894]
===
match
---
operator: , [4690,4691]
operator: , [4690,4691]
===
match
---
simple_stmt [13223,13268]
simple_stmt [13223,13268]
===
match
---
name: option [14607,14613]
name: option [14607,14613]
===
match
---
trailer [22576,22586]
trailer [22576,22586]
===
match
---
suite [19765,20050]
suite [19765,20050]
===
match
---
return_stmt [12512,12555]
return_stmt [12512,12555]
===
match
---
string: 'logging' [6183,6192]
string: 'logging' [6183,6192]
===
match
---
simple_stmt [23050,24621]
simple_stmt [23050,24621]
===
match
---
simple_stmt [19653,19709]
simple_stmt [19653,19709]
===
match
---
operator: } [15174,15175]
operator: } [15174,15175]
===
match
---
atom_expr [32154,32203]
atom_expr [32154,32203]
===
match
---
suite [8716,9331]
suite [8716,9331]
===
match
---
fstring_end: ' [17931,17932]
fstring_end: ' [17931,17932]
===
match
---
simple_stmt [13923,14018]
simple_stmt [13923,14018]
===
match
---
trailer [13171,13182]
trailer [13171,13182]
===
match
---
if_stmt [33648,34223]
if_stmt [33648,34223]
===
match
---
trailer [32179,32202]
trailer [32179,32202]
===
match
---
name: deprecated_name [29296,29311]
name: deprecated_name [29296,29311]
===
match
---
string: 'logging' [5510,5519]
string: 'logging' [5510,5519]
===
match
---
atom_expr [25960,26000]
atom_expr [25960,26000]
===
match
---
name: raw [28283,28286]
name: raw [28283,28286]
===
match
---
atom_expr [39285,39313]
atom_expr [39289,39317]
===
match
---
name: keys [21451,21455]
name: keys [21451,21455]
===
match
---
suite [18109,18310]
suite [18109,18310]
===
match
---
import_name [813,835]
import_name [813,835]
===
match
---
name: get_config [3073,3083]
name: get_config [3073,3083]
===
match
---
name: self [10884,10888]
name: self [10884,10888]
===
match
---
string: '' [21565,21567]
string: '' [21565,21567]
===
match
---
name: section [15280,15287]
name: section [15280,15287]
===
match
---
simple_stmt [14934,15007]
simple_stmt [14934,15007]
===
match
---
name: full_qualified_path [19095,19114]
name: full_qualified_path [19095,19114]
===
match
---
name: dirname [31076,31083]
name: dirname [31076,31083]
===
match
---
name: os [3184,3186]
name: os [3184,3186]
===
match
---
name: cfg [33191,33194]
name: cfg [33191,33194]
===
match
---
name: dirname [3205,3212]
name: dirname [3205,3212]
===
match
---
trailer [27972,27974]
trailer [27972,27974]
===
match
---
operator: = [33258,33259]
operator: = [33258,33259]
===
match
---
param [19609,19614]
param [19609,19614]
===
match
---
argument [36340,36345]
argument [36340,36345]
===
match
---
operator: , [36747,36748]
operator: , [36747,36748]
===
match
---
name: TEST_CONFIG_FILE [32776,32792]
name: TEST_CONFIG_FILE [32776,32792]
===
match
---
operator: ** [37201,37203]
operator: ** [37205,37207]
===
match
---
name: __file__ [3213,3221]
name: __file__ [3213,3221]
===
match
---
name: import_string [19173,19186]
name: import_string [19173,19186]
===
match
---
trailer [9892,9961]
trailer [9892,9961]
===
match
---
name: AirflowConfigException [15122,15144]
name: AirflowConfigException [15122,15144]
===
match
---
operator: , [4580,4581]
operator: , [4580,4581]
===
match
---
string: """         Reads options, imports the full qualified name, and returns the object.          In case of failure, it throws an exception a clear message with the key aad the section names          :return: The object or None, if the option is empty         """ [18745,19004]
string: """         Reads options, imports the full qualified name, and returns the object.          In case of failure, it throws an exception a clear message with the key aad the section names          :return: The object or None, if the option is empty         """ [18745,19004]
===
match
---
operator: , [5925,5926]
operator: , [5925,5926]
===
match
---
name: key [11904,11907]
name: key [11904,11907]
===
match
---
testlist_comp [24708,24778]
testlist_comp [24708,24778]
===
match
---
name: float [20743,20748]
name: float [20743,20748]
===
match
---
name: yaml [3932,3936]
name: yaml [3932,3936]
===
match
---
name: exceptions [1390,1400]
name: exceptions [1390,1400]
===
match
---
atom [7493,7570]
atom [7493,7570]
===
match
---
name: display_source [25722,25736]
name: display_source [25722,25736]
===
match
---
name: option [20001,20007]
name: option [20001,20007]
===
match
---
atom [7475,7950]
atom [7475,7950]
===
match
---
operator: , [3419,3420]
operator: , [3419,3420]
===
match
---
arglist [21736,21748]
arglist [21736,21748]
===
match
---
return_stmt [36319,36356]
return_stmt [36319,36356]
===
match
---
expr_stmt [25758,25779]
expr_stmt [25758,25779]
===
match
---
atom_expr [31388,31431]
atom_expr [31388,31431]
===
match
---
fstring_end: " [2808,2809]
fstring_end: " [2808,2809]
===
match
---
trailer [30888,30902]
trailer [30888,30902]
===
match
---
simple_stmt [19278,19482]
simple_stmt [19278,19482]
===
match
---
operator: * [38019,38020]
operator: * [38023,38024]
===
match
---
name: AIRFLOW_CONFIG [33344,33358]
name: AIRFLOW_CONFIG [33344,33358]
===
match
---
string: 'AIRFLOW_HOME' [33651,33665]
string: 'AIRFLOW_HOME' [33651,33665]
===
match
---
name: deprecated_section [16588,16606]
name: deprecated_section [16588,16606]
===
match
---
name: self [20146,20150]
name: self [20146,20150]
===
match
---
argument [36295,36307]
argument [36295,36307]
===
match
---
name: self [9611,9615]
name: self [9611,9615]
===
match
---
name: option [14296,14302]
name: option [14296,14302]
===
match
---
trailer [34641,34658]
trailer [34641,34658]
===
match
---
name: section [28357,28364]
name: section [28357,28364]
===
match
---
name: warn [37271,37275]
name: warn [37275,37279]
===
match
---
name: expand_env_var [30596,30610]
name: expand_env_var [30596,30610]
===
match
---
name: new [8738,8741]
name: new [8738,8741]
===
match
---
operator: , [38763,38764]
operator: , [38767,38768]
===
match
---
simple_stmt [30826,30876]
simple_stmt [30826,30876]
===
match
---
param [20691,20703]
param [20691,20703]
===
match
---
trailer [3559,3579]
trailer [3559,3579]
===
match
---
name: path [32342,32346]
name: path [32342,32346]
===
match
---
string: 'statsd_port' [6710,6723]
string: 'statsd_port' [6710,6723]
===
match
---
trailer [8798,8828]
trailer [8798,8828]
===
match
---
trailer [3845,3874]
trailer [3845,3874]
===
match
---
arglist [20563,20578]
arglist [20563,20578]
===
match
---
arglist [36340,36355]
arglist [36340,36355]
===
match
---
operator: { [2800,2801]
operator: { [2800,2801]
===
match
---
operator: = [8518,8519]
operator: = [8518,8519]
===
match
---
operator: , [35965,35966]
operator: , [35965,35966]
===
match
---
suite [29769,30274]
suite [29769,30274]
===
match
---
operator: = [31846,31847]
operator: = [31846,31847]
===
match
---
fstring [18168,18252]
fstring [18168,18252]
===
match
---
expr_stmt [18367,18405]
expr_stmt [18367,18405]
===
match
---
param [12995,13003]
param [12995,13003]
===
match
---
name: expand_env_var [16789,16803]
name: expand_env_var [16789,16803]
===
match
---
name: DeprecationWarning [38773,38791]
name: DeprecationWarning [38777,38795]
===
match
---
simple_stmt [25684,25703]
simple_stmt [25684,25703]
===
match
---
simple_stmt [32542,32632]
simple_stmt [32542,32632]
===
match
---
testlist_comp [7261,7287]
testlist_comp [7261,7287]
===
match
---
string: 'hostname_callable' [7507,7526]
string: 'hostname_callable' [7507,7526]
===
match
---
name: self [8560,8564]
name: self [8560,8564]
===
match
---
name: secrets_backend_cls [39374,39393]
name: secrets_backend_cls [39378,39397]
===
match
---
operator: , [4707,4708]
operator: , [4707,4708]
===
match
---
atom_expr [35912,35944]
atom_expr [35912,35944]
===
match
---
name: section [21117,21124]
name: section [21117,21124]
===
match
---
strings [19324,19467]
strings [19324,19467]
===
match
---
trailer [15037,15045]
trailer [15037,15045]
===
match
---
atom_expr [17483,17536]
atom_expr [17483,17536]
===
match
---
name: get [9616,9619]
name: get [9616,9619]
===
match
---
funcdef [38445,38858]
funcdef [38449,38862]
===
match
---
operator: , [5736,5737]
operator: , [5736,5737]
===
match
---
operator: , [36285,36286]
operator: , [36285,36286]
===
match
---
atom [5990,6012]
atom [5990,6012]
===
match
---
operator: = [8260,8261]
operator: = [8260,8261]
===
match
---
operator: } [18239,18240]
operator: } [18239,18240]
===
match
---
trailer [8662,8664]
trailer [8662,8664]
===
match
---
operator: , [28433,28434]
operator: , [28433,28434]
===
match
---
trailer [2559,2561]
trailer [2559,2561]
===
match
---
name: environ [21443,21450]
name: environ [21443,21450]
===
match
---
name: OrderedDict [982,993]
name: OrderedDict [982,993]
===
match
---
import_from [1185,1228]
import_from [1185,1228]
===
match
---
comparison [10557,10600]
comparison [10557,10600]
===
match
---
operator: = [19633,19634]
operator: = [19633,19634]
===
match
---
suite [9851,9962]
suite [9851,9962]
===
match
---
trailer [33368,33379]
trailer [33368,33379]
===
match
---
name: category [33708,33716]
name: category [33708,33716]
===
match
---
name: env_var [2277,2284]
name: env_var [2277,2284]
===
match
---
not_test [26219,26226]
not_test [26219,26226]
===
match
---
string: 'true' [17628,17634]
string: 'true' [17628,17634]
===
match
---
operator: , [22948,22949]
operator: , [22948,22949]
===
match
---
operator: , [16244,16245]
operator: , [16244,16245]
===
match
---
fstring_end: " [15196,15197]
fstring_end: " [15196,15197]
===
match
---
operator: @ [29224,29225]
operator: @ [29224,29225]
===
match
---
simple_stmt [4045,4122]
simple_stmt [4045,4122]
===
match
---
simple_stmt [25956,26001]
simple_stmt [25956,26001]
===
match
---
name: raw [26409,26412]
name: raw [26409,26412]
===
match
---
expr_stmt [26373,26391]
expr_stmt [26373,26391]
===
match
---
trailer [33143,33159]
trailer [33143,33159]
===
match
---
name: get [16812,16815]
name: get [16812,16815]
===
match
---
trailer [31904,31906]
trailer [31904,31906]
===
match
---
operator: ** [37589,37591]
operator: ** [37593,37595]
===
match
---
atom_expr [12873,12943]
atom_expr [12873,12943]
===
match
---
string: """Historical getfloat""" [35996,36021]
string: """Historical getfloat""" [35996,36021]
===
match
---
name: self [17037,17041]
name: self [17037,17041]
===
match
---
param [17983,17991]
param [17983,17991]
===
match
---
operator: ** [38848,38850]
operator: ** [38852,38854]
===
match
---
suite [35991,36357]
suite [35991,36357]
===
match
---
trailer [15973,15989]
trailer [15973,15989]
===
match
---
name: os [33669,33671]
name: os [33669,33671]
===
match
---
name: section [20648,20655]
name: section [20648,20655]
===
match
---
trailer [35927,35944]
trailer [35927,35944]
===
match
---
operator: , [13541,13542]
operator: , [13541,13542]
===
match
---
operator: , [6612,6613]
operator: , [6612,6613]
===
match
---
trailer [11959,11965]
trailer [11959,11965]
===
match
---
param [26674,26677]
param [26674,26677]
===
match
---
suite [26817,27773]
suite [26817,27773]
===
match
---
name: subprocess [2463,2473]
name: subprocess [2463,2473]
===
match
---
trailer [21104,21116]
trailer [21104,21116]
===
match
---
funcdef [8151,8222]
funcdef [8151,8222]
===
match
---
operator: } [10340,10341]
operator: } [10340,10341]
===
match
---
name: AirflowConfigException [18495,18517]
name: AirflowConfigException [18495,18517]
===
match
---
operator: , [37624,37625]
operator: , [37628,37629]
===
match
---
trailer [34297,34304]
trailer [34297,34304]
===
match
---
name: info [8753,8757]
name: info [8753,8757]
===
match
---
atom [5803,5836]
atom [5803,5836]
===
match
---
param [25464,25479]
param [25464,25479]
===
match
---
name: multiprocessing [820,835]
name: multiprocessing [820,835]
===
match
---
comparison [17679,17705]
comparison [17679,17705]
===
match
---
name: read_dict [19661,19670]
name: read_dict [19661,19670]
===
match
---
trailer [27184,27195]
trailer [27184,27195]
===
match
---
trailer [28417,28443]
trailer [28417,28443]
===
match
---
atom_expr [17578,17603]
atom_expr [17578,17603]
===
match
---
name: self [18373,18377]
name: self [18373,18377]
===
match
---
operator: , [7932,7933]
operator: , [7932,7933]
===
match
---
trailer [16341,16352]
trailer [16341,16352]
===
match
---
name: get [19988,19991]
name: get [19988,19991]
===
match
---
argument [34062,34089]
argument [34062,34089]
===
match
---
name: val [18445,18448]
name: val [18445,18448]
===
match
---
arglist [28751,28820]
arglist [28751,28820]
===
match
---
atom_expr [32875,32912]
atom_expr [32875,32912]
===
match
---
param [37194,37200]
param [37198,37204]
===
match
---
if_stmt [12799,12944]
if_stmt [12799,12944]
===
match
---
simple_stmt [20767,20954]
simple_stmt [20767,20954]
===
match
---
param [16279,16286]
param [16279,16286]
===
match
---
name: lower [21671,21676]
name: lower [21671,21676]
===
match
---
param [16925,16940]
param [16925,16940]
===
match
---
name: json [793,797]
name: json [793,797]
===
match
---
suite [19153,19208]
suite [19153,19208]
===
match
---
testlist_comp [6057,6084]
testlist_comp [6057,6084]
===
match
---
trailer [12541,12554]
trailer [12541,12554]
===
match
---
name: replace [26440,26447]
name: replace [26440,26447]
===
match
---
if_stmt [17612,17947]
if_stmt [17612,17947]
===
match
---
simple_stmt [16695,16766]
simple_stmt [16695,16766]
===
match
---
name: d [31897,31898]
name: d [31897,31898]
===
match
---
trailer [12921,12942]
trailer [12921,12942]
===
match
---
name: section [18382,18389]
name: section [18382,18389]
===
match
---
arglist [11192,11205]
arglist [11192,11205]
===
match
---
trailer [31083,31128]
trailer [31083,31128]
===
match
---
string: "'conf.has_option'" [37478,37497]
string: "'conf.has_option'" [37482,37501]
===
match
---
fstring_expr [18600,18609]
fstring_expr [18600,18609]
===
match
---
funcdef [3098,3403]
funcdef [3098,3403]
===
match
---
name: BaseSecretsBackend [39294,39312]
name: BaseSecretsBackend [39298,39316]
===
match
---
name: config [27910,27916]
name: config [27910,27916]
===
match
---
name: warnings [33804,33812]
name: warnings [33804,33812]
===
match
---
name: AirflowConfigParser [33260,33279]
name: AirflowConfigParser [33260,33279]
===
match
---
simple_stmt [30792,30826]
simple_stmt [30792,30826]
===
match
---
atom [24708,24742]
atom [24708,24742]
===
match
---
name: info [28746,28750]
name: info [28746,28750]
===
match
---
name: key [21667,21670]
name: key [21667,21670]
===
match
---
name: self [28830,28834]
name: self [28830,28834]
===
match
---
operator: = [15344,15345]
operator: = [15344,15345]
===
match
---
operator: , [27908,27909]
operator: , [27908,27909]
===
match
---
argument [37117,37129]
argument [37117,37129]
===
match
---
trailer [3312,3341]
trailer [3312,3341]
===
match
---
trailer [35116,35133]
trailer [35116,35133]
===
match
---
trailer [17209,17245]
trailer [17209,17245]
===
match
---
operator: = [12328,12329]
operator: = [12328,12329]
===
match
---
name: Dict [1289,1293]
name: Dict [1289,1293]
===
match
---
trailer [13964,13983]
trailer [13964,13983]
===
match
---
simple_stmt [22456,22503]
simple_stmt [22456,22503]
===
match
---
name: _section [21302,21310]
name: _section [21302,21310]
===
match
---
operator: , [13941,13942]
operator: , [13941,13942]
===
match
---
suite [17745,17947]
suite [17745,17947]
===
match
---
name: full_qualified_path [19187,19206]
name: full_qualified_path [19187,19206]
===
match
---
name: _TEST_PLUGINS_FOLDER [31473,31493]
name: _TEST_PLUGINS_FOLDER [31473,31493]
===
match
---
trailer [8462,8474]
trailer [8462,8474]
===
match
---
name: initialize_secrets_backends [40357,40384]
name: initialize_secrets_backends [40361,40388]
===
match
---
expr_stmt [34225,34281]
expr_stmt [34225,34281]
===
match
---
string: 'core' [10372,10378]
string: 'core' [10372,10378]
===
match
---
atom_expr [32639,32671]
atom_expr [32639,32671]
===
match
---
if_stmt [28457,28517]
if_stmt [28457,28517]
===
match
---
name: load_test_config [28552,28568]
name: load_test_config [28552,28568]
===
match
---
name: parents [30909,30916]
name: parents [30909,30916]
===
match
---
atom [6022,6054]
atom [6022,6054]
===
match
---
operator: , [11842,11843]
operator: , [11842,11843]
===
match
---
string: 'core' [6057,6063]
string: 'core' [6057,6063]
===
match
---
simple_stmt [12866,12944]
simple_stmt [12866,12944]
===
match
---
string: "Reading the config from %s" [33206,33234]
string: "Reading the config from %s" [33206,33234]
===
match
---
testlist_comp [13534,13546]
testlist_comp [13534,13546]
===
match
---
name: args [37195,37199]
name: args [37199,37203]
===
match
---
operator: , [5324,5325]
operator: , [5324,5325]
===
match
---
name: delimiter [22670,22679]
name: delimiter [22670,22679]
===
match
---
operator: = [32820,32821]
operator: = [32820,32821]
===
match
---
name: DeprecationWarning [34071,34089]
name: DeprecationWarning [34071,34089]
===
match
---
name: get [35142,35145]
name: get [35142,35145]
===
match
---
funcdef [36359,36759]
funcdef [36359,36759]
===
match
---
trailer [27963,27972]
trailer [27963,27972]
===
match
---
operator: , [25165,25166]
operator: , [25165,25166]
===
match
---
trailer [29795,30273]
trailer [29795,30273]
===
match
---
argument [17510,17518]
argument [17510,17518]
===
match
---
trailer [25005,25061]
trailer [25005,25061]
===
match
---
suite [13638,13780]
suite [13638,13780]
===
match
---
trailer [31099,31127]
trailer [31099,31127]
===
match
---
string: """Get path to unittests.cfg""" [32004,32035]
string: """Get path to unittests.cfg""" [32004,32035]
===
match
---
name: version [11379,11386]
name: version [11379,11386]
===
match
---
operator: , [20741,20742]
operator: , [20741,20742]
===
match
---
name: os [31458,31460]
name: os [31458,31460]
===
match
---
name: self [29011,29015]
name: self [29011,29015]
===
match
---
simple_stmt [36319,36357]
simple_stmt [36319,36357]
===
match
---
name: filenames [19550,19559]
name: filenames [19550,19559]
===
match
---
except_clause [26965,26982]
except_clause [26965,26982]
===
match
---
suite [8890,9331]
suite [8890,9331]
===
match
---
name: kwargs [35969,35975]
name: kwargs [35969,35975]
===
match
---
operator: = [32480,32481]
operator: = [32480,32481]
===
match
---
name: is_validated [8505,8517]
name: is_validated [8505,8517]
===
match
---
name: old [10890,10893]
name: old [10890,10893]
===
match
---
name: path [30546,30550]
name: path [30546,30550]
===
match
---
name: secrets_backend_list [39143,39163]
name: secrets_backend_list [39147,39167]
===
match
---
return_stmt [19128,19139]
return_stmt [19128,19139]
===
match
---
name: section [17318,17325]
name: section [17318,17325]
===
match
---
name: display_sensitive [26272,26289]
name: display_sensitive [26272,26289]
===
match
---
simple_stmt [36434,36719]
simple_stmt [36434,36719]
===
match
---
arglist [30376,30403]
arglist [30376,30403]
===
match
---
string: "deprecated. Please access the configuration from the 'configuration.conf' object via " [37813,37900]
string: "deprecated. Please access the configuration from the 'configuration.conf' object via " [37817,37904]
===
match
---
atom [5357,5394]
atom [5357,5394]
===
match
---
name: key [15171,15174]
name: key [15171,15174]
===
match
---
arith_expr [10668,10839]
arith_expr [10668,10839]
===
match
---
atom [6182,6218]
atom [6182,6218]
===
match
---
name: items [21184,21189]
name: items [21184,21189]
===
match
---
testlist_comp [27897,27916]
testlist_comp [27897,27916]
===
match
---
name: key [18343,18346]
name: key [18343,18346]
===
match
---
name: key [29615,29618]
name: key [29615,29618]
===
match
---
comp_op [17094,17100]
comp_op [17094,17100]
===
match
---
operator: = [20183,20184]
operator: = [20183,20184]
===
match
---
simple_stmt [26430,26459]
simple_stmt [26430,26459]
===
match
---
name: getint [37153,37159]
name: getsection [37153,37163]
===
match
---
expr_stmt [7455,7950]
expr_stmt [7455,7950]
===
match
---
name: self [14193,14197]
name: self [14193,14197]
===
match
---
name: deprecated_key [14227,14241]
name: deprecated_key [14227,14241]
===
match
---
funcdef [26599,27773]
funcdef [26599,27773]
===
match
---
atom_expr [39396,39444]
atom_expr [39400,39448]
===
match
---
name: get [13241,13244]
name: get [13241,13244]
===
match
---
atom_expr [21390,21405]
atom_expr [21390,21405]
===
match
---
arglist [29813,30259]
arglist [29813,30259]
===
match
---
atom_expr [8293,8326]
atom_expr [8293,8326]
===
match
---
name: env_var_cmd [12542,12553]
name: env_var_cmd [12542,12553]
===
match
---
number: 4 [21642,21643]
number: 4 [21642,21643]
===
match
---
name: secrets_client [2955,2969]
name: secrets_client [2955,2969]
===
match
---
simple_stmt [2374,2501]
simple_stmt [2374,2501]
===
match
---
name: name [11012,11016]
name: name [11012,11016]
===
match
---
name: load_test_config [34727,34743]
name: load_test_config [34727,34743]
===
match
---
operator: = [13461,13462]
operator: = [13461,13462]
===
match
---
simple_stmt [798,813]
simple_stmt [798,813]
===
match
---
name: isfile [32647,32653]
name: isfile [32647,32653]
===
match
---
atom [26528,26538]
atom [26528,26538]
===
match
---
atom [5838,5868]
atom [5838,5868]
===
match
---
trailer [29195,29200]
trailer [29195,29200]
===
match
---
dictorsetmaker [7725,7933]
dictorsetmaker [7725,7933]
===
match
---
comparison [33651,33679]
comparison [33651,33679]
===
match
---
operator: , [5868,5869]
operator: , [5868,5869]
===
match
---
param [14791,14799]
param [14791,14799]
===
match
---
operator: , [2561,2562]
operator: , [2561,2562]
===
match
---
param [8246,8266]
param [8246,8266]
===
match
---
name: file_path [3821,3830]
name: file_path [3821,3830]
===
match
---
arglist [16353,16365]
arglist [16353,16365]
===
match
---
operator: = [21830,21831]
operator: = [21830,21831]
===
match
---
string: 'AIRFLOW_HOME' [30376,30390]
string: 'AIRFLOW_HOME' [30376,30390]
===
match
---
suite [11909,11970]
suite [11909,11970]
===
match
---
simple_stmt [21913,21930]
simple_stmt [21913,21930]
===
match
---
operator: , [35893,35894]
operator: , [35893,35894]
===
match
---
string: 'webserver' [4736,4747]
string: 'webserver' [4736,4747]
===
match
---
operator: , [8272,8273]
operator: , [8272,8273]
===
match
---
fstring [2772,2809]
fstring [2772,2809]
===
match
---
simple_stmt [11215,11245]
simple_stmt [11215,11245]
===
match
---
arglist [36049,36308]
arglist [36049,36308]
===
match
---
name: path [31375,31379]
name: path [31375,31379]
===
match
---
trailer [22628,22644]
trailer [22628,22644]
===
match
---
name: OrderedDict [28366,28377]
name: OrderedDict [28366,28377]
===
match
---
operator: , [16723,16724]
operator: , [16723,16724]
===
match
---
simple_stmt [1185,1229]
simple_stmt [1185,1229]
===
match
---
name: os [32921,32923]
name: os [32921,32923]
===
match
---
arglist [28418,28442]
arglist [28418,28442]
===
match
---
simple_stmt [34765,34799]
simple_stmt [34765,34799]
===
match
---
name: fp [22752,22754]
name: fp [22752,22754]
===
match
---
if_stmt [22416,22561]
if_stmt [22416,22561]
===
match
---
atom_expr [32169,32202]
atom_expr [32169,32202]
===
match
---
trailer [32524,32531]
trailer [32524,32531]
===
match
---
trailer [31086,31091]
trailer [31086,31091]
===
match
---
simple_stmt [25128,25207]
simple_stmt [25128,25207]
===
match
---
name: key [16266,16269]
name: key [16266,16269]
===
match
---
return_stmt [20110,20122]
return_stmt [20110,20122]
===
match
---
param [11003,11011]
param [11003,11011]
===
match
---
name: parameterized_config [33295,33315]
name: parameterized_config [33295,33315]
===
match
---
operator: { [18600,18601]
operator: { [18600,18601]
===
match
---
operator: , [37079,37080]
operator: , [37079,37080]
===
match
---
import_as_names [1459,1506]
import_as_names [1459,1506]
===
match
---
import_from [1337,1375]
import_from [1337,1375]
===
match
---
operator: , [6550,6551]
operator: , [6550,6551]
===
match
---
atom_expr [37566,37598]
atom_expr [37570,37602]
===
match
---
name: section [12995,13002]
name: section [12995,13002]
===
match
---
trailer [21735,21749]
trailer [21735,21749]
===
match
---
operator: , [9710,9711]
operator: , [9710,9711]
===
match
---
name: default_section [22629,22644]
name: default_section [22629,22644]
===
match
---
trailer [20732,20755]
trailer [20732,20755]
===
match
---
operator: , [22797,22798]
operator: , [22797,22798]
===
match
---
argument [11719,11734]
argument [11719,11734]
===
match
---
name: conf [39561,39565]
name: conf [39565,39569]
===
match
---
fstring_expr [19443,19464]
fstring_expr [19443,19464]
===
match
---
string: 'running config, but please update your config before Apache ' [11588,11650]
string: 'running config, but please update your config before Apache ' [11588,11650]
===
match
---
number: 0 [2640,2641]
number: 0 [2640,2641]
===
match
---
name: command [2318,2325]
name: command [2318,2325]
===
match
---
trailer [34336,34403]
trailer [34336,34403]
===
match
---
trailer [30545,30550]
trailer [30545,30550]
===
match
---
suite [32807,32914]
suite [32807,32914]
===
match
---
param [35540,35546]
param [35540,35546]
===
match
---
atom_expr [38115,38401]
atom_expr [38119,38405]
===
match
---
suite [31548,31613]
suite [31548,31613]
===
match
---
if_stmt [27208,27266]
if_stmt [27208,27266]
===
match
---
operator: , [28249,28250]
operator: , [28249,28250]
===
match
---
name: kwargs [38028,38034]
name: kwargs [38032,38038]
===
match
---
name: key [16362,16365]
name: key [16362,16365]
===
match
---
name: close_fds [2480,2489]
name: close_fds [2480,2489]
===
match
---
trailer [32685,32761]
trailer [32685,32761]
===
match
---
suite [34540,34586]
suite [34540,34586]
===
match
---
string: 'scheduler' [7225,7236]
string: 'scheduler' [7225,7236]
===
match
---
arglist [13615,13636]
arglist [13615,13636]
===
match
---
operator: , [19733,19734]
operator: , [19733,19734]
===
match
---
simple_stmt [27000,27009]
simple_stmt [27000,27009]
===
match
---
fstring_start: f' [18535,18537]
fstring_start: f' [18535,18537]
===
match
---
trailer [35215,35220]
trailer [35215,35220]
===
match
---
funcdef [37179,37599]
funcdef [37183,37603]
===
match
---
testlist_comp [7529,7558]
testlist_comp [7529,7558]
===
match
---
string: 'core' [5540,5546]
string: 'core' [5540,5546]
===
match
---
atom_expr [13897,13913]
atom_expr [13897,13913]
===
match
---
simple_stmt [37690,37989]
simple_stmt [37694,37993]
===
match
---
simple_stmt [8336,8390]
simple_stmt [8336,8390]
===
match
---
param [15233,15238]
param [15233,15238]
===
match
---
atom_expr [21150,21199]
atom_expr [21150,21199]
===
match
---
expr_stmt [26430,26458]
expr_stmt [26430,26458]
===
match
---
name: str [8192,8195]
name: str [8192,8195]
===
match
---
arglist [22620,22679]
arglist [22620,22679]
===
match
---
name: super [16540,16545]
name: super [16540,16545]
===
match
---
trailer [9938,9958]
trailer [9938,9958]
===
match
---
name: Union [20727,20732]
name: Union [20727,20732]
===
match
---
param [16941,16960]
param [16941,16960]
===
match
---
operator: , [16850,16851]
operator: , [16850,16851]
===
match
---
trailer [22087,22089]
trailer [22087,22089]
===
match
---
argument [29728,29740]
argument [29728,29740]
===
match
---
trailer [22481,22502]
trailer [22481,22502]
===
match
---
atom [7172,7214]
atom [7172,7214]
===
match
---
name: raw [24881,24884]
name: raw [24881,24884]
===
match
---
return_stmt [13721,13779]
return_stmt [13721,13779]
===
match
---
name: section [13989,13996]
name: section [13989,13996]
===
match
---
operator: } [25937,25938]
operator: } [25937,25938]
===
match
---
name: os [843,845]
name: os [843,845]
===
match
---
name: display_source [25186,25200]
name: display_source [25186,25200]
===
match
---
operator: , [8378,8379]
operator: , [8378,8379]
===
match
---
fstring_end: ' [18294,18295]
fstring_end: ' [18294,18295]
===
match
---
funcdef [10977,11288]
funcdef [10977,11288]
===
match
---
operator: * [38453,38454]
operator: * [38457,38458]
===
match
---
return_stmt [14328,14341]
return_stmt [14328,14341]
===
match
---
trailer [21600,21608]
trailer [21600,21608]
===
match
---
operator: * [8267,8268]
operator: * [8267,8268]
===
match
---
name: AIRFLOW_HOME [33782,33794]
name: AIRFLOW_HOME [33782,33794]
===
match
---
name: option [15556,15562]
name: option [15556,15562]
===
match
---
name: val [18367,18370]
name: val [18367,18370]
===
match
---
name: sensitive_config_values [26126,26149]
name: sensitive_config_values [26126,26149]
===
match
---
name: get_airflow_test_config [32225,32248]
name: get_airflow_test_config [32225,32248]
===
match
---
operator: , [17069,17070]
operator: , [17069,17070]
===
match
---
atom [27249,27265]
atom [27249,27265]
===
match
---
operator: = [14358,14359]
operator: = [14358,14359]
===
match
---
name: config [28243,28249]
name: config [28243,28249]
===
match
---
comp_op [40084,40090]
comp_op [40088,40094]
===
match
---
trailer [21450,21455]
trailer [21450,21455]
===
match
---
string: '%%' [25849,25853]
string: '%%' [25849,25853]
===
match
---
string: '_CMD' [12340,12346]
string: '_CMD' [12340,12346]
===
match
---
name: Dict [24655,24659]
name: Dict [24655,24659]
===
match
---
operator: = [2489,2490]
operator: = [2489,2490]
===
match
---
expr_stmt [27167,27195]
expr_stmt [27167,27195]
===
match
---
trailer [34183,34188]
trailer [34183,34188]
===
match
---
string: 'logging' [6023,6032]
string: 'logging' [6023,6032]
===
match
---
param [15736,15741]
param [15736,15741]
===
match
---
operator: * [35960,35961]
operator: * [35960,35961]
===
match
---
name: write [33185,33190]
name: write [33185,33190]
===
match
---
parameters [15232,15288]
parameters [15232,15288]
===
match
---
param [19513,19526]
param [19513,19526]
===
match
---
param [28283,28287]
param [28283,28287]
===
match
---
operator: = [26867,26868]
operator: = [26867,26868]
===
match
---
atom [31863,31884]
atom [31863,31884]
===
match
---
simple_stmt [1664,1753]
simple_stmt [1664,1753]
===
match
---
string: 'Specifying both AIRFLOW_HOME environment variable and airflow_home ' [33425,33494]
string: 'Specifying both AIRFLOW_HOME environment variable and airflow_home ' [33425,33494]
===
match
---
string: 'logging' [6096,6105]
string: 'logging' [6096,6105]
===
match
---
name: self [12116,12120]
name: self [12116,12120]
===
match
---
atom_expr [29368,29755]
atom_expr [29368,29755]
===
match
---
string: 'atlas' [4670,4677]
string: 'atlas' [4670,4677]
===
match
---
fstring_string: __ [11953,11955]
fstring_string: __ [11953,11955]
===
match
---
atom_expr [13960,14017]
atom_expr [13960,14017]
===
match
---
operator: + [12338,12339]
operator: + [12338,12339]
===
match
---
name: self [8240,8244]
name: self [8240,8244]
===
match
---
name: option [20572,20578]
name: option [20572,20578]
===
match
---
operator: , [4565,4566]
operator: , [4565,4566]
===
match
---
atom [6503,6530]
atom [6503,6530]
===
match
---
name: self [19496,19500]
name: self [19496,19500]
===
match
---
name: full_qualified_path [19013,19032]
name: full_qualified_path [19013,19032]
===
match
---
trailer [31366,31454]
trailer [31366,31454]
===
match
---
name: section [16552,16559]
name: section [16552,16559]
===
match
---
fstring_start: f' [18638,18640]
fstring_start: f' [18638,18640]
===
match
---
operator: , [25478,25479]
operator: , [25478,25479]
===
match
---
trailer [32884,32900]
trailer [32884,32900]
===
match
---
string: r'\A#007A87\Z' [7635,7649]
string: r'\A#007A87\Z' [7635,7649]
===
match
---
name: self [18008,18012]
name: self [18008,18012]
===
match
---
operator: = [27287,27288]
operator: = [27287,27288]
===
match
---
operator: , [28794,28795]
operator: , [28794,28795]
===
match
---
simple_stmt [34175,34223]
simple_stmt [34175,34223]
===
match
---
testlist_comp [6883,6913]
testlist_comp [6883,6913]
===
match
---
name: k [28534,28535]
name: k [28534,28535]
===
match
---
atom_expr [33197,33251]
atom_expr [33197,33251]
===
match
---
atom_expr [14956,15005]
atom_expr [14956,15005]
===
match
---
name: val [21988,21991]
name: val [21988,21991]
===
match
---
atom_expr [22468,22502]
atom_expr [22468,22502]
===
match
---
argument [35088,35100]
argument [35088,35100]
===
match
---
funcdef [38860,39248]
funcdef [38864,39252]
===
match
---
simple_stmt [24798,24886]
simple_stmt [24798,24886]
===
match
---
operator: , [26067,26068]
operator: , [26067,26068]
===
match
---
operator: , [31281,31282]
operator: , [31281,31282]
===
match
---
name: conf [38000,38004]
name: conf [38004,38008]
===
match
---
fstring [18638,18664]
fstring [18638,18664]
===
match
---
param [38460,38468]
param [38464,38472]
===
match
---
dotted_name [1234,1246]
dotted_name [1234,1246]
===
match
---
trailer [22619,22680]
trailer [22619,22680]
===
match
---
operator: ** [39757,39759]
operator: ** [39761,39763]
===
match
---
name: current_value [8940,8953]
name: current_value [8940,8953]
===
match
---
parameters [11337,11387]
parameters [11337,11387]
===
match
---
if_stmt [15392,15429]
if_stmt [15392,15429]
===
match
---
operator: , [30099,30100]
operator: , [30099,30100]
===
match
---
arglist [33755,33777]
arglist [33755,33777]
===
match
---
name: key [17453,17456]
name: key [17453,17456]
===
match
---
name: logging [1569,1576]
name: logging [1569,1576]
===
match
---
name: option [14027,14033]
name: option [14027,14033]
===
match
---
name: section [17869,17876]
name: section [17869,17876]
===
match
---
name: output [2832,2838]
name: output [2832,2838]
===
match
---
trailer [34508,34531]
trailer [34508,34531]
===
match
---
operator: , [6530,6531]
operator: , [6530,6531]
===
match
---
name: optionstr [8212,8221]
name: optionstr [8212,8221]
===
match
---
trailer [3835,3840]
trailer [3835,3840]
===
match
---
trailer [2449,2454]
trailer [2449,2454]
===
match
---
string: 'Airflow {version}.' [11663,11683]
string: 'Airflow {version}.' [11663,11683]
===
match
---
suite [28575,29219]
suite [28575,29219]
===
match
---
name: custom_secret_backend [40002,40023]
name: custom_secret_backend [40006,40027]
===
match
---
operator: ** [37626,37628]
operator: ** [37630,37632]
===
match
---
string: 'scheduler' [6567,6578]
string: 'scheduler' [6567,6578]
===
match
---
testlist_comp [25499,25511]
testlist_comp [25499,25511]
===
match
---
operator: = [30805,30806]
operator: = [30805,30806]
===
match
---
trailer [38004,38018]
trailer [38008,38022]
===
match
---
fstring_start: f' [18269,18271]
fstring_start: f' [18269,18271]
===
match
---
atom_expr [28742,28821]
atom_expr [28742,28821]
===
match
---
name: read_string [29016,29027]
name: read_string [29016,29027]
===
match
---
param [8173,8187]
param [8173,8187]
===
match
---
atom_expr [22572,22586]
atom_expr [22572,22586]
===
match
---
atom_expr [3833,3874]
atom_expr [3833,3874]
===
match
---
name: kwargs [18350,18356]
name: kwargs [18350,18356]
===
match
---
atom_expr [32677,32761]
atom_expr [32677,32761]
===
match
---
operator: = [8751,8752]
operator: = [8751,8752]
===
match
---
param [15280,15287]
param [15280,15287]
===
match
---
argument [9118,9127]
argument [9118,9127]
===
match
---
param [20152,20160]
param [20152,20160]
===
match
---
name: has_option [33369,33379]
name: has_option [33369,33379]
===
match
---
trailer [34188,34222]
trailer [34188,34222]
===
match
---
simple_stmt [25558,25602]
simple_stmt [25558,25602]
===
match
---
simple_stmt [40208,40256]
simple_stmt [40212,40260]
===
match
---
operator: , [17456,17457]
operator: , [17456,17457]
===
match
---
name: Optional [39285,39293]
name: Optional [39289,39297]
===
match
---
return_stmt [12866,12943]
return_stmt [12866,12943]
===
match
---
operator: , [26637,26638]
operator: , [26637,26638]
===
match
---
name: config_file [3904,3915]
name: config_file [3904,3915]
===
match
---
atom_expr [18373,18405]
atom_expr [18373,18405]
===
match
---
name: stderr [2456,2462]
name: stderr [2456,2462]
===
match
---
simple_stmt [1092,1185]
simple_stmt [1092,1185]
===
match
---
trailer [26439,26447]
trailer [26439,26447]
===
match
---
argument [19571,19588]
argument [19571,19588]
===
match
---
name: _get_option_from_config_file [14198,14226]
name: _get_option_from_config_file [14198,14226]
===
match
---
fstring_string: The object could not be loaded. Please check " [19326,19372]
fstring_string: The object could not be loaded. Please check " [19326,19372]
===
match
---
operator: = [26377,26378]
operator: = [26377,26378]
===
match
---
trailer [16085,16135]
trailer [16085,16135]
===
match
---
string: """         Remove an option if it exists in config from a file or         default config. If both of config have the same option, this removes         the option in both configs unless remove_default=False.         """ [20199,20418]
string: """         Remove an option if it exists in config from a file or         default config. If both of config have the same option, this removes         the option in both configs unless remove_default=False.         """ [20199,20418]
===
match
---
return_stmt [37141,37176]
return_stmt [37141,37180]
===
match
---
operator: , [30173,30174]
operator: , [30173,30174]
===
match
---
name: module [1735,1741]
name: module [1735,1741]
===
match
---
atom_expr [26869,26891]
atom_expr [26869,26891]
===
match
---
expr_stmt [27110,27128]
expr_stmt [27110,27128]
===
match
---
operator: ** [35967,35969]
operator: ** [35967,35969]
===
match
---
parameters [37618,37635]
parameters [37622,37639]
===
match
---
trailer [23019,23040]
trailer [23019,23040]
===
match
---
simple_stmt [13891,13914]
simple_stmt [13891,13914]
===
match
---
name: config_sources [26623,26637]
name: config_sources [26623,26637]
===
match
---
string: "'conf.get'" [35416,35428]
string: "'conf.get'" [35416,35428]
===
match
---
name: stream [2577,2583]
name: stream [2577,2583]
===
match
---
suite [2106,2300]
suite [2106,2300]
===
match
---
atom [5178,5205]
atom [5178,5205]
===
match
---
name: AIRFLOW_CONFIG [32394,32408]
name: AIRFLOW_CONFIG [32394,32408]
===
match
---
name: name [9018,9022]
name: name [9018,9022]
===
match
---
trailer [19660,19670]
trailer [19660,19670]
===
match
---
name: env_var [2172,2179]
name: env_var [2172,2179]
===
match
---
strings [29399,29541]
strings [29399,29541]
===
match
---
number: 2 [35477,35478]
number: 2 [35477,35478]
===
match
---
simple_stmt [8293,8327]
simple_stmt [8293,8327]
===
match
---
operator: , [4599,4600]
operator: , [4599,4600]
===
match
---
string: 'core' [6221,6227]
string: 'core' [6221,6227]
===
match
---
name: _include_commands [26010,26027]
name: _include_commands [26010,26027]
===
match
---
name: format [31928,31934]
name: format [31928,31934]
===
match
---
trailer [33184,33190]
trailer [33184,33190]
===
match
---
name: process [2374,2381]
name: process [2374,2381]
===
match
---
trailer [19987,19991]
trailer [19987,19991]
===
match
---
name: d [31858,31859]
name: d [31858,31859]
===
match
---
fstring_end: ' [11968,11969]
fstring_end: ' [11968,11969]
===
match
---
trailer [12910,12943]
trailer [12910,12943]
===
match
---
trailer [16539,16576]
trailer [16539,16576]
===
match
---
operator: , [25427,25428]
operator: , [25427,25428]
===
match
---
operator: = [8822,8823]
operator: = [8822,8823]
===
match
---
name: config_sources [25871,25885]
name: config_sources [25871,25885]
===
match
---
string: 'statsd_datadog_enabled' [7013,7037]
string: 'statsd_datadog_enabled' [7013,7037]
===
match
---
if_stmt [15880,15917]
if_stmt [15880,15917]
===
match
---
if_stmt [16585,16863]
if_stmt [16585,16863]
===
match
---
operator: = [17183,17184]
operator: = [17183,17184]
===
match
---
atom_expr [38832,38857]
atom_expr [38836,38861]
===
match
---
simple_stmt [26163,26204]
simple_stmt [26163,26204]
===
match
---
trailer [21439,21458]
trailer [21439,21458]
===
match
---
expr_stmt [21826,21840]
expr_stmt [21826,21840]
===
match
---
param [16224,16229]
param [16224,16229]
===
match
---
name: os [3757,3759]
name: os [3757,3759]
===
match
---
arglist [37582,37597]
arglist [37586,37601]
===
match
---
name: section [20563,20570]
name: section [20563,20570]
===
match
---
name: deprecated_key [13943,13957]
name: deprecated_key [13943,13957]
===
match
---
atom_expr [32921,32951]
atom_expr [32921,32951]
===
match
---
if_stmt [32332,32485]
if_stmt [32332,32485]
===
match
---
name: _section [22157,22165]
name: _section [22157,22165]
===
match
---
string: 'fallback' [14900,14910]
string: 'fallback' [14900,14910]
===
match
---
expr_stmt [13223,13267]
expr_stmt [13223,13267]
===
match
---
atom_expr [29028,29061]
atom_expr [29028,29061]
===
match
---
funcdef [10863,10972]
funcdef [10863,10972]
===
match
---
operator: = [21531,21532]
operator: = [21531,21532]
===
match
---
name: section [20449,20456]
name: section [20449,20456]
===
match
---
name: FERNET_KEY [32469,32479]
name: FERNET_KEY [32469,32479]
===
match
---
name: new_key [30121,30128]
name: new_key [30121,30128]
===
match
---
operator: * [36340,36341]
operator: * [36340,36341]
===
match
---
trailer [34594,34605]
trailer [34594,34605]
===
match
---
if_stmt [13593,13780]
if_stmt [13593,13780]
===
match
---
string: "Reading test configuration from %s" [29127,29163]
string: "Reading test configuration from %s" [29127,29163]
===
match
---
trailer [32641,32646]
trailer [32641,32646]
===
match
---
arglist [36867,37130]
arglist [36867,37130]
===
match
---
operator: = [7473,7474]
operator: = [7473,7474]
===
match
---
atom [39718,39720]
atom [39722,39724]
===
match
---
string: '2.1' [7675,7680]
string: '2.1' [7675,7680]
===
match
---
name: section [28418,28425]
name: section [28418,28425]
===
match
---
simple_stmt [14184,14285]
simple_stmt [14184,14285]
===
match
---
operator: , [9127,9128]
operator: , [9127,9128]
===
match
---
arglist [3846,3873]
arglist [3846,3873]
===
match
---
atom [5215,5244]
atom [5215,5244]
===
match
---
name: display_sensitive [25327,25344]
name: display_sensitive [25327,25344]
===
match
---
operator: * [38050,38051]
operator: * [38054,38055]
===
match
---
simple_stmt [12952,12964]
simple_stmt [12952,12964]
===
match
---
funcdef [35947,36357]
funcdef [35947,36357]
===
match
---
parameters [31984,31998]
parameters [31984,31998]
===
match
---
operator: , [6192,6193]
operator: , [6192,6193]
===
match
---
simple_stmt [31500,31543]
simple_stmt [31500,31543]
===
match
---
arglist [38565,38814]
arglist [38569,38818]
===
match
---
atom_expr [17297,17367]
atom_expr [17297,17367]
===
match
---
sync_comp_for [26732,26806]
sync_comp_for [26732,26806]
===
match
---
name: deprecated_section [15440,15458]
name: deprecated_section [15440,15458]
===
match
---
name: val [17925,17928]
name: val [17925,17928]
===
match
---
operator: = [28329,28330]
operator: = [28329,28330]
===
match
---
operator: , [25039,25040]
operator: , [25039,25040]
===
match
---
arglist [14883,14895]
arglist [14883,14895]
===
match
---
name: json [1234,1238]
name: json [1234,1238]
===
match
---
string: """Get Secret Backend if defined in airflow.cfg""" [39319,39369]
string: """Get Secret Backend if defined in airflow.cfg""" [39323,39373]
===
match
---
testlist_comp [5919,5952]
testlist_comp [5919,5952]
===
match
---
name: self [9930,9934]
name: self [9930,9934]
===
match
---
param [15778,15782]
param [15778,15782]
===
match
---
simple_stmt [18432,18450]
simple_stmt [18432,18450]
===
match
---
param [11344,11352]
param [11344,11352]
===
match
---
atom_expr [2384,2500]
atom_expr [2384,2500]
===
match
---
operator: = [10428,10429]
operator: = [10428,10429]
===
match
---
name: Tuple [3147,3152]
name: Tuple [3147,3152]
===
match
---
string: "deprecated. Please access the configuration from the 'configuration.conf' object via " [35728,35815]
string: "deprecated. Please access the configuration from the 'configuration.conf' object via " [35728,35815]
===
match
---
name: section [29640,29647]
name: section [29640,29647]
===
match
---
operator: = [21235,21236]
operator: = [21235,21236]
===
match
---
suite [17163,17398]
suite [17163,17398]
===
match
---
operator: = [33081,33082]
operator: = [33081,33082]
===
match
---
suite [14148,14175]
suite [14148,14175]
===
match
---
operator: , [5499,5500]
operator: , [5499,5500]
===
match
---
fstring_expr [18585,18590]
fstring_expr [18585,18590]
===
match
---
testlist_comp [7000,7037]
testlist_comp [7000,7037]
===
match
---
atom [5068,7295]
atom [5068,7295]
===
match
---
operator: , [26083,26084]
operator: , [26083,26084]
===
match
---
trailer [30002,30192]
trailer [30002,30192]
===
match
---
comparison [13101,13147]
comparison [13101,13147]
===
match
---
atom_expr [34175,34222]
atom_expr [34175,34222]
===
match
---
strings [35230,35428]
strings [35230,35428]
===
match
---
name: get [9935,9938]
name: get [9935,9938]
===
match
---
operator: , [13689,13690]
operator: , [13689,13690]
===
match
---
atom_expr [28529,28536]
atom_expr [28529,28536]
===
match
---
name: sorted [21433,21439]
name: sorted [21433,21439]
===
match
---
string: 'default' [1695,1704]
string: 'default' [1695,1704]
===
match
---
atom_expr [26169,26203]
atom_expr [26169,26203]
===
match
---
param [28251,28266]
param [28251,28266]
===
match
---
name: warn [33813,33817]
name: warn [33813,33817]
===
match
---
trailer [32101,32106]
trailer [32101,32106]
===
match
---
simple_stmt [836,846]
simple_stmt [836,846]
===
match
---
trailer [28750,28821]
trailer [28750,28821]
===
match
---
atom_expr [21003,21045]
atom_expr [21003,21045]
===
match
---
atom [28393,28401]
atom [28393,28401]
===
match
---
name: min_sqlite_version [10218,10236]
name: min_sqlite_version [10218,10236]
===
match
---
param [38057,38065]
param [38061,38069]
===
match
---
atom_expr [19035,19079]
atom_expr [19035,19079]
===
match
---
operator: = [28496,28497]
operator: = [28496,28497]
===
match
---
string: 'metrics' [6669,6678]
string: 'metrics' [6669,6678]
===
match
---
operator: = [13668,13669]
operator: = [13668,13669]
===
match
---
suite [16607,16863]
suite [16607,16863]
===
match
---
arglist [19550,19588]
arglist [19550,19588]
===
match
---
name: airflow_home [30556,30568]
name: airflow_home [30556,30568]
===
match
---
name: is_sqlite [9973,9982]
name: is_sqlite [9973,9982]
===
match
---
operator: = [37979,37980]
operator: = [37983,37984]
===
match
---
parameters [35145,35162]
parameters [35145,35162]
===
match
---
operator: , [5479,5480]
operator: , [5479,5480]
===
match
---
testlist_comp [6603,6627]
testlist_comp [6603,6627]
===
match
---
operator: = [21665,21666]
operator: = [21665,21666]
===
match
---
operator: , [6354,6355]
operator: , [6354,6355]
===
match
---
name: stacklevel [37117,37127]
name: stacklevel [37117,37127]
===
match
---
atom_expr [3534,3579]
atom_expr [3534,3579]
===
match
---
testlist_comp [5397,5429]
testlist_comp [5397,5429]
===
match
---
suite [10399,10858]
suite [10399,10858]
===
match
---
operator: , [29674,29675]
operator: , [29674,29675]
===
match
---
name: section [28123,28130]
name: section [28123,28130]
===
match
---
param [37201,37209]
param [37205,37213]
===
match
---
atom [5078,5107]
atom [5078,5107]
===
match
---
operator: = [30165,30166]
operator: = [30165,30166]
===
match
---
simple_stmt [3741,3817]
simple_stmt [3741,3817]
===
match
---
trailer [25132,25150]
trailer [25132,25150]
===
match
---
number: 3 [29739,29740]
number: 3 [29739,29740]
===
match
---
operator: = [40355,40356]
operator: = [40359,40360]
===
match
---
operator: @ [27778,27779]
operator: @ [27778,27779]
===
match
---
if_stmt [32040,32143]
if_stmt [32040,32143]
===
match
---
operator: , [17228,17229]
operator: , [17228,17229]
===
match
---
trailer [3204,3212]
trailer [3204,3212]
===
match
---
name: warnings [33689,33697]
name: warnings [33689,33697]
===
match
---
operator: , [5657,5658]
operator: , [5657,5658]
===
match
---
suite [15792,16186]
suite [15792,16186]
===
match
---
parameters [8166,8188]
parameters [8166,8188]
===
match
---
import_name [836,845]
import_name [836,845]
===
match
---
trailer [9615,9619]
trailer [9615,9619]
===
match
---
argument [36749,36757]
argument [36749,36757]
===
match
---
name: str [8184,8187]
name: str [8184,8187]
===
match
---
simple_stmt [31912,31955]
simple_stmt [31912,31955]
===
match
---
name: kwargs [37591,37597]
name: kwargs [37595,37601]
===
match
---
atom_expr [3147,3162]
atom_expr [3147,3162]
===
match
---
decorated [29224,30274]
decorated [29224,30274]
===
match
---
name: sys [1643,1646]
name: sys [1643,1646]
===
match
---
operator: , [22754,22755]
operator: , [22754,22755]
===
match
---
name: args [38020,38024]
name: args [38024,38028]
===
match
---
string: '1' [17636,17639]
string: '1' [17636,17639]
===
match
---
name: FutureWarning [11829,11842]
name: FutureWarning [11829,11842]
===
match
---
name: realpath [31412,31420]
name: realpath [31412,31420]
===
match
---
suite [17559,17604]
suite [17559,17604]
===
match
---
operator: , [26656,26657]
operator: , [26656,26657]
===
match
---
name: section [27946,27953]
name: section [27946,27953]
===
match
---
name: TEST_CONFIG_FILE [32744,32760]
name: TEST_CONFIG_FILE [32744,32760]
===
match
---
trailer [21248,21250]
trailer [21248,21250]
===
match
---
trailer [21924,21929]
trailer [21924,21929]
===
match
---
fstring_end: " [2758,2759]
fstring_end: " [2758,2759]
===
match
---
return_stmt [12952,12963]
return_stmt [12952,12963]
===
match
---
name: log [34328,34331]
name: log [34328,34331]
===
match
---
operator: , [9769,9770]
operator: , [9769,9770]
===
match
---
fstring_end: ' [19407,19408]
fstring_end: ' [19407,19408]
===
match
---
name: delimiter [22799,22808]
name: delimiter [22799,22808]
===
match
---
expr_stmt [14507,14595]
expr_stmt [14507,14595]
===
match
---
name: List [39847,39851]
name: List [39851,39855]
===
match
---
name: key [27680,27683]
name: key [27680,27683]
===
match
---
suite [31999,32204]
suite [31999,32204]
===
match
---
name: section [19052,19059]
name: section [19052,19059]
===
match
---
name: AIRFLOW_HOME [30889,30901]
name: AIRFLOW_HOME [30889,30901]
===
match
---
trailer [9069,9092]
trailer [9069,9092]
===
match
---
name: section [13682,13689]
name: section [13682,13689]
===
match
---
trailer [18381,18405]
trailer [18381,18405]
===
match
---
with_item [3308,3356]
with_item [3308,3356]
===
match
---
suite [21510,21750]
suite [21510,21750]
===
match
---
name: os [32639,32641]
name: os [32639,32641]
===
match
---
simple_stmt [15337,15384]
simple_stmt [15337,15384]
===
match
---
name: _read_default_config_file [3448,3473]
name: _read_default_config_file [3448,3473]
===
match
---
string: 'core' [6312,6318]
string: 'core' [6312,6318]
===
match
---
name: dirname [31092,31099]
name: dirname [31092,31099]
===
match
---
arglist [28934,29001]
arglist [28934,29001]
===
match
---
import_name [884,901]
import_name [884,901]
===
match
---
simple_stmt [20479,20518]
simple_stmt [20479,20518]
===
match
---
simple_stmt [22185,22201]
simple_stmt [22185,22201]
===
match
---
testlist_comp [6917,6949]
testlist_comp [6917,6949]
===
match
---
simple_stmt [12316,12347]
simple_stmt [12316,12347]
===
match
---
name: TEST_CONFIG_FILE [32654,32670]
name: TEST_CONFIG_FILE [32654,32670]
===
match
---
expr_stmt [21527,21568]
expr_stmt [21527,21568]
===
match
---
trailer [28011,28056]
trailer [28011,28056]
===
match
---
import_from [929,957]
import_from [929,957]
===
match
---
string: 'airflow.cfg' [30570,30583]
string: 'airflow.cfg' [30570,30583]
===
match
---
name: distutils [1190,1199]
name: distutils [1190,1199]
===
match
---
operator: , [6658,6659]
operator: , [6658,6659]
===
match
---
name: secrets_path [13766,13778]
name: secrets_path [13766,13778]
===
match
---
name: optionstr [8173,8182]
name: optionstr [8173,8182]
===
match
---
fstring_expr [15160,15169]
fstring_expr [15160,15169]
===
match
---
operator: , [5813,5814]
operator: , [5813,5814]
===
match
---
string: 'from your airflow.cfg and suffer no change in behaviour.' [33990,34048]
string: 'from your airflow.cfg and suffer no change in behaviour.' [33990,34048]
===
match
---
operator: , [1797,1798]
operator: , [1797,1798]
===
match
---
name: action [1688,1694]
name: action [1688,1694]
===
match
---
simple_stmt [861,871]
simple_stmt [861,871]
===
match
---
suite [8665,9331]
suite [8665,9331]
===
match
---
comp_op [17268,17274]
comp_op [17268,17274]
===
match
---
name: new_value [11368,11377]
name: new_value [11368,11377]
===
match
---
testlist_comp [5609,5636]
testlist_comp [5609,5636]
===
match
---
trailer [20534,20551]
trailer [20534,20551]
===
match
---
name: self [22646,22650]
name: self [22646,22650]
===
match
---
for_stmt [28389,28543]
for_stmt [28389,28543]
===
match
---
with_item [33034,33067]
with_item [33034,33067]
===
match
---
atom_expr [10501,10540]
atom_expr [10501,10540]
===
match
---
name: super [20479,20484]
name: super [20479,20484]
===
match
---
operator: = [25562,25563]
operator: = [25562,25563]
===
match
---
expr_stmt [3248,3298]
expr_stmt [3248,3298]
===
match
---
simple_stmt [33804,34101]
simple_stmt [33804,34101]
===
match
---
trailer [29548,29674]
trailer [29548,29674]
===
match
---
operator: ** [38057,38059]
operator: ** [38061,38063]
===
match
---
operator: , [7822,7823]
operator: , [7822,7823]
===
match
---
name: val [28492,28495]
name: val [28492,28495]
===
match
---
arglist [9763,9789]
arglist [9763,9789]
===
match
---
simple_stmt [31553,31613]
simple_stmt [31553,31613]
===
match
---
argument [14996,15004]
argument [14996,15004]
===
match
---
fstring [2693,2759]
fstring [2693,2759]
===
match
---
atom [7528,7559]
atom [7528,7559]
===
match
---
expr_stmt [22157,22176]
expr_stmt [22157,22176]
===
match
---
with_item [34504,34539]
with_item [34504,34539]
===
match
---
arglist [22752,22808]
arglist [22752,22808]
===
match
---
operator: { [11936,11937]
operator: { [11936,11937]
===
match
---
trailer [29995,30002]
trailer [29995,30002]
===
match
---
name: warn [35617,35621]
name: warn [35617,35621]
===
match
---
name: _include_envs [24992,25005]
name: _include_envs [24992,25005]
===
match
---
param [26617,26622]
param [26617,26622]
===
match
---
name: airflow_home [32112,32124]
name: airflow_home [32112,32124]
===
match
---
atom_expr [37690,37988]
atom_expr [37694,37992]
===
match
---
arglist [11708,11801]
arglist [11708,11801]
===
match
---
string: r'^airflow\.contrib\.utils\.sendgrid\.send_email$' [7771,7821]
string: r'^airflow\.contrib\.utils\.sendgrid\.send_email$' [7771,7821]
===
match
---
number: 2 [38393,38394]
number: 2 [38397,38398]
===
match
---
trailer [8656,8662]
trailer [8656,8662]
===
match
---
if_stmt [15925,16166]
if_stmt [15925,16166]
===
match
---
trailer [33812,33817]
trailer [33812,33817]
===
match
---
simple_stmt [786,798]
simple_stmt [786,798]
===
match
---
operator: = [9207,9208]
operator: = [9207,9208]
===
match
---
simple_stmt [14328,14342]
simple_stmt [14328,14342]
===
match
---
trailer [17526,17528]
trailer [17526,17528]
===
match
---
operator: , [18024,18025]
operator: , [18024,18025]
===
match
---
fstring [15145,15197]
fstring [15145,15197]
===
match
---
name: as_dict [38418,38425]
name: as_dict [38422,38429]
===
match
---
operator: { [21389,21390]
operator: { [21389,21390]
===
match
---
operator: , [6744,6745]
operator: , [6744,6745]
===
match
---
trailer [12173,12181]
trailer [12173,12181]
===
match
---
expr_stmt [21139,21199]
expr_stmt [21139,21199]
===
match
---
name: kwargs [38850,38856]
name: kwargs [38854,38860]
===
match
---
return_stmt [30536,30584]
return_stmt [30536,30584]
===
match
---
name: secrets_client [3011,3025]
name: secrets_client [3011,3025]
===
match
---
return_stmt [10927,10971]
return_stmt [10927,10971]
===
match
---
expr_stmt [17176,17245]
expr_stmt [17176,17245]
===
match
---
arglist [32686,32760]
arglist [32686,32760]
===
match
---
operator: = [15967,15968]
operator: = [15967,15968]
===
match
---
atom_expr [34590,34631]
atom_expr [34590,34631]
===
match
---
name: category [1799,1807]
name: category [1799,1807]
===
match
---
operator: = [39418,39419]
operator: = [39422,39423]
===
match
---
name: section [18334,18341]
name: section [18334,18341]
===
match
---
name: replace [21541,21548]
name: replace [21541,21548]
===
match
---
name: append [40277,40283]
name: append [40281,40287]
===
match
---
suite [8550,9365]
suite [8550,9365]
===
match
---
string: 'core' [34606,34612]
string: 'core' [34606,34612]
===
match
---
name: replacement [8696,8707]
name: replacement [8696,8707]
===
match
---
operator: , [20689,20690]
operator: , [20689,20690]
===
match
---
name: config [27957,27963]
name: config [27957,27963]
===
match
---
fstring_string: Failed to convert value to bool. Please check " [17806,17853]
fstring_string: Failed to convert value to bool. Please check " [17806,17853]
===
match
---
suite [13009,13332]
suite [13009,13332]
===
match
---
name: re [7651,7653]
name: re [7651,7653]
===
match
---
simple_stmt [38517,38538]
simple_stmt [38521,38542]
===
match
---
trailer [11229,11244]
trailer [11229,11244]
===
match
---
name: log [19253,19256]
name: log [19253,19256]
===
match
---
operator: , [24879,24880]
operator: , [24879,24880]
===
match
---
atom_expr [32225,32262]
atom_expr [32225,32262]
===
match
---
name: key [29271,29274]
name: key [29271,29274]
===
match
---
string: 'statsd_datadog_tags' [7060,7081]
string: 'statsd_datadog_tags' [7060,7081]
===
match
---
trailer [25885,25896]
trailer [25885,25896]
===
match
---
atom_expr [26754,26764]
atom_expr [26754,26764]
===
match
---
argument [37160,37165]
argument [37164,37169]
===
match
---
name: DEFAULT_SECRETS_SEARCH_PATH [40171,40198]
name: DEFAULT_SECRETS_SEARCH_PATH [40175,40202]
===
match
---
string: 'core' [4487,4493]
string: 'core' [4487,4493]
===
match
---
trailer [33190,33195]
trailer [33190,33195]
===
match
---
name: opt [25684,25687]
name: opt [25684,25687]
===
match
---
operator: , [30192,30193]
operator: , [30192,30193]
===
match
---
suite [12738,12944]
suite [12738,12944]
===
match
---
name: NoOptionError [1139,1152]
name: NoOptionError [1139,1152]
===
match
---
comparison [12802,12848]
comparison [12802,12848]
===
match
---
name: pathlib [853,860]
name: pathlib [853,860]
===
match
---
comparison [13533,13579]
comparison [13533,13579]
===
match
---
return_stmt [20038,20049]
return_stmt [20038,20049]
===
match
---
testlist_star_expr [13923,13957]
testlist_star_expr [13923,13957]
===
match
---
name: section [16353,16360]
name: section [16353,16360]
===
match
---
expr_stmt [40002,40053]
expr_stmt [40006,40057]
===
match
---
atom_expr [10204,10237]
atom_expr [10204,10237]
===
match
---
operator: = [33132,33133]
operator: = [33132,33133]
===
match
---
name: kwargs [35515,35521]
name: kwargs [35515,35521]
===
match
---
name: utils [1520,1525]
name: utils [1520,1525]
===
match
---
if_stmt [31455,31613]
if_stmt [31455,31613]
===
match
---
operator: } [24674,24675]
operator: } [24674,24675]
===
match
---
trailer [31387,31432]
trailer [31387,31432]
===
match
---
name: section [13102,13109]
name: section [13102,13109]
===
match
---
atom [2522,2609]
atom [2522,2609]
===
match
---
trailer [28411,28417]
trailer [28411,28417]
===
match
---
trailer [31268,31290]
trailer [31268,31290]
===
match
---
operator: + [13037,13038]
operator: + [13037,13038]
===
match
---
name: config_sources [25006,25020]
name: config_sources [25006,25020]
===
match
---
name: raw [25362,25365]
name: raw [25362,25365]
===
match
---
name: section [14276,14283]
name: section [14276,14283]
===
match
---
name: key [16725,16728]
name: key [16725,16728]
===
match
---
name: self [28569,28573]
name: self [28569,28573]
===
match
---
string: 'worker_precheck' [5118,5135]
string: 'worker_precheck' [5118,5135]
===
match
---
name: key [17505,17508]
name: key [17505,17508]
===
match
---
name: DEFAULT_CONFIG [33316,33330]
name: DEFAULT_CONFIG [33316,33330]
===
match
---
argument [2432,2454]
argument [2432,2454]
===
match
---
name: strip [17529,17534]
name: strip [17529,17534]
===
match
---
name: section [13366,13373]
name: section [13366,13373]
===
match
---
expr_stmt [13655,13704]
expr_stmt [13655,13704]
===
match
---
atom_expr [15837,15871]
atom_expr [15837,15871]
===
match
---
operator: , [18346,18347]
operator: , [18346,18347]
===
match
---
trailer [32248,32262]
trailer [32248,32262]
===
match
---
expr_stmt [32415,32458]
expr_stmt [32415,32458]
===
match
---
name: DeprecationWarning [1715,1733]
name: DeprecationWarning [1715,1733]
===
match
---
trailer [31102,31107]
trailer [31102,31107]
===
match
---
arglist [35928,35943]
arglist [35928,35943]
===
match
---
operator: , [38344,38345]
operator: , [38348,38349]
===
match
---
with_stmt [3880,3960]
with_stmt [3880,3960]
===
match
---
dictorsetmaker [4486,4763]
dictorsetmaker [4486,4763]
===
match
---
atom_expr [15122,15198]
atom_expr [15122,15198]
===
match
---
name: getimport [39401,39410]
name: getimport [39405,39414]
===
match
---
fstring_end: ' [21408,21409]
fstring_end: ' [21408,21409]
===
match
---
name: airflow [1512,1519]
name: airflow [1512,1519]
===
match
---
operator: , [5564,5565]
operator: , [5564,5565]
===
match
---
comparison [12160,12181]
comparison [12160,12181]
===
match
---
name: warnings [38115,38123]
name: warnings [38119,38127]
===
match
---
testlist_comp [14005,14015]
testlist_comp [14005,14015]
===
match
---
trailer [2171,2180]
trailer [2171,2180]
===
match
---
operator: , [37497,37498]
operator: , [37501,37502]
===
match
---
trailer [26485,26496]
trailer [26485,26496]
===
match
---
operator: , [28121,28122]
operator: , [28121,28122]
===
match
---
name: format [29542,29548]
name: format [29542,29548]
===
match
---
atom [6882,6914]
atom [6882,6914]
===
match
---
arglist [8870,8888]
arglist [8870,8888]
===
match
---
simple_stmt [40105,40148]
simple_stmt [40109,40152]
===
match
---
name: __init__ [8231,8239]
name: __init__ [8231,8239]
===
match
---
string: " {} " [22468,22474]
string: " {} " [22468,22474]
===
match
---
string: 'core' [5609,5615]
string: 'core' [5609,5615]
===
match
---
parameters [16223,16287]
parameters [16223,16287]
===
match
---
factor [21641,21643]
factor [21641,21643]
===
match
---
trailer [29381,29755]
trailer [29381,29755]
===
match
---
string: 'worker_precheck' [5089,5106]
string: 'worker_precheck' [5089,5106]
===
match
---
operator: = [22137,22138]
operator: = [22137,22138]
===
match
---
operator: ** [8317,8319]
operator: ** [8317,8319]
===
match
---
simple_stmt [12195,12238]
simple_stmt [12195,12238]
===
match
---
atom [26103,26117]
atom [26103,26117]
===
match
---
name: OrderedDict [21237,21248]
name: OrderedDict [21237,21248]
===
match
---
string: """Historical has_option""" [37230,37257]
string: """Historical has_option""" [37234,37261]
===
match
---
name: WEBSERVER_CONFIG [34509,34525]
name: WEBSERVER_CONFIG [34509,34525]
===
match
---
atom [13101,13115]
atom [13101,13115]
===
match
---
trailer [18150,18309]
trailer [18150,18309]
===
match
---
name: option [16159,16165]
name: option [16159,16165]
===
match
---
simple_stmt [3925,3960]
simple_stmt [3925,3960]
===
match
---
name: kwargs [18398,18404]
name: kwargs [18398,18404]
===
match
---
simple_stmt [2651,2820]
simple_stmt [2651,2820]
===
match
---
return_stmt [32147,32203]
return_stmt [32147,32203]
===
match
---
expr_stmt [26307,26325]
expr_stmt [26307,26325]
===
match
---
name: warn [38124,38128]
name: warn [38128,38132]
===
match
---
name: _validate_config_dependencies [8565,8594]
name: _validate_config_dependencies [8565,8594]
===
match
---
name: section [28288,28295]
name: section [28288,28295]
===
match
---
name: self [14036,14040]
name: self [14036,14040]
===
match
---
name: os [21440,21442]
name: os [21440,21442]
===
match
---
name: str [13862,13865]
name: str [13862,13865]
===
match
---
operator: ** [18718,18720]
operator: ** [18718,18720]
===
match
---
name: env_var_secret_path [12922,12941]
name: env_var_secret_path [12922,12941]
===
match
---
name: args [36371,36375]
name: args [36371,36375]
===
match
---
name: os [31372,31374]
name: os [31372,31374]
===
match
---
string: 'task_log_reader' [6483,6500]
string: 'task_log_reader' [6483,6500]
===
match
---
fstring_expr [18231,18240]
fstring_expr [18231,18240]
===
match
---
name: kwargs [35937,35943]
name: kwargs [35937,35943]
===
match
---
name: parameterized_config [33083,33103]
name: parameterized_config [33083,33103]
===
match
---
suite [2642,2820]
suite [2642,2820]
===
match
---
name: join [31362,31366]
name: join [31362,31366]
===
match
---
atom_expr [9340,9357]
atom_expr [9340,9357]
===
match
---
name: env_var [11163,11170]
name: env_var [11163,11170]
===
match
---
operator: = [13031,13032]
operator: = [13031,13032]
===
match
---
simple_stmt [8975,9045]
simple_stmt [8975,9045]
===
match
---
operator: = [18371,18372]
operator: = [18371,18372]
===
match
---
trailer [2137,2148]
trailer [2137,2148]
===
match
---
arglist [25311,25365]
arglist [25311,25365]
===
match
---
return_stmt [40312,40331]
return_stmt [40316,40335]
===
match
---
simple_stmt [16518,16577]
simple_stmt [16518,16577]
===
match
---
name: info [32681,32685]
name: info [32681,32685]
===
match
---
suite [17468,17947]
suite [17468,17947]
===
match
---
name: val [21836,21839]
name: val [21836,21839]
===
match
---
name: self [22216,22220]
name: self [22216,22220]
===
match
---
trailer [25150,25206]
trailer [25150,25206]
===
match
---
param [8267,8273]
param [8267,8273]
===
match
---
testlist_comp [7085,7119]
testlist_comp [7085,7119]
===
match
---
atom_expr [29813,30192]
atom_expr [29813,30192]
===
match
---
name: _UNSET [1117,1123]
name: _UNSET [1117,1123]
===
match
---
atom_expr [15346,15383]
atom_expr [15346,15383]
===
match
---
string: """Historical as_dict""" [38086,38110]
string: """Historical as_dict""" [38090,38114]
===
match
---
name: initialize_secrets_backends [39186,39213]
name: initialize_secrets_backends [39190,39217]
===
match
---
name: deprecated_section [14562,14580]
name: deprecated_section [14562,14580]
===
match
---
operator: { [15170,15171]
operator: { [15170,15171]
===
match
---
testlist_comp [4701,4724]
testlist_comp [4701,4724]
===
match
---
string: 'dag_processor_manager_log_location' [6376,6412]
string: 'dag_processor_manager_log_location' [6376,6412]
===
match
---
trailer [19043,19079]
trailer [19043,19079]
===
match
---
suite [18419,18450]
suite [18419,18450]
===
match
---
trailer [8298,8300]
trailer [8298,8300]
===
match
---
name: option [14351,14357]
name: option [14351,14357]
===
match
---
atom_expr [32428,32458]
atom_expr [32428,32458]
===
match
---
name: section [27279,27286]
name: section [27279,27286]
===
match
---
if_stmt [21585,21645]
if_stmt [21585,21645]
===
match
---
string: 'airflow_home' [34151,34165]
string: 'airflow_home' [34151,34165]
===
match
---
simple_stmt [18002,18041]
simple_stmt [18002,18041]
===
match
---
trailer [18016,18040]
trailer [18016,18040]
===
match
---
suite [15563,15681]
suite [15563,15681]
===
match
---
param [26069,26084]
param [26069,26084]
===
match
---
operator: , [19511,19512]
operator: , [19511,19512]
===
match
---
trailer [22789,22795]
trailer [22789,22795]
===
match
---
name: getint [36735,36741]
name: getint [36735,36741]
===
match
---
operator: , [5793,5794]
operator: , [5793,5794]
===
match
---
operator: , [6724,6725]
operator: , [6724,6725]
===
match
---
param [13004,13007]
param [13004,13007]
===
match
---
name: section [21037,21044]
name: section [21037,21044]
===
match
---
name: secrets_path [13655,13667]
name: secrets_path [13655,13667]
===
match
---
operator: = [20017,20018]
operator: = [20017,20018]
===
match
---
param [20169,20188]
param [20169,20188]
===
match
---
name: raw [28118,28121]
name: raw [28118,28121]
===
match
---
operator: , [28130,28131]
operator: , [28130,28131]
===
match
---
string: "'conf.remove_option'" [37909,37931]
string: "'conf.remove_option'" [37913,37935]
===
match
---
if_stmt [25719,25855]
if_stmt [25719,25855]
===
match
---
name: import_string [1548,1561]
name: import_string [1548,1561]
===
match
---
atom [4486,4514]
atom [4486,4514]
===
match
---
atom [4631,4659]
atom [4631,4659]
===
match
---
operator: ** [18396,18398]
operator: ** [18396,18398]
===
match
---
name: _get_option_from_secrets [14521,14545]
name: _get_option_from_secrets [14521,14545]
===
match
---
import_name [1325,1336]
import_name [1325,1336]
===
match
---
expr_stmt [14027,14117]
expr_stmt [14027,14117]
===
match
---
simple_stmt [17477,17537]
simple_stmt [17477,17537]
===
match
---
expr_stmt [32816,32855]
expr_stmt [32816,32855]
===
match
---
atom_expr [19537,19589]
atom_expr [19537,19589]
===
match
---
name: log [28742,28745]
name: log [28742,28745]
===
match
---
return_stmt [14662,14729]
return_stmt [14662,14729]
===
match
---
name: realpath [31108,31116]
name: realpath [31108,31116]
===
match
---
if_stmt [17084,17133]
if_stmt [17084,17133]
===
match
---
name: opt [25758,25761]
name: opt [25758,25761]
===
match
---
operator: , [38024,38025]
operator: , [38028,38029]
===
match
---
expr_stmt [14184,14284]
expr_stmt [14184,14284]
===
match
---
atom_expr [26914,26952]
atom_expr [26914,26952]
===
match
---
operator: , [3859,3860]
operator: , [3859,3860]
===
match
---
operator: , [22922,22923]
operator: , [22922,22923]
===
match
---
operator: ** [8274,8276]
operator: ** [8274,8276]
===
match
---
operator: , [29269,29270]
operator: , [29269,29270]
===
match
---
operator: = [34202,34203]
operator: = [34202,34203]
===
match
---
operator: @ [28167,28168]
operator: @ [28167,28168]
===
match
---
name: os [30516,30518]
name: os [30516,30518]
===
match
---
trailer [21166,21183]
trailer [21166,21183]
===
match
---
trailer [13987,14017]
trailer [13987,14017]
===
match
---
trailer [19542,19544]
trailer [19542,19544]
===
match
---
operator: } [21405,21406]
operator: } [21405,21406]
===
match
---
trailer [3199,3204]
trailer [3199,3204]
===
match
---
operator: , [34432,34433]
operator: , [34432,34433]
===
match
---
atom_expr [29191,29218]
atom_expr [29191,29218]
===
match
---
trailer [32868,32874]
trailer [32868,32874]
===
match
---
string: 'statsd_host' [6614,6627]
string: 'statsd_host' [6614,6627]
===
match
---
arith_expr [13033,13045]
arith_expr [13033,13045]
===
match
---
operator: = [22249,22250]
operator: = [22249,22250]
===
match
---
atom_expr [8848,8889]
atom_expr [8848,8889]
===
match
---
name: deprecated_section [15505,15523]
name: deprecated_section [15505,15523]
===
match
---
operator: , [31600,31601]
operator: , [31600,31601]
===
match
---
atom_expr [21440,21457]
atom_expr [21440,21457]
===
match
---
trailer [13905,13911]
trailer [13905,13911]
===
match
---
name: section [9153,9160]
name: section [9153,9160]
===
match
---
operator: = [39577,39578]
operator: = [39581,39582]
===
match
---
atom_expr [21475,21509]
atom_expr [21475,21509]
===
match
---
expr_stmt [31331,31454]
expr_stmt [31331,31454]
===
match
---
param [29296,29311]
param [29296,29311]
===
match
---
trailer [30883,30888]
trailer [30883,30888]
===
match
---
trailer [10360,10371]
trailer [10360,10371]
===
match
---
operator: , [17634,17635]
operator: , [17634,17635]
===
match
---
name: env_var [21533,21540]
name: env_var [21533,21540]
===
match
---
string: "Accessing configuration method 'has_option' directly from the configuration module is " [37285,37373]
string: "Accessing configuration method 'has_option' directly from the configuration module is " [37289,37377]
===
match
---
name: new_value [11277,11286]
name: new_value [11277,11286]
===
match
---
parameters [12988,13008]
parameters [12988,13008]
===
match
---
suite [22017,22053]
suite [22017,22053]
===
match
---
simple_stmt [36026,36315]
simple_stmt [36026,36315]
===
match
---
string: 'AIRFLOW_TEST_CONFIG' [32180,32201]
string: 'AIRFLOW_TEST_CONFIG' [32180,32201]
===
match
---
suite [2067,2091]
suite [2067,2091]
===
match
---
suite [8428,8491]
suite [8428,8491]
===
match
---
trailer [14673,14705]
trailer [14673,14705]
===
match
---
testlist_comp [28499,28515]
testlist_comp [28499,28515]
===
match
---
trailer [3389,3391]
trailer [3389,3391]
===
match
---
simple_stmt [8560,8597]
simple_stmt [8560,8597]
===
match
---
atom_expr [36844,37136]
atom_expr [36844,37136]
===
match
---
arglist [9939,9957]
arglist [9939,9957]
===
match
---
param [38453,38459]
param [38457,38463]
===
match
---
atom_expr [8560,8596]
atom_expr [8560,8596]
===
match
---
param [19615,19626]
param [19615,19626]
===
match
---
name: _include_envs [26603,26616]
name: _include_envs [26603,26616]
===
match
---
atom_expr [12519,12555]
atom_expr [12519,12555]
===
match
---
operator: , [16564,16565]
operator: , [16564,16565]
===
match
---
atom_expr [31864,31873]
atom_expr [31864,31873]
===
match
---
name: file_name [3288,3297]
name: file_name [3288,3297]
===
match
---
testlist_star_expr [2505,2519]
testlist_star_expr [2505,2519]
===
match
---
name: self [22732,22736]
name: self [22732,22736]
===
match
---
funcdef [2841,3096]
funcdef [2841,3096]
===
match
---
name: initialize_secrets_backends [39814,39841]
name: initialize_secrets_backends [39818,39845]
===
match
---
trailer [33817,34100]
trailer [33817,34100]
===
match
---
argument [8380,8388]
argument [8380,8388]
===
match
---
name: os [3833,3835]
name: os [3833,3835]
===
match
---
name: env_var [2083,2090]
name: env_var [2083,2090]
===
match
---
operator: , [5292,5293]
operator: , [5292,5293]
===
match
---
name: self [25423,25427]
name: self [25423,25427]
===
match
---
name: yaml [1332,1336]
name: yaml [1332,1336]
===
match
---
trailer [3262,3267]
trailer [3262,3267]
===
match
---
operator: , [23004,23005]
operator: , [23004,23005]
===
match
---
name: _include_secrets [25294,25310]
name: _include_secrets [25294,25310]
===
match
---
name: option [17126,17132]
name: option [17126,17132]
===
match
---
operator: , [9221,9222]
operator: , [9221,9222]
===
match
---
name: action [1781,1787]
name: action [1781,1787]
===
match
---
name: os_environment [26717,26731]
name: os_environment [26717,26731]
===
match
---
argument [28435,28442]
argument [28435,28442]
===
match
---
operator: , [6578,6579]
operator: , [6578,6579]
===
match
---
param [26639,26657]
param [26639,26657]
===
match
---
simple_stmt [2900,2951]
simple_stmt [2900,2951]
===
match
---
simple_stmt [9419,9566]
simple_stmt [9419,9566]
===
match
---
name: old [8733,8736]
name: old [8733,8736]
===
match
---
name: opt [27250,27253]
name: opt [27250,27253]
===
match
---
argument [38019,38024]
argument [38023,38028]
===
match
---
name: has_section [21025,21036]
name: has_section [21025,21036]
===
match
---
trailer [32923,32928]
trailer [32923,32928]
===
match
---
operator: -> [3608,3610]
operator: -> [3608,3610]
===
match
---
string: 'fab_logging_level' [5586,5605]
string: 'fab_logging_level' [5586,5605]
===
match
---
operator: , [7545,7546]
operator: , [7545,7546]
===
match
---
name: include_secret [25261,25275]
name: include_secret [25261,25275]
===
match
---
name: write [34554,34559]
name: write [34554,34559]
===
match
---
atom_expr [17487,17519]
atom_expr [17487,17519]
===
match
---
operator: , [5116,5117]
operator: , [5116,5117]
===
match
---
operator: , [5403,5404]
operator: , [5403,5404]
===
match
---
name: key [21527,21530]
name: key [21527,21530]
===
match
---
operator: , [6872,6873]
operator: , [6872,6873]
===
match
---
operator: } [11952,11953]
operator: } [11952,11953]
===
match
---
name: config_key [3084,3094]
name: config_key [3084,3094]
===
match
---
name: key [15275,15278]
name: key [15275,15278]
===
match
---
operator: , [28116,28117]
operator: , [28116,28117]
===
match
---
name: env_var [1874,1881]
name: env_var [1874,1881]
===
match
---
testlist_comp [5283,5314]
testlist_comp [5283,5314]
===
match
---
trailer [13677,13681]
trailer [13677,13681]
===
match
---
simple_stmt [17758,17947]
simple_stmt [17758,17947]
===
match
---
trailer [22736,22751]
trailer [22736,22751]
===
match
---
name: isfile [32929,32935]
name: isfile [32929,32935]
===
match
---
string: 'task_log_prefix_template' [6107,6133]
string: 'task_log_prefix_template' [6107,6133]
===
match
---
name: self [21083,21087]
name: self [21083,21087]
===
match
---
name: display_source [27211,27225]
name: display_source [27211,27225]
===
match
---
name: name [11271,11275]
name: name [11271,11275]
===
match
---
name: command [13223,13230]
name: command [13223,13230]
===
match
---
trailer [32386,32393]
trailer [32386,32393]
===
match
---
trailer [12216,12237]
trailer [12216,12237]
===
match
---
string: 'backend' [39434,39443]
string: 'backend' [39438,39447]
===
match
---
suite [39486,39640]
suite [39490,39644]
===
match
---
trailer [26793,26806]
trailer [26793,26806]
===
match
---
operator: , [34525,34526]
operator: , [34525,34526]
===
match
---
arglist [37285,37548]
arglist [37289,37552]
===
match
---
simple_stmt [27674,27692]
simple_stmt [27674,27692]
===
match
---
strings [33831,34048]
strings [33831,34048]
===
match
---
import_from [1092,1168]
import_from [1092,1168]
===
match
---
trailer [7626,7634]
trailer [7626,7634]
===
match
---
return_stmt [15903,15916]
return_stmt [15903,15916]
===
match
---
name: deprecated_section [30036,30054]
name: deprecated_section [30036,30054]
===
match
---
atom_expr [16695,16765]
atom_expr [16695,16765]
===
match
---
with_stmt [34499,34586]
with_stmt [34499,34586]
===
match
---
trailer [21991,21997]
trailer [21991,21997]
===
match
---
string: 'encrypt_s3_logs' [5452,5469]
string: 'encrypt_s3_logs' [5452,5469]
===
match
---
string: 'logging' [5804,5813]
string: 'logging' [5804,5813]
===
match
---
string: 'remote_logging' [5255,5271]
string: 'remote_logging' [5255,5271]
===
match
---
atom [7623,7681]
atom [7623,7681]
===
match
---
string: '3.15.0' [10140,10148]
string: '3.15.0' [10140,10148]
===
match
---
string: """         Returns the section as a dict. Values are converted to int, float, bool         as required.          :param section: section from the config         :rtype: dict         """ [20767,20953]
string: """         Returns the section as a dict. Values are converted to int, float, bool         as required.          :param section: section from the config         :rtype: dict         """ [20767,20953]
===
match
---
expr_stmt [40208,40255]
expr_stmt [40212,40259]
===
match
---
fstring_start: f" [10284,10286]
fstring_start: f" [10284,10286]
===
match
---
trailer [14390,14440]
trailer [14390,14440]
===
match
---
name: ValueError [21953,21963]
name: ValueError [21953,21963]
===
match
---
trailer [8713,8715]
trailer [8713,8715]
===
match
---
string: 'core' [6504,6510]
string: 'core' [6504,6510]
===
match
---
arglist [8799,8827]
arglist [8799,8827]
===
match
---
operator: , [22622,22623]
operator: , [22622,22623]
===
match
---
name: has_section [21268,21279]
name: has_section [21268,21279]
===
match
---
trailer [13911,13913]
trailer [13911,13913]
===
match
---
simple_stmt [27243,27266]
simple_stmt [27243,27266]
===
match
---
name: dirname [3778,3785]
name: dirname [3778,3785]
===
match
---
suite [19115,19140]
suite [19115,19140]
===
match
---
name: items [28412,28417]
name: items [28412,28417]
===
match
---
trailer [8309,8326]
trailer [8309,8326]
===
match
---
trailer [21267,21279]
trailer [21267,21279]
===
match
---
atom_expr [35608,35900]
atom_expr [35608,35900]
===
match
---
operator: = [1714,1715]
operator: = [1714,1715]
===
match
---
suite [27150,27196]
suite [27150,27196]
===
match
---
string: 'metrics' [6735,6744]
string: 'metrics' [6735,6744]
===
match
---
name: TEST_DAGS_FOLDER [31237,31253]
name: TEST_DAGS_FOLDER [31237,31253]
===
match
---
name: fallback_key [13448,13460]
name: fallback_key [13448,13460]
===
match
---
trailer [25310,25366]
trailer [25310,25366]
===
match
---
name: AirflowConfigException [2657,2679]
name: AirflowConfigException [2657,2679]
===
match
---
argument [2480,2494]
argument [2480,2494]
===
match
---
name: path [31461,31465]
name: path [31461,31465]
===
match
---
name: deprecated_key [15742,15756]
name: deprecated_key [15742,15756]
===
match
---
expr_stmt [1563,1596]
expr_stmt [1563,1596]
===
match
---
simple_stmt [39979,39997]
simple_stmt [39983,40001]
===
match
---
trailer [16815,16861]
trailer [16815,16861]
===
match
---
number: 2 [26889,26890]
number: 2 [26889,26890]
===
match
---
expr_stmt [31837,31907]
expr_stmt [31837,31907]
===
match
---
not_test [26268,26289]
not_test [26268,26289]
===
match
---
name: key [18586,18589]
name: key [18586,18589]
===
match
---
simple_stmt [38115,38402]
simple_stmt [38119,38406]
===
match
---
string: 'encrypt_s3_logs' [5481,5498]
string: 'encrypt_s3_logs' [5481,5498]
===
match
---
operator: , [5519,5520]
operator: , [5519,5520]
===
match
---
operator: = [19579,19580]
operator: = [19579,19580]
===
match
---
trailer [25293,25310]
trailer [25293,25310]
===
match
---
suite [12019,12964]
suite [12019,12964]
===
match
---
operator: , [35428,35429]
operator: , [35428,35429]
===
match
---
name: raw [26674,26677]
name: raw [26674,26677]
===
match
---
atom_expr [17037,17075]
atom_expr [17037,17075]
===
match
---
arglist [25006,25060]
arglist [25006,25060]
===
match
---
funcdef [31615,31955]
funcdef [31615,31955]
===
match
---
atom [25928,25938]
atom [25928,25938]
===
match
---
atom_expr [3373,3391]
atom_expr [3373,3391]
===
match
---
trailer [2529,2536]
trailer [2529,2536]
===
match
---
string: '%' [25844,25847]
string: '%' [25844,25847]
===
match
---
string: "Accessing configuration method 'load_test_config' directly from the configuration module is " [34826,34920]
string: "Accessing configuration method 'load_test_config' directly from the configuration module is " [34826,34920]
===
match
---
name: info [29122,29126]
name: info [29122,29126]
===
match
---
expr_stmt [15960,16025]
expr_stmt [15960,16025]
===
match
---
suite [16288,16883]
suite [16288,16883]
===
match
---
operator: != [27058,27060]
operator: != [27058,27060]
===
match
---
operator: , [15613,15614]
operator: , [15613,15614]
===
match
---
atom_expr [31875,31883]
atom_expr [31875,31883]
===
match
---
atom_expr [15969,16025]
atom_expr [15969,16025]
===
match
---
operator: , [16228,16229]
operator: , [16228,16229]
===
match
---
operator: = [32497,32498]
operator: = [32497,32498]
===
match
---
strings [37713,37931]
strings [37717,37935]
===
match
---
name: as_dict [22819,22826]
name: as_dict [22819,22826]
===
match
---
if_stmt [27608,27692]
if_stmt [27608,27692]
===
match
---
simple_stmt [35576,35604]
simple_stmt [35576,35604]
===
match
---
trailer [12470,12494]
trailer [12470,12494]
===
match
---
operator: != [27619,27621]
operator: != [27619,27621]
===
match
---
name: SECRET_KEY [32486,32496]
name: SECRET_KEY [32486,32496]
===
match
---
trailer [11191,11206]
trailer [11191,11206]
===
match
---
for_stmt [40153,40307]
for_stmt [40157,40311]
===
match
---
name: section [18232,18239]
name: section [18232,18239]
===
match
---
operator: , [24770,24771]
operator: , [24770,24771]
===
match
---
name: args [38842,38846]
name: args [38846,38850]
===
match
---
name: filterwarnings [1673,1687]
name: filterwarnings [1673,1687]
===
match
---
name: get [13809,13812]
name: get [13809,13812]
===
match
---
funcdef [2302,2839]
funcdef [2302,2839]
===
match
---
name: config_sources [28086,28100]
name: config_sources [28086,28100]
===
match
---
name: get_custom_secret_backend [40026,40051]
name: get_custom_secret_backend [40030,40055]
===
match
---
name: PIPE [2450,2454]
name: PIPE [2450,2454]
===
match
---
number: 2 [37980,37981]
number: 2 [37984,37985]
===
match
---
arglist [33039,33058]
arglist [33039,33058]
===
match
---
simple_stmt [19537,19590]
simple_stmt [19537,19590]
===
match
---
atom [5396,5430]
atom [5396,5430]
===
match
---
operator: } [19463,19464]
operator: } [19463,19464]
===
match
---
simple_stmt [871,884]
simple_stmt [871,884]
===
match
---
arglist [14706,14728]
arglist [14706,14728]
===
match
---
operator: } [18660,18661]
operator: } [18660,18661]
===
match
---
operator: , [4762,4763]
operator: , [4762,4763]
===
match
---
argument [30246,30258]
argument [30246,30258]
===
match
---
param [38050,38056]
param [38054,38060]
===
match
---
operator: , [20508,20509]
operator: , [20508,20509]
===
match
---
trailer [36447,36718]
trailer [36447,36718]
===
match
---
atom_expr [12820,12848]
atom_expr [12820,12848]
===
match
---
operator: } [18589,18590]
operator: } [18589,18590]
===
match
---
arglist [27730,27752]
arglist [27730,27752]
===
match
---
operator: , [6592,6593]
operator: , [6592,6593]
===
match
---
fstring [11925,11969]
fstring [11925,11969]
===
match
---
trailer [13240,13244]
trailer [13240,13244]
===
match
---
name: interpolated [2194,2206]
name: interpolated [2194,2206]
===
match
---
comparison [32043,32082]
comparison [32043,32082]
===
match
---
fstring_start: f" [15145,15147]
fstring_start: f" [15145,15147]
===
match
---
operator: , [7570,7571]
operator: , [7570,7571]
===
match
---
simple_stmt [39374,39445]
simple_stmt [39378,39449]
===
match
---
operator: { [18216,18217]
operator: { [18216,18217]
===
match
---
name: warn [37699,37703]
name: warn [37703,37707]
===
match
---
name: __file__ [3786,3794]
name: __file__ [3786,3794]
===
match
---
operator: } [2807,2808]
operator: } [2807,2808]
===
match
---
operator: , [7649,7650]
operator: , [7649,7650]
===
match
---
name: val [21826,21829]
name: val [21826,21829]
===
match
---
operator: , [37931,37932]
operator: , [37935,37936]
===
match
---
name: display_sensitive [26639,26656]
name: display_sensitive [26639,26656]
===
match
---
atom_expr [32072,32082]
atom_expr [32072,32082]
===
match
---
number: 2 [37546,37547]
number: 2 [37550,37551]
===
match
---
atom_expr [33260,33332]
atom_expr [33260,33332]
===
match
---
name: val [18657,18660]
name: val [18657,18660]
===
match
---
simple_stmt [37655,37686]
simple_stmt [37659,37690]
===
match
---
simple_stmt [30304,30335]
simple_stmt [30304,30335]
===
match
---
trailer [32511,32519]
trailer [32511,32519]
===
match
---
return_stmt [16152,16165]
return_stmt [16152,16165]
===
match
---
param [30431,30443]
param [30431,30443]
===
match
---
funcdef [27796,28162]
funcdef [27796,28162]
===
match
---
argument [36742,36747]
argument [36742,36747]
===
match
---
testlist_comp [13102,13114]
testlist_comp [13102,13114]
===
match
---
suite [13843,14730]
suite [13843,14730]
===
match
---
name: section_prefix [21494,21508]
name: section_prefix [21494,21508]
===
match
---
atom [6263,6309]
atom [6263,6309]
===
match
---
expr_stmt [18002,18040]
expr_stmt [18002,18040]
===
match
---
testlist_comp [28394,28400]
testlist_comp [28394,28400]
===
match
---
argument [35935,35943]
argument [35935,35943]
===
match
---
string: 'statsd_custom_client_path' [7186,7213]
string: 'statsd_custom_client_path' [7186,7213]
===
match
---
operator: = [31048,31049]
operator: = [31048,31049]
===
match
---
operator: , [7665,7666]
operator: , [7665,7666]
===
match
---
suite [10238,10344]
suite [10238,10344]
===
match
---
atom_expr [13164,13205]
atom_expr [13164,13205]
===
match
---
simple_stmt [34328,34404]
simple_stmt [34328,34404]
===
match
---
name: super [13596,13601]
name: super [13596,13601]
===
match
---
fstring [21378,21409]
fstring [21378,21409]
===
match
---
name: self [21003,21007]
name: self [21003,21007]
===
match
---
trailer [38840,38857]
trailer [38844,38861]
===
match
---
suite [32464,32485]
suite [32464,32485]
===
match
---
name: self [22600,22604]
name: self [22600,22604]
===
match
---
testlist_comp [6697,6723]
testlist_comp [6697,6723]
===
match
---
trailer [12533,12541]
trailer [12533,12541]
===
match
---
name: conf [40388,40392]
name: conf [40392,40396]
===
match
---
name: join [10813,10817]
name: join [10813,10817]
===
match
---
expr_stmt [13891,13913]
expr_stmt [13891,13913]
===
match
---
operator: , [34089,34090]
operator: , [34089,34090]
===
match
---
name: Dict [23015,23019]
name: Dict [23015,23019]
===
match
---
atom_expr [27957,27974]
atom_expr [27957,27974]
===
match
---
atom [6471,6501]
atom [6471,6501]
===
match
---
atom [6804,6836]
atom [6804,6836]
===
match
---
name: airflow_home [31985,31997]
name: airflow_home [31985,31997]
===
match
---
operator: , [8244,8245]
operator: , [8244,8245]
===
match
---
operator: , [4677,4678]
operator: , [4677,4678]
===
match
---
atom [5246,5272]
atom [5246,5272]
===
match
---
return_stmt [13320,13331]
return_stmt [13320,13331]
===
match
---
operator: , [13817,13818]
operator: , [13817,13818]
===
match
---
operator: ** [35547,35549]
operator: ** [35547,35549]
===
match
---
atom_expr [32771,32798]
atom_expr [32771,32798]
===
match
---
operator: , [16939,16940]
operator: , [16939,16940]
===
match
---
operator: * [35146,35147]
operator: * [35146,35147]
===
match
---
name: warn [36853,36857]
name: warn [36853,36857]
===
match
---
name: has_option [10361,10371]
name: has_option [10361,10371]
===
match
---
simple_stmt [20199,20419]
simple_stmt [20199,20419]
===
match
---
subscriptlist [20722,20755]
subscriptlist [20722,20755]
===
match
---
name: stacklevel [30246,30256]
name: stacklevel [30246,30256]
===
match
---
operator: ** [36749,36751]
operator: ** [36749,36751]
===
match
---
name: _get_env_var_option [17042,17061]
name: _get_env_var_option [17042,17061]
===
match
---
name: conf [34134,34138]
name: conf [34134,34138]
===
match
---
trailer [35501,35505]
trailer [35501,35505]
===
match
---
argument [29611,29618]
argument [29611,29618]
===
match
---
atom_expr [33034,33059]
atom_expr [33034,33059]
===
match
---
name: AirflowConfigException [17764,17786]
name: AirflowConfigException [17764,17786]
===
match
---
string: 'scheduler' [7261,7272]
string: 'scheduler' [7261,7272]
===
match
---
name: process [2737,2744]
name: process [2737,2744]
===
match
---
string: '#fff' [7667,7673]
string: '#fff' [7667,7673]
===
match
---
operator: , [17508,17509]
operator: , [17508,17509]
===
match
---
name: section [22781,22788]
name: section [22781,22788]
===
match
---
suite [25115,25207]
suite [25115,25207]
===
match
---
expr_stmt [32206,32262]
expr_stmt [32206,32262]
===
match
---
if_stmt [12445,12556]
if_stmt [12445,12556]
===
match
---
string: 'statsd_port' [6680,6693]
string: 'statsd_port' [6680,6693]
===
match
---
suite [2264,2300]
suite [2264,2300]
===
match
---
string: """         Returns the current configuration as an OrderedDict of OrderedDicts.          :param display_source: If False, the option value is returned. If True,             a tuple of (option_value, source) is returned. Source is either             'airflow.cfg', 'default', 'env var', or 'cmd'.         :type display_source: bool         :param display_sensitive: If True, the values of options set by env             vars and bash commands will be displayed. If False, those options             are shown as '< hidden >'         :type display_sensitive: bool         :param raw: Should the values be output as interpolated values, or the             "raw" form that can be fed back in to ConfigParser         :type raw: bool         :param include_env: Should the value of configuration from AIRFLOW__             environment variables be included or not         :type include_env: bool         :param include_cmds: Should the result of calling any *_cmd config be             set (True, default), or should the _cmd options be left as the             command to run (False)         :type include_cmds: bool         :param include_secret: Should the result of calling any *_secret config be             set (True, default), or should the _secret options be left as the             path to get the secret from (False)         :type include_secret: bool         :rtype: Dict[str, Dict[str, str]]         :return: Dictionary, where the key is the name of the section and the content is             the dictionary with the name of the parameter and its value.         """ [23050,24620]
string: """         Returns the current configuration as an OrderedDict of OrderedDicts.          :param display_source: If False, the option value is returned. If True,             a tuple of (option_value, source) is returned. Source is either             'airflow.cfg', 'default', 'env var', or 'cmd'.         :type display_source: bool         :param display_sensitive: If True, the values of options set by env             vars and bash commands will be displayed. If False, those options             are shown as '< hidden >'         :type display_sensitive: bool         :param raw: Should the values be output as interpolated values, or the             "raw" form that can be fed back in to ConfigParser         :type raw: bool         :param include_env: Should the value of configuration from AIRFLOW__             environment variables be included or not         :type include_env: bool         :param include_cmds: Should the result of calling any *_cmd config be             set (True, default), or should the _cmd options be left as the             command to run (False)         :type include_cmds: bool         :param include_secret: Should the result of calling any *_secret config be             set (True, default), or should the _secret options be left as the             path to get the secret from (False)         :type include_secret: bool         :rtype: Dict[str, Dict[str, str]]         :return: Dictionary, where the key is the name of the section and the content is             the dictionary with the name of the parameter and its value.         """ [23050,24620]
===
match
---
suite [18054,18083]
suite [18054,18083]
===
match
---
trailer [21397,21403]
trailer [21397,21403]
===
match
---
name: key [26199,26202]
name: key [26199,26202]
===
match
---
operator: , [6253,6254]
operator: , [6253,6254]
===
match
---
name: section [13819,13826]
name: section [13819,13826]
===
match
---
argument [19044,19059]
argument [19044,19059]
===
match
---
name: remove_option [20634,20647]
name: remove_option [20634,20647]
===
match
---
atom_expr [26506,26519]
atom_expr [26506,26519]
===
match
---
trailer [32935,32951]
trailer [32935,32951]
===
match
---
number: 2 [35892,35893]
number: 2 [35892,35893]
===
match
---
string: 'task_log_prefix_template' [6145,6171]
string: 'task_log_prefix_template' [6145,6171]
===
match
---
name: fallback_key [13624,13636]
name: fallback_key [13624,13636]
===
match
---
atom_expr [2523,2572]
atom_expr [2523,2572]
===
match
---
trailer [11950,11952]
trailer [11950,11952]
===
match
---
simple_stmt [28324,28381]
simple_stmt [28324,28381]
===
match
---
trailer [30610,30640]
trailer [30610,30640]
===
match
---
atom_expr [28331,28380]
atom_expr [28331,28380]
===
match
---
operator: , [33761,33762]
operator: , [33761,33762]
===
match
---
simple_stmt [3621,3737]
simple_stmt [3621,3737]
===
match
---
name: fp [22222,22224]
name: fp [22222,22224]
===
match
---
operator: , [39587,39588]
operator: , [39591,39592]
===
match
---
name: key [17854,17857]
name: key [17854,17857]
===
match
---
name: file [34535,34539]
name: file [34535,34539]
===
match
---
name: full_qualified_path [19444,19463]
name: full_qualified_path [19444,19463]
===
match
---
atom_expr [2463,2478]
atom_expr [2463,2478]
===
match
---
comparison [17548,17558]
comparison [17548,17558]
===
match
---
operator: , [25768,25769]
operator: , [25768,25769]
===
match
---
atom_expr [30543,30584]
atom_expr [30543,30584]
===
match
---
expr_stmt [21661,21678]
expr_stmt [21661,21678]
===
match
---
suite [19240,19482]
suite [19240,19482]
===
match
---
suite [21792,22177]
suite [21792,22177]
===
match
---
name: config_sources [25311,25325]
name: config_sources [25311,25325]
===
match
---
arglist [15046,15101]
arglist [15046,15101]
===
match
---
expr_stmt [32469,32484]
expr_stmt [32469,32484]
===
match
---
string: 'dags' [31139,31145]
string: 'dags' [31139,31145]
===
match
---
operator: , [11902,11903]
operator: , [11902,11903]
===
match
---
operator: , [27851,27852]
operator: , [27851,27852]
===
match
---
testlist_comp [5685,5715]
testlist_comp [5685,5715]
===
match
---
name: read [3385,3389]
name: read [3385,3389]
===
match
---
strings [18168,18295]
strings [18168,18295]
===
match
---
not_test [20999,21045]
not_test [20999,21045]
===
match
---
if_stmt [40059,40148]
if_stmt [40063,40152]
===
match
---
operator: , [14009,14010]
operator: , [14009,14010]
===
match
---
name: interpolated [2238,2250]
name: interpolated [2238,2250]
===
match
---
atom_expr [11173,11206]
atom_expr [11173,11206]
===
match
---
testlist_comp [17687,17704]
testlist_comp [17687,17704]
===
match
---
name: _get_option_from_config_file [16195,16223]
name: _get_option_from_config_file [16195,16223]
===
match
---
expr_stmt [17572,17603]
expr_stmt [17572,17603]
===
match
---
arglist [14227,14283]
arglist [14227,14283]
===
match
---
trailer [31420,31430]
trailer [31420,31430]
===
match
---
with_stmt [33029,33196]
with_stmt [33029,33196]
===
match
---
comparison [27050,27092]
comparison [27050,27092]
===
match
---
operator: , [14405,14406]
operator: , [14405,14406]
===
match
---
trailer [31361,31366]
trailer [31361,31366]
===
match
---
operator: , [6950,6951]
operator: , [6950,6951]
===
match
---
name: secrets_backend_list [39227,39247]
name: secrets_backend_list [39231,39251]
===
match
---
string: 'core' [6416,6422]
string: 'core' [6416,6422]
===
match
---
name: os [3197,3199]
name: os [3197,3199]
===
match
---
suite [11029,11288]
suite [11029,11288]
===
match
---
trailer [22545,22557]
trailer [22545,22557]
===
match
---
suite [17280,17398]
suite [17280,17398]
===
match
---
comparison [14452,14470]
comparison [14452,14470]
===
match
---
name: OrderedDict [26506,26517]
name: OrderedDict [26506,26517]
===
match
---
operator: = [9740,9741]
operator: = [9740,9741]
===
match
---
operator: , [24854,24855]
operator: , [24854,24855]
===
match
---
operator: , [16834,16835]
operator: , [16834,16835]
===
match
---
trailer [3212,3222]
trailer [3212,3222]
===
match
---
trailer [34304,34322]
trailer [34304,34322]
===
match
---
atom [33415,33643]
atom [33415,33643]
===
match
---
arglist [39570,39624]
arglist [39574,39628]
===
match
---
name: section [26571,26578]
name: section [26571,26578]
===
match
---
simple_stmt [37993,38036]
simple_stmt [37997,38040]
===
match
---
name: self [14850,14854]
name: self [14850,14854]
===
match
---
trailer [15350,15369]
trailer [15350,15369]
===
match
---
if_stmt [39136,39216]
if_stmt [39140,39220]
===
match
---
name: airflow_defaults [8341,8357]
name: airflow_defaults [8341,8357]
===
match
---
testlist_comp [24757,24776]
testlist_comp [24757,24776]
===
match
---
if_stmt [34283,34586]
if_stmt [34283,34586]
===
match
---
name: key [14263,14266]
name: key [14263,14266]
===
match
---
operator: { [19372,19373]
operator: { [19372,19373]
===
match
---
name: self [26028,26032]
name: self [26028,26032]
===
match
---
name: get [33751,33754]
name: get [33751,33754]
===
match
---
simple_stmt [31331,31455]
simple_stmt [31331,31455]
===
match
---
trailer [21455,21457]
trailer [21455,21457]
===
match
---
atom_expr [27680,27691]
atom_expr [27680,27691]
===
match
---
operator: * [38841,38842]
operator: * [38845,38846]
===
match
---
return_stmt [39796,39807]
return_stmt [39800,39811]
===
match
---
name: stacklevel [36699,36709]
name: stacklevel [36699,36709]
===
match
---
simple_stmt [1757,1853]
simple_stmt [1757,1853]
===
match
---
name: ConfigParser [1125,1137]
name: ConfigParser [1125,1137]
===
match
---
atom [6220,6253]
atom [6220,6253]
===
match
---
name: self [12820,12824]
name: self [12820,12824]
===
match
---
name: conf [33746,33750]
name: conf [33746,33750]
===
match
---
name: conf [36730,36734]
name: conf [36730,36734]
===
match
---
atom_expr [32339,32371]
atom_expr [32339,32371]
===
match
---
param [17458,17466]
param [17458,17466]
===
match
---
simple_stmt [19166,19208]
simple_stmt [19166,19208]
===
match
---
name: conf [34637,34641]
name: conf [34637,34641]
===
match
---
funcdef [11975,12964]
funcdef [11975,12964]
===
match
---
name: section [14706,14713]
name: section [14706,14713]
===
match
---
name: self [20969,20973]
name: self [20969,20973]
===
match
---
import_from [958,993]
import_from [958,993]
===
match
---
simple_stmt [2955,3000]
simple_stmt [2955,3000]
===
match
---
name: _using_old_value [8853,8869]
name: _using_old_value [8853,8869]
===
match
---
string: 'scheduler' [6917,6928]
string: 'scheduler' [6917,6928]
===
match
---
name: self [25289,25293]
name: self [25289,25293]
===
match
---
name: self [13360,13364]
name: self [13360,13364]
===
match
---
testlist_comp [17623,17639]
testlist_comp [17623,17639]
===
match
---
atom_expr [3448,3496]
atom_expr [3448,3496]
===
match
---
operator: = [29647,29648]
operator: = [29647,29648]
===
match
---
operator: = [29573,29574]
operator: = [29573,29574]
===
match
---
operator: , [1293,1294]
operator: , [1293,1294]
===
match
---
operator: , [5546,5547]
operator: , [5546,5547]
===
match
---
name: Dict [23025,23029]
name: Dict [23025,23029]
===
match
---
fstring_expr [2800,2808]
fstring_expr [2800,2808]
===
match
---
operator: , [12993,12994]
operator: , [12993,12994]
===
match
---
suite [2895,3096]
suite [2895,3096]
===
match
---
operator: , [6510,6511]
operator: , [6510,6511]
===
match
---
expr_stmt [13923,14017]
expr_stmt [13923,14017]
===
match
---
name: section [9161,9168]
name: section [9161,9168]
===
match
---
name: key [15098,15101]
name: key [15098,15101]
===
match
---
operator: = [22943,22944]
operator: = [22943,22944]
===
match
---
atom_expr [12373,12383]
atom_expr [12373,12383]
===
match
---
name: option [15960,15966]
name: option [15960,15966]
===
match
---
name: _write_section [22737,22751]
name: _write_section [22737,22751]
===
match
---
operator: , [29163,29164]
operator: , [29163,29164]
===
match
---
string: 'ignore' [2563,2571]
string: 'ignore' [2563,2571]
===
match
---
trailer [1586,1596]
trailer [1586,1596]
===
match
---
operator: , [6928,6929]
operator: , [6928,6929]
===
match
---
trailer [10538,10540]
trailer [10538,10540]
===
match
---
atom_expr [12727,12737]
atom_expr [12727,12737]
===
match
---
testlist_comp [7760,7918]
testlist_comp [7760,7918]
===
match
---
simple_stmt [37141,37177]
simple_stmt [37141,37181]
===
match
---
atom_expr [27739,27752]
atom_expr [27739,27752]
===
match
---
operator: = [25688,25689]
operator: = [25688,25689]
===
match
---
name: fp [22620,22622]
name: fp [22620,22622]
===
match
---
name: val [22078,22081]
name: val [22078,22081]
===
match
---
string: 'log_filename_template' [6229,6252]
string: 'log_filename_template' [6229,6252]
===
match
---
operator: , [1152,1153]
operator: , [1152,1153]
===
match
---
operator: != [2637,2639]
operator: != [2637,2639]
===
match
---
trailer [17491,17495]
trailer [17491,17495]
===
match
---
annassign [24643,24675]
annassign [24643,24675]
===
match
---
tfpdef [3128,3142]
tfpdef [3128,3142]
===
match
---
name: _get_config_value_from_secret_backend [13728,13765]
name: _get_config_value_from_secret_backend [13728,13765]
===
match
---
argument [1688,1704]
argument [1688,1704]
===
match
---
atom [6999,7038]
atom [6999,7038]
===
match
---
trailer [19549,19589]
trailer [19549,19589]
===
match
---
trailer [7634,7665]
trailer [7634,7665]
===
match
---
operator: , [26621,26622]
operator: , [26621,26622]
===
match
---
testlist_comp [7624,7680]
testlist_comp [7624,7680]
===
match
---
name: args [37583,37587]
name: args [37587,37591]
===
match
---
argument [39757,39790]
argument [39761,39794]
===
match
---
operator: , [7058,7059]
operator: , [7058,7059]
===
match
---
suite [21213,21251]
suite [21213,21251]
===
match
---
operator: , [11763,11764]
operator: , [11763,11764]
===
match
---
param [22216,22221]
param [22216,22221]
===
match
---
name: path [2152,2156]
name: path [2152,2156]
===
match
---
string: 'statsd_on' [6580,6591]
string: 'statsd_on' [6580,6591]
===
match
---
not_test [1639,1658]
not_test [1639,1658]
===
match
---
param [8167,8172]
param [8167,8172]
===
match
---
string: 'metrics' [6883,6892]
string: 'metrics' [6883,6892]
===
match
---
trailer [1576,1586]
trailer [1576,1586]
===
match
---
name: warnings [37262,37270]
name: warnings [37266,37274]
===
match
---
operator: , [11717,11718]
operator: , [11717,11718]
===
match
---
expr_stmt [32542,32631]
expr_stmt [32542,32631]
===
match
---
strings [17804,17932]
strings [17804,17932]
===
match
---
trailer [27302,27304]
trailer [27302,27304]
===
match
---
name: conf [35497,35501]
name: conf [35497,35501]
===
match
---
operator: } [7942,7943]
operator: } [7942,7943]
===
match
---
trailer [17520,17526]
trailer [17520,17526]
===
match
---
name: has_section [21105,21116]
name: has_section [21105,21116]
===
match
---
simple_stmt [22529,22561]
simple_stmt [22529,22561]
===
match
---
simple_stmt [2825,2839]
simple_stmt [2825,2839]
===
match
---
name: self [8634,8638]
name: self [8634,8638]
===
match
---
name: self [24772,24776]
name: self [24772,24776]
===
match
---
name: file_path [3248,3257]
name: file_path [3248,3257]
===
match
---
operator: , [20456,20457]
operator: , [20456,20457]
===
match
---
name: BaseSecretsBackend [1488,1506]
name: BaseSecretsBackend [1488,1506]
===
match
---
trailer [21639,21644]
trailer [21639,21644]
===
match
---
simple_stmt [34408,34495]
simple_stmt [34408,34495]
===
match
---
string: "'conf.set'" [38751,38763]
string: "'conf.set'" [38755,38767]
===
match
---
operator: * [38426,38427]
operator: * [38430,38431]
===
match
---
trailer [2415,2421]
trailer [2415,2421]
===
match
---
atom [5878,5916]
atom [5878,5916]
===
match
---
trailer [32900,32904]
trailer [32900,32904]
===
match
---
simple_stmt [17028,17076]
simple_stmt [17028,17076]
===
match
---
name: kwargs [8319,8325]
name: kwargs [8319,8325]
===
match
---
name: warn [29377,29381]
name: warn [29377,29381]
===
match
---
trailer [17581,17587]
trailer [17581,17587]
===
match
---
name: val [21925,21928]
name: val [21925,21928]
===
match
---
operator: = [3755,3756]
operator: = [3755,3756]
===
match
---
return_stmt [32092,32142]
return_stmt [32092,32142]
===
match
---
name: key [14582,14585]
name: key [14582,14585]
===
match
---
name: List [1295,1299]
name: List [1295,1299]
===
match
---
atom_expr [2410,2430]
atom_expr [2410,2430]
===
match
---
name: new_value [9034,9043]
name: new_value [9034,9043]
===
match
---
operator: = [3258,3259]
operator: = [3258,3259]
===
match
---
trailer [33315,33331]
trailer [33315,33331]
===
match
---
name: _using_old_value [10867,10883]
name: _using_old_value [10867,10883]
===
match
---
argument [39411,39428]
argument [39415,39432]
===
match
---
trailer [34605,34631]
trailer [34605,34631]
===
match
---
name: str [3158,3161]
name: str [3158,3161]
===
match
---
name: section [19735,19742]
name: section [19735,19742]
===
match
---
name: StrictVersion [1215,1228]
name: StrictVersion [1215,1228]
===
match
---
name: read [33339,33343]
name: read [33339,33343]
===
match
---
param [11018,11027]
param [11018,11027]
===
match
---
testlist_comp [22094,22106]
testlist_comp [22094,22106]
===
match
---
trailer [38895,38915]
trailer [38899,38919]
===
match
---
operator: , [13831,13832]
operator: , [13831,13832]
===
match
---
fstring_end: ' [18663,18664]
fstring_end: ' [18663,18664]
===
match
---
expr_stmt [2505,2609]
expr_stmt [2505,2609]
===
match
---
string: 'sql_alchemy_conn' [4495,4513]
string: 'sql_alchemy_conn' [4495,4513]
===
match
---
operator: , [5347,5348]
operator: , [5347,5348]
===
match
---
suite [27093,27129]
suite [27093,27129]
===
match
---
operator: ** [17983,17985]
operator: ** [17983,17985]
===
match
---
simple_stmt [9996,10011]
simple_stmt [9996,10011]
===
match
---
operator: , [28100,28101]
operator: , [28100,28101]
===
match
---
name: stacklevel [35881,35891]
name: stacklevel [35881,35891]
===
match
---
name: self [19983,19987]
name: self [19983,19987]
===
match
---
name: self [16224,16228]
name: self [16224,16228]
===
match
---
param [11368,11378]
param [11368,11378]
===
match
---
atom_expr [17185,17245]
atom_expr [17185,17245]
===
match
---
name: opt [25617,25620]
name: opt [25617,25620]
===
match
---
trailer [25983,26000]
trailer [25983,26000]
===
match
---
name: self [26617,26621]
name: self [26617,26621]
===
match
---
if_stmt [20427,20518]
if_stmt [20427,20518]
===
match
---
arith_expr [25984,25999]
arith_expr [25984,25999]
===
match
---
suite [34323,34586]
suite [34323,34586]
===
match
---
operator: ** [38460,38462]
operator: ** [38464,38466]
===
match
---
atom_expr [11253,11287]
atom_expr [11253,11287]
===
match
---
atom [9647,9721]
atom [9647,9721]
===
match
---
string: "Reading default test configuration from %s" [28934,28978]
string: "Reading default test configuration from %s" [28934,28978]
===
match
---
operator: } [4768,4769]
operator: } [4768,4769]
===
match
---
for_stmt [21759,22177]
for_stmt [21759,22177]
===
match
---
string: "'conf.getboolean'" [35824,35843]
string: "'conf.getboolean'" [35824,35843]
===
match
---
atom_expr [33689,33736]
atom_expr [33689,33736]
===
match
---
atom_expr [35112,35135]
atom_expr [35112,35135]
===
match
---
testlist_comp [6631,6657]
testlist_comp [6631,6657]
===
match
---
name: float [18439,18444]
name: float [18439,18444]
===
match
---
name: config_sources [28331,28345]
name: config_sources [28331,28345]
===
match
---
suite [38916,39248]
suite [38920,39252]
===
match
---
atom_expr [31151,31184]
atom_expr [31151,31184]
===
match
---
fstring_expr [18656,18661]
fstring_expr [18656,18661]
===
match
---
arglist [20648,20663]
arglist [20648,20663]
===
match
---
funcdef [12969,13332]
funcdef [12969,13332]
===
match
---
name: ValueError [18098,18108]
name: ValueError [18098,18108]
===
match
---
atom_expr [11215,11244]
atom_expr [11215,11244]
===
match
---
name: _TEST_DAGS_FOLDER [31030,31047]
name: _TEST_DAGS_FOLDER [31030,31047]
===
match
---
trailer [13555,13579]
trailer [13555,13579]
===
match
---
name: split [2416,2421]
name: split [2416,2421]
===
match
---
suite [19644,19709]
suite [19644,19709]
===
match
---
trailer [20437,20448]
trailer [20437,20448]
===
match
---
name: raw [25202,25205]
name: raw [25202,25205]
===
match
---
atom_expr [7651,7664]
atom_expr [7651,7664]
===
match
---
name: NoSectionError [20081,20095]
name: NoSectionError [20081,20095]
===
match
---
operator: , [37547,37548]
operator: , [37551,37552]
===
match
---
name: env_var [26869,26876]
name: env_var [26869,26876]
===
match
---
name: warnings [29368,29376]
name: warnings [29368,29376]
===
match
---
trailer [26918,26938]
trailer [26918,26938]
===
match
---
expr_stmt [3497,3579]
expr_stmt [3497,3579]
===
match
---
operator: + [10806,10807]
operator: + [10806,10807]
===
match
---
param [13819,13827]
param [13819,13827]
===
match
---
name: name [9123,9127]
name: name [9123,9127]
===
match
---
param [25429,25444]
param [25429,25444]
===
match
---
trailer [30908,30937]
trailer [30908,30937]
===
match
---
expr_stmt [10478,10540]
expr_stmt [10478,10540]
===
match
---
name: get [10435,10438]
name: get [10435,10438]
===
match
---
operator: = [27247,27248]
operator: = [27247,27248]
===
match
---
trailer [3272,3298]
trailer [3272,3298]
===
match
---
name: mkdir [30903,30908]
name: mkdir [30903,30908]
===
match
---
if_stmt [13098,13312]
if_stmt [13098,13312]
===
match
---
name: process [2587,2594]
name: process [2587,2594]
===
match
---
simple_stmt [30589,30641]
simple_stmt [30589,30641]
===
match
---
atom_expr [13119,13147]
atom_expr [13119,13147]
===
match
---
argument [29570,29589]
argument [29570,29589]
===
match
---
name: _get_option_from_commands [15710,15735]
name: _get_option_from_commands [15710,15735]
===
match
---
raise_stmt [18489,18678]
raise_stmt [18489,18678]
===
match
---
operator: = [35891,35892]
operator: = [35891,35892]
===
match
---
fstring_string: ". [18661,18663]
fstring_string: ". [18661,18663]
===
match
---
parameters [30430,30444]
parameters [30430,30444]
===
match
---
name: environ [12534,12541]
name: environ [12534,12541]
===
match
---
arith_expr [12673,12692]
arith_expr [12673,12692]
===
match
---
name: file [33180,33184]
name: file [33180,33184]
===
match
---
simple_stmt [2332,2370]
simple_stmt [2332,2370]
===
match
---
atom_expr [32509,32523]
atom_expr [32509,32523]
===
match
---
atom [6838,6872]
atom [6838,6872]
===
match
---
name: option [14646,14652]
name: option [14646,14652]
===
match
---
name: dictionary [19615,19625]
name: dictionary [19615,19625]
===
match
---
operator: , [2511,2512]
operator: , [2511,2512]
===
match
---
simple_stmt [30876,30938]
simple_stmt [30876,30938]
===
match
---
trailer [21715,21735]
trailer [21715,21735]
===
match
---
operator: } [31906,31907]
operator: } [31906,31907]
===
match
---
and_test [9802,9850]
and_test [9802,9850]
===
match
---
operator: , [9676,9677]
operator: , [9676,9677]
===
match
---
name: str [24660,24663]
name: str [24660,24663]
===
match
---
operator: , [24663,24664]
operator: , [24663,24664]
===
match
---
name: display_sensitive [22880,22897]
name: display_sensitive [22880,22897]
===
match
---
name: deprecated_section [17144,17162]
name: deprecated_section [17144,17162]
===
match
---
operator: , [1733,1734]
operator: , [1733,1734]
===
match
---
simple_stmt [1431,1507]
simple_stmt [1431,1507]
===
match
---
atom [5726,5760]
atom [5726,5760]
===
match
---
return_stmt [19166,19207]
return_stmt [19166,19207]
===
match
---
fstring_string: " section.  [19396,19407]
fstring_string: " section.  [19396,19407]
===
match
---
operator: = [11712,11713]
operator: = [11712,11713]
===
match
---
operator: = [30841,30842]
operator: = [30841,30842]
===
match
---
name: decode [32450,32456]
name: decode [32450,32456]
===
match
---
argument [11708,11717]
argument [11708,11717]
===
match
---
name: _section [21775,21783]
name: _section [21775,21783]
===
match
---
argument [38426,38431]
argument [38430,38435]
===
match
---
operator: , [6032,6033]
operator: , [6032,6033]
===
match
---
name: fallback [39611,39619]
name: fallback [39615,39623]
===
match
---
suite [15021,15199]
suite [15021,15199]
===
match
---
atom_expr [1757,1852]
atom_expr [1757,1852]
===
match
---
fstring_start: f' [19425,19427]
fstring_start: f' [19425,19427]
===
match
---
trailer [1646,1658]
trailer [1646,1658]
===
match
---
operator: , [12810,12811]
operator: , [12810,12811]
===
match
---
operator: = [29738,29739]
operator: = [29738,29739]
===
match
---
simple_stmt [33334,33360]
simple_stmt [33334,33360]
===
match
---
name: _delimiters [22546,22557]
name: _delimiters [22546,22557]
===
match
---
string: """Historical set""" [38517,38537]
string: """Historical set""" [38521,38541]
===
match
---
suite [33680,33737]
suite [33680,33737]
===
match
---
suite [25276,25367]
suite [25276,25367]
===
match
---
name: self [25564,25568]
name: self [25564,25568]
===
match
---
trailer [37698,37703]
trailer [37702,37707]
===
match
---
atom [7711,7943]
atom [7711,7943]
===
match
---
name: alternative_secrets_config_dict [39759,39790]
name: alternative_secrets_config_dict [39763,39794]
===
match
---
trailer [11410,11853]
trailer [11410,11853]
===
match
---
simple_stmt [11918,11970]
simple_stmt [11918,11970]
===
match
---
trailer [10817,10839]
trailer [10817,10839]
===
match
---
expr_stmt [2955,2999]
expr_stmt [2955,2999]
===
match
---
operator: = [12671,12672]
operator: = [12671,12672]
===
match
---
name: option [17176,17182]
name: option [17176,17182]
===
match
---
trailer [22650,22660]
trailer [22650,22660]
===
match
---
param [26028,26033]
param [26028,26033]
===
match
---
name: section [22693,22700]
name: section [22693,22700]
===
match
---
string: 'w' [32794,32797]
string: 'w' [32794,32797]
===
match
---
parameters [20684,20704]
parameters [20684,20704]
===
match
---
arglist [29570,29656]
arglist [29570,29656]
===
match
---
suite [26679,27773]
suite [26679,27773]
===
match
---
atom_expr [28925,29002]
atom_expr [28925,29002]
===
match
---
name: template [31640,31648]
name: template [31640,31648]
===
match
---
simple_stmt [29118,29183]
simple_stmt [29118,29183]
===
match
---
operator: * [37619,37620]
operator: * [37623,37624]
===
match
---
name: configs [24856,24863]
name: configs [24856,24863]
===
match
---
trailer [26520,26527]
trailer [26520,26527]
===
match
---
testlist_comp [5247,5271]
testlist_comp [5247,5271]
===
match
---
suite [22587,22681]
suite [22587,22681]
===
match
---
string: 'logging' [5147,5156]
string: 'logging' [5147,5156]
===
match
---
name: secrets_backend_list [40334,40354]
name: secrets_backend_list [40338,40358]
===
match
---
argument [39611,39624]
argument [39615,39628]
===
match
---
suite [15947,16166]
suite [15947,16166]
===
match
---
fstring_string: " key in " [19377,19387]
fstring_string: " key in " [19377,19387]
===
match
---
name: section [20986,20993]
name: section [20986,20993]
===
match
---
suite [12182,12238]
suite [12182,12238]
===
match
---
trailer [16545,16547]
trailer [16545,16547]
===
match
---
trailer [31356,31361]
trailer [31356,31361]
===
match
---
atom_expr [13728,13779]
atom_expr [13728,13779]
===
match
---
testlist_comp [5110,5135]
testlist_comp [5110,5135]
===
match
---
operator: + [10721,10722]
operator: + [10721,10722]
===
match
---
simple_stmt [16782,16863]
simple_stmt [16782,16863]
===
match
---
name: include_env [22932,22943]
name: include_env [22932,22943]
===
match
---
operator: , [31441,31442]
operator: , [31441,31442]
===
match
---
name: AIRFLOW_HOME [30792,30804]
name: AIRFLOW_HOME [30792,30804]
===
match
---
suite [37225,37599]
suite [37229,37603]
===
match
---
not_test [19091,19114]
not_test [19091,19114]
===
match
---
argument [19671,19692]
argument [19671,19692]
===
match
---
factor [33160,33162]
factor [33160,33162]
===
match
---
operator: = [2382,2383]
operator: = [2382,2383]
===
match
---
number: 2 [35099,35100]
number: 2 [35099,35100]
===
match
---
decorator [11859,11873]
decorator [11859,11873]
===
match
---
string: 'password' [4679,4689]
string: 'password' [4679,4689]
===
match
---
arglist [2537,2571]
arglist [2537,2571]
===
match
---
operator: , [15237,15238]
operator: , [15237,15238]
===
match
---
simple_stmt [18122,18310]
simple_stmt [18122,18310]
===
match
---
operator: , [1123,1124]
operator: , [1123,1124]
===
match
---
simple_stmt [902,913]
simple_stmt [902,913]
===
match
---
atom [7224,7258]
atom [7224,7258]
===
match
---
name: section [9004,9011]
name: section [9004,9011]
===
match
---
fstring [9893,9960]
fstring [9893,9960]
===
match
---
atom [6566,6592]
atom [6566,6592]
===
match
---
name: section [25897,25904]
name: section [25897,25904]
===
match
---
atom_expr [16804,16861]
atom_expr [16804,16861]
===
match
---
trailer [39293,39313]
trailer [39297,39317]
===
match
---
operator: = [21709,21710]
operator: = [21709,21710]
===
match
---
argument [37582,37587]
argument [37586,37591]
===
match
---
operator: = [27114,27115]
operator: = [27114,27115]
===
match
---
simple_stmt [32147,32204]
simple_stmt [32147,32204]
===
match
---
trailer [34463,34494]
trailer [34463,34494]
===
match
---
atom_expr [14850,14896]
atom_expr [14850,14896]
===
match
---
subscriptlist [23020,23039]
subscriptlist [23020,23039]
===
match
---
trailer [32646,32653]
trailer [32646,32653]
===
match
---
name: val [17555,17558]
name: val [17555,17558]
===
match
---
operator: } [18608,18609]
operator: } [18608,18609]
===
match
---
if_stmt [21985,22145]
if_stmt [21985,22145]
===
match
---
operator: } [19395,19396]
operator: } [19395,19396]
===
match
---
operator: , [26861,26862]
operator: , [26861,26862]
===
match
---
suite [1659,1853]
suite [1659,1853]
===
match
---
name: section [12803,12810]
name: section [12803,12810]
===
match
---
string: '#' [17548,17551]
string: '#' [17548,17551]
===
match
---
simple_stmt [20110,20123]
simple_stmt [20110,20123]
===
match
---
operator: } [7691,7692]
operator: } [7691,7692]
===
match
---
name: self [8441,8445]
name: self [8441,8445]
===
match
---
suite [15459,15681]
suite [15459,15681]
===
match
---
trailer [34559,34585]
trailer [34559,34585]
===
match
---
name: OrderedDict [21318,21329]
name: OrderedDict [21318,21329]
===
match
---
name: TEST_CONFIG_FILE [29165,29181]
name: TEST_CONFIG_FILE [29165,29181]
===
match
---
trailer [31258,31263]
trailer [31258,31263]
===
match
---
string: 'executor' [9947,9957]
string: 'executor' [9947,9957]
===
match
---
param [16271,16278]
param [16271,16278]
===
match
---
testlist_comp [5763,5792]
testlist_comp [5763,5792]
===
match
---
name: section [11003,11010]
name: section [11003,11010]
===
match
---
trailer [24991,25005]
trailer [24991,25005]
===
match
---
atom_expr [9611,9639]
atom_expr [9611,9639]
===
match
---
simple_stmt [17176,17246]
simple_stmt [17176,17246]
===
match
---
operator: ** [14996,14998]
operator: ** [14996,14998]
===
match
---
operator: , [38431,38432]
operator: , [38435,38436]
===
match
---
string: '#' [17588,17591]
string: '#' [17588,17591]
===
match
---
expr_stmt [33409,33643]
expr_stmt [33409,33643]
===
match
---
name: key [25508,25511]
name: key [25508,25511]
===
match
---
name: filenames [19502,19511]
name: filenames [19502,19511]
===
match
---
name: validate [40393,40401]
name: validate [40397,40405]
===
match
---
operator: ** [18031,18033]
operator: ** [18031,18033]
===
match
---
atom_expr [30346,30405]
atom_expr [30346,30405]
===
match
---
atom_expr [1643,1658]
atom_expr [1643,1658]
===
match
---
trailer [26876,26882]
trailer [26876,26882]
===
match
---
expr_stmt [3168,3243]
expr_stmt [3168,3243]
===
match
---
name: airflow [1382,1389]
name: airflow [1382,1389]
===
match
---
atom_expr [18074,18082]
atom_expr [18074,18082]
===
match
---
arglist [29399,29741]
arglist [29399,29741]
===
match
---
name: set [38837,38840]
name: set [38841,38844]
===
match
---
atom [4735,4762]
atom [4735,4762]
===
match
---
name: super [13670,13675]
name: super [13670,13675]
===
match
---
atom_expr [21533,21568]
atom_expr [21533,21568]
===
match
---
trailer [11683,11690]
trailer [11683,11690]
===
match
---
operator: = [22999,23000]
operator: = [22999,23000]
===
match
---
sync_comp_for [2573,2608]
sync_comp_for [2573,2608]
===
match
---
comparison [27611,27656]
comparison [27611,27656]
===
match
---
testlist_star_expr [34408,34435]
testlist_star_expr [34408,34435]
===
match
---
testlist_comp [6023,6053]
testlist_comp [6023,6053]
===
match
---
name: section [26497,26504]
name: section [26497,26504]
===
match
---
operator: , [18389,18390]
operator: , [18389,18390]
===
match
---
trailer [30550,30555]
trailer [30550,30555]
===
match
---
name: option [15472,15478]
name: option [15472,15478]
===
match
---
atom_expr [16525,16576]
atom_expr [16525,16576]
===
match
---
operator: * [36370,36371]
operator: * [36370,36371]
===
match
---
string: 'logging' [5575,5584]
string: 'logging' [5575,5584]
===
match
---
name: airflow_defaults [21167,21183]
name: airflow_defaults [21167,21183]
===
match
---
atom_expr [14360,14440]
atom_expr [14360,14440]
===
match
---
name: replace [27177,27184]
name: replace [27177,27184]
===
match
---
operator: { [27761,27762]
operator: { [27761,27762]
===
match
---
testlist_comp [7049,7081]
testlist_comp [7049,7081]
===
match
---
name: path [3760,3764]
name: path [3760,3764]
===
match
---
suite [27657,27692]
suite [27657,27692]
===
match
---
operator: , [17503,17504]
operator: , [17503,17504]
===
match
---
param [19735,19743]
param [19735,19743]
===
match
---
name: get [34139,34142]
name: get [34139,34142]
===
match
---
argument [11786,11801]
argument [11786,11801]
===
match
---
atom_expr [26436,26458]
atom_expr [26436,26458]
===
match
---
simple_stmt [35112,35136]
simple_stmt [35112,35136]
===
match
---
funcdef [1855,2300]
funcdef [1855,2300]
===
match
---
operator: , [28978,28979]
operator: , [28978,28979]
===
match
---
simple_stmt [11163,11207]
simple_stmt [11163,11207]
===
match
---
trailer [21835,21840]
trailer [21835,21840]
===
match
---
name: expand_env_var [32154,32168]
name: expand_env_var [32154,32168]
===
match
---
atom [4700,4725]
atom [4700,4725]
===
match
---
operator: = [26311,26312]
operator: = [26311,26312]
===
match
---
trailer [40243,40255]
trailer [40247,40259]
===
match
---
atom_expr [8634,8664]
atom_expr [8634,8664]
===
match
---
trailer [2132,2137]
trailer [2132,2137]
===
match
---
if_stmt [15437,15681]
if_stmt [15437,15681]
===
match
---
if_stmt [15553,15681]
if_stmt [15553,15681]
===
match
---
name: AIRFLOW_CONFIG [32936,32950]
name: AIRFLOW_CONFIG [32936,32950]
===
match
---
argument [39430,39443]
argument [39434,39447]
===
match
---
operator: , [5997,5998]
operator: , [5997,5998]
===
match
---
name: key [12812,12815]
name: key [12812,12815]
===
match
---
name: self [9065,9069]
name: self [9065,9069]
===
match
---
name: _get_secret_option [15486,15504]
name: _get_secret_option [15486,15504]
===
match
---
name: get [13984,13987]
name: get [13984,13987]
===
match
---
trailer [31881,31883]
trailer [31881,31883]
===
match
---
operator: -> [39282,39284]
operator: -> [39286,39288]
===
match
---
operator: = [31207,31208]
operator: = [31207,31208]
===
match
---
name: section [11262,11269]
name: section [11262,11269]
===
match
---
operator: , [14789,14790]
operator: , [14789,14790]
===
match
---
trailer [35133,35135]
trailer [35133,35135]
===
match
---
suite [38512,38858]
suite [38516,38862]
===
match
---
atom_expr [12171,12181]
atom_expr [12171,12181]
===
match
---
name: Path [30884,30888]
name: Path [30884,30888]
===
match
---
string: '< hidden >' [26313,26325]
string: '< hidden >' [26313,26325]
===
match
---
name: self [18328,18332]
name: self [18328,18332]
===
match
---
param [11895,11903]
param [11895,11903]
===
match
---
name: ensure_secrets_loaded [38864,38885]
name: ensure_secrets_loaded [38868,38889]
===
match
---
name: env_var [2059,2066]
name: env_var [2059,2066]
===
match
---
name: conf [33253,33257]
name: conf [33253,33257]
===
match
---
name: strip [32905,32910]
name: strip [32905,32910]
===
match
---
name: loads [39538,39543]
name: loads [39542,39547]
===
match
---
operator: , [37199,37200]
operator: , [37203,37204]
===
match
---
simple_stmt [28529,28543]
simple_stmt [28529,28543]
===
match
---
fstring_string: AIRFLOW__ [11927,11936]
fstring_string: AIRFLOW__ [11927,11936]
===
match
---
atom [7084,7120]
atom [7084,7120]
===
match
---
name: json [39533,39537]
name: json [39537,39541]
===
match
---
suite [39671,39721]
suite [39675,39725]
===
match
---
testlist_comp [4632,4658]
testlist_comp [4632,4658]
===
match
---
param [11012,11017]
param [11012,11017]
===
match
---
name: deprecated_section [29336,29354]
name: deprecated_section [29336,29354]
===
match
---
suite [25663,25703]
suite [25663,25703]
===
match
---
name: setdefault [26486,26496]
name: setdefault [26486,26496]
===
match
---
name: section [15089,15096]
name: section [15089,15096]
===
match
---
operator: , [18394,18395]
operator: , [18394,18395]
===
match
---
string: 'navbar_color' [7607,7621]
string: 'navbar_color' [7607,7621]
===
match
---
suite [26356,26392]
suite [26356,26392]
===
match
---
trailer [25520,25544]
trailer [25520,25544]
===
match
---
atom_expr [31404,31430]
atom_expr [31404,31430]
===
match
---
expr_stmt [27243,27265]
expr_stmt [27243,27265]
===
match
---
atom_expr [3932,3959]
atom_expr [3932,3959]
===
match
---
atom_expr [31458,31494]
atom_expr [31458,31494]
===
match
---
operator: , [35050,35051]
operator: , [35050,35051]
===
match
---
name: self [9340,9344]
name: self [9340,9344]
===
match
---
operator: = [13231,13232]
operator: = [13231,13232]
===
match
---
suite [32672,32914]
suite [32672,32914]
===
match
---
operator: { [5068,5069]
operator: { [5068,5069]
===
match
---
testlist_comp [6221,6252]
testlist_comp [6221,6252]
===
match
---
name: format [22475,22481]
name: format [22475,22481]
===
match
---
operator: , [35100,35101]
operator: , [35100,35101]
===
match
---
strings [33425,33637]
strings [33425,33637]
===
match
---
operator: = [27678,27679]
operator: = [27678,27679]
===
match
---
simple_stmt [9730,9791]
simple_stmt [9730,9791]
===
match
---
trailer [18077,18082]
trailer [18077,18082]
===
match
---
operator: , [36345,36346]
operator: , [36345,36346]
===
match
---
param [19744,19750]
param [19744,19750]
===
match
---
operator: , [15756,15757]
operator: , [15756,15757]
===
match
---
operator: , [26504,26505]
operator: , [26504,26505]
===
match
---
trailer [20721,20756]
trailer [20721,20756]
===
match
---
name: kwargs [36349,36355]
name: kwargs [36349,36355]
===
match
---
expr_stmt [5047,7295]
expr_stmt [5047,7295]
===
match
---
operator: ** [13833,13835]
operator: ** [13833,13835]
===
match
---
arglist [26448,26457]
arglist [26448,26457]
===
match
---
name: key [13891,13894]
name: key [13891,13894]
===
match
---
return_stmt [35905,35944]
return_stmt [35905,35944]
===
match
---
operator: , [5973,5974]
operator: , [5973,5974]
===
match
---
name: multiprocessing [10501,10516]
name: multiprocessing [10501,10516]
===
match
---
funcdef [22206,22810]
funcdef [22206,22810]
===
match
---
operator: } [11967,11968]
operator: } [11967,11968]
===
match
---
trailer [7770,7822]
trailer [7770,7822]
===
match
---
suite [4040,30274]
suite [4040,30274]
===
match
---
operator: , [36375,36376]
operator: , [36375,36376]
===
match
---
name: new [29611,29614]
name: new [29611,29614]
===
match
---
trailer [35621,35900]
trailer [35621,35900]
===
match
---
operator: = [14514,14515]
operator: = [14514,14515]
===
match
---
name: has_option [16342,16352]
name: has_option [16342,16352]
===
match
---
param [18704,18712]
param [18704,18712]
===
match
---
name: configs [27921,27928]
name: configs [27921,27928]
===
match
---
trailer [28846,28884]
trailer [28846,28884]
===
match
---
name: opt [26430,26433]
name: opt [26430,26433]
===
match
---
name: getfloat [35951,35959]
name: getfloat [35951,35959]
===
match
---
testlist_comp [4487,4513]
testlist_comp [4487,4513]
===
match
---
raise_stmt [15116,15198]
raise_stmt [15116,15198]
===
match
---
operator: , [16748,16749]
operator: , [16748,16749]
===
match
---
trailer [31153,31158]
trailer [31153,31158]
===
match
---
name: config_sources [26034,26048]
name: config_sources [26034,26048]
===
match
---
param [9404,9408]
param [9404,9408]
===
match
---
comparison [14296,14314]
comparison [14296,14314]
===
match
---
trailer [31411,31420]
trailer [31411,31420]
===
match
---
name: sect [28529,28533]
name: sect [28529,28533]
===
match
---
operator: , [26048,26049]
operator: , [26048,26049]
===
match
---
operator: , [27876,27877]
operator: , [27876,27877]
===
match
---
name: key [18713,18716]
name: key [18713,18716]
===
match
---
trailer [33697,33702]
trailer [33697,33702]
===
match
---
string: 'scheduler' [6631,6642]
string: 'scheduler' [6631,6642]
===
match
---
for_stmt [8678,9331]
for_stmt [8678,9331]
===
match
---
string: 'task_log_reader' [6512,6529]
string: 'task_log_reader' [6512,6529]
===
match
---
name: opt [27110,27113]
name: opt [27110,27113]
===
match
---
name: get [14978,14981]
name: get [14978,14981]
===
match
---
operator: } [18291,18292]
operator: } [18291,18292]
===
match
---
name: key [19373,19376]
name: key [19373,19376]
===
match
---
operator: = [30083,30084]
operator: = [30083,30084]
===
match
---
name: bool [20750,20754]
name: bool [20750,20754]
===
match
---
operator: , [29740,29741]
operator: , [29740,29741]
===
match
---
simple_stmt [39179,39216]
simple_stmt [39183,39220]
===
match
---
simple_stmt [33253,33333]
simple_stmt [33253,33333]
===
match
---
atom_expr [32499,32540]
atom_expr [32499,32540]
===
match
---
arglist [39411,39443]
arglist [39415,39447]
===
match
---
operator: , [38394,38395]
operator: , [38398,38399]
===
match
---
name: path [32642,32646]
name: path [32642,32646]
===
match
---
testlist_comp [13989,14001]
testlist_comp [13989,14001]
===
match
---
expr_stmt [26908,26952]
expr_stmt [26908,26952]
===
match
---
suite [2218,2251]
suite [2218,2251]
===
match
---
argument [11765,11784]
argument [11765,11784]
===
match
---
trailer [2421,2430]
trailer [2421,2430]
===
match
---
expr_stmt [14351,14440]
expr_stmt [14351,14440]
===
match
---
name: AirflowConfigException [10624,10646]
name: AirflowConfigException [10624,10646]
===
match
---
simple_stmt [11397,11854]
simple_stmt [11397,11854]
===
match
---
operator: , [16118,16119]
operator: , [16118,16119]
===
match
---
operator: , [33234,33235]
operator: , [33234,33235]
===
match
---
param [20146,20151]
param [20146,20151]
===
match
---
operator: , [23023,23024]
operator: , [23023,23024]
===
match
---
name: kwargs [37203,37209]
name: kwargs [37207,37213]
===
match
---
trailer [16699,16715]
trailer [16699,16715]
===
match
---
trailer [31871,31873]
trailer [31871,31873]
===
match
---
string: 'statsd_host' [6644,6657]
string: 'statsd_host' [6644,6657]
===
match
---
string: 'airflow' [1842,1851]
string: 'airflow' [1842,1851]
===
match
---
atom_expr [12531,12554]
atom_expr [12531,12554]
===
match
---
trailer [22751,22809]
trailer [22751,22809]
===
match
---
name: section [27289,27296]
name: section [27289,27296]
===
match
---
comparison [29325,29354]
comparison [29325,29354]
===
match
---
argument [1781,1797]
argument [1781,1797]
===
match
---
name: _get_env_var_option [26919,26938]
name: _get_env_var_option [26919,26938]
===
match
---
not_test [3007,3025]
not_test [3007,3025]
===
match
---
atom_expr [13551,13579]
atom_expr [13551,13579]
===
match
---
operator: , [14718,14719]
operator: , [14718,14719]
===
match
---
fstring_start: f" [2772,2774]
fstring_start: f" [2772,2774]
===
match
---
simple_stmt [14027,14118]
simple_stmt [14027,14118]
===
match
---
name: option [14168,14174]
name: option [14168,14174]
===
match
---
while_stmt [2095,2300]
while_stmt [2095,2300]
===
match
---
name: get_all_start_methods [10517,10538]
name: get_all_start_methods [10517,10538]
===
match
---
operator: ** [16852,16854]
operator: ** [16852,16854]
===
match
---
arglist [7635,7664]
arglist [7635,7664]
===
match
---
operator: + [34257,34258]
operator: + [34257,34258]
===
match
---
atom [24673,24675]
atom [24673,24675]
===
match
---
name: setdefault [28346,28356]
name: setdefault [28346,28356]
===
match
---
atom_expr [22600,22680]
atom_expr [22600,22680]
===
match
---
name: args [35961,35965]
name: args [35961,35965]
===
match
---
name: self [22765,22769]
name: self [22765,22769]
===
match
---
operator: , [7943,7944]
operator: , [7943,7944]
===
match
---
arglist [14068,14116]
arglist [14068,14116]
===
match
---
operator: , [35843,35844]
operator: , [35843,35844]
===
match
---
trailer [32456,32458]
trailer [32456,32458]
===
match
---
trailer [8925,8929]
trailer [8925,8929]
===
match
---
name: deprecated_section [15615,15633]
name: deprecated_section [15615,15633]
===
match
---
operator: = [37545,37546]
operator: = [37549,37550]
===
match
---
name: key [17327,17330]
name: key [17327,17330]
===
match
---
simple_stmt [13448,13479]
simple_stmt [13448,13479]
===
match
---
atom_expr [20479,20517]
atom_expr [20479,20517]
===
match
---
if_stmt [32914,33196]
if_stmt [32914,33196]
===
match
---
atom_expr [33669,33679]
atom_expr [33669,33679]
===
match
---
name: fallback_key [13254,13266]
name: fallback_key [13254,13266]
===
match
---
atom [6764,6794]
atom [6764,6794]
===
match
---
trailer [11405,11410]
trailer [11405,11410]
===
match
---
name: __name__ [1587,1595]
name: __name__ [1587,1595]
===
match
---
name: key [26863,26866]
name: key [26863,26866]
===
match
---
sync_comp_for [31854,31906]
sync_comp_for [31854,31906]
===
match
---
operator: , [14430,14431]
operator: , [14430,14431]
===
match
---
param [35967,35975]
param [35967,35975]
===
match
---
param [17969,17977]
param [17969,17977]
===
match
---
atom_expr [34803,35107]
atom_expr [34803,35107]
===
match
---
suite [16678,16863]
suite [16678,16863]
===
match
---
simple_stmt [13018,13046]
simple_stmt [13018,13046]
===
match
---
name: section [20691,20698]
name: section [20691,20698]
===
match
---
operator: = [31254,31255]
operator: = [31254,31255]
===
match
---
name: self [25516,25520]
name: self [25516,25520]
===
match
---
simple_stmt [11253,11288]
simple_stmt [11253,11288]
===
match
---
fstring_expr [15170,15175]
fstring_expr [15170,15175]
===
match
---
simple_stmt [28584,28681]
simple_stmt [28584,28681]
===
match
---
atom_expr [27173,27195]
atom_expr [27173,27195]
===
match
---
string: 'logging' [5358,5367]
string: 'logging' [5358,5367]
===
match
---
name: PendingDeprecationWarning [1808,1833]
name: PendingDeprecationWarning [1808,1833]
===
match
---
suite [14626,14653]
suite [14626,14653]
===
match
---
testlist_comp [7225,7257]
testlist_comp [7225,7257]
===
match
---
operator: , [22097,22098]
operator: , [22097,22098]
===
match
---
name: self [22572,22576]
name: self [22572,22576]
===
match
---
param [20685,20690]
param [20685,20690]
===
match
---
operator: -> [38888,38890]
operator: -> [38892,38894]
===
match
---
arglist [8930,8953]
arglist [8930,8953]
===
match
---
operator: , [20570,20571]
operator: , [20570,20571]
===
match
---
atom [5647,5682]
atom [5647,5682]
===
match
---
operator: , [36257,36258]
operator: , [36257,36258]
===
match
---
param [27837,27852]
param [27837,27852]
===
match
---
import_as_names [1289,1323]
import_as_names [1289,1323]
===
match
---
fstring_string: Current value: " [18640,18656]
fstring_string: Current value: " [18640,18656]
===
match
---
if_stmt [34587,34661]
if_stmt [34587,34661]
===
match
---
for_stmt [22689,22810]
for_stmt [22689,22810]
===
match
---
atom [6602,6628]
atom [6602,6628]
===
match
---
name: new_value [9257,9266]
name: new_value [9257,9266]
===
match
---
sync_comp_for [31885,31906]
sync_comp_for [31885,31906]
===
match
---
expr_stmt [39499,39639]
expr_stmt [39503,39643]
===
match
---
trailer [14871,14882]
trailer [14871,14882]
===
match
---
name: option [15883,15889]
name: option [15883,15889]
===
match
---
atom_expr [10430,10465]
atom_expr [10430,10465]
===
match
---
string: 'unit_test_mode' [34614,34630]
string: 'unit_test_mode' [34614,34630]
===
match
---
string: """     Read Airflow configs from YAML file      :return: Python dictionary containing configs & their info     """ [3621,3736]
string: """     Read Airflow configs from YAML file      :return: Python dictionary containing configs & their info     """ [3621,3736]
===
match
---
arglist [15370,15382]
arglist [15370,15382]
===
match
---
arglist [25151,25205]
arglist [25151,25205]
===
match
---
name: default_config [8401,8415]
name: default_config [8401,8415]
===
match
---
dictorsetmaker [26529,26537]
dictorsetmaker [26529,26537]
===
match
---
trailer [2151,2156]
trailer [2151,2156]
===
match
---
atom_expr [18128,18309]
atom_expr [18128,18309]
===
match
---
operator: = [26912,26913]
operator: = [26912,26913]
===
match
---
name: _get_cmd_option [12973,12988]
name: _get_cmd_option [12973,12988]
===
match
---
name: configparser [1097,1109]
name: configparser [1097,1109]
===
match
---
operator: = [22897,22898]
operator: = [22897,22898]
===
match
---
expr_stmt [22042,22052]
expr_stmt [22042,22052]
===
match
---
name: cryptography [1342,1354]
name: cryptography [1342,1354]
===
match
---
simple_stmt [25826,25855]
simple_stmt [25826,25855]
===
match
---
expr_stmt [26851,26891]
expr_stmt [26851,26891]
===
match
---
trailer [38123,38128]
trailer [38127,38132]
===
match
---
simple_stmt [17384,17398]
simple_stmt [17384,17398]
===
match
---
name: section [19388,19395]
name: section [19388,19395]
===
match
---
name: DeprecationWarning [29692,29710]
name: DeprecationWarning [29692,29710]
===
match
---
funcdef [35525,35945]
funcdef [35525,35945]
===
match
---
parameters [30296,30298]
parameters [30296,30298]
===
match
---
string: 'logging' [5441,5450]
string: 'logging' [5441,5450]
===
match
---
testlist_comp [6312,6353]
testlist_comp [6312,6353]
===
match
---
dictorsetmaker [7507,7560]
dictorsetmaker [7507,7560]
===
match
---
operator: , [34149,34150]
operator: , [34149,34150]
===
match
---
trailer [3785,3795]
trailer [3785,3795]
===
match
---
comparison [8401,8427]
comparison [8401,8427]
===
match
---
parameters [25422,25484]
parameters [25422,25484]
===
match
---
operator: { [2710,2711]
operator: { [2710,2711]
===
match
---
operator: , [9168,9169]
operator: , [9168,9169]
===
match
---
arglist [25588,25600]
arglist [25588,25600]
===
match
---
atom_expr [10261,10343]
atom_expr [10261,10343]
===
match
---
suite [9410,10858]
suite [9410,10858]
===
match
---
name: section [16279,16286]
name: section [16279,16286]
===
match
---
name: TEMPLATE_START [32542,32556]
name: TEMPLATE_START [32542,32556]
===
match
---
trailer [33279,33332]
trailer [33279,33332]
===
match
---
operator: , [10445,10446]
operator: , [10445,10446]
===
match
---
operator: , [20150,20151]
operator: , [20150,20151]
===
match
---
name: get_airflow_home [30807,30823]
name: get_airflow_home [30807,30823]
===
match
---
simple_stmt [38825,38858]
simple_stmt [38829,38862]
===
match
---
operator: , [27253,27254]
operator: , [27253,27254]
===
match
---
simple_stmt [32957,33025]
simple_stmt [32957,33025]
===
match
---
funcdef [15706,16186]
funcdef [15706,16186]
===
match
---
trailer [21310,21317]
trailer [21310,21317]
===
match
---
operator: , [30132,30133]
operator: , [30132,30133]
===
match
---
return_stmt [15415,15428]
return_stmt [15415,15428]
===
match
---
simple_stmt [21361,21410]
simple_stmt [21361,21410]
===
match
---
param [36370,36376]
param [36370,36376]
===
match
---
param [31640,31648]
param [31640,31648]
===
match
---
name: TEST_CONFIG_FILE [32354,32370]
name: TEST_CONFIG_FILE [32354,32370]
===
match
---
name: file_path [3313,3322]
name: file_path [3313,3322]
===
match
---
name: raw [26085,26088]
name: raw [26085,26088]
===
match
---
atom_expr [35497,35522]
atom_expr [35497,35522]
===
match
---
funcdef [35138,35523]
funcdef [35138,35523]
===
match
---
name: has_option [20438,20448]
name: has_option [20438,20448]
===
match
---
trailer [28056,28161]
trailer [28056,28161]
===
match
---
atom_expr [20969,20994]
atom_expr [20969,20994]
===
match
---
name: sys [2537,2540]
name: sys [2537,2540]
===
match
---
operator: , [19999,20000]
operator: , [19999,20000]
===
match
---
trailer [33159,33163]
trailer [33159,33163]
===
match
---
trailer [33702,33736]
trailer [33702,33736]
===
match
---
name: cfg [33128,33131]
name: cfg [33128,33131]
===
match
---
simple_stmt [19253,19266]
simple_stmt [19253,19266]
===
match
---
name: returncode [2626,2636]
name: returncode [2626,2636]
===
match
---
string: 'logging_config_class' [5659,5681]
string: 'logging_config_class' [5659,5681]
===
match
---
parameters [11894,11908]
parameters [11894,11908]
===
match
---
trailer [31263,31268]
trailer [31263,31268]
===
match
---
name: self [22541,22545]
name: self [22541,22545]
===
match
---
name: path [3263,3267]
name: path [3263,3267]
===
match
---
raise_stmt [10618,10857]
raise_stmt [10618,10857]
===
match
---
trailer [35505,35522]
trailer [35505,35522]
===
match
---
suite [10918,10972]
suite [10918,10972]
===
match
---
fstring_expr [17868,17877]
fstring_expr [17868,17877]
===
match
---
name: key [12014,12017]
name: key [12014,12017]
===
match
---
suite [3616,3960]
suite [3616,3960]
===
match
---
operator: , [1486,1487]
operator: , [1486,1487]
===
match
---
param [20161,20168]
param [20161,20168]
===
match
---
comp_op [14136,14142]
comp_op [14136,14142]
===
match
---
atom_expr [38413,38442]
atom_expr [38417,38446]
===
match
---
strings [11424,11683]
strings [11424,11683]
===
match
---
argument [38433,38441]
argument [38437,38445]
===
match
---
operator: * [37194,37195]
operator: * [37198,37199]
===
match
---
factor [32901,32903]
factor [32901,32903]
===
match
---
name: cfg [33134,33137]
name: cfg [33134,33137]
===
match
---
name: os [31354,31356]
name: os [31354,31356]
===
match
---
parameters [13359,13379]
parameters [13359,13379]
===
match
---
operator: = [28537,28538]
operator: = [28537,28538]
===
match
---
trailer [2997,2999]
trailer [2997,2999]
===
match
---
arglist [29127,29181]
arglist [29127,29181]
===
match
---
name: key [14786,14789]
name: key [14786,14789]
===
match
---
comparison [12358,12383]
comparison [12358,12383]
===
match
---
atom [17686,17705]
atom [17686,17705]
===
match
---
atom_expr [21775,21791]
atom_expr [21775,21791]
===
match
---
name: decode [32525,32531]
name: decode [32525,32531]
===
match
---
trailer [40283,40306]
trailer [40287,40310]
===
match
---
trailer [30360,30405]
trailer [30360,30405]
===
match
---
string: '< hidden >' [25690,25702]
string: '< hidden >' [25690,25702]
===
match
---
funcdef [39810,40332]
funcdef [39814,40336]
===
match
---
arglist [38426,38441]
arglist [38430,38445]
===
match
---
arglist [10439,10464]
arglist [10439,10464]
===
match
---
testlist_comp [25765,25778]
testlist_comp [25765,25778]
===
match
---
string: 'setting has been used, but please update your config.' [29486,29541]
string: 'setting has been used, but please update your config.' [29486,29541]
===
match
---
operator: = [30916,30917]
operator: = [30916,30917]
===
match
---
name: items [31899,31904]
name: items [31899,31904]
===
match
---
trailer [21007,21024]
trailer [21007,21024]
===
match
---
fstring_start: f" [9893,9895]
fstring_start: f" [9893,9895]
===
match
---
name: OrderedDict [25906,25917]
name: OrderedDict [25906,25917]
===
match
---
fstring_expr [2736,2756]
fstring_expr [2736,2756]
===
match
---
name: display_sensitive [25645,25662]
name: display_sensitive [25645,25662]
===
match
---
operator: = [11793,11794]
operator: = [11793,11794]
===
match
---
atom_expr [12466,12494]
atom_expr [12466,12494]
===
match
---
not_test [34286,34322]
not_test [34286,34322]
===
match
---
name: current_value [8875,8888]
name: current_value [8875,8888]
===
match
---
operator: , [5272,5273]
operator: , [5272,5273]
===
match
---
operator: , [14775,14776]
operator: , [14775,14776]
===
match
---
dotted_name [1436,1451]
dotted_name [1436,1451]
===
match
---
number: 2 [39168,39169]
number: 2 [39172,39173]
===
match
---
arglist [31588,31611]
arglist [31588,31611]
===
match
---
arglist [38138,38395]
arglist [38142,38399]
===
match
---
trailer [28356,28380]
trailer [28356,28380]
===
match
---
name: airflow [1436,1443]
name: airflow [1436,1443]
===
match
---
name: communicate [2595,2606]
name: communicate [2595,2606]
===
match
---
operator: , [20736,20737]
operator: , [20736,20737]
===
match
---
trailer [13681,13704]
trailer [13681,13704]
===
match
---
string: 'max_threads' [7274,7287]
string: 'max_threads' [7274,7287]
===
match
---
atom_expr [24655,24669]
atom_expr [24655,24669]
===
match
---
name: run_command [2306,2317]
name: run_command [2306,2317]
===
match
---
name: name [11708,11712]
name: name [11708,11712]
===
match
---
trailer [22780,22789]
trailer [22780,22789]
===
match
---
name: expanduser [2138,2148]
name: expanduser [2138,2148]
===
match
---
exprlist [8610,8630]
exprlist [8610,8630]
===
match
---
name: fallback [8814,8822]
name: fallback [8814,8822]
===
match
---
funcdef [13805,14730]
funcdef [13805,14730]
===
match
---
simple_stmt [34803,35108]
simple_stmt [34803,35108]
===
match
---
string: "sqlite" [9742,9750]
string: "sqlite" [9742,9750]
===
match
---
operator: , [14102,14103]
operator: , [14102,14103]
===
match
---
name: val [22042,22045]
name: val [22042,22045]
===
match
---
name: Optional [20708,20716]
name: Optional [20708,20716]
===
match
---
suite [39872,40332]
suite [39876,40336]
===
match
---
operator: = [19700,19701]
operator: = [19700,19701]
===
match
---
name: path [31154,31158]
name: path [31154,31158]
===
match
---
name: option [14507,14513]
name: option [14507,14513]
===
match
---
trailer [21591,21600]
trailer [21591,21600]
===
match
---
if_stmt [19088,19140]
if_stmt [19088,19140]
===
match
---
raise_stmt [9864,9961]
raise_stmt [9864,9961]
===
match
---
string: 'scheduler' [6697,6708]
string: 'scheduler' [6697,6708]
===
match
---
return_stmt [3366,3402]
return_stmt [3366,3402]
===
match
---
comparison [39139,39169]
comparison [39143,39173]
===
match
---
name: name [9118,9122]
name: name [9118,9122]
===
match
---
name: deprecated_section [15928,15946]
name: deprecated_section [15928,15946]
===
match
---
simple_stmt [40388,40404]
simple_stmt [40392,40408]
===
match
---
arglist [28078,28143]
arglist [28078,28143]
===
match
---
operator: = [2970,2971]
operator: = [2970,2971]
===
match
---
comparison [12704,12737]
comparison [12704,12737]
===
match
---
name: subprocess [891,901]
name: subprocess [891,901]
===
match
---
atom_expr [31256,31290]
atom_expr [31256,31290]
===
match
---
operator: { [7593,7594]
operator: { [7593,7594]
===
match
---
name: environ [30364,30371]
name: environ [30364,30371]
===
match
---
name: get [18378,18381]
name: get [18378,18381]
===
match
---
operator: + [26584,26585]
operator: + [26584,26585]
===
match
---
name: config_sources [24840,24854]
name: config_sources [24840,24854]
===
match
---
operator: , [1704,1705]
operator: , [1704,1705]
===
match
---
name: display_source [26341,26355]
name: display_source [26341,26355]
===
match
---
operator: , [6708,6709]
operator: , [6708,6709]
===
match
---
atom_expr [8975,9044]
atom_expr [8975,9044]
===
match
---
name: _replace_config_with_display_sources [27800,27836]
name: _replace_config_with_display_sources [27800,27836]
===
match
---
string: 'sql_alchemy_conn' [9771,9789]
string: 'sql_alchemy_conn' [9771,9789]
===
match
---
param [26085,26088]
param [26085,26088]
===
match
---
atom [5539,5564]
atom [5539,5564]
===
match
---
name: templates_dir [3273,3286]
name: templates_dir [3273,3286]
===
match
---
string: 'have left it at the default value you should remove the setting ' [33911,33977]
string: 'have left it at the default value you should remove the setting ' [33911,33977]
===
match
---
string: ". Possible values are " [10761,10785]
string: ". Possible values are " [10761,10785]
===
match
---
simple_stmt [40002,40054]
simple_stmt [40006,40058]
===
match
---
name: file [32802,32806]
name: file [32802,32806]
===
match
---
name: _read_default_config_file [34438,34463]
name: _read_default_config_file [34438,34463]
===
match
---
arglist [11262,11286]
arglist [11262,11286]
===
match
---
operator: , [31128,31129]
operator: , [31128,31129]
===
match
---
name: lower [22082,22087]
name: lower [22082,22087]
===
match
---
name: space_around_delimiters [22226,22249]
name: space_around_delimiters [22226,22249]
===
match
---
string: "'conf.load_test_config'" [35025,35050]
string: "'conf.load_test_config'" [35025,35050]
===
match
---
name: args [37161,37165]
name: args [37165,37169]
===
match
---
name: config_sources [26471,26485]
name: config_sources [26471,26485]
===
match
---
name: sqlite_version [10186,10200]
name: sqlite_version [10186,10200]
===
match
---
simple_stmt [28492,28517]
simple_stmt [28492,28517]
===
match
---
operator: , [13622,13623]
operator: , [13622,13623]
===
match
---
name: optionxform [8155,8166]
name: optionxform [8155,8166]
===
match
---
name: deprecated_key [15635,15649]
name: deprecated_key [15635,15649]
===
match
---
operator: , [13996,13997]
operator: , [13996,13997]
===
match
---
name: str [23030,23033]
name: str [23030,23033]
===
match
---
return_stmt [39220,39247]
return_stmt [39224,39251]
===
match
---
trailer [16803,16862]
trailer [16803,16862]
===
match
---
string: 'statsd_custom_client_path' [7142,7169]
string: 'statsd_custom_client_path' [7142,7169]
===
match
---
name: parameterized_config [29028,29048]
name: parameterized_config [29028,29048]
===
match
---
testlist_comp [6137,6171]
testlist_comp [6137,6171]
===
match
---
name: remove_option [38005,38018]
name: remove_option [38009,38022]
===
match
---
name: self [24987,24991]
name: self [24987,24991]
===
match
---
string: 'AIRFLOW__CORE__UNIT_TEST_MODE' [27061,27092]
string: 'AIRFLOW__CORE__UNIT_TEST_MODE' [27061,27092]
===
match
---
name: AIRFLOW_HOME [34119,34131]
name: AIRFLOW_HOME [34119,34131]
===
match
---
operator: = [1807,1808]
operator: = [1807,1808]
===
match
---
trailer [12824,12848]
trailer [12824,12848]
===
match
---
atom [20065,20096]
atom [20065,20096]
===
match
---
name: super [19537,19542]
name: super [19537,19542]
===
match
---
name: path [3773,3777]
name: path [3773,3777]
===
match
---
fstring_string: ] not found in config [15175,15196]
fstring_string: ] not found in config [15175,15196]
===
match
---
operator: , [16093,16094]
operator: , [16093,16094]
===
match
---
simple_stmt [39684,39721]
simple_stmt [39688,39725]
===
match
---
name: path [3187,3191]
name: path [3187,3191]
===
match
---
simple_stmt [10927,10972]
simple_stmt [10927,10972]
===
match
---
atom_expr [33804,34100]
atom_expr [33804,34100]
===
match
---
strings [2693,2809]
strings [2693,2809]
===
match
---
name: load_test_config [34642,34658]
name: load_test_config [34642,34658]
===
match
---
argument [14720,14728]
argument [14720,14728]
===
match
---
simple_stmt [32004,32036]
simple_stmt [32004,32036]
===
update-node
---
name: getint [37153,37159]
replace getint by getsection
