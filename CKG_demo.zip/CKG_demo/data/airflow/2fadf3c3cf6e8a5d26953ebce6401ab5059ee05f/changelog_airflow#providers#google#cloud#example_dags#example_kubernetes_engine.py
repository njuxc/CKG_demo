===
match
---
operator: = [1791,1792]
operator: = [1791,1792]
===
match
---
name: task_id [3048,3055]
name: task_id [3100,3107]
===
match
---
arglist [1302,1340]
arglist [1302,1340]
===
match
---
trailer [1297,1301]
trailer [1297,1301]
===
match
---
simple_stmt [2997,3173]
simple_stmt [3049,3225]
===
match
---
string: "pod_task_xcom" [2304,2319]
string: "pod_task_xcom" [2330,2345]
===
match
---
operator: = [3012,3013]
operator: = [3064,3065]
===
match
---
name: airflow [862,869]
name: airflow [862,869]
===
match
---
name: task_id [1995,2002]
name: task_id [1995,2002]
===
match
---
string: "name" [1413,1419]
string: "name" [1413,1419]
===
match
---
name: GCP_LOCATION [2373,2385]
name: GCP_LOCATION [2399,2411]
===
match
---
name: start_date [1625,1635]
name: start_date [1625,1635]
===
match
---
operator: , [2526,2527]
operator: , [2552,2553]
===
match
---
name: pod_task [1955,1963]
name: pod_task [1955,1963]
===
match
---
argument [2023,2048]
argument [2023,2048]
===
match
---
expr_stmt [1733,1903]
expr_stmt [1733,1903]
===
match
---
trailer [2286,2638]
trailer [2312,2690]
===
match
---
operator: , [2500,2501]
operator: , [2526,2527]
===
match
---
operator: = [2792,2793]
operator: = [2844,2845]
===
match
---
name: image [2486,2491]
name: image [2512,2517]
===
match
---
operator: = [1579,1580]
operator: = [1579,1580]
===
match
---
name: pod_task_xcom [3327,3340]
name: pod_task_xcom [3379,3392]
===
match
---
name: get [1229,1232]
name: get [1229,1232]
===
match
---
operator: , [3134,3135]
operator: , [3186,3187]
===
match
---
atom_expr [1636,1647]
atom_expr [1636,1647]
===
match
---
name: task_id [1784,1791]
name: task_id [1784,1791]
===
match
---
operator: , [2420,2421]
operator: , [2446,2447]
===
match
---
simple_stmt [2735,2901]
simple_stmt [2787,2953]
===
match
---
string: '@once' [1580,1587]
string: '@once' [1580,1587]
===
match
---
name: utils [1105,1110]
name: utils [1105,1110]
===
match
---
name: environ [1221,1228]
name: environ [1221,1228]
===
match
---
operator: , [2631,2632]
operator: , [2657,2658]
===
match
---
name: airflow [889,896]
name: airflow [889,896]
===
match
---
atom_expr [3014,3172]
atom_expr [3066,3224]
===
match
---
name: CLUSTER_NAME [1421,1433]
name: CLUSTER_NAME [1421,1433]
===
match
---
operator: , [2143,2144]
operator: , [2143,2144]
===
match
---
operator: , [3165,3166]
operator: , [3217,3218]
===
match
---
argument [3144,3165]
argument [3196,3217]
===
match
---
arglist [1995,2191]
arglist [1995,2217]
===
match
---
import_as_names [1009,1089]
import_as_names [1009,1089]
===
match
---
operator: = [1748,1749]
operator: = [1748,1749]
===
match
---
operator: , [1587,1588]
operator: , [1587,1588]
===
match
---
simple_stmt [846,856]
simple_stmt [846,856]
===
match
---
operator: , [1324,1325]
operator: , [1324,1325]
===
match
---
import_name [846,855]
import_name [846,855]
===
match
---
name: DAG [1530,1533]
name: DAG [1530,1533]
===
match
---
operator: = [1410,1411]
operator: = [1410,1411]
===
match
---
name: GKEStartPodOperator [1966,1985]
name: GKEStartPodOperator [1966,1985]
===
match
---
name: GCP_PROJECT_ID [1829,1843]
name: GCP_PROJECT_ID [1829,1843]
===
match
---
operator: >> [3305,3307]
operator: >> [3357,3359]
===
match
---
name: providers [945,954]
name: providers [945,954]
===
match
---
string: 'example' [1659,1668]
string: 'example' [1659,1668]
===
match
---
name: pod_task_xcom [2251,2264]
name: pod_task_xcom [2277,2290]
===
match
---
operator: = [2133,2134]
operator: = [2133,2134]
===
match
---
name: name [2175,2179]
name: name [2175,2179]
===
match
---
simple_stmt [857,884]
simple_stmt [857,884]
===
match
---
string: "cluster-name" [1326,1340]
string: "cluster-name" [1326,1340]
===
match
---
suite [1680,3365]
suite [1680,3417]
===
match
---
operator: = [1888,1889]
operator: = [1888,1889]
===
match
---
trailer [2770,2900]
trailer [2822,2952]
===
match
---
operator: = [1657,1658]
operator: = [1657,1658]
===
match
---
simple_stmt [1092,1133]
simple_stmt [1092,1133]
===
match
---
argument [2395,2420]
argument [2421,2446]
===
match
---
name: environ [1290,1297]
name: environ [1290,1297]
===
match
---
operator: = [3086,3087]
operator: = [3138,3139]
===
match
---
shift_expr [3273,3322]
shift_expr [3325,3374]
===
match
---
operator: , [1063,1064]
operator: , [1063,1064]
===
match
---
name: GKECreateClusterOperator [1009,1033]
name: GKECreateClusterOperator [1009,1033]
===
match
---
name: environ [1154,1161]
name: environ [1154,1161]
===
match
---
string: "default" [2134,2143]
string: "default" [2134,2143]
===
match
---
name: BashOperator [2758,2770]
name: BashOperator [2810,2822]
===
match
---
name: GKEStartPodOperator [2267,2286]
name: GKEStartPodOperator [2293,2312]
===
match
---
atom_expr [1218,1271]
atom_expr [1218,1271]
===
match
---
name: project_id [1818,1828]
name: project_id [1818,1828]
===
match
---
trailer [1985,2197]
trailer [1985,2223]
===
match
---
dotted_name [937,995]
dotted_name [937,995]
===
match
---
trailer [1533,1672]
trailer [1533,1672]
===
match
---
operator: >> [3239,3241]
operator: >> [3291,3293]
===
match
---
operator: , [1896,1897]
operator: , [1896,1897]
===
match
---
argument [2058,2079]
argument [2058,2079]
===
match
---
string: "pod_task" [2003,2013]
string: "pod_task" [2003,2013]
===
match
---
name: namespace [2457,2466]
name: namespace [2483,2492]
===
match
---
argument [3048,3072]
argument [3100,3124]
===
match
---
name: GCP_LOCATION [3153,3165]
name: GCP_LOCATION [3205,3217]
===
match
---
argument [2486,2500]
argument [2512,2526]
===
match
---
argument [1625,1647]
argument [1625,1647]
===
match
---
atom_expr [1750,1903]
atom_expr [1750,1903]
===
match
---
string: "-c" [2522,2526]
string: "-c" [2548,2552]
===
match
---
atom_expr [1151,1202]
atom_expr [1151,1202]
===
match
---
operator: , [1433,1434]
operator: , [1433,1434]
===
match
---
argument [2611,2631]
argument [2637,2657]
===
match
---
name: get [1162,1165]
name: get [1162,1165]
===
match
---
operator: = [2033,2034]
operator: = [2033,2034]
===
match
---
expr_stmt [1402,1459]
expr_stmt [1402,1459]
===
match
---
operator: = [2442,2443]
operator: = [2468,2469]
===
match
---
name: delete_cluster [3308,3322]
name: delete_cluster [3360,3374]
===
match
---
operator: , [2354,2355]
operator: , [2380,2381]
===
match
---
argument [1818,1843]
argument [1818,1843]
===
match
---
name: CLUSTER_NAME [2408,2420]
name: CLUSTER_NAME [2434,2446]
===
match
---
argument [2089,2114]
argument [2089,2114]
===
match
---
operator: , [2476,2477]
operator: , [2502,2503]
===
match
---
name: days_ago [1636,1644]
name: days_ago [1636,1644]
===
match
---
name: models [877,883]
name: models [877,883]
===
match
---
name: name [3082,3086]
name: name [3134,3138]
===
match
---
operator: , [2893,2894]
operator: , [2945,2946]
===
match
---
argument [2153,2165]
argument [2153,2165]
===
match
---
name: get [1298,1301]
name: get [1298,1301]
===
match
---
simple_stmt [1272,1342]
simple_stmt [1272,1342]
===
match
---
operator: = [2466,2467]
operator: = [2492,2493]
===
match
---
dotted_name [1097,1116]
dotted_name [1097,1116]
===
match
---
operator: } [1458,1459]
operator: } [1458,1459]
===
match
---
operator: = [1861,1862]
operator: = [1861,1862]
===
match
---
operator: = [1216,1217]
operator: = [1216,1217]
===
match
---
operator: >> [3341,3343]
operator: >> [3393,3395]
===
match
---
name: bash [907,911]
name: bash [907,911]
===
match
---
operator: = [2101,2102]
operator: = [2101,2102]
===
match
---
trailer [1153,1161]
trailer [1153,1161]
===
match
---
name: bash_command [2780,2792]
name: bash_command [2832,2844]
===
match
---
string: "echo \"{{ task_instance.xcom_pull('pod_task_xcom')[0] }}\"" [2793,2853]
string: "echo \"{{ task_instance.xcom_pull('pod_task_xcom')[0] }}\"" [2845,2905]
===
match
---
simple_stmt [3224,3269]
simple_stmt [3276,3321]
===
match
---
arglist [3048,3166]
arglist [3100,3218]
===
match
---
name: task_id [2863,2870]
name: task_id [2915,2922]
===
match
---
trailer [1289,1297]
trailer [1289,1297]
===
match
---
argument [2780,2853]
argument [2832,2905]
===
match
---
name: google [955,961]
name: google [955,961]
===
match
---
operator: , [1808,1809]
operator: , [1808,1809]
===
match
---
argument [1653,1669]
argument [1653,1669]
===
match
---
name: body [1884,1888]
name: body [1884,1888]
===
match
---
operator: , [2319,2320]
operator: , [2345,2346]
===
match
---
name: cmds [2510,2514]
name: cmds [2536,2540]
===
match
---
name: location [2058,2066]
name: location [2058,2066]
===
match
---
trailer [1161,1165]
trailer [1161,1165]
===
match
---
name: CLUSTER [1889,1896]
name: CLUSTER [1889,1896]
===
match
---
name: days_ago [1124,1132]
name: days_ago [1124,1132]
===
match
---
operator: = [2407,2408]
operator: = [2433,2434]
===
match
---
argument [2124,2143]
argument [2124,2143]
===
match
---
string: "default" [2467,2476]
string: "default" [2493,2502]
===
match
---
simple_stmt [3273,3323]
simple_stmt [3325,3375]
===
match
---
operator: = [2339,2340]
operator: = [2365,2366]
===
match
---
name: location [2364,2372]
name: location [2390,2398]
===
match
---
name: operators [897,906]
name: operators [897,906]
===
match
---
with_stmt [1518,3365]
with_stmt [1518,3417]
===
match
---
argument [2863,2893]
argument [2915,2945]
===
match
---
name: name [2611,2615]
name: name [2637,2641]
===
match
---
simple_stmt [2251,2639]
simple_stmt [2277,2691]
===
match
---
simple_stmt [1955,2198]
simple_stmt [1955,2224]
===
match
---
name: airflow [937,944]
name: airflow [937,944]
===
match
---
string: "test-pod" [2180,2190]
string: "test-pod" [2180,2190]
===
match
---
trailer [1774,1903]
trailer [1774,1903]
===
match
---
name: CLUSTER_NAME [3087,3099]
name: CLUSTER_NAME [3139,3151]
===
match
---
name: project_id [2023,2033]
name: project_id [2023,2033]
===
match
---
name: pod_task_xcom_result [3344,3364]
name: pod_task_xcom_result [3396,3416]
===
match
---
argument [2175,2190]
argument [2175,2190]
===
match
---
string: "GCP_GKE_LOCATION" [1233,1251]
string: "GCP_GKE_LOCATION" [1233,1251]
===
match
---
name: GCP_LOCATION [2067,2079]
name: GCP_LOCATION [2067,2079]
===
match
---
name: pod_task_xcom_result [2735,2755]
name: pod_task_xcom_result [2787,2807]
===
match
---
operator: = [2265,2266]
operator: = [2291,2292]
===
match
---
string: "delete_cluster" [3056,3072]
string: "delete_cluster" [3108,3124]
===
match
---
atom_expr [1523,1672]
atom_expr [1523,1672]
===
match
---
operator: , [3072,3073]
operator: , [3124,3125]
===
match
---
name: os [853,855]
name: os [853,855]
===
match
---
string: "GCP_PROJECT_ID" [1166,1182]
string: "GCP_PROJECT_ID" [1166,1182]
===
match
---
operator: , [1556,1557]
operator: , [1556,1557]
===
match
---
argument [2430,2447]
argument [2456,2473]
===
match
---
string: """ Example Airflow DAG for Google Kubernetes Engine. """ [787,844]
string: """ Example Airflow DAG for Google Kubernetes Engine. """ [787,844]
===
match
---
string: "example-project" [1184,1201]
string: "example-project" [1184,1201]
===
match
---
operator: = [3152,3153]
operator: = [3204,3205]
===
match
---
name: schedule_interval [1562,1579]
name: schedule_interval [1562,1579]
===
match
---
operator: = [1635,1636]
operator: = [1635,1636]
===
match
---
dotted_name [889,911]
dotted_name [889,911]
===
match
---
name: GKEStartPodOperator [1069,1088]
name: GKEStartPodOperator [1069,1088]
===
match
---
number: 1 [1645,1646]
number: 1 [1645,1646]
===
match
---
with_item [1523,1679]
with_item [1523,1679]
===
match
---
name: pod_task [3242,3250]
name: pod_task [3294,3302]
===
match
---
expr_stmt [2997,3172]
expr_stmt [3049,3224]
===
match
---
simple_stmt [3327,3365]
simple_stmt [3379,3417]
===
match
---
string: "test-pod-xcom" [2616,2631]
string: "test-pod-xcom" [2642,2657]
===
match
---
name: kubernetes_engine [978,995]
name: kubernetes_engine [978,995]
===
match
---
name: GKECreateClusterOperator [1750,1774]
name: GKECreateClusterOperator [1750,1774]
===
match
---
name: GCP_PROJECT_ID [2340,2354]
name: GCP_PROJECT_ID [2366,2380]
===
match
---
expr_stmt [1955,2197]
expr_stmt [1955,2223]
===
match
---
operator: , [1647,1648]
operator: , [1647,1648]
===
match
---
operator: >> [3251,3253]
operator: >> [3303,3305]
===
match
---
operator: , [2447,2448]
operator: , [2473,2474]
===
match
---
string: "sh" [2516,2520]
string: "sh" [2542,2546]
===
match
---
operator: = [1964,1965]
operator: = [1964,1965]
===
match
---
operator: = [2002,2003]
operator: = [2002,2003]
===
match
---
trailer [1644,1647]
trailer [1644,1647]
===
match
---
atom_expr [1966,2197]
atom_expr [1966,2223]
===
match
---
operator: , [2114,2115]
operator: , [2114,2115]
===
match
---
name: GKEDeleteClusterOperator [1039,1063]
name: GKEDeleteClusterOperator [1039,1063]
===
match
---
argument [2364,2385]
argument [2390,2411]
===
match
---
arglist [1539,1670]
arglist [1539,1670]
===
match
---
operator: = [2303,2304]
operator: = [2329,2330]
===
match
---
import_from [1092,1132]
import_from [1092,1132]
===
match
---
arglist [1784,1897]
arglist [1784,1897]
===
match
---
name: tags [1653,1657]
name: tags [1653,1657]
===
match
---
operator: , [2165,2166]
operator: , [2165,2166]
===
match
---
argument [3082,3099]
argument [3134,3151]
===
match
---
string: "GCP_GKE_CLUSTER_NAME" [1302,1324]
string: "GCP_GKE_CLUSTER_NAME" [1302,1324]
===
match
---
name: CLUSTER [1402,1409]
name: CLUSTER [1402,1409]
===
match
---
operator: = [2514,2515]
operator: = [2540,2541]
===
match
---
string: "alpine" [2492,2500]
string: "alpine" [2518,2526]
===
match
---
operator: , [2013,2014]
operator: , [2013,2014]
===
match
---
name: GCP_PROJECT_ID [2034,2048]
name: GCP_PROJECT_ID [2034,2048]
===
match
---
operator: , [2520,2521]
operator: , [2546,2547]
===
match
---
string: "create_cluster" [1792,1808]
string: "create_cluster" [1792,1808]
===
match
---
operator: , [3099,3100]
operator: , [3151,3152]
===
match
---
operator: = [2158,2159]
operator: = [2158,2159]
===
match
---
operator: , [2601,2602]
operator: , [2627,2628]
===
match
---
name: GKEDeleteClusterOperator [3014,3038]
name: GKEDeleteClusterOperator [3066,3090]
===
match
---
testlist_comp [2516,2600]
testlist_comp [2542,2626]
===
match
---
name: create_cluster [3224,3238]
name: create_cluster [3276,3290]
===
match
---
operator: = [2615,2616]
operator: = [2641,2642]
===
match
---
name: CLUSTER_NAME [2102,2114]
name: CLUSTER_NAME [2102,2114]
===
match
---
arglist [2296,2632]
arglist [2322,2684]
===
match
---
simple_stmt [884,932]
simple_stmt [884,932]
===
match
---
atom [1412,1459]
atom [1412,1459]
===
match
---
string: "europe-north1-a" [1253,1270]
string: "europe-north1-a" [1253,1270]
===
match
---
operator: , [1088,1089]
operator: , [1088,1089]
===
match
---
operator: = [2372,2373]
operator: = [2398,2399]
===
match
---
atom_expr [1287,1341]
atom_expr [1287,1341]
===
match
---
operator: , [2385,2386]
operator: , [2411,2412]
===
match
---
string: "pod_task_xcom_result" [2871,2893]
string: "pod_task_xcom_result" [2923,2945]
===
match
---
name: airflow [1097,1104]
name: airflow [1097,1104]
===
match
---
shift_expr [3224,3268]
shift_expr [3276,3320]
===
match
---
operator: , [1669,1670]
operator: , [1669,1670]
===
match
---
arglist [1166,1201]
arglist [1166,1201]
===
match
---
operator: = [2870,2871]
operator: = [2922,2923]
===
match
---
simple_stmt [1402,1460]
simple_stmt [1402,1460]
===
match
---
operator: = [3119,3120]
operator: = [3171,3172]
===
match
---
simple_stmt [1203,1272]
simple_stmt [1203,1272]
===
match
---
trailer [1529,1533]
trailer [1529,1533]
===
match
---
trailer [1301,1341]
trailer [1301,1341]
===
match
---
argument [2457,2476]
argument [2483,2502]
===
match
---
import_from [857,883]
import_from [857,883]
===
match
---
argument [1784,1808]
argument [1784,1808]
===
match
---
arglist [2780,2894]
arglist [2832,2946]
===
match
---
name: delete_cluster [2997,3011]
name: delete_cluster [3049,3063]
===
match
---
name: GCP_LOCATION [1862,1874]
name: GCP_LOCATION [1862,1874]
===
match
---
name: create_cluster [3273,3287]
name: create_cluster [3325,3339]
===
match
---
string: 'mkdir -p /airflow/xcom/;echo \'[1,2,3,4]\' > /airflow/xcom/return.json' [2528,2600]
string: 'mkdir -p /airflow/xcom/;echo \'[1,2,3,4]\' > /airflow/xcom/return.json' [2554,2626]
===
match
---
string: "perl" [2159,2165]
string: "perl" [2159,2165]
===
match
---
simple_stmt [787,845]
simple_stmt [787,845]
===
match
---
name: project_id [3109,3119]
name: project_id [3161,3171]
===
match
---
argument [1884,1896]
argument [1884,1896]
===
match
---
dictorsetmaker [1413,1458]
dictorsetmaker [1413,1458]
===
match
---
simple_stmt [932,1092]
simple_stmt [932,1092]
===
match
---
operator: = [2756,2757]
operator: = [2808,2809]
===
match
---
name: location [3144,3152]
name: location [3196,3204]
===
match
---
name: GCP_LOCATION [1203,1215]
name: GCP_LOCATION [1203,1215]
===
match
---
expr_stmt [2251,2638]
expr_stmt [2277,2690]
===
match
---
simple_stmt [1134,1203]
simple_stmt [1134,1203]
===
match
---
operator: = [1285,1286]
operator: = [1285,1286]
===
match
---
name: cluster_name [2089,2101]
name: cluster_name [2089,2101]
===
match
---
trailer [1228,1232]
trailer [1228,1232]
===
match
---
simple_stmt [1733,1904]
simple_stmt [1733,1904]
===
match
---
argument [1853,1874]
argument [1853,1874]
===
match
---
name: GCP_PROJECT_ID [1134,1148]
name: GCP_PROJECT_ID [1134,1148]
===
match
---
operator: = [1828,1829]
operator: = [1828,1829]
===
match
---
import_from [932,1091]
import_from [932,1091]
===
match
---
name: os [1151,1153]
name: os [1151,1153]
===
match
---
operator: { [1412,1413]
operator: { [1412,1413]
===
match
---
name: create_cluster [1733,1747]
name: create_cluster [1733,1747]
===
match
---
operator: , [2079,2080]
operator: , [2079,2080]
===
match
---
expr_stmt [1203,1271]
expr_stmt [1203,1271]
===
match
---
name: cluster_name [2395,2407]
name: cluster_name [2421,2433]
===
match
---
atom [1658,1669]
atom [1658,1669]
===
match
---
expr_stmt [1272,1341]
expr_stmt [1272,1341]
===
match
---
name: os [1287,1289]
name: os [1287,1289]
===
match
---
name: CLUSTER_NAME [1272,1284]
name: CLUSTER_NAME [1272,1284]
===
match
---
operator: >> [3288,3290]
operator: >> [3340,3342]
===
match
---
number: 1 [1457,1458]
number: 1 [1457,1458]
===
match
---
operator: = [2066,2067]
operator: = [2066,2067]
===
match
---
trailer [1232,1271]
trailer [1232,1271]
===
match
---
argument [2510,2601]
argument [2536,2627]
===
match
---
trailer [1165,1202]
trailer [1165,1202]
===
match
---
atom_expr [2267,2638]
atom_expr [2293,2690]
===
match
---
file_input [787,3365]
file_input [787,3417]
===
match
---
name: cloud [962,967]
name: cloud [962,967]
===
match
---
trailer [3038,3172]
trailer [3090,3224]
===
match
---
expr_stmt [1134,1202]
expr_stmt [1134,1202]
===
match
---
operator: , [2048,2049]
operator: , [2048,2049]
===
match
---
name: dates [1111,1116]
name: dates [1111,1116]
===
match
---
expr_stmt [2735,2900]
expr_stmt [2787,2952]
===
match
---
operator: = [2179,2180]
operator: = [2179,2180]
===
match
---
argument [2329,2354]
argument [2355,2380]
===
match
---
argument [2296,2319]
argument [2322,2345]
===
match
---
name: operators [968,977]
name: operators [968,977]
===
match
---
operator: , [1843,1844]
operator: , [1843,1844]
===
match
---
operator: , [1874,1875]
operator: , [1874,1875]
===
match
---
name: image [2153,2158]
name: image [2153,2158]
===
match
---
string: "initial_node_count" [1435,1455]
string: "initial_node_count" [1435,1455]
===
match
---
name: os [1218,1220]
name: os [1218,1220]
===
match
---
operator: , [2190,2191]
operator: , [2190,2191]
===
match
---
name: models [1523,1529]
name: models [1523,1529]
===
match
---
name: project_id [2329,2339]
name: project_id [2355,2365]
===
match
---
trailer [1220,1228]
trailer [1220,1228]
===
match
---
name: task_id [2296,2303]
name: task_id [2322,2329]
===
match
---
string: "example_gcp_gke" [1539,1556]
string: "example_gcp_gke" [1539,1556]
===
match
---
operator: = [1149,1150]
operator: = [1149,1150]
===
match
---
arglist [1233,1270]
arglist [1233,1270]
===
match
---
operator: , [1182,1183]
operator: , [1182,1183]
===
match
---
name: location [1853,1861]
name: location [1853,1861]
===
match
---
atom_expr [2758,2900]
atom_expr [2810,2952]
===
match
---
operator: , [1251,1252]
operator: , [1251,1252]
===
match
---
atom [2515,2601]
atom [2541,2627]
===
match
---
operator: , [1033,1034]
operator: , [1033,1034]
===
match
---
shift_expr [3327,3364]
shift_expr [3379,3416]
===
match
---
argument [1995,2013]
argument [1995,2013]
===
match
---
operator: = [3055,3056]
operator: = [3107,3108]
===
match
---
name: BashOperator [919,931]
name: BashOperator [919,931]
===
match
---
operator: = [2491,2492]
operator: = [2517,2518]
===
match
---
import_from [884,931]
import_from [884,931]
===
match
---
operator: , [2853,2854]
operator: , [2905,2906]
===
match
---
name: GCP_PROJECT_ID [3120,3134]
name: GCP_PROJECT_ID [3172,3186]
===
match
---
name: pod_task_xcom [3291,3304]
name: pod_task_xcom [3343,3356]
===
match
---
name: namespace [2124,2133]
name: namespace [2124,2133]
===
match
---
name: dag [1676,1679]
name: dag [1676,1679]
===
match
---
name: delete_cluster [3254,3268]
name: delete_cluster [3306,3320]
===
match
---
argument [3109,3134]
argument [3161,3186]
===
match
---
argument [1562,1587]
argument [1562,1587]
===
match
---
name: do_xcom_push [2430,2442]
name: do_xcom_push [2456,2468]
===
insert-tree
---
argument [2200,2216]
    name: in_cluster [2200,2210]
    operator: = [2210,2211]
to
arglist [1995,2191]
at 14
===
insert-node
---
operator: , [2216,2217]
to
arglist [1995,2191]
at 15
===
insert-tree
---
argument [2667,2683]
    name: in_cluster [2667,2677]
    operator: = [2677,2678]
to
arglist [2296,2632]
at 18
===
insert-node
---
operator: , [2683,2684]
to
arglist [2296,2632]
at 19
