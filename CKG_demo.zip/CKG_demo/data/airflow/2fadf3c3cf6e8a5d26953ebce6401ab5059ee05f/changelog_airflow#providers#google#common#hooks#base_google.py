===
match
---
operator: ** [17228,17230]
operator: ** [17228,17230]
===
match
---
expr_stmt [9905,9960]
expr_stmt [9905,9960]
===
match
---
operator: , [17335,17336]
operator: , [17335,17336]
===
match
---
parameters [11966,11972]
parameters [11966,11972]
===
match
---
atom_expr [17370,17386]
atom_expr [17370,17386]
===
match
---
parameters [3852,3858]
parameters [3852,3858]
===
match
---
expr_stmt [9500,9550]
expr_stmt [9500,9550]
===
match
---
fstring_end: " [12925,12926]
fstring_end: " [12925,12926]
===
match
---
name: PasswordField [6957,6970]
name: PasswordField [6957,6970]
===
match
---
name: client_info [12964,12975]
name: client_info [12964,12975]
===
match
---
simple_stmt [19949,20019]
simple_stmt [20429,20499]
===
match
---
funcdef [10189,10921]
funcdef [10189,10921]
===
match
---
simple_stmt [1640,1668]
simple_stmt [1640,1668]
===
match
---
name: _get_field [8708,8718]
name: _get_field [8708,8718]
===
match
---
funcdef [13496,13833]
funcdef [13496,13833]
===
match
---
name: scope_value [13724,13735]
name: scope_value [13724,13735]
===
match
---
atom_expr [10115,10144]
atom_expr [10115,10144]
===
match
---
name: retry_if_temporary_quota [14218,14242]
name: retry_if_temporary_quota [14218,14242]
===
match
---
name: airflow [1673,1680]
name: airflow [1673,1680]
===
match
---
name: auth [9807,9811]
name: auth [9807,9811]
===
match
---
atom [14840,15120]
atom [14840,15120]
===
match
---
name: multiplier [14892,14902]
name: multiplier [14892,14902]
===
match
---
return_stmt [17319,17353]
return_stmt [17319,17353]
===
match
---
name: tenacity [14143,14151]
name: tenacity [14143,14151]
===
match
---
trailer [17912,17930]
trailer [17912,17930]
===
match
---
return_stmt [12507,12515]
return_stmt [12507,12515]
===
match
---
string: "extra__google_cloud_platform__scope" [7077,7114]
string: "extra__google_cloud_platform__scope" [7077,7114]
===
match
---
name: HttpError [3353,3362]
name: HttpError [3353,3362]
===
match
---
operator: , [15089,15090]
operator: , [15089,15090]
===
match
---
operator: = [19438,19439]
operator: = [19438,19439]
===
match
---
arglist [14292,14310]
arglist [14292,14310]
===
match
---
name: logging [14297,14304]
name: logging [14297,14304]
===
match
---
operator: , [9281,9282]
operator: , [9281,9282]
===
match
---
name: str [7802,7805]
name: str [7802,7805]
===
match
---
trailer [18689,18695]
trailer [18689,18695]
===
match
---
name: Sequence [1050,1058]
name: Sequence [1050,1058]
===
match
---
name: str [8339,8342]
name: str [8339,8342]
===
match
---
suite [16296,16572]
suite [16296,16572]
===
match
---
fstring_expr [12818,12831]
fstring_expr [12818,12831]
===
match
---
name: BS3TextFieldWidget [6388,6406]
name: BS3TextFieldWidget [6388,6406]
===
match
---
simple_stmt [10869,10921]
simple_stmt [10869,10921]
===
match
---
name: self [9524,9528]
name: self [9524,9528]
===
match
---
name: loads [8963,8968]
name: loads [8963,8968]
===
match
---
name: Callable [13892,13900]
name: Callable [13892,13900]
===
match
---
name: Callable [14077,14085]
name: Callable [14077,14085]
===
match
---
name: decorator [15254,15263]
name: decorator [15254,15263]
===
match
---
name: _cached_project_id [8310,8328]
name: _cached_project_id [8310,8328]
===
match
---
name: retry_if_temporary_quota [3466,3490]
name: retry_if_temporary_quota [3466,3490]
===
match
---
decorator [16654,16668]
decorator [16654,16668]
===
match
---
name: key_path [18511,18519]
name: key_path [18511,18519]
===
match
---
atom_expr [10784,10860]
atom_expr [10784,10860]
===
match
---
operator: ** [13879,13881]
operator: ** [13879,13881]
===
match
---
operator: @ [12193,12194]
operator: @ [12193,12194]
===
match
---
funcdef [14549,15264]
funcdef [14549,15264]
===
match
---
operator: = [6154,6155]
operator: = [6154,6155]
===
match
---
name: lazy_gettext [7145,7157]
name: lazy_gettext [7145,7157]
===
match
---
name: project_id [9754,9764]
name: project_id [9754,9764]
===
match
---
operator: , [9916,9917]
operator: , [9916,9917]
===
match
---
simple_stmt [11745,11791]
simple_stmt [11745,11791]
===
match
---
atom_expr [11840,11851]
atom_expr [11840,11851]
===
match
---
name: google [1115,1121]
name: google [1115,1121]
===
match
---
operator: = [12121,12122]
operator: = [12121,12122]
===
match
---
operator: , [9325,9326]
operator: , [9325,9326]
===
match
---
string: "config" [21209,21217]
string: "config" [21209,21217]
===
match
---
string: 'wait' [14135,14141]
string: 'wait' [14135,14141]
===
match
---
parameters [17454,17460]
parameters [17454,17460]
===
match
---
tfpdef [7840,7866]
tfpdef [7840,7866]
===
match
---
atom_expr [8145,8195]
atom_expr [8145,8195]
===
match
---
simple_stmt [6104,6140]
simple_stmt [6104,6140]
===
match
---
operator: , [8642,8643]
operator: , [8642,8643]
===
match
---
operator: @ [10150,10151]
operator: @ [10150,10151]
===
match
---
name: project_id [20006,20016]
name: project_id [20486,20496]
===
match
---
trailer [8080,8100]
trailer [8080,8100]
===
match
---
operator: , [7676,7677]
operator: , [7676,7677]
===
match
---
suite [18617,18806]
suite [18617,18806]
===
match
---
name: version [13441,13448]
name: version [13441,13448]
===
match
---
expr_stmt [20846,20891]
expr_stmt [20846,20891]
===
match
---
name: str [12551,12554]
name: str [12551,12554]
===
match
---
if_stmt [16077,16256]
if_stmt [16077,16256]
===
match
---
name: Callable [14601,14609]
name: Callable [14601,14609]
===
match
---
arglist [2930,2977]
arglist [2930,2977]
===
match
---
string: 'Legacy P12 key file are not supported, use a JSON key file.' [18369,18430]
string: 'Legacy P12 key file are not supported, use a JSON key file.' [18369,18430]
===
match
---
name: environ [20435,20442]
name: environ [20256,20263]
===
match
---
if_stmt [20031,21724]
if_stmt [20332,21724]
===
match
---
name: Optional [7904,7912]
name: Optional [7904,7912]
===
match
---
simple_stmt [9688,9725]
simple_stmt [9688,9725]
===
match
---
string: "config" [21006,21014]
string: "config" [21006,21014]
===
match
---
if_stmt [18052,18910]
if_stmt [18052,18910]
===
match
---
trailer [13395,13449]
trailer [13395,13449]
===
match
---
string: 'before' [14991,14999]
string: 'before' [14991,14999]
===
match
---
name: self [11967,11971]
name: self [11967,11971]
===
match
---
string: 'oauth2' [10800,10808]
string: 'oauth2' [10800,10808]
===
match
---
simple_stmt [2813,2911]
simple_stmt [2813,2911]
===
match
---
name: kwargs [15879,15885]
name: kwargs [15879,15885]
===
match
---
name: http [11175,11179]
name: http [11175,11179]
===
match
---
if_stmt [2768,2911]
if_stmt [2768,2911]
===
match
---
name: service_account_email [10693,10714]
name: service_account_email [10693,10714]
===
match
---
param [7883,7947]
param [7883,7947]
===
match
---
simple_stmt [18094,18265]
simple_stmt [18094,18265]
===
match
---
param [2388,2408]
param [2388,2408]
===
match
---
operator: , [7830,7831]
operator: , [7830,7831]
===
match
---
suite [3520,3681]
suite [3520,3681]
===
match
---
operator: } [7746,7747]
operator: } [7746,7747]
===
match
---
raise_stmt [9040,9083]
raise_stmt [9040,9083]
===
match
---
operator: , [21468,21469]
operator: , [21468,21469]
===
match
---
name: self [10742,10746]
name: self [10742,10746]
===
match
---
simple_stmt [10518,10556]
simple_stmt [10518,10556]
===
match
---
funcdef [13856,14526]
funcdef [13856,14526]
===
match
---
operator: ** [17344,17346]
operator: ** [17344,17346]
===
match
---
name: kwargs [17230,17236]
name: kwargs [17230,17236]
===
match
---
name: default [12452,12459]
name: default [12452,12459]
===
match
---
trailer [8968,8982]
trailer [8968,8982]
===
match
---
import_from [1000,1087]
import_from [1000,1087]
===
match
---
operator: , [8822,8823]
operator: , [8822,8823]
===
match
---
operator: = [9429,9430]
operator: = [9429,9430]
===
match
---
dictorsetmaker [7633,7737]
dictorsetmaker [7633,7737]
===
match
---
operator: * [15207,15208]
operator: * [15207,15208]
===
match
---
operator: , [22487,22488]
operator: , [22487,22488]
===
match
---
atom_expr [15091,15104]
atom_expr [15091,15104]
===
match
---
operator: , [14376,14377]
operator: , [14376,14377]
===
match
---
tfpdef [11396,11402]
tfpdef [11396,11402]
===
match
---
simple_stmt [1204,1220]
simple_stmt [1204,1220]
===
match
---
name: Optional [8861,8869]
name: Optional [8861,8869]
===
match
---
name: StringField [6643,6654]
name: StringField [6643,6654]
===
match
---
operator: , [15362,15363]
operator: , [15362,15363]
===
match
---
atom_expr [7287,7486]
atom_expr [7287,7486]
===
match
---
atom_expr [9383,9399]
atom_expr [9383,9399]
===
match
---
atom_expr [12421,12462]
atom_expr [12421,12462]
===
match
---
return_stmt [13801,13832]
return_stmt [13801,13832]
===
match
---
string: 'Keyfile JSON' [7001,7015]
string: 'Keyfile JSON' [7001,7015]
===
match
---
simple_stmt [11175,11195]
simple_stmt [11175,11195]
===
match
---
suite [14618,15264]
suite [14618,15264]
===
match
---
dotted_name [1673,1691]
dotted_name [1673,1691]
===
match
---
name: ClientInfo [13385,13395]
name: ClientInfo [13385,13395]
===
match
---
string: "set" [21016,21021]
string: "set" [21016,21021]
===
match
---
name: BS3TextFieldWidget [6863,6881]
name: BS3TextFieldWidget [6863,6881]
===
match
---
funcdef [10926,11370]
funcdef [10926,11370]
===
match
---
name: impersonation_chain [7883,7902]
name: impersonation_chain [7883,7902]
===
match
---
name: _get_credentials_and_project_id [12128,12159]
name: _get_credentials_and_project_id [12128,12159]
===
match
---
comparison [12474,12493]
comparison [12474,12493]
===
match
---
trailer [17260,17299]
trailer [17260,17299]
===
match
---
argument [18592,18602]
argument [18592,18602]
===
match
---
name: conn_name_attr [6022,6036]
name: conn_name_attr [6022,6036]
===
match
---
argument [22489,22509]
argument [22489,22509]
===
match
---
name: self [8145,8149]
name: self [8145,8149]
===
match
---
name: self [11143,11147]
name: self [11143,11147]
===
match
---
name: open [20788,20792]
name: open [20788,20792]
===
match
---
operator: , [7444,7445]
operator: , [7444,7445]
===
match
---
name: _ [22573,22574]
name: _ [22573,22574]
===
match
---
name: TypeVar [3927,3934]
name: TypeVar [3927,3934]
===
match
---
trailer [12643,12656]
trailer [12643,12656]
===
match
---
suite [10673,10715]
suite [10673,10715]
===
match
---
simple_stmt [1668,1716]
simple_stmt [1668,1716]
===
match
---
operator: , [1843,1844]
operator: , [1843,1844]
===
match
---
name: str [7933,7936]
name: str [7933,7936]
===
match
---
name: patch_environ [19781,19794]
name: patch_environ [19781,19794]
===
match
---
name: exception [3412,3421]
name: exception [3412,3421]
===
match
---
arglist [13754,13767]
arglist [13754,13767]
===
match
---
name: loads [20867,20872]
name: loads [20867,20872]
===
match
---
import_from [1640,1667]
import_from [1640,1667]
===
match
---
suite [8749,8983]
suite [8749,8983]
===
match
---
atom [18463,18486]
atom [18463,18486]
===
match
---
param [11404,11423]
param [11404,11423]
===
match
---
funcdef [11952,12188]
funcdef [11952,12188]
===
match
---
simple_stmt [18980,19413]
simple_stmt [18980,19413]
===
match
---
operator: , [1920,1921]
operator: , [1920,1921]
===
match
---
simple_stmt [6322,6407]
simple_stmt [6322,6407]
===
match
---
name: json [8958,8962]
name: json [8958,8962]
===
match
---
decorated [16654,17387]
decorated [16654,17387]
===
match
---
name: num_retries [12211,12222]
name: num_retries [12211,12222]
===
match
---
atom_expr [17897,17930]
atom_expr [17897,17930]
===
match
---
trailer [6808,6897]
trailer [6808,6897]
===
match
---
parameters [10215,10221]
parameters [10215,10221]
===
match
---
operator: ** [16609,16611]
operator: ** [16609,16611]
===
match
---
atom_expr [8861,8885]
atom_expr [8861,8885]
===
match
---
name: str [8880,8883]
name: str [8880,8883]
===
match
---
expr_stmt [8131,8195]
expr_stmt [8131,8195]
===
match
---
name: lazy_gettext [6826,6838]
name: lazy_gettext [6826,6838]
===
match
---
name: exception [2782,2791]
name: exception [2782,2791]
===
match
---
name: wtforms [6534,6541]
name: wtforms [6534,6541]
===
match
---
atom_expr [15328,15345]
atom_expr [15328,15345]
===
match
---
operator: = [16141,16142]
operator: = [16141,16142]
===
match
---
argument [7018,7049]
argument [7018,7049]
===
match
---
suite [15893,16619]
suite [15893,16619]
===
match
---
name: default_kwargs [14404,14418]
name: default_kwargs [14404,14418]
===
match
---
atom_expr [6957,7063]
atom_expr [6957,7063]
===
match
---
operator: , [1074,1075]
operator: , [1074,1075]
===
match
---
trailer [3884,3920]
trailer [3884,3920]
===
match
---
name: get_credentials_and_project_id [1890,1920]
name: get_credentials_and_project_id [1890,1920]
===
match
---
atom [21430,21701]
atom [21430,21701]
===
match
---
name: google [8407,8413]
name: google [8407,8413]
===
match
---
with_item [19545,19570]
with_item [19545,19570]
===
match
---
name: functools [10151,10160]
name: functools [10151,10160]
===
match
---
trailer [3934,3955]
trailer [3934,3955]
===
match
---
operator: , [3351,3352]
operator: , [3351,3352]
===
match
---
name: log [14292,14295]
name: log [14292,14295]
===
match
---
trailer [19519,19530]
trailer [19519,19530]
===
match
---
expr_stmt [17886,17930]
expr_stmt [17886,17930]
===
match
---
operator: @ [21747,21748]
operator: @ [21747,21748]
===
match
---
simple_stmt [1305,1365]
simple_stmt [1305,1365]
===
match
---
file_input [788,22635]
file_input [788,22635]
===
match
---
trailer [7000,7016]
trailer [7000,7016]
===
match
---
operator: = [11141,11142]
operator: = [11141,11142]
===
match
---
simple_stmt [8076,8123]
simple_stmt [8076,8123]
===
match
---
number: 409 [3437,3440]
number: 409 [3437,3440]
===
match
---
name: check_output [21392,21404]
name: check_output [21392,21404]
===
match
---
operator: } [7735,7736]
operator: } [7735,7736]
===
match
---
classdef [3460,3681]
classdef [3460,3681]
===
match
---
expr_stmt [6104,6139]
expr_stmt [6104,6139]
===
match
---
trailer [12718,12940]
trailer [12718,12940]
===
match
---
name: AirflowException [9046,9062]
name: AirflowException [9046,9062]
===
match
---
number: 5 [12514,12515]
number: 5 [12514,12515]
===
match
---
trailer [3646,3655]
trailer [3646,3655]
===
match
---
trailer [3394,3401]
trailer [3394,3401]
===
match
---
atom_expr [8253,8288]
atom_expr [8253,8288]
===
match
---
name: super [3868,3873]
name: super [3868,3873]
===
match
---
import_from [1220,1304]
import_from [1220,1304]
===
match
---
name: self [17199,17203]
name: self [17199,17203]
===
match
---
atom_expr [16143,16163]
atom_expr [16143,16163]
===
match
---
simple_stmt [15931,16065]
simple_stmt [15931,16065]
===
match
---
name: delegates [9460,9469]
name: delegates [9460,9469]
===
match
---
trailer [20252,20498]
trailer [20073,20319]
===
match
---
expr_stmt [19421,19493]
expr_stmt [19421,19493]
===
match
---
import_from [1924,1977]
import_from [1924,1977]
===
match
---
string: "extra__google_cloud_platform__keyfile_dict" [6911,6955]
string: "extra__google_cloud_platform__keyfile_dict" [6911,6955]
===
match
---
return_stmt [16628,16648]
return_stmt [16628,16648]
===
match
---
argument [3940,3954]
argument [3940,3954]
===
match
---
name: google_auth_httplib2 [10950,10970]
name: google_auth_httplib2 [10950,10970]
===
match
---
trailer [14418,14425]
trailer [14418,14425]
===
match
---
atom_expr [20982,21069]
atom_expr [20982,21069]
===
match
---
name: _get_target_principal_and_delegates [1849,1884]
name: _get_target_principal_and_delegates [1849,1884]
===
match
---
string: "activate-service-account" [20366,20392]
string: "activate-service-account" [20187,20213]
===
match
---
trailer [15154,15164]
trailer [15154,15164]
===
match
---
decorated [12193,12941]
decorated [12193,12941]
===
match
---
expr_stmt [8677,8736]
expr_stmt [8677,8736]
===
match
---
simple_stmt [2415,2764]
simple_stmt [2415,2764]
===
match
---
trailer [10793,10799]
trailer [10793,10799]
===
match
---
name: TooManyRequests [2961,2976]
name: TooManyRequests [2961,2976]
===
match
---
name: gapic_v1 [1326,1334]
name: gapic_v1 [1326,1334]
===
match
---
name: credentials [10518,10529]
name: credentials [10518,10529]
===
match
---
string: 'login' [7669,7676]
string: 'login' [7669,7676]
===
match
---
return_stmt [15177,15237]
return_stmt [15177,15237]
===
match
---
atom_expr [20432,20455]
atom_expr [20253,20276]
===
match
---
string: "extra__google_cloud_platform__num_retries" [7242,7285]
string: "extra__google_cloud_platform__num_retries" [7242,7285]
===
match
---
name: RT [15890,15892]
name: RT [15890,15892]
===
match
---
name: NumberRange [7380,7391]
name: NumberRange [7380,7391]
===
match
---
simple_stmt [8938,8983]
simple_stmt [8938,8983]
===
match
---
trailer [16335,16571]
trailer [16335,16571]
===
match
---
name: credentials [11319,11330]
name: credentials [11319,11330]
===
match
---
name: __init__ [3647,3655]
name: __init__ [3647,3655]
===
match
---
atom_expr [10950,10985]
atom_expr [10950,10985]
===
match
---
arglist [3342,3362]
arglist [3342,3362]
===
match
---
expr_stmt [9597,9631]
expr_stmt [9597,9631]
===
match
---
atom_expr [15184,15237]
atom_expr [15184,15237]
===
match
---
simple_stmt [17470,17878]
simple_stmt [17470,17878]
===
match
---
return_stmt [10869,10920]
return_stmt [10869,10920]
===
match
---
simple_stmt [3445,3458]
simple_stmt [3445,3458]
===
match
---
name: client_library_version [13396,13418]
name: client_library_version [13396,13418]
===
match
---
testlist [8618,8667]
testlist [8618,8667]
===
match
---
if_stmt [3328,3441]
if_stmt [3328,3441]
===
match
---
name: file_handle [22467,22478]
name: file_handle [22467,22478]
===
match
---
name: _cached_credentials [8223,8242]
name: _cached_credentials [8223,8242]
===
match
---
name: self [13738,13742]
name: self [13738,13742]
===
match
---
atom_expr [11283,11342]
atom_expr [11283,11342]
===
match
---
trailer [2929,2978]
trailer [2929,2978]
===
match
---
name: long_f [11884,11890]
name: long_f [11884,11890]
===
match
---
simple_stmt [11203,11261]
simple_stmt [11203,11261]
===
match
---
string: 'before' [14262,14270]
string: 'before' [14262,14270]
===
match
---
name: AuthorizedHttp [11304,11318]
name: AuthorizedHttp [11304,11318]
===
match
---
name: functools [17157,17166]
name: functools [17157,17166]
===
match
---
simple_stmt [10724,10760]
simple_stmt [10724,10760]
===
match
---
atom_expr [20240,20498]
atom_expr [20061,20319]
===
match
---
trailer [10909,10911]
trailer [10909,10911]
===
match
---
simple_stmt [8842,8893]
simple_stmt [8842,8893]
===
match
---
string: """         Returns project id.          :return: id of the project         :rtype: str         """ [11999,12098]
string: """         Returns project id.          :return: id of the project         :rtype: str         """ [11999,12098]
===
match
---
arglist [11810,11824]
arglist [11810,11824]
===
match
---
atom_expr [7904,7939]
atom_expr [7904,7939]
===
match
---
name: credentials [9812,9823]
name: credentials [9812,9823]
===
match
---
name: TypeVar [1067,1074]
name: TypeVar [1067,1074]
===
match
---
operator: -> [10021,10023]
operator: -> [10021,10023]
===
match
---
trailer [12436,12462]
trailer [12436,12462]
===
match
---
operator: , [7350,7351]
operator: , [7350,7351]
===
match
---
name: auth [1122,1126]
name: auth [1122,1126]
===
match
---
name: gcloud_config_tmp [19668,19685]
name: gcloud_config_tmp [19668,19685]
===
match
---
operator: -> [14598,14600]
operator: -> [14598,14600]
===
match
---
decorator [21747,21761]
decorator [21747,21761]
===
match
---
atom_expr [14143,14191]
atom_expr [14143,14191]
===
match
---
string: 'Keyfile Path' [6839,6853]
string: 'Keyfile Path' [6839,6853]
===
match
---
operator: , [2791,2792]
operator: , [2791,2792]
===
match
---
trailer [8041,8053]
trailer [8041,8053]
===
match
---
operator: , [7873,7874]
operator: , [7873,7874]
===
match
---
trailer [19594,19608]
trailer [19594,19608]
===
match
---
string: "client_secret" [21262,21277]
string: "client_secret" [21262,21277]
===
match
---
string: 'email' [10912,10919]
string: 'email' [10912,10919]
===
match
---
simple_stmt [9845,9897]
simple_stmt [9845,9897]
===
match
---
trailer [12846,12859]
trailer [12846,12859]
===
match
---
string: 'RequestsPerMinutePerProject' [2219,2248]
string: 'RequestsPerMinutePerProject' [2219,2248]
===
match
---
expr_stmt [8842,8892]
expr_stmt [8842,8892]
===
match
---
import_as_names [6364,6406]
import_as_names [6364,6406]
===
match
---
if_stmt [10648,10715]
if_stmt [10648,10715]
===
match
---
operator: -> [16713,16715]
operator: -> [16713,16715]
===
match
---
name: delegates [9111,9120]
name: delegates [9111,9120]
===
match
---
trailer [18462,18487]
trailer [18462,18487]
===
match
---
atom_expr [14272,14311]
atom_expr [14272,14311]
===
match
---
operator: , [21014,21015]
operator: , [21014,21015]
===
match
---
string: 'schema' [7659,7667]
string: 'schema' [7659,7667]
===
match
---
atom_expr [14941,14973]
atom_expr [14941,14973]
===
match
---
name: default_kwargs [14479,14493]
name: default_kwargs [14479,14493]
===
match
---
decorator [18915,18931]
decorator [18915,18931]
===
match
---
expr_stmt [11203,11260]
expr_stmt [11203,11260]
===
match
---
trailer [7442,7444]
trailer [7442,7444]
===
match
---
suite [2804,2911]
suite [2804,2911]
===
match
---
name: staticmethod [6177,6189]
name: staticmethod [6177,6189]
===
match
---
atom_expr [6231,6245]
atom_expr [6231,6245]
===
match
---
param [13872,13878]
param [13872,13878]
===
match
---
operator: , [15875,15876]
operator: , [15875,15876]
===
match
---
operator: = [10820,10821]
operator: = [10820,10821]
===
match
---
name: tenacity [14272,14280]
name: tenacity [14272,14280]
===
match
---
name: default_kwargs [15216,15230]
name: default_kwargs [15216,15230]
===
match
---
suite [12236,12941]
suite [12236,12941]
===
match
---
name: self [17256,17260]
name: self [17256,17260]
===
match
---
name: base [1735,1739]
name: base [1735,1739]
===
match
---
name: enter_context [19595,19608]
name: enter_context [19595,19608]
===
match
---
expr_stmt [19668,19743]
expr_stmt [19668,19743]
===
match
---
name: flush [22627,22632]
name: flush [22627,22632]
===
match
---
trailer [16171,16182]
trailer [16171,16182]
===
match
---
name: self [8392,8396]
name: self [8392,8396]
===
match
---
operator: { [12818,12819]
operator: { [12818,12819]
===
match
---
atom_expr [10532,10555]
atom_expr [10532,10555]
===
match
---
operator: , [15190,15191]
operator: , [15190,15191]
===
match
---
fstring [20418,20457]
fstring [20239,20278]
===
match
---
parameters [14801,14809]
parameters [14801,14809]
===
match
---
dotted_name [15800,15815]
dotted_name [15800,15815]
===
match
---
expr_stmt [10518,10555]
expr_stmt [10518,10555]
===
match
---
trailer [20883,20888]
trailer [20883,20888]
===
match
---
operator: , [9479,9480]
operator: , [9479,9480]
===
match
---
operator: , [14973,14974]
operator: , [14973,14974]
===
match
---
parameters [14071,14086]
parameters [14071,14086]
===
match
---
name: hooks [1729,1734]
name: hooks [1729,1734]
===
match
---
name: os [896,898]
name: os [896,898]
===
match
---
dotted_name [1761,1818]
dotted_name [1761,1818]
===
match
---
trailer [15033,15039]
trailer [15033,15039]
===
match
---
trailer [6970,7063]
trailer [6970,7063]
===
match
---
name: http [11203,11207]
name: http [11203,11207]
===
match
---
trailer [9692,9711]
trailer [9692,9711]
===
match
---
name: field_value [12538,12549]
name: field_value [12538,12549]
===
match
---
name: T [14611,14612]
name: T [14611,14612]
===
match
---
fstring_end: " [12863,12864]
fstring_end: " [12863,12864]
===
match
---
operator: = [14179,14180]
operator: = [14179,14180]
===
match
---
name: functools [15800,15809]
name: functools [15800,15809]
===
match
---
name: kwargs [14590,14596]
name: kwargs [14590,14596]
===
match
---
trailer [1992,2002]
trailer [1992,2002]
===
match
---
name: status [3395,3401]
name: status [3395,3401]
===
match
---
name: http [11337,11341]
name: http [11337,11341]
===
match
---
atom_expr [6826,6854]
atom_expr [6826,6854]
===
match
---
return_stmt [3445,3457]
return_stmt [3445,3457]
===
match
---
operator: , [6854,6855]
operator: , [6854,6855]
===
match
---
operator: = [10782,10783]
operator: = [10782,10783]
===
match
---
simple_stmt [6255,6314]
simple_stmt [6255,6314]
===
match
---
return_stmt [15247,15263]
return_stmt [15247,15263]
===
match
---
name: BS3PasswordFieldWidget [6364,6386]
name: BS3PasswordFieldWidget [6364,6386]
===
match
---
fstring_expr [20431,20456]
fstring_expr [20252,20277]
===
match
---
name: CREDENTIALS [18734,18745]
name: CREDENTIALS [18734,18745]
===
match
---
atom_expr [9688,9711]
atom_expr [9688,9711]
===
match
---
operator: , [10814,10815]
operator: , [10814,10815]
===
match
---
trailer [22466,22510]
trailer [22466,22510]
===
match
---
name: Any [6241,6244]
name: Any [6241,6244]
===
match
---
atom_expr [19781,19837]
atom_expr [19781,19837]
===
match
---
trailer [8869,8885]
trailer [8869,8885]
===
match
---
atom_expr [8618,8642]
atom_expr [8618,8642]
===
match
---
string: """     API for Google services does not have a standardized way to report quota violation errors.     The function has been adapted by trial and error to the following services:      * Google Translate     * Google Vision     * Google Text-to-Speech     * Google Speech-to-Text     * Google Natural Language     * Google Video Intelligence     """ [2415,2763]
string: """     API for Google services does not have a standardized way to report quota violation errors.     The function has been adapted by trial and error to the following services:      * Google Translate     * Google Vision     * Google Text-to-Speech     * Google Speech-to-Text     * Google Natural Language     * Google Video Intelligence     """ [2415,2763]
===
match
---
simple_stmt [874,889]
simple_stmt [874,889]
===
match
---
parameters [7547,7549]
parameters [7547,7549]
===
match
---
atom_expr [3412,3433]
atom_expr [3412,3433]
===
match
---
trailer [20530,20548]
trailer [20530,20548]
===
match
---
parameters [7765,7953]
parameters [7765,7953]
===
match
---
name: error [2884,2889]
name: error [2884,2889]
===
match
---
simple_stmt [11351,11370]
simple_stmt [11351,11370]
===
match
---
name: T [15189,15190]
name: T [15189,15190]
===
match
---
atom_expr [18634,18663]
atom_expr [18634,18663]
===
match
---
simple_stmt [12696,12941]
simple_stmt [12696,12941]
===
match
---
atom_expr [17326,17353]
atom_expr [17326,17353]
===
match
---
annassign [8328,8350]
annassign [8328,8350]
===
match
---
name: field_value [12847,12858]
name: field_value [12847,12858]
===
match
---
trailer [9823,9835]
trailer [9823,9835]
===
match
---
string: 'num_retries' [12437,12450]
string: 'num_retries' [12437,12450]
===
match
---
name: self [11840,11844]
name: self [11840,11844]
===
match
---
simple_stmt [3525,3606]
simple_stmt [3525,3606]
===
match
---
name: overridden_project_id [9500,9521]
name: overridden_project_id [9500,9521]
===
match
---
param [17228,17236]
param [17228,17236]
===
match
---
suite [12494,12516]
suite [12494,12516]
===
match
---
operator: , [14904,14905]
operator: , [14904,14905]
===
match
---
name: creds_content [21588,21601]
name: creds_content [21588,21601]
===
match
---
operator: , [2248,2249]
operator: , [2248,2249]
===
match
---
atom_expr [8870,8884]
atom_expr [8870,8884]
===
match
---
tfpdef [14072,14085]
tfpdef [14072,14085]
===
match
---
argument [7392,7397]
argument [7392,7397]
===
match
---
import_name [889,898]
import_name [889,898]
===
match
---
subscriptlist [7919,7937]
subscriptlist [7919,7937]
===
match
---
atom_expr [8792,8829]
atom_expr [8792,8829]
===
match
---
trailer [22632,22634]
trailer [22632,22634]
===
match
---
operator: @ [6176,6177]
operator: @ [6176,6177]
===
match
---
string: 'Scopes (comma separated)' [7158,7184]
string: 'Scopes (comma separated)' [7158,7184]
===
match
---
name: google [1225,1231]
name: google [1225,1231]
===
match
---
simple_stmt [13801,13833]
simple_stmt [13801,13833]
===
match
---
name: INVALID_REASONS [2307,2322]
name: INVALID_REASONS [2307,2322]
===
match
---
dotted_name [10151,10170]
dotted_name [10151,10170]
===
match
---
name: get_application_default_credentials_path [19451,19491]
name: get_application_default_credentials_path [19451,19491]
===
match
---
operator: -> [9797,9799]
operator: -> [9797,9799]
===
match
---
trailer [16126,16140]
trailer [16126,16140]
===
match
---
name: kwargs [16611,16617]
name: kwargs [16611,16617]
===
match
---
name: exceptions [1241,1251]
name: exceptions [1241,1251]
===
match
---
atom_expr [3639,3680]
atom_expr [3639,3680]
===
match
---
operator: , [2959,2960]
operator: , [2959,2960]
===
match
---
comparison [22546,22559]
comparison [22546,22559]
===
match
---
operator: = [11208,11209]
operator: = [11208,11209]
===
match
---
atom_expr [8561,8585]
atom_expr [8561,8585]
===
match
---
operator: , [20308,20309]
operator: , [20129,20130]
===
match
---
name: _get_credentials [10120,10136]
name: _get_credentials [10120,10136]
===
match
---
name: self [11872,11876]
name: self [11872,11876]
===
match
---
suite [3166,3458]
suite [3166,3458]
===
match
---
atom_expr [8401,8458]
atom_expr [8401,8458]
===
match
---
simple_stmt [12633,12657]
simple_stmt [12633,12657]
===
match
---
atom_expr [19609,19654]
atom_expr [19609,19654]
===
match
---
name: client_info [13465,13476]
name: client_info [13465,13476]
===
match
---
trailer [8784,8789]
trailer [8784,8789]
===
match
---
operator: } [12859,12860]
operator: } [12859,12860]
===
match
---
name: credentials_path [19421,19437]
name: credentials_path [19421,19437]
===
match
---
name: NumberRange [6560,6571]
name: NumberRange [6560,6571]
===
match
---
arglist [7145,7214]
arglist [7145,7214]
===
match
---
name: HttpError [1548,1557]
name: HttpError [1548,1557]
===
match
---
name: default [7462,7469]
name: default [7462,7469]
===
match
---
parameters [8391,8397]
parameters [8391,8397]
===
match
---
subscriptlist [15337,15344]
subscriptlist [15337,15344]
===
match
---
name: ValueError [12672,12682]
name: ValueError [12672,12682]
===
match
---
argument [9413,9446]
argument [9413,9446]
===
match
---
name: target_principal [9413,9429]
name: target_principal [9413,9429]
===
match
---
name: errors [1534,1540]
name: errors [1534,1540]
===
match
---
operator: , [2354,2355]
operator: , [2354,2355]
===
match
---
name: int [21839,21842]
name: int [21839,21842]
===
match
---
name: fun [14802,14805]
name: fun [14802,14805]
===
match
---
operator: = [7193,7194]
operator: = [7193,7194]
===
match
---
expr_stmt [3923,3955]
expr_stmt [3923,3955]
===
match
---
string: """Retries if there was an exception for exceeding the temporary quote limit.""" [3754,3834]
string: """Retries if there was an exception for exceeding the temporary quote limit.""" [3754,3834]
===
match
---
name: _get_field [8797,8807]
name: _get_field [8797,8807]
===
match
---
trailer [3499,3518]
trailer [3499,3518]
===
match
---
import_as_names [1259,1304]
import_as_names [1259,1304]
===
match
---
name: project_id [16245,16255]
name: project_id [16245,16255]
===
match
---
simple_stmt [17363,17387]
simple_stmt [17363,17387]
===
match
---
atom_expr [9641,9665]
atom_expr [9641,9665]
===
match
---
operator: == [12580,12582]
operator: == [12580,12582]
===
match
---
atom_expr [8776,8789]
atom_expr [8776,8789]
===
match
---
import_name [1108,1138]
import_name [1108,1138]
===
match
---
arglist [14357,14375]
arglist [14357,14375]
===
match
---
trailer [21172,21301]
trailer [21172,21301]
===
match
---
name: kwargs [16120,16126]
name: kwargs [16120,16126]
===
match
---
name: func [17326,17330]
name: func [17326,17330]
===
match
---
operator: = [9920,9921]
operator: = [9920,9921]
===
match
---
name: http_authorized [10724,10739]
name: http_authorized [10724,10739]
===
match
---
name: logging [15091,15098]
name: logging [15091,15098]
===
match
---
testlist_comp [2331,2355]
testlist_comp [2331,2355]
===
match
---
argument [10816,10836]
argument [10816,10836]
===
match
---
expr_stmt [3956,3974]
expr_stmt [3956,3974]
===
match
---
parameters [15847,15886]
parameters [15847,15886]
===
match
---
name: creds_content [21644,21657]
name: creds_content [21644,21657]
===
match
---
name: CREDENTIALS [20034,20045]
name: CREDENTIALS [19855,19866]
===
match
---
name: scope_value [13820,13831]
name: scope_value [13820,13831]
===
match
---
name: project_id [12110,12120]
name: project_id [12110,12120]
===
match
---
argument [14477,14493]
argument [14477,14493]
===
match
---
fstring_start: f" [12736,12738]
fstring_start: f" [12736,12738]
===
match
---
param [13507,13511]
param [13507,13511]
===
match
---
trailer [20518,20523]
trailer [20518,20523]
===
match
---
trailer [19712,19743]
trailer [19712,19743]
===
match
---
simple_stmt [10564,10640]
simple_stmt [10564,10640]
===
match
---
operator: { [20431,20432]
operator: { [20252,20253]
===
match
---
operator: -> [15887,15889]
operator: -> [15887,15889]
===
match
---
string: "Resource has been exhausted (e.g. check quota)." [2254,2303]
string: "Resource has been exhausted (e.g. check quota)." [2254,2303]
===
match
---
name: error [3050,3055]
name: error [3050,3055]
===
match
---
atom_expr [13385,13449]
atom_expr [13385,13449]
===
match
---
operator: -> [8398,8400]
operator: -> [8398,8400]
===
match
---
atom_expr [3331,3363]
atom_expr [3331,3363]
===
match
---
atom_expr [19584,19655]
atom_expr [19584,19655]
===
match
---
trailer [20866,20872]
trailer [20866,20872]
===
match
---
name: widget [7018,7024]
name: widget [7018,7024]
===
match
---
name: done [22519,22523]
name: done [22519,22523]
===
match
---
simple_stmt [11129,11167]
simple_stmt [11129,11167]
===
match
---
string: """Returns connection widgets to add to connection form""" [6255,6313]
string: """Returns connection widgets to add to connection form""" [6255,6313]
===
match
---
name: cast [1083,1087]
name: cast [1083,1087]
===
match
---
operator: = [17980,17981]
operator: = [17980,17981]
===
match
---
return_stmt [2988,3076]
return_stmt [2988,3076]
===
match
---
trailer [20434,20442]
trailer [20255,20263]
===
match
---
name: gcp_conn_id [8003,8014]
name: gcp_conn_id [8003,8014]
===
match
---
expr_stmt [7998,8028]
expr_stmt [7998,8028]
===
match
---
trailer [3655,3680]
trailer [3655,3680]
===
match
---
trailer [11318,11342]
trailer [11318,11342]
===
match
---
simple_stmt [9905,9961]
simple_stmt [9905,9961]
===
match
---
atom [6588,7497]
atom [6588,7497]
===
match
---
atom_expr [18564,18603]
atom_expr [18564,18603]
===
match
---
suite [12683,12941]
suite [12683,12941]
===
match
---
suite [11432,11933]
suite [11432,11933]
===
match
---
testlist_comp [21199,21278]
testlist_comp [21199,21278]
===
match
---
suite [18971,21742]
suite [18971,21742]
===
match
---
trailer [12577,12579]
trailer [12577,12579]
===
match
---
trailer [10889,10899]
trailer [10889,10899]
===
match
---
dotted_name [6327,6356]
dotted_name [6327,6356]
===
match
---
name: self [10015,10019]
name: self [10015,10019]
===
match
---
parameters [10940,10946]
parameters [10940,10946]
===
match
---
argument [9339,9357]
argument [9339,9357]
===
match
---
operator: , [14181,14182]
operator: , [14181,14182]
===
match
---
name: done [22546,22550]
name: done [22546,22550]
===
match
---
or_test [16143,16182]
or_test [16143,16182]
===
match
---
string: 'project_id' [16282,16294]
string: 'project_id' [16282,16294]
===
match
---
name: GoogleBaseHook [17205,17219]
name: GoogleBaseHook [17205,17219]
===
match
---
operator: , [8442,8443]
operator: , [8442,8443]
===
match
---
simple_stmt [1139,1176]
simple_stmt [1139,1176]
===
match
---
simple_stmt [1220,1305]
simple_stmt [1220,1305]
===
match
---
string: 'DefaultRequestsPerMinutePerUser' [2180,2213]
string: 'DefaultRequestsPerMinutePerUser' [2180,2213]
===
match
---
operator: = [12459,12460]
operator: = [12459,12460]
===
match
---
name: self [9346,9350]
name: self [9346,9350]
===
match
---
name: hasattr [11802,11809]
name: hasattr [11802,11809]
===
match
---
atom_expr [16591,16618]
atom_expr [16591,16618]
===
match
---
suite [9027,9084]
suite [9027,9084]
===
match
---
atom_expr [12702,12940]
atom_expr [12702,12940]
===
match
---
suite [18546,18806]
suite [18546,18806]
===
match
---
decorator [6176,6190]
decorator [6176,6190]
===
match
---
atom_expr [15937,16064]
atom_expr [15937,16064]
===
match
---
return_stmt [12170,12187]
return_stmt [12170,12187]
===
match
---
arglist [2782,2802]
arglist [2782,2802]
===
match
---
trailer [8622,8642]
trailer [8622,8642]
===
match
---
with_stmt [19540,21742]
with_stmt [19540,21742]
===
match
---
parameters [2387,2409]
parameters [2387,2409]
===
match
---
operator: -> [7954,7956]
operator: -> [7954,7956]
===
match
---
simple_stmt [8037,8068]
simple_stmt [8037,8068]
===
match
---
simple_stmt [16120,16183]
simple_stmt [16120,16183]
===
match
---
decorator [13838,13852]
decorator [13838,13852]
===
match
---
operator: , [7228,7229]
operator: , [7228,7229]
===
match
---
simple_stmt [1000,1088]
simple_stmt [1000,1088]
===
match
---
trailer [10899,10901]
trailer [10899,10901]
===
match
---
decorated [11938,12188]
decorated [11938,12188]
===
match
---
operator: , [21825,21826]
operator: , [21825,21826]
===
match
---
name: str [8785,8788]
name: str [8785,8788]
===
match
---
name: tenacity [14866,14874]
name: tenacity [14866,14874]
===
match
---
testlist_star_expr [22573,22580]
testlist_star_expr [22573,22580]
===
match
---
name: auth [1412,1416]
name: auth [1412,1416]
===
match
---
name: project_id [16172,16182]
name: project_id [16172,16182]
===
match
---
name: self [17982,17986]
name: self [17982,17986]
===
match
---
name: get_connection [8150,8164]
name: get_connection [8150,8164]
===
match
---
simple_stmt [13458,13477]
simple_stmt [13458,13477]
===
match
---
name: retry_if_operation_in_progress [14941,14971]
name: retry_if_operation_in_progress [14941,14971]
===
match
---
string: "client_id" [21602,21613]
string: "client_id" [21602,21613]
===
match
---
name: bool [3161,3165]
name: bool [3161,3165]
===
match
---
atom [20995,21068]
atom [20995,21068]
===
match
---
trailer [21404,21723]
trailer [21404,21723]
===
match
---
string: """Returns the Credentials object for Google API and the associated project_id""" [8468,8549]
string: """Returns the Credentials object for Google API and the associated project_id""" [8468,8549]
===
match
---
import_from [915,963]
import_from [915,963]
===
match
---
operator: @ [18915,18916]
operator: @ [18915,18916]
===
match
---
name: field_value [12560,12571]
name: field_value [12560,12571]
===
match
---
name: StringField [6797,6808]
name: StringField [6797,6808]
===
match
---
simple_stmt [862,874]
simple_stmt [862,874]
===
match
---
atom_expr [10876,10920]
atom_expr [10876,10920]
===
match
---
name: provide_authorized_gcloud [18939,18964]
name: provide_authorized_gcloud [18939,18964]
===
match
---
operator: , [17226,17227]
operator: , [17226,17227]
===
match
---
operator: = [2130,2131]
operator: = [2130,2131]
===
match
---
operator: -> [13513,13515]
operator: -> [13513,13515]
===
match
---
operator: , [20392,20393]
operator: , [20213,20214]
===
match
---
name: errors [2903,2909]
name: errors [2903,2909]
===
match
---
simple_stmt [12245,12399]
simple_stmt [12245,12399]
===
match
---
name: str [8453,8456]
name: str [8453,8456]
===
match
---
operator: , [6386,6387]
operator: , [6386,6387]
===
match
---
name: args [14471,14475]
name: args [14471,14475]
===
match
---
operator: , [21207,21208]
operator: , [21207,21208]
===
match
---
testlist_star_expr [9093,9120]
testlist_star_expr [9093,9120]
===
match
---
simple_stmt [11441,11737]
simple_stmt [11441,11737]
===
match
---
if_stmt [12471,12516]
if_stmt [12471,12516]
===
match
---
string: "gcloud" [20996,21004]
string: "gcloud" [20996,21004]
===
match
---
atom_expr [11210,11260]
atom_expr [11210,11260]
===
match
---
simple_stmt [9194,9491]
simple_stmt [9194,9491]
===
match
---
trailer [3426,3433]
trailer [3426,3433]
===
match
---
name: contextmanager [17393,17407]
name: contextmanager [17393,17407]
===
match
---
operator: = [8344,8345]
operator: = [8344,8345]
===
match
---
simple_stmt [14627,14779]
simple_stmt [14627,14779]
===
match
---
name: conf_file [18607,18616]
name: conf_file [18607,18616]
===
match
---
string: 'google_cloud_platform' [6116,6139]
string: 'google_cloud_platform' [6116,6139]
===
match
---
atom_expr [16319,16571]
atom_expr [16319,16571]
===
match
---
suite [13530,13833]
suite [13530,13833]
===
match
---
string: """         Download media resources.         Note that  the Python file object is compatible with io.Base and can be used with this class also.          :param file_handle: io.Base or file object. The stream in which to write the downloaded             bytes.         :type file_handle: io.Base or file object         :param request: googleapiclient.http.HttpRequest, the media request to perform in chunks.         :type request: Dict         :param chunk_size: int, File will be downloaded in chunks of this many bytes.         :type chunk_size: int         """ [21861,22425]
string: """         Download media resources.         Note that  the Python file object is compatible with io.Base and can be used with this class also.          :param file_handle: io.Base or file object. The stream in which to write the downloaded             bytes.         :type file_handle: io.Base or file object         :param request: googleapiclient.http.HttpRequest, the media request to perform in chunks.         :type request: Dict         :param chunk_size: int, File will be downloaded in chunks of this many bytes.         :type chunk_size: int         """ [21861,22425]
===
match
---
name: auth [1377,1381]
name: auth [1377,1381]
===
match
---
name: write [18644,18649]
name: write [18644,18649]
===
match
---
name: self [10115,10119]
name: self [10115,10119]
===
match
---
atom_expr [8330,8343]
atom_expr [8330,8343]
===
match
---
simple_stmt [7567,7604]
simple_stmt [7567,7604]
===
match
---
operator: = [19686,19687]
operator: = [19686,19687]
===
match
---
atom_expr [10588,10639]
atom_expr [10588,10639]
===
match
---
trailer [8406,8458]
trailer [8406,8458]
===
match
---
name: T [3923,3924]
name: T [3923,3924]
===
match
---
suite [11852,11892]
suite [11852,11892]
===
match
---
string: """Returns custom field behaviour""" [7567,7603]
string: """Returns custom field behaviour""" [7567,7603]
===
match
---
param [11396,11403]
param [11396,11403]
===
match
---
atom_expr [20049,20059]
atom_expr [19870,19880]
===
match
---
operator: = [6075,6076]
operator: = [6075,6076]
===
match
---
string: 'RT' [3969,3973]
string: 'RT' [3969,3973]
===
match
---
name: __init__ [7757,7765]
name: __init__ [7757,7765]
===
match
---
name: file_handle [22615,22626]
name: file_handle [22615,22626]
===
match
---
param [3624,3628]
param [3624,3628]
===
match
---
simple_stmt [1924,1978]
simple_stmt [1924,1978]
===
match
---
trailer [7978,7987]
trailer [7978,7987]
===
match
---
operator: , [15024,15025]
operator: , [15024,15025]
===
match
---
operator: = [7469,7470]
operator: = [7469,7470]
===
match
---
atom_expr [2893,2909]
atom_expr [2893,2909]
===
match
---
name: self [8561,8565]
name: self [8561,8565]
===
match
---
name: Forbidden [2793,2802]
name: Forbidden [2793,2802]
===
match
---
comparison [11830,11851]
comparison [11830,11851]
===
match
---
import_as_names [1019,1087]
import_as_names [1019,1087]
===
match
---
simple_stmt [10108,10145]
simple_stmt [10108,10145]
===
match
---
name: wait_exponential [14152,14168]
name: wait_exponential [14152,14168]
===
match
---
funcdef [8356,9765]
funcdef [8356,9765]
===
match
---
trailer [9926,9958]
trailer [9926,9958]
===
match
---
suite [21852,22635]
suite [21852,22635]
===
match
---
expr_stmt [9093,9184]
expr_stmt [9093,9184]
===
match
---
operator: , [21674,21675]
operator: , [21674,21675]
===
match
---
fstring_end: " [12781,12782]
fstring_end: " [12781,12782]
===
match
---
comparison [20034,20059]
comparison [19855,19880]
===
match
---
name: _get_field [9529,9539]
name: _get_field [9529,9539]
===
match
---
suite [20549,21724]
suite [20549,21724]
===
match
---
operator: , [1038,1039]
operator: , [1038,1039]
===
match
---
name: args [14582,14586]
name: args [14582,14586]
===
match
---
arglist [10800,10859]
arglist [10800,10859]
===
match
---
trailer [11876,11883]
trailer [11876,11883]
===
match
---
name: json [8998,9002]
name: json [8998,9002]
===
match
---
suite [3749,3921]
suite [3749,3921]
===
match
---
operator: , [14191,14192]
operator: , [14191,14192]
===
match
---
operator: = [3945,3946]
operator: = [3945,3946]
===
match
---
name: self [9688,9692]
name: self [9688,9692]
===
match
---
operator: = [9666,9667]
operator: = [9666,9667]
===
match
---
fstring_string: ).  [12860,12863]
fstring_string: ).  [12860,12863]
===
match
---
operator: ** [15877,15879]
operator: ** [15877,15879]
===
match
---
atom_expr [20862,20891]
atom_expr [20862,20891]
===
match
---
suite [14810,15238]
suite [14810,15238]
===
match
---
name: Optional [11976,11984]
name: Optional [11976,11984]
===
match
---
name: downloader [22583,22593]
name: downloader [22583,22593]
===
match
---
expr_stmt [6057,6099]
expr_stmt [6057,6099]
===
match
---
name: _authorize [10930,10940]
name: _authorize [10930,10940]
===
match
---
trailer [22626,22632]
trailer [22626,22632]
===
match
---
name: Optional [8444,8452]
name: Optional [8444,8452]
===
match
---
atom_expr [8407,8442]
atom_expr [8407,8442]
===
match
---
simple_stmt [9093,9185]
simple_stmt [9093,9185]
===
match
---
name: exit_stack [19688,19698]
name: exit_stack [19688,19698]
===
match
---
name: func [17173,17177]
name: func [17173,17177]
===
match
---
return_stmt [7612,7747]
return_stmt [7612,7747]
===
match
---
name: TypeVar [3961,3968]
name: TypeVar [3961,3968]
===
match
---
trailer [13524,13529]
trailer [13524,13529]
===
match
---
atom_expr [18303,18328]
atom_expr [18303,18328]
===
match
---
name: BaseHook [1747,1755]
name: BaseHook [1747,1755]
===
match
---
funcdef [11375,11933]
funcdef [11375,11933]
===
match
---
operator: = [9218,9219]
operator: = [9218,9219]
===
match
---
name: tenacity [15067,15075]
name: tenacity [15067,15075]
===
match
---
atom_expr [12123,12161]
atom_expr [12123,12161]
===
match
---
operator: { [12841,12842]
operator: { [12841,12842]
===
match
---
trailer [8309,8328]
trailer [8309,8328]
===
match
---
name: Credentials [8277,8288]
name: Credentials [8277,8288]
===
match
---
atom_expr [3927,3955]
atom_expr [3927,3955]
===
match
---
suite [12620,12657]
suite [12620,12657]
===
match
---
raise_stmt [15931,16064]
raise_stmt [15931,16064]
===
match
---
operator: , [15105,15106]
operator: , [15105,15106]
===
match
---
operator: -> [10947,10949]
operator: -> [10947,10949]
===
match
---
argument [11332,11341]
argument [11332,11341]
===
match
---
with_stmt [20783,21724]
with_stmt [20783,21724]
===
match
---
argument [14169,14181]
argument [14169,14181]
===
match
---
comparison [16080,16102]
comparison [16080,16102]
===
match
---
parameters [17198,17237]
parameters [17198,17237]
===
match
---
name: log [15021,15024]
name: log [15021,15024]
===
match
---
string: 'host' [7651,7657]
string: 'host' [7651,7657]
===
match
---
name: provide_gcp_credential_file_as_context [17416,17454]
name: provide_gcp_credential_file_as_context [17416,17454]
===
match
---
name: api_core [1232,1240]
name: api_core [1232,1240]
===
match
---
trailer [11883,11891]
trailer [11883,11891]
===
match
---
operator: = [11752,11753]
operator: = [11752,11753]
===
match
---
operator: , [21558,21559]
operator: , [21558,21559]
===
match
---
name: __init__ [7979,7987]
name: __init__ [7979,7987]
===
match
---
string: 'airflow_v' [13419,13430]
string: 'airflow_v' [13419,13430]
===
match
---
simple_stmt [22434,22511]
simple_stmt [22434,22511]
===
match
---
argument [9264,9281]
argument [9264,9281]
===
match
---
name: staticmethod [13839,13851]
name: staticmethod [13839,13851]
===
match
---
annassign [8859,8892]
annassign [8859,8892]
===
match
---
parameters [15321,15346]
parameters [15321,15346]
===
match
---
name: self [3624,3628]
name: self [3624,3628]
===
match
---
trailer [14494,14499]
trailer [14494,14499]
===
match
---
argument [15207,15212]
argument [15207,15212]
===
match
---
name: JSONDecodeError [9011,9026]
name: JSONDecodeError [9011,9026]
===
match
---
simple_stmt [1176,1204]
simple_stmt [1176,1204]
===
match
---
name: GoogleBaseHook [15854,15868]
name: GoogleBaseHook [15854,15868]
===
match
---
atom_expr [22447,22510]
atom_expr [22447,22510]
===
match
---
atom_expr [21392,21723]
atom_expr [21392,21723]
===
match
---
name: staticmethod [14532,14544]
name: staticmethod [14532,14544]
===
match
---
name: validators [7368,7378]
name: validators [7368,7378]
===
match
---
name: google [8253,8259]
name: google [8253,8259]
===
match
---
operator: , [8729,8730]
operator: , [8729,8730]
===
match
---
atom [21198,21279]
atom [21198,21279]
===
match
---
operator: , [22478,22479]
operator: , [22478,22479]
===
match
---
name: _cached_credentials [9646,9665]
name: _cached_credentials [9646,9665]
===
match
---
parameters [18964,18970]
parameters [18964,18970]
===
match
---
trailer [17986,17997]
trailer [17986,17997]
===
match
---
funcdef [9770,9988]
funcdef [9770,9988]
===
match
---
dotted_name [1405,1433]
dotted_name [1405,1433]
===
match
---
trailer [11224,11260]
trailer [11224,11260]
===
match
---
operator: @ [13838,13839]
operator: @ [13838,13839]
===
match
---
name: self [13507,13511]
name: self [13507,13511]
===
match
---
expr_stmt [11129,11166]
expr_stmt [11129,11166]
===
match
---
simple_stmt [899,915]
simple_stmt [899,915]
===
match
---
name: credentials [9905,9916]
name: credentials [9905,9916]
===
match
---
param [17199,17220]
param [17199,17220]
===
match
---
import_from [964,999]
import_from [964,999]
===
match
---
arglist [7317,7472]
arglist [7317,7472]
===
match
---
operator: = [22498,22499]
operator: = [22498,22499]
===
match
---
name: CREDENTIALS [1463,1474]
name: CREDENTIALS [1463,1474]
===
match
---
dictorsetmaker [18464,18485]
dictorsetmaker [18464,18485]
===
match
---
operator: , [1032,1033]
operator: , [1032,1033]
===
match
---
operator: , [1884,1885]
operator: , [1884,1885]
===
match
---
name: validators [6542,6552]
name: validators [6542,6552]
===
match
---
operator: * [17221,17222]
operator: * [17221,17222]
===
match
---
name: _get_credentials [11148,11164]
name: _get_credentials [11148,11164]
===
match
---
simple_stmt [9734,9765]
simple_stmt [9734,9765]
===
match
---
simple_stmt [1108,1139]
simple_stmt [1108,1139]
===
match
---
simple_stmt [15377,15790]
simple_stmt [15377,15790]
===
match
---
simple_stmt [1400,1475]
simple_stmt [1400,1475]
===
match
---
name: INVALID_KEYS [3033,3045]
name: INVALID_KEYS [3033,3045]
===
match
---
param [21812,21826]
param [21812,21826]
===
match
---
atom_expr [13516,13529]
atom_expr [13516,13529]
===
match
---
name: exit_stack [19756,19766]
name: exit_stack [19756,19766]
===
match
---
suite [18764,18806]
suite [18764,18806]
===
match
---
import_name [845,861]
import_name [845,861]
===
match
---
trailer [15200,15206]
trailer [15200,15206]
===
match
---
name: field_value [12819,12830]
name: field_value [12819,12830]
===
match
---
name: key [2999,3002]
name: key [2999,3002]
===
match
---
simple_stmt [12407,12463]
simple_stmt [12407,12463]
===
match
---
name: f [11396,11397]
name: f [11396,11397]
===
match
---
string: 'google_cloud_default' [7808,7830]
string: 'google_cloud_default' [7808,7830]
===
match
---
decorator [12193,12203]
decorator [12193,12203]
===
match
---
name: _cached_credentials [8623,8642]
name: _cached_credentials [8623,8642]
===
match
---
name: self [19609,19613]
name: self [19609,19613]
===
match
---
atom_expr [18449,18487]
atom_expr [18449,18487]
===
match
---
name: resp [3422,3426]
name: resp [3422,3426]
===
match
---
operator: = [13383,13384]
operator: = [13383,13384]
===
match
---
dictorsetmaker [14135,14377]
dictorsetmaker [14135,14377]
===
match
---
parameters [12975,12981]
parameters [12975,12981]
===
match
---
suite [14087,14500]
suite [14087,14500]
===
match
---
strings [18134,18250]
strings [18134,18250]
===
match
---
suite [3630,3681]
suite [3630,3681]
===
match
---
operator: , [14475,14476]
operator: , [14475,14476]
===
match
---
atom_expr [18680,18697]
atom_expr [18680,18697]
===
match
---
name: str [11985,11988]
name: str [11985,11988]
===
match
---
expr_stmt [13724,13768]
expr_stmt [13724,13768]
===
match
---
parameters [9790,9796]
parameters [9790,9796]
===
match
---
name: retry_if_operation_in_progress [3689,3719]
name: retry_if_operation_in_progress [3689,3719]
===
match
---
name: self [17455,17459]
name: self [17455,17459]
===
match
---
simple_stmt [18899,18910]
simple_stmt [18899,18910]
===
match
---
import_from [6415,6451]
import_from [6415,6451]
===
match
---
trailer [7932,7937]
trailer [7932,7937]
===
match
---
testlist_star_expr [9194,9217]
testlist_star_expr [9194,9217]
===
match
---
argument [12452,12461]
argument [12452,12461]
===
match
---
operator: , [21504,21505]
operator: , [21504,21505]
===
match
---
decorated [13482,13833]
decorated [13482,13833]
===
match
---
name: str [13525,13528]
name: str [13525,13528]
===
match
---
atom_expr [8037,8053]
atom_expr [8037,8053]
===
match
---
expr_stmt [12407,12462]
expr_stmt [12407,12462]
===
match
---
argument [17337,17342]
argument [17337,17342]
===
match
---
simple_stmt [9597,9632]
simple_stmt [9597,9632]
===
match
---
trailer [15358,15367]
trailer [15358,15367]
===
match
---
operator: , [2213,2214]
operator: , [2213,2214]
===
match
---
or_test [3380,3440]
or_test [3380,3440]
===
match
---
name: is_soft_quota_exception [3656,3679]
name: is_soft_quota_exception [3656,3679]
===
match
---
atom_expr [7913,7938]
atom_expr [7913,7938]
===
match
---
simple_stmt [3868,3921]
simple_stmt [3868,3921]
===
match
---
name: scopes [9339,9345]
name: scopes [9339,9345]
===
match
---
name: AirflowException [15937,15953]
name: AirflowException [15937,15953]
===
match
---
name: credentials [9741,9752]
name: credentials [9741,9752]
===
match
---
atom_expr [12527,12555]
atom_expr [12527,12555]
===
match
---
trailer [7918,7938]
trailer [7918,7938]
===
match
---
expr_stmt [1979,2012]
expr_stmt [1979,2012]
===
match
---
import_name [1176,1203]
import_name [1176,1203]
===
match
---
atom_expr [18791,18805]
atom_expr [18791,18805]
===
match
---
name: ClientInfo [12985,12995]
name: ClientInfo [12985,12995]
===
match
---
name: func [15816,15820]
name: func [15816,15820]
===
match
---
import_from [1756,1923]
import_from [1756,1923]
===
match
---
trailer [15188,15237]
trailer [15188,15237]
===
match
---
name: CLOUD_SDK_CONFIG_DIR [1441,1461]
name: CLOUD_SDK_CONFIG_DIR [1441,1461]
===
match
---
atom_expr [21644,21674]
atom_expr [21644,21674]
===
match
---
operator: , [1058,1059]
operator: , [1058,1059]
===
match
---
name: __init__ [3844,3852]
name: __init__ [3844,3852]
===
match
---
suite [17461,18910]
suite [17461,18910]
===
match
---
string: "You must use keyword arguments in this methods rather than positional" [15975,16046]
string: "You must use keyword arguments in this methods rather than positional" [15975,16046]
===
match
---
string: "relabeling" [7720,7732]
string: "relabeling" [7720,7732]
===
match
---
name: next_chunk [22594,22604]
name: next_chunk [22594,22604]
===
match
---
fstring_end: " [20456,20457]
fstring_end: " [20277,20278]
===
match
---
annassign [8774,8829]
annassign [8774,8829]
===
match
---
trailer [14971,14973]
trailer [14971,14973]
===
match
---
name: any [2820,2823]
name: any [2820,2823]
===
match
---
simple_stmt [21160,21302]
simple_stmt [21160,21302]
===
match
---
string: 'google_cloud_default' [6077,6099]
string: 'google_cloud_default' [6077,6099]
===
match
---
arglist [11319,11341]
arglist [11319,11341]
===
match
---
operator: , [7185,7186]
operator: , [7185,7186]
===
match
---
trailer [11192,11194]
trailer [11192,11194]
===
match
---
expr_stmt [9688,9724]
expr_stmt [9688,9724]
===
match
---
funcdef [3840,3921]
funcdef [3840,3921]
===
match
---
name: credentials [1127,1138]
name: credentials [1127,1138]
===
match
---
atom_expr [2771,2803]
atom_expr [2771,2803]
===
match
---
operator: , [7016,7017]
operator: , [7016,7017]
===
match
---
suite [18287,18520]
suite [18287,18520]
===
match
---
name: flush [18690,18695]
name: flush [18690,18695]
===
match
---
name: gcloud_config_tmp [19818,19835]
name: gcloud_config_tmp [19818,19835]
===
match
---
name: StringField [6509,6520]
name: StringField [6509,6520]
===
match
---
argument [17344,17352]
argument [17344,17352]
===
match
---
name: self [8165,8169]
name: self [8165,8169]
===
match
---
operator: , [16600,16601]
operator: , [16600,16601]
===
match
---
operator: , [7696,7697]
operator: , [7696,7697]
===
match
---
import_from [1558,1638]
import_from [1558,1638]
===
match
---
name: self [8131,8135]
name: self [8131,8135]
===
match
---
name: google [1146,1152]
name: google [1146,1152]
===
match
---
subscriptlist [15359,15366]
subscriptlist [15359,15366]
===
match
---
simple_stmt [9040,9084]
simple_stmt [9040,9084]
===
match
---
simple_stmt [1979,2013]
simple_stmt [1979,2013]
===
match
---
trailer [20872,20891]
trailer [20872,20891]
===
match
---
trailer [14469,14494]
trailer [14469,14494]
===
match
---
name: self [16240,16244]
name: self [16240,16244]
===
match
---
name: read [20884,20888]
name: read [20884,20888]
===
match
---
try_stmt [8745,9084]
try_stmt [8745,9084]
===
match
---
name: DEBUG [14305,14310]
name: DEBUG [14305,14310]
===
match
---
argument [10171,10183]
argument [10171,10183]
===
match
---
atom_expr [11976,11989]
atom_expr [11976,11989]
===
match
---
expr_stmt [9194,9490]
expr_stmt [9194,9490]
===
match
---
name: self [7998,8002]
name: self [7998,8002]
===
match
---
atom_expr [21588,21614]
atom_expr [21588,21614]
===
match
---
operator: , [1461,1462]
operator: , [1461,1462]
===
match
---
name: NamedTemporaryFile [18573,18591]
name: NamedTemporaryFile [18573,18591]
===
match
---
yield_expr [18785,18805]
yield_expr [18785,18805]
===
match
---
name: self [11390,11394]
name: self [11390,11394]
===
match
---
operator: , [2303,2304]
operator: , [2303,2304]
===
match
---
name: utils [1792,1797]
name: utils [1792,1797]
===
match
---
operator: -> [10222,10224]
operator: -> [10222,10224]
===
match
---
operator: = [19513,19514]
operator: = [19513,19514]
===
match
---
param [12976,12980]
param [12976,12980]
===
match
---
suite [18081,18265]
suite [18081,18265]
===
match
---
trailer [18320,18328]
trailer [18320,18328]
===
match
---
tfpdef [11404,11416]
tfpdef [11404,11416]
===
match
---
name: lru_cache [10161,10170]
name: lru_cache [10161,10170]
===
match
---
name: google_auth_httplib2 [1183,1203]
name: google_auth_httplib2 [1183,1203]
===
match
---
number: 5 [12460,12461]
number: 5 [12460,12461]
===
match
---
name: check_output [20240,20252]
name: check_output [20061,20073]
===
match
---
trailer [20051,20059]
trailer [19872,19880]
===
match
---
atom_expr [16167,16182]
atom_expr [16167,16182]
===
match
---
atom [2132,2306]
atom [2132,2306]
===
match
---
name: self [8305,8309]
name: self [8305,8309]
===
match
---
raise_stmt [16313,16571]
raise_stmt [16313,16571]
===
match
---
arglist [10596,10638]
arglist [10596,10638]
===
match
---
testlist_comp [20996,21067]
testlist_comp [20996,21067]
===
match
---
operator: { [7734,7735]
operator: { [7734,7735]
===
match
---
atom_expr [9922,9960]
atom_expr [9922,9960]
===
match
---
atom_expr [3380,3401]
atom_expr [3380,3401]
===
match
---
trailer [8452,8457]
trailer [8452,8457]
===
match
---
name: project_id [19520,19530]
name: project_id [19520,19530]
===
match
---
simple_stmt [1365,1400]
simple_stmt [1365,1400]
===
match
---
simple_stmt [6529,6572]
simple_stmt [6529,6572]
===
match
---
operator: , [7922,7923]
operator: , [7922,7923]
===
match
---
name: RT [15342,15344]
name: RT [15342,15344]
===
match
---
string: 'project' [9540,9549]
string: 'project' [9540,9549]
===
match
---
operator: = [13736,13737]
operator: = [13736,13737]
===
match
---
atom_expr [14362,14375]
atom_expr [14362,14375]
===
match
---
operator: @ [13482,13483]
operator: @ [13482,13483]
===
match
---
string: """Returns a valid access token from Google API Credentials""" [10037,10099]
string: """Returns a valid access token from Google API Credentials""" [10037,10099]
===
match
---
comparison [12560,12585]
comparison [12560,12585]
===
match
---
arglist [17998,18018]
arglist [17998,18018]
===
match
---
number: 5 [7470,7471]
number: 5 [7470,7471]
===
match
---
trailer [7976,7978]
trailer [7976,7978]
===
match
---
atom_expr [7998,8014]
atom_expr [7998,8014]
===
match
---
trailer [12537,12555]
trailer [12537,12555]
===
match
---
operator: = [10530,10531]
operator: = [10530,10531]
===
match
---
string: 'scope' [13754,13761]
string: 'scope' [13754,13761]
===
match
---
name: fallback_to_default_project_id [15291,15321]
name: fallback_to_default_project_id [15291,15321]
===
match
---
trailer [7047,7049]
trailer [7047,7049]
===
match
---
name: TooManyRequests [1289,1304]
name: TooManyRequests [1289,1304]
===
match
---
operator: , [2939,2940]
operator: , [2939,2940]
===
match
---
with_item [20788,20824]
with_item [20788,20824]
===
match
---
operator: } [20455,20456]
operator: } [20276,20277]
===
match
---
simple_stmt [14509,14526]
simple_stmt [14509,14526]
===
match
---
atom_expr [2820,2910]
atom_expr [2820,2910]
===
match
---
name: http [11225,11229]
name: http [11225,11229]
===
match
---
simple_stmt [8468,8550]
simple_stmt [8468,8550]
===
match
---
name: args [16603,16607]
name: args [16603,16607]
===
match
---
operator: = [7806,7807]
operator: = [7806,7807]
===
match
---
atom_expr [9524,9550]
atom_expr [9524,9550]
===
match
---
dictorsetmaker [6602,7487]
dictorsetmaker [6602,7487]
===
match
---
trailer [20994,21069]
trailer [20994,21069]
===
match
---
operator: @ [17156,17157]
operator: @ [17156,17157]
===
match
---
parameters [12222,12228]
parameters [12222,12228]
===
match
---
operator: , [7063,7064]
operator: , [7063,7064]
===
match
---
atom_expr [22615,22634]
atom_expr [22615,22634]
===
match
---
atom [14117,14391]
atom [14117,14391]
===
match
---
simple_stmt [10768,10861]
simple_stmt [10768,10861]
===
match
---
string: 'after' [15058,15065]
string: 'after' [15058,15065]
===
match
---
name: keyfile_dict [18068,18080]
name: keyfile_dict [18068,18080]
===
match
---
name: credentials [9668,9679]
name: credentials [9668,9679]
===
match
---
name: key [3026,3029]
name: key [3026,3029]
===
match
---
simple_stmt [2307,2358]
simple_stmt [2307,2358]
===
match
---
name: AirflowException [1699,1715]
name: AirflowException [1699,1715]
===
match
---
simple_stmt [16727,17147]
simple_stmt [16727,17147]
===
match
---
trailer [8807,8829]
trailer [8807,8829]
===
match
---
name: widget [6700,6706]
name: widget [6700,6706]
===
match
---
trailer [2002,2012]
trailer [2002,2012]
===
match
---
arglist [15086,15104]
arglist [15086,15104]
===
match
---
try_stmt [12616,12941]
try_stmt [12616,12941]
===
match
---
name: Dict [6231,6235]
name: Dict [6231,6235]
===
match
---
trailer [9158,9184]
trailer [9158,9184]
===
match
---
string: 'keyfile_dict' [17998,18012]
string: 'keyfile_dict' [17998,18012]
===
match
---
name: check_output [20982,20994]
name: check_output [20982,20994]
===
match
---
name: self [18965,18969]
name: self [18965,18969]
===
match
---
name: key_path [18055,18063]
name: key_path [18055,18063]
===
match
---
simple_stmt [7998,8029]
simple_stmt [7998,8029]
===
match
---
trailer [14280,14291]
trailer [14280,14291]
===
match
---
trailer [8222,8242]
trailer [8222,8242]
===
match
---
operator: , [17376,17377]
operator: , [17376,17377]
===
match
---
trailer [17901,17912]
trailer [17901,17912]
===
match
---
operator: , [10632,10633]
operator: , [10632,10633]
===
match
---
name: staticmethod [16655,16667]
name: staticmethod [16655,16667]
===
match
---
name: _cached_credentials [8566,8585]
name: _cached_credentials [8566,8585]
===
match
---
name: self [8792,8796]
name: self [8792,8796]
===
match
---
decorated [21747,22635]
decorated [21747,22635]
===
match
---
name: Forbidden [1259,1268]
name: Forbidden [1259,1268]
===
match
---
fstring [12881,12926]
fstring [12881,12926]
===
match
---
trailer [20888,20890]
trailer [20888,20890]
===
match
---
simple_stmt [9969,9988]
simple_stmt [9969,9988]
===
match
---
simple_stmt [22519,22532]
simple_stmt [22519,22532]
===
match
---
suite [3364,3441]
suite [3364,3441]
===
match
---
if_stmt [8905,8983]
if_stmt [8905,8983]
===
match
---
suite [11990,12188]
suite [11990,12188]
===
match
---
name: decorator [14516,14525]
name: decorator [14516,14525]
===
match
---
dictorsetmaker [14858,15106]
dictorsetmaker [14858,15106]
===
match
---
name: os [20432,20434]
name: os [20253,20255]
===
match
---
operator: = [6114,6115]
operator: = [6114,6115]
===
match
---
name: INVALID_KEYS [2117,2129]
name: INVALID_KEYS [2117,2129]
===
match
---
simple_stmt [8762,8830]
simple_stmt [8762,8830]
===
match
---
simple_stmt [17319,17354]
simple_stmt [17319,17354]
===
match
---
param [10015,10019]
param [10015,10019]
===
match
---
param [10216,10220]
param [10216,10220]
===
match
---
argument [16602,16607]
argument [16602,16607]
===
match
---
tfpdef [7789,7805]
tfpdef [7789,7805]
===
match
---
atom [7379,7399]
atom [7379,7399]
===
match
---
name: auth [8260,8264]
name: auth [8260,8264]
===
match
---
string: "in Google Cloud connection definition. Both are not set!" [16495,16553]
string: "in Google Cloud connection definition. Both are not set!" [16495,16553]
===
match
---
string: "set" [19983,19988]
string: "set" [20463,20468]
===
match
---
operator: = [8701,8702]
operator: = [8701,8702]
===
match
---
atom_expr [7025,7049]
atom_expr [7025,7049]
===
match
---
string: 'extra' [7698,7705]
string: 'extra' [7698,7705]
===
match
---
simple_stmt [13724,13792]
simple_stmt [13724,13792]
===
match
---
return_stmt [3373,3440]
return_stmt [3373,3440]
===
match
---
name: Optional [8776,8784]
name: Optional [8776,8784]
===
match
---
name: keyfile_dict_json [9308,9325]
name: keyfile_dict_json [9308,9325]
===
match
---
name: keyfile_dict [9295,9307]
name: keyfile_dict [9295,9307]
===
match
---
operator: @ [7503,7504]
operator: @ [7503,7504]
===
match
---
trailer [12159,12161]
trailer [12159,12161]
===
match
---
simple_stmt [1475,1513]
simple_stmt [1475,1513]
===
match
---
param [14588,14596]
param [14588,14596]
===
match
---
name: INVALID_REASONS [2864,2879]
name: INVALID_REASONS [2864,2879]
===
match
---
operator: { [11786,11787]
operator: { [11786,11787]
===
match
---
arglist [9264,9480]
arglist [9264,9480]
===
match
---
name: isinstance [2919,2929]
name: isinstance [2919,2929]
===
match
---
expr_stmt [17967,18019]
expr_stmt [17967,18019]
===
match
---
operator: == [3402,3404]
operator: == [3402,3404]
===
match
---
trailer [15098,15104]
trailer [15098,15104]
===
match
---
trailer [3968,3974]
trailer [3968,3974]
===
match
---
trailer [17299,17301]
trailer [17299,17301]
===
match
---
atom_expr [6988,7016]
atom_expr [6988,7016]
===
match
---
name: Any [11428,11431]
name: Any [11428,11431]
===
match
---
trailer [9528,9539]
trailer [9528,9539]
===
match
---
operator: , [21217,21218]
operator: , [21217,21218]
===
match
---
name: path [20519,20523]
name: path [20519,20523]
===
match
---
param [17221,17227]
param [17221,17227]
===
match
---
atom_expr [6672,6698]
atom_expr [6672,6698]
===
match
---
arglist [6988,7049]
arglist [6988,7049]
===
match
---
name: default_kwargs [14823,14837]
name: default_kwargs [14823,14837]
===
match
---
name: enter_context [19699,19712]
name: enter_context [19699,19712]
===
match
---
trailer [7391,7398]
trailer [7391,7398]
===
match
---
subscriptlist [8875,8883]
subscriptlist [8875,8883]
===
match
---
name: version [11244,11251]
name: version [11244,11251]
===
match
---
operator: } [7496,7497]
operator: } [7496,7497]
===
match
---
name: self [9791,9795]
name: self [9791,9795]
===
match
---
trailer [10757,10759]
trailer [10757,10759]
===
match
---
suite [22560,22607]
suite [22560,22607]
===
match
---
operator: , [21246,21247]
operator: , [21246,21247]
===
match
---
name: staticmethod [21748,21760]
name: staticmethod [21748,21760]
===
match
---
name: tenacity [1211,1219]
name: tenacity [1211,1219]
===
match
---
name: discovery [1503,1512]
name: discovery [1503,1512]
===
match
---
name: tokeninfo [10890,10899]
name: tokeninfo [10890,10899]
===
match
---
simple_stmt [18785,18806]
simple_stmt [18785,18806]
===
match
---
name: field_value [12644,12655]
name: field_value [12644,12655]
===
match
---
operator: , [2174,2175]
operator: , [2174,2175]
===
match
---
name: logging [15026,15033]
name: logging [15026,15033]
===
match
---
name: http [11332,11336]
name: http [11332,11336]
===
match
---
atom_expr [2919,2978]
atom_expr [2919,2978]
===
match
---
string: """         Returns num_retries from Connection.          :return: the number of times each API request should be retried         :rtype: int         """ [12245,12398]
string: """         Returns num_retries from Connection.          :return: the number of times each API request should be retried         :rtype: int         """ [12245,12398]
===
match
---
trailer [14463,14469]
trailer [14463,14469]
===
match
---
operator: , [21004,21005]
operator: , [21004,21005]
===
match
---
operator: -> [3158,3160]
operator: -> [3158,3160]
===
match
---
arglist [22467,22509]
arglist [22467,22509]
===
match
---
funcdef [7753,8351]
funcdef [7753,8351]
===
match
---
string: 'Google Cloud' [6156,6170]
string: 'Google Cloud' [6156,6170]
===
match
---
operator: , [6698,6699]
operator: , [6698,6699]
===
match
---
name: googleapiclient [1518,1533]
name: googleapiclient [1518,1533]
===
match
---
operator: { [18463,18464]
operator: { [18463,18464]
===
match
---
comp_op [8586,8592]
comp_op [8586,8592]
===
match
---
simple_stmt [3082,3095]
simple_stmt [3082,3095]
===
match
---
trailer [19961,20018]
trailer [20441,20498]
===
match
---
trailer [18649,18663]
trailer [18649,18663]
===
match
---
operator: = [7940,7941]
operator: = [7940,7941]
===
match
---
parameters [3135,3157]
parameters [3135,3157]
===
match
---
name: scopes [13500,13506]
name: scopes [13500,13506]
===
match
---
testlist_comp [7651,7705]
testlist_comp [7651,7705]
===
match
---
return_stmt [12633,12656]
return_stmt [12633,12656]
===
match
---
operator: = [10586,10587]
operator: = [10586,10587]
===
match
---
trailer [8695,8700]
trailer [8695,8700]
===
match
---
operator: = [9307,9308]
operator: = [9307,9308]
===
match
---
atom_expr [11872,11891]
atom_expr [11872,11891]
===
match
---
trailer [2823,2910]
trailer [2823,2910]
===
match
---
name: auth [1103,1107]
name: auth [1103,1107]
===
match
---
name: delegate_to [8042,8053]
name: delegate_to [8042,8053]
===
match
---
name: details [3012,3019]
name: details [3012,3019]
===
match
---
trailer [18732,18763]
trailer [18732,18763]
===
match
---
name: MediaIoBaseDownload [1591,1610]
name: MediaIoBaseDownload [1591,1610]
===
match
---
operator: = [8015,8016]
operator: = [8015,8016]
===
match
---
name: tenacity [3720,3728]
name: tenacity [3720,3728]
===
match
---
name: target_principal [9093,9109]
name: target_principal [9093,9109]
===
match
---
string: """         A decorator that provides a mechanism to repeat requests in response to exceeding a temporary quote         limit.         """ [13910,14048]
string: """         A decorator that provides a mechanism to repeat requests in response to exceeding a temporary quote         limit.         """ [13910,14048]
===
match
---
atom_expr [16240,16255]
atom_expr [16240,16255]
===
match
---
trailer [10595,10639]
trailer [10595,10639]
===
match
---
strings [12736,12926]
strings [12736,12926]
===
match
---
fstring_start: f' [11754,11756]
fstring_start: f' [11754,11756]
===
match
---
suite [10986,11370]
suite [10986,11370]
===
match
---
name: kwargs [16217,16223]
name: kwargs [16217,16223]
===
match
---
trailer [9350,9357]
trailer [9350,9357]
===
match
---
operator: , [10607,10608]
operator: , [10607,10608]
===
match
---
string: 'DefaultRequestsPerMinutePerProject' [2138,2174]
string: 'DefaultRequestsPerMinutePerProject' [2138,2174]
===
match
---
parameters [6225,6227]
parameters [6225,6227]
===
match
---
name: downloader [22434,22444]
name: downloader [22434,22444]
===
match
---
name: Dict [7553,7557]
name: Dict [7553,7557]
===
match
---
trailer [10119,10136]
trailer [10119,10136]
===
match
---
expr_stmt [10768,10860]
expr_stmt [10768,10860]
===
match
---
simple_stmt [6022,6053]
simple_stmt [6022,6053]
===
match
---
suite [16200,16256]
suite [16200,16256]
===
match
---
operator: , [12108,12109]
operator: , [12108,12109]
===
match
---
name: google [1370,1376]
name: google [1370,1376]
===
match
---
name: cast [17370,17374]
name: cast [17370,17374]
===
match
---
name: google [1779,1785]
name: google [1779,1785]
===
match
---
name: max [14906,14909]
name: max [14906,14909]
===
match
---
trailer [21657,21674]
trailer [21657,21674]
===
match
---
name: str [10225,10228]
name: str [10225,10228]
===
match
---
atom_expr [8305,8328]
atom_expr [8305,8328]
===
match
---
name: provide_gcp_credential_file_as_context [19614,19652]
name: provide_gcp_credential_file_as_context [19614,19652]
===
match
---
name: _cloud_sdk [1389,1399]
name: _cloud_sdk [1389,1399]
===
match
---
param [9791,9795]
param [9791,9795]
===
match
---
atom_expr [11244,11259]
atom_expr [11244,11259]
===
match
---
expr_stmt [14823,15120]
expr_stmt [14823,15120]
===
match
---
trailer [18311,18320]
trailer [18311,18320]
===
match
---
expr_stmt [8037,8067]
expr_stmt [8037,8067]
===
match
---
trailer [16595,16618]
trailer [16595,16618]
===
match
---
operator: } [18761,18762]
operator: } [18761,18762]
===
match
---
trailer [11164,11166]
trailer [11164,11166]
===
match
---
trailer [9958,9960]
trailer [9958,9960]
===
match
---
suite [12996,13477]
suite [12996,13477]
===
match
---
expr_stmt [8305,8350]
expr_stmt [8305,8350]
===
match
---
name: self [16167,16171]
name: self [16167,16171]
===
match
---
name: environ [20052,20059]
name: environ [19873,19880]
===
match
---
decorator [7503,7517]
decorator [7503,7517]
===
match
---
simple_stmt [964,1000]
simple_stmt [964,1000]
===
match
---
suite [2979,3077]
suite [2979,3077]
===
match
---
expr_stmt [10724,10759]
expr_stmt [10724,10759]
===
match
---
string: "v1" [10810,10814]
string: "v1" [10810,10814]
===
match
---
name: keyfile_dict [18650,18662]
name: keyfile_dict [18650,18662]
===
match
---
name: self [8076,8080]
name: self [8076,8080]
===
match
---
string: 'extras' [11816,11824]
string: 'extras' [11816,11824]
===
match
---
name: api_core [1317,1325]
name: api_core [1317,1325]
===
match
---
operator: , [1065,1066]
operator: , [1065,1066]
===
match
---
name: _cached_project_id [9693,9711]
name: _cached_project_id [9693,9711]
===
match
---
name: update [15148,15154]
name: update [15148,15154]
===
match
---
name: _get_credentials [10537,10553]
name: _get_credentials [10537,10553]
===
match
---
arith_expr [11231,11259]
arith_expr [11231,11259]
===
match
---
name: credentials [9194,9205]
name: credentials [9194,9205]
===
match
---
simple_stmt [7612,7748]
simple_stmt [7612,7748]
===
match
---
operator: -> [6228,6230]
operator: -> [6228,6230]
===
match
---
trailer [14168,14191]
trailer [14168,14191]
===
match
---
name: is_soft_quota_exception [2364,2387]
name: is_soft_quota_exception [2364,2387]
===
match
---
atom [19962,20017]
atom [20442,20497]
===
match
---
param [13879,13887]
param [13879,13887]
===
match
---
name: decorator [14062,14071]
name: decorator [14062,14071]
===
match
---
string: 'project_id' [16080,16092]
string: 'project_id' [16080,16092]
===
match
---
name: decorator [14792,14801]
name: decorator [14792,14801]
===
match
---
operator: , [6239,6240]
operator: , [6239,6240]
===
match
---
operator: = [16238,16239]
operator: = [16238,16239]
===
match
---
string: "hidden_fields" [7633,7648]
string: "hidden_fields" [7633,7648]
===
match
---
funcdef [17187,17354]
funcdef [17187,17354]
===
match
---
suite [15914,16065]
suite [15914,16065]
===
match
---
param [11967,11971]
param [11967,11971]
===
match
---
simple_stmt [3373,3441]
simple_stmt [3373,3441]
===
match
---
trailer [8648,8667]
trailer [8648,8667]
===
match
---
name: chunk_size [22499,22509]
name: chunk_size [22499,22509]
===
match
---
trailer [8182,8195]
trailer [8182,8195]
===
match
---
name: Tuple [1060,1065]
name: Tuple [1060,1065]
===
match
---
atom_expr [7853,7866]
atom_expr [7853,7866]
===
match
---
expr_stmt [11175,11194]
expr_stmt [11175,11194]
===
match
---
name: fun [15232,15235]
name: fun [15232,15235]
===
match
---
atom_expr [6863,6883]
atom_expr [6863,6883]
===
match
---
operator: , [20457,20458]
operator: , [20278,20279]
===
match
---
operator: , [10808,10809]
operator: , [10808,10809]
===
match
---
name: Tuple [8401,8406]
name: Tuple [8401,8406]
===
match
---
subscriptlist [8407,8457]
subscriptlist [8407,8457]
===
match
---
trailer [12425,12436]
trailer [12425,12436]
===
match
---
trailer [19652,19654]
trailer [19652,19654]
===
match
---
trailer [9062,9083]
trailer [9062,9083]
===
match
---
name: log [14357,14360]
name: log [14357,14360]
===
match
---
operator: , [3938,3939]
operator: , [3938,3939]
===
match
---
trailer [9645,9665]
trailer [9645,9665]
===
match
---
dotted_name [1370,1381]
dotted_name [1370,1381]
===
match
---
name: creds_file [20814,20824]
name: creds_file [20814,20824]
===
match
---
string: """         Returns the email address associated with the currently logged in account          If a service account is used, it returns the service account.         If user authentication (e.g. gcloud auth) is used, it returns the e-mail account of that user.         """ [10238,10509]
string: """         Returns the email address associated with the currently logged in account          If a service account is used, it returns the service account.         If user authentication (e.g. gcloud auth) is used, it returns the e-mail account of that user.         """ [10238,10509]
===
match
---
raise_stmt [18346,18431]
raise_stmt [18346,18431]
===
match
---
name: exists [20524,20530]
name: exists [20524,20530]
===
match
---
name: is_operation_in_progress_exception [3101,3135]
name: is_operation_in_progress_exception [3101,3135]
===
match
---
operator: * [14581,14582]
operator: * [14581,14582]
===
match
---
atom [19795,19836]
atom [19795,19836]
===
match
---
trailer [11984,11989]
trailer [11984,11989]
===
match
---
string: "gcloud" [20300,20308]
string: "gcloud" [20121,20129]
===
match
---
trailer [16281,16295]
trailer [16281,16295]
===
match
---
name: T [14615,14616]
name: T [14615,14616]
===
match
---
expr_stmt [6022,6052]
expr_stmt [6022,6052]
===
match
---
name: tenacity [15192,15200]
name: tenacity [15192,15200]
===
match
---
decorated [17156,17354]
decorated [17156,17354]
===
match
---
funcdef [9993,10145]
funcdef [9993,10145]
===
match
---
name: args [17338,17342]
name: args [17338,17342]
===
match
---
return_stmt [6581,7497]
return_stmt [6581,7497]
===
match
---
trailer [8707,8718]
trailer [8707,8718]
===
match
---
name: self [17897,17901]
name: self [17897,17901]
===
match
---
dictorsetmaker [19796,19835]
dictorsetmaker [19796,19835]
===
match
---
name: tenacity [14455,14463]
name: tenacity [14455,14463]
===
match
---
name: str [11399,11402]
name: str [11399,11402]
===
match
---
name: Optional [8687,8695]
name: Optional [8687,8695]
===
match
---
atom_expr [7424,7444]
atom_expr [7424,7444]
===
match
---
simple_stmt [14448,14500]
simple_stmt [14448,14500]
===
match
---
fstring_string: \" (type:  [12831,12841]
fstring_string: \" (type:  [12831,12841]
===
match
---
string: "core/project" [19990,20004]
string: "core/project" [20470,20484]
===
match
---
trailer [8962,8968]
trailer [8962,8968]
===
match
---
name: get_credentials_and_project_id [9220,9250]
name: get_credentials_and_project_id [9220,9250]
===
match
---
fstring_string: Current value: \" [12801,12818]
fstring_string: Current value: \" [12801,12818]
===
match
---
atom_expr [21041,21067]
atom_expr [21041,21067]
===
match
---
simple_stmt [1089,1108]
simple_stmt [1089,1108]
===
match
---
operator: , [12549,12550]
operator: , [12549,12550]
===
match
---
name: check_output [19949,19961]
name: check_output [20429,20441]
===
match
---
argument [6856,6883]
argument [6856,6883]
===
match
---
name: Union [7913,7918]
name: Union [7913,7918]
===
match
---
sync_comp_for [2850,2909]
sync_comp_for [2850,2909]
===
match
---
parameters [13871,13888]
parameters [13871,13888]
===
match
---
atom_expr [8687,8700]
atom_expr [8687,8700]
===
match
---
operator: , [17342,17343]
operator: , [17342,17343]
===
match
---
name: authed_http [11358,11369]
name: authed_http [11358,11369]
===
match
---
import_as_names [938,963]
import_as_names [938,963]
===
match
---
atom_expr [10742,10759]
atom_expr [10742,10759]
===
match
---
return_stmt [10108,10144]
return_stmt [10108,10144]
===
match
---
funcdef [16672,17387]
funcdef [16672,17387]
===
match
---
name: default [11925,11932]
name: default [11925,11932]
===
match
---
name: is_operation_in_progress_exception [3885,3919]
name: is_operation_in_progress_exception [3885,3919]
===
match
---
string: "auth/client_id" [21023,21039]
string: "auth/client_id" [21023,21039]
===
match
---
name: inner_wrapper [16635,16648]
name: inner_wrapper [16635,16648]
===
match
---
trailer [10746,10757]
trailer [10746,10757]
===
match
---
dotted_name [1115,1138]
dotted_name [1115,1138]
===
match
---
trailer [17374,17386]
trailer [17374,17386]
===
match
---
number: 0 [7396,7397]
number: 0 [7396,7397]
===
match
---
atom_expr [15350,15367]
atom_expr [15350,15367]
===
match
---
name: ClientInfo [1354,1364]
name: ClientInfo [1354,1364]
===
match
---
name: TemporaryDirectory [19722,19740]
name: TemporaryDirectory [19722,19740]
===
match
---
name: conf_file [18791,18800]
name: conf_file [18791,18800]
===
match
---
atom_expr [8703,8736]
atom_expr [8703,8736]
===
match
---
name: self [8218,8222]
name: self [8218,8222]
===
match
---
string: "Please provide only one value." [18218,18250]
string: "Please provide only one value." [18218,18250]
===
match
---
while_stmt [22540,22607]
while_stmt [22540,22607]
===
match
---
operator: , [1048,1049]
operator: , [1048,1049]
===
match
---
atom_expr [16120,16140]
atom_expr [16120,16140]
===
match
---
operator: = [9522,9523]
operator: = [9522,9523]
===
match
---
trailer [8565,8585]
trailer [8565,8585]
===
match
---
name: logging [14362,14369]
name: logging [14362,14369]
===
match
---
dotted_name [6534,6552]
dotted_name [6534,6552]
===
match
---
name: CLOUD_SDK_CONFIG_DIR [19796,19816]
name: CLOUD_SDK_CONFIG_DIR [19796,19816]
===
match
---
simple_stmt [20240,20499]
simple_stmt [20061,20320]
===
match
---
string: "The `keyfile_dict` and `key_path` fields are mutually exclusive. " [18134,18201]
string: "The `keyfile_dict` and `key_path` fields are mutually exclusive. " [18134,18201]
===
match
---
operator: , [6507,6508]
operator: , [6507,6508]
===
match
---
simple_stmt [18505,18520]
simple_stmt [18505,18520]
===
match
---
name: build [10794,10799]
name: build [10794,10799]
===
match
---
trailer [15231,15236]
trailer [15231,15236]
===
match
---
name: key_path [8677,8685]
name: key_path [8677,8685]
===
match
---
atom_expr [14297,14310]
atom_expr [14297,14310]
===
match
---
name: maxsize [10171,10178]
name: maxsize [10171,10178]
===
match
---
except_clause [8991,9026]
except_clause [8991,9026]
===
match
---
name: args [15909,15913]
name: args [15909,15913]
===
match
---
name: logging [1985,1992]
name: logging [1985,1992]
===
match
---
decorated [15799,16619]
decorated [15799,16619]
===
match
---
atom_expr [18352,18431]
atom_expr [18352,18431]
===
match
---
import_as_names [1441,1474]
import_as_names [1441,1474]
===
match
---
fstring_string: Please check the connection configuration. [12883,12925]
fstring_string: Please check the connection configuration. [12883,12925]
===
match
---
param [21827,21842]
param [21827,21842]
===
match
---
trailer [7861,7866]
trailer [7861,7866]
===
match
---
atom_expr [15192,15236]
atom_expr [15192,15236]
===
match
---
suite [20825,21724]
suite [20825,21724]
===
match
---
name: discovery [10784,10793]
name: discovery [10784,10793]
===
match
---
arglist [15021,15039]
arglist [15021,15039]
===
match
---
sync_comp_for [2880,2909]
sync_comp_for [2880,2909]
===
match
---
simple_stmt [13539,13716]
simple_stmt [13539,13716]
===
match
---
name: BS3TextFieldWidget [7194,7212]
name: BS3TextFieldWidget [7194,7212]
===
match
---
atom_expr [19756,19838]
atom_expr [19756,19838]
===
match
---
if_stmt [12524,12608]
if_stmt [12524,12608]
===
match
---
atom_expr [7317,7350]
atom_expr [7317,7350]
===
match
---
tfpdef [15322,15345]
tfpdef [15322,15345]
===
match
---
atom_expr [12560,12579]
atom_expr [12560,12579]
===
match
---
name: resp [3390,3394]
name: resp [3390,3394]
===
match
---
import_name [1139,1175]
import_name [1139,1175]
===
match
---
operator: , [7486,7487]
operator: , [7486,7487]
===
match
---
testlist_star_expr [12107,12120]
testlist_star_expr [12107,12120]
===
match
---
string: 'port' [7690,7696]
string: 'port' [7690,7696]
===
match
---
name: isinstance [12527,12537]
name: isinstance [12527,12537]
===
match
---
simple_stmt [21861,22426]
simple_stmt [21861,22426]
===
match
---
atom_expr [18719,18763]
atom_expr [18719,18763]
===
match
---
trailer [11809,11825]
trailer [11809,11825]
===
match
---
operator: { [14117,14118]
operator: { [14117,14118]
===
match
---
atom_expr [8644,8667]
atom_expr [8644,8667]
===
match
---
name: lazy_gettext [7317,7329]
name: lazy_gettext [7317,7329]
===
match
---
name: tenacity [3491,3499]
name: tenacity [3491,3499]
===
match
---
trailer [9250,9490]
trailer [9250,9490]
===
match
---
return_stmt [11351,11369]
return_stmt [11351,11369]
===
match
---
return_stmt [9734,9764]
return_stmt [9734,9764]
===
match
---
atom_expr [8244,8289]
atom_expr [8244,8289]
===
match
---
operator: = [22445,22446]
operator: = [22445,22446]
===
match
---
arglist [14470,14493]
arglist [14470,14493]
===
match
---
name: widget [6856,6862]
name: widget [6856,6862]
===
match
---
atom_expr [7116,7228]
atom_expr [7116,7228]
===
match
---
name: google [1405,1411]
name: google [1405,1411]
===
match
---
arglist [12538,12554]
arglist [12538,12554]
===
match
---
atom_expr [3059,3075]
atom_expr [3059,3075]
===
match
---
name: property [13483,13491]
name: property [13483,13491]
===
match
---
simple_stmt [20982,21070]
simple_stmt [20982,21070]
===
match
---
name: widget [7417,7423]
name: widget [7417,7423]
===
match
---
trailer [6654,6741]
trailer [6654,6741]
===
match
---
name: default_conn_name [6057,6074]
name: default_conn_name [6057,6074]
===
match
---
operator: @ [15269,15270]
operator: @ [15269,15270]
===
match
---
operator: = [3959,3960]
operator: = [3959,3960]
===
match
---
simple_stmt [915,964]
simple_stmt [915,964]
===
match
---
param [14581,14587]
param [14581,14587]
===
match
---
name: self [12223,12227]
name: self [12223,12227]
===
match
---
name: project_id [9714,9724]
name: project_id [9714,9724]
===
match
---
atom [18733,18762]
atom [18733,18762]
===
match
---
expr_stmt [12107,12161]
expr_stmt [12107,12161]
===
match
---
string: """         Fetches a field from extras, and returns it. This is some Airflow         magic. The google_cloud_platform hook type adds custom UI elements         to the hook page, which allow admins to specify service_account,         key_path, etc. They get formatted as shown below.         """ [11441,11736]
string: """         Fetches a field from extras, and returns it. This is some Airflow         magic. The google_cloud_platform hook type adds custom UI elements         to the hook page, which allow admins to specify service_account,         key_path, etc. They get formatted as shown below.         """ [11441,11736]
===
match
---
annassign [8685,8736]
annassign [8685,8736]
===
match
---
argument [16609,16617]
argument [16609,16617]
===
match
---
simple_stmt [3956,3975]
simple_stmt [3956,3975]
===
match
---
string: """Returns the Credentials object for Google API""" [9845,9896]
string: """Returns the Credentials object for Google API""" [9845,9896]
===
match
---
name: self [19515,19519]
name: self [19515,19519]
===
match
---
simple_stmt [9500,9551]
simple_stmt [9500,9551]
===
match
---
name: overridden_project_id [9610,9631]
name: overridden_project_id [9610,9631]
===
match
---
name: airflow [1721,1728]
name: airflow [1721,1728]
===
match
---
name: service_account_email [10651,10672]
name: service_account_email [10651,10672]
===
match
---
comparison [2999,3021]
comparison [2999,3021]
===
match
---
arglist [14169,14190]
arglist [14169,14190]
===
match
---
name: lazy_gettext [6439,6451]
name: lazy_gettext [6439,6451]
===
match
---
name: self [9383,9387]
name: self [9383,9387]
===
match
---
trailer [2839,2847]
trailer [2839,2847]
===
match
---
param [14802,14808]
param [14802,14808]
===
match
---
simple_stmt [10037,10100]
simple_stmt [10037,10100]
===
match
---
name: property [11939,11947]
name: property [11939,11947]
===
match
---
return_stmt [8611,8667]
return_stmt [8611,8667]
===
match
---
atom [7734,7736]
atom [7734,7736]
===
match
---
trailer [10536,10553]
trailer [10536,10553]
===
match
---
operator: , [15868,15869]
operator: , [15868,15869]
===
match
---
name: RT [15364,15366]
name: RT [15364,15366]
===
match
---
trailer [7212,7214]
trailer [7212,7214]
===
match
---
name: version [11252,11259]
name: version [11252,11259]
===
match
---
name: fun [14495,14498]
name: fun [14495,14498]
===
match
---
name: kwargs [16096,16102]
name: kwargs [16096,16102]
===
match
---
simple_stmt [11999,12099]
simple_stmt [11999,12099]
===
match
---
atom_expr [14866,14914]
atom_expr [14866,14914]
===
match
---
atom_expr [2995,3076]
atom_expr [2995,3076]
===
match
---
operator: , [6741,6742]
operator: , [6741,6742]
===
match
---
string: 'project_id' [16150,16162]
string: 'project_id' [16150,16162]
===
match
---
comparison [3380,3408]
comparison [3380,3408]
===
match
---
suite [16103,16183]
suite [16103,16183]
===
match
---
name: Callable [3946,3954]
name: Callable [3946,3954]
===
match
---
name: self [3853,3857]
name: self [3853,3857]
===
match
---
name: retry_if_exception [3500,3518]
name: retry_if_exception [3500,3518]
===
match
---
atom_expr [9046,9083]
atom_expr [9046,9083]
===
match
---
argument [2824,2909]
argument [2824,2909]
===
match
---
name: kwargs [13881,13887]
name: kwargs [13881,13887]
===
match
---
simple_stmt [17886,17959]
simple_stmt [17886,17959]
===
match
---
trailer [11251,11259]
trailer [11251,11259]
===
match
---
simple_stmt [2117,2307]
simple_stmt [2117,2307]
===
match
---
simple_stmt [15177,15238]
simple_stmt [15177,15238]
===
match
---
name: staticmethod [7504,7516]
name: staticmethod [7504,7516]
===
match
---
funcdef [15830,16619]
funcdef [15830,16619]
===
match
---
tfpdef [21827,21842]
tfpdef [21827,21842]
===
match
---
operator: = [6706,6707]
operator: = [6706,6707]
===
match
---
testlist_comp [2138,2304]
testlist_comp [2138,2304]
===
match
---
operator: , [15340,15341]
operator: , [15340,15341]
===
match
---
decorator [17156,17179]
decorator [17156,17179]
===
match
---
operator: = [10740,10741]
operator: = [10740,10741]
===
match
---
parameters [13506,13512]
parameters [13506,13512]
===
match
---
name: version [1660,1667]
name: version [1660,1667]
===
match
---
name: _get_access_token [9997,10014]
name: _get_access_token [9997,10014]
===
match
---
name: default [11404,11411]
name: default [11404,11411]
===
match
---
operator: , [7736,7737]
operator: , [7736,7737]
===
match
---
funcdef [14058,14500]
funcdef [14058,14500]
===
match
---
name: fieldwidgets [6344,6356]
name: fieldwidgets [6344,6356]
===
match
---
operator: , [10836,10837]
operator: , [10836,10837]
===
match
---
expr_stmt [19502,19530]
expr_stmt [19502,19530]
===
match
---
name: kwargs [16275,16281]
name: kwargs [16275,16281]
===
match
---
trailer [6235,6245]
trailer [6235,6245]
===
match
---
sync_comp_for [3046,3075]
sync_comp_for [3046,3075]
===
match
---
dotted_name [17157,17172]
dotted_name [17157,17172]
===
match
---
return_stmt [17363,17386]
return_stmt [17363,17386]
===
match
---
expr_stmt [8076,8122]
expr_stmt [8076,8122]
===
match
---
subscriptlist [14610,14616]
subscriptlist [14610,14616]
===
match
---
funcdef [6194,7498]
funcdef [6194,7498]
===
match
---
name: reason [2854,2860]
name: reason [2854,2860]
===
match
---
operator: = [7423,7424]
operator: = [7423,7424]
===
match
---
trailer [19491,19493]
trailer [19491,19493]
===
match
---
name: args [17222,17226]
name: args [17222,17226]
===
match
---
return_stmt [11918,11932]
return_stmt [11918,11932]
===
match
---
name: build_http [11182,11192]
name: build_http [11182,11192]
===
match
---
operator: = [14902,14903]
operator: = [14902,14903]
===
match
---
operator: ** [14426,14428]
operator: ** [14426,14428]
===
match
---
operator: , [7471,7472]
operator: , [7471,7472]
===
match
---
string: """         Function decorator that provides a Google Cloud credentials for application supporting Application         Default Credentials (ADC) strategy.          It is recommended to use ``provide_gcp_credential_file_as_context`` context manager to limit the         scope when authorization data is available. Using context manager also         makes it easier to use multiple connection in one function.         """ [16727,17146]
string: """         Function decorator that provides a Google Cloud credentials for application supporting Application         Default Credentials (ADC) strategy.          It is recommended to use ``provide_gcp_credential_file_as_context`` context manager to limit the         scope when authorization data is available. Using context manager also         makes it easier to use multiple connection in one function.         """ [16727,17146]
===
match
---
name: key_path [9273,9281]
name: key_path [9273,9281]
===
match
---
operator: , [14295,14296]
operator: , [14295,14296]
===
match
---
name: exception [3059,3068]
name: exception [3059,3068]
===
match
---
name: chunksize [22489,22498]
name: chunksize [22489,22498]
===
match
---
dotted_name [1146,1175]
dotted_name [1146,1175]
===
match
---
atom [20274,20480]
atom [20095,20301]
===
match
---
decorator [11938,11948]
decorator [11938,11948]
===
match
---
arglist [8808,8828]
arglist [8808,8828]
===
match
---
trailer [9811,9823]
trailer [9811,9823]
===
match
---
name: _get_target_principal_and_delegates [9123,9158]
name: _get_target_principal_and_delegates [9123,9158]
===
match
---
trailer [3728,3747]
trailer [3728,3747]
===
match
---
and_test [12527,12585]
and_test [12527,12585]
===
match
---
atom_expr [19440,19493]
atom_expr [19440,19493]
===
match
---
decorator [15269,15283]
decorator [15269,15283]
===
match
---
simple_stmt [13910,14049]
simple_stmt [13910,14049]
===
match
---
param [14072,14085]
param [14072,14085]
===
match
---
trailer [18800,18805]
trailer [18800,18805]
===
match
---
name: str [10024,10027]
name: str [10024,10027]
===
match
---
name: get_ui_field_behaviour [7525,7547]
name: get_ui_field_behaviour [7525,7547]
===
match
---
trailer [8149,8164]
trailer [8149,8164]
===
match
---
not_test [16271,16295]
not_test [16271,16295]
===
match
---
import_from [1716,1755]
import_from [1716,1755]
===
match
---
operator: = [7867,7868]
operator: = [7867,7868]
===
match
---
name: name [18757,18761]
name: name [18757,18761]
===
match
---
atom_expr [17256,17301]
atom_expr [17256,17301]
===
match
---
expr_stmt [22434,22510]
expr_stmt [22434,22510]
===
match
---
name: T [16716,16717]
name: T [16716,16717]
===
match
---
name: extras [8136,8142]
name: extras [8136,8142]
===
match
---
operator: == [3434,3436]
operator: == [3434,3436]
===
match
---
atom [14610,14613]
atom [14610,14613]
===
match
---
import_from [6529,6571]
import_from [6529,6571]
===
match
---
suite [4008,22635]
suite [4008,22635]
===
match
---
simple_stmt [1558,1639]
simple_stmt [1558,1639]
===
match
---
operator: , [7779,7780]
operator: , [7779,7780]
===
match
---
trailer [16244,16255]
trailer [16244,16255]
===
match
---
name: _get_field [11379,11389]
name: _get_field [11379,11389]
===
match
---
name: func [16591,16595]
name: func [16591,16595]
===
match
---
operator: , [21021,21022]
operator: , [21021,21022]
===
match
---
expr_stmt [9641,9679]
expr_stmt [9641,9679]
===
match
---
simple_stmt [21392,21724]
simple_stmt [21392,21724]
===
match
---
string: """         Return OAuth 2.0 scopes.          :return: Returns the scope defined in the connection configuration, or the default scope         :rtype: Sequence[str]         """ [13539,13715]
string: """         Return OAuth 2.0 scopes.          :return: Returns the scope defined in the connection configuration, or the default scope         :rtype: Sequence[str]         """ [13539,13715]
===
match
---
trailer [18695,18697]
trailer [18695,18697]
===
match
---
name: exception [3342,3351]
name: exception [3342,3351]
===
match
---
name: Callable [15328,15336]
name: Callable [15328,15336]
===
match
---
name: provide_gcp_credential_file_as_context [17261,17299]
name: provide_gcp_credential_file_as_context [17261,17299]
===
match
---
operator: , [11814,11815]
operator: , [11814,11815]
===
match
---
name: update [14419,14425]
name: update [14419,14425]
===
match
---
trailer [9010,9026]
trailer [9010,9026]
===
match
---
if_stmt [18300,18432]
if_stmt [18300,18432]
===
match
---
atom_expr [15001,15040]
atom_expr [15001,15040]
===
match
---
param [17455,17459]
param [17455,17459]
===
match
---
name: type [12842,12846]
name: type [12842,12846]
===
match
---
suite [18488,18520]
suite [18488,18520]
===
match
---
name: isinstance [2771,2781]
name: isinstance [2771,2781]
===
match
---
operator: * [15870,15871]
operator: * [15870,15871]
===
match
---
suite [17302,17354]
suite [17302,17354]
===
match
---
trailer [17330,17353]
trailer [17330,17353]
===
match
---
operator: = [11281,11282]
operator: = [11281,11282]
===
match
---
atom_expr [13738,13768]
atom_expr [13738,13768]
===
match
---
atom_expr [18100,18264]
atom_expr [18100,18264]
===
match
---
name: wraps [15810,15815]
name: wraps [15810,15815]
===
match
---
param [21799,21811]
param [21799,21811]
===
match
---
funcdef [2360,3095]
funcdef [2360,3095]
===
match
---
arglist [17913,17929]
arglist [17913,17929]
===
match
---
name: flask_babel [6420,6431]
name: flask_babel [6420,6431]
===
match
---
funcdef [18935,21742]
funcdef [18935,21742]
===
match
---
simple_stmt [6415,6452]
simple_stmt [6415,6452]
===
match
---
name: int [12640,12643]
name: int [12640,12643]
===
match
---
operator: = [8790,8791]
operator: = [8790,8791]
===
match
---
atom_expr [14404,14435]
atom_expr [14404,14435]
===
match
---
yield_expr [18899,18909]
yield_expr [18899,18909]
===
match
---
name: error [2834,2839]
name: error [2834,2839]
===
match
---
string: 'gcp_conn_id' [6039,6052]
string: 'gcp_conn_id' [6039,6052]
===
match
---
name: environment_vars [1417,1433]
name: environment_vars [1417,1433]
===
match
---
import_from [1305,1364]
import_from [1305,1364]
===
match
---
name: contextmanager [949,963]
name: contextmanager [949,963]
===
match
---
operator: = [6037,6038]
operator: = [6037,6038]
===
match
---
name: os [20516,20518]
name: os [20516,20518]
===
match
---
name: typing [1005,1011]
name: typing [1005,1011]
===
match
---
name: delegate_to [9371,9382]
name: delegate_to [9371,9382]
===
match
---
tfpdef [3136,3156]
tfpdef [3136,3156]
===
match
---
arglist [15189,15236]
arglist [15189,15236]
===
match
---
name: super [7971,7976]
name: super [7971,7976]
===
match
---
decorated [13838,14526]
decorated [13838,14526]
===
match
---
simple_stmt [8677,8737]
simple_stmt [8677,8737]
===
match
---
operator: , [20340,20341]
operator: , [20161,20162]
===
match
---
atom_expr [19515,19530]
atom_expr [19515,19530]
===
match
---
import_as_names [1832,1921]
import_as_names [1832,1921]
===
match
---
operator: , [17219,17220]
operator: , [17219,17220]
===
match
---
operator: , [6897,6898]
operator: , [6897,6898]
===
match
---
simple_stmt [6057,6100]
simple_stmt [6057,6100]
===
match
---
string: 'password' [7678,7688]
string: 'password' [7678,7688]
===
match
---
import_from [1365,1399]
import_from [1365,1399]
===
match
---
name: provide_gcp_credential_file [16676,16703]
name: provide_gcp_credential_file [16676,16703]
===
match
---
operator: = [9608,9609]
operator: = [9608,9609]
===
match
---
trailer [7329,7350]
trailer [7329,7350]
===
match
---
name: name [18801,18805]
name: name [18801,18805]
===
match
---
simple_stmt [21736,21742]
simple_stmt [21736,21742]
===
match
---
name: credentials [8419,8430]
name: credentials [8419,8430]
===
match
---
name: patch_environ [1964,1977]
name: patch_environ [1964,1977]
===
match
---
import_name [899,914]
import_name [899,914]
===
match
---
operator: = [11417,11418]
operator: = [11417,11418]
===
match
---
atom_expr [11143,11166]
atom_expr [11143,11166]
===
match
---
name: self [8644,8648]
name: self [8644,8648]
===
match
---
name: keyfile_dict_json [8842,8859]
name: keyfile_dict_json [8842,8859]
===
match
---
name: version [13433,13440]
name: version [13433,13440]
===
match
---
name: impersonation_chain [8103,8122]
name: impersonation_chain [8103,8122]
===
match
---
return_stmt [9969,9987]
return_stmt [9969,9987]
===
match
---
with_item [18564,18616]
with_item [18564,18616]
===
match
---
trailer [8169,8181]
trailer [8169,8181]
===
match
---
name: dict [21821,21825]
name: dict [21821,21825]
===
match
---
name: keyfile_dict [8762,8774]
name: keyfile_dict [8762,8774]
===
match
---
trailer [2781,2803]
trailer [2781,2803]
===
match
---
trailer [10138,10144]
trailer [10138,10144]
===
match
---
fstring_string: The num_retries field should be a integer.  [12738,12781]
fstring_string: The num_retries field should be a integer.  [12738,12781]
===
match
---
operator: , [13877,13878]
operator: , [13877,13878]
===
match
---
operator: , [14586,14587]
operator: , [14586,14587]
===
match
---
name: project_id [9597,9607]
name: project_id [9597,9607]
===
match
---
string: 'userRateLimitExceeded' [2331,2354]
string: 'userRateLimitExceeded' [2331,2354]
===
match
---
number: 1 [14180,14181]
number: 1 [14180,14181]
===
match
---
name: self [8703,8707]
name: self [8703,8707]
===
match
---
operator: = [9469,9470]
operator: = [9469,9470]
===
match
---
import_name [862,873]
import_name [862,873]
===
match
---
import_name [874,888]
import_name [874,888]
===
match
---
string: 'key_path' [8719,8729]
string: 'key_path' [8719,8729]
===
match
---
with_stmt [17251,17354]
with_stmt [17251,17354]
===
match
---
name: str [7919,7922]
name: str [7919,7922]
===
match
---
name: func [15322,15326]
name: func [15322,15326]
===
match
---
string: "T" [3935,3938]
string: "T" [3935,3938]
===
match
---
name: endswith [18312,18320]
name: endswith [18312,18320]
===
match
---
expr_stmt [8218,8296]
expr_stmt [8218,8296]
===
match
---
operator: ** [14588,14590]
operator: ** [14588,14590]
===
match
---
expr_stmt [8762,8829]
expr_stmt [8762,8829]
===
match
---
trailer [18643,18649]
trailer [18643,18649]
===
match
---
name: self [9159,9163]
name: self [9159,9163]
===
match
---
operator: @ [16654,16655]
operator: @ [16654,16655]
===
match
---
simple_stmt [3754,3835]
simple_stmt [3754,3835]
===
match
---
simple_stmt [12599,12608]
simple_stmt [12599,12608]
===
match
---
atom_expr [19949,20018]
atom_expr [20429,20498]
===
match
---
if_stmt [11799,11933]
if_stmt [11799,11933]
===
match
---
name: __init__ [3615,3623]
name: __init__ [3615,3623]
===
match
---
raise_stmt [12696,12940]
raise_stmt [12696,12940]
===
match
---
trailer [15075,15085]
trailer [15075,15085]
===
match
---
if_stmt [9559,9632]
if_stmt [9559,9632]
===
match
---
atom [7619,7747]
atom [7619,7747]
===
match
---
raise_stmt [18094,18264]
raise_stmt [18094,18264]
===
match
---
testlist_star_expr [9905,9919]
testlist_star_expr [9905,9919]
===
match
---
trailer [14346,14356]
trailer [14346,14356]
===
match
---
name: f [11787,11788]
name: f [11787,11788]
===
match
---
name: conf_file [18680,18689]
name: conf_file [18680,18689]
===
match
---
trailer [19794,19837]
trailer [19794,19837]
===
match
---
simple_stmt [11865,11892]
simple_stmt [11865,11892]
===
match
---
name: default_kwargs [14100,14114]
name: default_kwargs [14100,14114]
===
match
---
param [15322,15345]
param [15322,15345]
===
match
---
atom_expr [17982,18019]
atom_expr [17982,18019]
===
match
---
import_from [1400,1474]
import_from [1400,1474]
===
match
---
funcdef [3611,3681]
funcdef [3611,3681]
===
match
---
argument [7187,7214]
argument [7187,7214]
===
match
---
tfpdef [16704,16711]
tfpdef [16704,16711]
===
match
---
name: keyfile_dict [8908,8920]
name: keyfile_dict [8908,8920]
===
match
---
name: self [11810,11814]
name: self [11810,11814]
===
match
---
trailer [9387,9399]
trailer [9387,9399]
===
match
---
name: Optional [1040,1048]
name: Optional [1040,1048]
===
match
---
decorator [13482,13492]
decorator [13482,13492]
===
match
---
tfpdef [14802,14808]
tfpdef [14802,14808]
===
match
---
name: property [12194,12202]
name: property [12194,12202]
===
match
---
operator: { [18733,18734]
operator: { [18733,18734]
===
match
---
import_as_names [1591,1638]
import_as_names [1591,1638]
===
match
---
trailer [10911,10920]
trailer [10911,10920]
===
match
---
name: service_account [1160,1175]
name: service_account [1160,1175]
===
match
---
operator: { [6588,6589]
operator: { [6588,6589]
===
match
---
operator: = [18596,18597]
operator: = [18596,18597]
===
match
---
operator: , [7657,7658]
operator: , [7657,7658]
===
match
---
trailer [13819,13832]
trailer [13819,13832]
===
match
---
name: request [21812,21819]
name: request [21812,21819]
===
match
---
trailer [14291,14311]
trailer [14291,14311]
===
match
---
name: cloud [1786,1791]
name: cloud [1786,1791]
===
match
---
atom_expr [6643,6741]
atom_expr [6643,6741]
===
match
---
argument [13396,13448]
argument [13396,13448]
===
match
---
atom_expr [7145,7185]
atom_expr [7145,7185]
===
match
---
suite [7962,8351]
suite [7962,8351]
===
match
---
string: 'project_id' [16224,16236]
string: 'project_id' [16224,16236]
===
match
---
sync_comp_for [3022,3075]
sync_comp_for [3022,3075]
===
match
---
with_stmt [18444,18520]
with_stmt [18444,18520]
===
match
---
atom_expr [8218,8242]
atom_expr [8218,8242]
===
match
---
name: Optional [8244,8252]
name: Optional [8244,8252]
===
match
---
trailer [3875,3884]
trailer [3875,3884]
===
match
---
operator: } [11788,11789]
operator: } [11788,11789]
===
match
---
trailer [15085,15105]
trailer [15085,15105]
===
match
---
operator: , [16607,16608]
operator: , [16607,16608]
===
match
---
operator: = [7395,7396]
operator: = [7395,7396]
===
match
---
arith_expr [13419,13448]
arith_expr [13419,13448]
===
match
---
name: creds_content [21248,21261]
name: creds_content [21248,21261]
===
match
---
name: check_output [987,999]
name: check_output [987,999]
===
match
---
name: any [2995,2998]
name: any [2995,2998]
===
match
---
operator: , [9399,9400]
operator: , [9399,9400]
===
match
---
trailer [3068,3075]
trailer [3068,3075]
===
match
---
argument [10838,10859]
argument [10838,10859]
===
match
---
dotted_name [1225,1251]
dotted_name [1225,1251]
===
match
---
name: project_id [9207,9217]
name: project_id [9207,9217]
===
match
---
name: _get_field [17902,17912]
name: _get_field [17902,17912]
===
match
---
dictorsetmaker [18734,18761]
dictorsetmaker [18734,18761]
===
match
---
atom_expr [11182,11194]
atom_expr [11182,11194]
===
match
---
trailer [21601,21614]
trailer [21601,21614]
===
match
---
suite [8921,8983]
suite [8921,8983]
===
match
---
name: multiplier [14169,14179]
name: multiplier [14169,14179]
===
match
---
suite [18819,18910]
suite [18819,18910]
===
match
---
name: self [10216,10220]
name: self [10216,10220]
===
match
---
operator: @ [17392,17393]
operator: @ [17392,17393]
===
match
---
simple_stmt [11269,11343]
simple_stmt [11269,11343]
===
match
---
trailer [13440,13448]
trailer [13440,13448]
===
match
---
number: 5 [12606,12607]
number: 5 [12606,12607]
===
match
---
trailer [15336,15345]
trailer [15336,15345]
===
match
---
operator: = [8290,8291]
operator: = [8290,8291]
===
match
---
simple_stmt [10995,11121]
simple_stmt [10995,11121]
===
match
---
atom_expr [22583,22606]
atom_expr [22583,22606]
===
match
---
operator: = [12419,12420]
operator: = [12419,12420]
===
match
---
parameters [21798,21843]
parameters [21798,21843]
===
match
---
name: T [16710,16711]
name: T [16710,16711]
===
match
---
funcdef [17412,18910]
funcdef [17412,18910]
===
match
---
simple_stmt [1513,1558]
simple_stmt [1513,1558]
===
match
---
simple_stmt [15247,15264]
simple_stmt [15247,15264]
===
match
---
expr_stmt [10564,10639]
expr_stmt [10564,10639]
===
match
---
argument [6700,6727]
argument [6700,6727]
===
match
---
name: providers [1769,1778]
name: providers [1769,1778]
===
match
---
name: mode [18592,18596]
name: mode [18592,18596]
===
match
---
tfpdef [7883,7939]
tfpdef [7883,7939]
===
match
---
atom_expr [21160,21301]
atom_expr [21160,21301]
===
match
---
expr_stmt [16120,16182]
expr_stmt [16120,16182]
===
match
---
classdef [3977,22635]
classdef [3977,22635]
===
match
---
name: PasswordField [6494,6507]
name: PasswordField [6494,6507]
===
match
---
name: set_user_agent [1624,1638]
name: set_user_agent [1624,1638]
===
match
---
operator: = [20860,20861]
operator: = [20860,20861]
===
match
---
name: enter_context [19767,19780]
name: enter_context [19767,19780]
===
match
---
argument [15214,15230]
argument [15214,15230]
===
match
---
operator: { [19795,19796]
operator: { [19795,19796]
===
match
---
suite [8459,9765]
suite [8459,9765]
===
match
---
atom_expr [19545,19556]
atom_expr [19545,19556]
===
match
---
arglist [16596,16617]
arglist [16596,16617]
===
match
---
suite [7558,7748]
suite [7558,7748]
===
match
---
simple_stmt [18634,18664]
simple_stmt [18634,18664]
===
match
---
trailer [21054,21067]
trailer [21054,21067]
===
match
---
trailer [14151,14168]
trailer [14151,14168]
===
match
---
import_from [1513,1557]
import_from [1513,1557]
===
match
---
suite [15368,16649]
suite [15368,16649]
===
match
---
simple_stmt [16313,16572]
simple_stmt [16313,16572]
===
match
---
suite [19866,20019]
suite [20346,20499]
===
match
---
string: "extra__google_cloud_platform__project" [6602,6641]
string: "extra__google_cloud_platform__project" [6602,6641]
===
match
---
trailer [14609,14617]
trailer [14609,14617]
===
match
---
name: scopes [9351,9357]
name: scopes [9351,9357]
===
match
---
string: "activate-refresh-token" [21534,21558]
string: "activate-refresh-token" [21534,21558]
===
match
---
decorated [17392,18910]
decorated [17392,18910]
===
match
---
atom_expr [14338,14376]
atom_expr [14338,14376]
===
match
---
trailer [8718,8736]
trailer [8718,8736]
===
match
---
name: http [1579,1583]
name: http [1579,1583]
===
match
---
atom_expr [8444,8457]
atom_expr [8444,8457]
===
match
---
name: ResourceExhausted [1270,1287]
name: ResourceExhausted [1270,1287]
===
match
---
trailer [8430,8442]
trailer [8430,8442]
===
match
---
string: "auth" [21498,21504]
string: "auth" [21498,21504]
===
match
---
operator: , [12450,12451]
operator: , [12450,12451]
===
match
---
import_from [6322,6406]
import_from [6322,6406]
===
match
---
operator: , [11229,11230]
operator: , [11229,11230]
===
match
---
operator: = [13418,13419]
operator: = [13418,13419]
===
match
---
name: file_handle [21799,21810]
name: file_handle [21799,21810]
===
match
---
name: _cloud_sdk [19440,19450]
name: _cloud_sdk [19440,19450]
===
match
---
name: max [14183,14186]
name: max [14183,14186]
===
match
---
string: 'after' [14329,14336]
string: 'after' [14329,14336]
===
match
---
simple_stmt [16628,16649]
simple_stmt [16628,16649]
===
match
---
operator: , [1610,1611]
operator: , [1610,1611]
===
match
---
name: self [8037,8041]
name: self [8037,8041]
===
match
---
name: status [3427,3433]
name: status [3427,3433]
===
match
---
atom_expr [14455,14499]
atom_expr [14455,14499]
===
match
---
simple_stmt [3639,3681]
simple_stmt [3639,3681]
===
match
---
operator: = [8956,8957]
operator: = [8956,8957]
===
match
---
operator: = [17895,17896]
operator: = [17895,17896]
===
match
---
operator: = [8886,8887]
operator: = [8886,8887]
===
match
---
comparison [8561,8597]
comparison [8561,8597]
===
match
---
operator: * [17337,17338]
operator: * [17337,17338]
===
match
---
operator: , [21614,21615]
operator: , [21614,21615]
===
match
---
name: keyfile_dict [18533,18545]
name: keyfile_dict [18533,18545]
===
match
---
name: self [8618,8622]
name: self [8618,8622]
===
match
---
parameters [11389,11424]
parameters [11389,11424]
===
match
---
name: self [9641,9645]
name: self [9641,9645]
===
match
---
operator: , [19988,19989]
operator: , [20468,20469]
===
match
---
simple_stmt [10686,10715]
simple_stmt [10686,10715]
===
match
---
trailer [7299,7486]
trailer [7299,7486]
===
match
---
suite [3859,3921]
suite [3859,3921]
===
match
---
name: _get_field [17987,17997]
name: _get_field [17987,17997]
===
match
---
name: build_http [1612,1622]
name: build_http [1612,1622]
===
match
---
string: 'retry' [14932,14939]
string: 'retry' [14932,14939]
===
match
---
param [8392,8396]
param [8392,8396]
===
match
---
trailer [8264,8276]
trailer [8264,8276]
===
match
---
string: "airflow/" [11231,11241]
string: "airflow/" [11231,11241]
===
match
---
name: getattr [10588,10595]
name: getattr [10588,10595]
===
match
---
name: subprocess [969,979]
name: subprocess [969,979]
===
match
---
trailer [18116,18264]
trailer [18116,18264]
===
match
---
atom_expr [9346,9357]
atom_expr [9346,9357]
===
match
---
fstring_start: f" [12799,12801]
fstring_start: f" [12799,12801]
===
match
---
param [7789,7831]
param [7789,7831]
===
match
---
trailer [8164,8182]
trailer [8164,8182]
===
match
---
operator: = [8143,8144]
operator: = [8143,8144]
===
match
---
operator: -> [12229,12231]
operator: -> [12229,12231]
===
match
---
trailer [14304,14310]
trailer [14304,14310]
===
match
---
name: delegate_to [7840,7851]
name: delegate_to [7840,7851]
===
match
---
operator: + [13431,13432]
operator: + [13431,13432]
===
match
---
name: self [12421,12425]
name: self [12421,12425]
===
match
---
name: Any [11413,11416]
name: Any [11413,11416]
===
match
---
comparison [2824,2849]
comparison [2824,2849]
===
match
---
expr_stmt [2117,2306]
expr_stmt [2117,2306]
===
match
---
dotted_name [1563,1583]
dotted_name [1563,1583]
===
match
---
name: quota_retry [13860,13871]
name: quota_retry [13860,13871]
===
match
---
trailer [19780,19838]
trailer [19780,19838]
===
match
---
parameters [10014,10020]
parameters [10014,10020]
===
match
---
name: client_info [13371,13382]
name: client_info [13371,13382]
===
match
---
name: _get_scopes [13808,13819]
name: _get_scopes [13808,13819]
===
match
---
arglist [17331,17352]
arglist [17331,17352]
===
match
---
name: Optional [8330,8338]
name: Optional [8330,8338]
===
match
---
string: 'Invalid key JSON.' [9063,9082]
string: 'Invalid key JSON.' [9063,9082]
===
match
---
name: tempfile [18564,18572]
name: tempfile [18564,18572]
===
match
---
argument [14906,14913]
argument [14906,14913]
===
match
---
arglist [12437,12461]
arglist [12437,12461]
===
match
---
trailer [16149,16163]
trailer [16149,16163]
===
match
---
decorated [6176,7498]
decorated [6176,7498]
===
match
---
operator: } [15119,15120]
operator: } [15119,15120]
===
match
---
atom_expr [8958,8982]
atom_expr [8958,8982]
===
match
---
number: 300 [14910,14913]
number: 300 [14910,14913]
===
match
---
simple_stmt [22615,22635]
simple_stmt [22615,22635]
===
match
---
suite [13901,14526]
suite [13901,14526]
===
match
---
trailer [3011,3019]
trailer [3011,3019]
===
match
---
atom_expr [15133,15164]
atom_expr [15133,15164]
===
match
---
with_stmt [18714,18806]
with_stmt [18714,18806]
===
match
---
operator: , [19971,19972]
operator: , [20451,20452]
===
match
---
name: request [22480,22487]
name: request [22480,22487]
===
match
---
name: Callable [15350,15358]
name: Callable [15350,15358]
===
match
---
simple_stmt [19584,19656]
simple_stmt [19584,19656]
===
match
---
trailer [9539,9550]
trailer [9539,9550]
===
match
---
param [18965,18969]
param [18965,18969]
===
match
---
trailer [19740,19742]
trailer [19740,19742]
===
match
---
trailer [8276,8288]
trailer [8276,8288]
===
match
---
atom_expr [2834,2849]
atom_expr [2834,2849]
===
match
---
trailer [6684,6698]
trailer [6684,6698]
===
match
---
decorated [12946,13477]
decorated [12946,13477]
===
match
---
testlist_comp [19963,20016]
testlist_comp [20443,20496]
===
match
---
trailer [10553,10555]
trailer [10553,10555]
===
match
---
operator: = [9272,9273]
operator: = [9272,9273]
===
match
---
operator: ... [15337,15340]
operator: ... [15337,15340]
===
match
---
operator: , [20004,20005]
operator: , [20484,20485]
===
match
---
operator: } [12830,12831]
operator: } [12830,12831]
===
match
---
simple_stmt [14100,14392]
simple_stmt [14100,14392]
===
match
---
name: log [15086,15089]
name: log [15086,15089]
===
match
---
name: args [13873,13877]
name: args [13873,13877]
===
match
---
subscriptlist [6236,6244]
subscriptlist [6236,6244]
===
match
---
operator: } [18485,18486]
operator: } [18485,18486]
===
match
---
except_clause [12665,12682]
except_clause [12665,12682]
===
match
---
name: args [15208,15212]
name: args [15208,15212]
===
match
---
name: getLogger [1993,2002]
name: getLogger [1993,2002]
===
match
---
name: target_principal [9430,9446]
name: target_principal [9430,9446]
===
match
---
name: kwargs [15157,15163]
name: kwargs [15157,15163]
===
match
---
string: """         Context manager that provides a Google Cloud credentials for application supporting `Application         Default Credentials (ADC) strategy <https://cloud.google.com/docs/authentication/production>`__.          It can be used to provide credentials for external programs (e.g. gcloud) that expect authorization         file in ``GOOGLE_APPLICATION_CREDENTIALS`` environment variable.         """ [17470,17877]
string: """         Context manager that provides a Google Cloud credentials for application supporting `Application         Default Credentials (ADC) strategy <https://cloud.google.com/docs/authentication/production>`__.          It can be used to provide credentials for external programs (e.g. gcloud) that expect authorization         file in ``GOOGLE_APPLICATION_CREDENTIALS`` environment variable.         """ [17470,17877]
===
match
---
trailer [6881,6883]
trailer [6881,6883]
===
match
---
name: wrapper [17191,17198]
name: wrapper [17191,17198]
===
match
---
name: self [12123,12127]
name: self [12123,12127]
===
match
---
operator: = [9382,9383]
operator: = [9382,9383]
===
match
---
trailer [8259,8264]
trailer [8259,8264]
===
match
---
comparison [3412,3440]
comparison [3412,3440]
===
match
---
name: exception [2893,2902]
name: exception [2893,2902]
===
match
---
name: download_content_from_request [21769,21798]
name: download_content_from_request [21769,21798]
===
match
---
name: wait_exponential [14875,14891]
name: wait_exponential [14875,14891]
===
match
---
name: _ [12107,12108]
name: _ [12107,12108]
===
match
---
name: conf_file [18634,18643]
name: conf_file [18634,18643]
===
match
---
operator: , [1081,1082]
operator: , [1081,1082]
===
match
---
name: exit_stack [19584,19594]
name: exit_stack [19584,19594]
===
match
---
string: 'Number of Retries' [7330,7349]
string: 'Number of Retries' [7330,7349]
===
match
---
string: "auth/client_secret" [21226,21246]
string: "auth/client_secret" [21226,21246]
===
match
---
expr_stmt [11745,11790]
expr_stmt [11745,11790]
===
match
---
trailer [3873,3875]
trailer [3873,3875]
===
match
---
name: conn_type [6104,6113]
name: conn_type [6104,6113]
===
match
---
name: __name__ [2003,2011]
name: __name__ [2003,2011]
===
match
---
name: tenacity [14338,14346]
name: tenacity [14338,14346]
===
match
---
suite [8598,8668]
suite [8598,8668]
===
match
---
name: Dict [1034,1038]
name: Dict [1034,1038]
===
match
---
operator: = [9121,9122]
operator: = [9121,9122]
===
match
---
string: "config" [19973,19981]
string: "config" [20453,20461]
===
match
---
string: "gcloud" [19963,19971]
string: "gcloud" [20443,20451]
===
match
---
name: gcp_conn_id [8170,8181]
name: gcp_conn_id [8170,8181]
===
match
---
name: token [10139,10144]
name: token [10139,10144]
===
match
---
trailer [19721,19740]
trailer [19721,19740]
===
match
---
operator: = [7378,7379]
operator: = [7378,7379]
===
match
---
name: ResourceExhausted [2942,2959]
name: ResourceExhausted [2942,2959]
===
match
---
name: json [869,873]
name: json [869,873]
===
match
---
operator: , [15040,15041]
operator: , [15040,15041]
===
match
---
name: delegate_to [9388,9399]
name: delegate_to [9388,9399]
===
match
---
string: 'service_account_email' [10609,10632]
string: 'service_account_email' [10609,10632]
===
match
---
number: 1 [14903,14904]
number: 1 [14903,14904]
===
match
---
name: DEBUG [15099,15104]
name: DEBUG [15099,15104]
===
match
---
simple_stmt [15133,15165]
simple_stmt [15133,15165]
===
match
---
atom_expr [20516,20548]
atom_expr [20516,20548]
===
match
---
trailer [14874,14891]
trailer [14874,14891]
===
match
---
string: 'w+t' [18597,18602]
string: 'w+t' [18597,18602]
===
match
---
name: str [8696,8699]
name: str [8696,8699]
===
match
---
operator: , [18012,18013]
operator: , [18012,18013]
===
match
---
arglist [8719,8735]
arglist [8719,8735]
===
match
---
param [15870,15876]
param [15870,15876]
===
match
---
trailer [13742,13753]
trailer [13742,13753]
===
match
---
string: 'key_path' [17913,17923]
string: 'key_path' [17913,17923]
===
match
---
param [15877,15885]
param [15877,15885]
===
match
---
name: google_auth_httplib2 [11283,11303]
name: google_auth_httplib2 [11283,11303]
===
match
---
parameters [3623,3629]
parameters [3623,3629]
===
match
---
trailer [3644,3646]
trailer [3644,3646]
===
match
---
operator: , [21810,21811]
operator: , [21810,21811]
===
match
---
name: CREDENTIALS [20443,20454]
name: CREDENTIALS [20264,20275]
===
match
---
operator: ** [14477,14479]
operator: ** [14477,14479]
===
match
---
atom [2325,2357]
atom [2325,2357]
===
match
---
name: extras [11877,11883]
name: extras [11877,11883]
===
match
---
name: str [7862,7865]
name: str [7862,7865]
===
match
---
operator: { [14840,14841]
operator: { [14840,14841]
===
match
---
name: key_path [17886,17894]
name: key_path [17886,17894]
===
match
---
operator: , [6492,6493]
operator: , [6492,6493]
===
match
---
simple_stmt [19421,19494]
simple_stmt [19421,19494]
===
match
---
if_stmt [2916,3077]
if_stmt [2916,3077]
===
match
---
name: exception [3136,3145]
name: exception [3136,3145]
===
match
---
classdef [3683,3921]
classdef [3683,3921]
===
match
---
funcdef [15287,16649]
funcdef [15287,16649]
===
match
---
arglist [14892,14913]
arglist [14892,14913]
===
match
---
atom_expr [3720,3747]
atom_expr [3720,3747]
===
match
---
trailer [19608,19655]
trailer [19608,19655]
===
match
---
simple_stmt [1756,1924]
simple_stmt [1756,1924]
===
match
---
tfpdef [21812,21825]
tfpdef [21812,21825]
===
match
---
simple_stmt [13371,13450]
simple_stmt [13371,13450]
===
match
---
string: '' [12583,12585]
string: '' [12583,12585]
===
match
---
name: lazy_gettext [6672,6684]
name: lazy_gettext [6672,6684]
===
match
---
simple_stmt [13005,13363]
simple_stmt [13005,13363]
===
match
---
operator: , [17923,17924]
operator: , [17923,17924]
===
match
---
trailer [22604,22606]
trailer [22604,22606]
===
match
---
arglist [17375,17385]
arglist [17375,17385]
===
match
---
atom_expr [8998,9026]
atom_expr [8998,9026]
===
match
---
number: 100 [14187,14190]
number: 100 [14187,14190]
===
match
---
name: auth [8414,8418]
name: auth [8414,8418]
===
match
---
operator: , [22574,22575]
operator: , [22574,22575]
===
match
---
simple_stmt [845,862]
simple_stmt [845,862]
===
match
---
string: "set" [21219,21224]
string: "set" [21219,21224]
===
match
---
string: """         Returns an authorized HTTP object to be used to build a Google cloud         service hook connection.         """ [10995,11120]
string: """         Returns an authorized HTTP object to be used to build a Google cloud         service hook connection.         """ [10995,11120]
===
match
---
atom_expr [12640,12656]
atom_expr [12640,12656]
===
match
---
trailer [8252,8289]
trailer [8252,8289]
===
match
---
operator: , [14311,14312]
operator: , [14311,14312]
===
match
---
name: project_id [12177,12187]
name: project_id [12177,12187]
===
match
---
name: credentials [11129,11140]
name: credentials [11129,11140]
===
match
---
number: 429 [3405,3408]
number: 429 [3405,3408]
===
match
---
name: after_log [15076,15085]
name: after_log [15076,15085]
===
match
---
simple_stmt [8131,8210]
simple_stmt [8131,8210]
===
match
---
name: super [3639,3644]
name: super [3639,3644]
===
match
---
operator: , [7399,7400]
operator: , [7399,7400]
===
match
---
operator: , [947,948]
operator: , [947,948]
===
match
---
suite [2410,3095]
suite [2410,3095]
===
match
---
trailer [20523,20530]
trailer [20523,20530]
===
match
---
name: extra_dejson [8183,8195]
name: extra_dejson [8183,8195]
===
match
---
name: func [16704,16708]
name: func [16704,16708]
===
match
---
argument [7462,7471]
argument [7462,7471]
===
match
---
decorator [14531,14545]
decorator [14531,14545]
===
match
---
operator: = [14186,14187]
operator: = [14186,14187]
===
match
---
trailer [8874,8884]
trailer [8874,8884]
===
match
---
name: client_info [1335,1346]
name: client_info [1335,1346]
===
match
---
name: IntegerField [6480,6492]
name: IntegerField [6480,6492]
===
match
---
operator: = [9345,9346]
operator: = [9345,9346]
===
match
---
trailer [9806,9811]
trailer [9806,9811]
===
match
---
argument [7417,7444]
argument [7417,7444]
===
match
---
atom_expr [16217,16237]
atom_expr [16217,16237]
===
match
---
atom_expr [15026,15039]
atom_expr [15026,15039]
===
match
---
name: BS3TextFieldWidget [6707,6725]
name: BS3TextFieldWidget [6707,6725]
===
match
---
name: _get_field [13743,13753]
name: _get_field [13743,13753]
===
match
---
name: os [20049,20051]
name: os [19870,19872]
===
match
---
operator: -> [11973,11975]
operator: -> [11973,11975]
===
match
---
name: tempfile [19713,19721]
name: tempfile [19713,19721]
===
match
---
dotted_name [1096,1107]
dotted_name [1096,1107]
===
match
---
fstring_string: --key-file= [20420,20431]
fstring_string: --key-file= [20241,20252]
===
match
---
return_stmt [14509,14525]
return_stmt [14509,14525]
===
match
---
param [10941,10945]
param [10941,10945]
===
match
---
name: widget [7187,7193]
name: widget [7187,7193]
===
match
---
simple_stmt [17967,18044]
simple_stmt [17967,18044]
===
match
---
name: self [10941,10945]
name: self [10941,10945]
===
match
---
name: Exception [3147,3156]
name: Exception [3147,3156]
===
match
---
trailer [11303,11318]
trailer [11303,11318]
===
match
---
atom [2941,2977]
atom [2941,2977]
===
match
---
simple_stmt [6144,6171]
simple_stmt [6144,6171]
===
match
---
atom_expr [7924,7937]
atom_expr [7924,7937]
===
match
---
name: inner_wrapper [15834,15847]
name: inner_wrapper [15834,15847]
===
match
---
simple_stmt [10238,10510]
simple_stmt [10238,10510]
===
match
---
name: isinstance [3331,3341]
name: isinstance [3331,3341]
===
match
---
operator: , [11402,11403]
operator: , [11402,11403]
===
match
---
simple_stmt [18346,18432]
simple_stmt [18346,18432]
===
match
---
name: self [9922,9926]
name: self [9922,9926]
===
match
---
name: ExitStack [19545,19554]
name: ExitStack [19545,19554]
===
match
---
param [12223,12227]
param [12223,12227]
===
match
---
simple_stmt [6460,6521]
simple_stmt [6460,6521]
===
match
---
atom_expr [3491,3518]
atom_expr [3491,3518]
===
match
---
name: conf_file [18747,18756]
name: conf_file [18747,18756]
===
match
---
expr_stmt [11269,11342]
expr_stmt [11269,11342]
===
match
---
name: DEBUG [14370,14375]
name: DEBUG [14370,14375]
===
match
---
name: _get_scopes [1832,1843]
name: _get_scopes [1832,1843]
===
match
---
name: Any [1019,1022]
name: Any [1019,1022]
===
match
---
name: credentials [9976,9987]
name: credentials [9976,9987]
===
match
---
trailer [8413,8418]
trailer [8413,8418]
===
match
---
annassign [8242,8296]
annassign [8242,8296]
===
match
---
name: args [15871,15875]
name: args [15871,15875]
===
match
---
name: retry [14464,14469]
name: retry [14464,14469]
===
match
---
name: get_connection_form_widgets [6198,6225]
name: get_connection_form_widgets [6198,6225]
===
match
---
operator: = [14838,14839]
operator: = [14838,14839]
===
match
---
name: kwargs [14428,14434]
name: kwargs [14428,14434]
===
match
---
trailer [3389,3394]
trailer [3389,3394]
===
match
---
atom_expr [16275,16295]
atom_expr [16275,16295]
===
match
---
name: chunk_size [21827,21837]
name: chunk_size [21827,21837]
===
match
---
name: retry [15201,15206]
name: retry [15201,15206]
===
match
---
name: oauth2_client [10876,10889]
name: oauth2_client [10876,10889]
===
match
---
name: delegates [9470,9479]
name: delegates [9470,9479]
===
match
---
operator: , [21039,21040]
operator: , [21039,21040]
===
match
---
atom_expr [14218,14244]
atom_expr [14218,14244]
===
match
---
name: AirflowException [12702,12718]
name: AirflowException [12702,12718]
===
match
---
with_stmt [18559,18806]
with_stmt [18559,18806]
===
match
---
param [15848,15869]
param [15848,15869]
===
match
---
simple_stmt [2988,3077]
simple_stmt [2988,3077]
===
match
---
operator: { [7619,7620]
operator: { [7619,7620]
===
match
---
name: IntegerField [7287,7299]
name: IntegerField [7287,7299]
===
match
---
name: key_path [9264,9272]
name: key_path [9264,9272]
===
match
---
name: extras [11845,11851]
name: extras [11845,11851]
===
match
---
trailer [3421,3426]
trailer [3421,3426]
===
match
---
name: credentials_path [20793,20809]
name: credentials_path [20793,20809]
===
match
---
name: self [12976,12980]
name: self [12976,12980]
===
match
---
operator: @ [12946,12947]
operator: @ [12946,12947]
===
match
---
name: _get_credentials_and_project_id [9927,9958]
name: _get_credentials_and_project_id [9927,9958]
===
match
---
name: cache_discovery [10838,10853]
name: cache_discovery [10838,10853]
===
match
---
name: airflow [1761,1768]
name: airflow [1761,1768]
===
match
---
name: creds_file [20873,20883]
name: creds_file [20873,20883]
===
match
---
trailer [17997,18019]
trailer [17997,18019]
===
match
---
name: exception [3380,3389]
name: exception [3380,3389]
===
match
---
operator: , [1022,1023]
operator: , [1022,1023]
===
match
---
operator: -> [21844,21846]
operator: -> [21844,21846]
===
match
---
atom_expr [12842,12859]
atom_expr [12842,12859]
===
match
---
name: patch_environ [18719,18732]
name: patch_environ [18719,18732]
===
match
---
trailer [22593,22604]
trailer [22593,22604]
===
match
---
name: hook_name [6144,6153]
name: hook_name [6144,6153]
===
match
---
name: kwargs [17346,17352]
name: kwargs [17346,17352]
===
match
---
name: delegate_to [8056,8067]
name: delegate_to [8056,8067]
===
match
---
param [16704,16711]
param [16704,16711]
===
match
---
name: keyfile_dict [8969,8981]
name: keyfile_dict [8969,8981]
===
match
---
name: Credentials [9824,9835]
name: Credentials [9824,9835]
===
match
---
name: exit_stack [19560,19570]
name: exit_stack [19560,19570]
===
match
---
operator: @ [11938,11939]
operator: @ [11938,11939]
===
match
---
trailer [13753,13768]
trailer [13753,13768]
===
match
---
param [7840,7874]
param [7840,7874]
===
match
---
operator: = [1983,1984]
operator: = [1983,1984]
===
match
---
operator: , [7667,7668]
operator: , [7667,7668]
===
match
---
tfpdef [2388,2408]
tfpdef [2388,2408]
===
match
---
return_stmt [13458,13476]
return_stmt [13458,13476]
===
match
---
decorated [14531,15264]
decorated [14531,15264]
===
match
---
yield_expr [18505,18519]
yield_expr [18505,18519]
===
match
---
trailer [7157,7185]
trailer [7157,7185]
===
match
---
operator: ** [15214,15216]
operator: ** [15214,15216]
===
match
---
funcdef [7521,7748]
funcdef [7521,7748]
===
match
---
name: lazy_gettext [6988,7000]
name: lazy_gettext [6988,7000]
===
match
---
atom_expr [7194,7214]
atom_expr [7194,7214]
===
match
---
operator: , [1622,1623]
operator: , [1622,1623]
===
match
---
name: kwargs [16143,16149]
name: kwargs [16143,16149]
===
match
---
operator: , [21224,21225]
operator: , [21224,21225]
===
match
---
trailer [8002,8014]
trailer [8002,8014]
===
match
---
name: exception [2388,2397]
name: exception [2388,2397]
===
match
---
name: errors [3069,3075]
name: errors [3069,3075]
===
match
---
operator: -> [13889,13891]
operator: -> [13889,13891]
===
match
---
name: done [22576,22580]
name: done [22576,22580]
===
match
---
trailer [8418,8430]
trailer [8418,8430]
===
match
---
name: service_account_email [10564,10585]
name: service_account_email [10564,10585]
===
match
---
expr_stmt [16217,16255]
expr_stmt [16217,16255]
===
match
---
operator: = [9712,9713]
operator: = [9712,9713]
===
match
---
name: details [2840,2847]
name: details [2840,2847]
===
match
---
name: _ [9918,9919]
name: _ [9918,9919]
===
match
---
fstring_expr [11786,11789]
fstring_expr [11786,11789]
===
match
---
operator: } [14390,14391]
operator: } [14390,14391]
===
match
---
trailer [16223,16237]
trailer [16223,16237]
===
match
---
name: process_utils [1943,1956]
name: process_utils [1943,1956]
===
match
---
import_from [6460,6520]
import_from [6460,6520]
===
match
---
simple_stmt [8218,8297]
simple_stmt [8218,8297]
===
match
---
testlist_comp [21460,21675]
testlist_comp [21460,21675]
===
match
---
simple_stmt [9641,9680]
simple_stmt [9641,9680]
===
match
---
name: AirflowException [16319,16335]
name: AirflowException [16319,16335]
===
match
---
dotted_name [1310,1346]
dotted_name [1310,1346]
===
match
---
simple_stmt [12507,12516]
simple_stmt [12507,12516]
===
match
---
trailer [20442,20455]
trailer [20263,20276]
===
match
---
funcdef [14788,15238]
funcdef [14788,15238]
===
match
---
name: AuthorizedHttp [10971,10985]
name: AuthorizedHttp [10971,10985]
===
match
---
name: log [1979,1982]
name: log [1979,1982]
===
match
---
simple_stmt [16584,16619]
simple_stmt [16584,16619]
===
match
---
fstring [12736,12782]
fstring [12736,12782]
===
match
---
operator: = [11180,11181]
operator: = [11180,11181]
===
match
---
name: decoder [9003,9010]
name: decoder [9003,9010]
===
match
---
operator: = [14115,14116]
operator: = [14115,14116]
===
match
---
trailer [19698,19712]
trailer [19698,19712]
===
match
---
string: 'retry' [14209,14216]
string: 'retry' [14209,14216]
===
match
---
name: project_id [11956,11966]
name: project_id [11956,11966]
===
match
---
atom_expr [9220,9490]
atom_expr [9220,9490]
===
match
---
trailer [11147,11164]
trailer [11147,11164]
===
match
---
name: Optional [7853,7861]
name: Optional [7853,7861]
===
match
---
expr_stmt [14100,14391]
expr_stmt [14100,14391]
===
match
---
trailer [14242,14244]
trailer [14242,14244]
===
match
---
operator: , [1268,1269]
operator: , [1268,1269]
===
match
---
name: StringField [7116,7127]
name: StringField [7116,7127]
===
match
---
funcdef [12207,12941]
funcdef [12207,12941]
===
match
---
arglist [15207,15230]
arglist [15207,15230]
===
match
---
name: patch_environ [18449,18462]
name: patch_environ [18449,18462]
===
match
---
trailer [8135,8142]
trailer [8135,8142]
===
match
---
name: _get_credentials [9774,9790]
name: _get_credentials [9774,9790]
===
match
---
funcdef [12960,13477]
funcdef [12960,13477]
===
match
---
arglist [6672,6727]
arglist [6672,6727]
===
match
---
name: MediaIoBaseDownload [22447,22466]
name: MediaIoBaseDownload [22447,22466]
===
match
---
fstring_expr [12841,12860]
fstring_expr [12841,12860]
===
match
---
trailer [10799,10860]
trailer [10799,10860]
===
match
---
string: 'keyfile_dict' [8808,8822]
string: 'keyfile_dict' [8808,8822]
===
match
---
expr_stmt [13371,13449]
expr_stmt [13371,13449]
===
match
---
atom_expr [7380,7398]
atom_expr [7380,7398]
===
match
---
suite [10028,10145]
suite [10028,10145]
===
match
---
operator: , [14360,14361]
operator: , [14360,14361]
===
match
---
operator: , [1287,1288]
operator: , [1287,1288]
===
match
---
string: "client_id" [21055,21066]
string: "client_id" [21055,21066]
===
match
---
return_stmt [12599,12607]
return_stmt [12599,12607]
===
match
---
decorator [15799,15822]
decorator [15799,15822]
===
match
---
import_name [1089,1107]
import_name [1089,1107]
===
match
---
trailer [19613,19652]
trailer [19613,19652]
===
match
---
name: set_user_agent [11210,11224]
name: set_user_agent [11210,11224]
===
match
---
decorator [17392,17408]
decorator [17392,17408]
===
match
---
operator: = [2323,2324]
operator: = [2323,2324]
===
match
---
simple_stmt [14404,14436]
simple_stmt [14404,14436]
===
match
---
argument [7368,7399]
argument [7368,7399]
===
match
---
argument [9460,9479]
argument [9460,9479]
===
match
---
trailer [11844,11851]
trailer [11844,11851]
===
match
---
name: overridden_project_id [9562,9583]
name: overridden_project_id [9562,9583]
===
match
---
simple_stmt [22573,22607]
simple_stmt [22573,22607]
===
match
---
operator: = [14909,14910]
operator: = [14909,14910]
===
match
---
arglist [11225,11259]
arglist [11225,11259]
===
match
---
param [7775,7780]
param [7775,7780]
===
match
---
simple_stmt [8305,8351]
simple_stmt [8305,8351]
===
match
---
atom_expr [6797,6897]
atom_expr [6797,6897]
===
match
---
name: _get_field [12426,12436]
name: _get_field [12426,12436]
===
match
---
name: logging [881,888]
name: logging [881,888]
===
match
---
if_stmt [8558,8668]
if_stmt [8558,8668]
===
match
---
atom_expr [3961,3974]
atom_expr [3961,3974]
===
match
---
arglist [6826,6883]
arglist [6826,6883]
===
match
---
string: """     Some of the calls return 429 (too many requests!) or 409 errors (Conflict)     in case of operation in progress.      * Google Cloud SQL     """ [3171,3323]
string: """     Some of the calls return 429 (too many requests!) or 409 errors (Conflict)     in case of operation in progress.      * Google Cloud SQL     """ [3171,3323]
===
match
---
name: googleapiclient [1480,1495]
name: googleapiclient [1480,1495]
===
match
---
suite [9584,9632]
suite [9584,9632]
===
match
---
expr_stmt [22519,22531]
expr_stmt [22519,22531]
===
match
---
decorated [18915,21742]
decorated [18915,21742]
===
match
---
name: credentials_provider [1798,1818]
name: credentials_provider [1798,1818]
===
match
---
trailer [6838,6854]
trailer [6838,6854]
===
match
---
operator: = [6862,6863]
operator: = [6862,6863]
===
match
---
name: after_log [14347,14356]
name: after_log [14347,14356]
===
match
---
name: http [10816,10820]
name: http [10816,10820]
===
match
---
string: 'Project Id' [6685,6697]
string: 'Project Id' [6685,6697]
===
match
---
operator: , [9446,9447]
operator: , [9446,9447]
===
match
---
name: BS3PasswordFieldWidget [7025,7047]
name: BS3PasswordFieldWidget [7025,7047]
===
match
---
string: """         A decorator that provides a mechanism to repeat requests in response to         operation in progress (HTTP 409)         limit.         """ [14627,14778]
string: """         A decorator that provides a mechanism to repeat requests in response to         operation in progress (HTTP 409)         limit.         """ [14627,14778]
===
match
---
fstring_string: extra__google_cloud_platform__ [11756,11786]
fstring_string: extra__google_cloud_platform__ [11756,11786]
===
match
---
name: exception [2930,2939]
name: exception [2930,2939]
===
match
---
atom_expr [21248,21278]
atom_expr [21248,21278]
===
match
---
name: long_f [11745,11751]
name: long_f [11745,11751]
===
match
---
simple_stmt [16217,16256]
simple_stmt [16217,16256]
===
match
---
param [11390,11395]
param [11390,11395]
===
match
---
trailer [9163,9183]
trailer [9163,9183]
===
match
---
operator: , [7946,7947]
operator: , [7946,7947]
===
match
---
operator: = [7024,7025]
operator: = [7024,7025]
===
match
---
simple_stmt [14823,15121]
simple_stmt [14823,15121]
===
match
---
trailer [20792,20810]
trailer [20792,20810]
===
match
---
simple_stmt [19668,19744]
simple_stmt [19668,19744]
===
match
---
expr_stmt [2307,2357]
expr_stmt [2307,2357]
===
match
---
trailer [15953,16064]
trailer [15953,16064]
===
match
---
atom_expr [3006,3021]
atom_expr [3006,3021]
===
match
---
operator: * [13872,13873]
operator: * [13872,13873]
===
match
---
name: wraps [17167,17172]
name: wraps [17167,17172]
===
match
---
testlist [9741,9764]
testlist [9741,9764]
===
match
---
dotted_name [1929,1956]
dotted_name [1929,1956]
===
match
---
atom_expr [13433,13448]
atom_expr [13433,13448]
===
match
---
name: google [9800,9806]
name: google [9800,9806]
===
match
---
operator: , [19981,19982]
operator: , [20461,20462]
===
match
---
suite [19571,21742]
suite [19571,21742]
===
match
---
trailer [15020,15040]
trailer [15020,15040]
===
match
---
trailer [12127,12159]
trailer [12127,12159]
===
match
---
atom_expr [3868,3920]
atom_expr [3868,3920]
===
match
---
atom_expr [19713,19742]
atom_expr [19713,19742]
===
match
---
expr_stmt [22573,22606]
expr_stmt [22573,22606]
===
match
---
operator: = [8054,8055]
operator: = [8054,8055]
===
match
---
name: reason [2824,2830]
name: reason [2824,2830]
===
match
---
fstring [11754,11790]
fstring [11754,11790]
===
match
---
string: """Retries if there was an exception for exceeding the temporary quote limit.""" [3525,3605]
string: """Retries if there was an exception for exceeding the temporary quote limit.""" [3525,3605]
===
match
---
atom_expr [9159,9183]
atom_expr [9159,9183]
===
match
---
name: project_id [19502,19512]
name: project_id [19502,19512]
===
match
---
trailer [12571,12577]
trailer [12571,12577]
===
match
---
operator: , [9109,9110]
operator: , [9109,9110]
===
match
---
name: creds_content [21041,21054]
name: creds_content [21041,21054]
===
match
---
name: CREDENTIALS [18464,18475]
name: CREDENTIALS [18464,18475]
===
match
---
operator: @ [14531,14532]
operator: @ [14531,14532]
===
match
---
name: _get_credentials_email [10193,10215]
name: _get_credentials_email [10193,10215]
===
match
---
funcdef [3097,3458]
funcdef [3097,3458]
===
match
---
name: strip [12572,12577]
name: strip [12572,12577]
===
match
---
operator: , [14914,14915]
operator: , [14914,14915]
===
match
---
simple_stmt [11918,11933]
simple_stmt [11918,11933]
===
match
---
atom_expr [8165,8181]
atom_expr [8165,8181]
===
match
---
atom_expr [20873,20890]
atom_expr [20873,20890]
===
match
---
name: self [7775,7779]
name: self [7775,7779]
===
match
---
name: credentials [8265,8276]
name: credentials [8265,8276]
===
match
---
trailer [8338,8343]
trailer [8338,8343]
===
match
---
name: impersonation_chain [9164,9183]
name: impersonation_chain [9164,9183]
===
match
---
string: """         Provides a separate gcloud configuration with current credentials.          The gcloud tool allows you to login to Google Cloud only - ``gcloud auth login`` and         for the needs of Application Default Credentials ``gcloud auth application-default login``.         In our case, we want all commands to use only the credentials from ADCm so         we need to configure the credentials in gcloud manually.         """ [18980,19412]
string: """         Provides a separate gcloud configuration with current credentials.          The gcloud tool allows you to login to Google Cloud only - ``gcloud auth login`` and         for the needs of Application Default Credentials ``gcloud auth application-default login``.         In our case, we want all commands to use only the credentials from ADCm so         we need to configure the credentials in gcloud manually.         """ [18980,19412]
===
match
---
argument [15155,15163]
argument [15155,15163]
===
match
---
operator: = [11336,11337]
operator: = [11336,11337]
===
match
---
suite [12586,12608]
suite [12586,12608]
===
match
---
name: bound [3940,3945]
name: bound [3940,3945]
===
match
---
trailer [10136,10138]
trailer [10136,10138]
===
match
---
name: googleapiclient [1563,1578]
name: googleapiclient [1563,1578]
===
match
---
name: check_output [21160,21172]
name: check_output [21160,21172]
===
match
---
atom_expr [15067,15105]
atom_expr [15067,15105]
===
match
---
name: T [14807,14808]
name: T [14807,14808]
===
match
---
trailer [9002,9010]
trailer [9002,9010]
===
match
---
name: tempfile [906,914]
name: tempfile [906,914]
===
match
---
name: retry_if_exception [3729,3747]
name: retry_if_exception [3729,3747]
===
match
---
trailer [15206,15231]
trailer [15206,15231]
===
match
---
suite [20060,20499]
suite [19881,20320]
===
match
---
string: "gcloud" [21199,21207]
string: "gcloud" [21199,21207]
===
match
---
trailer [7987,7989]
trailer [7987,7989]
===
match
---
atom_expr [8076,8100]
atom_expr [8076,8100]
===
match
---
name: Dict [8870,8874]
name: Dict [8870,8874]
===
match
---
name: long_f [11830,11836]
name: long_f [11830,11836]
===
match
---
simple_stmt [12170,12188]
simple_stmt [12170,12188]
===
match
---
name: self [16596,16600]
name: self [16596,16600]
===
match
---
return_stmt [2813,2910]
return_stmt [2813,2910]
===
match
---
trailer [18756,18761]
trailer [18756,18761]
===
match
---
suite [11905,11933]
suite [11905,11933]
===
match
---
name: _cached_project_id [8649,8667]
name: _cached_project_id [8649,8667]
===
match
---
trailer [14425,14435]
trailer [14425,14435]
===
match
---
name: Union [1076,1081]
name: Union [1076,1081]
===
match
---
return_stmt [16584,16618]
return_stmt [16584,16618]
===
match
---
tfpdef [17199,17219]
tfpdef [17199,17219]
===
match
---
trailer [7127,7228]
trailer [7127,7228]
===
match
---
suite [10229,10921]
suite [10229,10921]
===
match
---
dotted_name [1721,1739]
dotted_name [1721,1739]
===
match
---
name: Sequence [7924,7932]
name: Sequence [7924,7932]
===
match
---
parameters [16703,16712]
parameters [16703,16712]
===
match
---
atom_expr [1985,2012]
atom_expr [1985,2012]
===
match
---
decorator [10150,10185]
decorator [10150,10185]
===
match
---
atom_expr [9123,9184]
atom_expr [9123,9184]
===
match
---
testlist_comp [2942,2976]
testlist_comp [2942,2976]
===
match
---
name: wrapper [17378,17385]
name: wrapper [17378,17385]
===
match
---
string: "extra__google_cloud_platform__key_path" [6755,6795]
string: "extra__google_cloud_platform__key_path" [6755,6795]
===
match
---
name: Callable [1024,1032]
name: Callable [1024,1032]
===
match
---
name: json [20862,20866]
name: json [20862,20866]
===
match
---
simple_stmt [19502,19531]
simple_stmt [19502,19531]
===
match
---
operator: -> [11425,11427]
operator: -> [11425,11427]
===
match
---
name: _authorize [10747,10757]
name: _authorize [10747,10757]
===
match
---
trailer [19766,19780]
trailer [19766,19780]
===
match
---
name: staticmethod [15270,15282]
name: staticmethod [15270,15282]
===
match
---
trailer [2847,2849]
trailer [2847,2849]
===
match
---
name: fun [14072,14075]
name: fun [14072,14075]
===
match
---
string: 'wait' [14858,14864]
string: 'wait' [14858,14864]
===
match
---
trailer [19450,19491]
trailer [19450,19491]
===
match
---
trailer [14369,14375]
trailer [14369,14375]
===
match
---
simple_stmt [18680,18698]
simple_stmt [18680,18698]
===
match
---
suite [6246,7498]
suite [6246,7498]
===
match
---
name: self [15848,15852]
name: self [15848,15852]
===
match
---
strings [16357,16553]
strings [16357,16553]
===
match
---
name: google [1310,1316]
name: google [1310,1316]
===
match
---
simple_stmt [8611,8668]
simple_stmt [8611,8668]
===
match
---
string: "keyword project_id parameter or as project_id extra " [16420,16474]
string: "keyword project_id parameter or as project_id extra " [16420,16474]
===
match
---
name: field_value [12407,12418]
name: field_value [12407,12418]
===
match
---
decorated [15269,16649]
decorated [15269,16649]
===
match
---
decorated [10150,10921]
decorated [10150,10921]
===
match
---
suite [17238,17354]
suite [17238,17354]
===
match
---
name: google [1096,1102]
name: google [1096,1102]
===
match
---
name: gcp_conn_id [8017,8028]
name: gcp_conn_id [8017,8028]
===
match
---
operator: , [7688,7689]
operator: , [7688,7689]
===
match
---
tfpdef [15848,15868]
tfpdef [15848,15868]
===
match
---
operator: -> [15347,15349]
operator: -> [15347,15349]
===
match
---
suite [18329,18432]
suite [18329,18432]
===
match
---
fstring_start: f" [12881,12883]
fstring_start: f" [12881,12883]
===
match
---
return_stmt [10686,10714]
return_stmt [10686,10714]
===
match
---
atom_expr [14601,14617]
atom_expr [14601,14617]
===
match
---
argument [14183,14190]
argument [14183,14190]
===
match
---
simple_stmt [6581,7498]
simple_stmt [6581,7498]
===
match
---
name: http_authorized [10821,10836]
name: http_authorized [10821,10836]
===
match
---
trailer [6725,6727]
trailer [6725,6727]
===
match
---
name: T [17375,17376]
name: T [17375,17376]
===
match
---
fstring [12799,12864]
fstring [12799,12864]
===
match
---
argument [14892,14904]
argument [14892,14904]
===
match
---
name: impersonation_chain [8081,8100]
name: impersonation_chain [8081,8100]
===
match
---
import_from [1475,1512]
import_from [1475,1512]
===
match
---
name: before_log [15010,15020]
name: before_log [15010,15020]
===
match
---
name: keyfile_dict_json [8938,8955]
name: keyfile_dict_json [8938,8955]
===
match
---
return_stmt [3082,3094]
return_stmt [3082,3094]
===
match
---
name: credentials_path [20531,20547]
name: credentials_path [20531,20547]
===
match
---
operator: , [13761,13762]
operator: , [13761,13762]
===
match
---
name: key_path [18278,18286]
name: key_path [18278,18286]
===
match
---
name: self [10532,10536]
name: self [10532,10536]
===
match
---
name: Exception [2399,2408]
name: Exception [2399,2408]
===
match
---
name: field_value [12474,12485]
name: field_value [12474,12485]
===
match
---
operator: ** [15155,15157]
operator: ** [15155,15157]
===
match
---
atom_expr [13808,13832]
atom_expr [13808,13832]
===
match
---
name: airflow [1645,1652]
name: airflow [1645,1652]
===
match
---
decorated [7503,7748]
decorated [7503,7748]
===
match
---
name: keyfile_dict [17967,17979]
name: keyfile_dict [17967,17979]
===
match
---
fstring_start: f" [20418,20420]
fstring_start: f" [20239,20241]
===
match
---
trailer [21261,21278]
trailer [21261,21278]
===
match
---
operator: , [7706,7707]
operator: , [7706,7707]
===
match
---
name: RT [3956,3958]
name: RT [3956,3958]
===
match
---
name: str [6236,6239]
name: str [6236,6239]
===
match
---
testlist_comp [20300,20458]
testlist_comp [20121,20279]
===
match
---
name: execute [10902,10909]
name: execute [10902,10909]
===
match
---
name: AirflowException [18100,18116]
name: AirflowException [18100,18116]
===
match
---
funcdef [21765,22635]
funcdef [21765,22635]
===
match
---
trailer [10970,10985]
trailer [10970,10985]
===
match
---
return_stmt [14448,14499]
return_stmt [14448,14499]
===
match
---
operator: } [19835,19836]
operator: } [19835,19836]
===
match
---
trailer [18572,18591]
trailer [18572,18591]
===
match
---
trailer [15009,15020]
trailer [15009,15020]
===
match
---
atom_expr [9800,9835]
atom_expr [9800,9835]
===
match
---
import_from [1668,1715]
import_from [1668,1715]
===
match
---
name: default_kwargs [15133,15147]
name: default_kwargs [15133,15147]
===
match
---
return_stmt [11865,11891]
return_stmt [11865,11891]
===
match
---
name: authed_http [11269,11280]
name: authed_http [11269,11280]
===
match
---
operator: -> [12982,12984]
operator: -> [12982,12984]
===
match
---
name: error [3006,3011]
name: error [3006,3011]
===
match
---
name: str [8875,8878]
name: str [8875,8878]
===
match
---
string: '.p12' [18321,18327]
string: '.p12' [18321,18327]
===
match
---
name: min [7392,7395]
name: min [7392,7395]
===
match
---
name: property [12947,12955]
name: property [12947,12955]
===
match
---
atom_expr [19688,19743]
atom_expr [19688,19743]
===
match
---
string: "auth" [20334,20340]
string: "auth" [20155,20161]
===
match
---
import_as_names [6480,6520]
import_as_names [6480,6520]
===
match
---
expr_stmt [8938,8982]
expr_stmt [8938,8982]
===
match
---
simple_stmt [12107,12162]
simple_stmt [12107,12162]
===
match
---
if_stmt [15906,16065]
if_stmt [15906,16065]
===
match
---
param [3853,3857]
param [3853,3857]
===
match
---
name: functools [852,861]
name: functools [852,861]
===
match
---
simple_stmt [20846,20892]
simple_stmt [20846,20892]
===
match
---
simple_stmt [19756,19839]
simple_stmt [19756,19839]
===
match
---
trailer [14891,14914]
trailer [14891,14914]
===
match
---
name: Sequence [13516,13524]
name: Sequence [13516,13524]
===
match
---
string: """         Decorator that provides fallback for Google Cloud project id. If         the project is None it will be replaced with the project_id from the         service account the Hook is authenticated with. Project id can be specified         either via project_id kwarg or via first parameter in positional args.          :param func: function to wrap         :return: result of the function call         """ [15377,15789]
string: """         Decorator that provides fallback for Google Cloud project id. If         the project is None it will be replaced with the project_id from the         service account the Hook is authenticated with. Project id can be specified         either via project_id kwarg or via first parameter in positional args.          :param func: function to wrap         :return: result of the function call         """ [15377,15789]
===
match
---
operator: , [8878,8879]
operator: , [8878,8879]
===
match
---
trailer [2902,2909]
trailer [2902,2909]
===
match
---
decorator [12946,12956]
decorator [12946,12956]
===
match
---
trailer [3341,3363]
trailer [3341,3363]
===
match
---
operator: , [15212,15213]
operator: , [15212,15213]
===
match
---
name: AirflowException [18352,18368]
name: AirflowException [18352,18368]
===
match
---
operator: = [10853,10854]
operator: = [10853,10854]
===
match
---
expr_stmt [6144,6170]
expr_stmt [6144,6170]
===
match
---
name: ExitStack [938,947]
name: ExitStack [938,947]
===
match
---
trailer [18591,18603]
trailer [18591,18603]
===
match
---
simple_stmt [3923,3956]
simple_stmt [3923,3956]
===
match
---
operator: = [3925,3926]
operator: = [3925,3926]
===
match
---
suite [16718,17387]
suite [16718,17387]
===
match
---
trailer [2998,3076]
trailer [2998,3076]
===
match
---
atom_expr [20788,20810]
atom_expr [20788,20810]
===
match
---
operator: = [22581,22582]
operator: = [22581,22582]
===
match
---
arglist [3935,3954]
arglist [3935,3954]
===
match
---
suite [9836,9988]
suite [9836,9988]
===
match
---
name: operation_in_progress_retry [14553,14580]
name: operation_in_progress_retry [14553,14580]
===
match
---
name: oauth2_client [10768,10781]
name: oauth2_client [10768,10781]
===
match
---
string: "The project id must be passed either as " [16357,16399]
string: "The project id must be passed either as " [16357,16399]
===
match
---
argument [2999,3075]
argument [2999,3075]
===
match
---
and_test [18055,18080]
and_test [18055,18080]
===
match
---
argument [9295,9325]
argument [9295,9325]
===
match
---
atom_expr [7971,7989]
atom_expr [7971,7989]
===
match
---
name: cast [15184,15188]
name: cast [15184,15188]
===
match
---
argument [14470,14475]
argument [14470,14475]
===
match
---
string: """         Return client information used to generate a user-agent for API calls.          It allows for better errors tracking.          This object is only used by the google-cloud-* libraries that are built specifically for         the Google Cloud. It is not supported by The Google APIs Python Client that use Discovery         based APIs.         """ [13005,13362]
string: """         Return client information used to generate a user-agent for API calls.          It allows for better errors tracking.          This object is only used by the google-cloud-* libraries that are built specifically for         the Google Cloud. It is not supported by The Google APIs Python Client that use Discovery         based APIs.         """ [13005,13362]
===
match
---
string: 'project_id' [16127,16139]
string: 'project_id' [16127,16139]
===
match
---
operator: * [16602,16603]
operator: * [16602,16603]
===
match
---
argument [9371,9399]
argument [9371,9399]
===
match
---
name: BS3TextFieldWidget [7424,7442]
name: BS3TextFieldWidget [7424,7442]
===
match
---
trailer [19554,19556]
trailer [19554,19556]
===
match
---
simple_stmt [1716,1756]
simple_stmt [1716,1756]
===
match
---
operator: = [22524,22525]
operator: = [22524,22525]
===
match
---
operator: * [14470,14471]
operator: * [14470,14471]
===
match
---
name: key_path [18477,18485]
name: key_path [18477,18485]
===
match
---
trailer [14356,14376]
trailer [14356,14376]
===
match
---
trailer [10901,10909]
trailer [10901,10909]
===
match
---
name: airflow [1929,1936]
name: airflow [1929,1936]
===
match
---
simple_stmt [3171,3324]
simple_stmt [3171,3324]
===
match
---
and_test [11802,11851]
and_test [11802,11851]
===
match
---
operator: , [11394,11395]
operator: , [11394,11395]
===
match
---
fstring_end: ' [11789,11790]
fstring_end: ' [11789,11790]
===
match
---
simple_stmt [7971,7990]
simple_stmt [7971,7990]
===
match
---
dotted_name [1518,1540]
dotted_name [1518,1540]
===
match
---
name: __init__ [3876,3884]
name: __init__ [3876,3884]
===
match
---
name: credentials [10596,10607]
name: credentials [10596,10607]
===
match
---
simple_stmt [889,899]
simple_stmt [889,899]
===
match
---
name: contextmanager [18916,18930]
name: contextmanager [18916,18930]
===
match
---
name: _get_credentials_and_project_id [8360,8391]
name: _get_credentials_and_project_id [8360,8391]
===
match
---
trailer [3019,3021]
trailer [3019,3021]
===
match
---
argument [14426,14434]
argument [14426,14434]
===
match
---
atom_expr [8131,8142]
atom_expr [8131,8142]
===
match
---
name: contextlib [920,930]
name: contextlib [920,930]
===
match
---
atom_expr [11802,11825]
atom_expr [11802,11825]
===
match
---
operator: = [10178,10179]
operator: = [10178,10179]
===
match
---
param [3136,3156]
param [3136,3156]
===
match
---
trailer [18368,18431]
trailer [18368,18431]
===
match
---
name: self [17331,17335]
name: self [17331,17335]
===
match
---
operator: -> [7550,7552]
operator: -> [7550,7552]
===
match
---
operator: , [9357,9358]
operator: , [9357,9358]
===
match
---
name: DEBUG [15034,15039]
name: DEBUG [15034,15039]
===
match
---
name: exceptions [1681,1691]
name: exceptions [1681,1691]
===
match
---
atom_expr [18747,18761]
atom_expr [18747,18761]
===
match
---
operator: , [14613,14614]
operator: , [14613,14614]
===
match
---
name: utils [1937,1942]
name: utils [1937,1942]
===
match
---
operator: + [11242,11243]
operator: + [11242,11243]
===
match
---
operator: ... [15359,15362]
operator: ... [15359,15362]
===
match
---
parameters [14580,14597]
parameters [14580,14597]
===
match
---
operator: , [9205,9206]
operator: , [9205,9206]
===
match
---
import_name [1204,1219]
import_name [1204,1219]
===
match
---
name: tenacity [15001,15009]
name: tenacity [15001,15009]
===
match
---
operator: , [9752,9753]
operator: , [9752,9753]
===
match
---
name: creds_content [20846,20859]
name: creds_content [20846,20859]
===
match
---
operator: = [8101,8102]
operator: = [8101,8102]
===
match
---
trailer [7912,7939]
trailer [7912,7939]
===
match
---
name: oauth2 [1153,1159]
name: oauth2 [1153,1159]
===
match
---
operator: @ [15799,15800]
operator: @ [15799,15800]
===
match
---
name: int [12232,12235]
name: int [12232,12235]
===
match
---
atom [7650,7706]
atom [7650,7706]
===
match
---
name: before_log [14281,14291]
name: before_log [14281,14291]
===
match
---
name: Credentials [8431,8442]
name: Credentials [8431,8442]
===
match
---
if_stmt [16268,16572]
if_stmt [16268,16572]
===
match
---
operator: , [11330,11331]
operator: , [11330,11331]
===
match
---
operator: , [14244,14245]
operator: , [14244,14245]
===
match
---
string: "gcloud" [21460,21468]
string: "gcloud" [21460,21468]
===
match
---
trailer [8796,8807]
trailer [8796,8807]
===
match
---
trailer [15147,15154]
trailer [15147,15154]
===
match
---
string: "refresh_token" [21658,21673]
string: "refresh_token" [21658,21673]
===
match
---
name: key_path [18303,18311]
name: key_path [18303,18311]
===
match
---
name: wtforms [6465,6472]
name: wtforms [6465,6472]
===
match
---
name: flask_appbuilder [6327,6343]
name: flask_appbuilder [6327,6343]
===
match
---
atom_expr [6707,6727]
atom_expr [6707,6727]
===
match
---
name: gcp_conn_id [7789,7800]
name: gcp_conn_id [7789,7800]
===
insert-tree
---
simple_stmt [788,845]
    string: """This module contains a Google Cloud API base hook.""" [788,844]
to
file_input [788,22635]
at 0
===
insert-node
---
name: GoogleBaseHook [3983,3997]
to
classdef [3977,22635]
at 0
===
insert-node
---
name: BaseHook [3998,4006]
to
classdef [3977,22635]
at 1
===
insert-tree
---
simple_stmt [4013,6017]
    string: """     A base hook for Google cloud-related hooks. Google cloud has a shared REST     API client that is built in the same way no matter which service you use.     This class helps construct and authorize the credentials needed to then     call googleapiclient.discovery.build() to actually discover and build a client     for a Google cloud service.      The class also contains some miscellaneous helper functions.      All hook derived from this base hook use the 'Google Cloud' connection     type. Three ways of authentication are supported:      Default credentials: Only the 'Project Id' is required. You'll need to     have set up default credentials, such as by the     ``GOOGLE_APPLICATION_DEFAULT`` environment variable or from the metadata     server on Google Compute Engine.      JSON key file: Specify 'Project Id', 'Keyfile Path' and 'Scope'.      Legacy P12 key files are not supported.      JSON data provided in the UI: Specify 'Keyfile JSON'.      :param gcp_conn_id: The connection ID to use when fetching connection info.     :type gcp_conn_id: str     :param delegate_to: The account to impersonate using domain-wide delegation of authority,         if any. For this to work, the service account making the request must have         domain-wide delegation enabled.     :type delegate_to: str     :param impersonation_chain: Optional service account to impersonate using short-term         credentials, or chained list of accounts required to get the access_token         of the last account in the list, which will be impersonated in the request.         If set as a string, the account must grant the originating account         the Service Account Token Creator IAM role.         If set as a sequence, the identities from the list must grant         Service Account Token Creator IAM role to the directly preceding identity, with first         account from the list granting this role to the originating account.     :type impersonation_chain: Union[str, Sequence[str]]     """ [4013,6016]
to
suite [4008,22635]
at 0
===
insert-node
---
if_stmt [19852,20320]
to
suite [19571,21742]
at 3
===
move-tree
---
comparison [20034,20059]
    name: CREDENTIALS [20034,20045]
    atom_expr [20049,20059]
        name: os [20049,20051]
        trailer [20051,20059]
            name: environ [20052,20059]
to
if_stmt [19852,20320]
at 0
===
move-tree
---
suite [20060,20499]
    simple_stmt [20240,20499]
        atom_expr [20240,20498]
            name: check_output [20240,20252]
            trailer [20252,20498]
                atom [20274,20480]
                    testlist_comp [20300,20458]
                        string: "gcloud" [20300,20308]
                        operator: , [20308,20309]
                        string: "auth" [20334,20340]
                        operator: , [20340,20341]
                        string: "activate-service-account" [20366,20392]
                        operator: , [20392,20393]
                        fstring [20418,20457]
                            fstring_start: f" [20418,20420]
                            fstring_string: --key-file= [20420,20431]
                            fstring_expr [20431,20456]
                                operator: { [20431,20432]
                                atom_expr [20432,20455]
                                    name: os [20432,20434]
                                    trailer [20434,20442]
                                        name: environ [20435,20442]
                                    trailer [20442,20455]
                                        name: CREDENTIALS [20443,20454]
                                operator: } [20455,20456]
                            fstring_end: " [20456,20457]
                        operator: , [20457,20458]
to
if_stmt [19852,20320]
at 1
===
insert-node
---
name: project_id [20335,20345]
to
if_stmt [20031,21724]
at 0
===
move-tree
---
suite [19866,20019]
    simple_stmt [19949,20019]
        atom_expr [19949,20018]
            name: check_output [19949,19961]
            trailer [19961,20018]
                atom [19962,20017]
                    testlist_comp [19963,20016]
                        string: "gcloud" [19963,19971]
                        operator: , [19971,19972]
                        string: "config" [19973,19981]
                        operator: , [19981,19982]
                        string: "set" [19983,19988]
                        operator: , [19988,19989]
                        string: "core/project" [19990,20004]
                        operator: , [20004,20005]
                        name: project_id [20006,20016]
to
if_stmt [20031,21724]
at 1
===
delete-tree
---
simple_stmt [788,845]
    string: """This module contains a Google Cloud API base hook.""" [788,844]
===
delete-node
---
name: GoogleBaseHook [3983,3997]
===
===
delete-node
---
name: BaseHook [3998,4006]
===
===
delete-tree
---
simple_stmt [4013,6017]
    string: """     A base hook for Google cloud-related hooks. Google cloud has a shared REST     API client that is built in the same way no matter which service you use.     This class helps construct and authorize the credentials needed to then     call googleapiclient.discovery.build() to actually discover and build a client     for a Google cloud service.      The class also contains some miscellaneous helper functions.      All hook derived from this base hook use the 'Google Cloud' connection     type. Three ways of authentication are supported:      Default credentials: Only the 'Project Id' is required. You'll need to     have set up default credentials, such as by the     ``GOOGLE_APPLICATION_DEFAULT`` environment variable or from the metadata     server on Google Compute Engine.      JSON key file: Specify 'Project Id', 'Keyfile Path' and 'Scope'.      Legacy P12 key files are not supported.      JSON data provided in the UI: Specify 'Keyfile JSON'.      :param gcp_conn_id: The connection ID to use when fetching connection info.     :type gcp_conn_id: str     :param delegate_to: The account to impersonate using domain-wide delegation of authority,         if any. For this to work, the service account making the request must have         domain-wide delegation enabled.     :type delegate_to: str     :param impersonation_chain: Optional service account to impersonate using short-term         credentials, or chained list of accounts required to get the access_token         of the last account in the list, which will be impersonated in the request.         If set as a string, the account must grant the originating account         the Service Account Token Creator IAM role.         If set as a sequence, the identities from the list must grant         Service Account Token Creator IAM role to the directly preceding identity, with first         account from the list granting this role to the originating account.     :type impersonation_chain: Union[str, Sequence[str]]     """ [4013,6016]
===
delete-node
---
if_stmt [19852,20019]
===
