===
match
---
trailer [3301,3305]
trailer [3366,3370]
===
match
---
not_test [3528,3554]
not_test [3593,3619]
===
match
---
name: sys [830,833]
name: sys [815,818]
===
match
---
atom_expr [3654,3696]
atom_expr [3719,3761]
===
match
---
if_stmt [3814,3916]
if_stmt [3879,3981]
===
match
---
simple_stmt [5461,5466]
simple_stmt [5526,5531]
===
match
---
param [1296,1308]
param [1409,1421]
===
match
---
expr_stmt [4597,4620]
expr_stmt [4662,4685]
===
match
---
simple_stmt [834,885]
simple_stmt [819,881]
===
match
---
atom_expr [3674,3695]
atom_expr [3739,3760]
===
match
---
name: __module__ [1636,1646]
name: __module__ [1628,1638]
===
match
---
name: property [2921,2929]
name: property [2986,2994]
===
match
---
name: message [3532,3539]
name: message [3597,3604]
===
match
---
name: stream [4793,4799]
name: stream [4858,4864]
===
match
---
decorator [2042,2062]
decorator [2107,2127]
===
match
---
name: __class__ [1626,1635]
name: __class__ [1618,1627]
===
match
---
name: message [3217,3224]
name: message [3282,3289]
===
match
---
name: self [3872,3876]
name: self [3937,3941]
===
match
---
parameters [2090,2123]
parameters [2155,2188]
===
match
---
comparison [4632,4650]
comparison [4697,4715]
===
match
---
operator: = [5127,5128]
operator: = [5192,5193]
===
match
---
param [3742,3746]
param [3807,3811]
===
match
---
name: close [2767,2772]
name: close [2832,2837]
===
match
---
name: _logger [5567,5574]
name: _logger [5632,5639]
===
match
---
funcdef [2519,2758]
funcdef [2584,2823]
===
match
---
name: logger [3295,3301]
name: logger [3360,3366]
===
match
---
trailer [2688,2695]
trailer [2753,2760]
===
match
---
if_stmt [5474,5582]
if_stmt [5539,5647]
===
match
---
name: __class__ [1660,1669]
name: __class__ [1652,1661]
===
match
---
operator: , [1735,1736]
operator: , [1800,1801]
===
match
---
trailer [3622,3630]
trailer [3687,3695]
===
match
---
dotted_name [2043,2061]
dotted_name [2108,2126]
===
match
---
simple_stmt [4664,4689]
simple_stmt [4729,4754]
===
match
---
simple_stmt [3235,3282]
simple_stmt [3300,3347]
===
match
---
atom_expr [3872,3884]
atom_expr [3937,3949]
===
match
---
atom_expr [3898,3910]
atom_expr [3963,3975]
===
match
---
name: context [1337,1344]
name: context [1450,1457]
===
match
---
trailer [3310,3316]
trailer [3375,3381]
===
match
---
operator: , [2095,2096]
operator: , [2160,2161]
===
match
---
param [2546,2551]
param [2611,2616]
===
match
---
string: """Return log name""" [2015,2036]
string: """Return log name""" [2080,2101]
===
match
---
operator: += [3581,3583]
operator: += [3646,3648]
===
match
---
trailer [4860,4872]
trailer [4925,4937]
===
match
---
name: set_context [4937,4948]
name: set_context [5002,5013]
===
match
---
except_clause [5268,5289]
except_clause [5333,5354]
===
match
---
parameters [3362,3377]
parameters [3427,3442]
===
match
---
string: """     Walks the tree of loggers and tries to set the context for each handler      :param logger: logger     :param value: value to set     """ [4969,5114]
string: """     Walks the tree of loggers and tries to set the context for each handler      :param logger: logger     :param value: value to set     """ [5034,5179]
===
match
---
name: logger [2538,2544]
name: logger [2603,2609]
===
match
---
name: _buffer [3679,3686]
name: _buffer [3744,3751]
===
match
---
name: log [1808,1811]
name: log [1873,1876]
===
match
---
name: try_number [2112,2122]
name: try_number [2177,2187]
===
match
---
atom_expr [1803,1811]
atom_expr [1868,1876]
===
match
---
trailer [3825,3833]
trailer [3890,3898]
===
match
---
simple_stmt [4969,5115]
simple_stmt [5034,5180]
===
match
---
operator: @ [1942,1943]
operator: @ [2007,2008]
===
match
---
expr_stmt [2684,2704]
expr_stmt [2749,2769]
===
match
---
atom_expr [3306,3316]
atom_expr [3371,3381]
===
match
---
atom_expr [1655,1678]
atom_expr [1647,1670]
===
match
---
name: Logger [1382,1388]
name: Logger [1502,1508]
===
match
---
name: self [3363,3367]
name: self [3428,3432]
===
match
---
string: """Return whether handler is able to support external links.""" [2301,2364]
string: """Return whether handler is able to support external links.""" [2366,2429]
===
match
---
name: self [3709,3713]
name: self [3774,3778]
===
match
---
name: encoding [2492,2500]
name: encoding [2557,2565]
===
match
---
string: """Propagate message removing escape codes.""" [3235,3281]
string: """Propagate message removing escape codes.""" [3300,3346]
===
match
---
name: stdout [4924,4930]
name: stdout [4989,4995]
===
match
---
param [4392,4398]
param [4457,4463]
===
match
---
name: property [1352,1360]
name: cached_property [1465,1480]
===
match
---
name: get_external_log_url [2070,2090]
name: get_external_log_url [2135,2155]
===
match
---
name: self [4800,4804]
name: self [4865,4869]
===
match
---
name: _set_context [1324,1336]
name: _set_context [1437,1449]
===
match
---
trailer [4426,4439]
trailer [4491,4504]
===
match
---
funcdef [4373,4770]
funcdef [4438,4835]
===
match
---
suite [4806,4931]
suite [4871,4996]
===
match
---
arglist [3306,3346]
arglist [3371,3411]
===
match
---
name: __init__ [2523,2531]
name: __init__ [2588,2596]
===
match
---
operator: -> [1999,2001]
operator: -> [2064,2066]
===
match
---
name: context [1296,1303]
name: context [1409,1416]
===
match
---
name: stream [4427,4433]
name: stream [4492,4498]
===
match
---
operator: @ [4775,4776]
operator: @ [4840,4841]
===
match
---
name: handler [5229,5236]
name: handler [5294,5301]
===
match
---
funcdef [1277,1346]
funcdef [1390,1459]
===
match
---
name: ANSI_ESCAPE [919,930]
name: ANSI_ESCAPE [997,1008]
===
match
---
name: remove_escape_codes [3318,3337]
name: remove_escape_codes [3383,3402]
===
match
---
import_as_names [854,884]
import_as_names [839,880]
===
match
---
atom_expr [4893,4903]
atom_expr [4958,4968]
===
match
---
if_stmt [3525,3727]
if_stmt [3590,3792]
===
match
---
simple_stmt [2684,2705]
simple_stmt [2749,2770]
===
match
---
parameters [2772,2778]
parameters [2837,2843]
===
match
---
name: self [2278,2282]
name: self [2343,2347]
===
match
---
suite [3938,4101]
suite [4003,4166]
===
match
---
parameters [4948,4963]
parameters [5013,5028]
===
match
---
name: _logger [5119,5126]
name: _logger [5184,5191]
===
match
---
name: logger [5129,5135]
name: logger [5194,5200]
===
match
---
suite [3748,3916]
suite [3813,3981]
===
match
---
name: _logger [5477,5484]
name: _logger [5542,5549]
===
match
---
decorator [2213,2223]
decorator [2278,2288]
===
match
---
trailer [4754,4763]
trailer [4819,4828]
===
match
---
suite [5154,5582]
suite [5219,5647]
===
match
---
suite [5212,5256]
suite [5277,5321]
===
match
---
return_stmt [4913,4930]
return_stmt [4978,4995]
===
match
---
simple_stmt [1791,1822]
simple_stmt [1856,1887]
===
match
---
trailer [3305,3347]
trailer [3370,3412]
===
match
---
return_stmt [1135,1167]
return_stmt [1213,1245]
===
match
---
name: _use_stderr [4602,4613]
name: _use_stderr [4667,4678]
===
match
---
operator: , [2536,2537]
operator: , [2601,2602]
===
match
---
simple_stmt [3174,3187]
simple_stmt [3239,3252]
===
match
---
trailer [935,943]
trailer [1013,1021]
===
match
---
trailer [3678,3686]
trailer [3743,3751]
===
match
---
simple_stmt [3709,3727]
simple_stmt [3774,3792]
===
match
---
trailer [3658,3673]
trailer [3723,3738]
===
match
---
name: _buffer [3826,3833]
name: _buffer [3891,3898]
===
match
---
param [1993,1997]
param [2058,2062]
===
match
---
name: abc [2043,2046]
name: abc [2108,2111]
===
match
---
name: _logger [5146,5153]
name: _logger [5211,5218]
===
match
---
name: self [4664,4668]
name: self [4729,4733]
===
match
---
name: StreamHandler [4128,4141]
name: StreamHandler [4193,4206]
===
match
---
name: self [4386,4390]
name: self [4451,4455]
===
match
---
name: Handler [4747,4754]
name: Handler [4812,4819]
===
match
---
name: log_name [1984,1992]
name: log_name [2049,2057]
===
match
---
operator: += [3631,3633]
operator: += [3696,3698]
===
match
---
parameters [1000,1011]
parameters [1078,1089]
===
match
---
funcdef [2066,2208]
funcdef [2131,2273]
===
match
---
trailer [4923,4930]
trailer [4988,4995]
===
match
---
arglist [1158,1166]
arglist [1236,1244]
===
match
---
name: _logger [5526,5533]
name: _logger [5591,5598]
===
match
---
string: "\n" [3549,3553]
string: "\n" [3614,3618]
===
match
---
simple_stmt [3852,3886]
simple_stmt [3917,3951]
===
match
---
operator: = [3911,3912]
operator: = [3976,3977]
===
match
---
trailer [3856,3871]
trailer [3921,3936]
===
match
---
expr_stmt [5516,5540]
expr_stmt [5581,5605]
===
match
---
param [3217,3224]
param [3282,3289]
===
match
---
suite [1578,1709]
suite [1581,1739]
===
match
---
name: property [1943,1951]
name: property [2008,2016]
===
match
---
atom_expr [3532,3554]
atom_expr [3597,3619]
===
match
---
name: rstrip [3687,3693]
name: rstrip [3752,3758]
===
match
---
parameters [1289,1309]
parameters [1402,1422]
===
match
---
simple_stmt [2434,2487]
simple_stmt [2499,2552]
===
match
---
operator: = [2507,2508]
operator: = [2572,2573]
===
match
---
import_from [834,884]
import_from [819,880]
===
match
---
expr_stmt [3898,3915]
expr_stmt [3963,3980]
===
match
---
operator: , [1811,1812]
operator: , [1876,1877]
===
match
---
name: text [1001,1005]
name: text [1079,1083]
===
match
---
classdef [2407,4101]
classdef [2472,4166]
===
match
---
name: _buffer [2745,2752]
name: _buffer [2810,2817]
===
match
---
param [1001,1010]
param [1079,1088]
===
match
---
suite [2006,2037]
suite [2071,2102]
===
match
---
name: logger [4949,4955]
name: logger [5014,5020]
===
match
---
name: AttributeError [5275,5289]
name: AttributeError [5340,5354]
===
match
---
trailer [4601,4613]
trailer [4666,4678]
===
match
---
name: abstractmethod [1961,1975]
name: abstractmethod [2026,2040]
===
match
---
simple_stmt [3290,3348]
simple_stmt [3355,3413]
===
match
---
operator: , [3367,3368]
operator: , [3432,3433]
===
match
---
param [3369,3376]
param [3434,3441]
===
match
---
operator: = [2753,2754]
operator: = [2818,2819]
===
match
---
name: RedirectStdHandler [4109,4127]
name: RedirectStdHandler [4174,4192]
===
match
---
name: endswith [3540,3548]
name: endswith [3605,3613]
===
match
---
name: _buffer [3573,3580]
name: _buffer [3638,3645]
===
match
---
return_stmt [1692,1708]
return_stmt [1747,1773]
===
match
---
name: self [2091,2095]
name: self [2156,2160]
===
match
---
param [2538,2545]
param [2603,2610]
===
match
---
name: isatty [3925,3931]
name: isatty [3990,3996]
===
match
---
funcdef [4789,4931]
funcdef [4854,4996]
===
match
---
trailer [1336,1345]
trailer [1449,1458]
===
match
---
name: sub [1154,1157]
name: sub [1232,1235]
===
match
---
suite [1851,2365]
suite [1916,2430]
===
match
---
operator: = [4681,4682]
operator: = [4746,4747]
===
match
---
atom_expr [3817,3834]
atom_expr [3882,3899]
===
match
---
suite [3555,3592]
suite [3620,3657]
===
match
---
decorator [2920,2930]
decorator [2985,2995]
===
match
---
name: log [3302,3305]
name: log [3367,3370]
===
match
---
operator: , [1160,1161]
operator: , [1238,1239]
===
match
---
name: __init__ [4377,4385]
name: __init__ [4442,4450]
===
match
---
name: text [1162,1166]
name: text [1240,1244]
===
match
---
name: sys [4920,4923]
name: sys [4985,4988]
===
match
---
parameters [3931,3937]
parameters [3996,4002]
===
match
---
atom_expr [4664,4680]
atom_expr [4729,4745]
===
match
---
comparison [5477,5502]
comparison [5542,5567]
===
match
---
name: _buffer [3714,3721]
name: _buffer [3779,3786]
===
match
---
trailer [3572,3580]
trailer [3637,3645]
===
match
---
name: supports_external_link [2255,2277]
name: supports_external_link [2320,2342]
===
match
---
name: self [2713,2717]
name: self [2778,2782]
===
match
---
operator: @ [2227,2228]
operator: @ [2292,2293]
===
match
---
name: str [4435,4438]
name: str [4500,4503]
===
match
---
name: self [4597,4601]
name: self [4662,4666]
===
match
---
string: """     This class is like a StreamHandler using sys.stderr/stdout, but always uses     whatever sys.stderr/stderr is currently set to rather than the value of     sys.stderr/stdout at handler construction time.     """ [4148,4367]
string: """     This class is like a StreamHandler using sys.stderr/stdout, but always uses     whatever sys.stderr/stderr is currently set to rather than the value of     sys.stderr/stdout at handler construction time.     """ [4213,4432]
===
match
---
suite [5195,5466]
suite [5260,5531]
===
match
---
name: self [3674,3678]
name: self [3739,3743]
===
match
---
name: sys [4893,4896]
name: sys [4958,4961]
===
match
---
operator: @ [2213,2214]
operator: @ [2278,2279]
===
match
---
name: handler [5167,5174]
name: handler [5232,5239]
===
match
---
atom_expr [2740,2752]
atom_expr [2805,2817]
===
match
---
name: level [2546,2551]
name: level [2611,2616]
===
match
---
name: _propagate_log [3196,3210]
name: _propagate_log [3261,3275]
===
match
---
simple_stmt [4088,4101]
simple_stmt [4153,4166]
===
match
---
name: ExternalLoggingMixin [1830,1850]
name: ExternalLoggingMixin [1895,1915]
===
match
---
for_stmt [5163,5466]
for_stmt [5228,5531]
===
match
---
name: _use_stderr [4861,4872]
name: _use_stderr [4926,4937]
===
match
---
funcdef [3732,3916]
funcdef [3797,3981]
===
match
---
simple_stmt [5567,5582]
simple_stmt [5632,5647]
===
match
---
decorators [2213,2247]
decorators [2278,2312]
===
match
---
classdef [1824,2365]
classdef [1889,2430]
===
match
---
trailer [1625,1635]
trailer [1617,1627]
===
match
---
string: r'\x1B[@-_][0-?]*[ -/]*[@-~]' [944,973]
string: r'\x1B[@-_][0-?]*[ -/]*[@-~]' [1022,1051]
===
match
---
operator: > [3835,3836]
operator: > [3900,3901]
===
match
---
name: self [1373,1377]
name: self [1493,1497]
===
match
---
trailer [5236,5248]
trailer [5301,5313]
===
match
---
suite [3839,3916]
suite [3904,3981]
===
match
---
name: self [3852,3856]
name: self [3917,3921]
===
match
---
simple_stmt [5119,5136]
simple_stmt [5184,5201]
===
match
---
name: Handler [854,861]
name: Handler [839,846]
===
match
---
suite [5290,5466]
suite [5355,5531]
===
match
---
name: __init__ [4755,4763]
name: __init__ [4820,4828]
===
match
---
suite [4873,4904]
suite [4938,4969]
===
match
---
operator: @ [1351,1352]
operator: @ [1464,1465]
===
match
---
funcdef [2934,3187]
funcdef [2999,3252]
===
match
---
simple_stmt [3618,3642]
simple_stmt [3683,3707]
===
match
---
suite [5554,5582]
suite [5619,5647]
===
match
---
funcdef [3353,3727]
funcdef [3418,3792]
===
match
---
if_stmt [4853,4904]
if_stmt [4918,4969]
===
match
---
name: self [1699,1703]
name: self [1684,1688]
===
match
---
name: value [4957,4962]
name: value [5022,5027]
===
match
---
name: __init__ [1281,1289]
name: __init__ [1394,1402]
===
match
---
trailer [3820,3834]
trailer [3885,3899]
===
match
---
trailer [3871,3885]
trailer [3936,3950]
===
match
---
name: message [3369,3376]
name: message [3434,3441]
===
match
---
name: handlers [5186,5194]
name: handlers [5251,5259]
===
match
---
name: self [3568,3572]
name: self [3633,3637]
===
match
---
name: logger [2689,2695]
name: logger [2754,2760]
===
match
---
classdef [4103,4931]
classdef [4168,4996]
===
match
---
operator: , [3316,3317]
operator: , [3381,3382]
===
match
---
name: self [1621,1625]
name: self [1613,1617]
===
match
---
trailer [1153,1157]
trailer [1231,1235]
===
match
---
decorated [1942,2037]
decorated [2007,2102]
===
match
---
simple_stmt [1692,1709]
simple_stmt [1684,1713]
===
match
---
simple_stmt [4815,4845]
simple_stmt [4880,4910]
===
match
---
parameters [4799,4805]
parameters [4864,4870]
===
match
---
simple_stmt [2562,2676]
simple_stmt [2627,2741]
===
match
---
suite [3378,3727]
suite [3443,3792]
===
match
---
name: _log [1704,1708]
name: _log [1699,1703]
===
match
---
name: _logger [5178,5185]
name: _logger [5243,5250]
===
match
---
trailer [5185,5194]
trailer [5250,5259]
===
match
---
param [1373,1377]
param [1493,1497]
===
match
---
expr_stmt [4664,4688]
expr_stmt [4729,4753]
===
match
---
expr_stmt [3568,3591]
expr_stmt [3633,3656]
===
match
---
name: logger [2698,2704]
name: logger [2763,2769]
===
match
---
decorator [4775,4785]
decorator [4840,4850]
===
match
---
string: """Convenience super-class to have a logger configured with the class name""" [1194,1271]
string: """Convenience super-class to have a logger configured with the class name""" [1272,1349]
===
match
---
string: """         Do whatever it takes to actually log the specified logging record          :param message: message to log         """ [3387,3516]
string: """         Do whatever it takes to actually log the specified logging record          :param message: message to log         """ [3452,3581]
===
match
---
operator: + [1653,1654]
operator: + [1645,1646]
===
match
---
suite [1189,1822]
suite [1267,1887]
===
match
---
suite [1019,1168]
suite [1097,1246]
===
match
---
atom_expr [1791,1821]
atom_expr [1856,1886]
===
match
---
atom_expr [5477,5494]
atom_expr [5542,5559]
===
match
---
simple_stmt [3568,3592]
simple_stmt [3633,3657]
===
match
---
name: re [933,935]
name: re [1011,1013]
===
match
---
operator: , [4955,4956]
operator: , [5020,5021]
===
match
---
atom_expr [4597,4613]
atom_expr [4662,4678]
===
match
---
name: ANSI_ESCAPE [1142,1153]
name: ANSI_ESCAPE [1220,1231]
===
match
---
atom_expr [3618,3630]
atom_expr [3683,3695]
===
match
---
name: set_context [1791,1802]
name: set_context [1856,1867]
===
match
---
name: level [3311,3316]
name: level [3376,3381]
===
match
---
name: context [1737,1744]
name: context [1802,1809]
===
match
---
parameters [3741,3747]
parameters [3806,3812]
===
match
---
trailer [943,974]
trailer [1021,1052]
===
match
---
operator: -> [1012,1014]
operator: -> [1090,1092]
===
match
---
string: """     Remove ANSI escapes codes from string. It's used to remove     "colors" from log messages.     """ [1024,1130]
string: """     Remove ANSI escapes codes from string. It's used to remove     "colors" from log messages.     """ [1102,1208]
===
match
---
atom_expr [3852,3885]
atom_expr [3917,3950]
===
match
---
name: re [820,822]
name: re [805,807]
===
match
---
param [2945,2949]
param [3010,3014]
===
match
---
string: "" [1158,1160]
string: "" [1236,1238]
===
match
---
expr_stmt [1591,1679]
expr_stmt [1594,1671]
===
match
---
name: abc [1957,1960]
name: abc [2022,2025]
===
match
---
suite [4964,5582]
suite [5029,5647]
===
match
---
operator: @ [1956,1957]
operator: @ [2021,2022]
===
match
---
name: self [3932,3936]
name: self [3997,4001]
===
match
---
simple_stmt [2788,2915]
simple_stmt [2853,2980]
===
match
---
operator: -> [2284,2286]
operator: -> [2349,2351]
===
match
---
parameters [1992,1998]
parameters [2057,2063]
===
match
---
suite [2131,2208]
suite [2196,2273]
===
match
---
funcdef [2763,2915]
funcdef [2828,2980]
===
match
---
trailer [3548,3554]
trailer [3613,3619]
===
match
---
expr_stmt [2740,2757]
expr_stmt [2805,2822]
===
match
---
atom_expr [4747,4769]
atom_expr [4812,4834]
===
match
---
simple_stmt [1194,1272]
simple_stmt [1272,1350]
===
match
---
while_stmt [5140,5582]
while_stmt [5205,5647]
===
match
---
expr_stmt [5567,5581]
expr_stmt [5632,5646]
===
match
---
decorated [1351,1709]
decorated [1464,1774]
===
match
---
atom_expr [1319,1345]
atom_expr [1432,1458]
===
match
---
simple_stmt [1135,1168]
simple_stmt [1213,1246]
===
match
---
simple_stmt [3757,3806]
simple_stmt [3822,3871]
===
match
---
name: parent [5534,5540]
name: parent [5599,5605]
===
match
---
dotted_name [1957,1975]
dotted_name [2022,2040]
===
match
---
name: abstractmethod [2047,2061]
name: abstractmethod [2112,2126]
===
match
---
trailer [3686,3693]
trailer [3751,3758]
===
match
---
suite [4440,4588]
suite [4505,4653]
===
match
---
simple_stmt [2301,2365]
simple_stmt [2366,2430]
===
match
---
name: propagate [5485,5494]
name: propagate [5550,5559]
===
match
---
name: set_context [5237,5248]
name: set_context [5302,5313]
===
match
---
name: remove_escape_codes [981,1000]
name: remove_escape_codes [1059,1078]
===
match
---
atom_expr [5229,5255]
atom_expr [5294,5320]
===
match
---
funcdef [1714,1822]
funcdef [1779,1887]
===
match
---
funcdef [3921,4101]
funcdef [3986,4166]
===
match
---
simple_stmt [4453,4588]
simple_stmt [4518,4653]
===
match
---
atom_expr [4416,4439]
atom_expr [4481,4504]
===
match
---
name: _log [1596,1600]
name: logger [1594,1600]
===
match
---
name: self [1731,1735]
name: self [1796,1800]
===
match
---
annassign [2500,2513]
annassign [2565,2578]
===
match
---
name: Logger [863,869]
name: Logger [848,854]
===
match
---
name: _use_stderr [4669,4680]
name: _use_stderr [4734,4745]
===
match
---
name: Exception [4459,4468]
name: Exception [4524,4533]
===
match
---
trailer [4896,4903]
trailer [4961,4968]
===
match
---
string: """Allows to redirect stdout and stderr to logger""" [2434,2486]
string: """Allows to redirect stdout and stderr to logger""" [2499,2551]
===
match
---
operator: = [2696,2697]
operator: = [2761,2762]
===
match
---
funcdef [4933,5582]
funcdef [4998,5647]
===
match
---
simple_stmt [2492,2514]
simple_stmt [2557,2579]
===
match
---
atom_expr [933,974]
atom_expr [1011,1052]
===
match
---
simple_stmt [4597,4621]
simple_stmt [4662,4686]
===
match
---
operator: = [2724,2725]
operator: = [2789,2790]
===
match
---
name: self [1655,1659]
name: self [1647,1651]
===
match
---
decorator [1942,1952]
decorator [2007,2017]
===
match
---
name: self [1290,1294]
name: self [1403,1407]
===
match
---
operator: = [5575,5576]
operator: = [5640,5641]
===
match
---
arglist [1803,1820]
arglist [1868,1885]
===
match
---
trailer [1526,1531]
trailer [1567,1572]
===
match
---
simple_stmt [4913,4931]
simple_stmt [4978,4996]
===
match
---
expr_stmt [2492,2513]
expr_stmt [2557,2578]
===
match
---
parameters [1372,1378]
parameters [1492,1498]
===
match
---
name: value [5249,5254]
name: value [5314,5319]
===
match
---
operator: , [3215,3216]
operator: , [3280,3281]
===
match
---
arglist [4427,4438]
arglist [4492,4503]
===
match
---
import_name [787,797]
import_name [787,797]
===
match
---
name: self [1993,1997]
name: self [2058,2062]
===
match
---
trailer [3539,3548]
trailer [3604,3613]
===
match
---
name: self [1319,1323]
name: self [1432,1436]
===
match
---
string: '.' [1649,1652]
string: '.' [1641,1644]
===
match
---
suite [1778,1822]
suite [1843,1887]
===
match
---
name: _propagate_log [3857,3871]
name: _propagate_log [3922,3936]
===
match
---
classdef [1170,1822]
classdef [1248,1887]
===
match
---
decorator [2227,2247]
decorator [2292,2312]
===
match
---
param [2091,2096]
param [2156,2161]
===
match
---
simple_stmt [813,823]
simple_stmt [798,808]
===
match
---
simple_stmt [5229,5256]
simple_stmt [5294,5321]
===
match
---
atom_expr [5526,5540]
atom_expr [5591,5605]
===
match
---
raise_stmt [4453,4587]
raise_stmt [4518,4652]
===
match
---
operator: = [1303,1304]
operator: = [1416,1417]
===
match
---
string: """         Returns False to indicate that the stream is not closed, as it will be         open for the duration of Airflow's lifecycle.          For compatibility with the io.IOBase interface.         """ [2960,3165]
string: """         Returns False to indicate that the stream is not closed, as it will be         open for the duration of Airflow's lifecycle.          For compatibility with the io.IOBase interface.         """ [3025,3230]
===
match
---
if_stmt [4629,4689]
if_stmt [4694,4754]
===
match
---
simple_stmt [3387,3517]
simple_stmt [3452,3582]
===
match
---
name: str [1007,1010]
name: str [1085,1088]
===
match
---
file_input [787,5582]
file_input [787,5647]
===
match
---
name: self [3898,3902]
name: self [3963,3967]
===
match
---
name: context [1758,1765]
name: context [1823,1830]
===
match
---
name: abc [794,797]
name: abc [794,797]
===
match
---
trailer [2744,2752]
trailer [2809,2817]
===
match
---
trailer [1703,1708]
trailer [1698,1703]
===
match
---
atom_expr [3568,3580]
atom_expr [3633,3645]
===
match
---
trailer [3693,3695]
trailer [3758,3760]
===
match
---
param [4800,4804]
param [4865,4869]
===
match
---
trailer [5484,5494]
trailer [5549,5559]
===
match
---
arith_expr [1621,1678]
arith_expr [1613,1670]
===
match
---
param [1290,1295]
param [1403,1408]
===
match
---
import_name [823,833]
import_name [808,818]
===
match
---
operator: @ [2920,2921]
operator: @ [2985,2986]
===
match
---
parameters [4385,4399]
parameters [4450,4464]
===
match
---
not_test [4412,4439]
not_test [4477,4504]
===
match
---
name: self [2945,2949]
name: self [3010,3014]
===
match
---
param [1737,1744]
param [1802,1809]
===
match
---
simple_stmt [1856,1937]
simple_stmt [1921,2002]
===
match
---
tfpdef [1001,1010]
tfpdef [1079,1088]
===
match
---
operator: = [3722,3723]
operator: = [3787,3788]
===
match
---
return_stmt [3174,3186]
return_stmt [3239,3251]
===
match
---
trailer [1659,1669]
trailer [1651,1661]
===
match
---
suite [4143,4931]
suite [4208,4996]
===
match
---
trailer [1323,1336]
trailer [1436,1449]
===
match
---
simple_stmt [1024,1131]
simple_stmt [1102,1209]
===
match
---
name: logging [839,846]
name: logging [824,831]
===
match
---
name: flush [3736,3741]
name: flush [3801,3806]
===
match
---
expr_stmt [3709,3726]
expr_stmt [3774,3791]
===
match
---
string: """         Returns False to indicate the fd is not connected to a tty(-like) device.         For compatibility reasons.         """ [3947,4079]
string: """         Returns False to indicate the fd is not connected to a tty(-like) device.         For compatibility reasons.         """ [4012,4144]
===
match
---
name: task_instance [2097,2110]
name: task_instance [2162,2175]
===
match
---
decorated [2042,2208]
decorated [2107,2273]
===
match
---
funcdef [2251,2365]
funcdef [2316,2430]
===
match
---
name: str [2127,2130]
name: str [2192,2195]
===
match
---
operator: = [5524,5525]
operator: = [5589,5590]
===
match
---
atom_expr [5178,5194]
atom_expr [5243,5259]
===
match
---
name: stream [4392,4398]
name: stream [4457,4463]
===
match
---
comparison [3817,3838]
comparison [3882,3903]
===
match
---
atom_expr [1699,1708]
atom_expr [1684,1703]
===
match
---
if_stmt [1755,1822]
if_stmt [1820,1887]
===
match
---
simple_stmt [1398,1422]
simple_stmt [1518,1542]
===
match
---
name: _log [1527,1531]
name: _log [1568,1572]
===
match
---
simple_stmt [2740,2758]
simple_stmt [2805,2823]
===
match
---
simple_stmt [2960,3166]
simple_stmt [3025,3231]
===
match
---
operator: , [4390,4391]
operator: , [4455,4456]
===
match
---
operator: @ [2042,2043]
operator: @ [2107,2108]
===
match
---
name: _buffer [3877,3884]
name: _buffer [3942,3949]
===
match
---
expr_stmt [5119,5135]
expr_stmt [5184,5200]
===
match
---
parameters [2277,2283]
parameters [2342,2348]
===
match
---
operator: , [861,862]
operator: , [846,847]
===
match
---
string: """Returns current stream.""" [4815,4844]
string: """Returns current stream.""" [4880,4909]
===
match
---
name: stream [4644,4650]
name: stream [4709,4715]
===
match
---
name: log [1369,1372]
name: log [1489,1492]
===
match
---
name: write [3357,3362]
name: write [3422,3427]
===
match
---
name: self [3654,3658]
name: self [3719,3723]
===
match
---
name: self [2773,2777]
name: self [2838,2842]
===
match
---
param [3363,3368]
param [3428,3433]
===
match
---
string: "Cannot use file like objects. Use 'stdout' or 'stderr' as a str and without 'ext://'." [4486,4573]
string: "Cannot use file like objects. Use 'stdout' or 'stderr' as a str and without 'ext://'." [4551,4638]
===
match
---
name: message [3584,3591]
name: message [3649,3656]
===
match
---
param [4949,4956]
param [5014,5021]
===
match
---
trailer [3673,3696]
trailer [3738,3761]
===
match
---
name: level [2726,2731]
name: level [2791,2796]
===
match
---
name: self [3821,3825]
name: self [3886,3890]
===
match
---
name: str [2002,2005]
name: str [2067,2070]
===
match
---
name: stderr [4897,4903]
name: stderr [4962,4968]
===
match
---
name: len [3817,3820]
name: len [3882,3885]
===
match
---
simple_stmt [3898,3916]
simple_stmt [3963,3981]
===
match
---
name: self [4856,4860]
name: self [4921,4925]
===
match
---
atom_expr [3821,3833]
atom_expr [3886,3898]
===
match
---
atom_expr [4920,4930]
atom_expr [4985,4995]
===
match
---
comp_op [1766,1772]
comp_op [1831,1837]
===
match
---
operator: , [869,870]
operator: , [854,855]
===
match
---
atom_expr [3290,3347]
atom_expr [3355,3412]
===
match
---
name: self [3742,3746]
name: self [3807,3811]
===
match
---
atom_expr [1603,1679]
atom_expr [1603,1671]
===
match
---
param [2773,2777]
param [2838,2842]
===
match
---
name: self [3618,3622]
name: self [3683,3687]
===
match
---
expr_stmt [2713,2731]
expr_stmt [2778,2796]
===
match
---
decorators [1942,1976]
decorators [2007,2041]
===
match
---
param [4957,4962]
param [5022,5027]
===
match
---
name: message [3634,3641]
name: message [3699,3706]
===
match
---
simple_stmt [5516,5541]
simple_stmt [5581,5606]
===
match
---
name: compile [936,943]
name: compile [1014,1021]
===
match
---
suite [4400,4770]
suite [4465,4835]
===
match
---
name: property [4776,4784]
name: property [4841,4849]
===
match
---
parameters [3210,3225]
parameters [3275,3290]
===
match
---
operator: = [4614,4615]
operator: = [4679,4680]
===
match
---
dotted_name [2228,2246]
dotted_name [2293,2311]
===
match
---
name: StreamLogWriter [2413,2428]
name: StreamLogWriter [2478,2493]
===
match
---
name: self [3211,3215]
name: self [3276,3280]
===
match
---
atom_expr [1522,1531]
atom_expr [1553,1572]
===
match
---
name: isinstance [4416,4426]
name: isinstance [4481,4491]
===
match
---
name: level [2718,2723]
name: level [2783,2788]
===
match
---
suite [4651,4689]
suite [4716,4754]
===
match
---
string: """Returns a logger.""" [1398,1421]
string: """Returns a logger.""" [1518,1541]
===
match
---
param [2532,2537]
param [2597,2602]
===
match
---
operator: + [1647,1648]
operator: + [1639,1640]
===
match
---
trailer [1802,1821]
trailer [1867,1886]
===
match
---
param [2097,2111]
param [2162,2176]
===
match
---
param [2112,2122]
param [2177,2187]
===
match
---
name: self [2532,2536]
name: self [2597,2601]
===
match
---
name: StreamHandler [871,884]
name: StreamHandler [856,869]
===
match
---
simple_stmt [3947,4080]
simple_stmt [4012,4145]
===
match
---
name: LoggingMixin [1176,1188]
name: LoggingMixin [1254,1266]
===
match
---
decorated [2920,3187]
decorated [2985,3252]
===
match
---
string: '' [3913,3915]
string: '' [3978,3980]
===
match
---
name: getLogger [1611,1620]
name: getLogger [1603,1612]
===
match
---
operator: , [4433,4434]
operator: , [4498,4499]
===
match
---
name: self [1522,1526]
name: self [1553,1557]
===
match
---
parameters [2531,2552]
parameters [2596,2617]
===
match
---
name: _buffer [3623,3630]
name: _buffer [3688,3695]
===
match
---
trailer [1807,1811]
trailer [1872,1876]
===
match
---
simple_stmt [4886,4904]
simple_stmt [4951,4969]
===
match
---
decorated [4775,4931]
decorated [4840,4996]
===
match
---
import_name [813,822]
import_name [798,807]
===
match
---
string: """Return the URL for log visualization in the external service.""" [2140,2207]
string: """Return the URL for log visualization in the external service.""" [2205,2272]
===
match
---
expr_stmt [919,974]
expr_stmt [997,1052]
===
match
---
name: self [3290,3294]
name: self [3355,3359]
===
match
---
operator: -> [1379,1381]
operator: -> [1499,1501]
===
match
---
expr_stmt [3618,3641]
expr_stmt [3683,3706]
===
match
---
name: _logger [5516,5523]
name: _logger [5581,5588]
===
match
---
atom_expr [4856,4872]
atom_expr [4921,4937]
===
match
---
trailer [5248,5255]
trailer [5313,5320]
===
match
---
atom_expr [4459,4587]
atom_expr [4524,4652]
===
match
---
suite [2779,2915]
suite [2844,2980]
===
match
---
atom_expr [1142,1167]
atom_expr [1220,1245]
===
match
---
trailer [5533,5540]
trailer [5598,5605]
===
match
---
trailer [3713,3721]
trailer [3778,3786]
===
match
---
string: """         Provide close method, for compatibility with the io.IOBase interface.          This is a no-op method.         """ [2788,2914]
string: """         Provide close method, for compatibility with the io.IOBase interface.          This is a no-op method.         """ [2853,2979]
===
match
---
trailer [3876,3884]
trailer [3941,3949]
===
match
---
decorated [2213,2365]
decorated [2278,2430]
===
match
---
name: self [2740,2744]
name: self [2805,2809]
===
match
---
simple_stmt [4148,4368]
simple_stmt [4213,4433]
===
match
---
string: '' [3724,3726]
string: '' [3789,3791]
===
match
---
trailer [1635,1646]
trailer [1627,1638]
===
match
---
trailer [1620,1679]
trailer [1612,1671]
===
match
---
name: _set_context [1718,1730]
name: _set_context [1783,1795]
===
match
---
name: context [1813,1820]
name: context [1878,1885]
===
match
---
operator: = [931,932]
operator: = [1009,1010]
===
match
---
trailer [3902,3910]
trailer [3967,3975]
===
match
---
trailer [4668,4680]
trailer [4733,4745]
===
match
---
funcdef [1365,1709]
funcdef [1485,1774]
===
match
---
simple_stmt [919,975]
simple_stmt [997,1053]
===
match
---
name: _buffer [3903,3910]
name: _buffer [3968,3975]
===
match
---
string: 'stdout' [4632,4640]
string: 'stdout' [4697,4705]
===
match
---
simple_stmt [4747,4770]
simple_stmt [4812,4835]
===
match
---
operator: , [1294,1295]
operator: , [1407,1408]
===
match
---
trailer [3294,3301]
trailer [3359,3366]
===
match
---
trailer [1669,1678]
trailer [1661,1670]
===
match
---
trailer [4763,4769]
trailer [4828,4834]
===
match
---
name: str [1015,1018]
name: str [1093,1096]
===
match
---
trailer [3337,3346]
trailer [3402,3411]
===
match
---
name: abstractmethod [2232,2246]
name: abstractmethod [2297,2311]
===
match
---
suite [1310,1346]
suite [1423,1459]
===
match
---
operator: , [2110,2111]
operator: , [2175,2176]
===
match
---
param [1731,1736]
param [1796,1801]
===
match
---
simple_stmt [787,798]
simple_stmt [787,798]
===
match
---
string: """         :param log: The log level method to write to, ie. log.debug, log.warning         :return:         """ [2562,2675]
string: """         :param log: The log level method to write to, ie. log.debug, log.warning         :return:         """ [2627,2740]
===
match
---
funcdef [977,1168]
funcdef [1055,1246]
===
match
---
parameters [2944,2950]
parameters [3009,3015]
===
match
---
name: self [3306,3310]
name: self [3371,3375]
===
match
---
comparison [1758,1777]
comparison [1823,1842]
===
match
---
suite [2951,3187]
suite [3016,3252]
===
match
---
param [4386,4391]
param [4451,4456]
===
match
---
parameters [1730,1745]
parameters [1795,1810]
===
match
---
suite [3226,3348]
suite [3291,3413]
===
match
---
return_stmt [4088,4100]
return_stmt [4153,4165]
===
match
---
operator: , [2544,2545]
operator: , [2609,2610]
===
match
---
name: self [4764,4768]
name: self [4829,4833]
===
match
---
decorator [1351,1361]
decorator [1464,1481]
===
match
---
try_stmt [5208,5466]
try_stmt [5273,5531]
===
match
---
if_stmt [4409,4588]
if_stmt [4474,4653]
===
match
---
simple_stmt [1319,1346]
simple_stmt [1432,1459]
===
match
---
suite [1746,1822]
suite [1811,1887]
===
match
---
decorator [1956,1976]
decorator [2021,2041]
===
match
---
simple_stmt [823,834]
simple_stmt [808,819]
===
match
---
funcdef [3192,3348]
funcdef [3257,3413]
===
match
---
operator: -> [2124,2126]
operator: -> [2189,2191]
===
match
---
atom_expr [1621,1646]
atom_expr [1613,1638]
===
match
---
trailer [1157,1167]
trailer [1235,1245]
===
match
---
name: closed [2938,2944]
name: closed [3003,3009]
===
match
---
number: 0 [3837,3838]
number: 0 [3902,3903]
===
match
---
suite [2292,2365]
suite [2357,2430]
===
match
---
name: _propagate_log [3659,3673]
name: _propagate_log [3724,3738]
===
match
---
param [3932,3936]
param [3997,4001]
===
match
---
name: message [3338,3345]
name: message [3403,3410]
===
match
---
suite [3605,3727]
suite [3670,3792]
===
match
---
atom_expr [2684,2695]
atom_expr [2749,2760]
===
match
---
name: self [2684,2688]
name: self [2749,2753]
===
match
---
simple_stmt [3654,3697]
simple_stmt [3719,3762]
===
match
---
simple_stmt [2713,2732]
simple_stmt [2778,2797]
===
match
---
param [3211,3216]
param [3276,3281]
===
match
---
atom_expr [3318,3346]
atom_expr [3383,3411]
===
match
---
funcdef [1980,2037]
funcdef [2045,2102]
===
match
---
name: bool [2287,2291]
name: bool [2352,2356]
===
match
---
name: __name__ [1670,1678]
name: __name__ [1662,1670]
===
match
---
atom_expr [2713,2723]
atom_expr [2778,2788]
===
match
---
simple_stmt [2015,2037]
simple_stmt [2080,2102]
===
match
---
name: self [1803,1807]
name: self [1868,1872]
===
match
---
suite [5503,5541]
suite [5568,5606]
===
match
---
trailer [4468,4587]
trailer [4533,4652]
===
match
---
param [2278,2282]
param [2343,2347]
===
match
---
simple_stmt [1591,1680]
simple_stmt [1594,1672]
===
match
---
atom_expr [3709,3721]
atom_expr [3774,3786]
===
match
---
string: """Define a log handler based on an external service (e.g. ELK, StackDriver).""" [1856,1936]
string: """Define a log handler based on an external service (e.g. ELK, StackDriver).""" [1921,2001]
===
match
---
trailer [2717,2723]
trailer [2782,2788]
===
match
---
string: """Ensure all logging output has been flushed""" [3757,3805]
string: """Ensure all logging output has been flushed""" [3822,3870]
===
match
---
name: property [2214,2222]
name: property [2279,2287]
===
match
---
return_stmt [4886,4903]
return_stmt [4951,4968]
===
match
---
suite [1389,1709]
suite [1509,1774]
===
match
---
name: abc [2228,2231]
name: abc [2293,2296]
===
match
---
operator: = [1601,1602]
operator: = [1601,1602]
===
match
---
simple_stmt [2140,2208]
simple_stmt [2205,2273]
===
match
---
suite [2553,2758]
suite [2618,2823]
===
match
---
string: '' [2755,2757]
string: '' [2820,2822]
===
match
---
suite [2429,4101]
suite [2494,4166]
===
insert-tree
---
simple_stmt [881,909]
    import_from [881,908]
        name: typing [886,892]
        name: Optional [900,908]
to
file_input [787,5582]
at 5
===
insert-tree
---
simple_stmt [910,963]
    import_from [910,962]
        dotted_name [915,939]
            name: airflow [915,922]
            name: compat [923,929]
            name: functools [930,939]
        name: cached_property [947,962]
to
file_input [787,5582]
at 6
===
insert-tree
---
simple_stmt [1355,1385]
    expr_stmt [1355,1384]
        name: _log [1355,1359]
        annassign [1359,1384]
            atom_expr [1361,1377]
                name: Optional [1361,1369]
                trailer [1369,1377]
                    name: Logger [1370,1376]
            operator: = [1378,1379]
to
suite [1189,1822]
at 1
===
insert-node
---
operator: , [869,870]
to
import_as_names [854,884]
at 5
===
insert-node
---
name: getLogger [871,880]
to
import_as_names [854,884]
at 6
===
update-node
---
name: property [1352,1360]
replace property by cached_property
===
insert-node
---
if_stmt [1550,1739]
to
suite [1389,1709]
at 1
===
insert-node
---
simple_stmt [1747,1774]
to
suite [1389,1709]
at 2
===
insert-node
---
comparison [1553,1580]
to
if_stmt [1550,1739]
at 0
===
move-tree
---
suite [1578,1709]
    simple_stmt [1591,1680]
        expr_stmt [1591,1679]
            atom_expr [1591,1600]
                name: self [1591,1595]
                trailer [1595,1600]
                    name: _log [1596,1600]
            operator: = [1601,1602]
            atom_expr [1603,1679]
                name: logging [1603,1610]
                trailer [1610,1620]
                    name: getLogger [1611,1620]
                trailer [1620,1679]
                    arith_expr [1621,1678]
                        atom_expr [1621,1646]
                            name: self [1621,1625]
                            trailer [1625,1635]
                                name: __class__ [1626,1635]
                            trailer [1635,1646]
                                name: __module__ [1636,1646]
                        operator: + [1647,1648]
                        string: '.' [1649,1652]
                        operator: + [1653,1654]
                        atom_expr [1655,1678]
                            name: self [1655,1659]
                            trailer [1659,1669]
                                name: __class__ [1660,1669]
                            trailer [1669,1678]
                                name: __name__ [1670,1678]
    simple_stmt [1692,1709]
        return_stmt [1692,1708]
            atom_expr [1699,1708]
                name: self [1699,1703]
                trailer [1703,1708]
                    name: _log [1704,1708]
to
if_stmt [1550,1739]
at 1
===
move-tree
---
return_stmt [1692,1708]
    atom_expr [1699,1708]
        name: self [1699,1703]
        trailer [1703,1708]
            name: _log [1704,1708]
to
simple_stmt [1747,1774]
at 0
===
move-tree
---
atom_expr [1522,1531]
    name: self [1522,1526]
    trailer [1526,1531]
        name: _log [1527,1531]
to
comparison [1553,1580]
at 0
===
insert-tree
---
simple_stmt [1725,1739]
    return_stmt [1725,1738]
        name: logger [1732,1738]
to
suite [1578,1709]
at 2
===
insert-tree
---
atom_expr [1754,1773]
    name: self [1754,1758]
    trailer [1758,1768]
        name: __class__ [1759,1768]
    trailer [1768,1773]
        name: _log [1769,1773]
to
return_stmt [1692,1708]
at 0
===
insert-tree
---
trailer [1557,1567]
    name: __class__ [1558,1567]
to
atom_expr [1522,1531]
at 1
===
insert-node
---
expr_stmt [1684,1712]
to
simple_stmt [1692,1709]
at 0
===
update-node
---
name: _log [1596,1600]
replace _log by logger
===
move-tree
---
name: _log [1596,1600]
to
expr_stmt [1591,1679]
at 0
===
move-tree
---
atom_expr [1699,1708]
    name: self [1699,1703]
    trailer [1703,1708]
        name: _log [1704,1708]
to
expr_stmt [1684,1712]
at 0
===
move-tree
---
name: getLogger [1611,1620]
to
atom_expr [1603,1679]
at 0
===
insert-tree
---
trailer [1688,1698]
    name: __class__ [1689,1698]
to
atom_expr [1699,1708]
at 1
===
delete-tree
---
simple_stmt [798,813]
    import_name [798,812]
        name: logging [805,812]
===
delete-node
---
trailer [1595,1600]
===
===
delete-node
---
atom_expr [1591,1600]
===
===
delete-node
---
name: logging [1603,1610]
===
===
delete-node
---
trailer [1610,1620]
===
===
delete-node
---
return_stmt [1515,1531]
===
===
delete-node
---
simple_stmt [1515,1548]
===
===
delete-node
---
suite [1434,1548]
===
===
delete-node
---
try_stmt [1430,1709]
===
