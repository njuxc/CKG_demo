===
match
---
trailer [80012,80017]
trailer [80119,80124]
===
match
---
name: session [27856,27863]
name: session [27856,27863]
===
match
---
name: get [70916,70919]
name: get [71023,71026]
===
match
---
name: UP_FOR_RETRY [29495,29507]
name: UP_FOR_RETRY [29495,29507]
===
match
---
name: session [24552,24559]
name: session [24552,24559]
===
match
---
return_stmt [73866,73918]
return_stmt [73973,74025]
===
match
---
trailer [57991,57994]
trailer [57991,57994]
===
match
---
trailer [24754,24760]
trailer [24754,24760]
===
match
---
operator: } [77815,77816]
operator: } [77922,77923]
===
match
---
atom_expr [88536,88765]
atom_expr [88643,88872]
===
match
---
name: __tablename__ [11163,11176]
name: __tablename__ [11163,11176]
===
match
---
argument [19430,19475]
argument [19430,19475]
===
match
---
string: """Return TI Context""" [67014,67037]
string: """Return TI Context""" [67121,67144]
===
match
---
name: DepContext [36619,36629]
name: DepContext [36619,36629]
===
match
---
return_stmt [32359,32377]
return_stmt [32359,32377]
===
match
---
simple_stmt [9831,9886]
simple_stmt [9831,9886]
===
match
---
trailer [13078,13107]
trailer [13078,13107]
===
match
---
name: ParamsDict [2421,2431]
name: ParamsDict [2421,2431]
===
match
---
atom_expr [61092,61523]
atom_expr [61092,61523]
===
match
---
operator: -> [34145,34147]
operator: -> [34145,34147]
===
match
---
name: self [34663,34667]
name: self [34663,34667]
===
match
---
operator: + [72915,72916]
operator: + [73022,73023]
===
match
---
operator: } [23660,23661]
operator: } [23660,23661]
===
match
---
suite [68444,68609]
suite [68551,68716]
===
match
---
operator: , [85217,85218]
operator: , [85324,85325]
===
match
---
trailer [49947,49955]
trailer [49947,49955]
===
match
---
operator: = [83048,83049]
operator: = [83155,83156]
===
match
---
name: Any [86753,86756]
name: Any [86860,86863]
===
match
---
suite [20307,23027]
suite [20307,23027]
===
match
---
argument [35076,35087]
argument [35076,35087]
===
match
---
operator: = [24436,24437]
operator: = [24436,24437]
===
match
---
argument [7642,8170]
argument [7642,8170]
===
match
---
expr_stmt [15365,15417]
expr_stmt [15365,15417]
===
match
---
simple_stmt [67735,67793]
simple_stmt [67842,67900]
===
match
---
decorator [93430,93440]
decorator [93537,93547]
===
match
---
with_item [15509,15536]
with_item [15509,15536]
===
match
---
atom_expr [66397,66490]
atom_expr [66504,66597]
===
match
---
name: self [34480,34484]
name: self [34480,34484]
===
match
---
suite [74718,74897]
suite [74825,75004]
===
match
---
operator: = [86457,86458]
operator: = [86564,86565]
===
match
---
trailer [28861,28909]
trailer [28861,28909]
===
match
---
atom_expr [90837,90845]
atom_expr [90944,90952]
===
match
---
name: self [76856,76860]
name: self [76963,76967]
===
match
---
name: execution_date [73976,73990]
name: execution_date [74083,74097]
===
match
---
name: kubernetes [3551,3561]
name: kubernetes [3551,3561]
===
match
---
name: base_job [8322,8330]
name: base_job [8322,8330]
===
match
---
argument [54673,54686]
argument [54673,54686]
===
match
---
atom_expr [66861,66876]
atom_expr [66968,66983]
===
match
---
trailer [86363,86370]
trailer [86470,86477]
===
match
---
trailer [67599,67640]
trailer [67706,67747]
===
match
---
name: Union [66253,66258]
name: Union [66360,66365]
===
match
---
name: session [63215,63222]
name: session [63215,63222]
===
match
---
simple_stmt [22682,22706]
simple_stmt [22682,22706]
===
match
---
expr_stmt [84133,84186]
expr_stmt [84240,84293]
===
match
---
atom_expr [80640,80651]
atom_expr [80747,80758]
===
match
---
trailer [46642,46648]
trailer [46642,46648]
===
match
---
atom_expr [49723,49769]
atom_expr [49723,49769]
===
match
---
trailer [27561,27572]
trailer [27561,27572]
===
match
---
name: job_id [11760,11766]
name: job_id [11760,11766]
===
match
---
arglist [25412,25454]
arglist [25412,25454]
===
match
---
funcdef [70022,70265]
funcdef [70129,70372]
===
match
---
if_stmt [30978,31018]
if_stmt [30978,31018]
===
match
---
suite [74524,74659]
suite [74631,74766]
===
match
---
operator: -> [93000,93002]
operator: -> [93107,93109]
===
match
---
operator: = [88609,88610]
operator: = [88716,88717]
===
match
---
arith_expr [39905,39938]
arith_expr [39905,39938]
===
match
---
name: State [8452,8457]
name: State [8452,8457]
===
match
---
operator: @ [23769,23770]
operator: @ [23769,23770]
===
match
---
atom_expr [74460,74479]
atom_expr [74567,74586]
===
match
---
operator: , [1069,1070]
operator: , [1069,1070]
===
match
---
fstring_string: DagRun for  [15847,15858]
fstring_string: DagRun for  [15847,15858]
===
match
---
name: ignore_depends_on_past [44038,44060]
name: ignore_depends_on_past [44038,44060]
===
match
---
operator: , [12971,12972]
operator: , [12971,12972]
===
match
---
simple_stmt [59479,59496]
simple_stmt [59479,59496]
===
match
---
operator: , [33349,33350]
operator: , [33349,33350]
===
match
---
trailer [8529,8733]
trailer [8529,8733]
===
match
---
strings [23539,23753]
strings [23539,23753]
===
match
---
expr_stmt [59565,59602]
expr_stmt [59565,59602]
===
match
---
name: self [45992,45996]
name: self [45992,45996]
===
match
---
name: execution_date [15283,15297]
name: execution_date [15283,15297]
===
match
---
operator: = [64197,64198]
operator: = [64197,64198]
===
match
---
expr_stmt [60269,60285]
expr_stmt [60269,60285]
===
match
---
name: start_date [64553,64563]
name: start_date [64660,64670]
===
match
---
trailer [68299,68319]
trailer [68406,68426]
===
match
---
name: bool [19897,19901]
name: bool [19897,19901]
===
match
---
name: task [59894,59898]
name: task [59894,59898]
===
match
---
name: error [63771,63776]
name: error [63771,63776]
===
match
---
name: job [8440,8443]
name: job [8440,8443]
===
match
---
name: context [59619,59626]
name: context [59619,59626]
===
match
---
name: prev_ds [75000,75007]
name: prev_ds [75107,75114]
===
match
---
operator: -> [4991,4993]
operator: -> [4991,4993]
===
match
---
name: execute_callable [57201,57217]
name: execute_callable [57201,57217]
===
match
---
name: test_mode [50837,50846]
name: test_mode [50837,50846]
===
match
---
name: operator_helpers [3223,3239]
name: operator_helpers [3223,3239]
===
match
---
trailer [68319,68357]
trailer [68426,68464]
===
match
---
atom_expr [26720,26726]
atom_expr [26720,26726]
===
match
---
trailer [80892,80908]
trailer [80999,81015]
===
match
---
name: relationship [13509,13521]
name: relationship [13509,13521]
===
match
---
name: self [80593,80597]
name: self [80700,80704]
===
match
---
simple_stmt [28918,28937]
simple_stmt [28918,28937]
===
match
---
operator: , [62784,62785]
operator: , [62784,62785]
===
match
---
import_from [67241,67267]
import_from [67348,67374]
===
match
---
operator: , [54751,54752]
operator: , [54751,54752]
===
match
---
atom_expr [75310,75363]
atom_expr [75417,75470]
===
match
---
name: email_on_failure [65479,65495]
name: email_on_failure [65586,65602]
===
match
---
atom_expr [82883,82898]
atom_expr [82990,83005]
===
match
---
trailer [57376,57386]
trailer [57376,57386]
===
match
---
operator: , [45422,45423]
operator: , [45422,45423]
===
match
---
atom_expr [59203,59234]
atom_expr [59203,59234]
===
match
---
operator: , [80651,80652]
operator: , [80758,80759]
===
match
---
simple_stmt [72453,72496]
simple_stmt [72560,72603]
===
match
---
dotted_name [2248,2267]
dotted_name [2248,2267]
===
match
---
name: TaskInstance [25485,25497]
name: TaskInstance [25485,25497]
===
match
---
operator: = [61598,61599]
operator: = [61598,61599]
===
match
---
name: hr_line_break [43613,43626]
name: hr_line_break [43613,43626]
===
match
---
atom_expr [9928,9939]
atom_expr [9928,9939]
===
match
---
operator: = [85924,85925]
operator: = [86031,86032]
===
match
---
trailer [56713,56727]
trailer [56713,56727]
===
match
---
name: str [9733,9736]
name: str [9733,9736]
===
match
---
simple_stmt [93724,93741]
simple_stmt [93831,93848]
===
match
---
simple_stmt [84023,84042]
simple_stmt [84130,84149]
===
match
---
name: or_ [7625,7628]
name: or_ [7625,7628]
===
match
---
name: get_previous_ti [32429,32444]
name: get_previous_ti [32429,32444]
===
match
---
trailer [85026,85032]
trailer [85133,85139]
===
match
---
operator: , [54754,54755]
operator: , [54754,54755]
===
match
---
funcdef [70621,70803]
funcdef [70728,70910]
===
match
---
trailer [23412,23445]
trailer [23412,23445]
===
match
---
name: str [34685,34688]
name: str [34685,34688]
===
match
---
name: FAILED [59459,59465]
name: FAILED [59459,59465]
===
match
---
atom_expr [31032,31064]
atom_expr [31032,31064]
===
match
---
trailer [11855,11891]
trailer [11855,11891]
===
match
---
name: session [45557,45564]
name: session [45557,45564]
===
match
---
atom_expr [46454,46467]
atom_expr [46454,46467]
===
match
---
operator: = [74208,74209]
operator: = [74315,74316]
===
match
---
operator: , [8048,8049]
operator: , [8048,8049]
===
match
---
name: verbose [61150,61157]
name: verbose [61150,61157]
===
match
---
operator: , [47719,47720]
operator: , [47719,47720]
===
match
---
name: expected_state [4536,4550]
name: expected_state [4536,4550]
===
match
---
simple_stmt [26430,26467]
simple_stmt [26430,26467]
===
match
---
name: ti [26213,26215]
name: ti [26213,26215]
===
match
---
argument [50637,50652]
argument [50637,50652]
===
match
---
not_test [29512,29538]
not_test [29512,29538]
===
match
---
name: state [16072,16077]
name: state [16072,16077]
===
match
---
arglist [54079,54232]
arglist [54079,54232]
===
match
---
name: lazy_object_proxy [72090,72107]
name: lazy_object_proxy [72197,72214]
===
match
---
name: Integer [11776,11783]
name: Integer [11776,11783]
===
match
---
trailer [55066,55068]
trailer [55066,55068]
===
match
---
operator: == [59864,59866]
operator: == [59864,59866]
===
match
---
trailer [9099,9105]
trailer [9099,9105]
===
match
---
name: try_number [46300,46310]
name: try_number [46300,46310]
===
match
---
suite [66576,66895]
suite [66683,67002]
===
match
---
strings [86080,86182]
strings [86187,86289]
===
match
---
trailer [68122,68130]
trailer [68229,68237]
===
match
---
suite [70301,71203]
suite [70408,71310]
===
match
---
operator: = [62069,62070]
operator: = [62069,62070]
===
match
---
operator: , [27076,27077]
operator: , [27076,27077]
===
match
---
trailer [80237,80242]
trailer [80344,80349]
===
match
---
atom_expr [72684,72696]
atom_expr [72791,72803]
===
match
---
name: set_error_file [4929,4943]
name: set_error_file [4929,4943]
===
match
---
operator: , [76108,76109]
operator: , [76215,76216]
===
match
---
fstring_start: f" [23601,23603]
fstring_start: f" [23601,23603]
===
match
---
decorated [32978,33457]
decorated [32978,33457]
===
match
---
suite [16455,16593]
suite [16455,16593]
===
match
---
param [89929,89938]
param [90036,90045]
===
match
---
name: list [90442,90446]
name: list [90549,90553]
===
match
---
operator: , [76215,76216]
operator: , [76322,76323]
===
match
---
name: self [63762,63766]
name: self [63762,63766]
===
match
---
expr_stmt [43828,44149]
expr_stmt [43828,44149]
===
match
---
operator: = [81522,81523]
operator: = [81629,81630]
===
match
---
name: self [65945,65949]
name: self [66052,66056]
===
match
---
param [27850,27855]
param [27850,27855]
===
match
---
name: get_prev_ds [76547,76558]
name: get_prev_ds [76654,76665]
===
match
---
name: create_session [15509,15523]
name: create_session [15509,15523]
===
match
---
name: task [49258,49262]
name: task [49258,49262]
===
match
---
name: staticmethod [71621,71633]
name: staticmethod [71728,71740]
===
match
---
simple_stmt [23073,23104]
simple_stmt [23073,23104]
===
match
---
simple_stmt [48776,48830]
simple_stmt [48776,48830]
===
match
---
name: utcnow [9461,9467]
name: utcnow [9461,9467]
===
match
---
trailer [25405,25411]
trailer [25405,25411]
===
match
---
param [86526,86531]
param [86633,86638]
===
match
---
operator: = [31765,31766]
operator: = [31765,31766]
===
match
---
name: utils [3393,3398]
name: utils [3393,3398]
===
match
---
name: external_trigger [74394,74410]
name: external_trigger [74501,74517]
===
match
---
trailer [76280,76287]
trailer [76387,76394]
===
match
---
parameters [68250,68252]
parameters [68357,68359]
===
match
---
name: connection [2324,2334]
name: connection [2324,2334]
===
match
---
suite [92772,92828]
suite [92879,92935]
===
match
---
atom_expr [7834,7893]
atom_expr [7834,7893]
===
match
---
trailer [47594,47609]
trailer [47594,47609]
===
match
---
dotted_name [2816,2849]
dotted_name [2816,2849]
===
match
---
trailer [52076,52078]
trailer [52076,52078]
===
match
---
operator: == [90932,90934]
operator: == [91039,91041]
===
match
---
name: TR [7756,7758]
name: TR [7756,7758]
===
match
---
trailer [30960,30965]
trailer [30960,30965]
===
match
---
name: email [3033,3038]
name: email [3033,3038]
===
match
---
name: self [10150,10154]
name: self [10150,10154]
===
match
---
decorator [93498,93508]
decorator [93605,93615]
===
match
---
trailer [47945,47950]
trailer [47945,47950]
===
match
---
simple_stmt [40629,40650]
simple_stmt [40629,40650]
===
match
---
trailer [24336,24343]
trailer [24336,24343]
===
match
---
simple_stmt [70314,70543]
simple_stmt [70421,70650]
===
match
---
name: update [83512,83518]
name: update [83619,83625]
===
match
---
trailer [11910,11923]
trailer [11910,11923]
===
match
---
suite [71931,71972]
suite [72038,72079]
===
match
---
trailer [67588,67599]
trailer [67695,67706]
===
match
---
trailer [50138,50156]
trailer [50138,50156]
===
match
---
tfpdef [19773,19784]
tfpdef [19773,19784]
===
match
---
trailer [77856,77858]
trailer [77963,77965]
===
match
---
atom_expr [58067,58079]
atom_expr [58067,58079]
===
match
---
simple_stmt [787,805]
simple_stmt [787,805]
===
match
---
trailer [40881,40888]
trailer [40881,40888]
===
match
---
trailer [46898,46902]
trailer [46898,46902]
===
match
---
atom_expr [7016,7039]
atom_expr [7016,7039]
===
match
---
suite [56651,56730]
suite [56651,56730]
===
match
---
expr_stmt [37344,37385]
expr_stmt [37344,37385]
===
match
---
name: RUNNING_DEPS [43891,43903]
name: RUNNING_DEPS [43891,43903]
===
match
---
atom [22857,22866]
atom [22857,22866]
===
match
---
string: "dag_run.run_id" [13377,13393]
string: "dag_run.run_id" [13377,13393]
===
match
---
trailer [89877,89884]
trailer [89984,89991]
===
match
---
simple_stmt [38200,38230]
simple_stmt [38200,38230]
===
match
---
simple_stmt [17327,17475]
simple_stmt [17327,17475]
===
match
---
suite [22833,22868]
suite [22833,22868]
===
match
---
name: set_current_context [54486,54505]
name: set_current_context [54486,54505]
===
match
---
operator: , [47999,48000]
operator: , [47999,48000]
===
match
---
name: models [2317,2323]
name: models [2317,2323]
===
match
---
decorated [74325,74659]
decorated [74432,74766]
===
match
---
and_test [84850,84883]
and_test [84957,84990]
===
match
---
name: plugins_manager [2646,2661]
name: plugins_manager [2646,2661]
===
match
---
name: error [64108,64113]
name: error [64108,64113]
===
match
---
funcdef [93760,93824]
funcdef [93867,93931]
===
match
---
fstring_expr [51982,51994]
fstring_expr [51982,51994]
===
match
---
name: str [92214,92217]
name: str [92321,92324]
===
match
---
trailer [14964,14977]
trailer [14964,14977]
===
match
---
operator: = [45581,45582]
operator: = [45581,45582]
===
match
---
atom_expr [22902,22937]
atom_expr [22902,22937]
===
match
---
operator: , [5359,5360]
operator: , [5359,5360]
===
match
---
atom_expr [53108,53120]
atom_expr [53108,53120]
===
match
---
name: _Variable__NO_DEFAULT_SENTINEL [70992,71022]
name: _Variable__NO_DEFAULT_SENTINEL [71099,71129]
===
match
---
name: next_kwargs [64737,64748]
name: next_kwargs [64844,64855]
===
match
---
trailer [56617,56631]
trailer [56617,56631]
===
match
---
operator: , [83632,83633]
operator: , [83739,83740]
===
match
---
trailer [64531,64546]
trailer [64638,64653]
===
match
---
name: RUNNING [46503,46510]
name: RUNNING [46503,46510]
===
match
---
return_stmt [24497,24509]
return_stmt [24497,24509]
===
match
---
argument [75596,75629]
argument [75703,75736]
===
match
---
atom [13151,13163]
atom [13151,13163]
===
match
---
name: ds_nodash [75412,75421]
name: ds_nodash [75519,75528]
===
match
---
name: set_duration [84781,84793]
name: set_duration [84888,84900]
===
match
---
name: error_file [63492,63502]
name: error_file [63492,63502]
===
match
---
param [35925,35938]
param [35925,35938]
===
match
---
name: self [37940,37944]
name: self [37940,37944]
===
match
---
name: force_fail [65849,65859]
name: force_fail [65956,65966]
===
match
---
arglist [75487,75630]
arglist [75594,75737]
===
match
---
suite [79582,79688]
suite [79689,79795]
===
match
---
name: AirflowException [51301,51317]
name: AirflowException [51301,51317]
===
match
---
expr_stmt [25883,25914]
expr_stmt [25883,25914]
===
match
---
name: conf [79973,79977]
name: conf [80080,80084]
===
match
---
name: task_id [91019,91026]
name: task_id [91126,91133]
===
match
---
simple_stmt [84280,84357]
simple_stmt [84387,84464]
===
match
---
name: TaskInstance [25567,25579]
name: TaskInstance [25567,25579]
===
match
---
name: self [47590,47594]
name: self [47590,47594]
===
match
---
suite [9640,10570]
suite [9640,10570]
===
match
---
operator: , [70056,70057]
operator: , [70163,70164]
===
match
---
trailer [86618,86623]
trailer [86725,86730]
===
match
---
simple_stmt [67801,67842]
simple_stmt [67908,67949]
===
match
---
name: hostname [43341,43349]
name: hostname [43341,43349]
===
match
---
return_stmt [32890,32901]
return_stmt [32890,32901]
===
match
---
operator: , [75629,75630]
operator: , [75736,75737]
===
match
---
atom_expr [15805,15933]
atom_expr [15805,15933]
===
match
---
trailer [83880,83891]
trailer [83987,83998]
===
match
---
trailer [74016,74018]
trailer [74123,74125]
===
match
---
name: self [62262,62266]
name: self [62262,62266]
===
match
---
simple_stmt [40116,40145]
simple_stmt [40116,40145]
===
match
---
atom_expr [51770,51843]
atom_expr [51770,51843]
===
match
---
trailer [44321,44328]
trailer [44321,44328]
===
match
---
name: execution_timeout [58572,58589]
name: execution_timeout [58572,58589]
===
match
---
trailer [63766,63770]
trailer [63766,63770]
===
match
---
param [20256,20287]
param [20256,20287]
===
match
---
name: filter [9127,9133]
name: filter [9127,9133]
===
match
---
trailer [58987,59007]
trailer [58987,59007]
===
match
---
arglist [24218,24359]
arglist [24218,24359]
===
match
---
simple_stmt [28806,28839]
simple_stmt [28806,28839]
===
match
---
trailer [38217,38229]
trailer [38217,38229]
===
match
---
expr_stmt [26857,26888]
expr_stmt [26857,26888]
===
match
---
operator: = [88705,88706]
operator: = [88812,88813]
===
match
---
name: _task_id [93028,93036]
name: _task_id [93135,93143]
===
match
---
trailer [44173,44194]
trailer [44173,44194]
===
match
---
operator: * [43641,43642]
operator: * [43641,43642]
===
match
---
trailer [83080,83088]
trailer [83187,83195]
===
match
---
name: renderedtifields [52391,52407]
name: renderedtifields [52391,52407]
===
match
---
trailer [46502,46510]
trailer [46502,46510]
===
match
---
trailer [90087,90127]
trailer [90194,90234]
===
match
---
name: task_id [49948,49955]
name: task_id [49948,49955]
===
match
---
trailer [83264,83286]
trailer [83371,83393]
===
match
---
funcdef [16612,17178]
funcdef [16612,17178]
===
match
---
param [32454,32459]
param [32454,32459]
===
match
---
trailer [82887,82898]
trailer [82994,83005]
===
match
---
decorator [93746,93756]
decorator [93853,93863]
===
match
---
trailer [14193,14198]
trailer [14193,14198]
===
match
---
atom_expr [73873,73918]
atom_expr [73980,74025]
===
match
---
atom_expr [62194,62222]
atom_expr [62194,62222]
===
match
---
operator: , [32487,32488]
operator: , [32487,32488]
===
match
---
name: utcnow [40394,40400]
name: utcnow [40394,40400]
===
match
---
trailer [6282,6289]
trailer [6282,6289]
===
match
---
atom_expr [23124,23155]
atom_expr [23124,23155]
===
match
---
name: Column [11548,11554]
name: Column [11548,11554]
===
match
---
name: extend [22975,22981]
name: extend [22975,22981]
===
match
---
name: self [78620,78624]
name: self [78727,78731]
===
match
---
return_stmt [70852,70872]
return_stmt [70959,70979]
===
match
---
operator: , [13632,13633]
operator: , [13632,13633]
===
match
---
name: or_ [91433,91436]
name: or_ [91540,91543]
===
match
---
expr_stmt [28918,28936]
expr_stmt [28918,28936]
===
match
---
decorated [10417,10570]
decorated [10417,10570]
===
match
---
trailer [35790,35814]
trailer [35790,35814]
===
match
---
expr_stmt [9692,9703]
expr_stmt [9692,9703]
===
match
---
trailer [75318,75334]
trailer [75425,75441]
===
match
---
name: dep_context [36604,36615]
name: dep_context [36604,36615]
===
match
---
atom_expr [68326,68339]
atom_expr [68433,68446]
===
match
---
name: result [89109,89115]
name: result [89216,89222]
===
match
---
trailer [58367,58383]
trailer [58367,58383]
===
match
---
operator: @ [28310,28311]
operator: @ [28310,28311]
===
match
---
operator: , [41576,41577]
operator: , [41576,41577]
===
match
---
argument [13883,13897]
argument [13883,13897]
===
match
---
trailer [25629,25636]
trailer [25629,25636]
===
match
---
suite [59251,60624]
suite [59251,60624]
===
match
---
operator: = [61692,61693]
operator: = [61692,61693]
===
match
---
trailer [79872,79877]
trailer [79979,79984]
===
match
---
atom_expr [52682,52696]
atom_expr [52682,52696]
===
match
---
atom_expr [86250,86476]
atom_expr [86357,86583]
===
match
---
string: 'webserver' [23185,23196]
string: 'webserver' [23185,23196]
===
match
---
simple_stmt [4258,4272]
simple_stmt [4258,4272]
===
match
---
name: self [46469,46473]
name: self [46469,46473]
===
match
---
operator: = [58301,58302]
operator: = [58301,58302]
===
match
---
trailer [52688,52696]
trailer [52688,52696]
===
match
---
name: queue [27478,27483]
name: queue [27478,27483]
===
match
---
arglist [86272,86466]
arglist [86379,86573]
===
match
---
name: set_state [28549,28558]
name: set_state [28549,28558]
===
match
---
trailer [5059,5077]
trailer [5059,5077]
===
match
---
name: deprecated_proxy [75848,75864]
name: deprecated_proxy [75955,75971]
===
match
---
name: ignore_ti_state [18121,18136]
name: ignore_ti_state [18121,18136]
===
match
---
name: self [46107,46111]
name: self [46107,46111]
===
match
---
argument [76910,76925]
argument [77017,77032]
===
match
---
atom_expr [61969,61994]
atom_expr [61969,61994]
===
match
---
name: TaskInstance [30357,30369]
name: TaskInstance [30357,30369]
===
match
---
operator: , [15297,15298]
operator: , [15297,15298]
===
match
---
trailer [6998,7003]
trailer [6998,7003]
===
match
---
name: state [68320,68325]
name: state [68427,68432]
===
match
---
name: task_id [24299,24306]
name: task_id [24299,24306]
===
match
---
comparison [69271,69285]
comparison [69378,69392]
===
match
---
atom_expr [72090,72113]
atom_expr [72197,72220]
===
match
---
suite [59548,59840]
suite [59548,59840]
===
match
---
name: hostname [26301,26309]
name: hostname [26301,26309]
===
match
---
argument [83603,83632]
argument [83710,83739]
===
match
---
name: e [51755,51756]
name: e [51755,51756]
===
match
---
name: Session [66940,66947]
name: Session [67047,67054]
===
match
---
name: ti [6042,6044]
name: ti [6042,6044]
===
match
---
trailer [14286,14294]
trailer [14286,14294]
===
match
---
expr_stmt [13715,13904]
expr_stmt [13715,13904]
===
match
---
name: functools [1866,1875]
name: functools [1866,1875]
===
match
---
name: timezone [28821,28829]
name: timezone [28821,28829]
===
match
---
if_stmt [44162,44360]
if_stmt [44162,44360]
===
match
---
trailer [9932,9939]
trailer [9932,9939]
===
match
---
name: dag_id [91097,91103]
name: dag_id [91204,91210]
===
match
---
trailer [9105,9113]
trailer [9105,9113]
===
match
---
return_stmt [93406,93424]
return_stmt [93513,93531]
===
match
---
string: "DAG" [18496,18501]
string: "DAG" [18496,18501]
===
match
---
fstring_end: " [72435,72436]
fstring_end: " [72542,72543]
===
match
---
name: init_run_context [89906,89922]
name: init_run_context [90013,90029]
===
match
---
trailer [59101,59105]
trailer [59101,59105]
===
match
---
name: Exception [4979,4988]
name: Exception [4979,4988]
===
match
---
simple_stmt [10337,10412]
simple_stmt [10337,10412]
===
match
---
if_stmt [79850,80019]
if_stmt [79957,80126]
===
match
---
operator: , [80571,80572]
operator: , [80678,80679]
===
match
---
atom_expr [82934,82948]
atom_expr [83041,83055]
===
match
---
operator: , [83899,83900]
operator: , [84006,84007]
===
match
---
suite [54515,54580]
suite [54515,54580]
===
match
---
simple_stmt [43336,43367]
simple_stmt [43336,43367]
===
match
---
not_test [14952,14993]
not_test [14952,14993]
===
match
---
atom_expr [54882,54936]
atom_expr [54882,54936]
===
match
---
name: self [79765,79769]
name: self [79872,79876]
===
match
---
name: dag_id [9198,9204]
name: dag_id [9198,9204]
===
match
---
name: airflow [78205,78212]
name: airflow [78312,78319]
===
match
---
name: DAG [67218,67221]
name: DAG [67325,67328]
===
match
---
name: t [91108,91109]
name: t [91215,91216]
===
match
---
trailer [64276,64278]
trailer [64276,64278]
===
match
---
string: "TaskInstance.dag_id == DagModel.dag_id" [13563,13603]
string: "TaskInstance.dag_id == DagModel.dag_id" [13563,13603]
===
match
---
name: task_id [12948,12955]
name: task_id [12948,12955]
===
match
---
atom_expr [85060,85073]
atom_expr [85167,85180]
===
match
---
operator: , [75187,75188]
operator: , [75294,75295]
===
match
---
trailer [54637,54642]
trailer [54637,54642]
===
match
---
fstring_string: ?task_id= [23564,23573]
fstring_string: ?task_id= [23564,23573]
===
match
---
name: NamedTuple [9628,9638]
name: NamedTuple [9628,9638]
===
match
---
atom_expr [60563,60623]
atom_expr [60563,60623]
===
match
---
operator: = [55554,55555]
operator: = [55554,55555]
===
match
---
name: SIGTERM [52689,52696]
name: SIGTERM [52689,52696]
===
match
---
atom_expr [64512,64579]
atom_expr [64616,64686]
===
match
---
name: pickle_id [22260,22269]
name: pickle_id [22260,22269]
===
match
---
name: self [27683,27687]
name: self [27683,27687]
===
match
---
trailer [23143,23153]
trailer [23143,23153]
===
match
---
argument [84103,84118]
argument [84210,84225]
===
match
---
name: test_mode [49448,49457]
name: test_mode [49448,49457]
===
match
---
operator: , [50846,50847]
operator: , [50846,50847]
===
match
---
name: execution_date [88462,88476]
name: execution_date [88569,88583]
===
match
---
if_stmt [56076,56178]
if_stmt [56076,56178]
===
match
---
name: cache [68167,68172]
name: cache [68274,68279]
===
match
---
return_stmt [4828,4853]
return_stmt [4828,4853]
===
match
---
name: executor_config [80893,80908]
name: executor_config [81000,81015]
===
match
---
name: self [62746,62750]
name: self [62746,62750]
===
match
---
name: session [48867,48874]
name: session [48867,48874]
===
match
---
operator: , [75762,75763]
operator: , [75869,75870]
===
match
---
operator: = [54663,54664]
operator: = [54663,54664]
===
match
---
simple_stmt [72654,72719]
simple_stmt [72761,72826]
===
match
---
simple_stmt [92239,92274]
simple_stmt [92346,92381]
===
match
---
trailer [7125,7136]
trailer [7125,7136]
===
match
---
name: log [50536,50539]
name: log [50536,50539]
===
match
---
trailer [75503,75519]
trailer [75610,75626]
===
match
---
dotted_name [2984,2997]
dotted_name [2984,2997]
===
match
---
name: autoescape [83101,83111]
name: autoescape [83208,83218]
===
match
---
simple_stmt [67213,67233]
simple_stmt [67320,67340]
===
match
---
name: prev_ti [35201,35208]
name: prev_ti [35201,35208]
===
match
---
trailer [8403,8406]
trailer [8403,8406]
===
match
---
name: kube_config [80472,80483]
name: kube_config [80579,80590]
===
match
---
atom_expr [52823,52890]
atom_expr [52823,52890]
===
match
---
atom_expr [84850,84863]
atom_expr [84957,84970]
===
match
---
arglist [63872,63883]
arglist [63872,63883]
===
match
---
name: log [63767,63770]
name: log [63767,63770]
===
match
---
trailer [40923,40925]
trailer [40923,40925]
===
match
---
name: end_date [25946,25954]
name: end_date [25946,25954]
===
match
---
operator: , [78543,78544]
operator: , [78650,78651]
===
match
---
operator: , [77245,77246]
operator: , [77352,77353]
===
match
---
atom_expr [32108,32119]
atom_expr [32108,32119]
===
match
---
simple_stmt [84133,84187]
simple_stmt [84240,84294]
===
match
---
name: _priority_weight [92691,92707]
name: _priority_weight [92798,92814]
===
match
---
name: test_mode [48758,48767]
name: test_mode [48758,48767]
===
match
---
arglist [14582,14830]
arglist [14582,14830]
===
match
---
name: self [64259,64263]
name: self [64259,64263]
===
match
---
trailer [32806,32826]
trailer [32806,32826]
===
match
---
suite [84884,84963]
suite [84991,85070]
===
match
---
operator: = [43292,43293]
operator: = [43292,43293]
===
match
---
trailer [71572,71600]
trailer [71679,71707]
===
match
---
comparison [59926,59962]
comparison [59926,59962]
===
match
---
name: duration [29147,29155]
name: duration [29147,29155]
===
match
---
comparison [91085,91103]
comparison [91192,91210]
===
match
---
name: self [71491,71495]
name: self [71598,71602]
===
match
---
name: sqltypes [1789,1797]
name: sqltypes [1789,1797]
===
match
---
operator: , [3429,3430]
operator: , [3429,3430]
===
match
---
trailer [51152,51167]
trailer [51152,51167]
===
match
---
trailer [35002,35036]
trailer [35002,35036]
===
match
---
name: Optional [33509,33517]
name: Optional [33509,33517]
===
match
---
string: 'prev_execution_date' [76747,76768]
string: 'prev_execution_date' [76854,76875]
===
match
---
name: item [71513,71517]
name: item [71620,71624]
===
match
---
trailer [4771,4773]
trailer [4771,4773]
===
match
---
name: ready_for_retry [29521,29536]
name: ready_for_retry [29521,29536]
===
match
---
name: default_html_content_err [84331,84355]
name: default_html_content_err [84438,84462]
===
match
---
comparison [25617,25651]
comparison [25617,25651]
===
match
---
trailer [67938,67947]
trailer [68045,68054]
===
match
---
param [60982,61009]
param [60982,61009]
===
match
---
name: error_fd [61829,61837]
name: error_fd [61829,61837]
===
match
---
name: run_ids [8064,8071]
name: run_ids [8064,8071]
===
match
---
trailer [6233,6239]
trailer [6233,6239]
===
match
---
name: commit [50218,50224]
name: commit [50218,50224]
===
match
---
name: context [4264,4271]
name: context [4264,4271]
===
match
---
decorators [47736,47779]
decorators [47736,47779]
===
match
---
operator: , [43971,43972]
operator: , [43971,43972]
===
match
---
operator: = [3847,3848]
operator: = [3847,3848]
===
match
---
name: Optional [80060,80068]
name: Optional [80167,80175]
===
match
---
trailer [15209,15214]
trailer [15209,15214]
===
match
---
name: task_copy [62243,62252]
name: task_copy [62243,62252]
===
match
---
name: self [92785,92789]
name: self [92892,92896]
===
match
---
operator: = [7623,7624]
operator: = [7623,7624]
===
match
---
atom_expr [52668,52713]
atom_expr [52668,52713]
===
match
---
param [63378,63407]
param [63378,63407]
===
match
---
trailer [39129,39316]
trailer [39129,39316]
===
match
---
name: self [14103,14107]
name: self [14103,14107]
===
match
---
trailer [11990,11996]
trailer [11990,11996]
===
match
---
if_stmt [49441,49535]
if_stmt [49441,49535]
===
match
---
operator: , [30391,30392]
operator: , [30391,30392]
===
match
---
name: execution_date [85977,85991]
name: execution_date [86084,86098]
===
match
---
operator: , [19627,19628]
operator: , [19627,19628]
===
match
---
name: bool [63436,63440]
name: bool [63436,63440]
===
match
---
string: 'run_as_user' [92581,92594]
string: 'run_as_user' [92688,92701]
===
match
---
trailer [50315,50320]
trailer [50315,50320]
===
match
---
trailer [89423,89441]
trailer [89530,89548]
===
match
---
if_stmt [22876,22938]
if_stmt [22876,22938]
===
match
---
number: 0 [30490,30491]
number: 0 [30490,30491]
===
match
---
fstring_end: " [79678,79679]
fstring_end: " [79785,79786]
===
match
---
name: self [77390,77394]
name: self [77497,77501]
===
match
---
name: task [64319,64323]
name: task [64319,64323]
===
match
---
trailer [31674,31679]
trailer [31674,31679]
===
match
---
trailer [26483,26489]
trailer [26483,26489]
===
match
---
param [47893,47922]
param [47893,47922]
===
match
---
trailer [20133,20138]
trailer [20133,20138]
===
match
---
atom_expr [14367,14400]
atom_expr [14367,14400]
===
match
---
atom_expr [89836,89849]
atom_expr [89943,89956]
===
match
---
name: loaded_value [40680,40692]
name: loaded_value [40680,40692]
===
match
---
operator: , [19995,19996]
operator: , [19995,19996]
===
match
---
name: _update_ti_state_for_sensing [54824,54852]
name: _update_ti_state_for_sensing [54824,54852]
===
match
---
atom_expr [40661,40692]
atom_expr [40661,40692]
===
match
---
name: get_next_ds [74210,74221]
name: get_next_ds [74317,74328]
===
match
---
arglist [53343,53463]
arglist [53343,53463]
===
match
---
simple_stmt [79696,79721]
simple_stmt [79803,79828]
===
match
---
name: self [64199,64203]
name: self [64199,64203]
===
match
---
name: models [2547,2553]
name: models [2547,2553]
===
match
---
operator: , [88592,88593]
operator: , [88699,88700]
===
match
---
operator: = [13674,13675]
operator: = [13674,13675]
===
match
---
fstring_end: " [23307,23308]
fstring_end: " [23307,23308]
===
match
---
simple_stmt [47205,47263]
simple_stmt [47205,47263]
===
match
---
operator: , [5414,5415]
operator: , [5414,5415]
===
match
---
operator: = [19623,19624]
operator: = [19623,19624]
===
match
---
if_stmt [73468,73782]
if_stmt [73575,73889]
===
match
---
not_test [46608,46621]
not_test [46608,46621]
===
match
---
name: file_path [22879,22888]
name: file_path [22879,22888]
===
match
---
arith_expr [38599,38618]
arith_expr [38599,38618]
===
match
---
name: self [44855,44859]
name: self [44855,44859]
===
match
---
name: task [31665,31669]
name: task [31665,31669]
===
match
---
name: State [65431,65436]
name: State [65538,65543]
===
match
---
import_from [2694,2727]
import_from [2694,2727]
===
match
---
name: __repr__ [37862,37870]
name: __repr__ [37862,37870]
===
match
---
operator: = [91953,91954]
operator: = [92060,92061]
===
match
---
dotted_name [1609,1634]
dotted_name [1609,1634]
===
match
---
operator: , [90988,90989]
operator: , [91095,91096]
===
match
---
simple_stmt [23364,23393]
simple_stmt [23364,23393]
===
match
---
string: "Error when executing on_success_callback" [60166,60208]
string: "Error when executing on_success_callback" [60166,60208]
===
match
---
simple_stmt [35359,35507]
simple_stmt [35359,35507]
===
match
---
operator: = [20280,20281]
operator: = [20280,20281]
===
match
---
operator: , [11814,11815]
operator: , [11814,11815]
===
match
---
trailer [83396,83413]
trailer [83503,83520]
===
match
---
name: Context [80069,80076]
name: Context [80176,80183]
===
match
---
name: self [92921,92925]
name: self [93028,93032]
===
match
---
trailer [48965,48972]
trailer [48965,48972]
===
match
---
operator: , [89849,89850]
operator: , [89956,89957]
===
match
---
expr_stmt [3742,3758]
expr_stmt [3742,3758]
===
match
---
operator: , [37281,37282]
operator: , [37281,37282]
===
match
---
expr_stmt [12559,12593]
expr_stmt [12559,12593]
===
match
---
atom_expr [46894,46971]
atom_expr [46894,46971]
===
match
---
suite [65552,65695]
suite [65659,65802]
===
match
---
name: state [46489,46494]
name: state [46489,46494]
===
match
---
simple_stmt [52113,52133]
simple_stmt [52113,52133]
===
match
---
parameters [92993,92999]
parameters [93100,93106]
===
match
---
name: state [50144,50149]
name: state [50144,50149]
===
match
---
trailer [63222,63229]
trailer [63222,63229]
===
match
---
name: get_prev_data_interval_start_success [68622,68658]
name: get_prev_data_interval_start_success [68729,68765]
===
match
---
operator: = [15679,15680]
operator: = [15679,15680]
===
match
---
atom_expr [84033,84041]
atom_expr [84140,84148]
===
match
---
operator: , [80753,80754]
operator: , [80860,80861]
===
match
---
atom_expr [46576,46589]
atom_expr [46576,46589]
===
match
---
trailer [12197,12223]
trailer [12197,12223]
===
match
---
with_stmt [5050,5324]
with_stmt [5050,5324]
===
match
---
trailer [64736,64748]
trailer [64843,64855]
===
match
---
argument [11865,11874]
argument [11865,11874]
===
match
---
name: self [27078,27082]
name: self [27078,27082]
===
match
---
operator: } [15872,15873]
operator: } [15872,15873]
===
match
---
atom_expr [49943,49955]
atom_expr [49943,49955]
===
match
---
simple_stmt [33691,33939]
simple_stmt [33691,33939]
===
match
---
name: get_email_subject_content [81263,81288]
name: get_email_subject_content [81370,81395]
===
match
---
name: Optional [34084,34092]
name: Optional [34084,34092]
===
match
---
name: renderedtifields [79256,79272]
name: renderedtifields [79363,79379]
===
match
---
simple_stmt [68568,68609]
simple_stmt [68675,68716]
===
match
---
operator: , [77858,77859]
operator: , [77965,77966]
===
match
---
name: airflow [2584,2591]
name: airflow [2584,2591]
===
match
---
operator: = [83715,83716]
operator: = [83822,83823]
===
match
---
name: result [57437,57443]
name: result [57437,57443]
===
match
---
operator: @ [70886,70887]
operator: @ [70993,70994]
===
match
---
fstring_end: " [23624,23625]
fstring_end: " [23624,23625]
===
match
---
trailer [47568,47576]
trailer [47568,47576]
===
match
---
simple_stmt [79470,79517]
simple_stmt [79577,79624]
===
match
---
name: RenderedTaskInstanceFields [52956,52982]
name: RenderedTaskInstanceFields [52956,52982]
===
match
---
trailer [84737,84743]
trailer [84844,84850]
===
match
---
decorated [74668,74897]
decorated [74775,75004]
===
match
---
name: execution_date [15365,15379]
name: execution_date [15365,15379]
===
match
---
param [24941,24954]
param [24941,24954]
===
match
---
atom_expr [67752,67792]
atom_expr [67859,67899]
===
match
---
name: query [89335,89340]
name: query [89442,89447]
===
match
---
operator: = [13723,13724]
operator: = [13723,13724]
===
match
---
trailer [7870,7878]
trailer [7870,7878]
===
match
---
name: from_obj [80879,80887]
name: from_obj [80986,80994]
===
match
---
atom_expr [11574,11592]
atom_expr [11574,11592]
===
match
---
name: queued_dttm [26612,26623]
name: queued_dttm [26612,26623]
===
match
---
parameters [10438,10444]
parameters [10438,10444]
===
match
---
return_stmt [72539,72586]
return_stmt [72646,72693]
===
match
---
trailer [74619,74637]
trailer [74726,74744]
===
match
---
name: dag_id [80565,80571]
name: dag_id [80672,80678]
===
match
---
name: get_email_subject_content [84566,84591]
name: get_email_subject_content [84673,84698]
===
match
---
name: subject [84133,84140]
name: subject [84240,84247]
===
match
---
name: session [64500,64507]
name: session [64604,64611]
===
match
---
operator: , [77056,77057]
operator: , [77163,77164]
===
match
---
name: log [28056,28059]
name: log [28056,28059]
===
match
---
arglist [11856,11890]
arglist [11856,11890]
===
match
---
name: fd [5320,5322]
name: fd [5320,5322]
===
match
---
trailer [49565,49573]
trailer [49565,49573]
===
match
---
name: staticmethod [70887,70899]
name: staticmethod [70994,71006]
===
match
---
name: log [60568,60571]
name: log [60568,60571]
===
match
---
name: first [25798,25803]
name: first [25798,25803]
===
match
---
name: execution_date [74789,74803]
name: execution_date [74896,74910]
===
match
---
atom [89629,89896]
atom [89736,90003]
===
match
---
name: TaskInstance [91302,91314]
name: TaskInstance [91409,91421]
===
match
---
trailer [92406,92417]
trailer [92513,92524]
===
match
---
name: DagRun [40845,40851]
name: DagRun [40845,40851]
===
match
---
arglist [11803,11830]
arglist [11803,11830]
===
match
---
trailer [50311,50315]
trailer [50311,50315]
===
match
---
operator: = [54539,54540]
operator: = [54539,54540]
===
match
---
decorator [10417,10427]
decorator [10417,10427]
===
match
---
tfpdef [47931,47950]
tfpdef [47931,47950]
===
match
---
trailer [64221,64230]
trailer [64221,64230]
===
match
---
expr_stmt [26607,26640]
expr_stmt [26607,26640]
===
match
---
operator: , [39348,39349]
operator: , [39348,39349]
===
match
---
argument [19338,19369]
argument [19338,19369]
===
match
---
operator: = [13839,13840]
operator: = [13839,13840]
===
match
---
param [47931,47958]
param [47931,47958]
===
match
---
name: PodGenerator [3705,3717]
name: PodGenerator [3705,3717]
===
match
---
name: email_for_state [65880,65895]
name: email_for_state [65987,66002]
===
match
---
funcdef [78085,79102]
funcdef [78192,79209]
===
match
---
trailer [76469,76505]
trailer [76576,76612]
===
match
---
name: queue [11896,11901]
name: queue [11896,11901]
===
match
---
atom_expr [24294,24306]
atom_expr [24294,24306]
===
match
---
simple_stmt [22283,22324]
simple_stmt [22283,22324]
===
match
---
suite [56096,56178]
suite [56096,56178]
===
match
---
operator: , [40448,40449]
operator: , [40448,40449]
===
match
---
simple_stmt [65456,65496]
simple_stmt [65563,65603]
===
match
---
name: state [6234,6239]
name: state [6234,6239]
===
match
---
operator: = [43955,43956]
operator: = [43955,43956]
===
match
---
argument [75764,75777]
argument [75871,75884]
===
match
---
simple_stmt [55262,55334]
simple_stmt [55262,55334]
===
match
---
if_stmt [50089,50227]
if_stmt [50089,50227]
===
match
---
atom_expr [30191,30223]
atom_expr [30191,30223]
===
match
---
name: session [51222,51229]
name: session [51222,51229]
===
match
---
trailer [66019,66023]
trailer [66126,66130]
===
match
---
name: getattr [56027,56034]
name: getattr [56027,56034]
===
match
---
if_stmt [67123,67180]
if_stmt [67230,67287]
===
match
---
fstring_end: " [72254,72255]
fstring_end: " [72361,72362]
===
match
---
parameters [34053,34144]
parameters [34053,34144]
===
match
---
operator: , [4493,4494]
operator: , [4493,4494]
===
match
---
trailer [77306,77314]
trailer [77413,77421]
===
match
---
simple_stmt [71755,71790]
simple_stmt [71862,71897]
===
match
---
name: update [53502,53508]
name: update [53502,53508]
===
match
---
expr_stmt [43613,43646]
expr_stmt [43613,43646]
===
match
---
name: task [52847,52851]
name: task [52847,52851]
===
match
---
name: __name__ [3867,3875]
name: __name__ [3867,3875]
===
match
---
atom_expr [9583,9596]
atom_expr [9583,9596]
===
match
---
name: airflow [1894,1901]
name: airflow [1894,1901]
===
match
---
expr_stmt [65456,65495]
expr_stmt [65563,65602]
===
match
---
operator: , [47051,47052]
operator: , [47051,47052]
===
match
---
simple_stmt [48952,48975]
simple_stmt [48952,48975]
===
match
---
trailer [92362,92371]
trailer [92469,92478]
===
match
---
trailer [79514,79516]
trailer [79621,79623]
===
match
---
parameters [9791,9797]
parameters [9791,9797]
===
match
---
name: NONE [45624,45628]
name: NONE [45624,45628]
===
match
---
simple_stmt [33427,33457]
simple_stmt [33427,33457]
===
match
---
name: NO_VALUE [1642,1650]
name: NO_VALUE [1642,1650]
===
match
---
simple_stmt [34185,34401]
simple_stmt [34185,34401]
===
match
---
suite [65509,65789]
suite [65616,65896]
===
match
---
trailer [51510,51517]
trailer [51510,51517]
===
match
---
atom [12783,13491]
atom [12783,13491]
===
match
---
arglist [13328,13474]
arglist [13328,13474]
===
match
---
simple_stmt [29084,29130]
simple_stmt [29084,29130]
===
match
---
name: _get_previous_dagrun_data_interval_success [68981,69023]
name: _get_previous_dagrun_data_interval_success [69088,69130]
===
match
---
operator: = [27471,27472]
operator: = [27471,27472]
===
match
---
operator: , [37263,37264]
operator: , [37263,37264]
===
match
---
trailer [30201,30223]
trailer [30201,30223]
===
match
---
operator: = [4308,4309]
operator: = [4308,4309]
===
match
---
suite [5158,5324]
suite [5158,5324]
===
match
---
decorator [47757,47779]
decorator [47757,47779]
===
match
---
simple_stmt [40185,40304]
simple_stmt [40185,40304]
===
match
---
name: run_id [91603,91609]
name: run_id [91710,91716]
===
match
---
operator: -> [93696,93698]
operator: -> [93803,93805]
===
match
---
name: task_id [9919,9926]
name: task_id [9919,9926]
===
match
---
atom_expr [16067,16077]
atom_expr [16067,16077]
===
match
---
operator: , [46310,46311]
operator: , [46310,46311]
===
match
---
suite [89524,89897]
suite [89631,90004]
===
match
---
atom_expr [28051,28087]
atom_expr [28051,28087]
===
match
---
operator: = [47993,47994]
operator: = [47993,47994]
===
match
---
trailer [43311,43318]
trailer [43311,43318]
===
match
---
operator: } [23586,23587]
operator: } [23586,23587]
===
match
---
string: 'prev_data_interval_start_success' [76301,76335]
string: 'prev_data_interval_start_success' [76408,76442]
===
match
---
name: self [29084,29088]
name: self [29084,29088]
===
match
---
name: with_entities [89125,89138]
name: with_entities [89232,89245]
===
match
---
return_stmt [35779,35835]
return_stmt [35779,35835]
===
match
---
name: self [37871,37875]
name: self [37871,37875]
===
match
---
trailer [53320,53325]
trailer [53320,53325]
===
match
---
simple_stmt [9692,9704]
simple_stmt [9692,9704]
===
match
---
trailer [7114,7121]
trailer [7114,7121]
===
match
---
fstring_string: __ [77315,77317]
fstring_string: __ [77422,77424]
===
match
---
trailer [80742,80753]
trailer [80849,80860]
===
match
---
operator: , [76505,76506]
operator: , [76612,76613]
===
match
---
operator: = [61025,61026]
operator: = [61025,61026]
===
match
---
name: commit [44322,44328]
name: commit [44322,44328]
===
match
---
name: Sentry [47758,47764]
name: Sentry [47758,47764]
===
match
---
operator: , [39222,39223]
operator: , [39222,39223]
===
match
---
atom_expr [11735,11755]
atom_expr [11735,11755]
===
match
---
arith_expr [84914,84945]
arith_expr [85021,85052]
===
match
---
simple_stmt [58158,58180]
simple_stmt [58158,58180]
===
match
---
number: 1 [83683,83684]
number: 1 [83790,83791]
===
match
---
name: priority_weight [13011,13026]
name: priority_weight [13011,13026]
===
match
---
operator: , [2289,2290]
operator: , [2289,2290]
===
match
---
atom_expr [29020,29034]
atom_expr [29020,29034]
===
match
---
suite [30993,31018]
suite [30993,31018]
===
match
---
name: LoggingMixin [3148,3160]
name: LoggingMixin [3148,3160]
===
match
---
simple_stmt [7016,7047]
simple_stmt [7016,7047]
===
match
---
name: AirflowTaskTimeout [57088,57106]
name: AirflowTaskTimeout [57088,57106]
===
match
---
trailer [10359,10411]
trailer [10359,10411]
===
match
---
name: add [64508,64511]
name: add [64612,64615]
===
match
---
name: info [50540,50544]
name: info [50540,50544]
===
match
---
name: self [79490,79494]
name: self [79597,79601]
===
match
---
name: self [64527,64531]
name: dag_run [64631,64638]
===
match
---
expr_stmt [6498,6525]
expr_stmt [6498,6525]
===
match
---
simple_stmt [22736,22760]
simple_stmt [22736,22760]
===
match
---
name: ti [92311,92313]
name: ti [92418,92420]
===
match
---
trailer [6914,6924]
trailer [6914,6924]
===
match
---
atom_expr [37470,37518]
atom_expr [37470,37518]
===
match
---
name: self [47283,47287]
name: self [47283,47287]
===
match
---
name: job_id [13056,13062]
name: job_id [13056,13062]
===
match
---
name: str [92930,92933]
name: str [93037,93040]
===
match
---
name: tis [5356,5359]
name: tis [5356,5359]
===
match
---
arglist [45731,45957]
arglist [45731,45957]
===
match
---
suite [4704,4725]
suite [4704,4725]
===
match
---
return_stmt [10100,10191]
return_stmt [10100,10191]
===
match
---
arglist [46454,46473]
arglist [46454,46473]
===
match
---
name: self [19241,19245]
name: self [19241,19245]
===
match
---
name: self [28332,28336]
name: self [28332,28336]
===
match
---
trailer [84591,84602]
trailer [84698,84709]
===
match
---
name: _state [93418,93424]
name: _state [93525,93531]
===
match
---
operator: = [81849,81850]
operator: = [81956,81957]
===
match
---
name: task [27117,27121]
name: task [27117,27121]
===
match
---
name: render_templates [53025,53041]
name: render_templates [53025,53041]
===
match
---
decorated [34001,34600]
decorated [34001,34600]
===
match
---
name: session [29595,29602]
name: session [29595,29602]
===
match
---
atom_expr [91812,91826]
atom_expr [91919,91933]
===
match
---
name: utils [3284,3289]
name: utils [3284,3289]
===
match
---
simple_stmt [71250,71445]
simple_stmt [71357,71552]
===
match
---
arglist [68131,68138]
arglist [68238,68245]
===
match
---
string: 'tomorrow_ds_nodash' [77556,77576]
string: 'tomorrow_ds_nodash' [77663,77683]
===
match
---
string: "--cfg-path" [22983,22995]
string: "--cfg-path" [22983,22995]
===
match
---
name: self [38599,38603]
name: self [38599,38603]
===
match
---
trailer [30712,30722]
trailer [30712,30722]
===
match
---
expr_stmt [58048,58085]
expr_stmt [58048,58085]
===
match
---
param [93067,93071]
param [93174,93178]
===
match
---
name: TemplateAssertionError [78664,78686]
name: TemplateAssertionError [78771,78793]
===
match
---
operator: , [45916,45917]
operator: , [45916,45917]
===
match
---
testlist_comp [22801,22815]
testlist_comp [22801,22815]
===
match
---
name: self [83789,83793]
name: self [83896,83900]
===
match
---
atom_expr [9277,9302]
atom_expr [9277,9302]
===
match
---
name: utcnow [44727,44733]
name: utcnow [44727,44733]
===
match
---
name: operator [26572,26580]
name: operator [26572,26580]
===
match
---
name: session [52251,52258]
name: session [52251,52258]
===
match
---
simple_stmt [57124,57144]
simple_stmt [57124,57144]
===
match
---
atom_expr [38241,38276]
atom_expr [38241,38276]
===
match
---
expr_stmt [53220,53299]
expr_stmt [53220,53299]
===
match
---
name: get_previous_dagrun [68300,68319]
name: get_previous_dagrun [68407,68426]
===
match
---
name: tis [90514,90517]
name: tis [90621,90624]
===
match
---
operator: = [86649,86650]
operator: = [86756,86757]
===
match
---
name: BaseJob [8380,8387]
name: BaseJob [8380,8387]
===
match
---
operator: , [52696,52697]
operator: , [52696,52697]
===
match
---
name: orm [1565,1568]
name: orm [1565,1568]
===
match
---
expr_stmt [8190,8242]
expr_stmt [8190,8242]
===
match
---
param [89923,89928]
param [90030,90035]
===
match
---
name: html_content [84382,84394]
name: html_content [84489,84501]
===
match
---
name: task_id_by_key [7162,7176]
name: task_id_by_key [7162,7176]
===
match
---
sync_comp_for [91041,91053]
sync_comp_for [91148,91160]
===
match
---
trailer [53266,53299]
trailer [53266,53299]
===
match
---
trailer [40028,40044]
trailer [40028,40044]
===
match
---
param [66931,66955]
param [67038,67062]
===
match
---
import_from [937,977]
import_from [937,977]
===
match
---
name: dag [18736,18739]
name: dag [18736,18739]
===
match
---
atom_expr [92491,92509]
atom_expr [92598,92616]
===
match
---
name: execution_date [85176,85190]
name: execution_date [85283,85297]
===
match
---
atom_expr [59990,60017]
atom_expr [59990,60017]
===
match
---
operator: == [91323,91325]
operator: == [91430,91432]
===
match
---
param [9971,9975]
param [9971,9975]
===
match
---
atom_expr [73597,73622]
atom_expr [73704,73729]
===
match
---
simple_stmt [81125,81157]
simple_stmt [81232,81264]
===
match
---
name: execute_callable [56140,56156]
name: execute_callable [56140,56156]
===
match
---
atom_expr [48929,48943]
atom_expr [48929,48943]
===
match
---
param [66232,66237]
param [66339,66344]
===
match
---
arith_expr [6557,6589]
arith_expr [6557,6589]
===
match
---
operator: , [13541,13542]
operator: , [13541,13542]
===
match
---
operator: = [67193,67194]
operator: = [67300,67301]
===
match
---
expr_stmt [93826,93845]
expr_stmt [93933,93952]
===
match
---
simple_stmt [43204,43231]
simple_stmt [43204,43231]
===
match
---
name: get_template_context [59580,59600]
name: get_template_context [59580,59600]
===
match
---
name: ti [26920,26922]
name: ti [26920,26922]
===
match
---
name: instance [35233,35241]
name: instance [35233,35241]
===
match
---
name: self [33954,33958]
name: self [33954,33958]
===
match
---
atom_expr [44828,44885]
atom_expr [44828,44885]
===
match
---
operator: == [25588,25590]
operator: == [25588,25590]
===
match
---
atom_expr [30357,30376]
atom_expr [30357,30376]
===
match
---
decorated [29241,29539]
decorated [29241,29539]
===
match
---
expr_stmt [68100,68156]
expr_stmt [68207,68263]
===
match
---
operator: @ [89453,89454]
operator: @ [89560,89561]
===
match
---
name: strftime [74875,74883]
name: strftime [74982,74990]
===
match
---
name: Column [12416,12422]
name: Column [12416,12422]
===
match
---
name: State [29489,29494]
name: State [29489,29494]
===
match
---
name: deserialize_json [70748,70764]
name: deserialize_json [70855,70871]
===
match
---
operator: == [24344,24346]
operator: == [24344,24346]
===
match
---
simple_stmt [72539,72587]
simple_stmt [72646,72694]
===
match
---
atom_expr [38558,38621]
atom_expr [38558,38621]
===
match
---
dictorsetmaker [82552,82562]
dictorsetmaker [82659,82669]
===
match
---
operator: } [52858,52859]
operator: } [52858,52859]
===
match
---
operator: { [37910,37911]
operator: { [37910,37911]
===
match
---
name: overwrite_params_with_dag_run_conf [79730,79764]
name: overwrite_params_with_dag_run_conf [79837,79871]
===
match
---
name: hostname [16099,16107]
name: hostname [16099,16107]
===
match
---
name: state [16080,16085]
name: state [16080,16085]
===
match
---
param [60796,60827]
param [60796,60827]
===
match
---
trailer [23417,23432]
trailer [23417,23432]
===
match
---
comparison [58241,58266]
comparison [58241,58266]
===
match
---
suite [93635,93663]
suite [93742,93770]
===
match
---
name: task_id [7871,7878]
name: task_id [7871,7878]
===
match
---
name: self [46940,46944]
name: self [46940,46944]
===
match
---
operator: , [20034,20035]
operator: , [20034,20035]
===
match
---
operator: , [59194,59195]
operator: , [59194,59195]
===
match
---
trailer [49918,49925]
trailer [49918,49925]
===
match
---
name: str [32476,32479]
name: str [32476,32479]
===
match
---
name: task [30318,30322]
name: task [30318,30322]
===
match
---
trailer [48745,48755]
trailer [48745,48755]
===
match
---
expr_stmt [19140,19156]
expr_stmt [19140,19156]
===
match
---
import_from [1846,1888]
import_from [1846,1888]
===
match
---
operator: , [1288,1289]
operator: , [1288,1289]
===
match
---
trailer [92493,92509]
trailer [92600,92616]
===
match
---
operator: @ [72830,72831]
operator: @ [72937,72938]
===
match
---
simple_stmt [901,937]
simple_stmt [901,937]
===
match
---
trailer [49162,49167]
trailer [49162,49167]
===
match
---
name: self [82558,82562]
name: self [82665,82669]
===
match
---
trailer [29146,29155]
trailer [29146,29155]
===
match
---
simple_stmt [9532,9567]
simple_stmt [9532,9567]
===
match
---
name: context [53267,53274]
name: context [53267,53274]
===
match
---
name: self [59439,59443]
name: self [59439,59443]
===
match
---
arglist [91726,91788]
arglist [91833,91895]
===
match
---
return_stmt [93331,93354]
return_stmt [93438,93461]
===
match
---
operator: = [68118,68119]
operator: = [68225,68226]
===
match
---
simple_stmt [91162,91355]
simple_stmt [91269,91462]
===
match
---
tfpdef [63378,63406]
tfpdef [63378,63406]
===
match
---
trailer [6429,6438]
trailer [6429,6438]
===
match
---
name: airflow [2358,2365]
name: airflow [2358,2365]
===
match
---
trailer [52117,52130]
trailer [52117,52130]
===
match
---
trailer [40896,40903]
trailer [40896,40903]
===
match
---
name: self [93226,93230]
name: self [93333,93337]
===
match
---
sync_comp_for [91827,91840]
sync_comp_for [91934,91947]
===
match
---
operator: = [11262,11263]
operator: = [11262,11263]
===
match
---
atom_expr [37697,37714]
atom_expr [37697,37714]
===
match
---
name: trigger_id [13096,13106]
name: trigger_id [13096,13106]
===
match
---
name: _execute_task_with_callbacks [52277,52305]
name: _execute_task_with_callbacks [52277,52305]
===
match
---
trailer [61618,61631]
trailer [61618,61631]
===
match
---
argument [35747,35759]
argument [35747,35759]
===
match
---
atom_expr [28127,28138]
atom_expr [28127,28138]
===
match
---
trailer [53126,53133]
trailer [53126,53133]
===
match
---
name: first [44878,44883]
name: first [44878,44883]
===
match
---
param [4588,4601]
param [4588,4601]
===
match
---
param [47824,47851]
param [47824,47851]
===
match
---
operator: , [72062,72063]
operator: , [72169,72170]
===
match
---
arglist [12924,12970]
arglist [12924,12970]
===
match
---
trailer [75524,75539]
trailer [75631,75646]
===
match
---
atom_expr [26398,26407]
atom_expr [26398,26407]
===
match
---
fstring_expr [49138,49156]
fstring_expr [49138,49156]
===
match
---
atom_expr [22846,22867]
atom_expr [22846,22867]
===
match
---
atom_expr [6000,6008]
atom_expr [6000,6008]
===
match
---
name: Optional [20266,20274]
name: Optional [20266,20274]
===
match
---
name: include_prior_dates [88706,88725]
name: include_prior_dates [88813,88832]
===
match
---
name: str [92175,92178]
name: str [92282,92285]
===
match
---
simple_stmt [43492,43533]
simple_stmt [43492,43533]
===
match
---
name: dag_run_state [8810,8823]
name: dag_run_state [8810,8823]
===
match
---
string: "execution_date" [14058,14074]
string: "execution_date" [14058,14074]
===
match
---
name: reason [37051,37057]
name: reason [37051,37057]
===
match
---
string: 'yesterday_ds_nodash' [77956,77977]
string: 'yesterday_ds_nodash' [78063,78084]
===
match
---
operator: = [39023,39024]
operator: = [39023,39024]
===
match
---
operator: += [46394,46396]
operator: += [46394,46396]
===
match
---
simple_stmt [11966,11998]
simple_stmt [11966,11998]
===
match
---
import_from [2304,2352]
import_from [2304,2352]
===
match
---
expr_stmt [58003,58039]
expr_stmt [58003,58039]
===
match
---
trailer [60996,61001]
trailer [60996,61001]
===
match
---
name: on_failure_callback [59516,59535]
name: on_failure_callback [59516,59535]
===
match
---
argument [61818,61842]
argument [61818,61842]
===
match
---
simple_stmt [92462,92510]
simple_stmt [92569,92617]
===
match
---
name: commit [24880,24886]
name: commit [24880,24886]
===
match
---
operator: , [1483,1484]
operator: , [1483,1484]
===
match
---
trailer [81151,81156]
trailer [81258,81263]
===
match
---
name: task [64521,64525]
name: task [64625,64629]
===
match
---
name: pool [61796,61800]
name: pool [61796,61800]
===
match
---
name: dag_run [40672,40679]
name: dag_run [40672,40679]
===
match
---
name: interval_start [67735,67749]
name: interval_start [67842,67856]
===
match
---
name: ignore_ti_state [19489,19504]
name: ignore_ti_state [19489,19504]
===
match
---
string: "--ignore-depends-on-past" [22613,22639]
string: "--ignore-depends-on-past" [22613,22639]
===
match
---
operator: = [61867,61868]
operator: = [61867,61868]
===
match
---
decorated [30555,32399]
decorated [30555,32399]
===
match
---
name: trigger_row [57743,57754]
name: trigger_row [57743,57754]
===
match
---
name: airflow [14477,14484]
name: airflow [14477,14484]
===
match
---
fstring_string: operator_failures_ [64300,64318]
fstring_string: operator_failures_ [64300,64318]
===
match
---
simple_stmt [80371,80463]
simple_stmt [80478,80570]
===
match
---
subscriptlist [4974,4988]
subscriptlist [4974,4988]
===
match
---
atom [24139,24402]
atom [24139,24402]
===
match
---
tfpdef [19919,19947]
tfpdef [19919,19947]
===
match
---
operator: , [40888,40889]
operator: , [40888,40889]
===
match
---
if_stmt [7159,8279]
if_stmt [7159,8279]
===
match
---
atom_expr [37736,37753]
atom_expr [37736,37753]
===
match
---
name: path [18983,18987]
name: path [18983,18987]
===
match
---
name: AirflowFailException [50929,50949]
name: AirflowFailException [50929,50949]
===
match
---
simple_stmt [25397,25456]
simple_stmt [25397,25456]
===
match
---
name: execution_date [34584,34598]
name: execution_date [34584,34598]
===
match
---
arglist [27049,27082]
arglist [27049,27082]
===
match
---
operator: = [41482,41483]
operator: = [41482,41483]
===
match
---
operator: , [13941,13942]
operator: , [13941,13942]
===
match
---
trailer [33958,33974]
trailer [33958,33974]
===
match
---
name: TaskInstance [30405,30417]
name: TaskInstance [30405,30417]
===
match
---
name: Column [11977,11983]
name: Column [11977,11983]
===
match
---
name: task_id [25580,25587]
name: task_id [25580,25587]
===
match
---
string: """Load and return error from error file""" [4643,4686]
string: """Load and return error from error file""" [4643,4686]
===
match
---
expr_stmt [12398,12435]
expr_stmt [12398,12435]
===
match
---
atom_expr [25943,25954]
atom_expr [25943,25954]
===
match
---
operator: @ [27809,27810]
operator: @ [27809,27810]
===
match
---
name: try_number [9741,9751]
name: try_number [9741,9751]
===
match
---
parameters [29588,29608]
parameters [29588,29608]
===
match
---
if_stmt [22826,22868]
if_stmt [22826,22868]
===
match
---
name: task [58983,58987]
name: task [58983,58987]
===
match
---
trailer [56587,56598]
trailer [56587,56598]
===
match
---
arglist [77528,77576]
arglist [77635,77683]
===
match
---
name: upper [47518,47523]
name: upper [47518,47523]
===
match
---
name: self [54882,54886]
name: self [54882,54886]
===
match
---
trailer [83793,83798]
trailer [83900,83905]
===
match
---
trailer [62235,62240]
trailer [62235,62240]
===
match
---
name: raw [18197,18200]
name: raw [18197,18200]
===
match
---
arglist [11305,11371]
arglist [11305,11371]
===
match
---
param [19965,19996]
param [19965,19996]
===
match
---
operator: = [84141,84142]
operator: = [84248,84249]
===
match
---
simple_stmt [92943,92963]
simple_stmt [93050,93070]
===
match
---
trailer [62311,62313]
trailer [62311,62313]
===
match
---
name: self [27492,27496]
name: self [27492,27496]
===
match
---
atom_expr [49158,49175]
atom_expr [49158,49175]
===
match
---
strings [81865,82137]
strings [81972,82244]
===
match
---
name: self [51944,51948]
name: self [51944,51948]
===
match
---
name: timezone [46059,46067]
name: timezone [46059,46067]
===
match
---
trailer [29042,29048]
trailer [29042,29048]
===
match
---
name: Any [71712,71715]
name: Any [71819,71822]
===
match
---
atom_expr [89042,89056]
atom_expr [89149,89163]
===
match
---
name: task_retries [6573,6585]
name: task_retries [6573,6585]
===
match
---
string: "Task successfully registered in smart sensor." [55155,55202]
string: "Task successfully registered in smart sensor." [55155,55202]
===
match
---
name: params [67502,67508]
name: params [67609,67615]
===
match
---
name: ignore_depends_on_past [22565,22587]
name: ignore_depends_on_past [22565,22587]
===
match
---
suite [58967,59059]
suite [58967,59059]
===
match
---
name: query [24161,24166]
name: query [24161,24166]
===
match
---
trailer [65773,65788]
trailer [65880,65895]
===
match
---
operator: } [54749,54750]
operator: } [54749,54750]
===
match
---
atom_expr [63215,63231]
atom_expr [63215,63231]
===
match
---
operator: = [20056,20057]
operator: = [20056,20057]
===
match
---
name: session [30177,30184]
name: session [30177,30184]
===
match
---
operator: @ [93114,93115]
operator: @ [93221,93222]
===
match
---
decorator [69996,70010]
decorator [70103,70117]
===
match
---
atom_expr [91262,91270]
atom_expr [91369,91377]
===
match
---
operator: , [72059,72060]
operator: , [72166,72167]
===
match
---
not_test [31131,31137]
not_test [31131,31137]
===
match
---
name: self [38208,38212]
name: self [38208,38212]
===
match
---
trailer [39249,39260]
trailer [39249,39260]
===
match
---
name: Context [3780,3787]
name: Context [3780,3787]
===
match
---
name: run_ids [8137,8144]
name: run_ids [8137,8144]
===
match
---
name: _run_raw_task [61649,61662]
name: _run_raw_task [61649,61662]
===
match
---
name: session [8366,8373]
name: session [8366,8373]
===
match
---
operator: + [43634,43635]
operator: + [43634,43635]
===
match
---
name: self [59901,59905]
name: self [59901,59905]
===
match
---
expr_stmt [26739,26780]
expr_stmt [26739,26780]
===
match
---
trailer [25531,25538]
trailer [25531,25538]
===
match
---
operator: = [60927,60928]
operator: = [60927,60928]
===
match
---
trailer [40338,40351]
trailer [40338,40351]
===
match
---
name: get_previous_execution_date [76861,76888]
name: get_previous_execution_date [76968,76995]
===
match
---
simple_stmt [49045,49062]
simple_stmt [49045,49062]
===
match
---
name: schedule [31712,31720]
name: schedule [31712,31720]
===
match
---
name: DeprecationWarning [33883,33901]
name: DeprecationWarning [33883,33901]
===
match
---
name: _log [14360,14364]
name: _log [14360,14364]
===
match
---
simple_stmt [58003,58040]
simple_stmt [58003,58040]
===
match
---
atom [51721,51751]
atom [51721,51751]
===
match
---
decorator [93199,93209]
decorator [93306,93316]
===
match
---
argument [44212,44251]
argument [44212,44251]
===
match
---
parameters [16448,16454]
parameters [16448,16454]
===
match
---
operator: = [3752,3753]
operator: = [3752,3753]
===
match
---
expr_stmt [81510,81549]
expr_stmt [81617,81656]
===
match
---
trailer [79621,79680]
trailer [79728,79787]
===
match
---
name: helpers [3076,3083]
name: helpers [3076,3083]
===
match
---
simple_stmt [66015,66077]
simple_stmt [66122,66184]
===
match
---
name: all [24387,24390]
name: all [24387,24390]
===
match
---
name: task [15210,15214]
name: task [15210,15214]
===
match
---
decorator [9945,9955]
decorator [9945,9955]
===
match
---
parameters [84433,84450]
parameters [84540,84557]
===
match
---
trailer [19185,19202]
trailer [19185,19202]
===
match
---
return_stmt [74609,74658]
return_stmt [74716,74765]
===
match
---
string: 'run_id' [77163,77171]
string: 'run_id' [77270,77278]
===
match
---
atom_expr [84897,84910]
atom_expr [85004,85017]
===
match
---
trailer [26861,26872]
trailer [26861,26872]
===
match
---
name: item [71877,71881]
name: item [71984,71988]
===
match
---
funcdef [72034,72587]
funcdef [72141,72694]
===
match
---
param [19816,19835]
param [19816,19835]
===
match
---
and_test [14413,14458]
and_test [14413,14458]
===
match
---
atom_expr [61600,61631]
atom_expr [61600,61631]
===
match
---
expr_stmt [48884,48904]
expr_stmt [48884,48904]
===
match
---
trailer [72811,72820]
trailer [72918,72927]
===
match
---
name: session [34698,34705]
name: session [34698,34705]
===
match
---
atom_expr [73535,73557]
atom_expr [73642,73664]
===
match
---
simple_stmt [74853,74897]
simple_stmt [74960,75004]
===
match
---
name: Optional [80313,80321]
name: Optional [80420,80428]
===
match
---
name: error [52507,52512]
name: error [52507,52512]
===
match
---
return_stmt [47082,47093]
return_stmt [47082,47093]
===
match
---
trailer [7646,8112]
trailer [7646,8112]
===
match
---
name: Session [67170,67177]
name: Session [67277,67284]
===
match
---
name: context [57060,57067]
name: context [57060,57067]
===
match
---
operator: , [76769,76770]
operator: , [76876,76877]
===
match
---
trailer [8373,8379]
trailer [8373,8379]
===
match
---
funcdef [10197,10412]
funcdef [10197,10412]
===
match
---
tfpdef [90074,90127]
tfpdef [90181,90234]
===
match
---
trailer [57811,57824]
trailer [57811,57824]
===
match
---
name: NamedTemporaryFile [61600,61618]
name: NamedTemporaryFile [61600,61618]
===
match
---
name: str [41565,41568]
name: str [41565,41568]
===
match
---
if_stmt [6360,6970]
if_stmt [6360,6970]
===
match
---
string: 'data_interval_end' [76181,76200]
string: 'data_interval_end' [76288,76307]
===
match
---
funcdef [4568,4923]
funcdef [4568,4923]
===
match
---
name: create_pod_id [80430,80443]
name: create_pod_id [80537,80550]
===
match
---
operator: , [70946,70947]
operator: , [71053,71054]
===
match
---
simple_stmt [69104,69129]
simple_stmt [69211,69236]
===
match
---
trailer [92886,92890]
trailer [92993,92997]
===
match
---
string: 'trigger.id' [13178,13190]
string: 'trigger.id' [13178,13190]
===
match
---
atom_expr [11668,11683]
atom_expr [11668,11683]
===
match
---
trailer [29223,29229]
trailer [29223,29229]
===
match
---
operator: , [88672,88673]
operator: , [88779,88780]
===
match
---
trailer [74298,74306]
trailer [74405,74413]
===
match
---
arglist [84306,84355]
arglist [84413,84462]
===
match
---
trailer [30224,30231]
trailer [30224,30231]
===
match
---
name: signal_handler [52698,52712]
name: signal_handler [52698,52712]
===
match
---
operator: } [89177,89178]
operator: } [89284,89285]
===
match
---
atom_expr [85018,85074]
atom_expr [85125,85181]
===
match
---
comparison [91534,91568]
comparison [91641,91675]
===
match
---
param [66246,66275]
param [66353,66382]
===
match
---
atom_expr [66655,66671]
atom_expr [66762,66778]
===
match
---
operator: == [29486,29488]
operator: == [29486,29488]
===
match
---
name: kubernetes [3615,3625]
name: kubernetes [3615,3625]
===
match
---
simple_stmt [820,835]
simple_stmt [820,835]
===
match
---
operator: , [44020,44021]
operator: , [44020,44021]
===
match
---
name: jinja_context [82535,82548]
name: jinja_context [82642,82655]
===
match
---
name: debug [85027,85032]
name: debug [85134,85139]
===
match
---
name: str [93631,93634]
name: str [93738,93741]
===
match
---
name: upper [93877,93882]
name: upper [93984,93989]
===
match
---
name: all [91081,91084]
name: all [91188,91191]
===
match
---
atom_expr [24844,24863]
atom_expr [24844,24863]
===
match
---
trailer [93027,93036]
trailer [93134,93143]
===
match
---
trailer [78538,78543]
trailer [78645,78650]
===
match
---
operator: = [6555,6556]
operator: = [6555,6556]
===
match
---
operator: { [72210,72211]
operator: { [72317,72318]
===
match
---
expr_stmt [11724,11755]
expr_stmt [11724,11755]
===
match
---
suite [57107,57166]
suite [57107,57166]
===
match
---
name: self [52199,52203]
name: self [52199,52203]
===
match
---
name: mark_success_url [23332,23348]
name: mark_success_url [23332,23348]
===
match
---
operator: , [77394,77395]
operator: , [77501,77502]
===
match
---
name: param [2408,2413]
name: param [2408,2413]
===
match
---
name: self [16011,16015]
name: self [16011,16015]
===
match
---
operator: , [19677,19678]
operator: , [19677,19678]
===
match
---
name: reschedule_exception [62388,62408]
name: reschedule_exception [62388,62408]
===
match
---
name: warnings [72453,72461]
name: warnings [72560,72568]
===
match
---
operator: , [75777,75778]
operator: , [75884,75885]
===
match
---
trailer [79905,79978]
trailer [80012,80085]
===
match
---
trailer [28836,28838]
trailer [28836,28838]
===
match
---
name: self [92686,92690]
name: self [92793,92797]
===
match
---
atom_expr [77423,77475]
atom_expr [77530,77582]
===
match
---
name: task_id [51973,51980]
name: task_id [51973,51980]
===
match
---
trailer [89884,89886]
trailer [89991,89993]
===
match
---
operator: , [28901,28902]
operator: , [28901,28902]
===
match
---
suite [58590,58823]
suite [58590,58823]
===
match
---
name: start_date [35209,35219]
name: start_date [35209,35219]
===
match
---
name: params [67526,67532]
name: params [67633,67639]
===
match
---
operator: , [18073,18074]
operator: , [18073,18074]
===
match
---
testlist_comp [22129,22179]
testlist_comp [22129,22179]
===
match
---
name: delete [61619,61625]
name: delete [61619,61625]
===
match
---
name: timeout [58329,58336]
name: timeout [58329,58336]
===
match
---
simple_stmt [32032,32097]
simple_stmt [32032,32097]
===
match
---
dotted_name [3062,3083]
dotted_name [3062,3083]
===
match
---
string: "Refreshed TaskInstance %s" [27049,27076]
string: "Refreshed TaskInstance %s" [27049,27076]
===
match
---
name: self [72662,72666]
name: self [72769,72773]
===
match
---
trailer [37915,37922]
trailer [37915,37922]
===
match
---
atom_expr [68256,68274]
atom_expr [68363,68381]
===
match
---
string: 'Pausing task as DEFERRED. dag_id=%s, task_id=%s, execution_date=%s, start_date=%s' [49813,49896]
string: 'Pausing task as DEFERRED. dag_id=%s, task_id=%s, execution_date=%s, start_date=%s' [49813,49896]
===
match
---
expr_stmt [48913,48943]
expr_stmt [48913,48943]
===
match
---
name: tis [90865,90868]
name: tis [90972,90975]
===
match
---
name: self [78534,78538]
name: self [78641,78645]
===
match
---
name: nullable [11816,11824]
name: nullable [11816,11824]
===
match
---
operator: = [49760,49761]
operator: = [49760,49761]
===
match
---
name: extend [22686,22692]
name: extend [22686,22692]
===
match
---
atom_expr [27435,27444]
atom_expr [27435,27444]
===
match
---
trailer [54405,54434]
trailer [54405,54434]
===
match
---
param [57501,57520]
param [57501,57520]
===
match
---
name: task_id [89228,89235]
name: task_id [89335,89342]
===
match
---
operator: , [70685,70686]
operator: , [70792,70793]
===
match
---
operator: , [34104,34105]
operator: , [34104,34105]
===
match
---
dotted_name [3499,3520]
dotted_name [3499,3520]
===
match
---
simple_stmt [24476,24489]
simple_stmt [24476,24489]
===
match
---
name: models [2445,2451]
name: models [2445,2451]
===
match
---
name: timezone [14956,14964]
name: timezone [14956,14964]
===
match
---
simple_stmt [25465,25663]
simple_stmt [25465,25663]
===
match
---
name: state [30418,30423]
name: state [30418,30423]
===
match
---
atom_expr [60301,60323]
atom_expr [60301,60323]
===
match
---
arglist [9181,9232]
arglist [9181,9232]
===
match
---
atom_expr [9901,9912]
atom_expr [9901,9912]
===
match
---
comparison [91480,91512]
comparison [91587,91619]
===
match
---
name: self [65673,65677]
name: self [65780,65784]
===
match
---
simple_stmt [3104,3161]
simple_stmt [3104,3161]
===
match
---
funcdef [86503,89448]
funcdef [86610,89555]
===
match
---
simple_stmt [16094,16113]
simple_stmt [16094,16113]
===
match
---
import_from [2760,2810]
import_from [2760,2810]
===
match
---
atom_expr [4615,4636]
atom_expr [4615,4636]
===
match
---
simple_stmt [83143,83216]
simple_stmt [83250,83323]
===
match
---
name: self [60363,60367]
name: self [60363,60367]
===
match
---
parameters [62093,62099]
parameters [62093,62099]
===
match
---
string: 'prev_data_interval_end_success' [76412,76444]
string: 'prev_data_interval_end_success' [76519,76551]
===
match
---
name: params [79957,79963]
name: params [80064,80070]
===
match
---
trailer [67559,67572]
trailer [67666,67679]
===
match
---
argument [91031,91053]
argument [91138,91160]
===
match
---
name: update [67553,67559]
name: update [67660,67666]
===
match
---
trailer [85032,85074]
trailer [85139,85181]
===
match
---
atom_expr [92462,92483]
atom_expr [92569,92590]
===
match
---
name: TaskInstance [91191,91203]
name: TaskInstance [91298,91310]
===
match
---
trailer [77114,77120]
trailer [77221,77227]
===
match
---
atom_expr [40333,40351]
atom_expr [40333,40351]
===
match
---
simple_stmt [52956,53050]
simple_stmt [52956,53050]
===
match
---
name: max_retry_delay [40029,40044]
name: max_retry_delay [40029,40044]
===
match
---
name: SEEK_SET [4743,4751]
name: SEEK_SET [4743,4751]
===
match
---
atom_expr [40636,40649]
atom_expr [40636,40649]
===
match
---
name: dag [18706,18709]
name: dag [18706,18709]
===
match
---
atom [72176,72333]
atom [72283,72440]
===
match
---
suite [65998,66077]
suite [66105,66184]
===
match
---
expr_stmt [85904,85965]
expr_stmt [86011,86072]
===
match
---
operator: { [77708,77709]
operator: { [77815,77816]
===
match
---
name: primaryjoin [13551,13562]
name: primaryjoin [13551,13562]
===
match
---
import_from [2811,2887]
import_from [2811,2887]
===
match
---
string: 'data_interval_start' [75287,75308]
string: 'data_interval_start' [75394,75415]
===
match
---
trailer [34684,34689]
trailer [34684,34689]
===
match
---
string: '' [74312,74314]
string: '' [74419,74421]
===
match
---
operator: { [23573,23574]
operator: { [23573,23574]
===
match
---
name: get [23470,23473]
name: get [23470,23473]
===
match
---
simple_stmt [11566,11593]
simple_stmt [11566,11593]
===
match
---
trailer [23469,23473]
trailer [23469,23473]
===
match
---
operator: , [80049,80050]
operator: , [80156,80157]
===
match
---
operator: , [13273,13274]
operator: , [13273,13274]
===
match
---
return_stmt [69897,69912]
return_stmt [70004,70019]
===
match
---
trailer [83798,83815]
trailer [83905,83922]
===
match
---
name: deprecated_func [72131,72146]
name: deprecated_func [72238,72253]
===
match
---
import_from [1048,1147]
import_from [1048,1147]
===
match
---
operator: - [43904,43905]
operator: - [43904,43905]
===
match
---
name: delay [40062,40067]
name: delay [40062,40067]
===
match
---
operator: , [76977,76978]
operator: , [77084,77085]
===
match
---
atom_expr [22307,22321]
atom_expr [22307,22321]
===
match
---
name: load_error_file [4572,4587]
name: load_error_file [4572,4587]
===
match
---
string: """         Get datetime of the next retry if the task instance fails. For exponential         backoff, retry_delay is used as base and will be converted to seconds.         """ [38014,38191]
string: """         Get datetime of the next retry if the task instance fails. For exponential         backoff, retry_delay is used as base and will be converted to seconds.         """ [38014,38191]
===
match
---
simple_stmt [90169,90234]
simple_stmt [90276,90341]
===
match
---
operator: , [41256,41257]
operator: , [41256,41257]
===
match
---
name: dr [41101,41103]
name: dr [41101,41103]
===
match
---
operator: { [15858,15859]
operator: { [15858,15859]
===
match
---
atom_expr [46484,46494]
atom_expr [46484,46494]
===
match
---
name: self [23349,23353]
name: self [23349,23353]
===
match
---
name: self [43336,43340]
name: self [43336,43340]
===
match
---
operator: @ [34001,34002]
operator: @ [34001,34002]
===
match
---
funcdef [32425,32973]
funcdef [32425,32973]
===
match
---
name: ds [74274,74276]
name: ds [74381,74383]
===
match
---
trailer [80878,80887]
trailer [80985,80994]
===
match
---
operator: = [23116,23117]
operator: = [23116,23117]
===
match
---
name: self [17923,17927]
name: self [17923,17927]
===
match
---
name: mark_success [60875,60887]
name: mark_success [60875,60887]
===
match
---
operator: , [62853,62854]
operator: , [62853,62854]
===
match
---
trailer [28851,28855]
trailer [28851,28855]
===
match
---
simple_stmt [89328,89375]
simple_stmt [89435,89482]
===
match
---
simple_stmt [33543,33683]
simple_stmt [33543,33683]
===
match
---
name: run_as_user [27644,27655]
name: run_as_user [27644,27655]
===
match
---
atom_expr [8203,8242]
atom_expr [8203,8242]
===
match
---
arglist [84728,84770]
arglist [84835,84877]
===
match
---
sliceop [93872,93875]
sliceop [93979,93982]
===
match
---
if_stmt [19024,19157]
if_stmt [19024,19157]
===
match
---
expr_stmt [27581,27630]
expr_stmt [27581,27630]
===
match
---
name: self [46215,46219]
name: self [46215,46219]
===
match
---
trailer [59795,59839]
trailer [59795,59839]
===
match
---
number: 1 [43527,43528]
number: 1 [43527,43528]
===
match
---
name: error [63694,63699]
name: error [63694,63699]
===
match
---
string: 'dag_run' [75169,75178]
string: 'dag_run' [75276,75285]
===
match
---
dotted_name [1677,1699]
dotted_name [1677,1699]
===
match
---
trailer [89366,89372]
trailer [89473,89479]
===
match
---
trailer [38557,38622]
trailer [38557,38622]
===
match
---
name: ti [6000,6002]
name: ti [6000,6002]
===
match
---
simple_stmt [67959,67991]
simple_stmt [68066,68098]
===
match
---
name: dr [32269,32271]
name: dr [32269,32271]
===
match
---
trailer [54886,54890]
trailer [54886,54890]
===
match
---
trailer [40733,40741]
trailer [40733,40741]
===
match
---
argument [61150,61165]
argument [61150,61165]
===
match
---
operator: -> [68921,68923]
operator: -> [69028,69030]
===
match
---
simple_stmt [89192,89262]
simple_stmt [89299,89369]
===
match
---
name: self [30609,30613]
name: self [30609,30613]
===
match
---
name: session [62689,62696]
name: session [62689,62696]
===
match
---
trailer [52589,52591]
trailer [52589,52591]
===
match
---
operator: -> [63554,63556]
operator: -> [63554,63556]
===
match
---
name: DagRunNotFound [2184,2198]
name: DagRunNotFound [2184,2198]
===
match
---
name: TaskInstance [30202,30214]
name: TaskInstance [30202,30214]
===
match
---
argument [78021,78046]
argument [78128,78153]
===
match
---
name: self [65707,65711]
name: self [65814,65818]
===
match
---
fstring [79622,79679]
fstring [79729,79786]
===
match
---
operator: , [76574,76575]
operator: , [76681,76682]
===
match
---
name: UndefinedError [1290,1304]
name: UndefinedError [1290,1304]
===
match
---
if_stmt [83873,84042]
if_stmt [83980,84149]
===
match
---
atom_expr [43307,43318]
atom_expr [43307,43318]
===
match
---
trailer [9126,9133]
trailer [9126,9133]
===
match
---
operator: - [72682,72683]
operator: - [72789,72790]
===
match
---
name: ignore_all_deps [43956,43971]
name: ignore_all_deps [43956,43971]
===
match
---
name: String [11984,11990]
name: String [11984,11990]
===
match
---
fstring_conversion [15870,15872]
fstring_conversion [15870,15872]
===
match
---
name: debug [28278,28283]
name: debug [28278,28283]
===
match
---
name: self [49914,49918]
name: self [49914,49918]
===
match
---
name: field_name [78441,78451]
name: field_name [78548,78558]
===
match
---
simple_stmt [1180,1192]
simple_stmt [1180,1192]
===
match
---
atom_expr [74541,74592]
atom_expr [74648,74699]
===
match
---
atom_expr [72546,72586]
atom_expr [72653,72693]
===
match
---
trailer [43364,43366]
trailer [43364,43366]
===
match
---
name: settings [91367,91375]
name: settings [91474,91482]
===
match
---
operator: = [61766,61767]
operator: = [61766,61767]
===
match
---
trailer [20092,20097]
trailer [20092,20097]
===
match
---
param [30609,30614]
param [30609,30614]
===
match
---
name: DateTime [68682,68690]
name: DateTime [68789,68797]
===
match
---
funcdef [71646,71972]
funcdef [71753,72079]
===
match
---
name: ti [26821,26823]
name: ti [26821,26823]
===
match
---
name: on_retry_callback [60306,60323]
name: on_retry_callback [60306,60323]
===
match
---
name: error [66533,66538]
name: error [66640,66645]
===
match
---
name: kube_config [81075,81086]
name: kube_config [81182,81193]
===
match
---
trailer [32826,32850]
trailer [32826,32850]
===
match
---
name: DagRun [9206,9212]
name: DagRun [9206,9212]
===
match
---
name: dag_id [15657,15663]
name: dag_id [15657,15663]
===
match
---
testlist_comp [79537,79575]
testlist_comp [79644,79682]
===
match
---
expr_stmt [12105,12155]
expr_stmt [12105,12155]
===
match
---
operator: , [46293,46294]
operator: , [46293,46294]
===
match
---
atom_expr [74105,74140]
atom_expr [74212,74247]
===
match
---
operator: = [13777,13778]
operator: = [13777,13778]
===
match
---
name: self [58671,58675]
name: self [58671,58675]
===
match
---
name: run_id [93060,93066]
name: run_id [93167,93173]
===
match
---
fstring_expr [37939,37952]
fstring_expr [37939,37952]
===
match
---
expr_stmt [62585,62618]
expr_stmt [62585,62618]
===
match
---
atom_expr [91955,91982]
atom_expr [92062,92089]
===
match
---
simple_stmt [79236,79307]
simple_stmt [79343,79414]
===
match
---
simple_stmt [14282,14310]
simple_stmt [14282,14310]
===
match
---
name: sqlalchemy [1720,1730]
name: sqlalchemy [1720,1730]
===
match
---
name: str [70943,70946]
name: str [71050,71053]
===
match
---
simple_stmt [74428,74481]
simple_stmt [74535,74588]
===
match
---
trailer [55031,55037]
trailer [55031,55037]
===
match
---
simple_stmt [51251,51268]
simple_stmt [51251,51268]
===
match
---
if_stmt [38975,39027]
if_stmt [38975,39027]
===
match
---
name: self [49547,49551]
name: self [49547,49551]
===
match
---
name: Variable [69862,69870]
name: Variable [69969,69977]
===
match
---
name: self [50028,50032]
name: self [50028,50032]
===
match
---
expr_stmt [11289,11372]
expr_stmt [11289,11372]
===
match
---
suite [74250,74277]
suite [74357,74384]
===
match
---
name: context [80186,80193]
name: context [80293,80300]
===
match
---
name: get_run_data_interval [67756,67777]
name: get_run_data_interval [67863,67884]
===
match
---
atom_expr [62627,62646]
atom_expr [62627,62646]
===
match
---
trailer [35075,35105]
trailer [35075,35105]
===
match
---
atom_expr [67654,67725]
atom_expr [67761,67832]
===
match
---
name: Session [34707,34714]
name: Session [34707,34714]
===
match
---
atom_expr [62689,62963]
atom_expr [62689,62963]
===
match
---
dotted_name [3551,3579]
dotted_name [3551,3579]
===
match
---
name: nullable [11269,11277]
name: nullable [11269,11277]
===
match
---
tfpdef [69809,69818]
tfpdef [69916,69925]
===
match
---
atom_expr [47937,47950]
atom_expr [47937,47950]
===
match
---
name: clear_xcom_data [27834,27849]
name: clear_xcom_data [27834,27849]
===
match
---
atom_expr [34988,35036]
atom_expr [34988,35036]
===
match
---
atom_expr [37955,37965]
atom_expr [37955,37965]
===
match
---
expr_stmt [48741,48767]
expr_stmt [48741,48767]
===
match
---
funcdef [41130,47094]
funcdef [41130,47094]
===
match
---
name: self [53931,53935]
name: self [53931,53935]
===
match
---
simple_stmt [29142,29208]
simple_stmt [29142,29208]
===
match
---
name: log [36691,36694]
name: log [36691,36694]
===
match
---
operator: , [84654,84655]
operator: , [84761,84762]
===
match
---
atom_expr [68981,69025]
atom_expr [69088,69132]
===
match
---
expr_stmt [11760,11784]
expr_stmt [11760,11784]
===
match
---
simple_stmt [7059,7077]
simple_stmt [7059,7077]
===
match
---
atom_expr [35322,35349]
atom_expr [35322,35349]
===
match
---
operator: < [86011,86012]
operator: < [86118,86119]
===
match
---
trailer [30492,30495]
trailer [30492,30495]
===
match
---
trailer [30384,30391]
trailer [30384,30391]
===
match
---
parameters [35886,35939]
parameters [35886,35939]
===
match
---
name: job_id [47893,47899]
name: job_id [47893,47899]
===
match
---
trailer [52506,52512]
trailer [52506,52512]
===
match
---
fstring_string:  from the template is deprecated and  [72217,72254]
fstring_string:  from the template is deprecated and  [72324,72361]
===
match
---
operator: , [22995,22996]
operator: , [22995,22996]
===
match
---
name: self [26857,26861]
name: self [26857,26861]
===
match
---
trailer [67947,67949]
trailer [68054,68056]
===
match
---
trailer [65381,65402]
trailer [65488,65509]
===
match
---
suite [49611,50246]
suite [49611,50246]
===
match
---
trailer [46000,46008]
trailer [46000,46008]
===
match
---
expr_stmt [24810,24835]
expr_stmt [24810,24835]
===
match
---
tfpdef [86676,86701]
tfpdef [86783,86808]
===
match
---
test [47212,47262]
test [47212,47262]
===
match
---
name: timezone [69334,69342]
name: timezone [69441,69449]
===
match
---
simple_stmt [16464,16525]
simple_stmt [16464,16525]
===
match
---
number: 0 [56863,56864]
number: 0 [56863,56864]
===
match
---
operator: = [53929,53930]
operator: = [53929,53930]
===
match
---
name: self [18742,18746]
name: self [18742,18746]
===
match
---
name: AirflowSmartSensorException [55127,55154]
name: AirflowSmartSensorException [55127,55154]
===
match
---
operator: = [92882,92883]
operator: = [92989,92990]
===
match
---
name: dr [31135,31137]
name: dr [31135,31137]
===
match
---
name: timeout_seconds [56492,56507]
name: timeout_seconds [56492,56507]
===
match
---
expr_stmt [16385,16407]
expr_stmt [16385,16407]
===
match
---
name: tuple_ [1477,1483]
name: tuple_ [1477,1483]
===
match
---
trailer [89354,89366]
trailer [89461,89473]
===
match
---
suite [59084,59158]
suite [59084,59158]
===
match
---
name: job [93948,93951]
name: job [94055,94058]
===
match
---
operator: , [2873,2874]
operator: , [2873,2874]
===
match
---
name: unixname [11724,11732]
name: unixname [11724,11732]
===
match
---
name: execution_date [88563,88577]
name: execution_date [88670,88684]
===
match
---
name: Column [11478,11484]
name: Column [11478,11484]
===
match
---
and_test [90814,90855]
and_test [90921,90962]
===
match
---
if_stmt [65522,65695]
if_stmt [65629,65802]
===
match
---
dotted_name [47758,47778]
dotted_name [47758,47778]
===
match
---
name: airflow [57656,57663]
name: airflow [57656,57663]
===
match
---
name: replacement [75779,75790]
name: replacement [75886,75897]
===
match
---
trailer [18700,18705]
trailer [18700,18705]
===
match
---
name: self [67195,67199]
name: self [67302,67306]
===
match
---
simple_stmt [80472,80499]
simple_stmt [80579,80606]
===
match
---
funcdef [69754,69913]
funcdef [69861,70020]
===
match
---
name: pool [61791,61795]
name: pool [61791,61795]
===
match
---
name: session [49518,49525]
name: session [49518,49525]
===
match
---
simple_stmt [4208,4241]
simple_stmt [4208,4241]
===
match
---
name: back_populates [13943,13957]
name: back_populates [13943,13957]
===
match
---
name: task_id [80598,80605]
name: task_id [80705,80712]
===
match
---
operator: @ [93498,93499]
operator: @ [93605,93606]
===
match
---
atom_expr [36686,36699]
atom_expr [36686,36699]
===
match
---
name: all [90810,90813]
name: all [90917,90920]
===
match
---
name: state [26023,26028]
name: state [26023,26028]
===
match
---
name: var [70868,70871]
name: var [70975,70978]
===
match
---
atom_expr [90539,90551]
atom_expr [90646,90658]
===
match
---
name: task [14341,14345]
name: task [14341,14345]
===
match
---
string: "Trigger" [13747,13756]
string: "Trigger" [13747,13756]
===
match
---
simple_stmt [18736,18757]
simple_stmt [18736,18757]
===
match
---
trailer [46008,46023]
trailer [46008,46023]
===
match
---
name: in_ [30314,30317]
name: in_ [30314,30317]
===
match
---
atom_expr [13037,13063]
atom_expr [13037,13063]
===
match
---
name: load_error_file [61969,61984]
name: load_error_file [61969,61984]
===
match
---
string: "Failed to load task run error" [4891,4922]
string: "Failed to load task run error" [4891,4922]
===
match
---
name: str [72761,72764]
name: str [72868,72871]
===
match
---
name: self [58708,58712]
name: self [58708,58712]
===
match
---
name: provide_session [60630,60645]
name: provide_session [60630,60645]
===
match
---
name: retries [6518,6525]
name: retries [6518,6525]
===
match
---
name: TaskInstance [90912,90924]
name: TaskInstance [91019,91031]
===
match
---
operator: = [39977,39978]
operator: = [39977,39978]
===
match
---
name: delete_qry [8190,8200]
name: delete_qry [8190,8200]
===
match
---
trailer [9806,9821]
trailer [9806,9821]
===
match
---
name: dag_run [67778,67785]
name: dag_run [67885,67892]
===
match
---
name: params [67923,67929]
name: params [68030,68036]
===
match
---
trailer [55762,55774]
trailer [55762,55774]
===
match
---
atom_expr [39960,40003]
atom_expr [39960,40003]
===
match
---
atom_expr [68851,68870]
atom_expr [68958,68977]
===
match
---
operator: = [27742,27743]
operator: = [27742,27743]
===
match
---
atom_expr [46312,46326]
atom_expr [46312,46326]
===
match
---
annassign [92173,92190]
annassign [92280,92297]
===
match
---
expr_stmt [28945,28994]
expr_stmt [28945,28994]
===
match
---
expr_stmt [65751,65788]
expr_stmt [65858,65895]
===
match
---
simple_stmt [12079,12101]
simple_stmt [12079,12101]
===
match
---
expr_stmt [36640,36654]
expr_stmt [36640,36654]
===
match
---
simple_stmt [67484,67510]
simple_stmt [67591,67617]
===
match
---
expr_stmt [88432,88452]
expr_stmt [88539,88559]
===
match
---
name: self [60276,60280]
name: self [60276,60280]
===
match
---
trailer [30231,30470]
trailer [30231,30470]
===
match
---
operator: , [73046,73047]
operator: , [73153,73154]
===
match
---
suite [5084,5324]
suite [5084,5324]
===
match
---
trailer [70596,70600]
trailer [70703,70707]
===
match
---
simple_stmt [36640,36655]
simple_stmt [36640,36655]
===
match
---
trailer [45996,46000]
trailer [45996,46000]
===
match
---
argument [76126,76151]
argument [76233,76258]
===
match
---
suite [68527,68556]
suite [68634,68663]
===
match
---
suite [18863,19157]
suite [18863,19157]
===
match
---
tfpdef [47124,47133]
tfpdef [47124,47133]
===
match
---
trailer [66303,66309]
trailer [66410,66416]
===
match
---
suite [3896,3954]
suite [3896,3954]
===
match
---
name: start_date [44947,44957]
name: start_date [44947,44957]
===
match
---
name: exception [84592,84601]
name: exception [84699,84708]
===
match
---
name: task_id [91110,91117]
name: task_id [91217,91224]
===
match
---
name: k [53413,53414]
name: k [53413,53414]
===
match
---
param [70569,70573]
param [70676,70680]
===
match
---
and_test [79853,79877]
and_test [79960,79984]
===
match
---
name: log [27039,27042]
name: log [27039,27042]
===
match
---
arglist [50139,50155]
arglist [50139,50155]
===
match
---
name: dag_id [10365,10371]
name: dag_id [10365,10371]
===
match
---
atom_expr [57833,57848]
atom_expr [57833,57848]
===
match
---
dictorsetmaker [51490,51517]
dictorsetmaker [51490,51517]
===
match
---
name: replace [72804,72811]
name: replace [72911,72918]
===
match
---
atom_expr [73993,74018]
atom_expr [74100,74125]
===
match
---
param [63534,63547]
param [63534,63547]
===
match
---
string: "Error when executing on_failure_callback" [59796,59838]
string: "Error when executing on_failure_callback" [59796,59838]
===
match
---
name: models [52384,52390]
name: models [52384,52390]
===
match
---
name: test_mode [48746,48755]
name: test_mode [48746,48755]
===
match
---
expr_stmt [8780,8801]
expr_stmt [8780,8801]
===
match
---
atom_expr [70592,70600]
atom_expr [70699,70707]
===
match
---
string: "CASCADE" [13464,13473]
string: "CASCADE" [13464,13473]
===
match
---
trailer [46299,46310]
trailer [46299,46310]
===
match
---
name: _run_execute_callback [58832,58853]
name: _run_execute_callback [58832,58853]
===
match
---
trailer [45905,45916]
trailer [45905,45916]
===
match
---
operator: , [47921,47922]
operator: , [47921,47922]
===
match
---
name: self [52787,52791]
name: self [52787,52791]
===
match
---
trailer [41512,41517]
trailer [41512,41517]
===
match
---
name: try_number [80680,80690]
name: try_number [80787,80797]
===
match
---
atom_expr [54730,54749]
atom_expr [54730,54749]
===
match
---
trailer [51596,51650]
trailer [51596,51650]
===
match
---
param [41534,41577]
param [41534,41577]
===
match
---
operator: = [62599,62600]
operator: = [62599,62600]
===
match
---
name: task [49144,49148]
name: task [49144,49148]
===
match
---
trailer [8443,8449]
trailer [8443,8449]
===
match
---
atom [22444,22473]
atom [22444,22473]
===
match
---
name: execution_date [14978,14992]
name: execution_date [14978,14992]
===
match
---
name: items [7961,7966]
name: items [7961,7966]
===
match
---
arith_expr [45938,45956]
arith_expr [45938,45956]
===
match
---
comp_op [40693,40699]
comp_op [40693,40699]
===
match
---
operator: @ [93746,93747]
operator: @ [93853,93854]
===
match
---
trailer [8258,8266]
trailer [8258,8266]
===
match
---
name: taskreschedule [2497,2511]
name: taskreschedule [2497,2511]
===
match
---
atom_expr [18659,18668]
atom_expr [18659,18668]
===
match
---
name: dry_run [62304,62311]
name: dry_run [62304,62311]
===
match
---
argument [91262,91283]
argument [91369,91390]
===
match
---
name: self [93384,93388]
name: self [93491,93495]
===
match
---
string: "when Dag Serialization is enabled. Hence for the task that have not yet " [78858,78932]
string: "when Dag Serialization is enabled. Hence for the task that have not yet " [78965,79039]
===
match
---
trailer [62750,62755]
trailer [62750,62755]
===
match
---
name: info [53321,53325]
name: info [53321,53325]
===
match
---
operator: , [25603,25604]
operator: , [25603,25604]
===
match
---
param [41391,41418]
param [41391,41418]
===
match
---
trailer [52182,52205]
trailer [52182,52205]
===
match
---
trailer [19072,19074]
trailer [19072,19074]
===
match
---
suite [70148,70265]
suite [70255,70372]
===
match
---
name: dag [32075,32078]
name: dag [32075,32078]
===
match
---
name: id [8404,8406]
name: id [8404,8406]
===
match
---
name: UtcDateTime [3431,3442]
name: UtcDateTime [3431,3442]
===
match
---
operator: , [43528,43529]
operator: , [43528,43529]
===
match
---
testlist_comp [12793,13485]
testlist_comp [12793,13485]
===
match
---
name: SKIPPED [50685,50692]
name: SKIPPED [50685,50692]
===
match
---
name: result [57340,57346]
name: result [57340,57346]
===
match
---
import_from [1672,1714]
import_from [1672,1714]
===
match
---
fstring_end: ' [52888,52889]
fstring_end: ' [52888,52889]
===
match
---
operator: , [28575,28576]
operator: , [28575,28576]
===
match
---
annassign [67216,67232]
annassign [67323,67339]
===
match
---
trailer [34423,34461]
trailer [34423,34461]
===
match
---
name: bool [41438,41442]
name: bool [41438,41442]
===
match
---
name: queued_dttm [46045,46056]
name: queued_dttm [46045,46056]
===
match
---
trailer [14322,14340]
trailer [14322,14340]
===
match
---
dotted_name [2942,2963]
dotted_name [2942,2963]
===
match
---
trailer [9133,9334]
trailer [9133,9334]
===
match
---
suite [56475,56634]
suite [56475,56634]
===
match
---
funcdef [71458,71607]
funcdef [71565,71714]
===
match
---
parameters [33007,33013]
parameters [33007,33013]
===
match
---
atom_expr [93482,93492]
atom_expr [93589,93599]
===
match
---
name: State [9502,9507]
name: State [9502,9507]
===
match
---
name: key [75558,75561]
name: key [75665,75668]
===
match
---
trailer [77120,77149]
trailer [77227,77256]
===
match
---
name: State [49560,49565]
name: State [49560,49565]
===
match
---
import_from [3901,3953]
import_from [3901,3953]
===
match
---
operator: -> [34728,34730]
operator: -> [34728,34730]
===
match
---
atom_expr [55758,55774]
atom_expr [55758,55774]
===
match
---
operator: , [63406,63407]
operator: , [63406,63407]
===
match
---
trailer [89683,89690]
trailer [89790,89797]
===
match
---
trailer [30184,30190]
trailer [30184,30190]
===
match
---
trailer [4224,4231]
trailer [4224,4231]
===
match
---
string: 'ti_job_id' [13043,13054]
string: 'ti_job_id' [13043,13054]
===
match
---
name: render_templates [62267,62283]
name: render_templates [62267,62283]
===
match
---
name: last_dagrun [32255,32266]
name: last_dagrun [32255,32266]
===
match
---
try_stmt [65924,66077]
try_stmt [66031,66184]
===
match
---
operator: = [14150,14151]
operator: = [14150,14151]
===
match
---
simple_stmt [35182,35262]
simple_stmt [35182,35262]
===
match
---
operator: = [8794,8795]
operator: = [8794,8795]
===
match
---
tfpdef [10223,10238]
tfpdef [10223,10238]
===
match
---
simple_stmt [75057,75089]
simple_stmt [75164,75196]
===
match
---
not_test [43673,43689]
not_test [43673,43689]
===
match
---
name: job_id [26367,26373]
name: job_id [26367,26373]
===
match
---
operator: , [85146,85147]
operator: , [85253,85254]
===
match
---
name: drs [9382,9385]
name: drs [9382,9385]
===
match
---
return_stmt [17916,17943]
return_stmt [17916,17943]
===
match
---
trailer [43133,43138]
trailer [43133,43138]
===
match
---
name: get_previous_start_date [34630,34653]
name: get_previous_start_date [34630,34653]
===
match
---
name: str [72870,72873]
name: str [72977,72980]
===
match
---
name: ignore_all_deps [60711,60726]
name: ignore_all_deps [60711,60726]
===
match
---
name: refresh_from_db [50599,50614]
name: refresh_from_db [50599,50614]
===
match
---
atom_expr [67195,67204]
atom_expr [67302,67311]
===
match
---
name: one [40920,40923]
name: one [40920,40923]
===
match
---
arglist [82780,82949]
arglist [82887,83056]
===
match
---
name: verbose [41197,41204]
name: verbose [41197,41204]
===
match
---
simple_stmt [1048,1148]
simple_stmt [1048,1148]
===
match
---
suite [8427,8469]
suite [8427,8469]
===
match
---
expr_stmt [11200,11284]
expr_stmt [11200,11284]
===
match
---
tfpdef [20044,20055]
tfpdef [20044,20055]
===
match
---
name: set [8961,8964]
name: set [8961,8964]
===
match
---
name: deprecated_proxy [76051,76067]
name: deprecated_proxy [76158,76174]
===
match
---
simple_stmt [74731,74774]
simple_stmt [74838,74881]
===
match
---
name: Optional [90132,90140]
name: Optional [90239,90247]
===
match
---
trailer [72563,72569]
trailer [72670,72676]
===
match
---
name: min_backoff [39011,39022]
name: min_backoff [39011,39022]
===
match
---
name: session [44261,44268]
name: session [44261,44268]
===
match
---
string: 'BASE_URL' [23487,23497]
string: 'BASE_URL' [23487,23497]
===
match
---
arglist [39117,39349]
arglist [39117,39349]
===
match
---
name: task_id [80585,80592]
name: task_id [80692,80699]
===
match
---
name: dag_run [73535,73542]
name: dag_run [73642,73649]
===
match
---
trailer [52130,52132]
trailer [52130,52132]
===
match
---
atom_expr [9181,9194]
atom_expr [9181,9194]
===
match
---
name: self [54945,54949]
name: self [54945,54949]
===
match
---
param [41227,41257]
param [41227,41257]
===
match
---
simple_stmt [92785,92828]
simple_stmt [92892,92935]
===
match
---
name: session [46093,46100]
name: session [46093,46100]
===
match
---
trailer [8524,8529]
trailer [8524,8529]
===
match
---
argument [19641,19654]
argument [19641,19654]
===
match
---
atom_expr [29006,29016]
atom_expr [29006,29016]
===
match
---
trailer [68941,68950]
trailer [69048,69057]
===
match
---
expr_stmt [59980,60017]
expr_stmt [59980,60017]
===
match
---
trailer [15987,15998]
trailer [15987,15998]
===
match
---
name: String [11393,11399]
name: String [11393,11399]
===
match
---
expr_stmt [4293,4332]
expr_stmt [4293,4332]
===
match
---
suite [89001,89302]
suite [89108,89409]
===
match
---
trailer [40073,40107]
trailer [40073,40107]
===
match
---
operator: = [68979,68980]
operator: = [69086,69087]
===
match
---
name: tis [91837,91840]
name: tis [91944,91947]
===
match
---
atom_expr [12123,12155]
atom_expr [12123,12155]
===
match
---
name: AirflowRescheduleException [50708,50734]
name: AirflowRescheduleException [50708,50734]
===
match
---
name: all [9348,9351]
name: all [9348,9351]
===
match
---
trailer [73032,73034]
trailer [73139,73141]
===
match
---
decorated [93598,93663]
decorated [93705,93770]
===
match
---
name: nullable [11876,11884]
name: nullable [11876,11884]
===
match
---
name: bool [41609,41613]
name: bool [41609,41613]
===
match
---
name: Exception [59223,59232]
name: Exception [59223,59232]
===
match
---
comparison [40319,40351]
comparison [40319,40351]
===
match
---
or_test [29100,29129]
or_test [29100,29129]
===
match
---
name: task [27521,27525]
name: task [27521,27525]
===
match
---
name: qry [25465,25468]
name: qry [25465,25468]
===
match
---
annassign [9731,9736]
annassign [9731,9736]
===
match
---
trailer [53604,53621]
trailer [53604,53621]
===
match
---
trailer [89788,89796]
trailer [89895,89903]
===
match
---
name: timezone [15382,15390]
name: timezone [15382,15390]
===
match
---
name: str [70859,70862]
name: str [70966,70969]
===
match
---
name: max [10163,10166]
name: max [10163,10166]
===
match
---
operator: = [28126,28127]
operator: = [28126,28127]
===
match
---
atom_expr [80691,80706]
atom_expr [80798,80813]
===
match
---
operator: , [28138,28139]
operator: , [28138,28139]
===
match
---
simple_stmt [85018,85075]
simple_stmt [85125,85182]
===
match
---
operator: = [86358,86359]
operator: = [86465,86466]
===
match
---
name: dag_run [74386,74393]
name: dag_run [74493,74500]
===
match
---
name: self [64217,64221]
name: self [64217,64221]
===
match
---
simple_stmt [93475,93493]
simple_stmt [93582,93600]
===
match
---
param [30660,30694]
param [30660,30694]
===
match
---
exprlist [78441,78467]
exprlist [78548,78574]
===
match
---
name: dag [67498,67501]
name: dag [67605,67608]
===
match
---
comp_op [59536,59542]
comp_op [59536,59542]
===
match
---
suite [22669,22706]
suite [22669,22706]
===
match
---
trailer [26611,26623]
trailer [26611,26623]
===
match
---
operator: = [44117,44118]
operator: = [44117,44118]
===
match
---
name: query [89651,89656]
name: query [89758,89763]
===
match
---
name: self [61936,61940]
name: self [61936,61940]
===
match
---
name: log [45650,45653]
name: log [45650,45653]
===
match
---
name: log [34414,34417]
name: log [34414,34417]
===
match
---
number: 256 [11918,11921]
number: 256 [11918,11921]
===
match
---
raise_stmt [79599,79687]
raise_stmt [79706,79794]
===
match
---
atom_expr [81181,81224]
atom_expr [81288,81331]
===
match
---
name: state [11566,11571]
name: state [11566,11571]
===
match
---
operator: , [47957,47958]
operator: , [47957,47958]
===
match
---
string: "/confirm" [23539,23549]
string: "/confirm" [23539,23549]
===
match
---
param [79771,79778]
param [79878,79885]
===
match
---
arglist [8543,8723]
arglist [8543,8723]
===
match
---
name: next_method [26906,26917]
name: next_method [26906,26917]
===
match
---
name: get_next_ds_nodash [75882,75900]
name: get_next_ds_nodash [75989,76007]
===
match
---
name: ti [6337,6339]
name: ti [6337,6339]
===
match
---
operator: = [37356,37357]
operator: = [37356,37357]
===
match
---
trailer [82758,82967]
trailer [82865,83074]
===
match
---
operator: , [13484,13485]
operator: , [13484,13485]
===
match
---
operator: = [12571,12572]
operator: = [12571,12572]
===
match
---
name: XCOM_RETURN_KEY [86651,86666]
name: XCOM_RETURN_KEY [86758,86773]
===
match
---
atom_expr [31577,31615]
atom_expr [31577,31615]
===
match
---
operator: = [88439,88440]
operator: = [88546,88547]
===
match
---
simple_stmt [24575,24738]
simple_stmt [24575,24738]
===
match
---
name: str [93462,93465]
name: str [93569,93572]
===
match
---
operator: , [44859,44860]
operator: , [44859,44860]
===
match
---
argument [71155,71178]
argument [71262,71285]
===
match
---
simple_stmt [61920,61995]
simple_stmt [61920,61995]
===
match
---
fstring_end: " [72314,72315]
fstring_end: " [72421,72422]
===
match
---
name: utils [3117,3122]
name: utils [3117,3122]
===
match
---
name: task [52866,52870]
name: task [52866,52870]
===
match
---
operator: + [6571,6572]
operator: + [6571,6572]
===
match
---
comparison [8810,8836]
comparison [8810,8836]
===
match
---
and_test [57313,57358]
and_test [57313,57358]
===
match
---
suite [23355,23764]
suite [23355,23764]
===
match
---
operator: , [68134,68135]
operator: , [68241,68242]
===
match
---
atom_expr [70221,70264]
atom_expr [70328,70371]
===
match
---
name: items [8163,8168]
name: items [8163,8168]
===
match
---
trailer [59579,59600]
trailer [59579,59600]
===
match
---
name: self [16449,16453]
name: self [16449,16453]
===
match
---
name: delay_backoff_in_seconds [39978,40002]
name: delay_backoff_in_seconds [39978,40002]
===
match
---
argument [80969,81009]
argument [81076,81116]
===
match
---
trailer [53112,53120]
trailer [53112,53120]
===
match
---
for_stmt [78437,78573]
for_stmt [78544,78680]
===
match
---
name: refresh_from_task [48781,48798]
name: refresh_from_task [48781,48798]
===
match
---
name: self [40019,40023]
name: self [40019,40023]
===
match
---
name: state [44756,44761]
name: state [44756,44761]
===
match
---
return_stmt [66832,66894]
return_stmt [66939,67001]
===
match
---
argument [15645,15663]
argument [15645,15663]
===
match
---
operator: = [32267,32268]
operator: = [32267,32268]
===
match
---
name: prev_ds [74961,74968]
name: prev_ds [75068,75075]
===
match
---
name: self [28559,28563]
name: self [28559,28563]
===
match
---
trailer [18658,18676]
trailer [18658,18676]
===
match
---
name: os [854,856]
name: os [854,856]
===
match
---
parameters [47282,47308]
parameters [47282,47308]
===
match
---
operator: = [93839,93840]
operator: = [93946,93947]
===
match
---
name: seconds [39970,39977]
name: seconds [39970,39977]
===
match
---
name: ti [25704,25706]
name: ti [25704,25706]
===
match
---
trailer [30434,30442]
trailer [30434,30442]
===
match
---
expr_stmt [14282,14309]
expr_stmt [14282,14309]
===
match
---
operator: , [4518,4519]
operator: , [4518,4519]
===
match
---
funcdef [72961,73052]
funcdef [73068,73159]
===
match
---
trailer [32111,32119]
trailer [32111,32119]
===
match
---
operator: @ [23314,23315]
operator: @ [23314,23315]
===
match
---
operator: = [43890,43891]
operator: = [43890,43891]
===
match
---
atom_expr [37127,37184]
atom_expr [37127,37184]
===
match
---
name: self [48776,48780]
name: self [48776,48780]
===
match
---
operator: , [4550,4551]
operator: , [4550,4551]
===
match
---
string: """             This attribute is deprecated.             Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.             """ [33198,33349]
string: """             This attribute is deprecated.             Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.             """ [33198,33349]
===
match
---
operator: = [88634,88635]
operator: = [88741,88742]
===
match
---
name: int [92398,92401]
name: int [92505,92508]
===
match
---
name: self [66861,66865]
name: self [66968,66972]
===
match
---
name: session [61018,61025]
name: session [61018,61025]
===
match
---
comparison [43451,43478]
comparison [43451,43478]
===
match
---
name: bool [20160,20164]
name: bool [20160,20164]
===
match
---
trailer [28466,28473]
trailer [28466,28473]
===
match
---
name: dag_id [15645,15651]
name: dag_id [15645,15651]
===
match
---
simple_stmt [3660,3718]
simple_stmt [3660,3718]
===
match
---
name: operator [26586,26594]
name: operator [26586,26594]
===
match
---
atom_expr [53122,53133]
atom_expr [53122,53133]
===
match
---
atom_expr [63006,63029]
atom_expr [63006,63029]
===
match
---
atom_expr [29142,29155]
atom_expr [29142,29155]
===
match
---
atom_expr [67918,67929]
atom_expr [68025,68036]
===
match
---
trailer [84565,84591]
trailer [84672,84698]
===
match
---
name: session [86450,86457]
name: session [86557,86564]
===
match
---
name: ceil [38563,38567]
name: ceil [38563,38567]
===
match
---
name: base_url [23454,23462]
name: base_url [23454,23462]
===
match
---
tfpdef [60944,60965]
tfpdef [60944,60965]
===
match
---
suite [40045,40108]
suite [40045,40108]
===
match
---
atom_expr [51251,51267]
atom_expr [51251,51267]
===
match
---
operator: , [19870,19871]
operator: , [19870,19871]
===
match
---
trailer [53493,53501]
trailer [53493,53501]
===
match
---
expr_stmt [27639,27674]
expr_stmt [27639,27674]
===
match
---
argument [61474,61483]
argument [61474,61483]
===
match
---
atom_expr [30268,30279]
atom_expr [30268,30279]
===
match
---
fstring_end: ' [51994,51995]
fstring_end: ' [51994,51995]
===
match
---
param [93690,93694]
param [93797,93801]
===
match
---
arglist [68148,68155]
arglist [68255,68262]
===
match
---
name: self [15859,15863]
name: self [15859,15863]
===
match
---
name: jinja_env [83777,83786]
name: jinja_env [83884,83893]
===
match
---
trailer [78338,78359]
trailer [78445,78466]
===
match
---
trailer [28949,28960]
trailer [28949,28960]
===
match
---
name: self [16121,16125]
name: self [16121,16125]
===
match
---
operator: , [51180,51181]
operator: , [51180,51181]
===
match
---
simple_stmt [18983,19011]
simple_stmt [18983,19011]
===
match
---
param [23349,23353]
param [23349,23353]
===
match
---
trailer [80496,80498]
trailer [80603,80605]
===
match
---
trailer [92954,92962]
trailer [93061,93069]
===
match
---
return_stmt [90485,90496]
return_stmt [90592,90603]
===
match
---
name: query [30185,30190]
name: query [30185,30190]
===
match
---
operator: = [15651,15652]
operator: = [15651,15652]
===
match
---
name: pool [22771,22775]
name: pool [22771,22775]
===
match
---
operator: , [47883,47884]
operator: , [47883,47884]
===
match
---
operator: = [93886,93887]
operator: = [93993,93994]
===
match
---
name: test_mode [61424,61433]
name: test_mode [61424,61433]
===
match
---
arglist [58671,58728]
arglist [58671,58728]
===
match
---
name: self [93731,93735]
name: self [93838,93842]
===
match
---
funcdef [93682,93741]
funcdef [93789,93848]
===
match
---
trailer [67777,67786]
trailer [67884,67893]
===
match
---
name: dag [3921,3924]
name: dag [3921,3924]
===
match
---
atom_expr [91747,91767]
atom_expr [91854,91874]
===
match
---
name: executor_config [93764,93779]
name: executor_config [93871,93886]
===
match
---
trailer [69023,69025]
trailer [69130,69132]
===
match
---
simple_stmt [11465,11498]
simple_stmt [11465,11498]
===
match
---
trailer [8420,8424]
trailer [8420,8424]
===
match
---
operator: , [49955,49956]
operator: , [49955,49956]
===
match
---
argument [36811,36826]
argument [36811,36826]
===
match
---
name: state [89827,89832]
name: state [89934,89939]
===
match
---
name: send_email [84717,84727]
name: send_email [84824,84834]
===
match
---
trailer [60155,60165]
trailer [60155,60165]
===
match
---
name: failed [37085,37091]
name: failed [37085,37091]
===
match
---
name: property [9767,9775]
name: property [9767,9775]
===
match
---
decorator [66169,66186]
decorator [66276,66293]
===
match
---
if_stmt [24411,24489]
if_stmt [24411,24489]
===
match
---
name: Optional [41556,41564]
name: Optional [41556,41564]
===
match
---
string: 'priority_weight' [92753,92770]
string: 'priority_weight' [92860,92877]
===
match
---
name: merge [7067,7072]
name: merge [7067,7072]
===
match
---
simple_stmt [7086,7154]
simple_stmt [7086,7154]
===
match
---
atom_expr [26448,26461]
atom_expr [26448,26461]
===
match
---
name: test_mode [61733,61742]
name: test_mode [61733,61742]
===
match
---
string: ':' [68148,68151]
string: ':' [68255,68258]
===
match
---
argument [13255,13273]
argument [13255,13273]
===
match
---
trailer [68427,68443]
trailer [68534,68550]
===
match
---
name: cmd [22971,22974]
name: cmd [22971,22974]
===
match
---
suite [46622,46655]
suite [46622,46655]
===
match
---
argument [77457,77474]
argument [77564,77581]
===
match
---
trailer [39171,39282]
trailer [39171,39282]
===
match
---
comparison [61936,61963]
comparison [61936,61963]
===
match
---
trailer [10377,10385]
trailer [10377,10385]
===
match
---
fstring [23562,23588]
fstring [23562,23588]
===
match
---
suite [31138,31749]
suite [31138,31749]
===
match
---
operator: , [19654,19655]
operator: , [19654,19655]
===
match
---
name: self [28502,28506]
name: self [28502,28506]
===
match
---
simple_stmt [14248,14274]
simple_stmt [14248,14274]
===
match
---
name: run_id [24352,24358]
name: run_id [24352,24358]
===
match
---
atom_expr [56046,56062]
atom_expr [56046,56062]
===
match
---
trailer [16015,16024]
trailer [16015,16024]
===
match
---
trailer [11809,11814]
trailer [11809,11814]
===
match
---
operator: , [84438,84439]
operator: , [84545,84546]
===
match
---
name: set_duration [64264,64276]
name: set_duration [64264,64276]
===
match
---
parameters [68413,68415]
parameters [68520,68522]
===
match
---
trailer [51495,51503]
trailer [51495,51503]
===
match
---
name: task [67560,67564]
name: task [67667,67671]
===
match
---
name: start_date [9586,9596]
name: start_date [9586,9596]
===
match
---
operator: , [68151,68152]
operator: , [68258,68259]
===
match
---
expr_stmt [92652,92677]
expr_stmt [92759,92784]
===
match
---
operator: = [44260,44261]
operator: = [44260,44261]
===
match
---
operator: = [46590,46591]
operator: = [46590,46591]
===
match
---
trailer [53967,53982]
trailer [53967,53982]
===
match
---
term [38568,38620]
term [38568,38620]
===
match
---
name: end_date [29164,29172]
name: end_date [29164,29172]
===
match
---
name: _run_finished_callback [59167,59189]
name: _run_finished_callback [59167,59189]
===
match
---
name: state [14178,14183]
name: state [14178,14183]
===
match
---
name: ti [26626,26628]
name: ti [26626,26628]
===
match
---
trailer [15819,15933]
trailer [15819,15933]
===
match
---
return_stmt [68544,68555]
return_stmt [68651,68662]
===
match
---
name: execution_date [74465,74479]
name: execution_date [74572,74586]
===
match
---
name: ti [26762,26764]
name: ti [26762,26764]
===
match
---
name: self [43239,43243]
name: self [43239,43243]
===
match
---
simple_stmt [4757,4774]
simple_stmt [4757,4774]
===
match
---
operator: , [20104,20105]
operator: , [20104,20105]
===
match
---
suite [84704,84772]
suite [84811,84879]
===
match
---
fstring_conversion [72214,72216]
fstring_conversion [72321,72323]
===
match
---
decorated [23032,23309]
decorated [23032,23309]
===
match
---
atom_expr [90912,90931]
atom_expr [91019,91038]
===
match
---
atom_expr [25927,25940]
atom_expr [25927,25940]
===
match
---
name: self [70718,70722]
name: self [70825,70829]
===
match
---
name: email_for_state [65456,65471]
name: email_for_state [65563,65578]
===
match
---
name: Sentry [2721,2727]
name: Sentry [2721,2727]
===
match
---
trailer [90611,90619]
trailer [90718,90726]
===
match
---
string: r'%Y-%m-%d' [74884,74895]
string: r'%Y-%m-%d' [74991,75002]
===
match
---
argument [80923,80955]
argument [81030,81062]
===
match
---
decorated [62319,63310]
decorated [62319,63310]
===
match
---
parameters [69701,69707]
parameters [69808,69814]
===
match
---
operator: = [6925,6926]
operator: = [6925,6926]
===
match
---
trailer [80321,80327]
trailer [80428,80434]
===
match
---
operator: = [25792,25793]
operator: = [25792,25793]
===
match
---
atom_expr [3790,3804]
atom_expr [3790,3804]
===
match
---
name: coerce_datetime [73882,73897]
name: coerce_datetime [73989,74004]
===
match
---
argument [45326,45371]
argument [45326,45371]
===
match
---
operator: , [19416,19417]
operator: , [19416,19417]
===
match
---
operator: , [53274,53275]
operator: , [53274,53275]
===
match
---
simple_stmt [2937,2979]
simple_stmt [2937,2979]
===
match
---
simple_stmt [1672,1715]
simple_stmt [1672,1715]
===
match
---
decorator [23769,23786]
decorator [23769,23786]
===
match
---
name: utcnow [49099,49105]
name: utcnow [49099,49105]
===
match
---
trailer [54041,54045]
trailer [54041,54045]
===
match
---
comparison [68781,68802]
comparison [68888,68909]
===
match
---
param [66284,66317]
param [66391,66424]
===
match
---
name: jinja_context [83399,83412]
name: jinja_context [83506,83519]
===
match
---
name: default [11641,11648]
name: default [11641,11648]
===
match
---
operator: = [26873,26874]
operator: = [26873,26874]
===
match
---
parameters [27849,27869]
parameters [27849,27869]
===
match
---
string: '' [68153,68155]
string: '' [68260,68262]
===
match
---
atom_expr [56160,56176]
atom_expr [56160,56176]
===
match
---
name: ds [74205,74207]
name: ds [74312,74314]
===
match
---
name: Stats [52823,52828]
name: Stats [52823,52828]
===
match
---
tfpdef [85176,85210]
tfpdef [85283,85317]
===
match
---
trailer [74642,74657]
trailer [74749,74764]
===
match
---
trailer [29088,29097]
trailer [29088,29097]
===
match
---
name: task [30524,30528]
name: task [30524,30528]
===
match
---
simple_stmt [1305,1487]
simple_stmt [1305,1487]
===
match
---
simple_stmt [93016,93037]
simple_stmt [93123,93144]
===
match
---
name: dep_context [35893,35904]
name: dep_context [35893,35904]
===
match
---
name: contextlib [794,804]
name: contextlib [794,804]
===
match
---
operator: = [53612,53613]
operator: = [53612,53613]
===
match
---
trailer [47014,47019]
trailer [47014,47019]
===
match
---
string: "task_instance" [11179,11194]
string: "task_instance" [11179,11194]
===
match
---
atom_expr [12580,12592]
atom_expr [12580,12592]
===
match
---
try_stmt [4815,4923]
try_stmt [4815,4923]
===
match
---
simple_stmt [61644,61891]
simple_stmt [61644,61891]
===
match
---
trailer [78359,78382]
trailer [78466,78489]
===
match
---
name: state [50671,50676]
name: state [50671,50676]
===
match
---
operator: = [39958,39959]
operator: = [39958,39959]
===
match
---
trailer [80200,80221]
trailer [80307,80328]
===
match
---
trailer [57217,57234]
trailer [57217,57234]
===
match
---
operator: , [8664,8665]
operator: , [8664,8665]
===
match
---
funcdef [29565,30550]
funcdef [29565,30550]
===
match
---
trailer [93735,93740]
trailer [93842,93847]
===
match
---
name: task_id [53113,53120]
name: task_id [53113,53120]
===
match
---
atom_expr [76337,76398]
atom_expr [76444,76505]
===
match
---
trailer [86258,86476]
trailer [86365,86583]
===
match
---
trailer [6517,6525]
trailer [6517,6525]
===
match
---
funcdef [17287,17824]
funcdef [17287,17824]
===
match
---
name: airflow [3166,3173]
name: airflow [3166,3173]
===
match
---
param [35887,35892]
param [35887,35892]
===
match
---
name: default_var [70252,70263]
name: default_var [70359,70370]
===
match
---
name: self [26240,26244]
name: self [26240,26244]
===
match
---
import_from [3271,3313]
import_from [3271,3313]
===
match
---
trailer [93853,93855]
trailer [93960,93962]
===
match
---
atom_expr [58533,58560]
atom_expr [58533,58560]
===
match
---
name: verbose [44270,44277]
name: verbose [44270,44277]
===
match
---
name: dump [5303,5307]
name: dump [5303,5307]
===
match
---
simple_stmt [6275,6301]
simple_stmt [6275,6301]
===
match
---
operator: = [61246,61247]
operator: = [61246,61247]
===
match
---
atom_expr [40074,40099]
atom_expr [40074,40099]
===
match
---
operator: , [13163,13164]
operator: , [13163,13164]
===
match
---
operator: = [63475,63476]
operator: = [63475,63476]
===
match
---
import_from [52371,52441]
import_from [52371,52441]
===
match
---
trailer [78624,78641]
trailer [78731,78748]
===
match
---
trailer [49148,49155]
trailer [49148,49155]
===
match
---
simple_stmt [73976,74019]
simple_stmt [74083,74126]
===
match
---
try_stmt [61572,62077]
try_stmt [61572,62077]
===
match
---
name: dag_id [22156,22162]
name: dag_id [22156,22162]
===
match
---
trailer [35208,35219]
trailer [35208,35219]
===
match
---
operator: , [49516,49517]
operator: , [49516,49517]
===
match
---
name: UtcDateTime [12023,12034]
name: UtcDateTime [12023,12034]
===
match
---
name: params [67701,67707]
name: params [67808,67814]
===
match
---
name: task_tries [7950,7960]
name: task_tries [7950,7960]
===
match
---
operator: , [33869,33870]
operator: , [33869,33870]
===
match
---
fstring_start: f" [37893,37895]
fstring_start: f" [37893,37895]
===
match
---
name: session [51634,51641]
name: session [51634,51641]
===
match
---
name: pendulum [34157,34165]
name: pendulum [34157,34165]
===
match
---
simple_stmt [15799,15944]
simple_stmt [15799,15944]
===
match
---
argument [83199,83214]
argument [83306,83321]
===
match
---
name: PodGenerator [80513,80525]
name: PodGenerator [80620,80632]
===
match
---
atom_expr [64233,64250]
atom_expr [64233,64250]
===
match
---
trailer [26722,26726]
trailer [26722,26726]
===
match
---
expr_stmt [25704,25762]
expr_stmt [25704,25762]
===
match
---
string: 'ti_failures' [64362,64375]
string: 'ti_failures' [64362,64375]
===
match
---
tfpdef [66931,66947]
tfpdef [67038,67054]
===
match
---
atom_expr [86559,86584]
atom_expr [86666,86691]
===
match
---
name: execution_date [74105,74119]
name: execution_date [74212,74226]
===
match
---
atom_expr [72785,72820]
atom_expr [72892,72927]
===
match
---
name: self [26398,26402]
name: self [26398,26402]
===
match
---
simple_stmt [4828,4854]
simple_stmt [4828,4854]
===
match
---
atom_expr [91006,91054]
atom_expr [91113,91161]
===
match
---
simple_stmt [59565,59603]
simple_stmt [59565,59603]
===
match
---
expr_stmt [16533,16555]
expr_stmt [16533,16555]
===
match
---
param [85227,85251]
param [85334,85358]
===
match
---
atom_expr [51475,51485]
atom_expr [51475,51485]
===
match
---
if_stmt [37082,37118]
if_stmt [37082,37118]
===
match
---
decorator [93598,93608]
decorator [93705,93715]
===
match
---
atom_expr [68664,68691]
atom_expr [68771,68798]
===
match
---
annassign [92662,92677]
annassign [92769,92784]
===
match
---
name: is_eligible_to_retry [65382,65402]
name: is_eligible_to_retry [65489,65509]
===
match
---
atom_expr [65673,65689]
atom_expr [65780,65796]
===
match
---
string: """         Get the very latest state from the database, if a session is passed,         we use and looking up the state becomes part of the session, otherwise         a new session is used.          :param session: SQLAlchemy ORM Session         :type session: Session         """ [23844,24125]
string: """         Get the very latest state from the database, if a session is passed,         we use and looking up the state becomes part of the session, otherwise         a new session is used.          :param session: SQLAlchemy ORM Session         :type session: Session         """ [23844,24125]
===
match
---
simple_stmt [1206,1231]
simple_stmt [1206,1231]
===
match
---
suite [50514,50548]
suite [50514,50548]
===
match
---
operator: { [53412,53413]
operator: { [53412,53413]
===
match
---
tfpdef [60911,60926]
tfpdef [60911,60926]
===
match
---
trailer [30638,30643]
trailer [30638,30643]
===
match
---
atom_expr [28096,28260]
atom_expr [28096,28260]
===
match
---
suite [25691,25763]
suite [25691,25763]
===
match
---
name: defer [58067,58072]
name: defer [58067,58072]
===
match
---
operator: , [30613,30614]
operator: , [30613,30614]
===
match
---
trailer [31599,31614]
trailer [31599,31614]
===
match
---
operator: = [92853,92854]
operator: = [92960,92961]
===
match
---
atom_expr [27639,27655]
atom_expr [27639,27655]
===
match
---
name: on_execute_callback [59030,59049]
name: on_execute_callback [59030,59049]
===
match
---
suite [62441,63310]
suite [62441,63310]
===
match
---
simple_stmt [2811,2888]
simple_stmt [2811,2888]
===
match
---
name: xcom [89442,89446]
name: xcom [89549,89553]
===
match
---
name: get_rendered_k8s_spec [79132,79153]
name: get_rendered_k8s_spec [79239,79260]
===
match
---
operator: = [80194,80195]
operator: = [80301,80302]
===
match
---
string: 'yesterday_ds' [77872,77886]
string: 'yesterday_ds' [77979,77993]
===
match
---
parameters [59189,59242]
parameters [59189,59242]
===
match
---
name: Context [66997,67004]
name: Context [67104,67111]
===
match
---
operator: { [37939,37940]
operator: { [37939,37940]
===
match
---
atom_expr [66253,66274]
atom_expr [66360,66381]
===
match
---
trailer [28967,28978]
trailer [28967,28978]
===
match
---
name: property [93361,93369]
name: property [93468,93476]
===
match
---
if_stmt [65877,66077]
if_stmt [65984,66184]
===
match
---
trailer [22849,22856]
trailer [22849,22856]
===
match
---
atom_expr [48776,48829]
atom_expr [48776,48829]
===
match
---
trailer [52909,52926]
trailer [52909,52926]
===
match
---
operator: -> [69172,69174]
operator: -> [69279,69281]
===
match
---
argument [33395,33407]
argument [33395,33407]
===
match
---
atom_expr [52171,52205]
atom_expr [52171,52205]
===
match
---
name: dict [83536,83540]
name: dict [83643,83647]
===
match
---
trailer [33699,33704]
trailer [33699,33704]
===
match
---
name: dag_id [28132,28138]
name: dag_id [28132,28138]
===
match
---
name: downstream_task_ids [30118,30137]
name: downstream_task_ids [30118,30137]
===
match
---
name: task_id [89773,89780]
name: task_id [89880,89887]
===
match
---
operator: @ [34605,34606]
operator: @ [34605,34606]
===
match
---
return_stmt [33427,33456]
return_stmt [33427,33456]
===
match
---
trailer [90971,90978]
trailer [91078,91085]
===
match
---
argument [80619,80666]
argument [80726,80773]
===
match
---
trailer [27048,27083]
trailer [27048,27083]
===
match
---
decorator [24515,24532]
decorator [24515,24532]
===
match
---
name: REQUEUEABLE_DEPS [43906,43922]
name: REQUEUEABLE_DEPS [43906,43922]
===
match
---
expr_stmt [83143,83215]
expr_stmt [83250,83322]
===
match
---
trailer [30427,30459]
trailer [30427,30459]
===
match
---
name: bool [63470,63474]
name: bool [63470,63474]
===
match
---
atom_expr [11803,11814]
atom_expr [11803,11814]
===
match
---
atom_expr [85926,85965]
atom_expr [86033,86072]
===
match
---
operator: ** [12206,12208]
operator: ** [12206,12208]
===
match
---
name: Optional [20226,20234]
name: Optional [20226,20234]
===
match
---
simple_stmt [23844,24126]
simple_stmt [23844,24126]
===
match
---
name: session [31048,31055]
name: session [31048,31055]
===
match
---
trailer [56910,56912]
trailer [56910,56912]
===
match
---
trailer [39289,39298]
trailer [39289,39298]
===
match
---
trailer [51925,51930]
trailer [51925,51930]
===
match
---
arglist [13043,13062]
arglist [13043,13062]
===
match
---
operator: = [80559,80560]
operator: = [80666,80667]
===
match
---
trailer [16537,16547]
trailer [16537,16547]
===
match
---
operator: } [53418,53419]
operator: } [53418,53419]
===
match
---
name: task_id_by_key [8148,8162]
name: task_id_by_key [8148,8162]
===
match
---
name: dag_id [37916,37922]
name: dag_id [37916,37922]
===
match
---
suite [32346,32378]
suite [32346,32378]
===
match
---
name: fd [5081,5083]
name: fd [5081,5083]
===
match
---
name: self [37911,37915]
name: self [37911,37915]
===
match
---
name: context [53605,53612]
name: context [53605,53612]
===
match
---
name: sqlalchemy [1609,1619]
name: sqlalchemy [1609,1619]
===
match
---
name: airflow [3319,3326]
name: airflow [3319,3326]
===
match
---
simple_stmt [6912,6970]
simple_stmt [6912,6970]
===
match
---
atom_expr [34148,34175]
atom_expr [34148,34175]
===
match
---
string: """         Checks whether the immediate dependents of this task instance have succeeded or have been skipped.         This is meant to be used by wait_for_downstream.          This is useful when you do not want to start processing the next         schedule of a task until the dependents are done. For instance,         if the task DROPs and recreates a table.          :param session: SQLAlchemy ORM Session         :type session: Session         """ [29618,30071]
string: """         Checks whether the immediate dependents of this task instance have succeeded or have been skipped.         This is meant to be used by wait_for_downstream.          This is useful when you do not want to start processing the next         schedule of a task until the dependents are done. For instance,         if the task DROPs and recreates a table.          :param session: SQLAlchemy ORM Session         :type session: Session         """ [29618,30071]
===
match
---
name: Exception [59074,59083]
name: Exception [59074,59083]
===
match
---
except_clause [51294,51322]
except_clause [51294,51322]
===
match
---
simple_stmt [80337,80363]
simple_stmt [80444,80470]
===
match
---
simple_stmt [73644,73696]
simple_stmt [73751,73803]
===
match
---
annassign [3822,3842]
annassign [3822,3842]
===
match
---
argument [12141,12153]
argument [12141,12153]
===
match
---
atom_expr [45605,45615]
atom_expr [45605,45615]
===
match
---
operator: , [10385,10386]
operator: , [10385,10386]
===
match
---
operator: -> [86750,86752]
operator: -> [86857,86859]
===
match
---
operator: , [63524,63525]
operator: , [63524,63525]
===
match
---
arglist [35076,35104]
arglist [35076,35104]
===
match
---
name: self [37259,37263]
name: self [37259,37263]
===
match
---
name: extend [22520,22526]
name: extend [22520,22526]
===
match
---
string: '' [47305,47307]
string: '' [47305,47307]
===
match
---
tfpdef [59196,59234]
tfpdef [59196,59234]
===
match
---
name: str [91978,91981]
name: str [92085,92088]
===
match
---
name: Connection [71838,71848]
name: Connection [71945,71955]
===
match
---
name: check_and_change_state_before_execution [41134,41173]
name: check_and_change_state_before_execution [41134,41173]
===
match
---
operator: = [73533,73534]
operator: = [73640,73641]
===
match
---
name: key [86276,86279]
name: key [86383,86386]
===
match
---
if_stmt [6039,6301]
if_stmt [6039,6301]
===
match
---
trailer [59049,59058]
trailer [59049,59058]
===
match
---
simple_stmt [62627,62647]
simple_stmt [62627,62647]
===
match
---
exprlist [8042,8060]
exprlist [8042,8060]
===
match
---
atom_expr [66641,66651]
atom_expr [66748,66758]
===
match
---
name: ignore_all_deps [22404,22419]
name: ignore_all_deps [22404,22419]
===
match
---
name: self [81289,81293]
name: self [81396,81400]
===
match
---
name: t [90837,90838]
name: t [90944,90945]
===
match
---
name: priority_weight [26539,26554]
name: priority_weight [26539,26554]
===
match
---
operator: , [7775,7776]
operator: , [7775,7776]
===
match
---
name: count [89662,89667]
name: count [89769,89774]
===
match
---
operator: -> [72990,72992]
operator: -> [73097,73099]
===
match
---
tfpdef [41427,41442]
tfpdef [41427,41442]
===
match
---
trailer [66033,66076]
trailer [66140,66183]
===
match
---
name: rendered_task_instance_fields [78280,78309]
name: rendered_task_instance_fields [78387,78416]
===
match
---
name: task [46945,46949]
name: task [46945,46949]
===
match
---
expr_stmt [9708,9720]
expr_stmt [9708,9720]
===
match
---
trailer [76900,76908]
trailer [77007,77015]
===
match
---
operator: , [74571,74572]
operator: , [74678,74679]
===
match
---
argument [13827,13850]
argument [13827,13850]
===
match
---
name: PickleType [12130,12140]
name: PickleType [12130,12140]
===
match
---
funcdef [9959,10192]
funcdef [9959,10192]
===
match
---
operator: , [75273,75274]
operator: , [75380,75381]
===
match
---
atom_expr [91558,91568]
atom_expr [91665,91675]
===
match
---
name: raw [89929,89932]
name: raw [90036,90039]
===
match
---
name: log [60152,60155]
name: log [60152,60155]
===
match
---
trailer [40671,40679]
trailer [40671,40679]
===
match
---
atom_expr [61644,61890]
atom_expr [61644,61890]
===
match
---
atom_expr [84065,84119]
atom_expr [84172,84226]
===
match
---
name: conf [75127,75131]
name: conf [75234,75238]
===
match
---
name: next_method [64705,64716]
name: next_method [64812,64823]
===
match
---
expr_stmt [32255,32321]
expr_stmt [32255,32321]
===
match
---
arglist [47345,47720]
arglist [47345,47720]
===
match
---
name: self [60667,60671]
name: self [60667,60671]
===
match
---
expr_stmt [59619,59647]
expr_stmt [59619,59647]
===
match
---
trailer [30417,30423]
trailer [30417,30423]
===
match
---
name: State [43465,43470]
name: State [43465,43470]
===
match
---
operator: , [20286,20287]
operator: , [20286,20287]
===
match
---
name: SKIPPED [30435,30442]
name: SKIPPED [30435,30442]
===
match
---
decorator [23032,23042]
decorator [23032,23042]
===
match
---
name: max_tries [6934,6943]
name: max_tries [6934,6943]
===
match
---
name: Optional [47901,47909]
name: Optional [47901,47909]
===
match
---
name: run_id [91782,91788]
name: run_id [91889,91895]
===
match
---
name: self [39245,39249]
name: self [39245,39249]
===
match
---
if_stmt [8474,8802]
if_stmt [8474,8802]
===
match
---
atom_expr [78312,78382]
atom_expr [78419,78489]
===
match
---
name: XCom [2628,2632]
name: XCom [2628,2632]
===
match
---
string: 'Immediate failure requested. ' [65814,65845]
string: 'Immediate failure requested. ' [65921,65952]
===
match
---
simple_stmt [3602,3656]
simple_stmt [3602,3656]
===
match
---
argument [11427,11443]
argument [11427,11443]
===
match
---
expr_stmt [15246,15322]
expr_stmt [15246,15322]
===
match
---
trailer [51953,51960]
trailer [51953,51960]
===
match
---
suite [93786,93824]
suite [93893,93931]
===
match
---
name: ti [7142,7144]
name: ti [7142,7144]
===
match
---
parameters [73943,73945]
parameters [74050,74052]
===
match
---
string: """Set TI duration""" [84817,84838]
string: """Set TI duration""" [84924,84945]
===
match
---
trailer [29025,29034]
trailer [29025,29034]
===
match
---
atom_expr [92785,92806]
atom_expr [92892,92913]
===
match
---
return_stmt [37105,37117]
return_stmt [37105,37117]
===
match
---
simple_stmt [10558,10570]
simple_stmt [10558,10570]
===
match
---
operator: , [15130,15131]
operator: , [15130,15131]
===
match
---
suite [83998,84042]
suite [84105,84149]
===
match
---
trailer [51581,51596]
trailer [51581,51596]
===
match
---
trailer [89143,89151]
trailer [89250,89258]
===
match
---
trailer [46445,46449]
trailer [46445,46449]
===
match
---
trailer [25579,25587]
trailer [25579,25587]
===
match
---
name: init_on_load [16126,16138]
name: init_on_load [16126,16138]
===
match
---
suite [84808,85075]
suite [84915,85182]
===
match
---
or_test [26448,26466]
or_test [26448,26466]
===
match
---
argument [91085,91147]
argument [91192,91254]
===
match
---
name: context [54656,54663]
name: context [54656,54663]
===
match
---
suite [59668,59723]
suite [59668,59723]
===
match
---
name: pool [26403,26407]
name: pool [26403,26407]
===
match
---
atom_expr [54486,54514]
atom_expr [54486,54514]
===
match
---
simple_stmt [37537,37773]
simple_stmt [37537,37773]
===
match
---
name: dag_id [24231,24237]
name: dag_id [24231,24237]
===
match
---
name: test_mode [52148,52157]
name: test_mode [52148,52157]
===
match
---
argument [83562,83581]
argument [83669,83688]
===
match
---
name: get_hostname [43352,43364]
name: get_hostname [43352,43364]
===
match
---
arglist [50796,50863]
arglist [50796,50863]
===
match
---
argument [51827,51842]
argument [51827,51842]
===
match
---
trailer [74637,74658]
trailer [74744,74765]
===
match
---
atom_expr [77173,77184]
atom_expr [77280,77291]
===
match
---
trailer [92165,92173]
trailer [92272,92280]
===
match
---
operator: , [2178,2179]
operator: , [2178,2179]
===
match
---
argument [86450,86465]
argument [86557,86572]
===
match
---
operator: = [16025,16026]
operator: = [16025,16026]
===
match
---
atom_expr [84913,84962]
atom_expr [85020,85069]
===
match
---
simple_stmt [72512,72526]
simple_stmt [72619,72633]
===
match
---
atom_expr [75222,75273]
atom_expr [75329,75380]
===
match
---
operator: , [77329,77330]
operator: , [77436,77437]
===
match
---
param [84794,84798]
param [84901,84905]
===
match
---
name: self [49723,49727]
name: self [49723,49727]
===
match
---
param [89515,89522]
param [89622,89629]
===
match
---
operator: , [32307,32308]
operator: , [32307,32308]
===
match
---
param [52470,52477]
param [52470,52477]
===
match
---
operator: { [37954,37955]
operator: { [37954,37955]
===
match
---
atom_expr [52087,52104]
atom_expr [52087,52104]
===
match
---
name: associationproxy [1507,1523]
name: associationproxy [1507,1523]
===
match
---
name: email_for_state [65751,65766]
name: email_for_state [65858,65873]
===
match
---
fstring_end: " [23661,23662]
fstring_end: " [23661,23662]
===
match
---
operator: = [65429,65430]
operator: = [65536,65537]
===
match
---
name: self [84868,84872]
name: self [84975,84979]
===
match
---
name: filter [24194,24200]
name: filter [24194,24200]
===
match
---
name: self [9928,9932]
name: self [9928,9932]
===
match
---
atom_expr [9436,9449]
atom_expr [9436,9449]
===
match
---
operator: = [64231,64232]
operator: = [64231,64232]
===
match
---
name: ti [25817,25819]
name: ti [25817,25819]
===
match
---
name: typing_compat [2950,2963]
name: typing_compat [2950,2963]
===
match
---
simple_stmt [2304,2353]
simple_stmt [2304,2353]
===
match
---
param [30623,30651]
param [30623,30651]
===
match
---
if_stmt [46408,46476]
if_stmt [46408,46476]
===
match
---
string: "Clearing XCom data" [28066,28086]
string: "Clearing XCom data" [28066,28086]
===
match
---
trailer [40679,40692]
trailer [40679,40692]
===
match
---
string: "exception" [60415,60426]
string: "exception" [60415,60426]
===
match
---
expr_stmt [69725,69740]
expr_stmt [69832,69847]
===
match
---
atom_expr [86052,86240]
atom_expr [86159,86347]
===
match
---
name: self [26607,26611]
name: self [26607,26611]
===
match
---
simple_stmt [4643,4687]
simple_stmt [4643,4687]
===
match
---
number: 1 [17942,17943]
number: 1 [17942,17943]
===
match
---
or_test [55820,55842]
or_test [55820,55842]
===
match
---
atom_expr [26430,26445]
atom_expr [26430,26445]
===
match
---
strings [72198,72315]
strings [72305,72422]
===
match
---
name: warnings [33691,33699]
name: warnings [33691,33699]
===
match
---
name: session [48859,48866]
name: session [48859,48866]
===
match
---
name: replace [68123,68130]
name: replace [68230,68237]
===
match
---
trailer [83363,83389]
trailer [83470,83496]
===
match
---
simple_stmt [1487,1549]
simple_stmt [1487,1549]
===
match
---
trailer [6017,6025]
trailer [6017,6025]
===
match
---
argument [13551,13603]
argument [13551,13603]
===
match
---
trailer [40838,40844]
trailer [40838,40844]
===
match
---
string: """         This attribute is deprecated.         Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.         """ [33023,33162]
string: """         This attribute is deprecated.         Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.         """ [33023,33162]
===
match
---
name: ignore_depends_on_past [44061,44083]
name: ignore_depends_on_past [44061,44083]
===
match
---
trailer [52186,52204]
trailer [52186,52204]
===
match
---
trailer [58791,58802]
trailer [58791,58802]
===
match
---
trailer [30523,30549]
trailer [30523,30549]
===
match
---
name: self [66570,66574]
name: self [66677,66681]
===
match
---
name: get_previous_dagrun [32272,32291]
name: get_previous_dagrun [32272,32291]
===
match
---
testlist_comp [89216,89260]
testlist_comp [89323,89367]
===
match
---
name: dag_id [90816,90822]
name: dag_id [90923,90929]
===
match
---
name: bool [41405,41409]
name: bool [41405,41409]
===
match
---
operator: = [60428,60429]
operator: = [60428,60429]
===
match
---
name: self [30956,30960]
name: self [30956,30960]
===
match
---
operator: < [38990,38991]
operator: < [38990,38991]
===
match
---
name: self [24935,24939]
name: self [24935,24939]
===
match
---
string: 'TaskInstanceKey' [10243,10260]
string: 'TaskInstanceKey' [10243,10260]
===
match
---
name: self [33008,33012]
name: self [33008,33012]
===
match
---
operator: , [47171,47172]
operator: , [47171,47172]
===
match
---
name: _get_previous_dagrun_success [69225,69253]
name: _get_previous_dagrun_success [69332,69360]
===
match
---
atom_expr [65539,65551]
atom_expr [65646,65658]
===
match
---
simple_stmt [54882,54937]
simple_stmt [54882,54937]
===
match
---
operator: , [28563,28564]
operator: , [28563,28564]
===
match
---
name: self [16533,16537]
name: self [16533,16537]
===
match
---
operator: -> [30701,30703]
operator: -> [30701,30703]
===
match
---
suite [68952,69129]
suite [69059,69236]
===
match
---
trailer [63194,63200]
trailer [63194,63200]
===
match
---
expr_stmt [70718,70770]
expr_stmt [70825,70877]
===
match
---
simple_stmt [49782,50077]
simple_stmt [49782,50077]
===
match
---
name: self [37179,37183]
name: self [37179,37183]
===
match
---
operator: , [12874,12875]
operator: , [12874,12875]
===
match
---
atom_expr [26709,26717]
atom_expr [26709,26717]
===
match
---
atom_expr [59619,59639]
atom_expr [59619,59639]
===
match
---
name: next_method [56463,56474]
name: next_method [56463,56474]
===
match
---
trailer [52576,52581]
trailer [52576,52581]
===
match
---
import_from [3546,3596]
import_from [3546,3596]
===
match
---
trailer [47511,47517]
trailer [47511,47517]
===
match
---
name: on_success_callback [59931,59950]
name: on_success_callback [59931,59950]
===
match
---
name: context [54664,54671]
name: context [54664,54671]
===
match
---
name: dag_id [91087,91093]
name: dag_id [91194,91200]
===
match
---
trailer [93342,93354]
trailer [93449,93461]
===
match
---
number: 80 [43643,43645]
number: 80 [43643,43645]
===
match
---
name: task_copy [56035,56044]
name: task_copy [56035,56044]
===
match
---
suite [62518,62538]
suite [62518,62538]
===
match
---
name: provide_session [23770,23785]
name: provide_session [23770,23785]
===
match
---
simple_stmt [79797,79842]
simple_stmt [79904,79949]
===
match
---
atom_expr [11706,11718]
atom_expr [11706,11718]
===
match
---
operator: == [60234,60236]
operator: == [60234,60236]
===
match
---
tfpdef [60796,60818]
tfpdef [60796,60818]
===
match
---
atom_expr [6945,6968]
atom_expr [6945,6968]
===
match
---
name: ignore_task_deps [61283,61299]
name: ignore_task_deps [61283,61299]
===
match
---
operator: - [56581,56582]
operator: - [56581,56582]
===
match
---
name: external_executor_id [46547,46567]
name: external_executor_id [46547,46567]
===
match
---
operator: = [41249,41250]
operator: = [41249,41250]
===
match
---
name: self [34063,34067]
name: self [34063,34067]
===
match
---
expr_stmt [68705,68765]
expr_stmt [68812,68872]
===
match
---
name: open [83982,83986]
name: open [84089,84093]
===
match
---
and_test [6363,6392]
and_test [6363,6392]
===
match
---
operator: = [11733,11734]
operator: = [11733,11734]
===
match
---
operator: = [78310,78311]
operator: = [78417,78418]
===
match
---
or_test [37358,37385]
or_test [37358,37385]
===
match
---
operator: = [18264,18265]
operator: = [18264,18265]
===
match
---
name: self [14248,14252]
name: self [14248,14252]
===
match
---
trailer [59211,59234]
trailer [59211,59234]
===
match
---
atom_expr [39224,39243]
atom_expr [39224,39243]
===
match
---
name: delete_qry [8267,8277]
name: delete_qry [8267,8277]
===
match
---
expr_stmt [14248,14273]
expr_stmt [14248,14273]
===
match
---
trailer [45661,45676]
trailer [45661,45676]
===
match
---
trailer [14252,14259]
trailer [14252,14259]
===
match
---
name: self [66839,66843]
name: self [66946,66950]
===
match
---
operator: = [25731,25732]
operator: = [25731,25732]
===
match
---
name: data_interval [69111,69124]
name: data_interval [69218,69231]
===
match
---
simple_stmt [66116,66136]
simple_stmt [66223,66243]
===
match
---
name: error_file [64096,64106]
name: error_file [64096,64106]
===
match
---
arglist [74563,74591]
arglist [74670,74698]
===
match
---
name: TaskReschedule [3765,3779]
name: TaskReschedule [3765,3779]
===
match
---
name: self [37955,37959]
name: self [37955,37959]
===
match
---
name: self [26430,26434]
name: self [26430,26434]
===
match
---
operator: = [19273,19274]
operator: = [19273,19274]
===
match
---
operator: = [34521,34522]
operator: = [34521,34522]
===
match
---
operator: + [17174,17175]
operator: + [17174,17175]
===
match
---
trailer [25546,25553]
trailer [25546,25553]
===
match
---
atom_expr [28446,28518]
atom_expr [28446,28518]
===
match
---
name: min_backoff [39449,39460]
name: min_backoff [39449,39460]
===
match
---
atom_expr [46093,46112]
atom_expr [46093,46112]
===
match
---
operator: , [79955,79956]
operator: , [80062,80063]
===
match
---
operator: ** [38595,38597]
operator: ** [38595,38597]
===
match
---
operator: = [18241,18242]
operator: = [18241,18242]
===
match
---
suite [81306,84413]
suite [81413,84520]
===
match
---
operator: = [53869,53870]
operator: = [53869,53870]
===
match
---
operator: = [47151,47152]
operator: = [47151,47152]
===
match
---
operator: , [47627,47628]
operator: , [47627,47628]
===
match
---
trailer [77439,77475]
trailer [77546,77582]
===
match
---
operator: * [72061,72062]
operator: * [72168,72169]
===
match
---
except_clause [50921,50977]
except_clause [50921,50977]
===
match
---
argument [51199,51220]
argument [51199,51220]
===
match
---
string: 'ti_pool' [12987,12996]
string: 'ti_pool' [12987,12996]
===
match
---
operator: = [70727,70728]
operator: = [70834,70835]
===
match
---
name: session [66474,66481]
name: session [66581,66588]
===
match
---
atom_expr [62746,62755]
atom_expr [62746,62755]
===
match
---
dotted_name [1851,1875]
dotted_name [1851,1875]
===
match
---
operator: , [77816,77817]
operator: , [77923,77924]
===
match
---
simple_stmt [57800,57825]
simple_stmt [57800,57825]
===
match
---
param [18083,18112]
param [18083,18112]
===
match
---
string: """Functions that need to be run before a Task is executed""" [58893,58954]
string: """Functions that need to be run before a Task is executed""" [58893,58954]
===
match
---
name: start_date [35250,35260]
name: start_date [35250,35260]
===
match
---
atom_expr [65431,65443]
atom_expr [65538,65550]
===
match
---
name: get_next_execution_date [76085,76108]
name: get_next_execution_date [76192,76215]
===
match
---
trailer [51774,51789]
trailer [51774,51789]
===
match
---
simple_stmt [20316,22114]
simple_stmt [20316,22114]
===
match
---
trailer [18882,18892]
trailer [18882,18892]
===
match
---
atom_expr [11611,11651]
atom_expr [11611,11651]
===
match
---
trailer [31760,31764]
trailer [31760,31764]
===
match
---
suite [56865,56913]
suite [56865,56913]
===
match
---
argument [11408,11424]
argument [11408,11424]
===
match
---
operator: @ [40408,40409]
operator: @ [40408,40409]
===
match
---
name: mark_success [61375,61387]
name: mark_success [61375,61387]
===
match
---
string: """Fetch rendered template fields from DB""" [79183,79227]
string: """Fetch rendered template fields from DB""" [79290,79334]
===
match
---
trailer [67169,67177]
trailer [67276,67284]
===
match
---
string: "Failed when executing execute callback" [59116,59156]
string: "Failed when executing execute callback" [59116,59156]
===
match
---
atom_expr [6982,6990]
atom_expr [6982,6990]
===
match
---
arglist [28120,28250]
arglist [28120,28250]
===
match
---
name: api_client [3569,3579]
name: api_client [3569,3579]
===
match
---
operator: -> [68253,68255]
operator: -> [68360,68362]
===
match
---
operator: = [51621,51622]
operator: = [51621,51622]
===
match
---
name: self [39197,39201]
name: self [39197,39201]
===
match
---
name: dep_context [36798,36809]
name: dep_context [36798,36809]
===
match
---
trailer [47057,47072]
trailer [47057,47072]
===
match
---
atom_expr [7950,7968]
atom_expr [7950,7968]
===
match
---
operator: @ [72596,72597]
operator: @ [72703,72704]
===
match
---
atom_expr [92709,92722]
atom_expr [92816,92829]
===
match
---
string: 'yesterday_ds' [77927,77941]
string: 'yesterday_ds' [78034,78048]
===
match
---
string: "error" [55899,55906]
string: "error" [55899,55906]
===
match
---
trailer [72466,72495]
trailer [72573,72602]
===
match
---
trailer [83942,83956]
trailer [84049,84063]
===
match
---
param [34114,34138]
param [34114,34138]
===
match
---
operator: = [67930,67931]
operator: = [68037,68038]
===
match
---
parameters [80044,80085]
parameters [80151,80192]
===
match
---
name: dag_id [9034,9040]
name: dag_id [9034,9040]
===
match
---
operator: , [77149,77150]
operator: , [77256,77257]
===
match
---
operator: { [77301,77302]
operator: { [77408,77409]
===
match
---
operator: , [63448,63449]
operator: , [63448,63449]
===
match
---
trailer [63770,63776]
trailer [63770,63776]
===
match
---
decorated [92968,93037]
decorated [93075,93144]
===
match
---
name: res [61539,61542]
name: res [61539,61542]
===
match
---
name: IO [1067,1069]
name: IO [1067,1069]
===
match
---
operator: = [76894,76895]
operator: = [77001,77002]
===
match
---
return_stmt [91426,91685]
return_stmt [91533,91792]
===
match
---
name: max_tries [82924,82933]
name: max_tries [83031,83040]
===
match
---
name: lock_for_update [25675,25690]
name: lock_for_update [25675,25690]
===
match
---
name: is_container [88978,88990]
name: is_container [89085,89097]
===
match
---
if_stmt [88975,89448]
if_stmt [89082,89555]
===
match
---
atom_expr [4764,4773]
atom_expr [4764,4773]
===
match
---
atom_expr [83073,83098]
atom_expr [83180,83205]
===
match
---
name: task_ids [89252,89260]
name: task_ids [89359,89367]
===
match
---
trailer [11554,11561]
trailer [11554,11561]
===
match
---
name: session [63534,63541]
name: session [63534,63541]
===
match
---
name: self [49782,49786]
name: self [49782,49786]
===
match
---
string: "next_ds_nodash" [75922,75938]
string: "next_ds_nodash" [76029,76045]
===
match
---
string: "--pickle" [22295,22305]
string: "--pickle" [22295,22305]
===
match
---
atom_expr [92950,92962]
atom_expr [93057,93069]
===
match
---
expr_stmt [67918,67949]
expr_stmt [68025,68056]
===
match
---
string: """Get failed Dependencies""" [37306,37335]
string: """Get failed Dependencies""" [37306,37335]
===
match
---
suite [5988,7154]
suite [5988,7154]
===
match
---
argument [7834,7968]
argument [7834,7968]
===
match
---
name: first_task_id [91121,91134]
name: first_task_id [91228,91241]
===
match
---
name: ti [26536,26538]
name: ti [26536,26538]
===
match
---
name: get [83939,83942]
name: get [84046,84049]
===
match
---
operator: = [61090,61091]
operator: = [61090,61091]
===
match
---
atom_expr [19056,19074]
atom_expr [19056,19074]
===
match
---
trailer [53740,53745]
trailer [53740,53745]
===
match
---
name: external_executor_id [46524,46544]
name: external_executor_id [46524,46544]
===
match
---
name: self [29159,29163]
name: self [29159,29163]
===
match
---
name: info [49791,49795]
name: info [49791,49795]
===
match
---
trailer [86189,86226]
trailer [86296,86333]
===
match
---
funcdef [5326,9604]
funcdef [5326,9604]
===
match
---
atom_expr [67584,67640]
atom_expr [67691,67747]
===
match
---
trailer [61984,61994]
trailer [61984,61994]
===
match
---
simple_stmt [63762,63823]
simple_stmt [63762,63823]
===
match
---
atom_expr [45210,45486]
atom_expr [45210,45486]
===
match
---
name: error [63816,63821]
name: error [63816,63821]
===
match
---
name: str [60997,61000]
name: str [60997,61000]
===
match
---
name: item [70047,70051]
name: item [70154,70158]
===
match
---
name: Optional [14185,14193]
name: Optional [14185,14193]
===
match
---
name: duration [85065,85073]
name: duration [85172,85180]
===
match
---
name: job_ids [6275,6282]
name: job_ids [6275,6282]
===
match
---
name: attr [47167,47171]
name: attr [47167,47171]
===
match
---
name: int [93318,93321]
name: int [93425,93428]
===
match
---
operator: = [23821,23822]
operator: = [23821,23822]
===
match
---
atom_expr [30669,30686]
atom_expr [30669,30686]
===
match
---
atom_expr [46497,46510]
atom_expr [46497,46510]
===
match
---
atom_expr [26901,26917]
atom_expr [26901,26917]
===
match
---
operator: = [38206,38207]
operator: = [38206,38207]
===
match
---
simple_stmt [55806,55843]
simple_stmt [55806,55843]
===
match
---
decorated [24894,27084]
decorated [24894,27084]
===
match
---
suite [93555,93593]
suite [93662,93700]
===
match
---
name: Column [11735,11741]
name: Column [11735,11741]
===
match
---
atom_expr [63187,63206]
atom_expr [63187,63206]
===
match
---
name: dag [73738,73741]
name: dag [73845,73848]
===
match
---
name: bool [41206,41210]
name: bool [41206,41210]
===
match
---
simple_stmt [79183,79228]
simple_stmt [79290,79335]
===
match
---
name: self [56583,56587]
name: self [56583,56587]
===
match
---
atom_expr [86550,86585]
atom_expr [86657,86692]
===
match
---
atom_expr [93023,93036]
atom_expr [93130,93143]
===
match
---
name: globals [93846,93853]
name: globals [93953,93960]
===
match
---
operator: = [31030,31031]
operator: = [31030,31031]
===
match
---
operator: , [51632,51633]
operator: , [51632,51633]
===
match
---
name: airflow [2893,2900]
name: airflow [2893,2900]
===
match
---
name: hr_line_break [45662,45675]
name: hr_line_break [45662,45675]
===
match
---
trailer [39914,39918]
trailer [39914,39918]
===
match
---
name: ti_deps [2824,2831]
name: ti_deps [2824,2831]
===
match
---
suite [58267,58337]
suite [58267,58337]
===
match
---
name: conditions [8231,8241]
name: conditions [8231,8241]
===
match
---
name: session [67130,67137]
name: session [67237,67244]
===
match
---
trailer [53459,53461]
trailer [53459,53461]
===
match
---
operator: , [7683,7684]
operator: , [7683,7684]
===
match
---
trailer [74874,74883]
trailer [74981,74990]
===
match
---
name: State [60237,60242]
name: State [60237,60242]
===
match
---
trailer [69977,69981]
trailer [70084,70088]
===
match
---
expr_stmt [54532,54579]
expr_stmt [54532,54579]
===
match
---
name: set [86255,86258]
name: set [86362,86365]
===
match
---
trailer [67525,67532]
trailer [67632,67639]
===
match
---
trailer [40859,40919]
trailer [40859,40919]
===
match
---
expr_stmt [26362,26385]
expr_stmt [26362,26385]
===
match
---
name: run_id [19279,19285]
name: run_id [19279,19285]
===
match
---
parameters [33499,33505]
parameters [33499,33505]
===
match
---
simple_stmt [46663,46680]
simple_stmt [46663,46680]
===
match
---
simple_stmt [83927,83957]
simple_stmt [84034,84064]
===
match
---
trailer [38567,38621]
trailer [38567,38621]
===
match
---
arglist [83943,83955]
arglist [84050,84062]
===
match
---
atom_expr [24823,24835]
atom_expr [24823,24835]
===
match
---
simple_stmt [11656,11684]
simple_stmt [11656,11684]
===
match
---
name: Optional [85192,85200]
name: Optional [85299,85307]
===
match
---
operator: } [78057,78058]
operator: } [78164,78165]
===
match
---
name: self [93453,93457]
name: self [93560,93564]
===
match
---
if_stmt [90461,90497]
if_stmt [90568,90604]
===
match
---
name: dag_id [52852,52858]
name: dag_id [52852,52858]
===
match
---
simple_stmt [89949,89977]
simple_stmt [90056,90084]
===
match
---
name: dag_id [15864,15870]
name: dag_id [15864,15870]
===
match
---
atom_expr [27539,27554]
atom_expr [27539,27554]
===
match
---
name: state [3462,3467]
name: state [3462,3467]
===
match
---
simple_stmt [871,885]
simple_stmt [871,885]
===
match
---
param [78124,78136]
param [78231,78243]
===
match
---
trailer [23180,23184]
trailer [23180,23184]
===
match
---
suite [32152,32229]
suite [32152,32229]
===
match
---
name: self [47507,47511]
name: self [47507,47511]
===
match
---
operator: , [84394,84395]
operator: , [84501,84502]
===
match
---
trailer [56050,56062]
trailer [56050,56062]
===
match
---
name: non_requeueable_dep_context [44224,44251]
name: non_requeueable_dep_context [44224,44251]
===
match
---
name: log [45698,45701]
name: log [45698,45701]
===
match
---
import_from [2728,2759]
import_from [2728,2759]
===
match
---
trailer [65725,65738]
trailer [65832,65845]
===
match
---
fstring_expr [23611,23624]
fstring_expr [23611,23624]
===
match
---
name: ignore_depends_on_past [60750,60772]
name: ignore_depends_on_past [60750,60772]
===
match
---
trailer [38603,38614]
trailer [38603,38614]
===
match
---
name: str [73958,73961]
name: str [74065,74068]
===
match
---
name: warn [8525,8529]
name: warn [8525,8529]
===
match
---
name: error [65962,65967]
name: error [66069,66074]
===
match
---
atom_expr [92445,92453]
atom_expr [92552,92560]
===
match
---
name: timezone [9452,9460]
name: timezone [9452,9460]
===
match
---
operator: = [34506,34507]
operator: = [34506,34507]
===
match
---
name: dag_id [40867,40873]
name: dag_id [40867,40873]
===
match
---
argument [49496,49516]
argument [49496,49516]
===
match
---
trailer [60414,60427]
trailer [60414,60427]
===
match
---
trailer [47909,47914]
trailer [47909,47914]
===
match
---
expr_stmt [30479,30495]
expr_stmt [30479,30495]
===
match
---
name: commit [46137,46143]
name: commit [46137,46143]
===
match
---
exprlist [8129,8144]
exprlist [8129,8144]
===
match
---
trailer [17811,17823]
trailer [17811,17823]
===
match
---
trailer [86182,86189]
trailer [86289,86296]
===
match
---
name: args [80805,80809]
name: args [80912,80916]
===
match
---
argument [13408,13441]
argument [13408,13441]
===
match
---
argument [80585,80605]
argument [80692,80712]
===
match
---
name: self [53736,53740]
name: self [53736,53740]
===
match
---
name: self [52087,52091]
name: self [52087,52091]
===
match
---
atom_expr [16121,16140]
atom_expr [16121,16140]
===
match
---
trailer [26968,26980]
trailer [26968,26980]
===
match
---
expr_stmt [68965,69025]
expr_stmt [69072,69132]
===
match
---
name: get_prev_start_date_success [69142,69169]
name: get_prev_start_date_success [69249,69276]
===
match
---
name: self [40123,40127]
name: self [40123,40127]
===
match
---
trailer [7666,7673]
trailer [7666,7673]
===
match
---
number: 256 [11810,11813]
number: 256 [11810,11813]
===
match
---
simple_stmt [67277,67304]
simple_stmt [67384,67411]
===
match
---
name: Optional [4606,4614]
name: Optional [4606,4614]
===
match
---
trailer [52870,52878]
trailer [52870,52878]
===
match
---
trailer [11952,11961]
trailer [11952,11961]
===
match
---
simple_stmt [69725,69741]
simple_stmt [69832,69848]
===
match
---
not_test [49207,49223]
not_test [49207,49223]
===
match
---
param [40170,40174]
param [40170,40174]
===
match
---
funcdef [73928,74141]
funcdef [74035,74248]
===
match
---
import_as_names [1576,1603]
import_as_names [1576,1603]
===
match
---
return_stmt [10337,10411]
return_stmt [10337,10411]
===
match
---
simple_stmt [54767,54794]
simple_stmt [54767,54794]
===
match
---
trailer [88503,88518]
trailer [88610,88625]
===
match
---
simple_stmt [17243,17268]
simple_stmt [17243,17268]
===
match
---
suite [14459,15944]
suite [14459,15944]
===
match
---
simple_stmt [24844,24864]
simple_stmt [24844,24864]
===
match
---
not_test [32071,32096]
not_test [32071,32096]
===
match
---
atom_expr [74934,74947]
atom_expr [75041,75054]
===
match
---
atom_expr [12184,12224]
atom_expr [12184,12224]
===
match
---
name: Iterable [1097,1105]
name: Iterable [1097,1105]
===
match
---
sync_comp_for [91658,91671]
sync_comp_for [91765,91778]
===
match
---
trailer [27439,27444]
trailer [27439,27444]
===
match
---
operator: = [62434,62435]
operator: = [62434,62435]
===
match
---
argument [76643,76663]
argument [76750,76770]
===
match
---
expr_stmt [9532,9566]
expr_stmt [9532,9566]
===
match
---
name: Any [85163,85166]
name: Any [85270,85273]
===
match
---
operator: -> [72867,72869]
operator: -> [72974,72976]
===
match
---
trailer [46902,46907]
trailer [46902,46907]
===
match
---
trailer [37929,37937]
trailer [37929,37937]
===
match
---
name: property [93431,93439]
name: property [93538,93546]
===
match
---
operator: , [1133,1134]
operator: , [1133,1134]
===
match
---
name: self [65798,65802]
name: self [65905,65909]
===
match
---
trailer [52681,52713]
trailer [52681,52713]
===
match
---
operator: -> [10445,10447]
operator: -> [10445,10447]
===
match
---
trailer [67658,67693]
trailer [67765,67800]
===
match
---
name: task [52577,52581]
name: task [52577,52581]
===
match
---
import_as_names [1334,1484]
import_as_names [1334,1484]
===
match
---
trailer [35059,35075]
trailer [35059,35075]
===
match
---
param [69809,69819]
param [69916,69926]
===
match
---
name: execution_date [15476,15490]
name: execution_date [15476,15490]
===
match
---
simple_stmt [26282,26310]
simple_stmt [26282,26310]
===
match
---
name: or_ [7801,7804]
name: or_ [7801,7804]
===
match
---
trailer [26679,26696]
trailer [26679,26696]
===
match
---
name: prev_ti [35189,35196]
name: prev_ti [35189,35196]
===
match
---
argument [51804,51825]
argument [51804,51825]
===
match
---
trailer [27011,27017]
trailer [27011,27017]
===
match
---
string: "Recording the task instance as FAILED" [24761,24800]
string: "Recording the task instance as FAILED" [24761,24800]
===
match
---
name: get_prev_execution_date [76718,76741]
name: get_prev_execution_date [76825,76848]
===
match
---
name: TR [8203,8205]
name: TR [8203,8205]
===
match
---
operator: = [90567,90568]
operator: = [90674,90675]
===
match
---
operator: , [47165,47166]
operator: , [47165,47166]
===
match
---
simple_stmt [53673,53720]
simple_stmt [53673,53720]
===
match
---
atom_expr [56892,56912]
atom_expr [56892,56912]
===
match
---
name: dict [82754,82758]
name: dict [82861,82865]
===
match
---
lambdef [75487,75540]
lambdef [75594,75647]
===
match
---
comp_op [8495,8501]
comp_op [8495,8501]
===
match
---
atom_expr [10136,10148]
atom_expr [10136,10148]
===
match
---
atom_expr [50135,50156]
atom_expr [50135,50156]
===
match
---
param [93532,93536]
param [93639,93643]
===
match
---
name: dr [9583,9585]
name: dr [9583,9585]
===
match
---
name: ti [6455,6457]
name: ti [6455,6457]
===
match
---
trailer [89841,89849]
trailer [89948,89956]
===
match
---
dotted_name [2482,2511]
dotted_name [2482,2511]
===
match
---
fstring_expr [52841,52859]
fstring_expr [52841,52859]
===
match
---
name: self [36981,36985]
name: self [36981,36985]
===
match
---
expr_stmt [26430,26466]
expr_stmt [26430,26466]
===
match
---
string: 'start_date' [47661,47673]
string: 'start_date' [47661,47673]
===
match
---
parameters [17968,18276]
parameters [17968,18276]
===
match
---
parameters [37998,38004]
parameters [37998,38004]
===
match
---
name: property [93599,93607]
name: property [93706,93714]
===
match
---
name: dep_context [37265,37276]
name: dep_context [37265,37276]
===
match
---
trailer [9024,9041]
trailer [9024,9041]
===
match
---
name: context [80266,80273]
name: context [80373,80380]
===
match
---
operator: } [23262,23263]
operator: } [23262,23263]
===
match
---
suite [71738,71972]
suite [71845,72079]
===
match
---
name: self [59097,59101]
name: self [59097,59101]
===
match
---
atom_expr [43352,43366]
atom_expr [43352,43366]
===
match
---
name: self [62993,62997]
name: self [62993,62997]
===
match
---
name: get_tomorrow_ds [72849,72864]
name: get_tomorrow_ds [72956,72971]
===
match
---
atom_expr [92741,92771]
atom_expr [92848,92878]
===
match
---
atom_expr [64287,64342]
atom_expr [64287,64342]
===
match
---
trailer [57322,57335]
trailer [57322,57335]
===
match
---
name: conf [83876,83880]
name: conf [83983,83987]
===
match
---
operator: , [8135,8136]
operator: , [8135,8136]
===
match
---
tfpdef [80051,80077]
tfpdef [80158,80184]
===
match
---
atom_expr [79965,79977]
atom_expr [80072,80084]
===
match
---
operator: , [6943,6944]
operator: , [6943,6944]
===
match
---
name: should_pass_filepath [18842,18862]
name: should_pass_filepath [18842,18862]
===
match
---
name: error [61920,61925]
name: error [61920,61925]
===
match
---
trailer [40866,40873]
trailer [40866,40873]
===
match
---
name: self [92462,92466]
name: self [92569,92573]
===
match
---
operator: , [5400,5401]
operator: , [5400,5401]
===
match
---
name: mark_success [49211,49223]
name: mark_success [49211,49223]
===
match
---
atom_expr [40729,40741]
atom_expr [40729,40741]
===
match
---
trailer [66848,66856]
trailer [66955,66963]
===
match
---
trailer [60481,60499]
trailer [60481,60499]
===
match
---
name: task_id [7145,7152]
name: task_id [7145,7152]
===
match
---
operator: { [23258,23259]
operator: { [23258,23259]
===
match
---
atom_expr [91169,91354]
atom_expr [91276,91461]
===
match
---
name: schedule [31462,31470]
name: schedule [31462,31470]
===
match
---
name: get_failed_dep_statuses [37235,37258]
name: get_failed_dep_statuses [37235,37258]
===
match
---
operator: , [47287,47288]
operator: , [47287,47288]
===
match
---
and_test [34546,34599]
and_test [34546,34599]
===
match
---
name: key [77923,77926]
name: key [78030,78033]
===
match
---
argument [13991,14005]
argument [13991,14005]
===
match
---
name: Proxy [76464,76469]
name: Proxy [76571,76576]
===
match
---
trailer [15634,15644]
trailer [15634,15644]
===
match
---
fstring [72276,72315]
fstring [72383,72422]
===
match
---
name: TaskInstanceKey [10107,10122]
name: TaskInstanceKey [10107,10122]
===
match
---
name: self [66130,66134]
name: self [66237,66241]
===
match
---
operator: == [7766,7768]
operator: == [7766,7768]
===
match
---
name: str [69815,69818]
name: str [69922,69925]
===
match
---
param [55227,55232]
param [55227,55232]
===
match
---
trailer [9187,9194]
trailer [9187,9194]
===
match
---
expr_stmt [26709,26726]
expr_stmt [26709,26726]
===
match
---
name: trigger_timeout [58285,58300]
name: trigger_timeout [58285,58300]
===
match
---
simple_stmt [64217,64251]
simple_stmt [64217,64251]
===
match
---
suite [83428,84357]
suite [83535,84464]
===
match
---
name: html_content [84199,84211]
name: html_content [84306,84318]
===
match
---
name: configuration [1902,1915]
name: configuration [1902,1915]
===
match
---
trailer [54505,54514]
trailer [54505,54514]
===
match
---
parameters [70568,70574]
parameters [70675,70681]
===
match
---
fstring_expr [51962,51981]
fstring_expr [51962,51981]
===
match
---
string: '%Y-%m-%d' [72940,72950]
string: '%Y-%m-%d' [73047,73057]
===
match
---
name: XCom [89139,89143]
name: XCom [89246,89250]
===
match
---
name: models [57664,57670]
name: models [57664,57670]
===
match
---
atom_expr [89657,89669]
atom_expr [89764,89776]
===
match
---
simple_stmt [32255,32322]
simple_stmt [32255,32322]
===
match
---
fstring_string: . [37923,37924]
fstring_string: . [37923,37924]
===
match
---
simple_stmt [86766,88393]
simple_stmt [86873,88500]
===
match
---
atom_expr [74178,74191]
atom_expr [74285,74298]
===
match
---
name: macros [75703,75709]
name: macros [75810,75816]
===
match
---
comparison [59439,59465]
comparison [59439,59465]
===
match
---
name: Proxy [72108,72113]
name: Proxy [72215,72220]
===
match
---
name: log [59782,59785]
name: log [59782,59785]
===
match
---
name: self [93023,93027]
name: self [93130,93134]
===
match
---
name: interval_start [67806,67820]
name: interval_start [67913,67927]
===
match
---
trailer [17247,17259]
trailer [17247,17259]
===
match
---
trailer [15222,15224]
trailer [15222,15224]
===
match
---
name: utils [2992,2997]
name: utils [2992,2997]
===
match
---
name: replace [81590,81597]
name: replace [81697,81704]
===
match
---
trailer [40083,40099]
trailer [40083,40099]
===
match
---
simple_stmt [70592,70608]
simple_stmt [70699,70715]
===
match
---
arglist [64431,64449]
arglist [64431,64449]
===
match
---
name: job_ids [5877,5884]
name: job_ids [5877,5884]
===
match
---
arglist [54560,54578]
arglist [54560,54578]
===
match
---
trailer [15723,15725]
trailer [15723,15725]
===
match
---
name: session [32300,32307]
name: session [32300,32307]
===
match
---
atom_expr [51490,51503]
atom_expr [51490,51503]
===
match
---
arglist [4737,4751]
arglist [4737,4751]
===
match
---
operator: -> [80310,80312]
operator: -> [80417,80419]
===
match
---
operator: = [26296,26297]
operator: = [26296,26297]
===
match
---
trailer [69253,69255]
trailer [69360,69362]
===
match
---
import_name [1231,1246]
import_name [1231,1246]
===
match
---
name: _executor_config [93807,93823]
name: _executor_config [93914,93930]
===
match
---
trailer [25401,25405]
trailer [25401,25405]
===
match
---
name: jinja_context [83498,83511]
name: jinja_context [83605,83618]
===
match
---
operator: { [77286,77287]
operator: { [77393,77394]
===
match
---
string: 'next_execution_date' [76028,76049]
string: 'next_execution_date' [76135,76156]
===
match
---
name: AirflowSensorTimeout [50951,50971]
name: AirflowSensorTimeout [50951,50971]
===
match
---
comparison [25567,25603]
comparison [25567,25603]
===
match
---
operator: , [63394,63395]
operator: , [63394,63395]
===
match
---
arglist [55899,55917]
arglist [55899,55917]
===
match
---
trailer [52049,52058]
trailer [52049,52058]
===
match
---
operator: = [83455,83456]
operator: = [83562,83563]
===
match
---
name: flush [66156,66161]
name: flush [66263,66268]
===
match
---
trailer [69972,69982]
trailer [70079,70089]
===
match
---
if_stmt [5997,7077]
if_stmt [5997,7077]
===
match
---
string: 'Host: {{ti.hostname}}<br>' [82035,82062]
string: 'Host: {{ti.hostname}}<br>' [82142,82169]
===
match
---
trailer [7704,8097]
trailer [7704,8097]
===
match
---
fstring_expr [77286,77299]
fstring_expr [77393,77406]
===
match
---
operator: , [37675,37676]
operator: , [37675,37676]
===
match
---
operator: = [47951,47952]
operator: = [47951,47952]
===
match
---
atom_expr [66116,66135]
atom_expr [66223,66242]
===
match
---
name: on_failure_callback [59694,59713]
name: on_failure_callback [59694,59713]
===
match
---
name: foreign_keys [13613,13625]
name: foreign_keys [13613,13625]
===
match
---
trailer [50598,50614]
trailer [50598,50614]
===
match
---
trailer [70737,70741]
trailer [70844,70848]
===
match
---
name: deprecated_proxy [76530,76546]
name: deprecated_proxy [76637,76653]
===
match
---
operator: = [48016,48017]
operator: = [48016,48017]
===
match
---
operator: = [86398,86399]
operator: = [86505,86506]
===
match
---
trailer [14359,14364]
trailer [14359,14364]
===
match
---
funcdef [73076,73919]
funcdef [73183,74026]
===
match
---
trailer [24879,24886]
trailer [24879,24886]
===
match
---
suite [50294,50343]
suite [50294,50343]
===
match
---
name: task [60301,60305]
name: task [60301,60305]
===
match
---
name: context [53613,53620]
name: context [53613,53620]
===
match
---
string: 'mssql' [91405,91412]
string: 'mssql' [91512,91519]
===
match
---
operator: , [62755,62756]
operator: , [62755,62756]
===
match
---
atom_expr [61950,61963]
atom_expr [61950,61963]
===
match
---
comparison [74789,74811]
comparison [74896,74918]
===
match
---
name: Optional [68256,68264]
name: Optional [68363,68371]
===
match
---
string: 'ti_trigger_id' [13079,13094]
string: 'ti_trigger_id' [13079,13094]
===
match
---
trailer [89661,89667]
trailer [89768,89774]
===
match
---
annassign [9715,9720]
annassign [9715,9720]
===
match
---
number: 2 [38617,38618]
number: 2 [38617,38618]
===
match
---
simple_stmt [46894,46972]
simple_stmt [46894,46972]
===
match
---
suite [49224,49429]
suite [49224,49429]
===
match
---
atom_expr [70718,70726]
atom_expr [70825,70833]
===
match
---
tfpdef [71513,71522]
tfpdef [71620,71629]
===
match
---
name: trigger_id [26862,26872]
name: trigger_id [26862,26872]
===
match
---
name: bool [47871,47875]
name: bool [47871,47875]
===
match
---
name: FileSystemLoader [83056,83072]
name: FileSystemLoader [83163,83179]
===
match
---
trailer [6930,6969]
trailer [6930,6969]
===
match
---
name: str [5308,5311]
name: str [5308,5311]
===
match
---
argument [78366,78381]
argument [78473,78488]
===
match
---
if_stmt [43670,46175]
if_stmt [43670,46175]
===
match
---
expr_stmt [57743,57791]
expr_stmt [57743,57791]
===
match
---
trailer [36724,36730]
trailer [36724,36730]
===
match
---
name: airflow [67246,67253]
name: airflow [67353,67360]
===
match
---
atom_expr [39210,39222]
atom_expr [39210,39222]
===
match
---
name: task_copy [62294,62303]
name: task_copy [62294,62303]
===
match
---
atom_expr [88479,88518]
atom_expr [88586,88625]
===
match
---
name: failed [36640,36646]
name: failed [36640,36646]
===
match
---
name: ts_nodash [68039,68048]
name: ts_nodash [68146,68155]
===
match
---
name: str [71519,71522]
name: str [71626,71629]
===
match
---
atom_expr [26282,26295]
atom_expr [26282,26295]
===
match
---
comparison [40661,40708]
comparison [40661,40708]
===
match
---
expr_stmt [12002,12035]
expr_stmt [12002,12035]
===
match
---
dotted_name [2893,2916]
dotted_name [2893,2916]
===
match
---
trailer [92690,92707]
trailer [92797,92814]
===
match
---
trailer [48842,48858]
trailer [48842,48858]
===
match
---
suite [52485,52659]
suite [52485,52659]
===
match
---
name: fd [4588,4590]
name: fd [4588,4590]
===
match
---
operator: = [70601,70602]
operator: = [70708,70709]
===
match
---
arglist [46908,46970]
arglist [46908,46970]
===
match
---
atom_expr [58003,58019]
atom_expr [58003,58019]
===
match
---
simple_stmt [27435,27452]
simple_stmt [27435,27452]
===
match
---
name: airflow [2942,2949]
name: airflow [2942,2949]
===
match
---
atom [22982,23006]
atom [22982,23006]
===
match
---
trailer [62997,63003]
trailer [62997,63003]
===
match
---
atom_expr [44765,44788]
atom_expr [44765,44788]
===
match
---
atom_expr [56027,56063]
atom_expr [56027,56063]
===
match
---
arglist [53016,53047]
arglist [53016,53047]
===
match
---
name: property [17830,17838]
name: property [17830,17838]
===
match
---
name: xcom_push [85105,85114]
name: xcom_push [85212,85221]
===
match
---
operator: = [12057,12058]
operator: = [12057,12058]
===
match
---
name: state [29011,29016]
name: state [29011,29016]
===
match
---
name: ti [7112,7114]
name: ti [7112,7114]
===
match
---
trailer [92384,92396]
trailer [92491,92503]
===
match
---
trailer [27496,27501]
trailer [27496,27501]
===
match
---
arglist [25519,25652]
arglist [25519,25652]
===
match
---
name: State [64431,64436]
name: State [64431,64436]
===
match
---
name: info [46903,46907]
name: info [46903,46907]
===
match
---
expr_stmt [92785,92827]
expr_stmt [92892,92934]
===
match
---
trailer [79494,79514]
trailer [79601,79621]
===
match
---
arglist [10167,10189]
arglist [10167,10189]
===
match
---
operator: , [13375,13376]
operator: , [13375,13376]
===
match
---
name: data_interval [68965,68978]
name: data_interval [69072,69085]
===
match
---
expr_stmt [9725,9736]
expr_stmt [9725,9736]
===
match
---
string: 'data_interval_end' [75201,75220]
string: 'data_interval_end' [75308,75327]
===
match
---
operator: = [8450,8451]
operator: = [8450,8451]
===
match
---
name: key [83842,83845]
name: key [83949,83952]
===
match
---
trailer [24160,24166]
trailer [24160,24166]
===
match
---
name: html_content_err [84754,84770]
name: html_content_err [84861,84877]
===
match
---
atom_expr [76051,76215]
atom_expr [76158,76322]
===
match
---
atom_expr [89139,89151]
atom_expr [89246,89258]
===
match
---
arglist [54656,54686]
arglist [54656,54686]
===
match
---
operator: } [51980,51981]
operator: } [51980,51981]
===
match
---
name: stacklevel [35747,35757]
name: stacklevel [35747,35757]
===
match
---
atom_expr [83982,83992]
atom_expr [84089,84099]
===
match
---
tfpdef [60711,60732]
tfpdef [60711,60732]
===
match
---
name: task [53741,53745]
name: task [53741,53745]
===
match
---
except_clause [50351,50383]
except_clause [50351,50383]
===
match
---
suite [9822,9940]
suite [9822,9940]
===
match
---
param [29589,29594]
param [29589,29594]
===
match
---
operator: , [20063,20064]
operator: , [20063,20064]
===
match
---
atom_expr [54401,54436]
atom_expr [54401,54436]
===
match
---
operator: , [75644,75645]
operator: , [75751,75752]
===
match
---
expr_stmt [11688,11719]
expr_stmt [11688,11719]
===
match
---
argument [11232,11248]
argument [11232,11248]
===
match
---
atom_expr [53931,53982]
atom_expr [53931,53982]
===
match
---
name: timezone [58303,58311]
name: timezone [58303,58311]
===
match
---
name: task_id_by_key [7086,7100]
name: task_id_by_key [7086,7100]
===
match
---
trailer [43502,43532]
trailer [43502,43532]
===
match
---
funcdef [74340,74659]
funcdef [74447,74766]
===
match
---
trailer [83669,83680]
trailer [83776,83787]
===
match
---
expr_stmt [49547,49573]
expr_stmt [49547,49573]
===
match
---
suite [73496,73558]
suite [73603,73665]
===
match
---
comparison [59511,59547]
comparison [59511,59547]
===
match
---
operator: = [23463,23464]
operator: = [23463,23464]
===
match
---
operator: = [27502,27503]
operator: = [27502,27503]
===
match
---
annassign [92347,92371]
annassign [92454,92478]
===
match
---
funcdef [37231,37853]
funcdef [37231,37853]
===
match
---
atom_expr [28945,28960]
atom_expr [28945,28960]
===
match
---
name: self [35786,35790]
name: self [35786,35790]
===
match
---
argument [49339,49368]
argument [49339,49368]
===
match
---
number: 1000 [11991,11995]
number: 1000 [11991,11995]
===
match
---
trailer [38562,38567]
trailer [38562,38567]
===
match
---
name: self [53673,53677]
name: self [53673,53677]
===
match
---
atom_expr [11769,11784]
atom_expr [11769,11784]
===
match
---
name: log [28274,28277]
name: log [28274,28277]
===
match
---
argument [83706,83730]
argument [83813,83837]
===
match
---
trailer [27464,27470]
trailer [27464,27470]
===
match
---
name: run_id [90560,90566]
name: run_id [90667,90673]
===
match
---
tfpdef [20256,20279]
tfpdef [20256,20279]
===
match
---
name: self [62231,62235]
name: self [62231,62235]
===
match
---
name: deprecated_proxy [77423,77439]
name: deprecated_proxy [77530,77546]
===
match
---
name: Optional [60952,60960]
name: Optional [60952,60960]
===
match
---
operator: , [60901,60902]
operator: , [60901,60902]
===
match
---
trailer [13737,13904]
trailer [13737,13904]
===
match
---
atom_expr [34676,34689]
atom_expr [34676,34689]
===
match
---
atom_expr [79336,79402]
atom_expr [79443,79509]
===
match
---
name: force_fail [65359,65369]
name: force_fail [65466,65476]
===
match
---
trailer [8379,8388]
trailer [8379,8388]
===
match
---
parameters [62362,62440]
parameters [62362,62440]
===
match
---
trailer [74771,74773]
trailer [74878,74880]
===
match
---
name: log [49787,49790]
name: log [49787,49790]
===
match
---
trailer [90574,90581]
trailer [90681,90688]
===
match
---
decorator [37210,37227]
decorator [37210,37227]
===
match
---
simple_stmt [18286,18477]
simple_stmt [18286,18477]
===
match
---
if_stmt [22650,22706]
if_stmt [22650,22706]
===
match
---
name: dag_id [89736,89742]
name: dag_id [89843,89849]
===
match
---
atom_expr [14262,14273]
atom_expr [14262,14273]
===
match
---
atom_expr [90569,90581]
atom_expr [90676,90688]
===
match
---
name: _schedule [31487,31496]
name: _schedule [31487,31496]
===
match
---
atom_expr [12302,12320]
atom_expr [12302,12320]
===
match
---
atom_expr [33171,33418]
atom_expr [33171,33418]
===
match
---
simple_stmt [3494,3536]
simple_stmt [3494,3536]
===
match
---
name: verbose [35925,35932]
name: verbose [35925,35932]
===
match
---
name: coerce_datetime [69343,69358]
name: coerce_datetime [69450,69465]
===
match
---
name: warnings [892,900]
name: warnings [892,900]
===
match
---
atom_expr [43858,44149]
atom_expr [43858,44149]
===
match
---
name: session [44314,44321]
name: session [44314,44321]
===
match
---
atom_expr [83342,83413]
atom_expr [83449,83520]
===
match
---
simple_stmt [57833,57849]
simple_stmt [57833,57849]
===
match
---
funcdef [85101,86477]
funcdef [85208,86584]
===
match
---
import_from [1604,1671]
import_from [1604,1671]
===
match
---
name: dagrun [69359,69365]
name: dagrun [69466,69472]
===
match
---
trailer [84305,84356]
trailer [84412,84463]
===
match
---
name: pickle [4835,4841]
name: pickle [4835,4841]
===
match
---
name: path [19119,19123]
name: path [19119,19123]
===
match
---
atom_expr [62601,62618]
atom_expr [62601,62618]
===
match
---
name: catch_warnings [73606,73620]
name: catch_warnings [73713,73727]
===
match
---
name: self [55038,55042]
name: self [55038,55042]
===
match
---
simple_stmt [43307,43328]
simple_stmt [43307,43328]
===
match
---
operator: == [40330,40332]
operator: == [40330,40332]
===
match
---
operator: = [26408,26409]
operator: = [26408,26409]
===
match
---
operator: = [76129,76130]
operator: = [76236,76237]
===
match
---
operator: = [15380,15381]
operator: = [15380,15381]
===
match
---
name: cmd [22218,22221]
name: cmd [22218,22221]
===
match
---
operator: , [77041,77042]
operator: , [77148,77149]
===
match
---
operator: == [59450,59452]
operator: == [59450,59452]
===
match
---
atom_expr [28269,28304]
atom_expr [28269,28304]
===
match
---
suite [30138,30163]
suite [30138,30163]
===
match
---
name: dag_id [9692,9698]
name: dag_id [9692,9698]
===
match
---
dotted_name [2638,2661]
dotted_name [2638,2661]
===
match
---
operator: = [77006,77007]
operator: = [77113,77114]
===
match
---
atom_expr [54541,54579]
atom_expr [54541,54579]
===
match
---
operator: , [13655,13656]
operator: , [13655,13656]
===
match
---
argument [80680,80706]
argument [80787,80813]
===
match
---
name: _key [92877,92881]
name: _key [92984,92988]
===
match
---
name: airflow [3448,3455]
name: airflow [3448,3455]
===
match
---
return_stmt [93089,93108]
return_stmt [93196,93215]
===
match
---
string: """Sets the log context.""" [89949,89976]
string: """Sets the log context.""" [90056,90083]
===
match
---
trailer [45510,45531]
trailer [45510,45531]
===
match
---
name: on_kill [57134,57141]
name: on_kill [57134,57141]
===
match
---
simple_stmt [80103,80150]
simple_stmt [80210,80257]
===
match
---
suite [84615,84679]
suite [84722,84786]
===
match
---
name: task [62751,62755]
name: task [62751,62755]
===
match
---
operator: , [55231,55232]
operator: , [55231,55232]
===
match
---
operator: , [12963,12964]
operator: , [12963,12964]
===
match
---
name: task [27789,27793]
name: task [27789,27793]
===
match
---
dotted_name [3319,3340]
dotted_name [3319,3340]
===
match
---
name: DagRun [9181,9187]
name: DagRun [9181,9187]
===
match
---
name: Index [12839,12844]
name: Index [12839,12844]
===
match
---
operator: , [43275,43276]
operator: , [43275,43276]
===
match
---
trailer [54777,54793]
trailer [54777,54793]
===
match
---
simple_stmt [84817,84839]
simple_stmt [84924,84946]
===
match
---
name: execute [55566,55573]
name: execute [55566,55573]
===
match
---
operator: , [52310,52311]
operator: , [52310,52311]
===
match
---
trailer [48798,48829]
trailer [48798,48829]
===
match
---
operator: { [72411,72412]
operator: { [72518,72519]
===
match
---
atom_expr [76446,76505]
atom_expr [76553,76612]
===
match
---
name: bool [60814,60818]
name: bool [60814,60818]
===
match
---
simple_stmt [4030,4204]
simple_stmt [4030,4204]
===
match
---
trailer [80525,80539]
trailer [80632,80646]
===
match
---
name: task_id [23579,23586]
name: task_id [23579,23586]
===
match
---
decorated [41109,47094]
decorated [41109,47094]
===
match
---
trailer [91458,91641]
trailer [91565,91748]
===
match
---
if_stmt [37790,37853]
if_stmt [37790,37853]
===
match
---
atom_expr [12416,12435]
atom_expr [12416,12435]
===
match
---
operator: = [63442,63443]
operator: = [63442,63443]
===
match
---
tfpdef [71671,71680]
tfpdef [71778,71787]
===
match
---
dictorsetmaker [89042,89164]
dictorsetmaker [89149,89271]
===
match
---
suite [78709,79102]
suite [78816,79209]
===
match
---
param [62363,62368]
param [62363,62368]
===
match
---
simple_stmt [63187,63207]
simple_stmt [63187,63207]
===
match
---
not_test [90464,90471]
not_test [90571,90578]
===
match
---
trailer [27687,27697]
trailer [27687,27697]
===
match
---
simple_stmt [19140,19157]
simple_stmt [19140,19157]
===
match
---
trailer [47160,47178]
trailer [47160,47178]
===
match
---
atom_expr [27604,27630]
atom_expr [27604,27630]
===
match
---
trailer [84993,85002]
trailer [85100,85109]
===
match
---
name: XCom [86250,86254]
name: XCom [86357,86361]
===
match
---
string: """         Pull XComs that optionally meet certain criteria.          The default value for `key` limits the search to XComs         that were returned by other tasks (as opposed to those that were pushed         manually). To remove this filter, pass key=None (or any desired value).          If a single task_id string is provided, the result is the value of the         most recent matching XCom from that task_id. If multiple task_ids are         provided, a tuple of matching values is returned. None is returned         whenever no matches are found.          :param key: A key for the XCom. If provided, only XComs with matching             keys will be returned. The default key is 'return_value', also             available as a constant XCOM_RETURN_KEY. This key is automatically             given to XComs returned by tasks (as opposed to being pushed             manually). To remove the filter, pass key=None.         :type key: str         :param task_ids: Only XComs from tasks with matching ids will be             pulled. Can pass None to remove the filter.         :type task_ids: str or iterable of strings (representing task_ids)         :param dag_id: If provided, only pulls XComs from this DAG.             If None (default), the DAG of the calling task is used.         :type dag_id: str         :param include_prior_dates: If False, only XComs from the current             execution_date are returned. If True, XComs from previous dates             are returned as well.         :type include_prior_dates: bool         :param session: Sqlalchemy ORM Session         :type session: Session         """ [86766,88392]
string: """         Pull XComs that optionally meet certain criteria.          The default value for `key` limits the search to XComs         that were returned by other tasks (as opposed to those that were pushed         manually). To remove this filter, pass key=None (or any desired value).          If a single task_id string is provided, the result is the value of the         most recent matching XCom from that task_id. If multiple task_ids are         provided, a tuple of matching values is returned. None is returned         whenever no matches are found.          :param key: A key for the XCom. If provided, only XComs with matching             keys will be returned. The default key is 'return_value', also             available as a constant XCOM_RETURN_KEY. This key is automatically             given to XComs returned by tasks (as opposed to being pushed             manually). To remove the filter, pass key=None.         :type key: str         :param task_ids: Only XComs from tasks with matching ids will be             pulled. Can pass None to remove the filter.         :type task_ids: str or iterable of strings (representing task_ids)         :param dag_id: If provided, only pulls XComs from this DAG.             If None (default), the DAG of the calling task is used.         :type dag_id: str         :param include_prior_dates: If False, only XComs from the current             execution_date are returned. If True, XComs from previous dates             are returned as well.         :type include_prior_dates: bool         :param session: Sqlalchemy ORM Session         :type session: Session         """ [86873,88499]
===
match
---
atom_expr [25708,25730]
atom_expr [25708,25730]
===
match
---
operator: , [10371,10372]
operator: , [10371,10372]
===
match
---
name: or_ [9151,9154]
name: or_ [9151,9154]
===
match
---
except_clause [4858,4874]
except_clause [4858,4874]
===
match
---
number: 1 [11873,11874]
number: 1 [11873,11874]
===
match
---
expr_stmt [61920,61994]
expr_stmt [61920,61994]
===
match
---
atom [43636,43646]
atom [43636,43646]
===
match
---
name: State [6242,6247]
name: State [6242,6247]
===
match
---
name: TaskInstance [91769,91781]
name: TaskInstance [91876,91888]
===
match
---
name: self_execution_date [86013,86032]
name: self_execution_date [86120,86139]
===
match
---
operator: = [28159,28160]
operator: = [28159,28160]
===
match
---
trailer [32078,32088]
trailer [32078,32088]
===
match
---
tfpdef [85138,85146]
tfpdef [85245,85253]
===
match
---
name: str [74187,74190]
name: str [74294,74297]
===
match
---
string: '-' [67982,67985]
string: '-' [68089,68092]
===
match
---
name: mark_success [61693,61705]
name: mark_success [61693,61705]
===
match
---
name: provide_session [37211,37226]
name: provide_session [37211,37226]
===
match
---
operator: -> [24978,24980]
operator: -> [24978,24980]
===
match
---
argument [86318,86338]
argument [86425,86445]
===
match
---
trailer [75342,75362]
trailer [75449,75469]
===
match
---
trailer [62777,62784]
trailer [62777,62784]
===
match
---
name: signal [52682,52688]
name: signal [52682,52688]
===
match
---
expr_stmt [31462,31496]
expr_stmt [31462,31496]
===
match
---
trailer [52502,52506]
trailer [52502,52506]
===
match
---
atom_expr [17923,17939]
atom_expr [17923,17939]
===
match
---
suite [79436,79688]
suite [79543,79795]
===
match
---
name: TaskInstance [91006,91018]
name: TaskInstance [91113,91125]
===
match
---
suite [67471,67510]
suite [67578,67617]
===
match
---
name: PickleType [1407,1417]
name: PickleType [1407,1417]
===
match
---
operator: = [92807,92808]
operator: = [92914,92915]
===
match
---
name: render_k8s_pod_yaml [79495,79514]
name: render_k8s_pod_yaml [79602,79621]
===
match
---
atom_expr [23295,23306]
atom_expr [23295,23306]
===
match
---
simple_stmt [72887,72952]
simple_stmt [72994,73059]
===
match
---
trailer [15312,15321]
trailer [15312,15321]
===
match
---
name: task [27744,27748]
name: task [27744,27748]
===
match
---
name: task_id [6430,6437]
name: task_id [6430,6437]
===
match
---
trailer [58542,58560]
trailer [58542,58560]
===
match
---
operator: = [59899,59900]
operator: = [59899,59900]
===
match
---
tfpdef [40450,40466]
tfpdef [40450,40466]
===
match
---
name: self [93413,93417]
name: self [93520,93524]
===
match
---
name: append [4225,4231]
name: append [4225,4231]
===
match
---
name: self [26709,26713]
name: self [26709,26713]
===
match
---
name: timetable [31477,31486]
name: timetable [31477,31486]
===
match
---
atom_expr [84989,85002]
atom_expr [85096,85109]
===
match
---
trailer [37147,37184]
trailer [37147,37184]
===
match
---
name: executor_config [26744,26759]
name: executor_config [26744,26759]
===
match
---
suite [73825,73854]
suite [73932,73961]
===
match
---
name: int [92718,92721]
name: int [92825,92828]
===
match
---
atom_expr [62294,62313]
atom_expr [62294,62313]
===
match
---
if_stmt [22483,22554]
if_stmt [22483,22554]
===
match
---
atom_expr [60147,60209]
atom_expr [60147,60209]
===
match
---
operator: , [17225,17226]
operator: , [17225,17226]
===
match
---
name: path [19096,19100]
name: path [19096,19100]
===
match
---
suite [67533,67573]
suite [67640,67680]
===
match
---
simple_stmt [64700,64724]
simple_stmt [64807,64831]
===
match
---
name: _state [92431,92437]
name: _state [92538,92544]
===
match
---
arglist [44855,44876]
arglist [44855,44876]
===
match
---
or_test [86399,86436]
or_test [86506,86543]
===
match
---
expr_stmt [92872,92890]
expr_stmt [92979,92997]
===
match
---
trailer [80539,81116]
trailer [80646,81223]
===
match
---
name: str [47988,47991]
name: str [47988,47991]
===
match
---
suite [52321,54794]
suite [52321,54794]
===
match
---
atom_expr [65798,65868]
atom_expr [65905,65975]
===
match
---
argument [83101,83116]
argument [83208,83223]
===
match
---
name: self [60147,60151]
name: self [60147,60151]
===
match
---
string: 'tomorrow_ds_nodash' [77489,77509]
string: 'tomorrow_ds_nodash' [77596,77616]
===
match
---
name: relationship [13920,13932]
name: relationship [13920,13932]
===
match
---
atom_expr [11513,11532]
atom_expr [11513,11532]
===
match
---
name: run_id [90839,90845]
name: run_id [90946,90952]
===
match
---
trailer [43259,43298]
trailer [43259,43298]
===
match
---
trailer [92266,92273]
trailer [92373,92380]
===
match
---
atom_expr [67277,67303]
atom_expr [67384,67410]
===
match
---
operator: , [75709,75710]
operator: , [75816,75817]
===
match
---
name: task [60059,60063]
name: task [60059,60063]
===
match
---
name: next_try_number [17847,17862]
name: next_try_number [17847,17862]
===
match
---
name: self [10387,10391]
name: self [10387,10391]
===
match
---
if_stmt [90807,91070]
if_stmt [90914,91177]
===
match
---
parameters [70029,70147]
parameters [70136,70254]
===
match
---
name: use_default [82510,82521]
name: use_default [82617,82628]
===
match
---
atom_expr [54037,54254]
atom_expr [54037,54254]
===
match
---
simple_stmt [68820,68832]
simple_stmt [68927,68939]
===
match
---
trailer [22519,22526]
trailer [22519,22526]
===
match
---
param [71513,71523]
param [71620,71630]
===
match
---
name: start_date [28968,28978]
name: start_date [28968,28978]
===
match
---
trailer [27477,27483]
trailer [27477,27483]
===
match
---
simple_stmt [81621,81663]
simple_stmt [81728,81770]
===
match
---
suite [57359,57422]
suite [57359,57422]
===
match
---
suite [15778,15944]
suite [15778,15944]
===
match
---
atom_expr [75734,75816]
atom_expr [75841,75923]
===
match
---
operator: , [77921,77922]
operator: , [78028,78029]
===
match
---
simple_stmt [27152,27427]
simple_stmt [27152,27427]
===
match
---
trailer [25931,25940]
trailer [25931,25940]
===
match
---
name: default_html_content_err [83364,83388]
name: default_html_content_err [83471,83495]
===
match
---
name: handle_failure [63340,63354]
name: handle_failure [63340,63354]
===
match
---
name: ds [67971,67973]
name: ds [68078,68080]
===
match
---
fstring [54708,54751]
fstring [54708,54751]
===
match
---
parameters [93779,93785]
parameters [93886,93892]
===
match
---
atom_expr [69184,69201]
atom_expr [69291,69308]
===
match
---
operator: { [79675,79676]
operator: { [79782,79783]
===
match
---
simple_stmt [50906,50913]
simple_stmt [50906,50913]
===
match
---
operator: } [37951,37952]
operator: } [37951,37952]
===
match
---
name: query [88528,88533]
name: query [88635,88640]
===
match
---
param [35893,35910]
param [35893,35910]
===
match
---
atom_expr [76240,76252]
atom_expr [76347,76359]
===
match
---
expr_stmt [58158,58179]
expr_stmt [58158,58179]
===
match
---
atom_expr [62802,62818]
atom_expr [62802,62818]
===
match
---
name: _update_ti_state_for_sensing [54406,54434]
name: _update_ti_state_for_sensing [54406,54434]
===
match
---
trailer [91738,91745]
trailer [91845,91852]
===
match
---
operator: = [45564,45565]
operator: = [45564,45565]
===
match
---
name: drs [9072,9075]
name: drs [9072,9075]
===
match
---
parameters [68658,68660]
parameters [68765,68767]
===
match
---
expr_stmt [46576,46596]
expr_stmt [46576,46596]
===
match
---
name: session [35097,35104]
name: session [35097,35104]
===
match
---
if_stmt [40658,40742]
if_stmt [40658,40742]
===
match
---
if_stmt [63713,63885]
if_stmt [63713,63885]
===
match
---
simple_stmt [53918,53983]
simple_stmt [53918,53983]
===
match
---
argument [11269,11283]
argument [11269,11283]
===
match
---
atom_expr [20266,20279]
atom_expr [20266,20279]
===
match
---
atom_expr [7701,8097]
atom_expr [7701,8097]
===
match
---
param [37283,37295]
param [37283,37295]
===
match
---
number: 1 [43530,43531]
number: 1 [43530,43531]
===
match
---
fstring_expr [51943,51961]
fstring_expr [51943,51961]
===
match
---
name: next_kwargs [26952,26963]
name: next_kwargs [26952,26963]
===
match
---
trailer [86254,86258]
trailer [86361,86365]
===
match
---
argument [80720,80753]
argument [80827,80860]
===
match
---
atom_expr [29159,29172]
atom_expr [29159,29172]
===
match
---
operator: -> [93315,93317]
operator: -> [93422,93424]
===
match
---
expr_stmt [49303,49369]
expr_stmt [49303,49369]
===
match
---
name: datetime [14140,14148]
name: datetime [14140,14148]
===
match
---
name: params [67694,67700]
name: params [67801,67807]
===
match
---
name: get_tomorrow_ds [73017,73032]
name: get_tomorrow_ds [73124,73139]
===
match
---
atom_expr [46635,46654]
atom_expr [46635,46654]
===
match
---
comparison [60301,60335]
comparison [60301,60335]
===
match
---
name: end_date [46581,46589]
name: end_date [46581,46589]
===
match
---
suite [63840,63885]
suite [63840,63885]
===
match
---
name: tempfile [1013,1021]
name: tempfile [1013,1021]
===
match
---
trailer [92857,92863]
trailer [92964,92970]
===
match
---
name: Column [12184,12190]
name: Column [12184,12190]
===
match
---
not_test [61535,61542]
not_test [61535,61542]
===
match
---
operator: @ [16598,16599]
operator: @ [16598,16599]
===
match
---
name: self [89509,89513]
name: self [89616,89620]
===
match
---
param [40450,40473]
param [40450,40473]
===
match
---
trailer [37383,37385]
trailer [37383,37385]
===
match
---
name: default_html_content [84246,84266]
name: default_html_content [84353,84373]
===
match
---
name: timezone [52061,52069]
name: timezone [52061,52069]
===
match
---
atom_expr [50507,50513]
atom_expr [50507,50513]
===
match
---
operator: , [966,967]
operator: , [966,967]
===
match
---
name: result [47144,47150]
name: result [47144,47150]
===
match
---
simple_stmt [52371,52442]
simple_stmt [52371,52442]
===
match
---
name: scheduler_job_id [80923,80939]
name: scheduler_job_id [81030,81046]
===
match
---
atom_expr [55865,55919]
atom_expr [55865,55919]
===
match
---
trailer [59905,59910]
trailer [59905,59910]
===
match
---
if_stmt [18876,19011]
if_stmt [18876,19011]
===
match
---
trailer [9438,9449]
trailer [9438,9449]
===
match
---
argument [44253,44268]
argument [44253,44268]
===
match
---
argument [11357,11371]
argument [11357,11371]
===
match
---
name: get_yesterday_ds [72615,72631]
name: get_yesterday_ds [72722,72738]
===
match
---
string: """         Generates the shell command required to execute this task instance.          :param dag_id: DAG ID         :type dag_id: str         :param task_id: Task ID         :type task_id: str         :param run_id: The run_id of this task's DagRun         :type run_id: datetime         :param mark_success: Whether to mark the task as successful         :type mark_success: bool         :param ignore_all_deps: Ignore all ignorable dependencies.             Overrides the other ignore_* parameters.         :type ignore_all_deps: bool         :param ignore_depends_on_past: Ignore depends_on_past parameter of DAGs             (e.g. for Backfills)         :type ignore_depends_on_past: bool         :param ignore_task_deps: Ignore task-specific dependencies such as depends_on_past             and trigger rule         :type ignore_task_deps: bool         :param ignore_ti_state: Ignore the task instance's previous failure/success         :type ignore_ti_state: bool         :param local: Whether to run the task locally         :type local: bool         :param pickle_id: If the DAG was serialized to the DB, the ID             associated with the pickled DAG         :type pickle_id: Optional[int]         :param file_path: path to the file containing the DAG definition         :type file_path: Optional[str]         :param raw: raw mode (needs more details)         :type raw: Optional[bool]         :param job_id: job ID (needs more details)         :type job_id: Optional[int]         :param pool: the Airflow pool that the task should run in         :type pool: Optional[str]         :param cfg_path: the Path to the configuration file         :type cfg_path: Optional[str]         :return: shell command that can be used to run the task instance         :rtype: list[str]         """ [20316,22113]
string: """         Generates the shell command required to execute this task instance.          :param dag_id: DAG ID         :type dag_id: str         :param task_id: Task ID         :type task_id: str         :param run_id: The run_id of this task's DagRun         :type run_id: datetime         :param mark_success: Whether to mark the task as successful         :type mark_success: bool         :param ignore_all_deps: Ignore all ignorable dependencies.             Overrides the other ignore_* parameters.         :type ignore_all_deps: bool         :param ignore_depends_on_past: Ignore depends_on_past parameter of DAGs             (e.g. for Backfills)         :type ignore_depends_on_past: bool         :param ignore_task_deps: Ignore task-specific dependencies such as depends_on_past             and trigger rule         :type ignore_task_deps: bool         :param ignore_ti_state: Ignore the task instance's previous failure/success         :type ignore_ti_state: bool         :param local: Whether to run the task locally         :type local: bool         :param pickle_id: If the DAG was serialized to the DB, the ID             associated with the pickled DAG         :type pickle_id: Optional[int]         :param file_path: path to the file containing the DAG definition         :type file_path: Optional[str]         :param raw: raw mode (needs more details)         :type raw: Optional[bool]         :param job_id: job ID (needs more details)         :type job_id: Optional[int]         :param pool: the Airflow pool that the task should run in         :type pool: Optional[str]         :param cfg_path: the Path to the configuration file         :type cfg_path: Optional[str]         :return: shell command that can be used to run the task instance         :rtype: list[str]         """ [20316,22113]
===
match
---
strings [54079,54192]
strings [54079,54192]
===
match
---
tfpdef [47967,47992]
tfpdef [47967,47992]
===
match
---
atom_expr [31635,31748]
atom_expr [31635,31748]
===
match
---
name: test_mode [60911,60920]
name: test_mode [60911,60920]
===
match
---
trailer [23123,23156]
trailer [23123,23156]
===
match
---
string: 'value' [77774,77781]
string: 'value' [77881,77888]
===
match
---
operator: { [49157,49158]
operator: { [49157,49158]
===
match
---
trailer [34165,34174]
trailer [34165,34174]
===
match
---
atom_expr [18879,18892]
atom_expr [18879,18892]
===
match
---
trailer [65949,65961]
trailer [66056,66068]
===
match
---
name: debug [34418,34423]
name: debug [34418,34423]
===
match
---
string: '%Y-%m-%d' [72707,72717]
string: '%Y-%m-%d' [72814,72824]
===
match
---
name: innerjoin [13991,14000]
name: innerjoin [13991,14000]
===
match
---
simple_stmt [68457,68497]
simple_stmt [68564,68604]
===
match
---
operator: = [29098,29099]
operator: = [29098,29099]
===
match
---
arglist [84639,84677]
arglist [84746,84784]
===
match
---
name: String [11911,11917]
name: String [11911,11917]
===
match
---
name: session [78366,78373]
name: session [78473,78480]
===
match
---
atom_expr [8366,8426]
atom_expr [8366,8426]
===
match
---
name: self [52306,52310]
name: self [52306,52310]
===
match
---
expr_stmt [58644,58729]
expr_stmt [58644,58729]
===
match
---
trailer [64297,64342]
trailer [64297,64342]
===
match
---
trailer [58284,58300]
trailer [58284,58300]
===
match
---
argument [66417,66428]
argument [66524,66535]
===
match
---
dotted_name [3906,3924]
dotted_name [3906,3924]
===
match
---
parameters [17862,17868]
parameters [17862,17868]
===
match
---
atom_expr [91367,91401]
atom_expr [91474,91508]
===
match
---
operator: , [92751,92752]
operator: , [92858,92859]
===
match
---
name: Index [13037,13042]
name: Index [13037,13042]
===
match
---
atom_expr [26875,26888]
atom_expr [26875,26888]
===
match
---
name: timezone [64233,64241]
name: timezone [64233,64241]
===
match
---
operator: = [5885,5886]
operator: = [5885,5886]
===
match
---
simple_stmt [3546,3597]
simple_stmt [3546,3597]
===
match
---
param [79154,79159]
param [79261,79266]
===
match
---
name: cmd [22355,22358]
name: cmd [22355,22358]
===
match
---
trailer [83174,83191]
trailer [83281,83298]
===
match
---
trailer [39316,39326]
trailer [39316,39326]
===
match
---
trailer [80776,80791]
trailer [80883,80898]
===
match
---
name: models [78213,78219]
name: models [78320,78326]
===
match
---
sync_comp_for [8038,8079]
sync_comp_for [8038,8079]
===
match
---
name: _execute_task [54546,54559]
name: _execute_task [54546,54559]
===
match
---
name: first [90539,90544]
name: first [90646,90651]
===
match
---
simple_stmt [67014,67038]
simple_stmt [67121,67145]
===
match
---
suite [38994,39027]
suite [38994,39027]
===
match
---
atom_expr [22516,22553]
atom_expr [22516,22553]
===
match
---
import_from [2979,3013]
import_from [2979,3013]
===
match
---
simple_stmt [11200,11285]
simple_stmt [11200,11285]
===
match
---
name: self [88441,88445]
name: self [88548,88552]
===
match
---
operator: , [41079,41080]
operator: , [41079,41080]
===
match
---
operator: = [13625,13626]
operator: = [13625,13626]
===
match
---
atom_expr [11742,11754]
atom_expr [11742,11754]
===
match
---
name: airflow [2309,2316]
name: airflow [2309,2316]
===
match
---
suite [8994,9063]
suite [8994,9063]
===
match
---
name: _try_number [17130,17141]
name: _try_number [17130,17141]
===
match
---
operator: , [51503,51504]
operator: , [51503,51504]
===
match
---
trailer [51987,51993]
trailer [51987,51993]
===
match
---
param [89509,89514]
param [89616,89621]
===
match
---
simple_stmt [73010,73052]
simple_stmt [73117,73159]
===
match
---
trailer [34748,34757]
trailer [34748,34757]
===
match
---
name: session [32834,32841]
name: session [32834,32841]
===
match
---
expr_stmt [11566,11592]
expr_stmt [11566,11592]
===
match
---
annassign [9698,9703]
annassign [9698,9703]
===
match
---
simple_stmt [15554,15744]
simple_stmt [15554,15744]
===
match
---
trailer [74942,74947]
trailer [75049,75054]
===
match
---
name: self [37537,37541]
name: self [37537,37541]
===
match
---
string: '' [67987,67989]
string: '' [68094,68096]
===
match
---
simple_stmt [40484,40621]
simple_stmt [40484,40621]
===
match
---
param [41427,41451]
param [41427,41451]
===
match
---
trailer [91173,91354]
trailer [91280,91461]
===
match
---
number: 1 [39025,39026]
number: 1 [39025,39026]
===
match
---
operator: , [66316,66317]
operator: , [66423,66424]
===
match
---
name: defer [58241,58246]
name: defer [58241,58246]
===
match
---
operator: , [75578,75579]
operator: , [75685,75686]
===
match
---
simple_stmt [25704,25763]
simple_stmt [25704,25763]
===
match
---
atom_expr [93731,93740]
atom_expr [93838,93847]
===
match
---
name: dag_id [47544,47550]
name: dag_id [47544,47550]
===
match
---
name: default_subject [81621,81636]
name: default_subject [81728,81743]
===
match
---
atom_expr [38208,38229]
atom_expr [38208,38229]
===
match
---
parameters [80303,80309]
parameters [80410,80416]
===
match
---
atom_expr [66065,66075]
atom_expr [66172,66182]
===
match
---
trailer [92811,92827]
trailer [92918,92934]
===
match
---
atom_expr [13509,13709]
atom_expr [13509,13709]
===
match
---
argument [76995,77041]
argument [77102,77148]
===
match
---
name: STATICA_HACK [93826,93838]
name: STATICA_HACK [93933,93945]
===
match
---
trailer [86578,86583]
trailer [86685,86690]
===
match
---
simple_stmt [90530,90552]
simple_stmt [90637,90659]
===
match
---
name: stacklevel [33915,33925]
name: stacklevel [33915,33925]
===
match
---
atom_expr [67560,67571]
atom_expr [67667,67678]
===
match
---
simple_stmt [30732,30942]
simple_stmt [30732,30942]
===
match
---
operator: , [41381,41382]
operator: , [41381,41382]
===
match
---
name: start_date [56588,56598]
name: start_date [56588,56598]
===
match
---
suite [7177,8279]
suite [7177,8279]
===
match
---
name: DagRun [15599,15605]
name: DagRun [15599,15605]
===
match
---
number: 1 [64340,64341]
number: 1 [64340,64341]
===
match
---
atom_expr [59453,59465]
atom_expr [59453,59465]
===
match
---
arith_expr [23225,23308]
arith_expr [23225,23308]
===
match
---
name: airflow_context_vars [53509,53529]
name: airflow_context_vars [53509,53529]
===
match
---
name: t [90814,90815]
name: t [90921,90922]
===
match
---
name: ti [7101,7103]
name: ti [7101,7103]
===
match
---
name: field_name [78545,78555]
name: field_name [78652,78662]
===
match
---
simple_stmt [64081,64115]
simple_stmt [64081,64115]
===
match
---
name: _try_number [58163,58174]
name: _try_number [58163,58174]
===
match
---
simple_stmt [29618,30072]
simple_stmt [29618,30072]
===
match
---
param [34077,34105]
param [34077,34105]
===
match
---
parameters [69169,69171]
parameters [69276,69278]
===
match
---
name: job_id [26379,26385]
name: job_id [26379,26385]
===
match
---
decorated [93199,93275]
decorated [93306,93382]
===
match
---
string: """Render templates in the operator fields.""" [80103,80149]
string: """Render templates in the operator fields.""" [80210,80256]
===
match
---
name: self [85926,85930]
name: self [86033,86037]
===
match
---
operator: , [76014,76015]
operator: , [76121,76122]
===
match
---
name: hashlib [812,819]
name: hashlib [812,819]
===
match
---
name: warn [33700,33704]
name: warn [33700,33704]
===
match
---
atom_expr [74210,74223]
atom_expr [74317,74330]
===
match
---
name: replace [75072,75079]
name: replace [75179,75186]
===
match
---
name: prev_ti [35242,35249]
name: prev_ti [35242,35249]
===
match
---
simple_stmt [26195,26228]
simple_stmt [26195,26228]
===
match
---
name: TaskInstance [91590,91602]
name: TaskInstance [91697,91709]
===
match
---
name: render_templates [52910,52926]
name: render_templates [52910,52926]
===
match
---
trailer [26300,26309]
trailer [26300,26309]
===
match
---
atom_expr [81125,81156]
atom_expr [81232,81263]
===
match
---
name: Exception [5148,5157]
name: Exception [5148,5157]
===
match
---
import_from [2243,2303]
import_from [2243,2303]
===
match
---
name: join [53405,53409]
name: join [53405,53409]
===
match
---
operator: @ [54799,54800]
operator: @ [54799,54800]
===
match
---
param [66360,66373]
param [66467,66480]
===
match
---
name: AirflowException [79605,79621]
name: AirflowException [79712,79728]
===
match
---
operator: = [48896,48897]
operator: = [48896,48897]
===
match
---
trailer [18746,18756]
trailer [18746,18756]
===
match
---
name: first [90606,90611]
name: first [90713,90718]
===
match
---
suite [22270,22324]
suite [22270,22324]
===
match
---
trailer [47543,47550]
trailer [47543,47550]
===
match
---
name: debug [28060,28065]
name: debug [28060,28065]
===
match
---
operator: , [76200,76201]
operator: , [76307,76308]
===
match
---
trailer [93549,93554]
trailer [93656,93661]
===
match
---
trailer [54573,54578]
trailer [54573,54578]
===
match
---
name: State [29052,29057]
name: State [29052,29057]
===
match
---
fstring_start: f" [15845,15847]
fstring_start: f" [15845,15847]
===
match
---
trailer [50544,50547]
trailer [50544,50547]
===
match
---
arith_expr [56532,56599]
arith_expr [56532,56599]
===
match
---
name: value [89158,89163]
name: value [89265,89270]
===
match
---
atom_expr [53312,53477]
atom_expr [53312,53477]
===
match
---
atom_expr [83934,83956]
atom_expr [84041,84063]
===
match
---
atom_expr [25983,25994]
atom_expr [25983,25994]
===
match
---
operator: @ [92896,92897]
operator: @ [93003,93004]
===
match
---
operator: , [75938,75939]
operator: , [76045,76046]
===
match
---
name: __table__ [8206,8215]
name: __table__ [8206,8215]
===
match
---
suite [4025,4566]
suite [4025,4566]
===
match
---
trailer [45942,45952]
trailer [45942,45952]
===
match
---
funcdef [40150,40403]
funcdef [40150,40403]
===
match
---
fstring_end: ' [49176,49177]
fstring_end: ' [49176,49177]
===
match
---
operator: = [79393,79394]
operator: = [79500,79501]
===
match
---
name: self [41183,41187]
name: self [41183,41187]
===
match
---
trailer [49262,49284]
trailer [49262,49284]
===
match
---
name: args [50509,50513]
name: args [50509,50513]
===
match
---
name: warning [46001,46008]
name: warning [46001,46008]
===
match
---
suite [5097,5133]
suite [5097,5133]
===
match
---
name: error [24540,24545]
name: error [24540,24545]
===
match
---
argument [50848,50863]
argument [50848,50863]
===
match
---
operator: , [51791,51792]
operator: , [51791,51792]
===
match
---
simple_stmt [38014,38192]
simple_stmt [38014,38192]
===
match
---
trailer [92876,92881]
trailer [92983,92988]
===
match
---
name: execution_date [88578,88592]
name: execution_date [88685,88699]
===
match
---
simple_stmt [31462,31497]
simple_stmt [31462,31497]
===
match
---
name: get_previous_dagrun [32807,32826]
name: get_previous_dagrun [32807,32826]
===
match
---
parameters [74698,74700]
parameters [74805,74807]
===
match
---
atom_expr [47212,47244]
atom_expr [47212,47244]
===
match
---
atom_expr [81528,81549]
atom_expr [81635,81656]
===
match
---
operator: , [12908,12909]
operator: , [12908,12909]
===
match
---
name: __init__ [14229,14237]
name: __init__ [14229,14237]
===
match
---
decorated [68166,68358]
decorated [68273,68465]
===
match
---
name: priority_weight [92812,92827]
name: priority_weight [92919,92934]
===
match
---
trailer [22358,22365]
trailer [22358,22365]
===
match
---
suite [52158,52268]
suite [52158,52268]
===
match
---
name: end_date [84919,84927]
name: end_date [85026,85034]
===
match
---
operator: , [77184,77185]
operator: , [77291,77292]
===
match
---
name: isinstance [63716,63726]
name: isinstance [63716,63726]
===
match
---
atom_expr [63240,63309]
atom_expr [63240,63309]
===
match
---
name: get_next_ds_nodash [74154,74172]
name: get_next_ds_nodash [74261,74279]
===
match
---
operator: , [1095,1096]
operator: , [1095,1096]
===
match
---
trailer [20198,20203]
trailer [20198,20203]
===
match
---
expr_stmt [4757,4773]
expr_stmt [4757,4773]
===
match
---
return_stmt [17800,17823]
return_stmt [17800,17823]
===
match
---
operator: = [67716,67717]
operator: = [67823,67824]
===
match
---
param [71671,71681]
param [71778,71788]
===
match
---
simple_stmt [66499,66540]
simple_stmt [66606,66647]
===
match
---
expr_stmt [52045,52078]
expr_stmt [52045,52078]
===
match
---
trailer [50670,50676]
trailer [50670,50676]
===
match
---
simple_stmt [64153,64183]
simple_stmt [64153,64183]
===
match
---
string: "Please use `dag_run_state`" [8636,8664]
string: "Please use `dag_run_state`" [8636,8664]
===
match
---
name: incr [64293,64297]
name: incr [64293,64297]
===
match
---
trailer [75519,75540]
trailer [75626,75647]
===
match
---
name: jinja_env [83153,83162]
name: jinja_env [83260,83269]
===
match
---
trailer [32946,32954]
trailer [32946,32954]
===
match
---
trailer [81219,81224]
trailer [81326,81331]
===
match
---
strings [78770,79076]
strings [78877,79183]
===
match
---
operator: , [70746,70747]
operator: , [70853,70854]
===
match
---
name: trigger_row [57980,57991]
name: trigger_row [57980,57991]
===
match
---
atom [5887,5889]
atom [5887,5889]
===
match
---
atom_expr [35055,35105]
atom_expr [35055,35105]
===
match
---
comparison [40890,40918]
comparison [40890,40918]
===
match
---
trailer [65529,65535]
trailer [65636,65642]
===
match
---
comparison [90912,90941]
comparison [91019,91048]
===
match
---
operator: @ [71620,71621]
operator: @ [71727,71728]
===
match
---
name: deprecated_proxy [75453,75469]
name: deprecated_proxy [75560,75576]
===
match
---
arglist [32827,32849]
arglist [32827,32849]
===
match
---
operator: , [29593,29594]
operator: , [29593,29594]
===
match
---
name: dep_status [37656,37666]
name: dep_status [37656,37666]
===
match
---
param [9792,9796]
param [9792,9796]
===
match
---
name: _task_id [92204,92212]
name: _task_id [92311,92319]
===
match
---
atom_expr [19241,19253]
atom_expr [19241,19253]
===
match
---
operator: } [77314,77315]
operator: } [77421,77422]
===
match
---
trailer [22436,22443]
trailer [22436,22443]
===
match
---
name: dag_run_state [9410,9423]
name: dag_run_state [9410,9423]
===
match
---
string: "%s. State set to NONE." [45855,45879]
string: "%s. State set to NONE." [45855,45879]
===
match
---
name: Column [11386,11392]
name: Column [11386,11392]
===
match
---
trailer [29191,29205]
trailer [29191,29205]
===
match
---
name: make_aware [15272,15282]
name: make_aware [15272,15282]
===
match
---
funcdef [66545,66895]
funcdef [66652,67002]
===
match
---
import_from [80371,80443]
import_from [80478,80550]
===
match
---
name: update [67491,67497]
name: update [67598,67604]
===
match
---
trailer [67755,67777]
trailer [67862,67884]
===
match
---
trailer [49059,49061]
trailer [49059,49061]
===
match
---
name: State [40333,40338]
name: State [40333,40338]
===
match
---
operator: } [64333,64334]
operator: } [64333,64334]
===
match
---
name: RUNNING [6018,6025]
name: RUNNING [6018,6025]
===
match
---
simple_stmt [12398,12436]
simple_stmt [12398,12436]
===
match
---
name: replacement [72412,72423]
name: replacement [72519,72530]
===
match
---
name: task [51968,51972]
name: task [51968,51972]
===
match
---
name: State [65720,65725]
name: State [65827,65832]
===
match
---
operator: , [75679,75680]
operator: , [75786,75787]
===
match
---
trailer [69729,69733]
trailer [69836,69840]
===
match
---
tfpdef [70074,70090]
tfpdef [70181,70197]
===
match
---
operator: = [48756,48757]
operator: = [48756,48757]
===
match
---
name: commit [51864,51870]
name: commit [51864,51870]
===
match
---
trailer [91789,91793]
trailer [91896,91900]
===
match
---
operator: = [71166,71167]
operator: = [71273,71274]
===
match
---
trailer [74119,74128]
trailer [74226,74235]
===
match
---
name: html_content_err [83323,83339]
name: html_content_err [83430,83446]
===
match
---
decorator [72596,72603]
decorator [72703,72710]
===
match
---
name: airflow [2482,2489]
name: airflow [2482,2489]
===
match
---
name: session [7059,7066]
name: session [7059,7066]
===
match
---
atom_expr [91302,91322]
atom_expr [91409,91429]
===
match
---
atom_expr [46951,46970]
atom_expr [46951,46970]
===
match
---
argument [34501,34512]
argument [34501,34512]
===
match
---
subscriptlist [3795,3803]
subscriptlist [3795,3803]
===
match
---
trailer [91793,91855]
trailer [91900,91962]
===
match
---
name: session [54859,54866]
name: session [54859,54866]
===
match
---
string: "Refreshing TaskInstance %s from DB" [25412,25448]
string: "Refreshing TaskInstance %s from DB" [25412,25448]
===
match
---
simple_stmt [43828,44150]
simple_stmt [43828,44150]
===
match
---
param [4961,4989]
param [4961,4989]
===
match
---
name: str [14194,14197]
name: str [14194,14197]
===
match
---
atom_expr [74498,74523]
atom_expr [74605,74630]
===
match
---
name: extend [22793,22799]
name: extend [22793,22799]
===
match
---
arglist [15283,15321]
arglist [15283,15321]
===
match
---
atom_expr [7801,7994]
atom_expr [7801,7994]
===
match
---
operator: , [18010,18011]
operator: , [18010,18011]
===
match
---
name: Stats [49116,49121]
name: Stats [49116,49121]
===
match
---
simple_stmt [67151,67180]
simple_stmt [67258,67287]
===
match
---
name: dag_id [19773,19779]
name: dag_id [19773,19779]
===
match
---
name: datetime [92300,92308]
name: datetime [92407,92415]
===
match
---
atom_expr [24746,24801]
atom_expr [24746,24801]
===
match
---
operator: = [26760,26761]
operator: = [26760,26761]
===
match
---
name: self [16067,16071]
name: self [16067,16071]
===
match
---
trailer [5922,5969]
trailer [5922,5969]
===
match
---
name: ignore_all_deps [19338,19353]
name: ignore_all_deps [19338,19353]
===
match
---
name: execute_callable [57035,57051]
name: execute_callable [57035,57051]
===
match
---
param [59190,59195]
param [59190,59195]
===
match
---
name: deps [37417,37421]
name: deps [37417,37421]
===
match
---
atom_expr [53491,53530]
atom_expr [53491,53530]
===
match
---
name: base_url [23165,23173]
name: base_url [23165,23173]
===
match
---
tfpdef [20220,20239]
tfpdef [20220,20239]
===
match
---
name: state [37960,37965]
name: state [37960,37965]
===
match
---
operator: , [14113,14114]
operator: , [14113,14114]
===
match
---
name: try_number [82888,82898]
name: try_number [82995,83005]
===
match
---
name: cmd [22736,22739]
name: cmd [22736,22739]
===
match
---
name: timedelta [39960,39969]
name: timedelta [39960,39969]
===
match
---
trailer [64436,64443]
trailer [64436,64443]
===
match
---
operator: , [75900,75901]
operator: , [76007,76008]
===
match
---
name: close [62016,62021]
name: close [62016,62021]
===
match
---
name: exception [82780,82789]
name: exception [82887,82896]
===
match
---
name: dag [30950,30953]
name: dag [30950,30953]
===
match
---
operator: @ [85080,85081]
operator: @ [85187,85188]
===
match
---
name: self [93622,93626]
name: self [93729,93733]
===
match
---
trailer [16138,16140]
trailer [16138,16140]
===
match
---
name: self [27111,27115]
name: self [27111,27115]
===
match
---
name: Integer [11632,11639]
name: Integer [11632,11639]
===
match
---
operator: = [90537,90538]
operator: = [90644,90645]
===
match
---
operator: @ [63315,63316]
operator: @ [63315,63316]
===
match
---
name: dep_context [36590,36601]
name: dep_context [36590,36601]
===
match
---
simple_stmt [60059,60093]
simple_stmt [60059,60093]
===
match
---
funcdef [52273,54794]
funcdef [52273,54794]
===
match
---
parameters [83841,83855]
parameters [83948,83962]
===
match
---
atom_expr [90890,91069]
atom_expr [90997,91176]
===
match
---
atom_expr [23574,23586]
atom_expr [23574,23586]
===
match
---
trailer [24390,24392]
trailer [24390,24392]
===
match
---
trailer [67497,67509]
trailer [67604,67616]
===
match
---
name: dag_id [49919,49925]
name: dag_id [49919,49925]
===
match
---
funcdef [23328,23764]
funcdef [23328,23764]
===
match
---
operator: = [31669,31670]
operator: = [31669,31670]
===
match
---
trailer [29536,29538]
trailer [29536,29538]
===
match
---
trailer [81086,81104]
trailer [81193,81211]
===
match
---
name: task [66844,66848]
name: task [66951,66955]
===
match
---
operator: = [8947,8948]
operator: = [8947,8948]
===
match
---
operator: = [61625,61626]
operator: = [61625,61626]
===
match
---
name: str [92546,92549]
name: str [92653,92656]
===
match
---
name: query [89119,89124]
name: query [89226,89231]
===
match
---
comp_op [8824,8830]
comp_op [8824,8830]
===
match
---
operator: = [43856,43857]
operator: = [43856,43857]
===
match
---
name: _try_number [17812,17823]
name: _try_number [17812,17823]
===
match
---
param [5378,5401]
param [5378,5401]
===
match
---
simple_stmt [93795,93824]
simple_stmt [93902,93931]
===
match
---
subscriptlist [90094,90125]
subscriptlist [90201,90232]
===
match
---
trailer [22912,22937]
trailer [22912,22937]
===
match
---
suite [92596,92644]
suite [92703,92751]
===
match
---
operator: - [6586,6587]
operator: - [6586,6587]
===
match
---
operator: = [41335,41336]
operator: = [41335,41336]
===
match
---
if_stmt [55582,56178]
if_stmt [55582,56178]
===
match
---
atom_expr [55883,55918]
atom_expr [55883,55918]
===
match
---
name: lazy_object_proxy [77097,77114]
name: lazy_object_proxy [77204,77221]
===
match
---
operator: , [45555,45556]
operator: , [45555,45556]
===
match
---
name: and_ [7726,7730]
name: and_ [7726,7730]
===
match
---
name: log [4383,4386]
name: log [4383,4386]
===
match
---
name: task [43122,43126]
name: task [43122,43126]
===
match
---
atom_expr [59025,59058]
atom_expr [59025,59058]
===
match
---
simple_stmt [62007,62024]
simple_stmt [62007,62024]
===
match
---
trailer [70867,70871]
trailer [70974,70978]
===
match
---
string: "prev_ds" [76564,76573]
string: "prev_ds" [76671,76680]
===
match
---
trailer [46316,46326]
trailer [46316,46326]
===
match
---
name: VariableJsonAccessor [77734,77754]
name: VariableJsonAccessor [77841,77861]
===
match
---
decorator [28524,28541]
decorator [28524,28541]
===
match
---
arglist [76085,76201]
arglist [76192,76308]
===
match
---
fstring_string: /log?execution_date= [23238,23258]
fstring_string: /log?execution_date= [23238,23258]
===
match
---
arglist [54708,54757]
arglist [54708,54757]
===
match
---
operator: = [27445,27446]
operator: = [27445,27446]
===
match
---
string: "at task runtime. Attempt %s of " [45801,45834]
string: "at task runtime. Attempt %s of " [45801,45834]
===
match
---
simple_stmt [5894,5970]
simple_stmt [5894,5970]
===
match
---
name: dag_id [91214,91220]
name: dag_id [91321,91327]
===
match
---
name: next_method [12559,12570]
name: next_method [12559,12570]
===
match
---
name: warn [72462,72466]
name: warn [72569,72573]
===
match
---
name: cmd [22433,22436]
name: cmd [22433,22436]
===
match
---
simple_stmt [49303,49370]
simple_stmt [49303,49370]
===
match
---
operator: = [26490,26491]
operator: = [26490,26491]
===
match
---
name: self [18696,18700]
name: self [18696,18700]
===
match
---
simple_stmt [9725,9737]
simple_stmt [9725,9737]
===
match
---
atom_expr [16385,16399]
atom_expr [16385,16399]
===
match
---
suite [93161,93194]
suite [93268,93301]
===
match
---
name: logging [827,834]
name: logging [827,834]
===
match
---
trailer [92466,92483]
trailer [92573,92590]
===
match
---
string: '-' [73043,73046]
string: '-' [73150,73153]
===
match
---
funcdef [66900,78059]
funcdef [67007,78166]
===
match
---
name: from_string [83253,83264]
name: from_string [83360,83371]
===
match
---
expr_stmt [27773,27803]
expr_stmt [27773,27803]
===
match
---
name: session [35911,35918]
name: session [35911,35918]
===
match
---
string: """     Sets the current execution context to the provided context object.     This method should be called once per Task execution, before calling operator.execute.     """ [4030,4203]
string: """     Sets the current execution context to the provided context object.     This method should be called once per Task execution, before calling operator.execute.     """ [4030,4203]
===
match
---
simple_stmt [60147,60210]
simple_stmt [60147,60210]
===
match
---
name: airflow [3607,3614]
name: airflow [3607,3614]
===
match
---
simple_stmt [11836,11892]
simple_stmt [11836,11892]
===
match
---
trailer [57133,57141]
trailer [57133,57141]
===
match
---
name: unixname [26341,26349]
name: unixname [26341,26349]
===
match
---
parameters [78117,78137]
parameters [78224,78244]
===
match
---
simple_stmt [40312,40403]
simple_stmt [40312,40403]
===
match
---
name: isoformat [68019,68028]
name: isoformat [68126,68135]
===
match
---
name: default_var [70074,70085]
name: default_var [70181,70192]
===
match
---
atom_expr [22736,22759]
atom_expr [22736,22759]
===
match
---
name: state [32315,32320]
name: state [32315,32320]
===
match
---
atom_expr [12016,12035]
atom_expr [12016,12035]
===
match
---
operator: , [3486,3487]
operator: , [3486,3487]
===
match
---
simple_stmt [67918,67950]
simple_stmt [68025,68057]
===
match
---
trailer [23616,23623]
trailer [23616,23623]
===
match
---
operator: , [75421,75422]
operator: , [75528,75529]
===
match
---
simple_stmt [835,847]
simple_stmt [835,847]
===
match
---
trailer [14977,14993]
trailer [14977,14993]
===
match
---
operator: = [18200,18201]
operator: = [18200,18201]
===
match
---
name: str [71677,71680]
name: str [71784,71787]
===
match
---
atom [72894,72930]
atom [73001,73037]
===
match
---
atom_expr [40123,40136]
atom_expr [40123,40136]
===
match
---
if_stmt [65356,65789]
if_stmt [65463,65896]
===
match
---
arglist [64521,64578]
arglist [64625,64685]
===
match
---
operator: = [79334,79335]
operator: = [79441,79442]
===
match
---
operator: , [71680,71681]
operator: , [71787,71788]
===
match
---
atom_expr [11911,11922]
atom_expr [11911,11922]
===
match
---
name: strftime [72698,72706]
name: strftime [72805,72813]
===
match
---
operator: = [85003,85004]
operator: = [85110,85111]
===
match
---
name: self [28269,28273]
name: self [28269,28273]
===
match
---
simple_stmt [65945,65969]
simple_stmt [66052,66076]
===
match
---
operator: , [51169,51170]
operator: , [51169,51170]
===
match
---
name: TaskInstance [92138,92150]
name: TaskInstance [92245,92257]
===
match
---
name: state [66646,66651]
name: state [66753,66758]
===
match
---
operator: = [83340,83341]
operator: = [83447,83448]
===
match
---
name: TR [7868,7870]
name: TR [7868,7870]
===
match
---
name: next_kwargs [58053,58064]
name: next_kwargs [58053,58064]
===
match
---
name: partial [1000,1007]
name: partial [1000,1007]
===
match
---
atom_expr [7059,7076]
atom_expr [7059,7076]
===
match
---
operator: = [54679,54680]
operator: = [54679,54680]
===
match
---
atom_expr [62773,62784]
atom_expr [62773,62784]
===
match
---
operator: , [13441,13442]
operator: , [13441,13442]
===
match
---
trailer [26286,26295]
trailer [26286,26295]
===
match
---
trailer [80242,80265]
trailer [80349,80372]
===
match
---
simple_stmt [49116,49179]
simple_stmt [49116,49179]
===
match
---
name: Float [1346,1351]
name: Float [1346,1351]
===
match
---
simple_stmt [857,871]
simple_stmt [857,871]
===
match
---
trailer [52988,53049]
trailer [52988,53049]
===
match
---
operator: , [12955,12956]
operator: , [12955,12956]
===
match
---
param [28332,28336]
param [28332,28336]
===
match
---
string: "XCom data cleared" [28284,28303]
string: "XCom data cleared" [28284,28303]
===
match
---
operator: = [58384,58385]
operator: = [58384,58385]
===
match
---
name: Any [1086,1089]
name: Any [1086,1089]
===
match
---
argument [54218,54231]
argument [54218,54231]
===
match
---
name: self [63156,63160]
name: self [63156,63160]
===
match
---
name: utils [3456,3461]
name: utils [3456,3461]
===
match
---
name: self [31595,31599]
name: self [31595,31599]
===
match
---
operator: = [65718,65719]
operator: = [65825,65826]
===
match
---
atom [13328,13344]
atom [13328,13344]
===
match
---
simple_stmt [27879,28043]
simple_stmt [27879,28043]
===
match
---
name: provide_session [78065,78080]
name: provide_session [78172,78187]
===
match
---
suite [10611,91856]
suite [10611,91963]
===
match
---
operator: == [25637,25639]
operator: == [25637,25639]
===
match
---
simple_stmt [1192,1206]
simple_stmt [1192,1206]
===
match
---
name: queue [26484,26489]
name: queue [26484,26489]
===
match
---
operator: , [80605,80606]
operator: , [80712,80713]
===
match
---
atom_expr [10123,10134]
atom_expr [10123,10134]
===
match
---
name: e [51321,51322]
name: e [51321,51322]
===
match
---
name: key [72064,72067]
name: key [72171,72174]
===
match
---
name: Stats [54767,54772]
name: Stats [54767,54772]
===
match
---
term [39463,39484]
term [39463,39484]
===
match
---
trailer [68065,68074]
trailer [68172,68181]
===
match
---
name: Proxy [77115,77120]
name: Proxy [77222,77227]
===
match
---
simple_stmt [84199,84268]
simple_stmt [84306,84375]
===
match
---
atom_expr [30405,30459]
atom_expr [30405,30459]
===
match
---
string: 'task' [18639,18645]
string: 'task' [18639,18645]
===
match
---
funcdef [47099,47263]
funcdef [47099,47263]
===
match
---
atom_expr [89216,89236]
atom_expr [89323,89343]
===
match
---
simple_stmt [937,978]
simple_stmt [937,978]
===
match
---
operator: , [11355,11356]
operator: , [11355,11356]
===
match
---
name: mark_success [43677,43689]
name: mark_success [43677,43689]
===
match
---
trailer [44328,44330]
trailer [44328,44330]
===
match
---
name: self [58158,58162]
name: self [58158,58162]
===
match
---
name: commit [49053,49059]
name: commit [49053,49059]
===
match
---
tfpdef [41312,41334]
tfpdef [41312,41334]
===
match
---
argument [36786,36809]
argument [36786,36809]
===
match
---
string: """         Checks on whether the task instance is in the right state and timeframe         to be retried.         """ [40185,40303]
string: """         Checks on whether the task instance is in the right state and timeframe         to be retried.         """ [40185,40303]
===
match
---
operator: , [61742,61743]
operator: , [61742,61743]
===
match
---
name: get_hostname [3191,3203]
name: get_hostname [3191,3203]
===
match
---
atom_expr [36868,37072]
atom_expr [36868,37072]
===
match
---
return_stmt [93795,93823]
return_stmt [93902,93930]
===
match
---
name: previous_start_date_success [35285,35312]
name: previous_start_date_success [35285,35312]
===
match
---
operator: , [39243,39244]
operator: , [39243,39244]
===
match
---
trailer [68074,68091]
trailer [68181,68198]
===
match
---
trailer [6420,6429]
trailer [6420,6429]
===
match
---
operator: , [14176,14177]
operator: , [14176,14177]
===
match
---
name: self [90008,90012]
name: self [90115,90119]
===
match
---
name: self [37999,38003]
name: self [37999,38003]
===
match
---
name: Integer [11856,11863]
name: Integer [11856,11863]
===
match
---
name: run_id [30385,30391]
name: run_id [30385,30391]
===
match
---
simple_stmt [69327,69378]
simple_stmt [69434,69485]
===
match
---
trailer [26022,26028]
trailer [26022,26028]
===
match
---
comp_op [57347,57353]
comp_op [57347,57353]
===
match
---
name: error [66527,66532]
name: error [66634,66639]
===
match
---
trailer [89772,89780]
trailer [89879,89887]
===
match
---
argument [86272,86279]
argument [86379,86386]
===
match
---
import_from [978,1007]
import_from [978,1007]
===
match
---
atom_expr [58787,58802]
atom_expr [58787,58802]
===
match
---
trailer [80830,80832]
trailer [80937,80939]
===
match
---
operator: = [80865,80866]
operator: = [80972,80973]
===
match
---
atom_expr [91108,91117]
atom_expr [91215,91224]
===
match
---
arglist [92577,92594]
arglist [92684,92701]
===
match
---
arglist [53700,53718]
arglist [53700,53718]
===
match
---
decorator [89453,89470]
decorator [89560,89577]
===
match
---
strings [45731,45879]
strings [45731,45879]
===
match
---
trailer [55898,55918]
trailer [55898,55918]
===
match
---
name: execution_date [15665,15679]
name: execution_date [15665,15679]
===
match
---
expr_stmt [46519,46567]
expr_stmt [46519,46567]
===
match
---
atom_expr [13725,13904]
atom_expr [13725,13904]
===
match
---
name: queue [92858,92863]
name: queue [92965,92970]
===
match
---
operator: = [44277,44278]
operator: = [44277,44278]
===
match
---
name: reason [37747,37753]
name: reason [37747,37753]
===
match
---
atom_expr [10170,10185]
atom_expr [10170,10185]
===
match
---
operator: , [32832,32833]
operator: , [32832,32833]
===
match
---
string: 'task_instance_dag_run_fkey' [13413,13441]
string: 'task_instance_dag_run_fkey' [13413,13441]
===
match
---
operator: , [1089,1090]
operator: , [1089,1090]
===
match
---
operator: { [54729,54730]
operator: { [54729,54730]
===
match
---
trailer [46795,46802]
trailer [46795,46802]
===
match
---
name: self [29272,29276]
name: self [29272,29276]
===
match
---
subscriptlist [5441,5468]
subscriptlist [5441,5468]
===
match
---
string: 'email' [83943,83950]
string: 'email' [84050,84057]
===
match
---
trailer [55565,55573]
trailer [55565,55573]
===
match
---
atom_expr [90959,90978]
atom_expr [91066,91085]
===
match
---
name: Stats [43492,43497]
name: Stats [43492,43497]
===
match
---
atom_expr [92884,92890]
atom_expr [92991,92997]
===
match
---
param [33008,33012]
param [33008,33012]
===
match
---
name: Session [40459,40466]
name: Session [40459,40466]
===
match
---
name: context [57052,57059]
name: context [57052,57059]
===
match
---
atom_expr [27007,27017]
atom_expr [27007,27017]
===
match
---
name: dep_context [45544,45555]
name: dep_context [45544,45555]
===
match
---
operator: , [89513,89514]
operator: , [89620,89621]
===
match
---
decorated [9766,9940]
decorated [9766,9940]
===
match
---
simple_stmt [62546,62576]
simple_stmt [62546,62576]
===
match
---
simple_stmt [50531,50548]
simple_stmt [50531,50548]
===
match
---
name: dag_id [91493,91499]
name: dag_id [91600,91606]
===
match
---
atom_expr [41044,41084]
atom_expr [41044,41084]
===
match
---
atom_expr [55052,55068]
atom_expr [55052,55068]
===
match
---
simple_stmt [34470,34531]
simple_stmt [34470,34531]
===
match
---
name: session [49526,49533]
name: session [49526,49533]
===
match
---
name: name [61838,61842]
name: name [61838,61842]
===
match
---
trailer [65422,65428]
trailer [65529,65535]
===
match
---
string: 'Try {{try_number}} out of {{max_tries + 1}}<br>' [82198,82247]
string: 'Try {{try_number}} out of {{max_tries + 1}}<br>' [82305,82354]
===
match
---
trailer [28829,28836]
trailer [28829,28836]
===
match
---
name: trigger_id [13152,13162]
name: trigger_id [13152,13162]
===
match
---
atom_expr [12612,12632]
atom_expr [12612,12632]
===
match
---
operator: , [23485,23486]
operator: , [23485,23486]
===
match
---
trailer [28065,28087]
trailer [28065,28087]
===
match
---
name: self [40074,40078]
name: self [40074,40078]
===
match
---
trailer [64323,64333]
trailer [64323,64333]
===
match
---
name: bytes [4595,4600]
name: bytes [4595,4600]
===
match
---
name: session [24941,24948]
name: session [24941,24948]
===
match
---
atom_expr [17243,17259]
atom_expr [17243,17259]
===
match
---
trailer [39214,39222]
trailer [39214,39222]
===
match
---
trailer [53088,53107]
trailer [53088,53107]
===
match
---
simple_stmt [6231,6259]
simple_stmt [6231,6259]
===
match
---
name: tis [8990,8993]
name: tis [8990,8993]
===
match
---
trailer [25971,25980]
trailer [25971,25980]
===
match
---
string: """Return Number of running TIs from the DB""" [89533,89579]
string: """Return Number of running TIs from the DB""" [89640,89686]
===
match
---
name: external_executor_id [12161,12181]
name: external_executor_id [12161,12181]
===
match
---
name: session [89515,89522]
name: session [89622,89629]
===
match
---
name: str [41513,41516]
name: str [41513,41516]
===
match
---
simple_stmt [46484,46511]
simple_stmt [46484,46511]
===
match
---
operator: , [81105,81106]
operator: , [81212,81213]
===
match
---
name: get_prev_ds_nodash [74910,74928]
name: get_prev_ds_nodash [75017,75035]
===
match
---
operator: = [11872,11873]
operator: = [11872,11873]
===
match
---
operator: ! [15870,15871]
operator: ! [15870,15871]
===
match
---
operator: , [76252,76253]
operator: , [76359,76360]
===
match
---
atom_expr [43375,43383]
atom_expr [43375,43383]
===
match
---
name: dagrun [69271,69277]
name: dagrun [69378,69384]
===
match
---
atom_expr [65707,65717]
atom_expr [65814,65824]
===
match
---
atom_expr [89335,89374]
atom_expr [89442,89481]
===
match
---
name: _key [93736,93740]
name: _key [93843,93847]
===
match
---
arith_expr [29159,29190]
arith_expr [29159,29190]
===
match
---
trailer [70101,70132]
trailer [70208,70239]
===
match
---
name: strftime [67821,67829]
name: strftime [67928,67936]
===
match
---
operator: = [70981,70982]
operator: = [71088,71089]
===
match
---
trailer [84095,84102]
trailer [84202,84209]
===
match
---
name: session [49045,49052]
name: session [49045,49052]
===
match
---
sync_comp_for [90856,90868]
sync_comp_for [90963,90975]
===
match
---
trailer [75672,75679]
trailer [75779,75786]
===
match
---
suite [33014,33457]
suite [33014,33457]
===
match
---
name: self [10170,10174]
name: self [10170,10174]
===
match
---
atom_expr [14029,14075]
atom_expr [14029,14075]
===
match
---
operator: , [37022,37023]
operator: , [37022,37023]
===
match
---
name: ti [7016,7018]
name: ti [7016,7018]
===
match
---
simple_stmt [54633,54688]
simple_stmt [54633,54688]
===
match
---
atom_expr [7756,7765]
atom_expr [7756,7765]
===
match
---
atom_expr [83876,83905]
atom_expr [83983,84012]
===
match
---
name: commit [52259,52265]
name: commit [52259,52265]
===
match
---
name: provide_session [28525,28540]
name: provide_session [28525,28540]
===
match
---
name: pendulum [35331,35339]
name: pendulum [35331,35339]
===
match
---
name: self [66015,66019]
name: self [66122,66126]
===
match
---
name: count [30479,30484]
name: count [30479,30484]
===
match
---
simple_stmt [34988,35037]
simple_stmt [34988,35037]
===
match
---
simple_stmt [78726,79102]
simple_stmt [78833,79209]
===
match
---
except_clause [60525,60541]
except_clause [60525,60541]
===
match
---
operator: = [13507,13508]
operator: = [13507,13508]
===
match
---
expr_stmt [6327,6347]
expr_stmt [6327,6347]
===
match
---
return_stmt [32387,32398]
return_stmt [32387,32398]
===
match
---
simple_stmt [4729,4753]
simple_stmt [4729,4753]
===
match
---
expr_stmt [30172,30470]
expr_stmt [30172,30470]
===
match
---
argument [86352,86370]
argument [86459,86477]
===
match
---
atom_expr [15859,15870]
atom_expr [15859,15870]
===
match
---
name: defer [49746,49751]
name: defer [49746,49751]
===
match
---
expr_stmt [61589,61631]
expr_stmt [61589,61631]
===
match
---
name: self [15299,15303]
name: self [15299,15303]
===
match
---
name: task_copy [56532,56541]
name: task_copy [56532,56541]
===
match
---
string: 'ts' [77591,77595]
string: 'ts' [77698,77702]
===
match
---
atom_expr [45506,45587]
atom_expr [45506,45587]
===
match
---
param [79160,79172]
param [79267,79279]
===
match
---
not_test [65373,65404]
not_test [65480,65511]
===
match
---
simple_stmt [26007,26029]
simple_stmt [26007,26029]
===
match
---
fstring_expr [72411,72426]
fstring_expr [72518,72533]
===
match
---
atom_expr [93541,93554]
atom_expr [93648,93661]
===
match
---
param [85124,85129]
param [85231,85236]
===
match
---
operator: , [41598,41599]
operator: , [41598,41599]
===
match
---
name: ignore_task_deps [19400,19416]
name: ignore_task_deps [19400,19416]
===
match
---
atom_expr [64732,64748]
atom_expr [64839,64855]
===
match
---
name: pool [11789,11793]
name: pool [11789,11793]
===
match
---
atom_expr [44942,44957]
atom_expr [44942,44957]
===
match
---
name: get_prev_data_interval_end_success [68884,68918]
name: get_prev_data_interval_end_success [68991,69025]
===
match
---
name: context [54560,54567]
name: context [54560,54567]
===
match
---
operator: , [64338,64339]
operator: , [64338,64339]
===
match
---
atom_expr [58708,58728]
atom_expr [58708,58728]
===
match
---
dotted_name [17184,17201]
dotted_name [17184,17201]
===
match
---
tfpdef [60681,60694]
tfpdef [60681,60694]
===
match
---
trailer [92840,92847]
trailer [92947,92954]
===
match
---
and_test [35189,35261]
and_test [35189,35261]
===
match
---
atom_expr [25542,25553]
atom_expr [25542,25553]
===
match
---
funcdef [28545,29236]
funcdef [28545,29236]
===
match
---
name: task_tries [8050,8060]
name: task_tries [8050,8060]
===
match
---
if_stmt [22768,22818]
if_stmt [22768,22818]
===
match
---
name: airflow [2539,2546]
name: airflow [2539,2546]
===
match
---
atom_expr [12981,13027]
atom_expr [12981,13027]
===
match
---
string: 'params' [76266,76274]
string: 'params' [76373,76381]
===
match
---
parameters [90073,90128]
parameters [90180,90235]
===
match
---
name: ti [26677,26679]
name: ti [26677,26679]
===
match
---
operator: , [76641,76642]
operator: , [76748,76749]
===
match
---
name: self [46894,46898]
name: self [46894,46898]
===
match
---
suite [35940,37205]
suite [35940,37205]
===
match
---
name: timedelta [72684,72693]
name: timedelta [72791,72800]
===
match
---
param [23808,23813]
param [23808,23813]
===
match
---
name: session [3333,3340]
name: session [3333,3340]
===
match
---
name: airflow [3906,3913]
name: airflow [3906,3913]
===
match
---
param [37871,37875]
param [37871,37875]
===
match
---
operator: = [26581,26582]
operator: = [26581,26582]
===
match
---
fstring_expr [37910,37923]
fstring_expr [37910,37923]
===
match
---
atom_expr [69969,69982]
atom_expr [70076,70089]
===
match
---
tfpdef [60836,60857]
tfpdef [60836,60857]
===
match
---
name: self [16627,16631]
name: self [16627,16631]
===
match
---
simple_stmt [58644,58730]
simple_stmt [58644,58730]
===
match
---
name: try_number [26200,26210]
name: try_number [26200,26210]
===
match
---
expr_stmt [64217,64250]
expr_stmt [64217,64250]
===
match
---
atom_expr [9502,9514]
atom_expr [9502,9514]
===
match
---
decorator [34001,34018]
decorator [34001,34018]
===
match
---
name: dag_run_state [8780,8793]
name: dag_run_state [8780,8793]
===
match
---
simple_stmt [15435,15492]
simple_stmt [15435,15492]
===
match
---
suite [84451,84772]
suite [84558,84879]
===
match
---
parameters [54852,54872]
parameters [54852,54872]
===
match
---
name: path [18819,18823]
name: path [18819,18823]
===
match
---
simple_stmt [24430,24450]
simple_stmt [24430,24450]
===
match
---
arglist [32292,32320]
arglist [32292,32320]
===
match
---
atom_expr [66015,66076]
atom_expr [66122,66183]
===
match
---
operator: = [26211,26212]
operator: = [26211,26212]
===
match
---
trailer [32941,32972]
trailer [32941,32972]
===
match
---
funcdef [58828,59158]
funcdef [58828,59158]
===
match
---
import_from [2579,2632]
import_from [2579,2632]
===
match
---
name: UndefinedError [78688,78702]
name: UndefinedError [78795,78809]
===
match
---
trailer [65711,65717]
trailer [65818,65824]
===
match
---
name: ti [24134,24136]
name: ti [24134,24136]
===
match
---
expr_stmt [25967,25994]
expr_stmt [25967,25994]
===
match
---
name: self [10373,10377]
name: self [10373,10377]
===
match
---
trailer [4594,4601]
trailer [4594,4601]
===
match
---
name: str [86565,86568]
name: str [86672,86675]
===
match
---
name: UndefinedError [79561,79575]
name: UndefinedError [79668,79682]
===
match
---
operator: @ [32404,32405]
operator: @ [32404,32405]
===
match
---
name: session [67339,67346]
name: session [67446,67453]
===
match
---
name: dag_id [90545,90551]
name: dag_id [90652,90658]
===
match
---
name: mark_success [61680,61692]
name: mark_success [61680,61692]
===
match
---
trailer [77527,77577]
trailer [77634,77684]
===
match
---
name: next_execution_date [73716,73735]
name: next_execution_date [73823,73842]
===
match
---
expr_stmt [92380,92417]
expr_stmt [92487,92524]
===
match
---
operator: = [74969,74970]
operator: = [75076,75077]
===
match
---
atom_expr [26007,26017]
atom_expr [26007,26017]
===
match
---
atom_expr [40831,40925]
atom_expr [40831,40925]
===
match
---
param [18020,18042]
param [18020,18042]
===
match
---
with_item [5055,5083]
with_item [5055,5083]
===
match
---
name: ti [25983,25985]
name: ti [25983,25985]
===
match
---
name: coerce_datetime [74444,74459]
name: coerce_datetime [74551,74566]
===
match
---
name: setter [17195,17201]
name: setter [17195,17201]
===
match
---
operator: , [15663,15664]
operator: , [15663,15664]
===
match
---
name: Exception [59746,59755]
name: Exception [59746,59755]
===
match
---
name: pod [80507,80510]
name: pod [80614,80617]
===
match
---
trailer [54655,54687]
trailer [54655,54687]
===
match
---
simple_stmt [26901,26935]
simple_stmt [26901,26935]
===
match
---
atom_expr [32179,32228]
atom_expr [32179,32228]
===
match
---
argument [76889,76908]
argument [76996,77015]
===
match
---
operator: , [66274,66275]
operator: , [66381,66382]
===
match
---
operator: = [18824,18825]
operator: = [18824,18825]
===
match
---
simple_stmt [50772,50865]
simple_stmt [50772,50865]
===
match
---
if_stmt [74997,75045]
if_stmt [75104,75152]
===
match
---
operator: = [88477,88478]
operator: = [88584,88585]
===
match
---
trailer [39891,39939]
trailer [39891,39939]
===
match
---
name: key [75764,75767]
name: key [75871,75874]
===
match
---
param [20114,20146]
param [20114,20146]
===
match
---
except_clause [84687,84703]
except_clause [84794,84810]
===
match
---
operator: , [1429,1430]
operator: , [1429,1430]
===
match
---
name: Column [11699,11705]
name: Column [11699,11705]
===
match
---
trailer [76067,76215]
trailer [76174,76322]
===
match
---
name: str [72637,72640]
name: str [72744,72747]
===
match
---
trailer [49338,49369]
trailer [49338,49369]
===
match
---
suite [32877,32902]
suite [32877,32902]
===
match
---
simple_stmt [32890,32902]
simple_stmt [32890,32902]
===
match
---
operator: , [54231,54232]
operator: , [54231,54232]
===
match
---
param [86540,86593]
param [86647,86700]
===
match
---
name: ti [92884,92886]
name: ti [92991,92993]
===
match
---
trailer [25803,25805]
trailer [25803,25805]
===
match
---
name: dag_id [91506,91512]
name: dag_id [91613,91619]
===
match
---
tfpdef [41197,41210]
tfpdef [41197,41210]
===
match
---
operator: = [82882,82883]
operator: = [82989,82990]
===
match
---
trailer [13521,13709]
trailer [13521,13709]
===
match
---
name: warning [45702,45709]
name: warning [45702,45709]
===
match
---
name: set_current_context [3987,4006]
name: set_current_context [3987,4006]
===
match
---
trailer [73478,73495]
trailer [73585,73602]
===
match
---
operator: , [12813,12814]
operator: , [12813,12814]
===
match
---
if_stmt [50504,50548]
if_stmt [50504,50548]
===
match
---
name: task_reschedule [44905,44920]
name: task_reschedule [44905,44920]
===
match
---
expr_stmt [79316,79402]
expr_stmt [79423,79509]
===
match
---
name: ignore_depends_on_past [45326,45348]
name: ignore_depends_on_past [45326,45348]
===
match
---
string: 'outlets' [76229,76238]
string: 'outlets' [76336,76345]
===
match
---
atom_expr [4694,4703]
atom_expr [4694,4703]
===
match
---
name: add [64423,64426]
name: add [64423,64426]
===
match
---
arglist [79906,79977]
arglist [80013,80084]
===
match
---
name: jinja_context [83296,83309]
name: jinja_context [83403,83416]
===
match
---
name: pool_slots [11836,11846]
name: pool_slots [11836,11846]
===
match
---
operator: = [26018,26019]
operator: = [26018,26019]
===
match
---
operator: , [90108,90109]
operator: , [90215,90216]
===
match
---
name: error_fd [61589,61597]
name: error_fd [61589,61597]
===
match
---
trailer [38245,38250]
trailer [38245,38250]
===
match
---
suite [22205,22249]
suite [22205,22249]
===
match
---
trailer [53404,53409]
trailer [53404,53409]
===
match
---
name: try_number [10175,10185]
name: try_number [10175,10185]
===
match
---
name: dag_id [92914,92920]
name: dag_id [93021,93027]
===
match
---
name: int [93550,93553]
name: int [93657,93660]
===
match
---
atom_expr [60952,60965]
atom_expr [60952,60965]
===
match
---
name: self [36716,36720]
name: self [36716,36720]
===
match
---
name: run_id [15554,15560]
name: run_id [15554,15560]
===
match
---
name: run_id [91616,91622]
name: run_id [91723,91729]
===
match
---
param [86602,86631]
param [86709,86738]
===
match
---
suite [14994,15492]
suite [14994,15492]
===
match
---
simple_stmt [46576,46597]
simple_stmt [46576,46597]
===
match
---
suite [74192,74316]
suite [74299,74423]
===
match
---
simple_stmt [57430,57444]
simple_stmt [57430,57444]
===
match
---
name: dag_id [30273,30279]
name: dag_id [30273,30279]
===
match
---
name: AirflowException [52610,52626]
name: AirflowException [52610,52626]
===
match
---
name: Optional [20190,20198]
name: Optional [20190,20198]
===
match
---
atom_expr [49386,49428]
atom_expr [49386,49428]
===
match
---
atom [22527,22552]
atom [22527,22552]
===
match
---
name: self [34988,34992]
name: self [34988,34992]
===
match
---
param [85138,85147]
param [85245,85254]
===
match
---
name: Optional [60988,60996]
name: Optional [60988,60996]
===
match
---
operator: = [6511,6512]
operator: = [6511,6512]
===
match
---
trailer [9212,9219]
trailer [9212,9219]
===
match
---
name: dag_model [18747,18756]
name: dag_model [18747,18756]
===
match
---
except_clause [71899,71930]
except_clause [72006,72037]
===
match
---
operator: , [13063,13064]
operator: , [13063,13064]
===
match
---
name: subject [84745,84752]
name: subject [84852,84859]
===
match
---
atom_expr [92220,92230]
atom_expr [92327,92337]
===
match
---
name: tis [91280,91283]
name: tis [91387,91390]
===
match
---
arglist [35542,35760]
arglist [35542,35760]
===
match
---
atom_expr [83153,83215]
atom_expr [83260,83322]
===
match
---
name: r [15871,15872]
name: r [15871,15872]
===
match
---
operator: , [19578,19579]
operator: , [19578,19579]
===
match
---
name: ApiClient [81181,81190]
name: ApiClient [81288,81297]
===
match
---
trailer [17081,17087]
trailer [17081,17087]
===
match
---
suite [18723,18757]
suite [18723,18757]
===
match
---
operator: , [28220,28221]
operator: , [28220,28221]
===
match
---
name: sha1 [39125,39129]
name: sha1 [39125,39129]
===
match
---
tfpdef [57501,57520]
tfpdef [57501,57520]
===
match
---
operator: , [86530,86531]
operator: , [86637,86638]
===
match
---
expr_stmt [59479,59495]
expr_stmt [59479,59495]
===
match
---
operator: , [45471,45472]
operator: , [45471,45472]
===
match
---
simple_stmt [80233,80275]
simple_stmt [80340,80382]
===
match
---
name: DeprecationWarning [73676,73694]
name: DeprecationWarning [73783,73801]
===
match
---
operator: = [32841,32842]
operator: = [32841,32842]
===
match
---
atom_expr [30293,30343]
atom_expr [30293,30343]
===
match
---
name: ti [92491,92493]
name: ti [92598,92600]
===
match
---
parameters [93531,93537]
parameters [93638,93644]
===
match
---
name: self [84930,84934]
name: self [85037,85041]
===
match
---
name: ti [92264,92266]
name: ti [92371,92373]
===
match
---
atom_expr [58158,58174]
atom_expr [58158,58174]
===
match
---
expr_stmt [5877,5889]
expr_stmt [5877,5889]
===
match
---
atom_expr [43336,43349]
atom_expr [43336,43349]
===
match
---
trailer [43379,43383]
trailer [43379,43383]
===
match
---
import_as_names [1965,2240]
import_as_names [1965,2240]
===
match
---
name: get [89224,89227]
name: get [89331,89334]
===
match
---
name: conf [79873,79877]
name: conf [79980,79984]
===
match
---
operator: = [34715,34716]
operator: = [34715,34716]
===
match
---
name: refresh_from_db [49480,49495]
name: refresh_from_db [49480,49495]
===
match
---
try_stmt [79449,79688]
try_stmt [79556,79795]
===
match
---
operator: = [43384,43385]
operator: = [43384,43385]
===
match
---
argument [13943,13974]
argument [13943,13974]
===
match
---
argument [8710,8722]
argument [8710,8722]
===
match
---
name: start_date [93132,93142]
name: start_date [93239,93249]
===
match
---
name: self [70794,70798]
name: self [70901,70905]
===
match
---
name: exception_html [82821,82835]
name: exception_html [82928,82942]
===
match
---
comparison [89760,89796]
comparison [89867,89903]
===
match
---
name: TaskInstance [91238,91250]
name: TaskInstance [91345,91357]
===
match
---
trailer [44770,44788]
trailer [44770,44788]
===
match
---
operator: = [36684,36685]
operator: = [36684,36685]
===
match
---
name: self [10136,10140]
name: self [10136,10140]
===
match
---
name: Log [46450,46453]
name: Log [46450,46453]
===
match
---
try_stmt [59664,59840]
try_stmt [59664,59840]
===
match
---
trailer [13042,13063]
trailer [13042,13063]
===
match
---
name: add [62697,62700]
name: add [62697,62700]
===
match
---
name: session [46663,46670]
name: session [46663,46670]
===
match
---
simple_stmt [1247,1305]
simple_stmt [1247,1305]
===
match
---
testlist_comp [22367,22390]
testlist_comp [22367,22390]
===
match
---
simple_stmt [52572,52592]
simple_stmt [52572,52592]
===
match
---
trailer [74186,74191]
trailer [74293,74298]
===
match
---
name: values_ordered_by_id [89192,89212]
name: values_ordered_by_id [89299,89319]
===
match
---
name: ID_LEN [2291,2297]
name: ID_LEN [2291,2297]
===
match
---
fstring [77284,77329]
fstring [77391,77436]
===
match
---
atom_expr [26479,26489]
atom_expr [26479,26489]
===
match
---
operator: = [52059,52060]
operator: = [52059,52060]
===
match
---
name: TR [44828,44830]
name: TR [44828,44830]
===
match
---
name: session [34522,34529]
name: session [34522,34529]
===
match
---
trailer [35826,35834]
trailer [35826,35834]
===
match
---
atom_expr [70863,70871]
atom_expr [70970,70978]
===
match
---
subscriptlist [59218,59232]
subscriptlist [59218,59232]
===
match
---
simple_stmt [24134,24403]
simple_stmt [24134,24403]
===
match
---
arglist [5060,5076]
arglist [5060,5076]
===
match
---
string: """Render k8s pod yaml""" [80337,80362]
string: """Render k8s pod yaml""" [80444,80469]
===
match
---
simple_stmt [33171,33419]
simple_stmt [33171,33419]
===
match
---
argument [79386,79401]
argument [79493,79508]
===
match
---
atom_expr [80772,80791]
atom_expr [80879,80898]
===
match
---
return_stmt [37886,37969]
return_stmt [37886,37969]
===
match
---
operator: = [49525,49526]
operator: = [49525,49526]
===
match
---
trailer [31047,31064]
trailer [31047,31064]
===
match
---
arglist [11393,11459]
arglist [11393,11459]
===
match
---
name: end_date [64222,64230]
name: end_date [64222,64230]
===
match
---
name: min_backoff [39473,39484]
name: min_backoff [39473,39484]
===
match
---
name: create_pod_id [80626,80639]
name: create_pod_id [80733,80746]
===
match
---
comp_op [60324,60330]
comp_op [60324,60330]
===
match
---
expr_stmt [30080,30096]
expr_stmt [30080,30096]
===
match
---
name: self [47539,47543]
name: self [47539,47543]
===
match
---
name: task_copy [56280,56289]
name: task_copy [56280,56289]
===
match
---
name: debug [37546,37551]
name: debug [37546,37551]
===
match
---
string: """Setting Next Try Number""" [17878,17907]
string: """Setting Next Try Number""" [17878,17907]
===
match
---
simple_stmt [41094,41104]
simple_stmt [41094,41104]
===
match
---
name: info [46261,46265]
name: info [46261,46265]
===
match
---
trailer [54545,54559]
trailer [54545,54559]
===
match
---
operator: = [11350,11351]
operator: = [11350,11351]
===
match
---
name: executor_config [27749,27764]
name: executor_config [27749,27764]
===
match
---
name: ti [92404,92406]
name: ti [92511,92513]
===
match
---
name: self [52045,52049]
name: self [52045,52049]
===
match
---
name: task_id [89049,89056]
name: task_id [89156,89163]
===
match
---
operator: , [86742,86743]
operator: , [86849,86850]
===
match
---
trailer [83252,83264]
trailer [83359,83371]
===
match
---
with_item [83982,83997]
with_item [84089,84104]
===
match
---
name: run_id [7769,7775]
name: run_id [7769,7775]
===
match
---
if_stmt [18622,18757]
if_stmt [18622,18757]
===
match
---
trailer [67693,67725]
trailer [67800,67832]
===
match
---
name: task [65474,65478]
name: task [65581,65585]
===
match
---
name: run_id [77178,77184]
name: run_id [77285,77291]
===
match
---
string: """         Clears all XCom data from the database for the task instance          :param session: SQLAlchemy ORM Session         :type session: Session         """ [27879,28042]
string: """         Clears all XCom data from the database for the task instance          :param session: SQLAlchemy ORM Session         :type session: Session         """ [27879,28042]
===
match
---
name: self [40356,40360]
name: self [40356,40360]
===
match
---
name: lock_for_update [50615,50630]
name: lock_for_update [50615,50630]
===
match
---
name: execution_date [72900,72914]
name: execution_date [73007,73021]
===
match
---
arglist [13079,13106]
arglist [13079,13106]
===
match
---
name: Optional [30704,30712]
name: Optional [30704,30712]
===
match
---
decorated [23769,24510]
decorated [23769,24510]
===
match
---
raise_stmt [55859,55919]
raise_stmt [55859,55919]
===
match
---
atom_expr [89153,89163]
atom_expr [89260,89270]
===
match
---
simple_stmt [84628,84679]
simple_stmt [84735,84786]
===
match
---
name: _CURRENT_CONTEXT [3806,3822]
name: _CURRENT_CONTEXT [3806,3822]
===
match
---
operator: = [69734,69735]
operator: = [69841,69842]
===
match
---
atom_expr [28918,28928]
atom_expr [28918,28928]
===
match
---
parameters [93142,93148]
parameters [93249,93255]
===
match
---
atom_expr [54958,54971]
atom_expr [54958,54971]
===
match
---
name: get_previous_scheduled_dagrun [32182,32211]
name: get_previous_scheduled_dagrun [32182,32211]
===
match
---
atom_expr [48741,48755]
atom_expr [48741,48755]
===
match
---
name: self [48884,48888]
name: self [48884,48888]
===
match
---
name: error [62070,62075]
name: error [62070,62075]
===
match
---
argument [75558,75578]
argument [75665,75685]
===
match
---
name: macros [67261,67267]
name: macros [67368,67374]
===
match
---
trailer [14374,14384]
trailer [14374,14384]
===
match
---
dotted_name [2584,2603]
dotted_name [2584,2603]
===
match
---
name: set_error_file [64081,64095]
name: set_error_file [64081,64095]
===
match
---
operator: , [77475,77476]
operator: , [77582,77583]
===
match
---
name: method_name [58028,58039]
name: method_name [58028,58039]
===
match
---
name: self [93143,93147]
name: self [93250,93254]
===
match
---
name: utils [3217,3222]
name: utils [3217,3222]
===
match
---
atom_expr [64565,64578]
atom_expr [64672,64685]
===
match
---
operator: , [67707,67708]
operator: , [67814,67815]
===
match
---
fstring_start: f' [54708,54710]
fstring_start: f' [54708,54710]
===
match
---
name: self [28127,28131]
name: self [28127,28131]
===
match
---
operator: = [53041,53042]
operator: = [53041,53042]
===
match
---
operator: , [49751,49752]
operator: , [49751,49752]
===
match
---
simple_stmt [11928,11962]
simple_stmt [11928,11962]
===
match
---
name: result [89081,89087]
name: result [89188,89194]
===
match
---
arglist [53108,53133]
arglist [53108,53133]
===
match
---
atom_expr [22971,23007]
atom_expr [22971,23007]
===
match
---
simple_stmt [79599,79688]
simple_stmt [79706,79795]
===
match
---
operator: , [22924,22925]
operator: , [22924,22925]
===
match
---
operator: , [53382,53383]
operator: , [53382,53383]
===
match
---
expr_stmt [26007,26028]
expr_stmt [26007,26028]
===
match
---
name: self [53583,53587]
name: self [53583,53587]
===
match
---
atom_expr [69175,69202]
atom_expr [69282,69309]
===
match
---
annassign [92847,92863]
annassign [92954,92970]
===
match
---
trailer [27704,27712]
trailer [27704,27712]
===
match
---
trailer [65677,65689]
trailer [65784,65796]
===
match
---
name: task_copy [56686,56695]
name: task_copy [56686,56695]
===
match
---
operator: + [46327,46328]
operator: + [46327,46328]
===
match
---
trailer [72569,72586]
trailer [72676,72693]
===
match
---
trailer [61096,61136]
trailer [61096,61136]
===
match
---
name: is_absolute [19061,19072]
name: is_absolute [19061,19072]
===
match
---
name: ti [6557,6559]
name: ti [6557,6559]
===
match
---
name: dep [37470,37473]
name: dep [37470,37473]
===
match
---
trailer [22799,22817]
trailer [22799,22817]
===
match
---
if_stmt [25814,27025]
if_stmt [25814,27025]
===
match
---
atom_expr [60223,60233]
atom_expr [60223,60233]
===
match
---
operator: - [10186,10187]
operator: - [10186,10187]
===
match
---
name: TaskDeferred [2227,2239]
name: TaskDeferred [2227,2239]
===
match
---
operator: = [34131,34132]
operator: = [34131,34132]
===
match
---
trailer [30965,30969]
trailer [30965,30969]
===
match
---
simple_stmt [51700,51706]
simple_stmt [51700,51706]
===
match
---
atom_expr [72895,72914]
atom_expr [73002,73021]
===
match
---
operator: ** [83397,83399]
operator: ** [83504,83506]
===
match
---
name: self [63240,63244]
name: self [63240,63244]
===
match
---
name: provide_session [85081,85096]
name: provide_session [85188,85203]
===
match
---
operator: = [41593,41594]
operator: = [41593,41594]
===
match
---
name: Float [11555,11560]
name: Float [11555,11560]
===
match
---
operator: = [60361,60362]
operator: = [60361,60362]
===
match
---
name: email_alert [84422,84433]
name: email_alert [84529,84540]
===
match
---
arglist [76889,76925]
arglist [76996,77032]
===
match
---
arith_expr [56563,56598]
arith_expr [56563,56598]
===
match
---
suite [78424,78573]
suite [78531,78680]
===
match
---
trailer [11748,11754]
trailer [11748,11754]
===
match
---
simple_stmt [68705,68766]
simple_stmt [68812,68873]
===
match
---
string: """     Simplified Task Instance.      Used to send data between processes via Queues.     """ [92015,92109]
string: """     Simplified Task Instance.      Used to send data between processes via Queues.     """ [92122,92216]
===
match
---
operator: , [28895,28896]
operator: , [28895,28896]
===
match
---
name: self [25397,25401]
name: self [25397,25401]
===
match
---
atom_expr [33434,33456]
atom_expr [33434,33456]
===
match
---
trailer [24351,24358]
trailer [24351,24358]
===
match
---
trailer [82729,82736]
trailer [82836,82843]
===
match
---
name: __repr__ [69930,69938]
name: __repr__ [70037,70045]
===
match
---
trailer [79379,79402]
trailer [79486,79509]
===
match
---
name: commit [63223,63229]
name: commit [63223,63229]
===
match
---
name: params [67357,67363]
name: params [67464,67470]
===
match
---
name: self [24294,24298]
name: self [24294,24298]
===
match
---
suite [29071,29208]
suite [29071,29208]
===
match
---
simple_stmt [79991,80019]
simple_stmt [80098,80126]
===
match
---
parameters [52305,52320]
parameters [52305,52320]
===
match
---
name: session [79386,79393]
name: session [79493,79500]
===
match
---
name: AirflowFailException [1987,2007]
name: AirflowFailException [1987,2007]
===
match
---
suite [82522,83414]
suite [82629,83521]
===
match
---
name: self [67323,67327]
name: self [67430,67434]
===
match
---
simple_stmt [74098,74141]
simple_stmt [74205,74248]
===
match
---
name: v [53428,53429]
name: v [53428,53429]
===
match
---
name: first [89367,89372]
name: first [89474,89479]
===
match
---
name: operator [11966,11974]
name: operator [11966,11974]
===
match
---
operator: = [70764,70765]
operator: = [70871,70872]
===
match
---
name: count [30196,30201]
name: count [30196,30201]
===
match
---
atom_expr [30202,30222]
atom_expr [30202,30222]
===
match
---
name: subject [84656,84663]
name: subject [84763,84770]
===
match
---
name: self [23295,23299]
name: self [23295,23299]
===
match
---
name: ignore_task_deps [18051,18067]
name: ignore_task_deps [18051,18067]
===
match
---
operator: , [54567,54568]
operator: , [54567,54568]
===
match
---
string: '' [16110,16112]
string: '' [16110,16112]
===
match
---
arglist [11312,11336]
arglist [11312,11336]
===
match
---
atom_expr [83006,83130]
atom_expr [83113,83237]
===
match
---
trailer [59115,59157]
trailer [59115,59157]
===
match
---
expr_stmt [18485,18514]
expr_stmt [18485,18514]
===
match
---
simple_stmt [11537,11562]
simple_stmt [11537,11562]
===
match
---
expr_stmt [53858,53876]
expr_stmt [53858,53876]
===
match
---
name: self [54633,54637]
name: self [54633,54637]
===
match
---
trailer [49551,49557]
trailer [49551,49557]
===
match
---
name: uselist [13860,13867]
name: uselist [13860,13867]
===
match
---
atom_expr [47641,47674]
atom_expr [47641,47674]
===
match
---
name: self [28201,28205]
name: self [28201,28205]
===
match
---
simple_stmt [70165,70198]
simple_stmt [70272,70305]
===
match
---
name: pickle [5296,5302]
name: pickle [5296,5302]
===
match
---
name: next_kwargs [56084,56095]
name: next_kwargs [56084,56095]
===
match
---
name: self [50594,50598]
name: self [50594,50598]
===
match
---
simple_stmt [28439,28519]
simple_stmt [28439,28519]
===
match
---
trailer [81190,81192]
trailer [81297,81299]
===
match
---
name: self [50188,50192]
name: self [50188,50192]
===
match
---
name: TaskDeferralError [55865,55882]
name: TaskDeferralError [55865,55882]
===
match
---
name: self [46040,46044]
name: self [46040,46044]
===
match
---
simple_stmt [12766,13492]
simple_stmt [12766,13492]
===
match
---
operator: , [75999,76000]
operator: , [76106,76107]
===
match
---
trailer [29057,29070]
trailer [29057,29070]
===
match
---
expr_stmt [11597,11651]
expr_stmt [11597,11651]
===
match
---
simple_stmt [74074,74086]
simple_stmt [74181,74193]
===
match
---
suite [91413,91686]
suite [91520,91793]
===
match
---
trailer [46348,46353]
trailer [46348,46353]
===
match
---
tfpdef [41534,41569]
tfpdef [41534,41569]
===
match
---
name: incr [43498,43502]
name: incr [43498,43502]
===
match
---
operator: = [61423,61424]
operator: = [61423,61424]
===
match
---
if_stmt [64050,64115]
if_stmt [64050,64115]
===
match
---
name: get_template_context [80201,80221]
name: get_template_context [80308,80328]
===
match
---
name: pod_template_file [81087,81104]
name: pod_template_file [81194,81211]
===
match
---
expr_stmt [68039,68091]
expr_stmt [68146,68198]
===
match
---
trailer [92337,92347]
trailer [92444,92454]
===
match
---
string: """For API-compatibly with TaskInstance.          Returns self         """ [10475,10549]
string: """For API-compatibly with TaskInstance.          Returns self         """ [10475,10549]
===
match
---
simple_stmt [40826,40926]
simple_stmt [40826,40926]
===
match
---
trailer [9041,9045]
trailer [9041,9045]
===
match
---
decorated [93114,93194]
decorated [93221,93301]
===
match
---
name: last_scheduling_decision [9535,9559]
name: last_scheduling_decision [9535,9559]
===
match
---
if_stmt [74786,74841]
if_stmt [74893,74948]
===
match
---
string: 'Failed to send email to: %s' [66034,66063]
string: 'Failed to send email to: %s' [66141,66170]
===
match
---
return_stmt [68820,68831]
return_stmt [68927,68938]
===
match
---
name: var [70799,70802]
name: var [70906,70909]
===
match
---
expr_stmt [23112,23156]
expr_stmt [23112,23156]
===
match
---
name: self [40170,40174]
name: self [40170,40174]
===
match
---
name: BaseJob [93968,93975]
name: BaseJob [94075,94082]
===
match
---
name: task_id [32947,32954]
name: task_id [32947,32954]
===
match
---
simple_stmt [28945,28995]
simple_stmt [28945,28995]
===
match
---
atom_expr [56510,56633]
atom_expr [56510,56633]
===
match
---
name: quote [23118,23123]
name: quote [23118,23123]
===
match
---
operator: + [45953,45954]
operator: + [45953,45954]
===
match
---
parameters [41173,41605]
parameters [41173,41605]
===
match
---
argument [28120,28138]
argument [28120,28138]
===
match
---
operator: = [28200,28201]
operator: = [28200,28201]
===
match
---
atom_expr [6513,6525]
atom_expr [6513,6525]
===
match
---
atom_expr [6993,7003]
atom_expr [6993,7003]
===
match
---
expr_stmt [93981,94031]
expr_stmt [94088,94138]
===
match
---
operator: , [18246,18247]
operator: , [18246,18247]
===
match
---
name: self [16316,16320]
name: self [16316,16320]
===
match
---
atom_expr [54945,54955]
atom_expr [54945,54955]
===
match
---
name: extend [22359,22365]
name: extend [22359,22365]
===
match
---
name: elements [1735,1743]
name: elements [1735,1743]
===
match
---
name: path [19056,19060]
name: path [19056,19060]
===
match
---
simple_stmt [29287,29403]
simple_stmt [29287,29403]
===
match
---
name: first [25755,25760]
name: first [25755,25760]
===
match
---
number: 1 [54756,54757]
number: 1 [54756,54757]
===
match
---
name: retries [66849,66856]
name: retries [66956,66963]
===
match
---
tfpdef [30660,30686]
tfpdef [30660,30686]
===
match
---
name: create_session [3348,3362]
name: create_session [3348,3362]
===
match
---
fstring_start: f' [49127,49129]
fstring_start: f' [49127,49129]
===
match
---
expr_stmt [25927,25954]
expr_stmt [25927,25954]
===
match
---
operator: = [80771,80772]
operator: = [80878,80879]
===
match
---
name: _set_context [90013,90025]
name: _set_context [90120,90132]
===
match
---
comp_op [14447,14453]
comp_op [14447,14453]
===
match
---
annassign [92212,92230]
annassign [92319,92337]
===
match
---
name: has_dag [15215,15222]
name: has_dag [15215,15222]
===
match
---
name: State [54958,54963]
name: State [54958,54963]
===
match
---
decorator [35267,35277]
decorator [35267,35277]
===
match
---
name: self [9792,9796]
name: self [9792,9796]
===
match
---
funcdef [72728,72821]
funcdef [72835,72928]
===
match
---
name: e [50292,50293]
name: e [50292,50293]
===
match
---
expr_stmt [89192,89261]
expr_stmt [89299,89368]
===
match
---
name: TaskInstance [25617,25629]
name: TaskInstance [25617,25629]
===
match
---
string: """             Wrapper around Connection. This way you can get connections in             templates by using ``{{ conn.conn_id }}`` or             ``{{ conn.get('conn_id') }}``.             """ [71250,71444]
string: """             Wrapper around Connection. This way you can get connections in             templates by using ``{{ conn.conn_id }}`` or             ``{{ conn.get('conn_id') }}``.             """ [71357,71551]
===
match
---
name: Column [11904,11910]
name: Column [11904,11910]
===
match
---
trailer [89062,89080]
trailer [89169,89187]
===
match
---
trailer [50130,50134]
trailer [50130,50134]
===
match
---
trailer [15475,15491]
trailer [15475,15491]
===
match
---
raise_stmt [56886,56912]
raise_stmt [56886,56912]
===
match
---
suite [55602,56178]
suite [55602,56178]
===
match
---
arglist [61680,61876]
arglist [61680,61876]
===
match
---
string: "tasks" [22140,22147]
string: "tasks" [22140,22147]
===
match
---
trailer [16389,16399]
trailer [16389,16399]
===
match
---
atom_expr [7726,8017]
atom_expr [7726,8017]
===
match
---
name: pool [47931,47935]
name: pool [47931,47935]
===
match
---
simple_stmt [38540,38623]
simple_stmt [38540,38623]
===
match
---
argument [70748,70769]
argument [70855,70876]
===
match
---
parameters [57485,57521]
parameters [57485,57521]
===
match
---
atom_expr [57372,57421]
atom_expr [57372,57421]
===
match
---
trailer [68130,68139]
trailer [68237,68246]
===
match
---
name: get_yesterday_ds_nodash [77996,78019]
name: get_yesterday_ds_nodash [78103,78126]
===
match
---
operator: , [45308,45309]
operator: , [45308,45309]
===
match
---
atom_expr [43147,43195]
atom_expr [43147,43195]
===
match
---
name: self [26282,26286]
name: self [26282,26286]
===
match
---
operator: = [23405,23406]
operator: = [23405,23406]
===
match
---
name: self [26322,26326]
name: self [26322,26326]
===
match
---
return_stmt [29468,29538]
return_stmt [29468,29538]
===
match
---
name: t [91275,91276]
name: t [91382,91383]
===
match
---
operator: ** [83199,83201]
operator: ** [83306,83308]
===
match
---
trailer [85950,85965]
trailer [86057,86072]
===
match
---
name: format [39165,39171]
name: format [39165,39171]
===
match
---
name: trigger_timeout [58649,58664]
name: trigger_timeout [58649,58664]
===
match
---
name: email [84738,84743]
name: email [84845,84850]
===
match
---
expr_stmt [44942,44986]
expr_stmt [44942,44986]
===
match
---
string: """         Call callback defined for finished state change.          NOTE: Only invoke this function from caller of self._run_raw_task or         self.run         """ [59260,59427]
string: """         Call callback defined for finished state change.          NOTE: Only invoke this function from caller of self._run_raw_task or         self.run         """ [59260,59427]
===
match
---
name: exception [81295,81304]
name: exception [81402,81411]
===
match
---
name: error [63866,63871]
name: error [63866,63871]
===
match
---
trailer [69870,69874]
trailer [69977,69981]
===
match
---
trailer [47609,47627]
trailer [47609,47627]
===
match
---
name: str [86645,86648]
name: str [86752,86755]
===
match
---
trailer [30423,30427]
trailer [30423,30427]
===
match
---
name: replace [67974,67981]
name: replace [68081,68088]
===
match
---
name: key [72211,72214]
name: key [72318,72321]
===
match
---
operator: @ [66169,66170]
operator: @ [66276,66277]
===
match
---
name: pool_slots [27562,27572]
name: pool_slots [27562,27572]
===
match
---
name: TaskInstanceKey [90110,90125]
name: TaskInstanceKey [90217,90232]
===
match
---
name: filter [8389,8395]
name: filter [8389,8395]
===
match
---
simple_stmt [27539,27573]
simple_stmt [27539,27573]
===
match
---
operator: , [50635,50636]
operator: , [50635,50636]
===
match
---
comparison [88404,88418]
comparison [88511,88525]
===
match
---
operator: , [47525,47526]
operator: , [47525,47526]
===
match
---
name: _log_state [65803,65813]
name: _log_state [65910,65920]
===
match
---
operator: = [18067,18068]
operator: = [18067,18068]
===
match
---
simple_stmt [32556,32785]
simple_stmt [32556,32785]
===
match
---
atom_expr [92872,92881]
atom_expr [92979,92988]
===
match
---
decorated [93360,93425]
decorated [93467,93532]
===
match
---
name: qry [25733,25736]
name: qry [25733,25736]
===
match
---
trailer [18993,19010]
trailer [18993,19010]
===
match
---
operator: , [13989,13990]
operator: , [13989,13990]
===
match
---
param [66326,66351]
param [66433,66458]
===
match
---
param [84440,84449]
param [84547,84556]
===
match
---
name: verbose [46840,46847]
name: verbose [46840,46847]
===
match
---
argument [13689,13702]
argument [13689,13702]
===
match
---
trailer [63160,63172]
trailer [63160,63172]
===
match
---
trailer [15598,15613]
trailer [15598,15613]
===
match
---
argument [48810,48828]
argument [48810,48828]
===
match
---
operator: , [47550,47551]
operator: , [47550,47551]
===
match
---
operator: , [79384,79385]
operator: , [79491,79492]
===
match
---
simple_stmt [84519,84603]
simple_stmt [84626,84710]
===
match
---
name: run_id [90982,90988]
name: run_id [91089,91095]
===
match
---
operator: = [51834,51835]
operator: = [51834,51835]
===
match
---
trailer [45697,45701]
trailer [45697,45701]
===
match
---
atom_expr [27721,27741]
atom_expr [27721,27741]
===
match
---
name: ExtendedJSON [12619,12631]
name: ExtendedJSON [12619,12631]
===
match
---
return_stmt [33947,33995]
return_stmt [33947,33995]
===
match
---
trailer [28100,28106]
trailer [28100,28106]
===
match
---
name: ParamsDict [67366,67376]
name: ParamsDict [67473,67483]
===
match
---
operator: , [63805,63806]
operator: , [63805,63806]
===
match
---
name: ds [74296,74298]
name: ds [74403,74405]
===
match
---
trailer [27777,27786]
trailer [27777,27786]
===
match
---
trailer [10140,10148]
trailer [10140,10148]
===
match
---
param [27111,27116]
param [27111,27116]
===
match
---
name: dep_context [2781,2792]
name: dep_context [2781,2792]
===
match
---
trailer [44975,44986]
trailer [44975,44986]
===
match
---
string: """Run TaskInstance""" [61055,61077]
string: """Run TaskInstance""" [61055,61077]
===
match
---
trailer [26326,26335]
trailer [26326,26335]
===
match
---
operator: , [36809,36810]
operator: , [36809,36810]
===
match
---
atom_expr [14956,14993]
atom_expr [14956,14993]
===
match
---
string: 'html_content_template' [84306,84329]
string: 'html_content_template' [84413,84436]
===
match
---
atom_expr [26536,26554]
atom_expr [26536,26554]
===
match
---
name: Context [3829,3836]
name: Context [3829,3836]
===
match
---
name: property [93043,93051]
name: property [93150,93158]
===
match
---
trailer [62168,62173]
trailer [62168,62173]
===
match
---
trailer [89138,89164]
trailer [89245,89271]
===
match
---
and_test [66839,66894]
and_test [66946,67001]
===
match
---
trailer [37944,37951]
trailer [37944,37951]
===
match
---
name: e [79580,79581]
name: e [79687,79688]
===
match
---
name: get_templated_fields [78339,78359]
name: get_templated_fields [78446,78466]
===
match
---
operator: = [39447,39448]
operator: = [39447,39448]
===
match
---
atom_expr [93802,93823]
atom_expr [93909,93930]
===
match
---
name: self [28897,28901]
name: self [28897,28901]
===
match
---
simple_stmt [2388,2432]
simple_stmt [2388,2432]
===
match
---
name: ignore_all_deps [61195,61210]
name: ignore_all_deps [61195,61210]
===
match
---
trailer [75254,75272]
trailer [75361,75379]
===
match
---
name: ti [6982,6984]
name: ti [6982,6984]
===
match
---
operator: = [62241,62242]
operator: = [62241,62242]
===
match
---
atom_expr [74748,74773]
atom_expr [74855,74880]
===
match
---
trailer [39099,39363]
trailer [39099,39363]
===
match
---
trailer [22739,22746]
trailer [22739,22746]
===
match
---
arglist [81598,81610]
arglist [81705,81717]
===
match
---
operator: , [88725,88726]
operator: , [88832,88833]
===
match
---
name: ext [1503,1506]
name: ext [1503,1506]
===
match
---
atom_expr [76530,76574]
atom_expr [76637,76681]
===
match
---
simple_stmt [67313,67348]
simple_stmt [67420,67455]
===
match
---
funcdef [72127,72526]
funcdef [72234,72633]
===
match
---
name: value [86299,86304]
name: value [86406,86411]
===
match
---
name: integrate_macros_plugins [2669,2693]
name: integrate_macros_plugins [2669,2693]
===
match
---
arglist [85033,85073]
arglist [85140,85180]
===
match
---
param [19844,19871]
param [19844,19871]
===
match
---
name: exception_html [83603,83617]
name: exception_html [83710,83724]
===
match
---
name: min [58667,58670]
name: min [58667,58670]
===
match
---
name: dagrun [8874,8880]
name: dagrun [8874,8880]
===
match
---
name: RUNNING_DEPS [2875,2887]
name: RUNNING_DEPS [2875,2887]
===
match
---
string: """Get Airflow Variable value""" [70165,70197]
string: """Get Airflow Variable value""" [70272,70304]
===
match
---
operator: = [41518,41519]
operator: = [41518,41519]
===
match
---
simple_stmt [1715,1769]
simple_stmt [1715,1769]
===
match
---
operator: , [63732,63733]
operator: , [63732,63733]
===
match
---
and_test [18625,18676]
and_test [18625,18676]
===
match
---
name: Optional [74178,74186]
name: Optional [74285,74293]
===
match
---
atom_expr [89643,89886]
atom_expr [89750,89993]
===
match
---
trailer [40127,40136]
trailer [40127,40136]
===
match
---
number: 1 [72694,72695]
number: 1 [72801,72802]
===
match
---
operator: , [75363,75364]
operator: , [75470,75471]
===
match
---
operator: , [50835,50836]
operator: , [50835,50836]
===
match
---
atom_expr [47539,47550]
atom_expr [47539,47550]
===
match
---
string: """Return task instance primary key part of the key""" [9831,9885]
string: """Return task instance primary key part of the key""" [9831,9885]
===
match
---
argument [44101,44134]
argument [44101,44134]
===
match
---
fstring [51931,51995]
fstring [51931,51995]
===
match
---
name: State [51505,51510]
name: State [51505,51510]
===
match
---
trailer [61662,61890]
trailer [61662,61890]
===
match
---
atom_expr [9176,9233]
atom_expr [9176,9233]
===
match
---
name: self [79891,79895]
name: self [79998,80002]
===
match
---
name: bool [60922,60926]
name: bool [60922,60926]
===
match
---
suite [46848,47074]
suite [46848,47074]
===
match
---
parameters [14093,14211]
parameters [14093,14211]
===
match
---
simple_stmt [4884,4923]
simple_stmt [4884,4923]
===
match
---
simple_stmt [14551,14845]
simple_stmt [14551,14845]
===
match
---
name: refresh_from_db [43244,43259]
name: refresh_from_db [43244,43259]
===
match
---
param [20073,20105]
param [20073,20105]
===
match
---
name: suppress_exception [67377,67395]
name: suppress_exception [67484,67502]
===
match
---
name: cfg_path [22949,22957]
name: cfg_path [22949,22957]
===
match
---
operator: , [51731,51732]
operator: , [51731,51732]
===
match
---
suite [93322,93355]
suite [93429,93462]
===
match
---
simple_stmt [52251,52268]
simple_stmt [52251,52268]
===
match
---
operator: = [19145,19146]
operator: = [19145,19146]
===
match
---
atom_expr [83049,83099]
atom_expr [83156,83206]
===
match
---
simple_stmt [71831,71883]
simple_stmt [71938,71990]
===
match
---
trailer [4742,4751]
trailer [4742,4751]
===
match
---
arglist [12799,12828]
arglist [12799,12828]
===
match
---
name: self [49158,49162]
name: self [49158,49162]
===
match
---
atom_expr [66148,66163]
atom_expr [66255,66270]
===
match
---
operator: = [24559,24560]
operator: = [24559,24560]
===
match
---
trailer [72930,72939]
trailer [73037,73046]
===
match
---
name: foreign_keys [13827,13839]
name: foreign_keys [13827,13839]
===
match
---
name: exc_info [54218,54226]
name: exc_info [54218,54226]
===
match
---
name: run_id [9055,9061]
name: run_id [9055,9061]
===
match
---
operator: , [89796,89797]
operator: , [89903,89904]
===
match
---
atom_expr [67806,67841]
atom_expr [67913,67948]
===
match
---
expr_stmt [67735,67792]
expr_stmt [67842,67899]
===
match
---
name: Trigger [57757,57764]
name: Trigger [57757,57764]
===
match
---
trailer [62550,62566]
trailer [62550,62566]
===
match
---
trailer [19245,19253]
trailer [19245,19253]
===
match
---
simple_stmt [54532,54580]
simple_stmt [54532,54580]
===
match
---
simple_stmt [23016,23027]
simple_stmt [23016,23027]
===
match
---
if_stmt [17074,17142]
if_stmt [17074,17142]
===
match
---
string: 'tomorrow_ds' [77461,77474]
string: 'tomorrow_ds' [77568,77581]
===
match
---
suite [66103,66164]
suite [66210,66271]
===
match
---
name: trigger_id [13840,13850]
name: trigger_id [13840,13850]
===
match
---
name: Column [12123,12129]
name: Column [12123,12129]
===
match
---
string: 'prev_ds_nodash' [76588,76604]
string: 'prev_ds_nodash' [76695,76711]
===
match
---
name: Exception [63734,63743]
name: Exception [63734,63743]
===
match
---
operator: = [86275,86276]
operator: = [86382,86383]
===
match
---
operator: , [80955,80956]
operator: , [81062,81063]
===
match
---
operator: <= [56860,56862]
operator: <= [56860,56862]
===
match
---
name: List [3824,3828]
name: List [3824,3828]
===
match
---
trailer [48941,48943]
trailer [48941,48943]
===
match
---
comparison [15763,15777]
comparison [15763,15777]
===
match
---
trailer [69908,69912]
trailer [70015,70019]
===
match
---
atom_expr [11210,11284]
atom_expr [11210,11284]
===
match
---
string: 'conn' [77830,77836]
string: 'conn' [77937,77943]
===
match
---
operator: , [57490,57491]
operator: , [57490,57491]
===
match
---
suite [25820,26981]
suite [25820,26981]
===
match
---
arglist [66034,66075]
arglist [66141,66182]
===
match
---
name: first [90506,90511]
name: first [90613,90618]
===
match
---
name: FAILED [64437,64443]
name: FAILED [64437,64443]
===
match
---
simple_stmt [47006,47074]
simple_stmt [47006,47074]
===
match
---
decorator [16413,16428]
decorator [16413,16428]
===
match
---
name: Optional [63504,63512]
name: Optional [63504,63512]
===
match
---
operator: % [39471,39472]
operator: % [39471,39472]
===
match
---
expr_stmt [11163,11194]
expr_stmt [11163,11194]
===
match
---
string: 'next_ds_nodash' [75830,75846]
string: 'next_ds_nodash' [75937,75953]
===
match
---
string: 'TaskInstance' [33518,33532]
string: 'TaskInstance' [33518,33532]
===
match
---
name: in_ [8407,8410]
name: in_ [8407,8410]
===
match
---
name: task [84644,84648]
name: task [84751,84755]
===
match
---
name: dag_id [91739,91745]
name: dag_id [91846,91852]
===
match
---
name: self [80653,80657]
name: self [80760,80764]
===
match
---
param [47810,47815]
param [47810,47815]
===
match
---
trailer [91314,91322]
trailer [91421,91429]
===
match
---
parameters [28558,28590]
parameters [28558,28590]
===
match
---
name: path [83927,83931]
name: path [84034,84038]
===
match
---
lambdef [5943,5967]
lambdef [5943,5967]
===
match
---
operator: = [56508,56509]
operator: = [56508,56509]
===
match
---
subscriptlist [4621,4635]
subscriptlist [4621,4635]
===
match
---
operator: = [19902,19903]
operator: = [19902,19903]
===
match
---
atom_expr [16316,16324]
atom_expr [16316,16324]
===
match
---
funcdef [62082,62314]
funcdef [62082,62314]
===
match
---
name: self [48799,48803]
name: self [48799,48803]
===
match
---
atom_expr [8396,8419]
atom_expr [8396,8419]
===
match
---
arglist [10360,10410]
arglist [10360,10410]
===
match
---
string: 'CASCADE' [13264,13273]
string: 'CASCADE' [13264,13273]
===
match
---
name: raw [19620,19623]
name: raw [19620,19623]
===
match
---
name: cmd [23023,23026]
name: cmd [23023,23026]
===
match
---
name: Column [12612,12618]
name: Column [12612,12618]
===
match
---
name: session [34114,34121]
name: session [34114,34121]
===
match
---
dotted_name [52376,52407]
dotted_name [52376,52407]
===
match
---
expr_stmt [36663,36730]
expr_stmt [36663,36730]
===
match
---
name: warning [15020,15027]
name: warning [15020,15027]
===
match
---
trailer [83075,83080]
trailer [83182,83187]
===
match
---
argument [32292,32307]
argument [32292,32307]
===
match
---
simple_stmt [23165,23210]
simple_stmt [23165,23210]
===
match
---
name: __getattr__ [70625,70636]
name: __getattr__ [70732,70743]
===
match
---
simple_stmt [90008,90032]
simple_stmt [90115,90139]
===
match
---
name: bool [19943,19947]
name: bool [19943,19947]
===
match
---
name: task [27658,27662]
name: task [27658,27662]
===
match
---
name: variable [2554,2562]
name: variable [2554,2562]
===
match
---
name: pid [26723,26726]
name: pid [26723,26726]
===
match
---
name: get [70230,70233]
name: get [70337,70340]
===
match
---
suite [22420,22475]
suite [22420,22475]
===
match
---
name: update [79998,80004]
name: update [80105,80111]
===
match
---
name: ignore_all_deps [45277,45292]
name: ignore_all_deps [45277,45292]
===
match
---
operator: , [62938,62939]
operator: , [62938,62939]
===
match
---
simple_stmt [16011,16037]
simple_stmt [16011,16037]
===
match
---
number: 1 [17176,17177]
number: 1 [17176,17177]
===
match
---
name: or_ [7701,7704]
name: or_ [7701,7704]
===
match
---
trailer [25760,25762]
trailer [25760,25762]
===
match
---
name: self [58280,58284]
name: self [58280,58284]
===
match
---
expr_stmt [69216,69255]
expr_stmt [69323,69362]
===
match
---
trailer [15716,15723]
trailer [15716,15723]
===
match
---
atom_expr [52905,52943]
atom_expr [52905,52943]
===
match
---
expr_stmt [29084,29129]
expr_stmt [29084,29129]
===
match
---
operator: , [45956,45957]
operator: , [45956,45957]
===
match
---
operator: = [49088,49089]
operator: = [49088,49089]
===
match
---
name: self [29006,29010]
name: self [29006,29010]
===
match
---
operator: , [35759,35760]
operator: , [35759,35760]
===
match
---
atom_expr [74435,74480]
atom_expr [74542,74587]
===
match
---
name: trigger_id [57967,57977]
name: trigger_id [57967,57977]
===
match
---
trailer [24200,24373]
trailer [24200,24373]
===
match
---
trailer [47019,47073]
trailer [47019,47073]
===
match
---
operator: , [61361,61362]
operator: , [61361,61362]
===
match
---
string: 'var' [77701,77706]
string: 'var' [77808,77813]
===
match
---
name: State [51490,51495]
name: State [51490,51495]
===
match
---
expr_stmt [43204,43230]
expr_stmt [43204,43230]
===
match
---
trailer [70229,70233]
trailer [70336,70340]
===
match
---
trailer [65402,65404]
trailer [65509,65511]
===
match
---
trailer [6289,6300]
trailer [6289,6300]
===
match
---
operator: } [23623,23624]
operator: } [23623,23624]
===
match
---
operator: -> [48029,48031]
operator: -> [48029,48031]
===
match
---
return_stmt [75057,75088]
return_stmt [75164,75195]
===
match
---
trailer [46523,46544]
trailer [46523,46544]
===
match
---
operator: = [51192,51193]
operator: = [51192,51193]
===
match
---
if_stmt [53733,54437]
if_stmt [53733,54437]
===
match
---
if_stmt [40016,40108]
if_stmt [40016,40108]
===
match
---
expr_stmt [9741,9760]
expr_stmt [9741,9760]
===
match
---
string: "dag_run.dag_id" [13359,13375]
string: "dag_run.dag_id" [13359,13375]
===
match
---
name: property [33463,33471]
name: property [33463,33471]
===
match
---
arglist [91480,91623]
arglist [91587,91730]
===
match
---
trailer [68264,68274]
trailer [68371,68381]
===
match
---
import_name [835,846]
import_name [835,846]
===
match
---
import_name [847,856]
import_name [847,856]
===
match
---
import_from [3314,3379]
import_from [3314,3379]
===
match
---
name: DateTime [68942,68950]
name: DateTime [69049,69057]
===
match
---
name: command_as_list [80815,80830]
name: command_as_list [80922,80937]
===
match
---
if_stmt [16045,16086]
if_stmt [16045,16086]
===
match
---
simple_stmt [25883,25915]
simple_stmt [25883,25915]
===
match
---
atom_expr [37405,37421]
atom_expr [37405,37421]
===
match
---
name: end_date [64570,64578]
name: end_date [64677,64685]
===
match
---
name: start_date [58676,58686]
name: start_date [58676,58686]
===
match
---
name: session [51642,51649]
name: session [51642,51649]
===
match
---
name: force_fail [63458,63468]
name: force_fail [63458,63468]
===
match
---
trailer [57764,57776]
trailer [57764,57776]
===
match
---
operator: , [2297,2298]
operator: , [2297,2298]
===
match
---
string: """             This attribute is deprecated.             Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.             """ [33718,33869]
string: """             This attribute is deprecated.             Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.             """ [33718,33869]
===
match
---
name: task [37429,37433]
name: task [37429,37433]
===
match
---
operator: , [76908,76909]
operator: , [77015,77016]
===
match
---
name: state [24504,24509]
name: state [24504,24509]
===
match
---
atom_expr [53243,53299]
atom_expr [53243,53299]
===
match
---
name: State [44765,44770]
name: State [44765,44770]
===
match
---
atom_expr [6012,6025]
atom_expr [6012,6025]
===
match
---
name: self [29589,29593]
name: self [29589,29593]
===
match
---
atom_expr [15205,15224]
atom_expr [15205,15224]
===
match
---
trailer [55894,55898]
trailer [55894,55898]
===
match
---
atom_expr [43204,43218]
atom_expr [43204,43218]
===
match
---
trailer [22526,22553]
trailer [22526,22553]
===
match
---
name: self [64700,64704]
name: self [64807,64811]
===
match
---
or_test [32050,32096]
or_test [32050,32096]
===
match
---
name: subject [83143,83150]
name: subject [83250,83257]
===
match
---
operator: = [13463,13464]
operator: = [13463,13464]
===
match
---
atom_expr [74971,74984]
atom_expr [75078,75091]
===
match
---
arglist [41064,41083]
arglist [41064,41083]
===
match
---
atom_expr [92518,92535]
atom_expr [92625,92642]
===
match
---
trailer [91388,91396]
trailer [91495,91503]
===
match
---
operator: = [7040,7041]
operator: = [7040,7041]
===
match
---
operator: = [72174,72175]
operator: = [72281,72282]
===
match
---
trailer [49105,49107]
trailer [49105,49107]
===
match
---
string: 'prev_execution_date_success' [76948,76977]
string: 'prev_execution_date_success' [77055,77084]
===
match
---
atom_expr [64153,64182]
atom_expr [64153,64182]
===
match
---
atom_expr [80486,80498]
atom_expr [80593,80605]
===
match
---
name: task_type [54740,54749]
name: task_type [54740,54749]
===
match
---
trailer [58027,58039]
trailer [58027,58039]
===
match
---
name: String [12191,12197]
name: String [12191,12197]
===
match
---
name: test_mode [66430,66439]
name: test_mode [66537,66546]
===
match
---
string: 'Airflow alert: {{ti}}' [81639,81662]
string: 'Airflow alert: {{ti}}' [81746,81769]
===
match
---
trailer [33986,33994]
trailer [33986,33994]
===
match
---
decorated [35267,35836]
decorated [35267,35836]
===
match
---
name: self [47006,47010]
name: self [47006,47010]
===
match
---
operator: = [62192,62193]
operator: = [62192,62193]
===
match
---
atom_expr [90132,90159]
atom_expr [90239,90266]
===
match
---
funcdef [70912,71203]
funcdef [71019,71310]
===
match
---
argument [15665,15694]
argument [15665,15694]
===
match
---
trailer [67177,67179]
trailer [67284,67286]
===
match
---
expr_stmt [92426,92453]
expr_stmt [92533,92560]
===
match
---
parameters [93066,93072]
parameters [93173,93179]
===
match
---
name: str [4621,4624]
name: str [4621,4624]
===
match
---
if_stmt [4778,4811]
if_stmt [4778,4811]
===
match
---
name: ignore_ti_state [19505,19520]
name: ignore_ti_state [19505,19520]
===
match
---
argument [66430,66449]
argument [66537,66556]
===
match
---
funcdef [93056,93109]
funcdef [93163,93216]
===
match
---
atom_expr [51856,51872]
atom_expr [51856,51872]
===
match
---
suite [61907,62077]
suite [61907,62077]
===
match
---
name: _date_or_empty [49978,49992]
name: _date_or_empty [49978,49992]
===
match
---
name: get [71650,71653]
name: get [71757,71760]
===
match
---
name: tis [8841,8844]
name: tis [8841,8844]
===
match
---
trailer [33179,33184]
trailer [33179,33184]
===
match
---
name: str [86579,86582]
name: str [86686,86689]
===
match
---
trailer [8424,8426]
trailer [8424,8426]
===
match
---
string: "previous_execution_date was called" [34424,34460]
string: "previous_execution_date was called" [34424,34460]
===
match
---
trailer [65802,65813]
trailer [65909,65920]
===
match
---
operator: = [11666,11667]
operator: = [11666,11667]
===
match
---
operator: , [77577,77578]
operator: , [77684,77685]
===
match
---
atom_expr [46252,46331]
atom_expr [46252,46331]
===
match
---
operator: + [58803,58804]
operator: + [58803,58804]
===
match
---
simple_stmt [64192,64209]
simple_stmt [64192,64209]
===
match
---
parameters [47800,48028]
parameters [47800,48028]
===
match
---
operator: , [18269,18270]
operator: , [18269,18270]
===
match
---
trailer [67445,67454]
trailer [67552,67561]
===
match
---
arglist [76848,77042]
arglist [76955,77149]
===
match
---
operator: + [17940,17941]
operator: + [17940,17941]
===
match
---
atom_expr [77356,77370]
atom_expr [77463,77477]
===
match
---
operator: = [84212,84213]
operator: = [84319,84320]
===
match
---
param [62388,62409]
param [62388,62409]
===
match
---
name: self [66925,66929]
name: self [67032,67036]
===
match
---
name: ConnectionAccessor [77838,77856]
name: ConnectionAccessor [77945,77963]
===
match
---
atom_expr [7123,7136]
atom_expr [7123,7136]
===
match
---
return_stmt [74289,74315]
return_stmt [74396,74422]
===
match
---
trailer [80657,80665]
trailer [80764,80772]
===
match
---
fstring_string: operator_successes_ [54710,54729]
fstring_string: operator_successes_ [54710,54729]
===
match
---
name: self [26947,26951]
name: self [26947,26951]
===
match
---
name: self [40877,40881]
name: self [40877,40881]
===
match
---
expr_stmt [84023,84041]
expr_stmt [84130,84148]
===
match
---
name: pendulum [35224,35232]
name: pendulum [35224,35232]
===
match
---
operator: = [25469,25470]
operator: = [25469,25470]
===
match
---
name: message [72467,72474]
name: message [72574,72581]
===
match
---
arglist [53968,53981]
arglist [53968,53981]
===
match
---
simple_stmt [47318,47731]
simple_stmt [47318,47731]
===
match
---
funcdef [59163,60624]
funcdef [59163,60624]
===
match
---
name: warning [45654,45661]
name: warning [45654,45661]
===
match
---
name: ti [6542,6544]
name: ti [6542,6544]
===
match
---
name: session [23814,23821]
name: session [23814,23821]
===
match
---
simple_stmt [18766,18811]
simple_stmt [18766,18811]
===
match
---
name: self [29175,29179]
name: self [29175,29179]
===
match
---
operator: + [58321,58322]
operator: + [58321,58322]
===
match
---
operator: = [11208,11209]
operator: = [11208,11209]
===
match
---
string: "&upstream=false" [23675,23692]
string: "&upstream=false" [23675,23692]
===
match
---
simple_stmt [59777,59840]
simple_stmt [59777,59840]
===
match
---
name: replacement [72353,72364]
name: replacement [72460,72471]
===
match
---
trailer [89227,89236]
trailer [89334,89343]
===
match
---
trailer [64361,64376]
trailer [64361,64376]
===
match
---
operator: = [45208,45209]
operator: = [45208,45209]
===
match
---
operator: , [13756,13757]
operator: , [13756,13757]
===
match
---
trailer [29229,29235]
trailer [29229,29235]
===
match
---
argument [32956,32971]
argument [32956,32971]
===
match
---
name: pool [41498,41502]
name: pool [41498,41502]
===
match
---
name: lead_msg [47289,47297]
name: lead_msg [47289,47297]
===
match
---
import_as_names [1642,1671]
import_as_names [1642,1671]
===
match
---
trailer [62644,62646]
trailer [62644,62646]
===
match
---
name: handle_failure [51153,51167]
name: handle_failure [51153,51167]
===
match
---
name: State [63006,63011]
name: State [63006,63011]
===
match
---
name: next_kwargs [55806,55817]
name: next_kwargs [55806,55817]
===
match
---
name: Union [90088,90093]
name: Union [90195,90200]
===
match
---
suite [4370,4566]
suite [4370,4566]
===
match
---
name: kubernetes [80384,80394]
name: kubernetes [80491,80501]
===
match
---
trailer [76717,76769]
trailer [76824,76876]
===
match
---
operator: , [41217,41218]
operator: , [41217,41218]
===
match
---
name: Union [5435,5440]
name: Union [5435,5440]
===
match
---
trailer [11705,11719]
trailer [11705,11719]
===
match
---
decorated [79107,79721]
decorated [79214,79828]
===
match
---
trailer [26450,26461]
trailer [26450,26461]
===
match
---
name: FAILED [65437,65443]
name: FAILED [65544,65550]
===
match
---
name: Column [11210,11216]
name: Column [11210,11216]
===
match
---
name: self [66499,66503]
name: self [66606,66610]
===
match
---
atom_expr [91503,91512]
atom_expr [91610,91619]
===
match
---
name: self [26793,26797]
name: self [26793,26797]
===
match
---
name: get_previous_ti [35060,35075]
name: get_previous_ti [35060,35075]
===
match
---
operator: = [3788,3789]
operator: = [3788,3789]
===
match
---
trailer [50614,50653]
trailer [50614,50653]
===
match
---
name: State [33981,33986]
name: State [33981,33986]
===
match
---
name: self [89784,89788]
name: self [89891,89895]
===
match
---
atom_expr [34084,34097]
atom_expr [34084,34097]
===
match
---
decorated [69996,70265]
decorated [70103,70372]
===
match
---
name: task [54574,54578]
name: task [54574,54578]
===
match
---
trailer [26340,26349]
trailer [26340,26349]
===
match
---
atom_expr [51577,51650]
atom_expr [51577,51650]
===
match
---
suite [38277,40108]
suite [38277,40108]
===
match
---
return_stmt [31548,31559]
return_stmt [31548,31559]
===
match
---
name: pendulum [31577,31585]
name: pendulum [31577,31585]
===
match
---
operator: , [85166,85167]
operator: , [85273,85274]
===
match
---
name: lock_for_update [43277,43292]
name: lock_for_update [43277,43292]
===
match
---
atom_expr [44751,44761]
atom_expr [44751,44761]
===
match
---
operator: = [61002,61003]
operator: = [61002,61003]
===
match
---
name: self [53108,53112]
name: self [53108,53112]
===
match
---
simple_stmt [885,901]
simple_stmt [885,901]
===
match
---
simple_stmt [22516,22554]
simple_stmt [22516,22554]
===
match
---
atom_expr [90079,90127]
atom_expr [90186,90234]
===
match
---
name: Variable [70093,70101]
name: Variable [70200,70208]
===
match
---
suite [59963,60210]
suite [59963,60210]
===
match
---
name: add [57808,57811]
name: add [57808,57811]
===
match
---
name: max [6927,6930]
name: max [6927,6930]
===
match
---
operator: = [36848,36849]
operator: = [36848,36849]
===
match
---
dictorsetmaker [77726,77802]
dictorsetmaker [77833,77909]
===
match
---
atom_expr [88441,88452]
atom_expr [88548,88559]
===
match
---
trailer [18663,18668]
trailer [18663,18668]
===
match
---
trailer [12022,12035]
trailer [12022,12035]
===
match
---
name: modded_hash [39892,39903]
name: modded_hash [39892,39903]
===
match
---
name: delete [8216,8222]
name: delete [8216,8222]
===
match
---
atom_expr [49090,49107]
atom_expr [49090,49107]
===
match
---
name: task_id [49168,49175]
name: task_id [49168,49175]
===
match
---
parameters [55226,55252]
parameters [55226,55252]
===
match
---
name: task_id [89789,89796]
name: task_id [89896,89903]
===
match
---
simple_stmt [52905,52944]
simple_stmt [52905,52944]
===
match
---
operator: + [58687,58688]
operator: + [58687,58688]
===
match
---
name: Session [30678,30685]
name: Session [30678,30685]
===
match
---
or_test [29006,29070]
or_test [29006,29070]
===
match
---
operator: , [53972,53973]
operator: , [53972,53973]
===
match
---
operator: , [60701,60702]
operator: , [60701,60702]
===
match
---
atom_expr [77888,77942]
atom_expr [77995,78049]
===
match
---
name: self [58787,58791]
name: self [58787,58791]
===
match
---
string: """Prepare Task for Execution""" [52330,52362]
string: """Prepare Task for Execution""" [52330,52362]
===
match
---
name: pid [48957,48960]
name: pid [48957,48960]
===
match
---
trailer [35339,35348]
trailer [35339,35348]
===
match
---
funcdef [37858,37970]
funcdef [37858,37970]
===
match
---
string: '' [72817,72819]
string: '' [72924,72926]
===
match
---
atom_expr [26298,26309]
atom_expr [26298,26309]
===
match
---
operator: = [28961,28962]
operator: = [28961,28962]
===
match
---
atom_expr [57777,57790]
atom_expr [57777,57790]
===
match
---
name: ti [92577,92579]
name: ti [92684,92686]
===
match
---
name: TaskInstance [19173,19185]
name: TaskInstance [19173,19185]
===
match
---
import_as_names [2611,2632]
import_as_names [2611,2632]
===
match
---
trailer [44877,44883]
trailer [44877,44883]
===
match
---
name: _date_or_empty [47595,47609]
name: _date_or_empty [47595,47609]
===
match
---
suite [71237,71972]
suite [71344,72079]
===
match
---
operator: , [61705,61706]
operator: , [61705,61706]
===
match
---
name: State [89836,89841]
name: State [89943,89948]
===
match
---
operator: @ [24515,24516]
operator: @ [24515,24516]
===
match
---
trailer [7841,7852]
trailer [7841,7852]
===
match
---
param [37265,37282]
param [37265,37282]
===
match
---
name: running [17097,17104]
name: running [17097,17104]
===
match
---
atom_expr [45693,45975]
atom_expr [45693,45975]
===
match
---
trailer [47227,47244]
trailer [47227,47244]
===
match
---
atom_expr [64217,64230]
atom_expr [64217,64230]
===
match
---
name: state [29480,29485]
name: state [29480,29485]
===
match
---
name: result [54680,54686]
name: result [54680,54686]
===
match
---
trailer [49479,49495]
trailer [49479,49495]
===
match
---
name: verbose_aware_logger [36868,36888]
name: verbose_aware_logger [36868,36888]
===
match
---
name: total_seconds [56618,56631]
name: total_seconds [56618,56631]
===
match
---
operator: , [80791,80792]
operator: , [80898,80899]
===
match
---
name: Session [86728,86735]
name: Session [86835,86842]
===
match
---
name: xcom [89390,89394]
name: xcom [89497,89501]
===
match
---
operator: @ [35267,35268]
operator: @ [35267,35268]
===
match
---
operator: = [27656,27657]
operator: = [27656,27657]
===
match
---
simple_stmt [93253,93275]
simple_stmt [93360,93382]
===
match
---
name: self [54037,54041]
name: self [54037,54041]
===
match
---
name: self [43375,43379]
name: self [43375,43379]
===
match
---
trailer [48858,48875]
trailer [48858,48875]
===
match
---
atom [91811,91841]
atom [91918,91948]
===
match
---
name: get_num_running_task_instances [89478,89508]
name: get_num_running_task_instances [89585,89615]
===
match
---
name: sql [1731,1734]
name: sql [1731,1734]
===
match
---
import_from [40751,40791]
import_from [40751,40791]
===
match
---
classdef [10572,91856]
classdef [10572,91963]
===
match
---
argument [43277,43297]
argument [43277,43297]
===
match
---
decorator [60629,60646]
decorator [60629,60646]
===
match
---
trailer [66865,66876]
trailer [66972,66983]
===
match
---
number: 1 [26465,26466]
number: 1 [26465,26466]
===
match
---
operator: = [34478,34479]
operator: = [34478,34479]
===
match
---
atom_expr [23273,23285]
atom_expr [23273,23285]
===
match
---
name: pendulum [68673,68681]
name: pendulum [68780,68788]
===
match
---
string: """Remake the key by subtracting 1 from try number to match in memory information""" [10007,10091]
string: """Remake the key by subtracting 1 from try number to match in memory information""" [10007,10091]
===
match
---
name: content [83847,83854]
name: content [83954,83961]
===
match
---
name: Base [2299,2303]
name: Base [2299,2303]
===
match
---
atom_expr [68466,68496]
atom_expr [68573,68603]
===
match
---
operator: , [66449,66450]
operator: , [66556,66557]
===
match
---
atom_expr [7642,8112]
atom_expr [7642,8112]
===
match
---
arglist [73043,73050]
arglist [73150,73157]
===
match
---
if_stmt [74383,74481]
if_stmt [74490,74588]
===
match
---
trailer [20274,20279]
trailer [20274,20279]
===
match
---
atom_expr [60237,60255]
atom_expr [60237,60255]
===
match
---
name: info [54891,54895]
name: info [54891,54895]
===
match
---
operator: { [51982,51983]
operator: { [51982,51983]
===
match
---
simple_stmt [58893,58955]
simple_stmt [58893,58955]
===
match
---
name: task_id [23278,23285]
name: task_id [23278,23285]
===
match
---
name: Any [70977,70980]
name: Any [71084,71087]
===
match
---
string: 'ds' [75377,75381]
string: 'ds' [75484,75488]
===
match
---
name: query_for_task_instance [44831,44854]
name: query_for_task_instance [44831,44854]
===
match
---
atom_expr [26653,26674]
atom_expr [26653,26674]
===
match
---
trailer [46580,46589]
trailer [46580,46589]
===
match
---
expr_stmt [90590,90619]
expr_stmt [90697,90726]
===
match
---
suite [3541,3718]
suite [3541,3718]
===
match
---
operator: , [7994,7995]
operator: , [7994,7995]
===
match
---
trailer [11712,11718]
trailer [11712,11718]
===
match
---
operator: -> [93232,93234]
operator: -> [93339,93341]
===
match
---
name: SUCCESS [35827,35834]
name: SUCCESS [35827,35834]
===
match
---
operator: = [57225,57226]
operator: = [57225,57226]
===
match
---
operator: = [57755,57756]
operator: = [57755,57756]
===
match
---
name: self [69939,69943]
name: self [70046,70050]
===
match
---
expr_stmt [16067,16085]
expr_stmt [16067,16085]
===
match
---
name: is_container [3091,3103]
name: is_container [3091,3103]
===
match
---
not_test [81524,81549]
not_test [81631,81656]
===
match
---
name: trigger_id [26878,26888]
name: trigger_id [26878,26888]
===
match
---
operator: , [32954,32955]
operator: , [32954,32955]
===
match
---
operator: , [63368,63369]
operator: , [63368,63369]
===
match
---
trailer [33704,33938]
trailer [33704,33938]
===
match
---
name: context [60353,60360]
name: context [60353,60360]
===
match
---
param [37259,37264]
param [37259,37264]
===
match
---
operator: = [88746,88747]
operator: = [88853,88854]
===
match
---
atom_expr [27557,27572]
atom_expr [27557,27572]
===
match
---
simple_stmt [1928,2243]
simple_stmt [1928,2243]
===
match
---
name: self [79380,79384]
name: self [79487,79491]
===
match
---
name: message [72386,72393]
name: message [72493,72500]
===
match
---
operator: , [64563,64564]
operator: , [64670,64671]
===
match
---
string: "TaskInstanceKey" [10448,10465]
string: "TaskInstanceKey" [10448,10465]
===
match
---
name: execution_date [15680,15694]
name: execution_date [15680,15694]
===
match
---
trailer [66129,66135]
trailer [66236,66242]
===
match
---
name: property [93669,93677]
name: property [93776,93784]
===
match
---
trailer [73765,73780]
trailer [73872,73887]
===
match
---
trailer [6374,6383]
trailer [6374,6383]
===
match
---
name: task_id [28480,28487]
name: task_id [28480,28487]
===
match
---
argument [61447,61460]
argument [61447,61460]
===
match
---
name: task [59511,59515]
name: task [59511,59515]
===
match
---
name: test_mode [61723,61732]
name: test_mode [61723,61732]
===
match
---
comparison [60223,60255]
comparison [60223,60255]
===
match
---
name: xcom_push [57377,57386]
name: xcom_push [57377,57386]
===
match
---
name: log [47011,47014]
name: log [47011,47014]
===
match
---
operator: = [6991,6992]
operator: = [6991,6992]
===
match
---
trailer [91261,91284]
trailer [91368,91391]
===
match
---
expr_stmt [22122,22180]
expr_stmt [22122,22180]
===
match
---
expr_stmt [83927,83956]
expr_stmt [84034,84063]
===
match
---
argument [44861,44876]
argument [44861,44876]
===
match
---
name: self [84434,84438]
name: self [84541,84545]
===
match
---
trailer [48972,48974]
trailer [48972,48974]
===
match
---
name: bool [60853,60857]
name: bool [60853,60857]
===
match
---
name: self [93571,93575]
name: self [93678,93682]
===
match
---
name: bool [60690,60694]
name: bool [60690,60694]
===
match
---
operator: , [30693,30694]
operator: , [30693,30694]
===
match
---
trailer [62283,62285]
trailer [62283,62285]
===
match
---
operator: = [84911,84912]
operator: = [85018,85019]
===
match
---
name: Column [12085,12091]
name: Column [12085,12091]
===
match
---
string: '%Y%m%dT%H%M%S' [68075,68090]
string: '%Y%m%dT%H%M%S' [68182,68197]
===
match
---
funcdef [47268,47731]
funcdef [47268,47731]
===
match
---
atom_expr [39888,39939]
atom_expr [39888,39939]
===
match
---
name: primary [9784,9791]
name: primary [9784,9791]
===
match
---
name: error [24755,24760]
name: error [24755,24760]
===
match
---
atom_expr [72453,72495]
atom_expr [72560,72602]
===
match
---
simple_stmt [75098,78059]
simple_stmt [75205,78166]
===
match
---
simple_stmt [28847,28910]
simple_stmt [28847,28910]
===
match
---
atom_expr [82754,82967]
atom_expr [82861,83074]
===
match
---
operator: = [85244,85245]
operator: = [85351,85352]
===
match
---
operator: = [11546,11547]
operator: = [11546,11547]
===
match
---
name: ignore_all_deps [43407,43422]
name: ignore_all_deps [43407,43422]
===
match
---
trailer [78641,78643]
trailer [78748,78750]
===
match
---
expr_stmt [48952,48974]
expr_stmt [48952,48974]
===
match
---
argument [43940,43971]
argument [43940,43971]
===
match
---
name: self [63201,63205]
name: self [63201,63205]
===
match
---
trailer [89690,89864]
trailer [89797,89971]
===
match
---
trailer [31647,31748]
trailer [31647,31748]
===
match
---
name: e [50382,50383]
name: e [50382,50383]
===
match
---
name: TaskFail [2468,2476]
name: TaskFail [2468,2476]
===
match
---
name: xcom [2599,2603]
name: xcom [2599,2603]
===
match
---
operator: , [52197,52198]
operator: , [52197,52198]
===
match
---
name: dag_run [75247,75254]
name: dag_run [75354,75361]
===
match
---
name: self [46576,46580]
name: self [46576,46580]
===
match
---
name: update [82730,82736]
name: update [82837,82843]
===
match
---
name: pool [60982,60986]
name: pool [60982,60986]
===
match
---
name: Proxy [76355,76360]
name: Proxy [76462,76467]
===
match
---
atom_expr [35515,35770]
atom_expr [35515,35770]
===
match
---
expr_stmt [7612,8180]
expr_stmt [7612,8180]
===
match
---
trailer [63200,63206]
trailer [63200,63206]
===
match
---
operator: = [66948,66949]
operator: = [67055,67056]
===
match
---
name: pool_override [27504,27517]
name: pool_override [27504,27517]
===
match
---
expr_stmt [31572,31615]
expr_stmt [31572,31615]
===
match
---
suite [47135,47263]
suite [47135,47263]
===
match
---
string: "Current context is not equal to the state at context stack. Expected=%s, got=%s" [4412,4493]
string: "Current context is not equal to the state at context stack. Expected=%s, got=%s" [4412,4493]
===
match
---
name: tis [90468,90471]
name: tis [90575,90578]
===
match
---
name: run_id [91251,91257]
name: run_id [91358,91364]
===
match
---
simple_stmt [23218,23309]
simple_stmt [23218,23309]
===
match
---
atom_expr [11305,11337]
atom_expr [11305,11337]
===
match
---
name: test_mode [41427,41436]
name: test_mode [41427,41436]
===
match
---
except_clause [78656,78708]
except_clause [78763,78815]
===
match
---
name: lead_msg [47485,47493]
name: lead_msg [47485,47493]
===
match
---
name: can_run [32089,32096]
name: can_run [32089,32096]
===
match
---
name: self [44942,44946]
name: self [44942,44946]
===
match
---
name: self [37630,37634]
name: self [37630,37634]
===
match
---
name: timedelta [72917,72926]
name: timedelta [73024,73033]
===
match
---
name: _try_number [65678,65689]
name: _try_number [65785,65796]
===
match
---
atom_expr [26966,26980]
atom_expr [26966,26980]
===
match
---
trailer [52581,52589]
trailer [52581,52589]
===
match
---
param [80304,80308]
param [80411,80415]
===
match
---
name: self [32802,32806]
name: self [32802,32806]
===
match
---
simple_stmt [86250,86477]
simple_stmt [86357,86584]
===
match
---
operator: = [66986,66987]
operator: = [67093,67094]
===
match
---
trailer [12923,12971]
trailer [12923,12971]
===
match
---
trailer [64356,64361]
trailer [64356,64361]
===
match
---
operator: , [60865,60866]
operator: , [60865,60866]
===
match
---
name: session [35089,35096]
name: session [35089,35096]
===
match
---
name: self [50666,50670]
name: self [50666,50670]
===
match
---
name: String [11305,11311]
name: String [11305,11311]
===
match
---
operator: = [69860,69861]
operator: = [69967,69968]
===
match
---
name: UP_FOR_RETRY [40339,40351]
name: UP_FOR_RETRY [40339,40351]
===
match
---
string: 'task' [81542,81548]
string: 'task' [81649,81655]
===
match
---
atom_expr [26257,26269]
atom_expr [26257,26269]
===
match
---
name: Literal [2971,2978]
name: Literal [2971,2978]
===
match
---
parameters [72631,72633]
parameters [72738,72740]
===
match
---
name: TaskReschedule [2519,2533]
name: TaskReschedule [2519,2533]
===
match
---
parameters [68918,68920]
parameters [69025,69027]
===
match
---
operator: , [80666,80667]
operator: , [80773,80774]
===
match
---
atom_expr [62993,63003]
atom_expr [62993,63003]
===
match
---
atom_expr [65418,65428]
atom_expr [65525,65535]
===
match
---
operator: , [86465,86466]
operator: , [86572,86573]
===
match
---
atom_expr [76276,76287]
atom_expr [76383,76394]
===
match
---
atom_expr [89355,89365]
atom_expr [89462,89472]
===
match
---
operator: , [1140,1141]
operator: , [1140,1141]
===
match
---
name: extend [22740,22746]
name: extend [22740,22746]
===
match
---
trailer [83540,83749]
trailer [83647,83856]
===
match
---
number: 4 [14828,14829]
number: 4 [14828,14829]
===
match
---
name: _run_finished_callback [66504,66526]
name: _run_finished_callback [66611,66633]
===
match
---
trailer [93575,93592]
trailer [93682,93699]
===
match
---
expr_stmt [36590,36631]
expr_stmt [36590,36631]
===
match
---
trailer [88540,88549]
trailer [88647,88656]
===
match
---
operator: = [18182,18183]
operator: = [18182,18183]
===
match
---
operator: = [33980,33981]
operator: = [33980,33981]
===
match
---
simple_stmt [22355,22393]
simple_stmt [22355,22393]
===
match
---
trailer [81535,81549]
trailer [81642,81656]
===
match
---
operator: , [2221,2222]
operator: , [2221,2222]
===
match
---
simple_stmt [9399,9424]
simple_stmt [9399,9424]
===
match
---
trailer [83482,83484]
trailer [83589,83591]
===
match
---
simple_stmt [1817,1846]
simple_stmt [1817,1846]
===
match
---
simple_stmt [31548,31560]
simple_stmt [31548,31560]
===
match
---
operator: = [49311,49312]
operator: = [49311,49312]
===
match
---
trailer [14559,14564]
trailer [14559,14564]
===
match
---
operator: -> [92927,92929]
operator: -> [93034,93036]
===
match
---
param [19880,19910]
param [19880,19910]
===
match
---
trailer [9507,9514]
trailer [9507,9514]
===
match
---
string: "--force" [22694,22703]
string: "--force" [22694,22703]
===
match
---
decorated [89453,89897]
decorated [89560,90004]
===
match
---
name: self [15011,15015]
name: self [15011,15015]
===
match
---
simple_stmt [82157,82498]
simple_stmt [82264,82605]
===
match
---
param [93622,93626]
param [93729,93733]
===
match
---
trailer [51789,51843]
trailer [51789,51843]
===
match
---
atom_expr [92426,92437]
atom_expr [92533,92544]
===
match
---
arglist [28862,28908]
arglist [28862,28908]
===
match
---
simple_stmt [44314,44331]
simple_stmt [44314,44331]
===
match
---
trailer [81074,81105]
trailer [81181,81212]
===
match
---
atom_expr [8251,8278]
atom_expr [8251,8278]
===
match
---
arglist [18659,18675]
arglist [18659,18675]
===
match
---
operator: , [76398,76399]
operator: , [76505,76506]
===
match
---
operator: , [13009,13010]
operator: , [13009,13010]
===
match
---
operator: = [13263,13264]
operator: = [13263,13264]
===
match
---
operator: , [67606,67607]
operator: , [67713,67714]
===
match
---
simple_stmt [46129,46146]
simple_stmt [46129,46146]
===
match
---
comparison [29038,29070]
comparison [29038,29070]
===
match
---
name: ignore_schedule [32032,32047]
name: ignore_schedule [32032,32047]
===
match
---
atom_expr [30177,30470]
atom_expr [30177,30470]
===
match
---
trailer [37013,37022]
trailer [37013,37022]
===
match
---
except_clause [50254,50293]
except_clause [50254,50293]
===
match
---
name: error_file [51622,51632]
name: error_file [51622,51632]
===
match
---
trailer [39282,39289]
trailer [39282,39289]
===
match
---
suite [25776,25806]
suite [25776,25806]
===
match
---
return_stmt [19166,19719]
return_stmt [19166,19719]
===
match
---
name: get [69871,69874]
name: get [69978,69981]
===
match
---
name: self [93096,93100]
name: self [93203,93207]
===
match
---
name: external_executor_id [26824,26844]
name: external_executor_id [26824,26844]
===
match
---
operator: = [60733,60734]
operator: = [60733,60734]
===
match
---
atom_expr [88978,89000]
atom_expr [89085,89107]
===
match
---
name: check_and_change_state_before_execution [61097,61136]
name: check_and_change_state_before_execution [61097,61136]
===
match
---
tfpdef [41352,41373]
tfpdef [41352,41373]
===
match
---
name: provide_session [32405,32420]
name: provide_session [32405,32420]
===
match
---
name: _try_number [17162,17173]
name: _try_number [17162,17173]
===
match
---
name: self [46649,46653]
name: self [46649,46653]
===
match
---
atom_expr [91238,91284]
atom_expr [91345,91391]
===
match
---
expr_stmt [12766,13491]
expr_stmt [12766,13491]
===
match
---
name: self [39210,39214]
name: self [39210,39214]
===
match
---
operator: = [12300,12301]
operator: = [12300,12301]
===
match
---
operator: = [50644,50645]
operator: = [50644,50645]
===
match
---
operator: , [81293,81294]
operator: , [81400,81401]
===
match
---
string: """         Forces the task instance's state to FAILED in the database.          :param session: SQLAlchemy ORM Session         :type session: Session         """ [24575,24737]
string: """         Forces the task instance's state to FAILED in the database.          :param session: SQLAlchemy ORM Session         :type session: Session         """ [24575,24737]
===
match
---
name: task_id [10378,10385]
name: task_id [10378,10385]
===
match
---
operator: = [41295,41296]
operator: = [41295,41296]
===
match
---
name: func [30191,30195]
name: func [30191,30195]
===
match
---
name: cfg_path [19691,19699]
name: cfg_path [19691,19699]
===
match
---
parameters [23348,23354]
parameters [23348,23354]
===
match
---
operator: , [31733,31734]
operator: , [31733,31734]
===
match
---
operator: , [66262,66263]
operator: , [66369,66370]
===
match
---
trailer [6933,6943]
trailer [6933,6943]
===
match
---
number: 1 [45955,45956]
number: 1 [45955,45956]
===
match
---
expr_stmt [57192,57234]
expr_stmt [57192,57234]
===
match
---
expr_stmt [11896,11923]
expr_stmt [11896,11923]
===
match
---
name: str [63513,63516]
name: str [63513,63516]
===
match
---
name: next_kwargs [12598,12609]
name: next_kwargs [12598,12609]
===
match
---
return_stmt [74829,74840]
return_stmt [74936,74947]
===
match
---
name: task [67224,67228]
name: task [67331,67335]
===
match
---
operator: = [73991,73992]
operator: = [74098,74099]
===
match
---
operator: , [36963,36964]
operator: , [36963,36964]
===
match
---
decorator [17183,17202]
decorator [17183,17202]
===
match
---
trailer [8162,8168]
trailer [8162,8168]
===
match
---
trailer [73042,73051]
trailer [73149,73158]
===
match
---
trailer [7111,7122]
trailer [7111,7122]
===
match
---
name: lock_for_update [49496,49511]
name: lock_for_update [49496,49511]
===
match
---
trailer [52225,52231]
trailer [52225,52231]
===
match
---
name: dill [12149,12153]
name: dill [12149,12153]
===
match
---
string: """             Wrapper around Variable. This way you can get variables in             templates by using ``{{ var.value.variable_name }}`` or             ``{{ var.value.get('variable_name', 'fallback') }}``.             """ [69451,69675]
string: """             Wrapper around Variable. This way you can get variables in             templates by using ``{{ var.value.variable_name }}`` or             ``{{ var.value.get('variable_name', 'fallback') }}``.             """ [69558,69782]
===
match
---
name: dag [67213,67216]
name: dag [67320,67323]
===
match
---
name: self [69973,69977]
name: self [70080,70084]
===
match
---
trailer [22310,22321]
trailer [22310,22321]
===
match
---
fstring_string: ti.finish. [51933,51943]
fstring_string: ti.finish. [51933,51943]
===
match
---
expr_stmt [26653,26696]
expr_stmt [26653,26696]
===
match
---
name: key [78021,78024]
name: key [78128,78131]
===
match
---
name: next_retry_datetime [40361,40380]
name: next_retry_datetime [40361,40380]
===
match
---
name: job [8359,8362]
name: job [8359,8362]
===
match
---
expr_stmt [70592,70607]
expr_stmt [70699,70714]
===
match
---
name: self [55758,55762]
name: self [55758,55762]
===
match
---
trailer [33454,33456]
trailer [33454,33456]
===
match
---
param [40444,40449]
param [40444,40449]
===
match
---
expr_stmt [11789,11831]
expr_stmt [11789,11831]
===
match
---
argument [43886,43922]
argument [43886,43922]
===
match
---
expr_stmt [11502,11532]
expr_stmt [11502,11532]
===
match
---
name: self [69725,69729]
name: self [69832,69836]
===
match
---
operator: , [61165,61166]
operator: , [61165,61166]
===
match
---
name: try_number [83670,83680]
name: try_number [83777,83787]
===
match
---
fstring_start: f' [51931,51933]
fstring_start: f' [51931,51933]
===
match
---
name: run_ids [9266,9273]
name: run_ids [9266,9273]
===
match
---
trailer [47046,47051]
trailer [47046,47051]
===
match
---
if_stmt [58238,58391]
if_stmt [58238,58391]
===
match
---
atom_expr [18651,18676]
atom_expr [18651,18676]
===
match
---
return_stmt [93016,93036]
return_stmt [93123,93143]
===
match
---
operator: = [81637,81638]
operator: = [81744,81745]
===
match
---
atom_expr [8452,8468]
atom_expr [8452,8468]
===
match
---
trailer [61940,61946]
trailer [61940,61946]
===
match
---
import_from [3161,3203]
import_from [3161,3203]
===
match
---
decorator [40408,40425]
decorator [40408,40425]
===
match
---
name: ignore_param_exceptions [67396,67419]
name: ignore_param_exceptions [67503,67526]
===
match
---
operator: , [79777,79778]
operator: , [79884,79885]
===
match
---
arglist [74307,74314]
arglist [74414,74421]
===
match
---
if_stmt [22562,22642]
if_stmt [22562,22642]
===
match
---
argument [44038,44083]
argument [44038,44083]
===
match
---
name: task [38213,38217]
name: task [38213,38217]
===
match
---
name: convert_to_utc [15461,15475]
name: convert_to_utc [15461,15475]
===
match
---
name: session [62427,62434]
name: session [62427,62434]
===
match
---
name: dag_id [88404,88410]
name: dag_id [88511,88517]
===
match
---
trailer [84086,84095]
trailer [84193,84202]
===
match
---
suite [47309,47731]
suite [47309,47731]
===
match
---
suite [60038,60093]
suite [60038,60093]
===
match
---
argument [61497,61512]
argument [61497,61512]
===
match
---
simple_stmt [91426,91686]
simple_stmt [91533,91793]
===
match
---
param [47967,48000]
param [47967,48000]
===
match
---
argument [90814,90868]
argument [90921,90975]
===
match
---
sync_comp_for [91271,91283]
sync_comp_for [91378,91390]
===
match
---
test [65814,65867]
test [65921,65974]
===
match
---
name: Integer [1394,1401]
name: Integer [1394,1401]
===
match
---
trailer [73881,73897]
trailer [73988,74004]
===
match
---
arglist [84221,84266]
arglist [84328,84373]
===
match
---
argument [82821,82850]
argument [82928,82957]
===
match
---
name: task [58878,58882]
name: task [58878,58882]
===
match
---
name: mark_success [46864,46876]
name: mark_success [46864,46876]
===
match
---
name: _date_or_empty [47103,47117]
name: _date_or_empty [47103,47117]
===
match
---
suite [32242,32322]
suite [32242,32322]
===
match
---
atom_expr [91590,91609]
atom_expr [91697,91716]
===
match
---
simple_stmt [40722,40742]
simple_stmt [40722,40742]
===
match
---
trailer [24886,24888]
trailer [24886,24888]
===
match
---
name: max_tries [6545,6554]
name: max_tries [6545,6554]
===
match
---
suite [8845,9604]
suite [8845,9604]
===
match
---
name: task [6513,6517]
name: task [6513,6517]
===
match
---
name: TYPE_CHECKING [1071,1084]
name: TYPE_CHECKING [1071,1084]
===
match
---
name: hasattr [92741,92748]
name: hasattr [92848,92855]
===
match
---
param [72064,72068]
param [72171,72175]
===
match
---
name: try_number [28507,28517]
name: try_number [28507,28517]
===
match
---
operator: , [25553,25554]
operator: , [25553,25554]
===
match
---
name: self [43147,43151]
name: self [43147,43151]
===
match
---
name: pool [20220,20224]
name: pool [20220,20224]
===
match
---
testlist_comp [13329,13343]
testlist_comp [13329,13343]
===
match
---
operator: = [24482,24483]
operator: = [24482,24483]
===
match
---
atom_expr [69973,69981]
atom_expr [70080,70088]
===
match
---
operator: = [11697,11698]
operator: = [11697,11698]
===
match
---
operator: , [19708,19709]
operator: , [19708,19709]
===
match
---
name: self [68295,68299]
name: self [68402,68406]
===
match
---
trailer [12889,12908]
trailer [12889,12908]
===
match
---
operator: , [71178,71179]
operator: , [71285,71286]
===
match
---
operator: == [90846,90848]
operator: == [90953,90955]
===
match
---
name: task_ids [88991,88999]
name: task_ids [89098,89106]
===
match
---
atom_expr [43239,43298]
atom_expr [43239,43298]
===
match
---
name: dag_id [14267,14273]
name: dag_id [14267,14273]
===
match
---
atom_expr [26213,26227]
atom_expr [26213,26227]
===
match
---
number: 2 [38593,38594]
number: 2 [38593,38594]
===
match
---
atom_expr [92264,92273]
atom_expr [92371,92380]
===
match
---
trailer [90093,90126]
trailer [90200,90233]
===
match
---
name: self [57486,57490]
name: self [57486,57490]
===
match
---
atom [3840,3842]
atom [3840,3842]
===
match
---
decorator [86482,86499]
decorator [86589,86606]
===
match
---
name: Log [64427,64430]
name: Log [64427,64430]
===
match
---
name: get_tomorrow_ds_nodash [72965,72987]
name: get_tomorrow_ds_nodash [73072,73094]
===
match
---
operator: , [5490,5491]
operator: , [5490,5491]
===
match
---
atom_expr [28201,28220]
atom_expr [28201,28220]
===
match
---
name: deserialize_json [71180,71196]
name: deserialize_json [71287,71303]
===
match
---
parameters [89922,89939]
parameters [90029,90046]
===
match
---
atom_expr [52183,52204]
atom_expr [52183,52204]
===
match
---
name: dag_run [79965,79972]
name: dag_run [80072,80079]
===
match
---
name: attributes [1624,1634]
name: attributes [1624,1634]
===
match
---
trailer [37473,37490]
trailer [37473,37490]
===
match
---
name: execution_date [74731,74745]
name: execution_date [74838,74852]
===
match
---
import_from [1817,1845]
import_from [1817,1845]
===
match
---
expr_stmt [40062,40107]
expr_stmt [40062,40107]
===
match
---
name: ti [91558,91560]
name: ti [91665,91667]
===
match
---
fstring_end: " [15910,15911]
fstring_end: " [15910,15911]
===
match
---
operator: , [22809,22810]
operator: , [22809,22810]
===
match
---
name: simplefilter [73653,73665]
name: simplefilter [73760,73772]
===
match
---
name: pickle_id [19559,19568]
name: pickle_id [19559,19568]
===
match
---
name: airflow [1933,1940]
name: airflow [1933,1940]
===
match
---
name: Column [12016,12022]
name: Column [12016,12022]
===
match
---
atom_expr [47042,47051]
atom_expr [47042,47051]
===
match
---
atom_expr [57124,57143]
atom_expr [57124,57143]
===
match
---
simple_stmt [24995,25389]
simple_stmt [24995,25389]
===
match
---
name: self [86526,86530]
name: self [86633,86637]
===
match
---
atom_expr [35821,35834]
atom_expr [35821,35834]
===
match
---
subscriptlist [18496,18513]
subscriptlist [18496,18513]
===
match
---
sync_comp_for [89105,89164]
sync_comp_for [89212,89271]
===
match
---
atom_expr [16011,16024]
atom_expr [16011,16024]
===
match
---
name: query [8374,8379]
name: query [8374,8379]
===
match
---
argument [61860,61875]
argument [61860,61875]
===
match
---
trailer [83012,83024]
trailer [83119,83131]
===
match
---
name: from_string [84075,84086]
name: from_string [84182,84193]
===
match
---
name: self [26567,26571]
name: self [26567,26571]
===
match
---
suite [17105,17142]
suite [17105,17142]
===
match
---
name: Column [11946,11952]
name: Column [11946,11952]
===
match
---
name: t [90860,90861]
name: t [90967,90968]
===
match
---
if_stmt [15202,15418]
if_stmt [15202,15418]
===
match
---
trailer [22443,22474]
trailer [22443,22474]
===
match
---
atom [22693,22704]
atom [22693,22704]
===
match
---
trailer [15282,15322]
trailer [15282,15322]
===
match
---
comparison [40356,40402]
comparison [40356,40402]
===
match
---
expr_stmt [92161,92190]
expr_stmt [92268,92297]
===
match
---
trailer [27748,27764]
trailer [27748,27764]
===
match
---
decorator [32978,32988]
decorator [32978,32988]
===
match
---
atom_expr [6042,6051]
atom_expr [6042,6051]
===
match
---
name: max_tries [27688,27697]
name: max_tries [27688,27697]
===
match
---
name: str [41477,41480]
name: str [41477,41480]
===
match
---
name: read [84035,84039]
name: read [84142,84146]
===
match
---
comparison [89814,89849]
comparison [89921,89956]
===
match
---
atom_expr [65377,65404]
atom_expr [65484,65511]
===
match
---
atom_expr [35242,35260]
atom_expr [35242,35260]
===
match
---
operator: = [53293,53294]
operator: = [53293,53294]
===
match
---
atom_expr [40356,40382]
atom_expr [40356,40382]
===
match
---
return_stmt [71555,71606]
return_stmt [71662,71713]
===
match
---
name: cmd [22682,22685]
name: cmd [22682,22685]
===
match
---
name: BaseJob [8396,8403]
name: BaseJob [8396,8403]
===
match
---
name: self [25927,25931]
name: self [25927,25931]
===
match
---
atom_expr [67498,67508]
atom_expr [67605,67615]
===
match
---
name: use_default [81510,81521]
name: use_default [81617,81628]
===
match
---
argument [54656,54671]
argument [54656,54671]
===
match
---
parameters [63354,63553]
parameters [63354,63553]
===
match
---
name: end_date [84855,84863]
name: end_date [84962,84970]
===
match
---
decorated [40408,41104]
decorated [40408,41104]
===
match
---
if_stmt [60298,60624]
if_stmt [60298,60624]
===
match
---
trailer [34739,34758]
trailer [34739,34758]
===
match
---
operator: = [48961,48962]
operator: = [48961,48962]
===
match
---
name: getLogger [3857,3866]
name: getLogger [3857,3866]
===
match
---
name: session [57492,57499]
name: session [57492,57499]
===
match
---
simple_stmt [84897,84963]
simple_stmt [85004,85070]
===
match
---
fstring_end: " [23587,23588]
fstring_end: " [23587,23588]
===
match
---
name: _date_or_empty [47646,47660]
name: _date_or_empty [47646,47660]
===
match
---
trailer [60063,60083]
trailer [60063,60083]
===
match
---
name: Optional [14131,14139]
name: Optional [14131,14139]
===
match
---
name: file_path [20114,20123]
name: file_path [20114,20123]
===
match
---
name: state [24430,24435]
name: state [24430,24435]
===
match
---
name: is_premature [29259,29271]
name: is_premature [29259,29271]
===
match
---
simple_stmt [46519,46568]
simple_stmt [46519,46568]
===
match
---
simple_stmt [93170,93194]
simple_stmt [93277,93301]
===
match
---
string: "prev_ds_nodash" [76647,76663]
string: "prev_ds_nodash" [76754,76770]
===
match
---
operator: = [33405,33406]
operator: = [33405,33406]
===
match
---
name: RenderedTaskInstanceFields [78312,78338]
name: RenderedTaskInstanceFields [78419,78445]
===
match
---
trailer [39932,39934]
trailer [39932,39934]
===
match
---
operator: , [13603,13604]
operator: , [13603,13604]
===
match
---
trailer [8205,8215]
trailer [8205,8215]
===
match
---
atom_expr [90008,90031]
atom_expr [90115,90138]
===
match
---
param [60836,60866]
param [60836,60866]
===
match
---
atom_expr [66499,66539]
atom_expr [66606,66646]
===
match
---
and_test [14933,14993]
and_test [14933,14993]
===
match
---
trailer [26571,26580]
trailer [26571,26580]
===
match
---
trailer [11216,11284]
trailer [11216,11284]
===
match
---
comparison [30511,30549]
comparison [30511,30549]
===
match
---
operator: = [66439,66440]
operator: = [66546,66547]
===
match
---
atom_expr [15382,15417]
atom_expr [15382,15417]
===
match
---
import_from [1148,1178]
import_from [1148,1178]
===
match
---
name: str [47130,47133]
name: str [47130,47133]
===
match
---
atom_expr [83457,83484]
atom_expr [83564,83591]
===
match
---
operator: = [30954,30955]
operator: = [30954,30955]
===
match
---
atom_expr [63762,63822]
atom_expr [63762,63822]
===
match
---
operator: , [1351,1352]
operator: , [1351,1352]
===
match
---
name: Column [11513,11519]
name: Column [11513,11519]
===
match
---
name: pool [22811,22815]
name: pool [22811,22815]
===
match
---
string: """Handle Failure for the TaskInstance""" [63571,63612]
string: """Handle Failure for the TaskInstance""" [63571,63612]
===
match
---
name: self [26901,26905]
name: self [26901,26905]
===
match
---
arglist [76623,76663]
arglist [76730,76770]
===
match
---
atom_expr [60407,60427]
atom_expr [60407,60427]
===
match
---
operator: -> [93628,93630]
operator: -> [93735,93737]
===
match
---
trailer [52265,52267]
trailer [52265,52267]
===
match
---
name: utcnow [64242,64248]
name: utcnow [64242,64248]
===
match
---
atom_expr [27581,27601]
atom_expr [27581,27601]
===
match
---
trailer [55059,55066]
trailer [55059,55066]
===
match
---
name: dep_status [37003,37013]
name: dep_status [37003,37013]
===
match
---
arith_expr [47345,47471]
arith_expr [47345,47471]
===
match
---
simple_stmt [26398,26418]
simple_stmt [26398,26418]
===
match
---
atom_expr [29489,29507]
atom_expr [29489,29507]
===
match
---
name: execution_date [73766,73780]
name: execution_date [73873,73887]
===
match
---
name: raw [89996,89999]
name: raw [90103,90106]
===
match
---
operator: , [10168,10169]
operator: , [10168,10169]
===
match
---
name: error_file [61818,61828]
name: error_file [61818,61828]
===
match
---
return_stmt [23507,23763]
return_stmt [23507,23763]
===
match
---
name: property [29242,29250]
name: property [29242,29250]
===
match
---
arglist [19216,19709]
arglist [19216,19709]
===
match
---
name: coerce_datetime [75231,75246]
name: coerce_datetime [75338,75353]
===
match
---
trailer [78533,78572]
trailer [78640,78679]
===
match
---
simple_stmt [24497,24510]
simple_stmt [24497,24510]
===
match
---
return_stmt [4884,4922]
return_stmt [4884,4922]
===
match
---
name: task_id [9708,9715]
name: task_id [9708,9715]
===
match
---
name: job_id [6293,6299]
name: job_id [6293,6299]
===
match
---
name: task [14297,14301]
name: task [14297,14301]
===
match
---
simple_stmt [8190,8243]
simple_stmt [8190,8243]
===
match
---
atom_expr [49973,50010]
atom_expr [49973,50010]
===
match
---
trailer [66155,66161]
trailer [66262,66268]
===
match
---
name: dag [6417,6420]
name: dag [6417,6420]
===
match
---
trailer [92222,92230]
trailer [92329,92337]
===
match
---
operator: , [82948,82949]
operator: , [83055,83056]
===
match
---
name: merge [52226,52231]
name: merge [52226,52231]
===
match
---
name: pod [81220,81223]
name: pod [81327,81330]
===
match
---
atom_expr [7625,8180]
atom_expr [7625,8180]
===
match
---
name: session [66931,66938]
name: session [67038,67045]
===
match
---
name: dagrun [14492,14498]
name: dagrun [14492,14498]
===
match
---
trailer [64203,64208]
trailer [64203,64208]
===
match
---
arith_expr [58303,58336]
arith_expr [58303,58336]
===
match
---
atom_expr [92670,92677]
atom_expr [92777,92784]
===
match
---
name: state [52192,52197]
name: state [52192,52197]
===
match
---
name: timezone [74435,74443]
name: timezone [74542,74550]
===
match
---
name: ondelete [13455,13463]
name: ondelete [13455,13463]
===
match
---
return_stmt [37193,37204]
return_stmt [37193,37204]
===
match
---
name: airflow [1851,1858]
name: airflow [1851,1858]
===
match
---
name: self [64153,64157]
name: self [64153,64157]
===
match
---
operator: - [82899,82900]
operator: - [83006,83007]
===
match
---
arglist [5308,5322]
arglist [5308,5322]
===
match
---
atom_expr [54767,54793]
atom_expr [54767,54793]
===
match
---
name: _queue [93656,93662]
name: _queue [93763,93769]
===
match
---
trailer [74393,74410]
trailer [74500,74517]
===
match
---
name: sqlalchemy [1677,1687]
name: sqlalchemy [1677,1687]
===
match
---
for_stmt [37394,37853]
for_stmt [37394,37853]
===
match
---
name: query [15593,15598]
name: query [15593,15598]
===
match
---
trailer [22685,22692]
trailer [22685,22692]
===
match
---
trailer [75071,75079]
trailer [75178,75186]
===
match
---
operator: , [80832,80833]
operator: , [80939,80940]
===
match
---
decorator [73061,73068]
decorator [73168,73175]
===
match
---
trailer [40911,40918]
trailer [40911,40918]
===
match
---
operator: = [83787,83788]
operator: = [83894,83895]
===
match
---
name: item [70742,70746]
name: item [70849,70853]
===
match
---
suite [30723,32399]
suite [30723,32399]
===
match
---
decorated [73061,73919]
decorated [73168,74026]
===
match
---
name: bool [60728,60732]
name: bool [60728,60732]
===
match
---
name: end_date [11502,11510]
name: end_date [11502,11510]
===
match
---
operator: , [37608,37609]
operator: , [37608,37609]
===
match
---
name: dag [18990,18993]
name: dag [18990,18993]
===
match
---
atom_expr [58022,58039]
atom_expr [58022,58039]
===
match
---
operator: - [39935,39936]
operator: - [39935,39936]
===
match
---
atom_expr [12130,12154]
atom_expr [12130,12154]
===
match
---
atom_expr [51944,51960]
atom_expr [51944,51960]
===
match
---
trailer [91759,91767]
trailer [91866,91874]
===
match
---
name: airflow [2393,2400]
name: airflow [2393,2400]
===
match
---
trailer [15863,15870]
trailer [15863,15870]
===
match
---
import_as_names [2275,2303]
import_as_names [2275,2303]
===
match
---
name: fd [4694,4696]
name: fd [4694,4696]
===
match
---
arglist [77996,78046]
arglist [78103,78153]
===
match
---
simple_stmt [11597,11652]
simple_stmt [11597,11652]
===
match
---
name: _Variable__NO_DEFAULT_SENTINEL [70102,70132]
name: _Variable__NO_DEFAULT_SENTINEL [70209,70239]
===
match
---
operator: , [39328,39329]
operator: , [39328,39329]
===
match
---
suite [27870,28305]
suite [27870,28305]
===
match
---
simple_stmt [17800,17824]
simple_stmt [17800,17824]
===
match
---
operator: { [23294,23295]
operator: { [23294,23295]
===
match
---
suite [93007,93037]
suite [93114,93144]
===
match
---
name: registered [53858,53868]
name: registered [53858,53868]
===
match
---
operator: = [31055,31056]
operator: = [31055,31056]
===
match
---
name: PodGenerator [81039,81051]
name: PodGenerator [81146,81158]
===
match
---
atom_expr [58241,58254]
atom_expr [58241,58254]
===
match
---
atom_expr [82716,82981]
atom_expr [82823,83088]
===
match
---
atom_expr [67932,67949]
atom_expr [68039,68056]
===
match
---
name: get_prev_data_interval_start_success [76361,76397]
name: get_prev_data_interval_start_success [76468,76504]
===
match
---
decorated [47736,52268]
decorated [47736,52268]
===
match
---
string: "\n" [43629,43633]
string: "\n" [43629,43633]
===
match
---
operator: , [78364,78365]
operator: , [78471,78472]
===
match
---
trailer [84872,84883]
trailer [84979,84990]
===
match
---
name: test_mode [51793,51802]
name: test_mode [51793,51802]
===
match
---
trailer [84946,84960]
trailer [85053,85067]
===
match
---
name: ds_nodash [77318,77327]
name: ds_nodash [77425,77434]
===
match
---
operator: = [92358,92359]
operator: = [92465,92466]
===
match
---
trailer [24245,24252]
trailer [24245,24252]
===
match
---
name: ignore_task_deps [61300,61316]
name: ignore_task_deps [61300,61316]
===
match
---
name: max_tries [82939,82948]
name: max_tries [83046,83055]
===
match
---
atom_expr [17807,17823]
atom_expr [17807,17823]
===
match
---
operator: , [12865,12866]
operator: , [12865,12866]
===
match
---
operator: = [83111,83112]
operator: = [83218,83219]
===
match
---
expr_stmt [57026,57068]
expr_stmt [57026,57068]
===
match
---
operator: = [6240,6241]
operator: = [6240,6241]
===
match
---
name: fd [4764,4766]
name: fd [4764,4766]
===
match
---
name: ti [91662,91664]
name: ti [91769,91771]
===
match
---
name: state [45610,45615]
name: state [45610,45615]
===
match
---
simple_stmt [3806,3843]
simple_stmt [3806,3843]
===
match
---
simple_stmt [67241,67268]
simple_stmt [67348,67375]
===
match
---
name: self [84850,84854]
name: self [84957,84961]
===
match
---
operator: ** [84103,84105]
operator: ** [84210,84212]
===
match
---
name: run_id [92267,92273]
name: run_id [92374,92380]
===
match
---
name: airflow [2765,2772]
name: airflow [2765,2772]
===
match
---
operator: , [1439,1440]
operator: , [1439,1440]
===
match
---
if_stmt [22332,22393]
if_stmt [22332,22393]
===
match
---
name: hr_line_break [46009,46022]
name: hr_line_break [46009,46022]
===
match
---
trailer [83072,83099]
trailer [83179,83206]
===
match
---
name: self [49313,49317]
name: self [49313,49317]
===
match
---
name: priority_weight [27586,27601]
name: priority_weight [27586,27601]
===
match
---
expr_stmt [65673,65694]
expr_stmt [65780,65801]
===
match
---
operator: , [60671,60672]
operator: , [60671,60672]
===
match
---
operator: , [5452,5453]
operator: , [5452,5453]
===
match
---
trailer [19278,19285]
trailer [19278,19285]
===
match
---
param [19773,19785]
param [19773,19785]
===
match
---
name: task [30092,30096]
name: task [30092,30096]
===
match
---
name: ForeignKeyConstraint [13294,13314]
name: ForeignKeyConstraint [13294,13314]
===
match
---
operator: , [28500,28501]
operator: , [28500,28501]
===
match
---
operator: , [63482,63483]
operator: , [63482,63483]
===
match
---
argument [43176,43194]
argument [43176,43194]
===
match
---
expr_stmt [39435,39484]
expr_stmt [39435,39484]
===
match
---
simple_stmt [64259,64279]
simple_stmt [64259,64279]
===
match
---
return_stmt [47205,47262]
return_stmt [47205,47262]
===
match
---
name: default_var [71167,71178]
name: default_var [71274,71285]
===
match
---
operator: , [45259,45260]
operator: , [45259,45260]
===
match
---
suite [71038,71203]
suite [71145,71310]
===
match
---
decorated [66169,66540]
decorated [66276,66647]
===
match
---
arglist [11224,11248]
arglist [11224,11248]
===
match
---
simple_stmt [90883,91070]
simple_stmt [90990,91177]
===
match
---
tfpdef [14115,14149]
tfpdef [14115,14149]
===
match
---
name: trigger_timeout [58713,58728]
name: trigger_timeout [58713,58728]
===
match
---
name: airflow [2816,2823]
name: airflow [2816,2823]
===
match
---
name: self [24241,24245]
name: self [24241,24245]
===
match
---
argument [70240,70263]
argument [70347,70370]
===
match
---
if_stmt [8284,8469]
if_stmt [8284,8469]
===
match
---
operator: = [36818,36819]
operator: = [36818,36819]
===
match
---
arglist [88563,88755]
arglist [88670,88862]
===
match
---
operator: = [41211,41212]
operator: = [41211,41212]
===
match
---
operator: ! [72423,72424]
operator: ! [72530,72531]
===
match
---
name: TaskInstance [24167,24179]
name: TaskInstance [24167,24179]
===
match
---
parameters [23057,23063]
parameters [23057,23063]
===
match
---
name: info [40629,40633]
name: info [40629,40633]
===
match
---
name: Optional [30630,30638]
name: Optional [30630,30638]
===
match
---
operator: = [18222,18223]
operator: = [18222,18223]
===
match
---
operator: , [70132,70133]
operator: , [70239,70240]
===
match
---
param [19919,19956]
param [19919,19956]
===
match
---
trailer [30489,30492]
trailer [30489,30492]
===
match
---
atom_expr [10150,10161]
atom_expr [10150,10161]
===
match
---
name: pickle_id [18793,18802]
name: pickle_id [18793,18802]
===
match
---
trailer [91257,91261]
trailer [91364,91368]
===
match
---
arglist [50615,50652]
arglist [50615,50652]
===
match
---
name: end_date [52050,52058]
name: end_date [52050,52058]
===
match
---
trailer [43151,43169]
trailer [43151,43169]
===
match
---
name: namespace [80969,80978]
name: namespace [81076,81085]
===
match
---
name: test_mode [66440,66449]
name: test_mode [66547,66556]
===
match
---
return_stmt [34539,34599]
return_stmt [34539,34599]
===
match
---
name: self [56079,56083]
name: self [56079,56083]
===
match
---
except_clause [49582,49610]
except_clause [49582,49610]
===
match
---
trailer [50187,50193]
trailer [50187,50193]
===
match
---
operator: , [70238,70239]
operator: , [70345,70346]
===
match
---
name: set_committed_value [1652,1671]
name: set_committed_value [1652,1671]
===
match
---
name: max_tries [6915,6924]
name: max_tries [6915,6924]
===
match
---
simple_stmt [9072,9364]
simple_stmt [9072,9364]
===
match
---
expr_stmt [67213,67232]
expr_stmt [67320,67339]
===
match
---
atom_expr [14297,14309]
atom_expr [14297,14309]
===
match
---
name: session [55024,55031]
name: session [55024,55031]
===
match
---
name: kube_config [80731,80742]
name: kube_config [80838,80849]
===
match
---
name: self [40729,40733]
name: self [40729,40733]
===
match
---
atom_expr [20226,20239]
atom_expr [20226,20239]
===
match
---
atom_expr [26677,26696]
atom_expr [26677,26696]
===
match
---
trailer [45609,45615]
trailer [45609,45615]
===
match
---
operator: = [44958,44959]
operator: = [44958,44959]
===
match
---
simple_stmt [62585,62619]
simple_stmt [62585,62619]
===
match
---
name: key [88606,88609]
name: key [88713,88716]
===
match
---
name: AirflowSkipException [2101,2121]
name: AirflowSkipException [2101,2121]
===
match
---
name: state [62998,63003]
name: state [62998,63003]
===
match
---
atom_expr [64319,64333]
atom_expr [64319,64333]
===
match
---
name: next_execution_date [73513,73532]
name: next_execution_date [73620,73639]
===
match
---
trailer [47331,47730]
trailer [47331,47730]
===
match
---
name: ti [6231,6233]
name: ti [6231,6233]
===
match
---
suite [50106,50227]
suite [50106,50227]
===
match
---
operator: * [38590,38591]
operator: * [38590,38591]
===
match
---
suite [15225,15323]
suite [15225,15323]
===
match
---
name: is_smart_sensor_compatible [53746,53772]
name: is_smart_sensor_compatible [53746,53772]
===
match
---
operator: , [50149,50150]
operator: , [50149,50150]
===
match
---
simple_stmt [86046,86241]
simple_stmt [86153,86348]
===
match
---
name: jinja_env [84065,84074]
name: jinja_env [84172,84181]
===
match
---
name: ti [92445,92447]
name: ti [92552,92554]
===
match
---
simple_stmt [92015,92110]
simple_stmt [92122,92217]
===
match
---
atom_expr [52572,52591]
atom_expr [52572,52591]
===
match
---
trailer [30313,30317]
trailer [30313,30317]
===
match
---
name: dep_context [37344,37355]
name: dep_context [37344,37355]
===
match
---
name: dep_status [37697,37707]
name: dep_status [37697,37707]
===
match
---
decorator [24894,24911]
decorator [24894,24911]
===
match
---
arglist [57387,57420]
arglist [57387,57420]
===
match
---
name: dep_status [36743,36753]
name: dep_status [36743,36753]
===
match
---
string: "Dependencies all met for %s" [37148,37177]
string: "Dependencies all met for %s" [37148,37177]
===
match
---
suite [18893,18949]
suite [18893,18949]
===
match
---
name: job_id [60944,60950]
name: job_id [60944,60950]
===
match
---
name: dag_run [79853,79860]
name: dag_run [79960,79967]
===
match
---
operator: = [67804,67805]
operator: = [67911,67912]
===
match
---
param [41498,41525]
param [41498,41525]
===
match
---
operator: , [85128,85129]
operator: , [85235,85236]
===
match
---
operator: ! [72214,72215]
operator: ! [72321,72322]
===
match
---
name: self [26195,26199]
name: self [26195,26199]
===
match
---
name: execution_date [72667,72681]
name: execution_date [72774,72788]
===
match
---
argument [88563,88592]
argument [88670,88699]
===
match
---
dotted_name [40756,40777]
dotted_name [40756,40777]
===
match
---
atom_expr [49045,49061]
atom_expr [49045,49061]
===
match
---
atom_expr [49253,49286]
atom_expr [49253,49286]
===
match
---
operator: = [33925,33926]
operator: = [33925,33926]
===
match
---
comparison [32108,32127]
comparison [32108,32127]
===
match
---
expr_stmt [27435,27451]
expr_stmt [27435,27451]
===
match
---
operator: } [53414,53415]
operator: } [53414,53415]
===
match
---
trailer [81192,81219]
trailer [81299,81326]
===
match
---
decorated [93498,93593]
decorated [93605,93700]
===
match
---
simple_stmt [30479,30496]
simple_stmt [30479,30496]
===
match
---
operator: = [63004,63005]
operator: = [63004,63005]
===
match
---
expr_stmt [39086,39363]
expr_stmt [39086,39363]
===
match
---
name: session [68349,68356]
name: session [68456,68463]
===
match
---
atom_expr [92380,92396]
atom_expr [92487,92503]
===
match
---
trailer [89340,89354]
trailer [89447,89461]
===
match
---
annassign [44821,44885]
annassign [44821,44885]
===
match
---
name: self [14355,14359]
name: self [14355,14359]
===
match
---
trailer [23432,23442]
trailer [23432,23442]
===
match
---
atom_expr [37537,37772]
atom_expr [37537,37772]
===
match
---
name: test_mode [46612,46621]
name: test_mode [46612,46621]
===
match
---
trailer [7100,7111]
trailer [7100,7111]
===
match
---
with_stmt [73592,73782]
with_stmt [73699,73889]
===
match
---
name: lazy_object_proxy [72546,72563]
name: lazy_object_proxy [72653,72670]
===
match
---
name: dag_id [80553,80559]
name: dag_id [80660,80666]
===
match
---
simple_stmt [2633,2694]
simple_stmt [2633,2694]
===
match
---
trailer [19150,19156]
trailer [19150,19156]
===
match
---
name: e [51790,51791]
name: e [51790,51791]
===
match
---
param [28577,28589]
param [28577,28589]
===
match
---
simple_stmt [28600,28798]
simple_stmt [28600,28798]
===
match
---
operator: = [48927,48928]
operator: = [48927,48928]
===
match
---
comparison [40860,40888]
comparison [40860,40888]
===
match
---
simple_stmt [17118,17142]
simple_stmt [17118,17142]
===
match
---
atom_expr [56563,56580]
atom_expr [56563,56580]
===
match
---
name: str [74713,74716]
name: str [74820,74823]
===
match
---
name: session [50877,50884]
name: session [50877,50884]
===
match
---
name: Optional [68924,68932]
name: Optional [69031,69039]
===
match
---
trailer [51681,51683]
trailer [51681,51683]
===
match
---
dotted_name [2539,2562]
dotted_name [2539,2562]
===
match
---
expr_stmt [68457,68496]
expr_stmt [68564,68603]
===
match
---
trailer [77291,77298]
trailer [77398,77405]
===
match
---
trailer [61648,61662]
trailer [61648,61662]
===
match
---
param [70829,70833]
param [70936,70940]
===
match
---
name: error_file [4944,4954]
name: error_file [4944,4954]
===
match
---
name: test_mode [46415,46424]
name: test_mode [46415,46424]
===
match
---
simple_stmt [74267,74277]
simple_stmt [74374,74384]
===
match
---
atom_expr [50123,50157]
atom_expr [50123,50157]
===
match
---
atom_expr [22789,22817]
atom_expr [22789,22817]
===
match
---
atom_expr [8148,8170]
atom_expr [8148,8170]
===
match
---
operator: , [10134,10135]
operator: , [10134,10135]
===
match
---
trailer [12065,12074]
trailer [12065,12074]
===
match
---
trailer [34156,34175]
trailer [34156,34175]
===
match
---
param [62094,62098]
param [62094,62098]
===
match
---
atom_expr [26739,26759]
atom_expr [26739,26759]
===
match
---
trailer [46353,46368]
trailer [46353,46368]
===
match
---
parameters [30599,30700]
parameters [30599,30700]
===
match
---
term [43637,43645]
term [43637,43645]
===
match
---
name: DepContext [2800,2810]
name: DepContext [2800,2810]
===
match
---
funcdef [69689,69741]
funcdef [69796,69848]
===
match
---
name: next_kwargs [26969,26980]
name: next_kwargs [26969,26980]
===
match
---
suite [26994,27025]
suite [26994,27025]
===
match
---
tfpdef [63492,63517]
tfpdef [63492,63517]
===
match
---
operator: = [19699,19700]
operator: = [19699,19700]
===
match
---
name: _priority_weight [93576,93592]
name: _priority_weight [93683,93699]
===
match
---
atom_expr [86359,86370]
atom_expr [86466,86477]
===
match
---
string: "--subdir" [22914,22924]
string: "--subdir" [22914,22924]
===
match
---
operator: = [68719,68720]
operator: = [68826,68827]
===
match
---
name: bool [19983,19987]
name: bool [19983,19987]
===
match
---
name: are_dependencies_met [35866,35886]
name: are_dependencies_met [35866,35886]
===
match
---
atom_expr [20297,20306]
atom_expr [20297,20306]
===
match
---
name: self [27539,27543]
name: self [27539,27543]
===
match
---
not_test [66089,66102]
not_test [66196,66209]
===
match
---
name: self [52572,52576]
name: self [52572,52576]
===
match
---
name: int [20093,20096]
name: int [20093,20096]
===
match
---
name: try_number [66866,66876]
name: try_number [66973,66983]
===
match
---
name: id [57992,57994]
name: id [57992,57994]
===
match
---
name: provide_session [62320,62335]
name: provide_session [62320,62335]
===
match
---
simple_stmt [43375,43391]
simple_stmt [43375,43391]
===
match
---
atom_expr [26020,26028]
atom_expr [26020,26028]
===
match
---
atom_expr [4968,4989]
atom_expr [4968,4989]
===
match
---
name: task_id [86331,86338]
name: task_id [86438,86445]
===
match
---
atom_expr [34409,34461]
atom_expr [34409,34461]
===
match
---
string: 'BASE_URL' [23198,23208]
string: 'BASE_URL' [23198,23208]
===
match
---
expr_stmt [90560,90581]
expr_stmt [90667,90688]
===
match
---
trailer [89656,89670]
trailer [89763,89777]
===
match
---
trailer [76244,76252]
trailer [76351,76359]
===
match
---
trailer [14228,14237]
trailer [14228,14237]
===
match
---
name: execution_date [23129,23143]
name: execution_date [23129,23143]
===
match
---
name: pid [43380,43383]
name: pid [43380,43383]
===
match
---
trailer [52102,52104]
trailer [52102,52104]
===
match
---
atom_expr [59439,59449]
atom_expr [59439,59449]
===
match
---
suite [66388,66540]
suite [66495,66647]
===
match
---
operator: = [43189,43190]
operator: = [43189,43190]
===
match
---
arith_expr [23514,23763]
arith_expr [23514,23763]
===
match
---
atom_expr [91433,91685]
atom_expr [91540,91792]
===
match
---
name: str [59218,59221]
name: str [59218,59221]
===
match
---
name: str [47910,47913]
name: str [47910,47913]
===
match
---
name: context [60407,60414]
name: context [60407,60414]
===
match
---
trailer [80695,80706]
trailer [80802,80813]
===
match
---
trailer [93876,93882]
trailer [93983,93989]
===
match
---
name: key [76126,76129]
name: key [76233,76236]
===
match
---
funcdef [17949,19720]
funcdef [17949,19720]
===
match
---
simple_stmt [90436,90452]
simple_stmt [90543,90559]
===
match
---
parameters [70919,71037]
parameters [71026,71144]
===
match
---
expr_stmt [56008,56063]
expr_stmt [56008,56063]
===
match
---
trailer [25736,25752]
trailer [25736,25752]
===
match
---
atom_expr [59853,59863]
atom_expr [59853,59863]
===
match
---
atom [22128,22180]
atom [22128,22180]
===
match
---
name: association_proxy [14029,14046]
name: association_proxy [14029,14046]
===
match
---
simple_stmt [73716,73782]
simple_stmt [73823,73889]
===
match
---
name: dill [1187,1191]
name: dill [1187,1191]
===
match
---
name: error_file [51199,51209]
name: error_file [51199,51209]
===
match
---
name: render_k8s_pod_yaml [80284,80303]
name: render_k8s_pod_yaml [80391,80410]
===
match
---
trailer [40665,40671]
trailer [40665,40671]
===
match
---
operator: = [60779,60780]
operator: = [60779,60780]
===
match
---
simple_stmt [48913,48944]
simple_stmt [48913,48944]
===
match
---
arglist [49813,50062]
arglist [49813,50062]
===
match
---
with_stmt [56975,57069]
with_stmt [56975,57069]
===
match
---
param [10217,10222]
param [10217,10222]
===
match
---
name: self [54401,54405]
name: self [54401,54405]
===
match
---
fstring_start: f" [23562,23564]
fstring_start: f" [23562,23564]
===
match
---
name: defaultdict [5951,5962]
name: defaultdict [5951,5962]
===
match
---
trailer [72803,72811]
trailer [72910,72918]
===
match
---
name: error [63378,63383]
name: error [63378,63383]
===
match
---
string: 'TaskInstance' [32531,32545]
string: 'TaskInstance' [32531,32545]
===
match
---
import_name [871,884]
import_name [871,884]
===
match
---
name: dep_status [37842,37852]
name: dep_status [37842,37852]
===
match
---
name: key [76643,76646]
name: key [76750,76753]
===
match
---
atom_expr [5296,5323]
atom_expr [5296,5323]
===
match
---
simple_stmt [23112,23157]
simple_stmt [23112,23157]
===
match
---
operator: -> [68661,68663]
operator: -> [68768,68770]
===
match
---
param [58854,58859]
param [58854,58859]
===
match
---
name: self [63364,63368]
name: self [63364,63368]
===
match
---
simple_stmt [92333,92372]
simple_stmt [92440,92479]
===
match
---
param [86676,86710]
param [86783,86817]
===
match
---
suite [22776,22818]
suite [22776,22818]
===
match
---
name: subject [84373,84380]
name: subject [84480,84487]
===
match
---
expr_stmt [40826,40925]
expr_stmt [40826,40925]
===
match
---
suite [24566,24889]
suite [24566,24889]
===
match
---
operator: , [46467,46468]
operator: , [46467,46468]
===
match
---
trailer [65961,65968]
trailer [66068,66075]
===
match
---
name: provide_session [29545,29560]
name: provide_session [29545,29560]
===
match
---
name: dep [37398,37401]
name: dep [37398,37401]
===
match
---
argument [19592,19606]
argument [19592,19606]
===
match
---
trailer [4386,4394]
trailer [4386,4394]
===
match
---
suite [63642,63682]
suite [63642,63682]
===
match
---
operator: == [91211,91213]
operator: == [91318,91320]
===
match
---
name: bool [66981,66985]
name: bool [67088,67092]
===
match
---
trailer [75246,75273]
trailer [75353,75380]
===
match
---
name: self [29230,29234]
name: self [29230,29234]
===
match
---
atom_expr [17157,17173]
atom_expr [17157,17173]
===
match
---
atom_expr [56079,56095]
atom_expr [56079,56095]
===
match
---
name: session [51835,51842]
name: session [51835,51842]
===
match
---
dotted_name [1554,1568]
dotted_name [1554,1568]
===
match
---
decorator [62319,62336]
decorator [62319,62336]
===
match
---
number: 1 [63176,63177]
number: 1 [63176,63177]
===
match
---
operator: , [44251,44252]
operator: , [44251,44252]
===
match
---
string: 'Host: {{ti.hostname}}<br>' [82385,82412]
string: 'Host: {{ti.hostname}}<br>' [82492,82519]
===
match
---
trailer [59872,59880]
trailer [59872,59880]
===
match
---
name: kube_config [3626,3637]
name: kube_config [3626,3637]
===
match
---
name: task [77206,77210]
name: task [77313,77317]
===
match
---
name: result [54673,54679]
name: result [54673,54679]
===
match
---
atom_expr [9007,9062]
atom_expr [9007,9062]
===
match
---
trailer [51930,51996]
trailer [51930,51996]
===
match
---
name: State [68326,68331]
name: State [68433,68438]
===
match
---
atom [56562,56599]
atom [56562,56599]
===
match
---
funcdef [57470,58823]
funcdef [57470,58823]
===
match
---
name: generate_command [19747,19763]
name: generate_command [19747,19763]
===
match
---
name: error [66423,66428]
name: error [66530,66535]
===
match
---
atom_expr [92282,92298]
atom_expr [92389,92405]
===
match
---
trailer [62875,62884]
trailer [62875,62884]
===
match
---
atom_expr [14221,14239]
atom_expr [14221,14239]
===
match
---
expr_stmt [16011,16036]
expr_stmt [16011,16036]
===
match
---
name: force_fail [51182,51192]
name: force_fail [51182,51192]
===
match
---
operator: = [62419,62420]
operator: = [62419,62420]
===
match
---
operator: , [53023,53024]
operator: , [53023,53024]
===
match
---
import_from [8304,8345]
import_from [8304,8345]
===
match
---
name: kube_image [80720,80730]
name: kube_image [80827,80837]
===
match
---
name: deps [37434,37438]
name: deps [37434,37438]
===
match
---
name: and_ [9176,9180]
name: and_ [9176,9180]
===
match
---
name: str [92439,92442]
name: str [92546,92549]
===
match
---
trailer [63248,63253]
trailer [63248,63253]
===
match
---
trailer [37807,37814]
trailer [37807,37814]
===
match
---
name: task [62157,62161]
name: task [62157,62161]
===
match
---
operator: , [13335,13336]
operator: , [13335,13336]
===
match
---
import_from [78200,78270]
import_from [78307,78377]
===
match
---
name: math [842,846]
name: math [842,846]
===
match
---
trailer [22792,22799]
trailer [22792,22799]
===
match
---
argument [49518,49533]
argument [49518,49533]
===
match
---
name: start [68865,68870]
name: start [68972,68977]
===
match
---
simple_stmt [6410,6439]
simple_stmt [6410,6439]
===
match
---
name: execution_date [39229,39243]
name: execution_date [39229,39243]
===
match
---
name: ignore_ti_state [44005,44020]
name: ignore_ti_state [44005,44020]
===
match
---
atom_expr [52061,52078]
atom_expr [52061,52078]
===
match
---
atom_expr [46450,46474]
atom_expr [46450,46474]
===
match
---
trailer [22746,22759]
trailer [22746,22759]
===
match
---
operator: { [52860,52861]
operator: { [52860,52861]
===
match
---
operator: , [76151,76152]
operator: , [76258,76259]
===
match
---
not_test [43427,43446]
not_test [43427,43446]
===
match
---
name: self [23808,23812]
name: self [23808,23812]
===
match
---
suite [72365,72437]
suite [72472,72544]
===
match
---
atom_expr [59777,59839]
atom_expr [59777,59839]
===
match
---
name: result [57192,57198]
name: result [57192,57198]
===
match
---
atom_expr [39151,39298]
atom_expr [39151,39298]
===
match
---
trailer [52982,52988]
trailer [52982,52988]
===
match
---
trailer [58052,58064]
trailer [58052,58064]
===
match
---
operator: , [47576,47577]
operator: , [47576,47577]
===
match
---
simple_stmt [1889,1928]
simple_stmt [1889,1928]
===
match
---
name: utcnow [46068,46074]
name: utcnow [46068,46074]
===
match
---
decorated [93430,93493]
decorated [93537,93600]
===
match
---
atom_expr [25519,25538]
atom_expr [25519,25538]
===
match
---
comparison [56844,56864]
comparison [56844,56864]
===
match
---
simple_stmt [80186,80224]
simple_stmt [80293,80331]
===
match
---
param [41460,41489]
param [41460,41489]
===
match
---
name: test_mode [51600,51609]
name: test_mode [51600,51609]
===
match
---
trailer [24440,24443]
trailer [24440,24443]
===
match
---
name: self [89985,89989]
name: self [90092,90096]
===
match
---
name: task [67918,67922]
name: task [68025,68029]
===
match
---
trailer [27543,27554]
trailer [27543,27554]
===
match
---
name: execution_timeout [58513,58530]
name: execution_timeout [58513,58530]
===
match
---
name: self [80888,80892]
name: self [80995,80999]
===
match
---
operator: , [86568,86569]
operator: , [86675,86676]
===
match
---
name: primaryjoin [13766,13777]
name: primaryjoin [13766,13777]
===
match
---
name: end_date [40128,40136]
name: end_date [40128,40136]
===
match
---
operator: == [40874,40876]
operator: == [40874,40876]
===
match
---
trailer [35330,35349]
trailer [35330,35349]
===
match
---
operator: = [5470,5471]
operator: = [5470,5471]
===
match
---
name: dr [40826,40828]
name: dr [40826,40828]
===
match
---
operator: = [58785,58786]
operator: = [58785,58786]
===
match
---
argument [56158,56176]
argument [56158,56176]
===
match
---
suite [59881,60210]
suite [59881,60210]
===
match
---
name: ignore_ti_state [43431,43446]
name: ignore_ti_state [43431,43446]
===
match
---
name: context [54506,54513]
name: context [54506,54513]
===
match
---
operator: = [26718,26719]
operator: = [26718,26719]
===
match
---
import_from [1008,1047]
import_from [1008,1047]
===
match
---
trailer [35241,35261]
trailer [35241,35261]
===
match
---
name: self [32942,32946]
name: self [32942,32946]
===
match
---
name: self [86326,86330]
name: self [86433,86437]
===
match
---
name: Union [4968,4973]
name: Union [4968,4973]
===
match
---
name: timer [52829,52834]
name: timer [52829,52834]
===
match
---
name: COLLATION_ARGS [11322,11336]
name: COLLATION_ARGS [11322,11336]
===
match
---
tfpdef [47893,47914]
tfpdef [47893,47914]
===
match
---
name: from_string [83163,83174]
name: from_string [83270,83281]
===
match
---
operator: = [70251,70252]
operator: = [70358,70359]
===
match
---
name: property [23315,23323]
name: property [23315,23323]
===
match
---
name: read [4767,4771]
name: read [4767,4771]
===
match
---
operator: , [53426,53427]
operator: , [53426,53427]
===
match
---
expr_stmt [34470,34530]
expr_stmt [34470,34530]
===
match
---
name: RUNNING [89842,89849]
name: RUNNING [89949,89956]
===
match
---
operator: -> [61038,61040]
operator: -> [61038,61040]
===
match
---
trailer [84220,84267]
trailer [84327,84374]
===
match
---
operator: , [63876,63877]
operator: , [63876,63877]
===
match
---
simple_stmt [71952,71972]
simple_stmt [72059,72079]
===
match
---
funcdef [9780,9940]
funcdef [9780,9940]
===
match
---
name: task [59926,59930]
name: task [59926,59930]
===
match
---
simple_stmt [53062,53135]
simple_stmt [53062,53135]
===
match
---
name: state [24444,24449]
name: state [24444,24449]
===
match
---
name: get_prev_start_date_success [77121,77148]
name: get_prev_start_date_success [77228,77255]
===
match
---
operator: = [66422,66423]
operator: = [66529,66530]
===
match
---
operator: } [72216,72217]
operator: } [72323,72324]
===
match
---
trailer [6984,6990]
trailer [6984,6990]
===
match
---
string: """Key used to identify task instance.""" [9645,9686]
string: """Key used to identify task instance.""" [9645,9686]
===
match
---
name: are_dependencies_met [44174,44194]
name: are_dependencies_met [44174,44194]
===
match
---
atom_expr [29158,29207]
atom_expr [29158,29207]
===
match
---
expr_stmt [74205,74223]
expr_stmt [74312,74330]
===
match
---
name: self [83716,83720]
name: self [83823,83827]
===
match
---
argument [61414,61433]
argument [61414,61433]
===
match
---
trailer [37490,37518]
trailer [37490,37518]
===
match
---
trailer [63671,63681]
trailer [63671,63681]
===
match
---
string: """         Set TaskInstance state.          :param state: State to set for the TI         :type state: str         :param session: SQLAlchemy ORM Session         :type session: Session         """ [28600,28797]
string: """         Set TaskInstance state.          :param state: State to set for the TI         :type state: str         :param session: SQLAlchemy ORM Session         :type session: Session         """ [28600,28797]
===
match
---
argument [45238,45259]
argument [45238,45259]
===
match
---
string: "execution date %s has no timezone information. Using default from dag or system" [15049,15130]
string: "execution date %s has no timezone information. Using default from dag or system" [15049,15130]
===
match
---
atom_expr [47901,47914]
atom_expr [47901,47914]
===
match
---
name: Proxy [72564,72569]
name: Proxy [72671,72676]
===
match
---
name: timezone [15452,15460]
name: timezone [15452,15460]
===
match
---
atom_expr [64081,64114]
atom_expr [64081,64114]
===
match
---
name: info [47015,47019]
name: info [47015,47019]
===
match
---
name: innerjoin [13665,13674]
name: innerjoin [13665,13674]
===
match
---
expr_stmt [26282,26309]
expr_stmt [26282,26309]
===
match
---
import_name [885,900]
import_name [885,900]
===
match
---
name: self_execution_date [86417,86436]
name: self_execution_date [86524,86543]
===
match
---
atom [81851,82147]
atom [81958,82254]
===
match
---
expr_stmt [19096,19123]
expr_stmt [19096,19123]
===
match
---
if_stmt [46837,47074]
if_stmt [46837,47074]
===
match
---
atom_expr [47688,47719]
atom_expr [47688,47719]
===
match
---
decorated [71620,71972]
decorated [71727,72079]
===
match
---
fstring_start: f" [72276,72278]
fstring_start: f" [72383,72385]
===
match
---
string: """         Copy common attributes from the given task.          :param task: The task object to copy from         :type task: airflow.models.BaseOperator         :param pool_override: Use the pool_override instead of task's pool         :type pool_override: str         """ [27152,27426]
string: """         Copy common attributes from the given task.          :param task: The task object to copy from         :type task: airflow.models.BaseOperator         :param pool_override: Use the pool_override instead of task's pool         :type pool_override: str         """ [27152,27426]
===
match
---
suite [6607,6970]
suite [6607,6970]
===
match
---
string: '%Y%m%dT%H%M%S' [47228,47243]
string: '%Y%m%dT%H%M%S' [47228,47243]
===
match
---
expr_stmt [62993,63029]
expr_stmt [62993,63029]
===
match
---
operator: = [38552,38553]
operator: = [38552,38553]
===
match
---
name: html_content [83228,83240]
name: html_content [83335,83347]
===
match
---
atom_expr [11548,11561]
atom_expr [11548,11561]
===
match
---
simple_stmt [55121,55204]
simple_stmt [55121,55204]
===
match
---
atom_expr [4729,4752]
atom_expr [4729,4752]
===
match
---
comparison [32862,32876]
comparison [32862,32876]
===
match
---
param [20220,20247]
param [20220,20247]
===
match
---
trailer [11399,11425]
trailer [11399,11425]
===
match
---
trailer [23299,23306]
trailer [23299,23306]
===
match
---
name: context [4362,4369]
name: context [4362,4369]
===
match
---
expr_stmt [15983,16002]
expr_stmt [15983,16002]
===
match
---
string: 'Log: <a href="{{ti.log_url}}">Link</a><br>' [81978,82022]
string: 'Log: <a href="{{ti.log_url}}">Link</a><br>' [82085,82129]
===
match
---
atom_expr [31712,31733]
atom_expr [31712,31733]
===
match
---
name: task_id [6327,6334]
name: task_id [6327,6334]
===
match
---
lambdef [76848,76926]
lambdef [76955,77033]
===
match
---
name: provide_session [41110,41125]
name: provide_session [41110,41125]
===
match
---
name: state [33975,33980]
name: state [33975,33980]
===
match
---
operator: , [19955,19956]
operator: , [19955,19956]
===
match
---
atom_expr [85192,85210]
atom_expr [85299,85317]
===
match
---
operator: = [6335,6336]
operator: = [6335,6336]
===
match
---
name: run_as_user [92632,92643]
name: run_as_user [92739,92750]
===
match
---
atom_expr [11977,11997]
atom_expr [11977,11997]
===
match
---
operator: @ [41109,41110]
operator: @ [41109,41110]
===
match
---
name: state [9402,9407]
name: state [9402,9407]
===
match
---
atom_expr [52610,52658]
atom_expr [52610,52658]
===
match
---
trailer [45220,45486]
trailer [45220,45486]
===
match
---
simple_stmt [78526,78573]
simple_stmt [78633,78680]
===
match
---
number: 1 [38992,38993]
number: 1 [38992,38993]
===
match
---
name: log [54042,54045]
name: log [54042,54045]
===
match
---
name: TaskInstance [91726,91738]
name: TaskInstance [91833,91845]
===
match
---
trailer [81133,81151]
trailer [81240,81258]
===
match
---
name: str [70053,70056]
name: str [70160,70163]
===
match
---
suite [61046,62077]
suite [61046,62077]
===
match
---
name: self [92239,92243]
name: self [92346,92350]
===
match
---
name: default_var [70240,70251]
name: default_var [70347,70358]
===
match
---
suite [61543,61563]
suite [61543,61563]
===
match
---
param [18051,18074]
param [18051,18074]
===
match
---
operator: , [18111,18112]
operator: , [18111,18112]
===
match
---
suite [55253,57444]
suite [55253,57444]
===
match
---
name: airflow_context_vars [53220,53240]
name: airflow_context_vars [53220,53240]
===
match
---
name: dirname [83081,83088]
name: dirname [83188,83195]
===
match
---
name: _run_raw_task [47787,47800]
name: _run_raw_task [47787,47800]
===
match
---
trailer [44946,44957]
trailer [44946,44957]
===
match
---
expr_stmt [92282,92324]
expr_stmt [92389,92431]
===
match
---
name: run_id [7115,7121]
name: run_id [7115,7121]
===
match
---
simple_stmt [54401,54437]
simple_stmt [54401,54437]
===
match
---
trailer [90838,90845]
trailer [90945,90952]
===
match
---
atom_expr [58671,58686]
atom_expr [58671,58686]
===
match
---
name: self [92128,92132]
name: self [92235,92239]
===
match
---
trailer [58311,58318]
trailer [58311,58318]
===
match
---
name: self [51770,51774]
name: self [51770,51774]
===
match
---
comparison [14432,14458]
comparison [14432,14458]
===
match
---
name: lazy [13976,13980]
name: lazy [13976,13980]
===
match
---
argument [82872,82902]
argument [82979,83009]
===
match
---
operator: -> [74175,74177]
operator: -> [74282,74284]
===
match
---
atom_expr [46519,46544]
atom_expr [46519,46544]
===
match
---
simple_stmt [92652,92678]
simple_stmt [92759,92785]
===
match
---
name: ti [26257,26259]
name: ti [26257,26259]
===
match
---
simple_stmt [12002,12036]
simple_stmt [12002,12036]
===
match
---
trailer [11519,11532]
trailer [11519,11532]
===
match
---
return_stmt [89622,89896]
return_stmt [89729,90003]
===
match
---
trailer [9401,9407]
trailer [9401,9407]
===
match
---
parameters [93689,93695]
parameters [93796,93802]
===
match
---
arglist [75882,76000]
arglist [75989,76107]
===
match
---
atom_expr [75495,75540]
atom_expr [75602,75647]
===
match
---
operator: , [60740,60741]
operator: , [60740,60741]
===
match
---
name: session [24844,24851]
name: session [24844,24851]
===
match
---
return_stmt [70787,70802]
return_stmt [70894,70909]
===
match
---
simple_stmt [11289,11373]
simple_stmt [11289,11373]
===
match
---
name: getattr [47153,47160]
name: getattr [47153,47160]
===
match
---
operator: = [27787,27788]
operator: = [27787,27788]
===
match
---
operator: , [9912,9913]
operator: , [9912,9913]
===
match
---
expr_stmt [89328,89374]
expr_stmt [89435,89481]
===
match
---
expr_stmt [57962,57994]
expr_stmt [57962,57994]
===
match
---
operator: == [24238,24240]
operator: == [24238,24240]
===
match
---
atom_expr [59212,59233]
atom_expr [59212,59233]
===
match
---
trailer [9905,9912]
trailer [9905,9912]
===
match
---
if_stmt [74236,74277]
if_stmt [74343,74384]
===
match
---
name: UP_FOR_RETRY [60243,60255]
name: UP_FOR_RETRY [60243,60255]
===
match
---
trailer [84648,84654]
trailer [84755,84761]
===
match
---
operator: = [44223,44224]
operator: = [44223,44224]
===
match
---
atom_expr [12793,12829]
atom_expr [12793,12829]
===
match
---
annassign [25706,25762]
annassign [25706,25762]
===
match
---
simple_stmt [39435,39485]
simple_stmt [39435,39485]
===
match
---
operator: , [60786,60787]
operator: , [60786,60787]
===
match
---
operator: @ [60629,60630]
operator: @ [60629,60630]
===
match
---
atom_expr [52956,53049]
atom_expr [52956,53049]
===
match
---
fstring [23601,23625]
fstring [23601,23625]
===
match
---
simple_stmt [74961,74985]
simple_stmt [75068,75092]
===
match
---
decorated [16598,17178]
decorated [16598,17178]
===
match
---
name: self [48838,48842]
name: self [48838,48842]
===
match
---
operator: = [32048,32049]
operator: = [32048,32049]
===
match
---
name: get_prev_ds_nodash [76623,76641]
name: get_prev_ds_nodash [76730,76748]
===
match
---
string: 'prev_data_interval_start_success' [77007,77041]
string: 'prev_data_interval_start_success' [77114,77148]
===
match
---
operator: = [43127,43128]
operator: = [43127,43128]
===
match
---
trailer [34417,34423]
trailer [34417,34423]
===
match
---
atom_expr [63156,63172]
atom_expr [63156,63172]
===
match
---
simple_stmt [26607,26641]
simple_stmt [26607,26641]
===
match
---
name: info [47327,47331]
name: info [47327,47331]
===
match
---
raise_stmt [86046,86240]
raise_stmt [86153,86347]
===
match
---
return_stmt [75098,78058]
return_stmt [75205,78165]
===
match
---
name: ts [77597,77599]
name: ts [77704,77706]
===
match
---
name: models [2256,2262]
name: models [2256,2262]
===
match
---
name: cache [72597,72602]
name: cache [72704,72709]
===
match
---
name: on_kill [52582,52589]
name: on_kill [52582,52589]
===
match
---
atom_expr [47507,47525]
atom_expr [47507,47525]
===
match
---
operator: , [1111,1112]
operator: , [1111,1112]
===
match
---
name: self [17077,17081]
name: self [17077,17081]
===
match
---
name: property [93499,93507]
name: property [93606,93614]
===
match
---
operator: == [44762,44764]
operator: == [44762,44764]
===
match
---
name: _run_as_user [92614,92626]
name: _run_as_user [92721,92733]
===
match
---
funcdef [27089,27804]
funcdef [27089,27804]
===
match
---
param [41586,41599]
param [41586,41599]
===
match
---
name: make_aware [15391,15401]
name: make_aware [15391,15401]
===
match
---
atom_expr [80979,81009]
atom_expr [81086,81116]
===
match
---
fstring_expr [23258,23263]
fstring_expr [23258,23263]
===
match
---
name: last_dagrun [32334,32345]
name: last_dagrun [32334,32345]
===
match
---
name: state [59858,59863]
name: state [59858,59863]
===
match
---
name: outlets [76245,76252]
name: outlets [76352,76359]
===
match
---
trailer [9033,9040]
trailer [9033,9040]
===
match
---
name: bool [66304,66308]
name: bool [66411,66415]
===
match
---
operator: , [37177,37178]
operator: , [37177,37178]
===
match
---
comparison [75000,75015]
comparison [75107,75122]
===
match
---
if_stmt [89387,89448]
if_stmt [89494,89555]
===
match
---
name: str [20134,20137]
name: str [20134,20137]
===
match
---
operator: == [24291,24293]
operator: == [24291,24293]
===
match
---
trailer [7628,8180]
trailer [7628,8180]
===
match
---
name: item [70937,70941]
name: item [71044,71048]
===
match
---
string: '-' [72812,72815]
string: '-' [72919,72922]
===
match
---
argument [45532,45555]
argument [45532,45555]
===
match
---
number: 1 [46329,46330]
number: 1 [46329,46330]
===
match
---
operator: , [10398,10399]
operator: , [10398,10399]
===
match
---
atom_expr [5308,5318]
atom_expr [5308,5318]
===
match
---
operator: , [36985,36986]
operator: , [36985,36986]
===
match
---
if_stmt [85974,86241]
if_stmt [86081,86348]
===
match
---
name: self [67654,67658]
name: self [67761,67765]
===
match
---
name: self [93690,93694]
name: self [93797,93801]
===
match
---
name: activate_dag_runs [8749,8766]
name: activate_dag_runs [8749,8766]
===
match
---
dotted_name [78205,78236]
dotted_name [78312,78343]
===
match
---
atom_expr [13073,13107]
atom_expr [13073,13107]
===
match
---
trailer [30257,30264]
trailer [30257,30264]
===
match
---
name: item [71671,71675]
name: item [71778,71782]
===
match
---
simple_stmt [51577,51651]
simple_stmt [51577,51651]
===
match
---
operator: = [61387,61388]
operator: = [61387,61388]
===
match
---
atom_expr [10107,10191]
atom_expr [10107,10191]
===
match
---
name: _try_number [46382,46393]
name: _try_number [46382,46393]
===
match
---
name: dag_model [13497,13506]
name: dag_model [13497,13506]
===
match
---
name: error_file [51804,51814]
name: error_file [51804,51814]
===
match
---
name: first_task_id [91326,91339]
name: first_task_id [91433,91446]
===
match
---
trailer [20301,20306]
trailer [20301,20306]
===
match
---
trailer [80644,80651]
trailer [80751,80758]
===
match
---
atom_expr [62585,62598]
atom_expr [62585,62598]
===
match
---
atom_expr [89760,89780]
atom_expr [89867,89887]
===
match
---
string: 'ti' [77384,77388]
string: 'ti' [77491,77495]
===
match
---
name: self [46951,46955]
name: self [46951,46955]
===
match
---
name: COLLATION_ARGS [11234,11248]
name: COLLATION_ARGS [11234,11248]
===
match
---
arglist [49740,49768]
arglist [49740,49768]
===
match
---
name: data [4785,4789]
name: data [4785,4789]
===
match
---
name: warn [35524,35528]
name: warn [35524,35528]
===
match
---
atom_expr [16533,16547]
atom_expr [16533,16547]
===
match
---
trailer [91026,91030]
trailer [91133,91137]
===
match
---
import_from [1247,1304]
import_from [1247,1304]
===
match
---
name: str [93393,93396]
name: str [93500,93503]
===
match
---
operator: = [32963,32964]
operator: = [32963,32964]
===
match
---
expr_stmt [26513,26554]
expr_stmt [26513,26554]
===
match
---
trailer [54707,54758]
trailer [54707,54758]
===
match
---
operator: = [68464,68465]
operator: = [68571,68572]
===
match
---
return_stmt [70214,70264]
return_stmt [70321,70371]
===
match
---
suite [74411,74481]
suite [74518,74588]
===
match
---
tfpdef [70964,70980]
tfpdef [71071,71087]
===
match
---
name: Union [4615,4620]
name: Union [4615,4620]
===
match
---
funcdef [60650,62077]
funcdef [60650,62077]
===
match
---
name: queued_dttm [12002,12013]
name: queued_dttm [12002,12013]
===
match
---
decorator [93360,93370]
decorator [93467,93477]
===
match
---
operator: , [18206,18207]
operator: , [18206,18207]
===
match
---
suite [72114,72587]
suite [72221,72694]
===
match
---
arith_expr [40123,40144]
arith_expr [40123,40144]
===
match
---
name: UP_FOR_RESCHEDULE [63012,63029]
name: UP_FOR_RESCHEDULE [63012,63029]
===
match
---
name: ready_for_retry [40154,40169]
name: ready_for_retry [40154,40169]
===
match
---
name: pendulum [73118,73126]
name: pendulum [73225,73233]
===
match
---
expr_stmt [11836,11891]
expr_stmt [11836,11891]
===
match
---
operator: = [32177,32178]
operator: = [32177,32178]
===
match
---
name: name [13205,13209]
name: name [13205,13209]
===
match
---
trailer [89826,89832]
trailer [89933,89939]
===
match
---
expr_stmt [25789,25805]
expr_stmt [25789,25805]
===
match
---
operator: , [86304,86305]
operator: , [86411,86412]
===
match
---
trailer [76354,76360]
trailer [76461,76467]
===
match
---
name: provide_session [89454,89469]
name: provide_session [89561,89576]
===
match
---
name: ts [67999,68001]
name: ts [68106,68108]
===
match
---
name: job_id [41460,41466]
name: job_id [41460,41466]
===
match
---
return_stmt [68568,68608]
return_stmt [68675,68715]
===
match
---
operator: = [76917,76918]
operator: = [77024,77025]
===
match
---
trailer [83088,83098]
trailer [83195,83205]
===
match
---
trailer [46670,46677]
trailer [46670,46677]
===
match
---
name: Stats [2754,2759]
name: Stats [2754,2759]
===
match
---
trailer [26517,26533]
trailer [26517,26533]
===
match
---
name: exception [59786,59795]
name: exception [59786,59795]
===
match
---
operator: = [13918,13919]
operator: = [13918,13919]
===
match
---
trailer [5440,5469]
trailer [5440,5469]
===
match
---
operator: = [43319,43320]
operator: = [43319,43320]
===
match
---
name: str [19781,19784]
name: str [19781,19784]
===
match
---
trailer [83055,83072]
trailer [83162,83179]
===
match
---
trailer [69342,69358]
trailer [69449,69465]
===
match
---
simple_stmt [27773,27804]
simple_stmt [27773,27804]
===
match
---
name: State [65539,65544]
name: State [65646,65651]
===
match
---
name: self [27850,27854]
name: self [27850,27854]
===
match
---
name: _run_as_user [92523,92535]
name: _run_as_user [92630,92642]
===
match
---
fstring [53410,53420]
fstring [53410,53420]
===
match
---
comparison [73797,73824]
comparison [73904,73931]
===
match
---
atom_expr [92652,92662]
atom_expr [92759,92769]
===
match
---
return_stmt [9894,9939]
return_stmt [9894,9939]
===
match
---
trailer [8395,8420]
trailer [8395,8420]
===
match
---
atom_expr [58667,58729]
atom_expr [58667,58729]
===
match
---
suite [5494,9604]
suite [5494,9604]
===
match
---
name: state [30623,30628]
name: state [30623,30628]
===
match
---
param [27856,27868]
param [27856,27868]
===
match
---
operator: = [59573,59574]
operator: = [59573,59574]
===
match
---
suite [24986,27084]
suite [24986,27084]
===
match
---
simple_stmt [51856,51873]
simple_stmt [51856,51873]
===
match
---
name: func [1445,1449]
name: func [1445,1449]
===
match
---
name: add [52179,52182]
name: add [52179,52182]
===
match
---
trailer [92243,92251]
trailer [92350,92358]
===
match
---
return_stmt [69962,69982]
return_stmt [70069,70089]
===
match
---
operator: , [91512,91513]
operator: , [91619,91620]
===
match
---
name: self [92609,92613]
name: self [92716,92720]
===
match
---
parameters [40443,40474]
parameters [40443,40474]
===
match
---
name: self [24746,24750]
name: self [24746,24750]
===
match
---
parameters [72987,72989]
parameters [73094,73096]
===
match
---
name: execution_date [14012,14026]
name: execution_date [14012,14026]
===
match
---
name: self [80196,80200]
name: self [80303,80307]
===
match
---
operator: = [90512,90513]
operator: = [90619,90620]
===
match
---
trailer [80068,80077]
trailer [80175,80184]
===
match
---
name: loads [4842,4847]
name: loads [4842,4847]
===
match
---
expr_stmt [6410,6438]
expr_stmt [6410,6438]
===
match
---
funcdef [93374,93425]
funcdef [93481,93532]
===
match
---
suite [62100,62314]
suite [62100,62314]
===
match
---
name: context [57226,57233]
name: context [57226,57233]
===
match
---
name: pool_override [27123,27136]
name: pool_override [27123,27136]
===
match
---
name: base [2912,2916]
name: base [2912,2916]
===
match
---
name: session [68341,68348]
name: session [68448,68455]
===
match
---
return_stmt [71831,71882]
return_stmt [71938,71989]
===
match
---
trailer [28164,28172]
trailer [28164,28172]
===
match
---
name: self [9971,9975]
name: self [9971,9975]
===
match
---
arglist [44212,44282]
arglist [44212,44282]
===
match
---
simple_stmt [92426,92454]
simple_stmt [92533,92561]
===
match
---
atom_expr [92161,92173]
atom_expr [92268,92280]
===
match
---
name: Optional [1125,1133]
name: Optional [1125,1133]
===
match
---
operator: = [24970,24971]
operator: = [24970,24971]
===
match
---
operator: , [86338,86339]
operator: , [86445,86446]
===
match
---
trailer [74306,74315]
trailer [74413,74422]
===
match
---
dotted_name [57656,57678]
dotted_name [57656,57678]
===
match
---
string: 'yesterday_ds_nodash' [78025,78046]
string: 'yesterday_ds_nodash' [78132,78153]
===
match
---
import_name [820,834]
import_name [820,834]
===
match
---
simple_stmt [40062,40108]
simple_stmt [40062,40108]
===
match
---
trailer [40400,40402]
trailer [40400,40402]
===
match
---
atom_expr [61936,61946]
atom_expr [61936,61946]
===
match
---
trailer [92203,92212]
trailer [92310,92319]
===
match
---
operator: = [50677,50678]
operator: = [50677,50678]
===
match
---
trailer [56083,56095]
trailer [56083,56095]
===
match
---
name: _CURRENT_CONTEXT [4310,4326]
name: _CURRENT_CONTEXT [4310,4326]
===
match
---
name: task_id [91547,91554]
name: task_id [91654,91661]
===
match
---
name: datetime [92253,92261]
name: datetime [92360,92368]
===
match
---
file_input [787,94032]
file_input [787,94139]
===
match
---
simple_stmt [91931,91983]
simple_stmt [92038,92090]
===
match
---
name: self [47318,47322]
name: self [47318,47322]
===
match
---
string: "%s" [63872,63876]
string: "%s" [63872,63876]
===
match
---
name: refresh_from_task [27093,27110]
name: refresh_from_task [27093,27110]
===
match
---
operator: , [80909,80910]
operator: , [81016,81017]
===
match
---
operator: @ [23032,23033]
operator: @ [23032,23033]
===
match
---
suite [22342,22393]
suite [22342,22393]
===
match
---
trailer [93655,93662]
trailer [93762,93769]
===
match
---
operator: , [61433,61434]
operator: , [61433,61434]
===
match
---
atom_expr [58644,58664]
atom_expr [58644,58664]
===
match
---
name: date [80767,80771]
name: date [80874,80878]
===
match
---
expr_stmt [65418,65443]
expr_stmt [65525,65550]
===
match
---
atom_expr [9025,9040]
atom_expr [9025,9040]
===
match
---
name: State [35821,35826]
name: State [35821,35826]
===
match
---
name: error [59196,59201]
name: error [59196,59201]
===
match
---
try_stmt [78599,79102]
try_stmt [78706,79209]
===
match
---
operator: = [26534,26535]
operator: = [26534,26535]
===
match
---
name: self [46377,46381]
name: self [46377,46381]
===
match
---
expr_stmt [31758,31770]
expr_stmt [31758,31770]
===
match
---
operator: = [59640,59641]
operator: = [59640,59641]
===
match
---
operator: , [61842,61843]
operator: , [61842,61843]
===
match
---
import_from [2477,2533]
import_from [2477,2533]
===
match
---
trailer [47660,47674]
trailer [47660,47674]
===
match
---
trailer [30305,30313]
trailer [30305,30313]
===
match
---
trailer [8410,8419]
trailer [8410,8419]
===
match
---
name: self [49475,49479]
name: self [49475,49479]
===
match
---
atom_expr [78732,79094]
atom_expr [78839,79201]
===
match
---
name: current_time [28982,28994]
name: current_time [28982,28994]
===
match
---
atom_expr [15599,15612]
atom_expr [15599,15612]
===
match
---
trailer [10154,10161]
trailer [10154,10161]
===
match
---
parameters [34653,34727]
parameters [34653,34727]
===
match
---
operator: = [8720,8721]
operator: = [8720,8721]
===
match
---
string: 'Mark success: <a href="{{ti.mark_success_url}}">Link</a><br>' [82075,82137]
string: 'Mark success: <a href="{{ti.mark_success_url}}">Link</a><br>' [82182,82244]
===
match
---
suite [50978,51286]
suite [50978,51286]
===
match
---
name: log [54887,54890]
name: log [54887,54890]
===
match
---
operator: , [23812,23813]
operator: , [23812,23813]
===
match
---
atom_expr [84914,84927]
atom_expr [85021,85034]
===
match
---
simple_stmt [14318,14347]
simple_stmt [14318,14347]
===
match
---
trailer [91203,91210]
trailer [91310,91317]
===
match
---
name: str [69969,69972]
name: str [70076,70079]
===
match
---
name: hr_line_break [46354,46367]
name: hr_line_break [46354,46367]
===
match
---
arglist [46266,46330]
arglist [46266,46330]
===
match
---
fstring_string: ]> [37966,37968]
fstring_string: ]> [37966,37968]
===
match
---
atom_expr [45901,45916]
atom_expr [45901,45916]
===
match
---
name: AirflowSmartSensorException [50261,50288]
name: AirflowSmartSensorException [50261,50288]
===
match
---
name: ignore_ti_state [61330,61345]
name: ignore_ti_state [61330,61345]
===
match
---
param [79765,79770]
param [79872,79877]
===
match
---
name: Exception [54006,54015]
name: Exception [54006,54015]
===
match
---
simple_stmt [36868,37073]
simple_stmt [36868,37073]
===
match
---
atom_expr [80653,80665]
atom_expr [80760,80772]
===
match
---
name: airflow [3499,3506]
name: airflow [3499,3506]
===
match
---
atom_expr [48799,48808]
atom_expr [48799,48808]
===
match
---
name: merge [46643,46648]
name: merge [46643,46648]
===
match
---
import_name [1180,1191]
import_name [1180,1191]
===
match
---
trailer [59626,59639]
trailer [59626,59639]
===
match
---
simple_stmt [39952,40004]
simple_stmt [39952,40004]
===
match
---
name: session [89643,89650]
name: session [89750,89757]
===
match
---
name: state [13004,13009]
name: state [13004,13009]
===
match
---
trailer [71848,71876]
trailer [71955,71983]
===
match
---
name: sanitize_for_serialization [81193,81219]
name: sanitize_for_serialization [81300,81326]
===
match
---
name: test_mode [66284,66293]
name: test_mode [66391,66400]
===
match
---
expr_stmt [62157,62173]
expr_stmt [62157,62173]
===
match
---
atom_expr [20190,20203]
atom_expr [20190,20203]
===
match
---
trailer [72666,72681]
trailer [72773,72788]
===
match
---
simple_stmt [89274,89302]
simple_stmt [89381,89409]
===
match
---
simple_stmt [36841,36855]
simple_stmt [36841,36855]
===
match
---
not_test [79414,79435]
not_test [79521,79542]
===
match
---
atom_expr [66839,66856]
atom_expr [66946,66963]
===
match
---
name: ti [92670,92672]
name: ti [92777,92779]
===
match
---
operator: = [6415,6416]
operator: = [6415,6416]
===
match
---
tfpdef [66246,66274]
tfpdef [66353,66381]
===
match
---
operator: = [80078,80079]
operator: = [80185,80186]
===
match
---
name: self [57962,57966]
name: self [57962,57966]
===
match
---
expr_stmt [61086,61523]
expr_stmt [61086,61523]
===
match
---
trailer [27643,27655]
trailer [27643,27655]
===
match
---
argument [11339,11355]
argument [11339,11355]
===
match
---
name: jinja2 [1252,1258]
name: jinja2 [1252,1258]
===
match
---
operator: , [85250,85251]
operator: , [85357,85358]
===
match
---
funcdef [74683,74897]
funcdef [74790,75004]
===
match
---
name: with_try_number [10201,10216]
name: with_try_number [10201,10216]
===
match
---
operator: , [35909,35910]
operator: , [35909,35910]
===
match
---
arith_expr [39449,39484]
arith_expr [39449,39484]
===
match
---
name: self [40444,40448]
name: self [40444,40448]
===
match
---
tfpdef [86640,86648]
tfpdef [86747,86755]
===
match
---
funcdef [70556,70608]
funcdef [70663,70715]
===
match
---
return_stmt [28439,28518]
return_stmt [28439,28518]
===
match
---
argument [14817,14829]
argument [14817,14829]
===
match
---
name: self [92426,92430]
name: self [92533,92537]
===
match
---
trailer [22856,22867]
trailer [22856,22867]
===
match
---
name: DagRunNotFound [15805,15819]
name: DagRunNotFound [15805,15819]
===
match
---
name: render [83287,83293]
name: render [83394,83400]
===
match
---
simple_stmt [36590,36632]
simple_stmt [36590,36632]
===
match
---
operator: , [91220,91221]
operator: , [91327,91328]
===
match
---
operator: , [51220,51221]
operator: , [51220,51221]
===
match
---
trailer [27042,27048]
trailer [27042,27048]
===
match
---
name: sql [1785,1788]
name: sql [1785,1788]
===
match
---
trailer [90446,90451]
trailer [90553,90558]
===
match
---
trailer [39124,39129]
trailer [39124,39129]
===
match
---
trailer [55006,55013]
trailer [55006,55013]
===
match
---
param [20182,20211]
param [20182,20211]
===
match
---
comparison [29006,29034]
comparison [29006,29034]
===
match
---
simple_stmt [44700,44736]
simple_stmt [44700,44736]
===
match
---
string: 'ts_nodash_with_tz' [77649,77668]
string: 'ts_nodash_with_tz' [77756,77775]
===
match
---
operator: = [32314,32315]
operator: = [32314,32315]
===
match
---
param [20044,20064]
param [20044,20064]
===
match
---
expr_stmt [62182,62222]
expr_stmt [62182,62222]
===
match
---
argument [48859,48874]
argument [48859,48874]
===
match
---
name: task_id [47569,47576]
name: task_id [47569,47576]
===
match
---
name: all [8421,8424]
name: all [8421,8424]
===
match
---
comparison [91108,91134]
comparison [91215,91241]
===
match
---
argument [13976,13989]
argument [13976,13989]
===
match
---
param [70937,70947]
param [71044,71054]
===
match
---
funcdef [34022,34600]
funcdef [34022,34600]
===
match
---
name: dt [31730,31732]
name: dt [31730,31732]
===
match
---
operator: -> [72758,72760]
operator: -> [72865,72867]
===
match
---
name: str [47946,47949]
name: str [47946,47949]
===
match
---
suite [57522,58823]
suite [57522,58823]
===
match
---
suite [60542,60624]
suite [60542,60624]
===
match
---
name: get_template_context [49318,49338]
name: get_template_context [49318,49338]
===
match
---
name: mark_success [41391,41403]
name: mark_success [41391,41403]
===
match
---
operator: = [62162,62163]
operator: = [62162,62163]
===
match
---
atom_expr [45618,45628]
atom_expr [45618,45628]
===
match
---
argument [19668,19677]
argument [19668,19677]
===
match
---
name: property [9946,9954]
name: property [9946,9954]
===
match
---
name: is_eligible_to_retry [66549,66569]
name: is_eligible_to_retry [66656,66676]
===
match
---
name: jinja2 [1199,1205]
name: jinja2 [1199,1205]
===
match
---
param [27123,27141]
param [27123,27141]
===
match
---
operator: = [45455,45456]
operator: = [45455,45456]
===
match
---
argument [51611,51632]
argument [51611,51632]
===
match
---
simple_stmt [90506,90521]
simple_stmt [90613,90628]
===
match
---
name: timezone [15263,15271]
name: timezone [15263,15271]
===
match
---
name: self [60223,60227]
name: self [60223,60227]
===
match
---
trailer [85941,85950]
trailer [86048,86057]
===
match
---
simple_stmt [92380,92418]
simple_stmt [92487,92525]
===
match
---
atom_expr [5931,5968]
atom_expr [5931,5968]
===
match
---
fstring_string:  with date  [15873,15884]
fstring_string:  with date  [15873,15884]
===
match
---
name: self [47118,47122]
name: self [47118,47122]
===
match
---
trailer [35814,35835]
trailer [35814,35835]
===
match
---
simple_stmt [72166,72334]
simple_stmt [72273,72441]
===
match
---
arglist [63777,63821]
arglist [63777,63821]
===
match
---
atom_expr [83243,83310]
atom_expr [83350,83417]
===
match
---
name: DEFERRED [57945,57953]
name: DEFERRED [57945,57953]
===
match
---
atom_expr [84143,84186]
atom_expr [84250,84293]
===
match
---
comparison [6000,6025]
comparison [6000,6025]
===
match
---
atom_expr [25901,25914]
atom_expr [25901,25914]
===
match
---
name: self [17312,17316]
name: self [17312,17316]
===
match
---
operator: , [1417,1418]
operator: , [1417,1418]
===
match
---
name: task_ids [86540,86548]
name: task_ids [86647,86655]
===
match
---
operator: , [60826,60827]
operator: , [60826,60827]
===
match
---
name: fd [4729,4731]
name: fd [4729,4731]
===
match
---
name: try_number [83654,83664]
name: try_number [83761,83771]
===
match
---
operator: , [1105,1106]
operator: , [1105,1106]
===
match
---
simple_stmt [56113,56178]
simple_stmt [56113,56178]
===
match
---
atom_expr [32802,32850]
atom_expr [32802,32850]
===
match
---
suite [19075,19124]
suite [19075,19124]
===
match
---
atom_expr [35224,35261]
atom_expr [35224,35261]
===
match
---
operator: @ [93360,93361]
operator: @ [93467,93468]
===
match
---
name: self [51983,51987]
name: self [51983,51987]
===
match
---
name: cfg_path [19700,19708]
name: cfg_path [19700,19708]
===
match
---
name: airflow_context_vars [53433,53453]
name: airflow_context_vars [53433,53453]
===
match
---
operator: , [61875,61876]
operator: , [61875,61876]
===
match
---
name: dag_id [11289,11295]
name: dag_id [11289,11295]
===
match
---
argument [75918,75938]
argument [76025,76045]
===
match
---
expr_stmt [28806,28838]
expr_stmt [28806,28838]
===
match
---
suite [75016,75045]
suite [75123,75152]
===
match
---
name: timezone [75310,75318]
name: timezone [75417,75425]
===
match
---
operator: = [92551,92552]
operator: = [92658,92659]
===
match
---
parameters [4943,4990]
parameters [4943,4990]
===
match
---
except_clause [5141,5157]
except_clause [5141,5157]
===
match
---
name: primary_key [11251,11262]
name: primary_key [11251,11262]
===
match
---
operator: @ [3956,3957]
operator: @ [3956,3957]
===
match
---
name: SUCCESS [49566,49573]
name: SUCCESS [49566,49573]
===
match
---
name: self [54980,54984]
name: self [54980,54984]
===
match
---
simple_stmt [34539,34600]
simple_stmt [34539,34600]
===
match
---
name: last_dagrun [32366,32377]
name: last_dagrun [32366,32377]
===
match
---
operator: = [18988,18989]
operator: = [18988,18989]
===
match
---
name: test_mode [63672,63681]
name: test_mode [63672,63681]
===
match
---
simple_stmt [52604,52659]
simple_stmt [52604,52659]
===
match
---
operator: = [48823,48824]
operator: = [48823,48824]
===
match
---
if_stmt [18839,19157]
if_stmt [18839,19157]
===
match
---
funcdef [81259,84413]
funcdef [81366,84520]
===
match
---
atom_expr [37656,37675]
atom_expr [37656,37675]
===
match
---
suite [22958,23008]
suite [22958,23008]
===
match
---
expr_stmt [54945,54971]
expr_stmt [54945,54971]
===
match
---
atom_expr [57939,57953]
atom_expr [57939,57953]
===
match
---
atom_expr [7868,7892]
atom_expr [7868,7892]
===
match
---
trailer [69124,69128]
trailer [69231,69235]
===
match
---
name: self [18633,18637]
name: self [18633,18637]
===
match
---
tfpdef [20005,20026]
tfpdef [20005,20026]
===
match
---
suite [72641,72719]
suite [72748,72826]
===
match
---
simple_stmt [31006,31018]
simple_stmt [31006,31018]
===
match
---
except_clause [53999,54015]
except_clause [53999,54015]
===
match
---
suite [84976,85010]
suite [85083,85117]
===
match
---
name: ti_hash [39463,39470]
name: ti_hash [39463,39470]
===
match
---
simple_stmt [9645,9687]
simple_stmt [9645,9687]
===
match
---
name: run_id [91264,91270]
name: run_id [91371,91377]
===
match
---
name: state [34507,34512]
name: state [34507,34512]
===
match
---
name: previous_ti_success [33480,33499]
name: previous_ti_success [33480,33499]
===
match
---
param [14115,14157]
param [14115,14157]
===
match
---
name: TaskInstanceKey [93699,93714]
name: TaskInstanceKey [93806,93821]
===
match
---
name: session [8251,8258]
name: session [8251,8258]
===
match
---
comparison [29475,29507]
comparison [29475,29507]
===
match
---
tfpdef [60875,60893]
tfpdef [60875,60893]
===
match
---
name: next_method [55590,55601]
name: next_method [55590,55601]
===
match
---
name: self [62585,62589]
name: self [62585,62589]
===
match
---
string: "ignore" [74563,74571]
string: "ignore" [74670,74678]
===
match
---
arith_expr [17157,17177]
arith_expr [17157,17177]
===
match
---
name: get_prev_ds [74971,74982]
name: get_prev_ds [75078,75089]
===
match
---
trailer [46219,46223]
trailer [46219,46223]
===
match
---
funcdef [72611,72719]
funcdef [72718,72826]
===
match
---
funcdef [52451,52659]
funcdef [52451,52659]
===
match
---
operator: , [72474,72475]
operator: , [72581,72582]
===
match
---
atom_expr [24810,24820]
atom_expr [24810,24820]
===
match
---
name: task_id [89144,89151]
name: task_id [89251,89258]
===
match
---
atom_expr [12059,12074]
atom_expr [12059,12074]
===
match
---
name: DagRun [40785,40791]
name: DagRun [40785,40791]
===
match
---
simple_stmt [53583,53622]
simple_stmt [53583,53622]
===
match
---
atom_expr [30956,30969]
atom_expr [30956,30969]
===
match
---
name: self [60563,60567]
name: self [60563,60567]
===
match
---
trailer [70233,70264]
trailer [70340,70371]
===
match
---
operator: = [26918,26919]
operator: = [26918,26919]
===
match
---
operator: , [66929,66930]
operator: , [67036,67037]
===
match
---
trailer [60367,60388]
trailer [60367,60388]
===
match
---
atom_expr [39245,39260]
atom_expr [39245,39260]
===
match
---
operator: , [79158,79159]
operator: , [79265,79266]
===
match
---
argument [76560,76573]
argument [76667,76680]
===
match
---
trailer [25797,25803]
trailer [25797,25803]
===
match
---
operator: = [25941,25942]
operator: = [25941,25942]
===
match
---
name: conf [23176,23180]
name: conf [23176,23180]
===
match
---
suite [69438,70265]
suite [69545,70372]
===
match
---
trailer [18495,18514]
trailer [18495,18514]
===
match
---
name: pool [61479,61483]
name: pool [61479,61483]
===
match
---
name: _run_id [92244,92251]
name: _run_id [92351,92358]
===
match
---
name: timezone [75495,75503]
name: timezone [75602,75610]
===
match
---
operator: , [78451,78452]
operator: , [78558,78559]
===
match
---
name: session [49761,49768]
name: session [49761,49768]
===
match
---
fstring_expr [77301,77315]
fstring_expr [77408,77422]
===
match
---
trailer [68147,68156]
trailer [68254,68263]
===
match
---
operator: = [86702,86703]
operator: = [86809,86810]
===
match
---
name: max_tries [83706,83715]
name: max_tries [83813,83822]
===
match
---
decorated [78064,79102]
decorated [78171,79209]
===
match
---
trailer [26905,26917]
trailer [26905,26917]
===
match
---
number: 1 [65693,65694]
number: 1 [65800,65801]
===
match
---
name: max_tries [46317,46326]
name: max_tries [46317,46326]
===
match
---
name: prepare_for_execution [62199,62220]
name: prepare_for_execution [62199,62220]
===
match
---
suite [58350,58391]
suite [58350,58391]
===
match
---
operator: , [5127,5128]
operator: , [5127,5128]
===
match
---
suite [58747,58823]
suite [58747,58823]
===
match
---
name: TaskInstance [25519,25531]
name: TaskInstance [25519,25531]
===
match
---
parameters [37258,37296]
parameters [37258,37296]
===
match
---
atom_expr [76814,77056]
atom_expr [76921,77163]
===
match
---
fstring_string: . [51961,51962]
fstring_string: . [51961,51962]
===
match
---
atom_expr [77097,77149]
atom_expr [77204,77256]
===
match
---
suite [44789,44987]
suite [44789,44987]
===
match
---
name: task_type [64324,64333]
name: task_type [64324,64333]
===
match
---
simple_stmt [52787,52810]
simple_stmt [52787,52810]
===
match
---
name: self [82934,82938]
name: self [83041,83045]
===
match
---
operator: , [15166,15167]
operator: , [15166,15167]
===
match
---
trailer [67327,67338]
trailer [67434,67445]
===
match
---
simple_stmt [50210,50227]
simple_stmt [50210,50227]
===
match
---
operator: = [85211,85212]
operator: = [85318,85319]
===
match
---
return_stmt [79696,79720]
return_stmt [79803,79827]
===
match
---
trailer [46677,46679]
trailer [46677,46679]
===
match
---
operator: , [7866,7867]
operator: , [7866,7867]
===
match
---
simple_stmt [2760,2811]
simple_stmt [2760,2811]
===
match
---
name: self [46295,46299]
name: self [46295,46299]
===
match
---
fstring_expr [53412,53415]
fstring_expr [53412,53415]
===
match
---
name: post_execute [54643,54655]
name: post_execute [54643,54655]
===
match
---
decorated [93042,93109]
decorated [93149,93216]
===
match
---
atom_expr [64527,64546]
atom_expr [64631,64653]
===
match
---
comparison [30981,30992]
comparison [30981,30992]
===
match
---
name: external_trigger [73479,73495]
name: external_trigger [73586,73602]
===
match
---
name: run_id [14413,14419]
name: run_id [14413,14419]
===
match
---
name: get_dagrun [40433,40443]
name: get_dagrun [40433,40443]
===
match
---
atom_expr [35201,35219]
atom_expr [35201,35219]
===
match
---
arglist [39197,39260]
arglist [39197,39260]
===
match
---
operator: = [83571,83572]
operator: = [83678,83679]
===
match
---
operator: , [49925,49926]
operator: , [49925,49926]
===
match
---
atom_expr [77734,77756]
atom_expr [77841,77863]
===
match
---
decorated [37210,37853]
decorated [37210,37853]
===
match
---
simple_stmt [7612,8181]
simple_stmt [7612,8181]
===
match
---
name: path [83987,83991]
name: path [84094,84098]
===
match
---
name: Exception [65988,65997]
name: Exception [66095,66104]
===
match
---
string: ' dag_id=%s, task_id=%s,' [47383,47408]
string: ' dag_id=%s, task_id=%s,' [47383,47408]
===
match
---
name: jinja_context [83441,83454]
name: jinja_context [83548,83561]
===
match
---
try_stmt [58963,59158]
try_stmt [58963,59158]
===
match
---
operator: = [44826,44827]
operator: = [44826,44827]
===
match
---
name: get [23181,23184]
name: get [23181,23184]
===
match
---
simple_stmt [1231,1247]
simple_stmt [1231,1247]
===
match
---
name: self [70829,70833]
name: self [70936,70940]
===
match
---
trailer [43455,43461]
trailer [43455,43461]
===
match
---
name: key [83952,83955]
name: key [84059,84062]
===
match
---
trailer [85930,85941]
trailer [86037,86048]
===
match
---
operator: , [86209,86210]
operator: , [86316,86317]
===
match
---
simple_stmt [10270,10329]
simple_stmt [10270,10329]
===
match
---
trailer [24166,24180]
trailer [24166,24180]
===
match
---
operator: = [83004,83005]
operator: = [83111,83112]
===
match
---
simple_stmt [1846,1889]
simple_stmt [1846,1889]
===
match
---
fstring [72198,72255]
fstring [72305,72362]
===
match
---
trailer [44733,44735]
trailer [44733,44735]
===
match
---
name: self [14282,14286]
name: self [14282,14286]
===
match
---
atom_expr [30630,30643]
atom_expr [30630,30643]
===
match
---
name: str [9817,9820]
name: str [9817,9820]
===
match
---
suite [63745,63823]
suite [63745,63823]
===
match
---
name: dag_run [80005,80012]
name: dag_run [80112,80119]
===
match
---
name: _end_date [92338,92347]
name: _end_date [92445,92454]
===
match
---
simple_stmt [93826,93846]
simple_stmt [93933,93953]
===
match
---
trailer [29010,29016]
trailer [29010,29016]
===
match
---
name: dagrun [32793,32799]
name: dagrun [32793,32799]
===
match
---
name: merge [29224,29229]
name: merge [29224,29229]
===
match
---
operator: , [22377,22378]
operator: , [22377,22378]
===
match
---
operator: , [56044,56045]
operator: , [56044,56045]
===
match
---
name: self [30268,30272]
name: self [30268,30272]
===
match
---
simple_stmt [6498,6526]
simple_stmt [6498,6526]
===
match
---
name: data_interval [68705,68718]
name: data_interval [68812,68825]
===
match
---
trailer [74221,74223]
trailer [74328,74330]
===
match
---
trailer [49419,49428]
trailer [49419,49428]
===
match
---
trailer [12579,12593]
trailer [12579,12593]
===
match
---
atom_expr [65720,65738]
atom_expr [65827,65845]
===
match
---
operator: , [77210,77211]
operator: , [77317,77318]
===
match
---
operator: = [92668,92669]
operator: = [92775,92776]
===
match
---
decorated [28524,29236]
decorated [28524,29236]
===
match
---
trailer [66884,66894]
trailer [66991,67001]
===
match
---
trailer [85200,85210]
trailer [85307,85317]
===
match
---
operator: , [4977,4978]
operator: , [4977,4978]
===
match
---
atom_expr [77287,77298]
atom_expr [77394,77405]
===
match
---
param [41183,41188]
param [41183,41188]
===
match
---
decorator [72830,72837]
decorator [72937,72944]
===
match
---
string: 'tomorrow_ds' [77408,77421]
string: 'tomorrow_ds' [77515,77528]
===
match
---
argument [57218,57233]
argument [57218,57233]
===
match
---
operator: = [16108,16109]
operator: = [16108,16109]
===
match
---
string: 'TaskInstanceKey' [9980,9997]
string: 'TaskInstanceKey' [9980,9997]
===
match
---
simple_stmt [15246,15323]
simple_stmt [15246,15323]
===
match
---
name: _run_id [93101,93108]
name: _run_id [93208,93215]
===
match
---
name: Optional [47937,47945]
name: Optional [47937,47945]
===
match
---
operator: , [82799,82800]
operator: , [82906,82907]
===
match
---
trailer [59785,59795]
trailer [59785,59795]
===
match
---
expr_stmt [13497,13709]
expr_stmt [13497,13709]
===
match
---
trailer [50535,50539]
trailer [50535,50539]
===
match
---
param [57486,57491]
param [57486,57491]
===
match
---
operator: -> [23828,23830]
operator: -> [23828,23830]
===
match
---
trailer [51870,51872]
trailer [51870,51872]
===
match
---
trailer [72706,72718]
trailer [72813,72825]
===
match
---
operator: } [58084,58085]
operator: } [58084,58085]
===
match
---
name: job_ids [8411,8418]
name: job_ids [8411,8418]
===
match
---
name: SUCCESS [51496,51503]
name: SUCCESS [51496,51503]
===
match
---
name: self [25640,25644]
name: self [25640,25644]
===
match
---
name: ti [26338,26340]
name: ti [26338,26340]
===
match
---
name: state [61941,61946]
name: state [61941,61946]
===
match
---
operator: , [56156,56157]
operator: , [56156,56157]
===
match
---
param [80051,80084]
param [80158,80191]
===
match
---
expr_stmt [57926,57953]
expr_stmt [57926,57953]
===
match
---
atom_expr [6242,6258]
atom_expr [6242,6258]
===
match
---
name: task_id [6384,6391]
name: task_id [6384,6391]
===
match
---
argument [61224,61269]
argument [61224,61269]
===
match
---
trailer [33517,33533]
trailer [33517,33533]
===
match
---
name: func [89657,89661]
name: func [89764,89768]
===
match
---
trailer [74506,74521]
trailer [74613,74628]
===
match
---
operator: , [84380,84381]
operator: , [84487,84488]
===
match
---
trailer [84102,84119]
trailer [84209,84226]
===
match
---
name: pool [93448,93452]
name: pool [93555,93559]
===
match
---
operator: , [27854,27855]
operator: , [27854,27855]
===
match
---
trailer [46265,46331]
trailer [46265,46331]
===
match
---
name: total_seconds [39919,39932]
name: total_seconds [39919,39932]
===
match
---
decorator [19725,19739]
decorator [19725,19739]
===
match
---
expr_stmt [5894,5969]
expr_stmt [5894,5969]
===
match
---
operator: = [71716,71717]
operator: = [71823,71824]
===
match
---
trailer [44854,44877]
trailer [44854,44877]
===
match
---
name: _try_number [26216,26227]
name: _try_number [26216,26227]
===
match
---
name: self [27007,27011]
name: self [27007,27011]
===
match
---
simple_stmt [57160,57166]
simple_stmt [57160,57166]
===
match
---
argument [82780,82799]
argument [82887,82906]
===
match
---
argument [51222,51237]
argument [51222,51237]
===
match
---
name: first_task_id [90590,90603]
name: first_task_id [90697,90710]
===
match
---
name: next_execution_date [73898,73917]
name: next_execution_date [74005,74024]
===
match
---
name: raw [89990,89993]
name: raw [90097,90100]
===
match
---
operator: , [54671,54672]
operator: , [54671,54672]
===
match
---
funcdef [23046,23309]
funcdef [23046,23309]
===
match
---
name: State [66655,66660]
name: State [66762,66767]
===
match
---
trailer [94022,94031]
trailer [94129,94138]
===
match
---
operator: = [43627,43628]
operator: = [43627,43628]
===
match
---
argument [83654,83684]
argument [83761,83791]
===
match
---
operator: = [14000,14001]
operator: = [14000,14001]
===
match
---
operator: , [24306,24307]
operator: , [24306,24307]
===
match
---
if_stmt [63691,64115]
if_stmt [63691,64115]
===
match
---
param [18152,18164]
param [18152,18164]
===
match
---
operator: , [4959,4960]
operator: , [4959,4960]
===
match
---
trailer [66401,66416]
trailer [66508,66523]
===
match
---
atom_expr [6337,6347]
atom_expr [6337,6347]
===
match
---
import_from [3204,3270]
import_from [3204,3270]
===
match
---
argument [13613,13632]
argument [13613,13632]
===
match
---
trailer [37545,37551]
trailer [37545,37551]
===
match
---
trailer [15656,15663]
trailer [15656,15663]
===
match
---
atom_expr [89708,89727]
atom_expr [89815,89834]
===
match
---
expr_stmt [82535,82563]
expr_stmt [82642,82670]
===
match
---
decorator [93280,93290]
decorator [93387,93397]
===
match
---
trailer [23442,23444]
trailer [23442,23444]
===
match
---
trailer [54734,54739]
trailer [54734,54739]
===
match
---
string: 'json' [77726,77732]
string: 'json' [77833,77839]
===
match
---
name: airflow [3019,3026]
name: airflow [3019,3026]
===
match
---
trailer [53015,53048]
trailer [53015,53048]
===
match
---
operator: , [30279,30280]
operator: , [30279,30280]
===
match
---
name: self [54541,54545]
name: self [54541,54545]
===
match
---
name: getpid [48966,48972]
name: getpid [48966,48972]
===
match
---
comparison [85996,86032]
comparison [86103,86139]
===
match
---
param [63458,63483]
param [63458,63483]
===
match
---
name: executor_config [92494,92509]
name: executor_config [92601,92616]
===
match
---
atom_expr [79891,79978]
atom_expr [79998,80085]
===
match
---
comparison [30245,30279]
comparison [30245,30279]
===
match
---
atom_expr [52187,52197]
atom_expr [52187,52197]
===
match
---
name: str [9700,9703]
name: str [9700,9703]
===
match
---
string: "TaskInstance.trigger_id == Trigger.id" [13778,13817]
string: "TaskInstance.trigger_id == Trigger.id" [13778,13817]
===
match
---
simple_stmt [44347,44360]
simple_stmt [44347,44360]
===
match
---
expr_stmt [89014,89178]
expr_stmt [89121,89285]
===
match
---
name: str [20275,20278]
name: str [20275,20278]
===
match
---
operator: + [23523,23524]
operator: + [23523,23524]
===
match
---
atom [82184,82497]
atom [82291,82604]
===
match
---
string: "`activate_dag_runs` parameter to clear_task_instances function is deprecated. " [8543,8623]
string: "`activate_dag_runs` parameter to clear_task_instances function is deprecated. " [8543,8623]
===
match
---
name: warnings [74541,74549]
name: warnings [74648,74656]
===
match
---
name: __file__ [83089,83097]
name: __file__ [83196,83204]
===
match
---
trailer [60305,60323]
trailer [60305,60323]
===
match
---
name: self [33434,33438]
name: self [33434,33438]
===
match
---
param [16627,16631]
param [16627,16631]
===
match
---
arglist [64298,64341]
arglist [64298,64341]
===
match
---
name: str [19147,19150]
name: str [19147,19150]
===
match
---
operator: = [19672,19673]
operator: = [19672,19673]
===
match
---
simple_stmt [30950,30970]
simple_stmt [30950,30970]
===
match
---
atom_expr [14551,14844]
atom_expr [14551,14844]
===
match
---
trailer [29179,29190]
trailer [29179,29190]
===
match
---
simple_stmt [53312,53478]
simple_stmt [53312,53478]
===
match
---
simple_stmt [82716,82982]
simple_stmt [82823,83089]
===
match
---
expr_stmt [9436,9469]
expr_stmt [9436,9469]
===
match
---
atom_expr [84728,84743]
atom_expr [84835,84850]
===
match
---
trailer [59105,59115]
trailer [59105,59115]
===
match
---
name: lazy_object_proxy [76337,76354]
name: lazy_object_proxy [76444,76461]
===
match
---
trailer [4766,4771]
trailer [4766,4771]
===
match
---
trailer [49026,49032]
trailer [49026,49032]
===
match
---
param [60875,60902]
param [60875,60902]
===
match
---
atom_expr [11796,11831]
atom_expr [11796,11831]
===
match
---
param [18237,18247]
param [18237,18247]
===
match
---
argument [71180,71201]
argument [71287,71308]
===
match
---
atom_expr [40907,40918]
atom_expr [40907,40918]
===
match
---
name: task [67188,67192]
name: task [67295,67299]
===
match
---
name: Optional [25708,25716]
name: Optional [25708,25716]
===
match
---
atom_expr [30087,30096]
atom_expr [30087,30096]
===
match
---
trailer [54772,54777]
trailer [54772,54777]
===
match
---
operator: = [27602,27603]
operator: = [27602,27603]
===
match
---
simple_stmt [51148,51239]
simple_stmt [51148,51239]
===
match
---
trailer [43340,43349]
trailer [43340,43349]
===
match
---
atom_expr [56980,57004]
atom_expr [56980,57004]
===
match
---
atom_expr [48952,48960]
atom_expr [48952,48960]
===
match
---
name: execution_date [14115,14129]
name: execution_date [14115,14129]
===
match
---
operator: = [5909,5910]
operator: = [5909,5910]
===
match
---
number: 1000 [11713,11717]
number: 1000 [11713,11717]
===
match
---
atom_expr [58363,58383]
atom_expr [58363,58383]
===
match
---
name: DepContext [45210,45220]
name: DepContext [45210,45220]
===
match
---
operator: = [80511,80512]
operator: = [80618,80619]
===
match
---
name: str [30639,30642]
name: str [30639,30642]
===
match
---
trailer [24193,24200]
trailer [24193,24200]
===
match
---
name: VariableAccessor [69421,69437]
name: VariableAccessor [69528,69544]
===
match
---
simple_stmt [84058,84120]
simple_stmt [84165,84227]
===
match
---
name: Session [91376,91383]
name: Session [91483,91490]
===
match
---
name: end_date [29105,29113]
name: end_date [29105,29113]
===
match
---
expr_stmt [81558,81611]
expr_stmt [81665,81718]
===
match
---
trailer [41476,41481]
trailer [41476,41481]
===
match
---
simple_stmt [50336,50343]
simple_stmt [50336,50343]
===
match
---
fstring_string: __ [77299,77301]
fstring_string: __ [77406,77408]
===
match
---
name: BigInteger [12309,12319]
name: BigInteger [12309,12319]
===
match
---
operator: = [94008,94009]
operator: = [94115,94116]
===
match
---
name: SUCCESS [30450,30457]
name: SUCCESS [30450,30457]
===
match
---
name: self [45645,45649]
name: self [45645,45649]
===
match
---
raise_stmt [55121,55203]
raise_stmt [55121,55203]
===
match
---
name: dag_id [88635,88641]
name: dag_id [88742,88748]
===
match
---
trailer [7072,7076]
trailer [7072,7076]
===
match
---
trailer [13932,14006]
trailer [13932,14006]
===
match
---
name: isoformat [23433,23442]
name: isoformat [23433,23442]
===
match
---
suite [92152,92891]
suite [92259,92998]
===
match
---
name: reconstructor [16414,16427]
name: reconstructor [16414,16427]
===
match
---
funcdef [27830,28305]
funcdef [27830,28305]
===
match
---
name: value [85156,85161]
name: value [85263,85268]
===
match
---
string: "Passing an execution_date to `TaskInstance()` is deprecated in favour of passing a run_id" [14582,14673]
string: "Passing an execution_date to `TaskInstance()` is deprecated in favour of passing a run_id" [14582,14673]
===
match
---
except_clause [79529,79581]
except_clause [79636,79688]
===
match
---
operator: , [70658,70659]
operator: , [70765,70766]
===
match
---
simple_stmt [27581,27631]
simple_stmt [27581,27631]
===
match
---
atom_expr [84214,84267]
atom_expr [84321,84374]
===
match
---
expr_stmt [11377,11460]
expr_stmt [11377,11460]
===
match
---
string: 'prev_start_date_success' [77070,77095]
string: 'prev_start_date_success' [77177,77202]
===
match
---
name: data [4757,4761]
name: data [4757,4761]
===
match
---
atom_expr [86080,86226]
atom_expr [86187,86333]
===
match
---
operator: @ [10417,10418]
operator: @ [10417,10418]
===
match
---
trailer [68139,68147]
trailer [68246,68254]
===
match
---
name: BaseJob [94023,94030]
name: BaseJob [94130,94137]
===
match
---
name: timezone [75222,75230]
name: timezone [75329,75337]
===
match
---
name: dag_id [12940,12946]
name: dag_id [12940,12946]
===
match
---
operator: -> [66380,66382]
operator: -> [66487,66489]
===
match
---
argument [51182,51197]
argument [51182,51197]
===
match
---
string: "airflow.task" [14385,14399]
string: "airflow.task" [14385,14399]
===
match
---
name: log [34993,34996]
name: log [34993,34996]
===
match
---
trailer [91030,91054]
trailer [91137,91161]
===
match
---
name: dependencies_deps [2832,2849]
name: dependencies_deps [2832,2849]
===
match
---
name: t [91262,91263]
name: t [91369,91370]
===
match
---
name: airflow [2733,2740]
name: airflow [2733,2740]
===
match
---
name: timezone [56563,56571]
name: timezone [56563,56571]
===
match
---
parameters [74172,74174]
parameters [74279,74281]
===
match
---
name: execution_date [74860,74874]
name: execution_date [74967,74981]
===
match
---
string: '%Y-%m-%d' [74129,74139]
string: '%Y-%m-%d' [74236,74246]
===
match
---
operator: = [3763,3764]
operator: = [3763,3764]
===
match
---
atom_expr [37911,37922]
atom_expr [37911,37922]
===
match
---
name: quote [1173,1178]
name: quote [1173,1178]
===
match
---
simple_stmt [6542,6590]
simple_stmt [6542,6590]
===
match
---
name: context [55233,55240]
name: context [55233,55240]
===
match
---
trailer [18931,18948]
trailer [18931,18948]
===
match
---
operator: , [19784,19785]
operator: , [19784,19785]
===
match
---
trailer [72899,72914]
trailer [73006,73021]
===
match
---
name: datetime [958,966]
name: datetime [958,966]
===
match
---
arglist [6931,6968]
arglist [6931,6968]
===
match
---
name: var [70723,70726]
name: var [70830,70833]
===
match
---
name: job_id [22383,22389]
name: job_id [22383,22389]
===
match
---
operator: { [23656,23657]
operator: { [23656,23657]
===
match
---
operator: == [40904,40906]
operator: == [40904,40906]
===
match
---
name: try_number [15988,15998]
name: try_number [15988,15998]
===
match
---
fstring_start: f" [72198,72200]
fstring_start: f" [72305,72307]
===
match
---
atom_expr [27744,27764]
atom_expr [27744,27764]
===
match
---
atom_expr [56686,56729]
atom_expr [56686,56729]
===
match
---
expr_stmt [84897,84962]
expr_stmt [85004,85069]
===
match
---
return_stmt [91712,91855]
return_stmt [91819,91962]
===
match
---
try_stmt [56742,57166]
try_stmt [56742,57166]
===
match
---
string: """Get Airflow Variable after deserializing JSON value""" [71055,71112]
string: """Get Airflow Variable after deserializing JSON value""" [71162,71219]
===
match
---
operator: @ [74668,74669]
operator: @ [74775,74776]
===
match
---
name: log [36721,36724]
name: log [36721,36724]
===
match
---
name: debug [25406,25411]
name: debug [25406,25411]
===
match
---
name: pool [19673,19677]
name: pool [19673,19677]
===
match
---
operator: , [53120,53121]
operator: , [53120,53121]
===
match
---
atom_expr [80810,80832]
atom_expr [80917,80939]
===
match
---
name: e [79100,79101]
name: e [79207,79208]
===
match
---
atom_expr [27521,27530]
atom_expr [27521,27530]
===
match
---
trailer [11392,11460]
trailer [11392,11460]
===
match
---
trailer [64248,64250]
trailer [64248,64250]
===
match
---
comparison [7756,7775]
comparison [7756,7775]
===
match
---
operator: = [75790,75791]
operator: = [75897,75898]
===
match
---
simple_stmt [34409,34462]
simple_stmt [34409,34462]
===
match
---
name: items [53454,53459]
name: items [53454,53459]
===
match
---
argument [11816,11830]
argument [11816,11830]
===
match
---
operator: , [92579,92580]
operator: , [92686,92687]
===
match
---
trailer [84918,84927]
trailer [85025,85034]
===
match
---
operator: , [30442,30443]
operator: , [30442,30443]
===
match
---
trailer [12422,12435]
trailer [12422,12435]
===
match
---
fstring_start: f" [72397,72399]
fstring_start: f" [72504,72506]
===
match
---
name: error_fd [61985,61993]
name: error_fd [61985,61993]
===
match
---
name: pickle [5110,5116]
name: pickle [5110,5116]
===
match
---
simple_stmt [48838,48876]
simple_stmt [48838,48876]
===
match
---
name: first [90569,90574]
name: first [90676,90681]
===
match
---
name: self [23574,23578]
name: self [23574,23578]
===
match
---
name: base [2263,2267]
name: base [2263,2267]
===
match
---
name: DagRunState [5441,5452]
name: DagRunState [5441,5452]
===
match
---
name: try_number [7926,7936]
name: try_number [7926,7936]
===
match
---
trailer [83286,83293]
trailer [83393,83400]
===
match
---
name: airflow [3062,3069]
name: airflow [3062,3069]
===
match
---
name: task_id [25596,25603]
name: task_id [25596,25603]
===
match
---
name: dag [31473,31476]
name: dag [31473,31476]
===
match
---
trailer [26434,26445]
trailer [26434,26445]
===
match
---
argument [51634,51649]
argument [51634,51649]
===
match
---
operator: = [77460,77461]
operator: = [77567,77568]
===
match
---
trailer [79997,80004]
trailer [80104,80111]
===
match
---
param [23058,23062]
param [23058,23062]
===
match
---
name: dag [68575,68578]
name: dag [68682,68685]
===
match
---
argument [61723,61742]
argument [61723,61742]
===
match
---
suite [93466,93493]
suite [93573,93600]
===
match
---
argument [45440,45471]
argument [45440,45471]
===
match
---
name: error_file [47967,47977]
name: error_file [47967,47977]
===
match
---
simple_stmt [16121,16141]
simple_stmt [16121,16141]
===
match
---
decorator [23314,23324]
decorator [23314,23324]
===
match
---
name: deprecated_proxy [77888,77904]
name: deprecated_proxy [77995,78011]
===
match
---
operator: = [32800,32801]
operator: = [32800,32801]
===
match
---
name: run_id [13337,13343]
name: run_id [13337,13343]
===
match
---
string: 'end_date' [47708,47718]
string: 'end_date' [47708,47718]
===
match
---
name: ds [75383,75385]
name: ds [75490,75492]
===
match
---
name: enrich_errors [47765,47778]
name: enrich_errors [47765,47778]
===
match
---
operator: = [92723,92724]
operator: = [92830,92831]
===
match
---
import_from [2432,2476]
import_from [2432,2476]
===
match
---
name: html_content_err [84396,84412]
name: html_content_err [84503,84519]
===
match
---
name: unixname [26327,26335]
name: unixname [26327,26335]
===
match
---
name: cache [72831,72836]
name: cache [72938,72943]
===
match
---
simple_stmt [81828,82148]
simple_stmt [81935,82255]
===
match
---
trailer [77360,77370]
trailer [77467,77477]
===
match
---
simple_stmt [61589,61632]
simple_stmt [61589,61632]
===
match
---
name: non_requeueable_dep_context [43828,43855]
name: non_requeueable_dep_context [43828,43855]
===
match
---
operator: , [3945,3946]
operator: , [3945,3946]
===
match
---
fstring_start: f' [52835,52837]
fstring_start: f' [52835,52837]
===
match
---
operator: , [2239,2240]
operator: , [2239,2240]
===
match
---
simple_stmt [13497,13710]
simple_stmt [13497,13710]
===
match
---
name: default_html_content_err [82157,82181]
name: default_html_content_err [82264,82288]
===
match
---
string: "&downstream=false" [23705,23724]
string: "&downstream=false" [23705,23724]
===
match
---
trailer [4394,4565]
trailer [4394,4565]
===
match
---
return_stmt [40722,40741]
return_stmt [40722,40741]
===
match
---
name: test_mode [62508,62517]
name: test_mode [62508,62517]
===
match
---
suite [69945,69983]
suite [70052,70090]
===
match
---
name: self [32454,32458]
name: self [32454,32458]
===
match
---
atom_expr [47590,47627]
atom_expr [47590,47627]
===
match
---
atom_expr [51920,51996]
atom_expr [51920,51996]
===
match
---
atom_expr [90606,90619]
atom_expr [90713,90726]
===
match
---
name: timetable [32079,32088]
name: timetable [32079,32088]
===
match
---
atom_expr [70093,70132]
atom_expr [70200,70239]
===
match
---
operator: , [62408,62409]
operator: , [62408,62409]
===
match
---
decorated [16413,16593]
decorated [16413,16593]
===
match
---
operator: , [22138,22139]
operator: , [22138,22139]
===
match
---
name: task [59689,59693]
name: task [59689,59693]
===
match
---
operator: , [11318,11319]
operator: , [11318,11319]
===
match
---
operator: , [49896,49897]
operator: , [49896,49897]
===
match
---
name: relative_fileloc [18932,18948]
name: relative_fileloc [18932,18948]
===
match
---
operator: , [41187,41188]
operator: , [41187,41188]
===
match
---
name: dag_id [86364,86370]
name: dag_id [86471,86477]
===
match
---
trailer [69183,69202]
trailer [69290,69309]
===
match
---
param [17221,17226]
param [17221,17226]
===
match
---
parameters [72146,72148]
parameters [72253,72255]
===
match
---
name: key [76560,76563]
name: key [76667,76670]
===
match
---
operator: , [58858,58859]
operator: , [58858,58859]
===
match
---
simple_stmt [34768,34980]
simple_stmt [34768,34980]
===
match
---
testlist_star_expr [84519,84558]
testlist_star_expr [84626,84665]
===
match
---
operator: } [72425,72426]
operator: } [72532,72533]
===
match
---
simple_stmt [62262,62286]
simple_stmt [62262,62286]
===
match
---
name: run_id [25645,25651]
name: run_id [25645,25651]
===
match
---
simple_stmt [25789,25806]
simple_stmt [25789,25806]
===
match
---
atom_expr [52842,52858]
atom_expr [52842,52858]
===
match
---
name: ignore_task_deps [60796,60812]
name: ignore_task_deps [60796,60812]
===
match
---
string: '' [68136,68138]
string: '' [68243,68245]
===
match
---
operator: @ [69996,69997]
operator: @ [70103,70104]
===
match
---
operator: + [39461,39462]
operator: + [39461,39462]
===
match
---
name: retry_delay [38218,38229]
name: retry_delay [38218,38229]
===
match
---
name: dep_context [36786,36797]
name: dep_context [36786,36797]
===
match
---
parameters [69938,69944]
parameters [70045,70051]
===
match
---
operator: , [19285,19286]
operator: , [19285,19286]
===
match
---
suite [88419,88453]
suite [88526,88560]
===
match
---
atom_expr [6557,6570]
atom_expr [6557,6570]
===
match
---
name: inspect [40636,40643]
name: inspect [40636,40643]
===
match
---
name: self [93802,93806]
name: self [93909,93913]
===
match
---
atom_expr [72662,72681]
atom_expr [72769,72788]
===
match
---
trailer [49245,49250]
trailer [49245,49250]
===
match
---
name: execution_date [31600,31614]
name: execution_date [31600,31614]
===
match
---
except_clause [3718,3736]
except_clause [3718,3736]
===
match
---
operator: , [9926,9927]
operator: , [9926,9927]
===
match
---
atom_expr [12839,12874]
atom_expr [12839,12874]
===
match
---
expr_stmt [35045,35105]
expr_stmt [35045,35105]
===
match
---
trailer [65478,65495]
trailer [65585,65602]
===
match
---
atom_expr [57800,57824]
atom_expr [57800,57824]
===
match
---
argument [61283,61316]
argument [61283,61316]
===
match
---
trailer [91615,91622]
trailer [91722,91729]
===
match
---
or_test [28963,28994]
or_test [28963,28994]
===
match
---
name: settings [67161,67169]
name: settings [67268,67276]
===
match
---
string: "Task Duration set to %s" [85033,85058]
string: "Task Duration set to %s" [85140,85165]
===
match
---
name: extend [22287,22293]
name: extend [22287,22293]
===
match
---
suite [80328,81254]
suite [80435,81361]
===
match
---
name: Tuple [9801,9806]
name: Tuple [9801,9806]
===
match
---
param [27117,27122]
param [27117,27122]
===
match
---
name: dr [9399,9401]
name: dr [9399,9401]
===
match
---
simple_stmt [68288,68358]
simple_stmt [68395,68465]
===
match
---
name: property [92969,92977]
name: property [93076,93084]
===
match
---
param [4944,4960]
param [4944,4960]
===
match
---
name: filter_for_tis [90059,90073]
name: filter_for_tis [90166,90180]
===
match
---
trailer [91505,91512]
trailer [91612,91619]
===
match
---
trailer [53935,53940]
trailer [53935,53940]
===
match
---
name: session [66116,66123]
name: session [66223,66230]
===
match
---
atom_expr [49313,49369]
atom_expr [49313,49369]
===
match
---
name: subject [84519,84526]
name: subject [84626,84633]
===
match
---
atom_expr [37040,37057]
atom_expr [37040,37057]
===
match
---
name: dag [32108,32111]
name: dag [32108,32111]
===
match
---
name: task_id [91561,91568]
name: task_id [91668,91675]
===
match
---
argument [75779,75815]
argument [75886,75922]
===
match
---
operator: , [35733,35734]
operator: , [35733,35734]
===
match
---
name: log [45997,46000]
name: log [45997,46000]
===
match
---
param [63416,63449]
param [63416,63449]
===
match
---
name: quote [23407,23412]
name: quote [23407,23412]
===
match
---
name: with_for_update [25737,25752]
name: with_for_update [25737,25752]
===
match
---
name: default_var [71155,71166]
name: default_var [71262,71273]
===
match
---
name: instance [8978,8986]
name: instance [8978,8986]
===
match
---
name: models [79249,79255]
name: models [79356,79362]
===
match
---
simple_stmt [93846,93894]
simple_stmt [93953,94001]
===
match
---
dotted_name [3019,3038]
dotted_name [3019,3038]
===
match
---
name: self [55585,55589]
name: self [55585,55589]
===
match
---
name: session [32220,32227]
name: session [32220,32227]
===
match
---
operator: -> [72087,72089]
operator: -> [72194,72196]
===
match
---
name: warnings [14551,14559]
name: warnings [14551,14559]
===
match
---
simple_stmt [69080,69092]
simple_stmt [69187,69199]
===
match
---
trailer [6457,6475]
trailer [6457,6475]
===
match
---
param [47118,47123]
param [47118,47123]
===
match
---
trailer [67338,67347]
trailer [67445,67454]
===
match
---
trailer [9045,9062]
trailer [9045,9062]
===
match
---
name: start_date [92314,92324]
name: start_date [92421,92431]
===
match
---
name: str [19824,19827]
name: str [19824,19827]
===
match
---
operator: = [40829,40830]
operator: = [40829,40830]
===
match
---
operator: = [54866,54867]
operator: = [54866,54867]
===
match
---
name: self [46519,46523]
name: self [46519,46523]
===
match
---
atom_expr [63504,63517]
atom_expr [63504,63517]
===
match
---
param [14109,14114]
param [14109,14114]
===
match
---
simple_stmt [847,857]
simple_stmt [847,857]
===
match
---
suite [37877,37970]
suite [37877,37970]
===
match
---
trailer [18920,18931]
trailer [18920,18931]
===
match
---
name: context [53974,53981]
name: context [53974,53981]
===
match
---
name: UtcDateTime [12423,12434]
name: UtcDateTime [12423,12434]
===
match
---
name: handle_failure [51775,51789]
name: handle_failure [51775,51789]
===
match
---
name: TaskDeferralError [2204,2221]
name: TaskDeferralError [2204,2221]
===
match
---
suite [9515,9604]
suite [9515,9604]
===
match
---
operator: , [31679,31680]
operator: , [31679,31680]
===
match
---
name: airflow [1822,1829]
name: airflow [1822,1829]
===
match
---
simple_stmt [18819,18831]
simple_stmt [18819,18831]
===
match
---
name: dag [18879,18882]
name: dag [18879,18882]
===
match
---
name: state [60228,60233]
name: state [60228,60233]
===
match
---
operator: , [62818,62819]
operator: , [62818,62819]
===
match
---
name: timezone [40385,40393]
name: timezone [40385,40393]
===
match
---
suite [70701,70803]
suite [70808,70910]
===
match
---
operator: , [47471,47472]
operator: , [47471,47472]
===
match
---
atom_expr [91769,91788]
atom_expr [91876,91895]
===
match
---
simple_stmt [78280,78383]
simple_stmt [78387,78490]
===
match
---
operator: = [60966,60967]
operator: = [60966,60967]
===
match
---
atom_expr [67323,67347]
atom_expr [67430,67454]
===
match
---
funcdef [63336,66164]
funcdef [63336,66271]
===
match
---
name: render_template_fields [80243,80265]
name: render_template_fields [80350,80372]
===
match
---
operator: = [13649,13650]
operator: = [13649,13650]
===
match
---
operator: = [44060,44061]
operator: = [44060,44061]
===
match
---
atom_expr [36619,36631]
atom_expr [36619,36631]
===
match
---
atom_expr [84930,84945]
atom_expr [85037,85052]
===
match
---
string: "task_instances" [13958,13974]
string: "task_instances" [13958,13974]
===
match
---
argument [13642,13655]
argument [13642,13655]
===
match
---
atom_expr [69111,69128]
atom_expr [69218,69235]
===
match
---
trailer [83511,83518]
trailer [83618,83625]
===
match
---
argument [57052,57067]
argument [57052,57067]
===
match
---
operator: == [89781,89783]
operator: == [89888,89890]
===
match
---
except_clause [60109,60125]
except_clause [60109,60125]
===
match
---
atom_expr [70794,70802]
atom_expr [70901,70909]
===
match
---
name: self [79154,79158]
name: self [79261,79265]
===
match
---
name: session [51667,51674]
name: session [51667,51674]
===
match
---
trailer [59994,60015]
trailer [59994,60015]
===
match
---
trailer [88549,88765]
trailer [88656,88872]
===
match
---
simple_stmt [57926,57954]
simple_stmt [57926,57954]
===
match
---
atom_expr [46663,46679]
atom_expr [46663,46679]
===
match
---
trailer [24814,24820]
trailer [24814,24820]
===
match
---
param [92128,92133]
param [92235,92240]
===
match
---
name: self [17157,17161]
name: self [17157,17161]
===
match
---
expr_stmt [90530,90551]
expr_stmt [90637,90658]
===
match
---
operator: = [86624,86625]
operator: = [86731,86732]
===
match
---
name: next_method [55763,55774]
name: next_method [55763,55774]
===
match
---
operator: , [10148,10149]
operator: , [10148,10149]
===
match
---
name: session [76910,76917]
name: session [77017,77024]
===
match
---
funcdef [93612,93663]
funcdef [93719,93770]
===
match
---
suite [6026,6301]
suite [6026,6301]
===
match
---
funcdef [93128,93194]
funcdef [93235,93301]
===
match
---
name: compat [1859,1865]
name: compat [1859,1865]
===
match
---
operator: = [41374,41375]
operator: = [41374,41375]
===
match
---
import_from [3057,3103]
import_from [3057,3103]
===
match
---
trailer [70798,70802]
trailer [70905,70909]
===
match
---
name: Index [12793,12798]
name: Index [12793,12798]
===
match
---
atom_expr [50174,50193]
atom_expr [50174,50193]
===
match
---
if_stmt [19049,19124]
if_stmt [19049,19124]
===
match
---
param [18121,18143]
param [18121,18143]
===
match
---
operator: == [89833,89835]
operator: == [89940,89942]
===
match
---
operator: = [92489,92490]
operator: = [92596,92597]
===
match
---
simple_stmt [8929,8966]
simple_stmt [8929,8966]
===
match
---
tfpdef [41460,41481]
tfpdef [41460,41481]
===
match
---
name: session [44253,44260]
name: session [44253,44260]
===
match
---
atom_expr [40877,40888]
atom_expr [40877,40888]
===
match
---
name: Literal [5454,5461]
name: Literal [5454,5461]
===
match
---
name: os [53491,53493]
name: os [53491,53493]
===
match
---
if_stmt [38238,40108]
if_stmt [38238,40108]
===
match
---
return_stmt [91162,91354]
return_stmt [91269,91461]
===
match
---
name: f [84033,84034]
name: f [84140,84141]
===
match
---
operator: } [15899,15900]
operator: } [15899,15900]
===
match
---
operator: = [12182,12183]
operator: = [12182,12183]
===
match
---
atom_expr [92311,92324]
atom_expr [92418,92431]
===
match
---
atom_expr [79605,79680]
atom_expr [79712,79787]
===
match
---
param [93143,93147]
param [93250,93254]
===
match
---
atom_expr [40319,40329]
atom_expr [40319,40329]
===
match
---
atom_expr [69725,69733]
atom_expr [69832,69840]
===
match
---
tfpdef [14158,14169]
tfpdef [14158,14169]
===
match
---
name: run_id [90849,90855]
name: run_id [90956,90962]
===
match
---
operator: , [13897,13898]
operator: , [13897,13898]
===
match
---
name: signal [878,884]
name: signal [878,884]
===
match
---
decorator [3956,3983]
decorator [3956,3983]
===
match
---
name: debug [28856,28861]
name: debug [28856,28861]
===
match
---
operator: , [79559,79560]
operator: , [79666,79667]
===
match
---
suite [54286,54437]
suite [54286,54437]
===
match
---
expr_stmt [6542,6589]
expr_stmt [6542,6589]
===
match
---
expr_stmt [15435,15491]
expr_stmt [15435,15491]
===
match
---
suite [89940,90032]
suite [90047,90139]
===
match
---
operator: , [39903,39904]
operator: , [39903,39904]
===
match
---
operator: @ [28524,28525]
operator: @ [28524,28525]
===
match
---
except_clause [57081,57106]
except_clause [57081,57106]
===
match
---
funcdef [37975,40145]
funcdef [37975,40145]
===
match
---
import_as_names [3932,3953]
import_as_names [3932,3953]
===
match
---
name: duration [84902,84910]
name: duration [85009,85017]
===
match
---
trailer [46453,46474]
trailer [46453,46474]
===
match
---
trailer [32181,32211]
trailer [32181,32211]
===
match
---
name: kube_config [80979,80990]
name: kube_config [81086,81097]
===
match
---
operator: = [75561,75562]
operator: = [75668,75669]
===
match
---
fstring_start: f" [23638,23640]
fstring_start: f" [23638,23640]
===
match
---
expr_stmt [18910,18948]
expr_stmt [18910,18948]
===
match
---
if_stmt [45499,46175]
if_stmt [45499,46175]
===
match
---
name: task [27700,27704]
name: task [27700,27704]
===
match
---
simple_stmt [8780,8802]
simple_stmt [8780,8802]
===
match
---
atom_expr [45938,45952]
atom_expr [45938,45952]
===
match
---
expr_stmt [55806,55842]
expr_stmt [55806,55842]
===
match
---
atom_expr [10360,10371]
atom_expr [10360,10371]
===
match
---
atom_expr [63716,63744]
atom_expr [63716,63744]
===
match
---
operator: = [67969,67970]
operator: = [68076,68077]
===
match
---
number: 0 [4737,4738]
number: 0 [4737,4738]
===
match
---
arglist [10123,10190]
arglist [10123,10190]
===
match
---
name: cfg_path [20256,20264]
name: cfg_path [20256,20264]
===
match
---
name: local [19540,19545]
name: local [19540,19545]
===
match
---
parameters [17311,17317]
parameters [17311,17317]
===
match
---
suite [23064,23309]
suite [23064,23309]
===
match
---
operator: , [91622,91623]
operator: , [91729,91730]
===
match
---
name: query [25479,25484]
name: query [25479,25484]
===
match
---
operator: , [81009,81010]
operator: , [81116,81117]
===
match
---
suite [73623,73782]
suite [73730,73889]
===
match
---
name: cmd [22789,22792]
name: cmd [22789,22792]
===
match
---
simple_stmt [81558,81612]
simple_stmt [81665,81719]
===
match
---
name: task [59906,59910]
name: task [59906,59910]
===
match
---
param [52306,52311]
param [52306,52311]
===
match
---
operator: = [67222,67223]
operator: = [67329,67330]
===
match
---
trailer [54642,54655]
trailer [54642,54655]
===
match
---
operator: , [76287,76288]
operator: , [76394,76395]
===
match
---
try_stmt [71806,71972]
try_stmt [71913,72079]
===
match
---
name: _pool [92657,92662]
name: _pool [92764,92769]
===
match
---
trailer [28106,28260]
trailer [28106,28260]
===
match
---
name: log [53317,53320]
name: log [53317,53320]
===
match
---
operator: , [27115,27116]
operator: , [27115,27116]
===
match
---
operator: , [89742,89743]
operator: , [89849,89850]
===
match
---
atom_expr [65525,65535]
atom_expr [65632,65642]
===
match
---
name: error [62064,62069]
name: error [62064,62069]
===
match
---
string: """Send alert email with exception information.""" [84460,84510]
string: """Send alert email with exception information.""" [84567,84617]
===
match
---
if_stmt [49204,49429]
if_stmt [49204,49429]
===
match
---
name: ti [25901,25903]
name: ti [25901,25903]
===
match
---
name: tis [91144,91147]
name: tis [91251,91254]
===
match
---
name: min [40070,40073]
name: min [40070,40073]
===
match
---
trailer [38212,38217]
trailer [38212,38217]
===
match
---
atom_expr [7101,7110]
atom_expr [7101,7110]
===
match
---
simple_stmt [62294,62314]
simple_stmt [62294,62314]
===
match
---
parameters [52469,52484]
parameters [52469,52484]
===
match
---
simple_stmt [12289,12321]
simple_stmt [12289,12321]
===
match
---
trailer [27585,27601]
trailer [27585,27601]
===
match
---
atom_expr [25591,25603]
atom_expr [25591,25603]
===
match
---
name: __init__ [70560,70568]
name: __init__ [70667,70675]
===
match
---
expr_stmt [73716,73781]
expr_stmt [73823,73888]
===
match
---
name: Integer [12066,12073]
name: Integer [12066,12073]
===
match
---
atom_expr [4606,4637]
atom_expr [4606,4637]
===
match
---
simple_stmt [39011,39027]
simple_stmt [39011,39027]
===
match
---
trailer [52834,52890]
trailer [52834,52890]
===
match
---
arglist [4412,4551]
arglist [4412,4551]
===
match
---
argument [67377,67419]
argument [67484,67526]
===
match
---
simple_stmt [1008,1048]
simple_stmt [1008,1048]
===
match
---
trailer [61136,61523]
trailer [61136,61523]
===
match
---
name: instance [34567,34575]
name: instance [34567,34575]
===
match
---
name: on_success_callback [60064,60083]
name: on_success_callback [60064,60083]
===
match
---
arglist [37573,37754]
arglist [37573,37754]
===
match
---
return_stmt [69080,69091]
return_stmt [69187,69198]
===
match
---
name: stacklevel [14817,14827]
name: stacklevel [14817,14827]
===
match
---
name: test_mode [64130,64139]
name: test_mode [64130,64139]
===
match
---
name: self [66880,66884]
name: self [66987,66991]
===
match
---
name: activate_dag_runs [8477,8494]
name: activate_dag_runs [8477,8494]
===
match
---
funcdef [68618,68871]
funcdef [68725,68978]
===
match
---
name: self [70592,70596]
name: self [70699,70703]
===
match
---
arglist [67982,67989]
arglist [68089,68096]
===
match
---
trailer [73117,73136]
trailer [73224,73243]
===
match
---
trailer [25484,25498]
trailer [25484,25498]
===
match
---
trailer [12798,12829]
trailer [12798,12829]
===
match
---
name: dag [67752,67755]
name: dag [67859,67862]
===
match
---
name: run_id [12957,12963]
name: run_id [12957,12963]
===
match
---
operator: , [77801,77802]
operator: , [77908,77909]
===
match
---
suite [15344,15418]
suite [15344,15418]
===
match
---
operator: = [35932,35933]
operator: = [35932,35933]
===
match
---
import_from [2633,2693]
import_from [2633,2693]
===
match
---
name: func [72519,72523]
name: func [72626,72630]
===
match
---
name: execution_date [88504,88518]
name: execution_date [88611,88625]
===
match
---
trailer [28205,28220]
trailer [28205,28220]
===
match
---
name: __table_args__ [12766,12780]
name: __table_args__ [12766,12780]
===
match
---
atom_expr [58048,58064]
atom_expr [58048,58064]
===
match
---
string: 'joined' [13981,13989]
string: 'joined' [13981,13989]
===
match
---
operator: , [77687,77688]
operator: , [77794,77795]
===
match
---
operator: , [83845,83846]
operator: , [83952,83953]
===
match
---
param [92134,92150]
param [92241,92257]
===
match
---
name: max [39915,39918]
name: max [39915,39918]
===
match
---
operator: , [66428,66429]
operator: , [66535,66536]
===
match
---
atom_expr [34576,34598]
atom_expr [34576,34598]
===
match
---
simple_stmt [73513,73558]
simple_stmt [73620,73665]
===
match
---
name: RenderedTaskInstanceFields [79336,79362]
name: RenderedTaskInstanceFields [79443,79469]
===
match
---
arglist [33198,33408]
arglist [33198,33408]
===
match
---
atom_expr [50307,50323]
atom_expr [50307,50323]
===
match
---
name: getuser [3306,3313]
name: getuser [3306,3313]
===
match
---
operator: , [57406,57407]
operator: , [57406,57407]
===
match
---
name: self [52861,52865]
name: self [52861,52865]
===
match
---
suite [22503,22554]
suite [22503,22554]
===
match
---
name: local [22717,22722]
name: local [22717,22722]
===
match
---
name: self [58003,58007]
name: self [58003,58007]
===
match
---
operator: , [12857,12858]
operator: , [12857,12858]
===
match
---
fstring_string: <TaskInstance:  [37895,37910]
fstring_string: <TaskInstance:  [37895,37910]
===
match
---
atom [38592,38620]
atom [38592,38620]
===
match
---
trailer [63871,63884]
trailer [63871,63884]
===
match
---
atom_expr [26626,26640]
atom_expr [26626,26640]
===
match
---
simple_stmt [46040,46077]
simple_stmt [46040,46077]
===
match
---
simple_stmt [19096,19124]
simple_stmt [19096,19124]
===
match
---
operator: -> [20294,20296]
operator: -> [20294,20296]
===
match
---
atom_expr [78526,78572]
atom_expr [78633,78679]
===
match
---
name: self [51148,51152]
name: self [51148,51152]
===
match
---
atom_expr [25471,25662]
atom_expr [25471,25662]
===
match
---
if_stmt [58603,58823]
if_stmt [58603,58823]
===
match
---
expr_stmt [26322,26349]
expr_stmt [26322,26349]
===
match
---
operator: } [51517,51518]
operator: } [51517,51518]
===
match
---
expr_stmt [67313,67347]
expr_stmt [67420,67454]
===
match
---
trailer [58162,58174]
trailer [58162,58174]
===
match
---
trailer [12190,12224]
trailer [12190,12224]
===
match
---
trailer [9223,9232]
trailer [9223,9232]
===
match
---
atom_expr [69851,69859]
atom_expr [69958,69966]
===
match
---
simple_stmt [12559,12594]
simple_stmt [12559,12594]
===
match
---
atom_expr [69904,69912]
atom_expr [70011,70019]
===
match
---
simple_stmt [81165,81225]
simple_stmt [81272,81332]
===
match
---
name: params [67484,67490]
name: params [67591,67597]
===
match
---
name: start [67787,67792]
name: start [67894,67899]
===
match
---
if_stmt [32105,32322]
if_stmt [32105,32322]
===
match
---
operator: = [28584,28585]
operator: = [28584,28585]
===
match
---
number: 2 [33406,33407]
number: 2 [33406,33407]
===
match
---
atom_expr [27700,27712]
atom_expr [27700,27712]
===
match
---
simple_stmt [90485,90497]
simple_stmt [90592,90604]
===
match
---
trailer [79899,79905]
trailer [80006,80012]
===
match
---
arglist [67600,67639]
arglist [67707,67746]
===
match
---
name: state [12902,12907]
name: state [12902,12907]
===
match
---
string: "Marking success for %s on %s" [46908,46938]
string: "Marking success for %s on %s" [46908,46938]
===
match
---
name: primary_key [11339,11350]
name: primary_key [11339,11350]
===
match
---
atom_expr [25397,25455]
atom_expr [25397,25455]
===
match
---
simple_stmt [3014,3057]
simple_stmt [3014,3057]
===
match
---
trailer [32271,32291]
trailer [32271,32291]
===
match
---
trailer [58712,58728]
trailer [58712,58728]
===
match
---
name: filter [25499,25505]
name: filter [25499,25505]
===
match
---
not_test [49444,49457]
not_test [49444,49457]
===
match
---
operator: = [12083,12084]
operator: = [12083,12084]
===
match
---
trailer [67981,67990]
trailer [68088,68097]
===
match
---
name: catchup [32112,32119]
name: catchup [32112,32119]
===
match
---
argument [86293,86304]
argument [86400,86411]
===
match
---
operator: , [34067,34068]
operator: , [34067,34068]
===
match
---
name: kubernetes_helper_functions [80395,80422]
name: kubernetes_helper_functions [80502,80529]
===
match
---
atom_expr [26607,26623]
atom_expr [26607,26623]
===
match
---
name: ti [25789,25791]
name: ti [25789,25791]
===
match
---
sync_comp_for [9254,9302]
sync_comp_for [9254,9302]
===
match
---
param [41197,41218]
param [41197,41218]
===
match
---
name: dag [30981,30984]
name: dag [30981,30984]
===
match
---
name: coerce_datetime [75504,75519]
name: coerce_datetime [75611,75626]
===
match
---
trailer [36629,36631]
trailer [36629,36631]
===
match
---
trailer [10174,10185]
trailer [10174,10185]
===
match
---
simple_stmt [65418,65444]
simple_stmt [65525,65551]
===
match
---
name: ForeignKeyConstraint [13117,13137]
name: ForeignKeyConstraint [13117,13137]
===
match
---
try_stmt [60452,60624]
try_stmt [60452,60624]
===
match
---
atom_expr [38599,38614]
atom_expr [38599,38614]
===
match
---
not_test [80161,80172]
not_test [80268,80279]
===
match
---
not_test [45502,45587]
not_test [45502,45587]
===
match
---
trailer [68331,68339]
trailer [68438,68446]
===
match
---
operator: , [41342,41343]
operator: , [41342,41343]
===
match
---
trailer [43169,43195]
trailer [43169,43195]
===
match
---
string: 'prev_execution_date_success' [76783,76812]
string: 'prev_execution_date_success' [76890,76919]
===
match
---
trailer [75469,75644]
trailer [75576,75751]
===
match
---
trailer [54045,54053]
trailer [54045,54053]
===
match
---
suite [57179,57235]
suite [57179,57235]
===
match
---
operator: , [83950,83951]
operator: , [84057,84058]
===
match
---
name: key [76743,76746]
name: key [76850,76853]
===
match
---
if_stmt [22257,22324]
if_stmt [22257,22324]
===
match
---
atom_expr [10373,10385]
atom_expr [10373,10385]
===
match
---
simple_stmt [60563,60624]
simple_stmt [60563,60624]
===
match
---
param [78118,78123]
param [78225,78230]
===
match
---
name: task_id [28152,28159]
name: task_id [28152,28159]
===
match
---
simple_stmt [25927,25955]
simple_stmt [25927,25955]
===
match
---
operator: , [35923,35924]
operator: , [35923,35924]
===
match
---
name: cache [1883,1888]
name: cache [1883,1888]
===
match
---
expr_stmt [64732,64755]
expr_stmt [64839,64862]
===
match
---
name: rendered_k8s_spec [79703,79720]
name: rendered_k8s_spec [79810,79827]
===
match
---
not_test [43403,43422]
not_test [43403,43422]
===
match
---
atom_expr [30113,30137]
atom_expr [30113,30137]
===
match
---
operator: -> [80086,80088]
operator: -> [80193,80195]
===
match
---
operator: , [88641,88642]
operator: , [88748,88749]
===
match
---
return_stmt [31628,31748]
return_stmt [31628,31748]
===
match
---
if_stmt [59923,60210]
if_stmt [59923,60210]
===
match
---
trailer [22293,22323]
trailer [22293,22323]
===
match
---
name: provide_session [47737,47752]
name: provide_session [47737,47752]
===
match
---
arglist [52187,52203]
arglist [52187,52203]
===
match
---
operator: = [20204,20205]
operator: = [20204,20205]
===
match
---
name: TR [7839,7841]
name: TR [7839,7841]
===
match
---
name: state [28923,28928]
name: state [28923,28928]
===
match
---
name: path [83076,83080]
name: path [83183,83187]
===
match
---
tfpdef [86719,86735]
tfpdef [86826,86842]
===
match
---
dotted_name [1774,1797]
dotted_name [1774,1797]
===
match
---
atom_expr [92537,92550]
atom_expr [92644,92657]
===
match
---
operator: = [23174,23175]
operator: = [23174,23175]
===
match
---
name: sanitized_pod [81165,81178]
name: sanitized_pod [81272,81285]
===
match
---
name: task [40079,40083]
name: task [40079,40083]
===
match
---
trailer [83891,83905]
trailer [83998,84012]
===
match
---
import_name [857,870]
import_name [857,870]
===
match
---
name: self [28963,28967]
name: self [28963,28967]
===
match
---
atom_expr [26762,26780]
atom_expr [26762,26780]
===
match
---
trailer [40643,40649]
trailer [40643,40649]
===
match
---
number: 1 [54753,54754]
number: 1 [54753,54754]
===
match
---
comparison [91367,91412]
comparison [91474,91519]
===
match
---
operator: , [18501,18502]
operator: , [18501,18502]
===
match
---
decorated [54799,55204]
decorated [54799,55204]
===
match
---
operator: = [60894,60895]
operator: = [60894,60895]
===
match
---
name: frame [52478,52483]
name: frame [52478,52483]
===
match
---
dotted_name [3665,3697]
dotted_name [3665,3697]
===
match
---
operator: = [88663,88664]
operator: = [88770,88771]
===
match
---
string: "DagModel" [13531,13541]
string: "DagModel" [13531,13541]
===
match
---
atom_expr [80196,80223]
atom_expr [80303,80330]
===
match
---
name: TaskInstance [91480,91492]
name: TaskInstance [91587,91599]
===
match
---
name: self [27773,27777]
name: self [27773,27777]
===
match
---
trailer [26412,26417]
trailer [26412,26417]
===
match
---
parameters [71473,71537]
parameters [71580,71644]
===
match
---
simple_stmt [15983,16003]
simple_stmt [15983,16003]
===
match
---
operator: , [12900,12901]
operator: , [12900,12901]
===
match
---
return_stmt [72654,72718]
return_stmt [72761,72825]
===
match
---
simple_stmt [11502,11533]
simple_stmt [11502,11533]
===
match
---
name: timezone [54998,55006]
name: timezone [54998,55006]
===
match
---
name: execute_callable [56113,56129]
name: execute_callable [56113,56129]
===
match
---
name: lock_for_update [24955,24970]
name: lock_for_update [24955,24970]
===
match
---
name: log [63862,63865]
name: log [63862,63865]
===
match
---
atom_expr [50531,50547]
atom_expr [50531,50547]
===
match
---
operator: , [40099,40100]
operator: , [40099,40100]
===
match
---
suite [69834,69913]
suite [69941,70020]
===
match
---
atom_expr [68933,68950]
atom_expr [69040,69057]
===
match
---
trailer [77754,77756]
trailer [77861,77863]
===
match
---
name: state [57931,57936]
name: state [57931,57936]
===
match
---
atom [82551,82563]
atom [82658,82670]
===
match
---
expr_stmt [80472,80498]
expr_stmt [80579,80605]
===
match
---
name: ignore_ti_state [60836,60851]
name: ignore_ti_state [60836,60851]
===
match
---
name: relationship [13725,13737]
name: relationship [13725,13737]
===
match
---
operator: , [9204,9205]
operator: , [9204,9205]
===
match
---
arglist [52682,52712]
arglist [52682,52712]
===
match
---
trailer [66503,66526]
trailer [66610,66633]
===
match
---
argument [88627,88641]
argument [88734,88748]
===
match
---
and_test [32108,32151]
and_test [32108,32151]
===
match
---
name: trigger_row [57812,57823]
name: trigger_row [57812,57823]
===
match
---
operator: = [64717,64718]
operator: = [64824,64825]
===
match
---
simple_stmt [15011,15186]
simple_stmt [15011,15186]
===
match
---
name: orm [1620,1623]
name: orm [1620,1623]
===
match
---
fstring [15845,15911]
fstring [15845,15911]
===
match
---
suite [38005,40145]
suite [38005,40145]
===
match
---
name: try_number [6560,6570]
name: try_number [6560,6570]
===
match
---
annassign [92483,92509]
annassign [92590,92616]
===
match
---
operator: = [32481,32482]
operator: = [32481,32482]
===
match
---
name: task [62194,62198]
name: task [62194,62198]
===
match
---
atom_expr [26362,26373]
atom_expr [26362,26373]
===
match
---
operator: = [30687,30688]
operator: = [30687,30688]
===
match
---
simple_stmt [22902,22938]
simple_stmt [22902,22938]
===
match
---
param [47124,47133]
param [47124,47133]
===
match
---
trailer [4731,4736]
trailer [4731,4736]
===
match
---
trailer [84039,84041]
trailer [84146,84148]
===
match
---
tfpdef [71698,71715]
tfpdef [71805,71822]
===
match
---
atom_expr [18742,18756]
atom_expr [18742,18756]
===
match
---
name: try_number [17184,17194]
name: try_number [17184,17194]
===
match
---
name: DeprecationWarning [14691,14709]
name: DeprecationWarning [14691,14709]
===
match
---
name: Column [12302,12308]
name: Column [12302,12308]
===
match
---
simple_stmt [39086,39364]
simple_stmt [39086,39364]
===
match
---
trailer [52258,52265]
trailer [52258,52265]
===
match
---
atom_expr [15652,15663]
atom_expr [15652,15663]
===
match
---
name: self [49241,49245]
name: self [49241,49245]
===
match
---
comparison [24270,24306]
comparison [24270,24306]
===
match
---
name: key [75918,75921]
name: key [76025,76028]
===
match
---
name: priority_weight [93516,93531]
name: priority_weight [93623,93638]
===
match
---
parameters [17220,17233]
parameters [17220,17233]
===
match
---
operator: = [55818,55819]
operator: = [55818,55819]
===
match
---
atom [15563,15743]
atom [15563,15743]
===
match
---
name: self [46484,46488]
name: self [46484,46488]
===
match
---
name: defaultdict [925,936]
name: defaultdict [925,936]
===
match
---
name: incr [54773,54777]
name: incr [54773,54777]
===
match
---
name: settings [1837,1845]
name: settings [1837,1845]
===
match
---
operator: , [12946,12947]
operator: , [12946,12947]
===
match
---
operator: = [5409,5410]
operator: = [5409,5410]
===
match
---
name: ignore_depends_on_past [18083,18105]
name: ignore_depends_on_past [18083,18105]
===
match
---
trailer [73897,73918]
trailer [74004,74025]
===
match
---
suite [78509,78573]
suite [78616,78680]
===
match
---
parameters [70636,70700]
parameters [70743,70807]
===
match
---
arglist [31665,31734]
arglist [31665,31734]
===
match
---
expr_stmt [43307,43327]
expr_stmt [43307,43327]
===
match
---
name: test_mode [16538,16547]
name: test_mode [16538,16547]
===
match
---
trailer [54702,54707]
trailer [54702,54707]
===
match
---
name: self [69702,69706]
name: self [69809,69813]
===
match
---
param [93226,93230]
param [93333,93337]
===
match
---
operator: = [43267,43268]
operator: = [43267,43268]
===
match
---
funcdef [33476,33996]
funcdef [33476,33996]
===
match
---
operator: -> [9977,9979]
operator: -> [9977,9979]
===
match
---
expr_stmt [18736,18756]
expr_stmt [18736,18756]
===
match
---
trailer [67973,67981]
trailer [68080,68088]
===
match
---
name: log [47323,47326]
name: log [47323,47326]
===
match
---
atom_expr [80313,80327]
atom_expr [80420,80434]
===
match
---
name: deps [45238,45242]
name: deps [45238,45242]
===
match
---
atom [75105,78058]
atom [75212,78165]
===
match
---
name: airflow [2437,2444]
name: airflow [2437,2444]
===
match
---
operator: == [91094,91096]
operator: == [91201,91203]
===
match
---
if_stmt [58980,59059]
if_stmt [58980,59059]
===
match
---
name: self [62164,62168]
name: self [62164,62168]
===
match
---
name: hasattr [81528,81535]
name: hasattr [81635,81642]
===
match
---
trailer [37050,37057]
trailer [37050,37057]
===
match
---
simple_stmt [5296,5324]
simple_stmt [5296,5324]
===
match
---
name: local [18152,18157]
name: local [18152,18157]
===
match
---
string: '<br>' [81604,81610]
string: '<br>' [81711,81717]
===
match
---
atom_expr [93846,93885]
atom_expr [93953,93992]
===
match
---
trailer [64157,64173]
trailer [64157,64173]
===
match
---
simple_stmt [17150,17178]
simple_stmt [17150,17178]
===
match
---
name: self [50139,50143]
name: self [50139,50143]
===
match
---
name: self [28475,28479]
name: self [28475,28479]
===
match
---
trailer [28059,28065]
trailer [28059,28065]
===
match
---
argument [28234,28249]
argument [28234,28249]
===
match
---
name: dag_id [8129,8135]
name: dag_id [8129,8135]
===
match
---
name: jinja_context [83201,83214]
name: jinja_context [83308,83321]
===
match
---
arglist [11400,11424]
arglist [11400,11424]
===
match
---
decorated [70886,71203]
decorated [70993,71310]
===
match
---
trailer [5942,5968]
trailer [5942,5968]
===
match
---
name: next_kwargs [55883,55894]
name: next_kwargs [55883,55894]
===
match
---
return_stmt [10558,10569]
return_stmt [10558,10569]
===
match
---
simple_stmt [90560,90582]
simple_stmt [90667,90689]
===
match
---
argument [7726,8079]
argument [7726,8079]
===
match
---
operator: , [11230,11231]
operator: , [11230,11231]
===
match
---
operator: , [86709,86710]
operator: , [86816,86817]
===
match
---
simple_stmt [63857,63885]
simple_stmt [63857,63885]
===
match
---
trailer [24750,24754]
trailer [24750,24754]
===
match
---
expr_stmt [81621,81662]
expr_stmt [81728,81769]
===
match
---
expr_stmt [12598,12632]
expr_stmt [12598,12632]
===
match
---
atom_expr [58303,58320]
atom_expr [58303,58320]
===
match
---
comparison [55758,55788]
comparison [55758,55788]
===
match
---
name: context [80165,80172]
name: context [80272,80279]
===
match
---
name: self [59990,59994]
name: self [59990,59994]
===
match
---
name: task [53588,53592]
name: task [53588,53592]
===
match
---
trailer [40380,40382]
trailer [40380,40382]
===
match
---
trailer [43208,43218]
trailer [43208,43218]
===
match
---
suite [16054,16086]
suite [16054,16086]
===
match
---
trailer [92313,92324]
trailer [92420,92431]
===
match
---
atom_expr [30520,30549]
atom_expr [30520,30549]
===
match
---
operator: = [89022,89023]
operator: = [89129,89130]
===
match
---
name: TemplateAssertionError [79537,79559]
name: TemplateAssertionError [79644,79666]
===
match
---
suite [69286,69315]
suite [69393,69422]
===
match
---
atom_expr [5454,5468]
atom_expr [5454,5468]
===
match
---
atom_expr [9092,9353]
atom_expr [9092,9353]
===
match
---
operator: = [49362,49363]
operator: = [49362,49363]
===
match
---
name: sqlalchemy [1774,1784]
name: sqlalchemy [1774,1784]
===
match
---
trailer [49121,49126]
trailer [49121,49126]
===
match
---
atom [22747,22758]
atom [22747,22758]
===
match
---
trailer [58675,58686]
trailer [58675,58686]
===
match
---
name: self [49253,49257]
name: self [49253,49257]
===
match
---
parameters [73103,73105]
parameters [73210,73212]
===
match
---
name: error_file [5060,5070]
name: error_file [5060,5070]
===
match
---
name: dag_id [49149,49155]
name: dag_id [49149,49155]
===
match
---
trailer [78500,78506]
trailer [78607,78613]
===
match
---
atom_expr [34740,34757]
atom_expr [34740,34757]
===
match
---
name: bool [60889,60893]
name: bool [60889,60893]
===
match
---
param [16449,16453]
param [16449,16453]
===
match
---
name: COLLATION_ARGS [12208,12222]
name: COLLATION_ARGS [12208,12222]
===
match
---
comparison [66641,66671]
comparison [66748,66778]
===
match
---
number: 1 [39937,39938]
number: 1 [39937,39938]
===
match
---
trailer [64569,64578]
trailer [64676,64685]
===
match
---
name: models [2366,2372]
name: models [2366,2372]
===
match
---
name: viewonly [13689,13697]
name: viewonly [13689,13697]
===
match
---
name: Optional [93541,93549]
name: Optional [93648,93656]
===
match
---
simple_stmt [2477,2534]
simple_stmt [2477,2534]
===
match
---
name: self [27460,27464]
name: self [27460,27464]
===
match
---
param [18173,18188]
param [18173,18188]
===
match
---
name: include_prior_dates [86676,86695]
name: include_prior_dates [86783,86802]
===
match
---
atom_expr [32917,32972]
atom_expr [32917,32972]
===
match
---
name: cache [73062,73067]
name: cache [73169,73174]
===
match
---
fstring_end: ' [54750,54751]
fstring_end: ' [54750,54751]
===
match
---
name: exception_html [83618,83632]
name: exception_html [83725,83739]
===
match
---
name: sanitized_pod [81240,81253]
name: sanitized_pod [81347,81360]
===
match
---
name: task_ids [88664,88672]
name: task_ids [88771,88779]
===
match
---
name: AirflowTaskTimeout [56892,56910]
name: AirflowTaskTimeout [56892,56910]
===
match
---
operator: , [51825,51826]
operator: , [51825,51826]
===
match
---
import_as_names [3417,3442]
import_as_names [3417,3442]
===
match
---
operator: , [52476,52477]
operator: , [52476,52477]
===
match
---
atom_expr [92181,92190]
atom_expr [92288,92297]
===
match
---
operator: = [18136,18137]
operator: = [18136,18137]
===
match
---
name: self [59575,59579]
name: self [59575,59579]
===
match
---
name: signal [52668,52674]
name: signal [52668,52674]
===
match
---
operator: @ [68166,68167]
operator: @ [68273,68274]
===
match
---
name: ID_LEN [11400,11406]
name: ID_LEN [11400,11406]
===
match
---
simple_stmt [46252,46332]
simple_stmt [46252,46332]
===
match
---
name: settings [81125,81133]
name: settings [81232,81240]
===
match
---
trailer [76888,76926]
trailer [76995,77033]
===
match
---
atom_expr [93413,93424]
atom_expr [93520,93531]
===
match
---
name: dag_id [90935,90941]
name: dag_id [91042,91048]
===
match
---
trailer [66660,66671]
trailer [66767,66778]
===
match
---
simple_stmt [31758,31771]
simple_stmt [31758,31771]
===
match
---
name: self [54853,54857]
name: self [54853,54857]
===
match
---
operator: , [50061,50062]
operator: , [50061,50062]
===
match
---
operator: == [91555,91557]
operator: == [91662,91664]
===
match
---
atom_expr [70729,70770]
atom_expr [70836,70877]
===
match
---
atom_expr [90814,90822]
atom_expr [90921,90929]
===
match
---
string: "TaskInstance" [90094,90108]
string: "TaskInstance" [90201,90215]
===
match
---
trailer [62040,62063]
trailer [62040,62063]
===
match
---
operator: , [14107,14108]
operator: , [14107,14108]
===
match
---
name: handle_failure [66402,66416]
name: handle_failure [66509,66523]
===
match
---
simple_stmt [62036,62077]
simple_stmt [62036,62077]
===
match
---
operator: , [92132,92133]
operator: , [92239,92240]
===
match
---
atom_expr [29175,29190]
atom_expr [29175,29190]
===
match
---
trailer [50891,50893]
trailer [50891,50893]
===
match
---
trailer [40393,40400]
trailer [40393,40400]
===
match
---
name: self [29475,29479]
name: self [29475,29479]
===
match
---
name: pool [18237,18241]
name: pool [18237,18241]
===
match
---
operator: , [35701,35702]
operator: , [35701,35702]
===
match
---
name: DagRun [40890,40896]
name: DagRun [40890,40896]
===
match
---
subscriptlist [91961,91981]
subscriptlist [92068,92088]
===
match
---
argument [19267,19285]
argument [19267,19285]
===
match
---
name: relative_fileloc [18994,19010]
name: relative_fileloc [18994,19010]
===
match
---
name: self [50151,50155]
name: self [50151,50155]
===
match
---
suite [4638,4923]
suite [4638,4923]
===
match
---
simple_stmt [8516,8734]
simple_stmt [8516,8734]
===
match
---
simple_stmt [62182,62223]
simple_stmt [62182,62223]
===
match
---
decorated [93668,93741]
decorated [93775,93848]
===
match
---
trailer [7730,8017]
trailer [7730,8017]
===
match
---
name: conf [80013,80017]
name: conf [80120,80124]
===
match
---
name: self [92872,92876]
name: self [92979,92983]
===
match
---
param [47283,47288]
param [47283,47288]
===
match
---
name: str [9807,9810]
name: str [9807,9810]
===
match
---
name: ignore_ti_state [20005,20020]
name: ignore_ti_state [20005,20020]
===
match
---
atom_expr [57313,57335]
atom_expr [57313,57335]
===
match
---
annassign [92437,92453]
annassign [92544,92560]
===
match
---
atom_expr [15452,15491]
atom_expr [15452,15491]
===
match
---
operator: = [13562,13563]
operator: = [13562,13563]
===
match
---
funcdef [17206,17268]
funcdef [17206,17268]
===
match
---
atom_expr [46377,46393]
atom_expr [46377,46393]
===
match
---
atom_expr [64700,64716]
atom_expr [64807,64823]
===
match
---
decorated [27809,28305]
decorated [27809,28305]
===
match
---
testlist_comp [22983,23005]
testlist_comp [22983,23005]
===
match
---
trailer [14226,14228]
trailer [14226,14228]
===
match
---
operator: = [13412,13413]
operator: = [13412,13413]
===
match
---
trailer [84901,84910]
trailer [85008,85017]
===
match
---
atom_expr [34558,34599]
atom_expr [34558,34599]
===
match
---
name: reschedule_exception [62902,62922]
name: reschedule_exception [62902,62922]
===
match
---
operator: = [89333,89334]
operator: = [89440,89441]
===
match
---
trailer [83293,83310]
trailer [83400,83417]
===
match
---
name: hexdigest [39317,39326]
name: hexdigest [39317,39326]
===
match
---
simple_stmt [82535,82564]
simple_stmt [82642,82671]
===
match
---
suite [9386,9604]
suite [9386,9604]
===
match
---
suite [18277,19720]
suite [18277,19720]
===
match
---
trailer [88445,88452]
trailer [88552,88559]
===
match
---
name: airflow [79241,79248]
name: airflow [79348,79355]
===
match
---
simple_stmt [74289,74316]
simple_stmt [74396,74423]
===
match
---
atom_expr [64259,64278]
atom_expr [64259,64278]
===
match
---
trailer [55154,55203]
trailer [55154,55203]
===
match
---
operator: = [61926,61927]
operator: = [61926,61927]
===
match
---
name: and_ [91454,91458]
name: and_ [91561,91565]
===
match
---
name: _date_or_empty [50033,50047]
name: _date_or_empty [50033,50047]
===
match
---
name: Session [32498,32505]
name: Session [32498,32505]
===
match
---
operator: = [54956,54957]
operator: = [54956,54957]
===
match
---
trailer [91263,91270]
trailer [91370,91377]
===
match
---
operator: , [61269,61270]
operator: , [61269,61270]
===
match
---
comparison [68512,68526]
comparison [68619,68633]
===
match
---
name: TaskInstance [24324,24336]
name: TaskInstance [24324,24336]
===
match
---
trailer [7878,7882]
trailer [7878,7882]
===
match
---
name: TaskInstance [30293,30305]
name: TaskInstance [30293,30305]
===
match
---
trailer [63253,63309]
trailer [63253,63309]
===
match
---
fstring_string: . [49156,49157]
fstring_string: . [49156,49157]
===
match
---
except_clause [59067,59083]
except_clause [59067,59083]
===
match
---
name: sqlalchemy [1492,1502]
name: sqlalchemy [1492,1502]
===
match
---
trailer [28273,28277]
trailer [28273,28277]
===
match
---
operator: , [61210,61211]
operator: , [61210,61211]
===
match
---
name: run_ids [9224,9231]
name: run_ids [9224,9231]
===
match
---
param [54853,54858]
param [54853,54858]
===
match
---
name: tis [90436,90439]
name: tis [90543,90546]
===
match
---
atom_expr [34157,34174]
atom_expr [34157,34174]
===
match
---
atom_expr [51505,51517]
atom_expr [51505,51517]
===
match
---
name: execution_timeout [58805,58822]
name: execution_timeout [58805,58822]
===
match
---
name: ts_nodash [77626,77635]
name: ts_nodash [77733,77742]
===
match
---
param [37999,38003]
param [37999,38003]
===
match
---
trailer [80597,80605]
trailer [80704,80712]
===
match
---
suite [73575,73782]
suite [73682,73889]
===
match
---
name: str [4956,4959]
name: str [4956,4959]
===
match
---
name: ignore_depends_on_past [61247,61269]
name: ignore_depends_on_past [61247,61269]
===
match
---
expr_stmt [39861,39939]
expr_stmt [39861,39939]
===
match
---
expr_stmt [15554,15743]
expr_stmt [15554,15743]
===
match
---
name: self [66397,66401]
name: self [66504,66508]
===
match
---
simple_stmt [59619,59648]
simple_stmt [59619,59648]
===
match
---
name: registered [54275,54285]
name: registered [54275,54285]
===
match
---
arglist [77905,77941]
arglist [78012,78048]
===
match
---
atom_expr [15953,15964]
atom_expr [15953,15964]
===
match
---
name: raw [20155,20158]
name: raw [20155,20158]
===
match
---
string: 'ti_successes' [54778,54792]
string: 'ti_successes' [54778,54792]
===
match
---
name: dag_id [12815,12821]
name: dag_id [12815,12821]
===
match
---
trailer [60083,60092]
trailer [60083,60092]
===
match
---
suite [68692,68871]
suite [68799,68978]
===
match
---
name: key [86640,86643]
name: key [86747,86750]
===
match
---
trailer [60227,60233]
trailer [60227,60233]
===
match
---
name: file_path [22926,22935]
name: file_path [22926,22935]
===
match
---
name: and_ [7834,7838]
name: and_ [7834,7838]
===
match
---
atom_expr [44314,44330]
atom_expr [44314,44330]
===
match
---
atom_expr [38568,38589]
atom_expr [38568,38589]
===
match
---
name: State [30429,30434]
name: State [30429,30434]
===
match
---
name: filter [89684,89690]
name: filter [89791,89797]
===
match
---
fstring_expr [77317,77328]
fstring_expr [77424,77435]
===
match
---
name: self [93177,93181]
name: self [93284,93288]
===
match
---
atom_expr [6542,6554]
atom_expr [6542,6554]
===
match
---
atom_expr [52787,52809]
atom_expr [52787,52809]
===
match
---
argument [45389,45422]
argument [45389,45422]
===
match
---
argument [53410,53461]
argument [53410,53461]
===
match
---
operator: , [47674,47675]
operator: , [47674,47675]
===
match
---
atom_expr [49560,49573]
atom_expr [49560,49573]
===
match
---
atom_expr [28475,28487]
atom_expr [28475,28487]
===
match
---
expr_stmt [40629,40649]
expr_stmt [40629,40649]
===
match
---
name: pop [4327,4330]
name: pop [4327,4330]
===
match
---
operator: = [11902,11903]
operator: = [11902,11903]
===
match
---
suite [71538,71607]
suite [71645,71714]
===
match
---
not_test [46411,46424]
not_test [46411,46424]
===
match
---
trailer [4696,4703]
trailer [4696,4703]
===
match
---
expr_stmt [16316,16332]
expr_stmt [16316,16332]
===
match
---
atom [89215,89261]
atom [89322,89368]
===
match
---
name: test_mode [48990,48999]
name: test_mode [48990,48999]
===
match
---
trailer [37416,37421]
trailer [37416,37421]
===
match
---
arith_expr [72662,72696]
arith_expr [72769,72803]
===
match
---
name: self [23612,23616]
name: self [23612,23616]
===
match
---
simple_stmt [84717,84772]
simple_stmt [84824,84879]
===
match
---
name: self [17807,17811]
name: self [17807,17811]
===
match
---
operator: @ [32978,32979]
operator: @ [32978,32979]
===
match
---
funcdef [62340,63310]
funcdef [62340,63310]
===
match
---
name: ignore_depends_on_past [19919,19941]
name: ignore_depends_on_past [19919,19941]
===
match
---
argument [33915,33927]
argument [33915,33927]
===
match
---
name: self [25591,25595]
name: self [25591,25595]
===
match
---
return_stmt [30504,30549]
return_stmt [30504,30549]
===
match
---
simple_stmt [11377,11461]
simple_stmt [11377,11461]
===
match
---
name: self [62627,62631]
name: self [62627,62631]
===
match
---
return_stmt [89412,89447]
return_stmt [89519,89554]
===
match
---
simple_stmt [93406,93425]
simple_stmt [93513,93532]
===
match
---
fstring [52835,52889]
fstring [52835,52889]
===
match
---
name: execution_date [85951,85965]
name: execution_date [86058,86072]
===
match
---
param [92921,92925]
param [93028,93032]
===
match
---
trailer [35523,35528]
trailer [35523,35528]
===
match
---
name: str [93076,93079]
name: str [93183,93186]
===
match
---
string: "previous_start_date was called" [35003,35035]
string: "previous_start_date was called" [35003,35035]
===
match
---
name: min_backoff [38978,38989]
name: min_backoff [38978,38989]
===
match
---
operator: , [37634,37635]
operator: , [37634,37635]
===
match
---
operator: , [54192,54193]
operator: , [54192,54193]
===
match
---
operator: = [50855,50856]
operator: = [50855,50856]
===
match
---
trailer [26244,26254]
trailer [26244,26254]
===
match
---
funcdef [70816,70873]
funcdef [70923,70980]
===
match
---
trailer [19060,19072]
trailer [19060,19072]
===
match
---
param [63364,63369]
param [63364,63369]
===
match
---
trailer [32475,32480]
trailer [32475,32480]
===
match
---
operator: , [58706,58707]
operator: , [58706,58707]
===
match
---
param [58860,58877]
param [58860,58877]
===
match
---
simple_stmt [70214,70265]
simple_stmt [70321,70372]
===
match
---
trailer [84074,84086]
trailer [84181,84193]
===
match
---
string: "--pool" [22801,22809]
string: "--pool" [22801,22809]
===
match
---
simple_stmt [59097,59158]
simple_stmt [59097,59158]
===
match
---
operator: = [12121,12122]
operator: = [12121,12122]
===
match
---
atom_expr [16027,16036]
atom_expr [16027,16036]
===
match
---
name: open [5055,5059]
name: open [5055,5059]
===
match
---
operator: , [86436,86437]
operator: , [86543,86544]
===
match
---
trailer [8406,8410]
trailer [8406,8410]
===
match
---
atom_expr [11849,11891]
atom_expr [11849,11891]
===
match
---
comp_op [59951,59957]
comp_op [59951,59957]
===
match
---
name: signal [52675,52681]
name: signal [52675,52681]
===
match
---
name: DagModel [3937,3945]
name: DagModel [3937,3945]
===
match
---
trailer [29205,29207]
trailer [29205,29207]
===
match
---
comparison [7664,7683]
comparison [7664,7683]
===
match
---
arglist [78534,78571]
arglist [78641,78678]
===
match
---
name: innerjoin [13883,13892]
name: innerjoin [13883,13892]
===
match
---
operator: = [12014,12015]
operator: = [12014,12015]
===
match
---
operator: = [32506,32507]
operator: = [32506,32507]
===
match
---
dotted_name [3957,3982]
dotted_name [3957,3982]
===
match
---
name: ignore_ti_state [41352,41367]
name: ignore_ti_state [41352,41367]
===
match
---
simple_stmt [8251,8279]
simple_stmt [8251,8279]
===
match
---
name: provide_session [57450,57465]
name: provide_session [57450,57465]
===
match
---
name: dag_run [67709,67716]
name: dag_run [67816,67823]
===
match
---
atom_expr [89119,89164]
atom_expr [89226,89271]
===
match
---
name: Index [13073,13078]
name: Index [13073,13078]
===
match
---
operator: == [7674,7676]
operator: == [7674,7676]
===
match
---
trailer [55589,55601]
trailer [55589,55601]
===
match
---
expr_stmt [82157,82497]
expr_stmt [82264,82604]
===
match
---
operator: @ [24894,24895]
operator: @ [24894,24895]
===
match
---
atom_expr [91081,91148]
atom_expr [91188,91255]
===
match
---
argument [66527,66538]
argument [66634,66645]
===
match
---
parameters [93225,93231]
parameters [93332,93338]
===
match
---
trailer [84960,84962]
trailer [85067,85069]
===
match
---
name: task [53936,53940]
name: task [53936,53940]
===
match
---
trailer [55882,55919]
trailer [55882,55919]
===
match
---
trailer [26585,26594]
trailer [26585,26594]
===
match
---
name: dag_id [7104,7110]
name: dag_id [7104,7110]
===
match
---
name: utils [3507,3512]
name: utils [3507,3512]
===
match
---
simple_stmt [15953,15974]
simple_stmt [15953,15974]
===
match
---
name: Exception [84694,84703]
name: Exception [84801,84810]
===
match
---
return_stmt [89274,89301]
return_stmt [89381,89408]
===
match
---
name: execution_date [31697,31711]
name: execution_date [31697,31711]
===
match
---
trailer [66069,66075]
trailer [66176,66182]
===
match
---
name: execute_callable [56008,56024]
name: execute_callable [56008,56024]
===
match
---
simple_stmt [57651,57694]
simple_stmt [57651,57694]
===
match
---
name: self [70863,70867]
name: self [70970,70974]
===
match
---
name: key [57387,57390]
name: key [57387,57390]
===
match
---
decorator [74325,74332]
decorator [74432,74439]
===
match
---
subscriptlist [66259,66273]
subscriptlist [66366,66380]
===
match
---
name: TaskDeferred [57508,57520]
name: TaskDeferred [57508,57520]
===
match
---
name: and_ [7642,7646]
name: and_ [7642,7646]
===
match
---
trailer [60499,60508]
trailer [60499,60508]
===
match
---
operator: , [61773,61774]
operator: , [61773,61774]
===
match
---
name: next_kwargs [55825,55836]
name: next_kwargs [55825,55836]
===
match
---
suite [64402,64581]
suite [64402,64688]
===
match
---
simple_stmt [3057,3104]
simple_stmt [3057,3104]
===
match
---
expr_stmt [88528,88765]
expr_stmt [88635,88872]
===
match
---
name: trigger [57671,57678]
name: trigger [57671,57678]
===
match
---
operator: @ [30555,30556]
operator: @ [30555,30556]
===
match
---
tfpdef [41227,41248]
tfpdef [41227,41248]
===
match
---
name: execution_date [64532,64546]
name: execution_date [64639,64653]
===
match
---
operator: , [86630,86631]
operator: , [86737,86738]
===
match
---
param [5356,5360]
param [5356,5360]
===
match
---
operator: = [54226,54227]
operator: = [54226,54227]
===
match
---
trailer [28493,28500]
trailer [28493,28500]
===
match
---
suite [86033,86241]
suite [86140,86348]
===
match
---
name: encode [39283,39289]
name: encode [39283,39289]
===
match
---
name: session [63187,63194]
name: session [63187,63194]
===
match
---
operator: = [40634,40635]
operator: = [40634,40635]
===
match
---
name: self [92518,92522]
name: self [92625,92629]
===
match
---
trailer [10122,10191]
trailer [10122,10191]
===
match
---
trailer [10364,10371]
trailer [10364,10371]
===
match
---
operator: = [45292,45293]
operator: = [45292,45293]
===
match
---
atom_expr [50877,50893]
atom_expr [50877,50893]
===
match
---
operator: = [11296,11297]
operator: = [11296,11297]
===
match
---
name: warnings [33171,33179]
name: warnings [33171,33179]
===
match
---
atom_expr [64199,64208]
atom_expr [64199,64208]
===
match
---
name: self [44700,44704]
name: self [44700,44704]
===
match
---
name: query [9100,9105]
name: query [9100,9105]
===
match
---
simple_stmt [27460,27484]
simple_stmt [27460,27484]
===
match
---
parameters [93621,93627]
parameters [93728,93734]
===
match
---
simple_stmt [41044,41085]
simple_stmt [41044,41085]
===
match
---
name: default_html_content [81828,81848]
name: default_html_content [81935,81955]
===
match
---
trailer [37746,37753]
trailer [37746,37753]
===
match
---
name: run_id [22173,22179]
name: run_id [22173,22179]
===
match
---
param [80045,80050]
param [80152,80157]
===
match
---
operator: = [78024,78025]
operator: = [78131,78132]
===
match
---
name: html_content_err [84280,84296]
name: html_content_err [84387,84403]
===
match
---
parameters [69769,69833]
parameters [69876,69940]
===
match
---
name: self [37491,37495]
name: self [37491,37495]
===
match
---
name: self [48913,48917]
name: self [48913,48917]
===
match
---
atom [22612,22640]
atom [22612,22640]
===
match
---
name: exc_info [63807,63815]
name: exc_info [63807,63815]
===
match
---
trailer [53107,53134]
trailer [53107,53134]
===
match
---
operator: == [43462,43464]
operator: == [43462,43464]
===
match
---
name: exception [60572,60581]
name: exception [60572,60581]
===
match
---
operator: = [82182,82183]
operator: = [82289,82290]
===
match
---
param [59196,59241]
param [59196,59241]
===
match
---
name: exception [83562,83571]
name: exception [83669,83678]
===
match
---
atom_expr [83665,83680]
atom_expr [83772,83787]
===
match
---
param [90074,90127]
param [90181,90234]
===
match
---
atom_expr [11946,11961]
atom_expr [11946,11961]
===
match
---
trailer [64292,64297]
trailer [64292,64297]
===
match
---
operator: , [66063,66064]
operator: , [66170,66171]
===
match
---
expr_stmt [36841,36854]
expr_stmt [36841,36854]
===
match
---
trailer [34992,34996]
trailer [34992,34996]
===
match
---
operator: = [18694,18695]
operator: = [18694,18695]
===
match
---
operator: , [13241,13242]
operator: , [13241,13242]
===
match
---
trailer [83720,83730]
trailer [83827,83837]
===
match
---
operator: = [19601,19602]
operator: = [19601,19602]
===
match
---
simple_stmt [64287,64343]
simple_stmt [64287,64343]
===
match
---
decorated [85080,86477]
decorated [85187,86584]
===
match
---
return_stmt [81233,81253]
return_stmt [81340,81360]
===
match
---
name: self [25967,25971]
name: self [25967,25971]
===
match
---
parameters [28331,28337]
parameters [28331,28337]
===
match
---
name: run_id [15967,15973]
name: run_id [15967,15973]
===
match
---
name: task_retries [6498,6510]
name: task_retries [6498,6510]
===
match
---
simple_stmt [71555,71607]
simple_stmt [71662,71714]
===
match
---
operator: = [50630,50631]
operator: = [50630,50631]
===
match
---
operator: @ [92968,92969]
operator: @ [93075,93076]
===
match
---
operator: } [49155,49156]
operator: } [49155,49156]
===
match
---
name: task [38246,38250]
name: task [38246,38250]
===
match
---
operator: = [53018,53019]
operator: = [53018,53019]
===
match
---
trailer [81597,81611]
trailer [81704,81718]
===
match
---
if_stmt [50560,50654]
if_stmt [50560,50654]
===
match
---
trailer [60581,60623]
trailer [60581,60623]
===
match
---
atom_expr [39096,39363]
atom_expr [39096,39363]
===
match
---
simple_stmt [23507,23764]
simple_stmt [23507,23764]
===
match
---
and_test [29475,29538]
and_test [29475,29538]
===
match
---
funcdef [30576,32399]
funcdef [30576,32399]
===
match
---
name: html_content [84528,84540]
name: html_content [84635,84647]
===
match
---
trailer [30190,30224]
trailer [30190,30224]
===
match
---
trailer [4614,4637]
trailer [4614,4637]
===
match
---
funcdef [40429,41104]
funcdef [40429,41104]
===
match
---
argument [43989,44020]
argument [43989,44020]
===
match
---
name: utils [3174,3179]
name: utils [3174,3179]
===
match
---
simple_stmt [74609,74659]
simple_stmt [74716,74766]
===
match
---
name: state [32460,32465]
name: state [32460,32465]
===
match
---
name: REQUEUEABLE_DEPS [2857,2873]
name: REQUEUEABLE_DEPS [2857,2873]
===
match
---
trailer [66526,66539]
trailer [66633,66646]
===
match
---
name: str [60961,60964]
name: str [60961,60964]
===
match
---
param [35313,35317]
param [35313,35317]
===
match
---
name: QUEUED [65545,65551]
name: QUEUED [65652,65658]
===
match
---
name: run_id [10155,10161]
name: run_id [10155,10161]
===
match
---
name: job_id [19648,19654]
name: job_id [19648,19654]
===
match
---
decorated [32404,32973]
decorated [32404,32973]
===
match
---
fstring_expr [49157,49176]
fstring_expr [49157,49176]
===
match
---
operator: = [37290,37291]
operator: = [37290,37291]
===
match
---
suite [8295,8469]
suite [8295,8469]
===
match
---
name: run_id [90575,90581]
name: run_id [90682,90688]
===
match
---
name: String [11803,11809]
name: String [11803,11809]
===
match
---
if_stmt [72350,72437]
if_stmt [72457,72544]
===
match
---
trailer [57944,57953]
trailer [57944,57953]
===
match
---
name: log_url [23050,23057]
name: log_url [23050,23057]
===
match
---
operator: , [33407,33408]
operator: , [33407,33408]
===
match
---
operator: = [68049,68050]
operator: = [68156,68157]
===
match
---
trailer [83162,83174]
trailer [83269,83281]
===
match
---
suite [23835,24510]
suite [23835,24510]
===
match
---
string: """         Checks dependencies and then sets state to RUNNING if they are met. Returns         True if and only if state is set to RUNNING, which implies that task should be         executed, in preparation for _run_raw_task          :param verbose: whether to turn on more verbose logging         :type verbose: bool         :param ignore_all_deps: Ignore all of the non-critical dependencies, just runs         :type ignore_all_deps: bool         :param ignore_depends_on_past: Ignore depends_on_past DAG attribute         :type ignore_depends_on_past: bool         :param ignore_task_deps: Don't check the dependencies of this TaskInstance's task         :type ignore_task_deps: bool         :param ignore_ti_state: Disregards previous task instance state         :type ignore_ti_state: bool         :param mark_success: Don't run the task, mark its state as success         :type mark_success: bool         :param test_mode: Doesn't record success or failure in the DB         :type test_mode: bool         :param job_id: Job (BackfillJob / LocalTaskJob / SchedulerJob) ID         :type job_id: str         :param pool: specifies the pool to use to run the task instance         :type pool: str         :param external_executor_id: The identifier of the celery executor         :type external_executor_id: str         :param session: SQLAlchemy ORM Session         :type session: Session         :return: whether the state was changed to running or not         :rtype: bool         """ [41623,43113]
string: """         Checks dependencies and then sets state to RUNNING if they are met. Returns         True if and only if state is set to RUNNING, which implies that task should be         executed, in preparation for _run_raw_task          :param verbose: whether to turn on more verbose logging         :type verbose: bool         :param ignore_all_deps: Ignore all of the non-critical dependencies, just runs         :type ignore_all_deps: bool         :param ignore_depends_on_past: Ignore depends_on_past DAG attribute         :type ignore_depends_on_past: bool         :param ignore_task_deps: Don't check the dependencies of this TaskInstance's task         :type ignore_task_deps: bool         :param ignore_ti_state: Disregards previous task instance state         :type ignore_ti_state: bool         :param mark_success: Don't run the task, mark its state as success         :type mark_success: bool         :param test_mode: Doesn't record success or failure in the DB         :type test_mode: bool         :param job_id: Job (BackfillJob / LocalTaskJob / SchedulerJob) ID         :type job_id: str         :param pool: specifies the pool to use to run the task instance         :type pool: str         :param external_executor_id: The identifier of the celery executor         :type external_executor_id: str         :param session: SQLAlchemy ORM Session         :type session: Session         :return: whether the state was changed to running or not         :rtype: bool         """ [41623,43113]
===
match
---
or_test [58067,58085]
or_test [58067,58085]
===
match
---
name: var [69856,69859]
name: var [69963,69966]
===
match
---
name: min_backoff [38540,38551]
name: min_backoff [38540,38551]
===
match
---
atom_expr [72519,72525]
atom_expr [72626,72632]
===
match
---
name: RESTARTING [8458,8468]
name: RESTARTING [8458,8468]
===
match
---
operator: } [82562,82563]
operator: } [82669,82670]
===
match
---
name: default_html_content [83265,83285]
name: default_html_content [83372,83392]
===
match
---
name: Union [1142,1147]
name: Union [1142,1147]
===
match
---
atom_expr [55127,55203]
atom_expr [55127,55203]
===
match
---
name: extend [22437,22443]
name: extend [22437,22443]
===
match
---
name: Environment [83013,83024]
name: Environment [83120,83131]
===
match
---
expr_stmt [69851,69880]
expr_stmt [69958,69987]
===
match
---
name: state [65423,65428]
name: state [65530,65535]
===
match
---
trailer [38250,38276]
trailer [38250,38276]
===
match
---
name: dep_context [44212,44223]
name: dep_context [44212,44223]
===
match
---
trailer [50776,50795]
trailer [50776,50795]
===
match
---
trailer [34996,35002]
trailer [34996,35002]
===
match
---
name: Index [12918,12923]
name: Index [12918,12923]
===
match
---
decorator [78064,78081]
decorator [78171,78188]
===
match
---
name: int [9753,9756]
name: int [9753,9756]
===
match
---
trailer [71148,71202]
trailer [71255,71309]
===
match
---
operator: = [44716,44717]
operator: = [44716,44717]
===
match
---
operator: } [49175,49176]
operator: } [49175,49176]
===
match
---
name: session [67151,67158]
name: session [67258,67265]
===
match
---
name: self [85060,85064]
name: self [85167,85171]
===
match
---
name: log [46899,46902]
name: log [46899,46902]
===
match
---
trailer [25498,25505]
trailer [25498,25505]
===
match
---
name: self [10439,10443]
name: self [10439,10443]
===
match
---
operator: , [13974,13975]
operator: , [13974,13975]
===
match
---
trailer [66023,66033]
trailer [66130,66140]
===
match
---
name: deprecated_proxy [72038,72054]
name: deprecated_proxy [72145,72161]
===
match
---
string: "data_interval_end | ds" [75791,75815]
string: "data_interval_end | ds" [75898,75922]
===
match
---
string: "DagRun" [13933,13941]
string: "DagRun" [13933,13941]
===
match
---
argument [83294,83309]
argument [83401,83416]
===
match
---
atom_expr [91613,91622]
atom_expr [91720,91729]
===
match
---
name: queued_dttm [26629,26640]
name: queued_dttm [26629,26640]
===
match
---
atom_expr [67161,67179]
atom_expr [67268,67286]
===
match
---
operator: = [35820,35821]
operator: = [35820,35821]
===
match
---
operator: , [1449,1450]
operator: , [1449,1450]
===
match
---
name: Column [11574,11580]
name: Column [11574,11580]
===
match
---
operator: , [18142,18143]
operator: , [18142,18143]
===
match
---
atom_expr [46040,46056]
atom_expr [46040,46056]
===
match
---
if_stmt [68778,68832]
if_stmt [68885,68939]
===
match
---
trailer [11223,11249]
trailer [11223,11249]
===
match
---
simple_stmt [26857,26889]
simple_stmt [26857,26889]
===
match
---
dotted_name [3448,3467]
dotted_name [3448,3467]
===
match
---
name: dag_run [79865,79872]
name: dag_run [79972,79979]
===
match
---
name: state [40324,40329]
name: state [40324,40329]
===
match
---
name: priority_weight_total [27609,27630]
name: priority_weight_total [27609,27630]
===
match
---
name: self [49973,49977]
name: self [49973,49977]
===
match
---
trailer [62566,62575]
trailer [62566,62575]
===
match
---
atom_expr [57926,57936]
atom_expr [57926,57936]
===
match
---
name: self [49386,49390]
name: self [49386,49390]
===
match
---
operator: = [46057,46058]
operator: = [46057,46058]
===
match
---
name: session [52218,52225]
name: session [52218,52225]
===
match
---
name: ti [7073,7075]
name: ti [7073,7075]
===
match
---
return_stmt [68844,68870]
return_stmt [68951,68977]
===
match
---
atom_expr [63427,63441]
atom_expr [63427,63441]
===
match
---
simple_stmt [66585,66630]
simple_stmt [66692,66737]
===
match
---
operator: , [3798,3799]
operator: , [3798,3799]
===
match
---
name: trigger [57783,57790]
name: trigger [57783,57790]
===
match
---
name: get_template_context [60368,60388]
name: get_template_context [60368,60388]
===
match
---
name: Index [12981,12986]
name: Index [12981,12986]
===
match
---
trailer [33184,33418]
trailer [33184,33418]
===
match
---
name: session [86458,86465]
name: session [86565,86572]
===
match
---
trailer [35232,35241]
trailer [35232,35241]
===
match
---
string: """Get Airflow Connection value""" [71755,71789]
string: """Get Airflow Connection value""" [71862,71896]
===
match
---
trailer [58670,58729]
trailer [58670,58729]
===
match
---
name: str [92664,92667]
name: str [92771,92774]
===
match
---
name: Log [2384,2387]
name: Log [2384,2387]
===
match
---
string: """Initialize the attributes that aren't stored in the DB""" [16464,16524]
string: """Initialize the attributes that aren't stored in the DB""" [16464,16524]
===
match
---
atom_expr [77979,78047]
atom_expr [78086,78154]
===
match
---
name: __getattr__ [71462,71473]
name: __getattr__ [71569,71580]
===
match
---
tfpdef [41498,41517]
tfpdef [41498,41517]
===
match
---
if_stmt [15760,15944]
if_stmt [15760,15944]
===
match
---
not_test [67126,67137]
not_test [67233,67244]
===
match
---
name: TaskInstance [25717,25729]
name: TaskInstance [25717,25729]
===
match
---
trailer [57807,57811]
trailer [57807,57811]
===
match
---
return_stmt [72887,72951]
return_stmt [72994,73058]
===
match
---
name: ImportError [3725,3736]
name: ImportError [3725,3736]
===
match
---
raise_stmt [15799,15943]
raise_stmt [15799,15943]
===
match
---
simple_stmt [60269,60286]
simple_stmt [60269,60286]
===
match
---
name: airflow [8859,8866]
name: airflow [8859,8866]
===
match
---
name: String [1423,1429]
name: String [1423,1429]
===
match
---
name: AirflowException [78732,78748]
name: AirflowException [78839,78855]
===
match
---
trailer [83986,83992]
trailer [84093,84099]
===
match
---
operator: = [75967,75968]
operator: = [76074,76075]
===
match
---
operator: , [14829,14830]
operator: , [14829,14830]
===
match
---
name: filter [30225,30231]
name: filter [30225,30231]
===
match
---
name: self [73761,73765]
name: self [73868,73872]
===
match
---
trailer [53940,53967]
trailer [53940,53967]
===
match
---
trailer [74128,74140]
trailer [74235,74247]
===
match
---
operator: = [26819,26820]
operator: = [26819,26820]
===
match
---
operator: { [51943,51944]
operator: { [51943,51944]
===
match
---
simple_stmt [52171,52206]
simple_stmt [52171,52206]
===
match
---
operator: = [40467,40468]
operator: = [40467,40468]
===
match
---
trailer [25411,25455]
trailer [25411,25455]
===
match
---
name: SUCCESS [76901,76908]
name: SUCCESS [77008,77015]
===
match
---
return_stmt [92943,92962]
return_stmt [93050,93069]
===
match
---
operator: } [55841,55842]
operator: } [55841,55842]
===
match
---
trailer [84934,84945]
trailer [85041,85052]
===
match
---
suite [66672,66823]
suite [66779,66930]
===
match
---
name: tis [91050,91053]
name: tis [91157,91160]
===
match
---
parameters [24934,24977]
parameters [24934,24977]
===
match
---
trailer [8222,8224]
trailer [8222,8224]
===
match
---
simple_stmt [31572,31616]
simple_stmt [31572,31616]
===
match
---
suite [29609,30550]
suite [29609,30550]
===
match
---
name: self [58764,58768]
name: self [58764,58768]
===
match
---
operator: , [2154,2155]
operator: , [2154,2155]
===
match
---
simple_stmt [24746,24802]
simple_stmt [24746,24802]
===
match
---
atom [38598,38619]
atom [38598,38619]
===
match
---
name: replacement [75956,75967]
name: replacement [76063,76074]
===
match
---
operator: , [1388,1389]
operator: , [1388,1389]
===
match
---
trailer [9300,9302]
trailer [9300,9302]
===
match
---
operator: = [9560,9561]
operator: = [9560,9561]
===
match
---
argument [61375,61400]
argument [61375,61400]
===
match
---
argument [83042,83099]
argument [83149,83206]
===
match
---
comparison [14413,14427]
comparison [14413,14427]
===
match
---
parameters [72054,72086]
parameters [72161,72193]
===
match
---
name: _execute_task [55213,55226]
name: _execute_task [55213,55226]
===
match
---
param [48009,48022]
param [48009,48022]
===
match
---
name: self [23124,23128]
name: self [23124,23128]
===
match
---
param [14158,14177]
param [14158,14177]
===
match
---
simple_stmt [64500,64581]
simple_stmt [64604,64688]
===
match
---
atom_expr [18696,18709]
atom_expr [18696,18709]
===
match
---
name: session [40450,40457]
name: session [40450,40457]
===
match
---
argument [31665,31679]
argument [31665,31679]
===
match
---
atom_expr [6231,6239]
atom_expr [6231,6239]
===
match
---
param [32460,32488]
param [32460,32488]
===
match
---
name: XCOM_RETURN_KEY [57391,57406]
name: XCOM_RETURN_KEY [57391,57406]
===
match
---
return_stmt [40116,40144]
return_stmt [40116,40144]
===
match
---
trailer [74521,74523]
trailer [74628,74630]
===
match
---
name: path [19140,19144]
name: path [19140,19144]
===
match
---
name: session [66482,66489]
name: session [66589,66596]
===
match
---
operator: = [16400,16401]
operator: = [16400,16401]
===
match
---
operator: -> [90129,90131]
operator: -> [90236,90238]
===
match
---
name: state [32827,32832]
name: state [32827,32832]
===
match
---
name: ignore_ti_state [45440,45455]
name: ignore_ti_state [45440,45455]
===
match
---
name: ti [26410,26412]
name: ti [26410,26412]
===
match
---
trailer [3828,3837]
trailer [3828,3837]
===
match
---
string: 'test_mode' [77343,77354]
string: 'test_mode' [77450,77461]
===
match
---
simple_stmt [43147,43196]
simple_stmt [43147,43196]
===
match
---
trailer [26402,26407]
trailer [26402,26407]
===
match
---
name: _run_finished_callback [62041,62063]
name: _run_finished_callback [62041,62063]
===
match
---
name: relationship [1591,1603]
name: relationship [1591,1603]
===
match
---
trailer [91018,91026]
trailer [91125,91133]
===
match
---
simple_stmt [5499,5873]
simple_stmt [5499,5873]
===
match
---
atom_expr [15011,15185]
atom_expr [15011,15185]
===
match
---
sync_comp_for [53421,53461]
sync_comp_for [53421,53461]
===
match
---
string: '' [75085,75087]
string: '' [75192,75194]
===
match
---
trailer [65436,65443]
trailer [65543,65550]
===
match
---
atom_expr [83789,83817]
atom_expr [83896,83924]
===
match
---
name: partial [56132,56139]
name: partial [56132,56139]
===
match
---
name: dagrun [40771,40777]
name: dagrun [40771,40777]
===
match
---
name: _CURRENT_CONTEXT [4208,4224]
name: _CURRENT_CONTEXT [4208,4224]
===
match
---
simple_stmt [3443,3494]
simple_stmt [3443,3494]
===
match
---
simple_stmt [51920,51997]
simple_stmt [51920,51997]
===
match
---
operator: = [58665,58666]
operator: = [58665,58666]
===
match
---
operator: = [80625,80626]
operator: = [80732,80733]
===
match
---
name: String [11581,11587]
name: String [11581,11587]
===
match
---
name: dag_id [51954,51960]
name: dag_id [51954,51960]
===
match
---
name: STATICA_HACK [93897,93909]
name: STATICA_HACK [94004,94016]
===
match
---
operator: = [13892,13893]
operator: = [13892,13893]
===
match
---
name: result [47248,47254]
name: result [47248,47254]
===
match
---
string: 'utf-8' [39290,39297]
string: 'utf-8' [39290,39297]
===
match
---
param [4007,4023]
param [4007,4023]
===
match
---
trailer [49390,49419]
trailer [49390,49419]
===
match
---
trailer [72461,72466]
trailer [72568,72573]
===
match
---
tfpdef [28565,28575]
tfpdef [28565,28575]
===
match
---
operator: , [77455,77456]
operator: , [77562,77563]
===
match
---
suite [93080,93109]
suite [93187,93216]
===
match
---
expr_stmt [12079,12100]
expr_stmt [12079,12100]
===
match
---
simple_stmt [63215,63232]
simple_stmt [63215,63232]
===
match
---
trailer [74464,74479]
trailer [74571,74586]
===
match
---
import_as_names [1067,1147]
import_as_names [1067,1147]
===
match
---
comp_op [32056,32062]
comp_op [32056,32062]
===
match
---
name: data_interval [69041,69054]
name: data_interval [69148,69161]
===
match
---
atom_expr [89814,89832]
atom_expr [89921,89939]
===
match
---
trailer [7103,7110]
trailer [7103,7110]
===
match
---
name: max_tries [83721,83730]
name: max_tries [83828,83837]
===
match
---
trailer [46449,46475]
trailer [46449,46475]
===
match
---
operator: , [13002,13003]
operator: , [13002,13003]
===
match
---
name: run_id [24337,24343]
name: run_id [24337,24343]
===
match
---
trailer [93855,93885]
trailer [93962,93992]
===
match
---
param [34698,34721]
param [34698,34721]
===
match
---
simple_stmt [16533,16593]
simple_stmt [16533,16593]
===
match
---
atom_expr [59575,59602]
atom_expr [59575,59602]
===
match
---
simple_stmt [58513,58561]
simple_stmt [58513,58561]
===
match
---
trailer [27038,27042]
trailer [27038,27042]
===
match
---
trailer [71876,71882]
trailer [71983,71989]
===
match
---
name: pool_override [43176,43189]
name: pool_override [43176,43189]
===
match
---
atom_expr [49139,49155]
atom_expr [49139,49155]
===
match
---
for_stmt [8355,8469]
for_stmt [8355,8469]
===
match
---
simple_stmt [22433,22475]
simple_stmt [22433,22475]
===
match
---
fstring_expr [23272,23286]
fstring_expr [23272,23286]
===
match
---
name: deprecated_proxy [75734,75750]
name: deprecated_proxy [75841,75857]
===
match
---
name: COLLATION_ARGS [2275,2289]
name: COLLATION_ARGS [2275,2289]
===
match
---
name: delay [38200,38205]
name: delay [38200,38205]
===
match
---
parameters [93308,93314]
parameters [93415,93421]
===
match
---
simple_stmt [68965,69026]
simple_stmt [69072,69133]
===
match
---
name: VariableAccessor [77783,77799]
name: VariableAccessor [77890,77906]
===
match
---
atom_expr [20084,20097]
atom_expr [20084,20097]
===
match
---
name: dag_run [75180,75187]
name: dag_run [75287,75294]
===
match
---
trailer [77904,77942]
trailer [78011,78049]
===
match
---
name: TaskInstance [91747,91759]
name: TaskInstance [91854,91866]
===
match
---
name: ignore_depends_on_past [19453,19475]
name: ignore_depends_on_past [19453,19475]
===
match
---
parameters [4587,4602]
parameters [4587,4602]
===
match
---
parameters [29271,29277]
parameters [29271,29277]
===
match
---
atom_expr [73949,73962]
atom_expr [74056,74069]
===
match
---
trailer [9154,9320]
trailer [9154,9320]
===
match
---
operator: , [50813,50814]
operator: , [50813,50814]
===
match
---
trailer [83191,83198]
trailer [83298,83305]
===
match
---
string: """     Clears a set of task instances, but makes sure the running ones     get killed.      :param tis: a list of task instances     :param session: current session     :param dag_run_state: state to set DagRun to. If set to False, dagrun state will not         be changed.     :param dag: DAG object     :param activate_dag_runs: Deprecated parameter, do not pass     """ [5499,5872]
string: """     Clears a set of task instances, but makes sure the running ones     get killed.      :param tis: a list of task instances     :param session: current session     :param dag_run_state: state to set DagRun to. If set to False, dagrun state will not         be changed.     :param dag: DAG object     :param activate_dag_runs: Deprecated parameter, do not pass     """ [5499,5872]
===
match
---
simple_stmt [3901,3954]
simple_stmt [3901,3954]
===
match
---
name: delay [40139,40144]
name: delay [40139,40144]
===
match
---
suite [51907,51997]
suite [51907,51997]
===
match
---
suite [89395,89448]
suite [89502,89555]
===
match
---
trailer [28283,28304]
trailer [28283,28304]
===
match
---
argument [75956,75999]
argument [76063,76106]
===
match
---
atom_expr [59901,59910]
atom_expr [59901,59910]
===
match
---
trailer [49284,49286]
trailer [49284,49286]
===
match
---
operator: = [83664,83665]
operator: = [83771,83772]
===
match
---
operator: @ [29241,29242]
operator: @ [29241,29242]
===
match
---
operator: = [15561,15562]
operator: = [15561,15562]
===
match
---
expr_stmt [92836,92863]
expr_stmt [92943,92970]
===
match
---
operator: = [76746,76747]
operator: = [76853,76854]
===
match
---
name: self [29100,29104]
name: self [29100,29104]
===
match
---
operator: = [76180,76181]
operator: = [76287,76288]
===
match
---
name: session [51856,51863]
name: session [51856,51863]
===
match
---
name: self [74638,74642]
name: self [74745,74749]
===
match
---
param [41266,41303]
param [41266,41303]
===
match
---
name: datetime [92349,92357]
name: datetime [92456,92464]
===
match
---
simple_stmt [48741,48768]
simple_stmt [48741,48768]
===
match
---
name: ti [92749,92751]
name: ti [92856,92858]
===
match
---
simple_stmt [6327,6348]
simple_stmt [6327,6348]
===
match
---
simple_stmt [51885,51891]
simple_stmt [51885,51891]
===
match
---
trailer [30117,30137]
trailer [30117,30137]
===
match
---
arglist [51790,51842]
arglist [51790,51842]
===
match
---
atom_expr [22218,22248]
atom_expr [22218,22248]
===
match
---
suite [90160,91856]
suite [90267,91963]
===
match
---
name: self [15953,15957]
name: self [15953,15957]
===
match
---
name: get_next_execution_date [73080,73103]
name: get_next_execution_date [73187,73210]
===
match
---
atom_expr [22433,22474]
atom_expr [22433,22474]
===
match
---
atom_expr [64427,64450]
atom_expr [64427,64450]
===
match
---
atom_expr [46940,46949]
atom_expr [46940,46949]
===
match
---
tfpdef [34114,34130]
tfpdef [34114,34130]
===
match
---
string: "--local" [22748,22757]
string: "--local" [22748,22757]
===
match
---
name: context [59565,59572]
name: context [59565,59572]
===
match
---
simple_stmt [39861,39940]
simple_stmt [39861,39940]
===
match
---
name: TaskInstance [24218,24230]
name: TaskInstance [24218,24230]
===
match
---
name: int [39096,39099]
name: int [39096,39099]
===
match
---
trailer [72697,72706]
trailer [72804,72813]
===
match
---
simple_stmt [60353,60391]
simple_stmt [60353,60391]
===
match
---
suite [80173,80224]
suite [80280,80331]
===
match
---
atom_expr [68120,68156]
atom_expr [68227,68263]
===
match
---
name: get_yesterday_ds [77905,77921]
name: get_yesterday_ds [78012,78028]
===
match
---
name: self [47641,47645]
name: self [47641,47645]
===
match
---
name: is_subdag [18883,18892]
name: is_subdag [18883,18892]
===
match
---
trailer [34484,34500]
trailer [34484,34500]
===
match
---
name: context [60500,60507]
name: context [60500,60507]
===
match
---
name: state [34077,34082]
name: state [34077,34082]
===
match
---
atom_expr [40070,40107]
atom_expr [40070,40107]
===
match
---
trailer [8215,8222]
trailer [8215,8222]
===
match
---
number: 1000 [12587,12591]
number: 1000 [12587,12591]
===
match
---
name: context [59714,59721]
name: context [59714,59721]
===
match
---
suite [46989,47074]
suite [46989,47074]
===
match
---
fstring_start: f" [53410,53412]
fstring_start: f" [53410,53412]
===
match
---
name: info [63249,63253]
name: info [63249,63253]
===
match
---
testlist_comp [78664,78702]
testlist_comp [78771,78809]
===
match
---
string: """         This attribute is deprecated.         Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.         """ [33543,33682]
string: """         This attribute is deprecated.         Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.         """ [33543,33682]
===
match
---
name: start_date [44705,44715]
name: start_date [44705,44715]
===
match
---
name: pod_id [80619,80625]
name: pod_id [80726,80732]
===
match
---
atom_expr [25733,25762]
atom_expr [25733,25762]
===
match
---
trailer [17927,17939]
trailer [17927,17939]
===
match
---
operator: -= [63173,63175]
operator: -= [63173,63175]
===
match
---
trailer [6044,6051]
trailer [6044,6051]
===
match
---
name: self [17863,17867]
name: self [17863,17867]
===
match
---
operator: } [77327,77328]
operator: } [77434,77435]
===
match
---
atom_expr [93571,93592]
atom_expr [93678,93699]
===
match
---
simple_stmt [28051,28088]
simple_stmt [28051,28088]
===
match
---
name: error_file [51611,51621]
name: error_file [51611,51621]
===
match
---
argument [76169,76200]
argument [76276,76307]
===
match
---
atom_expr [76606,76664]
atom_expr [76713,76771]
===
match
---
name: ti [24438,24440]
name: ti [24438,24440]
===
match
---
trailer [14564,14844]
trailer [14564,14844]
===
match
---
trailer [9351,9353]
trailer [9351,9353]
===
match
---
trailer [68600,68608]
trailer [68707,68715]
===
match
---
name: dag_id [24246,24252]
name: dag_id [24246,24252]
===
match
---
name: task_id [89241,89248]
name: task_id [89348,89355]
===
match
---
trailer [19220,19227]
trailer [19220,19227]
===
match
---
name: hr_line_break [46229,46242]
name: hr_line_break [46229,46242]
===
match
---
simple_stmt [45605,45629]
simple_stmt [45605,45629]
===
match
---
name: State [17091,17096]
name: State [17091,17096]
===
match
---
atom_expr [29216,29235]
atom_expr [29216,29235]
===
match
---
trailer [9347,9351]
trailer [9347,9351]
===
match
---
atom_expr [69862,69880]
atom_expr [69969,69987]
===
match
---
atom_expr [31670,31679]
atom_expr [31670,31679]
===
match
---
operator: , [61483,61484]
operator: , [61483,61484]
===
match
---
operator: = [44868,44869]
operator: = [44868,44869]
===
match
---
name: run_id [15606,15612]
name: run_id [15606,15612]
===
match
---
trailer [91602,91609]
trailer [91709,91716]
===
match
---
simple_stmt [3843,3877]
simple_stmt [3843,3877]
===
match
---
dotted_name [2699,2713]
dotted_name [2699,2713]
===
match
---
operator: = [66343,66344]
operator: = [66450,66451]
===
match
---
operator: = [51814,51815]
operator: = [51814,51815]
===
match
---
string: """             Wrapper around Variable. This way you can get variables in             templates by using ``{{ var.json.variable_name }}`` or             ``{{ var.json.get('variable_name', {'fall': 'back'}) }}``.             """ [70314,70542]
string: """             Wrapper around Variable. This way you can get variables in             templates by using ``{{ var.json.variable_name }}`` or             ``{{ var.json.get('variable_name', {'fall': 'back'}) }}``.             """ [70421,70649]
===
match
---
name: test_mode [77361,77370]
name: test_mode [77468,77477]
===
match
---
string: 'execution_date is {}; received {})' [86146,86182]
string: 'execution_date is {}; received {})' [86253,86289]
===
match
---
argument [19489,19520]
argument [19489,19520]
===
match
---
atom_expr [48838,48875]
atom_expr [48838,48875]
===
match
---
arglist [43260,43297]
arglist [43260,43297]
===
match
---
trailer [23184,23209]
trailer [23184,23209]
===
match
---
name: task_reschedule [44960,44975]
name: task_reschedule [44960,44975]
===
match
---
dotted_name [3166,3183]
dotted_name [3166,3183]
===
match
---
atom_expr [69334,69377]
atom_expr [69441,69484]
===
match
---
name: self [27034,27038]
name: self [27034,27038]
===
match
---
expr_stmt [6982,7003]
expr_stmt [6982,7003]
===
match
---
simple_stmt [30151,30163]
simple_stmt [30151,30163]
===
match
---
fstring_end: " [37968,37969]
fstring_end: " [37968,37969]
===
match
---
string: """         This attribute is deprecated.         Please use `airflow.models.taskinstance.TaskInstance.get_previous_start_date` method.         """ [35359,35506]
string: """         This attribute is deprecated.         Please use `airflow.models.taskinstance.TaskInstance.get_previous_start_date` method.         """ [35359,35506]
===
match
---
name: self [69787,69791]
name: self [69894,69898]
===
match
---
name: state [28931,28936]
name: state [28931,28936]
===
match
---
name: replace [68140,68147]
name: replace [68247,68254]
===
match
---
name: relationship [94010,94022]
name: relationship [94117,94129]
===
match
---
name: data_interval_start [75343,75362]
name: data_interval_start [75450,75469]
===
match
---
name: dag_id [88446,88452]
name: dag_id [88553,88559]
===
match
---
name: bool [20051,20055]
name: bool [20051,20055]
===
match
---
expr_stmt [26240,26269]
expr_stmt [26240,26269]
===
match
---
name: try_number [10223,10233]
name: try_number [10223,10233]
===
match
---
suite [37092,37118]
suite [37092,37118]
===
match
---
suite [50384,50693]
suite [50384,50693]
===
match
---
operator: , [91054,91055]
operator: , [91161,91162]
===
match
---
name: pool [61474,61478]
name: pool [61474,61478]
===
match
---
trailer [59443,59449]
trailer [59443,59449]
===
match
---
decorator [79107,79124]
decorator [79214,79231]
===
match
---
atom [55840,55842]
atom [55840,55842]
===
match
---
name: handle_failure_with_callback [66194,66222]
name: handle_failure_with_callback [66301,66329]
===
match
---
suite [46877,46972]
suite [46877,46972]
===
match
---
name: deprecated_proxy [76814,76830]
name: deprecated_proxy [76921,76937]
===
match
---
name: try_number [82872,82882]
name: try_number [82979,82989]
===
match
---
funcdef [74906,75089]
funcdef [75013,75196]
===
match
---
name: self [53019,53023]
name: self [53019,53023]
===
match
---
simple_stmt [52218,52238]
simple_stmt [52218,52238]
===
match
---
and_test [85977,86032]
and_test [86084,86139]
===
match
---
suite [40709,40742]
suite [40709,40742]
===
match
---
atom_expr [6912,6924]
atom_expr [6912,6924]
===
match
---
suite [27143,27804]
suite [27143,27804]
===
match
---
atom_expr [58323,58336]
atom_expr [58323,58336]
===
match
---
atom_expr [7839,7852]
atom_expr [7839,7852]
===
match
---
trailer [47010,47014]
trailer [47010,47014]
===
match
---
operator: == [89728,89730]
operator: == [89835,89837]
===
match
---
simple_stmt [84460,84511]
simple_stmt [84567,84618]
===
match
---
decorated [86482,89448]
decorated [86589,89555]
===
match
---
name: fd [5129,5131]
name: fd [5129,5131]
===
match
---
trailer [56289,56307]
trailer [56289,56307]
===
match
---
trailer [53508,53530]
trailer [53508,53530]
===
match
---
name: t [91045,91046]
name: t [91152,91153]
===
match
---
name: ti [92629,92631]
name: ti [92736,92738]
===
match
---
trailer [3794,3804]
trailer [3794,3804]
===
match
---
simple_stmt [2728,2760]
simple_stmt [2728,2760]
===
match
---
atom_expr [25617,25636]
atom_expr [25617,25636]
===
match
---
atom_expr [55820,55836]
atom_expr [55820,55836]
===
match
---
name: log [85023,85026]
name: log [85130,85133]
===
match
---
trailer [60165,60209]
trailer [60165,60209]
===
match
---
name: self [49027,49031]
name: self [49027,49031]
===
match
---
trailer [50134,50157]
trailer [50134,50157]
===
match
---
suite [79174,79721]
suite [79281,79828]
===
match
---
name: Optional [92709,92717]
name: Optional [92816,92824]
===
match
---
name: priority_weight [26518,26533]
name: priority_weight [26518,26533]
===
match
---
expr_stmt [63655,63681]
expr_stmt [63655,63681]
===
match
---
simple_stmt [89985,90000]
simple_stmt [90092,90107]
===
match
---
trailer [58328,58336]
trailer [58328,58336]
===
match
---
name: self [45901,45905]
name: self [45901,45905]
===
match
---
trailer [90813,90869]
trailer [90920,90976]
===
match
---
trailer [89080,89088]
trailer [89187,89195]
===
match
---
name: passed [37708,37714]
name: passed [37708,37714]
===
match
---
name: DateTime [69193,69201]
name: DateTime [69300,69308]
===
match
---
atom_expr [76856,76926]
atom_expr [76963,77033]
===
match
---
simple_stmt [57192,57235]
simple_stmt [57192,57235]
===
match
---
trailer [90815,90822]
trailer [90922,90929]
===
match
---
atom_expr [72917,72929]
atom_expr [73024,73036]
===
match
---
operator: -> [32519,32521]
operator: -> [32519,32521]
===
match
---
funcdef [89902,90032]
funcdef [90009,90139]
===
match
---
trailer [15401,15417]
trailer [15401,15417]
===
match
---
simple_stmt [59980,60018]
simple_stmt [59980,60018]
===
match
---
string: """         Return the try number that this task number will be when it is actually         run.          If the TaskInstance is currently running, this will match the column in the         database, in all other cases this will be incremented.         """ [16642,16898]
string: """         Return the try number that this task number will be when it is actually         run.          If the TaskInstance is currently running, this will match the column in the         database, in all other cases this will be incremented.         """ [16642,16898]
===
match
---
tfpdef [20182,20203]
tfpdef [20182,20203]
===
match
---
name: ignore_all_deps [19880,19895]
name: ignore_all_deps [19880,19895]
===
match
---
name: property [23033,23041]
name: property [23033,23041]
===
match
---
fstring_string:  instead. [72426,72435]
fstring_string:  instead. [72533,72542]
===
match
---
operator: , [89151,89152]
operator: , [89258,89259]
===
match
---
trailer [62700,62963]
trailer [62700,62963]
===
match
---
argument [32212,32227]
argument [32212,32227]
===
match
---
if_stmt [9482,9604]
if_stmt [9482,9604]
===
match
---
trailer [59600,59602]
trailer [59600,59602]
===
match
---
if_stmt [4691,4725]
if_stmt [4691,4725]
===
match
---
if_stmt [4341,4566]
if_stmt [4341,4566]
===
match
---
annassign [92707,92729]
annassign [92814,92836]
===
match
---
simple_stmt [59025,59059]
simple_stmt [59025,59059]
===
match
---
operator: = [11884,11885]
operator: = [11884,11885]
===
match
---
operator: , [14156,14157]
operator: , [14156,14157]
===
match
---
name: session [50174,50181]
name: session [50174,50181]
===
match
---
name: Index [1383,1388]
name: Index [1383,1388]
===
match
---
name: dag_id [10128,10134]
name: dag_id [10128,10134]
===
match
---
name: BooleanClauseList [1751,1768]
name: BooleanClauseList [1751,1768]
===
match
---
operator: != [4359,4361]
operator: != [4359,4361]
===
match
---
suite [91699,91856]
suite [91806,91963]
===
match
---
name: Stats [64351,64356]
name: Stats [64351,64356]
===
match
---
trailer [76860,76888]
trailer [76967,76995]
===
match
---
name: String [11742,11748]
name: String [11742,11748]
===
match
---
atom_expr [52498,52559]
atom_expr [52498,52559]
===
match
---
operator: -> [84800,84802]
operator: -> [84907,84909]
===
match
---
funcdef [68880,69129]
funcdef [68987,69236]
===
match
---
simple_stmt [27007,27025]
simple_stmt [27007,27025]
===
match
---
suite [79788,80019]
suite [79895,80126]
===
match
---
param [5365,5373]
param [5365,5373]
===
match
---
funcdef [19743,23027]
funcdef [19743,23027]
===
match
---
trailer [41063,41084]
trailer [41063,41084]
===
match
---
suite [34176,34600]
suite [34176,34600]
===
match
---
operator: = [14295,14296]
operator: = [14295,14296]
===
match
---
trailer [89650,89656]
trailer [89757,89763]
===
match
---
operator: , [13344,13345]
operator: , [13344,13345]
===
match
---
name: are_dependencies_met [45511,45531]
name: are_dependencies_met [45511,45531]
===
match
---
name: item [70676,70680]
name: item [70783,70787]
===
match
---
suite [22723,22760]
suite [22723,22760]
===
match
---
atom_expr [54998,55015]
atom_expr [54998,55015]
===
match
---
name: dag [6363,6366]
name: dag [6363,6366]
===
match
---
operator: , [2626,2627]
operator: , [2626,2627]
===
match
---
trailer [12586,12592]
trailer [12586,12592]
===
match
---
name: List [20297,20301]
name: List [20297,20301]
===
match
---
trailer [43243,43259]
trailer [43243,43259]
===
match
---
operator: , [82850,82851]
operator: , [82957,82958]
===
match
---
name: try_number [7126,7136]
name: try_number [7126,7136]
===
match
---
name: bool [47838,47842]
name: bool [47838,47842]
===
match
---
return_stmt [69303,69314]
return_stmt [69410,69421]
===
match
---
tfpdef [70937,70946]
tfpdef [71044,71053]
===
match
---
trailer [64173,64182]
trailer [64173,64182]
===
match
---
name: verbose [61158,61165]
name: verbose [61158,61165]
===
match
---
operator: = [31575,31576]
operator: = [31575,31576]
===
match
---
argument [13766,13817]
argument [13766,13817]
===
match
---
import_from [1769,1815]
import_from [1769,1815]
===
match
---
name: timedelta [39905,39914]
name: timedelta [39905,39914]
===
match
---
name: strftime [68066,68074]
name: strftime [68173,68181]
===
match
---
trailer [31036,31047]
trailer [31036,31047]
===
match
---
name: get_template_context [66904,66924]
name: get_template_context [67011,67031]
===
match
---
name: state [93378,93383]
name: state [93485,93490]
===
match
---
atom_expr [92239,92251]
atom_expr [92346,92358]
===
match
---
trailer [38573,38587]
trailer [38573,38587]
===
match
---
arglist [7756,7995]
arglist [7756,7995]
===
match
---
atom_expr [12573,12593]
atom_expr [12573,12593]
===
match
---
arglist [15645,15694]
arglist [15645,15694]
===
match
---
name: run_id [62778,62784]
name: run_id [62778,62784]
===
match
---
trailer [6002,6008]
trailer [6002,6008]
===
match
---
trailer [25644,25651]
trailer [25644,25651]
===
match
---
name: catch_warnings [74507,74521]
name: catch_warnings [74614,74628]
===
match
---
name: TaskInstanceKey [9612,9627]
name: TaskInstanceKey [9612,9627]
===
match
---
with_stmt [52818,54688]
with_stmt [52818,54688]
===
match
---
trailer [88483,88494]
trailer [88590,88601]
===
match
---
parameters [58853,58883]
parameters [58853,58883]
===
match
---
trailer [52807,52809]
trailer [52807,52809]
===
match
---
decorated [72596,72719]
decorated [72703,72826]
===
match
---
operator: == [91610,91612]
operator: == [91717,91719]
===
match
---
atom_expr [56280,56307]
atom_expr [56280,56307]
===
match
---
name: execution_date [28186,28200]
name: execution_date [28186,28200]
===
match
---
simple_stmt [58764,58823]
simple_stmt [58764,58823]
===
match
---
name: warnings [35515,35523]
name: warnings [35515,35523]
===
match
---
name: self [10217,10221]
name: self [10217,10221]
===
match
---
atom_expr [19147,19156]
atom_expr [19147,19156]
===
match
---
name: sentry [2707,2713]
name: sentry [2707,2713]
===
match
---
suite [49000,49062]
suite [49000,49062]
===
match
---
simple_stmt [5877,5890]
simple_stmt [5877,5890]
===
match
---
name: session [50856,50863]
name: session [50856,50863]
===
match
---
name: dag_run [40734,40741]
name: dag_run [40734,40741]
===
match
---
arglist [51597,51649]
arglist [51597,51649]
===
match
---
simple_stmt [11789,11832]
simple_stmt [11789,11832]
===
match
---
simple_stmt [6455,6482]
simple_stmt [6455,6482]
===
match
---
trailer [14266,14273]
trailer [14266,14273]
===
match
---
parameters [72755,72757]
parameters [72862,72864]
===
match
---
operator: = [61299,61300]
operator: = [61299,61300]
===
match
---
parameters [85114,85257]
parameters [85221,85364]
===
match
---
name: dag_id [77292,77298]
name: dag_id [77399,77405]
===
match
---
name: dag_id [7677,7683]
name: dag_id [7677,7683]
===
match
---
simple_stmt [43613,43661]
simple_stmt [43613,43661]
===
match
---
name: merge [49021,49026]
name: merge [49021,49026]
===
match
---
string: """         Returns whether a task is in UP_FOR_RETRY state and its retry interval         has elapsed.         """ [29287,29402]
string: """         Returns whether a task is in UP_FOR_RETRY state and its retry interval         has elapsed.         """ [29287,29402]
===
match
---
name: _get_previous_dagrun_data_interval_success [68371,68413]
name: _get_previous_dagrun_data_interval_success [68478,68520]
===
match
---
name: task_copy [55242,55251]
name: task_copy [55242,55251]
===
match
---
expr_stmt [56668,56729]
expr_stmt [56668,56729]
===
match
---
operator: , [84540,84541]
operator: , [84647,84648]
===
match
---
name: following_schedule [73742,73760]
name: following_schedule [73849,73867]
===
match
---
arglist [13531,13703]
arglist [13531,13703]
===
match
---
simple_stmt [89014,89179]
simple_stmt [89121,89286]
===
match
---
arglist [89139,89163]
arglist [89246,89270]
===
match
---
name: run_id [40897,40903]
name: run_id [40897,40903]
===
match
---
name: self [84989,84993]
name: self [85096,85100]
===
match
---
trailer [4973,4989]
trailer [4973,4989]
===
match
---
name: DagRun [3947,3953]
name: DagRun [3947,3953]
===
match
---
atom_expr [59926,59950]
atom_expr [59926,59950]
===
match
---
atom_expr [84868,84883]
atom_expr [84975,84990]
===
match
---
dictorsetmaker [75119,78048]
dictorsetmaker [75226,78155]
===
match
---
comparison [69041,69062]
comparison [69148,69169]
===
match
---
name: VariableJsonAccessor [70280,70300]
name: VariableJsonAccessor [70387,70407]
===
match
---
operator: = [51229,51230]
operator: = [51229,51230]
===
match
---
name: self [30380,30384]
name: self [30380,30384]
===
match
---
trailer [89667,89669]
trailer [89774,89776]
===
match
---
trailer [91436,91685]
trailer [91543,91792]
===
match
---
string: 'ti_state_lkp' [12924,12938]
string: 'ti_state_lkp' [12924,12938]
===
match
---
fstring_expr [15858,15873]
fstring_expr [15858,15873]
===
match
---
name: context [4232,4239]
name: context [4232,4239]
===
match
---
operator: , [12938,12939]
operator: , [12938,12939]
===
match
---
operator: { [51962,51963]
operator: { [51962,51963]
===
match
---
operator: = [37276,37277]
operator: = [37276,37277]
===
match
---
arglist [89708,89850]
arglist [89815,89957]
===
match
---
arglist [13151,13274]
arglist [13151,13274]
===
match
---
annassign [9751,9760]
annassign [9751,9760]
===
match
---
name: TaskInstance [91534,91546]
name: TaskInstance [91641,91653]
===
match
---
atom_expr [26410,26417]
atom_expr [26410,26417]
===
match
---
name: params [79771,79777]
name: params [79878,79884]
===
match
---
operator: = [32299,32300]
operator: = [32299,32300]
===
match
---
expr_stmt [39952,40003]
expr_stmt [39952,40003]
===
match
---
expr_stmt [3760,3779]
expr_stmt [3760,3779]
===
match
---
decorator [85080,85097]
decorator [85187,85204]
===
match
---
return_stmt [72778,72820]
return_stmt [72885,72927]
===
match
---
trailer [24282,24290]
trailer [24282,24290]
===
match
---
operator: = [86298,86299]
operator: = [86405,86406]
===
match
---
operator: , [19909,19910]
operator: , [19909,19910]
===
match
---
arglist [76718,76768]
arglist [76825,76875]
===
match
---
param [17227,17232]
param [17227,17232]
===
match
---
trailer [91086,91093]
trailer [91193,91200]
===
match
---
funcdef [29255,29539]
funcdef [29255,29539]
===
match
---
operator: , [46938,46939]
operator: , [46938,46939]
===
match
---
trailer [46810,46812]
trailer [46810,46812]
===
match
---
operator: , [34512,34513]
operator: , [34512,34513]
===
match
---
name: task_copy [62182,62191]
name: task_copy [62182,62191]
===
match
---
fstring_conversion [72423,72425]
fstring_conversion [72530,72532]
===
match
---
name: session [46129,46136]
name: session [46129,46136]
===
match
---
name: run_id [14158,14164]
name: run_id [14158,14164]
===
match
---
name: signal_handler [52455,52469]
name: signal_handler [52455,52469]
===
match
---
name: dep_context [37358,37369]
name: dep_context [37358,37369]
===
match
---
atom_expr [37424,37438]
atom_expr [37424,37438]
===
match
---
name: retry_exponential_backoff [38251,38276]
name: retry_exponential_backoff [38251,38276]
===
match
---
atom_expr [31473,31496]
atom_expr [31473,31496]
===
match
---
parameters [66924,66993]
parameters [67031,67100]
===
match
---
trailer [51479,51485]
trailer [51479,51485]
===
match
---
operator: = [76947,76948]
operator: = [77054,77055]
===
match
---
operator: = [28819,28820]
operator: = [28819,28820]
===
match
---
trailer [43497,43502]
trailer [43497,43502]
===
match
---
comparison [57340,57358]
comparison [57340,57358]
===
match
---
atom_expr [67484,67509]
atom_expr [67591,67616]
===
match
---
trailer [64704,64716]
trailer [64811,64823]
===
match
---
name: session [50210,50217]
name: session [50210,50217]
===
match
---
simple_stmt [35515,35771]
simple_stmt [35515,35771]
===
match
---
decorated [28310,28519]
decorated [28310,28519]
===
match
---
expr_stmt [12289,12320]
expr_stmt [12289,12320]
===
match
---
operator: , [3362,3363]
operator: , [3362,3363]
===
match
---
name: handle_failure [51582,51596]
name: handle_failure [51582,51596]
===
match
---
tfpdef [4961,4989]
tfpdef [4961,4989]
===
match
---
operator: = [9076,9077]
operator: = [9076,9077]
===
match
---
name: refresh_from_db [62551,62566]
name: refresh_from_db [62551,62566]
===
match
---
suite [44921,44987]
suite [44921,44987]
===
match
---
expr_stmt [90436,90451]
expr_stmt [90543,90558]
===
match
---
if_stmt [64123,64183]
if_stmt [64123,64183]
===
match
---
string: 'subject_template' [84150,84168]
string: 'subject_template' [84257,84275]
===
match
---
string: "{}#{}#{}#{}" [39151,39164]
string: "{}#{}#{}#{}" [39151,39164]
===
match
---
operator: , [85058,85059]
operator: , [85165,85166]
===
match
---
operator: = [60858,60859]
operator: = [60858,60859]
===
match
---
name: session [44869,44876]
name: session [44869,44876]
===
match
---
name: start_date [44976,44986]
name: start_date [44976,44986]
===
match
---
name: xcom [89328,89332]
name: xcom [89435,89439]
===
match
---
string: 'Submitting %s to sensor service' [54896,54929]
string: 'Submitting %s to sensor service' [54896,54929]
===
match
---
expr_stmt [6231,6258]
expr_stmt [6231,6258]
===
match
---
name: State [3488,3493]
name: State [3488,3493]
===
match
---
atom_expr [73738,73781]
atom_expr [73845,73888]
===
match
---
trailer [16320,16324]
trailer [16320,16324]
===
match
---
name: self [54931,54935]
name: self [54931,54935]
===
match
---
name: utils [3070,3075]
name: utils [3070,3075]
===
match
---
name: dr [9532,9534]
name: dr [9532,9534]
===
match
---
operator: , [44134,44135]
operator: , [44134,44135]
===
match
---
trailer [64426,64451]
trailer [64426,64451]
===
match
---
trailer [62198,62220]
trailer [62198,62220]
===
match
---
name: ts_nodash_with_tz [77670,77687]
name: ts_nodash_with_tz [77777,77794]
===
match
---
trailer [52791,52807]
trailer [52791,52807]
===
match
---
argument [61791,61800]
argument [61791,61800]
===
match
---
atom_expr [26240,26254]
atom_expr [26240,26254]
===
match
---
string: """Is task instance is eligible for retry""" [66585,66629]
string: """Is task instance is eligible for retry""" [66692,66736]
===
match
---
import_from [1549,1603]
import_from [1549,1603]
===
match
---
param [29595,29607]
param [29595,29607]
===
match
---
simple_stmt [54037,54255]
simple_stmt [54037,54255]
===
match
---
name: _run_execute_callback [53678,53699]
name: _run_execute_callback [53678,53699]
===
match
---
trailer [15390,15401]
trailer [15390,15401]
===
match
---
name: unixname [16016,16024]
name: unixname [16016,16024]
===
match
---
name: job_id [61447,61453]
name: job_id [61447,61453]
===
match
---
operator: = [60819,60820]
operator: = [60819,60820]
===
match
---
funcdef [93294,93355]
funcdef [93401,93462]
===
match
---
trailer [12986,13027]
trailer [12986,13027]
===
match
---
suite [74370,74659]
suite [74477,74766]
===
match
---
trailer [23153,23155]
trailer [23153,23155]
===
match
---
operator: , [24953,24954]
operator: , [24953,24954]
===
match
---
trailer [83024,83130]
trailer [83131,83237]
===
match
---
name: downstream_task_ids [30529,30548]
name: downstream_task_ids [30529,30548]
===
match
---
atom_expr [32942,32954]
atom_expr [32942,32954]
===
match
---
fstring_string: Unable to render a k8s spec for this taskinstance:  [79624,79675]
fstring_string: Unable to render a k8s spec for this taskinstance:  [79731,79782]
===
match
---
and_test [40319,40402]
and_test [40319,40402]
===
match
---
name: get [71145,71148]
name: get [71252,71255]
===
match
---
name: Union [86559,86564]
name: Union [86666,86671]
===
match
---
suite [70835,70873]
suite [70942,70980]
===
match
---
name: task [59491,59495]
name: task [59491,59495]
===
match
---
name: self [80810,80814]
name: self [80917,80921]
===
match
---
arglist [45532,45586]
arglist [45532,45586]
===
match
---
param [34063,34068]
param [34063,34068]
===
match
---
classdef [70274,71203]
classdef [70381,71310]
===
match
---
expr_stmt [7016,7046]
expr_stmt [7016,7046]
===
match
---
name: Session [34123,34130]
name: Session [34123,34130]
===
match
---
name: are_dependents_done [29569,29588]
name: are_dependents_done [29569,29588]
===
match
---
name: dag_id [80645,80651]
name: dag_id [80752,80758]
===
match
---
trailer [14046,14075]
trailer [14046,14075]
===
match
---
simple_stmt [81315,81367]
simple_stmt [81422,81474]
===
match
---
name: dr [9376,9378]
name: dr [9376,9378]
===
match
---
atom_expr [51963,51980]
atom_expr [51963,51980]
===
match
---
trailer [64507,64511]
trailer [64611,64615]
===
match
---
name: e [50321,50322]
name: e [50321,50322]
===
match
---
name: self [24858,24862]
name: self [24858,24862]
===
match
---
simple_stmt [93935,93976]
simple_stmt [94042,94083]
===
match
---
name: dag_run [73471,73478]
name: dag_run [73578,73585]
===
match
---
name: test_mode [63624,63633]
name: test_mode [63624,63633]
===
match
---
name: value [86293,86298]
name: value [86400,86405]
===
match
---
simple_stmt [16385,16408]
simple_stmt [16385,16408]
===
match
---
string: """URL to mark TI success""" [23364,23392]
string: """URL to mark TI success""" [23364,23392]
===
match
---
name: QUEUED [9508,9514]
name: QUEUED [9508,9514]
===
match
---
name: error [66246,66251]
name: error [66353,66358]
===
match
---
name: contextlib [67435,67445]
name: contextlib [67542,67552]
===
match
---
name: session [85942,85949]
name: session [86049,86056]
===
match
---
atom_expr [55585,55601]
atom_expr [55585,55601]
===
match
---
name: task [49163,49167]
name: task [49163,49167]
===
match
---
name: task [15304,15308]
name: task [15304,15308]
===
match
---
operator: , [34667,34668]
operator: , [34667,34668]
===
match
---
trailer [74712,74717]
trailer [74819,74824]
===
match
---
name: task [27473,27477]
name: task [27473,27477]
===
match
---
simple_stmt [44942,44987]
simple_stmt [44942,44987]
===
match
---
suite [4999,5324]
suite [4999,5324]
===
match
---
trailer [49977,49992]
trailer [49977,49992]
===
match
---
decorator [68166,68210]
decorator [68273,68317]
===
match
---
atom_expr [75520,75539]
atom_expr [75627,75646]
===
match
---
operator: , [84168,84169]
operator: , [84275,84276]
===
match
---
trailer [52178,52182]
trailer [52178,52182]
===
match
---
name: rendered_value [78557,78571]
name: rendered_value [78664,78678]
===
match
---
atom_expr [30444,30457]
atom_expr [30444,30457]
===
match
---
arglist [45238,45472]
arglist [45238,45472]
===
match
---
operator: = [82933,82934]
operator: = [83040,83041]
===
match
---
name: executor_config [27726,27741]
name: executor_config [27726,27741]
===
match
---
name: reschedule_exception [50815,50835]
name: reschedule_exception [50815,50835]
===
match
---
name: dag_id [7667,7673]
name: dag_id [7667,7673]
===
match
---
operator: = [27698,27699]
operator: = [27698,27699]
===
match
---
string: 'ds_nodash' [75399,75410]
string: 'ds_nodash' [75506,75517]
===
match
---
name: session [36811,36818]
name: session [36811,36818]
===
match
---
trailer [92613,92626]
trailer [92720,92733]
===
match
---
param [17992,18011]
param [17992,18011]
===
match
---
arglist [83042,83116]
arglist [83149,83223]
===
match
---
atom_expr [25567,25587]
atom_expr [25567,25587]
===
match
---
name: result [54532,54538]
name: result [54532,54538]
===
match
---
argument [43260,43275]
argument [43260,43275]
===
match
---
name: pool_slots [26451,26461]
name: pool_slots [26451,26461]
===
match
---
dotted_name [2437,2460]
dotted_name [2437,2460]
===
match
---
name: context_to_airflow_vars [53243,53266]
name: context_to_airflow_vars [53243,53266]
===
match
---
trailer [85022,85026]
trailer [85129,85133]
===
match
---
operator: , [78555,78556]
operator: , [78662,78663]
===
match
---
trailer [91032,91040]
trailer [91139,91147]
===
match
---
simple_stmt [63156,63178]
simple_stmt [63156,63178]
===
match
---
atom_expr [26338,26349]
atom_expr [26338,26349]
===
match
---
operator: = [9408,9409]
operator: = [9408,9409]
===
match
---
comparison [8477,8506]
comparison [8477,8506]
===
match
---
operator: , [28473,28474]
operator: , [28473,28474]
===
match
---
trailer [46648,46654]
trailer [46648,46654]
===
match
---
suite [60336,60624]
suite [60336,60624]
===
match
---
expr_stmt [3806,3842]
expr_stmt [3806,3842]
===
match
---
simple_stmt [71129,71203]
simple_stmt [71236,71310]
===
match
---
operator: = [77555,77556]
operator: = [77662,77663]
===
match
---
name: String [12580,12586]
name: String [12580,12586]
===
match
---
name: context [59980,59987]
name: context [59980,59987]
===
match
---
trailer [28277,28283]
trailer [28277,28283]
===
match
---
trailer [53699,53719]
trailer [53699,53719]
===
match
---
name: rendered_task_instance_fields [78394,78423]
name: rendered_task_instance_fields [78501,78530]
===
match
---
trailer [49992,50010]
trailer [49992,50010]
===
match
---
simple_stmt [2534,2579]
simple_stmt [2534,2579]
===
match
---
trailer [68681,68690]
trailer [68788,68797]
===
match
---
operator: , [44083,44084]
operator: , [44083,44084]
===
match
---
name: self [49139,49143]
name: self [49139,49143]
===
match
---
name: self [26739,26743]
name: self [26739,26743]
===
match
---
simple_stmt [48046,48733]
simple_stmt [48046,48733]
===
match
---
name: State [46497,46502]
name: State [46497,46502]
===
match
---
trailer [34575,34599]
trailer [34575,34599]
===
match
---
atom_expr [37003,37022]
atom_expr [37003,37022]
===
match
---
trailer [15015,15019]
trailer [15015,15019]
===
match
---
dotted_name [2393,2413]
dotted_name [2393,2413]
===
match
---
operator: } [37965,37966]
operator: } [37965,37966]
===
match
---
simple_stmt [69451,69676]
simple_stmt [69558,69783]
===
match
---
name: self [93260,93264]
name: self [93367,93371]
===
match
---
operator: == [65536,65538]
operator: == [65643,65645]
===
match
---
name: _end_date [93265,93274]
name: _end_date [93372,93381]
===
match
---
fstring [64298,64335]
fstring [64298,64335]
===
match
---
argument [49740,49751]
argument [49740,49751]
===
match
---
suite [54016,54255]
suite [54016,54255]
===
match
---
suite [79878,80019]
suite [79985,80126]
===
match
---
operator: @ [9766,9767]
operator: @ [9766,9767]
===
match
---
suite [67641,67726]
suite [67748,67833]
===
match
---
operator: -> [28338,28340]
operator: -> [28338,28340]
===
match
---
testlist_comp [91812,91840]
testlist_comp [91919,91947]
===
match
---
import_from [2353,2387]
import_from [2353,2387]
===
match
---
name: get_k8s_pod_yaml [79363,79379]
name: get_k8s_pod_yaml [79470,79486]
===
match
---
atom_expr [51667,51683]
atom_expr [51667,51683]
===
match
---
atom_expr [11984,11996]
atom_expr [11984,11996]
===
match
---
operator: = [20027,20028]
operator: = [20027,20028]
===
match
---
suite [65928,65969]
suite [66035,66076]
===
match
---
operator: = [86586,86587]
operator: = [86693,86694]
===
match
---
name: ti [91613,91615]
name: ti [91720,91722]
===
match
---
name: Exception [60116,60125]
name: Exception [60116,60125]
===
match
---
name: values_ordered_by_id [89281,89301]
name: values_ordered_by_id [89388,89408]
===
match
---
name: self [92836,92840]
name: self [92943,92947]
===
match
---
tfpdef [5420,5469]
tfpdef [5420,5469]
===
match
---
name: init_on_load [16436,16448]
name: init_on_load [16436,16448]
===
match
---
arglist [56140,56176]
arglist [56140,56176]
===
match
---
atom_expr [91454,91641]
atom_expr [91561,91748]
===
match
---
argument [19299,19324]
argument [19299,19324]
===
match
---
name: timetables [2901,2911]
name: timetables [2901,2911]
===
match
---
name: pickle [864,870]
name: pickle [864,870]
===
match
---
if_stmt [3879,3954]
if_stmt [3879,3954]
===
match
---
name: Index [12884,12889]
name: Index [12884,12889]
===
match
---
trailer [6475,6481]
trailer [6475,6481]
===
match
---
atom_expr [79991,80018]
atom_expr [80098,80125]
===
match
---
atom_expr [9151,9320]
atom_expr [9151,9320]
===
match
---
name: ti [5978,5980]
name: ti [5978,5980]
===
match
---
simple_stmt [4293,4333]
simple_stmt [4293,4333]
===
match
---
atom_expr [68721,68765]
atom_expr [68828,68872]
===
match
---
trailer [79972,79977]
trailer [80079,80084]
===
match
---
operator: , [13473,13474]
operator: , [13473,13474]
===
match
---
number: 1 [93874,93875]
number: 1 [93981,93982]
===
match
---
trailer [46143,46145]
trailer [46143,46145]
===
match
---
atom_expr [79865,79877]
atom_expr [79972,79984]
===
match
---
name: __init__ [14085,14093]
name: __init__ [14085,14093]
===
match
---
name: session [76918,76925]
name: session [77025,77032]
===
match
---
trailer [36785,36827]
trailer [36785,36827]
===
match
---
operator: -> [10240,10242]
operator: -> [10240,10242]
===
match
---
simple_stmt [51536,51543]
simple_stmt [51536,51543]
===
match
---
operator: == [9195,9197]
operator: == [9195,9197]
===
match
---
name: execute_callable [55537,55553]
name: execute_callable [55537,55553]
===
match
---
argument [13665,13679]
argument [13665,13679]
===
match
---
number: 1 [9759,9760]
number: 1 [9759,9760]
===
match
---
name: render [83192,83198]
name: render [83299,83305]
===
match
---
argument [80553,80571]
argument [80660,80678]
===
match
---
operator: -> [35319,35321]
operator: -> [35319,35321]
===
match
---
operator: = [57937,57938]
operator: = [57937,57938]
===
match
---
simple_stmt [67546,67573]
simple_stmt [67653,67680]
===
match
---
name: trigger [13715,13722]
name: trigger [13715,13722]
===
match
---
name: self [92380,92384]
name: self [92487,92491]
===
match
---
simple_stmt [27683,27713]
simple_stmt [27683,27713]
===
match
---
power [38593,38619]
power [38593,38619]
===
match
---
name: contextlib [3957,3967]
name: contextlib [3957,3967]
===
match
---
simple_stmt [73866,73919]
simple_stmt [73973,74026]
===
match
---
string: 'ts_nodash' [77613,77624]
string: 'ts_nodash' [77720,77731]
===
match
---
operator: = [11975,11976]
operator: = [11975,11976]
===
match
---
atom_expr [6290,6299]
atom_expr [6290,6299]
===
match
---
param [60750,60787]
param [60750,60787]
===
match
---
expr_stmt [17243,17267]
expr_stmt [17243,17267]
===
match
---
trailer [26628,26640]
trailer [26628,26640]
===
match
---
suite [19032,19157]
suite [19032,19157]
===
match
---
name: start_date [29180,29190]
name: start_date [29180,29190]
===
match
---
atom_expr [23465,23498]
atom_expr [23465,23498]
===
match
---
trailer [80639,80666]
trailer [80746,80773]
===
match
---
name: int [10235,10238]
name: int [10235,10238]
===
match
---
simple_stmt [62157,62174]
simple_stmt [62157,62174]
===
match
---
simple_stmt [5110,5133]
simple_stmt [5110,5133]
===
match
---
name: current_time [29117,29129]
name: current_time [29117,29129]
===
match
---
atom_expr [11393,11425]
atom_expr [11393,11425]
===
match
---
simple_stmt [24872,24889]
simple_stmt [24872,24889]
===
match
---
name: Variable [70729,70737]
name: Variable [70836,70844]
===
match
---
simple_stmt [26362,26386]
simple_stmt [26362,26386]
===
match
---
simple_stmt [32793,32851]
simple_stmt [32793,32851]
===
match
---
name: session [61860,61867]
name: session [61860,61867]
===
match
---
name: DepContext [43858,43868]
name: DepContext [43858,43868]
===
match
---
name: ti_deps [2773,2780]
name: ti_deps [2773,2780]
===
match
---
atom_expr [54633,54687]
atom_expr [54633,54687]
===
match
---
except_clause [65981,65997]
except_clause [66088,66104]
===
match
---
suite [78138,79102]
suite [78245,79209]
===
match
---
simple_stmt [90590,90620]
simple_stmt [90697,90727]
===
match
---
expr_stmt [92199,92230]
expr_stmt [92306,92337]
===
match
---
name: provide_session [54800,54815]
name: provide_session [54800,54815]
===
match
---
operator: , [75155,75156]
operator: , [75262,75263]
===
match
---
name: session [28577,28584]
name: session [28577,28584]
===
match
---
name: exceptions [1941,1951]
name: exceptions [1941,1951]
===
match
---
name: loader [83042,83048]
name: loader [83149,83155]
===
match
---
name: default_subject [84170,84185]
name: default_subject [84277,84292]
===
match
---
name: context [49303,49310]
name: context [49303,49310]
===
match
---
suite [79453,79517]
suite [79560,79624]
===
match
---
name: utils [3327,3332]
name: utils [3327,3332]
===
match
---
argument [68341,68356]
argument [68448,68463]
===
match
---
arglist [72812,72819]
arglist [72919,72926]
===
match
---
atom_expr [49116,49178]
atom_expr [49116,49178]
===
match
---
except_clause [50701,50758]
except_clause [50701,50758]
===
match
---
operator: , [88754,88755]
operator: , [88861,88862]
===
match
---
name: self [15652,15656]
name: self [15652,15656]
===
match
---
name: self [40644,40648]
name: self [40644,40648]
===
match
---
name: get_previous_execution_date [34026,34053]
name: get_previous_execution_date [34026,34053]
===
match
---
arglist [73666,73694]
arglist [73773,73801]
===
match
---
param [29272,29276]
param [29272,29276]
===
match
---
name: Stats [54697,54702]
name: Stats [54697,54702]
===
match
---
operator: , [64335,64336]
operator: , [64335,64336]
===
match
---
simple_stmt [74205,74224]
simple_stmt [74312,74331]
===
match
---
simple_stmt [66811,66823]
simple_stmt [66918,66930]
===
match
---
if_stmt [66086,66164]
if_stmt [66193,66271]
===
match
---
trailer [92717,92722]
trailer [92824,92829]
===
match
---
name: downstream_task_ids [30323,30342]
name: downstream_task_ids [30323,30342]
===
match
---
name: context [58860,58867]
name: context [58860,58867]
===
match
---
param [10439,10443]
param [10439,10443]
===
match
---
trailer [77799,77801]
trailer [77906,77908]
===
match
---
import_from [3380,3442]
import_from [3380,3442]
===
match
---
trailer [22981,23007]
trailer [22981,23007]
===
match
---
name: self [45506,45510]
name: self [45506,45510]
===
match
---
atom [58083,58085]
atom [58083,58085]
===
match
---
simple_stmt [45196,45487]
simple_stmt [45196,45487]
===
match
---
name: dag_id [92184,92190]
name: dag_id [92291,92297]
===
match
---
atom_expr [46215,46243]
atom_expr [46215,46243]
===
match
---
name: Connection [71562,71572]
name: Connection [71669,71679]
===
match
---
atom_expr [38554,38622]
atom_expr [38554,38622]
===
match
---
name: test_mode [51171,51180]
name: test_mode [51171,51180]
===
match
---
name: default_conn [71698,71710]
name: default_conn [71805,71817]
===
match
---
operator: , [84526,84527]
operator: , [84633,84634]
===
match
---
name: params [79991,79997]
name: params [80098,80104]
===
match
---
atom_expr [53709,53718]
atom_expr [53709,53718]
===
match
---
operator: = [92262,92263]
operator: = [92369,92370]
===
match
---
suite [93397,93425]
suite [93504,93532]
===
match
---
name: session [25471,25478]
name: session [25471,25478]
===
match
---
operator: = [19101,19102]
operator: = [19101,19102]
===
match
---
trailer [11304,11372]
trailer [11304,11372]
===
match
---
trailer [64241,64248]
trailer [64241,64248]
===
match
---
suite [10466,10570]
suite [10466,10570]
===
match
---
name: signum [52470,52476]
name: signum [52470,52476]
===
match
---
expr_stmt [83323,83413]
expr_stmt [83430,83520]
===
match
---
funcdef [92910,92963]
funcdef [93017,93070]
===
match
---
operator: = [3838,3839]
operator: = [3838,3839]
===
match
---
trailer [24230,24237]
trailer [24230,24237]
===
match
---
trailer [72523,72525]
trailer [72630,72632]
===
match
---
trailer [46044,46056]
trailer [46044,46056]
===
match
---
name: task_id [11200,11207]
name: task_id [11200,11207]
===
match
---
name: self [15983,15987]
name: self [15983,15987]
===
match
---
name: str [14166,14169]
name: str [14166,14169]
===
match
---
comparison [24324,24358]
comparison [24324,24358]
===
match
---
name: session [43268,43275]
name: session [43268,43275]
===
match
---
simple_stmt [56492,56634]
simple_stmt [56492,56634]
===
match
---
arglist [64096,64113]
arglist [64096,64113]
===
match
---
operator: { [15884,15885]
operator: { [15884,15885]
===
match
---
name: Session [1707,1714]
name: Session [1707,1714]
===
match
---
fstring_string:  Please use  [72399,72411]
fstring_string:  Please use  [72506,72518]
===
match
---
arglist [12198,12222]
arglist [12198,12222]
===
match
---
fstring_string: &dag_id= [23286,23294]
fstring_string: &dag_id= [23286,23294]
===
match
---
trailer [46256,46260]
trailer [46256,46260]
===
match
---
import_name [1206,1230]
import_name [1206,1230]
===
match
---
name: data_interval [68781,68794]
name: data_interval [68888,68901]
===
match
---
string: 'task_instance_key_str' [77259,77282]
string: 'task_instance_key_str' [77366,77389]
===
match
---
simple_stmt [32165,32229]
simple_stmt [32165,32229]
===
match
---
name: lazy_object_proxy [1213,1230]
name: lazy_object_proxy [1213,1230]
===
match
---
name: task [59025,59029]
name: task [59025,59029]
===
match
---
simple_stmt [67357,67421]
simple_stmt [67464,67528]
===
match
---
name: Union [59212,59217]
name: Union [59212,59217]
===
match
---
name: models [2592,2598]
name: models [2592,2598]
===
match
---
name: finished [29026,29034]
name: finished [29026,29034]
===
match
---
atom_expr [45645,45676]
atom_expr [45645,45676]
===
match
---
trailer [47692,47707]
trailer [47692,47707]
===
match
---
name: State [61950,61955]
name: State [61950,61955]
===
match
---
name: self [62363,62367]
name: self [62363,62367]
===
match
---
string: "Webserver does not have access to User-defined Macros or Filters " [78770,78837]
string: "Webserver does not have access to User-defined Macros or Filters " [78877,78944]
===
match
---
trailer [54053,54254]
trailer [54053,54254]
===
match
---
name: session [64174,64181]
name: session [64174,64181]
===
match
---
name: dag [30966,30969]
name: dag [30966,30969]
===
match
---
import_from [3602,3655]
import_from [3602,3655]
===
match
---
name: prev_ti [35045,35052]
name: prev_ti [35045,35052]
===
match
---
simple_stmt [48884,48905]
simple_stmt [48884,48905]
===
match
---
trailer [49167,49175]
trailer [49167,49175]
===
match
---
name: getboolean [67589,67599]
name: getboolean [67696,67706]
===
match
---
operator: = [61453,61454]
operator: = [61453,61454]
===
match
---
operator: @ [16413,16414]
operator: @ [16413,16414]
===
match
---
operator: = [34098,34099]
operator: = [34098,34099]
===
match
---
name: strftime [74120,74128]
name: strftime [74227,74235]
===
match
---
atom_expr [44700,44715]
atom_expr [44700,44715]
===
match
---
trailer [80221,80223]
trailer [80328,80330]
===
match
---
atom_expr [73644,73695]
atom_expr [73751,73802]
===
match
---
name: get_previous_ti [33439,33454]
name: get_previous_ti [33439,33454]
===
match
---
if_stmt [8742,8802]
if_stmt [8742,8802]
===
match
---
name: external_executor_id [26798,26818]
name: external_executor_id [26798,26818]
===
match
---
trailer [25985,25994]
trailer [25985,25994]
===
match
---
operator: } [51993,51994]
operator: } [51993,51994]
===
match
---
atom_expr [80513,81116]
atom_expr [80620,81223]
===
match
---
name: Integer [11953,11960]
name: Integer [11953,11960]
===
match
---
fstring_expr [15884,15900]
fstring_expr [15884,15900]
===
match
---
tfpdef [19880,19901]
tfpdef [19880,19901]
===
match
---
operator: = [5395,5396]
operator: = [5395,5396]
===
match
---
param [33500,33504]
param [33500,33504]
===
match
---
atom_expr [40890,40903]
atom_expr [40890,40903]
===
match
---
name: Optional [74704,74712]
name: Optional [74811,74819]
===
match
---
name: logging [3849,3856]
name: logging [3849,3856]
===
match
---
atom_expr [7142,7152]
atom_expr [7142,7152]
===
match
---
trailer [24828,24835]
trailer [24828,24835]
===
match
---
name: staticmethod [90038,90050]
name: staticmethod [90145,90157]
===
match
---
operator: , [22162,22163]
operator: , [22162,22163]
===
match
---
name: timeout [58247,58254]
name: timeout [58247,58254]
===
match
---
trailer [53772,53774]
trailer [53772,53774]
===
match
---
string: "next_ds" [75768,75777]
string: "next_ds" [75875,75884]
===
match
---
name: session [41586,41593]
name: session [41586,41593]
===
match
---
trailer [90517,90520]
trailer [90624,90627]
===
match
---
trailer [34500,34530]
trailer [34500,34530]
===
match
---
decorator [90037,90051]
decorator [90144,90158]
===
match
---
return_stmt [69104,69128]
return_stmt [69211,69235]
===
match
---
name: Log [50135,50138]
name: Log [50135,50138]
===
match
---
name: COLLATION_ARGS [11410,11424]
name: COLLATION_ARGS [11410,11424]
===
match
---
trailer [5311,5318]
trailer [5311,5318]
===
match
---
operator: = [18740,18741]
operator: = [18740,18741]
===
match
---
if_stmt [92738,92828]
if_stmt [92845,92935]
===
match
---
name: add [9042,9045]
name: add [9042,9045]
===
match
---
name: deprecated_proxy [76701,76717]
name: deprecated_proxy [76808,76824]
===
match
---
if_stmt [56841,56913]
if_stmt [56841,56913]
===
match
---
atom_expr [52251,52267]
atom_expr [52251,52267]
===
match
---
simple_stmt [81510,81550]
simple_stmt [81617,81657]
===
match
---
name: get_rendered_template_fields [78089,78117]
name: get_rendered_template_fields [78196,78224]
===
match
---
param [60681,60702]
param [60681,60702]
===
match
---
trailer [90924,90931]
trailer [91031,91038]
===
match
---
suite [53897,53983]
suite [53897,53983]
===
match
---
param [69702,69706]
param [69809,69813]
===
match
---
operator: ** [56158,56160]
operator: ** [56158,56160]
===
match
---
simple_stmt [78620,78644]
simple_stmt [78727,78751]
===
match
---
operator: = [14365,14366]
operator: = [14365,14366]
===
match
---
operator: , [34137,34138]
operator: , [34137,34138]
===
match
---
arglist [78360,78381]
arglist [78467,78488]
===
match
---
name: is_localized [14965,14977]
name: is_localized [14965,14977]
===
match
---
trailer [33438,33454]
trailer [33438,33454]
===
match
---
name: clear [28101,28106]
name: clear [28101,28106]
===
match
---
return_stmt [73842,73853]
return_stmt [73949,73960]
===
match
---
name: TaskInstance [89708,89720]
name: TaskInstance [89815,89827]
===
match
---
trailer [82938,82948]
trailer [83045,83055]
===
match
---
atom_expr [12191,12223]
atom_expr [12191,12223]
===
match
---
operator: , [18637,18638]
operator: , [18637,18638]
===
match
---
simple_stmt [11163,11195]
simple_stmt [11163,11195]
===
match
---
trailer [91546,91554]
trailer [91653,91661]
===
match
---
atom_expr [11298,11372]
atom_expr [11298,11372]
===
match
---
suite [55789,55920]
suite [55789,55920]
===
match
---
fstring_string: = [53415,53416]
fstring_string: = [53415,53416]
===
match
---
name: key [93686,93689]
name: key [93793,93796]
===
match
---
name: cfg_path [22997,23005]
name: cfg_path [22997,23005]
===
match
---
simple_stmt [61086,61524]
simple_stmt [61086,61524]
===
match
---
operator: = [14170,14171]
operator: = [14170,14171]
===
match
---
param [93780,93784]
param [93887,93891]
===
match
---
or_test [36604,36631]
or_test [36604,36631]
===
match
---
name: query [40839,40844]
name: query [40839,40844]
===
match
---
arglist [43886,44135]
arglist [43886,44135]
===
match
---
name: str [34093,34096]
name: str [34093,34096]
===
match
---
operator: @ [86482,86483]
operator: @ [86589,86590]
===
match
---
atom_expr [15983,15998]
atom_expr [15983,15998]
===
match
---
atom_expr [22283,22323]
atom_expr [22283,22323]
===
match
---
simple_stmt [23401,23446]
simple_stmt [23401,23446]
===
match
---
operator: , [13817,13818]
operator: , [13817,13818]
===
match
---
simple_stmt [49070,49108]
simple_stmt [49070,49108]
===
match
---
name: verbose_aware_logger [37127,37147]
name: verbose_aware_logger [37127,37147]
===
match
---
operator: { [55840,55841]
operator: { [55840,55841]
===
match
---
test [61928,61994]
test [61928,61994]
===
match
---
argument [19559,19578]
argument [19559,19578]
===
match
---
atom_expr [91719,91855]
atom_expr [91826,91962]
===
match
---
trailer [52231,52237]
trailer [52231,52237]
===
match
---
trailer [59490,59495]
trailer [59490,59495]
===
match
---
name: SUCCESS [33987,33994]
name: SUCCESS [33987,33994]
===
match
---
trailer [76463,76469]
trailer [76570,76576]
===
match
---
operator: @ [37210,37211]
operator: @ [37210,37211]
===
match
---
return_stmt [93170,93193]
return_stmt [93277,93300]
===
match
---
trailer [18632,18646]
trailer [18632,18646]
===
match
---
name: int [38554,38557]
name: int [38554,38557]
===
match
---
name: task [40024,40028]
name: task [40024,40028]
===
match
---
operator: , [66372,66373]
operator: , [66479,66480]
===
match
---
name: deprecated_proxy [77979,77995]
name: deprecated_proxy [78086,78102]
===
match
---
name: merge [24852,24857]
name: merge [24852,24857]
===
match
---
atom_expr [65945,65968]
atom_expr [66052,66075]
===
match
---
trailer [18705,18709]
trailer [18705,18709]
===
match
---
name: get_prev_execution_date [74344,74367]
name: get_prev_execution_date [74451,74474]
===
match
---
simple_stmt [11688,11720]
simple_stmt [11688,11720]
===
match
---
name: test_mode [61414,61423]
name: test_mode [61414,61423]
===
match
---
operator: = [61795,61796]
operator: = [61795,61796]
===
match
---
atom_expr [50666,50676]
atom_expr [50666,50676]
===
match
---
name: jinja_context [82716,82729]
name: jinja_context [82823,82836]
===
match
---
fstring_expr [64318,64334]
fstring_expr [64318,64334]
===
match
---
trailer [39201,39208]
trailer [39201,39208]
===
match
---
operator: , [19545,19546]
operator: , [19545,19546]
===
match
---
name: dr [32179,32181]
name: dr [32179,32181]
===
match
---
expr_stmt [26567,26594]
expr_stmt [26567,26594]
===
match
---
name: commit [50885,50891]
name: commit [50885,50891]
===
match
---
name: get_yesterday_ds [72785,72801]
name: get_yesterday_ds [72892,72908]
===
match
---
operator: = [26675,26676]
operator: = [26675,26676]
===
match
---
name: ti [92360,92362]
name: ti [92467,92469]
===
match
---
name: dag [18690,18693]
name: dag [18690,18693]
===
match
---
simple_stmt [66148,66164]
simple_stmt [66255,66271]
===
match
---
operator: = [24948,24949]
operator: = [24948,24949]
===
match
---
expr_stmt [24134,24402]
expr_stmt [24134,24402]
===
match
---
name: self [29516,29520]
name: self [29516,29520]
===
match
---
name: sqlalchemy [3399,3409]
name: sqlalchemy [3399,3409]
===
match
---
trailer [47218,47227]
trailer [47218,47227]
===
match
---
trailer [11917,11922]
trailer [11917,11922]
===
match
---
argument [68320,68339]
argument [68427,68446]
===
match
---
operator: , [13284,13285]
operator: , [13284,13285]
===
match
---
name: AirflowNotFoundException [71906,71930]
name: AirflowNotFoundException [72013,72037]
===
match
---
name: force_fail [66451,66461]
name: force_fail [66558,66568]
===
match
---
comparison [66861,66894]
comparison [66968,67001]
===
match
---
operator: = [92218,92219]
operator: = [92325,92326]
===
match
---
name: with_entities [89341,89354]
name: with_entities [89448,89461]
===
match
---
operator: = [60274,60275]
operator: = [60274,60275]
===
match
---
name: str [28572,28575]
name: str [28572,28575]
===
match
---
name: self [38241,38245]
name: self [38241,38245]
===
match
---
name: bind [91384,91388]
name: bind [91491,91495]
===
match
---
atom_expr [26857,26872]
atom_expr [26857,26872]
===
match
---
name: Stats [51920,51925]
name: Stats [51920,51925]
===
match
---
operator: , [22171,22172]
operator: , [22171,22172]
===
match
---
name: _priority_weight [92790,92806]
name: _priority_weight [92897,92913]
===
match
---
operator: -> [93149,93151]
operator: -> [93256,93258]
===
match
---
name: self [93338,93342]
name: self [93445,93449]
===
match
---
name: pool [27497,27501]
name: pool [27497,27501]
===
match
---
name: e [50545,50546]
name: e [50545,50546]
===
match
---
operator: , [66350,66351]
operator: , [66457,66458]
===
match
---
name: session [28234,28241]
name: session [28234,28241]
===
match
---
name: error_file [51210,51220]
name: error_file [51210,51220]
===
match
---
trailer [29104,29113]
trailer [29104,29113]
===
match
---
name: refresh_from_task [14323,14340]
name: refresh_from_task [14323,14340]
===
match
---
operator: = [39886,39887]
operator: = [39886,39887]
===
match
---
trailer [89124,89138]
trailer [89231,89245]
===
match
---
name: refresh_from_db [24919,24934]
name: refresh_from_db [24919,24934]
===
match
---
trailer [65813,65868]
trailer [65920,65975]
===
match
---
operator: = [18035,18036]
operator: = [18035,18036]
===
match
---
expr_stmt [92518,92557]
expr_stmt [92625,92664]
===
match
---
string: 'html_content_template' [84221,84244]
string: 'html_content_template' [84328,84351]
===
match
---
string: "%s dependency '%s' PASSED: %s, %s" [37573,37608]
string: "%s dependency '%s' PASSED: %s, %s" [37573,37608]
===
match
---
name: run_id [7759,7765]
name: run_id [7759,7765]
===
match
---
if_stmt [57310,57422]
if_stmt [57310,57422]
===
match
---
name: key [88610,88613]
name: key [88717,88720]
===
match
---
param [52312,52319]
param [52312,52319]
===
match
---
name: typing [1053,1059]
name: typing [1053,1059]
===
match
---
simple_stmt [88462,88519]
simple_stmt [88569,88626]
===
match
---
param [93453,93457]
param [93560,93564]
===
match
---
trailer [8071,8077]
trailer [8071,8077]
===
match
---
for_stmt [9372,9604]
for_stmt [9372,9604]
===
match
---
name: Log [52183,52186]
name: Log [52183,52186]
===
match
---
simple_stmt [37836,37853]
simple_stmt [37836,37853]
===
match
---
trailer [6383,6392]
trailer [6383,6392]
===
match
---
expr_stmt [39011,39026]
expr_stmt [39011,39026]
===
match
---
name: self [84728,84732]
name: self [84835,84839]
===
match
---
atom_expr [79490,79516]
atom_expr [79597,79623]
===
match
---
name: dag_id [90925,90931]
name: dag_id [91032,91038]
===
match
---
argument [57387,57406]
argument [57387,57406]
===
match
---
trailer [59458,59465]
trailer [59458,59465]
===
match
---
name: cache [74326,74331]
name: cache [74433,74438]
===
match
---
argument [66451,66472]
argument [66558,66579]
===
match
---
atom_expr [61829,61842]
atom_expr [61829,61842]
===
match
---
name: State [6012,6017]
name: State [6012,6017]
===
match
---
trailer [24851,24857]
trailer [24851,24857]
===
match
---
arglist [51168,51237]
arglist [51168,51237]
===
match
---
atom_expr [68419,68443]
atom_expr [68526,68550]
===
match
---
trailer [37959,37965]
trailer [37959,37965]
===
match
---
operator: = [20165,20166]
operator: = [20165,20166]
===
match
---
trailer [36720,36724]
trailer [36720,36724]
===
match
---
atom_expr [27473,27483]
atom_expr [27473,27483]
===
match
---
expr_stmt [63156,63177]
expr_stmt [63156,63177]
===
match
---
atom_expr [81075,81104]
atom_expr [81182,81211]
===
match
---
operator: = [80939,80940]
operator: = [81046,81047]
===
match
---
operator: , [78019,78020]
operator: , [78126,78127]
===
match
---
if_stmt [54272,54437]
if_stmt [54272,54437]
===
match
---
name: key [77552,77555]
name: key [77659,77662]
===
match
---
string: "Dependencies not met for %s, dependency '%s' FAILED: %s" [36906,36963]
string: "Dependencies not met for %s, dependency '%s' FAILED: %s" [36906,36963]
===
match
---
decorated [9945,10192]
decorated [9945,10192]
===
match
---
name: try_number [93298,93308]
name: try_number [93405,93415]
===
match
---
dotted_name [1153,1165]
dotted_name [1153,1165]
===
match
---
name: Optional [59203,59211]
name: Optional [59203,59211]
===
match
---
parameters [92127,92151]
parameters [92234,92258]
===
match
---
operator: = [9597,9598]
operator: = [9597,9598]
===
match
---
simple_stmt [18910,18949]
simple_stmt [18910,18949]
===
match
---
trailer [26713,26717]
trailer [26713,26717]
===
match
---
suite [86757,89448]
suite [86864,89555]
===
match
---
operator: = [11648,11649]
operator: = [11648,11649]
===
match
---
trailer [23277,23285]
trailer [23277,23285]
===
match
---
atom_expr [4208,4240]
atom_expr [4208,4240]
===
match
---
name: hostname [11688,11696]
name: hostname [11688,11696]
===
match
---
name: bool [60774,60778]
name: bool [60774,60778]
===
match
---
arglist [83892,83904]
arglist [83999,84011]
===
match
---
trailer [5116,5121]
trailer [5116,5121]
===
match
---
name: key [77457,77460]
name: key [77564,77567]
===
match
---
name: reduced [9963,9970]
name: reduced [9963,9970]
===
match
---
expr_stmt [93846,93893]
expr_stmt [93953,94000]
===
match
---
trailer [11617,11651]
trailer [11617,11651]
===
match
---
atom_expr [84639,84654]
atom_expr [84746,84761]
===
match
---
name: DeprecationWarning [74573,74591]
name: DeprecationWarning [74680,74698]
===
match
---
atom_expr [92360,92371]
atom_expr [92467,92478]
===
match
---
atom_expr [9046,9061]
atom_expr [9046,9061]
===
match
---
name: try_number [80696,80706]
name: try_number [80803,80813]
===
match
---
name: Column [12059,12065]
name: Column [12059,12065]
===
match
---
string: 'conf' [75119,75125]
string: 'conf' [75226,75232]
===
match
---
name: r [72424,72425]
name: r [72531,72532]
===
match
---
except_clause [51714,51756]
except_clause [51714,51756]
===
match
---
funcdef [84418,84772]
funcdef [84525,84879]
===
match
---
name: State [76895,76900]
name: State [77002,77007]
===
match
---
operator: -> [59243,59245]
operator: -> [59243,59245]
===
match
---
atom_expr [4310,4332]
atom_expr [4310,4332]
===
match
---
trailer [46228,46243]
trailer [46228,46243]
===
match
---
atom_expr [73017,73051]
atom_expr [73124,73158]
===
match
---
trailer [92576,92595]
trailer [92683,92702]
===
match
---
tfpdef [47289,47302]
tfpdef [47289,47302]
===
match
---
trailer [60242,60255]
trailer [60242,60255]
===
match
---
simple_stmt [82994,83131]
simple_stmt [83101,83238]
===
match
---
trailer [92789,92806]
trailer [92896,92913]
===
match
---
name: task_ids [88655,88663]
name: task_ids [88762,88770]
===
match
---
name: execution_timeout [58543,58560]
name: execution_timeout [58543,58560]
===
match
---
simple_stmt [52087,52105]
simple_stmt [52087,52105]
===
match
---
trailer [66645,66651]
trailer [66752,66758]
===
match
---
name: write [52983,52988]
name: write [52983,52988]
===
match
---
arglist [63727,63743]
arglist [63727,63743]
===
match
---
simple_stmt [27639,27675]
simple_stmt [27639,27675]
===
match
---
name: self [74460,74464]
name: self [74567,74571]
===
match
---
trailer [48803,48808]
trailer [48803,48808]
===
match
---
trailer [40360,40380]
trailer [40360,40380]
===
match
---
expr_stmt [72386,72436]
expr_stmt [72493,72543]
===
match
---
simple_stmt [69216,69256]
simple_stmt [69323,69363]
===
match
---
name: task_type [27794,27803]
name: task_type [27794,27803]
===
match
---
trailer [68864,68870]
trailer [68971,68977]
===
match
---
comparison [7839,7866]
comparison [7839,7866]
===
match
---
atom [79536,79576]
atom [79643,79683]
===
match
---
param [5406,5415]
param [5406,5415]
===
match
---
arith_expr [17923,17943]
arith_expr [17923,17943]
===
match
---
name: rendered_task_instance_fields [78471,78500]
name: rendered_task_instance_fields [78578,78607]
===
match
---
if_stmt [48983,49062]
if_stmt [48983,49062]
===
match
---
expr_stmt [67188,67204]
expr_stmt [67295,67311]
===
match
---
name: test_mode [43209,43218]
name: test_mode [43209,43218]
===
match
---
name: content [84087,84094]
name: content [84194,84201]
===
match
---
operator: = [28929,28930]
operator: = [28929,28930]
===
match
---
atom_expr [46787,46812]
atom_expr [46787,46812]
===
match
---
fstring_end: ' [64334,64335]
fstring_end: ' [64334,64335]
===
match
---
trailer [54949,54955]
trailer [54949,54955]
===
match
---
simple_stmt [18690,18710]
simple_stmt [18690,18710]
===
match
---
atom_expr [93651,93662]
atom_expr [93758,93769]
===
match
---
atom_expr [52861,52878]
atom_expr [52861,52878]
===
match
---
trailer [15523,15525]
trailer [15523,15525]
===
match
---
suite [37815,37853]
suite [37815,37853]
===
match
---
funcdef [69138,69378]
funcdef [69245,69485]
===
match
---
name: executor_namespace [80991,81009]
name: executor_namespace [81098,81116]
===
match
---
dotted_name [2358,2376]
dotted_name [2358,2376]
===
match
---
operator: = [13697,13698]
operator: = [13697,13698]
===
match
---
name: exception [82790,82799]
name: exception [82897,82906]
===
match
---
simple_stmt [46438,46476]
simple_stmt [46438,46476]
===
match
---
name: test_mode [16390,16399]
name: test_mode [16390,16399]
===
match
---
name: refresh_from_task [6458,6475]
name: refresh_from_task [6458,6475]
===
match
---
name: run_id [9933,9939]
name: run_id [9933,9939]
===
match
---
name: end [69125,69128]
name: end [69232,69235]
===
match
---
atom_expr [4740,4751]
atom_expr [4740,4751]
===
match
---
suite [4790,4811]
suite [4790,4811]
===
match
---
trailer [62015,62021]
trailer [62015,62021]
===
match
---
name: FAILED [24829,24835]
name: FAILED [24829,24835]
===
match
---
funcdef [10431,10570]
funcdef [10431,10570]
===
match
---
atom_expr [66880,66894]
atom_expr [66987,67001]
===
match
---
name: dagrun [32862,32868]
name: dagrun [32862,32868]
===
match
---
trailer [9460,9467]
trailer [9460,9467]
===
match
---
suite [73963,74141]
suite [74070,74248]
===
match
---
tfpdef [30623,30643]
tfpdef [30623,30643]
===
match
---
atom [51489,51518]
atom [51489,51518]
===
match
---
name: os [4740,4742]
name: os [4740,4742]
===
match
---
name: UtcDateTime [11485,11496]
name: UtcDateTime [11485,11496]
===
match
---
operator: = [25899,25900]
operator: = [25899,25900]
===
match
---
trailer [22974,22981]
trailer [22974,22981]
===
match
---
name: task_id [14287,14294]
name: task_id [14287,14294]
===
match
---
operator: = [31471,31472]
operator: = [31471,31472]
===
match
---
string: """         Returns a command that can be executed anywhere where airflow is         installed. This command is part of the message sent to executors by         the orchestrator.         """ [18286,18476]
string: """         Returns a command that can be executed anywhere where airflow is         installed. This command is part of the message sent to executors by         the orchestrator.         """ [18286,18476]
===
match
---
name: interval_start [68051,68065]
name: interval_start [68158,68172]
===
match
---
expr_stmt [27492,27530]
expr_stmt [27492,27530]
===
match
---
name: RenderedTaskInstanceFields [79280,79306]
name: RenderedTaskInstanceFields [79387,79413]
===
match
---
trailer [64430,64450]
trailer [64430,64450]
===
match
---
name: external_executor_id [7019,7039]
name: external_executor_id [7019,7039]
===
match
---
name: get_hostname [48929,48941]
name: get_hostname [48929,48941]
===
match
---
trailer [70862,70872]
trailer [70969,70979]
===
match
---
operator: , [91767,91768]
operator: , [91874,91875]
===
match
---
import_from [57651,57693]
import_from [57651,57693]
===
match
---
suite [24417,24450]
suite [24417,24450]
===
match
---
simple_stmt [28096,28261]
simple_stmt [28096,28261]
===
match
---
trailer [52846,52851]
trailer [52846,52851]
===
match
---
atom_expr [29084,29097]
atom_expr [29084,29097]
===
match
---
return_stmt [93724,93740]
return_stmt [93831,93847]
===
match
---
trailer [68578,68600]
trailer [68685,68707]
===
match
---
trailer [11802,11831]
trailer [11802,11831]
===
match
---
operator: - [38615,38616]
operator: - [38615,38616]
===
match
---
name: TaskInstanceKey [28446,28461]
name: TaskInstanceKey [28446,28461]
===
match
---
atom_expr [46295,46310]
atom_expr [46295,46310]
===
match
---
arglist [83562,83731]
arglist [83669,83838]
===
match
---
operator: , [10221,10222]
operator: , [10221,10222]
===
match
---
operator: @ [93430,93431]
operator: @ [93537,93538]
===
match
---
trailer [4330,4332]
trailer [4330,4332]
===
match
---
name: dep_context [45532,45543]
name: dep_context [45532,45543]
===
match
---
operator: , [30459,30460]
operator: , [30459,30460]
===
match
---
dotted_name [8309,8330]
dotted_name [8309,8330]
===
match
---
name: params [67546,67552]
name: params [67653,67659]
===
match
---
trailer [5307,5323]
trailer [5307,5323]
===
match
---
name: log [46220,46223]
name: log [46220,46223]
===
match
---
trailer [30317,30343]
trailer [30317,30343]
===
match
---
subscriptlist [63391,63405]
subscriptlist [63391,63405]
===
match
---
string: 'execution_date' [75435,75451]
string: 'execution_date' [75542,75558]
===
match
---
operator: = [26374,26375]
operator: = [26374,26375]
===
match
---
parameters [70828,70834]
parameters [70935,70941]
===
match
---
string: "--job-id" [22367,22377]
string: "--job-id" [22367,22377]
===
match
---
import_as_names [3348,3379]
import_as_names [3348,3379]
===
match
---
expr_stmt [15953,15973]
expr_stmt [15953,15973]
===
match
---
name: TaskInstance [93981,93993]
name: TaskInstance [94088,94100]
===
match
---
atom_expr [50210,50226]
atom_expr [50210,50226]
===
match
---
trailer [59930,59950]
trailer [59930,59950]
===
match
---
trailer [54890,54895]
trailer [54890,54895]
===
match
---
atom_expr [6417,6438]
atom_expr [6417,6438]
===
match
---
parameters [32444,32518]
parameters [32444,32518]
===
match
---
name: prev_attempted_tries [6948,6968]
name: prev_attempted_tries [6948,6968]
===
match
---
arglist [13933,14005]
arglist [13933,14005]
===
match
---
argument [77552,77576]
argument [77659,77683]
===
match
---
if_stmt [63621,63682]
if_stmt [63621,63682]
===
match
---
name: session [45565,45572]
name: session [45565,45572]
===
match
---
operator: = [71196,71197]
operator: = [71303,71304]
===
match
---
name: session [50637,50644]
name: session [50637,50644]
===
match
---
sync_comp_for [7922,7968]
sync_comp_for [7922,7968]
===
match
---
trailer [83938,83942]
trailer [84045,84049]
===
match
---
atom_expr [77302,77314]
atom_expr [77409,77421]
===
match
---
trailer [92522,92535]
trailer [92629,92642]
===
match
---
operator: = [35081,35082]
operator: = [35081,35082]
===
match
---
name: ti [30487,30489]
name: ti [30487,30489]
===
match
---
operator: , [24550,24551]
operator: , [24550,24551]
===
match
---
suite [65911,66077]
suite [66018,66184]
===
match
---
name: Session [85236,85243]
name: Session [85343,85350]
===
match
---
parameters [60657,61037]
parameters [60657,61037]
===
match
---
tfpdef [70047,70056]
tfpdef [70154,70163]
===
match
---
name: ignore_schedule [32136,32151]
name: ignore_schedule [32136,32151]
===
match
---
atom_expr [92199,92212]
atom_expr [92306,92319]
===
match
---
if_stmt [22714,22760]
if_stmt [22714,22760]
===
match
---
trailer [8168,8170]
trailer [8168,8170]
===
match
---
name: RenderedTaskInstanceFields [52989,53015]
name: RenderedTaskInstanceFields [52989,53015]
===
match
---
atom_expr [62164,62173]
atom_expr [62164,62173]
===
match
---
suite [63562,66164]
suite [63562,66271]
===
match
---
name: dag [18917,18920]
name: dag [18917,18920]
===
match
---
operator: -> [85258,85260]
operator: -> [85365,85367]
===
match
---
name: error [5122,5127]
name: error [5122,5127]
===
match
---
name: self [93532,93536]
name: self [93639,93643]
===
match
---
name: email [84649,84654]
name: email [84756,84761]
===
match
---
name: State [50679,50684]
name: State [50679,50684]
===
match
---
trailer [28855,28861]
trailer [28855,28861]
===
match
---
string: """Executes Task (optionally with a Timeout) and pushes Xcom results""" [55262,55333]
string: """Executes Task (optionally with a Timeout) and pushes Xcom results""" [55262,55333]
===
match
---
name: provide_session [34002,34017]
name: provide_session [34002,34017]
===
match
---
name: self_execution_date [86190,86209]
name: self_execution_date [86297,86316]
===
match
---
name: Optional [73949,73957]
name: Optional [74056,74064]
===
match
---
name: prev_attempted_tries [17291,17311]
name: prev_attempted_tries [17291,17311]
===
match
---
name: self [66641,66645]
name: self [66748,66752]
===
match
---
comparison [32050,32067]
comparison [32050,32067]
===
match
---
name: DateTime [73127,73135]
name: DateTime [73234,73242]
===
match
---
operator: = [67321,67322]
operator: = [67428,67429]
===
match
---
simple_stmt [83498,83764]
simple_stmt [83605,83871]
===
match
---
trailer [40852,40859]
trailer [40852,40859]
===
match
---
trailer [93806,93823]
trailer [93913,93930]
===
match
---
name: session [57800,57807]
name: session [57800,57807]
===
match
---
atom_expr [41504,41517]
atom_expr [41504,41517]
===
match
---
operator: = [19504,19505]
operator: = [19504,19505]
===
match
---
name: defer [49605,49610]
name: defer [49605,49610]
===
match
---
name: state [12823,12828]
name: state [12823,12828]
===
match
---
name: DeprecationWarning [33363,33381]
name: DeprecationWarning [33363,33381]
===
match
---
operator: = [49511,49512]
operator: = [49511,49512]
===
match
---
operator: , [41488,41489]
operator: , [41488,41489]
===
match
---
simple_stmt [23454,23499]
simple_stmt [23454,23499]
===
match
---
simple_stmt [3780,3805]
simple_stmt [3780,3805]
===
match
---
simple_stmt [57962,57995]
simple_stmt [57962,57995]
===
match
---
trailer [6559,6570]
trailer [6559,6570]
===
match
---
operator: @ [35841,35842]
operator: @ [35841,35842]
===
match
---
name: replace [74299,74306]
name: replace [74406,74413]
===
match
---
name: deprecated_func [72570,72585]
name: deprecated_func [72677,72692]
===
match
---
atom_expr [53673,53719]
atom_expr [53673,53719]
===
match
---
decorated [29544,30550]
decorated [29544,30550]
===
match
---
name: Optional [86550,86558]
name: Optional [86657,86665]
===
match
---
operator: = [11453,11454]
operator: = [11453,11454]
===
match
---
trailer [19202,19719]
trailer [19202,19719]
===
match
---
name: super [14221,14226]
name: super [14221,14226]
===
match
---
name: dag_ids [88627,88634]
name: dag_ids [88734,88741]
===
match
---
name: _handle_reschedule [50777,50795]
name: _handle_reschedule [50777,50795]
===
match
---
name: state [51988,51993]
name: state [51988,51993]
===
match
---
name: ti [92809,92811]
name: ti [92916,92918]
===
match
---
operator: = [78131,78132]
operator: = [78238,78239]
===
match
---
trailer [45649,45653]
trailer [45649,45653]
===
match
---
name: state [29043,29048]
name: state [29043,29048]
===
match
---
atom_expr [35786,35835]
atom_expr [35786,35835]
===
match
---
comparison [9181,9204]
comparison [9181,9204]
===
match
---
operator: == [91402,91404]
operator: == [91509,91511]
===
match
---
trailer [67820,67829]
trailer [67927,67936]
===
match
---
string: '-' [74307,74310]
string: '-' [74414,74417]
===
match
---
trailer [25752,25754]
trailer [25752,25754]
===
match
---
operator: = [66481,66482]
operator: = [66588,66589]
===
match
---
name: Column [11769,11775]
name: Column [11769,11775]
===
match
---
name: dag [5406,5409]
name: dag [5406,5409]
===
match
---
trailer [7804,7994]
trailer [7804,7994]
===
match
---
string: """         Returns the DagRun for this TaskInstance          :param session: SQLAlchemy ORM Session         :return: DagRun         """ [40484,40620]
string: """         Returns the DagRun for this TaskInstance          :param session: SQLAlchemy ORM Session         :return: DagRun         """ [40484,40620]
===
match
---
operator: , [45371,45372]
operator: , [45371,45372]
===
match
---
decorated [63315,66164]
decorated [63315,66271]
===
match
---
operator: -> [9798,9800]
operator: -> [9798,9800]
===
match
---
name: _try_number [63161,63172]
name: _try_number [63161,63172]
===
match
---
name: duration [84994,85002]
name: duration [85101,85109]
===
match
---
operator: -> [33506,33508]
operator: -> [33506,33508]
===
match
---
simple_stmt [46162,46175]
simple_stmt [46162,46175]
===
match
---
name: state [16048,16053]
name: state [16048,16053]
===
match
---
name: _try_number [92385,92396]
name: _try_number [92492,92503]
===
match
---
import_name [805,819]
import_name [805,819]
===
match
---
trailer [73741,73760]
trailer [73848,73867]
===
match
---
operator: , [77370,77371]
operator: , [77477,77478]
===
match
---
simple_stmt [30172,30471]
simple_stmt [30172,30471]
===
match
---
name: airflow [3209,3216]
name: airflow [3209,3216]
===
match
---
name: task [30113,30117]
name: task [30113,30117]
===
match
---
operator: = [67395,67396]
operator: = [67502,67503]
===
match
---
name: staticmethod [19726,19738]
name: staticmethod [19726,19738]
===
match
---
simple_stmt [55024,55044]
simple_stmt [55024,55044]
===
match
---
atom_expr [54569,54578]
atom_expr [54569,54578]
===
match
---
name: execution_date [15402,15416]
name: execution_date [15402,15416]
===
match
---
atom_expr [24347,24358]
atom_expr [24347,24358]
===
match
---
trailer [11311,11337]
trailer [11311,11337]
===
match
---
trailer [91818,91826]
trailer [91925,91933]
===
match
---
simple_stmt [35779,35836]
simple_stmt [35779,35836]
===
match
---
operator: , [51598,51599]
operator: , [51598,51599]
===
match
---
name: dump [5117,5121]
name: dump [5117,5121]
===
match
---
operator: , [33927,33928]
operator: , [33927,33928]
===
match
---
operator: = [89994,89995]
operator: = [90101,90102]
===
match
---
name: failed [36841,36847]
name: failed [36841,36847]
===
match
---
simple_stmt [64732,64756]
simple_stmt [64839,64863]
===
match
---
operator: , [44268,44269]
operator: , [44268,44269]
===
match
---
name: provide_session [79108,79123]
name: provide_session [79215,79230]
===
match
---
atom_expr [67546,67572]
atom_expr [67653,67679]
===
match
---
operator: , [25448,25449]
operator: , [25448,25449]
===
match
---
arglist [86190,86225]
arglist [86297,86332]
===
match
---
simple_stmt [64415,64452]
simple_stmt [64415,64452]
===
match
---
param [60667,60672]
param [60667,60672]
===
match
---
expr_stmt [58513,58560]
expr_stmt [58513,58560]
===
match
---
name: queue [93616,93621]
name: queue [93723,93728]
===
match
---
string: "dag_run" [14047,14056]
string: "dag_run" [14047,14056]
===
match
---
string: 'try_number' [11618,11630]
string: 'try_number' [11618,11630]
===
match
---
trailer [30677,30686]
trailer [30677,30686]
===
match
---
operator: = [27136,27137]
operator: = [27136,27137]
===
match
---
name: ti [26583,26585]
name: ti [26583,26585]
===
match
---
name: dag_id [9188,9194]
name: dag_id [9188,9194]
===
match
---
suite [56746,57069]
suite [56746,57069]
===
match
---
operator: , [12204,12205]
operator: , [12204,12205]
===
match
---
operator: , [51802,51803]
operator: , [51802,51803]
===
match
---
name: error [59642,59647]
name: error [59642,59647]
===
match
---
name: provide_session [63316,63331]
name: provide_session [63316,63331]
===
match
---
if_stmt [29003,29208]
if_stmt [29003,29208]
===
match
---
operator: = [78373,78374]
operator: = [78480,78481]
===
match
---
expr_stmt [92686,92729]
expr_stmt [92793,92836]
===
match
---
tfpdef [19794,19806]
tfpdef [19794,19806]
===
match
---
operator: , [11406,11407]
operator: , [11406,11407]
===
match
---
operator: = [30644,30645]
operator: = [30644,30645]
===
match
---
name: previous_ti [32996,33007]
name: previous_ti [32996,33007]
===
match
---
name: session [15529,15536]
name: session [15529,15536]
===
match
---
trailer [60151,60155]
trailer [60151,60155]
===
match
---
trailer [7882,7892]
trailer [7882,7892]
===
match
---
suite [73137,73919]
suite [73244,74026]
===
match
---
atom_expr [89419,89447]
atom_expr [89526,89554]
===
match
---
simple_stmt [68039,68092]
simple_stmt [68146,68199]
===
match
---
param [81295,81304]
param [81402,81411]
===
match
---
return_stmt [74428,74480]
return_stmt [74535,74587]
===
match
---
atom_expr [76895,76908]
atom_expr [77002,77015]
===
match
---
name: bool [41330,41334]
name: bool [41330,41334]
===
match
---
atom_expr [83716,83730]
atom_expr [83823,83837]
===
match
---
name: airflow [3109,3116]
name: airflow [3109,3116]
===
match
---
name: has_task [6375,6383]
name: has_task [6375,6383]
===
match
---
suite [72149,72526]
suite [72256,72633]
===
match
---
string: 'dag_run' [41070,41079]
string: 'dag_run' [41070,41079]
===
match
---
name: self [57372,57376]
name: self [57372,57376]
===
match
---
atom_expr [91085,91093]
atom_expr [91192,91200]
===
match
---
operator: = [27555,27556]
operator: = [27555,27556]
===
match
---
decorated [23314,23764]
decorated [23314,23764]
===
match
---
atom_expr [28160,28172]
atom_expr [28160,28172]
===
match
---
simple_stmt [66397,66491]
simple_stmt [66504,66598]
===
match
---
atom_expr [59097,59157]
atom_expr [59097,59157]
===
match
---
name: airflow [2638,2645]
name: airflow [2638,2645]
===
match
---
name: datetime [85201,85209]
name: datetime [85308,85316]
===
match
---
expr_stmt [23454,23498]
expr_stmt [23454,23498]
===
match
---
name: self [92994,92998]
name: self [93101,93105]
===
match
---
name: task [77302,77306]
name: task [77409,77413]
===
match
---
simple_stmt [46377,46399]
simple_stmt [46377,46399]
===
match
---
trailer [69855,69859]
trailer [69962,69966]
===
match
---
operator: , [8696,8697]
operator: , [8696,8697]
===
match
---
simple_stmt [22122,22181]
simple_stmt [22122,22181]
===
match
---
name: self [64732,64736]
name: self [64839,64843]
===
match
---
name: email_on_retry [65774,65788]
name: email_on_retry [65881,65895]
===
match
---
arglist [53267,53298]
arglist [53267,53298]
===
match
---
simple_stmt [33023,33163]
simple_stmt [33023,33163]
===
match
---
trailer [57776,57791]
trailer [57776,57791]
===
match
---
name: pendulum [34558,34566]
name: pendulum [34558,34566]
===
match
---
decorator [35841,35858]
decorator [35841,35858]
===
match
---
trailer [25887,25898]
trailer [25887,25898]
===
match
---
operator: , [80706,80707]
operator: , [80813,80814]
===
match
---
atom_expr [77783,77801]
atom_expr [77890,77908]
===
match
---
argument [11876,11890]
argument [11876,11890]
===
match
---
atom_expr [41556,41569]
atom_expr [41556,41569]
===
match
---
expr_stmt [18983,19010]
expr_stmt [18983,19010]
===
match
---
if_stmt [80158,80224]
if_stmt [80265,80331]
===
match
---
comparison [90959,90988]
comparison [91066,91095]
===
match
---
operator: , [61800,61801]
operator: , [61800,61801]
===
match
---
trailer [22604,22611]
trailer [22604,22611]
===
match
---
name: debug [27043,27048]
name: debug [27043,27048]
===
match
---
name: self [26362,26366]
name: self [26362,26366]
===
match
---
name: Variable [71136,71144]
name: Variable [71243,71251]
===
match
---
expr_stmt [91931,91982]
expr_stmt [92038,92089]
===
match
---
name: dagrun [69216,69222]
name: dagrun [69323,69329]
===
match
---
name: self [25450,25454]
name: self [25450,25454]
===
match
---
operator: = [81573,81574]
operator: = [81680,81681]
===
match
---
operator: = [45405,45406]
operator: = [45405,45406]
===
match
---
number: 1 [82901,82902]
number: 1 [83008,83009]
===
match
---
name: send_email [84628,84638]
name: send_email [84735,84745]
===
match
---
trailer [69874,69880]
trailer [69981,69987]
===
match
---
name: session [24153,24160]
name: session [24153,24160]
===
match
---
simple_stmt [71055,71113]
simple_stmt [71162,71220]
===
match
---
suite [60456,60509]
suite [60456,60509]
===
match
---
suite [72874,72952]
suite [72981,73059]
===
match
---
name: dr [41081,41083]
name: dr [41081,41083]
===
match
---
simple_stmt [79316,79403]
simple_stmt [79423,79510]
===
match
---
atom_expr [78534,78543]
atom_expr [78641,78650]
===
match
---
testlist_comp [13359,13393]
testlist_comp [13359,13393]
===
match
---
name: _try_number [62807,62818]
name: _try_number [62807,62818]
===
match
---
argument [35089,35104]
argument [35089,35104]
===
match
---
trailer [89372,89374]
trailer [89479,89481]
===
match
---
atom_expr [12884,12908]
atom_expr [12884,12908]
===
match
---
name: Optional [73109,73117]
name: Optional [73216,73224]
===
match
---
name: max_retry_delay [40084,40099]
name: max_retry_delay [40084,40099]
===
match
---
trailer [73126,73135]
trailer [73233,73242]
===
match
---
atom_expr [81575,81611]
atom_expr [81682,81718]
===
match
---
expr_stmt [32032,32096]
expr_stmt [32032,32096]
===
match
---
name: suppress [67446,67454]
name: suppress [67553,67561]
===
match
---
trailer [25595,25603]
trailer [25595,25603]
===
match
---
atom_expr [60363,60390]
atom_expr [60363,60390]
===
match
---
atom_expr [60477,60508]
atom_expr [60477,60508]
===
match
---
operator: = [8201,8202]
operator: = [8201,8202]
===
match
---
trailer [74459,74480]
trailer [74566,74587]
===
match
---
name: hasattr [92569,92576]
name: hasattr [92676,92683]
===
match
---
name: item [69875,69879]
name: item [69982,69986]
===
match
---
trailer [75750,75816]
trailer [75857,75923]
===
match
---
name: dag [6371,6374]
name: dag [6371,6374]
===
match
---
name: queued_by_job [93994,94007]
name: queued_by_job [94101,94114]
===
match
---
name: self [28051,28055]
name: self [28051,28055]
===
match
---
trailer [27662,27674]
trailer [27662,27674]
===
match
---
operator: = [80809,80810]
operator: = [80916,80917]
===
match
---
name: run_ids_by_dag_id [8929,8946]
name: run_ids_by_dag_id [8929,8946]
===
match
---
testlist_comp [30429,30457]
testlist_comp [30429,30457]
===
match
---
decorator [41109,41126]
decorator [41109,41126]
===
match
---
expr_stmt [16094,16112]
expr_stmt [16094,16112]
===
match
---
trailer [50508,50513]
trailer [50508,50513]
===
match
---
name: session [46438,46445]
name: session [46438,46445]
===
match
---
name: add [46446,46449]
name: add [46446,46449]
===
match
---
atom_expr [25794,25805]
atom_expr [25794,25805]
===
match
---
import_from [2937,2978]
import_from [2937,2978]
===
match
---
operator: = [14260,14261]
operator: = [14260,14261]
===
match
---
operator: @ [93668,93669]
operator: @ [93775,93776]
===
match
---
simple_stmt [9741,9761]
simple_stmt [9741,9761]
===
match
---
name: SUCCESS [43471,43478]
name: SUCCESS [43471,43478]
===
match
---
trailer [60571,60581]
trailer [60571,60581]
===
match
---
name: utcnow [55007,55013]
name: utcnow [55007,55013]
===
match
---
name: in_env_var_format [53276,53293]
name: in_env_var_format [53276,53293]
===
match
---
param [20155,20173]
param [20155,20173]
===
match
---
atom_expr [25967,25980]
atom_expr [25967,25980]
===
match
---
trailer [74443,74459]
trailer [74550,74566]
===
match
---
name: dag_id [89721,89727]
name: dag_id [89828,89834]
===
match
---
atom_expr [10344,10411]
atom_expr [10344,10411]
===
match
---
trailer [3866,3876]
trailer [3866,3876]
===
match
---
name: self [44169,44173]
name: self [44169,44173]
===
match
---
name: self [58363,58367]
name: self [58363,58367]
===
match
---
atom_expr [8949,8965]
atom_expr [8949,8965]
===
match
---
trailer [70722,70726]
trailer [70829,70833]
===
match
---
simple_stmt [4799,4811]
simple_stmt [4799,4811]
===
match
---
operator: , [84244,84245]
operator: , [84351,84352]
===
match
---
operator: , [17982,17983]
operator: , [17982,17983]
===
match
---
param [93384,93388]
param [93491,93495]
===
match
---
name: run_id [25630,25636]
name: run_id [25630,25636]
===
match
---
atom_expr [58983,59007]
atom_expr [58983,59007]
===
match
---
simple_stmt [57372,57422]
simple_stmt [57372,57422]
===
match
---
suite [10261,10412]
suite [10261,10412]
===
match
---
name: Iterable [90079,90087]
name: Iterable [90186,90194]
===
match
---
name: ti [26020,26022]
name: ti [26020,26022]
===
match
---
trailer [51258,51265]
trailer [51258,51265]
===
match
---
name: self [61092,61096]
name: self [61092,61096]
===
match
---
simple_stmt [64351,64377]
simple_stmt [64351,64377]
===
match
---
name: execution_date [86384,86398]
name: execution_date [86491,86505]
===
match
---
argument [50615,50635]
argument [50615,50635]
===
match
---
string: """         Based on this instance's try_number, this will calculate         the number of previously attempted tries, defaulting to 0.         """ [17327,17474]
string: """         Based on this instance's try_number, this will calculate         the number of previously attempted tries, defaulting to 0.         """ [17327,17474]
===
match
---
trailer [9219,9223]
trailer [9219,9223]
===
match
---
name: in_ [91790,91793]
name: in_ [91897,91900]
===
match
---
operator: = [63541,63542]
operator: = [63541,63542]
===
match
---
operator: == [91118,91120]
operator: == [91225,91227]
===
match
---
name: state [32050,32055]
name: state [32050,32055]
===
match
---
arith_expr [43629,43646]
arith_expr [43629,43646]
===
match
---
name: settings [46787,46795]
name: settings [46787,46795]
===
match
---
tfpdef [85156,85166]
tfpdef [85263,85273]
===
match
---
name: self [29142,29146]
name: self [29142,29146]
===
match
---
trailer [52865,52870]
trailer [52865,52870]
===
match
---
tfpdef [66326,66342]
tfpdef [66433,66449]
===
match
---
name: self [52842,52846]
name: self [52842,52846]
===
match
---
name: TaskInstanceKey [28341,28356]
name: TaskInstanceKey [28341,28356]
===
match
---
operator: = [19399,19400]
operator: = [19399,19400]
===
match
---
name: execution_date [80777,80791]
name: execution_date [80884,80898]
===
match
---
name: __repr__ [70820,70828]
name: __repr__ [70927,70935]
===
match
---
operator: { [77317,77318]
operator: { [77424,77425]
===
match
---
arith_expr [46312,46330]
arith_expr [46312,46330]
===
match
---
operator: = [57390,57391]
operator: = [57390,57391]
===
match
---
suite [34759,35262]
suite [34759,35262]
===
match
---
name: replace [73035,73042]
name: replace [73142,73149]
===
match
---
name: pickle_id [22311,22320]
name: pickle_id [22311,22320]
===
match
---
expr_stmt [11928,11961]
expr_stmt [11928,11961]
===
match
---
name: _get_previous_dagrun_success [68222,68250]
name: _get_previous_dagrun_success [68329,68357]
===
match
---
name: primary [91819,91826]
name: primary [91926,91933]
===
match
---
name: vals_kv [89216,89223]
name: vals_kv [89323,89330]
===
match
---
atom_expr [92686,92707]
atom_expr [92793,92814]
===
match
---
name: session [49013,49020]
name: session [49013,49020]
===
match
---
operator: , [11249,11250]
operator: , [11249,11250]
===
match
---
name: self [31032,31036]
name: self [31032,31036]
===
match
---
trailer [26011,26017]
trailer [26011,26017]
===
match
---
return_stmt [46162,46174]
return_stmt [46162,46174]
===
match
---
name: RenderedTaskInstanceFields [78244,78270]
name: RenderedTaskInstanceFields [78351,78377]
===
match
---
suite [35350,35836]
suite [35350,35836]
===
match
---
trailer [91375,91383]
trailer [91482,91490]
===
match
---
name: scalar [89878,89884]
name: scalar [89985,89991]
===
match
---
trailer [91396,91401]
trailer [91503,91508]
===
match
---
operator: , [9815,9816]
operator: , [9815,9816]
===
match
---
name: execution_date [47058,47072]
name: execution_date [47058,47072]
===
match
---
name: urllib [1153,1159]
name: urllib [1153,1159]
===
match
---
simple_stmt [3204,3271]
simple_stmt [3204,3271]
===
match
---
operator: = [66367,66368]
operator: = [66474,66475]
===
match
---
name: TaskInstance [89814,89826]
name: TaskInstance [89921,89933]
===
match
---
name: has_option [83881,83891]
name: has_option [83988,83998]
===
match
---
name: session [28242,28249]
name: session [28242,28249]
===
match
---
name: item [70234,70238]
name: item [70341,70345]
===
match
---
trailer [54559,54579]
trailer [54559,54579]
===
match
---
operator: , [83730,83731]
operator: , [83837,83838]
===
match
---
atom_expr [5951,5967]
atom_expr [5951,5967]
===
match
---
suite [9998,10192]
suite [9998,10192]
===
match
---
name: ti [24414,24416]
name: ti [24414,24416]
===
match
---
trailer [90025,90031]
trailer [90132,90138]
===
match
---
atom_expr [67366,67420]
atom_expr [67473,67527]
===
match
---
arglist [37148,37183]
arglist [37148,37183]
===
match
---
expr_stmt [26793,26844]
expr_stmt [26793,26844]
===
match
---
name: environ [53494,53501]
name: environ [53494,53501]
===
match
---
name: iso [23112,23115]
name: iso [23112,23115]
===
match
---
suite [18966,19011]
suite [18966,19011]
===
match
---
arglist [47161,47177]
arglist [47161,47177]
===
match
---
name: self [50531,50535]
name: self [50531,50535]
===
match
---
name: task [30961,30965]
name: task [30961,30965]
===
match
---
operator: = [81038,81039]
operator: = [81145,81146]
===
match
---
name: log [28852,28855]
name: log [28852,28855]
===
match
---
operator: @ [79107,79108]
operator: @ [79214,79215]
===
match
---
name: self [81536,81540]
name: self [81643,81647]
===
match
---
suite [89315,89448]
suite [89422,89555]
===
match
---
expr_stmt [46040,46076]
expr_stmt [46040,46076]
===
match
---
string: " Continue to run task in non smart sensor mode." [54143,54192]
string: " Continue to run task in non smart sensor mode." [54143,54192]
===
match
---
decorated [17183,17268]
decorated [17183,17268]
===
match
---
expr_stmt [23401,23445]
expr_stmt [23401,23445]
===
match
---
string: '' [73048,73050]
string: '' [73155,73157]
===
match
---
operator: , [2198,2199]
operator: , [2198,2199]
===
match
---
simple_stmt [52045,52079]
simple_stmt [52045,52079]
===
match
---
arglist [13747,13898]
arglist [13747,13898]
===
match
---
if_stmt [22401,22475]
if_stmt [22401,22475]
===
match
---
name: state [35815,35820]
name: state [35815,35820]
===
match
---
atom_expr [48963,48974]
atom_expr [48963,48974]
===
match
---
if_stmt [68509,68556]
if_stmt [68616,68663]
===
match
---
or_test [27504,27530]
or_test [27504,27530]
===
match
---
operator: @ [62319,62320]
operator: @ [62319,62320]
===
match
---
trailer [77995,78047]
trailer [78102,78154]
===
match
---
name: get_template_env [83799,83815]
name: get_template_env [83906,83922]
===
match
---
name: str [47299,47302]
name: str [47299,47302]
===
match
---
trailer [62696,62700]
trailer [62696,62700]
===
match
---
atom_expr [27773,27786]
atom_expr [27773,27786]
===
match
---
name: self [27639,27643]
name: self [27639,27643]
===
match
---
decorated [17273,17824]
decorated [17273,17824]
===
match
---
name: Integer [12092,12099]
name: Integer [12092,12099]
===
match
---
name: dep_context [37506,37517]
name: dep_context [37506,37517]
===
match
---
simple_stmt [22601,22642]
simple_stmt [22601,22642]
===
match
---
name: session [32292,32299]
name: session [32292,32299]
===
match
---
simple_stmt [69851,69881]
simple_stmt [69958,69988]
===
match
---
name: execution_date [74643,74657]
name: execution_date [74750,74764]
===
match
---
fstring_expr [37924,37938]
fstring_expr [37924,37938]
===
match
---
atom_expr [12918,12971]
atom_expr [12918,12971]
===
match
---
operator: , [83099,83100]
operator: , [83206,83207]
===
match
---
operator: , [43525,43526]
operator: , [43525,43526]
===
match
---
name: job_id [48889,48895]
name: job_id [48889,48895]
===
match
---
operator: = [19568,19569]
operator: = [19568,19569]
===
match
---
operator: , [61316,61317]
operator: , [61316,61317]
===
match
---
name: email [65905,65910]
name: email [66012,66017]
===
match
---
name: self [49943,49947]
name: self [49943,49947]
===
match
---
funcdef [47783,52268]
funcdef [47783,52268]
===
match
---
simple_stmt [83441,83485]
simple_stmt [83548,83592]
===
match
---
name: on_retry_callback [60482,60499]
name: on_retry_callback [60482,60499]
===
match
---
name: execution_date [15885,15899]
name: execution_date [15885,15899]
===
match
---
name: session [55052,55059]
name: session [55052,55059]
===
match
---
suite [17869,17944]
suite [17869,17944]
===
match
---
expr_stmt [74961,74984]
expr_stmt [75068,75091]
===
match
---
trailer [68763,68765]
trailer [68870,68872]
===
match
---
return_stmt [71129,71202]
return_stmt [71236,71309]
===
match
---
atom_expr [18990,19010]
atom_expr [18990,19010]
===
match
---
return_stmt [66811,66822]
return_stmt [66918,66929]
===
match
---
operator: , [12829,12830]
operator: , [12829,12830]
===
match
---
expr_stmt [27539,27572]
expr_stmt [27539,27572]
===
match
---
operator: , [50949,50950]
operator: , [50949,50950]
===
match
---
atom_expr [53062,53134]
atom_expr [53062,53134]
===
match
---
name: register_in_sensor_service [53941,53967]
name: register_in_sensor_service [53941,53967]
===
match
---
simple_stmt [19166,19720]
simple_stmt [19166,19720]
===
match
---
name: defaultdict [5911,5922]
name: defaultdict [5911,5922]
===
match
---
name: hashlib [39117,39124]
name: hashlib [39117,39124]
===
match
---
trailer [12140,12154]
trailer [12140,12154]
===
match
---
trailer [49727,49739]
trailer [49727,49739]
===
match
---
name: get_connection_from_secrets [71849,71876]
name: get_connection_from_secrets [71956,71983]
===
match
---
number: 1 [72927,72928]
number: 1 [73034,73035]
===
match
---
name: task_copy [57313,57322]
name: task_copy [57313,57322]
===
match
---
trailer [79895,79899]
trailer [80002,80006]
===
match
---
name: self [53312,53316]
name: self [53312,53316]
===
match
---
simple_stmt [55537,55574]
simple_stmt [55537,55574]
===
match
---
operator: = [74746,74747]
operator: = [74853,74854]
===
match
---
name: scalar [15717,15723]
name: scalar [15717,15723]
===
match
---
name: exception [84440,84449]
name: exception [84547,84556]
===
match
---
name: str [63391,63394]
name: str [63391,63394]
===
match
---
name: task [77287,77291]
name: task [77394,77398]
===
match
---
name: items [9295,9300]
name: items [9295,9300]
===
match
---
atom_expr [9914,9926]
atom_expr [9914,9926]
===
match
---
operator: , [78686,78687]
operator: , [78793,78794]
===
match
---
name: session [51230,51237]
name: session [51230,51237]
===
match
---
expr_stmt [67357,67420]
expr_stmt [67464,67527]
===
match
---
name: Connection [2342,2352]
name: Connection [2342,2352]
===
match
---
simple_stmt [50123,50158]
simple_stmt [50123,50158]
===
match
---
name: task [43170,43174]
name: task [43170,43174]
===
match
---
operator: , [45572,45573]
operator: , [45572,45573]
===
match
---
atom_expr [56132,56177]
atom_expr [56132,56177]
===
match
---
name: duration [25986,25994]
name: duration [25986,25994]
===
match
---
expr_stmt [3843,3876]
expr_stmt [3843,3876]
===
match
---
return_stmt [74267,74276]
return_stmt [74374,74383]
===
match
---
number: 1 [10188,10189]
number: 1 [10188,10189]
===
match
---
trailer [32923,32941]
trailer [32923,32941]
===
match
---
param [34669,34697]
param [34669,34697]
===
match
---
name: commit [51675,51681]
name: commit [51675,51681]
===
match
---
atom_expr [91480,91499]
atom_expr [91587,91606]
===
match
---
simple_stmt [51280,51286]
simple_stmt [51280,51286]
===
match
---
name: TaskInstance [90959,90971]
name: TaskInstance [91066,91078]
===
match
---
name: List [1107,1111]
name: List [1107,1111]
===
match
---
name: Tuple [1135,1140]
name: Tuple [1135,1140]
===
match
---
name: trigger_timeout [12398,12413]
name: trigger_timeout [12398,12413]
===
match
---
simple_stmt [92872,92891]
simple_stmt [92979,92998]
===
match
---
name: self [47161,47165]
name: self [47161,47165]
===
match
---
atom_expr [40019,40044]
atom_expr [40019,40044]
===
match
---
name: dep_name [37667,37675]
name: dep_name [37667,37675]
===
match
---
suite [64064,64115]
suite [64064,64115]
===
match
---
param [63492,63525]
param [63492,63525]
===
match
---
dotted_name [3109,3140]
dotted_name [3109,3140]
===
match
---
name: simplefilter [74550,74562]
name: simplefilter [74657,74669]
===
match
---
name: session [15585,15592]
name: session [15585,15592]
===
match
---
suite [3737,3759]
suite [3737,3759]
===
match
---
operator: = [57978,57979]
operator: = [57978,57979]
===
match
---
name: state [28565,28570]
name: state [28565,28570]
===
match
---
operator: = [13957,13958]
operator: = [13957,13958]
===
match
---
name: run_id [11377,11383]
name: run_id [11377,11383]
===
match
---
name: task [6410,6414]
name: task [6410,6414]
===
match
---
trailer [67552,67559]
trailer [67659,67666]
===
match
---
suite [72997,73052]
suite [73104,73159]
===
match
---
trailer [40078,40083]
trailer [40078,40083]
===
match
---
fstring [49127,49177]
fstring [49127,49177]
===
match
---
operator: = [35918,35919]
operator: = [35918,35919]
===
match
---
atom_expr [11581,11591]
atom_expr [11581,11591]
===
match
---
atom_expr [80560,80571]
atom_expr [80667,80678]
===
match
---
expr_stmt [81828,82147]
expr_stmt [81935,82254]
===
match
---
operator: , [47850,47851]
operator: , [47850,47851]
===
match
---
name: local [19534,19539]
name: local [19534,19539]
===
match
---
operator: = [84559,84560]
operator: = [84666,84667]
===
match
---
name: ds [74239,74241]
name: ds [74346,74348]
===
match
---
expr_stmt [6912,6969]
expr_stmt [6912,6969]
===
match
---
trailer [81578,81589]
trailer [81685,81696]
===
match
---
simple_stmt [30504,30550]
simple_stmt [30504,30550]
===
match
---
trailer [26538,26554]
trailer [26538,26554]
===
match
---
name: session [79394,79401]
name: session [79501,79508]
===
match
---
name: info [40661,40665]
name: info [40661,40665]
===
match
---
atom_expr [34480,34530]
atom_expr [34480,34530]
===
match
---
trailer [52828,52834]
trailer [52828,52834]
===
match
---
atom [9078,9363]
atom [9078,9363]
===
match
---
argument [33975,33994]
argument [33975,33994]
===
match
---
name: try_number [7842,7852]
name: try_number [7842,7852]
===
match
---
name: ignore_all_deps [19354,19369]
name: ignore_all_deps [19354,19369]
===
match
---
name: self [36686,36690]
name: self [36686,36690]
===
match
---
argument [77923,77941]
argument [78030,78048]
===
match
---
simple_stmt [28366,28431]
simple_stmt [28366,28431]
===
match
---
atom_expr [57035,57068]
atom_expr [57035,57068]
===
match
---
operator: , [37504,37505]
operator: , [37504,37505]
===
match
---
trailer [27725,27741]
trailer [27725,27741]
===
match
---
simple_stmt [12598,12633]
simple_stmt [12598,12633]
===
match
---
atom_expr [23413,23444]
atom_expr [23413,23444]
===
match
---
name: task_id [77307,77314]
name: task_id [77414,77421]
===
match
---
name: UtcDateTime [11520,11531]
name: UtcDateTime [11520,11531]
===
match
---
operator: , [74310,74311]
operator: , [74417,74418]
===
match
---
trailer [46802,46810]
trailer [46802,46810]
===
match
---
simple_stmt [93981,94032]
simple_stmt [94088,94139]
===
match
---
test [36686,36730]
test [36686,36730]
===
match
---
return_stmt [74098,74140]
return_stmt [74205,74247]
===
match
---
name: str [85143,85146]
name: str [85250,85253]
===
match
---
atom_expr [43451,43461]
atom_expr [43451,43461]
===
match
---
trailer [40023,40028]
trailer [40023,40028]
===
match
---
expr_stmt [32165,32228]
expr_stmt [32165,32228]
===
match
---
simple_stmt [1769,1816]
simple_stmt [1769,1816]
===
match
---
operator: = [15450,15451]
operator: = [15450,15451]
===
match
---
suite [29278,29539]
suite [29278,29539]
===
match
---
name: State [59867,59872]
name: State [59867,59872]
===
match
---
trailer [9294,9300]
trailer [9294,9300]
===
match
---
atom_expr [73118,73135]
atom_expr [73225,73242]
===
match
---
name: e [50507,50508]
name: e [50507,50508]
===
match
---
atom_expr [64431,64443]
atom_expr [64431,64443]
===
match
---
name: execution_date [28206,28220]
name: execution_date [28206,28220]
===
match
---
expr_stmt [8929,8965]
expr_stmt [8929,8965]
===
match
---
name: dag_id [12859,12865]
name: dag_id [12859,12865]
===
match
---
return_stmt [30151,30162]
return_stmt [30151,30162]
===
match
---
trailer [9054,9061]
trailer [9054,9061]
===
match
---
trailer [58246,58254]
trailer [58246,58254]
===
match
---
trailer [39918,39932]
trailer [39918,39932]
===
match
---
name: clear_xcom_data [52792,52807]
name: clear_xcom_data [52792,52807]
===
match
---
string: 'DAGS_FOLDER' [19103,19116]
string: 'DAGS_FOLDER' [19103,19116]
===
match
---
atom_expr [23118,23156]
atom_expr [23118,23156]
===
match
---
operator: = [51641,51642]
operator: = [51641,51642]
===
match
---
if_stmt [84847,85010]
if_stmt [84954,85117]
===
match
---
name: end_date [93217,93225]
name: end_date [93324,93332]
===
match
---
trailer [50047,50061]
trailer [50047,50061]
===
match
---
operator: == [61947,61949]
operator: == [61947,61949]
===
match
---
name: t [91031,91032]
name: t [91138,91139]
===
match
---
simple_stmt [54980,55016]
simple_stmt [54980,55016]
===
match
---
trailer [54434,54436]
trailer [54434,54436]
===
match
---
operator: , [68339,68340]
operator: , [68446,68447]
===
match
---
suite [22588,22642]
suite [22588,22642]
===
match
---
atom_expr [30318,30342]
atom_expr [30318,30342]
===
match
---
trailer [68028,68030]
trailer [68135,68137]
===
match
---
trailer [79362,79379]
trailer [79469,79486]
===
match
---
name: session [78124,78131]
name: session [78231,78238]
===
match
---
operator: , [25651,25652]
operator: , [25651,25652]
===
match
---
suite [61576,61891]
suite [61576,61891]
===
match
---
funcdef [68218,68358]
funcdef [68325,68465]
===
match
---
comparison [74239,74249]
comparison [74346,74356]
===
match
---
name: Stats [64287,64292]
name: Stats [64287,64292]
===
match
---
atom_expr [22355,22392]
atom_expr [22355,22392]
===
match
---
operator: - [56560,56561]
operator: - [56560,56561]
===
match
---
name: pool [43190,43194]
name: pool [43190,43194]
===
match
---
name: task_ids [7883,7891]
name: task_ids [7883,7891]
===
match
---
trailer [32530,32546]
trailer [32530,32546]
===
match
---
name: delay [40101,40106]
name: delay [40101,40106]
===
match
---
name: Exception [4865,4874]
name: Exception [4865,4874]
===
match
---
suite [58627,58730]
suite [58627,58730]
===
match
---
string: "rendering of template_fields." [79045,79076]
string: "rendering of template_fields." [79152,79183]
===
match
---
string: 'start_date' [50048,50060]
string: 'start_date' [50048,50060]
===
match
---
name: provide_session [40409,40424]
name: provide_session [40409,40424]
===
match
---
name: models [2401,2407]
name: models [2401,2407]
===
match
---
operator: += [65690,65692]
operator: += [65797,65799]
===
match
---
operator: + [47381,47382]
operator: + [47381,47382]
===
match
---
name: dag_id [23300,23306]
name: dag_id [23300,23306]
===
match
---
atom_expr [26376,26385]
atom_expr [26376,26385]
===
match
---
operator: , [76741,76742]
operator: , [76848,76849]
===
match
---
operator: , [13394,13395]
operator: , [13394,13395]
===
match
---
name: rendered_value [78453,78467]
name: rendered_value [78560,78574]
===
match
---
suite [74057,74086]
suite [74164,74193]
===
match
---
name: log [3123,3126]
name: log [3123,3126]
===
match
---
atom_expr [33981,33994]
atom_expr [33981,33994]
===
match
---
name: engine [46796,46802]
name: engine [46796,46802]
===
match
---
name: Any [70087,70090]
name: Any [70194,70197]
===
match
---
name: passed [37808,37814]
name: passed [37808,37814]
===
match
---
trailer [93417,93424]
trailer [93524,93531]
===
match
---
name: task [48804,48808]
name: task [48804,48808]
===
match
---
name: str [20199,20202]
name: str [20199,20202]
===
match
---
suite [41614,47094]
suite [41614,47094]
===
match
---
name: total_seconds [84947,84960]
name: total_seconds [85054,85067]
===
match
---
operator: = [59235,59236]
operator: = [59235,59236]
===
match
---
name: get_prev [31721,31729]
name: get_prev [31721,31729]
===
match
---
atom_expr [60059,60092]
atom_expr [60059,60092]
===
match
---
name: filter_by [15635,15644]
name: filter_by [15635,15644]
===
match
---
name: context [52927,52934]
name: context [52927,52934]
===
match
---
operator: } [77298,77299]
operator: } [77405,77406]
===
match
---
simple_stmt [10475,10550]
simple_stmt [10475,10550]
===
match
---
expr_stmt [27721,27764]
expr_stmt [27721,27764]
===
match
---
simple_stmt [72386,72437]
simple_stmt [72493,72544]
===
match
---
name: session [66360,66367]
name: session [66467,66474]
===
match
---
trailer [81589,81597]
trailer [81696,81704]
===
match
---
name: set_duration [62632,62644]
name: set_duration [62632,62644]
===
match
---
name: dag_id [91204,91210]
name: dag_id [91311,91317]
===
match
---
operator: = [69223,69224]
operator: = [69330,69331]
===
match
---
name: str [19803,19806]
name: str [19803,19806]
===
match
---
operator: = [13980,13981]
operator: = [13980,13981]
===
match
---
string: "&state=success" [23737,23753]
string: "&state=success" [23737,23753]
===
match
---
name: dag_id [90826,90832]
name: dag_id [90933,90939]
===
match
---
operator: = [66532,66533]
operator: = [66639,66640]
===
match
---
name: primary_key [11427,11438]
name: primary_key [11427,11438]
===
match
---
expr_stmt [73513,73557]
expr_stmt [73620,73664]
===
match
---
import_from [3660,3717]
import_from [3660,3717]
===
match
---
fstring_start: f" [79622,79624]
fstring_start: f" [79729,79731]
===
match
---
trailer [52191,52197]
trailer [52191,52197]
===
match
---
operator: , [37753,37754]
operator: , [37753,37754]
===
match
---
trailer [80990,81009]
trailer [81097,81116]
===
match
---
expr_stmt [83441,83484]
expr_stmt [83548,83591]
===
match
---
param [71698,71723]
param [71805,71830]
===
match
---
name: job_ids [8287,8294]
name: job_ids [8287,8294]
===
match
---
trailer [62266,62283]
trailer [62266,62283]
===
match
---
trailer [61837,61842]
trailer [61837,61842]
===
match
---
name: self [92333,92337]
name: self [92440,92444]
===
match
---
simple_stmt [17878,17908]
simple_stmt [17878,17908]
===
match
---
param [83842,83846]
param [83949,83953]
===
match
---
if_stmt [58569,58823]
if_stmt [58569,58823]
===
match
---
atom_expr [54697,54758]
atom_expr [54697,54758]
===
match
---
atom_expr [36716,36730]
atom_expr [36716,36730]
===
match
---
suite [24463,24489]
suite [24463,24489]
===
match
---
atom_expr [91534,91554]
atom_expr [91641,91661]
===
match
---
suite [16633,17178]
suite [16633,17178]
===
match
---
simple_stmt [2888,2937]
simple_stmt [2888,2937]
===
match
---
name: _dag_id [92955,92962]
name: _dag_id [93062,93069]
===
match
---
operator: = [12414,12415]
operator: = [12414,12415]
===
match
---
atom_expr [27658,27674]
atom_expr [27658,27674]
===
match
---
simple_stmt [81233,81254]
simple_stmt [81340,81361]
===
match
---
trailer [72939,72951]
trailer [73046,73058]
===
match
---
trailer [72926,72929]
trailer [73033,73036]
===
match
---
name: execution_timeout [56290,56307]
name: execution_timeout [56290,56307]
===
match
---
trailer [53501,53508]
trailer [53501,53508]
===
match
---
trailer [67301,67303]
trailer [67408,67410]
===
match
---
operator: = [35904,35905]
operator: = [35904,35905]
===
match
---
suite [37297,37853]
suite [37297,37853]
===
match
---
operator: = [92179,92180]
operator: = [92286,92287]
===
match
---
name: ignore_task_deps [44118,44134]
name: ignore_task_deps [44118,44134]
===
match
---
trailer [56571,56578]
trailer [56571,56578]
===
match
---
string: "exception" [59627,59638]
string: "exception" [59627,59638]
===
match
---
name: session [9092,9099]
name: session [9092,9099]
===
match
---
arglist [30245,30460]
arglist [30245,30460]
===
match
---
arglist [11618,11650]
arglist [11618,11650]
===
match
---
name: key [10435,10438]
name: key [10435,10438]
===
match
---
name: SimpleTaskInstance [91991,92009]
name: SimpleTaskInstance [92098,92116]
===
match
---
name: warning [54046,54053]
name: warning [54046,54053]
===
match
---
name: session [51251,51258]
name: session [51251,51258]
===
match
---
if_stmt [52141,52268]
if_stmt [52141,52268]
===
match
---
trailer [12129,12155]
trailer [12129,12155]
===
match
---
name: log [2373,2376]
name: log [2373,2376]
===
match
---
name: session [78374,78381]
name: session [78481,78488]
===
match
---
trailer [4841,4847]
trailer [4841,4847]
===
match
---
name: DateTime [35340,35348]
name: DateTime [35340,35348]
===
match
---
parameters [74367,74369]
parameters [74474,74476]
===
match
---
param [60944,60973]
param [60944,60973]
===
match
---
comparison [24218,24252]
comparison [24218,24252]
===
match
---
name: ti [91831,91833]
name: ti [91938,91940]
===
match
---
trailer [15214,15222]
trailer [15214,15222]
===
match
---
atom_expr [7112,7121]
atom_expr [7112,7121]
===
match
---
simple_stmt [46635,46655]
simple_stmt [46635,46655]
===
match
---
atom_expr [92569,92595]
atom_expr [92676,92702]
===
match
---
name: Optional [34148,34156]
name: Optional [34148,34156]
===
match
---
param [17863,17867]
param [17863,17867]
===
match
---
parameters [66569,66575]
parameters [66676,66682]
===
match
---
operator: = [61828,61829]
operator: = [61828,61829]
===
match
---
operator: , [41524,41525]
operator: , [41524,41525]
===
match
---
trailer [46955,46970]
trailer [46955,46970]
===
match
---
name: next_method [26923,26934]
name: next_method [26923,26934]
===
match
---
name: ti [91812,91814]
name: ti [91919,91921]
===
match
---
lambdef [5923,5968]
lambdef [5923,5968]
===
match
---
funcdef [55209,57444]
funcdef [55209,57444]
===
match
---
simple_stmt [32359,32378]
simple_stmt [32359,32378]
===
match
---
name: count [30511,30516]
name: count [30511,30516]
===
match
---
trailer [89441,89447]
trailer [89548,89554]
===
match
---
classdef [71212,71972]
classdef [71319,72079]
===
match
---
trailer [56578,56580]
trailer [56578,56580]
===
match
---
string: '' [47260,47262]
string: '' [47260,47262]
===
match
---
name: _start_date [92287,92298]
name: _start_date [92394,92405]
===
match
---
dotted_name [3385,3409]
dotted_name [3385,3409]
===
match
---
atom_expr [93856,93884]
atom_expr [93963,93991]
===
match
---
name: run_id [9213,9219]
name: run_id [9213,9219]
===
match
---
name: datetime [93235,93243]
name: datetime [93342,93350]
===
match
---
trailer [50320,50323]
trailer [50320,50323]
===
match
---
operator: , [33901,33902]
operator: , [33901,33902]
===
match
---
string: """         The start date from property previous_ti_success.          :param state: If passed, it only take into account instances of a specific state.         :param session: SQLAlchemy ORM Session         """ [34768,34979]
string: """         The start date from property previous_ti_success.          :param state: If passed, it only take into account instances of a specific state.         :param session: SQLAlchemy ORM Session         """ [34768,34979]
===
match
---
simple_stmt [24810,24836]
simple_stmt [24810,24836]
===
match
---
suite [17234,17268]
suite [17234,17268]
===
match
---
name: State [6993,6998]
name: State [6993,6998]
===
match
---
parameters [27110,27142]
parameters [27110,27142]
===
match
---
name: warnings [73597,73605]
name: warnings [73704,73712]
===
match
---
atom_expr [69359,69376]
atom_expr [69466,69483]
===
match
---
name: get_dagrun [85931,85941]
name: get_dagrun [86038,86048]
===
match
---
operator: = [18915,18916]
operator: = [18915,18916]
===
match
---
name: seek [4732,4736]
name: seek [4732,4736]
===
match
---
name: try_number [7856,7866]
name: try_number [7856,7866]
===
match
---
atom_expr [92333,92347]
atom_expr [92440,92454]
===
match
---
name: cache [74669,74674]
name: cache [74776,74781]
===
match
---
trailer [46067,46074]
trailer [46067,46074]
===
match
---
expr_stmt [14355,14400]
expr_stmt [14355,14400]
===
match
---
name: render [84096,84102]
name: render [84203,84209]
===
match
---
name: render [84143,84149]
name: render [84250,84256]
===
match
---
number: 0 [30493,30494]
number: 0 [30493,30494]
===
match
---
atom_expr [49241,49250]
atom_expr [49241,49250]
===
match
---
name: dag_id [13329,13335]
name: dag_id [13329,13335]
===
match
---
operator: = [88577,88578]
operator: = [88684,88685]
===
match
---
name: min [39888,39891]
name: min [39888,39891]
===
match
---
name: ignore_all_deps [61179,61194]
name: ignore_all_deps [61179,61194]
===
match
---
operator: = [82789,82790]
operator: = [82896,82897]
===
match
---
trailer [60388,60390]
trailer [60388,60390]
===
match
---
suite [4284,4566]
suite [4284,4566]
===
match
---
operator: , [28487,28488]
operator: , [28487,28488]
===
match
---
operator: = [67159,67160]
operator: = [67266,67267]
===
match
---
simple_stmt [26709,26727]
simple_stmt [26709,26727]
===
match
---
atom_expr [83536,83749]
atom_expr [83643,83856]
===
match
---
trailer [30214,30222]
trailer [30214,30222]
===
match
---
name: timezone [49090,49098]
name: timezone [49090,49098]
===
match
---
operator: = [20139,20140]
operator: = [20139,20140]
===
match
---
simple_stmt [30080,30097]
simple_stmt [30080,30097]
===
match
---
name: incr [49122,49126]
name: incr [49122,49126]
===
match
---
suite [44297,44360]
suite [44297,44360]
===
match
---
name: extend [22906,22912]
name: extend [22906,22912]
===
match
---
name: incr [54703,54707]
name: incr [54703,54707]
===
match
---
atom_expr [33509,33533]
atom_expr [33509,33533]
===
match
---
param [70047,70057]
param [70154,70164]
===
match
---
simple_stmt [57026,57069]
simple_stmt [57026,57069]
===
match
---
atom_expr [63385,63406]
atom_expr [63385,63406]
===
match
---
trailer [80004,80018]
trailer [80111,80125]
===
match
---
name: kubernetes [3673,3683]
name: kubernetes [3673,3683]
===
match
---
name: self [26007,26011]
name: self [26007,26011]
===
match
---
operator: { [82551,82552]
operator: { [82658,82659]
===
match
---
trailer [37707,37714]
trailer [37707,37714]
===
match
---
tfpdef [34669,34689]
tfpdef [34669,34689]
===
match
---
testlist [9901,9939]
testlist [9901,9939]
===
match
---
name: item [71601,71605]
name: item [71708,71712]
===
match
---
expr_stmt [11966,11997]
expr_stmt [11966,11997]
===
match
---
name: default_subject [83175,83190]
name: default_subject [83282,83297]
===
match
---
operator: } [51960,51961]
operator: } [51960,51961]
===
match
---
expr_stmt [27007,27024]
expr_stmt [27007,27024]
===
match
---
arglist [36906,37058]
arglist [36906,37058]
===
match
---
funcdef [54820,55204]
funcdef [54820,55204]
===
match
---
suite [31531,31560]
suite [31531,31560]
===
match
---
decorator [9766,9776]
decorator [9766,9776]
===
match
---
name: pool_slots [26435,26445]
name: pool_slots [26435,26445]
===
match
---
return_stmt [40312,40402]
return_stmt [40312,40402]
===
match
---
tfpdef [92134,92150]
tfpdef [92241,92257]
===
match
---
operator: , [46949,46950]
operator: , [46949,46950]
===
match
---
operator: @ [73061,73062]
operator: @ [73168,73169]
===
match
---
trailer [85064,85073]
trailer [85171,85180]
===
match
---
name: cmd [22283,22286]
name: cmd [22283,22286]
===
match
---
operator: = [41410,41411]
operator: = [41410,41411]
===
match
---
name: ignore_task_deps [22486,22502]
name: ignore_task_deps [22486,22502]
===
match
---
funcdef [90055,91856]
funcdef [90162,91963]
===
match
---
name: conditions [7612,7622]
name: conditions [7612,7622]
===
match
---
trailer [89157,89163]
trailer [89264,89270]
===
match
---
atom_expr [32075,32096]
atom_expr [32075,32096]
===
match
---
string: 'execution_date' [75562,75578]
string: 'execution_date' [75669,75685]
===
match
---
funcdef [35281,35836]
funcdef [35281,35836]
===
match
---
name: jinja_env [82994,83003]
name: jinja_env [83101,83110]
===
match
---
atom_expr [26821,26844]
atom_expr [26821,26844]
===
match
---
import_from [2388,2431]
import_from [2388,2431]
===
match
---
trailer [8388,8395]
trailer [8388,8395]
===
match
---
trailer [93882,93884]
trailer [93989,93991]
===
match
---
if_stmt [59436,60624]
if_stmt [59436,60624]
===
match
---
arglist [12845,12873]
arglist [12845,12873]
===
match
---
name: str [9812,9815]
name: str [9812,9815]
===
match
---
return_stmt [17118,17141]
return_stmt [17118,17141]
===
match
---
name: next_kwargs [56165,56176]
name: next_kwargs [56165,56176]
===
match
---
trailer [86330,86338]
trailer [86437,86445]
===
match
---
atom_expr [53400,53462]
atom_expr [53400,53462]
===
match
---
name: parse [1160,1165]
name: parse [1160,1165]
===
match
---
name: qry [25794,25797]
name: qry [25794,25797]
===
match
---
trailer [91725,91789]
trailer [91832,91896]
===
match
---
name: job_id [6045,6051]
name: job_id [6045,6051]
===
match
---
with_stmt [67430,67510]
with_stmt [67537,67617]
===
match
---
string: 'task_instance_trigger_id_fkey' [13210,13241]
string: 'task_instance_trigger_id_fkey' [13210,13241]
===
match
---
funcdef [93444,93493]
funcdef [93551,93600]
===
match
---
name: overwrite_params_with_dag_run_conf [67659,67693]
name: overwrite_params_with_dag_run_conf [67766,67800]
===
match
---
argument [32834,32849]
argument [32834,32849]
===
match
---
decorated [60629,62077]
decorated [60629,62077]
===
match
---
atom_expr [14131,14149]
atom_expr [14131,14149]
===
match
---
trailer [83389,83396]
trailer [83496,83503]
===
match
---
simple_stmt [65707,65739]
simple_stmt [65814,65846]
===
match
---
trailer [60567,60571]
trailer [60567,60571]
===
match
---
name: utcnow [56572,56578]
name: utcnow [56572,56578]
===
match
---
expr_stmt [67959,67990]
expr_stmt [68066,68097]
===
match
---
name: Variable [70983,70991]
name: Variable [71090,71098]
===
match
---
name: ts [68120,68122]
name: ts [68227,68229]
===
match
---
trailer [8457,8468]
trailer [8457,8468]
===
match
---
trailer [67786,67792]
trailer [67893,67899]
===
match
---
expr_stmt [82994,83130]
expr_stmt [83101,83237]
===
match
---
trailer [67501,67508]
trailer [67608,67615]
===
match
---
simple_stmt [22218,22249]
simple_stmt [22218,22249]
===
match
---
decorator [29544,29561]
decorator [29544,29561]
===
match
---
name: DataInterval [2924,2936]
name: DataInterval [2924,2936]
===
match
---
atom_expr [17077,17087]
atom_expr [17077,17087]
===
match
---
name: state [12965,12970]
name: state [12965,12970]
===
match
---
name: value [89360,89365]
name: value [89467,89472]
===
match
---
name: key [86272,86275]
name: key [86379,86382]
===
match
---
simple_stmt [67188,67205]
simple_stmt [67295,67312]
===
match
---
atom_expr [89985,89993]
atom_expr [90092,90100]
===
match
---
operator: = [27018,27019]
operator: = [27018,27019]
===
match
---
operator: = [11794,11795]
operator: = [11794,11795]
===
match
---
name: property [16599,16607]
name: property [16599,16607]
===
match
---
name: xcom_pull [86507,86516]
name: xcom_pull [86614,86623]
===
match
---
atom [78663,78703]
atom [78770,78810]
===
match
---
tfpdef [86540,86585]
tfpdef [86647,86692]
===
match
---
name: send_email [3046,3056]
name: send_email [3046,3056]
===
match
---
trailer [62220,62222]
trailer [62220,62222]
===
match
---
name: UP_FOR_RETRY [65726,65738]
name: UP_FOR_RETRY [65833,65845]
===
match
---
name: session [40831,40838]
name: session [40831,40838]
===
match
---
name: dep_name [37014,37022]
name: dep_name [37014,37022]
===
match
---
name: ti [6931,6933]
name: ti [6931,6933]
===
match
---
name: self [84561,84565]
name: self [84668,84672]
===
match
---
trailer [28922,28928]
trailer [28922,28928]
===
match
---
trailer [28479,28487]
trailer [28479,28487]
===
match
---
name: extend [22850,22856]
name: extend [22850,22856]
===
match
---
operator: , [13094,13095]
operator: , [13094,13095]
===
match
---
name: TemplateAssertionError [1266,1288]
name: TemplateAssertionError [1266,1288]
===
match
---
operator: , [2069,2070]
operator: , [2069,2070]
===
match
---
expr_stmt [46377,46398]
expr_stmt [46377,46398]
===
match
---
trailer [46100,46106]
trailer [46100,46106]
===
match
---
name: get_prev_data_interval_end_success [76470,76504]
name: get_prev_data_interval_end_success [76577,76611]
===
match
---
trailer [52926,52943]
trailer [52926,52943]
===
match
---
operator: , [69791,69792]
operator: , [69898,69899]
===
match
---
name: extend [22222,22228]
name: extend [22222,22228]
===
match
---
operator: { [75105,75106]
operator: { [75212,75213]
===
match
---
argument [39970,40002]
argument [39970,40002]
===
match
---
trailer [27608,27630]
trailer [27608,27630]
===
match
---
name: dep_context [37405,37416]
name: dep_context [37405,37416]
===
match
---
trailer [52626,52658]
trailer [52626,52658]
===
match
---
name: utcnow [62610,62616]
name: utcnow [62610,62616]
===
match
---
name: DagRunState [3475,3486]
name: DagRunState [3475,3486]
===
match
---
trailer [75079,75088]
trailer [75186,75195]
===
match
---
trailer [91814,91818]
trailer [91921,91925]
===
match
---
trailer [63435,63441]
trailer [63435,63441]
===
match
---
name: self [90026,90030]
name: self [90133,90137]
===
match
---
operator: -> [73946,73948]
operator: -> [74053,74055]
===
match
---
name: data [4848,4852]
name: data [4848,4852]
===
match
---
operator: = [52934,52935]
operator: = [52934,52935]
===
match
---
name: deprecated_proxy [77511,77527]
name: deprecated_proxy [77618,77634]
===
match
---
trailer [92672,92677]
trailer [92779,92784]
===
match
---
argument [88739,88754]
argument [88846,88861]
===
match
---
name: mark_success [22192,22204]
name: mark_success [22192,22204]
===
match
---
import_from [3014,3056]
import_from [3014,3056]
===
match
---
comparison [74034,74056]
comparison [74141,74163]
===
match
---
suite [67138,67180]
suite [67245,67287]
===
match
---
name: Optional [41504,41512]
name: Optional [41504,41512]
===
match
---
atom_expr [53583,53621]
atom_expr [53583,53621]
===
match
---
name: get_run_data_interval [68579,68600]
name: get_run_data_interval [68686,68707]
===
match
---
name: context [57218,57225]
name: context [57218,57225]
===
match
---
trailer [51967,51972]
trailer [51967,51972]
===
match
---
name: task [6476,6480]
name: task [6476,6480]
===
match
---
atom_expr [19274,19285]
atom_expr [19274,19285]
===
match
---
operator: , [91745,91746]
operator: , [91852,91853]
===
match
---
name: prepare_for_execution [49263,49284]
name: prepare_for_execution [49263,49284]
===
match
---
expr_stmt [45605,45628]
expr_stmt [45605,45628]
===
match
---
atom_expr [13294,13484]
atom_expr [13294,13484]
===
match
---
name: ti [92181,92183]
name: ti [92288,92290]
===
match
---
trailer [9585,9596]
trailer [9585,9596]
===
match
---
number: 1 [6588,6589]
number: 1 [6588,6589]
===
match
---
atom_expr [45992,46023]
atom_expr [45992,46023]
===
match
---
name: duration [25972,25980]
name: duration [25972,25980]
===
match
---
param [10223,10238]
param [10223,10238]
===
match
---
name: get_prev_ds [74687,74698]
name: get_prev_ds [74794,74805]
===
match
---
operator: = [63518,63519]
operator: = [63518,63519]
===
match
---
name: String [11217,11223]
name: String [11217,11223]
===
match
---
factor [93873,93875]
factor [93980,93982]
===
match
---
atom_expr [22601,22641]
atom_expr [22601,22641]
===
match
---
trailer [22382,22390]
trailer [22382,22390]
===
match
---
trailer [5483,5490]
trailer [5483,5490]
===
match
---
name: self [58854,58858]
name: self [58854,58858]
===
match
---
operator: = [53241,53242]
operator: = [53241,53242]
===
match
---
name: executor_config [12105,12120]
name: executor_config [12105,12120]
===
match
---
operator: , [79963,79964]
operator: , [80070,80071]
===
match
---
name: self [62802,62806]
name: self [62802,62806]
===
match
---
operator: { [53416,53417]
operator: { [53416,53417]
===
match
---
expr_stmt [38540,38622]
expr_stmt [38540,38622]
===
match
---
name: log [3843,3846]
name: log [3843,3846]
===
match
---
operator: = [49745,49746]
operator: = [49745,49746]
===
match
---
return_stmt [68288,68357]
return_stmt [68395,68464]
===
match
---
argument [35815,35834]
argument [35815,35834]
===
match
---
name: context [60084,60091]
name: context [60084,60091]
===
match
---
trailer [51167,51238]
trailer [51167,51238]
===
match
---
string: '%Y-%m-%d' [67830,67840]
string: '%Y-%m-%d' [67937,67947]
===
match
---
name: ignore_ti_state [61346,61361]
name: ignore_ti_state [61346,61361]
===
match
---
name: self [45938,45942]
name: self [45938,45942]
===
match
---
name: models [14485,14491]
name: models [14485,14491]
===
match
---
operator: , [13873,13874]
operator: , [13873,13874]
===
match
---
suite [70575,70608]
suite [70682,70715]
===
match
---
arglist [15049,15167]
arglist [15049,15167]
===
match
---
trailer [17161,17173]
trailer [17161,17173]
===
match
---
name: session [1692,1699]
name: session [1692,1699]
===
match
---
trailer [52851,52858]
trailer [52851,52858]
===
match
---
simple_stmt [16642,16899]
simple_stmt [16642,16899]
===
match
---
operator: , [78122,78123]
operator: , [78229,78230]
===
match
---
string: 'Exception:<br>{{exception_html}}<br>' [81927,81965]
string: 'Exception:<br>{{exception_html}}<br>' [82034,82072]
===
match
---
name: prev_ti [34546,34553]
name: prev_ti [34546,34553]
===
match
---
name: self [10360,10364]
name: self [10360,10364]
===
match
---
name: self [27581,27585]
name: self [27581,27585]
===
match
---
trailer [26823,26844]
trailer [26823,26844]
===
match
---
operator: { [37924,37925]
operator: { [37924,37925]
===
match
---
atom_expr [73471,73495]
atom_expr [73578,73602]
===
match
---
name: key [76944,76947]
name: key [77051,77054]
===
match
---
name: error_file [64053,64063]
name: error_file [64053,64063]
===
match
---
name: self [35887,35891]
name: self [35887,35891]
===
match
---
name: actual_start_date [62369,62386]
name: actual_start_date [62369,62386]
===
match
---
simple_stmt [29216,29236]
simple_stmt [29216,29236]
===
match
---
argument [9176,9302]
argument [9176,9302]
===
match
---
if_stmt [56277,57235]
if_stmt [56277,57235]
===
match
---
name: run_id [9725,9731]
name: run_id [9725,9731]
===
match
---
string: 'dag_run_conf_overrides_params' [67608,67639]
string: 'dag_run_conf_overrides_params' [67715,67746]
===
match
---
trailer [28131,28138]
trailer [28131,28138]
===
match
---
simple_stmt [52498,52560]
simple_stmt [52498,52560]
===
match
---
operator: = [58065,58066]
operator: = [58065,58066]
===
match
---
return_stmt [23016,23026]
return_stmt [23016,23026]
===
match
---
name: rendered_k8s_spec [79418,79435]
name: rendered_k8s_spec [79525,79542]
===
match
---
name: self [51577,51581]
name: self [51577,51581]
===
match
---
operator: , [11874,11875]
operator: , [11874,11875]
===
match
---
exprlist [9258,9273]
exprlist [9258,9273]
===
match
---
suite [18677,18710]
suite [18677,18710]
===
match
---
trailer [49143,49148]
trailer [49143,49148]
===
match
---
operator: = [49558,49559]
operator: = [49558,49559]
===
match
---
if_stmt [43400,43533]
if_stmt [43400,43533]
===
match
---
name: e [50976,50977]
name: e [50976,50977]
===
match
---
arith_expr [82883,82902]
arith_expr [82990,83009]
===
match
---
name: ti [7123,7125]
name: ti [7123,7125]
===
match
---
import_from [79236,79306]
import_from [79343,79413]
===
match
---
name: state [54950,54955]
name: state [54950,54955]
===
match
---
trailer [36694,36699]
trailer [36694,36699]
===
match
---
atom_expr [89784,89796]
atom_expr [89891,89903]
===
match
---
name: AirflowSmartSensorException [2127,2154]
name: AirflowSmartSensorException [2127,2154]
===
match
---
name: get [55895,55898]
name: get [55895,55898]
===
match
---
name: task [60477,60481]
name: task [60477,60481]
===
match
---
trailer [28055,28059]
trailer [28055,28059]
===
match
---
atom_expr [72661,72718]
atom_expr [72768,72825]
===
match
---
name: client [3562,3568]
name: client [3562,3568]
===
match
---
name: self [26513,26517]
name: self [26513,26517]
===
match
---
simple_stmt [92161,92191]
simple_stmt [92268,92298]
===
match
---
operator: , [8097,8098]
operator: , [8097,8098]
===
match
---
operator: , [14056,14057]
operator: , [14056,14057]
===
match
---
name: e [51168,51169]
name: e [51168,51169]
===
match
---
name: stacklevel [33395,33405]
name: stacklevel [33395,33405]
===
match
---
expr_stmt [27460,27483]
expr_stmt [27460,27483]
===
match
---
name: cmd [22516,22519]
name: cmd [22516,22519]
===
match
---
try_stmt [60034,60210]
try_stmt [60034,60210]
===
match
---
atom_expr [19216,19227]
atom_expr [19216,19227]
===
match
---
argument [88655,88672]
argument [88762,88779]
===
match
---
operator: , [62386,62387]
operator: , [62386,62387]
===
match
---
name: deps [43886,43890]
name: deps [43886,43890]
===
match
---
name: self [54730,54734]
name: self [54730,54734]
===
match
---
operator: = [28241,28242]
operator: = [28241,28242]
===
match
---
param [66925,66930]
param [67032,67037]
===
match
---
expr_stmt [26901,26934]
expr_stmt [26901,26934]
===
match
---
name: replacement [72069,72080]
name: replacement [72176,72187]
===
match
---
simple_stmt [31628,31749]
simple_stmt [31628,31749]
===
match
---
trailer [50217,50224]
trailer [50217,50224]
===
match
---
operator: , [19475,19476]
operator: , [19475,19476]
===
match
---
operator: ** [11408,11410]
operator: ** [11408,11410]
===
match
---
expr_stmt [26479,26500]
expr_stmt [26479,26500]
===
match
---
operator: , [60934,60935]
operator: , [60934,60935]
===
match
---
name: session [32842,32849]
name: session [32842,32849]
===
match
---
name: DateTime [34166,34174]
name: DateTime [34166,34174]
===
match
---
atom_expr [50679,50692]
atom_expr [50679,50692]
===
match
---
operator: = [65767,65768]
operator: = [65874,65875]
===
match
---
name: try_number [16616,16626]
name: try_number [16616,16626]
===
match
---
trailer [40844,40852]
trailer [40844,40852]
===
match
---
name: timeout_seconds [56844,56859]
name: timeout_seconds [56844,56859]
===
match
---
name: models [40764,40770]
name: models [40764,40770]
===
match
---
name: self [50772,50776]
name: self [50772,50776]
===
match
---
name: Context [58869,58876]
name: Context [58869,58876]
===
match
---
name: exception [59106,59115]
name: exception [59106,59115]
===
match
---
name: self [17978,17982]
name: self [17978,17982]
===
match
---
import_as_names [2857,2887]
import_as_names [2857,2887]
===
match
---
name: os [83073,83075]
name: os [83180,83182]
===
match
---
trailer [52512,52559]
trailer [52512,52559]
===
match
---
simple_stmt [37105,37118]
simple_stmt [37105,37118]
===
match
---
operator: = [19988,19989]
operator: = [19988,19989]
===
match
---
name: models [3914,3920]
name: models [3914,3920]
===
match
---
simple_stmt [10007,10092]
simple_stmt [10007,10092]
===
match
---
name: pool [12998,13002]
name: pool [12998,13002]
===
match
---
string: "Error when executing on_retry_callback" [60582,60622]
string: "Error when executing on_retry_callback" [60582,60622]
===
match
---
name: strftime [72931,72939]
name: strftime [73038,73046]
===
match
---
name: Optional [41468,41476]
name: Optional [41468,41476]
===
match
---
name: commit [46671,46677]
name: commit [46671,46677]
===
match
---
string: "run" [22149,22154]
string: "run" [22149,22154]
===
match
---
name: get_previous_ti [34485,34500]
name: get_previous_ti [34485,34500]
===
match
---
trailer [6247,6258]
trailer [6247,6258]
===
match
---
name: datetime [93152,93160]
name: datetime [93259,93267]
===
match
---
atom_expr [84299,84356]
atom_expr [84406,84463]
===
match
---
param [54859,54871]
param [54859,54871]
===
match
---
arglist [23185,23208]
arglist [23185,23208]
===
match
---
operator: , [22147,22148]
operator: , [22147,22148]
===
match
---
name: state [6003,6008]
name: state [6003,6008]
===
match
---
trailer [4736,4752]
trailer [4736,4752]
===
match
---
and_test [43403,43478]
and_test [43403,43478]
===
match
---
param [57492,57500]
param [57492,57500]
===
match
---
not_test [50563,50576]
not_test [50563,50576]
===
match
---
if_stmt [91364,91856]
if_stmt [91471,91963]
===
match
---
name: defaultdict [5931,5942]
name: defaultdict [5931,5942]
===
match
---
simple_stmt [58363,58391]
simple_stmt [58363,58391]
===
match
---
name: get_dep_statuses [37474,37490]
name: get_dep_statuses [37474,37490]
===
match
---
operator: = [12610,12611]
operator: = [12610,12611]
===
match
---
operator: , [63546,63547]
operator: , [63546,63547]
===
match
---
operator: { [23611,23612]
operator: { [23611,23612]
===
match
---
name: session [61505,61512]
name: session [61505,61512]
===
match
---
name: content [84023,84030]
name: content [84130,84137]
===
match
---
testlist_comp [51722,51750]
testlist_comp [51722,51750]
===
match
---
name: test_mode [62410,62419]
name: test_mode [62410,62419]
===
match
---
operator: , [75083,75084]
operator: , [75190,75191]
===
match
---
name: airflow [3665,3672]
name: airflow [3665,3672]
===
match
---
name: self [53968,53972]
name: self [53968,53972]
===
match
---
name: end_date [62876,62884]
name: end_date [62876,62884]
===
match
---
atom_expr [27683,27697]
atom_expr [27683,27697]
===
match
---
atom_expr [18625,18646]
atom_expr [18625,18646]
===
match
---
atom_expr [57757,57791]
atom_expr [57757,57791]
===
match
---
name: DagRun [8888,8894]
name: DagRun [8888,8894]
===
match
---
name: dag_id [28120,28126]
name: dag_id [28120,28126]
===
match
---
funcdef [3983,4566]
funcdef [3983,4566]
===
match
---
operator: , [2121,2122]
operator: , [2121,2122]
===
match
---
name: _log_state [52092,52102]
name: _log_state [52092,52102]
===
match
---
trailer [45653,45661]
trailer [45653,45661]
===
match
---
parameters [9970,9976]
parameters [9970,9976]
===
match
---
atom_expr [50028,50061]
atom_expr [50028,50061]
===
match
---
name: self [25542,25546]
name: self [25542,25546]
===
match
---
parameters [93452,93458]
parameters [93559,93565]
===
match
---
atom_expr [62546,62575]
atom_expr [62546,62575]
===
match
---
argument [19620,19627]
argument [19620,19627]
===
match
---
name: Optional [34676,34684]
name: Optional [34676,34684]
===
match
---
name: bool [41369,41373]
name: bool [41369,41373]
===
match
---
operator: = [14827,14828]
operator: = [14827,14828]
===
match
---
trailer [22905,22912]
trailer [22905,22912]
===
match
---
param [5420,5491]
param [5420,5491]
===
match
---
suite [68803,68832]
suite [68910,68939]
===
match
---
name: KubeConfig [3645,3655]
name: KubeConfig [3645,3655]
===
match
---
operator: = [57059,57060]
operator: = [57059,57060]
===
match
---
name: append [6283,6289]
name: append [6283,6289]
===
match
---
param [52478,52483]
param [52478,52483]
===
match
---
suite [40176,40403]
suite [40176,40403]
===
match
---
operator: -> [93538,93540]
operator: -> [93645,93647]
===
match
---
trailer [10166,10190]
trailer [10166,10190]
===
match
---
name: cmd [22601,22604]
name: cmd [22601,22604]
===
match
---
if_stmt [93894,94032]
if_stmt [94001,94139]
===
match
---
atom_expr [26947,26963]
atom_expr [26947,26963]
===
match
---
and_test [91085,91134]
and_test [91192,91241]
===
match
---
comparison [9485,9514]
comparison [9485,9514]
===
match
---
simple_stmt [26793,26845]
simple_stmt [26793,26845]
===
match
---
return_stmt [35182,35261]
return_stmt [35182,35261]
===
match
---
name: ti [6945,6947]
name: ti [6945,6947]
===
match
---
atom_expr [90810,90869]
atom_expr [90917,90976]
===
match
---
name: ds [67801,67803]
name: ds [67908,67910]
===
match
---
dotted_name [1720,1743]
dotted_name [1720,1743]
===
match
---
name: RUNNING [46460,46467]
name: RUNNING [46460,46467]
===
match
---
name: path [19027,19031]
name: path [19027,19031]
===
match
---
name: job_id [48898,48904]
name: job_id [48898,48904]
===
match
---
name: nullable [11357,11365]
name: nullable [11357,11365]
===
match
---
try_stmt [4245,4566]
try_stmt [4245,4566]
===
match
---
name: execution_timeout [56696,56713]
name: execution_timeout [56696,56713]
===
match
---
arglist [43170,43194]
arglist [43170,43194]
===
match
---
name: provide_session [24895,24910]
name: provide_session [24895,24910]
===
match
---
atom_expr [11217,11249]
atom_expr [11217,11249]
===
match
---
name: Optional [68664,68672]
name: Optional [68771,68779]
===
match
---
operator: = [18787,18788]
operator: = [18787,18788]
===
match
---
param [41352,41382]
param [41352,41382]
===
match
---
trailer [49020,49026]
trailer [49020,49026]
===
match
---
atom_expr [86326,86338]
atom_expr [86433,86445]
===
match
---
funcdef [28324,28519]
funcdef [28324,28519]
===
match
---
operator: , [72067,72068]
operator: , [72174,72175]
===
match
---
name: commit [51259,51265]
name: commit [51259,51265]
===
match
---
name: airflow [40756,40763]
name: airflow [40756,40763]
===
match
---
expr_stmt [18819,18830]
expr_stmt [18819,18830]
===
match
---
name: merge [46101,46106]
name: merge [46101,46106]
===
match
---
atom_expr [7664,7673]
atom_expr [7664,7673]
===
match
---
operator: - [93873,93874]
operator: - [93980,93981]
===
match
---
operator: = [63815,63816]
operator: = [63815,63816]
===
match
---
trailer [7144,7152]
trailer [7144,7152]
===
match
---
arglist [77440,77474]
arglist [77547,77581]
===
match
---
expr_stmt [23165,23209]
expr_stmt [23165,23209]
===
match
---
atom_expr [49782,50076]
atom_expr [49782,50076]
===
match
---
number: 1 [58178,58179]
number: 1 [58178,58179]
===
match
---
name: integrate_macros_plugins [67277,67301]
name: integrate_macros_plugins [67384,67408]
===
match
---
atom_expr [80731,80753]
atom_expr [80838,80860]
===
match
---
simple_stmt [36663,36731]
simple_stmt [36663,36731]
===
match
---
name: session [5365,5372]
name: session [5365,5372]
===
match
---
atom_expr [10163,10190]
atom_expr [10163,10190]
===
match
---
name: RenderedTaskInstanceFields [52415,52441]
name: RenderedTaskInstanceFields [52415,52441]
===
match
---
operator: , [1462,1463]
operator: , [1462,1463]
===
match
---
operator: , [28172,28173]
operator: , [28172,28173]
===
match
---
trailer [64095,64114]
trailer [64095,64114]
===
match
---
trailer [76546,76574]
trailer [76653,76681]
===
match
---
name: dict [80322,80326]
name: dict [80429,80433]
===
match
---
name: test_mode [63416,63425]
name: test_mode [63416,63425]
===
match
---
simple_stmt [62531,62538]
simple_stmt [62531,62538]
===
match
---
trailer [16125,16138]
trailer [16125,16138]
===
match
---
name: timeout [3513,3520]
name: timeout [3513,3520]
===
match
---
simple_stmt [53858,53877]
simple_stmt [53858,53877]
===
match
---
name: tis [5984,5987]
name: tis [5984,5987]
===
match
---
atom_expr [53736,53774]
atom_expr [53736,53774]
===
match
---
name: coerce_datetime [75319,75334]
name: coerce_datetime [75426,75441]
===
match
---
name: State [59453,59458]
name: State [59453,59458]
===
match
---
trailer [7137,7141]
trailer [7137,7141]
===
match
---
name: job_id [43312,43318]
name: job_id [43312,43318]
===
match
---
import_from [14472,14512]
import_from [14472,14512]
===
match
---
trailer [7758,7765]
trailer [7758,7765]
===
match
---
operator: @ [93042,93043]
operator: @ [93149,93150]
===
match
---
operator: , [62884,62885]
operator: , [62884,62885]
===
match
---
suite [69203,69378]
suite [69310,69485]
===
match
---
name: attr [47124,47128]
name: attr [47124,47128]
===
match
---
name: vals_kv [89014,89021]
name: vals_kv [89121,89128]
===
match
---
operator: = [12781,12782]
operator: = [12781,12782]
===
match
---
trailer [47707,47719]
trailer [47707,47719]
===
match
---
atom_expr [84628,84678]
atom_expr [84735,84785]
===
match
---
trailer [26494,26500]
trailer [26494,26500]
===
match
---
fstring_expr [53416,53419]
fstring_expr [53416,53419]
===
match
---
trailer [83198,83215]
trailer [83305,83322]
===
match
---
name: base_url [23225,23233]
name: base_url [23225,23233]
===
match
---
atom_expr [68575,68608]
atom_expr [68682,68715]
===
match
---
fstring_expr [54729,54750]
fstring_expr [54729,54750]
===
match
---
name: log [59102,59105]
name: log [59102,59105]
===
match
---
name: self [45605,45609]
name: self [45605,45609]
===
match
---
suite [71810,71883]
suite [71917,71990]
===
match
---
name: task [62236,62240]
name: task [62236,62240]
===
match
---
trailer [33974,33995]
trailer [33974,33995]
===
match
---
param [23814,23826]
param [23814,23826]
===
match
---
name: end_date [62590,62598]
name: end_date [62590,62598]
===
match
---
operator: = [16078,16079]
operator: = [16078,16079]
===
match
---
dotted_name [1894,1915]
dotted_name [1894,1915]
===
match
---
name: self [52905,52909]
name: self [52905,52909]
===
match
---
simple_stmt [49241,49287]
simple_stmt [49241,49287]
===
match
---
string: "wb" [5072,5076]
string: "wb" [5072,5076]
===
match
---
simple_stmt [3742,3759]
simple_stmt [3742,3759]
===
match
---
return_stmt [74074,74085]
return_stmt [74181,74192]
===
match
---
trailer [74883,74896]
trailer [74990,75003]
===
match
---
name: Optional [74934,74942]
name: Optional [75041,75049]
===
match
---
operator: = [66461,66462]
operator: = [66568,66569]
===
match
---
name: run_id [12867,12873]
name: run_id [12867,12873]
===
match
---
trailer [30091,30096]
trailer [30091,30096]
===
match
---
string: """Returns SQLAlchemy filter to query selected task instances""" [90169,90233]
string: """Returns SQLAlchemy filter to query selected task instances""" [90276,90340]
===
match
---
trailer [37428,37433]
trailer [37428,37433]
===
match
---
name: session [44861,44868]
name: session [44861,44868]
===
match
---
name: task_id [30306,30313]
name: task_id [30306,30313]
===
match
---
name: session [32212,32219]
name: session [32212,32219]
===
match
---
name: get_prev_execution_date [74748,74771]
name: get_prev_execution_date [74855,74878]
===
match
---
simple_stmt [57743,57792]
simple_stmt [57743,57792]
===
match
---
trailer [66258,66274]
trailer [66365,66381]
===
match
---
import_from [901,936]
import_from [901,936]
===
match
---
expr_stmt [64192,64208]
expr_stmt [64192,64208]
===
match
---
name: _defer_task [49728,49739]
name: _defer_task [49728,49739]
===
match
---
trailer [91250,91257]
trailer [91357,91364]
===
match
---
name: self [44751,44755]
name: self [44751,44755]
===
match
---
name: verbose [45574,45581]
name: verbose [45574,45581]
===
match
---
operator: , [57499,57500]
operator: , [57499,57500]
===
match
---
trailer [44830,44854]
trailer [44830,44854]
===
match
---
argument [31048,31063]
argument [31048,31063]
===
match
---
name: Variable [70221,70229]
name: Variable [70328,70336]
===
match
---
name: dr [31758,31760]
name: dr [31758,31760]
===
match
---
trailer [46944,46949]
trailer [46944,46949]
===
match
---
simple_stmt [88432,88453]
simple_stmt [88539,88560]
===
match
---
name: ondelete [13255,13263]
name: ondelete [13255,13263]
===
match
---
operator: , [22305,22306]
operator: , [22305,22306]
===
match
---
name: verbose_aware_logger [36663,36683]
name: verbose_aware_logger [36663,36683]
===
match
---
name: job_id [43321,43327]
name: job_id [43321,43327]
===
match
---
name: Any [3800,3803]
name: Any [3800,3803]
===
match
---
name: NamedTuple [1113,1123]
name: NamedTuple [1113,1123]
===
match
---
atom_expr [52989,53048]
atom_expr [52989,53048]
===
match
---
name: task [27557,27561]
name: task [27557,27561]
===
match
---
trailer [48888,48895]
trailer [48888,48895]
===
match
---
simple_stmt [59894,59911]
simple_stmt [59894,59911]
===
match
---
name: property [92897,92905]
name: property [93004,93012]
===
match
---
name: jobs [8317,8321]
name: jobs [8317,8321]
===
match
---
parameters [4006,4024]
parameters [4006,4024]
===
match
---
name: cmd [22846,22849]
name: cmd [22846,22849]
===
match
---
string: """The DagRun that ran before this task instance's DagRun.          :param state: If passed, it only take into account instances of a specific state.         :param session: SQLAlchemy ORM Session.         """ [30732,30941]
string: """The DagRun that ran before this task instance's DagRun.          :param state: If passed, it only take into account instances of a specific state.         :param session: SQLAlchemy ORM Session.         """ [30732,30941]
===
match
---
trailer [57966,57977]
trailer [57966,57977]
===
match
---
trailer [91109,91117]
trailer [91216,91224]
===
match
---
decorator [28310,28320]
decorator [28310,28320]
===
match
---
decorated [34605,35262]
decorated [34605,35262]
===
match
---
operator: = [36647,36648]
operator: = [36647,36648]
===
match
---
simple_stmt [27492,27531]
simple_stmt [27492,27531]
===
match
---
suite [8767,8802]
suite [8767,8802]
===
match
---
return_stmt [84366,84412]
return_stmt [84473,84519]
===
match
---
expr_stmt [14012,14075]
expr_stmt [14012,14075]
===
match
---
param [70676,70686]
param [70783,70793]
===
match
---
name: IO [4592,4594]
name: IO [4592,4594]
===
match
---
arglist [47020,47072]
arglist [47020,47072]
===
match
---
trailer [67829,67841]
trailer [67936,67948]
===
match
---
operator: = [61345,61346]
operator: = [61345,61346]
===
match
---
suite [52891,54688]
suite [52891,54688]
===
match
---
atom_expr [48884,48895]
atom_expr [48884,48895]
===
match
---
dotted_name [2309,2334]
dotted_name [2309,2334]
===
match
---
decorated [19725,23027]
decorated [19725,23027]
===
match
---
trailer [67922,67929]
trailer [68029,68036]
===
match
---
suite [90870,91070]
suite [90977,91177]
===
match
---
name: state [24476,24481]
name: state [24476,24481]
===
match
---
name: session [32489,32496]
name: session [32489,32496]
===
match
---
trailer [15271,15282]
trailer [15271,15282]
===
match
---
tfpdef [66956,66985]
tfpdef [67063,67092]
===
match
---
name: DagRunState [5472,5483]
name: DagRunState [5472,5483]
===
match
---
trailer [84732,84737]
trailer [84839,84844]
===
match
---
parameters [16626,16632]
parameters [16626,16632]
===
match
---
atom_expr [29475,29485]
atom_expr [29475,29485]
===
match
---
trailer [39164,39171]
trailer [39164,39171]
===
match
---
atom_expr [11478,11497]
atom_expr [11478,11497]
===
match
---
name: self [45693,45697]
name: self [45693,45697]
===
match
---
fstring_string: Accessing  [72200,72210]
fstring_string: Accessing  [72307,72317]
===
match
---
trailer [73957,73962]
trailer [74064,74069]
===
match
---
except_clause [59739,59755]
except_clause [59739,59755]
===
match
---
argument [19383,19416]
argument [19383,19416]
===
match
---
name: Optional [20125,20133]
name: Optional [20125,20133]
===
match
---
string: 'previously_succeeded' [43503,43525]
string: 'previously_succeeded' [43503,43525]
===
match
---
if_stmt [32331,32378]
if_stmt [32331,32378]
===
match
---
suite [92010,93824]
suite [92117,93931]
===
match
---
annassign [92251,92273]
annassign [92358,92380]
===
match
---
operator: , [61030,61031]
operator: , [61030,61031]
===
match
---
name: mark_success [19844,19856]
name: mark_success [19844,19856]
===
match
---
name: render [84299,84305]
name: render [84406,84412]
===
match
---
name: self [47053,47057]
name: self [47053,47057]
===
match
---
name: task_id [14302,14309]
name: task_id [14302,14309]
===
match
---
name: self [80304,80308]
name: self [80411,80415]
===
match
---
fstring_string: &execution_date= [23640,23656]
fstring_string: &execution_date= [23640,23656]
===
match
---
string: """         Immediately runs the task (without checking or changing db state         before execution) and then sets the appropriate final state after         completion and runs any post-execute callbacks. Meant to be called         only after another function changes the state to running.          :param mark_success: Don't run the task, mark its state as success         :type mark_success: bool         :param test_mode: Doesn't record success or failure in the DB         :type test_mode: bool         :param pool: specifies the pool to use to run the task instance         :type pool: str         :param session: SQLAlchemy ORM Session         :type session: Session         """ [48046,48732]
string: """         Immediately runs the task (without checking or changing db state         before execution) and then sets the appropriate final state after         completion and runs any post-execute callbacks. Meant to be called         only after another function changes the state to running.          :param mark_success: Don't run the task, mark its state as success         :type mark_success: bool         :param test_mode: Doesn't record success or failure in the DB         :type test_mode: bool         :param pool: specifies the pool to use to run the task instance         :type pool: str         :param session: SQLAlchemy ORM Session         :type session: Session         """ [48046,48732]
===
match
---
simple_stmt [805,820]
simple_stmt [805,820]
===
match
---
argument [19691,19708]
argument [19691,19708]
===
match
---
arglist [61150,61513]
arglist [61150,61513]
===
match
---
suite [56308,57166]
suite [56308,57166]
===
match
---
atom_expr [64548,64563]
atom_expr [64655,64670]
===
match
---
trailer [44194,44296]
trailer [44194,44296]
===
match
---
dotted_name [8859,8880]
dotted_name [8859,8880]
===
match
---
name: run_id [10392,10398]
name: run_id [10392,10398]
===
match
---
operator: -> [74931,74933]
operator: -> [75038,75040]
===
match
---
parameters [93383,93389]
parameters [93490,93496]
===
match
---
trailer [24298,24306]
trailer [24298,24306]
===
match
---
name: _get_previous_dagrun_success [68466,68494]
name: _get_previous_dagrun_success [68573,68601]
===
match
---
operator: @ [47757,47758]
operator: @ [47757,47758]
===
match
---
name: Optional [34731,34739]
name: Optional [34731,34739]
===
match
---
operator: , [12996,12997]
operator: , [12996,12997]
===
match
---
funcdef [17843,17944]
funcdef [17843,17944]
===
match
---
tfpdef [14178,14198]
tfpdef [14178,14198]
===
match
---
operator: = [20240,20241]
operator: = [20240,20241]
===
match
---
simple_stmt [92686,92730]
simple_stmt [92793,92837]
===
match
---
parameters [19763,20293]
parameters [19763,20293]
===
match
---
name: and_ [90890,90894]
name: and_ [90997,91001]
===
match
---
name: _get_previous_dagrun_data_interval_success [68721,68763]
name: _get_previous_dagrun_data_interval_success [68828,68870]
===
match
---
name: base_job [93952,93960]
name: base_job [94059,94067]
===
match
---
atom_expr [65900,65910]
atom_expr [66007,66017]
===
match
---
atom_expr [13920,14006]
atom_expr [13920,14006]
===
match
---
atom_expr [59511,59535]
atom_expr [59511,59535]
===
match
---
arglist [92749,92770]
arglist [92856,92877]
===
match
---
trailer [91560,91568]
trailer [91667,91675]
===
match
---
atom_expr [74616,74658]
atom_expr [74723,74765]
===
match
---
atom_expr [44718,44735]
atom_expr [44718,44735]
===
match
---
name: association_proxy [1531,1548]
name: association_proxy [1531,1548]
===
match
---
suite [4875,4923]
suite [4875,4923]
===
match
---
parameters [86516,86749]
parameters [86623,86856]
===
match
---
atom_expr [26322,26335]
atom_expr [26322,26335]
===
match
---
operator: , [28249,28250]
operator: , [28249,28250]
===
match
---
name: __getattr__ [69758,69769]
name: __getattr__ [69865,69876]
===
match
---
atom_expr [77838,77858]
atom_expr [77945,77965]
===
match
---
trailer [44883,44885]
trailer [44883,44885]
===
match
---
trailer [44704,44715]
trailer [44704,44715]
===
match
---
trailer [92656,92662]
trailer [92763,92769]
===
match
---
trailer [45623,45628]
trailer [45623,45628]
===
match
---
trailer [63011,63029]
trailer [63011,63029]
===
match
---
name: refresh_from_db [64158,64173]
name: refresh_from_db [64158,64173]
===
match
---
atom_expr [7086,7153]
atom_expr [7086,7153]
===
match
---
name: self [16094,16098]
name: self [16094,16098]
===
match
---
trailer [41564,41569]
trailer [41564,41569]
===
match
---
name: math [38558,38562]
name: math [38558,38562]
===
match
---
trailer [14384,14400]
trailer [14384,14400]
===
match
---
atom_expr [51148,51238]
atom_expr [51148,51238]
===
match
---
string: ' execution_date=%s, start_date=%s, end_date=%s' [47423,47471]
string: ' execution_date=%s, start_date=%s, end_date=%s' [47423,47471]
===
match
---
name: TaskInstanceKey [10344,10359]
name: TaskInstanceKey [10344,10359]
===
match
---
name: get_connection_from_secrets [71573,71600]
name: get_connection_from_secrets [71680,71707]
===
match
---
name: task [64192,64196]
name: task [64192,64196]
===
match
---
name: run_id [28494,28500]
name: run_id [28494,28500]
===
match
---
operator: = [90440,90441]
operator: = [90547,90548]
===
match
---
name: self [56046,56050]
name: self [56046,56050]
===
match
---
name: dag_run_state [9485,9498]
name: dag_run_state [9485,9498]
===
match
---
name: tuple_ [91719,91725]
name: tuple_ [91826,91832]
===
match
---
operator: = [67700,67701]
operator: = [67807,67808]
===
match
---
string: "Rescheduling due to concurrency limits reached " [45731,45780]
string: "Rescheduling due to concurrency limits reached " [45731,45780]
===
match
---
trailer [46381,46393]
trailer [46381,46393]
===
match
---
and_test [18789,18810]
and_test [18789,18810]
===
match
---
trailer [66123,66129]
trailer [66230,66236]
===
match
---
name: in_ [91258,91261]
name: in_ [91365,91368]
===
match
---
trailer [68932,68951]
trailer [69039,69058]
===
match
---
name: property [32979,32987]
name: property [32979,32987]
===
match
---
simple_stmt [52330,52363]
simple_stmt [52330,52363]
===
match
---
atom_expr [23176,23209]
atom_expr [23176,23209]
===
match
---
trailer [34566,34575]
trailer [34566,34575]
===
match
---
operator: = [60695,60696]
operator: = [60695,60696]
===
match
---
name: self [43129,43133]
name: self [43129,43133]
===
match
---
string: """         Marks the task as deferred and sets up the trigger that is needed         to resume it.         """ [57531,57642]
string: """         Marks the task as deferred and sets up the trigger that is needed         to resume it.         """ [57531,57642]
===
match
---
trailer [49790,49795]
trailer [49790,49795]
===
match
---
suite [36828,37073]
suite [36828,37073]
===
match
---
operator: = [61194,61195]
operator: = [61194,61195]
===
match
---
operator: <= [66877,66879]
operator: <= [66984,66986]
===
match
---
name: self [24810,24814]
name: self [24810,24814]
===
match
---
trailer [76622,76664]
trailer [76729,76771]
===
match
---
simple_stmt [14355,14401]
simple_stmt [14355,14401]
===
match
---
simple_stmt [11896,11924]
simple_stmt [11896,11924]
===
match
---
operator: , [1377,1378]
operator: , [1377,1378]
===
match
---
if_stmt [62505,62538]
if_stmt [62505,62538]
===
match
---
operator: = [59484,59485]
operator: = [59484,59485]
===
match
---
atom_expr [80593,80605]
atom_expr [80700,80712]
===
match
---
operator: = [43350,43351]
operator: = [43350,43351]
===
match
---
name: start_date [11465,11475]
name: start_date [11465,11475]
===
match
---
name: property [28311,28319]
name: property [28311,28319]
===
match
---
parameters [92920,92926]
parameters [93027,93033]
===
match
---
string: '%sMarking task as %s.' [47345,47368]
string: '%sMarking task as %s.' [47345,47368]
===
match
---
trailer [88990,89000]
trailer [89097,89107]
===
match
---
operator: , [23196,23197]
operator: , [23196,23197]
===
match
---
name: Exception [60532,60541]
name: Exception [60532,60541]
===
match
---
atom_expr [46438,46475]
atom_expr [46438,46475]
===
match
---
not_test [18789,18802]
not_test [18789,18802]
===
match
---
name: refresh_from_task [43152,43169]
name: refresh_from_task [43152,43169]
===
match
---
name: dag [31761,31764]
name: dag [31761,31764]
===
match
---
expr_stmt [60407,60435]
expr_stmt [60407,60435]
===
match
---
string: "Unknown" [55908,55917]
string: "Unknown" [55908,55917]
===
match
---
return_stmt [72512,72525]
return_stmt [72619,72632]
===
match
---
name: State [30444,30449]
name: State [30444,30449]
===
match
---
trailer [32291,32321]
trailer [32291,32321]
===
match
---
trailer [63512,63517]
trailer [63512,63517]
===
match
---
simple_stmt [4383,4566]
simple_stmt [4383,4566]
===
match
---
name: task_id [92986,92993]
name: task_id [93093,93100]
===
match
---
simple_stmt [37193,37205]
simple_stmt [37193,37205]
===
match
---
trailer [23128,23143]
trailer [23128,23143]
===
match
---
arglist [91191,91340]
arglist [91298,91447]
===
match
---
operator: = [14199,14200]
operator: = [14199,14200]
===
match
---
fstring_string: . [51981,51982]
fstring_string: . [51981,51982]
===
match
---
name: pickler [12141,12148]
name: pickler [12141,12148]
===
match
---
string: """         Make an XCom available for tasks to pull.          :param key: A key for the XCom         :type key: str         :param value: A value for the XCom. The value is pickled and stored             in the database.         :type value: any picklable object         :param execution_date: if provided, the XCom will not be visible until             this date. This can be used, for example, to send a message to a             task on a future date without it being immediately visible.         :type execution_date: datetime         :param session: Sqlalchemy ORM Session         :type session: Session         """ [85275,85895]
string: """         Make an XCom available for tasks to pull.          :param key: A key for the XCom         :type key: str         :param value: A value for the XCom. The value is pickled and stored             in the database.         :type value: any picklable object         :param execution_date: if provided, the XCom will not be visible until             this date. This can be used, for example, to send a message to a             task on a future date without it being immediately visible.         :type execution_date: datetime         :param session: Sqlalchemy ORM Session         :type session: Session         """ [85382,86002]
===
match
---
operator: , [88613,88614]
operator: , [88720,88721]
===
match
---
number: 2 [8721,8722]
number: 2 [8721,8722]
===
match
---
trailer [92183,92190]
trailer [92290,92297]
===
match
---
dotted_name [80376,80422]
dotted_name [80483,80529]
===
match
---
atom_expr [8064,8079]
atom_expr [8064,8079]
===
match
---
trailer [54984,54995]
trailer [54984,54995]
===
match
---
operator: , [91339,91340]
operator: , [91446,91447]
===
match
---
name: incr [64357,64361]
name: incr [64357,64361]
===
match
---
simple_stmt [84989,85010]
simple_stmt [85096,85117]
===
match
---
name: session [50645,50652]
name: session [50645,50652]
===
match
---
parameters [40169,40175]
parameters [40169,40175]
===
match
---
name: execution_timeout [56542,56559]
name: execution_timeout [56542,56559]
===
match
---
atom_expr [56458,56474]
atom_expr [56458,56474]
===
match
---
name: executor_config [26765,26780]
name: executor_config [26765,26780]
===
match
---
atom_expr [68924,68951]
atom_expr [69031,69058]
===
match
---
suite [33534,33996]
suite [33534,33996]
===
match
---
name: self [40907,40911]
name: self [40907,40911]
===
match
---
string: "Task failed with exception" [63777,63805]
string: "Task failed with exception" [63777,63805]
===
match
---
atom_expr [75848,76014]
atom_expr [75955,76121]
===
match
---
simple_stmt [89622,89897]
simple_stmt [89729,90004]
===
match
---
name: State [45618,45623]
name: State [45618,45623]
===
match
---
name: html_content [84665,84677]
name: html_content [84772,84784]
===
match
---
operator: , [18163,18164]
operator: , [18163,18164]
===
match
---
name: execution_date [46956,46970]
name: execution_date [46956,46970]
===
match
---
atom_expr [57201,57234]
atom_expr [57201,57234]
===
match
---
atom_expr [39197,39208]
atom_expr [39197,39208]
===
match
---
expr_stmt [32793,32850]
expr_stmt [32793,32850]
===
match
---
suite [4249,4272]
suite [4249,4272]
===
match
---
trailer [25716,25730]
trailer [25716,25730]
===
match
---
fstring_expr [23294,23307]
fstring_expr [23294,23307]
===
match
---
operator: , [48021,48022]
operator: , [48021,48022]
===
match
---
operator: , [1123,1124]
operator: , [1123,1124]
===
match
---
name: attrs [40666,40671]
name: attrs [40666,40671]
===
match
---
name: self_execution_date [85904,85923]
name: self_execution_date [86011,86030]
===
match
---
name: reschedule_exception [50738,50758]
name: reschedule_exception [50738,50758]
===
match
---
name: self [35313,35317]
name: self [35313,35317]
===
match
---
name: instance [9025,9033]
name: instance [9025,9033]
===
match
---
simple_stmt [2979,3014]
simple_stmt [2979,3014]
===
match
---
simple_stmt [3161,3204]
simple_stmt [3161,3204]
===
match
---
name: self [70654,70658]
name: self [70761,70765]
===
match
---
name: Optional [35322,35330]
name: Optional [35322,35330]
===
match
---
annassign [92535,92557]
annassign [92642,92664]
===
match
---
string: "Updating task params (%s) with DagRun.conf (%s)" [79906,79955]
string: "Updating task params (%s) with DagRun.conf (%s)" [80013,80062]
===
match
---
name: execution_date [14933,14947]
name: execution_date [14933,14947]
===
match
---
simple_stmt [26322,26350]
simple_stmt [26322,26350]
===
match
---
trailer [26366,26373]
trailer [26366,26373]
===
match
---
expr_stmt [43336,43366]
expr_stmt [43336,43366]
===
match
---
name: logging_mixin [3127,3140]
name: logging_mixin [3127,3140]
===
match
---
string: 'execution_date' [49993,50009]
string: 'execution_date' [49993,50009]
===
match
---
name: State [57939,57944]
name: State [57939,57944]
===
match
---
name: NONE [6999,7003]
name: NONE [6999,7003]
===
match
---
name: local [20044,20049]
name: local [20044,20049]
===
match
---
expr_stmt [92609,92643]
expr_stmt [92716,92750]
===
match
---
simple_stmt [45645,45677]
simple_stmt [45645,45677]
===
match
---
name: self [58644,58648]
name: self [58644,58648]
===
match
---
trailer [50884,50891]
trailer [50884,50891]
===
match
---
atom_expr [3849,3876]
atom_expr [3849,3876]
===
match
---
name: run_as_user [27663,27674]
name: run_as_user [27663,27674]
===
match
---
operator: = [89213,89214]
operator: = [89320,89321]
===
match
---
name: provide_session [34606,34621]
name: provide_session [34606,34621]
===
match
---
name: taskfail [2452,2460]
name: taskfail [2452,2460]
===
match
---
comparison [65525,65551]
comparison [65632,65658]
===
match
---
name: session [88739,88746]
name: session [88846,88853]
===
match
---
name: self [26479,26483]
name: self [26479,26483]
===
match
---
operator: = [79488,79489]
operator: = [79595,79596]
===
match
---
trailer [16098,16107]
trailer [16098,16107]
===
match
---
atom_expr [62036,62076]
atom_expr [62036,62076]
===
match
---
simple_stmt [46215,46244]
simple_stmt [46215,46244]
===
match
---
name: self [86359,86363]
name: self [86466,86470]
===
match
---
atom_expr [35331,35348]
atom_expr [35331,35348]
===
match
---
name: task [67200,67204]
name: task [67307,67311]
===
match
---
atom_expr [75453,75644]
atom_expr [75560,75751]
===
match
---
simple_stmt [32910,32973]
simple_stmt [32910,32973]
===
match
---
argument [53605,53620]
argument [53605,53620]
===
match
---
param [19794,19807]
param [19794,19807]
===
match
---
funcdef [93213,93275]
funcdef [93320,93382]
===
match
---
simple_stmt [37344,37386]
simple_stmt [37344,37386]
===
match
---
atom_expr [59867,59880]
atom_expr [59867,59880]
===
match
---
trailer [64520,64579]
trailer [64624,64686]
===
match
---
name: iso [23259,23262]
name: iso [23259,23262]
===
match
---
trailer [45701,45709]
trailer [45701,45709]
===
match
---
name: property [93200,93208]
name: property [93307,93315]
===
match
---
name: _handle_reschedule [62344,62362]
name: _handle_reschedule [62344,62362]
===
match
---
dotted_name [79241,79272]
dotted_name [79348,79379]
===
match
---
atom_expr [92836,92847]
atom_expr [92943,92954]
===
match
---
operator: , [86279,86280]
operator: , [86386,86387]
===
match
---
parameters [24545,24565]
parameters [24545,24565]
===
match
---
name: dag_id [23617,23623]
name: dag_id [23617,23623]
===
match
---
name: self [50307,50311]
name: self [50307,50311]
===
match
---
name: from_string [83352,83363]
name: from_string [83459,83470]
===
match
---
tfpdef [34077,34097]
tfpdef [34077,34097]
===
match
---
name: job_id [61767,61773]
name: job_id [61767,61773]
===
match
---
operator: , [54929,54930]
operator: , [54929,54930]
===
match
---
trailer [46074,46076]
trailer [46074,46076]
===
match
---
trailer [49795,50076]
trailer [49795,50076]
===
match
---
trailer [31585,31594]
trailer [31585,31594]
===
match
---
suite [74812,74841]
suite [74919,74948]
===
match
---
operator: = [11767,11768]
operator: = [11767,11768]
===
match
---
name: self [14318,14322]
name: self [14318,14322]
===
match
---
operator: = [66310,66311]
operator: = [66417,66418]
===
match
---
import_from [8854,8894]
import_from [8854,8894]
===
match
---
trailer [37666,37675]
trailer [37666,37675]
===
match
---
trailer [25945,25954]
trailer [25945,25954]
===
match
---
name: next_method [58008,58019]
name: next_method [58008,58019]
===
match
---
name: context [52935,52942]
name: context [52935,52942]
===
match
---
name: ignore_depends_on_past [19430,19452]
name: ignore_depends_on_past [19430,19452]
===
match
---
trailer [29494,29507]
trailer [29494,29507]
===
match
---
name: ExtendedJSON [3417,3429]
name: ExtendedJSON [3417,3429]
===
match
---
expr_stmt [67151,67179]
expr_stmt [67258,67286]
===
match
---
name: session [85227,85234]
name: session [85334,85341]
===
match
---
atom_expr [91191,91210]
atom_expr [91298,91317]
===
match
---
name: hostname [48918,48926]
name: hostname [48918,48926]
===
match
---
atom_expr [71136,71202]
atom_expr [71243,71309]
===
match
---
name: self [78360,78364]
name: self [78467,78471]
===
match
---
name: self [64565,64569]
name: self [64672,64676]
===
match
---
dotted_name [2765,2792]
dotted_name [2765,2792]
===
match
---
fstring_expr [52860,52879]
fstring_expr [52860,52879]
===
match
---
return_stmt [75033,75044]
return_stmt [75140,75151]
===
match
---
trailer [57141,57143]
trailer [57141,57143]
===
match
---
trailer [36888,37072]
trailer [36888,37072]
===
match
---
name: context [49420,49427]
name: context [49420,49427]
===
match
---
name: session [62567,62574]
name: session [62567,62574]
===
match
---
arglist [84150,84185]
arglist [84257,84292]
===
match
---
simple_stmt [8440,8469]
simple_stmt [8440,8469]
===
match
---
trailer [58648,58664]
trailer [58648,58664]
===
match
---
argument [53025,53047]
argument [53025,53047]
===
match
---
name: state [34669,34674]
name: state [34669,34674]
===
match
---
atom_expr [90514,90520]
atom_expr [90621,90627]
===
match
---
name: debug [36725,36730]
name: debug [36725,36730]
===
match
---
simple_stmt [26240,26270]
simple_stmt [26240,26270]
===
match
---
name: get_task [6421,6429]
name: get_task [6421,6429]
===
match
---
name: params [76281,76287]
name: params [76388,76394]
===
match
---
name: log [66020,66023]
name: log [66127,66130]
===
match
---
atom_expr [57962,57977]
atom_expr [57962,57977]
===
match
---
operator: , [71722,71723]
operator: , [71829,71830]
===
match
---
name: base_url [23514,23522]
name: base_url [23514,23522]
===
match
---
operator: < [40383,40384]
operator: < [40383,40384]
===
match
---
name: ApiClient [3587,3596]
name: ApiClient [3587,3596]
===
match
---
suite [60126,60210]
suite [60126,60210]
===
match
---
operator: , [84743,84744]
operator: , [84850,84851]
===
match
---
name: XCOM_RETURN_KEY [2611,2626]
name: XCOM_RETURN_KEY [2611,2626]
===
match
---
name: state [34501,34506]
name: state [34501,34506]
===
match
---
simple_stmt [65798,65869]
simple_stmt [65905,65976]
===
match
---
name: SUCCESS [68332,68339]
name: SUCCESS [68439,68446]
===
match
---
if_stmt [46861,47074]
if_stmt [46861,47074]
===
match
---
arglist [23474,23497]
arglist [23474,23497]
===
match
---
simple_stmt [53220,53300]
simple_stmt [53220,53300]
===
match
---
name: try_number [17210,17220]
name: try_number [17210,17220]
===
match
---
name: exception [66024,66033]
name: exception [66131,66140]
===
match
---
simple_stmt [18485,18515]
simple_stmt [18485,18515]
===
match
---
simple_stmt [3760,3780]
simple_stmt [3760,3780]
===
match
---
operator: , [37714,37715]
operator: , [37714,37715]
===
match
---
name: self [89731,89735]
name: self [89838,89842]
===
match
---
trailer [88494,88503]
trailer [88601,88610]
===
match
---
parameters [84793,84799]
parameters [84900,84906]
===
match
---
simple_stmt [60407,60436]
simple_stmt [60407,60436]
===
match
---
name: pickle_id [18173,18182]
name: pickle_id [18173,18182]
===
match
---
tfpdef [60982,61001]
tfpdef [60982,61001]
===
match
---
name: add [50131,50134]
name: add [50131,50134]
===
match
---
atom_expr [70859,70872]
atom_expr [70966,70979]
===
match
---
import_from [1487,1548]
import_from [1487,1548]
===
match
---
name: state [35076,35081]
name: state [35076,35081]
===
match
---
name: get_many [88541,88549]
name: get_many [88648,88656]
===
match
---
operator: - [83681,83682]
operator: - [83788,83789]
===
match
---
suite [92934,92963]
suite [93041,93070]
===
match
---
operator: , [24358,24359]
operator: , [24358,24359]
===
match
---
expr_stmt [58363,58390]
expr_stmt [58363,58390]
===
match
---
name: result [57026,57032]
name: result [57026,57032]
===
match
---
name: run_id [37945,37951]
name: run_id [37945,37951]
===
match
---
simple_stmt [57531,57643]
simple_stmt [57531,57643]
===
match
---
operator: , [13702,13703]
operator: , [13702,13703]
===
match
---
string: "Starting attempt %s of %s" [46266,46293]
string: "Starting attempt %s of %s" [46266,46293]
===
match
---
name: self [93309,93313]
name: self [93416,93420]
===
match
---
name: bool [66338,66342]
name: bool [66445,66449]
===
match
---
trailer [25903,25914]
trailer [25903,25914]
===
match
---
return_stmt [93475,93492]
return_stmt [93582,93599]
===
match
---
name: replacement [75596,75607]
name: replacement [75703,75714]
===
match
---
import_from [3104,3160]
import_from [3104,3160]
===
match
---
atom_expr [5435,5469]
atom_expr [5435,5469]
===
match
---
arith_expr [72895,72929]
arith_expr [73002,73036]
===
match
---
string: """Only Renders Templates for the TI""" [62109,62148]
string: """Only Renders Templates for the TI""" [62109,62148]
===
match
---
operator: , [19324,19325]
operator: , [19324,19325]
===
match
---
name: self [27435,27439]
name: self [27435,27439]
===
match
---
name: state [43456,43461]
name: state [43456,43461]
===
match
---
name: session [24872,24879]
name: session [24872,24879]
===
match
---
atom_expr [80233,80274]
atom_expr [80340,80381]
===
match
---
if_stmt [14930,15492]
if_stmt [14930,15492]
===
match
---
param [34663,34668]
param [34663,34668]
===
match
---
trailer [7066,7072]
trailer [7066,7072]
===
match
---
atom_expr [8440,8449]
atom_expr [8440,8449]
===
match
---
name: self [36757,36761]
name: self [36757,36761]
===
match
---
arglist [12890,12907]
arglist [12890,12907]
===
match
---
operator: == [90823,90825]
operator: == [90930,90932]
===
match
---
trailer [74982,74984]
trailer [75089,75091]
===
match
---
name: renderedtifields [78220,78236]
name: renderedtifields [78327,78343]
===
match
---
name: mark_success [17992,18004]
name: mark_success [17992,18004]
===
match
---
name: error [5312,5317]
name: error [5312,5317]
===
match
---
arglist [75751,75815]
arglist [75858,75922]
===
match
---
decorator [71620,71634]
decorator [71727,71741]
===
match
---
name: pid [26714,26717]
name: pid [26714,26717]
===
match
---
name: orm [1688,1691]
name: orm [1688,1691]
===
match
---
suite [69063,69092]
suite [69170,69199]
===
match
---
name: logging [14367,14374]
name: logging [14367,14374]
===
match
---
annassign [92298,92324]
annassign [92405,92431]
===
match
---
name: pre_execute [53593,53604]
name: pre_execute [53593,53604]
===
match
---
suite [78586,79102]
suite [78693,79209]
===
match
---
simple_stmt [26479,26501]
simple_stmt [26479,26501]
===
match
---
operator: , [48808,48809]
operator: , [48808,48809]
===
match
---
operator: = [35757,35758]
operator: = [35757,35758]
===
match
---
operator: , [47040,47041]
operator: , [47040,47041]
===
match
---
param [24546,24551]
param [24546,24551]
===
match
---
atom_expr [77511,77577]
atom_expr [77618,77684]
===
match
---
name: try_number [39250,39260]
name: try_number [39250,39260]
===
match
---
param [28559,28564]
param [28559,28564]
===
match
---
suite [50577,50654]
suite [50577,50654]
===
match
---
argument [83397,83412]
argument [83504,83519]
===
match
---
name: next_retry_datetime [37979,37998]
name: next_retry_datetime [37979,37998]
===
match
---
name: pool_slots [27544,27554]
name: pool_slots [27544,27554]
===
match
---
name: start_date [69366,69376]
name: start_date [69473,69483]
===
match
---
param [32489,32512]
param [32489,32512]
===
match
---
trailer [45709,45975]
trailer [45709,45975]
===
match
---
string: 'execution_date can not be in the past (current ' [86080,86129]
string: 'execution_date can not be in the past (current ' [86187,86236]
===
match
---
name: timezone [73873,73881]
name: timezone [73980,73988]
===
match
---
name: dialect [91389,91396]
name: dialect [91496,91503]
===
match
---
trailer [91084,91148]
trailer [91191,91255]
===
match
---
arglist [70742,70769]
arglist [70849,70876]
===
match
---
exprlist [7926,7946]
exprlist [7926,7946]
===
match
---
argument [88686,88725]
argument [88793,88832]
===
match
---
string: 'ti_state' [12890,12900]
string: 'ti_state' [12890,12900]
===
match
---
expr_stmt [64700,64723]
expr_stmt [64807,64830]
===
match
---
operator: = [57199,57200]
operator: = [57199,57200]
===
match
---
trailer [80564,80571]
trailer [80671,80678]
===
match
---
name: start_date [25904,25914]
name: start_date [25904,25914]
===
match
---
operator: , [47814,47815]
operator: , [47814,47815]
===
match
---
simple_stmt [54697,54759]
simple_stmt [54697,54759]
===
match
---
name: dag_id [28467,28473]
name: dag_id [28467,28473]
===
match
---
name: merge [50182,50187]
name: merge [50182,50187]
===
match
---
operator: = [11384,11385]
operator: = [11384,11385]
===
match
---
operator: -> [93073,93075]
operator: -> [93180,93182]
===
match
---
operator: , [71522,71523]
operator: , [71629,71630]
===
match
---
simple_stmt [40751,40817]
simple_stmt [40751,40817]
===
match
---
atom_expr [6275,6300]
atom_expr [6275,6300]
===
match
---
expr_stmt [11465,11497]
expr_stmt [11465,11497]
===
match
---
name: RenderedTaskInstanceFields [53062,53088]
name: RenderedTaskInstanceFields [53062,53088]
===
match
---
operator: , [19806,19807]
operator: , [19806,19807]
===
match
---
name: self [59777,59781]
name: self [59777,59781]
===
match
---
name: airflow [2699,2706]
name: airflow [2699,2706]
===
match
---
operator: , [47493,47494]
operator: , [47493,47494]
===
match
---
trailer [57930,57936]
trailer [57930,57936]
===
match
---
if_stmt [66638,66823]
if_stmt [66745,66930]
===
match
---
comparison [63624,63641]
comparison [63624,63641]
===
match
---
name: var [70597,70600]
name: var [70704,70707]
===
match
---
atom_expr [84561,84602]
atom_expr [84668,84709]
===
match
---
name: airflow [3385,3392]
name: airflow [3385,3392]
===
match
---
name: execution_date [14432,14446]
name: execution_date [14432,14446]
===
match
---
string: "data_interval_end | ds_nodash" [75968,75999]
string: "data_interval_end | ds_nodash" [76075,76106]
===
match
---
arglist [34501,34529]
arglist [34501,34529]
===
match
---
name: get_yesterday_ds_nodash [72732,72755]
name: get_yesterday_ds_nodash [72839,72862]
===
match
---
trailer [60280,60285]
trailer [60280,60285]
===
match
---
name: error [4961,4966]
name: error [4961,4966]
===
match
---
trailer [39969,40003]
trailer [39969,40003]
===
match
---
name: Optional [32467,32475]
name: Optional [32467,32475]
===
match
---
suite [83906,84042]
suite [84013,84149]
===
match
---
name: self [77241,77245]
name: self [77348,77352]
===
match
---
name: task [47047,47051]
name: task [47047,47051]
===
match
---
name: dag_id [39202,39208]
name: dag_id [39202,39208]
===
match
---
trailer [26215,26227]
trailer [26215,26227]
===
match
---
name: func [72055,72059]
name: func [72162,72166]
===
match
---
trailer [7960,7966]
trailer [7960,7966]
===
match
---
simple_stmt [62689,62964]
simple_stmt [62689,62964]
===
match
---
trailer [11775,11784]
trailer [11775,11784]
===
match
---
name: start_date [25888,25898]
name: start_date [25888,25898]
===
match
---
decorator [34605,34622]
decorator [34605,34622]
===
match
---
trailer [31594,31615]
trailer [31594,31615]
===
match
---
name: self [46312,46316]
name: self [46312,46316]
===
match
---
fstring_expr [37954,37966]
fstring_expr [37954,37966]
===
match
---
trailer [81051,81074]
trailer [81158,81181]
===
match
---
name: test_mode [43221,43230]
name: test_mode [43221,43230]
===
match
---
trailer [50143,50149]
trailer [50143,50149]
===
match
---
name: pool_override [48810,48823]
name: pool_override [48810,48823]
===
match
---
atom_expr [67521,67532]
atom_expr [67628,67639]
===
match
---
name: self [84897,84901]
name: self [85004,85008]
===
match
---
expr_stmt [72166,72333]
expr_stmt [72273,72440]
===
match
---
decorator [92896,92906]
decorator [93003,93013]
===
match
---
name: XCom [89153,89157]
name: XCom [89260,89264]
===
match
---
expr_stmt [54980,55015]
expr_stmt [54980,55015]
===
match
---
atom_expr [5110,5132]
atom_expr [5110,5132]
===
match
---
funcdef [89474,89897]
funcdef [89581,90004]
===
match
---
name: tis [90447,90450]
name: tis [90554,90557]
===
match
---
simple_stmt [27721,27765]
simple_stmt [27721,27765]
===
match
---
atom_expr [28821,28838]
atom_expr [28821,28838]
===
match
---
argument [61760,61773]
argument [61760,61773]
===
match
---
suite [83856,84120]
suite [83963,84227]
===
match
---
decorated [92896,92963]
decorated [93003,93070]
===
match
---
name: TR [3760,3762]
name: TR [3760,3762]
===
match
---
atom_expr [65474,65495]
atom_expr [65581,65602]
===
match
---
name: property [93747,93755]
name: property [93854,93862]
===
match
---
trailer [64511,64580]
trailer [64615,64687]
===
match
---
decorated [33462,33996]
decorated [33462,33996]
===
match
---
if_stmt [55755,55920]
if_stmt [55755,55920]
===
match
---
operator: -> [72634,72636]
operator: -> [72741,72743]
===
match
---
operator: , [30343,30344]
operator: , [30343,30344]
===
match
---
name: dagrun [32917,32923]
name: dagrun [32917,32923]
===
match
---
name: self [56458,56462]
name: self [56458,56462]
===
match
---
atom_expr [49914,49925]
atom_expr [49914,49925]
===
match
---
operator: == [6009,6011]
operator: == [6009,6011]
===
match
---
name: test_mode [63655,63664]
name: test_mode [63655,63664]
===
match
---
trailer [63776,63822]
trailer [63776,63822]
===
match
---
name: get_template_context [83462,83482]
name: get_template_context [83569,83589]
===
match
---
name: _start_date [93182,93193]
name: _start_date [93289,93300]
===
match
---
arglist [72467,72494]
arglist [72574,72601]
===
match
---
trailer [89223,89227]
trailer [89330,89334]
===
match
---
trailer [40323,40329]
trailer [40323,40329]
===
match
---
operator: = [26446,26447]
operator: = [26446,26447]
===
match
---
operator: , [91976,91977]
operator: , [92083,92084]
===
match
---
name: __init__ [69693,69701]
name: __init__ [69800,69808]
===
match
---
fstring_string: &dag_id= [23603,23611]
fstring_string: &dag_id= [23603,23611]
===
match
---
simple_stmt [11724,11756]
simple_stmt [11724,11756]
===
match
---
name: self [69904,69908]
name: self [70011,70015]
===
match
---
operator: = [29602,29603]
operator: = [29602,29603]
===
match
---
trailer [46260,46265]
trailer [46260,46265]
===
match
---
simple_stmt [12105,12156]
simple_stmt [12105,12156]
===
match
---
expr_stmt [80186,80223]
expr_stmt [80293,80330]
===
match
---
name: timezone [62601,62609]
name: timezone [62601,62609]
===
match
---
name: TaskReschedule [62714,62728]
name: TaskReschedule [62714,62728]
===
match
---
arglist [36786,36826]
arglist [36786,36826]
===
match
---
name: res [61086,61089]
name: res [61086,61089]
===
match
---
arglist [79380,79401]
arglist [79487,79508]
===
match
---
decorator [70886,70900]
decorator [70993,71007]
===
match
---
trailer [13314,13484]
trailer [13314,13484]
===
match
---
name: and_ [91169,91173]
name: and_ [91276,91280]
===
match
---
arglist [68320,68356]
arglist [68427,68463]
===
match
---
parameters [89508,89523]
parameters [89615,89630]
===
match
---
trailer [24857,24863]
trailer [24857,24863]
===
match
---
string: 'Exception:<br>Failed attempt to attach error logs<br>' [82260,82315]
string: 'Exception:<br>Failed attempt to attach error logs<br>' [82367,82422]
===
match
---
operator: , [55240,55241]
operator: , [55240,55241]
===
match
---
suite [54873,55204]
suite [54873,55204]
===
match
---
name: run_id [15763,15769]
name: run_id [15763,15769]
===
match
---
string: 'Log: <a href="{{ti.log_url}}">Link</a><br>' [82328,82372]
string: 'Log: <a href="{{ti.log_url}}">Link</a><br>' [82435,82479]
===
match
---
name: self [47042,47046]
name: self [47042,47046]
===
match
---
atom_expr [12085,12100]
atom_expr [12085,12100]
===
match
---
simple_stmt [35045,35106]
simple_stmt [35045,35106]
===
match
---
name: airflow [52376,52383]
name: airflow [52376,52383]
===
match
---
name: session [51827,51834]
name: session [51827,51834]
===
match
---
string: "ignore" [73666,73674]
string: "ignore" [73773,73781]
===
match
---
name: Union [63385,63390]
name: Union [63385,63390]
===
match
---
operator: -= [58175,58177]
operator: -= [58175,58177]
===
match
---
name: get_task_instance [32924,32941]
name: get_task_instance [32924,32941]
===
match
---
simple_stmt [85904,85966]
simple_stmt [86011,86073]
===
match
---
trailer [71600,71606]
trailer [71707,71713]
===
match
---
atom_expr [89731,89742]
atom_expr [89838,89849]
===
match
---
name: self [92282,92286]
name: self [92389,92393]
===
match
---
operator: , [77942,77943]
operator: , [78049,78050]
===
match
---
trailer [68672,68691]
trailer [68779,68798]
===
match
---
name: _dag_id [92166,92173]
name: _dag_id [92273,92280]
===
match
---
comparison [91302,91339]
comparison [91409,91446]
===
match
---
name: ti [30172,30174]
name: ti [30172,30174]
===
match
---
name: default [11865,11872]
name: default [11865,11872]
===
match
---
expr_stmt [24430,24449]
expr_stmt [24430,24449]
===
match
---
param [35911,35924]
param [35911,35924]
===
match
---
operator: = [64749,64750]
operator: = [64856,64857]
===
match
---
trailer [15592,15598]
trailer [15592,15598]
===
match
---
operator: @ [29544,29545]
operator: @ [29544,29545]
===
match
---
name: exception [83572,83581]
name: exception [83679,83688]
===
match
---
simple_stmt [22789,22818]
simple_stmt [22789,22818]
===
match
---
trailer [11741,11755]
trailer [11741,11755]
===
match
---
expr_stmt [46484,46510]
expr_stmt [46484,46510]
===
match
---
tfpdef [20155,20164]
tfpdef [20155,20164]
===
match
---
name: cfg_path [18256,18264]
name: cfg_path [18256,18264]
===
match
---
operator: = [57413,57414]
operator: = [57413,57414]
===
match
---
name: params [67932,67938]
name: params [68039,68045]
===
match
---
operator: @ [17273,17274]
operator: @ [17273,17274]
===
match
---
simple_stmt [9436,9470]
simple_stmt [9436,9470]
===
match
---
string: "__fail__" [55778,55788]
string: "__fail__" [55778,55788]
===
match
---
operator: = [30485,30486]
operator: = [30485,30486]
===
match
---
string: "Exporting the following env vars:\n%s" [53343,53382]
string: "Exporting the following env vars:\n%s" [53343,53382]
===
match
---
operator: = [14027,14028]
operator: = [14027,14028]
===
match
---
name: deserialize_value [89063,89080]
name: deserialize_value [89170,89187]
===
match
---
trailer [22365,22392]
trailer [22365,22392]
===
match
---
name: self [56160,56164]
name: self [56160,56164]
===
match
---
suite [67005,78059]
suite [67112,78166]
===
match
---
name: pool [48824,48828]
name: pool [48824,48828]
===
match
---
atom_expr [26513,26533]
atom_expr [26513,26533]
===
match
---
number: 0 [11649,11650]
number: 0 [11649,11650]
===
match
---
name: force_fail [66462,66472]
name: force_fail [66569,66579]
===
match
---
operator: + [47421,47422]
operator: + [47421,47422]
===
match
---
atom_expr [4592,4601]
atom_expr [4592,4601]
===
match
---
name: self [24347,24351]
name: self [24347,24351]
===
match
---
name: task_copy [55556,55565]
name: task_copy [55556,55565]
===
match
---
param [70074,70133]
param [70181,70240]
===
match
---
trailer [52091,52102]
trailer [52091,52102]
===
match
---
operator: @ [17829,17830]
operator: @ [17829,17830]
===
match
---
trailer [47523,47525]
trailer [47523,47525]
===
match
---
tfpdef [32489,32505]
tfpdef [32489,32505]
===
match
---
parameters [71653,71737]
parameters [71760,71844]
===
match
---
atom_expr [14318,14346]
atom_expr [14318,14346]
===
match
---
trailer [4847,4853]
trailer [4847,4853]
===
match
---
not_test [44165,44296]
not_test [44165,44296]
===
match
---
name: test_mode [66093,66102]
name: test_mode [66200,66209]
===
match
---
atom_expr [92609,92626]
atom_expr [92716,92733]
===
match
---
operator: , [11425,11426]
operator: , [11425,11426]
===
match
---
if_stmt [25672,25806]
if_stmt [25672,25806]
===
match
---
trailer [25754,25760]
trailer [25754,25760]
===
match
---
parameters [5350,5493]
parameters [5350,5493]
===
match
---
name: dagrun [68512,68518]
name: dagrun [68619,68625]
===
match
---
atom_expr [22379,22390]
atom_expr [22379,22390]
===
match
---
name: exception [81579,81588]
name: exception [81686,81695]
===
match
---
name: default_conn [71959,71971]
name: default_conn [72066,72078]
===
match
---
not_test [48986,48999]
not_test [48986,48999]
===
match
---
name: get [70026,70029]
name: get [70133,70136]
===
match
---
name: defaultdict [8949,8960]
name: defaultdict [8949,8960]
===
match
---
operator: , [14673,14674]
operator: , [14673,14674]
===
match
---
suite [49458,49535]
suite [49458,49535]
===
match
---
operator: , [18187,18188]
operator: , [18187,18188]
===
match
---
if_stmt [22189,22249]
if_stmt [22189,22249]
===
match
---
suite [72765,72821]
suite [72872,72928]
===
match
---
operator: = [11572,11573]
operator: = [11572,11573]
===
match
---
param [55233,55241]
param [55233,55241]
===
match
---
atom_expr [9399,9407]
atom_expr [9399,9407]
===
match
---
trailer [66843,66848]
trailer [66950,66955]
===
match
---
expr_stmt [67801,67841]
expr_stmt [67908,67948]
===
match
---
argument [45277,45308]
argument [45277,45308]
===
match
---
operator: , [13054,13055]
operator: , [13054,13055]
===
match
---
operator: -> [93390,93392]
operator: -> [93497,93499]
===
match
---
operator: , [66236,66237]
operator: , [66343,66344]
===
match
---
trailer [80265,80274]
trailer [80372,80381]
===
match
---
atom [22800,22816]
atom [22800,22816]
===
match
---
name: dagrun [68601,68607]
name: dagrun [68708,68714]
===
match
---
name: raw [16321,16324]
name: raw [16321,16324]
===
match
---
expr_stmt [78280,78382]
expr_stmt [78387,78489]
===
match
---
name: params [67565,67571]
name: params [67672,67678]
===
match
---
trailer [31476,31486]
trailer [31476,31486]
===
match
---
name: task [53714,53718]
name: task [53714,53718]
===
match
---
simple_stmt [69962,69983]
simple_stmt [70069,70090]
===
match
---
return_stmt [57430,57443]
return_stmt [57430,57443]
===
match
---
argument [86384,86436]
argument [86491,86543]
===
match
---
name: include_prior_dates [88686,88705]
name: include_prior_dates [88793,88812]
===
match
---
trailer [93100,93108]
trailer [93207,93215]
===
match
---
argument [52927,52942]
argument [52927,52942]
===
match
---
decorated [57449,58823]
decorated [57449,58823]
===
match
---
atom_expr [62231,62240]
atom_expr [62231,62240]
===
match
---
name: ti [92134,92136]
name: ti [92241,92243]
===
match
---
name: self [48952,48956]
name: self [48952,48956]
===
match
---
trailer [30195,30201]
trailer [30195,30201]
===
match
---
name: end_date [29089,29097]
name: end_date [29089,29097]
===
match
---
arglist [11217,11283]
arglist [11217,11283]
===
match
---
string: """Returns a tuple that identifies the task instance uniquely""" [28366,28430]
string: """Returns a tuple that identifies the task instance uniquely""" [28366,28430]
===
match
---
operator: , [53462,53463]
operator: , [53462,53463]
===
match
---
string: 'email' [83892,83899]
string: 'email' [83999,84006]
===
match
---
atom_expr [39905,39934]
atom_expr [39905,39934]
===
match
---
simple_stmt [25967,25995]
simple_stmt [25967,25995]
===
match
---
atom_expr [46059,46076]
atom_expr [46059,46076]
===
match
---
dotted_name [14477,14498]
dotted_name [14477,14498]
===
match
---
name: raw [19624,19627]
name: raw [19624,19627]
===
match
---
trailer [84034,84039]
trailer [84141,84146]
===
match
---
argument [45557,45572]
argument [45557,45572]
===
match
---
funcdef [92982,93037]
funcdef [93089,93144]
===
match
---
operator: -> [73106,73108]
operator: -> [73213,73215]
===
match
---
name: path [19602,19606]
name: path [19602,19606]
===
match
---
name: log [50312,50315]
name: log [50312,50315]
===
match
---
atom_expr [80060,80077]
atom_expr [80167,80184]
===
match
---
simple_stmt [89412,89448]
simple_stmt [89519,89555]
===
match
---
parameters [79153,79173]
parameters [79260,79280]
===
match
---
trailer [47987,47992]
trailer [47987,47992]
===
match
---
name: key [85138,85141]
name: key [85245,85248]
===
match
---
atom_expr [17125,17141]
atom_expr [17125,17141]
===
match
---
operator: = [54996,54997]
operator: = [54996,54997]
===
match
---
name: self [52498,52502]
name: self [52498,52502]
===
match
---
name: State [29020,29025]
name: State [29020,29025]
===
match
---
operator: , [2037,2038]
operator: , [2037,2038]
===
match
---
operator: = [80978,80979]
operator: = [81085,81086]
===
match
---
name: self [84639,84643]
name: self [84746,84750]
===
match
---
simple_stmt [10100,10192]
simple_stmt [10100,10192]
===
match
---
operator: , [84663,84664]
operator: , [84770,84771]
===
match
---
name: ti [26376,26378]
name: ti [26376,26378]
===
match
---
name: get_previous_start_date [35791,35814]
name: get_previous_start_date [35791,35814]
===
match
---
expr_stmt [89985,89999]
expr_stmt [90092,90106]
===
match
---
trailer [5461,5468]
trailer [5461,5468]
===
match
---
name: timeout_seconds [56668,56683]
name: timeout_seconds [56668,56683]
===
match
---
arglist [5122,5131]
arglist [5122,5131]
===
match
---
name: self [80772,80776]
name: self [80879,80883]
===
match
---
atom_expr [49475,49534]
atom_expr [49475,49534]
===
match
---
operator: , [75131,75132]
operator: , [75238,75239]
===
match
---
atom_expr [20125,20138]
atom_expr [20125,20138]
===
match
---
expr_stmt [84199,84267]
expr_stmt [84306,84374]
===
match
---
name: debug [79900,79905]
name: debug [80007,80012]
===
match
---
trailer [92447,92453]
trailer [92554,92560]
===
match
---
simple_stmt [5004,5046]
simple_stmt [5004,5046]
===
match
---
simple_stmt [49013,49033]
simple_stmt [49013,49033]
===
match
---
name: render [83835,83841]
name: render [83942,83948]
===
match
---
funcdef [80280,81254]
funcdef [80387,81361]
===
match
---
name: self [28462,28466]
name: self [28462,28466]
===
match
---
name: _queue [92841,92847]
name: _queue [92948,92954]
===
match
---
operator: = [76563,76564]
operator: = [76670,76671]
===
match
---
operator: = [35096,35097]
operator: = [35096,35097]
===
match
---
if_stmt [88401,88453]
if_stmt [88508,88560]
===
match
---
funcdef [68367,68609]
funcdef [68474,68716]
===
match
---
operator: = [34690,34691]
operator: = [34690,34691]
===
match
---
trailer [76360,76398]
trailer [76467,76505]
===
match
---
name: path [19151,19155]
name: path [19151,19155]
===
match
---
operator: , [20172,20173]
operator: , [20172,20173]
===
match
---
string: 'ti' [82552,82556]
string: 'ti' [82659,82663]
===
match
---
name: session [88747,88754]
name: session [88854,88861]
===
match
---
trailer [11580,11592]
trailer [11580,11592]
===
match
---
trailer [29163,29172]
trailer [29163,29172]
===
match
---
param [92994,92998]
param [93101,93105]
===
match
---
operator: , [4738,4739]
operator: , [4738,4739]
===
match
---
simple_stmt [93089,93109]
simple_stmt [93196,93216]
===
match
---
atom_expr [24241,24252]
atom_expr [24241,24252]
===
match
---
simple_stmt [56886,56913]
simple_stmt [56886,56913]
===
match
---
expr_stmt [12161,12224]
expr_stmt [12161,12224]
===
match
---
name: self [40319,40323]
name: self [40319,40323]
===
match
---
name: format [86183,86189]
name: format [86290,86296]
===
match
---
expr_stmt [9399,9423]
expr_stmt [9399,9423]
===
match
---
operator: ** [11320,11322]
operator: ** [11320,11322]
===
match
---
operator: , [81540,81541]
operator: , [81647,81648]
===
match
---
name: timezone [15313,15321]
name: timezone [15313,15321]
===
match
---
name: delay [39952,39957]
name: delay [39952,39957]
===
match
---
operator: = [35053,35054]
operator: = [35053,35054]
===
match
---
suite [40475,41104]
suite [40475,41104]
===
match
---
atom_expr [65769,65788]
atom_expr [65876,65895]
===
match
---
name: start_date [58792,58802]
name: start_date [58792,58802]
===
match
---
expr_stmt [58764,58822]
expr_stmt [58764,58822]
===
match
---
simple_stmt [46787,46829]
simple_stmt [46787,46829]
===
match
---
name: run_ids_by_dag_id [9007,9024]
name: run_ids_by_dag_id [9007,9024]
===
match
---
trailer [11983,11997]
trailer [11983,11997]
===
match
---
name: str [72993,72996]
name: str [73100,73103]
===
match
---
suite [28357,28519]
suite [28357,28519]
===
match
---
comparison [38978,38993]
comparison [38978,38993]
===
match
---
trailer [83518,83763]
trailer [83625,83870]
===
match
---
expr_stmt [81165,81224]
expr_stmt [81272,81331]
===
match
---
trailer [56139,56177]
trailer [56139,56177]
===
match
---
trailer [43868,44149]
trailer [43868,44149]
===
match
---
trailer [62631,62644]
trailer [62631,62644]
===
match
---
import_from [2534,2578]
import_from [2534,2578]
===
match
---
name: BooleanClauseList [90141,90158]
name: BooleanClauseList [90248,90265]
===
match
---
name: defer [58323,58328]
name: defer [58323,58328]
===
match
---
name: dag_run_state [5420,5433]
name: dag_run_state [5420,5433]
===
match
---
name: self [23273,23277]
name: self [23273,23277]
===
match
---
operator: = [92309,92310]
operator: = [92416,92417]
===
match
---
trailer [66416,66490]
trailer [66523,66597]
===
match
---
name: RESTARTING [66661,66671]
name: RESTARTING [66768,66778]
===
match
---
name: dag [18807,18810]
name: dag [18807,18810]
===
match
---
name: execution_date [73543,73557]
name: execution_date [73650,73664]
===
match
---
name: get_next_execution_date [73993,74016]
name: get_next_execution_date [74100,74123]
===
match
---
param [66570,66574]
param [66677,66681]
===
match
---
funcdef [79128,79721]
funcdef [79235,79828]
===
match
---
suite [51519,51543]
suite [51519,51543]
===
match
---
operator: = [86325,86326]
operator: = [86432,86433]
===
match
---
argument [61179,61210]
argument [61179,61210]
===
match
---
operator: = [45242,45243]
operator: = [45242,45243]
===
match
---
name: AirflowTaskTimeout [2160,2178]
name: AirflowTaskTimeout [2160,2178]
===
match
---
name: error [60430,60435]
name: error [60430,60435]
===
match
---
name: TaskInstanceStateType [91931,91952]
name: TaskInstanceStateType [92038,92059]
===
match
---
decorated [17829,17944]
decorated [17829,17944]
===
match
---
name: session [32964,32971]
name: session [32964,32971]
===
match
---
name: Column [11849,11855]
name: Column [11849,11855]
===
match
---
name: run_id [15958,15964]
name: run_id [15958,15964]
===
match
---
operator: , [11443,11444]
operator: , [11443,11444]
===
match
---
name: last_dagrun [32165,32176]
name: last_dagrun [32165,32176]
===
match
---
name: self [92161,92165]
name: self [92268,92272]
===
match
---
trailer [93264,93274]
trailer [93371,93381]
===
match
---
name: set_committed_value [41044,41063]
name: set_committed_value [41044,41063]
===
match
---
atom_expr [5055,5077]
atom_expr [5055,5077]
===
match
---
operator: , [7936,7937]
operator: , [7936,7937]
===
match
---
string: """Log URL for TaskInstance""" [23073,23103]
string: """Log URL for TaskInstance""" [23073,23103]
===
match
---
name: utcnow [58312,58318]
name: utcnow [58312,58318]
===
match
---
name: registered [53918,53928]
name: registered [53918,53928]
===
match
---
trailer [9534,9559]
trailer [9534,9559]
===
match
---
name: task [65769,65773]
name: task [65876,65880]
===
match
---
operator: @ [74325,74326]
operator: @ [74432,74433]
===
match
---
name: self [93482,93486]
name: self [93589,93593]
===
match
---
trailer [14139,14149]
trailer [14139,14149]
===
match
---
dotted_name [1492,1523]
dotted_name [1492,1523]
===
match
---
atom_expr [51983,51993]
atom_expr [51983,51993]
===
match
---
name: ID_LEN [12198,12204]
name: ID_LEN [12198,12204]
===
match
---
name: execution_date [86399,86413]
name: execution_date [86506,86520]
===
match
---
name: task_id [24283,24290]
name: task_id [24283,24290]
===
match
---
arglist [75080,75087]
arglist [75187,75194]
===
match
---
name: utcnow [28830,28836]
name: utcnow [28830,28836]
===
match
---
string: 'core' [67600,67606]
string: 'core' [67707,67713]
===
match
---
funcdef [79726,80019]
funcdef [79833,80126]
===
match
---
atom_expr [55556,55573]
atom_expr [55556,55573]
===
match
---
trailer [57782,57790]
trailer [57782,57790]
===
match
---
name: Dict [1091,1095]
name: Dict [1091,1095]
===
match
---
name: DeprecationWarning [35715,35733]
name: DeprecationWarning [35715,35733]
===
match
---
simple_stmt [26739,26781]
simple_stmt [26739,26781]
===
match
---
argument [81023,81105]
argument [81130,81212]
===
match
---
name: _execute_task_with_callbacks [49391,49419]
name: _execute_task_with_callbacks [49391,49419]
===
match
---
trailer [89989,89993]
trailer [90096,90100]
===
match
---
name: session [34514,34521]
name: session [34514,34521]
===
match
---
trailer [78506,78508]
trailer [78613,78615]
===
match
---
atom [30428,30458]
atom [30428,30458]
===
match
---
name: setattr [78526,78533]
name: setattr [78633,78640]
===
match
---
trailer [50224,50226]
trailer [50224,50226]
===
match
---
name: session [49753,49760]
name: session [49753,49760]
===
match
---
operator: | [37422,37423]
operator: | [37422,37423]
===
match
---
name: e [79686,79687]
name: e [79793,79794]
===
match
---
simple_stmt [49723,49770]
simple_stmt [49723,49770]
===
match
---
operator: , [55906,55907]
operator: , [55906,55907]
===
match
---
name: queued_by_job_id [26658,26674]
name: queued_by_job_id [26658,26674]
===
match
---
string: '-' [75080,75083]
string: '-' [75187,75190]
===
match
---
simple_stmt [14472,14538]
simple_stmt [14472,14538]
===
match
---
trailer [9918,9926]
trailer [9918,9926]
===
match
---
expr_stmt [44806,44885]
expr_stmt [44806,44885]
===
match
---
trailer [70991,71022]
trailer [71098,71129]
===
match
---
fstring_expr [23573,23587]
fstring_expr [23573,23587]
===
match
---
return_stmt [23218,23308]
return_stmt [23218,23308]
===
match
---
expr_stmt [47144,47178]
expr_stmt [47144,47178]
===
match
---
atom_expr [24153,24392]
atom_expr [24153,24392]
===
match
---
not_test [52144,52157]
not_test [52144,52157]
===
match
---
not_test [64388,64401]
not_test [64388,64401]
===
match
---
name: bool [41290,41294]
name: bool [41290,41294]
===
match
---
not_test [30109,30137]
not_test [30109,30137]
===
match
---
name: AirflowSkipException [50358,50378]
name: AirflowSkipException [50358,50378]
===
match
---
operator: , [82902,82903]
operator: , [83009,83010]
===
match
---
operator: , [64443,64444]
operator: , [64443,64444]
===
match
---
param [79779,79786]
param [79886,79893]
===
match
---
name: context [80051,80058]
name: context [80158,80165]
===
match
---
trailer [62589,62598]
trailer [62589,62598]
===
match
---
operator: = [44004,44005]
operator: = [44004,44005]
===
match
---
trailer [92545,92550]
trailer [92652,92657]
===
match
---
operator: = [70091,70092]
operator: = [70198,70199]
===
match
---
arglist [62746,62939]
arglist [62746,62939]
===
match
---
name: ignore_task_deps [44101,44117]
name: ignore_task_deps [44101,44117]
===
match
---
funcdef [4925,5324]
funcdef [4925,5324]
===
match
---
name: task_id [6340,6347]
name: task_id [6340,6347]
===
match
---
operator: = [19539,19540]
operator: = [19539,19540]
===
match
---
simple_stmt [43122,43139]
simple_stmt [43122,43139]
===
match
---
atom_expr [33954,33995]
atom_expr [33954,33995]
===
match
---
subscript [93871,93875]
subscript [93978,93982]
===
match
---
name: task_id [91315,91322]
name: task_id [91422,91429]
===
match
---
name: provide_session [66170,66185]
name: provide_session [66277,66292]
===
match
---
name: platform [3290,3298]
name: platform [3290,3298]
===
match
---
atom_expr [75064,75088]
atom_expr [75171,75195]
===
match
---
name: cmd [22902,22905]
name: cmd [22902,22905]
===
match
---
trailer [67454,67470]
trailer [67561,67577]
===
match
---
name: timeout [3528,3535]
name: timeout [3528,3535]
===
match
---
trailer [72693,72696]
trailer [72800,72803]
===
match
---
name: session [57833,57840]
name: session [57833,57840]
===
match
---
trailer [74549,74562]
trailer [74656,74669]
===
match
---
param [86719,86743]
param [86826,86850]
===
match
---
simple_stmt [55052,55069]
simple_stmt [55052,55069]
===
match
---
atom_expr [74860,74896]
atom_expr [74967,75003]
===
match
---
name: task [76276,76280]
name: task [76383,76387]
===
match
---
trailer [47326,47331]
trailer [47326,47331]
===
match
---
name: do_xcom_push [57323,57335]
name: do_xcom_push [57323,57335]
===
match
---
trailer [54739,54749]
trailer [54739,54749]
===
match
---
if_stmt [46605,46655]
if_stmt [46605,46655]
===
match
---
name: QUEUED [5484,5490]
name: QUEUED [5484,5490]
===
match
---
trailer [7018,7039]
trailer [7018,7039]
===
match
---
name: pool [19668,19672]
name: pool [19668,19672]
===
match
---
name: ti [26966,26968]
name: ti [26966,26968]
===
match
---
tfpdef [47860,47875]
tfpdef [47860,47875]
===
match
---
trailer [3856,3866]
trailer [3856,3866]
===
match
---
operator: , [69818,69819]
operator: , [69925,69926]
===
match
---
number: 0 [16001,16002]
number: 0 [16001,16002]
===
match
---
tfpdef [19965,19987]
tfpdef [19965,19987]
===
match
---
name: self [65377,65381]
name: self [65484,65488]
===
match
---
arglist [7839,7892]
arglist [7839,7892]
===
match
---
suite [90472,90497]
suite [90579,90604]
===
match
---
name: get_next_ds [73932,73943]
name: get_next_ds [74039,74050]
===
match
---
if_stmt [44902,44987]
if_stmt [44902,44987]
===
match
---
comparison [91590,91622]
comparison [91697,91729]
===
match
---
name: uselist [13642,13649]
name: uselist [13642,13649]
===
match
---
name: XCom [89355,89359]
name: XCom [89462,89466]
===
match
---
expr_stmt [45196,45486]
expr_stmt [45196,45486]
===
match
---
name: ds_nodash [67959,67968]
name: ds_nodash [68066,68075]
===
match
---
operator: , [1340,1341]
operator: , [1340,1341]
===
match
---
simple_stmt [26513,26555]
simple_stmt [26513,26555]
===
match
---
operator: @ [17183,17184]
operator: @ [17183,17184]
===
match
---
operator: = [80592,80593]
operator: = [80699,80700]
===
match
---
operator: , [73674,73675]
operator: , [73781,73782]
===
match
---
fstring_end: " [77328,77329]
fstring_end: " [77435,77436]
===
match
---
operator: = [80484,80485]
operator: = [80591,80592]
===
match
---
trailer [6339,6347]
trailer [6339,6347]
===
match
---
name: KeyboardInterrupt [51733,51750]
name: KeyboardInterrupt [51733,51750]
===
match
---
suite [4819,4854]
suite [4819,4854]
===
match
---
trailer [49098,49105]
trailer [49098,49105]
===
match
---
name: result [89042,89048]
name: result [89149,89155]
===
match
---
operator: = [15965,15966]
operator: = [15965,15966]
===
match
---
operator: , [71153,71154]
operator: , [71260,71261]
===
match
---
operator: = [26336,26337]
operator: = [26336,26337]
===
match
---
arith_expr [43891,43922]
arith_expr [43891,43922]
===
match
---
name: run [60654,60657]
name: run [60654,60657]
===
match
---
simple_stmt [59260,59428]
simple_stmt [59260,59428]
===
match
---
atom_expr [84717,84771]
atom_expr [84824,84878]
===
match
---
trailer [86564,86584]
trailer [86671,86691]
===
match
---
operator: = [58020,58021]
operator: = [58020,58021]
===
match
---
for_stmt [36739,37073]
for_stmt [36739,37073]
===
match
---
arith_expr [10170,10189]
arith_expr [10170,10189]
===
match
---
suite [43690,46175]
suite [43690,46175]
===
match
---
name: self [10565,10569]
name: self [10565,10569]
===
match
---
name: ti [26875,26877]
name: ti [26875,26877]
===
match
---
name: DeprecationWarning [72476,72494]
name: DeprecationWarning [72583,72601]
===
match
---
name: run_id [30370,30376]
name: run_id [30370,30376]
===
match
---
trailer [5962,5967]
trailer [5962,5967]
===
match
---
name: DepContext [37373,37383]
name: DepContext [37373,37383]
===
match
---
trailer [71144,71148]
trailer [71251,71255]
===
match
---
name: task [27447,27451]
name: task [27447,27451]
===
match
---
fstring_string:   [37938,37939]
fstring_string:   [37938,37939]
===
match
---
trailer [67490,67497]
trailer [67597,67604]
===
match
---
name: AirflowException [1965,1981]
name: AirflowException [1965,1981]
===
match
---
import_as_names [1266,1304]
import_as_names [1266,1304]
===
match
---
import_from [1715,1768]
import_from [1715,1768]
===
match
---
name: rendered_k8s_spec [79470,79487]
name: rendered_k8s_spec [79577,79594]
===
match
---
expr_stmt [92462,92509]
expr_stmt [92569,92616]
===
match
---
name: Optional [20084,20092]
name: Optional [20084,20092]
===
match
---
trailer [30449,30457]
trailer [30449,30457]
===
match
---
name: state [76889,76894]
name: state [76996,77001]
===
match
---
atom_expr [33691,33938]
atom_expr [33691,33938]
===
match
---
name: email [66070,66075]
name: email [66177,66182]
===
match
---
atom_expr [93260,93274]
atom_expr [93367,93381]
===
match
---
operator: , [1401,1402]
operator: , [1401,1402]
===
match
---
name: self [80640,80644]
name: self [80747,80751]
===
match
---
operator: + [23234,23235]
operator: + [23234,23235]
===
match
---
simple_stmt [92199,92231]
simple_stmt [92306,92338]
===
match
---
operator: { [52841,52842]
operator: { [52841,52842]
===
match
---
name: dep_status [37797,37807]
name: dep_status [37797,37807]
===
match
---
fstring_expr [23656,23661]
fstring_expr [23656,23661]
===
match
---
name: t [91085,91086]
name: t [91192,91193]
===
match
---
name: error [63878,63883]
name: error [63878,63883]
===
match
---
suite [22889,22938]
suite [22889,22938]
===
match
---
simple_stmt [74829,74841]
simple_stmt [74936,74948]
===
match
---
decorated [35841,37205]
decorated [35841,37205]
===
match
---
name: replacement [76169,76180]
name: replacement [76276,76287]
===
match
---
name: state [17082,17087]
name: state [17082,17087]
===
match
---
trailer [25478,25484]
trailer [25478,25484]
===
match
---
number: 2 [33926,33927]
number: 2 [33926,33927]
===
match
---
operator: , [11630,11631]
operator: , [11630,11631]
===
match
---
argument [12206,12222]
argument [12206,12222]
===
match
---
tfpdef [4007,4023]
tfpdef [4007,4023]
===
match
---
trailer [32088,32096]
trailer [32088,32096]
===
match
---
name: Any [92485,92488]
name: Any [92592,92595]
===
match
---
operator: , [2095,2096]
operator: , [2095,2096]
===
match
---
decorator [93042,93052]
decorator [93149,93159]
===
match
---
name: base_worker_pod [81023,81038]
name: base_worker_pod [81130,81145]
===
match
---
string: "DagRun" [30713,30721]
string: "DagRun" [30713,30721]
===
match
---
name: dag_run [13910,13917]
name: dag_run [13910,13917]
===
match
---
trailer [8960,8965]
trailer [8960,8965]
===
match
---
name: get_dagrun [88484,88494]
name: get_dagrun [88591,88601]
===
match
---
trailer [48917,48926]
trailer [48917,48926]
===
match
---
operator: = [46545,46546]
operator: = [46545,46546]
===
match
---
trailer [30272,30279]
trailer [30272,30279]
===
match
---
atom_expr [5472,5490]
atom_expr [5472,5490]
===
match
---
name: self [23413,23417]
name: self [23413,23417]
===
match
---
trailer [80814,80830]
trailer [80921,80937]
===
match
---
expr_stmt [38200,38229]
expr_stmt [38200,38229]
===
match
---
name: prev_ti [34470,34477]
name: prev_ti [34470,34477]
===
match
---
atom_expr [14248,14259]
atom_expr [14248,14259]
===
match
---
trailer [52069,52076]
trailer [52069,52076]
===
match
---
atom_expr [52218,52237]
atom_expr [52218,52237]
===
match
---
operator: , [41068,41069]
operator: , [41068,41069]
===
match
---
name: self [58533,58537]
name: self [58533,58537]
===
match
---
simple_stmt [9894,9940]
simple_stmt [9894,9940]
===
match
---
operator: = [79167,79168]
operator: = [79274,79275]
===
match
---
atom_expr [29038,29048]
atom_expr [29038,29048]
===
match
---
trailer [9467,9469]
trailer [9467,9469]
===
match
---
name: self [92199,92203]
name: self [92306,92310]
===
match
---
operator: -> [41606,41608]
operator: -> [41606,41608]
===
match
---
simple_stmt [6982,7004]
simple_stmt [6982,7004]
===
match
---
name: task [64204,64208]
name: task [64204,64208]
===
match
---
arglist [12987,13026]
arglist [12987,13026]
===
match
---
name: TR [7664,7666]
name: TR [7664,7666]
===
match
---
trailer [47645,47660]
trailer [47645,47660]
===
match
---
import_from [3494,3535]
import_from [3494,3535]
===
match
---
name: mark_success [47824,47836]
name: mark_success [47824,47836]
===
match
---
arglist [40074,40106]
arglist [40074,40106]
===
match
---
param [69787,69792]
param [69894,69899]
===
match
---
atom_expr [16094,16107]
atom_expr [16094,16107]
===
match
---
operator: == [29049,29051]
operator: == [29049,29051]
===
match
---
decorated [93280,93355]
decorated [93387,93462]
===
match
---
atom_expr [26583,26594]
atom_expr [26583,26594]
===
match
---
operator: - [29173,29174]
operator: - [29173,29174]
===
match
---
string: 'Rescheduling task, marking task as UP_FOR_RESCHEDULE' [63254,63308]
string: 'Rescheduling task, marking task as UP_FOR_RESCHEDULE' [63254,63308]
===
match
---
operator: , [20246,20247]
operator: , [20246,20247]
===
match
---
trailer [83351,83363]
trailer [83458,83470]
===
match
---
simple_stmt [69897,69913]
simple_stmt [70004,70020]
===
match
---
operator: , [79769,79770]
operator: , [79876,79877]
===
match
---
decorator [17829,17839]
decorator [17829,17839]
===
match
---
tfpdef [34698,34714]
tfpdef [34698,34714]
===
match
---
operator: , [33381,33382]
operator: , [33381,33382]
===
match
---
comparison [4344,4369]
comparison [4344,4369]
===
match
---
trailer [58768,58784]
trailer [58768,58784]
===
match
---
name: self [48741,48745]
name: self [48741,48745]
===
match
---
trailer [46459,46467]
trailer [46459,46467]
===
match
---
name: end_date [92363,92371]
name: end_date [92470,92478]
===
match
---
string: "DagRun" [68265,68273]
string: "DagRun" [68372,68380]
===
match
---
simple_stmt [50594,50654]
simple_stmt [50594,50654]
===
match
---
param [18256,18270]
param [18256,18270]
===
match
---
arglist [80640,80665]
arglist [80747,80772]
===
match
---
if_stmt [79411,79688]
if_stmt [79518,79795]
===
match
---
operator: , [32458,32459]
operator: , [32458,32459]
===
match
---
parameters [47117,47134]
parameters [47117,47134]
===
match
---
simple_stmt [9583,9604]
simple_stmt [9583,9604]
===
match
---
name: on_execute_callback [58988,59007]
name: on_execute_callback [58988,59007]
===
match
---
funcdef [69926,69983]
funcdef [70033,70090]
===
match
---
trailer [51674,51681]
trailer [51674,51681]
===
match
---
name: max_tries [66885,66894]
name: max_tries [66992,67001]
===
match
---
string: '\n' [81598,81602]
string: '\n' [81705,81709]
===
match
---
name: self [66232,66236]
name: self [66339,66343]
===
match
---
param [71491,71496]
param [71598,71603]
===
match
---
name: flush [57841,57846]
name: flush [57841,57846]
===
match
---
name: context_to_airflow_vars [3247,3270]
name: context_to_airflow_vars [3247,3270]
===
match
---
name: kwargs [58073,58079]
name: kwargs [58073,58079]
===
match
---
atom_expr [92809,92827]
atom_expr [92916,92934]
===
match
---
operator: = [24137,24138]
operator: = [24137,24138]
===
match
---
name: r [72215,72216]
name: r [72322,72323]
===
match
---
name: XCom [88536,88540]
name: XCom [88643,88647]
===
match
---
tfpdef [60750,60778]
tfpdef [60750,60778]
===
match
---
operator: == [55775,55777]
operator: == [55775,55777]
===
match
---
name: XCom [89058,89062]
name: XCom [89165,89169]
===
match
---
operator: = [41570,41571]
operator: = [41570,41571]
===
match
---
atom_expr [75668,75679]
atom_expr [75775,75786]
===
match
---
name: dag_id [25547,25553]
name: dag_id [25547,25553]
===
match
---
try_stmt [49187,51997]
try_stmt [49187,51997]
===
match
---
name: self [83665,83669]
name: self [83772,83776]
===
match
---
trailer [53745,53772]
trailer [53745,53772]
===
match
---
name: task [65900,65904]
name: task [66007,66011]
===
match
---
atom_expr [94010,94031]
atom_expr [94117,94138]
===
match
---
name: prev_ti [34576,34583]
name: prev_ti [34576,34583]
===
match
---
operator: , [37057,37058]
operator: , [37057,37058]
===
match
---
operator: = [13209,13210]
operator: = [13209,13210]
===
match
---
operator: = [63665,63666]
operator: = [63665,63666]
===
match
---
yield_expr [4258,4271]
yield_expr [4258,4271]
===
match
---
name: error_fd [62007,62015]
name: error_fd [62007,62015]
===
match
---
expr_stmt [49241,49286]
expr_stmt [49241,49286]
===
match
---
name: self [92950,92954]
name: self [93057,93061]
===
match
---
trailer [36690,36694]
trailer [36690,36694]
===
match
---
simple_stmt [78147,78192]
simple_stmt [78254,78299]
===
match
---
operator: = [83151,83152]
operator: = [83258,83259]
===
match
---
name: ti [25943,25945]
name: ti [25943,25945]
===
match
---
suite [51560,51706]
suite [51560,51706]
===
match
---
return_stmt [71952,71971]
return_stmt [72059,72078]
===
match
---
parameters [10216,10239]
parameters [10216,10239]
===
match
---
simple_stmt [13910,14007]
simple_stmt [13910,14007]
===
match
---
name: result [47212,47218]
name: result [47212,47218]
===
match
---
name: _try_number [17248,17259]
name: _try_number [17248,17259]
===
match
---
tfpdef [20114,20138]
tfpdef [20114,20138]
===
match
---
if_stmt [67518,67573]
if_stmt [67625,67680]
===
match
---
name: interval_start [68004,68018]
name: interval_start [68111,68125]
===
match
---
name: state [65530,65535]
name: state [65637,65642]
===
match
---
trailer [73652,73665]
trailer [73759,73772]
===
match
---
trailer [67228,67232]
trailer [67335,67339]
===
match
---
simple_stmt [15365,15418]
simple_stmt [15365,15418]
===
match
---
name: self [33500,33504]
name: self [33500,33504]
===
match
---
trailer [49739,49769]
trailer [49739,49769]
===
match
---
operator: , [19606,19607]
operator: , [19606,19607]
===
match
---
tfpdef [19816,19827]
tfpdef [19816,19827]
===
match
---
operator: = [84031,84032]
operator: = [84138,84139]
===
match
---
simple_stmt [2353,2388]
simple_stmt [2353,2388]
===
match
---
atom_expr [74638,74657]
atom_expr [74745,74764]
===
match
---
trailer [58007,58019]
trailer [58007,58019]
===
match
---
if_stmt [91078,91355]
if_stmt [91185,91462]
===
match
---
if_stmt [82507,84357]
if_stmt [82614,84464]
===
match
---
name: datetime [942,950]
name: datetime [942,950]
===
match
---
operator: @ [93280,93281]
operator: @ [93387,93388]
===
match
---
atom_expr [27789,27803]
atom_expr [27789,27803]
===
match
---
name: ValueError [86052,86062]
name: ValueError [86159,86169]
===
match
---
trailer [26199,26210]
trailer [26199,26210]
===
match
---
if_stmt [73794,73854]
if_stmt [73901,73961]
===
match
---
name: session [50123,50130]
name: session [50123,50130]
===
match
---
name: session [88495,88502]
name: session [88602,88609]
===
match
---
term [19103,19123]
term [19103,19123]
===
match
---
expr_stmt [79470,79516]
expr_stmt [79577,79623]
===
match
---
atom_expr [56532,56559]
atom_expr [56532,56559]
===
match
---
trailer [26951,26963]
trailer [26951,26963]
===
match
---
name: state [28903,28908]
name: state [28903,28908]
===
match
---
name: exception [60156,60165]
name: exception [60156,60165]
===
match
---
return_stmt [41094,41103]
return_stmt [41094,41103]
===
match
---
simple_stmt [37127,37185]
simple_stmt [37127,37185]
===
match
---
expr_stmt [13910,14006]
expr_stmt [13910,14006]
===
match
---
annassign [18488,18514]
annassign [18488,18514]
===
match
---
name: trigger_timeout [58611,58626]
name: trigger_timeout [58611,58626]
===
match
---
atom_expr [30245,30264]
atom_expr [30245,30264]
===
match
---
operator: , [84752,84753]
operator: , [84859,84860]
===
match
---
name: info [50316,50320]
name: info [50316,50320]
===
match
---
name: ts_nodash_with_tz [68100,68117]
name: ts_nodash_with_tz [68207,68224]
===
match
---
if_stmt [69038,69092]
if_stmt [69145,69199]
===
match
---
suite [28591,29236]
suite [28591,29236]
===
match
---
name: lazy_object_proxy [76446,76463]
name: lazy_object_proxy [76553,76570]
===
match
---
name: self [27721,27725]
name: self [27721,27725]
===
match
---
name: task_id [91033,91040]
name: task_id [91140,91147]
===
match
---
suite [48037,52268]
suite [48037,52268]
===
match
---
name: html_content_err [84542,84558]
name: html_content_err [84649,84665]
===
match
---
name: try_number [38604,38614]
name: try_number [38604,38614]
===
match
---
trailer [91781,91788]
trailer [91888,91895]
===
match
---
argument [44270,44282]
argument [44270,44282]
===
match
---
operator: = [9757,9758]
operator: = [9757,9758]
===
match
---
trailer [56462,56474]
trailer [56462,56474]
===
match
---
name: self [31670,31674]
name: self [31670,31674]
===
match
---
operator: , [86666,86667]
operator: , [86773,86774]
===
match
---
operator: = [45616,45617]
operator: = [45616,45617]
===
match
---
trailer [73034,73042]
trailer [73141,73149]
===
match
---
expr_stmt [67999,68030]
expr_stmt [68106,68137]
===
match
---
name: self [92652,92656]
name: self [92759,92763]
===
match
---
funcdef [24536,24889]
funcdef [24536,24889]
===
match
---
param [62369,62387]
param [62369,62387]
===
match
---
name: items [8072,8077]
name: items [8072,8077]
===
match
---
name: task [62169,62173]
name: task [62169,62173]
===
match
---
trailer [66161,66163]
trailer [66268,66270]
===
match
---
atom_expr [56583,56598]
atom_expr [56583,56598]
===
match
---
operator: , [24939,24940]
operator: , [24939,24940]
===
match
---
operator: , [19227,19228]
operator: , [19227,19228]
===
match
---
trailer [26877,26888]
trailer [26877,26888]
===
match
---
name: warnings [73644,73652]
name: warnings [73751,73759]
===
match
---
name: self [64445,64449]
name: self [64445,64449]
===
match
---
name: task [80238,80242]
name: task [80345,80349]
===
match
---
exprlist [53425,53429]
exprlist [53425,53429]
===
match
---
name: UP_FOR_RETRY [29058,29070]
name: UP_FOR_RETRY [29058,29070]
===
match
---
name: self [34409,34413]
name: self [34409,34413]
===
match
---
atom_expr [28847,28909]
atom_expr [28847,28909]
===
match
---
name: try_number [92407,92417]
name: try_number [92514,92524]
===
match
---
param [24935,24940]
param [24935,24940]
===
match
---
trailer [53587,53592]
trailer [53587,53592]
===
match
---
operator: { [64318,64319]
operator: { [64318,64319]
===
match
---
name: ignore_all_deps [41227,41242]
name: ignore_all_deps [41227,41242]
===
match
---
param [70654,70659]
param [70761,70766]
===
match
---
operator: , [5318,5319]
operator: , [5318,5319]
===
match
---
name: self [54569,54573]
name: self [54569,54573]
===
match
---
suite [37519,37853]
suite [37519,37853]
===
match
---
name: task [67521,67525]
name: task [67628,67632]
===
match
---
name: warn [14560,14564]
name: warn [14560,14564]
===
match
---
param [83847,83854]
param [83954,83961]
===
match
---
operator: , [43174,43175]
operator: , [43174,43175]
===
match
---
fstring_string: ti.start. [49129,49138]
fstring_string: ti.start. [49129,49138]
===
match
---
name: dep_status [37456,37466]
name: dep_status [37456,37466]
===
match
---
name: execution_date [74034,74048]
name: execution_date [74141,74155]
===
match
---
trailer [26259,26269]
trailer [26259,26269]
===
match
---
name: external_executor_id [41534,41554]
name: external_executor_id [41534,41554]
===
match
---
return_stmt [32910,32972]
return_stmt [32910,32972]
===
match
---
param [85156,85167]
param [85263,85274]
===
match
---
name: bool [86697,86701]
name: bool [86804,86808]
===
match
---
name: session [64415,64422]
name: session [64415,64422]
===
match
---
name: self [55820,55824]
name: self [55820,55824]
===
match
---
operator: = [88534,88535]
operator: = [88641,88642]
===
match
---
name: DagRun [40860,40866]
name: DagRun [40860,40866]
===
match
---
name: ti [26492,26494]
name: ti [26492,26494]
===
match
---
arglist [76547,76573]
arglist [76654,76680]
===
match
---
trailer [46488,46494]
trailer [46488,46494]
===
match
---
name: ApiClient [3742,3751]
name: ApiClient [3742,3751]
===
match
---
atom_expr [57980,57994]
atom_expr [57980,57994]
===
match
---
atom_expr [9206,9232]
atom_expr [9206,9232]
===
match
---
trailer [58537,58542]
trailer [58537,58542]
===
match
---
atom_expr [30429,30442]
atom_expr [30429,30442]
===
match
---
atom_expr [68051,68091]
atom_expr [68158,68198]
===
match
---
name: state [24815,24820]
name: state [24815,24820]
===
match
---
name: log [63245,63248]
name: log [63245,63248]
===
match
---
param [47860,47884]
param [47860,47884]
===
match
---
simple_stmt [58048,58086]
simple_stmt [58048,58086]
===
match
---
if_stmt [78391,79102]
if_stmt [78498,79209]
===
match
---
name: airflow [3276,3283]
name: airflow [3276,3283]
===
match
---
argument [49753,49768]
argument [49753,49768]
===
match
---
simple_stmt [12040,12075]
simple_stmt [12040,12075]
===
match
---
name: task [31675,31679]
name: task [31675,31679]
===
match
---
with_stmt [54481,54580]
with_stmt [54481,54580]
===
match
---
operator: , [11863,11864]
operator: , [11863,11864]
===
match
---
name: data_interval_end [75255,75272]
name: data_interval_end [75362,75379]
===
match
---
name: start_date [84873,84883]
name: start_date [84980,84990]
===
match
---
simple_stmt [43239,43299]
simple_stmt [43239,43299]
===
match
---
trailer [53713,53718]
trailer [53713,53718]
===
match
---
operator: = [92627,92628]
operator: = [92734,92735]
===
match
---
funcdef [35862,37205]
funcdef [35862,37205]
===
match
---
trailer [23473,23498]
trailer [23473,23498]
===
match
---
name: dry_run [62086,62093]
name: dry_run [62086,62093]
===
match
---
trailer [28461,28518]
trailer [28461,28518]
===
match
---
string: """Overwrite Task Params with DagRun.conf""" [79797,79841]
string: """Overwrite Task Params with DagRun.conf""" [79904,79948]
===
match
---
string: 'Try {{try_number}} out of {{max_tries + 1}}<br>' [81865,81914]
string: 'Try {{try_number}} out of {{max_tries + 1}}<br>' [81972,82021]
===
match
---
suite [57005,57069]
suite [57005,57069]
===
match
---
name: utils [3027,3032]
name: utils [3027,3032]
===
match
---
name: Dict [3790,3794]
name: Dict [3790,3794]
===
match
---
atom_expr [18490,18514]
atom_expr [18490,18514]
===
match
---
dotted_name [1933,1951]
dotted_name [1933,1951]
===
match
---
name: set_duration [52118,52130]
name: set_duration [52118,52130]
===
match
---
comparison [89708,89742]
comparison [89815,89849]
===
match
---
name: f [83996,83997]
name: f [84103,84104]
===
match
---
suite [31245,31497]
suite [31245,31497]
===
match
---
return_stmt [93253,93274]
return_stmt [93360,93381]
===
match
---
name: Exception [63396,63405]
name: Exception [63396,63405]
===
match
---
simple_stmt [70718,70771]
simple_stmt [70825,70878]
===
match
---
trailer [4326,4330]
trailer [4326,4330]
===
match
---
name: dag_id [19221,19227]
name: dag_id [19221,19227]
===
match
---
atom_expr [43492,43532]
atom_expr [43492,43532]
===
match
---
atom_expr [73761,73780]
atom_expr [73868,73887]
===
match
---
name: name [91397,91401]
name: name [91504,91508]
===
match
---
atom_expr [92629,92643]
atom_expr [92736,92750]
===
match
---
operator: = [29156,29157]
operator: = [29156,29157]
===
match
---
funcdef [24915,27084]
funcdef [24915,27084]
===
match
---
decorator [74668,74675]
decorator [74775,74782]
===
match
---
yield_expr [37836,37852]
yield_expr [37836,37852]
===
match
---
parameters [79764,79787]
parameters [79871,79894]
===
match
---
name: _date_or_empty [47693,47707]
name: _date_or_empty [47693,47707]
===
match
---
trailer [58072,58079]
trailer [58072,58079]
===
match
---
decorator [93114,93124]
decorator [93221,93231]
===
match
---
atom_expr [26195,26210]
atom_expr [26195,26210]
===
match
---
argument [53276,53298]
argument [53276,53298]
===
match
---
atom_expr [92404,92417]
atom_expr [92511,92524]
===
match
---
arglist [32942,32971]
arglist [32942,32971]
===
match
---
string: 'ti_dag_run' [12845,12857]
string: 'ti_dag_run' [12845,12857]
===
match
---
name: session [37497,37504]
name: session [37497,37504]
===
match
---
name: run_id [19267,19273]
name: run_id [19267,19273]
===
match
---
dotted_name [3276,3298]
dotted_name [3276,3298]
===
match
---
funcdef [32992,33457]
funcdef [32992,33457]
===
match
---
name: pool [92673,92677]
name: pool [92780,92784]
===
match
---
name: self [93780,93784]
name: self [93887,93891]
===
match
---
fstring [72397,72436]
fstring [72504,72543]
===
match
---
name: replacement [76995,77006]
name: replacement [77102,77113]
===
match
---
simple_stmt [3314,3380]
simple_stmt [3314,3380]
===
match
---
expr_stmt [11537,11561]
expr_stmt [11537,11561]
===
match
---
name: kube_image [80743,80753]
name: kube_image [80850,80860]
===
match
---
name: dag_id [86602,86608]
name: dag_id [86709,86715]
===
match
---
name: bool [41244,41248]
name: bool [41244,41248]
===
match
---
simple_stmt [14221,14240]
simple_stmt [14221,14240]
===
match
---
operator: = [11824,11825]
operator: = [11824,11825]
===
match
---
name: start_date [28950,28960]
name: start_date [28950,28960]
===
match
---
sync_comp_for [91135,91147]
sync_comp_for [91242,91254]
===
match
---
operator: , [11267,11268]
operator: , [11267,11268]
===
match
---
operator: == [30265,30267]
operator: == [30265,30267]
===
match
---
name: trigger_timeout [58368,58383]
name: trigger_timeout [58368,58383]
===
match
---
name: task [51949,51953]
name: task [51949,51953]
===
match
---
name: task_id [19794,19801]
name: task_id [19794,19801]
===
match
---
suite [60256,60624]
suite [60256,60624]
===
match
---
trailer [62728,62953]
trailer [62728,62953]
===
match
---
name: previous_schedule [74620,74637]
name: previous_schedule [74727,74744]
===
match
---
simple_stmt [55859,55920]
simple_stmt [55859,55920]
===
match
---
operator: , [10161,10162]
operator: , [10161,10162]
===
match
---
name: dag_id [88432,88438]
name: dag_id [88539,88545]
===
match
---
name: exception_html [82836,82850]
name: exception_html [82943,82957]
===
match
---
name: error [66417,66422]
name: error [66524,66529]
===
match
---
expr_stmt [43122,43138]
expr_stmt [43122,43138]
===
match
---
name: self [9901,9905]
name: self [9901,9905]
===
match
---
tfpdef [41391,41409]
tfpdef [41391,41409]
===
match
---
operator: = [56130,56131]
operator: = [56130,56131]
===
match
---
name: pid [12079,12082]
name: pid [12079,12082]
===
match
---
name: str [92849,92852]
name: str [92956,92959]
===
match
---
simple_stmt [26567,26595]
simple_stmt [26567,26595]
===
match
---
trailer [48956,48960]
trailer [48956,48960]
===
match
---
argument [11445,11459]
argument [11445,11459]
===
match
---
simple_stmt [12161,12225]
simple_stmt [12161,12225]
===
match
---
suite [46425,46476]
suite [46425,46476]
===
match
---
name: Optional [68419,68427]
name: Optional [68526,68534]
===
match
---
if_stmt [69268,69315]
if_stmt [69375,69422]
===
match
---
trailer [7122,7137]
trailer [7122,7137]
===
match
---
operator: = [82835,82836]
operator: = [82942,82943]
===
match
---
operator: } [52878,52879]
operator: } [52878,52879]
===
match
---
annassign [92396,92417]
annassign [92503,92524]
===
match
---
trailer [11587,11591]
trailer [11587,11591]
===
match
---
and_test [8810,8844]
and_test [8810,8844]
===
match
---
trailer [73542,73557]
trailer [73649,73664]
===
match
---
trailer [56631,56633]
trailer [56631,56633]
===
match
---
trailer [10391,10398]
trailer [10391,10398]
===
match
---
trailer [57846,57848]
trailer [57846,57848]
===
match
---
name: _try_number [11597,11608]
name: _try_number [11597,11608]
===
match
---
name: self [61644,61648]
name: self [61644,61648]
===
match
---
expr_stmt [9583,9603]
expr_stmt [9583,9603]
===
match
---
name: task [78539,78543]
name: task [78646,78650]
===
match
---
trailer [30528,30548]
trailer [30528,30548]
===
match
---
operator: = [68002,68003]
operator: = [68109,68110]
===
match
---
name: dag_run [79779,79786]
name: dag_run [79886,79893]
===
match
---
name: dag_id [9258,9264]
name: dag_id [9258,9264]
===
match
---
suite [59008,59059]
suite [59008,59059]
===
match
---
simple_stmt [73842,73854]
simple_stmt [73949,73961]
===
match
---
name: Column [12573,12579]
name: Column [12573,12579]
===
match
---
name: NamedTemporaryFile [1029,1047]
name: NamedTemporaryFile [1029,1047]
===
match
---
atom_expr [28462,28473]
atom_expr [28462,28473]
===
match
---
expr_stmt [30950,30969]
expr_stmt [30950,30969]
===
match
---
trailer [56034,56063]
trailer [56034,56063]
===
match
---
arglist [18633,18645]
arglist [18633,18645]
===
match
---
name: defer [57777,57782]
name: defer [57777,57782]
===
match
---
name: ti [6912,6914]
name: ti [6912,6914]
===
match
---
fstring [23236,23308]
fstring [23236,23308]
===
match
---
simple_stmt [70852,70873]
simple_stmt [70959,70980]
===
match
---
name: provide_session [86483,86498]
name: provide_session [86590,86605]
===
match
---
operator: , [62425,62426]
operator: , [62425,62426]
===
match
---
for_stmt [8974,9063]
for_stmt [8974,9063]
===
match
---
name: self [77356,77360]
name: self [77463,77467]
===
match
---
fstring_end: " [53419,53420]
fstring_end: " [53419,53420]
===
match
---
name: XCom [89419,89423]
name: XCom [89526,89530]
===
match
---
suite [64140,64183]
suite [64140,64183]
===
match
---
name: self [47810,47814]
name: self [47810,47814]
===
match
---
string: 'task' [77198,77204]
string: 'task' [77305,77311]
===
match
---
operator: , [61512,61513]
operator: , [61512,61513]
===
match
---
param [18197,18207]
param [18197,18207]
===
match
---
trailer [49786,49790]
trailer [49786,49790]
===
match
---
number: 0 [24441,24442]
number: 0 [24441,24442]
===
match
---
not_test [19052,19074]
not_test [19052,19074]
===
match
---
simple_stmt [58280,58337]
simple_stmt [58280,58337]
===
match
---
param [72069,72085]
param [72176,72192]
===
match
---
name: next_method [56051,56062]
name: next_method [56051,56062]
===
match
---
name: file_path [19592,19601]
name: file_path [19592,19601]
===
match
---
trailer [67376,67420]
trailer [67483,67527]
===
match
---
name: ti [6290,6292]
name: ti [6290,6292]
===
match
---
tfpdef [63458,63474]
tfpdef [63458,63474]
===
match
---
fstring_start: f' [64298,64300]
fstring_start: f' [64298,64300]
===
match
---
operator: = [56684,56685]
operator: = [56684,56685]
===
match
---
name: jinja_env [83243,83252]
name: jinja_env [83350,83359]
===
match
---
trailer [64552,64563]
trailer [64659,64670]
===
match
---
name: jinja_env [83342,83351]
name: jinja_env [83449,83458]
===
match
---
operator: , [9264,9265]
operator: , [9264,9265]
===
match
---
name: trigger_timeout [58769,58784]
name: trigger_timeout [58769,58784]
===
match
---
name: _defer_task [57474,57485]
name: _defer_task [57474,57485]
===
match
---
operator: , [1589,1590]
operator: , [1589,1590]
===
match
---
name: defer [57501,57506]
name: defer [57501,57506]
===
match
---
operator: = [45348,45349]
operator: = [45348,45349]
===
match
---
operator: = [75921,75922]
operator: = [76028,76029]
===
match
---
name: self [62094,62098]
name: self [62094,62098]
===
match
---
comparison [25519,25553]
comparison [25519,25553]
===
match
---
simple_stmt [44806,44886]
simple_stmt [44806,44886]
===
match
---
operator: , [34696,34697]
operator: , [34696,34697]
===
match
---
fstring_string:  [ [37952,37954]
fstring_string:  [ [37952,37954]
===
match
---
string: 'dag' [18670,18675]
string: 'dag' [18670,18675]
===
match
---
trailer [12308,12320]
trailer [12308,12320]
===
match
---
name: Tuple [91955,91960]
name: Tuple [92062,92067]
===
match
---
operator: { [51489,51490]
operator: { [51489,51490]
===
match
---
string: "worker-config" [80940,80955]
string: "worker-config" [81047,81062]
===
match
---
argument [76743,76768]
argument [76850,76875]
===
match
---
atom_expr [90442,90451]
atom_expr [90549,90558]
===
match
---
operator: , [35087,35088]
operator: , [35087,35088]
===
match
---
simple_stmt [83323,83414]
simple_stmt [83430,83521]
===
match
---
atom_expr [23612,23623]
atom_expr [23612,23623]
===
match
---
operator: = [68348,68349]
operator: = [68455,68456]
===
match
---
string: "DataInterval" [68428,68442]
string: "DataInterval" [68535,68549]
===
match
---
name: deserialize_model_file [81052,81074]
name: deserialize_model_file [81159,81181]
===
match
---
name: parent_dag [18921,18931]
name: parent_dag [18921,18931]
===
match
---
name: key [91815,91818]
name: key [91922,91925]
===
match
---
atom [84913,84946]
atom [85020,85053]
===
match
---
name: provide_session [30556,30571]
name: provide_session [30556,30571]
===
match
---
operator: = [59988,59989]
operator: = [59988,59989]
===
match
---
name: ti [53016,53018]
name: ti [53016,53018]
===
match
---
simple_stmt [26653,26697]
simple_stmt [26653,26697]
===
match
---
trailer [89359,89365]
trailer [89466,89472]
===
match
---
simple_stmt [16067,16086]
simple_stmt [16067,16086]
===
match
---
operator: , [50010,50011]
operator: , [50010,50011]
===
match
---
fstring_string:  not found [15900,15910]
fstring_string:  not found [15900,15910]
===
match
---
atom_expr [6931,6943]
atom_expr [6931,6943]
===
match
---
simple_stmt [35949,36582]
simple_stmt [35949,36582]
===
match
---
name: nullable [11445,11453]
name: nullable [11445,11453]
===
match
---
trailer [57840,57846]
trailer [57840,57846]
===
match
---
decorator [30555,30572]
decorator [30555,30572]
===
match
---
trailer [73620,73622]
trailer [73727,73729]
===
match
---
name: reconstructor [1576,1589]
name: reconstructor [1576,1589]
===
match
---
fstring_string: &task_id= [23263,23272]
fstring_string: &task_id= [23263,23272]
===
match
---
trailer [14340,14346]
trailer [14340,14346]
===
match
---
try_stmt [31241,31560]
try_stmt [31241,31560]
===
match
---
name: e [78707,78708]
name: e [78814,78815]
===
match
---
fstring_string: . [52859,52860]
fstring_string: . [52859,52860]
===
match
---
atom_expr [62007,62023]
atom_expr [62007,62023]
===
match
---
name: state [49552,49557]
name: state [49552,49557]
===
match
---
atom_expr [64415,64451]
atom_expr [64415,64451]
===
match
---
tfpdef [86602,86623]
tfpdef [86709,86730]
===
match
---
name: value [57408,57413]
name: value [57408,57413]
===
match
---
atom_expr [37797,37814]
atom_expr [37797,37814]
===
match
---
import_name [1192,1205]
import_name [1192,1205]
===
match
---
name: email_alert [65950,65961]
name: email_alert [66057,66068]
===
match
---
trailer [24760,24801]
trailer [24760,24801]
===
match
---
atom_expr [86570,86583]
atom_expr [86677,86690]
===
match
---
for_stmt [5974,7154]
for_stmt [5974,7154]
===
match
---
name: dag [74616,74619]
name: dag [74723,74726]
===
match
---
string: 'kcah_acitats' [93856,93870]
string: 'kcah_acitats' [93963,93977]
===
match
---
trailer [26764,26780]
trailer [26764,26780]
===
match
---
name: try_number [10400,10410]
name: try_number [10400,10410]
===
match
---
operator: , [77756,77757]
operator: , [77863,77864]
===
match
---
name: task [60269,60273]
name: task [60269,60273]
===
match
---
atom_expr [15509,15525]
atom_expr [15509,15525]
===
match
---
name: task [18664,18668]
name: task [18664,18668]
===
match
---
tfpdef [32460,32480]
tfpdef [32460,32480]
===
match
---
name: self [84914,84918]
name: self [85021,85025]
===
match
---
operator: ** [11232,11234]
operator: ** [11232,11234]
===
match
---
trailer [6544,6554]
trailer [6544,6554]
===
match
---
trailer [35528,35770]
trailer [35528,35770]
===
match
---
name: getuser [16027,16034]
name: getuser [16027,16034]
===
match
---
simple_stmt [31027,31065]
simple_stmt [31027,31065]
===
match
---
param [41312,41343]
param [41312,41343]
===
match
---
param [28565,28576]
param [28565,28576]
===
match
---
name: collections [906,917]
name: collections [906,917]
===
match
---
trailer [73665,73695]
trailer [73772,73802]
===
match
---
operator: = [19452,19453]
operator: = [19452,19453]
===
match
---
name: dag [18485,18488]
name: dag [18485,18488]
===
match
---
atom_expr [23407,23445]
atom_expr [23407,23445]
===
match
---
atom_expr [27034,27083]
atom_expr [27034,27083]
===
match
---
atom_expr [37940,37951]
atom_expr [37940,37951]
===
match
---
atom_expr [37373,37385]
atom_expr [37373,37385]
===
match
---
name: execution_date [15152,15166]
name: execution_date [15152,15166]
===
match
---
simple_stmt [978,1008]
simple_stmt [978,1008]
===
match
---
name: property [93281,93289]
name: property [93388,93396]
===
match
---
operator: } [37937,37938]
operator: } [37937,37938]
===
match
---
name: DAG [3932,3935]
name: DAG [3932,3935]
===
match
---
name: dag_id [86352,86358]
name: dag_id [86459,86465]
===
match
---
trailer [59781,59785]
trailer [59781,59785]
===
match
---
name: context [4007,4014]
name: context [4007,4014]
===
match
---
argument [80846,80909]
argument [80953,81016]
===
match
---
simple_stmt [56008,56064]
simple_stmt [56008,56064]
===
match
---
name: var [69909,69912]
name: var [70016,70019]
===
match
---
string: "airflow" [22129,22138]
string: "airflow" [22129,22138]
===
match
---
string: 'prev_execution_date' [76678,76699]
string: 'prev_execution_date' [76785,76806]
===
match
---
operator: = [30085,30086]
operator: = [30085,30086]
===
match
---
atom_expr [68295,68357]
atom_expr [68402,68464]
===
match
---
operator: = [16325,16326]
operator: = [16325,16326]
===
match
---
atom_expr [6927,6969]
atom_expr [6927,6969]
===
match
---
atom_expr [74704,74717]
atom_expr [74811,74824]
===
match
---
operator: , [76558,76559]
operator: , [76665,76666]
===
match
---
name: TaskInstance [24270,24282]
name: TaskInstance [24270,24282]
===
match
---
atom_expr [3824,3837]
atom_expr [3824,3837]
===
match
---
name: queue [27465,27470]
name: queue [27465,27470]
===
match
---
name: value [17227,17232]
name: value [17227,17232]
===
match
---
name: timedelta [968,977]
name: timedelta [968,977]
===
match
---
name: trigger_id [12289,12299]
name: trigger_id [12289,12299]
===
match
---
tfpdef [41266,41294]
tfpdef [41266,41294]
===
match
---
name: key [83901,83904]
name: key [84008,84011]
===
match
---
trailer [15019,15027]
trailer [15019,15027]
===
match
---
simple_stmt [60477,60509]
simple_stmt [60477,60509]
===
match
---
param [14178,14205]
param [14178,14205]
===
match
---
operator: = [83932,83933]
operator: = [84039,84040]
===
match
---
name: get_failed_dep_statuses [36762,36785]
name: get_failed_dep_statuses [36762,36785]
===
match
---
simple_stmt [93644,93663]
simple_stmt [93751,93770]
===
match
---
name: activate_dag_runs [5378,5395]
name: activate_dag_runs [5378,5395]
===
match
---
name: session [37283,37290]
name: session [37283,37290]
===
match
---
tfpdef [70676,70685]
tfpdef [70783,70792]
===
match
---
name: var [69978,69981]
name: var [70085,70088]
===
match
---
expr_stmt [44700,44735]
expr_stmt [44700,44735]
===
match
---
expr_stmt [90506,90520]
expr_stmt [90613,90627]
===
match
---
trailer [50032,50047]
trailer [50032,50047]
===
match
---
operator: = [32219,32220]
operator: = [32219,32220]
===
match
---
name: max_tries [26245,26254]
name: max_tries [26245,26254]
===
match
---
name: actual_start_date [49070,49087]
name: actual_start_date [49070,49087]
===
match
---
name: pendulum [69184,69192]
name: pendulum [69291,69299]
===
match
---
atom_expr [69225,69255]
atom_expr [69332,69362]
===
match
---
atom [77708,77816]
atom [77815,77923]
===
match
---
name: item [71149,71153]
name: item [71256,71260]
===
match
---
name: dag_run [75335,75342]
name: dag_run [75442,75449]
===
match
---
argument [80805,80832]
argument [80912,80939]
===
match
---
trailer [37551,37772]
trailer [37551,37772]
===
match
---
trailer [30322,30342]
trailer [30322,30342]
===
match
---
name: hasattr [18625,18632]
name: hasattr [18625,18632]
===
match
---
parameters [72864,72866]
parameters [72971,72973]
===
match
---
name: task [14262,14266]
name: task [14262,14266]
===
match
---
atom_expr [19173,19719]
atom_expr [19173,19719]
===
match
---
fstring_expr [72210,72217]
fstring_expr [72317,72324]
===
match
---
operator: , [1650,1651]
operator: , [1650,1651]
===
match
---
trailer [64422,64426]
trailer [64422,64426]
===
match
---
with_stmt [15504,15944]
with_stmt [15504,15944]
===
match
---
trailer [7966,7968]
trailer [7966,7968]
===
match
---
name: name [13408,13412]
name: name [13408,13412]
===
match
---
operator: = [83617,83618]
operator: = [83724,83725]
===
match
---
expr_stmt [31027,31064]
expr_stmt [31027,31064]
===
match
---
atom_expr [22682,22705]
atom_expr [22682,22705]
===
match
---
name: DeprecationWarning [8678,8696]
name: DeprecationWarning [8678,8696]
===
match
---
string: 'task_instance' [77224,77239]
string: 'task_instance' [77331,77346]
===
match
---
name: pod_override_object [80846,80865]
name: pod_override_object [80953,80972]
===
match
---
expr_stmt [62231,62252]
expr_stmt [62231,62252]
===
match
---
or_test [65359,65404]
or_test [65466,65511]
===
match
---
string: """         Returns whether or not all the conditions are met for this task instance to be run         given the context for the dependencies (e.g. a task instance being force run from         the UI will ignore some dependencies).          :param dep_context: The execution context that determines the dependencies that             should be evaluated.         :type dep_context: DepContext         :param session: database session         :type session: sqlalchemy.orm.session.Session         :param verbose: whether log details on failed dependencies on             info or debug log level         :type verbose: bool         """ [35949,36581]
string: """         Returns whether or not all the conditions are met for this task instance to be run         given the context for the dependencies (e.g. a task instance being force run from         the UI will ignore some dependencies).          :param dep_context: The execution context that determines the dependencies that             should be evaluated.         :type dep_context: DepContext         :param session: database session         :type session: sqlalchemy.orm.session.Session         :param verbose: whether log details on failed dependencies on             info or debug log level         :type verbose: bool         """ [35949,36581]
===
match
---
name: info [36695,36699]
name: info [36695,36699]
===
match
---
name: task_id [90612,90619]
name: task_id [90719,90726]
===
match
---
string: "Executing %s on %s" [47020,47040]
string: "Executing %s on %s" [47020,47040]
===
match
---
name: log [79896,79899]
name: log [80003,80006]
===
match
---
atom_expr [29052,29070]
atom_expr [29052,29070]
===
match
---
trailer [39326,39328]
trailer [39326,39328]
===
match
---
name: TaskFail [64512,64520]
name: TaskFail [64616,64624]
===
match
---
name: execution_date [23418,23432]
name: execution_date [23418,23432]
===
match
---
atom_expr [67971,67990]
atom_expr [68078,68097]
===
match
---
fstring_start: f" [77284,77286]
fstring_start: f" [77391,77393]
===
match
---
name: Column [11796,11802]
name: Column [11796,11802]
===
match
---
trailer [14237,14239]
trailer [14237,14239]
===
match
---
trailer [14301,14309]
trailer [14301,14309]
===
match
---
comparison [44751,44788]
comparison [44751,44788]
===
match
---
simple_stmt [92518,92558]
simple_stmt [92625,92665]
===
match
---
operator: , [24252,24253]
operator: , [24252,24253]
===
match
---
return_stmt [4713,4724]
return_stmt [4713,4724]
===
match
---
decorator [32404,32421]
decorator [32404,32421]
===
match
---
name: self [75520,75524]
name: self [75627,75631]
===
match
---
suite [78603,78644]
suite [78710,78751]
===
match
---
trailer [49126,49178]
trailer [49126,49178]
===
match
---
argument [61619,61630]
argument [61619,61630]
===
match
---
operator: , [64106,64107]
operator: , [64106,64107]
===
match
---
tfpdef [58860,58876]
tfpdef [58860,58876]
===
match
---
suite [14212,16408]
suite [14212,16408]
===
match
---
operator: = [19647,19648]
operator: = [19647,19648]
===
match
---
trailer [73605,73620]
trailer [73712,73727]
===
match
---
expr_stmt [43375,43390]
expr_stmt [43375,43390]
===
match
---
decorator [33462,33472]
decorator [33462,33472]
===
match
---
expr_stmt [56492,56633]
expr_stmt [56492,56633]
===
match
---
name: merge [66124,66129]
name: merge [66231,66236]
===
match
---
operator: = [11847,11848]
operator: = [11847,11848]
===
match
---
name: self [47564,47568]
name: self [47564,47568]
===
match
---
name: raw [22829,22832]
name: raw [22829,22832]
===
match
---
operator: = [40068,40069]
operator: = [40068,40069]
===
match
---
name: hasattr [18651,18658]
name: hasattr [18651,18658]
===
match
---
atom [22294,22322]
atom [22294,22322]
===
match
---
arglist [56035,56062]
arglist [56035,56062]
===
match
---
name: task_id [22164,22171]
name: task_id [22164,22171]
===
match
---
name: task [59479,59483]
name: task [59479,59483]
===
match
---
trailer [63865,63871]
trailer [63865,63871]
===
match
---
trailer [50539,50544]
trailer [50539,50544]
===
match
---
decorated [93746,93824]
decorated [93853,93931]
===
match
---
atom_expr [4383,4565]
atom_expr [4383,4565]
===
match
---
simple_stmt [50877,50894]
simple_stmt [50877,50894]
===
match
---
operator: = [73736,73737]
operator: = [73843,73844]
===
match
---
trailer [44726,44733]
trailer [44726,44733]
===
match
---
name: PodGenerator [80866,80878]
name: PodGenerator [80973,80985]
===
match
---
operator: } [37922,37923]
operator: } [37922,37923]
===
match
---
name: error [63727,63732]
name: error [63727,63732]
===
match
---
name: task_id [28165,28172]
name: task_id [28165,28172]
===
match
---
operator: == [66652,66654]
operator: == [66759,66761]
===
match
---
name: self [85124,85128]
name: self [85231,85235]
===
match
---
atom_expr [68673,68690]
atom_expr [68780,68797]
===
match
---
name: next_execution_date [73797,73816]
name: next_execution_date [73904,73923]
===
match
---
atom_expr [49547,49557]
atom_expr [49547,49557]
===
match
---
name: str [9717,9720]
name: str [9717,9720]
===
match
---
with_stmt [74493,74659]
with_stmt [74600,74766]
===
match
---
trailer [63861,63865]
trailer [63861,63865]
===
match
---
name: exception_html [81558,81572]
name: exception_html [81665,81679]
===
match
---
atom_expr [58606,58626]
atom_expr [58606,58626]
===
match
---
number: 2 [35758,35759]
number: 2 [35758,35759]
===
match
---
atom_expr [93177,93193]
atom_expr [93284,93300]
===
match
---
atom_expr [26567,26580]
atom_expr [26567,26580]
===
match
---
atom_expr [24218,24237]
atom_expr [24218,24237]
===
match
---
name: TR [44823,44825]
name: TR [44823,44825]
===
match
---
name: task [58538,58542]
name: task [58538,58542]
===
match
---
atom_expr [28963,28978]
atom_expr [28963,28978]
===
match
---
atom_expr [6371,6392]
atom_expr [6371,6392]
===
match
---
string: "-" [43637,43640]
string: "-" [43637,43640]
===
match
---
if_stmt [56455,56730]
if_stmt [56455,56730]
===
match
---
decorator [92968,92978]
decorator [93075,93085]
===
match
---
name: where [8225,8230]
name: where [8225,8230]
===
match
---
string: """         Refreshes the task instance from the database based on the primary key          :param session: SQLAlchemy ORM Session         :type session: Session         :param lock_for_update: if True, indicates that the database should             lock the TaskInstance (issuing a FOR UPDATE clause) until the             session is committed.         :type lock_for_update: bool         """ [24995,25388]
string: """         Refreshes the task instance from the database based on the primary key          :param session: SQLAlchemy ORM Session         :type session: Session         :param lock_for_update: if True, indicates that the database should             lock the TaskInstance (issuing a FOR UPDATE clause) until the             session is committed.         :type lock_for_update: bool         """ [24995,25388]
===
match
---
arglist [66417,66489]
arglist [66524,66596]
===
match
---
operator: = [18004,18005]
operator: = [18004,18005]
===
match
---
name: timeout [56980,56987]
name: timeout [56980,56987]
===
match
---
argument [45574,45586]
argument [45574,45586]
===
match
---
operator: = [20098,20099]
operator: = [20098,20099]
===
match
---
argument [13860,13873]
argument [13860,13873]
===
match
---
suite [43479,43533]
suite [43479,43533]
===
match
---
simple_stmt [51770,51844]
simple_stmt [51770,51844]
===
match
---
operator: , [2007,2008]
operator: , [2007,2008]
===
match
---
trailer [75230,75246]
trailer [75337,75353]
===
match
---
trailer [63390,63406]
trailer [63390,63406]
===
match
---
operator: , [5070,5071]
operator: , [5070,5071]
===
match
---
string: "started running, please use 'airflow tasks render' for debugging the " [78953,79024]
string: "started running, please use 'airflow tasks render' for debugging the " [79060,79131]
===
match
---
name: ignore_task_deps [45389,45405]
name: ignore_task_deps [45389,45405]
===
match
---
name: self [41064,41068]
name: self [41064,41068]
===
match
---
name: session [61868,61875]
name: session [61868,61875]
===
match
---
with_stmt [83977,84042]
with_stmt [84084,84149]
===
match
---
name: dep_context [45196,45207]
name: dep_context [45196,45207]
===
match
---
name: get_dagrun [31037,31047]
name: get_dagrun [31037,31047]
===
match
---
trailer [26797,26818]
trailer [26797,26818]
===
match
---
trailer [76830,77056]
trailer [76937,77163]
===
match
---
name: state [59444,59449]
name: state [59444,59449]
===
match
---
atom_expr [11699,11719]
atom_expr [11699,11719]
===
match
---
name: self [43451,43455]
name: self [43451,43455]
===
match
---
string: 'data_interval_start' [75608,75629]
string: 'data_interval_start' [75715,75736]
===
match
---
import_from [2888,2936]
import_from [2888,2936]
===
match
---
operator: , [67985,67986]
operator: , [68092,68093]
===
match
---
name: context [4511,4518]
name: context [4511,4518]
===
match
---
name: dr [31027,31029]
name: dr [31027,31029]
===
match
---
trailer [6292,6299]
trailer [6292,6299]
===
match
---
name: self [28918,28922]
name: self [28918,28922]
===
match
---
expr_stmt [58280,58336]
expr_stmt [58280,58336]
===
match
---
name: str [22379,22382]
name: str [22379,22382]
===
match
---
trailer [37433,37438]
trailer [37433,37438]
===
match
---
name: Optional [32522,32530]
name: Optional [32522,32530]
===
match
---
decorator [16598,16608]
decorator [16598,16608]
===
match
---
if_stmt [92566,92644]
if_stmt [92673,92751]
===
match
---
decorator [17273,17283]
decorator [17273,17283]
===
match
---
trailer [59029,59049]
trailer [59029,59049]
===
match
---
name: pendulum [1238,1246]
name: pendulum [1238,1246]
===
match
---
name: dag_id [53127,53133]
name: dag_id [53127,53133]
===
match
---
operator: = [45543,45544]
operator: = [45543,45544]
===
match
---
name: pool [27526,27530]
name: pool [27526,27530]
===
match
---
operator: = [43219,43220]
operator: = [43219,43220]
===
match
---
name: self [17221,17225]
name: self [17221,17225]
===
match
---
funcdef [72845,72952]
funcdef [72952,73059]
===
match
---
simple_stmt [2432,2477]
simple_stmt [2432,2477]
===
match
---
name: filter [40853,40859]
name: filter [40853,40859]
===
match
---
decorator [27809,27826]
decorator [27809,27826]
===
match
---
name: log [24751,24754]
name: log [24751,24754]
===
match
---
name: self [62773,62777]
name: self [62773,62777]
===
match
---
operator: == [7853,7855]
operator: == [7853,7855]
===
match
---
simple_stmt [16316,16333]
simple_stmt [16316,16333]
===
match
---
operator: = [47303,47304]
operator: = [47303,47304]
===
match
---
atom_expr [93096,93108]
atom_expr [93203,93215]
===
match
---
operator: = [68325,68326]
operator: = [68432,68433]
===
match
---
name: self [82883,82887]
name: self [82990,82994]
===
match
---
name: pendulum [34740,34748]
name: pendulum [34740,34748]
===
match
---
name: functools [983,992]
name: functools [983,992]
===
match
---
name: task [66065,66069]
name: task [66172,66176]
===
match
---
expr_stmt [9072,9363]
expr_stmt [9072,9363]
===
match
---
name: airflow [8309,8316]
name: airflow [8309,8316]
===
match
---
not_test [37793,37814]
not_test [37793,37814]
===
match
---
if_stmt [32859,32902]
if_stmt [32859,32902]
===
match
---
operator: , [14709,14710]
operator: , [14709,14710]
===
match
---
argument [13205,13241]
argument [13205,13241]
===
match
---
trailer [24386,24390]
trailer [24386,24390]
===
match
---
trailer [91383,91388]
trailer [91490,91495]
===
match
---
trailer [28506,28517]
trailer [28506,28517]
===
match
---
operator: , [13850,13851]
operator: , [13850,13851]
===
match
---
operator: = [11438,11439]
operator: = [11438,11439]
===
match
---
name: self [53709,53713]
name: self [53709,53713]
===
match
---
simple_stmt [68844,68871]
simple_stmt [68951,68978]
===
match
---
trailer [84727,84771]
trailer [84834,84878]
===
match
---
atom_expr [72894,72951]
atom_expr [73001,73058]
===
match
---
simple_stmt [2579,2633]
simple_stmt [2579,2633]
===
match
---
expr_stmt [18766,18810]
expr_stmt [18766,18810]
===
match
---
operator: = [11511,11512]
operator: = [11511,11512]
===
match
---
operator: = [80730,80731]
operator: = [80837,80838]
===
match
---
name: from_object [57765,57776]
name: from_object [57765,57776]
===
match
---
name: property [10418,10426]
name: property [10418,10426]
===
match
---
name: task_id [80658,80665]
name: task_id [80765,80772]
===
match
---
expr_stmt [84280,84356]
expr_stmt [84387,84463]
===
match
---
trailer [50684,50692]
trailer [50684,50692]
===
match
---
suite [50759,50913]
suite [50759,50913]
===
match
---
tfpdef [4588,4601]
tfpdef [4588,4601]
===
match
---
simple_stmt [49547,49574]
simple_stmt [49547,49574]
===
match
---
name: retries [27705,27712]
name: retries [27705,27712]
===
match
---
operator: , [1471,1472]
operator: , [1471,1472]
===
match
---
name: log [25402,25405]
name: log [25402,25405]
===
match
---
name: os [48963,48965]
name: os [48963,48965]
===
match
---
operator: = [61478,61479]
operator: = [61478,61479]
===
match
---
atom_expr [62902,62938]
atom_expr [62902,62938]
===
match
---
expr_stmt [88462,88518]
expr_stmt [88569,88625]
===
match
---
trailer [15957,15964]
trailer [15957,15964]
===
match
---
funcdef [34626,35262]
funcdef [34626,35262]
===
match
---
suite [6314,7077]
suite [6314,7077]
===
match
---
if_stmt [67581,67726]
if_stmt [67688,67833]
===
match
---
name: dag [31767,31770]
name: dag [31767,31770]
===
match
---
if_stmt [59508,59840]
if_stmt [59508,59840]
===
match
---
trailer [29520,29536]
trailer [29520,29536]
===
match
---
atom_expr [62262,62285]
atom_expr [62262,62285]
===
match
---
simple_stmt [27034,27084]
simple_stmt [27034,27084]
===
match
---
param [84434,84439]
param [84541,84546]
===
match
---
name: self [62871,62875]
name: self [62871,62875]
===
match
---
simple_stmt [72778,72821]
simple_stmt [72885,72928]
===
match
---
name: context [53700,53707]
name: context [53700,53707]
===
match
---
number: 1 [64337,64338]
number: 1 [64337,64338]
===
match
---
expr_stmt [8440,8468]
expr_stmt [8440,8468]
===
match
---
number: 0 [90518,90519]
number: 0 [90625,90626]
===
match
---
simple_stmt [17916,17944]
simple_stmt [17916,17944]
===
match
---
operator: @ [19725,19726]
operator: @ [19725,19726]
===
match
---
expr_stmt [25465,25662]
expr_stmt [25465,25662]
===
match
---
name: clear_task_instances [5330,5350]
name: clear_task_instances [5330,5350]
===
match
---
name: pickle_id [19569,19578]
name: pickle_id [19569,19578]
===
match
---
comparison [17077,17104]
comparison [17077,17104]
===
match
---
import_from [1305,1486]
import_from [1305,1486]
===
match
---
name: dag_id [13626,13632]
name: dag_id [13626,13632]
===
match
---
name: warnings [8516,8524]
name: warnings [8516,8524]
===
match
---
name: str [93003,93006]
name: str [93110,93113]
===
match
---
name: end_date [25932,25940]
name: end_date [25932,25940]
===
match
---
suite [45588,46175]
suite [45588,46175]
===
match
---
trailer [17096,17104]
trailer [17096,17104]
===
match
---
string: "Setting task state for %s to %s" [28862,28895]
string: "Setting task state for %s to %s" [28862,28895]
===
match
---
string: '' [65865,65867]
string: '' [65972,65974]
===
match
---
operator: , [60972,60973]
operator: , [60972,60973]
===
match
---
operator: = [56025,56026]
operator: = [56025,56026]
===
match
---
return_stmt [4799,4810]
return_stmt [4799,4810]
===
match
---
name: strftime [47219,47227]
name: strftime [47219,47227]
===
match
---
suite [51323,51706]
suite [51323,51706]
===
match
---
operator: , [76664,76665]
operator: , [76771,76772]
===
match
---
name: current_state [23794,23807]
name: current_state [23794,23807]
===
match
---
argument [80767,80791]
argument [80874,80898]
===
match
---
operator: } [23306,23307]
operator: } [23306,23307]
===
match
---
arglist [81536,81548]
arglist [81643,81655]
===
match
---
trailer [56727,56729]
trailer [56727,56729]
===
match
---
name: Exception [51722,51731]
name: Exception [51722,51731]
===
match
---
simple_stmt [50307,50324]
simple_stmt [50307,50324]
===
match
---
name: Optional [63427,63435]
name: Optional [63427,63435]
===
match
---
argument [67709,67724]
argument [67816,67831]
===
match
---
name: self [63857,63861]
name: self [63857,63861]
===
match
---
name: ignore_depends_on_past [41266,41288]
name: ignore_depends_on_past [41266,41288]
===
match
---
name: iso [23401,23404]
name: iso [23401,23404]
===
match
---
name: provide_session [24516,24531]
name: provide_session [24516,24531]
===
match
---
name: self [24546,24550]
name: self [24546,24550]
===
match
---
operator: , [71495,71496]
operator: , [71602,71603]
===
match
---
name: get_template_context [59995,60015]
name: get_template_context [59995,60015]
===
match
---
operator: = [76646,76647]
operator: = [76753,76754]
===
match
---
argument [63807,63821]
argument [63807,63821]
===
match
---
string: """Returns TaskInstanceKey with provided ``try_number``""" [10270,10328]
string: """Returns TaskInstanceKey with provided ``try_number``""" [10270,10328]
===
match
---
suite [49191,49574]
suite [49191,49574]
===
match
---
operator: , [66472,66473]
operator: , [66579,66580]
===
match
---
name: self [57926,57930]
name: self [57926,57930]
===
match
---
name: get_tomorrow_ds [77440,77455]
name: get_tomorrow_ds [77547,77562]
===
match
---
operator: @ [93598,93599]
operator: @ [93705,93706]
===
match
---
suite [63700,64115]
suite [63700,64115]
===
match
---
atom_expr [47318,47730]
atom_expr [47318,47730]
===
match
---
atom_expr [47564,47576]
atom_expr [47564,47576]
===
match
---
operator: - [84928,84929]
operator: - [85035,85036]
===
match
---
string: "--ignore-all-dependencies" [22445,22472]
string: "--ignore-all-dependencies" [22445,22472]
===
match
---
name: session [29216,29223]
name: session [29216,29223]
===
match
---
name: ignore_param_exceptions [66956,66979]
name: ignore_param_exceptions [67063,67086]
===
match
---
name: get_dagrun [67328,67338]
name: get_dagrun [67435,67445]
===
match
---
atom [23525,23763]
atom [23525,23763]
===
match
---
operator: -> [66994,66996]
operator: -> [67101,67103]
===
match
---
trailer [49317,49338]
trailer [49317,49338]
===
match
---
name: task [43134,43138]
name: task [43134,43138]
===
match
---
operator: , [20145,20146]
operator: , [20145,20146]
===
match
---
operator: , [75385,75386]
operator: , [75492,75493]
===
match
---
trailer [60960,60965]
trailer [60960,60965]
===
match
---
expr_stmt [55537,55573]
expr_stmt [55537,55573]
===
match
---
param [17978,17983]
param [17978,17983]
===
match
---
name: inspect [1455,1462]
name: inspect [1455,1462]
===
match
---
argument [82924,82948]
argument [83031,83055]
===
match
---
operator: , [86370,86371]
operator: , [86477,86478]
===
match
---
name: state [6985,6990]
name: state [6985,6990]
===
match
---
not_test [64126,64139]
not_test [64126,64139]
===
match
---
name: var [69730,69733]
name: var [69837,69840]
===
match
---
name: dag_id [14253,14259]
name: dag_id [14253,14259]
===
match
---
name: dt [31572,31574]
name: dt [31572,31574]
===
match
---
simple_stmt [8854,8920]
simple_stmt [8854,8920]
===
match
---
string: 'next_execution_date' [76130,76151]
string: 'next_execution_date' [76237,76258]
===
match
---
name: self [39224,39228]
name: self [39224,39228]
===
match
---
atom_expr [32269,32321]
atom_expr [32269,32321]
===
match
---
dotted_name [93940,93960]
dotted_name [94047,94067]
===
match
---
trailer [46136,46143]
trailer [46136,46143]
===
match
---
operator: { [23272,23273]
operator: { [23272,23273]
===
match
---
name: self [28160,28164]
name: self [28160,28164]
===
match
---
operator: , [13107,13108]
operator: , [13107,13108]
===
match
---
classdef [9606,10570]
classdef [9606,10570]
===
match
---
operator: , [81602,81603]
operator: , [81709,81710]
===
match
---
simple_stmt [51667,51684]
simple_stmt [51667,51684]
===
match
---
trailer [29479,29485]
trailer [29479,29485]
===
match
---
name: self [80045,80049]
name: self [80152,80156]
===
match
---
simple_stmt [47082,47094]
simple_stmt [47082,47094]
===
match
---
trailer [60015,60017]
trailer [60015,60017]
===
match
---
strings [82198,82487]
strings [82305,82594]
===
match
---
dotted_name [3607,3637]
dotted_name [3607,3637]
===
match
---
trailer [92748,92771]
trailer [92855,92878]
===
match
---
atom_expr [5911,5969]
atom_expr [5911,5969]
===
match
---
trailer [83461,83482]
trailer [83568,83589]
===
match
---
trailer [53453,53459]
trailer [53453,53459]
===
match
---
suite [37439,37853]
suite [37439,37853]
===
match
---
fstring [23638,23662]
fstring [23638,23662]
===
match
---
trailer [62021,62023]
trailer [62021,62023]
===
match
---
name: property [35268,35276]
name: property [35268,35276]
===
match
---
trailer [62806,62818]
trailer [62806,62818]
===
match
---
suite [69708,69741]
suite [69815,69848]
===
match
---
atom_expr [43129,43138]
atom_expr [43129,43138]
===
match
---
trailer [40919,40923]
trailer [40919,40923]
===
match
---
simple_stmt [62993,63030]
simple_stmt [62993,63030]
===
match
---
atom_expr [74296,74315]
atom_expr [74403,74422]
===
match
---
operator: + [40137,40138]
operator: + [40137,40138]
===
match
---
trailer [57386,57421]
trailer [57386,57421]
===
match
---
parameters [35312,35318]
parameters [35312,35318]
===
match
---
name: self [89923,89927]
name: self [90030,90034]
===
match
---
atom_expr [9532,9559]
atom_expr [9532,9559]
===
match
---
simple_stmt [41623,43114]
simple_stmt [41623,43114]
===
match
---
name: task [30080,30084]
name: task [30080,30084]
===
match
---
expr_stmt [65707,65738]
expr_stmt [65814,65845]
===
match
---
simple_stmt [49386,49429]
simple_stmt [49386,49429]
===
match
---
simple_stmt [61556,61563]
simple_stmt [61556,61563]
===
match
---
expr_stmt [12040,12074]
expr_stmt [12040,12074]
===
match
---
atom_expr [30487,30495]
atom_expr [30487,30495]
===
match
---
trailer [56987,57004]
trailer [56987,57004]
===
match
---
operator: , [18668,18669]
operator: , [18668,18669]
===
match
---
name: ignore_task_deps [19383,19399]
name: ignore_task_deps [19383,19399]
===
match
---
trailer [73760,73781]
trailer [73867,73888]
===
match
---
name: state [35082,35087]
name: state [35082,35087]
===
match
---
operator: , [27121,27122]
operator: , [27121,27122]
===
match
---
name: self [23058,23062]
name: self [23058,23062]
===
match
---
name: iso [23657,23660]
name: iso [23657,23660]
===
match
---
name: pickle_id [20073,20082]
name: pickle_id [20073,20082]
===
match
---
name: Integer [11675,11682]
name: Integer [11675,11682]
===
match
---
name: ID_LEN [11224,11230]
name: ID_LEN [11224,11230]
===
match
---
trailer [69192,69201]
trailer [69299,69308]
===
match
---
name: self [28847,28851]
name: self [28847,28851]
===
match
---
atom_expr [44169,44296]
atom_expr [44169,44296]
===
match
---
operator: = [61157,61158]
operator: = [61157,61158]
===
match
---
name: self [16385,16389]
name: self [16385,16389]
===
match
---
name: task [18701,18705]
name: task [18701,18705]
===
match
---
operator: == [25539,25541]
operator: == [25539,25541]
===
match
---
name: self [52113,52117]
name: self [52113,52117]
===
match
---
operator: / [19117,19118]
operator: / [19117,19118]
===
match
---
operator: , [13679,13680]
operator: , [13679,13680]
===
match
---
decorated [72830,72952]
decorated [72937,73059]
===
match
---
trailer [65544,65551]
trailer [65651,65658]
===
match
---
decorator [63315,63332]
decorator [63315,63332]
===
match
---
trailer [55013,55015]
trailer [55013,55015]
===
match
---
simple_stmt [75033,75045]
simple_stmt [75140,75152]
===
match
---
trailer [37541,37545]
trailer [37541,37545]
===
match
---
operator: , [18041,18042]
operator: , [18041,18042]
===
match
---
operator: -> [93459,93461]
operator: -> [93566,93568]
===
match
---
name: SENSING [54964,54971]
name: SENSING [54964,54971]
===
match
---
string: "--mark-success" [22230,22246]
string: "--mark-success" [22230,22246]
===
match
---
atom [22913,22936]
atom [22913,22936]
===
match
---
name: task [27440,27444]
name: task [27440,27444]
===
match
---
operator: , [19520,19521]
operator: , [19520,19521]
===
match
---
tfpdef [4944,4959]
tfpdef [4944,4959]
===
match
---
operator: , [5372,5373]
operator: , [5372,5373]
===
match
---
name: ignore_all_deps [43940,43955]
name: ignore_all_deps [43940,43955]
===
match
---
trailer [82736,82981]
trailer [82843,83088]
===
match
---
atom_expr [49013,49032]
atom_expr [49013,49032]
===
match
---
string: 'inlets' [75658,75666]
string: 'inlets' [75765,75773]
===
match
---
arglist [28462,28517]
arglist [28462,28517]
===
match
---
simple_stmt [47144,47197]
simple_stmt [47144,47197]
===
match
---
operator: , [64546,64547]
operator: , [64653,64654]
===
match
---
name: String [11706,11712]
name: String [11706,11712]
===
match
---
trailer [12618,12632]
trailer [12618,12632]
===
match
---
name: stacklevel [8710,8720]
name: stacklevel [8710,8720]
===
match
---
name: mark_success [19299,19311]
name: mark_success [19299,19311]
===
match
---
return_stmt [84058,84119]
return_stmt [84165,84226]
===
match
---
fstring_string: dag. [52837,52841]
fstring_string: dag. [52837,52841]
===
match
---
operator: { [49138,49139]
operator: { [49138,49139]
===
match
---
simple_stmt [26947,26981]
simple_stmt [26947,26981]
===
match
---
trailer [46223,46228]
trailer [46223,46228]
===
match
---
trailer [5121,5132]
trailer [5121,5132]
===
match
---
name: ti [92220,92222]
name: ti [92327,92329]
===
match
---
name: queue [26495,26500]
name: queue [26495,26500]
===
match
---
name: validate [67939,67947]
name: validate [68046,68054]
===
match
---
expr_stmt [92333,92371]
expr_stmt [92440,92478]
===
match
---
param [86640,86667]
param [86747,86774]
===
match
---
simple_stmt [3380,3443]
simple_stmt [3380,3443]
===
match
---
trailer [26378,26385]
trailer [26378,26385]
===
match
---
name: data_interval [68851,68864]
name: data_interval [68958,68971]
===
match
---
trailer [62609,62616]
trailer [62609,62616]
===
match
---
trailer [51972,51980]
trailer [51972,51980]
===
match
---
name: DagRun [14506,14512]
name: DagRun [14506,14512]
===
match
---
atom_expr [75335,75362]
atom_expr [75442,75469]
===
match
---
string: 'prev_ds' [76519,76528]
string: 'prev_ds' [76626,76635]
===
match
---
name: v [53417,53418]
name: v [53417,53418]
===
match
---
import_as_names [3475,3493]
import_as_names [3475,3493]
===
match
---
atom_expr [24270,24290]
atom_expr [24270,24290]
===
match
---
trailer [34092,34097]
trailer [34092,34097]
===
match
---
atom_expr [63857,63884]
atom_expr [63857,63884]
===
match
---
argument [62064,62075]
argument [62064,62075]
===
match
---
atom_expr [63667,63681]
atom_expr [63667,63681]
===
match
---
name: get_next_ds [75751,75762]
name: get_next_ds [75858,75869]
===
match
---
return_stmt [69327,69377]
return_stmt [69434,69484]
===
match
---
operator: = [77926,77927]
operator: = [78033,78034]
===
match
---
argument [28186,28220]
argument [28186,28220]
===
match
---
trailer [11674,11683]
trailer [11674,11683]
===
match
---
operator: , [59221,59222]
operator: , [59221,59222]
===
match
---
name: mark_success [19312,19324]
name: mark_success [19312,19324]
===
match
---
name: str [70682,70685]
name: str [70789,70792]
===
match
---
atom_expr [66295,66309]
atom_expr [66402,66416]
===
match
---
trailer [59693,59713]
trailer [59693,59713]
===
match
---
if_stmt [31128,31749]
if_stmt [31128,31749]
===
match
---
name: start_date [9439,9449]
name: start_date [9439,9449]
===
match
---
simple_stmt [61055,61078]
simple_stmt [61055,61078]
===
match
---
name: log [46345,46348]
name: log [46345,46348]
===
match
---
name: task [84733,84737]
name: task [84840,84844]
===
match
---
string: 'ti_dag_state' [12799,12813]
string: 'ti_dag_state' [12799,12813]
===
match
---
name: get_previous_ti [33959,33974]
name: get_previous_ti [33959,33974]
===
match
---
number: 1 [10167,10168]
number: 1 [10167,10168]
===
match
---
name: job_id [61760,61766]
name: job_id [61760,61766]
===
match
---
operator: = [39094,39095]
operator: = [39094,39095]
===
match
---
name: ti_hash [39086,39093]
name: ti_hash [39086,39093]
===
match
---
trailer [91960,91982]
trailer [92067,92089]
===
match
---
param [93309,93313]
param [93416,93420]
===
match
---
if_stmt [64385,64581]
if_stmt [64385,64688]
===
match
---
name: self [52232,52236]
name: self [52232,52236]
===
match
---
operator: , [71022,71023]
operator: , [71129,71130]
===
match
---
return_stmt [31006,31017]
return_stmt [31006,31017]
===
match
---
if_stmt [74031,74086]
if_stmt [74138,74193]
===
match
---
param [24955,24976]
param [24955,24976]
===
match
---
trailer [55037,55043]
trailer [55037,55043]
===
match
---
import_from [1889,1927]
import_from [1889,1927]
===
match
---
name: jinja2 [83006,83012]
name: jinja2 [83113,83119]
===
match
---
operator: , [83581,83582]
operator: , [83688,83689]
===
match
---
trailer [59217,59233]
trailer [59217,59233]
===
match
---
name: self [59853,59857]
name: self [59853,59857]
===
match
---
name: self [25883,25887]
name: self [25883,25887]
===
match
---
atom_expr [76701,76769]
atom_expr [76808,76876]
===
match
---
name: get_previous_dagrun [30580,30599]
name: get_previous_dagrun [30580,30599]
===
match
---
trailer [93181,93193]
trailer [93288,93300]
===
match
---
comparison [91191,91220]
comparison [91298,91327]
===
match
---
operator: , [19834,19835]
operator: , [19834,19835]
===
match
---
atom [89024,89178]
atom [89131,89285]
===
match
---
atom_expr [47006,47073]
atom_expr [47006,47073]
===
match
---
name: start_date [84935,84945]
name: start_date [85042,85052]
===
match
---
name: self [35055,35059]
name: self [35055,35059]
===
match
---
operator: @ [57449,57450]
operator: @ [57449,57450]
===
match
---
name: execute [8259,8266]
name: execute [8259,8266]
===
match
---
name: State [24823,24828]
name: State [24823,24828]
===
match
---
trailer [27525,27530]
trailer [27525,27530]
===
match
---
operator: , [72815,72816]
operator: , [72922,72923]
===
match
---
string: "Task received SIGTERM signal" [52627,52657]
string: "Task received SIGTERM signal" [52627,52657]
===
match
---
trailer [93993,94007]
trailer [94100,94114]
===
match
---
simple_stmt [59689,59723]
simple_stmt [59689,59723]
===
match
---
trailer [62063,62076]
trailer [62063,62076]
===
match
---
expr_stmt [26195,26227]
expr_stmt [26195,26227]
===
match
---
trailer [34413,34417]
trailer [34413,34417]
===
match
---
atom_expr [27492,27501]
atom_expr [27492,27501]
===
match
---
atom_expr [67224,67232]
atom_expr [67331,67339]
===
match
---
trailer [68494,68496]
trailer [68601,68603]
===
match
---
trailer [90140,90159]
trailer [90247,90266]
===
match
---
number: 20 [11588,11590]
number: 20 [11588,11590]
===
match
---
simple_stmt [3271,3314]
simple_stmt [3271,3314]
===
match
---
operator: = [4762,4763]
operator: = [4762,4763]
===
match
---
operator: = [22126,22127]
operator: = [22126,22127]
===
match
---
simple_stmt [92609,92644]
simple_stmt [92716,92751]
===
match
---
name: dag_id [90530,90536]
name: dag_id [90637,90643]
===
match
---
name: task_id [37930,37937]
name: task_id [37930,37937]
===
match
---
suite [59756,59840]
suite [59756,59840]
===
match
---
name: Optional [47979,47987]
name: Optional [47979,47987]
===
match
---
simple_stmt [37306,37336]
simple_stmt [37306,37336]
===
match
---
string: "--raw" [22858,22865]
string: "--raw" [22858,22865]
===
match
---
suite [74948,75089]
suite [75055,75196]
===
match
---
simple_stmt [68100,68157]
simple_stmt [68207,68264]
===
match
---
atom_expr [30380,30391]
atom_expr [30380,30391]
===
match
---
name: Optional [66295,66303]
name: Optional [66402,66410]
===
match
---
name: task_ids [7938,7946]
name: task_ids [7938,7946]
===
match
---
operator: @ [33462,33463]
operator: @ [33462,33463]
===
match
---
operator: = [30175,30176]
operator: = [30175,30176]
===
match
---
name: task [83794,83798]
name: task [83901,83905]
===
match
---
name: log [15016,15019]
name: log [15016,15019]
===
match
---
name: _pool [93487,93492]
name: _pool [93594,93599]
===
match
---
param [55242,55251]
param [55242,55251]
===
match
---
name: dag_run [67717,67724]
name: dag_run [67824,67831]
===
match
---
operator: , [30650,30651]
operator: , [30650,30651]
===
match
---
arglist [48799,48828]
arglist [48799,48828]
===
match
---
name: session [50848,50855]
name: session [50848,50855]
===
match
---
name: in_ [91027,91030]
name: in_ [91134,91137]
===
match
---
simple_stmt [45693,45976]
simple_stmt [45693,45976]
===
match
---
name: self [84794,84798]
name: self [84901,84905]
===
match
---
name: self [80691,80695]
name: self [80798,80802]
===
match
---
operator: , [77599,77600]
operator: , [77706,77707]
===
match
---
simple_stmt [32387,32399]
simple_stmt [32387,32399]
===
match
---
atom_expr [48913,48926]
atom_expr [48913,48926]
===
match
---
decorated [90037,91856]
decorated [90144,91963]
===
match
---
name: state [92448,92453]
name: state [92555,92560]
===
match
---
trailer [9180,9233]
trailer [9180,9233]
===
match
---
name: self [17243,17247]
name: self [17243,17247]
===
match
---
name: Column [11298,11304]
name: Column [11298,11304]
===
match
---
simple_stmt [65673,65695]
simple_stmt [65780,65802]
===
match
---
name: total_seconds [38574,38587]
name: total_seconds [38574,38587]
===
match
---
name: value [17262,17267]
name: value [17262,17267]
===
match
---
atom_expr [47153,47178]
atom_expr [47153,47178]
===
match
---
name: ignore_depends_on_past [45349,45371]
name: ignore_depends_on_past [45349,45371]
===
match
---
operator: = [15999,16000]
operator: = [15999,16000]
===
match
---
name: provide_session [27810,27825]
name: provide_session [27810,27825]
===
match
---
operator: = [61504,61505]
operator: = [61504,61505]
===
match
---
expr_stmt [11656,11683]
expr_stmt [11656,11683]
===
match
---
operator: , [18227,18228]
operator: , [18227,18228]
===
match
---
name: NO_VALUE [40700,40708]
name: NO_VALUE [40700,40708]
===
match
---
expr_stmt [3780,3804]
expr_stmt [3780,3804]
===
match
---
atom_expr [92855,92863]
atom_expr [92962,92970]
===
match
---
suite [68275,68358]
suite [68382,68465]
===
match
---
simple_stmt [70787,70803]
simple_stmt [70894,70910]
===
match
---
simple_stmt [37886,37970]
simple_stmt [37886,37970]
===
match
---
return_stmt [90883,91069]
return_stmt [90990,91176]
===
match
---
operator: , [12821,12822]
operator: , [12821,12822]
===
match
---
atom_expr [55024,55043]
atom_expr [55024,55043]
===
match
---
atom_expr [60276,60285]
atom_expr [60276,60285]
===
match
---
name: pod_mutation_hook [81134,81151]
name: pod_mutation_hook [81241,81258]
===
match
---
name: task [54735,54739]
name: task [54735,54739]
===
match
---
trailer [24443,24449]
trailer [24443,24449]
===
match
---
atom_expr [18917,18948]
atom_expr [18917,18948]
===
match
---
trailer [15460,15475]
trailer [15460,15475]
===
match
---
name: self [93067,93071]
name: self [93174,93178]
===
match
---
trailer [54963,54971]
trailer [54963,54971]
===
match
---
name: str [86619,86622]
name: str [86726,86729]
===
match
---
arglist [39892,39938]
arglist [39892,39938]
===
match
---
string: 'macros' [75693,75701]
string: 'macros' [75800,75808]
===
match
---
atom_expr [52045,52058]
atom_expr [52045,52058]
===
match
---
string: "DagModel" [18503,18513]
string: "DagModel" [18503,18513]
===
match
---
atom_expr [32522,32546]
atom_expr [32522,32546]
===
match
---
name: ignore_task_deps [45406,45422]
name: ignore_task_deps [45406,45422]
===
match
---
suite [17318,17824]
suite [17318,17824]
===
match
---
name: airflow [93940,93947]
name: airflow [94047,94054]
===
match
---
name: AirflowRescheduleException [2043,2069]
name: AirflowRescheduleException [2043,2069]
===
match
---
name: set [5963,5966]
name: set [5963,5966]
===
match
---
suite [53775,54437]
suite [53775,54437]
===
match
---
operator: , [75540,75541]
operator: , [75647,75648]
===
match
---
import_from [3443,3493]
import_from [3443,3493]
===
match
---
simple_stmt [85275,85896]
simple_stmt [85382,86003]
===
match
---
operator: = [18157,18158]
operator: = [18157,18158]
===
match
---
return_stmt [93644,93662]
return_stmt [93751,93769]
===
match
---
trailer [15027,15185]
trailer [15027,15185]
===
match
---
name: render_templates [80028,80044]
name: render_templates [80135,80151]
===
match
---
name: queued_by_job_id [26680,26696]
name: queued_by_job_id [26680,26696]
===
match
---
name: self [80233,80237]
name: self [80340,80344]
===
match
---
atom_expr [93981,94007]
atom_expr [94088,94114]
===
match
---
name: prev_ds [75064,75071]
name: prev_ds [75171,75178]
===
match
---
name: _executor_config [92467,92483]
name: _executor_config [92574,92590]
===
match
---
simple_stmt [74541,74593]
simple_stmt [74648,74700]
===
match
---
name: Column [11668,11674]
name: Column [11668,11674]
===
match
---
if_stmt [61532,61563]
if_stmt [61532,61563]
===
match
---
operator: = [75767,75768]
operator: = [75874,75875]
===
match
---
name: session [43260,43267]
name: session [43260,43267]
===
match
---
operator: , [19253,19254]
operator: , [19253,19254]
===
match
---
suite [15537,15944]
suite [15537,15944]
===
match
---
name: dr [9436,9438]
name: dr [9436,9438]
===
match
---
name: verbose [60681,60688]
name: verbose [60681,60688]
===
match
---
operator: , [62367,62368]
operator: , [62367,62368]
===
match
---
name: ConnectionAccessor [71218,71236]
name: ConnectionAccessor [71325,71343]
===
match
---
trailer [53409,53462]
trailer [53409,53462]
===
match
---
trailer [62922,62938]
trailer [62922,62938]
===
match
---
name: defer [49740,49745]
name: defer [49740,49745]
===
match
---
return_stmt [73010,73051]
return_stmt [73117,73158]
===
match
---
param [20005,20035]
param [20005,20035]
===
match
---
operator: @ [9945,9946]
operator: @ [9945,9946]
===
match
---
simple_stmt [62231,62253]
simple_stmt [62231,62253]
===
match
---
raise_stmt [78726,79101]
raise_stmt [78833,79208]
===
match
---
operator: -> [74701,74703]
operator: -> [74808,74810]
===
match
---
operator: , [64525,64526]
operator: , [64629,64630]
===
match
---
name: SUCCESS [61956,61963]
name: SUCCESS [61956,61963]
===
match
---
name: timezone [3005,3013]
name: timezone [3005,3013]
===
match
---
operator: , [83684,83685]
operator: , [83791,83792]
===
match
---
name: stats [2741,2746]
name: stats [2741,2746]
===
match
---
string: 'Mark success: <a href="{{ti.mark_success_url}}">Link</a><br>' [82425,82487]
string: 'Mark success: <a href="{{ti.mark_success_url}}">Link</a><br>' [82532,82594]
===
match
---
operator: , [43922,43923]
operator: , [43922,43923]
===
match
---
atom_expr [34731,34758]
atom_expr [34731,34758]
===
match
---
name: str [20235,20238]
name: str [20235,20238]
===
match
---
trailer [59713,59722]
trailer [59713,59722]
===
match
---
name: ti [92855,92857]
name: ti [92962,92964]
===
match
---
name: BaseJob [8338,8345]
name: BaseJob [8338,8345]
===
match
---
atom_expr [46340,46368]
atom_expr [46340,46368]
===
match
---
name: self [9914,9918]
name: self [9914,9918]
===
match
---
name: job_id [61454,61460]
name: job_id [61454,61460]
===
match
---
atom_expr [44960,44986]
atom_expr [44960,44986]
===
match
---
name: and_ [1435,1439]
name: and_ [1435,1439]
===
match
---
operator: = [49251,49252]
operator: = [49251,49252]
===
match
---
trailer [63229,63231]
trailer [63229,63231]
===
match
---
operator: -> [68416,68418]
operator: -> [68523,68525]
===
match
---
name: self [72895,72899]
name: self [73002,73006]
===
match
---
name: dag [15309,15312]
name: dag [15309,15312]
===
match
---
trailer [84854,84863]
trailer [84961,84970]
===
match
---
trailer [20234,20239]
trailer [20234,20239]
===
match
---
parameters [74928,74930]
parameters [75035,75037]
===
match
---
import_name [787,804]
import_name [787,804]
===
match
---
name: log [46257,46260]
name: log [46257,46260]
===
match
---
operator: = [17260,17261]
operator: = [17260,17261]
===
match
---
operator: = [9450,9451]
operator: = [9450,9451]
===
match
---
trailer [57051,57068]
trailer [57051,57068]
===
match
---
name: ti [26298,26300]
name: ti [26298,26300]
===
match
---
name: run_ids_by_dag_id [9277,9294]
name: run_ids_by_dag_id [9277,9294]
===
match
---
operator: = [11609,11610]
operator: = [11609,11610]
===
match
---
expr_stmt [73976,74018]
expr_stmt [74083,74125]
===
match
---
trailer [39228,39243]
trailer [39228,39243]
===
match
---
atom_expr [17091,17104]
atom_expr [17091,17104]
===
match
---
and_test [65880,65910]
and_test [65987,66017]
===
match
---
operator: = [84297,84298]
operator: = [84404,84405]
===
match
---
atom_expr [93338,93354]
atom_expr [93445,93461]
===
match
---
name: session [52171,52178]
name: session [52171,52178]
===
match
---
operator: = [65472,65473]
operator: = [65579,65580]
===
match
---
name: debug [34997,35002]
name: debug [34997,35002]
===
match
---
atom_expr [59486,59495]
atom_expr [59486,59495]
===
match
---
expr_stmt [84519,84602]
expr_stmt [84626,84709]
===
match
---
atom_expr [80005,80017]
atom_expr [80112,80124]
===
match
---
operator: , [1981,1982]
operator: , [1981,1982]
===
match
---
operator: = [11476,11477]
operator: = [11476,11477]
===
match
---
simple_stmt [9007,9063]
simple_stmt [9007,9063]
===
match
---
trailer [93870,93876]
trailer [93977,93983]
===
match
---
trailer [30369,30376]
trailer [30369,30376]
===
match
---
simple_stmt [68544,68556]
simple_stmt [68651,68663]
===
match
---
name: log [52503,52506]
name: log [52503,52506]
===
match
---
atom_expr [74386,74410]
atom_expr [74493,74517]
===
match
---
name: property [17274,17282]
name: property [17274,17282]
===
match
---
name: items [78501,78506]
name: items [78608,78613]
===
match
---
comparison [90814,90832]
comparison [90921,90939]
===
match
---
name: hostname [26287,26295]
name: hostname [26287,26295]
===
match
---
name: e [51597,51598]
name: e [51597,51598]
===
match
---
name: expected_state [4293,4307]
name: expected_state [4293,4307]
===
match
---
name: self [47688,47692]
name: self [47688,47692]
===
match
---
simple_stmt [62109,62149]
simple_stmt [62109,62149]
===
match
---
parameters [81288,81305]
parameters [81395,81412]
===
match
---
simple_stmt [50239,50246]
simple_stmt [50239,50246]
===
match
---
trailer [86062,86240]
trailer [86169,86347]
===
match
---
expr_stmt [50666,50692]
expr_stmt [50666,50692]
===
match
---
argument [13455,13473]
argument [13455,13473]
===
match
---
name: XCom [28096,28100]
name: XCom [28096,28100]
===
match
---
name: self [43307,43311]
name: self [43307,43311]
===
match
---
name: airflow [2984,2991]
name: airflow [2984,2991]
===
match
---
comp_op [58255,58261]
comp_op [58255,58261]
===
match
---
atom_expr [71838,71882]
atom_expr [71945,71989]
===
match
---
atom_expr [50139,50149]
atom_expr [50139,50149]
===
match
---
trailer [74562,74592]
trailer [74669,74699]
===
match
---
operator: = [26624,26625]
operator: = [26624,26625]
===
match
---
operator: = [19353,19354]
operator: = [19353,19354]
===
match
---
suite [51757,51891]
suite [51757,51891]
===
match
---
arith_expr [58787,58822]
arith_expr [58787,58822]
===
match
---
operator: = [36602,36603]
operator: = [36602,36603]
===
match
---
simple_stmt [29468,29539]
simple_stmt [29468,29539]
===
match
---
name: AirflowSensorTimeout [2075,2095]
name: AirflowSensorTimeout [2075,2095]
===
match
---
name: Optional [69175,69183]
name: Optional [69282,69290]
===
match
---
suite [80094,80275]
suite [80201,80382]
===
match
---
atom_expr [28502,28517]
atom_expr [28502,28517]
===
match
---
name: dag [67229,67232]
name: dag [67336,67339]
===
match
---
comparison [59853,59880]
comparison [59853,59880]
===
match
---
atom_expr [27460,27470]
atom_expr [27460,27470]
===
match
---
trailer [68018,68028]
trailer [68125,68135]
===
match
---
operator: = [82549,82550]
operator: = [82656,82657]
===
match
---
atom_expr [15299,15321]
atom_expr [15299,15321]
===
match
---
name: timeout_seconds [56988,57003]
name: timeout_seconds [56988,57003]
===
match
---
atom_expr [78471,78508]
atom_expr [78578,78615]
===
match
---
name: get_tomorrow_ds_nodash [77528,77550]
name: get_tomorrow_ds_nodash [77635,77657]
===
match
---
operator: , [77550,77551]
operator: , [77657,77658]
===
match
---
atom_expr [52113,52132]
atom_expr [52113,52132]
===
match
---
suite [65405,65496]
suite [65512,65603]
===
match
---
name: state [27012,27017]
name: state [27012,27017]
===
match
---
string: 'execution_date' [47610,47626]
string: 'execution_date' [47610,47626]
===
match
---
simple_stmt [89533,89580]
simple_stmt [89640,89687]
===
match
---
name: session [36819,36826]
name: session [36819,36826]
===
match
---
trailer [23578,23586]
trailer [23578,23586]
===
match
---
operator: , [61008,61009]
operator: , [61008,61009]
===
match
---
name: refresh_from_db [48843,48858]
name: refresh_from_db [48843,48858]
===
match
---
name: staticmethod [69997,70009]
name: staticmethod [70104,70116]
===
match
---
operator: = [51209,51210]
operator: = [51209,51210]
===
match
---
arglist [70234,70263]
arglist [70341,70370]
===
match
---
name: AirflowNotFoundException [2013,2037]
name: AirflowNotFoundException [2013,2037]
===
match
---
name: Union [18490,18495]
name: Union [18490,18495]
===
match
---
simple_stmt [92836,92864]
simple_stmt [92943,92971]
===
match
---
name: models [2490,2496]
name: models [2490,2496]
===
match
---
trailer [69365,69376]
trailer [69472,69483]
===
match
---
atom [22229,22247]
atom [22229,22247]
===
match
---
argument [88606,88613]
argument [88713,88720]
===
match
---
trailer [90012,90025]
trailer [90119,90132]
===
match
---
simple_stmt [28269,28305]
simple_stmt [28269,28305]
===
match
---
operator: , [51609,51610]
operator: , [51609,51610]
===
match
---
name: deprecated_proxy [76606,76622]
name: deprecated_proxy [76713,76729]
===
match
---
trailer [72107,72113]
trailer [72214,72220]
===
match
---
name: TaskDeferred [49589,49601]
name: TaskDeferred [49589,49601]
===
match
---
operator: , [4624,4625]
operator: , [4624,4625]
===
match
---
subscriptlist [86565,86583]
subscriptlist [86672,86690]
===
match
---
name: task_reschedule [44806,44821]
name: task_reschedule [44806,44821]
===
match
---
trailer [46106,46112]
trailer [46106,46112]
===
match
---
trailer [47322,47326]
trailer [47322,47326]
===
match
---
name: task [14109,14113]
name: task [14109,14113]
===
match
---
name: ID_LEN [11312,11318]
name: ID_LEN [11312,11318]
===
match
---
name: execution_date [85996,86010]
name: execution_date [86103,86117]
===
match
---
name: jinja_context [84105,84118]
name: jinja_context [84212,84225]
===
match
---
operator: = [19311,19312]
operator: = [19311,19312]
===
match
---
tfpdef [85227,85243]
tfpdef [85334,85350]
===
match
---
simple_stmt [46340,46369]
simple_stmt [46340,46369]
===
match
---
name: defer [58022,58027]
name: defer [58022,58027]
===
match
---
name: self [46252,46256]
name: self [46252,46256]
===
match
---
name: __init__ [92119,92127]
name: __init__ [92226,92234]
===
match
---
operator: { [58083,58084]
operator: { [58083,58084]
===
match
---
name: Column [1334,1340]
name: Column [1334,1340]
===
match
---
atom_expr [43465,43478]
atom_expr [43465,43478]
===
match
---
expr_stmt [59894,59910]
expr_stmt [59894,59910]
===
match
---
name: pool [26413,26417]
name: pool [26413,26417]
===
match
---
name: self [18659,18663]
name: self [18659,18663]
===
match
---
operator: , [13191,13192]
operator: , [13191,13192]
===
match
---
trailer [51863,51870]
trailer [51863,51870]
===
match
---
trailer [92286,92298]
trailer [92393,92405]
===
match
---
operator: = [61732,61733]
operator: = [61732,61733]
===
match
---
expr_stmt [18690,18709]
expr_stmt [18690,18709]
===
match
---
name: self [26653,26657]
name: self [26653,26657]
===
match
---
name: Optional [86610,86618]
name: Optional [86717,86725]
===
match
---
atom_expr [13117,13284]
atom_expr [13117,13284]
===
match
---
name: job_id [20182,20188]
name: job_id [20182,20188]
===
match
---
operator: , [58876,58877]
operator: , [58876,58877]
===
match
---
trailer [5302,5307]
trailer [5302,5307]
===
match
---
name: start_date [54985,54995]
name: start_date [54985,54995]
===
match
---
trailer [80887,80909]
trailer [80994,81016]
===
match
---
atom_expr [30704,30722]
atom_expr [30704,30722]
===
match
---
testlist [84373,84412]
testlist [84480,84519]
===
match
---
name: task [60281,60285]
name: task [60281,60285]
===
match
---
name: task [54638,54642]
name: task [54638,54642]
===
match
---
operator: , [13027,13028]
operator: , [13027,13028]
===
match
---
operator: = [27863,27864]
operator: = [27863,27864]
===
match
---
operator: = [19863,19864]
operator: = [19863,19864]
===
match
---
name: FAILED [51511,51517]
name: FAILED [51511,51517]
===
match
---
if_stmt [8807,9604]
if_stmt [8807,9604]
===
match
---
trailer [56164,56176]
trailer [56164,56176]
===
match
---
sync_comp_for [8125,8170]
sync_comp_for [8125,8170]
===
match
---
name: ignore_param_exceptions [49339,49362]
name: ignore_param_exceptions [49339,49362]
===
match
---
name: ignore_ti_state [45456,45471]
name: ignore_ti_state [45456,45471]
===
match
---
operator: , [47122,47123]
operator: , [47122,47123]
===
match
---
name: render_templates [78625,78641]
name: render_templates [78732,78748]
===
match
---
name: dep_status [37736,37746]
name: dep_status [37736,37746]
===
match
---
atom_expr [71562,71606]
atom_expr [71669,71713]
===
match
---
funcdef [84777,85075]
funcdef [84884,85182]
===
match
---
trailer [89720,89727]
trailer [89827,89834]
===
match
---
return_stmt [44347,44359]
return_stmt [44347,44359]
===
match
---
name: self [78118,78122]
name: self [78225,78229]
===
match
---
operator: @ [93199,93200]
operator: @ [93306,93307]
===
match
---
trailer [53316,53320]
trailer [53316,53320]
===
match
---
trailer [75864,76014]
trailer [75971,76121]
===
match
---
operator: , [8722,8723]
operator: , [8722,8723]
===
match
---
simple_stmt [67999,68031]
simple_stmt [68106,68138]
===
match
---
name: default_var [70964,70975]
name: default_var [71071,71082]
===
match
---
name: State [46454,46459]
name: State [46454,46459]
===
match
---
atom_expr [25640,25651]
atom_expr [25640,25651]
===
match
---
string: """Get the email subject content for exceptions.""" [81315,81366]
string: """Get the email subject content for exceptions.""" [81422,81473]
===
match
---
not_test [50092,50105]
not_test [50092,50105]
===
match
---
operator: , [41450,41451]
operator: , [41450,41451]
===
match
---
name: total_seconds [56714,56727]
name: total_seconds [56714,56727]
===
match
---
testlist_comp [50929,50971]
testlist_comp [50929,50971]
===
match
---
string: """Write error into error file by path""" [5004,5045]
string: """Write error into error file by path""" [5004,5045]
===
match
---
suite [91149,91355]
suite [91256,91462]
===
match
---
atom_expr [70983,71022]
atom_expr [71090,71129]
===
match
---
param [18216,18228]
param [18216,18228]
===
match
---
operator: = [83241,83242]
operator: = [83348,83349]
===
match
---
name: execution_date [15435,15449]
name: execution_date [15435,15449]
===
match
---
name: session [86719,86726]
name: session [86826,86833]
===
match
---
name: self [65418,65422]
name: self [65525,65529]
===
match
---
name: result [57414,57420]
name: result [57414,57420]
===
match
---
operator: = [19828,19829]
operator: = [19828,19829]
===
match
---
operator: , [51197,51198]
operator: , [51197,51198]
===
match
---
operator: , [9810,9811]
operator: , [9810,9811]
===
match
---
name: task_id [10141,10148]
name: task_id [10141,10148]
===
match
---
operator: = [26255,26256]
operator: = [26255,26256]
===
match
---
suite [32547,32973]
suite [32547,32973]
===
match
---
operator: = [18105,18106]
operator: = [18105,18106]
===
match
---
atom_expr [68004,68030]
atom_expr [68111,68137]
===
match
---
trailer [93486,93492]
trailer [93593,93599]
===
match
---
atom_expr [58764,58784]
atom_expr [58764,58784]
===
match
---
trailer [8266,8278]
trailer [8266,8278]
===
match
---
parameters [23807,23827]
parameters [23807,23827]
===
match
---
funcdef [83831,84120]
funcdef [83938,84227]
===
match
---
name: dag [75152,75155]
name: dag [75259,75262]
===
match
---
name: delay [38568,38573]
name: delay [38568,38573]
===
match
---
simple_stmt [79891,79979]
simple_stmt [79998,80086]
===
match
---
name: in_ [30424,30427]
name: in_ [30424,30427]
===
match
---
atom_expr [86610,86623]
atom_expr [86717,86730]
===
match
---
argument [66474,66489]
argument [66581,66596]
===
match
---
atom_expr [31595,31614]
atom_expr [31595,31614]
===
match
---
expr_stmt [29142,29207]
expr_stmt [29142,29207]
===
match
---
name: total_seconds [29192,29205]
name: total_seconds [29192,29205]
===
match
---
param [58878,58882]
param [58878,58882]
===
match
---
trailer [56541,56559]
trailer [56541,56559]
===
match
---
operator: == [9499,9501]
operator: == [9499,9501]
===
match
---
param [14103,14108]
param [14103,14108]
===
match
---
operator: = [16548,16549]
operator: = [16548,16549]
===
match
---
name: REQUEUEABLE_DEPS [45243,45259]
name: REQUEUEABLE_DEPS [45243,45259]
===
match
---
name: dep_status [37040,37050]
name: dep_status [37040,37050]
===
match
---
atom [50928,50972]
atom [50928,50972]
===
match
---
param [66956,66992]
param [67063,67099]
===
match
---
name: max_tries [45943,45952]
name: max_tries [45943,45952]
===
match
---
trailer [62303,62311]
trailer [62303,62311]
===
match
---
name: AttributeError [67455,67469]
name: AttributeError [67562,67576]
===
match
---
simple_stmt [93564,93593]
simple_stmt [93671,93700]
===
match
---
operator: = [25981,25982]
operator: = [25981,25982]
===
match
---
trailer [16071,16077]
trailer [16071,16077]
===
match
---
name: self [37925,37929]
name: self [37925,37929]
===
match
---
name: task_id [19246,19253]
name: task_id [19246,19253]
===
match
---
name: execution_date [75525,75539]
name: execution_date [75632,75646]
===
match
---
operator: , [35891,35892]
operator: , [35891,35892]
===
match
---
tfpdef [47824,47842]
tfpdef [47824,47842]
===
match
---
name: ti [26448,26450]
name: ti [26448,26450]
===
match
---
operator: , [22154,22155]
operator: , [22154,22155]
===
match
---
arglist [49496,49533]
arglist [49496,49533]
===
match
---
trailer [70741,70770]
trailer [70848,70877]
===
match
---
name: render [84214,84220]
name: render [84321,84327]
===
match
---
operator: @ [47736,47737]
operator: @ [47736,47737]
===
match
---
trailer [32211,32228]
trailer [32211,32228]
===
match
---
name: self [85018,85022]
name: self [85125,85129]
===
match
---
atom_expr [36757,36827]
atom_expr [36757,36827]
===
match
---
trailer [35249,35260]
trailer [35249,35260]
===
match
---
param [17312,17316]
param [17312,17316]
===
match
---
classdef [69415,70265]
classdef [69522,70372]
===
match
---
name: info [46349,46353]
name: info [46349,46353]
===
match
---
name: session [61497,61504]
name: session [61497,61504]
===
match
---
funcdef [80024,80275]
funcdef [80131,80382]
===
match
---
argument [32309,32320]
argument [32309,32320]
===
match
---
trailer [4231,4240]
trailer [4231,4240]
===
match
---
name: self [37424,37428]
name: self [37424,37428]
===
match
---
string: 'webserver' [23474,23485]
string: 'webserver' [23474,23485]
===
match
---
atom_expr [54980,54995]
atom_expr [54980,54995]
===
match
---
argument [67694,67707]
argument [67801,67814]
===
match
---
atom_expr [50594,50653]
atom_expr [50594,50653]
===
match
---
funcdef [74150,74316]
funcdef [74257,74423]
===
match
---
trailer [7141,7153]
trailer [7141,7153]
===
match
---
string: """Fetch rendered template fields from DB""" [78147,78191]
string: """Fetch rendered template fields from DB""" [78254,78298]
===
match
---
name: self [52187,52191]
name: self [52187,52191]
===
match
---
name: task [75668,75672]
name: task [75775,75779]
===
match
---
operator: , [11639,11640]
operator: , [11639,11640]
===
match
---
name: self [17125,17129]
name: self [17125,17129]
===
match
---
raise_stmt [52604,52658]
raise_stmt [52604,52658]
===
match
---
trailer [26657,26674]
trailer [26657,26674]
===
match
---
arglist [33718,33928]
arglist [33718,33928]
===
match
---
name: dagrun [68457,68463]
name: dagrun [68564,68570]
===
match
---
trailer [34583,34598]
trailer [34583,34598]
===
match
---
name: ti [91503,91505]
name: ti [91610,91612]
===
match
---
expr_stmt [56113,56177]
expr_stmt [56113,56177]
===
match
---
atom_expr [64351,64376]
atom_expr [64351,64376]
===
match
---
arith_expr [83665,83684]
arith_expr [83772,83791]
===
match
---
name: self [51475,51479]
name: self [51475,51479]
===
match
---
name: self [15205,15209]
name: self [15205,15209]
===
match
---
name: SUCCESS [59873,59880]
name: SUCCESS [59873,59880]
===
match
---
name: dag_run [67313,67320]
name: dag_run [67420,67427]
===
match
---
atom_expr [24872,24888]
atom_expr [24872,24888]
===
match
---
arglist [7664,8098]
arglist [7664,8098]
===
match
---
name: t [91139,91140]
name: t [91246,91247]
===
match
---
operator: = [80690,80691]
operator: = [80797,80798]
===
match
---
trailer [48780,48798]
trailer [48780,48798]
===
match
---
trailer [58318,58320]
trailer [58318,58320]
===
match
---
trailer [8077,8079]
trailer [8077,8079]
===
match
---
trailer [26922,26934]
trailer [26922,26934]
===
match
---
arglist [71149,71201]
arglist [71256,71308]
===
match
---
simple_stmt [50174,50194]
simple_stmt [50174,50194]
===
match
---
simple_stmt [69303,69315]
simple_stmt [69410,69422]
===
match
---
name: state [65712,65717]
name: state [65819,65824]
===
match
---
expr_stmt [92239,92273]
expr_stmt [92346,92380]
===
match
---
name: Exception [4626,4635]
name: Exception [4626,4635]
===
match
---
simple_stmt [1148,1179]
simple_stmt [1148,1179]
===
match
---
name: net [3180,3183]
name: net [3180,3183]
===
match
---
trailer [54895,54936]
trailer [54895,54936]
===
match
---
name: Iterable [86570,86578]
name: Iterable [86677,86685]
===
match
---
operator: , [11337,11338]
operator: , [11337,11338]
===
match
---
operator: = [36797,36798]
operator: = [36797,36798]
===
match
---
name: generate_command [19186,19202]
name: generate_command [19186,19202]
===
match
---
name: self [58606,58610]
name: self [58606,58610]
===
match
---
atom [13177,13191]
atom [13177,13191]
===
match
---
atom_expr [80888,80908]
atom_expr [80995,81015]
===
match
---
trailer [17129,17141]
trailer [17129,17141]
===
match
---
import_from [1928,2242]
import_from [1928,2242]
===
match
---
operator: = [75607,75608]
operator: = [75714,75715]
===
match
---
name: test_mode [64392,64401]
name: test_mode [64392,64401]
===
match
---
atom_expr [6455,6481]
atom_expr [6455,6481]
===
match
---
trailer [8230,8242]
trailer [8230,8242]
===
match
---
funcdef [16432,16593]
funcdef [16432,16593]
===
match
---
string: """         The execution date from property previous_ti_success.          :param state: If passed, it only take into account instances of a specific state.         :param session: SQLAlchemy ORM Session         """ [34185,34400]
string: """         The execution date from property previous_ti_success.          :param state: If passed, it only take into account instances of a specific state.         :param session: SQLAlchemy ORM Session         """ [34185,34400]
===
match
---
trailer [53677,53699]
trailer [53677,53699]
===
match
---
trailer [84643,84648]
trailer [84750,84755]
===
match
---
tfpdef [66284,66309]
tfpdef [66391,66416]
===
match
---
argument [61680,61705]
argument [61680,61705]
===
match
---
trailer [22692,22705]
trailer [22692,22705]
===
match
---
atom_expr [67435,67470]
atom_expr [67542,67577]
===
match
---
name: str [22307,22310]
name: str [22307,22310]
===
match
---
trailer [12844,12874]
trailer [12844,12874]
===
match
---
trailer [84149,84186]
trailer [84256,84293]
===
match
---
name: extend [22605,22611]
name: extend [22605,22611]
===
match
---
name: Column [11611,11617]
name: Column [11611,11617]
===
match
---
name: pod_generator [3684,3697]
name: pod_generator [3684,3697]
===
match
---
param [62410,62426]
param [62410,62426]
===
match
---
name: dag_id [40882,40888]
name: dag_id [40882,40888]
===
match
---
trailer [46907,46971]
trailer [46907,46971]
===
match
---
name: or_ [1468,1471]
name: or_ [1468,1471]
===
match
---
operator: , [45879,45880]
operator: , [45879,45880]
===
match
---
name: add [7138,7141]
name: add [7138,7141]
===
match
---
trailer [49052,49059]
trailer [49052,49059]
===
match
---
trailer [45531,45587]
trailer [45531,45587]
===
match
---
operator: = [11277,11278]
operator: = [11277,11278]
===
match
---
import_from [93935,93975]
import_from [94042,94082]
===
match
---
parameters [66222,66379]
parameters [66329,66486]
===
match
---
operator: , [61400,61401]
operator: , [61400,61401]
===
match
---
argument [53016,53023]
argument [53016,53023]
===
match
---
funcdef [14081,16408]
funcdef [14081,16408]
===
match
---
atom [29158,29191]
atom [29158,29191]
===
match
---
name: conf [23465,23469]
name: conf [23465,23469]
===
match
---
name: len [30520,30523]
name: len [30520,30523]
===
match
---
string: """             This attribute is deprecated.             Please use `airflow.models.taskinstance.TaskInstance.get_previous_start_date` method.             """ [35542,35701]
string: """             This attribute is deprecated.             Please use `airflow.models.taskinstance.TaskInstance.get_previous_start_date` method.             """ [35542,35701]
===
match
---
if_stmt [14410,15944]
if_stmt [14410,15944]
===
match
---
atom_expr [25883,25898]
atom_expr [25883,25898]
===
match
---
trailer [36761,36785]
trailer [36761,36785]
===
match
---
name: session [66148,66155]
name: session [66255,66262]
===
match
---
name: context [59050,59057]
name: context [59050,59057]
===
match
---
name: dag_id [25532,25538]
name: dag_id [25532,25538]
===
match
---
operator: == [91500,91502]
operator: == [91607,91609]
===
match
---
name: self [58048,58052]
name: self [58048,58052]
===
match
---
operator: , [91568,91569]
operator: , [91675,91676]
===
match
---
trailer [84638,84678]
trailer [84745,84785]
===
match
---
name: job_id [18216,18222]
name: job_id [18216,18222]
===
match
---
simple_stmt [2694,2728]
simple_stmt [2694,2728]
===
match
---
name: job_id [19641,19647]
name: job_id [19641,19647]
===
match
---
atom_expr [14355,14364]
atom_expr [14355,14364]
===
match
---
arglist [80553,81106]
arglist [80660,81213]
===
match
---
atom [56510,56617]
atom [56510,56617]
===
match
---
name: test_mode [50567,50576]
name: test_mode [50567,50576]
===
match
---
trailer [51265,51267]
trailer [51265,51267]
===
match
---
simple_stmt [9708,9721]
simple_stmt [9708,9721]
===
match
---
name: dispose [46803,46810]
name: dispose [46803,46810]
===
match
---
atom_expr [26793,26818]
atom_expr [26793,26818]
===
match
---
suite [93715,93741]
suite [93822,93848]
===
match
---
tfpdef [20073,20097]
tfpdef [20073,20097]
===
match
---
atom_expr [39117,39328]
atom_expr [39117,39328]
===
match
---
operator: == [90979,90981]
operator: == [91086,91088]
===
match
---
name: ignore_ti_state [22653,22668]
name: ignore_ti_state [22653,22668]
===
match
---
trailer [7838,7893]
trailer [7838,7893]
===
match
---
name: task_id_by_key [5894,5908]
name: task_id_by_key [5894,5908]
===
match
---
trailer [53592,53604]
trailer [53592,53604]
===
match
---
atom_expr [10387,10398]
atom_expr [10387,10398]
===
match
---
operator: , [78047,78048]
operator: , [78154,78155]
===
match
---
trailer [22228,22248]
trailer [22228,22248]
===
match
---
name: self [69851,69855]
name: self [69958,69962]
===
match
---
name: self [63667,63671]
name: self [63667,63671]
===
match
---
name: self [93651,93655]
name: self [93758,93762]
===
match
---
trailer [10127,10134]
trailer [10127,10134]
===
match
---
name: execution_date [15246,15260]
name: execution_date [15246,15260]
===
match
---
name: test_mode [47860,47869]
name: test_mode [47860,47869]
===
match
---
trailer [63726,63744]
trailer [63726,63744]
===
match
---
trailer [50181,50187]
trailer [50181,50187]
===
match
---
atom_expr [14282,14294]
atom_expr [14282,14294]
===
match
---
operator: = [81179,81180]
operator: = [81286,81287]
===
match
---
dotted_name [2733,2746]
dotted_name [2733,2746]
===
match
---
name: actual_start_date [50796,50813]
name: actual_start_date [50796,50813]
===
match
---
operator: = [89932,89933]
operator: = [90039,90040]
===
match
---
string: "Received SIGTERM. Terminating subprocesses." [52513,52558]
string: "Received SIGTERM. Terminating subprocesses." [52513,52558]
===
match
---
atom_expr [64500,64580]
atom_expr [64604,64687]
===
match
---
param [62427,62439]
param [62427,62439]
===
match
---
trailer [50795,50864]
trailer [50795,50864]
===
match
---
name: verbose [36703,36710]
name: verbose [36703,36710]
===
match
---
name: task_id [86318,86325]
name: task_id [86425,86432]
===
match
---
trailer [86558,86585]
trailer [86665,86692]
===
match
---
trailer [65904,65910]
trailer [66011,66017]
===
match
---
trailer [77177,77184]
trailer [77284,77291]
===
match
---
name: Exception [66264,66273]
name: Exception [66371,66380]
===
match
---
operator: = [11365,11366]
operator: = [11365,11366]
===
match
---
atom_expr [80866,80909]
atom_expr [80973,81016]
===
match
---
atom_expr [62871,62884]
atom_expr [62871,62884]
===
match
---
trailer [15303,15308]
trailer [15303,15308]
===
match
---
dotted_name [3209,3239]
dotted_name [3209,3239]
===
match
---
argument [76944,76977]
argument [77051,77084]
===
match
---
param [47289,47307]
param [47289,47307]
===
match
---
atom_expr [15585,15725]
atom_expr [15585,15725]
===
match
---
simple_stmt [80507,81117]
simple_stmt [80614,81224]
===
match
---
name: sqlalchemy [1310,1320]
name: sqlalchemy [1310,1320]
===
match
---
atom_expr [32467,32480]
atom_expr [32467,32480]
===
match
---
operator: , [3935,3936]
operator: , [3935,3936]
===
match
---
name: should_pass_filepath [18766,18786]
name: should_pass_filepath [18766,18786]
===
match
---
atom_expr [8516,8733]
atom_expr [8516,8733]
===
match
---
decorator [54799,54816]
decorator [54799,54816]
===
match
---
name: max_tries [11656,11665]
name: max_tries [11656,11665]
===
match
---
return_stmt [74853,74896]
return_stmt [74960,75003]
===
match
---
name: mark_success [61388,61400]
name: mark_success [61388,61400]
===
match
---
name: ignore_task_deps [19965,19981]
name: ignore_task_deps [19965,19981]
===
match
---
name: models [8867,8873]
name: models [8867,8873]
===
match
---
trailer [69358,69377]
trailer [69465,69484]
===
match
---
sync_comp_for [89237,89260]
sync_comp_for [89344,89367]
===
match
---
trailer [15308,15312]
trailer [15308,15312]
===
match
---
name: task_id [91760,91767]
name: task_id [91867,91874]
===
match
---
name: str [20302,20305]
name: str [20302,20305]
===
match
---
name: modded_hash [39435,39446]
name: modded_hash [39435,39446]
===
match
---
atom [13358,13394]
atom [13358,13394]
===
match
---
expr_stmt [53918,53982]
expr_stmt [53918,53982]
===
match
---
trailer [46344,46348]
trailer [46344,46348]
===
match
---
operator: = [15261,15262]
operator: = [15261,15262]
===
match
---
operator: , [19369,19370]
operator: , [19369,19370]
===
match
---
argument [34514,34529]
argument [34514,34529]
===
match
---
return_stmt [17150,17177]
return_stmt [17150,17177]
===
match
---
operator: = [12148,12149]
operator: = [12148,12149]
===
match
---
argument [19534,19545]
argument [19534,19545]
===
match
---
try_stmt [84611,84772]
try_stmt [84718,84879]
===
match
---
trailer [92631,92643]
trailer [92738,92750]
===
match
---
expr_stmt [84989,85009]
expr_stmt [85096,85116]
===
match
---
name: merge [63195,63200]
name: merge [63195,63200]
===
match
---
funcdef [92115,92891]
funcdef [92222,92998]
===
match
---
atom_expr [60988,61001]
atom_expr [60988,61001]
===
match
---
operator: = [90604,90605]
operator: = [90711,90712]
===
match
---
simple_stmt [54945,54972]
simple_stmt [54945,54972]
===
match
---
operator: = [67364,67365]
operator: = [67471,67472]
===
match
---
name: self [55227,55231]
name: self [55227,55231]
===
match
---
atom_expr [29100,29113]
atom_expr [29100,29113]
===
match
---
name: getLogger [14375,14384]
name: getLogger [14375,14384]
===
match
---
funcdef [66190,66540]
funcdef [66297,66647]
===
match
---
operator: { [89024,89025]
operator: { [89131,89132]
===
match
---
name: task_id [52871,52878]
name: task_id [52871,52878]
===
match
---
simple_stmt [83777,83818]
simple_stmt [83884,83925]
===
match
---
operator: , [54857,54858]
operator: , [54857,54858]
===
match
---
param [81289,81294]
param [81396,81401]
===
match
---
name: _try_number [93343,93354]
name: _try_number [93450,93461]
===
match
---
simple_stmt [67654,67726]
simple_stmt [67761,67833]
===
match
---
operator: , [77635,77636]
operator: , [77742,77743]
===
match
---
trailer [16034,16036]
trailer [16034,16036]
===
match
---
testlist_comp [22914,22935]
testlist_comp [22914,22935]
===
match
---
name: provide_session [35842,35857]
name: provide_session [35842,35857]
===
match
---
decorator [93668,93678]
decorator [93775,93785]
===
match
---
name: construct_pod [80526,80539]
name: construct_pod [80633,80646]
===
match
---
operator: = [26964,26965]
operator: = [26964,26965]
===
match
---
name: key [28328,28331]
name: key [28328,28331]
===
match
---
name: self [70569,70573]
name: self [70676,70680]
===
match
---
operator: = [57033,57034]
operator: = [57033,57034]
===
match
---
arglist [37491,37517]
arglist [37491,37517]
===
match
---
trailer [12091,12100]
trailer [12091,12100]
===
match
---
expr [37405,37438]
expr [37405,37438]
===
match
---
trailer [44755,44761]
trailer [44755,44761]
===
match
---
name: conf [1923,1927]
name: conf [1923,1927]
===
match
---
operator: ** [83294,83296]
operator: ** [83401,83403]
===
match
---
name: property [93115,93123]
name: property [93222,93230]
===
match
---
not_test [4781,4789]
not_test [4781,4789]
===
match
---
name: AttributeError [31516,31530]
name: AttributeError [31516,31530]
===
match
---
string: "Failed to register in sensor service." [54079,54118]
string: "Failed to register in sensor service." [54079,54118]
===
match
---
name: item [69809,69813]
name: item [69916,69920]
===
match
---
name: self [53122,53126]
name: self [53122,53126]
===
match
---
name: session [46635,46642]
name: session [46635,46642]
===
match
---
name: in_ [9220,9223]
name: in_ [9220,9223]
===
match
---
name: self [88479,88483]
name: self [88586,88590]
===
match
---
name: run_id [8042,8048]
name: run_id [8042,8048]
===
match
---
name: str [23831,23834]
name: str [23831,23834]
===
match
---
arglist [54896,54935]
arglist [54896,54935]
===
match
---
operator: = [86736,86737]
operator: = [86843,86844]
===
match
---
decorated [3956,4566]
decorated [3956,4566]
===
match
---
trailer [31720,31729]
trailer [31720,31729]
===
match
---
operator: == [30517,30519]
operator: == [30517,30519]
===
match
---
simple_stmt [50666,50693]
simple_stmt [50666,50693]
===
match
---
name: jinja2 [83049,83055]
name: jinja2 [83156,83162]
===
match
---
name: task_id [92223,92230]
name: task_id [92330,92337]
===
match
---
name: session [32956,32963]
name: session [32956,32963]
===
match
---
name: closed [4697,4703]
name: closed [4697,4703]
===
match
---
name: self [62036,62040]
name: self [62036,62040]
===
match
---
simple_stmt [22846,22868]
simple_stmt [22846,22868]
===
match
---
atom_expr [9801,9821]
atom_expr [9801,9821]
===
match
---
simple_stmt [52668,52714]
simple_stmt [52668,52714]
===
match
---
trailer [67199,67204]
trailer [67306,67311]
===
match
---
try_stmt [53893,54255]
try_stmt [53893,54255]
===
match
---
expr_stmt [26947,26980]
expr_stmt [26947,26980]
===
match
---
name: inlets [75673,75679]
name: inlets [75780,75786]
===
match
---
trailer [49495,49534]
trailer [49495,49534]
===
match
---
name: conf [67584,67588]
name: conf [67691,67695]
===
match
---
fstring_expr [79675,79678]
fstring_expr [79782,79785]
===
match
---
funcdef [23790,24510]
funcdef [23790,24510]
===
match
---
try_stmt [3537,3759]
try_stmt [3537,3759]
===
match
---
trailer [26743,26759]
trailer [26743,26759]
===
match
---
operator: , [37495,37496]
operator: , [37495,37496]
===
match
---
param [60911,60935]
param [60911,60935]
===
match
---
trailer [25505,25662]
trailer [25505,25662]
===
match
---
name: ignore_all_deps [18020,18035]
name: ignore_all_deps [18020,18035]
===
match
---
argument [31697,31733]
argument [31697,31733]
===
match
---
atom_expr [75247,75272]
atom_expr [75354,75379]
===
match
---
simple_stmt [53491,53531]
simple_stmt [53491,53531]
===
match
---
name: render [83390,83396]
name: render [83497,83503]
===
match
---
trailer [59857,59863]
trailer [59857,59863]
===
match
---
simple_stmt [84366,84413]
simple_stmt [84473,84520]
===
match
---
name: state [32309,32314]
name: state [32309,32314]
===
match
---
trailer [90894,91069]
trailer [91001,91176]
===
match
---
name: self [80560,80564]
name: self [80667,80671]
===
match
---
atom_expr [90088,90126]
atom_expr [90195,90233]
===
match
---
suite [8507,8802]
suite [8507,8802]
===
match
---
suite [85266,86477]
suite [85373,86584]
===
match
---
operator: = [67750,67751]
operator: = [67857,67858]
===
match
---
name: reschedule_date [62923,62938]
name: reschedule_date [62923,62938]
===
match
---
name: session [48009,48016]
name: session [48009,48016]
===
match
---
arglist [14047,14074]
arglist [14047,14074]
===
match
---
if_stmt [30106,30163]
if_stmt [30106,30163]
===
match
---
operator: @ [78064,78065]
operator: @ [78171,78172]
===
match
---
trailer [89048,89056]
trailer [89155,89163]
===
match
---
simple_stmt [63240,63310]
simple_stmt [63240,63310]
===
match
---
name: warn [33180,33184]
name: warn [33180,33184]
===
match
---
trailer [64263,64276]
trailer [64263,64276]
===
match
---
param [61018,61031]
param [61018,61031]
===
match
---
name: test_mode [50096,50105]
name: test_mode [50096,50105]
===
match
---
string: "--ignore-dependencies" [22528,22551]
string: "--ignore-dependencies" [22528,22551]
===
match
---
name: Optional [92537,92545]
name: Optional [92644,92652]
===
match
---
operator: , [89927,89928]
operator: , [90034,90035]
===
match
---
argument [28152,28172]
argument [28152,28172]
===
match
---
name: Variable [2570,2578]
name: Variable [2570,2578]
===
match
---
name: tis [91668,91671]
name: tis [91775,91778]
===
match
---
if_stmt [22946,23008]
if_stmt [22946,23008]
===
match
---
string: '-' [68131,68134]
string: '-' [68238,68241]
===
match
---
name: task_id [30215,30222]
name: task_id [30215,30222]
===
match
---
name: Trigger [57686,57693]
name: Trigger [57686,57693]
===
match
---
operator: += [72394,72396]
operator: += [72501,72503]
===
match
---
name: TaskInstance [30245,30257]
name: TaskInstance [30245,30257]
===
match
---
name: commit [55060,55066]
name: commit [55060,55066]
===
match
---
name: state [26012,26017]
name: state [26012,26017]
===
match
---
trailer [22221,22228]
trailer [22221,22228]
===
match
---
subscriptlist [9807,9820]
subscriptlist [9807,9820]
===
match
---
name: sqlalchemy [1554,1564]
name: sqlalchemy [1554,1564]
===
match
---
trailer [4620,4636]
trailer [4620,4636]
===
match
---
trailer [90544,90551]
trailer [90651,90658]
===
match
---
atom_expr [89058,89088]
atom_expr [89165,89195]
===
match
---
simple_stmt [13715,13905]
simple_stmt [13715,13905]
===
match
---
name: ignore_depends_on_past [61224,61246]
name: ignore_depends_on_past [61224,61246]
===
match
---
trailer [67564,67571]
trailer [67671,67678]
===
match
---
trailer [15644,15695]
trailer [15644,15695]
===
match
---
operator: = [19948,19949]
operator: = [19948,19949]
===
match
---
name: state [8444,8449]
name: state [8444,8449]
===
match
---
arith_expr [58671,58706]
arith_expr [58671,58706]
===
match
---
operator: = [58531,58532]
operator: = [58531,58532]
===
match
---
trailer [13137,13284]
trailer [13137,13284]
===
match
---
number: 1000 [11749,11753]
number: 1000 [11749,11753]
===
match
---
not_test [8745,8766]
not_test [8745,8766]
===
match
---
if_stmt [51472,51706]
if_stmt [51472,51706]
===
match
---
operator: , [76926,76927]
operator: , [77033,77034]
===
match
---
name: key [92887,92890]
name: key [92994,92997]
===
match
---
name: self [29038,29042]
name: self [29038,29042]
===
match
---
atom_expr [4835,4853]
atom_expr [4835,4853]
===
match
---
atom_expr [31758,31764]
atom_expr [31758,31764]
===
match
---
comparison [90837,90855]
comparison [90944,90962]
===
match
---
name: bool [19858,19862]
name: bool [19858,19862]
===
match
---
operator: = [47876,47877]
operator: = [47876,47877]
===
match
---
atom_expr [9452,9469]
atom_expr [9452,9469]
===
match
---
suite [58884,59158]
suite [58884,59158]
===
match
---
name: self [83457,83461]
name: self [83564,83568]
===
match
---
name: contextmanager [3968,3982]
name: contextmanager [3968,3982]
===
match
---
name: task [27604,27608]
name: task [27604,27608]
===
match
---
name: rendered_k8s_spec [79316,79333]
name: rendered_k8s_spec [79423,79440]
===
match
---
atom [22366,22391]
atom [22366,22391]
===
match
---
string: 'dag' [75145,75150]
string: 'dag' [75252,75257]
===
match
---
classdef [91985,93824]
classdef [92092,93931]
===
match
---
name: dag_id [30258,30264]
name: dag_id [30258,30264]
===
match
---
comparison [30357,30391]
comparison [30357,30391]
===
match
---
for_stmt [37452,37853]
for_stmt [37452,37853]
===
match
---
name: TYPE_CHECKING [3882,3895]
name: TYPE_CHECKING [3882,3895]
===
match
---
name: state [47512,47517]
name: state [47512,47517]
===
match
---
simple_stmt [14012,14076]
simple_stmt [14012,14076]
===
match
---
fstring_start: f" [23236,23238]
fstring_start: f" [23236,23238]
===
match
---
atom_expr [50772,50864]
atom_expr [50772,50864]
===
match
---
operator: } [23285,23286]
operator: } [23285,23286]
===
match
---
atom_expr [91031,91040]
atom_expr [91138,91147]
===
match
---
param [85176,85218]
param [85283,85325]
===
match
---
atom_expr [30524,30548]
atom_expr [30524,30548]
===
match
---
parameters [37870,37876]
parameters [37870,37876]
===
match
---
atom_expr [53433,53461]
atom_expr [53433,53461]
===
match
---
atom_expr [40860,40873]
atom_expr [40860,40873]
===
match
---
name: conf [83934,83938]
name: conf [84041,84045]
===
match
---
argument [91454,91671]
argument [91561,91778]
===
match
---
operator: = [11944,11945]
operator: = [11944,11945]
===
match
---
name: force_fail [66326,66336]
name: force_fail [66433,66443]
===
match
---
simple_stmt [46093,46113]
simple_stmt [46093,46113]
===
match
---
trailer [61955,61963]
trailer [61955,61963]
===
match
---
suite [93244,93275]
suite [93351,93382]
===
match
---
simple_stmt [4713,4725]
simple_stmt [4713,4725]
===
match
---
atom_expr [24324,24343]
atom_expr [24324,24343]
===
match
---
name: warnings [74498,74506]
name: warnings [74605,74613]
===
match
---
operator: -> [4603,4605]
operator: -> [4603,4605]
===
match
---
operator: , [41302,41303]
operator: , [41302,41303]
===
match
---
operator: , [20210,20211]
operator: , [20210,20211]
===
match
---
number: 16 [39346,39348]
number: 16 [39346,39348]
===
match
---
param [70964,71023]
param [71071,71130]
===
match
---
name: task_copy [57124,57133]
name: task_copy [57124,57133]
===
match
---
name: session [30660,30667]
name: session [30660,30667]
===
match
---
simple_stmt [8304,8346]
simple_stmt [8304,8346]
===
match
---
if_stmt [44748,44987]
if_stmt [44748,44987]
===
match
---
simple_stmt [93331,93355]
simple_stmt [93438,93462]
===
match
---
atom_expr [29516,29538]
atom_expr [29516,29538]
===
match
---
atom_expr [62714,62953]
atom_expr [62714,62953]
===
match
---
expr_stmt [49070,49107]
expr_stmt [49070,49107]
===
match
---
name: run_id [40912,40918]
name: run_id [40912,40918]
===
match
---
name: priority_weight [11928,11943]
name: priority_weight [11928,11943]
===
match
---
trailer [31729,31733]
trailer [31729,31733]
===
match
---
name: warning [4387,4394]
name: warning [4387,4394]
===
match
---
trailer [78748,79094]
trailer [78855,79201]
===
match
---
argument [11641,11650]
argument [11641,11650]
===
match
---
name: BigInteger [1805,1815]
name: BigInteger [1805,1815]
===
match
---
testlist_comp [22295,22321]
testlist_comp [22295,22321]
===
match
---
atom_expr [15263,15322]
atom_expr [15263,15322]
===
match
---
operator: , [61460,61461]
operator: , [61460,61461]
===
match
---
name: UP_FOR_RESCHEDULE [44771,44788]
name: UP_FOR_RESCHEDULE [44771,44788]
===
match
---
trailer [15605,15612]
trailer [15605,15612]
===
match
---
name: self [59486,59490]
name: self [59486,59490]
===
match
---
name: message [72166,72173]
name: message [72273,72280]
===
match
---
name: self [59190,59194]
name: self [59190,59194]
===
match
---
operator: = [47843,47844]
operator: = [47843,47844]
===
match
---
trailer [47517,47523]
trailer [47517,47523]
===
match
---
name: self [65525,65529]
name: self [65632,65636]
===
match
---
name: ForeignKeyConstraint [1357,1377]
name: ForeignKeyConstraint [1357,1377]
===
match
---
name: str [3795,3798]
name: str [3795,3798]
===
match
---
atom_expr [24438,24449]
atom_expr [24438,24449]
===
match
---
atom_expr [91726,91745]
atom_expr [91833,91852]
===
match
---
name: info [46224,46228]
name: info [46224,46228]
===
match
---
atom_expr [73109,73136]
atom_expr [73216,73243]
===
match
---
simple_stmt [88528,88766]
simple_stmt [88635,88873]
===
match
---
simple_stmt [56668,56730]
simple_stmt [56668,56730]
===
match
---
trailer [91492,91499]
trailer [91599,91606]
===
match
---
string: '\n' [53400,53404]
string: '\n' [53400,53404]
===
match
---
name: delay_backoff_in_seconds [39861,39885]
name: delay_backoff_in_seconds [39861,39885]
===
match
---
operator: } [79677,79678]
operator: } [79784,79785]
===
match
---
trailer [38587,38589]
trailer [38587,38589]
===
match
---
decorated [24515,24889]
decorated [24515,24889]
===
match
---
arglist [43503,43531]
arglist [43503,43531]
===
match
---
name: TaskInstance [31635,31647]
name: TaskInstance [31635,31647]
===
match
---
name: task [49246,49250]
name: task [49246,49250]
===
match
---
name: k [53425,53426]
name: k [53425,53426]
===
match
---
fstring_string: will be removed in a future version. [72278,72314]
fstring_string: will be removed in a future version. [72385,72421]
===
match
---
name: TaskInstanceKey [91961,91976]
name: TaskInstanceKey [92068,92083]
===
match
---
name: ti [26720,26722]
name: ti [26720,26722]
===
match
---
atom_expr [28489,28500]
atom_expr [28489,28500]
===
match
---
trailer [72801,72803]
trailer [72908,72910]
===
match
---
name: error_file [51815,51825]
name: error_file [51815,51825]
===
match
---
param [72055,72060]
param [72162,72167]
===
match
---
decorator [47736,47753]
decorator [47736,47753]
===
match
---
operator: = [48866,48867]
operator: = [48866,48867]
===
match
---
except_clause [31509,31530]
except_clause [31509,31530]
===
match
---
suite [6393,6590]
suite [6393,6590]
===
match
---
name: pod [81152,81155]
name: pod [81259,81262]
===
match
---
trailer [27793,27803]
trailer [27793,27803]
===
match
---
operator: = [92443,92444]
operator: = [92550,92551]
===
match
---
name: incr [51926,51930]
name: incr [51926,51930]
===
match
---
operator: = [24821,24822]
operator: = [24821,24822]
===
match
---
name: self [10123,10127]
name: self [10123,10127]
===
match
---
name: KubeConfig [80486,80496]
name: KubeConfig [80593,80603]
===
match
---
name: self [30087,30091]
name: self [30087,30091]
===
match
---
name: state [51480,51485]
name: state [51480,51485]
===
match
---
name: str [74943,74946]
name: str [75050,75053]
===
match
---
atom_expr [26920,26934]
atom_expr [26920,26934]
===
match
---
trailer [59515,59535]
trailer [59515,59535]
===
match
---
name: job_id [22335,22341]
name: job_id [22335,22341]
===
match
---
trailer [55824,55836]
trailer [55824,55836]
===
match
---
trailer [49257,49262]
trailer [49257,49262]
===
match
---
name: pendulum [68933,68941]
name: pendulum [69040,69048]
===
match
---
name: merge [55032,55037]
name: merge [55032,55037]
===
match
---
operator: == [30377,30379]
operator: == [30377,30379]
===
match
---
arglist [40860,40918]
arglist [40860,40918]
===
match
---
atom_expr [47053,47072]
atom_expr [47053,47072]
===
match
---
atom_expr [11386,11460]
atom_expr [11386,11460]
===
match
---
import_as_names [958,977]
import_as_names [958,977]
===
match
---
atom_expr [78620,78643]
atom_expr [78727,78750]
===
match
---
name: max_tries [26260,26269]
name: max_tries [26260,26269]
===
match
---
name: tis [90074,90077]
name: tis [90181,90184]
===
match
---
name: session [31056,31063]
name: session [31056,31063]
===
match
---
name: ignore_ti_state [43989,44004]
name: ignore_ti_state [43989,44004]
===
match
---
operator: , [41417,41418]
operator: , [41417,41418]
===
match
---
expr_stmt [24476,24488]
expr_stmt [24476,24488]
===
match
---
atom_expr [41468,41481]
atom_expr [41468,41481]
===
match
---
simple_stmt [49475,49535]
simple_stmt [49475,49535]
===
match
---
name: str [81575,81578]
name: str [81682,81685]
===
match
---
atom_expr [37925,37937]
atom_expr [37925,37937]
===
match
---
name: path [18910,18914]
name: path [18910,18914]
===
match
---
name: task_id [39215,39222]
name: task_id [39215,39222]
===
match
---
name: bool [20022,20026]
name: bool [20022,20026]
===
match
---
decorator [57449,57466]
decorator [57449,57466]
===
match
---
trailer [92430,92437]
trailer [92537,92544]
===
match
---
operator: , [53707,53708]
operator: , [53707,53708]
===
match
---
suite [6052,6301]
suite [6052,6301]
===
match
---
name: run_id [90972,90978]
name: run_id [91079,91085]
===
match
---
operator: = [11177,11178]
operator: = [11177,11178]
===
match
---
argument [57408,57420]
argument [57408,57420]
===
match
---
atom_expr [26492,26500]
atom_expr [26492,26500]
===
match
---
name: DateTime [34749,34757]
name: DateTime [34749,34757]
===
match
---
trailer [52674,52681]
trailer [52674,52681]
===
match
---
operator: = [41443,41444]
operator: = [41443,41444]
===
match
---
name: timezone [44718,44726]
name: timezone [44718,44726]
===
match
---
operator: , [86592,86593]
operator: , [86699,86700]
===
match
---
simple_stmt [11760,11785]
simple_stmt [11760,11785]
===
match
---
name: TaskInstance [89760,89772]
name: TaskInstance [89867,89879]
===
match
---
name: self [51963,51967]
name: self [51963,51967]
===
match
---
name: self [77173,77177]
name: self [77280,77284]
===
match
---
name: command_as_list [17953,17968]
name: command_as_list [17953,17968]
===
match
---
strings [8543,8664]
strings [8543,8664]
===
match
---
name: utcnow [52070,52076]
name: utcnow [52070,52076]
===
match
---
expr_stmt [60353,60390]
expr_stmt [60353,60390]
===
match
---
name: provide_session [3364,3379]
name: provide_session [3364,3379]
===
match
---
atom_expr [11904,11923]
atom_expr [11904,11923]
===
match
---
decorator [29241,29251]
decorator [29241,29251]
===
match
---
operator: , [90941,90942]
operator: , [91048,91049]
===
match
---
simple_stmt [1549,1604]
simple_stmt [1549,1604]
===
match
---
trailer [11484,11497]
trailer [11484,11497]
===
match
---
name: operator [27778,27786]
name: operator [27778,27786]
===
match
---
trailer [6947,6968]
trailer [6947,6968]
===
match
---
name: ignore_task_deps [41312,41328]
name: ignore_task_deps [41312,41328]
===
match
---
name: self [64548,64552]
name: self [64655,64659]
===
match
---
name: current_time [28806,28818]
name: current_time [28806,28818]
===
match
---
operator: , [1084,1085]
operator: , [1084,1085]
===
match
---
simple_stmt [1604,1672]
simple_stmt [1604,1672]
===
match
---
name: self [19216,19220]
name: self [19216,19220]
===
match
---
trailer [62616,62618]
trailer [62616,62618]
===
match
---
name: _log_state [47272,47282]
name: _log_state [47272,47282]
===
match
---
expr_stmt [27683,27712]
expr_stmt [27683,27712]
===
match
---
operator: , [75816,75817]
operator: , [75923,75924]
===
match
---
name: in_ [7879,7882]
name: in_ [7879,7882]
===
match
---
name: dag_id [9906,9912]
name: dag_id [9906,9912]
===
match
---
trailer [75334,75363]
trailer [75441,75470]
===
match
---
argument [11251,11267]
argument [11251,11267]
===
match
---
expr_stmt [26398,26417]
expr_stmt [26398,26417]
===
match
---
simple_stmt [45992,46024]
simple_stmt [45992,46024]
===
match
---
name: delete_old_records [53089,53107]
name: delete_old_records [53089,53107]
===
match
---
name: session [79160,79167]
name: session [79267,79274]
===
match
---
atom_expr [40385,40402]
atom_expr [40385,40402]
===
match
---
name: _try_number [17928,17939]
name: _try_number [17928,17939]
===
match
---
name: self [19274,19278]
name: self [19274,19278]
===
match
---
operator: @ [90037,90038]
operator: @ [90144,90145]
===
match
---
suite [93930,94032]
suite [94037,94139]
===
match
---
atom [72661,72697]
atom [72768,72804]
===
match
---
simple_stmt [63655,63682]
simple_stmt [63655,63682]
===
match
---
tfpdef [63416,63441]
tfpdef [63416,63441]
===
match
---
name: instance [31586,31594]
name: instance [31586,31594]
===
match
---
fstring_string: .duration [52879,52888]
fstring_string: .duration [52879,52888]
===
match
---
argument [11320,11336]
argument [11320,11336]
===
match
---
name: str [4974,4977]
name: str [4974,4977]
===
match
---
atom_expr [14185,14198]
atom_expr [14185,14198]
===
match
---
name: instance [9046,9054]
name: instance [9046,9054]
===
match
---
trailer [31486,31496]
trailer [31486,31496]
===
match
---
name: ignore_all_deps [45293,45308]
name: ignore_all_deps [45293,45308]
===
match
---
name: isoformat [23144,23153]
name: isoformat [23144,23153]
===
match
---
atom_expr [59689,59722]
atom_expr [59689,59722]
===
match
---
trailer [58610,58626]
trailer [58610,58626]
===
match
---
name: e [79676,79677]
name: e [79783,79784]
===
match
---
name: get [70738,70741]
name: get [70845,70848]
===
match
---
trailer [22286,22293]
trailer [22286,22293]
===
match
---
trailer [89735,89742]
trailer [89842,89849]
===
match
---
name: log [37542,37545]
name: log [37542,37545]
===
match
---
name: try_number [45906,45916]
name: try_number [45906,45916]
===
match
---
trailer [53325,53477]
trailer [53325,53477]
===
match
---
name: context [52312,52319]
name: context [52312,52319]
===
match
---
operator: = [92402,92403]
operator: = [92509,92510]
===
match
---
operator: = [47915,47916]
operator: = [47915,47916]
===
match
---
name: expected_state [4344,4358]
name: expected_state [4344,4358]
===
match
---
operator: , [66954,66955]
operator: , [67061,67062]
===
match
---
not_test [32132,32151]
not_test [32132,32151]
===
match
---
name: self [28489,28493]
name: self [28489,28493]
===
match
---
name: self [46340,46344]
name: self [46340,46344]
===
match
---
string: """         The task instance for the task that ran before this task instance.          :param state: If passed, it only take into account instances of a specific state.         :param session: SQLAlchemy ORM Session         """ [32556,32784]
string: """         The task instance for the task that ran before this task instance.          :param state: If passed, it only take into account instances of a specific state.         :param session: SQLAlchemy ORM Session         """ [32556,32784]
===
match
---
atom_expr [46129,46145]
atom_expr [46129,46145]
===
match
---
simple_stmt [2243,2304]
simple_stmt [2243,2304]
===
match
---
comparison [51475,51518]
comparison [51475,51518]
===
match
---
name: actual_start_date [62836,62853]
name: actual_start_date [62836,62853]
===
match
---
simple_stmt [65751,65789]
simple_stmt [65858,65896]
===
match
---
param [69939,69943]
param [70046,70050]
===
match
---
suite [59466,59840]
suite [59466,59840]
===
match
---
name: task [76240,76244]
name: task [76347,76351]
===
match
---
atom_expr [81039,81105]
atom_expr [81146,81212]
===
match
---
param [60711,60741]
param [60711,60741]
===
match
---
simple_stmt [78200,78271]
simple_stmt [78307,78378]
===
match
---
name: Context [4016,4023]
name: Context [4016,4023]
===
match
---
name: queued_by_job_id [12040,12056]
name: queued_by_job_id [12040,12056]
===
match
---
name: cmd [22122,22125]
name: cmd [22122,22125]
===
match
---
name: duration [11537,11545]
name: duration [11537,11545]
===
match
---
trailer [8224,8230]
trailer [8224,8230]
===
match
---
param [24552,24564]
param [24552,24564]
===
match
---
trailer [43470,43478]
trailer [43470,43478]
===
match
---
operator: , [39208,39209]
operator: , [39208,39209]
===
match
---
name: airflow [2248,2255]
name: airflow [2248,2255]
===
match
---
name: DagRun [9106,9112]
name: DagRun [9106,9112]
===
match
---
atom_expr [58280,58300]
atom_expr [58280,58300]
===
match
---
simple_stmt [33947,33996]
simple_stmt [33947,33996]
===
match
---
trailer [56695,56713]
trailer [56695,56713]
===
match
---
expr_stmt [74731,74773]
expr_stmt [74838,74880]
===
match
---
expr_stmt [80507,81116]
expr_stmt [80614,81223]
===
match
---
argument [61330,61361]
argument [61330,61361]
===
match
---
operator: = [13867,13868]
operator: = [13867,13868]
===
match
---
name: deserialize_value [89424,89441]
name: deserialize_value [89531,89548]
===
match
---
simple_stmt [83228,83311]
simple_stmt [83335,83418]
===
match
---
operator: = [46495,46496]
operator: = [46495,46496]
===
match
---
simple_stmt [66832,66895]
simple_stmt [66939,67002]
===
match
---
name: str [66259,66262]
name: str [66366,66369]
===
match
---
atom_expr [80626,80666]
atom_expr [80733,80773]
===
match
---
name: self [28945,28949]
name: self [28945,28949]
===
match
---
trailer [63244,63248]
trailer [63244,63248]
===
match
---
simple_stmt [91712,91856]
simple_stmt [91819,91963]
===
match
---
tfpdef [19844,19862]
tfpdef [19844,19862]
===
match
---
name: execution_timeout [58689,58706]
name: execution_timeout [58689,58706]
===
match
---
expr_stmt [83228,83310]
expr_stmt [83335,83417]
===
match
---
simple_stmt [92282,92325]
simple_stmt [92389,92432]
===
match
---
expr_stmt [83777,83817]
expr_stmt [83884,83924]
===
match
---
string: 'next_ds' [75723,75732]
string: 'next_ds' [75830,75839]
===
match
---
atom_expr [47979,47992]
atom_expr [47979,47992]
===
match
---
arglist [67694,67724]
arglist [67801,67831]
===
match
---
name: self [62546,62550]
name: self [62546,62550]
===
match
---
name: Optional [30669,30677]
name: Optional [30669,30677]
===
match
---
operator: = [31711,31712]
operator: = [31711,31712]
===
match
---
name: self [43204,43208]
name: self [43204,43208]
===
match
---
try_stmt [5093,5324]
try_stmt [5093,5324]
===
match
---
trailer [83815,83817]
trailer [83922,83924]
===
match
---
atom_expr [83498,83763]
atom_expr [83605,83870]
===
match
---
operator: = [72080,72081]
operator: = [72187,72188]
===
match
---
simple_stmt [22971,23008]
simple_stmt [22971,23008]
===
match
---
return_stmt [93564,93592]
return_stmt [93671,93699]
===
match
---
operator: , [91284,91285]
operator: , [91391,91392]
===
match
---
trailer [22611,22641]
trailer [22611,22641]
===
match
---
operator: , [84329,84330]
operator: , [84436,84437]
===
match
---
name: airflow [80376,80383]
name: airflow [80483,80490]
===
match
---
number: 1 [46397,46398]
number: 1 [46397,46398]
===
match
---
funcdef [93512,93593]
funcdef [93619,93700]
===
match
---
simple_stmt [63571,63613]
simple_stmt [63571,63613]
===
match
---
name: execution_date [86211,86225]
name: execution_date [86318,86332]
===
match
---
trailer [51948,51953]
trailer [51948,51953]
===
match
---
name: RESTARTING [6248,6258]
name: RESTARTING [6248,6258]
===
match
---
name: run_id [19816,19822]
name: run_id [19816,19822]
===
match
---
fstring [37893,37969]
fstring [37893,37969]
===
match
---
arglist [90912,91055]
arglist [91019,91162]
===
insert-node
---
name: TaskInstance [10578,10590]
to
classdef [10572,91856]
at 0
===
insert-tree
---
arglist [10591,10609]
    name: Base [10591,10595]
    operator: , [10595,10596]
    name: LoggingMixin [10597,10609]
to
classdef [10572,91856]
at 1
===
insert-tree
---
simple_stmt [10616,11158]
    string: """     Task instances store the state of a task instance. This table is the     authority and single source of truth around what tasks have run and the     state they are in.      The SqlAlchemy model doesn't have a SqlAlchemy foreign key to the task or     dag model deliberately to have more control over transactions.      Database transactions on this table should insure double triggers and     any confusion around what task instances are or aren't ready to run     even while multiple schedulers may be firing task instances.     """ [10616,11157]
to
suite [10611,91856]
at 0
===
insert-tree
---
simple_stmt [64500,64592]
    expr_stmt [64500,64542]
        name: dag_run [64500,64507]
        operator: = [64508,64509]
        atom_expr [64510,64542]
            name: self [64510,64514]
            trailer [64514,64525]
                name: get_dagrun [64515,64525]
            trailer [64525,64542]
                argument [64526,64541]
                    name: session [64526,64533]
                    operator: = [64533,64534]
                    name: session [64534,64541]
to
suite [64402,64581]
at 1
===
update-node
---
name: self [64527,64531]
replace self by dag_run
===
delete-node
---
name: TaskInstance [10578,10590]
===
===
delete-tree
---
arglist [10591,10609]
    name: Base [10591,10595]
    operator: , [10595,10596]
    name: LoggingMixin [10597,10609]
===
delete-tree
---
simple_stmt [10616,11158]
    string: """     Task instances store the state of a task instance. This table is the     authority and single source of truth around what tasks have run and the     state they are in.      The SqlAlchemy model doesn't have a SqlAlchemy foreign key to the task or     dag model deliberately to have more control over transactions.      Database transactions on this table should insure double triggers and     any confusion around what task instances are or aren't ready to run     even while multiple schedulers may be firing task instances.     """ [10616,11157]
