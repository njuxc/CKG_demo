===
match
---
simple_stmt [21613,22016]
simple_stmt [21613,22016]
===
match
---
param [7002,7007]
param [7002,7007]
===
match
---
name: V1PreferredSchedulingTerm [18966,18991]
name: V1PreferredSchedulingTerm [18966,18991]
===
match
---
string: "default" [7083,7092]
string: "default" [7083,7092]
===
match
---
atom_expr [10079,10368]
atom_expr [10079,10368]
===
match
---
operator: = [2963,2964]
operator: = [2963,2964]
===
match
---
atom [7145,7160]
atom [7145,7160]
===
match
---
operator: , [13790,13791]
operator: , [13790,13791]
===
match
---
name: kubernetes_pod [1088,1102]
name: kubernetes_pod [1088,1102]
===
match
---
string: "hello" [10854,10861]
string: "hello" [10854,10861]
===
match
---
operator: = [4991,4992]
operator: = [4991,4992]
===
match
---
string: "airflow.providers.cncf.kubernetes.utils.pod_launcher.PodLauncher.monitor_pod" [1526,1604]
string: "airflow.providers.cncf.kubernetes.utils.pod_launcher.PodLauncher.monitor_pod" [1526,1604]
===
match
---
string: "bar" [12877,12882]
string: "bar" [12877,12882]
===
match
---
name: k8s [2484,2487]
name: k8s [2484,2487]
===
match
---
testlist_comp [18272,18285]
testlist_comp [18272,18285]
===
match
---
operator: , [17328,17329]
operator: , [17328,17329]
===
match
---
operator: = [17419,17420]
operator: = [17419,17420]
===
match
---
name: sanitized_pod [19828,19841]
name: sanitized_pod [19828,19841]
===
match
---
operator: , [7846,7847]
operator: , [7846,7847]
===
match
---
argument [17570,17585]
argument [17570,17585]
===
match
---
string: 'preferred_during_scheduling_ignored_during_execution' [13543,13597]
string: 'preferred_during_scheduling_ignored_during_execution' [13543,13597]
===
match
---
number: 1 [17910,17911]
number: 1 [17910,17911]
===
match
---
atom_expr [5582,5590]
atom_expr [5582,5590]
===
match
---
comparison [9465,9534]
comparison [9465,9534]
===
match
---
string: "foo" [4693,4698]
string: "foo" [4693,4698]
===
match
---
atom_expr [9933,9941]
atom_expr [9933,9941]
===
match
---
name: in_cluster [3149,3159]
name: in_cluster [3149,3159]
===
match
---
trailer [12499,12595]
trailer [12499,12595]
===
match
---
string: "task" [3129,3135]
string: "task" [3129,3135]
===
match
---
operator: , [4078,4079]
operator: , [4078,4079]
===
match
---
name: pod [9315,9318]
name: pod [9315,9318]
===
match
---
string: "kub_pod_test" [2205,2219]
string: "kub_pod_test" [2205,2219]
===
match
---
string: "test" [6563,6569]
string: "test" [6563,6569]
===
match
---
trailer [15237,15248]
trailer [15237,15248]
===
match
---
argument [3061,3082]
argument [3061,3082]
===
match
---
operator: -> [2481,2483]
operator: -> [2481,2483]
===
match
---
trailer [19906,19941]
trailer [19906,19941]
===
match
---
simple_stmt [12444,12461]
simple_stmt [12444,12461]
===
match
---
operator: , [4602,4603]
operator: , [4602,4603]
===
match
---
name: execute [16722,16729]
name: execute [16722,16729]
===
match
---
name: k [22450,22451]
name: k [22450,22451]
===
match
---
name: airflow [943,950]
name: airflow [943,950]
===
match
---
assert_stmt [10486,10532]
assert_stmt [10486,10532]
===
match
---
operator: , [19492,19493]
operator: , [19492,19493]
===
match
---
name: cmds [21719,21723]
name: cmds [21719,21723]
===
match
---
name: file_path [3634,3643]
name: file_path [3634,3643]
===
match
---
atom_expr [1730,1754]
atom_expr [1730,1754]
===
match
---
string: "bar" [8672,8677]
string: "bar" [8672,8677]
===
match
---
name: context [3474,3481]
name: context [3474,3481]
===
match
---
name: create_context [3438,3452]
name: create_context [3438,3452]
===
match
---
operator: } [18139,18140]
operator: } [18139,18140]
===
match
---
string: "-cx" [22582,22587]
string: "-cx" [22582,22587]
===
match
---
name: pod [20625,20628]
name: pod [20625,20628]
===
match
---
name: self [9224,9228]
name: self [9224,9228]
===
match
---
atom_expr [5322,5341]
atom_expr [5322,5341]
===
match
---
simple_stmt [18160,18556]
simple_stmt [18160,18556]
===
match
---
trailer [23450,23458]
trailer [23450,23458]
===
match
---
name: failed_pod_status [16433,16450]
name: failed_pod_status [16433,16450]
===
match
---
string: "foo" [18343,18348]
string: "foo" [18343,18348]
===
match
---
trailer [1229,1238]
trailer [1229,1238]
===
match
---
name: labels [20392,20398]
name: labels [20392,20398]
===
match
---
string: "Equal" [20180,20187]
string: "Equal" [20180,20187]
===
match
---
atom [22652,22666]
atom [22652,22666]
===
match
---
name: sanitized_pod [23076,23089]
name: sanitized_pod [23076,23089]
===
match
---
atom_expr [13073,13081]
atom_expr [13073,13081]
===
match
---
atom_expr [17483,17496]
atom_expr [17483,17496]
===
match
---
name: run_pod [12619,12626]
name: run_pod [12619,12626]
===
match
---
name: labels [6523,6529]
name: labels [6523,6529]
===
match
---
name: name [5915,5919]
name: name [5915,5919]
===
match
---
trailer [19794,19817]
trailer [19794,19817]
===
match
---
name: image [6420,6425]
name: image [6420,6425]
===
match
---
string: "bar" [16145,16150]
string: "bar" [16145,16150]
===
match
---
operator: = [19422,19423]
operator: = [19422,19423]
===
match
---
name: xcom_pull [23643,23652]
name: xcom_pull [23643,23652]
===
match
---
comparison [9256,9299]
comparison [9256,9299]
===
match
---
operator: { [19556,19557]
operator: { [19556,19557]
===
match
---
name: arguments [5845,5854]
name: arguments [5845,5854]
===
match
---
atom [16105,16116]
atom [16105,16116]
===
match
---
name: file_path [3223,3232]
name: file_path [3223,3232]
===
match
---
operator: = [6458,6459]
operator: = [6458,6459]
===
match
---
name: name [5164,5168]
name: name [5164,5168]
===
match
---
name: self [7002,7006]
name: self [7002,7006]
===
match
---
name: namespace [7793,7802]
name: namespace [7793,7802]
===
match
---
name: name_base [15238,15247]
name: name_base [15238,15247]
===
match
---
atom_expr [12444,12460]
atom_expr [12444,12460]
===
match
---
trailer [18748,18756]
trailer [18748,18756]
===
match
---
atom_expr [22309,22436]
atom_expr [22309,22436]
===
match
---
name: DeprecationWarning [22335,22353]
name: DeprecationWarning [22335,22353]
===
match
---
argument [7359,7384]
argument [7359,7384]
===
match
---
argument [22645,22666]
argument [22645,22666]
===
match
---
name: context [17570,17577]
name: context [17570,17577]
===
match
---
dictorsetmaker [17801,18126]
dictorsetmaker [17801,18126]
===
match
---
argument [19702,19727]
argument [19702,19727]
===
match
---
trailer [22941,22943]
trailer [22941,22943]
===
match
---
string: "ubuntu:16.04" [5783,5797]
string: "ubuntu:16.04" [5783,5797]
===
match
---
string: "weight" [17900,17908]
string: "weight" [17900,17908]
===
match
---
testlist_comp [19486,19499]
testlist_comp [19486,19499]
===
match
---
trailer [9033,9209]
trailer [9033,9209]
===
match
---
name: monitor_mock [1768,1780]
name: monitor_mock [1768,1780]
===
match
---
arglist [19413,19767]
arglist [19413,19767]
===
match
---
name: ANY [15810,15813]
name: ANY [15810,15813]
===
match
---
operator: = [22915,22916]
operator: = [22915,22916]
===
match
---
name: do_xcom_push [21157,21169]
name: do_xcom_push [21157,21169]
===
match
---
string: "default" [21205,21214]
string: "default" [21205,21214]
===
match
---
string: "airflow_version" [13054,13071]
string: "airflow_version" [13054,13071]
===
match
---
argument [21977,22004]
argument [21977,22004]
===
match
---
argument [20510,20528]
argument [20510,20528]
===
match
---
operator: = [10381,10382]
operator: = [10381,10382]
===
match
---
string: "task" [10971,10977]
string: "task" [10971,10977]
===
match
---
operator: = [3410,3411]
operator: = [3410,3411]
===
match
---
trailer [12832,12841]
trailer [12832,12841]
===
match
---
operator: } [18057,18058]
operator: } [18057,18058]
===
match
---
operator: , [18020,18021]
operator: , [18020,18021]
===
match
---
name: k8s [8787,8790]
name: k8s [8787,8790]
===
match
---
name: name [10279,10283]
name: name [10279,10283]
===
match
---
name: metadata [23811,23819]
name: metadata [23811,23819]
===
match
---
trailer [9403,9406]
trailer [9403,9406]
===
match
---
expr_stmt [21280,21312]
expr_stmt [21280,21312]
===
match
---
name: cluster_context [7359,7374]
name: cluster_context [7359,7374]
===
match
---
name: image [13242,13247]
name: image [13242,13247]
===
match
---
name: arguments [20357,20366]
name: arguments [20357,20366]
===
match
---
name: addCleanup [1876,1886]
name: addCleanup [1876,1886]
===
match
---
name: cluster_context [19702,19717]
name: cluster_context [19702,19717]
===
match
---
simple_stmt [4240,4284]
simple_stmt [4240,4284]
===
match
---
atom [10339,10357]
atom [10339,10357]
===
match
---
atom_expr [22145,22167]
atom_expr [22145,22167]
===
match
---
operator: = [4587,4588]
operator: = [4587,4588]
===
match
---
name: k [8029,8030]
name: k [8029,8030]
===
match
---
string: "echo 10" [21764,21773]
string: "echo 10" [21764,21773]
===
match
---
atom_expr [5709,6146]
atom_expr [5709,6146]
===
match
---
name: V1Toleration [20071,20083]
name: V1Toleration [20071,20083]
===
match
---
name: raises [8217,8223]
name: raises [8217,8223]
===
match
---
trailer [17101,17440]
trailer [17101,17440]
===
match
---
name: node_selector [22231,22244]
name: node_selector [22231,22244]
===
match
---
trailer [18688,18693]
trailer [18688,18693]
===
match
---
string: "bar" [20407,20412]
string: "bar" [20407,20412]
===
match
---
import_name [785,800]
import_name [785,800]
===
match
---
operator: , [3338,3339]
operator: , [3338,3339]
===
match
---
atom_expr [23735,23744]
atom_expr [23735,23744]
===
match
---
name: key [20084,20087]
name: key [20084,20087]
===
match
---
operator: = [21690,21691]
operator: = [21690,21691]
===
match
---
operator: = [2189,2190]
operator: = [2189,2190]
===
match
---
trailer [15226,15237]
trailer [15226,15237]
===
match
---
atom_expr [23538,23548]
atom_expr [23538,23548]
===
match
---
name: k [4194,4195]
name: k [4194,4195]
===
match
---
operator: , [15057,15058]
operator: , [15057,15058]
===
match
---
trailer [15103,15106]
trailer [15103,15106]
===
match
---
operator: = [16491,16492]
operator: = [16491,16492]
===
match
---
string: "airflow.providers.cncf.kubernetes.utils.pod_launcher.PodLauncher.start_pod" [1386,1462]
string: "airflow.providers.cncf.kubernetes.utils.pod_launcher.PodLauncher.start_pod" [1386,1462]
===
match
---
trailer [2321,2331]
trailer [2321,2331]
===
match
---
trailer [16943,16956]
trailer [16943,16956]
===
match
---
operator: , [3928,3929]
operator: , [3928,3929]
===
match
---
trailer [19875,19880]
trailer [19875,19880]
===
match
---
name: pod [10548,10551]
name: pod [10548,10551]
===
match
---
operator: , [1252,1253]
operator: , [1252,1253]
===
match
---
operator: = [23227,23228]
operator: = [23227,23228]
===
match
---
name: image [9444,9449]
name: image [9444,9449]
===
match
---
trailer [1512,1614]
trailer [1512,1614]
===
match
---
string: "task" [12525,12531]
string: "task" [12525,12531]
===
match
---
string: "echo 10" [19525,19534]
string: "echo 10" [19525,19534]
===
match
---
string: "task" [4753,4759]
string: "task" [4753,4759]
===
match
---
operator: , [18702,18703]
operator: , [18702,18703]
===
match
---
string: "Always" [6850,6858]
string: "Always" [6850,6858]
===
match
---
operator: { [3068,3069]
operator: { [3068,3069]
===
match
---
comparison [19957,20002]
comparison [19957,20002]
===
match
---
name: ti [23470,23472]
name: ti [23470,23472]
===
match
---
string: "test_push_xcom_pod_info" [23503,23528]
string: "test_push_xcom_pod_info" [23503,23528]
===
match
---
operator: = [7183,7184]
operator: = [7183,7184]
===
match
---
string: "default" [9153,9162]
string: "default" [9153,9162]
===
match
---
number: 0 [13239,13240]
number: 0 [13239,13240]
===
match
---
operator: , [17134,17135]
operator: , [17134,17135]
===
match
---
operator: = [8832,8833]
operator: = [8832,8833]
===
match
---
name: sanitized_pod [19957,19970]
name: sanitized_pod [19957,19970]
===
match
---
name: metadata [8076,8084]
name: metadata [8076,8084]
===
match
---
assert_stmt [15311,15355]
assert_stmt [15311,15355]
===
match
---
argument [7860,7874]
argument [7860,7874]
===
match
---
string: 'kubernetes.io/role' [14301,14321]
string: 'kubernetes.io/role' [14301,14321]
===
match
---
simple_stmt [17076,17441]
simple_stmt [17076,17441]
===
match
---
string: "foo" [9710,9715]
string: "foo" [9710,9715]
===
match
---
string: "ubuntu:16.04" [2964,2978]
string: "ubuntu:16.04" [2964,2978]
===
match
---
name: labels [3942,3948]
name: labels [3942,3948]
===
match
---
param [21538,21542]
param [21538,21542]
===
match
---
argument [10172,10190]
argument [10172,10190]
===
match
---
operator: = [3876,3877]
operator: = [3876,3877]
===
match
---
name: k8s [19062,19065]
name: k8s [19062,19065]
===
match
---
operator: { [13521,13522]
operator: { [13521,13522]
===
match
---
operator: = [12566,12567]
operator: = [12566,12567]
===
match
---
operator: == [9338,9340]
operator: == [9338,9340]
===
match
---
name: patch [1507,1512]
name: patch [1507,1512]
===
match
---
trailer [4204,4207]
trailer [4204,4207]
===
match
---
trailer [4248,4257]
trailer [4248,4257]
===
match
---
name: KubernetesPodOperator [18164,18185]
name: KubernetesPodOperator [18164,18185]
===
match
---
name: return_value [17624,17636]
name: return_value [17624,17636]
===
match
---
funcdef [11106,15873]
funcdef [11106,15873]
===
match
---
atom [6498,6509]
atom [6498,6509]
===
match
---
import_from [1132,1166]
import_from [1132,1166]
===
match
---
name: test_pod_template_file [11110,11132]
name: test_pod_template_file [11110,11132]
===
match
---
name: pod [15209,15212]
name: pod [15209,15212]
===
match
---
name: pod [13424,13427]
name: pod [13424,13427]
===
match
---
operator: , [14321,14322]
operator: , [14321,14322]
===
match
---
simple_stmt [4902,4953]
simple_stmt [4902,4953]
===
match
---
simple_stmt [13212,13266]
simple_stmt [13212,13266]
===
match
---
operator: = [18162,18163]
operator: = [18162,18163]
===
match
---
trailer [18823,19364]
trailer [18823,19364]
===
match
---
with_stmt [22304,22902]
with_stmt [22304,22902]
===
match
---
trailer [8597,8603]
trailer [8597,8603]
===
match
---
argument [23496,23528]
argument [23496,23528]
===
match
---
name: pod [10791,10794]
name: pod [10791,10794]
===
match
---
name: self [10383,10387]
name: self [10383,10387]
===
match
---
name: ApiClient [2764,2773]
name: ApiClient [2764,2773]
===
match
---
argument [17148,17168]
argument [17148,17168]
===
match
---
operator: } [11099,11100]
operator: } [11099,11100]
===
match
---
trailer [13077,13081]
trailer [13077,13081]
===
match
---
simple_stmt [9666,9953]
simple_stmt [9666,9953]
===
match
---
atom_expr [22082,22118]
atom_expr [22082,22118]
===
match
---
simple_stmt [14768,14803]
simple_stmt [14768,14803]
===
match
---
name: containers [6815,6825]
name: containers [6815,6825]
===
match
---
operator: = [22651,22652]
operator: = [22651,22652]
===
match
---
name: do_xcom_push [7327,7339]
name: do_xcom_push [7327,7339]
===
match
---
operator: = [21106,21107]
operator: = [21106,21107]
===
match
---
atom [13391,13404]
atom [13391,13404]
===
match
---
atom [9696,9952]
atom [9696,9952]
===
match
---
trailer [6076,6095]
trailer [6076,6095]
===
match
---
operator: , [19727,19728]
operator: , [19727,19728]
===
match
---
operator: , [11089,11090]
operator: , [11089,11090]
===
match
---
expr_stmt [2849,2877]
expr_stmt [2849,2877]
===
match
---
atom_expr [9673,9692]
atom_expr [9673,9692]
===
match
---
operator: = [6425,6426]
operator: = [6425,6426]
===
match
---
argument [8754,8973]
argument [8754,8973]
===
match
---
expr_stmt [4349,4383]
expr_stmt [4349,4383]
===
match
---
operator: = [20103,20104]
operator: = [20103,20104]
===
match
---
name: TestCase [1303,1311]
name: TestCase [1303,1311]
===
match
---
name: spec [18689,18693]
name: spec [18689,18693]
===
match
---
operator: = [12524,12525]
operator: = [12524,12525]
===
match
---
name: name [18370,18374]
name: name [18370,18374]
===
match
---
name: pod [19787,19790]
name: pod [19787,19790]
===
match
---
name: spec [4913,4917]
name: spec [4913,4917]
===
match
---
argument [2637,2652]
argument [2637,2652]
===
match
---
name: pod [21369,21372]
name: pod [21369,21372]
===
match
---
name: name [4720,4724]
name: name [4720,4724]
===
match
---
name: pod [5322,5325]
name: pod [5322,5325]
===
match
---
expr_stmt [1481,1614]
expr_stmt [1481,1614]
===
match
---
dictorsetmaker [18003,18057]
dictorsetmaker [18003,18057]
===
match
---
name: task_id [22713,22720]
name: task_id [22713,22720]
===
match
---
operator: = [16416,16417]
operator: = [16416,16417]
===
match
---
suite [1313,23898]
suite [1313,27643]
===
match
---
name: sanitized_pod [20666,20679]
name: sanitized_pod [20666,20679]
===
match
---
name: node_selector [22873,22886]
name: node_selector [22873,22886]
===
match
---
argument [5095,5115]
argument [5095,5115]
===
match
---
trailer [2694,2697]
trailer [2694,2697]
===
match
---
name: test_labels [4962,4973]
name: test_labels [4962,4973]
===
match
---
fstring [16807,16897]
fstring [16807,16897]
===
match
---
atom_expr [11081,11089]
atom_expr [11081,11089]
===
match
---
argument [2198,2219]
argument [2198,2219]
===
match
---
trailer [15337,15340]
trailer [15337,15340]
===
match
---
string: "1" [5506,5509]
string: "1" [5506,5509]
===
match
---
operator: , [20496,20497]
operator: , [20496,20497]
===
match
---
operator: , [23330,23331]
operator: , [23330,23331]
===
match
---
trailer [8726,8736]
trailer [8726,8736]
===
match
---
number: 1 [1248,1249]
number: 1 [1248,1249]
===
match
---
operator: = [21918,21919]
operator: = [21918,21919]
===
match
---
argument [5915,5926]
argument [5915,5926]
===
match
---
argument [19212,19225]
argument [19212,19225]
===
match
---
expr_stmt [19374,19777]
expr_stmt [19374,19777]
===
match
---
argument [4424,4484]
argument [4424,4484]
===
match
---
trailer [9512,9523]
trailer [9512,9523]
===
match
---
operator: = [4752,4753]
operator: = [4752,4753]
===
match
---
operator: , [21834,21835]
operator: , [21834,21835]
===
match
---
string: "bar" [6538,6543]
string: "bar" [6538,6543]
===
match
---
operator: , [5509,5510]
operator: , [5509,5510]
===
match
---
argument [9075,9091]
argument [9075,9091]
===
match
---
argument [4616,4636]
argument [4616,4636]
===
match
---
string: "task" [21856,21862]
string: "task" [21856,21862]
===
match
---
suite [7025,7678]
suite [7025,7678]
===
match
---
atom_expr [4878,4893]
atom_expr [4878,4893]
===
match
---
parameters [20028,20034]
parameters [20028,20034]
===
match
---
trailer [21368,21373]
trailer [21368,21373]
===
match
---
string: "bar" [3957,3962]
string: "bar" [3957,3962]
===
match
---
atom_expr [8127,8144]
atom_expr [8127,8144]
===
match
---
name: airflow [1137,1144]
name: airflow [1137,1144]
===
match
---
trailer [4912,4917]
trailer [4912,4917]
===
match
---
expr_stmt [11148,12337]
expr_stmt [11148,12337]
===
match
---
atom [20152,20207]
atom [20152,20207]
===
match
---
operator: = [3741,3742]
operator: = [3741,3742]
===
match
---
name: sanitize_for_serialization [21342,21368]
name: sanitize_for_serialization [21342,21368]
===
match
---
name: self [17529,17533]
name: self [17529,17533]
===
match
---
simple_stmt [1623,1704]
simple_stmt [1623,1704]
===
match
---
number: 0 [13305,13306]
number: 0 [13305,13306]
===
match
---
string: "hello" [8648,8655]
string: "hello" [8648,8655]
===
match
---
suite [4980,5602]
suite [4980,5602]
===
match
---
arglist [18199,18545]
arglist [18199,18545]
===
match
---
argument [17216,17237]
argument [17216,17237]
===
match
---
name: image [20289,20294]
name: image [20289,20294]
===
match
---
expr_stmt [17076,17440]
expr_stmt [17076,17440]
===
match
---
operator: == [13454,13456]
operator: == [13454,13456]
===
match
---
trailer [1372,1472]
trailer [1372,1472]
===
match
---
name: image [17148,17153]
name: image [17148,17153]
===
match
---
argument [3246,3271]
argument [3246,3271]
===
match
---
dictorsetmaker [20154,20205]
dictorsetmaker [20154,20205]
===
match
---
expr_stmt [2064,2087]
expr_stmt [2064,2087]
===
match
---
name: name [8643,8647]
name: name [8643,8647]
===
match
---
atom_expr [2669,2700]
atom_expr [2669,2700]
===
match
---
operator: { [6530,6531]
operator: { [6530,6531]
===
match
---
atom_expr [2167,2188]
atom_expr [2167,2188]
===
match
---
name: containers [9430,9440]
name: containers [9430,9440]
===
match
---
simple_stmt [10075,10369]
simple_stmt [10075,10369]
===
match
---
expr_stmt [14768,14802]
expr_stmt [14768,14802]
===
match
---
name: labels [5880,5886]
name: labels [5880,5886]
===
match
---
assert_stmt [20796,20854]
assert_stmt [20796,20854]
===
match
---
name: KubernetesPodOperator [17080,17101]
name: KubernetesPodOperator [17080,17101]
===
match
---
parameters [8189,8195]
parameters [8189,8195]
===
match
---
argument [10243,10265]
argument [10243,10265]
===
match
---
operator: = [21827,21828]
operator: = [21827,21828]
===
match
---
operator: , [22886,22887]
operator: , [22886,22887]
===
match
---
argument [6030,6096]
argument [6030,6096]
===
match
---
comparison [23858,23897]
comparison [23858,23897]
===
match
---
assert_stmt [8065,8111]
assert_stmt [8065,8111]
===
match
---
trailer [16729,16746]
trailer [16729,16746]
===
match
---
operator: = [5066,5067]
operator: = [5066,5067]
===
match
---
operator: = [18374,18375]
operator: = [18374,18375]
===
match
---
operator: = [19199,19200]
operator: = [19199,19200]
===
match
---
name: sanitized_pod [18606,18619]
name: sanitized_pod [18606,18619]
===
match
---
operator: = [7831,7832]
operator: = [7831,7832]
===
match
---
atom [18342,18356]
atom [18342,18356]
===
match
---
name: k [22031,22032]
name: k [22031,22032]
===
match
---
operator: = [15008,15009]
operator: = [15008,15009]
===
match
---
string: "beta.kubernetes.io/os" [21570,21593]
string: "beta.kubernetes.io/os" [21570,21593]
===
match
---
arglist [2125,2157]
arglist [2125,2157]
===
match
---
name: k [7613,7614]
name: k [7613,7614]
===
match
---
name: config_file [3622,3633]
name: config_file [3622,3633]
===
match
---
argument [21157,21175]
argument [21157,21175]
===
match
---
argument [4720,4731]
argument [4720,4731]
===
match
---
atom_expr [8723,8987]
atom_expr [8723,8987]
===
match
---
dictorsetmaker [13655,13996]
dictorsetmaker [13655,13996]
===
match
---
trailer [4195,4204]
trailer [4195,4204]
===
match
---
operator: , [22727,22728]
operator: , [22727,22728]
===
match
---
operator: , [3569,3570]
operator: , [3569,3570]
===
match
---
operator: { [14293,14294]
operator: { [14293,14294]
===
match
---
expr_stmt [7445,7509]
expr_stmt [7445,7509]
===
match
---
operator: = [2996,2997]
operator: = [2996,2997]
===
match
---
trailer [19817,19819]
trailer [19817,19819]
===
match
---
argument [19051,19298]
argument [19051,19298]
===
match
---
string: "spec" [21472,21478]
string: "spec" [21472,21478]
===
match
---
string: "linux" [21595,21602]
string: "linux" [21595,21602]
===
match
---
operator: = [6690,6691]
operator: = [6690,6691]
===
match
---
assert_stmt [13153,13199]
assert_stmt [13153,13199]
===
match
---
operator: = [10010,10011]
operator: = [10010,10011]
===
match
---
operator: , [14985,14986]
operator: , [14985,14986]
===
match
---
atom_expr [4909,4940]
atom_expr [4909,4940]
===
match
---
param [4974,4978]
param [4974,4978]
===
match
---
dictorsetmaker [13543,14534]
dictorsetmaker [13543,14534]
===
match
---
operator: , [20335,20336]
operator: , [20335,20336]
===
match
---
name: command [9527,9534]
name: command [9527,9534]
===
match
---
atom_expr [1887,1908]
atom_expr [1887,1908]
===
match
---
string: 'values' [14341,14349]
string: 'values' [14341,14349]
===
match
---
name: read_namespaced_pod [16957,16976]
name: read_namespaced_pod [16957,16976]
===
match
---
trailer [8053,8055]
trailer [8053,8055]
===
match
---
name: ANY [15854,15857]
name: ANY [15854,15857]
===
match
---
string: "bash" [20329,20335]
string: "bash" [20329,20335]
===
match
---
operator: { [21569,21570]
operator: { [21569,21570]
===
match
---
trailer [4207,4213]
trailer [4207,4213]
===
match
---
dictorsetmaker [13763,13834]
dictorsetmaker [13763,13834]
===
match
---
simple_stmt [9218,9240]
simple_stmt [9218,9240]
===
match
---
name: cmds [7140,7144]
name: cmds [7140,7144]
===
match
---
operator: = [7958,7959]
operator: = [7958,7959]
===
match
---
operator: { [16835,16836]
operator: { [16835,16836]
===
match
---
suite [23170,23898]
suite [23170,23898]
===
match
---
name: value [3909,3914]
name: value [3909,3914]
===
match
---
string: "world" [10863,10870]
string: "world" [10863,10870]
===
match
---
operator: , [22512,22513]
operator: , [22512,22513]
===
match
---
operator: , [6440,6441]
operator: , [6440,6441]
===
match
---
argument [18837,19353]
argument [18837,19353]
===
match
---
name: sanitized_pod [22066,22079]
name: sanitized_pod [22066,22079]
===
match
---
trailer [21310,21312]
trailer [21310,21312]
===
match
---
dictorsetmaker [6531,6543]
dictorsetmaker [6531,6543]
===
match
---
testlist_comp [20976,20989]
testlist_comp [20976,20989]
===
match
---
string: "ubuntu:16.04" [3771,3785]
string: "ubuntu:16.04" [3771,3785]
===
match
---
name: tolerations [20754,20765]
name: tolerations [20754,20765]
===
match
---
name: cluster_context [21189,21204]
name: cluster_context [21189,21204]
===
match
---
simple_stmt [12822,13141]
simple_stmt [12822,13141]
===
match
---
operator: = [23323,23324]
operator: = [23323,23324]
===
match
---
name: operator [2620,2628]
name: operator [2620,2628]
===
match
---
operator: = [21045,21046]
operator: = [21045,21046]
===
match
---
atom_expr [18674,18719]
atom_expr [18674,18719]
===
match
---
name: DagRun [1018,1024]
name: DagRun [1018,1024]
===
match
---
param [6333,6337]
param [6333,6337]
===
match
---
string: "key" [20154,20159]
string: "key" [20154,20159]
===
match
---
operator: = [3842,3843]
operator: = [3842,3843]
===
match
---
operator: , [10357,10358]
operator: , [10357,10358]
===
match
---
fstring_string: Pod Launching failed: Pod  [16809,16835]
fstring_string: Pod Launching failed: Pod  [16809,16835]
===
match
---
atom [6234,6286]
atom [6234,6286]
===
match
---
operator: , [13036,13037]
operator: , [13036,13037]
===
match
---
string: 'foo' [14352,14357]
string: 'foo' [14352,14357]
===
match
---
name: do_xcom_push [6641,6653]
name: do_xcom_push [6641,6653]
===
match
---
string: "foo" [20400,20405]
string: "foo" [20400,20405]
===
match
---
name: operator [2602,2610]
name: operator [2602,2610]
===
match
---
name: dag_run [2181,2188]
name: dag_run [2181,2188]
===
match
---
name: pod_template_file [12549,12566]
name: pod_template_file [12549,12566]
===
match
---
operator: = [23564,23565]
operator: = [23564,23565]
===
match
---
string: "operator" [20168,20178]
string: "operator" [20168,20178]
===
match
---
string: 'operator' [14323,14333]
string: 'operator' [14323,14333]
===
match
---
operator: { [18002,18003]
operator: { [18002,18003]
===
match
---
comparison [13424,13462]
comparison [13424,13462]
===
match
---
operator: = [5099,5100]
operator: = [5099,5100]
===
match
---
argument [8397,8411]
argument [8397,8411]
===
match
---
number: 0 [9404,9405]
number: 0 [9404,9405]
===
match
---
name: do_xcom_push [7946,7958]
name: do_xcom_push [7946,7958]
===
match
---
operator: , [10318,10319]
operator: , [10318,10319]
===
match
---
atom_expr [19907,19924]
atom_expr [19907,19924]
===
match
---
name: metadata [9286,9294]
name: metadata [9286,9294]
===
match
---
operator: = [8870,8871]
operator: = [8870,8871]
===
match
---
trailer [13172,13182]
trailer [13172,13182]
===
match
---
operator: , [15698,15699]
operator: , [15698,15699]
===
match
---
string: "bar" [5366,5371]
string: "bar" [5366,5371]
===
match
---
atom_expr [7445,7474]
atom_expr [7445,7474]
===
match
---
argument [3942,3963]
argument [3942,3963]
===
match
---
dotted_name [6865,6875]
dotted_name [6865,6875]
===
match
---
operator: , [14590,14591]
operator: , [14590,14591]
===
match
---
operator: = [5682,5683]
operator: = [5682,5683]
===
match
---
comparison [10594,10631]
comparison [10594,10631]
===
match
---
name: value [16785,16790]
name: value [16785,16790]
===
match
---
operator: } [21808,21809]
operator: } [21808,21809]
===
match
---
string: "try_number" [15751,15763]
string: "try_number" [15751,15763]
===
match
---
name: name [15281,15285]
name: name [15281,15285]
===
match
---
atom [17874,18108]
atom [17874,18108]
===
match
---
name: pod [8072,8075]
name: pod [8072,8075]
===
match
---
trailer [2124,2158]
trailer [2124,2158]
===
match
---
name: labels [12842,12848]
name: labels [12842,12848]
===
match
---
operator: } [18149,18150]
operator: } [18149,18150]
===
match
---
operator: , [9123,9124]
operator: , [9123,9124]
===
match
---
suite [5655,6287]
suite [5655,6287]
===
match
---
name: containers [9474,9484]
name: containers [9474,9484]
===
match
---
assert_stmt [10784,11100]
assert_stmt [10784,11100]
===
match
---
argument [15003,15014]
argument [15003,15014]
===
match
---
argument [17372,17390]
argument [17372,17390]
===
match
---
expr_stmt [10047,10066]
expr_stmt [10047,10066]
===
match
---
simple_stmt [16551,16609]
simple_stmt [16551,16609]
===
match
---
operator: } [13139,13140]
operator: } [13139,13140]
===
match
---
name: obj [2743,2746]
name: obj [2743,2746]
===
match
---
trailer [20748,20753]
trailer [20748,20753]
===
match
---
atom_expr [14669,14696]
atom_expr [14669,14696]
===
match
---
name: mock [11041,11045]
name: mock [11041,11045]
===
match
---
string: 'match_fields' [13903,13917]
string: 'match_fields' [13903,13917]
===
match
---
trailer [3295,3308]
trailer [3295,3308]
===
match
---
name: k8s [8723,8726]
name: k8s [8723,8726]
===
match
---
argument [10204,10229]
argument [10204,10229]
===
match
---
operator: = [7926,7927]
operator: = [7926,7927]
===
match
---
name: mock [9933,9937]
name: mock [9933,9937]
===
match
---
operator: = [5753,5754]
operator: = [5753,5754]
===
match
---
operator: { [17753,17754]
operator: { [17753,17754]
===
match
---
string: "echo 10" [18311,18320]
string: "echo 10" [18311,18320]
===
match
---
argument [6583,6597]
argument [6583,6597]
===
match
---
name: test_pod_delete_even_on_launcher_error [6963,7001]
name: test_pod_delete_even_on_launcher_error [6963,7001]
===
match
---
name: str [16777,16780]
name: str [16777,16780]
===
match
---
operator: { [21046,21047]
operator: { [21046,21047]
===
match
---
trailer [19929,19940]
trailer [19929,19940]
===
match
---
string: "task" [22721,22727]
string: "task" [22721,22727]
===
match
---
operator: = [9010,9011]
operator: = [9010,9011]
===
match
---
operator: = [2204,2205]
operator: = [2204,2205]
===
match
---
argument [23319,23330]
argument [23319,23330]
===
match
---
operator: , [2741,2742]
operator: , [2741,2742]
===
match
---
operator: , [7812,7813]
operator: , [7812,7813]
===
match
---
argument [20480,20496]
argument [20480,20496]
===
match
---
atom_expr [15527,15546]
atom_expr [15527,15546]
===
match
---
name: namespace [17115,17124]
name: namespace [17115,17124]
===
match
---
atom_expr [23076,23113]
atom_expr [23076,23113]
===
match
---
argument [20095,20111]
argument [20095,20111]
===
match
---
operator: = [18436,18437]
operator: = [18436,18437]
===
match
---
operator: , [21060,21061]
operator: , [21060,21061]
===
match
---
atom_expr [6764,6790]
atom_expr [6764,6790]
===
match
---
name: metadata [10497,10505]
name: metadata [10497,10505]
===
match
---
string: "nodeAffinity" [17767,17781]
string: "nodeAffinity" [17767,17781]
===
match
---
dictorsetmaker [9710,9942]
dictorsetmaker [9710,9942]
===
match
---
atom_expr [23875,23897]
atom_expr [23875,23897]
===
match
---
name: sanitized_pod [21458,21471]
name: sanitized_pod [21458,21471]
===
match
---
name: containers [10603,10613]
name: containers [10603,10613]
===
match
---
expr_stmt [6348,6749]
expr_stmt [6348,6749]
===
match
---
name: value [4208,4213]
name: value [4208,4213]
===
match
---
name: in_cluster [21876,21886]
name: in_cluster [21876,21886]
===
match
---
expr_stmt [15927,15945]
expr_stmt [15927,15945]
===
match
---
string: "spec" [20817,20823]
string: "spec" [20817,20823]
===
match
---
trailer [8304,8539]
trailer [8304,8539]
===
match
---
name: pod [22911,22914]
name: pod [22911,22914]
===
match
---
name: k [20217,20218]
name: k [20217,20218]
===
match
---
operator: = [7576,7577]
operator: = [7576,7577]
===
match
---
atom_expr [22190,22227]
atom_expr [22190,22227]
===
match
---
name: arguments [21004,21013]
name: arguments [21004,21013]
===
match
---
name: cmds [16061,16065]
name: cmds [16061,16065]
===
match
---
arglist [5744,6136]
arglist [5744,6136]
===
match
---
string: "default" [16299,16308]
string: "default" [16299,16308]
===
match
---
name: context [17519,17526]
name: context [17519,17526]
===
match
---
name: self [1887,1891]
name: self [1887,1891]
===
match
---
operator: , [5901,5902]
operator: , [5901,5902]
===
match
---
name: test_describes_pod_on_failure [15882,15911]
name: test_describes_pod_on_failure [15882,15911]
===
match
---
trailer [5334,5341]
trailer [5334,5341]
===
match
---
string: "spec" [19971,19977]
string: "spec" [19971,19977]
===
match
---
operator: , [7255,7256]
operator: , [7255,7256]
===
match
---
trailer [15321,15326]
trailer [15321,15326]
===
match
---
operator: } [4705,4706]
operator: } [4705,4706]
===
match
---
operator: = [19588,19589]
operator: = [19588,19589]
===
match
---
suite [8574,11101]
suite [8574,11101]
===
match
---
funcdef [23136,23898]
funcdef [23136,23898]
===
match
---
operator: = [12476,12477]
operator: = [12476,12477]
===
match
---
string: "bash" [17188,17194]
string: "bash" [17188,17194]
===
match
---
argument [6523,6544]
argument [6523,6544]
===
match
---
expr_stmt [15955,16319]
expr_stmt [15955,16319]
===
match
---
atom_expr [15268,15285]
atom_expr [15268,15285]
===
match
---
string: "kubernetes_pod_operator" [5414,5439]
string: "kubernetes_pod_operator" [5414,5439]
===
match
---
trailer [4257,4260]
trailer [4257,4260]
===
match
---
atom [4692,4706]
atom [4692,4706]
===
match
---
operator: == [9496,9498]
operator: == [9496,9498]
===
match
---
simple_stmt [12643,12679]
simple_stmt [12643,12679]
===
match
---
expr_stmt [7568,7600]
expr_stmt [7568,7600]
===
match
---
name: node_selector [21553,21566]
name: node_selector [21553,21566]
===
match
---
string: 'match_fields' [14434,14448]
string: 'match_fields' [14434,14448]
===
match
---
operator: , [3344,3345]
operator: , [3344,3345]
===
match
---
string: "bar" [21054,21059]
string: "bar" [21054,21059]
===
match
---
argument [23673,23687]
argument [23673,23687]
===
match
---
param [20029,20033]
param [20029,20033]
===
match
---
name: create_pod_request_obj [22033,22055]
name: create_pod_request_obj [22033,22055]
===
match
---
trailer [4463,4484]
trailer [4463,4484]
===
match
---
simple_stmt [17560,17587]
simple_stmt [17560,17587]
===
match
---
trailer [16721,16729]
trailer [16721,16729]
===
match
---
name: create_context [16690,16704]
name: create_context [16690,16704]
===
match
---
atom [19485,19500]
atom [19485,19500]
===
match
---
string: "execution_date" [9915,9931]
string: "execution_date" [9915,9931]
===
match
---
assert_stmt [22183,22244]
assert_stmt [22183,22244]
===
match
---
string: "mynamespace" [13186,13199]
string: "mynamespace" [13186,13199]
===
match
---
name: spec [13428,13432]
name: spec [13428,13432]
===
match
---
atom [5345,5601]
atom [5345,5601]
===
match
---
arglist [3891,3926]
arglist [3891,3926]
===
match
---
atom_expr [20868,21270]
atom_expr [20868,21270]
===
match
---
argument [23488,23494]
argument [23488,23494]
===
match
---
operator: = [15957,15958]
operator: = [15957,15958]
===
match
---
atom [19132,19272]
atom [19132,19272]
===
match
---
name: in_cluster [8429,8439]
name: in_cluster [8429,8439]
===
match
---
trailer [20744,20787]
trailer [20744,20787]
===
match
---
string: "execution_date" [13099,13115]
string: "execution_date" [13099,13115]
===
match
---
operator: = [7276,7277]
operator: = [7276,7277]
===
match
---
string: "bar" [15575,15580]
string: "bar" [15575,15580]
===
match
---
argument [3553,3569]
argument [3553,3569]
===
match
---
name: isinstance [22134,22144]
name: isinstance [22134,22144]
===
match
---
name: V1Container [8791,8802]
name: V1Container [8791,8802]
===
match
---
operator: = [3803,3804]
operator: = [3803,3804]
===
match
---
trailer [22153,22167]
trailer [22153,22167]
===
match
---
atom_expr [20682,20718]
atom_expr [20682,20718]
===
match
---
operator: , [17168,17169]
operator: , [17168,17169]
===
match
---
expr_stmt [1818,1862]
expr_stmt [1818,1862]
===
match
---
atom_expr [14940,14953]
atom_expr [14940,14953]
===
match
---
trailer [23039,23053]
trailer [23039,23053]
===
match
---
name: sanitize_for_serialization [2710,2736]
name: sanitize_for_serialization [2710,2736]
===
match
---
trailer [8629,8642]
trailer [8629,8642]
===
match
---
string: "bash" [5817,5823]
string: "bash" [5817,5823]
===
match
---
simple_stmt [1039,1132]
simple_stmt [1039,1132]
===
match
---
string: "try_number" [10991,11003]
string: "try_number" [10991,11003]
===
match
---
string: "Always" [13329,13337]
string: "Always" [13329,13337]
===
match
---
trailer [8802,8955]
trailer [8802,8955]
===
match
---
operator: = [21886,21887]
operator: = [21886,21887]
===
match
---
operator: , [5150,5151]
operator: , [5150,5151]
===
match
---
atom [21046,21060]
atom [21046,21060]
===
match
---
argument [5777,5797]
argument [5777,5797]
===
match
---
string: "bash" [5101,5107]
string: "bash" [5101,5107]
===
match
---
trailer [21638,22015]
trailer [21638,22015]
===
match
---
trailer [18693,18702]
trailer [18693,18702]
===
match
---
name: pytest [875,881]
name: pytest [875,881]
===
match
---
assert_stmt [7648,7677]
assert_stmt [7648,7677]
===
match
---
string: "default" [7375,7384]
string: "default" [7375,7384]
===
match
---
operator: = [3322,3323]
operator: = [3322,3323]
===
match
---
operator: , [10293,10294]
operator: , [10293,10294]
===
match
---
arglist [3553,3644]
arglist [3553,3644]
===
match
---
arglist [20084,20126]
arglist [20084,20126]
===
match
---
string: "airflow.providers.cncf.kubernetes.utils.pod_launcher.PodLauncher.delete_pod" [6876,6953]
string: "airflow.providers.cncf.kubernetes.utils.pod_launcher.PodLauncher.delete_pod" [6876,6953]
===
match
---
string: "ubuntu:16.04" [13251,13265]
string: "ubuntu:16.04" [13251,13265]
===
match
---
operator: = [8663,8664]
operator: = [8663,8664]
===
match
---
expr_stmt [5664,5696]
expr_stmt [5664,5696]
===
match
---
name: KubernetesPodOperator [3697,3718]
name: KubernetesPodOperator [3697,3718]
===
match
---
atom_expr [9499,9534]
atom_expr [9499,9534]
===
match
---
operator: { [7216,7217]
operator: { [7216,7217]
===
match
---
dictorsetmaker [21047,21059]
dictorsetmaker [21047,21059]
===
match
---
suite [8196,8540]
suite [8196,8540]
===
match
---
name: run_pod [9229,9236]
name: run_pod [9229,9236]
===
match
---
name: KubernetesPodOperator [22454,22475]
name: KubernetesPodOperator [22454,22475]
===
match
---
operator: , [22550,22551]
operator: , [22550,22551]
===
match
---
name: name_base [17714,17723]
name: name_base [17714,17723]
===
match
---
argument [2074,2086]
argument [2074,2086]
===
match
---
string: "In" [19221,19225]
string: "In" [19221,19225]
===
match
---
operator: } [8677,8678]
operator: } [8677,8678]
===
match
---
argument [22713,22727]
argument [22713,22727]
===
match
---
operator: = [16104,16105]
operator: = [16104,16105]
===
match
---
dictorsetmaker [22653,22665]
dictorsetmaker [22653,22665]
===
match
---
operator: , [19210,19211]
operator: , [19210,19211]
===
match
---
argument [23726,23744]
argument [23726,23744]
===
match
---
argument [17115,17134]
argument [17115,17134]
===
match
---
name: self [5291,5295]
name: self [5291,5295]
===
match
---
simple_stmt [4510,4864]
simple_stmt [4510,4864]
===
match
---
atom [14255,14400]
atom [14255,14400]
===
match
---
comparison [12650,12678]
comparison [12650,12678]
===
match
---
operator: , [21739,21740]
operator: , [21739,21740]
===
match
---
string: "name" [21079,21085]
string: "name" [21079,21085]
===
match
---
string: "True" [10940,10946]
string: "True" [10940,10946]
===
match
---
atom [13669,13954]
atom [13669,13954]
===
match
---
atom_expr [22917,22943]
atom_expr [22917,22943]
===
match
---
name: node_selector [22154,22167]
name: node_selector [22154,22167]
===
match
---
argument [2221,2248]
argument [2221,2248]
===
match
---
string: "In" [18034,18038]
string: "In" [18034,18038]
===
match
---
argument [7793,7812]
argument [7793,7812]
===
match
---
atom_expr [20734,20787]
atom_expr [20734,20787]
===
match
---
trailer [9349,9358]
trailer [9349,9358]
===
match
---
expr_stmt [10377,10398]
expr_stmt [10377,10398]
===
match
---
name: name_base [7726,7735]
name: name_base [7726,7735]
===
match
---
string: "task_id" [10960,10969]
string: "task_id" [10960,10969]
===
match
---
string: 'In' [14335,14339]
string: 'In' [14335,14339]
===
match
---
operator: = [18503,18504]
operator: = [18503,18504]
===
match
---
name: sanitize_for_serialization [19849,19875]
name: sanitize_for_serialization [19849,19875]
===
match
---
string: 'values' [13810,13818]
string: 'values' [13810,13818]
===
match
---
name: k8s [3878,3881]
name: k8s [3878,3881]
===
match
---
name: name_base [7865,7874]
name: name_base [7865,7874]
===
match
---
argument [16193,16207]
argument [16193,16207]
===
match
---
name: sanitized_pod [21321,21334]
name: sanitized_pod [21321,21334]
===
match
---
string: "dag" [2081,2086]
string: "dag" [2081,2086]
===
match
---
string: "kubernetes_pod_operator" [12933,12958]
string: "kubernetes_pod_operator" [12933,12958]
===
match
---
operator: , [18544,18545]
operator: , [18544,18545]
===
match
---
name: self [20029,20033]
name: self [20029,20033]
===
match
---
string: "default" [10220,10229]
string: "default" [10220,10229]
===
match
---
arglist [12517,12581]
arglist [12517,12581]
===
match
---
operator: = [22080,22081]
operator: = [22080,22081]
===
match
---
arglist [4549,4853]
arglist [4549,4853]
===
match
---
atom_expr [9465,9495]
atom_expr [9465,9495]
===
match
---
trailer [4535,4863]
trailer [4535,4863]
===
match
---
string: "True" [9792,9798]
string: "True" [9792,9798]
===
match
---
name: name [21823,21827]
name: name [21823,21827]
===
match
---
name: V1EnvVar [3882,3890]
name: V1EnvVar [3882,3890]
===
match
---
operator: , [10870,10871]
operator: , [10870,10871]
===
match
---
parameters [2464,2480]
parameters [2464,2480]
===
match
---
name: name [14971,14975]
name: name [14971,14975]
===
match
---
suite [22437,22902]
suite [22437,22902]
===
match
---
atom [17482,17509]
atom [17482,17509]
===
match
---
name: SUCCESS [3331,3338]
name: SUCCESS [3331,3338]
===
match
---
atom [5887,5901]
atom [5887,5901]
===
match
---
name: KubernetesPodOperator [2890,2911]
name: KubernetesPodOperator [2890,2911]
===
match
---
operator: = [3128,3129]
operator: = [3128,3129]
===
match
---
name: task_id [23664,23671]
name: task_id [23664,23671]
===
match
---
operator: @ [2012,2013]
operator: @ [2012,2013]
===
match
---
simple_stmt [19374,19778]
simple_stmt [19374,19778]
===
match
---
arglist [22335,22426]
arglist [22335,22426]
===
match
---
number: 0 [9485,9486]
number: 0 [9485,9486]
===
match
---
operator: , [8987,8988]
operator: , [8987,8988]
===
match
---
string: "ubuntu:16.04" [7112,7126]
string: "ubuntu:16.04" [7112,7126]
===
match
---
name: self [3291,3295]
name: self [3291,3295]
===
match
---
string: "bartemplated" [4162,4176]
string: "bartemplated" [4162,4176]
===
match
---
name: self [16493,16497]
name: self [16493,16497]
===
match
---
operator: , [22167,22168]
operator: , [22167,22168]
===
match
---
name: create_context [7583,7597]
name: create_context [7583,7597]
===
match
---
simple_stmt [3693,4090]
simple_stmt [3693,4090]
===
match
---
operator: != [15286,15288]
operator: != [15286,15288]
===
match
---
operator: } [20412,20413]
operator: } [20412,20413]
===
match
---
string: "task" [4010,4016]
string: "task" [4010,4016]
===
match
---
name: tpl_file [14940,14948]
name: tpl_file [14940,14948]
===
match
---
name: run_pod [4883,4890]
name: run_pod [4883,4890]
===
match
---
argument [3474,3489]
argument [3474,3489]
===
match
---
name: pod [15527,15530]
name: pod [15527,15530]
===
match
---
argument [8911,8932]
argument [8911,8932]
===
match
---
name: create_pod_request_obj [18573,18595]
name: create_pod_request_obj [18573,18595]
===
match
---
string: "read_pod_namespaced_result" [16348,16376]
string: "read_pod_namespaced_result" [16348,16376]
===
match
---
operator: { [16877,16878]
operator: { [16877,16878]
===
match
---
trailer [9443,9449]
trailer [9443,9449]
===
match
---
atom [20066,20128]
atom [20066,20128]
===
match
---
name: client [898,904]
name: client [898,904]
===
match
---
name: create_pod_request_obj [22919,22941]
name: create_pod_request_obj [22919,22941]
===
match
---
trailer [23642,23652]
trailer [23642,23652]
===
match
---
simple_stmt [23697,23767]
simple_stmt [23697,23767]
===
match
---
import_from [1167,1204]
import_from [1167,1204]
===
match
---
operator: = [21335,21336]
operator: = [21335,21336]
===
match
---
string: "foo" [22653,22658]
string: "foo" [22653,22658]
===
match
---
string: "default" [7803,7812]
string: "default" [7803,7812]
===
match
---
string: "Equal" [20104,20111]
string: "Equal" [20104,20111]
===
match
---
name: context [3482,3489]
name: context [3482,3489]
===
match
---
argument [22745,22761]
argument [22745,22761]
===
match
---
name: k [10075,10076]
name: k [10075,10076]
===
match
---
dictorsetmaker [3950,3962]
dictorsetmaker [3950,3962]
===
match
---
name: k [16720,16721]
name: k [16720,16721]
===
match
---
name: in_cluster [18426,18436]
name: in_cluster [18426,18436]
===
match
---
name: node_selector [21977,21990]
name: node_selector [21977,21990]
===
match
---
name: k [3453,3454]
name: k [3453,3454]
===
match
---
atom_expr [18685,18702]
atom_expr [18685,18702]
===
match
---
expr_stmt [17048,17066]
expr_stmt [17048,17066]
===
match
---
string: "test" [3101,3107]
string: "test" [3101,3107]
===
match
---
string: "ts" [2303,2307]
string: "ts" [2303,2307]
===
match
---
string: "task" [16201,16207]
string: "task" [16201,16207]
===
match
---
name: test_env_vars [3664,3677]
name: test_env_vars [3664,3677]
===
match
---
name: KubernetesPodOperator [21617,21638]
name: KubernetesPodOperator [21617,21638]
===
match
---
simple_stmt [3423,3456]
simple_stmt [3423,3456]
===
match
---
atom_expr [22134,22174]
atom_expr [22134,22174]
===
match
---
name: k [23179,23180]
name: k [23179,23180]
===
match
---
atom [21014,21025]
atom [21014,21025]
===
match
---
simple_stmt [21451,21510]
simple_stmt [21451,21510]
===
match
---
name: values [19227,19233]
name: values [19227,19233]
===
match
---
argument [7916,7932]
argument [7916,7932]
===
match
---
simple_stmt [3291,3352]
simple_stmt [3291,3352]
===
match
---
string: "test" [4725,4731]
string: "test" [4725,4731]
===
match
---
operator: = [16298,16299]
operator: = [16298,16299]
===
match
---
operator: , [4628,4629]
operator: , [4628,4629]
===
match
---
operator: = [16346,16347]
operator: = [16346,16347]
===
match
---
name: sanitize_for_serialization [18627,18653]
name: sanitize_for_serialization [18627,18653]
===
match
---
trailer [19195,19242]
trailer [19195,19242]
===
match
---
operator: , [20343,20344]
operator: , [20343,20344]
===
match
---
simple_stmt [10541,10579]
simple_stmt [10541,10579]
===
match
---
parameters [8567,8573]
parameters [8567,8573]
===
match
---
string: "ti" [2373,2377]
string: "ti" [2373,2377]
===
match
---
operator: = [20459,20460]
operator: = [20459,20460]
===
match
---
trailer [1982,2006]
trailer [1982,2006]
===
match
---
operator: , [3012,3013]
operator: , [3012,3013]
===
match
---
simple_stmt [1712,1755]
simple_stmt [1712,1755]
===
match
---
name: raises [7530,7536]
name: raises [7530,7536]
===
match
---
simple_stmt [5315,5602]
simple_stmt [5315,5602]
===
match
---
assert_stmt [18667,18719]
assert_stmt [18667,18719]
===
match
---
operator: , [6466,6467]
operator: , [6466,6467]
===
match
---
trailer [17548,17551]
trailer [17548,17551]
===
match
---
name: ti [23640,23642]
name: ti [23640,23642]
===
match
---
name: tolerations [21228,21239]
name: tolerations [21228,21239]
===
match
---
atom_expr [1967,2006]
atom_expr [1967,2006]
===
match
---
simple_stmt [1343,1473]
simple_stmt [1343,1473]
===
match
---
string: "ubuntu:16.04" [20295,20309]
string: "ubuntu:16.04" [20295,20309]
===
match
---
string: "default" [22503,22512]
string: "default" [22503,22512]
===
match
---
simple_stmt [23629,23689]
simple_stmt [23629,23689]
===
match
---
trailer [4882,4890]
trailer [4882,4890]
===
match
---
string: "default" [3599,3608]
string: "default" [3599,3608]
===
match
---
name: task_id [20452,20459]
name: task_id [20452,20459]
===
match
---
import_from [938,985]
import_from [938,985]
===
match
---
atom_expr [23640,23688]
atom_expr [23640,23688]
===
match
---
operator: , [7160,7161]
operator: , [7160,7161]
===
match
---
trailer [23540,23548]
trailer [23540,23548]
===
match
---
operator: , [8932,8933]
operator: , [8932,8933]
===
match
---
atom_expr [2620,2653]
atom_expr [2620,2653]
===
match
---
name: V1NodeAffinity [18855,18869]
name: V1NodeAffinity [18855,18869]
===
match
---
name: image [15009,15014]
name: image [15009,15014]
===
match
---
operator: = [22966,22967]
operator: = [22966,22967]
===
match
---
atom [17783,18140]
atom [17783,18140]
===
match
---
simple_stmt [15202,15249]
simple_stmt [15202,15249]
===
match
---
name: pod_spec [9277,9285]
name: pod_spec [9277,9285]
===
match
---
operator: , [20166,20167]
operator: , [20166,20167]
===
match
---
atom_expr [16777,16791]
atom_expr [16777,16791]
===
match
---
name: name [14949,14953]
name: name [14949,14953]
===
match
---
name: ANY [11046,11049]
name: ANY [11046,11049]
===
match
---
name: match_expressions [19114,19131]
name: match_expressions [19114,19131]
===
match
---
number: 0 [21421,21422]
number: 0 [21421,21422]
===
match
---
dotted_name [887,904]
dotted_name [887,904]
===
match
---
operator: } [4176,4177]
operator: } [4176,4177]
===
match
---
operator: = [16683,16684]
operator: = [16683,16684]
===
match
---
operator: = [4130,4131]
operator: = [4130,4131]
===
match
---
name: pod [23440,23443]
name: pod [23440,23443]
===
match
---
name: patch [1648,1653]
name: patch [1648,1653]
===
match
---
name: name [9269,9273]
name: name [9269,9273]
===
match
---
atom [21569,21603]
atom [21569,21603]
===
match
---
name: full_pod_spec [9176,9189]
name: full_pod_spec [9176,9189]
===
match
---
name: name_base [14976,14985]
name: name_base [14976,14985]
===
match
---
operator: , [18356,18357]
operator: , [18356,18357]
===
match
---
string: "dag" [15642,15647]
string: "dag" [15642,15647]
===
match
---
assert_stmt [23013,23060]
assert_stmt [23013,23060]
===
match
---
name: spec [9388,9392]
name: spec [9388,9392]
===
match
---
name: metadata [12833,12841]
name: metadata [12833,12841]
===
match
---
argument [19227,19241]
argument [19227,19241]
===
match
---
argument [4745,4759]
argument [4745,4759]
===
match
---
simple_stmt [4872,4894]
simple_stmt [4872,4894]
===
match
---
simple_stmt [18565,18598]
simple_stmt [18565,18598]
===
match
---
operator: } [10356,10357]
operator: } [10356,10357]
===
match
---
operator: = [6010,6011]
operator: = [6010,6011]
===
match
---
name: V1LocalObjectReference [6054,6076]
name: V1LocalObjectReference [6054,6076]
===
match
---
argument [23558,23590]
argument [23558,23590]
===
match
---
operator: = [19717,19718]
operator: = [19717,19718]
===
match
---
name: context [17578,17585]
name: context [17578,17585]
===
match
---
atom_expr [1623,1640]
atom_expr [1623,1640]
===
match
---
name: self [8568,8572]
name: self [8568,8572]
===
match
---
name: V1EnvFromSource [4408,4423]
name: V1EnvFromSource [4408,4423]
===
match
---
operator: = [20629,20630]
operator: = [20629,20630]
===
match
---
atom_expr [2582,2611]
atom_expr [2582,2611]
===
match
---
trailer [18854,18869]
trailer [18854,18869]
===
match
---
operator: = [19791,19792]
operator: = [19791,19792]
===
match
---
operator: } [2446,2447]
operator: } [2446,2447]
===
match
---
expr_stmt [1623,1703]
expr_stmt [1623,1703]
===
match
---
name: k8s [19166,19169]
name: k8s [19166,19169]
===
match
---
operator: , [17911,17912]
operator: , [17911,17912]
===
match
---
argument [18335,18356]
argument [18335,18356]
===
match
---
name: self [15091,15095]
name: self [15091,15095]
===
match
---
trailer [13365,13376]
trailer [13365,13376]
===
match
---
name: stop [1904,1908]
name: stop [1904,1908]
===
match
---
arglist [5028,5266]
arglist [5028,5266]
===
match
---
trailer [9487,9495]
trailer [9487,9495]
===
match
---
string: "bash" [6460,6466]
string: "bash" [6460,6466]
===
match
---
name: self [7445,7449]
name: self [7445,7449]
===
match
---
trailer [9676,9685]
trailer [9676,9685]
===
match
---
name: affinity [19741,19749]
name: affinity [19741,19749]
===
match
---
name: dag_id [2074,2080]
name: dag_id [2074,2080]
===
match
---
trailer [8030,8053]
trailer [8030,8053]
===
match
---
atom_expr [17529,17551]
atom_expr [17529,17551]
===
match
---
trailer [13432,13453]
trailer [13432,13453]
===
match
---
atom [23290,23305]
atom [23290,23305]
===
match
---
name: spec [23035,23039]
name: spec [23035,23039]
===
match
---
operator: = [3067,3068]
operator: = [3067,3068]
===
match
---
name: in_cluster [20480,20490]
name: in_cluster [20480,20490]
===
match
---
atom_expr [6806,6846]
atom_expr [6806,6846]
===
match
---
expr_stmt [19787,19819]
expr_stmt [19787,19819]
===
match
---
funcdef [4958,5602]
funcdef [4958,5602]
===
match
---
argument [7327,7345]
argument [7327,7345]
===
match
---
trailer [9484,9487]
trailer [9484,9487]
===
match
---
testlist_comp [20329,20342]
testlist_comp [20329,20342]
===
match
---
trailer [6261,6285]
trailer [6261,6285]
===
match
---
operator: , [23388,23389]
operator: , [23388,23389]
===
match
---
operator: , [16237,16238]
operator: , [16237,16238]
===
match
---
argument [21039,21060]
argument [21039,21060]
===
match
---
operator: = [20866,20867]
operator: = [20866,20867]
===
match
---
name: pod [8023,8026]
name: pod [8023,8026]
===
match
---
trailer [14872,15072]
trailer [14872,15072]
===
match
---
operator: == [9274,9276]
operator: == [9274,9276]
===
match
---
string: "test" [15939,15945]
string: "test" [15939,15945]
===
match
---
operator: == [18769,18771]
operator: == [18769,18771]
===
match
---
operator: , [9901,9902]
operator: , [9901,9902]
===
match
---
name: name [9295,9299]
name: name [9295,9299]
===
match
---
trailer [2487,2493]
trailer [2487,2493]
===
match
---
argument [5940,5954]
argument [5940,5954]
===
match
---
atom [16418,16457]
atom [16418,16457]
===
match
---
name: labels [22645,22651]
name: labels [22645,22651]
===
match
---
param [2049,2053]
param [2049,2053]
===
match
---
atom_expr [16385,16415]
atom_expr [16385,16415]
===
match
---
trailer [15326,15337]
trailer [15326,15337]
===
match
---
operator: , [19570,19571]
operator: , [19570,19571]
===
match
---
name: do_xcom_push [5247,5259]
name: do_xcom_push [5247,5259]
===
match
---
operator: = [4009,4010]
operator: = [4009,4010]
===
match
---
operator: = [6350,6351]
operator: = [6350,6351]
===
match
---
name: ANY [11086,11089]
name: ANY [11086,11089]
===
match
---
trailer [8084,8089]
trailer [8084,8089]
===
match
---
name: pod [13219,13222]
name: pod [13219,13222]
===
match
---
string: "test" [3982,3988]
string: "test" [3982,3988]
===
match
---
trailer [6373,6749]
trailer [6373,6749]
===
match
---
argument [21823,21834]
argument [21823,21834]
===
match
---
name: k [10396,10397]
name: k [10396,10397]
===
match
---
name: task [2130,2134]
name: task [2130,2134]
===
match
---
trailer [21471,21479]
trailer [21471,21479]
===
match
---
string: "-cx" [6468,6473]
string: "-cx" [6468,6473]
===
match
---
atom_expr [18571,18597]
atom_expr [18571,18597]
===
match
---
operator: = [6762,6763]
operator: = [6762,6763]
===
match
---
import_as_names [912,936]
import_as_names [912,936]
===
match
---
argument [6713,6738]
argument [6713,6738]
===
match
---
name: spec [13361,13365]
name: spec [13361,13365]
===
match
---
name: task_id [17314,17321]
name: task_id [17314,17321]
===
match
---
string: "footemplated" [4139,4153]
string: "footemplated" [4139,4153]
===
match
---
name: self [19844,19848]
name: self [19844,19848]
===
match
---
operator: == [23114,23116]
operator: == [23114,23116]
===
match
---
operator: { [5136,5137]
operator: { [5136,5137]
===
match
---
trailer [11045,11049]
trailer [11045,11049]
===
match
---
name: KubernetesPodOperator [20221,20242]
name: KubernetesPodOperator [20221,20242]
===
match
---
operator: = [18850,18851]
operator: = [18850,18851]
===
match
---
operator: = [21615,21616]
operator: = [21615,21616]
===
match
---
expr_stmt [6155,6187]
expr_stmt [6155,6187]
===
match
---
atom [6530,6544]
atom [6530,6544]
===
match
---
expr_stmt [17742,18150]
expr_stmt [17742,18150]
===
match
---
operator: = [8918,8919]
operator: = [8918,8919]
===
match
---
operator: = [22755,22756]
operator: = [22755,22756]
===
match
---
trailer [10616,10622]
trailer [10616,10622]
===
match
---
parameters [2736,2747]
parameters [2736,2747]
===
match
---
trailer [23878,23887]
trailer [23878,23887]
===
match
---
operator: , [16431,16432]
operator: , [16431,16432]
===
match
---
trailer [3473,3490]
trailer [3473,3490]
===
match
---
name: task_id [12517,12524]
name: task_id [12517,12524]
===
match
---
operator: , [8655,8656]
operator: , [8655,8656]
===
match
---
atom_expr [18622,18658]
atom_expr [18622,18658]
===
match
---
operator: = [22791,22792]
operator: = [22791,22792]
===
match
---
simple_stmt [10377,10399]
simple_stmt [10377,10399]
===
match
---
name: test_image_pull_policy_correctly_set [6296,6332]
name: test_image_pull_policy_correctly_set [6296,6332]
===
match
---
atom_expr [13357,13387]
atom_expr [13357,13387]
===
match
---
name: metadata [15531,15539]
name: metadata [15531,15539]
===
match
---
trailer [20824,20839]
trailer [20824,20839]
===
match
---
name: labels [5335,5341]
name: labels [5335,5341]
===
match
---
simple_stmt [18667,18720]
simple_stmt [18667,18720]
===
match
---
number: 0 [10614,10615]
number: 0 [10614,10615]
===
match
---
operator: , [5831,5832]
operator: , [5831,5832]
===
match
---
argument [23402,23420]
argument [23402,23420]
===
match
---
operator: , [5265,5266]
operator: , [5265,5266]
===
match
---
name: pod [23000,23003]
name: pod [23000,23003]
===
match
---
operator: , [2550,2551]
operator: , [2550,2551]
===
match
---
operator: } [17271,17272]
operator: } [17271,17272]
===
match
---
expr_stmt [20864,21270]
expr_stmt [20864,21270]
===
match
---
trailer [2000,2005]
trailer [2000,2005]
===
match
---
name: env_vars [3868,3876]
name: env_vars [3868,3876]
===
match
---
operator: = [18237,18238]
operator: = [18237,18238]
===
match
---
trailer [12618,12626]
trailer [12618,12626]
===
match
---
param [17033,17037]
param [17033,17037]
===
match
---
operator: , [7384,7385]
operator: , [7384,7385]
===
match
---
suite [21544,23131]
suite [21544,23131]
===
match
---
name: k [2886,2887]
name: k [2886,2887]
===
match
---
comparison [13285,13337]
comparison [13285,13337]
===
match
---
name: write [12407,12412]
name: write [12407,12412]
===
match
---
trailer [3396,3409]
trailer [3396,3409]
===
match
---
trailer [4442,4463]
trailer [4442,4463]
===
match
---
operator: = [6529,6530]
operator: = [6529,6530]
===
match
---
arglist [18685,18718]
arglist [18685,18718]
===
match
---
name: cluster_context [6713,6728]
name: cluster_context [6713,6728]
===
match
---
operator: , [19688,19689]
operator: , [19688,19689]
===
match
---
simple_stmt [23179,23432]
simple_stmt [23179,23432]
===
match
---
name: k [4247,4248]
name: k [4247,4248]
===
match
---
name: pod [6758,6761]
name: pod [6758,6761]
===
match
---
name: do_xcom_push [10172,10184]
name: do_xcom_push [10172,10184]
===
match
---
string: "echo 10" [20368,20377]
string: "echo 10" [20368,20377]
===
match
---
import_as_name [923,936]
import_as_name [923,936]
===
match
---
atom_expr [23713,23766]
atom_expr [23713,23766]
===
match
---
name: test_pod_name_required [8167,8189]
name: test_pod_name_required [8167,8189]
===
match
---
trailer [6765,6788]
trailer [6765,6788]
===
match
---
arglist [8224,8268]
arglist [8224,8268]
===
match
---
assert_stmt [12643,12678]
assert_stmt [12643,12678]
===
match
---
name: image [10307,10312]
name: image [10307,10312]
===
match
---
name: do_xcom_push [4060,4072]
name: do_xcom_push [4060,4072]
===
match
---
atom [17258,17272]
atom [17258,17272]
===
match
---
trailer [23030,23060]
trailer [23030,23060]
===
match
---
operator: = [11166,11167]
operator: = [11166,11167]
===
match
---
number: 0 [9524,9525]
number: 0 [9524,9525]
===
match
---
trailer [1971,1982]
trailer [1971,1982]
===
match
---
name: image [7106,7111]
name: image [7106,7111]
===
match
---
atom [21763,21774]
atom [21763,21774]
===
match
---
string: "ubuntu:16.04" [22536,22550]
string: "ubuntu:16.04" [22536,22550]
===
match
---
atom [22616,22627]
atom [22616,22627]
===
match
---
operator: , [8240,8241]
operator: , [8240,8241]
===
match
---
name: namespace [8322,8331]
name: namespace [8322,8331]
===
match
---
name: image [10617,10622]
name: image [10617,10622]
===
match
---
dictorsetmaker [17900,18086]
dictorsetmaker [17900,18086]
===
match
---
operator: , [19598,19599]
operator: , [19598,19599]
===
match
---
operator: , [23271,23272]
operator: , [23271,23272]
===
match
---
trailer [4423,4485]
trailer [4423,4485]
===
match
---
assert_stmt [8120,8157]
assert_stmt [8120,8157]
===
match
---
argument [20542,20567]
argument [20542,20567]
===
match
---
simple_stmt [5664,5697]
simple_stmt [5664,5697]
===
match
---
operator: = [23382,23383]
operator: = [23382,23383]
===
match
---
operator: , [16179,16180]
operator: , [16179,16180]
===
match
---
argument [5998,6016]
argument [5998,6016]
===
match
---
name: k [9008,9009]
name: k [9008,9009]
===
match
---
atom_expr [14851,15072]
atom_expr [14851,15072]
===
match
---
argument [8718,8987]
argument [8718,8987]
===
match
---
operator: } [13953,13954]
operator: } [13953,13954]
===
match
---
name: cmds [6454,6458]
name: cmds [6454,6458]
===
match
---
name: monitor_mock [2508,2520]
name: monitor_mock [2508,2520]
===
match
---
trailer [1922,1933]
trailer [1922,1933]
===
match
---
operator: , [13869,13870]
operator: , [13869,13870]
===
match
---
operator: = [20522,20523]
operator: = [20522,20523]
===
match
---
atom [6459,6474]
atom [6459,6474]
===
match
---
string: "/tmp/fake_file" [2861,2877]
string: "/tmp/fake_file" [2861,2877]
===
match
---
name: pytest [16623,16629]
name: pytest [16623,16629]
===
match
---
operator: = [4843,4844]
operator: = [4843,4844]
===
match
---
simple_stmt [7445,7510]
simple_stmt [7445,7510]
===
match
---
name: KubernetesPodOperator [12478,12499]
name: KubernetesPodOperator [12478,12499]
===
match
---
operator: = [23181,23182]
operator: = [23181,23182]
===
match
---
operator: = [23749,23750]
operator: = [23749,23750]
===
match
---
atom [17951,18085]
atom [17951,18085]
===
match
---
name: client_mock [3365,3376]
name: client_mock [3365,3376]
===
match
---
string: "execution_date" [5564,5580]
string: "execution_date" [5564,5580]
===
match
---
assert_stmt [15261,15298]
assert_stmt [15261,15298]
===
match
---
argument [3868,3928]
argument [3868,3928]
===
match
---
string: "-cx" [21733,21738]
string: "-cx" [21733,21738]
===
match
---
name: in_cluster [9075,9085]
name: in_cluster [9075,9085]
===
match
---
name: test_node_selector [21519,21537]
name: test_node_selector [21519,21537]
===
match
---
argument [20289,20309]
argument [20289,20309]
===
match
---
operator: = [19682,19683]
operator: = [19682,19683]
===
match
---
arglist [3732,4079]
arglist [3732,4079]
===
match
---
name: ti [23713,23715]
name: ti [23713,23715]
===
match
---
name: k [4989,4990]
name: k [4989,4990]
===
match
---
operator: , [7230,7231]
operator: , [7230,7231]
===
match
---
trailer [2673,2684]
trailer [2673,2684]
===
match
---
operator: , [4731,4732]
operator: , [4731,4732]
===
match
---
name: pod_template_yaml [11148,11165]
name: pod_template_yaml [11148,11165]
===
match
---
name: env_from [4392,4400]
name: env_from [4392,4400]
===
match
---
operator: = [6497,6498]
operator: = [6497,6498]
===
match
---
name: name_base [10522,10531]
name: name_base [10522,10531]
===
match
---
simple_stmt [17519,17552]
simple_stmt [17519,17552]
===
match
---
operator: , [6016,6017]
operator: , [6016,6017]
===
match
---
argument [21074,21085]
argument [21074,21085]
===
match
---
name: isinstance [18674,18684]
name: isinstance [18674,18684]
===
match
---
name: name [7860,7864]
name: name [7860,7864]
===
match
---
trailer [1787,1801]
trailer [1787,1801]
===
match
---
string: "test" [17060,17066]
string: "test" [17060,17066]
===
match
---
name: self [7578,7582]
name: self [7578,7582]
===
match
---
trailer [1903,1908]
trailer [1903,1908]
===
match
---
name: name [12663,12667]
name: name [12663,12667]
===
match
---
operator: , [7874,7875]
operator: , [7874,7875]
===
match
---
atom [18002,18058]
atom [18002,18058]
===
match
---
name: create_context [2034,2048]
name: create_context [2034,2048]
===
match
---
operator: { [17951,17952]
operator: { [17951,17952]
===
match
---
assert_stmt [5315,5601]
assert_stmt [5315,5601]
===
match
---
operator: = [18270,18271]
operator: = [18270,18271]
===
match
---
name: monitor_patch [1788,1801]
name: monitor_patch [1788,1801]
===
match
---
operator: , [14044,14045]
operator: , [14044,14045]
===
match
---
simple_stmt [13475,14649]
simple_stmt [13475,14649]
===
match
---
atom [8664,8678]
atom [8664,8678]
===
match
---
name: spec [9469,9473]
name: spec [9469,9473]
===
match
---
name: AirflowException [16637,16653]
name: AirflowException [16637,16653]
===
match
---
argument [7297,7313]
argument [7297,7313]
===
match
---
trailer [8736,8987]
trailer [8736,8987]
===
match
---
string: "ubuntu:16.04" [18238,18252]
string: "ubuntu:16.04" [18238,18252]
===
match
---
operator: , [23297,23298]
operator: , [23297,23298]
===
match
---
name: namespace [4549,4558]
name: namespace [4549,4558]
===
match
---
trailer [16850,16855]
trailer [16850,16855]
===
match
---
operator: = [21723,21724]
operator: = [21723,21724]
===
match
---
name: task_id [7888,7895]
name: task_id [7888,7895]
===
match
---
atom_expr [6235,6285]
atom_expr [6235,6285]
===
match
---
dictorsetmaker [17981,18059]
dictorsetmaker [17981,18059]
===
match
---
argument [18426,18442]
argument [18426,18442]
===
match
---
string: "echo 10" [21015,21024]
string: "echo 10" [21015,21024]
===
match
---
operator: , [20438,20439]
operator: , [20438,20439]
===
match
---
operator: = [18341,18342]
operator: = [18341,18342]
===
match
---
simple_stmt [3464,3491]
simple_stmt [3464,3491]
===
match
---
trailer [1860,1862]
trailer [1860,1862]
===
match
---
name: task_instance [2423,2436]
name: task_instance [2423,2436]
===
match
---
name: context [7568,7575]
name: context [7568,7575]
===
match
---
arglist [19017,19299]
arglist [19017,19299]
===
match
---
arglist [22493,22887]
arglist [22493,22887]
===
match
---
name: self [5649,5653]
name: self [5649,5653]
===
match
---
trailer [9387,9392]
trailer [9387,9392]
===
match
---
atom [17187,17202]
atom [17187,17202]
===
match
---
name: test_randomize_pod_name [7687,7710]
name: test_randomize_pod_name [7687,7710]
===
match
---
atom_expr [19896,19941]
atom_expr [19896,19941]
===
match
---
trailer [12662,12667]
trailer [12662,12667]
===
match
---
name: pod [9256,9259]
name: pod [9256,9259]
===
match
---
testlist_comp [4622,4635]
testlist_comp [4622,4635]
===
match
---
assert_stmt [10587,10631]
assert_stmt [10587,10631]
===
match
---
name: test_image_pull_secrets_correctly_set [5611,5648]
name: test_image_pull_secrets_correctly_set [5611,5648]
===
match
---
expr_stmt [23470,23529]
expr_stmt [23470,23529]
===
match
---
number: 1 [19024,19025]
number: 1 [19024,19025]
===
match
---
name: pod [10377,10380]
name: pod [10377,10380]
===
match
---
name: cmds [2992,2996]
name: cmds [2992,2996]
===
match
---
name: operators [1078,1087]
name: operators [1078,1087]
===
match
---
name: fake_pull_secrets [6267,6284]
name: fake_pull_secrets [6267,6284]
===
match
---
trailer [6185,6187]
trailer [6185,6187]
===
match
---
operator: , [10190,10191]
operator: , [10190,10191]
===
match
---
operator: , [15813,15814]
operator: , [15813,15814]
===
match
---
name: in_cluster [5968,5978]
name: in_cluster [5968,5978]
===
match
---
operator: , [20956,20957]
operator: , [20956,20957]
===
match
---
string: "default" [18504,18513]
string: "default" [18504,18513]
===
match
---
name: timezone [1158,1166]
name: timezone [1158,1166]
===
match
---
operator: , [18474,18475]
operator: , [18474,18475]
===
match
---
operator: = [3695,3696]
operator: = [3695,3696]
===
match
---
atom_expr [1763,1780]
atom_expr [1763,1780]
===
match
---
trailer [13376,13379]
trailer [13376,13379]
===
match
---
name: task_id [23344,23351]
name: task_id [23344,23351]
===
match
---
name: pod [12650,12653]
name: pod [12650,12653]
===
match
---
string: "matchExpressions" [17981,17999]
string: "matchExpressions" [17981,17999]
===
match
---
operator: = [3222,3223]
operator: = [3222,3223]
===
match
---
operator: , [17358,17359]
operator: , [17358,17359]
===
match
---
operator: , [3608,3609]
operator: , [3608,3609]
===
match
---
atom_expr [6161,6187]
atom_expr [6161,6187]
===
match
---
name: k [4510,4511]
name: k [4510,4511]
===
match
---
name: start_patch [1348,1359]
name: start_patch [1348,1359]
===
match
---
operator: { [3949,3950]
operator: { [3949,3950]
===
match
---
number: 0 [4258,4259]
number: 0 [4258,4259]
===
match
---
name: image [2958,2963]
name: image [2958,2963]
===
match
---
string: 'In' [13804,13808]
string: 'In' [13804,13808]
===
match
---
simple_stmt [15311,15356]
simple_stmt [15311,15356]
===
match
---
argument [5217,5233]
argument [5217,5233]
===
match
---
name: containers [13366,13376]
name: containers [13366,13376]
===
match
---
name: called [17657,17663]
name: called [17657,17663]
===
match
---
argument [7244,7255]
argument [7244,7255]
===
match
---
name: pod [19907,19910]
name: pod [19907,19910]
===
match
---
expr_stmt [1343,1472]
expr_stmt [1343,1472]
===
match
---
name: do_xcom_push [19670,19682]
name: do_xcom_push [19670,19682]
===
match
---
atom_expr [16781,16790]
atom_expr [16781,16790]
===
match
---
name: called [16977,16983]
name: called [16977,16983]
===
match
---
trailer [9236,9239]
trailer [9236,9239]
===
match
---
name: labels [21039,21045]
name: labels [21039,21045]
===
match
---
string: "echo 10" [3037,3046]
string: "echo 10" [3037,3046]
===
match
---
operator: , [21259,21260]
operator: , [21259,21260]
===
match
---
name: tolerations [21409,21420]
name: tolerations [21409,21420]
===
match
---
argument [4685,4706]
argument [4685,4706]
===
match
---
operator: = [18208,18209]
operator: = [18208,18209]
===
match
---
name: node_selector [23040,23053]
name: node_selector [23040,23053]
===
match
---
operator: = [20974,20975]
operator: = [20974,20975]
===
match
---
operator: = [5259,5260]
operator: = [5259,5260]
===
match
---
arglist [2198,2248]
arglist [2198,2248]
===
match
---
name: run_pod [23451,23458]
name: run_pod [23451,23458]
===
match
---
operator: = [2142,2143]
operator: = [2142,2143]
===
match
---
comparison [10791,11100]
comparison [10791,11100]
===
match
---
parameters [2833,2839]
parameters [2833,2839]
===
match
---
atom_expr [1983,2005]
atom_expr [1983,2005]
===
match
---
operator: , [17237,17238]
operator: , [17237,17238]
===
match
---
argument [3211,3232]
argument [3211,3232]
===
match
---
operator: , [3107,3108]
operator: , [3107,3108]
===
match
---
name: do_xcom_push [5998,6010]
name: do_xcom_push [5998,6010]
===
match
---
string: 'preference' [13655,13667]
string: 'preference' [13655,13667]
===
match
---
arglist [23031,23059]
arglist [23031,23059]
===
match
---
trailer [9440,9443]
trailer [9440,9443]
===
match
---
string: "default" [17420,17429]
string: "default" [17420,17429]
===
match
---
operator: = [23256,23257]
operator: = [23256,23257]
===
match
---
name: start_patch [1892,1903]
name: start_patch [1892,1903]
===
match
---
argument [18398,18412]
argument [18398,18412]
===
match
---
name: do_xcom_push [21906,21918]
name: do_xcom_push [21906,21918]
===
match
---
operator: , [5550,5551]
operator: , [5550,5551]
===
match
---
trailer [22032,22055]
trailer [22032,22055]
===
match
---
operator: = [7374,7375]
operator: = [7374,7375]
===
match
---
argument [20113,20126]
argument [20113,20126]
===
match
---
argument [5061,5081]
argument [5061,5081]
===
match
---
name: image [15341,15346]
name: image [15341,15346]
===
match
---
string: 'match_expressions' [13703,13722]
string: 'match_expressions' [13703,13722]
===
match
---
operator: } [16895,16896]
operator: } [16895,16896]
===
match
---
operator: = [22720,22721]
operator: = [22720,22721]
===
match
---
operator: = [4040,4041]
operator: = [4040,4041]
===
match
---
operator: , [22588,22589]
operator: , [22588,22589]
===
match
---
operator: , [18513,18514]
operator: , [18513,18514]
===
match
---
name: name [6262,6266]
name: name [6262,6266]
===
match
---
dictorsetmaker [16138,16150]
dictorsetmaker [16138,16150]
===
match
---
name: test_envs_from_configmaps [4293,4318]
name: test_envs_from_configmaps [4293,4318]
===
match
---
string: "foo" [10828,10833]
string: "foo" [10828,10833]
===
match
---
atom_expr [2309,2333]
atom_expr [2309,2333]
===
match
---
operator: = [5707,5708]
operator: = [5707,5708]
===
match
---
string: "bash" [16067,16073]
string: "bash" [16067,16073]
===
match
---
name: do_xcom_push [20510,20522]
name: do_xcom_push [20510,20522]
===
match
---
comparison [18735,18780]
comparison [18735,18780]
===
match
---
operator: = [20680,20681]
operator: = [20680,20681]
===
match
---
name: name [21074,21078]
name: name [21074,21078]
===
match
---
name: staticmethod [2013,2025]
name: staticmethod [2013,2025]
===
match
---
operator: == [6847,6849]
operator: == [6847,6849]
===
match
---
string: "ubuntu:16.04" [4588,4602]
string: "ubuntu:16.04" [4588,4602]
===
match
---
name: task_id [3121,3128]
name: task_id [3121,3128]
===
match
---
name: pod_spec [9416,9424]
name: pod_spec [9416,9424]
===
match
---
expr_stmt [7034,7436]
expr_stmt [7034,7436]
===
match
---
name: State [17483,17488]
name: State [17483,17488]
===
match
---
trailer [2775,2802]
trailer [2775,2802]
===
match
---
name: key [23746,23749]
name: key [23746,23749]
===
match
---
string: "bash" [3805,3811]
string: "bash" [3805,3811]
===
match
---
arglist [23653,23687]
arglist [23653,23687]
===
match
---
operator: , [3751,3752]
operator: , [3751,3752]
===
match
---
name: labels [7209,7215]
name: labels [7209,7215]
===
match
---
atom [8765,8973]
atom [8765,8973]
===
match
---
name: execution_date [2221,2235]
name: execution_date [2221,2235]
===
match
---
argument [9137,9162]
argument [9137,9162]
===
match
---
name: containers [8754,8764]
name: containers [8754,8764]
===
match
---
name: affinity [18694,18702]
name: affinity [18694,18702]
===
match
---
operator: , [2219,2220]
operator: , [2219,2220]
===
match
---
atom_expr [8029,8055]
atom_expr [8029,8055]
===
match
---
name: image [15003,15008]
name: image [15003,15008]
===
match
---
classdef [1262,23898]
classdef [1262,27643]
===
match
---
name: namespace [23218,23227]
name: namespace [23218,23227]
===
match
---
name: TaskInstance [2112,2124]
name: TaskInstance [2112,2124]
===
match
---
trailer [2773,2775]
trailer [2773,2775]
===
match
---
operator: } [16855,16856]
operator: } [16855,16856]
===
match
---
trailer [9392,9403]
trailer [9392,9403]
===
match
---
name: affinity [13475,13483]
name: affinity [13475,13483]
===
match
---
operator: , [19025,19026]
operator: , [19025,19026]
===
match
---
operator: , [1016,1017]
operator: , [1016,1017]
===
match
---
name: pod [22114,22117]
name: pod [22114,22117]
===
match
---
number: 0 [2698,2699]
number: 0 [2698,2699]
===
match
---
argument [2958,2978]
argument [2958,2978]
===
match
---
simple_stmt [6799,6859]
simple_stmt [6799,6859]
===
match
---
suite [11139,15873]
suite [11139,15873]
===
match
---
name: cluster_context [16283,16298]
name: cluster_context [16283,16298]
===
match
---
simple_stmt [14847,15073]
simple_stmt [14847,15073]
===
match
---
expr_stmt [20138,20207]
expr_stmt [20138,20207]
===
match
---
operator: = [10312,10313]
operator: = [10312,10313]
===
match
---
trailer [9318,9327]
trailer [9318,9327]
===
match
---
trailer [1506,1512]
trailer [1506,1512]
===
match
---
operator: = [20912,20913]
operator: = [20912,20913]
===
match
---
expr_stmt [6758,6790]
expr_stmt [6758,6790]
===
match
---
name: addCleanup [1923,1933]
name: addCleanup [1923,1933]
===
match
---
operator: = [2534,2535]
operator: = [2534,2535]
===
match
---
trailer [8603,8998]
trailer [8603,8998]
===
match
---
atom_expr [10493,10532]
atom_expr [10493,10532]
===
match
---
name: task_instance [2096,2109]
name: task_instance [2096,2109]
===
match
---
operator: , [12580,12581]
operator: , [12580,12581]
===
match
---
import_from [986,1038]
import_from [986,1038]
===
match
---
name: name_base [14815,14824]
name: name_base [14815,14824]
===
match
---
name: assert_called_once_with [3516,3539]
name: assert_called_once_with [3516,3539]
===
match
---
trailer [13121,13125]
trailer [13121,13125]
===
match
---
argument [10332,10357]
argument [10332,10357]
===
match
---
string: "bar" [7224,7229]
string: "bar" [7224,7229]
===
match
---
argument [14971,14985]
argument [14971,14985]
===
match
---
dictorsetmaker [5888,5900]
dictorsetmaker [5888,5900]
===
match
---
name: self [3360,3364]
name: self [3360,3364]
===
match
---
operator: = [5196,5197]
operator: = [5196,5197]
===
match
---
operator: , [17194,17195]
operator: , [17194,17195]
===
match
---
name: V1Pod [8598,8603]
name: V1Pod [8598,8603]
===
match
---
string: "foo" [5359,5364]
string: "foo" [5359,5364]
===
match
---
atom_expr [23031,23053]
atom_expr [23031,23053]
===
match
---
argument [20323,20343]
argument [20323,20343]
===
match
---
operator: = [14939,14940]
operator: = [14939,14940]
===
match
---
trailer [10560,10565]
trailer [10560,10565]
===
match
---
param [7008,7023]
param [7008,7023]
===
match
---
name: client_mock [16932,16943]
name: client_mock [16932,16943]
===
match
---
atom_expr [4247,4265]
atom_expr [4247,4265]
===
match
---
name: k [18160,18161]
name: k [18160,18161]
===
match
---
string: 'pod_name' [23677,23687]
string: 'pod_name' [23677,23687]
===
match
---
arglist [22145,22173]
arglist [22145,22173]
===
match
---
operator: , [3004,3005]
operator: , [3004,3005]
===
match
---
atom_expr [1918,1958]
atom_expr [1918,1958]
===
match
---
operator: { [13762,13763]
operator: { [13762,13763]
===
match
---
name: in_cluster [23372,23382]
name: in_cluster [23372,23382]
===
match
---
trailer [9507,9512]
trailer [9507,9512]
===
match
---
trailer [10100,10368]
trailer [10100,10368]
===
match
---
trailer [23652,23688]
trailer [23652,23688]
===
match
---
testlist_comp [5101,5114]
testlist_comp [5101,5114]
===
match
---
parameters [23163,23169]
parameters [23163,23169]
===
match
---
operator: , [8481,8482]
operator: , [8481,8482]
===
match
---
name: namespace [23888,23897]
name: namespace [23888,23897]
===
match
---
trailer [5303,5306]
trailer [5303,5306]
===
match
---
name: self [16927,16931]
name: self [16927,16931]
===
match
---
string: "test_push_xcom_pod_info" [23565,23590]
string: "test_push_xcom_pod_info" [23565,23590]
===
match
---
atom [14170,14511]
atom [14170,14511]
===
match
---
name: cluster_context [3583,3598]
name: cluster_context [3583,3598]
===
match
---
import_from [801,840]
import_from [801,840]
===
match
---
atom_expr [12478,12595]
atom_expr [12478,12595]
===
match
---
string: "name" [22689,22695]
string: "name" [22689,22695]
===
match
---
name: exceptions [951,961]
name: exceptions [951,961]
===
match
---
suite [2055,2448]
suite [2055,2448]
===
match
---
argument [16027,16047]
argument [16027,16047]
===
match
---
operator: , [6627,6628]
operator: , [6627,6628]
===
match
---
name: k [7598,7599]
name: k [7598,7599]
===
match
---
operator: , [2359,2360]
operator: , [2359,2360]
===
match
---
name: containers [9393,9403]
name: containers [9393,9403]
===
match
---
name: name [23820,23824]
name: name [23820,23824]
===
match
---
expr_stmt [3360,3414]
expr_stmt [3360,3414]
===
match
---
string: "foo" [7217,7222]
string: "foo" [7217,7222]
===
match
---
name: mock [5542,5546]
name: mock [5542,5546]
===
match
---
argument [18266,18286]
argument [18266,18286]
===
match
---
operator: , [2392,2393]
operator: , [2392,2393]
===
match
---
name: mock [13073,13077]
name: mock [13073,13077]
===
match
---
operator: = [1728,1729]
operator: = [1728,1729]
===
match
---
argument [4002,4016]
argument [4002,4016]
===
match
---
name: spec [6207,6211]
name: spec [6207,6211]
===
match
---
name: ctx [16658,16661]
name: ctx [16658,16661]
===
match
---
atom_expr [19062,19298]
atom_expr [19062,19298]
===
match
---
trailer [17561,17569]
trailer [17561,17569]
===
match
---
comparison [4194,4231]
comparison [4194,4231]
===
match
---
simple_stmt [22450,22902]
simple_stmt [22450,22902]
===
match
---
trailer [1841,1854]
trailer [1841,1854]
===
match
---
operator: , [13081,13082]
operator: , [13081,13082]
===
match
---
simple_stmt [20666,20719]
simple_stmt [20666,20719]
===
match
---
string: "preferredDuringSchedulingIgnoredDuringExecution" [17801,17850]
string: "preferredDuringSchedulingIgnoredDuringExecution" [17801,17850]
===
match
---
name: k [6161,6162]
name: k [6161,6162]
===
match
---
argument [6558,6569]
argument [6558,6569]
===
match
---
simple_stmt [2064,2088]
simple_stmt [2064,2088]
===
match
---
atom_expr [15209,15248]
atom_expr [15209,15248]
===
match
---
simple_stmt [9308,9369]
simple_stmt [9308,9369]
===
match
---
name: kubernetes [887,897]
name: kubernetes [887,897]
===
match
---
number: 0 [13377,13378]
number: 0 [13377,13378]
===
match
---
name: ANY [13122,13125]
name: ANY [13122,13125]
===
match
---
name: k8s [18809,18812]
name: k8s [18809,18812]
===
match
---
trailer [16956,16976]
trailer [16956,16976]
===
match
---
trailer [18626,18653]
trailer [18626,18653]
===
match
---
trailer [16704,16707]
trailer [16704,16707]
===
match
---
trailer [7493,7509]
trailer [7493,7509]
===
match
---
simple_stmt [19889,19942]
simple_stmt [19889,19942]
===
match
---
trailer [3539,3654]
trailer [3539,3654]
===
match
---
string: "test" [7738,7744]
string: "test" [7738,7744]
===
match
---
name: monitor_patch [1939,1952]
name: monitor_patch [1939,1952]
===
match
---
operator: , [22627,22628]
operator: , [22627,22628]
===
match
---
arglist [23488,23528]
arglist [23488,23528]
===
match
---
name: k [5705,5706]
name: k [5705,5706]
===
match
---
name: self [6333,6337]
name: self [6333,6337]
===
match
---
trailer [2542,2550]
trailer [2542,2550]
===
match
---
trailer [23819,23824]
trailer [23819,23824]
===
match
---
trailer [9526,9534]
trailer [9526,9534]
===
match
---
operator: } [16150,16151]
operator: } [16150,16151]
===
match
---
trailer [3452,3455]
trailer [3452,3455]
===
match
---
argument [20581,20604]
argument [20581,20604]
===
match
---
operator: , [3907,3908]
operator: , [3907,3908]
===
match
---
atom [22573,22588]
atom [22573,22588]
===
match
---
simple_stmt [18790,19365]
simple_stmt [18790,19365]
===
match
---
name: pod [18565,18568]
name: pod [18565,18568]
===
match
---
argument [18456,18474]
argument [18456,18474]
===
match
---
name: AirflowException [8224,8240]
name: AirflowException [8224,8240]
===
match
---
assert_stmt [14662,14708]
assert_stmt [14662,14708]
===
match
---
operator: , [4153,4154]
operator: , [4153,4154]
===
match
---
name: sanitized_pod [20803,20816]
name: sanitized_pod [20803,20816]
===
match
---
string: "airflow_version" [11022,11039]
string: "airflow_version" [11022,11039]
===
match
---
atom_expr [18704,18718]
atom_expr [18704,18718]
===
match
---
name: client_mock [3504,3515]
name: client_mock [3504,3515]
===
match
---
simple_stmt [4098,4179]
simple_stmt [4098,4179]
===
match
---
name: task_instance [2379,2392]
name: task_instance [2379,2392]
===
match
---
string: "echo 10" [17227,17236]
string: "echo 10" [17227,17236]
===
match
---
operator: , [15768,15769]
operator: , [15768,15769]
===
match
---
argument [14922,14953]
argument [14922,14953]
===
match
---
operator: , [16013,16014]
operator: , [16013,16014]
===
match
---
name: V1Affinity [18708,18718]
name: V1Affinity [18708,18718]
===
match
---
string: 'pod_anti_affinity' [14608,14627]
string: 'pod_anti_affinity' [14608,14627]
===
match
---
name: ANY [13078,13081]
name: ANY [13078,13081]
===
match
---
trailer [18707,18718]
trailer [18707,18718]
===
match
---
operator: = [7215,7216]
operator: = [7215,7216]
===
match
---
atom [13625,14022]
atom [13625,14022]
===
match
---
comparison [22190,22244]
comparison [22190,22244]
===
match
---
string: "dag_id" [5385,5393]
string: "dag_id" [5385,5393]
===
match
---
operator: , [5590,5591]
operator: , [5590,5591]
===
match
---
arglist [19907,19940]
arglist [19907,19940]
===
match
---
atom [3036,3047]
atom [3036,3047]
===
match
---
name: return_value [16403,16415]
name: return_value [16403,16415]
===
match
---
operator: = [17124,17125]
operator: = [17124,17125]
===
match
---
name: cmds [23285,23289]
name: cmds [23285,23289]
===
match
---
atom [14293,14366]
atom [14293,14366]
===
match
---
expr_stmt [23538,23620]
expr_stmt [23538,23620]
===
match
---
name: k [15104,15105]
name: k [15104,15105]
===
match
---
trailer [14672,14677]
trailer [14672,14677]
===
match
---
string: "test" [17726,17732]
string: "test" [17726,17732]
===
match
---
name: spec [20749,20753]
name: spec [20749,20753]
===
match
---
operator: , [10977,10978]
operator: , [10977,10978]
===
match
---
simple_stmt [21553,21604]
simple_stmt [21553,21604]
===
match
---
atom_expr [10548,10565]
atom_expr [10548,10565]
===
match
---
string: "operator" [18022,18032]
string: "operator" [18022,18032]
===
match
---
operator: = [23444,23445]
operator: = [23444,23445]
===
match
---
atom_expr [1783,1809]
atom_expr [1783,1809]
===
match
---
argument [22815,22840]
argument [22815,22840]
===
match
---
string: "bar" [18350,18355]
string: "bar" [18350,18355]
===
match
---
operator: } [22665,22666]
operator: } [22665,22666]
===
match
---
expr_stmt [4872,4893]
expr_stmt [4872,4893]
===
match
---
name: pod [13357,13360]
name: pod [13357,13360]
===
match
---
name: k [6348,6349]
name: k [6348,6349]
===
match
---
atom_expr [4514,4863]
atom_expr [4514,4863]
===
match
---
operator: = [10152,10153]
operator: = [10152,10153]
===
match
---
string: "affinity" [19979,19989]
string: "affinity" [19979,19989]
===
match
---
simple_stmt [8120,8158]
simple_stmt [8120,8158]
===
match
---
expr_stmt [7754,8014]
expr_stmt [7754,8014]
===
match
---
operator: = [5947,5948]
operator: = [5947,5948]
===
match
---
name: env_from [4835,4843]
name: env_from [4835,4843]
===
match
---
operator: { [21795,21796]
operator: { [21795,21796]
===
match
---
operator: = [5168,5169]
operator: = [5168,5169]
===
match
---
name: pytest [8210,8216]
name: pytest [8210,8216]
===
match
---
trailer [9685,9692]
trailer [9685,9692]
===
match
---
name: namespace [7073,7082]
name: namespace [7073,7082]
===
match
---
atom_expr [15318,15346]
atom_expr [15318,15346]
===
match
---
expr_stmt [17449,17509]
expr_stmt [17449,17509]
===
match
---
name: arguments [19514,19523]
name: arguments [19514,19523]
===
match
---
name: KubernetesPodOperator [7758,7779]
name: KubernetesPodOperator [7758,7779]
===
match
---
not_test [17603,17663]
not_test [17603,17663]
===
match
---
funcdef [17669,20003]
funcdef [17669,20003]
===
match
---
argument [4582,4602]
argument [4582,4602]
===
match
---
name: name [15222,15226]
name: name [15222,15226]
===
match
---
trailer [17453,17466]
trailer [17453,17466]
===
match
---
trailer [7529,7536]
trailer [7529,7536]
===
match
---
operator: , [5233,5234]
operator: , [5233,5234]
===
match
---
operator: = [19523,19524]
operator: = [19523,19524]
===
match
---
name: self [17607,17611]
name: self [17607,17611]
===
match
---
argument [3026,3047]
argument [3026,3047]
===
match
---
simple_stmt [2662,2701]
simple_stmt [2662,2701]
===
match
---
number: 1 [1251,1252]
number: 1 [1251,1252]
===
match
---
simple_stmt [801,841]
simple_stmt [801,841]
===
match
---
simple_stmt [8583,8999]
simple_stmt [8583,8999]
===
match
---
name: tolerations [21498,21509]
name: tolerations [21498,21509]
===
match
---
trailer [21408,21420]
trailer [21408,21420]
===
match
---
trailer [16689,16704]
trailer [16689,16704]
===
match
---
simple_stmt [2886,3283]
simple_stmt [2886,3283]
===
match
---
operator: , [5954,5955]
operator: , [5954,5955]
===
match
---
parameters [1327,1333]
parameters [1327,1333]
===
match
---
atom [3324,3351]
atom [3324,3351]
===
match
---
name: do_xcom_push [22779,22791]
name: do_xcom_push [22779,22791]
===
match
---
funcdef [6292,6859]
funcdef [6292,6859]
===
match
---
string: "hello" [15598,15605]
string: "hello" [15598,15605]
===
match
---
trailer [16976,16983]
trailer [16976,16983]
===
match
---
name: self [23446,23450]
name: self [23446,23450]
===
match
---
trailer [5295,5303]
trailer [5295,5303]
===
match
---
argument [23746,23765]
argument [23746,23765]
===
match
---
string: "dag_id" [10884,10892]
string: "dag_id" [10884,10892]
===
match
---
string: "task" [10122,10128]
string: "task" [10122,10128]
===
match
---
argument [4803,4821]
argument [4803,4821]
===
match
---
name: State [3325,3330]
name: State [3325,3330]
===
match
---
argument [19480,19500]
argument [19480,19500]
===
match
---
trailer [17656,17663]
trailer [17656,17663]
===
match
---
name: configmap_name [4469,4483]
name: configmap_name [4469,4483]
===
match
---
atom_expr [12829,12848]
atom_expr [12829,12848]
===
match
---
trailer [15809,15813]
trailer [15809,15813]
===
match
---
name: context [16675,16682]
name: context [16675,16682]
===
match
---
operator: = [6048,6049]
operator: = [6048,6049]
===
match
---
operator: , [7195,7196]
operator: , [7195,7196]
===
match
---
operator: = [17384,17385]
operator: = [17384,17385]
===
match
---
name: task_id [9047,9054]
name: task_id [9047,9054]
===
match
---
expr_stmt [2886,3282]
expr_stmt [2886,3282]
===
match
---
string: 'foo' [13821,13826]
string: 'foo' [13821,13826]
===
match
---
string: "key" [20088,20093]
string: "key" [20088,20093]
===
match
---
operator: = [4364,4365]
operator: = [4364,4365]
===
match
---
name: spec [10598,10602]
name: spec [10598,10602]
===
match
---
operator: = [3035,3036]
operator: = [3035,3036]
===
match
---
operator: = [23414,23415]
operator: = [23414,23415]
===
match
---
trailer [21403,21408]
trailer [21403,21408]
===
match
---
atom_expr [1818,1834]
atom_expr [1818,1834]
===
match
---
string: "default" [6126,6135]
string: "default" [6126,6135]
===
match
---
name: cmds [20323,20327]
name: cmds [20323,20327]
===
match
---
operator: = [4512,4513]
operator: = [4512,4513]
===
match
---
simple_stmt [17596,17664]
simple_stmt [17596,17664]
===
match
---
atom_expr [17607,17663]
atom_expr [17607,17663]
===
match
---
string: "-cx" [5825,5830]
string: "-cx" [5825,5830]
===
match
---
simple_stmt [23833,23898]
simple_stmt [23833,23898]
===
match
---
trailer [18653,18658]
trailer [18653,18658]
===
match
---
simple_stmt [18728,18781]
simple_stmt [18728,18781]
===
match
---
arglist [1239,1258]
arglist [1239,1258]
===
match
---
testlist_comp [3805,3818]
testlist_comp [3805,3818]
===
match
---
operator: = [19061,19062]
operator: = [19061,19062]
===
match
---
string: "task" [21107,21113]
string: "task" [21107,21113]
===
match
---
name: DagRun [23551,23557]
name: DagRun [23551,23557]
===
match
---
operator: , [3819,3820]
operator: , [3819,3820]
===
match
---
testlist_comp [2998,3011]
testlist_comp [2998,3011]
===
match
---
string: "something" [13392,13403]
string: "something" [13392,13403]
===
match
---
atom [7216,7230]
atom [7216,7230]
===
match
---
return_stmt [2662,2700]
return_stmt [2662,2700]
===
match
---
suite [17705,20003]
suite [17705,20003]
===
match
---
expr_stmt [3423,3455]
expr_stmt [3423,3455]
===
match
---
trailer [10387,10395]
trailer [10387,10395]
===
match
---
operator: { [16137,16138]
operator: { [16137,16138]
===
match
---
operator: , [22353,22354]
operator: , [22353,22354]
===
match
---
argument [17342,17358]
argument [17342,17358]
===
match
---
string: "nodeSelector" [23098,23112]
string: "nodeSelector" [23098,23112]
===
match
---
name: containers [9513,9523]
name: containers [9513,9523]
===
match
---
dictorsetmaker [2279,2437]
dictorsetmaker [2279,2437]
===
match
---
simple_stmt [1206,1260]
simple_stmt [1206,1260]
===
match
---
assert_stmt [16916,16983]
assert_stmt [16916,16983]
===
match
---
argument [17404,17429]
argument [17404,17429]
===
match
---
operator: { [13669,13670]
operator: { [13669,13670]
===
match
---
operator: , [4636,4637]
operator: , [4636,4637]
===
match
---
operator: = [19220,19221]
operator: = [19220,19221]
===
match
---
name: V1NodeSelectorRequirement [19170,19195]
name: V1NodeSelectorRequirement [19170,19195]
===
match
---
name: setUp [1322,1327]
name: setUp [1322,1327]
===
match
---
trailer [23557,23620]
trailer [23557,23620]
===
match
---
operator: , [7152,7153]
operator: , [7152,7153]
===
match
---
comparison [15268,15298]
comparison [15268,15298]
===
match
---
name: image [9407,9412]
name: image [9407,9412]
===
match
---
operator: = [9222,9223]
operator: = [9222,9223]
===
match
---
string: "bash" [21725,21731]
string: "bash" [21725,21731]
===
match
---
name: k8s_api_affinity [18790,18806]
name: k8s_api_affinity [18790,18806]
===
match
---
operator: = [7475,7476]
operator: = [7475,7476]
===
match
---
string: "ssd" [19235,19240]
string: "ssd" [19235,19240]
===
match
---
argument [21719,21739]
argument [21719,21739]
===
match
---
name: node_selector [23117,23130]
name: node_selector [23117,23130]
===
match
---
name: spec [13223,13227]
name: spec [13223,13227]
===
match
---
operator: = [8027,8028]
operator: = [8027,8028]
===
match
---
operator: = [17078,17079]
operator: = [17078,17079]
===
match
---
name: read_namespaced_pod_mock [16466,16490]
name: read_namespaced_pod_mock [16466,16490]
===
match
---
trailer [2636,2653]
trailer [2636,2653]
===
match
---
name: context [2645,2652]
name: context [2645,2652]
===
match
---
trailer [1854,1860]
trailer [1854,1860]
===
match
---
atom [4403,4486]
atom [4403,4486]
===
match
---
string: 'weight' [13984,13992]
string: 'weight' [13984,13992]
===
match
---
trailer [3437,3452]
trailer [3437,3452]
===
match
---
name: TaskInstance [1026,1038]
name: TaskInstance [1026,1038]
===
match
---
expr_stmt [22066,22118]
expr_stmt [22066,22118]
===
match
---
operator: , [19298,19299]
operator: , [19298,19299]
===
match
---
name: failed_pod_status [16591,16608]
name: failed_pod_status [16591,16608]
===
match
---
string: "spec" [23090,23096]
string: "spec" [23090,23096]
===
match
---
operator: = [17153,17154]
operator: = [17153,17154]
===
match
---
atom_expr [15091,15106]
atom_expr [15091,15106]
===
match
---
string: "default" [5038,5047]
string: "default" [5038,5047]
===
match
---
operator: = [3981,3982]
operator: = [3981,3982]
===
match
---
operator: , [21113,21114]
operator: , [21113,21114]
===
match
---
trailer [12626,12629]
trailer [12626,12629]
===
match
---
string: "bar" [9717,9722]
string: "bar" [9717,9722]
===
match
---
name: models [999,1005]
name: models [999,1005]
===
match
---
argument [22530,22550]
argument [22530,22550]
===
match
---
operator: == [13183,13185]
operator: == [13183,13185]
===
match
---
argument [19196,19210]
argument [19196,19210]
===
match
---
atom_expr [3433,3455]
atom_expr [3433,3455]
===
match
---
comparison [6806,6858]
comparison [6806,6858]
===
match
---
simple_stmt [13417,13463]
simple_stmt [13417,13463]
===
match
---
name: cluster_context [6110,6125]
name: cluster_context [6110,6125]
===
match
---
argument [19741,19766]
argument [19741,19766]
===
match
---
operator: = [3770,3771]
operator: = [3770,3771]
===
match
---
operator: = [23711,23712]
operator: = [23711,23712]
===
match
---
trailer [2507,2520]
trailer [2507,2520]
===
match
---
name: isinstance [19896,19906]
name: isinstance [19896,19906]
===
match
---
string: "default" [6729,6738]
string: "default" [6729,6738]
===
match
---
name: DEFAULT_DATE [2236,2248]
name: DEFAULT_DATE [2236,2248]
===
match
---
operator: } [14021,14022]
operator: } [14021,14022]
===
match
---
operator: , [3165,3166]
operator: , [3165,3166]
===
match
---
trailer [13379,13387]
trailer [13379,13387]
===
match
---
trailer [22315,22321]
trailer [22315,22321]
===
match
---
name: name [8828,8832]
name: name [8828,8832]
===
match
---
name: KubernetesPodOperator [23183,23204]
name: KubernetesPodOperator [23183,23204]
===
match
---
operator: , [4789,4790]
operator: , [4789,4790]
===
match
---
trailer [20070,20083]
trailer [20070,20083]
===
match
---
name: flush [12453,12458]
name: flush [12453,12458]
===
match
---
string: "bar" [5144,5149]
string: "bar" [5144,5149]
===
match
---
operator: != [10566,10568]
operator: != [10566,10568]
===
match
---
operator: , [19766,19767]
operator: , [19766,19767]
===
match
---
name: metadata [9677,9685]
name: metadata [9677,9685]
===
match
---
testlist_comp [23291,23304]
testlist_comp [23291,23304]
===
match
---
string: "task" [17322,17328]
string: "task" [17322,17328]
===
match
---
trailer [18812,18823]
trailer [18812,18823]
===
match
---
operator: , [4046,4047]
operator: , [4046,4047]
===
match
---
name: cncf [1062,1066]
name: cncf [1062,1066]
===
match
---
operator: , [5447,5448]
operator: , [5447,5448]
===
match
---
trailer [19978,19990]
trailer [19978,19990]
===
match
---
simple_stmt [2572,2612]
simple_stmt [2572,2612]
===
match
---
name: pod_name [23782,23790]
name: pod_name [23782,23790]
===
match
---
operator: , [3785,3786]
operator: , [3785,3786]
===
match
---
string: "disktype" [18010,18020]
string: "disktype" [18010,18020]
===
match
---
trailer [10602,10613]
trailer [10602,10613]
===
match
---
operator: = [19451,19452]
operator: = [19451,19452]
===
match
---
name: tolerations [20843,20854]
name: tolerations [20843,20854]
===
match
---
simple_stmt [15927,15946]
simple_stmt [15927,15946]
===
match
---
operator: = [10077,10078]
operator: = [10077,10078]
===
match
---
arglist [17115,17430]
arglist [17115,17430]
===
match
---
atom [20367,20378]
atom [20367,20378]
===
match
---
name: task_id [10114,10121]
name: task_id [10114,10121]
===
match
---
operator: { [12852,12853]
operator: { [12852,12853]
===
match
---
atom [5136,5150]
atom [5136,5150]
===
match
---
name: name [6558,6562]
name: name [6558,6562]
===
match
---
trailer [19910,19915]
trailer [19910,19915]
===
match
---
simple_stmt [20044,20129]
simple_stmt [20044,20129]
===
match
---
argument [20427,20438]
argument [20427,20438]
===
match
---
name: name_base [17048,17057]
name: name_base [17048,17057]
===
match
---
trailer [12458,12460]
trailer [12458,12460]
===
match
---
simple_stmt [2620,2654]
simple_stmt [2620,2654]
===
match
---
argument [19640,19656]
argument [19640,19656]
===
match
---
string: "test" [7249,7255]
string: "test" [7249,7255]
===
match
---
operator: != [8145,8147]
operator: != [8145,8147]
===
match
---
atom_expr [13160,13182]
atom_expr [13160,13182]
===
match
---
operator: , [10128,10129]
operator: , [10128,10129]
===
match
---
atom_expr [16419,16431]
atom_expr [16419,16431]
===
match
---
operator: , [4332,4333]
operator: , [4332,4333]
===
match
---
atom_expr [1934,1957]
atom_expr [1934,1957]
===
match
---
simple_stmt [15261,15299]
simple_stmt [15261,15299]
===
match
---
operator: , [18038,18039]
operator: , [18038,18039]
===
match
---
string: "ubuntu:16.04" [5067,5081]
string: "ubuntu:16.04" [5067,5081]
===
match
---
simple_stmt [6758,6791]
simple_stmt [6758,6791]
===
match
---
expr_stmt [12608,12629]
expr_stmt [12608,12629]
===
match
---
argument [21127,21143]
argument [21127,21143]
===
match
---
assert_stmt [19889,19941]
assert_stmt [19889,19941]
===
match
---
operator: = [21855,21856]
operator: = [21855,21856]
===
match
---
string: "default" [20266,20275]
string: "default" [20266,20275]
===
match
---
operator: = [5854,5855]
operator: = [5854,5855]
===
match
---
name: self [2582,2586]
name: self [2582,2586]
===
match
---
string: 'pod_namespace' [23750,23765]
string: 'pod_namespace' [23750,23765]
===
match
---
name: self [1730,1734]
name: self [1730,1734]
===
match
---
name: datetime [1230,1238]
name: datetime [1230,1238]
===
match
---
name: V1Toleration [20774,20786]
name: V1Toleration [20774,20786]
===
match
---
atom [18310,18321]
atom [18310,18321]
===
match
---
name: self [1623,1627]
name: self [1623,1627]
===
match
---
expr_stmt [17714,17732]
expr_stmt [17714,17732]
===
match
---
operator: , [21862,21863]
operator: , [21862,21863]
===
match
---
operator: , [16047,16048]
operator: , [16047,16048]
===
match
---
name: k [20631,20632]
name: k [20631,20632]
===
match
---
simple_stmt [16385,16458]
simple_stmt [16385,16458]
===
match
---
atom [5855,5866]
atom [5855,5866]
===
match
---
name: name [3977,3981]
name: name [3977,3981]
===
match
---
name: k [19793,19794]
name: k [19793,19794]
===
match
---
name: do_xcom_push [8463,8475]
name: do_xcom_push [8463,8475]
===
match
---
operator: , [3988,3989]
operator: , [3988,3989]
===
match
---
string: "disktype" [19200,19210]
string: "disktype" [19200,19210]
===
match
---
argument [3622,3643]
argument [3622,3643]
===
match
---
simple_stmt [2258,2448]
simple_stmt [2258,2448]
===
match
---
with_stmt [16618,16747]
with_stmt [16618,16747]
===
match
---
trailer [20713,20718]
trailer [20713,20718]
===
match
---
argument [8617,8704]
argument [8617,8704]
===
match
---
trailer [4099,4122]
trailer [4099,4122]
===
match
---
string: "ubuntu:16.04" [7832,7846]
string: "ubuntu:16.04" [7832,7846]
===
match
---
operator: , [20187,20188]
operator: , [20187,20188]
===
match
---
string: "bar" [17266,17271]
string: "bar" [17266,17271]
===
match
---
atom [4131,4177]
atom [4131,4177]
===
match
---
name: cluster_context [18488,18503]
name: cluster_context [18488,18503]
===
match
---
atom [21724,21739]
atom [21724,21739]
===
match
---
name: pod [13285,13288]
name: pod [13285,13288]
===
match
---
trailer [15271,15280]
trailer [15271,15280]
===
match
---
name: pod [18654,18657]
name: pod [18654,18657]
===
match
---
string: "True" [5441,5447]
string: "True" [5441,5447]
===
match
---
atom_expr [12614,12629]
atom_expr [12614,12629]
===
match
---
atom [15550,15872]
atom [15550,15872]
===
match
---
name: context [7623,7630]
name: context [7623,7630]
===
match
---
name: AirflowException [969,985]
name: AirflowException [969,985]
===
match
---
assert_stmt [22127,22174]
assert_stmt [22127,22174]
===
match
---
simple_stmt [2503,2564]
simple_stmt [2503,2564]
===
match
---
name: task_ids [23726,23734]
name: task_ids [23726,23734]
===
match
---
atom_expr [4993,5276]
atom_expr [4993,5276]
===
match
---
string: "foo" [12870,12875]
string: "foo" [12870,12875]
===
match
---
operator: = [7307,7308]
operator: = [7307,7308]
===
match
---
operator: , [13001,13002]
operator: , [13001,13002]
===
match
---
atom_expr [3360,3409]
atom_expr [3360,3409]
===
match
---
trailer [21428,21441]
trailer [21428,21441]
===
match
---
expr_stmt [23179,23431]
expr_stmt [23179,23431]
===
match
---
parameters [4318,4339]
parameters [4318,4339]
===
match
---
name: call_args [2685,2694]
name: call_args [2685,2694]
===
match
---
operator: = [7993,7994]
operator: = [7993,7994]
===
match
---
argument [3732,3751]
argument [3732,3751]
===
match
---
atom_expr [3291,3321]
atom_expr [3291,3321]
===
match
---
name: airflow [991,998]
name: airflow [991,998]
===
match
---
operator: == [13326,13328]
operator: == [13326,13328]
===
match
---
atom_expr [23475,23529]
atom_expr [23475,23529]
===
match
---
trailer [21287,21310]
trailer [21287,21310]
===
match
---
operator: , [10229,10230]
operator: , [10229,10230]
===
match
---
argument [23218,23237]
argument [23218,23237]
===
match
---
atom_expr [9416,9449]
atom_expr [9416,9449]
===
match
---
name: pod [9218,9221]
name: pod [9218,9221]
===
match
---
suite [15918,16984]
suite [15918,16984]
===
match
---
name: self [3499,3503]
name: self [3499,3503]
===
match
---
atom [16066,16081]
atom [16066,16081]
===
match
---
operator: = [7756,7757]
operator: = [7756,7757]
===
match
---
trailer [9228,9236]
trailer [9228,9236]
===
match
---
name: KubernetesPodOperator [4514,4535]
name: KubernetesPodOperator [4514,4535]
===
match
---
testlist_comp [2537,2562]
testlist_comp [2537,2562]
===
match
---
name: called [7671,7677]
name: called [7671,7677]
===
match
---
name: pod [14669,14672]
name: pod [14669,14672]
===
match
---
string: "-cx" [20984,20989]
string: "-cx" [20984,20989]
===
match
---
name: patch [1367,1372]
name: patch [1367,1372]
===
match
---
trailer [6814,6825]
trailer [6814,6825]
===
match
---
atom_expr [9224,9239]
atom_expr [9224,9239]
===
match
---
arglist [20256,20605]
arglist [20256,20605]
===
match
---
atom_expr [8594,8998]
atom_expr [8594,8998]
===
match
---
name: is_delete_operator_pod [7398,7420]
name: is_delete_operator_pod [7398,7420]
===
match
---
operator: , [3271,3272]
operator: , [3271,3272]
===
match
---
atom_expr [20067,20127]
atom_expr [20067,20127]
===
match
---
simple_stmt [1481,1615]
simple_stmt [1481,1615]
===
match
---
argument [18887,19339]
argument [18887,19339]
===
match
---
import_from [1039,1131]
import_from [1039,1131]
===
match
---
trailer [1653,1703]
trailer [1653,1703]
===
match
---
string: "foo" [17259,17264]
string: "foo" [17259,17264]
===
match
---
argument [8463,8481]
argument [8463,8481]
===
match
---
operator: , [6096,6097]
operator: , [6096,6097]
===
match
---
atom [18940,19339]
atom [18940,19339]
===
match
---
assert_stmt [15520,15872]
assert_stmt [15520,15872]
===
match
---
trailer [3330,3338]
trailer [3330,3338]
===
match
---
argument [16251,16269]
argument [16251,16269]
===
match
---
return_stmt [2757,2807]
return_stmt [2757,2807]
===
match
---
trailer [1647,1653]
trailer [1647,1653]
===
match
---
operator: = [3100,3101]
operator: = [3100,3101]
===
match
---
argument [17314,17328]
argument [17314,17328]
===
match
---
trailer [3881,3890]
trailer [3881,3890]
===
match
---
assert_stmt [6196,6286]
assert_stmt [6196,6286]
===
match
---
trailer [1987,2000]
trailer [1987,2000]
===
match
---
atom_expr [12567,12580]
atom_expr [12567,12580]
===
match
---
name: context [2637,2644]
name: context [2637,2644]
===
match
---
operator: = [5037,5038]
operator: = [5037,5038]
===
match
---
atom [13820,13834]
atom [13820,13834]
===
match
---
name: monitor_mock [7450,7462]
name: monitor_mock [7450,7462]
===
match
---
testlist_comp [16419,16456]
testlist_comp [16419,16456]
===
match
---
name: image [15350,15355]
name: image [15350,15355]
===
match
---
trailer [23458,23461]
trailer [23458,23461]
===
match
---
operator: , [7932,7933]
operator: , [7932,7933]
===
match
---
trailer [9468,9473]
trailer [9468,9473]
===
match
---
name: namespace [18199,18208]
name: namespace [18199,18208]
===
match
---
name: self [17699,17703]
name: self [17699,17703]
===
match
---
string: "key" [18003,18008]
string: "key" [18003,18008]
===
match
---
string: "default" [3262,3271]
string: "default" [3262,3271]
===
match
---
name: cluster_context [20542,20557]
name: cluster_context [20542,20557]
===
match
---
string: "ubuntu:16.04" [17154,17168]
string: "ubuntu:16.04" [17154,17168]
===
match
---
name: arguments [22606,22615]
name: arguments [22606,22615]
===
match
---
name: State [1199,1204]
name: State [1199,1204]
===
match
---
funcdef [15878,16984]
funcdef [15878,16984]
===
match
---
argument [7946,7964]
argument [7946,7964]
===
match
---
name: cluster_context [10204,10219]
name: cluster_context [10204,10219]
===
match
---
trailer [15980,16319]
trailer [15980,16319]
===
match
---
simple_stmt [22025,22058]
simple_stmt [22025,22058]
===
match
---
testlist_comp [16067,16080]
testlist_comp [16067,16080]
===
match
---
name: self [16685,16689]
name: self [16685,16689]
===
match
---
operator: = [9054,9055]
operator: = [9054,9055]
===
match
---
operator: } [3081,3082]
operator: } [3081,3082]
===
match
---
comparison [15527,15872]
comparison [15527,15872]
===
match
---
trailer [17636,17656]
trailer [17636,17656]
===
match
---
name: service_account_name [13433,13453]
name: service_account_name [13433,13453]
===
match
---
operator: = [19555,19556]
operator: = [19555,19556]
===
match
---
string: "default" [16004,16013]
string: "default" [16004,16013]
===
match
---
trailer [10551,10560]
trailer [10551,10560]
===
match
---
name: tolerations [20581,20592]
name: tolerations [20581,20592]
===
match
---
name: k [17549,17550]
name: k [17549,17550]
===
match
---
name: name_base [17291,17300]
name: name_base [17291,17300]
===
match
---
operator: = [3191,3192]
operator: = [3191,3192]
===
match
---
trailer [4917,4928]
trailer [4917,4928]
===
match
---
dotted_name [991,1005]
dotted_name [991,1005]
===
match
---
atom [13724,13869]
atom [13724,13869]
===
match
---
operator: = [22572,22573]
operator: = [22572,22573]
===
match
---
with_item [12352,12384]
with_item [12352,12384]
===
match
---
simple_stmt [16328,16377]
simple_stmt [16328,16377]
===
match
---
name: FAILED [16425,16431]
name: FAILED [16425,16431]
===
match
---
string: "task_id" [9812,9821]
string: "task_id" [9812,9821]
===
match
---
operator: = [18807,18808]
operator: = [18807,18808]
===
match
---
string: "bar" [4155,4160]
string: "bar" [4155,4160]
===
match
---
comparison [9315,9368]
comparison [9315,9368]
===
match
---
number: 0 [2695,2696]
number: 0 [2695,2696]
===
match
---
number: 0 [9441,9442]
number: 0 [9441,9442]
===
match
---
trailer [4407,4423]
trailer [4407,4423]
===
match
---
atom_expr [2070,2087]
atom_expr [2070,2087]
===
match
---
name: KubernetesPodOperator [15959,15980]
name: KubernetesPodOperator [15959,15980]
===
match
---
atom_expr [22031,22057]
atom_expr [22031,22057]
===
match
---
name: run_pod [2457,2464]
name: run_pod [2457,2464]
===
match
---
operator: { [4131,4132]
operator: { [4131,4132]
===
match
---
trailer [1716,1727]
trailer [1716,1727]
===
match
---
name: ApiClient [912,921]
name: ApiClient [912,921]
===
match
---
argument [10307,10318]
argument [10307,10318]
===
match
---
operator: = [6266,6267]
operator: = [6266,6267]
===
match
---
trailer [1933,1958]
trailer [1933,1958]
===
match
---
string: "default" [2935,2944]
string: "default" [2935,2944]
===
match
---
name: self [2503,2507]
name: self [2503,2507]
===
match
---
trailer [15340,15346]
trailer [15340,15346]
===
match
---
expr_stmt [4510,4863]
expr_stmt [4510,4863]
===
match
---
suite [2494,2701]
suite [2494,2701]
===
match
---
operator: = [6125,6126]
operator: = [6125,6126]
===
match
---
number: 1 [1245,1246]
number: 1 [1245,1246]
===
match
---
operator: = [1360,1361]
operator: = [1360,1361]
===
match
---
simple_stmt [12474,12596]
simple_stmt [12474,12596]
===
match
---
dictorsetmaker [20400,20412]
dictorsetmaker [20400,20412]
===
match
---
with_stmt [8205,8540]
with_stmt [8205,8540]
===
match
---
simple_stmt [16916,16984]
simple_stmt [16916,16984]
===
match
---
trailer [9327,9337]
trailer [9327,9337]
===
match
---
operator: { [13625,13626]
operator: { [13625,13626]
===
match
---
atom_expr [23183,23431]
atom_expr [23183,23431]
===
match
---
name: metadata [23879,23887]
name: metadata [23879,23887]
===
match
---
trailer [3364,3376]
trailer [3364,3376]
===
match
---
trailer [10613,10616]
trailer [10613,10616]
===
match
---
number: 2016 [1239,1243]
number: 2016 [1239,1243]
===
match
---
trailer [4122,4178]
trailer [4122,4178]
===
match
---
atom [13486,14648]
atom [13486,14648]
===
match
---
name: metadata [9260,9268]
name: metadata [9260,9268]
===
match
---
operator: , [19500,19501]
operator: , [19500,19501]
===
match
---
name: context [4123,4130]
name: context [4123,4130]
===
match
---
name: affinity [18527,18535]
name: affinity [18527,18535]
===
match
---
name: task_id [21848,21855]
name: task_id [21848,21855]
===
match
---
atom_expr [10594,10622]
atom_expr [10594,10622]
===
match
---
decorated [6864,7678]
decorated [6864,7678]
===
match
---
dictorsetmaker [21796,21808]
dictorsetmaker [21796,21808]
===
match
---
parameters [3677,3683]
parameters [3677,3683]
===
match
---
comparison [4909,4952]
comparison [4909,4952]
===
match
---
expr_stmt [4989,5276]
expr_stmt [4989,5276]
===
match
---
string: "spec" [18749,18755]
string: "spec" [18749,18755]
===
match
---
operator: , [5371,5372]
operator: , [5371,5372]
===
match
---
operator: , [2333,2334]
operator: , [2333,2334]
===
match
---
trailer [1347,1359]
trailer [1347,1359]
===
match
---
string: "-cx" [7154,7159]
string: "-cx" [7154,7159]
===
match
---
operator: , [16450,16451]
operator: , [16450,16451]
===
match
---
suite [2748,2808]
suite [2748,2808]
===
match
---
trailer [10510,10521]
trailer [10510,10521]
===
match
---
operator: = [18939,18940]
operator: = [18939,18940]
===
match
---
operator: , [17496,17497]
operator: , [17496,17497]
===
match
---
name: metadata [15213,15221]
name: metadata [15213,15221]
===
match
---
name: name_base [18375,18384]
name: name_base [18375,18384]
===
match
---
operator: , [3643,3644]
operator: , [3643,3644]
===
match
---
param [8190,8194]
param [8190,8194]
===
match
---
operator: , [21143,21144]
operator: , [21143,21144]
===
match
---
trailer [23663,23671]
trailer [23663,23671]
===
match
---
name: utils [1145,1150]
name: utils [1145,1150]
===
match
---
name: read_namespaced_pod [17637,17656]
name: read_namespaced_pod [17637,17656]
===
match
---
operator: , [10946,10947]
operator: , [10946,10947]
===
match
---
name: k8s_api_tolerations [21240,21259]
name: k8s_api_tolerations [21240,21259]
===
match
---
string: "echo 10" [4661,4670]
string: "echo 10" [4661,4670]
===
match
---
name: SUCCESS [2543,2550]
name: SUCCESS [2543,2550]
===
match
---
operator: = [20941,20942]
operator: = [20941,20942]
===
match
---
string: "bash" [20976,20982]
string: "bash" [20976,20982]
===
match
---
simple_stmt [2167,2250]
simple_stmt [2167,2250]
===
match
---
name: in_cluster [6611,6621]
name: in_cluster [6611,6621]
===
match
---
argument [19514,19535]
argument [19514,19535]
===
match
---
operator: = [8247,8248]
operator: = [8247,8248]
===
match
---
atom_expr [23807,23824]
atom_expr [23807,23824]
===
match
---
name: namespace [5028,5037]
name: namespace [5028,5037]
===
match
---
operator: = [15937,15938]
operator: = [15937,15938]
===
match
---
operator: , [12915,12916]
operator: , [12915,12916]
===
match
---
name: cluster_context [21938,21953]
name: cluster_context [21938,21953]
===
match
---
trailer [15095,15103]
trailer [15095,15103]
===
match
---
expr_stmt [23697,23766]
expr_stmt [23697,23766]
===
match
---
name: self [1837,1841]
name: self [1837,1841]
===
match
---
name: metadata [12654,12662]
name: metadata [12654,12662]
===
match
---
operator: , [3854,3855]
operator: , [3854,3855]
===
match
---
trailer [2601,2611]
trailer [2601,2611]
===
match
---
string: "default" [22831,22840]
string: "default" [22831,22840]
===
match
---
atom_expr [8787,8955]
atom_expr [8787,8955]
===
match
---
argument [20392,20413]
argument [20392,20413]
===
match
---
string: "foo" [21047,21052]
string: "foo" [21047,21052]
===
match
---
trailer [3718,4089]
trailer [3718,4089]
===
match
---
name: run_pod [15096,15103]
name: run_pod [15096,15103]
===
match
---
atom [12852,13140]
atom [12852,13140]
===
match
---
suite [12385,15873]
suite [12385,15873]
===
match
---
operator: = [6562,6563]
operator: = [6562,6563]
===
match
---
trailer [10496,10505]
trailer [10496,10505]
===
match
---
simple_stmt [4392,4487]
simple_stmt [4392,4487]
===
match
---
trailer [22972,22999]
trailer [22972,22999]
===
match
---
argument [4650,4671]
argument [4650,4671]
===
match
---
string: "bash" [18272,18278]
string: "bash" [18272,18278]
===
match
---
simple_stmt [986,1039]
simple_stmt [986,1039]
===
match
---
name: AirflowException [7477,7493]
name: AirflowException [7477,7493]
===
match
---
comparison [4247,4283]
comparison [4247,4283]
===
match
---
trailer [4890,4893]
trailer [4890,4893]
===
match
---
argument [21685,21705]
argument [21685,21705]
===
match
---
operator: { [17783,17784]
operator: { [17783,17784]
===
match
---
name: cmds [17182,17186]
name: cmds [17182,17186]
===
match
---
name: task_id [4745,4752]
name: task_id [4745,4752]
===
match
---
operator: , [6474,6475]
operator: , [6474,6475]
===
match
---
name: V1ConfigMapEnvSource [4443,4463]
name: V1ConfigMapEnvSource [4443,4463]
===
match
---
argument [4123,4177]
argument [4123,4177]
===
match
---
expr_stmt [10075,10368]
expr_stmt [10075,10368]
===
match
---
param [11133,11137]
param [11133,11137]
===
match
---
operator: , [11008,11009]
operator: , [11008,11009]
===
match
---
operator: = [9189,9190]
operator: = [9189,9190]
===
match
---
operator: , [10840,10841]
operator: , [10840,10841]
===
match
---
name: self [1871,1875]
name: self [1871,1875]
===
match
---
name: KubernetesPodOperator [5709,5730]
name: KubernetesPodOperator [5709,5730]
===
match
---
operator: , [7425,7426]
operator: , [7425,7426]
===
match
---
operator: , [23305,23306]
operator: , [23305,23306]
===
match
---
operator: , [23744,23745]
operator: , [23744,23745]
===
match
---
argument [6611,6627]
argument [6611,6627]
===
match
---
atom_expr [2537,2550]
atom_expr [2537,2550]
===
match
---
trailer [19169,19195]
trailer [19169,19195]
===
match
---
name: tpl_file [12567,12575]
name: tpl_file [12567,12575]
===
match
---
name: KubernetesPodOperator [8283,8304]
name: KubernetesPodOperator [8283,8304]
===
match
---
name: cluster_context [8499,8514]
name: cluster_context [8499,8514]
===
match
---
operator: , [16269,16270]
operator: , [16269,16270]
===
match
---
string: 'bar' [13828,13833]
string: 'bar' [13828,13833]
===
match
---
trailer [4928,4931]
trailer [4928,4931]
===
match
---
string: "dag_id" [9736,9744]
string: "dag_id" [9736,9744]
===
match
---
name: pod [10594,10597]
name: pod [10594,10597]
===
match
---
string: "-cx" [3006,3011]
string: "-cx" [3006,3011]
===
match
---
operator: , [13923,13924]
operator: , [13923,13924]
===
match
---
string: "foo" [3069,3074]
string: "foo" [3069,3074]
===
match
---
operator: = [9152,9153]
operator: = [9152,9153]
===
match
---
string: "dag" [10894,10899]
string: "dag" [10894,10899]
===
match
---
argument [4549,4568]
argument [4549,4568]
===
match
---
operator: } [18355,18356]
operator: } [18355,18356]
===
match
---
name: xcom_pull [23716,23725]
name: xcom_pull [23716,23725]
===
match
---
string: "airflow_version" [15786,15803]
string: "airflow_version" [15786,15803]
===
match
---
trailer [10521,10532]
trailer [10521,10532]
===
match
---
argument [21228,21259]
argument [21228,21259]
===
match
---
operator: = [17257,17258]
operator: = [17257,17258]
===
match
---
trailer [13360,13365]
trailer [13360,13365]
===
match
---
trailer [9294,9299]
trailer [9294,9299]
===
match
---
expr_stmt [3693,4089]
expr_stmt [3693,4089]
===
match
---
assert_stmt [18728,18780]
assert_stmt [18728,18780]
===
match
---
trailer [17488,17496]
trailer [17488,17496]
===
match
---
simple_stmt [16466,16543]
simple_stmt [16466,16543]
===
match
---
operator: , [3232,3233]
operator: , [3232,3233]
===
match
---
name: namespace [3732,3741]
name: namespace [3732,3741]
===
match
---
param [7711,7715]
param [7711,7715]
===
match
---
operator: } [18084,18085]
operator: } [18084,18085]
===
match
---
string: "world" [10349,10356]
string: "world" [10349,10356]
===
match
---
atom_expr [5542,5550]
atom_expr [5542,5550]
===
match
---
operator: , [4821,4822]
operator: , [4821,4822]
===
match
---
name: k8s_api_affinity [19750,19766]
name: k8s_api_affinity [19750,19766]
===
match
---
name: in_cluster [4030,4040]
name: in_cluster [4030,4040]
===
match
---
trailer [13427,13432]
trailer [13427,13432]
===
match
---
name: pod [20714,20717]
name: pod [20714,20717]
===
match
---
operator: , [15014,15015]
operator: , [15014,15015]
===
match
---
atom_expr [9256,9273]
atom_expr [9256,9273]
===
match
---
return_stmt [2258,2447]
return_stmt [2258,2447]
===
match
---
name: self [2669,2673]
name: self [2669,2673]
===
match
---
atom_expr [1343,1359]
atom_expr [1343,1359]
===
match
---
operator: , [16081,16082]
operator: , [16081,16082]
===
match
---
atom [5100,5115]
atom [5100,5115]
===
match
---
name: self [12614,12618]
name: self [12614,12618]
===
match
---
atom [4621,4636]
atom [4621,4636]
===
match
---
argument [23372,23388]
argument [23372,23388]
===
match
---
name: state [1186,1191]
name: state [1186,1191]
===
match
---
argument [5811,5831]
argument [5811,5831]
===
match
---
operator: , [14904,14905]
operator: , [14904,14905]
===
match
---
operator: , [21025,21026]
operator: , [21025,21026]
===
match
---
operator: , [21085,21086]
operator: , [21085,21086]
===
match
---
atom_expr [21458,21494]
atom_expr [21458,21494]
===
match
---
string: "task_id" [5461,5470]
string: "task_id" [5461,5470]
===
match
---
operator: , [21214,21215]
operator: , [21214,21215]
===
match
---
operator: , [5047,5048]
operator: , [5047,5048]
===
match
---
name: KubernetesPodOperator [7038,7059]
name: KubernetesPodOperator [7038,7059]
===
match
---
trailer [5325,5334]
trailer [5325,5334]
===
match
---
operator: = [23549,23550]
operator: = [23549,23550]
===
match
---
expr_stmt [1712,1754]
expr_stmt [1712,1754]
===
match
---
name: test_no_need_to_describe_pod_on_success [16993,17032]
name: test_no_need_to_describe_pod_on_success [16993,17032]
===
match
---
simple_stmt [22911,22944]
simple_stmt [22911,22944]
===
match
---
trailer [5546,5550]
trailer [5546,5550]
===
match
---
atom [18001,18059]
atom [18001,18059]
===
match
---
operator: , [15614,15615]
operator: , [15614,15615]
===
match
---
argument [16095,16116]
argument [16095,16116]
===
match
---
decorator [2012,2026]
decorator [2012,2026]
===
match
---
operator: == [10623,10625]
operator: == [10623,10625]
===
match
---
string: "nodeSelector" [22212,22226]
string: "nodeSelector" [22212,22226]
===
match
---
name: context [16738,16745]
name: context [16738,16745]
===
match
---
comparison [8127,8157]
comparison [8127,8157]
===
match
---
argument [3149,3165]
argument [3149,3165]
===
match
---
param [8568,8572]
param [8568,8572]
===
match
---
operator: = [5227,5228]
operator: = [5227,5228]
===
match
---
operator: { [4692,4693]
operator: { [4692,4693]
===
match
---
atom_expr [5291,5306]
atom_expr [5291,5306]
===
match
---
operator: , [22004,22005]
operator: , [22004,22005]
===
match
---
operator: , [13995,13996]
operator: , [13995,13996]
===
match
---
simple_stmt [1918,1959]
simple_stmt [1918,1959]
===
match
---
simple_stmt [23775,23825]
simple_stmt [23775,23825]
===
match
---
name: arguments [6488,6497]
name: arguments [6488,6497]
===
match
---
operator: , [5203,5204]
operator: , [5203,5204]
===
match
---
argument [17182,17202]
argument [17182,17202]
===
match
---
name: pod [13160,13163]
name: pod [13160,13163]
===
match
---
atom_expr [2503,2533]
atom_expr [2503,2533]
===
match
---
atom_expr [19926,19940]
atom_expr [19926,19940]
===
match
---
name: pod [9384,9387]
name: pod [9384,9387]
===
match
---
operator: , [21963,21964]
operator: , [21963,21964]
===
match
---
operator: , [5107,5108]
operator: , [5107,5108]
===
match
---
string: "world" [10059,10066]
string: "world" [10059,10066]
===
match
---
string: "task" [8405,8411]
string: "task" [8405,8411]
===
match
---
param [15912,15916]
param [15912,15916]
===
match
---
name: k [16836,16837]
name: k [16836,16837]
===
match
---
assert_stmt [12822,13140]
assert_stmt [12822,13140]
===
match
---
string: "True" [15692,15698]
string: "True" [15692,15698]
===
match
---
name: task [23488,23492]
name: task [23488,23492]
===
match
---
operator: , [16116,16117]
operator: , [16116,16117]
===
match
---
name: return_value [16510,16522]
name: return_value [16510,16522]
===
match
---
atom [5816,5831]
atom [5816,5831]
===
match
---
simple_stmt [14815,14835]
simple_stmt [14815,14835]
===
match
---
name: name [4261,4265]
name: name [4261,4265]
===
match
---
operator: = [4438,4439]
operator: = [4438,4439]
===
match
---
operator: = [4724,4725]
operator: = [4724,4725]
===
match
---
name: namespace [20903,20912]
name: namespace [20903,20912]
===
match
---
and_test [23840,23897]
and_test [23840,23897]
===
match
---
operator: , [13125,13126]
operator: , [13125,13126]
===
match
---
operator: , [7902,7903]
operator: , [7902,7903]
===
match
---
trailer [3890,3927]
trailer [3890,3927]
===
match
---
atom [17226,17237]
atom [17226,17237]
===
match
---
name: fake_pull_secrets [6077,6094]
name: fake_pull_secrets [6077,6094]
===
match
---
operator: = [22615,22616]
operator: = [22615,22616]
===
match
---
trailer [23725,23766]
trailer [23725,23766]
===
match
---
name: name [16165,16169]
name: name [16165,16169]
===
match
---
name: V1NodeSelectorTerm [19066,19084]
name: V1NodeSelectorTerm [19066,19084]
===
match
---
arglist [8643,8703]
arglist [8643,8703]
===
match
---
argument [19549,19570]
argument [19549,19570]
===
match
---
operator: = [20490,20491]
operator: = [20490,20491]
===
match
---
name: pod_name [23629,23637]
name: pod_name [23629,23637]
===
match
---
name: name [10561,10565]
name: name [10561,10565]
===
match
---
operator: , [21774,21775]
operator: , [21774,21775]
===
match
---
argument [3121,3135]
argument [3121,3135]
===
match
---
argument [18527,18544]
argument [18527,18544]
===
match
---
operator: , [22797,22798]
operator: , [22797,22798]
===
match
---
name: image [10004,10009]
name: image [10004,10009]
===
match
---
name: name_base [10569,10578]
name: name_base [10569,10578]
===
match
---
name: arguments [3833,3842]
name: arguments [3833,3842]
===
match
---
atom_expr [13285,13325]
atom_expr [13285,13325]
===
match
---
operator: = [5886,5887]
operator: = [5886,5887]
===
match
---
name: spec [9508,9512]
name: spec [9508,9512]
===
match
---
name: k [3464,3465]
name: k [3464,3465]
===
match
---
trailer [9268,9273]
trailer [9268,9273]
===
match
---
operator: { [14121,14122]
operator: { [14121,14122]
===
match
---
argument [4773,4789]
argument [4773,4789]
===
match
---
atom [20975,20990]
atom [20975,20990]
===
match
---
operator: , [10899,10900]
operator: , [10899,10900]
===
match
---
name: name_base [15289,15298]
name: name_base [15289,15298]
===
match
---
simple_stmt [20727,20788]
simple_stmt [20727,20788]
===
match
---
name: models [923,929]
name: models [923,929]
===
match
---
operator: , [7126,7127]
operator: , [7126,7127]
===
match
---
name: task_id [18398,18405]
name: task_id [18398,18405]
===
match
---
operator: { [15039,15040]
operator: { [15039,15040]
===
match
---
operator: , [15857,15858]
operator: , [15857,15858]
===
match
---
simple_stmt [20864,21271]
simple_stmt [20864,21271]
===
match
---
trailer [12370,12372]
trailer [12370,12372]
===
match
---
string: "spec" [22204,22210]
string: "spec" [22204,22210]
===
match
---
trailer [23204,23431]
trailer [23204,23431]
===
match
---
arglist [8322,8525]
arglist [8322,8525]
===
match
---
simple_stmt [15085,15107]
simple_stmt [15085,15107]
===
match
---
string: "task_instance" [2406,2421]
string: "task_instance" [2406,2421]
===
match
---
name: k [3693,3694]
name: k [3693,3694]
===
match
---
simple_stmt [7754,8015]
simple_stmt [7754,8015]
===
match
---
operator: , [1243,1244]
operator: , [1243,1244]
===
match
---
name: client_patch [1628,1640]
name: client_patch [1628,1640]
===
match
---
assert_stmt [13278,13337]
assert_stmt [13278,13337]
===
match
---
operator: { [17258,17259]
operator: { [17258,17259]
===
match
---
argument [9176,9198]
argument [9176,9198]
===
match
---
atom_expr [1502,1614]
atom_expr [1502,1614]
===
match
---
funcdef [16989,17664]
funcdef [16989,17664]
===
match
---
operator: , [16151,16152]
operator: , [16151,16152]
===
match
---
simple_stmt [9377,9450]
simple_stmt [9377,9450]
===
match
---
atom_expr [4439,4484]
atom_expr [4439,4484]
===
match
---
argument [7826,7846]
argument [7826,7846]
===
match
---
simple_stmt [7034,7437]
simple_stmt [7034,7437]
===
match
---
trailer [16522,16542]
trailer [16522,16542]
===
match
---
name: affinity [18772,18780]
name: affinity [18772,18780]
===
match
---
name: image [8865,8870]
name: image [8865,8870]
===
match
---
name: side_effect [7463,7474]
name: side_effect [7463,7474]
===
match
---
string: "default" [6397,6406]
string: "default" [6397,6406]
===
match
---
dictorsetmaker [18343,18355]
dictorsetmaker [18343,18355]
===
match
---
operator: = [21567,21568]
operator: = [21567,21568]
===
match
---
name: self [22082,22086]
name: self [22082,22086]
===
match
---
operator: = [16231,16232]
operator: = [16231,16232]
===
match
---
name: in_cluster [21127,21137]
name: in_cluster [21127,21137]
===
match
---
argument [3096,3107]
argument [3096,3107]
===
match
---
operator: , [9829,9830]
operator: , [9829,9830]
===
match
---
string: "bar" [22660,22665]
string: "bar" [22660,22665]
===
match
---
operator: = [21239,21240]
operator: = [21239,21240]
===
match
---
trailer [14948,14953]
trailer [14948,14953]
===
match
---
simple_stmt [9008,9210]
simple_stmt [9008,9210]
===
match
---
string: "default" [8332,8341]
string: "default" [8332,8341]
===
match
---
operator: = [12612,12613]
operator: = [12612,12613]
===
match
---
operator: = [2580,2581]
operator: = [2580,2581]
===
match
---
name: spec [8718,8722]
name: spec [8718,8722]
===
match
---
funcdef [21515,23131]
funcdef [21515,23131]
===
match
---
import_from [841,866]
import_from [841,866]
===
match
---
string: "airflow_version" [9874,9891]
string: "airflow_version" [9874,9891]
===
match
---
trailer [1366,1372]
trailer [1366,1372]
===
match
---
import_from [882,936]
import_from [882,936]
===
match
---
argument [19612,19626]
argument [19612,19626]
===
match
---
string: "bar" [5895,5900]
string: "bar" [5895,5900]
===
match
---
atom_expr [1643,1703]
atom_expr [1643,1703]
===
match
---
string: "echo 10" [3844,3853]
string: "echo 10" [3844,3853]
===
match
---
param [17699,17703]
param [17699,17703]
===
match
---
name: labels [19549,19555]
name: labels [19549,19555]
===
match
---
operator: } [13834,13835]
operator: } [13834,13835]
===
match
---
argument [4835,4852]
argument [4835,4852]
===
match
---
argument [20084,20093]
argument [20084,20093]
===
match
---
name: sanitize_for_serialization [20687,20713]
name: sanitize_for_serialization [20687,20713]
===
match
---
operator: , [14454,14455]
operator: , [14454,14455]
===
match
---
name: pod [22025,22028]
name: pod [22025,22028]
===
match
---
name: self [2465,2469]
name: self [2465,2469]
===
match
---
operator: , [5823,5824]
operator: , [5823,5824]
===
match
---
string: "bartemplated" [4269,4283]
string: "bartemplated" [4269,4283]
===
match
---
operator: = [22029,22030]
operator: = [22029,22030]
===
match
---
assert_stmt [4240,4283]
assert_stmt [4240,4283]
===
match
---
atom_expr [22968,23004]
atom_expr [22968,23004]
===
match
---
name: ANY [5547,5550]
name: ANY [5547,5550]
===
match
---
string: "fakeSecret" [5684,5696]
string: "fakeSecret" [5684,5696]
===
match
---
name: pod [9673,9676]
name: pod [9673,9676]
===
match
---
trailer [1627,1640]
trailer [1627,1640]
===
match
---
name: State [16419,16424]
name: State [16419,16424]
===
match
---
operator: = [19842,19843]
operator: = [19842,19843]
===
match
---
operator: = [4815,4816]
operator: = [4815,4816]
===
match
---
name: self [20682,20686]
name: self [20682,20686]
===
match
---
name: cmds [20970,20974]
name: cmds [20970,20974]
===
match
---
funcdef [2706,2808]
funcdef [2706,2808]
===
match
---
operator: = [20087,20088]
operator: = [20087,20088]
===
match
---
operator: , [4852,4853]
operator: , [4852,4853]
===
match
---
name: metadata [9350,9358]
name: metadata [9350,9358]
===
match
---
name: labels [10804,10810]
name: labels [10804,10810]
===
match
---
simple_stmt [16675,16708]
simple_stmt [16675,16708]
===
match
---
testlist_comp [13821,13833]
testlist_comp [13821,13833]
===
match
---
simple_stmt [7613,7640]
simple_stmt [7613,7640]
===
match
---
operator: @ [6864,6865]
operator: @ [6864,6865]
===
match
---
operator: = [22452,22453]
operator: = [22452,22453]
===
match
---
name: arguments [3026,3035]
name: arguments [3026,3035]
===
match
---
name: airflow [1044,1051]
name: airflow [1044,1051]
===
match
---
operator: , [20111,20112]
operator: , [20111,20112]
===
match
---
assert_stmt [13212,13265]
assert_stmt [13212,13265]
===
match
---
string: "default" [23228,23237]
string: "default" [23228,23237]
===
match
---
trailer [22203,22211]
trailer [22203,22211]
===
match
---
argument [20452,20466]
argument [20452,20466]
===
match
---
trailer [20083,20127]
trailer [20083,20127]
===
match
---
operator: , [8678,8679]
operator: , [8678,8679]
===
match
---
simple_stmt [17742,18151]
simple_stmt [17742,18151]
===
match
---
name: tolerations [20138,20149]
name: tolerations [20138,20149]
===
match
---
expr_stmt [14847,15072]
expr_stmt [14847,15072]
===
match
---
argument [5880,5901]
argument [5880,5901]
===
match
---
simple_stmt [6155,6188]
simple_stmt [6155,6188]
===
match
---
dictorsetmaker [13504,14634]
dictorsetmaker [13504,14634]
===
match
---
name: arguments [18300,18309]
name: arguments [18300,18309]
===
match
---
argument [20903,20922]
argument [20903,20922]
===
match
---
string: "key" [20161,20166]
string: "key" [20161,20166]
===
match
---
trailer [1767,1780]
trailer [1767,1780]
===
match
---
atom [3843,3854]
atom [3843,3854]
===
match
---
name: client_mock [1823,1834]
name: client_mock [1823,1834]
===
match
---
name: render_template_fields [4100,4122]
name: render_template_fields [4100,4122]
===
match
---
name: affinity [17742,17750]
name: affinity [17742,17750]
===
match
---
assert_stmt [9377,9449]
assert_stmt [9377,9449]
===
match
---
argument [18488,18513]
argument [18488,18513]
===
match
---
atom_expr [18851,19353]
atom_expr [18851,19353]
===
match
---
name: image_pull_policy [6829,6846]
name: image_pull_policy [6829,6846]
===
match
---
operator: = [10338,10339]
operator: = [10338,10339]
===
match
---
parameters [11132,11138]
parameters [11132,11138]
===
match
---
name: in_cluster [3553,3563]
name: in_cluster [3553,3563]
===
match
---
comparison [9673,9952]
comparison [9673,9952]
===
match
---
operator: , [6569,6570]
operator: , [6569,6570]
===
match
---
operator: = [19131,19132]
operator: = [19131,19132]
===
match
---
name: raises [16630,16636]
name: raises [16630,16636]
===
match
---
atom_expr [15959,16319]
atom_expr [15959,16319]
===
match
---
name: containers [13294,13304]
name: containers [13294,13304]
===
match
---
string: "try_number" [5492,5504]
string: "try_number" [5492,5504]
===
match
---
assert_stmt [13417,13462]
assert_stmt [13417,13462]
===
match
---
operator: , [21924,21925]
operator: , [21924,21925]
===
match
---
name: self [1983,1987]
name: self [1983,1987]
===
match
---
atom_expr [9012,9209]
atom_expr [9012,9209]
===
match
---
operator: == [9413,9415]
operator: == [9413,9415]
===
match
---
name: pod [10493,10496]
name: pod [10493,10496]
===
match
---
operator: , [4671,4672]
operator: , [4671,4672]
===
match
---
operator: = [6621,6622]
operator: = [6621,6622]
===
match
---
dictorsetmaker [15040,15056]
dictorsetmaker [15040,15056]
===
match
---
trailer [12653,12662]
trailer [12653,12662]
===
match
---
trailer [9897,9901]
trailer [9897,9901]
===
match
---
argument [16165,16179]
argument [16165,16179]
===
match
---
expr_stmt [18606,18658]
expr_stmt [18606,18658]
===
match
---
name: image [5061,5066]
name: image [5061,5066]
===
match
---
operator: = [10256,10257]
operator: = [10256,10257]
===
match
---
atom_expr [21425,21441]
atom_expr [21425,21441]
===
match
---
atom_expr [7758,8014]
atom_expr [7758,8014]
===
match
---
trailer [1807,1809]
trailer [1807,1809]
===
match
---
trailer [16837,16841]
trailer [16837,16841]
===
match
---
name: arguments [17216,17225]
name: arguments [17216,17225]
===
match
---
name: arguments [7174,7183]
name: arguments [7174,7183]
===
match
---
operator: } [5900,5901]
operator: } [5900,5901]
===
match
---
string: "foo" [16138,16143]
string: "foo" [16138,16143]
===
match
---
operator: , [6659,6660]
operator: , [6659,6660]
===
match
---
argument [6641,6659]
argument [6641,6659]
===
match
---
arglist [18837,19354]
arglist [18837,19354]
===
match
---
string: "hello" [15040,15047]
string: "hello" [15040,15047]
===
match
---
operator: , [22695,22696]
operator: , [22695,22696]
===
match
---
string: "foo" [19557,19562]
string: "foo" [19557,19562]
===
match
---
name: do_xcom_push [4803,4815]
name: do_xcom_push [4803,4815]
===
match
---
string: "default" [21662,21671]
string: "default" [21662,21671]
===
match
---
name: namespace [6387,6396]
name: namespace [6387,6396]
===
match
---
trailer [1952,1957]
trailer [1952,1957]
===
match
---
string: "dag" [9746,9751]
string: "dag" [9746,9751]
===
match
---
operator: = [23734,23735]
operator: = [23734,23735]
===
match
---
trailer [20889,21270]
trailer [20889,21270]
===
match
---
name: return_value [17467,17479]
name: return_value [17467,17479]
===
match
---
atom_expr [9341,9368]
atom_expr [9341,9368]
===
match
---
trailer [13304,13307]
trailer [13304,13307]
===
match
---
trailer [1875,1886]
trailer [1875,1886]
===
match
---
argument [2125,2134]
argument [2125,2134]
===
match
---
operator: = [10057,10058]
operator: = [10057,10058]
===
match
---
argument [2136,2157]
argument [2136,2157]
===
match
---
operator: , [5175,5176]
operator: , [5175,5176]
===
match
---
string: "-cx" [3813,3818]
string: "-cx" [3813,3818]
===
match
---
name: tpl_file [12398,12406]
name: tpl_file [12398,12406]
===
match
---
trailer [18595,18597]
trailer [18595,18597]
===
match
---
name: self [7711,7715]
name: self [7711,7715]
===
match
---
argument [6673,6699]
argument [6673,6699]
===
match
---
suite [7555,7640]
suite [7555,7640]
===
match
---
testlist_comp [14352,14364]
testlist_comp [14352,14364]
===
match
---
argument [22606,22627]
argument [22606,22627]
===
match
---
operator: , [17272,17273]
operator: , [17272,17273]
===
match
---
name: k8s [933,936]
name: k8s [933,936]
===
match
---
name: name [20427,20431]
name: name [20427,20431]
===
match
---
name: kubernetes [1067,1077]
name: kubernetes [1067,1077]
===
match
---
testlist_comp [17483,17508]
testlist_comp [17483,17508]
===
match
---
simple_stmt [5285,5307]
simple_stmt [5285,5307]
===
match
---
name: test_tolerations [20012,20028]
name: test_tolerations [20012,20028]
===
match
---
suite [20035,21510]
suite [20035,21510]
===
match
---
expr_stmt [19828,19880]
expr_stmt [19828,19880]
===
match
---
name: k [18571,18572]
name: k [18571,18572]
===
match
---
operator: = [7895,7896]
operator: = [7895,7896]
===
match
---
name: labels [17251,17257]
name: labels [17251,17257]
===
match
---
dictorsetmaker [5359,5591]
dictorsetmaker [5359,5591]
===
match
---
string: "default" [3742,3751]
string: "default" [3742,3751]
===
match
---
trailer [8790,8802]
trailer [8790,8802]
===
match
---
atom_expr [1481,1499]
atom_expr [1481,1499]
===
match
---
simple_stmt [22952,23005]
simple_stmt [22952,23005]
===
match
---
argument [6488,6509]
argument [6488,6509]
===
match
---
trailer [2180,2188]
trailer [2180,2188]
===
match
---
name: pod_template_yaml [12413,12430]
name: pod_template_yaml [12413,12430]
===
match
---
name: run_id [2198,2204]
name: run_id [2198,2204]
===
match
---
string: "execution_date" [11063,11079]
string: "execution_date" [11063,11079]
===
match
---
argument [19446,19466]
argument [19446,19466]
===
match
---
operator: , [7313,7314]
operator: , [7313,7314]
===
match
---
trailer [8216,8223]
trailer [8216,8223]
===
match
---
expr_stmt [15085,15106]
expr_stmt [15085,15106]
===
match
---
string: "default" [5754,5763]
string: "default" [5754,5763]
===
match
---
operator: = [16065,16066]
operator: = [16065,16066]
===
match
---
string: "foo" [13457,13462]
string: "foo" [13457,13462]
===
match
---
simple_stmt [11148,12338]
simple_stmt [11148,12338]
===
match
---
trailer [7059,7436]
trailer [7059,7436]
===
match
---
parameters [4973,4979]
parameters [4973,4979]
===
match
---
name: unittest [792,800]
name: unittest [792,800]
===
match
---
operator: , [9198,9199]
operator: , [9198,9199]
===
match
---
trailer [7779,8014]
trailer [7779,8014]
===
match
---
name: file_path [2849,2858]
name: file_path [2849,2858]
===
match
---
name: self [15912,15916]
name: self [15912,15916]
===
match
---
dictorsetmaker [14147,14511]
dictorsetmaker [14147,14511]
===
match
---
name: KubernetesPodOperator [1110,1131]
name: KubernetesPodOperator [1110,1131]
===
match
---
name: self [3433,3437]
name: self [3433,3437]
===
match
---
parameters [7001,7024]
parameters [7001,7024]
===
match
---
string: "kubernetes_pod_operator" [10913,10938]
string: "kubernetes_pod_operator" [10913,10938]
===
match
---
simple_stmt [17449,17510]
simple_stmt [17449,17510]
===
match
---
string: "kubernetes_pod_operator" [9765,9790]
string: "kubernetes_pod_operator" [9765,9790]
===
match
---
atom_expr [20745,20768]
atom_expr [20745,20768]
===
match
---
testlist_comp [21725,21738]
testlist_comp [21725,21738]
===
match
---
fstring_start: f" [16807,16809]
fstring_start: f" [16807,16809]
===
match
---
name: pod [15085,15088]
name: pod [15085,15088]
===
match
---
name: pod [5285,5288]
name: pod [5285,5288]
===
match
---
atom_expr [1837,1862]
atom_expr [1837,1862]
===
match
---
trailer [21341,21368]
trailer [21341,21368]
===
match
---
name: task_id [16193,16200]
name: task_id [16193,16200]
===
match
---
simple_stmt [7568,7601]
simple_stmt [7568,7601]
===
match
---
operator: = [9117,9118]
operator: = [9117,9118]
===
match
---
trailer [1734,1746]
trailer [1734,1746]
===
match
---
name: node_selectors [22858,22872]
name: node_selectors [22858,22872]
===
match
---
name: k [21286,21287]
name: k [21286,21287]
===
match
---
operator: = [10283,10284]
operator: = [10283,10284]
===
match
---
simple_stmt [22066,22119]
simple_stmt [22066,22119]
===
match
---
operator: == [4266,4268]
operator: == [4266,4268]
===
match
---
name: start_mock [2674,2684]
name: start_mock [2674,2684]
===
match
---
argument [5028,5047]
argument [5028,5047]
===
match
---
operator: = [3914,3915]
operator: = [3914,3915]
===
match
---
name: execute [7615,7622]
name: execute [7615,7622]
===
match
---
operator: , [6135,6136]
operator: , [6135,6136]
===
match
---
argument [18199,18218]
argument [18199,18218]
===
match
---
string: "ubuntu:16.04" [8871,8885]
string: "ubuntu:16.04" [8871,8885]
===
match
---
trailer [13307,13325]
trailer [13307,13325]
===
match
---
name: spec [14673,14677]
name: spec [14673,14677]
===
match
---
string: "value" [20119,20126]
string: "value" [20119,20126]
===
match
---
simple_stmt [15955,16320]
simple_stmt [15955,16320]
===
match
---
trailer [6809,6814]
trailer [6809,6814]
===
match
---
operator: , [14357,14358]
operator: , [14357,14358]
===
match
---
expr_stmt [8023,8055]
expr_stmt [8023,8055]
===
match
---
name: self [21538,21542]
name: self [21538,21542]
===
match
---
trailer [2331,2333]
trailer [2331,2333]
===
match
---
name: start_mock [1717,1727]
name: start_mock [1717,1727]
===
match
---
atom_expr [10383,10398]
atom_expr [10383,10398]
===
match
---
operator: , [3197,3198]
operator: , [3197,3198]
===
match
---
operator: , [2469,2470]
operator: , [2469,2470]
===
match
---
trailer [15853,15857]
trailer [15853,15857]
===
match
---
expr_stmt [21321,21373]
expr_stmt [21321,21373]
===
match
---
operator: = [7248,7249]
operator: = [7248,7249]
===
match
---
operator: = [17290,17291]
operator: = [17290,17291]
===
match
---
trailer [1752,1754]
trailer [1752,1754]
===
match
---
argument [15032,15057]
argument [15032,15057]
===
match
---
assert_stmt [9308,9368]
assert_stmt [9308,9368]
===
match
---
trailer [22144,22174]
trailer [22144,22174]
===
match
---
string: 'required_during_scheduling_ignored_during_execution' [14066,14119]
string: 'required_during_scheduling_ignored_during_execution' [14066,14119]
===
match
---
trailer [7622,7639]
trailer [7622,7639]
===
match
---
string: "default" [21954,21963]
string: "default" [21954,21963]
===
match
---
operator: } [9951,9952]
operator: } [9951,9952]
===
match
---
argument [4030,4046]
argument [4030,4046]
===
match
---
name: pod [18685,18688]
name: pod [18685,18688]
===
match
---
operator: = [8625,8626]
operator: = [8625,8626]
===
match
---
operator: = [14975,14976]
operator: = [14975,14976]
===
match
---
operator: = [20592,20593]
operator: = [20592,20593]
===
match
---
arglist [7073,7426]
arglist [7073,7426]
===
match
---
operator: , [5115,5116]
operator: , [5115,5116]
===
match
---
suite [2840,3655]
suite [2840,3655]
===
match
---
name: k8s [18962,18965]
name: k8s [18962,18965]
===
match
---
operator: = [17577,17578]
operator: = [17577,17578]
===
match
---
operator: , [2978,2979]
operator: , [2978,2979]
===
match
---
argument [10114,10128]
argument [10114,10128]
===
match
---
name: pod_spec [9499,9507]
name: pod_spec [9499,9507]
===
match
---
name: affinity [19916,19924]
name: affinity [19916,19924]
===
match
---
expr_stmt [20217,20615]
expr_stmt [20217,20615]
===
match
---
trailer [8089,8100]
trailer [8089,8100]
===
match
---
argument [21876,21892]
argument [21876,21892]
===
match
---
arglist [21400,21441]
arglist [21400,21441]
===
match
---
atom_expr [19957,19990]
atom_expr [19957,19990]
===
match
---
trailer [6825,6828]
trailer [6825,6828]
===
match
---
operator: , [9860,9861]
operator: , [9860,9861]
===
match
---
name: mock [1643,1647]
name: mock [1643,1647]
===
match
---
atom_expr [19793,19819]
atom_expr [19793,19819]
===
match
---
operator: = [7420,7421]
operator: = [7420,7421]
===
match
---
trailer [13227,13238]
trailer [13227,13238]
===
match
---
trailer [22999,23004]
trailer [22999,23004]
===
match
---
operator: = [6159,6160]
operator: = [6159,6160]
===
match
---
expr_stmt [16385,16457]
expr_stmt [16385,16457]
===
match
---
simple_stmt [22183,22245]
simple_stmt [22183,22245]
===
match
---
name: failed_pod_status [16328,16345]
name: failed_pod_status [16328,16345]
===
match
---
name: do_xcom_push [3179,3191]
name: do_xcom_push [3179,3191]
===
match
---
name: task [2355,2359]
name: task [2355,2359]
===
match
---
name: pod_name [23795,23803]
name: pod_name [23795,23803]
===
match
---
expr_stmt [21553,21603]
expr_stmt [21553,21603]
===
match
---
simple_stmt [8065,8112]
simple_stmt [8065,8112]
===
match
---
operator: , [20604,20605]
operator: , [20604,20605]
===
match
---
name: name [4464,4468]
name: name [4464,4468]
===
match
---
name: match [22355,22360]
name: match [22355,22360]
===
match
---
operator: = [6590,6591]
operator: = [6590,6591]
===
match
---
argument [9047,9061]
argument [9047,9061]
===
match
---
name: DagRun [2191,2197]
name: DagRun [2191,2197]
===
match
---
operator: , [21423,21424]
operator: , [21423,21424]
===
match
---
operator: = [4072,4073]
operator: = [4072,4073]
===
match
---
name: fake_pull_secrets [5664,5681]
name: fake_pull_secrets [5664,5681]
===
match
---
argument [22858,22886]
argument [22858,22886]
===
match
---
operator: = [7802,7803]
operator: = [7802,7803]
===
match
---
name: unittest [1294,1302]
name: unittest [1294,1302]
===
match
---
dictorsetmaker [4132,4176]
dictorsetmaker [4132,4176]
===
match
---
operator: , [22666,22667]
operator: , [22666,22667]
===
match
---
and_test [23782,23824]
and_test [23782,23824]
===
match
---
atom_expr [3878,3927]
atom_expr [3878,3927]
===
match
---
string: "foo" [5888,5893]
string: "foo" [5888,5893]
===
match
---
operator: = [19023,19024]
operator: = [19023,19024]
===
match
---
name: k [19374,19375]
name: k [19374,19375]
===
match
---
operator: = [14774,14775]
operator: = [14774,14775]
===
match
---
name: arguments [4650,4659]
name: arguments [4650,4659]
===
match
---
argument [5845,5866]
argument [5845,5866]
===
match
---
name: do_xcom_push [16251,16263]
name: do_xcom_push [16251,16263]
===
match
---
trailer [16389,16402]
trailer [16389,16402]
===
match
---
string: "{{ bar }}" [3896,3907]
string: "{{ bar }}" [3896,3907]
===
match
---
operator: } [5149,5150]
operator: } [5149,5150]
===
match
---
name: self [1763,1767]
name: self [1763,1767]
===
match
---
atom_expr [2484,2493]
atom_expr [2484,2493]
===
match
---
dictorsetmaker [21570,21602]
dictorsetmaker [21570,21602]
===
match
---
operator: , [9722,9723]
operator: , [9722,9723]
===
match
---
expr_stmt [18160,18555]
expr_stmt [18160,18555]
===
match
---
operator: , [6597,6598]
operator: , [6597,6598]
===
match
---
simple_stmt [882,937]
simple_stmt [882,937]
===
match
---
operator: } [7229,7230]
operator: } [7229,7230]
===
match
---
trailer [7462,7474]
trailer [7462,7474]
===
match
---
name: name [16851,16855]
name: name [16851,16855]
===
match
---
argument [19114,19272]
argument [19114,19272]
===
match
---
operator: } [3962,3963]
operator: } [3962,3963]
===
match
---
operator: , [23590,23591]
operator: , [23590,23591]
===
match
---
param [2834,2838]
param [2834,2838]
===
match
---
operator: = [17480,17481]
operator: = [17480,17481]
===
match
---
argument [21938,21963]
argument [21938,21963]
===
match
---
name: pod [6806,6809]
name: pod [6806,6809]
===
match
---
string: "task" [20460,20466]
string: "task" [20460,20466]
===
match
---
trailer [20686,20713]
trailer [20686,20713]
===
match
---
operator: = [18405,18406]
operator: = [18405,18406]
===
match
---
trailer [1238,1259]
trailer [1238,1259]
===
match
---
expr_stmt [10004,10038]
expr_stmt [10004,10038]
===
match
---
name: mock [1362,1366]
name: mock [1362,1366]
===
match
---
operator: = [20150,20151]
operator: = [20150,20151]
===
match
---
name: labels [4685,4691]
name: labels [4685,4691]
===
match
---
atom_expr [6050,6095]
atom_expr [6050,6095]
===
match
---
suite [7717,8158]
suite [7717,8158]
===
match
---
simple_stmt [14662,14709]
simple_stmt [14662,14709]
===
match
---
operator: = [4876,4877]
operator: = [4876,4877]
===
match
---
atom_expr [18735,18768]
atom_expr [18735,18768]
===
match
---
string: "bar" [10835,10840]
string: "bar" [10835,10840]
===
match
---
expr_stmt [20625,20657]
expr_stmt [20625,20657]
===
match
---
argument [22779,22797]
argument [22779,22797]
===
match
---
name: spec [15322,15326]
name: spec [15322,15326]
===
match
---
name: task_id [8397,8404]
name: task_id [8397,8404]
===
match
---
name: image_pull_policy [13308,13325]
name: image_pull_policy [13308,13325]
===
match
---
trailer [23487,23529]
trailer [23487,23529]
===
match
---
param [2471,2479]
param [2471,2479]
===
match
---
simple_stmt [16756,16908]
simple_stmt [16756,16908]
===
match
---
dictorsetmaker [17259,17271]
dictorsetmaker [17259,17271]
===
match
---
operator: , [19535,19536]
operator: , [19535,19536]
===
match
---
assert_stmt [23833,23897]
assert_stmt [23833,23897]
===
match
---
name: k [4098,4099]
name: k [4098,4099]
===
match
---
name: task_id [7269,7276]
name: task_id [7269,7276]
===
match
---
operator: , [18442,18443]
operator: , [18442,18443]
===
match
---
name: node_selector [21991,22004]
name: node_selector [21991,22004]
===
match
---
operator: , [18321,18322]
operator: , [18321,18322]
===
match
---
trailer [19399,19777]
trailer [19399,19777]
===
match
---
argument [16730,16745]
argument [16730,16745]
===
match
---
param [4328,4333]
param [4328,4333]
===
match
---
name: spec [22149,22153]
name: spec [22149,22153]
===
match
---
trailer [20816,20824]
trailer [20816,20824]
===
match
---
string: "-cx" [19494,19499]
string: "-cx" [19494,19499]
===
match
---
simple_stmt [21382,21443]
simple_stmt [21382,21443]
===
match
---
operator: } [14365,14366]
operator: } [14365,14366]
===
match
---
atom_expr [23020,23060]
atom_expr [23020,23060]
===
match
---
number: 0 [1254,1255]
number: 0 [1254,1255]
===
match
---
name: name [3096,3100]
name: name [3096,3100]
===
match
---
operator: , [4759,4760]
operator: , [4759,4760]
===
match
---
name: V1Affinity [19930,19940]
name: V1Affinity [19930,19940]
===
match
---
trailer [7536,7554]
trailer [7536,7554]
===
match
---
dictorsetmaker [14234,14455]
dictorsetmaker [14234,14455]
===
match
---
argument [18370,18384]
argument [18370,18384]
===
match
---
string: 'default' [4559,4568]
string: 'default' [4559,4568]
===
match
---
name: image_pull_secrets [6030,6048]
name: image_pull_secrets [6030,6048]
===
match
---
trailer [14677,14686]
trailer [14677,14686]
===
match
---
string: "default" [19423,19432]
string: "default" [19423,19432]
===
match
---
trailer [12452,12458]
trailer [12452,12458]
===
match
---
assert_stmt [21451,21509]
assert_stmt [21451,21509]
===
match
---
argument [19584,19598]
argument [19584,19598]
===
match
---
funcdef [2813,3655]
funcdef [2813,3655]
===
match
---
operator: = [5135,5136]
operator: = [5135,5136]
===
match
---
operator: , [20768,20769]
operator: , [20768,20769]
===
match
---
trailer [8100,8111]
trailer [8100,8111]
===
match
---
argument [5744,5763]
argument [5744,5763]
===
match
---
operator: , [3082,3083]
operator: , [3082,3083]
===
match
---
argument [10142,10158]
argument [10142,10158]
===
match
---
simple_stmt [17714,17733]
simple_stmt [17714,17733]
===
match
---
atom [13762,13835]
atom [13762,13835]
===
match
---
operator: = [8647,8648]
operator: = [8647,8648]
===
match
---
trailer [2628,2636]
trailer [2628,2636]
===
match
---
name: V1ObjectMeta [8630,8642]
name: V1ObjectMeta [8630,8642]
===
match
---
operator: = [18535,18536]
operator: = [18535,18536]
===
match
---
trailer [19970,19978]
trailer [19970,19978]
===
match
---
name: self [4974,4978]
name: self [4974,4978]
===
match
---
argument [3833,3854]
argument [3833,3854]
===
match
---
operator: { [20399,20400]
operator: { [20399,20400]
===
match
---
operator: , [17300,17301]
operator: , [17300,17301]
===
match
---
string: "fake failure" [7494,7508]
string: "fake failure" [7494,7508]
===
match
---
name: metadata [13164,13172]
name: metadata [13164,13172]
===
match
---
name: AirflowException [7537,7553]
name: AirflowException [7537,7553]
===
match
---
operator: , [14633,14634]
operator: , [14633,14634]
===
match
---
name: pod [15318,15321]
name: pod [15318,15321]
===
match
---
atom_expr [21389,21442]
atom_expr [21389,21442]
===
match
---
name: client_patch [1988,2000]
name: client_patch [1988,2000]
===
match
---
string: "tolerations" [20825,20838]
string: "tolerations" [20825,20838]
===
match
---
operator: , [20990,20991]
operator: , [20990,20991]
===
match
---
funcdef [7683,8158]
funcdef [7683,8158]
===
match
---
name: image [18232,18237]
name: image [18232,18237]
===
match
---
operator: == [15547,15549]
operator: == [15547,15549]
===
match
---
comparison [12829,13140]
comparison [12829,13140]
===
match
---
name: sanitize_for_serialization [22973,22999]
name: sanitize_for_serialization [22973,22999]
===
match
---
name: name [8140,8144]
name: name [8140,8144]
===
match
---
operator: , [21809,21810]
operator: , [21809,21810]
===
match
---
string: "footemplated" [4217,4231]
string: "footemplated" [4217,4231]
===
match
---
simple_stmt [8023,8056]
simple_stmt [8023,8056]
===
match
---
atom [3877,3928]
atom [3877,3928]
===
match
---
assert_stmt [17596,17663]
assert_stmt [17596,17663]
===
match
---
string: "-cx" [20337,20342]
string: "-cx" [20337,20342]
===
match
---
name: k8s [19926,19929]
name: k8s [19926,19929]
===
match
---
atom [17852,18126]
atom [17852,18126]
===
match
---
import_name [868,881]
import_name [868,881]
===
match
---
operator: , [9941,9942]
operator: , [9941,9942]
===
match
---
expr_stmt [17519,17551]
expr_stmt [17519,17551]
===
match
---
trailer [7614,7622]
trailer [7614,7622]
===
match
---
atom [2536,2563]
atom [2536,2563]
===
match
---
operator: = [19233,19234]
operator: = [19233,19234]
===
match
---
name: pod [4909,4912]
name: pod [4909,4912]
===
match
---
trailer [22475,22901]
trailer [22475,22901]
===
match
---
operator: , [16308,16309]
operator: , [16308,16309]
===
match
---
operator: , [8885,8886]
operator: , [8885,8886]
===
match
---
string: "something" [8920,8931]
string: "something" [8920,8931]
===
match
---
argument [5164,5175]
argument [5164,5175]
===
match
---
operator: } [15056,15057]
operator: } [15056,15057]
===
match
---
name: self [2737,2741]
name: self [2737,2741]
===
match
---
atom_expr [16927,16983]
atom_expr [16927,16983]
===
match
---
string: 'match_expressions' [14234,14253]
string: 'match_expressions' [14234,14253]
===
match
---
atom [3068,3082]
atom [3068,3082]
===
match
---
argument [23344,23358]
argument [23344,23358]
===
match
---
name: NamedTemporaryFile [12352,12370]
name: NamedTemporaryFile [12352,12370]
===
match
---
trailer [15280,15285]
trailer [15280,15285]
===
match
---
operator: = [5782,5783]
operator: = [5782,5783]
===
match
---
name: in_cluster [7297,7307]
name: in_cluster [7297,7307]
===
match
---
expr_stmt [16675,16707]
expr_stmt [16675,16707]
===
match
---
name: tolerations [20593,20604]
name: tolerations [20593,20604]
===
match
---
operator: = [7339,7340]
operator: = [7339,7340]
===
match
---
trailer [9429,9440]
trailer [9429,9440]
===
match
---
argument [23592,23619]
argument [23592,23619]
===
match
---
name: metadata [16842,16850]
name: metadata [16842,16850]
===
match
---
suite [4340,4953]
suite [4340,4953]
===
match
---
name: return_value [3309,3321]
name: return_value [3309,3321]
===
match
---
name: containers [13228,13238]
name: containers [13228,13238]
===
match
---
simple_stmt [3360,3415]
simple_stmt [3360,3415]
===
match
---
name: self [1783,1787]
name: self [1783,1787]
===
match
---
name: failed_pod_status [16878,16895]
name: failed_pod_status [16878,16895]
===
match
---
trailer [23736,23744]
trailer [23736,23744]
===
match
---
expr_stmt [12474,12595]
expr_stmt [12474,12595]
===
match
---
name: isoformat [2322,2331]
name: isoformat [2322,2331]
===
match
---
expr_stmt [5705,6146]
expr_stmt [5705,6146]
===
match
---
name: cmds [4616,4620]
name: cmds [4616,4620]
===
match
---
name: image_pull_secrets [6212,6230]
name: image_pull_secrets [6212,6230]
===
match
---
atom_expr [21337,21373]
atom_expr [21337,21373]
===
match
---
operator: , [1246,1247]
operator: , [1246,1247]
===
match
---
trailer [22321,22436]
trailer [22321,22436]
===
match
---
string: b"""             apiVersion: v1             kind: Pod             metadata:               name: hello               namespace: mynamespace               labels:                 foo: bar             spec:               serviceAccountName: foo               affinity:                 nodeAffinity:                   requiredDuringSchedulingIgnoredDuringExecution:                     nodeSelectorTerms:                     - matchExpressions:                       - key: kubernetes.io/role                         operator: In                         values:                         - foo                         - bar                   preferredDuringSchedulingIgnoredDuringExecution:                   - weight: 1                     preference:                       matchExpressions:                       - key: kubernetes.io/role                         operator: In                         values:                         - foo                         - bar               containers:                 - name: base                   image: ubuntu:16.04                   imagePullPolicy: Always                   command:                     - something         """ [11168,12337]
string: b"""             apiVersion: v1             kind: Pod             metadata:               name: hello               namespace: mynamespace               labels:                 foo: bar             spec:               serviceAccountName: foo               affinity:                 nodeAffinity:                   requiredDuringSchedulingIgnoredDuringExecution:                     nodeSelectorTerms:                     - matchExpressions:                       - key: kubernetes.io/role                         operator: In                         values:                         - foo                         - bar                   preferredDuringSchedulingIgnoredDuringExecution:                   - weight: 1                     preference:                       matchExpressions:                       - key: kubernetes.io/role                         operator: In                         values:                         - foo                         - bar               containers:                 - name: base                   image: ubuntu:16.04                   imagePullPolicy: Always                   command:                     - something         """ [11168,12337]
===
match
---
name: pod [8127,8130]
name: pod [8127,8130]
===
match
---
name: name [19584,19588]
name: name [19584,19588]
===
match
---
simple_stmt [6196,6287]
simple_stmt [6196,6287]
===
match
---
expr_stmt [7726,7744]
expr_stmt [7726,7744]
===
match
---
argument [8322,8341]
argument [8322,8341]
===
match
---
dotted_name [943,961]
dotted_name [943,961]
===
match
---
string: "some.custom.image:andtag" [14776,14802]
string: "some.custom.image:andtag" [14776,14802]
===
match
---
argument [3179,3197]
argument [3179,3197]
===
match
---
string: "Always" [6691,6699]
string: "Always" [6691,6699]
===
match
---
name: sanitized_pod [22952,22965]
name: sanitized_pod [22952,22965]
===
match
---
string: "1" [13033,13036]
string: "1" [13033,13036]
===
match
---
comparison [5322,5601]
comparison [5322,5601]
===
match
---
name: image [21685,21690]
name: image [21685,21690]
===
match
---
operator: , [12882,12883]
operator: , [12882,12883]
===
match
---
operator: = [23661,23662]
operator: = [23661,23662]
===
match
---
name: name [23319,23323]
name: name [23319,23323]
===
match
---
trailer [23887,23897]
trailer [23887,23897]
===
match
---
name: KubernetesPodOperator [4993,5014]
name: KubernetesPodOperator [4993,5014]
===
match
---
name: configmap_name [4349,4363]
name: configmap_name [4349,4363]
===
match
---
name: k [23493,23494]
name: k [23493,23494]
===
match
---
atom_expr [2112,2158]
atom_expr [2112,2158]
===
match
---
name: in_cluster [16221,16231]
name: in_cluster [16221,16231]
===
match
---
trailer [15530,15539]
trailer [15530,15539]
===
match
---
trailer [22086,22113]
trailer [22086,22113]
===
match
---
atom [19556,19570]
atom [19556,19570]
===
match
---
operator: } [21059,21060]
operator: } [21059,21060]
===
match
---
funcdef [1318,2007]
funcdef [1318,2007]
===
match
---
trailer [16402,16415]
trailer [16402,16415]
===
match
---
operator: , [7092,7093]
operator: , [7092,7093]
===
match
---
name: k8s [8594,8597]
name: k8s [8594,8597]
===
match
---
suite [3684,4284]
suite [3684,4284]
===
match
---
simple_stmt [10047,10067]
simple_stmt [10047,10067]
===
match
---
expr_stmt [2503,2563]
expr_stmt [2503,2563]
===
match
---
operator: == [16804,16806]
operator: == [16804,16806]
===
match
---
atom_expr [4404,4485]
atom_expr [4404,4485]
===
match
---
suite [17039,17664]
suite [17039,17664]
===
match
---
expr_stmt [22952,23004]
expr_stmt [22952,23004]
===
match
---
operator: = [4783,4784]
operator: = [4783,4784]
===
match
---
string: "bar" [4700,4705]
string: "bar" [4700,4705]
===
match
---
atom_expr [3499,3654]
atom_expr [3499,3654]
===
match
---
name: name_base [16170,16179]
name: name_base [16170,16179]
===
match
---
string: "task_id" [15716,15725]
string: "task_id" [15716,15725]
===
match
---
dictorsetmaker [8665,8677]
dictorsetmaker [8665,8677]
===
match
---
name: namespace [20256,20265]
name: namespace [20256,20265]
===
match
---
argument [3765,3785]
argument [3765,3785]
===
match
---
name: key [19196,19199]
name: key [19196,19199]
===
match
---
name: self [11133,11137]
name: self [11133,11137]
===
match
---
operator: , [9061,9062]
operator: , [9061,9062]
===
match
---
string: "bash" [2998,3004]
string: "bash" [2998,3004]
===
match
---
fstring_expr [16877,16896]
fstring_expr [16877,16896]
===
match
---
trailer [20753,20765]
trailer [20753,20765]
===
match
---
dictorsetmaker [10340,10356]
dictorsetmaker [10340,10356]
===
match
---
operator: = [19376,19377]
operator: = [19376,19377]
===
match
---
name: k [4891,4892]
name: k [4891,4892]
===
match
---
argument [9105,9123]
argument [9105,9123]
===
match
---
name: self [2834,2838]
name: self [2834,2838]
===
match
---
string: 'kubernetes.io/role' [13770,13790]
string: 'kubernetes.io/role' [13770,13790]
===
match
---
operator: , [23494,23495]
operator: , [23494,23495]
===
match
---
string: "ubuntu:16.04" [20942,20956]
string: "ubuntu:16.04" [20942,20956]
===
match
---
atom_expr [7523,7554]
atom_expr [7523,7554]
===
match
---
name: startswith [10511,10521]
name: startswith [10511,10521]
===
match
---
operator: } [20205,20206]
operator: } [20205,20206]
===
match
---
string: "some.custom.image:andtag" [10012,10038]
string: "some.custom.image:andtag" [10012,10038]
===
match
---
operator: = [21762,21763]
operator: = [21762,21763]
===
match
---
operator: , [5926,5927]
operator: , [5926,5927]
===
match
---
operator: , [20567,20568]
operator: , [20567,20568]
===
match
---
atom_expr [7578,7600]
atom_expr [7578,7600]
===
match
---
atom_expr [13424,13453]
atom_expr [13424,13453]
===
match
---
name: start_patch [1735,1746]
name: start_patch [1735,1746]
===
match
---
trailer [13293,13304]
trailer [13293,13304]
===
match
---
argument [8643,8655]
argument [8643,8655]
===
match
---
string: 'key' [13763,13768]
string: 'key' [13763,13768]
===
match
---
name: pod [16838,16841]
name: pod [16838,16841]
===
match
---
operator: = [22688,22689]
operator: = [22688,22689]
===
match
---
operator: = [1641,1642]
operator: = [1641,1642]
===
match
---
name: match [8242,8247]
name: match [8242,8247]
===
match
---
operator: , [21731,21732]
operator: , [21731,21732]
===
match
---
name: create_pod_request_obj [19795,19817]
name: create_pod_request_obj [19795,19817]
===
match
---
operator: , [2289,2290]
operator: , [2289,2290]
===
match
---
name: config_map_ref [4424,4438]
name: config_map_ref [4424,4438]
===
match
---
operator: = [19619,19620]
operator: = [19619,19620]
===
match
---
name: read_namespaced_pod_mock [16551,16575]
name: read_namespaced_pod_mock [16551,16575]
===
match
---
expr_stmt [18790,19364]
expr_stmt [18790,19364]
===
match
---
argument [20936,20956]
argument [20936,20956]
===
match
---
name: namespace [15994,16003]
name: namespace [15994,16003]
===
match
---
trailer [9523,9526]
trailer [9523,9526]
===
match
---
name: context [3423,3430]
name: context [3423,3430]
===
match
---
simple_stmt [841,867]
simple_stmt [841,867]
===
match
---
string: "bash" [23291,23297]
string: "bash" [23291,23297]
===
match
---
name: task_id [19612,19619]
name: task_id [19612,19619]
===
match
---
operator: = [20431,20432]
operator: = [20431,20432]
===
match
---
trailer [5586,5590]
trailer [5586,5590]
===
match
---
dotted_name [1172,1191]
dotted_name [1172,1191]
===
match
---
name: k [12627,12628]
name: k [12627,12628]
===
match
---
operator: = [10219,10220]
operator: = [10219,10220]
===
match
---
arglist [20745,20786]
arglist [20745,20786]
===
match
---
string: "values" [18040,18048]
string: "values" [18040,18048]
===
match
---
operator: , [8704,8705]
operator: , [8704,8705]
===
match
---
name: self [18622,18626]
name: self [18622,18626]
===
match
---
name: pod [23807,23810]
name: pod [23807,23810]
===
match
---
operator: = [2080,2081]
operator: = [2080,2081]
===
match
---
atom_expr [8283,8539]
atom_expr [8283,8539]
===
match
---
fstring_expr [16835,16856]
fstring_expr [16835,16856]
===
match
---
name: k [23459,23460]
name: k [23459,23460]
===
match
---
string: "dag_id" [12900,12908]
string: "dag_id" [12900,12908]
===
match
---
operator: , [8341,8342]
operator: , [8341,8342]
===
match
---
atom_expr [20221,20615]
atom_expr [20221,20615]
===
match
---
atom_expr [19166,19242]
atom_expr [19166,19242]
===
match
---
trailer [16780,16791]
trailer [16780,16791]
===
match
---
operator: , [19353,19354]
operator: , [19353,19354]
===
match
---
atom_expr [4098,4178]
atom_expr [4098,4178]
===
match
---
arglist [10114,10358]
arglist [10114,10358]
===
match
---
atom_expr [6352,6749]
atom_expr [6352,6749]
===
match
---
string: "node_selectors is deprecated. Please use node_selector instead." [22361,22426]
string: "node_selectors is deprecated. Please use node_selector instead." [22361,22426]
===
match
---
operator: , [20466,20467]
operator: , [20466,20467]
===
match
---
argument [20970,20990]
argument [20970,20990]
===
match
---
atom [18050,18057]
atom [18050,18057]
===
match
---
argument [5129,5150]
argument [5129,5150]
===
match
---
operator: } [14647,14648]
operator: } [14647,14648]
===
match
---
name: KubernetesPodOperator [19378,19399]
name: KubernetesPodOperator [19378,19399]
===
match
---
simple_stmt [5705,6147]
simple_stmt [5705,6147]
===
match
---
operator: = [23473,23474]
operator: = [23473,23474]
===
match
---
string: "name" [21828,21834]
string: "name" [21828,21834]
===
match
---
name: command [8911,8918]
name: command [8911,8918]
===
match
---
operator: } [21602,21603]
operator: } [21602,21603]
===
match
---
string: "1" [11005,11008]
string: "1" [11005,11008]
===
match
---
name: namespace [22493,22502]
name: namespace [22493,22502]
===
match
---
expr_stmt [8583,8998]
expr_stmt [8583,8998]
===
match
---
argument [21099,21113]
argument [21099,21113]
===
match
---
name: DEFAULT_DATE [23607,23619]
name: DEFAULT_DATE [23607,23619]
===
match
---
trailer [1891,1903]
trailer [1891,1903]
===
match
---
argument [7888,7902]
argument [7888,7902]
===
match
---
dotted_name [1137,1150]
dotted_name [1137,1150]
===
match
---
operator: = [21990,21991]
operator: = [21990,21991]
===
match
---
operator: = [21137,21138]
operator: = [21137,21138]
===
match
---
not_test [16923,16983]
not_test [16923,16983]
===
match
---
string: "airflow.kubernetes.kube_client.get_kube_client" [1654,1702]
string: "airflow.kubernetes.kube_client.get_kube_client" [1654,1702]
===
match
---
simple_stmt [7648,7678]
simple_stmt [7648,7678]
===
match
---
argument [6110,6135]
argument [6110,6135]
===
match
---
string: "value" [20198,20205]
string: "value" [20198,20205]
===
match
---
operator: = [23351,23352]
operator: = [23351,23352]
===
match
---
trailer [22148,22153]
trailer [22148,22153]
===
match
---
string: "test" [5920,5926]
string: "test" [5920,5926]
===
match
---
assert_stmt [13350,13404]
assert_stmt [13350,13404]
===
match
---
comparison [14669,14708]
comparison [14669,14708]
===
match
---
operator: = [4401,4402]
operator: = [4401,4402]
===
match
---
assert_stmt [4187,4231]
assert_stmt [4187,4231]
===
match
---
name: arguments [16095,16104]
name: arguments [16095,16104]
===
match
---
name: image [10626,10631]
name: image [10626,10631]
===
match
---
argument [4464,4483]
argument [4464,4483]
===
match
---
name: test_create_with_affinity [17673,17698]
name: test_create_with_affinity [17673,17698]
===
match
---
trailer [2802,2807]
trailer [2802,2807]
===
match
---
name: monitor_mock [3296,3308]
name: monitor_mock [3296,3308]
===
match
---
operator: = [1219,1220]
operator: = [1219,1220]
===
match
---
name: unittest [846,854]
name: unittest [846,854]
===
match
---
argument [22684,22695]
argument [22684,22695]
===
match
---
trailer [8642,8704]
trailer [8642,8704]
===
match
---
trailer [6211,6230]
trailer [6211,6230]
===
match
---
atom_expr [1294,1311]
atom_expr [1294,1311]
===
match
---
operator: = [3598,3599]
operator: = [3598,3599]
===
match
---
name: command [9488,9495]
name: command [9488,9495]
===
match
---
name: labels [15032,15038]
name: labels [15032,15038]
===
match
---
name: execute [17562,17569]
name: execute [17562,17569]
===
match
---
argument [2925,2944]
argument [2925,2944]
===
match
---
argument [22568,22588]
argument [22568,22588]
===
match
---
operator: , [8003,8004]
operator: , [8003,8004]
===
match
---
name: run_id [2136,2142]
name: run_id [2136,2142]
===
match
---
operator: == [15347,15349]
operator: == [15347,15349]
===
match
---
expr_stmt [16328,16376]
expr_stmt [16328,16376]
===
match
---
string: "airflow_version" [5523,5540]
string: "airflow_version" [5523,5540]
===
match
---
trailer [16629,16636]
trailer [16629,16636]
===
match
---
operator: , [8839,8840]
operator: , [8839,8840]
===
match
---
argument [6387,6406]
argument [6387,6406]
===
match
---
name: self [1918,1922]
name: self [1918,1922]
===
match
---
file_input [785,23898]
file_input [785,27643]
===
match
---
trailer [14686,14694]
trailer [14686,14694]
===
match
---
funcdef [2453,2701]
funcdef [2453,2701]
===
match
---
argument [7623,7638]
argument [7623,7638]
===
match
---
simple_stmt [4989,5277]
simple_stmt [4989,5277]
===
match
---
dictorsetmaker [17767,18140]
dictorsetmaker [17767,18140]
===
match
---
operator: , [10265,10266]
operator: , [10265,10266]
===
match
---
trailer [18684,18719]
trailer [18684,18719]
===
match
---
trailer [9473,9484]
trailer [9473,9484]
===
match
---
string: "name" [20432,20438]
string: "name" [20432,20438]
===
match
---
dictorsetmaker [5137,5149]
dictorsetmaker [5137,5149]
===
match
---
argument [7398,7425]
argument [7398,7425]
===
match
---
parameters [17032,17038]
parameters [17032,17038]
===
match
---
name: metadata [10552,10560]
name: metadata [10552,10560]
===
match
---
operator: = [19484,19485]
operator: = [19484,19485]
===
match
---
atom_expr [12650,12667]
atom_expr [12650,12667]
===
match
---
operator: , [23358,23359]
operator: , [23358,23359]
===
match
---
name: in_cluster [17342,17352]
name: in_cluster [17342,17352]
===
match
---
operator: , [2556,2557]
operator: , [2556,2557]
===
match
---
trailer [4931,4940]
trailer [4931,4940]
===
match
---
operator: , [20093,20094]
operator: , [20093,20094]
===
match
---
argument [8828,8839]
argument [8828,8839]
===
match
---
atom_expr [7038,7436]
atom_expr [7038,7436]
===
match
---
dictorsetmaker [19557,19569]
dictorsetmaker [19557,19569]
===
match
---
string: "-cx" [16075,16080]
string: "-cx" [16075,16080]
===
match
---
name: self [1818,1822]
name: self [1818,1822]
===
match
---
argument [14890,14904]
argument [14890,14904]
===
match
---
name: image [20936,20941]
name: image [20936,20941]
===
match
---
operator: = [21078,21079]
operator: = [21078,21079]
===
match
---
name: self [17033,17037]
name: self [17033,17037]
===
match
---
string: "kubernetes_pod_operator" [15665,15690]
string: "kubernetes_pod_operator" [15665,15690]
===
match
---
name: sanitize_for_serialization [2776,2802]
name: sanitize_for_serialization [2776,2802]
===
match
---
name: k8s [20770,20773]
name: k8s [20770,20773]
===
match
---
operator: , [5797,5798]
operator: , [5797,5798]
===
match
---
simple_stmt [23069,23131]
simple_stmt [23069,23131]
===
match
---
string: "-cx" [17196,17201]
string: "-cx" [17196,17201]
===
match
---
simple_stmt [19828,19881]
simple_stmt [19828,19881]
===
match
---
operator: = [8475,8476]
operator: = [8475,8476]
===
match
---
string: "foo" [15568,15573]
string: "foo" [15568,15573]
===
match
---
operator: = [4468,4469]
operator: = [4468,4469]
===
match
---
string: "bar" [21803,21808]
string: "bar" [21803,21808]
===
match
---
name: k [17076,17077]
name: k [17076,17077]
===
match
---
argument [21004,21025]
argument [21004,21025]
===
match
---
name: k [7034,7035]
name: k [7034,7035]
===
match
---
operator: , [8379,8380]
operator: , [8379,8380]
===
match
---
string: "bar" [3076,3081]
string: "bar" [3076,3081]
===
match
---
operator: , [1024,1025]
operator: , [1024,1025]
===
match
---
name: patch [6870,6875]
name: patch [6870,6875]
===
match
---
operator: = [17321,17322]
operator: = [17321,17322]
===
match
---
trailer [21399,21442]
trailer [21399,21442]
===
match
---
operator: = [1835,1836]
operator: = [1835,1836]
===
match
---
operator: = [17724,17725]
operator: = [17724,17725]
===
match
---
name: create_pod_request_obj [20633,20655]
name: create_pod_request_obj [20633,20655]
===
match
---
atom [7184,7195]
atom [7184,7195]
===
match
---
simple_stmt [10587,10632]
simple_stmt [10587,10632]
===
match
---
atom [16763,16907]
atom [16763,16907]
===
match
---
argument [20256,20275]
argument [20256,20275]
===
match
---
string: "task" [6591,6597]
string: "task" [6591,6597]
===
match
---
trailer [16784,16790]
trailer [16784,16790]
===
match
---
trailer [6053,6076]
trailer [6053,6076]
===
match
---
simple_stmt [7726,7745]
simple_stmt [7726,7745]
===
match
---
operator: , [18412,18413]
operator: , [18412,18413]
===
match
---
trailer [13163,13172]
trailer [13163,13172]
===
match
---
name: self [1328,1332]
name: self [1328,1332]
===
match
---
argument [18300,18321]
argument [18300,18321]
===
match
---
name: context [2572,2579]
name: context [2572,2579]
===
match
---
trailer [3376,3396]
trailer [3376,3396]
===
match
---
name: k [23735,23736]
name: k [23735,23736]
===
match
---
name: to_dict [14687,14694]
name: to_dict [14687,14694]
===
match
---
name: pod [23875,23878]
name: pod [23875,23878]
===
match
---
name: create_pod_request_obj [6766,6788]
name: create_pod_request_obj [6766,6788]
===
match
---
operator: = [21661,21662]
operator: = [21661,21662]
===
match
---
name: k [9237,9238]
name: k [9237,9238]
===
match
---
name: pod [19876,19879]
name: pod [19876,19879]
===
match
---
simple_stmt [6348,6750]
simple_stmt [6348,6750]
===
match
---
operator: , [15647,15648]
operator: , [15647,15648]
===
match
---
name: namespace [19413,19422]
name: namespace [19413,19422]
===
match
---
atom_expr [2890,3282]
atom_expr [2890,3282]
===
match
---
operator: = [10121,10122]
operator: = [10121,10122]
===
match
---
name: DAG [1013,1016]
name: DAG [1013,1016]
===
match
---
name: pod [6203,6206]
name: pod [6203,6206]
===
match
---
testlist_comp [22574,22587]
testlist_comp [22574,22587]
===
match
---
operator: = [3633,3634]
operator: = [3633,3634]
===
match
---
name: image [16027,16032]
name: image [16027,16032]
===
match
---
dictorsetmaker [13703,13924]
dictorsetmaker [13703,13924]
===
match
---
trailer [2911,3282]
trailer [2911,3282]
===
match
---
operator: , [8445,8446]
operator: , [8445,8446]
===
match
---
string: "1" [15765,15768]
string: "1" [15765,15768]
===
match
---
name: ctx [16781,16784]
name: ctx [16781,16784]
===
match
---
name: ANY [9898,9901]
name: ANY [9898,9901]
===
match
---
operator: , [7283,7284]
operator: , [7283,7284]
===
match
---
atom_expr [20803,20839]
atom_expr [20803,20839]
===
match
---
name: cmds [5811,5815]
name: cmds [5811,5815]
===
match
---
operator: , [3963,3964]
operator: , [3963,3964]
===
match
---
operator: = [17751,17752]
operator: = [17751,17752]
===
match
---
string: "hello" [12671,12678]
string: "hello" [12671,12678]
===
match
---
testlist_comp [7146,7159]
testlist_comp [7146,7159]
===
match
---
operator: { [22652,22653]
operator: { [22652,22653]
===
match
---
name: k8s_api_tolerations [20044,20063]
name: k8s_api_tolerations [20044,20063]
===
match
---
atom_expr [17449,17479]
atom_expr [17449,17479]
===
match
---
operator: , [22580,22581]
operator: , [22580,22581]
===
match
---
trailer [20765,20768]
trailer [20765,20768]
===
match
---
atom_expr [16720,16746]
atom_expr [16720,16746]
===
match
---
name: k [6764,6765]
name: k [6764,6765]
===
match
---
trailer [5014,5276]
trailer [5014,5276]
===
match
---
name: labels [9686,9692]
name: labels [9686,9692]
===
match
---
operator: = [23676,23677]
operator: = [23676,23677]
===
match
---
name: monitor_mock [16390,16402]
name: monitor_mock [16390,16402]
===
match
---
argument [3583,3608]
argument [3583,3608]
===
match
---
trailer [2073,2087]
trailer [2073,2087]
===
match
---
simple_stmt [13278,13338]
simple_stmt [13278,13338]
===
match
---
string: "True" [12960,12966]
string: "True" [12960,12966]
===
match
---
simple_stmt [16720,16747]
simple_stmt [16720,16747]
===
match
---
string: "foo" [3950,3955]
string: "foo" [3950,3955]
===
match
---
trailer [10794,10803]
trailer [10794,10803]
===
match
---
name: image [5777,5782]
name: image [5777,5782]
===
match
---
atom_expr [20770,20786]
atom_expr [20770,20786]
===
match
---
string: "ubuntu:16.04" [6426,6440]
string: "ubuntu:16.04" [6426,6440]
===
match
---
string: "task" [9055,9061]
string: "task" [9055,9061]
===
match
---
name: cmds [18266,18270]
name: cmds [18266,18270]
===
match
---
name: V1Affinity [18813,18823]
name: V1Affinity [18813,18823]
===
match
---
atom_expr [9893,9901]
atom_expr [9893,9901]
===
match
---
param [2737,2742]
param [2737,2742]
===
match
---
name: NamedTemporaryFile [822,840]
name: NamedTemporaryFile [822,840]
===
match
---
operator: { [13486,13487]
operator: { [13486,13487]
===
match
---
name: V1Pod [2488,2493]
name: V1Pod [2488,2493]
===
match
---
trailer [17623,17636]
trailer [17623,17636]
===
match
---
operator: == [4941,4943]
operator: == [4941,4943]
===
match
---
operator: { [10814,10815]
operator: { [10814,10815]
===
match
---
operator: , [2134,2135]
operator: , [2134,2135]
===
match
---
string: "task" [5197,5203]
string: "task" [5197,5203]
===
match
---
operator: , [19225,19226]
operator: , [19225,19226]
===
match
---
operator: , [2944,2945]
operator: , [2944,2945]
===
match
---
argument [3891,3907]
argument [3891,3907]
===
match
---
expr_stmt [2167,2249]
expr_stmt [2167,2249]
===
match
---
name: task_id [4002,4009]
name: task_id [4002,4009]
===
match
---
operator: , [22840,22841]
operator: , [22840,22841]
===
match
---
trailer [18572,18595]
trailer [18572,18595]
===
match
---
operator: = [14825,14826]
operator: = [14825,14826]
===
match
---
operator: = [16589,16590]
operator: = [16589,16590]
===
match
---
argument [12517,12531]
argument [12517,12531]
===
match
---
parameters [21537,21543]
parameters [21537,21543]
===
match
---
name: labels [16130,16136]
name: labels [16130,16136]
===
match
---
operator: = [1500,1501]
operator: = [1500,1501]
===
match
---
simple_stmt [20217,20616]
simple_stmt [20217,20616]
===
match
---
string: 'bar' [14359,14364]
string: 'bar' [14359,14364]
===
match
---
operator: , [14400,14401]
operator: , [14400,14401]
===
match
---
name: k [7754,7755]
name: k [7754,7755]
===
match
---
comparison [15318,15355]
comparison [15318,15355]
===
match
---
trailer [22211,22227]
trailer [22211,22227]
===
match
---
name: k8s [8626,8629]
name: k8s [8626,8629]
===
match
---
simple_stmt [4349,4384]
simple_stmt [4349,4384]
===
match
---
testlist_comp [17188,17201]
testlist_comp [17188,17201]
===
match
---
operator: = [20118,20119]
operator: = [20118,20119]
===
match
---
simple_stmt [21280,21313]
simple_stmt [21280,21313]
===
match
---
simple_stmt [1132,1167]
simple_stmt [1132,1167]
===
match
---
string: "task" [2347,2353]
string: "task" [2347,2353]
===
match
---
string: "task" [14898,14904]
string: "task" [14898,14904]
===
match
---
name: ti [23538,23540]
name: ti [23538,23540]
===
match
---
operator: = [23289,23290]
operator: = [23289,23290]
===
match
---
name: KubernetesPodOperator [14851,14872]
name: KubernetesPodOperator [14851,14872]
===
match
---
name: KubernetesPodOperator [9012,9033]
name: KubernetesPodOperator [9012,9033]
===
match
---
operator: = [4620,4621]
operator: = [4620,4621]
===
match
---
atom_expr [1871,1909]
atom_expr [1871,1909]
===
match
---
operator: , [18218,18219]
operator: , [18218,18219]
===
match
---
name: metadata [8131,8139]
name: metadata [8131,8139]
===
match
---
atom_expr [23446,23461]
atom_expr [23446,23461]
===
match
---
atom [18271,18286]
atom [18271,18286]
===
match
---
name: startswith [15227,15237]
name: startswith [15227,15237]
===
match
---
operator: { [15550,15551]
operator: { [15550,15551]
===
match
---
trailer [10597,10602]
trailer [10597,10602]
===
match
---
atom [19234,19241]
atom [19234,19241]
===
match
---
string: "task" [7896,7902]
string: "task" [7896,7902]
===
match
---
name: self [1481,1485]
name: self [1481,1485]
===
match
---
string: "1" [9857,9860]
string: "1" [9857,9860]
===
match
---
string: "test" [5169,5175]
string: "test" [5169,5175]
===
match
---
atom_expr [2764,2807]
atom_expr [2764,2807]
===
match
---
operator: = [7111,7112]
operator: = [7111,7112]
===
match
---
expr_stmt [13475,14648]
expr_stmt [13475,14648]
===
match
---
argument [8680,8703]
argument [8680,8703]
===
match
---
comparison [21458,21509]
comparison [21458,21509]
===
match
---
argument [15994,16013]
argument [15994,16013]
===
match
---
number: 0 [4205,4206]
number: 0 [4205,4206]
===
match
---
atom_expr [16836,16855]
atom_expr [16836,16855]
===
match
---
string: "bash" [7146,7152]
string: "bash" [7146,7152]
===
match
---
name: DEFAULT_DATE [1206,1218]
name: DEFAULT_DATE [1206,1218]
===
match
---
name: labels [3061,3067]
name: labels [3061,3067]
===
match
---
name: client_patch [1842,1854]
name: client_patch [1842,1854]
===
match
---
operator: = [3563,3564]
operator: = [3563,3564]
===
match
---
param [3678,3682]
param [3678,3682]
===
match
---
atom [13521,14552]
atom [13521,14552]
===
match
---
expr_stmt [2572,2611]
expr_stmt [2572,2611]
===
match
---
name: spec [21404,21408]
name: spec [21404,21408]
===
match
---
simple_stmt [2096,2159]
simple_stmt [2096,2159]
===
match
---
name: task_id [14890,14897]
name: task_id [14890,14897]
===
match
---
argument [19017,19025]
argument [19017,19025]
===
match
---
trailer [11085,11089]
trailer [11085,11089]
===
match
---
operator: , [19466,19467]
operator: , [19466,19467]
===
match
---
name: k [23662,23663]
name: k [23662,23663]
===
match
---
argument [3909,3926]
argument [3909,3926]
===
match
---
operator: = [8722,8723]
operator: = [8722,8723]
===
match
---
name: test_config_path [2817,2833]
name: test_config_path [2817,2833]
===
match
---
name: test_full_pod_spec [8549,8567]
name: test_full_pod_spec [8549,8567]
===
match
---
simple_stmt [19787,19820]
simple_stmt [19787,19820]
===
match
---
name: affinity [14678,14686]
name: affinity [14678,14686]
===
match
---
name: DEFAULT_DATE [2309,2321]
name: DEFAULT_DATE [2309,2321]
===
match
---
argument [8242,8268]
argument [8242,8268]
===
match
---
trailer [19065,19084]
trailer [19065,19084]
===
match
---
name: operator [20095,20103]
name: operator [20095,20103]
===
match
---
atom_expr [23662,23671]
atom_expr [23662,23671]
===
match
---
name: dag [2286,2289]
name: dag [2286,2289]
===
match
---
string: "echo 10" [6499,6508]
string: "echo 10" [6499,6508]
===
match
---
trailer [12406,12412]
trailer [12406,12412]
===
match
---
name: k [14847,14848]
name: k [14847,14848]
===
match
---
name: airflow [1172,1179]
name: airflow [1172,1179]
===
match
---
atom_expr [19378,19777]
atom_expr [19378,19777]
===
match
---
string: "test-config-map" [4366,4383]
string: "test-config-map" [4366,4383]
===
match
---
operator: , [18085,18086]
operator: , [18085,18086]
===
match
---
atom_expr [3325,3338]
atom_expr [3325,3338]
===
match
---
fstring_string:  returned a failure:  [16856,16877]
fstring_string:  returned a failure:  [16856,16877]
===
match
---
atom [16137,16151]
atom [16137,16151]
===
match
---
name: in_cluster [10142,10152]
name: in_cluster [10142,10152]
===
match
---
operator: , [20378,20379]
operator: , [20378,20379]
===
match
---
atom_expr [9277,9299]
atom_expr [9277,9299]
===
match
---
name: ANY [9938,9941]
name: ANY [9938,9941]
===
match
---
expr_stmt [1763,1809]
expr_stmt [1763,1809]
===
match
---
name: self [8190,8194]
name: self [8190,8194]
===
match
---
atom_expr [19844,19880]
atom_expr [19844,19880]
===
match
---
name: cmds [19480,19484]
name: cmds [19480,19484]
===
match
---
trailer [16931,16943]
trailer [16931,16943]
===
match
---
operator: , [9091,9092]
operator: , [9091,9092]
===
match
---
name: in_cluster [7916,7926]
name: in_cluster [7916,7926]
===
match
---
argument [2992,3012]
argument [2992,3012]
===
match
---
operator: , [20922,20923]
operator: , [20922,20923]
===
match
---
trailer [18756,18768]
trailer [18756,18768]
===
match
---
atom_expr [18809,19364]
atom_expr [18809,19364]
===
match
---
string: "hello" [10340,10347]
string: "hello" [10340,10347]
===
match
---
name: arguments [21753,21762]
name: arguments [21753,21762]
===
match
---
argument [7269,7283]
argument [7269,7283]
===
match
---
trailer [1302,1311]
trailer [1302,1311]
===
match
---
expr_stmt [14815,14834]
expr_stmt [14815,14834]
===
match
---
trailer [23097,23113]
trailer [23097,23113]
===
match
---
dictorsetmaker [15568,15858]
dictorsetmaker [15568,15858]
===
match
---
name: sanitized_pod [22190,22203]
name: sanitized_pod [22190,22203]
===
match
---
atom_expr [22454,22901]
atom_expr [22454,22901]
===
match
---
trailer [1485,1499]
trailer [1485,1499]
===
match
---
atom_expr [1712,1727]
atom_expr [1712,1727]
===
match
---
string: "ubuntu:16.04" [19452,19466]
string: "ubuntu:16.04" [19452,19466]
===
match
---
trailer [9259,9268]
trailer [9259,9268]
===
match
---
string: "mynamespace" [8690,8703]
string: "mynamespace" [8690,8703]
===
match
---
operator: } [18107,18108]
operator: } [18107,18108]
===
match
---
name: labels [21788,21794]
name: labels [21788,21794]
===
match
---
name: namespace [9328,9337]
name: namespace [9328,9337]
===
match
---
assert_stmt [4902,4952]
assert_stmt [4902,4952]
===
match
---
argument [8865,8885]
argument [8865,8885]
===
match
---
fstring_end: " [16896,16897]
fstring_end: " [16896,16897]
===
match
---
operator: , [20982,20983]
operator: , [20982,20983]
===
match
---
trailer [2520,2533]
trailer [2520,2533]
===
match
---
name: labels [8657,8663]
name: labels [8657,8663]
===
match
---
atom [21795,21809]
atom [21795,21809]
===
match
---
simple_stmt [2757,2808]
simple_stmt [2757,2808]
===
match
---
name: task [2049,2053]
name: task [2049,2053]
===
match
---
operator: = [8404,8405]
operator: = [8404,8405]
===
match
---
operator: = [14849,14850]
operator: = [14849,14850]
===
match
---
atom_expr [4194,4213]
atom_expr [4194,4213]
===
match
---
name: labels [10332,10338]
name: labels [10332,10338]
===
match
---
name: cmds [5095,5099]
name: cmds [5095,5099]
===
match
---
name: obj [2803,2806]
name: obj [2803,2806]
===
match
---
arglist [8617,8988]
arglist [8617,8988]
===
match
---
operator: = [6396,6397]
operator: = [6396,6397]
===
match
---
operator: == [5342,5344]
operator: == [5342,5344]
===
match
---
operator: = [2859,2860]
operator: = [2859,2860]
===
match
---
operator: = [2235,2236]
operator: = [2235,2236]
===
match
---
argument [17286,17300]
argument [17286,17300]
===
match
---
string: "task" [18406,18412]
string: "task" [18406,18412]
===
match
---
operator: = [2934,2935]
operator: = [2934,2935]
===
match
---
name: V1Toleration [21429,21441]
name: V1Toleration [21429,21441]
===
match
---
name: pod [12608,12611]
name: pod [12608,12611]
===
match
---
name: affinity [14700,14708]
name: affinity [14700,14708]
===
match
---
atom_expr [3464,3490]
atom_expr [3464,3490]
===
match
---
atom [3804,3819]
atom [3804,3819]
===
match
---
name: pod_spec [9341,9349]
name: pod_spec [9341,9349]
===
match
---
name: name [3891,3895]
name: name [3891,3895]
===
match
---
simple_stmt [17048,17067]
simple_stmt [17048,17067]
===
match
---
operator: = [3895,3896]
operator: = [3895,3896]
===
match
---
operator: , [21892,21893]
operator: , [21892,21893]
===
match
---
atom [14121,14533]
atom [14121,14533]
===
match
---
name: k8s [4439,4442]
name: k8s [4439,4442]
===
match
---
name: task_id [5940,5947]
name: task_id [5940,5947]
===
match
---
operator: = [23502,23503]
operator: = [23502,23503]
===
match
---
simple_stmt [868,882]
simple_stmt [868,882]
===
match
---
trailer [20773,20786]
trailer [20773,20786]
===
match
---
name: image [3765,3770]
name: image [3765,3770]
===
match
---
name: addCleanup [1972,1982]
name: addCleanup [1972,1982]
===
match
---
name: containers [4918,4928]
name: containers [4918,4928]
===
match
---
argument [6454,6474]
argument [6454,6474]
===
match
---
argument [8359,8379]
argument [8359,8379]
===
match
---
operator: , [6544,6545]
operator: , [6544,6545]
===
match
---
argument [4060,4078]
argument [4060,4078]
===
match
---
trailer [23089,23097]
trailer [23089,23097]
===
match
---
operator: == [6231,6233]
operator: == [6231,6233]
===
match
---
operator: = [7144,7145]
operator: = [7144,7145]
===
match
---
trailer [16424,16431]
trailer [16424,16431]
===
match
---
name: task [2125,2129]
name: task [2125,2129]
===
match
---
atom_expr [18164,18555]
atom_expr [18164,18555]
===
match
---
simple_stmt [1871,1910]
simple_stmt [1871,1910]
===
match
---
funcdef [6959,7678]
funcdef [6959,7678]
===
match
---
arglist [2925,3272]
arglist [2925,3272]
===
match
---
arglist [15994,16309]
arglist [15994,16309]
===
match
---
name: spec [13289,13293]
name: spec [13289,13293]
===
match
---
name: KubernetesPodOperator [10079,10100]
name: KubernetesPodOperator [10079,10100]
===
match
---
name: self [1967,1971]
name: self [1967,1971]
===
match
---
string: "world" [15607,15614]
string: "world" [15607,15614]
===
match
---
name: affinity [18536,18544]
name: affinity [18536,18544]
===
match
---
name: k8s [6235,6238]
name: k8s [6235,6238]
===
match
---
trailer [7582,7597]
trailer [7582,7597]
===
match
---
param [2465,2470]
param [2465,2470]
===
match
---
simple_stmt [12608,12630]
simple_stmt [12608,12630]
===
match
---
operator: = [15038,15039]
operator: = [15038,15039]
===
match
---
operator: = [7864,7865]
operator: = [7864,7865]
===
match
---
atom [13599,14044]
atom [13599,14044]
===
match
---
argument [5247,5265]
argument [5247,5265]
===
match
---
expr_stmt [5285,5306]
expr_stmt [5285,5306]
===
match
---
expr_stmt [2096,2158]
expr_stmt [2096,2158]
===
match
---
name: k8s [21425,21428]
name: k8s [21425,21428]
===
match
---
simple_stmt [20796,20855]
simple_stmt [20796,20855]
===
match
---
name: read_namespaced_pod [16523,16542]
name: read_namespaced_pod [16523,16542]
===
match
---
atom_expr [10791,10810]
atom_expr [10791,10810]
===
match
---
operator: , [4568,4569]
operator: , [4568,4569]
===
match
---
name: DAG [2070,2073]
name: DAG [2070,2073]
===
match
---
operator: = [3431,3432]
operator: = [3431,3432]
===
match
---
name: delete_pod_mock [7008,7023]
name: delete_pod_mock [7008,7023]
===
match
---
string: "task" [7277,7283]
string: "task" [7277,7283]
===
match
---
name: stop [1953,1957]
name: stop [1953,1957]
===
match
---
name: client_mock [16498,16509]
name: client_mock [16498,16509]
===
match
---
string: "default" [17125,17134]
string: "default" [17125,17134]
===
match
---
name: isinstance [23020,23030]
name: isinstance [23020,23030]
===
match
---
argument [17251,17272]
argument [17251,17272]
===
match
---
name: cluster_context [9137,9152]
name: cluster_context [9137,9152]
===
match
---
name: return_value [3397,3409]
name: return_value [3397,3409]
===
match
---
operator: , [4016,4017]
operator: , [4016,4017]
===
match
---
string: "`name` is required" [8248,8268]
string: "`name` is required" [8248,8268]
===
match
---
string: "foo" [4132,4137]
string: "foo" [4132,4137]
===
match
---
name: create_context [2587,2601]
name: create_context [2587,2601]
===
match
---
name: metadata [8617,8625]
name: metadata [8617,8625]
===
match
---
operator: , [19924,19925]
operator: , [19924,19925]
===
match
---
name: return_value [16944,16956]
name: return_value [16944,16956]
===
match
---
trailer [2586,2601]
trailer [2586,2601]
===
match
---
name: tempfile [806,814]
name: tempfile [806,814]
===
match
---
operator: , [23237,23238]
operator: , [23237,23238]
===
match
---
name: metadata [15272,15280]
name: metadata [15272,15280]
===
match
---
operator: , [23671,23672]
operator: , [23671,23672]
===
match
---
operator: = [23492,23493]
operator: = [23492,23493]
===
match
---
name: name_base [8148,8157]
name: name_base [8148,8157]
===
match
---
assert_stmt [10541,10578]
assert_stmt [10541,10578]
===
match
---
operator: = [4691,4692]
operator: = [4691,4692]
===
match
---
operator: { [5887,5888]
operator: { [5887,5888]
===
match
---
string: "bar" [19564,19569]
string: "bar" [19564,19569]
===
match
---
operator: = [7036,7037]
operator: = [7036,7037]
===
match
---
argument [7073,7092]
argument [7073,7092]
===
match
---
argument [21848,21862]
argument [21848,21862]
===
match
---
operator: == [13388,13390]
operator: == [13388,13390]
===
match
---
name: task_id [21099,21106]
name: task_id [21099,21106]
===
match
---
name: pod [4872,4875]
name: pod [4872,4875]
===
match
---
funcdef [5607,6287]
funcdef [5607,6287]
===
match
---
atom_expr [23551,23620]
atom_expr [23551,23620]
===
match
---
operator: == [10811,10813]
operator: == [10811,10813]
===
match
---
number: 0 [1257,1258]
number: 0 [1257,1258]
===
match
---
name: run_pod [10388,10395]
name: run_pod [10388,10395]
===
match
---
argument [5968,5984]
argument [5968,5984]
===
match
---
dictorsetmaker [10828,11090]
dictorsetmaker [10828,11090]
===
match
---
name: timezone [1221,1229]
name: timezone [1221,1229]
===
match
---
operator: = [21284,21285]
operator: = [21284,21285]
===
match
---
number: 1 [13994,13995]
number: 1 [13994,13995]
===
match
---
name: pod [21280,21283]
name: pod [21280,21283]
===
match
---
name: tpl_file [12444,12452]
name: tpl_file [12444,12452]
===
match
---
trailer [19084,19298]
trailer [19084,19298]
===
match
---
name: mock [15805,15809]
name: mock [15805,15809]
===
match
---
funcdef [8545,11101]
funcdef [8545,11101]
===
match
---
simple_stmt [23470,23530]
simple_stmt [23470,23530]
===
match
---
name: k8s [20067,20070]
name: k8s [20067,20070]
===
match
---
argument [21788,21809]
argument [21788,21809]
===
match
---
name: mock [6865,6869]
name: mock [6865,6869]
===
match
---
operator: = [5815,5816]
operator: = [5815,5816]
===
match
---
operator: , [21705,21706]
operator: , [21705,21706]
===
match
---
trailer [9358,9368]
trailer [9358,9368]
===
match
---
operator: = [19650,19651]
operator: = [19650,19651]
===
match
---
trailer [1801,1807]
trailer [1801,1807]
===
match
---
string: "echo 10" [22617,22626]
string: "echo 10" [22617,22626]
===
match
---
operator: } [14551,14552]
operator: } [14551,14552]
===
match
---
operator: } [19569,19570]
operator: } [19569,19570]
===
match
---
operator: = [8364,8365]
operator: = [8364,8365]
===
match
---
trailer [13241,13247]
trailer [13241,13247]
===
match
---
string: "world" [15049,15056]
string: "world" [15049,15056]
===
match
---
name: mock [9893,9897]
name: mock [9893,9897]
===
match
---
expr_stmt [16466,16542]
expr_stmt [16466,16542]
===
match
---
string: "foo" [5137,5142]
string: "foo" [5137,5142]
===
match
---
name: preference [19051,19061]
name: preference [19051,19061]
===
match
---
comparison [23795,23824]
comparison [23795,23824]
===
match
---
trailer [16575,16588]
trailer [16575,16588]
===
match
---
trailer [3308,3321]
trailer [3308,3321]
===
match
---
string: "tolerations" [21480,21493]
string: "tolerations" [21480,21493]
===
match
---
name: startswith [8090,8100]
name: startswith [8090,8100]
===
match
---
name: in_cluster [19640,19650]
name: in_cluster [19640,19650]
===
match
---
simple_stmt [21321,21374]
simple_stmt [21321,21374]
===
match
---
name: mock [11081,11085]
name: mock [11081,11085]
===
match
---
operator: = [14897,14898]
operator: = [14897,14898]
===
match
---
name: providers [1052,1061]
name: providers [1052,1061]
===
match
---
operator: = [2888,2889]
operator: = [2888,2889]
===
match
---
trailer [7670,7677]
trailer [7670,7677]
===
match
---
string: "affinity" [18757,18767]
string: "affinity" [18757,18767]
===
match
---
operator: = [16200,16201]
operator: = [16200,16201]
===
match
---
with_item [16623,16661]
with_item [16623,16661]
===
match
---
operator: , [17202,17203]
operator: , [17202,17203]
===
match
---
operator: , [14953,14954]
operator: , [14953,14954]
===
match
---
operator: == [23872,23874]
operator: == [23872,23874]
===
match
---
simple_stmt [15520,15873]
simple_stmt [15520,15873]
===
match
---
trailer [2697,2700]
trailer [2697,2700]
===
match
---
assert_stmt [23069,23130]
assert_stmt [23069,23130]
===
match
---
name: cluster_context [7978,7993]
name: cluster_context [7978,7993]
===
match
---
operator: = [8514,8515]
operator: = [8514,8515]
===
match
---
atom [14200,14485]
atom [14200,14485]
===
match
---
atom_expr [8072,8111]
atom_expr [8072,8111]
===
match
---
atom_expr [17560,17586]
atom_expr [17560,17586]
===
match
---
name: pod_spec [8583,8591]
name: pod_spec [8583,8591]
===
match
---
operator: == [20840,20842]
operator: == [20840,20842]
===
match
---
trailer [8223,8269]
trailer [8223,8269]
===
match
---
name: name_base [15927,15936]
name: name_base [15927,15936]
===
match
---
trailer [16841,16850]
trailer [16841,16850]
===
match
---
trailer [1746,1752]
trailer [1746,1752]
===
match
---
name: self [1934,1938]
name: self [1934,1938]
===
match
---
assert_stmt [15202,15248]
assert_stmt [15202,15248]
===
match
---
string: "execution_date" [15831,15847]
string: "execution_date" [15831,15847]
===
match
---
name: in_cluster [4773,4783]
name: in_cluster [4773,4783]
===
match
---
operator: = [21013,21014]
operator: = [21013,21014]
===
match
---
name: name [17286,17290]
name: name [17286,17290]
===
match
---
argument [22493,22512]
argument [22493,22512]
===
match
---
trailer [22918,22941]
trailer [22918,22941]
===
match
---
name: self [4878,4882]
name: self [4878,4882]
===
match
---
name: KubernetesPodOperator [20868,20889]
name: KubernetesPodOperator [20868,20889]
===
match
---
argument [21189,21214]
argument [21189,21214]
===
match
---
operator: = [20064,20065]
operator: = [20064,20065]
===
match
---
expr_stmt [18565,18597]
expr_stmt [18565,18597]
===
match
---
operator: = [16263,16264]
operator: = [16263,16264]
===
match
---
arglist [23726,23765]
arglist [23726,23765]
===
match
---
atom_expr [16623,16654]
atom_expr [16623,16654]
===
match
---
argument [18232,18252]
argument [18232,18252]
===
match
---
operator: , [13826,13827]
operator: , [13826,13827]
===
match
---
argument [8499,8524]
argument [8499,8524]
===
match
---
name: k8s [18851,18854]
name: k8s [18851,18854]
===
match
---
param [2743,2746]
param [2743,2746]
===
match
---
name: delete_pod_mock [7655,7670]
name: delete_pod_mock [7655,7670]
===
match
---
name: mock [15849,15853]
name: mock [15849,15853]
===
match
---
trailer [19848,19875]
trailer [19848,19875]
===
match
---
name: in_cluster [22745,22755]
name: in_cluster [22745,22755]
===
match
---
trailer [6238,6261]
trailer [6238,6261]
===
match
---
atom_expr [7613,7639]
atom_expr [7613,7639]
===
match
---
name: labels [15540,15546]
name: labels [15540,15546]
===
match
---
name: dag_run [23541,23548]
name: dag_run [23541,23548]
===
match
---
trailer [13288,13293]
trailer [13288,13293]
===
match
---
name: pod [20745,20748]
name: pod [20745,20748]
===
match
---
operator: { [5345,5346]
operator: { [5345,5346]
===
match
---
simple_stmt [18606,18659]
simple_stmt [18606,18659]
===
match
---
operator: = [2110,2111]
operator: = [2110,2111]
===
match
---
string: "ubuntu:16.04" [21691,21705]
string: "ubuntu:16.04" [21691,21705]
===
match
---
name: TaskInstance [23475,23487]
name: TaskInstance [23475,23487]
===
match
---
operator: , [18278,18279]
operator: , [18278,18279]
===
match
---
dictorsetmaker [3069,3081]
dictorsetmaker [3069,3081]
===
match
---
operator: == [19991,19993]
operator: == [19991,19993]
===
match
---
expr_stmt [3291,3351]
expr_stmt [3291,3351]
===
match
---
operator: , [9751,9752]
operator: , [9751,9752]
===
match
---
string: "default" [7994,8003]
string: "default" [7994,8003]
===
match
---
trailer [13222,13227]
trailer [13222,13227]
===
match
---
argument [7209,7230]
argument [7209,7230]
===
match
---
name: weight [19017,19023]
name: weight [19017,19023]
===
match
---
name: dict [23055,23059]
name: dict [23055,23059]
===
match
---
name: namespace [8680,8689]
name: namespace [8680,8689]
===
match
---
trailer [12412,12431]
trailer [12412,12431]
===
match
---
operator: = [18468,18469]
operator: = [18468,18469]
===
match
---
expr_stmt [1206,1259]
expr_stmt [1206,1259]
===
match
---
operator: = [18309,18310]
operator: = [18309,18310]
===
match
---
atom [8919,8932]
atom [8919,8932]
===
match
---
suite [1334,2007]
suite [1334,2007]
===
match
---
expr_stmt [20044,20128]
expr_stmt [20044,20128]
===
match
---
operator: , [9162,9163]
operator: , [9162,9163]
===
match
---
string: "dag" [2279,2284]
string: "dag" [2279,2284]
===
match
---
argument [16061,16081]
argument [16061,16081]
===
match
---
atom [20399,20413]
atom [20399,20413]
===
match
---
atom_expr [8210,8269]
atom_expr [8210,8269]
===
match
---
simple_stmt [12398,12432]
simple_stmt [12398,12432]
===
match
---
atom [17753,18150]
atom [17753,18150]
===
match
---
expr_stmt [9218,9239]
expr_stmt [9218,9239]
===
match
---
operator: = [6728,6729]
operator: = [6728,6729]
===
match
---
dictorsetmaker [4693,4705]
dictorsetmaker [4693,4705]
===
match
---
name: pod_namespace [23840,23853]
name: pod_namespace [23840,23853]
===
match
---
operator: = [20557,20558]
operator: = [20557,20558]
===
match
---
name: metadata [5326,5334]
name: metadata [5326,5334]
===
match
---
assert_stmt [9458,9534]
assert_stmt [9458,9534]
===
match
---
operator: , [10158,10159]
operator: , [10158,10159]
===
match
---
operator: = [20327,20328]
operator: = [20327,20328]
===
match
---
atom_expr [3697,4089]
atom_expr [3697,4089]
===
match
---
expr_stmt [9008,9209]
expr_stmt [9008,9209]
===
match
---
simple_stmt [785,801]
simple_stmt [785,801]
===
match
---
expr_stmt [21613,22015]
expr_stmt [21613,22015]
===
match
---
name: isinstance [20734,20744]
name: isinstance [20734,20744]
===
match
---
funcdef [4289,4953]
funcdef [4289,4953]
===
match
---
simple_stmt [2849,2878]
simple_stmt [2849,2878]
===
match
---
operator: } [5600,5601]
operator: } [5600,5601]
===
match
---
operator: = [7630,7631]
operator: = [7630,7631]
===
match
---
operator: , [14552,14553]
operator: , [14552,14553]
===
match
---
assert_stmt [20727,20787]
assert_stmt [20727,20787]
===
match
---
arglist [7793,8004]
arglist [7793,8004]
===
match
---
string: "ssd" [18051,18056]
string: "ssd" [18051,18056]
===
match
---
simple_stmt [19950,20003]
simple_stmt [19950,20003]
===
match
---
atom_expr [2191,2249]
atom_expr [2191,2249]
===
match
---
comparison [13357,13404]
comparison [13357,13404]
===
match
---
name: namespace [9359,9368]
name: namespace [9359,9368]
===
match
---
trailer [23034,23039]
trailer [23034,23039]
===
match
---
name: env_vars [4196,4204]
name: env_vars [4196,4204]
===
match
---
operator: = [16032,16033]
operator: = [16032,16033]
===
match
---
trailer [15221,15226]
trailer [15221,15226]
===
match
---
operator: , [18384,18385]
operator: , [18384,18385]
===
match
---
argument [7106,7126]
argument [7106,7126]
===
match
---
assert_stmt [23775,23824]
assert_stmt [23775,23824]
===
match
---
name: image [14768,14773]
name: image [14768,14773]
===
match
---
suite [8270,8540]
suite [8270,8540]
===
match
---
atom_expr [8626,8704]
atom_expr [8626,8704]
===
match
---
operator: , [6406,6407]
operator: , [6406,6407]
===
match
---
string: "task" [9823,9829]
string: "task" [9823,9829]
===
match
---
operator: , [13808,13809]
operator: , [13808,13809]
===
match
---
atom [10814,11100]
atom [10814,11100]
===
match
---
name: execution_date [23592,23606]
name: execution_date [23592,23606]
===
match
---
string: "ubuntu:16.04" [16033,16047]
string: "ubuntu:16.04" [16033,16047]
===
match
---
trailer [17466,17479]
trailer [17466,17479]
===
match
---
atom [14351,14365]
atom [14351,14365]
===
match
---
atom_expr [16685,16707]
atom_expr [16685,16707]
===
match
---
operator: = [3481,3482]
operator: = [3481,3482]
===
match
---
atom_expr [7655,7677]
atom_expr [7655,7677]
===
match
---
name: task_ids [23653,23661]
name: task_ids [23653,23661]
===
match
---
trailer [18185,18555]
trailer [18185,18555]
===
match
---
operator: , [15733,15734]
operator: , [15733,15734]
===
match
---
operator: , [16073,16074]
operator: , [16073,16074]
===
match
---
string: "foo" [21796,21801]
string: "foo" [21796,21801]
===
match
---
expr_stmt [16551,16608]
expr_stmt [16551,16608]
===
match
---
trailer [16509,16522]
trailer [16509,16522]
===
match
---
parameters [7710,7716]
parameters [7710,7716]
===
match
---
name: mock [5582,5586]
name: mock [5582,5586]
===
match
---
argument [16130,16151]
argument [16130,16151]
===
match
---
name: State [2537,2542]
name: State [2537,2542]
===
match
---
atom_expr [13117,13125]
atom_expr [13117,13125]
===
match
---
name: image [8359,8364]
name: image [8359,8364]
===
match
---
comparison [16777,16897]
comparison [16777,16897]
===
match
---
operator: = [16003,16004]
operator: = [16003,16004]
===
match
---
trailer [21420,21423]
trailer [21420,21423]
===
match
---
string: "try_number" [13019,13031]
string: "try_number" [13019,13031]
===
match
---
operator: = [18569,18570]
operator: = [18569,18570]
===
match
---
operator: , [21175,21176]
operator: , [21175,21176]
===
match
---
name: context [16730,16737]
name: context [16730,16737]
===
match
---
operator: , [18252,18253]
operator: , [18252,18253]
===
match
---
name: operator [2471,2479]
name: operator [2471,2479]
===
match
---
operator: == [23804,23806]
operator: == [23804,23806]
===
match
---
atom [3949,3963]
atom [3949,3963]
===
match
---
name: cmds [22568,22572]
name: cmds [22568,22572]
===
match
---
atom_expr [6203,6230]
atom_expr [6203,6230]
===
match
---
operator: , [3047,3048]
operator: , [3047,3048]
===
match
---
funcdef [2030,2448]
funcdef [2030,2448]
===
match
---
operator: , [23420,23421]
operator: , [23420,23421]
===
match
---
operator: , [7345,7346]
operator: , [7345,7346]
===
match
---
name: env_from [4844,4852]
name: env_from [4844,4852]
===
match
---
name: self [3678,3682]
name: self [3678,3682]
===
match
---
name: labels [18335,18341]
name: labels [18335,18341]
===
match
---
name: list_namespaced_pod [3377,3396]
name: list_namespaced_pod [3377,3396]
===
match
---
trailer [9285,9294]
trailer [9285,9294]
===
match
---
name: do_xcom_push [23402,23414]
name: do_xcom_push [23402,23414]
===
match
---
parameters [6332,6338]
parameters [6332,6338]
===
match
---
trailer [8130,8139]
trailer [8130,8139]
===
match
---
trailer [17569,17586]
trailer [17569,17586]
===
match
---
name: task_id [5189,5196]
name: task_id [5189,5196]
===
match
---
string: "kub_pod_test" [2143,2157]
string: "kub_pod_test" [2143,2157]
===
match
---
trailer [22113,22118]
trailer [22113,22118]
===
match
---
name: create_pod_request_obj [8031,8053]
name: create_pod_request_obj [8031,8053]
===
match
---
name: tpl_file [12376,12384]
name: tpl_file [12376,12384]
===
match
---
trailer [3503,3515]
trailer [3503,3515]
===
match
---
operator: = [20294,20295]
operator: = [20294,20295]
===
match
---
operator: } [15871,15872]
operator: } [15871,15872]
===
match
---
argument [19670,19688]
argument [19670,19688]
===
match
---
name: run_id [23496,23502]
name: run_id [23496,23502]
===
match
---
name: mock [1502,1506]
name: mock [1502,1506]
===
match
---
name: stop [2001,2005]
name: stop [2001,2005]
===
match
---
name: sanitized_pod [18735,18748]
name: sanitized_pod [18735,18748]
===
match
---
atom_expr [17080,17440]
atom_expr [17080,17440]
===
match
---
name: pod [22145,22148]
name: pod [22145,22148]
===
match
---
atom_expr [1221,1259]
atom_expr [1221,1259]
===
match
---
operator: == [12668,12670]
operator: == [12668,12670]
===
match
---
parameters [17698,17704]
parameters [17698,17704]
===
match
---
operator: = [22502,22503]
operator: = [22502,22503]
===
match
---
name: pod_namespace [23858,23871]
name: pod_namespace [23858,23871]
===
match
---
argument [12549,12580]
argument [12549,12580]
===
match
---
operator: = [6653,6654]
operator: = [6653,6654]
===
match
---
name: start [1802,1807]
name: start [1802,1807]
===
match
---
name: config_file [3211,3222]
name: config_file [3211,3222]
===
match
---
trailer [20632,20655]
trailer [20632,20655]
===
match
---
operator: , [8411,8412]
operator: , [8411,8412]
===
match
---
string: "bash" [19486,19492]
string: "bash" [19486,19492]
===
match
---
operator: , [20309,20310]
operator: , [20309,20310]
===
match
---
name: test_push_xcom_pod_info [23140,23163]
name: test_push_xcom_pod_info [23140,23163]
===
match
---
operator: , [19626,19627]
operator: , [19626,19627]
===
match
---
operator: , [22761,22762]
operator: , [22761,22762]
===
match
---
trailer [14694,14696]
trailer [14694,14696]
===
match
---
atom_expr [18962,19321]
atom_expr [18962,19321]
===
match
---
name: k [12474,12475]
name: k [12474,12475]
===
match
---
number: 0 [15338,15339]
number: 0 [15338,15339]
===
match
---
simple_stmt [23440,23462]
simple_stmt [23440,23462]
===
match
---
operator: = [21953,21954]
operator: = [21953,21954]
===
match
---
name: image [22530,22535]
name: image [22530,22535]
===
match
---
name: return_value [16576,16588]
name: return_value [16576,16588]
===
match
---
name: pytest [22309,22315]
name: pytest [22309,22315]
===
match
---
operator: == [21495,21497]
operator: == [21495,21497]
===
match
---
name: create_context [17534,17548]
name: create_context [17534,17548]
===
match
---
atom_expr [15849,15857]
atom_expr [15849,15857]
===
match
---
arglist [6387,6739]
arglist [6387,6739]
===
match
---
operator: , [17429,17430]
operator: , [17429,17430]
===
match
---
name: do_xcom_push [17372,17384]
name: do_xcom_push [17372,17384]
===
match
---
arglist [14890,15058]
arglist [14890,15058]
===
match
---
expr_stmt [23629,23688]
expr_stmt [23629,23688]
===
match
---
name: pod_template_file [14922,14939]
name: pod_template_file [14922,14939]
===
match
---
name: name [10506,10510]
name: name [10506,10510]
===
match
---
atom [19524,19535]
atom [19524,19535]
===
match
---
operator: , [19656,19657]
operator: , [19656,19657]
===
match
---
operator: { [14200,14201]
operator: { [14200,14201]
===
match
---
string: 'key' [14294,14299]
string: 'key' [14294,14299]
===
match
---
string: "value" [20189,20196]
string: "value" [20189,20196]
===
match
---
string: "test" [23324,23330]
string: "test" [23324,23330]
===
match
---
name: create_pod_request_obj [21288,21310]
name: create_pod_request_obj [21288,21310]
===
match
---
name: k [15955,15956]
name: k [15955,15956]
===
match
---
name: metadata [9319,9327]
name: metadata [9319,9327]
===
match
---
argument [21906,21924]
argument [21906,21924]
===
match
---
simple_stmt [23538,23621]
simple_stmt [23538,23621]
===
match
---
parameters [5648,5654]
parameters [5648,5654]
===
match
---
operator: = [3159,3160]
operator: = [3159,3160]
===
match
---
name: k8s [6050,6053]
name: k8s [6050,6053]
===
match
---
assert_stmt [6799,6858]
assert_stmt [6799,6858]
===
match
---
name: image_pull_policy [6673,6690]
name: image_pull_policy [6673,6690]
===
match
---
number: 0 [4929,4930]
number: 0 [4929,4930]
===
match
---
trailer [5730,6146]
trailer [5730,6146]
===
match
---
dictorsetmaker [7217,7229]
dictorsetmaker [7217,7229]
===
match
---
assert_stmt [19950,20002]
assert_stmt [19950,20002]
===
match
---
name: namespace [21652,21661]
name: namespace [21652,21661]
===
match
---
string: "task" [12995,13001]
string: "task" [12995,13001]
===
match
---
operator: , [7964,7965]
operator: , [7964,7965]
===
match
---
operator: , [12966,12967]
operator: , [12966,12967]
===
match
---
operator: = [3261,3262]
operator: = [3261,3262]
===
match
---
name: pytest [7523,7529]
name: pytest [7523,7529]
===
match
---
operator: , [5400,5401]
operator: , [5400,5401]
===
match
---
operator: { [9696,9697]
operator: { [9696,9697]
===
match
---
operator: , [21671,21672]
operator: , [21671,21672]
===
match
---
operator: } [14532,14533]
operator: } [14532,14533]
===
match
---
name: namespace [5744,5753]
name: namespace [5744,5753]
===
match
---
atom_expr [20631,20657]
atom_expr [20631,20657]
===
match
---
suite [16662,16747]
suite [16662,16747]
===
match
---
name: ANY [5587,5590]
name: ANY [5587,5590]
===
match
---
operator: == [12849,12851]
operator: == [12849,12851]
===
match
---
trailer [13238,13241]
trailer [13238,13241]
===
match
---
name: k [17560,17561]
name: k [17560,17561]
===
match
---
dictorsetmaker [14294,14365]
dictorsetmaker [14294,14365]
===
match
---
name: env_from [4944,4952]
name: env_from [4944,4952]
===
match
---
name: cluster_context [22815,22830]
name: cluster_context [22815,22830]
===
match
---
operator: , [5866,5867]
operator: , [5866,5867]
===
match
---
trailer [1938,1952]
trailer [1938,1952]
===
match
---
trailer [1886,1909]
trailer [1886,1909]
===
match
---
string: "dag" [5395,5400]
string: "dag" [5395,5400]
===
match
---
trailer [10803,10810]
trailer [10803,10810]
===
match
---
atom_expr [21617,22015]
atom_expr [21617,22015]
===
match
---
operator: , [23053,23054]
operator: , [23053,23054]
===
match
---
string: 'node_affinity' [13504,13519]
string: 'node_affinity' [13504,13519]
===
match
---
name: k8s [4404,4407]
name: k8s [4404,4407]
===
match
---
operator: { [2265,2266]
operator: { [2265,2266]
===
match
---
string: "task" [15727,15733]
string: "task" [15727,15733]
===
match
---
name: start [1855,1860]
name: start [1855,1860]
===
match
---
operator: = [17527,17528]
operator: = [17527,17528]
===
match
---
string: "-cx" [4630,4635]
string: "-cx" [4630,4635]
===
match
---
name: self [1343,1347]
name: self [1343,1347]
===
match
---
operator: = [20219,20220]
operator: = [20219,20220]
===
match
---
name: pod [21400,21403]
name: pod [21400,21403]
===
match
---
trailer [19915,19924]
trailer [19915,19924]
===
match
---
expr_stmt [22025,22057]
expr_stmt [22025,22057]
===
match
---
operator: { [20153,20154]
operator: { [20153,20154]
===
match
---
string: "task" [23352,23358]
string: "task" [23352,23358]
===
match
---
name: namespace [13173,13182]
name: namespace [13173,13182]
===
match
---
name: start [1747,1752]
name: start [1747,1752]
===
match
---
arglist [23558,23619]
arglist [23558,23619]
===
match
---
name: name_base [10047,10056]
name: name_base [10047,10056]
===
match
---
trailer [18965,18991]
trailer [18965,18991]
===
match
---
testlist_comp [5817,5830]
testlist_comp [5817,5830]
===
match
---
operator: , [16207,16208]
operator: , [16207,16208]
===
match
---
operator: , [921,922]
operator: , [921,922]
===
match
---
number: 0 [6826,6827]
number: 0 [6826,6827]
===
match
---
operator: = [8331,8332]
operator: = [8331,8332]
===
match
---
atom [4660,4671]
atom [4660,4671]
===
match
---
name: labels [5129,5135]
name: labels [5129,5135]
===
match
---
operator: , [3135,3136]
operator: , [3135,3136]
===
match
---
name: mock [862,866]
name: mock [862,866]
===
match
---
operator: = [2068,2069]
operator: = [2068,2069]
===
match
---
simple_stmt [9458,9535]
simple_stmt [9458,9535]
===
match
---
operator: , [18286,18287]
operator: , [18286,18287]
===
match
---
name: name_base [19589,19598]
name: name_base [19589,19598]
===
match
---
atom [3412,3414]
atom [3412,3414]
===
match
---
argument [21652,21671]
argument [21652,21671]
===
match
---
operator: } [14484,14485]
operator: } [14484,14485]
===
match
---
string: "-cx" [18280,18285]
string: "-cx" [18280,18285]
===
match
---
name: warns [22316,22321]
name: warns [22316,22321]
===
match
---
trailer [16636,16654]
trailer [16636,16654]
===
match
---
operator: , [3811,3812]
operator: , [3811,3812]
===
match
---
argument [10279,10293]
argument [10279,10293]
===
match
---
operator: = [2129,2130]
operator: = [2129,2130]
===
match
---
operator: = [2644,2645]
operator: = [2644,2645]
===
match
---
string: "ubuntu:16.04" [23257,23271]
string: "ubuntu:16.04" [23257,23271]
===
match
---
operator: = [17058,17059]
operator: = [17058,17059]
===
match
---
operator: , [1249,1250]
operator: , [1249,1250]
===
match
---
name: name [7244,7248]
name: name [7244,7248]
===
match
---
with_stmt [12347,15873]
with_stmt [12347,15873]
===
match
---
name: task_id [6583,6590]
name: task_id [6583,6590]
===
match
---
name: env_from [4932,4940]
name: env_from [4932,4940]
===
match
---
operator: == [9693,9695]
operator: == [9693,9695]
===
match
---
operator: { [18342,18343]
operator: { [18342,18343]
===
match
---
operator: , [20528,20529]
operator: , [20528,20529]
===
match
---
argument [21753,21774]
argument [21753,21774]
===
match
---
trailer [8075,8084]
trailer [8075,8084]
===
match
---
name: node_affinity [18837,18850]
name: node_affinity [18837,18850]
===
match
---
name: pod [6155,6158]
name: pod [6155,6158]
===
match
---
trailer [18869,19353]
trailer [18869,19353]
===
match
---
operator: = [1781,1782]
operator: = [1781,1782]
===
match
---
operator: , [15580,15581]
operator: , [15580,15581]
===
match
---
name: namespace [2925,2934]
name: namespace [2925,2934]
===
match
---
string: "dag" [12910,12915]
string: "dag" [12910,12915]
===
match
---
operator: = [23606,23607]
operator: = [23606,23607]
===
match
---
parameters [2048,2054]
parameters [2048,2054]
===
match
---
with_stmt [7518,7640]
with_stmt [7518,7640]
===
match
---
operator: , [19432,19433]
operator: , [19432,19433]
===
match
---
name: name_base [10284,10293]
name: name_base [10284,10293]
===
match
---
expr_stmt [4392,4486]
expr_stmt [4392,4486]
===
match
---
argument [7140,7160]
argument [7140,7160]
===
match
---
name: return_value [2521,2533]
name: return_value [2521,2533]
===
match
---
name: do_xcom_push [9105,9117]
name: do_xcom_push [9105,9117]
===
match
---
string: "echo 10" [16106,16115]
string: "echo 10" [16106,16115]
===
match
---
string: "default" [18209,18218]
string: "default" [18209,18218]
===
match
---
name: sanitize_for_serialization [22087,22113]
name: sanitize_for_serialization [22087,22113]
===
match
---
arglist [20903,21260]
arglist [20903,21260]
===
match
---
simple_stmt [13153,13200]
simple_stmt [13153,13200]
===
match
---
funcdef [3660,4284]
funcdef [3660,4284]
===
match
---
atom_expr [12398,12431]
atom_expr [12398,12431]
===
match
---
testlist_comp [3325,3350]
testlist_comp [3325,3350]
===
match
---
simple_stmt [1763,1810]
simple_stmt [1763,1810]
===
match
---
operator: = [3948,3949]
operator: = [3948,3949]
===
match
---
name: pod_spec [10257,10265]
name: pod_spec [10257,10265]
===
match
---
operator: { [10339,10340]
operator: { [10339,10340]
===
match
---
name: V1LocalObjectReference [6239,6261]
name: V1LocalObjectReference [6239,6261]
===
match
---
name: in_cluster [5217,5227]
name: in_cluster [5217,5227]
===
match
---
atom_expr [7477,7509]
atom_expr [7477,7509]
===
match
---
operator: , [14533,14534]
operator: , [14533,14534]
===
match
---
suite [6339,6859]
suite [6339,6859]
===
match
---
name: image [10313,10318]
name: image [10313,10318]
===
match
---
argument [8657,8678]
argument [8657,8678]
===
match
---
operator: = [5978,5979]
operator: = [5978,5979]
===
match
---
string: "-cx" [5109,5114]
string: "-cx" [5109,5114]
===
match
---
arglist [23218,23421]
arglist [23218,23421]
===
match
---
name: name [12576,12580]
name: name [12576,12580]
===
match
---
name: spec [9425,9429]
name: spec [9425,9429]
===
match
---
operator: = [13484,13485]
operator: = [13484,13485]
===
match
---
name: operator [19212,19220]
name: operator [19212,19220]
===
match
---
atom_expr [13219,13247]
atom_expr [13219,13247]
===
match
---
operator: = [20265,20266]
operator: = [20265,20266]
===
match
---
name: name [8085,8089]
name: name [8085,8089]
===
match
---
name: k [5304,5305]
name: k [5304,5305]
===
match
---
name: isinstance [21389,21399]
name: isinstance [21389,21399]
===
match
---
operator: == [13248,13250]
operator: == [13248,13250]
===
match
---
operator: = [16136,16137]
operator: = [16136,16137]
===
match
---
name: run_pod [5296,5303]
name: run_pod [5296,5303]
===
match
---
string: "task" [5472,5478]
string: "task" [5472,5478]
===
match
---
name: self [1712,1716]
name: self [1712,1716]
===
match
---
atom_expr [12352,12372]
atom_expr [12352,12372]
===
match
---
operator: , [9798,9799]
operator: , [9798,9799]
===
match
---
name: image [19446,19451]
name: image [19446,19451]
===
match
---
trailer [16497,16509]
trailer [16497,16509]
===
match
---
operator: , [2436,2437]
operator: , [2436,2437]
===
match
---
trailer [8139,8144]
trailer [8139,8144]
===
match
---
operator: , [6509,6510]
operator: , [6509,6510]
===
match
---
atom [15039,15057]
atom [15039,15057]
===
match
---
trailer [1822,1834]
trailer [1822,1834]
===
match
---
name: context [7631,7638]
name: context [7631,7638]
===
match
---
string: "default" [20558,20567]
string: "default" [20558,20567]
===
match
---
operator: , [6699,6700]
operator: , [6699,6700]
===
match
---
name: preferred_during_scheduling_ignored_during_execution [18887,18939]
name: preferred_during_scheduling_ignored_during_execution [18887,18939]
===
match
---
simple_stmt [22127,22175]
simple_stmt [22127,22175]
===
match
---
comparison [10548,10578]
comparison [10548,10578]
===
match
---
name: k [22917,22918]
name: k [22917,22918]
===
match
---
simple_stmt [1818,1863]
simple_stmt [1818,1863]
===
match
---
dotted_name [1044,1102]
dotted_name [1044,1102]
===
match
---
operator: = [8592,8593]
operator: = [8592,8593]
===
match
---
trailer [7449,7462]
trailer [7449,7462]
===
match
---
name: self [17449,17453]
name: self [17449,17453]
===
match
---
simple_stmt [13350,13405]
simple_stmt [13350,13405]
===
match
---
name: k [16705,16706]
name: k [16705,16706]
===
match
---
atom_expr [1362,1472]
atom_expr [1362,1472]
===
match
---
assert_stmt [9249,9299]
assert_stmt [9249,9299]
===
match
---
name: self [4328,4332]
name: self [4328,4332]
===
match
---
string: "default" [19718,19727]
string: "default" [19718,19727]
===
match
---
name: monitor_patch [1486,1499]
name: monitor_patch [1486,1499]
===
match
---
string: "try_number" [9843,9855]
string: "try_number" [9843,9855]
===
match
---
string: "bash" [4622,4628]
string: "bash" [4622,4628]
===
match
---
param [23164,23168]
param [23164,23168]
===
match
---
string: "foo" [6531,6536]
string: "foo" [6531,6536]
===
match
---
arglist [9047,9199]
arglist [9047,9199]
===
match
---
param [1328,1332]
param [1328,1332]
===
match
---
operator: = [19749,19750]
operator: = [19749,19750]
===
match
---
trailer [20655,20657]
trailer [20655,20657]
===
match
---
argument [8429,8445]
argument [8429,8445]
===
match
---
argument [3977,3988]
argument [3977,3988]
===
match
---
simple_stmt [8283,8540]
simple_stmt [8283,8540]
===
match
---
assert_stmt [9666,9952]
assert_stmt [9666,9952]
===
match
---
arglist [19196,19241]
arglist [19196,19241]
===
match
---
name: k [21613,21614]
name: k [21613,21614]
===
match
---
simple_stmt [23013,23061]
simple_stmt [23013,23061]
===
match
---
operator: = [20366,20367]
operator: = [20366,20367]
===
match
---
simple_stmt [1167,1205]
simple_stmt [1167,1205]
===
match
---
atom_expr [21286,21312]
atom_expr [21286,21312]
===
match
---
argument [5189,5203]
argument [5189,5203]
===
match
---
operator: { [8664,8665]
operator: { [8664,8665]
===
match
---
name: mock [13117,13121]
name: mock [13117,13121]
===
match
---
expr_stmt [23440,23461]
expr_stmt [23440,23461]
===
match
---
operator: = [9085,9086]
operator: = [9085,9086]
===
match
---
operator: , [17502,17503]
operator: , [17502,17503]
===
match
---
name: pod [12829,12832]
name: pod [12829,12832]
===
match
---
operator: , [11049,11050]
operator: , [11049,11050]
===
match
---
argument [22355,22426]
argument [22355,22426]
===
match
---
atom_expr [21400,21423]
atom_expr [21400,21423]
===
match
---
name: image [4582,4587]
name: image [4582,4587]
===
match
---
string: "task" [5948,5954]
string: "task" [5948,5954]
===
match
---
operator: = [8439,8440]
operator: = [8439,8440]
===
match
---
string: 'node_selector_terms' [14147,14168]
string: 'node_selector_terms' [14147,14168]
===
match
---
name: containers [15327,15337]
name: containers [15327,15337]
===
match
---
comparison [9384,9449]
comparison [9384,9449]
===
match
---
name: task_id [23737,23744]
name: task_id [23737,23744]
===
match
---
operator: = [8689,8690]
operator: = [8689,8690]
===
match
---
string: "base" [8833,8839]
string: "base" [8833,8839]
===
match
---
name: monitor_mock [17454,17466]
name: monitor_mock [17454,17466]
===
match
---
operator: , [4706,4707]
operator: , [4706,4707]
===
match
---
atom_expr [16551,16588]
atom_expr [16551,16588]
===
match
---
operator: , [20413,20414]
operator: , [20413,20414]
===
match
---
operator: = [16737,16738]
operator: = [16737,16738]
===
match
---
name: V1PodSpec [8727,8736]
name: V1PodSpec [8727,8736]
===
match
---
argument [7978,8003]
argument [7978,8003]
===
match
---
name: env_vars [4249,4257]
name: env_vars [4249,4257]
===
match
---
trailer [10395,10398]
trailer [10395,10398]
===
match
---
trailer [21479,21494]
trailer [21479,21494]
===
match
---
operator: { [17874,17875]
operator: { [17874,17875]
===
match
---
name: pod [15268,15271]
name: pod [15268,15271]
===
match
---
string: "bash" [22574,22580]
string: "bash" [22574,22580]
===
match
---
funcdef [20008,21510]
funcdef [20008,21510]
===
match
---
simple_stmt [20625,20658]
simple_stmt [20625,20658]
===
match
---
operator: = [15089,15090]
operator: = [15089,15090]
===
match
---
parameters [15911,15917]
parameters [15911,15917]
===
match
---
trailer [12841,12848]
trailer [12841,12848]
===
match
---
operator: = [5919,5920]
operator: = [5919,5920]
===
match
---
name: pod_spec [9190,9198]
name: pod_spec [9190,9198]
===
match
---
name: k8s [18704,18707]
name: k8s [18704,18707]
===
match
---
operator: = [4558,4559]
operator: = [4558,4559]
===
match
---
string: "world" [14827,14834]
string: "world" [14827,14834]
===
match
---
operator: = [22872,22873]
operator: = [22872,22873]
===
match
---
argument [23251,23271]
argument [23251,23271]
===
match
---
operator: , [12531,12532]
operator: , [12531,12532]
===
match
---
trailer [9937,9941]
trailer [9937,9941]
===
match
---
decorator [6864,6955]
decorator [6864,6955]
===
match
---
atom_expr [9315,9337]
atom_expr [9315,9337]
===
match
---
argument [16221,16237]
argument [16221,16237]
===
match
---
trailer [3515,3539]
trailer [3515,3539]
===
match
---
operator: = [22830,22831]
operator: = [22830,22831]
===
match
---
operator: , [20275,20276]
operator: , [20275,20276]
===
match
---
trailer [4260,4265]
trailer [4260,4265]
===
match
---
name: name [22684,22688]
name: name [22684,22688]
===
match
---
argument [7174,7195]
argument [7174,7195]
===
match
---
string: "task" [19620,19626]
string: "task" [19620,19626]
===
match
---
param [5649,5653]
param [5649,5653]
===
match
---
string: "ubuntu:16.04" [8365,8379]
string: "ubuntu:16.04" [8365,8379]
===
match
---
testlist_comp [6460,6473]
testlist_comp [6460,6473]
===
match
---
operator: , [5984,5985]
operator: , [5984,5985]
===
match
---
operator: = [5289,5290]
operator: = [5289,5290]
===
match
---
name: pod [9465,9468]
name: pod [9465,9468]
===
match
---
simple_stmt [10784,11101]
simple_stmt [10784,11101]
===
match
---
operator: = [17352,17353]
operator: = [17352,17353]
===
match
---
name: task_instance [2167,2180]
name: task_instance [2167,2180]
===
match
---
operator: = [10184,10185]
operator: = [10184,10185]
===
match
---
name: cmds [3799,3803]
name: cmds [3799,3803]
===
match
---
trailer [18991,19321]
trailer [18991,19321]
===
match
---
operator: == [14697,14699]
operator: == [14697,14699]
===
match
---
trailer [3465,3473]
trailer [3465,3473]
===
match
---
operator: = [7736,7737]
operator: = [7736,7737]
===
match
---
string: "preference" [17937,17949]
string: "preference" [17937,17949]
===
match
---
arglist [21652,22005]
arglist [21652,22005]
===
match
---
funcdef [8163,8540]
funcdef [8163,8540]
===
match
---
operator: , [7006,7007]
operator: , [7006,7007]
===
match
---
import_as_names [1013,1038]
import_as_names [1013,1038]
===
match
---
name: self [16385,16389]
name: self [16385,16389]
===
match
---
string: "default" [20913,20922]
string: "default" [20913,20922]
===
match
---
argument [3799,3819]
argument [3799,3819]
===
match
---
name: pod_namespace [23697,23710]
name: pod_namespace [23697,23710]
===
match
---
argument [6420,6440]
argument [6420,6440]
===
match
---
operator: = [17225,17226]
operator: = [17225,17226]
===
match
---
operator: } [6543,6544]
operator: } [6543,6544]
===
match
---
operator: , [1255,1256]
operator: , [1255,1256]
===
match
---
name: name_base [8101,8110]
name: name_base [8101,8110]
===
match
---
name: cluster_context [17404,17419]
name: cluster_context [17404,17419]
===
match
---
operator: = [22360,22361]
operator: = [22360,22361]
===
match
---
trailer [20242,20615]
trailer [20242,20615]
===
match
---
argument [6262,6284]
argument [6262,6284]
===
match
---
trailer [10505,10510]
trailer [10505,10510]
===
match
---
name: execute [2629,2636]
name: execute [2629,2636]
===
match
---
name: full_pod_spec [10243,10256]
name: full_pod_spec [10243,10256]
===
match
---
trailer [2684,2694]
trailer [2684,2694]
===
match
---
string: "echo 10" [5856,5865]
string: "echo 10" [5856,5865]
===
match
---
name: image [7826,7831]
name: image [7826,7831]
===
match
---
operator: = [21169,21170]
operator: = [21169,21170]
===
match
---
decorated [2012,2448]
decorated [2012,2448]
===
match
---
operator: = [22535,22536]
operator: = [22535,22536]
===
match
---
name: pod [23031,23034]
name: pod [23031,23034]
===
match
---
name: run_id [23558,23564]
name: run_id [23558,23564]
===
match
---
name: dict [22169,22173]
name: dict [22169,22173]
===
match
---
atom [20153,20206]
atom [20153,20206]
===
match
---
expr_stmt [20666,20718]
expr_stmt [20666,20718]
===
match
---
name: value [20113,20118]
name: value [20113,20118]
===
match
---
name: affinity [19994,20002]
name: affinity [19994,20002]
===
match
---
argument [23653,23671]
argument [23653,23671]
===
match
---
string: "echo 10" [7185,7194]
string: "echo 10" [7185,7194]
===
match
---
comparison [13219,13265]
comparison [13219,13265]
===
match
---
argument [23285,23305]
argument [23285,23305]
===
match
---
name: SUCCESS [17489,17496]
name: SUCCESS [17489,17496]
===
match
---
operator: = [21204,21205]
operator: = [21204,21205]
===
match
---
trailer [17611,17623]
trailer [17611,17623]
===
match
---
operator: = [18620,18621]
operator: = [18620,18621]
===
match
---
name: command [13380,13387]
name: command [13380,13387]
===
match
---
comparison [6203,6286]
comparison [6203,6286]
===
match
---
expr_stmt [22450,22901]
expr_stmt [22450,22901]
===
match
---
arglist [8828,8933]
arglist [8828,8933]
===
match
---
dictorsetmaker [12870,13126]
dictorsetmaker [12870,13126]
===
match
---
assert_stmt [21382,21442]
assert_stmt [21382,21442]
===
match
---
simple_stmt [20138,20208]
simple_stmt [20138,20208]
===
match
---
atom [2265,2447]
atom [2265,2447]
===
match
---
trailer [15212,15221]
trailer [15212,15221]
===
match
---
trailer [9424,9429]
trailer [9424,9429]
===
match
---
string: 'operator' [13792,13802]
string: 'operator' [13792,13802]
===
match
---
name: do_xcom_push [18456,18468]
name: do_xcom_push [18456,18468]
===
match
---
name: cluster_context [3246,3261]
name: cluster_context [3246,3261]
===
match
---
name: self [21337,21341]
name: self [21337,21341]
===
match
---
simple_stmt [938,986]
simple_stmt [938,986]
===
match
---
operator: , [17390,17391]
operator: , [17390,17391]
===
match
---
atom [6049,6096]
atom [6049,6096]
===
match
---
comparison [23076,23130]
comparison [23076,23130]
===
match
---
trailer [6828,6846]
trailer [6828,6846]
===
match
---
trailer [23715,23725]
trailer [23715,23725]
===
match
---
comparison [13160,13199]
comparison [13160,13199]
===
match
---
operator: , [13954,13955]
operator: , [13954,13955]
===
match
---
trailer [23810,23819]
trailer [23810,23819]
===
match
---
operator: == [4214,4216]
operator: == [4214,4216]
===
match
---
simple_stmt [1967,2007]
simple_stmt [1967,2007]
===
match
---
trailer [9406,9412]
trailer [9406,9412]
===
match
---
trailer [6162,6185]
trailer [6162,6185]
===
match
---
argument [20357,20378]
argument [20357,20378]
===
match
---
operator: , [5081,5082]
operator: , [5081,5082]
===
match
---
name: create_pod_request_obj [6163,6185]
name: create_pod_request_obj [6163,6185]
===
match
---
operator: = [23638,23639]
operator: = [23638,23639]
===
match
---
name: self [22968,22972]
name: self [22968,22972]
===
match
---
string: "dag_id" [15632,15640]
string: "dag_id" [15632,15640]
===
match
---
argument [16283,16308]
argument [16283,16308]
===
match
---
string: "-cx" [23299,23304]
string: "-cx" [23299,23304]
===
match
---
string: "task_id" [12984,12993]
string: "task_id" [12984,12993]
===
match
---
string: "{{ foo }}" [3915,3926]
string: "{{ foo }}" [3915,3926]
===
match
---
simple_stmt [4187,4232]
simple_stmt [4187,4232]
===
match
---
atom_expr [15805,15813]
atom_expr [15805,15813]
===
match
---
operator: , [6738,6739]
operator: , [6738,6739]
===
match
---
operator: = [8764,8765]
operator: = [8764,8765]
===
match
---
name: execute [3466,3473]
name: execute [3466,3473]
===
match
---
expr_stmt [22911,22943]
expr_stmt [22911,22943]
===
match
---
trailer [22055,22057]
trailer [22055,22057]
===
match
---
name: self [23164,23168]
name: self [23164,23168]
===
match
---
simple_stmt [9249,9300]
simple_stmt [9249,9300]
===
match
---
atom [2997,3012]
atom [2997,3012]
===
match
---
name: spec [19911,19915]
name: spec [19911,19915]
===
match
---
name: spec [6810,6814]
name: spec [6810,6814]
===
match
---
string: "default" [8515,8524]
string: "default" [8515,8524]
===
match
---
atom [20328,20343]
atom [20328,20343]
===
match
---
name: KubernetesPodOperator [6352,6373]
name: KubernetesPodOperator [6352,6373]
===
match
---
name: metadata [10795,10803]
name: metadata [10795,10803]
===
match
---
operator: , [5763,5764]
operator: , [5763,5764]
===
match
---
operator: , [14339,14340]
operator: , [14339,14340]
===
match
---
trailer [6206,6211]
trailer [6206,6211]
===
match
---
name: image [23251,23256]
name: image [23251,23256]
===
match
---
atom_expr [16493,16542]
atom_expr [16493,16542]
===
match
---
argument [19413,19432]
argument [19413,19432]
===
match
---
operator: , [8524,8525]
operator: , [8524,8525]
===
match
---
name: utils [1180,1185]
name: utils [1180,1185]
===
match
---
trailer [6788,6790]
trailer [6788,6790]
===
match
---
operator: = [7082,7083]
operator: = [7082,7083]
===
match
---
comparison [20803,20854]
comparison [20803,20854]
===
match
---
trailer [17533,17548]
trailer [17533,17548]
===
match
---
name: dag [2064,2067]
name: dag [2064,2067]
===
match
---
trailer [12575,12580]
trailer [12575,12580]
===
match
---
simple_stmt [3499,3655]
simple_stmt [3499,3655]
===
match
---
operator: = [17186,17187]
operator: = [17186,17187]
===
match
---
trailer [15539,15546]
trailer [15539,15546]
===
match
---
assert_stmt [16756,16907]
assert_stmt [16756,16907]
===
match
---
simple_stmt [10486,10533]
simple_stmt [10486,10533]
===
match
---
string: "foo" [8665,8670]
string: "foo" [8665,8670]
===
match
---
operator: = [20398,20399]
operator: = [20398,20399]
===
match
---
operator: = [4659,4660]
operator: = [4659,4660]
===
match
---
operator: = [16169,16170]
operator: = [16169,16170]
===
match
---
trailer [7597,7600]
trailer [7597,7600]
===
match
---
name: k [20864,20865]
name: k [20864,20865]
===
match
---
string: 'pod_affinity' [14570,14584]
string: 'pod_affinity' [14570,14584]
===
match
---
operator: == [22228,22230]
operator: == [22228,22230]
===
match
---
operator: = [21794,21795]
operator: = [21794,21795]
===
match
---
simple_stmt [10004,10039]
simple_stmt [10004,10039]
===
match
---
atom_expr [11041,11049]
atom_expr [11041,11049]
===
match
---
operator: , [5478,5479]
operator: , [5478,5479]
===
match
---
name: client_mock [17612,17623]
name: client_mock [17612,17623]
===
match
---
number: 0 [20766,20767]
number: 0 [20766,20767]
===
match
---
name: key [23673,23676]
name: key [23673,23676]
===
match
---
trailer [2197,2249]
trailer [2197,2249]
===
match
---
atom_expr [9384,9412]
atom_expr [9384,9412]
===
insert-node
---
name: TestKubernetesPodOperator [1268,1293]
to
classdef [1262,23898]
at 0
===
insert-tree
---
funcdef [23903,24518]
    name: test_previous_pods_ignored_for_reattached [23907,23948]
    parameters [23948,23954]
        param [23949,23953]
            name: self [23949,23953]
    suite [23955,24518]
        simple_stmt [23964,24103]
            string: """         When looking for pods to possibly reattach to,         ignore pods from previous tries that were properly finished         """ [23964,24102]
        simple_stmt [24111,24268]
            expr_stmt [24111,24267]
                name: k [24111,24112]
                operator: = [24113,24114]
                atom_expr [24115,24267]
                    name: KubernetesPodOperator [24115,24136]
                    trailer [24136,24267]
                        arglist [24150,24257]
                            argument [24150,24169]
                                name: namespace [24150,24159]
                                operator: = [24159,24160]
                                string: "default" [24160,24169]
                            operator: , [24169,24170]
                            argument [24183,24203]
                                name: image [24183,24188]
                                operator: = [24188,24189]
                                string: "ubuntu:16.04" [24189,24203]
                            operator: , [24203,24204]
                            argument [24217,24228]
                                name: name [24217,24221]
                                operator: = [24221,24222]
                                string: "test" [24222,24228]
                            operator: , [24228,24229]
                            argument [24242,24256]
                                name: task_id [24242,24249]
                                operator: = [24249,24250]
                                string: "task" [24250,24256]
                            operator: , [24256,24257]
        simple_stmt [24276,24292]
            atom_expr [24276,24291]
                name: self [24276,24280]
                trailer [24280,24288]
                    name: run_pod [24281,24288]
                trailer [24288,24291]
                    name: k [24289,24290]
        simple_stmt [24300,24371]
            atom_expr [24300,24370]
                name: self [24300,24304]
                trailer [24304,24316]
                    name: client_mock [24305,24316]
                trailer [24316,24329]
                    name: return_value [24317,24329]
                trailer [24329,24349]
                    name: list_namespaced_pod [24330,24349]
                trailer [24349,24368]
                    name: assert_called_once [24350,24368]
                trailer [24368,24370]
        simple_stmt [24379,24451]
            expr_stmt [24379,24450]
                testlist_star_expr [24379,24388]
                    name: _ [24379,24380]
                    operator: , [24380,24381]
                    name: kwargs [24382,24388]
                operator: = [24389,24390]
                atom_expr [24391,24450]
                    name: self [24391,24395]
                    trailer [24395,24407]
                        name: client_mock [24396,24407]
                    trailer [24407,24420]
                        name: return_value [24408,24420]
                    trailer [24420,24440]
                        name: list_namespaced_pod [24421,24440]
                    trailer [24440,24450]
                        name: call_args [24441,24450]
        simple_stmt [24459,24518]
            assert_stmt [24459,24517]
                comparison [24466,24517]
                    string: 'already_checked!=True' [24466,24489]
                    atom_expr [24493,24517]
                        name: kwargs [24493,24499]
                        trailer [24499,24517]
                            string: 'label_selector' [24500,24516]
to
suite [1313,23898]
at 21
===
insert-tree
---
decorated [24523,25455]
    decorators [24523,24761]
        decorator [24523,24614]
            operator: @ [24523,24524]
            dotted_name [24524,24534]
                name: mock [24524,24528]
                name: patch [24529,24534]
            string: "airflow.providers.cncf.kubernetes.utils.pod_launcher.PodLauncher.delete_pod" [24535,24612]
        decorator [24618,24761]
            operator: @ [24618,24619]
            dotted_name [24619,24629]
                name: mock [24619,24623]
                name: patch [24624,24629]
            strings [24639,24754]
                string: "airflow.providers.cncf.kubernetes.operators.kubernetes_pod" [24639,24699]
                string: ".KubernetesPodOperator.patch_already_checked" [24708,24754]
    funcdef [24765,25455]
        name: test_mark_created_pod_if_not_deleted [24769,24805]
        parameters [24805,24856]
            param [24806,24811]
                name: self [24806,24810]
                operator: , [24810,24811]
            param [24812,24839]
                name: mock_patch_already_checked [24812,24838]
                operator: , [24838,24839]
            param [24840,24855]
                name: mock_delete_pod [24840,24855]
        suite [24857,25455]
            simple_stmt [24866,24954]
                string: """If we aren't deleting pods and have a failure, mark it so we don't reattach to it""" [24866,24953]
            simple_stmt [24962,25161]
                expr_stmt [24962,25160]
                    name: k [24962,24963]
                    operator: = [24964,24965]
                    atom_expr [24966,25160]
                        name: KubernetesPodOperator [24966,24987]
                        trailer [24987,25160]
                            arglist [25001,25150]
                                argument [25001,25020]
                                    name: namespace [25001,25010]
                                    operator: = [25010,25011]
                                    string: "default" [25011,25020]
                                operator: , [25020,25021]
                                argument [25034,25054]
                                    name: image [25034,25039]
                                    operator: = [25039,25040]
                                    string: "ubuntu:16.04" [25040,25054]
                                operator: , [25054,25055]
                                argument [25068,25079]
                                    name: name [25068,25072]
                                    operator: = [25072,25073]
                                    string: "test" [25073,25079]
                                operator: , [25079,25080]
                                argument [25093,25107]
                                    name: task_id [25093,25100]
                                    operator: = [25100,25101]
                                    string: "task" [25101,25107]
                                operator: , [25107,25108]
                                argument [25121,25149]
                                    name: is_delete_operator_pod [25121,25143]
                                    operator: = [25143,25144]
                                operator: , [25149,25150]
            simple_stmt [25169,25229]
                expr_stmt [25169,25228]
                    atom_expr [25169,25199]
                        name: self [25169,25173]
                        trailer [25173,25186]
                            name: monitor_mock [25174,25186]
                        trailer [25186,25199]
                            name: return_value [25187,25199]
                    operator: = [25200,25201]
                    atom [25202,25228]
                        testlist_comp [25203,25227]
                            atom_expr [25203,25215]
                                name: State [25203,25208]
                                trailer [25208,25215]
                                    name: FAILED [25209,25215]
                            operator: , [25215,25216]
                            operator: , [25221,25222]
            simple_stmt [25237,25270]
                expr_stmt [25237,25269]
                    name: context [25237,25244]
                    operator: = [25245,25246]
                    atom_expr [25247,25269]
                        name: self [25247,25251]
                        trailer [25251,25266]
                            name: create_context [25252,25266]
                        trailer [25266,25269]
                            name: k [25267,25268]
            with_stmt [25278,25355]
                atom_expr [25283,25314]
                    name: pytest [25283,25289]
                    trailer [25289,25296]
                        name: raises [25290,25296]
                    trailer [25296,25314]
                        name: AirflowException [25297,25313]
                suite [25315,25355]
                    simple_stmt [25328,25355]
                        atom_expr [25328,25354]
                            name: k [25328,25329]
                            trailer [25329,25337]
                                name: execute [25330,25337]
                            trailer [25337,25354]
                                argument [25338,25353]
                                    name: context [25338,25345]
                                    operator: = [25345,25346]
                                    name: context [25346,25353]
            simple_stmt [25363,25411]
                atom_expr [25363,25410]
                    name: mock_patch_already_checked [25363,25389]
                    trailer [25389,25408]
                        name: assert_called_once [25390,25408]
                    trailer [25408,25410]
            simple_stmt [25419,25455]
                atom_expr [25419,25454]
                    name: mock_delete_pod [25419,25434]
                    trailer [25434,25452]
                        name: assert_not_called [25435,25452]
                    trailer [25452,25454]
to
suite [1313,23898]
at 22
===
insert-tree
---
decorated [25460,26423]
    decorators [25460,25698]
        decorator [25460,25551]
            operator: @ [25460,25461]
            dotted_name [25461,25471]
                name: mock [25461,25465]
                name: patch [25466,25471]
            string: "airflow.providers.cncf.kubernetes.utils.pod_launcher.PodLauncher.delete_pod" [25472,25549]
        decorator [25555,25698]
            operator: @ [25555,25556]
            dotted_name [25556,25566]
                name: mock [25556,25560]
                name: patch [25561,25566]
            strings [25576,25691]
                string: "airflow.providers.cncf.kubernetes.operators.kubernetes_pod" [25576,25636]
                string: ".KubernetesPodOperator.patch_already_checked" [25645,25691]
    funcdef [25702,26423]
        name: test_mark_created_pod_if_not_deleted_during_exception [25706,25759]
        parameters [25759,25824]
            param [25769,25774]
                name: self [25769,25773]
                operator: , [25773,25774]
            param [25775,25802]
                name: mock_patch_already_checked [25775,25801]
                operator: , [25801,25802]
            param [25803,25818]
                name: mock_delete_pod [25803,25818]
        suite [25825,26423]
            simple_stmt [25834,25925]
                string: """If we aren't deleting pods and have an exception, mark it so we don't reattach to it""" [25834,25924]
            simple_stmt [25933,26132]
                expr_stmt [25933,26131]
                    name: k [25933,25934]
                    operator: = [25935,25936]
                    atom_expr [25937,26131]
                        name: KubernetesPodOperator [25937,25958]
                        trailer [25958,26131]
                            arglist [25972,26121]
                                argument [25972,25991]
                                    name: namespace [25972,25981]
                                    operator: = [25981,25982]
                                    string: "default" [25982,25991]
                                operator: , [25991,25992]
                                argument [26005,26025]
                                    name: image [26005,26010]
                                    operator: = [26010,26011]
                                    string: "ubuntu:16.04" [26011,26025]
                                operator: , [26025,26026]
                                argument [26039,26050]
                                    name: name [26039,26043]
                                    operator: = [26043,26044]
                                    string: "test" [26044,26050]
                                operator: , [26050,26051]
                                argument [26064,26078]
                                    name: task_id [26064,26071]
                                    operator: = [26071,26072]
                                    string: "task" [26072,26078]
                                operator: , [26078,26079]
                                argument [26092,26120]
                                    name: is_delete_operator_pod [26092,26114]
                                    operator: = [26114,26115]
                                operator: , [26120,26121]
            simple_stmt [26140,26197]
                expr_stmt [26140,26196]
                    atom_expr [26140,26169]
                        name: self [26140,26144]
                        trailer [26144,26157]
                            name: monitor_mock [26145,26157]
                        trailer [26157,26169]
                            name: side_effect [26158,26169]
                    operator: = [26170,26171]
                    atom_expr [26172,26196]
                        name: AirflowException [26172,26188]
                        trailer [26188,26196]
                            string: "oops" [26189,26195]
            simple_stmt [26205,26238]
                expr_stmt [26205,26237]
                    name: context [26205,26212]
                    operator: = [26213,26214]
                    atom_expr [26215,26237]
                        name: self [26215,26219]
                        trailer [26219,26234]
                            name: create_context [26220,26234]
                        trailer [26234,26237]
                            name: k [26235,26236]
            with_stmt [26246,26323]
                atom_expr [26251,26282]
                    name: pytest [26251,26257]
                    trailer [26257,26264]
                        name: raises [26258,26264]
                    trailer [26264,26282]
                        name: AirflowException [26265,26281]
                suite [26283,26323]
                    simple_stmt [26296,26323]
                        atom_expr [26296,26322]
                            name: k [26296,26297]
                            trailer [26297,26305]
                                name: execute [26298,26305]
                            trailer [26305,26322]
                                argument [26306,26321]
                                    name: context [26306,26313]
                                    operator: = [26313,26314]
                                    name: context [26314,26321]
            simple_stmt [26331,26379]
                atom_expr [26331,26378]
                    name: mock_patch_already_checked [26331,26357]
                    trailer [26357,26376]
                        name: assert_called_once [26358,26376]
                    trailer [26376,26378]
            simple_stmt [26387,26423]
                atom_expr [26387,26422]
                    name: mock_delete_pod [26387,26402]
                    trailer [26402,26420]
                        name: assert_not_called [26403,26420]
                    trailer [26420,26422]
to
suite [1313,23898]
at 23
===
insert-tree
---
decorated [26428,27643]
    decorators [26428,26666]
        decorator [26428,26519]
            operator: @ [26428,26429]
            dotted_name [26429,26439]
                name: mock [26429,26433]
                name: patch [26434,26439]
            string: "airflow.providers.cncf.kubernetes.utils.pod_launcher.PodLauncher.delete_pod" [26440,26517]
        decorator [26523,26666]
            operator: @ [26523,26524]
            dotted_name [26524,26534]
                name: mock [26524,26528]
                name: patch [26529,26534]
            strings [26544,26659]
                string: "airflow.providers.cncf.kubernetes.operators.kubernetes_pod" [26544,26604]
                string: ".KubernetesPodOperator.patch_already_checked" [26613,26659]
    funcdef [26670,27643]
        name: test_mark_reattached_pod_if_not_deleted [26674,26713]
        parameters [26713,26764]
            param [26714,26719]
                name: self [26714,26718]
                operator: , [26718,26719]
            param [26720,26747]
                name: mock_patch_already_checked [26720,26746]
                operator: , [26746,26747]
            param [26748,26763]
                name: mock_delete_pod [26748,26763]
        suite [26765,27643]
            simple_stmt [26774,26862]
                string: """If we aren't deleting pods and have a failure, mark it so we don't reattach to it""" [26774,26861]
            simple_stmt [26870,27069]
                expr_stmt [26870,27068]
                    name: k [26870,26871]
                    operator: = [26872,26873]
                    atom_expr [26874,27068]
                        name: KubernetesPodOperator [26874,26895]
                        trailer [26895,27068]
                            arglist [26909,27058]
                                argument [26909,26928]
                                    name: namespace [26909,26918]
                                    operator: = [26918,26919]
                                    string: "default" [26919,26928]
                                operator: , [26928,26929]
                                argument [26942,26962]
                                    name: image [26942,26947]
                                    operator: = [26947,26948]
                                    string: "ubuntu:16.04" [26948,26962]
                                operator: , [26962,26963]
                                argument [26976,26987]
                                    name: name [26976,26980]
                                    operator: = [26980,26981]
                                    string: "test" [26981,26987]
                                operator: , [26987,26988]
                                argument [27001,27015]
                                    name: task_id [27001,27008]
                                    operator: = [27008,27009]
                                    string: "task" [27009,27015]
                                operator: , [27015,27016]
                                argument [27029,27057]
                                    name: is_delete_operator_pod [27029,27051]
                                    operator: = [27051,27052]
                                operator: , [27057,27058]
            simple_stmt [27122,27144]
                expr_stmt [27122,27143]
                    name: pod [27122,27125]
                    operator: = [27126,27127]
                    atom_expr [27128,27143]
                        name: self [27128,27132]
                        trailer [27132,27140]
                            name: run_pod [27133,27140]
                        trailer [27140,27143]
                            name: k [27141,27142]
            simple_stmt [27186,27226]
                atom_expr [27186,27225]
                    name: mock_patch_already_checked [27186,27212]
                    trailer [27212,27223]
                        name: reset_mock [27213,27223]
                    trailer [27223,27225]
            simple_stmt [27234,27263]
                atom_expr [27234,27262]
                    name: mock_delete_pod [27234,27249]
                    trailer [27249,27260]
                        name: reset_mock [27250,27260]
                    trailer [27260,27262]
            simple_stmt [27271,27348]
                expr_stmt [27271,27347]
                    atom_expr [27271,27339]
                        name: self [27271,27275]
                        trailer [27275,27287]
                            name: client_mock [27276,27287]
                        trailer [27287,27300]
                            name: return_value [27288,27300]
                        trailer [27300,27320]
                            name: list_namespaced_pod [27301,27320]
                        trailer [27320,27333]
                            name: return_value [27321,27333]
                        trailer [27333,27339]
                            name: items [27334,27339]
                    operator: = [27340,27341]
                    atom [27342,27347]
                        name: pod [27343,27346]
            simple_stmt [27356,27416]
                expr_stmt [27356,27415]
                    atom_expr [27356,27386]
                        name: self [27356,27360]
                        trailer [27360,27373]
                            name: monitor_mock [27361,27373]
                        trailer [27373,27386]
                            name: return_value [27374,27386]
                    operator: = [27387,27388]
                    atom [27389,27415]
                        testlist_comp [27390,27414]
                            atom_expr [27390,27402]
                                name: State [27390,27395]
                                trailer [27395,27402]
                                    name: FAILED [27396,27402]
                            operator: , [27402,27403]
                            operator: , [27408,27409]
            simple_stmt [27425,27458]
                expr_stmt [27425,27457]
                    name: context [27425,27432]
                    operator: = [27433,27434]
                    atom_expr [27435,27457]
                        name: self [27435,27439]
                        trailer [27439,27454]
                            name: create_context [27440,27454]
                        trailer [27454,27457]
                            name: k [27455,27456]
            with_stmt [27466,27543]
                atom_expr [27471,27502]
                    name: pytest [27471,27477]
                    trailer [27477,27484]
                        name: raises [27478,27484]
                    trailer [27484,27502]
                        name: AirflowException [27485,27501]
                suite [27503,27543]
                    simple_stmt [27516,27543]
                        atom_expr [27516,27542]
                            name: k [27516,27517]
                            trailer [27517,27525]
                                name: execute [27518,27525]
                            trailer [27525,27542]
                                argument [27526,27541]
                                    name: context [27526,27533]
                                    operator: = [27533,27534]
                                    name: context [27534,27541]
            simple_stmt [27551,27599]
                atom_expr [27551,27598]
                    name: mock_patch_already_checked [27551,27577]
                    trailer [27577,27596]
                        name: assert_called_once [27578,27596]
                    trailer [27596,27598]
            simple_stmt [27607,27643]
                atom_expr [27607,27642]
                    name: mock_delete_pod [27607,27622]
                    trailer [27622,27640]
                        name: assert_not_called [27623,27640]
                    trailer [27640,27642]
to
suite [1313,23898]
at 24
===
delete-node
---
name: TestKubernetesPodOperator [1268,1293]
===
