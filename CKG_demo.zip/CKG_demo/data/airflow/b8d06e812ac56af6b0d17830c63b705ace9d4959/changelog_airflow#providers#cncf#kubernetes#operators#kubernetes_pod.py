===
match
---
name: env_from [8499,8507]
name: env_from [8499,8507]
===
match
---
name: pod_runtime_info_env [1703,1723]
name: pod_runtime_info_env [1703,1723]
===
match
---
name: self [8038,8042]
name: self [8038,8042]
===
match
---
parameters [8010,10081]
parameters [8010,10081]
===
match
---
name: final_state [18264,18275]
name: final_state [18264,18275]
===
match
---
name: k8s [23944,23947]
name: k8s [24068,24071]
===
match
---
atom_expr [19629,19707]
atom_expr [19626,19704]
===
match
---
name: self [10835,10839]
name: self [10835,10839]
===
match
---
operator: , [22275,22276]
operator: , [22272,22273]
===
match
---
atom_expr [21154,21172]
atom_expr [21151,21169]
===
match
---
atom_expr [12962,12973]
atom_expr [12962,12973]
===
match
---
name: env_from [21300,21308]
name: env_from [21297,21305]
===
match
---
trailer [14392,14398]
trailer [14392,14398]
===
match
---
trailer [9308,9313]
trailer [9308,9313]
===
match
---
param [8904,8939]
param [8904,8939]
===
match
---
name: cmds [8177,8181]
name: cmds [8177,8181]
===
match
---
param [8104,8132]
param [8104,8132]
===
match
---
name: self [18021,18025]
name: self [18021,18025]
===
match
---
simple_stmt [21948,22005]
simple_stmt [21945,22002]
===
match
---
return_stmt [19188,19199]
return_stmt [19185,19196]
===
match
---
name: final_state [25169,25180]
name: final_state [25345,25356]
===
match
---
trailer [11249,11265]
trailer [11249,11265]
===
match
---
atom_expr [12462,12483]
atom_expr [12462,12483]
===
match
---
trailer [14749,14754]
trailer [14749,14754]
===
match
---
name: debug [22582,22587]
name: debug [22579,22584]
===
match
---
name: args [21198,21202]
name: args [21195,21199]
===
match
---
expr_stmt [23331,23423]
expr_stmt [23355,23447]
===
match
---
for_stmt [23516,23657]
for_stmt [23540,23681]
===
match
---
param [9805,9845]
param [9805,9845]
===
match
---
argument [10257,10271]
argument [10257,10271]
===
match
---
operator: = [14660,14661]
operator: = [14660,14661]
===
match
---
name: get_logs [23400,23408]
name: get_logs [23424,23432]
===
match
---
name: Optional [9300,9308]
name: Optional [9300,9308]
===
match
---
trailer [11351,11360]
trailer [11351,11360]
===
match
---
param [8038,8043]
param [8038,8043]
===
match
---
simple_stmt [25351,25376]
simple_stmt [25527,25552]
===
match
---
name: self [15597,15601]
name: self [15597,15601]
===
match
---
name: event [23520,23525]
name: event [23544,23549]
===
match
---
atom_expr [11380,11402]
atom_expr [11380,11402]
===
match
---
arglist [18553,18569]
arglist [18553,18569]
===
match
---
testlist_comp [10857,10897]
testlist_comp [10857,10897]
===
match
---
suite [23499,23657]
suite [23523,23681]
===
match
---
atom_expr [23365,23423]
atom_expr [23389,23447]
===
match
---
trailer [16615,16632]
trailer [16615,16632]
===
match
---
name: debug [21957,21962]
name: debug [21954,21959]
===
match
---
operator: { [16581,16582]
operator: { [16581,16582]
===
match
---
name: label_id [14367,14375]
name: label_id [14367,14375]
===
match
---
trailer [15564,15572]
trailer [15564,15572]
===
match
---
name: do_xcom_push [14692,14704]
name: do_xcom_push [14692,14704]
===
match
---
sync_comp_for [10728,10758]
sync_comp_for [10728,10758]
===
match
---
name: volume_mounts [10984,10997]
name: volume_mounts [10984,10997]
===
match
---
name: try_numbers_match [16167,16184]
name: try_numbers_match [16167,16184]
===
match
---
name: context [13989,13996]
name: context [13989,13996]
===
match
---
string: "already_checked" [18078,18095]
string: "already_checked" [18078,18095]
===
match
---
param [9106,9144]
param [9106,9144]
===
match
---
name: seen_oids [13237,13246]
name: seen_oids [13237,13246]
===
match
---
operator: , [15643,15644]
operator: , [15643,15644]
===
match
---
import_as_names [1150,1176]
import_as_names [1150,1176]
===
match
---
operator: = [9708,9709]
operator: = [9708,9709]
===
match
---
suite [22078,22207]
suite [22075,22204]
===
match
---
name: self [12638,12642]
name: self [12638,12642]
===
match
---
trailer [10934,10937]
trailer [10934,10937]
===
match
---
operator: , [20275,20276]
operator: , [20272,20273]
===
match
---
name: Type [14577,14581]
name: Type [14577,14581]
===
match
---
expr_stmt [12178,12226]
expr_stmt [12178,12226]
===
match
---
operator: , [13166,13167]
operator: , [13166,13167]
===
match
---
trailer [10694,10760]
trailer [10694,10760]
===
match
---
name: self [14784,14788]
name: self [14784,14788]
===
match
---
import_name [1000,1033]
import_name [1000,1033]
===
match
---
simple_stmt [24772,24797]
simple_stmt [24896,24921]
===
match
---
operator: , [23342,23343]
operator: , [23366,23367]
===
match
---
name: log [19634,19637]
name: log [19631,19634]
===
match
---
trailer [22587,22695]
trailer [22584,22692]
===
match
---
simple_stmt [11082,11163]
simple_stmt [11082,11163]
===
match
---
operator: , [8209,8210]
operator: , [8209,8210]
===
match
---
name: content [13090,13097]
name: content [13090,13097]
===
match
---
trailer [16399,16427]
trailer [16399,16427]
===
match
---
simple_stmt [18579,18618]
simple_stmt [18579,18618]
===
match
---
atom_expr [10240,10282]
atom_expr [10240,10282]
===
match
---
name: k8s [20236,20239]
name: k8s [20233,20236]
===
match
---
name: v [11022,11023]
name: v [11022,11023]
===
match
---
atom_expr [11082,11094]
atom_expr [11082,11094]
===
match
---
name: List [8518,8522]
name: List [8518,8522]
===
match
---
if_stmt [24724,24797]
if_stmt [24848,24921]
===
match
---
simple_stmt [11208,11237]
simple_stmt [11208,11237]
===
match
---
name: name [12861,12865]
name: name [12861,12865]
===
match
---
return_stmt [22215,22225]
return_stmt [22212,22222]
===
match
---
trailer [8407,8427]
trailer [8407,8427]
===
match
---
atom_expr [25358,25375]
atom_expr [25534,25551]
===
match
---
atom_expr [11001,11024]
atom_expr [11001,11024]
===
match
---
simple_stmt [19319,19354]
simple_stmt [19316,19351]
===
match
---
name: resources [11988,11997]
name: resources [11988,11997]
===
match
---
trailer [16059,16062]
trailer [16059,16062]
===
match
---
operator: , [10074,10075]
operator: , [10074,10075]
===
match
---
name: label [18752,18757]
name: label [18769,18774]
===
match
---
simple_stmt [15075,15218]
simple_stmt [15075,15218]
===
match
---
operator: , [15021,15022]
operator: , [15021,15022]
===
match
---
fstring_expr [16581,16593]
fstring_expr [16581,16593]
===
match
---
atom_expr [8621,8635]
atom_expr [8621,8635]
===
match
---
atom_expr [18992,19025]
atom_expr [18989,19022]
===
match
---
return_stmt [14617,14705]
return_stmt [14617,14705]
===
match
---
name: str [14463,14466]
name: str [14463,14466]
===
match
---
operator: , [16657,16658]
operator: , [16657,16658]
===
match
---
trailer [15704,15710]
trailer [15704,15710]
===
match
---
simple_stmt [15586,15676]
simple_stmt [15586,15676]
===
match
---
atom_expr [8230,8249]
atom_expr [8230,8249]
===
match
---
trailer [19004,19011]
trailer [19001,19008]
===
match
---
string: 'image' [7836,7843]
string: 'image' [7836,7843]
===
match
---
tfpdef [8104,8124]
tfpdef [8104,8124]
===
match
---
trailer [24043,24052]
trailer [24167,24176]
===
match
---
simple_stmt [14525,14539]
simple_stmt [14525,14539]
===
match
---
name: k8s [20190,20193]
name: k8s [20187,20190]
===
match
---
comparison [15692,15715]
comparison [15692,15715]
===
match
---
atom_expr [14030,14054]
atom_expr [14030,14054]
===
match
---
simple_stmt [24316,24584]
simple_stmt [24440,24708]
===
match
---
argument [21140,21172]
argument [21137,21169]
===
match
---
arglist [21963,22003]
arglist [21960,22000]
===
match
---
trailer [25049,25071]
trailer [25225,25247]
===
match
---
atom_expr [9994,10007]
atom_expr [9994,10007]
===
match
---
tfpdef [9724,9751]
tfpdef [9724,9751]
===
match
---
atom_expr [21948,22004]
atom_expr [21945,22001]
===
match
---
trailer [24780,24791]
trailer [24904,24915]
===
match
---
name: create_pod_launcher [15912,15931]
name: create_pod_launcher [15912,15931]
===
match
---
trailer [18241,18245]
trailer [18241,18245]
===
match
---
operator: , [18750,18751]
operator: , [18767,18768]
===
match
---
name: str [9309,9312]
name: str [9309,9312]
===
match
---
atom_expr [15629,15643]
atom_expr [15629,15643]
===
match
---
atom_expr [8349,8372]
atom_expr [8349,8372]
===
match
---
operator: = [12866,12867]
operator: = [12866,12867]
===
match
---
operator: , [18559,18560]
operator: , [18559,18560]
===
match
---
name: warnings [842,850]
name: warnings [842,850]
===
match
---
name: Optional [9623,9631]
name: Optional [9623,9631]
===
match
---
name: info [16275,16279]
name: info [16275,16279]
===
match
---
fstring_string:  returned a failure:  [16560,16581]
fstring_string:  returned a failure:  [16560,16581]
===
match
---
name: State [1907,1912]
name: State [1907,1912]
===
match
---
name: label_id [18722,18730]
name: label_id [18736,18744]
===
match
---
expr_stmt [16361,16445]
expr_stmt [16361,16445]
===
match
---
fstring_string:  and the same try_number. [17745,17770]
fstring_string:  and the same try_number. [17745,17770]
===
match
---
operator: = [12718,12719]
operator: = [12718,12719]
===
match
---
name: self [21948,21952]
name: self [21945,21949]
===
match
---
trailer [22577,22581]
trailer [22574,22578]
===
match
---
param [9522,9554]
param [9522,9554]
===
match
---
name: service_account_name [12206,12226]
name: service_account_name [12206,12226]
===
match
---
atom_expr [24143,24224]
atom_expr [24267,24348]
===
match
---
name: self [23591,23595]
name: self [23615,23619]
===
match
---
name: pod_template_file [19904,19921]
name: pod_template_file [19901,19918]
===
match
---
simple_stmt [16266,16345]
simple_stmt [16266,16345]
===
match
---
name: pod_list [15586,15594]
name: pod_list [15586,15594]
===
match
---
simple_stmt [17692,17772]
simple_stmt [17692,17772]
===
match
---
expr_stmt [12897,12953]
expr_stmt [12897,12953]
===
match
---
funcdef [14711,16910]
funcdef [14711,16910]
===
match
---
fstring_expr [18426,18436]
fstring_expr [18426,18436]
===
match
---
simple_stmt [19834,19923]
simple_stmt [19831,19920]
===
match
---
name: k8s_resources [11954,11967]
name: k8s_resources [11954,11967]
===
match
---
operator: , [24193,24194]
operator: , [24317,24318]
===
match
---
atom_expr [9491,9505]
atom_expr [9491,9505]
===
match
---
name: self [16266,16270]
name: self [16266,16270]
===
match
---
atom_expr [15084,15217]
atom_expr [15084,15217]
===
match
---
name: reason [25010,25016]
name: reason [25134,25140]
===
match
---
testlist_comp [24610,24641]
testlist_comp [24734,24765]
===
match
---
name: name [24189,24193]
name: name [24313,24317]
===
match
---
atom_expr [21295,21308]
atom_expr [21292,21305]
===
match
---
string: 'dag_id' [13878,13886]
string: 'dag_id' [13878,13886]
===
match
---
operator: , [7880,7881]
operator: , [7880,7881]
===
match
---
name: kubernetes [1132,1142]
name: kubernetes [1132,1142]
===
match
---
operator: = [8888,8889]
operator: = [8888,8889]
===
match
---
trailer [22783,22792]
trailer [22780,22789]
===
match
---
trailer [17036,17069]
trailer [17036,17069]
===
match
---
trailer [15153,15169]
trailer [15153,15169]
===
match
---
operator: { [25138,25139]
operator: { [25314,25315]
===
match
---
name: AirflowException [16820,16836]
name: AirflowException [16820,16836]
===
match
---
name: self [19152,19156]
name: self [19149,19153]
===
match
---
name: Optional [10036,10044]
name: Optional [10036,10044]
===
match
---
try_stmt [14764,16910]
try_stmt [14764,16910]
===
match
---
name: labels [22793,22799]
name: labels [22790,22796]
===
match
---
expr_stmt [12067,12169]
expr_stmt [12067,12169]
===
match
---
name: AirflowException [15768,15784]
name: AirflowException [15768,15784]
===
match
---
operator: = [21604,21605]
operator: = [21601,21602]
===
match
---
name: self [12462,12466]
name: self [12462,12466]
===
match
---
trailer [13341,13368]
trailer [13341,13368]
===
match
---
name: volume_mounts [11034,11047]
name: volume_mounts [11034,11047]
===
match
---
operator: = [25281,25282]
operator: = [25457,25458]
===
match
---
trailer [16529,16595]
trailer [16529,16595]
===
match
---
name: Type [929,933]
name: Type [929,933]
===
match
---
or_test [12486,12508]
or_test [12486,12508]
===
match
---
except_clause [23432,23455]
except_clause [23456,23479]
===
match
---
operator: = [20109,20110]
operator: = [20106,20107]
===
match
---
name: convert_affinity [11894,11910]
name: convert_affinity [11894,11910]
===
match
---
simple_stmt [10908,10971]
simple_stmt [10908,10971]
===
match
---
name: context [19029,19036]
name: context [19026,19033]
===
match
---
name: self [12296,12300]
name: self [12296,12300]
===
match
---
arglist [24982,25031]
arglist [25106,25155]
===
match
---
trailer [18773,18775]
trailer [18797,18799]
===
match
---
trailer [14398,14400]
trailer [14398,14400]
===
match
---
name: self [11949,11953]
name: self [11949,11953]
===
match
---
annassign [12973,12991]
annassign [12973,12991]
===
match
---
name: final_state [23870,23881]
name: final_state [23994,24005]
===
match
---
trailer [15953,15969]
trailer [15953,15969]
===
match
---
trailer [23844,23854]
trailer [23868,23878]
===
match
---
simple_stmt [11380,11423]
simple_stmt [11380,11423]
===
match
---
test [10581,10627]
test [10581,10627]
===
match
---
atom [11000,11048]
atom [11000,11048]
===
match
---
name: dnspolicy [9522,9531]
name: dnspolicy [9522,9531]
===
match
---
name: secret [21912,21918]
name: secret [21909,21915]
===
match
---
trailer [15911,15931]
trailer [15911,15931]
===
match
---
operator: , [1649,1650]
operator: , [1649,1650]
===
match
---
trailer [22806,22814]
trailer [22803,22811]
===
match
---
name: name [20476,20480]
name: name [20473,20477]
===
match
---
name: pod [23939,23942]
name: pod [24063,24066]
===
match
---
name: env_vars [8444,8452]
name: env_vars [8444,8452]
===
match
---
sync_comp_for [10938,10952]
sync_comp_for [10938,10952]
===
match
---
name: int [8805,8808]
name: int [8805,8808]
===
match
---
funcdef [22231,23902]
funcdef [22228,24026]
===
match
---
comp_op [13230,13236]
comp_op [13230,13236]
===
match
---
name: kind [20289,20293]
name: kind [20286,20290]
===
match
---
trailer [23476,23498]
trailer [23500,23522]
===
match
---
name: self [18450,18454]
name: self [18450,18454]
===
match
---
operator: } [18435,18436]
operator: } [18435,18436]
===
match
---
name: self [25218,25222]
name: self [25394,25398]
===
match
---
operator: * [8052,8053]
operator: * [8052,8053]
===
match
---
name: State [22296,22301]
name: State [22293,22298]
===
match
---
simple_stmt [13855,14066]
simple_stmt [13855,14066]
===
match
---
atom [11867,11869]
atom [11867,11869]
===
match
---
name: self [20943,20947]
name: self [20940,20944]
===
match
---
parameters [18953,18967]
parameters [18950,18964]
===
match
---
string: 'ti' [14038,14042]
string: 'ti' [14038,14042]
===
match
---
name: node_selectors [11434,11448]
name: node_selectors [11434,11448]
===
match
---
tfpdef [9563,9591]
tfpdef [9563,9591]
===
match
---
name: launcher [16992,17000]
name: launcher [16992,17000]
===
match
---
name: V1Pod [13014,13019]
name: V1Pod [13014,13019]
===
match
---
operator: , [1603,1604]
operator: , [1603,1604]
===
match
---
name: create_new_pod_for_operator [18525,18552]
name: create_new_pod_for_operator [18525,18552]
===
match
---
trailer [10245,10247]
trailer [10245,10247]
===
match
---
trailer [11882,11891]
trailer [11882,11891]
===
match
---
name: context [13934,13941]
name: context [13934,13941]
===
match
---
fstring_end: ' [16593,16594]
fstring_end: ' [16593,16594]
===
match
---
name: self [14568,14572]
name: self [14568,14572]
===
match
---
simple_stmt [15992,16064]
simple_stmt [15992,16064]
===
match
---
trailer [9437,9455]
trailer [9437,9455]
===
match
---
funcdef [24230,25201]
funcdef [24354,25377]
===
match
---
string: '+' [23052,23055]
string: '+' [23049,23052]
===
match
---
testlist_comp [11098,11142]
testlist_comp [11098,11142]
===
match
---
name: V1ResourceRequirements [8972,8994]
name: V1ResourceRequirements [8972,8994]
===
match
---
string: "Pod Event: %s - %s" [23606,23626]
string: "Pod Event: %s - %s" [23630,23650]
===
match
---
name: k8s [9438,9441]
name: k8s [9438,9441]
===
match
---
name: startup_timeout_seconds [10507,10530]
name: startup_timeout_seconds [10507,10530]
===
match
---
atom_expr [19126,19148]
atom_expr [19123,19145]
===
match
---
operator: -> [14738,14740]
operator: -> [14738,14740]
===
match
---
name: self [10769,10773]
name: self [10769,10773]
===
match
---
name: Optional [9076,9084]
name: Optional [9076,9084]
===
match
---
name: labels [20410,20416]
name: labels [20407,20413]
===
match
---
name: self [21247,21251]
name: self [21244,21248]
===
match
---
atom [12167,12169]
atom [12167,12169]
===
match
---
trailer [22306,22312]
trailer [22303,22309]
===
match
---
name: startup_timeout_seconds [10533,10556]
name: startup_timeout_seconds [10533,10556]
===
match
---
name: self [13000,13004]
name: self [13000,13004]
===
match
---
name: k8s [13010,13013]
name: k8s [13010,13013]
===
match
---
raise_stmt [16856,16909]
raise_stmt [16856,16909]
===
match
---
name: sub [19372,19375]
name: sub [19369,19372]
===
match
---
name: __init__ [10248,10256]
name: __init__ [10248,10256]
===
match
---
expr_stmt [11082,11162]
expr_stmt [11082,11162]
===
match
---
trailer [20830,21331]
trailer [20827,21328]
===
match
---
name: secrets [8561,8568]
name: secrets [8561,8568]
===
match
---
name: self [19755,19759]
name: self [19752,19756]
===
match
---
atom [10415,10417]
atom [10415,10417]
===
match
---
name: ports [10947,10952]
name: ports [10947,10952]
===
match
---
name: self [21154,21158]
name: self [21151,21155]
===
match
---
atom_expr [9533,9546]
atom_expr [9533,9546]
===
match
---
operator: -> [13198,13200]
operator: -> [13198,13200]
===
match
---
name: serialize_pod [24116,24129]
name: serialize_pod [24240,24253]
===
match
---
name: pod [16670,16673]
name: pod [16670,16673]
===
match
---
trailer [13311,13324]
trailer [13311,13324]
===
match
---
string: """         Creates a V1Pod based on user parameters. Note that a `pod` or `pod_template_file`         will supersede all other values.          """ [19472,19620]
string: """         Creates a V1Pod based on user parameters. Note that a `pod` or `pod_template_file`         will supersede all other values.          """ [19469,19617]
===
match
---
sync_comp_for [18738,18803]
sync_comp_for [18755,18828]
===
match
---
name: self [22573,22577]
name: self [22570,22574]
===
match
---
trailer [23799,23807]
trailer [23823,23831]
===
match
---
atom [7826,7977]
atom [7826,7977]
===
match
---
name: kwargs [25619,25625]
name: kwargs [25795,25801]
===
match
---
operator: = [20983,20984]
operator: = [20980,20981]
===
match
---
parameters [19443,19449]
parameters [19440,19446]
===
match
---
atom_expr [14624,14705]
atom_expr [14624,14705]
===
match
---
atom_expr [25283,25291]
atom_expr [25459,25467]
===
match
---
name: kubernetes [1777,1787]
name: kubernetes [1777,1787]
===
match
---
atom [25483,25538]
atom [25659,25714]
===
match
---
trailer [14636,14648]
trailer [14636,14648]
===
match
---
trailer [19234,19309]
trailer [19231,19306]
===
match
---
atom_expr [8509,8544]
atom_expr [8509,8544]
===
match
---
name: debug [19638,19643]
name: debug [19635,19640]
===
match
---
operator: } [12507,12508]
operator: } [12507,12508]
===
match
---
name: self [22060,22064]
name: self [22057,22061]
===
match
---
operator: = [10998,10999]
operator: = [10998,10999]
===
match
---
name: V1Volume [8417,8425]
name: V1Volume [8417,8425]
===
match
---
name: annotations [20516,20527]
name: annotations [20513,20524]
===
match
---
trailer [20016,20050]
trailer [20013,20047]
===
match
---
name: self [21991,21995]
name: self [21988,21992]
===
match
---
name: Dict [9500,9504]
name: Dict [9500,9504]
===
match
---
dictorsetmaker [25484,25537]
dictorsetmaker [25660,25713]
===
match
---
name: get_logs [24685,24693]
name: get_logs [24809,24817]
===
match
---
operator: , [8938,8939]
operator: , [8938,8939]
===
match
---
name: self [25244,25248]
name: self [25420,25424]
===
match
---
if_stmt [14781,15218]
if_stmt [14781,15218]
===
match
---
simple_stmt [10502,10557]
simple_stmt [10502,10557]
===
match
---
expr_stmt [15318,15362]
expr_stmt [15318,15362]
===
match
---
trailer [25287,25291]
trailer [25463,25467]
===
match
---
name: labels [18761,18767]
name: labels [18785,18791]
===
match
---
trailer [20451,20470]
trailer [20448,20467]
===
match
---
operator: , [9268,9269]
operator: , [9268,9269]
===
match
---
comparison [14784,14811]
comparison [14784,14811]
===
match
---
tfpdef [9278,9313]
tfpdef [9278,9313]
===
match
---
atom_expr [14131,14155]
atom_expr [14131,14155]
===
match
---
atom_expr [8518,8543]
atom_expr [8518,8543]
===
match
---
expr_stmt [15992,16063]
expr_stmt [15992,16063]
===
match
---
name: self [20405,20409]
name: self [20402,20406]
===
match
---
name: self [23795,23799]
name: self [23819,23823]
===
match
---
operator: = [8839,8840]
operator: = [8839,8840]
===
match
---
operator: , [24290,24291]
operator: , [24414,24415]
===
match
---
trailer [23595,23599]
trailer [23619,23623]
===
match
---
fstring_start: f" [18377,18379]
fstring_start: f" [18377,18379]
===
match
---
operator: , [13515,13516]
operator: , [13515,13516]
===
match
---
name: Optional [8570,8578]
name: Optional [8570,8578]
===
match
---
name: namespace [10377,10386]
name: namespace [10377,10386]
===
match
---
expr_stmt [18237,18251]
expr_stmt [18237,18251]
===
match
---
name: ports [20989,20994]
name: ports [20986,20991]
===
match
---
name: client [14666,14672]
name: client [14666,14672]
===
match
---
name: launcher [24772,24780]
name: launcher [24896,24904]
===
match
---
name: AirflowException [16862,16878]
name: AirflowException [16862,16878]
===
match
---
atom_expr [8273,8308]
atom_expr [8273,8308]
===
match
---
operator: , [20664,20665]
operator: , [20661,20662]
===
match
---
trailer [9631,9642]
trailer [9631,9642]
===
match
---
name: arguments [8219,8228]
name: arguments [8219,8228]
===
match
---
testlist_comp [10696,10758]
testlist_comp [10696,10758]
===
match
---
name: labels [14532,14538]
name: labels [14532,14538]
===
match
---
operator: = [12532,12533]
operator: = [12532,12533]
===
match
---
dotted_name [1007,1025]
dotted_name [1007,1025]
===
match
---
name: self [18237,18241]
name: self [18237,18241]
===
match
---
suite [18097,18339]
suite [18097,18339]
===
match
---
name: log_line [18215,18223]
name: log_line [18215,18223]
===
match
---
name: result [25194,25200]
name: result [25370,25376]
===
match
---
name: metadata [25320,25328]
name: metadata [25496,25504]
===
match
---
fstring_string:  and launcher  [18412,18426]
fstring_string:  and launcher  [18412,18426]
===
match
---
operator: = [21797,21798]
operator: = [21794,21795]
===
match
---
name: convert_port [10922,10934]
name: convert_port [10922,10934]
===
match
---
string: 'task_instance' [16709,16724]
string: 'task_instance' [16709,16724]
===
match
---
operator: = [12091,12092]
operator: = [12091,12092]
===
match
---
comparison [24808,24836]
comparison [24932,24960]
===
match
---
name: pod_generator [1201,1214]
name: pod_generator [1201,1214]
===
match
---
name: log_events_on_failure [12720,12741]
name: log_events_on_failure [12720,12741]
===
match
---
trailer [15695,15711]
trailer [15695,15711]
===
match
---
name: lower [19403,19408]
name: lower [19400,19405]
===
match
---
operator: = [20861,20862]
operator: = [20858,20859]
===
match
---
trailer [16554,16559]
trailer [16554,16559]
===
match
---
name: labels [22964,22970]
name: labels [22961,22967]
===
match
---
name: pod [23850,23853]
name: pod [23874,23877]
===
match
---
name: Dict [8716,8720]
name: Dict [8716,8720]
===
match
---
simple_stmt [24096,24135]
simple_stmt [24220,24259]
===
match
---
trailer [19371,19375]
trailer [19368,19372]
===
match
---
name: List [9228,9232]
name: List [9228,9232]
===
match
---
simple_stmt [1913,1968]
simple_stmt [1913,1968]
===
match
---
operator: = [21202,21203]
operator: = [21199,21200]
===
match
---
name: pod [18054,18057]
name: pod [18054,18057]
===
match
---
simple_stmt [16361,16446]
simple_stmt [16361,16446]
===
match
---
trailer [20818,20830]
trailer [20815,20827]
===
match
---
operator: , [23055,23056]
operator: , [23052,23053]
===
match
---
name: namespace [16768,16777]
name: namespace [16768,16777]
===
match
---
name: metadata [18058,18066]
name: metadata [18058,18066]
===
match
---
name: image [20856,20861]
name: image [20853,20858]
===
match
---
name: pod_template [19834,19846]
name: pod_template [19831,19843]
===
match
---
param [24255,24260]
param [24379,24384]
===
match
---
trailer [13013,13019]
trailer [13013,13019]
===
match
---
name: pod [22166,22169]
name: pod [22163,22166]
===
match
---
parameters [13066,13197]
parameters [13066,13197]
===
match
---
trailer [10687,10694]
trailer [10687,10694]
===
match
---
name: in_cluster [11213,11223]
name: in_cluster [11213,11223]
===
match
---
fstring_end: ' [15863,15864]
fstring_end: ' [15863,15864]
===
match
---
atom_expr [25018,25031]
atom_expr [25142,25155]
===
match
---
trailer [11987,11998]
trailer [11987,11998]
===
match
---
trailer [15352,15362]
trailer [15352,15362]
===
match
---
operator: = [8161,8162]
operator: = [8161,8162]
===
match
---
name: airflow [1658,1665]
name: airflow [1658,1665]
===
match
---
name: self [21605,21609]
name: self [21602,21606]
===
match
---
operator: { [11938,11939]
operator: { [11938,11939]
===
match
---
name: List [9685,9689]
name: List [9685,9689]
===
match
---
name: utils [1888,1893]
name: utils [1888,1893]
===
match
---
simple_stmt [10333,10352]
simple_stmt [10333,10352]
===
match
---
name: volume [11113,11119]
name: volume [11113,11119]
===
match
---
simple_stmt [17798,17881]
simple_stmt [17798,17881]
===
match
---
operator: , [21810,21811]
operator: , [21807,21808]
===
match
---
name: Optional [9676,9684]
name: Optional [9676,9684]
===
match
---
name: Tuple [922,927]
name: Tuple [922,927]
===
match
---
atom_expr [8408,8426]
atom_expr [8408,8426]
===
match
---
operator: == [19026,19028]
operator: == [19023,19025]
===
match
---
import_name [1991,2004]
import_name [1991,2004]
===
match
---
name: List [8282,8286]
name: List [8282,8286]
===
match
---
string: "already_checked" [24060,24077]
string: "already_checked" [24184,24201]
===
match
---
tfpdef [9153,9182]
tfpdef [9153,9182]
===
match
---
string: "base" [20903,20909]
string: "base" [20900,20906]
===
match
---
atom_expr [16045,16062]
atom_expr [16045,16062]
===
match
---
name: version [1926,1933]
name: version [1926,1933]
===
match
---
trailer [24115,24129]
trailer [24239,24253]
===
match
---
name: dict [9131,9135]
name: dict [9131,9135]
===
match
---
suite [22329,23902]
suite [22326,24026]
===
match
---
annassign [25269,25291]
annassign [25445,25467]
===
match
---
simple_stmt [12638,12683]
simple_stmt [12638,12683]
===
match
---
operator: = [20293,20294]
operator: = [20290,20291]
===
match
---
operator: , [9320,9321]
operator: , [9320,9321]
===
match
---
operator: = [16762,16763]
operator: = [16762,16763]
===
match
---
operator: = [11095,11096]
operator: = [11095,11096]
===
match
---
atom_expr [18761,18775]
atom_expr [18785,18799]
===
match
---
name: debug [19764,19769]
name: debug [19761,19766]
===
match
---
name: len [15692,15695]
name: len [15692,15695]
===
match
---
string: 'execution_date' [13971,13987]
string: 'execution_date' [13971,13987]
===
match
---
operator: = [23389,23390]
operator: = [23413,23414]
===
match
---
name: content [13221,13228]
name: content [13221,13228]
===
match
---
parameters [14722,14737]
parameters [14722,14737]
===
match
---
simple_stmt [12691,12742]
simple_stmt [12691,12742]
===
match
---
param [16953,16966]
param [16953,16966]
===
match
---
argument [20682,20710]
argument [20679,20707]
===
match
---
name: priority_class_name [12755,12774]
name: priority_class_name [12755,12774]
===
match
---
name: pod [15270,15273]
name: pod [15270,15273]
===
match
---
name: start_pod [23253,23262]
name: start_pod [23277,23286]
===
match
---
name: self [20366,20370]
name: self [20363,20367]
===
match
---
operator: , [19396,19397]
operator: , [19393,19394]
===
match
---
trailer [24052,24059]
trailer [24176,24183]
===
match
---
funcdef [23907,24225]
funcdef [24031,24349]
===
match
---
name: name [12883,12887]
name: name [12883,12887]
===
match
---
param [9854,9896]
param [9854,9896]
===
match
---
operator: , [10014,10015]
operator: , [10014,10015]
===
match
---
atom_expr [17055,17068]
atom_expr [17055,17068]
===
match
---
name: airflow [1285,1292]
name: airflow [1285,1292]
===
match
---
testlist_comp [12355,12415]
testlist_comp [12355,12415]
===
match
---
name: schedulername [12557,12570]
name: schedulername [12557,12570]
===
match
---
operator: = [23363,23364]
operator: = [23387,23388]
===
match
---
tfpdef [9854,9888]
tfpdef [9854,9888]
===
match
---
name: get_kube_client [14850,14865]
name: get_kube_client [14850,14865]
===
match
---
name: kubernetes [1190,1200]
name: kubernetes [1190,1200]
===
match
---
name: label_selector [15509,15523]
name: label_selector [15509,15523]
===
match
---
operator: , [22312,22313]
operator: , [22309,22310]
===
match
---
name: reattach_on_restart [11319,11338]
name: reattach_on_restart [11319,11338]
===
match
---
atom_expr [9690,9705]
atom_expr [9690,9705]
===
match
---
name: name [25371,25375]
name: name [25547,25551]
===
match
---
operator: = [18296,18297]
operator: = [18296,18297]
===
match
---
name: message [25024,25031]
name: message [25148,25155]
===
match
---
param [18954,18962]
param [18951,18959]
===
match
---
string: 'dag' [14139,14144]
string: 'dag' [14139,14144]
===
match
---
name: template_fields [7793,7808]
name: template_fields [7793,7808]
===
match
---
param [25218,25222]
param [25394,25398]
===
match
---
operator: , [21710,21711]
operator: , [21707,21708]
===
match
---
name: self [12595,12599]
name: self [12595,12599]
===
match
---
name: image_pull_policy [21043,21060]
name: image_pull_policy [21040,21057]
===
match
---
return_stmt [16791,16804]
return_stmt [16791,16804]
===
match
---
name: str [8197,8200]
name: str [8197,8200]
===
match
---
trailer [8467,8481]
trailer [8467,8481]
===
match
---
trailer [14440,14462]
trailer [14440,14462]
===
match
---
operator: = [20438,20439]
operator: = [20435,20436]
===
match
---
tfpdef [8904,8931]
tfpdef [8904,8931]
===
match
---
atom [11197,11199]
atom [11197,11199]
===
match
---
string: 'arguments' [7869,7880]
string: 'arguments' [7869,7880]
===
match
---
operator: = [20321,20322]
operator: = [20318,20319]
===
match
---
string: " Will attach to this pod and monitor instead of starting new one" [18122,18188]
string: " Will attach to this pod and monitor instead of starting new one" [18122,18188]
===
match
---
trailer [16270,16274]
trailer [16270,16274]
===
match
---
name: self [23845,23849]
name: self [23869,23873]
===
match
---
atom_expr [8454,8482]
atom_expr [8454,8482]
===
match
---
operator: , [7900,7901]
operator: , [7900,7901]
===
match
---
name: security_context [9473,9489]
name: security_context [9473,9489]
===
match
---
name: pod_list [15696,15704]
name: pod_list [15696,15704]
===
match
---
trailer [12599,12613]
trailer [12599,12613]
===
match
---
operator: } [10492,10493]
operator: } [10492,10493]
===
match
---
atom_expr [14463,14473]
atom_expr [14463,14473]
===
match
---
atom_expr [12868,12888]
atom_expr [12868,12888]
===
match
---
trailer [16118,16137]
trailer [16118,16137]
===
match
---
import_from [1119,1176]
import_from [1119,1176]
===
match
---
trailer [13895,13902]
trailer [13895,13902]
===
match
---
raise_stmt [15762,15882]
raise_stmt [15762,15882]
===
match
---
name: log_events_on_failure [23477,23498]
name: log_events_on_failure [23501,23522]
===
match
---
trailer [22105,22153]
trailer [22102,22150]
===
match
---
atom_expr [18054,18096]
atom_expr [18054,18096]
===
match
---
name: handle_pod_overlap [16919,16937]
name: handle_pod_overlap [16919,16937]
===
match
---
name: launcher [18561,18569]
name: launcher [18561,18569]
===
match
---
name: is_delete_operator_pod [12265,12287]
name: is_delete_operator_pod [12265,12287]
===
match
---
name: PodGenerator [19989,20001]
name: PodGenerator [19986,19998]
===
match
---
tfpdef [9608,9642]
tfpdef [9608,9642]
===
match
---
name: self [11801,11805]
name: self [11801,11805]
===
match
---
expr_stmt [10395,10417]
expr_stmt [10395,10417]
===
match
---
atom_expr [9685,9706]
atom_expr [9685,9706]
===
match
---
argument [20642,20664]
argument [20639,20661]
===
match
---
name: kube_client [1150,1161]
name: kube_client [1150,1161]
===
match
---
simple_stmt [10151,10232]
simple_stmt [10151,10232]
===
match
---
name: key [16736,16739]
name: key [16736,16739]
===
match
---
name: name [20207,20211]
name: name [20204,20208]
===
match
---
operator: , [13125,13126]
operator: , [13125,13126]
===
match
---
if_stmt [1969,2005]
if_stmt [1969,2005]
===
match
---
name: get_logs [24671,24679]
name: get_logs [24795,24803]
===
match
---
trailer [9232,9260]
trailer [9232,9260]
===
match
---
trailer [8281,8308]
trailer [8281,8308]
===
match
---
operator: , [13080,13081]
operator: , [13080,13081]
===
match
---
name: pod [23395,23398]
name: pod [23419,23422]
===
match
---
atom_expr [12355,12385]
atom_expr [12355,12385]
===
match
---
operator: , [17053,17054]
operator: , [17053,17054]
===
match
---
operator: , [1472,1473]
operator: , [1472,1473]
===
match
---
trailer [18995,19004]
trailer [18992,19001]
===
match
---
operator: , [21260,21261]
operator: , [21257,21258]
===
match
---
trailer [22799,22806]
trailer [22796,22803]
===
match
---
simple_stmt [23863,23902]
simple_stmt [23987,24026]
===
match
---
argument [15645,15674]
argument [15645,15674]
===
match
---
trailer [10002,10007]
trailer [10002,10007]
===
match
---
argument [21491,21520]
argument [21488,21517]
===
match
---
name: image_pull_policy [11405,11422]
name: image_pull_policy [11405,11422]
===
match
---
name: error [24976,24981]
name: error [25100,25105]
===
match
---
trailer [24684,24693]
trailer [24808,24817]
===
match
---
trailer [9693,9705]
trailer [9693,9705]
===
match
---
name: self [11878,11882]
name: self [11878,11882]
===
match
---
trailer [23206,23214]
trailer [23203,23211]
===
match
---
tfpdef [9659,9707]
tfpdef [9659,9707]
===
match
---
operator: } [23126,23127]
operator: } [23123,23124]
===
match
---
name: config_file [15171,15182]
name: config_file [15171,15182]
===
match
---
argument [20592,20624]
argument [20589,20621]
===
match
---
name: init_containers [12661,12676]
name: init_containers [12661,12676]
===
match
---
expr_stmt [11347,11371]
expr_stmt [11347,11371]
===
match
---
atom [25397,25399]
atom [25573,25575]
===
match
---
name: hostnetwork [12315,12326]
name: hostnetwork [12315,12326]
===
match
---
name: label [14467,14472]
name: label [14467,14472]
===
match
---
trailer [15608,15628]
trailer [15608,15628]
===
match
---
argument [20313,20542]
argument [20310,20539]
===
match
---
name: name [20434,20438]
name: name [20431,20435]
===
match
---
name: pod [21846,21849]
name: pod [21843,21846]
===
match
---
name: V1EnvFromSource [8527,8542]
name: V1EnvFromSource [8527,8542]
===
match
---
name: AirflowException [16513,16529]
name: AirflowException [16513,16529]
===
match
---
expr_stmt [11292,11338]
expr_stmt [11292,11338]
===
match
---
trailer [14902,14913]
trailer [14902,14913]
===
match
---
name: pod_launcher [1801,1813]
name: pod_launcher [1801,1813]
===
match
---
string: 'parent_dag_id' [14176,14191]
string: 'parent_dag_id' [14176,14191]
===
match
---
name: self [20606,20610]
name: self [20603,20607]
===
match
---
name: pod [23386,23389]
name: pod [23410,23413]
===
match
---
name: context [18954,18961]
name: context [18951,18958]
===
match
---
name: self [21038,21042]
name: self [21035,21039]
===
match
---
trailer [8196,8201]
trailer [8196,8201]
===
match
---
trailer [9432,9456]
trailer [9432,9456]
===
match
---
name: self [14951,14955]
name: self [14951,14955]
===
match
---
param [9608,9650]
param [9608,9650]
===
match
---
simple_stmt [11292,11339]
simple_stmt [11292,11339]
===
match
---
operator: = [19847,19848]
operator: = [19844,19845]
===
match
---
atom_expr [23845,23853]
atom_expr [23869,23877]
===
match
---
name: context [16608,16615]
name: context [16608,16615]
===
match
---
name: make_safe_label_value [14441,14462]
name: make_safe_label_value [14441,14462]
===
match
---
atom_expr [11894,11920]
atom_expr [11894,11920]
===
match
---
atom_expr [14661,14672]
atom_expr [14661,14672]
===
match
---
suite [24596,24695]
suite [24720,24819]
===
match
---
trailer [23760,23766]
trailer [23784,23790]
===
match
---
trailer [10247,10256]
trailer [10247,10256]
===
match
---
if_stmt [13215,13447]
if_stmt [13215,13447]
===
match
---
name: volumes [21790,21797]
name: volumes [21787,21794]
===
match
---
operator: , [21114,21115]
operator: , [21111,21112]
===
match
---
operator: , [14002,14003]
operator: , [14002,14003]
===
match
---
trailer [9499,9505]
trailer [9499,9505]
===
match
---
name: namespace [10365,10374]
name: namespace [10365,10374]
===
match
---
name: monitor_launched_pod [18303,18323]
name: monitor_launched_pod [18303,18323]
===
match
---
operator: , [19391,19392]
operator: , [19388,19389]
===
match
---
name: env_from [10840,10848]
name: env_from [10840,10848]
===
match
---
trailer [14581,14607]
trailer [14581,14607]
===
match
---
trailer [24179,24188]
trailer [24303,24312]
===
match
---
atom_expr [16513,16595]
atom_expr [16513,16595]
===
match
---
operator: , [21670,21671]
operator: , [21667,21668]
===
match
---
name: V1Pod [22307,22312]
name: V1Pod [22304,22309]
===
match
---
operator: , [9844,9845]
operator: , [9844,9845]
===
match
---
name: info [18459,18463]
name: info [18459,18463]
===
match
---
operator: = [8374,8375]
operator: = [8374,8375]
===
match
---
trailer [16137,16231]
trailer [16137,16231]
===
match
---
atom_expr [9031,9045]
atom_expr [9031,9045]
===
match
---
name: create_pod_request_obj [15281,15303]
name: create_pod_request_obj [15281,15303]
===
match
---
operator: } [17744,17745]
operator: } [17744,17745]
===
match
---
trailer [18066,18073]
trailer [18066,18073]
===
match
---
atom_expr [18298,18338]
atom_expr [18298,18338]
===
match
---
name: p [10935,10936]
name: p [10935,10936]
===
match
---
suite [11788,11825]
suite [11788,11825]
===
match
---
trailer [14043,14054]
trailer [14043,14054]
===
match
---
operator: } [25398,25399]
operator: } [25574,25575]
===
match
---
trailer [20610,20624]
trailer [20607,20621]
===
match
---
name: airflow [1007,1014]
name: airflow [1007,1014]
===
match
---
simple_stmt [14414,14475]
simple_stmt [14414,14475]
===
match
---
name: Optional [9994,10002]
name: Optional [9994,10002]
===
match
---
name: str [8120,8123]
name: str [8120,8123]
===
match
---
argument [20434,20481]
argument [20431,20478]
===
match
---
name: V1Pod [9636,9641]
name: V1Pod [9636,9641]
===
match
---
name: k8s [8968,8971]
name: k8s [8968,8971]
===
match
---
atom_expr [17012,17021]
atom_expr [17012,17021]
===
match
---
param [10066,10075]
param [10066,10075]
===
match
---
name: self [23707,23711]
name: self [23731,23735]
===
match
---
suite [18976,19054]
suite [18973,19051]
===
match
---
simple_stmt [1058,1070]
simple_stmt [1058,1070]
===
match
---
if_stmt [19935,20051]
if_stmt [19932,20048]
===
match
---
name: dag_id [13903,13909]
name: dag_id [13903,13909]
===
match
---
name: Optional [8874,8882]
name: Optional [8874,8882]
===
match
---
string: 'xcom_push' [10113,10124]
string: 'xcom_push' [10113,10124]
===
match
---
name: k8s [17012,17015]
name: k8s [17012,17015]
===
match
---
testlist_star_expr [23331,23362]
testlist_star_expr [23355,23386]
===
match
---
trailer [19036,19042]
trailer [19033,19039]
===
match
---
name: add_xcom_sidecar [22185,22201]
name: add_xcom_sidecar [22182,22198]
===
match
---
name: name [19398,19402]
name: name [19395,19399]
===
match
---
comp_op [14800,14806]
comp_op [14800,14806]
===
match
---
name: xcom_push [16633,16642]
name: xcom_push [16633,16642]
===
match
---
name: pod [20230,20233]
name: pod [20227,20230]
===
match
---
trailer [16204,16210]
trailer [16204,16210]
===
match
---
name: self [14723,14727]
name: self [14723,14727]
===
match
---
name: airflow [1124,1131]
name: airflow [1124,1131]
===
match
---
simple_stmt [15318,15363]
simple_stmt [15318,15363]
===
match
---
name: utils [1841,1846]
name: utils [1841,1846]
===
match
---
atom_expr [8282,8307]
atom_expr [8282,8307]
===
match
---
param [8855,8895]
param [8855,8895]
===
match
---
operator: , [19692,19693]
operator: , [19689,19690]
===
match
---
expr_stmt [15075,15217]
expr_stmt [15075,15217]
===
match
---
atom [11822,11824]
atom [11822,11824]
===
match
---
trailer [16053,16059]
trailer [16053,16059]
===
match
---
atom_expr [16114,16231]
atom_expr [16114,16231]
===
match
---
name: namespace [25329,25338]
name: namespace [25505,25514]
===
match
---
atom_expr [24195,24217]
atom_expr [24319,24341]
===
match
---
name: pod_list [15954,15962]
name: pod_list [15954,15962]
===
match
---
operator: = [15595,15596]
operator: = [15595,15596]
===
match
---
trailer [24791,24796]
trailer [24915,24920]
===
match
---
operator: , [16434,16435]
operator: , [16434,16435]
===
match
---
name: self [20031,20035]
name: self [20028,20032]
===
match
---
atom_expr [21504,21520]
atom_expr [21501,21517]
===
match
---
name: Optional [8230,8238]
name: Optional [8230,8238]
===
match
---
string: """         Generate labels for the pod to track the pod in case of Operator crash          :param context: task context provided by airflow DAG         :return: dict         """ [13668,13846]
string: """         Generate labels for the pod to track the pod in case of Operator crash          :param context: task context provided by airflow DAG         :return: dict         """ [13668,13846]
===
match
---
suite [19085,19412]
suite [19082,19409]
===
match
---
name: schedulername [12573,12586]
name: schedulername [12573,12586]
===
match
---
operator: = [8203,8204]
operator: = [8203,8204]
===
match
---
operator: , [18287,18288]
operator: , [18287,18288]
===
match
---
name: event [25004,25009]
name: event [25128,25133]
===
match
---
simple_stmt [10360,10387]
simple_stmt [10360,10387]
===
match
---
name: pod_template [21880,21892]
name: pod_template [21877,21889]
===
match
---
name: convert_port [1544,1556]
name: convert_port [1544,1556]
===
match
---
simple_stmt [16856,16910]
simple_stmt [16856,16910]
===
match
---
operator: = [11224,11225]
operator: = [11224,11225]
===
match
---
operator: , [910,911]
operator: , [910,911]
===
match
---
name: tolerations [20682,20693]
name: tolerations [20679,20690]
===
match
---
operator: = [8545,8546]
operator: = [8545,8546]
===
match
---
trailer [8082,8087]
trailer [8082,8087]
===
match
---
trailer [8971,8994]
trailer [8971,8994]
===
match
---
name: PodRuntimeInfoEnv [1731,1748]
name: PodRuntimeInfoEnv [1731,1748]
===
match
---
fstring_end: " [17770,17771]
fstring_end: " [17770,17771]
===
match
---
name: version [1941,1948]
name: version [1941,1948]
===
match
---
operator: = [20792,20793]
operator: = [20789,20790]
===
match
---
fstring_string: More than one pod running with labels:  [15808,15847]
fstring_string: More than one pod running with labels:  [15808,15847]
===
match
---
param [9278,9321]
param [9278,9321]
===
match
---
operator: , [25615,25616]
operator: , [25791,25792]
===
match
---
suite [25253,25627]
suite [25429,25803]
===
match
---
name: metadata [20313,20321]
name: metadata [20310,20318]
===
match
---
param [9411,9464]
param [9411,9464]
===
match
---
operator: = [9643,9644]
operator: = [9643,9644]
===
match
---
trailer [23202,23206]
trailer [23199,23203]
===
match
---
operator: = [10405,10406]
operator: = [10405,10406]
===
match
---
comparison [10102,10137]
comparison [10102,10137]
===
match
---
operator: , [8053,8054]
operator: , [8053,8054]
===
match
---
string: '-' [19393,19396]
string: '-' [19390,19393]
===
match
---
name: update [22971,22977]
name: update [22968,22974]
===
match
---
name: pod_generator [1163,1176]
name: pod_generator [1163,1176]
===
match
---
parameters [14567,14573]
parameters [14567,14573]
===
match
---
name: resources [8948,8957]
name: resources [8948,8957]
===
match
---
param [24261,24270]
param [24385,24394]
===
match
---
simple_stmt [22017,22049]
simple_stmt [22014,22046]
===
match
---
trailer [22581,22587]
trailer [22578,22584]
===
match
---
name: get [10109,10112]
name: get [10109,10112]
===
match
---
trailer [9441,9454]
trailer [9441,9454]
===
match
---
name: init_containers [20749,20764]
name: init_containers [20746,20761]
===
match
---
trailer [19375,19411]
trailer [19372,19408]
===
match
---
operator: = [21385,21386]
operator: = [21382,21383]
===
match
---
operator: , [25192,25193]
operator: , [25368,25369]
===
match
---
operator: = [16739,16740]
operator: = [16739,16740]
===
match
---
operator: , [8894,8895]
operator: , [8894,8895]
===
match
---
arglist [10257,10281]
arglist [10257,10281]
===
match
---
atom_expr [20064,20082]
atom_expr [20061,20079]
===
match
---
or_test [11186,11199]
or_test [11186,11199]
===
match
---
name: remote_pod [18499,18509]
name: remote_pod [18499,18509]
===
match
---
tfpdef [23939,23953]
tfpdef [24063,24077]
===
match
---
operator: { [15847,15848]
operator: { [15847,15848]
===
match
---
name: log [18206,18209]
name: log [18206,18209]
===
match
---
number: 1 [15973,15974]
number: 1 [15973,15974]
===
match
---
name: name [20898,20902]
name: name [20895,20899]
===
match
---
name: read_pod_events [24919,24934]
name: read_pod_events [25043,25058]
===
match
---
trailer [14202,14209]
trailer [14202,14209]
===
match
---
name: is_delete_operator_pod [9330,9352]
name: is_delete_operator_pod [9330,9352]
===
match
---
if_stmt [16458,16596]
if_stmt [16458,16596]
===
match
---
arglist [19644,19706]
arglist [19641,19703]
===
match
---
name: service_account_name [21453,21473]
name: service_account_name [21450,21470]
===
match
---
operator: = [14950,14951]
operator: = [14950,14951]
===
match
---
trailer [21656,21670]
trailer [21653,21667]
===
match
---
trailer [13307,13311]
trailer [13307,13311]
===
match
---
name: labels [10472,10478]
name: labels [10472,10478]
===
match
---
name: Optional [9424,9432]
name: Optional [9424,9432]
===
match
---
name: labels [10481,10487]
name: labels [10481,10487]
===
match
---
name: self [25045,25049]
name: self [25221,25225]
===
match
---
name: self [13337,13341]
name: self [13337,13341]
===
match
---
trailer [14648,14705]
trailer [14648,14705]
===
match
---
operator: = [21246,21247]
operator: = [21243,21244]
===
match
---
operator: } [14064,14065]
operator: } [14064,14065]
===
match
---
atom_expr [25004,25016]
atom_expr [25128,25140]
===
match
---
name: launcher [15896,15904]
name: launcher [15896,15904]
===
match
---
trailer [22322,22327]
trailer [22319,22324]
===
match
---
name: remote_pod [23883,23893]
name: remote_pod [24007,24017]
===
match
---
suite [18352,18571]
suite [18352,18571]
===
match
---
name: self [12235,12239]
name: self [12235,12239]
===
match
---
trailer [11668,11682]
trailer [11668,11682]
===
match
---
simple_stmt [24040,24088]
simple_stmt [24164,24212]
===
match
---
except_clause [1034,1052]
except_clause [1034,1052]
===
match
---
name: label_id [18742,18750]
name: label_id [18759,18767]
===
match
---
name: node_selectors [11685,11699]
name: node_selectors [11685,11699]
===
match
---
simple_stmt [22338,22565]
simple_stmt [22335,22562]
===
match
---
operator: = [8722,8723]
operator: = [8722,8723]
===
match
---
name: self [22263,22267]
name: self [22260,22264]
===
match
---
return_stmt [23863,23901]
return_stmt [23987,24025]
===
match
---
if_stmt [24850,25033]
if_stmt [24974,25157]
===
match
---
raise_stmt [19212,19309]
raise_stmt [19209,19306]
===
match
---
name: startup_timeout [23273,23288]
name: startup_timeout [23297,23312]
===
match
---
name: seen_oids [13573,13582]
name: seen_oids [13573,13582]
===
match
---
operator: = [12985,12986]
operator: = [12985,12986]
===
match
---
name: env_vars [10611,10619]
name: env_vars [10611,10619]
===
match
---
operator: = [9314,9315]
operator: = [9314,9315]
===
match
---
trailer [15724,15744]
trailer [15724,15744]
===
match
---
trailer [18458,18463]
trailer [18458,18463]
===
match
---
name: List [8408,8412]
name: List [8408,8412]
===
match
---
simple_stmt [1991,2005]
simple_stmt [1991,2005]
===
match
---
name: k8s_resources [21101,21114]
name: k8s_resources [21098,21111]
===
match
---
trailer [19862,19875]
trailer [19859,19872]
===
match
---
atom_expr [20190,20219]
atom_expr [20187,20216]
===
match
---
trailer [21864,21879]
trailer [21861,21876]
===
match
---
name: k8s [9632,9635]
name: k8s [9632,9635]
===
match
---
string: """         Monitors a pod to completion that was created by a previous KubernetesPodOperator          :param launcher: pod launcher that will manage launching and monitoring pods         :param pod: podspec used to find pod using k8s API         :return:         """ [24316,24583]
string: """         Monitors a pod to completion that was created by a previous KubernetesPodOperator          :param launcher: pod launcher that will manage launching and monitoring pods         :param pod: podspec used to find pod using k8s API         :return:         """ [24440,24707]
===
match
---
simple_stmt [10426,10459]
simple_stmt [10426,10459]
===
match
---
arglist [13262,13283]
arglist [13262,13283]
===
match
---
name: items [15705,15710]
name: items [15705,15710]
===
match
---
trailer [18302,18323]
trailer [18302,18323]
===
match
---
number: 220 [19349,19352]
number: 220 [19346,19349]
===
match
---
argument [21688,21710]
argument [21685,21707]
===
match
---
trailer [10112,10125]
trailer [10112,10125]
===
match
---
operator: = [15082,15083]
operator: = [15082,15083]
===
match
---
name: body [24096,24100]
name: body [24220,24224]
===
match
---
name: self [16395,16399]
name: self [16395,16399]
===
match
---
operator: { [18404,18405]
operator: { [18404,18405]
===
match
---
trailer [23161,23218]
trailer [23158,23215]
===
match
---
name: safe_label [14506,14516]
name: safe_label [14506,14516]
===
match
---
trailer [10912,10918]
trailer [10912,10918]
===
match
---
atom_expr [14741,14754]
atom_expr [14741,14754]
===
match
---
string: "Adding xcom sidecar to task %s" [22106,22138]
string: "Adding xcom sidecar to task %s" [22103,22135]
===
match
---
operator: , [8728,8729]
operator: , [8728,8729]
===
match
---
atom_expr [24967,25032]
atom_expr [25091,25156]
===
match
---
simple_stmt [11245,11284]
simple_stmt [11245,11284]
===
match
---
trailer [23394,23398]
trailer [23418,23422]
===
match
---
name: cmds [10400,10404]
name: cmds [10400,10404]
===
match
---
trailer [19408,19410]
trailer [19405,19407]
===
match
---
name: self [23289,23293]
name: self [23313,23317]
===
match
---
trailer [23947,23953]
trailer [24071,24077]
===
match
---
name: pod_template_file [19724,19741]
name: pod_template_file [19721,19738]
===
match
---
expr_stmt [13000,13026]
expr_stmt [13000,13026]
===
match
---
argument [25617,25625]
argument [25793,25801]
===
match
---
suite [19463,22226]
suite [19460,22223]
===
match
---
name: image [10346,10351]
name: image [10346,10351]
===
match
---
name: result [16386,16392]
name: result [16386,16392]
===
match
---
operator: , [20952,20953]
operator: , [20949,20950]
===
match
---
param [23933,23938]
param [24057,24062]
===
match
---
name: xcom_sidecar [22172,22184]
name: xcom_sidecar [22169,22181]
===
match
---
name: self [14898,14902]
name: self [14898,14902]
===
match
---
operator: , [13386,13387]
operator: , [13386,13387]
===
match
---
trailer [24975,24981]
trailer [25099,25105]
===
match
---
atom [22991,23127]
atom [22988,23124]
===
match
---
operator: , [24217,24218]
operator: , [24341,24342]
===
match
---
name: metadata [25362,25370]
name: metadata [25538,25546]
===
match
---
operator: = [13862,13863]
operator: = [13862,13863]
===
match
---
name: self [11245,11249]
name: self [11245,11249]
===
match
---
for_stmt [14363,14517]
for_stmt [14363,14517]
===
match
---
expr_stmt [14487,14516]
expr_stmt [14487,14516]
===
match
---
import_name [835,850]
import_name [835,850]
===
match
---
simple_stmt [12335,12454]
simple_stmt [12335,12454]
===
match
---
arglist [14887,15022]
arglist [14887,15022]
===
match
---
operator: = [15004,15005]
operator: = [15004,15005]
===
match
---
name: airflow [1182,1189]
name: airflow [1182,1189]
===
match
---
testlist [18586,18617]
testlist [18586,18617]
===
match
---
operator: , [904,905]
operator: , [904,905]
===
match
---
name: self [20651,20655]
name: self [20648,20652]
===
match
---
operator: = [10531,10532]
operator: = [10531,10532]
===
match
---
name: jinja_env [13135,13144]
name: jinja_env [13135,13144]
===
match
---
name: self [15318,15322]
name: self [15318,15322]
===
match
---
operator: = [14504,14505]
operator: = [14504,14505]
===
match
---
suite [16249,16446]
suite [16249,16446]
===
match
---
name: namespace [15634,15643]
name: namespace [15634,15643]
===
match
---
operator: = [21037,21038]
operator: = [21034,21035]
===
match
---
expr_stmt [14829,15040]
expr_stmt [14829,15040]
===
match
---
name: pod [25249,25252]
name: pod [25425,25428]
===
match
---
atom_expr [22091,22153]
atom_expr [22088,22150]
===
match
---
name: remote_pod [18277,18287]
name: remote_pod [18277,18287]
===
match
---
expr_stmt [12595,12629]
expr_stmt [12595,12629]
===
match
---
trailer [8286,8307]
trailer [8286,8307]
===
match
---
operator: } [16592,16593]
operator: } [16592,16593]
===
match
---
tfpdef [8824,8838]
tfpdef [8824,8838]
===
match
---
name: Optional [912,920]
name: Optional [912,920]
===
match
---
name: labels [14386,14392]
name: labels [14386,14392]
===
match
---
simple_stmt [10240,10283]
simple_stmt [10240,10283]
===
match
---
trailer [16210,16213]
trailer [16210,16213]
===
match
---
operator: = [20211,20212]
operator: = [20208,20209]
===
match
---
string: 'ts' [13997,14001]
string: 'ts' [13997,14001]
===
match
---
expr_stmt [12552,12586]
expr_stmt [12552,12586]
===
match
---
simple_stmt [18703,18805]
simple_stmt [18703,18839]
===
match
---
trailer [16016,16035]
trailer [16016,16035]
===
match
---
name: pod [22951,22954]
name: pod [22948,22951]
===
match
---
trailer [23563,23569]
trailer [23587,23593]
===
match
---
name: validate_key [19319,19331]
name: validate_key [19316,19328]
===
match
---
trailer [18077,18096]
trailer [18077,18096]
===
match
---
trailer [25248,25252]
trailer [25424,25428]
===
match
---
operator: = [18246,18247]
operator: = [18246,18247]
===
match
---
name: key [16643,16646]
name: key [16643,16646]
===
match
---
trailer [25023,25031]
trailer [25147,25155]
===
match
---
name: init_containers [9659,9674]
name: init_containers [9659,9674]
===
match
---
simple_stmt [22775,22815]
simple_stmt [22772,22812]
===
match
---
fstring [17703,17771]
fstring [17703,17771]
===
match
---
arglist [15629,15674]
arglist [15629,15674]
===
match
---
operator: = [21850,21851]
operator: = [21847,21848]
===
match
---
name: self [19073,19077]
name: self [19070,19074]
===
match
---
atom_expr [13298,13324]
atom_expr [13298,13324]
===
match
---
fstring_start: f' [16879,16881]
fstring_start: f' [16879,16881]
===
match
---
name: Optional [24292,24300]
name: Optional [24416,24424]
===
match
---
name: self [25551,25555]
name: self [25727,25731]
===
match
---
trailer [14955,14971]
trailer [14955,14971]
===
match
---
operator: , [24669,24670]
operator: , [24793,24794]
===
match
---
name: context [16701,16708]
name: context [16701,16708]
===
match
---
name: Optional [8074,8082]
name: Optional [8074,8082]
===
match
---
atom_expr [16665,16687]
atom_expr [16665,16687]
===
match
---
atom_expr [20862,20872]
atom_expr [20859,20869]
===
match
---
atom_expr [12595,12613]
atom_expr [12595,12613]
===
match
---
name: dns_policy [21594,21604]
name: dns_policy [21591,21601]
===
match
---
simple_stmt [19362,19412]
simple_stmt [19359,19409]
===
match
---
atom_expr [15597,15675]
atom_expr [15597,15675]
===
match
---
trailer [19763,19769]
trailer [19760,19766]
===
match
---
operator: = [12313,12314]
operator: = [12313,12314]
===
match
---
name: jinja2 [1998,2004]
name: jinja2 [1998,2004]
===
match
---
fstring_string: Pod returned a failure:  [25114,25138]
fstring_string: Pod returned a failure:  [25290,25314]
===
match
---
trailer [9689,9706]
trailer [9689,9706]
===
match
---
name: ex [16904,16906]
name: ex [16904,16906]
===
match
---
tfpdef [8219,8249]
tfpdef [8219,8249]
===
match
---
trailer [21956,21962]
trailer [21953,21959]
===
match
---
name: utils [1788,1793]
name: utils [1788,1793]
===
match
---
name: Optional [8273,8281]
name: Optional [8273,8281]
===
match
---
name: self [23390,23394]
name: self [23414,23418]
===
match
---
name: items [23564,23569]
name: items [23588,23593]
===
match
---
string: 'Never' [21703,21710]
string: 'Never' [21700,21707]
===
match
---
expr_stmt [12335,12453]
expr_stmt [12335,12453]
===
match
---
name: kwargs [10102,10108]
name: kwargs [10102,10108]
===
match
---
fstring [16530,16594]
fstring [16530,16594]
===
match
---
tfpdef [9522,9546]
tfpdef [9522,9546]
===
match
---
operator: ** [10273,10275]
operator: ** [10273,10275]
===
match
---
operator: , [9512,9513]
operator: , [9512,9513]
===
match
---
trailer [19643,19707]
trailer [19640,19704]
===
match
---
string: "Creating pod for KubernetesPodOperator task %s" [19644,19692]
string: "Creating pod for KubernetesPodOperator task %s" [19641,19689]
===
match
---
trailer [16545,16554]
trailer [16545,16554]
===
match
---
operator: { [16536,16537]
operator: { [16536,16537]
===
match
---
name: add [13308,13311]
name: add [13308,13311]
===
match
---
operator: , [8094,8095]
operator: , [8094,8095]
===
match
---
name: items [16054,16059]
name: items [16054,16059]
===
match
---
name: int [10003,10006]
name: int [10003,10006]
===
match
---
trailer [16708,16725]
trailer [16708,16725]
===
match
---
name: cncf [1676,1680]
name: cncf [1676,1680]
===
match
---
atom_expr [10395,10404]
atom_expr [10395,10404]
===
match
---
dotted_as_name [1007,1033]
dotted_as_name [1007,1033]
===
match
---
trailer [15111,15217]
trailer [15111,15217]
===
match
---
param [9769,9796]
param [9769,9796]
===
match
---
name: do_xcom_push [10297,10309]
name: do_xcom_push [10297,10309]
===
match
---
name: final_state [16361,16372]
name: final_state [16361,16372]
===
match
---
operator: { [10491,10492]
operator: { [10491,10492]
===
match
---
argument [21020,21060]
argument [21017,21057]
===
match
---
string: "node_selectors is deprecated. Please use node_selector instead." [11552,11617]
string: "node_selectors is deprecated. Please use node_selector instead." [11552,11617]
===
match
---
trailer [15235,15242]
trailer [15235,15242]
===
match
---
atom_expr [23263,23271]
atom_expr [23287,23295]
===
match
---
name: name [19097,19101]
name: name [19094,19098]
===
match
---
name: termination_grace_period [25420,25444]
name: termination_grace_period [25596,25620]
===
match
---
name: context [13529,13536]
name: context [13529,13536]
===
match
---
name: self [19629,19633]
name: self [19626,19630]
===
match
---
name: metadata [24180,24188]
name: metadata [24304,24312]
===
match
---
simple_stmt [14169,14228]
simple_stmt [14169,14228]
===
match
---
name: self [12856,12860]
name: self [12856,12860]
===
match
---
simple_stmt [25551,25627]
simple_stmt [25727,25803]
===
match
---
trailer [14175,14192]
trailer [14175,14192]
===
match
---
name: List [8192,8196]
name: List [8192,8196]
===
match
---
simple_stmt [1875,1913]
simple_stmt [1875,1913]
===
match
---
simple_stmt [21846,21899]
simple_stmt [21843,21896]
===
match
---
simple_stmt [12028,12059]
simple_stmt [12028,12059]
===
match
---
name: pod_template [20096,20108]
name: pod_template [20093,20105]
===
match
---
name: SUCCESS [24829,24836]
name: SUCCESS [24953,24960]
===
match
---
trailer [12071,12090]
trailer [12071,12090]
===
match
---
name: tolerations [20699,20710]
name: tolerations [20696,20707]
===
match
---
simple_stmt [1653,1749]
simple_stmt [1653,1749]
===
match
---
trailer [11534,11651]
trailer [11534,11651]
===
match
---
name: pod [23268,23271]
name: pod [23292,23295]
===
match
---
operator: = [9359,9360]
operator: = [9359,9360]
===
match
---
funcdef [18931,19054]
funcdef [18928,19051]
===
match
---
name: seen_oids [13417,13426]
name: seen_oids [13417,13426]
===
match
---
name: monitor_pod [24654,24665]
name: monitor_pod [24778,24789]
===
match
---
param [16992,17006]
param [16992,17006]
===
match
---
param [9968,10015]
param [9968,10015]
===
match
---
atom_expr [21798,21810]
atom_expr [21795,21807]
===
match
---
name: V1EnvVar [13275,13283]
name: V1EnvVar [13275,13283]
===
match
---
name: final_state [23331,23342]
name: final_state [23355,23366]
===
match
---
tfpdef [9769,9787]
tfpdef [9769,9787]
===
match
---
atom_expr [21448,21473]
atom_expr [21445,21470]
===
match
---
argument [20207,20218]
argument [20204,20215]
===
match
---
operator: = [22021,22022]
operator: = [22018,22019]
===
match
---
name: V1Container [20819,20830]
name: V1Container [20816,20827]
===
match
---
trailer [20068,20082]
trailer [20065,20079]
===
match
---
arglist [20592,21811]
arglist [20589,21808]
===
match
---
name: context [13397,13404]
name: context [13397,13404]
===
match
---
name: cluster_context [15154,15169]
name: cluster_context [15154,15169]
===
match
---
name: self [12517,12521]
name: self [12517,12521]
===
match
---
name: k8s [8413,8416]
name: k8s [8413,8416]
===
match
---
name: affinity [11924,11932]
name: affinity [11924,11932]
===
match
---
name: env_from [10785,10793]
name: env_from [10785,10793]
===
match
---
suite [14812,15041]
suite [14812,15041]
===
match
---
name: context [16036,16043]
name: context [16036,16043]
===
match
---
atom_expr [18450,18473]
atom_expr [18450,18473]
===
match
---
operator: , [14375,14376]
operator: , [14375,14376]
===
match
---
tfpdef [8699,8721]
tfpdef [8699,8721]
===
match
---
operator: , [20481,20482]
operator: , [20478,20479]
===
match
---
name: self [23472,23476]
name: self [23496,23500]
===
match
---
atom_expr [14687,14704]
atom_expr [14687,14704]
===
match
---
trailer [25328,25338]
trailer [25504,25514]
===
match
---
operator: = [9394,9395]
operator: = [9394,9395]
===
match
---
string: 'cmds' [7853,7859]
string: 'cmds' [7853,7859]
===
match
---
name: self [23933,23937]
name: self [24057,24061]
===
match
---
or_test [10407,10417]
or_test [10407,10417]
===
match
---
atom_expr [15907,15933]
atom_expr [15907,15933]
===
match
---
operator: , [9401,9402]
operator: , [9401,9402]
===
match
---
trailer [12119,12139]
trailer [12119,12139]
===
match
---
name: security_context [12486,12502]
name: security_context [12486,12502]
===
match
---
name: in_cluster [14903,14913]
name: in_cluster [14903,14913]
===
match
---
atom_expr [23591,23656]
atom_expr [23615,23680]
===
match
---
trailer [16767,16777]
trailer [16767,16777]
===
match
---
argument [20398,20416]
argument [20395,20413]
===
match
---
simple_stmt [25045,25077]
simple_stmt [25221,25253]
===
match
---
operator: , [14054,14055]
operator: , [14054,14055]
===
match
---
name: body [24219,24223]
name: body [24343,24347]
===
match
---
raise_stmt [10151,10231]
raise_stmt [10151,10231]
===
match
---
atom_expr [24103,24134]
atom_expr [24227,24258]
===
match
---
or_test [12661,12682]
or_test [12661,12682]
===
match
---
name: str [8883,8886]
name: str [8883,8886]
===
match
---
trailer [10678,10687]
trailer [10678,10687]
===
match
---
name: seen_oids [13298,13307]
name: seen_oids [13298,13307]
===
match
---
atom_expr [22303,22312]
atom_expr [22300,22309]
===
match
---
param [8780,8815]
param [8780,8815]
===
match
---
name: self [11347,11351]
name: self [11347,11351]
===
match
---
argument [16659,16687]
argument [16659,16687]
===
match
---
trailer [23833,23844]
trailer [23857,23868]
===
match
---
name: self [14661,14665]
name: self [14661,14665]
===
match
---
name: create_new_pod_for_operator [22235,22262]
name: create_new_pod_for_operator [22232,22259]
===
match
---
simple_stmt [18365,18438]
simple_stmt [18365,18438]
===
match
---
trailer [19042,19053]
trailer [19039,19050]
===
match
---
name: self [24143,24147]
name: self [24267,24271]
===
match
---
trailer [23599,23605]
trailer [23623,23629]
===
match
---
simple_stmt [12178,12227]
simple_stmt [12178,12227]
===
match
---
argument [15171,15199]
argument [15171,15199]
===
match
---
operator: = [15458,15459]
operator: = [15458,15459]
===
match
---
atom_expr [22140,22152]
atom_expr [22137,22149]
===
match
---
name: configmaps [10887,10897]
name: configmaps [10887,10897]
===
match
---
name: labels [14169,14175]
name: labels [14169,14175]
===
match
---
atom_expr [20984,20994]
atom_expr [20981,20991]
===
match
---
name: self [11664,11668]
name: self [11664,11668]
===
match
---
operator: @ [18913,18914]
operator: @ [18910,18911]
===
match
---
trailer [18524,18552]
trailer [18524,18552]
===
match
---
simple_stmt [20230,21837]
simple_stmt [20227,21834]
===
match
---
name: self [18201,18205]
name: self [18201,18205]
===
match
---
operator: = [24079,24080]
operator: = [24203,24204]
===
match
---
trailer [19402,19408]
trailer [19399,19405]
===
match
---
name: State [17037,17042]
name: State [17037,17042]
===
match
---
name: client [15075,15081]
name: client [15075,15081]
===
match
---
name: volumes [11087,11094]
name: volumes [11087,11094]
===
match
---
trailer [15095,15111]
trailer [15095,15111]
===
match
---
name: host_network [21491,21503]
name: host_network [21488,21500]
===
match
---
operator: , [23893,23894]
operator: , [24017,24018]
===
match
---
trailer [9227,9261]
trailer [9227,9261]
===
match
---
atom_expr [11292,11316]
atom_expr [11292,11316]
===
match
---
argument [20935,20952]
argument [20932,20949]
===
match
---
if_stmt [19716,20221]
if_stmt [19713,20218]
===
match
---
trailer [14865,15040]
trailer [14865,15040]
===
match
---
trailer [12860,12865]
trailer [12860,12865]
===
match
---
operator: = [21095,21096]
operator: = [21092,21093]
===
match
---
operator: , [21576,21577]
operator: , [21573,21574]
===
match
---
operator: , [13909,13910]
operator: , [13909,13910]
===
match
---
trailer [23605,23656]
trailer [23629,23680]
===
match
---
name: volumes [21803,21810]
name: volumes [21800,21807]
===
match
---
name: V1Container [9694,9705]
name: V1Container [9694,9705]
===
match
---
name: AirflowException [1102,1118]
name: AirflowException [1102,1118]
===
match
---
atom_expr [24772,24796]
atom_expr [24896,24920]
===
match
---
trailer [23043,23051]
trailer [23040,23048]
===
match
---
simple_stmt [23591,23657]
simple_stmt [23615,23681]
===
match
---
atom_expr [23642,23655]
atom_expr [23666,23679]
===
match
---
operator: > [15712,15713]
operator: > [15712,15713]
===
match
---
operator: , [9553,9554]
operator: , [9553,9554]
===
match
---
name: pod_launcher [14624,14636]
name: pod_launcher [14624,14636]
===
match
---
operator: , [21060,21061]
operator: , [21057,21058]
===
match
---
name: launcher [24645,24653]
name: launcher [24769,24777]
===
match
---
name: label_id [18779,18787]
name: label_id [18804,18812]
===
match
---
operator: , [23398,23399]
operator: , [23422,23423]
===
match
---
trailer [23633,23640]
trailer [23657,23664]
===
match
---
name: bool [8759,8763]
name: bool [8759,8763]
===
match
---
trailer [21158,21172]
trailer [21155,21169]
===
match
---
atom_expr [23795,23807]
atom_expr [23819,23831]
===
match
---
atom_expr [10674,10760]
atom_expr [10674,10760]
===
match
---
name: staticmethod [13599,13611]
name: staticmethod [13599,13611]
===
match
---
import_as_names [1801,1827]
import_as_names [1801,1827]
===
match
---
trailer [7818,7823]
trailer [7818,7823]
===
match
---
name: self [24680,24684]
name: self [24804,24808]
===
match
---
operator: , [16951,16952]
operator: , [16951,16952]
===
match
---
operator: = [8683,8684]
operator: = [8683,8684]
===
match
---
comparison [13218,13246]
comparison [13218,13246]
===
match
---
trailer [16632,16642]
trailer [16632,16642]
===
match
---
name: command [20935,20942]
name: command [20932,20939]
===
match
---
name: backwards_compat_converters [1370,1397]
name: backwards_compat_converters [1370,1397]
===
match
---
argument [20289,20299]
argument [20286,20296]
===
match
---
atom_expr [24910,24945]
atom_expr [25034,25069]
===
match
---
name: launcher [16436,16444]
name: launcher [16436,16444]
===
match
---
name: toleration [12374,12384]
name: toleration [12374,12384]
===
match
---
atom_expr [8354,8371]
atom_expr [8354,8371]
===
match
---
trailer [23051,23061]
trailer [23048,23058]
===
match
---
trailer [8353,8372]
trailer [8353,8372]
===
match
---
operator: , [24259,24260]
operator: , [24383,24384]
===
match
---
trailer [8715,8721]
trailer [8715,8721]
===
match
---
name: self [11171,11175]
name: self [11171,11175]
===
match
---
string: 'True' [23106,23112]
string: 'True' [23103,23109]
===
match
---
name: List [8349,8353]
name: List [8349,8353]
===
match
---
name: self [16947,16951]
name: self [16947,16951]
===
match
---
trailer [19633,19637]
trailer [19630,19634]
===
match
---
operator: += [18374,18376]
operator: += [18374,18376]
===
match
---
name: kube_client [15084,15095]
name: kube_client [15084,15095]
===
match
---
simple_stmt [19974,20051]
simple_stmt [19971,20048]
===
match
---
import_from [1653,1748]
import_from [1653,1748]
===
match
---
suite [17785,17881]
suite [17785,17881]
===
match
---
trailer [20174,20180]
trailer [20171,20177]
===
match
---
trailer [8578,8592]
trailer [8578,8592]
===
match
---
operator: , [18609,18610]
operator: , [18609,18610]
===
match
---
name: self [23263,23267]
name: self [23287,23291]
===
match
---
operator: = [20169,20170]
operator: = [20166,20167]
===
match
---
atom [11938,11940]
atom [11938,11940]
===
match
---
funcdef [13616,14539]
funcdef [13616,14539]
===
match
---
name: task_id [22145,22152]
name: task_id [22142,22149]
===
match
---
name: toleration [12390,12400]
name: toleration [12390,12400]
===
match
---
name: providers [1762,1771]
name: providers [1762,1771]
===
match
---
atom_expr [25271,25280]
atom_expr [25447,25456]
===
match
---
name: annotations [20499,20510]
name: annotations [20496,20507]
===
match
---
name: client [15236,15242]
name: client [15236,15242]
===
match
---
arglist [21880,21897]
arglist [21877,21894]
===
match
---
name: state [1894,1899]
name: state [1894,1899]
===
match
---
name: client [15602,15608]
name: client [15602,15608]
===
match
---
atom_expr [14487,14503]
atom_expr [14487,14503]
===
match
---
name: _render_nested_template_fields [13464,13494]
name: _render_nested_template_fields [13464,13494]
===
match
---
name: namespace [24208,24217]
name: namespace [24332,24341]
===
match
---
trailer [9684,9707]
trailer [9684,9707]
===
match
---
atom_expr [20171,20220]
atom_expr [20168,20217]
===
match
---
trailer [15628,15675]
trailer [15628,15675]
===
match
---
operator: , [13404,13405]
operator: , [13404,13405]
===
match
---
name: p [10725,10726]
name: p [10725,10726]
===
match
---
trailer [14220,14227]
trailer [14220,14227]
===
match
---
simple_stmt [23244,23319]
simple_stmt [23268,23343]
===
match
---
argument [21198,21217]
argument [21195,21214]
===
match
---
trailer [11086,11094]
trailer [11086,11094]
===
match
---
name: config_file [12047,12058]
name: config_file [12047,12058]
===
match
---
string: """          In cases where the Scheduler restarts while a KubernetesPodOperator task is running,         this function will either continue to monitor the existing pod or launch a new pod         based on the `reattach_on_restart` parameter.          :param labels: labels used to determine if a pod is repeated         :type labels: dict         :param try_numbers_match: do the try numbers match? Only needed for logging purposes         :type try_numbers_match: bool         :param launcher: PodLauncher         :param pod: Pod found with matching labels         """ [17079,17649]
string: """          In cases where the Scheduler restarts while a KubernetesPodOperator task is running,         this function will either continue to monitor the existing pod or launch a new pod         based on the `reattach_on_restart` parameter.          :param labels: labels used to determine if a pod is repeated         :type labels: dict         :param try_numbers_match: do the try numbers match? Only needed for logging purposes         :type try_numbers_match: bool         :param launcher: PodLauncher         :param pod: Pod found with matching labels         """ [17079,17649]
===
match
---
trailer [8583,8591]
trailer [8583,8591]
===
match
---
name: full_pod_spec [12600,12613]
name: full_pod_spec [12600,12613]
===
match
---
trailer [22963,22970]
trailer [22960,22967]
===
match
---
name: image [10338,10343]
name: image [10338,10343]
===
match
---
operator: , [7941,7942]
operator: , [7941,7942]
===
match
---
atom_expr [23628,23640]
atom_expr [23652,23664]
===
match
---
operator: , [23937,23938]
operator: , [24061,24062]
===
match
---
fstring_start: f' [25112,25114]
fstring_start: f' [25288,25290]
===
match
---
name: PodGenerator [19863,19875]
name: PodGenerator [19860,19872]
===
match
---
name: dag_id [14221,14227]
name: dag_id [14221,14227]
===
match
---
operator: != [24820,24822]
operator: != [24944,24946]
===
match
---
name: bool [9747,9751]
name: bool [9747,9751]
===
match
---
trailer [15269,15273]
trailer [15269,15273]
===
match
---
operator: = [25481,25482]
operator: = [25657,25658]
===
match
---
import_from [1913,1967]
import_from [1913,1967]
===
match
---
expr_stmt [12462,12508]
expr_stmt [12462,12508]
===
match
---
name: utils [1015,1020]
name: utils [1015,1020]
===
match
---
operator: = [23288,23289]
operator: = [23312,23313]
===
match
---
atom_expr [16862,16909]
atom_expr [16862,16909]
===
match
---
trailer [20338,20542]
trailer [20335,20539]
===
match
---
name: dnspolicy [21610,21619]
name: dnspolicy [21607,21616]
===
match
---
atom_expr [19218,19309]
atom_expr [19215,19306]
===
match
---
atom_expr [23390,23398]
atom_expr [23414,23422]
===
match
---
suite [24307,25201]
suite [24431,25377]
===
match
---
atom_expr [22946,23137]
atom_expr [22943,23134]
===
match
---
name: reattach_on_restart [18026,18045]
name: reattach_on_restart [18026,18045]
===
match
---
operator: -> [19450,19452]
operator: -> [19447,19449]
===
match
---
name: Optional [8959,8967]
name: Optional [8959,8967]
===
match
---
name: pod [22780,22783]
name: pod [22777,22780]
===
match
---
trailer [16481,16489]
trailer [16481,16489]
===
match
---
atom_expr [10502,10530]
atom_expr [10502,10530]
===
match
---
atom_expr [24680,24693]
atom_expr [24804,24817]
===
match
---
operator: , [23061,23062]
operator: , [23058,23059]
===
match
---
atom_expr [10292,10309]
atom_expr [10292,10309]
===
match
---
trailer [15962,15968]
trailer [15962,15968]
===
match
---
name: env_from [10774,10782]
name: env_from [10774,10782]
===
match
---
name: remote_pod [25182,25192]
name: remote_pod [25358,25368]
===
match
---
trailer [25555,25562]
trailer [25731,25738]
===
match
---
atom_expr [12235,12262]
atom_expr [12235,12262]
===
match
---
atom_expr [12691,12717]
atom_expr [12691,12717]
===
match
---
annassign [7808,7977]
annassign [7808,7977]
===
match
---
name: bool [8834,8838]
name: bool [8834,8838]
===
match
---
atom_expr [7810,7823]
atom_expr [7810,7823]
===
match
---
name: namespace [8063,8072]
name: namespace [8063,8072]
===
match
---
name: hostnetwork [21509,21520]
name: hostnetwork [21506,21517]
===
match
---
atom_expr [9228,9260]
atom_expr [9228,9260]
===
match
---
if_stmt [14128,14228]
if_stmt [14128,14228]
===
match
---
operator: = [9952,9953]
operator: = [9952,9953]
===
match
---
name: pod [16542,16545]
name: pod [16542,16545]
===
match
---
suite [24946,25033]
suite [25070,25157]
===
match
---
atom_expr [12638,12658]
atom_expr [12638,12658]
===
match
---
name: config_file [14993,15004]
name: config_file [14993,15004]
===
match
---
name: label [14377,14382]
name: label [14377,14382]
===
match
---
name: client [14829,14835]
name: client [14829,14835]
===
match
---
if_stmt [17658,17881]
if_stmt [17658,17881]
===
match
---
operator: = [21503,21504]
operator: = [21500,21501]
===
match
---
operator: , [21989,21990]
operator: , [21986,21987]
===
match
---
atom_expr [20322,20542]
atom_expr [20319,20539]
===
match
---
comp_op [10126,10132]
comp_op [10126,10132]
===
match
---
atom_expr [9623,9642]
atom_expr [9623,9642]
===
match
---
expr_stmt [25351,25375]
expr_stmt [25527,25551]
===
match
---
atom_expr [23752,23808]
atom_expr [23776,23832]
===
match
---
atom_expr [9433,9455]
atom_expr [9433,9455]
===
match
---
name: log_line [18365,18373]
name: log_line [18365,18373]
===
match
---
name: schedulername [21657,21670]
name: schedulername [21654,21667]
===
match
---
atom_expr [25415,25444]
atom_expr [25591,25620]
===
match
---
operator: , [13269,13270]
operator: , [13269,13270]
===
match
---
trailer [21508,21520]
trailer [21505,21517]
===
match
---
name: task_id [21996,22003]
name: task_id [21993,22000]
===
match
---
operator: = [9889,9890]
operator: = [9889,9890]
===
match
---
atom_expr [10696,10727]
atom_expr [10696,10727]
===
match
---
atom_expr [12067,12090]
atom_expr [12067,12090]
===
match
---
name: yaml [1021,1025]
name: yaml [1021,1025]
===
match
---
atom_expr [16476,16489]
atom_expr [16476,16489]
===
match
---
name: airflow [1076,1083]
name: airflow [1076,1083]
===
match
---
expr_stmt [10467,10493]
expr_stmt [10467,10493]
===
match
---
funcdef [19417,22226]
funcdef [19414,22223]
===
match
---
operator: -> [25224,25226]
operator: -> [25400,25402]
===
match
---
name: try_number [14044,14054]
name: try_number [14044,14054]
===
match
---
trailer [10430,10440]
trailer [10430,10440]
===
match
---
atom_expr [21748,21772]
atom_expr [21745,21769]
===
match
---
argument [14887,14913]
argument [14887,14913]
===
match
---
trailer [23262,23318]
trailer [23286,23342]
===
match
---
name: final_state [24610,24621]
name: final_state [24734,24745]
===
match
---
operator: , [22267,22268]
operator: , [22264,22265]
===
match
---
atom_expr [12517,12531]
atom_expr [12517,12531]
===
match
---
annassign [13008,13026]
annassign [13008,13026]
===
match
---
operator: , [9096,9097]
operator: , [9096,9097]
===
match
---
operator: , [9598,9599]
operator: , [9598,9599]
===
match
---
name: cncf [1772,1776]
name: cncf [1772,1776]
===
match
---
simple_stmt [1177,1235]
simple_stmt [1177,1235]
===
match
---
name: final_state [18486,18497]
name: final_state [18486,18497]
===
match
---
import_as_names [870,933]
import_as_names [870,933]
===
match
---
string: 'pod_name' [16647,16657]
string: 'pod_name' [16647,16657]
===
match
---
name: State [24285,24290]
name: State [24409,24414]
===
match
---
trailer [10399,10404]
trailer [10399,10404]
===
match
---
name: k8s [25271,25274]
name: k8s [25447,25450]
===
match
---
name: k8s [13271,13274]
name: k8s [13271,13274]
===
match
---
simple_stmt [16791,16805]
simple_stmt [16791,16805]
===
match
---
trailer [22201,22206]
trailer [22198,22203]
===
match
---
argument [21790,21810]
argument [21787,21807]
===
match
---
param [19073,19078]
param [19070,19075]
===
match
---
funcdef [16915,18618]
funcdef [16915,18618]
===
match
---
operator: , [16325,16326]
operator: , [16325,16326]
===
match
---
name: self [24727,24731]
name: self [24851,24855]
===
match
---
name: str [8244,8247]
name: str [8244,8247]
===
match
---
tfpdef [17007,17021]
tfpdef [17007,17021]
===
match
---
name: items [15963,15968]
name: items [15963,15968]
===
match
---
suite [17679,17772]
suite [17679,17772]
===
match
---
name: delete_pod [23834,23844]
name: delete_pod [23858,23868]
===
match
---
name: name [16555,16559]
name: name [16555,16559]
===
match
---
simple_stmt [16080,16232]
simple_stmt [16080,16232]
===
match
---
trailer [23293,23317]
trailer [23317,23341]
===
match
---
name: debug [23156,23161]
name: debug [23153,23158]
===
match
---
name: self [15005,15009]
name: self [15005,15009]
===
match
---
if_stmt [10636,10761]
if_stmt [10636,10761]
===
match
---
operator: = [13020,13021]
operator: = [13020,13021]
===
match
---
name: id [13312,13314]
name: id [13312,13314]
===
match
---
dictorsetmaker [23009,23113]
dictorsetmaker [23006,23110]
===
match
---
name: cluster_context [14935,14950]
name: cluster_context [14935,14950]
===
match
---
arglist [24176,24223]
arglist [24300,24347]
===
match
---
fstring_string: found a running pod with labels  [17811,17843]
fstring_string: found a running pod with labels  [17811,17843]
===
match
---
atom_expr [22060,22077]
atom_expr [22057,22074]
===
match
---
trailer [19011,19025]
trailer [19008,19022]
===
match
---
atom_expr [24040,24078]
atom_expr [24164,24202]
===
match
---
operator: = [25395,25396]
operator: = [25571,25572]
===
match
---
operator: , [17005,17006]
operator: , [17005,17006]
===
match
---
argument [14993,15021]
argument [14993,15021]
===
match
---
argument [23273,23317]
argument [23297,23341]
===
match
---
atom [13864,14065]
atom [13864,14065]
===
match
---
name: V1EnvVar [8472,8480]
name: V1EnvVar [8472,8480]
===
match
---
trailer [10724,10727]
trailer [10724,10727]
===
match
---
simple_stmt [12805,12848]
simple_stmt [12805,12848]
===
match
---
name: tolerations [9411,9422]
name: tolerations [9411,9422]
===
match
---
tfpdef [9805,9837]
tfpdef [9805,9837]
===
match
---
operator: = [11317,11318]
operator: = [11317,11318]
===
match
---
name: annotations [11838,11849]
name: annotations [11838,11849]
===
match
---
atom [13378,13395]
atom [13378,13395]
===
match
---
name: log_events_on_failure [9724,9745]
name: log_events_on_failure [9724,9745]
===
match
---
tfpdef [13135,13166]
tfpdef [13135,13166]
===
match
---
name: in_cluster [8609,8619]
name: in_cluster [8609,8619]
===
match
---
atom [12451,12453]
atom [12451,12453]
===
match
---
name: pod [22017,22020]
name: pod [22014,22017]
===
match
---
operator: , [9895,9896]
operator: , [9895,9896]
===
match
---
name: pod [17007,17010]
name: pod [17007,17010]
===
match
---
name: name [25351,25355]
name: name [25527,25531]
===
match
---
operator: = [10919,10920]
operator: = [10919,10920]
===
match
---
import_from [1071,1118]
import_from [1071,1118]
===
match
---
trailer [21802,21810]
trailer [21799,21807]
===
match
---
atom_expr [19398,19410]
atom_expr [19395,19407]
===
match
---
atom_expr [9578,9591]
atom_expr [9578,9591]
===
match
---
string: '-' [23057,23060]
string: '-' [23054,23057]
===
match
---
suite [23955,24225]
suite [24079,24349]
===
match
---
operator: = [15243,15244]
operator: = [15243,15244]
===
match
---
name: self [24967,24971]
name: self [25091,25095]
===
match
---
operator: = [23408,23409]
operator: = [23432,23433]
===
match
---
simple_stmt [7793,7978]
simple_stmt [7793,7978]
===
match
---
name: reason [23634,23640]
name: reason [23658,23664]
===
match
---
name: hostnetwork [9376,9387]
name: hostnetwork [9376,9387]
===
match
---
trailer [18454,18458]
trailer [18454,18458]
===
match
---
param [9153,9190]
param [9153,9190]
===
match
---
testlist [23870,23901]
testlist [23994,24025]
===
match
---
name: remote_pod [16374,16384]
name: remote_pod [16374,16384]
===
match
---
simple_stmt [15231,15252]
simple_stmt [15231,15252]
===
match
---
name: Optional [9122,9130]
name: Optional [9122,9130]
===
match
---
name: remote_pod [16582,16592]
name: remote_pod [16582,16592]
===
match
---
name: launcher [23244,23252]
name: launcher [23268,23276]
===
match
---
name: create_pod_launcher [14548,14567]
name: create_pod_launcher [14548,14567]
===
match
---
trailer [14145,14155]
trailer [14145,14155]
===
match
---
operator: , [16990,16991]
operator: , [16990,16991]
===
match
---
operator: { [25397,25398]
operator: { [25573,25574]
===
match
---
atom_expr [19989,20050]
atom_expr [19986,20047]
===
match
---
trailer [10569,10578]
trailer [10569,10578]
===
match
---
if_stmt [15947,16446]
if_stmt [15947,16446]
===
match
---
operator: , [8131,8132]
operator: , [8131,8132]
===
match
---
operator: , [21619,21620]
operator: , [21616,21617]
===
match
---
expr_stmt [10502,10556]
expr_stmt [10502,10556]
===
match
---
operator: , [18497,18498]
operator: , [18497,18498]
===
match
---
tfpdef [8561,8592]
tfpdef [8561,8592]
===
match
---
if_stmt [15689,15883]
if_stmt [15689,15883]
===
match
---
name: self [15720,15724]
name: self [15720,15724]
===
match
---
operator: = [12045,12046]
operator: = [12045,12046]
===
match
---
atom_expr [8669,8682]
atom_expr [8669,8682]
===
match
---
name: patch_already_checked [23911,23932]
name: patch_already_checked [24035,24056]
===
match
---
name: pod [22222,22225]
name: pod [22219,22222]
===
match
---
operator: , [23881,23882]
operator: , [24005,24006]
===
match
---
name: launcher [23365,23373]
name: launcher [23389,23397]
===
match
---
name: image_pull_policy [8855,8872]
name: image_pull_policy [8855,8872]
===
match
---
suite [11727,11775]
suite [11727,11775]
===
match
---
param [9659,9715]
param [9659,9715]
===
match
---
name: pod [13005,13008]
name: pod [13005,13008]
===
match
---
atom_expr [19719,19741]
atom_expr [19716,19738]
===
match
---
name: Optional [8340,8348]
name: Optional [8340,8348]
===
match
---
name: self [25283,25287]
name: self [25459,25463]
===
match
---
name: result [18611,18617]
name: result [18611,18617]
===
match
---
name: content [13369,13376]
name: content [13369,13376]
===
match
---
name: execute [14715,14722]
name: execute [14715,14722]
===
match
---
import_as_name [976,989]
import_as_name [976,989]
===
match
---
expr_stmt [10426,10458]
expr_stmt [10426,10458]
===
match
---
atom_expr [22673,22685]
atom_expr [22670,22682]
===
match
---
return_stmt [25162,25200]
return_stmt [25338,25376]
===
match
---
name: labels [14487,14493]
name: labels [14487,14493]
===
match
---
tfpdef [16992,17005]
tfpdef [16992,17005]
===
match
---
trailer [19130,19148]
trailer [19127,19145]
===
match
---
atom_expr [11521,11651]
atom_expr [11521,11651]
===
match
---
atom_expr [24645,24694]
atom_expr [24769,24818]
===
match
---
comparison [18992,19053]
comparison [18989,19050]
===
match
---
suite [15975,16232]
suite [15975,16232]
===
match
---
name: log [16271,16274]
name: log [16271,16274]
===
match
---
name: is_delete_operator_pod [24732,24754]
name: is_delete_operator_pod [24856,24878]
===
match
---
if_stmt [23704,23855]
if_stmt [23728,23979]
===
match
---
operator: , [20380,20381]
operator: , [20377,20378]
===
match
---
name: kubernetes [1348,1358]
name: kubernetes [1348,1358]
===
match
---
name: pod_runtime_info_envs [10639,10660]
name: pod_runtime_info_envs [10639,10660]
===
match
---
trailer [11744,11758]
trailer [11744,11758]
===
match
---
trailer [23151,23155]
trailer [23148,23152]
===
match
---
name: V1Pod [17016,17021]
name: V1Pod [17016,17021]
===
match
---
name: kwargs [10068,10074]
name: kwargs [10068,10074]
===
match
---
atom_expr [19755,19821]
atom_expr [19752,19818]
===
match
---
trailer [12239,12262]
trailer [12239,12262]
===
match
---
operator: = [12263,12264]
operator: = [12263,12264]
===
match
---
name: pod [24130,24133]
name: pod [24254,24257]
===
match
---
operator: = [15182,15183]
operator: = [15182,15183]
===
match
---
name: helpers [1847,1854]
name: helpers [1847,1854]
===
match
---
string: "Pod Event: %s - %s" [24982,25002]
string: "Pod Event: %s - %s" [25106,25126]
===
match
---
name: secrets [11176,11183]
name: secrets [11176,11183]
===
match
---
arglist [24666,24693]
arglist [24790,24817]
===
match
---
param [18963,18966]
param [18960,18963]
===
match
---
operator: = [10344,10345]
operator: = [10344,10345]
===
match
---
number: 1 [15714,15715]
number: 1 [15714,15715]
===
match
---
atom_expr [21852,21898]
atom_expr [21849,21895]
===
match
---
operator: , [15169,15170]
operator: , [15169,15170]
===
match
---
name: label_id [14494,14502]
name: label_id [14494,14502]
===
match
---
atom_expr [15460,15495]
atom_expr [15460,15495]
===
match
---
name: schedulername [9563,9576]
name: schedulername [9563,9576]
===
match
---
name: State [24823,24828]
name: State [24947,24952]
===
match
---
name: max_length [19338,19348]
name: max_length [19335,19345]
===
match
---
fstring_expr [17843,17851]
fstring_expr [17843,17851]
===
match
---
name: self [15335,15339]
name: self [15335,15339]
===
match
---
suite [20083,20130]
suite [20080,20127]
===
match
---
name: annotations [11852,11863]
name: annotations [11852,11863]
===
match
---
suite [11449,11700]
suite [11449,11700]
===
match
---
param [13176,13191]
param [13176,13191]
===
match
---
atom_expr [23198,23216]
atom_expr [23195,23213]
===
match
---
name: labels [16327,16333]
name: labels [16327,16333]
===
match
---
name: debug [22100,22105]
name: debug [22097,22102]
===
match
---
fstring_expr [18404,18412]
fstring_expr [18404,18412]
===
match
---
expr_stmt [24609,24694]
expr_stmt [24733,24818]
===
match
---
atom_expr [24727,24754]
atom_expr [24851,24878]
===
match
---
operator: , [1579,1580]
operator: , [1579,1580]
===
match
---
trailer [24981,25032]
trailer [25105,25156]
===
match
---
operator: = [8125,8126]
operator: = [8125,8126]
===
match
---
atom_expr [22314,22327]
atom_expr [22311,22324]
===
match
---
name: labels [17738,17744]
name: labels [17738,17744]
===
match
---
tfpdef [13176,13190]
tfpdef [13176,13190]
===
match
---
trailer [22677,22685]
trailer [22674,22682]
===
match
---
expr_stmt [11208,11236]
expr_stmt [11208,11236]
===
match
---
operator: = [20693,20694]
operator: = [20690,20691]
===
match
---
atom_expr [18021,18045]
atom_expr [18021,18045]
===
match
---
trailer [11296,11316]
trailer [11296,11316]
===
match
---
name: get_logs [23414,23422]
name: get_logs [23438,23446]
===
match
---
trailer [11384,11402]
trailer [11384,11402]
===
match
---
simple_stmt [18486,18571]
simple_stmt [18486,18571]
===
match
---
param [8499,8552]
param [8499,8552]
===
match
---
name: convert_configmap [10857,10874]
name: convert_configmap [10857,10874]
===
match
---
name: List [8239,8243]
name: List [8239,8243]
===
match
---
name: State [16476,16481]
name: State [16476,16481]
===
match
---
name: SUCCESS [16482,16489]
name: SUCCESS [16482,16489]
===
match
---
operator: , [7843,7844]
operator: , [7843,7844]
===
match
---
string: "True" [24081,24087]
string: "True" [24205,24211]
===
match
---
name: self [11380,11384]
name: self [11380,11384]
===
match
---
name: namespace [25606,25615]
name: namespace [25782,25791]
===
match
---
atom_expr [23529,23569]
atom_expr [23553,23593]
===
match
---
trailer [10108,10112]
trailer [10108,10112]
===
match
---
argument [15133,15169]
argument [15133,15169]
===
match
---
simple_stmt [16608,16689]
simple_stmt [16608,16689]
===
match
---
name: V1Pod [20175,20180]
name: V1Pod [20172,20177]
===
match
---
dotted_name [1658,1723]
dotted_name [1658,1723]
===
match
---
operator: ** [25617,25619]
operator: ** [25793,25795]
===
match
---
trailer [14138,14145]
trailer [14138,14145]
===
match
---
suite [17070,18618]
suite [17070,18618]
===
match
---
arglist [14649,14704]
arglist [14649,14704]
===
match
---
name: Optional [8111,8119]
name: Optional [8111,8119]
===
match
---
fstring [16879,16908]
fstring [16879,16908]
===
match
---
operator: , [21409,21410]
operator: , [21406,21407]
===
match
---
atom_expr [14427,14474]
atom_expr [14427,14474]
===
match
---
operator: , [9189,9190]
operator: , [9189,9190]
===
match
---
atom_expr [12856,12865]
atom_expr [12856,12865]
===
match
---
operator: = [9547,9548]
operator: = [9547,9548]
===
match
---
for_stmt [24897,25033]
for_stmt [25021,25157]
===
match
---
trailer [12695,12717]
trailer [12695,12717]
===
match
---
tfpdef [8780,8808]
tfpdef [8780,8808]
===
match
---
suite [24711,24797]
suite [24835,24921]
===
match
---
simple_stmt [11833,11870]
simple_stmt [11833,11870]
===
match
---
simple_stmt [18985,19054]
simple_stmt [18982,19051]
===
match
---
operator: = [8428,8429]
operator: = [8428,8429]
===
match
---
trailer [14209,14220]
trailer [14209,14220]
===
match
---
name: dict [16961,16965]
name: dict [16961,16965]
===
match
---
name: ports [20978,20983]
name: ports [20975,20980]
===
match
---
suite [10090,13027]
suite [10090,13027]
===
match
---
name: _set_name [19063,19072]
name: _set_name [19060,19069]
===
match
---
trailer [13368,13427]
trailer [13368,13427]
===
match
---
trailer [12182,12203]
trailer [12182,12203]
===
match
---
trailer [19875,19898]
trailer [19872,19895]
===
match
---
name: create_labels_for_pod [15465,15486]
name: create_labels_for_pod [15465,15486]
===
match
---
name: volume_mounts [8325,8338]
name: volume_mounts [8325,8338]
===
match
---
param [24271,24274]
param [24395,24398]
===
match
---
simple_stmt [13456,13593]
simple_stmt [13456,13593]
===
match
---
name: self [22775,22779]
name: self [22772,22776]
===
match
---
name: pod_generator [14427,14440]
name: pod_generator [14427,14440]
===
match
---
name: Dict [8926,8930]
name: Dict [8926,8930]
===
match
---
atom_expr [11245,11265]
atom_expr [11245,11265]
===
match
---
suite [14608,14706]
suite [14608,14706]
===
match
---
trailer [17047,17053]
trailer [17047,17053]
===
match
---
expr_stmt [12805,12847]
expr_stmt [12805,12847]
===
match
---
name: convert_env_vars [10581,10597]
name: convert_env_vars [10581,10597]
===
match
---
atom_expr [9022,9046]
atom_expr [9022,9046]
===
match
---
trailer [24939,24945]
trailer [25063,25069]
===
match
---
operator: , [16384,16385]
operator: , [16384,16385]
===
match
---
argument [23400,23422]
argument [23424,23446]
===
match
---
name: secrets [21927,21934]
name: secrets [21924,21931]
===
match
---
atom [11097,11143]
atom [11097,11143]
===
match
---
trailer [12339,12351]
trailer [12339,12351]
===
match
---
name: self [22140,22144]
name: self [22137,22141]
===
match
---
funcdef [19059,19412]
funcdef [19056,19409]
===
match
---
import_from [1875,1912]
import_from [1875,1912]
===
match
---
arglist [16643,16687]
arglist [16643,16687]
===
match
---
name: k8s [17044,17047]
name: k8s [17044,17047]
===
match
---
arglist [19376,19410]
arglist [19373,19407]
===
match
---
trailer [11910,11920]
trailer [11910,11920]
===
match
---
atom_expr [14898,14913]
atom_expr [14898,14913]
===
match
---
operator: , [20909,20910]
operator: , [20906,20907]
===
match
---
param [8652,8690]
param [8652,8690]
===
match
---
operator: = [16664,16665]
operator: = [16664,16665]
===
match
---
name: self [10674,10678]
name: self [10674,10678]
===
match
---
name: Tuple [22290,22295]
name: Tuple [22287,22292]
===
match
---
atom [12354,12416]
atom [12354,12416]
===
match
---
name: p [10942,10943]
name: p [10942,10943]
===
match
---
operator: , [14971,14972]
operator: , [14971,14972]
===
match
---
trailer [8238,8249]
trailer [8238,8249]
===
match
---
name: self [15183,15187]
name: self [15183,15187]
===
match
---
atom_expr [22023,22048]
atom_expr [22020,22045]
===
match
---
trailer [10364,10374]
trailer [10364,10374]
===
match
---
name: launcher [16335,16343]
name: launcher [16335,16343]
===
match
---
operator: = [10375,10376]
operator: = [10375,10376]
===
match
---
name: Optional [9219,9227]
name: Optional [9219,9227]
===
match
---
name: Optional [8621,8629]
name: Optional [8621,8629]
===
match
---
arglist [20856,21309]
arglist [20853,21306]
===
match
---
param [8444,8490]
param [8444,8490]
===
match
---
name: k8s [9031,9034]
name: k8s [9031,9034]
===
match
---
suite [14755,16910]
suite [14755,16910]
===
match
---
name: delete_pod [24781,24791]
name: delete_pod [24905,24915]
===
match
---
atom_expr [20511,20527]
atom_expr [20508,20524]
===
match
---
name: reattach_on_restart [11297,11316]
name: reattach_on_restart [11297,11316]
===
match
---
name: TYPE_CHECKING [1972,1985]
name: TYPE_CHECKING [1972,1985]
===
match
---
operator: , [23793,23794]
operator: , [23817,23818]
===
match
---
name: staticmethod [18914,18926]
name: staticmethod [18911,18923]
===
match
---
name: pod [22044,22047]
name: pod [22041,22044]
===
match
---
name: is_delete_operator_pod [23712,23734]
name: is_delete_operator_pod [23736,23758]
===
match
---
name: make_unique_pod_id [20452,20470]
name: make_unique_pod_id [20449,20467]
===
match
---
operator: , [13376,13377]
operator: , [13376,13377]
===
match
---
atom_expr [21386,21409]
atom_expr [21383,21406]
===
match
---
trailer [11837,11849]
trailer [11837,11849]
===
match
---
operator: , [920,921]
operator: , [920,921]
===
match
---
operator: , [9002,9003]
operator: , [9002,9003]
===
match
---
arglist [20259,21826]
arglist [20256,21823]
===
match
---
trailer [24665,24694]
trailer [24789,24818]
===
match
---
simple_stmt [15451,15496]
simple_stmt [15451,15496]
===
match
---
fstring [15806,15864]
fstring [15806,15864]
===
match
---
atom_expr [9168,9182]
atom_expr [9168,9182]
===
match
---
atom_expr [20651,20664]
atom_expr [20648,20661]
===
match
---
name: List [8463,8467]
name: List [8463,8467]
===
match
---
atom_expr [25508,25537]
atom_expr [25684,25713]
===
match
---
operator: { [22991,22992]
operator: { [22988,22989]
===
match
---
trailer [10855,10899]
trailer [10855,10899]
===
match
---
atom_expr [12335,12351]
atom_expr [12335,12351]
===
match
---
atom_expr [20405,20416]
atom_expr [20402,20413]
===
match
---
funcdef [14544,14706]
funcdef [14544,14706]
===
match
---
trailer [23155,23161]
trailer [23152,23158]
===
match
---
trailer [23756,23760]
trailer [23780,23784]
===
match
---
name: pod_template_file [12830,12847]
name: pod_template_file [12830,12847]
===
match
---
atom [11071,11073]
atom [11071,11073]
===
match
---
name: log [23152,23155]
name: log [23149,23152]
===
match
---
trailer [15343,15352]
trailer [15343,15352]
===
match
---
name: self [12805,12809]
name: self [12805,12809]
===
match
---
name: volumes [8390,8397]
name: volumes [8390,8397]
===
match
---
simple_stmt [11347,11372]
simple_stmt [11347,11372]
===
match
---
atom_expr [20471,20480]
atom_expr [20468,20477]
===
match
---
suite [19110,19310]
suite [19107,19307]
===
match
---
trailer [14493,14503]
trailer [14493,14503]
===
match
---
operator: = [8309,8310]
operator: = [8309,8310]
===
match
---
name: p [10732,10733]
name: p [10732,10733]
===
match
---
name: priority_class_name [12777,12796]
name: priority_class_name [12777,12796]
===
match
---
arglist [16736,16777]
arglist [16736,16777]
===
match
---
trailer [22095,22099]
trailer [22092,22096]
===
match
---
operator: = [16646,16647]
operator: = [16646,16647]
===
match
---
or_test [19126,19170]
or_test [19123,19167]
===
match
---
simple_stmt [15762,15883]
simple_stmt [15762,15883]
===
match
---
name: self [11292,11296]
name: self [11292,11296]
===
match
---
operator: , [1538,1539]
operator: , [1538,1539]
===
match
---
name: self [10502,10506]
name: self [10502,10506]
===
match
---
expr_stmt [10565,10627]
expr_stmt [10565,10627]
===
match
---
operator: , [8042,8043]
operator: , [8042,8043]
===
match
---
operator: = [20902,20903]
operator: = [20899,20900]
===
match
---
atom_expr [23289,23317]
atom_expr [23313,23341]
===
match
---
trailer [15530,15564]
trailer [15530,15564]
===
match
---
name: final_state [24808,24819]
name: final_state [24932,24943]
===
match
---
operator: , [9714,9715]
operator: , [9714,9715]
===
match
---
trailer [25071,25076]
trailer [25247,25252]
===
match
---
operator: = [9090,9091]
operator: = [9090,9091]
===
match
---
operator: , [21308,21309]
operator: , [21305,21306]
===
match
---
operator: , [13957,13958]
operator: , [13957,13958]
===
match
---
suite [13659,14539]
suite [13659,14539]
===
match
---
arglist [15133,15199]
arglist [15133,15199]
===
match
---
operator: = [21447,21448]
operator: = [21444,21445]
===
match
---
param [16967,16991]
param [16967,16991]
===
match
---
sync_comp_for [12386,12415]
sync_comp_for [12386,12415]
===
match
---
argument [14935,14971]
argument [14935,14971]
===
match
---
fstring_string: Pod Launching failed:  [16881,16903]
fstring_string: Pod Launching failed:  [16881,16903]
===
match
---
simple_stmt [935,990]
simple_stmt [935,990]
===
match
---
name: result [23356,23362]
name: result [23380,23386]
===
match
---
name: arguments [21208,21217]
name: arguments [21205,21214]
===
match
---
name: self [19126,19130]
name: self [19123,19127]
===
match
---
operator: = [17807,17808]
operator: = [17807,17808]
===
match
---
atom_expr [16763,16777]
atom_expr [16763,16777]
===
match
---
dotted_name [1124,1142]
dotted_name [1124,1142]
===
match
---
trailer [15464,15486]
trailer [15464,15486]
===
match
---
name: self [10565,10569]
name: self [10565,10569]
===
match
---
name: self [12335,12339]
name: self [12335,12339]
===
match
---
tfpdef [9199,9261]
tfpdef [9199,9261]
===
match
---
name: Optional [9022,9030]
name: Optional [9022,9030]
===
match
---
name: kwargs [25388,25394]
name: kwargs [25564,25570]
===
match
---
atom_expr [15526,15572]
atom_expr [15526,15572]
===
match
---
name: pod [24792,24795]
name: pod [24916,24919]
===
match
---
operator: , [20299,20300]
operator: , [20296,20297]
===
match
---
operator: , [11617,11618]
operator: , [11617,11618]
===
match
---
operator: , [24621,24622]
operator: , [24745,24746]
===
match
---
tfpdef [8325,8373]
tfpdef [8325,8373]
===
match
---
trailer [23558,23562]
trailer [23582,23586]
===
match
---
atom [11160,11162]
atom [11160,11162]
===
match
---
name: V1Pod [17048,17053]
name: V1Pod [17048,17053]
===
match
---
name: env_vars [10679,10687]
name: env_vars [10679,10687]
===
match
---
string: "Pod" [20294,20299]
string: "Pod" [20291,20296]
===
match
---
expr_stmt [13855,14065]
expr_stmt [13855,14065]
===
match
---
name: convert_image_pull_secrets [12093,12119]
name: convert_image_pull_secrets [12093,12119]
===
match
---
import_name [1058,1069]
import_name [1058,1069]
===
match
---
argument [20556,21825]
argument [20553,21822]
===
match
---
name: arguments [10443,10452]
name: arguments [10443,10452]
===
match
---
operator: , [18332,18333]
operator: , [18332,18333]
===
match
---
name: str [14750,14753]
name: str [14750,14753]
===
match
---
operator: = [16010,16011]
operator: = [16010,16011]
===
match
---
name: image_pull_secrets [21367,21385]
name: image_pull_secrets [21364,21382]
===
match
---
name: convert_image_pull_secrets [1478,1504]
name: convert_image_pull_secrets [1478,1504]
===
match
---
name: pod_template_file [9805,9822]
name: pod_template_file [9805,9822]
===
match
---
trailer [20574,21825]
trailer [20571,21822]
===
match
---
simple_stmt [22215,22226]
simple_stmt [22212,22223]
===
match
---
name: pod_list [16045,16053]
name: pod_list [16045,16053]
===
match
---
atom_expr [8239,8248]
atom_expr [8239,8248]
===
match
---
trailer [18767,18773]
trailer [18791,18797]
===
match
---
atom_expr [13010,13019]
atom_expr [13010,13019]
===
match
---
operator: } [12018,12019]
operator: } [12018,12019]
===
match
---
name: volume_mounts [21159,21172]
name: volume_mounts [21156,21169]
===
match
---
string: "grace_period_seconds" [25484,25506]
string: "grace_period_seconds" [25660,25682]
===
match
---
simple_stmt [23752,23809]
simple_stmt [23776,23833]
===
match
---
name: self [11833,11837]
name: self [11833,11837]
===
match
---
name: AirflowException [23439,23455]
name: AirflowException [23463,23479]
===
match
---
trailer [14849,14865]
trailer [14849,14865]
===
match
---
atom_expr [20236,21836]
atom_expr [20233,21833]
===
match
---
name: self [20471,20475]
name: self [20468,20472]
===
match
---
atom [12017,12019]
atom [12017,12019]
===
match
---
name: self [25415,25419]
name: self [25591,25595]
===
match
---
expr_stmt [15896,15933]
expr_stmt [15896,15933]
===
match
---
if_stmt [11431,11825]
if_stmt [11431,11825]
===
match
---
name: log_line [17798,17806]
name: log_line [17798,17806]
===
match
---
trailer [8925,8931]
trailer [8925,8931]
===
match
---
trailer [22970,22977]
trailer [22967,22974]
===
match
---
name: List [9928,9932]
name: List [9928,9932]
===
match
---
atom_expr [14582,14606]
atom_expr [14582,14606]
===
match
---
name: create_pod_request_obj [19421,19443]
name: create_pod_request_obj [19418,19440]
===
match
---
name: try_numbers_match [16967,16984]
name: try_numbers_match [16967,16984]
===
match
---
name: self [11082,11086]
name: self [11082,11086]
===
match
---
operator: , [14913,14914]
operator: , [14913,14914]
===
match
---
operator: , [13102,13103]
operator: , [13102,13103]
===
match
---
atom_expr [25244,25252]
atom_expr [25420,25428]
===
match
---
sync_comp_for [10878,10897]
sync_comp_for [10878,10897]
===
match
---
name: V1VolumeMount [8358,8371]
name: V1VolumeMount [8358,8371]
===
match
---
trailer [18073,18077]
trailer [18073,18077]
===
match
---
name: context [14195,14202]
name: context [14195,14202]
===
match
---
atom_expr [8192,8201]
atom_expr [8192,8201]
===
match
---
name: do_xcom_push [9769,9781]
name: do_xcom_push [9769,9781]
===
match
---
name: labels [15451,15457]
name: labels [15451,15457]
===
match
---
atom_expr [19849,19922]
atom_expr [19846,19919]
===
match
---
name: V1Pod [23948,23953]
name: V1Pod [24072,24077]
===
match
---
name: launcher [16186,16194]
name: launcher [16186,16194]
===
match
---
trailer [10296,10309]
trailer [10296,10309]
===
match
---
test [12093,12169]
test [12093,12169]
===
match
---
name: labels [17844,17850]
name: labels [17844,17850]
===
match
---
atom [12680,12682]
atom [12680,12682]
===
match
---
string: "v1" [20271,20275]
string: "v1" [20268,20272]
===
match
---
name: node_selector [11713,11726]
name: node_selector [11713,11726]
===
match
---
param [9905,9959]
param [9905,9959]
===
match
---
trailer [10773,10782]
trailer [10773,10782]
===
match
---
expr_stmt [12856,12888]
expr_stmt [12856,12888]
===
match
---
arglist [16159,16213]
arglist [16159,16213]
===
match
---
param [9473,9513]
param [9473,9513]
===
match
---
dotted_name [1285,1299]
dotted_name [1285,1299]
===
match
---
name: context [13888,13895]
name: context [13888,13895]
===
match
---
simple_stmt [12856,12889]
simple_stmt [12856,12889]
===
match
---
name: airflow_version [23028,23043]
name: airflow_version [23025,23040]
===
match
---
name: termination_grace_period [12902,12926]
name: termination_grace_period [12902,12926]
===
match
---
argument [20728,20764]
argument [20725,20761]
===
match
---
atom_expr [10102,10125]
atom_expr [10102,10125]
===
match
---
simple_stmt [25474,25539]
simple_stmt [25650,25715]
===
match
---
string: 'labels' [7910,7918]
string: 'labels' [7910,7918]
===
match
---
trailer [23267,23271]
trailer [23291,23295]
===
match
---
name: convert_pod_runtime_info_env [10696,10724]
name: convert_pod_runtime_info_env [10696,10724]
===
match
---
parameters [16937,17027]
parameters [16937,17027]
===
match
---
decorator [13598,13612]
decorator [13598,13612]
===
match
---
or_test [10481,10493]
or_test [10481,10493]
===
match
---
trailer [11175,11183]
trailer [11175,11183]
===
match
---
param [8609,8643]
param [8609,8643]
===
match
---
name: tolerations [12404,12415]
name: tolerations [12404,12415]
===
match
---
trailer [15784,15882]
trailer [15784,15882]
===
match
---
trailer [25361,25370]
trailer [25537,25546]
===
match
---
simple_stmt [19629,19708]
simple_stmt [19626,19705]
===
match
---
name: context [13112,13119]
name: context [13112,13119]
===
match
---
trailer [8416,8425]
trailer [8416,8425]
===
match
---
trailer [18205,18209]
trailer [18205,18209]
===
match
---
subscriptlist [17037,17068]
subscriptlist [17037,17068]
===
match
---
name: _do_render_template_fields [13342,13368]
name: _do_render_template_fields [13342,13368]
===
match
---
param [22263,22268]
param [22260,22265]
===
match
---
name: self [24255,24259]
name: self [24379,24383]
===
match
---
name: yaml [23183,23187]
name: yaml [23180,23184]
===
match
---
suite [24837,25154]
suite [24961,25330]
===
match
---
suite [13206,13593]
suite [13206,13593]
===
match
---
name: image_pull_secrets [12072,12090]
name: image_pull_secrets [12072,12090]
===
match
---
operator: = [24643,24644]
operator: = [24767,24768]
===
match
---
name: convert_pod_runtime_info_env [1510,1538]
name: convert_pod_runtime_info_env [1510,1538]
===
match
---
atom [10797,10799]
atom [10797,10799]
===
match
---
operator: -> [17028,17030]
operator: -> [17028,17030]
===
match
---
atom_expr [8570,8592]
atom_expr [8570,8592]
===
match
---
param [19444,19448]
param [19441,19445]
===
match
---
atom_expr [20439,20481]
atom_expr [20436,20478]
===
match
---
name: self [25508,25512]
name: self [25684,25688]
===
match
---
operator: = [20650,20651]
operator: = [20647,20648]
===
match
---
name: pod [15340,15343]
name: pod [15340,15343]
===
match
---
operator: , [21349,21350]
operator: , [21346,21347]
===
match
---
trailer [23849,23853]
trailer [23873,23877]
===
match
---
operator: = [8088,8089]
operator: = [8088,8089]
===
match
---
atom [10491,10493]
atom [10491,10493]
===
match
---
name: env_vars [10570,10578]
name: env_vars [10570,10578]
===
match
---
name: Optional [22314,22322]
name: Optional [22311,22319]
===
match
---
expr_stmt [12235,12287]
expr_stmt [12235,12287]
===
match
---
name: full_pod_spec [20116,20129]
name: full_pod_spec [20113,20126]
===
match
---
name: create_new_pod_for_operator [16400,16427]
name: create_new_pod_for_operator [16400,16427]
===
match
---
simple_stmt [10674,10761]
simple_stmt [10674,10761]
===
match
---
name: resources [10257,10266]
name: resources [10257,10266]
===
match
---
name: namespace [25304,25313]
name: namespace [25480,25489]
===
match
---
name: remote_pod [24623,24633]
name: remote_pod [24747,24757]
===
match
---
param [8063,8095]
param [8063,8095]
===
match
---
trailer [22064,22077]
trailer [22061,22074]
===
match
---
expr_stmt [11245,11283]
expr_stmt [11245,11283]
===
match
---
atom_expr [15692,15711]
atom_expr [15692,15711]
===
match
---
trailer [14665,14672]
trailer [14665,14672]
===
match
---
suite [23231,23424]
suite [23255,23448]
===
match
---
operator: , [8256,8257]
operator: , [8256,8257]
===
match
---
name: self [20862,20866]
name: self [20859,20863]
===
match
---
trailer [8191,8202]
trailer [8191,8202]
===
match
---
name: self [21652,21656]
name: self [21649,21653]
===
match
---
name: client [25556,25562]
name: client [25732,25738]
===
match
---
name: volume [11125,11131]
name: volume [11125,11131]
===
match
---
name: pod [25072,25075]
name: pod [25248,25251]
===
match
---
operator: = [9592,9593]
operator: = [9592,9593]
===
match
---
expr_stmt [10292,10324]
expr_stmt [10292,10324]
===
match
---
name: pod [18248,18251]
name: pod [18248,18251]
===
match
---
classdef [2007,25627]
classdef [2007,25803]
===
match
---
name: re [19369,19371]
name: re [19366,19368]
===
match
---
operator: , [8380,8381]
operator: , [8380,8381]
===
match
---
testlist_comp [7836,7971]
testlist_comp [7836,7971]
===
match
---
name: final_state [16080,16091]
name: final_state [16080,16091]
===
match
---
parameters [18678,18686]
parameters [18678,18686]
===
match
---
simple_stmt [23964,24032]
simple_stmt [24088,24156]
===
match
---
name: full_pod_spec [20036,20049]
name: full_pod_spec [20033,20046]
===
match
---
name: affinity [20656,20664]
name: affinity [20653,20661]
===
match
---
name: metadata [24199,24207]
name: metadata [24323,24331]
===
match
---
trailer [13004,13008]
trailer [13004,13008]
===
match
---
name: startup_timeout_seconds [23294,23317]
name: startup_timeout_seconds [23318,23341]
===
match
---
operator: = [7824,7825]
operator: = [7824,7825]
===
match
---
atom_expr [16537,16559]
atom_expr [16537,16559]
===
match
---
trailer [16878,16909]
trailer [16878,16909]
===
match
---
name: extend [10688,10694]
name: extend [10688,10694]
===
match
---
string: 'env_vars' [7890,7900]
string: 'env_vars' [7890,7900]
===
match
---
trailer [21042,21060]
trailer [21039,21057]
===
match
---
expr_stmt [17798,17880]
expr_stmt [17798,17880]
===
match
---
operator: = [15148,15149]
operator: = [15148,15149]
===
match
---
decorated [13598,14539]
decorated [13598,14539]
===
match
---
exprlist [14367,14382]
exprlist [14367,14382]
===
match
---
expr_stmt [17692,17771]
expr_stmt [17692,17771]
===
match
---
name: metadata [16674,16682]
name: metadata [16674,16682]
===
match
---
name: self [10292,10296]
name: self [10292,10296]
===
match
---
operator: = [21294,21295]
operator: = [21291,21292]
===
match
---
name: id [13218,13220]
name: id [13218,13220]
===
match
---
trailer [18214,18224]
trailer [18214,18224]
===
match
---
suite [14156,14228]
suite [14156,14228]
===
match
---
string: 'pod_template_file' [7951,7970]
string: 'pod_template_file' [7951,7970]
===
match
---
name: metadata [18996,19004]
name: metadata [18993,19001]
===
match
---
name: self [11208,11212]
name: self [11208,11212]
===
match
---
name: models [1293,1299]
name: models [1293,1299]
===
match
---
param [13135,13167]
param [13135,13167]
===
match
---
name: str [24301,24304]
name: str [24425,24428]
===
match
---
trailer [20206,20219]
trailer [20203,20216]
===
match
---
string: 'dag' [14203,14208]
string: 'dag' [14203,14208]
===
match
---
operator: , [22301,22302]
operator: , [22298,22299]
===
match
---
name: self [20064,20068]
name: self [20061,20065]
===
match
---
atom_expr [21605,21619]
atom_expr [21602,21616]
===
match
---
name: context [14030,14037]
name: context [14030,14037]
===
match
---
atom_expr [10979,10997]
atom_expr [10979,10997]
===
match
---
atom_expr [13888,13909]
atom_expr [13888,13909]
===
match
---
trailer [18209,18214]
trailer [18209,18214]
===
match
---
atom [10968,10970]
atom [10968,10970]
===
match
---
simple_stmt [12462,12509]
simple_stmt [12462,12509]
===
match
---
atom_expr [8468,8480]
atom_expr [8468,8480]
===
match
---
atom_expr [14784,14799]
atom_expr [14784,14799]
===
match
---
name: bool [16986,16990]
name: bool [16986,16990]
===
match
---
test [11000,11073]
test [11000,11073]
===
match
---
name: context [14131,14138]
name: context [14131,14138]
===
match
---
operator: = [20270,20271]
operator: = [20267,20268]
===
match
---
name: self [10360,10364]
name: self [10360,10364]
===
match
---
simple_stmt [25089,25154]
simple_stmt [25265,25330]
===
match
---
name: labels [19005,19011]
name: labels [19002,19008]
===
match
---
name: reattach_on_restart [15725,15744]
name: reattach_on_restart [15725,15744]
===
match
---
trailer [10044,10049]
trailer [10044,10049]
===
match
---
name: init_containers [20728,20743]
name: init_containers [20725,20740]
===
match
---
param [9376,9402]
param [9376,9402]
===
match
---
name: resources [12002,12011]
name: resources [12002,12011]
===
match
---
trailer [12901,12926]
trailer [12901,12926]
===
match
---
expr_stmt [12517,12543]
expr_stmt [12517,12543]
===
match
---
operator: = [16112,16113]
operator: = [16112,16113]
===
match
---
name: self [23409,23413]
name: self [23433,23437]
===
match
---
name: self [21386,21390]
name: self [21383,21387]
===
match
---
atom_expr [25095,25153]
atom_expr [25271,25329]
===
match
---
operator: @ [13598,13599]
operator: @ [13598,13599]
===
match
---
sync_comp_for [11025,11047]
sync_comp_for [11025,11047]
===
match
---
string: 'ti' [19037,19041]
string: 'ti' [19034,19038]
===
match
---
atom_expr [24823,24836]
atom_expr [24947,24960]
===
match
---
name: cluster_context [15133,15148]
name: cluster_context [15133,15148]
===
match
---
trailer [20370,20380]
trailer [20367,20377]
===
match
---
trailer [8677,8682]
trailer [8677,8682]
===
match
---
name: pod [18992,18995]
name: pod [18989,18992]
===
match
---
operator: != [18788,18790]
operator: != [18813,18815]
===
match
---
operator: , [13190,13191]
operator: , [13190,13191]
===
match
---
string: 'value' [13379,13386]
string: 'value' [13379,13386]
===
match
---
test [11097,11162]
test [11097,11162]
===
match
---
atom_expr [21096,21114]
atom_expr [21093,21111]
===
match
---
operator: , [18275,18276]
operator: , [18275,18276]
===
match
---
trailer [9635,9641]
trailer [9635,9641]
===
match
---
name: security_context [12467,12483]
name: security_context [12467,12483]
===
match
---
name: image_pull_policy [21020,21037]
name: image_pull_policy [21017,21034]
===
match
---
expr_stmt [12638,12682]
expr_stmt [12638,12682]
===
match
---
name: termination_grace_period [12929,12953]
name: termination_grace_period [12929,12953]
===
match
---
name: log_line [18464,18472]
name: log_line [18464,18472]
===
match
---
trailer [20988,20994]
trailer [20985,20991]
===
match
---
name: self [19444,19448]
name: self [19441,19445]
===
match
---
name: self [22673,22677]
name: self [22670,22674]
===
match
---
name: startup_timeout_seconds [8780,8803]
name: startup_timeout_seconds [8780,8803]
===
match
---
operator: , [8642,8643]
operator: , [8642,8643]
===
match
---
argument [20782,21349]
argument [20779,21346]
===
match
---
operator: , [16103,16104]
operator: , [16103,16104]
===
match
---
atom [10856,10898]
atom [10856,10898]
===
match
---
tfpdef [8444,8482]
tfpdef [8444,8482]
===
match
---
atom_expr [8579,8591]
atom_expr [8579,8591]
===
match
---
atom_expr [8917,8931]
atom_expr [8917,8931]
===
match
---
atom_expr [21555,21576]
atom_expr [21552,21573]
===
match
---
atom_expr [19369,19411]
atom_expr [19366,19408]
===
match
---
name: self [21295,21299]
name: self [21292,21296]
===
match
---
operator: , [14672,14673]
operator: , [14672,14673]
===
match
---
name: metadata [22784,22792]
name: metadata [22781,22789]
===
match
---
name: ports [10913,10918]
name: ports [10913,10918]
===
match
---
dotted_name [1754,1793]
dotted_name [1754,1793]
===
match
---
param [22269,22276]
param [22266,22273]
===
match
---
operator: -> [24276,24278]
operator: -> [24400,24402]
===
match
---
name: ports [8266,8271]
name: ports [8266,8271]
===
match
---
suite [10822,10900]
suite [10822,10900]
===
match
---
name: full_pod_spec [12616,12629]
name: full_pod_spec [12616,12629]
===
match
---
trailer [15303,15305]
trailer [15303,15305]
===
match
---
name: monitor_pod [23374,23385]
name: monitor_pod [23398,23409]
===
match
---
expr_stmt [12028,12058]
expr_stmt [12028,12058]
===
match
---
arglist [23162,23217]
arglist [23159,23214]
===
match
---
operator: , [18597,18598]
operator: , [18597,18598]
===
match
---
trailer [13220,13229]
trailer [13220,13229]
===
match
---
name: self [11740,11744]
name: self [11740,11744]
===
match
---
name: k8s [20322,20325]
name: k8s [20319,20322]
===
match
---
operator: , [8845,8846]
operator: , [8845,8846]
===
match
---
atom_expr [19319,19353]
atom_expr [19316,19350]
===
match
---
name: env_vars [21252,21260]
name: env_vars [21249,21257]
===
match
---
name: self [16763,16767]
name: self [16763,16767]
===
match
---
simple_stmt [16507,16596]
simple_stmt [16507,16596]
===
match
---
expr_stmt [16080,16231]
expr_stmt [16080,16231]
===
match
---
trailer [25274,25280]
trailer [25450,25456]
===
match
---
operator: , [16091,16092]
operator: , [16091,16092]
===
match
---
operator: = [9457,9458]
operator: = [9457,9458]
===
match
---
atom_expr [14951,14971]
atom_expr [14951,14971]
===
match
---
param [18679,18685]
param [18679,18685]
===
match
---
arglist [25585,25625]
arglist [25761,25801]
===
match
---
trailer [8629,8635]
trailer [8629,8635]
===
match
---
trailer [8348,8373]
trailer [8348,8373]
===
match
---
name: CoreV1Api [12975,12984]
name: CoreV1Api [12975,12984]
===
match
---
atom_expr [9233,9259]
atom_expr [9233,9259]
===
match
---
atom_expr [9676,9707]
atom_expr [9676,9707]
===
match
---
name: Secret [1273,1279]
name: Secret [1273,1279]
===
match
---
name: self [12897,12901]
name: self [12897,12901]
===
match
---
name: error [23600,23605]
name: error [23624,23629]
===
match
---
operator: = [21153,21154]
operator: = [21150,21151]
===
match
---
fstring_expr [16536,16560]
fstring_expr [16536,16560]
===
match
---
atom_expr [15005,15021]
atom_expr [15005,15021]
===
match
---
atom_expr [15231,15242]
atom_expr [15231,15242]
===
match
---
trailer [16725,16735]
trailer [16725,16735]
===
match
---
name: V1Pod [25275,25280]
name: V1Pod [25451,25456]
===
match
---
name: _try_numbers_match [18935,18953]
name: _try_numbers_match [18932,18950]
===
match
---
name: launcher [23529,23537]
name: launcher [23553,23561]
===
match
---
name: V1LocalObjectReference [9237,9259]
name: V1LocalObjectReference [9237,9259]
===
match
---
operator: , [18961,18962]
operator: , [18958,18959]
===
match
---
name: node_selectors [9106,9120]
name: node_selectors [9106,9120]
===
match
---
name: yaml [1065,1069]
name: yaml [1065,1069]
===
match
---
trailer [20470,20481]
trailer [20467,20478]
===
match
---
simple_stmt [12595,12630]
simple_stmt [12595,12630]
===
match
---
simple_stmt [25388,25400]
simple_stmt [25564,25576]
===
match
---
trailer [9030,9046]
trailer [9030,9046]
===
match
---
operator: , [8689,8690]
operator: , [8689,8690]
===
match
---
expr_stmt [12750,12796]
expr_stmt [12750,12796]
===
match
---
name: PodLauncher [14637,14648]
name: PodLauncher [14637,14648]
===
match
---
trailer [20748,20764]
trailer [20745,20761]
===
match
---
atom_expr [8399,8427]
atom_expr [8399,8427]
===
match
---
testlist_star_expr [16080,16111]
testlist_star_expr [16080,16111]
===
match
---
atom_expr [10769,10782]
atom_expr [10769,10782]
===
match
---
name: bool [9354,9358]
name: bool [9354,9358]
===
match
---
name: super [10240,10245]
name: super [10240,10245]
===
match
---
name: result [18511,18517]
name: result [18511,18517]
===
match
---
name: name [19079,19083]
name: name [19076,19080]
===
match
---
atom_expr [14195,14227]
atom_expr [14195,14227]
===
match
---
comp_op [25445,25451]
comp_op [25621,25627]
===
match
---
name: Optional [8707,8715]
name: Optional [8707,8715]
===
match
---
param [13076,13081]
param [13076,13081]
===
match
---
name: launcher [24910,24918]
name: launcher [25034,25042]
===
match
---
expr_stmt [25304,25338]
expr_stmt [25480,25514]
===
match
---
trailer [20947,20952]
trailer [20944,20949]
===
match
---
trailer [24300,24305]
trailer [24424,24429]
===
match
---
param [8738,8771]
param [8738,8771]
===
match
---
trailer [9541,9546]
trailer [9541,9546]
===
match
---
name: labels [22807,22813]
name: labels [22804,22810]
===
match
---
trailer [25370,25375]
trailer [25546,25551]
===
match
---
operator: , [19077,19078]
operator: , [19074,19075]
===
match
---
name: Tuple [17031,17036]
name: Tuple [17031,17036]
===
match
---
operator: = [9506,9507]
operator: = [9506,9507]
===
match
---
simple_stmt [18237,18252]
simple_stmt [18237,18252]
===
match
---
simple_stmt [18264,18339]
simple_stmt [18264,18339]
===
match
---
name: ports [10957,10962]
name: ports [10957,10962]
===
match
---
name: full_pod_spec [9608,9621]
name: full_pod_spec [9608,9621]
===
match
---
name: log [23757,23760]
name: log [23781,23784]
===
match
---
name: k8s [8354,8357]
name: k8s [8354,8357]
===
match
---
name: annotations [8904,8915]
name: annotations [8904,8915]
===
match
---
operator: = [15905,15906]
operator: = [15905,15906]
===
match
---
atom [18721,18804]
atom [18719,18838]
===
match
---
string: "Deleting pod for task %s" [23767,23793]
string: "Deleting pod for task %s" [23791,23817]
===
match
---
trailer [22950,22954]
trailer [22947,22951]
===
match
---
trailer [9084,9089]
trailer [9084,9089]
===
match
---
simple_stmt [15265,15306]
simple_stmt [15265,15306]
===
match
---
atom_expr [23147,23218]
atom_expr [23144,23215]
===
match
---
param [19079,19083]
param [19076,19080]
===
match
---
param [8266,8316]
param [8266,8316]
===
match
---
test [11970,12019]
test [11970,12019]
===
match
---
atom_expr [10360,10374]
atom_expr [10360,10374]
===
match
---
name: arguments [10431,10440]
name: arguments [10431,10440]
===
match
---
testlist_comp [13379,13394]
testlist_comp [13379,13394]
===
match
---
atom_expr [12750,12774]
atom_expr [12750,12774]
===
match
---
atom_expr [25045,25076]
atom_expr [25221,25252]
===
match
---
name: re [832,834]
name: re [832,834]
===
match
---
if_stmt [23469,23657]
if_stmt [23493,23681]
===
match
---
atom_expr [15768,15882]
atom_expr [15768,15882]
===
match
---
name: value [16757,16762]
name: value [16757,16762]
===
match
---
trailer [19723,19741]
trailer [19720,19738]
===
match
---
operator: = [11968,11969]
operator: = [11968,11969]
===
match
---
param [13642,13649]
param [13642,13649]
===
match
---
string: 'task_id' [13923,13932]
string: 'task_id' [13923,13932]
===
match
---
trailer [8412,8426]
trailer [8412,8426]
===
match
---
argument [23386,23398]
argument [23410,23422]
===
match
---
name: V1ContainerPort [8291,8306]
name: V1ContainerPort [8291,8306]
===
match
---
suite [14401,14517]
suite [14401,14517]
===
match
---
name: Optional [8399,8407]
name: Optional [8399,8407]
===
match
---
name: parent_dag [14210,14220]
name: parent_dag [14210,14220]
===
match
---
argument [20259,20275]
argument [20256,20272]
===
match
---
atom_expr [23554,23562]
atom_expr [23578,23586]
===
match
---
suite [995,1034]
suite [995,1034]
===
match
---
trailer [12872,12882]
trailer [12872,12882]
===
match
---
atom_expr [20111,20129]
atom_expr [20108,20126]
===
match
---
atom_expr [8959,8995]
atom_expr [8959,8995]
===
match
---
operator: } [11823,11824]
operator: } [11823,11824]
===
match
---
testlist_star_expr [18264,18295]
testlist_star_expr [18264,18295]
===
match
---
atom_expr [8874,8887]
atom_expr [8874,8887]
===
match
---
simple_stmt [25304,25339]
simple_stmt [25480,25515]
===
match
---
trailer [11953,11967]
trailer [11953,11967]
===
match
---
import_as_names [1411,1650]
import_as_names [1411,1650]
===
match
---
name: str [8156,8159]
name: str [8156,8159]
===
match
---
param [16947,16952]
param [16947,16952]
===
match
---
name: namespace [20371,20380]
name: namespace [20368,20377]
===
match
---
simple_stmt [19755,19822]
simple_stmt [19752,19819]
===
match
---
name: security_context [21538,21554]
name: security_context [21535,21551]
===
match
---
operator: , [21825,21826]
operator: , [21822,21823]
===
match
---
expr_stmt [22017,22048]
expr_stmt [22014,22045]
===
match
---
name: Optional [9533,9541]
name: Optional [9533,9541]
===
match
---
name: self [24853,24857]
name: self [24977,24981]
===
match
---
atom_expr [11347,11360]
atom_expr [11347,11360]
===
match
---
trailer [23766,23808]
trailer [23790,23832]
===
match
---
name: self [21203,21207]
name: self [21200,21204]
===
match
---
exprlist [18742,18757]
exprlist [18759,18774]
===
match
---
operator: = [11361,11362]
operator: = [11361,11362]
===
match
---
name: init_containers [12643,12658]
name: init_containers [12643,12658]
===
match
---
fstring_string: found a running pod with labels  [17705,17737]
fstring_string: found a running pod with labels  [17705,17737]
===
match
---
name: result [23895,23901]
name: result [24019,24025]
===
match
---
name: k8s [20815,20818]
name: k8s [20812,20815]
===
match
---
operator: , [13395,13396]
operator: , [13395,13396]
===
match
---
operator: = [8636,8637]
operator: = [8636,8637]
===
match
---
trailer [19942,19956]
trailer [19939,19953]
===
match
---
name: image_pull_policy [11385,11402]
name: image_pull_policy [11385,11402]
===
match
---
name: labels [22269,22275]
name: labels [22266,22272]
===
match
---
atom [10456,10458]
atom [10456,10458]
===
match
---
name: remote_pod [18599,18609]
name: remote_pod [18599,18609]
===
match
---
name: message [23648,23655]
name: message [23672,23679]
===
match
---
operator: = [11759,11760]
operator: = [11759,11760]
===
match
---
operator: = [20189,20190]
operator: = [20186,20187]
===
match
---
name: tolerations [12434,12445]
name: tolerations [12434,12445]
===
match
---
trailer [14594,14606]
trailer [14594,14606]
===
match
---
atom [10921,10953]
atom [10921,10953]
===
match
---
expr_stmt [11833,11869]
expr_stmt [11833,11869]
===
match
---
operator: { [11867,11868]
operator: { [11867,11868]
===
match
---
atom_expr [15950,15969]
atom_expr [15950,15969]
===
match
---
param [22277,22285]
param [22274,22282]
===
match
---
atom_expr [11949,11967]
atom_expr [11949,11967]
===
match
---
atom_expr [15149,15169]
atom_expr [15149,15169]
===
match
---
trailer [12556,12570]
trailer [12556,12570]
===
match
---
simple_stmt [19472,19621]
simple_stmt [19469,19618]
===
match
---
tfpdef [8390,8427]
tfpdef [8390,8427]
===
match
---
atom_expr [13218,13229]
atom_expr [13218,13229]
===
match
---
param [23939,23953]
param [24063,24077]
===
match
---
string: "jinja2.Environment" [13146,13166]
string: "jinja2.Environment" [13146,13166]
===
match
---
tfpdef [8499,8544]
tfpdef [8499,8544]
===
match
---
atom_expr [22290,22328]
atom_expr [22287,22325]
===
match
---
suite [10661,10761]
suite [10661,10761]
===
match
---
trailer [14691,14704]
trailer [14691,14704]
===
match
---
name: Optional [9824,9832]
name: Optional [9824,9832]
===
match
---
name: labels [16953,16959]
name: labels [16953,16959]
===
match
---
name: List [9433,9437]
name: List [9433,9437]
===
match
---
name: volumes [11147,11154]
name: volumes [11147,11154]
===
match
---
suite [2049,25627]
suite [2049,25803]
===
match
---
trailer [9883,9888]
trailer [9883,9888]
===
match
---
expr_stmt [21846,21898]
expr_stmt [21843,21895]
===
match
---
name: self [20111,20115]
name: self [20108,20112]
===
match
---
name: env_vars [10598,10606]
name: env_vars [10598,10606]
===
match
---
name: patch_namespaced_pod [24155,24175]
name: patch_namespaced_pod [24279,24299]
===
match
---
atom_expr [19694,19706]
atom_expr [19691,19703]
===
match
---
trailer [19903,19921]
trailer [19900,19918]
===
match
---
name: self [20511,20515]
name: self [20508,20512]
===
match
---
string: 'try_number' [18791,18803]
string: 'try_number' [18816,18828]
===
match
---
operator: = [16393,16394]
operator: = [16393,16394]
===
match
---
name: content [13315,13322]
name: content [13315,13322]
===
match
---
param [14723,14728]
param [14723,14728]
===
match
---
operator: = [12614,12615]
operator: = [12614,12615]
===
match
---
name: V1Toleration [9442,9454]
name: V1Toleration [9442,9454]
===
match
---
operator: = [12927,12928]
operator: = [12927,12928]
===
match
---
trailer [21207,21217]
trailer [21204,21214]
===
match
---
operator: , [20994,20995]
operator: , [20991,20992]
===
match
---
name: Optional [9168,9176]
name: Optional [9168,9176]
===
match
---
not_test [18050,18096]
not_test [18050,18096]
===
match
---
operator: , [25594,25595]
operator: , [25770,25771]
===
match
---
atom_expr [20366,20380]
atom_expr [20363,20377]
===
match
---
name: image_pull_secrets [12143,12161]
name: image_pull_secrets [12143,12161]
===
match
---
atom_expr [18237,18245]
atom_expr [18237,18245]
===
match
---
trailer [24653,24665]
trailer [24777,24789]
===
match
---
name: items [16205,16210]
name: items [16205,16210]
===
match
---
param [14729,14736]
param [14729,14736]
===
match
---
name: pod_runtime_info_envs [9905,9926]
name: pod_runtime_info_envs [9905,9926]
===
match
---
name: self [16537,16541]
name: self [16537,16541]
===
match
---
trailer [24918,24934]
trailer [25042,25058]
===
match
---
trailer [20245,21836]
trailer [20242,21833]
===
match
---
suite [21935,22049]
suite [21932,22046]
===
match
---
atom_expr [8463,8481]
atom_expr [8463,8481]
===
match
---
string: 'try_number' [14016,14028]
string: 'try_number' [14016,14028]
===
match
---
operator: = [8809,8810]
operator: = [8809,8810]
===
match
---
name: log [23596,23599]
name: log [23620,23623]
===
match
---
atom_expr [8287,8306]
atom_expr [8287,8306]
===
match
---
atom_expr [13000,13008]
atom_expr [13000,13008]
===
match
---
suite [25457,25539]
suite [25633,25715]
===
match
---
param [9563,9599]
param [9563,9599]
===
match
---
name: k8s [19453,19456]
name: k8s [19450,19453]
===
match
---
atom_expr [19453,19462]
atom_expr [19450,19459]
===
match
---
simple_stmt [10979,11074]
simple_stmt [10979,11074]
===
match
---
name: filtered_labels [18703,18718]
name: label_strings [18703,18716]
===
match
---
name: create_labels_for_pod [13620,13641]
name: create_labels_for_pod [13620,13641]
===
match
---
name: PodRuntimeInfoEnv [9933,9950]
name: PodRuntimeInfoEnv [9933,9950]
===
match
---
trailer [24129,24134]
trailer [24253,24258]
===
match
---
trailer [16673,16682]
trailer [16673,16682]
===
match
---
name: info [18210,18214]
name: info [18210,18214]
===
match
---
trailer [24731,24754]
trailer [24855,24878]
===
match
---
name: str [8083,8086]
name: str [8083,8086]
===
match
---
name: Optional [8509,8517]
name: Optional [8509,8517]
===
match
---
atom_expr [13312,13323]
atom_expr [13312,13323]
===
match
---
name: labels [20398,20404]
name: labels [20395,20401]
===
match
---
atom_expr [20031,20049]
atom_expr [20028,20046]
===
match
---
import_from [1828,1874]
import_from [1828,1874]
===
match
---
try_stmt [24592,24797]
try_stmt [24716,24921]
===
match
---
suite [19742,20051]
suite [19739,20048]
===
match
---
expr_stmt [18703,18804]
expr_stmt [18703,18838]
===
match
---
name: node_selector [11669,11682]
name: node_selector [11669,11682]
===
match
---
simple_stmt [18201,18225]
simple_stmt [18201,18225]
===
match
---
comp_if [18776,18803]
comp_if [18801,18828]
===
match
---
param [9063,9097]
param [9063,9097]
===
match
---
name: k8s [22303,22306]
name: k8s [22300,22303]
===
match
---
atom_expr [23183,23217]
atom_expr [23180,23214]
===
match
---
name: Dict [890,894]
name: Dict [890,894]
===
match
---
name: str [10045,10048]
name: str [10045,10048]
===
match
---
atom_expr [15276,15305]
atom_expr [15276,15305]
===
match
---
argument [14674,14704]
argument [14674,14704]
===
match
---
trailer [16735,16778]
trailer [16735,16778]
===
match
---
name: reconcile_pods [20002,20016]
name: reconcile_pods [19999,20013]
===
match
---
argument [21637,21670]
argument [21634,21667]
===
match
---
trailer [18025,18045]
trailer [18025,18045]
===
match
---
name: ImportError [1041,1052]
name: ImportError [1041,1052]
===
match
---
param [8141,8168]
param [8141,8168]
===
match
---
suite [10138,10232]
suite [10138,10232]
===
match
---
expr_stmt [24096,24134]
expr_stmt [24220,24258]
===
match
---
name: self [10908,10912]
name: self [10908,10912]
===
match
---
suite [19171,19200]
suite [19168,19197]
===
match
---
fstring_string: creating pod with labels  [18379,18404]
fstring_string: creating pod with labels  [18379,18404]
===
match
---
operator: , [9053,9054]
operator: , [9053,9054]
===
match
---
name: safe_dump [23188,23197]
name: safe_dump [23185,23194]
===
match
---
atom_expr [16395,16445]
atom_expr [16395,16445]
===
match
---
name: metadata [24044,24052]
name: metadata [24168,24176]
===
match
---
tfpdef [9106,9136]
tfpdef [9106,9136]
===
match
---
atom_expr [23028,23061]
atom_expr [23025,23058]
===
match
---
operator: { [25483,25484]
operator: { [25659,25660]
===
match
---
try_stmt [991,1070]
try_stmt [991,1070]
===
match
---
atom_expr [25551,25626]
atom_expr [25727,25802]
===
match
---
name: Any [885,888]
name: Any [885,888]
===
match
---
operator: = [20510,20511]
operator: = [20507,20508]
===
match
---
name: k8s [986,989]
name: k8s [986,989]
===
match
---
trailer [22043,22048]
trailer [22040,22045]
===
match
---
return_stmt [19362,19411]
return_stmt [19359,19408]
===
match
---
name: termination_grace_period [9968,9992]
name: termination_grace_period [9968,9992]
===
match
---
expr_stmt [15509,15572]
expr_stmt [15509,15572]
===
match
---
simple_stmt [19212,19310]
simple_stmt [19209,19307]
===
match
---
name: V1Pod [19457,19462]
name: V1Pod [19454,19459]
===
match
---
operator: = [11266,11267]
operator: = [11266,11267]
===
match
---
name: config_file [15010,15021]
name: config_file [15010,15021]
===
match
---
name: restart_policy [21688,21702]
name: restart_policy [21685,21699]
===
match
---
atom_expr [9424,9456]
atom_expr [9424,9456]
===
match
---
operator: } [25537,25538]
operator: } [25713,25714]
===
match
---
operator: , [8167,8168]
operator: , [8167,8168]
===
match
---
name: node_selector [20611,20624]
name: node_selector [20608,20621]
===
match
---
name: CoreV1Api [965,974]
name: CoreV1Api [965,974]
===
match
---
trailer [22295,22328]
trailer [22292,22325]
===
match
---
param [14568,14572]
param [14568,14572]
===
match
---
expr_stmt [14169,14227]
expr_stmt [14169,14227]
===
match
---
operator: , [16333,16334]
operator: , [16333,16334]
===
match
---
atom_expr [9122,9136]
atom_expr [9122,9136]
===
match
---
name: str [22323,22326]
name: str [22320,22323]
===
match
---
trailer [13949,13957]
trailer [13949,13957]
===
match
---
name: replace [23044,23051]
name: replace [23041,23048]
===
match
---
trailer [20698,20710]
trailer [20695,20707]
===
match
---
simple_stmt [12067,12170]
simple_stmt [12067,12170]
===
match
---
name: bool [9389,9393]
name: bool [9389,9393]
===
match
---
name: full_pod_spec [20069,20082]
name: full_pod_spec [20066,20079]
===
match
---
expr_stmt [10908,10970]
expr_stmt [10908,10970]
===
match
---
trailer [23252,23262]
trailer [23276,23286]
===
match
---
operator: } [16559,16560]
operator: } [16559,16560]
===
match
---
trailer [15339,15343]
trailer [15339,15343]
===
match
---
simple_stmt [19188,19200]
simple_stmt [19185,19197]
===
match
---
if_stmt [25412,25539]
if_stmt [25588,25715]
===
match
---
name: config_file [12033,12044]
name: config_file [12033,12044]
===
match
---
tfpdef [13090,13102]
tfpdef [13090,13102]
===
match
---
atom_expr [9219,9261]
atom_expr [9219,9261]
===
match
---
name: pod [24176,24179]
name: pod [24300,24303]
===
match
---
name: self [21922,21926]
name: self [21919,21923]
===
match
---
operator: = [10310,10311]
operator: = [10310,10311]
===
match
---
name: self [18520,18524]
name: self [18520,18524]
===
match
---
atom_expr [20943,20952]
atom_expr [20940,20949]
===
match
---
operator: , [8599,8600]
operator: , [8599,8600]
===
match
---
atom_expr [11208,11223]
atom_expr [11208,11223]
===
match
---
atom_expr [18520,18570]
atom_expr [18520,18570]
===
match
---
name: label_selector [15848,15862]
name: label_selector [15848,15862]
===
match
---
name: models [976,982]
name: models [976,982]
===
match
---
tfpdef [8738,8763]
tfpdef [8738,8763]
===
match
---
atom_expr [10036,10049]
atom_expr [10036,10049]
===
match
---
name: k8s [8468,8471]
name: k8s [8468,8471]
===
match
---
atom_expr [9438,9454]
atom_expr [9438,9454]
===
match
---
trailer [15486,15495]
trailer [15486,15495]
===
match
---
fstring_end: " [18436,18437]
fstring_end: " [18436,18437]
===
match
---
expr_stmt [20156,20220]
expr_stmt [20153,20217]
===
match
---
atom_expr [22573,22695]
atom_expr [22570,22692]
===
match
---
argument [16643,16657]
argument [16643,16657]
===
match
---
name: reattach_on_restart [8738,8757]
name: reattach_on_restart [8738,8757]
===
match
---
if_stmt [25241,25627]
if_stmt [25417,25803]
===
match
---
atom_expr [14838,15040]
atom_expr [14838,15040]
===
match
---
trailer [21879,21898]
trailer [21876,21895]
===
match
---
trailer [8522,8543]
trailer [8522,8543]
===
match
---
arglist [13508,13582]
arglist [13508,13582]
===
match
---
suite [20143,20221]
suite [20140,20218]
===
match
---
operator: , [25016,25017]
operator: , [25140,25141]
===
match
---
string: 'airflow_version' [23009,23026]
string: 'airflow_version' [23006,23023]
===
match
---
string: r'[^a-z0-9.-]+' [19376,19391]
string: r'[^a-z0-9.-]+' [19373,19388]
===
match
---
name: pod [25316,25319]
name: pod [25492,25495]
===
match
---
name: image_pull_secrets [9199,9217]
name: image_pull_secrets [9199,9217]
===
match
---
name: Optional [8917,8925]
name: Optional [8917,8925]
===
match
---
atom_expr [25316,25338]
atom_expr [25492,25514]
===
match
---
number: 120 [8811,8814]
number: 120 [8811,8814]
===
match
---
expr_stmt [18110,18188]
expr_stmt [18110,18188]
===
match
---
parameters [13641,13650]
parameters [13641,13650]
===
match
---
trailer [8471,8480]
trailer [8471,8480]
===
match
---
fstring_string:  but a different try_number. [17851,17879]
fstring_string:  but a different try_number. [17851,17879]
===
match
---
simple_stmt [13440,13447]
simple_stmt [13440,13447]
===
match
---
name: self [12691,12695]
name: self [12691,12695]
===
match
---
operator: , [22671,22672]
operator: , [22668,22669]
===
match
---
name: self [18298,18302]
name: self [18298,18302]
===
match
---
operator: , [21217,21218]
operator: , [21214,21215]
===
match
---
atom_expr [23707,23734]
atom_expr [23731,23758]
===
match
---
atom_expr [15696,15710]
atom_expr [15696,15710]
===
match
---
operator: = [21651,21652]
operator: = [21648,21649]
===
match
---
operator: = [8996,8997]
operator: = [8996,8997]
===
match
---
simple_stmt [22573,22696]
simple_stmt [22570,22693]
===
match
---
operator: = [8483,8484]
operator: = [8483,8484]
===
match
---
name: pod [24195,24198]
name: pod [24319,24322]
===
match
---
trailer [24284,24306]
trailer [24408,24430]
===
match
---
suite [24755,24797]
suite [24879,24921]
===
match
---
name: PodGenerator [21852,21864]
name: PodGenerator [21849,21861]
===
match
---
trailer [15601,15608]
trailer [15601,15608]
===
match
---
name: task_id [23800,23807]
name: task_id [23824,23831]
===
match
---
expr_stmt [19974,20050]
expr_stmt [19971,20047]
===
match
---
simple_stmt [12962,12992]
simple_stmt [12962,12992]
===
match
---
simple_stmt [17079,17650]
simple_stmt [17079,17650]
===
match
---
name: volumes [11135,11142]
name: volumes [11135,11142]
===
match
---
name: client [24148,24154]
name: client [24272,24278]
===
match
---
atom_expr [14577,14607]
atom_expr [14577,14607]
===
match
---
trailer [23197,23217]
trailer [23194,23214]
===
match
---
suite [16843,16910]
suite [16843,16910]
===
match
---
atom_expr [20694,20710]
atom_expr [20691,20707]
===
match
---
name: Secret [8584,8590]
name: Secret [8584,8590]
===
match
---
operator: , [9366,9367]
operator: , [9366,9367]
===
match
---
name: name [19332,19336]
name: name [19329,19333]
===
match
---
operator: = [9788,9789]
operator: = [9788,9789]
===
match
---
trailer [13261,13284]
trailer [13261,13284]
===
match
---
if_stmt [18018,18571]
if_stmt [18018,18571]
===
match
---
trailer [9236,9259]
trailer [9236,9259]
===
match
---
simple_stmt [11740,11775]
simple_stmt [11740,11775]
===
match
---
operator: , [883,884]
operator: , [883,884]
===
match
---
name: do_xcom_push [22065,22077]
name: do_xcom_push [22062,22074]
===
match
---
trailer [23553,23563]
trailer [23577,23587]
===
match
---
trailer [21952,21956]
trailer [21949,21953]
===
match
---
name: image [20867,20872]
name: image [20864,20869]
===
match
---
operator: , [23626,23627]
operator: , [23650,23651]
===
match
---
operator: { [16903,16904]
operator: { [16903,16904]
===
match
---
atom_expr [12296,12312]
atom_expr [12296,12312]
===
match
---
name: str [9833,9836]
name: str [9833,9836]
===
match
---
name: k8s [8523,8526]
name: k8s [8523,8526]
===
match
---
trailer [15009,15021]
trailer [15009,15021]
===
match
---
arglist [20356,20528]
arglist [20353,20525]
===
match
---
suite [16490,16596]
suite [16490,16596]
===
match
---
name: cluster_context [8652,8667]
name: cluster_context [8652,8667]
===
match
---
trailer [8882,8887]
trailer [8882,8887]
===
match
---
simple_stmt [1235,1280]
simple_stmt [1235,1280]
===
match
---
simple_stmt [18110,18189]
simple_stmt [18110,18189]
===
match
---
trailer [9932,9951]
trailer [9932,9951]
===
match
---
operator: = [20404,20405]
operator: = [20401,20402]
===
match
---
name: airflow [1880,1887]
name: airflow [1880,1887]
===
match
---
atom_expr [15318,15332]
atom_expr [15318,15332]
===
match
---
name: label_selector [15645,15659]
name: label_selector [15645,15659]
===
match
---
trailer [12754,12774]
trailer [12754,12774]
===
match
---
name: api_version [20259,20270]
name: api_version [20256,20267]
===
match
---
name: yaml [1029,1033]
name: yaml [1029,1033]
===
match
---
trailer [8967,8995]
trailer [8967,8995]
===
match
---
argument [10273,10281]
argument [10273,10281]
===
match
---
name: pod [18334,18337]
name: pod [18334,18337]
===
match
---
name: cluster_context [14956,14971]
name: cluster_context [14956,14971]
===
match
---
operator: , [16165,16166]
operator: , [16165,16166]
===
match
---
simple_stmt [20096,20130]
simple_stmt [20093,20127]
===
match
---
operator: = [10050,10051]
operator: = [10050,10051]
===
match
---
operator: { [17737,17738]
operator: { [17737,17738]
===
match
---
operator: { [13864,13865]
operator: { [13864,13865]
===
match
---
operator: = [25589,25590]
operator: = [25765,25766]
===
match
---
parameters [22262,22286]
parameters [22259,22283]
===
match
---
arglist [19332,19352]
arglist [19329,19349]
===
match
---
operator: = [15274,15275]
operator: = [15274,15275]
===
match
---
if_stmt [19123,19200]
if_stmt [19120,19197]
===
match
---
operator: } [11868,11869]
operator: } [11868,11869]
===
match
---
name: metadata [20181,20189]
name: metadata [20178,20186]
===
match
---
name: remote_pod [23344,23354]
name: remote_pod [23368,23378]
===
match
---
trailer [23187,23197]
trailer [23184,23194]
===
match
---
name: pod [25288,25291]
name: pod [25464,25467]
===
match
---
tfpdef [9330,9358]
tfpdef [9330,9358]
===
match
---
name: len [15950,15953]
name: len [15950,15953]
===
match
---
trailer [9130,9136]
trailer [9130,9136]
===
match
---
operator: , [18509,18510]
operator: , [18509,18510]
===
match
---
name: launcher [24261,24269]
name: launcher [24385,24393]
===
match
---
name: self [12028,12032]
name: self [12028,12032]
===
match
---
import_from [1280,1319]
import_from [1280,1319]
===
match
---
operator: = [8250,8251]
operator: = [8250,8251]
===
match
---
trailer [12809,12827]
trailer [12809,12827]
===
match
---
operator: == [15970,15972]
operator: == [15970,15972]
===
match
---
atom_expr [11740,11758]
atom_expr [11740,11758]
===
match
---
name: airflow [1240,1247]
name: airflow [1240,1247]
===
match
---
tfpdef [9012,9046]
tfpdef [9012,9046]
===
match
---
operator: = [21747,21748]
operator: = [21744,21745]
===
match
---
parameters [23932,23954]
parameters [24056,24078]
===
match
---
arglist [13369,13426]
arglist [13369,13426]
===
match
---
operator: , [23181,23182]
operator: , [23178,23179]
===
match
---
name: isinstance [13251,13261]
name: isinstance [13251,13261]
===
match
---
operator: , [9958,9959]
operator: , [9958,9959]
===
match
---
string: "`name` is required unless `pod_template_file` or `full_pod_spec` is set" [19235,19308]
string: "`name` is required unless `pod_template_file` or `full_pod_spec` is set" [19232,19305]
===
match
---
atom_expr [11801,11819]
atom_expr [11801,11819]
===
match
---
name: self [21504,21508]
name: self [21501,21505]
===
match
---
trailer [13494,13592]
trailer [13494,13592]
===
match
---
simple_stmt [1320,1653]
simple_stmt [1320,1653]
===
match
---
atom_expr [9632,9641]
atom_expr [9632,9641]
===
match
---
operator: , [8315,8316]
operator: , [8315,8316]
===
match
---
trailer [11021,11024]
trailer [11021,11024]
===
match
---
argument [14649,14672]
argument [14649,14672]
===
match
---
fstring_start: f" [17809,17811]
fstring_start: f" [17809,17811]
===
match
---
operator: = [19987,19988]
operator: = [19984,19985]
===
match
---
name: secret [1259,1265]
name: secret [1259,1265]
===
match
---
name: AirflowException [10157,10173]
name: AirflowException [10157,10173]
===
match
---
operator: , [1813,1814]
operator: , [1813,1814]
===
match
---
param [9330,9367]
param [9330,9367]
===
match
---
operator: , [21473,21474]
operator: , [21470,21471]
===
match
---
operator: -> [22287,22289]
operator: -> [22284,22286]
===
match
---
suite [23735,23855]
suite [23759,23879]
===
match
---
name: kube_client [14838,14849]
name: kube_client [14838,14849]
===
match
---
name: Optional [8147,8155]
name: Optional [8147,8155]
===
match
---
trailer [19759,19763]
trailer [19756,19760]
===
match
---
name: launcher [18324,18332]
name: launcher [18324,18332]
===
match
---
number: 0 [16060,16061]
number: 0 [16060,16061]
===
match
---
tfpdef [9905,9951]
tfpdef [9905,9951]
===
match
---
name: volume_mounts [11052,11065]
name: volume_mounts [11052,11065]
===
match
---
operator: , [894,895]
operator: , [894,895]
===
match
---
argument [21243,21260]
argument [21240,21257]
===
match
---
argument [20856,20872]
argument [20853,20869]
===
match
---
string: 'try_number' [19012,19024]
string: 'try_number' [19009,19021]
===
match
---
and_test [15692,15744]
and_test [15692,15744]
===
match
---
trailer [10597,10607]
trailer [10597,10607]
===
match
---
operator: += [18119,18121]
operator: += [18119,18121]
===
match
---
atom_expr [16701,16778]
atom_expr [16701,16778]
===
match
---
operator: = [14193,14194]
operator: = [14193,14194]
===
match
---
simple_stmt [14617,14706]
simple_stmt [14617,14706]
===
match
---
atom_expr [9928,9951]
atom_expr [9928,9951]
===
match
---
atom_expr [10333,10343]
atom_expr [10333,10343]
===
match
---
operator: != [16473,16475]
operator: != [16473,16475]
===
match
---
operator: = [12659,12660]
operator: = [12659,12660]
===
match
---
name: labels [15565,15571]
name: labels [15565,15571]
===
match
---
name: node_selector [11806,11819]
name: node_selector [11806,11819]
===
match
---
operator: = [20605,20606]
operator: = [20602,20603]
===
match
---
argument [20898,20909]
argument [20895,20906]
===
match
---
name: Any [13099,13102]
name: Any [13099,13102]
===
match
---
expr_stmt [15451,15495]
expr_stmt [15451,15495]
===
match
---
tfpdef [9411,9456]
tfpdef [9411,9456]
===
match
---
name: str [7819,7822]
name: str [7819,7822]
===
match
---
atom [12506,12508]
atom [12506,12508]
===
match
---
name: airflow [1833,1840]
name: airflow [1833,1840]
===
match
---
name: Optional [14741,14749]
name: Optional [14741,14749]
===
match
---
simple_stmt [11949,12020]
simple_stmt [11949,12020]
===
match
---
name: image [8104,8109]
name: image [8104,8109]
===
match
---
name: reconcile_pods [21865,21879]
name: reconcile_pods [21862,21876]
===
match
---
name: convert_configmap [1433,1450]
name: convert_configmap [1433,1450]
===
match
---
trailer [22954,22963]
trailer [22951,22960]
===
match
---
name: Optional [8669,8677]
name: Optional [8669,8677]
===
match
---
atom_expr [24292,24305]
atom_expr [24416,24429]
===
match
---
name: self [23147,23151]
name: self [23144,23148]
===
match
---
except_clause [16813,16842]
except_clause [16813,16842]
===
match
---
string: 'task_instance' [16616,16631]
string: 'task_instance' [16616,16631]
===
match
---
atom_expr [13337,13427]
atom_expr [13337,13427]
===
match
---
simple_stmt [12897,12954]
simple_stmt [12897,12954]
===
match
---
expr_stmt [12962,12991]
expr_stmt [12962,12991]
===
match
---
operator: = [21702,21703]
operator: = [21699,21700]
===
match
---
name: cluster_context [11268,11283]
name: cluster_context [11268,11283]
===
match
---
name: items [24940,24945]
name: items [25064,25069]
===
match
---
trailer [15187,15199]
trailer [15187,15199]
===
match
---
name: get_logs [11352,11360]
name: get_logs [11352,11360]
===
match
---
operator: , [23112,23113]
operator: , [23109,23110]
===
match
---
argument [20181,20219]
argument [20178,20216]
===
match
---
name: log_events_on_failure [12696,12717]
name: log_events_on_failure [12696,12717]
===
match
---
operator: , [24633,24634]
operator: , [24757,24758]
===
match
---
if_stmt [24805,25154]
if_stmt [24929,25330]
===
match
---
dictorsetmaker [13878,14055]
dictorsetmaker [13878,14055]
===
match
---
argument [21086,21114]
argument [21083,21111]
===
match
---
trailer [13461,13463]
trailer [13461,13463]
===
match
---
argument [21594,21619]
argument [21591,21616]
===
match
---
trailer [21995,22003]
trailer [21992,22000]
===
match
---
suite [24880,25033]
suite [25004,25157]
===
match
---
name: get_logs [8824,8832]
name: get_logs [8824,8832]
===
match
---
atom_expr [12897,12926]
atom_expr [12897,12926]
===
match
---
trailer [24828,24836]
trailer [24952,24960]
===
match
---
name: context [15487,15494]
name: context [15487,15494]
===
match
---
trailer [25584,25626]
trailer [25760,25802]
===
match
---
operator: = [10441,10442]
operator: = [10441,10442]
===
match
---
trailer [13996,14002]
trailer [13996,14002]
===
match
---
subscriptlist [22296,22327]
subscriptlist [22293,22324]
===
match
---
operator: = [10783,10784]
operator: = [10783,10784]
===
match
---
trailer [22099,22105]
trailer [22096,22102]
===
match
---
name: self [10395,10399]
name: self [10395,10399]
===
match
---
operator: , [10056,10057]
operator: , [10056,10057]
===
match
---
atom_expr [21247,21260]
atom_expr [21244,21257]
===
match
---
expr_stmt [22166,22206]
expr_stmt [22163,22203]
===
match
---
operator: = [12828,12829]
operator: = [12828,12829]
===
match
---
name: airflow_version [1952,1967]
name: airflow_version [1952,1967]
===
match
---
param [13112,13126]
param [13112,13126]
===
match
---
name: update [22800,22806]
name: update [22797,22803]
===
match
---
name: log_line [18110,18118]
name: log_line [18110,18118]
===
match
---
arglist [18324,18337]
arglist [18324,18337]
===
match
---
operator: -> [18968,18970]
operator: -> [18965,18967]
===
match
---
trailer [24934,24939]
trailer [25058,25063]
===
match
---
expr_stmt [18486,18570]
expr_stmt [18486,18570]
===
match
---
name: convert_resources [1562,1579]
name: convert_resources [1562,1579]
===
match
---
name: labels [18405,18411]
name: labels [18405,18411]
===
match
---
expr_stmt [15265,15305]
expr_stmt [15265,15305]
===
match
---
name: dnspolicy [12534,12543]
name: dnspolicy [12534,12543]
===
match
---
name: airflow [1754,1761]
name: airflow [1754,1761]
===
match
---
fstring_string: Pod  [16532,16536]
fstring_string: Pod  [16532,16536]
===
match
---
operator: = [11683,11684]
operator: = [11683,11684]
===
match
---
param [13090,13103]
param [13090,13103]
===
match
---
operator: , [21172,21173]
operator: , [21169,21170]
===
match
---
name: result [24635,24641]
name: result [24759,24765]
===
match
---
string: "Adding KubernetesPodOperator labels to pod before launch for task %s" [22601,22671]
string: "Adding KubernetesPodOperator labels to pod before launch for task %s" [22598,22668]
===
match
---
trailer [10848,10855]
trailer [10848,10855]
===
match
---
trailer [8517,8544]
trailer [8517,8544]
===
match
---
name: str [17064,17067]
name: str [17064,17067]
===
match
---
argument [21728,21772]
argument [21725,21769]
===
match
---
name: self [15907,15911]
name: self [15907,15911]
===
match
---
name: pod_launcher [14582,14594]
name: pod_launcher [14582,14594]
===
match
---
name: convert_volume [1609,1623]
name: convert_volume [1609,1623]
===
match
---
name: in_cluster [14789,14799]
name: in_cluster [14789,14799]
===
match
---
operator: -> [10082,10084]
operator: -> [10082,10084]
===
match
---
suite [14768,16805]
suite [14768,16805]
===
match
---
fstring_expr [25138,25151]
fstring_expr [25314,25327]
===
match
---
name: self [12750,12754]
name: self [12750,12754]
===
match
---
name: pod [24040,24043]
name: pod [24164,24167]
===
match
---
operator: = [20942,20943]
operator: = [20939,20940]
===
match
---
operator: = [15333,15334]
operator: = [15333,15334]
===
match
---
fstring [17809,17880]
fstring [17809,17880]
===
match
---
name: pod_list [16196,16204]
name: pod_list [16196,16204]
===
match
---
dotted_name [1325,1397]
dotted_name [1325,1397]
===
match
---
argument [25585,25594]
argument [25761,25770]
===
match
---
name: pod [24935,24938]
name: pod [25059,25062]
===
match
---
import_name [825,834]
import_name [825,834]
===
match
---
operator: , [20527,20528]
operator: , [20524,20525]
===
match
---
simple_stmt [24967,25033]
simple_stmt [25091,25157]
===
match
---
simple_stmt [10292,10325]
simple_stmt [10292,10325]
===
match
---
simple_stmt [851,934]
simple_stmt [851,934]
===
match
---
name: affinity [11883,11891]
name: affinity [11883,11891]
===
match
---
param [8390,8435]
param [8390,8435]
===
match
---
testlist_comp [11001,11047]
testlist_comp [11001,11047]
===
match
---
name: env [21243,21246]
name: env [21240,21243]
===
match
---
simple_stmt [22166,22207]
simple_stmt [22163,22204]
===
match
---
name: self [10333,10337]
name: self [10333,10337]
===
match
---
name: backcompat [1359,1369]
name: backcompat [1359,1369]
===
match
---
param [8948,9003]
param [8948,9003]
===
match
---
atom_expr [21203,21217]
atom_expr [21200,21214]
===
match
---
fstring_expr [16903,16907]
fstring_expr [16903,16907]
===
match
---
name: List [906,910]
name: List [906,910]
===
match
---
suite [23691,23855]
suite [23715,23979]
===
match
---
trailer [24207,24217]
trailer [24331,24341]
===
match
---
operator: = [14686,14687]
operator: = [14686,14687]
===
match
---
atom_expr [10426,10440]
atom_expr [10426,10440]
===
match
---
parameters [24254,24275]
parameters [24378,24399]
===
match
---
trailer [20866,20872]
trailer [20863,20869]
===
match
---
name: kubernetes [940,950]
name: kubernetes [940,950]
===
match
---
param [10024,10057]
param [10024,10057]
===
match
---
name: namespace [25596,25605]
name: namespace [25772,25781]
===
match
---
trailer [23413,23422]
trailer [23437,23446]
===
match
---
operator: = [20365,20366]
operator: = [20362,20363]
===
match
---
arglist [23606,23655]
arglist [23630,23679]
===
match
---
operator: = [17701,17702]
operator: = [17701,17702]
===
match
---
dotted_name [1918,1933]
dotted_name [1918,1933]
===
match
---
trailer [8290,8306]
trailer [8290,8306]
===
match
---
operator: , [16194,16195]
operator: , [16194,16195]
===
match
---
name: self [10467,10471]
name: self [10467,10471]
===
match
---
expr_stmt [18264,18338]
expr_stmt [18264,18338]
===
match
---
name: pod [25266,25269]
name: pod [25442,25445]
===
match
---
simple_stmt [10565,10628]
simple_stmt [10565,10628]
===
match
---
name: service_account_name [9278,9298]
name: service_account_name [9278,9298]
===
match
---
trailer [21926,21934]
trailer [21923,21931]
===
match
---
trailer [23711,23734]
trailer [23735,23758]
===
match
---
operator: -> [14574,14576]
operator: -> [14574,14576]
===
match
---
trailer [8462,8482]
trailer [8462,8482]
===
match
---
name: try_numbers_match [17661,17678]
name: try_numbers_match [17661,17678]
===
match
---
atom_expr [19029,19053]
atom_expr [19026,19050]
===
match
---
simple_stmt [1000,1034]
simple_stmt [1000,1034]
===
match
---
expr_stmt [10333,10351]
expr_stmt [10333,10351]
===
match
---
import_from [935,989]
import_from [935,989]
===
match
---
atom_expr [15954,15968]
atom_expr [15954,15968]
===
match
---
trailer [13941,13949]
trailer [13941,13949]
===
match
---
atom_expr [23825,23854]
atom_expr [23849,23878]
===
match
---
tfpdef [9063,9089]
tfpdef [9063,9089]
===
match
---
trailer [24154,24175]
trailer [24278,24299]
===
match
---
trailer [11112,11120]
trailer [11112,11120]
===
match
---
atom_expr [8523,8542]
atom_expr [8523,8542]
===
match
---
name: name [16683,16687]
name: name [16683,16687]
===
match
---
atom_expr [8183,8202]
atom_expr [8183,8202]
===
match
---
operator: , [9649,9650]
operator: , [9649,9650]
===
match
---
name: AirflowException [25095,25111]
name: AirflowException [25271,25287]
===
match
---
atom_expr [23244,23318]
atom_expr [23268,23342]
===
match
---
trailer [22977,23137]
trailer [22974,23134]
===
match
---
trailer [20655,20664]
trailer [20652,20661]
===
match
---
trailer [9832,9837]
trailer [9832,9837]
===
match
---
simple_stmt [22091,22154]
simple_stmt [22088,22151]
===
match
---
atom_expr [15183,15199]
atom_expr [15183,15199]
===
match
---
operator: , [1161,1162]
operator: , [1161,1162]
===
match
---
name: log [24972,24975]
name: log [25096,25099]
===
match
---
name: metadata [22955,22963]
name: metadata [22952,22960]
===
match
---
simple_stmt [10835,10900]
simple_stmt [10835,10900]
===
match
---
name: k8s [9690,9693]
name: k8s [9690,9693]
===
match
---
name: self [10979,10983]
name: self [10979,10983]
===
match
---
name: Iterable [7810,7818]
name: Iterable [7810,7818]
===
match
---
name: ex [16840,16842]
name: ex [16840,16842]
===
match
---
operator: , [1427,1428]
operator: , [1427,1428]
===
match
---
name: pod_template [20156,20168]
name: pod_template [20153,20165]
===
match
---
atom_expr [23944,23953]
atom_expr [24068,24077]
===
match
---
atom_expr [21922,21934]
atom_expr [21919,21931]
===
match
---
trailer [22184,22201]
trailer [22181,22198]
===
match
---
operator: = [8593,8594]
operator: = [8593,8594]
===
match
---
name: name [25585,25589]
name: name [25761,25765]
===
match
---
expr_stmt [10979,11073]
expr_stmt [10979,11073]
===
match
---
simple_stmt [12552,12587]
simple_stmt [12552,12587]
===
match
---
atom_expr [10857,10877]
atom_expr [10857,10877]
===
match
---
trailer [21452,21473]
trailer [21449,21470]
===
match
---
name: namespace [20356,20365]
name: namespace [20353,20362]
===
match
---
name: Iterable [896,904]
name: Iterable [896,904]
===
match
---
name: convert_volume_mount [11001,11021]
name: convert_volume_mount [11001,11021]
===
match
---
atom_expr [23472,23498]
atom_expr [23496,23522]
===
match
---
name: typing [856,862]
name: typing [856,862]
===
match
---
param [9199,9269]
param [9199,9269]
===
match
---
name: self [21798,21802]
name: self [21795,21799]
===
match
---
comparison [16461,16489]
comparison [16461,16489]
===
match
---
simple_stmt [24143,24225]
simple_stmt [24267,24349]
===
match
---
atom_expr [8968,8994]
atom_expr [8968,8994]
===
match
---
operator: , [10271,10272]
operator: , [10271,10272]
===
match
---
operator: , [20624,20625]
operator: , [20621,20622]
===
match
---
tfpdef [16967,16990]
tfpdef [16967,16990]
===
match
---
name: launcher [22277,22285]
name: launcher [22274,22282]
===
match
---
name: k8s [8287,8290]
name: k8s [8287,8290]
===
match
---
trailer [24857,24879]
trailer [24981,25003]
===
match
---
name: name [8141,8145]
name: name [8141,8145]
===
match
---
operator: = [24679,24680]
operator: = [24803,24804]
===
match
---
name: self [23752,23756]
name: self [23776,23780]
===
match
---
expr_stmt [18365,18437]
expr_stmt [18365,18437]
===
match
---
expr_stmt [15231,15251]
expr_stmt [15231,15251]
===
match
---
trailer [16274,16279]
trailer [16274,16279]
===
match
---
name: self [23554,23558]
name: self [23578,23582]
===
match
---
operator: = [18719,18720]
operator: = [18717,18718]
===
match
---
name: c [10882,10883]
name: c [10882,10883]
===
match
---
name: node_selector [11761,11774]
name: node_selector [11761,11774]
===
match
---
simple_stmt [12750,12797]
simple_stmt [12750,12797]
===
match
---
atom_expr [9875,9888]
atom_expr [9875,9888]
===
match
---
string: 'kubernetes_pod_operator' [23079,23104]
string: 'kubernetes_pod_operator' [23076,23101]
===
match
---
name: content [13262,13269]
name: content [13262,13269]
===
match
---
atom_expr [22172,22206]
atom_expr [22169,22203]
===
match
---
trailer [10471,10478]
trailer [10471,10478]
===
match
---
simple_stmt [1280,1320]
simple_stmt [1280,1320]
===
match
---
trailer [8119,8124]
trailer [8119,8124]
===
match
---
name: config_file [15188,15199]
name: config_file [15188,15199]
===
match
---
trailer [19898,19922]
trailer [19895,19919]
===
match
---
operator: , [9759,9760]
operator: , [9759,9760]
===
match
---
suite [1053,1070]
suite [1053,1070]
===
match
---
trailer [14788,14799]
trailer [14788,14799]
===
match
---
trailer [21299,21308]
trailer [21296,21305]
===
match
---
tfpdef [8177,8202]
tfpdef [8177,8202]
===
match
---
name: Any [17002,17005]
name: Any [17002,17005]
===
match
---
name: labels [18553,18559]
name: labels [18553,18559]
===
match
---
expr_stmt [25388,25399]
expr_stmt [25564,25575]
===
match
---
trailer [8243,8248]
trailer [8243,8248]
===
match
---
name: self [21748,21752]
name: self [21745,21749]
===
match
---
arglist [22601,22685]
arglist [22598,22682]
===
match
---
operator: = [25356,25357]
operator: = [25532,25533]
===
match
---
operator: ** [10066,10068]
operator: ** [10066,10068]
===
match
---
expr_stmt [25474,25538]
expr_stmt [25650,25714]
===
match
---
expr_stmt [11878,11940]
expr_stmt [11878,11940]
===
match
---
name: configmaps [10024,10034]
name: configmaps [10024,10034]
===
match
---
operator: = [15524,15525]
operator: = [15524,15525]
===
match
---
name: client [12967,12973]
name: client [12967,12973]
===
match
---
name: self [15629,15633]
name: self [15629,15633]
===
match
---
name: content [13508,13515]
name: content [13508,13515]
===
match
---
trailer [12642,12658]
trailer [12642,12658]
===
match
---
name: labels [18679,18685]
name: labels [18679,18685]
===
match
---
simple_stmt [14487,14517]
simple_stmt [14487,14517]
===
match
---
trailer [20180,20220]
trailer [20177,20217]
===
match
---
operator: , [13536,13537]
operator: , [13536,13537]
===
match
---
trailer [14466,14473]
trailer [14466,14473]
===
match
---
expr_stmt [25266,25291]
expr_stmt [25442,25467]
===
match
---
sync_comp_for [11121,11142]
sync_comp_for [11121,11142]
===
match
---
name: items [14393,14398]
name: items [14393,14398]
===
match
---
name: self [21555,21559]
name: self [21552,21556]
===
match
---
name: str [8678,8681]
name: str [8678,8681]
===
match
---
trailer [17063,17068]
trailer [17063,17068]
===
match
---
operator: = [14425,14426]
operator: = [14425,14426]
===
match
---
name: pod_runtime_info_envs [10737,10758]
name: pod_runtime_info_envs [10737,10758]
===
match
---
name: dnspolicy [12522,12531]
name: dnspolicy [12522,12531]
===
match
---
name: _get_pod_identifying_label_string [15531,15564]
name: _get_pod_identifying_label_string [15531,15564]
===
match
---
name: read_pod_events [23538,23553]
name: read_pod_events [23562,23577]
===
match
---
fstring_end: ' [25151,25152]
fstring_end: ' [25327,25328]
===
match
---
string: "creating pod with labels %s and launcher %s" [16280,16325]
string: "creating pod with labels %s and launcher %s" [16280,16325]
===
match
---
string: 'pod_namespace' [16740,16755]
string: 'pod_namespace' [16740,16755]
===
match
---
trailer [12373,12385]
trailer [12373,12385]
===
match
---
atom_expr [19899,19921]
atom_expr [19896,19918]
===
match
---
atom_expr [15335,15362]
atom_expr [15335,15362]
===
match
---
operator: = [12571,12572]
operator: = [12571,12572]
===
match
---
name: labels [16428,16434]
name: labels [16428,16434]
===
match
---
name: metadata [16546,16554]
name: metadata [16546,16554]
===
match
---
dotted_name [1240,1265]
dotted_name [1240,1265]
===
match
---
trailer [23214,23216]
trailer [23211,23213]
===
match
---
name: exceptions [1084,1094]
name: exceptions [1084,1094]
===
match
---
name: priority_class_name [21728,21747]
name: priority_class_name [21725,21744]
===
match
---
atom_expr [23409,23422]
atom_expr [23433,23446]
===
match
---
atom [10625,10627]
atom [10625,10627]
===
match
---
simple_stmt [15509,15573]
simple_stmt [15509,15573]
===
match
---
param [17007,17021]
param [17007,17021]
===
match
---
operator: = [22170,22171]
operator: = [22167,22168]
===
match
---
expr_stmt [10360,10386]
expr_stmt [10360,10386]
===
match
---
dotted_name [1182,1214]
dotted_name [1182,1214]
===
match
---
operator: , [20542,20543]
operator: , [20539,20540]
===
match
---
and_test [13218,13284]
and_test [13218,13284]
===
match
---
trailer [20475,20480]
trailer [20472,20477]
===
match
---
operator: = [9752,9753]
operator: = [9752,9753]
===
match
---
trailer [10874,10877]
trailer [10874,10877]
===
match
---
trailer [9586,9591]
trailer [9586,9591]
===
match
---
operator: , [9463,9464]
operator: , [9463,9464]
===
match
---
funcdef [13032,13593]
funcdef [13032,13593]
===
match
---
name: in_cluster [14887,14897]
name: in_cluster [14887,14897]
===
match
---
simple_stmt [24609,24695]
simple_stmt [24733,24819]
===
match
---
operator: = [12484,12485]
operator: = [12484,12485]
===
match
---
simple_stmt [825,835]
simple_stmt [825,835]
===
match
---
operator: , [1450,1451]
operator: , [1450,1451]
===
match
---
simple_stmt [25162,25201]
simple_stmt [25338,25377]
===
match
---
name: self [15265,15269]
name: self [15265,15269]
===
match
---
operator: { [12017,12018]
operator: { [12017,12018]
===
match
---
suite [15745,15883]
suite [15745,15883]
===
match
---
trailer [13274,13283]
trailer [13274,13283]
===
match
---
name: client [951,957]
name: client [951,957]
===
match
---
operator: = [9838,9839]
operator: = [9838,9839]
===
match
---
trailer [11212,11223]
trailer [11212,11223]
===
match
---
string: "Starting pod:\n%s" [23162,23181]
string: "Starting pod:\n%s" [23159,23178]
===
match
---
simple_stmt [11664,11700]
simple_stmt [11664,11700]
===
match
---
argument [24671,24693]
argument [24795,24817]
===
match
---
name: namespace [15323,15332]
name: namespace [15323,15332]
===
match
---
operator: , [17042,17043]
operator: , [17042,17043]
===
match
---
name: service_account_name [12183,12203]
name: service_account_name [12183,12203]
===
match
---
param [9724,9760]
param [9724,9760]
===
match
---
funcdef [25206,25627]
funcdef [25382,25803]
===
match
---
name: cluster_context [11250,11265]
name: cluster_context [11250,11265]
===
match
---
trailer [20115,20129]
trailer [20112,20126]
===
match
---
atom_expr [20744,20764]
atom_expr [20741,20761]
===
match
---
name: label_selector [15660,15674]
name: label_selector [15660,15674]
===
match
---
return_stmt [18985,19053]
return_stmt [18982,19050]
===
match
---
trailer [25562,25584]
trailer [25738,25760]
===
match
---
dotted_name [940,957]
dotted_name [940,957]
===
match
---
expr_stmt [11380,11422]
expr_stmt [11380,11422]
===
match
---
trailer [12966,12973]
trailer [12966,12973]
===
match
---
operator: , [888,889]
operator: , [888,889]
===
match
---
tfpdef [13112,13125]
tfpdef [13112,13125]
===
match
---
trailer [10506,10530]
trailer [10506,10530]
===
match
---
atom_expr [24176,24193]
atom_expr [24300,24317]
===
match
---
expr_stmt [12691,12741]
expr_stmt [12691,12741]
===
match
---
name: airflow [1918,1925]
name: airflow [1918,1925]
===
match
---
name: safe_label [14414,14424]
name: safe_label [14414,14424]
===
match
---
name: attach_to_pod [22030,22043]
name: attach_to_pod [22027,22040]
===
match
---
name: extract_xcom [14674,14686]
name: extract_xcom [14674,14686]
===
match
---
atom_expr [10908,10918]
atom_expr [10908,10918]
===
match
---
atom_expr [11098,11120]
atom_expr [11098,11120]
===
match
---
arglist [16428,16444]
arglist [16428,16444]
===
match
---
tfpdef [9968,10007]
tfpdef [9968,10007]
===
match
---
name: v [11029,11030]
name: v [11029,11030]
===
match
---
operator: = [12352,12353]
operator: = [12352,12353]
===
match
---
fstring_start: f" [17703,17705]
fstring_start: f" [17703,17705]
===
match
---
name: metadata [15344,15352]
name: metadata [15344,15352]
===
match
---
argument [21538,21576]
argument [21535,21573]
===
match
---
trailer [24147,24154]
trailer [24271,24278]
===
match
---
expr_stmt [20096,20129]
expr_stmt [20093,20126]
===
match
---
trailer [14462,14474]
trailer [14462,14474]
===
match
---
name: pod_template [20017,20029]
name: pod_template [20014,20026]
===
match
---
simple_stmt [13000,13027]
simple_stmt [13000,13027]
===
match
---
name: labels [18067,18073]
name: labels [18067,18073]
===
match
---
name: cmds [10407,10411]
name: cmds [10407,10411]
===
match
---
name: k8s [9233,9236]
name: k8s [9233,9236]
===
match
---
atom_expr [17044,17053]
atom_expr [17044,17053]
===
match
---
atom_expr [11664,11682]
atom_expr [11664,11682]
===
match
---
suite [15058,15218]
suite [15058,15218]
===
match
---
name: debug [23761,23766]
name: debug [23785,23790]
===
match
---
name: V1PodSpec [20565,20574]
name: V1PodSpec [20562,20571]
===
match
---
operator: , [16184,16185]
operator: , [16184,16185]
===
match
---
trailer [20325,20338]
trailer [20322,20335]
===
match
---
name: get_logs [11363,11371]
name: get_logs [11363,11371]
===
match
---
atom_expr [16196,16213]
atom_expr [16196,16213]
===
match
---
trailer [23537,23553]
trailer [23561,23577]
===
match
---
name: self [23198,23202]
name: self [23195,23199]
===
match
---
fstring_expr [17737,17745]
fstring_expr [17737,17745]
===
match
---
name: result [18289,18295]
name: result [18289,18295]
===
match
---
trailer [22029,22043]
trailer [22026,22040]
===
match
---
argument [21427,21473]
argument [21424,21470]
===
match
---
operator: , [974,975]
operator: , [974,975]
===
match
---
atom_expr [11833,11849]
atom_expr [11833,11849]
===
match
---
name: event [23628,23633]
name: event [23652,23657]
===
match
---
operator: = [11184,11185]
operator: = [11184,11185]
===
match
---
simple_stmt [12517,12544]
simple_stmt [12517,12544]
===
match
---
atom_expr [14386,14400]
atom_expr [14386,14400]
===
match
---
name: handle_pod_overlap [16119,16137]
name: handle_pod_overlap [16119,16137]
===
match
---
suite [19957,20051]
suite [19954,20048]
===
match
---
name: log [19760,19763]
name: log [19757,19760]
===
match
---
operator: } [25150,25151]
operator: } [25326,25327]
===
match
---
argument [20978,20994]
argument [20975,20991]
===
match
---
operator: , [9795,9796]
operator: , [9795,9796]
===
match
---
raise_stmt [25089,25153]
raise_stmt [25265,25329]
===
match
---
trailer [20001,20016]
trailer [19998,20013]
===
match
---
arglist [20017,20049]
arglist [20014,20046]
===
match
---
trailer [20564,20574]
trailer [20561,20571]
===
match
---
operator: , [25180,25181]
operator: , [25356,25357]
===
match
---
fstring_expr [15847,15863]
fstring_expr [15847,15863]
===
match
---
expr_stmt [10769,10799]
expr_stmt [10769,10799]
===
match
---
expr_stmt [11740,11774]
expr_stmt [11740,11774]
===
match
---
name: monitor_launched_pod [24234,24254]
name: monitor_launched_pod [24358,24378]
===
match
---
operator: = [10266,10267]
operator: = [10266,10267]
===
match
---
operator: , [16043,16044]
operator: , [16043,16044]
===
match
---
expr_stmt [12296,12326]
expr_stmt [12296,12326]
===
match
---
atom_expr [21038,21060]
atom_expr [21035,21057]
===
match
---
name: providers [1333,1342]
name: providers [1333,1342]
===
match
---
name: name [25590,25594]
name: name [25766,25770]
===
match
---
name: self [10426,10430]
name: self [10426,10430]
===
match
---
string: """         Creates a new pod and monitors for duration of task          :param labels: labels used to track pod         :param launcher: pod launcher that will manage launching and monitoring pods         :return:         """ [22338,22564]
string: """         Creates a new pod and monitors for duration of task          :param labels: labels used to track pod         :param launcher: pod launcher that will manage launching and monitoring pods         :return:         """ [22335,22561]
===
match
---
name: bool [18971,18975]
name: bool [18968,18972]
===
match
---
name: PodGenerator [24103,24115]
name: PodGenerator [24227,24239]
===
match
---
name: image_pull_secrets [21391,21409]
name: image_pull_secrets [21388,21406]
===
match
---
name: secret [22023,22029]
name: secret [22020,22026]
===
match
---
trailer [15322,15332]
trailer [15322,15332]
===
match
---
trailer [16669,16673]
trailer [16669,16673]
===
match
---
trailer [21609,21619]
trailer [21606,21616]
===
match
---
name: tolerations [12340,12351]
name: tolerations [12340,12351]
===
match
---
name: self [16012,16016]
name: self [16012,16016]
===
match
---
expr_stmt [7793,7977]
expr_stmt [7793,7977]
===
match
---
operator: = [15659,15660]
operator: = [15659,15660]
===
match
---
name: cncf [1343,1347]
name: cncf [1343,1347]
===
match
---
name: self [21448,21452]
name: self [21445,21449]
===
match
---
trailer [10839,10848]
trailer [10839,10848]
===
match
---
name: jinja_env [13550,13559]
name: jinja_env [13550,13559]
===
match
---
atom_expr [19938,19956]
atom_expr [19935,19953]
===
match
---
name: self [12868,12872]
name: self [12868,12872]
===
match
---
operator: { [17843,17844]
operator: { [17843,17844]
===
match
---
string: """Add an "already tried annotation to ensure we only retry once""" [23964,24031]
string: """Add an "already tried annotation to ensure we only retry once""" [24088,24155]
===
match
---
name: providers [1666,1675]
name: providers [1666,1675]
===
match
---
name: value [16659,16664]
name: value [16659,16664]
===
match
---
fstring [18377,18437]
fstring [18377,18437]
===
match
---
atom_expr [9824,9837]
atom_expr [9824,9837]
===
match
---
name: env_from [21286,21294]
name: env_from [21283,21291]
===
match
---
operator: = [11820,11821]
operator: = [11820,11821]
===
match
---
name: convert_resources [11970,11987]
name: convert_resources [11970,11987]
===
match
---
simple_stmt [11801,11825]
simple_stmt [11801,11825]
===
match
---
name: pod [18963,18966]
name: pod [18960,18963]
===
match
---
atom_expr [11171,11183]
atom_expr [11171,11183]
===
match
---
argument [20499,20527]
argument [20496,20524]
===
match
---
atom_expr [10922,10937]
atom_expr [10922,10937]
===
match
---
operator: , [20872,20873]
operator: , [20869,20870]
===
match
---
simple_stmt [13668,13847]
simple_stmt [13668,13847]
===
match
---
trailer [20193,20206]
trailer [20190,20203]
===
match
---
name: self [15276,15280]
name: self [15276,15280]
===
match
---
operator: , [20029,20030]
operator: , [20026,20027]
===
match
---
trailer [15633,15643]
trailer [15633,15643]
===
match
---
trailer [22792,22799]
trailer [22789,22796]
===
match
---
name: full_pod_spec [19943,19956]
name: full_pod_spec [19940,19953]
===
match
---
simple_stmt [1119,1177]
simple_stmt [1119,1177]
===
match
---
simple_stmt [12296,12327]
simple_stmt [12296,12327]
===
match
---
trailer [12521,12531]
trailer [12521,12531]
===
match
---
simple_stmt [835,851]
simple_stmt [835,851]
===
match
---
name: pod [24271,24274]
name: pod [24395,24398]
===
match
---
name: result [16798,16804]
name: result [16798,16804]
===
match
---
suite [23456,23675]
suite [23480,23699]
===
match
---
atom_expr [10581,10607]
atom_expr [10581,10607]
===
match
---
arglist [16036,16062]
arglist [16036,16062]
===
match
---
operator: } [18411,18412]
operator: } [18411,18412]
===
match
---
tfpdef [8141,8160]
tfpdef [8141,8160]
===
match
---
expr_stmt [20230,21836]
expr_stmt [20227,21833]
===
match
---
operator: { [18721,18722]
operator: { [18735,18736]
===
match
---
trailer [9034,9045]
trailer [9034,9045]
===
match
---
param [9012,9054]
param [9012,9054]
===
match
---
name: delete_namespaced_pod [25563,25584]
name: delete_namespaced_pod [25739,25760]
===
match
---
atom_expr [20561,21825]
atom_expr [20558,21822]
===
match
---
name: pod [25358,25361]
name: pod [25534,25537]
===
match
---
operator: = [20560,20561]
operator: = [20557,20558]
===
match
---
fstring_end: ' [16907,16908]
fstring_end: ' [16907,16908]
===
match
---
operator: , [23640,23641]
operator: , [23664,23665]
===
match
---
operator: , [8489,8490]
operator: , [8489,8490]
===
match
---
arglist [16280,16343]
arglist [16280,16343]
===
match
---
atom_expr [16266,16344]
atom_expr [16266,16344]
===
match
---
name: self [20694,20698]
name: self [20691,20695]
===
match
---
operator: , [8434,8435]
operator: , [8434,8435]
===
match
---
name: labels [8699,8705]
name: labels [8699,8705]
===
match
---
if_stmt [10808,10900]
if_stmt [10808,10900]
===
match
---
operator: , [21892,21893]
operator: , [21889,21890]
===
match
---
operator: = [10008,10009]
operator: = [10008,10009]
===
match
---
number: 0 [16211,16212]
number: 0 [16211,16212]
===
match
---
name: config_file [9063,9074]
name: config_file [9063,9074]
===
match
---
suite [1986,2005]
suite [1986,2005]
===
match
---
simple_stmt [20156,20221]
simple_stmt [20153,20218]
===
match
---
operator: = [10579,10580]
operator: = [10579,10580]
===
match
---
name: pod [23559,23562]
name: pod [23583,23586]
===
match
---
param [8699,8729]
param [8699,8729]
===
match
---
operator: = [9262,9263]
operator: = [9262,9263]
===
match
---
name: AirflowException [19218,19234]
name: AirflowException [19215,19231]
===
match
---
atom_expr [18201,18224]
atom_expr [18201,18224]
===
match
---
name: self [15231,15235]
name: self [15231,15235]
===
match
---
atom [10695,10759]
atom [10695,10759]
===
match
---
simple_stmt [12235,12288]
simple_stmt [12235,12288]
===
match
---
name: self [15526,15530]
name: self [15526,15530]
===
match
---
name: service_account_name [21427,21447]
name: service_account_name [21424,21444]
===
match
---
if_stmt [22057,22207]
if_stmt [22054,22204]
===
match
---
name: security_context [21560,21576]
name: security_context [21557,21573]
===
match
---
operator: = [12204,12205]
operator: = [12204,12205]
===
match
---
trailer [13902,13909]
trailer [13902,13909]
===
match
---
and_test [18021,18096]
and_test [18021,18096]
===
match
---
testlist_star_expr [18486,18517]
testlist_star_expr [18486,18517]
===
match
---
name: final_state [18586,18597]
name: final_state [18586,18597]
===
match
---
atom_expr [13934,13957]
atom_expr [13934,13957]
===
match
---
for_stmt [21908,22049]
for_stmt [21905,22046]
===
match
---
operator: = [25605,25606]
operator: = [25781,25782]
===
match
---
trailer [12882,12888]
trailer [12882,12888]
===
match
---
name: context [13642,13649]
name: context [13642,13649]
===
match
---
name: super [13456,13461]
name: super [13456,13461]
===
match
---
name: self [16665,16669]
name: self [16665,16669]
===
match
---
name: pod_generator [19849,19862]
name: pod_generator [19846,19859]
===
match
---
trailer [22144,22152]
trailer [22141,22149]
===
match
---
subscriptlist [24285,24305]
subscriptlist [24409,24429]
===
match
---
name: on_kill [25210,25217]
name: on_kill [25386,25393]
===
match
---
name: remote_pod [16093,16103]
name: remote_pod [16093,16103]
===
match
---
expr_stmt [11171,11199]
expr_stmt [11171,11199]
===
match
---
name: validate_key [1862,1874]
name: validate_key [1862,1874]
===
match
---
name: scheduler_name [21637,21651]
name: scheduler_name [21634,21648]
===
match
---
simple_stmt [10395,10418]
simple_stmt [10395,10418]
===
match
---
atom_expr [11878,11891]
atom_expr [11878,11891]
===
match
---
name: task_id [19699,19706]
name: task_id [19696,19703]
===
match
---
name: final_state [25139,25150]
name: final_state [25315,25326]
===
match
---
name: backcompat [1692,1702]
name: backcompat [1692,1702]
===
match
---
atom_expr [20606,20624]
atom_expr [20603,20621]
===
match
---
operator: = [25314,25315]
operator: = [25490,25491]
===
match
---
atom_expr [16608,16688]
atom_expr [16608,16688]
===
match
---
trailer [21752,21772]
trailer [21749,21769]
===
match
---
operator: , [8551,8552]
operator: , [8551,8552]
===
match
---
name: node_selector [9153,9166]
name: node_selector [9153,9166]
===
match
---
trailer [12300,12312]
trailer [12300,12312]
===
match
---
trailer [15931,15933]
trailer [15931,15933]
===
match
---
expr_stmt [15586,15675]
expr_stmt [15586,15675]
===
match
---
trailer [18057,18066]
trailer [18057,18066]
===
match
---
fstring [25112,25152]
fstring [25288,25328]
===
match
---
argument [21367,21409]
argument [21364,21406]
===
match
---
operator: , [22138,22139]
operator: , [22135,22136]
===
match
---
or_test [11852,11869]
or_test [11852,11869]
===
match
---
argument [19338,19352]
argument [19335,19349]
===
match
---
tfpdef [9473,9505]
tfpdef [9473,9505]
===
match
---
trailer [18463,18473]
trailer [18463,18473]
===
match
---
operator: , [16372,16373]
operator: , [16372,16373]
===
match
---
name: bool [8630,8634]
name: bool [8630,8634]
===
match
---
file_input [785,25627]
file_input [785,25803]
===
match
---
simple_stmt [23669,23675]
simple_stmt [23693,23699]
===
match
---
comparison [19097,19109]
comparison [19094,19106]
===
match
---
name: priority_class_name [9854,9873]
name: priority_class_name [9854,9873]
===
match
---
import_from [1320,1652]
import_from [1320,1652]
===
match
---
atom [24609,24642]
atom [24733,24766]
===
match
---
operator: = [10479,10480]
operator: = [10479,10480]
===
match
---
name: to_dict [23207,23214]
name: to_dict [23204,23211]
===
match
---
string: "'xcom_push' was deprecated, use 'do_xcom_push' instead" [10174,10230]
string: "'xcom_push' was deprecated, use 'do_xcom_push' instead" [10174,10230]
===
match
---
trailer [10173,10231]
trailer [10173,10231]
===
match
---
operator: , [20710,20711]
operator: , [20707,20708]
===
match
---
name: Optional [8183,8191]
name: Optional [8183,8191]
===
match
---
test [12354,12453]
test [12354,12453]
===
match
---
trailer [21962,22004]
trailer [21959,22001]
===
match
---
atom_expr [12552,12570]
atom_expr [12552,12570]
===
match
---
atom_expr [19152,19170]
atom_expr [19149,19167]
===
match
---
trailer [19698,19706]
trailer [19695,19703]
===
match
---
tfpdef [16953,16965]
tfpdef [16953,16965]
===
match
---
name: labels [24053,24059]
name: labels [24177,24183]
===
match
---
name: _try_numbers_match [16017,16035]
name: _try_numbers_match [16017,16035]
===
match
---
fstring_start: f' [15806,15808]
fstring_start: f' [15806,15808]
===
match
---
operator: } [17850,17851]
operator: } [17850,17851]
===
match
---
name: log [22096,22099]
name: log [22093,22096]
===
match
---
operator: = [14897,14898]
operator: = [14897,14898]
===
match
---
name: Tuple [24279,24284]
name: Tuple [24403,24408]
===
match
---
import_from [1177,1234]
import_from [1177,1234]
===
match
---
operator: = [9183,9184]
operator: = [9183,9184]
===
match
---
simple_stmt [1749,1828]
simple_stmt [1749,1828]
===
match
---
simple_stmt [13337,13428]
simple_stmt [13337,13428]
===
match
---
tfpdef [8948,8995]
tfpdef [8948,8995]
===
match
---
operator: = [21554,21555]
operator: = [21551,21552]
===
match
---
operator: , [8814,8815]
operator: , [8814,8815]
===
match
---
operator: , [21520,21521]
operator: , [21517,21518]
===
match
---
name: task_id [13950,13957]
name: task_id [13950,13957]
===
match
---
atom_expr [20815,21331]
atom_expr [20812,21328]
===
match
---
operator: = [20234,20235]
operator: = [20231,20232]
===
match
---
operator: } [11939,11940]
operator: } [11939,11940]
===
match
---
name: label [18732,18737]
name: label [18747,18752]
===
match
---
parameters [19072,19084]
parameters [19069,19081]
===
match
---
trailer [9176,9182]
trailer [9176,9182]
===
match
---
name: PodGenerator [20439,20451]
name: PodGenerator [20436,20448]
===
match
---
name: k8s [20561,20564]
name: k8s [20558,20561]
===
match
---
operator: = [8932,8933]
operator: = [8932,8933]
===
match
---
arglist [22106,22152]
arglist [22103,22149]
===
match
---
name: pod [22202,22205]
name: pod [22199,22202]
===
match
---
operator: } [16906,16907]
operator: } [16906,16907]
===
match
---
name: _render_nested_template_fields [13036,13066]
name: _render_nested_template_fields [13036,13066]
===
match
---
return_stmt [18579,18617]
return_stmt [18579,18617]
===
match
---
simple_stmt [23825,23855]
simple_stmt [23849,23879]
===
match
---
operator: = [18518,18519]
operator: = [18518,18519]
===
match
---
trailer [23373,23385]
trailer [23397,23409]
===
match
---
atom_expr [12028,12044]
atom_expr [12028,12044]
===
match
---
trailer [21390,21409]
trailer [21387,21406]
===
match
---
operator: , [24269,24270]
operator: , [24393,24394]
===
match
---
name: set [13187,13190]
name: set [13187,13190]
===
match
---
name: log_line [17692,17700]
name: log_line [17692,17700]
===
match
---
name: secrets [11186,11193]
name: secrets [11186,11193]
===
match
---
name: BaseOperator [1307,1319]
name: BaseOperator [1307,1319]
===
match
---
import_as_names [965,989]
import_as_names [965,989]
===
match
---
atom_expr [8413,8425]
atom_expr [8413,8425]
===
match
---
arglist [23052,23060]
arglist [23049,23057]
===
match
---
name: Optional [9875,9883]
name: Optional [9875,9883]
===
match
---
operator: , [927,928]
operator: , [927,928]
===
match
---
trailer [16541,16545]
trailer [16541,16545]
===
match
---
name: self [15460,15464]
name: self [15460,15464]
===
match
---
name: kwargs [10275,10281]
name: kwargs [10275,10281]
===
match
---
name: TYPE_CHECKING [870,883]
name: TYPE_CHECKING [870,883]
===
match
---
name: dict [13654,13658]
name: dict [13654,13658]
===
match
---
trailer [24971,24975]
trailer [25095,25099]
===
match
---
argument [20356,20380]
argument [20353,20377]
===
match
---
tfpdef [8652,8682]
tfpdef [8652,8682]
===
match
---
name: Dict [13121,13125]
name: Dict [13121,13125]
===
match
---
name: self [15149,15153]
name: self [15149,15153]
===
match
---
name: task_id [22678,22685]
name: task_id [22675,22682]
===
match
---
name: log [18455,18458]
name: log [18455,18458]
===
match
---
trailer [16427,16445]
trailer [16427,16445]
===
match
---
suite [25232,25627]
suite [25408,25803]
===
match
---
operator: , [19336,19337]
operator: , [19333,19334]
===
match
---
name: str [9542,9545]
name: str [9542,9545]
===
match
---
name: resources [21086,21095]
name: resources [21083,21092]
===
match
---
dotted_name [1076,1094]
dotted_name [1076,1094]
===
match
---
name: self [19694,19698]
name: self [19691,19695]
===
match
---
trailer [24175,24224]
trailer [24299,24348]
===
match
---
name: str [9085,9088]
name: str [9085,9088]
===
match
---
name: is_delete_operator_pod [12240,12262]
name: is_delete_operator_pod [12240,12262]
===
match
---
trailer [8526,8542]
trailer [8526,8542]
===
match
---
name: do_xcom_push [10312,10324]
name: do_xcom_push [10312,10324]
===
match
---
name: get [18074,18077]
name: get [18074,18077]
===
match
---
simple_stmt [11521,11652]
simple_stmt [11521,11652]
===
match
---
trailer [8357,8371]
trailer [8357,8371]
===
match
---
string: 'name' [13388,13394]
string: 'name' [13388,13394]
===
match
---
name: launcher [23825,23833]
name: launcher [23849,23857]
===
match
---
name: self [16114,16118]
name: self [16114,16118]
===
match
---
name: xcom_sidecar [1815,1827]
name: xcom_sidecar [1815,1827]
===
match
---
operator: , [14727,14728]
operator: , [14727,14728]
===
match
---
trailer [20515,20527]
trailer [20512,20524]
===
match
---
simple_stmt [25266,25292]
simple_stmt [25442,25468]
===
match
---
name: convert_env_vars [1456,1472]
name: convert_env_vars [1456,1472]
===
match
---
operator: , [7970,7971]
operator: , [7970,7971]
===
match
---
test [10921,10970]
test [10921,10970]
===
match
---
name: pod_template_file [12810,12827]
name: pod_template_file [12810,12827]
===
match
---
name: convert_toleration [1585,1603]
name: convert_toleration [1585,1603]
===
match
---
trailer [24188,24193]
trailer [24312,24317]
===
match
---
trailer [25512,25537]
trailer [25688,25713]
===
match
---
atom_expr [10565,10578]
atom_expr [10565,10578]
===
match
---
trailer [20409,20416]
trailer [20406,20413]
===
match
---
name: try_numbers_match [15992,16009]
name: try_numbers_match [15992,16009]
===
match
---
name: kube_client [14649,14660]
name: kube_client [14649,14660]
===
match
---
trailer [24198,24207]
trailer [24322,24331]
===
match
---
atom_expr [11970,11998]
atom_expr [11970,11998]
===
match
---
trailer [16642,16688]
trailer [16642,16688]
===
match
---
trailer [15280,15303]
trailer [15280,15303]
===
match
---
name: List [8579,8583]
name: List [8579,8583]
===
match
---
name: convert_volume [11098,11112]
name: convert_volume [11098,11112]
===
match
---
fstring_end: " [17879,17880]
fstring_end: " [17879,17880]
===
match
---
operator: , [9143,9144]
operator: , [9143,9144]
===
match
---
operator: = [12775,12776]
operator: = [12775,12776]
===
match
---
name: self [19938,19942]
name: self [19935,19939]
===
match
---
funcdef [7998,13027]
funcdef [7998,13027]
===
match
---
param [8177,8210]
param [8177,8210]
===
match
---
operator: , [1556,1557]
operator: , [1556,1557]
===
match
---
trailer [10337,10343]
trailer [10337,10343]
===
match
---
name: result [16105,16111]
name: result [16105,16111]
===
match
---
string: "name" [20212,20218]
string: "name" [20209,20215]
===
match
---
trailer [16682,16687]
trailer [16682,16687]
===
match
---
name: bool [9783,9787]
name: bool [9783,9787]
===
match
---
trailer [16035,16063]
trailer [16035,16063]
===
match
---
operator: , [25002,25003]
operator: , [25126,25127]
===
match
---
operator: , [13559,13560]
operator: , [13559,13560]
===
match
---
trailer [8155,8160]
trailer [8155,8160]
===
match
---
suite [13285,13447]
suite [13285,13447]
===
match
---
name: Optional [9491,9499]
name: Optional [9491,9499]
===
match
---
name: _set_name [12873,12882]
name: _set_name [12873,12882]
===
match
---
operator: , [1623,1624]
operator: , [1623,1624]
===
match
---
operator: , [20764,20765]
operator: , [20761,20762]
===
match
---
name: patch_already_checked [25050,25071]
name: patch_already_checked [25226,25247]
===
match
---
comparison [25415,25456]
comparison [25591,25632]
===
match
---
expr_stmt [19834,19922]
expr_stmt [19831,19919]
===
match
---
name: Optional [17055,17063]
name: Optional [17055,17063]
===
match
---
tfpdef [8609,8635]
tfpdef [8609,8635]
===
match
---
operator: = [11892,11893]
operator: = [11892,11893]
===
match
---
simple_stmt [23331,23424]
simple_stmt [23355,23448]
===
match
---
trailer [25319,25328]
trailer [25495,25504]
===
match
---
name: V1ObjectMeta [20326,20338]
name: V1ObjectMeta [20323,20335]
===
match
---
atom_expr [22775,22814]
atom_expr [22772,22811]
===
match
---
name: self [22946,22950]
name: self [22943,22947]
===
match
---
name: log_events_on_failure [24858,24879]
name: log_events_on_failure [24982,25003]
===
match
---
trailer [21100,21114]
trailer [21097,21111]
===
match
---
name: self [20744,20748]
name: self [20741,20745]
===
match
---
name: Optional [8454,8462]
name: Optional [8454,8462]
===
match
---
string: "Pod template file found, will parse for base pod" [19770,19820]
string: "Pod template file found, will parse for base pod" [19767,19817]
===
match
---
import_from [851,933]
import_from [851,933]
===
match
---
operator: , [1504,1505]
operator: , [1504,1505]
===
match
---
test [11894,11940]
test [11894,11940]
===
match
---
name: priority_class_name [21753,21772]
name: priority_class_name [21750,21769]
===
match
---
name: self [22091,22095]
name: self [22088,22092]
===
match
---
name: node_selector [20592,20605]
name: node_selector [20589,20602]
===
match
---
trailer [16279,16344]
trailer [16279,16344]
===
match
---
operator: { [11822,11823]
operator: { [11822,11823]
===
match
---
simple_stmt [10769,10800]
simple_stmt [10769,10800]
===
match
---
name: get_kube_client [15096,15111]
name: get_kube_client [15096,15111]
===
match
---
arglist [23263,23317]
arglist [23287,23341]
===
match
---
name: kubernetes [1681,1691]
name: kubernetes [1681,1691]
===
match
---
atom_expr [12178,12203]
atom_expr [12178,12203]
===
match
---
testlist_comp [10922,10952]
testlist_comp [10922,10952]
===
match
---
operator: = [11850,11851]
operator: = [11850,11851]
===
match
---
comparison [15950,15974]
comparison [15950,15974]
===
match
---
fstring_start: f' [16530,16532]
fstring_start: f' [16530,16532]
===
match
---
atom_expr [15720,15744]
atom_expr [15720,15744]
===
match
---
trailer [11805,11819]
trailer [11805,11819]
===
match
---
name: event [23642,23647]
name: event [23666,23671]
===
match
---
try_stmt [23227,23855]
try_stmt [23251,23979]
===
match
---
expr_stmt [11801,11824]
expr_stmt [11801,11824]
===
match
---
import_from [1749,1827]
import_from [1749,1827]
===
match
---
simple_stmt [1071,1119]
simple_stmt [1071,1119]
===
match
---
operator: -> [13651,13653]
operator: -> [13651,13653]
===
match
---
name: log [21953,21956]
name: log [21950,21953]
===
match
---
simple_stmt [10467,10494]
simple_stmt [10467,10494]
===
match
---
parameters [25217,25223]
parameters [25393,25399]
===
match
---
param [8824,8846]
param [8824,8846]
===
match
---
atom_expr [21652,21670]
atom_expr [21649,21667]
===
match
---
name: __init__ [8002,8010]
name: __init__ [8002,8010]
===
match
---
simple_stmt [11878,11941]
simple_stmt [11878,11941]
===
match
---
atom_expr [10467,10478]
atom_expr [10467,10478]
===
match
---
operator: = [11403,11404]
operator: = [11403,11404]
===
match
---
name: c [10875,10876]
name: c [10875,10876]
===
match
---
name: hostnetwork [12301,12312]
name: hostnetwork [12301,12312]
===
match
---
trailer [21559,21576]
trailer [21556,21573]
===
match
---
atom_expr [13271,13283]
atom_expr [13271,13283]
===
match
---
raise_stmt [16507,16595]
raise_stmt [16507,16595]
===
match
---
name: self [20984,20988]
name: self [20981,20985]
===
match
---
name: V1ObjectMeta [20194,20206]
name: V1ObjectMeta [20191,20203]
===
match
---
expr_stmt [11664,11699]
expr_stmt [11664,11699]
===
match
---
operator: { [12506,12507]
operator: { [12506,12507]
===
match
---
simple_stmt [11171,11200]
simple_stmt [11171,11200]
===
match
---
trailer [20239,20245]
trailer [20236,20242]
===
match
---
atom_expr [8111,8124]
atom_expr [8111,8124]
===
match
---
name: V1Pod [20240,20245]
name: V1Pod [20237,20242]
===
match
---
name: event [25018,25023]
name: event [25142,25147]
===
match
---
name: str [9587,9590]
name: str [9587,9590]
===
match
---
name: spec [20556,20560]
name: spec [20553,20557]
===
match
---
operator: , [21772,21773]
operator: , [21769,21770]
===
match
---
name: is_subdag [14146,14155]
name: is_subdag [14146,14155]
===
match
---
name: affinity [20642,20650]
name: affinity [20639,20647]
===
match
---
param [8325,8381]
param [8325,8381]
===
match
---
operator: , [8770,8771]
operator: , [8770,8771]
===
match
---
name: pod [24666,24669]
name: pod [24790,24793]
===
match
---
name: pod [18242,18245]
name: pod [18242,18245]
===
match
---
name: pod [21894,21897]
name: pod [21891,21894]
===
match
---
trailer [14037,14043]
trailer [14037,14043]
===
match
---
tfpdef [8266,8308]
tfpdef [8266,8308]
===
match
---
name: self [12067,12071]
name: self [12067,12071]
===
match
---
arglist [23767,23807]
arglist [23791,23831]
===
match
---
atom_expr [15265,15273]
atom_expr [15265,15273]
===
match
---
atom_expr [9300,9313]
atom_expr [9300,9313]
===
match
---
name: Optional [9578,9586]
name: Optional [9578,9586]
===
match
---
trailer [18552,18570]
trailer [18552,18570]
===
match
---
name: pod_template_file [19131,19148]
name: pod_template_file [19128,19145]
===
match
---
import_as_name [1941,1967]
import_as_name [1941,1967]
===
match
---
arglist [23386,23422]
arglist [23410,23446]
===
match
---
atom [20793,21349]
atom [20790,21346]
===
match
---
argument [21286,21308]
argument [21283,21305]
===
match
---
trailer [12466,12483]
trailer [12466,12483]
===
match
---
name: PodGenerator [1222,1234]
name: PodGenerator [1222,1234]
===
match
---
decorated [18913,19054]
decorated [18910,19051]
===
match
---
trailer [20035,20049]
trailer [20032,20046]
===
match
---
name: xcom_push [16726,16735]
name: xcom_push [16726,16735]
===
match
---
atom_expr [8340,8373]
atom_expr [8340,8373]
===
match
---
atom_expr [13251,13284]
atom_expr [13251,13284]
===
match
---
trailer [19456,19462]
trailer [19453,19459]
===
match
---
operator: = [14836,14837]
operator: = [14836,14837]
===
match
---
name: cmds [20948,20952]
name: cmds [20945,20949]
===
match
---
name: client [15245,15251]
name: client [15245,15251]
===
match
---
or_test [10443,10458]
or_test [10443,10458]
===
match
---
name: labels [13855,13861]
name: labels [13855,13861]
===
match
---
name: labels [16159,16165]
name: labels [16159,16165]
===
match
---
trailer [10983,10997]
trailer [10983,10997]
===
match
---
argument [16736,16755]
argument [16736,16755]
===
match
---
simple_stmt [1828,1875]
simple_stmt [1828,1875]
===
match
---
name: convert_toleration [12355,12373]
name: convert_toleration [12355,12373]
===
match
---
name: self [12962,12966]
name: self [12962,12966]
===
match
---
name: containers [20782,20792]
name: containers [20779,20789]
===
match
---
simple_stmt [13298,13325]
simple_stmt [13298,13325]
===
match
---
name: pod [23203,23206]
name: pod [23200,23203]
===
match
---
name: final_state [16461,16472]
name: final_state [16461,16472]
===
match
---
name: affinity [9012,9020]
name: affinity [9012,9020]
===
match
---
name: str [9884,9887]
name: str [9884,9887]
===
match
---
expr_stmt [11949,12019]
expr_stmt [11949,12019]
===
match
---
trailer [23385,23423]
trailer [23409,23447]
===
match
---
name: in_cluster [11226,11236]
name: in_cluster [11226,11236]
===
match
---
expr_stmt [14414,14474]
expr_stmt [14414,14474]
===
match
---
atom_expr [17031,17069]
atom_expr [17031,17069]
===
match
---
atom_expr [24853,24879]
atom_expr [24977,25003]
===
match
---
tfpdef [9376,9393]
tfpdef [9376,9393]
===
match
---
simple_stmt [23147,23219]
simple_stmt [23144,23216]
===
match
---
name: log [22578,22581]
name: log [22575,22578]
===
match
---
argument [16757,16777]
argument [16757,16777]
===
match
---
trailer [18323,18338]
trailer [18323,18338]
===
match
---
simple_stmt [15896,15934]
simple_stmt [15896,15934]
===
match
---
name: pod_template [19974,19986]
name: pod_template [19971,19983]
===
match
---
name: extend [10849,10855]
name: extend [10849,10855]
===
match
---
argument [25596,25615]
argument [25772,25791]
===
match
---
trailer [19769,19821]
trailer [19766,19818]
===
match
---
operator: = [20743,20744]
operator: = [20740,20741]
===
match
---
tfpdef [8855,8887]
tfpdef [8855,8887]
===
match
---
operator: , [16965,16966]
operator: , [16965,16966]
===
match
---
name: convert_volume_mount [1629,1649]
name: convert_volume_mount [1629,1649]
===
match
---
name: launcher [18427,18435]
name: launcher [18427,18435]
===
match
---
testlist [25169,25200]
testlist [25345,25376]
===
match
---
decorator [18913,18927]
decorator [18910,18924]
===
match
---
name: self [12552,12556]
name: self [12552,12556]
===
match
---
simple_stmt [14829,15041]
simple_stmt [14829,15041]
===
match
---
if_stmt [19094,19310]
if_stmt [19091,19307]
===
match
---
trailer [12032,12044]
trailer [12032,12044]
===
match
---
atom_expr [16012,16063]
atom_expr [16012,16063]
===
match
---
name: seen_oids [13176,13185]
name: seen_oids [13176,13185]
===
match
---
simple_stmt [22946,23138]
simple_stmt [22943,23135]
===
match
---
atom_expr [14169,14192]
atom_expr [14169,14192]
===
match
---
operator: , [16755,16756]
operator: , [16755,16756]
===
match
---
tfpdef [8063,8087]
tfpdef [8063,8087]
===
match
---
name: context [14729,14736]
name: context [14729,14736]
===
match
---
simple_stmt [16701,16779]
simple_stmt [16701,16779]
===
match
---
name: image_pull_secrets [12120,12138]
name: image_pull_secrets [12120,12138]
===
match
---
name: try_number [19043,19053]
name: try_number [19040,19050]
===
match
---
operator: , [23354,23355]
operator: , [23378,23379]
===
match
---
name: warn [11530,11534]
name: warn [11530,11534]
===
match
---
name: volume_mounts [21140,21153]
name: volume_mounts [21137,21150]
===
match
---
trailer [10256,10282]
trailer [10256,10282]
===
match
---
param [8561,8600]
param [8561,8600]
===
match
---
trailer [25009,25016]
trailer [25133,25140]
===
match
---
atom_expr [13456,13592]
atom_expr [13456,13592]
===
match
---
name: deserialize_model_file [19876,19898]
name: deserialize_model_file [19873,19895]
===
match
---
comparison [18779,18803]
comparison [18804,18828]
===
match
---
atom_expr [8074,8087]
atom_expr [8074,8087]
===
match
---
arglist [11552,11637]
arglist [11552,11637]
===
match
---
name: list_namespaced_pod [15609,15628]
name: list_namespaced_pod [15609,15628]
===
match
---
atom_expr [8147,8160]
atom_expr [8147,8160]
===
match
---
return_stmt [14525,14538]
return_stmt [14525,14538]
===
match
---
tfpdef [10024,10049]
tfpdef [10024,10049]
===
match
---
string: 'task' [13942,13948]
string: 'task' [13942,13948]
===
match
---
param [8219,8257]
param [8219,8257]
===
match
---
atom_expr [24279,24306]
atom_expr [24403,24430]
===
match
---
operator: , [20416,20417]
operator: , [20413,20414]
===
match
---
name: airflow [1325,1332]
name: airflow [1325,1332]
===
match
---
atom_expr [9076,9089]
atom_expr [9076,9089]
===
match
---
trailer [13314,13323]
trailer [13314,13323]
===
match
---
suite [23570,23657]
suite [23594,23681]
===
match
---
name: self [14687,14691]
name: self [14687,14691]
===
match
---
name: V1Affinity [9035,9045]
name: V1Affinity [9035,9045]
===
match
---
name: jinja_env [13406,13415]
name: jinja_env [13406,13415]
===
match
---
atom_expr [8707,8721]
atom_expr [8707,8721]
===
match
---
string: "Adding secret to task %s" [21963,21989]
string: "Adding secret to task %s" [21960,21986]
===
match
---
name: PodLauncher [14595,14606]
name: PodLauncher [14595,14606]
===
match
---
name: self [12178,12182]
name: self [12178,12182]
===
match
---
simple_stmt [18450,18474]
simple_stmt [18450,18474]
===
match
---
atom_expr [13989,14002]
atom_expr [13989,14002]
===
match
---
operator: , [13415,13416]
operator: , [13415,13416]
===
match
---
if_stmt [10099,10232]
if_stmt [10099,10232]
===
match
---
trailer [21251,21260]
trailer [21248,21257]
===
match
---
trailer [19331,19353]
trailer [19328,19350]
===
match
---
name: event [24901,24906]
name: event [25025,25030]
===
match
---
dotted_name [1833,1854]
dotted_name [1833,1854]
===
match
---
name: convert_affinity [1411,1427]
name: convert_affinity [1411,1427]
===
match
---
operator: = [19348,19349]
operator: = [19345,19346]
===
match
---
dotted_name [1880,1899]
dotted_name [1880,1899]
===
match
---
name: namespace [15353,15362]
name: namespace [15353,15362]
===
match
---
expr_stmt [24040,24087]
expr_stmt [24164,24211]
===
match
---
or_test [10785,10799]
or_test [10785,10799]
===
match
---
name: node_selector [11745,11758]
name: node_selector [11745,11758]
===
match
---
atom_expr [21991,22003]
atom_expr [21988,22000]
===
match
---
name: warnings [11521,11529]
name: warnings [11521,11529]
===
match
---
name: full_pod_spec [19157,19170]
name: full_pod_spec [19154,19167]
===
match
---
name: termination_grace_period [25513,25537]
name: termination_grace_period [25689,25713]
===
match
---
atom_expr [12805,12827]
atom_expr [12805,12827]
===
match
---
name: self [19719,19723]
name: self [19716,19720]
===
match
---
name: self [21096,21100]
name: self [21093,21097]
===
match
---
import_from [1235,1279]
import_from [1235,1279]
===
match
---
trailer [24059,24078]
trailer [24183,24202]
===
match
---
trailer [22779,22783]
trailer [22776,22780]
===
match
---
operator: = [9047,9048]
operator: = [9047,9048]
===
match
---
atom_expr [10157,10231]
atom_expr [10157,10231]
===
match
---
name: self [13076,13080]
name: self [13076,13080]
===
match
---
name: items [18768,18773]
name: items [18792,18797]
===
match
---
name: kubernetes [1248,1258]
name: kubernetes [1248,1258]
===
match
---
name: configmaps [10811,10821]
name: configmaps [10811,10821]
===
match
---
trailer [13463,13494]
trailer [13463,13494]
===
match
---
name: self [19899,19903]
name: self [19896,19900]
===
match
---
name: k8s [20171,20174]
name: k8s [20168,20171]
===
match
---
trailer [19156,19170]
trailer [19153,19167]
===
match
---
testlist_star_expr [16361,16392]
testlist_star_expr [16361,16392]
===
match
---
atom_expr [12093,12139]
atom_expr [12093,12139]
===
match
---
operator: , [7859,7860]
operator: , [7859,7860]
===
match
---
string: 'config_file' [7928,7941]
string: 'config_file' [7928,7941]
===
match
---
trailer [17015,17021]
trailer [17015,17021]
===
match
---
trailer [19637,19643]
trailer [19634,19640]
===
match
---
name: dict [9177,9181]
name: dict [9177,9181]
===
match
---
atom_expr [10835,10899]
atom_expr [10835,10899]
===
match
---
operator: = [24101,24102]
operator: = [24225,24226]
===
match
---
operator: { [18426,18427]
operator: { [18426,18427]
===
match
---
operator: , [7918,7919]
operator: , [7918,7919]
===
match
---
operator: } [15862,15863]
operator: } [15862,15863]
===
match
---
name: kwargs [25474,25480]
name: kwargs [25650,25656]
===
match
---
operator: = [8764,8765]
operator: = [8764,8765]
===
match
---
trailer [11529,11534]
trailer [11529,11534]
===
match
---
trailer [25419,25444]
trailer [25595,25620]
===
match
---
trailer [25111,25153]
trailer [25287,25329]
===
match
---
operator: = [9137,9138]
operator: = [9137,9138]
===
match
---
name: DeprecationWarning [11619,11637]
name: DeprecationWarning [11619,11637]
===
match
---
trailer [23647,23655]
trailer [23671,23679]
===
match
---
operator: , [23271,23272]
operator: , [23295,23296]
===
match
---
name: affinity [11911,11919]
name: affinity [11911,11919]
===
match
---
string: 'dag' [13896,13901]
string: 'dag' [13896,13901]
===
insert-tree
---
simple_stmt [785,825]
    string: """Executes task in a Kubernetes POD""" [785,824]
to
file_input [785,25627]
at 0
===
insert-node
---
name: KubernetesPodOperator [2013,2034]
to
classdef [2007,25627]
at 0
===
insert-node
---
name: BaseOperator [2035,2047]
to
classdef [2007,25627]
at 1
===
insert-tree
---
simple_stmt [2054,7788]
    string: """     Execute a task in a Kubernetes Pod      .. seealso::         For more information on how to use this operator, take a look at the guide:         :ref:`howto/operator:KubernetesPodOperator`      .. note::         If you use `Google Kubernetes Engine <https://cloud.google.com/kubernetes-engine/>`__         and Airflow is not running in the same cluster, consider using         :class:`~airflow.providers.google.cloud.operators.kubernetes_engine.GKEStartPodOperator`, which         simplifies the authorization process.      :param namespace: the namespace to run within kubernetes.     :type namespace: str     :param image: Docker image you wish to launch. Defaults to hub.docker.com,         but fully qualified URLS will point to custom repositories. (templated)     :type image: str     :param name: name of the pod in which the task will run, will be used (plus a random         suffix) to generate a pod id (DNS-1123 subdomain, containing only [a-z0-9.-]).     :type name: str     :param cmds: entrypoint of the container. (templated)         The docker images's entrypoint is used if this is not provided.     :type cmds: list[str]     :param arguments: arguments of the entrypoint. (templated)         The docker image's CMD is used if this is not provided.     :type arguments: list[str]     :param ports: ports for launched pod.     :type ports: list[k8s.V1ContainerPort]     :param volume_mounts: volumeMounts for launched pod.     :type volume_mounts: list[k8s.V1VolumeMount]     :param volumes: volumes for launched pod. Includes ConfigMaps and PersistentVolumes.     :type volumes: list[k8s.V1Volume]     :param env_vars: Environment variables initialized in the container. (templated)     :type env_vars: list[k8s.V1EnvVar]     :param secrets: Kubernetes secrets to inject in the container.         They can be exposed as environment vars or files in a volume.     :type secrets: list[airflow.kubernetes.secret.Secret]     :param in_cluster: run kubernetes client with in_cluster configuration.     :type in_cluster: bool     :param cluster_context: context that points to kubernetes cluster.         Ignored when in_cluster is True. If None, current-context is used.     :type cluster_context: str     :param reattach_on_restart: if the scheduler dies while the pod is running, reattach and monitor     :type reattach_on_restart: bool     :param labels: labels to apply to the Pod. (templated)     :type labels: dict     :param startup_timeout_seconds: timeout in seconds to startup the pod.     :type startup_timeout_seconds: int     :param get_logs: get the stdout of the container as logs of the tasks.     :type get_logs: bool     :param image_pull_policy: Specify a policy to cache or always pull an image.     :type image_pull_policy: str     :param annotations: non-identifying metadata you can attach to the Pod.         Can be a large range of data, and can include characters         that are not permitted by labels.     :type annotations: dict     :param resources: A dict containing resources requests and limits.         Possible keys are request_memory, request_cpu, limit_memory, limit_cpu,         and limit_gpu, which will be used to generate airflow.kubernetes.pod.Resources.         See also kubernetes.io/docs/concepts/configuration/manage-compute-resources-container     :type resources: k8s.V1ResourceRequirements     :param affinity: A dict containing a group of affinity scheduling rules.     :type affinity: k8s.V1Affinity     :param config_file: The path to the Kubernetes config file. (templated)         If not specified, default value is ``~/.kube/config``     :type config_file: str     :param node_selectors: A dict containing a group of scheduling rules.     :type node_selectors: dict     :param image_pull_secrets: Any image pull secrets to be given to the pod.         If more than one secret is required, provide a         comma separated list: secret_a,secret_b     :type image_pull_secrets: List[k8s.V1LocalObjectReference]     :param service_account_name: Name of the service account     :type service_account_name: str     :param is_delete_operator_pod: What to do when the pod reaches its final         state, or the execution is interrupted.         If False (default): do nothing, If True: delete the pod     :type is_delete_operator_pod: bool     :param hostnetwork: If True enable host networking on the pod.     :type hostnetwork: bool     :param tolerations: A list of kubernetes tolerations.     :type tolerations: List[k8s.V1Toleration]     :param security_context: security options the pod should run with (PodSecurityContext).     :type security_context: dict     :param dnspolicy: dnspolicy for the pod.     :type dnspolicy: str     :param schedulername: Specify a schedulername for the pod     :type schedulername: str     :param full_pod_spec: The complete podSpec     :type full_pod_spec: kubernetes.client.models.V1Pod     :param init_containers: init container for the launched Pod     :type init_containers: list[kubernetes.client.models.V1Container]     :param log_events_on_failure: Log the pod's events if a failure occurs     :type log_events_on_failure: bool     :param do_xcom_push: If True, the content of the file         /airflow/xcom/return.json in the container will also be pushed to an         XCom when the container completes.     :type do_xcom_push: bool     :param pod_template_file: path to pod template file (templated)     :type pod_template_file: str     :param priority_class_name: priority class name for the launched Pod     :type priority_class_name: str     :param termination_grace_period: Termination grace period if task killed in UI,         defaults to kubernetes default     :type termination_grace_period: int     """ [2054,7787]
to
suite [2049,25627]
at 0
===
insert-node
---
decorated [18623,18905]
to
suite [2049,25627]
at 9
===
insert-node
---
funcdef [18641,18905]
to
decorated [18623,18905]
at 1
===
move-tree
---
parameters [18678,18686]
    param [18679,18685]
        name: labels [18679,18685]
to
funcdef [18641,18905]
at 1
===
insert-node
---
suite [18694,18905]
to
funcdef [18641,18905]
at 4
===
insert-tree
---
simple_stmt [23224,23243]
    expr_stmt [23224,23242]
        name: final_state [23224,23235]
        operator: = [23236,23237]
to
suite [22329,23902]
at 5
===
move-tree
---
simple_stmt [18703,18805]
    expr_stmt [18703,18804]
        name: filtered_labels [18703,18718]
        operator: = [18719,18720]
        atom [18721,18804]
            operator: { [18721,18722]
            dictorsetmaker [18722,18803]
                name: label_id [18722,18730]
                name: label [18732,18737]
                sync_comp_for [18738,18803]
                    exprlist [18742,18757]
                        name: label_id [18742,18750]
                        operator: , [18750,18751]
                        name: label [18752,18757]
                    atom_expr [18761,18775]
                        name: labels [18761,18767]
                        trailer [18767,18773]
                            name: items [18768,18773]
                        trailer [18773,18775]
                    comp_if [18776,18803]
                        comparison [18779,18803]
                            name: label_id [18779,18787]
                            operator: != [18788,18790]
                            string: 'try_number' [18791,18803]
            operator: } [18803,18804]
to
suite [18694,18905]
at 0
===
insert-node
---
if_stmt [25169,25253]
to
suite [24837,25154]
at 1
===
update-node
---
name: filtered_labels [18703,18718]
replace filtered_labels by label_strings
===
insert-tree
---
comparison [23896,23924]
    name: final_state [23896,23907]
    operator: != [23908,23910]
    atom_expr [23911,23924]
        name: State [23911,23916]
        trailer [23916,23924]
            name: SUCCESS [23917,23924]
to
if_stmt [23704,23855]
at 2
===
insert-tree
---
suite [23925,23979]
    simple_stmt [23942,23979]
        atom_expr [23942,23978]
            name: self [23942,23946]
            trailer [23946,23968]
                name: patch_already_checked [23947,23968]
            trailer [23968,23978]
                atom_expr [23969,23977]
                    name: self [23969,23973]
                    trailer [23973,23977]
                        name: pod [23974,23977]
to
if_stmt [23704,23855]
at 3
===
insert-node
---
suite [25204,25253]
to
if_stmt [25169,25253]
at 1
===
insert-node
---
testlist_comp [18733,18828]
to
atom [18721,18804]
at 0
===
move-tree
---
simple_stmt [25045,25077]
    atom_expr [25045,25076]
        name: self [25045,25049]
        trailer [25049,25071]
            name: patch_already_checked [25050,25071]
        trailer [25071,25076]
            name: pod [25072,25075]
to
suite [25204,25253]
at 0
===
insert-node
---
fstring [18733,18754]
to
testlist_comp [18733,18828]
at 0
===
move-tree
---
sync_comp_for [18738,18803]
    exprlist [18742,18757]
        name: label_id [18742,18750]
        operator: , [18750,18751]
        name: label [18752,18757]
    atom_expr [18761,18775]
        name: labels [18761,18767]
        trailer [18767,18773]
            name: items [18768,18773]
        trailer [18773,18775]
    comp_if [18776,18803]
        comparison [18779,18803]
            name: label_id [18779,18787]
            operator: != [18788,18790]
            string: 'try_number' [18791,18803]
to
testlist_comp [18733,18828]
at 1
===
insert-node
---
fstring_expr [18735,18745]
to
fstring [18733,18754]
at 1
===
insert-node
---
fstring_expr [18746,18753]
to
fstring [18733,18754]
at 3
===
insert-node
---
atom_expr [18778,18800]
to
sync_comp_for [18738,18803]
at 1
===
move-tree
---
operator: { [18721,18722]
to
fstring_expr [18735,18745]
at 0
===
move-tree
---
name: label_id [18722,18730]
to
fstring_expr [18735,18745]
at 1
===
move-tree
---
name: label [18732,18737]
to
fstring_expr [18746,18753]
at 1
===
insert-node
---
trailer [18784,18800]
to
atom_expr [18778,18800]
at 1
===
move-tree
---
atom_expr [18761,18775]
    name: labels [18761,18767]
    trailer [18767,18773]
        name: items [18768,18773]
    trailer [18773,18775]
to
trailer [18784,18800]
at 0
===
delete-tree
---
simple_stmt [785,825]
    string: """Executes task in a Kubernetes POD""" [785,824]
===
delete-node
---
name: KubernetesPodOperator [2013,2034]
===
===
delete-node
---
name: BaseOperator [2035,2047]
===
===
delete-tree
---
simple_stmt [2054,7788]
    string: """     Execute a task in a Kubernetes Pod      .. seealso::         For more information on how to use this operator, take a look at the guide:         :ref:`howto/operator:KubernetesPodOperator`      .. note::         If you use `Google Kubernetes Engine <https://cloud.google.com/kubernetes-engine/>`__         and Airflow is not running in the same cluster, consider using         :class:`~airflow.providers.google.cloud.operators.kubernetes_engine.GKEStartPodOperator`, which         simplifies the authorization process.      :param namespace: the namespace to run within kubernetes.     :type namespace: str     :param image: Docker image you wish to launch. Defaults to hub.docker.com,         but fully qualified URLS will point to custom repositories. (templated)     :type image: str     :param name: name of the pod in which the task will run, will be used (plus a random         suffix) to generate a pod id (DNS-1123 subdomain, containing only [a-z0-9.-]).     :type name: str     :param cmds: entrypoint of the container. (templated)         The docker images's entrypoint is used if this is not provided.     :type cmds: list[str]     :param arguments: arguments of the entrypoint. (templated)         The docker image's CMD is used if this is not provided.     :type arguments: list[str]     :param ports: ports for launched pod.     :type ports: list[k8s.V1ContainerPort]     :param volume_mounts: volumeMounts for launched pod.     :type volume_mounts: list[k8s.V1VolumeMount]     :param volumes: volumes for launched pod. Includes ConfigMaps and PersistentVolumes.     :type volumes: list[k8s.V1Volume]     :param env_vars: Environment variables initialized in the container. (templated)     :type env_vars: list[k8s.V1EnvVar]     :param secrets: Kubernetes secrets to inject in the container.         They can be exposed as environment vars or files in a volume.     :type secrets: list[airflow.kubernetes.secret.Secret]     :param in_cluster: run kubernetes client with in_cluster configuration.     :type in_cluster: bool     :param cluster_context: context that points to kubernetes cluster.         Ignored when in_cluster is True. If None, current-context is used.     :type cluster_context: str     :param reattach_on_restart: if the scheduler dies while the pod is running, reattach and monitor     :type reattach_on_restart: bool     :param labels: labels to apply to the Pod. (templated)     :type labels: dict     :param startup_timeout_seconds: timeout in seconds to startup the pod.     :type startup_timeout_seconds: int     :param get_logs: get the stdout of the container as logs of the tasks.     :type get_logs: bool     :param image_pull_policy: Specify a policy to cache or always pull an image.     :type image_pull_policy: str     :param annotations: non-identifying metadata you can attach to the Pod.         Can be a large range of data, and can include characters         that are not permitted by labels.     :type annotations: dict     :param resources: A dict containing resources requests and limits.         Possible keys are request_memory, request_cpu, limit_memory, limit_cpu,         and limit_gpu, which will be used to generate airflow.kubernetes.pod.Resources.         See also kubernetes.io/docs/concepts/configuration/manage-compute-resources-container     :type resources: k8s.V1ResourceRequirements     :param affinity: A dict containing a group of affinity scheduling rules.     :type affinity: k8s.V1Affinity     :param config_file: The path to the Kubernetes config file. (templated)         If not specified, default value is ``~/.kube/config``     :type config_file: str     :param node_selectors: A dict containing a group of scheduling rules.     :type node_selectors: dict     :param image_pull_secrets: Any image pull secrets to be given to the pod.         If more than one secret is required, provide a         comma separated list: secret_a,secret_b     :type image_pull_secrets: List[k8s.V1LocalObjectReference]     :param service_account_name: Name of the service account     :type service_account_name: str     :param is_delete_operator_pod: What to do when the pod reaches its final         state, or the execution is interrupted.         If False (default): do nothing, If True: delete the pod     :type is_delete_operator_pod: bool     :param hostnetwork: If True enable host networking on the pod.     :type hostnetwork: bool     :param tolerations: A list of kubernetes tolerations.     :type tolerations: List[k8s.V1Toleration]     :param security_context: security options the pod should run with (PodSecurityContext).     :type security_context: dict     :param dnspolicy: dnspolicy for the pod.     :type dnspolicy: str     :param schedulername: Specify a schedulername for the pod     :type schedulername: str     :param full_pod_spec: The complete podSpec     :type full_pod_spec: kubernetes.client.models.V1Pod     :param init_containers: init container for the launched Pod     :type init_containers: list[kubernetes.client.models.V1Container]     :param log_events_on_failure: Log the pod's events if a failure occurs     :type log_events_on_failure: bool     :param do_xcom_push: If True, the content of the file         /airflow/xcom/return.json in the container will also be pushed to an         XCom when the container completes.     :type do_xcom_push: bool     :param pod_template_file: path to pod template file (templated)     :type pod_template_file: str     :param priority_class_name: priority class name for the launched Pod     :type priority_class_name: str     :param termination_grace_period: Termination grace period if task killed in UI,         defaults to kubernetes default     :type termination_grace_period: int     """ [2054,7787]
===
delete-node
---
dictorsetmaker [18722,18803]
===
===
delete-node
---
operator: } [18803,18804]
===
===
delete-node
---
suite [18694,18908]
===
===
delete-node
---
funcdef [18641,18908]
===
===
delete-node
---
decorated [18623,18908]
===
