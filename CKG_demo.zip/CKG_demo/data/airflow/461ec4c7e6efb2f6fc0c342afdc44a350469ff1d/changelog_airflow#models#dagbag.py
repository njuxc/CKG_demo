===
match
---
name: safe_mode [11937,11946]
name: safe_mode [11841,11850]
===
match
---
atom_expr [15441,15469]
atom_expr [15345,15373]
===
match
---
name: session [26188,26195]
name: session [26092,26099]
===
match
---
trailer [15516,15530]
trailer [15420,15434]
===
match
---
name: conf [3936,3940]
name: conf [3909,3913]
===
match
---
simple_stmt [17456,17520]
simple_stmt [17360,17424]
===
match
---
name: current_module [15573,15587]
name: current_module [15477,15491]
===
match
---
atom [13708,13720]
atom [13612,13624]
===
match
---
string: "keys" [23475,23481]
string: "keys" [23379,23385]
===
match
---
trailer [4780,4798]
trailer [4753,4771]
===
match
---
name: dag_id [8299,8305]
name: dag_id [8272,8278]
===
match
---
if_stmt [14615,14729]
if_stmt [14519,14633]
===
match
---
fstring [12941,13019]
fstring [12845,12923]
===
match
---
name: subdags [16802,16809]
name: subdags [16706,16713]
===
match
---
atom [25066,25068]
atom [24970,24972]
===
match
---
name: duration [22224,22232]
name: duration [22128,22136]
===
match
---
name: filepath [12252,12260]
name: filepath [12156,12164]
===
match
---
name: file_last_changed [11605,11622]
name: file_last_changed [11509,11526]
===
match
---
atom_expr [7813,7835]
atom_expr [7786,7808]
===
match
---
trailer [12490,12549]
trailer [12394,12453]
===
match
---
trailer [13613,13624]
trailer [13517,13528]
===
match
---
simple_stmt [24591,24601]
simple_stmt [24495,24505]
===
match
---
trailer [8897,8904]
trailer [8870,8877]
===
match
---
name: root_dag [17905,17913]
name: root_dag [17809,17817]
===
match
---
argument [5444,5465]
argument [5417,5438]
===
match
---
tfpdef [3828,3854]
tfpdef [3801,3827]
===
match
---
suite [10471,10565]
suite [10444,10469]
===
match
---
name: sha1 [12722,12726]
name: sha1 [12626,12630]
===
match
---
not_test [10463,10470]
not_test [10436,10443]
===
match
---
string: 'core' [20246,20252]
string: 'core' [20150,20156]
===
match
---
name: dags [23076,23080]
name: dags [22980,22984]
===
match
---
name: current_zip_file [14266,14282]
name: current_zip_file [14170,14186]
===
match
---
simple_stmt [21658,22092]
simple_stmt [21562,21996]
===
match
---
atom_expr [23201,23218]
atom_expr [23105,23122]
===
match
---
name: dag [16798,16801]
name: dag [16702,16705]
===
match
---
return_stmt [11736,11745]
return_stmt [11640,11649]
===
match
---
name: filepath [12679,12687]
name: filepath [12583,12591]
===
match
---
expr_stmt [5303,5404]
expr_stmt [5276,5377]
===
match
---
trailer [19279,19291]
trailer [19183,19195]
===
match
---
parameters [16255,16304]
parameters [16159,16208]
===
match
---
argument [7133,7148]
argument [7106,7121]
===
match
---
operator: , [4433,4434]
operator: , [4406,4407]
===
match
---
param [10893,10902]
param [10797,10806]
===
match
---
atom_expr [12052,12116]
atom_expr [11956,12020]
===
match
---
atom_expr [14746,14811]
atom_expr [14650,14715]
===
match
---
fstring_end: """ [23871,23874]
fstring_end: """ [23775,23778]
===
match
---
operator: , [24884,24885]
operator: , [24788,24789]
===
match
---
operator: = [16398,16399]
operator: = [16302,16303]
===
match
---
name: Dict [1029,1033]
name: Dict [1029,1033]
===
match
---
name: values [22954,22960]
name: values [22858,22864]
===
match
---
if_stmt [8763,8921]
if_stmt [8736,8894]
===
match
---
name: session [24906,24913]
name: session [24810,24817]
===
match
---
name: last_expired [9363,9375]
name: last_expired [9336,9348]
===
match
---
trailer [19034,19042]
trailer [18938,18946]
===
match
---
string: "Failed to write serialized DAG: %s" [25193,25229]
string: "Failed to write serialized DAG: %s" [25097,25133]
===
match
---
expr_stmt [4881,4904]
expr_stmt [4854,4877]
===
match
---
arglist [27866,27896]
arglist [27770,27800]
===
match
---
simple_stmt [27597,27665]
simple_stmt [27501,27569]
===
match
---
sync_comp_for [16422,16472]
sync_comp_for [16326,16376]
===
match
---
operator: = [16723,16724]
operator: = [16627,16628]
===
match
---
fstring_string: s.\n [13014,13018]
fstring_string: s.\n [12918,12922]
===
match
---
suite [12328,12572]
suite [12232,12476]
===
match
---
fstring_string: _ [12812,12813]
fstring_string: _ [12716,12717]
===
match
---
name: safe_mode [21564,21573]
name: safe_mode [21468,21477]
===
match
---
simple_stmt [26835,26911]
simple_stmt [26739,26815]
===
match
---
comparison [11588,11622]
comparison [11492,11526]
===
match
---
name: utcnow [21465,21471]
name: utcnow [21369,21375]
===
match
---
operator: = [18844,18845]
operator: = [18748,18749]
===
match
---
atom_expr [3591,3650]
atom_expr [3564,3623]
===
match
---
trailer [9654,9661]
trailer [9627,9634]
===
match
---
trailer [22997,23005]
trailer [22901,22909]
===
match
---
if_stmt [11244,11319]
if_stmt [11148,11223]
===
match
---
name: Optional [26668,26676]
name: Optional [26572,26580]
===
match
---
trailer [18789,18800]
trailer [18693,18704]
===
match
---
atom_expr [21503,21584]
atom_expr [21407,21488]
===
match
---
trailer [8561,8593]
trailer [8534,8566]
===
match
---
name: sys [15441,15444]
name: sys [15345,15348]
===
match
---
name: settings [7726,7734]
name: settings [7699,7707]
===
match
---
name: self [23201,23205]
name: self [23105,23109]
===
match
---
trailer [12688,12692]
trailer [12592,12596]
===
match
---
name: self [25906,25910]
name: self [25810,25814]
===
match
---
expr_stmt [2072,2084]
expr_stmt [2045,2057]
===
match
---
name: task_num [2089,2097]
name: task_num [2062,2070]
===
match
---
suite [15831,16010]
suite [15735,15914]
===
match
---
sync_comp_for [16408,16472]
sync_comp_for [16312,16376]
===
match
---
arglist [12491,12548]
arglist [12395,12452]
===
match
---
string: """             Try to serialize the dag to the DB, but make a note of any errors.              We can't place them directly in import_errors, as this may be retried, and work the next time             """ [24339,24544]
string: """             Try to serialize the dag to the DB, but make a note of any errors.              We can't place them directly in import_errors, as this may be retried, and work the next time             """ [24243,24448]
===
match
---
name: datetime [11468,11476]
name: datetime [11372,11380]
===
match
---
simple_stmt [16614,16636]
simple_stmt [16518,16540]
===
match
---
name: _sync_perm_for_dag [26629,26647]
name: _sync_perm_for_dag [26533,26551]
===
match
---
suite [24574,24601]
suite [24478,24505]
===
match
---
name: self [10887,10891]
name: self [10791,10795]
===
match
---
trailer [22463,22468]
trailer [22367,22372]
===
match
---
trailer [14791,14800]
trailer [14695,14704]
===
match
---
expr_stmt [3557,3650]
expr_stmt [3530,3623]
===
match
---
sync_comp_for [23419,23433]
sync_comp_for [23323,23337]
===
match
---
name: mod [16568,16571]
name: mod [16472,16475]
===
match
---
name: row [10627,10630]
name: row [10531,10534]
===
match
---
funcdef [6494,10224]
funcdef [6467,10197]
===
match
---
operator: } [13013,13014]
operator: } [12917,12918]
===
match
---
trailer [6454,6459]
trailer [6427,6432]
===
match
---
simple_stmt [5915,5937]
simple_stmt [5888,5910]
===
match
---
name: warnings [4276,4284]
name: warnings [4249,4257]
===
match
---
operator: = [4820,4821]
operator: = [4793,4794]
===
match
---
name: modules [12886,12893]
name: modules [12790,12797]
===
match
---
atom_expr [24841,24884]
atom_expr [24745,24788]
===
match
---
trailer [24774,24940]
trailer [24678,24844]
===
match
---
name: SerializedDagModel [10378,10396]
name: SerializedDagModel [10351,10369]
===
match
---
operator: = [4111,4112]
operator: = [4084,4085]
===
match
---
simple_stmt [10086,10111]
simple_stmt [10059,10084]
===
match
---
simple_stmt [17593,17865]
simple_stmt [17497,17769]
===
match
---
operator: , [6518,6519]
operator: , [6491,6492]
===
match
---
simple_stmt [15856,16010]
simple_stmt [15760,15914]
===
match
---
operator: , [13317,13318]
operator: , [13221,13222]
===
match
---
simple_stmt [27831,27898]
simple_stmt [27735,27802]
===
match
---
expr_stmt [15083,15105]
expr_stmt [14987,15009]
===
match
---
trailer [11476,11490]
trailer [11380,11394]
===
match
---
atom_expr [20963,20978]
atom_expr [20867,20882]
===
match
---
name: super [4210,4215]
name: super [4183,4188]
===
match
---
name: airflow [1513,1520]
name: airflow [1486,1493]
===
match
---
string: 'dagbag_import_error_tracebacks' [5261,5293]
string: 'dagbag_import_error_tracebacks' [5234,5266]
===
match
---
trailer [8041,8132]
trailer [8014,8105]
===
match
---
expr_stmt [12126,12186]
expr_stmt [12030,12090]
===
match
---
simple_stmt [869,879]
simple_stmt [869,879]
===
match
---
name: sqla_models [27362,27373]
name: sqla_models [27266,27277]
===
match
---
operator: * [17955,17956]
operator: * [17859,17860]
===
match
---
trailer [22014,22050]
trailer [21918,21954]
===
match
---
name: timedelta [2058,2067]
name: timedelta [2031,2040]
===
match
---
arglist [25724,25871]
arglist [25628,25775]
===
match
---
atom_expr [27878,27896]
atom_expr [27782,27800]
===
match
---
expr_stmt [5010,5058]
expr_stmt [4983,5031]
===
match
---
operator: , [9857,9858]
operator: , [9830,9831]
===
match
---
name: name [27383,27387]
name: name [27287,27291]
===
match
---
simple_stmt [12039,12117]
simple_stmt [11943,12021]
===
match
---
with_stmt [14232,16210]
with_stmt [14136,16114]
===
match
---
name: stats [23193,23198]
name: stats [23097,23102]
===
match
---
trailer [9546,9551]
trailer [9519,9524]
===
match
---
string: "Filling up the DagBag from %s" [20883,20914]
string: "Filling up the DagBag from %s" [20787,20818]
===
match
---
trailer [10786,10793]
trailer [10690,10697]
===
match
---
name: importlib [810,819]
name: importlib [810,819]
===
match
---
atom_expr [19066,19257]
atom_expr [18970,19161]
===
match
---
name: ext [14487,14490]
name: ext [14391,14394]
===
match
---
atom_expr [14367,14399]
atom_expr [14271,14303]
===
match
---
name: subdag [19762,19768]
name: subdag [19666,19672]
===
match
---
string: 'LOAD_EXAMPLES' [20096,20111]
string: 'LOAD_EXAMPLES' [20000,20015]
===
match
---
trailer [11676,11694]
trailer [11580,11598]
===
match
---
name: dag_folder [4578,4588]
name: dag_folder [4551,4561]
===
match
---
name: read_dags_from_db [4918,4935]
name: read_dags_from_db [4891,4908]
===
match
---
suite [9119,9161]
suite [9092,9134]
===
match
---
argument [17896,17913]
argument [17800,17817]
===
match
---
simple_stmt [14589,14598]
simple_stmt [14493,14502]
===
match
---
name: encode [12736,12742]
name: encode [12640,12646]
===
match
---
param [10925,10939]
param [10829,10843]
===
match
---
operator: = [5546,5547]
operator: = [5519,5520]
===
match
---
name: attempt [25800,25807]
name: attempt [25704,25711]
===
match
---
argument [21943,21979]
argument [21847,21883]
===
match
---
simple_stmt [11823,11833]
simple_stmt [11727,11737]
===
match
---
atom_expr [9471,9480]
atom_expr [9444,9453]
===
match
---
name: dag [9535,9538]
name: dag [9508,9511]
===
match
---
operator: = [15656,15657]
operator: = [15560,15561]
===
match
---
name: subdags [22908,22915]
name: subdags [22812,22819]
===
match
---
trailer [13295,13317]
trailer [13199,13221]
===
match
---
name: dag_id [22020,22026]
name: dag_id [21924,21930]
===
match
---
string: """Collects DAGs from database.""" [22293,22327]
string: """Collects DAGs from database.""" [22197,22231]
===
match
---
atom [11830,11832]
atom [11734,11736]
===
match
---
operator: = [8105,8106]
operator: = [8078,8079]
===
match
---
name: duration [23264,23272]
name: duration [23168,23176]
===
match
---
name: self [7813,7817]
name: self [7786,7790]
===
match
---
name: format_exc [13942,13952]
name: format_exc [13846,13856]
===
match
---
operator: , [21980,21981]
operator: , [21884,21885]
===
match
---
name: str [3710,3713]
name: str [3683,3686]
===
match
---
expr_stmt [17456,17519]
expr_stmt [17360,17423]
===
match
---
param [20122,20203]
param [20026,20107]
===
match
---
suite [11878,11948]
suite [11782,11852]
===
match
---
operator: = [4020,4021]
operator: = [3993,3994]
===
match
---
name: only_if_updated [20009,20024]
name: only_if_updated [19913,19928]
===
match
---
trailer [26249,26256]
trailer [26153,26160]
===
match
---
trailer [13605,13613]
trailer [13509,13517]
===
match
---
name: hexdigest [12753,12762]
name: hexdigest [12657,12666]
===
match
---
name: TYPE_CHECKING [1921,1934]
name: TYPE_CHECKING [1894,1907]
===
match
---
suite [14568,14598]
suite [14472,14502]
===
match
---
simple_stmt [20936,20979]
simple_stmt [20840,20883]
===
match
---
expr_stmt [21042,21052]
expr_stmt [20946,20956]
===
match
---
name: dag_was_updated [24960,24975]
name: dag_was_updated [24864,24879]
===
match
---
name: log [12586,12589]
name: log [12490,12493]
===
match
---
decorated [6473,10224]
decorated [6446,10197]
===
match
---
operator: = [21546,21547]
operator: = [21450,21451]
===
match
---
name: safe_mode [21265,21274]
name: safe_mode [21169,21178]
===
match
---
string: "Importing %s" [12596,12610]
string: "Importing %s" [12500,12514]
===
match
---
suite [23126,23907]
suite [23030,23811]
===
match
---
simple_stmt [13535,13586]
simple_stmt [13439,13490]
===
match
---
trailer [13952,14047]
trailer [13856,13951]
===
match
---
param [23954,23987]
param [23858,23891]
===
match
---
string: 'best-practices.html#reducing-dag-complexity' [13211,13256]
string: 'best-practices.html#reducing-dag-complexity' [13115,13160]
===
match
---
operator: , [24921,24922]
operator: , [24825,24826]
===
match
---
name: dags [26088,26092]
name: dags [25992,25996]
===
match
---
simple_stmt [2072,2085]
simple_stmt [2045,2058]
===
match
---
fstring_expr [23646,23658]
fstring_expr [23550,23562]
===
match
---
exprlist [9530,9538]
exprlist [9503,9511]
===
match
---
subscriptlist [4687,4695]
subscriptlist [4660,4668]
===
match
---
name: warn [4285,4289]
name: warn [4258,4262]
===
match
---
simple_stmt [17318,17375]
simple_stmt [17222,17279]
===
match
---
sync_comp_for [22027,22048]
sync_comp_for [21931,21952]
===
match
---
name: str [4863,4866]
name: str [4836,4839]
===
match
---
string: "Please take a look at these docs to improve your DAG import time:\n" [13032,13101]
string: "Please take a look at these docs to improve your DAG import time:\n" [12936,13005]
===
match
---
name: Session [10278,10285]
name: Session [10251,10258]
===
match
---
operator: = [3504,3505]
operator: = [3477,3478]
===
match
---
name: dag [10748,10751]
name: dag [10652,10655]
===
match
---
argument [21930,21980]
argument [21834,21884]
===
match
---
name: mods [16417,16421]
name: mods [16321,16325]
===
match
---
name: self [15795,15799]
name: self [15699,15703]
===
match
---
import_name [820,846]
import_name [820,846]
===
match
---
name: spec_from_loader [13484,13500]
name: spec_from_loader [13388,13404]
===
match
---
name: Union [3704,3709]
name: Union [3677,3682]
===
match
---
name: resource_name_for_dag [26995,27016]
name: resource_name_for_dag [26899,26920]
===
match
---
atom_expr [11491,11517]
atom_expr [11395,11421]
===
match
---
operator: , [4861,4862]
operator: , [4834,4835]
===
match
---
name: dag [17362,17365]
name: dag [17266,17269]
===
match
---
param [3678,3683]
param [3651,3656]
===
match
---
trailer [21471,21473]
trailer [21375,21377]
===
match
---
import_from [10336,10396]
import_from [10309,10369]
===
match
---
subscriptlist [5039,5052]
subscriptlist [5012,5025]
===
match
---
suite [27463,27496]
suite [27367,27400]
===
match
---
atom_expr [18428,18437]
atom_expr [18332,18341]
===
match
---
string: "Running dagbag.sync_to_db with retries. Try %d of %d" [25724,25778]
string: "Running dagbag.sync_to_db with retries. Try %d of %d" [25628,25682]
===
match
---
trailer [12735,12742]
trailer [12639,12646]
===
match
---
name: full_filepath [25235,25248]
name: full_filepath [25139,25152]
===
match
---
if_stmt [11531,11746]
if_stmt [11435,11650]
===
match
---
name: Session [23972,23979]
name: Session [23876,23883]
===
match
---
name: exception [17023,17032]
name: exception [16927,16936]
===
match
---
atom_expr [6791,6813]
atom_expr [6764,6786]
===
match
---
argument [5479,5512]
argument [5452,5485]
===
match
---
comparison [8766,8785]
comparison [8739,8758]
===
match
---
atom [14498,14513]
atom [14402,14417]
===
match
---
name: SerializedDagModel [24746,24764]
name: SerializedDagModel [24650,24668]
===
match
---
arglist [16465,16471]
arglist [16369,16375]
===
match
---
comparison [19011,19042]
comparison [18915,18946]
===
match
---
import_from [1149,1178]
import_from [1149,1178]
===
match
---
name: dag [16554,16557]
name: dag [16458,16461]
===
match
---
trailer [8400,8408]
trailer [8373,8381]
===
match
---
trailer [17077,17085]
trailer [16981,16989]
===
match
---
name: dag_id [8257,8263]
name: dag_id [8230,8236]
===
match
---
name: dag [19342,19345]
name: dag [19246,19249]
===
match
---
name: Dict [4853,4857]
name: Dict [4826,4830]
===
match
---
name: ZipFile [14245,14252]
name: ZipFile [14149,14156]
===
match
---
atom_expr [23280,23290]
atom_expr [23184,23194]
===
match
---
suite [8852,8921]
suite [8825,8894]
===
match
---
string: """:return: the amount of dags contained in this dagbag""" [5848,5906]
string: """:return: the amount of dags contained in this dagbag""" [5821,5879]
===
match
---
name: dags [9278,9282]
name: dags [9251,9255]
===
match
---
name: log [1717,1720]
name: log [1690,1693]
===
match
---
atom_expr [4913,4935]
atom_expr [4886,4908]
===
match
---
simple_stmt [6438,6468]
simple_stmt [6411,6441]
===
match
---
name: sqla_models [26814,26825]
name: sqla_models [26718,26729]
===
match
---
atom_expr [26549,26598]
atom_expr [26453,26502]
===
match
---
name: airflow [1568,1575]
name: airflow [1541,1548]
===
match
---
annassign [5168,5189]
annassign [5141,5162]
===
match
---
name: dag_id [10256,10262]
name: dag_id [10229,10235]
===
match
---
name: include_smart_sensor [5526,5546]
name: include_smart_sensor [5499,5519]
===
match
---
name: dag_ids [6301,6308]
name: dag_ids [6274,6281]
===
match
---
operator: = [21622,21623]
operator: = [21526,21527]
===
match
---
simple_stmt [8869,8921]
simple_stmt [8842,8894]
===
match
---
name: self [22665,22669]
name: self [22569,22573]
===
match
---
atom_expr [5303,5343]
atom_expr [5276,5316]
===
match
---
operator: -> [6315,6317]
operator: -> [6288,6290]
===
match
---
name: insert [15450,15456]
name: insert [15354,15360]
===
match
---
funcdef [23933,26599]
funcdef [23837,26503]
===
match
---
name: sqla_models [27286,27297]
name: sqla_models [27190,27201]
===
match
---
if_stmt [6788,8636]
if_stmt [6761,8609]
===
match
---
name: conf [20151,20155]
name: conf [20055,20059]
===
match
---
trailer [8206,8210]
trailer [8179,8183]
===
match
---
name: safe_mode [21275,21284]
name: safe_mode [21179,21188]
===
match
---
trailer [23971,23980]
trailer [23875,23884]
===
match
---
name: org_mod_name [12630,12642]
name: org_mod_name [12534,12546]
===
match
---
atom_expr [27555,27583]
atom_expr [27459,27487]
===
match
---
atom_expr [19870,19883]
atom_expr [19774,19787]
===
match
---
name: DagModel [6770,6778]
name: DagModel [6743,6751]
===
match
---
name: self [12438,12442]
name: self [12342,12346]
===
match
---
comparison [14618,14640]
comparison [14522,14544]
===
match
---
name: importlib [13389,13398]
name: importlib [13293,13302]
===
match
---
operator: { [23836,23837]
operator: { [23740,23741]
===
match
---
name: self [8289,8293]
name: self [8262,8266]
===
match
---
simple_stmt [24997,25043]
simple_stmt [24901,24947]
===
match
---
name: exception [22152,22161]
name: exception [22056,22065]
===
match
---
name: www [27690,27693]
name: www [27594,27597]
===
match
---
argument [22006,22050]
argument [21910,21954]
===
match
---
name: importlib [13548,13557]
name: importlib [13452,13461]
===
match
---
suite [10287,10865]
suite [10260,10769]
===
match
---
comparison [14487,14513]
comparison [14391,14417]
===
match
---
name: dag [22031,22034]
name: dag [21935,21938]
===
match
---
atom_expr [27572,27582]
atom_expr [27476,27486]
===
match
---
name: self [10202,10206]
name: self [10175,10179]
===
match
---
fstring_string:          DagBag parsing time:  [23806,23836]
fstring_string:          DagBag parsing time:  [23710,23740]
===
match
---
name: self [17051,17055]
name: self [16955,16959]
===
match
---
simple_stmt [21602,21642]
simple_stmt [21506,21546]
===
match
---
expr_stmt [14214,14223]
expr_stmt [14118,14127]
===
match
---
name: dag [17887,17890]
name: dag [17791,17794]
===
match
---
name: safe_mode [3918,3927]
name: safe_mode [3891,3900]
===
match
---
import_from [1755,1824]
import_from [1728,1797]
===
match
---
string: """Sync DAG specific permissions, if necessary""" [26703,26752]
string: """Sync DAG specific permissions, if necessary""" [26607,26656]
===
match
---
operator: , [6202,6203]
operator: , [6175,6176]
===
match
---
name: str [22011,22014]
name: str [21915,21918]
===
match
---
name: airflow [1478,1485]
name: airflow [1451,1458]
===
match
---
operator: = [4075,4076]
operator: = [4048,4049]
===
match
---
name: property [6284,6292]
name: property [6257,6265]
===
match
---
trailer [16557,16565]
trailer [16461,16469]
===
match
---
operator: -> [26954,26956]
operator: -> [26858,26860]
===
match
---
name: dag_id [10103,10109]
name: dag_id [10076,10082]
===
match
---
name: dag_id [8070,8076]
name: dag_id [8043,8049]
===
match
---
atom_expr [19280,19290]
atom_expr [19184,19194]
===
match
---
name: self [8386,8390]
name: self [8359,8363]
===
match
---
simple_stmt [25266,25360]
simple_stmt [25170,25264]
===
match
---
trailer [26354,26356]
trailer [26258,26260]
===
match
---
with_stmt [25620,26599]
with_stmt [25524,26503]
===
match
---
comparison [7803,7835]
comparison [7776,7808]
===
match
---
name: exception [25183,25192]
name: exception [25087,25096]
===
match
---
name: timeout [1909,1916]
name: timeout [1882,1889]
===
match
---
arglist [10435,10450]
arglist [10408,10423]
===
match
---
arglist [11927,11946]
arglist [11831,11850]
===
match
---
name: _load_modules_from_zip [14155,14177]
name: _load_modules_from_zip [14059,14081]
===
match
---
name: sys [16145,16148]
name: sys [16049,16052]
===
match
---
atom_expr [10627,10634]
atom_expr [10531,10538]
===
match
---
operator: , [5465,5466]
operator: , [5438,5439]
===
match
---
name: airflow [1703,1710]
name: airflow [1676,1683]
===
match
---
name: name [13619,13623]
name: name [13523,13527]
===
match
---
operator: , [20914,20915]
operator: , [20818,20819]
===
match
---
name: DAG [16468,16471]
name: DAG [16372,16375]
===
match
---
atom_expr [13932,14047]
atom_expr [13836,13951]
===
match
---
atom_expr [15886,16009]
atom_expr [15790,15913]
===
match
---
name: file_last_changed [17461,17478]
name: file_last_changed [17365,17382]
===
match
---
atom_expr [11600,11622]
atom_expr [11504,11526]
===
match
---
atom_expr [26240,26258]
atom_expr [26144,26162]
===
match
---
trailer [7117,7149]
trailer [7090,7122]
===
match
---
name: filepath [11927,11935]
name: filepath [11831,11839]
===
match
---
trailer [21751,21777]
trailer [21655,21681]
===
match
---
fstring_string: \n [13177,13179]
fstring_string: \n [13081,13083]
===
match
---
arglist [3873,3907]
arglist [3846,3880]
===
match
---
trailer [10430,10434]
trailer [10403,10407]
===
match
---
atom_expr [23963,23980]
atom_expr [23867,23884]
===
match
---
del_stmt [8285,8306]
del_stmt [8258,8279]
===
match
---
name: modules [13606,13613]
name: modules [13510,13517]
===
match
---
argument [27802,27817]
argument [27706,27721]
===
match
---
name: session [10269,10276]
name: session [10242,10249]
===
match
---
name: self [15083,15087]
name: self [14987,14991]
===
match
---
factor [13984,14025]
factor [13888,13929]
===
match
---
if_stmt [19801,19885]
if_stmt [19705,19789]
===
match
---
name: dag_id [8063,8069]
name: dag_id [8036,8042]
===
match
---
operator: = [23449,23450]
operator: = [23353,23354]
===
match
---
trailer [27801,27818]
trailer [27705,27722]
===
match
---
name: _load_modules_from_file [11903,11926]
name: _load_modules_from_file [11807,11830]
===
match
---
name: dag_folder [20936,20946]
name: dag_folder [20840,20850]
===
match
---
name: new_module [13673,13683]
name: new_module [13577,13587]
===
match
---
atom_expr [22944,22962]
atom_expr [22848,22866]
===
match
---
name: append [15566,15572]
name: append [15470,15476]
===
match
---
name: dag_id [7899,7905]
name: dag_id [7872,7878]
===
match
---
name: AirflowDagCycleException [19363,19387]
name: AirflowDagCycleException [19267,19291]
===
match
---
trailer [9065,9095]
trailer [9038,9068]
===
match
---
arglist [20088,20111]
arglist [19992,20015]
===
match
---
name: file_last_changed [4781,4798]
name: file_last_changed [4754,4771]
===
match
---
param [16278,16303]
param [16182,16207]
===
match
---
expr_stmt [21490,21584]
expr_stmt [21394,21488]
===
match
---
name: values [26093,26099]
name: values [25997,26003]
===
match
---
expr_stmt [3482,3552]
expr_stmt [3455,3525]
===
match
---
simple_stmt [6554,6699]
simple_stmt [6527,6672]
===
match
---
expr_stmt [21602,21641]
expr_stmt [21506,21545]
===
match
---
dotted_name [1214,1235]
dotted_name [1214,1235]
===
match
---
parameters [19924,20287]
parameters [19828,20191]
===
match
---
atom_expr [6055,6239]
atom_expr [6028,6212]
===
match
---
operator: @ [6473,6474]
operator: @ [6446,6447]
===
match
---
simple_stmt [12878,12904]
simple_stmt [12782,12808]
===
match
---
name: self [9273,9277]
name: self [9246,9250]
===
match
---
fstring_start: f" [16990,16992]
fstring_start: f" [16894,16896]
===
match
---
name: dag_id [10842,10848]
name: dag_id [10746,10752]
===
match
---
name: self [25688,25692]
name: self [25592,25596]
===
match
---
name: importlib [854,863]
name: importlib [854,863]
===
match
---
name: include_examples [21315,21331]
name: include_examples [21219,21235]
===
match
---
name: dag [27572,27575]
name: dag [27476,27479]
===
match
---
string: "pathlib.Path" [19971,19985]
string: "pathlib.Path" [19875,19889]
===
match
---
name: store_serialized_dags [4241,4262]
name: store_serialized_dags [4214,4235]
===
match
---
atom [19362,19421]
atom [19266,19325]
===
match
---
name: join [27231,27235]
name: join [27135,27139]
===
match
---
name: DAGBAG_IMPORT_TIMEOUT [12992,13013]
name: DAGBAG_IMPORT_TIMEOUT [12896,12917]
===
match
---
name: self [13985,13989]
name: self [13889,13893]
===
match
---
operator: = [21734,21735]
operator: = [21638,21639]
===
match
---
operator: , [27876,27877]
operator: , [27780,27781]
===
match
---
name: fileloc [16979,16986]
name: fileloc [16883,16890]
===
match
---
atom [14221,14223]
atom [14125,14127]
===
match
---
trailer [12752,12762]
trailer [12656,12666]
===
match
---
not_test [9602,9662]
not_test [9575,9635]
===
match
---
suite [27584,27898]
suite [27488,27802]
===
match
---
argument [13978,14025]
argument [13882,13929]
===
match
---
atom_expr [24746,24940]
atom_expr [24650,24844]
===
match
---
operator: , [13509,13510]
operator: , [13413,13414]
===
match
---
simple_stmt [8429,8441]
simple_stmt [8402,8414]
===
match
---
expr_stmt [18312,18347]
expr_stmt [18216,18251]
===
match
---
string: """         Adds the DAG into the bag, recurses into sub dags.          :raises: AirflowDagCycleException if a cycle is detected in this dag or its subdags.         :raises: AirflowDagDuplicatedIdException if this dag or its subdags already exists in the bag.         """ [17593,17864]
string: """         Adds the DAG into the bag, recurses into sub dags.          :raises: AirflowDagCycleException if a cycle is detected in this dag or its subdags.         :raises: AirflowDagDuplicatedIdException if this dag or its subdags already exists in the bag.         """ [17497,17768]
===
match
---
trailer [7898,7906]
trailer [7871,7879]
===
match
---
name: dag [4186,4189]
name: dag [4159,4162]
===
match
---
except_clause [11754,11775]
except_clause [11658,11679]
===
match
---
name: dag_id [23042,23048]
name: dag_id [22946,22952]
===
match
---
name: models [22349,22355]
name: models [22253,22259]
===
match
---
operator: { [13197,13198]
operator: { [13101,13102]
===
match
---
expr_stmt [23393,23434]
expr_stmt [23297,23338]
===
match
---
operator: = [8803,8804]
operator: = [8776,8777]
===
match
---
name: traceback [15886,15895]
name: traceback [15790,15799]
===
match
---
operator: , [20112,20113]
operator: , [20016,20017]
===
match
---
trailer [15380,15388]
trailer [15284,15292]
===
match
---
atom_expr [14121,14127]
atom_expr [14025,14031]
===
match
---
simple_stmt [1825,1875]
simple_stmt [1798,1848]
===
match
---
expr_stmt [4634,4662]
expr_stmt [4607,4635]
===
match
---
string: 'Loaded DAG %s' [19325,19340]
string: 'Loaded DAG %s' [19229,19244]
===
match
---
return_stmt [12195,12212]
return_stmt [12099,12116]
===
match
---
name: sum [23404,23407]
name: sum [23308,23311]
===
match
---
trailer [23244,23255]
trailer [23148,23159]
===
match
---
name: dag [24560,24563]
name: dag [24464,24467]
===
match
---
argument [8098,8113]
argument [8071,8086]
===
match
---
name: load_op_links [10599,10612]
name: load_op_links [10503,10516]
===
match
---
simple_stmt [12913,13270]
simple_stmt [12817,13174]
===
match
---
string: """Add DAG to DagBag from DB""" [10296,10327]
string: """Add DAG to DagBag from DB""" [10269,10300]
===
match
---
argument [24906,24921]
argument [24810,24825]
===
match
---
name: read_all_dags [22696,22709]
name: read_all_dags [22600,22613]
===
match
---
simple_stmt [1563,1607]
simple_stmt [1536,1580]
===
match
---
name: datetime [959,967]
name: datetime [959,967]
===
match
---
atom_expr [4682,4696]
atom_expr [4655,4669]
===
match
---
name: get [10431,10434]
name: get [10404,10407]
===
match
---
name: _load_modules_from_file [12222,12245]
name: _load_modules_from_file [12126,12149]
===
match
---
string: 'USE_SMART_SENSOR' [3889,3907]
string: 'USE_SMART_SENSOR' [3862,3880]
===
match
---
trailer [19129,19136]
trailer [19033,19040]
===
match
---
string: 'best-practices.html#top-level-python-code' [13132,13175]
string: 'best-practices.html#top-level-python-code' [13036,13079]
===
match
---
operator: , [17225,17226]
operator: , [17129,17130]
===
match
---
simple_stmt [6005,6047]
simple_stmt [5978,6020]
===
match
---
expr_stmt [10724,10751]
expr_stmt [10628,10655]
===
match
---
name: self [4833,4837]
name: self [4806,4810]
===
match
---
name: exception [13781,13790]
name: exception [13685,13694]
===
match
---
name: utils [1711,1716]
name: utils [1684,1689]
===
match
---
name: store_serialized_dags [4037,4058]
name: store_serialized_dags [4010,4031]
===
match
---
name: self [7876,7880]
name: self [7849,7853]
===
match
---
name: include_smart_sensor [3828,3848]
name: include_smart_sensor [3801,3821]
===
match
---
simple_stmt [1149,1179]
simple_stmt [1149,1179]
===
match
---
operator: , [24315,24316]
operator: , [24219,24220]
===
match
---
atom_expr [25174,25249]
atom_expr [25078,25153]
===
match
---
name: stats [21658,21663]
name: stats [21562,21567]
===
match
---
suite [15420,15589]
suite [15324,15493]
===
match
---
name: log [19315,19318]
name: log [19219,19222]
===
match
---
atom_expr [10852,10864]
atom_expr [10756,10768]
===
match
---
trailer [11797,11807]
trailer [11701,11711]
===
match
---
operator: , [16466,16467]
operator: , [16370,16371]
===
match
---
name: self [22455,22459]
name: self [22359,22363]
===
match
---
name: filepath [14253,14261]
name: filepath [14157,14165]
===
match
---
comp_op [9266,9272]
comp_op [9239,9245]
===
match
---
operator: , [17176,17177]
operator: , [17080,17081]
===
match
---
if_stmt [7782,8594]
if_stmt [7755,8567]
===
match
---
name: int [5835,5838]
name: int [5808,5811]
===
match
---
name: timedelta [23308,23317]
name: timedelta [23212,23221]
===
match
---
atom_expr [22016,22026]
atom_expr [21920,21930]
===
match
---
name: root_dag [16715,16723]
name: root_dag [16619,16627]
===
match
---
name: one_or_none [27431,27442]
name: one_or_none [27335,27346]
===
match
---
atom_expr [25288,25357]
atom_expr [25192,25261]
===
match
---
name: os [876,878]
name: os [876,878]
===
match
---
arith_expr [21812,21855]
arith_expr [21716,21759]
===
match
---
name: stacklevel [4487,4497]
name: stacklevel [4460,4470]
===
match
---
name: session [24317,24324]
name: session [24221,24228]
===
match
---
subscriptlist [3710,3735]
subscriptlist [3683,3708]
===
match
---
atom_expr [10138,10147]
atom_expr [10111,10120]
===
match
---
trailer [7100,7117]
trailer [7073,7090]
===
match
---
name: dag_folder [4652,4662]
name: dag_folder [4625,4635]
===
match
---
operator: = [21365,21366]
operator: = [21269,21270]
===
match
---
operator: = [20947,20948]
operator: = [20851,20852]
===
match
---
trailer [6322,6327]
trailer [6295,6300]
===
match
---
trailer [18471,18477]
trailer [18375,18381]
===
match
---
operator: , [6228,6229]
operator: , [6201,6202]
===
match
---
simple_stmt [18214,18266]
simple_stmt [18118,18170]
===
match
---
atom_expr [16568,16580]
atom_expr [16472,16484]
===
match
---
trailer [27611,27664]
trailer [27515,27568]
===
match
---
operator: = [16088,16089]
operator: = [15992,15993]
===
match
---
name: file [2034,2038]
name: file [2007,2011]
===
match
---
name: self [10823,10827]
name: self [10727,10731]
===
match
---
trailer [18740,18748]
trailer [18644,18652]
===
match
---
simple_stmt [906,923]
simple_stmt [906,923]
===
match
---
operator: = [18955,18956]
operator: = [18859,18860]
===
match
---
simple_stmt [12438,12461]
simple_stmt [12342,12365]
===
match
---
trailer [15087,15098]
trailer [14991,15002]
===
match
---
name: models [26804,26810]
name: models [26708,26714]
===
match
---
suite [18438,18478]
suite [18342,18382]
===
match
---
name: self [8776,8780]
name: self [8749,8753]
===
match
---
not_test [11845,11877]
not_test [11749,11781]
===
match
---
trailer [15724,15728]
trailer [15628,15632]
===
match
---
trailer [23278,23320]
trailer [23182,23224]
===
match
---
operator: = [5454,5455]
operator: = [5427,5428]
===
match
---
name: path [11274,11278]
name: path [11178,11182]
===
match
---
name: textwrap [23501,23509]
name: textwrap [23405,23413]
===
match
---
decorated [5942,6278]
decorated [5915,6251]
===
match
---
atom_expr [12714,12764]
atom_expr [12618,12668]
===
match
---
name: self [22143,22147]
name: self [22047,22051]
===
match
---
argument [21564,21583]
argument [21468,21487]
===
match
---
operator: = [18495,18496]
operator: = [18399,18400]
===
match
---
expr_stmt [23227,23255]
expr_stmt [23131,23159]
===
match
---
trailer [8814,8822]
trailer [8787,8795]
===
match
---
operator: = [21048,21049]
operator: = [20952,20953]
===
match
---
name: collect_dags [5418,5430]
name: collect_dags [5391,5403]
===
match
---
param [10250,10255]
param [10223,10228]
===
match
---
name: org_mod_name [12814,12826]
name: org_mod_name [12718,12730]
===
match
---
trailer [16078,16087]
trailer [15982,15991]
===
match
---
atom_expr [11898,11947]
atom_expr [11802,11851]
===
match
---
expr_stmt [14090,14127]
expr_stmt [13994,14031]
===
match
---
name: dag_hash [10856,10864]
name: dag_hash [10760,10768]
===
match
---
operator: = [9774,9775]
operator: = [9747,9748]
===
match
---
trailer [27297,27308]
trailer [27201,27212]
===
match
---
dotted_name [1446,1459]
dotted_name [1419,1432]
===
match
---
name: str [5180,5183]
name: str [5153,5156]
===
match
---
atom_expr [12477,12549]
atom_expr [12381,12453]
===
match
---
name: dags [19275,19279]
name: dags [19179,19183]
===
match
---
operator: , [19238,19239]
operator: , [19142,19143]
===
match
---
param [10887,10892]
param [10791,10796]
===
match
---
param [3828,3909]
param [3801,3882]
===
match
---
simple_stmt [2034,2044]
simple_stmt [2007,2017]
===
match
---
trailer [13210,13257]
trailer [13114,13161]
===
match
---
name: new_module [13535,13545]
name: new_module [13439,13449]
===
match
---
suite [8786,8921]
suite [8759,8894]
===
match
---
name: bool [20065,20069]
name: bool [19969,19973]
===
match
---
name: dag [10657,10660]
name: dag [10561,10564]
===
match
---
operator: { [9483,9484]
operator: { [9456,9457]
===
match
---
name: dag [18497,18500]
name: dag [18401,18404]
===
match
---
name: session [26268,26275]
name: session [26172,26179]
===
match
---
atom_expr [18330,18347]
atom_expr [18234,18251]
===
match
---
name: self [5982,5986]
name: self [5955,5959]
===
match
---
fstring_string: *  [13116,13118]
fstring_string: *  [13020,13022]
===
match
---
name: exception [15729,15738]
name: exception [15633,15642]
===
match
---
trailer [23358,23384]
trailer [23262,23288]
===
match
---
string: 'DAGBAG_IMPORT_TIMEOUT' [3528,3551]
string: 'DAGBAG_IMPORT_TIMEOUT' [3501,3524]
===
match
---
parameters [22277,22283]
parameters [22181,22187]
===
match
---
param [19948,20000]
param [19852,19904]
===
match
---
name: FileLoadStat [1963,1975]
name: FileLoadStat [1936,1948]
===
match
---
name: tabulate [1170,1178]
name: tabulate [1170,1178]
===
match
---
except_clause [22104,22125]
except_clause [22008,22029]
===
match
---
atom_expr [14854,14871]
atom_expr [14758,14775]
===
match
---
operator: , [1658,1659]
operator: , [1631,1632]
===
match
---
arglist [16706,16727]
arglist [16610,16631]
===
match
---
except_clause [17127,17300]
except_clause [17031,17204]
===
match
---
fstring_string:          Total task number:  [23768,23796]
fstring_string:          Total task number:  [23672,23700]
===
match
---
operator: , [26657,26658]
operator: , [26561,26562]
===
match
---
simple_stmt [10574,10613]
simple_stmt [10478,10517]
===
match
---
operator: { [4822,4823]
operator: { [4795,4796]
===
match
---
name: SourceFileLoader [13409,13425]
name: SourceFileLoader [13313,13329]
===
match
---
param [22278,22282]
param [22182,22186]
===
match
---
name: str [6323,6326]
name: str [6296,6299]
===
match
---
trailer [8544,8561]
trailer [8517,8534]
===
match
---
operator: = [10850,10851]
operator: = [10754,10755]
===
match
---
operator: @ [26604,26605]
operator: @ [26508,26509]
===
match
---
comparison [8461,8518]
comparison [8434,8491]
===
match
---
atom_expr [11981,12029]
atom_expr [11885,11933]
===
match
---
operator: , [25778,25779]
operator: , [25682,25683]
===
match
---
del_stmt [15373,15398]
del_stmt [15277,15302]
===
match
---
del_stmt [16194,16209]
del_stmt [16098,16113]
===
match
---
atom_expr [15856,15883]
atom_expr [15760,15787]
===
match
---
simple_stmt [4166,4201]
simple_stmt [4139,4174]
===
match
---
name: ViewMenu [27374,27382]
name: ViewMenu [27278,27286]
===
match
---
name: mod_name [15389,15397]
name: mod_name [15293,15301]
===
match
---
name: error_message [13319,13332]
name: error_message [13223,13236]
===
match
---
fstring_expr [23855,23862]
fstring_expr [23759,23766]
===
match
---
atom_expr [19860,19884]
atom_expr [19764,19788]
===
match
---
simple_stmt [1698,1755]
simple_stmt [1671,1728]
===
match
---
name: self [10250,10254]
name: self [10223,10227]
===
match
---
arglist [15671,15698]
arglist [15575,15602]
===
match
---
name: row [10852,10855]
name: row [10756,10759]
===
match
---
name: _bag_dag [17940,17948]
name: _bag_dag [17844,17852]
===
match
---
suite [22963,23059]
suite [22867,22963]
===
match
---
operator: , [16260,16261]
operator: , [16164,16165]
===
match
---
dotted_name [16319,16337]
dotted_name [16223,16241]
===
match
---
name: models [24219,24225]
name: models [24123,24129]
===
match
---
name: dag_id [10216,10222]
name: dag_id [10189,10195]
===
match
---
name: import_errors [26554,26567]
name: import_errors [26458,26471]
===
match
---
simple_stmt [23893,23907]
simple_stmt [23797,23811]
===
match
---
trailer [16464,16472]
trailer [16368,16376]
===
match
---
name: subdag [18783,18789]
name: subdag [18687,18693]
===
match
---
atom_expr [16431,16450]
atom_expr [16335,16354]
===
match
---
simple_stmt [26549,26599]
simple_stmt [26453,26503]
===
match
---
name: orm_dag [9841,9848]
name: orm_dag [9814,9821]
===
match
---
testlist_comp [22016,22048]
testlist_comp [21920,21952]
===
match
---
expr_stmt [8715,8725]
expr_stmt [8688,8698]
===
match
---
simple_stmt [5199,5295]
simple_stmt [5172,5268]
===
match
---
name: filepath [13920,13928]
name: filepath [13824,13832]
===
match
---
fstring_end: ' [12827,12828]
fstring_end: ' [12731,12732]
===
match
---
operator: , [12082,12083]
operator: , [11986,11987]
===
match
---
name: orm [1130,1133]
name: orm [1130,1133]
===
match
---
name: str [4805,4808]
name: str [4778,4781]
===
match
---
name: new_module [13627,13637]
name: new_module [13531,13541]
===
match
---
trailer [16571,16580]
trailer [16475,16484]
===
match
---
name: NamedTuple [1976,1986]
name: NamedTuple [1949,1959]
===
match
---
for_stmt [14296,16210]
for_stmt [14200,16114]
===
match
---
name: dag [24796,24799]
name: dag [24700,24703]
===
match
---
atom_expr [7726,7768]
atom_expr [7699,7741]
===
match
---
parameters [5981,5987]
parameters [5954,5960]
===
match
---
import_name [1940,1954]
import_name [1913,1927]
===
match
---
simple_stmt [4276,4515]
simple_stmt [4249,4488]
===
match
---
name: dag_id [7187,7193]
name: dag_id [7160,7166]
===
match
---
name: datetime [4810,4818]
name: datetime [4783,4791]
===
match
---
name: limit [13978,13983]
name: limit [13882,13887]
===
match
---
factor [25315,25356]
factor [25219,25260]
===
match
---
name: self [11672,11676]
name: self [11576,11580]
===
match
---
name: e [13753,13754]
name: e [13657,13658]
===
match
---
operator: , [20037,20038]
operator: , [19941,19942]
===
match
---
comparison [7856,7938]
comparison [7829,7911]
===
match
---
argument [18885,18895]
argument [18789,18799]
===
match
---
import_from [6739,6778]
import_from [6712,6751]
===
match
---
name: row [10574,10577]
name: row [10478,10481]
===
match
---
name: filepath [12970,12978]
name: filepath [12874,12882]
===
match
---
name: attempt [25559,25566]
name: attempt [25463,25470]
===
match
---
name: Permission [27298,27308]
name: Permission [27202,27212]
===
match
---
trailer [4068,4074]
trailer [4041,4047]
===
match
---
trailer [12726,12752]
trailer [12630,12656]
===
match
---
name: DAGBAG_IMPORT_TIMEOUT [3482,3503]
name: DAGBAG_IMPORT_TIMEOUT [3455,3476]
===
match
---
atom_expr [5237,5294]
atom_expr [5210,5267]
===
match
---
operator: , [17913,17914]
operator: , [17817,17818]
===
match
---
operator: = [5235,5236]
operator: = [5208,5209]
===
match
---
tfpdef [3753,3775]
tfpdef [3726,3748]
===
match
---
operator: @ [6283,6284]
operator: @ [6256,6257]
===
match
---
tfpdef [20047,20069]
tfpdef [19951,19973]
===
match
---
annassign [4798,4824]
annassign [4771,4797]
===
match
---
name: dag [16763,16766]
name: dag [16667,16670]
===
match
---
operator: = [10410,10411]
operator: = [10383,10384]
===
match
---
annassign [2111,2116]
annassign [2084,2089]
===
match
---
operator: , [12315,12316]
operator: , [12219,12220]
===
match
---
import_from [26761,26825]
import_from [26665,26729]
===
match
---
trailer [17409,17422]
trailer [17313,17326]
===
match
---
simple_stmt [10296,10328]
simple_stmt [10269,10301]
===
match
---
expr_stmt [9763,9894]
expr_stmt [9736,9867]
===
match
---
atom_expr [10169,10186]
atom_expr [10142,10159]
===
match
---
dotted_name [1568,1586]
dotted_name [1541,1559]
===
match
---
expr_stmt [2089,2102]
expr_stmt [2062,2075]
===
match
---
name: datetime [975,983]
name: datetime [975,983]
===
match
---
string: 'collect_db_dags' [22423,22440]
string: 'collect_db_dags' [22327,22344]
===
match
---
atom_expr [15561,15588]
atom_expr [15465,15492]
===
match
---
trailer [20873,20877]
trailer [20777,20781]
===
match
---
trailer [19097,19257]
trailer [19001,19161]
===
match
---
suite [1988,2117]
suite [1961,2090]
===
match
---
name: e [16094,16095]
name: e [15998,15999]
===
match
---
trailer [19825,19830]
trailer [19729,19734]
===
match
---
name: dag_folder [23245,23255]
name: dag_folder [23149,23159]
===
match
---
name: dag [27878,27881]
name: dag [27782,27785]
===
match
---
name: safe_mode [20212,20221]
name: safe_mode [20116,20125]
===
match
---
name: list_py_file_paths [1660,1678]
name: list_py_file_paths [1633,1651]
===
match
---
param [23948,23953]
param [23852,23857]
===
match
---
trailer [23317,23319]
trailer [23221,23223]
===
match
---
with_stmt [22406,23097]
with_stmt [22310,23001]
===
match
---
name: self [25597,25601]
name: self [25501,25505]
===
match
---
name: get [18967,18970]
name: get [18871,18874]
===
match
---
arglist [19539,19578]
arglist [19443,19482]
===
match
---
operator: , [17894,17895]
operator: , [17798,17799]
===
match
---
name: filter [27355,27361]
name: filter [27259,27265]
===
match
---
atom_expr [21209,21397]
atom_expr [21113,21301]
===
match
---
suite [16597,16810]
suite [16501,16714]
===
match
---
name: parent_dag [9644,9654]
name: parent_dag [9617,9627]
===
match
---
name: process_file [9781,9793]
name: process_file [9754,9766]
===
match
---
atom_expr [21147,21184]
atom_expr [21051,21088]
===
match
---
dotted_name [6744,6762]
dotted_name [6717,6735]
===
match
---
name: m [16431,16432]
name: m [16335,16336]
===
match
---
name: MIN_SERIALIZED_DAG_FETCH_INTERVAL [7735,7768]
name: MIN_SERIALIZED_DAG_FETCH_INTERVAL [7708,7741]
===
match
---
simple_stmt [27484,27496]
simple_stmt [27388,27400]
===
match
---
simple_stmt [16483,16499]
simple_stmt [16387,16403]
===
match
---
operator: = [3934,3935]
operator: = [3907,3908]
===
match
---
operator: = [20149,20150]
operator: = [20053,20054]
===
match
---
trailer [19274,19279]
trailer [19178,19183]
===
match
---
operator: , [25286,25287]
operator: , [25190,25191]
===
match
---
name: dags [6455,6459]
name: dags [6428,6432]
===
match
---
name: debug [25697,25702]
name: debug [25601,25606]
===
match
---
name: tasks [21951,21956]
name: tasks [21855,21860]
===
match
---
operator: , [14361,14362]
operator: , [14265,14266]
===
match
---
name: subdag [18889,18895]
name: subdag [18793,18799]
===
match
---
name: subdag [19804,19810]
name: subdag [19708,19714]
===
match
---
operator: = [11979,11980]
operator: = [11883,11884]
===
match
---
operator: , [3526,3527]
operator: , [3499,3500]
===
match
---
operator: , [9077,9078]
operator: , [9050,9051]
===
match
---
name: dags_hash [10828,10837]
name: dags_hash [10732,10741]
===
match
---
suite [7024,7195]
suite [6997,7168]
===
match
---
trailer [26574,26598]
trailer [26478,26502]
===
match
---
arith_expr [7876,7938]
arith_expr [7849,7911]
===
match
---
operator: = [5495,5496]
operator: = [5468,5469]
===
match
---
name: prev_dag [18946,18954]
name: prev_dag [18850,18858]
===
match
---
name: conf [5346,5350]
name: conf [5319,5323]
===
match
---
trailer [18966,18970]
trailer [18870,18874]
===
match
---
name: serialize_errors [25650,25666]
name: serialize_errors [25554,25570]
===
match
---
atom_expr [26338,26356]
atom_expr [26242,26260]
===
match
---
operator: = [27809,27810]
operator: = [27713,27714]
===
match
---
operator: = [4545,4546]
operator: = [4518,4519]
===
match
---
name: report [23492,23498]
name: report [23396,23402]
===
match
---
atom_expr [14381,14398]
atom_expr [14285,14302]
===
match
---
param [5826,5830]
param [5799,5803]
===
match
---
comparison [15328,15351]
comparison [15232,15255]
===
match
---
operator: = [17492,17493]
operator: = [17396,17397]
===
match
---
arglist [14679,14727]
arglist [14583,14631]
===
match
---
expr_stmt [16060,16096]
expr_stmt [15964,16000]
===
match
---
name: root_dag_id [8734,8745]
name: root_dag_id [8707,8718]
===
match
---
atom_expr [25688,25889]
atom_expr [25592,25793]
===
match
---
trailer [21520,21584]
trailer [21424,21488]
===
match
---
operator: = [12454,12455]
operator: = [12358,12359]
===
match
---
trailer [9643,9654]
trailer [9616,9627]
===
match
---
param [6506,6511]
param [6479,6484]
===
match
---
trailer [15243,15252]
trailer [15147,15156]
===
match
---
name: os [14432,14434]
name: os [14336,14338]
===
match
---
name: ApplessAirflowSecurityManager [27710,27739]
name: ApplessAirflowSecurityManager [27614,27643]
===
match
---
operator: , [16276,16277]
operator: , [16180,16181]
===
match
---
comparison [9625,9661]
comparison [9598,9634]
===
match
---
parameters [23947,23988]
parameters [23851,23892]
===
match
---
parameters [5825,5831]
parameters [5798,5804]
===
match
---
name: dag_id [7125,7131]
name: dag_id [7098,7104]
===
match
---
name: dag [9640,9643]
name: dag [9613,9616]
===
match
---
simple_stmt [15648,15700]
simple_stmt [15552,15604]
===
match
---
trailer [9551,9557]
trailer [9524,9530]
===
match
---
trailer [22422,22441]
trailer [22326,22345]
===
match
---
fstring [16990,17034]
fstring [16894,16938]
===
match
---
trailer [26143,26150]
trailer [26047,26054]
===
match
---
name: dag_id [10435,10441]
name: dag_id [10408,10414]
===
match
---
trailer [16617,16627]
trailer [16521,16531]
===
match
---
suite [24326,25360]
suite [24230,25264]
===
match
---
parameters [23119,23125]
parameters [23023,23029]
===
match
---
name: subdag [23035,23041]
name: subdag [22939,22945]
===
match
---
name: dag_id [27576,27582]
name: dag_id [27480,27486]
===
match
---
trailer [19314,19318]
trailer [19218,19222]
===
match
---
name: might_contain_dag [1680,1697]
name: might_contain_dag [1653,1670]
===
match
---
name: import_errors [4838,4851]
name: import_errors [4811,4824]
===
match
---
name: session [26260,26267]
name: session [26164,26171]
===
match
---
name: dag_id [7000,7006]
name: dag_id [6973,6979]
===
match
---
for_stmt [21193,22165]
for_stmt [21097,22069]
===
match
---
name: log [20874,20877]
name: log [20778,20781]
===
match
---
trailer [19222,19229]
trailer [19126,19133]
===
match
---
name: self [20817,20821]
name: self [20721,20725]
===
match
---
operator: < [9353,9354]
operator: < [9326,9327]
===
match
---
trailer [14670,14678]
trailer [14574,14582]
===
match
---
name: subdags [23027,23034]
name: subdags [22931,22938]
===
match
---
trailer [11902,11926]
trailer [11806,11830]
===
match
---
operator: { [22918,22919]
operator: { [22822,22823]
===
match
---
name: SerializedDagModel [10412,10430]
name: SerializedDagModel [10385,10403]
===
match
---
name: dag [25231,25234]
name: dag [25135,25138]
===
match
---
sync_comp_for [23369,23383]
sync_comp_for [23273,23287]
===
match
---
trailer [16665,16674]
trailer [16569,16578]
===
match
---
param [17574,17582]
param [17478,17486]
===
match
---
trailer [12893,12903]
trailer [12797,12807]
===
match
---
name: update [26568,26574]
name: update [26472,26478]
===
match
---
operator: , [5512,5513]
operator: , [5485,5486]
===
match
---
name: load_op_links [5798,5811]
name: load_op_links [5771,5784]
===
match
---
atom_expr [25570,25606]
atom_expr [25474,25510]
===
match
---
if_stmt [4238,4569]
if_stmt [4211,4542]
===
match
---
name: dag_id [26941,26947]
name: dag_id [26845,26851]
===
match
---
atom_expr [26995,27024]
atom_expr [26899,26928]
===
match
---
operator: != [9591,9593]
operator: != [9564,9566]
===
match
---
name: fromtimestamp [11477,11490]
name: fromtimestamp [11381,11394]
===
match
---
operator: , [12538,12539]
operator: , [12442,12443]
===
match
---
operator: == [14627,14629]
operator: == [14531,14533]
===
match
---
atom_expr [23501,23884]
atom_expr [23405,23788]
===
match
---
trailer [5158,5168]
trailer [5131,5141]
===
match
---
operator: , [1033,1034]
operator: , [1033,1034]
===
match
---
name: row [10467,10470]
name: row [10440,10443]
===
match
---
name: import_errors [16961,16974]
name: import_errors [16865,16878]
===
match
---
name: serialize_errors [26127,26143]
name: serialize_errors [26031,26047]
===
match
---
atom [11534,11718]
atom [11438,11622]
===
match
---
testlist_star_expr [14416,14429]
testlist_star_expr [14320,14333]
===
match
---
name: mod_name [14618,14626]
name: mod_name [14522,14530]
===
match
---
name: OperationalError [26300,26316]
name: OperationalError [26204,26220]
===
match
---
return_stmt [24591,24600]
return_stmt [24495,24504]
===
match
---
trailer [25178,25182]
trailer [25082,25086]
===
match
---
name: utcnow [10806,10812]
name: utcnow [10710,10716]
===
match
---
name: spec [13462,13466]
name: spec [13366,13370]
===
match
---
atom_expr [15130,15278]
atom_expr [15034,15182]
===
match
---
name: self [8331,8335]
name: self [8304,8308]
===
match
---
operator: , [983,984]
operator: , [983,984]
===
match
---
name: process_file [21508,21520]
name: process_file [21412,21424]
===
match
---
trailer [15895,15906]
trailer [15799,15810]
===
match
---
operator: , [3682,3683]
operator: , [3655,3656]
===
match
---
trailer [11493,11498]
trailer [11397,11402]
===
match
---
expr_stmt [10574,10612]
expr_stmt [10478,10516]
===
match
---
arglist [8063,8114]
arglist [8036,8087]
===
match
---
atom_expr [12438,12453]
atom_expr [12342,12357]
===
match
---
operator: = [13546,13547]
operator: = [13450,13451]
===
match
---
simple_stmt [9241,9283]
simple_stmt [9214,9256]
===
match
---
trailer [16705,16728]
trailer [16609,16632]
===
match
---
suite [5839,5937]
suite [5812,5910]
===
match
---
atom_expr [21889,21904]
atom_expr [21793,21808]
===
match
---
name: filepath [11508,11516]
name: filepath [11412,11420]
===
match
---
atom_expr [15795,15830]
atom_expr [15699,15734]
===
match
---
funcdef [23102,23907]
funcdef [23006,23811]
===
match
---
import_as_names [975,994]
import_as_names [975,994]
===
match
---
name: ApplessAirflowSecurityManager [27772,27801]
name: ApplessAirflowSecurityManager [27676,27705]
===
match
---
name: ViewMenu [27248,27256]
name: ViewMenu [27152,27160]
===
match
---
name: last_expired [9312,9324]
name: last_expired [9285,9297]
===
match
---
name: root_dag [18906,18914]
name: root_dag [18810,18818]
===
match
---
name: dag [10838,10841]
name: dag [10742,10745]
===
match
---
atom_expr [10657,10668]
atom_expr [10561,10572]
===
match
---
name: SerializedDagModel [7997,8015]
name: SerializedDagModel [7970,7988]
===
match
---
import_from [1180,1208]
import_from [1180,1208]
===
match
---
trailer [23034,23049]
trailer [22938,22953]
===
match
---
expr_stmt [18487,18508]
expr_stmt [18391,18412]
===
match
---
name: debug [25915,25920]
name: debug [25819,25824]
===
match
---
operator: , [3818,3819]
operator: , [3791,3792]
===
match
---
name: subdag [23052,23058]
name: subdag [22956,22962]
===
match
---
except_clause [16822,16865]
except_clause [16726,16769]
===
match
---
name: security [26848,26856]
name: security [26752,26760]
===
match
---
atom_expr [19011,19027]
atom_expr [18915,18931]
===
match
---
name: m [16412,16413]
name: m [16316,16317]
===
match
---
name: dag_id [10179,10185]
name: dag_id [10152,10158]
===
match
---
name: dag [18971,18974]
name: dag [18875,18878]
===
match
---
atom [23279,23306]
atom [23183,23210]
===
match
---
atom_expr [11271,11295]
atom_expr [11175,11199]
===
match
---
name: self [8614,8618]
name: self [8587,8591]
===
match
---
tfpdef [20212,20227]
tfpdef [20116,20131]
===
match
---
operator: , [21386,21387]
operator: , [21290,21291]
===
match
---
name: str [4858,4861]
name: str [4831,4834]
===
match
---
name: session [8106,8113]
name: session [8079,8086]
===
match
---
atom_expr [13283,13345]
atom_expr [13187,13249]
===
match
---
operator: , [20181,20182]
operator: , [20085,20086]
===
match
---
suite [21415,22092]
suite [21319,21996]
===
match
---
decorator [6283,6293]
decorator [6256,6266]
===
match
---
string: "The store_serialized_dags parameter has been deprecated. " [4307,4366]
string: "The store_serialized_dags parameter has been deprecated. " [4280,4339]
===
match
---
operator: , [14182,14183]
operator: , [14086,14087]
===
match
---
name: _add_dag_from_db [7101,7117]
name: _add_dag_from_db [7074,7090]
===
match
---
arglist [21521,21583]
arglist [21425,21487]
===
match
---
name: logger [25590,25596]
name: logger [25494,25500]
===
match
---
operator: = [21811,21812]
operator: = [21715,21716]
===
match
---
name: list_py_file_paths [21209,21227]
name: list_py_file_paths [21113,21131]
===
match
---
name: settings [21752,21760]
name: settings [21656,21664]
===
match
---
expr_stmt [13462,13518]
expr_stmt [13366,13422]
===
match
---
atom_expr [22222,22232]
atom_expr [22126,22136]
===
match
---
simple_stmt [20869,20928]
simple_stmt [20773,20832]
===
match
---
operator: == [11669,11671]
operator: == [11573,11575]
===
match
---
trailer [16755,16762]
trailer [16659,16666]
===
match
---
name: dag_id [8511,8517]
name: dag_id [8484,8490]
===
match
---
trailer [4837,4851]
trailer [4810,4824]
===
match
---
operator: , [27651,27652]
operator: , [27555,27556]
===
match
---
suite [26102,26198]
suite [26006,26102]
===
match
---
expr_stmt [11974,12029]
expr_stmt [11878,11933]
===
match
---
atom [27096,27462]
atom [27000,27366]
===
match
---
name: safe_mode [21574,21583]
name: safe_mode [21478,21487]
===
match
---
name: _serialize_dag_capturing_errors [24280,24311]
name: _serialize_dag_capturing_errors [24184,24215]
===
match
---
name: Stats [22411,22416]
name: Stats [22315,22320]
===
match
---
name: found_dags [16483,16493]
name: found_dags [16387,16397]
===
match
---
atom_expr [4671,4680]
atom_expr [4644,4653]
===
match
---
atom [17134,17287]
atom [17038,17191]
===
match
---
trailer [10142,10147]
trailer [10115,10120]
===
match
---
name: dag [19031,19034]
name: dag [18935,18938]
===
match
---
name: filepath [12727,12735]
name: filepath [12631,12639]
===
match
---
name: duration [23837,23845]
name: duration [23741,23749]
===
match
---
suite [25633,26599]
suite [25537,26503]
===
match
---
atom [16512,16522]
atom [16416,16426]
===
match
---
suite [4263,4569]
suite [4236,4542]
===
match
---
name: include_examples [21298,21314]
name: include_examples [21202,21218]
===
match
---
operator: , [13434,13435]
operator: , [13338,13339]
===
match
---
name: total_seconds [23321,23334]
name: total_seconds [23225,23238]
===
match
---
simple_stmt [6248,6278]
simple_stmt [6221,6251]
===
match
---
trailer [8780,8785]
trailer [8753,8758]
===
match
---
simple_stmt [25688,25890]
simple_stmt [25592,25794]
===
match
---
expr_stmt [4671,4701]
expr_stmt [4644,4674]
===
match
---
name: session [26659,26666]
name: session [26563,26570]
===
match
---
name: dag [9329,9332]
name: dag [9302,9305]
===
match
---
name: dags [8619,8623]
name: dags [8592,8596]
===
match
---
trailer [16655,16665]
trailer [16559,16569]
===
match
---
name: fileloc [16931,16938]
name: fileloc [16835,16842]
===
match
---
name: stats [22201,22206]
name: stats [22105,22110]
===
match
---
name: read_dags_from_db [6260,6277]
name: read_dags_from_db [6233,6250]
===
match
---
name: modules [15344,15351]
name: modules [15248,15255]
===
match
---
tfpdef [20009,20030]
tfpdef [19913,19934]
===
match
---
operator: , [25024,25025]
operator: , [24928,24929]
===
match
---
operator: } [12811,12812]
operator: } [12715,12716]
===
match
---
trailer [21946,21957]
trailer [21850,21861]
===
match
---
name: self [15856,15860]
name: self [15760,15764]
===
match
---
expr_stmt [11891,11947]
expr_stmt [11795,11851]
===
match
---
name: self [17391,17395]
name: self [17295,17299]
===
match
---
suite [13346,14128]
suite [13250,14032]
===
match
---
trailer [12672,12678]
trailer [12576,12582]
===
match
---
name: str [5175,5178]
name: str [5148,5151]
===
match
---
operator: = [21573,21574]
operator: = [21477,21478]
===
match
---
trailer [25696,25702]
trailer [25600,25606]
===
match
---
trailer [21760,21772]
trailer [21664,21676]
===
match
---
atom_expr [11468,11518]
atom_expr [11372,11422]
===
match
---
arglist [9066,9094]
arglist [9039,9067]
===
match
---
simple_stmt [21042,21053]
simple_stmt [20946,20957]
===
match
---
name: duration [21803,21811]
name: duration [21707,21715]
===
match
---
operator: , [4027,4028]
operator: , [4000,4001]
===
match
---
trailer [27847,27865]
trailer [27751,27769]
===
match
---
name: dag_folder [21241,21251]
name: dag_folder [21145,21155]
===
match
---
name: filepath [9811,9819]
name: filepath [9784,9792]
===
match
---
dotted_name [1478,1491]
dotted_name [1451,1464]
===
match
---
operator: - [21832,21833]
operator: - [21736,21737]
===
match
---
param [17958,17962]
param [17862,17866]
===
match
---
operator: } [12826,12827]
operator: } [12730,12731]
===
match
---
dotted_name [4171,4189]
dotted_name [4144,4162]
===
match
---
trailer [20245,20280]
trailer [20149,20184]
===
match
---
operator: = [22192,22193]
operator: = [22096,22097]
===
match
---
simple_stmt [16693,16729]
simple_stmt [16597,16633]
===
match
---
name: _ [12644,12645]
name: _ [12548,12549]
===
match
---
param [10269,10285]
param [10242,10258]
===
match
---
simple_stmt [15299,15308]
simple_stmt [15203,15212]
===
match
---
name: mod_name [15531,15539]
name: mod_name [15435,15443]
===
match
---
simple_stmt [12126,12187]
simple_stmt [12030,12091]
===
match
---
import_from [16314,16348]
import_from [16218,16252]
===
match
---
name: o [16402,16403]
name: o [16306,16307]
===
match
---
operator: , [17961,17962]
operator: , [17865,17866]
===
match
---
trailer [18225,18230]
trailer [18129,18134]
===
match
---
name: self [4671,4675]
name: self [4644,4648]
===
match
---
name: is_subdag [24564,24573]
name: is_subdag [24468,24477]
===
match
---
name: isfile [11279,11285]
name: isfile [11183,11189]
===
match
---
trailer [9148,9152]
trailer [9121,9125]
===
match
---
name: dags_hash [5159,5168]
name: dags_hash [5132,5141]
===
match
---
atom_expr [8202,8264]
atom_expr [8175,8237]
===
match
---
trailer [5925,5936]
trailer [5898,5909]
===
match
---
simple_stmt [1607,1698]
simple_stmt [1580,1671]
===
match
---
trailer [9311,9324]
trailer [9284,9297]
===
match
---
arglist [18885,18931]
arglist [18789,18835]
===
match
---
param [26941,26952]
param [26845,26856]
===
match
---
atom_expr [22455,22507]
atom_expr [22359,22411]
===
match
---
name: session [1844,1851]
name: session [1817,1824]
===
match
---
name: OperationalError [1097,1113]
name: OperationalError [1097,1113]
===
match
---
arglist [13791,13823]
arglist [13695,13727]
===
match
---
operator: = [21501,21502]
operator: = [21405,21406]
===
match
---
name: log [16888,16891]
name: log [16792,16795]
===
match
---
trailer [15138,15143]
trailer [15042,15047]
===
match
---
trailer [13780,13790]
trailer [13684,13694]
===
match
---
atom_expr [5922,5936]
atom_expr [5895,5909]
===
match
---
name: self [21503,21507]
name: self [21407,21411]
===
match
---
simple_stmt [17391,17440]
simple_stmt [17295,17344]
===
match
---
argument [19200,19238]
argument [19104,19142]
===
match
---
trailer [5781,5795]
trailer [5754,5768]
===
match
---
operator: = [15884,15885]
operator: = [15788,15789]
===
match
---
trailer [12721,12726]
trailer [12625,12630]
===
match
---
argument [9079,9094]
argument [9052,9067]
===
match
---
comparison [10012,10068]
comparison [9985,10041]
===
match
---
try_stmt [24613,25360]
try_stmt [24517,25264]
===
match
---
name: parent_dag [8887,8897]
name: parent_dag [8860,8870]
===
match
---
name: dagbag_stats [23206,23218]
name: dagbag_stats [23110,23122]
===
match
---
param [20009,20038]
param [19913,19942]
===
match
---
name: filepath [12074,12082]
name: filepath [11978,11986]
===
match
---
trailer [22669,22674]
trailer [22573,22578]
===
match
---
trailer [11867,11877]
trailer [11771,11781]
===
match
---
name: airflow [27682,27689]
name: airflow [27586,27593]
===
match
---
operator: = [11466,11467]
operator: = [11370,11371]
===
match
---
trailer [19864,19869]
trailer [19768,19773]
===
match
---
operator: = [9819,9820]
operator: = [9792,9793]
===
match
---
trailer [8298,8306]
trailer [8271,8279]
===
match
---
trailer [15689,15698]
trailer [15593,15602]
===
match
---
name: file_last_changed [17056,17073]
name: file_last_changed [16960,16977]
===
match
---
name: include_examples [5496,5512]
name: include_examples [5469,5485]
===
match
---
operator: , [12642,12643]
operator: , [12546,12547]
===
match
---
operator: { [5056,5057]
operator: { [5029,5030]
===
match
---
name: only_if_updated [21531,21546]
name: only_if_updated [21435,21450]
===
match
---
name: read_dags_from_db [4527,4544]
name: read_dags_from_db [4500,4517]
===
match
---
name: has_logged [12410,12420]
name: has_logged [12314,12324]
===
match
---
name: str [26949,26952]
name: str [26853,26856]
===
match
---
import_from [1114,1148]
import_from [1114,1148]
===
match
---
trailer [25692,25696]
trailer [25596,25600]
===
match
---
trailer [7817,7835]
trailer [7790,7808]
===
match
---
if_stmt [14829,15308]
if_stmt [14733,15212]
===
match
---
name: found_dags [21969,21979]
name: found_dags [21873,21883]
===
match
---
name: str [16090,16093]
name: str [15994,15997]
===
match
---
simple_stmt [15130,15279]
simple_stmt [15034,15183]
===
match
---
trailer [12856,12864]
trailer [12760,12768]
===
match
---
atom_expr [7856,7873]
atom_expr [7829,7846]
===
match
---
operator: = [24744,24745]
operator: = [24648,24649]
===
match
---
name: dags [10174,10178]
name: dags [10147,10151]
===
match
---
suite [24617,25069]
suite [24521,24973]
===
match
---
operator: = [8746,8747]
operator: = [8719,8720]
===
match
---
simple_stmt [25059,25069]
simple_stmt [24963,24973]
===
match
---
not_test [14832,14901]
not_test [14736,14805]
===
match
---
name: self [13844,13848]
name: self [13748,13752]
===
match
---
name: util [13558,13562]
name: util [13462,13466]
===
match
---
operator: { [23855,23856]
operator: { [23759,23760]
===
match
---
operator: = [17924,17925]
operator: = [17828,17829]
===
match
---
name: self [19209,19213]
name: self [19113,19117]
===
match
---
string: "Failed to import: %s" [15739,15761]
string: "Failed to import: %s" [15643,15665]
===
match
---
name: LoggingMixin [1742,1754]
name: LoggingMixin [1715,1727]
===
match
---
argument [25026,25041]
argument [24930,24945]
===
match
---
operator: = [9252,9253]
operator: = [9225,9226]
===
match
---
trailer [5241,5252]
trailer [5214,5225]
===
match
---
trailer [19524,19528]
trailer [19428,19432]
===
match
---
name: self [12052,12056]
name: self [11956,11960]
===
match
---
trailer [7864,7871]
trailer [7837,7844]
===
match
---
trailer [27235,27257]
trailer [27139,27161]
===
match
---
simple_stmt [24728,24941]
simple_stmt [24632,24845]
===
match
---
name: fileloc [25279,25286]
name: fileloc [25183,25190]
===
match
---
trailer [10837,10849]
trailer [10741,10753]
===
match
---
name: textwrap [897,905]
name: textwrap [897,905]
===
match
---
trailer [25182,25192]
trailer [25086,25096]
===
match
---
name: self [15042,15046]
name: self [14946,14950]
===
match
---
simple_stmt [14416,14468]
simple_stmt [14320,14372]
===
match
---
name: fileloc [16079,16086]
name: fileloc [15983,15990]
===
match
---
atom_expr [26219,26276]
atom_expr [26123,26180]
===
match
---
name: filepath [16262,16270]
name: filepath [16166,16174]
===
match
---
simple_stmt [1508,1563]
simple_stmt [1481,1536]
===
match
---
operator: , [17572,17573]
operator: , [17476,17477]
===
match
---
simple_stmt [22143,22165]
simple_stmt [22047,22069]
===
match
---
atom_expr [7173,7194]
atom_expr [7146,7167]
===
match
---
suite [11719,11746]
suite [11623,11650]
===
match
---
name: sys [12853,12856]
name: sys [12757,12760]
===
match
---
suite [23006,23059]
suite [22910,22963]
===
match
---
operator: = [5344,5345]
operator: = [5317,5318]
===
match
---
simple_stmt [4634,4663]
simple_stmt [4607,4636]
===
match
---
simple_stmt [1209,1248]
simple_stmt [1209,1248]
===
match
---
expr_stmt [9471,9676]
expr_stmt [9444,9649]
===
match
---
trailer [26239,26276]
trailer [26143,26180]
===
match
---
atom_expr [4276,4514]
atom_expr [4249,4487]
===
match
---
trailer [17460,17478]
trailer [17364,17382]
===
match
---
operator: = [23474,23475]
operator: = [23378,23379]
===
match
---
comparison [27286,27332]
comparison [27190,27236]
===
match
---
name: sqla_models [27132,27143]
name: sqla_models [27036,27047]
===
match
---
tfpdef [4037,4074]
tfpdef [4010,4047]
===
match
---
name: o [23423,23424]
name: o [23327,23328]
===
match
---
funcdef [26920,27521]
funcdef [26824,27425]
===
match
---
trailer [10698,10705]
trailer [10602,10609]
===
match
---
operator: - [25315,25316]
operator: - [25219,25220]
===
match
---
argument [21298,21331]
argument [21202,21235]
===
match
---
argument [25309,25356]
argument [25213,25260]
===
match
---
simple_stmt [19856,19885]
simple_stmt [19760,19789]
===
match
---
operator: , [14781,14782]
operator: , [14685,14686]
===
match
---
atom_expr [13469,13518]
atom_expr [13373,13422]
===
match
---
expr_stmt [9291,9375]
expr_stmt [9264,9348]
===
match
---
comparison [12841,12864]
comparison [12745,12768]
===
match
---
expr_stmt [24728,24940]
expr_stmt [24632,24844]
===
match
---
operator: = [22241,22242]
operator: = [22145,22146]
===
match
---
trailer [27125,27131]
trailer [27029,27035]
===
match
---
atom_expr [5199,5234]
atom_expr [5172,5207]
===
match
---
trailer [14448,14467]
trailer [14352,14371]
===
match
---
name: bool [20144,20148]
name: bool [20048,20052]
===
match
---
atom [21050,21052]
atom [20954,20956]
===
match
---
name: exception [17429,17438]
name: exception [17333,17342]
===
match
---
except_clause [13733,13754]
except_clause [13637,13658]
===
match
---
expr_stmt [23264,23336]
expr_stmt [23168,23240]
===
match
---
operator: = [8584,8585]
operator: = [8557,8558]
===
match
---
operator: = [13467,13468]
operator: = [13371,13372]
===
match
---
arglist [12596,12620]
arglist [12500,12524]
===
match
---
name: filename [15690,15698]
name: filename [15594,15602]
===
match
---
name: Exception [11761,11770]
name: Exception [11665,11674]
===
match
---
trailer [14434,14439]
trailer [14338,14343]
===
match
---
name: file_last_changed_on_disk [11440,11465]
name: file_last_changed_on_disk [11344,11369]
===
match
---
name: debug [19319,19324]
name: debug [19223,19228]
===
match
---
atom_expr [19804,19817]
atom_expr [19708,19721]
===
match
---
for_stmt [22980,23059]
for_stmt [22884,22963]
===
match
---
trailer [10841,10848]
trailer [10745,10752]
===
match
---
param [6512,6519]
param [6485,6492]
===
match
---
if_stmt [6997,7195]
if_stmt [6970,7168]
===
match
---
atom_expr [5413,5611]
atom_expr [5386,5584]
===
match
---
trailer [25001,25020]
trailer [24905,24924]
===
match
---
argument [16706,16713]
argument [16610,16617]
===
match
---
name: subdag [10709,10715]
name: subdag [10613,10619]
===
match
---
trailer [8618,8623]
trailer [8591,8596]
===
match
---
trailer [14244,14252]
trailer [14148,14156]
===
match
---
if_stmt [9384,9677]
if_stmt [9357,9650]
===
match
---
param [14194,14203]
param [14098,14107]
===
match
---
name: Dict [4682,4686]
name: Dict [4655,4659]
===
match
---
trailer [17336,17374]
trailer [17240,17278]
===
match
---
name: mod_name [15328,15336]
name: mod_name [15232,15240]
===
match
---
atom_expr [22174,22191]
atom_expr [22078,22095]
===
match
---
tfpdef [26941,26952]
tfpdef [26845,26856]
===
match
---
operator: = [13625,13626]
operator: = [13529,13530]
===
match
---
atom_expr [16693,16728]
atom_expr [16597,16632]
===
match
---
operator: = [17890,17891]
operator: = [17794,17795]
===
match
---
operator: , [12260,12261]
operator: , [12164,12165]
===
match
---
trailer [9143,9148]
trailer [9116,9121]
===
match
---
operator: = [15099,15100]
operator: = [15003,15004]
===
match
---
atom [25274,25358]
atom [25178,25262]
===
match
---
string: """         :return: a list of DAG IDs in this bag         :rtype: List[unicode]         """ [6337,6429]
string: """         :return: a list of DAG IDs in this bag         :rtype: List[unicode]         """ [6310,6402]
===
match
---
trailer [8886,8897]
trailer [8859,8870]
===
match
---
import_from [1441,1472]
import_from [1414,1445]
===
match
---
expr_stmt [15856,16009]
expr_stmt [15760,15913]
===
match
---
simple_stmt [27508,27521]
simple_stmt [27412,27425]
===
match
---
del_stmt [8382,8408]
del_stmt [8355,8381]
===
match
---
name: duration [23282,23290]
name: duration [23186,23194]
===
match
---
name: loader [13654,13660]
name: loader [13558,13564]
===
match
---
operator: , [19566,19567]
operator: , [19470,19471]
===
match
---
name: o [16465,16466]
name: o [16369,16370]
===
match
---
name: conf [20230,20234]
name: conf [20134,20138]
===
match
---
atom [16400,16473]
atom [16304,16377]
===
match
---
atom_expr [25316,25356]
atom_expr [25220,25260]
===
match
---
name: filter [27279,27285]
name: filter [27183,27189]
===
match
---
trailer [18833,18843]
trailer [18737,18747]
===
match
---
name: self [5010,5014]
name: self [4983,4987]
===
match
---
expr_stmt [4776,4824]
expr_stmt [4749,4797]
===
match
---
name: _ [14363,14364]
name: _ [14267,14268]
===
match
---
simple_stmt [803,820]
simple_stmt [803,820]
===
match
---
name: dag [18751,18754]
name: dag [18655,18658]
===
match
---
return_stmt [5915,5936]
return_stmt [5888,5909]
===
match
---
operator: , [25870,25871]
operator: , [25774,25775]
===
match
---
name: tabulate [1154,1162]
name: tabulate [1154,1162]
===
match
---
dotted_name [1119,1133]
dotted_name [1119,1133]
===
match
---
name: self [10169,10173]
name: self [10142,10146]
===
match
---
trailer [21942,21980]
trailer [21846,21884]
===
match
---
simple_stmt [5303,5405]
simple_stmt [5276,5378]
===
match
---
name: _add_dag_from_db [10233,10249]
name: _add_dag_from_db [10206,10222]
===
match
---
name: _bag_dag [17878,17886]
name: _bag_dag [17782,17790]
===
match
---
arglist [15457,15468]
arglist [15361,15372]
===
match
---
if_stmt [12398,12550]
if_stmt [12302,12454]
===
match
---
name: self [17318,17322]
name: self [17222,17226]
===
match
---
name: found_dags [9997,10007]
name: found_dags [9970,9980]
===
match
---
atom_expr [19960,19992]
atom_expr [19864,19896]
===
match
---
operator: } [9675,9676]
operator: } [9648,9649]
===
match
---
trailer [19876,19883]
trailer [19780,19787]
===
match
---
trailer [15665,15670]
trailer [15569,15574]
===
match
---
name: models [10349,10355]
name: models [10322,10328]
===
match
---
name: zip_info [14300,14308]
name: zip_info [14204,14212]
===
match
---
trailer [22709,22711]
trailer [22613,22615]
===
match
---
dotted_name [10341,10370]
dotted_name [10314,10343]
===
match
---
atom_expr [25800,25834]
atom_expr [25704,25738]
===
match
---
suite [14283,16210]
suite [14187,16114]
===
match
---
name: get_last_updated_datetime [8016,8041]
name: get_last_updated_datetime [7989,8014]
===
match
---
trailer [10434,10451]
trailer [10407,10424]
===
match
---
name: orm_dag [9111,9118]
name: orm_dag [9084,9091]
===
match
---
trailer [10598,10612]
trailer [10502,10516]
===
match
---
atom_expr [17318,17374]
atom_expr [17222,17278]
===
match
---
trailer [19528,19538]
trailer [19432,19442]
===
match
---
name: root_dag [17574,17582]
name: root_dag [17478,17486]
===
match
---
name: module_from_spec [13563,13579]
name: module_from_spec [13467,13483]
===
match
---
arglist [26240,26275]
arglist [26144,26179]
===
match
---
dotted_name [854,868]
dotted_name [854,868]
===
match
---
trailer [3519,3552]
trailer [3492,3525]
===
match
---
name: file_last_changed_on_disk [17089,17114]
name: file_last_changed_on_disk [16993,17018]
===
match
---
trailer [17428,17439]
trailer [17332,17343]
===
match
---
argument [21881,21904]
argument [21785,21808]
===
match
---
expr_stmt [12630,12693]
expr_stmt [12534,12597]
===
match
---
expr_stmt [18946,18982]
expr_stmt [18850,18886]
===
match
---
import_from [1825,1874]
import_from [1798,1847]
===
match
---
name: dag [27533,27536]
name: dag [27437,27440]
===
match
---
name: airflow [4171,4178]
name: airflow [4144,4151]
===
match
---
trailer [23080,23087]
trailer [22984,22991]
===
match
---
name: head [14563,14567]
name: head [14467,14471]
===
match
---
atom_expr [10682,10706]
atom_expr [10586,10610]
===
match
---
argument [21803,21855]
argument [21707,21759]
===
match
---
name: info [15139,15143]
name: info [15043,15047]
===
match
---
trailer [16901,16939]
trailer [16805,16843]
===
match
---
name: dag_folder [23647,23657]
name: dag_folder [23551,23561]
===
match
---
name: DeprecationWarning [4451,4469]
name: DeprecationWarning [4424,4442]
===
match
---
operator: = [10592,10593]
operator: = [10496,10497]
===
match
---
operator: = [12782,12783]
operator: = [12686,12687]
===
match
---
trailer [16206,16209]
trailer [16110,16113]
===
match
---
name: MAX_DB_RETRIES [1789,1803]
name: MAX_DB_RETRIES [1762,1776]
===
match
---
atom_expr [13119,13176]
atom_expr [13023,13080]
===
match
---
name: DAG [4197,4200]
name: DAG [4170,4173]
===
match
---
atom_expr [15681,15698]
atom_expr [15585,15602]
===
match
---
name: row [10406,10409]
name: row [10379,10382]
===
match
---
name: flask_appbuilder [26766,26782]
name: flask_appbuilder [26670,26686]
===
match
---
operator: , [8575,8576]
operator: , [8548,8549]
===
match
---
trailer [22147,22151]
trailer [22051,22055]
===
match
---
operator: { [23646,23647]
operator: { [23550,23551]
===
match
---
name: dag [8799,8802]
name: dag [8772,8775]
===
match
---
name: self [16693,16697]
name: self [16597,16601]
===
match
---
expr_stmt [27753,27818]
expr_stmt [27657,27722]
===
match
---
name: correct_maybe_zipped [1638,1658]
name: correct_maybe_zipped [1611,1631]
===
match
---
name: dag_folder [4591,4601]
name: dag_folder [4564,4574]
===
match
---
name: path [15445,15449]
name: path [15349,15353]
===
match
---
for_stmt [19758,19885]
for_stmt [19662,19789]
===
match
---
name: dag_folder [20968,20978]
name: dag_folder [20872,20882]
===
match
---
name: session [24914,24921]
name: session [24818,24825]
===
match
---
trailer [9780,9793]
trailer [9753,9766]
===
match
---
dotted_name [1513,1543]
dotted_name [1486,1516]
===
match
---
trailer [17482,17490]
trailer [17386,17394]
===
match
---
trailer [15134,15138]
trailer [15038,15042]
===
match
---
trailer [13672,13684]
trailer [13576,13588]
===
match
---
name: orm_dag [9304,9311]
name: orm_dag [9277,9284]
===
match
---
param [10256,10268]
param [10229,10241]
===
match
---
name: getboolean [3941,3951]
name: getboolean [3914,3924]
===
match
---
name: dag_id [9655,9661]
name: dag_id [9628,9634]
===
match
---
if_stmt [8458,8594]
if_stmt [8431,8567]
===
match
---
name: DagModel [9045,9053]
name: DagModel [9018,9026]
===
match
---
atom_expr [18382,18406]
atom_expr [18286,18310]
===
match
---
simple_stmt [10165,10187]
simple_stmt [10138,10160]
===
match
---
simple_stmt [8734,8755]
simple_stmt [8707,8728]
===
match
---
name: recursive [19731,19740]
name: recursive [19635,19644]
===
match
---
atom [9606,9662]
atom [9579,9635]
===
match
---
atom_expr [13901,13929]
atom_expr [13805,13833]
===
match
---
name: dag [18428,18431]
name: dag [18332,18335]
===
match
---
name: hashlib [12714,12721]
name: hashlib [12618,12625]
===
match
---
atom_expr [16454,16472]
atom_expr [16358,16376]
===
match
---
name: session [7133,7140]
name: session [7106,7113]
===
match
---
return_stmt [10195,10223]
return_stmt [10168,10196]
===
match
---
name: subdags [18705,18712]
name: subdags [18609,18616]
===
match
---
argument [21730,21777]
argument [21634,21681]
===
match
---
if_stmt [16142,16210]
if_stmt [16046,16114]
===
match
---
trailer [14380,14399]
trailer [14284,14303]
===
match
---
suite [17584,17931]
suite [17488,17835]
===
match
---
atom_expr [10093,10110]
atom_expr [10066,10083]
===
match
---
operator: , [15679,15680]
operator: , [15583,15584]
===
match
---
operator: = [8881,8882]
operator: = [8854,8855]
===
match
---
operator: = [25033,25034]
operator: = [24937,24938]
===
match
---
trailer [14389,14398]
trailer [14293,14302]
===
match
---
fstring_end: " [13018,13019]
fstring_end: " [12922,12923]
===
match
---
simple_stmt [14746,14812]
simple_stmt [14650,14716]
===
match
---
operator: , [20202,20203]
operator: , [20106,20107]
===
match
---
name: sqla_models [27186,27197]
name: sqla_models [27090,27101]
===
match
---
trailer [19213,19218]
trailer [19117,19122]
===
match
---
name: dags [26245,26249]
name: dags [26149,26153]
===
match
---
name: log [12482,12485]
name: log [12386,12389]
===
match
---
trailer [20882,20927]
trailer [20786,20831]
===
match
---
name: str [2113,2116]
name: str [2086,2089]
===
match
---
suite [14902,15308]
suite [14806,15212]
===
match
---
fstring_start: f" [13114,13116]
fstring_start: f" [13018,13020]
===
match
---
operator: , [1061,1062]
operator: , [1061,1062]
===
match
---
if_stmt [24557,24601]
if_stmt [24461,24505]
===
match
---
name: query [27126,27131]
name: query [27030,27035]
===
match
---
trailer [21632,21639]
trailer [21536,21543]
===
match
---
atom_expr [10202,10223]
atom_expr [10175,10196]
===
match
---
name: self [23120,23124]
name: self [23024,23028]
===
match
---
simple_stmt [23071,23097]
simple_stmt [22975,23001]
===
match
---
name: filepath [21197,21205]
name: filepath [21101,21109]
===
match
---
name: importlib [13469,13478]
name: importlib [13373,13382]
===
match
---
name: get_docs_url [13119,13131]
name: get_docs_url [13023,13035]
===
match
---
atom_expr [26083,26101]
atom_expr [25987,26005]
===
match
---
suite [19780,19885]
suite [19684,19789]
===
match
---
expr_stmt [25650,25671]
expr_stmt [25554,25575]
===
match
---
simple_stmt [19270,19298]
simple_stmt [19174,19202]
===
match
---
atom_expr [15943,15983]
atom_expr [15847,15887]
===
match
---
trailer [11694,11704]
trailer [11598,11608]
===
match
---
expr_stmt [7676,7769]
expr_stmt [7649,7742]
===
match
---
name: filepath [15225,15233]
name: filepath [15129,15137]
===
match
---
name: m [16405,16406]
name: m [16309,16310]
===
match
---
atom [9483,9676]
atom [9456,9649]
===
match
---
simple_stmt [788,803]
simple_stmt [788,803]
===
match
---
operator: , [21331,21332]
operator: , [21235,21236]
===
match
---
name: dag [16927,16930]
name: dag [16831,16834]
===
match
---
return_stmt [10086,10110]
return_stmt [10059,10083]
===
match
---
tfpdef [10269,10285]
tfpdef [10242,10258]
===
match
---
simple_stmt [18871,18933]
simple_stmt [18775,18837]
===
match
---
import_name [923,938]
import_name [923,938]
===
match
---
name: getboolean [20077,20087]
name: getboolean [19981,19991]
===
match
---
name: DAG [16345,16348]
name: DAG [16249,16252]
===
match
---
string: "Calling the DAG.bulk_sync_to_db method" [25921,25961]
string: "Calling the DAG.bulk_sync_to_db method" [25825,25865]
===
match
---
trailer [25589,25606]
trailer [25493,25510]
===
match
---
trailer [25297,25308]
trailer [25201,25212]
===
match
---
name: dag [17958,17961]
name: dag [17862,17865]
===
match
---
return_stmt [14136,14145]
return_stmt [14040,14049]
===
match
---
atom_expr [20869,20927]
atom_expr [20773,20831]
===
match
---
operator: = [6226,6227]
operator: = [6199,6200]
===
match
---
expr_stmt [4833,4872]
expr_stmt [4806,4845]
===
match
---
trailer [25807,25819]
trailer [25711,25723]
===
match
---
operator: , [20252,20253]
operator: , [20156,20157]
===
match
---
name: zip_info [14381,14389]
name: zip_info [14285,14293]
===
match
---
expr_stmt [22174,22247]
expr_stmt [22078,22151]
===
match
---
argument [23408,23433]
argument [23312,23337]
===
match
---
name: file [1626,1630]
name: file [1599,1603]
===
match
---
name: subdag [18695,18701]
name: subdag [18599,18605]
===
match
---
name: attempt_number [25820,25834]
name: attempt_number [25724,25738]
===
match
---
name: str [14121,14124]
name: str [14025,14028]
===
match
---
fstring [13114,13180]
fstring [13018,13084]
===
match
---
trailer [25819,25834]
trailer [25723,25738]
===
match
---
name: join [15666,15670]
name: join [15570,15574]
===
match
---
name: spec [13614,13618]
name: spec [13518,13522]
===
match
---
expr_stmt [2034,2043]
expr_stmt [2007,2016]
===
match
---
name: self [8805,8809]
name: self [8778,8782]
===
match
---
name: orm_dag [9035,9042]
name: orm_dag [9008,9015]
===
match
---
atom [11743,11745]
atom [11647,11649]
===
match
---
name: found_dags [17535,17545]
name: found_dags [17439,17449]
===
match
---
name: prev_dag [18998,19006]
name: prev_dag [18902,18910]
===
match
---
name: dag [22016,22019]
name: dag [21920,21923]
===
match
---
trailer [9152,9160]
trailer [9125,9133]
===
match
---
operator: = [13930,13931]
operator: = [13834,13835]
===
match
---
name: self [9542,9546]
name: self [9515,9519]
===
match
---
name: dagbag_report [23106,23119]
name: dagbag_report [23010,23023]
===
match
---
name: self [10724,10728]
name: self [10628,10632]
===
match
---
name: SerializedDagModel [24248,24266]
name: SerializedDagModel [24152,24170]
===
match
---
string: """Whether or not to read dags from DB""" [6005,6046]
string: """Whether or not to read dags from DB""" [5978,6019]
===
match
---
atom [4822,4824]
atom [4795,4797]
===
match
---
name: mods [11891,11895]
name: mods [11795,11799]
===
match
---
expr_stmt [4578,4625]
expr_stmt [4551,4598]
===
match
---
arglist [24796,24922]
arglist [24700,24826]
===
match
---
atom_expr [9355,9375]
atom_expr [9328,9348]
===
match
---
operator: , [14800,14801]
operator: , [14704,14705]
===
match
---
name: dag [16513,16516]
name: dag [16417,16420]
===
match
---
operator: , [25229,25230]
operator: , [25133,25134]
===
match
---
name: __dict__ [16433,16441]
name: __dict__ [16337,16345]
===
match
---
decorator [23912,23929]
decorator [23816,23833]
===
match
---
name: filepath [13436,13444]
name: filepath [13340,13348]
===
match
---
name: include_smart_sensor [21366,21386]
name: include_smart_sensor [21270,21290]
===
match
---
trailer [5203,5234]
trailer [5176,5207]
===
match
---
name: read_dags_from_db [3996,4013]
name: read_dags_from_db [3969,3986]
===
match
---
name: zipfile [11849,11856]
name: zipfile [11753,11760]
===
match
---
simple_stmt [8202,8265]
simple_stmt [8175,8238]
===
match
---
operator: = [7706,7707]
operator: = [7679,7680]
===
match
---
import_as_names [26876,26910]
import_as_names [26780,26814]
===
match
---
name: self [5777,5781]
name: self [5750,5754]
===
match
---
name: filepath [12149,12157]
name: filepath [12053,12061]
===
match
---
arglist [8562,8592]
arglist [8535,8565]
===
match
---
name: self [17949,17953]
name: self [17853,17857]
===
match
---
tfpdef [3692,3736]
tfpdef [3665,3709]
===
match
---
atom_expr [15507,15540]
atom_expr [15411,15444]
===
match
---
atom_expr [23275,23336]
atom_expr [23179,23240]
===
match
---
suite [12273,14146]
suite [12177,14050]
===
match
---
name: only_if_updated [10903,10918]
name: only_if_updated [10807,10822]
===
match
---
argument [7718,7768]
argument [7691,7741]
===
match
---
funcdef [19908,22248]
funcdef [19812,22152]
===
match
---
return_stmt [12562,12571]
return_stmt [12466,12475]
===
match
---
string: 'core' [5253,5259]
string: 'core' [5226,5232]
===
match
---
expr_stmt [23193,23218]
expr_stmt [23097,23122]
===
match
---
atom_expr [12289,12327]
atom_expr [12193,12231]
===
match
---
simple_stmt [16060,16097]
simple_stmt [15964,16001]
===
match
---
return_stmt [8607,8635]
return_stmt [8580,8608]
===
match
---
operator: = [10918,10919]
operator: = [10822,10823]
===
match
---
simple_stmt [12581,12622]
simple_stmt [12485,12526]
===
match
---
name: file_last_changed_on_disk [17494,17519]
name: file_last_changed_on_disk [17398,17423]
===
match
---
expr_stmt [17051,17114]
expr_stmt [16955,17018]
===
match
---
trailer [4917,4935]
trailer [4890,4908]
===
match
---
simple_stmt [954,995]
simple_stmt [954,995]
===
match
---
trailer [23509,23516]
trailer [23413,23420]
===
match
---
operator: = [7124,7125]
operator: = [7097,7098]
===
match
---
name: SerializedDagModel [6965,6983]
name: SerializedDagModel [6938,6956]
===
match
---
name: fileloc [19231,19238]
name: fileloc [19135,19142]
===
match
---
expr_stmt [17391,17439]
expr_stmt [17295,17343]
===
match
---
operator: , [26887,26888]
operator: , [26791,26792]
===
match
---
operator: , [14424,14425]
operator: , [14328,14329]
===
match
---
for_stmt [16508,17520]
for_stmt [16412,17424]
===
match
---
funcdef [10870,12213]
funcdef [10774,12117]
===
match
---
atom_expr [23359,23368]
atom_expr [23263,23272]
===
match
---
comparison [19804,19830]
comparison [19708,19734]
===
match
---
trailer [9362,9375]
trailer [9335,9348]
===
match
---
name: dag [8715,8718]
name: dag [8688,8691]
===
match
---
and_test [9997,10068]
and_test [9970,10041]
===
match
---
atom_expr [4800,4819]
atom_expr [4773,4792]
===
match
---
string: 'DAG_DISCOVERY_SAFE_MODE' [3960,3985]
string: 'DAG_DISCOVERY_SAFE_MODE' [3933,3958]
===
match
---
name: safe_mode [5591,5600]
name: safe_mode [5564,5573]
===
match
---
string: 'scheduler_zombie_task_threshold' [3616,3649]
string: 'scheduler_zombie_task_threshold' [3589,3622]
===
match
---
trailer [12595,12621]
trailer [12499,12525]
===
match
---
operator: } [5188,5189]
operator: } [5161,5162]
===
match
---
name: sys [12882,12885]
name: sys [12786,12789]
===
match
---
name: task_num [23410,23418]
name: task_num [23314,23322]
===
match
---
name: dag [19219,19222]
name: dag [19123,19126]
===
match
---
suite [26962,27521]
suite [26866,27425]
===
match
---
trailer [15660,15665]
trailer [15564,15569]
===
match
---
param [12246,12251]
param [12150,12155]
===
match
---
string: "Filling up the DagBag from database" [22469,22506]
string: "Filling up the DagBag from database" [22373,22410]
===
match
---
atom_expr [17391,17422]
atom_expr [17295,17326]
===
match
---
atom_expr [13772,13824]
atom_expr [13676,13728]
===
match
---
name: dag_resource_name [27391,27408]
name: dag_resource_name [27295,27312]
===
match
---
operator: , [5042,5043]
operator: , [5015,5016]
===
match
---
name: dag_folder [4639,4649]
name: dag_folder [4612,4622]
===
match
---
return_stmt [17528,17545]
return_stmt [17432,17449]
===
match
---
atom_expr [9337,9352]
atom_expr [9310,9325]
===
match
---
name: models [6936,6942]
name: models [6909,6915]
===
match
---
name: zip_info [14854,14862]
name: zip_info [14758,14766]
===
match
---
suite [27072,27496]
suite [26976,27400]
===
match
---
name: security_manager [27753,27769]
name: security_manager [27657,27673]
===
match
---
name: self [5199,5203]
name: self [5172,5176]
===
match
---
name: filepath [12540,12548]
name: filepath [12444,12452]
===
match
---
atom [12569,12571]
atom [12473,12475]
===
match
---
tfpdef [26659,26685]
tfpdef [26563,26589]
===
match
---
name: self [10093,10097]
name: self [10066,10070]
===
match
---
operator: = [25667,25668]
operator: = [25571,25572]
===
match
---
operator: , [25834,25835]
operator: , [25738,25739]
===
match
---
trailer [4885,4896]
trailer [4858,4869]
===
match
---
name: dag_folder [19948,19958]
name: dag_folder [19852,19862]
===
match
---
trailer [26244,26249]
trailer [26148,26153]
===
match
---
dotted_name [827,846]
dotted_name [827,846]
===
match
---
and_test [9579,9662]
and_test [9552,9635]
===
match
---
subscriptlist [19966,19991]
subscriptlist [19870,19895]
===
match
---
atom_expr [17479,17490]
atom_expr [17383,17394]
===
match
---
trailer [13500,13518]
trailer [13404,13422]
===
match
---
trailer [15670,15699]
trailer [15574,15603]
===
match
---
atom_expr [17051,17086]
atom_expr [16955,16990]
===
match
---
import_from [24206,24266]
import_from [24110,24170]
===
match
---
trailer [4289,4514]
trailer [4262,4487]
===
match
---
name: subdag [18827,18833]
name: subdag [18731,18737]
===
match
---
annassign [2097,2102]
annassign [2070,2075]
===
match
---
operator: , [22232,22233]
operator: , [22136,22137]
===
match
---
name: found_dags [16745,16755]
name: found_dags [16649,16659]
===
match
---
name: str [10264,10267]
name: str [10237,10240]
===
match
---
simple_stmt [14357,14400]
simple_stmt [14261,14304]
===
match
---
simple_stmt [3482,3553]
simple_stmt [3455,3526]
===
match
---
trailer [19571,19578]
trailer [19475,19482]
===
match
---
operator: , [12250,12251]
operator: , [12154,12155]
===
match
---
simple_stmt [13654,13685]
simple_stmt [13558,13589]
===
match
---
name: getint [5351,5357]
name: getint [5324,5330]
===
match
---
trailer [26553,26567]
trailer [26457,26471]
===
match
---
simple_stmt [26338,26357]
simple_stmt [26242,26261]
===
match
---
name: mod_name [14416,14424]
name: mod_name [14320,14328]
===
match
---
comparison [9579,9597]
comparison [9552,9570]
===
match
---
name: e [15625,15626]
name: e [15529,15530]
===
match
---
simple_stmt [23227,23256]
simple_stmt [23131,23160]
===
match
---
atom_expr [17873,17930]
atom_expr [17777,17834]
===
match
---
name: dags [22949,22953]
name: dags [22853,22857]
===
match
---
trailer [12073,12116]
trailer [11977,12020]
===
match
---
suite [25983,26277]
suite [25887,26181]
===
match
---
operator: = [15941,15942]
operator: = [15845,15846]
===
match
---
trailer [26579,26597]
trailer [26483,26501]
===
match
---
operator: = [12050,12051]
operator: = [11954,11955]
===
match
---
name: append [16756,16762]
name: append [16660,16666]
===
match
---
trailer [13290,13345]
trailer [13194,13249]
===
match
---
trailer [8015,8041]
trailer [7988,8014]
===
match
---
operator: = [22010,22011]
operator: = [21914,21915]
===
match
---
raise_stmt [19060,19257]
raise_stmt [18964,19161]
===
match
---
operator: { [17022,17023]
operator: { [16926,16927]
===
match
---
simple_stmt [17051,17115]
simple_stmt [16955,17019]
===
match
---
not_test [15038,15057]
not_test [14942,14961]
===
match
---
simple_stmt [5154,5190]
simple_stmt [5127,5163]
===
match
---
operator: , [13813,13814]
operator: , [13717,13718]
===
match
---
file_input [788,27898]
file_input [788,27802]
===
match
---
import_from [1473,1507]
import_from [1446,1480]
===
match
---
name: Stats [1467,1472]
name: Stats [1440,1445]
===
match
---
name: serialize_errors [26580,26596]
name: serialize_errors [26484,26500]
===
match
---
name: dag [19167,19170]
name: dag [19071,19074]
===
match
---
simple_stmt [16745,16768]
simple_stmt [16649,16672]
===
match
---
name: found_dags [22038,22048]
name: found_dags [21942,21952]
===
match
---
trailer [10805,10812]
trailer [10709,10716]
===
match
---
name: dag_id [8354,8360]
name: dag_id [8327,8333]
===
match
---
string: 'smart_sensor' [20167,20181]
string: 'smart_sensor' [20071,20085]
===
match
---
name: importlib [827,836]
name: importlib [827,836]
===
match
---
fstring_expr [12813,12827]
fstring_expr [12717,12731]
===
match
---
operator: , [3713,3714]
operator: , [3686,3687]
===
match
---
return_stmt [16218,16229]
return_stmt [16122,16133]
===
match
---
name: file_last_changed_on_disk [16278,16303]
name: file_last_changed_on_disk [16182,16207]
===
match
---
name: get_docs_url [13198,13210]
name: get_docs_url [13102,13114]
===
match
---
trailer [26345,26354]
trailer [26249,26258]
===
match
---
suite [2146,27898]
suite [2119,27802]
===
match
---
operator: = [21888,21889]
operator: = [21792,21793]
===
match
---
arglist [13501,13517]
arglist [13405,13421]
===
match
---
name: permission_name [27041,27056]
name: permission_name [26945,26960]
===
match
---
name: os [11491,11493]
name: os [11395,11397]
===
match
---
name: collect_dags [19912,19924]
name: collect_dags [19816,19828]
===
match
---
argument [9811,9857]
argument [9784,9830]
===
match
---
trailer [16887,16891]
trailer [16791,16795]
===
match
---
simple_stmt [11736,11746]
simple_stmt [11640,11650]
===
match
---
operator: , [21772,21773]
operator: , [21676,21677]
===
match
---
name: current_zip_file [14312,14328]
name: current_zip_file [14216,14232]
===
match
---
atom_expr [13844,13879]
atom_expr [13748,13783]
===
match
---
trailer [13478,13483]
trailer [13382,13387]
===
match
---
annassign [2079,2084]
annassign [2052,2057]
===
match
---
simple_stmt [22293,22328]
simple_stmt [22197,22232]
===
match
---
operator: = [9086,9087]
operator: = [9059,9060]
===
match
---
operator: = [5590,5591]
operator: = [5563,5564]
===
match
---
atom_expr [27362,27387]
atom_expr [27266,27291]
===
match
---
number: 1 [12690,12691]
number: 1 [12594,12595]
===
match
---
atom_expr [8540,8593]
atom_expr [8513,8566]
===
match
---
name: settings [4605,4613]
name: settings [4578,4586]
===
match
---
name: getmtime [11499,11507]
name: getmtime [11403,11411]
===
match
---
param [3692,3744]
param [3665,3717]
===
match
---
expr_stmt [9241,9282]
expr_stmt [9214,9255]
===
match
---
trailer [22223,22232]
trailer [22127,22136]
===
match
---
name: self [26083,26087]
name: self [25987,25991]
===
match
---
trailer [20234,20245]
trailer [20138,20149]
===
match
---
argument [23467,23481]
argument [23371,23385]
===
match
---
if_stmt [8835,8921]
if_stmt [8808,8894]
===
match
---
atom_expr [11849,11877]
atom_expr [11753,11781]
===
match
---
expr_stmt [16956,17034]
expr_stmt [16860,16938]
===
match
---
name: found_dag [10023,10032]
name: found_dag [9996,10005]
===
match
---
param [19934,19939]
param [19838,19843]
===
match
---
name: write_dag [24765,24774]
name: write_dag [24669,24678]
===
match
---
operator: = [4650,4651]
operator: = [4623,4624]
===
match
---
arglist [3603,3649]
arglist [3576,3622]
===
match
---
name: self [6255,6259]
name: self [6228,6232]
===
match
---
name: task_policy [18460,18471]
name: task_policy [18364,18375]
===
match
---
atom_expr [3936,3986]
atom_expr [3909,3959]
===
match
---
atom [22015,22049]
atom [21919,21953]
===
match
---
name: security_manager [27831,27847]
name: security_manager [27735,27751]
===
match
---
string: 'core' [3952,3958]
string: 'core' [3925,3931]
===
match
---
operator: = [12925,12926]
operator: = [12829,12830]
===
match
---
trailer [8510,8518]
trailer [8483,8491]
===
match
---
name: utcnow [21633,21639]
name: utcnow [21537,21543]
===
match
---
name: e [11774,11775]
name: e [11678,11679]
===
match
---
name: name [27309,27313]
name: name [27213,27217]
===
match
---
name: access_control [27882,27896]
name: access_control [27786,27800]
===
match
---
sync_comp_for [21958,21979]
sync_comp_for [21862,21883]
===
match
---
simple_stmt [12702,12765]
simple_stmt [12606,12669]
===
match
---
operator: = [16988,16989]
operator: = [16892,16893]
===
match
---
atom [11316,11318]
atom [11220,11222]
===
match
---
name: self [15720,15724]
name: self [15624,15628]
===
match
---
string: "Serialized DAG %s no longer exists" [8219,8255]
string: "Serialized DAG %s no longer exists" [8192,8228]
===
match
---
fstring [13193,13259]
fstring [13097,13163]
===
match
---
operator: , [3986,3987]
operator: , [3959,3960]
===
match
---
trailer [19019,19027]
trailer [18923,18931]
===
match
---
atom_expr [5034,5053]
atom_expr [5007,5026]
===
match
---
arglist [15173,15252]
arglist [15077,15156]
===
match
---
trailer [23205,23218]
trailer [23109,23122]
===
match
---
operator: , [24799,24800]
operator: , [24703,24704]
===
match
---
trailer [8390,8400]
trailer [8363,8373]
===
match
---
operator: , [21777,21778]
operator: , [21681,21682]
===
match
---
fstring_start: f' [12784,12786]
fstring_start: f' [12688,12690]
===
match
---
name: machinery [837,846]
name: machinery [837,846]
===
match
---
name: filepath [11695,11703]
name: filepath [11599,11607]
===
match
---
name: self [6309,6313]
name: self [6282,6286]
===
match
---
import_from [27677,27739]
import_from [27581,27643]
===
match
---
trailer [26676,26685]
trailer [26580,26589]
===
match
---
trailer [16974,16987]
trailer [16878,16891]
===
match
---
name: dag_id [10012,10018]
name: dag_id [9985,9991]
===
match
---
name: self [14746,14750]
name: self [14650,14654]
===
match
---
atom_expr [4881,4896]
atom_expr [4854,4869]
===
match
---
operator: , [6170,6171]
operator: , [6143,6144]
===
match
---
simple_stmt [25174,25250]
simple_stmt [25078,25154]
===
match
---
string: '__init__' [14630,14640]
string: '__init__' [14534,14544]
===
match
---
name: airflow [24211,24218]
name: airflow [24115,24122]
===
match
---
atom_expr [6318,6327]
atom_expr [6291,6300]
===
match
---
atom_expr [18734,18748]
atom_expr [18638,18652]
===
match
---
operator: , [1039,1040]
operator: , [1039,1040]
===
match
---
trailer [18970,18982]
trailer [18874,18886]
===
match
---
name: Session [26677,26684]
name: Session [26581,26588]
===
match
---
arglist [20167,20201]
arglist [20071,20105]
===
match
---
name: only_if_updated [11552,11567]
name: only_if_updated [11456,11471]
===
match
---
trailer [18345,18347]
trailer [18249,18251]
===
match
---
string: 'USE_SMART_SENSOR' [20183,20201]
string: 'USE_SMART_SENSOR' [20087,20105]
===
match
---
simple_stmt [26377,26383]
simple_stmt [26281,26287]
===
match
---
trailer [14328,14337]
trailer [14232,14241]
===
match
---
trailer [19170,19178]
trailer [19074,19082]
===
match
---
operator: @ [5942,5943]
operator: @ [5915,5916]
===
match
---
fstring_string:          -------------------------------------------------------------------         Number of DAGs:  [23658,23759]
fstring_string:          -------------------------------------------------------------------         Number of DAGs:  [23562,23663]
===
match
---
suite [20288,22248]
suite [20192,22152]
===
match
---
name: dag_id [7803,7809]
name: dag_id [7776,7782]
===
match
---
atom_expr [27597,27664]
atom_expr [27501,27568]
===
match
---
arglist [22201,22246]
arglist [22105,22150]
===
match
---
trailer [20821,20839]
trailer [20725,20743]
===
match
---
operator: = [25314,25315]
operator: = [25218,25219]
===
match
---
trailer [12056,12073]
trailer [11960,11977]
===
match
---
suite [13363,13721]
suite [13267,13625]
===
match
---
operator: = [23238,23239]
operator: = [23142,23143]
===
match
---
atom [25669,25671]
atom [25573,25575]
===
match
---
name: dag_id [8815,8821]
name: dag_id [8788,8794]
===
match
---
operator: { [12801,12802]
operator: { [12705,12706]
===
match
---
name: dag_num [23345,23352]
name: dag_num [23249,23256]
===
match
---
operator: == [16157,16159]
operator: == [16061,16063]
===
match
---
operator: = [7140,7141]
operator: = [7113,7114]
===
match
---
string: 'core' [3520,3526]
string: 'core' [3493,3499]
===
match
---
suite [16866,17115]
suite [16770,17019]
===
match
---
trailer [9848,9856]
trailer [9821,9829]
===
match
---
simple_stmt [8327,8362]
simple_stmt [8300,8335]
===
match
---
strings [12941,13259]
strings [12845,13163]
===
match
---
name: fileloc [15763,15770]
name: fileloc [15667,15674]
===
match
---
atom_expr [12987,13013]
atom_expr [12891,12917]
===
match
---
trailer [7018,7023]
trailer [6991,6996]
===
match
---
name: root_dag_id [9066,9077]
name: root_dag_id [9039,9050]
===
match
---
trailer [5014,5032]
trailer [4987,5005]
===
match
---
name: dag [17074,17077]
name: dag [16978,16981]
===
match
---
simple_stmt [7970,8133]
simple_stmt [7943,8106]
===
match
---
name: dags [19865,19869]
name: dags [19769,19773]
===
match
---
simple_stmt [16218,16230]
simple_stmt [16122,16134]
===
match
---
trailer [13408,13425]
trailer [13312,13329]
===
match
---
trailer [9475,9480]
trailer [9448,9453]
===
match
---
operator: = [6537,6538]
operator: = [6510,6511]
===
match
---
name: bool [4069,4073]
name: bool [4042,4046]
===
match
---
not_test [9107,9118]
not_test [9080,9091]
===
match
---
trailer [17877,17886]
trailer [17781,17790]
===
match
---
trailer [22948,22953]
trailer [22852,22857]
===
match
---
trailer [18459,18471]
trailer [18363,18375]
===
match
---
operator: = [18749,18750]
operator: = [18653,18654]
===
match
---
name: timedelta [7708,7717]
name: timedelta [7681,7690]
===
match
---
trailer [22960,22962]
trailer [22864,22866]
===
match
---
name: dagbag_import_error_tracebacks [5204,5234]
name: dagbag_import_error_tracebacks [5177,5207]
===
match
---
string: "Failed to bag_dag: %s" [16902,16925]
string: "Failed to bag_dag: %s" [16806,16829]
===
match
---
name: path [16202,16206]
name: path [16106,16110]
===
match
---
atom_expr [10724,10745]
atom_expr [10628,10649]
===
match
---
name: conf [1243,1247]
name: conf [1243,1247]
===
match
---
if_stmt [14484,14544]
if_stmt [14388,14448]
===
match
---
operator: , [21904,21905]
operator: , [21808,21809]
===
match
---
trailer [22953,22960]
trailer [22857,22864]
===
match
---
name: dag [27653,27656]
name: dag [27557,27560]
===
match
---
fstring_start: f""" [23530,23534]
fstring_start: f""" [23434,23438]
===
match
---
name: import_errors [15861,15874]
name: import_errors [15765,15778]
===
match
---
trailer [27361,27409]
trailer [27265,27313]
===
match
---
comp_op [14491,14497]
comp_op [14395,14401]
===
match
---
trailer [26150,26197]
trailer [26054,26101]
===
match
---
trailer [23459,23482]
trailer [23363,23386]
===
match
---
name: warning [14671,14678]
name: warning [14575,14582]
===
match
---
trailer [22200,22247]
trailer [22104,22151]
===
match
---
name: utcnow [18339,18345]
name: utcnow [18243,18249]
===
match
---
name: dag_id [27017,27023]
name: dag_id [26921,26927]
===
match
---
trailer [26182,26196]
trailer [26086,26100]
===
match
---
operator: , [23306,23307]
operator: , [23210,23211]
===
match
---
operator: , [18914,18915]
operator: , [18818,18819]
===
match
---
name: exception [17291,17300]
name: exception [17195,17204]
===
match
---
name: log [14667,14670]
name: log [14571,14574]
===
match
---
name: x [22219,22220]
name: x [22123,22124]
===
match
---
param [20047,20113]
param [19951,20017]
===
match
---
name: PermissionView [27144,27158]
name: PermissionView [27048,27062]
===
match
---
name: sys [15340,15343]
name: sys [15244,15247]
===
match
---
trailer [12762,12764]
trailer [12666,12668]
===
match
---
operator: } [17032,17033]
operator: } [16936,16937]
===
match
---
trailer [8353,8361]
trailer [8326,8334]
===
match
---
suite [13755,14128]
suite [13659,14032]
===
match
---
trailer [15906,16009]
trailer [15810,15913]
===
match
---
name: prev_dag [19011,19019]
name: prev_dag [18915,18923]
===
match
---
name: o [23295,23296]
name: o [23199,23200]
===
match
---
name: is_expired [9387,9397]
name: is_expired [9360,9370]
===
match
---
trailer [7880,7898]
trailer [7853,7871]
===
match
---
name: recursive [17915,17924]
name: recursive [17819,17828]
===
match
---
name: self [24997,25001]
name: self [24901,24905]
===
match
---
simple_stmt [24206,24267]
simple_stmt [24110,24171]
===
match
---
trailer [24764,24774]
trailer [24668,24678]
===
match
---
atom_expr [5926,5935]
atom_expr [5899,5908]
===
match
---
operator: , [22050,22051]
operator: , [21954,21955]
===
match
---
atom [16401,16407]
atom [16305,16311]
===
match
---
trailer [21171,21183]
trailer [21075,21087]
===
match
---
funcdef [3656,5812]
funcdef [3629,5785]
===
match
---
name: dags_last_fetched [7881,7898]
name: dags_last_fetched [7854,7871]
===
match
---
atom_expr [4060,4074]
atom_expr [4033,4047]
===
match
---
try_stmt [18518,19903]
try_stmt [18422,19807]
===
match
---
import_from [1875,1916]
import_from [1848,1889]
===
match
---
atom_expr [18751,18762]
atom_expr [18655,18666]
===
match
---
trailer [19230,19238]
trailer [19134,19142]
===
match
---
simple_stmt [22665,22712]
simple_stmt [22569,22616]
===
match
---
atom_expr [23308,23319]
atom_expr [23212,23223]
===
match
---
trailer [12589,12595]
trailer [12493,12499]
===
match
---
atom_expr [13548,13585]
atom_expr [13452,13489]
===
match
---
simple_stmt [10950,11094]
simple_stmt [10854,10998]
===
match
---
for_stmt [18691,18933]
for_stmt [18595,18837]
===
match
---
operator: = [4589,4590]
operator: = [4562,4563]
===
match
---
name: warnings [930,938]
name: warnings [930,938]
===
match
---
simple_stmt [12477,12550]
simple_stmt [12381,12454]
===
match
---
lambdef [22212,22232]
lambdef [22116,22136]
===
match
---
if_stmt [10460,10565]
if_stmt [10433,10469]
===
match
---
operator: = [23981,23982]
operator: = [23885,23886]
===
match
---
number: 0 [16207,16208]
number: 0 [16111,16112]
===
match
---
trailer [13660,13672]
trailer [13564,13576]
===
match
---
name: dag [16334,16337]
name: dag [16238,16241]
===
match
---
name: os [12648,12650]
name: os [12552,12554]
===
match
---
name: self [18957,18961]
name: self [18861,18865]
===
match
---
atom_expr [19031,19042]
atom_expr [18935,18946]
===
match
---
name: bool [3771,3775]
name: bool [3744,3748]
===
match
---
for_stmt [26072,26198]
for_stmt [25976,26102]
===
match
---
name: self [20869,20873]
name: self [20773,20777]
===
match
---
name: self [23071,23075]
name: self [22975,22979]
===
match
---
name: fileloc [17078,17085]
name: fileloc [16982,16989]
===
match
---
name: dag [17891,17894]
name: dag [17795,17798]
===
match
---
name: self [5154,5158]
name: self [5127,5131]
===
match
---
trailer [10211,10215]
trailer [10184,10188]
===
match
---
name: subdags [18501,18508]
name: subdags [18405,18412]
===
match
---
name: timeout [1894,1901]
name: timeout [1867,1874]
===
match
---
trailer [16762,16767]
trailer [16666,16671]
===
match
---
name: read_dags_from_db [20822,20839]
name: read_dags_from_db [20726,20743]
===
match
---
operator: , [14717,14718]
operator: , [14621,14622]
===
match
---
trailer [21227,21397]
trailer [21131,21301]
===
match
---
import_from [4166,4200]
import_from [4139,4173]
===
match
---
trailer [27285,27333]
trailer [27189,27237]
===
match
---
trailer [15143,15278]
trailer [15047,15182]
===
match
---
atom_expr [17425,17439]
atom_expr [17329,17343]
===
match
---
name: self [16883,16887]
name: self [16787,16791]
===
match
---
trailer [23281,23290]
trailer [23185,23194]
===
match
---
expr_stmt [5199,5294]
expr_stmt [5172,5267]
===
match
---
name: exception [16856,16865]
name: exception [16760,16769]
===
match
---
name: DAG_ACTIONS [27060,27071]
name: DAG_ACTIONS [26964,26975]
===
match
---
simple_stmt [4913,4956]
simple_stmt [4886,4929]
===
match
---
atom_expr [14449,14466]
atom_expr [14353,14370]
===
match
---
expr_stmt [12702,12764]
expr_stmt [12606,12668]
===
match
---
name: dag_id [27870,27876]
name: dag_id [27774,27780]
===
match
---
parameters [17948,17983]
parameters [17852,17887]
===
match
---
name: dag [19568,19571]
name: dag [19472,19475]
===
match
---
trailer [23087,23096]
trailer [22991,23000]
===
match
---
trailer [13618,13623]
trailer [13522,13527]
===
match
---
name: session [9079,9086]
name: session [9052,9059]
===
match
---
name: dags [10143,10147]
name: dags [10116,10120]
===
match
---
simple_stmt [4671,4702]
simple_stmt [4644,4675]
===
match
---
name: has_logged [4886,4896]
name: has_logged [4859,4869]
===
match
---
string: """         Given a file path or a folder, this method looks for python modules,         imports them and adds them to the dagbag collection.          Note that if a ``.airflowignore`` file is found while processing         the directory, it will behave much like a ``.gitignore``,         ignoring files that match any of the regex patterns specified         in the file.          **Note**: The patterns in .airflowignore are treated as         un-anchored regexes, not shell-like glob patterns.         """ [20297,20805]
string: """         Given a file path or a folder, this method looks for python modules,         imports them and adds them to the dagbag collection.          Note that if a ``.airflowignore`` file is found while processing         the directory, it will behave much like a ``.gitignore``,         ignoring files that match any of the regex patterns specified         in the file.          **Note**: The patterns in .airflowignore are treated as         un-anchored regexes, not shell-like glob patterns.         """ [20201,20709]
===
match
---
name: spec [13580,13584]
name: spec [13484,13488]
===
match
---
expr_stmt [23027,23058]
expr_stmt [22931,22962]
===
match
---
operator: , [10901,10902]
operator: , [10805,10806]
===
match
---
atom_expr [20817,20839]
atom_expr [20721,20743]
===
match
---
trailer [25320,25356]
trailer [25224,25260]
===
match
---
param [6309,6313]
param [6282,6286]
===
match
---
atom_expr [4634,4649]
atom_expr [4607,4622]
===
match
---
funcdef [22253,23097]
funcdef [22157,23001]
===
match
---
operator: = [12159,12160]
operator: = [12063,12064]
===
match
---
trailer [19810,19817]
trailer [19714,19721]
===
match
---
name: session [23954,23961]
name: session [23858,23865]
===
match
---
name: dags [8294,8298]
name: dags [8267,8271]
===
match
---
trailer [25910,25914]
trailer [25814,25818]
===
match
---
atom_expr [8805,8822]
atom_expr [8778,8795]
===
match
---
name: path [14370,14374]
name: path [14274,14278]
===
match
---
name: splitext [14440,14448]
name: splitext [14344,14352]
===
match
---
suite [15627,16097]
suite [15531,16001]
===
match
---
name: fileloc [19035,19042]
name: fileloc [18939,18946]
===
match
---
name: AirflowClusterPolicyViolation [17243,17272]
name: AirflowClusterPolicyViolation [17147,17176]
===
match
---
operator: , [4499,4500]
operator: , [4472,4473]
===
match
---
name: _serialize_dag_capturing_errors [26151,26182]
name: _serialize_dag_capturing_errors [26055,26086]
===
match
---
name: self [12405,12409]
name: self [12309,12313]
===
match
---
string: """Prints a report around DagBag loading stats""" [23135,23184]
string: """Prints a report around DagBag loading stats""" [23039,23088]
===
match
---
return_stmt [25266,25359]
return_stmt [25170,25263]
===
match
---
name: utils [1486,1491]
name: utils [1459,1464]
===
match
---
operator: = [10625,10626]
operator: = [10529,10530]
===
match
---
simple_stmt [9763,9895]
simple_stmt [9736,9868]
===
match
---
operator: , [21284,21285]
operator: , [21188,21189]
===
match
---
name: debug [12590,12595]
name: debug [12494,12499]
===
match
---
operator: , [4808,4809]
operator: , [4781,4782]
===
match
---
operator: , [6510,6511]
operator: , [6483,6484]
===
match
---
string: 'dagbag_import_error_traceback_depth' [5366,5403]
string: 'dagbag_import_error_traceback_depth' [5339,5376]
===
match
---
trailer [16930,16938]
trailer [16834,16842]
===
match
---
atom_expr [10692,10705]
atom_expr [10596,10609]
===
match
---
name: airflow [1214,1221]
name: airflow [1214,1221]
===
match
---
suite [14205,16230]
suite [14109,16134]
===
match
---
trailer [21704,22073]
trailer [21608,21977]
===
match
---
param [10903,10924]
param [10807,10828]
===
match
---
operator: , [17971,17972]
operator: , [17875,17876]
===
match
---
name: found_dag [10044,10053]
name: found_dag [10017,10026]
===
match
---
name: dags_last_fetched [8336,8353]
name: dags_last_fetched [8309,8326]
===
match
---
simple_stmt [18487,18509]
simple_stmt [18391,18413]
===
match
---
operator: { [12969,12970]
operator: { [12873,12874]
===
match
---
name: list [6445,6449]
name: list [6418,6422]
===
match
---
trailer [10812,10814]
trailer [10716,10718]
===
match
---
trailer [9793,9894]
trailer [9766,9867]
===
match
---
name: current_zip_file [14884,14900]
name: current_zip_file [14788,14804]
===
match
---
atom_expr [12853,12864]
atom_expr [12757,12768]
===
match
---
operator: , [19999,20000]
operator: , [19903,19904]
===
match
---
trailer [16978,16986]
trailer [16882,16890]
===
match
---
name: top_level_dags [16526,16540]
name: top_level_dags [16430,16444]
===
match
---
name: serialized_dag [10356,10370]
name: serialized_dag [10329,10343]
===
match
---
trailer [27865,27897]
trailer [27769,27801]
===
match
---
trailer [10855,10864]
trailer [10759,10768]
===
match
---
name: self [19860,19864]
name: self [19764,19768]
===
match
---
import_name [803,819]
import_name [803,819]
===
match
---
name: timeout_msg [12913,12924]
name: timeout_msg [12817,12828]
===
match
---
trailer [12664,12693]
trailer [12568,12597]
===
match
---
trailer [21639,21641]
trailer [21543,21545]
===
match
---
argument [4487,4499]
argument [4460,4472]
===
match
---
operator: = [5054,5055]
operator: = [5027,5028]
===
match
---
simple_stmt [16652,16677]
simple_stmt [16556,16581]
===
match
---
trailer [5357,5404]
trailer [5330,5377]
===
match
---
except_clause [25081,25104]
except_clause [24985,25008]
===
match
---
if_stmt [1918,1955]
if_stmt [1891,1928]
===
match
---
operator: - [15942,15943]
operator: - [15846,15847]
===
match
---
trailer [20967,20978]
trailer [20871,20882]
===
match
---
name: self [23948,23952]
name: self [23852,23856]
===
match
---
operator: , [12017,12018]
operator: , [11921,11922]
===
match
---
simple_stmt [24339,24545]
simple_stmt [24243,24449]
===
match
---
name: e [22124,22125]
name: e [22028,22029]
===
match
---
argument [5526,5567]
argument [5499,5540]
===
match
---
name: filepath [21521,21529]
name: filepath [21425,21433]
===
match
---
operator: , [5178,5179]
operator: , [5151,5152]
===
match
---
if_stmt [20814,20860]
if_stmt [20718,20764]
===
match
---
name: bool [3929,3933]
name: bool [3902,3906]
===
match
---
name: filepath [12612,12620]
name: filepath [12516,12524]
===
match
---
simple_stmt [4833,4873]
simple_stmt [4806,4846]
===
match
---
operator: } [22919,22920]
operator: } [22823,22824]
===
match
---
name: self [4776,4780]
name: self [4749,4753]
===
match
---
suite [15058,15279]
suite [14962,15183]
===
match
---
simple_stmt [879,890]
simple_stmt [879,890]
===
match
---
name: fileloc [15875,15882]
name: fileloc [15779,15786]
===
match
---
name: root_dag_id [9254,9265]
name: root_dag_id [9227,9238]
===
match
---
if_stmt [9994,10187]
if_stmt [9967,10160]
===
match
---
name: FileLoadStat [21692,21704]
name: FileLoadStat [21596,21608]
===
match
---
operator: , [16925,16926]
operator: , [16829,16830]
===
match
---
suite [26317,26383]
suite [26221,26287]
===
match
---
simple_stmt [12773,12829]
simple_stmt [12677,12733]
===
match
---
string: """Actual implementation of bagging a dag.          The only purpose of this is to avoid exposing ``recursive`` in ``bag_dag()``,         intended to only be used by the ``_bag_dag()`` implementation.         """ [17993,18205]
string: """Actual implementation of bagging a dag.          The only purpose of this is to avoid exposing ``recursive`` in ``bag_dag()``,         intended to only be used by the ``_bag_dag()`` implementation.         """ [17897,18109]
===
match
---
trailer [18390,18401]
trailer [18294,18305]
===
match
---
operator: = [18925,18926]
operator: = [18829,18830]
===
match
---
trailer [13776,13780]
trailer [13680,13684]
===
match
---
simple_stmt [23998,24049]
simple_stmt [23902,23953]
===
match
---
operator: , [3729,3730]
operator: , [3702,3703]
===
match
---
name: self [4634,4638]
name: self [4607,4611]
===
match
---
name: fileloc [17483,17490]
name: fileloc [17387,17394]
===
match
---
trailer [13790,13824]
trailer [13694,13728]
===
match
---
expr_stmt [22908,22920]
expr_stmt [22812,22824]
===
match
---
name: Dict [4800,4804]
name: Dict [4773,4777]
===
match
---
name: conf [5237,5241]
name: conf [5210,5214]
===
match
---
atom_expr [25231,25248]
atom_expr [25135,25152]
===
match
---
name: correct_maybe_zipped [9820,9840]
name: correct_maybe_zipped [9793,9813]
===
match
---
atom_expr [23408,23418]
atom_expr [23312,23322]
===
match
---
expr_stmt [4527,4568]
expr_stmt [4500,4541]
===
match
---
parameters [6505,6544]
parameters [6478,6517]
===
match
---
name: dagbag_stats [22179,22191]
name: dagbag_stats [22083,22095]
===
match
---
simple_stmt [13462,13519]
simple_stmt [13366,13423]
===
match
---
operator: = [23050,23051]
operator: = [22954,22955]
===
match
---
name: dags [19826,19830]
name: dags [19730,19734]
===
match
---
name: MAX_DB_RETRIES [25856,25870]
name: MAX_DB_RETRIES [25760,25774]
===
match
---
not_test [12401,12420]
not_test [12305,12324]
===
match
---
suite [19043,19258]
suite [18947,19162]
===
match
---
trailer [19869,19884]
trailer [19773,19788]
===
match
---
trailer [7177,7182]
trailer [7150,7155]
===
match
---
name: settings [24841,24849]
name: settings [24745,24753]
===
match
---
trailer [4226,4228]
trailer [4199,4201]
===
match
---
name: root_dag_id [8869,8880]
name: root_dag_id [8842,8853]
===
match
---
expr_stmt [5777,5811]
expr_stmt [5750,5784]
===
match
---
trailer [11498,11507]
trailer [11402,11411]
===
match
---
atom_expr [20230,20280]
atom_expr [20134,20184]
===
match
---
expr_stmt [13535,13585]
expr_stmt [13439,13489]
===
match
---
name: property [5943,5951]
name: property [5916,5924]
===
match
---
operator: , [10441,10442]
operator: , [10414,10415]
===
match
---
name: subdags [22998,23005]
name: subdags [22902,22909]
===
match
---
name: infolist [14329,14337]
name: infolist [14233,14241]
===
match
---
trailer [17055,17073]
trailer [16959,16977]
===
match
---
name: path [14435,14439]
name: path [14339,14343]
===
match
---
simple_stmt [18783,18807]
simple_stmt [18687,18711]
===
match
---
return_stmt [8429,8440]
return_stmt [8402,8413]
===
match
---
name: path_hash [12802,12811]
name: path_hash [12706,12715]
===
match
---
name: dagbag_import_error_traceback_depth [5308,5343]
name: dagbag_import_error_traceback_depth [5281,5316]
===
match
---
atom_expr [9304,9324]
atom_expr [9277,9297]
===
match
---
name: str [21168,21171]
name: str [21072,21075]
===
match
---
param [26648,26653]
param [26552,26557]
===
match
---
name: utils [1620,1625]
name: utils [1593,1598]
===
match
---
atom_expr [10838,10848]
atom_expr [10742,10752]
===
match
---
name: Session [1141,1148]
name: Session [1141,1148]
===
match
---
name: self [7096,7100]
name: self [7069,7073]
===
match
---
atom_expr [8838,8851]
atom_expr [8811,8824]
===
match
---
name: get_dag [6498,6505]
name: get_dag [6471,6478]
===
match
---
simple_stmt [8382,8409]
simple_stmt [8355,8382]
===
match
---
simple_stmt [15490,15541]
simple_stmt [15394,15445]
===
match
---
name: dag_id [8766,8772]
name: dag_id [8739,8745]
===
match
---
trailer [9557,9559]
trailer [9530,9532]
===
match
---
string: "Found __init__.%s at root of %s" [14679,14712]
string: "Found __init__.%s at root of %s" [14583,14616]
===
match
---
atom_expr [21943,21957]
atom_expr [21847,21861]
===
match
---
name: fileloc [16558,16565]
name: fileloc [16462,16469]
===
match
---
atom_expr [8883,8904]
atom_expr [8856,8877]
===
match
---
name: dag_was_updated [24728,24743]
name: dag_was_updated [24632,24647]
===
match
---
trailer [23360,23368]
trailer [23264,23272]
===
match
---
expr_stmt [18783,18806]
expr_stmt [18687,18710]
===
match
---
del_stmt [10165,10186]
del_stmt [10138,10159]
===
match
---
trailer [4675,4680]
trailer [4648,4653]
===
match
---
name: duration [2048,2056]
name: duration [2021,2029]
===
match
---
operator: = [19292,19293]
operator: = [19196,19197]
===
match
---
name: self [8202,8206]
name: self [8175,8179]
===
match
---
operator: = [23499,23500]
operator: = [23403,23404]
===
match
---
simple_stmt [8607,8636]
simple_stmt [8580,8609]
===
match
---
trailer [5430,5611]
trailer [5403,5584]
===
match
---
simple_stmt [8715,8726]
simple_stmt [8688,8699]
===
match
---
trailer [6464,6466]
trailer [6437,6439]
===
match
---
if_stmt [13841,14128]
if_stmt [13745,14032]
===
match
---
name: self [15130,15134]
name: self [15034,15038]
===
match
---
atom [10022,10068]
atom [9995,10041]
===
match
---
argument [21531,21562]
argument [21435,21466]
===
match
---
name: session [8577,8584]
name: session [8550,8557]
===
match
---
name: Exception [22111,22120]
name: Exception [22015,22024]
===
match
---
fstring_start: f" [13193,13195]
fstring_start: f" [13097,13099]
===
match
---
atom_expr [16883,16939]
atom_expr [16787,16843]
===
match
---
trailer [11793,11797]
trailer [11697,11701]
===
match
---
name: dag [17569,17572]
name: dag [17473,17476]
===
match
---
name: self [6450,6454]
name: self [6423,6427]
===
match
---
name: sd_last_updated_datetime [8461,8485]
name: sd_last_updated_datetime [8434,8458]
===
match
---
tfpdef [3918,3933]
tfpdef [3891,3906]
===
match
---
trailer [18315,18327]
trailer [18219,18231]
===
match
---
atom_expr [18451,18477]
atom_expr [18355,18381]
===
match
---
name: AirflowDagDuplicatedIdException [19389,19420]
name: AirflowDagDuplicatedIdException [19293,19324]
===
match
---
del_stmt [12878,12903]
del_stmt [12782,12807]
===
match
---
simple_stmt [23393,23435]
simple_stmt [23297,23339]
===
match
---
dictorsetmaker [9501,9662]
dictorsetmaker [9474,9635]
===
match
---
operator: = [18801,18802]
operator: = [18705,18706]
===
match
---
operator: = [19125,19126]
operator: = [19029,19030]
===
match
---
param [26654,26658]
param [26558,26562]
===
match
---
name: retries [1774,1781]
name: retries [1747,1754]
===
match
---
expr_stmt [21134,21184]
expr_stmt [21038,21088]
===
match
---
name: Dict [5170,5174]
name: Dict [5143,5147]
===
match
---
name: include_examples [5479,5495]
name: include_examples [5452,5468]
===
match
---
expr_stmt [10682,10715]
expr_stmt [10586,10619]
===
match
---
name: dags [10098,10102]
name: dags [10071,10075]
===
match
---
trailer [13131,13176]
trailer [13035,13080]
===
match
---
operator: > [7874,7875]
operator: > [7847,7848]
===
match
---
name: include_examples [20047,20063]
name: include_examples [19951,19967]
===
match
---
simple_stmt [22174,22248]
simple_stmt [22078,22152]
===
match
---
trailer [27016,27024]
trailer [26920,26928]
===
match
---
funcdef [10229,10865]
funcdef [10202,10769]
===
match
---
testlist_comp [16402,16406]
testlist_comp [16306,16310]
===
match
---
trailer [9840,9857]
trailer [9813,9830]
===
match
---
trailer [18875,18884]
trailer [18779,18788]
===
match
---
trailer [26256,26258]
trailer [26160,26162]
===
match
---
name: task_num [23797,23805]
name: task_num [23701,23709]
===
match
---
operator: = [10934,10935]
operator: = [10838,10839]
===
match
---
simple_stmt [5848,5907]
simple_stmt [5821,5880]
===
match
---
operator: == [9637,9639]
operator: == [9610,9612]
===
match
---
atom_expr [4605,4625]
atom_expr [4578,4598]
===
match
---
atom_expr [12126,12158]
atom_expr [12030,12062]
===
match
---
name: self [25316,25320]
name: self [25220,25224]
===
match
---
testlist_comp [16513,16521]
testlist_comp [16417,16425]
===
match
---
trailer [3872,3908]
trailer [3845,3881]
===
match
---
trailer [4613,4625]
trailer [4586,4598]
===
match
---
operator: , [19969,19970]
operator: , [19873,19874]
===
match
---
try_stmt [13359,14128]
try_stmt [13263,14032]
===
match
---
simple_stmt [26761,26826]
simple_stmt [26665,26730]
===
match
---
tfpdef [10256,10267]
tfpdef [10229,10240]
===
match
---
atom_expr [23027,23049]
atom_expr [22931,22953]
===
match
---
suite [13880,14048]
suite [13784,13952]
===
match
---
operator: , [5567,5568]
operator: , [5540,5541]
===
match
---
import_from [1209,1247]
import_from [1209,1247]
===
match
---
trailer [4804,4819]
trailer [4777,4792]
===
match
---
simple_stmt [23264,23337]
simple_stmt [23168,23241]
===
match
---
funcdef [5956,6278]
funcdef [5929,6251]
===
match
---
operator: , [21251,21252]
operator: , [21155,21156]
===
match
---
name: mods [15561,15565]
name: mods [15465,15469]
===
match
---
testlist_comp [25275,25357]
testlist_comp [25179,25261]
===
match
---
trailer [10764,10782]
trailer [10668,10686]
===
match
---
atom_expr [23451,23482]
atom_expr [23355,23386]
===
match
---
trailer [6259,6277]
trailer [6232,6250]
===
match
---
trailer [12655,12664]
trailer [12559,12568]
===
match
---
simple_stmt [2048,2068]
simple_stmt [2021,2041]
===
match
---
name: session [9087,9094]
name: session [9060,9067]
===
match
---
atom_expr [18214,18230]
atom_expr [18118,18134]
===
match
---
name: dag_id [10787,10793]
name: dag_id [10691,10697]
===
match
---
name: filename [14390,14398]
name: filename [14294,14302]
===
match
---
suite [19831,19885]
suite [19735,19789]
===
match
---
name: min_serialized_dag_fetch_secs [7676,7705]
name: min_serialized_dag_fetch_secs [7649,7678]
===
match
---
operator: = [4897,4898]
operator: = [4870,4871]
===
match
---
simple_stmt [14662,14729]
simple_stmt [14566,14633]
===
match
---
name: timeout_msg [13333,13344]
name: timeout_msg [13237,13248]
===
match
---
atom_expr [22194,22247]
atom_expr [22098,22151]
===
match
---
atom [22918,22920]
atom [22822,22824]
===
match
---
simple_stmt [14535,14544]
simple_stmt [14439,14448]
===
match
---
decorated [6283,6468]
decorated [6256,6441]
===
match
---
atom_expr [18871,18932]
atom_expr [18775,18836]
===
match
---
param [17563,17568]
param [17467,17472]
===
match
---
trailer [5174,5184]
trailer [5147,5157]
===
match
---
atom [7785,7952]
atom [7758,7925]
===
match
---
trailer [15456,15469]
trailer [15360,15373]
===
match
---
atom_expr [19126,19136]
atom_expr [19030,19040]
===
match
---
trailer [25920,25962]
trailer [25824,25866]
===
match
---
name: airflow [22341,22348]
name: airflow [22245,22252]
===
match
---
name: limit [15936,15941]
name: limit [15840,15845]
===
match
---
atom_expr [21456,21473]
atom_expr [21360,21377]
===
match
---
arglist [25193,25248]
arglist [25097,25152]
===
match
---
name: self [11898,11902]
name: self [11802,11806]
===
match
---
atom_expr [3506,3552]
atom_expr [3479,3525]
===
match
---
operator: = [18905,18906]
operator: = [18809,18810]
===
match
---
expr_stmt [10621,10634]
expr_stmt [10525,10538]
===
match
---
atom_expr [3778,3818]
atom_expr [3751,3791]
===
match
---
trailer [16432,16441]
trailer [16336,16345]
===
match
---
name: self [6506,6510]
name: self [6479,6483]
===
match
---
operator: , [1678,1679]
operator: , [1651,1652]
===
match
---
suite [22442,23097]
suite [22346,23001]
===
match
---
simple_stmt [18275,18304]
simple_stmt [18179,18208]
===
match
---
fstring_expr [12801,12812]
fstring_expr [12705,12716]
===
match
---
trailer [16960,16974]
trailer [16864,16878]
===
match
---
import_from [1698,1754]
import_from [1671,1727]
===
match
---
funcdef [12218,14146]
funcdef [12122,14050]
===
match
---
name: session [7141,7148]
name: session [7114,7121]
===
match
---
trailer [3793,3818]
trailer [3766,3791]
===
match
---
name: filename [14458,14466]
name: filename [14362,14370]
===
match
---
name: dag_folder [21172,21182]
name: dag_folder [21076,21086]
===
match
---
trailer [11285,11295]
trailer [11189,11199]
===
match
---
name: sqla [26792,26796]
name: sqla [26696,26700]
===
match
---
name: self [14662,14666]
name: self [14566,14570]
===
match
---
operator: = [19993,19994]
operator: = [19897,19898]
===
match
---
name: DAG [24194,24197]
name: DAG [24098,24101]
===
match
---
suite [10941,12213]
suite [10845,12117]
===
match
---
name: log [13777,13780]
name: log [13681,13684]
===
match
---
atom_expr [5777,5795]
atom_expr [5750,5768]
===
match
---
trailer [27382,27387]
trailer [27286,27291]
===
match
---
decorator [5942,5952]
decorator [5915,5925]
===
match
---
atom_expr [14090,14118]
atom_expr [13994,14022]
===
match
---
name: airflow [1880,1887]
name: airflow [1853,1860]
===
match
---
expr_stmt [16784,16809]
expr_stmt [16688,16713]
===
match
---
param [26659,26692]
param [26563,26596]
===
match
---
operator: = [21145,21146]
operator: = [21049,21050]
===
match
---
name: utils [1888,1893]
name: utils [1861,1866]
===
match
---
name: self [20963,20967]
name: self [20867,20871]
===
match
---
name: is_subdag [16618,16627]
name: is_subdag [16522,16531]
===
match
---
name: dag [8883,8886]
name: dag [8856,8859]
===
match
---
name: self [3678,3682]
name: self [3651,3655]
===
match
---
simple_stmt [1875,1917]
simple_stmt [1848,1890]
===
match
---
suite [14641,14729]
suite [14545,14633]
===
match
---
name: fileloc [19020,19027]
name: fileloc [18924,18931]
===
match
---
comparison [11643,11704]
comparison [11547,11608]
===
match
---
simple_stmt [5777,5812]
simple_stmt [5750,5785]
===
match
---
import_name [788,802]
import_name [788,802]
===
match
---
operator: = [10707,10708]
operator: = [10611,10612]
===
match
---
classdef [1957,2117]
classdef [1930,2090]
===
match
---
operator: == [27388,27390]
operator: == [27292,27294]
===
match
---
operator: = [5796,5797]
operator: = [5769,5770]
===
match
---
name: pathlib [1947,1954]
name: pathlib [1920,1927]
===
match
---
operator: = [4697,4698]
operator: = [4670,4671]
===
match
---
trailer [19218,19230]
trailer [19122,19134]
===
match
---
simple_stmt [13772,13825]
simple_stmt [13676,13729]
===
match
---
comparison [16145,16168]
comparison [16049,16072]
===
match
---
name: sys [15377,15380]
name: sys [15281,15284]
===
match
---
param [16256,16261]
param [16160,16165]
===
match
---
simple_stmt [17528,17546]
simple_stmt [17432,17450]
===
match
---
name: stats [23460,23465]
name: stats [23364,23369]
===
match
---
return_stmt [27484,27495]
return_stmt [27388,27399]
===
match
---
operator: } [13257,13258]
operator: } [13161,13162]
===
match
---
simple_stmt [9132,9161]
simple_stmt [9105,9134]
===
match
---
name: str [2040,2043]
name: str [2013,2016]
===
match
---
name: size [5821,5825]
name: size [5794,5798]
===
match
---
trailer [27373,27382]
trailer [27277,27286]
===
match
---
return_stmt [23893,23906]
return_stmt [23797,23810]
===
match
---
funcdef [24276,25360]
funcdef [24180,25264]
===
match
---
trailer [27536,27551]
trailer [27440,27455]
===
match
---
dotted_name [1830,1851]
dotted_name [1803,1824]
===
match
---
simple_stmt [26703,26753]
simple_stmt [26607,26657]
===
match
---
not_test [27092,27462]
not_test [26996,27366]
===
match
---
expr_stmt [13602,13637]
expr_stmt [13506,13541]
===
match
---
name: Exception [25147,25156]
name: Exception [25051,25060]
===
match
---
simple_stmt [10682,10716]
simple_stmt [10586,10620]
===
match
---
trailer [27575,27582]
trailer [27479,27486]
===
match
---
name: zip_info [14783,14791]
name: zip_info [14687,14695]
===
match
---
operator: , [19985,19986]
operator: , [19889,19890]
===
match
---
operator: , [14871,14872]
operator: , [14775,14776]
===
match
---
simple_stmt [20297,20806]
simple_stmt [20201,20710]
===
match
---
parameters [24311,24325]
parameters [24215,24229]
===
match
---
name: self [17563,17567]
name: self [17467,17471]
===
match
---
name: limit [25309,25314]
name: limit [25213,25218]
===
match
---
simple_stmt [26127,26198]
simple_stmt [26031,26102]
===
match
---
name: sum [21939,21942]
name: sum [21843,21846]
===
match
---
atom_expr [4210,4228]
atom_expr [4183,4201]
===
match
---
operator: , [12610,12611]
operator: , [12514,12515]
===
match
---
parameters [3668,4124]
parameters [3641,4097]
===
match
---
atom_expr [21658,22091]
atom_expr [21562,21995]
===
match
---
operator: = [26267,26268]
operator: = [26171,26172]
===
match
---
operator: = [19208,19209]
operator: = [19112,19113]
===
match
---
trailer [18500,18508]
trailer [18404,18412]
===
match
---
operator: = [13387,13388]
operator: = [13291,13292]
===
match
---
name: is_subdag [8842,8851]
name: is_subdag [8815,8824]
===
match
---
name: mod_name [13501,13509]
name: mod_name [13405,13413]
===
match
---
return_stmt [6438,6467]
return_stmt [6411,6440]
===
match
---
atom_expr [15340,15351]
atom_expr [15244,15255]
===
match
---
trailer [22459,22463]
trailer [22363,22367]
===
match
---
name: self [17873,17877]
name: self [17777,17781]
===
match
---
operator: , [4469,4470]
operator: , [4442,4443]
===
match
---
simple_stmt [5413,5612]
simple_stmt [5386,5585]
===
match
---
arglist [21730,22051]
arglist [21634,21955]
===
match
---
name: dags_last_fetched [10765,10782]
name: dags_last_fetched [10669,10686]
===
match
---
name: mod_name [12841,12849]
name: mod_name [12745,12753]
===
match
---
operator: , [3800,3801]
operator: , [3773,3774]
===
match
---
name: self [18871,18875]
name: self [18775,18779]
===
match
---
suite [25607,26599]
suite [25511,26503]
===
match
---
atom_expr [8386,8408]
atom_expr [8359,8381]
===
match
---
param [4091,4118]
param [4064,4091]
===
match
---
atom_expr [7014,7023]
atom_expr [6987,6996]
===
match
---
trailer [7717,7769]
trailer [7690,7742]
===
match
---
trailer [14853,14901]
trailer [14757,14805]
===
match
---
suite [19422,19903]
suite [19326,19807]
===
match
---
trailer [22161,22164]
trailer [22065,22068]
===
match
---
name: fileloc [15648,15655]
name: fileloc [15552,15559]
===
match
---
import_as_name [26804,26825]
import_as_name [26708,26729]
===
match
---
name: is_subdag [18834,18843]
name: is_subdag [18738,18747]
===
match
---
name: filepath [21735,21743]
name: filepath [21639,21647]
===
match
---
name: file [21730,21734]
name: file [21634,21638]
===
match
---
trailer [26092,26099]
trailer [25996,26003]
===
match
---
trailer [10782,10794]
trailer [10686,10698]
===
match
---
name: isinstance [16454,16464]
name: isinstance [16358,16368]
===
match
---
comparison [11247,11263]
comparison [11151,11167]
===
match
---
operator: , [5600,5601]
operator: , [5573,5574]
===
match
---
arglist [12009,12028]
arglist [11913,11932]
===
match
---
name: file_parse_start_dttm [21432,21453]
name: file_parse_start_dttm [21336,21357]
===
match
---
operator: , [15233,15234]
operator: , [15137,15138]
===
match
---
operator: = [3737,3738]
operator: = [3710,3711]
===
match
---
name: fileloc [9849,9856]
name: fileloc [9822,9829]
===
match
---
name: subdags [10661,10668]
name: subdags [10565,10572]
===
match
---
arglist [12307,12326]
arglist [12211,12230]
===
match
---
suite [1935,1955]
suite [1908,1928]
===
match
---
atom_expr [13389,13445]
atom_expr [13293,13349]
===
match
---
simple_stmt [15083,15106]
simple_stmt [14987,15010]
===
match
---
parameters [14177,14204]
parameters [14081,14108]
===
match
---
param [3918,3987]
param [3891,3960]
===
match
---
name: filepath [14184,14192]
name: filepath [14088,14096]
===
match
---
name: dag_id [8562,8568]
name: dag_id [8535,8541]
===
match
---
trailer [19965,19992]
trailer [19869,19896]
===
match
---
trailer [12667,12672]
trailer [12571,12576]
===
match
---
trailer [25601,25605]
trailer [25505,25509]
===
match
---
name: dags [7178,7182]
name: dags [7151,7155]
===
match
---
trailer [21743,21751]
trailer [21647,21655]
===
match
---
trailer [16064,16078]
trailer [15968,15982]
===
match
---
atom_expr [13985,14025]
atom_expr [13889,13929]
===
match
---
testlist_comp [16401,16472]
testlist_comp [16305,16376]
===
match
---
operator: , [22206,22207]
operator: , [22110,22111]
===
match
---
argument [21265,21284]
argument [21169,21188]
===
match
---
import_name [879,889]
import_name [879,889]
===
match
---
name: headers [23467,23474]
name: headers [23371,23378]
===
match
---
name: safe_mode [12317,12326]
name: safe_mode [12221,12230]
===
match
---
trailer [8623,8627]
trailer [8596,8600]
===
match
---
atom_expr [27286,27313]
atom_expr [27190,27217]
===
match
---
trailer [27308,27313]
trailer [27212,27217]
===
match
---
trailer [11604,11622]
trailer [11508,11526]
===
match
---
operator: = [25596,25597]
operator: = [25500,25501]
===
match
---
name: utcnow [7865,7871]
name: utcnow [7838,7844]
===
match
---
trailer [22178,22191]
trailer [22082,22095]
===
match
---
expr_stmt [8799,8822]
expr_stmt [8772,8795]
===
match
---
name: subdag [19870,19876]
name: subdag [19774,19780]
===
match
---
name: collect_dags_from_db [22257,22277]
name: collect_dags_from_db [22161,22181]
===
match
---
testlist_comp [14499,14512]
testlist_comp [14403,14416]
===
match
---
expr_stmt [16614,16635]
expr_stmt [16518,16539]
===
match
---
operator: , [21529,21530]
operator: , [21433,21434]
===
match
---
operator: = [14219,14220]
operator: = [14123,14124]
===
match
---
trailer [12678,12688]
trailer [12582,12592]
===
match
---
trailer [14252,14262]
trailer [14156,14166]
===
match
---
atom_expr [4853,4867]
atom_expr [4826,4840]
===
match
---
name: getint [3596,3602]
name: getint [3569,3575]
===
match
---
if_stmt [15792,16097]
if_stmt [15696,16001]
===
match
---
operator: , [17953,17954]
operator: , [17857,17858]
===
match
---
operator: = [10795,10796]
operator: = [10699,10700]
===
match
---
simple_stmt [1180,1209]
simple_stmt [1180,1209]
===
match
---
name: fileloc [18741,18748]
name: fileloc [18645,18652]
===
match
---
trailer [13557,13562]
trailer [13461,13466]
===
match
---
testlist_star_expr [12630,12645]
testlist_star_expr [12534,12549]
===
match
---
expr_stmt [15490,15540]
expr_stmt [15394,15444]
===
match
---
simple_stmt [8285,8307]
simple_stmt [8258,8280]
===
match
---
atom_expr [5010,5032]
atom_expr [4983,5005]
===
match
---
name: dag [22937,22940]
name: dag [22841,22844]
===
match
---
name: seconds [7718,7725]
name: seconds [7691,7698]
===
match
---
trailer [17365,17373]
trailer [17269,17277]
===
match
---
name: settings [18451,18459]
name: settings [18355,18363]
===
match
---
simple_stmt [13901,14048]
simple_stmt [13805,13952]
===
match
---
simple_stmt [23492,23885]
simple_stmt [23396,23789]
===
match
---
simple_stmt [15441,15470]
simple_stmt [15345,15374]
===
match
---
subscriptlist [4805,4818]
subscriptlist [4778,4791]
===
match
---
name: safe_mode [12262,12271]
name: safe_mode [12166,12175]
===
match
---
param [3753,3819]
param [3726,3792]
===
match
---
name: bool [5991,5995]
name: bool [5964,5968]
===
match
---
name: _process_modules [12057,12073]
name: _process_modules [11961,11977]
===
match
---
except_clause [19355,19421]
except_clause [19259,19325]
===
match
---
atom_expr [10797,10814]
atom_expr [10701,10718]
===
match
---
trailer [8627,8635]
trailer [8600,8608]
===
match
---
operator: , [14882,14883]
operator: , [14786,14787]
===
match
---
name: dag [6759,6762]
name: dag [6732,6735]
===
match
---
name: dag [18885,18888]
name: dag [18789,18792]
===
match
---
name: import_errors [16065,16078]
name: import_errors [15969,15982]
===
match
---
trailer [22695,22709]
trailer [22599,22613]
===
match
---
trailer [14750,14754]
trailer [14654,14658]
===
match
---
expr_stmt [16554,16580]
expr_stmt [16458,16484]
===
match
---
name: Session [6529,6536]
name: Session [6502,6509]
===
match
---
operator: , [4117,4118]
operator: , [4090,4091]
===
match
---
name: stats [1454,1459]
name: stats [1427,1432]
===
match
---
name: dag_folder [21134,21144]
name: dag_folder [21038,21048]
===
match
---
trailer [17073,17086]
trailer [16977,16990]
===
match
---
trailer [8335,8353]
trailer [8308,8326]
===
match
---
string: 'core' [20088,20094]
string: 'core' [19992,19998]
===
match
---
name: path [16149,16153]
name: path [16053,16057]
===
match
---
if_stmt [27089,27496]
if_stmt [26993,27400]
===
match
---
atom_expr [24997,25042]
atom_expr [24901,24946]
===
match
---
name: serialized_dag [22356,22370]
name: serialized_dag [22260,22274]
===
match
---
trailer [13398,13408]
trailer [13302,13312]
===
match
---
trailer [10728,10733]
trailer [10632,10637]
===
match
---
or_test [27533,27583]
or_test [27437,27487]
===
match
---
name: subdags [18487,18494]
name: subdags [18391,18398]
===
match
---
trailer [21892,21904]
trailer [21796,21808]
===
match
---
trailer [13989,14025]
trailer [13893,13929]
===
match
---
atom_expr [7997,8132]
atom_expr [7970,8105]
===
match
---
simple_stmt [11891,11948]
simple_stmt [11795,11852]
===
match
---
trailer [14369,14374]
trailer [14273,14278]
===
match
---
name: filepath [14719,14727]
name: filepath [14623,14631]
===
match
---
trailer [4284,4289]
trailer [4257,4262]
===
match
---
name: found_dags [16784,16794]
name: found_dags [16688,16698]
===
match
---
name: table [23443,23448]
name: table [23347,23352]
===
match
---
simple_stmt [6739,6779]
simple_stmt [6712,6752]
===
match
---
atom_expr [15720,15771]
atom_expr [15624,15675]
===
match
---
operator: = [22211,22212]
operator: = [22115,22116]
===
match
---
trailer [14760,14811]
trailer [14664,14715]
===
match
---
name: session [10443,10450]
name: session [10416,10423]
===
match
---
atom_expr [23071,23096]
atom_expr [22975,23000]
===
match
---
import_from [1508,1562]
import_from [1481,1535]
===
match
---
trailer [13848,13879]
trailer [13752,13783]
===
match
---
trailer [16153,16156]
trailer [16057,16060]
===
match
---
atom_expr [6450,6466]
atom_expr [6423,6439]
===
match
---
name: conf [3857,3861]
name: conf [3830,3834]
===
match
---
operator: = [20228,20229]
operator: = [20132,20133]
===
match
---
trailer [25702,25889]
trailer [25606,25793]
===
match
---
operator: { [23759,23760]
operator: { [23663,23664]
===
match
---
atom_expr [10412,10451]
atom_expr [10385,10424]
===
match
---
import_from [995,1068]
import_from [995,1068]
===
match
---
name: current_module [15490,15504]
name: current_module [15394,15408]
===
match
---
atom_expr [8488,8518]
atom_expr [8461,8491]
===
match
---
operator: , [17360,17361]
operator: , [17264,17265]
===
match
---
name: dag [26183,26186]
name: dag [26087,26090]
===
match
---
string: "File %s assumed to contain no DAGs. Skipping." [12491,12538]
string: "File %s assumed to contain no DAGs. Skipping." [12395,12442]
===
match
---
atom_expr [17456,17491]
atom_expr [17360,17395]
===
match
---
arglist [3952,3985]
arglist [3925,3958]
===
match
---
operator: , [10254,10255]
operator: , [10227,10228]
===
match
---
atom_expr [11789,11810]
atom_expr [11693,11714]
===
match
---
name: debug [27606,27611]
name: debug [27510,27515]
===
match
---
classdef [2119,27898]
classdef [2092,27802]
===
match
---
if_stmt [8149,8441]
if_stmt [8122,8414]
===
match
---
name: List [6318,6322]
name: List [6291,6295]
===
match
---
import_from [6923,6983]
import_from [6896,6956]
===
match
---
return_stmt [11823,11832]
return_stmt [11727,11736]
===
match
---
name: task_num [21930,21938]
name: task_num [21834,21842]
===
match
---
name: getboolean [3783,3793]
name: getboolean [3756,3766]
===
match
---
trailer [14666,14670]
trailer [14570,14574]
===
match
---
and_test [11552,11704]
and_test [11456,11608]
===
match
---
trailer [15874,15883]
trailer [15778,15787]
===
match
---
arglist [13291,13344]
arglist [13195,13248]
===
match
---
name: dag [16652,16655]
name: dag [16556,16559]
===
match
---
name: session [27118,27125]
name: session [27022,27029]
===
match
---
atom_expr [18971,18981]
atom_expr [18875,18885]
===
match
---
string: """Information about single file""" [1993,2028]
string: """Information about single file""" [1966,2001]
===
match
---
name: dags [18962,18966]
name: dags [18866,18870]
===
match
---
simple_stmt [10484,10565]
simple_stmt [10457,10469]
===
match
---
name: split [14375,14380]
name: split [14279,14284]
===
match
---
name: dag_id [10033,10039]
name: dag_id [10006,10012]
===
match
---
operator: = [11896,11897]
operator: = [11800,11801]
===
match
---
operator: = [8069,8070]
operator: = [8042,8043]
===
match
---
import_as_names [1014,1068]
import_as_names [1014,1068]
===
match
---
atom [5187,5189]
atom [5160,5162]
===
match
---
simple_stmt [2107,2117]
simple_stmt [2080,2090]
===
match
---
name: append [21664,21670]
name: append [21568,21574]
===
match
---
trailer [22468,22507]
trailer [22372,22411]
===
match
---
atom_expr [14237,14262]
atom_expr [14141,14166]
===
match
---
comp_op [7007,7013]
comp_op [6980,6986]
===
match
---
arglist [20246,20279]
arglist [20150,20183]
===
match
---
simple_stmt [1755,1825]
simple_stmt [1728,1798]
===
match
---
simple_stmt [16554,16581]
simple_stmt [16458,16485]
===
match
---
trailer [7734,7768]
trailer [7707,7741]
===
match
---
for_stmt [18416,18478]
for_stmt [18320,18382]
===
match
---
suite [20840,20860]
suite [20744,20764]
===
match
---
trailer [16441,16448]
trailer [16345,16352]
===
match
---
atom_expr [10023,10039]
atom_expr [9996,10012]
===
match
---
operator: = [20031,20032]
operator: = [19935,19936]
===
match
---
name: security [26783,26791]
name: security [26687,26695]
===
match
---
name: bulk_write_to_db [26223,26239]
name: bulk_write_to_db [26127,26143]
===
match
---
name: utils [1576,1581]
name: utils [1549,1554]
===
match
---
name: airflow [1760,1767]
name: airflow [1733,1740]
===
match
---
arglist [5358,5403]
arglist [5331,5376]
===
match
---
atom_expr [26668,26685]
atom_expr [26572,26589]
===
match
---
argument [18916,18931]
argument [18820,18835]
===
match
---
name: dag_id [18975,18981]
name: dag_id [18879,18885]
===
match
---
trailer [20076,20087]
trailer [19980,19991]
===
match
---
name: self [8540,8544]
name: self [8513,8517]
===
match
---
atom_expr [14783,14800]
atom_expr [14687,14704]
===
match
---
trailer [16801,16809]
trailer [16705,16713]
===
match
---
trailer [11926,11947]
trailer [11830,11851]
===
match
---
string: "pathlib.Path" [3715,3729]
string: "pathlib.Path" [3688,3702]
===
match
---
operator: = [24913,24914]
operator: = [24817,24818]
===
match
---
atom_expr [21692,22073]
atom_expr [21596,21977]
===
match
---
simple_stmt [3557,3651]
simple_stmt [3530,3624]
===
match
---
name: zip_info [15681,15689]
name: zip_info [15585,15593]
===
match
---
argument [15936,15983]
argument [15840,15887]
===
match
---
name: log [19525,19528]
name: log [19429,19432]
===
match
---
argument [26260,26275]
argument [26164,26179]
===
match
---
trailer [20155,20166]
trailer [20059,20070]
===
match
---
and_test [9607,9661]
and_test [9580,9634]
===
match
---
arglist [17337,17373]
arglist [17241,17277]
===
match
---
name: filepath [12307,12315]
name: filepath [12211,12219]
===
match
---
atom_expr [6445,6467]
atom_expr [6418,6440]
===
match
---
name: len [21889,21892]
name: len [21793,21796]
===
match
---
name: self [5826,5830]
name: self [5799,5803]
===
match
---
name: hashlib [795,802]
name: hashlib [795,802]
===
match
---
atom_expr [25275,25286]
atom_expr [25179,25190]
===
match
---
name: self [4881,4885]
name: self [4854,4858]
===
match
---
name: getboolean [3862,3872]
name: getboolean [3835,3845]
===
match
---
trailer [14457,14466]
trailer [14361,14370]
===
match
---
name: access_control [27537,27551]
name: access_control [27441,27455]
===
match
---
name: self [5413,5417]
name: self [5386,5390]
===
match
---
expr_stmt [26975,27024]
expr_stmt [26879,26928]
===
match
---
trailer [7182,7186]
trailer [7155,7159]
===
match
---
simple_stmt [14136,14146]
simple_stmt [14040,14050]
===
match
---
name: provide_session [23913,23928]
name: provide_session [23817,23832]
===
match
---
simple_stmt [25906,25963]
simple_stmt [25810,25867]
===
match
---
atom_expr [4776,4798]
atom_expr [4749,4771]
===
match
---
operator: , [1027,1028]
operator: , [1027,1028]
===
match
---
atom [16496,16498]
atom [16400,16402]
===
match
---
arglist [23279,23319]
arglist [23183,23223]
===
match
---
atom_expr [18312,18327]
atom_expr [18216,18231]
===
match
---
name: machinery [13399,13408]
name: machinery [13303,13312]
===
match
---
operator: = [9481,9482]
operator: = [9454,9455]
===
match
---
operator: += [16795,16797]
operator: += [16699,16701]
===
match
---
name: dag [19294,19297]
name: dag [19198,19201]
===
match
---
name: sorted [22194,22200]
name: sorted [22098,22104]
===
match
---
name: safe_mode [10925,10934]
name: safe_mode [10829,10838]
===
match
---
trailer [10097,10102]
trailer [10070,10075]
===
match
---
operator: , [20280,20281]
operator: , [20184,20185]
===
match
---
trailer [15728,15738]
trailer [15632,15642]
===
match
---
name: traceback [25288,25297]
name: traceback [25192,25201]
===
match
---
name: keys [6460,6464]
name: keys [6433,6437]
===
match
---
name: self [25174,25178]
name: self [25078,25082]
===
match
---
name: traceback [913,922]
name: traceback [913,922]
===
match
---
name: dag [19280,19283]
name: dag [19184,19187]
===
match
---
name: dags_last_fetched [5015,5032]
name: dags_last_fetched [4988,5005]
===
match
---
name: check_cycle [1551,1562]
name: check_cycle [1524,1535]
===
match
---
number: 2 [6227,6228]
number: 2 [6200,6201]
===
match
---
name: filepath [10893,10901]
name: filepath [10797,10805]
===
match
---
name: self [6791,6795]
name: self [6764,6768]
===
match
---
suite [14069,14128]
suite [13973,14032]
===
match
---
name: validate [16666,16674]
name: validate [16570,16578]
===
match
---
operator: = [4936,4937]
operator: = [4909,4910]
===
match
---
name: include_smart_sensor [5547,5567]
name: include_smart_sensor [5520,5540]
===
match
---
name: exception [11798,11807]
name: exception [11702,11711]
===
match
---
atom_expr [16060,16087]
atom_expr [15964,15991]
===
match
---
name: import_errors [13906,13919]
name: import_errors [13810,13823]
===
match
---
trailer [25234,25248]
trailer [25138,25152]
===
match
---
trailer [5252,5294]
trailer [5225,5267]
===
match
---
name: bool [26957,26961]
name: bool [26861,26865]
===
match
---
name: dags [10729,10733]
name: dags [10633,10637]
===
match
---
name: conf [3591,3595]
name: conf [3564,3568]
===
match
---
operator: - [12689,12690]
operator: - [12593,12594]
===
match
---
simple_stmt [7096,7150]
simple_stmt [7069,7123]
===
match
---
name: os [11271,11273]
name: os [11175,11177]
===
match
---
funcdef [16235,17546]
funcdef [16139,17450]
===
match
---
name: dags_last_fetched [8493,8510]
name: dags_last_fetched [8466,8483]
===
match
---
name: warn [6064,6068]
name: warn [6037,6041]
===
match
---
name: sd_last_updated_datetime [8156,8180]
name: sd_last_updated_datetime [8129,8153]
===
match
---
simple_stmt [923,939]
simple_stmt [923,939]
===
match
---
param [3996,4028]
param [3969,4001]
===
match
---
dotted_name [24211,24240]
dotted_name [24115,24144]
===
match
---
name: exec_module [13661,13672]
name: exec_module [13565,13576]
===
match
---
fstring_expr [23836,23846]
fstring_expr [23740,23750]
===
match
---
fstring_string: Invalid timetable expression:  [16992,17022]
fstring_string: Invalid timetable expression:  [16896,16926]
===
match
---
fstring_expr [23796,23806]
fstring_expr [23700,23710]
===
match
---
name: dagbag_import_error_traceback_depth [25321,25356]
name: dagbag_import_error_traceback_depth [25225,25260]
===
match
---
if_stmt [11842,12030]
if_stmt [11746,11934]
===
match
---
atom_expr [8289,8306]
atom_expr [8262,8279]
===
match
---
name: str [19966,19969]
name: str [19870,19873]
===
match
---
trailer [27869,27876]
trailer [27773,27780]
===
match
---
param [22219,22220]
param [22123,22124]
===
match
---
name: self [15943,15947]
name: self [15847,15851]
===
match
---
fstring_expr [13197,13258]
fstring_expr [13101,13162]
===
match
---
name: self [16060,16064]
name: self [15964,15968]
===
match
---
trailer [14124,14127]
trailer [14028,14031]
===
match
---
name: sum [23275,23278]
name: sum [23179,23182]
===
match
---
name: read_dags_from_db [6796,6813]
name: read_dags_from_db [6769,6786]
===
match
---
trailer [15343,15351]
trailer [15247,15255]
===
match
---
return_stmt [6248,6277]
return_stmt [6221,6250]
===
match
---
expr_stmt [10823,10864]
expr_stmt [10727,10768]
===
match
---
simple_stmt [10760,10815]
simple_stmt [10664,10719]
===
match
---
name: dag [25021,25024]
name: dag [24925,24928]
===
match
---
expr_stmt [23345,23384]
expr_stmt [23249,23288]
===
match
---
atom_expr [12882,12903]
atom_expr [12786,12807]
===
match
---
atom_expr [16652,16676]
atom_expr [16556,16580]
===
match
---
arglist [8219,8263]
arglist [8192,8236]
===
match
---
name: found_dags [12202,12212]
name: found_dags [12106,12116]
===
match
---
name: dag_folder [20949,20959]
name: dag_folder [20853,20863]
===
match
---
operator: = [7995,7996]
operator: = [7968,7969]
===
match
---
name: bool [20026,20030]
name: bool [19930,19934]
===
match
---
simple_stmt [12562,12572]
simple_stmt [12466,12476]
===
match
---
name: session [27802,27809]
name: session [27706,27713]
===
match
---
name: log [11794,11797]
name: log [11698,11701]
===
match
---
atom_expr [24560,24573]
atom_expr [24464,24477]
===
match
---
simple_stmt [15373,15399]
simple_stmt [15277,15303]
===
match
---
atom_expr [3857,3908]
atom_expr [3830,3881]
===
match
---
suite [12421,12550]
suite [12325,12454]
===
match
---
trailer [16148,16153]
trailer [16052,16057]
===
match
---
arglist [16902,16938]
arglist [16806,16842]
===
match
---
atom_expr [26575,26597]
atom_expr [26479,26501]
===
match
---
name: Optional [23963,23971]
name: Optional [23867,23875]
===
match
---
param [16262,16271]
param [16166,16175]
===
match
---
atom_expr [18957,18982]
atom_expr [18861,18886]
===
match
---
name: SerializedDagModel [22378,22396]
name: SerializedDagModel [22282,22300]
===
match
---
name: timer [22417,22422]
name: timer [22321,22326]
===
match
---
name: _add_dag_from_db [8545,8561]
name: _add_dag_from_db [8518,8534]
===
match
---
name: dag [10783,10786]
name: dag [10687,10690]
===
match
---
name: AirflowDagCycleException [17152,17176]
name: AirflowDagCycleException [17056,17080]
===
match
---
if_stmt [19728,19885]
if_stmt [19632,19789]
===
match
---
trailer [13919,13929]
trailer [13823,13833]
===
match
---
simple_stmt [9291,9376]
simple_stmt [9264,9349]
===
match
---
name: path [12651,12655]
name: path [12555,12559]
===
match
---
name: self [23240,23244]
name: self [23144,23148]
===
match
---
funcdef [26625,27898]
funcdef [26529,27802]
===
match
---
operator: , [15761,15762]
operator: , [15665,15666]
===
match
---
atom_expr [19219,19229]
atom_expr [19123,19133]
===
match
---
name: typing [1000,1006]
name: typing [1000,1006]
===
match
---
trailer [15799,15830]
trailer [15703,15734]
===
match
---
argument [17887,17894]
argument [17791,17798]
===
match
---
atom_expr [9607,9620]
atom_expr [9580,9593]
===
match
---
name: self [19520,19524]
name: self [19424,19428]
===
match
---
name: Dict [5034,5038]
name: Dict [5007,5011]
===
match
---
atom_expr [13291,13317]
atom_expr [13195,13221]
===
match
---
name: filepath [14802,14810]
name: filepath [14706,14714]
===
match
---
string: 'Exception bagging dag: %s' [19539,19566]
string: 'Exception bagging dag: %s' [19443,19470]
===
match
---
name: only_if_updated [9859,9874]
name: only_if_updated [9832,9847]
===
match
---
name: path_hash [12702,12711]
name: path_hash [12606,12615]
===
match
---
name: os [14367,14369]
name: os [14271,14273]
===
match
---
simple_stmt [10336,10397]
simple_stmt [10309,10370]
===
match
---
name: self [5303,5307]
name: self [5276,5280]
===
match
---
name: Permission [27198,27208]
name: Permission [27102,27112]
===
match
---
name: airflow [6744,6751]
name: airflow [6717,6724]
===
match
---
expr_stmt [4913,4955]
expr_stmt [4886,4928]
===
match
---
simple_stmt [2089,2103]
simple_stmt [2062,2076]
===
match
---
operator: = [12646,12647]
operator: = [12550,12551]
===
match
---
name: log [8207,8210]
name: log [8180,8183]
===
match
---
trailer [11273,11278]
trailer [11177,11182]
===
match
---
trailer [27143,27158]
trailer [27047,27062]
===
match
---
trailer [7186,7194]
trailer [7159,7167]
===
match
---
name: check_cycle [18214,18225]
name: check_cycle [18118,18129]
===
match
---
operator: , [7131,7132]
operator: , [7104,7105]
===
match
---
name: utils [1768,1773]
name: utils [1741,1746]
===
match
---
arglist [21752,21776]
arglist [21656,21680]
===
match
---
name: dag [16614,16617]
name: dag [16518,16521]
===
match
---
trailer [12991,13013]
trailer [12895,12917]
===
match
---
name: dag_id [8748,8754]
name: dag_id [8721,8727]
===
match
---
name: safe_mode [12019,12028]
name: safe_mode [11923,11932]
===
match
---
fstring_start: f" [12941,12943]
fstring_start: f" [12845,12847]
===
match
---
name: is_missing [9688,9698]
name: is_missing [9661,9671]
===
match
---
atom_expr [9273,9282]
atom_expr [9246,9255]
===
match
---
suite [10148,10187]
suite [10121,10160]
===
match
---
del_stmt [8327,8361]
del_stmt [8300,8334]
===
match
---
name: str [5039,5042]
name: str [5012,5015]
===
match
---
name: dag [9506,9509]
name: dag [9479,9482]
===
match
---
name: self [10594,10598]
name: self [10498,10502]
===
match
---
name: root_dag [18897,18905]
name: root_dag [18801,18809]
===
match
---
trailer [23320,23334]
trailer [23224,23238]
===
match
---
name: conf [3506,3510]
name: conf [3479,3483]
===
match
---
string: """         Given a path to a python module or zip file, this method imports         the module and look for dag objects within it.         """ [10950,11093]
string: """         Given a path to a python module or zip file, this method imports         the module and look for dag objects within it.         """ [10854,10997]
===
match
---
simple_stmt [10823,10865]
simple_stmt [10727,10769]
===
match
---
import_name [869,878]
import_name [869,878]
===
match
---
and_test [18998,19042]
and_test [18902,18946]
===
match
---
name: import_module [15517,15530]
name: import_module [15421,15434]
===
match
---
fstring_string: \n         -------------------------------------------------------------------         DagBag loading stats for  [23534,23646]
fstring_string: \n         -------------------------------------------------------------------         DagBag loading stats for  [23438,23550]
===
match
---
name: self [19821,19825]
name: self [19725,19729]
===
match
---
operator: , [3887,3888]
operator: , [3860,3861]
===
match
---
simple_stmt [16883,16940]
simple_stmt [16787,16844]
===
match
---
operator: , [19340,19341]
operator: , [19244,19245]
===
match
---
expr_stmt [5154,5189]
expr_stmt [5127,5162]
===
match
---
name: dag [21947,21950]
name: dag [21851,21854]
===
match
---
atom_expr [16614,16627]
atom_expr [16518,16531]
===
match
---
name: safe_mode [5581,5590]
name: safe_mode [5554,5563]
===
match
---
name: dag_folder [5444,5454]
name: dag_folder [5417,5427]
===
match
---
trailer [18884,18932]
trailer [18788,18836]
===
match
---
name: task_num [23393,23401]
name: task_num [23297,23305]
===
match
---
operator: } [23861,23862]
operator: } [23765,23766]
===
match
---
name: dag_id [27657,27663]
name: dag_id [27561,27567]
===
match
---
name: dag_id [19877,19883]
name: dag_id [19781,19787]
===
match
---
name: rollback [26346,26354]
name: rollback [26250,26258]
===
match
---
simple_stmt [12630,12694]
simple_stmt [12534,12598]
===
match
---
atom_expr [22665,22674]
atom_expr [22569,22578]
===
match
---
name: dag [17479,17482]
name: dag [17383,17386]
===
match
---
trailer [19538,19579]
trailer [19442,19483]
===
match
---
simple_stmt [6055,6240]
simple_stmt [6028,6213]
===
match
---
trailer [4217,4226]
trailer [4190,4199]
===
match
---
name: docs [1582,1586]
name: docs [1555,1559]
===
match
---
operator: , [23952,23953]
operator: , [23856,23857]
===
match
---
atom_expr [22677,22711]
atom_expr [22581,22615]
===
match
---
string: "Failed to bag_dag: %s" [17337,17360]
string: "Failed to bag_dag: %s" [17241,17264]
===
match
---
return_stmt [13701,13720]
return_stmt [13605,13624]
===
match
---
sync_comp_for [9526,9662]
sync_comp_for [9499,9635]
===
match
---
name: subdag [10692,10698]
name: subdag [10596,10602]
===
match
---
name: dagbag_import_error_traceback_depth [15948,15983]
name: dagbag_import_error_traceback_depth [15852,15887]
===
match
---
simple_stmt [4527,4569]
simple_stmt [4500,4542]
===
match
---
name: log [27602,27605]
name: log [27506,27509]
===
match
---
string: 'smart_sensor' [3873,3887]
string: 'smart_sensor' [3846,3860]
===
match
---
name: file_last_changed_on_disk [12090,12115]
name: file_last_changed_on_disk [11994,12019]
===
match
---
name: airflow [26840,26847]
name: airflow [26744,26751]
===
match
---
name: dags [5931,5935]
name: dags [5904,5908]
===
match
---
atom_expr [16090,16096]
atom_expr [15994,16000]
===
match
---
name: loader [13511,13517]
name: loader [13415,13421]
===
match
---
name: log [14751,14754]
name: log [14655,14658]
===
match
---
name: loader [13380,13386]
name: loader [13284,13290]
===
match
---
operator: } [23805,23806]
operator: } [23709,23710]
===
match
---
simple_stmt [13701,13721]
simple_stmt [13605,13625]
===
match
---
simple_stmt [19520,19580]
simple_stmt [19424,19484]
===
match
---
comp_if [16451,16472]
comp_if [16355,16376]
===
match
---
atom_expr [14662,14728]
atom_expr [14566,14632]
===
match
---
name: root_dag [17963,17971]
name: root_dag [17867,17875]
===
match
---
arglist [12074,12115]
arglist [11978,12019]
===
match
---
name: filepath [11588,11596]
name: filepath [11492,11500]
===
match
---
name: head [14357,14361]
name: head [14261,14265]
===
match
---
atom_expr [5170,5184]
atom_expr [5143,5157]
===
match
---
suite [11296,11319]
suite [11200,11223]
===
match
---
argument [19158,19178]
argument [19062,19082]
===
match
---
try_stmt [25979,26383]
try_stmt [25883,26287]
===
match
---
name: dags [10687,10691]
name: dags [10591,10595]
===
match
---
name: recursive [18664,18673]
name: recursive [18568,18577]
===
match
---
operator: , [10267,10268]
operator: , [10240,10241]
===
match
---
simple_stmt [995,1069]
simple_stmt [995,1069]
===
match
---
name: is_missing [9241,9251]
name: is_missing [9214,9224]
===
match
---
name: filepath [11286,11294]
name: filepath [11190,11198]
===
match
---
name: sys [886,889]
name: sys [886,889]
===
match
---
simple_stmt [9035,9096]
simple_stmt [9008,9069]
===
match
---
name: correct_maybe_zipped [21147,21167]
name: correct_maybe_zipped [21051,21071]
===
match
---
operator: { [12813,12814]
operator: { [12717,12718]
===
match
---
name: Optional [4060,4068]
name: Optional [4033,4041]
===
match
---
operator: -> [5988,5990]
operator: -> [5961,5963]
===
match
---
argument [24821,24884]
argument [24725,24788]
===
match
---
name: exc [1086,1089]
name: exc [1086,1089]
===
match
---
simple_stmt [25650,25672]
simple_stmt [25554,25576]
===
match
---
name: found_dags [10057,10067]
name: found_dags [10030,10040]
===
match
---
atom_expr [10574,10591]
atom_expr [10478,10495]
===
match
---
simple_stmt [17993,18206]
simple_stmt [17897,18110]
===
match
---
testlist_comp [19363,19420]
testlist_comp [19267,19324]
===
match
---
suite [9398,9677]
suite [9371,9650]
===
match
---
fstring_string: DagBag import timeout for  [12943,12969]
fstring_string: DagBag import timeout for  [12847,12873]
===
match
---
atom_expr [18275,18303]
atom_expr [18179,18207]
===
match
---
string: "Syncing DAG permissions: %s to the DB" [27612,27651]
string: "Syncing DAG permissions: %s to the DB" [27516,27555]
===
match
---
except_clause [26293,26316]
except_clause [26197,26220]
===
match
---
trailer [19318,19324]
trailer [19222,19228]
===
match
---
import_from [1563,1606]
import_from [1536,1579]
===
match
---
string: 'DAG_DISCOVERY_SAFE_MODE' [20254,20279]
string: 'DAG_DISCOVERY_SAFE_MODE' [20158,20183]
===
match
---
trailer [3951,3986]
trailer [3924,3959]
===
match
---
suite [21398,22165]
suite [21302,22069]
===
match
---
name: dags [2107,2111]
name: dags [2080,2084]
===
match
---
operator: -> [5832,5834]
operator: -> [5805,5807]
===
match
---
name: dag_id [10699,10705]
name: dag_id [10603,10609]
===
match
---
name: min_update_interval [24821,24840]
name: min_update_interval [24725,24744]
===
match
---
name: self [8488,8492]
name: self [8461,8465]
===
match
---
name: e [14125,14126]
name: e [14029,14030]
===
match
---
import_name [906,922]
import_name [906,922]
===
match
---
name: self [9471,9475]
name: self [9444,9448]
===
match
---
parameters [10249,10286]
parameters [10222,10259]
===
match
---
funcdef [6297,6468]
funcdef [6270,6441]
===
match
---
atom_expr [22411,22441]
atom_expr [22315,22345]
===
match
---
operator: , [11935,11936]
operator: , [11839,11840]
===
match
---
operator: } [4823,4824]
operator: } [4796,4797]
===
match
---
param [16272,16277]
param [16176,16181]
===
match
---
name: dedent [23510,23516]
name: dedent [23414,23420]
===
match
---
import_name [939,953]
import_name [939,953]
===
match
---
name: is_subdag [9611,9620]
name: is_subdag [9584,9593]
===
match
---
name: has_logged [15088,15098]
name: has_logged [14992,15002]
===
match
---
name: timezone [7856,7864]
name: timezone [7829,7837]
===
match
---
operator: = [21274,21275]
operator: = [21178,21179]
===
match
---
trailer [6459,6464]
trailer [6432,6437]
===
match
---
name: dag [10621,10624]
name: dag [10525,10528]
===
match
---
name: dag_id [19572,19578]
name: dag_id [19476,19482]
===
match
---
trailer [14678,14728]
trailer [14582,14632]
===
match
---
simple_stmt [16194,16210]
simple_stmt [16098,16114]
===
match
---
for_stmt [27037,27496]
for_stmt [26941,27400]
===
match
---
trailer [27601,27605]
trailer [27505,27509]
===
match
---
name: is_expired [9291,9301]
name: is_expired [9264,9274]
===
match
---
name: dag_cycle_tester [1527,1543]
name: dag_cycle_tester [1500,1516]
===
match
---
dotted_name [26840,26868]
dotted_name [26744,26772]
===
match
---
arglist [13426,13444]
arglist [13330,13348]
===
match
---
atom [14143,14145]
atom [14047,14049]
===
match
---
operator: } [5057,5058]
operator: } [5030,5031]
===
match
---
name: info [20878,20882]
name: info [20782,20786]
===
match
---
atom_expr [18783,18800]
atom_expr [18687,18704]
===
match
---
name: dags [4676,4680]
name: dags [4649,4653]
===
match
---
operator: = [5185,5186]
operator: = [5158,5159]
===
match
---
name: models [24176,24182]
name: models [24080,24086]
===
match
---
name: log [17323,17326]
name: log [17227,17230]
===
match
---
operator: { [4870,4871]
operator: { [4843,4844]
===
match
---
simple_stmt [7166,7195]
simple_stmt [7139,7168]
===
match
---
name: values [16442,16448]
name: values [16346,16352]
===
match
---
operator: { [23796,23797]
operator: { [23700,23701]
===
match
---
trailer [27197,27208]
trailer [27101,27112]
===
match
---
simple_stmt [1114,1149]
simple_stmt [1114,1149]
===
match
---
name: timedelta [985,994]
name: timedelta [985,994]
===
match
---
expr_stmt [10760,10814]
expr_stmt [10664,10718]
===
match
---
trailer [12485,12490]
trailer [12389,12394]
===
match
---
trailer [17413,17421]
trailer [17317,17325]
===
match
---
name: airflow [16319,16326]
name: airflow [16223,16230]
===
match
---
name: sd_last_updated_datetime [7970,7994]
name: sd_last_updated_datetime [7943,7967]
===
match
---
operator: , [14192,14193]
operator: , [14096,14097]
===
match
---
sync_comp_for [23291,23305]
sync_comp_for [23195,23209]
===
match
---
trailer [18961,18966]
trailer [18865,18870]
===
match
---
expr_stmt [8869,8904]
expr_stmt [8842,8877]
===
match
---
name: existing [19200,19208]
name: existing [19104,19112]
===
match
---
import_from [22336,22396]
import_from [22240,22300]
===
match
---
expr_stmt [21432,21473]
expr_stmt [21336,21377]
===
match
---
name: log [15135,15138]
name: log [15039,15042]
===
match
---
atom_expr [10734,10744]
atom_expr [10638,10648]
===
match
---
simple_stmt [10724,10752]
simple_stmt [10628,10656]
===
match
---
number: 0 [16154,16155]
number: 0 [16058,16059]
===
match
---
trailer [8293,8298]
trailer [8266,8271]
===
match
---
param [24317,24324]
param [24221,24228]
===
match
---
name: load_op_links [4091,4104]
name: load_op_links [4064,4077]
===
match
---
name: log [25693,25696]
name: log [25597,25600]
===
match
---
import_from [954,994]
import_from [954,994]
===
match
---
import_name [890,905]
import_name [890,905]
===
match
---
suite [8519,8594]
suite [8492,8567]
===
match
---
trailer [15860,15874]
trailer [15764,15778]
===
match
---
name: len [21943,21946]
name: len [21847,21850]
===
match
---
or_test [4591,4625]
or_test [4564,4598]
===
match
---
parameters [10886,10940]
parameters [10790,10844]
===
match
---
if_stmt [12838,12904]
if_stmt [12742,12808]
===
match
---
and_test [9304,9375]
and_test [9277,9348]
===
match
---
argument [22234,22246]
argument [22138,22150]
===
match
---
simple_stmt [16956,17035]
simple_stmt [16860,16939]
===
match
---
simple_stmt [24163,24198]
simple_stmt [24067,24102]
===
match
---
trailer [27430,27442]
trailer [27334,27346]
===
match
---
suite [22284,23097]
suite [22188,23001]
===
match
---
name: filepath [15460,15468]
name: filepath [15364,15372]
===
match
---
or_test [11247,11295]
or_test [11151,11199]
===
match
---
name: fileloc [18755,18762]
name: fileloc [18659,18666]
===
match
---
trailer [14862,14871]
trailer [14766,14775]
===
match
---
name: settings [1200,1208]
name: settings [1200,1208]
===
match
---
trailer [10691,10706]
trailer [10595,10610]
===
match
---
name: sqlalchemy [1119,1129]
name: sqlalchemy [1119,1129]
===
match
---
atom_expr [21947,21956]
atom_expr [21851,21860]
===
match
---
name: stats [23378,23383]
name: stats [23282,23287]
===
match
---
trailer [17322,17326]
trailer [17226,17230]
===
match
---
arglist [6082,6229]
arglist [6055,6202]
===
match
---
parameters [26647,26693]
parameters [26551,26597]
===
match
---
name: dag [16710,16713]
name: dag [16614,16617]
===
match
---
name: log [22148,22151]
name: log [22052,22055]
===
match
---
name: self [11600,11604]
name: self [11504,11508]
===
match
---
simple_stmt [18382,18407]
simple_stmt [18286,18311]
===
match
---
name: sum [23355,23358]
name: sum [23259,23262]
===
match
---
operator: { [5187,5188]
operator: { [5160,5161]
===
match
---
simple_stmt [12195,12213]
simple_stmt [12099,12117]
===
match
---
name: dags [22006,22010]
name: dags [21910,21914]
===
match
---
atom_expr [10823,10849]
atom_expr [10727,10753]
===
match
---
number: 0 [15457,15458]
number: 0 [15361,15362]
===
match
---
simple_stmt [18312,18348]
simple_stmt [18216,18252]
===
match
---
name: util [864,868]
name: util [864,868]
===
match
---
trailer [15388,15398]
trailer [15292,15302]
===
match
---
name: x [22222,22223]
name: x [22126,22127]
===
match
---
simple_stmt [6923,6984]
simple_stmt [6896,6957]
===
match
---
name: safe_mode [14873,14882]
name: safe_mode [14777,14786]
===
match
---
name: serialized_dag [24226,24240]
name: serialized_dag [24130,24144]
===
match
---
operator: , [1051,1052]
operator: , [1051,1052]
===
match
---
atom_expr [15658,15699]
atom_expr [15562,15603]
===
match
---
name: DAGS_FOLDER [4614,4625]
name: DAGS_FOLDER [4587,4598]
===
match
---
atom_expr [19310,19346]
atom_expr [19214,19250]
===
match
---
trailer [27656,27663]
trailer [27560,27567]
===
match
---
trailer [21670,22091]
trailer [21574,21995]
===
match
---
arglist [19325,19345]
arglist [19229,19249]
===
match
---
operator: = [26993,26994]
operator: = [26897,26898]
===
match
---
name: get [7183,7186]
name: get [7156,7159]
===
match
---
trailer [25278,25286]
trailer [25182,25190]
===
match
---
fstring_string: *  [13195,13197]
fstring_string: *  [13099,13101]
===
match
---
operator: = [14430,14431]
operator: = [14334,14335]
===
match
---
except_clause [25140,25156]
except_clause [25044,25060]
===
match
---
name: self [16956,16960]
name: self [16860,16864]
===
match
---
argument [9859,9880]
argument [9832,9853]
===
match
---
name: dag [10734,10737]
name: dag [10638,10641]
===
match
---
name: self [10138,10142]
name: self [10111,10115]
===
match
---
name: file_parse_start_dttm [21834,21855]
name: file_parse_start_dttm [21738,21759]
===
match
---
trailer [12008,12029]
trailer [11912,11933]
===
match
---
name: subdag [22984,22990]
name: subdag [22888,22894]
===
match
---
name: file_last_changed [11677,11694]
name: file_last_changed [11581,11598]
===
match
---
name: include_smart_sensor [21345,21365]
name: include_smart_sensor [21249,21269]
===
match
---
name: o [23373,23374]
name: o [23277,23278]
===
match
---
operator: = [3589,3590]
operator: = [3562,3563]
===
match
---
name: import_errors [17396,17409]
name: import_errors [17300,17313]
===
match
---
operator: , [3958,3959]
operator: , [3931,3932]
===
match
---
import_name [847,868]
import_name [847,868]
===
match
---
trailer [27185,27209]
trailer [27089,27113]
===
match
---
simple_stmt [16383,16474]
simple_stmt [16287,16378]
===
match
---
suite [18713,18933]
suite [18617,18837]
===
match
---
atom_expr [13654,13684]
atom_expr [13558,13588]
===
match
---
atom_expr [17410,17421]
atom_expr [17314,17325]
===
match
---
trailer [18338,18345]
trailer [18242,18249]
===
match
---
trailer [23407,23434]
trailer [23311,23338]
===
match
---
trailer [19324,19346]
trailer [19228,19250]
===
match
---
string: 'LOAD_EXAMPLES' [3802,3817]
string: 'LOAD_EXAMPLES' [3775,3790]
===
match
---
arglist [15739,15770]
arglist [15643,15674]
===
match
---
name: stacklevel [6216,6226]
name: stacklevel [6189,6199]
===
match
---
name: self [26648,26652]
name: self [26552,26556]
===
match
---
name: getboolean [20156,20166]
name: getboolean [20060,20070]
===
match
---
param [24312,24316]
param [24216,24220]
===
match
---
suite [12865,12904]
suite [12769,12808]
===
match
---
except_clause [15605,15626]
except_clause [15509,15530]
===
match
---
name: o [16426,16427]
name: o [16330,16331]
===
match
---
name: permission_name [27317,27332]
name: permission_name [27221,27236]
===
match
---
if_stmt [12282,12572]
if_stmt [12186,12476]
===
match
---
name: top_level_dags [16383,16397]
name: top_level_dags [16287,16301]
===
match
---
name: warnings [6055,6063]
name: warnings [6028,6036]
===
match
---
name: self [19270,19274]
name: self [19174,19178]
===
match
---
name: file_parse_end_dttm [21812,21831]
name: file_parse_end_dttm [21716,21735]
===
match
---
atom_expr [8331,8361]
atom_expr [8304,8334]
===
match
---
name: dag_folder [3692,3702]
name: dag_folder [3665,3675]
===
match
---
name: self [9776,9780]
name: self [9749,9753]
===
match
---
if_stmt [18995,19258]
if_stmt [18899,19162]
===
match
---
trailer [10215,10223]
trailer [10188,10196]
===
match
---
operator: = [13332,13333]
operator: = [13236,13237]
===
match
---
operator: } [12978,12979]
operator: } [12882,12883]
===
match
---
atom_expr [19270,19291]
atom_expr [19174,19195]
===
match
---
atom_expr [20151,20202]
atom_expr [20055,20106]
===
match
---
name: str [4687,4690]
name: str [4660,4663]
===
match
---
name: provide_session [26605,26620]
name: provide_session [26509,26524]
===
match
---
trailer [6068,6239]
trailer [6041,6212]
===
match
---
simple_stmt [21490,21585]
simple_stmt [21394,21489]
===
match
---
expr_stmt [22665,22711]
expr_stmt [22569,22615]
===
match
---
name: session [25034,25041]
name: session [24938,24945]
===
match
---
trailer [26087,26092]
trailer [25991,25996]
===
match
---
arglist [3794,3817]
arglist [3767,3790]
===
match
---
testlist_comp [17152,17273]
testlist_comp [17056,17177]
===
match
---
name: tasks [18432,18437]
name: tasks [18336,18341]
===
match
---
simple_stmt [13602,13638]
simple_stmt [13506,13542]
===
match
---
name: AirflowTimetableInvalid [16829,16852]
name: AirflowTimetableInvalid [16733,16756]
===
match
---
trailer [12585,12589]
trailer [12489,12493]
===
match
---
dotted_name [24168,24186]
dotted_name [24072,24090]
===
match
---
operator: } [4700,4701]
operator: } [4673,4674]
===
match
---
param [14184,14193]
param [14088,14097]
===
match
---
argument [8577,8592]
argument [8550,8565]
===
match
---
trailer [26567,26574]
trailer [26471,26478]
===
match
---
name: str [17425,17428]
name: str [17329,17332]
===
match
---
operator: = [20070,20071]
operator: = [19974,19975]
===
match
---
simple_stmt [14214,14224]
simple_stmt [14118,14128]
===
match
---
param [20212,20281]
param [20116,20185]
===
match
---
suite [16541,17520]
suite [16445,17424]
===
match
---
atom_expr [25597,25605]
atom_expr [25501,25509]
===
match
---
operator: , [1803,1804]
operator: , [1776,1777]
===
match
---
atom_expr [19167,19178]
atom_expr [19071,19082]
===
match
---
atom_expr [12727,12751]
atom_expr [12631,12655]
===
match
---
name: filepath [11868,11876]
name: filepath [11772,11780]
===
match
---
simple_stmt [18827,18851]
simple_stmt [18731,18755]
===
match
---
suite [14514,14544]
suite [14418,14448]
===
match
---
trailer [27605,27611]
trailer [27509,27515]
===
match
---
name: dagbag_import_error_traceback_depth [13990,14025]
name: dagbag_import_error_traceback_depth [13894,13929]
===
match
---
simple_stmt [14090,14128]
simple_stmt [13994,14032]
===
match
---
atom_expr [7708,7769]
atom_expr [7681,7742]
===
match
---
operator: = [23273,23274]
operator: = [23177,23178]
===
match
---
expr_stmt [2048,2067]
expr_stmt [2021,2040]
===
match
---
operator: } [23767,23768]
operator: } [23671,23672]
===
match
---
trailer [5038,5053]
trailer [5011,5026]
===
match
---
atom_expr [22143,22164]
atom_expr [22047,22068]
===
match
---
if_stmt [27530,27898]
if_stmt [27434,27802]
===
match
---
name: dag_id [6512,6518]
name: dag_id [6485,6491]
===
match
---
simple_stmt [10621,10635]
simple_stmt [10525,10539]
===
match
---
trailer [14374,14380]
trailer [14278,14284]
===
match
---
name: airflow [1612,1619]
name: airflow [1585,1592]
===
match
---
name: dags [9547,9551]
name: dags [9520,9524]
===
match
---
name: dag_id [9153,9159]
name: dag_id [9126,9132]
===
match
---
name: provide_session [1859,1874]
name: provide_session [1832,1847]
===
match
---
name: log [22460,22463]
name: log [22364,22367]
===
match
---
trailer [5307,5343]
trailer [5280,5316]
===
match
---
name: has_logged [15047,15057]
name: has_logged [14951,14961]
===
match
---
trailer [25020,25042]
trailer [24924,24946]
===
match
---
name: warning [8211,8218]
name: warning [8184,8191]
===
match
---
name: orm_dag [9355,9362]
name: orm_dag [9328,9335]
===
match
---
return_stmt [25059,25068]
return_stmt [24963,24972]
===
match
---
operator: = [23199,23200]
operator: = [23103,23104]
===
match
---
operator: = [23353,23354]
operator: = [23257,23258]
===
match
---
trailer [4638,4649]
trailer [4611,4622]
===
match
---
name: dict [26575,26579]
name: dict [26479,26483]
===
match
---
trailer [7871,7873]
trailer [7844,7846]
===
match
---
string: ".py" [14499,14504]
string: ".py" [14403,14408]
===
match
---
trailer [3782,3793]
trailer [3755,3766]
===
match
---
argument [8562,8575]
argument [8535,8548]
===
match
---
suite [17301,17520]
suite [17205,17424]
===
match
---
simple_stmt [15561,15589]
simple_stmt [15465,15493]
===
match
---
trailer [13562,13579]
trailer [13466,13483]
===
match
---
name: report [23900,23906]
name: report [23804,23810]
===
match
---
atom_expr [7096,7149]
atom_expr [7069,7122]
===
match
---
if_stmt [18661,18933]
if_stmt [18565,18837]
===
match
---
expr_stmt [20936,20978]
expr_stmt [20840,20882]
===
match
---
operator: , [19387,19388]
operator: , [19291,19292]
===
match
---
name: Exception [15612,15621]
name: Exception [15516,15525]
===
match
---
atom [4870,4872]
atom [4843,4845]
===
match
---
if_stmt [15035,15279]
if_stmt [14939,15183]
===
match
---
name: dag_id [19811,19817]
name: dag_id [19715,19721]
===
match
---
name: sys [13602,13605]
name: sys [13506,13509]
===
match
---
atom_expr [16956,16987]
atom_expr [16860,16891]
===
match
---
name: serialized_dag [6943,6957]
name: serialized_dag [6916,6930]
===
match
---
trailer [10577,10591]
trailer [10481,10495]
===
match
---
import_from [1607,1697]
import_from [1580,1670]
===
match
---
name: DAG [26219,26222]
name: DAG [26123,26126]
===
match
---
subscriptlist [4858,4866]
subscriptlist [4831,4839]
===
match
---
operator: , [3614,3615]
operator: , [3587,3588]
===
match
---
suite [9713,10187]
suite [9686,10160]
===
match
---
trailer [20087,20112]
trailer [19991,20016]
===
match
---
dotted_name [1703,1734]
dotted_name [1676,1707]
===
match
---
name: exception [17327,17336]
name: exception [17231,17240]
===
match
---
expr_stmt [23492,23884]
expr_stmt [23396,23788]
===
match
---
trailer [11507,11517]
trailer [11411,11421]
===
match
---
trailer [10733,10745]
trailer [10637,10649]
===
match
---
operator: = [14365,14366]
operator: = [14269,14270]
===
match
---
param [17963,17972]
param [17867,17876]
===
match
---
name: values [26250,26256]
name: values [26154,26160]
===
match
---
trailer [27442,27444]
trailer [27346,27348]
===
match
---
name: is_expired [9702,9712]
name: is_expired [9675,9685]
===
match
---
testlist_star_expr [14357,14364]
testlist_star_expr [14261,14268]
===
match
---
name: only_if_updated [21547,21562]
name: only_if_updated [21451,21466]
===
match
---
name: path [12668,12672]
name: path [12572,12576]
===
match
---
name: airflow [1830,1837]
name: airflow [1803,1810]
===
match
---
trailer [21167,21184]
trailer [21071,21088]
===
match
---
name: get_docs_url [1594,1606]
name: get_docs_url [1567,1579]
===
match
---
name: datetime [5044,5052]
name: datetime [5017,5025]
===
match
---
trailer [24849,24884]
trailer [24753,24788]
===
match
---
name: exception [19529,19538]
name: exception [19433,19442]
===
match
---
atom_expr [18827,18843]
atom_expr [18731,18747]
===
match
---
tfpdef [3996,4019]
tfpdef [3969,3992]
===
match
---
name: sync_perm_for_dag [27848,27865]
name: sync_perm_for_dag [27752,27769]
===
match
---
atom_expr [23035,23048]
atom_expr [22939,22952]
===
match
---
operator: = [3855,3856]
operator: = [3828,3829]
===
match
---
string: "Reading %s from %s" [14761,14781]
string: "Reading %s from %s" [14665,14685]
===
match
---
name: timezone [1499,1507]
name: timezone [1472,1480]
===
match
---
name: file_last_changed_on_disk [11643,11668]
name: file_last_changed_on_disk [11547,11572]
===
match
---
name: process_file [10874,10886]
name: process_file [10778,10790]
===
match
---
suite [19741,19885]
suite [19645,19789]
===
match
---
operator: = [22675,22676]
operator: = [22579,22580]
===
match
---
atom_expr [7876,7906]
atom_expr [7849,7879]
===
match
---
name: self [17456,17460]
name: self [17360,17364]
===
match
---
trailer [10686,10691]
trailer [10590,10595]
===
match
---
name: log [25911,25914]
name: log [25815,25818]
===
match
---
name: dag [26076,26079]
name: dag [25980,25983]
===
match
---
name: __init__ [4218,4226]
name: __init__ [4191,4199]
===
match
---
operator: , [12088,12089]
operator: , [11992,11993]
===
match
---
name: log [15725,15728]
name: log [15629,15632]
===
match
---
name: task [18420,18424]
name: task [18324,18328]
===
match
---
import_as_names [1789,1824]
import_as_names [1762,1797]
===
match
---
atom_expr [16745,16767]
atom_expr [16649,16671]
===
match
---
atom_expr [23355,23384]
atom_expr [23259,23288]
===
match
---
annassign [2038,2043]
annassign [2011,2016]
===
match
---
name: self [16256,16260]
name: self [16160,16164]
===
match
---
operator: , [14504,14505]
operator: , [14408,14409]
===
match
---
operator: , [14712,14713]
operator: , [14616,14617]
===
match
---
string: 'scheduler' [3603,3614]
string: 'scheduler' [3576,3587]
===
match
---
simple_stmt [23027,23059]
simple_stmt [22931,22963]
===
match
---
name: sqlalchemy [1075,1085]
name: sqlalchemy [1075,1085]
===
match
---
name: MIN_SERIALIZED_DAG_UPDATE_INTERVAL [24850,24884]
name: MIN_SERIALIZED_DAG_UPDATE_INTERVAL [24754,24788]
===
match
---
trailer [12130,12148]
trailer [12034,12052]
===
match
---
name: subdags [23088,23095]
name: subdags [22992,22999]
===
match
---
tfpdef [23954,23980]
tfpdef [23858,23884]
===
match
---
dotted_name [22341,22370]
dotted_name [22245,22274]
===
match
---
atom_expr [19568,19578]
atom_expr [19472,19482]
===
match
---
name: configuration [1222,1235]
name: configuration [1222,1235]
===
match
---
trailer [16891,16901]
trailer [16795,16805]
===
match
---
fstring_string:           [23846,23855]
fstring_string:           [23750,23759]
===
match
---
trailer [12148,12158]
trailer [12052,12062]
===
match
---
operator: , [17272,17273]
operator: , [17176,17177]
===
match
---
simple_stmt [10195,10224]
simple_stmt [10168,10197]
===
match
---
name: dag [18312,18315]
name: dag [18216,18219]
===
match
---
name: utils [1838,1843]
name: utils [1811,1816]
===
match
---
arglist [20883,20926]
arglist [20787,20830]
===
match
---
simple_stmt [4210,4229]
simple_stmt [4183,4202]
===
match
---
name: dag_id [8401,8407]
name: dag_id [8374,8380]
===
match
---
trailer [17326,17336]
trailer [17230,17240]
===
match
---
operator: } [23657,23658]
operator: } [23561,23562]
===
match
---
operator: = [21454,21455]
operator: = [21358,21359]
===
match
---
name: dags [8781,8785]
name: dags [8754,8758]
===
match
---
name: fileloc [17366,17373]
name: fileloc [17270,17277]
===
match
---
atom_expr [14312,14339]
atom_expr [14216,14243]
===
match
---
argument [22208,22232]
argument [22112,22136]
===
match
---
name: dag [25275,25278]
name: dag [25179,25182]
===
match
---
operator: = [17423,17424]
operator: = [17327,17328]
===
match
---
name: dags [7019,7023]
name: dags [6992,6996]
===
match
---
fstring_string: unusual_prefix_ [12786,12801]
fstring_string: unusual_prefix_ [12690,12705]
===
match
---
operator: = [10746,10747]
operator: = [10650,10651]
===
match
---
tfpdef [19948,19992]
tfpdef [19852,19896]
===
match
---
simple_stmt [1940,1955]
simple_stmt [1913,1928]
===
match
---
atom_expr [20072,20112]
atom_expr [19976,20016]
===
match
---
trailer [21950,21956]
trailer [21854,21860]
===
match
---
name: conf [20072,20076]
name: conf [19976,19980]
===
match
---
suite [6328,6468]
suite [6301,6441]
===
match
---
name: dagbag_import_error_tracebacks [13849,13879]
name: dagbag_import_error_tracebacks [13753,13783]
===
match
---
subscriptlist [5175,5183]
subscriptlist [5148,5156]
===
match
---
name: permissions [26857,26868]
name: permissions [26761,26772]
===
match
---
operator: , [9533,9534]
operator: , [9506,9507]
===
match
---
simple_stmt [1070,1114]
simple_stmt [1070,1114]
===
match
---
string: "The store_serialized_dags property has been deprecated. Use read_dags_from_db instead." [6082,6170]
string: "The store_serialized_dags property has been deprecated. Use read_dags_from_db instead." [6055,6143]
===
match
---
simple_stmt [19897,19903]
simple_stmt [19801,19807]
===
match
---
if_stmt [15325,15399]
if_stmt [15229,15303]
===
match
---
suite [23989,26599]
suite [23893,26503]
===
match
---
name: found_dags [21490,21500]
name: found_dags [21394,21404]
===
match
---
name: dag [18275,18278]
name: dag [18179,18182]
===
match
---
name: timezone [21624,21632]
name: timezone [21528,21536]
===
match
---
name: getboolean [20235,20245]
name: getboolean [20139,20149]
===
match
---
name: dag [16724,16727]
name: dag [16628,16631]
===
match
---
trailer [27230,27235]
trailer [27134,27139]
===
match
---
trailer [15572,15588]
trailer [15476,15492]
===
match
---
operator: != [19028,19030]
operator: != [18932,18934]
===
match
---
param [14178,14183]
param [14082,14087]
===
match
---
if_stmt [24957,25043]
if_stmt [24861,24947]
===
match
---
trailer [15046,15057]
trailer [14950,14961]
===
match
---
try_stmt [15416,16210]
try_stmt [15320,16114]
===
match
---
name: dag [17410,17413]
name: dag [17314,17317]
===
match
---
suite [18522,19347]
suite [18426,19251]
===
match
---
expr_stmt [13380,13445]
expr_stmt [13284,13349]
===
match
---
trailer [3940,3951]
trailer [3913,3924]
===
match
---
name: filename [15244,15252]
name: filename [15148,15156]
===
match
---
name: o [23359,23360]
name: o [23263,23264]
===
match
---
for_stmt [25555,26599]
for_stmt [25459,26503]
===
match
---
atom_expr [27236,27256]
atom_expr [27140,27160]
===
match
---
trailer [16093,16096]
trailer [15997,16000]
===
match
---
simple_stmt [16784,16810]
simple_stmt [16688,16714]
===
match
---
fstring [12784,12828]
fstring [12688,12732]
===
match
---
atom_expr [10760,10794]
atom_expr [10664,10698]
===
match
---
name: dags_last_fetched [7818,7835]
name: dags_last_fetched [7791,7808]
===
match
---
atom_expr [13614,13623]
atom_expr [13518,13527]
===
match
---
atom_expr [8614,8635]
atom_expr [8587,8608]
===
match
---
name: get [8624,8627]
name: get [8597,8600]
===
match
---
name: load_op_links [10578,10591]
name: load_op_links [10482,10495]
===
match
---
name: self [7014,7018]
name: self [6987,6991]
===
match
---
name: DeprecationWarning [6184,6202]
name: DeprecationWarning [6157,6175]
===
match
---
name: dag [19126,19129]
name: dag [19030,19033]
===
match
---
trailer [4686,4696]
trailer [4659,4669]
===
match
---
arglist [5253,5293]
arglist [5226,5266]
===
match
---
name: get [10212,10215]
name: get [10185,10188]
===
match
---
trailer [15449,15456]
trailer [15353,15360]
===
match
---
trailer [15738,15771]
trailer [15642,15675]
===
match
---
atom_expr [15235,15252]
atom_expr [15139,15156]
===
match
---
argument [19119,19136]
argument [19023,19040]
===
match
---
trailer [22019,22026]
trailer [21923,21930]
===
match
---
trailer [16674,16676]
trailer [16578,16580]
===
match
---
name: self [22174,22178]
name: self [22078,22082]
===
match
---
simple_stmt [22908,22921]
simple_stmt [22812,22825]
===
match
---
name: bool [20223,20227]
name: bool [20127,20131]
===
match
---
param [17973,17982]
param [17877,17886]
===
match
---
simple_stmt [20853,20860]
simple_stmt [20757,20764]
===
match
---
name: dag [16975,16978]
name: dag [16879,16882]
===
match
---
fstring_expr [23759,23768]
fstring_expr [23663,23672]
===
match
---
name: self [11789,11793]
name: self [11693,11697]
===
match
---
name: subdags [19772,19779]
name: subdags [19676,19683]
===
match
---
atom_expr [16975,16986]
atom_expr [16879,16890]
===
match
---
trailer [18431,18437]
trailer [18335,18341]
===
match
---
return_stmt [9132,9160]
return_stmt [9105,9133]
===
match
---
atom_expr [23240,23255]
atom_expr [23144,23159]
===
match
---
name: found_dags [9763,9773]
name: found_dags [9736,9746]
===
match
---
name: key [9501,9504]
name: key [9474,9477]
===
match
---
operator: , [8255,8256]
operator: , [8228,8229]
===
match
---
name: store_serialized_dags [4547,4568]
name: store_serialized_dags [4520,4541]
===
match
---
trailer [5417,5430]
trailer [5390,5403]
===
match
---
dotted_name [26766,26796]
dotted_name [26670,26700]
===
match
---
name: filepath [11247,11255]
name: filepath [11151,11159]
===
match
---
operator: , [15458,15459]
operator: , [15362,15363]
===
match
---
operator: = [15505,15506]
operator: = [15409,15410]
===
match
---
parameters [6308,6314]
parameters [6281,6287]
===
match
---
trailer [13483,13500]
trailer [13387,13404]
===
match
---
name: zipfile [946,953]
name: zipfile [946,953]
===
match
---
operator: @ [23912,23913]
operator: @ [23816,23817]
===
match
---
decorated [26604,27898]
decorated [26508,27802]
===
match
---
comp_if [9576,9662]
comp_if [9549,9635]
===
match
---
atom [4699,4701]
atom [4672,4674]
===
match
---
simple_stmt [5010,5059]
simple_stmt [4983,5032]
===
match
---
arglist [4307,4500]
arglist [4280,4473]
===
match
---
name: resource_name_for_dag [26889,26910]
name: resource_name_for_dag [26793,26814]
===
match
---
simple_stmt [4776,4825]
simple_stmt [4749,4798]
===
match
---
simple_stmt [4881,4905]
simple_stmt [4854,4878]
===
match
---
tfpdef [6520,6536]
tfpdef [6493,6509]
===
match
---
name: filepath [13815,13823]
name: filepath [13719,13727]
===
match
---
param [6520,6543]
param [6493,6516]
===
match
---
factor [12689,12691]
factor [12593,12595]
===
match
---
operator: , [26258,26259]
operator: , [26162,26163]
===
match
---
trailer [23409,23418]
trailer [23313,23322]
===
match
---
funcdef [14151,16230]
funcdef [14055,16134]
===
match
---
simple_stmt [9471,9677]
simple_stmt [9444,9650]
===
match
---
comparison [27362,27408]
comparison [27266,27312]
===
match
---
name: self [12126,12130]
name: self [12030,12034]
===
match
---
name: modules [15381,15388]
name: modules [15285,15292]
===
match
---
operator: , [26652,26653]
operator: , [26556,26557]
===
match
---
name: found_dags [12039,12049]
name: found_dags [11943,11953]
===
match
---
name: bag_dag [17555,17562]
name: bag_dag [17459,17466]
===
match
---
suite [11332,11746]
suite [11236,11650]
===
match
---
atom_expr [14836,14901]
atom_expr [14740,14805]
===
match
---
operator: , [16403,16404]
operator: , [16307,16308]
===
match
---
trailer [14108,14118]
trailer [14012,14022]
===
match
---
not_test [11267,11295]
not_test [11171,11199]
===
match
---
name: resolve_template_files [18279,18301]
name: resolve_template_files [18183,18205]
===
match
---
name: DAGBAG_IMPORT_TIMEOUT [13296,13317]
name: DAGBAG_IMPORT_TIMEOUT [13200,13221]
===
match
---
atom_expr [10783,10793]
atom_expr [10687,10697]
===
match
---
string: 'core' [3794,3800]
string: 'core' [3767,3773]
===
match
---
simple_stmt [19060,19258]
simple_stmt [18964,19162]
===
match
---
simple_stmt [8540,8594]
simple_stmt [8513,8567]
===
match
---
name: self [26240,26244]
name: self [26144,26148]
===
match
---
trailer [10032,10039]
trailer [10005,10012]
===
match
---
name: incoming [19158,19166]
name: incoming [19062,19070]
===
match
---
argument [7118,7131]
argument [7091,7104]
===
match
---
not_test [8152,8180]
not_test [8125,8153]
===
match
---
try_stmt [11328,11833]
try_stmt [11232,11737]
===
match
---
string: """         Gets the DAG out of the dictionary, and refreshes it if expired          :param dag_id: DAG Id         :type dag_id: str         """ [6554,6698]
string: """         Gets the DAG out of the dictionary, and refreshes it if expired          :param dag_id: DAG Id         :type dag_id: str         """ [6527,6671]
===
match
---
trailer [4857,4867]
trailer [4830,4840]
===
match
---
dotted_name [1612,1630]
dotted_name [1585,1603]
===
match
---
operator: , [23465,23466]
operator: , [23369,23370]
===
match
---
trailer [17395,17409]
trailer [17299,17313]
===
match
---
trailer [16201,16206]
trailer [16105,16110]
===
match
---
trailer [25914,25920]
trailer [25818,25824]
===
match
---
operator: = [18888,18889]
operator: = [18792,18793]
===
match
---
name: fileloc [19171,19178]
name: fileloc [19075,19082]
===
match
---
trailer [22151,22161]
trailer [22055,22065]
===
match
---
expr_stmt [10406,10451]
expr_stmt [10379,10424]
===
match
---
name: dag_id [10128,10134]
name: dag_id [10101,10107]
===
match
---
name: stats [23300,23305]
name: stats [23204,23209]
===
match
---
operator: = [17087,17088]
operator: = [16991,16992]
===
match
---
operator: , [16713,16714]
operator: , [16617,16618]
===
match
---
suite [7953,8594]
suite [7926,8567]
===
match
---
name: dag_policy [18391,18401]
name: dag_policy [18295,18305]
===
match
---
name: self [13901,13905]
name: self [13805,13809]
===
match
---
operator: , [8076,8077]
operator: , [8049,8050]
===
match
---
name: self [12477,12481]
name: self [12381,12385]
===
match
---
trailer [23516,23884]
trailer [23420,23788]
===
match
---
atom_expr [6255,6277]
atom_expr [6228,6250]
===
match
---
operator: , [17956,17957]
operator: , [17860,17861]
===
match
---
name: task [18472,18476]
name: task [18376,18380]
===
match
---
atom_expr [19520,19579]
atom_expr [19424,19483]
===
match
---
trailer [14754,14760]
trailer [14658,14664]
===
match
---
string: "File %s:%s assumed to contain no DAGs. Skipping." [15173,15223]
string: "File %s:%s assumed to contain no DAGs. Skipping." [15077,15127]
===
match
---
param [23120,23124]
param [23024,23028]
===
match
---
name: stats [23428,23433]
name: stats [23332,23337]
===
match
---
argument [5581,5600]
argument [5554,5573]
===
match
---
trailer [10827,10837]
trailer [10731,10741]
===
match
---
name: key [22208,22211]
name: key [22112,22115]
===
match
---
operator: , [16270,16271]
operator: , [16174,16175]
===
match
---
try_stmt [16593,17520]
try_stmt [16497,17424]
===
match
---
name: sync_to_db [23937,23947]
name: sync_to_db [23841,23851]
===
match
---
trailer [10660,10668]
trailer [10564,10572]
===
match
---
decorator [6473,6490]
decorator [6446,6463]
===
match
---
trailer [27354,27361]
trailer [27258,27265]
===
match
---
name: run_with_db_retries [25570,25589]
name: run_with_db_retries [25474,25493]
===
match
---
name: recursive [18916,18925]
name: recursive [18820,18829]
===
match
---
atom_expr [9841,9856]
atom_expr [9814,9829]
===
match
---
operator: , [19178,19179]
operator: , [19082,19083]
===
match
---
arglist [25021,25041]
arglist [24925,24945]
===
match
---
name: self [13772,13776]
name: self [13676,13680]
===
match
---
name: settings [18382,18390]
name: settings [18286,18294]
===
match
---
atom_expr [26127,26197]
atom_expr [26031,26101]
===
match
---
name: AirflowDagDuplicatedIdException [17194,17225]
name: AirflowDagDuplicatedIdException [17098,17129]
===
match
---
name: sys [16198,16201]
name: sys [16102,16105]
===
match
---
expr_stmt [23443,23482]
expr_stmt [23347,23386]
===
match
---
atom_expr [11672,11704]
atom_expr [11576,11608]
===
match
---
expr_stmt [16483,16498]
expr_stmt [16387,16402]
===
match
---
name: sqla_models [27236,27247]
name: sqla_models [27140,27151]
===
match
---
atom_expr [16145,16156]
atom_expr [16049,16060]
===
match
---
simple_stmt [23345,23385]
simple_stmt [23249,23289]
===
match
---
name: items [9552,9557]
name: items [9525,9530]
===
match
---
simple_stmt [13380,13446]
simple_stmt [13284,13350]
===
match
---
suite [5996,6278]
suite [5969,6251]
===
match
---
simple_stmt [8799,8823]
simple_stmt [8772,8796]
===
match
---
name: log [25602,25605]
name: log [25506,25509]
===
match
---
atom_expr [10594,10612]
atom_expr [10498,10516]
===
match
---
expr_stmt [12039,12116]
expr_stmt [11943,12020]
===
match
---
name: dags [9476,9480]
name: dags [9449,9453]
===
match
---
name: OperationalError [25088,25104]
name: OperationalError [24992,25008]
===
match
---
trailer [11856,11867]
trailer [11760,11771]
===
match
---
operator: , [3743,3744]
operator: , [3716,3717]
===
match
---
expr_stmt [7970,8132]
expr_stmt [7943,8105]
===
match
---
name: timeout [13283,13290]
name: timeout [13187,13194]
===
match
---
name: path [15661,15665]
name: path [15565,15569]
===
match
---
trailer [26222,26239]
trailer [26126,26143]
===
match
---
operator: = [16709,16710]
operator: = [16613,16614]
===
match
---
import_from [1070,1113]
import_from [1070,1113]
===
match
---
name: split [12673,12678]
name: split [12577,12582]
===
match
---
trailer [25308,25357]
trailer [25212,25261]
===
match
---
operator: = [4868,4869]
operator: = [4841,4842]
===
match
---
suite [25157,25360]
suite [25061,25264]
===
match
---
trailer [22416,22422]
trailer [22320,22326]
===
match
---
atom_expr [14432,14467]
atom_expr [14336,14371]
===
match
---
operator: == [27314,27316]
operator: == [27218,27220]
===
match
---
operator: = [22916,22917]
operator: = [22820,22821]
===
match
---
expr_stmt [14357,14399]
expr_stmt [14261,14303]
===
match
---
name: subdag [18734,18740]
name: subdag [18638,18644]
===
match
---
name: dag [27866,27869]
name: dag [27770,27773]
===
match
---
param [17949,17954]
param [17853,17858]
===
match
---
atom_expr [12665,12692]
atom_expr [12569,12596]
===
match
---
name: dag [24312,24315]
name: dag [24216,24219]
===
match
---
name: self [22944,22948]
name: self [22848,22852]
===
match
---
name: DAGS_FOLDER [21761,21772]
name: DAGS_FOLDER [21665,21676]
===
match
---
arglist [5444,5601]
arglist [5417,5574]
===
match
---
trailer [10102,10110]
trailer [10075,10083]
===
match
---
name: self [5926,5930]
name: self [5899,5903]
===
match
---
atom_expr [8776,8785]
atom_expr [8749,8758]
===
match
---
operator: = [17904,17905]
operator: = [17808,17809]
===
match
---
name: bool [4015,4019]
name: bool [3988,3992]
===
match
---
operator: = [27770,27771]
operator: = [27674,27675]
===
match
---
del_stmt [19856,19884]
del_stmt [19760,19788]
===
match
---
simple_stmt [847,869]
simple_stmt [847,869]
===
match
---
simple_stmt [22455,22508]
simple_stmt [22359,22412]
===
match
---
suite [11961,12030]
suite [11865,11934]
===
match
---
param [5982,5986]
param [5955,5959]
===
match
---
funcdef [17936,19903]
funcdef [17840,19807]
===
match
---
atom_expr [17362,17373]
atom_expr [17266,17277]
===
match
---
operator: = [9043,9044]
operator: = [9016,9017]
===
match
---
name: filepath [16160,16168]
name: filepath [16064,16072]
===
match
---
name: filepath [14109,14117]
name: filepath [14013,14021]
===
match
---
name: store_serialized_dags [5960,5981]
name: store_serialized_dags [5933,5954]
===
match
---
operator: = [7725,7726]
operator: = [7698,7699]
===
match
---
operator: = [24840,24841]
operator: = [24744,24745]
===
match
---
trailer [11807,11810]
trailer [11711,11714]
===
match
---
with_item [14237,14282]
with_item [14141,14186]
===
match
---
name: mod_name [13426,13434]
name: mod_name [13330,13338]
===
match
---
parameters [17562,17583]
parameters [17466,17487]
===
match
---
name: bag_dag [16698,16705]
name: bag_dag [16602,16609]
===
match
---
name: dag_folder [20916,20926]
name: dag_folder [20820,20830]
===
match
---
simple_stmt [18734,18763]
simple_stmt [18638,18667]
===
match
---
simple_stmt [23193,23219]
simple_stmt [23097,23123]
===
match
---
atom [25273,25359]
atom [25177,25263]
===
match
---
trailer [15530,15540]
trailer [15434,15444]
===
match
---
testlist_comp [10023,10067]
testlist_comp [9996,10040]
===
match
---
dotted_name [1760,1781]
dotted_name [1733,1754]
===
match
---
name: recursive [17973,17982]
name: recursive [17877,17886]
===
match
---
name: dag_num [23760,23767]
name: dag_num [23664,23671]
===
match
---
name: timezone [21456,21464]
name: timezone [21360,21368]
===
match
---
operator: = [3776,3777]
operator: = [3749,3750]
===
match
---
name: Exception [13740,13749]
name: Exception [13644,13653]
===
match
---
operator: { [4699,4700]
operator: { [4672,4673]
===
match
---
name: dag [9607,9610]
name: dag [9580,9583]
===
match
---
expr_stmt [18734,18762]
expr_stmt [18638,18666]
===
match
---
trailer [12306,12327]
trailer [12210,12231]
===
match
---
operator: - [13984,13985]
operator: - [13888,13889]
===
match
---
name: dag_id [19223,19229]
name: dag_id [19127,19133]
===
match
---
atom_expr [16198,16209]
atom_expr [16102,16113]
===
match
---
or_test [9688,9712]
or_test [9661,9685]
===
match
---
suite [24976,25043]
suite [24880,24947]
===
match
---
atom_expr [23404,23434]
atom_expr [23308,23338]
===
match
---
trailer [18754,18762]
trailer [18658,18666]
===
match
---
name: file_last_changed_on_disk [12161,12186]
name: file_last_changed_on_disk [12065,12090]
===
match
---
name: dag_id [19130,19136]
name: dag_id [19034,19040]
===
match
---
name: dag_id [19119,19125]
name: dag_id [19023,19029]
===
match
---
name: self [7173,7177]
name: self [7146,7150]
===
match
---
name: dag_id [8898,8904]
name: dag_id [8871,8877]
===
match
---
name: dag [18803,18806]
name: dag [18707,18710]
===
match
---
atom_expr [16927,16938]
atom_expr [16831,16842]
===
match
---
fstring_expr [13118,13177]
fstring_expr [13022,13081]
===
match
---
trailer [18278,18301]
trailer [18182,18205]
===
match
---
name: self [19310,19314]
name: self [19214,19218]
===
match
---
suite [18674,18933]
suite [18578,18837]
===
match
---
comparison [7000,7023]
comparison [6973,6996]
===
match
---
name: self [12987,12991]
name: self [12891,12895]
===
match
---
argument [25590,25605]
argument [25494,25509]
===
match
---
name: dag [10631,10634]
name: dag [10535,10538]
===
match
---
trailer [19283,19290]
trailer [19187,19194]
===
match
---
name: session [25026,25033]
name: session [24930,24937]
===
match
---
atom_expr [16798,16809]
atom_expr [16702,16713]
===
match
---
sync_comp_for [10040,10067]
sync_comp_for [10013,10040]
===
match
---
name: include_smart_sensor [20122,20142]
name: include_smart_sensor [20026,20046]
===
match
---
name: models [16327,16333]
name: models [16231,16237]
===
match
---
name: join [27181,27185]
name: join [27085,27089]
===
match
---
trailer [10173,10178]
trailer [10146,10151]
===
match
---
name: dag [9337,9340]
name: dag [9310,9313]
===
match
---
name: dagbag_import_error_tracebacks [15800,15830]
name: dagbag_import_error_tracebacks [15704,15734]
===
match
---
name: load_op_links [5782,5795]
name: load_op_links [5755,5768]
===
match
---
atom_expr [19821,19830]
atom_expr [19725,19734]
===
match
---
name: log [25179,25182]
name: log [25083,25086]
===
match
---
trailer [23041,23048]
trailer [22945,22952]
===
match
---
comparison [9337,9375]
comparison [9310,9348]
===
match
---
operator: = [21314,21315]
operator: = [21218,21219]
===
match
---
trailer [8210,8218]
trailer [8183,8191]
===
match
---
name: info [12486,12490]
name: info [12390,12394]
===
match
---
name: dag_id [8569,8575]
name: dag_id [8542,8548]
===
match
---
name: safe_mode [14194,14203]
name: safe_mode [14098,14107]
===
match
---
name: getfloat [3511,3519]
name: getfloat [3484,3492]
===
match
---
argument [8063,8076]
argument [8036,8049]
===
match
---
name: splitext [12656,12664]
name: splitext [12560,12568]
===
match
---
name: security [27694,27702]
name: security [27598,27606]
===
match
---
name: tabulate [23451,23459]
name: tabulate [23355,23363]
===
match
---
expr_stmt [11440,11518]
expr_stmt [11344,11422]
===
match
---
name: key [9530,9533]
name: key [9503,9506]
===
match
---
if_stmt [14560,14598]
if_stmt [14464,14502]
===
match
---
suite [15352,15399]
suite [15256,15303]
===
match
---
atom_expr [25906,25962]
atom_expr [25810,25866]
===
match
---
atom_expr [22011,22050]
atom_expr [21915,21954]
===
match
---
name: utils [1521,1526]
name: utils [1494,1499]
===
match
---
operator: } [4871,4872]
operator: } [4844,4845]
===
match
---
name: modules [12857,12864]
name: modules [12761,12768]
===
match
---
name: dag [24183,24186]
name: dag [24087,24090]
===
match
---
name: mods [16272,16276]
name: mods [16176,16180]
===
match
---
comparison [10128,10147]
comparison [10101,10120]
===
match
---
string: 'utf-8' [12743,12750]
string: 'utf-8' [12647,12654]
===
match
---
atom_expr [21735,21777]
atom_expr [21639,21681]
===
match
---
name: might_contain_dag [14836,14853]
name: might_contain_dag [14740,14757]
===
match
---
name: NamedTuple [1041,1051]
name: NamedTuple [1041,1051]
===
match
---
name: last_loaded [18316,18327]
name: last_loaded [18220,18231]
===
match
---
operator: , [10891,10892]
operator: , [10795,10796]
===
match
---
simple_stmt [27753,27819]
simple_stmt [27657,27723]
===
match
---
atom_expr [9045,9095]
atom_expr [9018,9068]
===
match
---
return_stmt [11309,11318]
return_stmt [11213,11222]
===
match
---
operator: = [16494,16495]
operator: = [16398,16399]
===
match
---
trailer [10737,10744]
trailer [10641,10648]
===
match
---
arglist [26183,26195]
arglist [26087,26099]
===
match
---
operator: = [12712,12713]
operator: = [12616,12617]
===
match
---
name: o [23280,23281]
name: o [23184,23185]
===
match
---
trailer [9340,9352]
trailer [9313,9325]
===
match
---
trailer [6449,6467]
trailer [6422,6440]
===
match
---
suite [16305,17546]
suite [16209,17450]
===
match
---
operator: = [19166,19167]
operator: = [19070,19071]
===
match
---
name: dag_num [2072,2079]
name: dag_num [2045,2052]
===
match
---
name: dag_id [7118,7124]
name: dag_id [7091,7097]
===
match
---
name: has_logged [12443,12453]
name: has_logged [12347,12357]
===
match
---
simple_stmt [23443,23483]
simple_stmt [23347,23387]
===
match
---
simple_stmt [21432,21474]
simple_stmt [21336,21378]
===
match
---
param [12262,12271]
param [12166,12175]
===
match
---
parameters [12245,12272]
parameters [12149,12176]
===
match
---
name: airflow [1185,1192]
name: airflow [1185,1192]
===
match
---
name: root_dag_id [9625,9636]
name: root_dag_id [9598,9609]
===
match
---
import_as_names [1638,1697]
import_as_names [1611,1670]
===
match
---
number: 2 [4498,4499]
number: 2 [4471,4472]
===
match
---
operator: , [10923,10924]
operator: , [10827,10828]
===
match
---
simple_stmt [11440,11519]
simple_stmt [11344,11423]
===
match
---
trailer [13905,13919]
trailer [13809,13823]
===
match
---
trailer [13941,13952]
trailer [13845,13856]
===
match
---
name: self [27597,27601]
name: self [27501,27505]
===
match
---
trailer [9277,9282]
trailer [9250,9255]
===
match
---
suite [6545,10224]
suite [6518,10197]
===
match
---
atom_expr [18497,18508]
atom_expr [18401,18412]
===
match
---
name: update [23081,23087]
name: update [22985,22991]
===
match
---
simple_stmt [6337,6430]
simple_stmt [6310,6403]
===
match
---
atom_expr [9542,9559]
atom_expr [9515,9532]
===
match
---
simple_stmt [1441,1473]
simple_stmt [1414,1446]
===
match
---
name: dag_resource_name [26975,26992]
name: dag_resource_name [26879,26896]
===
match
---
name: dag_num [21881,21888]
name: dag_num [21785,21792]
===
match
---
name: replace [21744,21751]
name: replace [21648,21655]
===
match
---
string: """Save attributes about list of DAG to the DB.""" [23998,24048]
string: """Save attributes about list of DAG to the DB.""" [23902,23952]
===
match
---
simple_stmt [890,906]
simple_stmt [890,906]
===
match
---
name: filepath [15671,15679]
name: filepath [15575,15583]
===
match
---
name: e [11808,11809]
name: e [11712,11713]
===
match
---
name: _load_modules_from_zip [11986,12008]
name: _load_modules_from_zip [11890,11912]
===
match
---
operator: { [12986,12987]
operator: { [12890,12891]
===
match
---
operator: + [7907,7908]
operator: + [7880,7881]
===
match
---
fstring_string:  after  [12979,12986]
fstring_string:  after  [12883,12890]
===
match
---
suite [16035,16097]
suite [15939,16001]
===
match
---
name: dags [8810,8814]
name: dags [8783,8787]
===
match
---
trailer [3709,3736]
trailer [3682,3709]
===
match
---
name: filepath [12009,12017]
name: filepath [11913,11921]
===
match
---
trailer [14094,14108]
trailer [13998,14012]
===
match
---
simple_stmt [939,954]
simple_stmt [939,954]
===
match
---
name: List [1035,1039]
name: List [1035,1039]
===
match
---
name: dags [19214,19218]
name: dags [19118,19122]
===
match
---
expr_stmt [9035,9095]
expr_stmt [9008,9068]
===
match
---
expr_stmt [12913,13269]
expr_stmt [12817,13173]
===
match
---
name: self [13291,13295]
name: self [13195,13199]
===
match
---
trailer [12481,12485]
trailer [12385,12389]
===
match
---
name: traceback [13932,13941]
name: traceback [13836,13845]
===
match
---
name: airflow [24168,24175]
name: airflow [24072,24079]
===
match
---
operator: , [16516,16517]
operator: , [16420,16421]
===
match
---
suite [26694,27898]
suite [26598,27802]
===
match
---
operator: , [15223,15224]
operator: , [15127,15128]
===
match
---
atom_expr [15083,15098]
atom_expr [14987,15002]
===
match
---
trailer [8809,8814]
trailer [8782,8787]
===
match
---
name: DAG [4692,4695]
name: DAG [4665,4668]
===
match
---
name: mods [11974,11978]
name: mods [11878,11882]
===
match
---
name: dag [16706,16709]
name: dag [16610,16613]
===
match
---
atom_expr [13602,13624]
atom_expr [13506,13528]
===
match
---
atom_expr [5154,5168]
atom_expr [5127,5141]
===
match
---
suite [14340,16210]
suite [14244,16114]
===
match
---
operator: = [23402,23403]
operator: = [23306,23307]
===
match
---
atom_expr [15042,15057]
atom_expr [14946,14961]
===
match
---
expr_stmt [12438,12460]
expr_stmt [12342,12364]
===
match
---
trailer [5350,5357]
trailer [5323,5330]
===
match
---
trailer [14439,14448]
trailer [14343,14352]
===
match
---
arglist [27612,27663]
arglist [27516,27567]
===
match
---
name: airflow [6928,6935]
name: airflow [6901,6908]
===
match
---
simple_stmt [11789,11811]
simple_stmt [11693,11715]
===
match
---
dotted_name [1880,1901]
dotted_name [1853,1874]
===
match
---
trailer [27571,27583]
trailer [27475,27487]
===
match
---
operator: = [9302,9303]
operator: = [9275,9276]
===
match
---
atom_expr [13198,13257]
atom_expr [13102,13161]
===
match
---
name: debug [14755,14760]
name: debug [14659,14664]
===
match
---
name: root_dag_id [9579,9590]
name: root_dag_id [9552,9563]
===
match
---
operator: , [3908,3909]
operator: , [3881,3882]
===
match
---
operator: , [26186,26187]
operator: , [26090,26091]
===
match
---
name: dag [26654,26657]
name: dag [26558,26561]
===
match
---
operator: , [18895,18896]
operator: , [18799,18800]
===
match
---
arglist [21241,21387]
arglist [21145,21291]
===
match
---
operator: = [21938,21939]
operator: = [21842,21843]
===
match
---
name: dag [18226,18229]
name: dag [18130,18133]
===
match
---
operator: , [5364,5365]
operator: , [5337,5338]
===
match
---
trailer [8492,8510]
trailer [8465,8483]
===
match
---
return_stmt [7166,7194]
return_stmt [7139,7167]
===
match
---
name: dags [10207,10211]
name: dags [10180,10184]
===
match
---
name: root_dag [17896,17904]
name: root_dag [17800,17808]
===
match
---
simple_stmt [25122,25128]
simple_stmt [25026,25032]
===
match
---
trailer [11278,11285]
trailer [11182,11189]
===
match
---
trailer [11985,12008]
trailer [11889,11912]
===
match
---
name: self [14090,14094]
name: self [13994,13998]
===
match
---
suite [25105,25128]
suite [25009,25032]
===
match
---
name: int [2081,2084]
name: int [2054,2057]
===
match
---
atom_expr [19209,19238]
atom_expr [19113,19142]
===
match
---
name: Union [19960,19965]
name: Union [19864,19869]
===
match
---
name: bool [4106,4110]
name: bool [4079,4083]
===
match
---
name: self [14178,14182]
name: self [14082,14086]
===
match
---
fstring_end: " [17033,17034]
fstring_end: " [16937,16938]
===
match
---
name: dags [9144,9148]
name: dags [9117,9121]
===
match
---
name: dag [21962,21965]
name: dag [21866,21869]
===
match
---
name: self [4913,4917]
name: self [4886,4890]
===
match
---
simple_stmt [15720,15772]
simple_stmt [15624,15676]
===
match
---
atom_expr [12648,12693]
atom_expr [12552,12597]
===
match
---
trailer [21663,21670]
trailer [21567,21574]
===
match
---
import_from [24163,24197]
import_from [24067,24101]
===
match
---
atom_expr [3704,3736]
atom_expr [3677,3709]
===
match
---
trailer [25192,25249]
trailer [25096,25153]
===
match
---
name: len [5922,5925]
name: len [5895,5898]
===
match
---
name: mods [12084,12088]
name: mods [11988,11992]
===
match
---
name: session [8098,8105]
name: session [8071,8078]
===
match
---
trailer [26099,26101]
trailer [26003,26005]
===
match
---
atom_expr [27118,27444]
atom_expr [27022,27348]
===
match
---
name: extend [26144,26150]
name: extend [26048,26054]
===
match
---
name: filename [14792,14800]
name: filename [14696,14704]
===
match
---
argument [23359,23383]
argument [23263,23287]
===
match
---
name: fileloc [17414,17421]
name: fileloc [17318,17325]
===
match
---
fstring_expr [12969,12979]
fstring_expr [12873,12883]
===
match
---
trailer [9610,9620]
trailer [9583,9593]
===
match
---
trailer [10178,10186]
trailer [10151,10159]
===
match
---
trailer [15947,15983]
trailer [15851,15887]
===
match
---
trailer [3595,3602]
trailer [3568,3575]
===
match
---
suite [4125,5812]
suite [4098,5785]
===
match
---
atom [5056,5058]
atom [5029,5031]
===
match
---
trailer [15565,15572]
trailer [15469,15476]
===
match
---
name: exception [16892,16901]
name: exception [16796,16805]
===
match
---
name: SerializedDagModel [22677,22695]
name: SerializedDagModel [22581,22599]
===
match
---
name: parent_dag [18790,18800]
name: parent_dag [18694,18704]
===
match
---
name: _sync_perm_for_dag [25002,25020]
name: _sync_perm_for_dag [24906,24924]
===
match
---
trailer [3510,3519]
trailer [3483,3492]
===
match
---
suite [10669,10716]
suite [10573,10620]
===
match
---
operator: } [13176,13177]
operator: } [13080,13081]
===
match
---
decorated [23912,26599]
decorated [23816,26503]
===
match
---
name: os [12665,12667]
name: os [12569,12571]
===
match
---
arglist [14761,14810]
arglist [14665,14714]
===
match
---
tfpdef [20122,20148]
tfpdef [20026,20052]
===
match
---
tfpdef [4091,4110]
tfpdef [4064,4083]
===
match
---
trailer [4215,4217]
trailer [4188,4190]
===
match
---
trailer [27247,27256]
trailer [27151,27160]
===
match
---
name: session [8585,8592]
name: session [8558,8565]
===
match
---
factor [15942,15983]
factor [15846,15887]
===
match
---
name: import_errors [14095,14108]
name: import_errors [13999,14012]
===
match
---
argument [21345,21386]
argument [21249,21290]
===
match
---
name: models [4179,4185]
name: models [4152,4158]
===
match
---
operator: } [23845,23846]
operator: } [23749,23750]
===
match
---
name: needs_perm_views [26924,26940]
name: needs_perm_views [26828,26844]
===
match
---
operator: > [8486,8487]
operator: > [8459,8460]
===
match
---
if_stmt [9104,9161]
if_stmt [9077,9134]
===
match
---
name: mod_name [12773,12781]
name: mod_name [12677,12685]
===
match
---
arglist [17887,17929]
arglist [17791,17833]
===
match
---
trailer [13579,13585]
trailer [13483,13489]
===
match
---
name: self [26549,26553]
name: self [26453,26457]
===
match
---
with_stmt [13278,14128]
with_stmt [13182,14032]
===
match
---
simple_stmt [27677,27740]
simple_stmt [27581,27644]
===
match
---
operator: , [8113,8114]
operator: , [8086,8087]
===
match
---
expr_stmt [8734,8754]
expr_stmt [8707,8727]
===
match
---
suite [6814,8636]
suite [6787,8609]
===
match
---
argument [13319,13344]
argument [13223,13248]
===
match
---
expr_stmt [18827,18850]
expr_stmt [18731,18754]
===
match
---
operator: = [8719,8720]
operator: = [8692,8693]
===
match
---
name: dag [8838,8841]
name: dag [8811,8814]
===
match
---
name: ext [14714,14717]
name: ext [14618,14621]
===
match
---
trailer [12650,12655]
trailer [12554,12559]
===
match
---
name: include_examples [3753,3769]
name: include_examples [3726,3742]
===
match
---
trailer [3602,3650]
trailer [3575,3623]
===
match
---
arglist [19119,19239]
arglist [19023,19143]
===
match
---
expr_stmt [14416,14467]
expr_stmt [14320,14371]
===
match
---
trailer [8218,8264]
trailer [8191,8237]
===
match
---
operator: , [21562,21563]
operator: , [21466,21467]
===
match
---
name: self [10760,10764]
name: self [10664,10668]
===
match
---
name: filename [14863,14871]
name: filename [14767,14775]
===
match
---
suite [16169,16210]
suite [16073,16114]
===
match
---
trailer [5930,5935]
trailer [5903,5908]
===
match
---
atom_expr [21752,21772]
atom_expr [21656,21676]
===
match
---
atom_expr [26151,26196]
atom_expr [26055,26100]
===
match
---
arglist [3520,3551]
arglist [3493,3524]
===
match
---
simple_stmt [4578,4626]
simple_stmt [4551,4599]
===
match
---
name: __file__ [16572,16580]
name: __file__ [16476,16484]
===
match
---
arglist [14854,14900]
arglist [14758,14804]
===
match
---
arglist [23460,23481]
arglist [23364,23385]
===
match
---
fstring [23530,23874]
fstring [23434,23778]
===
match
---
name: format_exc [15896,15906]
name: format_exc [15800,15810]
===
match
---
not_test [12285,12327]
not_test [12189,12231]
===
match
---
trailer [13425,13445]
trailer [13329,13349]
===
match
---
expr_stmt [19270,19297]
expr_stmt [19174,19201]
===
match
---
name: zip_info [14449,14457]
name: zip_info [14353,14361]
===
match
---
name: dag [22994,22997]
name: dag [22898,22901]
===
match
---
annassign [5032,5058]
annassign [5005,5031]
===
match
---
trailer [11490,11518]
trailer [11394,11422]
===
match
---
string: ".pyc" [14506,14512]
string: ".pyc" [14410,14416]
===
match
---
name: conf [3778,3782]
name: conf [3751,3755]
===
match
---
atom_expr [5346,5404]
atom_expr [5319,5377]
===
match
---
trailer [9053,9065]
trailer [9026,9038]
===
match
---
name: file_parse_end_dttm [21602,21621]
name: file_parse_end_dttm [21506,21525]
===
match
---
name: info [22464,22468]
name: info [22368,22372]
===
match
---
name: ext [14426,14429]
name: ext [14330,14333]
===
match
---
name: path [11494,11498]
name: path [11398,11402]
===
match
---
name: Optional [1053,1061]
name: Optional [1053,1061]
===
match
---
operator: = [18328,18329]
operator: = [18232,18233]
===
match
---
trailer [20166,20202]
trailer [20070,20106]
===
match
---
suite [17984,19903]
suite [17888,19807]
===
match
---
name: __init__ [3660,3668]
name: __init__ [3633,3641]
===
match
---
name: session [26338,26345]
name: session [26242,26249]
===
match
---
simple_stmt [11974,12030]
simple_stmt [11878,11934]
===
match
---
name: timetable [16656,16665]
name: timetable [16560,16569]
===
match
---
atom_expr [27831,27897]
atom_expr [27735,27801]
===
match
---
simple_stmt [820,847]
simple_stmt [820,847]
===
match
---
name: session [6520,6527]
name: session [6493,6500]
===
match
---
operator: = [8568,8569]
operator: = [8541,8542]
===
match
---
name: table [23856,23861]
name: table [23760,23765]
===
match
---
operator: { [13118,13119]
operator: { [13022,13023]
===
match
---
name: last_loaded [9341,9352]
name: last_loaded [9314,9325]
===
match
---
name: dags [22670,22674]
name: dags [22574,22578]
===
match
---
trailer [12409,12420]
trailer [12313,12324]
===
match
---
trailer [12885,12893]
trailer [12789,12797]
===
match
---
annassign [4851,4872]
annassign [4824,4845]
===
match
---
name: int [2099,2102]
name: int [2072,2075]
===
match
---
dotted_name [6928,6957]
dotted_name [6901,6930]
===
match
---
operator: , [5259,5260]
operator: , [5232,5233]
===
match
---
name: DAG_ACTIONS [26876,26887]
name: DAG_ACTIONS [26780,26791]
===
match
---
name: timezone [18330,18338]
name: timezone [18234,18242]
===
match
---
expr_stmt [13901,14047]
expr_stmt [13805,13951]
===
match
---
testlist_comp [23280,23305]
testlist_comp [23184,23209]
===
match
---
operator: , [17567,17568]
operator: , [17471,17472]
===
match
---
operator: = [9874,9875]
operator: = [9847,9848]
===
match
---
dotted_name [1075,1089]
dotted_name [1075,1089]
===
match
---
simple_stmt [22336,22397]
simple_stmt [22240,22301]
===
match
---
name: might_contain_dag [12289,12306]
name: might_contain_dag [12193,12210]
===
match
---
name: dag_folder [5455,5465]
name: dag_folder [5428,5438]
===
match
---
operator: , [19136,19137]
operator: , [19040,19041]
===
match
---
trailer [27881,27896]
trailer [27785,27800]
===
match
---
name: dag_id [19284,19290]
name: dag_id [19188,19194]
===
match
---
name: logging_mixin [1721,1734]
name: logging_mixin [1694,1707]
===
match
---
name: min_serialized_dag_fetch_secs [7909,7938]
name: min_serialized_dag_fetch_secs [7882,7911]
===
match
---
name: stats [21042,21047]
name: stats [20946,20951]
===
match
---
strings [4307,4433]
strings [4280,4406]
===
match
---
arglist [7118,7148]
arglist [7091,7121]
===
match
---
trailer [24563,24573]
trailer [24467,24477]
===
match
---
name: dag_folder [23227,23237]
name: dag_folder [23131,23141]
===
match
---
expr_stmt [16383,16473]
expr_stmt [16287,16377]
===
match
---
funcdef [5817,5937]
funcdef [5790,5910]
===
match
---
name: TYPE_CHECKING [1014,1027]
name: TYPE_CHECKING [1014,1027]
===
match
---
name: timezone [10797,10805]
name: timezone [10701,10709]
===
match
---
simple_stmt [18451,18478]
simple_stmt [18355,18382]
===
match
---
name: mod_name [12894,12902]
name: mod_name [12798,12806]
===
match
---
import_from [26835,26910]
import_from [26739,26814]
===
match
---
for_stmt [22933,23059]
for_stmt [22837,22963]
===
match
---
name: retry_state [25808,25819]
name: retry_state [25712,25723]
===
match
---
name: getboolean [5242,5252]
name: getboolean [5215,5225]
===
match
---
name: run_with_db_retries [1805,1824]
name: run_with_db_retries [1778,1797]
===
match
---
atom_expr [16554,16565]
atom_expr [16458,16469]
===
match
---
atom_expr [9139,9160]
atom_expr [9112,9133]
===
match
---
trailer [12742,12751]
trailer [12646,12655]
===
match
---
name: bool [3850,3854]
name: bool [3823,3827]
===
match
---
atom_expr [15377,15398]
atom_expr [15281,15302]
===
match
---
trailer [23075,23080]
trailer [22979,22984]
===
match
---
argument [18897,18914]
argument [18801,18818]
===
match
---
name: mod [16518,16521]
name: mod [16422,16425]
===
match
---
dotted_name [27682,27702]
dotted_name [27586,27606]
===
match
---
simple_stmt [21134,21185]
simple_stmt [21038,21089]
===
match
---
trailer [16448,16450]
trailer [16352,16354]
===
match
---
expr_stmt [15648,15699]
expr_stmt [15552,15603]
===
match
---
simple_stmt [11309,11319]
simple_stmt [11213,11223]
===
match
---
simple_stmt [1473,1508]
simple_stmt [1446,1481]
===
match
---
trailer [18301,18303]
trailer [18205,18207]
===
match
---
trailer [21507,21520]
trailer [21411,21424]
===
match
---
parameters [26940,26953]
parameters [26844,26857]
===
match
---
name: dag_id [8628,8634]
name: dag_id [8601,8607]
===
match
---
argument [17915,17929]
argument [17819,17833]
===
match
---
annassign [4680,4701]
annassign [4653,4674]
===
match
---
name: reverse [22234,22241]
name: reverse [22138,22145]
===
match
---
name: mods [14214,14218]
name: mods [14118,14122]
===
match
---
param [4037,4082]
param [4010,4055]
===
match
---
operator: , [19938,19939]
operator: , [19842,19843]
===
match
---
simple_stmt [26219,26277]
simple_stmt [26123,26181]
===
match
---
name: dag_id [10738,10744]
name: dag_id [10642,10648]
===
match
---
simple_stmt [7676,7770]
simple_stmt [7649,7743]
===
match
---
atom [24598,24600]
atom [24502,24504]
===
match
---
name: self [11981,11985]
name: self [11885,11889]
===
match
---
funcdef [17551,17931]
funcdef [17455,17835]
===
match
---
trailer [15444,15449]
trailer [15348,15353]
===
match
---
name: mods [16225,16229]
name: mods [16129,16133]
===
match
---
trailer [18974,18981]
trailer [18878,18885]
===
match
---
name: self [10682,10686]
name: self [10586,10590]
===
match
---
name: self [19934,19938]
name: self [19838,19842]
===
match
---
arglist [9811,9880]
arglist [9784,9853]
===
match
---
trailer [21464,21471]
trailer [21368,21375]
===
match
---
name: e [22162,22163]
name: e [22066,22067]
===
match
---
atom_expr [21624,21641]
atom_expr [21528,21545]
===
match
---
name: read_dags_from_db [4938,4955]
name: read_dags_from_db [4911,4928]
===
match
---
suite [8181,8441]
suite [8154,8414]
===
match
---
param [12252,12261]
param [12156,12165]
===
match
---
expr_stmt [2107,2116]
expr_stmt [2080,2089]
===
match
---
atom_expr [27653,27663]
atom_expr [27557,27567]
===
match
---
trailer [27278,27285]
trailer [27182,27189]
===
match
---
operator: = [4497,4498]
operator: = [4470,4471]
===
match
---
fstring_expr [17022,17033]
fstring_expr [16926,16937]
===
match
---
operator: , [4081,4082]
operator: , [4054,4055]
===
match
---
atom_expr [17074,17085]
atom_expr [16978,16989]
===
match
---
operator: = [26686,26687]
operator: = [26590,26591]
===
match
---
and_test [7803,7938]
and_test [7776,7911]
===
match
---
trailer [10630,10634]
trailer [10534,10538]
===
match
---
for_stmt [10643,10716]
for_stmt [10547,10620]
===
match
---
simple_stmt [16314,16374]
simple_stmt [16218,16278]
===
match
---
trailer [16697,16705]
trailer [16601,16609]
===
match
---
name: key [9594,9597]
name: key [9567,9570]
===
match
---
simple_stmt [1993,2029]
simple_stmt [1966,2002]
===
match
---
name: needs_perm_views [27555,27571]
name: needs_perm_views [27459,27475]
===
match
---
name: Union [1063,1068]
name: Union [1063,1068]
===
match
---
return_stmt [27508,27520]
return_stmt [27412,27424]
===
match
---
name: is_zipfile [11857,11867]
name: is_zipfile [11761,11771]
===
match
---
if_stmt [9685,10187]
if_stmt [9658,10160]
===
match
---
name: os [15658,15660]
name: os [15562,15564]
===
match
---
fstring_end: " [13258,13259]
fstring_end: " [13162,13163]
===
match
---
name: get [9149,9152]
name: get [9122,9125]
===
match
---
atom_expr [12405,12420]
atom_expr [12309,12324]
===
match
---
name: provide_session [6474,6489]
name: provide_session [6447,6462]
===
match
---
atom_expr [12581,12621]
atom_expr [12485,12525]
===
match
---
name: attempt [25625,25632]
name: attempt [25529,25536]
===
match
---
name: util [13479,13483]
name: util [13383,13387]
===
match
---
trailer [27180,27185]
trailer [27084,27089]
===
match
---
name: _process_modules [16239,16255]
name: _process_modules [16143,16159]
===
match
---
name: self [22278,22282]
name: self [22182,22186]
===
match
---
atom [12927,13269]
atom [12831,13173]
===
match
---
trailer [6795,6813]
trailer [6768,6786]
===
match
---
atom_expr [27533,27551]
atom_expr [27437,27455]
===
match
---
trailer [14337,14339]
trailer [14241,14243]
===
match
---
simple_stmt [23135,23185]
simple_stmt [23039,23089]
===
match
---
trailer [17886,17930]
trailer [17790,17834]
===
match
---
name: new_module [13709,13719]
name: new_module [13613,13623]
===
match
---
name: format_exc [25298,25308]
name: format_exc [25202,25212]
===
match
---
name: models [6752,6758]
name: models [6725,6731]
===
match
---
simple_stmt [10406,10452]
simple_stmt [10379,10425]
===
match
---
name: self [12246,12250]
name: self [12150,12154]
===
match
---
simple_stmt [26975,27025]
simple_stmt [26879,26929]
===
match
---
argument [16715,16727]
argument [16619,16631]
===
match
---
atom_expr [21939,21980]
atom_expr [21843,21884]
===
match
---
atom_expr [9820,9857]
atom_expr [9793,9830]
===
match
---
fstring_end: " [13179,13180]
fstring_end: " [13083,13084]
===
match
---
string: "Failed to import: %s" [13791,13813]
string: "Failed to import: %s" [13695,13717]
===
match
---
suite [10069,10111]
suite [10042,10084]
===
match
---
or_test [20949,20978]
or_test [20853,20882]
===
match
---
name: zip_info [15235,15243]
name: zip_info [15139,15147]
===
match
---
simple_stmt [17873,17931]
simple_stmt [17777,17835]
===
match
---
trailer [27131,27159]
trailer [27035,27063]
===
match
---
name: session [27810,27817]
name: session [27714,27721]
===
match
---
name: dags_hash [8391,8400]
name: dags_hash [8364,8373]
===
match
---
atom_expr [27132,27158]
atom_expr [27036,27062]
===
match
---
atom_expr [9640,9661]
atom_expr [9613,9634]
===
match
---
operator: = [16628,16629]
operator: = [16532,16533]
===
match
---
name: dag_num [23361,23368]
name: dag_num [23265,23272]
===
match
---
simple_stmt [18946,18983]
simple_stmt [18850,18887]
===
match
---
comparison [9254,9282]
comparison [9227,9255]
===
match
---
fstring_expr [12986,13014]
fstring_expr [12890,12918]
===
match
---
operator: , [20094,20095]
operator: , [19998,19999]
===
match
---
trailer [20877,20882]
trailer [20781,20786]
===
match
---
name: o [23408,23409]
name: o [23312,23313]
===
match
---
string: '' [21774,21776]
string: '' [21678,21680]
===
match
---
name: airflow [10341,10348]
name: airflow [10314,10321]
===
match
---
operator: = [16566,16567]
operator: = [16470,16471]
===
match
---
name: airflow [1446,1453]
name: airflow [1419,1426]
===
match
---
name: get_current [9054,9065]
name: get_current [9027,9038]
===
match
---
atom_expr [22994,23005]
atom_expr [22898,22909]
===
match
---
trailer [17478,17491]
trailer [17382,17395]
===
match
---
suite [11776,11833]
suite [11680,11737]
===
match
---
name: found_dags [21893,21903]
name: found_dags [21797,21807]
===
match
---
trailer [18401,18406]
trailer [18305,18310]
===
match
---
atom_expr [27772,27818]
atom_expr [27676,27722]
===
match
---
try_stmt [21411,22165]
try_stmt [21315,22069]
===
match
---
operator: , [4690,4691]
operator: , [4663,4664]
===
match
---
decorator [26604,26621]
decorator [26508,26525]
===
match
---
operator: = [13983,13984]
operator: = [13887,13888]
===
match
---
atom_expr [27186,27208]
atom_expr [27090,27112]
===
match
---
name: self [9139,9143]
name: self [9112,9116]
===
match
---
name: AirflowDagDuplicatedIdException [19066,19097]
name: AirflowDagDuplicatedIdException [18970,19001]
===
match
---
name: SCHEDULER_ZOMBIE_TASK_THRESHOLD [3557,3588]
name: SCHEDULER_ZOMBIE_TASK_THRESHOLD [3530,3561]
===
match
---
name: dag [18402,18405]
name: dag [18306,18309]
===
match
---
atom_expr [21168,21183]
atom_expr [21072,21087]
===
match
---
operator: , [21855,21856]
operator: , [21759,21760]
===
match
---
name: importlib [15507,15516]
name: importlib [15411,15420]
===
match
---
argument [6216,6228]
argument [6189,6201]
===
match
---
trailer [12442,12453]
trailer [12346,12357]
===
match
---
trailer [10206,10211]
trailer [10179,10184]
===
match
---
expr_stmt [12773,12828]
expr_stmt [12677,12732]
===
match
---
suite [22126,22165]
suite [22030,22069]
===
match
---
trailer [23334,23336]
trailer [23238,23240]
===
match
---
simple_stmt [19310,19347]
simple_stmt [19214,19251]
===
match
---
string: "You should pass the read_dags_from_db parameter." [4383,4433]
string: "You should pass the read_dags_from_db parameter." [4356,4406]
===
match
---
fstring_string:           [23862,23871]
fstring_string:           [23766,23775]
===
match
---
atom_expr [27866,27876]
atom_expr [27770,27780]
===
match
---
string: 'core' [5358,5364]
string: 'core' [5331,5337]
===
match
---
name: _bag_dag [18876,18884]
name: _bag_dag [18780,18788]
===
match
---
suite [16121,16210]
suite [16025,16114]
===
match
---
name: subdag [10647,10653]
name: subdag [10551,10557]
===
match
---
operator: = [14119,14120]
operator: = [14023,14024]
===
match
---
annassign [2056,2067]
annassign [2029,2040]
===
match
---
name: file_last_changed [12131,12148]
name: file_last_changed [12035,12052]
===
match
---
trailer [3861,3872]
trailer [3834,3845]
===
match
---
atom_expr [4833,4851]
atom_expr [4806,4824]
===
match
---
trailer [8841,8851]
trailer [8814,8824]
===
match
---
name: self [12581,12585]
name: self [12485,12489]
===
match
---
trailer [6063,6068]
trailer [6036,6041]
===
match
---
atom_expr [9776,9894]
atom_expr [9749,9867]
===
match
---
name: zipfile [14237,14244]
name: zipfile [14141,14148]
===
match
---
param [17569,17573]
param [17473,17477]
===
insert-tree
---
simple_stmt [1248,1414]
    import_from [1248,1413]
        dotted_name [1253,1271]
            name: airflow [1253,1260]
            name: exceptions [1261,1271]
        import_as_names [1285,1411]
            name: AirflowClusterPolicyViolation [1285,1314]
            operator: , [1314,1315]
            name: AirflowDagCycleException [1320,1344]
            operator: , [1344,1345]
            name: AirflowDagDuplicatedIdException [1350,1381]
            operator: , [1381,1382]
            name: AirflowTimetableInvalid [1387,1410]
            operator: , [1410,1411]
to
file_input [788,27898]
at 17
===
insert-node
---
name: DagBag [2098,2104]
to
classdef [2119,27898]
at 0
===
insert-node
---
name: LoggingMixin [2105,2117]
to
classdef [2119,27898]
at 1
===
insert-tree
---
simple_stmt [2124,3450]
    string: """     A dagbag is a collection of dags, parsed out of a folder tree and has high     level configuration settings, like what database to use as a backend and     what executor to use to fire off tasks. This makes it easier to run     distinct environments for say production and development, tests, or for     different teams or security profiles. What would have been system level     settings are now dagbag level so that one system can run multiple,     independent settings sets.      :param dag_folder: the folder to scan to find DAGs     :type dag_folder: unicode     :param include_examples: whether to include the examples that ship         with airflow or not     :type include_examples: bool     :param include_smart_sensor: whether to include the smart sensor native         DAGs that create the smart sensor operators for whole cluster     :type include_smart_sensor: bool     :param read_dags_from_db: Read DAGs from DB if ``True`` is passed.         If ``False`` DAGs are read from python files.     :type read_dags_from_db: bool     :param load_op_links: Should the extra operator link be loaded via plugins when         de-serializing the DAG? This flag is set to False in Scheduler so that Extra Operator links         are not loaded to not run User code in Scheduler.     :type load_op_links: bool     """ [2124,3449]
to
suite [2146,27898]
at 0
===
insert-node
---
return_stmt [10457,10468]
to
simple_stmt [10484,10565]
at 0
===
delete-tree
---
simple_stmt [1248,1441]
    import_from [1248,1440]
        dotted_name [1253,1271]
            name: airflow [1253,1260]
            name: exceptions [1261,1271]
        import_as_names [1285,1438]
            name: AirflowClusterPolicyViolation [1285,1314]
            operator: , [1314,1315]
            name: AirflowDagCycleException [1320,1344]
            operator: , [1344,1345]
            name: AirflowDagDuplicatedIdException [1350,1381]
            operator: , [1381,1382]
            name: AirflowTimetableInvalid [1387,1410]
            operator: , [1410,1411]
            name: SerializedDagNotFound [1416,1437]
            operator: , [1437,1438]
===
delete-node
---
name: DagBag [2125,2131]
===
===
delete-node
---
name: LoggingMixin [2132,2144]
===
===
delete-tree
---
simple_stmt [2151,3477]
    string: """     A dagbag is a collection of dags, parsed out of a folder tree and has high     level configuration settings, like what database to use as a backend and     what executor to use to fire off tasks. This makes it easier to run     distinct environments for say production and development, tests, or for     different teams or security profiles. What would have been system level     settings are now dagbag level so that one system can run multiple,     independent settings sets.      :param dag_folder: the folder to scan to find DAGs     :type dag_folder: unicode     :param include_examples: whether to include the examples that ship         with airflow or not     :type include_examples: bool     :param include_smart_sensor: whether to include the smart sensor native         DAGs that create the smart sensor operators for whole cluster     :type include_smart_sensor: bool     :param read_dags_from_db: Read DAGs from DB if ``True`` is passed.         If ``False`` DAGs are read from python files.     :type read_dags_from_db: bool     :param load_op_links: Should the extra operator link be loaded via plugins when         de-serializing the DAG? This flag is set to False in Scheduler so that Extra Operator links         are not loaded to not run User code in Scheduler.     :type load_op_links: bool     """ [2151,3476]
===
delete-tree
---
raise_stmt [10484,10564]
    atom_expr [10490,10564]
        name: SerializedDagNotFound [10490,10511]
        trailer [10511,10564]
            fstring [10512,10563]
                fstring_start: f" [10512,10514]
                fstring_string: DAG ' [10514,10519]
                fstring_expr [10519,10527]
                    operator: { [10519,10520]
                    name: dag_id [10520,10526]
                    operator: } [10526,10527]
                fstring_string: ' not found in serialized_dag table [10527,10562]
                fstring_end: " [10562,10563]
