===
match
---
name: DagNotFound [5058,5069]
name: DagNotFound [4889,4900]
===
match
---
name: BadRequest [4232,4242]
name: BadRequest [4063,4073]
===
match
---
suite [3086,3209]
suite [2917,3040]
===
match
---
name: filter [2793,2799]
name: filter [2624,2630]
===
match
---
operator: { [5230,5231]
operator: { [5061,5062]
===
match
---
name: query [1782,1787]
name: query [1759,1764]
===
match
---
factor [2800,2819]
factor [2631,2650]
===
match
---
name: dump [3370,3374]
name: dump [3201,3205]
===
match
---
name: one_or_none [3686,3697]
name: one_or_none [3517,3528]
===
match
---
operator: { [3755,3756]
operator: { [3586,3587]
===
match
---
number: 1 [4037,4038]
number: 1 [3868,3869]
===
match
---
name: request [3823,3830]
name: request [3654,3661]
===
match
---
dotted_name [1330,1348]
dotted_name [1330,1348]
===
match
---
name: common [4944,4950]
name: common [4775,4781]
===
match
---
operator: = [3844,3845]
operator: = [3675,3676]
===
match
---
trailer [4357,4370]
trailer [4188,4201]
===
match
---
name: security [1588,1596]
name: security [1565,1573]
===
match
---
decorated [1997,2488]
decorated [1974,2319]
===
match
---
name: limit [2648,2653]
name: limit [2479,2484]
===
match
---
trailer [2782,2792]
trailer [2613,2623]
===
match
---
name: dag_id [3293,3299]
name: dag_id [3124,3130]
===
match
---
atom_expr [3375,3428]
atom_expr [3206,3259]
===
match
---
name: any [3117,3120]
name: any [2948,2951]
===
match
---
name: airflow [1540,1547]
name: airflow [1517,1524]
===
match
---
trailer [1655,1668]
trailer [1632,1645]
===
match
---
name: setattr [4408,4415]
name: setattr [4239,4246]
===
match
---
import_from [827,866]
import_from [827,866]
===
match
---
operator: = [2767,2768]
operator: = [2598,2599]
===
match
---
fstring_end: " [1959,1960]
fstring_end: " [1936,1937]
===
match
---
name: DagModel [3284,3292]
name: DagModel [3115,3123]
===
match
---
name: detail [2394,2400]
name: detail [2225,2231]
===
match
---
string: "Only `is_paused` field can be updated through the REST API" [4076,4136]
string: "Only `is_paused` field can be updated through the REST API" [3907,3967]
===
match
---
operator: > [4035,4036]
operator: > [3866,3867]
===
match
---
import_from [1535,1584]
import_from [1512,1561]
===
match
---
name: dags_query [3179,3189]
name: dags_query [3010,3020]
===
match
---
name: DagModel [2783,2791]
name: DagModel [2614,2622]
===
match
---
operator: == [3133,3135]
operator: == [2964,2966]
===
match
---
expr_stmt [3990,4006]
expr_stmt [3821,3837]
===
match
---
trailer [2065,2078]
trailer [2042,2055]
===
match
---
name: dags [3389,3393]
name: dags [3220,3224]
===
match
---
name: airflow [1187,1194]
name: airflow [1187,1194]
===
match
---
name: g [816,817]
name: g [816,817]
===
match
---
if_stmt [2338,2449]
if_stmt [2173,2280]
===
match
---
trailer [3328,3332]
trailer [3159,3163]
===
match
---
trailer [1797,1804]
trailer [1774,1781]
===
match
---
string: """Delete the specific DAG.""" [4669,4699]
string: """Delete the specific DAG.""" [4500,4530]
===
match
---
name: offset [3301,3307]
name: offset [3132,3138]
===
match
---
simple_stmt [3588,3618]
simple_stmt [3419,3449]
===
match
---
atom [3102,3157]
atom [2933,2988]
===
match
---
fstring_string: ' are still running [5238,5257]
fstring_string: ' are still running [5069,5088]
===
match
---
trailer [4415,4458]
trailer [4246,4289]
===
match
---
if_stmt [3078,3209]
if_stmt [2909,3040]
===
match
---
operator: = [2167,2168]
operator: = [2131,2132]
===
match
---
argument [5030,5045]
argument [4861,4876]
===
match
---
operator: , [1083,1084]
operator: , [1083,1084]
===
match
---
trailer [2776,2782]
trailer [2607,2613]
===
match
---
operator: } [5117,5118]
operator: } [4948,4949]
===
match
---
expr_stmt [3007,3073]
expr_stmt [2838,2904]
===
match
---
atom [2594,2616]
atom [2425,2447]
===
match
---
string: "DAG not found" [1890,1905]
string: "DAG not found" [1867,1882]
===
match
---
return_stmt [2453,2487]
return_stmt [2284,2318]
===
match
---
comparison [1854,1865]
comparison [1831,1842]
===
match
---
name: dag_id [5231,5237]
name: dag_id [5062,5068]
===
match
---
name: DagModel [3038,3046]
name: DagModel [2869,2877]
===
match
---
name: dags_query [3020,3030]
name: dags_query [2851,2861]
===
match
---
atom_expr [1974,1994]
atom_expr [1951,1971]
===
match
---
fstring [3739,3775]
fstring [3570,3606]
===
match
---
operator: , [2672,2673]
operator: , [2503,2504]
===
match
---
simple_stmt [4379,4404]
simple_stmt [4210,4235]
===
match
---
name: dag [4416,4419]
name: dag [4247,4250]
===
match
---
name: dags_query [3166,3176]
name: dags_query [2997,3007]
===
match
---
trailer [3189,3196]
trailer [3020,3027]
===
match
---
name: dag_id [1814,1820]
name: dag_id [1791,1797]
===
match
---
expr_stmt [3622,3699]
expr_stmt [3453,3530]
===
match
---
trailer [3651,3658]
trailer [3482,3489]
===
match
---
name: dag [1429,1432]
name: dag [1406,1409]
===
match
---
operator: = [4390,4391]
operator: = [4221,4222]
===
match
---
expr_stmt [4320,4370]
expr_stmt [4151,4201]
===
match
---
string: "DAG not found" [2377,2392]
string: "DAG not found" [2208,2223]
===
match
---
name: session [3548,3555]
name: session [3379,3386]
===
match
---
trailer [2885,2895]
trailer [2716,2726]
===
match
---
name: session [1774,1781]
name: session [1751,1758]
===
match
---
name: DagModel [2904,2912]
name: DagModel [2735,2743]
===
match
---
trailer [2912,2922]
trailer [2743,2753]
===
match
---
raise_stmt [4226,4311]
raise_stmt [4057,4142]
===
match
---
import_from [910,933]
import_from [910,933]
===
match
---
atom_expr [3807,3853]
atom_expr [3638,3684]
===
match
---
name: NotFound [2368,2376]
name: NotFound [2199,2207]
===
match
---
atom_expr [3823,3835]
atom_expr [3654,3666]
===
match
---
simple_stmt [4408,4459]
simple_stmt [4239,4290]
===
match
---
name: security [4515,4523]
name: security [4346,4354]
===
match
---
operator: , [1095,1096]
operator: , [1095,1096]
===
match
---
dotted_name [1462,1478]
dotted_name [1439,1455]
===
match
---
name: dags [3257,3261]
name: dags [3088,3092]
===
match
---
simple_stmt [1025,1106]
simple_stmt [1025,1106]
===
match
---
trailer [3685,3697]
trailer [3516,3528]
===
match
---
name: NoContent [972,981]
name: NoContent [972,981]
===
match
---
comparison [3659,3684]
comparison [3490,3515]
===
match
---
name: update_mask [4332,4343]
name: update_mask [4163,4174]
===
match
---
atom_expr [1644,1668]
atom_expr [1621,1645]
===
match
---
name: update_mask [4160,4171]
name: update_mask [3991,4002]
===
match
---
operator: , [1372,1373]
operator: , [1372,1373]
===
match
---
name: session [3845,3852]
name: session [3676,3683]
===
match
---
fstring_start: f" [2401,2403]
fstring_start: f" [2232,2234]
===
match
---
fstring_start: f" [5196,5198]
fstring_start: f" [5027,5029]
===
match
---
param [2674,2691]
param [2505,2522]
===
match
---
trailer [1626,1642]
trailer [1603,1619]
===
match
---
decorated [3432,4512]
decorated [3263,4343]
===
match
---
name: dag_schema [4491,4501]
name: dag_schema [4322,4332]
===
match
---
name: tags [2692,2696]
name: tags [2523,2527]
===
match
---
name: readable_dags [3058,3071]
name: readable_dags [2889,2902]
===
match
---
name: dag_id [1701,1707]
name: dag_id [1678,1684]
===
match
---
name: dag_id [4633,4639]
name: dag_id [4464,4470]
===
match
---
name: ACTION_CAN_DELETE [4554,4571]
name: ACTION_CAN_DELETE [4385,4402]
===
match
---
dotted_name [1111,1143]
dotted_name [1111,1143]
===
match
---
name: current_app [2945,2956]
name: current_app [2776,2787]
===
match
---
simple_stmt [3794,3854]
simple_stmt [3625,3685]
===
match
---
name: dag_id [1938,1944]
name: dag_id [1915,1921]
===
match
---
operator: , [5281,5282]
operator: , [5112,5113]
===
match
---
name: len [4018,4021]
name: len [3849,3852]
===
match
---
trailer [3635,3641]
trailer [3466,3472]
===
match
---
operator: , [3835,3836]
operator: , [3666,3667]
===
match
---
trailer [3030,3037]
trailer [2861,2868]
===
match
---
atom_expr [3121,3132]
atom_expr [2952,2963]
===
match
---
dotted_name [1998,2022]
dotted_name [1975,1999]
===
match
---
trailer [3283,3300]
trailer [3114,3131]
===
match
---
tfpdef [4646,4662]
tfpdef [4477,4493]
===
match
---
name: update_mask [4146,4157]
name: update_mask [3977,3988]
===
match
---
simple_stmt [3166,3209]
simple_stmt [2997,3040]
===
match
---
name: airflow [987,994]
name: airflow [987,994]
===
match
---
name: DagModel [2821,2829]
name: DagModel [2652,2660]
===
match
---
import_from [1457,1497]
import_from [1434,1474]
===
match
---
suite [2110,2488]
suite [2087,2319]
===
match
---
atom_expr [1881,1961]
atom_expr [1858,1938]
===
match
---
fstring [1914,1960]
fstring [1891,1937]
===
match
---
atom_expr [1615,1642]
atom_expr [1592,1619]
===
match
---
operator: , [2662,2663]
operator: , [2493,2494]
===
match
---
param [4646,4662]
param [4477,4493]
===
match
---
dotted_name [1414,1432]
dotted_name [1391,1409]
===
match
---
name: ACTION_CAN_EDIT [3472,3487]
name: ACTION_CAN_EDIT [3303,3318]
===
match
---
comparison [1805,1830]
comparison [1782,1807]
===
match
---
name: current_app [803,814]
name: current_app [803,814]
===
match
---
atom_expr [2547,2571]
atom_expr [2378,2402]
===
match
---
name: marshmallow [832,843]
name: marshmallow [832,843]
===
match
---
trailer [2529,2545]
trailer [2360,2376]
===
match
---
name: provide_session [1673,1688]
name: provide_session [1650,1665]
===
match
---
suite [2353,2449]
suite [2184,2280]
===
match
---
atom_expr [3234,3250]
atom_expr [3065,3081]
===
match
---
if_stmt [3704,3777]
if_stmt [3535,3608]
===
match
---
name: session [3837,3844]
name: session [3668,3675]
===
match
---
operator: , [1321,1322]
operator: , [1321,1322]
===
match
---
operator: = [4002,4003]
operator: = [3833,3834]
===
match
---
trailer [3641,3651]
trailer [3472,3482]
===
match
---
trailer [2829,2839]
trailer [2660,2670]
===
match
---
simple_stmt [910,934]
simple_stmt [910,934]
===
match
---
name: session [4646,4653]
name: session [4477,4484]
===
match
---
trailer [3057,3072]
trailer [2888,2903]
===
match
---
fstring [2401,2447]
fstring [2232,2278]
===
match
---
name: DagModel [3642,3650]
name: DagModel [3473,3481]
===
match
---
name: permissions [2025,2036]
name: permissions [2002,2013]
===
match
---
trailer [2879,2885]
trailer [2710,2716]
===
match
---
name: update_mask [4358,4369]
name: update_mask [4189,4200]
===
match
---
name: ValidationError [851,866]
name: ValidationError [851,866]
===
match
---
operator: @ [4514,4515]
operator: @ [4345,4346]
===
match
---
name: DagNotFound [1374,1385]
name: DagNotFound [1374,1385]
===
match
---
simple_stmt [1967,1995]
simple_stmt [1944,1972]
===
match
---
if_stmt [2732,2924]
if_stmt [2563,2755]
===
match
---
dotted_name [4932,4963]
dotted_name [4763,4794]
===
match
---
name: DagTag [3121,3127]
name: DagTag [2952,2958]
===
match
---
name: DagModel [2801,2809]
name: DagModel [2632,2640]
===
match
---
import_from [1025,1105]
import_from [1025,1105]
===
match
---
name: requires_access [4524,4539]
name: requires_access [4355,4370]
===
match
---
name: str [4641,4644]
name: str [4472,4475]
===
match
---
argument [3389,3398]
argument [3220,3229]
===
match
---
name: airflow [4932,4939]
name: airflow [4763,4770]
===
match
---
suite [4991,5047]
suite [4822,4878]
===
match
---
expr_stmt [4379,4403]
expr_stmt [4210,4234]
===
match
---
trailer [1843,1845]
trailer [1820,1822]
===
match
---
trailer [2196,2204]
trailer [2160,2168]
===
match
---
comparison [4018,4038]
comparison [3849,3869]
===
match
---
atom_expr [3489,3513]
atom_expr [3320,3344]
===
match
---
suite [3583,4512]
suite [3414,4343]
===
match
---
arglist [5022,5045]
arglist [4853,4876]
===
match
---
name: is_subdag [2810,2819]
name: is_subdag [2641,2650]
===
match
---
simple_stmt [2859,2924]
simple_stmt [2690,2755]
===
match
---
simple_stmt [3214,3252]
simple_stmt [3045,3083]
===
match
---
name: permissions [4542,4553]
name: permissions [4373,4384]
===
match
---
expr_stmt [2929,3001]
expr_stmt [2760,2832]
===
match
---
param [1701,1708]
param [1678,1685]
===
match
---
name: NotFound [1097,1105]
name: NotFound [1097,1105]
===
match
---
trailer [3046,3053]
trailer [2877,2884]
===
match
---
operator: , [1293,1294]
operator: , [1293,1294]
===
match
---
fstring_start: f" [3739,3741]
fstring_start: f" [3570,3572]
===
match
---
simple_stmt [2708,2728]
simple_stmt [2539,2559]
===
match
---
atom_expr [2368,2448]
atom_expr [2199,2279]
===
match
---
expr_stmt [3257,3334]
expr_stmt [3088,3165]
===
match
---
name: permissions [2054,2065]
name: permissions [2031,2042]
===
match
---
fstring_string: ' not found [3763,3774]
fstring_string: ' not found [3594,3605]
===
match
---
name: DAG [2163,2166]
name: DAG [2127,2130]
===
match
---
suite [1866,1962]
suite [1843,1939]
===
match
---
operator: = [3413,3414]
operator: = [3244,3245]
===
match
---
simple_stmt [3007,3074]
simple_stmt [2838,2905]
===
match
---
operator: } [3762,3763]
operator: } [3593,3594]
===
match
---
simple_stmt [2158,2205]
simple_stmt [2122,2169]
===
match
---
simple_stmt [4927,4982]
simple_stmt [4758,4813]
===
match
---
atom_expr [4491,4511]
atom_expr [4322,4342]
===
match
---
if_stmt [4015,4138]
if_stmt [3846,3969]
===
match
---
trailer [2036,2052]
trailer [2013,2029]
===
match
---
operator: { [1937,1938]
operator: { [1914,1915]
===
match
---
name: ValidationError [3865,3880]
name: ValidationError [3696,3711]
===
match
---
name: requires_access [2007,2022]
name: requires_access [1984,1999]
===
match
---
argument [4243,4310]
argument [4074,4141]
===
match
---
name: format_parameters [2576,2593]
name: format_parameters [2407,2424]
===
match
---
name: str [3943,3946]
name: str [3774,3777]
===
match
---
except_clause [3858,3887]
except_clause [3689,3718]
===
match
---
name: NotFound [1881,1889]
name: NotFound [1858,1866]
===
match
---
name: dag_schema [1283,1293]
name: dag_schema [1283,1293]
===
match
---
trailer [3233,3251]
trailer [3064,3082]
===
match
---
atom_expr [2994,3000]
atom_expr [2825,2831]
===
match
---
operator: , [2545,2546]
operator: , [2376,2377]
===
match
---
try_stmt [4987,5260]
try_stmt [4818,5091]
===
match
---
operator: , [2690,2691]
operator: , [2521,2522]
===
match
---
argument [3400,3427]
argument [3231,3258]
===
match
---
operator: = [2696,2697]
operator: = [2527,2528]
===
match
---
name: dump [2478,2482]
name: dump [2309,2313]
===
match
---
param [4633,4645]
param [4464,4476]
===
match
---
name: DagModel [1788,1796]
name: DagModel [1765,1773]
===
match
---
string: """Update the specific DAG""" [3588,3617]
string: """Update the specific DAG""" [3419,3448]
===
match
---
name: BadRequest [1085,1095]
name: BadRequest [1085,1095]
===
match
---
name: update_mask [3565,3576]
name: update_mask [3396,3407]
===
match
---
name: airflow [1330,1337]
name: airflow [1330,1337]
===
match
---
simple_stmt [2929,3002]
simple_stmt [2760,2833]
===
match
---
arglist [1890,1960]
arglist [1867,1937]
===
match
---
name: AirflowException [1356,1372]
name: AirflowException [1356,1372]
===
match
---
simple_stmt [2115,2141]
simple_stmt [2092,2118]
===
match
---
return_stmt [3340,3429]
return_stmt [3171,3260]
===
match
---
simple_stmt [1875,1962]
simple_stmt [1852,1939]
===
match
---
atom_expr [3103,3140]
atom_expr [2934,2971]
===
match
---
name: BadRequest [4058,4068]
name: BadRequest [3889,3899]
===
match
---
name: BadRequest [3903,3913]
name: BadRequest [3734,3744]
===
match
---
if_stmt [4183,4312]
if_stmt [4014,4143]
===
match
---
operator: = [2943,2944]
operator: = [2774,2775]
===
match
---
atom_expr [4573,4597]
atom_expr [4404,4428]
===
match
---
atom_expr [3020,3073]
atom_expr [2851,2904]
===
match
---
atom_expr [3943,3960]
atom_expr [3774,3791]
===
match
---
suite [5160,5260]
suite [4991,5091]
===
match
---
trailer [3196,3208]
trailer [3027,3039]
===
match
---
name: total_entries [3400,3413]
name: total_entries [3231,3244]
===
match
---
atom_expr [5000,5046]
atom_expr [4831,4877]
===
match
---
name: airflow [939,946]
name: airflow [939,946]
===
match
---
name: query [2777,2782]
name: query [2608,2613]
===
match
---
trailer [2792,2799]
trailer [2623,2630]
===
match
---
simple_stmt [3095,3158]
simple_stmt [2926,2989]
===
match
---
operator: , [4571,4572]
operator: , [4402,4403]
===
match
---
operator: = [3942,3943]
operator: = [3773,3774]
===
match
---
name: RESOURCE_DAG [4585,4597]
name: RESOURCE_DAG [4416,4428]
===
match
---
operator: @ [2618,2619]
operator: @ [2449,2450]
===
match
---
atom_expr [4408,4458]
atom_expr [4239,4289]
===
match
---
simple_stmt [4463,4480]
simple_stmt [4294,4311]
===
match
---
expr_stmt [2756,2840]
expr_stmt [2587,2671]
===
match
---
parameters [3547,3582]
parameters [3378,3413]
===
match
---
fstring_string: ' not found [5118,5129]
fstring_string: ' not found [4949,4960]
===
match
---
param [2692,2701]
param [2523,2532]
===
match
---
name: dags_query [3264,3274]
name: dags_query [3095,3105]
===
match
---
operator: @ [2490,2491]
operator: @ [2321,2322]
===
match
---
name: delete_dag [5011,5021]
name: delete_dag [4842,4852]
===
match
---
fstring_string:  was not found [2432,2446]
fstring_string:  was not found [2263,2277]
===
match
---
operator: == [3675,3677]
operator: == [3506,3508]
===
match
---
param [2664,2673]
param [2495,2504]
===
match
---
name: dags [3394,3398]
name: dags [3225,3229]
===
match
---
simple_stmt [4146,4175]
simple_stmt [3977,4006]
===
match
---
arglist [2377,2447]
arglist [2208,2278]
===
match
---
fstring_expr [2424,2432]
fstring_expr [2255,2263]
===
match
---
param [3565,3581]
param [3396,3412]
===
match
---
name: load [3818,3822]
name: load [3649,3653]
===
match
---
if_stmt [1851,1962]
if_stmt [1828,1939]
===
match
---
simple_stmt [1768,1846]
simple_stmt [1745,1823]
===
match
---
import_as_names [1356,1408]
import_as_names [1356,1385]
===
match
---
funcdef [4618,5287]
funcdef [4449,5118]
===
match
---
name: permissions [3489,3500]
name: permissions [3320,3331]
===
match
---
name: format_parameters [1164,1181]
name: format_parameters [1164,1181]
===
match
---
name: tag [3145,3148]
name: tag [2976,2979]
===
match
---
name: dag_schema [1974,1984]
name: dag_schema [1951,1961]
===
match
---
name: Session [1527,1534]
name: Session [1504,1511]
===
match
---
sync_comp_for [3141,3156]
sync_comp_for [2972,2987]
===
match
---
param [2648,2654]
param [2479,2485]
===
match
---
trailer [2477,2482]
trailer [2308,2313]
===
match
---
operator: = [4249,4250]
operator: = [4080,4081]
===
match
---
name: dag_detail_schema [1260,1277]
name: dag_detail_schema [1260,1277]
===
match
---
name: api_connexion [995,1008]
name: api_connexion [995,1008]
===
match
---
atom [4540,4599]
atom [4371,4430]
===
match
---
name: dag_id [2425,2431]
name: dag_id [2256,2262]
===
match
---
atom_expr [4347,4370]
atom_expr [4178,4201]
===
match
---
operator: @ [3432,3433]
operator: @ [3263,3264]
===
match
---
name: permissions [2518,2529]
name: permissions [2349,2360]
===
match
---
decorator [3432,3517]
decorator [3263,3348]
===
match
---
trailer [3127,3132]
trailer [2958,2963]
===
match
---
name: detail [3936,3942]
name: detail [3767,3773]
===
match
---
name: total_entries [3414,3427]
name: total_entries [3245,3258]
===
match
---
name: exceptions [1338,1348]
name: exceptions [1338,1348]
===
match
---
name: session [4463,4470]
name: session [4294,4301]
===
match
---
operator: = [3805,3806]
operator: = [3636,3637]
===
match
---
operator: } [2431,2432]
operator: } [2262,2263]
===
match
---
suite [3888,3962]
suite [3719,3793]
===
match
---
simple_stmt [4226,4312]
simple_stmt [4057,4143]
===
match
---
parameters [1700,1717]
parameters [1677,1694]
===
match
---
operator: { [2424,2425]
operator: { [2255,2256]
===
match
---
operator: @ [4601,4602]
operator: @ [4432,4433]
===
match
---
name: get_dag [2189,2196]
name: get_dag [2153,2160]
===
match
---
dotted_name [872,897]
dotted_name [872,897]
===
match
---
simple_stmt [5265,5287]
simple_stmt [5096,5118]
===
match
---
name: experimental [4951,4963]
name: experimental [4782,4794]
===
match
---
raise_stmt [4052,4137]
raise_stmt [3883,3968]
===
match
---
trailer [4477,4479]
trailer [4308,4310]
===
match
---
atom_expr [2054,2078]
atom_expr [2031,2055]
===
match
---
operator: = [3228,3229]
operator: = [3059,3060]
===
match
---
decorator [3517,3534]
decorator [3348,3365]
===
match
---
param [2102,2108]
param [2079,2085]
===
match
---
argument [5189,5258]
argument [5020,5089]
===
match
---
trailer [3274,3283]
trailer [3105,3114]
===
match
---
trailer [3374,3429]
trailer [3205,3260]
===
match
---
name: session [1554,1561]
name: session [1531,1538]
===
match
---
raise_stmt [5169,5259]
raise_stmt [5000,5090]
===
match
---
atom [1613,1670]
atom [1590,1647]
===
match
---
trailer [4506,4511]
trailer [4337,4342]
===
match
---
trailer [5188,5259]
trailer [5019,5090]
===
match
---
operator: , [1448,1449]
operator: , [1425,1426]
===
match
---
trailer [3913,3961]
trailer [3744,3792]
===
match
---
decorator [1997,2082]
decorator [1974,2059]
===
match
---
trailer [3248,3250]
trailer [3079,3081]
===
match
---
dotted_name [1503,1519]
dotted_name [1480,1496]
===
match
---
name: session [2655,2662]
name: session [2486,2493]
===
match
---
trailer [2970,2993]
trailer [2801,2824]
===
match
---
import_as_names [1440,1456]
import_as_names [1417,1433]
===
match
---
string: "Only `is_paused` field can be updated through the REST API" [4250,4310]
string: "Only `is_paused` field can be updated through the REST API" [4081,4141]
===
match
---
dictorsetmaker [2595,2615]
dictorsetmaker [2426,2446]
===
match
---
name: patch_body [4434,4444]
name: patch_body [4265,4275]
===
match
---
name: provide_session [2619,2634]
name: provide_session [2450,2465]
===
match
---
name: sql [883,886]
name: sql [883,886]
===
match
---
name: offset [3308,3314]
name: offset [3139,3145]
===
match
---
name: settings [1511,1519]
name: settings [1488,1496]
===
match
---
atom_expr [3903,3961]
atom_expr [3734,3792]
===
match
---
name: filter [3652,3658]
name: filter [3483,3489]
===
match
---
atom [3458,3515]
atom [3289,3346]
===
match
---
suite [5070,5132]
suite [4901,4963]
===
match
---
suite [2850,2924]
suite [2681,2755]
===
match
---
name: security [3433,3441]
name: security [3264,3272]
===
match
---
trailer [3822,3853]
trailer [3653,3684]
===
match
---
trailer [2809,2819]
trailer [2640,2650]
===
match
---
atom_expr [3038,3072]
atom_expr [2869,2903]
===
match
---
not_test [3707,3714]
not_test [3538,3545]
===
match
---
operator: ~ [2800,2801]
operator: ~ [2631,2632]
===
match
---
if_stmt [3966,4404]
if_stmt [3797,4235]
===
match
---
trailer [5021,5046]
trailer [4852,4877]
===
match
---
name: limit [3316,3321]
name: limit [3147,3152]
===
match
---
dotted_name [4515,4539]
dotted_name [4346,4370]
===
match
---
name: NoContent [5272,5281]
name: NoContent [5103,5112]
===
match
---
name: order_by [3275,3283]
name: order_by [3106,3114]
===
match
---
operator: , [817,818]
operator: , [817,818]
===
match
---
dotted_name [987,1008]
dotted_name [987,1008]
===
match
---
operator: , [5028,5029]
operator: , [4859,4860]
===
match
---
file_input [785,5287]
file_input [785,5118]
===
match
---
trailer [4171,4174]
trailer [4002,4005]
===
match
---
atom_expr [4232,4311]
atom_expr [4063,4142]
===
match
---
fstring_start: f" [1914,1916]
fstring_start: f" [1891,1893]
===
match
---
name: dag [4507,4510]
name: dag [4338,4341]
===
match
---
name: or_ [905,908]
name: or_ [905,908]
===
match
---
atom_expr [4434,4457]
atom_expr [4265,4288]
===
match
---
atom [4004,4006]
atom [3835,3837]
===
match
---
trailer [3817,3822]
trailer [3648,3653]
===
match
---
decorator [2575,2618]
decorator [2406,2449]
===
match
---
import_as_names [803,826]
import_as_names [803,826]
===
match
---
trailer [2967,2970]
trailer [2798,2801]
===
match
---
operator: } [4005,4006]
operator: } [3836,3837]
===
match
---
name: detail [4243,4249]
name: detail [4074,4080]
===
match
---
name: filter [3190,3196]
name: filter [3021,3027]
===
match
---
decorator [1672,1689]
decorator [1649,1666]
===
match
---
atom_expr [3347,3429]
atom_expr [3178,3260]
===
match
---
operator: @ [1672,1673]
operator: @ [1649,1650]
===
match
---
atom_expr [4320,4344]
atom_expr [4151,4175]
===
match
---
name: security [1470,1478]
name: security [1447,1455]
===
match
---
import_as_names [1151,1181]
import_as_names [1151,1181]
===
match
---
name: tag [3136,3139]
name: tag [2967,2970]
===
match
---
trailer [2376,2448]
trailer [2207,2279]
===
match
---
name: all [3329,3332]
name: all [3160,3163]
===
match
---
name: dag_id [3047,3053]
name: dag_id [2878,2884]
===
match
---
suite [2703,3430]
suite [2534,3261]
===
match
---
raise_stmt [1875,1961]
raise_stmt [1852,1938]
===
match
---
atom [1614,1669]
atom [1591,1646]
===
match
---
comparison [3121,3139]
comparison [2952,2970]
===
match
---
argument [4069,4136]
argument [3900,3967]
===
match
---
trailer [1813,1820]
trailer [1790,1797]
===
match
---
name: patch_body_ [3990,4001]
name: patch_body_ [3821,3832]
===
match
---
operator: , [3398,3399]
operator: , [3229,3230]
===
match
---
fstring_expr [1937,1945]
fstring_expr [1914,1922]
===
match
---
trailer [3244,3248]
trailer [3075,3079]
===
match
---
name: permissions [1644,1655]
name: permissions [1621,1632]
===
match
---
decorators [1587,1689]
decorators [1564,1666]
===
match
---
simple_stmt [934,982]
simple_stmt [934,982]
===
match
---
name: session [2872,2879]
name: session [2703,2710]
===
match
---
expr_stmt [2859,2923]
expr_stmt [2690,2754]
===
match
---
string: 'limit' [2595,2602]
string: 'limit' [2426,2433]
===
match
---
name: dags_query [3234,3244]
name: dags_query [3065,3075]
===
match
---
name: dump [4502,4506]
name: dump [4333,4337]
===
match
---
trailer [3053,3057]
trailer [2884,2888]
===
match
---
operator: = [2685,2686]
operator: = [2516,2517]
===
match
---
dotted_name [3433,3457]
dotted_name [3264,3288]
===
match
---
name: api_connexion [1038,1051]
name: api_connexion [1038,1051]
===
match
---
import_from [1409,1456]
import_from [1386,1433]
===
match
---
name: airflow [915,922]
name: airflow [915,922]
===
match
---
fstring_end: " [5129,5130]
fstring_end: " [4960,4961]
===
match
---
name: cond [3095,3099]
name: cond [2926,2930]
===
match
---
operator: , [4419,4420]
operator: , [4250,4251]
===
match
---
string: """Get basic information about a DAG.""" [1723,1763]
string: """Get basic information about a DAG.""" [1700,1740]
===
match
---
name: dump [1985,1989]
name: dump [1962,1966]
===
match
---
name: permissions [2547,2558]
name: permissions [2378,2389]
===
match
---
suite [3715,3777]
suite [3546,3608]
===
match
---
atom [2516,2573]
atom [2347,2404]
===
match
---
simple_stmt [5000,5047]
simple_stmt [4831,4878]
===
match
---
factor [2903,2922]
factor [2734,2753]
===
match
---
name: dag [1990,1993]
name: dag [1967,1970]
===
match
---
comparison [4186,4212]
comparison [4017,4043]
===
match
---
import_as_names [1241,1322]
import_as_names [1241,1322]
===
match
---
name: Session [4655,4662]
name: Session [4486,4493]
===
match
---
dotted_name [1187,1227]
dotted_name [1187,1227]
===
match
---
name: AirflowException [5143,5159]
name: AirflowException [4974,4990]
===
match
---
simple_stmt [1325,1409]
simple_stmt [1325,1386]
===
match
---
trailer [4331,4344]
trailer [4162,4175]
===
match
---
import_as_names [1070,1105]
import_as_names [1070,1105]
===
match
---
name: DagModel [2886,2894]
name: DagModel [2717,2725]
===
match
---
simple_stmt [4669,4700]
simple_stmt [4500,4531]
===
match
---
trailer [4068,4137]
trailer [3899,3968]
===
match
---
trailer [3738,3776]
trailer [3569,3607]
===
match
---
simple_stmt [3990,4007]
simple_stmt [3821,3838]
===
match
---
name: limit [3322,3327]
name: limit [3153,3158]
===
match
---
trailer [2188,2196]
trailer [2152,2160]
===
match
---
simple_stmt [5169,5260]
simple_stmt [5000,5091]
===
match
---
arglist [2800,2839]
arglist [2631,2670]
===
match
---
name: filter [3031,3037]
name: filter [2862,2868]
===
match
---
atom_expr [1805,1820]
atom_expr [1782,1797]
===
match
---
name: offset [2664,2670]
name: offset [2495,2501]
===
match
---
suite [4039,4138]
suite [3870,3969]
===
match
---
operator: @ [3517,3518]
operator: @ [3348,3349]
===
match
---
trailer [3946,3960]
trailer [3777,3791]
===
match
---
fstring_end: " [3774,3775]
fstring_end: " [3605,3606]
===
match
---
operator: , [2392,2393]
operator: , [2223,2224]
===
match
---
name: provide_session [3518,3533]
name: provide_session [3349,3364]
===
match
---
operator: = [3393,3394]
operator: = [3224,3225]
===
match
---
name: request [819,826]
name: request [819,826]
===
match
---
simple_stmt [5079,5132]
simple_stmt [4910,4963]
===
match
---
operator: , [2653,2654]
operator: , [2484,2485]
===
match
---
name: dag_id [3668,3674]
name: dag_id [3499,3505]
===
match
---
decorators [2490,2635]
decorators [2321,2466]
===
match
---
operator: = [5037,5038]
operator: = [4868,4869]
===
match
---
name: tags [3152,3156]
name: tags [2983,2987]
===
match
---
atom_expr [3230,3251]
atom_expr [3061,3082]
===
match
---
raise_stmt [3897,3961]
raise_stmt [3728,3792]
===
match
---
name: session [1709,1716]
name: session [1686,1693]
===
match
---
name: airflow [1462,1469]
name: airflow [1439,1446]
===
match
---
name: ACTION_CAN_READ [1627,1642]
name: ACTION_CAN_READ [1604,1619]
===
match
---
trailer [1984,1989]
trailer [1961,1966]
===
match
---
trailer [1889,1961]
trailer [1866,1938]
===
match
---
expr_stmt [2158,2204]
expr_stmt [2122,2168]
===
match
---
parameters [2101,2109]
parameters [2078,2086]
===
match
---
name: update_mask [4022,4033]
name: update_mask [3853,3864]
===
match
---
trailer [2895,2902]
trailer [2726,2733]
===
match
---
simple_stmt [785,827]
simple_stmt [785,827]
===
match
---
param [1709,1716]
param [1686,1693]
===
match
---
atom_expr [3460,3487]
atom_expr [3291,3318]
===
match
---
trailer [4444,4457]
trailer [4275,4288]
===
match
---
suite [1718,1995]
suite [1695,1972]
===
match
---
name: tags [3081,3085]
name: tags [2912,2916]
===
match
---
simple_stmt [1182,1325]
simple_stmt [1182,1325]
===
match
---
name: or_ [3197,3200]
name: or_ [3028,3031]
===
match
---
trailer [2558,2571]
trailer [2389,2402]
===
match
---
trailer [3307,3315]
trailer [3138,3146]
===
match
---
simple_stmt [1723,1764]
simple_stmt [1700,1741]
===
match
---
name: schemas [1209,1216]
name: schemas [1209,1216]
===
match
---
return_stmt [4484,4511]
return_stmt [4315,4342]
===
match
---
return_stmt [5265,5286]
return_stmt [5096,5117]
===
match
---
name: one_or_none [1832,1843]
name: one_or_none [1809,1820]
===
match
---
trailer [2482,2487]
trailer [2313,2318]
===
match
---
operator: ~ [2903,2904]
operator: ~ [2734,2735]
===
match
---
testlist_comp [2025,2078]
testlist_comp [2002,2055]
===
match
---
name: err [3947,3950]
name: err [3778,3781]
===
match
---
name: patch_dag [3538,3547]
name: patch_dag [3369,3378]
===
match
---
name: DagModel [3659,3667]
name: DagModel [3490,3498]
===
match
---
atom_expr [3730,3776]
atom_expr [3561,3607]
===
match
---
fstring_end: " [2446,2447]
fstring_end: " [2277,2278]
===
match
---
name: permissions [4573,4584]
name: permissions [4404,4415]
===
match
---
simple_stmt [1535,1585]
simple_stmt [1512,1562]
===
match
---
try_stmt [3781,3962]
try_stmt [3612,3793]
===
match
---
simple_stmt [3340,3430]
simple_stmt [3171,3261]
===
match
---
trailer [3037,3073]
trailer [2868,2904]
===
match
---
raise_stmt [5079,5131]
raise_stmt [4910,4962]
===
match
---
suite [3981,4404]
suite [3812,4235]
===
match
---
name: all [3245,3248]
name: all [3076,3079]
===
match
---
trailer [5010,5021]
trailer [4841,4852]
===
match
---
import_from [1498,1534]
import_from [1475,1511]
===
match
---
name: commit [4471,4477]
name: commit [4302,4308]
===
match
---
trailer [2180,2188]
trailer [2144,2152]
===
match
---
name: filter [1798,1804]
name: filter [1775,1781]
===
match
---
operator: , [2819,2820]
operator: , [2650,2651]
===
match
---
name: detail [5189,5195]
name: detail [5020,5026]
===
match
---
atom_expr [4160,4174]
atom_expr [3991,4005]
===
match
---
operator: @ [1997,1998]
operator: @ [1974,1975]
===
match
---
operator: = [2870,2871]
operator: = [2701,2702]
===
match
---
name: is_subdag [2913,2922]
name: is_subdag [2744,2753]
===
match
---
name: dags_collection_schema [3347,3369]
name: dags_collection_schema [3178,3200]
===
match
---
operator: , [3563,3564]
operator: , [3394,3395]
===
match
---
simple_stmt [2756,2841]
simple_stmt [2587,2672]
===
match
---
tfpdef [4633,4644]
tfpdef [4464,4475]
===
match
---
decorator [2618,2635]
decorator [2449,2466]
===
match
---
atom_expr [2821,2839]
atom_expr [2652,2670]
===
match
---
operator: , [2052,2053]
operator: , [2029,2030]
===
match
---
name: DagTag [1450,1456]
name: DagTag [1427,1433]
===
match
---
name: in_ [3054,3057]
name: in_ [2885,2888]
===
match
---
dotted_name [1540,1561]
dotted_name [1517,1538]
===
match
---
atom_expr [1774,1845]
atom_expr [1751,1822]
===
match
---
name: dags_collection_schema [1299,1321]
name: dags_collection_schema [1299,1321]
===
match
---
import_from [982,1024]
import_from [982,1024]
===
match
---
operator: * [3201,3202]
operator: * [3032,3033]
===
match
---
suite [2747,2841]
suite [2578,2672]
===
match
---
name: expression [887,897]
name: expression [887,897]
===
match
---
param [3548,3556]
param [3379,3387]
===
match
---
trailer [1804,1831]
trailer [1781,1808]
===
match
---
dotted_name [1588,1612]
dotted_name [1565,1589]
===
match
---
name: security [2491,2499]
name: security [2322,2330]
===
match
---
arglist [3389,3427]
arglist [3220,3258]
===
match
---
fstring_expr [5230,5238]
fstring_expr [5061,5069]
===
match
---
decorator [4601,4618]
decorator [4432,4449]
===
match
---
dotted_name [939,964]
dotted_name [939,964]
===
match
---
name: dag [3711,3714]
name: dag [3542,3545]
===
match
---
atom [2023,2080]
atom [2000,2057]
===
match
---
name: dag [1768,1771]
name: dag [1745,1748]
===
match
---
argument [2394,2447]
argument [2225,2278]
===
match
---
trailer [3116,3120]
trailer [2947,2951]
===
match
---
funcdef [2635,3430]
funcdef [2466,3261]
===
match
---
trailer [3369,3374]
trailer [3200,3205]
===
match
---
operator: , [4644,4645]
operator: , [4475,4476]
===
match
---
suite [3785,3854]
suite [3616,3685]
===
match
---
trailer [3111,3116]
trailer [2942,2947]
===
match
---
name: RESOURCE_DAG [1656,1668]
name: RESOURCE_DAG [1633,1645]
===
match
---
operator: { [5110,5111]
operator: { [4941,4942]
===
match
---
name: get_dag [1693,1700]
name: get_dag [1670,1677]
===
match
---
decorator [4514,4601]
decorator [4345,4432]
===
match
---
simple_stmt [3724,3777]
simple_stmt [3555,3608]
===
match
---
atom_expr [2460,2487]
atom_expr [2291,2318]
===
match
---
operator: = [3576,3577]
operator: = [3407,3408]
===
match
---
operator: == [1821,1823]
operator: == [1798,1800]
===
match
---
name: dags_query [2859,2869]
name: dags_query [2690,2700]
===
match
---
import_from [785,826]
import_from [785,826]
===
match
---
operator: , [3934,3935]
operator: , [3765,3766]
===
match
---
name: DAG [930,933]
name: DAG [930,933]
===
match
---
string: """Get all DAGs.""" [2708,2727]
string: """Get all DAGs.""" [2539,2558]
===
match
---
operator: , [3487,3488]
operator: , [3318,3319]
===
match
---
name: airflow [1111,1118]
name: airflow [1111,1118]
===
match
---
operator: != [4198,4200]
operator: != [4029,4031]
===
match
---
operator: = [4075,4076]
operator: = [3906,3907]
===
match
---
name: dag_schema [1217,1227]
name: dag_schema [1217,1227]
===
match
---
expr_stmt [3166,3208]
expr_stmt [2997,3039]
===
match
---
param [2655,2663]
param [2486,2494]
===
match
---
name: dag_id [1824,1830]
name: dag_id [1801,1807]
===
match
---
atom [4541,4598]
atom [4372,4429]
===
match
---
operator: } [1944,1945]
operator: } [1921,1922]
===
match
---
fstring_expr [3755,3763]
fstring_expr [3586,3594]
===
match
---
name: permissions [1486,1497]
name: permissions [1463,1474]
===
match
---
name: airflow [1414,1421]
name: airflow [1391,1398]
===
match
---
name: sm [2968,2970]
name: sm [2799,2801]
===
match
---
simple_stmt [4320,4371]
simple_stmt [4151,4202]
===
match
---
name: patch_body [4347,4357]
name: patch_body [4178,4188]
===
match
---
name: session [5030,5037]
name: session [4861,4868]
===
match
---
name: DagModel [1440,1448]
name: DagModel [1417,1425]
===
match
---
name: NotFound [3730,3738]
name: NotFound [3561,3569]
===
match
---
simple_stmt [827,867]
simple_stmt [827,867]
===
match
---
fstring_expr [5110,5118]
fstring_expr [4941,4949]
===
match
---
string: 'is_paused' [4201,4212]
string: 'is_paused' [4032,4043]
===
match
---
name: get_accessible_dag_ids [2971,2993]
name: get_accessible_dag_ids [2802,2824]
===
match
---
decorated [2490,3430]
decorated [2321,3261]
===
match
---
name: user [2996,3000]
name: user [2827,2831]
===
match
---
trailer [3950,3959]
trailer [3781,3790]
===
match
---
name: patch_body [4379,4389]
name: patch_body [4210,4220]
===
match
---
fstring_string: Dag with id: ' [5096,5110]
fstring_string: Dag with id: ' [4927,4941]
===
match
---
arglist [3914,3960]
arglist [3745,3791]
===
match
---
expr_stmt [4146,4174]
expr_stmt [3977,4005]
===
match
---
trailer [4584,4597]
trailer [4415,4428]
===
match
---
name: requires_access [3442,3457]
name: requires_access [3273,3288]
===
match
---
name: flask [790,795]
name: flask [790,795]
===
match
---
atom_expr [4018,4034]
atom_expr [3849,3865]
===
match
---
name: session [3628,3635]
name: session [3459,3466]
===
match
---
expr_stmt [3095,3157]
expr_stmt [2926,2988]
===
match
---
except_clause [5051,5069]
except_clause [4882,4900]
===
match
---
name: provide_session [1569,1584]
name: provide_session [1546,1561]
===
match
---
atom_expr [4463,4479]
atom_expr [4294,4310]
===
match
---
operator: = [3100,3101]
operator: = [2931,2932]
===
match
---
operator: = [3262,3263]
operator: = [3093,3094]
===
match
---
simple_stmt [3897,3962]
simple_stmt [3728,3793]
===
match
---
name: detail [1907,1913]
name: detail [1884,1890]
===
match
---
import_from [867,908]
import_from [867,908]
===
match
---
name: dag [1854,1857]
name: dag [1831,1834]
===
match
---
atom_expr [3284,3299]
atom_expr [3115,3130]
===
match
---
simple_stmt [2362,2449]
simple_stmt [2193,2280]
===
match
---
name: is_active [2830,2839]
name: is_active [2661,2670]
===
match
---
trailer [2995,3000]
trailer [2826,2831]
===
match
---
trailer [4242,4311]
trailer [4073,4142]
===
match
---
atom_expr [3659,3674]
atom_expr [3490,3505]
===
match
---
trailer [3300,3307]
trailer [3131,3138]
===
match
---
fstring [5094,5130]
fstring [4925,4961]
===
match
---
name: dags_query [2756,2766]
name: dags_query [2587,2597]
===
match
---
name: dag [3622,3625]
name: dag [3453,3456]
===
match
---
parameters [4632,4663]
parameters [4463,4494]
===
match
---
name: RESOURCE_DAG [2559,2571]
name: RESOURCE_DAG [2390,2402]
===
match
---
name: dags_query [3007,3017]
name: dags_query [2838,2848]
===
match
---
decorated [4514,5287]
decorated [4345,5118]
===
match
---
trailer [2993,3001]
trailer [2824,2832]
===
match
---
testlist_comp [1615,1668]
testlist_comp [1592,1645]
===
match
---
number: 204 [5283,5286]
number: 204 [5114,5117]
===
match
---
atom [2024,2079]
atom [2001,2056]
===
match
---
name: _vendor [947,954]
name: _vendor [947,954]
===
match
---
atom_expr [2169,2204]
atom_expr [2133,2168]
===
match
---
operator: , [1254,1255]
operator: , [1254,1255]
===
match
---
name: dag_detail_schema [2460,2477]
name: dag_detail_schema [2291,2308]
===
match
---
decorated [1587,1995]
decorated [1564,1972]
===
match
---
decorators [3432,3534]
decorators [3263,3365]
===
match
---
fstring_string: Task instances of dag with id: ' [5198,5230]
fstring_string: Task instances of dag with id: ' [5029,5061]
===
match
---
name: requires_access [1597,1612]
name: requires_access [1574,1589]
===
match
---
name: err [3884,3887]
name: err [3715,3718]
===
match
---
name: api_connexion [1119,1132]
name: api_connexion [1119,1132]
===
match
---
name: session [2769,2776]
name: session [2600,2607]
===
match
---
trailer [3332,3334]
trailer [3163,3165]
===
match
---
name: delete_dag [4622,4632]
name: delete_dag [4453,4463]
===
match
---
string: "Invalid Dag schema" [3914,3934]
string: "Invalid Dag schema" [3745,3765]
===
match
---
name: update_mask [3969,3980]
name: update_mask [3800,3811]
===
match
---
name: patch_body_ [4320,4331]
name: patch_body_ [4151,4162]
===
match
---
import_from [4927,4981]
import_from [4758,4812]
===
match
---
atom_expr [5085,5131]
atom_expr [4916,4962]
===
match
---
fstring_string: The DAG with dag_id:  [1916,1937]
fstring_string: The DAG with dag_id:  [1893,1914]
===
match
---
name: g [2994,2995]
name: g [2825,2826]
===
match
---
name: filter [2896,2902]
name: filter [2727,2733]
===
match
---
name: DagModel [3103,3111]
name: DagModel [2934,2942]
===
match
---
trailer [2799,2840]
trailer [2630,2671]
===
match
---
string: 'is_paused' [4421,4432]
string: 'is_paused' [4252,4263]
===
match
---
name: exceptions [1052,1062]
name: exceptions [1052,1062]
===
match
---
name: query [3636,3641]
name: query [3467,3472]
===
match
---
name: airflow [1503,1510]
name: airflow [1480,1487]
===
match
---
name: utils [1548,1553]
name: utils [1525,1530]
===
match
---
operator: @ [2575,2576]
operator: @ [2406,2407]
===
match
---
funcdef [1689,1995]
funcdef [1666,1972]
===
match
---
simple_stmt [982,1025]
simple_stmt [982,1025]
===
match
---
operator: , [4432,4433]
operator: , [4263,4264]
===
match
---
number: 0 [2671,2672]
number: 0 [2502,2503]
===
match
---
name: only_active [2735,2746]
name: only_active [2566,2577]
===
match
---
operator: , [814,815]
operator: , [814,815]
===
match
---
operator: { [2594,2595]
operator: { [2425,2426]
===
match
---
name: tags [3112,3116]
name: tags [2943,2947]
===
match
---
import_from [934,981]
import_from [934,981]
===
match
---
name: check_limit [2604,2615]
name: check_limit [2435,2446]
===
match
---
name: readable_dags [2929,2942]
name: readable_dags [2760,2773]
===
match
---
name: dag_id [3756,3762]
name: dag_id [3587,3593]
===
match
---
name: name [3128,3132]
name: name [2959,2963]
===
match
---
name: dag_id [3678,3684]
name: dag_id [3509,3515]
===
match
---
trailer [4021,4034]
trailer [3852,3865]
===
match
---
arglist [4416,4457]
arglist [4247,4288]
===
match
---
string: 'is_paused' [4445,4456]
string: 'is_paused' [4276,4287]
===
match
---
name: patch_body_ [4392,4403]
name: patch_body_ [4223,4234]
===
match
---
atom_expr [4058,4137]
atom_expr [3889,3968]
===
match
---
name: sqlalchemy [872,882]
name: sqlalchemy [872,882]
===
match
---
expr_stmt [3794,3853]
expr_stmt [3625,3684]
===
match
---
name: current_app [2169,2180]
name: current_app [2133,2144]
===
match
---
atom_expr [2872,2923]
atom_expr [2703,2754]
===
match
---
operator: = [5195,5196]
operator: = [5026,5027]
===
match
---
name: session [5038,5045]
name: session [4869,4876]
===
match
---
argument [1907,1960]
argument [1884,1937]
===
match
---
simple_stmt [1106,1182]
simple_stmt [1106,1182]
===
match
---
import_from [1182,1324]
import_from [1182,1324]
===
match
---
atom_expr [3197,3207]
atom_expr [3028,3038]
===
match
---
name: airflow [1030,1037]
name: airflow [1030,1037]
===
match
---
operator: = [4158,4159]
operator: = [3989,3990]
===
match
---
operator: , [1905,1906]
operator: , [1882,1883]
===
match
---
atom_expr [3264,3334]
atom_expr [3095,3165]
===
match
---
decorators [4514,4618]
decorators [4345,4449]
===
match
---
name: permissions [1615,1626]
name: permissions [1592,1603]
===
match
---
name: json [3831,3835]
name: json [3662,3666]
===
match
---
except_clause [5136,5159]
except_clause [4967,4990]
===
match
---
trailer [3315,3321]
trailer [3146,3152]
===
match
---
trailer [4553,4571]
trailer [4384,4402]
===
match
---
decorator [2490,2575]
decorator [2321,2406]
===
match
---
trailer [4470,4477]
trailer [4301,4308]
===
match
---
atom_expr [2769,2840]
atom_expr [2600,2671]
===
match
---
name: dag_id [5111,5117]
name: dag_id [4942,4948]
===
match
---
trailer [3388,3428]
trailer [3219,3259]
===
match
---
name: dag_bag [2181,2188]
name: dag_bag [2145,2152]
===
match
---
dotted_name [1030,1062]
dotted_name [1030,1062]
===
match
---
name: detail [4069,4075]
name: detail [3900,3906]
===
match
---
operator: , [1642,1643]
operator: , [1619,1620]
===
match
---
testlist [5272,5286]
testlist [5103,5117]
===
match
---
argument [3201,3206]
argument [3032,3037]
===
match
---
fstring_string:  was not found [1945,1959]
fstring_string:  was not found [1922,1936]
===
match
---
trailer [2956,2967]
trailer [2787,2798]
===
match
---
simple_stmt [1498,1535]
simple_stmt [1475,1512]
===
match
---
name: RESOURCE_DAG [2066,2078]
name: RESOURCE_DAG [2043,2055]
===
match
---
name: connexion [955,964]
name: connexion [955,964]
===
match
---
name: only_active [2674,2685]
name: only_active [2505,2516]
===
match
---
suite [4213,4312]
suite [4044,4143]
===
match
---
simple_stmt [2453,2488]
simple_stmt [2284,2319]
===
match
---
simple_stmt [1457,1498]
simple_stmt [1434,1475]
===
match
---
name: dag_id [5022,5028]
name: dag_id [4853,4859]
===
match
---
name: total_entries [3214,3227]
name: total_entries [3045,3058]
===
match
---
atom [2517,2572]
atom [2348,2403]
===
match
---
suite [4664,5287]
suite [4495,5118]
===
match
---
simple_stmt [3622,3700]
simple_stmt [3453,3531]
===
match
---
name: dag [2483,2486]
name: dag [2314,2317]
===
match
---
operator: { [4004,4005]
operator: { [3835,3836]
===
match
---
string: """Get details of DAG.""" [2115,2140]
string: """Get details of DAG.""" [2092,2117]
===
match
---
atom_expr [3179,3208]
atom_expr [3010,3039]
===
match
---
funcdef [2082,2488]
funcdef [2059,2319]
===
match
---
name: cond [3202,3206]
name: cond [3033,3037]
===
match
---
operator: = [3626,3627]
operator: = [3457,3458]
===
match
---
trailer [5093,5131]
trailer [4924,4962]
===
match
---
fstring_string: Dag with id: ' [3741,3755]
fstring_string: Dag with id: ' [3572,3586]
===
match
---
name: appbuilder [2957,2967]
name: appbuilder [2788,2798]
===
match
---
atom_expr [4542,4571]
atom_expr [4373,4402]
===
match
---
dotted_name [2491,2515]
dotted_name [2322,2346]
===
match
---
trailer [3471,3487]
trailer [3302,3318]
===
match
---
name: patch_body [3794,3804]
name: patch_body [3625,3635]
===
match
---
operator: } [2615,2616]
operator: } [2446,2447]
===
match
---
parameters [2647,2702]
parameters [2478,2533]
===
match
---
trailer [1781,1787]
trailer [1758,1764]
===
match
---
trailer [1831,1843]
trailer [1808,1820]
===
match
---
operator: = [4345,4346]
operator: = [4176,4177]
===
match
---
atom_expr [2945,3001]
atom_expr [2776,2832]
===
match
---
name: dag_schema [3807,3817]
name: dag_schema [3638,3648]
===
match
---
argument [3837,3852]
argument [3668,3683]
===
match
---
simple_stmt [1409,1457]
simple_stmt [1386,1434]
===
match
---
trailer [3200,3207]
trailer [3031,3038]
===
match
---
expr_stmt [3214,3251]
expr_stmt [3045,3082]
===
match
---
return_stmt [1967,1994]
return_stmt [1944,1971]
===
match
---
name: delete_dag [5000,5010]
name: delete_dag [4831,4841]
===
match
---
operator: , [1277,1278]
operator: , [1277,1278]
===
match
---
trailer [3120,3140]
trailer [2951,2971]
===
match
---
atom_expr [3628,3699]
atom_expr [3459,3530]
===
match
---
operator: = [3177,3178]
operator: = [3008,3009]
===
match
---
annassign [2161,2204]
annassign [2125,2168]
===
match
---
trailer [3658,3685]
trailer [3489,3516]
===
match
---
name: api [4940,4943]
name: api [4771,4774]
===
match
---
name: ACTION_CAN_READ [2037,2052]
name: ACTION_CAN_READ [2014,2029]
===
match
---
trailer [3667,3674]
trailer [3498,3505]
===
match
---
name: api_connexion [1195,1208]
name: api_connexion [1195,1208]
===
match
---
atom_expr [2518,2545]
atom_expr [2349,2376]
===
match
---
arglist [3823,3852]
arglist [3654,3683]
===
match
---
name: parameters [1133,1143]
name: parameters [1133,1143]
===
match
---
name: messages [3951,3959]
name: messages [3782,3790]
===
match
---
atom_expr [3947,3959]
atom_expr [3778,3790]
===
match
---
name: delete_dag [4971,4981]
name: delete_dag [4802,4812]
===
match
---
simple_stmt [3257,3335]
simple_stmt [3088,3166]
===
match
---
name: DAGCollection [1241,1254]
name: DAGCollection [1241,1254]
===
match
---
testlist_comp [3103,3156]
testlist_comp [2934,2987]
===
match
---
fstring_start: f" [5094,5096]
fstring_start: f" [4925,4927]
===
match
---
trailer [4501,4506]
trailer [4332,4337]
===
match
---
argument [3936,3960]
argument [3767,3791]
===
match
---
name: dag [2158,2161]
name: dag [2122,2125]
===
match
---
name: update_mask [4186,4197]
name: update_mask [4017,4028]
===
match
---
operator: } [5237,5238]
operator: } [5068,5069]
===
match
---
decorator [1587,1672]
decorator [1564,1649]
===
match
---
name: AlreadyExists [1070,1083]
name: AlreadyExists [1070,1083]
===
match
---
simple_stmt [867,909]
simple_stmt [867,909]
===
match
---
raise_stmt [3724,3776]
raise_stmt [3555,3607]
===
match
---
trailer [1989,1994]
trailer [1966,1971]
===
match
---
name: AlreadyExists [5175,5188]
name: AlreadyExists [5006,5019]
===
match
---
testlist_comp [4542,4597]
testlist_comp [4373,4428]
===
match
---
trailer [3292,3299]
trailer [3123,3130]
===
match
---
operator: @ [1587,1588]
operator: @ [1564,1565]
===
match
---
name: security [1016,1024]
name: security [1016,1024]
===
match
---
fstring [5196,5258]
fstring [5027,5089]
===
match
---
trailer [3697,3699]
trailer [3528,3530]
===
match
---
atom_expr [2025,2052]
atom_expr [2002,2029]
===
match
---
name: dag_id [3557,3563]
name: dag_id [3388,3394]
===
match
---
simple_stmt [4484,4512]
simple_stmt [4315,4343]
===
match
---
trailer [3321,3328]
trailer [3152,3159]
===
match
---
name: len [3230,3233]
name: len [3061,3064]
===
match
---
import_from [1106,1181]
import_from [1106,1181]
===
match
---
operator: = [1913,1914]
operator: = [1890,1891]
===
match
---
name: check_limit [1151,1162]
name: check_limit [1151,1162]
===
match
---
name: security [1998,2006]
name: security [1975,1983]
===
match
---
operator: = [2400,2401]
operator: = [2231,2232]
===
match
---
operator: , [1707,1708]
operator: , [1684,1685]
===
match
---
atom_expr [2904,2922]
atom_expr [2735,2753]
===
match
---
import_from [1325,1408]
import_from [1325,1385]
===
match
---
name: RESOURCE_DAG [3501,3513]
name: RESOURCE_DAG [3332,3344]
===
match
---
simple_stmt [4052,4138]
simple_stmt [3883,3969]
===
match
---
trailer [1787,1797]
trailer [1764,1774]
===
match
---
atom_expr [5175,5259]
atom_expr [5006,5090]
===
match
---
name: provide_session [4602,4617]
name: provide_session [4433,4448]
===
match
---
atom [3459,3514]
atom [3290,3345]
===
match
---
expr_stmt [1768,1845]
expr_stmt [1745,1822]
===
match
---
operator: , [1162,1163]
operator: , [1162,1163]
===
match
---
trailer [2902,2923]
trailer [2733,2754]
===
match
---
name: query [2880,2885]
name: query [2711,2716]
===
match
---
trailer [3500,3513]
trailer [3331,3344]
===
match
---
operator: = [3018,3019]
operator: = [2849,2850]
===
match
---
name: NotFound [5085,5093]
name: NotFound [4916,4924]
===
match
---
trailer [3830,3835]
trailer [3661,3666]
===
match
---
operator: = [1772,1773]
operator: = [1749,1750]
===
match
---
name: permissions [3460,3471]
name: permissions [3291,3302]
===
match
---
name: get_dags [2639,2647]
name: get_dags [2470,2478]
===
match
---
name: dag_id [2197,2203]
name: dag_id [2161,2167]
===
match
---
operator: = [2670,2671]
operator: = [2501,2502]
===
match
---
name: requires_access [2500,2515]
name: requires_access [2331,2346]
===
match
---
fstring_string: The DAG with dag_id:  [2403,2424]
fstring_string: The DAG with dag_id:  [2234,2255]
===
match
---
fstring_end: " [5257,5258]
fstring_end: " [5088,5089]
===
match
---
number: 0 [4172,4173]
number: 0 [4003,4004]
===
match
---
raise_stmt [2362,2448]
raise_stmt [2193,2279]
===
match
---
param [3557,3564]
param [3388,3395]
===
match
---
funcdef [3534,4512]
funcdef [3365,4343]
===
match
---
name: get_dag_details [2086,2101]
name: get_dag_details [2063,2078]
===
match
---
name: DagModel [1805,1813]
name: DagModel [1782,1790]
===
match
---
name: ACTION_CAN_READ [2530,2545]
name: ACTION_CAN_READ [2361,2376]
===
match
---
atom_expr [2801,2819]
atom_expr [2632,2650]
===
match
---
name: dag_id [2102,2108]
name: dag_id [2079,2085]
===
match
---
name: models [1422,1428]
name: models [1399,1405]
===
match
---
name: dag [2341,2344]
name: dag [2180,2183]
===
match
---
operator: , [3555,3556]
operator: , [3386,3387]
===
match
---
testlist_comp [2518,2571]
testlist_comp [2349,2402]
===
match
---
testlist_comp [3460,3513]
testlist_comp [3291,3344]
===
match
---
name: DAGCollection [3375,3388]
name: DAGCollection [3206,3219]
===
move-tree
---
simple_stmt [2158,2205]
    expr_stmt [2158,2204]
        name: dag [2158,2161]
        annassign [2161,2204]
            name: DAG [2163,2166]
            operator: = [2167,2168]
            atom_expr [2169,2204]
                name: current_app [2169,2180]
                trailer [2180,2188]
                    name: dag_bag [2181,2188]
                trailer [2188,2196]
                    name: get_dag [2189,2196]
                trailer [2196,2204]
                    name: dag_id [2197,2203]
to
suite [2110,2488]
at 1
===
insert-node
---
not_test [2176,2183]
to
if_stmt [2338,2449]
at 0
===
move-tree
---
name: dag [2341,2344]
to
not_test [2176,2183]
at 0
===
delete-node
---
operator: , [1385,1386]
===
===
delete-node
---
name: SerializedDagNotFound [1387,1408]
===
===
delete-node
---
suite [2149,2205]
===
===
delete-node
---
try_stmt [2145,2334]
===
===
delete-node
---
comparison [2341,2352]
===
