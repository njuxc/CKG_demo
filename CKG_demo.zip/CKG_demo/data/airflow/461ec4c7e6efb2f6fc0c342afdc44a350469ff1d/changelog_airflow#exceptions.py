===
match
---
param [6517,6552]
param [6400,6435]
===
match
---
fstring [6733,6778]
fstring [6616,6661]
===
match
---
atom_expr [6827,6844]
atom_expr [6710,6727]
===
match
---
string: """Raise when a Dag's ID is already used by another Dag""" [3136,3194]
string: """Raise when a Dag's ID is already used by another Dag""" [3136,3194]
===
match
---
argument [4549,4561]
argument [4549,4561]
===
match
---
atom_expr [8164,8176]
atom_expr [8047,8059]
===
match
---
atom_expr [7059,7078]
atom_expr [6942,6961]
===
match
---
simple_stmt [1430,1499]
simple_stmt [1430,1499]
===
match
---
name: self [7780,7784]
name: self [7663,7667]
===
match
---
tfpdef [6491,6499]
tfpdef [6374,6382]
===
match
---
fstring_string:  Parse error  [6885,6898]
fstring_string:  Parse error  [6768,6781]
===
match
---
operator: = [7793,7794]
operator: = [7676,7677]
===
match
---
suite [5405,5465]
suite [5288,5348]
===
match
---
expr_stmt [1684,1701]
expr_stmt [1684,1701]
===
match
---
string: """A problem occurred when trying to serialize a DAG""" [4856,4911]
string: """A problem occurred when trying to serialize a DAG""" [4739,4794]
===
match
---
name: existing [3247,3255]
name: existing [3247,3255]
===
match
---
name: platform [1181,1189]
name: platform [1181,1189]
===
match
---
funcdef [3200,3419]
funcdef [3200,3419]
===
match
---
name: Optional [7651,7659]
name: Optional [7534,7542]
===
match
---
suite [6715,7261]
suite [6598,7144]
===
match
---
suite [5519,5580]
suite [5402,5463]
===
match
---
name: str [6496,6499]
name: str [6379,6382]
===
match
---
simple_stmt [7780,7803]
simple_stmt [7663,7686]
===
match
---
fstring_string: 3 [6908,6909]
fstring_string: 3 [6791,6792]
===
match
---
name: AirflowException [1212,1228]
name: AirflowException [1212,1228]
===
match
---
string: """Raise when DAG max_active_tasks limit is reached""" [5410,5464]
string: """Raise when DAG max_active_tasks limit is reached""" [5293,5347]
===
match
---
operator: } [8202,8203]
operator: } [8085,8086]
===
match
---
fstring_expr [7058,7079]
fstring_expr [6941,6962]
===
match
---
operator: = [6677,6678]
operator: = [6560,6561]
===
match
---
annassign [6068,6073]
annassign [5951,5956]
===
match
---
name: super [7753,7758]
name: super [7636,7641]
===
match
---
name: AirflowException [3113,3129]
name: AirflowException [3113,3129]
===
match
---
simple_stmt [8255,8320]
simple_stmt [8138,8203]
===
match
---
operator: } [6744,6745]
operator: } [6627,6628]
===
match
---
name: utils [1117,1122]
name: utils [1117,1122]
===
match
---
operator: = [3408,3409]
operator: = [3408,3409]
===
match
---
trailer [7132,7134]
trailer [7015,7017]
===
match
---
simple_stmt [3740,3789]
simple_stmt [3740,3789]
===
match
---
name: self [3394,3398]
name: self [3394,3398]
===
match
---
simple_stmt [6862,6931]
simple_stmt [6745,6814]
===
match
---
name: AirflowBadRequest [4148,4165]
name: AirflowBadRequest [4148,4165]
===
match
---
number: 400 [1518,1521]
number: 400 [1518,1521]
===
match
---
name: self [5842,5846]
name: self [5725,5729]
===
match
---
expr_stmt [7780,7802]
expr_stmt [7663,7685]
===
match
---
fstring_string:  from  [3493,3499]
fstring_string:  from  [3493,3499]
===
match
---
string: """Raise when a Task Instance is not available in the system""" [5079,5142]
string: """Raise when a Task Instance is not available in the system""" [4962,5025]
===
match
---
fstring_end: " [6165,6166]
fstring_end: " [6048,6049]
===
match
---
string: """     Raise when the task should be re-scheduled at a later time.      :param reschedule_date: The date when the task should be rescheduled     :type reschedule_date: datetime.datetime     """ [1968,2162]
string: """     Raise when the task should be re-scheduled at a later time.      :param reschedule_date: The date when the task should be rescheduled     :type reschedule_date: datetime.datetime     """ [1968,2162]
===
match
---
atom_expr [6043,6056]
atom_expr [5926,5939]
===
match
---
trailer [2244,2260]
trailer [2244,2260]
===
match
---
name: Optional [6043,6051]
name: Optional [5926,5934]
===
match
---
suite [2609,2660]
suite [2609,2660]
===
match
---
number: 500 [1377,1380]
number: 500 [1377,1380]
===
match
---
suite [1240,1381]
suite [1240,1381]
===
match
---
fstring_string:  method= [8177,8185]
fstring_string:  method= [8060,8068]
===
match
---
name: self [3500,3504]
name: self [3500,3504]
===
match
---
fstring_expr [8163,8177]
fstring_expr [8046,8060]
===
match
---
simple_stmt [5979,6029]
simple_stmt [5862,5912]
===
match
---
name: __init__ [7761,7769]
name: __init__ [7644,7652]
===
match
---
name: ValueError [8044,8054]
name: ValueError [7927,7937]
===
match
---
name: AirflowException [2495,2511]
name: AirflowException [2495,2511]
===
match
---
operator: , [7590,7591]
operator: , [7473,7474]
===
match
---
param [6091,6095]
param [5974,5978]
===
match
---
name: msg [6612,6615]
name: msg [6495,6498]
===
match
---
import_from [1162,1203]
import_from [1162,1203]
===
match
---
name: status_code [1684,1695]
name: status_code [1684,1695]
===
match
---
name: str [8119,8122]
name: str [8002,8005]
===
match
---
name: __repr__ [8101,8109]
name: __repr__ [7984,7992]
===
match
---
operator: = [7676,7677]
operator: = [7559,7560]
===
match
---
simple_stmt [6943,6980]
simple_stmt [6826,6863]
===
match
---
name: __init__ [5833,5841]
name: __init__ [5716,5724]
===
match
---
classdef [1704,1804]
classdef [1704,1804]
===
match
---
classdef [3791,3894]
classdef [3791,3894]
===
match
---
classdef [4010,4120]
classdef [4010,4120]
===
match
---
operator: , [5846,5847]
operator: , [5729,5730]
===
match
---
name: enumerate [6817,6826]
name: enumerate [6700,6709]
===
match
---
operator: + [7171,7172]
operator: + [7054,7055]
===
match
---
import_as_name [1070,1103]
import_as_name [1070,1103]
===
match
---
suite [4289,4563]
suite [4289,4563]
===
match
---
name: PoolNotFound [5151,5163]
name: PoolNotFound [5034,5046]
===
match
---
atom_expr [7879,7891]
atom_expr [7762,7774]
===
match
---
fstring_expr [6735,6745]
fstring_expr [6618,6628]
===
match
---
expr_stmt [6862,6930]
expr_stmt [6745,6813]
===
match
---
comparison [7953,7977]
comparison [7836,7860]
===
match
---
atom_expr [7953,7965]
atom_expr [7836,7848]
===
match
---
param [4402,4410]
param [4402,4410]
===
match
---
trailer [4428,4437]
trailer [4428,4437]
===
match
---
trailer [2218,2220]
trailer [2218,2220]
===
match
---
expr_stmt [6724,6778]
expr_stmt [6607,6661]
===
match
---
simple_stmt [4062,4120]
simple_stmt [4062,4120]
===
match
---
operator: { [6115,6116]
operator: { [5998,5999]
===
match
---
name: NoAvailablePoolSlot [5258,5277]
name: NoAvailablePoolSlot [5141,5160]
===
match
---
tfpdef [3232,3245]
tfpdef [3232,3245]
===
match
---
operator: = [6639,6640]
operator: = [6522,6523]
===
match
---
dotted_name [1109,1133]
dotted_name [1109,1133]
===
match
---
operator: + [6913,6914]
operator: + [6796,6797]
===
match
---
name: dag_id [3219,3225]
name: dag_id [3219,3225]
===
match
---
name: AirflowTaskTimeout [2572,2590]
name: AirflowTaskTimeout [2572,2590]
===
match
---
param [6491,6500]
param [6374,6383]
===
match
---
name: prepare_code_snippet [1141,1161]
name: prepare_code_snippet [1141,1161]
===
match
---
import_name [935,950]
import_name [935,950]
===
match
---
operator: , [7682,7683]
operator: , [7565,7566]
===
match
---
name: existing [3410,3418]
name: existing [3410,3418]
===
match
---
string: """     Raise after the task register itself in the smart sensor service     It should exit without failing a task     """ [2338,2460]
string: """     Raise after the task register itself in the smart sensor service     It should exit without failing a task     """ [2338,2460]
===
match
---
classdef [6169,7261]
classdef [6052,7144]
===
match
---
suite [2333,2461]
suite [2333,2461]
===
match
---
fstring_start: f" [7042,7044]
fstring_start: f" [6925,6927]
===
match
---
name: Optional [7701,7709]
name: Optional [7584,7592]
===
match
---
fstring_string: <TaskDeferred trigger= [8141,8163]
fstring_string: <TaskDeferred trigger= [8024,8046]
===
match
---
suite [3131,3548]
suite [3131,3548]
===
match
---
classdef [2281,2461]
classdef [2281,2461]
===
match
---
trailer [7006,7014]
trailer [6889,6897]
===
match
---
param [6501,6516]
param [6384,6399]
===
match
---
name: hasattr [7986,7993]
name: hasattr [7869,7876]
===
match
---
atom_expr [6601,6609]
atom_expr [6484,6492]
===
match
---
simple_stmt [1601,1679]
simple_stmt [1601,1679]
===
match
---
name: parse_errors [6664,6676]
name: parse_errors [6547,6559]
===
match
---
parameters [8109,8115]
parameters [7992,7998]
===
match
---
name: TaskInstanceNotFound [5027,5047]
name: TaskInstanceNotFound [4910,4930]
===
match
---
operator: } [6128,6129]
operator: } [6011,6012]
===
match
---
name: AirflowException [8232,8248]
name: AirflowException [8115,8131]
===
match
---
fstring_expr [3531,3546]
fstring_expr [3531,3546]
===
match
---
simple_stmt [6034,6057]
simple_stmt [5917,5940]
===
match
---
name: existing [3314,3322]
name: existing [3314,3322]
===
match
---
name: __init__ [4380,4388]
name: __init__ [4380,4388]
===
match
---
string: """     Raises when not all tasks succeed in backfill.      :param message: The human-readable description of the exception     :param ti_status: The information about all task statuses     """ [5630,5823]
string: """     Raises when not all tasks succeed in backfill.      :param message: The human-readable description of the exception     :param ti_status: The information about all task statuses     """ [5513,5706]
===
match
---
tfpdef [6517,6552]
tfpdef [6400,6435]
===
match
---
operator: , [4393,4394]
operator: , [4393,4394]
===
match
---
atom_expr [4421,4454]
atom_expr [4421,4454]
===
match
---
operator: = [7828,7829]
operator: = [7711,7712]
===
match
---
fstring_expr [6115,6129]
fstring_expr [5998,6012]
===
match
---
fstring_string: \n\n [6773,6777]
fstring_string: \n\n [6656,6660]
===
match
---
name: AirflowDagCycleException [2973,2997]
name: AirflowDagCycleException [2973,2997]
===
match
---
arglist [7194,7229]
arglist [7077,7112]
===
match
---
trailer [7664,7674]
trailer [7547,7557]
===
match
---
suite [4412,4563]
suite [4412,4563]
===
match
---
atom_expr [7173,7230]
atom_expr [7056,7113]
===
match
---
classdef [5021,5143]
classdef [4904,5026]
===
match
---
atom_expr [2240,2260]
atom_expr [2240,2260]
===
match
---
funcdef [7553,8092]
funcdef [7436,7975]
===
match
---
trailer [3536,3545]
trailer [3536,3545]
===
match
---
name: __init__ [6476,6484]
name: __init__ [6359,6367]
===
match
---
suite [1751,1804]
suite [1751,1804]
===
match
---
name: str [6070,6073]
name: str [5953,5956]
===
match
---
classdef [4914,5019]
classdef [4797,4902]
===
match
---
suite [7412,8206]
suite [7295,8089]
===
match
---
param [3247,3260]
param [3247,3260]
===
match
---
string: "\n" [7166,7170]
string: "\n" [7049,7053]
===
match
---
classdef [1912,2279]
classdef [1912,2279]
===
match
---
suite [1425,1522]
suite [1425,1522]
===
match
---
expr_stmt [5911,5937]
expr_stmt [5794,5820]
===
match
---
name: result [6862,6868]
name: result [6745,6751]
===
match
---
suite [2513,2564]
suite [2513,2564]
===
match
---
name: reschedule_date [2263,2278]
name: reschedule_date [2263,2278]
===
match
---
name: method_name [7830,7841]
name: method_name [7713,7724]
===
match
---
fstring_start: f" [8139,8141]
fstring_start: f" [8022,8024]
===
match
---
suite [4167,4248]
suite [4167,4248]
===
match
---
atom_expr [6150,6162]
atom_expr [6033,6045]
===
match
---
classdef [3550,3685]
classdef [3550,3685]
===
match
---
simple_stmt [7879,7902]
simple_stmt [7762,7785]
===
match
---
simple_stmt [3949,4008]
simple_stmt [3949,4008]
===
match
---
funcdef [6079,6167]
funcdef [5962,6050]
===
match
---
name: __str__ [6701,6708]
name: __str__ [6584,6591]
===
match
---
trailer [6578,6587]
trailer [6461,6470]
===
match
---
name: timedelta [7719,7728]
name: timedelta [7602,7611]
===
match
---
operator: -> [3262,3264]
operator: -> [3262,3264]
===
match
---
operator: , [6844,6845]
operator: , [6727,6728]
===
match
---
fstring [6883,6912]
fstring [6766,6795]
===
match
---
name: self [6601,6605]
name: self [6484,6488]
===
match
---
name: AirflowNotFoundException [5048,5072]
name: AirflowNotFoundException [4931,4955]
===
match
---
name: is_tty [1197,1203]
name: is_tty [1197,1203]
===
match
---
funcdef [4376,4563]
funcdef [4376,4563]
===
match
---
expr_stmt [7811,7841]
expr_stmt [7694,7724]
===
match
---
name: line_no [6034,6041]
name: line_no [5917,5924]
===
match
---
simple_stmt [1968,2163]
simple_stmt [1968,2163]
===
match
---
operator: } [3545,3546]
operator: } [3545,3546]
===
match
---
trailer [6605,6609]
trailer [6488,6492]
===
match
---
classdef [5354,5465]
classdef [5237,5348]
===
match
---
operator: * [4395,4396]
operator: * [4395,4396]
===
match
---
simple_stmt [5524,5580]
simple_stmt [5407,5463]
===
match
---
expr_stmt [6659,6691]
expr_stmt [6542,6574]
===
match
---
suite [5974,6167]
suite [5857,6050]
===
match
---
name: self [7811,7815]
name: self [7694,7698]
===
match
---
atom_expr [7850,7861]
atom_expr [7733,7744]
===
match
---
simple_stmt [4615,4689]
simple_stmt [4615,4689]
===
match
---
name: super [5877,5882]
name: super [5760,5765]
===
match
---
name: incoming [3377,3385]
name: incoming [3377,3385]
===
match
---
parameters [3212,3261]
parameters [3212,3261]
===
match
---
simple_stmt [6659,6692]
simple_stmt [6542,6575]
===
match
---
operator: -> [3442,3444]
operator: -> [3442,3444]
===
match
---
name: stacklevel [4549,4559]
name: stacklevel [4549,4559]
===
match
---
name: timeout [7958,7965]
name: timeout [7841,7848]
===
match
---
operator: -> [6554,6556]
operator: -> [6437,6439]
===
match
---
name: dag_id [3346,3352]
name: dag_id [3346,3352]
===
match
---
name: AirflowException [4592,4608]
name: AirflowException [4592,4608]
===
match
---
name: DagFileExists [4256,4269]
name: DagFileExists [4256,4269]
===
match
---
string: "=" [6872,6875]
string: "=" [6755,6758]
===
match
---
suite [8123,8206]
suite [8006,8089]
===
match
---
fstring_expr [3480,3493]
fstring_expr [3480,3493]
===
match
---
operator: , [1013,1014]
operator: , [1013,1014]
===
match
---
name: self [4389,4393]
name: self [4389,4393]
===
match
---
name: datetime [7710,7718]
name: datetime [7593,7601]
===
match
---
name: ti_status [5928,5937]
name: ti_status [5811,5820]
===
match
---
if_stmt [6992,7238]
if_stmt [6875,7121]
===
match
---
name: line_no [7222,7229]
name: line_no [7105,7112]
===
match
---
expr_stmt [7156,7237]
expr_stmt [7039,7120]
===
match
---
simple_stmt [1684,1702]
simple_stmt [1684,1702]
===
match
---
arglist [1555,1594]
arglist [1555,1594]
===
match
---
name: DagCodeNotFound [3902,3917]
name: DagCodeNotFound [3902,3917]
===
match
---
fstring_string: , [6164,6165]
fstring_string: , [6047,6048]
===
match
---
operator: , [2185,2186]
operator: , [2185,2186]
===
match
---
atom_expr [8044,8091]
atom_expr [7927,7974]
===
match
---
name: str [3242,3245]
name: str [3242,3245]
===
match
---
atom_expr [6995,7014]
atom_expr [6878,6897]
===
match
---
operator: } [7078,7079]
operator: } [6961,6962]
===
match
---
fstring_string: \nFilename:  [6745,6757]
fstring_string: \nFilename:  [6628,6640]
===
match
---
simple_stmt [7247,7261]
simple_stmt [7130,7144]
===
match
---
operator: , [3217,3218]
operator: , [3217,3218]
===
match
---
simple_stmt [2518,2564]
simple_stmt [2518,2564]
===
match
---
name: InvalidStatsNameException [2469,2494]
name: InvalidStatsNameException [2469,2494]
===
match
---
string: "=" [6915,6918]
string: "=" [6798,6801]
===
match
---
name: warn [4472,4476]
name: warn [4472,4476]
===
match
---
operator: , [4443,4444]
operator: , [4443,4444]
===
match
---
name: self [6150,6154]
name: self [6033,6037]
===
match
---
fstring_expr [6145,6164]
fstring_expr [6028,6047]
===
match
---
operator: * [7589,7590]
operator: * [7472,7473]
===
match
---
trailer [3485,3492]
trailer [3485,3492]
===
match
---
name: self [3436,3440]
name: self [3436,3440]
===
match
---
operator: , [4547,4548]
operator: , [4547,4548]
===
match
---
simple_stmt [3021,3073]
simple_stmt [3021,3073]
===
match
---
simple_stmt [5911,5938]
simple_stmt [5794,5821]
===
match
---
string: "total_seconds" [8008,8023]
string: "total_seconds" [7891,7906]
===
match
---
string: """     Special exception raised to signal that the operator it was raised from     wishes to defer until a trigger fires.     """ [7417,7547]
string: """     Special exception raised to signal that the operator it was raised from     wishes to defer until a trigger fires.     """ [7300,7430]
===
match
---
name: message [6968,6975]
name: message [6851,6858]
===
match
---
atom_expr [3279,3323]
atom_expr [3279,3323]
===
match
---
name: str [3257,3260]
name: str [3257,3260]
===
match
---
name: timeout [7692,7699]
name: timeout [7575,7582]
===
match
---
param [2181,2186]
param [2181,2186]
===
match
---
trailer [7709,7729]
trailer [7592,7612]
===
match
---
return_stmt [6106,6166]
return_stmt [5989,6049]
===
match
---
name: SerializationError [4814,4832]
name: SerializationError [4697,4715]
===
match
---
operator: } [3492,3493]
operator: } [3492,3493]
===
match
---
operator: , [6489,6490]
operator: , [6372,6373]
===
match
---
name: result [7032,7038]
name: result [6915,6921]
===
match
---
name: self [6624,6628]
name: self [6507,6511]
===
match
---
name: status_code [1504,1515]
name: status_code [1504,1515]
===
match
---
operator: + [6881,6882]
operator: + [6764,6765]
===
match
---
simple_stmt [4856,4912]
simple_stmt [4739,4795]
===
match
---
trailer [7957,7965]
trailer [7840,7848]
===
match
---
simple_stmt [967,1024]
simple_stmt [967,1024]
===
match
---
param [3232,3246]
param [3232,3246]
===
match
---
simple_stmt [951,967]
simple_stmt [951,967]
===
match
---
name: __init__ [3287,3295]
name: __init__ [3287,3295]
===
match
---
suite [6219,7261]
suite [6102,7144]
===
match
---
simple_stmt [4964,5019]
simple_stmt [4847,4902]
===
match
---
suite [5190,5250]
suite [5073,5133]
===
match
---
name: msg [6606,6609]
name: msg [6489,6492]
===
match
---
operator: { [8185,8186]
operator: { [8068,8069]
===
match
---
operator: } [6909,6910]
operator: } [6792,6793]
===
match
---
name: self [3361,3365]
name: self [3361,3365]
===
match
---
not_test [7982,8024]
not_test [7865,7907]
===
match
---
operator: { [6757,6758]
operator: { [6640,6641]
===
match
---
name: self [3213,3217]
name: self [3213,3217]
===
match
---
simple_stmt [3279,3324]
simple_stmt [3279,3324]
===
match
---
funcdef [8097,8206]
funcdef [7980,8089]
===
match
---
import_name [951,966]
import_name [951,966]
===
match
---
name: Dict [991,995]
name: Dict [991,995]
===
match
---
name: super [4421,4426]
name: super [4421,4426]
===
match
---
name: message [5848,5855]
name: message [5731,5738]
===
match
---
name: self [2181,2185]
name: self [2181,2185]
===
match
---
operator: = [3344,3345]
operator: = [3344,3345]
===
match
---
operator: { [6955,6956]
operator: { [6838,6839]
===
match
---
simple_stmt [2338,2461]
simple_stmt [2338,2461]
===
match
---
fstring_end: " [6777,6778]
fstring_end: " [6660,6661]
===
match
---
trailer [7769,7771]
trailer [7652,7654]
===
match
---
atom_expr [7780,7792]
atom_expr [7663,7675]
===
match
---
name: self [8164,8168]
name: self [8047,8051]
===
match
---
name: str [7630,7633]
name: str [7513,7516]
===
match
---
string: """Raise when a Task with duplicate task_id is defined in the same DAG""" [4615,4688]
string: """Raise when a Task with duplicate task_id is defined in the same DAG""" [4615,4688]
===
match
---
name: error_no [6792,6800]
name: error_no [6675,6683]
===
match
---
name: self [6758,6762]
name: self [6641,6645]
===
match
---
name: AirflowException [1733,1749]
name: AirflowException [1733,1749]
===
match
---
simple_stmt [7753,7772]
simple_stmt [7636,7655]
===
match
---
name: line_no [7114,7121]
name: line_no [6997,7004]
===
match
---
operator: , [3230,3231]
operator: , [3230,3231]
===
match
---
classdef [5145,5250]
classdef [5028,5133]
===
match
---
atom_expr [7701,7729]
atom_expr [7584,7612]
===
match
---
simple_stmt [5301,5352]
simple_stmt [5184,5235]
===
match
---
simple_stmt [902,935]
simple_stmt [902,935]
===
match
---
simple_stmt [7312,7376]
simple_stmt [7195,7259]
===
match
---
name: AirflowNotFoundException [1530,1554]
name: AirflowNotFoundException [1530,1554]
===
match
---
subscriptlist [7665,7673]
subscriptlist [7548,7556]
===
match
---
name: __init__ [2172,2180]
name: __init__ [2172,2180]
===
match
---
string: """Raise when a DAG Run is not available in the system""" [4062,4119]
string: """Raise when a DAG Run is not available in the system""" [4062,4119]
===
match
---
name: __init__ [4429,4437]
name: __init__ [4429,4437]
===
match
---
operator: { [6898,6899]
operator: { [6781,6782]
===
match
---
classdef [3687,3789]
classdef [3687,3789]
===
match
---
name: int [6052,6055]
name: int [5935,5938]
===
match
---
name: AirflowTimetableInvalid [3693,3716]
name: AirflowTimetableInvalid [3693,3716]
===
match
---
name: __init__ [6579,6587]
name: __init__ [6462,6470]
===
match
---
name: msg [6588,6591]
name: msg [6471,6474]
===
match
---
suite [5625,5938]
suite [5508,5821]
===
match
---
name: DeprecationWarning [4529,4547]
name: DeprecationWarning [4529,4547]
===
match
---
name: parse_errors [6679,6691]
name: parse_errors [6562,6574]
===
match
---
name: super [2213,2218]
name: super [2213,2218]
===
match
---
name: AirflowException [5607,5623]
name: AirflowException [5490,5506]
===
match
---
classdef [1806,1910]
classdef [1806,1910]
===
match
---
string: """Raise when the task execution times-out""" [2614,2659]
string: """Raise when the task execution times-out""" [2614,2659]
===
match
---
atom_expr [7651,7675]
atom_expr [7534,7558]
===
match
---
simple_stmt [6106,6167]
simple_stmt [5989,6050]
===
match
---
name: parse_errors [6832,6844]
name: parse_errors [6715,6727]
===
match
---
name: error_no [6899,6907]
name: error_no [6782,6790]
===
match
---
name: message [6061,6068]
name: message [5944,5951]
===
match
---
tfpdef [6501,6515]
tfpdef [6384,6398]
===
match
---
atom_expr [6817,6848]
atom_expr [6700,6731]
===
match
---
name: BaseException [7397,7410]
name: BaseException [7280,7293]
===
match
---
suite [5074,5143]
suite [4957,5026]
===
match
---
operator: = [1696,1697]
operator: = [1696,1697]
===
match
---
name: self [6709,6713]
name: self [6592,6596]
===
match
---
simple_stmt [1856,1910]
simple_stmt [1856,1910]
===
match
---
string: """Raise when there is a violation of a Cluster Policy in Dag definition""" [3609,3684]
string: """Raise when there is a violation of a Cluster Policy in Dag definition""" [3609,3684]
===
match
---
name: result [6724,6730]
name: result [6607,6613]
===
match
---
classdef [2566,2660]
classdef [2566,2660]
===
match
---
tfpdef [3219,3230]
tfpdef [3219,3230]
===
match
---
argument [4438,4443]
argument [4438,4443]
===
match
---
param [2187,2202]
param [2187,2202]
===
match
---
parameters [6484,6553]
parameters [6367,6436]
===
match
---
import_from [1025,1103]
import_from [1025,1103]
===
match
---
operator: { [3480,3481]
operator: { [3480,3481]
===
match
---
argument [4445,4453]
argument [4445,4453]
===
match
---
suite [3016,3073]
suite [3016,3073]
===
match
---
string: """Raise when creating a DAG run for DAG which already has DAG run entry""" [4172,4247]
string: """Raise when creating a DAG run for DAG which already has DAG run entry""" [4172,4247]
===
match
---
name: incoming [3505,3513]
name: incoming [3505,3513]
===
match
---
operator: } [3513,3514]
operator: } [3513,3514]
===
match
---
operator: } [6163,6164]
operator: } [6046,6047]
===
match
---
name: __init__ [5885,5893]
name: __init__ [5768,5776]
===
match
---
atom_expr [4463,4562]
atom_expr [4463,4562]
===
match
---
name: airflow [1030,1037]
name: airflow [1030,1037]
===
match
---
name: existing [3399,3407]
name: existing [3399,3407]
===
match
---
name: __str__ [6083,6090]
name: __str__ [5966,5973]
===
match
---
string: """Raise when there is not enough slots in pool""" [5301,5351]
string: """Raise when there is not enough slots in pool""" [5184,5234]
===
match
---
simple_stmt [5410,5465]
simple_stmt [5293,5348]
===
match
---
operator: += [7163,7165]
operator: += [7046,7048]
===
match
---
name: __str__ [3428,3435]
name: __str__ [3428,3435]
===
match
---
parameters [6708,6714]
parameters [6591,6597]
===
match
---
name: str [3227,3230]
name: str [3227,3230]
===
match
---
string: """Raise when name of the stats is invalid""" [2518,2563]
string: """Raise when name of the stats is invalid""" [2518,2563]
===
match
---
arglist [4477,4561]
arglist [4477,4561]
===
match
---
import_from [967,1023]
import_from [967,1023]
===
match
---
name: ti_status [5916,5925]
name: ti_status [5799,5808]
===
match
---
suite [2204,2279]
suite [2204,2279]
===
match
---
name: Dict [7660,7664]
name: Dict [7543,7547]
===
match
---
trailer [7998,8006]
trailer [7881,7889]
===
match
---
operator: } [6772,6773]
operator: } [6655,6656]
===
match
---
import_as_names [986,1023]
import_as_names [986,1023]
===
match
---
arith_expr [7166,7237]
arith_expr [7049,7120]
===
match
---
name: trigger [7600,7607]
name: trigger [7483,7490]
===
match
---
name: AirflowException [4833,4849]
name: AirflowException [4716,4732]
===
match
---
classdef [1383,1522]
classdef [1383,1522]
===
match
---
expr_stmt [3332,3352]
expr_stmt [3332,3352]
===
match
---
funcdef [3424,3548]
funcdef [3424,3548]
===
match
---
operator: , [7633,7634]
operator: , [7516,7517]
===
match
---
name: AirflowException [2591,2607]
name: AirflowException [2591,2607]
===
match
---
name: code_utils [1123,1133]
name: code_utils [1123,1133]
===
match
---
string: """     Base class for all Airflow's errors.     Each custom exception should be derived from this class     """ [1245,1357]
string: """     Base class for all Airflow's errors.     Each custom exception should be derived from this class     """ [1245,1357]
===
match
---
atom_expr [2213,2231]
atom_expr [2213,2231]
===
match
---
fstring_string:   [6910,6911]
fstring_string:   [6793,6794]
===
match
---
expr_stmt [7850,7870]
expr_stmt [7733,7753]
===
match
---
atom_expr [7811,7827]
atom_expr [7694,7710]
===
match
---
classdef [1206,1381]
classdef [1206,1381]
===
match
---
operator: -> [8116,8118]
operator: -> [7999,8001]
===
match
---
name: super [3279,3284]
name: super [3279,3284]
===
match
---
name: trigger [7795,7802]
name: trigger [7678,7685]
===
match
---
simple_stmt [2715,2757]
simple_stmt [2715,2757]
===
match
---
expr_stmt [1363,1380]
expr_stmt [1363,1380]
===
match
---
trailer [7198,7208]
trailer [7081,7091]
===
match
---
name: TaskDeferralError [8214,8231]
name: TaskDeferralError [8097,8114]
===
match
---
classdef [1524,1702]
classdef [1524,1702]
===
match
---
name: reschedule_date [2245,2260]
name: reschedule_date [2245,2260]
===
match
---
classdef [4250,4563]
classdef [4250,4563]
===
match
---
trailer [4426,4428]
trailer [4426,4428]
===
match
---
name: DagRunNotFound [4016,4030]
name: DagRunNotFound [4016,4030]
===
match
---
atom_expr [3332,3343]
atom_expr [3332,3343]
===
match
---
name: FileSyntaxError [5946,5961]
name: FileSyntaxError [5829,5844]
===
match
---
simple_stmt [3361,3386]
simple_stmt [3361,3386]
===
match
---
name: self [7575,7579]
name: self [7458,7462]
===
match
---
expr_stmt [2240,2278]
expr_stmt [2240,2278]
===
match
---
atom_expr [7994,8006]
atom_expr [7877,7889]
===
match
---
fstring_end: " [6978,6979]
fstring_end: " [6861,6862]
===
match
---
simple_stmt [1025,1104]
simple_stmt [1025,1104]
===
match
---
param [5848,5856]
param [5731,5739]
===
match
---
string: """Raise when a Task is not available in the system""" [4964,5018]
string: """Raise when a Task is not available in the system""" [4847,4901]
===
match
---
parameters [4388,4411]
parameters [4388,4411]
===
match
---
string: """Raise when a DAG has an invalid timetable.""" [3740,3788]
string: """Raise when a DAG has an invalid timetable.""" [3740,3788]
===
match
---
string: "\n" [7233,7237]
string: "\n" [7116,7120]
===
match
---
name: self [6116,6120]
name: self [5999,6003]
===
match
---
name: BackfillUnfinished [5588,5606]
name: BackfillUnfinished [5471,5489]
===
match
---
name: TaskNotFound [4920,4932]
name: TaskNotFound [4803,4815]
===
match
---
simple_stmt [8132,8206]
simple_stmt [8015,8089]
===
match
---
operator: = [6731,6732]
operator: = [6614,6615]
===
match
---
atom_expr [7710,7728]
atom_expr [7593,7611]
===
match
---
suite [1851,1910]
suite [1851,1910]
===
match
---
param [6485,6490]
param [6368,6373]
===
match
---
simple_stmt [6571,6593]
simple_stmt [6454,6476]
===
match
---
name: line_no [7007,7014]
name: line_no [6890,6897]
===
match
---
fstring_end: " [8204,8205]
fstring_end: " [8087,8088]
===
match
---
parameters [2180,2203]
parameters [2180,2203]
===
match
---
name: self [5911,5915]
name: self [5794,5798]
===
match
---
trailer [3398,3407]
trailer [3398,3407]
===
match
---
name: kwargs [7864,7870]
name: kwargs [7747,7753]
===
match
---
param [3219,3231]
param [3219,3231]
===
match
---
name: self [7850,7854]
name: self [7733,7737]
===
match
---
trailer [6762,6772]
trailer [6645,6655]
===
match
---
operator: , [7607,7608]
operator: , [7490,7491]
===
match
---
atom_expr [5911,5925]
atom_expr [5794,5808]
===
match
---
name: AirflowException [2998,3014]
name: AirflowException [2998,3014]
===
match
---
arglist [6827,6847]
arglist [6710,6730]
===
match
---
return_stmt [8132,8205]
return_stmt [8015,8088]
===
match
---
tfpdef [7692,7729]
tfpdef [7575,7612]
===
match
---
string: """Raise when the requested object/resource is not available in the system""" [1601,1678]
string: """Raise when the requested object/resource is not available in the system""" [1601,1678]
===
match
---
trailer [2220,2229]
trailer [2220,2229]
===
match
---
atom_expr [3481,3492]
atom_expr [3481,3492]
===
match
---
name: trigger [8169,8176]
name: trigger [8052,8059]
===
match
---
simple_stmt [6624,6651]
simple_stmt [6507,6534]
===
match
---
name: warnings [958,966]
name: warnings [958,966]
===
match
---
trailer [3284,3286]
trailer [3284,3286]
===
match
---
name: __init__ [7557,7565]
name: __init__ [7440,7448]
===
match
---
name: self [6736,6740]
name: self [6619,6623]
===
match
---
simple_stmt [1504,1522]
simple_stmt [1504,1522]
===
match
---
suite [2804,2853]
suite [2804,2853]
===
match
---
operator: , [995,996]
operator: , [995,996]
===
match
---
atom_expr [6624,6638]
atom_expr [6507,6521]
===
match
---
expr_stmt [6034,6056]
expr_stmt [5917,5939]
===
match
---
name: timeout [7894,7901]
name: timeout [7777,7784]
===
match
---
if_stmt [7099,7238]
if_stmt [6982,7121]
===
match
---
simple_stmt [5195,5250]
simple_stmt [5078,5133]
===
match
---
classdef [3896,4008]
classdef [3896,4008]
===
match
---
name: parse_error [6802,6813]
name: parse_error [6685,6696]
===
match
---
atom_expr [3500,3513]
atom_expr [3500,3513]
===
match
---
operator: , [6515,6516]
operator: , [6398,6399]
===
match
---
string: """Raise when there is configuration problem""" [1756,1803]
string: """Raise when there is configuration problem""" [1756,1803]
===
match
---
name: AirflowException [3717,3733]
name: AirflowException [3717,3733]
===
match
---
suite [2710,2757]
suite [2710,2757]
===
match
---
name: dag_id [3337,3343]
name: dag_id [3337,3343]
===
match
---
name: self [7879,7883]
name: self [7762,7766]
===
match
---
trailer [7070,7078]
trailer [6953,6961]
===
match
---
fstring_start: f" [6883,6885]
fstring_start: f" [6766,6768]
===
match
---
operator: = [1375,1376]
operator: = [1375,1376]
===
match
---
simple_stmt [3332,3353]
simple_stmt [3332,3353]
===
match
---
name: trigger [7785,7792]
name: trigger [7668,7675]
===
match
---
name: FileSyntaxError [6536,6551]
name: FileSyntaxError [6419,6434]
===
match
---
name: parse_error [7102,7113]
name: parse_error [6985,6996]
===
match
---
param [8110,8114]
param [7993,7997]
===
match
---
name: self [3532,3536]
name: self [3532,3536]
===
match
---
name: str [7665,7668]
name: str [7548,7551]
===
match
---
simple_stmt [1162,1204]
simple_stmt [1162,1204]
===
match
---
trailer [6587,6592]
trailer [6470,6475]
===
match
---
operator: { [3531,3532]
operator: { [3531,3532]
===
match
---
classdef [2967,3073]
classdef [2967,3073]
===
match
---
name: DagRunAlreadyExists [4128,4147]
name: DagRunAlreadyExists [4128,4147]
===
match
---
funcdef [2168,2279]
funcdef [2168,2279]
===
match
---
operator: = [2261,2262]
operator: = [2261,2262]
===
match
---
classdef [2855,2965]
classdef [2855,2965]
===
match
---
operator: } [6975,6976]
operator: } [6858,6859]
===
match
---
dotted_name [1167,1189]
dotted_name [1167,1189]
===
match
---
name: List [6531,6535]
name: List [6414,6418]
===
match
---
trailer [7659,7675]
trailer [7542,7558]
===
match
---
name: AirflowException [7289,7305]
name: AirflowException [7172,7188]
===
match
---
simple_stmt [6601,6616]
simple_stmt [6484,6499]
===
match
---
simple_stmt [5630,5824]
simple_stmt [5513,5707]
===
match
---
trailer [5893,5902]
trailer [5776,5785]
===
match
---
return_stmt [7247,7260]
return_stmt [7130,7143]
===
match
---
name: file_path [6763,6772]
name: file_path [6646,6655]
===
match
---
operator: , [6499,6500]
operator: , [6382,6383]
===
match
---
atom_expr [6116,6128]
atom_expr [5999,6011]
===
match
---
trailer [4437,4454]
trailer [4437,4454]
===
match
---
fstring_end: " [7081,7082]
fstring_end: " [6964,6965]
===
match
---
operator: , [3312,3313]
operator: , [3312,3313]
===
match
---
trailer [7883,7891]
trailer [7766,7774]
===
match
---
operator: ** [4445,4447]
operator: ** [4445,4447]
===
match
---
simple_stmt [4421,4455]
simple_stmt [4421,4455]
===
match
---
string: """Exceptions used by Airflow""" [902,934]
string: """Exceptions used by Airflow""" [902,934]
===
match
---
atom_expr [6531,6552]
atom_expr [6414,6435]
===
match
---
operator: { [8163,8164]
operator: { [8046,8047]
===
match
---
operator: += [7039,7041]
operator: += [6922,6924]
===
match
---
trailer [3286,3295]
trailer [3286,3295]
===
match
---
simple_stmt [4463,4563]
simple_stmt [4463,4563]
===
match
---
param [5857,5866]
param [5740,5749]
===
match
---
name: AirflowNotFoundException [3809,3833]
name: AirflowNotFoundException [3809,3833]
===
match
---
parameters [7565,7743]
parameters [7448,7626]
===
match
---
simple_stmt [1245,1358]
simple_stmt [1245,1358]
===
match
---
classdef [5582,5938]
classdef [5465,5821]
===
match
---
parameters [3435,3441]
parameters [3435,3441]
===
match
---
atom_expr [6571,6592]
atom_expr [6454,6475]
===
match
---
trailer [7221,7229]
trailer [7104,7112]
===
match
---
param [3213,3218]
param [3213,3218]
===
match
---
suite [3944,4008]
suite [3944,4008]
===
match
---
fstring [6113,6166]
fstring [5996,6049]
===
match
---
if_stmt [7950,8092]
if_stmt [7833,7975]
===
match
---
classdef [4808,4912]
classdef [4691,4795]
===
match
---
simple_stmt [935,951]
simple_stmt [935,951]
===
match
---
name: str [6146,6149]
name: str [6029,6032]
===
match
---
operator: = [3375,3376]
operator: = [3375,3376]
===
match
---
name: parse_errors [6517,6529]
name: parse_errors [6400,6412]
===
match
---
fstring_string:  - also found in  [3514,3531]
fstring_string:  - also found in  [3514,3531]
===
match
---
simple_stmt [6224,6467]
simple_stmt [6107,6350]
===
match
---
name: str [3445,3448]
name: str [3445,3448]
===
match
---
name: msg [6741,6744]
name: msg [6624,6627]
===
match
---
name: AirflowConfigException [1710,1732]
name: AirflowConfigException [1710,1732]
===
match
---
dotted_name [1030,1062]
dotted_name [1030,1062]
===
match
---
atom_expr [6758,6772]
atom_expr [6641,6655]
===
match
---
name: airflow [1109,1116]
name: airflow [1109,1116]
===
match
---
expr_stmt [7032,7082]
expr_stmt [6915,6965]
===
match
---
name: line_no [7071,7078]
name: line_no [6954,6961]
===
match
---
suite [4959,5019]
suite [4842,4902]
===
match
---
name: self [8110,8114]
name: self [7993,7997]
===
match
---
classdef [4565,4689]
classdef [4565,4689]
===
match
---
name: AirflowFailException [2861,2881]
name: AirflowFailException [2861,2881]
===
match
---
name: AirflowNotFoundException [3918,3942]
name: AirflowNotFoundException [3918,3942]
===
match
---
suite [7015,7238]
suite [6898,7121]
===
match
---
trailer [5915,5925]
trailer [5798,5808]
===
match
---
name: reschedule_date [2187,2202]
name: reschedule_date [2187,2202]
===
match
---
name: AirflowException [2315,2331]
name: AirflowException [2315,2331]
===
match
---
fstring_string: \n [7079,7081]
fstring_string: \n [6962,6964]
===
match
---
param [4389,4394]
param [4389,4394]
===
match
---
trailer [7815,7827]
trailer [7698,7710]
===
match
---
import_from [1104,1161]
import_from [1104,1161]
===
match
---
term [6872,6880]
term [6755,6763]
===
match
---
number: 20 [6878,6880]
number: 20 [6761,6763]
===
match
---
name: message [6121,6128]
name: message [6004,6011]
===
match
---
name: kwargs [7855,7861]
name: kwargs [7738,7744]
===
match
---
name: self [7953,7957]
name: self [7836,7840]
===
match
---
name: DagConcurrencyLimitReached [5360,5386]
name: DagConcurrencyLimitReached [5243,5269]
===
match
---
suite [7744,8092]
suite [7627,7975]
===
match
---
fstring_string: \n [6976,6978]
fstring_string: \n [6859,6861]
===
match
---
expr_stmt [6624,6650]
expr_stmt [6507,6533]
===
match
---
fstring_expr [6757,6773]
fstring_expr [6640,6656]
===
match
---
name: method_name [7617,7628]
name: method_name [7500,7511]
===
match
---
name: method_name [7816,7827]
name: method_name [7699,7710]
===
match
---
suite [3270,3419]
suite [3270,3419]
===
match
---
name: self [3481,3485]
name: self [3481,3485]
===
match
---
operator: { [3499,3500]
operator: { [3499,3500]
===
match
---
name: line_no [6155,6162]
name: line_no [6038,6045]
===
match
---
fstring_format_spec [6907,6909]
fstring_format_spec [6790,6792]
===
match
---
suite [1596,1702]
suite [1596,1702]
===
match
---
fstring [8139,8205]
fstring [8022,8088]
===
match
---
number: 2 [4560,4561]
number: 2 [4560,4561]
===
match
---
simple_stmt [3840,3894]
simple_stmt [3840,3894]
===
match
---
expr_stmt [6601,6615]
expr_stmt [6484,6498]
===
match
---
operator: , [4400,4401]
operator: , [4400,4401]
===
match
---
trailer [6628,6638]
trailer [6511,6521]
===
match
---
file_input [902,8320]
file_input [902,8203]
===
match
---
simple_stmt [5877,5903]
simple_stmt [5760,5786]
===
match
---
operator: , [7736,7737]
operator: , [7619,7620]
===
match
---
atom_expr [7102,7121]
atom_expr [6985,7004]
===
match
---
name: AirflowSkipException [2765,2785]
name: AirflowSkipException [2765,2785]
===
match
---
suite [1963,2279]
suite [1963,2279]
===
match
---
operator: * [6919,6920]
operator: * [6802,6803]
===
match
---
fstring_expr [6955,6976]
fstring_expr [6838,6859]
===
match
---
simple_stmt [2905,2965]
simple_stmt [2905,2965]
===
match
---
operator: { [6145,6146]
operator: { [6028,6029]
===
match
---
trailer [6831,6844]
trailer [6714,6727]
===
match
---
name: file_path [6641,6650]
name: file_path [6524,6533]
===
match
---
operator: , [989,990]
operator: , [989,990]
===
match
---
name: method_name [8191,8202]
name: method_name [8074,8085]
===
match
---
name: NotFound [1070,1078]
name: NotFound [1070,1078]
===
match
---
param [4395,4401]
param [4395,4401]
===
match
---
number: 20 [6921,6923]
number: 20 [6804,6806]
===
match
---
string: """Raise when task max_active_tasks limit is reached""" [5524,5579]
string: """Raise when task max_active_tasks limit is reached""" [5407,5462]
===
match
---
name: __init__ [3204,3212]
name: __init__ [3204,3212]
===
match
---
param [7643,7683]
param [7526,7566]
===
match
---
name: AirflowException [5387,5403]
name: AirflowException [5270,5286]
===
match
---
trailer [6663,6676]
trailer [6546,6559]
===
match
---
operator: , [7208,7209]
operator: , [7091,7092]
===
match
---
name: self [8186,8190]
name: self [8069,8073]
===
match
---
name: warnings [4463,4471]
name: warnings [4463,4471]
===
match
---
operator: = [4559,4560]
operator: = [4559,4560]
===
match
---
classdef [7263,7376]
classdef [7146,7259]
===
match
---
trailer [6740,6744]
trailer [6623,6627]
===
match
---
name: self [6091,6095]
name: self [5974,5978]
===
match
---
trailer [7854,7861]
trailer [7737,7744]
===
match
---
trailer [2229,2231]
trailer [2229,2231]
===
match
---
name: AirflowException [1555,1571]
name: AirflowException [1555,1571]
===
match
---
name: __init__ [2221,2229]
name: __init__ [2221,2229]
===
match
---
operator: += [6950,6952]
operator: += [6833,6835]
===
match
---
trailer [7718,7728]
trailer [7601,7611]
===
match
---
fstring_start: f" [6953,6955]
fstring_start: f" [6836,6838]
===
match
---
exprlist [6792,6813]
exprlist [6675,6696]
===
match
---
return_stmt [3458,3547]
return_stmt [3458,3547]
===
match
---
name: args [4396,4400]
name: args [4396,4400]
===
match
---
funcdef [5829,5938]
funcdef [5712,5821]
===
match
---
arith_expr [6872,6930]
arith_expr [6755,6813]
===
match
---
atom_expr [7660,7674]
atom_expr [7543,7557]
===
match
---
operator: * [6876,6877]
operator: * [6759,6760]
===
match
---
simple_stmt [3136,3195]
simple_stmt [3136,3195]
===
match
---
name: DagNotFound [3797,3808]
name: DagNotFound [3797,3808]
===
match
---
trailer [6120,6128]
trailer [6003,6011]
===
match
---
name: List [997,1001]
name: List [997,1001]
===
match
---
operator: , [3245,3246]
operator: , [3245,3246]
===
match
---
name: self [7994,7998]
name: self [7877,7881]
===
match
---
simple_stmt [6061,6074]
simple_stmt [5944,5957]
===
match
---
classdef [2662,2757]
classdef [2662,2757]
===
match
---
name: self [6659,6663]
name: self [6542,6546]
===
match
---
classdef [5467,5580]
classdef [5350,5463]
===
match
---
name: timeout [7999,8006]
name: timeout [7882,7889]
===
match
---
classdef [5940,6167]
classdef [5823,6050]
===
match
---
suite [6562,6692]
suite [6445,6575]
===
match
---
raise_stmt [8038,8091]
raise_stmt [7921,7974]
===
match
---
name: AirflowException [1407,1423]
name: AirflowException [1407,1423]
===
match
---
name: parse_error [6956,6967]
name: parse_error [6839,6850]
===
match
---
trailer [6051,6056]
trailer [5934,5939]
===
match
---
classdef [5252,5352]
classdef [5135,5235]
===
match
---
string: """Raise when a DAG is not available in the system""" [3840,3893]
string: """Raise when a DAG is not available in the system""" [3840,3893]
===
match
---
name: AirflowException [1833,1849]
name: AirflowException [1833,1849]
===
match
---
operator: = [6610,6611]
operator: = [6493,6494]
===
match
---
operator: = [1516,1517]
operator: = [1516,1517]
===
match
---
name: AirflowClusterPolicyViolation [3556,3585]
name: AirflowClusterPolicyViolation [3556,3585]
===
match
---
simple_stmt [2240,2279]
simple_stmt [2240,2279]
===
match
---
classdef [2463,2564]
classdef [2463,2564]
===
match
---
string: """Raise when a DAG ID is still in DagBag i.e., DAG file is in DAG folder""" [4294,4370]
string: """Raise when a DAG ID is still in DagBag i.e., DAG file is in DAG folder""" [4294,4370]
===
match
---
trailer [8168,8176]
trailer [8051,8059]
===
match
---
param [6709,6713]
param [6592,6596]
===
match
---
operator: } [8176,8177]
operator: } [8059,8060]
===
match
---
name: AirflowException [5278,5294]
name: AirflowException [5161,5177]
===
match
---
simple_stmt [3394,3419]
simple_stmt [3394,3419]
===
match
---
operator: , [6800,6801]
operator: , [6683,6684]
===
match
---
simple_stmt [3458,3548]
simple_stmt [3458,3548]
===
match
---
simple_stmt [3609,3685]
simple_stmt [3609,3685]
===
match
---
suite [8250,8320]
suite [8133,8203]
===
match
---
name: parse_error [6995,7006]
name: parse_error [6878,6889]
===
match
---
classdef [2759,2853]
classdef [2759,2853]
===
match
---
string: "\n" [6926,6930]
string: "\n" [6809,6813]
===
match
---
name: typing [972,978]
name: typing [972,978]
===
match
---
simple_stmt [7032,7083]
simple_stmt [6915,6966]
===
match
---
name: file_path [6629,6638]
name: file_path [6512,6521]
===
match
---
simple_stmt [7850,7871]
simple_stmt [7733,7754]
===
match
---
simple_stmt [8038,8092]
simple_stmt [7921,7975]
===
match
---
classdef [4122,4248]
classdef [4122,4248]
===
match
---
tfpdef [3247,3260]
tfpdef [3247,3260]
===
match
---
name: dag_id [3296,3302]
name: dag_id [3296,3302]
===
match
---
name: AirflowBadRequest [4270,4287]
name: AirflowBadRequest [4270,4287]
===
match
---
name: Exception [1229,1238]
name: Exception [1229,1238]
===
match
---
atom_expr [7753,7771]
atom_expr [7636,7654]
===
match
---
trailer [6826,6848]
trailer [6709,6731]
===
match
---
trailer [4471,4476]
trailer [4471,4476]
===
match
---
param [7575,7580]
param [7458,7463]
===
match
---
trailer [8054,8091]
trailer [7937,7974]
===
match
---
name: AirflowSmartSensorException [2287,2314]
name: AirflowSmartSensorException [2287,2314]
===
match
---
classdef [3075,3548]
classdef [3075,3548]
===
match
---
operator: , [8006,8007]
operator: , [7889,7890]
===
match
---
atom_expr [6146,6163]
atom_expr [6029,6046]
===
match
---
trailer [3336,3343]
trailer [3336,3343]
===
match
---
suite [3835,3894]
suite [3835,3894]
===
match
---
fstring_expr [3499,3514]
fstring_expr [3499,3514]
===
match
---
suite [2900,2965]
suite [2900,2965]
===
match
---
string: "DagFileExists is deprecated and will be removed." [4477,4527]
string: "DagFileExists is deprecated and will be removed." [4477,4527]
===
match
---
suite [6097,6167]
suite [5980,6050]
===
match
---
name: AirflowSensorTimeout [1812,1832]
name: AirflowSensorTimeout [1812,1832]
===
match
---
classdef [7378,8206]
classdef [7261,8089]
===
match
---
name: dag_id [3486,3492]
name: dag_id [3486,3492]
===
match
---
name: AirflowWebServerTimeout [2668,2691]
name: AirflowWebServerTimeout [2668,2691]
===
match
---
trailer [7760,7769]
trailer [7643,7652]
===
match
---
name: AirflowNotFoundException [4933,4957]
name: AirflowNotFoundException [4816,4840]
===
match
---
atom_expr [3394,3407]
atom_expr [3394,3407]
===
match
---
simple_stmt [1104,1162]
simple_stmt [1104,1162]
===
match
---
name: AirflowDagDuplicatedIdException [3081,3112]
name: AirflowDagDuplicatedIdException [3081,3112]
===
match
---
name: datetime [942,950]
name: datetime [942,950]
===
match
---
name: kwargs [4447,4453]
name: kwargs [4447,4453]
===
match
---
fstring [3465,3547]
fstring [3465,3547]
===
match
---
operator: , [3302,3303]
operator: , [3302,3303]
===
match
---
suite [8025,8092]
suite [7908,7975]
===
match
---
name: incoming [3366,3374]
name: incoming [3366,3374]
===
match
---
trailer [7193,7230]
trailer [7076,7113]
===
match
---
name: timeout [7884,7891]
name: timeout [7767,7774]
===
match
---
atom_expr [8186,8202]
atom_expr [8069,8085]
===
match
---
trailer [7784,7792]
trailer [7667,7675]
===
match
---
and_test [7102,7134]
and_test [6985,7017]
===
match
---
trailer [4476,4562]
trailer [4476,4562]
===
match
---
simple_stmt [2213,2232]
simple_stmt [2213,2232]
===
match
---
name: DuplicateTaskIdFound [4571,4591]
name: DuplicateTaskIdFound [4571,4591]
===
match
---
operator: , [7579,7580]
operator: , [7462,7463]
===
match
---
fstring_start: f" [3465,3467]
fstring_start: f" [3465,3467]
===
match
---
name: Any [7670,7673]
name: Any [7553,7556]
===
match
---
name: ApiConnextionNotFound [1573,1594]
name: ApiConnextionNotFound [1573,1594]
===
match
---
operator: = [7730,7731]
operator: = [7613,7614]
===
match
---
name: self [2240,2244]
name: self [2240,2244]
===
match
---
atom_expr [6659,6676]
atom_expr [6542,6559]
===
match
---
param [7600,7608]
param [7483,7491]
===
match
---
trailer [8190,8202]
trailer [8073,8085]
===
match
---
annassign [6041,6056]
annassign [5924,5939]
===
match
---
name: result [7254,7260]
name: result [7137,7143]
===
match
---
param [7617,7634]
param [7500,7517]
===
match
---
comp_op [7966,7972]
comp_op [7849,7855]
===
match
---
simple_stmt [5079,5143]
simple_stmt [4962,5026]
===
match
---
name: args [4439,4443]
name: args [4439,4443]
===
match
---
name: Optional [1015,1023]
name: Optional [1015,1023]
===
match
---
string: """     Raises when connection or variable file can not be parsed      :param msg: The human-readable description of the exception     :param file_path: A processed file that contains errors     :param parse_errors: File syntax errors     """ [6224,6466]
string: """     Raises when connection or variable file can not be parsed      :param msg: The human-readable description of the exception     :param file_path: A processed file that contains errors     :param parse_errors: File syntax errors     """ [6107,6349]
===
match
---
name: AirflowException [2692,2708]
name: AirflowException [2692,2708]
===
match
---
operator: ** [4402,4404]
operator: ** [4402,4404]
===
match
---
name: incoming [3304,3312]
name: incoming [3304,3312]
===
match
---
operator: = [7862,7863]
operator: = [7745,7746]
===
match
---
operator: , [5855,5856]
operator: , [5738,5739]
===
match
---
name: result [6943,6949]
name: result [6826,6832]
===
match
---
suite [5296,5352]
suite [5179,5235]
===
match
---
operator: { [7058,7059]
operator: { [6941,6942]
===
match
---
name: file_path [7199,7208]
name: file_path [7082,7091]
===
match
---
simple_stmt [7156,7238]
simple_stmt [7039,7121]
===
match
---
arglist [4438,4453]
arglist [4438,4453]
===
match
---
name: self [6827,6831]
name: self [6710,6714]
===
match
---
simple_stmt [1363,1381]
simple_stmt [1363,1381]
===
match
---
expr_stmt [3361,3385]
expr_stmt [3361,3385]
===
match
---
suite [7307,7376]
suite [7190,7259]
===
match
---
name: AirflowException [3586,3602]
name: AirflowException [3586,3602]
===
match
---
trailer [7758,7760]
trailer [7641,7643]
===
match
---
name: AirflowException [1945,1961]
name: AirflowException [1945,1961]
===
match
---
name: AirflowException [6201,6217]
name: AirflowException [6084,6100]
===
match
---
suite [5868,5938]
suite [5751,5821]
===
match
---
name: parse_error [7059,7070]
name: parse_error [6942,6953]
===
match
---
trailer [7993,8024]
trailer [7876,7907]
===
match
---
atom_expr [7210,7229]
atom_expr [7093,7112]
===
match
---
name: TaskConcurrencyLimitReached [5473,5500]
name: TaskConcurrencyLimitReached [5356,5383]
===
match
---
name: ConnectionNotUnique [7269,7288]
name: ConnectionNotUnique [7152,7171]
===
match
---
fstring_start: f" [6733,6735]
fstring_start: f" [6616,6618]
===
match
---
number: 404 [1698,1701]
number: 404 [1698,1701]
===
match
---
name: exceptions [1052,1062]
name: exceptions [1052,1062]
===
match
---
param [7692,7737]
param [7575,7620]
===
match
---
atom_expr [6736,6744]
atom_expr [6619,6627]
===
match
---
string: """Raise when there is a cycle in Dag definition""" [3021,3072]
string: """Raise when there is a cycle in Dag definition""" [3021,3072]
===
match
---
suite [6849,7238]
suite [6732,7121]
===
match
---
fstring [7042,7082]
fstring [6925,6965]
===
match
---
number: 1 [6846,6847]
number: 1 [6729,6730]
===
match
---
trailer [5884,5893]
trailer [5767,5776]
===
match
---
simple_stmt [2809,2853]
simple_stmt [2809,2853]
===
match
---
fstring_start: f" [6113,6115]
fstring_start: f" [5996,5998]
===
match
---
trailer [3365,3374]
trailer [3365,3374]
===
match
---
suite [3735,3789]
suite [3735,3789]
===
match
---
param [5842,5847]
param [5725,5730]
===
match
---
trailer [6967,6975]
trailer [6850,6858]
===
match
---
atom_expr [5877,5902]
atom_expr [5760,5785]
===
match
---
suite [3449,3548]
suite [3449,3548]
===
match
---
arglist [7994,8023]
arglist [7877,7906]
===
match
---
string: """Information about a single error in a file.""" [5979,6028]
string: """Information about a single error in a file.""" [5862,5911]
===
match
---
name: AirflowNotFoundException [5164,5188]
name: AirflowNotFoundException [5047,5071]
===
match
---
atom_expr [7194,7208]
atom_expr [7077,7091]
===
match
---
name: self [6485,6489]
name: self [6368,6372]
===
match
---
string: """Raise when multiple values are found for the same conn_id""" [7312,7375]
string: """Raise when multiple values are found for the same conn_id""" [7195,7258]
===
match
---
tfpdef [7617,7633]
tfpdef [7500,7516]
===
match
---
name: kwargs [7643,7649]
name: kwargs [7526,7532]
===
match
---
name: AirflowException [5501,5517]
name: AirflowException [5384,5400]
===
match
---
atom_expr [7986,8024]
atom_expr [7869,7907]
===
match
---
expr_stmt [1504,1521]
expr_stmt [1504,1521]
===
match
---
name: ti_status [5857,5866]
name: ti_status [5740,5749]
===
match
---
trailer [5882,5884]
trailer [5765,5767]
===
match
---
fstring_string: > [8203,8204]
fstring_string: > [8086,8087]
===
match
---
expr_stmt [3394,3418]
expr_stmt [3394,3418]
===
match
---
trailer [7113,7121]
trailer [6996,7004]
===
match
---
parameters [5841,5867]
parameters [5724,5750]
===
match
---
name: is_tty [7126,7132]
name: is_tty [7009,7015]
===
match
---
trailer [6154,6162]
trailer [6037,6045]
===
match
---
expr_stmt [6943,6979]
expr_stmt [6826,6862]
===
match
---
name: Any [986,989]
name: Any [986,989]
===
match
---
term [6915,6923]
term [6798,6806]
===
match
---
name: TaskDeferred [7384,7396]
name: TaskDeferred [7267,7279]
===
match
---
trailer [3504,3513]
trailer [3504,3513]
===
match
---
simple_stmt [6724,6779]
simple_stmt [6607,6662]
===
match
---
name: NamedTuple [5962,5972]
name: NamedTuple [5845,5855]
===
match
---
fstring_string: Ignoring DAG  [3467,3480]
fstring_string: Ignoring DAG  [3467,3480]
===
match
---
name: file_path [6501,6510]
name: file_path [6384,6393]
===
match
---
expr_stmt [6061,6073]
expr_stmt [5944,5956]
===
match
---
operator: = [5926,5927]
operator: = [5809,5810]
===
match
---
fstring_expr [8185,8203]
fstring_expr [8068,8086]
===
match
---
simple_stmt [4294,4371]
simple_stmt [4294,4371]
===
match
---
name: incoming [3232,3240]
name: incoming [3232,3240]
===
match
---
fstring_expr [6898,6910]
fstring_expr [6781,6793]
===
match
---
operator: , [1571,1572]
operator: , [1571,1572]
===
match
---
name: kwargs [4404,4410]
name: kwargs [4404,4410]
===
match
---
for_stmt [6788,7238]
for_stmt [6671,7121]
===
match
---
string: """Raise when the application or server cannot handle the request""" [1430,1498]
string: """Raise when the application or server cannot handle the request""" [1430,1498]
===
match
---
string: """Raised when a task failed during deferral for some reason.""" [8255,8319]
string: """Raised when a task failed during deferral for some reason.""" [8138,8202]
===
match
---
trailer [6149,6163]
trailer [6032,6046]
===
match
---
name: status_code [1363,1374]
name: status_code [1363,1374]
===
match
---
param [3436,3440]
param [3436,3440]
===
match
---
name: message [5894,5901]
name: message [5777,5784]
===
match
---
name: AirflowException [2882,2898]
name: AirflowException [2882,2898]
===
match
---
fstring_end: " [6911,6912]
fstring_end: " [6794,6795]
===
match
---
simple_stmt [1756,1804]
simple_stmt [1756,1804]
===
match
---
string: """Raise when a Pool is not available in the system""" [5195,5249]
string: """Raise when a Pool is not available in the system""" [5078,5132]
===
match
---
string: """Raise when the task should be failed without retrying""" [2905,2964]
string: """Raise when the task should be failed without retrying""" [2905,2964]
===
match
---
fstring_string: . Line number: s [6129,6145]
fstring_string: . Line number: s [6012,6028]
===
match
---
name: str [6512,6515]
name: str [6395,6398]
===
match
---
suite [4851,4912]
suite [4734,4795]
===
match
---
string: """Raise when a DAG code is not available in the system""" [3949,4007]
string: """Raise when a DAG code is not available in the system""" [3949,4007]
===
match
---
suite [4610,4689]
suite [4610,4689]
===
match
---
name: super [6571,6576]
name: super [6454,6459]
===
match
---
and_test [7953,8024]
and_test [7836,7907]
===
match
---
trailer [3295,3323]
trailer [3295,3323]
===
match
---
atom_expr [7126,7134]
atom_expr [7009,7017]
===
match
---
name: self [3332,3336]
name: self [3332,3336]
===
match
---
fstring_end: " [3546,3547]
fstring_end: " [3546,3547]
===
match
---
name: ApiConnextionNotFound [1082,1103]
name: ApiConnextionNotFound [1082,1103]
===
match
---
name: NamedTuple [1003,1013]
name: NamedTuple [1003,1013]
===
match
---
trailer [6535,6552]
trailer [6418,6435]
===
match
---
atom_expr [3361,3374]
atom_expr [3361,3374]
===
match
---
name: AirflowFileParseException [6175,6200]
name: AirflowFileParseException [6058,6083]
===
match
---
name: msg [6491,6494]
name: msg [6374,6377]
===
match
---
fstring [6953,6979]
fstring [6836,6862]
===
match
---
atom_expr [3532,3545]
atom_expr [3532,3545]
===
match
---
operator: * [4438,4439]
operator: * [4438,4439]
===
match
---
classdef [8208,8320]
classdef [8091,8203]
===
match
---
suite [3604,3685]
suite [3604,3685]
===
match
---
arglist [3296,3322]
arglist [3296,3322]
===
match
---
operator: = [7892,7893]
operator: = [7775,7776]
===
match
---
expr_stmt [7879,7901]
expr_stmt [7762,7784]
===
match
---
funcdef [6472,6692]
funcdef [6355,6575]
===
match
---
string: "Timeout value must be a timedelta" [8055,8090]
string: "Timeout value must be a timedelta" [7938,7973]
===
match
---
suite [7135,7238]
suite [7018,7121]
===
match
---
name: AirflowBadRequest [1389,1406]
name: AirflowBadRequest [1389,1406]
===
match
---
tfpdef [7643,7675]
tfpdef [7526,7558]
===
match
---
operator: , [1001,1002]
operator: , [1001,1002]
===
match
---
operator: += [6869,6871]
operator: += [6752,6754]
===
match
---
operator: { [6735,6736]
operator: { [6618,6619]
===
match
---
operator: + [6924,6925]
operator: + [6807,6808]
===
match
---
trailer [6576,6578]
trailer [6459,6461]
===
match
---
funcdef [6697,7261]
funcdef [6580,7144]
===
match
---
name: airflow [1167,1174]
name: airflow [1167,1174]
===
match
---
simple_stmt [2614,2660]
simple_stmt [2614,2660]
===
match
---
name: utils [1175,1180]
name: utils [1175,1180]
===
match
---
operator: , [7668,7669]
operator: , [7551,7552]
===
match
---
name: AirflowException [2786,2802]
name: AirflowException [2786,2802]
===
match
---
simple_stmt [4172,4248]
simple_stmt [4172,4248]
===
match
---
operator: + [7231,7232]
operator: + [7114,7115]
===
match
---
string: """Raise when the web server times out""" [2715,2756]
string: """Raise when the web server times out""" [2715,2756]
===
match
---
name: api_connexion [1038,1051]
name: api_connexion [1038,1051]
===
match
---
suite [4057,4120]
suite [4057,4120]
===
match
---
string: """Raise when there is a timeout on sensor polling""" [1856,1909]
string: """Raise when there is a timeout on sensor polling""" [1856,1909]
===
match
---
fstring_string: Line number:   [7044,7058]
fstring_string: Line number:   [6927,6941]
===
match
---
operator: , [4527,4528]
operator: , [4527,4528]
===
match
---
simple_stmt [7417,7548]
simple_stmt [7300,7431]
===
match
---
name: parse_error [7210,7221]
name: parse_error [7093,7104]
===
match
---
atom_expr [6956,6975]
atom_expr [6839,6858]
===
match
---
simple_stmt [7811,7842]
simple_stmt [7694,7725]
===
match
---
name: prepare_code_snippet [7173,7193]
name: prepare_code_snippet [7056,7076]
===
match
---
parameters [6090,6096]
parameters [5973,5979]
===
match
---
name: AirflowNotFoundException [4031,4055]
name: AirflowNotFoundException [4031,4055]
===
match
---
name: self [7194,7198]
name: self [7077,7081]
===
match
---
string: """Raise when the task should be skipped""" [2809,2852]
string: """Raise when the task should be skipped""" [2809,2852]
===
match
---
name: result [7156,7162]
name: result [7039,7045]
===
match
---
name: existing [3537,3545]
name: existing [3537,3545]
===
match
---
name: AirflowRescheduleException [1918,1944]
name: AirflowRescheduleException [1918,1944]
===
delete-tree
---
classdef [4691,4806]
    name: SerializedDagNotFound [4697,4718]
    name: DagNotFound [4719,4730]
    suite [4732,4806]
        simple_stmt [4737,4806]
            string: """Raise when DAG is not found in the serialized_dags table in DB""" [4737,4805]
