===
match
---
dotted_name [1686,1702]
dotted_name [1686,1702]
===
match
---
decorator [32074,32135]
decorator [32459,32520]
===
match
---
atom [26322,26324]
atom [26707,26709]
===
match
---
argument [19976,19988]
argument [20361,20373]
===
match
---
operator: = [9564,9565]
operator: = [9949,9950]
===
match
---
argument [16139,16164]
argument [16524,16549]
===
match
---
trailer [5547,5598]
trailer [5932,5983]
===
match
---
trailer [12824,12989]
trailer [13209,13374]
===
match
---
atom_expr [9591,9605]
atom_expr [9976,9990]
===
match
---
name: safe_mode [12204,12213]
name: safe_mode [12589,12598]
===
match
---
name: mock [13389,13393]
name: mock [13774,13778]
===
match
---
name: sync_to_db [29804,29814]
name: sync_to_db [30189,30199]
===
match
---
name: session [27101,27108]
name: session [27486,27493]
===
match
---
argument [16732,16743]
argument [17117,17128]
===
match
---
atom_expr [10621,10631]
atom_expr [11006,11016]
===
match
---
operator: , [15271,15272]
operator: , [15656,15657]
===
match
---
simple_stmt [37041,37334]
simple_stmt [37426,37719]
===
match
---
name: replace [11799,11806]
name: replace [12184,12191]
===
match
---
parameters [29167,29236]
parameters [29552,29621]
===
match
---
trailer [2173,2198]
trailer [2173,2198]
===
match
---
name: DagBag [27632,27638]
name: DagBag [28017,28023]
===
match
---
atom_expr [13479,13505]
atom_expr [13864,13890]
===
match
---
atom_expr [28643,28674]
atom_expr [29028,29059]
===
match
---
expr_stmt [19285,19359]
expr_stmt [19670,19744]
===
match
---
expr_stmt [25834,25903]
expr_stmt [26219,26288]
===
match
---
name: process_dag [25871,25882]
name: process_dag [26256,26267]
===
match
---
name: test_dag [20637,20645]
name: test_dag [21022,21030]
===
match
---
fstring_string: validating  [14655,14666]
fstring_string: validating  [15040,15051]
===
match
---
name: join [11635,11639]
name: join [12020,12024]
===
match
---
name: test_get_dag_without_refresh [8306,8334]
name: test_get_dag_without_refresh [8691,8719]
===
match
---
name: invalid_dag_files [7838,7855]
name: invalid_dag_files [8223,8240]
===
match
---
name: side_effect [29722,29733]
name: side_effect [30107,30118]
===
match
---
operator: , [18943,18944]
operator: , [19328,19329]
===
match
---
name: dag_id [13303,13309]
name: dag_id [13688,13694]
===
match
---
name: import_errors [6519,6532]
name: import_errors [6904,6917]
===
match
---
trailer [6862,6876]
trailer [7247,7261]
===
match
---
name: dag_bag [34469,34476]
name: dag_bag [34854,34861]
===
match
---
dotted_name [15427,15441]
dotted_name [15812,15826]
===
match
---
simple_stmt [17660,17707]
simple_stmt [18045,18092]
===
match
---
trailer [6870,6875]
trailer [7255,7260]
===
match
---
name: default_args [15736,15748]
name: default_args [16121,16133]
===
match
---
name: test_dont_load_example [3184,3206]
name: test_dont_load_example [3569,3591]
===
match
---
name: process_file [6222,6234]
name: process_file [6607,6619]
===
match
---
suite [5751,5773]
suite [6136,6158]
===
match
---
name: path [8115,8119]
name: path [8500,8504]
===
match
---
atom_expr [6287,6304]
atom_expr [6672,6689]
===
match
---
trailer [7435,7445]
trailer [7820,7830]
===
match
---
funcdef [5737,5773]
funcdef [6122,6158]
===
match
---
name: dag [24534,24537]
name: dag [24919,24922]
===
match
---
name: dagbag_stats [3950,3962]
name: dagbag_stats [4335,4347]
===
match
---
atom_expr [36603,36634]
atom_expr [36988,37019]
===
match
---
operator: , [25191,25192]
operator: , [25576,25577]
===
match
---
operator: = [26662,26663]
operator: = [27047,27048]
===
match
---
param [11466,11471]
param [11851,11856]
===
match
---
import_from [5638,5672]
import_from [6023,6057]
===
match
---
param [8798,8807]
param [9183,9192]
===
match
---
operator: } [28628,28629]
operator: } [29013,29014]
===
match
---
name: filename [20722,20730]
name: filename [21107,21115]
===
match
---
name: file [8053,8057]
name: file [8438,8442]
===
match
---
expr_stmt [17568,17647]
expr_stmt [17953,18032]
===
match
---
simple_stmt [12475,12513]
simple_stmt [12860,12898]
===
match
---
atom_expr [23534,23603]
atom_expr [23919,23988]
===
match
---
atom_expr [31172,31325]
atom_expr [31557,31710]
===
match
---
trailer [33341,33343]
trailer [33726,33728]
===
match
---
expr_stmt [14501,14576]
expr_stmt [14886,14961]
===
match
---
operator: == [37879,37881]
operator: == [38264,38266]
===
match
---
name: op_subdag_0 [16518,16529]
name: op_subdag_0 [16903,16914]
===
match
---
argument [20277,20298]
argument [20662,20683]
===
match
---
with_stmt [32464,33681]
with_stmt [32849,34066]
===
match
---
trailer [6183,6189]
trailer [6568,6574]
===
match
---
operator: } [37332,37333]
operator: } [37717,37718]
===
match
---
name: db [2303,2305]
name: db [2303,2305]
===
match
---
suite [6057,6639]
suite [6442,7024]
===
match
---
name: dag [13442,13445]
name: dag [13827,13830]
===
match
---
name: NamedTemporaryFile [5985,6003]
name: NamedTemporaryFile [6370,6388]
===
match
---
argument [36145,36167]
argument [36530,36552]
===
match
---
operator: = [19108,19109]
operator: = [19493,19494]
===
match
---
simple_stmt [33522,33536]
simple_stmt [33907,33921]
===
match
---
atom_expr [6390,6401]
atom_expr [6775,6786]
===
match
---
name: SerializationError [1254,1272]
name: SerializationError [1254,1272]
===
match
---
expr_stmt [14148,14188]
expr_stmt [14533,14573]
===
match
---
argument [3834,3856]
argument [4219,4241]
===
match
---
trailer [34278,34288]
trailer [34663,34673]
===
match
---
operator: = [12375,12376]
operator: = [12760,12761]
===
match
---
simple_stmt [19143,19196]
simple_stmt [19528,19581]
===
match
---
atom_expr [7479,7546]
atom_expr [7864,7931]
===
match
---
atom_expr [34852,34875]
atom_expr [35237,35260]
===
match
---
name: default_args [22491,22503]
name: default_args [22876,22888]
===
match
---
operator: , [11986,11987]
operator: , [12371,12372]
===
match
---
import_as_names [964,991]
import_as_names [964,991]
===
match
---
arglist [19394,19431]
arglist [19779,19816]
===
match
---
name: encode [5153,5159]
name: encode [5538,5544]
===
match
---
trailer [17002,17020]
trailer [17387,17405]
===
match
---
atom_expr [13996,14026]
atom_expr [14381,14411]
===
match
---
simple_stmt [6583,6639]
simple_stmt [6968,7024]
===
match
---
comparison [3131,3174]
comparison [3131,3174]
===
match
---
argument [12245,12290]
argument [12630,12675]
===
match
---
trailer [31559,31563]
trailer [31944,31948]
===
match
---
param [35830,35834]
param [36215,36219]
===
match
---
simple_stmt [13715,13817]
simple_stmt [14100,14202]
===
match
---
string: "test_example_bash_operator" [33612,33640]
string: "test_example_bash_operator" [33997,34025]
===
match
---
argument [28546,28568]
argument [28931,28953]
===
match
---
suite [4986,5361]
suite [5371,5746]
===
match
---
name: dag [11290,11293]
name: dag [11675,11678]
===
match
---
simple_stmt [29320,29349]
simple_stmt [29705,29734]
===
match
---
name: dagbag [26028,26034]
name: dagbag [26413,26419]
===
match
---
name: fileloc [11873,11880]
name: fileloc [12258,12265]
===
match
---
name: invalid_dag_files [8198,8215]
name: invalid_dag_files [8583,8600]
===
match
---
parameters [4979,4985]
parameters [5364,5370]
===
match
---
name: mock_sync_perm_for_dag [31338,31360]
name: mock_sync_perm_for_dag [31723,31745]
===
match
---
atom_expr [11362,11387]
atom_expr [11747,11772]
===
match
---
atom_expr [25124,25134]
atom_expr [25509,25519]
===
match
---
name: suffix [4621,4627]
name: suffix [5006,5012]
===
match
---
comparison [20633,20659]
comparison [21018,21044]
===
match
---
operator: = [25031,25032]
operator: = [25416,25417]
===
match
---
param [30900,30904]
param [31285,31289]
===
match
---
name: dagbag [22097,22103]
name: dagbag [22482,22488]
===
match
---
argument [20213,20230]
argument [20598,20615]
===
match
---
name: mock [31363,31367]
name: mock [31748,31752]
===
match
---
trailer [35135,35140]
trailer [35520,35525]
===
match
---
simple_stmt [3887,3924]
simple_stmt [4272,4309]
===
match
---
simple_stmt [13050,13076]
simple_stmt [13435,13461]
===
match
---
atom_expr [20316,20326]
atom_expr [20701,20711]
===
match
---
string: """With safe mode disabled, an empty python file should be discovered.""" [4495,4568]
string: """With safe mode disabled, an empty python file should be discovered.""" [4880,4953]
===
match
---
atom_expr [22056,22127]
atom_expr [22441,22512]
===
match
---
expr_stmt [5822,5920]
expr_stmt [6207,6305]
===
match
---
name: os [27667,27669]
name: os [28052,28054]
===
match
---
arglist [25081,25134]
arglist [25466,25519]
===
match
---
operator: , [34131,34132]
operator: , [34516,34517]
===
match
---
operator: == [26325,26327]
operator: == [26710,26712]
===
match
---
name: actual_dagbag [14630,14643]
name: actual_dagbag [15015,15028]
===
match
---
atom_expr [26664,26682]
atom_expr [27049,27067]
===
match
---
simple_stmt [10311,10380]
simple_stmt [10696,10765]
===
match
---
name: invalid_dag_files [8061,8078]
name: invalid_dag_files [8446,8463]
===
match
---
simple_stmt [19786,19802]
simple_stmt [20171,20187]
===
match
---
atom_expr [33174,33187]
atom_expr [33559,33572]
===
match
---
name: dagbag [37886,37892]
name: dagbag [38271,38277]
===
match
---
trailer [33222,33246]
trailer [33607,33631]
===
match
---
atom_expr [36507,36536]
atom_expr [36892,36921]
===
match
---
operator: , [10002,10003]
operator: , [10387,10388]
===
match
---
name: assert_called_once_with [33571,33594]
name: assert_called_once_with [33956,33979]
===
match
---
operator: = [7856,7857]
operator: = [8241,8242]
===
match
---
name: DummyOperator [18906,18919]
name: DummyOperator [19291,19304]
===
match
---
trailer [20448,20463]
trailer [20833,20848]
===
match
---
name: db [2144,2146]
name: db [2144,2146]
===
match
---
suite [28383,28949]
suite [28768,29334]
===
match
---
name: dagbag [3381,3387]
name: dagbag [3766,3772]
===
match
---
string: 'subdag_b.task' [18928,18943]
string: 'subdag_b.task' [19313,19328]
===
match
---
trailer [20276,20327]
trailer [20661,20712]
===
match
---
trailer [36281,36286]
trailer [36666,36671]
===
match
---
simple_stmt [850,866]
simple_stmt [850,866]
===
match
---
name: flush [3715,3720]
name: flush [4100,4105]
===
match
---
name: airflow [1497,1504]
name: airflow [1497,1504]
===
match
---
operator: = [20207,20208]
operator: = [20592,20593]
===
match
---
simple_stmt [26994,27027]
simple_stmt [27379,27412]
===
match
---
name: len [36323,36326]
name: len [36708,36711]
===
match
---
trailer [13321,13323]
trailer [13706,13708]
===
match
---
trailer [4420,4441]
trailer [4805,4826]
===
match
---
operator: == [11359,11361]
operator: == [11744,11746]
===
match
---
with_item [28355,28382]
with_item [28740,28767]
===
match
---
import_from [1817,1889]
import_from [1817,1889]
===
match
---
name: basename [8874,8882]
name: basename [9259,9267]
===
match
---
simple_stmt [36500,36559]
simple_stmt [36885,36944]
===
match
---
import_from [1378,1444]
import_from [1378,1444]
===
match
---
string: """Test that dagbag.sync_to_db is retried on OperationalError""" [29246,29310]
string: """Test that dagbag.sync_to_db is retried on OperationalError""" [29631,29695]
===
match
---
atom_expr [32799,32862]
atom_expr [33184,33247]
===
match
---
trailer [14077,14084]
trailer [14462,14469]
===
match
---
assert_stmt [3124,3174]
assert_stmt [3124,3174]
===
match
---
name: self [13111,13115]
name: self [13496,13500]
===
match
---
operator: , [27770,27771]
operator: , [28155,28156]
===
match
---
name: dag [16451,16454]
name: dag [16836,16839]
===
match
---
string: "test_zip.zip" [7530,7544]
string: "test_zip.zip" [7915,7929]
===
match
---
name: op_subdag_0 [16781,16792]
name: op_subdag_0 [17166,17177]
===
match
---
operator: , [5957,5958]
operator: , [6342,6343]
===
match
---
operator: @ [29010,29011]
operator: @ [29395,29396]
===
match
---
trailer [36376,36382]
trailer [36761,36767]
===
match
---
string: 'parent.op_subdag_1.opSubdag_C' [19063,19094]
string: 'parent.op_subdag_1.opSubdag_C' [19448,19479]
===
match
---
expr_stmt [19048,19122]
expr_stmt [19433,19507]
===
match
---
name: self [3601,3605]
name: self [3986,3990]
===
match
---
operator: = [16337,16338]
operator: = [16722,16723]
===
match
---
atom_expr [35504,35544]
atom_expr [35889,35929]
===
match
---
name: name [3997,4001]
name: name [4382,4386]
===
match
---
param [14258,14263]
param [14643,14648]
===
match
---
string: 'test_zip_dag' [10016,10030]
string: 'test_zip_dag' [10401,10415]
===
match
---
trailer [29449,29454]
trailer [29834,29839]
===
match
---
atom_expr [13957,13977]
atom_expr [14342,14362]
===
match
---
trailer [2059,2069]
trailer [2059,2069]
===
match
---
simple_stmt [4410,4447]
simple_stmt [4795,4832]
===
match
---
name: set_downstream [20449,20463]
name: set_downstream [20834,20848]
===
match
---
string: 'opSubdag_A' [24750,24762]
string: 'opSubdag_A' [25135,25147]
===
match
---
atom_expr [16412,16464]
atom_expr [16797,16849]
===
match
---
simple_stmt [33026,33062]
simple_stmt [33411,33447]
===
match
---
string: 'parent' [17547,17555]
string: 'parent' [17932,17940]
===
match
---
name: DagBag [36138,36144]
name: DagBag [36523,36529]
===
match
---
simple_stmt [2808,2834]
simple_stmt [2808,2834]
===
match
---
dotted_name [1278,1292]
dotted_name [1278,1292]
===
match
---
atom_expr [14940,14966]
atom_expr [15325,15351]
===
match
---
name: ApplessAirflowSecurityManager [32529,32558]
name: ApplessAirflowSecurityManager [32914,32943]
===
match
---
simple_stmt [1492,1541]
simple_stmt [1492,1541]
===
match
---
atom_expr [12233,12315]
atom_expr [12618,12700]
===
match
---
trailer [4911,4919]
trailer [5296,5304]
===
match
---
operator: , [31129,31130]
operator: , [31514,31515]
===
match
---
string: 'owner' [21429,21436]
string: 'owner' [21814,21821]
===
match
---
name: op_a [25472,25476]
name: op_a [25857,25861]
===
match
---
name: session [33117,33124]
name: session [33502,33509]
===
match
---
operator: = [19718,19719]
operator: = [20103,20104]
===
match
---
name: source [14004,14010]
name: source [14389,14395]
===
match
---
operator: = [17090,17091]
operator: = [17475,17476]
===
match
---
name: keepends [5901,5909]
name: keepends [6286,6294]
===
match
---
with_item [31089,31149]
with_item [31474,31534]
===
match
---
operator: , [35410,35411]
operator: , [35795,35796]
===
match
---
arglist [4213,4245]
arglist [4598,4630]
===
match
---
name: name [4914,4918]
name: name [5299,5303]
===
match
---
simple_stmt [32422,32456]
simple_stmt [32807,32841]
===
match
---
name: mkdtemp [1977,1984]
name: mkdtemp [1977,1984]
===
match
---
expr_stmt [26641,26682]
expr_stmt [27026,27067]
===
match
---
name: dag_id [12392,12398]
name: dag_id [12777,12783]
===
match
---
atom_expr [35057,35102]
atom_expr [35442,35487]
===
match
---
expr_stmt [36001,36027]
expr_stmt [36386,36412]
===
match
---
simple_stmt [35845,35884]
simple_stmt [36230,36269]
===
match
---
name: default_args [24693,24705]
name: default_args [25078,25090]
===
match
---
suite [26398,27192]
suite [26783,27577]
===
match
---
trailer [26561,26584]
trailer [26946,26969]
===
match
---
trailer [4212,4246]
trailer [4597,4631]
===
match
---
string: 'owner' [22507,22514]
string: 'owner' [22892,22899]
===
match
---
assert_stmt [36997,37032]
assert_stmt [37382,37417]
===
match
---
name: os [36835,36837]
name: os [37220,37222]
===
match
---
simple_stmt [23867,23920]
simple_stmt [24252,24305]
===
match
---
name: subdag_d [24362,24370]
name: subdag_d [24747,24755]
===
match
---
expr_stmt [20702,20765]
expr_stmt [21087,21150]
===
match
---
operator: , [16577,16578]
operator: , [16962,16963]
===
match
---
atom_expr [35914,35946]
atom_expr [36299,36331]
===
match
---
atom_expr [27516,27553]
atom_expr [27901,27938]
===
match
---
operator: , [17074,17075]
operator: , [17459,17460]
===
match
---
operator: == [34623,34625]
operator: == [35008,35010]
===
match
---
operator: = [32059,32060]
operator: = [32444,32445]
===
match
---
name: datetime [15400,15408]
name: datetime [15785,15793]
===
match
---
name: dag_ids [37024,37031]
name: dag_ids [37409,37416]
===
match
---
name: TEST_DAGS_FOLDER [8125,8141]
name: TEST_DAGS_FOLDER [8510,8526]
===
match
---
operator: = [20303,20304]
operator: = [20688,20689]
===
match
---
name: SerializedDAG [13210,13223]
name: SerializedDAG [13595,13608]
===
match
---
operator: = [17692,17693]
operator: = [18077,18078]
===
match
---
operator: , [11098,11099]
operator: , [11483,11484]
===
match
---
name: dag [19733,19736]
name: dag [20118,20121]
===
match
---
trailer [31640,31645]
trailer [32025,32030]
===
match
---
name: dagbag [36016,36022]
name: dagbag [36401,36407]
===
match
---
name: task_id [25404,25411]
name: task_id [25789,25796]
===
match
---
name: dag [5669,5672]
name: dag [6054,6057]
===
match
---
name: test_dag [20875,20883]
name: test_dag [21260,21268]
===
match
---
assert_stmt [34893,34972]
assert_stmt [35278,35357]
===
match
---
simple_stmt [13408,13463]
simple_stmt [13793,13848]
===
match
---
operator: , [34959,34960]
operator: , [35344,35345]
===
match
---
simple_stmt [9638,9706]
simple_stmt [10023,10091]
===
match
---
operator: } [3791,3792]
operator: } [4176,4177]
===
match
---
name: from_dict [13224,13233]
name: from_dict [13609,13618]
===
match
---
atom_expr [29443,29466]
atom_expr [29828,29851]
===
match
---
expr_stmt [11600,11686]
expr_stmt [11985,12071]
===
match
---
name: path [7383,7387]
name: path [7768,7772]
===
match
---
simple_stmt [13522,13559]
simple_stmt [13907,13944]
===
match
---
name: task_id [25493,25500]
name: task_id [25878,25885]
===
match
---
trailer [10519,10582]
trailer [10904,10967]
===
match
---
name: dag [11331,11334]
name: dag [11716,11719]
===
match
---
string: ".py" [3624,3629]
string: ".py" [4009,4014]
===
match
---
name: found_dags [20885,20895]
name: found_dags [21270,21280]
===
match
---
comparison [15019,15047]
comparison [15404,15432]
===
match
---
trailer [26715,26746]
trailer [27100,27131]
===
match
---
fstring_expr [14666,14674]
fstring_expr [15051,15059]
===
match
---
name: call [30060,30064]
name: call [30445,30449]
===
match
---
operator: = [25442,25443]
operator: = [25827,25828]
===
match
---
atom_expr [31363,31379]
atom_expr [31748,31764]
===
match
---
name: mock_dagmodel [10592,10605]
name: mock_dagmodel [10977,10990]
===
match
---
operator: , [31126,31127]
operator: , [31511,31512]
===
match
---
name: datetime [15673,15681]
name: datetime [16058,16066]
===
match
---
arglist [5548,5597]
arglist [5933,5982]
===
match
---
operator: = [31418,31419]
operator: = [31803,31804]
===
match
---
suite [24373,24584]
suite [24758,24969]
===
match
---
trailer [20936,20943]
trailer [21321,21328]
===
match
---
operator: , [16223,16224]
operator: , [16608,16609]
===
match
---
string: 'subdag_c.task' [24151,24166]
string: 'subdag_c.task' [24536,24551]
===
match
---
atom_expr [20029,20098]
atom_expr [20414,20483]
===
match
---
name: dagbag [7479,7485]
name: dagbag [7864,7870]
===
match
---
name: mock_bulk_write_to_db [29700,29721]
name: mock_bulk_write_to_db [30085,30106]
===
match
---
decorator [10214,10253]
decorator [10599,10638]
===
match
---
assert_stmt [8158,8216]
assert_stmt [8543,8601]
===
match
---
operator: == [3971,3973]
operator: == [4356,4358]
===
match
---
comparison [6590,6616]
comparison [6975,7001]
===
match
---
trailer [37023,37031]
trailer [37408,37416]
===
match
---
name: SubDagOperator [24727,24741]
name: SubDagOperator [25112,25126]
===
match
---
name: subdag_0 [24768,24776]
name: subdag_0 [25153,25161]
===
match
---
argument [19157,19180]
argument [19542,19565]
===
match
---
name: self [7431,7435]
name: self [7816,7820]
===
match
---
atom_expr [13650,13666]
atom_expr [14035,14051]
===
match
---
atom_expr [8996,9054]
atom_expr [9381,9439]
===
match
---
operator: = [10709,10710]
operator: = [11094,11095]
===
match
---
trailer [9350,9369]
trailer [9735,9754]
===
match
---
atom_expr [5144,5161]
atom_expr [5529,5546]
===
match
---
name: tags [31943,31947]
name: tags [32328,32332]
===
match
---
name: models [7929,7935]
name: models [8314,8320]
===
match
---
funcdef [20995,26108]
funcdef [21380,26493]
===
match
---
operator: , [25115,25116]
operator: , [25500,25501]
===
match
---
name: subdag [24868,24874]
name: subdag [25253,25259]
===
match
---
trailer [35970,35991]
trailer [36355,36376]
===
match
---
argument [7943,7968]
argument [8328,8353]
===
match
---
expr_stmt [26593,26632]
expr_stmt [26978,27017]
===
match
---
parameters [7234,7240]
parameters [7619,7625]
===
match
---
expr_stmt [29646,29690]
expr_stmt [30031,30075]
===
match
---
comparison [36184,36209]
comparison [36569,36594]
===
match
---
trailer [30064,30092]
trailer [30449,30477]
===
match
---
name: DummyOperator [18669,18682]
name: DummyOperator [19054,19067]
===
match
---
dotted_name [8260,8272]
dotted_name [8645,8657]
===
match
---
name: DAG [29395,29398]
name: DAG [29780,29783]
===
match
---
simple_stmt [11600,11687]
simple_stmt [11985,12072]
===
match
---
dotted_name [1228,1246]
dotted_name [1228,1246]
===
match
---
trailer [19156,19195]
trailer [19541,19580]
===
match
---
arglist [19870,19917]
arglist [20255,20302]
===
match
---
simple_stmt [33174,33188]
simple_stmt [33559,33573]
===
match
---
operator: == [27148,27150]
operator: == [27533,27535]
===
match
---
atom [34949,34972]
atom [35334,35357]
===
match
---
name: subdag [16675,16681]
name: subdag [17060,17066]
===
match
---
name: subdag_1 [16455,16463]
name: subdag_1 [16840,16848]
===
match
---
name: airflow [1191,1198]
name: airflow [1191,1198]
===
match
---
operator: = [25500,25501]
operator: = [25885,25886]
===
match
---
atom_expr [7406,7470]
atom_expr [7791,7855]
===
match
---
trailer [16901,16903]
trailer [17286,17288]
===
match
---
trailer [36382,36384]
trailer [36767,36769]
===
match
---
name: dagbag [29320,29326]
name: dagbag [29705,29711]
===
match
---
string: 'parent' [15603,15611]
string: 'parent' [15988,15996]
===
match
---
name: dag [32930,32933]
name: dag [33315,33318]
===
match
---
name: rollback [30281,30289]
name: rollback [30666,30674]
===
match
---
operator: = [25387,25388]
operator: = [25772,25773]
===
match
---
arglist [33612,33666]
arglist [33997,34051]
===
match
---
name: get_dag [3138,3145]
name: get_dag [3138,3145]
===
match
---
atom_expr [2144,2162]
atom_expr [2144,2162]
===
match
---
operator: , [9902,9903]
operator: , [10287,10288]
===
match
---
comparison [38294,38341]
comparison [38679,38726]
===
match
---
operator: = [29556,29557]
operator: = [29941,29942]
===
match
---
operator: , [15657,15658]
operator: , [16042,16043]
===
match
---
simple_stmt [31939,31962]
simple_stmt [32324,32347]
===
match
---
name: dagbag [4728,4734]
name: dagbag [5113,5119]
===
match
---
trailer [11072,11110]
trailer [11457,11495]
===
match
---
simple_stmt [31828,31842]
simple_stmt [32213,32227]
===
match
---
simple_stmt [20490,20501]
simple_stmt [20875,20886]
===
match
---
name: standard_subdag [16886,16901]
name: standard_subdag [17271,17286]
===
match
---
dotted_name [1023,1036]
dotted_name [1023,1036]
===
match
---
number: 1 [8978,8979]
number: 1 [9363,9364]
===
match
---
strings [7092,7191]
strings [7477,7576]
===
match
---
name: default_args [15624,15636]
name: default_args [16009,16021]
===
match
---
name: default_args [25032,25044]
name: default_args [25417,25429]
===
match
---
arglist [3597,3629]
arglist [3982,4014]
===
match
---
name: self [17216,17220]
name: self [17601,17605]
===
match
---
name: www [1554,1557]
name: www [1554,1557]
===
match
---
name: dag_folder [27656,27666]
name: dag_folder [28041,28051]
===
match
---
atom_expr [6512,6570]
atom_expr [6897,6955]
===
match
---
atom_expr [21662,21687]
atom_expr [22047,22072]
===
match
---
string: 'opSubdag_B' [19719,19731]
string: 'opSubdag_B' [20104,20116]
===
match
---
operator: = [4239,4240]
operator: = [4624,4625]
===
match
---
arglist [8125,8147]
arglist [8510,8532]
===
match
---
operator: , [19417,19418]
operator: , [19802,19803]
===
match
---
name: nested_subdags [20521,20535]
name: nested_subdags [20906,20920]
===
match
---
string: 'subdag_a.task' [18691,18706]
string: 'subdag_a.task' [19076,19091]
===
match
---
name: err [28838,28841]
name: err [29223,29226]
===
match
---
expr_stmt [14350,14431]
expr_stmt [14735,14816]
===
match
---
name: DAG [17666,17669]
name: DAG [18051,18054]
===
match
---
operator: , [12202,12203]
operator: , [12587,12588]
===
match
---
name: write_dag [34279,34288]
name: write_dag [34664,34673]
===
match
---
atom_expr [37004,37009]
atom_expr [37389,37394]
===
match
---
expr_stmt [13357,13398]
expr_stmt [13742,13783]
===
match
---
parameters [19024,19026]
parameters [19409,19411]
===
match
---
expr_stmt [8538,8577]
expr_stmt [8923,8962]
===
match
---
name: patch [28026,28031]
name: patch [28411,28416]
===
match
---
name: SubDagOperator [22425,22439]
name: SubDagOperator [22810,22824]
===
match
---
atom_expr [13377,13387]
atom_expr [13762,13772]
===
match
---
name: f [14181,14182]
name: f [14566,14567]
===
match
---
name: dag [36111,36114]
name: dag [36496,36499]
===
match
---
operator: += [12128,12130]
operator: += [12513,12515]
===
match
---
trailer [28307,28319]
trailer [28692,28704]
===
match
---
trailer [6908,6913]
trailer [7293,7298]
===
match
---
number: 5 [33844,33845]
number: 5 [34229,34230]
===
match
---
name: err [28914,28917]
name: err [29299,29302]
===
match
---
trailer [35934,35943]
trailer [36319,36328]
===
match
---
string: '' [15194,15196]
string: '' [15579,15581]
===
match
---
string: 'subdag_a.task' [23646,23661]
string: 'subdag_a.task' [24031,24046]
===
match
---
expr_stmt [16875,16903]
expr_stmt [17260,17288]
===
match
---
arglist [36571,36634]
arglist [36956,37019]
===
match
---
atom_expr [31207,31270]
atom_expr [31592,31655]
===
match
---
name: mock_dagmodel [11744,11757]
name: mock_dagmodel [12129,12142]
===
match
---
name: is_active [26731,26740]
name: is_active [27116,27125]
===
match
---
trailer [34399,34407]
trailer [34784,34792]
===
match
---
name: models [14071,14077]
name: models [14456,14462]
===
match
---
trailer [34799,34833]
trailer [35184,35218]
===
match
---
atom_expr [3578,3630]
atom_expr [3963,4015]
===
match
---
expr_stmt [17068,17125]
expr_stmt [17453,17510]
===
match
---
atom_expr [31580,31614]
atom_expr [31965,31999]
===
match
---
operator: += [11024,11026]
operator: += [11409,11411]
===
match
---
atom_expr [32764,32917]
atom_expr [33149,33302]
===
match
---
argument [4621,4633]
argument [5006,5018]
===
match
---
trailer [20095,20097]
trailer [20480,20482]
===
match
---
name: task_id [20181,20188]
name: task_id [20566,20573]
===
match
---
simple_stmt [17337,17353]
simple_stmt [17722,17738]
===
match
---
argument [12906,12928]
argument [13291,13313]
===
match
---
name: subdag [15550,15556]
name: subdag [15935,15941]
===
match
---
name: default_args [17680,17692]
name: default_args [18065,18077]
===
match
---
name: mock_sync_perm_for_dag [32670,32692]
name: mock_sync_perm_for_dag [33055,33077]
===
match
---
trailer [25170,25225]
trailer [25555,25610]
===
match
---
name: get_dag [34400,34407]
name: get_dag [34785,34792]
===
match
---
trailer [7378,7388]
trailer [7763,7773]
===
match
---
name: patch [11394,11399]
name: patch [11779,11784]
===
match
---
operator: { [3751,3752]
operator: { [4136,4137]
===
match
---
simple_stmt [32000,32069]
simple_stmt [32385,32454]
===
match
---
name: default_args [17568,17580]
name: default_args [17953,17965]
===
match
---
atom_expr [32707,32741]
atom_expr [33092,33126]
===
match
---
name: mock_dagmodel [8341,8354]
name: mock_dagmodel [8726,8739]
===
match
---
name: process_file [26335,26347]
name: process_file [26720,26732]
===
match
---
argument [18622,18647]
argument [19007,19032]
===
match
---
operator: == [4888,4890]
operator: == [5273,5275]
===
match
---
trailer [27520,27526]
trailer [27905,27911]
===
match
---
name: dag_folder [5257,5267]
name: dag_folder [5642,5652]
===
match
---
simple_stmt [14350,14432]
simple_stmt [14735,14817]
===
match
---
name: DAG [24405,24408]
name: DAG [24790,24793]
===
match
---
string: 'dag "{}" should {}be in dagbag.dags after processing dag "{}"' [15082,15145]
string: 'dag "{}" should {}be in dagbag.dags after processing dag "{}"' [15467,15530]
===
match
---
atom_expr [24875,24885]
atom_expr [25260,25270]
===
match
---
operator: = [18690,18691]
operator: = [19075,19076]
===
match
---
name: empty_dir [7959,7968]
name: empty_dir [8344,8353]
===
match
---
name: process_dag [13676,13687]
name: process_dag [14061,14072]
===
match
---
simple_stmt [24009,24090]
simple_stmt [24394,24475]
===
match
---
assert_stmt [37911,37944]
assert_stmt [38296,38329]
===
match
---
string: """         Test that we can refresh an ordinary .py DAG         """ [10311,10379]
string: """         Test that we can refresh an ordinary .py DAG         """ [10696,10764]
===
match
---
suite [14341,15287]
suite [14726,15672]
===
match
---
trailer [26093,26107]
trailer [26478,26492]
===
match
---
name: __path__ [35935,35943]
name: __path__ [36320,36328]
===
match
---
expr_stmt [37041,37333]
expr_stmt [37426,37718]
===
match
---
arglist [29515,29565]
arglist [29900,29950]
===
match
---
trailer [2265,2267]
trailer [2265,2267]
===
match
---
name: DagModel [1308,1316]
name: DagModel [1308,1316]
===
match
---
argument [3012,3037]
argument [3012,3037]
===
match
---
atom_expr [15245,15271]
atom_expr [15630,15656]
===
match
---
comparison [37847,37901]
comparison [38232,38286]
===
match
---
operator: = [19164,19165]
operator: = [19549,19550]
===
match
---
name: os [10503,10505]
name: os [10888,10890]
===
match
---
suite [11916,12215]
suite [12301,12600]
===
match
---
number: 0 [10846,10847]
number: 0 [11231,11232]
===
match
---
arglist [11407,11430]
arglist [11792,11815]
===
match
---
trailer [25590,25603]
trailer [25975,25988]
===
match
---
operator: = [35912,35913]
operator: = [36297,36298]
===
match
---
name: getsource [13897,13906]
name: getsource [14282,14291]
===
match
---
operator: @ [11393,11394]
operator: @ [11778,11779]
===
match
---
atom_expr [25443,25453]
atom_expr [25828,25838]
===
match
---
name: op_error [29661,29669]
name: op_error [30046,30054]
===
match
---
operator: , [30836,30837]
operator: , [31221,31222]
===
match
---
simple_stmt [36997,37033]
simple_stmt [37382,37418]
===
match
---
string: 'A' [25501,25504]
string: 'A' [25886,25889]
===
match
---
name: dagbag [12377,12383]
name: dagbag [12762,12768]
===
match
---
operator: == [4442,4444]
operator: == [4827,4829]
===
match
---
name: self [11152,11156]
name: self [11537,11541]
===
match
---
operator: = [5835,5836]
operator: = [6220,6221]
===
match
---
name: dagbag [13479,13485]
name: dagbag [13864,13870]
===
match
---
name: has_dag [13434,13441]
name: has_dag [13819,13826]
===
match
---
name: self [13688,13692]
name: self [14073,14077]
===
match
---
operator: == [35688,35690]
operator: == [36073,36075]
===
match
---
atom_expr [7499,7545]
atom_expr [7884,7930]
===
match
---
trailer [2251,2265]
trailer [2251,2265]
===
match
---
trailer [28864,28870]
trailer [29249,29255]
===
match
---
atom [13298,13348]
atom [13683,13733]
===
match
---
simple_stmt [25156,25226]
simple_stmt [25541,25611]
===
match
---
argument [3039,3061]
argument [3039,3061]
===
match
---
trailer [1964,1974]
trailer [1964,1974]
===
match
---
assert_stmt [7555,7592]
assert_stmt [7940,7977]
===
match
---
parameters [15377,15379]
parameters [15762,15764]
===
match
---
atom_expr [4421,4440]
atom_expr [4806,4825]
===
match
---
trailer [16116,16165]
trailer [16501,16550]
===
match
---
trailer [30289,30306]
trailer [30674,30691]
===
match
---
arglist [4601,4633]
arglist [4986,5018]
===
match
---
comparison [2743,2758]
comparison [2743,2758]
===
match
---
with_item [27437,27464]
with_item [27822,27849]
===
match
---
atom_expr [8866,8892]
atom_expr [9251,9277]
===
match
---
trailer [13493,13505]
trailer [13878,13890]
===
match
---
operator: , [37986,37987]
operator: , [38371,38372]
===
match
---
expr_stmt [25472,25505]
expr_stmt [25857,25890]
===
match
---
string: 'example_bash_operator.py' [8896,8922]
string: 'example_bash_operator.py' [9281,9307]
===
match
---
string: 'cycle_dag' [21389,21400]
string: 'cycle_dag' [21774,21785]
===
match
---
name: subdag_1 [16296,16304]
name: subdag_1 [16681,16689]
===
match
---
testlist_comp [4277,4298]
testlist_comp [4662,4683]
===
match
---
expr_stmt [32670,32741]
expr_stmt [33055,33126]
===
match
---
name: side_effect [28308,28319]
name: side_effect [28693,28704]
===
match
---
atom_expr [4694,4708]
atom_expr [5079,5093]
===
match
---
operator: , [932,933]
operator: , [932,933]
===
match
---
expr_stmt [35561,35643]
expr_stmt [35946,36028]
===
match
---
simple_stmt [14994,15287]
simple_stmt [15379,15672]
===
match
---
name: DAG [23534,23537]
name: DAG [23919,23922]
===
match
---
arglist [33776,33845]
arglist [34161,34230]
===
match
---
argument [19419,19431]
argument [19804,19816]
===
match
---
operator: = [20086,20087]
operator: = [20471,20472]
===
match
---
operator: = [19646,19647]
operator: = [20031,20032]
===
match
---
name: process_file [12164,12176]
name: process_file [12549,12561]
===
match
---
name: test_serialized_dags_are_written_to_db_on_sync [27201,27247]
name: test_serialized_dags_are_written_to_db_on_sync [27586,27632]
===
match
---
trailer [12391,12399]
trailer [12776,12784]
===
match
---
name: create_dagrun [13060,13073]
name: create_dagrun [13445,13458]
===
match
---
name: dag_folder [6979,6989]
name: dag_folder [7364,7374]
===
match
---
simple_stmt [13472,13514]
simple_stmt [13857,13899]
===
match
---
fstring [14653,14675]
fstring [15038,15060]
===
match
---
atom_expr [19380,19432]
atom_expr [19765,19817]
===
match
---
name: _TestDagBag [12233,12244]
name: _TestDagBag [12618,12629]
===
match
---
name: _sync_perm_for_dag [31399,31417]
name: _sync_perm_for_dag [31784,31802]
===
match
---
name: serialized_dag [1337,1351]
name: serialized_dag [1337,1351]
===
match
---
string: "test_example_bash_operator.py" [32830,32861]
string: "test_example_bash_operator.py" [33215,33246]
===
match
---
trailer [30704,30708]
trailer [31089,31093]
===
match
---
name: fileloc [20970,20977]
name: fileloc [21355,21362]
===
match
---
operator: @ [1914,1915]
operator: @ [1914,1915]
===
match
---
string: """         Don't crash when loading an invalid (contains a cycle) DAG file.         Don't load the dag into the DagBag either         """ [21035,21173]
string: """         Don't crash when loading an invalid (contains a cycle) DAG file.         Don't load the dag into the DagBag either         """ [21420,21558]
===
match
---
atom_expr [6179,6191]
atom_expr [6564,6576]
===
match
---
name: dag_file [38332,38340]
name: dag_file [38717,38725]
===
match
---
atom_expr [17666,17706]
atom_expr [18051,18091]
===
match
---
trailer [36198,36203]
trailer [36583,36588]
===
match
---
atom_expr [37752,37831]
atom_expr [38137,38216]
===
match
---
with_stmt [3573,4005]
with_stmt [3958,4390]
===
match
---
expr_stmt [29757,29788]
expr_stmt [30142,30173]
===
match
---
simple_stmt [24727,24797]
simple_stmt [25112,25182]
===
match
---
name: test_serialized_dag_errors_are_import_errors [28102,28146]
name: test_serialized_dag_errors_are_import_errors [28487,28531]
===
match
---
simple_stmt [6154,6167]
simple_stmt [6539,6552]
===
match
---
atom_expr [30055,30092]
atom_expr [30440,30477]
===
match
---
atom_expr [10104,10120]
atom_expr [10489,10505]
===
match
---
atom_expr [5559,5573]
atom_expr [5944,5958]
===
match
---
name: len [20633,20636]
name: len [21018,21021]
===
match
---
simple_stmt [11045,11111]
simple_stmt [11430,11496]
===
match
---
trailer [11634,11639]
trailer [12019,12024]
===
match
---
atom_expr [19997,20007]
atom_expr [20382,20392]
===
match
---
atom_expr [13050,13075]
atom_expr [13435,13460]
===
match
---
name: append [14457,14463]
name: append [14842,14848]
===
match
---
expr_stmt [10993,11028]
expr_stmt [11378,11413]
===
match
---
operator: == [20978,20980]
operator: == [21363,21365]
===
match
---
atom_expr [6265,6277]
atom_expr [6650,6662]
===
match
---
name: op_subdag_0 [25279,25290]
name: op_subdag_0 [25664,25675]
===
match
---
name: mock [29368,29372]
name: mock [29753,29757]
===
match
---
suite [16081,16275]
suite [16466,16660]
===
match
---
operator: = [30699,30700]
operator: = [31084,31085]
===
match
---
argument [18683,18706]
argument [19068,19091]
===
match
---
trailer [31103,31112]
trailer [31488,31497]
===
match
---
string: 'not ' [15221,15227]
string: 'not ' [15606,15612]
===
match
---
trailer [29721,29733]
trailer [30106,30118]
===
match
---
simple_stmt [6468,6493]
simple_stmt [6853,6878]
===
match
---
operator: - [13938,13939]
operator: - [14323,14324]
===
match
---
operator: = [15601,15602]
operator: = [15986,15987]
===
match
---
import_name [839,849]
import_name [839,849]
===
match
---
trailer [30069,30073]
trailer [30454,30458]
===
match
---
trailer [23880,23919]
trailer [24265,24304]
===
match
---
name: conf_vars [4265,4274]
name: conf_vars [4650,4659]
===
match
---
name: dag_id [14960,14966]
name: dag_id [15345,15351]
===
match
---
name: dagbag [9116,9122]
name: dagbag [9501,9507]
===
match
---
name: is_active [27017,27026]
name: is_active [27402,27411]
===
match
---
factor [13938,13940]
factor [14323,14325]
===
match
---
trailer [8873,8882]
trailer [9258,9267]
===
match
---
name: dag [20966,20969]
name: dag [21351,21354]
===
match
---
name: serialized_dag [36452,36466]
name: serialized_dag [36837,36851]
===
match
---
arglist [24742,24795]
arglist [25127,25180]
===
match
---
atom_expr [29797,29836]
atom_expr [30182,30221]
===
match
---
name: models [3820,3826]
name: models [4205,4211]
===
match
---
trailer [4357,4397]
trailer [4742,4782]
===
match
---
simple_stmt [3072,3116]
simple_stmt [3072,3116]
===
match
---
simple_stmt [36125,36169]
simple_stmt [36510,36554]
===
match
---
name: dags_last_fetched [13278,13295]
name: dags_last_fetched [13663,13680]
===
match
---
name: dag_folder [9580,9590]
name: dag_folder [9965,9975]
===
match
---
string: 'dag "{}" should {}have been found after processing dag "{}"' [14779,14840]
string: 'dag "{}" should {}have been found after processing dag "{}"' [15164,15225]
===
match
---
operator: = [23666,23667]
operator: = [24051,24052]
===
match
---
trailer [34558,34563]
trailer [34943,34948]
===
match
---
return_stmt [24325,24340]
return_stmt [24710,24725]
===
match
---
operator: = [10909,10910]
operator: = [11294,11295]
===
match
---
name: task_id [16732,16739]
name: task_id [17117,17124]
===
match
---
name: dag [33464,33467]
name: dag [33849,33852]
===
match
---
atom_expr [25066,25135]
atom_expr [25451,25520]
===
match
---
trailer [13577,13584]
trailer [13962,13969]
===
match
---
operator: , [19890,19891]
operator: , [20275,20276]
===
match
---
atom_expr [11814,11826]
atom_expr [12199,12211]
===
match
---
simple_stmt [32930,32978]
simple_stmt [33315,33363]
===
match
---
comparison [11290,11305]
comparison [11675,11690]
===
match
---
name: actual_found_dags [14285,14302]
name: actual_found_dags [14670,14687]
===
match
---
atom_expr [25156,25225]
atom_expr [25541,25610]
===
match
---
trailer [38165,38238]
trailer [38550,38623]
===
match
---
trailer [24023,24089]
trailer [24408,24474]
===
match
---
expr_stmt [3072,3115]
expr_stmt [3072,3115]
===
match
---
name: assert_queries_count [1750,1770]
name: assert_queries_count [1750,1770]
===
match
---
name: permissions [1839,1850]
name: permissions [1839,1850]
===
match
---
decorator [28954,29006]
decorator [29339,29391]
===
match
---
atom_expr [3131,3166]
atom_expr [3131,3166]
===
match
---
atom_expr [34788,34833]
atom_expr [35173,35218]
===
match
---
trailer [28811,28825]
trailer [29196,29210]
===
match
---
simple_stmt [12751,12801]
simple_stmt [13136,13186]
===
match
---
operator: = [38231,38232]
operator: = [38616,38617]
===
match
---
atom_expr [19696,19765]
atom_expr [20081,20150]
===
match
---
simple_stmt [21378,21401]
simple_stmt [21763,21786]
===
match
---
with_stmt [27432,28020]
with_stmt [27817,28405]
===
match
---
name: subdag_0 [24914,24922]
name: subdag_0 [25299,25307]
===
match
---
operator: , [13692,13693]
operator: , [14077,14078]
===
match
---
name: DummyOperator [24129,24142]
name: DummyOperator [24514,24527]
===
match
---
operator: = [16433,16434]
operator: = [16818,16819]
===
match
---
argument [23663,23675]
argument [24048,24060]
===
match
---
simple_stmt [4853,4922]
simple_stmt [5238,5307]
===
match
---
simple_stmt [29246,29311]
simple_stmt [29631,29696]
===
match
---
argument [30075,30091]
argument [30460,30476]
===
match
---
atom_expr [13271,13295]
atom_expr [13656,13680]
===
match
---
simple_stmt [25246,25262]
simple_stmt [25631,25647]
===
match
---
atom_expr [14004,14025]
atom_expr [14389,14410]
===
match
---
name: super [11052,11057]
name: super [11437,11442]
===
match
---
suite [36385,36559]
suite [36770,36944]
===
match
---
string: "test_example_bash_operator" [31646,31674]
string: "test_example_bash_operator" [32031,32059]
===
match
---
name: airflow [12756,12763]
name: airflow [13141,13148]
===
match
---
decorator [37401,37473]
decorator [37786,37858]
===
match
---
name: path [28797,28801]
name: path [29182,29186]
===
match
---
trailer [2826,2828]
trailer [2826,2828]
===
match
---
atom_expr [1977,1986]
atom_expr [1977,1986]
===
match
---
atom_expr [13494,13504]
atom_expr [13879,13889]
===
match
---
simple_stmt [8158,8217]
simple_stmt [8543,8602]
===
match
---
name: utc [11823,11826]
name: utc [12208,12211]
===
match
---
number: 1 [35087,35088]
number: 1 [35472,35473]
===
match
---
name: dag_id [36467,36473]
name: dag_id [36852,36858]
===
match
---
assert_stmt [27576,27609]
assert_stmt [27961,27994]
===
match
---
suite [13706,14235]
suite [14091,14620]
===
match
---
name: sys [7608,7611]
name: sys [7993,7996]
===
match
---
arglist [30065,30091]
arglist [30450,30476]
===
match
---
name: subdag_c [19016,19024]
name: subdag_c [19401,19409]
===
match
---
name: ANY [29562,29565]
name: ANY [29947,29950]
===
match
---
name: test_get_dag_with_dag_serialization [33855,33890]
name: test_get_dag_with_dag_serialization [34240,34275]
===
match
---
param [11472,11485]
param [11857,11870]
===
match
---
operator: , [21523,21524]
operator: , [21908,21909]
===
match
---
operator: } [4002,4003]
operator: } [4387,4388]
===
match
---
atom_expr [14779,14981]
atom_expr [15164,15366]
===
match
---
name: default_args [16365,16377]
name: default_args [16750,16762]
===
match
---
atom_expr [20733,20765]
atom_expr [21118,21150]
===
match
---
number: 1 [3922,3923]
number: 1 [4307,4308]
===
match
---
name: f [3649,3650]
name: f [4034,4035]
===
match
---
name: exc [1129,1132]
name: exc [1129,1132]
===
match
---
trailer [2119,2133]
trailer [2119,2133]
===
match
---
operator: = [29387,29388]
operator: = [29772,29773]
===
match
---
expr_stmt [6885,6947]
expr_stmt [7270,7332]
===
match
---
simple_stmt [2117,2136]
simple_stmt [2117,2136]
===
match
---
name: datetime [12956,12964]
name: datetime [13341,13349]
===
match
---
name: DagModel [26918,26926]
name: DagModel [27303,27311]
===
match
---
arglist [9017,9053]
arglist [9402,9438]
===
match
---
atom_expr [34337,34367]
atom_expr [34722,34752]
===
match
---
name: expected [10104,10112]
name: expected [10489,10497]
===
match
---
parameters [24370,24372]
parameters [24755,24757]
===
match
---
operator: , [26280,26281]
operator: , [26665,26666]
===
match
---
arglist [30120,30146]
arglist [30505,30531]
===
match
---
trailer [2791,2798]
trailer [2791,2798]
===
match
---
simple_stmt [1186,1223]
simple_stmt [1186,1223]
===
match
---
expr_stmt [31163,31325]
expr_stmt [31548,31710]
===
match
---
name: op_subdag_1 [16614,16625]
name: op_subdag_1 [16999,17010]
===
match
---
name: task_id [23638,23645]
name: task_id [24023,24030]
===
match
---
name: return_value [32627,32639]
name: return_value [33012,33024]
===
match
---
name: dag_id [26940,26946]
name: dag_id [27325,27331]
===
match
---
name: model_before [26692,26704]
name: model_before [27077,27089]
===
match
---
argument [18920,18943]
argument [19305,19328]
===
match
---
comparison [12056,12075]
comparison [12441,12460]
===
match
---
comparison [15001,15080]
comparison [15386,15465]
===
match
---
string: 'assumed to contain no DAGs. Skipping.' [7152,7191]
string: 'assumed to contain no DAGs. Skipping.' [7537,7576]
===
match
---
name: tests [1686,1691]
name: tests [1686,1691]
===
match
---
decorator [1914,1927]
decorator [1914,1927]
===
match
---
decorator [29083,29133]
decorator [29468,29518]
===
match
---
name: default_args [19109,19121]
name: default_args [19494,19506]
===
match
---
atom_expr [3777,3791]
atom_expr [4162,4176]
===
match
---
trailer [13255,13260]
trailer [13640,13645]
===
match
---
name: self [2869,2873]
name: self [2869,2873]
===
match
---
simple_stmt [943,992]
simple_stmt [943,992]
===
match
---
dotted_name [15470,15493]
dotted_name [15855,15878]
===
match
---
name: dag [16670,16673]
name: dag [17055,17058]
===
match
---
atom_expr [30700,30708]
atom_expr [31085,31093]
===
match
---
operator: , [25852,25853]
operator: , [26237,26238]
===
match
---
name: subdag_0 [16102,16110]
name: subdag_0 [16487,16495]
===
match
---
arglist [22558,22568]
arglist [22943,22953]
===
match
---
operator: = [29366,29367]
operator: = [29751,29752]
===
match
---
name: dagbag [37743,37749]
name: dagbag [38128,38134]
===
match
---
import_name [1158,1185]
import_name [1158,1185]
===
match
---
name: tests [1718,1723]
name: tests [1718,1723]
===
match
---
comparison [12446,12466]
comparison [12831,12851]
===
match
---
name: session [30130,30137]
name: session [30515,30522]
===
match
---
operator: = [13343,13344]
operator: = [13728,13729]
===
match
---
name: op_subdag_1 [16830,16841]
name: op_subdag_1 [17215,17226]
===
match
---
atom [29982,30162]
atom [30367,30547]
===
match
---
name: line [5852,5856]
name: line [6237,6241]
===
match
---
name: filepath [10884,10892]
name: filepath [11269,11277]
===
match
---
with_item [3578,3635]
with_item [3963,4020]
===
match
---
atom [5327,5329]
atom [5712,5714]
===
match
---
name: subdag_0 [16229,16237]
name: subdag_0 [16614,16622]
===
match
---
operator: == [14759,14761]
operator: == [15144,15146]
===
match
---
parameters [31471,31473]
parameters [31856,31858]
===
match
---
operator: = [15748,15749]
operator: = [16133,16134]
===
match
---
simple_stmt [1817,1890]
simple_stmt [1817,1890]
===
match
---
operator: = [27764,27765]
operator: = [28149,28150]
===
match
---
name: default_args [18859,18871]
name: default_args [19244,19256]
===
match
---
argument [19333,19358]
argument [19718,19743]
===
match
---
name: dag [25193,25196]
name: dag [25578,25581]
===
match
---
trailer [6294,6297]
trailer [6679,6682]
===
match
---
assert_stmt [26315,26353]
assert_stmt [26700,26738]
===
match
---
atom_expr [23624,23676]
atom_expr [24009,24061]
===
match
---
assert_stmt [38247,38278]
assert_stmt [38632,38663]
===
match
---
trailer [20860,20874]
trailer [21245,21259]
===
match
---
operator: , [27696,27697]
operator: , [28081,28082]
===
match
---
funcdef [28098,28949]
funcdef [28483,29334]
===
match
---
atom_expr [3713,3722]
atom_expr [4098,4107]
===
match
---
operator: , [36601,36602]
operator: , [36986,36987]
===
match
---
name: session [31766,31773]
name: session [32151,32158]
===
match
---
comparison [3381,3399]
comparison [3766,3784]
===
match
---
number: 0 [34656,34657]
number: 0 [35041,35042]
===
match
---
atom_expr [12097,12127]
atom_expr [12482,12512]
===
match
---
name: sqlalchemy [1090,1100]
name: sqlalchemy [1090,1100]
===
match
---
name: include_examples [27748,27764]
name: include_examples [28133,28149]
===
match
---
trailer [14647,14652]
trailer [15032,15037]
===
match
---
name: INFO [6871,6875]
name: INFO [7256,7260]
===
match
---
trailer [31398,31417]
trailer [31783,31802]
===
match
---
name: dagbag [14062,14068]
name: dagbag [14447,14453]
===
match
---
simple_stmt [26801,26829]
simple_stmt [27186,27214]
===
match
---
operator: = [12255,12256]
operator: = [12640,12641]
===
match
---
name: DummyOperator [25479,25492]
name: DummyOperator [25864,25877]
===
match
---
operator: , [28528,28529]
operator: , [28913,28914]
===
match
---
dotted_name [1546,1566]
dotted_name [1546,1566]
===
match
---
suite [19501,19802]
suite [19886,20187]
===
match
---
trailer [13247,13255]
trailer [13632,13640]
===
match
---
atom_expr [38258,38272]
atom_expr [38643,38657]
===
match
---
operator: , [12892,12893]
operator: , [13277,13278]
===
match
---
name: dag [25331,25334]
name: dag [25716,25719]
===
match
---
simple_stmt [11836,11881]
simple_stmt [12221,12266]
===
match
---
trailer [16546,16597]
trailer [16931,16982]
===
match
---
name: default_args [18872,18884]
name: default_args [19257,19269]
===
match
---
atom_expr [15673,15702]
atom_expr [16058,16087]
===
match
---
comparison [37918,37944]
comparison [38303,38329]
===
match
---
atom_expr [35593,35643]
atom_expr [35978,36028]
===
match
---
name: dagbag [31163,31169]
name: dagbag [31548,31554]
===
match
---
name: expected_dag_ids [14440,14456]
name: expected_dag_ids [14825,14841]
===
match
---
argument [16643,16664]
argument [17028,17049]
===
match
---
atom_expr [9116,9141]
atom_expr [9501,9526]
===
match
---
assert_stmt [4410,4446]
assert_stmt [4795,4831]
===
match
---
suite [24955,25262]
suite [25340,25647]
===
match
---
argument [24742,24762]
argument [25127,25147]
===
match
---
name: sync_perm_for_dag [32724,32741]
name: sync_perm_for_dag [33109,33126]
===
match
---
expr_stmt [21721,21745]
expr_stmt [22106,22130]
===
match
---
dotted_name [1118,1132]
dotted_name [1118,1132]
===
match
---
string: """         test that dag successfully imported without import errors when tasks         obey cluster policy.         """ [37528,37649]
string: """         test that dag successfully imported without import errors when tasks         obey cluster policy.         """ [37913,38034]
===
match
---
funcdef [38021,38342]
funcdef [38406,38727]
===
match
---
with_stmt [5092,5361]
with_stmt [5477,5746]
===
match
---
assert_stmt [2808,2833]
assert_stmt [2808,2833]
===
match
---
operator: , [21487,21488]
operator: , [21872,21873]
===
match
---
with_stmt [28350,28949]
with_stmt [28735,29334]
===
match
---
atom_expr [7045,7062]
atom_expr [7430,7447]
===
match
---
name: textwrap [13865,13873]
name: textwrap [14250,14258]
===
match
---
name: endswith [10194,10202]
name: endswith [10579,10587]
===
match
---
trailer [33103,33125]
trailer [33488,33510]
===
match
---
expr_stmt [35955,35991]
expr_stmt [36340,36376]
===
match
---
operator: , [38185,38186]
operator: , [38570,38571]
===
match
---
name: found_dags [21918,21928]
name: found_dags [22303,22313]
===
match
---
assert_stmt [13522,13558]
assert_stmt [13907,13943]
===
match
---
simple_stmt [1681,1713]
simple_stmt [1681,1713]
===
match
---
name: models [22296,22302]
name: models [22681,22687]
===
match
---
operator: = [37824,37825]
operator: = [38209,38210]
===
match
---
name: process_file_calls [11219,11237]
name: process_file_calls [11604,11622]
===
match
---
name: file_path [26074,26083]
name: file_path [26459,26468]
===
match
---
name: sys [846,849]
name: sys [846,849]
===
match
---
name: TEST_DAGS_FOLDER [12273,12289]
name: TEST_DAGS_FOLDER [12658,12674]
===
match
---
operator: , [4619,4620]
operator: , [5004,5005]
===
match
---
comparison [2778,2798]
comparison [2778,2798]
===
match
---
trailer [21681,21687]
trailer [22066,22072]
===
match
---
name: dag [34289,34292]
name: dag [34674,34677]
===
match
---
trailer [27545,27552]
trailer [27930,27937]
===
match
---
name: DagBag [5250,5256]
name: DagBag [5635,5641]
===
match
---
name: dagbag [20897,20903]
name: dagbag [21282,21288]
===
match
---
expr_stmt [9715,10074]
expr_stmt [10100,10459]
===
match
---
number: 0 [8760,8761]
number: 0 [9145,9146]
===
match
---
operator: = [26722,26723]
operator: = [27107,27108]
===
match
---
trailer [37892,37900]
trailer [38277,38285]
===
match
---
name: models [5243,5249]
name: models [5628,5634]
===
match
---
arglist [30769,30839]
arglist [31154,31224]
===
match
---
name: dagbag [31392,31398]
name: dagbag [31777,31783]
===
match
---
name: dag [17660,17663]
name: dag [18045,18048]
===
match
---
name: DummyOperator [20352,20365]
name: DummyOperator [20737,20750]
===
match
---
name: filter [27125,27131]
name: filter [27510,27516]
===
match
---
operator: , [5282,5283]
operator: , [5667,5668]
===
match
---
funcdef [14240,15287]
funcdef [14625,15672]
===
match
---
atom_expr [8112,8148]
atom_expr [8497,8533]
===
match
---
atom_expr [25571,25603]
atom_expr [25956,25988]
===
match
---
operator: = [13031,13032]
operator: = [13416,13417]
===
match
---
operator: = [25123,25124]
operator: = [25508,25509]
===
match
---
operator: , [12973,12974]
operator: , [13358,13359]
===
match
---
name: frozen_time [31138,31149]
name: frozen_time [31523,31534]
===
match
---
trailer [21743,21745]
trailer [22128,22130]
===
match
---
trailer [26675,26680]
trailer [27060,27065]
===
match
---
operator: = [34361,34362]
operator: = [34746,34747]
===
match
---
suite [31474,31615]
suite [31859,32000]
===
match
---
argument [24778,24795]
argument [25163,25180]
===
match
---
trailer [10510,10519]
trailer [10895,10904]
===
match
---
trailer [10629,10631]
trailer [11014,11016]
===
match
---
operator: , [17642,17643]
operator: , [18027,18028]
===
match
---
name: caplog [7195,7201]
name: caplog [7580,7586]
===
match
---
name: dagbag [13650,13656]
name: dagbag [14035,14041]
===
match
---
simple_stmt [15527,15579]
simple_stmt [15912,15964]
===
match
---
operator: , [7003,7004]
operator: , [7388,7389]
===
match
---
comparison [8232,8253]
comparison [8617,8638]
===
match
---
operator: , [12018,12019]
operator: , [12403,12404]
===
match
---
name: fileloc [10186,10193]
name: fileloc [10571,10578]
===
match
---
arglist [37682,37732]
arglist [38067,38117]
===
match
---
assert_stmt [20959,20989]
assert_stmt [21344,21374]
===
match
---
trailer [30087,30091]
trailer [30472,30476]
===
match
---
operator: = [5909,5910]
operator: = [6294,6295]
===
match
---
comparison [12482,12512]
comparison [12867,12897]
===
match
---
name: len [38254,38257]
name: len [38639,38642]
===
match
---
expr_stmt [5234,5307]
expr_stmt [5619,5692]
===
match
---
argument [35197,35220]
argument [35582,35605]
===
match
---
fstring [4891,4921]
fstring [5276,5306]
===
match
---
param [12568,12573]
param [12953,12958]
===
match
---
trailer [13380,13387]
trailer [13765,13772]
===
match
---
argument [32880,32902]
argument [33265,33287]
===
match
---
name: dagbag [13592,13598]
name: dagbag [13977,13983]
===
match
---
trailer [10417,10430]
trailer [10802,10815]
===
match
---
name: models [17379,17385]
name: models [17764,17770]
===
match
---
trailer [13233,13261]
trailer [13618,13646]
===
match
---
number: 1 [9243,9244]
number: 1 [9628,9629]
===
match
---
operator: , [2525,2526]
operator: , [2525,2526]
===
match
---
name: self [7709,7713]
name: self [8094,8098]
===
match
---
operator: = [23532,23533]
operator: = [23917,23918]
===
match
---
name: subdag_a [23491,23499]
name: subdag_a [23876,23884]
===
match
---
atom_expr [4417,4441]
atom_expr [4802,4826]
===
match
---
name: SubDagOperator [20262,20276]
name: SubDagOperator [20647,20661]
===
match
---
argument [15736,15761]
argument [16121,16146]
===
match
---
trailer [33084,33103]
trailer [33469,33488]
===
match
---
trailer [29394,29398]
trailer [29779,29783]
===
match
---
operator: = [29658,29659]
operator: = [30043,30044]
===
match
---
atom_expr [5136,5162]
atom_expr [5521,5547]
===
match
---
comparison [11321,11341]
comparison [11706,11726]
===
match
---
simple_stmt [34327,34368]
simple_stmt [34712,34753]
===
match
---
simple_stmt [27478,27564]
simple_stmt [27863,27949]
===
match
---
atom_expr [24255,24304]
atom_expr [24640,24689]
===
match
---
operator: , [11470,11471]
operator: , [11855,11856]
===
match
---
operator: = [38080,38081]
operator: = [38465,38466]
===
match
---
name: os [31207,31209]
name: os [31592,31594]
===
match
---
trailer [34915,34940]
trailer [35300,35325]
===
match
---
assert_stmt [21834,21867]
assert_stmt [22219,22252]
===
match
---
operator: == [12334,12336]
operator: == [12719,12721]
===
match
---
string: 'opSubdag_D' [20052,20064]
string: 'opSubdag_D' [20437,20449]
===
match
---
name: dag [21591,21594]
name: dag [21976,21979]
===
match
---
trailer [14229,14234]
trailer [14614,14619]
===
match
---
simple_stmt [8944,8980]
simple_stmt [9329,9365]
===
match
---
name: DagBag [29329,29335]
name: DagBag [29714,29720]
===
match
---
comparison [11207,11237]
comparison [11592,11622]
===
match
---
atom [9726,10074]
atom [10111,10459]
===
match
---
name: DAG [26845,26848]
name: DAG [27230,27233]
===
match
---
name: writelines [6117,6127]
name: writelines [6502,6512]
===
match
---
atom_expr [11696,11722]
atom_expr [12081,12107]
===
match
---
name: _sync_perms [32995,33006]
name: _sync_perms [33380,33391]
===
match
---
name: empty_dir [3606,3615]
name: empty_dir [3991,4000]
===
match
---
argument [24063,24088]
argument [24448,24473]
===
match
---
name: reset_mock [33049,33059]
name: reset_mock [33434,33444]
===
match
---
simple_stmt [4995,5084]
simple_stmt [5380,5469]
===
match
---
name: name [14183,14187]
name: name [14568,14572]
===
match
---
name: op_a [25522,25526]
name: op_a [25907,25911]
===
match
---
decorator [1992,2005]
decorator [1992,2005]
===
match
---
name: mock [30660,30664]
name: mock [31045,31049]
===
match
---
name: DagBag [28489,28495]
name: DagBag [28874,28880]
===
match
---
trailer [28937,28946]
trailer [29322,29331]
===
match
---
operator: == [6278,6280]
operator: == [6663,6665]
===
match
---
operator: -> [2232,2234]
operator: -> [2232,2234]
===
match
---
parameters [4479,4485]
parameters [4864,4870]
===
match
---
funcdef [7667,8254]
funcdef [8052,8639]
===
match
---
atom_expr [16810,16842]
atom_expr [17195,17227]
===
match
---
name: process_file [9004,9016]
name: process_file [9389,9401]
===
match
---
name: object [11400,11406]
name: object [11785,11791]
===
match
---
atom_expr [29525,29533]
atom_expr [29910,29918]
===
match
---
operator: , [3615,3616]
operator: , [4000,4001]
===
match
---
simple_stmt [32755,32918]
simple_stmt [33140,33303]
===
match
---
arglist [34127,34146]
arglist [34512,34531]
===
match
---
string: """         test that we're able to parse file that contains multi-byte char         """ [4995,5083]
string: """         test that we're able to parse file that contains multi-byte char         """ [5380,5468]
===
match
---
argument [10703,10722]
argument [11088,11107]
===
match
---
simple_stmt [38247,38279]
simple_stmt [38632,38664]
===
match
---
simple_stmt [815,825]
simple_stmt [815,825]
===
match
---
operator: == [36320,36322]
operator: == [36705,36707]
===
match
---
name: self [33891,33895]
name: self [34276,34280]
===
match
---
parameters [32165,32194]
parameters [32550,32579]
===
match
---
operator: , [19731,19732]
operator: , [20116,20117]
===
match
---
name: self [26266,26270]
name: self [26651,26655]
===
match
---
import_from [21272,21302]
import_from [21657,21687]
===
match
---
suite [12997,13042]
suite [13382,13427]
===
match
---
name: dag [13494,13497]
name: dag [13879,13882]
===
match
---
operator: , [10063,10064]
operator: , [10448,10449]
===
match
---
name: getsource [5868,5877]
name: getsource [6253,6262]
===
match
---
fstring_start: f' [7092,7094]
fstring_start: f' [7477,7479]
===
match
---
operator: = [4342,4343]
operator: = [4727,4728]
===
match
---
parameters [37512,37518]
parameters [37897,37903]
===
match
---
trailer [16342,16391]
trailer [16727,16776]
===
match
---
atom_expr [12456,12466]
atom_expr [12841,12851]
===
match
---
trailer [6116,6127]
trailer [6501,6512]
===
match
---
simple_stmt [31392,31443]
simple_stmt [31777,31828]
===
match
---
name: test_zip_path [6990,7003]
name: test_zip_path [7375,7388]
===
match
---
trailer [27515,27554]
trailer [27900,27939]
===
match
---
expr_stmt [2694,2722]
expr_stmt [2694,2722]
===
match
---
name: f [4912,4913]
name: f [5297,5298]
===
match
---
operator: = [26298,26299]
operator: = [26683,26684]
===
match
---
name: safe_mode [8830,8839]
name: safe_mode [9215,9224]
===
match
---
name: timedelta [923,932]
name: timedelta [923,932]
===
match
---
trailer [29454,29466]
trailer [29839,29851]
===
match
---
trailer [2278,2292]
trailer [2278,2292]
===
match
---
name: subdag_b [23947,23955]
name: subdag_b [24332,24340]
===
match
---
simple_stmt [1113,1157]
simple_stmt [1113,1157]
===
match
---
import_from [15527,15578]
import_from [15912,15963]
===
match
---
trailer [9660,9665]
trailer [10045,10050]
===
match
---
comparison [38254,38278]
comparison [38639,38663]
===
match
---
name: default_args [21413,21425]
name: default_args [21798,21810]
===
match
---
operator: = [3850,3851]
operator: = [4235,4236]
===
match
---
name: mock_sync_perm_for_dag [33356,33378]
name: mock_sync_perm_for_dag [33741,33763]
===
match
---
operator: { [33485,33486]
operator: { [33870,33871]
===
match
---
operator: = [18820,18821]
operator: = [19205,19206]
===
match
---
string: "example2" [35703,35713]
string: "example2" [36088,36098]
===
match
---
simple_stmt [11929,11952]
simple_stmt [12314,12337]
===
match
---
name: db [2171,2173]
name: db [2171,2173]
===
match
---
trailer [10745,10758]
trailer [11130,11143]
===
match
---
name: subdag_1 [20126,20134]
name: subdag_1 [20511,20519]
===
match
---
trailer [2305,2330]
trailer [2305,2330]
===
match
---
operator: @ [28025,28026]
operator: @ [28410,28411]
===
match
---
simple_stmt [22056,22128]
simple_stmt [22441,22513]
===
match
---
atom [33642,33666]
atom [34027,34051]
===
match
---
atom_expr [36138,36168]
atom_expr [36523,36553]
===
match
---
name: mock_sync_perm_for_dag [32000,32022]
name: mock_sync_perm_for_dag [32385,32407]
===
match
---
name: DagBag [7413,7419]
name: DagBag [7798,7804]
===
match
---
name: subdag_d [20087,20095]
name: subdag_d [20472,20480]
===
match
---
name: process_file_calls [11929,11947]
name: process_file_calls [12314,12332]
===
match
---
number: 2020 [35403,35407]
number: 2020 [35788,35792]
===
match
---
atom_expr [25479,25505]
atom_expr [25864,25890]
===
match
---
trailer [3027,3037]
trailer [3027,3037]
===
match
---
operator: = [7463,7464]
operator: = [7848,7849]
===
match
---
name: dags [34214,34218]
name: dags [34599,34603]
===
match
---
name: airflow [17414,17421]
name: airflow [17799,17806]
===
match
---
name: ANY [30033,30036]
name: ANY [30418,30421]
===
match
---
name: len [8232,8235]
name: len [8617,8620]
===
match
---
simple_stmt [32510,32568]
simple_stmt [32895,32953]
===
match
---
operator: == [38274,38276]
operator: == [38659,38661]
===
match
---
trailer [16765,16780]
trailer [17150,17165]
===
match
---
atom_expr [5097,5117]
atom_expr [5482,5502]
===
match
---
operator: = [29770,29771]
operator: = [30155,30156]
===
match
---
atom_expr [28355,28371]
atom_expr [28740,28756]
===
match
---
trailer [33059,33061]
trailer [33444,33446]
===
match
---
name: read_dags_from_db [36145,36162]
name: read_dags_from_db [36530,36547]
===
match
---
trailer [36619,36634]
trailer [37004,37019]
===
match
---
operator: = [19057,19058]
operator: = [19442,19443]
===
match
---
atom_expr [14630,14676]
atom_expr [15015,15061]
===
match
---
atom_expr [14228,14234]
atom_expr [14613,14619]
===
match
---
fstring_string: / [3976,3977]
fstring_string: / [4361,4362]
===
match
---
operator: , [16449,16450]
operator: , [16834,16835]
===
match
---
atom_expr [14545,14555]
atom_expr [14930,14940]
===
match
---
trailer [16780,16793]
trailer [17165,17178]
===
match
---
arglist [10228,10251]
arglist [10613,10636]
===
match
---
name: DagBag [8718,8724]
name: DagBag [9103,9109]
===
match
---
atom_expr [30065,30073]
atom_expr [30450,30458]
===
match
---
arglist [19537,19584]
arglist [19922,19969]
===
match
---
trailer [37671,37676]
trailer [38056,38061]
===
match
---
simple_stmt [20702,20766]
simple_stmt [21087,21151]
===
match
---
operator: = [29822,29823]
operator: = [30207,30208]
===
match
---
trailer [31942,31947]
trailer [32327,32332]
===
match
---
name: dag [24168,24171]
name: dag [24553,24556]
===
match
---
operator: } [14673,14674]
operator: } [15058,15059]
===
match
---
name: file_path [22143,22152]
name: file_path [22528,22537]
===
match
---
name: actual_dagbag [14304,14317]
name: actual_dagbag [14689,14702]
===
match
---
operator: } [35724,35725]
operator: } [36109,36110]
===
match
---
name: mock_bulk_write_to_db [29174,29195]
name: mock_bulk_write_to_db [29559,29580]
===
match
---
simple_stmt [19606,19676]
simple_stmt [19991,20061]
===
match
---
import_as_names [1300,1316]
import_as_names [1300,1316]
===
match
---
fstring_start: f" [4891,4893]
fstring_start: f" [5276,5278]
===
match
---
name: subdag_0 [16266,16274]
name: subdag_0 [16651,16659]
===
match
---
param [2364,2368]
param [2364,2368]
===
match
---
name: dag_folder [13100,13110]
name: dag_folder [13485,13495]
===
match
---
fstring_string: File  [7094,7099]
fstring_string: File  [7479,7484]
===
match
---
trailer [8119,8124]
trailer [8504,8509]
===
match
---
expr_stmt [32930,32977]
expr_stmt [33315,33362]
===
match
---
name: dag_id [36424,36430]
name: dag_id [36809,36815]
===
match
---
arglist [32047,32067]
arglist [32432,32452]
===
match
---
name: airflow [17476,17483]
name: airflow [17861,17868]
===
match
---
operator: , [12290,12291]
operator: , [12675,12676]
===
match
---
name: airflow [15427,15434]
name: airflow [15812,15819]
===
match
---
dotted_name [17476,17500]
dotted_name [17861,17885]
===
match
---
number: 1 [15697,15698]
number: 1 [16082,16083]
===
match
---
simple_stmt [32670,32742]
simple_stmt [33055,33127]
===
match
---
atom_expr [10640,10679]
atom_expr [11025,11064]
===
match
---
name: TEST_DAGS_FOLDER [11640,11656]
name: TEST_DAGS_FOLDER [12025,12041]
===
match
---
name: subdag_c [24172,24180]
name: subdag_c [24557,24565]
===
match
---
operator: = [16739,16740]
operator: = [17124,17125]
===
match
---
operator: , [8281,8282]
operator: , [8666,8667]
===
match
---
name: dagbag [28603,28609]
name: dagbag [28988,28994]
===
match
---
name: len [4417,4420]
name: len [4802,4805]
===
match
---
operator: , [30678,30679]
operator: , [31063,31064]
===
match
---
trailer [8882,8892]
trailer [9267,9277]
===
match
---
simple_stmt [33330,33344]
simple_stmt [33715,33729]
===
match
---
name: found_dags [26016,26026]
name: found_dags [26401,26411]
===
match
---
classdef [8693,9055]
classdef [9078,9440]
===
match
---
return_stmt [12149,12214]
return_stmt [12534,12599]
===
match
---
string: "Ignoring DAG" [6555,6569]
string: "Ignoring DAG" [6940,6954]
===
match
---
argument [5901,5914]
argument [6286,6299]
===
match
---
name: dir [4601,4604]
name: dir [4986,4989]
===
match
---
name: new_dagbag [36218,36228]
name: new_dagbag [36603,36613]
===
match
---
simple_stmt [5421,5517]
simple_stmt [5806,5902]
===
match
---
operator: } [5722,5723]
operator: } [6107,6108]
===
match
---
name: write_dag [35187,35196]
name: write_dag [35572,35581]
===
match
---
assert_stmt [35653,35725]
assert_stmt [36038,36110]
===
match
---
argument [20181,20202]
argument [20566,20587]
===
match
---
operator: , [4380,4381]
operator: , [4765,4766]
===
match
---
name: mock_sync_perm_for_dag [33200,33222]
name: mock_sync_perm_for_dag [33585,33607]
===
match
---
operator: = [11575,11576]
operator: = [11960,11961]
===
match
---
name: realpath [11618,11626]
name: realpath [12003,12011]
===
match
---
name: operators [15478,15487]
name: operators [15863,15872]
===
match
---
simple_stmt [7038,7063]
simple_stmt [7423,7448]
===
match
---
name: write [3685,3690]
name: write [4070,4075]
===
match
---
trailer [10439,10442]
trailer [10824,10827]
===
match
---
name: include_examples [31288,31304]
name: include_examples [31673,31689]
===
match
---
operator: , [11081,11082]
operator: , [11466,11467]
===
match
---
trailer [9579,9629]
trailer [9964,10014]
===
match
---
expr_stmt [31338,31379]
expr_stmt [31723,31764]
===
match
---
sync_comp_for [5848,5919]
sync_comp_for [6233,6304]
===
match
---
atom_expr [36218,36251]
atom_expr [36603,36636]
===
match
---
name: return_value [8655,8667]
name: return_value [9040,9052]
===
match
---
arglist [24652,24705]
arglist [25037,25090]
===
match
---
string: """         Test that when dagbag.sync_to_db is called the DAGs are Serialized and written to DB         even when dagbag.read_dags_from_db is False         """ [27263,27423]
string: """         Test that when dagbag.sync_to_db is called the DAGs are Serialized and written to DB         even when dagbag.read_dags_from_db is False         """ [27648,27808]
===
match
---
atom_expr [27842,27866]
atom_expr [28227,28251]
===
match
---
operator: , [22524,22525]
operator: , [22909,22910]
===
match
---
simple_stmt [33078,33126]
simple_stmt [33463,33511]
===
match
---
name: dag_folder [7420,7430]
name: dag_folder [7805,7815]
===
match
---
string: "test_with_non_default_owner.py" [37700,37732]
string: "test_with_non_default_owner.py" [38085,38117]
===
match
---
parameters [21019,21025]
parameters [21404,21410]
===
match
---
name: dag [23906,23909]
name: dag [24291,24294]
===
match
---
operator: = [26705,26706]
operator: = [27090,27091]
===
match
---
trailer [11266,11274]
trailer [11651,11659]
===
match
---
trailer [14010,14017]
trailer [14395,14402]
===
match
---
simple_stmt [6505,6571]
simple_stmt [6890,6956]
===
match
---
name: DummyOperator [24495,24508]
name: DummyOperator [24880,24893]
===
match
---
trailer [30664,30669]
trailer [31049,31054]
===
match
---
operator: , [37778,37779]
operator: , [38163,38164]
===
match
---
name: include_examples [4358,4374]
name: include_examples [4743,4759]
===
match
---
name: MagicMock [31368,31377]
name: MagicMock [31753,31762]
===
match
---
name: default_args [18635,18647]
name: default_args [19020,19032]
===
match
---
name: tf_2 [6052,6056]
name: tf_2 [6437,6441]
===
match
---
atom_expr [26801,26828]
atom_expr [27186,27213]
===
match
---
name: DagBag [6972,6978]
name: DagBag [7357,7363]
===
match
---
simple_stmt [30915,31039]
simple_stmt [31300,31424]
===
match
---
trailer [3656,3670]
trailer [4041,4055]
===
match
---
trailer [31597,31614]
trailer [31982,31999]
===
match
---
atom_expr [27667,27730]
atom_expr [28052,28115]
===
match
---
string: 'opSubdag_A' [19629,19641]
string: 'opSubdag_A' [20014,20026]
===
match
---
param [37513,37517]
param [37898,37902]
===
match
---
name: operators [22339,22348]
name: operators [22724,22733]
===
match
---
operator: = [23775,23776]
operator: = [24160,24161]
===
match
---
trailer [11862,11870]
trailer [12247,12255]
===
match
---
suite [10812,11111]
suite [11197,11496]
===
match
---
name: clear_db_dags [2120,2133]
name: clear_db_dags [2120,2133]
===
match
---
simple_stmt [2989,3063]
simple_stmt [2989,3063]
===
match
---
import_name [15393,15408]
import_name [15778,15793]
===
match
---
comparison [12332,12362]
comparison [12717,12747]
===
match
---
name: tf_2 [6445,6449]
name: tf_2 [6830,6834]
===
match
---
name: include_examples [3039,3055]
name: include_examples [3039,3055]
===
match
---
operator: = [2484,2485]
operator: = [2484,2485]
===
match
---
atom_expr [36511,36535]
atom_expr [36896,36920]
===
match
---
name: settings [31057,31065]
name: settings [31442,31450]
===
match
---
return_stmt [11045,11110]
return_stmt [11430,11495]
===
match
---
trailer [4897,4902]
trailer [5282,5287]
===
match
---
operator: , [24852,24853]
operator: , [25237,25238]
===
match
---
name: session [28375,28382]
name: session [28760,28767]
===
match
---
name: example_bash_op_dag [35116,35135]
name: example_bash_op_dag [35501,35520]
===
match
---
with_stmt [35374,35644]
with_stmt [35759,36029]
===
match
---
simple_stmt [24817,24887]
simple_stmt [25202,25272]
===
match
---
operator: , [14317,14318]
operator: , [14702,14703]
===
match
---
operator: { [33642,33643]
operator: { [34027,34028]
===
match
---
simple_stmt [7353,7389]
simple_stmt [7738,7774]
===
match
---
name: log [14644,14647]
name: log [15029,15032]
===
match
---
name: security [1558,1566]
name: security [1558,1566]
===
match
---
atom_expr [6070,6099]
atom_expr [6455,6484]
===
match
---
parameters [11981,12035]
parameters [12366,12420]
===
match
---
parameters [28146,28176]
parameters [28531,28561]
===
match
---
name: dagbag [11120,11126]
name: dagbag [11505,11511]
===
match
---
string: 'parent.op_subdag_0' [16117,16137]
string: 'parent.op_subdag_0' [16502,16522]
===
match
---
trailer [5218,5220]
trailer [5603,5605]
===
match
---
operator: = [24403,24404]
operator: = [24788,24789]
===
match
---
name: subdag_a [23523,23531]
name: subdag_a [23908,23916]
===
match
---
parameters [19498,19500]
parameters [19883,19885]
===
match
---
name: os [32799,32801]
name: os [33184,33186]
===
match
---
arglist [6017,6038]
arglist [6402,6423]
===
match
---
operator: = [7021,7022]
operator: = [7406,7407]
===
match
---
trailer [31586,31597]
trailer [31971,31982]
===
match
---
argument [19711,19731]
argument [20096,20116]
===
match
---
name: dag [25431,25434]
name: dag [25816,25819]
===
match
---
operator: { [5704,5705]
operator: { [6089,6090]
===
match
---
name: dag_file [36824,36832]
name: dag_file [37209,37217]
===
match
---
trailer [22162,22176]
trailer [22547,22561]
===
match
---
name: task_id [23881,23888]
name: task_id [24266,24273]
===
match
---
name: test_sync_perm_for_dag [32143,32165]
name: test_sync_perm_for_dag [32528,32550]
===
match
---
name: encoding [5959,5967]
name: encoding [6344,6352]
===
match
---
funcdef [32991,33126]
funcdef [33376,33511]
===
match
---
atom_expr [34567,34581]
atom_expr [34952,34966]
===
match
---
name: self [10878,10882]
name: self [11263,11267]
===
match
---
name: include_examples [38187,38203]
name: include_examples [38572,38588]
===
match
---
trailer [14421,14429]
trailer [14806,14814]
===
match
---
name: op_subdag_0 [20152,20163]
name: op_subdag_0 [20537,20548]
===
match
---
name: dag_id [14714,14720]
name: dag_id [15099,15105]
===
match
---
trailer [5842,5847]
trailer [6227,6232]
===
match
---
arglist [17670,17705]
arglist [18055,18090]
===
match
---
name: airflow [22288,22295]
name: airflow [22673,22680]
===
match
---
string: 'owner1' [17593,17601]
string: 'owner1' [17978,17986]
===
match
---
name: SerializedDagModel [36082,36100]
name: SerializedDagModel [36467,36485]
===
match
---
name: airflow [22331,22338]
name: airflow [22716,22723]
===
match
---
operator: , [8796,8797]
operator: , [9181,9182]
===
match
---
operator: = [19663,19664]
operator: = [20048,20049]
===
match
---
name: subdag_1 [20070,20078]
name: subdag_1 [20455,20463]
===
match
---
operator: , [12185,12186]
operator: , [12570,12571]
===
match
---
with_stmt [13952,14235]
with_stmt [14337,14620]
===
match
---
assert_stmt [6505,6570]
assert_stmt [6890,6955]
===
match
---
name: dag_folder [12245,12255]
name: dag_folder [12630,12640]
===
match
---
argument [16570,16577]
argument [16955,16962]
===
match
---
trailer [27114,27124]
trailer [27499,27509]
===
match
---
name: TEST_DAGS_FOLDER [36848,36864]
name: TEST_DAGS_FOLDER [37233,37249]
===
match
---
assert_stmt [7038,7062]
assert_stmt [7423,7447]
===
match
---
trailer [14046,14048]
trailer [14431,14433]
===
match
---
trailer [26247,26254]
trailer [26632,26639]
===
match
---
name: include_examples [5575,5591]
name: include_examples [5960,5976]
===
match
---
name: self [10281,10285]
name: self [10666,10670]
===
match
---
argument [12838,12892]
argument [13223,13277]
===
match
---
operator: { [37168,37169]
operator: { [37553,37554]
===
match
---
simple_stmt [10175,10209]
simple_stmt [10560,10594]
===
match
---
simple_stmt [34260,34314]
simple_stmt [34645,34699]
===
match
---
simple_stmt [19696,19766]
simple_stmt [20081,20151]
===
match
---
operator: } [37877,37878]
operator: } [38262,38263]
===
match
---
string: 'opSubdag_C' [25089,25101]
string: 'opSubdag_C' [25474,25486]
===
match
---
atom_expr [2700,2722]
atom_expr [2700,2722]
===
match
---
parameters [7708,7714]
parameters [8093,8099]
===
match
---
atom_expr [35116,35140]
atom_expr [35501,35525]
===
match
---
argument [37804,37830]
argument [38189,38215]
===
match
---
simple_stmt [36218,36252]
simple_stmt [36603,36637]
===
match
---
name: serialization [1391,1404]
name: serialization [1391,1404]
===
match
---
name: dagbag [26232,26238]
name: dagbag [26617,26623]
===
match
---
name: dag_folder [36916,36926]
name: dag_folder [37301,37311]
===
match
---
name: create_dag [13907,13917]
name: create_dag [14292,14302]
===
match
---
atom_expr [33464,33482]
atom_expr [33849,33867]
===
match
---
dotted_name [11394,11406]
dotted_name [11779,11791]
===
match
---
atom_expr [12815,12989]
atom_expr [13200,13374]
===
match
---
name: example_dags [36306,36318]
name: example_dags [36691,36703]
===
match
---
operator: , [35097,35098]
operator: , [35482,35483]
===
match
---
operator: = [18634,18635]
operator: = [19019,19020]
===
match
---
name: flush [6159,6164]
name: flush [6544,6549]
===
match
---
trailer [3004,3011]
trailer [3004,3011]
===
match
---
number: 0 [10440,10441]
number: 0 [10825,10826]
===
match
---
name: flush [14041,14046]
name: flush [14426,14431]
===
match
---
name: dag_id [14484,14490]
name: dag_id [14869,14875]
===
match
---
expr_stmt [35116,35155]
expr_stmt [35501,35540]
===
match
---
argument [9607,9628]
argument [9992,10013]
===
match
---
trailer [35068,35102]
trailer [35453,35487]
===
match
---
trailer [3684,3690]
trailer [4069,4075]
===
match
---
expr_stmt [13271,13348]
expr_stmt [13656,13733]
===
match
---
name: dagbag [28805,28811]
name: dagbag [29190,29196]
===
match
---
atom_expr [19939,20008]
atom_expr [20324,20393]
===
match
---
name: ANY [30705,30708]
name: ANY [31090,31093]
===
match
---
name: get_dag [9296,9303]
name: get_dag [9681,9688]
===
match
---
operator: = [28401,28402]
operator: = [28786,28787]
===
match
---
operator: = [8758,8759]
operator: = [9143,9144]
===
match
---
arglist [37759,37830]
arglist [38144,38215]
===
match
---
simple_stmt [18906,18959]
simple_stmt [19291,19344]
===
match
---
atom_expr [12256,12290]
atom_expr [12641,12675]
===
match
---
name: include_examples [26562,26578]
name: include_examples [26947,26963]
===
match
---
atom_expr [13415,13453]
atom_expr [13800,13838]
===
match
---
suite [4318,4398]
suite [4703,4783]
===
match
---
name: dagbag_stats [3905,3917]
name: dagbag_stats [4290,4302]
===
match
---
name: dagbag [3131,3137]
name: dagbag [3131,3137]
===
match
---
name: create_dag [13694,13704]
name: create_dag [14079,14089]
===
match
---
simple_stmt [23624,23677]
simple_stmt [24009,24062]
===
match
---
trailer [36144,36168]
trailer [36529,36553]
===
match
---
trailer [30669,30731]
trailer [31054,31116]
===
match
---
return_stmt [16855,16865]
return_stmt [17240,17250]
===
match
---
name: task_id [20044,20051]
name: task_id [20429,20436]
===
match
---
operator: = [5241,5242]
operator: = [5626,5627]
===
match
---
name: dag [14390,14393]
name: dag [14775,14778]
===
match
---
operator: = [24839,24840]
operator: = [25224,25225]
===
match
---
string: 'nested_cycle.op_subdag_0' [24652,24678]
string: 'nested_cycle.op_subdag_0' [25037,25063]
===
match
---
with_stmt [23460,25604]
with_stmt [23845,25989]
===
match
---
suite [24616,24923]
suite [25001,25308]
===
match
---
name: mock_dagmodel [11836,11849]
name: mock_dagmodel [12221,12234]
===
match
---
operator: , [34828,34829]
operator: , [35213,35214]
===
match
---
fstring_start: f""" [37108,37112]
fstring_start: f""" [37493,37497]
===
match
---
name: len [36302,36305]
name: len [36687,36690]
===
match
---
atom_expr [3898,3917]
atom_expr [4283,4302]
===
match
---
trailer [36525,36535]
trailer [36910,36920]
===
match
---
atom_expr [20966,20977]
atom_expr [21351,21362]
===
match
---
expr_stmt [3811,3873]
expr_stmt [4196,4258]
===
match
---
name: min_update_interval [30680,30699]
name: min_update_interval [31065,31084]
===
match
---
operator: = [19401,19402]
operator: = [19786,19787]
===
match
---
trailer [37676,37681]
trailer [38061,38066]
===
match
---
expr_stmt [26904,26947]
expr_stmt [27289,27332]
===
match
---
name: airflow [1228,1235]
name: airflow [1228,1235]
===
match
---
name: mock_dagmodel [8586,8599]
name: mock_dagmodel [8971,8984]
===
match
---
arglist [28416,28465]
arglist [28801,28850]
===
match
---
simple_stmt [3222,3283]
simple_stmt [3607,3668]
===
match
---
operator: , [12978,12979]
operator: , [13363,13364]
===
match
---
atom_expr [3995,4001]
atom_expr [4380,4386]
===
match
---
name: patch [29011,29016]
name: patch [29396,29401]
===
match
---
expr_stmt [20152,20231]
expr_stmt [20537,20616]
===
match
---
name: SerializedDagModel [27933,27951]
name: SerializedDagModel [28318,28336]
===
match
---
operator: , [17678,17679]
operator: , [18063,18064]
===
match
---
trailer [18588,18648]
trailer [18973,19033]
===
match
---
atom_expr [19606,19675]
atom_expr [19991,20060]
===
match
---
name: task_id [16426,16433]
name: task_id [16811,16818]
===
match
---
operator: , [4676,4677]
operator: , [5061,5062]
===
match
---
string: """         test the loading of a DAG from within a zip file that skips another file because         it doesn't have "airflow" and "DAG"         """ [6689,6837]
string: """         test the loading of a DAG from within a zip file that skips another file because         it doesn't have "airflow" and "DAG"         """ [7074,7222]
===
match
---
trailer [7506,7511]
trailer [7891,7896]
===
match
---
operator: = [2510,2511]
operator: = [2510,2511]
===
match
---
expr_stmt [4728,4791]
expr_stmt [5113,5176]
===
match
---
number: 2020 [35081,35085]
number: 2020 [35466,35470]
===
match
---
trailer [20463,20476]
trailer [20848,20861]
===
match
---
classdef [11890,12215]
classdef [12275,12600]
===
match
---
testlist_comp [7859,7910]
testlist_comp [8244,8295]
===
match
---
operator: = [37064,37065]
operator: = [37449,37450]
===
match
---
trailer [27124,27131]
trailer [27509,27516]
===
match
---
parameters [17321,17323]
parameters [17706,17708]
===
match
---
name: found_dags [14148,14158]
name: found_dags [14533,14543]
===
match
---
atom_expr [13326,13346]
atom_expr [13711,13731]
===
match
---
name: fileloc [10964,10971]
name: fileloc [11349,11356]
===
match
---
trailer [28771,28776]
trailer [29156,29161]
===
match
---
simple_stmt [19939,20009]
simple_stmt [20324,20394]
===
match
---
trailer [20535,20537]
trailer [20920,20922]
===
match
---
operator: = [36907,36908]
operator: = [37292,37293]
===
match
---
name: expected_import_errors [37041,37063]
name: expected_import_errors [37426,37448]
===
match
---
name: dag [2743,2746]
name: dag [2743,2746]
===
match
---
argument [20066,20078]
argument [20451,20463]
===
match
---
trailer [7501,7506]
trailer [7886,7891]
===
match
---
name: dags [36282,36286]
name: dags [36667,36671]
===
match
---
argument [18945,18957]
argument [19330,19342]
===
match
---
operator: = [19345,19346]
operator: = [19730,19731]
===
match
---
operator: = [26553,26554]
operator: = [26938,26939]
===
match
---
name: dags_in_bag [6605,6616]
name: dags_in_bag [6990,7001]
===
match
---
number: 2 [13344,13345]
number: 2 [13729,13730]
===
match
---
atom_expr [29542,29550]
atom_expr [29927,29935]
===
match
---
parameters [6665,6679]
parameters [7050,7064]
===
match
---
name: test_utils [1782,1792]
name: test_utils [1782,1792]
===
match
---
name: patch [33687,33692]
name: patch [34072,34077]
===
match
---
name: dummy [15488,15493]
name: dummy [15873,15878]
===
match
---
name: count [27927,27932]
name: count [28312,28317]
===
match
---
operator: = [25088,25089]
operator: = [25473,25474]
===
match
---
simple_stmt [12439,12467]
simple_stmt [12824,12852]
===
match
---
operator: , [11415,11416]
operator: , [11800,11801]
===
match
---
trailer [10112,10118]
trailer [10497,10503]
===
match
---
atom [15639,15703]
atom [16024,16088]
===
match
---
name: dag_id [6298,6304]
name: dag_id [6683,6689]
===
match
---
name: dag [20497,20500]
name: dag [20882,20885]
===
match
---
operator: , [35713,35714]
operator: , [36098,36099]
===
match
---
expr_stmt [31939,31961]
expr_stmt [32324,32346]
===
match
---
name: expected_parent_dag [14940,14959]
name: expected_parent_dag [15325,15344]
===
match
---
name: dagbag [26087,26093]
name: dagbag [26472,26478]
===
match
---
name: test_sync_to_db_syncs_dag_specific_perms_on_update [30849,30899]
name: test_sync_to_db_syncs_dag_specific_perms_on_update [31234,31284]
===
match
---
atom [29660,29690]
atom [30045,30075]
===
match
---
number: 5 [34647,34648]
number: 5 [35032,35033]
===
match
---
atom_expr [28489,28583]
atom_expr [28874,28968]
===
match
---
name: airflow [5643,5650]
name: airflow [6028,6035]
===
match
---
trailer [4221,4231]
trailer [4606,4616]
===
match
---
operator: = [14069,14070]
operator: = [14454,14455]
===
match
---
name: subdag_0 [25347,25355]
name: subdag_0 [25732,25740]
===
match
---
atom_expr [20521,20537]
atom_expr [20906,20922]
===
match
---
string: 'airflow/example_dags/example_subdag_operator.py' [9853,9902]
string: 'airflow/example_dags/example_subdag_operator.py' [10238,10287]
===
match
---
decorated [11393,12513]
decorated [11778,12898]
===
match
---
name: airflow [15470,15477]
name: airflow [15855,15862]
===
match
---
number: 1 [13936,13937]
number: 1 [14321,14322]
===
match
---
trailer [10666,10679]
trailer [11051,11064]
===
match
---
trailer [4866,4879]
trailer [5251,5264]
===
match
---
number: 1 [34818,34819]
number: 1 [35203,35204]
===
match
---
name: datetime [10682,10690]
name: datetime [11067,11075]
===
match
---
suite [22241,25628]
suite [22626,26013]
===
match
---
argument [38211,38237]
argument [38596,38622]
===
match
---
name: dag_file [38071,38079]
name: dag_file [38456,38464]
===
match
---
name: should_be_found [14895,14910]
name: should_be_found [15280,15295]
===
match
---
number: 5 [30838,30839]
number: 5 [31223,31224]
===
match
---
trailer [30330,30332]
trailer [30715,30717]
===
match
---
name: dagbag [3898,3904]
name: dagbag [4283,4289]
===
match
---
trailer [13635,13642]
trailer [14020,14027]
===
match
---
atom_expr [21732,21745]
atom_expr [22117,22130]
===
match
---
name: subdag_1 [19823,19831]
name: subdag_1 [20208,20216]
===
match
---
parameters [11465,11486]
parameters [11850,11871]
===
match
---
operator: , [15734,15735]
operator: , [16119,16120]
===
match
---
assert_stmt [3936,4004]
assert_stmt [4321,4389]
===
match
---
name: caplog [28643,28649]
name: caplog [29028,29034]
===
match
---
simple_stmt [31491,31527]
simple_stmt [31876,31912]
===
match
---
suite [4640,4922]
suite [5025,5307]
===
match
---
simple_stmt [22453,22479]
simple_stmt [22838,22864]
===
match
---
trailer [33594,33680]
trailer [33979,34065]
===
match
---
name: cluster_policies [37440,37456]
name: cluster_policies [37825,37841]
===
match
---
name: os [10520,10522]
name: os [10905,10907]
===
match
---
atom_expr [35664,35686]
atom_expr [36049,36071]
===
match
---
simple_stmt [22388,22440]
simple_stmt [22773,22825]
===
match
---
operator: , [26729,26730]
operator: , [27114,27115]
===
match
---
name: op_a [20345,20349]
name: op_a [20730,20734]
===
match
---
name: dag_id [11267,11273]
name: dag_id [11652,11658]
===
match
---
operator: = [34182,34183]
operator: = [34567,34568]
===
match
---
trailer [7201,7206]
trailer [7586,7591]
===
match
---
atom_expr [24495,24547]
atom_expr [24880,24932]
===
match
---
expr_stmt [24976,25045]
expr_stmt [25361,25430]
===
match
---
operator: = [7368,7369]
operator: = [7753,7754]
===
match
---
atom_expr [16886,16903]
atom_expr [17271,17288]
===
match
---
name: DagBag [13093,13099]
name: DagBag [13478,13484]
===
match
---
string: "example_bash_operator.py" [10554,10580]
string: "example_bash_operator.py" [10939,10965]
===
match
---
name: dag_id [15019,15025]
name: dag_id [15404,15410]
===
match
---
trailer [8654,8667]
trailer [9039,9052]
===
match
---
name: mock_dag [29408,29416]
name: mock_dag [29793,29801]
===
match
---
name: default_args [24448,24460]
name: default_args [24833,24845]
===
match
---
atom_expr [24987,25045]
atom_expr [25372,25430]
===
match
---
name: sync_perm_for_dag [32640,32657]
name: sync_perm_for_dag [33025,33042]
===
match
---
simple_stmt [16518,16598]
simple_stmt [16903,16983]
===
match
---
parameters [1946,1951]
parameters [1946,1951]
===
match
---
name: self [11466,11470]
name: self [11851,11855]
===
match
---
name: DagBag [35964,35970]
name: DagBag [36349,36355]
===
match
---
string: "test_zip.zip/test_zip.py" [11658,11684]
string: "test_zip.zip/test_zip.py" [12043,12069]
===
match
---
trailer [14456,14463]
trailer [14841,14848]
===
match
---
operator: , [25101,25102]
operator: , [25486,25487]
===
match
---
argument [19621,19641]
argument [20006,20026]
===
match
---
import_from [1273,1316]
import_from [1273,1316]
===
match
---
argument [25331,25338]
argument [25716,25723]
===
match
---
trailer [31876,31894]
trailer [32261,32279]
===
match
---
argument [24854,24866]
argument [25239,25251]
===
match
---
trailer [31214,31219]
trailer [31599,31604]
===
match
---
name: SubDagOperator [25293,25307]
name: SubDagOperator [25678,25692]
===
match
---
operator: = [29541,29542]
operator: = [29926,29927]
===
match
---
simple_stmt [6415,6456]
simple_stmt [6800,6841]
===
match
---
simple_stmt [11350,11388]
simple_stmt [11735,11773]
===
match
---
operator: == [25787,25789]
operator: == [26172,26174]
===
match
---
atom_expr [24648,24706]
atom_expr [25033,25091]
===
match
---
name: _TestDagBag [10792,10803]
name: _TestDagBag [11177,11188]
===
match
---
operator: == [20655,20657]
operator: == [21040,21042]
===
match
---
assert_stmt [28596,28629]
assert_stmt [28981,29014]
===
match
---
atom_expr [3325,3339]
atom_expr [3710,3724]
===
match
---
atom_expr [34115,34147]
atom_expr [34500,34532]
===
match
---
simple_stmt [16855,16866]
simple_stmt [17240,17251]
===
match
---
operator: } [4315,4316]
operator: } [4700,4701]
===
match
---
operator: = [31206,31207]
operator: = [31591,31592]
===
match
---
comparison [10952,10971]
comparison [11337,11356]
===
match
---
trailer [13880,13943]
trailer [14265,14328]
===
match
---
name: default_args [19892,19904]
name: default_args [20277,20289]
===
match
---
string: "airflow.www.security.ApplessAirflowSecurityManager" [32081,32133]
string: "airflow.www.security.ApplessAirflowSecurityManager" [32466,32518]
===
match
---
atom [4275,4316]
atom [4660,4701]
===
match
---
name: path [27670,27674]
name: path [28055,28059]
===
match
---
name: include_examples [4751,4767]
name: include_examples [5136,5152]
===
match
---
expr_stmt [10388,10442]
expr_stmt [10773,10827]
===
match
---
trailer [25132,25134]
trailer [25517,25519]
===
match
---
arglist [18826,18884]
arglist [19211,19269]
===
match
---
name: new_dags [36260,36268]
name: new_dags [36645,36653]
===
match
---
trailer [6234,6245]
trailer [6619,6630]
===
match
---
simple_stmt [3683,3701]
simple_stmt [4068,4086]
===
match
---
name: self [28147,28151]
name: self [28532,28536]
===
match
---
string: 'op_subdag_1' [16651,16664]
string: 'op_subdag_1' [17036,17049]
===
match
---
name: rollback [28938,28946]
name: rollback [29323,29331]
===
match
---
trailer [35600,35618]
trailer [35985,36003]
===
match
---
string: 'dags_folder' [4285,4298]
string: 'dags_folder' [4670,4683]
===
match
---
expr_stmt [22491,22570]
expr_stmt [22876,22955]
===
match
---
name: airflow [10410,10417]
name: airflow [10795,10802]
===
match
---
string: "utf8" [6032,6038]
string: "utf8" [6417,6423]
===
match
---
trailer [8124,8148]
trailer [8509,8533]
===
match
---
simple_stmt [2276,2295]
simple_stmt [2276,2295]
===
match
---
name: dags_hash [13364,13373]
name: dags_hash [13749,13758]
===
match
---
simple_stmt [7601,7662]
simple_stmt [7986,8047]
===
match
---
operator: , [19655,19656]
operator: , [20040,20041]
===
match
---
operator: , [28167,28168]
operator: , [28552,28553]
===
match
---
string: 'subdag_1.task' [16434,16449]
string: 'subdag_1.task' [16819,16834]
===
match
---
simple_stmt [24907,24923]
simple_stmt [25292,25308]
===
match
---
assert_stmt [13567,13616]
assert_stmt [13952,14001]
===
match
---
assert_stmt [2771,2798]
assert_stmt [2771,2798]
===
match
---
operator: , [29533,29534]
operator: , [29918,29919]
===
match
---
trailer [26808,26814]
trailer [27193,27199]
===
match
---
name: test_dag_cluster_policy_obeyed [38025,38055]
name: test_dag_cluster_policy_obeyed [38410,38440]
===
match
---
operator: = [34292,34293]
operator: = [34677,34678]
===
match
---
trailer [19672,19674]
trailer [20057,20059]
===
match
---
operator: = [16650,16651]
operator: = [17035,17036]
===
match
---
string: """         Test that dagbag.sync_to_db will sync DAG specific permissions when a DAG is         new or updated         """ [30915,31038]
string: """         Test that dagbag.sync_to_db will sync DAG specific permissions when a DAG is         new or updated         """ [31300,31423]
===
match
---
suite [4486,4922]
suite [4871,5307]
===
match
---
operator: , [34819,34820]
operator: , [35204,35205]
===
match
---
name: DagBag [34184,34190]
name: DagBag [34569,34575]
===
match
---
name: join [28411,28415]
name: join [28796,28800]
===
match
---
simple_stmt [28734,28777]
simple_stmt [29119,29162]
===
match
---
atom_expr [27798,27817]
atom_expr [28183,28202]
===
match
---
comparison [25765,25791]
comparison [26150,26176]
===
match
---
name: max [11795,11798]
name: max [12180,12183]
===
match
---
atom_expr [13093,13174]
atom_expr [13478,13559]
===
match
---
expr_stmt [10732,10776]
expr_stmt [11117,11161]
===
match
---
assert_stmt [11283,11305]
assert_stmt [11668,11690]
===
match
---
simple_stmt [38071,38141]
simple_stmt [38456,38526]
===
match
---
name: dag_folder [26255,26265]
name: dag_folder [26640,26650]
===
match
---
operator: = [24150,24151]
operator: = [24535,24536]
===
match
---
return_stmt [19216,19231]
return_stmt [19601,19616]
===
match
---
with_stmt [12810,13042]
with_stmt [13195,13427]
===
match
---
trailer [8197,8216]
trailer [8582,8601]
===
match
---
operator: , [25425,25426]
operator: , [25810,25811]
===
match
---
operator: } [10073,10074]
operator: } [10458,10459]
===
match
---
trailer [20943,20945]
trailer [21328,21330]
===
match
---
param [5406,5410]
param [5791,5795]
===
match
---
name: mock_dag [29469,29477]
name: mock_dag [29854,29862]
===
match
---
comparison [13574,13616]
comparison [13959,14001]
===
match
---
name: patch [37402,37407]
name: patch [37787,37792]
===
match
---
operator: = [31170,31171]
operator: = [31555,31556]
===
match
---
operator: == [8036,8038]
operator: == [8421,8423]
===
match
---
arglist [5953,5974]
arglist [6338,6359]
===
match
---
dotted_name [17371,17385]
dotted_name [17756,17770]
===
match
---
name: subdag_c [25124,25132]
name: subdag_c [25509,25517]
===
match
---
comparison [6475,6492]
comparison [6860,6877]
===
match
---
arglist [19711,19764]
arglist [20096,20149]
===
match
---
trailer [25307,25358]
trailer [25692,25743]
===
match
---
trailer [5339,5352]
trailer [5724,5737]
===
match
---
name: op_a [20444,20448]
name: op_a [20829,20833]
===
match
---
name: tags [34559,34563]
name: tags [34944,34948]
===
match
---
operator: = [24767,24768]
operator: = [25152,25153]
===
match
---
operator: , [25329,25330]
operator: , [25714,25715]
===
match
---
argument [16225,16237]
argument [16610,16622]
===
match
---
name: f [13981,13982]
name: f [14366,14367]
===
match
---
name: subdag_0 [24858,24866]
name: subdag_0 [25243,25251]
===
match
---
atom_expr [35391,35423]
atom_expr [35776,35808]
===
match
---
operator: = [21387,21388]
operator: = [21772,21773]
===
match
---
name: dag [25335,25338]
name: dag [25720,25723]
===
match
---
name: _sync_to_db [31828,31839]
name: _sync_to_db [32213,32224]
===
match
---
trailer [36187,36204]
trailer [36572,36589]
===
match
---
operator: , [21446,21447]
operator: , [21831,21832]
===
match
---
atom_expr [8232,8248]
atom_expr [8617,8633]
===
match
---
string: 'parent.op_subdag_1' [16343,16363]
string: 'parent.op_subdag_1' [16728,16748]
===
match
---
trailer [31839,31841]
trailer [32224,32226]
===
match
---
operator: , [24532,24533]
operator: , [24917,24918]
===
match
---
atom_expr [25648,25669]
atom_expr [26033,26054]
===
match
---
operator: , [4283,4284]
operator: , [4668,4669]
===
match
---
string: "test_example_bash_operator.py" [28434,28465]
string: "test_example_bash_operator.py" [28819,28850]
===
match
---
argument [7970,7992]
argument [8355,8377]
===
match
---
name: dag [13256,13259]
name: dag [13641,13644]
===
match
---
import_as_name [1477,1491]
import_as_name [1477,1491]
===
match
---
trailer [13335,13346]
trailer [13720,13731]
===
match
---
expr_stmt [15592,15611]
expr_stmt [15977,15996]
===
match
---
atom_expr [26241,26305]
atom_expr [26626,26690]
===
match
---
trailer [9572,9579]
trailer [9957,9964]
===
match
---
atom_expr [32529,32567]
atom_expr [32914,32952]
===
match
---
simple_stmt [5320,5361]
simple_stmt [5705,5746]
===
match
---
atom [33485,33509]
atom [33870,33894]
===
match
---
atom_expr [33548,33680]
atom_expr [33933,34065]
===
match
---
atom_expr [21462,21491]
atom_expr [21847,21876]
===
match
---
simple_stmt [21505,21552]
simple_stmt [21890,21937]
===
match
---
operator: , [16664,16665]
operator: , [17049,17050]
===
match
---
operator: = [18927,18928]
operator: = [19312,19313]
===
match
---
argument [20366,20377]
argument [20751,20762]
===
match
---
number: 2020 [34638,34642]
number: 2020 [35023,35027]
===
match
---
name: path [11613,11617]
name: path [11998,12002]
===
match
---
name: dagbag [7397,7403]
name: dagbag [7782,7788]
===
match
---
name: dag [11246,11249]
name: dag [11631,11634]
===
match
---
suite [17324,20501]
suite [17709,20886]
===
match
---
operator: , [15080,15081]
operator: , [15465,15466]
===
match
---
comp_op [2747,2753]
comp_op [2747,2753]
===
match
---
argument [14085,14110]
argument [14470,14495]
===
match
---
simple_stmt [1018,1050]
simple_stmt [1018,1050]
===
match
---
operator: , [34816,34817]
operator: , [35201,35202]
===
match
---
comparison [22143,22176]
comparison [22528,22561]
===
match
---
atom [6361,6363]
atom [6746,6748]
===
match
---
testlist_comp [4670,4691]
testlist_comp [5055,5076]
===
match
---
simple_stmt [3713,3723]
simple_stmt [4098,4108]
===
match
---
suite [7241,7662]
suite [7626,8047]
===
match
---
param [27248,27252]
param [27633,27637]
===
match
---
trailer [30325,30330]
trailer [30710,30715]
===
match
---
suite [3446,4005]
suite [3831,4390]
===
match
---
atom_expr [30000,30037]
atom_expr [30385,30422]
===
match
---
trailer [25080,25135]
trailer [25465,25520]
===
match
---
simple_stmt [28687,28722]
simple_stmt [29072,29107]
===
match
---
expr_stmt [37743,37831]
expr_stmt [38128,38216]
===
match
---
name: logging [807,814]
name: logging [807,814]
===
match
---
trailer [29968,30172]
trailer [30353,30557]
===
match
---
trailer [14084,14135]
trailer [14469,14520]
===
match
---
argument [25081,25101]
argument [25466,25486]
===
match
---
name: patch [1044,1049]
name: patch [1044,1049]
===
match
---
comparison [13479,13513]
comparison [13864,13898]
===
match
---
simple_stmt [27576,27610]
simple_stmt [27961,27995]
===
match
---
argument [11168,11189]
argument [11553,11574]
===
match
---
name: include_examples [9085,9101]
name: include_examples [9470,9486]
===
match
---
if_stmt [8863,8980]
if_stmt [9248,9365]
===
match
---
trailer [9295,9303]
trailer [9680,9688]
===
match
---
atom_expr [22589,22629]
atom_expr [22974,23014]
===
match
---
operator: = [12844,12845]
operator: = [13229,13230]
===
match
---
operator: = [18583,18584]
operator: = [18968,18969]
===
match
---
name: process_file_calls [12109,12127]
name: process_file_calls [12494,12512]
===
match
---
name: path [10096,10100]
name: path [10481,10485]
===
match
---
trailer [8114,8119]
trailer [8499,8504]
===
match
---
name: dagbag [5234,5240]
name: dagbag [5619,5625]
===
match
---
operator: = [27500,27501]
operator: = [27885,27886]
===
match
---
name: test_get_non_existing_dag [2843,2868]
name: test_get_non_existing_dag [2843,2868]
===
match
---
name: ser_dag_1 [34567,34576]
name: ser_dag_1 [34952,34961]
===
match
---
name: query [27916,27921]
name: query [28301,28306]
===
match
---
name: size [3388,3392]
name: size [3773,3777]
===
match
---
trailer [27926,27932]
trailer [28311,28317]
===
match
---
number: 8 [35421,35422]
number: 8 [35806,35807]
===
match
---
operator: = [18948,18949]
operator: = [19333,19334]
===
match
---
atom_expr [5934,5975]
atom_expr [6319,6360]
===
match
---
arglist [7512,7544]
arglist [7897,7929]
===
match
---
atom_expr [34469,34519]
atom_expr [34854,34904]
===
match
---
trailer [26670,26675]
trailer [27055,27060]
===
match
---
atom_expr [31714,31782]
atom_expr [32099,32167]
===
match
---
name: task_id [24143,24150]
name: task_id [24528,24535]
===
match
---
suite [32497,33681]
suite [32882,34066]
===
match
---
operator: = [13168,13169]
operator: = [13553,13554]
===
match
---
dictorsetmaker [3752,3791]
dictorsetmaker [4137,4176]
===
match
---
trailer [20931,20936]
trailer [21316,21321]
===
match
---
trailer [13896,13906]
trailer [14281,14291]
===
match
---
atom_expr [20444,20476]
atom_expr [20829,20861]
===
match
---
name: subdag_c [23977,23985]
name: subdag_c [24362,24370]
===
match
---
atom_expr [27908,27969]
atom_expr [28293,28354]
===
match
---
name: tz [35391,35393]
name: tz [35776,35778]
===
match
---
name: dag_id [15265,15271]
name: dag_id [15650,15656]
===
match
---
arglist [9671,9703]
arglist [10056,10088]
===
match
---
simple_stmt [28883,28918]
simple_stmt [29268,29303]
===
match
---
name: dag_name [17670,17678]
name: dag_name [18055,18063]
===
match
---
operator: , [7968,7969]
operator: , [8353,8354]
===
match
---
trailer [12459,12466]
trailer [12844,12851]
===
match
---
operator: , [17243,17244]
operator: , [17628,17629]
===
match
---
name: subdag_1 [25107,25115]
name: subdag_1 [25492,25500]
===
match
---
operator: , [16568,16569]
operator: , [16953,16954]
===
match
---
assert_stmt [26067,26107]
assert_stmt [26452,26492]
===
match
---
string: 'dags_folder' [4678,4691]
string: 'dags_folder' [5063,5076]
===
match
---
name: dagbag [38258,38264]
name: dagbag [38643,38649]
===
match
---
name: SubDagOperator [19696,19710]
name: SubDagOperator [20081,20095]
===
match
---
operator: { [14666,14667]
operator: { [15051,15052]
===
match
---
import_from [992,1017]
import_from [992,1017]
===
match
---
name: subdag [25436,25442]
name: subdag [25821,25827]
===
match
---
name: path [10203,10207]
name: path [10588,10592]
===
match
---
name: tests [1776,1781]
name: tests [1776,1781]
===
match
---
operator: == [8249,8251]
operator: == [8634,8636]
===
match
---
name: dagbag [6215,6221]
name: dagbag [6600,6606]
===
match
---
assert_stmt [12408,12430]
assert_stmt [12793,12815]
===
match
---
fstring_end: ' [14674,14675]
fstring_end: ' [15059,15060]
===
match
---
funcdef [19012,19232]
funcdef [19397,19617]
===
match
---
number: 0 [35944,35945]
number: 0 [36329,36330]
===
match
---
name: set [35660,35663]
name: set [36045,36048]
===
match
---
name: replace [10695,10702]
name: replace [11080,11087]
===
match
---
atom_expr [5211,5220]
atom_expr [5596,5605]
===
match
---
name: subdag_b [18949,18957]
name: subdag_b [19334,19342]
===
match
---
atom_expr [34260,34313]
atom_expr [34645,34698]
===
match
---
suite [19264,19469]
suite [19649,19854]
===
match
---
suite [35836,36559]
suite [36221,36944]
===
match
---
name: unittest [997,1005]
name: unittest [997,1005]
===
match
---
atom_expr [30010,30018]
atom_expr [30395,30403]
===
match
---
param [11982,11987]
param [12367,12372]
===
match
---
atom_expr [5333,5360]
atom_expr [5718,5745]
===
match
---
suite [10972,11029]
suite [11357,11414]
===
match
---
name: op_error [29671,29679]
name: op_error [30056,30064]
===
match
---
name: clear_db_runs [2279,2292]
name: clear_db_runs [2279,2292]
===
match
---
simple_stmt [15465,15515]
simple_stmt [15850,15900]
===
match
---
name: dag_name [22593,22601]
name: dag_name [22978,22986]
===
match
---
trailer [9254,9273]
trailer [9639,9658]
===
match
---
string: 'example_bash_operator' [9740,9763]
string: 'example_bash_operator' [10125,10148]
===
match
---
trailer [3596,3630]
trailer [3981,4015]
===
match
---
name: subdag_c [19223,19231]
name: subdag_c [19608,19616]
===
match
---
operator: , [34651,34652]
operator: , [35036,35037]
===
match
---
name: subdag [17494,17500]
name: subdag [17879,17885]
===
match
---
simple_stmt [9116,9142]
simple_stmt [9501,9527]
===
match
---
parameters [23742,23744]
parameters [24127,24129]
===
match
---
with_item [32469,32496]
with_item [32854,32881]
===
match
---
if_stmt [12053,12133]
if_stmt [12438,12518]
===
match
---
name: empty_dir [4306,4315]
name: empty_dir [4691,4700]
===
match
---
assert_stmt [14689,14981]
assert_stmt [15074,15366]
===
match
---
assert_stmt [4853,4921]
assert_stmt [5238,5306]
===
match
---
simple_stmt [18979,18995]
simple_stmt [19364,19380]
===
match
---
name: subdag_0 [19490,19498]
name: subdag_0 [19875,19883]
===
match
---
operator: = [38203,38204]
operator: = [38588,38589]
===
match
---
name: tz [12953,12955]
name: tz [13338,13340]
===
match
---
name: f [14039,14040]
name: f [14424,14425]
===
match
---
simple_stmt [19380,19433]
simple_stmt [19765,19818]
===
match
---
string: "w+" [6017,6021]
string: "w+" [6402,6406]
===
match
---
trailer [2048,2055]
trailer [2048,2055]
===
match
---
trailer [2160,2162]
trailer [2160,2162]
===
match
---
if_stmt [10949,11029]
if_stmt [11334,11414]
===
match
---
expr_stmt [36900,36988]
expr_stmt [37285,37373]
===
match
---
string: 'get_current' [8283,8296]
string: 'get_current' [8668,8681]
===
match
---
trailer [10193,10202]
trailer [10578,10587]
===
match
---
operator: = [19979,19980]
operator: = [20364,20365]
===
match
---
name: assert_not_called [33379,33396]
name: assert_not_called [33764,33781]
===
match
---
simple_stmt [892,943]
simple_stmt [892,943]
===
match
---
name: datetime [897,905]
name: datetime [897,905]
===
match
---
trailer [3994,4002]
trailer [4379,4387]
===
match
---
name: op_subdag_0 [25542,25553]
name: op_subdag_0 [25927,25938]
===
match
---
atom_expr [14529,14575]
atom_expr [14914,14960]
===
match
---
name: found_dags [20710,20720]
name: found_dags [21095,21105]
===
match
---
name: non_existing_dag_id [3072,3091]
name: non_existing_dag_id [3072,3091]
===
match
---
atom [31950,31961]
atom [32335,32346]
===
match
---
name: dags [8243,8247]
name: dags [8628,8632]
===
match
---
comparison [3894,3923]
comparison [4279,4308]
===
match
---
dictorsetmaker [17584,17646]
dictorsetmaker [17969,18031]
===
match
---
trailer [6297,6304]
trailer [6682,6689]
===
match
---
name: filepath [9017,9025]
name: filepath [9402,9410]
===
match
---
expr_stmt [16614,16693]
expr_stmt [16999,17078]
===
match
---
decorated [1914,1987]
decorated [1914,1987]
===
match
---
simple_stmt [34893,34973]
simple_stmt [35278,35358]
===
match
---
name: subdag [19990,19996]
name: subdag [20375,20381]
===
match
---
operator: { [13197,13198]
operator: { [13582,13583]
===
match
---
argument [16451,16463]
argument [16836,16848]
===
match
---
operator: = [5558,5559]
operator: = [5943,5944]
===
match
---
name: TEST_DAGS_FOLDER [37682,37698]
name: TEST_DAGS_FOLDER [38067,38083]
===
match
---
atom_expr [27101,27191]
atom_expr [27486,27576]
===
match
---
trailer [4882,4887]
trailer [5267,5272]
===
match
---
assert_stmt [4804,4840]
assert_stmt [5189,5225]
===
match
---
operator: = [16228,16229]
operator: = [16613,16614]
===
match
---
assert_stmt [26994,27026]
assert_stmt [27379,27411]
===
match
---
operator: { [4668,4669]
operator: { [5053,5054]
===
match
---
expr_stmt [38150,38238]
expr_stmt [38535,38623]
===
match
---
import_from [943,991]
import_from [943,991]
===
match
---
string: 'parent.op_subdag_0' [19537,19557]
string: 'parent.op_subdag_0' [19922,19942]
===
match
---
trailer [24883,24885]
trailer [25268,25270]
===
match
---
atom_expr [19533,19585]
atom_expr [19918,19970]
===
match
---
name: session [32052,32059]
name: session [32437,32444]
===
match
---
simple_stmt [23940,23956]
simple_stmt [24325,24341]
===
match
---
name: dag [31939,31942]
name: dag [32324,32327]
===
match
---
operator: = [11608,11609]
operator: = [11993,11994]
===
match
---
trailer [12493,12512]
trailer [12878,12897]
===
match
---
name: import_errors [37382,37395]
name: import_errors [37767,37780]
===
match
---
trailer [29546,29550]
trailer [29931,29935]
===
match
---
name: tz [34800,34802]
name: tz [35185,35187]
===
match
---
atom_expr [8236,8247]
atom_expr [8621,8632]
===
match
---
return_stmt [18979,18994]
return_stmt [19364,19379]
===
match
---
simple_stmt [5822,5921]
simple_stmt [6207,6306]
===
match
---
name: found_dags [25842,25852]
name: found_dags [26227,26237]
===
match
---
operator: = [2698,2699]
operator: = [2698,2699]
===
match
---
trailer [6164,6166]
trailer [6549,6551]
===
match
---
name: operators [12764,12773]
name: operators [13149,13158]
===
match
---
argument [4775,4790]
argument [5160,5175]
===
match
---
name: dummy [17432,17437]
name: dummy [17817,17822]
===
match
---
name: include_smart_sensor [36937,36957]
name: include_smart_sensor [37322,37342]
===
match
---
name: subdag_d [24394,24402]
name: subdag_d [24779,24787]
===
match
---
name: subdag [24778,24784]
name: subdag [25163,25169]
===
match
---
name: DagBag [5541,5547]
name: DagBag [5926,5932]
===
match
---
expr_stmt [12097,12132]
expr_stmt [12482,12517]
===
match
---
argument [29815,29835]
argument [30200,30220]
===
match
---
trailer [4305,4315]
trailer [4690,4700]
===
match
---
operator: = [8503,8504]
operator: = [8888,8889]
===
match
---
operator: , [3339,3340]
operator: , [3724,3725]
===
match
---
trailer [5115,5117]
trailer [5500,5502]
===
match
---
name: DagModel [26707,26715]
name: DagModel [27092,27100]
===
match
---
number: 0 [34145,34146]
number: 0 [34530,34531]
===
match
---
number: 2021 [12965,12969]
number: 2021 [13350,13354]
===
match
---
name: mock [29542,29546]
name: mock [29927,29931]
===
match
---
simple_stmt [36398,36432]
simple_stmt [36783,36817]
===
match
---
arglist [7943,7992]
arglist [8328,8377]
===
match
---
arglist [12838,12979]
arglist [13223,13364]
===
match
---
name: TEST_DAGS_FOLDER [9671,9687]
name: TEST_DAGS_FOLDER [10056,10072]
===
match
---
name: self [20733,20737]
name: self [21118,21122]
===
match
---
operator: = [36926,36927]
operator: = [37311,37312]
===
match
---
simple_stmt [20444,20477]
simple_stmt [20829,20862]
===
match
---
name: frozen_time [31543,31554]
name: frozen_time [31928,31939]
===
match
---
name: empty_dir [5273,5282]
name: empty_dir [5658,5667]
===
match
---
name: process_file_calls [11369,11387]
name: process_file_calls [11754,11772]
===
match
---
trailer [23637,23676]
trailer [24022,24061]
===
match
---
argument [23881,23904]
argument [24266,24289]
===
match
---
argument [27748,27770]
argument [28133,28155]
===
match
---
operator: , [3856,3857]
operator: , [4241,4242]
===
match
---
number: 0 [6491,6492]
number: 0 [6876,6877]
===
match
---
name: deepcopy [7370,7378]
name: deepcopy [7755,7763]
===
match
---
string: """With safe mode enabled, a file not matching the discovery heuristics         should not be discovered.         """ [4063,4180]
string: """With safe mode enabled, a file not matching the discovery heuristics         should not be discovered.         """ [4448,4565]
===
match
---
name: include_smart_sensor [38211,38231]
name: include_smart_sensor [38596,38616]
===
match
---
suite [5625,5813]
suite [6010,6198]
===
match
---
name: validate_dags [14244,14257]
name: validate_dags [14629,14642]
===
match
---
number: 1 [28018,28019]
number: 1 [28403,28404]
===
match
---
name: dag [14385,14388]
name: dag [14770,14773]
===
match
---
number: 2016 [17635,17639]
number: 2016 [18020,18024]
===
match
---
argument [19182,19194]
argument [19567,19579]
===
match
---
trailer [28495,28583]
trailer [28880,28968]
===
match
---
atom_expr [38159,38238]
atom_expr [38544,38623]
===
match
---
atom_expr [34184,34247]
atom_expr [34569,34632]
===
match
---
name: patch [36565,36570]
name: patch [36950,36955]
===
match
---
name: assert_queries_count [34852,34872]
name: assert_queries_count [35237,35257]
===
match
---
comp_op [13540,13546]
comp_op [13925,13931]
===
match
---
name: dagbag [4421,4427]
name: dagbag [4806,4812]
===
match
---
simple_stmt [1961,1987]
simple_stmt [1961,1987]
===
match
---
operator: , [16673,16674]
operator: , [17058,17059]
===
match
---
import_name [785,799]
import_name [785,799]
===
match
---
name: read_dags_from_db [13151,13168]
name: read_dags_from_db [13536,13553]
===
match
---
name: DagBag [26248,26254]
name: DagBag [26633,26639]
===
match
---
simple_stmt [25637,25670]
simple_stmt [26022,26055]
===
match
---
name: my_flow [5795,5802]
name: my_flow [6180,6187]
===
match
---
dictorsetmaker [5705,5722]
dictorsetmaker [6090,6107]
===
match
---
string: 'core' [4670,4676]
string: 'core' [5055,5061]
===
match
---
name: mock_session [29757,29769]
name: mock_session [30142,30154]
===
match
---
simple_stmt [28480,28584]
simple_stmt [28865,28969]
===
match
---
name: only_if_updated [12187,12202]
name: only_if_updated [12572,12587]
===
match
---
simple_stmt [8538,8578]
simple_stmt [8923,8963]
===
match
---
suite [15380,16866]
suite [15765,17251]
===
match
---
trailer [25882,25903]
trailer [26267,26288]
===
match
---
trailer [34637,34658]
trailer [35022,35043]
===
match
---
dotted_name [1776,1799]
dotted_name [1776,1799]
===
match
---
name: subdag_d [19423,19431]
name: subdag_d [19808,19816]
===
match
---
operator: = [32762,32763]
operator: = [33147,33148]
===
match
---
name: DagBag [3005,3011]
name: DagBag [3005,3011]
===
match
---
operator: = [34467,34468]
operator: = [34852,34853]
===
match
---
operator: , [32862,32863]
operator: , [33247,33248]
===
match
---
parameters [2363,2369]
parameters [2363,2369]
===
match
---
string: 'dags/test_zip.zip/test_zip.py' [10032,10063]
string: 'dags/test_zip.zip/test_zip.py' [10417,10448]
===
match
---
name: tempfile [948,956]
name: tempfile [948,956]
===
match
---
import_from [1639,1680]
import_from [1639,1680]
===
match
---
operator: @ [33769,33770]
operator: @ [34154,34155]
===
match
---
with_item [26760,26787]
with_item [27145,27172]
===
match
---
trailer [29776,29786]
trailer [30161,30171]
===
match
---
trailer [27451,27453]
trailer [27836,27838]
===
match
---
name: DAG [23777,23780]
name: DAG [24162,24165]
===
match
---
string: "airflow.models.serialized_dag.SerializedDagModel.write_dag" [28032,28092]
string: "airflow.models.serialized_dag.SerializedDagModel.write_dag" [28417,28477]
===
match
---
atom_expr [10993,11023]
atom_expr [11378,11408]
===
match
---
name: task_id [24509,24516]
name: task_id [24894,24901]
===
match
---
atom_expr [33522,33535]
atom_expr [33907,33920]
===
match
---
suite [1909,38342]
suite [1909,38727]
===
match
---
operator: , [19557,19558]
operator: , [19942,19943]
===
match
---
trailer [11757,11770]
trailer [12142,12155]
===
match
---
trailer [4879,4882]
trailer [5264,5267]
===
match
---
name: found_dags [22085,22095]
name: found_dags [22470,22480]
===
match
---
name: self [17092,17096]
name: self [17477,17481]
===
match
---
operator: == [7617,7619]
operator: == [8002,8004]
===
match
---
string: "test_with_non_default_owner" [37848,37877]
string: "test_with_non_default_owner" [38233,38262]
===
match
---
trailer [12244,12315]
trailer [12629,12700]
===
match
---
trailer [5354,5359]
trailer [5739,5744]
===
match
---
atom_expr [16718,16744]
atom_expr [17103,17129]
===
match
---
operator: = [36833,36834]
operator: = [37218,37219]
===
match
---
name: dag_id [12460,12466]
name: dag_id [12845,12851]
===
match
---
simple_stmt [1445,1492]
simple_stmt [1445,1492]
===
match
---
atom_expr [7562,7592]
atom_expr [7947,7977]
===
match
---
atom_expr [21942,21971]
atom_expr [22327,22356]
===
match
---
name: DagBag [14078,14084]
name: DagBag [14463,14469]
===
match
---
atom_expr [19754,19764]
atom_expr [20139,20149]
===
match
---
operator: { [4275,4276]
operator: { [4660,4661]
===
match
---
operator: = [8823,8824]
operator: = [9208,9209]
===
match
---
trailer [14182,14187]
trailer [14567,14572]
===
match
---
trailer [38264,38272]
trailer [38649,38657]
===
match
---
comparison [35660,35725]
comparison [36045,36110]
===
match
---
argument [25404,25425]
argument [25789,25810]
===
match
---
simple_stmt [17568,17648]
simple_stmt [17953,18033]
===
match
---
trailer [27921,27960]
trailer [28306,28345]
===
match
---
string: 'owner1' [5714,5722]
string: 'owner1' [6099,6107]
===
match
---
name: self [15314,15318]
name: self [15699,15703]
===
match
---
name: test_get_dag_fileloc [9379,9399]
name: test_get_dag_fileloc [9764,9784]
===
match
---
simple_stmt [4063,4181]
simple_stmt [4448,4566]
===
match
---
operator: , [26034,26035]
operator: , [26419,26420]
===
match
---
name: models [1206,1212]
name: models [1206,1212]
===
match
---
operator: , [35419,35420]
operator: , [35804,35805]
===
match
---
name: default_args [24076,24088]
name: default_args [24461,24473]
===
match
---
simple_stmt [31163,31326]
simple_stmt [31548,31711]
===
match
---
atom_expr [6215,6245]
atom_expr [6600,6630]
===
match
---
operator: += [35141,35143]
operator: += [35526,35528]
===
match
---
name: subdag_c [24009,24017]
name: subdag_c [24394,24402]
===
match
---
trailer [9657,9705]
trailer [10042,10090]
===
match
---
operator: = [3600,3601]
operator: = [3985,3986]
===
match
---
operator: = [36136,36137]
operator: = [36521,36522]
===
match
---
name: timezone [10710,10718]
name: timezone [11095,11103]
===
match
---
name: cluster_policy [36620,36634]
name: cluster_policy [37005,37019]
===
match
---
name: self [3777,3781]
name: self [4162,4166]
===
match
---
argument [3597,3615]
argument [3982,4000]
===
match
---
argument [19733,19745]
argument [20118,20130]
===
match
---
name: cluster_policies [36603,36619]
name: cluster_policies [36988,37004]
===
match
---
operator: , [14922,14923]
operator: , [15307,15308]
===
match
---
name: mock [30700,30704]
name: mock [31085,31089]
===
match
---
name: utils [1458,1463]
name: utils [1458,1463]
===
match
---
name: ser_dag_1_update_time [34601,34622]
name: ser_dag_1_update_time [34986,35007]
===
match
---
name: ser_dag_1_update_time [35773,35794]
name: ser_dag_1_update_time [36158,36179]
===
match
---
import_as_names [1206,1222]
import_as_names [1206,1222]
===
match
---
name: models [3300,3306]
name: models [3685,3691]
===
match
---
simple_stmt [23766,23847]
simple_stmt [24151,24232]
===
match
---
name: f [3995,3996]
name: f [4380,4381]
===
match
---
atom_expr [29681,29689]
atom_expr [30066,30074]
===
match
---
trailer [13302,13309]
trailer [13687,13694]
===
match
---
name: self [4217,4221]
name: self [4602,4606]
===
match
---
operator: = [19996,19997]
operator: = [20381,20382]
===
match
---
name: DummyOperator [21351,21364]
name: DummyOperator [21736,21749]
===
match
---
name: dags [32943,32947]
name: dags [33328,33332]
===
match
---
operator: , [10285,10286]
operator: , [10670,10671]
===
match
---
name: session [28930,28937]
name: session [29315,29322]
===
match
---
trailer [5540,5547]
trailer [5925,5932]
===
match
---
name: subdag [25340,25346]
name: subdag [25725,25731]
===
match
---
name: self [7954,7958]
name: self [8339,8343]
===
match
---
dotted_name [22288,22302]
dotted_name [22673,22687]
===
match
---
trailer [30317,30319]
trailer [30702,30704]
===
match
---
import_from [1604,1638]
import_from [1604,1638]
===
match
---
operator: , [16363,16364]
operator: , [16748,16749]
===
match
---
expr_stmt [27623,27785]
expr_stmt [28008,28170]
===
match
---
trailer [3962,3965]
trailer [4347,4350]
===
match
---
name: dagbag [37017,37023]
name: dagbag [37402,37408]
===
match
---
atom_expr [31101,31133]
atom_expr [31486,31518]
===
match
---
arglist [13100,13173]
arglist [13485,13558]
===
match
---
name: join [38090,38094]
name: join [38475,38479]
===
match
---
string: 'op_subdag_0' [25316,25329]
string: 'op_subdag_0' [25701,25714]
===
match
---
name: test_process_file_with_none [26117,26144]
name: test_process_file_with_none [26502,26529]
===
match
---
trailer [28693,28704]
trailer [29078,29089]
===
match
---
operator: == [5330,5332]
operator: == [5715,5717]
===
match
---
trailer [27182,27189]
trailer [27567,27574]
===
match
---
operator: = [16530,16531]
operator: = [16915,16916]
===
match
---
comparison [35741,35794]
comparison [36126,36179]
===
match
---
name: example_dags_folder [10533,10552]
name: example_dags_folder [10918,10937]
===
match
---
atom_expr [8169,8189]
atom_expr [8554,8574]
===
match
---
comparison [36452,36487]
comparison [36837,36872]
===
match
---
name: dag_id [11568,11574]
name: dag_id [11953,11959]
===
match
---
simple_stmt [21315,21365]
simple_stmt [21700,21750]
===
match
---
name: mock [30308,30312]
name: mock [30693,30697]
===
match
---
atom_expr [6112,6141]
atom_expr [6497,6526]
===
match
---
simple_stmt [29357,29400]
simple_stmt [29742,29785]
===
match
---
trailer [6554,6570]
trailer [6939,6955]
===
match
---
operator: = [16377,16378]
operator: = [16762,16763]
===
match
---
name: set_level [6853,6862]
name: set_level [7238,7247]
===
match
---
argument [12292,12314]
argument [12677,12699]
===
match
---
name: patch [30763,30768]
name: patch [31148,31153]
===
match
---
name: f [5121,5122]
name: f [5506,5507]
===
match
---
name: join [9666,9670]
name: join [10051,10055]
===
match
---
name: mock_dag [30670,30678]
name: mock_dag [31055,31063]
===
match
---
atom_expr [4605,4619]
atom_expr [4990,5004]
===
match
---
with_stmt [5929,6639]
with_stmt [6314,7024]
===
match
---
name: len [6475,6478]
name: len [6860,6863]
===
match
---
name: new_serialized_dags_count [27880,27905]
name: new_serialized_dags_count [28265,28290]
===
match
---
atom_expr [5243,5307]
atom_expr [5628,5692]
===
match
---
operator: , [34140,34141]
operator: , [34525,34526]
===
match
---
name: op_a [25571,25575]
name: op_a [25956,25960]
===
match
---
operator: = [3298,3299]
operator: = [3683,3684]
===
match
---
string: 'test_deactivate_unknown_dags' [27151,27181]
string: 'test_deactivate_unknown_dags' [27536,27566]
===
match
---
operator: == [11209,11211]
operator: == [11594,11596]
===
match
---
operator: = [34335,34336]
operator: = [34720,34721]
===
match
---
expr_stmt [28480,28583]
expr_stmt [28865,28968]
===
match
---
name: splitlines [13919,13929]
name: splitlines [14304,14314]
===
match
---
atom_expr [30660,30731]
atom_expr [31045,31116]
===
match
---
operator: = [16585,16586]
operator: = [16970,16971]
===
match
---
name: dagbag [26328,26334]
name: dagbag [26713,26719]
===
match
---
name: default_args [23833,23845]
name: default_args [24218,24230]
===
match
---
name: only_if_updated [8808,8823]
name: only_if_updated [9193,9208]
===
match
---
name: dag [24764,24767]
name: dag [25149,25152]
===
match
---
name: DummyOperator [19143,19156]
name: DummyOperator [19528,19541]
===
match
---
name: example_bash_op_dag [35201,35220]
name: example_bash_op_dag [35586,35605]
===
match
---
suite [33009,33126]
suite [33394,33511]
===
match
---
simple_stmt [6956,7029]
simple_stmt [7341,7414]
===
match
---
operator: , [5573,5574]
operator: , [5958,5959]
===
match
---
name: path [7612,7616]
name: path [7997,8001]
===
match
---
name: conf_vars [1807,1816]
name: conf_vars [1807,1816]
===
match
---
simple_stmt [29797,29837]
simple_stmt [30182,30222]
===
match
---
trailer [37758,37831]
trailer [38143,38216]
===
match
---
number: 2020 [34812,34816]
number: 2020 [35197,35201]
===
match
---
operator: , [37438,37439]
operator: , [37823,37824]
===
match
---
name: syspath_before [7353,7367]
name: syspath_before [7738,7752]
===
match
---
name: airflow [15532,15539]
name: airflow [15917,15924]
===
match
---
operator: = [16151,16152]
operator: = [16536,16537]
===
match
---
name: tags [35136,35140]
name: tags [35521,35525]
===
match
---
param [33891,33895]
param [34276,34280]
===
match
---
simple_stmt [6846,6877]
simple_stmt [7231,7262]
===
match
---
comparison [34539,34581]
comparison [34924,34966]
===
match
---
atom_expr [21619,21645]
atom_expr [22004,22030]
===
match
---
name: dag_maker [12815,12824]
name: dag_maker [13200,13209]
===
match
---
string: "example_bash_operator" [35619,35642]
string: "example_bash_operator" [36004,36027]
===
match
---
name: dags_hash [13657,13666]
name: dags_hash [14042,14051]
===
match
---
expr_stmt [11120,11190]
expr_stmt [11505,11575]
===
match
---
trailer [34222,34247]
trailer [34607,34632]
===
match
---
name: default_args [23820,23832]
name: default_args [24205,24217]
===
match
---
operator: , [35088,35089]
operator: , [35473,35474]
===
match
---
name: session [30020,30027]
name: session [30405,30412]
===
match
---
name: tf_1 [6154,6158]
name: tf_1 [6539,6543]
===
match
---
name: mock_dagmodel [11696,11709]
name: mock_dagmodel [12081,12094]
===
match
---
name: op_a [21662,21666]
name: op_a [22047,22051]
===
match
---
name: os [8112,8114]
name: os [8497,8499]
===
match
---
trailer [13445,13452]
trailer [13830,13837]
===
match
---
operator: } [33665,33666]
operator: } [34050,34051]
===
match
---
trailer [6518,6532]
trailer [6903,6917]
===
match
---
name: return_value [11850,11862]
name: return_value [12235,12247]
===
match
---
operator: } [13347,13348]
operator: } [13732,13733]
===
match
---
name: actual_found_dag_ids [14501,14521]
name: actual_found_dag_ids [14886,14906]
===
match
---
trailer [35681,35686]
trailer [36066,36071]
===
match
---
number: 0 [21866,21867]
number: 0 [22251,22252]
===
match
---
name: subdag_d [25214,25222]
name: subdag_d [25599,25607]
===
match
---
name: self [21020,21024]
name: self [21405,21409]
===
match
---
arglist [36848,36889]
arglist [37233,37274]
===
match
---
trailer [3996,4001]
trailer [4381,4386]
===
match
---
trailer [35511,35519]
trailer [35896,35904]
===
match
---
subscript [5916,5918]
subscript [6301,6303]
===
match
---
string: "test_zip.zip" [6932,6946]
string: "test_zip.zip" [7317,7331]
===
match
---
argument [5257,5282]
argument [5642,5667]
===
match
---
atom_expr [2511,2525]
atom_expr [2511,2525]
===
match
---
trailer [9665,9670]
trailer [10050,10055]
===
match
---
simple_stmt [34445,34520]
simple_stmt [34830,34905]
===
match
---
name: subdag_d [19253,19261]
name: subdag_d [19638,19646]
===
match
---
name: empty_dir [3028,3037]
name: empty_dir [3028,3037]
===
match
---
string: "test_missing_owner.py" [36866,36889]
string: "test_missing_owner.py" [37251,37274]
===
match
---
expr_stmt [29320,29348]
expr_stmt [29705,29733]
===
match
---
string: """ * Task must have non-None non-default owner. Current value: airflow""" [37235,37309]
string: """ * Task must have non-None non-default owner. Current value: airflow""" [37620,37694]
===
match
---
name: default_args [24461,24473]
name: default_args [24846,24858]
===
match
---
trailer [4821,4834]
trailer [5206,5219]
===
match
---
operator: , [22601,22602]
operator: , [22986,22987]
===
match
---
string: "airflow.models.dagbag.settings.MIN_SERIALIZED_DAG_UPDATE_INTERVAL" [30769,30836]
string: "airflow.models.dagbag.settings.MIN_SERIALIZED_DAG_UPDATE_INTERVAL" [31154,31221]
===
match
---
simple_stmt [20029,20099]
simple_stmt [20414,20484]
===
match
---
string: """         test if an invalid cron expression         as schedule interval can be identified         """ [7724,7829]
string: """         test if an invalid cron expression         as schedule interval can be identified         """ [8109,8214]
===
match
---
assert_stmt [12325,12362]
assert_stmt [12710,12747]
===
match
---
suite [12036,12215]
suite [12421,12600]
===
match
---
atom_expr [7195,7206]
atom_expr [7580,7591]
===
match
---
name: default_args [24680,24692]
name: default_args [25065,25077]
===
match
---
atom_expr [33330,33343]
atom_expr [33715,33728]
===
match
---
suite [2033,2071]
suite [2033,2071]
===
match
---
atom_expr [29329,29348]
atom_expr [29714,29733]
===
match
---
trailer [14180,14188]
trailer [14565,14573]
===
match
---
trailer [18919,18958]
trailer [19304,19343]
===
match
---
name: safe_mode [4775,4784]
name: safe_mode [5160,5169]
===
match
---
trailer [31100,31134]
trailer [31485,31519]
===
match
---
name: task_id [25171,25178]
name: task_id [25556,25563]
===
match
---
name: tags [35682,35686]
name: tags [36067,36071]
===
match
---
simple_stmt [37658,37734]
simple_stmt [38043,38119]
===
match
---
simple_stmt [26593,26633]
simple_stmt [26978,27018]
===
match
---
atom [13311,13347]
atom [13696,13732]
===
match
---
comparison [3943,4004]
comparison [4328,4389]
===
match
---
trailer [10527,10532]
trailer [10912,10917]
===
match
---
string: 'opSubdag_B' [24840,24852]
string: 'opSubdag_B' [25225,25237]
===
match
---
operator: = [2543,2544]
operator: = [2543,2544]
===
match
---
name: ANY [29547,29550]
name: ANY [29932,29935]
===
match
---
operator: = [3357,3358]
operator: = [3742,3743]
===
match
---
name: self [11982,11986]
name: self [12367,12371]
===
match
---
expr_stmt [29357,29399]
expr_stmt [29742,29784]
===
match
---
atom_expr [19866,19918]
atom_expr [20251,20303]
===
match
---
import_as_names [913,942]
import_as_names [913,942]
===
match
---
simple_stmt [7250,7345]
simple_stmt [7635,7730]
===
match
---
name: DummyOperator [23867,23880]
name: DummyOperator [24252,24265]
===
match
---
name: subdag [19657,19663]
name: subdag [20042,20048]
===
match
---
parameters [23499,23501]
parameters [23884,23886]
===
match
---
atom_expr [10140,10162]
atom_expr [10525,10547]
===
match
---
name: dagbag [20702,20708]
name: dagbag [21087,21093]
===
match
---
name: tf_2 [6112,6116]
name: tf_2 [6497,6501]
===
match
---
trailer [14548,14555]
trailer [14933,14940]
===
match
---
name: process_file_calls [8956,8974]
name: process_file_calls [9341,9359]
===
match
---
atom_expr [6475,6487]
atom_expr [6860,6872]
===
match
---
simple_stmt [26160,26224]
simple_stmt [26545,26609]
===
match
---
trailer [33570,33594]
trailer [33955,33979]
===
match
---
name: get_dag [34908,34915]
name: get_dag [35293,35300]
===
match
---
simple_stmt [1378,1445]
simple_stmt [1378,1445]
===
match
---
expr_stmt [11568,11591]
expr_stmt [11953,11976]
===
match
---
funcdef [24940,25262]
funcdef [25325,25647]
===
match
---
name: self [8792,8796]
name: self [9177,9181]
===
match
---
operator: = [28712,28713]
operator: = [29097,29098]
===
match
---
name: get_dag [13486,13493]
name: get_dag [13871,13878]
===
match
---
name: dag_bag [35504,35511]
name: dag_bag [35889,35896]
===
match
---
name: dag_name [15592,15600]
name: dag_name [15977,15985]
===
match
---
trailer [11334,11341]
trailer [11719,11726]
===
match
---
operator: , [22103,22104]
operator: , [22488,22489]
===
match
---
trailer [6003,6048]
trailer [6388,6433]
===
match
---
trailer [14100,14110]
trailer [14485,14495]
===
match
---
name: op_subdag_c_task [24287,24303]
name: op_subdag_c_task [24672,24688]
===
match
---
name: assert_not_called [31877,31894]
name: assert_not_called [32262,32279]
===
match
---
atom [2583,2635]
atom [2583,2635]
===
match
---
operator: { [33496,33497]
operator: { [33881,33882]
===
match
---
atom_expr [3381,3394]
atom_expr [3766,3779]
===
match
---
simple_stmt [27798,27818]
simple_stmt [28183,28203]
===
match
---
suite [19834,20135]
suite [20219,20520]
===
match
---
name: __path__ [10431,10439]
name: __path__ [10816,10824]
===
match
---
trailer [19620,19675]
trailer [20005,20060]
===
match
---
expr_stmt [19522,19585]
expr_stmt [19907,19970]
===
match
---
string: 'start_date' [21448,21460]
string: 'start_date' [21833,21845]
===
match
---
operator: , [30128,30129]
operator: , [30513,30514]
===
match
---
name: DAG [24648,24651]
name: DAG [25033,25036]
===
match
---
trailer [38004,38015]
trailer [38389,38400]
===
match
---
name: set_downstream [16815,16829]
name: set_downstream [17200,17214]
===
match
---
operator: = [19736,19737]
operator: = [20121,20122]
===
match
---
operator: , [10914,10915]
operator: , [11299,11300]
===
match
---
name: source_lines [6086,6098]
name: source_lines [6471,6483]
===
match
---
name: os [7499,7501]
name: os [7884,7886]
===
match
---
operator: = [24537,24538]
operator: = [24922,24923]
===
match
---
operator: , [36864,36865]
operator: , [37249,37250]
===
match
---
name: dag [25624,25627]
name: dag [26009,26012]
===
match
---
assert_stmt [26956,26985]
assert_stmt [27341,27370]
===
match
---
atom [30642,30746]
atom [31027,31131]
===
match
---
name: dagbag [9064,9070]
name: dagbag [9449,9455]
===
match
---
operator: == [21863,21865]
operator: == [22248,22250]
===
match
---
argument [19747,19764]
argument [20132,20149]
===
match
---
trailer [32046,32068]
trailer [32431,32453]
===
match
---
atom_expr [30120,30128]
atom_expr [30505,30513]
===
match
---
number: 0 [11950,11951]
number: 0 [12335,12336]
===
match
---
operator: = [29327,29328]
operator: = [29712,29713]
===
match
---
operator: , [19745,19746]
operator: , [20130,20131]
===
match
---
name: object [8266,8272]
name: object [8651,8657]
===
match
---
simple_stmt [8496,8529]
simple_stmt [8881,8914]
===
match
---
name: self [2094,2098]
name: self [2094,2098]
===
match
---
atom_expr [9658,9704]
atom_expr [10043,10089]
===
match
---
name: side_effect [29736,29747]
name: side_effect [30121,30132]
===
match
---
name: _sync_perm_for_dag [33085,33103]
name: _sync_perm_for_dag [33470,33488]
===
match
---
operator: = [31632,31633]
operator: = [32017,32018]
===
match
---
trailer [34343,34367]
trailer [34728,34752]
===
match
---
string: "example_bash_operator" [34495,34518]
string: "example_bash_operator" [34880,34903]
===
match
---
operator: = [20731,20732]
operator: = [21116,21117]
===
match
---
parameters [5622,5624]
parameters [6007,6009]
===
match
---
name: models [6965,6971]
name: models [7350,7356]
===
match
---
name: subdag [22411,22417]
name: subdag [22796,22802]
===
match
---
trailer [25492,25505]
trailer [25877,25890]
===
match
---
simple_stmt [12224,12316]
simple_stmt [12609,12701]
===
match
---
number: 1 [34644,34645]
number: 1 [35029,35030]
===
match
---
operator: , [30037,30038]
operator: , [30422,30423]
===
match
---
arglist [8273,8296]
arglist [8658,8681]
===
match
---
operator: , [3037,3038]
operator: , [3037,3038]
===
match
---
name: new_dagbag [36271,36281]
name: new_dagbag [36656,36666]
===
match
---
with_stmt [35052,35222]
with_stmt [35437,35607]
===
match
---
argument [26562,26583]
argument [26947,26968]
===
match
---
atom_expr [30138,30146]
atom_expr [30523,30531]
===
match
---
name: DAG [18822,18825]
name: DAG [19207,19210]
===
match
---
expr_stmt [4335,4397]
expr_stmt [4720,4782]
===
match
---
name: dag_id [9304,9310]
name: dag_id [9689,9695]
===
match
---
name: dagbag [27842,27848]
name: dagbag [28227,28233]
===
match
---
name: test_utils [1724,1734]
name: test_utils [1724,1734]
===
match
---
simple_stmt [16810,16843]
simple_stmt [17195,17228]
===
match
---
suite [20946,20990]
suite [21331,21375]
===
match
---
name: dag [16574,16577]
name: dag [16959,16962]
===
match
---
operator: , [8806,8807]
operator: , [9191,9192]
===
match
---
name: subdag_c [19048,19056]
name: subdag_c [19433,19441]
===
match
---
number: 4 [34830,34831]
number: 4 [35215,35216]
===
match
---
dotted_name [12756,12779]
dotted_name [13141,13164]
===
match
---
name: session [1511,1518]
name: session [1511,1518]
===
match
---
name: caplog [28169,28175]
name: caplog [28554,28560]
===
match
---
argument [19394,19417]
argument [19779,19802]
===
match
---
name: realpath [12264,12272]
name: realpath [12649,12657]
===
match
---
string: "Public" [33643,33651]
string: "Public" [34028,34036]
===
match
---
operator: = [9071,9072]
operator: = [9456,9457]
===
match
---
arglist [18589,18647]
arglist [18974,19032]
===
match
---
argument [29535,29550]
argument [29920,29935]
===
match
---
simple_stmt [24976,25046]
simple_stmt [25361,25431]
===
match
---
expr_stmt [11696,11735]
expr_stmt [12081,12120]
===
match
---
argument [11807,11826]
argument [12192,12211]
===
match
---
parameters [4047,4053]
parameters [4432,4438]
===
match
---
simple_stmt [17471,17523]
simple_stmt [17856,17908]
===
match
---
comparison [27989,28019]
comparison [28374,28404]
===
match
---
atom_expr [37924,37944]
atom_expr [38309,38329]
===
match
---
simple_stmt [35892,35947]
simple_stmt [36277,36332]
===
match
---
string: """         Test that we can refresh a packaged DAG         """ [11496,11559]
string: """         Test that we can refresh a packaged DAG         """ [11881,11944]
===
match
---
operator: = [16207,16208]
operator: = [16592,16593]
===
match
---
name: dag [20918,20921]
name: dag [21303,21306]
===
match
---
trailer [13553,13558]
trailer [13938,13943]
===
match
---
name: should_be_found [15065,15080]
name: should_be_found [15450,15465]
===
match
---
atom_expr [13547,13558]
atom_expr [13932,13943]
===
match
---
param [8335,8340]
param [8720,8725]
===
match
---
name: join [37677,37681]
name: join [38062,38066]
===
match
---
operator: = [31361,31362]
operator: = [31746,31747]
===
match
---
name: empty_dir [4222,4231]
name: empty_dir [4607,4616]
===
match
---
operator: , [14555,14556]
operator: , [14940,14941]
===
match
---
operator: == [36205,36207]
operator: == [36590,36592]
===
match
---
operator: = [12029,12030]
operator: = [12414,12415]
===
match
---
atom_expr [4658,4710]
atom_expr [5043,5095]
===
match
---
name: subdag_a [18574,18582]
name: subdag_a [18959,18967]
===
match
---
operator: = [32603,32604]
operator: = [32988,32989]
===
match
---
number: 1 [34133,34134]
number: 1 [34518,34519]
===
match
---
operator: { [21428,21429]
operator: { [21813,21814]
===
match
---
name: tzinfo [11807,11813]
name: tzinfo [12192,12198]
===
match
---
dictorsetmaker [15640,15702]
dictorsetmaker [16025,16087]
===
match
---
expr_stmt [9557,9629]
expr_stmt [9942,10014]
===
match
---
atom_expr [27632,27785]
atom_expr [28017,28170]
===
match
---
argument [26716,26729]
argument [27101,27114]
===
match
---
atom_expr [25987,26058]
atom_expr [26372,26443]
===
match
---
operator: = [12952,12953]
operator: = [13337,13338]
===
match
---
expr_stmt [3291,3364]
expr_stmt [3676,3749]
===
match
---
operator: , [20298,20299]
operator: , [20683,20684]
===
match
---
name: expected_dag_ids [14600,14616]
name: expected_dag_ids [14985,15001]
===
match
---
string: "test_zip_invalid_cron.zip" [7883,7910]
string: "test_zip_invalid_cron.zip" [8268,8295]
===
match
---
funcdef [15292,20990]
funcdef [15677,21375]
===
match
---
name: dag_name [17536,17544]
name: dag_name [17921,17929]
===
match
---
simple_stmt [26641,26683]
simple_stmt [27026,27068]
===
match
---
name: exceptions [1236,1246]
name: exceptions [1236,1246]
===
match
---
name: validate_dags [25992,26005]
name: validate_dags [26377,26390]
===
match
---
name: dag_id [27546,27552]
name: dag_id [27931,27937]
===
match
---
name: dag_id [10155,10161]
name: dag_id [10540,10546]
===
match
---
expr_stmt [34162,34247]
expr_stmt [34547,34632]
===
match
---
atom_expr [7431,7445]
atom_expr [7816,7830]
===
match
---
argument [20300,20307]
argument [20685,20692]
===
match
---
expr_stmt [7920,7993]
expr_stmt [8305,8378]
===
match
---
operator: = [5591,5592]
operator: = [5976,5977]
===
match
---
trailer [28850,28864]
trailer [29235,29249]
===
match
---
name: dagbag [17068,17074]
name: dagbag [17453,17459]
===
match
---
name: datetime [31104,31112]
name: datetime [31489,31497]
===
match
---
decorated [37401,37945]
decorated [37786,38330]
===
match
---
trailer [10653,10666]
trailer [11038,11051]
===
match
---
trailer [27131,27182]
trailer [27516,27567]
===
match
---
trailer [14483,14490]
trailer [14868,14875]
===
match
---
param [14385,14388]
param [14770,14773]
===
match
---
funcdef [23487,23713]
funcdef [23872,24098]
===
match
---
name: test_process_file_duplicated_dag_id [5370,5405]
name: test_process_file_duplicated_dag_id [5755,5790]
===
match
---
simple_stmt [10640,10724]
simple_stmt [11025,11109]
===
match
---
trailer [4667,4710]
trailer [5052,5095]
===
match
---
name: example_dags_folder [10388,10407]
name: example_dags_folder [10773,10792]
===
match
---
name: DagBag [36909,36915]
name: DagBag [37294,37300]
===
match
---
trailer [5877,5889]
trailer [6262,6274]
===
match
---
operator: = [13143,13144]
operator: = [13528,13529]
===
match
---
name: mock_serialize [28153,28167]
name: mock_serialize [28538,28552]
===
match
---
funcdef [27197,28020]
funcdef [27582,28405]
===
match
---
operator: , [13149,13150]
operator: , [13534,13535]
===
match
---
name: deactivate_unknown_dags [26849,26872]
name: deactivate_unknown_dags [27234,27257]
===
match
---
arglist [23881,23918]
arglist [24266,24303]
===
match
---
with_stmt [34847,34973]
with_stmt [35232,35358]
===
match
---
assert_stmt [13472,13513]
assert_stmt [13857,13898]
===
match
---
trailer [34218,34222]
trailer [34603,34607]
===
match
---
number: 0 [35418,35419]
number: 0 [35803,35804]
===
match
---
name: self [12568,12572]
name: self [12953,12957]
===
match
---
string: 'A' [16740,16743]
string: 'A' [17125,17128]
===
match
---
operator: >= [2829,2831]
operator: >= [2829,2831]
===
match
---
trailer [16199,16238]
trailer [16584,16623]
===
match
---
name: subdag_a [18542,18550]
name: subdag_a [18927,18935]
===
match
---
name: splitlines [5890,5900]
name: splitlines [6275,6285]
===
match
---
name: found_1 [6287,6294]
name: found_1 [6672,6679]
===
match
---
trailer [6971,6978]
trailer [7356,7363]
===
match
---
name: op_subdag_1 [20248,20259]
name: op_subdag_1 [20633,20644]
===
match
---
trailer [37885,37901]
trailer [38270,38286]
===
match
---
trailer [7942,7993]
trailer [8327,8378]
===
match
---
dotted_name [17414,17437]
dotted_name [17799,17822]
===
match
---
operator: = [4391,4392]
operator: = [4776,4777]
===
match
---
arglist [31113,31132]
arglist [31498,31517]
===
match
---
string: "airflow.models.dagbag.DagBag.collect_dags" [28961,29004]
string: "airflow.models.dagbag.DagBag.collect_dags" [29346,29389]
===
match
---
name: is_active [26976,26985]
name: is_active [27361,27370]
===
match
---
name: default_args [22616,22628]
name: default_args [23001,23013]
===
match
---
trailer [4698,4708]
trailer [5083,5093]
===
match
---
trailer [9644,9657]
trailer [10029,10042]
===
match
---
operator: = [25864,25865]
operator: = [26249,26250]
===
match
---
trailer [12343,12362]
trailer [12728,12747]
===
match
---
atom_expr [3741,3793]
atom_expr [4126,4178]
===
match
---
parameters [5405,5411]
parameters [5790,5796]
===
match
---
name: _TestDagBag [11896,11907]
name: _TestDagBag [12281,12292]
===
match
---
atom_expr [29930,30172]
atom_expr [30315,30557]
===
match
---
expr_stmt [12371,12399]
expr_stmt [12756,12784]
===
match
---
fstring_end: " [4920,4921]
fstring_end: " [5305,5306]
===
match
---
name: validate_dags [17221,17234]
name: validate_dags [17606,17619]
===
match
---
name: test_utils [1692,1702]
name: test_utils [1692,1702]
===
match
---
arglist [2500,2548]
arglist [2500,2548]
===
match
---
name: include_examples [3341,3357]
name: include_examples [3726,3742]
===
match
---
trailer [16642,16693]
trailer [17027,17078]
===
match
---
name: size [2822,2826]
name: size [2822,2826]
===
match
---
name: create_dag [5612,5622]
name: create_dag [5997,6007]
===
match
---
operator: , [34822,34823]
operator: , [35207,35208]
===
match
---
operator: , [31123,31124]
operator: , [31508,31509]
===
match
---
arglist [14378,14429]
arglist [14763,14814]
===
match
---
operator: @ [1992,1993]
operator: @ [1992,1993]
===
match
---
trailer [4750,4791]
trailer [5135,5176]
===
match
---
trailer [13929,13935]
trailer [14314,14320]
===
match
---
name: DummyOperator [17445,17458]
name: DummyOperator [17830,17843]
===
match
---
string: "test_invalid_cron.py" [7859,7881]
string: "test_invalid_cron.py" [8244,8266]
===
match
---
simple_stmt [7920,7994]
simple_stmt [8305,8379]
===
match
---
name: self [4480,4484]
name: self [4865,4869]
===
match
---
name: dagbag [3291,3297]
name: dagbag [3676,3682]
===
match
---
name: get_dag [35512,35519]
name: get_dag [35897,35904]
===
match
---
atom_expr [19664,19674]
atom_expr [20049,20059]
===
match
---
name: subdag [19747,19753]
name: subdag [20132,20138]
===
match
---
trailer [17011,17019]
trailer [17396,17404]
===
match
---
fstring [7092,7139]
fstring [7477,7524]
===
match
---
operator: = [24075,24076]
operator: = [24460,24461]
===
match
---
trailer [20005,20007]
trailer [20390,20392]
===
match
---
string: "has no tags" [38294,38307]
string: "has no tags" [38679,38692]
===
match
---
name: datetime [35072,35080]
name: datetime [35457,35465]
===
match
---
name: op_subdag_c_task [24110,24126]
name: op_subdag_c_task [24495,24511]
===
match
---
trailer [5563,5573]
trailer [5948,5958]
===
match
---
suite [2875,3175]
suite [2875,3175]
===
match
---
atom_expr [29557,29565]
atom_expr [29942,29950]
===
match
---
name: get_dag [7569,7576]
name: get_dag [7954,7961]
===
match
---
dictorsetmaker [13377,13397]
dictorsetmaker [13762,13782]
===
match
---
name: os [9658,9660]
name: os [10043,10045]
===
match
---
name: import_errors [28851,28864]
name: import_errors [29236,29249]
===
match
---
simple_stmt [37840,37902]
simple_stmt [38225,38287]
===
match
---
simple_stmt [18811,18886]
simple_stmt [19196,19271]
===
match
---
operator: = [5967,5968]
operator: = [6352,6353]
===
match
---
assert_stmt [6330,6363]
assert_stmt [6715,6748]
===
match
---
simple_stmt [11568,11592]
simple_stmt [11953,11977]
===
match
---
operator: = [10501,10502]
operator: = [10886,10887]
===
match
---
simple_stmt [16485,16501]
simple_stmt [16870,16886]
===
match
---
operator: , [22083,22084]
operator: , [22468,22469]
===
match
---
name: assert_called_once_with [33223,33246]
name: assert_called_once_with [33608,33631]
===
match
---
atom_expr [36544,36557]
atom_expr [36929,36942]
===
match
---
name: TEST_DAGS_FOLDER [31220,31236]
name: TEST_DAGS_FOLDER [31605,31621]
===
match
---
testlist_star_expr [25834,25863]
testlist_star_expr [26219,26248]
===
match
---
simple_stmt [28596,28630]
simple_stmt [28981,29015]
===
match
---
name: SubDagOperator [15564,15578]
name: SubDagOperator [15949,15963]
===
match
---
simple_stmt [36694,36816]
simple_stmt [37079,37201]
===
match
---
funcdef [2839,3175]
funcdef [2839,3175]
===
match
---
string: 'nested_cycle.op_subdag_0.opSubdag_B' [23781,23818]
string: 'nested_cycle.op_subdag_0.opSubdag_B' [24166,24203]
===
match
---
name: logging [6863,6870]
name: logging [7248,7255]
===
match
---
name: self [25866,25870]
name: self [26251,26255]
===
match
---
atom_expr [29772,29788]
atom_expr [30157,30173]
===
match
---
string: 'start_date' [17603,17615]
string: 'start_date' [17988,18000]
===
match
---
operator: = [11813,11814]
operator: = [12198,12199]
===
match
---
return_stmt [20119,20134]
return_stmt [20504,20519]
===
match
---
trailer [8612,8625]
trailer [8997,9010]
===
match
---
operator: = [20069,20070]
operator: = [20454,20455]
===
match
---
name: get_dag [12384,12391]
name: get_dag [12769,12776]
===
match
---
argument [2527,2548]
argument [2527,2548]
===
match
---
atom_expr [36909,36988]
atom_expr [37294,37373]
===
match
---
trailer [35080,35101]
trailer [35465,35486]
===
match
---
name: filepath [12177,12185]
name: filepath [12562,12570]
===
match
---
operator: = [13091,13092]
operator: = [13476,13477]
===
match
---
name: empty_dir [9596,9605]
name: empty_dir [9981,9990]
===
match
---
trailer [10694,10702]
trailer [11079,11087]
===
match
---
name: dags [26671,26675]
name: dags [27056,27060]
===
match
---
name: timezone [1477,1485]
name: timezone [1477,1485]
===
match
---
name: test_load_subdags [15296,15313]
name: test_load_subdags [15681,15698]
===
match
---
trailer [3833,3873]
trailer [4218,4258]
===
match
---
trailer [5249,5256]
trailer [5634,5641]
===
match
---
trailer [32483,32485]
trailer [32868,32870]
===
match
---
expr_stmt [19855,19918]
expr_stmt [20240,20303]
===
match
---
name: airflow [35914,35921]
name: airflow [36299,36306]
===
match
---
expr_stmt [10134,10162]
expr_stmt [10519,10547]
===
match
---
name: SubDagOperator [20166,20180]
name: SubDagOperator [20551,20565]
===
match
---
trailer [32453,32455]
trailer [32838,32840]
===
match
---
comparison [28603,28629]
comparison [28988,29014]
===
match
---
name: is_subdag [29417,29426]
name: is_subdag [29802,29811]
===
match
---
string: 'not ' [14916,14922]
string: 'not ' [15301,15307]
===
match
---
string: "test_example_bash_operator.py" [31238,31269]
string: "test_example_bash_operator.py" [31623,31654]
===
match
---
trailer [25451,25453]
trailer [25836,25838]
===
match
---
dictorsetmaker [22507,22569]
dictorsetmaker [22892,22954]
===
match
---
name: include_examples [37780,37796]
name: include_examples [38165,38181]
===
match
---
expr_stmt [28838,28870]
expr_stmt [29223,29255]
===
match
---
name: dagbag [28844,28850]
name: dagbag [29229,29235]
===
match
---
atom_expr [2042,2070]
atom_expr [2042,2070]
===
match
---
operator: , [17255,17256]
operator: , [17640,17641]
===
match
---
trailer [30004,30009]
trailer [30389,30394]
===
match
---
atom_expr [5985,6048]
atom_expr [6370,6433]
===
match
---
name: dag_name [21378,21386]
name: dag_name [21763,21771]
===
match
---
operator: , [32902,32903]
operator: , [33287,33288]
===
match
---
trailer [20180,20231]
trailer [20565,20616]
===
match
---
simple_stmt [11120,11191]
simple_stmt [11505,11576]
===
match
---
simple_stmt [22583,22630]
simple_stmt [22968,23015]
===
match
---
operator: = [28562,28563]
operator: = [28947,28948]
===
match
---
trailer [36100,36110]
trailer [36485,36495]
===
match
---
simple_stmt [25522,25555]
simple_stmt [25907,25940]
===
match
---
operator: , [32050,32051]
operator: , [32435,32436]
===
match
---
name: dagbag [26546,26552]
name: dagbag [26931,26937]
===
match
---
name: test_refresh_py_dag [10261,10280]
name: test_refresh_py_dag [10646,10665]
===
match
---
comparison [5327,5360]
comparison [5712,5745]
===
match
---
number: 5 [33762,33763]
number: 5 [34147,34148]
===
match
---
number: 5 [31122,31123]
number: 5 [31507,31508]
===
match
---
argument [24448,24473]
argument [24833,24858]
===
match
---
atom_expr [38311,38341]
atom_expr [38696,38726]
===
match
---
name: self [30900,30904]
name: self [31285,31289]
===
match
---
simple_stmt [8225,8254]
simple_stmt [8610,8639]
===
match
---
trailer [15681,15690]
trailer [16066,16075]
===
match
---
name: airflow [21320,21327]
name: airflow [21705,21712]
===
match
---
name: dagbag [11212,11218]
name: dagbag [11597,11603]
===
match
---
name: path [12259,12263]
name: path [12644,12648]
===
match
---
atom_expr [36452,36473]
atom_expr [36837,36858]
===
match
---
trailer [33467,33482]
trailer [33852,33867]
===
match
---
name: models [29388,29394]
name: models [29773,29779]
===
match
---
argument [20080,20097]
argument [20465,20482]
===
match
---
operator: , [5983,5984]
operator: , [6368,6369]
===
match
---
atom_expr [25347,25357]
atom_expr [25732,25742]
===
match
---
name: mock [29557,29561]
name: mock [29942,29946]
===
match
---
trailer [4743,4750]
trailer [5128,5135]
===
match
---
return_stmt [20490,20500]
return_stmt [20875,20885]
===
match
---
name: DAG [24020,24023]
name: DAG [24405,24408]
===
match
---
trailer [35390,35424]
trailer [35775,35809]
===
match
---
name: ERROR [28668,28673]
name: ERROR [29053,29058]
===
match
---
string: "airflow.settings.task_policy" [37408,37438]
string: "airflow.settings.task_policy" [37793,37823]
===
match
---
operator: , [20720,20721]
operator: , [21105,21106]
===
match
---
argument [25308,25329]
argument [25693,25714]
===
match
---
expr_stmt [8496,8528]
expr_stmt [8881,8913]
===
match
---
name: test_task_cluster_policy_violation [36644,36678]
name: test_task_cluster_policy_violation [37029,37063]
===
match
---
arglist [30010,30036]
arglist [30395,30421]
===
match
---
arith_expr [13312,13346]
arith_expr [13697,13731]
===
match
---
simple_stmt [5786,5813]
simple_stmt [6171,6198]
===
match
---
trailer [36066,36068]
trailer [36451,36453]
===
match
---
operator: , [29550,29551]
operator: , [29935,29936]
===
match
---
trailer [33185,33187]
trailer [33570,33572]
===
match
---
operator: = [3623,3624]
operator: = [4008,4009]
===
match
---
name: tags [34577,34581]
name: tags [34962,34966]
===
match
---
funcdef [18538,18758]
funcdef [18923,19143]
===
match
---
trailer [27638,27785]
trailer [28023,28170]
===
match
---
name: basename [4903,4911]
name: basename [5288,5296]
===
match
---
atom_expr [8092,8149]
atom_expr [8477,8534]
===
match
---
name: datetime [34118,34126]
name: datetime [34503,34511]
===
match
---
name: subdag_0 [16586,16594]
name: subdag_0 [16971,16979]
===
match
---
name: test_dag [20510,20518]
name: test_dag [20895,20903]
===
match
---
comp_op [9312,9318]
comp_op [9697,9703]
===
match
---
operator: , [4231,4232]
operator: , [4616,4617]
===
match
---
operator: { [15639,15640]
operator: { [16024,16025]
===
match
---
simple_stmt [11314,11342]
simple_stmt [11699,11727]
===
match
---
operator: , [34648,34649]
operator: , [35033,35034]
===
match
---
simple_stmt [25834,25904]
simple_stmt [26219,26289]
===
match
---
operator: @ [8259,8260]
operator: @ [8644,8645]
===
match
---
string: "test_dag_removed_if_serialized_dag_is_removed" [12845,12892]
string: "test_dag_removed_if_serialized_dag_is_removed" [13230,13277]
===
match
---
name: DAG [19866,19869]
name: DAG [20251,20254]
===
match
---
operator: = [24516,24517]
operator: = [24901,24902]
===
match
---
name: caplog [6672,6678]
name: caplog [7057,7063]
===
match
---
operator: = [11784,11785]
operator: = [12169,12170]
===
match
---
operator: , [9025,9026]
operator: , [9410,9411]
===
match
---
suite [27088,27192]
suite [27473,27577]
===
match
---
simple_stmt [36260,36287]
simple_stmt [36645,36672]
===
match
---
expr_stmt [34380,34432]
expr_stmt [34765,34817]
===
match
---
for_stmt [20914,20990]
for_stmt [21299,21375]
===
match
---
expr_stmt [11836,11880]
expr_stmt [12221,12265]
===
match
---
trailer [37930,37944]
trailer [38315,38329]
===
match
---
comparison [28741,28776]
comparison [29126,29161]
===
match
---
trailer [35463,35466]
trailer [35848,35851]
===
match
---
arglist [24024,24088]
arglist [24409,24473]
===
match
---
simple_stmt [19048,19123]
simple_stmt [19433,19508]
===
match
---
arglist [16643,16692]
arglist [17028,17077]
===
match
---
trailer [20228,20230]
trailer [20613,20615]
===
match
---
name: dag_file [37658,37666]
name: dag_file [38043,38051]
===
match
---
name: self [38056,38060]
name: self [38441,38445]
===
match
---
name: last_expired [11771,11783]
name: last_expired [12156,12168]
===
match
---
simple_stmt [21721,21746]
simple_stmt [22106,22131]
===
match
---
assert_stmt [2736,2758]
assert_stmt [2736,2758]
===
match
---
operator: , [16137,16138]
operator: , [16522,16523]
===
match
---
operator: = [25477,25478]
operator: = [25862,25863]
===
match
---
trailer [13975,13977]
trailer [14360,14362]
===
match
---
atom_expr [16186,16238]
atom_expr [16571,16623]
===
match
---
string: "airflow.models.dag.DAG.bulk_write_to_db" [29090,29131]
string: "airflow.models.dag.DAG.bulk_write_to_db" [29475,29516]
===
match
---
trailer [34114,34148]
trailer [34499,34533]
===
match
---
operator: = [25178,25179]
operator: = [25563,25564]
===
match
---
trailer [20737,20749]
trailer [21122,21134]
===
match
---
fstring_expr [4894,4920]
fstring_expr [5279,5305]
===
match
---
name: dag [36477,36480]
name: dag [36862,36865]
===
match
---
trailer [6852,6862]
trailer [7237,7247]
===
match
---
trailer [14017,14025]
trailer [14402,14410]
===
match
---
operator: , [25434,25435]
operator: , [25819,25820]
===
match
---
name: dagbag [8092,8098]
name: dagbag [8477,8483]
===
match
---
atom_expr [28805,28825]
atom_expr [29190,29210]
===
match
---
name: op_a [20395,20399]
name: op_a [20780,20784]
===
match
---
simple_stmt [9715,10075]
simple_stmt [10100,10460]
===
match
---
operator: , [15176,15177]
operator: , [15561,15562]
===
match
---
name: MagicMock [29373,29382]
name: MagicMock [29758,29767]
===
match
---
arglist [16200,16237]
arglist [16585,16622]
===
match
---
name: dag_name [22453,22461]
name: dag_name [22838,22846]
===
match
---
name: f [5353,5354]
name: f [5738,5739]
===
match
---
name: standard_subdag [17109,17124]
name: standard_subdag [17494,17509]
===
match
---
param [26145,26149]
param [26530,26534]
===
match
---
comparison [6265,6282]
comparison [6650,6667]
===
match
---
name: dagbag [26664,26670]
name: dagbag [27049,27055]
===
match
---
atom_expr [19059,19122]
atom_expr [19444,19507]
===
match
---
string: "airflow.models.dagbag.settings.MIN_SERIALIZED_DAG_FETCH_INTERVAL" [33776,33842]
string: "airflow.models.dagbag.settings.MIN_SERIALIZED_DAG_FETCH_INTERVAL" [34161,34227]
===
match
---
operator: = [25315,25316]
operator: = [25700,25701]
===
match
---
trailer [8175,8189]
trailer [8560,8574]
===
match
---
name: dagbag [38311,38317]
name: dagbag [38696,38702]
===
match
---
operator: , [20708,20709]
operator: , [21093,21094]
===
match
---
operator: = [32705,32706]
operator: = [33090,33091]
===
match
---
operator: = [7430,7431]
operator: = [7815,7816]
===
match
---
atom_expr [13889,13941]
atom_expr [14274,14326]
===
match
---
operator: , [37698,37699]
operator: , [38083,38084]
===
match
---
with_stmt [4577,4922]
with_stmt [4962,5307]
===
match
---
name: text [28772,28776]
name: text [29157,29161]
===
match
---
name: dag_id [11335,11341]
name: dag_id [11720,11726]
===
match
---
suite [35425,35644]
suite [35810,36029]
===
match
---
simple_stmt [37342,37396]
simple_stmt [37727,37781]
===
match
---
atom_expr [17003,17019]
atom_expr [17388,17404]
===
match
---
name: object [10221,10227]
name: object [10606,10612]
===
match
---
name: dagbag [13357,13363]
name: dagbag [13742,13748]
===
match
---
arglist [37957,38015]
arglist [38342,38400]
===
match
---
operator: , [19331,19332]
operator: , [19716,19717]
===
match
---
atom [37066,37333]
atom [37451,37718]
===
match
---
name: subdag_b [18811,18819]
name: subdag_b [19196,19204]
===
match
---
name: security_manager [32707,32723]
name: security_manager [33092,33108]
===
match
---
name: dagbag [21910,21916]
name: dagbag [22295,22301]
===
match
---
name: include_examples [12292,12308]
name: include_examples [12677,12693]
===
match
---
name: dagbag_stats [4428,4440]
name: dagbag_stats [4813,4825]
===
match
---
atom_expr [14161,14188]
atom_expr [14546,14573]
===
match
---
name: dummy [22349,22354]
name: dummy [22734,22739]
===
match
---
with_item [4582,4639]
with_item [4967,5024]
===
match
---
trailer [7051,7062]
trailer [7436,7447]
===
match
---
operator: , [24446,24447]
operator: , [24831,24832]
===
match
---
assert_stmt [20626,20659]
assert_stmt [21011,21044]
===
match
---
name: op_a [21612,21616]
name: op_a [21997,22001]
===
match
---
operator: = [24460,24461]
operator: = [24845,24846]
===
match
---
atom_expr [20087,20097]
atom_expr [20472,20482]
===
match
---
simple_stmt [6179,6192]
simple_stmt [6564,6577]
===
match
---
parameters [36678,36684]
parameters [37063,37069]
===
match
---
expr_stmt [22583,22629]
expr_stmt [22968,23014]
===
match
---
name: get_dag [11259,11266]
name: get_dag [11644,11651]
===
match
---
name: dagbag [14208,14214]
name: dagbag [14593,14599]
===
match
---
trailer [27189,27191]
trailer [27574,27576]
===
match
---
return_stmt [24568,24583]
return_stmt [24953,24968]
===
match
---
trailer [27804,27815]
trailer [28189,28200]
===
match
---
fstring_start: f' [14653,14655]
fstring_start: f' [15038,15040]
===
match
---
string: """         Helper method to process a file generated from the input create_dag function.         """ [13715,13816]
string: """         Helper method to process a file generated from the input create_dag function.         """ [14100,14201]
===
match
---
assert_stmt [25758,25791]
assert_stmt [26143,26176]
===
match
---
name: _TestDagBag [8944,8955]
name: _TestDagBag [9329,9340]
===
match
---
simple_stmt [24637,24707]
simple_stmt [25022,25092]
===
match
---
atom_expr [7608,7616]
atom_expr [7993,8001]
===
match
---
operator: == [6358,6360]
operator: == [6743,6745]
===
match
---
trailer [19536,19585]
trailer [19921,19970]
===
match
---
atom_expr [32469,32485]
atom_expr [32854,32870]
===
match
---
assert_stmt [9332,9369]
assert_stmt [9717,9754]
===
match
---
expr_stmt [29487,29566]
expr_stmt [29872,29951]
===
match
---
trailer [26680,26682]
trailer [27065,27067]
===
match
---
name: subdag_a [19664,19672]
name: subdag_a [20049,20057]
===
match
---
simple_stmt [34380,34433]
simple_stmt [34765,34818]
===
match
---
atom_expr [8194,8216]
atom_expr [8579,8601]
===
match
---
simple_stmt [26838,26895]
simple_stmt [27223,27280]
===
match
---
name: dagbag [6512,6518]
name: dagbag [6897,6903]
===
match
---
simple_stmt [21243,21259]
simple_stmt [21628,21644]
===
match
---
operator: = [14522,14523]
operator: = [14907,14908]
===
match
---
string: "test_example_bash_operator" [32948,32976]
string: "test_example_bash_operator" [33333,33361]
===
match
---
trailer [28659,28674]
trailer [29044,29059]
===
match
---
name: _sync_to_db [31974,31985]
name: _sync_to_db [32359,32370]
===
match
---
expr_stmt [36260,36286]
expr_stmt [36645,36671]
===
match
---
arglist [37408,37471]
arglist [37793,37856]
===
match
---
operator: , [35407,35408]
operator: , [35792,35793]
===
match
---
comparison [2815,2833]
comparison [2815,2833]
===
match
---
operator: = [3324,3325]
operator: = [3709,3710]
===
match
---
trailer [6239,6244]
trailer [6624,6629]
===
match
---
decorators [33686,33847]
decorators [34071,34232]
===
match
---
name: test_sync_to_db_is_retried [29141,29167]
name: test_sync_to_db_is_retried [29526,29552]
===
match
---
operator: , [9812,9813]
operator: , [10197,10198]
===
match
---
name: dagbag [37924,37930]
name: dagbag [38309,38315]
===
match
---
trailer [36022,36027]
trailer [36407,36412]
===
match
---
name: include_examples [2527,2543]
name: include_examples [2527,2543]
===
match
---
name: datetime [11786,11794]
name: datetime [12171,12179]
===
match
---
param [29218,29235]
param [29603,29620]
===
match
---
atom_expr [11252,11274]
atom_expr [11637,11659]
===
match
---
number: 1 [5916,5917]
number: 1 [6301,6302]
===
match
---
atom_expr [14402,14429]
atom_expr [14787,14814]
===
match
---
operator: == [34564,34566]
operator: == [34949,34951]
===
match
---
trailer [17096,17108]
trailer [17481,17493]
===
match
---
string: "SerializationError" [28890,28910]
string: "SerializationError" [29275,29295]
===
match
---
arglist [14865,14967]
arglist [15250,15352]
===
match
---
name: process_file [10865,10877]
name: process_file [11250,11262]
===
match
---
parameters [23985,23987]
parameters [24370,24372]
===
match
---
number: 12 [5843,5845]
number: 12 [6228,6230]
===
match
---
dotted_name [21320,21343]
dotted_name [21705,21728]
===
match
---
operator: = [29524,29525]
operator: = [29909,29910]
===
match
---
atom_expr [31688,31701]
atom_expr [32073,32086]
===
match
---
atom_expr [34900,34945]
atom_expr [35285,35330]
===
match
---
name: join [7507,7511]
name: join [7892,7896]
===
match
---
number: 7 [2832,2833]
number: 7 [2832,2833]
===
match
---
operator: , [14283,14284]
operator: , [14668,14669]
===
match
---
funcdef [16292,16501]
funcdef [16677,16886]
===
match
---
comparison [34601,34658]
comparison [34986,35043]
===
match
---
param [15314,15318]
param [15699,15703]
===
match
---
name: set [37882,37885]
name: set [38267,38270]
===
match
---
name: DagBag [3827,3833]
name: DagBag [4212,4218]
===
match
---
name: dag [21708,21711]
name: dag [22093,22096]
===
match
---
operator: = [11948,11949]
operator: = [12333,12334]
===
match
---
trailer [27509,27515]
trailer [27894,27900]
===
match
---
atom_expr [27437,27453]
atom_expr [27822,27838]
===
match
---
atom_expr [4194,4246]
atom_expr [4579,4631]
===
match
---
name: writelines [6075,6085]
name: writelines [6460,6470]
===
match
---
name: filepath [8883,8891]
name: filepath [9268,9276]
===
match
---
expr_stmt [7353,7388]
expr_stmt [7738,7773]
===
match
---
name: dagbag [2989,2995]
name: dagbag [2989,2995]
===
match
---
name: file_path [21930,21939]
name: file_path [22315,22324]
===
match
---
assert_stmt [6258,6317]
assert_stmt [6643,6702]
===
match
---
for_stmt [14586,15287]
for_stmt [14971,15672]
===
match
---
name: include_examples [3834,3850]
name: include_examples [4219,4235]
===
match
---
import_from [17471,17522]
import_from [17856,17907]
===
match
---
trailer [28704,28721]
trailer [29089,29106]
===
match
---
name: DAG [21299,21302]
name: DAG [21684,21687]
===
match
---
operator: = [30137,30138]
operator: = [30522,30523]
===
match
---
name: dag_folder [38166,38176]
name: dag_folder [38551,38561]
===
match
---
operator: = [36981,36982]
operator: = [37366,37367]
===
match
---
name: op_subdag_1 [25375,25386]
name: op_subdag_1 [25760,25771]
===
match
---
arglist [3834,3872]
arglist [4219,4257]
===
match
---
string: '' [13881,13883]
string: '' [14266,14268]
===
match
---
trailer [27140,27147]
trailer [27525,27532]
===
match
---
exprlist [10088,10100]
exprlist [10473,10485]
===
match
---
name: line [5838,5842]
name: line [6223,6227]
===
match
---
name: path [4898,4902]
name: path [5283,5287]
===
match
---
comparison [37004,37032]
comparison [37389,37417]
===
match
---
trailer [19953,20008]
trailer [20338,20393]
===
match
---
number: 0 [4445,4446]
number: 0 [4830,4831]
===
match
---
trailer [11368,11387]
trailer [11753,11772]
===
match
---
atom_expr [27060,27076]
atom_expr [27445,27461]
===
match
---
fstring_string: DAG policy violation (DAG ID: test_missing_owner, Path:  [37112,37168]
fstring_string: DAG policy violation (DAG ID: test_missing_owner, Path:  [37497,37553]
===
match
---
trailer [12258,12263]
trailer [12643,12648]
===
match
---
simple_stmt [25758,25792]
simple_stmt [26143,26177]
===
match
---
operator: , [9042,9043]
operator: , [9427,9428]
===
match
---
expr_stmt [21612,21645]
expr_stmt [21997,22030]
===
match
---
atom_expr [4737,4791]
atom_expr [5122,5176]
===
match
---
name: task_id [19954,19961]
name: task_id [20339,20346]
===
match
---
name: timezone [11814,11822]
name: timezone [12199,12207]
===
match
---
name: mock_dagmodel [8538,8551]
name: mock_dagmodel [8923,8936]
===
match
---
name: session [26780,26787]
name: session [27165,27172]
===
match
---
trailer [5900,5915]
trailer [6285,6300]
===
match
---
simple_stmt [22254,22270]
simple_stmt [22639,22655]
===
match
---
name: example_dags [1173,1185]
name: example_dags [1173,1185]
===
match
---
fstring [37108,37185]
fstring [37493,37570]
===
match
---
number: 1 [11027,11028]
number: 1 [11412,11413]
===
match
---
atom [5704,5723]
atom [6089,6108]
===
match
---
name: subdags [25778,25785]
name: subdags [26163,26170]
===
match
---
name: include_examples [11168,11184]
name: include_examples [11553,11569]
===
match
---
file_input [785,38342]
file_input [785,38727]
===
match
---
operator: = [24171,24172]
operator: = [24556,24557]
===
match
---
atom_expr [4811,4835]
atom_expr [5196,5220]
===
match
---
assert_stmt [36295,36336]
assert_stmt [36680,36721]
===
match
---
arglist [26255,26304]
arglist [26640,26689]
===
match
---
name: path [11630,11634]
name: path [12015,12019]
===
match
---
comparison [8165,8216]
comparison [8550,8601]
===
match
---
operator: = [28842,28843]
operator: = [29227,29228]
===
match
---
operator: , [33760,33761]
operator: , [34145,34146]
===
match
---
name: os [11627,11629]
name: os [12012,12014]
===
match
---
simple_stmt [9332,9370]
simple_stmt [9717,9755]
===
match
---
name: mock_session [29823,29835]
name: mock_session [30208,30220]
===
match
---
trailer [10118,10120]
trailer [10503,10505]
===
match
---
expr_stmt [22453,22478]
expr_stmt [22838,22863]
===
match
---
name: create_session [26760,26774]
name: create_session [27145,27159]
===
match
---
trailer [34872,34875]
trailer [35257,35260]
===
match
---
name: should_be_found [14762,14777]
name: should_be_found [15147,15162]
===
match
---
atom_expr [5353,5359]
atom_expr [5738,5744]
===
match
---
name: DAG [15449,15452]
name: DAG [15834,15837]
===
match
---
name: _TestDagBag [10993,11004]
name: _TestDagBag [11378,11389]
===
match
---
operator: , [19180,19181]
operator: , [19565,19566]
===
match
---
suite [18790,18995]
suite [19175,19380]
===
match
---
name: test_process_file_that_contains_multi_bytes_char [4931,4979]
name: test_process_file_that_contains_multi_bytes_char [5316,5364]
===
match
---
suite [19027,19232]
suite [19412,19617]
===
match
---
atom_expr [5838,5847]
atom_expr [6223,6232]
===
match
---
name: dag_folder [14085,14095]
name: dag_folder [14470,14480]
===
match
---
atom_expr [25522,25554]
atom_expr [25907,25939]
===
match
---
trailer [33533,33535]
trailer [33918,33920]
===
match
---
simple_stmt [36445,36488]
simple_stmt [36830,36873]
===
match
---
trailer [3387,3392]
trailer [3772,3777]
===
match
---
param [10884,10893]
param [11269,11278]
===
match
---
argument [24832,24852]
argument [25217,25237]
===
match
---
trailer [31513,31524]
trailer [31898,31909]
===
match
---
trailer [8575,8577]
trailer [8960,8962]
===
match
---
funcdef [4010,4447]
funcdef [4395,4832]
===
match
---
operator: , [14777,14778]
operator: , [15162,15163]
===
match
---
simple_stmt [16259,16275]
simple_stmt [16644,16660]
===
match
---
name: len [21841,21844]
name: len [22226,22229]
===
match
---
name: dagbag [4335,4341]
name: dagbag [4720,4726]
===
match
---
name: test_safe_mode_heuristic_mismatch [4014,4047]
name: test_safe_mode_heuristic_mismatch [4399,4432]
===
match
---
atom_expr [2171,2200]
atom_expr [2171,2200]
===
match
---
simple_stmt [2379,2469]
simple_stmt [2379,2469]
===
match
---
name: join [32807,32811]
name: join [33192,33196]
===
match
---
atom_expr [13592,13616]
atom_expr [13977,14001]
===
match
---
name: tz [1489,1491]
name: tz [1489,1491]
===
match
---
operator: = [21940,21941]
operator: = [22325,22326]
===
match
---
suite [23469,25604]
suite [23854,25989]
===
match
---
name: conf_vars [3741,3750]
name: conf_vars [4126,4135]
===
match
---
name: dag [5687,5690]
name: dag [6072,6075]
===
match
---
suite [26788,26829]
suite [27173,27214]
===
match
---
trailer [7935,7942]
trailer [8320,8327]
===
match
---
atom_expr [13312,13323]
atom_expr [13697,13708]
===
match
---
testlist_comp [29661,29689]
testlist_comp [30046,30074]
===
match
---
name: DagModel [8567,8575]
name: DagModel [8952,8960]
===
match
---
expr_stmt [13084,13174]
expr_stmt [13469,13559]
===
match
---
assert_stmt [5320,5360]
assert_stmt [5705,5745]
===
match
---
name: dag_id [11321,11327]
name: dag_id [11706,11712]
===
match
---
name: subdag [20309,20315]
name: subdag [20694,20700]
===
match
---
name: subdags [21854,21861]
name: subdags [22239,22246]
===
match
---
argument [16579,16596]
argument [16964,16981]
===
match
---
name: empty_dir [14101,14110]
name: empty_dir [14486,14495]
===
match
---
param [7709,7713]
param [8094,8098]
===
match
---
atom_expr [10732,10766]
atom_expr [11117,11151]
===
match
---
name: test_dag [25769,25777]
name: test_dag [26154,26162]
===
match
---
operator: = [5793,5794]
operator: = [6178,6179]
===
match
---
operator: , [18706,18707]
operator: , [19091,19092]
===
match
---
string: '\u3042' [5144,5152]
string: '\u3042' [5529,5537]
===
match
---
import_from [21315,21364]
import_from [21700,21749]
===
match
---
trailer [11798,11806]
trailer [12183,12191]
===
match
---
name: MagicMock [29777,29786]
name: MagicMock [30162,30171]
===
match
---
atom [33496,33508]
atom [33881,33893]
===
match
---
name: caplog [6846,6852]
name: caplog [7231,7237]
===
match
---
simple_stmt [8003,8041]
simple_stmt [8388,8426]
===
match
---
operator: == [6602,6604]
operator: == [6987,6989]
===
match
---
simple_stmt [22326,22376]
simple_stmt [22711,22761]
===
match
---
simple_stmt [22491,22571]
simple_stmt [22876,22956]
===
match
---
number: 1 [15700,15701]
number: 1 [16085,16086]
===
match
---
name: subdag_1 [19855,19863]
name: subdag_1 [20240,20248]
===
match
---
trailer [24651,24706]
trailer [25036,25091]
===
match
---
name: dagbag [3943,3949]
name: dagbag [4328,4334]
===
match
---
name: include_examples [7005,7021]
name: include_examples [7390,7406]
===
match
---
simple_stmt [28930,28949]
simple_stmt [29315,29334]
===
match
---
simple_stmt [15393,15409]
simple_stmt [15778,15794]
===
match
---
name: nested_subdags [17307,17321]
name: nested_subdags [17692,17706]
===
match
---
comparison [8866,8922]
comparison [9251,9307]
===
match
---
dictorsetmaker [35692,35724]
dictorsetmaker [36077,36109]
===
match
---
atom_expr [21841,21862]
atom_expr [22226,22247]
===
match
---
operator: = [8676,8677]
operator: = [9061,9062]
===
match
---
operator: , [32828,32829]
operator: , [33213,33214]
===
match
---
atom_expr [28603,28623]
atom_expr [28988,29008]
===
match
---
operator: = [5267,5268]
operator: = [5652,5653]
===
match
---
expr_stmt [24637,24706]
expr_stmt [25022,25091]
===
match
---
argument [4358,4380]
argument [4743,4765]
===
match
---
fstring_end: """ [37182,37185]
fstring_end: """ [37567,37570]
===
match
---
name: dag [24854,24857]
name: dag [25239,25242]
===
match
---
arglist [16343,16390]
arglist [16728,16775]
===
match
---
number: 0 [4880,4881]
number: 0 [5265,5266]
===
match
---
parameters [26144,26150]
parameters [26529,26535]
===
match
---
atom_expr [5534,5598]
atom_expr [5919,5983]
===
match
---
trailer [28667,28673]
trailer [29052,29058]
===
match
---
with_stmt [26755,26829]
with_stmt [27140,27214]
===
match
---
name: operators [17422,17431]
name: operators [17807,17816]
===
match
---
name: set_level [28650,28659]
name: set_level [29035,29044]
===
match
---
name: DagBag [4744,4750]
name: DagBag [5129,5135]
===
match
---
number: 2 [17024,17025]
number: 2 [17409,17410]
===
match
---
operator: = [36957,36958]
operator: = [37342,37343]
===
match
---
trailer [8098,8111]
trailer [8483,8496]
===
match
---
trailer [14003,14026]
trailer [14388,14411]
===
match
---
operator: = [21426,21427]
operator: = [21811,21812]
===
match
---
arglist [23781,23845]
arglist [24166,24230]
===
match
---
operator: , [11996,11997]
operator: , [12381,12382]
===
match
---
trailer [3965,3970]
trailer [4350,4355]
===
match
---
simple_stmt [29757,29789]
simple_stmt [30142,30174]
===
match
---
trailer [34576,34581]
trailer [34961,34966]
===
match
---
name: dags_last_fetched [35601,35618]
name: dags_last_fetched [35986,36003]
===
match
---
operator: == [10961,10963]
operator: == [11346,11348]
===
match
---
trailer [8551,8564]
trailer [8936,8949]
===
match
---
simple_stmt [2736,2759]
simple_stmt [2736,2759]
===
match
---
with_item [5934,5983]
with_item [6319,6368]
===
match
---
name: serialized_dags_count [27478,27499]
name: serialized_dags_count [27863,27884]
===
match
---
name: task_id [16643,16650]
name: task_id [17028,17035]
===
match
---
name: subdags [17012,17019]
name: subdags [17397,17404]
===
match
---
suite [36069,36116]
suite [36454,36501]
===
match
---
funcdef [24601,24923]
funcdef [24986,25308]
===
match
---
trailer [29685,29689]
trailer [30070,30074]
===
match
---
name: len [3894,3897]
name: len [4279,4282]
===
match
---
operator: = [20284,20285]
operator: = [20669,20670]
===
match
---
parameters [24613,24615]
parameters [24998,25000]
===
match
---
name: default_args [19559,19571]
name: default_args [19944,19956]
===
match
---
name: side_effect [32693,32704]
name: side_effect [33078,33089]
===
match
---
name: dagbag [7562,7568]
name: dagbag [7947,7953]
===
match
---
arglist [5257,5306]
arglist [5642,5691]
===
match
---
atom_expr [10682,10723]
atom_expr [11067,11108]
===
match
---
operator: = [16626,16627]
operator: = [17011,17012]
===
match
---
decorated [8259,9370]
decorated [8644,9755]
===
match
---
atom_expr [36082,36115]
atom_expr [36467,36500]
===
match
---
operator: { [37847,37848]
operator: { [38232,38233]
===
match
---
atom_expr [32605,32657]
atom_expr [32990,33042]
===
match
---
name: os [12256,12258]
name: os [12641,12643]
===
match
---
operator: = [23888,23889]
operator: = [24273,24274]
===
match
---
arglist [18683,18720]
arglist [19068,19105]
===
match
---
trailer [15264,15271]
trailer [15649,15656]
===
match
---
return_stmt [19786,19801]
return_stmt [20171,20186]
===
match
---
name: DagBag [34337,34343]
name: DagBag [34722,34728]
===
match
---
trailer [36842,36847]
trailer [37227,37232]
===
match
---
name: dag_id [13381,13387]
name: dag_id [13766,13772]
===
match
---
argument [36937,36963]
argument [37322,37348]
===
match
---
operator: , [9605,9606]
operator: , [9990,9991]
===
match
---
name: new_dags [36327,36335]
name: new_dags [36712,36720]
===
match
---
operator: = [22504,22505]
operator: = [22889,22890]
===
match
---
dotted_name [1165,1185]
dotted_name [1165,1185]
===
match
---
name: task_id [16547,16554]
name: task_id [16932,16939]
===
match
---
argument [19954,19974]
argument [20339,20359]
===
match
---
operator: = [26051,26052]
operator: = [26436,26437]
===
match
---
operator: = [26600,26601]
operator: = [26985,26986]
===
match
---
name: SerializedDagModel [1359,1377]
name: SerializedDagModel [1359,1377]
===
match
---
name: dag [19419,19422]
name: dag [19804,19807]
===
match
---
trailer [4427,4440]
trailer [4812,4825]
===
match
---
name: flush [6184,6189]
name: flush [6569,6574]
===
match
---
simple_stmt [21413,21493]
simple_stmt [21798,21878]
===
match
---
simple_stmt [11283,11306]
simple_stmt [11668,11691]
===
match
---
trailer [38331,38341]
trailer [38716,38726]
===
match
---
name: SerializedDagModel [13415,13433]
name: SerializedDagModel [13800,13818]
===
match
---
trailer [27679,27730]
trailer [28064,28115]
===
match
---
trailer [35186,35196]
trailer [35571,35581]
===
match
---
name: subdag_b [24875,24883]
name: subdag_b [25260,25268]
===
match
---
simple_stmt [9236,9274]
simple_stmt [9621,9659]
===
match
---
name: DagBag [7936,7942]
name: DagBag [8321,8327]
===
match
---
name: set_downstream [16766,16780]
name: set_downstream [17151,17165]
===
match
---
name: start_date [12942,12952]
name: start_date [13327,13337]
===
match
---
name: SerializedDAG [1431,1444]
name: SerializedDAG [1431,1444]
===
match
---
trailer [17634,17646]
trailer [18019,18031]
===
match
---
name: session [28713,28720]
name: session [29098,29105]
===
match
---
string: "test_dag_with_no_tags.py" [38113,38139]
string: "test_dag_with_no_tags.py" [38498,38524]
===
match
---
arglist [38166,38237]
arglist [38551,38622]
===
match
---
atom_expr [1961,1974]
atom_expr [1961,1974]
===
match
---
assert_stmt [27982,28019]
assert_stmt [28367,28404]
===
match
---
operator: = [25213,25214]
operator: = [25598,25599]
===
match
---
string: 'op_subdag_1' [20285,20298]
string: 'op_subdag_1' [20670,20683]
===
match
---
arglist [4358,4396]
arglist [4743,4781]
===
match
---
name: datetime [21471,21479]
name: datetime [21856,21864]
===
match
---
operator: { [37918,37919]
operator: { [38303,38304]
===
match
---
operator: , [982,983]
operator: , [982,983]
===
match
---
expr_stmt [35484,35544]
expr_stmt [35869,35929]
===
match
---
trailer [8868,8873]
trailer [9253,9258]
===
match
---
string: "airflow.models.dagbag.settings.MIN_SERIALIZED_DAG_UPDATE_INTERVAL" [33693,33760]
string: "airflow.models.dagbag.settings.MIN_SERIALIZED_DAG_UPDATE_INTERVAL" [34078,34145]
===
match
---
operator: = [21730,21731]
operator: = [22115,22116]
===
match
---
param [29174,29196]
param [29559,29581]
===
match
---
arglist [32788,32903]
arglist [33173,33288]
===
match
---
atom_expr [26555,26584]
atom_expr [26940,26969]
===
match
---
atom_expr [35379,35424]
atom_expr [35764,35809]
===
match
---
name: cls [2028,2031]
name: cls [2028,2031]
===
match
---
trailer [8242,8247]
trailer [8627,8632]
===
match
---
argument [24143,24166]
argument [24528,24551]
===
match
---
comparison [28797,28825]
comparison [29182,29210]
===
match
---
name: join [10528,10532]
name: join [10913,10917]
===
match
---
string: """         Test that errors serializing a DAG are recorded as import_errors in the DB         """ [28186,28284]
string: """         Test that errors serializing a DAG are recorded as import_errors in the DB         """ [28571,28669]
===
match
---
atom_expr [3601,3615]
atom_expr [3986,4000]
===
match
---
simple_stmt [13996,14027]
simple_stmt [14381,14412]
===
match
---
funcdef [37477,37945]
funcdef [37862,38330]
===
match
---
name: example_dags_folder [35971,35990]
name: example_dags_folder [36356,36375]
===
match
---
name: some_expected_dag_ids [2659,2680]
name: some_expected_dag_ids [2659,2680]
===
match
---
name: session [27457,27464]
name: session [27842,27849]
===
match
---
name: clear_db_runs [2147,2160]
name: clear_db_runs [2147,2160]
===
match
---
arglist [12177,12213]
arglist [12562,12598]
===
match
---
atom_expr [38254,38273]
atom_expr [38639,38658]
===
match
---
funcdef [23973,24341]
funcdef [24358,24726]
===
match
---
name: DagBag [26555,26561]
name: DagBag [26940,26946]
===
match
---
name: patch [29084,29089]
name: patch [29469,29474]
===
match
---
trailer [8013,8035]
trailer [8398,8420]
===
match
---
string: 'opSubdag_D' [25179,25191]
string: 'opSubdag_D' [25564,25576]
===
match
---
name: SubDagOperator [16532,16546]
name: SubDagOperator [16917,16931]
===
match
---
arglist [17235,17263]
arglist [17620,17648]
===
match
---
trailer [28405,28410]
trailer [28790,28795]
===
match
---
atom_expr [17617,17646]
atom_expr [18002,18031]
===
match
---
name: subdag_d [19285,19293]
name: subdag_d [19670,19678]
===
match
---
name: DummyOperator [12787,12800]
name: DummyOperator [13172,13185]
===
match
---
funcdef [7222,7662]
funcdef [7607,8047]
===
match
---
name: session [31598,31605]
name: session [31983,31990]
===
match
---
operator: = [10138,10139]
operator: = [10523,10524]
===
match
---
argument [24764,24776]
argument [25149,25161]
===
match
---
simple_stmt [2477,2550]
simple_stmt [2477,2550]
===
match
---
simple_stmt [18669,18722]
simple_stmt [19054,19107]
===
match
---
simple_stmt [32204,32414]
simple_stmt [32589,32799]
===
match
---
atom_expr [18906,18958]
atom_expr [19291,19343]
===
match
---
name: set_downstream [25527,25541]
name: set_downstream [25912,25926]
===
match
---
argument [17680,17705]
argument [18065,18090]
===
match
---
atom_expr [6901,6947]
atom_expr [7286,7332]
===
match
---
argument [25103,25115]
argument [25488,25500]
===
match
---
name: airflow [17371,17378]
name: airflow [17756,17763]
===
match
---
name: subdag_0 [24605,24613]
name: subdag_0 [24990,24998]
===
match
---
arglist [16117,16164]
arglist [16502,16549]
===
match
---
param [8792,8797]
param [9177,9182]
===
match
---
name: dag_file [37770,37778]
name: dag_file [38155,38163]
===
match
---
operator: = [7953,7954]
operator: = [8338,8339]
===
match
---
trailer [16814,16829]
trailer [17199,17214]
===
match
---
operator: = [13110,13111]
operator: = [13495,13496]
===
match
---
name: dagbag [3811,3817]
name: dagbag [4196,4202]
===
match
---
trailer [16731,16744]
trailer [17116,17129]
===
match
---
argument [13127,13149]
argument [13512,13534]
===
match
---
argument [2500,2525]
argument [2500,2525]
===
match
---
name: freeze_time [31089,31100]
name: freeze_time [31474,31485]
===
match
---
atom_expr [2056,2069]
atom_expr [2056,2069]
===
match
---
simple_stmt [1541,1604]
simple_stmt [1541,1604]
===
match
---
operator: , [10094,10095]
operator: , [10479,10480]
===
match
---
name: minutes [13336,13343]
name: minutes [13721,13728]
===
match
---
operator: , [31236,31237]
operator: , [31621,31622]
===
match
---
trailer [7498,7546]
trailer [7883,7931]
===
match
---
trailer [9122,9141]
trailer [9507,9526]
===
match
---
operator: , [34654,34655]
operator: , [35039,35040]
===
match
---
operator: , [35416,35417]
operator: , [35801,35802]
===
match
---
name: subdag [25207,25213]
name: subdag [25592,25598]
===
match
---
argument [28705,28720]
argument [29090,29105]
===
match
---
trailer [36466,36473]
trailer [36851,36858]
===
match
---
name: dag [20066,20069]
name: dag [20451,20454]
===
match
---
operator: = [31605,31606]
operator: = [31990,31991]
===
match
---
atom_expr [8165,8190]
atom_expr [8550,8575]
===
match
---
assert_stmt [6468,6492]
assert_stmt [6853,6877]
===
match
---
atom_expr [6337,6357]
atom_expr [6722,6742]
===
match
---
number: 1 [21486,21487]
number: 1 [21871,21872]
===
match
---
trailer [21632,21645]
trailer [22017,22030]
===
match
---
simple_stmt [22283,22314]
simple_stmt [22668,22699]
===
match
---
trailer [29951,29968]
trailer [30336,30353]
===
match
---
name: dag [18708,18711]
name: dag [19093,19096]
===
match
---
name: safe_mode [4382,4391]
name: safe_mode [4767,4776]
===
match
---
arglist [10533,10580]
arglist [10918,10965]
===
match
---
trailer [6431,6444]
trailer [6816,6829]
===
match
---
trailer [15690,15702]
trailer [16075,16087]
===
match
---
atom_expr [16628,16693]
atom_expr [17013,17078]
===
match
---
operator: , [1306,1307]
operator: , [1306,1307]
===
match
---
operator: , [6670,6671]
operator: , [7055,7056]
===
match
---
argument [5575,5597]
argument [5960,5982]
===
match
---
simple_stmt [36001,36028]
simple_stmt [36386,36413]
===
match
---
atom_expr [8567,8577]
atom_expr [8952,8962]
===
match
---
name: only_if_updated [11998,12013]
name: only_if_updated [12383,12398]
===
match
---
atom_expr [13529,13539]
atom_expr [13914,13924]
===
match
---
trailer [11626,11686]
trailer [12011,12071]
===
match
---
testlist_comp [30000,30148]
testlist_comp [30385,30533]
===
match
---
decorator [5686,5725]
decorator [6071,6110]
===
match
---
operator: = [13195,13196]
operator: = [13580,13581]
===
match
---
name: empty_dir [3782,3791]
name: empty_dir [4167,4176]
===
match
---
simple_stmt [16761,16794]
simple_stmt [17146,17179]
===
match
---
name: return_value [10654,10666]
name: return_value [11039,11051]
===
match
---
name: operators [17484,17493]
name: operators [17869,17878]
===
match
---
name: task_id [19394,19401]
name: task_id [19779,19786]
===
match
---
atom_expr [10520,10581]
atom_expr [10905,10966]
===
match
---
name: datetime [35394,35402]
name: datetime [35779,35787]
===
match
---
atom_expr [26963,26985]
atom_expr [27348,27370]
===
match
---
string: 'op_subdag_0' [16555,16568]
string: 'op_subdag_0' [16940,16953]
===
match
---
name: airflow [1383,1390]
name: airflow [1383,1390]
===
match
---
operator: = [25646,25647]
operator: = [26031,26032]
===
match
---
name: params [29535,29541]
name: params [29920,29926]
===
match
---
simple_stmt [6205,6246]
simple_stmt [6590,6631]
===
match
---
atom_expr [4217,4231]
atom_expr [4602,4616]
===
match
---
simple_stmt [3936,4005]
simple_stmt [4321,4390]
===
match
---
operator: = [23909,23910]
operator: = [24294,24295]
===
match
---
operator: = [19753,19754]
operator: = [20138,20139]
===
match
---
argument [26036,26057]
argument [26421,26442]
===
match
---
name: dag [32047,32050]
name: dag [32432,32435]
===
match
---
trailer [36249,36251]
trailer [36634,36636]
===
match
---
atom [22506,22570]
atom [22891,22955]
===
match
---
name: source_lines [5822,5834]
name: source_lines [6207,6219]
===
match
---
name: dagbag [6425,6431]
name: dagbag [6810,6816]
===
match
---
suite [23988,24341]
suite [24373,24726]
===
match
---
trailer [14532,14575]
trailer [14917,14960]
===
match
---
operator: , [19094,19095]
operator: , [19479,19480]
===
match
---
name: patch [10215,10220]
name: patch [10600,10605]
===
match
---
argument [16426,16449]
argument [16811,16834]
===
match
---
string: "example_bash_operator" [34408,34431]
string: "example_bash_operator" [34793,34816]
===
match
---
simple_stmt [18574,18649]
simple_stmt [18959,19034]
===
match
---
assert_stmt [27831,27866]
assert_stmt [28216,28251]
===
match
---
expr_stmt [20510,20537]
expr_stmt [20895,20922]
===
match
---
atom_expr [6846,6876]
atom_expr [7231,7261]
===
match
---
argument [24509,24532]
argument [24894,24917]
===
match
---
name: side_effect [29646,29657]
name: side_effect [30031,30042]
===
match
---
operator: , [14214,14215]
operator: , [14599,14600]
===
match
---
operator: , [30708,30709]
operator: , [31093,31094]
===
match
---
assert_stmt [3887,3923]
assert_stmt [4272,4308]
===
match
---
param [36679,36683]
param [37064,37068]
===
match
---
name: path [28865,28869]
name: path [29250,29254]
===
match
---
trailer [11612,11617]
trailer [11997,12002]
===
match
---
atom_expr [36323,36336]
atom_expr [36708,36721]
===
match
---
name: dag_file [36927,36935]
name: dag_file [37312,37320]
===
match
---
name: process_dag [21947,21958]
name: process_dag [22332,22343]
===
match
---
number: 12 [12975,12977]
number: 12 [13360,13362]
===
match
---
name: dag_maker [12574,12583]
name: dag_maker [12959,12968]
===
match
---
parameters [33890,33896]
parameters [34275,34281]
===
match
---
name: len [8194,8197]
name: len [8579,8582]
===
match
---
operator: { [17583,17584]
operator: { [17968,17969]
===
match
---
name: test_task_cluster_policy_obeyed [37481,37512]
name: test_task_cluster_policy_obeyed [37866,37897]
===
match
---
arglist [34812,34831]
arglist [35197,35216]
===
match
---
number: 0 [36208,36209]
number: 0 [36593,36594]
===
match
---
name: dagbag [13084,13090]
name: dagbag [13469,13475]
===
match
---
arglist [24832,24885]
arglist [25217,25270]
===
match
---
simple_stmt [992,1018]
simple_stmt [992,1018]
===
match
---
trailer [30628,30756]
trailer [31013,31141]
===
match
---
operator: , [38209,38210]
operator: , [38594,38595]
===
match
---
number: 0 [38277,38278]
number: 0 [38662,38663]
===
match
---
atom_expr [14440,14491]
atom_expr [14825,14876]
===
match
---
operator: = [11151,11152]
operator: = [11536,11537]
===
match
---
name: ser_dag_1 [34380,34389]
name: ser_dag_1 [34765,34774]
===
match
---
suite [10302,11388]
suite [10687,11773]
===
match
---
dotted_name [1383,1423]
dotted_name [1383,1423]
===
match
---
decorator [33769,33847]
decorator [34154,34232]
===
match
---
suite [9406,10209]
suite [9791,10594]
===
match
---
trailer [34288,34313]
trailer [34673,34698]
===
match
---
name: tz [35069,35071]
name: tz [35454,35456]
===
match
---
name: dag_file [37169,37177]
name: dag_file [37554,37562]
===
match
---
operator: = [25411,25412]
operator: = [25796,25797]
===
match
---
trailer [13433,13441]
trailer [13818,13826]
===
match
---
operator: = [28320,28321]
operator: = [28705,28706]
===
match
---
name: filepath [8798,8806]
name: filepath [9183,9191]
===
match
---
name: dagbag [31580,31586]
name: dagbag [31965,31971]
===
match
---
expr_stmt [6205,6245]
expr_stmt [6590,6630]
===
match
---
expr_stmt [34445,34519]
expr_stmt [34830,34904]
===
match
---
name: subdag_b [18986,18994]
name: subdag_b [19371,19379]
===
match
---
name: expected_active_dags [26873,26893]
name: expected_active_dags [27258,27278]
===
match
---
trailer [13485,13493]
trailer [13870,13878]
===
match
---
trailer [21958,21971]
trailer [22343,22356]
===
match
---
simple_stmt [35653,35726]
simple_stmt [36038,36111]
===
match
---
atom_expr [11725,11735]
atom_expr [12110,12120]
===
match
---
argument [16666,16673]
argument [17051,17058]
===
match
---
name: session [33109,33116]
name: session [33494,33501]
===
match
---
operator: , [23575,23576]
operator: , [23960,23961]
===
match
---
atom_expr [15082,15286]
atom_expr [15467,15671]
===
match
---
parameters [5748,5750]
parameters [6133,6135]
===
match
---
name: DagModel [27115,27123]
name: DagModel [27500,27508]
===
match
---
funcdef [8302,9370]
funcdef [8687,9755]
===
match
---
expr_stmt [27478,27563]
expr_stmt [27863,27948]
===
match
---
simple_stmt [31628,31676]
simple_stmt [32013,32061]
===
match
---
simple_stmt [34162,34248]
simple_stmt [34547,34633]
===
match
---
name: self [2511,2515]
name: self [2511,2515]
===
match
---
name: tz [31101,31103]
name: tz [31486,31488]
===
match
---
number: 1 [17644,17645]
number: 1 [18029,18030]
===
match
---
atom_expr [31057,31075]
atom_expr [31442,31460]
===
match
---
trailer [34213,34218]
trailer [34598,34603]
===
match
---
trailer [32806,32811]
trailer [33191,33196]
===
match
---
trailer [6978,7028]
trailer [7363,7413]
===
match
---
trailer [30009,30037]
trailer [30394,30422]
===
match
---
name: config [1793,1799]
name: config [1793,1799]
===
match
---
with_stmt [35438,35644]
with_stmt [35823,36029]
===
match
---
operator: = [25106,25107]
operator: = [25491,25492]
===
match
---
operator: , [34143,34144]
operator: , [34528,34529]
===
match
---
suite [4247,4447]
suite [4632,4832]
===
match
---
trailer [25526,25541]
trailer [25911,25926]
===
match
---
trailer [35943,35946]
trailer [36328,36331]
===
match
---
trailer [29382,29399]
trailer [29767,29784]
===
match
---
trailer [31736,31760]
trailer [32121,32145]
===
match
---
name: logging [28660,28667]
name: logging [29045,29052]
===
match
---
operator: = [10619,10620]
operator: = [11004,11005]
===
match
---
atom_expr [20856,20904]
atom_expr [21241,21289]
===
match
---
suite [31150,32069]
suite [31535,32454]
===
match
---
name: non_existing_dag_id [3146,3165]
name: non_existing_dag_id [3146,3165]
===
match
---
decorator [8259,8298]
decorator [8644,8683]
===
match
---
name: basename [3986,3994]
name: basename [4371,4379]
===
match
---
operator: = [32798,32799]
operator: = [33183,33184]
===
match
---
name: example_dags_folder [35892,35911]
name: example_dags_folder [36277,36296]
===
match
---
name: sync_to_db [31587,31597]
name: sync_to_db [31972,31982]
===
match
---
atom_expr [11152,11166]
atom_expr [11537,11551]
===
match
---
suite [33897,35795]
suite [34282,36180]
===
match
---
name: DAG [16113,16116]
name: DAG [16498,16501]
===
match
---
operator: = [21537,21538]
operator: = [21922,21923]
===
match
---
simple_stmt [21701,21712]
simple_stmt [22086,22097]
===
match
---
simple_stmt [23697,23713]
simple_stmt [24082,24098]
===
match
---
operator: @ [28954,28955]
operator: @ [29339,29340]
===
match
---
argument [4233,4245]
argument [4618,4630]
===
match
---
name: scalar [27961,27967]
name: scalar [28346,28352]
===
match
---
atom_expr [26918,26947]
atom_expr [27303,27332]
===
match
---
string: "example_bash_operator" [34916,34939]
string: "example_bash_operator" [35301,35324]
===
match
---
trailer [22060,22074]
trailer [22445,22459]
===
match
---
atom_expr [6445,6454]
atom_expr [6830,6839]
===
match
---
trailer [11822,11826]
trailer [12207,12211]
===
match
---
name: os [8866,8868]
name: os [9251,9253]
===
match
---
trailer [22548,22557]
trailer [22933,22942]
===
match
---
operator: , [12969,12970]
operator: , [13354,13355]
===
match
---
simple_stmt [1604,1639]
simple_stmt [1604,1639]
===
match
---
testlist_comp [30308,30332]
testlist_comp [30693,30717]
===
match
---
atom_expr [24785,24795]
atom_expr [25170,25180]
===
match
---
name: datetime [17344,17352]
name: datetime [17729,17737]
===
match
---
trailer [17669,17706]
trailer [18054,18091]
===
match
---
trailer [38089,38094]
trailer [38474,38479]
===
match
---
string: "example_bash_operator" [35520,35543]
string: "example_bash_operator" [35905,35928]
===
match
---
name: mock_dag [29357,29365]
name: mock_dag [29742,29750]
===
match
---
comparison [14714,14744]
comparison [15099,15129]
===
match
---
simple_stmt [24255,24305]
simple_stmt [24640,24690]
===
match
---
return_stmt [25617,25627]
return_stmt [26002,26012]
===
match
---
operator: = [4735,4736]
operator: = [5120,5121]
===
match
---
simple_stmt [33548,33681]
simple_stmt [33933,34066]
===
match
---
trailer [35402,35423]
trailer [35787,35808]
===
match
---
trailer [2499,2549]
trailer [2499,2549]
===
match
---
trailer [36059,36066]
trailer [36444,36451]
===
match
---
operator: = [22120,22121]
operator: = [22505,22506]
===
match
---
trailer [20043,20098]
trailer [20428,20483]
===
match
---
atom_expr [2249,2267]
atom_expr [2249,2267]
===
match
---
operator: , [20307,20308]
operator: , [20692,20693]
===
match
---
name: realpath [10511,10519]
name: realpath [10896,10904]
===
match
---
atom_expr [14071,14135]
atom_expr [14456,14520]
===
match
---
suite [35103,35222]
suite [35488,35607]
===
match
---
atom_expr [16586,16596]
atom_expr [16971,16981]
===
match
---
trailer [32558,32567]
trailer [32943,32952]
===
match
---
string: 'owner' [5705,5712]
string: 'owner' [6090,6097]
===
match
---
argument [19559,19584]
argument [19944,19969]
===
match
---
param [28169,28175]
param [28554,28560]
===
match
---
suite [8846,9055]
suite [9231,9440]
===
match
---
parameters [16078,16080]
parameters [16463,16465]
===
match
---
trailer [16594,16596]
trailer [16979,16981]
===
match
---
atom_expr [24129,24181]
atom_expr [24514,24566]
===
match
---
simple_stmt [29487,29567]
simple_stmt [29872,29952]
===
match
---
argument [4601,4619]
argument [4986,5004]
===
match
---
number: 2 [11357,11358]
number: 2 [11742,11743]
===
match
---
name: operators [15540,15549]
name: operators [15925,15934]
===
match
---
argument [6023,6038]
argument [6408,6423]
===
match
---
trailer [3897,3918]
trailer [4282,4303]
===
match
---
name: ANY [30015,30018]
name: ANY [30400,30403]
===
match
---
with_stmt [18511,20477]
with_stmt [18896,20862]
===
match
---
name: DagBag [38159,38165]
name: DagBag [38544,38550]
===
match
---
atom_expr [16761,16793]
atom_expr [17146,17178]
===
match
---
atom_expr [26707,26746]
atom_expr [27092,27131]
===
match
---
name: found_dags [14216,14226]
name: found_dags [14601,14611]
===
match
---
operator: , [24866,24867]
operator: , [25251,25252]
===
match
---
arglist [9580,9628]
arglist [9965,10013]
===
match
---
funcdef [10861,11111]
funcdef [11246,11496]
===
match
---
simple_stmt [19453,19469]
simple_stmt [19838,19854]
===
match
---
operator: , [30731,30732]
operator: , [31116,31117]
===
match
---
with_stmt [27055,27192]
with_stmt [27440,27577]
===
match
---
trailer [10505,10510]
trailer [10890,10895]
===
match
---
suite [38062,38342]
suite [38447,38727]
===
match
---
atom_expr [8010,8035]
atom_expr [8395,8420]
===
match
---
trailer [9001,9003]
trailer [9386,9388]
===
match
---
operator: , [33107,33108]
operator: , [33492,33493]
===
match
---
simple_stmt [34594,34659]
simple_stmt [34979,35044]
===
match
---
operator: = [31055,31056]
operator: = [31440,31441]
===
match
---
number: 1 [21489,21490]
number: 1 [21874,21875]
===
match
---
simple_stmt [26407,26538]
simple_stmt [26792,26923]
===
match
---
simple_stmt [36900,36989]
simple_stmt [37285,37374]
===
match
---
name: subdag_b [23910,23918]
name: subdag_b [24295,24303]
===
match
---
funcdef [11965,12215]
funcdef [12350,12600]
===
match
---
name: dag_id [14549,14555]
name: dag_id [14934,14940]
===
match
---
comparison [9339,9369]
comparison [9724,9754]
===
match
---
operator: == [17021,17023]
operator: == [17406,17408]
===
match
---
dictorsetmaker [37080,37323]
dictorsetmaker [37465,37708]
===
match
---
atom_expr [36188,36203]
atom_expr [36573,36588]
===
match
---
operator: -> [2100,2102]
operator: -> [2100,2102]
===
match
---
operator: = [29467,29468]
operator: = [29852,29853]
===
match
---
name: nested_subdag_cycle [25648,25667]
name: nested_subdag_cycle [26033,26052]
===
match
---
simple_stmt [8739,8762]
simple_stmt [9124,9147]
===
match
---
simple_stmt [3811,3874]
simple_stmt [4196,4259]
===
match
---
trailer [36480,36487]
trailer [36865,36872]
===
match
---
trailer [37016,37032]
trailer [37401,37417]
===
match
---
funcdef [4927,5361]
funcdef [5312,5746]
===
match
---
name: models [1286,1292]
name: models [1286,1292]
===
match
---
argument [22105,22126]
argument [22490,22511]
===
match
---
name: os [3978,3980]
name: os [4363,4365]
===
match
---
atom_expr [6590,6601]
atom_expr [6975,6986]
===
match
---
simple_stmt [17366,17397]
simple_stmt [17751,17782]
===
match
---
name: info [14648,14652]
name: info [15033,15037]
===
match
---
trailer [26347,26353]
trailer [26732,26738]
===
match
---
trailer [11057,11059]
trailer [11442,11444]
===
match
---
name: NamedTemporaryFile [5097,5115]
name: NamedTemporaryFile [5482,5500]
===
match
---
trailer [13656,13666]
trailer [14041,14051]
===
match
---
name: dagbag [11362,11368]
name: dagbag [11747,11753]
===
match
---
name: datetime [22549,22557]
name: datetime [22934,22942]
===
match
---
parameters [19831,19833]
parameters [20216,20218]
===
match
---
name: dag [13574,13577]
name: dag [13959,13962]
===
match
---
atom_expr [3649,3670]
atom_expr [4034,4055]
===
match
---
simple_stmt [10134,10163]
simple_stmt [10519,10548]
===
match
---
atom_expr [10503,10582]
atom_expr [10888,10967]
===
match
---
arglist [11640,11684]
arglist [12025,12069]
===
match
---
operator: , [25017,25018]
operator: , [25402,25403]
===
match
---
trailer [19393,19432]
trailer [19778,19817]
===
match
---
name: fileloc [10759,10766]
name: fileloc [11144,11151]
===
match
---
name: setup_methods [2080,2093]
name: setup_methods [2080,2093]
===
match
---
comparison [20966,20989]
comparison [21351,21374]
===
match
---
trailer [36510,36536]
trailer [36895,36921]
===
match
---
operator: = [32934,32935]
operator: = [33319,33320]
===
match
---
parameters [22238,22240]
parameters [22623,22625]
===
match
---
trailer [12163,12176]
trailer [12548,12561]
===
match
---
name: dagbag [9344,9350]
name: dagbag [9729,9735]
===
match
---
atom_expr [36271,36286]
atom_expr [36656,36671]
===
match
---
trailer [38317,38331]
trailer [38702,38716]
===
match
---
operator: == [8893,8895]
operator: == [9278,9280]
===
match
---
name: default_args [5691,5703]
name: default_args [6076,6088]
===
match
---
number: 0 [6295,6296]
number: 0 [6680,6681]
===
match
---
simple_stmt [15716,15763]
simple_stmt [16101,16148]
===
match
---
string: 'core' [4277,4283]
string: 'core' [4662,4668]
===
match
---
dictorsetmaker [33643,33665]
dictorsetmaker [34028,34050]
===
match
---
comparison [6337,6363]
comparison [6722,6748]
===
match
---
name: serialized_objects [1405,1423]
name: serialized_objects [1405,1423]
===
match
---
expr_stmt [6956,7028]
expr_stmt [7341,7413]
===
match
---
name: call [30665,30669]
name: call [31050,31054]
===
match
---
trailer [3690,3700]
trailer [4075,4085]
===
match
---
name: dag [21505,21508]
name: dag [21890,21893]
===
match
---
operator: == [8191,8193]
operator: == [8576,8578]
===
match
---
atom [4276,4299]
atom [4661,4684]
===
match
---
name: caplog [28765,28771]
name: caplog [29150,29156]
===
match
---
simple_stmt [6258,6318]
simple_stmt [6643,6703]
===
match
---
assert_stmt [12475,12512]
assert_stmt [12860,12897]
===
match
---
simple_stmt [3455,3565]
simple_stmt [3840,3950]
===
match
---
decorated [32074,33681]
decorated [32459,34066]
===
match
---
atom_expr [14524,14576]
atom_expr [14909,14961]
===
match
---
atom_expr [15722,15762]
atom_expr [16107,16147]
===
match
---
name: include_examples [36965,36981]
name: include_examples [37350,37366]
===
match
---
name: task_id [24832,24839]
name: task_id [25217,25224]
===
match
---
name: task_id [20366,20373]
name: task_id [20751,20758]
===
match
---
param [8830,8844]
param [9215,9229]
===
match
---
trailer [4609,4619]
trailer [4994,5004]
===
match
---
operator: - [13324,13325]
operator: - [13709,13710]
===
match
---
atom [37090,37323]
atom [37475,37708]
===
match
---
name: process_file [11060,11072]
name: process_file [11445,11457]
===
match
---
arglist [24143,24180]
arglist [24528,24565]
===
match
---
parameters [18787,18789]
parameters [19172,19174]
===
match
---
argument [20309,20326]
argument [20694,20711]
===
match
---
name: assert_has_calls [29952,29968]
name: assert_has_calls [30337,30353]
===
match
---
expr_stmt [18574,18648]
expr_stmt [18959,19033]
===
match
---
trailer [4913,4918]
trailer [5298,5303]
===
match
---
testlist [14208,14234]
testlist [14593,14619]
===
match
---
string: """DAGs are collected from Database""" [35845,35883]
string: """DAGs are collected from Database""" [36230,36268]
===
match
---
name: ANY [30088,30091]
name: ANY [30473,30476]
===
match
---
arglist [32812,32861]
arglist [33197,33246]
===
match
---
name: import_errors [28610,28623]
name: import_errors [28995,29008]
===
match
---
param [4480,4484]
param [4865,4869]
===
match
---
trailer [24793,24795]
trailer [25178,25180]
===
match
---
name: TEST_DAGS_FOLDER [32812,32828]
name: TEST_DAGS_FOLDER [33197,33213]
===
match
---
operator: , [24762,24763]
operator: , [25147,25148]
===
match
---
atom_expr [28403,28466]
atom_expr [28788,28851]
===
match
---
name: ser_dag_1_update_time [34445,34466]
name: ser_dag_1_update_time [34830,34851]
===
match
---
operator: = [15637,15638]
operator: = [16022,16023]
===
match
---
simple_stmt [8996,9055]
simple_stmt [9381,9440]
===
match
---
simple_stmt [1223,1273]
simple_stmt [1223,1273]
===
match
---
operator: { [37066,37067]
operator: { [37451,37452]
===
match
---
operator: = [22462,22463]
operator: = [22847,22848]
===
match
---
trailer [20645,20653]
trailer [21030,21038]
===
match
---
simple_stmt [7071,7217]
simple_stmt [7456,7602]
===
match
---
suite [18553,18758]
suite [18938,19143]
===
match
---
simple_stmt [27831,27867]
simple_stmt [28216,28252]
===
match
---
simple_stmt [14201,14235]
simple_stmt [14586,14620]
===
match
---
operator: = [38157,38158]
operator: = [38542,38543]
===
match
---
funcdef [2338,2834]
funcdef [2338,2834]
===
match
---
operator: } [4919,4920]
operator: } [5304,5305]
===
match
---
name: DAG [18585,18588]
name: DAG [18970,18973]
===
match
---
simple_stmt [8641,8684]
simple_stmt [9026,9069]
===
match
---
fstring_expr [3977,4003]
fstring_expr [4362,4388]
===
match
---
name: _sync_to_db [31460,31471]
name: _sync_to_db [31845,31856]
===
match
---
trailer [9016,9054]
trailer [9401,9439]
===
match
---
trailer [16690,16692]
trailer [17075,17077]
===
match
---
name: default_args [22603,22615]
name: default_args [22988,23000]
===
match
---
simple_stmt [29930,30173]
simple_stmt [30315,30558]
===
match
---
trailer [2492,2499]
trailer [2492,2499]
===
match
---
suite [21026,26108]
suite [21411,26493]
===
match
---
name: empty_dir [26271,26280]
name: empty_dir [26656,26665]
===
match
---
simple_stmt [33356,33399]
simple_stmt [33741,33784]
===
match
---
funcdef [5608,5813]
funcdef [5993,6198]
===
match
---
trailer [27074,27076]
trailer [27459,27461]
===
match
---
name: ApplessAirflowSecurityManager [1574,1603]
name: ApplessAirflowSecurityManager [1574,1603]
===
match
---
trailer [11258,11266]
trailer [11643,11651]
===
match
---
comparison [27583,27609]
comparison [27968,27994]
===
match
---
simple_stmt [29408,29435]
simple_stmt [29793,29820]
===
match
---
atom_expr [34626,34658]
atom_expr [35011,35043]
===
match
---
name: dag [33104,33107]
name: dag [33489,33492]
===
match
---
trailer [14040,14046]
trailer [14425,14431]
===
match
---
atom_expr [4912,4918]
atom_expr [5297,5303]
===
match
---
name: clear_db_serialized_dags [2306,2330]
name: clear_db_serialized_dags [2306,2330]
===
match
---
operator: = [27666,27667]
operator: = [28051,28052]
===
match
---
trailer [18825,18885]
trailer [19210,19270]
===
match
---
name: tests [1609,1614]
name: tests [1609,1614]
===
match
---
operator: , [11656,11657]
operator: , [12041,12042]
===
match
---
operator: , [30319,30320]
operator: , [30704,30705]
===
match
---
trailer [4600,4634]
trailer [4985,5019]
===
match
---
argument [4751,4773]
argument [5136,5158]
===
match
---
expr_stmt [37658,37733]
expr_stmt [38043,38118]
===
match
---
simple_stmt [29700,29748]
simple_stmt [30085,30133]
===
match
---
simple_stmt [6330,6364]
simple_stmt [6715,6749]
===
match
---
assert_stmt [11350,11387]
assert_stmt [11735,11772]
===
match
---
arglist [19300,19358]
arglist [19685,19743]
===
match
---
name: path [38085,38089]
name: path [38470,38474]
===
match
---
expr_stmt [10493,10582]
expr_stmt [10878,10967]
===
match
---
param [13694,13704]
param [14079,14089]
===
match
---
dotted_name [1497,1518]
dotted_name [1497,1518]
===
match
---
trailer [24142,24181]
trailer [24527,24566]
===
match
---
name: f [5211,5212]
name: f [5596,5597]
===
match
---
name: teardown_class [2013,2027]
name: teardown_class [2013,2027]
===
match
---
name: subdag_d [24575,24583]
name: subdag_d [24960,24968]
===
match
---
suite [2681,2799]
suite [2681,2799]
===
match
---
string: 'parent.op_subdag_0.opSubdag_B' [18826,18857]
string: 'parent.op_subdag_0.opSubdag_B' [19211,19242]
===
match
---
name: dag_maker [13050,13059]
name: dag_maker [13435,13444]
===
match
---
trailer [3980,3985]
trailer [4365,4370]
===
match
---
name: DAG [19533,19536]
name: DAG [19918,19921]
===
match
---
operator: = [19904,19905]
operator: = [20289,20290]
===
match
---
argument [7005,7027]
argument [7390,7412]
===
match
---
arglist [25404,25453]
arglist [25789,25838]
===
match
---
simple_stmt [16412,16465]
simple_stmt [16797,16850]
===
match
---
name: dag_folder [7943,7953]
name: dag_folder [8328,8338]
===
match
---
trailer [6127,6141]
trailer [6512,6526]
===
match
---
simple_stmt [8586,8633]
simple_stmt [8971,9018]
===
match
---
atom_expr [13111,13125]
atom_expr [13496,13510]
===
match
---
expr_stmt [15624,15703]
expr_stmt [16009,16088]
===
match
---
argument [25193,25205]
argument [25578,25590]
===
match
---
operator: = [20051,20052]
operator: = [20436,20437]
===
match
---
name: dagbag [12224,12230]
name: dagbag [12609,12615]
===
match
---
trailer [22592,22629]
trailer [22977,23014]
===
match
---
trailer [4274,4317]
trailer [4659,4702]
===
match
---
trailer [10702,10723]
trailer [11087,11108]
===
match
---
comparison [21841,21867]
comparison [22226,22252]
===
match
---
name: OperationalError [29498,29514]
name: OperationalError [29883,29899]
===
match
---
argument [31598,31613]
argument [31983,31998]
===
match
---
name: dag_bag [34392,34399]
name: dag_bag [34777,34784]
===
match
---
trailer [29561,29565]
trailer [29946,29950]
===
match
---
name: DagBag [32764,32770]
name: DagBag [33149,33155]
===
match
---
trailer [26254,26305]
trailer [26639,26690]
===
match
---
operator: == [9245,9247]
operator: == [9630,9632]
===
match
---
name: f [3713,3714]
name: f [4098,4099]
===
match
---
parameters [15313,15319]
parameters [15698,15704]
===
match
---
atom_expr [16532,16597]
atom_expr [16917,16982]
===
match
---
expr_stmt [11246,11274]
expr_stmt [11631,11659]
===
match
---
arglist [17635,17645]
arglist [18020,18030]
===
match
---
operator: = [4374,4375]
operator: = [4759,4760]
===
match
---
atom_expr [25214,25224]
atom_expr [25599,25609]
===
match
---
name: test_deactivate_unknown_dags [26363,26391]
name: test_deactivate_unknown_dags [26748,26776]
===
match
---
name: dagbag [8236,8242]
name: dagbag [8621,8627]
===
match
---
arglist [15726,15761]
arglist [16111,16146]
===
match
---
name: should_be_found [22105,22120]
name: should_be_found [22490,22505]
===
match
---
name: dag [19643,19646]
name: dag [20028,20031]
===
match
---
name: patch [33770,33775]
name: patch [34155,34160]
===
match
---
suite [16307,16501]
suite [16692,16886]
===
match
---
trailer [31209,31214]
trailer [31594,31599]
===
match
---
name: dag_id [14394,14400]
name: dag_id [14779,14785]
===
match
---
atom_expr [5268,5282]
atom_expr [5653,5667]
===
match
---
name: self [3023,3027]
name: self [3023,3027]
===
match
---
name: models [7406,7412]
name: models [7791,7797]
===
match
---
arglist [3314,3363]
arglist [3699,3748]
===
match
---
classdef [10786,11111]
classdef [11171,11496]
===
match
---
name: dag_id [14590,14596]
name: dag_id [14975,14981]
===
match
---
name: freezegun [1056,1065]
name: freezegun [1056,1065]
===
match
---
return_stmt [23697,23712]
return_stmt [24082,24097]
===
match
---
name: op_subdag_1 [25591,25602]
name: op_subdag_1 [25976,25987]
===
match
---
atom [7078,7216]
atom [7463,7601]
===
match
---
arglist [27680,27729]
arglist [28065,28114]
===
match
---
operator: = [9623,9624]
operator: = [10008,10009]
===
match
---
operator: == [36537,36539]
operator: == [36922,36924]
===
match
---
name: empty_dir [4610,4619]
name: empty_dir [4995,5004]
===
match
---
name: mock_dagmodel [8641,8654]
name: mock_dagmodel [9026,9039]
===
match
---
operator: , [22095,22096]
operator: , [22480,22481]
===
match
---
name: subdag_1 [25253,25261]
name: subdag_1 [25638,25646]
===
match
---
trailer [25222,25224]
trailer [25607,25609]
===
match
---
name: last_expired [10667,10679]
name: last_expired [11052,11064]
===
match
---
name: safe_mode [11100,11109]
name: safe_mode [11485,11494]
===
match
---
operator: == [6305,6307]
operator: == [6690,6692]
===
match
---
name: super [8996,9001]
name: super [9381,9386]
===
match
---
simple_stmt [13084,13175]
simple_stmt [13469,13560]
===
match
---
operator: , [36355,36356]
operator: , [36740,36741]
===
match
---
name: dags [13554,13558]
name: dags [13939,13943]
===
match
---
name: _TestDagBag [11129,11140]
name: _TestDagBag [11514,11525]
===
match
---
string: 'parent.op_subdag_1' [19870,19890]
string: 'parent.op_subdag_1' [20255,20275]
===
match
---
parameters [26391,26397]
parameters [26776,26782]
===
match
---
name: dagbag [2477,2483]
name: dagbag [2477,2483]
===
match
---
operator: = [10844,10845]
operator: = [11229,11230]
===
match
---
operator: = [37750,37751]
operator: = [38135,38136]
===
match
---
argument [12942,12978]
argument [13327,13363]
===
match
---
decorator [28025,28094]
decorator [28410,28479]
===
match
---
trailer [20324,20326]
trailer [20709,20711]
===
match
---
parameters [18550,18552]
parameters [18935,18937]
===
match
---
name: dir [4213,4216]
name: dir [4598,4601]
===
match
---
name: mock_security_manager [32172,32193]
name: mock_security_manager [32557,32578]
===
match
---
arglist [24991,25044]
arglist [25376,25429]
===
match
---
string: """         test that process_file can handle Nones         """ [26160,26223]
string: """         test that process_file can handle Nones         """ [26545,26608]
===
match
---
arglist [15691,15701]
arglist [16076,16086]
===
match
---
number: 1 [35409,35410]
number: 1 [35794,35795]
===
match
---
name: os [38082,38084]
name: os [38467,38469]
===
match
---
name: test_dag [26006,26014]
name: test_dag [26391,26399]
===
match
---
fstring [3974,4004]
fstring [4359,4389]
===
match
---
atom_expr [36047,36068]
atom_expr [36432,36453]
===
match
---
name: dag_id [13446,13452]
name: dag_id [13831,13837]
===
match
---
trailer [29514,29566]
trailer [29899,29951]
===
match
---
name: cls [2056,2059]
name: cls [2056,2059]
===
match
---
name: classmethod [1915,1926]
name: classmethod [1915,1926]
===
match
---
atom_expr [16113,16165]
atom_expr [16498,16550]
===
match
---
name: process_file_calls [9351,9369]
name: process_file_calls [9736,9754]
===
match
---
name: cls [1947,1950]
name: cls [1947,1950]
===
match
---
number: 5 [34136,34137]
number: 5 [34521,34522]
===
match
---
trailer [2714,2722]
trailer [2714,2722]
===
match
---
expr_stmt [24110,24181]
expr_stmt [24495,24566]
===
match
---
dotted_name [1322,1351]
dotted_name [1322,1351]
===
match
---
trailer [8020,8034]
trailer [8405,8419]
===
match
---
operator: , [19641,19642]
operator: , [20026,20027]
===
match
---
arglist [14533,14574]
arglist [14918,14959]
===
match
---
param [4980,4984]
param [5365,5369]
===
match
---
trailer [31178,31325]
trailer [31563,31710]
===
match
---
assert_stmt [36177,36209]
assert_stmt [36562,36594]
===
match
---
simple_stmt [25279,25359]
simple_stmt [25664,25744]
===
match
---
name: fileloc [12068,12075]
name: fileloc [12453,12460]
===
match
---
name: dag [10182,10185]
name: dag [10567,10570]
===
match
---
operator: , [30073,30074]
operator: , [30458,30459]
===
match
---
operator: = [2996,2997]
operator: = [2996,2997]
===
match
---
name: _sync_perms [33522,33533]
name: _sync_perms [33907,33918]
===
match
---
trailer [31554,31559]
trailer [31939,31944]
===
match
---
atom_expr [25765,25786]
atom_expr [26150,26171]
===
match
---
name: utc [10719,10722]
name: utc [11104,11107]
===
match
---
argument [24868,24885]
argument [25253,25270]
===
match
---
string: 'utf8' [14018,14024]
string: 'utf8' [14403,14409]
===
match
---
simple_stmt [27101,27192]
simple_stmt [27486,27577]
===
match
---
operator: @ [30762,30763]
operator: @ [31147,31148]
===
match
---
operator: , [26026,26027]
operator: , [26411,26412]
===
match
---
trailer [34190,34213]
trailer [34575,34598]
===
match
---
name: dag [2694,2697]
name: dag [2694,2697]
===
match
---
trailer [12383,12391]
trailer [12768,12776]
===
match
---
name: file [4883,4887]
name: file [5268,5272]
===
match
---
fstring_string: / [4893,4894]
fstring_string: / [5278,5279]
===
match
---
atom_expr [20637,20653]
atom_expr [21022,21038]
===
match
---
name: dagbag [2700,2706]
name: dagbag [2700,2706]
===
match
---
name: task_id [19621,19628]
name: task_id [20006,20013]
===
match
---
name: assert_called_once_with [32023,32046]
name: assert_called_once_with [32408,32431]
===
match
---
arglist [11073,11109]
arglist [11458,11494]
===
match
---
comparison [14696,14777]
comparison [15081,15162]
===
match
---
name: test_dag [25637,25645]
name: test_dag [26022,26030]
===
match
---
trailer [3306,3313]
trailer [3691,3698]
===
match
---
name: dag_bag [34327,34334]
name: dag_bag [34712,34719]
===
match
---
expr_stmt [24009,24089]
expr_stmt [24394,24474]
===
match
---
simple_stmt [37528,37650]
simple_stmt [37913,38035]
===
match
---
name: test_zip [7226,7234]
name: test_zip [7611,7619]
===
match
---
trailer [3137,3145]
trailer [3137,3145]
===
match
---
name: dag [13529,13532]
name: dag [13914,13917]
===
match
---
name: dag [36357,36360]
name: dag [36742,36745]
===
match
---
trailer [3605,3615]
trailer [3990,4000]
===
match
---
trailer [36543,36558]
trailer [36928,36943]
===
match
---
atom_expr [2117,2135]
atom_expr [2117,2135]
===
match
---
name: set [37004,37007]
name: set [37389,37392]
===
match
---
simple_stmt [28396,28467]
simple_stmt [28781,28852]
===
match
---
name: dag [25103,25106]
name: dag [25488,25491]
===
match
---
operator: = [1975,1976]
operator: = [1975,1976]
===
match
---
for_stmt [8049,8150]
for_stmt [8434,8535]
===
match
---
name: get_dag [2707,2714]
name: get_dag [2707,2714]
===
match
---
string: "airflow.settings.task_policy" [36571,36601]
string: "airflow.settings.task_policy" [36956,36986]
===
match
---
simple_stmt [16875,16904]
simple_stmt [17260,17289]
===
match
---
atom_expr [20220,20230]
atom_expr [20605,20615]
===
match
---
number: 0 [3398,3399]
number: 0 [3783,3784]
===
match
---
expr_stmt [35892,35946]
expr_stmt [36277,36331]
===
match
---
name: dags [31641,31645]
name: dags [32026,32030]
===
match
---
string: 'example_subdag_operator' [9826,9851]
string: 'example_subdag_operator' [10211,10236]
===
match
---
dictorsetmaker [21429,21491]
dictorsetmaker [21814,21876]
===
match
---
string: """         Test that dag_ids not passed into deactivate_unknown_dags         are deactivated when function is invoked         """ [26407,26537]
string: """         Test that dag_ids not passed into deactivate_unknown_dags         are deactivated when function is invoked         """ [26792,26922]
===
match
---
trailer [31699,31701]
trailer [32084,32086]
===
match
---
simple_stmt [785,800]
simple_stmt [785,800]
===
match
---
atom_expr [2486,2549]
atom_expr [2486,2549]
===
match
---
operator: , [21928,21929]
operator: , [22313,22314]
===
match
---
operator: , [29669,29670]
operator: , [30054,30055]
===
match
---
assert_stmt [7071,7216]
assert_stmt [7456,7601]
===
match
---
atom_expr [13183,13194]
atom_expr [13568,13579]
===
match
---
trailer [7958,7968]
trailer [8343,8353]
===
match
---
operator: , [31310,31311]
operator: , [31695,31696]
===
match
---
simple_stmt [9415,9549]
simple_stmt [9800,9934]
===
match
---
name: should_be_found [15200,15215]
name: should_be_found [15585,15600]
===
match
---
atom_expr [17092,17125]
atom_expr [17477,17510]
===
match
---
atom_expr [3820,3873]
atom_expr [4205,4258]
===
match
---
trailer [5143,5162]
trailer [5528,5547]
===
match
---
simple_stmt [5234,5308]
simple_stmt [5619,5693]
===
match
---
operator: = [12013,12014]
operator: = [12398,12399]
===
match
---
suite [14617,15287]
suite [15002,15672]
===
match
---
name: unittest [1023,1031]
name: unittest [1023,1031]
===
match
---
operator: { [6361,6362]
operator: { [6746,6747]
===
match
---
name: len [6265,6268]
name: len [6650,6653]
===
match
---
atom_expr [37882,37901]
atom_expr [38267,38286]
===
match
---
name: self [6666,6670]
name: self [7051,7055]
===
match
---
return_stmt [21701,21711]
return_stmt [22086,22096]
===
match
---
atom_expr [31089,31134]
atom_expr [31474,31519]
===
match
---
operator: , [30018,30019]
operator: , [30403,30404]
===
match
---
trailer [27108,27114]
trailer [27493,27499]
===
match
---
with_item [5985,6056]
with_item [6370,6441]
===
match
---
comparison [26322,26353]
comparison [26707,26738]
===
match
---
name: op_a [16761,16765]
name: op_a [17146,17150]
===
match
---
simple_stmt [25987,26059]
simple_stmt [26372,26444]
===
match
---
operator: , [15695,15696]
operator: , [16080,16081]
===
match
---
suite [11487,12513]
suite [11872,12898]
===
match
---
import_from [1713,1770]
import_from [1713,1770]
===
match
---
name: create_session [32469,32483]
name: create_session [32854,32868]
===
match
---
operator: , [23661,23662]
operator: , [24046,24047]
===
match
---
name: dagbag [12487,12493]
name: dagbag [12872,12878]
===
match
---
simple_stmt [26546,26585]
simple_stmt [26931,26970]
===
match
---
name: dags [6397,6401]
name: dags [6782,6786]
===
match
---
name: include_examples [34191,34207]
name: include_examples [34576,34592]
===
match
---
param [2028,2031]
param [2028,2031]
===
match
---
name: dags_in_bag [6376,6387]
name: dags_in_bag [6761,6772]
===
match
---
operator: = [14334,14335]
operator: = [14719,14720]
===
match
---
atom_expr [22156,22176]
atom_expr [22541,22561]
===
match
---
atom_expr [13357,13373]
atom_expr [13742,13758]
===
match
---
expr_stmt [36125,36168]
expr_stmt [36510,36553]
===
match
---
trailer [10185,10193]
trailer [10570,10578]
===
match
---
name: _TestDagBag [8699,8710]
name: _TestDagBag [9084,9095]
===
match
---
name: some_expected_dag_ids [2559,2580]
name: some_expected_dag_ids [2559,2580]
===
match
---
string: 'dags_folder' [3761,3774]
string: 'dags_folder' [4146,4159]
===
match
---
assert_stmt [37342,37395]
assert_stmt [37727,37780]
===
match
---
operator: = [36269,36270]
operator: = [36654,36655]
===
match
---
atom_expr [28293,28319]
atom_expr [28678,28704]
===
match
---
name: expected_parent_dag [14264,14283]
name: expected_parent_dag [14649,14668]
===
match
---
atom_expr [31634,31675]
atom_expr [32019,32060]
===
match
---
name: dagbag [31634,31640]
name: dagbag [32019,32025]
===
match
---
operator: , [13125,13126]
operator: , [13510,13511]
===
match
---
name: items [36377,36382]
name: items [36762,36767]
===
match
---
atom_expr [16339,16391]
atom_expr [16724,16776]
===
match
---
operator: = [32896,32897]
operator: = [33281,33282]
===
match
---
simple_stmt [10388,10443]
simple_stmt [10773,10828]
===
match
---
name: subdag_a [24785,24793]
name: subdag_a [25170,25178]
===
match
---
assert_stmt [28883,28917]
assert_stmt [29268,29302]
===
match
---
arglist [33693,33763]
arglist [34078,34148]
===
match
---
name: subdag_c [24332,24340]
name: subdag_c [24717,24725]
===
match
---
param [8808,8829]
param [9193,9214]
===
match
---
name: basic_cycle [21216,21227]
name: basic_cycle [21601,21612]
===
match
---
trailer [36326,36336]
trailer [36711,36721]
===
match
---
name: text [7202,7206]
name: text [7587,7591]
===
match
---
name: dagbag [9289,9295]
name: dagbag [9674,9680]
===
match
---
trailer [32022,32046]
trailer [32407,32431]
===
match
---
arglist [4751,4790]
arglist [5136,5175]
===
match
---
string: 'subdag_c.task' [19165,19180]
string: 'subdag_c.task' [19550,19565]
===
match
---
argument [13024,13040]
argument [13409,13425]
===
match
---
trailer [3650,3656]
trailer [4035,4041]
===
match
---
name: self [4980,4984]
name: self [5365,5369]
===
match
---
argument [29515,29533]
argument [29900,29918]
===
match
---
name: mock [30138,30142]
name: mock [30523,30527]
===
match
---
name: models [1650,1656]
name: models [1650,1656]
===
match
---
name: basic_cycle [21732,21743]
name: basic_cycle [22117,22128]
===
match
---
simple_stmt [25375,25455]
simple_stmt [25760,25840]
===
match
---
atom [13376,13398]
atom [13761,13783]
===
match
---
name: session [30075,30082]
name: session [30460,30467]
===
match
---
name: count [27521,27526]
name: count [27906,27911]
===
match
---
string: '' [14889,14891]
string: '' [15274,15276]
===
match
---
name: values [20937,20943]
name: values [21322,21328]
===
match
---
name: session [27502,27509]
name: session [27887,27894]
===
match
---
operator: } [13397,13398]
operator: } [13782,13783]
===
match
---
name: path [36838,36842]
name: path [37223,37227]
===
match
---
string: """Notices:\n""" [37202,37218]
string: """Notices:\n""" [37587,37603]
===
match
---
operator: = [16454,16455]
operator: = [16839,16840]
===
match
---
atom_expr [13198,13208]
atom_expr [13583,13593]
===
match
---
simple_stmt [6689,6838]
simple_stmt [7074,7223]
===
match
---
name: example_dags [36001,36013]
name: example_dags [36386,36398]
===
match
---
atom_expr [5795,5804]
atom_expr [6180,6189]
===
match
---
operator: == [28624,28626]
operator: == [29009,29011]
===
match
---
trailer [27016,27026]
trailer [27401,27411]
===
match
---
assert_stmt [11200,11237]
assert_stmt [11585,11622]
===
match
---
param [14304,14318]
param [14689,14703]
===
match
---
string: "test_zip.zip" [9689,9703]
string: "test_zip.zip" [10074,10088]
===
match
---
atom_expr [25769,25785]
atom_expr [26154,26170]
===
match
---
name: SerializedDagModel [27527,27545]
name: SerializedDagModel [27912,27930]
===
match
---
atom_expr [37375,37395]
atom_expr [37760,37780]
===
match
---
argument [30710,30730]
argument [31095,31115]
===
match
---
atom_expr [3943,3970]
atom_expr [4328,4355]
===
match
---
expr_stmt [6376,6401]
expr_stmt [6761,6786]
===
match
---
parameters [33006,33008]
parameters [33391,33393]
===
match
---
name: mock [30010,30014]
name: mock [30395,30399]
===
match
---
parameters [21227,21229]
parameters [21612,21614]
===
match
---
name: write_dag [36101,36110]
name: write_dag [36486,36495]
===
match
---
name: dag_folder [32788,32798]
name: dag_folder [33173,33183]
===
match
---
suite [16048,16843]
suite [16433,17228]
===
match
---
atom_expr [2788,2798]
atom_expr [2788,2798]
===
match
---
arglist [24509,24546]
arglist [24894,24931]
===
match
---
name: task_id [19711,19718]
name: task_id [20096,20103]
===
match
---
parameters [2225,2231]
parameters [2225,2231]
===
match
---
argument [30680,30708]
argument [31065,31093]
===
match
---
operator: , [14110,14111]
operator: , [14495,14496]
===
match
---
atom_expr [2815,2828]
atom_expr [2815,2828]
===
match
---
name: empty_dir [13116,13125]
name: empty_dir [13501,13510]
===
match
---
string: """         Test that fileloc is correctly set when we load example DAGs,         specifically SubDAGs and packaged DAGs.         """ [9415,9548]
string: """         Test that fileloc is correctly set when we load example DAGs,         specifically SubDAGs and packaged DAGs.         """ [9800,9933]
===
match
---
param [11998,12019]
param [12383,12404]
===
match
---
name: self [7235,7239]
name: self [7620,7624]
===
match
---
string: """         Test that Serialized DAG is updated in DagBag when it is updated in         Serialized DAG table after 'min_serialized_dag_fetch_interval' seconds are passed.         """ [33906,34088]
string: """         Test that Serialized DAG is updated in DagBag when it is updated in         Serialized DAG table after 'min_serialized_dag_fetch_interval' seconds are passed.         """ [34291,34473]
===
match
---
name: os [822,824]
name: os [822,824]
===
match
---
string: 'opSubdag_C' [19962,19974]
string: 'opSubdag_C' [20347,20359]
===
match
---
name: mock_sync_perm_for_dag [31420,31442]
name: mock_sync_perm_for_dag [31805,31827]
===
match
---
name: session [31606,31613]
name: session [31991,31998]
===
match
---
atom [7858,7911]
atom [8243,8296]
===
match
---
argument [5548,5573]
argument [5933,5958]
===
match
---
simple_stmt [16186,16239]
simple_stmt [16571,16624]
===
match
---
dotted_name [15532,15556]
dotted_name [15917,15941]
===
match
---
name: nested_subdags [20750,20764]
name: nested_subdags [21135,21149]
===
match
---
trailer [13497,13504]
trailer [13882,13889]
===
match
---
name: filepath [11073,11081]
name: filepath [11458,11466]
===
match
---
atom_expr [13865,13943]
atom_expr [14250,14328]
===
match
---
arglist [11141,11189]
arglist [11526,11574]
===
match
---
operator: = [9101,9102]
operator: = [9486,9487]
===
match
---
name: actual_dagbag [15029,15042]
name: actual_dagbag [15414,15427]
===
match
---
trailer [32723,32741]
trailer [33108,33126]
===
match
---
atom_expr [37669,37733]
atom_expr [38054,38118]
===
match
---
simple_stmt [31047,31076]
simple_stmt [31432,31461]
===
match
---
operator: = [31948,31949]
operator: = [32333,32334]
===
match
---
atom_expr [14374,14430]
atom_expr [14759,14815]
===
match
---
name: dag_folder [11141,11151]
name: dag_folder [11526,11536]
===
match
---
operator: , [20883,20884]
operator: , [21268,21269]
===
match
---
atom_expr [25389,25454]
atom_expr [25774,25839]
===
match
---
operator: = [15720,15721]
operator: = [16105,16106]
===
match
---
strings [37108,37309]
strings [37493,37694]
===
match
---
simple_stmt [20626,20660]
simple_stmt [21011,21045]
===
match
---
name: dag_id [10088,10094]
name: dag_id [10473,10479]
===
match
---
operator: = [29427,29428]
operator: = [29812,29813]
===
match
---
trailer [36228,36249]
trailer [36613,36634]
===
match
---
trailer [28410,28415]
trailer [28795,28800]
===
match
---
atom_expr [31392,31417]
atom_expr [31777,31802]
===
match
---
operator: , [4773,4774]
operator: , [5158,5159]
===
match
---
name: DummyOperator [22362,22375]
name: DummyOperator [22747,22760]
===
match
---
atom_expr [11744,11783]
atom_expr [12129,12168]
===
match
---
name: dagbag [33078,33084]
name: dagbag [33463,33469]
===
match
---
dotted_name [22331,22354]
dotted_name [22716,22739]
===
match
---
atom_expr [37886,37900]
atom_expr [38271,38285]
===
match
---
name: my_dag [5786,5792]
name: my_dag [6171,6177]
===
match
---
suite [37519,37945]
suite [37904,38330]
===
match
---
name: return_value [11758,11770]
name: return_value [12143,12155]
===
match
---
trailer [36847,36890]
trailer [37232,37275]
===
match
---
suite [35467,35644]
suite [35852,36029]
===
match
---
string: "get_current" [10238,10251]
string: "get_current" [10623,10636]
===
match
---
simple_stmt [20959,20990]
simple_stmt [21344,21375]
===
match
---
name: safe_mode [10916,10925]
name: safe_mode [11301,11310]
===
match
---
operator: , [14966,14967]
operator: , [15351,15352]
===
match
---
name: include_examples [14112,14128]
name: include_examples [14497,14513]
===
match
---
simple_stmt [17409,17459]
simple_stmt [17794,17844]
===
match
---
arglist [33247,33281]
arglist [33632,33666]
===
match
---
name: cluster_policy [37457,37471]
name: cluster_policy [37842,37856]
===
match
---
name: subdag_1 [25197,25205]
name: subdag_1 [25582,25590]
===
match
---
with_stmt [3736,3874]
with_stmt [4121,4259]
===
match
---
decorator [36564,36636]
decorator [36949,37021]
===
match
---
operator: = [7404,7405]
operator: = [7789,7790]
===
match
---
trailer [14393,14400]
trailer [14778,14785]
===
match
---
trailer [5212,5218]
trailer [5597,5603]
===
match
---
argument [24534,24546]
argument [24919,24931]
===
match
---
string: "non_existing_dag_id" [3094,3115]
string: "non_existing_dag_id" [3094,3115]
===
match
---
simple_stmt [1158,1186]
simple_stmt [1158,1186]
===
match
---
expr_stmt [28293,28340]
expr_stmt [28678,28725]
===
match
---
simple_stmt [31688,31702]
simple_stmt [32073,32087]
===
match
---
trailer [14643,14647]
trailer [15028,15032]
===
match
---
string: 'A' [21641,21644]
string: 'A' [22026,22029]
===
match
---
name: subdag_0 [24637,24645]
name: subdag_0 [25022,25030]
===
match
---
operator: , [31270,31271]
operator: , [31655,31656]
===
match
---
atom [33653,33665]
atom [34038,34050]
===
match
---
operator: = [37667,37668]
operator: = [38052,38053]
===
match
---
name: assert_queries_count [35443,35463]
name: assert_queries_count [35828,35848]
===
match
---
argument [24168,24180]
argument [24553,24565]
===
match
---
simple_stmt [13625,13667]
simple_stmt [14010,14052]
===
match
---
name: dag [13299,13302]
name: dag [13684,13687]
===
match
---
name: self [4605,4609]
name: self [4990,4994]
===
match
---
argument [19990,20007]
argument [20375,20392]
===
match
---
operator: = [20188,20189]
operator: = [20573,20574]
===
match
---
trailer [30306,30334]
trailer [30691,30719]
===
match
---
name: datetime [17617,17625]
name: datetime [18002,18010]
===
match
---
simple_stmt [3124,3175]
simple_stmt [3124,3175]
===
match
---
operator: = [11723,11724]
operator: = [12108,12109]
===
match
---
simple_stmt [4495,4569]
simple_stmt [4880,4954]
===
match
---
import_name [22254,22269]
import_name [22639,22654]
===
match
---
dotted_name [22393,22417]
dotted_name [22778,22802]
===
match
---
trailer [24286,24304]
trailer [24671,24689]
===
match
---
trailer [34126,34147]
trailer [34511,34532]
===
match
---
import_from [1492,1540]
import_from [1492,1540]
===
match
---
operator: = [27630,27631]
operator: = [28015,28016]
===
match
---
simple_stmt [28643,28675]
simple_stmt [29028,29060]
===
match
---
trailer [20969,20977]
trailer [21354,21362]
===
match
---
name: datetime [15682,15690]
name: datetime [16067,16075]
===
match
---
atom_expr [19143,19195]
atom_expr [19528,19580]
===
match
---
argument [25207,25224]
argument [25592,25609]
===
match
---
funcdef [3180,3400]
funcdef [3565,3785]
===
match
---
trailer [9670,9704]
trailer [10055,10089]
===
match
---
trailer [37456,37471]
trailer [37841,37856]
===
match
---
suite [10121,10209]
suite [10506,10594]
===
match
---
suite [23745,23956]
suite [24130,24341]
===
match
---
argument [20044,20064]
argument [20429,20449]
===
match
---
trailer [24408,24474]
trailer [24793,24859]
===
match
---
trailer [7485,7498]
trailer [7870,7883]
===
match
---
number: 5 [35090,35091]
number: 5 [35475,35476]
===
match
---
name: inspect [792,799]
name: inspect [792,799]
===
match
---
operator: } [37919,37920]
operator: } [38304,38305]
===
match
---
name: _sync_to_db [31688,31699]
name: _sync_to_db [32073,32084]
===
match
---
operator: , [26014,26015]
operator: , [26399,26400]
===
match
---
trailer [32770,32917]
trailer [33155,33302]
===
match
---
trailer [25355,25357]
trailer [25740,25742]
===
match
---
simple_stmt [14062,14136]
simple_stmt [14447,14521]
===
match
---
return_stmt [14201,14234]
return_stmt [14586,14619]
===
match
---
trailer [2146,2160]
trailer [2146,2160]
===
match
---
trailer [12272,12290]
trailer [12657,12675]
===
match
---
return_stmt [19453,19468]
return_stmt [19838,19853]
===
match
---
atom_expr [35964,35991]
atom_expr [36349,36376]
===
match
---
name: test_dag [17003,17011]
name: test_dag [17388,17396]
===
match
---
name: subdag_0 [16070,16078]
name: subdag_0 [16455,16463]
===
match
---
trailer [13073,13075]
trailer [13458,13460]
===
match
---
argument [36965,36987]
argument [37350,37372]
===
match
---
name: filepath [11988,11996]
name: filepath [12373,12381]
===
match
---
simple_stmt [12408,12431]
simple_stmt [12793,12816]
===
match
---
name: dag [12371,12374]
name: dag [12756,12759]
===
match
---
name: cluster_policies [1622,1638]
name: cluster_policies [1622,1638]
===
match
---
operator: , [17639,17640]
operator: , [18024,18025]
===
match
---
operator: } [4708,4709]
operator: } [5093,5094]
===
match
---
lambdef [14533,14555]
lambdef [14918,14940]
===
match
---
name: ANY [30125,30128]
name: ANY [30510,30513]
===
match
---
name: dag_id [13636,13642]
name: dag_id [14021,14027]
===
match
---
operator: , [18620,18621]
operator: , [19005,19006]
===
match
---
name: subdag_b [19754,19762]
name: subdag_b [20139,20147]
===
match
---
name: self [2364,2368]
name: self [2364,2368]
===
match
---
name: dag [13632,13635]
name: dag [14017,14020]
===
match
---
name: DummyOperator [16718,16731]
name: DummyOperator [17103,17116]
===
match
---
simple_stmt [14148,14189]
simple_stmt [14533,14574]
===
match
---
param [28153,28168]
param [28538,28553]
===
match
---
arglist [27656,27771]
arglist [28041,28156]
===
match
---
name: dag_id [26723,26729]
name: dag_id [27108,27114]
===
match
---
argument [21525,21550]
argument [21910,21935]
===
match
---
name: statement [29515,29524]
name: statement [29900,29909]
===
match
---
name: dagbag [6956,6962]
name: dagbag [7341,7347]
===
match
---
name: has_logged [7052,7062]
name: has_logged [7437,7447]
===
match
---
trailer [34907,34915]
trailer [35292,35300]
===
match
---
atom [28627,28629]
atom [29012,29014]
===
match
---
argument [23577,23602]
argument [23962,23987]
===
match
---
trailer [25667,25669]
trailer [26052,26054]
===
match
---
name: dag [20304,20307]
name: dag [20689,20692]
===
match
---
trailer [10718,10722]
trailer [11103,11107]
===
match
---
trailer [35519,35544]
trailer [35904,35929]
===
match
---
simple_stmt [24568,24584]
simple_stmt [24953,24969]
===
match
---
operator: = [9724,9725]
operator: = [10109,10110]
===
match
---
name: mock_dagmodel [11472,11485]
name: mock_dagmodel [11857,11870]
===
match
---
funcdef [31456,31615]
funcdef [31841,32000]
===
match
---
simple_stmt [19522,19586]
simple_stmt [19907,19971]
===
match
---
name: path [32802,32806]
name: path [33187,33191]
===
match
---
operator: = [8565,8566]
operator: = [8950,8951]
===
match
---
argument [7447,7469]
argument [7832,7854]
===
match
---
name: default_args [19333,19345]
name: default_args [19718,19730]
===
match
---
name: dag [20204,20207]
name: dag [20589,20592]
===
match
---
trailer [23537,23603]
trailer [23922,23988]
===
match
---
name: process_dag [17097,17108]
name: process_dag [17482,17493]
===
match
---
trailer [33048,33059]
trailer [33433,33444]
===
match
---
name: dag_policy [38005,38015]
name: dag_policy [38390,38400]
===
match
---
name: task_id [20277,20284]
name: task_id [20662,20669]
===
match
---
string: """         Test that if a DAG does not exist in serialized_dag table (as the DAG file was removed),         remove dags from the DagBag         """ [12594,12742]
string: """         Test that if a DAG does not exist in serialized_dag table (as the DAG file was removed),         remove dags from the DagBag         """ [12979,13127]
===
match
---
name: session [32060,32067]
name: session [32445,32452]
===
match
---
name: expected_dag_ids [14350,14366]
name: expected_dag_ids [14735,14751]
===
match
---
atom_expr [30083,30091]
atom_expr [30468,30476]
===
match
---
name: TEST_DAGS_FOLDER [28416,28432]
name: TEST_DAGS_FOLDER [28801,28817]
===
match
---
name: found_dags [17076,17086]
name: found_dags [17461,17471]
===
match
---
operator: = [5703,5704]
operator: = [6088,6089]
===
match
---
name: default_args [17693,17705]
name: default_args [18078,18090]
===
match
---
argument [37780,37802]
argument [38165,38187]
===
match
---
name: validate_dags [20861,20874]
name: validate_dags [21246,21259]
===
match
---
assert_stmt [10175,10208]
assert_stmt [10560,10593]
===
match
---
name: mock [30028,30032]
name: mock [30413,30417]
===
match
---
operator: == [12453,12455]
operator: == [12838,12840]
===
match
---
string: 'subdag_d.task' [19402,19417]
string: 'subdag_d.task' [19787,19802]
===
match
---
simple_stmt [17536,17556]
simple_stmt [17921,17941]
===
match
---
name: self [4694,4698]
name: self [5079,5083]
===
match
---
trailer [30142,30146]
trailer [30527,30531]
===
match
---
name: subdag [20213,20219]
name: subdag [20598,20604]
===
match
---
simple_stmt [8092,8150]
simple_stmt [8477,8535]
===
match
---
name: dag_id [13498,13504]
name: dag_id [13883,13889]
===
match
---
name: subdags [14422,14429]
name: subdags [14807,14814]
===
match
---
operator: = [20350,20351]
operator: = [20735,20736]
===
match
---
decorated [10214,11388]
decorated [10599,11773]
===
match
---
name: freeze_time [34103,34114]
name: freeze_time [34488,34499]
===
match
---
simple_stmt [9064,9108]
simple_stmt [9449,9493]
===
match
---
name: deepcopy [883,891]
name: deepcopy [883,891]
===
match
---
name: dags [15043,15047]
name: dags [15428,15432]
===
match
---
simple_stmt [1713,1771]
simple_stmt [1713,1771]
===
match
---
name: collect_dags_from_db [36229,36249]
name: collect_dags_from_db [36614,36634]
===
match
---
suite [12585,13667]
suite [12970,14052]
===
match
---
argument [5691,5723]
argument [6076,6108]
===
match
---
name: dummy [12774,12779]
name: dummy [13159,13164]
===
match
---
argument [16200,16223]
argument [16585,16608]
===
match
---
name: safe_mode [9044,9053]
name: safe_mode [9429,9438]
===
match
---
trailer [10690,10694]
trailer [11075,11079]
===
match
---
operator: = [11250,11251]
operator: = [11635,11636]
===
match
---
operator: = [27906,27907]
operator: = [28291,28292]
===
match
---
expr_stmt [18811,18885]
expr_stmt [19196,19270]
===
match
---
trailer [29786,29788]
trailer [30171,30173]
===
match
---
name: Session [31066,31073]
name: Session [31451,31458]
===
match
---
name: clear_db_dags [2252,2265]
name: clear_db_dags [2252,2265]
===
match
---
and_test [6265,6317]
and_test [6650,6702]
===
match
---
name: import_errors [28812,28825]
name: import_errors [29197,29210]
===
match
---
suite [2240,2333]
suite [2240,2333]
===
match
---
operator: = [19571,19572]
operator: = [19956,19957]
===
match
---
operator: , [20895,20896]
operator: , [21280,21281]
===
match
---
operator: , [15227,15228]
operator: , [15612,15613]
===
match
---
operator: = [24127,24128]
operator: = [24512,24513]
===
match
---
name: include_smart_sensor [37804,37824]
name: include_smart_sensor [38189,38209]
===
match
---
name: write [13998,14003]
name: write [14383,14388]
===
match
---
trailer [25777,25785]
trailer [26162,26170]
===
match
---
name: assert_called_once_with [31737,31760]
name: assert_called_once_with [32122,32145]
===
match
---
name: path [7502,7506]
name: path [7887,7891]
===
match
---
trailer [7611,7616]
trailer [7996,8001]
===
match
---
param [10287,10300]
param [10672,10685]
===
match
---
name: dagbag [10140,10146]
name: dagbag [10525,10531]
===
match
---
name: spec [29383,29387]
name: spec [29768,29772]
===
match
---
atom_expr [10182,10208]
atom_expr [10567,10593]
===
match
---
name: mock [30120,30124]
name: mock [30505,30509]
===
match
---
operator: @ [10214,10215]
operator: @ [10599,10600]
===
match
---
name: dag_id [26716,26722]
name: dag_id [27101,27107]
===
match
---
atom_expr [14369,14431]
atom_expr [14754,14816]
===
match
---
argument [26255,26280]
argument [26640,26665]
===
match
---
trailer [6478,6487]
trailer [6863,6872]
===
match
---
atom_expr [32000,32068]
atom_expr [32385,32453]
===
match
---
parameters [38055,38061]
parameters [38440,38446]
===
match
---
operator: = [38176,38177]
operator: = [38561,38562]
===
match
---
funcdef [35800,36559]
funcdef [36185,36944]
===
match
---
argument [9085,9106]
argument [9470,9491]
===
match
---
name: set [36507,36510]
name: set [36892,36895]
===
match
---
name: tz [13312,13314]
name: tz [13697,13699]
===
match
---
simple_stmt [19216,19232]
simple_stmt [19601,19617]
===
match
---
atom_expr [36415,36431]
atom_expr [36800,36816]
===
match
---
name: model_before [26815,26827]
name: model_before [27200,27212]
===
match
---
name: dag_id [13533,13539]
name: dag_id [13918,13924]
===
match
---
string: "example_branch_operator" [2609,2634]
string: "example_branch_operator" [2609,2634]
===
match
---
name: patch [28955,28960]
name: patch [29340,29345]
===
match
---
name: path [28406,28410]
name: path [28791,28795]
===
match
---
name: dag_id [15170,15176]
name: dag_id [15555,15561]
===
match
---
atom_expr [12953,12978]
atom_expr [13338,13363]
===
match
---
name: self [37513,37517]
name: self [37898,37902]
===
match
---
trailer [32639,32657]
trailer [33024,33042]
===
match
---
classdef [1892,38342]
classdef [1892,38727]
===
match
---
name: patch [8260,8265]
name: patch [8645,8650]
===
match
---
operator: = [24749,24750]
operator: = [25134,25135]
===
match
---
atom_expr [13632,13642]
atom_expr [14017,14027]
===
match
---
test [14889,14922]
test [15274,15307]
===
match
---
operator: , [24166,24167]
operator: , [24551,24552]
===
match
---
operator: , [7881,7882]
operator: , [8266,8267]
===
match
---
trailer [5137,5143]
trailer [5522,5528]
===
match
---
number: 1 [13939,13940]
number: 1 [14324,14325]
===
match
---
name: self [20856,20860]
name: self [21241,21245]
===
match
---
arglist [18920,18957]
arglist [19305,19342]
===
match
---
simple_stmt [12325,12363]
simple_stmt [12710,12748]
===
match
---
argument [4382,4396]
argument [4767,4781]
===
match
---
trailer [2515,2525]
trailer [2515,2525]
===
match
---
simple_stmt [10825,10848]
simple_stmt [11210,11233]
===
match
---
atom_expr [26266,26280]
atom_expr [26651,26665]
===
match
---
name: dag [16044,16047]
name: dag [16429,16432]
===
match
---
comparison [26074,26107]
comparison [26459,26492]
===
match
---
funcdef [21212,21712]
funcdef [21597,22097]
===
match
---
name: sync_to_db [28694,28704]
name: sync_to_db [29079,29089]
===
match
---
name: only_if_updated [9027,9042]
name: only_if_updated [9412,9427]
===
match
---
operator: = [20164,20165]
operator: = [20549,20550]
===
match
---
name: to_dict [13248,13255]
name: to_dict [13633,13640]
===
match
---
name: task_id [18683,18690]
name: task_id [19068,19075]
===
match
---
trailer [33378,33396]
trailer [33763,33781]
===
match
---
comparison [12415,12430]
comparison [12800,12815]
===
match
---
name: DAG [22310,22313]
name: DAG [22695,22698]
===
match
---
name: write [3651,3656]
name: write [4036,4041]
===
match
---
name: f [3683,3684]
name: f [4068,4069]
===
match
---
name: test_zip_path [6885,6898]
name: test_zip_path [7270,7283]
===
match
---
number: 2020 [34127,34131]
number: 2020 [34512,34516]
===
match
---
name: self [26392,26396]
name: self [26777,26781]
===
match
---
import_from [1085,1112]
import_from [1085,1112]
===
match
---
trailer [13314,13321]
trailer [13699,13706]
===
match
---
argument [23820,23845]
argument [24205,24230]
===
match
---
trailer [30032,30036]
trailer [30417,30421]
===
match
---
name: decorators [5651,5661]
name: decorators [6036,6046]
===
match
---
simple_stmt [31543,31564]
simple_stmt [31928,31949]
===
match
---
atom_expr [34800,34832]
atom_expr [35185,35217]
===
match
---
comparison [8010,8040]
comparison [8395,8425]
===
match
---
name: join [27675,27679]
name: join [28060,28064]
===
match
---
expr_stmt [26692,26746]
expr_stmt [27077,27131]
===
match
---
simple_stmt [839,850]
simple_stmt [839,850]
===
match
---
argument [31766,31781]
argument [32151,32166]
===
match
---
param [6672,6678]
param [7057,7063]
===
match
---
string: 'airflow/example_dags/example_bash_operator.py' [9765,9812]
string: 'airflow/example_dags/example_bash_operator.py' [10150,10197]
===
match
---
string: "task_1" [13032,13040]
string: "task_1" [13417,13425]
===
match
---
operator: = [22615,22616]
operator: = [23000,23001]
===
match
---
argument [14112,14134]
argument [14497,14519]
===
match
---
string: 'example_subdag_operator.section-1' [9916,9951]
string: 'example_subdag_operator.section-1' [10301,10336]
===
match
---
name: standard_subdag [15362,15377]
name: standard_subdag [15747,15762]
===
match
---
operator: , [35091,35092]
operator: , [35476,35477]
===
match
---
name: subdag_b [23734,23742]
name: subdag_b [24119,24127]
===
match
---
name: path [31210,31214]
name: path [31595,31599]
===
match
---
simple_stmt [17216,17265]
simple_stmt [17601,17650]
===
match
---
trailer [5867,5877]
trailer [6252,6262]
===
match
---
name: empty_dir [2516,2525]
name: empty_dir [2516,2525]
===
match
---
simple_stmt [29443,29478]
simple_stmt [29828,29863]
===
match
---
trailer [5915,5919]
trailer [6300,6304]
===
match
---
simple_stmt [27623,27786]
simple_stmt [28008,28171]
===
match
---
name: create_session [1526,1540]
name: create_session [1526,1540]
===
match
---
atom_expr [23777,23846]
atom_expr [24162,24231]
===
match
---
operator: , [35413,35414]
operator: , [35798,35799]
===
match
---
name: process_file [8099,8111]
name: process_file [8484,8496]
===
match
---
operator: @ [37401,37402]
operator: @ [37786,37787]
===
match
---
trailer [36837,36842]
trailer [37222,37227]
===
match
---
name: process_file [6432,6444]
name: process_file [6817,6829]
===
match
---
trailer [7412,7419]
trailer [7797,7804]
===
match
---
operator: = [17581,17582]
operator: = [17966,17967]
===
match
---
simple_stmt [1317,1378]
simple_stmt [1317,1378]
===
match
---
operator: == [4836,4838]
operator: == [5221,5223]
===
match
---
name: include_examples [7447,7463]
name: include_examples [7832,7848]
===
match
---
name: TEST_DAGS_FOLDER [27680,27696]
name: TEST_DAGS_FOLDER [28065,28081]
===
match
---
trailer [6543,6554]
trailer [6928,6939]
===
match
---
name: name [6240,6244]
name: name [6625,6629]
===
match
---
name: dag_id [2792,2798]
name: dag_id [2792,2798]
===
match
---
param [14319,14339]
param [14704,14724]
===
match
---
comparison [13529,13558]
comparison [13914,13943]
===
match
---
atom_expr [36477,36487]
atom_expr [36862,36872]
===
match
---
simple_stmt [17068,17126]
simple_stmt [17453,17511]
===
match
---
atom_expr [33200,33282]
atom_expr [33585,33667]
===
match
---
name: include_examples [7970,7986]
name: include_examples [8355,8371]
===
match
---
trailer [15145,15152]
trailer [15530,15537]
===
match
---
atom_expr [20352,20378]
atom_expr [20737,20763]
===
match
---
operator: = [10680,10681]
operator: = [11065,11066]
===
match
---
comparison [4811,4840]
comparison [5196,5225]
===
match
---
name: dag [14540,14543]
name: dag [14925,14928]
===
match
---
operator: } [21491,21492]
operator: } [21876,21877]
===
match
---
simple_stmt [14501,14577]
simple_stmt [14886,14962]
===
match
---
atom [30307,30333]
atom [30692,30718]
===
match
---
expr_stmt [5786,5804]
expr_stmt [6171,6189]
===
match
---
operator: = [25291,25292]
operator: = [25676,25677]
===
match
---
trailer [6444,6455]
trailer [6829,6840]
===
match
---
name: path [28396,28400]
name: path [28781,28785]
===
match
---
name: test_collect_dags_from_db [35804,35829]
name: test_collect_dags_from_db [36189,36214]
===
match
---
suite [29237,30757]
suite [29622,31142]
===
match
---
name: SerializedDagModel [34260,34278]
name: SerializedDagModel [34645,34663]
===
match
---
string: """         Test that dagbag._sync_perm_for_dag will call ApplessAirflowSecurityManager.sync_perm_for_dag         when DAG specific perm views don't exist already or the DAG has access_control set.         """ [32204,32413]
string: """         Test that dagbag._sync_perm_for_dag will call ApplessAirflowSecurityManager.sync_perm_for_dag         when DAG specific perm views don't exist already or the DAG has access_control set.         """ [32589,32798]
===
match
---
param [29168,29173]
param [29553,29558]
===
match
---
simple_stmt [35168,35222]
simple_stmt [35553,35607]
===
match
---
with_stmt [34783,34973]
with_stmt [35168,35358]
===
match
---
trailer [35618,35643]
trailer [36003,36028]
===
match
---
name: f [5136,5137]
name: f [5521,5522]
===
match
---
atom_expr [31974,31987]
atom_expr [32359,32372]
===
match
---
suite [27465,28020]
suite [27850,28405]
===
match
---
name: dag_id [10452,10458]
name: dag_id [10837,10843]
===
match
---
decorator [33686,33765]
decorator [34071,34150]
===
match
---
expr_stmt [8586,8632]
expr_stmt [8971,9017]
===
match
---
operator: == [9341,9343]
operator: == [9726,9728]
===
match
---
name: filepath [10952,10960]
name: filepath [11337,11345]
===
match
---
trailer [17220,17234]
trailer [17605,17619]
===
match
---
name: tags [34941,34945]
name: tags [35326,35330]
===
match
---
atom_expr [31854,31896]
atom_expr [32239,32281]
===
match
---
operator: > [35771,35772]
operator: > [36156,36157]
===
match
---
name: nested_subdag_cycle [22219,22238]
name: nested_subdag_cycle [22604,22623]
===
match
---
name: session [26801,26808]
name: session [27186,27193]
===
match
---
atom_expr [32936,32977]
atom_expr [33321,33362]
===
match
---
name: DagModel [8273,8281]
name: DagModel [8658,8666]
===
match
---
operator: = [20315,20316]
operator: = [20700,20701]
===
match
---
trailer [38257,38273]
trailer [38642,38658]
===
match
---
decorated [36564,37396]
decorated [36949,37781]
===
match
---
name: operators [22401,22410]
name: operators [22786,22795]
===
match
---
atom_expr [9566,9629]
atom_expr [9951,10014]
===
match
---
name: dag_id [27141,27147]
name: dag_id [27526,27532]
===
match
---
name: return_value [10746,10758]
name: return_value [11131,11143]
===
match
---
argument [23906,23918]
argument [24291,24303]
===
match
---
expr_stmt [16102,16165]
expr_stmt [16487,16550]
===
match
---
atom_expr [28660,28673]
atom_expr [29045,29058]
===
match
---
name: dag [12415,12418]
name: dag [12800,12803]
===
match
---
operator: = [23645,23646]
operator: = [24030,24031]
===
match
---
name: found_2 [6415,6422]
name: found_2 [6800,6807]
===
match
---
name: dagbag [17257,17263]
name: dagbag [17642,17648]
===
match
---
name: dag [25427,25430]
name: dag [25812,25815]
===
match
---
expr_stmt [28396,28466]
expr_stmt [28781,28851]
===
match
---
suite [18520,20477]
suite [18905,20862]
===
match
---
expr_stmt [17660,17706]
expr_stmt [18045,18091]
===
match
---
trailer [6074,6085]
trailer [6459,6470]
===
match
---
operator: = [13296,13297]
operator: = [13681,13682]
===
match
---
comparison [6287,6317]
comparison [6672,6702]
===
match
---
assert_stmt [22136,22176]
assert_stmt [22521,22561]
===
match
---
name: example_dags [36364,36376]
name: example_dags [36749,36761]
===
match
---
trailer [26926,26939]
trailer [27311,27324]
===
match
---
simple_stmt [2303,2333]
simple_stmt [2303,2333]
===
match
---
param [11988,11997]
param [12373,12382]
===
match
---
name: join [13884,13888]
name: join [14269,14273]
===
match
---
name: serialized_dag [36511,36525]
name: serialized_dag [36896,36910]
===
match
---
operator: = [24018,24019]
operator: = [24403,24404]
===
match
---
name: subdag [20080,20086]
name: subdag [20465,20471]
===
match
---
atom_expr [7954,7968]
atom_expr [8339,8353]
===
match
---
name: models [2998,3004]
name: models [2998,3004]
===
match
---
atom [3751,3792]
atom [4136,4177]
===
match
---
name: empty_dir [5564,5573]
name: empty_dir [5949,5958]
===
match
---
name: subdag_b [23766,23774]
name: subdag_b [24151,24159]
===
match
---
name: asserts [1735,1742]
name: asserts [1735,1742]
===
match
---
trailer [16425,16464]
trailer [16810,16849]
===
match
---
string: 'op_subdag_0' [20189,20202]
string: 'op_subdag_0' [20574,20587]
===
match
---
expr_stmt [12224,12315]
expr_stmt [12609,12700]
===
match
---
name: dag_folder [37759,37769]
name: dag_folder [38144,38154]
===
match
---
atom_expr [18669,18721]
atom_expr [19054,19106]
===
match
---
operator: = [8626,8627]
operator: = [9011,9012]
===
match
---
string: 'core' [3753,3759]
string: 'core' [4138,4144]
===
match
---
number: 1 [9339,9340]
number: 1 [9724,9725]
===
match
---
argument [4213,4231]
argument [4598,4616]
===
match
---
import_name [815,824]
import_name [815,824]
===
match
---
trailer [11849,11862]
trailer [12234,12247]
===
match
---
trailer [29803,29814]
trailer [30188,30199]
===
match
---
simple_stmt [36177,36210]
simple_stmt [36562,36595]
===
match
---
operator: == [34946,34948]
operator: == [35331,35333]
===
match
---
string: 'example_bash_operator' [8505,8528]
string: 'example_bash_operator' [8890,8913]
===
match
---
simple_stmt [38150,38239]
simple_stmt [38535,38624]
===
match
---
name: get_dag [10147,10154]
name: get_dag [10532,10539]
===
match
---
operator: = [16554,16555]
operator: = [16939,16940]
===
match
---
trailer [13598,13616]
trailer [13983,14001]
===
match
---
name: source [13856,13862]
name: source [14241,14247]
===
match
---
simple_stmt [16102,16166]
simple_stmt [16487,16551]
===
match
---
operator: = [32527,32528]
operator: = [32912,32913]
===
match
---
param [7235,7239]
param [7620,7624]
===
match
---
name: test_zip_path [7100,7113]
name: test_zip_path [7485,7498]
===
match
---
name: f [4638,4639]
name: f [5023,5024]
===
match
---
simple_stmt [3291,3365]
simple_stmt [3676,3750]
===
match
---
name: self [14096,14100]
name: self [14481,14485]
===
match
---
trailer [10202,10208]
trailer [10587,10593]
===
match
---
simple_stmt [29646,29691]
simple_stmt [30031,30076]
===
match
---
simple_stmt [13183,13263]
simple_stmt [13568,13648]
===
match
---
comparison [37349,37395]
comparison [37734,37780]
===
match
---
atom_expr [29498,29566]
atom_expr [29883,29951]
===
match
---
name: db [2249,2251]
name: db [2249,2251]
===
match
---
comparison [11357,11387]
comparison [11742,11772]
===
match
---
name: dagbag [29797,29803]
name: dagbag [30182,30188]
===
match
---
name: subdag_a [23704,23712]
name: subdag_a [24089,24097]
===
match
---
operator: } [33664,33665]
operator: } [34049,34050]
===
match
---
name: dag_file [37080,37088]
name: dag_file [37465,37473]
===
match
---
trailer [21470,21479]
trailer [21855,21864]
===
match
---
name: session [32489,32496]
name: session [32874,32881]
===
match
---
atom_expr [20633,20654]
atom_expr [21018,21039]
===
match
---
expr_stmt [36824,36890]
expr_stmt [37209,37275]
===
match
---
import_name [17337,17352]
import_name [17722,17737]
===
match
---
string: 'A' [20374,20377]
string: 'A' [20759,20762]
===
match
---
simple_stmt [11496,11560]
simple_stmt [11881,11945]
===
match
---
name: NamedTemporaryFile [964,982]
name: NamedTemporaryFile [964,982]
===
match
---
number: 1 [22564,22565]
number: 1 [22949,22950]
===
match
---
simple_stmt [19855,19919]
simple_stmt [20240,20304]
===
match
---
name: fileloc [8668,8675]
name: fileloc [9053,9060]
===
match
---
import_from [12751,12800]
import_from [13136,13185]
===
match
---
name: TEST_DAGS_FOLDER [38095,38111]
name: TEST_DAGS_FOLDER [38480,38496]
===
match
---
name: test_dag [21845,21853]
name: test_dag [22230,22238]
===
match
---
assert_stmt [7601,7634]
assert_stmt [7986,8019]
===
match
---
trailer [2821,2826]
trailer [2821,2826]
===
match
---
simple_stmt [15592,15612]
simple_stmt [15977,15997]
===
match
---
string: "utf8" [5968,5974]
string: "utf8" [6353,6359]
===
match
---
trailer [6268,6277]
trailer [6653,6662]
===
match
---
not_test [27838,27866]
not_test [28223,28251]
===
match
---
decorated [37950,38342]
decorated [38335,38727]
===
match
---
trailer [36305,36319]
trailer [36690,36704]
===
match
---
number: 1 [12131,12132]
number: 1 [12516,12517]
===
match
---
number: 0 [34650,34651]
number: 0 [35035,35036]
===
match
---
operator: , [10892,10893]
operator: , [11277,11278]
===
match
---
operator: = [20373,20374]
operator: = [20758,20759]
===
match
---
trailer [3011,3062]
trailer [3011,3062]
===
match
---
simple_stmt [14039,14049]
simple_stmt [14424,14434]
===
match
---
expr_stmt [6415,6455]
expr_stmt [6800,6840]
===
match
---
name: dags_last_fetched [34477,34494]
name: dags_last_fetched [34862,34879]
===
match
---
atom_expr [24817,24886]
atom_expr [25202,25271]
===
match
---
assert_stmt [8225,8253]
assert_stmt [8610,8638]
===
match
---
return_stmt [16259,16274]
return_stmt [16644,16659]
===
match
---
operator: = [13374,13375]
operator: = [13759,13760]
===
match
---
name: name [14230,14234]
name: name [14615,14619]
===
match
---
name: DAG [19059,19062]
name: DAG [19444,19447]
===
match
---
name: clear_db_serialized_dags [2174,2198]
name: clear_db_serialized_dags [2174,2198]
===
match
---
name: self [3440,3444]
name: self [3825,3829]
===
match
---
argument [19657,19674]
argument [20042,20059]
===
match
---
name: updated_ser_dag_1 [35484,35501]
name: updated_ser_dag_1 [35869,35886]
===
match
---
string: "new_tag" [35715,35724]
string: "new_tag" [36100,36109]
===
match
---
operator: , [21484,21485]
operator: , [21869,21870]
===
match
---
name: dag [23663,23666]
name: dag [24048,24051]
===
match
---
arglist [31220,31269]
arglist [31605,31654]
===
match
---
number: 0 [34873,34874]
number: 0 [35258,35259]
===
match
---
name: self [29168,29172]
name: self [29553,29557]
===
match
---
name: test_dag_removed_if_serialized_dag_is_removed [12522,12567]
name: test_dag_removed_if_serialized_dag_is_removed [12907,12952]
===
match
---
suite [4054,4447]
suite [4439,4832]
===
match
---
simple_stmt [10732,10777]
simple_stmt [11117,11162]
===
match
---
operator: = [21509,21510]
operator: = [21894,21895]
===
match
---
string: "test_zip_dag" [11577,11591]
string: "test_zip_dag" [11962,11976]
===
match
---
name: dedent [13874,13880]
name: dedent [14259,14265]
===
match
---
param [10894,10915]
param [11279,11300]
===
match
---
operator: , [20064,20065]
operator: , [20449,20450]
===
match
---
operator: , [12572,12573]
operator: , [12957,12958]
===
match
---
trailer [12955,12964]
trailer [13340,13349]
===
match
---
name: DummyOperator [23624,23637]
name: DummyOperator [24009,24022]
===
match
---
operator: } [6362,6363]
operator: } [6747,6748]
===
match
---
name: join [31215,31219]
name: join [31600,31604]
===
match
---
arglist [20181,20230]
arglist [20566,20615]
===
match
---
atom_expr [31828,31841]
atom_expr [32213,32226]
===
match
---
name: subdag_d [24538,24546]
name: subdag_d [24923,24931]
===
match
---
name: default_args [16152,16164]
name: default_args [16537,16549]
===
match
---
name: subdag_1 [24976,24984]
name: subdag_1 [25361,25369]
===
match
---
operator: , [33275,33276]
operator: , [33660,33661]
===
match
---
expr_stmt [14062,14135]
expr_stmt [14447,14520]
===
match
---
name: dagbag [38150,38156]
name: dagbag [38535,38541]
===
match
---
trailer [11617,11626]
trailer [12002,12011]
===
match
---
with_stmt [4260,4398]
with_stmt [4645,4783]
===
match
---
trailer [19062,19122]
trailer [19447,19507]
===
match
---
with_stmt [34098,34659]
with_stmt [34483,35044]
===
match
---
trailer [30124,30128]
trailer [30509,30513]
===
match
---
trailer [6913,6947]
trailer [7298,7332]
===
match
---
trailer [31367,31377]
trailer [31752,31762]
===
match
---
argument [20204,20211]
argument [20589,20596]
===
match
---
comparison [34900,34972]
comparison [35285,35357]
===
match
---
simple_stmt [1273,1317]
simple_stmt [1273,1317]
===
match
---
name: dag_id [12446,12452]
name: dag_id [12831,12837]
===
match
---
atom_expr [32670,32704]
atom_expr [33055,33089]
===
match
---
string: b"# airflow" [3657,3669]
string: b"# airflow" [4042,4054]
===
match
---
name: filename [20981,20989]
name: filename [21366,21374]
===
match
---
atom_expr [12377,12399]
atom_expr [12762,12784]
===
match
---
name: op_a [16810,16814]
name: op_a [17195,17199]
===
match
---
simple_stmt [33464,33510]
simple_stmt [33849,33895]
===
match
---
trailer [13393,13397]
trailer [13778,13782]
===
match
---
argument [3341,3363]
argument [3726,3748]
===
match
---
operator: } [7113,7114]
operator: } [7498,7499]
===
match
---
suite [8356,9370]
suite [8741,9755]
===
match
---
comparison [13632,13666]
comparison [14017,14051]
===
match
---
name: tzinfo [10703,10709]
name: tzinfo [11088,11094]
===
match
---
for_stmt [36036,36116]
for_stmt [36421,36501]
===
match
---
comparison [27132,27181]
comparison [27517,27566]
===
match
---
name: join [6909,6913]
name: join [7294,7298]
===
match
---
simple_stmt [38287,38342]
simple_stmt [38672,38727]
===
match
---
number: 0 [35096,35097]
number: 0 [35481,35482]
===
match
---
operator: = [5300,5301]
operator: = [5685,5686]
===
match
---
import_from [1771,1816]
import_from [1771,1816]
===
match
---
simple_stmt [14689,14982]
simple_stmt [15074,15367]
===
match
---
operator: = [24874,24875]
operator: = [25259,25260]
===
match
---
trailer [32801,32806]
trailer [33186,33191]
===
match
---
param [2094,2098]
param [2094,2098]
===
match
---
atom [13197,13262]
atom [13582,13647]
===
match
---
name: import_errors [38318,38331]
name: import_errors [38703,38716]
===
match
---
operator: , [23818,23819]
operator: , [24203,24204]
===
match
---
fstring_expr [37168,37178]
fstring_expr [37553,37563]
===
match
---
simple_stmt [21272,21303]
simple_stmt [21657,21688]
===
match
---
name: filepath [12056,12064]
name: filepath [12441,12449]
===
match
---
name: models [4737,4743]
name: models [5122,5128]
===
match
---
expr_stmt [13856,13943]
expr_stmt [14241,14328]
===
match
---
trailer [34802,34811]
trailer [35187,35196]
===
match
---
name: mock_sync_perm_for_dag [33026,33048]
name: mock_sync_perm_for_dag [33411,33433]
===
match
---
string: ".py" [4628,4633]
string: ".py" [5013,5018]
===
match
---
trailer [29529,29533]
trailer [29914,29918]
===
match
---
argument [30130,30146]
argument [30515,30531]
===
match
---
name: found_dags [17245,17255]
name: found_dags [17630,17640]
===
match
---
funcdef [11436,12513]
funcdef [11821,12898]
===
match
---
argument [24680,24705]
argument [25065,25090]
===
match
---
name: fileloc [11863,11870]
name: fileloc [12248,12255]
===
match
---
name: basic_cycle [21959,21970]
name: basic_cycle [22344,22355]
===
match
---
name: dag [16666,16669]
name: dag [17051,17054]
===
match
---
name: DAG [17393,17396]
name: DAG [17778,17781]
===
match
---
funcdef [18775,18995]
funcdef [19160,19380]
===
match
---
import_from [892,942]
import_from [892,942]
===
match
---
operator: = [12231,12232]
operator: = [12616,12617]
===
match
---
name: settings [1214,1222]
name: settings [1214,1222]
===
match
---
atom_expr [5860,5919]
atom_expr [6245,6304]
===
match
---
comparison [16999,17025]
comparison [17384,17410]
===
match
---
number: 0 [31128,31129]
number: 0 [31513,31514]
===
match
---
name: list [14524,14528]
name: list [14909,14913]
===
match
---
operator: { [33653,33654]
operator: { [34038,34039]
===
match
---
simple_stmt [2249,2268]
simple_stmt [2249,2268]
===
match
---
name: dagbag_stats [4822,4834]
name: dagbag_stats [5207,5219]
===
match
---
decorated [1992,2071]
decorated [1992,2071]
===
match
---
trailer [6158,6164]
trailer [6543,6549]
===
match
---
name: DummyOperator [15501,15514]
name: DummyOperator [15886,15899]
===
match
---
name: session [30710,30717]
name: session [31095,31102]
===
match
---
trailer [12964,12978]
trailer [13349,13363]
===
match
---
simple_stmt [7838,7912]
simple_stmt [8223,8297]
===
match
---
expr_stmt [5525,5598]
expr_stmt [5910,5983]
===
match
---
dictorsetmaker [33486,33508]
dictorsetmaker [33871,33893]
===
match
---
operator: , [14871,14872]
operator: , [15256,15257]
===
match
---
operator: { [13376,13377]
operator: { [13761,13762]
===
match
---
name: os [37669,37671]
name: os [38054,38056]
===
match
---
suite [1952,1987]
suite [1952,1987]
===
match
---
atom_expr [26760,26776]
atom_expr [27145,27161]
===
match
---
atom_expr [13010,13041]
atom_expr [13395,13426]
===
match
---
arglist [31761,31781]
arglist [32146,32166]
===
match
---
name: mock_dagmodel [10640,10653]
name: mock_dagmodel [11025,11038]
===
match
---
import_from [22326,22375]
import_from [22711,22760]
===
match
---
trailer [34407,34432]
trailer [34792,34817]
===
match
---
name: DAG [22589,22592]
name: DAG [22974,22977]
===
match
---
simple_stmt [7479,7547]
simple_stmt [7864,7932]
===
match
---
suite [3636,4005]
suite [4021,4390]
===
match
---
trailer [24990,25045]
trailer [25375,25430]
===
match
---
argument [31288,31310]
argument [31673,31695]
===
match
---
import_name [800,814]
import_name [800,814]
===
match
---
name: dates [1464,1469]
name: dates [1464,1469]
===
match
---
atom_expr [10410,10442]
atom_expr [10795,10827]
===
match
---
operator: , [30147,30148]
operator: , [30532,30533]
===
match
---
decorated [28025,28949]
decorated [28410,29334]
===
match
---
operator: = [2581,2582]
operator: = [2581,2582]
===
match
---
suite [21230,21712]
suite [21615,22097]
===
match
---
name: expected_parent_dag [15245,15264]
name: expected_parent_dag [15630,15649]
===
match
---
operator: = [3055,3056]
operator: = [3055,3056]
===
match
---
operator: = [18871,18872]
operator: = [19256,19257]
===
match
---
argument [6979,7003]
argument [7364,7388]
===
match
---
expr_stmt [16328,16391]
expr_stmt [16713,16776]
===
match
---
trailer [19710,19765]
trailer [20095,20150]
===
match
---
atom_expr [7379,7387]
atom_expr [7764,7772]
===
match
---
assert_stmt [36445,36487]
assert_stmt [36830,36872]
===
match
---
import_from [15465,15514]
import_from [15850,15899]
===
match
---
atom_expr [14039,14048]
atom_expr [14424,14433]
===
match
---
name: tz [34115,34117]
name: tz [34500,34502]
===
match
---
for_stmt [10084,10209]
for_stmt [10469,10594]
===
match
---
string: 'op_subdag_1' [25412,25425]
string: 'op_subdag_1' [25797,25810]
===
match
---
name: subdag [16579,16585]
name: subdag [16964,16970]
===
match
---
atom_expr [20262,20327]
atom_expr [20647,20712]
===
match
---
trailer [8235,8248]
trailer [8620,8633]
===
match
---
trailer [34811,34832]
trailer [35196,35217]
===
match
---
name: dagbag [25834,25840]
name: dagbag [26219,26225]
===
match
---
name: process_file_calls [11005,11023]
name: process_file_calls [11390,11408]
===
match
---
trailer [27554,27561]
trailer [27939,27946]
===
match
---
operator: } [13261,13262]
operator: } [13646,13647]
===
match
---
assert_stmt [28734,28776]
assert_stmt [29119,29161]
===
match
---
name: subdag_a [18712,18720]
name: subdag_a [19097,19105]
===
match
---
import_from [1541,1603]
import_from [1541,1603]
===
match
---
name: suffix [3617,3623]
name: suffix [4002,4008]
===
match
---
name: self [9400,9404]
name: self [9785,9789]
===
match
---
name: subdag_1 [20316,20324]
name: subdag_1 [20701,20709]
===
match
---
trailer [21946,21958]
trailer [22331,22343]
===
match
---
name: classmethod [1993,2004]
name: classmethod [1993,2004]
===
match
---
atom_expr [12156,12214]
atom_expr [12541,12599]
===
match
---
argument [13336,13345]
argument [13721,13730]
===
match
---
atom_expr [30592,30756]
atom_expr [30977,31141]
===
match
---
operator: , [38111,38112]
operator: , [38496,38497]
===
match
---
name: dag_ids [38265,38272]
name: dag_ids [38650,38657]
===
match
---
argument [25427,25434]
argument [25812,25819]
===
match
---
operator: = [26916,26917]
operator: = [27301,27302]
===
match
---
trailer [7576,7592]
trailer [7961,7977]
===
match
---
operator: , [1212,1213]
operator: , [1212,1213]
===
match
---
argument [3314,3339]
argument [3699,3724]
===
match
---
arglist [12245,12314]
arglist [12630,12699]
===
match
---
atom_expr [9344,9369]
atom_expr [9729,9754]
===
match
---
operator: @ [37950,37951]
operator: @ [38335,38336]
===
match
---
name: dag_id [2715,2721]
name: dag_id [2715,2721]
===
match
---
simple_stmt [866,892]
simple_stmt [866,892]
===
match
---
simple_stmt [12594,12743]
simple_stmt [12979,13128]
===
match
---
name: dag_folder [28513,28523]
name: dag_folder [28898,28908]
===
match
---
arglist [7420,7469]
arglist [7805,7854]
===
match
---
trailer [25575,25590]
trailer [25960,25975]
===
match
---
name: example_dags [10418,10430]
name: example_dags [10803,10815]
===
match
---
trailer [20636,20654]
trailer [21021,21039]
===
match
---
operator: , [7528,7529]
operator: , [7913,7914]
===
match
---
operator: = [21617,21618]
operator: = [22002,22003]
===
match
---
trailer [26844,26848]
trailer [27229,27233]
===
match
---
import_from [17409,17458]
import_from [17794,17843]
===
match
---
trailer [32626,32639]
trailer [33011,33024]
===
match
---
trailer [5152,5159]
trailer [5537,5544]
===
match
---
name: subdag_1 [25443,25451]
name: subdag_1 [25828,25836]
===
match
---
parameters [10877,10931]
parameters [11262,11316]
===
match
---
name: dag_file [38177,38185]
name: dag_file [38562,38570]
===
match
---
parameters [9399,9405]
parameters [9784,9790]
===
match
---
name: dag_name [21515,21523]
name: dag_name [21900,21908]
===
match
---
operator: @ [5686,5687]
operator: @ [6071,6072]
===
match
---
expr_stmt [21378,21400]
expr_stmt [21763,21785]
===
match
---
name: max [10691,10694]
name: max [11076,11079]
===
match
---
trailer [31645,31675]
trailer [32030,32060]
===
match
---
name: include_examples [26282,26298]
name: include_examples [26667,26683]
===
match
---
number: 6 [25790,25791]
number: 6 [26175,26176]
===
match
---
name: dagbag [13271,13277]
name: dagbag [13656,13662]
===
match
---
comparison [9289,9323]
comparison [9674,9708]
===
match
---
trailer [14373,14431]
trailer [14758,14816]
===
match
---
parameters [2027,2032]
parameters [2027,2032]
===
match
---
atom_expr [13389,13397]
atom_expr [13774,13782]
===
match
---
operator: , [31120,31121]
operator: , [31505,31506]
===
match
---
name: dag_id [36481,36487]
name: dag_id [36866,36872]
===
match
---
dictorsetmaker [13299,13347]
dictorsetmaker [13684,13732]
===
match
---
operator: , [37802,37803]
operator: , [38187,38188]
===
match
---
suite [8923,8980]
suite [9308,9365]
===
match
---
for_stmt [2645,2799]
for_stmt [2645,2799]
===
match
---
atom_expr [18822,18885]
atom_expr [19207,19270]
===
match
---
trailer [11140,11190]
trailer [11525,11575]
===
match
---
trailer [14167,14180]
trailer [14552,14565]
===
match
---
atom_expr [9638,9705]
atom_expr [10023,10090]
===
match
---
simple_stmt [16614,16694]
simple_stmt [16999,17079]
===
match
---
operator: = [23589,23590]
operator: = [23974,23975]
===
match
---
trailer [13883,13888]
trailer [14268,14273]
===
match
---
operator: , [25205,25206]
operator: , [25590,25591]
===
match
---
expr_stmt [31047,31075]
expr_stmt [31432,31460]
===
match
---
argument [23638,23661]
argument [24023,24046]
===
match
---
simple_stmt [4728,4792]
simple_stmt [5113,5177]
===
match
---
param [14540,14543]
param [14925,14928]
===
match
---
trailer [11004,11023]
trailer [11389,11408]
===
match
---
trailer [13059,13073]
trailer [13444,13458]
===
match
---
name: self [3207,3211]
name: self [3592,3596]
===
match
---
name: startswith [6544,6554]
name: startswith [6929,6939]
===
match
---
operator: = [10925,10926]
operator: = [11310,11311]
===
match
---
funcdef [19486,19802]
funcdef [19871,20187]
===
match
---
argument [29383,29398]
argument [29768,29783]
===
match
---
arglist [36916,36987]
arglist [37301,37372]
===
match
---
trailer [19299,19359]
trailer [19684,19744]
===
match
---
operator: , [6930,6931]
operator: , [7315,7316]
===
match
---
atom_expr [9073,9107]
atom_expr [9458,9492]
===
match
---
trailer [31894,31896]
trailer [32279,32281]
===
match
---
atom_expr [28765,28776]
atom_expr [29150,29161]
===
match
---
name: NamedTemporaryFile [5934,5952]
name: NamedTemporaryFile [6319,6337]
===
match
---
number: 5 [35412,35413]
number: 5 [35797,35798]
===
match
---
simple_stmt [30268,30335]
simple_stmt [30653,30720]
===
match
---
name: dag_bag [35593,35600]
name: dag_bag [35978,35985]
===
match
---
operator: , [25338,25339]
operator: , [25723,25724]
===
match
---
param [32172,32193]
param [32557,32578]
===
match
---
parameters [35829,35835]
parameters [36214,36220]
===
match
---
argument [3858,3872]
argument [4243,4257]
===
match
---
name: import_errors [37931,37944]
name: import_errors [38316,38329]
===
match
---
parameters [8791,8845]
parameters [9176,9230]
===
match
---
string: "example_bash_operator" [2584,2607]
string: "example_bash_operator" [2584,2607]
===
match
---
testlist_star_expr [20702,20730]
testlist_star_expr [21087,21115]
===
match
---
funcdef [10257,11388]
funcdef [10642,11773]
===
match
---
parameters [24952,24954]
parameters [25337,25339]
===
match
---
name: after_model [26904,26915]
name: after_model [27289,27300]
===
match
---
operator: , [20211,20212]
operator: , [20596,20597]
===
match
---
simple_stmt [11246,11275]
simple_stmt [11631,11660]
===
match
---
suite [5412,6639]
suite [5797,7024]
===
match
---
trailer [31760,31782]
trailer [32145,32167]
===
match
---
name: DummyOperator [16186,16199]
name: DummyOperator [16571,16584]
===
match
---
simple_stmt [37911,37945]
simple_stmt [38296,38330]
===
match
---
name: dummy [21338,21343]
name: dummy [21723,21728]
===
match
---
trailer [13532,13539]
trailer [13917,13924]
===
match
---
name: schedule_interval [12906,12923]
name: schedule_interval [13291,13308]
===
match
---
atom_expr [4815,4834]
atom_expr [5200,5219]
===
match
---
string: "can_read" [33497,33507]
string: "can_read" [33882,33892]
===
match
---
name: tf_2 [6179,6183]
name: tf_2 [6564,6568]
===
match
---
simple_stmt [21910,21972]
simple_stmt [22295,22357]
===
match
---
name: mock [29772,29776]
name: mock [30157,30161]
===
match
---
operator: = [31773,31774]
operator: = [32158,32159]
===
match
---
string: """Loading a DAG with ID that already existed in a DAG bag should result in an import error.""" [5421,5516]
string: """Loading a DAG with ID that already existed in a DAG bag should result in an import error.""" [5806,5901]
===
match
---
name: process_file_calls [9123,9141]
name: process_file_calls [9508,9526]
===
match
---
trailer [27915,27921]
trailer [28300,28306]
===
match
---
trailer [5159,5161]
trailer [5544,5546]
===
match
---
simple_stmt [31714,31783]
simple_stmt [32099,32168]
===
match
---
simple_stmt [21612,21646]
simple_stmt [21997,22031]
===
match
---
simple_stmt [26956,26986]
simple_stmt [27341,27371]
===
match
---
arglist [23638,23675]
arglist [24023,24060]
===
match
---
name: dag_name [15726,15734]
name: dag_name [16111,16119]
===
match
---
dictorsetmaker [9740,10064]
dictorsetmaker [10125,10449]
===
match
---
name: cluster_policies [37988,38004]
name: cluster_policies [38373,38389]
===
match
---
parameters [27247,27253]
parameters [27632,27638]
===
match
---
trailer [3313,3364]
trailer [3698,3749]
===
match
---
simple_stmt [1051,1085]
simple_stmt [1051,1085]
===
match
---
arglist [24409,24473]
arglist [24794,24858]
===
match
---
operator: , [18857,18858]
operator: , [19242,19243]
===
match
---
decorators [28954,29133]
decorators [29339,29518]
===
match
---
name: self [9591,9595]
name: self [9976,9980]
===
match
---
operator: , [33640,33641]
operator: , [34025,34026]
===
match
---
trailer [6449,6454]
trailer [6834,6839]
===
match
---
trailer [7419,7470]
trailer [7804,7855]
===
match
---
atom_expr [4895,4919]
atom_expr [5280,5304]
===
match
---
name: self [25987,25991]
name: self [26372,26376]
===
match
---
operator: } [33508,33509]
operator: } [33893,33894]
===
match
---
atom_expr [11627,11685]
atom_expr [12012,12070]
===
match
---
trailer [11156,11166]
trailer [11541,11551]
===
match
---
import_from [866,891]
import_from [866,891]
===
match
---
trailer [13201,13208]
trailer [13586,13593]
===
match
---
trailer [10430,10439]
trailer [10815,10824]
===
match
---
expr_stmt [23523,23603]
expr_stmt [23908,23988]
===
match
---
name: TEST_DAGS_FOLDER [7512,7528]
name: TEST_DAGS_FOLDER [7897,7913]
===
match
---
operator: = [25334,25335]
operator: = [25719,25720]
===
match
---
operator: @ [33686,33687]
operator: @ [34071,34072]
===
match
---
string: 'owner' [15640,15647]
string: 'owner' [16025,16032]
===
match
---
operator: = [35200,35201]
operator: = [35585,35586]
===
match
---
name: airflow [22393,22400]
name: airflow [22778,22785]
===
match
---
atom_expr [6154,6166]
atom_expr [6539,6551]
===
match
---
operator: , [35701,35702]
operator: , [36086,36087]
===
match
---
name: name [6538,6542]
name: name [6923,6927]
===
match
---
string: 'mock_dag' [29455,29465]
string: 'mock_dag' [29840,29850]
===
match
---
name: timedelta [13326,13335]
name: timedelta [13711,13720]
===
match
---
trailer [27526,27553]
trailer [27911,27938]
===
match
---
operator: = [36413,36414]
operator: = [36798,36799]
===
match
---
name: os [6901,6903]
name: os [7286,7288]
===
match
---
simple_stmt [2771,2799]
simple_stmt [2771,2799]
===
match
---
trailer [10758,10766]
trailer [11143,11151]
===
match
---
operator: , [29195,29196]
operator: , [29580,29581]
===
match
---
simple_stmt [23523,23604]
simple_stmt [23908,23989]
===
match
---
trailer [10522,10527]
trailer [10907,10912]
===
match
---
atom_expr [24405,24474]
atom_expr [24790,24859]
===
match
---
operator: = [16681,16682]
operator: = [17066,17067]
===
match
---
decorator [37950,38017]
decorator [38335,38402]
===
match
---
simple_stmt [825,839]
simple_stmt [825,839]
===
match
---
simple_stmt [25066,25136]
simple_stmt [25451,25521]
===
match
---
trailer [3750,3793]
trailer [4135,4178]
===
match
---
parameters [19261,19263]
parameters [19646,19648]
===
match
---
trailer [19869,19918]
trailer [20254,20303]
===
match
---
name: DAG [15722,15725]
name: DAG [16107,16110]
===
match
---
operator: , [10552,10553]
operator: , [10937,10938]
===
match
---
trailer [28946,28948]
trailer [29331,29333]
===
match
---
name: set_downstream [21667,21681]
name: set_downstream [22052,22066]
===
match
---
name: ANY [29686,29689]
name: ANY [30071,30074]
===
match
---
trailer [28649,28659]
trailer [29034,29044]
===
match
---
suite [2370,2834]
suite [2370,2834]
===
match
---
suite [5123,5361]
suite [5508,5746]
===
match
---
simple_stmt [31580,31615]
simple_stmt [31965,32000]
===
match
---
atom_expr [7929,7993]
atom_expr [8314,8378]
===
match
---
return_stmt [18742,18757]
return_stmt [19127,19142]
===
match
---
name: mock_sync_perm_for_dag [31854,31876]
name: mock_sync_perm_for_dag [32239,32261]
===
match
---
name: op_a [16711,16715]
name: op_a [17096,17100]
===
match
---
param [1947,1950]
param [1947,1950]
===
match
---
name: self [27248,27252]
name: self [27633,27637]
===
match
---
number: 0 [34142,34143]
number: 0 [34527,34528]
===
match
---
simple_stmt [20152,20232]
simple_stmt [20537,20617]
===
match
---
name: models [5534,5540]
name: models [5919,5925]
===
match
---
atom_expr [4301,4315]
atom_expr [4686,4700]
===
match
---
name: op_subdag_c_task [24255,24271]
name: op_subdag_c_task [24640,24656]
===
match
---
name: cls [1961,1964]
name: cls [1961,1964]
===
match
---
simple_stmt [24495,24548]
simple_stmt [24880,24933]
===
match
---
simple_stmt [28293,28341]
simple_stmt [28678,28726]
===
match
---
trailer [9084,9107]
trailer [9469,9492]
===
match
---
operator: = [19628,19629]
operator: = [20013,20014]
===
match
---
trailer [30312,30317]
trailer [30697,30702]
===
match
---
operator: } [22569,22570]
operator: } [22954,22955]
===
match
---
operator: = [3022,3023]
operator: = [3022,3023]
===
match
---
name: join [8120,8124]
name: join [8505,8509]
===
match
---
name: dags [20932,20936]
name: dags [21317,21321]
===
match
---
atom_expr [36364,36384]
atom_expr [36749,36769]
===
match
---
argument [37759,37778]
argument [38144,38163]
===
match
---
argument [13100,13125]
argument [13485,13510]
===
match
---
trailer [22074,22127]
trailer [22459,22512]
===
match
---
operator: = [11871,11872]
operator: = [12256,12257]
===
match
---
operator: = [6989,6990]
operator: = [7374,7375]
===
match
---
assert_stmt [37840,37901]
assert_stmt [38225,38286]
===
match
---
string: ".py" [4240,4245]
string: ".py" [4625,4630]
===
match
---
name: set [37013,37016]
name: set [37398,37401]
===
match
---
operator: = [13863,13864]
operator: = [14248,14249]
===
match
---
name: DagModel [11725,11733]
name: DagModel [12110,12118]
===
match
---
name: ANY [13394,13397]
name: ANY [13779,13782]
===
match
---
operator: = [30082,30083]
operator: = [30467,30468]
===
match
---
trailer [27967,27969]
trailer [28352,28354]
===
match
---
name: mock [30083,30087]
name: mock [30468,30472]
===
match
---
name: actual_found_dags [14557,14574]
name: actual_found_dags [14942,14959]
===
match
---
arglist [26716,26745]
arglist [27101,27130]
===
match
---
argument [33109,33124]
argument [33494,33509]
===
match
---
name: self [2226,2230]
name: self [2226,2230]
===
match
---
atom_expr [17216,17264]
atom_expr [17601,17649]
===
match
---
name: self [4048,4052]
name: self [4433,4437]
===
match
---
simple_stmt [25571,25604]
simple_stmt [25956,25989]
===
match
---
name: tests [1644,1649]
name: tests [1644,1649]
===
match
---
parameters [14257,14340]
parameters [14642,14725]
===
match
---
string: """         test that retrieving a non existing dag id returns None without crashing         """ [2884,2980]
string: """         test that retrieving a non existing dag id returns None without crashing         """ [2884,2980]
===
match
---
funcdef [9375,10209]
funcdef [9760,10594]
===
match
---
name: dags [36199,36203]
name: dags [36584,36588]
===
match
---
name: join [36843,36847]
name: join [37228,37232]
===
match
---
name: assert_has_calls [30612,30628]
name: assert_has_calls [30997,31013]
===
match
---
name: freeze_time [35057,35068]
name: freeze_time [35442,35453]
===
match
---
name: empty_dir [7436,7445]
name: empty_dir [7821,7830]
===
match
---
operator: , [34645,34646]
operator: , [35030,35031]
===
match
---
name: call [30326,30330]
name: call [30711,30715]
===
match
---
trailer [36423,36431]
trailer [36808,36816]
===
match
---
decorator [11393,11432]
decorator [11778,11817]
===
match
---
trailer [3714,3720]
trailer [4099,4105]
===
match
---
atom [17583,17647]
atom [17968,18032]
===
match
---
name: syspath_before [7620,7634]
name: syspath_before [8005,8019]
===
match
---
trailer [2055,2070]
trailer [2055,2070]
===
match
---
operator: = [19185,19186]
operator: = [19570,19571]
===
match
---
trailer [15152,15286]
trailer [15537,15671]
===
match
---
suite [34834,34973]
suite [35219,35358]
===
match
---
simple_stmt [19285,19360]
simple_stmt [19670,19745]
===
match
---
name: expected_active_dags [26641,26661]
name: expected_active_dags [27026,27046]
===
match
---
atom_expr [26838,26894]
atom_expr [27223,27279]
===
match
---
name: SubDagOperator [16628,16642]
name: SubDagOperator [17013,17027]
===
match
---
atom_expr [20166,20231]
atom_expr [20551,20616]
===
match
---
operator: = [37769,37770]
operator: = [38154,38155]
===
match
---
atom [14696,14758]
atom [15081,15143]
===
match
---
trailer [3329,3339]
trailer [3714,3724]
===
match
---
name: dagbag [13547,13553]
name: dagbag [13932,13938]
===
match
---
argument [27656,27730]
argument [28041,28115]
===
match
---
name: path [10506,10510]
name: path [10891,10895]
===
match
---
simple_stmt [31338,31380]
simple_stmt [31723,31765]
===
match
---
trailer [37007,37009]
trailer [37392,37394]
===
match
---
name: dag [15716,15719]
name: dag [16101,16104]
===
match
---
operator: , [34134,34135]
operator: , [34519,34520]
===
match
---
import_from [1186,1222]
import_from [1186,1222]
===
match
---
simple_stmt [2884,2981]
simple_stmt [2884,2981]
===
match
---
name: DagBag [9573,9579]
name: DagBag [9958,9964]
===
match
---
operator: , [29679,29680]
operator: , [30064,30065]
===
match
---
operator: = [10459,10460]
operator: = [10844,10845]
===
match
---
trailer [2330,2332]
trailer [2330,2332]
===
match
---
parameters [2093,2099]
parameters [2093,2099]
===
match
---
simple_stmt [14440,14492]
simple_stmt [14825,14877]
===
match
---
operator: == [12484,12486]
operator: == [12869,12871]
===
match
---
assert_stmt [9282,9323]
assert_stmt [9667,9708]
===
match
---
name: dag [13198,13201]
name: dag [13583,13586]
===
match
---
atom_expr [21845,21861]
atom_expr [22230,22246]
===
match
---
trailer [24741,24796]
trailer [25126,25181]
===
match
---
operator: = [4216,4217]
operator: = [4601,4602]
===
match
---
name: subdag_a [23667,23675]
name: subdag_a [24052,24060]
===
match
---
name: found_1 [6269,6276]
name: found_1 [6654,6661]
===
match
---
trailer [9595,9605]
trailer [9980,9990]
===
match
---
assert_stmt [16992,17025]
assert_stmt [17377,17410]
===
match
---
dotted_name [5643,5661]
dotted_name [6028,6046]
===
match
---
trailer [13189,13194]
trailer [13574,13579]
===
match
---
simple_stmt [2042,2071]
simple_stmt [2042,2071]
===
match
---
name: source_lines [6128,6140]
name: source_lines [6513,6525]
===
match
---
string: 'subdag_b.task' [23889,23904]
string: 'subdag_b.task' [24274,24289]
===
match
---
atom_expr [29700,29733]
atom_expr [30085,30118]
===
match
---
trailer [12176,12214]
trailer [12561,12599]
===
match
---
string: "SerializationError" [28741,28761]
string: "SerializationError" [29126,29146]
===
match
---
lambdef [14378,14400]
lambdef [14763,14785]
===
match
---
simple_stmt [35734,35795]
simple_stmt [36119,36180]
===
match
---
name: mock_s10n_write_dag [30592,30611]
name: mock_s10n_write_dag [30977,30996]
===
match
---
name: subdag_1 [19980,19988]
name: subdag_1 [20365,20373]
===
match
---
operator: = [16884,16885]
operator: = [17269,17270]
===
match
---
trailer [31377,31379]
trailer [31762,31764]
===
match
---
expr_stmt [20248,20327]
expr_stmt [20633,20712]
===
match
---
name: SerializedDagModel [35168,35186]
name: SerializedDagModel [35553,35571]
===
match
---
operator: == [2785,2787]
operator: == [2785,2787]
===
match
---
number: 1 [12332,12333]
number: 1 [12717,12718]
===
match
---
simple_stmt [10493,10583]
simple_stmt [10878,10968]
===
match
---
simple_stmt [24325,24341]
simple_stmt [24710,24726]
===
match
---
string: """         test the loading of a DAG within a zip file that includes dependencies         """ [7250,7344]
string: """         test the loading of a DAG within a zip file that includes dependencies         """ [7635,7729]
===
match
---
string: """With safe mode enabled, a file matching the discovery heuristics         should be discovered.         """ [3455,3564]
string: """With safe mode enabled, a file matching the discovery heuristics         should be discovered.         """ [3840,3949]
===
match
---
name: shutil [832,838]
name: shutil [832,838]
===
match
---
name: query [27109,27114]
name: query [27494,27499]
===
match
---
operator: = [20519,20520]
operator: = [20904,20905]
===
match
---
name: ANY [30143,30146]
name: ANY [30528,30531]
===
match
---
trailer [4350,4357]
trailer [4735,4742]
===
match
---
atom_expr [36835,36890]
atom_expr [37220,37275]
===
match
---
name: datetime [21462,21470]
name: datetime [21847,21855]
===
match
---
name: SubDagOperator [20029,20043]
name: SubDagOperator [20414,20428]
===
match
---
trailer [27674,27679]
trailer [28059,28064]
===
match
---
name: airflow [1546,1553]
name: airflow [1546,1553]
===
match
---
atom_expr [35168,35221]
atom_expr [35553,35606]
===
match
---
simple_stmt [36824,36891]
simple_stmt [37209,37276]
===
match
---
argument [25117,25134]
argument [25502,25519]
===
match
---
name: import_errors [8021,8034]
name: import_errors [8406,8419]
===
match
---
atom_expr [30321,30332]
atom_expr [30706,30717]
===
match
---
name: SubDagOperator [24817,24831]
name: SubDagOperator [25202,25216]
===
match
---
operator: , [20202,20203]
operator: , [20587,20588]
===
match
---
name: process_file [5340,5352]
name: process_file [5725,5737]
===
match
---
dotted_name [1450,1469]
dotted_name [1450,1469]
===
match
---
simple_stmt [4335,4398]
simple_stmt [4720,4783]
===
match
---
trailer [17234,17264]
trailer [17619,17649]
===
match
---
simple_stmt [31854,31897]
simple_stmt [32239,32282]
===
match
---
argument [19096,19121]
argument [19481,19506]
===
match
---
trailer [5889,5900]
trailer [6274,6285]
===
match
---
operator: = [6213,6214]
operator: = [6598,6599]
===
match
---
assert_stmt [36500,36558]
assert_stmt [36885,36943]
===
match
---
expr_stmt [23766,23846]
expr_stmt [24151,24231]
===
match
---
name: test_dag [22075,22083]
name: test_dag [22460,22468]
===
match
---
name: utcnow [13315,13321]
name: utcnow [13700,13706]
===
match
---
trailer [27951,27958]
trailer [28336,28343]
===
match
---
name: task_id [16200,16207]
name: task_id [16585,16592]
===
match
---
simple_stmt [10452,10485]
simple_stmt [10837,10870]
===
match
---
suite [13983,14235]
suite [14368,14620]
===
match
---
trailer [3904,3917]
trailer [4289,4302]
===
match
---
with_stmt [16039,16843]
with_stmt [16424,17228]
===
match
---
trailer [37381,37395]
trailer [37766,37780]
===
match
---
expr_stmt [21413,21492]
expr_stmt [21798,21877]
===
match
---
name: subdags [20646,20653]
name: subdags [21031,21038]
===
match
---
operator: = [20260,20261]
operator: = [20645,20646]
===
match
---
operator: = [23832,23833]
operator: = [24217,24218]
===
match
---
testlist_comp [3753,3774]
testlist_comp [4138,4159]
===
match
---
name: actual_found_dag_ids [14724,14744]
name: actual_found_dag_ids [15109,15129]
===
match
---
trailer [8667,8675]
trailer [9052,9060]
===
match
---
name: dag_folder [5548,5558]
name: dag_folder [5933,5943]
===
match
---
arglist [38095,38139]
arglist [38480,38524]
===
match
---
name: subdag_0 [19793,19801]
name: subdag_0 [20178,20186]
===
match
---
operator: = [19864,19865]
operator: = [20249,20250]
===
match
---
arglist [16426,16463]
arglist [16811,16848]
===
match
---
simple_stmt [12149,12215]
simple_stmt [12534,12600]
===
match
---
name: security_manager [32510,32526]
name: security_manager [32895,32911]
===
match
---
name: dags [6597,6601]
name: dags [6982,6986]
===
match
---
parameters [30899,30905]
parameters [31284,31290]
===
match
---
name: expected [9715,9723]
name: expected [10100,10108]
===
match
---
simple_stmt [21662,21688]
simple_stmt [22047,22073]
===
match
---
atom_expr [30308,30319]
atom_expr [30693,30704]
===
match
---
operator: , [28568,28569]
operator: , [28953,28954]
===
match
---
name: models [26838,26844]
name: models [27223,27229]
===
match
---
arglist [33104,33124]
arglist [33489,33509]
===
match
---
atom_expr [33356,33398]
atom_expr [33741,33783]
===
match
---
simple_stmt [9282,9324]
simple_stmt [9667,9709]
===
match
---
atom_expr [9289,9311]
atom_expr [9674,9696]
===
match
---
expr_stmt [10825,10847]
expr_stmt [11210,11232]
===
match
---
expr_stmt [11744,11827]
expr_stmt [12129,12212]
===
match
---
expr_stmt [2989,3062]
expr_stmt [2989,3062]
===
match
---
operator: == [37010,37012]
operator: == [37395,37397]
===
match
---
operator: } [37177,37178]
operator: } [37562,37563]
===
match
---
simple_stmt [20248,20328]
simple_stmt [20633,20713]
===
match
---
atom_expr [3894,3918]
atom_expr [4279,4303]
===
match
---
simple_stmt [2559,2636]
simple_stmt [2559,2636]
===
match
---
param [3440,3444]
param [3825,3829]
===
match
---
name: default_args [19096,19108]
name: default_args [19481,19493]
===
match
---
trailer [31985,31987]
trailer [32370,32372]
===
match
---
simple_stmt [32580,32658]
simple_stmt [32965,33043]
===
match
---
param [12574,12583]
param [12959,12968]
===
match
---
name: file [3966,3970]
name: file [4351,4355]
===
match
---
simple_stmt [13567,13617]
simple_stmt [13952,14002]
===
match
---
trailer [18682,18721]
trailer [19067,19106]
===
match
---
trailer [11770,11783]
trailer [12155,12168]
===
match
---
suite [10932,11111]
suite [11317,11496]
===
match
---
simple_stmt [3649,3671]
simple_stmt [4034,4056]
===
match
---
import_from [1317,1377]
import_from [1317,1377]
===
match
---
operator: = [31304,31305]
operator: = [31689,31690]
===
match
---
simple_stmt [35955,35992]
simple_stmt [36340,36377]
===
match
---
trailer [23780,23846]
trailer [24165,24231]
===
match
---
trailer [13099,13174]
trailer [13484,13559]
===
match
---
argument [38166,38185]
argument [38551,38570]
===
match
---
trailer [9303,9311]
trailer [9688,9696]
===
match
---
with_item [5097,5122]
with_item [5482,5507]
===
match
---
atom_expr [28687,28721]
atom_expr [29072,29106]
===
match
---
name: db [2276,2278]
name: db [2276,2278]
===
match
---
name: mock_sync_perm_for_dag [32580,32602]
name: mock_sync_perm_for_dag [32965,32987]
===
match
---
name: airflow [1165,1172]
name: airflow [1165,1172]
===
match
---
atom_expr [11129,11190]
atom_expr [11514,11575]
===
match
---
name: updated_ser_dag_1 [35664,35681]
name: updated_ser_dag_1 [36049,36066]
===
match
---
name: task_id [13024,13031]
name: task_id [13409,13416]
===
match
---
argument [32052,32067]
argument [32437,32452]
===
match
---
name: default_args [21525,21537]
name: default_args [21910,21922]
===
match
---
name: mock [30321,30325]
name: mock [30706,30710]
===
match
---
name: tf_1 [6235,6239]
name: tf_1 [6620,6624]
===
match
---
operator: = [24692,24693]
operator: = [25077,25078]
===
match
---
name: default_args [16378,16390]
name: default_args [16763,16775]
===
match
---
funcdef [33851,35795]
funcdef [34236,36180]
===
match
---
import_name [825,838]
import_name [825,838]
===
match
---
name: delete [27183,27189]
name: delete [27568,27574]
===
match
---
string: 'nested_cycle.op_subdag_1' [24991,25017]
string: 'nested_cycle.op_subdag_1' [25376,25402]
===
match
---
name: example_bash_op_dag [34293,34312]
name: example_bash_op_dag [34678,34697]
===
match
---
name: mock [1032,1036]
name: mock [1032,1036]
===
match
---
funcdef [36640,37396]
funcdef [37025,37781]
===
match
---
trailer [13115,13125]
trailer [13500,13510]
===
match
---
name: DagModel [10228,10236]
name: DagModel [10613,10621]
===
match
---
name: len [25765,25768]
name: len [26150,26153]
===
match
---
name: subdag_d [19460,19468]
name: subdag_d [19845,19853]
===
match
---
operator: = [5532,5533]
operator: = [5917,5918]
===
match
---
name: expected_parent_dag [14402,14421]
name: expected_parent_dag [14787,14806]
===
match
---
name: import_errors [8176,8189]
name: import_errors [8561,8574]
===
match
---
trailer [30280,30289]
trailer [30665,30674]
===
match
---
operator: , [6021,6022]
operator: , [6406,6407]
===
match
---
comp_op [13643,13649]
comp_op [14028,14034]
===
match
---
name: dagbag [2815,2821]
name: dagbag [2815,2821]
===
match
---
trailer [5272,5282]
trailer [5657,5667]
===
match
---
name: default_args [24063,24075]
name: default_args [24448,24460]
===
match
---
fstring_start: f" [3974,3976]
fstring_start: f" [4359,4361]
===
match
---
simple_stmt [7555,7593]
simple_stmt [7940,7978]
===
match
---
atom_expr [11331,11341]
atom_expr [11716,11726]
===
match
---
trailer [24271,24286]
trailer [24656,24671]
===
match
---
name: DagModel [10621,10629]
name: DagModel [11006,11014]
===
match
---
operator: = [25430,25431]
operator: = [25815,25816]
===
match
---
atom_expr [2998,3062]
atom_expr [2998,3062]
===
match
---
name: set_downstream [24272,24286]
name: set_downstream [24657,24671]
===
match
---
expr_stmt [32755,32917]
expr_stmt [33140,33302]
===
match
---
operator: = [6899,6900]
operator: = [7284,7285]
===
match
---
trailer [30014,30018]
trailer [30399,30403]
===
match
---
import_from [17366,17396]
import_from [17751,17781]
===
match
---
with_stmt [4653,4792]
with_stmt [5038,5177]
===
match
---
trailer [11218,11237]
trailer [11603,11622]
===
match
---
string: "example" [34950,34959]
string: "example" [35335,35344]
===
match
---
trailer [6532,6543]
trailer [6917,6928]
===
match
---
funcdef [6644,7217]
funcdef [7029,7602]
===
match
---
operator: == [37921,37923]
operator: == [38306,38308]
===
match
---
name: patch [37951,37956]
name: patch [38336,38341]
===
match
---
atom_expr [24020,24089]
atom_expr [24405,24474]
===
match
---
trailer [31219,31270]
trailer [31604,31655]
===
match
---
argument [5284,5306]
argument [5669,5691]
===
match
---
name: models [26241,26247]
name: models [26626,26632]
===
match
---
string: "get_current" [11417,11430]
string: "get_current" [11802,11815]
===
match
---
expr_stmt [2559,2635]
expr_stmt [2559,2635]
===
match
---
operator: = [11184,11185]
operator: = [11569,11570]
===
match
---
atom_expr [36016,36027]
atom_expr [36401,36412]
===
match
---
name: task_dict [36548,36557]
name: task_dict [36933,36942]
===
match
---
argument [18708,18720]
argument [19093,19105]
===
match
---
name: SubDagOperator [25066,25080]
name: SubDagOperator [25451,25465]
===
match
---
operator: == [3395,3397]
operator: == [3780,3782]
===
match
---
arglist [6979,7027]
arglist [7364,7412]
===
match
---
name: process_file [7486,7498]
name: process_file [7871,7883]
===
match
---
atom_expr [21511,21551]
atom_expr [21896,21936]
===
match
---
arglist [6914,6946]
arglist [7299,7331]
===
match
---
name: mock_sync_perm_for_dag [31491,31513]
name: mock_sync_perm_for_dag [31876,31898]
===
match
---
argument [25171,25191]
argument [25556,25576]
===
match
---
string: 'subdag_d.task' [24517,24532]
string: 'subdag_d.task' [24902,24917]
===
match
---
expr_stmt [8641,8683]
expr_stmt [9026,9068]
===
match
---
param [10916,10930]
param [11301,11315]
===
match
---
name: include_examples [28546,28562]
name: include_examples [28931,28947]
===
match
---
number: 1 [4839,4840]
number: 1 [5224,5225]
===
match
---
trailer [31112,31133]
trailer [31497,31518]
===
match
---
operator: = [9590,9591]
operator: = [9975,9976]
===
match
---
string: 'nested_cycle' [22464,22478]
string: 'nested_cycle' [22849,22863]
===
match
---
atom_expr [36540,36558]
atom_expr [36925,36943]
===
match
---
funcdef [1931,1987]
funcdef [1931,1987]
===
match
---
arglist [19157,19194]
arglist [19542,19579]
===
match
---
name: rmtree [2049,2055]
name: rmtree [2049,2055]
===
match
---
simple_stmt [26315,26354]
simple_stmt [26700,26739]
===
match
---
simple_stmt [5525,5599]
simple_stmt [5910,5984]
===
match
---
trailer [21844,21862]
trailer [22229,22247]
===
match
---
operator: = [29496,29497]
operator: = [29881,29882]
===
match
---
expr_stmt [31628,31675]
expr_stmt [32013,32060]
===
match
---
name: default_args [16139,16151]
name: default_args [16524,16536]
===
match
---
name: process_file_calls [9255,9273]
name: process_file_calls [9640,9658]
===
match
---
trailer [5256,5307]
trailer [5641,5692]
===
match
---
operator: = [26239,26240]
operator: = [26624,26625]
===
match
---
trailer [26872,26894]
trailer [27257,27279]
===
match
---
name: default_args [19572,19584]
name: default_args [19957,19969]
===
match
---
atom_expr [6533,6542]
atom_expr [6918,6927]
===
match
---
comparison [4860,4921]
comparison [5245,5306]
===
match
---
name: test_skip_cycle_dags [20999,21019]
name: test_skip_cycle_dags [21384,21404]
===
match
---
trailer [28609,28623]
trailer [28994,29008]
===
match
---
atom_expr [8586,8625]
atom_expr [8971,9010]
===
match
---
name: dagbag [8169,8175]
name: dagbag [8554,8560]
===
match
---
operator: = [30717,30718]
operator: = [31102,31103]
===
match
---
name: dag_id [14667,14673]
name: dag_id [15052,15058]
===
match
---
operator: = [29734,29735]
operator: = [30119,30120]
===
match
---
name: example_bash_op_dag [34162,34181]
name: example_bash_op_dag [34547,34566]
===
match
---
argument [34191,34212]
argument [34576,34597]
===
match
---
name: dagbag [7045,7051]
name: dagbag [7430,7436]
===
match
---
assert_stmt [35734,35794]
assert_stmt [36119,36179]
===
match
---
operator: , [14400,14401]
operator: , [14785,14786]
===
match
---
name: process_file_calls [8739,8757]
name: process_file_calls [9124,9142]
===
match
---
string: "airflow.settings.dag_policy" [37957,37986]
string: "airflow.settings.dag_policy" [38342,38371]
===
match
---
trailer [27932,27959]
trailer [28317,28344]
===
match
---
trailer [22557,22569]
trailer [22942,22954]
===
match
---
argument [16675,16692]
argument [17060,17077]
===
match
---
simple_stmt [13357,13399]
simple_stmt [13742,13784]
===
match
---
expr_stmt [17536,17555]
expr_stmt [17921,17940]
===
match
---
string: "example" [35692,35701]
string: "example" [36077,36086]
===
match
---
name: tf_1 [5979,5983]
name: tf_1 [6364,6368]
===
match
---
trailer [26334,26347]
trailer [26719,26732]
===
match
---
operator: { [9726,9727]
operator: { [10111,10112]
===
match
---
simple_stmt [26232,26306]
simple_stmt [26617,26691]
===
match
---
atom_expr [22540,22569]
atom_expr [22925,22954]
===
match
---
argument [25493,25504]
argument [25878,25889]
===
match
---
operator: , [28432,28433]
operator: , [28817,28818]
===
match
---
atom_expr [4265,4317]
atom_expr [4650,4702]
===
match
---
expr_stmt [25637,25669]
expr_stmt [26022,26054]
===
match
---
trailer [3781,3791]
trailer [4166,4176]
===
match
---
string: "w+" [5953,5957]
string: "w+" [6338,6342]
===
match
---
trailer [24508,24547]
trailer [24893,24932]
===
match
---
trailer [21479,21491]
trailer [21864,21876]
===
match
---
operator: = [24646,24647]
operator: = [25031,25032]
===
match
---
atom_expr [6425,6455]
atom_expr [6810,6840]
===
match
---
assert_stmt [28790,28825]
assert_stmt [29175,29210]
===
match
---
name: teardown_method [2210,2225]
name: teardown_method [2210,2225]
===
match
---
trailer [8599,8612]
trailer [8984,8997]
===
match
---
arglist [31196,31311]
arglist [31581,31696]
===
match
---
simple_stmt [20856,20905]
simple_stmt [21241,21290]
===
match
---
operator: , [7445,7446]
operator: , [7830,7831]
===
match
---
atom_expr [23867,23919]
atom_expr [24252,24304]
===
match
---
simple_stmt [28790,28826]
simple_stmt [29175,29211]
===
match
---
name: func [27516,27520]
name: func [27901,27905]
===
match
---
name: self [3325,3329]
name: self [3710,3714]
===
match
---
name: dag_id [8496,8502]
name: dag_id [8881,8887]
===
match
---
trailer [21666,21681]
trailer [22051,22066]
===
match
---
name: tz [34626,34628]
name: tz [35011,35013]
===
match
---
simple_stmt [26692,26747]
simple_stmt [27077,27132]
===
match
---
import_from [1445,1491]
import_from [1445,1491]
===
match
---
trailer [35196,35221]
trailer [35581,35606]
===
match
---
trailer [34940,34945]
trailer [35325,35330]
===
match
---
test [15194,15227]
test [15579,15612]
===
match
---
name: dag [16570,16573]
name: dag [16955,16958]
===
match
---
simple_stmt [2171,2201]
simple_stmt [2171,2201]
===
match
---
name: DagBag [1300,1306]
name: DagBag [1300,1306]
===
match
---
number: 1 [17641,17642]
number: 1 [18026,18027]
===
match
---
import_from [1113,1156]
import_from [1113,1156]
===
match
---
operator: = [4604,4605]
operator: = [4989,4990]
===
match
---
operator: = [12308,12309]
operator: = [12693,12694]
===
match
---
simple_stmt [20345,20379]
simple_stmt [20730,20764]
===
match
---
expr_stmt [10452,10484]
expr_stmt [10837,10869]
===
match
---
param [9400,9404]
param [9785,9789]
===
match
---
simple_stmt [9557,9630]
simple_stmt [9942,10015]
===
match
---
trailer [32692,32704]
trailer [33077,33089]
===
match
---
trailer [36547,36557]
trailer [36932,36942]
===
match
---
name: orig [29552,29556]
name: orig [29937,29941]
===
match
---
assert_stmt [38287,38341]
assert_stmt [38672,38726]
===
match
---
operator: = [6963,6964]
operator: = [7348,7349]
===
match
---
string: 'parent.op_subdag_0.opSubdag_A' [18589,18620]
string: 'parent.op_subdag_0.opSubdag_A' [18974,19005]
===
match
---
name: new_dags [36415,36423]
name: new_dags [36800,36808]
===
match
---
funcdef [4452,4922]
funcdef [4837,5307]
===
match
---
name: process_file [11969,11981]
name: process_file [12354,12366]
===
match
---
assert_stmt [11314,11341]
assert_stmt [11699,11726]
===
match
---
trailer [35071,35080]
trailer [35456,35465]
===
match
---
atom_expr [11836,11870]
atom_expr [12221,12255]
===
match
---
name: dagbag [27798,27804]
name: dagbag [28183,28189]
===
match
---
name: dag [12993,12996]
name: dag [13378,13381]
===
match
---
simple_stmt [16711,16745]
simple_stmt [17096,17130]
===
match
---
name: _ [17088,17089]
name: _ [17473,17474]
===
match
---
name: self [8335,8339]
name: self [8720,8724]
===
match
---
return_stmt [16485,16500]
return_stmt [16870,16885]
===
match
---
atom [4668,4709]
atom [5053,5094]
===
match
---
operator: = [16716,16717]
operator: = [17101,17102]
===
match
---
name: len [16999,17002]
name: len [17384,17387]
===
match
---
operator: , [14262,14263]
operator: , [14647,14648]
===
match
---
name: DagBag [10804,10810]
name: DagBag [11189,11195]
===
match
---
name: self [35830,35834]
name: self [36215,36219]
===
match
---
name: models [8711,8717]
name: models [9096,9102]
===
match
---
name: query [27510,27515]
name: query [27895,27900]
===
match
---
name: call [30005,30009]
name: call [30390,30394]
===
match
---
suite [8726,9055]
suite [9111,9440]
===
match
---
name: self [14258,14262]
name: self [14643,14647]
===
match
---
suite [8079,8150]
suite [8464,8535]
===
match
---
name: suffix [4233,4239]
name: suffix [4618,4624]
===
match
---
arglist [20044,20097]
arglist [20429,20482]
===
match
---
comparison [36302,36336]
comparison [36687,36721]
===
match
---
name: test_get_existing_dag [2342,2363]
name: test_get_existing_dag [2342,2363]
===
match
---
atom_expr [3300,3364]
atom_expr [3685,3749]
===
match
---
trailer [26975,26985]
trailer [27360,27370]
===
match
---
decorated [28954,30757]
decorated [29339,31142]
===
match
---
atom_expr [9248,9273]
atom_expr [9633,9658]
===
match
---
with_stmt [4189,4447]
with_stmt [4574,4832]
===
match
---
suite [34876,34973]
suite [35261,35358]
===
match
---
param [10878,10883]
param [11263,11268]
===
match
---
trailer [4902,4911]
trailer [5287,5296]
===
match
---
name: session [32559,32566]
name: session [32944,32951]
===
match
---
argument [26282,26304]
argument [26667,26689]
===
match
---
name: delete_dag_specific_permissions [32422,32453]
name: delete_dag_specific_permissions [32807,32838]
===
match
---
simple_stmt [1085,1113]
simple_stmt [1085,1113]
===
match
---
operator: { [3977,3978]
operator: { [4362,4363]
===
match
---
name: set_downstream [20400,20414]
name: set_downstream [20785,20799]
===
match
---
name: mock [1013,1017]
name: mock [1013,1017]
===
match
---
assert_stmt [13408,13462]
assert_stmt [13793,13847]
===
match
---
operator: = [10408,10409]
operator: = [10793,10794]
===
match
---
name: mock_sync_perm_for_dag [33548,33570]
name: mock_sync_perm_for_dag [33933,33955]
===
match
---
comparison [4417,4446]
comparison [4802,4831]
===
match
---
trailer [30114,30119]
trailer [30499,30504]
===
match
---
expr_stmt [20345,20378]
expr_stmt [20730,20763]
===
match
---
operator: , [8828,8829]
operator: , [9213,9214]
===
match
---
trailer [21514,21551]
trailer [21899,21936]
===
match
---
name: dagbag [29443,29449]
name: dagbag [29828,29834]
===
match
---
param [26392,26396]
param [26777,26781]
===
match
---
suite [2108,2201]
suite [2108,2201]
===
match
---
name: dag_id [2649,2655]
name: dag_id [2649,2655]
===
match
---
trailer [15725,15762]
trailer [16110,16147]
===
match
---
operator: { [22506,22507]
operator: { [22891,22892]
===
match
---
trailer [34117,34126]
trailer [34502,34511]
===
match
---
name: subdag_c [19997,20005]
name: subdag_c [20382,20390]
===
match
---
name: fileloc [10769,10776]
name: fileloc [11154,11161]
===
match
---
name: dag_folder [31196,31206]
name: dag_folder [31581,31591]
===
match
---
number: 2 [35464,35465]
number: 2 [35849,35850]
===
match
---
operator: , [22565,22566]
operator: , [22950,22951]
===
match
---
name: inspect [5860,5867]
name: inspect [6245,6252]
===
match
---
name: process_file_calls [10825,10843]
name: process_file_calls [11210,11228]
===
match
---
name: TEST_DAGS_FOLDER [6914,6930]
name: TEST_DAGS_FOLDER [7299,7315]
===
match
---
simple_stmt [2694,2723]
simple_stmt [2694,2723]
===
match
---
atom_expr [14464,14490]
atom_expr [14849,14875]
===
match
---
trailer [15042,15047]
trailer [15427,15432]
===
match
---
trailer [20399,20414]
trailer [20784,20799]
===
match
---
name: mock_dagmodel [10732,10745]
name: mock_dagmodel [11117,11130]
===
match
---
expr_stmt [2477,2549]
expr_stmt [2477,2549]
===
match
---
operator: , [14302,14303]
operator: , [14687,14688]
===
match
---
name: test_dag [16875,16883]
name: test_dag [17260,17268]
===
match
---
operator: == [28015,28017]
operator: == [28400,28402]
===
match
---
expr_stmt [8944,8979]
expr_stmt [9329,9364]
===
match
---
suite [30906,32069]
suite [31291,32454]
===
match
---
trailer [30611,30628]
trailer [30996,31013]
===
match
---
name: session [27080,27087]
name: session [27465,27472]
===
match
---
name: self [5406,5410]
name: self [5791,5795]
===
match
---
name: models [21285,21291]
name: models [21670,21676]
===
match
---
funcdef [19819,20135]
funcdef [20204,20520]
===
match
---
argument [7420,7445]
argument [7805,7830]
===
match
---
trailer [27669,27674]
trailer [28054,28059]
===
match
---
name: dagbag [22156,22162]
name: dagbag [22541,22547]
===
match
---
atom_expr [13442,13452]
atom_expr [13827,13837]
===
match
---
name: dag [22583,22586]
name: dag [22968,22971]
===
match
---
name: set_downstream [25576,25590]
name: set_downstream [25961,25975]
===
match
---
arglist [30670,30730]
arglist [31055,31115]
===
match
---
operator: = [35591,35592]
operator: = [35976,35977]
===
match
---
trailer [26774,26776]
trailer [27159,27161]
===
match
---
atom_expr [28930,28948]
atom_expr [29315,29333]
===
match
---
operator: = [28523,28524]
operator: = [28908,28909]
===
match
---
operator: , [921,922]
operator: , [921,922]
===
match
---
trailer [14847,14981]
trailer [15232,15366]
===
match
---
trailer [6396,6401]
trailer [6781,6786]
===
match
---
argument [21633,21644]
argument [22018,22029]
===
match
---
operator: = [30027,30028]
operator: = [30412,30413]
===
match
---
assert_stmt [14994,15286]
assert_stmt [15379,15671]
===
match
---
suite [7715,8254]
suite [8100,8639]
===
match
---
atom_expr [27132,27147]
atom_expr [27517,27532]
===
match
---
param [38056,38060]
param [38441,38445]
===
match
---
name: dags [36023,36027]
name: dags [36408,36412]
===
match
---
name: _TestDagBag [9073,9084]
name: _TestDagBag [9458,9469]
===
match
---
string: 'owner1' [21438,21446]
string: 'owner1' [21823,21831]
===
match
---
name: test_dag [21721,21729]
name: test_dag [22106,22114]
===
match
---
testlist_comp [2584,2634]
testlist_comp [2584,2634]
===
match
---
funcdef [23730,23956]
funcdef [24115,24341]
===
match
---
name: expected_import_errors [37349,37371]
name: expected_import_errors [37734,37756]
===
match
---
name: self [26145,26149]
name: self [26530,26534]
===
match
---
operator: = [26578,26579]
operator: = [26963,26964]
===
match
---
not_test [27001,27026]
not_test [27386,27411]
===
match
---
atom_expr [27502,27563]
atom_expr [27887,27948]
===
match
---
atom_expr [31939,31947]
atom_expr [32324,32332]
===
match
---
name: dag [18516,18519]
name: dag [18901,18904]
===
match
---
argument [38187,38209]
argument [38572,38594]
===
match
---
expr_stmt [10640,10723]
expr_stmt [11025,11108]
===
match
---
trailer [25768,25786]
trailer [26153,26171]
===
match
---
trailer [33396,33398]
trailer [33781,33783]
===
match
---
trailer [28369,28371]
trailer [28754,28756]
===
match
---
comparison [13415,13462]
comparison [13800,13847]
===
match
---
name: session [31047,31054]
name: session [31432,31439]
===
match
---
name: default_args [18622,18634]
name: default_args [19007,19019]
===
match
---
atom_expr [38082,38140]
atom_expr [38467,38525]
===
match
---
name: test_utils [1828,1838]
name: test_utils [1828,1838]
===
match
---
atom_expr [13234,13260]
atom_expr [13619,13645]
===
match
---
name: os [4895,4897]
name: os [5280,5282]
===
match
---
name: SubDagOperator [19606,19620]
name: SubDagOperator [19991,20005]
===
match
---
name: datetime [22261,22269]
name: datetime [22646,22654]
===
match
---
arglist [35403,35422]
arglist [35788,35807]
===
match
---
operator: = [22587,22588]
operator: = [22972,22973]
===
match
---
name: subdag_c [19186,19194]
name: subdag_c [19571,19579]
===
match
---
trailer [6596,6601]
trailer [6981,6986]
===
match
---
operator: == [36474,36476]
operator: == [36859,36861]
===
match
---
name: DagBag [37752,37758]
name: DagBag [38137,38143]
===
match
---
name: mock_bulk_write_to_db [29930,29951]
name: mock_bulk_write_to_db [30315,30336]
===
match
---
name: DummyOperator [21619,21632]
name: DummyOperator [22004,22017]
===
match
---
simple_stmt [2144,2163]
simple_stmt [2144,2163]
===
match
---
trailer [36110,36115]
trailer [36495,36500]
===
match
---
name: default_args [19905,19917]
name: default_args [20290,20302]
===
match
---
name: func [1108,1112]
name: func [1108,1112]
===
match
---
trailer [12263,12272]
trailer [12648,12657]
===
match
---
name: airflow [21277,21284]
name: airflow [21662,21669]
===
match
---
name: after_model [27005,27016]
name: after_model [27390,27401]
===
match
---
number: 6 [20658,20659]
number: 6 [21043,21044]
===
match
---
param [28147,28152]
param [28532,28537]
===
match
---
name: textwrap [857,865]
name: textwrap [857,865]
===
match
---
atom_expr [4860,4887]
atom_expr [5245,5272]
===
match
---
number: 0 [27608,27609]
number: 0 [27993,27994]
===
match
---
simple_stmt [21035,21174]
simple_stmt [21420,21559]
===
match
---
trailer [26814,26828]
trailer [27199,27213]
===
match
---
atom_expr [35069,35101]
atom_expr [35454,35486]
===
match
---
name: op_error [29487,29495]
name: op_error [29872,29880]
===
match
---
atom_expr [7370,7388]
atom_expr [7755,7773]
===
match
---
name: flush [5213,5218]
name: flush [5598,5603]
===
match
---
name: sys [7379,7382]
name: sys [7764,7767]
===
match
---
dotted_name [1718,1742]
dotted_name [1718,1742]
===
match
---
operator: , [31117,31118]
operator: , [31502,31503]
===
match
---
trailer [6221,6234]
trailer [6606,6619]
===
match
---
expr_stmt [34327,34367]
expr_stmt [34712,34752]
===
match
---
argument [19643,19655]
argument [20028,20040]
===
match
---
name: updated_ser_dag_1_update_time [35741,35770]
name: updated_ser_dag_1_update_time [36126,36155]
===
match
---
atom_expr [32422,32455]
atom_expr [32807,32840]
===
match
---
name: dag_bag [34900,34907]
name: dag_bag [35285,35292]
===
match
---
operator: = [19294,19295]
operator: = [19679,19680]
===
match
---
trailer [11794,11798]
trailer [12179,12183]
===
match
---
simple_stmt [5136,5199]
simple_stmt [5521,5584]
===
match
---
decorated [5686,5773]
decorated [6071,6158]
===
match
---
atom_expr [20925,20945]
atom_expr [21310,21330]
===
match
---
subscript [5843,5846]
subscript [6228,6231]
===
match
---
name: airflow [1450,1457]
name: airflow [1450,1457]
===
match
---
number: 2016 [15691,15695]
number: 2016 [16076,16080]
===
match
---
name: dag_id [14865,14871]
name: dag_id [15250,15256]
===
match
---
name: dag_id [13578,13584]
name: dag_id [13963,13969]
===
match
---
trailer [29416,29426]
trailer [29801,29811]
===
match
---
operator: += [8975,8977]
operator: += [9360,9362]
===
match
---
name: process_file [9645,9657]
name: process_file [10030,10042]
===
match
---
operator: == [11328,11330]
operator: == [11713,11715]
===
match
---
operator: , [19988,19989]
operator: , [20373,20374]
===
match
---
argument [28513,28528]
argument [28898,28913]
===
match
---
name: NamedTemporaryFile [4194,4212]
name: NamedTemporaryFile [4579,4597]
===
match
---
name: test_safe_mode_heuristic_match [3409,3439]
name: test_safe_mode_heuristic_match [3794,3824]
===
match
---
trailer [2133,2135]
trailer [2133,2135]
===
match
---
number: 0 [8039,8040]
number: 0 [8424,8425]
===
match
---
operator: = [19531,19532]
operator: = [19916,19917]
===
match
---
simple_stmt [16992,17026]
simple_stmt [17377,17411]
===
match
---
string: 'parent.op_subdag_1.opSubdag_D' [19300,19331]
string: 'parent.op_subdag_1.opSubdag_D' [19685,19716]
===
match
---
atom_expr [3683,3700]
atom_expr [4068,4085]
===
match
---
argument [36916,36935]
argument [37301,37320]
===
match
---
operator: { [4894,4895]
operator: { [5279,5280]
===
match
---
parameters [8334,8355]
parameters [8719,8740]
===
match
---
suite [3794,3874]
suite [4179,4259]
===
match
---
string: """         test that file processing results in import error when task does not         obey cluster policy.         """ [36694,36815]
string: """         test that file processing results in import error when task does not         obey cluster policy.         """ [37079,37200]
===
match
---
operator: , [21916,21917]
operator: , [22301,22302]
===
match
---
trailer [13997,14003]
trailer [14382,14388]
===
match
---
atom [21428,21492]
atom [21813,21877]
===
match
---
operator: = [11127,11128]
operator: = [11512,11513]
===
match
---
atom_expr [8014,8034]
atom_expr [8399,8419]
===
match
---
trailer [6343,6357]
trailer [6728,6742]
===
match
---
argument [18859,18884]
argument [19244,19269]
===
match
---
trailer [3826,3833]
trailer [4211,4218]
===
match
---
name: test_zip_skip_log [6648,6665]
name: test_zip_skip_log [7033,7050]
===
match
---
arglist [25308,25357]
arglist [25693,25742]
===
match
---
exprlist [36349,36360]
exprlist [36734,36745]
===
match
---
operator: } [17646,17647]
operator: } [18031,18032]
===
match
---
argument [11141,11166]
argument [11526,11551]
===
match
---
simple_stmt [35561,35644]
simple_stmt [35946,36029]
===
match
---
operator: = [14095,14096]
operator: = [14480,14481]
===
match
---
argument [34289,34312]
argument [34674,34697]
===
match
---
atom_expr [6863,6875]
atom_expr [7248,7260]
===
match
---
operator: , [10882,10883]
operator: , [11267,11268]
===
match
---
import_from [15422,15452]
import_from [15807,15837]
===
match
---
string: 'subdag_0.task' [16208,16223]
string: 'subdag_0.task' [16593,16608]
===
match
---
trailer [13935,13941]
trailer [14320,14326]
===
match
---
return_stmt [23940,23955]
return_stmt [24325,24340]
===
match
---
simple_stmt [36295,36337]
simple_stmt [36680,36722]
===
match
---
funcdef [26359,27192]
funcdef [26744,27577]
===
match
---
string: b"# DAG" [3691,3699]
string: b"# DAG" [4076,4084]
===
match
---
operator: @ [32074,32075]
operator: @ [32459,32460]
===
match
---
simple_stmt [12097,12133]
simple_stmt [12482,12518]
===
match
---
name: f [14228,14229]
name: f [14613,14614]
===
match
---
funcdef [3405,4005]
funcdef [3790,4390]
===
match
---
import_from [1018,1049]
import_from [1018,1049]
===
match
---
name: process_file [8779,8791]
name: process_file [9164,9176]
===
match
---
name: timezone [934,942]
name: timezone [934,942]
===
match
---
simple_stmt [34532,34582]
simple_stmt [34917,34967]
===
match
---
decorator [30762,30841]
decorator [31147,31226]
===
match
---
simple_stmt [3374,3400]
simple_stmt [3759,3785]
===
match
---
trailer [27960,27967]
trailer [28345,28352]
===
match
---
import_name [21243,21258]
import_name [21628,21643]
===
match
---
name: call [30115,30119]
name: call [30500,30504]
===
match
---
operator: , [14226,14227]
operator: , [14611,14612]
===
match
---
funcdef [30845,32069]
funcdef [31230,32454]
===
match
---
simple_stmt [14630,14677]
simple_stmt [15015,15062]
===
match
---
arglist [19063,19121]
arglist [19448,19506]
===
match
---
trailer [20874,20904]
trailer [21259,21289]
===
match
---
trailer [1984,1986]
trailer [1984,1986]
===
match
---
name: ANY [29530,29533]
name: ANY [29915,29918]
===
match
---
atom_expr [3978,4002]
atom_expr [4363,4387]
===
match
---
operator: = [28487,28488]
operator: = [28872,28873]
===
match
---
atom [37918,37920]
atom [38303,38305]
===
match
---
name: reset_mock [31514,31524]
name: reset_mock [31899,31909]
===
match
---
atom_expr [24727,24796]
atom_expr [25112,25181]
===
match
---
expr_stmt [21910,21971]
expr_stmt [22295,22356]
===
match
---
name: dag [36544,36547]
name: dag [36929,36932]
===
match
---
string: "test_deactivate_unknown_dags" [26602,26632]
string: "test_deactivate_unknown_dags" [26987,27017]
===
match
---
operator: = [19422,19423]
operator: = [19807,19808]
===
match
---
name: dag_ids [37893,37900]
name: dag_ids [38278,38285]
===
match
---
simple_stmt [13271,13349]
simple_stmt [13656,13734]
===
match
---
trailer [13223,13233]
trailer [13608,13618]
===
match
---
trailer [31073,31075]
trailer [31458,31460]
===
match
---
name: models [9566,9572]
name: models [9951,9957]
===
match
---
name: values [36060,36066]
name: values [36445,36451]
===
match
---
atom_expr [35443,35466]
atom_expr [35828,35851]
===
match
---
name: assert_has_calls [30290,30306]
name: assert_has_calls [30675,30691]
===
match
---
atom_expr [31491,31526]
atom_expr [31876,31911]
===
match
---
arglist [21480,21490]
arglist [21865,21875]
===
match
---
param [2226,2230]
param [2226,2230]
===
match
---
argument [25019,25044]
argument [25404,25429]
===
match
---
operator: } [15702,15703]
operator: } [16087,16088]
===
match
---
operator: = [35962,35963]
operator: = [36347,36348]
===
match
---
name: session [29815,29822]
name: session [30200,30207]
===
match
---
expr_stmt [16711,16744]
expr_stmt [17096,17129]
===
match
---
name: tf_2 [6533,6537]
name: tf_2 [6918,6922]
===
match
---
name: DummyOperator [13010,13023]
name: DummyOperator [13395,13408]
===
match
---
number: 0 [35093,35094]
number: 0 [35478,35479]
===
match
---
parameters [2868,2874]
parameters [2868,2874]
===
match
---
testlist_star_expr [21910,21939]
testlist_star_expr [22295,22324]
===
match
---
arglist [26006,26057]
arglist [26391,26442]
===
match
---
name: ANY [30070,30073]
name: ANY [30455,30458]
===
match
---
name: dag [23465,23468]
name: dag [23850,23853]
===
match
---
operator: = [8839,8840]
operator: = [9224,9225]
===
match
---
trailer [11733,11735]
trailer [12118,12120]
===
match
---
operator: = [6423,6424]
operator: = [6808,6809]
===
match
---
simple_stmt [6070,6100]
simple_stmt [6455,6485]
===
match
---
dotted_name [21277,21291]
dotted_name [21662,21676]
===
match
---
simple_stmt [27982,28020]
simple_stmt [28367,28405]
===
match
---
string: "new_tag" [35145,35154]
string: "new_tag" [35530,35539]
===
match
---
name: task_id [19157,19164]
name: task_id [19542,19549]
===
match
---
name: new_dagbag [36125,36135]
name: new_dagbag [36510,36520]
===
match
---
simple_stmt [10993,11029]
simple_stmt [11378,11414]
===
match
---
trailer [26939,26947]
trailer [27324,27332]
===
match
---
name: DagBag [3307,3313]
name: DagBag [3692,3698]
===
match
---
name: self [21942,21946]
name: self [22327,22331]
===
match
---
name: mock_security_manager [32605,32626]
name: mock_security_manager [32990,33011]
===
match
---
number: 2016 [22558,22562]
number: 2016 [22943,22947]
===
match
---
name: path [6904,6908]
name: path [7289,7293]
===
match
---
name: datetime [22540,22548]
name: datetime [22925,22933]
===
match
---
name: map [14529,14532]
name: map [14914,14917]
===
match
---
trailer [34476,34494]
trailer [34861,34879]
===
match
---
name: validate_dags [22061,22074]
name: validate_dags [22446,22459]
===
match
---
name: session [28705,28712]
name: session [29090,29097]
===
match
---
trailer [29335,29348]
trailer [29720,29733]
===
match
---
name: found_1 [6205,6212]
name: found_1 [6590,6597]
===
match
---
import_from [1223,1272]
import_from [1223,1272]
===
match
---
name: DAG [21511,21514]
name: DAG [21896,21899]
===
match
---
parameters [3206,3212]
parameters [3591,3597]
===
match
---
name: default_args [23590,23602]
name: default_args [23975,23987]
===
match
---
trailer [21853,21861]
trailer [22238,22246]
===
match
---
trailer [2198,2200]
trailer [2198,2200]
===
match
---
atom_expr [14390,14400]
atom_expr [14775,14785]
===
match
---
name: mock_collect_dags [29218,29235]
name: mock_collect_dags [29603,29620]
===
match
---
atom_expr [27922,27959]
atom_expr [28307,28344]
===
match
---
arglist [19621,19674]
arglist [20006,20059]
===
match
---
atom_expr [8711,8724]
atom_expr [9096,9109]
===
match
---
name: tests [1822,1827]
name: tests [1822,1827]
===
match
---
arglist [23538,23602]
arglist [23923,23987]
===
match
---
funcdef [19249,19469]
funcdef [19634,19854]
===
match
---
operator: { [28627,28628]
operator: { [29012,29013]
===
match
---
string: "my_flow" [6308,6317]
string: "my_flow" [6693,6702]
===
match
---
simple_stmt [35484,35545]
simple_stmt [35869,35930]
===
match
---
expr_stmt [24394,24474]
expr_stmt [24779,24859]
===
match
---
atom_expr [36302,36319]
atom_expr [36687,36704]
===
match
---
name: empty_dir [11157,11166]
name: empty_dir [11542,11551]
===
match
---
string: "Public" [33486,33494]
string: "Public" [33871,33879]
===
match
---
trailer [4814,4835]
trailer [5199,5220]
===
match
---
simple_stmt [5638,5673]
simple_stmt [6023,6058]
===
match
---
atom_expr [35660,35687]
atom_expr [36045,36072]
===
match
---
operator: = [3092,3093]
operator: = [3092,3093]
===
match
---
atom_expr [10592,10618]
atom_expr [10977,11003]
===
match
---
number: 0 [34824,34825]
number: 0 [35209,35210]
===
match
---
string: 'airflow/example_dags/example_subdag_operator.py' [9953,10002]
string: 'airflow/example_dags/example_subdag_operator.py' [10338,10387]
===
match
---
name: mkdtemp [984,991]
name: mkdtemp [984,991]
===
match
---
atom_expr [18585,18648]
atom_expr [18970,19033]
===
match
---
operator: , [23904,23905]
operator: , [24289,24290]
===
match
---
name: dagbag [13183,13189]
name: dagbag [13568,13574]
===
match
---
name: default_args [19346,19358]
name: default_args [19731,19743]
===
match
---
trailer [5952,5975]
trailer [6337,6360]
===
match
---
number: 0 [31125,31126]
number: 0 [31510,31511]
===
match
---
trailer [2706,2714]
trailer [2706,2714]
===
match
---
operator: == [3919,3921]
operator: == [4304,4306]
===
match
---
with_stmt [31084,32069]
with_stmt [31469,32454]
===
match
---
number: 5 [34821,34822]
number: 5 [35206,35207]
===
match
---
return_stmt [24907,24922]
return_stmt [25292,25307]
===
match
---
operator: , [11166,11167]
operator: , [11551,11552]
===
match
---
name: format [15146,15152]
name: format [15531,15537]
===
match
---
expr_stmt [7838,7911]
expr_stmt [8223,8296]
===
match
---
number: 0 [34139,34140]
number: 0 [34524,34525]
===
match
---
expr_stmt [1961,1986]
expr_stmt [1961,1986]
===
match
---
atom_expr [11052,11110]
atom_expr [11437,11495]
===
match
---
trailer [32942,32947]
trailer [33327,33332]
===
match
---
name: mock_sync_perm_for_dag [31714,31736]
name: mock_sync_perm_for_dag [32099,32121]
===
match
---
trailer [14959,14966]
trailer [15344,15351]
===
match
---
name: len [8010,8013]
name: len [8395,8398]
===
match
---
trailer [6085,6099]
trailer [6470,6484]
===
match
---
trailer [13906,13918]
trailer [14291,14303]
===
match
---
with_item [27060,27087]
with_item [27445,27472]
===
match
---
name: op_subdag_0 [20415,20426]
name: op_subdag_0 [20800,20811]
===
match
---
testlist_comp [34950,34971]
testlist_comp [35335,35356]
===
match
---
atom_expr [37017,37031]
atom_expr [37402,37416]
===
match
---
operator: = [26265,26266]
operator: = [26650,26651]
===
match
---
param [8341,8354]
param [8726,8739]
===
match
---
trailer [19762,19764]
trailer [20147,20149]
===
match
---
simple_stmt [25472,25506]
simple_stmt [25857,25891]
===
match
---
name: dagbag [9248,9254]
name: dagbag [9633,9639]
===
match
---
name: serialized_dags_count [27583,27604]
name: serialized_dags_count [27968,27989]
===
match
---
atom_expr [33026,33061]
atom_expr [33411,33446]
===
match
---
atom_expr [16999,17020]
atom_expr [17384,17405]
===
match
---
number: 0 [8252,8253]
number: 0 [8637,8638]
===
match
---
name: subdag_b [18779,18787]
name: subdag_b [19164,19172]
===
match
---
simple_stmt [11696,11736]
simple_stmt [12081,12121]
===
match
---
param [12020,12034]
param [12405,12419]
===
match
---
trailer [6903,6908]
trailer [7288,7293]
===
match
---
expr_stmt [33464,33509]
expr_stmt [33849,33894]
===
match
---
name: safe_mode [12020,12029]
name: safe_mode [12405,12414]
===
match
---
name: updated_ser_dag_1_update_time [35561,35590]
name: updated_ser_dag_1_update_time [35946,35975]
===
match
---
arglist [3012,3061]
arglist [3012,3061]
===
match
---
name: file [8143,8147]
name: file [8528,8532]
===
match
---
return_stmt [25246,25261]
return_stmt [25631,25646]
===
match
---
operator: = [12923,12924]
operator: = [13308,13309]
===
match
---
import_from [1051,1084]
import_from [1051,1084]
===
match
---
trailer [5802,5804]
trailer [6187,6189]
===
match
---
name: scalar [27555,27561]
name: scalar [27940,27946]
===
match
---
name: dagbag [14161,14167]
name: dagbag [14546,14552]
===
match
---
expr_stmt [27880,27969]
expr_stmt [28265,28354]
===
match
---
name: default_args [21538,21550]
name: default_args [21923,21935]
===
match
---
arglist [20277,20326]
arglist [20662,20711]
===
match
---
trailer [7382,7387]
trailer [7767,7772]
===
match
---
trailer [13918,13929]
trailer [14303,14314]
===
match
---
assert_stmt [34532,34581]
assert_stmt [34917,34966]
===
match
---
atom_expr [20395,20427]
atom_expr [20780,20812]
===
match
---
operator: , [28151,28152]
operator: , [28536,28537]
===
match
---
atom_expr [30268,30334]
atom_expr [30653,30719]
===
match
---
operator: = [19961,19962]
operator: = [20346,20347]
===
match
---
trailer [8111,8149]
trailer [8496,8534]
===
match
---
trailer [13441,13453]
trailer [13826,13838]
===
match
---
operator: = [26740,26741]
operator: = [27125,27126]
===
match
---
operator: , [34825,34826]
operator: , [35210,35211]
===
match
---
argument [32788,32862]
argument [33173,33247]
===
match
---
name: access_control [33468,33482]
name: access_control [33853,33867]
===
match
---
name: task_dict [36526,36535]
name: task_dict [36911,36920]
===
match
---
number: 1 [22567,22568]
number: 1 [22952,22953]
===
match
---
name: _sync_perms [33174,33185]
name: _sync_perms [33559,33570]
===
match
---
name: expected_parent_dag [14464,14483]
name: expected_parent_dag [14849,14868]
===
match
---
fstring_string: :file_no_airflow_dag.py  [7114,7138]
fstring_string: :file_no_airflow_dag.py  [7499,7523]
===
match
---
expr_stmt [13183,13262]
expr_stmt [13568,13647]
===
match
---
name: airflow [1322,1329]
name: airflow [1322,1329]
===
match
---
name: dag [31628,31631]
name: dag [32013,32016]
===
match
---
name: test_process_file_cron_validity_check [7671,7708]
name: test_process_file_cron_validity_check [8056,8093]
===
match
---
atom_expr [27005,27026]
atom_expr [27390,27411]
===
match
---
name: DAG [24987,24990]
name: DAG [25372,25375]
===
match
---
name: test_refresh_packaged_dag [11440,11465]
name: test_refresh_packaged_dag [11825,11850]
===
match
---
param [10281,10286]
param [10666,10671]
===
match
---
name: nested_subdag_cycle [25883,25902]
name: nested_subdag_cycle [26268,26287]
===
match
---
name: file_path [25854,25863]
name: file_path [26239,26248]
===
match
---
name: last_expired [8613,8625]
name: last_expired [8998,9010]
===
match
---
number: 1 [11207,11208]
number: 1 [11592,11593]
===
match
---
parameters [10280,10301]
parameters [10665,10686]
===
match
---
simple_stmt [30592,30757]
simple_stmt [30977,31142]
===
match
---
number: 6 [35099,35100]
number: 6 [35484,35485]
===
match
---
simple_stmt [5211,5221]
simple_stmt [5596,5606]
===
match
---
testlist_comp [30660,30732]
testlist_comp [31045,31117]
===
match
---
atom_expr [13210,13261]
atom_expr [13595,13646]
===
match
---
argument [16547,16568]
argument [16932,16953]
===
match
---
name: dag [20300,20303]
name: dag [20685,20688]
===
match
---
operator: == [27605,27607]
operator: == [27990,27992]
===
match
---
trailer [20414,20427]
trailer [20799,20812]
===
match
---
name: new_serialized_dags_count [27989,28014]
name: new_serialized_dags_count [28374,28399]
===
match
---
atom_expr [30028,30036]
atom_expr [30413,30421]
===
match
---
trailer [30059,30064]
trailer [30444,30449]
===
match
---
simple_stmt [13856,13944]
simple_stmt [14241,14329]
===
match
---
name: freeze_time [34788,34799]
name: freeze_time [35173,35184]
===
match
---
param [14285,14303]
param [14670,14688]
===
match
---
simple_stmt [21834,21868]
simple_stmt [22219,22253]
===
match
---
number: 0 [3963,3964]
number: 0 [4348,4349]
===
match
---
name: dagbag [32755,32761]
name: dagbag [33140,33146]
===
match
---
string: "example2" [34961,34971]
string: "example2" [35346,35356]
===
match
---
funcdef [2076,2201]
funcdef [2076,2201]
===
match
---
simple_stmt [5768,5773]
simple_stmt [6153,6158]
===
match
---
suite [4711,4792]
suite [5096,5177]
===
match
---
operator: = [25346,25347]
operator: = [25731,25732]
===
match
---
expr_stmt [25279,25358]
expr_stmt [25664,25743]
===
match
---
atom_expr [36184,36204]
atom_expr [36569,36589]
===
match
---
name: len [36184,36187]
name: len [36569,36572]
===
match
---
trailer [35921,35934]
trailer [36306,36319]
===
match
---
operator: = [18711,18712]
operator: = [19096,19097]
===
match
---
name: empty_dir [3330,3339]
name: empty_dir [3715,3724]
===
match
---
simple_stmt [1639,1681]
simple_stmt [1639,1681]
===
match
---
name: path [9661,9665]
name: path [10046,10050]
===
match
---
arglist [20875,20903]
arglist [21260,21288]
===
match
---
operator: , [32170,32171]
operator: , [32555,32556]
===
match
---
operator: , [29216,29217]
operator: , [29601,29602]
===
match
---
simple_stmt [37743,37832]
simple_stmt [38128,38217]
===
match
---
trailer [14840,14847]
trailer [15225,15232]
===
match
---
param [29197,29217]
param [29582,29602]
===
match
---
testlist_comp [5838,5919]
testlist_comp [6223,6304]
===
match
---
expr_stmt [10592,10631]
expr_stmt [10977,11016]
===
match
---
trailer [10154,10162]
trailer [10539,10547]
===
match
---
name: read_dags_from_db [34344,34361]
name: read_dags_from_db [34729,34746]
===
match
---
string: 'start_date' [15659,15671]
string: 'start_date' [16044,16056]
===
match
---
assert_stmt [3374,3399]
assert_stmt [3759,3784]
===
match
---
suite [32195,33681]
suite [32580,34066]
===
match
---
suite [3213,3400]
suite [3598,3785]
===
match
---
atom_expr [30110,30147]
atom_expr [30495,30532]
===
match
---
operator: { [13298,13299]
operator: { [13683,13684]
===
match
---
simple_stmt [1771,1817]
simple_stmt [1771,1817]
===
match
---
name: import_errors [6344,6357]
name: import_errors [6729,6742]
===
match
---
atom_expr [3023,3037]
atom_expr [3023,3037]
===
match
---
operator: = [14159,14160]
operator: = [14544,14545]
===
match
---
name: set [36540,36543]
name: set [36925,36928]
===
match
---
trailer [11629,11634]
trailer [12014,12019]
===
match
---
operator: = [10767,10768]
operator: = [11152,11153]
===
match
---
argument [22603,22628]
argument [22988,23013]
===
match
---
trailer [34494,34519]
trailer [34879,34904]
===
match
---
operator: @ [29083,29084]
operator: @ [29468,29469]
===
match
---
expr_stmt [29443,29477]
expr_stmt [29828,29862]
===
match
---
simple_stmt [7724,7830]
simple_stmt [8109,8215]
===
match
---
trailer [31524,31526]
trailer [31909,31911]
===
match
---
name: mock [30055,30059]
name: mock [30440,30444]
===
match
---
name: subdag_a [18749,18757]
name: subdag_a [19134,19142]
===
match
---
name: name [6450,6454]
name: name [6835,6839]
===
match
---
suite [12076,12133]
suite [12461,12518]
===
match
---
operator: == [6488,6490]
operator: == [6873,6875]
===
match
---
string: "new_tag" [31951,31960]
string: "new_tag" [32336,32345]
===
match
---
suite [28177,28949]
suite [28562,29334]
===
match
---
name: dag_id [13202,13208]
name: dag_id [13587,13593]
===
match
---
atom_expr [6965,7028]
atom_expr [7350,7413]
===
match
---
name: dag_id [12838,12844]
name: dag_id [13223,13229]
===
match
---
name: NamedTemporaryFile [4582,4600]
name: NamedTemporaryFile [4967,4985]
===
match
---
number: 10 [12971,12973]
number: 10 [13356,13358]
===
match
---
atom_expr [10710,10722]
atom_expr [11095,11107]
===
match
---
name: dag_id [36349,36355]
name: dag_id [36734,36740]
===
match
---
param [6666,6671]
param [7051,7056]
===
match
---
suite [26151,26354]
suite [26536,26739]
===
match
---
operator: = [6388,6389]
operator: = [6773,6774]
===
match
---
name: empty_dir [2060,2069]
name: empty_dir [2060,2069]
===
match
---
operator: = [37796,37797]
operator: = [38181,38182]
===
match
---
argument [34344,34366]
argument [34729,34751]
===
match
---
name: subdag_1 [16682,16690]
name: subdag_1 [17067,17075]
===
match
---
funcdef [32139,33681]
funcdef [32524,34066]
===
match
---
arglist [28513,28569]
arglist [28898,28954]
===
match
---
expr_stmt [29700,29747]
expr_stmt [30085,30132]
===
match
---
funcdef [17303,20501]
funcdef [17688,20886]
===
match
---
suite [36685,37396]
suite [37070,37781]
===
match
---
name: get_dagmodel [26927,26939]
name: get_dagmodel [27312,27324]
===
match
---
name: shutil [2042,2048]
name: shutil [2042,2048]
===
match
---
atom_expr [26087,26107]
atom_expr [26472,26492]
===
match
---
operator: , [17601,17602]
operator: , [17986,17987]
===
match
---
name: dagbag [35955,35961]
name: dagbag [36340,36346]
===
match
---
operator: , [36935,36936]
operator: , [37320,37321]
===
match
---
trailer [13873,13880]
trailer [14258,14265]
===
match
---
trailer [14377,14430]
trailer [14762,14815]
===
match
---
trailer [20749,20765]
trailer [21134,21150]
===
match
---
trailer [32811,32862]
trailer [33196,33247]
===
match
---
param [13688,13693]
param [14073,14078]
===
match
---
name: datetime [34803,34811]
name: datetime [35188,35196]
===
match
---
trailer [27848,27866]
trailer [28233,28251]
===
match
---
atom_expr [29388,29398]
atom_expr [29773,29783]
===
match
---
operator: == [37372,37374]
operator: == [37757,37759]
===
match
---
arglist [35081,35100]
arglist [35466,35485]
===
match
---
operator: = [16111,16112]
operator: = [16496,16497]
===
match
---
operator: , [19974,19975]
operator: , [20359,20360]
===
match
---
name: test_safe_mode_disabled [4456,4479]
name: test_safe_mode_disabled [4841,4864]
===
match
---
name: dag_id [27952,27958]
name: dag_id [28337,28343]
===
match
---
name: import_errors [22163,22176]
name: import_errors [22548,22561]
===
match
---
operator: = [24857,24858]
operator: = [25242,25243]
===
match
---
name: SubDagOperator [25389,25403]
name: SubDagOperator [25774,25788]
===
match
---
expr_stmt [21505,21551]
expr_stmt [21890,21936]
===
match
---
name: DagBag [11908,11914]
name: DagBag [12293,12299]
===
match
---
name: datetime [17626,17634]
name: datetime [18011,18019]
===
match
---
atom_expr [34103,34148]
atom_expr [34488,34533]
===
match
---
name: my_flow [5741,5748]
name: my_flow [6126,6133]
===
match
---
trailer [14528,14576]
trailer [14913,14961]
===
match
---
string: """         Test that, once a DAG is loaded, it doesn't get refreshed again if it         hasn't been expired.         """ [8365,8487]
string: """         Test that, once a DAG is loaded, it doesn't get refreshed again if it         hasn't been expired.         """ [8750,8872]
===
match
---
name: dag_id [2778,2784]
name: dag_id [2778,2784]
===
match
---
operator: { [35691,35692]
operator: { [36076,36077]
===
match
---
simple_stmt [15422,15453]
simple_stmt [15807,15838]
===
match
---
name: dag [36040,36043]
name: dag [36425,36428]
===
match
---
operator: , [31764,31765]
operator: , [32149,32150]
===
match
---
name: DAG [19296,19299]
name: DAG [19681,19684]
===
match
---
trailer [20365,20378]
trailer [20750,20763]
===
match
---
argument [5959,5974]
argument [6344,6359]
===
match
---
name: self [32166,32170]
name: self [32551,32555]
===
match
---
fstring_expr [7099,7114]
fstring_expr [7484,7499]
===
match
---
string: """         test that the example are not loaded         """ [3222,3282]
string: """         test that the example are not loaded         """ [3607,3667]
===
match
---
operator: , [30092,30093]
operator: , [30477,30478]
===
match
---
atom_expr [19296,19359]
atom_expr [19681,19744]
===
match
---
simple_stmt [33200,33283]
simple_stmt [33585,33668]
===
match
---
arglist [22593,22628]
arglist [22978,23013]
===
match
---
simple_stmt [24110,24182]
simple_stmt [24495,24567]
===
match
---
name: subdag_1 [16328,16336]
name: subdag_1 [16713,16721]
===
match
---
name: setup_class [1935,1946]
name: setup_class [1935,1946]
===
match
---
atom_expr [28844,28870]
atom_expr [29229,29255]
===
match
---
trailer [13023,13041]
trailer [13408,13426]
===
match
---
arglist [34638,34657]
arglist [35023,35042]
===
match
---
argument [25436,25453]
argument [25821,25838]
===
match
---
testlist_star_expr [17068,17089]
testlist_star_expr [17453,17474]
===
match
---
operator: , [9687,9688]
operator: , [10072,10073]
===
match
---
operator: = [7986,7987]
operator: = [8371,8372]
===
match
---
name: serialized_dag [36398,36412]
name: serialized_dag [36783,36797]
===
match
---
operator: = [25196,25197]
operator: = [25581,25582]
===
match
---
simple_stmt [18742,18758]
simple_stmt [19127,19143]
===
match
---
string: 'owner1' [15649,15657]
string: 'owner1' [16034,16042]
===
match
---
trailer [10605,10618]
trailer [10990,11003]
===
match
---
name: DummyOperator [19380,19393]
name: DummyOperator [19765,19778]
===
match
---
arglist [14085,14134]
arglist [14470,14519]
===
match
---
name: fileloc [11600,11607]
name: fileloc [11985,11992]
===
match
---
expr_stmt [32510,32567]
expr_stmt [32895,32952]
===
match
---
atom [15001,15061]
atom [15386,15446]
===
match
---
argument [19892,19917]
argument [20277,20302]
===
match
---
name: models [2486,2492]
name: models [2486,2492]
===
match
---
param [3207,3211]
param [3592,3596]
===
match
---
fstring_end: ' [7138,7139]
fstring_end: ' [7523,7524]
===
match
---
trailer [11059,11072]
trailer [11444,11457]
===
match
---
operator: = [4767,4768]
operator: = [5152,5153]
===
match
---
name: SubDagOperator [19939,19953]
name: SubDagOperator [20324,20338]
===
match
---
name: dags [13190,13194]
name: dags [13575,13579]
===
match
---
name: datetime [913,921]
name: datetime [913,921]
===
match
---
name: utils [1505,1510]
name: utils [1505,1510]
===
match
---
trailer [26848,26872]
trailer [27233,27257]
===
match
---
name: dagbag [5525,5531]
name: dagbag [5910,5916]
===
match
---
operator: , [29172,29173]
operator: , [29557,29558]
===
match
---
operator: = [36014,36015]
operator: = [36399,36400]
===
match
---
operator: , [35094,35095]
operator: , [35479,35480]
===
match
---
trailer [8717,8724]
trailer [9102,9109]
===
match
---
trailer [35663,35687]
trailer [36048,36072]
===
match
---
trailer [10146,10154]
trailer [10531,10539]
===
match
---
name: process_file_calls [12494,12512]
name: process_file_calls [12879,12897]
===
match
---
operator: = [20219,20220]
operator: = [20604,20605]
===
match
---
name: write [5138,5143]
name: write [5523,5528]
===
match
---
name: DAG [16339,16342]
name: DAG [16724,16727]
===
match
---
name: test_dag [17235,17243]
name: test_dag [17620,17628]
===
match
---
name: models [4344,4350]
name: models [4729,4735]
===
match
---
argument [9580,9605]
argument [9965,9990]
===
match
---
name: dagbag [28687,28693]
name: dagbag [29072,29078]
===
match
---
operator: , [3759,3760]
operator: , [4144,4145]
===
match
---
name: return_value [8552,8564]
name: return_value [8937,8949]
===
match
---
name: path [8869,8873]
name: path [9254,9258]
===
match
---
name: self [22056,22060]
name: self [22441,22445]
===
match
---
number: 0 [31131,31132]
number: 0 [31516,31517]
===
match
---
expr_stmt [8739,8761]
expr_stmt [9124,9146]
===
match
---
name: dag [19182,19185]
name: dag [19567,19570]
===
match
---
name: dagbag [32936,32942]
name: dagbag [33321,33327]
===
match
---
trailer [38084,38089]
trailer [38469,38474]
===
match
---
atom_expr [29368,29399]
atom_expr [29753,29784]
===
match
---
assert_stmt [12439,12466]
assert_stmt [12824,12851]
===
match
---
simple_stmt [27880,27970]
simple_stmt [28265,28355]
===
match
---
decorated [30762,32069]
decorated [31147,32454]
===
match
---
operator: , [12928,12929]
operator: , [13313,13314]
===
match
---
name: dagbag [8014,8020]
name: dagbag [8399,8405]
===
match
---
name: create_dag [5878,5888]
name: create_dag [6263,6273]
===
match
---
name: dag [2788,2791]
name: dag [2788,2791]
===
match
---
name: dagbag [37375,37381]
name: dagbag [37760,37766]
===
match
---
atom_expr [12337,12362]
atom_expr [12722,12747]
===
match
---
dictorsetmaker [4276,4315]
dictorsetmaker [4661,4700]
===
match
---
simple_stmt [24394,24475]
simple_stmt [24779,24860]
===
match
---
name: dagbag [5333,5339]
name: dagbag [5718,5724]
===
match
---
simple_stmt [16328,16392]
simple_stmt [16713,16777]
===
match
---
name: DummyOperator [16412,16425]
name: DummyOperator [16797,16810]
===
match
---
name: dagbag [4860,4866]
name: dagbag [5245,5251]
===
match
---
suite [34149,34659]
suite [34534,35044]
===
match
---
name: dag [10134,10137]
name: dag [10519,10522]
===
match
---
name: mock [30110,30114]
name: mock [30495,30499]
===
match
---
name: subdag_1 [24944,24952]
name: subdag_1 [25329,25337]
===
match
---
argument [16365,16390]
argument [16750,16775]
===
match
---
atom_expr [2276,2294]
atom_expr [2276,2294]
===
match
---
dictorsetmaker [4669,4708]
dictorsetmaker [5054,5093]
===
match
---
simple_stmt [33906,34089]
simple_stmt [34291,34474]
===
match
---
assert_stmt [34594,34658]
assert_stmt [34979,35043]
===
match
---
trailer [8168,8190]
trailer [8553,8575]
===
match
---
funcdef [15358,16866]
funcdef [15743,17251]
===
match
---
name: session [27908,27915]
name: session [28293,28300]
===
match
---
name: dag_folder [3012,3022]
name: dag_folder [3012,3022]
===
match
---
name: mock [29681,29685]
name: mock [30066,30070]
===
match
---
operator: , [10236,10237]
operator: , [10621,10622]
===
match
---
name: dagbag [12337,12343]
name: dagbag [12722,12728]
===
match
---
simple_stmt [20119,20135]
simple_stmt [20504,20520]
===
match
---
atom_expr [29408,29426]
atom_expr [29793,29811]
===
match
---
trailer [13888,13942]
trailer [14273,14327]
===
match
---
name: self [5268,5272]
name: self [5653,5657]
===
match
---
atom_expr [15029,15047]
atom_expr [15414,15432]
===
match
---
name: db [1710,1712]
name: db [1710,1712]
===
match
---
string: "example_bash_operator" [34223,34246]
string: "example_bash_operator" [34608,34631]
===
match
---
name: list [14369,14373]
name: list [14754,14758]
===
match
---
trailer [7568,7576]
trailer [7953,7961]
===
match
---
name: dags [29450,29454]
name: dags [29835,29839]
===
match
---
arglist [22075,22126]
arglist [22460,22511]
===
match
---
name: get [34219,34222]
name: get [34604,34607]
===
match
---
operator: = [34390,34391]
operator: = [34775,34776]
===
match
---
fstring_string: ):\n [37178,37182]
fstring_string: ):\n [37563,37567]
===
match
---
assert_stmt [8003,8040]
assert_stmt [8388,8425]
===
match
---
argument [13151,13173]
argument [13536,13558]
===
match
---
name: return_value [11710,11722]
name: return_value [12095,12107]
===
match
---
atom_expr [12487,12512]
atom_expr [12872,12897]
===
match
---
operator: , [15698,15699]
operator: , [16083,16084]
===
match
---
name: subdag_0 [20220,20228]
name: subdag_0 [20605,20613]
===
match
---
string: 'start_date' [22526,22538]
string: 'start_date' [22911,22923]
===
match
---
simple_stmt [12371,12400]
simple_stmt [12756,12785]
===
match
---
name: os [11610,11612]
name: os [11995,11997]
===
match
---
name: dagbag [36900,36906]
name: dagbag [37285,37291]
===
match
---
name: return_value [8600,8612]
name: return_value [8985,8997]
===
match
---
expr_stmt [31392,31442]
expr_stmt [31777,31827]
===
match
---
arglist [15170,15272]
arglist [15555,15657]
===
match
---
trailer [27815,27817]
trailer [28200,28202]
===
match
---
name: subdag [25117,25123]
name: subdag [25502,25508]
===
match
---
name: mock_session [30718,30730]
name: mock_session [31103,31115]
===
match
---
name: session [31774,31781]
name: session [32159,32166]
===
match
---
funcdef [2009,2071]
funcdef [2009,2071]
===
match
---
name: datetime [21250,21258]
name: datetime [21635,21643]
===
match
---
number: 1 [6281,6282]
number: 1 [6666,6667]
===
match
---
name: read_dags_from_db [27849,27866]
name: read_dags_from_db [28234,28251]
===
match
---
atom_expr [14096,14110]
atom_expr [14481,14495]
===
match
---
funcdef [8775,9055]
funcdef [9160,9440]
===
match
---
atom_expr [25293,25358]
atom_expr [25678,25743]
===
match
---
arglist [19954,20007]
arglist [20339,20392]
===
match
---
name: path [37672,37676]
name: path [38057,38061]
===
match
---
trailer [32947,32977]
trailer [33332,33362]
===
match
---
operator: = [16573,16574]
operator: = [16958,16959]
===
match
---
import_name [850,865]
import_name [850,865]
===
match
---
name: create_session [28355,28369]
name: create_session [28740,28754]
===
match
---
trailer [37681,37733]
trailer [38066,38118]
===
match
---
name: freeze_time [1073,1084]
name: freeze_time [1073,1084]
===
match
---
name: create_session [27060,27074]
name: create_session [27445,27459]
===
match
---
name: dag [12456,12459]
name: dag [12841,12844]
===
match
---
name: DagModel [27132,27140]
name: DagModel [27517,27525]
===
match
---
name: dagbag [27623,27629]
name: dagbag [28008,28014]
===
match
---
name: items [10113,10118]
name: items [10498,10503]
===
match
---
trailer [25991,26005]
trailer [26376,26390]
===
match
---
trailer [6189,6191]
trailer [6574,6576]
===
match
---
name: mock [29525,29529]
name: mock [29910,29914]
===
match
---
suite [23502,23713]
suite [23887,24098]
===
match
---
operator: , [36963,36964]
operator: , [37348,37349]
===
match
---
name: DagBag [4351,4357]
name: DagBag [4736,4742]
===
match
---
name: SerializedDAG [13234,13247]
name: SerializedDAG [13619,13632]
===
match
---
atom_expr [27527,27552]
atom_expr [27912,27937]
===
match
---
operator: = [3867,3868]
operator: = [4252,4253]
===
match
---
trailer [17108,17125]
trailer [17493,17510]
===
match
---
name: op_subdag_1 [20464,20475]
name: op_subdag_1 [20849,20860]
===
match
---
expr_stmt [9064,9107]
expr_stmt [9449,9492]
===
match
---
with_item [12815,12996]
with_item [13200,13381]
===
match
---
comp_op [12419,12425]
comp_op [12804,12810]
===
match
---
comp_op [13585,13591]
comp_op [13970,13976]
===
match
---
atom_expr [37013,37032]
atom_expr [37398,37417]
===
match
---
expr_stmt [15716,15762]
expr_stmt [16101,16147]
===
match
---
string: 'owner' [17584,17591]
string: 'owner' [17969,17976]
===
match
---
atom_expr [34539,34563]
atom_expr [34924,34948]
===
match
---
name: _TestDagBag [12097,12108]
name: _TestDagBag [12482,12493]
===
match
---
name: SubDagOperator [25156,25170]
name: SubDagOperator [25541,25555]
===
match
---
trailer [3720,3722]
trailer [4105,4107]
===
match
---
trailer [36915,36988]
trailer [37300,37373]
===
match
---
string: "test_zip_dag" [7577,7591]
string: "test_zip_dag" [7962,7976]
===
match
---
trailer [12108,12127]
trailer [12493,12512]
===
match
---
trailer [9003,9016]
trailer [9388,9401]
===
match
---
simple_stmt [20510,20538]
simple_stmt [20895,20923]
===
match
---
name: process_file [14168,14180]
name: process_file [14553,14565]
===
match
---
with_stmt [21586,21688]
with_stmt [21971,22073]
===
match
---
string: 'nested_cycle.op_subdag_1.opSubdag_D' [24409,24446]
string: 'nested_cycle.op_subdag_1.opSubdag_D' [24794,24831]
===
match
---
number: 2016 [21480,21484]
number: 2016 [21865,21869]
===
match
---
simple_stmt [8365,8488]
simple_stmt [8750,8873]
===
match
---
simple_stmt [15624,15704]
simple_stmt [16009,16089]
===
match
---
operator: , [20078,20079]
operator: , [20463,20464]
===
match
---
name: patch [32075,32080]
name: patch [32460,32465]
===
match
---
trailer [13363,13373]
trailer [13748,13758]
===
match
---
trailer [28415,28466]
trailer [28800,28851]
===
match
---
atom_expr [13299,13309]
atom_expr [13684,13694]
===
match
---
name: NamedTemporaryFile [13957,13975]
name: NamedTemporaryFile [14342,14360]
===
match
---
funcdef [26113,26354]
funcdef [26498,26739]
===
match
---
param [14264,14284]
param [14649,14669]
===
match
---
operator: , [34137,34138]
operator: , [34522,34523]
===
match
---
name: path [10523,10527]
name: path [10908,10912]
===
match
---
name: dag [31761,31764]
name: dag [32146,32149]
===
match
---
trailer [2292,2294]
trailer [2292,2294]
===
match
---
name: sqlalchemy [1118,1128]
name: sqlalchemy [1118,1128]
===
match
---
name: db [2117,2119]
name: db [2117,2119]
===
match
---
string: "/dev/null" [29336,29347]
string: "/dev/null" [29721,29732]
===
match
---
number: 0 [34827,34828]
number: 0 [35212,35213]
===
match
---
atom [3752,3775]
atom [4137,4160]
===
match
---
simple_stmt [26067,26108]
simple_stmt [26452,26493]
===
match
---
decorator [29010,29079]
decorator [29395,29464]
===
match
---
name: dag [16862,16865]
name: dag [17247,17250]
===
match
---
dotted_name [10215,10227]
dotted_name [10600,10612]
===
match
---
trailer [33246,33282]
trailer [33631,33667]
===
match
---
name: example_dags [36047,36059]
name: example_dags [36432,36444]
===
match
---
name: map [14374,14377]
name: map [14759,14762]
===
match
---
operator: = [17545,17546]
operator: = [17930,17931]
===
match
---
name: conf_vars [4658,4667]
name: conf_vars [5043,5052]
===
match
---
suite [21595,21688]
suite [21980,22073]
===
match
---
name: create_session [27437,27451]
name: create_session [27822,27836]
===
match
---
argument [30020,30036]
argument [30405,30421]
===
match
---
trailer [6537,6542]
trailer [6922,6927]
===
match
---
string: 'foo' [8678,8683]
string: 'foo' [9063,9068]
===
match
---
name: include_examples [13127,13143]
name: include_examples [13512,13528]
===
match
---
trailer [3392,3394]
trailer [3777,3779]
===
match
---
name: models [1330,1336]
name: models [1330,1336]
===
match
---
number: 20 [31560,31562]
number: 20 [31945,31947]
===
match
---
argument [26731,26745]
argument [27116,27130]
===
match
---
name: path [3981,3985]
name: path [4366,4370]
===
match
---
number: 0 [35415,35416]
number: 0 [35800,35801]
===
match
---
parameters [3439,3445]
parameters [3824,3830]
===
match
---
name: f [3634,3635]
name: f [4019,4020]
===
match
---
name: include_examples [5284,5300]
name: include_examples [5669,5685]
===
match
---
trailer [26005,26058]
trailer [26390,26443]
===
match
---
operator: = [17664,17665]
operator: = [18049,18050]
===
match
---
operator: , [22562,22563]
operator: , [22947,22948]
===
match
---
name: encode [14011,14017]
name: encode [14396,14402]
===
match
---
name: new_dagbag [36188,36198]
name: new_dagbag [36573,36583]
===
match
---
simple_stmt [7397,7471]
simple_stmt [7782,7856]
===
match
---
name: dagbag [6390,6396]
name: dagbag [6775,6781]
===
match
---
name: dags_last_fetched [13599,13616]
name: dags_last_fetched [13984,14001]
===
match
---
assert_stmt [6583,6616]
assert_stmt [6968,7001]
===
match
---
string: 'nested_cycle.op_subdag_0.opSubdag_A' [23538,23575]
string: 'nested_cycle.op_subdag_0.opSubdag_A' [23923,23960]
===
match
---
name: NamedTemporaryFile [3578,3596]
name: NamedTemporaryFile [3963,3981]
===
match
---
trailer [27561,27563]
trailer [27946,27948]
===
match
---
name: format [14841,14847]
name: format [15226,15232]
===
match
---
operator: , [24776,24777]
operator: , [25161,25162]
===
match
---
name: subdag_1 [16492,16500]
name: subdag_1 [16877,16885]
===
match
---
trailer [14463,14491]
trailer [14848,14876]
===
match
---
name: task_id [18920,18927]
name: task_id [19305,19312]
===
match
---
name: keys [26676,26680]
name: keys [27061,27065]
===
match
---
operator: } [33507,33508]
operator: } [33892,33893]
===
match
---
funcdef [13672,14235]
funcdef [14057,14620]
===
match
---
operator: = [14128,14129]
operator: = [14513,14514]
===
match
---
expr_stmt [26546,26584]
expr_stmt [26931,26969]
===
match
---
name: op_a [21682,21686]
name: op_a [22067,22071]
===
match
---
string: "airflow.models.serialized_dag.SerializedDagModel.write_dag" [29017,29077]
string: "airflow.models.serialized_dag.SerializedDagModel.write_dag" [29402,29462]
===
match
---
param [2869,2873]
param [2869,2873]
===
match
---
operator: { [7099,7100]
operator: { [7484,7485]
===
match
---
operator: = [4627,4628]
operator: = [5012,5013]
===
match
---
operator: = [3818,3819]
operator: = [4203,4204]
===
match
---
assert_stmt [13625,13666]
assert_stmt [14010,14051]
===
match
---
name: subdag_0 [19737,19745]
name: subdag_0 [20122,20130]
===
match
---
operator: , [27730,27731]
operator: , [28115,28116]
===
match
---
name: SubDagOperator [17508,17522]
name: SubDagOperator [17893,17907]
===
match
---
name: call [30313,30317]
name: call [30698,30702]
===
match
---
name: mock_serialize [28293,28307]
name: mock_serialize [28678,28692]
===
match
---
trailer [34628,34637]
trailer [35013,35022]
===
match
---
atom_expr [11610,11686]
atom_expr [11995,12071]
===
match
---
operator: , [8141,8142]
operator: , [8526,8527]
===
match
---
name: default_args [15749,15761]
name: default_args [16134,16146]
===
match
---
parameters [12567,12584]
parameters [12952,12969]
===
match
---
atom_expr [8538,8564]
atom_expr [8923,8949]
===
match
---
trailer [26270,26280]
trailer [26655,26665]
===
match
---
simple_stmt [27263,27424]
simple_stmt [27648,27809]
===
match
---
trailer [3949,3962]
trailer [4334,4347]
===
match
---
funcdef [22215,25628]
funcdef [22600,26013]
===
match
---
simple_stmt [6112,6142]
simple_stmt [6497,6527]
===
match
---
simple_stmt [6376,6402]
simple_stmt [6761,6787]
===
match
---
simple_stmt [28186,28285]
simple_stmt [28571,28670]
===
match
---
name: inspect [13889,13896]
name: inspect [14274,14281]
===
match
---
operator: = [24784,24785]
operator: = [25169,25170]
===
match
---
string: "can_read" [33654,33664]
string: "can_read" [34039,34049]
===
match
---
name: include_examples [9607,9623]
name: include_examples [9992,10008]
===
match
---
atom_expr [37440,37471]
atom_expr [37825,37856]
===
match
---
trailer [8955,8974]
trailer [9340,9359]
===
match
---
trailer [31065,31073]
trailer [31450,31458]
===
match
---
simple_stmt [20395,20428]
simple_stmt [20780,20813]
===
match
---
funcdef [2206,2333]
funcdef [2206,2333]
===
match
---
name: found_2 [6479,6486]
name: found_2 [6864,6871]
===
match
---
arglist [21515,21550]
arglist [21900,21935]
===
match
---
name: task_id [25081,25088]
name: task_id [25466,25473]
===
match
---
atom [4669,4692]
atom [5054,5077]
===
match
---
operator: = [34207,34208]
operator: = [34592,34593]
===
match
---
name: models [15435,15441]
name: models [15820,15826]
===
match
---
operator: = [16669,16670]
operator: = [17054,17055]
===
match
---
operator: , [25840,25841]
operator: , [26225,26226]
===
match
---
name: empty_dir [1965,1974]
name: empty_dir [1965,1974]
===
match
---
number: 1 [31119,31120]
number: 1 [31504,31505]
===
match
---
name: dag [16225,16228]
name: dag [16610,16613]
===
match
---
comparison [36507,36558]
comparison [36892,36943]
===
match
---
operator: , [24061,24062]
operator: , [24446,24447]
===
match
---
suite [6680,7217]
suite [7065,7602]
===
match
---
name: name [5355,5359]
name: name [5740,5744]
===
match
---
name: dag [19976,19979]
name: dag [20361,20364]
===
match
---
name: OperationalError [1140,1156]
name: OperationalError [1140,1156]
===
match
---
name: mock_session [30268,30280]
name: mock_session [30653,30665]
===
match
---
atom_expr [27933,27958]
atom_expr [28318,28343]
===
match
---
name: example_dags [35922,35934]
name: example_dags [36307,36319]
===
match
---
name: encoding [6023,6031]
name: encoding [6408,6416]
===
match
---
name: dag [14545,14548]
name: dag [14930,14933]
===
match
---
trailer [11806,11827]
trailer [12191,12212]
===
match
---
comparison [7092,7206]
comparison [7477,7591]
===
match
---
string: "example_bash_operator" [10461,10484]
string: "example_bash_operator" [10846,10869]
===
match
---
name: dag [18945,18948]
name: dag [19330,19333]
===
match
---
param [32166,32171]
param [32551,32556]
===
match
---
trailer [13277,13295]
trailer [13662,13680]
===
match
---
funcdef [12518,13667]
funcdef [12903,14052]
===
match
---
string: """         Test that we're able to parse some example DAGs and retrieve them         """ [2379,2468]
string: """         Test that we're able to parse some example DAGs and retrieve them         """ [2379,2468]
===
match
---
atom_expr [26328,26353]
atom_expr [26713,26738]
===
match
---
name: operators [21328,21337]
name: operators [21713,21722]
===
match
---
import_from [22388,22439]
import_from [22773,22824]
===
match
---
trailer [38094,38140]
trailer [38479,38525]
===
match
---
argument [31196,31270]
argument [31581,31655]
===
match
---
string: 'nested_cycle.op_subdag_1.opSubdag_C' [24024,24061]
string: 'nested_cycle.op_subdag_1.opSubdag_C' [24409,24446]
===
match
---
name: DagModel [11407,11415]
name: DagModel [11792,11800]
===
match
---
name: freeze_time [35379,35390]
name: freeze_time [35764,35775]
===
match
---
name: default_args [25019,25031]
name: default_args [25404,25416]
===
match
---
trailer [11639,11685]
trailer [12024,12070]
===
match
---
simple_stmt [25617,25628]
simple_stmt [26002,26013]
===
match
---
arglist [25171,25224]
arglist [25556,25609]
===
match
---
operator: , [17086,17087]
operator: , [17471,17472]
===
match
---
name: func [27922,27926]
name: func [28307,28311]
===
match
---
operator: == [15062,15064]
operator: == [15447,15449]
===
match
---
trailer [25870,25882]
trailer [26255,26267]
===
match
---
string: "test_example_bash_operator" [33247,33275]
string: "test_example_bash_operator" [33632,33660]
===
match
---
atom_expr [13881,13942]
atom_expr [14266,14327]
===
match
---
trailer [3145,3166]
trailer [3145,3166]
===
match
---
atom_expr [8641,8675]
atom_expr [9026,9060]
===
match
---
name: dagbag_stats [4867,4879]
name: dagbag_stats [5252,5264]
===
match
---
arglist [16547,16596]
arglist [16932,16981]
===
match
---
simple_stmt [28838,28871]
simple_stmt [29223,29256]
===
match
---
name: dag [13377,13380]
name: dag [13762,13765]
===
match
---
parameters [16304,16306]
parameters [16689,16691]
===
match
---
comparison [28890,28917]
comparison [29275,29302]
===
match
---
atom_expr [4344,4397]
atom_expr [4729,4782]
===
match
---
atom_expr [4582,4634]
atom_expr [4967,5019]
===
match
---
trailer [14652,14676]
trailer [15037,15061]
===
match
---
name: dagbag [11252,11258]
name: dagbag [11637,11643]
===
match
---
trailer [12161,12163]
trailer [12546,12548]
===
match
---
dotted_name [1822,1850]
dotted_name [1822,1850]
===
match
---
decorated [33686,35795]
decorated [34071,36180]
===
match
---
operator: = [33483,33484]
operator: = [33868,33869]
===
match
---
assert_stmt [9236,9273]
assert_stmt [9621,9658]
===
match
---
name: dagbag [28480,28486]
name: dagbag [28865,28871]
===
match
---
operator: , [35085,35086]
operator: , [35470,35471]
===
match
---
atom_expr [33078,33125]
atom_expr [33463,33510]
===
match
---
parameters [13687,13705]
parameters [14072,14090]
===
match
---
atom_expr [14181,14187]
atom_expr [14566,14572]
===
match
---
dotted_name [1644,1656]
dotted_name [1644,1656]
===
match
---
name: dagbag [20925,20931]
name: dagbag [21310,21316]
===
match
---
atom [35144,35155]
atom [35529,35540]
===
match
---
name: dagbag [9638,9644]
name: dagbag [10023,10029]
===
match
---
expr_stmt [29408,29434]
expr_stmt [29793,29819]
===
match
---
operator: , [34642,34643]
operator: , [35027,35028]
===
match
---
name: dagbag [6337,6343]
name: dagbag [6722,6728]
===
match
---
simple_stmt [11200,11238]
simple_stmt [11585,11623]
===
match
---
name: should_be_found [26036,26051]
name: should_be_found [26421,26436]
===
match
---
name: delete_dag_specific_permissions [1858,1889]
name: delete_dag_specific_permissions [1858,1889]
===
match
---
name: dagbag [7920,7926]
name: dagbag [8305,8311]
===
match
---
name: subdag_0 [19647,19655]
name: subdag_0 [20032,20040]
===
match
---
argument [29552,29565]
argument [29937,29950]
===
match
---
number: 2020 [31113,31117]
number: 2020 [31498,31502]
===
match
---
name: len [4811,4814]
name: len [5196,5199]
===
match
---
name: _sync_perms [33330,33341]
name: _sync_perms [33715,33726]
===
match
---
argument [3617,3629]
argument [4002,4014]
===
match
---
trailer [10532,10581]
trailer [10917,10966]
===
match
---
funcdef [29137,30757]
funcdef [29522,31142]
===
match
---
name: return_value [10606,10618]
name: return_value [10991,11003]
===
match
---
operator: = [14367,14368]
operator: = [14752,14753]
===
match
---
import_from [1681,1712]
import_from [1681,1712]
===
match
---
name: TEST_DAGS_FOLDER [1664,1680]
name: TEST_DAGS_FOLDER [1664,1680]
===
match
---
name: self [36679,36683]
name: self [37064,37068]
===
match
---
name: dag_id [26593,26599]
name: dag_id [26978,26984]
===
match
---
comparison [7608,7634]
comparison [7993,8019]
===
match
---
name: tick [31555,31559]
name: tick [31940,31944]
===
match
---
simple_stmt [13010,13042]
simple_stmt [13395,13427]
===
match
---
suite [15320,20990]
suite [15705,21375]
===
match
---
trailer [29814,29836]
trailer [30199,30221]
===
match
---
name: subdag_0 [19522,19530]
name: subdag_0 [19907,19915]
===
match
---
atom [5837,5920]
atom [6222,6305]
===
match
---
name: should_be_found [14319,14334]
name: should_be_found [14704,14719]
===
match
---
name: self [4301,4305]
name: self [4686,4690]
===
match
---
name: DagBag [2493,2499]
name: DagBag [2493,2499]
===
match
---
simple_stmt [11744,11828]
simple_stmt [12129,12213]
===
match
---
funcdef [5366,6639]
funcdef [5751,7024]
===
match
---
simple_stmt [10592,10632]
simple_stmt [10977,11017]
===
match
---
atom_expr [25866,25903]
atom_expr [26251,26288]
===
match
---
atom_expr [11786,11827]
atom_expr [12171,12212]
===
match
---
dictorsetmaker [13198,13261]
dictorsetmaker [13583,13646]
===
match
---
name: mock_dagmodel [10287,10300]
name: mock_dagmodel [10672,10685]
===
match
---
name: empty_dir [4699,4708]
name: empty_dir [5084,5093]
===
match
---
name: path [28524,28528]
name: path [28909,28913]
===
match
---
trailer [25403,25454]
trailer [25788,25839]
===
match
---
expr_stmt [11929,11951]
expr_stmt [12314,12336]
===
match
---
trailer [35393,35402]
trailer [35778,35787]
===
match
---
trailer [11709,11722]
trailer [12094,12107]
===
match
---
trailer [29372,29382]
trailer [29757,29767]
===
match
---
name: mock [30000,30004]
name: mock [30385,30389]
===
match
---
operator: = [35502,35503]
operator: = [35887,35888]
===
match
---
name: task_id [24742,24749]
name: task_id [25127,25134]
===
match
---
expr_stmt [26232,26305]
expr_stmt [26617,26690]
===
match
---
fstring_end: " [4003,4004]
fstring_end: " [4388,4389]
===
match
---
operator: = [4784,4785]
operator: = [5169,5170]
===
match
---
with_item [13957,13982]
with_item [14342,14367]
===
match
---
operator: , [33842,33843]
operator: , [34227,34228]
===
match
---
name: fileloc [10493,10500]
name: fileloc [10878,10885]
===
match
---
expr_stmt [7397,7470]
expr_stmt [7782,7855]
===
match
---
simple_stmt [4804,4841]
simple_stmt [5189,5226]
===
match
---
simple_stmt [35116,35156]
simple_stmt [35501,35541]
===
match
---
name: os [28403,28405]
name: os [28788,28790]
===
match
---
simple_stmt [26904,26948]
simple_stmt [27289,27333]
===
match
---
import_from [22283,22313]
import_from [22668,22698]
===
match
---
operator: = [36162,36163]
operator: = [36547,36548]
===
match
---
number: 0 [34653,34654]
number: 0 [35038,35039]
===
match
---
name: mock_s10n_write_dag [29197,29216]
name: mock_s10n_write_dag [29582,29601]
===
match
---
name: dagbag [6590,6596]
name: dagbag [6975,6981]
===
match
---
trailer [5352,5360]
trailer [5737,5745]
===
match
---
funcdef [24358,24584]
funcdef [24743,24969]
===
match
---
operator: , [24678,24679]
operator: , [25063,25064]
===
match
---
name: model_before [26963,26975]
name: model_before [27348,27360]
===
match
---
string: "test_example_bash_operator.py" [27698,27729]
string: "test_example_bash_operator.py" [28083,28114]
===
match
---
name: task_id [25308,25315]
name: task_id [25693,25700]
===
match
---
name: dir [3597,3600]
name: dir [3982,3985]
===
match
---
operator: = [6031,6032]
operator: = [6416,6417]
===
match
---
name: SerializationError [28322,28340]
name: SerializationError [28707,28725]
===
match
---
name: airflow [1278,1285]
name: airflow [1278,1285]
===
match
---
name: include_examples [32880,32896]
name: include_examples [33265,33281]
===
match
---
name: example_bash_op_dag [34539,34558]
name: example_bash_op_dag [34924,34943]
===
match
---
name: safe_mode [3858,3867]
name: safe_mode [4243,4252]
===
match
---
name: self [5559,5563]
name: self [5944,5948]
===
match
---
name: process_dag [20738,20749]
name: process_dag [21123,21134]
===
match
---
expr_stmt [25375,25454]
expr_stmt [25760,25839]
===
match
---
name: task_id [21633,21640]
name: task_id [22018,22025]
===
match
---
comp_op [11294,11300]
comp_op [11679,11685]
===
match
---
subscript [13936,13940]
subscript [14321,14325]
===
match
---
operator: = [24985,24986]
operator: = [25370,25371]
===
match
---
atom_expr [16682,16692]
atom_expr [17067,17077]
===
match
---
simple_stmt [800,815]
simple_stmt [800,815]
===
match
---
comparison [9243,9273]
comparison [9628,9658]
===
match
---
atom_expr [31543,31563]
atom_expr [31928,31948]
===
match
---
name: mock [30065,30069]
name: mock [30450,30454]
===
match
---
name: dagbag [4815,4821]
name: dagbag [5200,5206]
===
match
---
name: datetime [34629,34637]
name: datetime [35014,35022]
===
match
---
string: 'owner1' [22516,22524]
string: 'owner1' [22901,22909]
===
match
---
name: dag_folder [2500,2510]
name: dag_folder [2500,2510]
===
match
---
name: dag [20208,20211]
name: dag [20593,20596]
===
match
---
simple_stmt [6885,6948]
simple_stmt [7270,7333]
===
match
---
for_stmt [36345,36559]
for_stmt [36730,36944]
===
match
---
name: dag_folder [3314,3324]
name: dag_folder [3699,3709]
===
match
---
name: process_file_calls [12344,12362]
name: process_file_calls [12729,12747]
===
match
---
operator: = [21640,21641]
operator: = [22025,22026]
===
match
---
trailer [24831,24886]
trailer [25216,25271]
===
match
---
atom_expr [8944,8974]
atom_expr [9329,9359]
===
match
---
argument [25340,25357]
argument [25725,25742]
===
match
---
name: super [12156,12161]
name: super [12541,12546]
===
match
---
name: dagbag [9557,9563]
name: dagbag [9942,9948]
===
match
---
atom_expr [11212,11237]
atom_expr [11597,11622]
===
match
---
atom_expr [37988,38015]
atom_expr [38373,38400]
===
match
---
name: import_errors [26094,26107]
name: import_errors [26479,26492]
===
match
---
param [4048,4052]
param [4433,4437]
===
match
---
simple_stmt [31974,31988]
simple_stmt [32359,32373]
===
match
---
atom [35691,35725]
atom [36076,36110]
===
match
---
name: len [8165,8168]
name: len [8550,8553]
===
match
---
atom_expr [13574,13584]
atom_expr [13959,13969]
===
match
---
name: tf_1 [6070,6074]
name: tf_1 [6455,6459]
===
match
---
atom_expr [6235,6244]
atom_expr [6620,6629]
===
match
---
name: sync_to_db [27805,27815]
name: sync_to_db [28190,28200]
===
match
---
atom [37847,37878]
atom [38232,38263]
===
match
---
number: 2 [12482,12483]
number: 2 [12867,12868]
===
match
---
trailer [25541,25554]
trailer [25926,25939]
===
match
---
trailer [7511,7545]
trailer [7896,7930]
===
match
---
name: merge [26809,26814]
name: merge [27194,27199]
===
match
---
name: default_args [23577,23589]
name: default_args [23962,23974]
===
match
---
expr_stmt [16518,16597]
expr_stmt [16903,16982]
===
match
---
atom_expr [2303,2332]
atom_expr [2303,2332]
===
match
---
simple_stmt [36082,36116]
simple_stmt [36467,36501]
===
match
---
name: f [13996,13997]
name: f [14381,14382]
===
match
---
trailer [17625,17634]
trailer [18010,18019]
===
match
---
simple_stmt [22136,22177]
simple_stmt [22521,22562]
===
match
---
arglist [12965,12977]
arglist [13350,13362]
===
match
---
param [21020,21024]
param [21405,21409]
===
match
---
name: only_if_updated [10894,10909]
name: only_if_updated [11279,11294]
===
match
---
expr_stmt [36398,36431]
expr_stmt [36783,36816]
===
match
---
operator: , [8339,8340]
operator: , [8724,8725]
===
match
---
expr_stmt [38071,38140]
expr_stmt [38456,38525]
===
match
---
suite [27254,28020]
suite [27639,28405]
===
match
---
trailer [30119,30147]
trailer [30504,30532]
===
match
---
operator: = [33116,33117]
operator: = [33501,33502]
===
match
---
expr_stmt [32580,32657]
expr_stmt [32965,33042]
===
match
---
name: DagBag [31172,31178]
name: DagBag [31557,31563]
===
match
---
funcdef [16066,16275]
funcdef [16451,16660]
===
match
---
trailer [16829,16842]
trailer [17214,17227]
===
match
---
atom_expr [34392,34432]
atom_expr [34777,34817]
===
match
---
name: only_if_updated [11083,11098]
name: only_if_updated [11468,11483]
===
match
---
operator: = [7927,7928]
operator: = [8312,8313]
===
match
---
name: copy [871,875]
name: copy [871,875]
===
match
---
name: dag [35197,35200]
name: dag [35582,35585]
===
match
---
operator: @ [36564,36565]
operator: @ [36949,36950]
===
match
---
trailer [3985,3994]
trailer [4370,4379]
===
match
---
operator: , [2607,2608]
operator: , [2607,2608]
===
insert-node
---
name: TestDagBag [1898,1908]
to
classdef [1892,38342]
at 0
===
insert-tree
---
funcdef [3180,3560]
    name: test_serialized_dag_not_existing_doesnt_raise [3184,3229]
    parameters [3229,3235]
        param [3230,3234]
            name: self [3230,3234]
    suite [3236,3560]
        simple_stmt [3245,3342]
            string: """         test that retrieving a non existing dag id returns None without crashing         """ [3245,3341]
        simple_stmt [3350,3448]
            expr_stmt [3350,3447]
                name: dagbag [3350,3356]
                operator: = [3357,3358]
                atom_expr [3359,3447]
                    name: models [3359,3365]
                    trailer [3365,3372]
                        name: DagBag [3366,3372]
                    trailer [3372,3447]
                        arglist [3373,3446]
                            argument [3373,3398]
                                name: dag_folder [3373,3383]
                                operator: = [3383,3384]
                                atom_expr [3384,3398]
                                    name: self [3384,3388]
                                    trailer [3388,3398]
                                        name: empty_dir [3389,3398]
                            operator: , [3398,3399]
                            argument [3400,3422]
                                name: include_examples [3400,3416]
                                operator: = [3416,3417]
                            operator: , [3422,3423]
                            argument [3424,3446]
                                name: read_dags_from_db [3424,3441]
                                operator: = [3441,3442]
        simple_stmt [3457,3501]
            expr_stmt [3457,3500]
                name: non_existing_dag_id [3457,3476]
                operator: = [3477,3478]
                string: "non_existing_dag_id" [3479,3500]
        simple_stmt [3509,3560]
            assert_stmt [3509,3559]
                comparison [3516,3559]
                    atom_expr [3516,3551]
                        name: dagbag [3516,3522]
                        trailer [3522,3530]
                            name: get_dag [3523,3530]
                        trailer [3530,3551]
                            name: non_existing_dag_id [3531,3550]
to
suite [1909,38342]
at 6
===
delete-node
---
name: TestDagBag [1898,1908]
===
