===
match
---
atom_expr [7845,7868]
atom_expr [7792,7815]
===
match
---
name: Exception [25696,25705]
name: Exception [25643,25652]
===
match
---
string: "Exiting gracefully upon receiving signal %s" [6294,6339]
string: "Exiting gracefully upon receiving signal %s" [6241,6286]
===
match
---
atom_expr [45319,45325]
atom_expr [44458,44464]
===
match
---
trailer [42791,42798]
trailer [41930,41937]
===
match
---
name: list [36861,36865]
name: list [36086,36090]
===
match
---
param [30022,30029]
param [29969,29976]
===
match
---
expr_stmt [49382,49403]
expr_stmt [48521,48542]
===
match
---
suite [28282,28527]
suite [28229,28474]
===
match
---
operator: , [23774,23775]
operator: , [23721,23722]
===
match
---
tfpdef [44011,44026]
tfpdef [43150,43165]
===
match
---
atom_expr [31933,31990]
atom_expr [31880,31937]
===
match
---
atom_expr [5833,5884]
atom_expr [5780,5831]
===
match
---
annassign [7522,7590]
annassign [7469,7537]
===
match
---
comparison [17516,17539]
comparison [17463,17486]
===
match
---
name: task_instance_str [17486,17503]
name: task_instance_str [17433,17450]
===
match
---
arglist [23417,23584]
arglist [23364,23531]
===
match
---
atom_expr [20323,20390]
atom_expr [20270,20337]
===
match
---
name: in_ [8512,8515]
name: in_ [8459,8462]
===
match
---
name: info [26193,26197]
name: info [26140,26144]
===
match
---
arglist [44205,44236]
arglist [43344,43375]
===
match
---
trailer [27521,27544]
trailer [27468,27491]
===
match
---
name: debug [33653,33658]
name: debug [32878,32883]
===
match
---
name: FAILED [42134,42140]
name: FAILED [41273,41279]
===
match
---
name: join [10443,10447]
name: join [10390,10394]
===
match
---
simple_stmt [1875,1907]
simple_stmt [1822,1854]
===
match
---
atom_expr [10373,10396]
atom_expr [10320,10343]
===
match
---
name: int [12085,12088]
name: int [12032,12035]
===
match
---
trailer [37653,37676]
trailer [36835,36858]
===
match
---
expr_stmt [12254,12279]
expr_stmt [12201,12226]
===
match
---
name: set_state [23194,23203]
name: set_state [23141,23150]
===
match
---
operator: - [47498,47499]
operator: - [46637,46638]
===
match
---
name: max_active_tasks_per_dag_limit [14848,14878]
name: max_active_tasks_per_dag_limit [14795,14825]
===
match
---
suite [37435,37560]
suite [36621,36742]
===
match
---
arglist [41856,41908]
arglist [40995,41047]
===
match
---
simple_stmt [50314,50330]
simple_stmt [49453,49469]
===
match
---
trailer [21847,21869]
trailer [21794,21816]
===
match
---
atom_expr [46814,46850]
atom_expr [45953,45989]
===
match
---
trailer [18731,18812]
trailer [18678,18759]
===
match
---
atom_expr [39609,39645]
atom_expr [38791,38827]
===
match
---
name: creating_job_id [38747,38762]
name: creating_job_id [37929,37944]
===
match
---
name: next_dagrun [36066,36077]
name: next_dagrun [35291,35302]
===
match
---
argument [46834,46849]
argument [45973,45988]
===
match
---
name: dag_id [36669,36675]
name: dag_id [35894,35900]
===
match
---
operator: , [7868,7869]
operator: , [7815,7816]
===
match
---
atom [17855,17944]
atom [17802,17891]
===
match
---
name: TI [17608,17610]
name: TI [17555,17557]
===
match
---
trailer [21257,21529]
trailer [21204,21476]
===
match
---
raise_stmt [20675,20726]
raise_stmt [20622,20673]
===
match
---
name: run_id [21450,21456]
name: run_id [21397,21403]
===
match
---
operator: = [48990,48991]
operator: = [48129,48130]
===
match
---
name: processor_agent [20646,20661]
name: processor_agent [20593,20608]
===
match
---
arglist [18558,18619]
arglist [18505,18566]
===
match
---
operator: = [13213,13214]
operator: = [13160,13161]
===
match
---
trailer [17284,17335]
trailer [17231,17282]
===
match
---
trailer [45905,45907]
trailer [45044,45046]
===
match
---
name: dag [23028,23031]
name: dag [22975,22978]
===
match
---
param [20545,20550]
param [20492,20497]
===
match
---
testlist_comp [47897,47924]
testlist_comp [47036,47063]
===
match
---
name: log [33649,33652]
name: log [32874,32877]
===
match
---
name: data_interval [38905,38918]
name: data_interval [38087,38100]
===
match
---
name: QUEUED [38550,38556]
name: QUEUED [37732,37738]
===
match
---
simple_stmt [46424,46641]
simple_stmt [45563,45780]
===
match
---
name: args [5189,5193]
name: args [5136,5140]
===
match
---
if_stmt [26886,26979]
if_stmt [26833,26926]
===
match
---
atom_expr [28877,28946]
atom_expr [28824,28893]
===
match
---
suite [26264,29992]
suite [26211,29939]
===
match
---
trailer [28324,28339]
trailer [28271,28286]
===
match
---
name: State [51099,51104]
name: State [50238,50243]
===
match
---
name: task_concurrency_map [12124,12144]
name: task_concurrency_map [12071,12091]
===
match
---
operator: , [10036,10037]
operator: , [9983,9984]
===
match
---
name: callback_tuples [32839,32854]
name: callback_tuples [32240,32255]
===
match
---
tfpdef [35335,35367]
tfpdef [34560,34592]
===
match
---
simple_stmt [43291,43300]
simple_stmt [42430,42439]
===
match
---
name: debug [45381,45386]
name: debug [44520,44525]
===
match
---
name: ti_key [21213,21219]
name: ti_key [21160,21166]
===
match
---
name: models [2536,2542]
name: models [2483,2489]
===
match
---
simple_stmt [21024,21035]
simple_stmt [20971,20982]
===
match
---
operator: = [44160,44161]
operator: = [43299,43300]
===
match
---
exprlist [20973,20986]
exprlist [20920,20933]
===
match
---
expr_stmt [16857,16895]
expr_stmt [16804,16842]
===
match
---
operator: , [24805,24806]
operator: , [24752,24753]
===
match
---
operator: == [22285,22287]
operator: == [22232,22234]
===
match
---
trailer [31851,31873]
trailer [31798,31820]
===
match
---
trailer [42034,42045]
trailer [41173,41184]
===
match
---
trailer [39608,39646]
trailer [38790,38828]
===
match
---
name: self [51364,51368]
name: self [50503,50507]
===
match
---
operator: , [21582,21583]
operator: , [21529,21530]
===
match
---
expr_stmt [20233,20301]
expr_stmt [20180,20248]
===
match
---
if_stmt [17513,18003]
if_stmt [17460,17950]
===
match
---
operator: , [18154,18155]
operator: , [18101,18102]
===
match
---
operator: , [1080,1081]
operator: , [1080,1081]
===
match
---
simple_stmt [9362,9392]
simple_stmt [9309,9339]
===
match
---
operator: < [42046,42047]
operator: < [41185,41186]
===
match
---
name: DR [2556,2558]
name: DR [2503,2505]
===
match
---
name: pool_slots_free [10038,10053]
name: pool_slots_free [9985,10000]
===
match
---
name: max_tis [10029,10036]
name: max_tis [9976,9983]
===
match
---
argument [49039,49044]
argument [48178,48183]
===
match
---
trailer [23570,23576]
trailer [23517,23523]
===
match
---
name: self [7831,7835]
name: self [7778,7782]
===
match
---
name: TI [42242,42244]
name: TI [41381,41383]
===
match
---
testlist_comp [8862,8877]
testlist_comp [8809,8824]
===
match
---
name: signal [5954,5960]
name: signal [5901,5907]
===
match
---
name: debug [41053,41058]
name: debug [40192,40197]
===
match
---
factor [13226,13245]
factor [13173,13192]
===
match
---
except_clause [25899,25915]
except_clause [25846,25862]
===
match
---
operator: = [21892,21893]
operator: = [21839,21840]
===
match
---
operator: = [46259,46260]
operator: = [45398,45399]
===
match
---
suite [41027,41290]
suite [40166,40429]
===
match
---
atom_expr [23816,23833]
atom_expr [23763,23780]
===
match
---
trailer [25884,25886]
trailer [25831,25833]
===
match
---
operator: , [14751,14752]
operator: , [14698,14699]
===
match
---
name: sql_conn [5445,5453]
name: sql_conn [5392,5400]
===
match
---
atom_expr [39294,39306]
atom_expr [38476,38488]
===
match
---
trailer [21934,21942]
trailer [21881,21889]
===
match
---
name: dag_id [16937,16943]
name: dag_id [16884,16890]
===
match
---
dotted_name [2422,2441]
dotted_name [2369,2388]
===
match
---
comparison [33512,33546]
comparison [32737,32771]
===
match
---
name: dag_id [40559,40565]
name: dag_id [39741,39747]
===
match
---
name: dag_model [14181,14190]
name: dag_model [14128,14137]
===
match
---
name: dag_id [8780,8786]
name: dag_id [8727,8733]
===
match
---
name: processor_agent [24534,24549]
name: processor_agent [24481,24496]
===
match
---
operator: , [23520,23521]
operator: , [23467,23468]
===
match
---
testlist_star_expr [8771,8793]
testlist_star_expr [8718,8740]
===
match
---
expr_stmt [39326,39775]
expr_stmt [38508,38957]
===
match
---
name: get [5320,5323]
name: get [5267,5270]
===
match
---
operator: = [24634,24635]
operator: = [24581,24582]
===
match
---
import_as_names [2343,2416]
import_as_names [2290,2363]
===
match
---
expr_stmt [37634,37687]
expr_stmt [36816,36869]
===
match
---
trailer [9938,9942]
trailer [9885,9889]
===
match
---
simple_stmt [4723,4748]
simple_stmt [4670,4695]
===
match
---
atom_expr [43205,43278]
atom_expr [42344,42417]
===
match
---
name: priority_sorted_task_instances [13374,13404]
name: priority_sorted_task_instances [13321,13351]
===
match
---
string: 'core' [5324,5330]
string: 'core' [5271,5277]
===
match
---
name: TI [18177,18179]
name: TI [18124,18126]
===
match
---
operator: = [49574,49575]
operator: = [48713,48714]
===
match
---
trailer [26046,26050]
trailer [25993,25997]
===
match
---
trailer [10938,10942]
trailer [10885,10889]
===
match
---
name: num_starving_tasks [16591,16609]
name: num_starving_tasks [16538,16556]
===
match
---
name: dag_run [43355,43362]
name: dag_run [42494,42501]
===
match
---
name: Dict [20769,20773]
name: Dict [20716,20720]
===
match
---
string: "Ran scheduling loop in %.2f seconds" [28892,28929]
string: "Ran scheduling loop in %.2f seconds" [28839,28876]
===
match
---
atom [15703,15748]
atom [15650,15695]
===
match
---
atom_expr [8547,8557]
atom_expr [8494,8504]
===
match
---
trailer [31900,31907]
trailer [31847,31854]
===
match
---
suite [45908,46187]
suite [45047,45326]
===
match
---
name: self [6878,6882]
name: self [6825,6829]
===
match
---
operator: , [42633,42634]
operator: , [41772,41773]
===
match
---
name: trigger_timeout [50870,50885]
name: trigger_timeout [50009,50024]
===
match
---
testlist_comp [32863,32887]
testlist_comp [32264,32288]
===
match
---
trailer [50903,50905]
trailer [50042,50044]
===
match
---
arglist [22839,22869]
arglist [22786,22816]
===
match
---
name: TI [10448,10450]
name: TI [10395,10397]
===
match
---
operator: , [51430,51431]
operator: , [50569,50570]
===
match
---
name: _do_scheduling [28325,28339]
name: _do_scheduling [28272,28286]
===
match
---
atom_expr [41841,41909]
atom_expr [40980,41048]
===
match
---
argument [43542,43565]
argument [42681,42704]
===
match
---
name: executor [20276,20284]
name: executor [20223,20231]
===
match
---
trailer [17871,17878]
trailer [17818,17825]
===
match
---
name: _create_dag_runs [35137,35153]
name: _create_dag_runs [34362,34378]
===
match
---
suite [7967,8921]
suite [7914,8868]
===
match
---
trailer [41855,41909]
trailer [40994,41048]
===
match
---
trailer [43262,43277]
trailer [42401,42416]
===
match
---
name: info [22419,22423]
name: info [22366,22370]
===
match
---
name: airflow [1880,1887]
name: airflow [1827,1834]
===
match
---
trailer [44982,44987]
trailer [44121,44126]
===
match
---
name: allow_future_exec_dates [43168,43191]
name: allow_future_exec_dates [42307,42330]
===
match
---
trailer [46154,46169]
trailer [45293,45308]
===
match
---
name: buffer_key [22483,22493]
name: buffer_key [22430,22440]
===
match
---
name: OperationalError [50353,50369]
name: OperationalError [49492,49508]
===
match
---
param [4653,4659]
param [4600,4606]
===
match
---
name: max_runs [24626,24634]
name: max_runs [24573,24581]
===
match
---
name: session [35115,35122]
name: session [34340,34347]
===
match
---
name: limit [10883,10888]
name: limit [10830,10835]
===
match
---
name: query [47988,47993]
name: query [47127,47132]
===
match
---
trailer [22832,22838]
trailer [22779,22785]
===
match
---
name: self [6360,6364]
name: self [6307,6311]
===
match
---
name: models [1696,1702]
name: models [1643,1649]
===
match
---
name: Session [46251,46258]
name: Session [45390,45397]
===
match
---
simple_stmt [49687,49778]
simple_stmt [48826,48917]
===
match
---
atom_expr [13672,13707]
atom_expr [13619,13654]
===
match
---
name: self [6028,6032]
name: self [5975,5979]
===
match
---
name: dag_map [8594,8601]
name: dag_map [8541,8548]
===
match
---
name: airflow [2096,2103]
name: airflow [2043,2050]
===
match
---
argument [49077,49092]
argument [48216,48231]
===
match
---
operator: , [5860,5861]
operator: , [5807,5808]
===
match
---
name: tis_with_right_state [20884,20904]
name: tis_with_right_state [20831,20851]
===
match
---
atom_expr [9378,9386]
atom_expr [9325,9333]
===
match
---
name: State [22521,22526]
name: State [22468,22473]
===
match
---
name: dagrun_timeout [41996,42010]
name: dagrun_timeout [41135,41149]
===
match
---
atom_expr [41957,41975]
atom_expr [41096,41114]
===
match
---
suite [44802,45077]
suite [43941,44216]
===
match
---
atom_expr [36984,36997]
atom_expr [36209,36222]
===
match
---
trailer [18660,18676]
trailer [18607,18623]
===
match
---
name: executable_tis [17319,17333]
name: executable_tis [17266,17280]
===
match
---
name: logging [4622,4629]
name: logging [4569,4576]
===
match
---
trailer [40467,40478]
trailer [39649,39660]
===
match
---
name: execute_callbacks [43542,43559]
name: execute_callbacks [42681,42698]
===
match
---
name: dag_model [37517,37526]
name: dag_model [36699,36708]
===
match
---
name: TaskInstance [50785,50797]
name: TaskInstance [49924,49936]
===
match
---
name: State [38544,38549]
name: State [37726,37731]
===
match
---
comparison [22279,22300]
comparison [22226,22247]
===
match
---
number: 0 [29406,29407]
number: 0 [29353,29354]
===
match
---
name: log [6756,6759]
name: log [6703,6706]
===
match
---
trailer [31873,31882]
trailer [31820,31829]
===
match
---
name: Optional [1030,1038]
name: Optional [1030,1038]
===
match
---
name: num_runs [29395,29403]
name: num_runs [29342,29350]
===
match
---
name: max_active_runs [41011,41026]
name: max_active_runs [40150,40165]
===
match
---
dotted_name [1347,1377]
dotted_name [1347,1377]
===
match
---
name: processor_agent [45495,45510]
name: processor_agent [44634,44649]
===
match
---
simple_stmt [4169,4228]
simple_stmt [4116,4175]
===
match
---
operator: = [23790,23791]
operator: = [23737,23738]
===
match
---
name: super [5171,5176]
name: super [5118,5123]
===
match
---
name: dag_run [40598,40605]
name: dag_run [39780,39787]
===
match
---
operator: , [24709,24710]
operator: , [24656,24657]
===
match
---
name: TaskInstance [50857,50869]
name: TaskInstance [49996,50008]
===
match
---
simple_stmt [16778,16787]
simple_stmt [16725,16734]
===
match
---
name: task_instance [15012,15025]
name: task_instance [14959,14972]
===
match
---
name: session [42563,42570]
name: session [41702,41709]
===
match
---
string: """         This function is where the main scheduling decisions take places. It:          - Creates any necessary DAG runs by examining the next_dagrun_create_after column of DagModel            Since creating Dag Runs is a relatively time consuming process, we select only 10 dags by default           (configurable via ``scheduler.max_dagruns_to_create_per_loop`` setting) - putting this higher will           mean one scheduler could spend a chunk of time creating dag runs, and not ever get around to           scheduling tasks.          - Finds the "next n oldest" running DAG Runs to examine for scheduling (n=20 by default, configurable           via ``scheduler.max_dagruns_per_loop_to_schedule`` config setting) and tries to progress state (TIs           to SCHEDULED, or DagRuns to SUCCESS/FAILURE etc)            By "next oldest", we mean hasn't been examined/scheduled in the most time.            The reason we don't select all dagruns at once because the rows are selected with row locks, meaning           that only one scheduler can "process them", even it is waiting behind other dags. Increasing this           limit will allow more throughput for smaller DAGs but will likely slow down throughput for larger           (>500 tasks.) DAGs          - Then, via a Critical Section (locking the rows of the Pool model) we queue tasks, and then send them           to the executor.            See docs of _critical_section_execute_task_instances for more.          :return: Number of TIs enqueued in this iteration         :rtype: int         """ [30047,31607]
string: """         This function is where the main scheduling decisions take places. It:          - Creates any necessary DAG runs by examining the next_dagrun_create_after column of DagModel            Since creating Dag Runs is a relatively time consuming process, we select only 10 dags by default           (configurable via ``scheduler.max_dagruns_to_create_per_loop`` setting) - putting this higher will           mean one scheduler could spend a chunk of time creating dag runs, and not ever get around to           scheduling tasks.          - Finds the "next n oldest" running DAG Runs to examine for scheduling (n=20 by default, configurable           via ``scheduler.max_dagruns_per_loop_to_schedule`` config setting) and tries to progress state (TIs           to SCHEDULED, or DagRuns to SUCCESS/FAILURE etc)            By "next oldest", we mean hasn't been examined/scheduled in the most time.            The reason we don't select all dagruns at once because the rows are selected with row locks, meaning           that only one scheduler can "process them", even it is waiting behind other dags. Increasing this           limit will allow more throughput for smaller DAGs but will likely slow down throughput for larger           (>500 tasks.) DAGs          - Then, via a Critical Section (locking the rows of the Pool model) we queue tasks, and then send them           to the executor.            See docs of _critical_section_execute_task_instances for more.          :return: Number of TIs enqueued in this iteration         :rtype: int         """ [29994,31554]
===
match
---
dotted_name [2245,2266]
dotted_name [2192,2213]
===
match
---
expr_stmt [20828,20875]
expr_stmt [20775,20822]
===
match
---
name: active_runs [41215,41226]
name: active_runs [40354,40365]
===
match
---
tfpdef [39803,39811]
tfpdef [38985,38993]
===
match
---
name: num_times_parse_dags [5042,5062]
name: num_times_parse_dags [4989,5009]
===
match
---
param [4386,4439]
param [4333,4386]
===
match
---
trailer [39299,39306]
trailer [38481,38488]
===
match
---
name: TI [17880,17882]
name: TI [17827,17829]
===
match
---
simple_stmt [26099,26172]
simple_stmt [26046,26119]
===
match
---
name: self [45372,45376]
name: self [44511,44515]
===
match
---
trailer [45899,45905]
trailer [45038,45044]
===
match
---
decorator [46329,46346]
decorator [45468,45485]
===
match
---
trailer [17610,17625]
trailer [17557,17572]
===
match
---
name: primary [22064,22071]
name: primary [22011,22018]
===
match
---
atom_expr [21943,21968]
atom_expr [21890,21915]
===
match
---
operator: = [45814,45815]
operator: = [44953,44954]
===
match
---
name: session [45840,45847]
name: session [44979,44986]
===
match
---
atom_expr [27607,27672]
atom_expr [27554,27619]
===
match
---
name: self [15253,15257]
name: self [15200,15204]
===
match
---
operator: , [4376,4377]
operator: , [4323,4324]
===
match
---
trailer [10833,10838]
trailer [10780,10785]
===
match
---
name: with_row_locks [2402,2416]
name: with_row_locks [2349,2363]
===
match
---
name: self [14224,14228]
name: self [14171,14175]
===
match
---
trailer [38870,38899]
trailer [38052,38081]
===
match
---
operator: , [12077,12078]
operator: , [12024,12025]
===
match
---
atom_expr [13227,13245]
atom_expr [13174,13192]
===
match
---
name: serialized_dag [1744,1758]
name: serialized_dag [1691,1705]
===
match
---
trailer [21973,21975]
trailer [21920,21922]
===
match
---
operator: -> [35387,35389]
operator: -> [34612,34614]
===
match
---
name: TI [8443,8445]
name: TI [8390,8392]
===
match
---
name: self [5984,5988]
name: self [5931,5935]
===
match
---
funcdef [7795,8921]
funcdef [7742,8868]
===
match
---
name: log [18723,18726]
name: log [18670,18673]
===
match
---
try_stmt [24826,26221]
try_stmt [24773,26168]
===
match
---
name: _verify_integrity_if_dag_changed [43314,43346]
name: _verify_integrity_if_dag_changed [42453,42485]
===
match
---
atom_expr [49856,49886]
atom_expr [48995,49025]
===
match
---
lambdef [13214,13265]
lambdef [13161,13212]
===
match
---
atom_expr [38826,38842]
atom_expr [38008,38024]
===
match
---
name: self [24147,24151]
name: self [24094,24098]
===
match
---
simple_stmt [42591,42667]
simple_stmt [41730,41806]
===
match
---
trailer [5524,5558]
trailer [5471,5505]
===
match
---
operator: = [22096,22097]
operator: = [22043,22044]
===
match
---
trailer [39914,39921]
trailer [39096,39103]
===
match
---
tfpdef [20551,20567]
tfpdef [20498,20514]
===
match
---
tfpdef [45125,45133]
tfpdef [44264,44272]
===
match
---
name: list [39609,39613]
name: list [38791,38795]
===
match
---
param [44028,44040]
param [43167,43179]
===
match
---
name: processor_agent [24963,24978]
name: processor_agent [24910,24925]
===
match
---
dotted_name [2311,2335]
dotted_name [2258,2282]
===
match
---
name: conf [36528,36532]
name: conf [35753,35757]
===
match
---
trailer [49862,49867]
trailer [49001,49006]
===
match
---
trailer [23111,23115]
trailer [23058,23062]
===
match
---
trailer [18064,18068]
trailer [18011,18015]
===
match
---
name: TI [48795,48797]
name: TI [47934,47936]
===
match
---
name: session [44229,44236]
name: session [43368,43375]
===
match
---
name: self [24866,24870]
name: self [24813,24817]
===
match
---
name: max_tis [10015,10022]
name: max_tis [9962,9969]
===
match
---
comparison [7327,7355]
comparison [7274,7302]
===
match
---
operator: = [24600,24601]
operator: = [24547,24548]
===
match
---
suite [44839,44904]
suite [43978,44043]
===
match
---
name: DAG [45130,45133]
name: DAG [44269,44272]
===
match
---
name: dag_model [37359,37368]
name: dag_model [36563,36572]
===
match
---
trailer [41010,41026]
trailer [40149,40165]
===
match
---
name: __mapper_args__ [4169,4184]
name: __mapper_args__ [4116,4131]
===
match
---
name: pool_name [45952,45961]
name: pool_name [45091,45100]
===
match
---
arglist [5324,5350]
arglist [5271,5297]
===
match
---
name: grace_multiplier [7464,7480]
name: grace_multiplier [7411,7427]
===
match
---
trailer [24905,24907]
trailer [24852,24854]
===
match
---
simple_stmt [5171,5205]
simple_stmt [5118,5152]
===
match
---
param [13221,13223]
param [13168,13170]
===
match
---
expr_stmt [32144,32164]
expr_stmt [32091,32111]
===
match
---
name: session [30022,30029]
name: session [29969,29976]
===
match
---
trailer [5372,5385]
trailer [5319,5332]
===
match
---
name: CHECK_SLAS [45257,45267]
name: CHECK_SLAS [44396,44406]
===
match
---
operator: , [36900,36901]
operator: , [36125,36126]
===
match
---
simple_stmt [1972,2007]
simple_stmt [1919,1954]
===
match
---
operator: = [28318,28319]
operator: = [28265,28266]
===
match
---
name: is_failure_callback [42855,42874]
name: is_failure_callback [41994,42013]
===
match
---
operator: , [27709,27710]
operator: , [27656,27657]
===
match
---
name: self [40784,40788]
name: self [39927,39931]
===
match
---
name: of [49039,49041]
name: of [48178,48180]
===
match
---
atom_expr [10282,10292]
atom_expr [10229,10239]
===
match
---
number: 80 [6810,6812]
number: 80 [6757,6759]
===
match
---
argument [18586,18618]
argument [18533,18565]
===
match
---
name: session [21894,21901]
name: session [21841,21848]
===
match
---
name: TI [10622,10624]
name: TI [10569,10571]
===
match
---
name: utcnow [42057,42063]
name: utcnow [41196,41202]
===
match
---
name: tis_to_reset_or_adopt [48968,48989]
name: tis_to_reset_or_adopt [48107,48128]
===
match
---
operator: = [44439,44440]
operator: = [43578,43579]
===
match
---
name: dagbag [37344,37350]
name: dagbag [36548,36554]
===
match
---
operator: , [39306,39307]
operator: , [38488,38489]
===
match
---
name: outerjoin [48387,48396]
name: outerjoin [47526,47535]
===
match
---
operator: == [7631,7633]
operator: == [7578,7580]
===
match
---
comparison [48695,48724]
comparison [47834,47863]
===
match
---
name: task_map [8852,8860]
name: task_map [8799,8807]
===
match
---
argument [5682,5704]
argument [5629,5651]
===
match
---
decorated [20495,23834]
decorated [20442,23781]
===
match
---
trailer [10563,10571]
trailer [10510,10518]
===
match
---
with_item [27791,27813]
with_item [27738,27760]
===
match
---
trailer [22059,22063]
trailer [22006,22010]
===
match
---
name: all [39759,39762]
name: all [38941,38944]
===
match
---
name: get_dag [37351,37358]
name: get_dag [36555,36562]
===
match
---
name: self [29425,29429]
name: self [29372,29376]
===
match
---
atom_expr [16237,16570]
atom_expr [16184,16517]
===
match
---
name: pool_name [45869,45878]
name: pool_name [45008,45017]
===
match
---
name: self [25933,25937]
name: self [25880,25884]
===
match
---
trailer [48701,48707]
trailer [47840,47846]
===
match
---
name: TaskInstanceKey [1859,1874]
name: TaskInstanceKey [1806,1821]
===
match
---
with_stmt [27786,28864]
with_stmt [27733,28811]
===
match
---
suite [22301,22450]
suite [22248,22397]
===
match
---
simple_stmt [26927,26979]
simple_stmt [26874,26926]
===
match
---
name: DagCallbackRequest [41520,41538]
name: DagCallbackRequest [40659,40677]
===
match
---
dotted_name [1647,1668]
dotted_name [1594,1615]
===
match
---
operator: = [12226,12227]
operator: = [12173,12174]
===
match
---
name: task_instance [14012,14025]
name: task_instance [13959,13972]
===
match
---
operator: < [47477,47478]
operator: < [46616,46617]
===
match
---
name: self [23107,23111]
name: self [23054,23058]
===
match
---
name: slots_available [20191,20206]
name: slots_available [20138,20153]
===
match
---
name: timezone [42048,42056]
name: timezone [41187,41195]
===
match
---
name: self [9934,9938]
name: self [9881,9885]
===
match
---
name: dm [36063,36065]
name: dm [35288,35290]
===
match
---
atom_expr [42702,42927]
atom_expr [41841,42066]
===
match
---
trailer [50869,50885]
trailer [50008,50024]
===
match
---
name: dag_hash [37572,37580]
name: dag_hash [36754,36762]
===
match
---
trailer [15441,15518]
trailer [15388,15465]
===
match
---
name: session [40717,40724]
name: session [39878,39885]
===
match
---
name: event_scheduler [2110,2125]
name: event_scheduler [2057,2072]
===
match
---
trailer [29572,29581]
trailer [29519,29528]
===
match
---
name: e [34345,34346]
name: e [33570,33571]
===
match
---
name: retry_db_transaction [2198,2218]
name: retry_db_transaction [2145,2165]
===
match
---
simple_stmt [17273,17336]
simple_stmt [17220,17283]
===
match
---
name: TI [48806,48808]
name: TI [47945,47947]
===
match
---
atom_expr [5923,5944]
atom_expr [5870,5891]
===
match
---
trailer [24856,24863]
trailer [24803,24810]
===
match
---
name: QUEUED [22527,22533]
name: QUEUED [22474,22480]
===
match
---
operator: , [18873,18874]
operator: , [18820,18821]
===
match
---
simple_stmt [50559,50727]
simple_stmt [49698,49866]
===
match
---
operator: @ [34658,34659]
operator: @ [33883,33884]
===
match
---
import_from [2417,2486]
import_from [2364,2433]
===
match
---
atom_expr [46284,46323]
atom_expr [45423,45462]
===
match
---
name: log [28882,28885]
name: log [28829,28832]
===
match
---
trailer [20275,20284]
trailer [20222,20231]
===
match
---
trailer [15484,15492]
trailer [15431,15439]
===
match
---
name: dag_run [39843,39850]
name: dag_run [39025,39032]
===
match
---
operator: = [18956,18957]
operator: = [18903,18904]
===
match
---
atom_expr [5669,5680]
atom_expr [5616,5627]
===
match
---
name: warning [12675,12682]
name: warning [12622,12629]
===
match
---
name: int [9003,9006]
name: int [8950,8953]
===
match
---
trailer [24105,24173]
trailer [24052,24120]
===
match
---
trailer [5641,5648]
trailer [5588,5595]
===
match
---
trailer [2825,2827]
trailer [2772,2774]
===
match
---
name: self [28808,28812]
name: self [28755,28759]
===
match
---
atom_expr [43863,43909]
atom_expr [43002,43048]
===
match
---
simple_stmt [1642,1683]
simple_stmt [1589,1630]
===
match
---
operator: <= [10761,10763]
operator: <= [10708,10710]
===
match
---
operator: , [5921,5922]
operator: , [5868,5869]
===
match
---
atom_expr [34455,34500]
atom_expr [33680,33725]
===
match
---
name: resettable_states [48043,48060]
name: resettable_states [47182,47199]
===
match
---
operator: = [47265,47266]
operator: = [46404,46405]
===
match
---
argument [18916,18933]
argument [18863,18880]
===
match
---
atom_expr [44760,44788]
atom_expr [43899,43927]
===
match
---
atom [38313,38348]
atom [37495,37530]
===
match
---
name: group_by [8538,8546]
name: group_by [8485,8493]
===
match
---
name: TI [21830,21832]
name: TI [21777,21779]
===
match
---
trailer [16191,16202]
trailer [16138,16149]
===
match
---
trailer [42570,42576]
trailer [41709,41715]
===
match
---
string: 'scheduler' [4414,4425]
string: 'scheduler' [4361,4372]
===
match
---
simple_stmt [14922,14931]
simple_stmt [14869,14878]
===
match
---
name: dag_run [42255,42262]
name: dag_run [41394,41401]
===
match
---
name: session [43901,43908]
name: session [43040,43047]
===
match
---
name: dag [41735,41738]
name: dag [40874,40877]
===
match
---
name: timer [34188,34193]
name: timer [33413,33418]
===
match
---
trailer [39942,39952]
trailer [39124,39134]
===
match
---
suite [15368,15542]
suite [15315,15489]
===
match
---
name: id [38768,38770]
name: id [37950,37952]
===
match
---
name: state [23769,23774]
name: state [23716,23721]
===
match
---
atom_expr [50452,50465]
atom_expr [49591,49604]
===
match
---
if_stmt [41940,43101]
if_stmt [41079,42240]
===
match
---
atom_expr [47597,47609]
atom_expr [46736,46748]
===
match
---
operator: @ [34884,34885]
operator: @ [34109,34110]
===
match
---
parameters [44004,44041]
parameters [43143,43180]
===
match
---
name: event_buffer [22159,22171]
name: event_buffer [22106,22118]
===
match
---
name: error [23742,23747]
name: error [23689,23694]
===
match
---
atom_expr [35085,35123]
atom_expr [34310,34348]
===
match
---
trailer [13176,13279]
trailer [13123,13226]
===
match
---
suite [46877,50436]
suite [46016,49575]
===
match
---
name: timezone [39906,39914]
name: timezone [39088,39096]
===
match
---
simple_stmt [28649,28688]
simple_stmt [28596,28635]
===
match
---
atom_expr [34268,34290]
atom_expr [33493,33515]
===
match
---
suite [21998,23800]
suite [21945,23747]
===
match
---
name: max_active_tis_per_dag [15519,15541]
name: max_active_tis_per_dag [15466,15488]
===
match
---
atom_expr [11336,11389]
atom_expr [11283,11336]
===
match
---
atom_expr [5907,5921]
atom_expr [5854,5868]
===
match
---
atom_expr [27517,27544]
atom_expr [27464,27491]
===
match
---
not_test [6160,6184]
not_test [6107,6131]
===
match
---
suite [5221,5250]
suite [5168,5197]
===
match
---
name: task [23316,23320]
name: task [23263,23267]
===
match
---
name: configuration [1316,1329]
name: configuration [1316,1329]
===
match
---
simple_stmt [45997,46085]
simple_stmt [45136,45224]
===
match
---
param [44750,44795]
param [43889,43934]
===
match
---
name: SIGUSR2 [5975,5982]
name: SIGUSR2 [5922,5929]
===
match
---
trailer [5464,5473]
trailer [5411,5420]
===
match
---
atom_expr [35986,35999]
atom_expr [35211,35224]
===
match
---
comp_op [24053,24059]
comp_op [24000,24006]
===
match
---
atom_expr [45690,45700]
atom_expr [44829,44839]
===
match
---
operator: = [10943,10944]
operator: = [10890,10891]
===
match
---
return_stmt [43092,43100]
return_stmt [42231,42239]
===
match
---
name: utcnow [43147,43153]
name: utcnow [42286,42292]
===
match
---
trailer [10028,10054]
trailer [9975,10001]
===
match
---
simple_stmt [38390,38790]
simple_stmt [37572,37972]
===
match
---
trailer [36457,36482]
trailer [35682,35707]
===
match
---
name: len [17516,17519]
name: len [17463,17466]
===
match
---
name: State [49393,49398]
name: State [48532,48537]
===
match
---
name: executor [18831,18839]
name: executor [18778,18786]
===
match
---
trailer [38825,38843]
trailer [38007,38025]
===
match
---
arglist [45656,45700]
arglist [44795,44839]
===
match
---
name: load_only [48785,48794]
name: load_only [47924,47933]
===
match
---
atom_expr [22990,22999]
atom_expr [22937,22946]
===
match
---
name: self [45021,45025]
name: self [44160,44164]
===
match
---
simple_stmt [32144,32165]
simple_stmt [32091,32112]
===
match
---
name: DM [2575,2577]
name: DM [2522,2524]
===
match
---
name: num_unhandled [13828,13841]
name: num_unhandled [13775,13788]
===
match
---
operator: , [38556,38557]
operator: , [37738,37739]
===
match
---
atom_expr [45670,45681]
atom_expr [44809,44820]
===
match
---
operator: = [47517,47518]
operator: = [46656,46657]
===
match
---
funcdef [39077,41409]
funcdef [38259,40548]
===
match
---
trailer [11862,11869]
trailer [11809,11816]
===
match
---
name: Session [41493,41500]
name: Session [40632,40639]
===
match
---
simple_stmt [1100,1144]
simple_stmt [1100,1144]
===
match
---
name: task_id [8446,8453]
name: task_id [8393,8400]
===
match
---
name: session [19034,19041]
name: session [18981,18988]
===
match
---
trailer [14232,14237]
trailer [14179,14184]
===
match
---
expr_stmt [41735,41807]
expr_stmt [40874,40946]
===
match
---
name: processor_agent [28549,28564]
name: processor_agent [28496,28511]
===
match
---
operator: = [24758,24759]
operator: = [24705,24706]
===
match
---
name: dag_id [14110,14116]
name: dag_id [14057,14063]
===
match
---
name: self [41044,41048]
name: self [40183,40187]
===
match
---
import_from [974,1045]
import_from [974,1045]
===
match
---
trailer [6882,6886]
trailer [6829,6833]
===
match
---
operator: , [16547,16548]
operator: , [16494,16495]
===
match
---
operator: = [40386,40387]
operator: = [39568,39569]
===
match
---
simple_stmt [22011,22073]
simple_stmt [21958,22020]
===
match
---
name: RUNNING [39686,39693]
name: RUNNING [38868,38875]
===
match
---
dotted_name [2492,2511]
dotted_name [2439,2458]
===
match
---
name: self [4328,4332]
name: self [4275,4279]
===
match
---
return_stmt [20467,20489]
return_stmt [20414,20436]
===
match
---
name: dag_run [32801,32808]
name: dag_run [32206,32213]
===
match
---
string: "Waiting for processors to finish since we're using sqlite" [28108,28167]
string: "Waiting for processors to finish since we're using sqlite" [28055,28114]
===
match
---
operator: , [36246,36247]
operator: , [35471,35472]
===
match
---
trailer [25937,25941]
trailer [25884,25888]
===
match
---
atom_expr [10315,10336]
atom_expr [10262,10283]
===
match
---
trailer [39721,39730]
trailer [38903,38912]
===
match
---
operator: - [42066,42067]
operator: - [41205,41206]
===
match
---
name: bool [6971,6975]
name: bool [6918,6922]
===
match
---
trailer [17214,17264]
trailer [17161,17211]
===
match
---
term [23550,23583]
term [23497,23530]
===
match
---
operator: , [28850,28851]
operator: , [28797,28798]
===
match
---
name: scheduler_health_check_threshold [7726,7758]
name: scheduler_health_check_threshold [7673,7705]
===
match
---
trailer [22992,22999]
trailer [22939,22946]
===
match
---
name: all [21970,21973]
name: all [21917,21920]
===
match
---
trailer [36307,36319]
trailer [35532,35544]
===
match
---
trailer [11081,11085]
trailer [11028,11032]
===
match
---
name: get_dag [22982,22989]
name: get_dag [22929,22936]
===
match
---
atom_expr [12195,12217]
atom_expr [12142,12164]
===
match
---
name: self [4693,4697]
name: self [4640,4644]
===
match
---
operator: , [1086,1087]
operator: , [1086,1087]
===
match
---
operator: ** [4668,4670]
operator: ** [4615,4617]
===
match
---
name: processor_timeout_seconds [24365,24390]
name: processor_timeout_seconds [24312,24337]
===
match
---
subscriptlist [20774,20813]
subscriptlist [20721,20760]
===
match
---
atom_expr [44205,44219]
atom_expr [43344,43358]
===
match
---
simple_stmt [44145,44238]
simple_stmt [43284,43377]
===
match
---
name: existing_dagruns [36366,36382]
name: existing_dagruns [35591,35607]
===
match
---
name: x [17389,17390]
name: x [17336,17337]
===
match
---
argument [49046,49061]
argument [48185,48200]
===
match
---
name: dag_id [37613,37619]
name: dag_id [36795,36801]
===
match
---
operator: = [34203,34204]
operator: = [33428,33429]
===
match
---
name: len [50038,50041]
name: len [49177,49180]
===
match
---
operator: , [27267,27268]
operator: , [27214,27215]
===
match
---
name: info [25426,25430]
name: info [25373,25377]
===
match
---
trailer [11724,11729]
trailer [11671,11676]
===
match
---
name: end [6415,6418]
name: end [6362,6365]
===
match
---
funcdef [46213,46324]
funcdef [45352,45463]
===
match
---
trailer [10524,10530]
trailer [10471,10477]
===
match
---
operator: = [49084,49085]
operator: = [48223,48224]
===
match
---
simple_stmt [18718,18813]
simple_stmt [18665,18760]
===
match
---
operator: * [4653,4654]
operator: * [4600,4601]
===
match
---
trailer [36856,36860]
trailer [36081,36085]
===
match
---
simple_stmt [12098,12245]
simple_stmt [12045,12192]
===
match
---
name: retry_db_transaction [34659,34679]
name: retry_db_transaction [33884,33904]
===
match
---
simple_stmt [6719,6742]
simple_stmt [6666,6689]
===
match
---
name: str [8397,8400]
name: str [8344,8347]
===
match
---
operator: = [47952,47953]
operator: = [47091,47092]
===
match
---
name: dag_id [44213,44219]
name: dag_id [43352,43358]
===
match
---
name: filter [48023,48029]
name: filter [47162,47168]
===
match
---
trailer [36939,36946]
trailer [36164,36171]
===
match
---
number: 1 [4477,4478]
number: 1 [4424,4425]
===
match
---
operator: -> [39150,39152]
operator: -> [38332,38334]
===
match
---
name: send_sla_callback_request_to_execute [45606,45642]
name: send_sla_callback_request_to_execute [44745,44781]
===
match
---
atom_expr [27686,27709]
atom_expr [27633,27656]
===
match
---
suite [41307,41409]
suite [40446,40548]
===
match
---
name: DagModel [35085,35093]
name: DagModel [34310,34318]
===
match
---
operator: , [46319,46320]
operator: , [45458,45459]
===
match
---
name: QUEUED [10422,10428]
name: QUEUED [10369,10375]
===
match
---
trailer [42262,42269]
trailer [41401,41408]
===
match
---
operator: , [43056,43057]
operator: , [42195,42196]
===
match
---
trailer [42483,42489]
trailer [41622,41628]
===
match
---
operator: , [23757,23758]
operator: , [23704,23705]
===
match
---
name: num_queued_tis [28303,28317]
name: num_queued_tis [28250,28264]
===
match
---
annassign [8384,8585]
annassign [8331,8532]
===
match
---
trailer [15335,15344]
trailer [15282,15291]
===
match
---
name: tuple_ [1093,1099]
name: tuple_ [1093,1099]
===
match
---
name: id [49581,49583]
name: id [48720,48722]
===
match
---
operator: , [47065,47066]
operator: , [46204,46205]
===
match
---
trailer [44180,44204]
trailer [43319,43343]
===
match
---
trailer [42241,42270]
trailer [41380,41409]
===
match
---
name: session [23791,23798]
name: session [23738,23745]
===
match
---
name: self [5368,5372]
name: self [5315,5319]
===
match
---
name: adopt_or_reset_orphaned_tasks [27336,27365]
name: adopt_or_reset_orphaned_tasks [27283,27312]
===
match
---
number: 0 [9919,9920]
number: 0 [9866,9867]
===
match
---
atom_expr [47447,47476]
atom_expr [46586,46615]
===
match
---
name: self [50519,50523]
name: self [49658,49662]
===
match
---
name: dag_max_active_tasks_map [11978,12002]
name: dag_max_active_tasks_map [11925,11949]
===
match
---
name: self [45760,45764]
name: self [44899,44903]
===
match
---
name: isinstance [45308,45318]
name: isinstance [44447,44457]
===
match
---
operator: , [10396,10397]
operator: , [10343,10344]
===
match
---
simple_stmt [16804,16841]
simple_stmt [16751,16788]
===
match
---
operator: , [9006,9007]
operator: , [8953,8954]
===
match
---
operator: = [21211,21212]
operator: = [21158,21159]
===
match
---
name: session [9639,9646]
name: session [9586,9593]
===
match
---
name: executable_tis [16804,16818]
name: executable_tis [16751,16765]
===
match
---
name: len [17315,17318]
name: len [17262,17265]
===
match
---
operator: , [6339,6340]
operator: , [6286,6287]
===
match
---
annassign [26999,27049]
annassign [26946,26996]
===
match
---
name: dag_model [10451,10460]
name: dag_model [10398,10407]
===
match
---
trailer [38767,38770]
trailer [37949,37952]
===
match
---
name: external_executor_id [22321,22341]
name: external_executor_id [22268,22288]
===
match
---
operator: = [40914,40915]
operator: = [40053,40054]
===
match
---
atom_expr [13364,13405]
atom_expr [13311,13352]
===
match
---
name: DagRun [44742,44748]
name: DagRun [43881,43887]
===
match
---
operator: -> [6049,6051]
operator: -> [5996,5998]
===
match
---
name: _create_dagruns_for_dags [34914,34938]
name: _create_dagruns_for_dags [34139,34163]
===
match
---
simple_stmt [27059,27085]
simple_stmt [27006,27032]
===
match
---
atom_expr [21162,21210]
atom_expr [21109,21157]
===
match
---
name: datetime [948,956]
name: datetime [948,956]
===
match
---
simple_stmt [11402,11424]
simple_stmt [11349,11371]
===
match
---
operator: = [37648,37649]
operator: = [36830,36831]
===
match
---
simple_stmt [24092,24174]
simple_stmt [24039,24121]
===
match
---
sync_comp_for [10706,10765]
sync_comp_for [10653,10712]
===
match
---
trailer [23193,23203]
trailer [23140,23150]
===
match
---
trailer [42830,42837]
trailer [41969,41976]
===
match
---
atom_expr [49576,49583]
atom_expr [48715,48722]
===
match
---
comparison [24033,24082]
comparison [23980,24029]
===
match
---
trailer [45318,45337]
trailer [44457,44476]
===
match
---
name: ti_key [21411,21417]
name: ti_key [21358,21364]
===
match
---
name: filter [36707,36713]
name: filter [35932,35938]
===
match
---
operator: , [13245,13246]
operator: , [13192,13193]
===
match
---
name: _emit_pool_metrics [45741,45759]
name: _emit_pool_metrics [44880,44898]
===
match
---
string: """         Make scheduling decisions about an individual dag run          :param dag_run: The DagRun to schedule         :return: Callback that needs to be executed         """ [41549,41726]
string: """         Make scheduling decisions about an individual dag run          :param dag_run: The DagRun to schedule         :return: Callback that needs to be executed         """ [40688,40865]
===
match
---
name: _processor_poll_interval [5076,5100]
name: _processor_poll_interval [5023,5047]
===
match
---
name: self [25719,25723]
name: self [25666,25670]
===
match
---
import_name [789,804]
import_name [789,804]
===
match
---
expr_stmt [9817,9887]
expr_stmt [9764,9834]
===
match
---
simple_stmt [21739,21764]
simple_stmt [21686,21711]
===
match
---
name: existing_dagruns_filter [36200,36223]
name: existing_dagruns_filter [35425,35448]
===
match
---
name: ti [18871,18873]
name: ti [18818,18820]
===
match
---
decorator [8926,8943]
decorator [8873,8890]
===
match
---
name: debug [28886,28891]
name: debug [28833,28838]
===
match
---
tfpdef [4448,4473]
tfpdef [4395,4420]
===
match
---
trailer [48494,48500]
trailer [47633,47639]
===
match
---
operator: , [29918,29919]
operator: , [29865,29866]
===
match
---
name: itertools [812,821]
name: itertools [812,821]
===
match
---
trailer [47987,47993]
trailer [47126,47132]
===
match
---
argument [45308,45357]
argument [44447,44496]
===
match
---
strings [22643,22789]
strings [22590,22736]
===
match
---
tfpdef [9008,9024]
tfpdef [8955,8971]
===
match
---
string: 'max_queued_runs_per_dag' [36548,36573]
string: 'max_queued_runs_per_dag' [35773,35798]
===
match
---
tfpdef [4584,4599]
tfpdef [4531,4546]
===
match
---
param [46236,46241]
param [45375,45380]
===
match
---
trailer [11290,11317]
trailer [11237,11264]
===
match
---
name: DagRun [39591,39597]
name: DagRun [38773,38779]
===
match
---
argument [24747,24770]
argument [24694,24717]
===
match
---
name: timers [27386,27392]
name: timers [27333,27339]
===
match
---
trailer [28891,28946]
trailer [28838,28893]
===
match
---
trailer [22171,22175]
trailer [22118,22122]
===
match
---
operator: , [50008,50009]
operator: , [49147,49148]
===
match
---
name: dag_id [39598,39604]
name: dag_id [38780,38786]
===
match
---
name: dag_id [14324,14330]
name: dag_id [14271,14277]
===
match
---
simple_stmt [805,822]
simple_stmt [805,822]
===
match
---
atom_expr [6360,6380]
atom_expr [6307,6327]
===
match
---
atom_expr [40388,40426]
atom_expr [39570,39608]
===
match
---
trailer [23883,23888]
trailer [23830,23835]
===
match
---
name: signal [5833,5839]
name: signal [5780,5786]
===
match
---
dictorsetmaker [51199,51235]
dictorsetmaker [50338,50374]
===
match
---
trailer [44311,44393]
trailer [43450,43532]
===
match
---
trailer [42720,42927]
trailer [41859,42066]
===
match
---
name: ti [23431,23433]
name: ti [23378,23380]
===
match
---
name: session [11062,11069]
name: session [11009,11016]
===
match
---
operator: = [50542,50543]
operator: = [49681,49682]
===
match
---
trailer [24533,24549]
trailer [24480,24496]
===
match
---
name: serialized_dag [15321,15335]
name: serialized_dag [15268,15282]
===
match
---
name: dag_id [36006,36012]
name: dag_id [35231,35237]
===
match
---
name: self [46236,46240]
name: self [45375,45379]
===
match
---
trailer [26188,26192]
trailer [26135,26139]
===
match
---
operator: -> [46267,46269]
operator: -> [45406,45408]
===
match
---
operator: = [34023,34024]
operator: = [33248,33249]
===
match
---
simple_stmt [49323,49358]
simple_stmt [48462,48497]
===
match
---
simple_stmt [15626,15775]
simple_stmt [15573,15722]
===
match
---
trailer [42529,42535]
trailer [41668,41674]
===
match
---
name: TI [10282,10284]
name: TI [10229,10231]
===
match
---
subscriptlist [8397,8410]
subscriptlist [8344,8357]
===
match
---
name: exc [1116,1119]
name: exc [1116,1119]
===
match
---
simple_stmt [6429,6448]
simple_stmt [6376,6395]
===
match
---
trailer [49924,50125]
trailer [49063,49264]
===
match
---
trailer [24096,24100]
trailer [24043,24047]
===
match
---
suite [22534,23800]
suite [22481,23747]
===
match
---
operator: , [5536,5537]
operator: , [5483,5484]
===
match
---
trailer [12015,12025]
trailer [11962,11972]
===
match
---
name: task_instance [16871,16884]
name: task_instance [16818,16831]
===
match
---
trailer [49340,49347]
trailer [48479,48486]
===
match
---
atom_expr [44491,44502]
atom_expr [43630,43641]
===
match
---
trailer [34015,34032]
trailer [33240,33257]
===
match
---
term [6804,6812]
term [6751,6759]
===
match
---
atom [36385,36498]
atom [35610,35723]
===
match
---
operator: , [44219,44220]
operator: , [43358,43359]
===
match
---
name: queued_by_job_id [17918,17934]
name: queued_by_job_id [17865,17881]
===
match
---
trailer [23443,23451]
trailer [23390,23398]
===
match
---
string: "task says its %s. (Info: %s) Was the task killed externally?" [22727,22789]
string: "task says its %s. (Info: %s) Was the task killed externally?" [22674,22736]
===
match
---
trailer [8476,8481]
trailer [8423,8428]
===
match
---
trailer [24978,24984]
trailer [24925,24931]
===
match
---
trailer [11575,11662]
trailer [11522,11609]
===
match
---
trailer [49157,49166]
trailer [48296,48305]
===
match
---
atom_expr [17880,17894]
atom_expr [17827,17841]
===
match
---
number: 0 [41929,41930]
number: 0 [41068,41069]
===
match
---
name: dagbag [15258,15264]
name: dagbag [15205,15211]
===
match
---
trailer [23040,23052]
trailer [22987,22999]
===
match
---
atom_expr [15704,15724]
atom_expr [15651,15671]
===
match
---
name: priority_weight [18661,18676]
name: priority_weight [18608,18623]
===
match
---
name: dag_models [37055,37065]
name: dag_models [36280,36290]
===
match
---
arglist [37471,37533]
arglist [36653,36715]
===
match
---
name: self [39112,39116]
name: self [38294,38298]
===
match
---
name: command [18512,18519]
name: command [18459,18466]
===
match
---
name: models [1584,1590]
name: models [1531,1537]
===
match
---
suite [9045,18099]
suite [8992,18046]
===
match
---
trailer [44868,44903]
trailer [44007,44042]
===
match
---
atom_expr [47404,47417]
atom_expr [46543,46556]
===
match
---
name: max_tis_per_query [20252,20269]
name: max_tis_per_query [20199,20216]
===
match
---
name: log [12882,12885]
name: log [12829,12832]
===
match
---
atom_expr [46841,46849]
atom_expr [45980,45988]
===
match
---
atom_expr [20247,20269]
atom_expr [20194,20216]
===
match
---
for_stmt [49476,49584]
for_stmt [48615,48723]
===
match
---
fstring [46109,46142]
fstring [45248,45281]
===
match
---
trailer [48439,48446]
trailer [47578,47585]
===
match
---
name: dag_id [41352,41358]
name: dag_id [40491,40497]
===
match
---
simple_stmt [37290,37299]
simple_stmt [36515,36524]
===
match
---
name: self [6751,6755]
name: self [6698,6702]
===
match
---
suite [32739,32890]
suite [32148,32291]
===
match
---
arglist [5188,5203]
arglist [5135,5150]
===
match
---
operator: = [40671,40672]
operator: = [39832,39833]
===
match
---
name: num_starving_tasks [17100,17118]
name: num_starving_tasks [17047,17065]
===
match
---
name: self [45585,45589]
name: self [44724,44728]
===
match
---
name: _update_state [39789,39802]
name: _update_state [38971,38984]
===
match
---
operator: { [46130,46131]
operator: { [45269,45270]
===
match
---
fstring_start: f' [45933,45935]
fstring_start: f' [45072,45074]
===
match
---
name: log [41846,41849]
name: log [40985,40988]
===
match
---
name: request [23673,23680]
name: request [23620,23627]
===
match
---
arglist [17432,17503]
arglist [17379,17450]
===
match
---
trailer [47352,47554]
trailer [46491,46693]
===
match
---
name: defaultdict [11734,11745]
name: defaultdict [11681,11692]
===
match
---
name: TaskInstance [1845,1857]
name: TaskInstance [1792,1804]
===
match
---
name: List [7845,7849]
name: List [7792,7796]
===
match
---
name: self [25052,25056]
name: self [24999,25003]
===
match
---
operator: >= [41004,41006]
operator: >= [40143,40145]
===
match
---
name: self [27874,27878]
name: self [27821,27825]
===
match
---
operator: = [15416,15417]
operator: = [15363,15364]
===
match
---
atom_expr [35912,36173]
atom_expr [35137,35398]
===
match
---
name: start_date [42035,42045]
name: start_date [41174,41184]
===
match
---
string: 'pool_metrics_interval' [27634,27657]
string: 'pool_metrics_interval' [27581,27604]
===
match
---
sync_comp_for [17385,17408]
sync_comp_for [17332,17355]
===
match
---
expr_stmt [36507,36574]
expr_stmt [35732,35799]
===
match
---
name: self [49911,49915]
name: self [49050,49054]
===
match
---
name: max_tis [20365,20372]
name: max_tis [20312,20319]
===
match
---
trailer [39435,39440]
trailer [38617,38622]
===
match
---
for_stmt [33209,33338]
for_stmt [32434,32563]
===
match
---
trailer [18790,18794]
trailer [18737,18741]
===
match
---
simple_stmt [26273,26878]
simple_stmt [26220,26825]
===
match
---
operator: = [12145,12146]
operator: = [12092,12093]
===
match
---
argument [40709,40724]
argument [39870,39885]
===
match
---
expr_stmt [4169,4227]
expr_stmt [4116,4174]
===
match
---
parameters [45759,45790]
parameters [44898,44929]
===
match
---
atom_expr [11718,11729]
atom_expr [11665,11676]
===
match
---
simple_stmt [28189,28232]
simple_stmt [28136,28179]
===
match
---
name: utils [2161,2166]
name: utils [2108,2113]
===
match
---
atom_expr [36843,36900]
atom_expr [36068,36125]
===
match
---
expr_stmt [40902,40951]
expr_stmt [40041,40090]
===
match
---
name: is_lock_not_available_error [34311,34338]
name: is_lock_not_available_error [33536,33563]
===
match
---
atom_expr [11734,11751]
atom_expr [11681,11698]
===
match
---
operator: , [46388,46389]
operator: , [45527,45528]
===
match
---
trailer [10571,10598]
trailer [10518,10545]
===
match
---
trailer [16250,16570]
trailer [16197,16517]
===
match
---
atom_expr [37205,37221]
atom_expr [36430,36446]
===
match
---
trailer [50407,50409]
trailer [49546,49548]
===
match
---
name: signal [5893,5899]
name: signal [5840,5846]
===
match
---
atom_expr [20790,20807]
atom_expr [20737,20754]
===
match
---
atom_expr [23875,23914]
atom_expr [23822,23861]
===
match
---
operator: , [44748,44749]
operator: , [43887,43888]
===
match
---
operator: == [20149,20151]
operator: == [20096,20098]
===
match
---
operator: , [13534,13535]
operator: , [13481,13482]
===
match
---
trailer [36924,36930]
trailer [36149,36155]
===
match
---
name: sql_conn [5388,5396]
name: sql_conn [5335,5343]
===
match
---
operator: , [36675,36676]
operator: , [35900,35901]
===
match
---
simple_stmt [25417,25557]
simple_stmt [25364,25504]
===
match
---
expr_stmt [8594,8643]
expr_stmt [8541,8590]
===
match
---
if_stmt [41817,41931]
if_stmt [40956,41070]
===
match
---
name: query [42208,42213]
name: query [41347,41352]
===
match
---
name: state [21474,21479]
name: state [21421,21426]
===
match
---
param [45119,45124]
param [44258,44263]
===
match
---
expr_stmt [39885,39923]
expr_stmt [39067,39105]
===
match
---
trailer [16241,16245]
trailer [16188,16192]
===
match
---
arglist [27428,27545]
arglist [27375,27492]
===
match
---
name: dag_id [8562,8568]
name: dag_id [8509,8515]
===
match
---
funcdef [34910,35273]
funcdef [34135,34498]
===
match
---
operator: , [1191,1192]
operator: , [1191,1192]
===
match
---
trailer [17694,17701]
trailer [17641,17648]
===
match
---
name: self [44945,44949]
name: self [44084,44088]
===
match
---
expr_stmt [5637,5726]
expr_stmt [5584,5673]
===
match
---
operator: , [7959,7960]
operator: , [7906,7907]
===
match
---
with_item [28254,28281]
with_item [28201,28228]
===
match
---
arglist [12683,12747]
arglist [12630,12694]
===
match
---
name: handle_failure [23727,23741]
name: handle_failure [23674,23688]
===
match
---
if_stmt [34308,34569]
if_stmt [33533,33794]
===
match
---
simple_stmt [8594,8644]
simple_stmt [8541,8591]
===
match
---
name: logger [46834,46840]
name: logger [45973,45979]
===
match
---
atom_expr [5368,5385]
atom_expr [5315,5332]
===
match
---
fstring_string: pool.queued_slots. [46011,46029]
fstring_string: pool.queued_slots. [45150,45168]
===
match
---
strings [12908,13031]
strings [12855,12978]
===
match
---
trailer [23819,23833]
trailer [23766,23780]
===
match
---
simple_stmt [28808,28864]
simple_stmt [28755,28811]
===
match
---
if_stmt [33509,33732]
if_stmt [32734,32957]
===
match
---
operator: , [6032,6033]
operator: , [5979,5980]
===
match
---
operator: == [42305,42307]
operator: == [41444,41446]
===
match
---
simple_stmt [49911,50126]
simple_stmt [49050,49265]
===
match
---
name: DagRun [36428,36434]
name: DagRun [35653,35659]
===
match
---
atom_expr [49393,49403]
atom_expr [48532,48542]
===
match
---
name: self [24958,24962]
name: self [24905,24909]
===
match
---
name: id [17941,17943]
name: id [17888,17890]
===
match
---
name: fileloc [23444,23451]
name: fileloc [23391,23398]
===
match
---
trailer [35357,35367]
trailer [34582,34592]
===
match
---
arglist [27621,27671]
arglist [27568,27618]
===
match
---
atom_expr [39396,39764]
atom_expr [38578,38946]
===
match
---
name: dag [41824,41827]
name: dag [40963,40966]
===
match
---
operator: , [18962,18963]
operator: , [18909,18910]
===
match
---
name: typing [979,985]
name: typing [979,985]
===
match
---
trailer [25871,25880]
trailer [25818,25827]
===
match
---
name: pool_to_task_instances [11820,11842]
name: pool_to_task_instances [11767,11789]
===
match
---
operator: = [40458,40459]
operator: = [39640,39641]
===
match
---
argument [5188,5193]
argument [5135,5140]
===
match
---
name: get_dag [40685,40692]
name: get_dag [39846,39853]
===
match
---
operator: , [27672,27673]
operator: , [27619,27620]
===
match
---
name: SchedulerJob [48482,48494]
name: SchedulerJob [47621,47633]
===
match
---
trailer [4629,4636]
trailer [4576,4583]
===
match
---
arglist [39373,39765]
arglist [38555,38947]
===
match
---
name: fileloc [45674,45681]
name: fileloc [44813,44820]
===
match
---
name: state [47395,47400]
name: state [46534,46539]
===
match
---
name: dag_run [44532,44539]
name: dag_run [43671,43678]
===
match
---
name: self [8988,8992]
name: self [8935,8939]
===
match
---
operator: = [8794,8795]
operator: = [8741,8742]
===
match
---
trailer [6759,6764]
trailer [6706,6711]
===
match
---
trailer [35114,35123]
trailer [34339,34348]
===
match
---
trailer [25526,25536]
trailer [25473,25483]
===
match
---
name: debug [47146,47151]
name: debug [46285,46290]
===
match
---
atom_expr [10945,11087]
atom_expr [10892,11034]
===
match
---
atom_expr [50841,50855]
atom_expr [49980,49994]
===
match
---
atom_expr [22024,22072]
atom_expr [21971,22019]
===
match
---
atom [39614,39644]
atom [38796,38826]
===
match
---
name: signal [877,883]
name: signal [877,883]
===
match
---
if_stmt [44246,44413]
if_stmt [43385,43552]
===
match
---
trailer [37470,37534]
trailer [36652,36716]
===
match
---
name: _schedule_dag_run [32783,32800]
name: _schedule_dag_run [32188,32205]
===
match
---
name: processor_timeout [24456,24473]
name: processor_timeout [24403,24420]
===
match
---
name: State [10534,10539]
name: State [10481,10486]
===
match
---
name: os [867,869]
name: os [867,869]
===
match
---
name: task_instance [14167,14180]
name: task_instance [14114,14127]
===
match
---
name: int [4243,4246]
name: int [4190,4193]
===
match
---
name: log [28813,28816]
name: log [28760,28763]
===
match
---
name: str [6730,6733]
name: str [6677,6680]
===
match
---
simple_stmt [34604,34619]
simple_stmt [33829,33844]
===
match
---
arglist [11576,11661]
arglist [11523,11608]
===
match
---
name: dag_id [8458,8464]
name: dag_id [8405,8411]
===
match
---
strings [29748,29871]
strings [29695,29818]
===
match
---
name: self [19028,19032]
name: self [18975,18979]
===
match
---
simple_stmt [45144,45233]
simple_stmt [44283,44372]
===
match
---
argument [11040,11070]
argument [10987,11017]
===
match
---
name: log [17423,17426]
name: log [17370,17373]
===
match
---
operator: , [47841,47842]
operator: , [46980,46981]
===
match
---
trailer [27611,27620]
trailer [27558,27567]
===
match
---
atom_expr [45965,45983]
atom_expr [45104,45122]
===
match
---
name: dag_run [32863,32870]
name: dag_run [32264,32271]
===
match
---
parameters [19027,19051]
parameters [18974,18998]
===
match
---
expr_stmt [4693,4713]
expr_stmt [4640,4660]
===
match
---
expr_stmt [5368,5417]
expr_stmt [5315,5364]
===
match
---
atom_expr [38763,38770]
atom_expr [37945,37952]
===
match
---
testlist_star_expr [43469,43501]
testlist_star_expr [42608,42640]
===
match
---
atom_expr [31967,31980]
atom_expr [31914,31927]
===
match
---
string: """         Attempts to execute TaskInstances that should be executed by the scheduler.          There are three steps:         1. Pick TIs by priority with the constraint that they are in the expected states         and that we do exceed max_active_runs or pool limits.         2. Change the state for the TIs above atomically.         3. Enqueue the TIs in the executor.          HA note: This function is a "critical section" meaning that only a single executor process can execute         this function at the same time. This is achieved by doing ``SELECT ... from pool FOR UPDATE``. For DBs         that support NOWAIT, a "blocked" scheduler will skip this and continue on with other tasks (creating         new DAG runs, progressing TIs from None to SCHEDULED etc.); DBs that don't support this (such as         MariaDB or MySQL 5.x) the other schedulers will wait for the lock before continuing.          :param session:         :type session: sqlalchemy.orm.Session         :return: Number of task instance with state changed.         """ [19068,20114]
string: """         Attempts to execute TaskInstances that should be executed by the scheduler.          There are three steps:         1. Pick TIs by priority with the constraint that they are in the expected states         and that we do exceed max_active_runs or pool limits.         2. Change the state for the TIs above atomically.         3. Enqueue the TIs in the executor.          HA note: This function is a "critical section" meaning that only a single executor process can execute         this function at the same time. This is achieved by doing ``SELECT ... from pool FOR UPDATE``. For DBs         that support NOWAIT, a "blocked" scheduler will skip this and continue on with other tasks (creating         new DAG runs, progressing TIs from None to SCHEDULED etc.); DBs that don't support this (such as         MariaDB or MySQL 5.x) the other schedulers will wait for the lock before continuing.          :param session:         :type session: sqlalchemy.orm.Session         :return: Number of task instance with state changed.         """ [19015,20061]
===
match
---
decorated [50471,51453]
decorated [49610,50592]
===
match
---
trailer [49556,49573]
trailer [48695,48712]
===
match
---
name: tis_to_reset_or_adopt [49490,49511]
name: tis_to_reset_or_adopt [48629,48650]
===
match
---
trailer [5178,5187]
trailer [5125,5134]
===
match
---
trailer [45926,45932]
trailer [45065,45071]
===
match
---
trailer [5396,5407]
trailer [5343,5354]
===
match
---
string: """         Is this SchedulerJob alive?          We define alive as in a state of running and a heartbeat within the         threshold defined in the ``scheduler_health_check_threshold`` config         setting.          ``grace_multiplier`` is accepted for compatibility with the parent class.          :rtype: boolean         """ [6985,7315]
string: """         Is this SchedulerJob alive?          We define alive as in a state of running and a heartbeat within the         threshold defined in the ``scheduler_health_check_threshold`` config         setting.          ``grace_multiplier`` is accepted for compatibility with the parent class.          :rtype: boolean         """ [6932,7262]
===
match
---
operator: = [7528,7529]
operator: = [7475,7476]
===
match
---
trailer [16470,16481]
trailer [16417,16428]
===
match
---
suite [2880,51453]
suite [2827,50592]
===
match
---
name: dag_hash [38717,38725]
name: dag_hash [37899,37907]
===
match
---
comparison [47382,47417]
comparison [46521,46556]
===
match
---
name: latest_version [44441,44455]
name: latest_version [43580,43594]
===
match
---
name: queue [18806,18811]
name: queue [18753,18758]
===
match
---
simple_stmt [47137,47213]
simple_stmt [46276,46352]
===
match
---
not_test [29007,29030]
not_test [28954,28977]
===
match
---
name: self [23627,23631]
name: self [23574,23578]
===
match
---
name: verify_integrity [44642,44658]
name: verify_integrity [43781,43797]
===
match
---
operator: , [17098,17099]
operator: , [17045,17046]
===
match
---
atom_expr [45304,45358]
atom_expr [44443,44497]
===
match
---
atom_expr [39260,39316]
atom_expr [38442,38498]
===
match
---
name: event_buffer [20828,20840]
name: event_buffer [20775,20787]
===
match
---
simple_stmt [46649,46711]
simple_stmt [45788,45850]
===
match
---
name: dag_map [8903,8910]
name: dag_map [8850,8857]
===
match
---
atom [9389,9391]
atom [9336,9338]
===
match
---
atom_expr [31788,31833]
atom_expr [31735,31780]
===
match
---
name: info [16246,16250]
name: info [16193,16197]
===
match
---
operator: , [14384,14385]
operator: , [14331,14332]
===
match
---
expr_stmt [49236,49258]
expr_stmt [48375,48397]
===
match
---
name: self [44005,44009]
name: self [43144,43148]
===
match
---
param [50525,50548]
param [49664,49687]
===
match
---
atom_expr [44378,44392]
atom_expr [43517,43531]
===
match
---
operator: * [6896,6897]
operator: * [6843,6844]
===
match
---
argument [38429,38458]
argument [37611,37640]
===
match
---
name: join [49863,49867]
name: join [49002,49006]
===
match
---
atom_expr [40849,40863]
atom_expr [39988,40002]
===
match
---
name: filter [36451,36457]
name: filter [35676,35682]
===
match
---
name: RUNNING [48510,48517]
name: RUNNING [47649,47656]
===
match
---
name: signum [6475,6481]
name: signum [6422,6428]
===
match
---
expr_stmt [12833,12864]
expr_stmt [12780,12811]
===
match
---
annassign [12054,12089]
annassign [12001,12036]
===
match
---
import_as_names [2182,2239]
import_as_names [2129,2186]
===
match
---
atom_expr [17866,17878]
atom_expr [17813,17825]
===
match
---
simple_stmt [6280,6349]
simple_stmt [6227,6296]
===
match
---
name: int [14981,14984]
name: int [14928,14931]
===
match
---
operator: = [4637,4638]
operator: = [4584,4585]
===
match
---
comparison [11287,11322]
comparison [11234,11269]
===
match
---
operator: , [36077,36078]
operator: , [35302,35303]
===
match
---
name: dag_run [43255,43262]
name: dag_run [42394,42401]
===
match
---
trailer [36668,36675]
trailer [35893,35900]
===
match
---
name: state [50832,50837]
name: state [49971,49976]
===
match
---
operator: , [10978,10979]
operator: , [10925,10926]
===
match
---
trailer [37358,37393]
trailer [36562,36597]
===
match
---
string: "Exception when executing SchedulerJob._run_scheduler_loop" [25738,25797]
string: "Exception when executing SchedulerJob._run_scheduler_loop" [25685,25744]
===
match
---
expr_stmt [15393,15541]
expr_stmt [15340,15488]
===
match
---
operator: += [8831,8833]
operator: += [8778,8780]
===
match
---
atom_expr [6164,6184]
atom_expr [6111,6131]
===
match
---
trailer [24573,24816]
trailer [24520,24763]
===
match
---
trailer [39758,39762]
trailer [38940,38944]
===
match
---
param [39803,39812]
param [38985,38994]
===
match
---
atom_expr [8415,8585]
atom_expr [8362,8532]
===
match
---
name: get_task [23032,23040]
name: get_task [22979,22987]
===
match
---
atom_expr [25021,25038]
atom_expr [24968,24985]
===
match
---
atom_expr [15012,15063]
atom_expr [14959,15010]
===
match
---
simple_stmt [5234,5250]
simple_stmt [5181,5197]
===
match
---
fstring_string: dagrun.schedule_delay. [40532,40554]
fstring_string: dagrun.schedule_delay. [39714,39736]
===
match
---
suite [9921,10006]
suite [9868,9953]
===
match
---
simple_stmt [14050,14118]
simple_stmt [13997,14065]
===
match
---
operator: , [4272,4273]
operator: , [4219,4220]
===
match
---
atom_expr [24886,24907]
atom_expr [24833,24854]
===
match
---
operator: , [42912,42913]
operator: , [42051,42052]
===
match
---
expr_stmt [39843,39872]
expr_stmt [39025,39054]
===
match
---
atom_expr [48030,48061]
atom_expr [47169,47200]
===
match
---
arglist [10029,10053]
arglist [9976,10000]
===
match
---
simple_stmt [13463,13554]
simple_stmt [13410,13501]
===
match
---
arglist [24410,24446]
arglist [24357,24393]
===
match
---
name: State [46054,46059]
name: State [45193,45198]
===
match
---
name: value [21058,21063]
name: value [21005,21010]
===
match
---
trailer [23258,23263]
trailer [23205,23210]
===
match
---
atom [10695,10766]
atom [10642,10713]
===
match
---
trailer [50778,50784]
trailer [49917,49923]
===
match
---
not_test [44814,44838]
not_test [43953,43977]
===
match
---
arglist [50819,50905]
arglist [49958,50044]
===
match
---
operator: , [8786,8787]
operator: , [8733,8734]
===
match
---
simple_stmt [11562,11663]
simple_stmt [11509,11610]
===
match
---
name: log [9939,9942]
name: log [9886,9889]
===
match
---
trailer [34862,34878]
trailer [34087,34103]
===
match
---
import_from [1460,1528]
import_from [1407,1475]
===
match
---
trailer [41394,41408]
trailer [40533,40547]
===
match
---
name: starved_pools [10843,10856]
name: starved_pools [10790,10803]
===
match
---
trailer [34278,34290]
trailer [33503,33515]
===
match
---
atom_expr [21443,21456]
atom_expr [21390,21403]
===
match
---
name: get [37605,37608]
name: get [36787,36790]
===
match
---
simple_stmt [36366,36499]
simple_stmt [35591,35724]
===
match
---
string: '*' [39436,39439]
string: '*' [38618,38621]
===
match
---
name: self [5862,5866]
name: self [5809,5813]
===
match
---
trailer [48399,48413]
trailer [47538,47552]
===
match
---
name: ti [22990,22992]
name: ti [22937,22939]
===
match
---
atom_expr [44818,44838]
atom_expr [43957,43977]
===
match
---
operator: , [45681,45682]
operator: , [44820,44821]
===
match
---
name: count [8788,8793]
name: count [8735,8740]
===
match
---
name: self [17936,17940]
name: self [17883,17887]
===
match
---
trailer [7624,7630]
trailer [7571,7577]
===
match
---
operator: == [22480,22482]
operator: == [22427,22429]
===
match
---
sync_comp_for [45338,45357]
sync_comp_for [44477,44496]
===
match
---
name: flush [42571,42576]
name: flush [41710,41715]
===
match
---
trailer [49518,49528]
trailer [48657,48667]
===
match
---
argument [44221,44236]
argument [43360,43375]
===
match
---
name: _process_executor_events [28485,28509]
name: _process_executor_events [28432,28456]
===
match
---
operator: , [20808,20809]
operator: , [20755,20756]
===
match
---
atom_expr [47293,47611]
atom_expr [46432,46750]
===
match
---
string: 'scheduler' [4535,4546]
string: 'scheduler' [4482,4493]
===
match
---
arglist [44525,44563]
arglist [43664,43702]
===
match
---
name: pickle_dags [24759,24770]
name: pickle_dags [24706,24717]
===
match
---
name: dag_id [36991,36997]
name: dag_id [36216,36222]
===
match
---
name: session [46390,46397]
name: session [45529,45536]
===
match
---
operator: = [21056,21057]
operator: = [21003,21004]
===
match
---
name: lower [5352,5357]
name: lower [5299,5304]
===
match
---
operator: , [47101,47102]
operator: , [46240,46241]
===
match
---
atom_expr [8443,8453]
atom_expr [8390,8400]
===
match
---
atom_expr [6653,6680]
atom_expr [6600,6627]
===
match
---
trailer [47916,47924]
trailer [47055,47063]
===
match
---
operator: = [24794,24795]
operator: = [24741,24742]
===
match
---
number: 1 [46318,46319]
number: 1 [45457,45458]
===
match
---
name: DagRunType [2519,2529]
name: DagRunType [2466,2476]
===
match
---
name: EXECUTION_STATES [12200,12216]
name: EXECUTION_STATES [12147,12163]
===
match
---
name: task_id [15485,15492]
name: task_id [15432,15439]
===
match
---
simple_stmt [37572,37621]
simple_stmt [36754,36803]
===
match
---
simple_stmt [18826,18978]
simple_stmt [18773,18925]
===
match
---
name: is_lock_not_available_error [2343,2370]
name: is_lock_not_available_error [2290,2317]
===
match
---
tfpdef [18156,18180]
tfpdef [18103,18127]
===
match
---
suite [12586,17120]
suite [12533,17067]
===
match
---
operator: , [51114,51115]
operator: , [50253,50254]
===
match
---
string: "trigger_id" [51258,51270]
string: "trigger_id" [50397,50409]
===
match
---
atom_expr [16178,16202]
atom_expr [16125,16149]
===
match
---
name: dag_run [41775,41782]
name: dag_run [40914,40921]
===
match
---
name: msg [23550,23553]
name: msg [23497,23500]
===
match
---
operator: = [20321,20322]
operator: = [20268,20269]
===
match
---
atom_expr [7665,7682]
atom_expr [7612,7629]
===
match
---
and_test [43113,43191]
and_test [42252,42330]
===
match
---
fstring_string: pool.starving_tasks. [17066,17086]
fstring_string: pool.starving_tasks. [17013,17033]
===
match
---
trailer [2542,2555]
trailer [2489,2502]
===
match
---
decorator [34884,34906]
decorator [34109,34131]
===
match
---
name: wait_until_finished [28210,28229]
name: wait_until_finished [28157,28176]
===
match
---
name: guard [34604,34609]
name: guard [33829,33834]
===
match
---
name: utils [2430,2435]
name: utils [2377,2382]
===
match
---
if_stmt [22276,22450]
if_stmt [22223,22397]
===
match
---
atom_expr [2580,2595]
atom_expr [2527,2542]
===
match
---
operator: , [48816,48817]
operator: , [47955,47956]
===
match
---
trailer [26943,26978]
trailer [26890,26925]
===
match
---
operator: , [29613,29614]
operator: , [29560,29561]
===
match
---
simple_stmt [43092,43101]
simple_stmt [42231,42240]
===
match
---
atom [23556,23583]
atom [23503,23530]
===
match
---
decorator [46192,46209]
decorator [45331,45348]
===
match
---
argument [11510,11552]
argument [11457,11499]
===
match
---
name: query [49032,49037]
name: query [48171,48176]
===
match
---
name: self [24886,24890]
name: self [24833,24837]
===
match
---
trailer [38448,38458]
trailer [37630,37640]
===
match
---
atom_expr [9591,9647]
atom_expr [9538,9594]
===
match
---
if_stmt [45483,45576]
if_stmt [44622,44715]
===
match
---
name: utcnow [25030,25036]
name: utcnow [24977,24983]
===
match
---
name: signal [5847,5853]
name: signal [5794,5800]
===
match
---
simple_stmt [8815,8840]
simple_stmt [8762,8787]
===
match
---
simple_stmt [35132,35176]
simple_stmt [34357,34401]
===
match
---
name: dag_model [15026,15035]
name: dag_model [14973,14982]
===
match
---
comparison [50819,50855]
comparison [49958,49994]
===
match
---
atom_expr [22288,22300]
atom_expr [22235,22247]
===
match
---
trailer [41964,41975]
trailer [41103,41114]
===
match
---
name: models [2561,2567]
name: models [2508,2514]
===
match
---
atom_expr [18596,18618]
atom_expr [18543,18565]
===
match
---
import_from [2091,2147]
import_from [2038,2094]
===
match
---
arglist [10973,11071]
arglist [10920,11018]
===
match
---
if_stmt [11284,11424]
if_stmt [11231,11371]
===
match
---
name: pool [13049,13053]
name: pool [12996,13000]
===
match
---
name: SIGINT [5854,5860]
name: SIGINT [5801,5807]
===
match
---
string: "-" [6824,6827]
string: "-" [6771,6774]
===
match
---
atom_expr [6394,6420]
atom_expr [6341,6367]
===
match
---
name: __name__ [47816,47824]
name: __name__ [46955,46963]
===
match
---
name: current_process [2810,2825]
name: current_process [2757,2772]
===
match
---
trailer [29311,29359]
trailer [29258,29306]
===
match
---
atom_expr [31745,31770]
atom_expr [31692,31717]
===
match
---
atom_expr [42348,42378]
atom_expr [41487,41517]
===
match
---
name: session [44556,44563]
name: session [43695,43702]
===
match
---
name: dag_model [38861,38870]
name: dag_model [38043,38052]
===
match
---
operator: , [5680,5681]
operator: , [5627,5628]
===
match
---
simple_stmt [14563,14902]
simple_stmt [14510,14849]
===
match
---
name: x [11515,11516]
name: x [11462,11463]
===
match
---
suite [31771,31834]
suite [31718,31781]
===
match
---
atom_expr [42361,42377]
atom_expr [41500,41516]
===
match
---
name: __init__ [4310,4318]
name: __init__ [4257,4265]
===
match
---
atom_expr [36934,36946]
atom_expr [36159,36171]
===
match
---
exprlist [33213,33237]
exprlist [32438,32462]
===
match
---
name: len [49652,49655]
name: len [48791,48794]
===
match
---
trailer [27228,27376]
trailer [27175,27323]
===
match
---
expr_stmt [12034,12089]
expr_stmt [11981,12036]
===
match
---
name: state [17859,17864]
name: state [17806,17811]
===
match
---
name: session [47293,47300]
name: session [46432,46439]
===
match
---
atom_expr [39680,39693]
atom_expr [38862,38875]
===
match
---
trailer [29320,29345]
trailer [29267,29292]
===
match
---
suite [50550,51453]
suite [49689,50592]
===
match
---
simple_stmt [22615,22808]
simple_stmt [22562,22755]
===
match
---
import_name [895,906]
import_name [895,906]
===
match
---
name: dag_model [38495,38504]
name: dag_model [37677,37686]
===
match
---
operator: = [4247,4248]
operator: = [4194,4195]
===
match
---
arglist [18732,18811]
arglist [18679,18758]
===
match
---
atom_expr [38495,38516]
atom_expr [37677,37698]
===
match
---
atom_expr [36606,37028]
atom_expr [35831,36253]
===
match
---
trailer [45605,45642]
trailer [44744,44781]
===
match
---
trailer [7534,7541]
trailer [7481,7488]
===
match
---
atom_expr [10572,10597]
atom_expr [10519,10544]
===
match
---
simple_stmt [23231,23240]
simple_stmt [23178,23187]
===
match
---
simple_stmt [15393,15542]
simple_stmt [15340,15489]
===
match
---
trailer [5839,5846]
trailer [5786,5793]
===
match
---
trailer [47488,47495]
trailer [46627,46634]
===
match
---
trailer [41052,41058]
trailer [40191,40197]
===
match
---
operator: = [14986,14987]
operator: = [14933,14934]
===
match
---
number: 0 [33545,33546]
number: 0 [32770,32771]
===
match
---
operator: , [4643,4644]
operator: , [4590,4591]
===
match
---
operator: @ [45716,45717]
operator: @ [44855,44856]
===
match
---
trailer [47993,47997]
trailer [47132,47136]
===
match
---
dictorsetmaker [51090,51277]
dictorsetmaker [50229,50416]
===
match
---
name: open_slots [16857,16867]
name: open_slots [16804,16814]
===
match
---
atom_expr [47801,47832]
atom_expr [46940,46971]
===
match
---
name: msg [23748,23751]
name: msg [23695,23698]
===
match
---
name: TI [21888,21890]
name: TI [21835,21837]
===
match
---
operator: , [15279,15280]
operator: , [15226,15227]
===
match
---
simple_stmt [20828,20876]
simple_stmt [20775,20823]
===
match
---
trailer [12881,12885]
trailer [12828,12832]
===
match
---
name: str [12074,12077]
name: str [12021,12024]
===
match
---
trailer [22369,22373]
trailer [22316,22320]
===
match
---
trailer [34528,34537]
trailer [33753,33762]
===
match
---
simple_stmt [14224,14456]
simple_stmt [14171,14403]
===
match
---
operator: , [39764,39765]
operator: , [38946,38947]
===
match
---
trailer [20645,20661]
trailer [20592,20608]
===
match
---
trailer [43146,43153]
trailer [42285,42292]
===
match
---
param [4617,4644]
param [4564,4591]
===
match
---
atom_expr [27386,27555]
atom_expr [27333,27502]
===
match
---
name: utcnow [50897,50903]
name: utcnow [50036,50042]
===
match
---
name: self [17418,17422]
name: self [17365,17369]
===
match
---
simple_stmt [23107,23171]
simple_stmt [23054,23118]
===
match
---
argument [24723,24733]
argument [24670,24680]
===
match
---
name: ti [23160,23162]
name: ti [23107,23109]
===
match
---
operator: += [16610,16612]
operator: += [16557,16559]
===
match
---
operator: = [27769,27770]
operator: = [27716,27717]
===
match
---
trailer [2809,2825]
trailer [2756,2772]
===
match
---
operator: , [18794,18795]
operator: , [18741,18742]
===
match
---
name: log [47142,47145]
name: log [46281,46284]
===
match
---
name: get_dag [44927,44934]
name: get_dag [44066,44073]
===
match
---
param [6920,6925]
param [6867,6872]
===
match
---
trailer [12805,12811]
trailer [12752,12758]
===
match
---
name: str [5309,5312]
name: str [5256,5259]
===
match
---
operator: , [24145,24146]
operator: , [24092,24093]
===
match
---
trailer [5319,5323]
trailer [5266,5270]
===
match
---
simple_stmt [1785,1875]
simple_stmt [1732,1822]
===
match
---
operator: , [20788,20789]
operator: , [20735,20736]
===
match
---
name: self [22365,22369]
name: self [22312,22316]
===
match
---
trailer [47795,47800]
trailer [46934,46939]
===
match
---
name: airflow [1912,1919]
name: airflow [1859,1866]
===
match
---
operator: { [40554,40555]
operator: { [39736,39737]
===
match
---
trailer [8396,8411]
trailer [8343,8358]
===
match
---
atom_expr [8627,8643]
atom_expr [8574,8590]
===
match
---
atom_expr [50819,50837]
atom_expr [49958,49976]
===
match
---
name: run_id [48821,48827]
name: run_id [47960,47966]
===
match
---
name: session [44659,44666]
name: session [43798,43805]
===
match
---
testlist_comp [36293,36341]
testlist_comp [35518,35566]
===
match
---
name: self [29893,29897]
name: self [29840,29844]
===
match
---
fstring_string: pool.open_slots. [45935,45951]
fstring_string: pool.open_slots. [45074,45090]
===
match
---
simple_stmt [24529,24817]
simple_stmt [24476,24764]
===
match
---
name: info [14233,14237]
name: info [14180,14184]
===
match
---
operator: = [21828,21829]
operator: = [21775,21776]
===
match
---
simple_stmt [860,870]
simple_stmt [860,870]
===
match
---
trailer [9597,9602]
trailer [9544,9549]
===
match
---
trailer [27023,27049]
trailer [26970,26996]
===
match
---
sync_comp_for [11518,11552]
sync_comp_for [11465,11499]
===
match
---
arglist [34863,34877]
arglist [34088,34102]
===
match
---
simple_stmt [32760,32819]
simple_stmt [32165,32224]
===
match
---
operator: = [4600,4601]
operator: = [4547,4548]
===
match
---
name: task_instance [15704,15717]
name: task_instance [15651,15664]
===
match
---
string: 'sql_alchemy_conn' [5332,5350]
string: 'sql_alchemy_conn' [5279,5297]
===
match
---
expr_stmt [14948,14992]
expr_stmt [14895,14939]
===
match
---
atom_expr [41511,41539]
atom_expr [40650,40678]
===
match
---
suite [21011,21651]
suite [20958,21598]
===
match
---
fstring_expr [46029,46040]
fstring_expr [45168,45179]
===
match
---
trailer [47038,47050]
trailer [46177,46189]
===
match
---
name: self [4723,4727]
name: self [4670,4674]
===
match
---
atom_expr [17654,18002]
atom_expr [17601,17949]
===
match
---
name: call_regular_interval [27207,27228]
name: call_regular_interval [27154,27175]
===
match
---
expr_stmt [44913,44936]
expr_stmt [44052,44075]
===
match
---
atom_expr [5483,5505]
atom_expr [5430,5452]
===
match
---
arglist [8547,8568]
arglist [8494,8515]
===
match
---
simple_stmt [42470,42506]
simple_stmt [41609,41645]
===
match
---
argument [44525,44546]
argument [43664,43685]
===
match
---
name: Exception [25906,25915]
name: Exception [25853,25862]
===
match
---
trailer [11085,11087]
trailer [11032,11034]
===
match
---
name: SimpleTaskInstance [23498,23516]
name: SimpleTaskInstance [23445,23463]
===
match
---
name: latest_heartbeat [7690,7706]
name: latest_heartbeat [7637,7653]
===
match
---
operator: , [20269,20270]
operator: , [20216,20217]
===
match
---
operator: = [20381,20382]
operator: = [20328,20329]
===
match
---
trailer [18722,18726]
trailer [18669,18673]
===
match
---
trailer [36239,36246]
trailer [35464,35471]
===
match
---
arglist [4261,4299]
arglist [4208,4246]
===
match
---
not_test [21701,21725]
not_test [21648,21672]
===
match
---
name: heartbeat_callback [46217,46235]
name: heartbeat_callback [45356,45374]
===
match
---
name: self [33274,33278]
name: self [32499,32503]
===
match
---
name: ti [22844,22846]
name: ti [22791,22793]
===
match
---
atom_expr [5014,5039]
atom_expr [4961,4986]
===
match
---
atom_expr [24092,24173]
atom_expr [24039,24120]
===
match
---
trailer [35136,35153]
trailer [34361,34378]
===
match
---
name: task_id [15740,15747]
name: task_id [15687,15694]
===
match
---
trailer [10624,10640]
trailer [10571,10587]
===
match
---
operator: = [14083,14084]
operator: = [14030,14031]
===
match
---
name: execution_date [36045,36059]
name: execution_date [35270,35284]
===
match
---
name: pickle_dags [24747,24758]
name: pickle_dags [24694,24705]
===
match
---
name: state [2436,2441]
name: state [2383,2388]
===
match
---
name: RUNNING [48717,48724]
name: RUNNING [47856,47863]
===
match
---
name: state [21024,21029]
name: state [20971,20976]
===
match
---
operator: , [23566,23567]
operator: , [23513,23514]
===
match
---
expr_stmt [13656,13723]
expr_stmt [13603,13670]
===
match
---
parameters [34938,34960]
parameters [34163,34185]
===
match
---
name: info [17427,17431]
name: info [17374,17378]
===
match
---
expr_stmt [24321,24355]
expr_stmt [24268,24302]
===
match
---
name: timer [28931,28936]
name: timer [28878,28883]
===
match
---
trailer [36860,36900]
trailer [36085,36125]
===
match
---
return_stmt [8896,8920]
return_stmt [8843,8867]
===
match
---
string: "DAG %s already has %d active runs, not moving any more runs to RUNNING state %s" [41080,41161]
string: "DAG %s already has %d active runs, not moving any more runs to RUNNING state %s" [40219,40300]
===
match
---
atom_expr [10877,10897]
atom_expr [10824,10844]
===
match
---
name: dag [37333,37336]
name: dag [36537,36540]
===
match
---
name: debug [28817,28822]
name: debug [28764,28769]
===
match
---
name: run_id [42298,42304]
name: run_id [41437,41443]
===
match
---
name: dagrun [1703,1709]
name: dagrun [1650,1656]
===
match
---
operator: , [20979,20980]
operator: , [20926,20927]
===
match
---
atom_expr [9934,9971]
atom_expr [9881,9918]
===
match
---
name: num_times_parse_dags [29898,29918]
name: num_times_parse_dags [29845,29865]
===
match
---
return_stmt [9984,10005]
return_stmt [9931,9952]
===
match
---
trailer [47141,47145]
trailer [46280,46284]
===
match
---
trailer [17940,17943]
trailer [17887,17890]
===
match
---
simple_stmt [5483,5559]
simple_stmt [5430,5506]
===
match
---
comparison [36038,36077]
comparison [35263,35302]
===
match
---
simple_stmt [42563,42579]
simple_stmt [41702,41718]
===
match
---
atom_expr [10482,10500]
atom_expr [10429,10447]
===
match
---
suite [29408,29655]
suite [29355,29602]
===
match
---
if_stmt [20634,20727]
if_stmt [20581,20674]
===
match
---
simple_stmt [26987,27050]
simple_stmt [26934,26997]
===
match
---
atom_expr [40460,40478]
atom_expr [39642,39660]
===
match
---
fstring [40530,40567]
fstring [39712,39749]
===
match
---
string: """         Finds TIs that are ready for execution with respect to pool limits,         dag max_active_tasks, executor state, and priority.          :param max_tis: Maximum number of TIs to queue in this loop.         :type max_tis: int         :return: list[airflow.models.TaskInstance]         """ [9054,9353]
string: """         Finds TIs that are ready for execution with respect to pool limits,         dag max_active_tasks, executor state, and priority.          :param max_tis: Maximum number of TIs to queue in this loop.         :type max_tis: int         :return: list[airflow.models.TaskInstance]         """ [9001,9300]
===
match
---
atom_expr [27791,27804]
atom_expr [27738,27751]
===
match
---
trailer [39952,39961]
trailer [39134,39143]
===
match
---
name: session [39308,39315]
name: session [38490,38497]
===
match
---
name: timedelta [45327,45336]
name: timedelta [44466,44475]
===
match
---
atom_expr [20906,20927]
atom_expr [20853,20874]
===
match
---
trailer [33428,33440]
trailer [32653,32665]
===
match
---
name: session [50771,50778]
name: session [49910,49917]
===
match
---
operator: -> [23858,23860]
operator: -> [23805,23807]
===
match
---
name: dag_run [43113,43120]
name: dag_run [42252,42259]
===
match
---
atom_expr [10730,10743]
atom_expr [10677,10690]
===
match
---
name: str [20780,20783]
name: str [20727,20730]
===
match
---
name: pool_name [12599,12608]
name: pool_name [12546,12555]
===
match
---
simple_stmt [38806,38849]
simple_stmt [37988,38031]
===
match
---
argument [38627,38649]
argument [37809,37831]
===
match
---
operator: , [22150,22151]
operator: , [22097,22098]
===
match
---
trailer [17882,17894]
trailer [17829,17841]
===
match
---
atom [47896,47925]
atom [47035,47064]
===
match
---
operator: += [13825,13827]
operator: += [13772,13774]
===
match
---
operator: , [17167,17168]
operator: , [17114,17115]
===
match
---
trailer [42497,42505]
trailer [41636,41644]
===
match
---
name: _send_dag_callbacks_to_processor [43016,43048]
name: _send_dag_callbacks_to_processor [42155,42187]
===
match
---
name: ti [23766,23768]
name: ti [23713,23715]
===
match
---
atom_expr [21830,21869]
atom_expr [21777,21816]
===
match
---
name: State [17866,17871]
name: State [17813,17818]
===
match
---
name: len [23816,23819]
name: len [23763,23766]
===
match
---
import_from [1724,1784]
import_from [1671,1731]
===
match
---
name: _get_next_dagruns_to_examine [31938,31966]
name: _get_next_dagruns_to_examine [31885,31913]
===
match
---
suite [16216,16787]
suite [16163,16734]
===
match
---
trailer [47145,47151]
trailer [46284,46290]
===
match
---
name: guard [31722,31727]
name: guard [31669,31674]
===
match
---
name: priority_sorted_task_instances [13137,13167]
name: priority_sorted_task_instances [13084,13114]
===
match
---
trailer [6856,6867]
trailer [6803,6814]
===
match
---
name: ti [49382,49384]
name: ti [48521,48523]
===
match
---
name: session [42522,42529]
name: session [41661,41668]
===
match
---
atom_expr [32839,32889]
atom_expr [32240,32290]
===
match
---
name: session [28518,28525]
name: session [28465,28472]
===
match
---
expr_stmt [36366,36498]
expr_stmt [35591,35723]
===
match
---
argument [28776,28790]
argument [28723,28737]
===
match
---
name: Signals [6660,6667]
name: Signals [6607,6614]
===
match
---
name: self [32778,32782]
name: self [32183,32187]
===
match
---
string: "%s tasks up for execution:\n\t%s" [11576,11610]
string: "%s tasks up for execution:\n\t%s" [11523,11557]
===
match
---
name: self [6394,6398]
name: self [6341,6345]
===
match
---
expr_stmt [17591,17641]
expr_stmt [17538,17588]
===
match
---
atom_expr [22365,22424]
atom_expr [22312,22371]
===
match
---
name: dag_id [36240,36246]
name: dag_id [35465,35471]
===
match
---
simple_stmt [28303,28349]
simple_stmt [28250,28296]
===
match
---
operator: , [11711,11712]
operator: , [11658,11659]
===
match
---
atom_expr [39859,39872]
atom_expr [39041,39054]
===
match
---
trailer [39597,39604]
trailer [38779,38786]
===
match
---
operator: { [51198,51199]
operator: { [50337,50338]
===
match
---
trailer [22989,23000]
trailer [22936,22947]
===
match
---
comparison [9900,9920]
comparison [9847,9867]
===
match
---
name: ti [49353,49355]
name: ti [48492,48494]
===
match
---
funcdef [8947,18099]
funcdef [8894,18046]
===
match
---
name: try_number [22469,22479]
name: try_number [22416,22426]
===
match
---
operator: -> [41508,41510]
operator: -> [40647,40649]
===
match
---
name: ti_key [21195,21201]
name: ti_key [21142,21148]
===
match
---
name: _enqueue_task_instances_with_queued_state [20405,20446]
name: _enqueue_task_instances_with_queued_state [20352,20393]
===
match
---
name: self [6920,6924]
name: self [6867,6871]
===
match
---
name: session [31874,31881]
name: session [31821,31828]
===
match
---
name: query [10973,10978]
name: query [10920,10925]
===
match
---
atom_expr [39664,39676]
atom_expr [38846,38858]
===
match
---
trailer [44926,44934]
trailer [44065,44073]
===
match
---
name: info [49920,49924]
name: info [49059,49063]
===
match
---
name: session [34016,34023]
name: session [33241,33248]
===
match
---
name: dag [42752,42755]
name: dag [41891,41894]
===
match
---
fstring [17064,17098]
fstring [17011,17045]
===
match
---
operator: , [45764,45765]
operator: , [44903,44904]
===
match
---
comparison [48623,48665]
comparison [47762,47804]
===
match
---
trailer [17519,17535]
trailer [17466,17482]
===
match
---
trailer [17422,17426]
trailer [17369,17373]
===
match
---
name: processor_agent [27879,27894]
name: processor_agent [27826,27841]
===
match
---
name: debug [9943,9948]
name: debug [9890,9895]
===
match
---
operator: , [27365,27366]
operator: , [27312,27313]
===
match
---
operator: , [16517,16518]
operator: , [16464,16465]
===
match
---
name: query [35154,35159]
name: query [34379,34384]
===
match
---
string: '_end' [47835,47841]
string: '_end' [46974,46980]
===
match
---
trailer [40935,40951]
trailer [40074,40090]
===
match
---
suite [41828,41931]
suite [40967,41070]
===
match
---
name: event_buffer [23820,23832]
name: event_buffer [23767,23779]
===
match
---
name: tuple_ [36226,36232]
name: tuple_ [35451,35457]
===
match
---
string: "Not executing %s since it requires %s slots " [16276,16322]
string: "Not executing %s since it requires %s slots " [16223,16269]
===
match
---
name: session [45848,45855]
name: session [44987,44994]
===
match
---
trailer [13249,13264]
trailer [13196,13211]
===
match
---
name: self [28320,28324]
name: self [28267,28271]
===
match
---
suite [44042,44676]
suite [43181,43815]
===
match
---
trailer [4525,4534]
trailer [4472,4481]
===
match
---
simple_stmt [18512,18634]
simple_stmt [18459,18581]
===
match
---
suite [46275,46324]
suite [45414,45463]
===
match
---
suite [37066,38920]
suite [36291,38102]
===
match
---
name: group_by [39722,39730]
name: group_by [38904,38912]
===
match
---
name: state [22279,22284]
name: state [22226,22231]
===
match
---
operator: , [34868,34869]
operator: , [34093,34094]
===
match
---
name: signal [5900,5906]
name: signal [5847,5853]
===
match
---
trailer [25029,25036]
trailer [24976,24983]
===
match
---
operator: = [42900,42901]
operator: = [42039,42040]
===
match
---
name: task_map [8912,8920]
name: task_map [8859,8867]
===
match
---
name: DefaultDict [11696,11707]
name: DefaultDict [11643,11654]
===
match
---
name: executable_tis [17394,17408]
name: executable_tis [17341,17355]
===
match
---
name: simple_task_instance [23477,23497]
name: simple_task_instance [23424,23444]
===
match
---
expr_stmt [12371,12399]
expr_stmt [12318,12346]
===
match
---
name: ti [22466,22468]
name: ti [22413,22415]
===
match
---
name: ti [18478,18480]
name: ti [18425,18427]
===
match
---
arglist [41395,41407]
arglist [40534,40546]
===
match
---
name: state [22848,22853]
name: state [22795,22800]
===
match
---
trailer [45307,45358]
trailer [44446,44497]
===
match
---
trailer [36539,36574]
trailer [35764,35799]
===
match
---
trailer [36065,36077]
trailer [35290,35302]
===
match
---
funcdef [45737,46187]
funcdef [44876,45326]
===
match
---
operator: == [42252,42254]
operator: == [41391,41393]
===
match
---
atom_expr [44634,44675]
atom_expr [43773,43814]
===
match
---
dotted_name [1308,1329]
dotted_name [1308,1329]
===
match
---
name: items [10736,10741]
name: items [10683,10688]
===
match
---
trailer [46102,46108]
trailer [45241,45247]
===
match
---
suite [20220,20302]
suite [20167,20249]
===
match
---
name: log [47699,47702]
name: log [46838,46841]
===
match
---
name: guard [35258,35263]
name: guard [34483,34488]
===
match
---
operator: , [27503,27504]
operator: , [27450,27451]
===
match
---
trailer [39864,39872]
trailer [39046,39054]
===
match
---
operator: = [7887,7888]
operator: = [7834,7835]
===
match
---
name: self [26099,26103]
name: self [26046,26050]
===
match
---
atom_expr [49515,49528]
atom_expr [48654,48667]
===
match
---
expr_stmt [40366,40426]
expr_stmt [39548,39608]
===
match
---
operator: = [18656,18657]
operator: = [18603,18604]
===
match
---
simple_stmt [11820,11885]
simple_stmt [11767,11832]
===
match
---
atom_expr [43113,43135]
atom_expr [42252,42274]
===
match
---
name: info [15892,15896]
name: info [15839,15843]
===
match
---
operator: , [8689,8690]
operator: , [8636,8637]
===
match
---
operator: , [25506,25507]
operator: , [25453,25454]
===
match
---
name: log [14568,14571]
name: log [14515,14518]
===
match
---
atom_expr [39615,39624]
atom_expr [38797,38806]
===
match
---
atom_expr [38806,38843]
atom_expr [37988,38025]
===
match
---
trailer [33440,33442]
trailer [32665,32667]
===
match
---
name: filter [10475,10481]
name: filter [10422,10428]
===
match
---
name: items [12578,12583]
name: items [12525,12530]
===
match
---
operator: , [41474,41475]
operator: , [40613,40614]
===
match
---
name: State [42361,42366]
name: State [41500,41505]
===
match
---
atom_expr [29316,29345]
atom_expr [29263,29292]
===
match
---
atom_expr [12800,12819]
atom_expr [12747,12766]
===
match
---
name: sqlalchemy [1105,1115]
name: sqlalchemy [1105,1115]
===
match
---
name: commit [33085,33091]
name: commit [32310,32316]
===
match
---
arglist [46741,46788]
arglist [45880,45927]
===
match
---
operator: , [49061,49062]
operator: , [48200,48201]
===
match
---
operator: == [39677,39679]
operator: == [38859,38861]
===
match
---
parameters [6468,6489]
parameters [6415,6436]
===
match
---
name: append [16819,16825]
name: append [16766,16772]
===
match
---
operator: = [43559,43560]
operator: = [42698,42699]
===
match
---
name: states [12188,12194]
name: states [12135,12141]
===
match
---
string: "DAG %s has %s/%s running and queued tasks" [14259,14302]
string: "DAG %s has %s/%s running and queued tasks" [14206,14249]
===
match
---
argument [23546,23583]
argument [23493,23530]
===
match
---
arglist [31967,31989]
arglist [31914,31936]
===
match
---
name: existing_dagruns [38356,38372]
name: existing_dagruns [37538,37554]
===
match
---
name: open_slots [16205,16215]
name: open_slots [16152,16162]
===
match
---
simple_stmt [50391,50410]
simple_stmt [49530,49549]
===
match
---
trailer [39892,39903]
trailer [39074,39085]
===
match
---
name: self [24014,24018]
name: self [23961,23965]
===
match
---
atom_expr [25639,25664]
atom_expr [25586,25611]
===
match
---
operator: = [33968,33969]
operator: = [33193,33194]
===
match
---
atom_expr [42752,42763]
atom_expr [41891,41902]
===
match
---
simple_stmt [43919,43942]
simple_stmt [43058,43081]
===
match
---
expr_stmt [6719,6741]
expr_stmt [6666,6688]
===
match
---
name: _start_queued_dagruns [31852,31873]
name: _start_queued_dagruns [31799,31820]
===
match
---
atom_expr [43011,43078]
atom_expr [42150,42217]
===
match
---
operator: = [49053,49054]
operator: = [48192,48193]
===
match
---
simple_stmt [22441,22450]
simple_stmt [22388,22397]
===
match
---
string: "Couldn't find dag %s in DagBag/DB!" [41856,41892]
string: "Couldn't find dag %s in DagBag/DB!" [40995,41031]
===
match
---
name: TI [42214,42216]
name: TI [41353,41355]
===
match
---
name: slots_stats [45828,45839]
name: slots_stats [44967,44978]
===
match
---
name: filter [21912,21918]
name: filter [21859,21865]
===
match
---
simple_stmt [50430,50436]
simple_stmt [49569,49575]
===
match
---
trailer [27571,27593]
trailer [27518,27540]
===
match
---
atom_expr [15726,15747]
atom_expr [15673,15694]
===
match
---
expr_stmt [46719,46789]
expr_stmt [45858,45928]
===
match
---
name: priority [18796,18804]
name: priority [18743,18751]
===
match
---
name: str [8680,8683]
name: str [8627,8630]
===
match
---
param [46384,46389]
param [45523,45528]
===
match
---
for_stmt [37038,38920]
for_stmt [36263,38102]
===
match
---
simple_stmt [23021,23053]
simple_stmt [22968,23000]
===
match
---
trailer [25605,25625]
trailer [25552,25572]
===
match
---
operator: = [18924,18925]
operator: = [18871,18872]
===
match
---
name: ti_key [21497,21503]
name: ti_key [21444,21450]
===
match
---
trailer [43870,43883]
trailer [43009,43022]
===
match
---
name: self [5669,5673]
name: self [5616,5620]
===
match
---
operator: = [4705,4706]
operator: = [4652,4653]
===
match
---
name: timezone [1998,2006]
name: timezone [1945,1953]
===
match
---
operator: , [20549,20550]
operator: , [20496,20497]
===
match
---
name: or_ [35912,35915]
name: or_ [35137,35140]
===
match
---
name: conf [4402,4406]
name: conf [4349,4353]
===
match
---
simple_stmt [1602,1642]
simple_stmt [1549,1589]
===
match
---
name: DR [10358,10360]
name: DR [10305,10307]
===
match
---
operator: , [43899,43900]
operator: , [43038,43039]
===
match
---
decorated [45716,46187]
decorated [44855,45326]
===
match
---
string: 'scheduler.tasks.executable' [17285,17313]
string: 'scheduler.tasks.executable' [17232,17260]
===
match
---
name: key [18791,18794]
name: key [18738,18741]
===
match
---
name: SimpleTaskInstance [1825,1843]
name: SimpleTaskInstance [1772,1790]
===
match
---
string: 'scheduler' [7542,7553]
string: 'scheduler' [7489,7500]
===
match
---
return_stmt [7599,7768]
return_stmt [7546,7715]
===
match
---
trailer [39613,39645]
trailer [38795,38827]
===
match
---
name: dag_run [39813,39820]
name: dag_run [38995,39002]
===
match
---
param [6034,6041]
param [5981,5988]
===
match
---
atom_expr [36428,36449]
atom_expr [35653,35674]
===
match
---
operator: , [1857,1858]
operator: , [1804,1805]
===
match
---
trailer [4697,4704]
trailer [4644,4651]
===
match
---
subscriptlist [12074,12082]
subscriptlist [12021,12029]
===
match
---
string: 'dag_model' [10585,10596]
string: 'dag_model' [10532,10543]
===
match
---
name: TI [10831,10833]
name: TI [10778,10780]
===
match
---
name: num_ready [13099,13108]
name: num_ready [13046,13055]
===
match
---
name: processor_agent [26898,26913]
name: processor_agent [26845,26860]
===
match
---
name: Session [34752,34759]
name: Session [33977,33984]
===
match
---
import_as_names [1825,1874]
import_as_names [1772,1821]
===
match
---
name: task_instances [18484,18498]
name: task_instances [18431,18445]
===
match
---
name: dag_run [44422,44429]
name: dag_run [43561,43568]
===
match
---
name: run_id [42643,42649]
name: run_id [41782,41788]
===
match
---
atom_expr [23028,23052]
atom_expr [22975,22999]
===
match
---
name: DagRun [36662,36668]
name: DagRun [35887,35893]
===
match
---
atom_expr [18522,18633]
atom_expr [18469,18580]
===
match
---
trailer [33658,33702]
trailer [32883,32927]
===
match
---
name: startswith [5397,5407]
name: startswith [5344,5354]
===
match
---
name: num_timed_out_tasks [51432,51451]
name: num_timed_out_tasks [50571,50590]
===
match
---
trailer [44509,44516]
trailer [43648,43655]
===
match
---
comp_op [7344,7350]
comp_op [7291,7297]
===
match
---
name: dag [39803,39806]
name: dag [38985,38988]
===
match
---
argument [17377,17408]
argument [17324,17355]
===
match
---
trailer [45975,45983]
trailer [45114,45122]
===
match
---
name: session [43372,43379]
name: session [42511,42518]
===
match
---
expr_stmt [24529,24816]
expr_stmt [24476,24763]
===
match
---
name: pool [12806,12810]
name: pool [12753,12757]
===
match
---
atom_expr [47382,47400]
atom_expr [46521,46539]
===
match
---
name: options [48777,48784]
name: options [47916,47923]
===
match
---
atom_expr [29425,29632]
atom_expr [29372,29579]
===
match
---
name: SIGTERM [5914,5921]
name: SIGTERM [5861,5868]
===
match
---
argument [27659,27671]
argument [27606,27618]
===
match
---
dotted_name [1880,1893]
dotted_name [1827,1840]
===
match
---
arglist [49616,49665]
arglist [48755,48804]
===
match
---
trailer [7446,7481]
trailer [7393,7428]
===
match
---
name: Stats [47790,47795]
name: Stats [46929,46934]
===
match
---
name: USE_JOB_SCHEDULE [31754,31770]
name: USE_JOB_SCHEDULE [31701,31717]
===
match
---
trailer [17023,17031]
trailer [16970,16978]
===
match
---
atom_expr [15253,15297]
atom_expr [15200,15244]
===
match
---
name: next_event [28852,28862]
name: next_event [28799,28809]
===
match
---
name: processor_agent [45590,45605]
name: processor_agent [44729,44744]
===
match
---
operator: , [35333,35334]
operator: , [34558,34559]
===
match
---
trailer [23031,23040]
trailer [22978,22987]
===
match
---
name: ti [22057,22059]
name: ti [22004,22006]
===
match
---
expr_stmt [23256,23270]
expr_stmt [23203,23217]
===
match
---
name: self [13463,13467]
name: self [13410,13414]
===
match
---
trailer [35915,36173]
trailer [35140,35398]
===
match
---
name: task_instance [16076,16089]
name: task_instance [16023,16036]
===
match
---
name: task_instance [42410,42423]
name: task_instance [41549,41562]
===
match
---
operator: , [1028,1029]
operator: , [1028,1029]
===
match
---
argument [5658,5680]
argument [5605,5627]
===
match
---
string: "Setting the following tasks to queued state:\n\t%s" [17432,17484]
string: "Setting the following tasks to queued state:\n\t%s" [17379,17431]
===
match
---
name: check_trigger_timeouts [27522,27544]
name: check_trigger_timeouts [27469,27491]
===
match
---
name: self [5234,5238]
name: self [5181,5185]
===
match
---
trailer [10521,10550]
trailer [10468,10497]
===
match
---
name: QUEUED [21590,21596]
name: QUEUED [21537,21543]
===
match
---
trailer [24605,24612]
trailer [24552,24559]
===
match
---
name: pool_slots_free [9900,9915]
name: pool_slots_free [9847,9862]
===
match
---
name: DagRunState [10410,10421]
name: DagRunState [10357,10368]
===
match
---
with_item [31694,31727]
with_item [31641,31674]
===
match
---
trailer [25951,25992]
trailer [25898,25939]
===
match
---
name: self [7685,7689]
name: self [7632,7636]
===
match
---
name: dag_model [37677,37686]
name: dag_model [36859,36868]
===
match
---
trailer [33525,33541]
trailer [32750,32766]
===
match
---
string: 'SchedulerJob' [4212,4226]
string: 'SchedulerJob' [4159,4173]
===
match
---
name: task_instance [11870,11883]
name: task_instance [11817,11830]
===
match
---
name: DefaultDict [7932,7943]
name: DefaultDict [7879,7890]
===
match
---
trailer [5899,5906]
trailer [5846,5853]
===
match
---
argument [27489,27502]
argument [27436,27449]
===
match
---
name: conf [4521,4525]
name: conf [4468,4472]
===
match
---
name: log [5217,5220]
name: log [5164,5167]
===
match
---
operator: = [24012,24013]
operator: = [23959,23960]
===
match
---
name: pool [13548,13552]
name: pool [13495,13499]
===
match
---
name: sleep [29306,29311]
name: sleep [29253,29258]
===
match
---
argument [42738,42763]
argument [41877,41902]
===
match
---
name: sla [45322,45325]
name: sla [44461,44464]
===
match
---
name: int [4470,4473]
name: int [4417,4420]
===
match
---
trailer [8549,8557]
trailer [8496,8504]
===
match
---
trailer [6886,6891]
trailer [6833,6838]
===
match
---
comparison [16178,16215]
comparison [16125,16162]
===
match
---
argument [41791,41806]
argument [40930,40945]
===
match
---
string: "Setting external_id for %s to %s" [22379,22413]
string: "Setting external_id for %s to %s" [22326,22360]
===
match
---
name: run_single_parsing_loop [27895,27918]
name: run_single_parsing_loop [27842,27865]
===
match
---
arglist [21275,21515]
arglist [21222,21462]
===
match
---
operator: = [44917,44918]
operator: = [44056,44057]
===
match
---
name: self [34939,34943]
name: self [34164,34168]
===
match
---
atom_expr [40693,40707]
atom_expr [39854,39868]
===
match
---
atom_expr [24921,24944]
atom_expr [24868,24891]
===
match
---
suite [27814,28864]
suite [27761,28811]
===
match
---
name: TI [9383,9385]
name: TI [9330,9332]
===
match
---
argument [34279,34289]
argument [33504,33514]
===
match
---
expr_stmt [14003,14032]
expr_stmt [13950,13979]
===
match
---
string: "Not executing %s since the number of tasks running or queued " [14602,14665]
string: "Not executing %s since the number of tasks running or queued " [14549,14612]
===
match
---
tfpdef [4488,4518]
tfpdef [4435,4465]
===
match
---
name: has_task_concurrency_limits [15036,15063]
name: has_task_concurrency_limits [14983,15010]
===
match
---
string: "-" [6892,6895]
string: "-" [6839,6842]
===
match
---
string: "DAG '%s' not found in serialized_dag table" [40803,40847]
string: "DAG '%s' not found in serialized_dag table" [39942,39986]
===
match
---
trailer [21008,21010]
trailer [20955,20957]
===
match
---
name: guard [31818,31823]
name: guard [31765,31770]
===
match
---
expr_stmt [10015,10054]
expr_stmt [9962,10001]
===
match
---
name: airflow [2492,2499]
name: airflow [2439,2446]
===
match
---
decorator [43947,43964]
decorator [43086,43103]
===
match
---
name: to_reset [49142,49150]
name: to_reset [48281,48289]
===
match
---
suite [29031,29360]
suite [28978,29307]
===
match
---
operator: = [42490,42491]
operator: = [41629,41630]
===
match
---
operator: , [34950,34951]
operator: , [34175,34176]
===
match
---
name: OperationalError [1127,1143]
name: OperationalError [1127,1143]
===
match
---
name: loop_count [29376,29386]
name: loop_count [29323,29333]
===
match
---
fstring_end: ' [17097,17098]
fstring_end: ' [17044,17045]
===
match
---
trailer [44301,44305]
trailer [43440,43444]
===
match
---
atom_expr [6730,6741]
atom_expr [6677,6688]
===
match
---
name: pool_name [46030,46039]
name: pool_name [45169,45178]
===
match
---
name: run [28772,28775]
name: run [28719,28722]
===
match
---
name: log [11567,11570]
name: log [11514,11517]
===
match
---
atom_expr [42522,42550]
atom_expr [41661,41689]
===
match
---
arglist [40693,40724]
arglist [39854,39885]
===
match
---
trailer [4727,4736]
trailer [4674,4683]
===
match
---
operator: , [29950,29951]
operator: , [29897,29898]
===
match
---
simple_stmt [35258,35273]
simple_stmt [34483,34498]
===
match
---
trailer [33829,33835]
trailer [33054,33060]
===
match
---
atom_expr [8603,8624]
atom_expr [8550,8571]
===
match
---
operator: = [15251,15252]
operator: = [15198,15199]
===
match
---
name: TaskCallbackRequest [23372,23391]
name: TaskCallbackRequest [23319,23338]
===
match
---
trailer [37343,37350]
trailer [36547,36554]
===
match
---
name: sqlalchemy [2325,2335]
name: sqlalchemy [2272,2282]
===
match
---
trailer [49615,49666]
trailer [48754,48805]
===
match
---
atom_expr [7664,7723]
atom_expr [7611,7670]
===
match
---
name: self [24529,24533]
name: self [24476,24480]
===
match
---
name: int [12021,12024]
name: int [11968,11971]
===
match
---
name: dag_run [42110,42117]
name: dag_run [41249,41256]
===
match
---
name: repr [49348,49352]
name: repr [48487,48491]
===
match
---
if_stmt [28960,29360]
if_stmt [28907,29307]
===
match
---
name: provide_session [8927,8942]
name: provide_session [8874,8889]
===
match
---
if_stmt [13423,13868]
if_stmt [13370,13815]
===
match
---
simple_stmt [45281,45288]
simple_stmt [44420,44427]
===
match
---
simple_stmt [34521,34540]
simple_stmt [33746,33765]
===
match
---
name: log [44302,44305]
name: log [43441,43444]
===
match
---
trailer [44498,44502]
trailer [43637,43641]
===
match
---
operator: * [5188,5189]
operator: * [5135,5136]
===
match
---
simple_stmt [20884,20933]
simple_stmt [20831,20880]
===
match
---
trailer [38407,38789]
trailer [37589,37971]
===
match
---
atom_expr [21746,21763]
atom_expr [21693,21710]
===
match
---
name: self [24843,24847]
name: self [24790,24794]
===
match
---
operator: } [17943,17944]
operator: } [17890,17891]
===
match
---
name: task_instance [42536,42549]
name: task_instance [41675,41688]
===
match
---
expr_stmt [20167,20206]
expr_stmt [20114,20153]
===
match
---
string: "Exited execute loop" [26198,26219]
string: "Exited execute loop" [26145,26166]
===
match
---
atom_expr [41044,41289]
atom_expr [40183,40428]
===
match
---
atom_expr [36003,36012]
atom_expr [35228,35237]
===
match
---
operator: , [43540,43541]
operator: , [42679,42680]
===
match
---
name: blocking [28776,28784]
name: blocking [28723,28731]
===
match
---
operator: , [14822,14823]
operator: , [14769,14770]
===
match
---
comparison [36918,36946]
comparison [36143,36171]
===
match
---
atom_expr [37339,37393]
atom_expr [36543,36597]
===
match
---
simple_stmt [10869,10898]
simple_stmt [10816,10845]
===
match
---
operator: = [5649,5650]
operator: = [5596,5597]
===
match
---
name: max_active_tasks [14191,14207]
name: max_active_tasks [14138,14154]
===
match
---
atom_expr [22318,22341]
atom_expr [22265,22288]
===
match
---
name: all [37012,37015]
name: all [36237,36240]
===
match
---
atom_expr [5651,5726]
atom_expr [5598,5673]
===
match
---
param [4488,4575]
param [4435,4522]
===
match
---
name: timers [27200,27206]
name: timers [27147,27153]
===
match
---
trailer [35270,35272]
trailer [34495,34497]
===
match
---
trailer [49915,49919]
trailer [49054,49058]
===
match
---
name: self [22970,22974]
name: self [22917,22921]
===
match
---
name: session [50391,50398]
name: session [49530,49537]
===
match
---
trailer [18853,18977]
trailer [18800,18924]
===
match
---
classdef [2852,51453]
classdef [2799,50592]
===
match
---
trailer [25430,25556]
trailer [25377,25503]
===
match
---
trailer [45494,45510]
trailer [44633,44649]
===
match
---
name: self [20126,20130]
name: self [20073,20077]
===
match
---
name: dag_run [40414,40421]
name: dag_run [39596,39603]
===
match
---
operator: , [51236,51237]
operator: , [50375,50376]
===
match
---
trailer [51377,51452]
trailer [50516,50591]
===
match
---
name: dagbag [1662,1668]
name: dagbag [1609,1615]
===
match
---
name: using_sqlite [27840,27852]
name: using_sqlite [27787,27799]
===
match
---
trailer [10259,10263]
trailer [10206,10210]
===
match
---
name: dag_run [40693,40700]
name: dag_run [39854,39861]
===
match
---
name: error [41850,41855]
name: error [40989,40994]
===
match
---
expr_stmt [17345,17409]
expr_stmt [17292,17356]
===
match
---
operator: , [43484,43485]
operator: , [42623,42624]
===
match
---
string: "Marking task instance %s as %s" [23126,23158]
string: "Marking task instance %s as %s" [23073,23105]
===
match
---
operator: , [48804,48805]
operator: , [47943,47944]
===
match
---
name: timedelta [24476,24485]
name: timedelta [24423,24432]
===
match
---
suite [38373,38849]
suite [37555,38031]
===
match
---
operator: @ [8926,8927]
operator: @ [8873,8874]
===
match
---
trailer [41186,41193]
trailer [40325,40332]
===
match
---
trailer [16245,16250]
trailer [16192,16197]
===
match
---
name: sig_name [6719,6727]
name: sig_name [6666,6674]
===
match
---
simple_stmt [37170,37223]
simple_stmt [36395,36448]
===
match
---
trailer [25130,25146]
trailer [25077,25093]
===
match
---
import_from [2306,2416]
import_from [2253,2363]
===
match
---
operator: , [13053,13054]
operator: , [13000,13001]
===
match
---
name: gauge [17135,17140]
name: gauge [17082,17087]
===
match
---
atom_expr [25573,25625]
atom_expr [25520,25572]
===
match
---
trailer [21560,21567]
trailer [21507,21514]
===
match
---
trailer [36406,36412]
trailer [35631,35637]
===
match
---
name: current_task_concurrency [15626,15650]
name: current_task_concurrency [15573,15597]
===
match
---
atom_expr [44945,44987]
atom_expr [44084,44126]
===
match
---
atom_expr [48711,48724]
atom_expr [47850,47863]
===
match
---
name: List [8386,8390]
name: List [8333,8337]
===
match
---
atom_expr [25508,25538]
atom_expr [25455,25485]
===
match
---
atom_expr [9842,9886]
atom_expr [9789,9833]
===
match
---
tfpdef [34743,34759]
tfpdef [33968,33984]
===
match
---
param [44733,44749]
param [43872,43888]
===
match
---
operator: = [33755,33756]
operator: = [32980,32981]
===
match
---
trailer [25647,25655]
trailer [25594,25602]
===
match
---
name: session [44667,44674]
name: session [43806,43813]
===
match
---
name: _processor_poll_interval [29321,29345]
name: _processor_poll_interval [29268,29292]
===
match
---
operator: = [24691,24692]
operator: = [24638,24639]
===
match
---
name: incr [34461,34465]
name: incr [33686,33690]
===
match
---
name: dag_run [41344,41351]
name: dag_run [40483,40490]
===
match
---
simple_stmt [17591,17642]
simple_stmt [17538,17589]
===
match
---
trailer [44204,44237]
trailer [43343,43376]
===
match
---
name: count [8471,8476]
name: count [8418,8423]
===
match
---
atom_expr [24398,24447]
atom_expr [24345,24394]
===
match
---
name: getboolean [27013,27023]
name: getboolean [26960,26970]
===
match
---
trailer [41255,41270]
trailer [40394,40409]
===
match
---
operator: , [48480,48481]
operator: , [47619,47620]
===
match
---
name: executor [24848,24856]
name: executor [24795,24803]
===
match
---
trailer [11745,11751]
trailer [11692,11698]
===
match
---
expr_stmt [47946,48851]
expr_stmt [47085,47990]
===
match
---
arglist [48623,48725]
arglist [47762,47864]
===
match
---
trailer [12674,12682]
trailer [12621,12629]
===
match
---
name: state [49385,49390]
name: state [48524,48529]
===
match
---
tfpdef [41459,41474]
tfpdef [40598,40613]
===
match
---
atom_expr [17377,17384]
atom_expr [17324,17331]
===
match
---
argument [23742,23781]
argument [23689,23728]
===
match
---
operator: , [8910,8911]
operator: , [8857,8858]
===
match
---
expr_stmt [2556,2574]
expr_stmt [2503,2521]
===
match
---
name: session [8429,8436]
name: session [8376,8383]
===
match
---
name: dag_runs [40609,40617]
name: dag_runs [39791,39799]
===
match
---
atom_expr [10534,10549]
atom_expr [10481,10496]
===
match
---
name: _executable_task_instances_to_queued [20328,20364]
name: _executable_task_instances_to_queued [20275,20311]
===
match
---
trailer [36434,36449]
trailer [35659,35674]
===
match
---
atom_expr [36413,36426]
atom_expr [35638,35651]
===
match
---
operator: , [17878,17879]
operator: , [17825,17826]
===
match
---
subscriptlist [8674,8694]
subscriptlist [8621,8641]
===
match
---
testlist_comp [13226,13264]
testlist_comp [13173,13211]
===
match
---
string: """         Get the concurrency maps.          :param states: List of states to query for         :type states: list[airflow.utils.state.State]         :return: A map from (dag_id, task_id) to # of task instances and          a map from (dag_id, task_id) to # of task instances in the given state list         :rtype: tuple[dict[str, int], dict[tuple[str, str], int]]         """ [7976,8355]
string: """         Get the concurrency maps.          :param states: List of states to query for         :type states: list[airflow.utils.state.State]         :return: A map from (dag_id, task_id) to # of task instances and          a map from (dag_id, task_id) to # of task instances in the given state list         :rtype: tuple[dict[str, int], dict[tuple[str, str], int]]         """ [7923,8302]
===
match
---
subscriptlist [8680,8688]
subscriptlist [8627,8635]
===
match
---
atom_expr [41894,41908]
atom_expr [41033,41047]
===
match
---
operator: , [27030,27031]
operator: , [26977,26978]
===
match
---
atom_expr [17936,17943]
atom_expr [17883,17890]
===
match
---
trailer [20856,20873]
trailer [20803,20820]
===
match
---
atom_expr [49065,49093]
atom_expr [48204,48232]
===
match
---
atom_expr [45921,45984]
atom_expr [45060,45123]
===
match
---
name: TI [10260,10262]
name: TI [10207,10209]
===
match
---
simple_stmt [12833,12865]
simple_stmt [12780,12812]
===
match
---
trailer [5571,5587]
trailer [5518,5534]
===
match
---
simple_stmt [45467,45474]
simple_stmt [44606,44613]
===
match
---
atom_expr [49734,49760]
atom_expr [48873,48899]
===
match
---
trailer [45025,45041]
trailer [44164,44180]
===
match
---
name: settings [45248,45256]
name: settings [44387,44395]
===
match
---
try_stmt [26005,26172]
try_stmt [25952,26119]
===
match
---
trailer [2827,2832]
trailer [2774,2779]
===
match
---
name: session [43533,43540]
name: session [42672,42679]
===
match
---
atom_expr [8662,8695]
atom_expr [8609,8642]
===
match
---
trailer [10474,10481]
trailer [10421,10428]
===
match
---
name: OperationalError [34229,34245]
name: OperationalError [33454,33470]
===
match
---
expr_stmt [38806,38848]
expr_stmt [37988,38030]
===
match
---
trailer [10481,10501]
trailer [10428,10448]
===
match
---
operator: = [46407,46408]
operator: = [45546,45547]
===
match
---
trailer [27335,27365]
trailer [27282,27312]
===
match
---
operator: , [38324,38325]
operator: , [37506,37507]
===
match
---
comparison [40992,41026]
comparison [40131,40165]
===
match
---
name: Session [35378,35385]
name: Session [34603,34610]
===
match
---
and_test [40968,41026]
and_test [40107,40165]
===
match
---
atom_expr [17608,17641]
atom_expr [17555,17588]
===
match
---
name: merge [42530,42535]
name: merge [41669,41674]
===
match
---
name: dag_run [40460,40467]
name: dag_run [39642,39649]
===
match
---
trailer [41351,41358]
trailer [40490,40497]
===
match
---
name: create_session [28254,28268]
name: create_session [28201,28215]
===
match
---
trailer [21252,21257]
trailer [21199,21204]
===
match
---
name: provide_session [46330,46345]
name: provide_session [45469,45484]
===
match
---
testlist_comp [15704,15747]
testlist_comp [15651,15694]
===
match
---
name: models [25573,25579]
name: models [25520,25526]
===
match
---
return_stmt [41922,41930]
return_stmt [41061,41069]
===
match
---
name: try_number [22011,22021]
name: try_number [21958,21968]
===
match
---
name: info [29434,29438]
name: info [29381,29385]
===
match
---
atom_expr [7620,7630]
atom_expr [7567,7577]
===
match
---
simple_stmt [25719,25799]
simple_stmt [25666,25746]
===
match
---
name: self [37452,37456]
name: self [36638,36642]
===
match
---
name: task_id [8870,8877]
name: task_id [8817,8824]
===
match
---
name: dag_run [41894,41901]
name: dag_run [41033,41040]
===
match
---
name: State [42128,42133]
name: State [41267,41272]
===
match
---
trailer [21942,21969]
trailer [21889,21916]
===
match
---
atom [4187,4227]
atom [4134,4174]
===
match
---
atom_expr [23568,23576]
atom_expr [23515,23523]
===
match
---
suite [20154,20207]
suite [20101,20154]
===
match
---
trailer [24018,24028]
trailer [23965,23975]
===
match
---
name: str [12016,12019]
name: str [11963,11966]
===
match
---
expr_stmt [2531,2555]
expr_stmt [2478,2502]
===
match
---
atom_expr [18788,18794]
atom_expr [18735,18741]
===
match
---
atom_expr [48550,48560]
atom_expr [47689,47699]
===
match
---
simple_stmt [29713,29970]
simple_stmt [29660,29917]
===
match
---
name: callback [44750,44758]
name: callback [43889,43897]
===
match
---
trailer [42117,42127]
trailer [41256,41266]
===
match
---
name: next_dagrun [38505,38516]
name: next_dagrun [37687,37698]
===
match
---
atom_expr [48482,48500]
atom_expr [47621,47639]
===
match
---
atom_expr [17203,17264]
atom_expr [17150,17211]
===
match
---
trailer [45386,45454]
trailer [44525,44593]
===
match
---
trailer [23672,23681]
trailer [23619,23628]
===
match
---
atom_expr [4521,4574]
atom_expr [4468,4521]
===
match
---
argument [9615,9629]
argument [9562,9576]
===
match
---
trailer [41901,41908]
trailer [41040,41047]
===
match
---
trailer [10447,10461]
trailer [10394,10408]
===
match
---
trailer [42297,42304]
trailer [41436,41443]
===
match
---
simple_stmt [24843,24874]
simple_stmt [24790,24821]
===
match
---
simple_stmt [24921,24945]
simple_stmt [24868,24892]
===
match
---
number: 1 [27770,27771]
number: 1 [27717,27718]
===
match
---
comparison [14475,14541]
comparison [14422,14488]
===
match
---
name: queued_by_job_id [49431,49447]
name: queued_by_job_id [48570,48586]
===
match
---
number: 0 [9839,9840]
number: 0 [9786,9787]
===
match
---
name: filter [42235,42241]
name: filter [41374,41380]
===
match
---
name: value [20981,20986]
name: value [20928,20933]
===
match
---
simple_stmt [20310,20391]
simple_stmt [20257,20338]
===
match
---
name: pickle_dags [24000,24011]
name: pickle_dags [23947,23958]
===
match
---
name: utcnow [47489,47495]
name: utcnow [46628,46634]
===
match
---
simple_stmt [1303,1342]
simple_stmt [1303,1342]
===
match
---
operator: , [42798,42799]
operator: , [41937,41938]
===
match
---
string: "__fail__" [51151,51161]
string: "__fail__" [50290,50300]
===
match
---
suite [14542,14931]
suite [14489,14878]
===
match
---
trailer [17858,17864]
trailer [17805,17811]
===
match
---
if_stmt [31742,31834]
if_stmt [31689,31781]
===
match
---
trailer [46294,46323]
trailer [45433,45462]
===
match
---
name: priority [18647,18655]
name: priority [18594,18602]
===
match
---
string: "and %s task instances ready to be queued" [12989,13031]
string: "and %s task instances ready to be queued" [12936,12978]
===
match
---
string: 'open' [10753,10759]
string: 'open' [10700,10706]
===
match
---
name: dag [38900,38903]
name: dag [38082,38085]
===
match
---
operator: , [46240,46241]
operator: , [45379,45380]
===
match
---
operator: = [5699,5700]
operator: = [5646,5647]
===
match
---
suite [18190,18978]
suite [18137,18925]
===
match
---
name: data_interval [38592,38605]
name: data_interval [37774,37787]
===
match
---
atom_expr [21497,21514]
atom_expr [21444,21461]
===
match
---
name: task_instances_to_examine [11616,11641]
name: task_instances_to_examine [11563,11588]
===
match
---
name: filter [48440,48446]
name: filter [47579,47585]
===
match
---
name: dag [40667,40670]
name: dag [39828,39831]
===
match
---
simple_stmt [37333,37394]
simple_stmt [36537,36598]
===
match
---
atom_expr [42823,42837]
atom_expr [41962,41976]
===
match
---
if_stmt [49799,50126]
if_stmt [48938,49265]
===
match
---
dotted_name [2096,2125]
dotted_name [2043,2072]
===
match
---
import_from [943,973]
import_from [943,973]
===
match
---
try_stmt [25846,25993]
try_stmt [25793,25940]
===
match
---
trailer [39617,39624]
trailer [38799,38806]
===
match
---
trailer [44658,44675]
trailer [43797,43814]
===
match
---
operator: = [31931,31932]
operator: = [31878,31879]
===
match
---
name: DagRun [36918,36924]
name: DagRun [36143,36149]
===
match
---
atom_expr [46155,46168]
atom_expr [45294,45307]
===
match
---
trailer [12885,12890]
trailer [12832,12837]
===
match
---
parameters [7821,7899]
parameters [7768,7846]
===
match
---
name: TI [42348,42350]
name: TI [41487,41489]
===
match
---
atom_expr [12555,12585]
atom_expr [12502,12532]
===
match
---
trailer [10842,10857]
trailer [10789,10804]
===
match
---
trailer [42340,42347]
trailer [41479,41486]
===
match
---
name: provide_session [7775,7790]
name: provide_session [7722,7737]
===
match
---
expr_stmt [13293,13315]
expr_stmt [13240,13262]
===
match
---
name: subdir [5674,5680]
name: subdir [5621,5627]
===
match
---
trailer [23115,23125]
trailer [23062,23072]
===
match
---
trailer [46657,46662]
trailer [45796,45801]
===
match
---
name: models [11718,11724]
name: models [11665,11671]
===
match
---
comp_if [10744,10765]
comp_if [10691,10712]
===
match
---
name: dag_id [41902,41908]
name: dag_id [41041,41047]
===
match
---
trailer [11509,11553]
trailer [11456,11500]
===
match
---
atom_expr [20769,20814]
atom_expr [20716,20761]
===
match
---
trailer [6659,6667]
trailer [6606,6614]
===
match
---
trailer [21201,21209]
trailer [21148,21156]
===
match
---
name: append [49341,49347]
name: append [48480,48486]
===
match
---
operator: , [38458,38459]
operator: , [37640,37641]
===
match
---
name: num_runs [29573,29581]
name: num_runs [29520,29528]
===
match
---
operator: , [30020,30021]
operator: , [29967,29968]
===
match
---
trailer [23726,23741]
trailer [23673,23688]
===
match
---
operator: = [4519,4520]
operator: = [4466,4467]
===
match
---
operator: { [47587,47588]
operator: { [46726,46727]
===
match
---
name: Tuple [7944,7949]
name: Tuple [7891,7896]
===
match
---
atom_expr [8815,8830]
atom_expr [8762,8777]
===
match
---
param [6042,6047]
param [5989,5994]
===
match
---
operator: { [45951,45952]
operator: { [45090,45091]
===
match
---
atom_expr [49486,49512]
atom_expr [48625,48651]
===
match
---
trailer [28936,28945]
trailer [28883,28892]
===
match
---
simple_stmt [22551,22599]
simple_stmt [22498,22546]
===
match
---
expr_stmt [40443,40500]
expr_stmt [39625,39682]
===
match
---
name: task_instance [14777,14790]
name: task_instance [14724,14737]
===
match
---
atom_expr [49382,49390]
atom_expr [48521,48529]
===
match
---
suite [35873,36174]
suite [35098,35399]
===
match
---
name: self [11336,11340]
name: self [11283,11287]
===
match
---
operator: , [39116,39117]
operator: , [38298,38299]
===
match
---
operator: = [43532,43533]
operator: = [42671,42672]
===
match
---
name: using_mysql [5431,5442]
name: using_mysql [5378,5389]
===
match
---
simple_stmt [19068,20115]
simple_stmt [19015,20062]
===
match
---
name: min [10025,10028]
name: min [9972,9975]
===
match
---
atom_expr [16912,16944]
atom_expr [16859,16891]
===
match
---
trailer [24639,24660]
trailer [24586,24607]
===
match
---
simple_stmt [9054,9354]
simple_stmt [9001,9301]
===
match
---
name: register_signals [24926,24942]
name: register_signals [24873,24889]
===
match
---
operator: , [39646,39647]
operator: , [38828,38829]
===
match
---
name: fallback [27489,27497]
name: fallback [27436,27444]
===
match
---
trailer [8583,8585]
trailer [8530,8532]
===
match
---
name: task_instances [18156,18170]
name: task_instances [18103,18117]
===
match
---
operator: = [39904,39905]
operator: = [39086,39087]
===
match
---
comparison [39664,39693]
comparison [38846,38875]
===
match
---
name: filter_for_tis [21813,21827]
name: filter_for_tis [21760,21774]
===
match
---
atom_expr [48785,48828]
atom_expr [47924,47967]
===
match
---
simple_stmt [1724,1785]
simple_stmt [1671,1732]
===
match
---
atom_expr [4356,4376]
atom_expr [4303,4323]
===
match
---
atom_expr [29312,29358]
atom_expr [29259,29305]
===
match
---
trailer [10281,10293]
trailer [10228,10240]
===
match
---
name: airflow [2153,2160]
name: airflow [2100,2107]
===
match
---
trailer [11053,11070]
trailer [11000,11017]
===
match
---
name: _process_executor_events [20520,20544]
name: _process_executor_events [20467,20491]
===
match
---
arglist [14259,14437]
arglist [14206,14384]
===
match
---
simple_stmt [8771,8803]
simple_stmt [8718,8750]
===
match
---
argument [38708,38725]
argument [37890,37907]
===
match
---
trailer [42071,42086]
trailer [41210,41225]
===
match
---
dotted_name [1465,1498]
dotted_name [1412,1445]
===
match
---
operator: == [44266,44268]
operator: == [43405,43407]
===
match
---
if_stmt [27832,28232]
if_stmt [27779,28179]
===
match
---
name: args [4654,4658]
name: args [4601,4605]
===
match
---
operator: = [27667,27668]
operator: = [27614,27615]
===
match
---
name: session [40709,40716]
name: session [39870,39877]
===
match
---
trailer [34377,34383]
trailer [33602,33608]
===
match
---
arith_expr [49734,49776]
arith_expr [48873,48915]
===
match
---
atom_expr [36063,36077]
atom_expr [35288,35302]
===
match
---
name: ti_primary_key_to_try_number_map [20735,20767]
name: ti_primary_key_to_try_number_map [20682,20714]
===
match
---
not_test [20637,20661]
not_test [20584,20608]
===
match
---
trailer [35960,36100]
trailer [35185,35325]
===
match
---
import_from [1972,2006]
import_from [1919,1953]
===
match
---
trailer [23768,23774]
trailer [23715,23721]
===
match
---
operator: , [41226,41227]
operator: , [40365,40366]
===
match
---
trailer [25941,25951]
trailer [25888,25898]
===
match
---
string: "state" [47588,47595]
string: "state" [46727,46734]
===
match
---
atom_expr [18718,18812]
atom_expr [18665,18759]
===
match
---
name: Session [25648,25655]
name: Session [25595,25602]
===
match
---
trailer [15358,15366]
trailer [15305,15313]
===
match
---
name: filter [42288,42294]
name: filter [41427,41433]
===
match
---
operator: -= [16868,16870]
operator: -= [16815,16817]
===
match
---
operator: = [45689,45690]
operator: = [44828,44829]
===
match
---
trailer [20446,20458]
trailer [20393,20405]
===
match
---
operator: , [50523,50524]
operator: , [49662,49663]
===
match
---
name: num_queued_tis [34638,34652]
name: num_queued_tis [33863,33877]
===
match
---
param [7831,7836]
param [7778,7783]
===
match
---
for_stmt [27730,29992]
for_stmt [27677,29939]
===
match
---
name: dag_run [10285,10292]
name: dag_run [10232,10239]
===
match
---
trailer [46002,46008]
trailer [45141,45147]
===
match
---
operator: , [8405,8406]
operator: , [8352,8353]
===
match
---
name: retry_db_transaction [34885,34905]
name: retry_db_transaction [34110,34130]
===
match
---
name: loop_count [29603,29613]
name: loop_count [29550,29560]
===
match
---
name: utils [2020,2025]
name: utils [1967,1972]
===
match
---
trailer [31753,31770]
trailer [31700,31717]
===
match
---
atom_expr [24033,24052]
atom_expr [23980,23999]
===
match
---
name: int [39153,39156]
name: int [38335,38338]
===
match
---
name: log [13468,13471]
name: log [13415,13418]
===
match
---
name: max_active_tasks_per_dag_limit [14511,14541]
name: max_active_tasks_per_dag_limit [14458,14488]
===
match
---
trailer [51368,51372]
trailer [50507,50511]
===
match
---
annassign [12002,12025]
annassign [11949,11972]
===
match
---
name: commit [31901,31907]
name: commit [31848,31854]
===
match
---
trailer [42350,42356]
trailer [41489,41495]
===
match
---
trailer [23320,23340]
trailer [23267,23287]
===
match
---
name: utils [2253,2258]
name: utils [2200,2205]
===
match
---
name: try_adopt_task_instances [49167,49191]
name: try_adopt_task_instances [48306,48330]
===
match
---
trailer [26192,26197]
trailer [26139,26144]
===
match
---
simple_stmt [32839,32890]
simple_stmt [32240,32291]
===
match
---
simple_stmt [23809,23834]
simple_stmt [23756,23781]
===
match
---
trailer [20181,20190]
trailer [20128,20137]
===
match
---
name: query [10869,10874]
name: query [10816,10821]
===
match
---
simple_stmt [5776,5825]
simple_stmt [5723,5772]
===
match
---
suite [46415,50466]
suite [45554,49605]
===
match
---
name: session [49085,49092]
name: session [48224,48231]
===
match
---
simple_stmt [2575,2596]
simple_stmt [2522,2543]
===
match
---
string: 'scheduler' [27621,27632]
string: 'scheduler' [27568,27579]
===
match
---
trailer [17431,17504]
trailer [17378,17451]
===
match
---
trailer [40856,40863]
trailer [39995,40002]
===
match
---
simple_stmt [29425,29633]
simple_stmt [29372,29580]
===
match
---
name: log [29430,29433]
name: log [29377,29380]
===
match
---
trailer [42604,42666]
trailer [41743,41805]
===
match
---
operator: = [4474,4475]
operator: = [4421,4422]
===
match
---
simple_stmt [12599,12616]
simple_stmt [12546,12563]
===
match
---
operator: , [47909,47910]
operator: , [47048,47049]
===
match
---
trailer [39429,39435]
trailer [38611,38617]
===
match
---
trailer [38549,38556]
trailer [37731,37738]
===
match
---
atom_expr [8674,8689]
atom_expr [8621,8636]
===
match
---
atom_expr [11843,11861]
atom_expr [11790,11808]
===
match
---
name: self [20641,20645]
name: self [20588,20592]
===
match
---
trailer [10489,10499]
trailer [10436,10446]
===
match
---
atom_expr [18697,18705]
atom_expr [18644,18652]
===
match
---
name: num_finished_events [29011,29030]
name: num_finished_events [28958,28977]
===
match
---
name: dag_ids [24723,24730]
name: dag_ids [24670,24677]
===
match
---
subscriptlist [12068,12088]
subscriptlist [12015,12035]
===
match
---
operator: = [4354,4355]
operator: = [4301,4302]
===
match
---
operator: = [25019,25020]
operator: = [24966,24967]
===
match
---
simple_stmt [34369,34435]
simple_stmt [33594,33660]
===
match
---
string: 'orphaned_tasks_check_interval' [27269,27300]
string: 'orphaned_tasks_check_interval' [27216,27247]
===
match
---
trailer [12670,12674]
trailer [12617,12621]
===
match
---
atom_expr [14085,14117]
atom_expr [14032,14064]
===
match
---
trailer [5187,5204]
trailer [5134,5151]
===
match
---
name: options [10307,10314]
name: options [10254,10261]
===
match
---
name: log [21249,21252]
name: log [21196,21199]
===
match
---
arglist [12908,13109]
arglist [12855,13056]
===
match
---
trailer [28663,28687]
trailer [28610,28634]
===
match
---
name: log [28098,28101]
name: log [28045,28048]
===
match
---
name: DagCallbackRequest [44769,44787]
name: DagCallbackRequest [43908,43926]
===
match
---
name: buffer_key [22176,22186]
name: buffer_key [22123,22133]
===
match
---
name: State [7634,7639]
name: State [7581,7586]
===
match
---
name: max_queued_dagruns [36507,36525]
name: max_queued_dagruns [35732,35750]
===
match
---
name: Optional [44760,44768]
name: Optional [43899,43907]
===
match
---
trailer [42576,42578]
trailer [41715,41717]
===
match
---
name: join [10277,10281]
name: join [10224,10228]
===
match
---
trailer [10350,10357]
trailer [10297,10304]
===
match
---
param [45760,45765]
param [44899,44904]
===
match
---
operator: = [22968,22969]
operator: = [22915,22916]
===
match
---
suite [34348,34569]
suite [33573,33794]
===
match
---
name: DefaultDict [7909,7920]
name: DefaultDict [7856,7867]
===
match
---
name: DAG [39808,39811]
name: DAG [38990,38993]
===
match
---
atom_expr [18658,18676]
atom_expr [18605,18623]
===
match
---
name: log [26104,26107]
name: log [26051,26054]
===
match
---
operator: , [50098,50099]
operator: , [49237,49238]
===
match
---
atom_expr [4402,4438]
atom_expr [4349,4385]
===
match
---
name: dag_run [42823,42830]
name: dag_run [41962,41969]
===
match
---
suite [26914,26979]
suite [26861,26926]
===
match
---
atom_expr [16804,16840]
atom_expr [16751,16787]
===
match
---
atom_expr [12056,12089]
atom_expr [12003,12036]
===
match
---
operator: = [50755,50756]
operator: = [49894,49895]
===
match
---
name: debug_dump [6857,6867]
name: debug_dump [6804,6814]
===
match
---
name: stop [34274,34278]
name: stop [33499,33503]
===
match
---
name: self [30016,30020]
name: self [29963,29967]
===
match
---
name: state [34723,34728]
name: state [33948,33953]
===
match
---
trailer [37015,37017]
trailer [36240,36242]
===
match
---
name: TI [10325,10327]
name: TI [10272,10274]
===
match
---
testlist_comp [35956,36141]
testlist_comp [35181,35366]
===
match
---
name: TI [8503,8505]
name: TI [8450,8452]
===
match
---
argument [18558,18568]
argument [18505,18515]
===
match
---
expr_stmt [12098,12244]
expr_stmt [12045,12191]
===
match
---
atom_expr [15321,15367]
atom_expr [15268,15314]
===
match
---
name: self [5071,5075]
name: self [5018,5022]
===
match
---
operator: , [24660,24661]
operator: , [24607,24608]
===
match
---
operator: , [49650,49651]
operator: , [48789,48790]
===
match
---
trailer [33762,33768]
trailer [32987,32993]
===
match
---
number: 0 [20152,20153]
number: 0 [20099,20100]
===
match
---
atom_expr [37583,37620]
atom_expr [36765,36802]
===
match
---
name: dag_models [35335,35345]
name: dag_models [34560,34570]
===
match
---
operator: - [13708,13709]
operator: - [13655,13656]
===
match
---
trailer [7437,7446]
trailer [7384,7393]
===
match
---
operator: = [22619,22620]
operator: = [22566,22567]
===
match
---
suite [23086,23240]
suite [23033,23187]
===
match
---
operator: , [34721,34722]
operator: , [33946,33947]
===
match
---
operator: , [21052,21053]
operator: , [20999,21000]
===
match
---
trailer [21887,21891]
trailer [21834,21838]
===
match
---
string: "DAG '%s' not found in serialized_dag table" [37471,37515]
string: "DAG '%s' not found in serialized_dag table" [36653,36697]
===
match
---
name: attempt [46803,46810]
name: attempt [45942,45949]
===
match
---
atom_expr [4249,4300]
atom_expr [4196,4247]
===
match
---
name: name [35857,35861]
name: name [35082,35086]
===
match
---
simple_stmt [4693,4714]
simple_stmt [4640,4661]
===
match
---
name: dag_map [8815,8822]
name: dag_map [8762,8769]
===
match
---
decorator [45716,45733]
decorator [44855,44872]
===
match
---
trailer [20847,20856]
trailer [20794,20803]
===
match
---
arglist [41080,41271]
arglist [40219,40410]
===
match
---
name: task_instance [11843,11856]
name: task_instance [11790,11803]
===
match
---
trailer [21749,21763]
trailer [21696,21710]
===
match
---
simple_stmt [28458,28527]
simple_stmt [28405,28474]
===
match
---
name: task_map [8652,8660]
name: task_map [8599,8607]
===
match
---
name: _critical_section_execute_task_instances [18987,19027]
name: _critical_section_execute_task_instances [18934,18974]
===
match
---
name: TI [10939,10941]
name: TI [10886,10888]
===
match
---
trailer [15887,15891]
trailer [15834,15838]
===
match
---
subscriptlist [7909,7965]
subscriptlist [7856,7912]
===
match
---
operator: = [37581,37582]
operator: = [36763,36764]
===
match
---
name: expunge_all [33429,33440]
name: expunge_all [32654,32665]
===
match
---
operator: , [24416,24417]
operator: , [24363,24364]
===
match
---
return_stmt [18077,18098]
return_stmt [18024,18045]
===
match
---
name: debug [28102,28107]
name: debug [28049,28054]
===
match
---
simple_stmt [18077,18099]
simple_stmt [18024,18046]
===
match
---
dotted_name [1977,1990]
dotted_name [1924,1937]
===
match
---
strings [16276,16392]
strings [16223,16339]
===
match
---
operator: = [35910,35911]
operator: = [35135,35136]
===
match
---
trailer [27414,27555]
trailer [27361,27502]
===
match
---
name: next_dagruns_to_examine [34839,34862]
name: next_dagruns_to_examine [34064,34087]
===
match
---
name: dag [40653,40656]
name: dag [39814,39817]
===
match
---
name: processor_agent [28194,28209]
name: processor_agent [28141,28156]
===
match
---
name: ti [18065,18067]
name: ti [18012,18014]
===
match
---
name: QUEUED [47903,47909]
name: QUEUED [47042,47048]
===
match
---
atom_expr [42048,42065]
atom_expr [41187,41204]
===
match
---
atom_expr [10448,10460]
atom_expr [10395,10407]
===
match
---
trailer [50784,50798]
trailer [49923,49937]
===
match
---
name: debug [46903,46908]
name: debug [46042,46047]
===
match
---
trailer [31709,31718]
trailer [31656,31665]
===
match
---
trailer [49166,49191]
trailer [48305,48330]
===
match
---
trailer [29429,29433]
trailer [29376,29380]
===
match
---
name: execution_date [10645,10659]
name: execution_date [10592,10606]
===
match
---
trailer [28229,28231]
trailer [28176,28178]
===
match
---
name: active_runs_of_dags [40916,40935]
name: active_runs_of_dags [40055,40074]
===
match
---
atom_expr [44505,44564]
atom_expr [43644,43703]
===
match
---
name: filter [10819,10825]
name: filter [10766,10772]
===
match
---
atom_expr [6429,6447]
atom_expr [6376,6394]
===
match
---
trailer [48776,48784]
trailer [47915,47923]
===
match
---
name: self [18826,18830]
name: self [18773,18777]
===
match
---
atom_expr [10813,10859]
atom_expr [10760,10806]
===
match
---
atom [36866,36898]
atom [36091,36123]
===
match
---
name: current_index [13710,13723]
name: current_index [13657,13670]
===
match
---
string: 'scheduler' [46741,46752]
string: 'scheduler' [45880,45891]
===
match
---
simple_stmt [49382,49404]
simple_stmt [48521,48543]
===
match
---
expr_stmt [44491,44564]
expr_stmt [43630,43703]
===
match
---
simple_stmt [24321,24356]
simple_stmt [24268,24303]
===
match
---
trailer [21194,21210]
trailer [21141,21157]
===
match
---
name: task [23259,23263]
name: task [23206,23210]
===
match
---
trailer [13476,13553]
trailer [13423,13500]
===
match
---
atom_expr [44162,44237]
atom_expr [43301,43376]
===
match
---
import_name [837,859]
import_name [837,859]
===
match
---
name: filter_for_tis [21833,21847]
name: filter_for_tis [21780,21794]
===
match
---
atom_expr [23498,23520]
atom_expr [23445,23467]
===
match
---
simple_stmt [50445,50466]
simple_stmt [49584,49605]
===
match
---
operator: , [8992,8993]
operator: , [8939,8940]
===
match
---
name: log [11341,11344]
name: log [11288,11291]
===
match
---
name: ti [18658,18660]
name: ti [18605,18607]
===
match
---
atom_expr [29713,29969]
atom_expr [29660,29916]
===
match
---
expr_stmt [13137,13279]
expr_stmt [13084,13226]
===
match
---
atom_expr [20843,20875]
atom_expr [20790,20822]
===
match
---
trailer [46902,46908]
trailer [46041,46047]
===
match
---
tfpdef [19034,19050]
tfpdef [18981,18997]
===
match
---
param [6469,6474]
param [6416,6421]
===
match
---
atom_expr [2561,2574]
atom_expr [2508,2521]
===
match
---
trailer [42127,42141]
trailer [41266,41280]
===
match
---
operator: @ [46192,46193]
operator: @ [45331,45332]
===
match
---
suite [15064,16158]
suite [15011,16105]
===
match
---
name: timer [27808,27813]
name: timer [27755,27760]
===
match
---
atom_expr [4693,4704]
atom_expr [4640,4651]
===
match
---
argument [42855,42879]
argument [41994,42018]
===
match
---
trailer [4260,4300]
trailer [4207,4247]
===
match
---
name: send_callback_to_execute [23648,23672]
name: send_callback_to_execute [23595,23619]
===
match
---
arglist [47382,47528]
arglist [46521,46667]
===
match
---
string: "state" [51090,51097]
string: "state" [50229,50236]
===
match
---
name: query [10813,10818]
name: query [10760,10765]
===
match
---
name: self [41841,41845]
name: self [40980,40984]
===
match
---
name: DagRun [2568,2574]
name: DagRun [2515,2521]
===
match
---
atom_expr [5071,5100]
atom_expr [5018,5047]
===
match
---
suite [24830,25681]
suite [24777,25628]
===
match
---
arglist [14602,14879]
arglist [14549,14826]
===
match
---
operator: , [12122,12123]
operator: , [12069,12070]
===
match
---
trailer [44539,44546]
trailer [43678,43685]
===
match
---
exprlist [45869,45890]
exprlist [45008,45029]
===
match
---
file_input [789,51453]
file_input [789,50592]
===
match
---
atom_expr [50314,50329]
atom_expr [49453,49468]
===
match
---
name: ti [18522,18524]
name: ti [18469,18471]
===
match
---
return_stmt [7423,7481]
return_stmt [7370,7428]
===
match
---
name: exit [6433,6437]
name: exit [6380,6384]
===
match
---
name: frame [6483,6488]
name: frame [6430,6435]
===
match
---
atom_expr [27874,27920]
atom_expr [27821,27867]
===
match
---
name: str [7950,7953]
name: str [7897,7900]
===
match
---
name: ti [23568,23570]
name: ti [23515,23517]
===
match
---
trailer [10324,10336]
trailer [10271,10283]
===
match
---
expr_stmt [42680,42927]
expr_stmt [41819,42066]
===
match
---
arglist [46295,46322]
arglist [45434,45461]
===
match
---
name: State [48711,48716]
name: State [47850,47855]
===
match
---
operator: = [27497,27498]
operator: = [27444,27445]
===
match
---
name: State [42492,42497]
name: State [41631,41636]
===
match
---
trailer [10611,10620]
trailer [10558,10567]
===
match
---
strings [14602,14751]
strings [14549,14698]
===
match
---
trailer [38899,38919]
trailer [38081,38101]
===
match
---
name: _ [21054,21055]
name: _ [21001,21002]
===
match
---
name: in_ [48039,48042]
name: in_ [47178,47181]
===
match
---
name: len [21746,21749]
name: len [21693,21696]
===
match
---
arglist [29748,29951]
arglist [29695,29898]
===
match
---
string: "Timed out %i deferred tasks without fired triggers" [51378,51430]
string: "Timed out %i deferred tasks without fired triggers" [50517,50569]
===
match
---
simple_stmt [2556,2575]
simple_stmt [2503,2522]
===
match
---
name: Exception [23076,23085]
name: Exception [23023,23032]
===
match
---
operator: = [9638,9639]
operator: = [9585,9586]
===
match
---
operator: = [47894,47895]
operator: = [47033,47034]
===
match
---
atom_expr [33824,33837]
atom_expr [33049,33062]
===
match
---
trailer [44212,44219]
trailer [43351,43358]
===
match
---
arglist [18871,18963]
arglist [18818,18910]
===
match
---
atom_expr [24601,24612]
atom_expr [24548,24559]
===
match
---
name: ti_key [20973,20979]
name: ti_key [20920,20926]
===
match
---
name: dag_folder [5658,5668]
name: dag_folder [5605,5615]
===
match
---
name: _is_parent_process [6506,6524]
name: _is_parent_process [6453,6471]
===
match
---
name: num_timed_out_tasks [51331,51350]
name: num_timed_out_tasks [50470,50489]
===
match
---
expr_stmt [27059,27084]
expr_stmt [27006,27031]
===
match
---
name: int [7961,7964]
name: int [7908,7911]
===
match
---
annassign [8601,8643]
annassign [8548,8590]
===
match
---
atom_expr [42651,42665]
atom_expr [41790,41804]
===
match
---
parameters [6919,6967]
parameters [6866,6914]
===
match
---
name: unfinished [42367,42377]
name: unfinished [41506,41516]
===
match
---
name: dag_run [42308,42315]
name: dag_run [41447,41454]
===
match
---
name: queued_runs_of_dags [37185,37204]
name: queued_runs_of_dags [36410,36429]
===
match
---
string: """         The actual scheduler loop. The main steps in the loop are:             #. Harvest DAG parsing results through DagFileProcessorAgent             #. Find and queue executable tasks                 #. Change task instance state in DB                 #. Queue tasks in executor             #. Heartbeat executor                 #. Execute queued tasks in executor asynchronously                 #. Sync on the states of running tasks          Following is a graphic representation of these steps.          .. image:: ../docs/apache-airflow/img/scheduler_loop.jpg          :rtype: None         """ [26273,26877]
string: """         The actual scheduler loop. The main steps in the loop are:             #. Harvest DAG parsing results through DagFileProcessorAgent             #. Find and queue executable tasks                 #. Change task instance state in DB                 #. Queue tasks in executor             #. Heartbeat executor                 #. Execute queued tasks in executor asynchronously                 #. Sync on the states of running tasks          Following is a graphic representation of these steps.          .. image:: ../docs/apache-airflow/img/scheduler_loop.jpg          :rtype: None         """ [26220,26824]
===
match
---
trailer [15717,15724]
trailer [15664,15671]
===
match
---
simple_stmt [5893,5946]
simple_stmt [5840,5893]
===
match
---
name: sqlalchemy [1211,1221]
name: sqlalchemy [1211,1221]
===
match
---
operator: = [36383,36384]
operator: = [35608,35609]
===
match
---
atom_expr [42591,42666]
atom_expr [41730,41805]
===
match
---
name: info [23884,23888]
name: info [23831,23835]
===
match
---
testlist_star_expr [21047,21055]
testlist_star_expr [20994,21002]
===
match
---
name: session [49046,49053]
name: session [48185,48192]
===
match
---
operator: , [10997,10998]
operator: , [10944,10945]
===
match
---
operator: , [12741,12742]
operator: , [12688,12689]
===
match
---
operator: , [17313,17314]
operator: , [17260,17261]
===
match
---
atom_expr [27835,27852]
atom_expr [27782,27799]
===
match
---
operator: } [46140,46141]
operator: } [45279,45280]
===
match
---
name: DR [10398,10400]
name: DR [10345,10347]
===
match
---
arglist [36233,36269]
arglist [35458,35494]
===
match
---
name: get_task [15433,15441]
name: get_task [15380,15388]
===
match
---
name: DagRun [34832,34838]
name: DagRun [34057,34063]
===
match
---
name: TI [48451,48453]
name: TI [47590,47592]
===
match
---
name: log [42596,42599]
name: log [41735,41738]
===
match
---
arglist [31818,31832]
arglist [31765,31779]
===
match
---
name: DagModel [2587,2595]
name: DagModel [2534,2542]
===
match
---
simple_stmt [2787,2850]
simple_stmt [2734,2797]
===
match
---
expr_stmt [37170,37222]
expr_stmt [36395,36447]
===
match
---
simple_stmt [30047,31608]
simple_stmt [29994,31555]
===
match
---
name: self [28189,28193]
name: self [28136,28140]
===
match
---
name: periodic [39953,39961]
name: periodic [39135,39143]
===
match
---
name: ti [23557,23559]
name: ti [23504,23506]
===
match
---
trailer [42595,42599]
trailer [41734,41738]
===
match
---
arith_expr [47480,47526]
arith_expr [46619,46665]
===
match
---
name: update [47580,47586]
name: update [46719,46725]
===
match
---
name: min [20243,20246]
name: min [20190,20193]
===
match
---
operator: == [50838,50840]
operator: == [49977,49979]
===
match
---
name: conf [5513,5517]
name: conf [5460,5464]
===
match
---
atom_expr [26893,26913]
atom_expr [26840,26860]
===
match
---
param [39112,39117]
param [38294,38299]
===
match
---
funcdef [20516,23834]
funcdef [20463,23781]
===
match
---
atom_expr [47031,47065]
atom_expr [46170,46204]
===
match
---
name: info [23776,23780]
name: info [23723,23727]
===
match
---
name: sum [9842,9845]
name: sum [9789,9792]
===
match
---
atom_expr [47480,47497]
atom_expr [46619,46636]
===
match
---
name: provide_session [46193,46208]
name: provide_session [45332,45347]
===
match
---
operator: , [22417,22418]
operator: , [22364,22365]
===
match
---
trailer [36005,36012]
trailer [35230,35237]
===
match
---
operator: = [45847,45848]
operator: = [44986,44987]
===
match
---
number: 0 [17538,17539]
number: 0 [17485,17486]
===
match
---
if_stmt [12628,12774]
if_stmt [12575,12721]
===
match
---
name: count [39430,39435]
name: count [38612,38617]
===
match
---
trailer [37214,37221]
trailer [36439,36446]
===
match
---
name: dag_id [41783,41789]
name: dag_id [40922,40928]
===
match
---
trailer [4534,4574]
trailer [4481,4521]
===
match
---
operator: , [14302,14303]
operator: , [14249,14250]
===
match
---
name: DagRun [48623,48629]
name: DagRun [47762,47768]
===
match
---
name: defaultdict [8627,8638]
name: defaultdict [8574,8585]
===
match
---
atom_expr [5862,5883]
atom_expr [5809,5830]
===
match
---
if_stmt [45297,45474]
if_stmt [44436,44613]
===
match
---
name: max_active_runs [40972,40987]
name: max_active_runs [40111,40126]
===
match
---
name: models [1737,1743]
name: models [1684,1690]
===
match
---
name: State [47897,47902]
name: State [47036,47041]
===
match
---
name: dag_run [41957,41964]
name: dag_run [41096,41103]
===
match
---
string: " this task has been reached." [16012,16042]
string: " this task has been reached." [15959,15989]
===
match
---
name: reset_tis_message [49323,49340]
name: reset_tis_message [48462,48479]
===
match
---
name: session [34952,34959]
name: session [34177,34184]
===
match
---
simple_stmt [2240,2306]
simple_stmt [2187,2253]
===
match
---
trailer [42244,42251]
trailer [41383,41390]
===
match
---
comparison [29376,29407]
comparison [29323,29354]
===
match
---
name: heartrate [4232,4241]
name: heartrate [4179,4188]
===
match
---
operator: , [14790,14791]
operator: , [14737,14738]
===
match
---
name: DagRunState [2449,2460]
name: DagRunState [2396,2407]
===
match
---
trailer [48453,48470]
trailer [47592,47609]
===
match
---
param [41484,41501]
param [40623,40640]
===
match
---
and_test [28963,29030]
and_test [28910,28977]
===
match
---
name: ti [23256,23258]
name: ti [23203,23205]
===
match
---
name: full_filepath [23417,23430]
name: full_filepath [23364,23377]
===
match
---
simple_stmt [26026,26053]
simple_stmt [25973,26000]
===
match
---
param [4342,4377]
param [4289,4324]
===
match
---
name: SerializedDagNotFound [37413,37434]
name: dag [36617,36620]
===
match
---
name: execution_date [38480,38494]
name: execution_date [37662,37676]
===
match
---
expr_stmt [12599,12615]
expr_stmt [12546,12562]
===
match
---
name: result [8727,8733]
name: result [8674,8680]
===
match
---
trailer [13229,13245]
trailer [13176,13192]
===
match
---
operator: , [1016,1017]
operator: , [1016,1017]
===
match
---
argument [10992,10997]
argument [10939,10944]
===
match
---
trailer [21955,21968]
trailer [21902,21915]
===
match
---
name: task_id [23044,23051]
name: task_id [22991,22998]
===
match
---
name: dag_models [36887,36897]
name: dag_models [36112,36122]
===
match
---
if_stmt [45241,45288]
if_stmt [44380,44427]
===
match
---
expr_stmt [9362,9391]
expr_stmt [9309,9338]
===
match
---
name: get_dag [15265,15272]
name: get_dag [15212,15219]
===
match
---
name: State [39680,39685]
name: State [38862,38867]
===
match
---
simple_stmt [44297,44394]
simple_stmt [43436,43533]
===
match
---
name: latest_version [44269,44283]
name: latest_version [43408,43422]
===
match
---
name: timedelta [47500,47509]
name: timedelta [46639,46648]
===
match
---
name: dag_run [44634,44641]
name: dag_run [43773,43780]
===
match
---
trailer [5323,5351]
trailer [5270,5298]
===
match
---
name: pools [12800,12805]
name: pools [12747,12752]
===
match
---
trailer [4406,4413]
trailer [4353,4360]
===
match
---
name: info [22344,22348]
name: info [22291,22295]
===
match
---
name: slots_stats [9603,9614]
name: slots_stats [9550,9561]
===
match
---
trailer [23647,23672]
trailer [23594,23619]
===
match
---
simple_stmt [822,837]
simple_stmt [822,837]
===
match
---
param [41459,41475]
param [40598,40614]
===
match
---
trailer [26050,26052]
trailer [25997,25999]
===
match
---
trailer [45540,45575]
trailer [44679,44714]
===
match
---
name: pool [12611,12615]
name: pool [12558,12562]
===
match
---
operator: = [23430,23431]
operator: = [23377,23378]
===
match
---
name: ti [13247,13249]
name: ti [13194,13196]
===
match
---
operator: , [18933,18934]
operator: , [18880,18881]
===
match
---
trailer [8511,8515]
trailer [8458,8462]
===
match
---
name: dag_id [15718,15724]
name: dag_id [15665,15671]
===
match
---
simple_stmt [2628,2783]
simple_stmt [2575,2730]
===
match
---
fstring_end: ' [45962,45963]
fstring_end: ' [45101,45102]
===
match
---
trailer [28653,28663]
trailer [28600,28610]
===
match
---
name: ti [49428,49430]
name: ti [48567,48569]
===
match
---
name: Tuple [7903,7908]
name: Tuple [7850,7855]
===
match
---
atom_expr [43309,43380]
atom_expr [42448,42519]
===
match
---
decorated [46329,50466]
decorated [45468,49605]
===
match
---
operator: = [38543,38544]
operator: = [37725,37726]
===
match
---
name: existing_dagruns_filter [36458,36481]
name: existing_dagruns_filter [35683,35706]
===
match
---
name: pools [45894,45899]
name: pools [45033,45038]
===
match
---
simple_stmt [20233,20302]
simple_stmt [20180,20249]
===
match
---
trailer [14237,14455]
trailer [14184,14402]
===
match
---
except_clause [25689,25705]
except_clause [25636,25652]
===
match
---
name: len [12845,12848]
name: len [12792,12795]
===
match
---
operator: , [8464,8465]
operator: , [8411,8412]
===
match
---
simple_stmt [29301,29360]
simple_stmt [29248,29307]
===
match
---
expr_stmt [48968,49121]
expr_stmt [48107,48260]
===
match
---
name: self [43309,43313]
name: self [42448,42452]
===
match
---
decorator [20495,20512]
decorator [20442,20459]
===
match
---
trailer [10360,10369]
trailer [10307,10316]
===
match
---
argument [34199,34208]
argument [33424,33433]
===
match
---
name: dag_models [36331,36341]
name: dag_models [35556,35566]
===
match
---
atom_expr [5984,6000]
atom_expr [5931,5947]
===
match
---
operator: = [5101,5102]
operator: = [5048,5049]
===
match
---
arglist [27242,27366]
arglist [27189,27313]
===
match
---
decorated [46192,46324]
decorated [45331,45463]
===
match
---
trailer [7541,7590]
trailer [7488,7537]
===
match
---
operator: = [28681,28682]
operator: = [28628,28629]
===
match
---
operator: , [41193,41194]
operator: , [40332,40333]
===
match
---
suite [15601,16158]
suite [15548,16105]
===
match
---
name: State [31967,31972]
name: State [31914,31919]
===
match
---
param [8994,9007]
param [8941,8954]
===
match
---
trailer [34465,34500]
trailer [33690,33725]
===
match
---
atom_expr [7530,7590]
atom_expr [7477,7537]
===
match
---
name: info [6887,6891]
name: info [6834,6838]
===
match
---
name: retries [2167,2174]
name: retries [2114,2121]
===
match
---
name: num_unhandled [13656,13669]
name: num_unhandled [13603,13616]
===
match
---
name: self [12877,12881]
name: self [12824,12828]
===
match
---
name: int [20810,20813]
name: int [20757,20760]
===
match
---
arglist [49698,49776]
arglist [48837,48915]
===
match
---
name: guard [34945,34950]
name: guard [34170,34175]
===
match
---
trailer [17134,17140]
trailer [17081,17087]
===
match
---
funcdef [6907,7769]
funcdef [6854,7716]
===
match
---
string: 'scheduler.orphaned_tasks.adopted' [49698,49732]
string: 'scheduler.orphaned_tasks.adopted' [48837,48871]
===
match
---
argument [37377,37392]
argument [36581,36596]
===
match
---
name: QUEUED [46060,46066]
name: QUEUED [45199,45205]
===
match
---
name: utcnow [17905,17911]
name: utcnow [17852,17858]
===
match
---
name: get_latest_version_hash [44181,44204]
name: get_latest_version_hash [43320,43343]
===
match
---
suite [39962,40585]
suite [39144,39767]
===
match
---
name: orm [1222,1225]
name: orm [1222,1225]
===
match
---
name: task_id [15359,15366]
name: task_id [15306,15313]
===
match
---
trailer [26197,26220]
trailer [26144,26167]
===
match
---
name: reset_tis_message [49236,49253]
name: reset_tis_message [48375,48392]
===
match
---
atom_expr [41007,41026]
atom_expr [40146,40165]
===
match
---
name: signal [5840,5846]
name: signal [5787,5793]
===
match
---
string: "-" [6804,6807]
string: "-" [6751,6754]
===
match
---
operator: - [40479,40480]
operator: - [39661,39662]
===
match
---
operator: -> [30031,30033]
operator: -> [29978,29980]
===
match
---
trailer [36869,36876]
trailer [36094,36101]
===
match
---
name: _schedule_dag_run [41418,41435]
name: _schedule_dag_run [40557,40574]
===
match
---
operator: { [20817,20818]
operator: { [20764,20765]
===
match
---
operator: , [21456,21457]
operator: , [21403,21404]
===
match
---
name: attempt [47031,47038]
name: attempt [46170,46177]
===
match
---
string: "Execution date is in future: %s" [43220,43253]
string: "Execution date is in future: %s" [42359,42392]
===
match
---
trailer [32861,32889]
trailer [32262,32290]
===
match
---
name: DagRunType [38438,38448]
name: DagRunType [37620,37630]
===
match
---
atom_expr [4622,4636]
atom_expr [4569,4583]
===
match
---
name: self [25867,25871]
name: self [25814,25818]
===
match
---
simple_stmt [5136,5163]
simple_stmt [5083,5110]
===
match
---
name: slot_stats [46144,46154]
name: slot_stats [45283,45293]
===
match
---
name: task_instance [17010,17023]
name: task_instance [16957,16970]
===
match
---
atom_expr [29390,29403]
atom_expr [29337,29350]
===
match
---
name: sqlalchemy [1052,1062]
name: sqlalchemy [1052,1062]
===
match
---
simple_stmt [28093,28169]
simple_stmt [28040,28116]
===
match
---
arglist [29316,29357]
arglist [29263,29304]
===
match
---
name: callback [44999,45007]
name: callback [44138,44146]
===
match
---
trailer [27763,27772]
trailer [27710,27719]
===
match
---
name: task_instance [13347,13360]
name: task_instance [13294,13307]
===
match
---
string: 'scheduler.critical_section_busy' [34466,34499]
string: 'scheduler.critical_section_busy' [33691,33724]
===
match
---
name: msg [23546,23549]
name: msg [23493,23496]
===
match
---
operator: , [1074,1075]
operator: , [1074,1075]
===
match
---
trailer [27593,27720]
trailer [27540,27667]
===
match
---
operator: = [9589,9590]
operator: = [9536,9537]
===
match
---
name: executor [24891,24899]
name: executor [24838,24846]
===
match
---
if_stmt [29373,29655]
if_stmt [29320,29602]
===
match
---
name: make_transient [1250,1264]
name: make_transient [1250,1264]
===
match
---
name: dag_id [14003,14009]
name: dag_id [13950,13956]
===
match
---
atom_expr [38314,38324]
atom_expr [37496,37506]
===
match
---
trailer [7849,7868]
trailer [7796,7815]
===
match
---
operator: , [33319,33320]
operator: , [32544,32545]
===
match
---
name: log [6285,6288]
name: log [6232,6235]
===
match
---
subscriptlist [7950,7958]
subscriptlist [7897,7905]
===
match
---
name: dagbag [40678,40684]
name: dagbag [39839,39845]
===
match
---
operator: , [6802,6803]
operator: , [6749,6750]
===
match
---
trailer [39670,39676]
trailer [38852,38858]
===
match
---
name: provide_session [20496,20511]
name: provide_session [20443,20458]
===
match
---
operator: = [5151,5152]
operator: = [5098,5099]
===
match
---
name: self [24921,24925]
name: self [24868,24872]
===
match
---
argument [38480,38516]
argument [37662,37698]
===
match
---
import_from [1342,1406]
import_from [1342,1406]
===
match
---
trailer [7908,7966]
trailer [7855,7913]
===
match
---
simple_stmt [13293,13316]
simple_stmt [13240,13263]
===
match
---
name: SKIPPED [42498,42505]
name: SKIPPED [41637,41644]
===
match
---
trailer [42599,42604]
trailer [41738,41743]
===
match
---
atom_expr [27068,27084]
atom_expr [27015,27031]
===
match
---
trailer [5967,6001]
trailer [5914,5948]
===
match
---
atom [47267,47633]
atom [46406,46772]
===
match
---
operator: , [42837,42838]
operator: , [41976,41977]
===
match
---
atom_expr [31694,31718]
atom_expr [31641,31665]
===
match
---
operator: , [20372,20373]
operator: , [20319,20320]
===
match
---
name: executable_tis [9362,9376]
name: executable_tis [9309,9323]
===
match
---
trailer [49119,49121]
trailer [48258,48260]
===
match
---
atom_expr [28649,28687]
atom_expr [28596,28634]
===
match
---
trailer [27188,27190]
trailer [27135,27137]
===
match
---
trailer [12890,13123]
trailer [12837,13070]
===
match
---
name: _verify_integrity_if_dag_changed [43972,44004]
name: _verify_integrity_if_dag_changed [43111,43143]
===
match
---
trailer [17426,17431]
trailer [17373,17378]
===
match
---
name: send [34199,34203]
name: send [33424,33428]
===
match
---
trailer [32800,32818]
trailer [32205,32223]
===
match
---
trailer [41774,41807]
trailer [40913,40946]
===
match
---
name: List [20906,20910]
name: List [20853,20857]
===
match
---
atom_expr [28189,28231]
atom_expr [28136,28178]
===
match
---
simple_stmt [27565,27721]
simple_stmt [27512,27668]
===
match
---
if_stmt [21542,21651]
if_stmt [21489,21598]
===
match
---
except_clause [23069,23085]
except_clause [23016,23032]
===
match
---
operator: = [6960,6961]
operator: = [6907,6908]
===
match
---
name: EventScheduler [2133,2147]
name: EventScheduler [2080,2094]
===
match
---
trailer [50919,50926]
trailer [50058,50065]
===
match
---
operator: , [22863,22864]
operator: , [22810,22811]
===
match
---
name: log [5246,5249]
name: log [5193,5196]
===
match
---
name: self [29713,29717]
name: self [29660,29664]
===
match
---
name: executor [33517,33525]
name: executor [32742,32750]
===
match
---
trailer [18839,18853]
trailer [18786,18800]
===
match
---
operator: , [16089,16090]
operator: , [16036,16037]
===
match
---
funcdef [5732,6002]
funcdef [5679,5949]
===
match
---
trailer [46833,46850]
trailer [45972,45989]
===
match
---
trailer [10327,10335]
trailer [10274,10282]
===
match
---
name: dag_runs [39635,39643]
name: dag_runs [38817,38825]
===
match
---
operator: = [38643,38644]
operator: = [37825,37826]
===
match
---
atom_expr [23431,23451]
atom_expr [23378,23398]
===
match
---
name: dag_run [40849,40856]
name: dag_run [39988,39995]
===
match
---
operator: , [39382,39383]
operator: , [38564,38565]
===
match
---
if_stmt [43110,43300]
if_stmt [42249,42439]
===
match
---
trailer [47707,47765]
trailer [46846,46904]
===
match
---
dictorsetmaker [4188,4226]
dictorsetmaker [4135,4173]
===
match
---
name: processor_agent [29675,29690]
name: processor_agent [29622,29637]
===
match
---
trailer [43015,43048]
trailer [42154,42187]
===
match
---
operator: , [1091,1092]
operator: , [1091,1092]
===
match
---
operator: , [6481,6482]
operator: , [6428,6429]
===
match
---
name: defaultdict [39348,39359]
name: defaultdict [38530,38541]
===
match
---
simple_stmt [41044,41290]
simple_stmt [40183,40429]
===
match
---
atom_expr [23766,23774]
atom_expr [23713,23721]
===
match
---
name: incr [49611,49615]
name: incr [48750,48754]
===
match
---
comparison [7620,7647]
comparison [7567,7594]
===
match
---
name: Stats [45921,45926]
name: Stats [45060,45065]
===
match
---
simple_stmt [2417,2487]
simple_stmt [2364,2434]
===
match
---
trailer [22974,22981]
trailer [22921,22928]
===
match
---
expr_stmt [18689,18705]
expr_stmt [18636,18652]
===
match
---
param [18150,18155]
param [18097,18102]
===
match
---
name: open_slots [16507,16517]
name: open_slots [16454,16464]
===
match
---
param [19028,19033]
param [18975,18980]
===
match
---
name: max_active_tasks_per_dag_limit [14406,14436]
name: max_active_tasks_per_dag_limit [14353,14383]
===
match
---
operator: , [45448,45449]
operator: , [44587,44588]
===
match
---
name: models [9591,9597]
name: models [9538,9544]
===
match
---
trailer [42658,42665]
trailer [41797,41804]
===
match
---
for_stmt [21984,23800]
for_stmt [21931,23747]
===
match
---
operator: = [10693,10694]
operator: = [10640,10641]
===
match
---
trailer [25880,25884]
trailer [25827,25831]
===
match
---
operator: > [43136,43137]
operator: > [42275,42276]
===
match
---
trailer [45380,45386]
trailer [44519,44525]
===
match
---
trailer [39921,39923]
trailer [39103,39105]
===
match
---
name: slots_available [33526,33541]
name: slots_available [32751,32766]
===
match
---
expr_stmt [5299,5359]
expr_stmt [5246,5306]
===
match
---
trailer [17661,17667]
trailer [17608,17614]
===
match
---
name: pool [12743,12747]
name: pool [12690,12694]
===
match
---
name: callback_to_run [32760,32775]
name: callback_to_run [32165,32180]
===
match
---
atom_expr [34188,34209]
atom_expr [33413,33434]
===
match
---
trailer [34198,34209]
trailer [33423,33434]
===
match
---
name: dag_model [38326,38335]
name: dag_model [37508,37517]
===
match
---
trailer [6414,6418]
trailer [6361,6365]
===
match
---
simple_stmt [1047,1100]
simple_stmt [1047,1100]
===
match
---
for_stmt [20969,21651]
for_stmt [20916,21598]
===
match
---
name: skip_locked [2389,2400]
name: skip_locked [2336,2347]
===
match
---
name: Session [50534,50541]
name: Session [49673,49680]
===
match
---
tfpdef [39813,39828]
tfpdef [38995,39010]
===
match
---
atom_expr [43138,43155]
atom_expr [42277,42294]
===
match
---
name: num_times_parse_dags [24152,24172]
name: num_times_parse_dags [24099,24119]
===
match
---
name: self [33512,33516]
name: self [32737,32741]
===
match
---
name: info [22152,22156]
name: info [22099,22103]
===
match
---
name: bind [35844,35848]
name: bind [35069,35073]
===
match
---
string: 'trigger_timeout_check_interval' [27455,27487]
string: 'trigger_timeout_check_interval' [27402,27434]
===
match
---
decorator [7774,7791]
decorator [7721,7738]
===
match
---
name: len [13672,13675]
name: len [13619,13622]
===
match
---
trailer [45827,45839]
trailer [44966,44978]
===
match
---
name: self [6843,6847]
name: self [6790,6794]
===
match
---
name: max_tis_per_query [20131,20148]
name: max_tis_per_query [20078,20095]
===
match
---
name: do_pickle [5141,5150]
name: do_pickle [5088,5097]
===
match
---
expr_stmt [4723,4747]
expr_stmt [4670,4694]
===
match
---
name: DagRun [36038,36044]
name: DagRun [35263,35269]
===
match
---
name: callback_tuples [32144,32159]
name: callback_tuples [32091,32106]
===
match
---
simple_stmt [24456,24521]
simple_stmt [24403,24468]
===
match
---
name: is_paused [10490,10499]
name: is_paused [10437,10446]
===
match
---
atom_expr [18050,18068]
atom_expr [17997,18015]
===
match
---
name: defaultdict [931,942]
name: defaultdict [931,942]
===
match
---
trailer [37456,37460]
trailer [36642,36646]
===
match
---
param [9008,9031]
param [8955,8978]
===
match
---
atom [22621,22807]
atom [22568,22754]
===
match
---
string: "error" [51199,51206]
string: "error" [50338,50345]
===
match
---
arglist [43049,43077]
arglist [42188,42216]
===
match
---
operator: = [20928,20929]
operator: = [20875,20876]
===
match
---
trailer [28812,28816]
trailer [28759,28763]
===
match
---
atom [16987,17032]
atom [16934,16979]
===
match
---
name: dag_run [43863,43870]
name: dag_run [43002,43009]
===
match
---
atom_expr [24866,24873]
atom_expr [24813,24820]
===
match
---
atom_expr [28370,28395]
atom_expr [28317,28342]
===
match
---
name: timer [33749,33754]
name: timer [32974,32979]
===
match
---
operator: = [44503,44504]
operator: = [43642,43643]
===
match
---
operator: , [38903,38904]
operator: , [38085,38086]
===
match
---
simple_stmt [15236,15298]
simple_stmt [15183,15245]
===
match
---
trailer [47586,47611]
trailer [46725,46750]
===
match
---
string: 'scheduler.tasks.running' [17215,17240]
string: 'scheduler.tasks.running' [17162,17187]
===
match
---
name: session [50314,50321]
name: session [49453,49460]
===
match
---
name: ValueError [20681,20691]
name: ValueError [20628,20638]
===
match
---
simple_stmt [22145,22188]
simple_stmt [22092,22135]
===
match
---
atom_expr [50888,50905]
atom_expr [50027,50044]
===
match
---
name: processor_agent [44823,44838]
name: processor_agent [43962,43977]
===
match
---
number: 1 [38847,38848]
number: 1 [38029,38030]
===
match
---
trailer [8515,8523]
trailer [8462,8470]
===
match
---
name: expected_start_date [40366,40385]
name: expected_start_date [39548,39567]
===
match
---
arglist [37359,37392]
arglist [36563,36596]
===
match
---
atom_expr [40659,40670]
atom_expr [39820,39831]
===
match
---
arglist [43884,43908]
arglist [43023,43047]
===
match
---
trailer [48629,48638]
trailer [47768,47777]
===
match
---
operator: = [27006,27007]
operator: = [26953,26954]
===
match
---
name: skip_locked [11042,11053]
name: skip_locked [10989,11000]
===
match
---
name: getint [4407,4413]
name: getint [4354,4360]
===
match
---
name: priority [18925,18933]
name: priority [18872,18880]
===
match
---
atom_expr [24552,24816]
atom_expr [24499,24763]
===
match
---
name: expunge_all [28424,28435]
name: expunge_all [28371,28382]
===
match
---
suite [30038,34653]
suite [29985,33878]
===
match
---
name: latest_heartbeat [47460,47476]
name: latest_heartbeat [46599,46615]
===
match
---
operator: = [49391,49392]
operator: = [48530,48531]
===
match
---
name: callback_to_execute [42680,42699]
name: callback_to_execute [41819,41838]
===
match
---
name: dag_id [17002,17008]
name: dag_id [16949,16955]
===
match
---
trailer [46733,46740]
trailer [45872,45879]
===
match
---
name: TI [10522,10524]
name: TI [10469,10471]
===
match
---
expr_stmt [23362,23606]
expr_stmt [23309,23553]
===
match
---
trailer [48446,48519]
trailer [47585,47658]
===
match
---
expr_stmt [31922,31990]
expr_stmt [31869,31937]
===
match
---
trailer [27690,27709]
trailer [27637,27656]
===
match
---
trailer [22378,22424]
trailer [22325,22371]
===
match
---
string: """Sends SLA Callbacks to DagFileProcessor if tasks have SLAs set and check_slas=True""" [45144,45232]
string: """Sends SLA Callbacks to DagFileProcessor if tasks have SLAs set and check_slas=True""" [44283,44371]
===
match
---
operator: , [23451,23452]
operator: , [23398,23399]
===
match
---
name: guard [33079,33084]
name: guard [32304,32309]
===
match
---
operator: , [1022,1023]
operator: , [1022,1023]
===
match
---
trailer [33835,33837]
trailer [33060,33062]
===
match
---
simple_stmt [29649,29655]
simple_stmt [29596,29602]
===
match
---
and_test [41957,42086]
and_test [41096,41225]
===
match
---
trailer [40684,40692]
trailer [39845,39853]
===
match
---
name: executable_tis [9991,10005]
name: executable_tis [9938,9952]
===
match
---
name: pool_slots [16192,16202]
name: pool_slots [16139,16149]
===
match
---
name: error [43214,43219]
name: error [42353,42358]
===
match
---
operator: , [44546,44547]
operator: , [43685,43686]
===
match
---
simple_stmt [23362,23607]
simple_stmt [23309,23554]
===
match
---
suite [31728,34653]
suite [31675,33878]
===
match
---
suite [6706,6742]
suite [6653,6689]
===
match
---
atom_expr [36861,36899]
atom_expr [36086,36124]
===
match
---
atom_expr [36867,36876]
atom_expr [36092,36101]
===
match
---
param [39126,39143]
param [38308,38325]
===
match
---
name: self [22824,22828]
name: self [22771,22775]
===
match
---
for_stmt [46799,50436]
for_stmt [45938,49575]
===
match
---
argument [34016,34031]
argument [33241,33256]
===
match
---
operator: , [39811,39812]
operator: , [38993,38994]
===
match
---
name: update_state [43512,43524]
name: update_state [42651,42663]
===
match
---
name: open_slots [13071,13081]
name: open_slots [13018,13028]
===
match
---
name: call_regular_interval [27393,27414]
name: call_regular_interval [27340,27361]
===
match
---
operator: , [29581,29582]
operator: , [29528,29529]
===
match
---
name: serialized_dag [15236,15250]
name: serialized_dag [15183,15197]
===
match
---
name: dag_id [36870,36876]
name: dag_id [36095,36101]
===
match
---
name: callback_requests [2026,2043]
name: callback_requests [1973,1990]
===
match
---
name: self [20177,20181]
name: self [20124,20128]
===
match
---
operator: , [2288,2289]
operator: , [2235,2236]
===
match
---
atom_expr [21411,21425]
atom_expr [21358,21372]
===
match
---
simple_stmt [45921,45985]
simple_stmt [45060,45124]
===
match
---
name: start_date [41965,41975]
name: start_date [41104,41114]
===
match
---
funcdef [35308,38920]
funcdef [34533,38102]
===
match
---
arglist [38900,38918]
arglist [38082,38100]
===
match
---
operator: = [45669,45670]
operator: = [44808,44809]
===
match
---
simple_stmt [48968,49122]
simple_stmt [48107,48261]
===
match
---
name: join [17372,17376]
name: join [17319,17323]
===
match
---
name: orm [1160,1163]
name: orm [1160,1163]
===
match
---
argument [44659,44674]
argument [43798,43813]
===
match
---
name: conf [1337,1341]
name: conf [1337,1341]
===
match
---
atom_expr [10747,10760]
atom_expr [10694,10707]
===
match
---
trailer [17063,17119]
trailer [17010,17066]
===
match
---
name: session [37377,37384]
name: session [36581,36588]
===
match
---
atom_expr [33970,34032]
atom_expr [33195,33257]
===
match
---
name: self [24601,24605]
name: self [24548,24552]
===
match
---
suite [13442,13868]
suite [13389,13815]
===
match
---
trailer [5960,5967]
trailer [5907,5914]
===
match
---
term [6824,6832]
term [6771,6779]
===
match
---
name: self [28544,28548]
name: self [28491,28495]
===
match
---
name: task_instance [16178,16191]
name: task_instance [16125,16138]
===
match
---
trailer [50455,50465]
trailer [49594,49604]
===
match
---
name: session [17654,17661]
name: session [17601,17608]
===
match
---
trailer [42207,42213]
trailer [41346,41352]
===
match
---
atom_expr [41775,41789]
atom_expr [40914,40928]
===
match
---
name: dag [45670,45673]
name: dag [44809,44812]
===
match
---
name: conf [4249,4253]
name: conf [4196,4200]
===
match
---
param [4668,4677]
param [4615,4624]
===
match
---
trailer [28374,28383]
trailer [28321,28330]
===
match
---
string: "Calling SchedulerJob.adopt_or_reset_orphaned_tasks method" [47152,47211]
string: "Calling SchedulerJob.adopt_or_reset_orphaned_tasks method" [46291,46350]
===
match
---
name: callback_to_run [43926,43941]
name: callback_to_run [43065,43080]
===
match
---
for_stmt [40594,41409]
for_stmt [39776,40548]
===
match
---
operator: , [11610,11611]
operator: , [11557,11558]
===
match
---
name: callback_to_execute [43058,43077]
name: callback_to_execute [42197,42216]
===
match
---
name: primary [21202,21209]
name: primary [21149,21156]
===
match
---
trailer [25146,25156]
trailer [25093,25103]
===
match
---
name: processor_timeout_seconds [24494,24519]
name: processor_timeout_seconds [24441,24466]
===
match
---
trailer [6293,6348]
trailer [6240,6295]
===
match
---
trailer [37587,37594]
trailer [36769,36776]
===
match
---
name: timezone [17896,17904]
name: timezone [17843,17851]
===
match
---
string: """     Returns True if the current process is the parent process. False if the current process is a child     process started by multiprocessing.     """ [2628,2782]
string: """     Returns True if the current process is the parent process. False if the current process is a child     process started by multiprocessing.     """ [2575,2729]
===
match
---
trailer [8614,8624]
trailer [8561,8571]
===
match
---
name: state [48033,48038]
name: state [47172,47177]
===
match
---
name: self [49153,49157]
name: self [48292,48296]
===
match
---
return_stmt [2787,2849]
return_stmt [2734,2796]
===
match
---
name: State [21555,21560]
name: State [21502,21507]
===
match
---
trailer [42347,42379]
trailer [41486,41518]
===
match
---
arglist [45387,45453]
arglist [44526,44592]
===
match
---
operator: != [48639,48641]
operator: != [47778,47780]
===
match
---
simple_stmt [40881,40890]
simple_stmt [40020,40029]
===
match
---
operator: , [27632,27633]
operator: , [27579,27580]
===
match
---
trailer [45932,45984]
trailer [45071,45123]
===
match
---
simple_stmt [42522,42551]
simple_stmt [41661,41690]
===
match
---
atom_expr [46043,46067]
atom_expr [45182,45206]
===
match
---
trailer [21832,21847]
trailer [21779,21794]
===
match
---
atom_expr [50771,51309]
atom_expr [49910,50448]
===
match
---
return_stmt [33723,33731]
return_stmt [32948,32956]
===
match
---
operator: = [5719,5720]
operator: = [5666,5667]
===
match
---
arglist [22379,22423]
arglist [22326,22370]
===
match
---
name: dag [44499,44502]
name: dag [43638,43641]
===
match
---
name: info [6760,6764]
name: info [6707,6711]
===
match
---
atom_expr [7932,7965]
atom_expr [7879,7912]
===
match
---
atom_expr [21380,21393]
atom_expr [21327,21340]
===
match
---
if_stmt [9897,10006]
if_stmt [9844,9953]
===
match
---
name: Dict [1018,1022]
name: Dict [1018,1022]
===
match
---
atom_expr [22098,22132]
atom_expr [22045,22079]
===
match
---
param [6483,6488]
param [6430,6435]
===
match
---
operator: = [23370,23371]
operator: = [23317,23318]
===
match
---
simple_stmt [10224,10671]
simple_stmt [10171,10618]
===
match
---
argument [24486,24519]
argument [24433,24466]
===
match
---
name: self [20843,20847]
name: self [20790,20794]
===
match
---
name: session [2259,2266]
name: session [2206,2213]
===
match
---
arglist [29460,29614]
arglist [29407,29561]
===
match
---
trailer [41048,41052]
trailer [40187,40191]
===
match
---
simple_stmt [34268,34291]
simple_stmt [33493,33516]
===
match
---
trailer [10825,10859]
trailer [10772,10806]
===
match
---
parameters [23851,23857]
parameters [23798,23804]
===
match
---
except_clause [26065,26081]
except_clause [26012,26028]
===
match
---
name: str [20785,20788]
name: str [20732,20735]
===
match
---
simple_stmt [5567,5628]
simple_stmt [5514,5575]
===
match
---
param [26250,26254]
param [26197,26201]
===
match
---
argument [49063,49093]
argument [48202,48232]
===
match
---
operator: * [6808,6809]
operator: * [6755,6756]
===
match
---
name: State [36934,36939]
name: State [36159,36164]
===
match
---
with_stmt [28249,28527]
with_stmt [28196,28474]
===
match
---
name: ValueError [26933,26943]
name: ValueError [26880,26890]
===
match
---
operator: == [9916,9918]
operator: == [9863,9865]
===
match
---
operator: = [18695,18696]
operator: = [18642,18643]
===
match
---
name: current_max_active_tasks_per_dag [14352,14384]
name: current_max_active_tasks_per_dag [14299,14331]
===
match
---
trailer [16825,16840]
trailer [16772,16787]
===
match
---
name: executable_tis [17626,17640]
name: executable_tis [17573,17587]
===
match
---
name: append [32855,32861]
name: append [32256,32262]
===
match
---
name: session [36399,36406]
name: session [35624,35631]
===
match
---
exprlist [12531,12551]
exprlist [12478,12498]
===
match
---
name: Optional [14972,14980]
name: Optional [14919,14927]
===
match
---
parameters [18149,18181]
parameters [18096,18128]
===
match
---
testlist_comp [23557,23582]
testlist_comp [23504,23529]
===
match
---
trailer [8442,8482]
trailer [8389,8429]
===
match
---
operator: , [8400,8401]
operator: , [8347,8348]
===
match
---
name: DagRun [39410,39416]
name: DagRun [38592,38598]
===
match
---
trailer [4364,4376]
trailer [4311,4323]
===
match
---
simple_stmt [21047,21064]
simple_stmt [20994,21011]
===
match
---
atom_expr [15883,16120]
atom_expr [15830,16067]
===
match
---
name: TI [47994,47996]
name: TI [47133,47135]
===
match
---
operator: , [48724,48725]
operator: , [47863,47864]
===
match
---
simple_stmt [20400,20459]
simple_stmt [20347,20406]
===
match
---
arglist [35986,36078]
arglist [35211,35303]
===
match
---
name: dag_id [21387,21393]
name: dag_id [21334,21340]
===
match
---
param [18156,18180]
param [18103,18127]
===
match
---
operator: = [38494,38495]
operator: = [37676,37677]
===
match
---
trailer [33768,33807]
trailer [32993,33032]
===
match
---
name: dag_model [37205,37214]
name: dag_model [36430,36439]
===
match
---
simple_stmt [31847,31883]
simple_stmt [31794,31830]
===
match
---
name: self [18150,18154]
name: self [18097,18101]
===
match
---
name: session [31982,31989]
name: session [31929,31936]
===
match
---
subscriptlist [20780,20807]
subscriptlist [20727,20754]
===
match
---
name: fileloc [42756,42763]
name: fileloc [41895,41902]
===
match
---
suite [6057,6448]
suite [6004,6395]
===
match
---
name: kwargs [4670,4676]
name: kwargs [4617,4623]
===
match
---
name: self [24635,24639]
name: self [24582,24586]
===
match
---
trailer [24962,24978]
trailer [24909,24925]
===
match
---
name: info [14572,14576]
name: info [14519,14523]
===
match
---
name: airflow [1534,1541]
name: airflow [1481,1488]
===
match
---
name: collections [912,923]
name: collections [912,923]
===
match
---
name: or_ [48447,48450]
name: or_ [47586,47589]
===
match
---
expr_stmt [11978,12025]
expr_stmt [11925,11972]
===
match
---
atom_expr [17129,17194]
atom_expr [17076,17141]
===
match
---
name: order_by [10612,10620]
name: order_by [10559,10567]
===
match
---
name: dag_id [42781,42787]
name: dag_id [41920,41926]
===
match
---
operator: , [2069,2070]
operator: , [2016,2017]
===
match
---
suite [18037,18069]
suite [17984,18016]
===
match
---
trailer [23433,23443]
trailer [23380,23390]
===
match
---
trailer [47602,47609]
trailer [46741,46748]
===
match
---
fstring [46009,46041]
fstring [45148,45180]
===
match
---
name: task_instance [16418,16431]
name: task_instance [16365,16378]
===
match
---
operator: } [20818,20819]
operator: } [20765,20766]
===
match
---
name: error [34339,34344]
name: error [33564,33569]
===
match
---
name: dag_model [37042,37051]
name: dag_model [36267,36276]
===
match
---
name: UNPICKLEABLE_EXECUTORS [24060,24082]
name: UNPICKLEABLE_EXECUTORS [24007,24029]
===
match
---
string: """Respond to executor events.""" [20592,20625]
string: """Respond to executor events.""" [20539,20572]
===
match
---
name: conf [27008,27012]
name: conf [26955,26959]
===
match
---
name: conf [24398,24402]
name: conf [24345,24349]
===
match
---
name: serialized_dag [15418,15432]
name: serialized_dag [15365,15379]
===
match
---
and_test [22466,22533]
and_test [22413,22480]
===
match
---
name: ti [23191,23193]
name: ti [23138,23140]
===
match
---
trailer [14980,14985]
trailer [14927,14932]
===
match
---
simple_stmt [36200,36357]
simple_stmt [35425,35582]
===
match
---
trailer [34193,34198]
trailer [33418,33423]
===
match
---
operator: -> [26256,26258]
operator: -> [26203,26205]
===
match
---
operator: += [16660,16662]
operator: += [16607,16609]
===
match
---
simple_stmt [23191,23211]
simple_stmt [23138,23158]
===
match
---
name: run_type [48630,48638]
name: run_type [47769,47777]
===
match
---
name: exception [25942,25951]
name: exception [25889,25898]
===
match
---
name: in_ [36271,36274]
name: in_ [35496,35499]
===
match
---
strings [15930,16042]
strings [15877,15989]
===
match
---
if_stmt [37235,37299]
if_stmt [36460,36524]
===
match
---
string: 'polymorphic_identity' [4188,4210]
string: 'polymorphic_identity' [4135,4157]
===
match
---
trailer [46008,46068]
trailer [45147,45207]
===
match
---
atom_expr [20177,20206]
atom_expr [20124,20153]
===
match
---
argument [13210,13265]
argument [13157,13212]
===
match
---
operator: , [18786,18787]
operator: , [18733,18734]
===
match
---
name: self [24033,24037]
name: self [23980,23984]
===
match
---
name: dag [42068,42071]
name: dag [41207,41210]
===
match
---
name: get_dag [41767,41774]
name: get_dag [40906,40913]
===
match
---
expr_stmt [8771,8802]
expr_stmt [8718,8749]
===
match
---
atom [41943,42096]
atom [41082,41235]
===
match
---
trailer [13471,13476]
trailer [13418,13423]
===
match
---
trailer [20779,20808]
trailer [20726,20755]
===
match
---
trailer [51372,51377]
trailer [50511,50516]
===
match
---
expr_stmt [22615,22807]
expr_stmt [22562,22754]
===
match
---
simple_stmt [7976,8356]
simple_stmt [7923,8303]
===
match
---
simple_stmt [23875,23915]
simple_stmt [23822,23862]
===
match
---
simple_stmt [5426,5474]
simple_stmt [5373,5421]
===
match
---
funcdef [18104,18978]
funcdef [18051,18925]
===
match
---
simple_stmt [47694,47766]
simple_stmt [46833,46905]
===
match
---
name: state [36925,36930]
name: state [36150,36155]
===
match
---
atom_expr [41183,41193]
atom_expr [40322,40332]
===
match
---
arglist [4535,4573]
arglist [4482,4520]
===
match
---
simple_stmt [17418,17505]
simple_stmt [17365,17452]
===
match
---
operator: , [4332,4333]
operator: , [4279,4280]
===
match
---
name: queued_tis [20310,20320]
name: queued_tis [20257,20267]
===
match
---
name: callback_to_run [33222,33237]
name: callback_to_run [32447,32462]
===
match
---
trailer [29305,29311]
trailer [29252,29258]
===
match
---
name: provide_session [50472,50487]
name: provide_session [49611,49626]
===
match
---
operator: , [44376,44377]
operator: , [43515,43516]
===
match
---
name: dagbag [22975,22981]
name: dagbag [22922,22928]
===
match
---
trailer [11842,11862]
trailer [11789,11809]
===
match
---
suite [45008,45077]
suite [44147,44216]
===
match
---
operator: -> [20576,20578]
operator: -> [20523,20525]
===
match
---
atom_expr [35836,35861]
atom_expr [35061,35086]
===
match
---
name: dag_run [41248,41255]
name: dag_run [40387,40394]
===
match
---
fstring_start: f' [46009,46011]
fstring_start: f' [45148,45150]
===
match
---
trailer [50321,50327]
trailer [49460,49466]
===
match
---
string: """         Unconditionally create a DAG run for the given DAG, and update the dag_model's fields to control         if/when the next DAGRun should be created         """ [35404,35574]
string: """         Unconditionally create a DAG run for the given DAG, and update the dag_model's fields to control         if/when the next DAGRun should be created         """ [34629,34799]
===
match
---
suite [47669,47855]
suite [46808,46994]
===
match
---
name: next_event [29347,29357]
name: next_event [29294,29304]
===
match
---
name: queued_dttm [17883,17894]
name: queued_dttm [17830,17841]
===
match
---
name: Stats [49605,49610]
name: Stats [48744,48749]
===
match
---
trailer [20130,20148]
trailer [20077,20095]
===
match
---
arglist [24587,24806]
arglist [24534,24753]
===
match
---
atom_expr [29670,29695]
atom_expr [29617,29642]
===
match
---
name: num_starving_tasks [13293,13311]
name: num_starving_tasks [13240,13258]
===
match
---
name: dag_run [43347,43354]
name: dag_run [42486,42493]
===
match
---
name: SerializedDagModel [1766,1784]
name: SerializedDagModel [1713,1731]
===
match
---
atom [7664,7707]
atom [7611,7654]
===
match
---
name: session [37385,37392]
name: session [36589,36596]
===
match
---
simple_stmt [20735,20820]
simple_stmt [20682,20767]
===
match
---
operator: = [41739,41740]
operator: = [40878,40879]
===
match
---
trailer [8860,8879]
trailer [8807,8826]
===
match
---
trailer [23391,23606]
trailer [23338,23553]
===
match
---
name: func [39425,39429]
name: func [38607,38611]
===
match
---
if_stmt [51328,51453]
if_stmt [50467,50592]
===
match
---
string: 'scheduler_health_check_threshold' [46754,46788]
string: 'scheduler_health_check_threshold' [45893,45927]
===
match
---
trailer [21911,21918]
trailer [21858,21865]
===
match
---
name: airflow [1347,1354]
name: airflow [1347,1354]
===
match
---
trailer [36617,37028]
trailer [35842,36253]
===
match
---
name: dag_id [42659,42665]
name: dag_id [41798,41804]
===
match
---
name: command_as_list [18525,18540]
name: command_as_list [18472,18487]
===
match
---
name: Pool [11725,11729]
name: Pool [11672,11676]
===
match
---
string: """Helper method to clean up processor_agent to avoid leaving orphan processes.""" [6066,6148]
string: """Helper method to clean up processor_agent to avoid leaving orphan processes.""" [6013,6095]
===
match
---
name: self [47137,47141]
name: self [46276,46280]
===
match
---
name: timer [34268,34273]
name: timer [33493,33498]
===
match
---
name: self [18718,18722]
name: self [18665,18669]
===
match
---
comp_op [38349,38355]
comp_op [37531,37537]
===
match
---
name: query [47946,47951]
name: query [47085,47090]
===
match
---
arglist [47801,47853]
arglist [46940,46992]
===
match
---
atom [36293,36320]
atom [35518,35545]
===
match
---
trailer [28881,28885]
trailer [28828,28832]
===
match
---
param [50519,50524]
param [49658,49663]
===
match
---
name: debug [11345,11350]
name: debug [11292,11297]
===
match
---
operator: <= [33542,33544]
operator: <= [32767,32769]
===
match
---
name: Session [19043,19050]
name: Session [18990,18997]
===
match
---
name: bool [4595,4599]
name: bool [4542,4546]
===
match
---
name: dag_id [36420,36426]
name: dag_id [35645,35651]
===
match
---
if_stmt [15318,15542]
if_stmt [15265,15489]
===
match
---
trailer [37011,37015]
trailer [36236,36240]
===
match
---
name: current_index [13332,13345]
name: current_index [13279,13292]
===
match
---
simple_stmt [943,974]
simple_stmt [943,974]
===
match
---
simple_stmt [34585,34591]
simple_stmt [33810,33816]
===
match
---
expr_stmt [33749,33807]
expr_stmt [32974,33032]
===
match
---
name: task_instances_to_examine [11291,11316]
name: task_instances_to_examine [11238,11263]
===
match
---
name: Stats [45997,46002]
name: Stats [45136,45141]
===
match
---
name: SCHEDULED [38449,38458]
name: SCHEDULED [37631,37640]
===
match
---
simple_stmt [33723,33732]
simple_stmt [32948,32957]
===
match
---
name: num_starving_tasks_total [12371,12395]
name: num_starving_tasks_total [12318,12342]
===
match
---
trailer [25425,25430]
trailer [25372,25377]
===
match
---
name: signal [5968,5974]
name: signal [5915,5921]
===
match
---
operator: = [28784,28785]
operator: = [28731,28732]
===
match
---
name: info [23578,23582]
name: info [23525,23529]
===
match
---
trailer [24847,24856]
trailer [24794,24803]
===
match
---
name: DagRun [36248,36254]
name: DagRun [35473,35479]
===
match
---
expr_stmt [10907,11087]
expr_stmt [10854,11034]
===
match
---
operator: = [18563,18564]
operator: = [18510,18511]
===
match
---
import_from [2007,2090]
import_from [1954,2037]
===
match
---
name: state [39851,39856]
name: state [39033,39038]
===
match
---
trailer [39403,39409]
trailer [38585,38591]
===
match
---
atom_expr [24014,24028]
atom_expr [23961,23975]
===
match
---
name: FAILED [47603,47609]
name: FAILED [46742,46748]
===
match
---
name: Exception [6696,6705]
name: Exception [6643,6652]
===
match
---
name: executor [20848,20856]
name: executor [20795,20803]
===
match
---
atom_expr [8429,8569]
atom_expr [8376,8516]
===
match
---
trailer [11566,11570]
trailer [11513,11517]
===
match
---
simple_stmt [6264,6271]
simple_stmt [6211,6218]
===
match
---
trailer [40692,40725]
trailer [39853,39886]
===
match
---
arglist [5968,6000]
arglist [5915,5947]
===
match
---
expr_stmt [22145,22187]
expr_stmt [22092,22134]
===
match
---
operator: = [9833,9834]
operator: = [9780,9781]
===
match
---
string: """         Takes task_instances, which should have been set to queued, and enqueues them         with the executor.          :param task_instances: TaskInstances to enqueue         :type task_instances: list[TaskInstance]         """ [18199,18433]
string: """         Takes task_instances, which should have been set to queued, and enqueues them         with the executor.          :param task_instances: TaskInstances to enqueue         :type task_instances: list[TaskInstance]         """ [18146,18380]
===
match
---
trailer [27918,27920]
trailer [27865,27867]
===
match
---
number: 0 [43298,43299]
number: 0 [42437,42438]
===
match
---
trailer [42356,42360]
trailer [41495,41499]
===
match
---
name: full_filepath [45656,45669]
name: full_filepath [44795,44808]
===
match
---
trailer [49115,49119]
trailer [48254,48258]
===
match
---
param [19034,19050]
param [18981,18997]
===
match
---
simple_stmt [7599,7769]
simple_stmt [7546,7716]
===
match
---
operator: = [11061,11062]
operator: = [11008,11009]
===
match
---
atom_expr [40673,40725]
atom_expr [39834,39886]
===
match
---
decorated [7774,8921]
decorated [7721,8868]
===
match
---
atom_expr [17010,17031]
atom_expr [16957,16978]
===
match
---
name: state [22145,22150]
name: state [22092,22097]
===
match
---
name: session [32810,32817]
name: session [32215,32222]
===
match
---
string: "Processor agent is not started." [45541,45574]
string: "Processor agent is not started." [44680,44713]
===
match
---
import_from [907,942]
import_from [907,942]
===
match
---
simple_stmt [41549,41727]
simple_stmt [40688,40866]
===
match
---
atom_expr [42635,42649]
atom_expr [41774,41788]
===
match
---
operator: , [44009,44010]
operator: , [43148,43149]
===
match
---
name: try_number [22494,22504]
name: try_number [22441,22451]
===
match
---
trailer [34338,34347]
trailer [33563,33572]
===
match
---
param [35369,35385]
param [34594,34610]
===
match
---
argument [42781,42798]
argument [41920,41937]
===
match
---
name: end [26047,26050]
name: end [25994,25997]
===
match
---
atom_expr [26933,26978]
atom_expr [26880,26925]
===
match
---
arglist [15273,15296]
arglist [15220,15243]
===
match
---
name: slot_stats [45880,45890]
name: slot_stats [45019,45029]
===
match
---
name: SchedulerJob [47447,47459]
name: SchedulerJob [46586,46598]
===
match
---
name: dag_id [42263,42269]
name: dag_id [41402,41408]
===
match
---
operator: , [17008,17009]
operator: , [16955,16956]
===
match
---
operator: , [4658,4659]
operator: , [4605,4606]
===
match
---
operator: , [1180,1181]
operator: , [1180,1181]
===
match
---
trailer [21219,21230]
trailer [21166,21177]
===
match
---
name: self [31788,31792]
name: self [31735,31739]
===
match
---
name: _exit_gracefully [6011,6027]
name: _exit_gracefully [5958,5974]
===
match
---
number: 0 [11321,11322]
number: 0 [11268,11269]
===
match
---
atom_expr [24529,24549]
atom_expr [24476,24496]
===
match
---
simple_stmt [44051,44137]
simple_stmt [43190,43276]
===
match
---
atom_expr [8559,8568]
atom_expr [8506,8515]
===
match
---
name: Stats [17203,17208]
name: Stats [17150,17155]
===
match
---
atom_expr [48504,48517]
atom_expr [47643,47656]
===
match
---
expr_stmt [15236,15297]
expr_stmt [15183,15244]
===
match
---
operator: , [17987,17988]
operator: , [17934,17935]
===
match
---
trailer [5853,5860]
trailer [5800,5807]
===
match
---
atom_expr [49428,49447]
atom_expr [48567,48586]
===
match
---
name: session [38679,38686]
name: session [37861,37868]
===
match
---
name: timer [33824,33829]
name: timer [33049,33054]
===
match
---
atom_expr [41381,41408]
atom_expr [40520,40547]
===
match
---
name: open_slots [13426,13436]
name: open_slots [13373,13383]
===
match
---
name: dag_id [41187,41193]
name: dag_id [40326,40332]
===
match
---
name: gauge [17209,17214]
name: gauge [17156,17161]
===
match
---
simple_stmt [24958,24987]
simple_stmt [24905,24934]
===
match
---
for_stmt [8723,8888]
for_stmt [8670,8835]
===
match
---
simple_stmt [39843,39873]
simple_stmt [39025,39055]
===
match
---
operator: = [28517,28518]
operator: = [28464,28465]
===
match
---
simple_stmt [43309,43381]
simple_stmt [42448,42520]
===
match
---
name: do_pickle [4584,4593]
name: do_pickle [4531,4540]
===
match
---
name: Collection [993,1003]
name: Collection [993,1003]
===
match
---
param [7837,7869]
param [7784,7816]
===
match
---
trailer [27392,27414]
trailer [27339,27361]
===
match
---
atom_expr [47980,48829]
atom_expr [47119,47968]
===
match
---
string: 'unit_test_mode' [27032,27048]
string: 'unit_test_mode' [26979,26995]
===
match
---
atom_expr [17516,17535]
atom_expr [17463,17482]
===
match
---
atom_expr [11820,11884]
atom_expr [11767,11831]
===
match
---
name: dag_id [45694,45700]
name: dag_id [44833,44839]
===
match
---
trailer [39293,39316]
trailer [38475,38498]
===
match
---
trailer [45839,45856]
trailer [44978,44995]
===
match
---
name: start [24900,24905]
name: start [24847,24852]
===
match
---
name: _critical_section_execute_task_instances [33975,34015]
name: _critical_section_execute_task_instances [33200,33240]
===
match
---
name: dm [36325,36327]
name: dm [35550,35552]
===
match
---
name: num_tasks_in_executor [12254,12275]
name: num_tasks_in_executor [12201,12222]
===
match
---
atom_expr [14167,14207]
atom_expr [14114,14154]
===
match
---
atom_expr [7430,7481]
atom_expr [7377,7428]
===
match
---
expr_stmt [13800,13841]
expr_stmt [13747,13788]
===
match
---
string: """Find Dag Models needing DagRuns and Create Dag Runs with retries in case of OperationalError""" [34970,35068]
string: """Find Dag Models needing DagRuns and Create Dag Runs with retries in case of OperationalError""" [34195,34293]
===
match
---
trailer [29438,29632]
trailer [29385,29579]
===
match
---
operator: = [44789,44790]
operator: = [43928,43929]
===
match
---
name: task_instances [12537,12551]
name: task_instances [12484,12498]
===
match
---
name: get_dag [44517,44524]
name: get_dag [43656,43663]
===
match
---
name: key [22060,22063]
name: key [22007,22010]
===
match
---
expr_stmt [6642,6680]
expr_stmt [6589,6627]
===
match
---
name: int [8407,8410]
name: int [8354,8357]
===
match
---
name: slots_available [20285,20300]
name: slots_available [20232,20247]
===
match
---
operator: , [23764,23765]
operator: , [23711,23712]
===
match
---
argument [45840,45855]
argument [44979,44994]
===
match
---
trailer [29315,29358]
trailer [29262,29305]
===
match
---
name: Collection [35347,35357]
name: Collection [34572,34582]
===
match
---
trailer [38317,38324]
trailer [37499,37506]
===
match
---
trailer [35163,35165]
trailer [34388,34390]
===
match
---
name: query [36407,36412]
name: query [35632,35637]
===
match
---
operator: , [38649,38650]
operator: , [37831,37832]
===
match
---
simple_stmt [42154,42394]
simple_stmt [41293,41533]
===
match
---
atom_expr [49348,49356]
atom_expr [48487,48495]
===
match
---
funcdef [44681,45077]
funcdef [43820,44216]
===
match
---
trailer [5487,5505]
trailer [5434,5452]
===
match
---
name: __get_concurrency_maps [12152,12174]
name: __get_concurrency_maps [12099,12121]
===
match
---
suite [33257,33338]
suite [32482,32563]
===
match
---
name: Optional [41511,41519]
name: Optional [40650,40658]
===
match
---
simple_stmt [45372,45455]
simple_stmt [44511,44594]
===
match
---
simple_stmt [41841,41910]
simple_stmt [40980,41049]
===
match
---
name: queued_runs_of_dags [38806,38825]
name: queued_runs_of_dags [37988,38007]
===
match
---
arglist [17215,17263]
arglist [17162,17210]
===
match
---
name: log [46846,46849]
name: log [45985,45988]
===
match
---
import_from [2148,2239]
import_from [2095,2186]
===
match
---
arglist [38429,38771]
arglist [37611,37953]
===
match
---
name: in_ [36857,36860]
name: in_ [36082,36085]
===
match
---
simple_stmt [9934,9972]
simple_stmt [9881,9919]
===
match
---
name: DagCallbackRequest [2051,2069]
name: DagCallbackRequest [1998,2016]
===
match
---
name: resettable_states [47876,47893]
name: resettable_states [47015,47032]
===
match
---
name: dag_id [39417,39423]
name: dag_id [38599,38605]
===
match
---
name: dag_id [40944,40950]
name: dag_id [40083,40089]
===
match
---
trailer [36274,36356]
trailer [35499,35581]
===
match
---
name: pools [9583,9588]
name: pools [9530,9535]
===
match
---
name: _exit_gracefully [5867,5883]
name: _exit_gracefully [5814,5830]
===
match
---
trailer [49655,49665]
trailer [48794,48804]
===
match
---
trailer [31907,31909]
trailer [31854,31856]
===
match
---
name: exception [40793,40802]
name: error [39936,39941]
===
match
---
arglist [36540,36573]
arglist [35765,35798]
===
match
---
simple_stmt [5833,5885]
simple_stmt [5780,5832]
===
match
---
name: incr [49693,49697]
name: incr [48832,48836]
===
match
---
trailer [39264,39293]
trailer [38446,38475]
===
match
---
name: callback_to_run [33321,33336]
name: callback_to_run [32546,32561]
===
match
---
expr_stmt [5071,5126]
expr_stmt [5018,5073]
===
match
---
trailer [10959,11081]
trailer [10906,11028]
===
match
---
simple_stmt [37634,37688]
simple_stmt [36816,36870]
===
match
---
name: rollback [50399,50407]
name: rollback [49538,49546]
===
match
---
simple_stmt [5299,5360]
simple_stmt [5246,5307]
===
match
---
operator: , [49044,49045]
operator: , [48183,48184]
===
match
---
name: state [48495,48500]
name: state [47634,47639]
===
match
---
name: dag_id [40857,40863]
name: dag_id [39996,40002]
===
match
---
operator: , [31823,31824]
operator: , [31770,31771]
===
match
---
string: 'scheduler.critical_section_duration' [33769,33806]
string: 'scheduler.critical_section_duration' [32994,33031]
===
match
---
string: "Executor reports task instance %s finished (%s) although the " [22643,22706]
string: "Executor reports task instance %s finished (%s) although the " [22590,22653]
===
match
---
name: executable_tis [18022,18036]
name: executable_tis [17969,17983]
===
match
---
name: self [43011,43015]
name: self [42150,42154]
===
match
---
trailer [27158,27188]
trailer [27105,27135]
===
match
---
name: max_tis_per_query [5488,5505]
name: max_tis_per_query [5435,5452]
===
match
---
return_stmt [21739,21763]
return_stmt [21686,21710]
===
match
---
name: state [21545,21550]
name: state [21492,21497]
===
match
---
trailer [10253,10259]
trailer [10200,10206]
===
match
---
name: dag_run [41741,41748]
name: dag_run [40880,40887]
===
match
---
name: log [4617,4620]
name: log [4564,4567]
===
match
---
trailer [7435,7437]
trailer [7382,7384]
===
match
---
name: append [21636,21642]
name: append [21583,21589]
===
match
---
atom [32162,32164]
atom [32109,32111]
===
match
---
name: self [40673,40677]
name: self [39834,39838]
===
match
---
param [4328,4333]
param [4275,4280]
===
match
---
atom_expr [46729,46789]
atom_expr [45868,45928]
===
match
---
name: session [31710,31717]
name: session [31657,31664]
===
match
---
trailer [22063,22071]
trailer [22010,22018]
===
match
---
name: with_row_locks [10945,10959]
name: with_row_locks [10892,10906]
===
match
---
name: num_failed [47658,47668]
name: num_failed [46797,46807]
===
match
---
name: EventScheduler [27068,27082]
name: EventScheduler [27015,27029]
===
match
---
simple_stmt [23627,23682]
simple_stmt [23574,23629]
===
match
---
atom_expr [44249,44265]
atom_expr [43388,43404]
===
match
---
operator: , [23162,23163]
operator: , [23109,23110]
===
match
---
simple_stmt [13862,13868]
simple_stmt [13809,13815]
===
match
---
name: Session [20560,20567]
name: Session [20507,20514]
===
match
---
trailer [49766,49776]
trailer [48905,48915]
===
match
---
atom_expr [36528,36574]
atom_expr [35753,35799]
===
match
---
trailer [5846,5884]
trailer [5793,5831]
===
match
---
arglist [7542,7589]
arglist [7489,7536]
===
match
---
trailer [38504,38516]
trailer [37686,37698]
===
match
---
name: dag_id [42245,42251]
name: dag_id [41384,41390]
===
match
---
name: grace_multiplier [7327,7343]
name: grace_multiplier [7274,7290]
===
match
---
fstring_end: ' [46141,46142]
fstring_end: ' [45280,45281]
===
match
---
if_stmt [15800,16158]
if_stmt [15747,16105]
===
match
---
simple_stmt [11478,11554]
simple_stmt [11425,11501]
===
match
---
name: session [35369,35376]
name: session [34594,34601]
===
match
---
trailer [26103,26107]
trailer [26050,26054]
===
match
---
name: self [28877,28881]
name: self [28824,28828]
===
match
---
trailer [40391,40413]
trailer [39573,39595]
===
match
---
name: self [31847,31851]
name: self [31794,31798]
===
match
---
simple_stmt [21244,21530]
simple_stmt [21191,21477]
===
match
---
simple_stmt [12371,12400]
simple_stmt [12318,12347]
===
match
---
operator: = [4400,4401]
operator: = [4347,4348]
===
match
---
trailer [28509,28526]
trailer [28456,28473]
===
match
---
operator: = [18520,18521]
operator: = [18467,18468]
===
match
---
name: join [11505,11509]
name: join [11452,11456]
===
match
---
arith_expr [13672,13723]
arith_expr [13619,13670]
===
match
---
name: info [42600,42604]
name: info [41739,41743]
===
match
---
arith_expr [40460,40500]
arith_expr [39642,39682]
===
match
---
name: time [902,906]
name: time [902,906]
===
match
---
atom_expr [17896,17913]
atom_expr [17843,17860]
===
match
---
name: info [22374,22378]
name: info [22321,22325]
===
match
---
trailer [20773,20814]
trailer [20720,20761]
===
match
---
trailer [21635,21642]
trailer [21582,21589]
===
match
---
testlist_star_expr [12098,12144]
testlist_star_expr [12045,12091]
===
match
---
name: pool_slots_free [9817,9832]
name: pool_slots_free [9764,9779]
===
match
---
comparison [42027,42086]
comparison [41166,41225]
===
match
---
operator: , [6822,6823]
operator: , [6769,6770]
===
match
---
dotted_name [1105,1119]
dotted_name [1105,1119]
===
match
---
trailer [15264,15272]
trailer [15211,15219]
===
match
---
name: self [41445,41449]
name: self [40584,40588]
===
match
---
name: int [8620,8623]
name: int [8567,8570]
===
match
---
import_from [1266,1302]
import_from [1266,1302]
===
match
---
trailer [43883,43909]
trailer [43022,43048]
===
match
---
operator: , [46752,46753]
operator: , [45891,45892]
===
match
---
name: num_queued_tis [28988,29002]
name: num_queued_tis [28935,28949]
===
match
---
trailer [10882,10888]
trailer [10829,10835]
===
match
---
suite [11323,11424]
suite [11270,11371]
===
match
---
trailer [9614,9647]
trailer [9561,9594]
===
match
---
param [45766,45789]
param [44905,44928]
===
match
---
name: dag_run [39885,39892]
name: dag_run [39067,39074]
===
match
---
operator: -> [18182,18184]
operator: -> [18129,18131]
===
match
---
except_clause [34222,34250]
except_clause [33447,33475]
===
match
---
arglist [23126,23169]
arglist [23073,23116]
===
match
---
atom_expr [22483,22504]
atom_expr [22430,22451]
===
match
---
suite [36187,36357]
suite [35412,35582]
===
match
---
operator: - [49513,49514]
operator: - [48652,48653]
===
match
---
for_stmt [49279,49455]
for_stmt [48418,48594]
===
match
---
trailer [27878,27894]
trailer [27825,27841]
===
match
---
operator: = [38591,38592]
operator: = [37773,37774]
===
match
---
trailer [44524,44564]
trailer [43663,43703]
===
match
---
number: 1 [16613,16614]
number: 1 [16560,16561]
===
match
---
name: BACKFILL_JOB [10384,10396]
name: BACKFILL_JOB [10331,10343]
===
match
---
simple_stmt [22365,22425]
simple_stmt [22312,22372]
===
match
---
trailer [49610,49615]
trailer [48749,48754]
===
match
---
name: min [29312,29315]
name: min [29259,29262]
===
match
---
name: airflow [1271,1278]
name: airflow [1271,1278]
===
match
---
trailer [36486,36488]
trailer [35711,35713]
===
match
---
atom_expr [34832,34878]
atom_expr [34057,34103]
===
match
---
simple_stmt [24365,24448]
simple_stmt [24312,24395]
===
match
---
atom_expr [6878,6901]
atom_expr [6825,6848]
===
match
---
name: self [27331,27335]
name: self [27278,27282]
===
match
---
dotted_name [1912,1947]
dotted_name [1859,1894]
===
match
---
import_from [1303,1341]
import_from [1303,1341]
===
match
---
trailer [14567,14571]
trailer [14514,14518]
===
match
---
string: """Only run DagRun.verify integrity if Serialized DAG has changed since it is slow""" [44051,44136]
string: """Only run DagRun.verify integrity if Serialized DAG has changed since it is slow""" [43190,43275]
===
match
---
trailer [35093,35114]
trailer [34318,34339]
===
match
---
atom_expr [47897,47909]
atom_expr [47036,47048]
===
match
---
string: 'mysql' [5465,5472]
string: 'mysql' [5412,5419]
===
match
---
atom_expr [21244,21529]
atom_expr [21191,21476]
===
match
---
name: TI [17856,17858]
name: TI [17803,17805]
===
match
---
name: airflow [2012,2019]
name: airflow [1959,1966]
===
match
---
name: selectinload [10572,10584]
name: selectinload [10519,10531]
===
match
---
simple_stmt [41922,41931]
simple_stmt [41061,41070]
===
match
---
operator: , [27544,27545]
operator: , [27491,27492]
===
match
---
fstring_end: ' [40566,40567]
fstring_end: ' [39748,39749]
===
match
---
atom_expr [46097,46170]
atom_expr [45236,45309]
===
match
---
name: dag_run [44205,44212]
name: dag_run [43344,43351]
===
match
---
name: processor_timeout [24674,24691]
name: processor_timeout [24621,24638]
===
match
---
or_test [23290,23340]
or_test [23237,23287]
===
match
---
trailer [40700,40707]
trailer [39861,39868]
===
match
---
comparison [50857,50905]
comparison [49996,50044]
===
match
---
name: List [10934,10938]
name: List [10881,10885]
===
match
---
simple_stmt [20675,20727]
simple_stmt [20622,20674]
===
match
---
trailer [31966,31990]
trailer [31913,31937]
===
match
---
trailer [47495,47497]
trailer [46634,46636]
===
match
---
atom [8415,8579]
atom [8362,8526]
===
match
---
name: int [5507,5510]
name: int [5454,5457]
===
match
---
atom_expr [40555,40565]
atom_expr [39737,39747]
===
match
---
trailer [39737,39744]
trailer [38919,38926]
===
match
---
name: task_instance [16457,16470]
name: task_instance [16404,16417]
===
match
---
name: self [6469,6473]
name: self [6416,6420]
===
match
---
trailer [5075,5100]
trailer [5022,5047]
===
match
---
operator: , [38725,38726]
operator: , [37907,37908]
===
match
---
expr_stmt [5014,5062]
expr_stmt [4961,5009]
===
match
---
operator: @ [50471,50472]
operator: @ [49610,49611]
===
match
---
name: retry_state [47039,47050]
name: retry_state [46178,46189]
===
match
---
name: dag_id [14026,14032]
name: dag_id [13973,13979]
===
match
---
trailer [28097,28101]
trailer [28044,28048]
===
match
---
name: task_instance_str [11644,11661]
name: task_instance_str [11591,11608]
===
match
---
operator: , [9629,9630]
operator: , [9576,9577]
===
match
---
string: 'num_runs' [4427,4437]
string: 'num_runs' [4374,4384]
===
match
---
expr_stmt [22011,22072]
expr_stmt [21958,22019]
===
match
---
annassign [5587,5627]
annassign [5534,5574]
===
match
---
simple_stmt [33749,33808]
simple_stmt [32974,33033]
===
match
---
name: scheduler_health_check_threshold [7490,7522]
name: scheduler_health_check_threshold [7437,7469]
===
match
---
name: _send_sla_callbacks_to_processor [45086,45118]
name: _send_sla_callbacks_to_processor [44225,44257]
===
match
---
trailer [13675,13707]
trailer [13622,13654]
===
match
---
name: __init__ [5179,5187]
name: __init__ [5126,5134]
===
match
---
trailer [6440,6446]
trailer [6387,6393]
===
match
---
trailer [46289,46294]
trailer [45428,45433]
===
match
---
trailer [47459,47476]
trailer [46598,46615]
===
match
---
expr_stmt [18647,18676]
expr_stmt [18594,18623]
===
match
---
name: airflow [1688,1695]
name: airflow [1635,1642]
===
match
---
trailer [21969,21973]
trailer [21916,21920]
===
match
---
expr_stmt [5483,5558]
expr_stmt [5430,5505]
===
match
---
expr_stmt [24365,24447]
expr_stmt [24312,24394]
===
match
---
name: dag_id [36850,36856]
name: dag_id [36075,36081]
===
match
---
trailer [39850,39856]
trailer [39032,39038]
===
match
---
trailer [4413,4438]
trailer [4360,4385]
===
match
---
name: defaultdict [8698,8709]
name: defaultdict [8645,8656]
===
match
---
arglist [46109,46169]
arglist [45248,45308]
===
match
---
if_stmt [21698,21764]
if_stmt [21645,21711]
===
match
---
trailer [9382,9386]
trailer [9329,9333]
===
match
---
name: dag_model [23434,23443]
name: dag_model [23381,23390]
===
match
---
atom [47954,48851]
atom [47093,47990]
===
match
---
trailer [10442,10447]
trailer [10389,10394]
===
match
---
name: airflow [1790,1797]
name: airflow [1737,1744]
===
match
---
name: set [49486,49489]
name: set [48625,48628]
===
match
---
name: frame [6042,6047]
name: frame [5989,5994]
===
match
---
param [34717,34722]
param [33942,33947]
===
match
---
name: dag [38390,38393]
name: dag [37572,37575]
===
match
---
operator: , [38770,38771]
operator: , [37952,37953]
===
match
---
import_from [1206,1264]
import_from [1206,1264]
===
match
---
atom_expr [10358,10369]
atom_expr [10305,10316]
===
match
---
name: info [51373,51377]
name: info [50512,50516]
===
match
---
name: dag_run [33312,33319]
name: dag_run [32537,32544]
===
match
---
arglist [16276,16548]
arglist [16223,16495]
===
match
---
trailer [22120,22132]
trailer [22067,22079]
===
match
---
operator: , [42879,42880]
operator: , [42018,42019]
===
match
---
name: dag [37609,37612]
name: dag [36791,36794]
===
match
---
arglist [43347,43379]
arglist [42486,42518]
===
match
---
if_stmt [7324,7482]
if_stmt [7271,7429]
===
match
---
atom_expr [17052,17119]
atom_expr [16999,17066]
===
match
---
operator: = [40657,40658]
operator: = [39818,39819]
===
match
---
suite [45511,45576]
suite [44650,44715]
===
match
---
atom_expr [20641,20661]
atom_expr [20588,20608]
===
match
---
name: state [42351,42356]
name: state [41490,41495]
===
match
---
param [34952,34959]
param [34177,34184]
===
match
---
simple_stmt [47946,48852]
simple_stmt [47085,47991]
===
match
---
trailer [36706,36713]
trailer [35931,35938]
===
match
---
name: dag_run [40659,40666]
name: dag_run [39820,39827]
===
match
---
suite [40767,40890]
suite [39910,40029]
===
match
---
argument [24626,24660]
argument [24573,24607]
===
match
---
trailer [18830,18839]
trailer [18777,18786]
===
match
---
name: event_buffer [20990,21002]
name: event_buffer [20937,20949]
===
match
---
name: session [28510,28517]
name: session [28457,28464]
===
match
---
for_stmt [18474,18978]
for_stmt [18421,18925]
===
match
---
trailer [38835,38842]
trailer [38017,38024]
===
match
---
trailer [6418,6420]
trailer [6365,6367]
===
match
---
arglist [5847,5883]
arglist [5794,5830]
===
match
---
comparison [10398,10428]
comparison [10345,10375]
===
match
---
fstring_expr [45951,45962]
fstring_expr [45090,45101]
===
match
---
atom_expr [11287,11317]
atom_expr [11234,11264]
===
match
---
atom_expr [9835,9887]
atom_expr [9782,9834]
===
match
---
name: self [11562,11566]
name: self [11509,11513]
===
match
---
name: eagerload [1171,1180]
name: eagerload [1171,1180]
===
match
---
operator: = [12276,12277]
operator: = [12223,12224]
===
match
---
name: task_concurrency_limit [15393,15415]
name: task_concurrency_limit [15340,15362]
===
match
---
name: _execute [23843,23851]
name: _execute [23790,23798]
===
match
---
operator: = [17606,17607]
operator: = [17553,17554]
===
match
---
trailer [42294,42323]
trailer [41433,41462]
===
match
---
operator: -> [45791,45793]
operator: -> [44930,44932]
===
match
---
import_from [1529,1570]
import_from [1476,1517]
===
match
---
suite [6976,7769]
suite [6923,7716]
===
match
---
atom_expr [48397,48413]
atom_expr [47536,47552]
===
match
---
name: DEFERRED [50847,50855]
name: DEFERRED [49986,49994]
===
match
---
simple_stmt [5014,5063]
simple_stmt [4961,5010]
===
match
---
atom_expr [45816,45856]
atom_expr [44955,44995]
===
match
---
name: session [31825,31832]
name: session [31772,31779]
===
match
---
suite [10792,10860]
suite [10739,10807]
===
match
---
name: stats [1888,1893]
name: stats [1835,1840]
===
match
---
operator: , [23559,23560]
operator: , [23506,23507]
===
match
---
atom_expr [48642,48665]
atom_expr [47781,47804]
===
match
---
operator: -> [9033,9035]
operator: -> [8980,8982]
===
match
---
atom_expr [5968,5982]
atom_expr [5915,5929]
===
match
---
name: ti [22318,22320]
name: ti [22265,22267]
===
match
---
name: executable_tis [17520,17534]
name: executable_tis [17467,17481]
===
match
---
trailer [20246,20301]
trailer [20193,20248]
===
match
---
name: lower [47825,47830]
name: lower [46964,46969]
===
match
---
name: getint [36533,36539]
name: getint [35758,35764]
===
match
---
name: enumerate [13364,13373]
name: enumerate [13311,13320]
===
match
---
import_name [860,869]
import_name [860,869]
===
match
---
atom_expr [16871,16895]
atom_expr [16818,16842]
===
match
---
trailer [22828,22832]
trailer [22775,22779]
===
match
---
funcdef [23839,26221]
funcdef [23786,26168]
===
match
---
operator: , [17913,17914]
operator: , [17860,17861]
===
match
---
name: Tuple [1040,1045]
name: Tuple [1040,1045]
===
match
---
name: list [11746,11750]
name: list [11693,11697]
===
match
---
trailer [18608,18618]
trailer [18555,18565]
===
match
---
atom_expr [17856,17864]
atom_expr [17803,17811]
===
match
---
trailer [21901,21907]
trailer [21848,21854]
===
match
---
trailer [38393,38407]
trailer [37575,37589]
===
match
---
operator: = [12798,12799]
operator: = [12745,12746]
===
match
---
trailer [9845,9886]
trailer [9792,9833]
===
match
---
name: log [24097,24100]
name: log [24044,24047]
===
match
---
expr_stmt [8815,8839]
expr_stmt [8762,8786]
===
match
---
simple_stmt [44491,44565]
simple_stmt [43630,43704]
===
match
---
atom_expr [24635,24660]
atom_expr [24582,24607]
===
match
---
operator: , [42649,42650]
operator: , [41788,41789]
===
match
---
name: debug [44306,44311]
name: debug [43445,43450]
===
match
---
name: ValueError [44858,44868]
name: ValueError [43997,44007]
===
match
---
not_test [26889,26913]
not_test [26836,26860]
===
match
---
operator: -> [6968,6970]
operator: -> [6915,6917]
===
match
---
name: x [17382,17383]
name: x [17329,17330]
===
match
---
name: ti_deps [1920,1927]
name: ti_deps [1867,1874]
===
match
---
name: state [23204,23209]
name: state [23151,23156]
===
match
---
trailer [26030,26046]
trailer [25977,25993]
===
match
---
atom_expr [40517,40584]
atom_expr [39699,39766]
===
match
---
atom_expr [42242,42251]
atom_expr [41381,41390]
===
match
---
name: utcnow [7674,7680]
name: utcnow [7621,7627]
===
match
---
name: max_tis [20233,20240]
name: max_tis [20180,20187]
===
match
---
trailer [26107,26117]
trailer [26054,26064]
===
match
---
name: any [45304,45307]
name: any [44443,44446]
===
match
---
operator: , [22842,22843]
operator: , [22789,22790]
===
match
---
atom_expr [27565,27720]
atom_expr [27512,27667]
===
match
---
string: """         Looks at all tasks that are in the "deferred" state and whose trigger         or execution timeout has passed, so they can be marked as failed.         """ [50559,50726]
string: """         Looks at all tasks that are in the "deferred" state and whose trigger         or execution timeout has passed, so they can be marked as failed.         """ [49698,49865]
===
match
---
trailer [34609,34616]
trailer [33834,33841]
===
match
---
suite [35395,38920]
suite [34620,38102]
===
match
---
trailer [10735,10741]
trailer [10682,10688]
===
match
---
name: ti [23755,23757]
name: ti [23702,23704]
===
match
---
operator: , [48665,48666]
operator: , [47804,47805]
===
match
---
name: ti [22415,22417]
name: ti [22362,22364]
===
match
---
number: 300.0 [27311,27316]
number: 300.0 [27258,27263]
===
match
---
trailer [48022,48029]
trailer [47161,47168]
===
match
---
trailer [33084,33091]
trailer [32309,32316]
===
match
---
suite [20583,23834]
suite [20530,23781]
===
match
---
operator: , [21479,21480]
operator: , [21426,21427]
===
match
---
dotted_name [1790,1817]
dotted_name [1737,1764]
===
match
---
name: info [11571,11575]
name: info [11518,11522]
===
match
---
name: int [36631,36634]
name: int [35856,35859]
===
match
---
operator: , [4478,4479]
operator: , [4425,4426]
===
match
---
import_as_names [2449,2486]
import_as_names [2396,2433]
===
match
---
comparison [21545,21597]
comparison [21492,21544]
===
match
---
name: timer [27797,27802]
name: timer [27744,27749]
===
match
---
trailer [46908,47120]
trailer [46047,46259]
===
match
---
atom_expr [40968,40987]
atom_expr [40107,40126]
===
match
---
name: state [34863,34868]
name: state [34088,34093]
===
match
---
trailer [44934,44936]
trailer [44073,44075]
===
match
---
string: "Deactivating DAGs that haven't been touched since %s" [25452,25506]
string: "Deactivating DAGs that haven't been touched since %s" [25399,25453]
===
match
---
atom_expr [36399,36488]
atom_expr [35624,35713]
===
match
---
operator: = [27066,27067]
operator: = [27013,27014]
===
match
---
operator: - [4476,4477]
operator: - [4423,4424]
===
match
---
name: num_queued_tis [33953,33967]
name: num_queued_tis [33178,33192]
===
match
---
trailer [21386,21393]
trailer [21333,21340]
===
match
---
string: """         Reset any TaskInstance still in QUEUED or SCHEDULED states that were         enqueued by a SchedulerJob that is no longer running.          :return: the number of TIs reset         :rtype: int         """ [46424,46640]
string: """         Reset any TaskInstance still in QUEUED or SCHEDULED states that were         enqueued by a SchedulerJob that is no longer running.          :return: the number of TIs reset         :rtype: int         """ [45563,45779]
===
match
---
name: task_concurrency_map [12034,12054]
name: task_concurrency_map [11981,12001]
===
match
---
tfpdef [44733,44748]
tfpdef [43872,43887]
===
match
---
operator: , [29546,29547]
operator: , [29493,29494]
===
match
---
simple_stmt [39326,39776]
simple_stmt [38508,38958]
===
match
---
string: "from DAG %s is >= to the DAG's max_active_tasks limit of %s" [14690,14751]
string: "from DAG %s is >= to the DAG's max_active_tasks limit of %s" [14637,14698]
===
match
---
trailer [36655,36661]
trailer [35880,35886]
===
match
---
atom_expr [25126,25158]
atom_expr [25073,25105]
===
match
---
suite [26082,26172]
suite [26029,26119]
===
match
---
expr_stmt [41324,41364]
expr_stmt [40463,40503]
===
match
---
name: self [25417,25421]
name: self [25364,25368]
===
match
---
name: callback_to_run [43486,43501]
name: callback_to_run [42625,42640]
===
match
---
name: session [12219,12226]
name: session [12166,12173]
===
match
---
name: State [47911,47916]
name: State [47050,47055]
===
match
---
suite [50370,50436]
suite [49509,49575]
===
match
---
name: info [24101,24105]
name: info [24048,24052]
===
match
---
trailer [41766,41774]
trailer [40905,40913]
===
match
---
argument [43347,43362]
argument [42486,42501]
===
match
---
if_stmt [14472,14931]
if_stmt [14419,14878]
===
match
---
operator: , [41449,41450]
operator: , [40588,40589]
===
match
---
name: selectinload [21943,21955]
name: selectinload [21890,21902]
===
match
---
name: pool_slots [16471,16481]
name: pool_slots [16418,16428]
===
match
---
name: check_trigger_timeouts [50496,50518]
name: check_trigger_timeouts [49635,49657]
===
match
---
simple_stmt [33644,33703]
simple_stmt [32869,32928]
===
match
---
atom_expr [15653,15774]
atom_expr [15600,15721]
===
match
---
name: in_ [10839,10842]
name: in_ [10786,10789]
===
match
---
trailer [14571,14576]
trailer [14518,14523]
===
match
---
parameters [50518,50549]
parameters [49657,49688]
===
match
---
trailer [10741,10743]
trailer [10688,10690]
===
match
---
trailer [35159,35163]
trailer [34384,34388]
===
match
---
trailer [12682,12748]
trailer [12629,12695]
===
match
---
trailer [14228,14232]
trailer [14175,14179]
===
match
---
trailer [14025,14032]
trailer [13972,13979]
===
match
---
atom_expr [6280,6348]
atom_expr [6227,6295]
===
match
---
name: priority [18916,18924]
name: priority [18863,18871]
===
match
---
parameters [35328,35386]
parameters [34553,34611]
===
match
---
trailer [48386,48396]
trailer [47525,47535]
===
match
---
arglist [28892,28945]
arglist [28839,28892]
===
match
---
name: get_next_data_interval [37654,37676]
name: get_next_data_interval [36836,36858]
===
match
---
suite [47233,50330]
suite [46372,49469]
===
match
---
param [41445,41450]
param [40584,40589]
===
match
---
operator: , [8618,8619]
operator: , [8565,8566]
===
match
---
operator: , [14330,14331]
operator: , [14277,14278]
===
match
---
atom_expr [10934,10942]
atom_expr [10881,10889]
===
match
---
if_stmt [38310,38849]
if_stmt [37492,38031]
===
match
---
name: DagRun [41468,41474]
name: DagRun [40607,40613]
===
match
---
operator: , [47752,47753]
operator: , [46891,46892]
===
match
---
name: DagRun [39822,39828]
name: DagRun [39004,39010]
===
match
---
name: ti [18596,18598]
name: ti [18543,18545]
===
match
---
atom_expr [5388,5417]
atom_expr [5335,5364]
===
match
---
name: queued_by_job [48400,48413]
name: queued_by_job [47539,47552]
===
match
---
parameters [5752,5758]
parameters [5699,5705]
===
match
---
simple_stmt [11672,11752]
simple_stmt [11619,11699]
===
match
---
sync_comp_for [39625,39643]
sync_comp_for [38807,38825]
===
match
---
trailer [33311,33337]
trailer [32536,32562]
===
match
---
arglist [40530,40583]
arglist [39712,39765]
===
match
---
name: Session [1241,1248]
name: Session [1241,1248]
===
match
---
trailer [51104,51114]
trailer [50243,50253]
===
match
---
operator: = [12396,12397]
operator: = [12343,12344]
===
match
---
operator: @ [20495,20496]
operator: @ [20442,20443]
===
match
---
name: base_job [1547,1555]
name: base_job [1494,1502]
===
match
---
name: priority_sorted_task_instances [13676,13706]
name: priority_sorted_task_instances [13623,13653]
===
match
---
operator: = [24493,24494]
operator: = [24440,24441]
===
match
---
trailer [27206,27228]
trailer [27153,27175]
===
match
---
string: '*' [8477,8480]
string: '*' [8424,8427]
===
match
---
string: "Exiting scheduler loop as requested number of runs (%d - got to %d) has been reached" [29460,29546]
string: "Exiting scheduler loop as requested number of runs (%d - got to %d) has been reached" [29407,29493]
===
match
---
trailer [50846,50855]
trailer [49985,49994]
===
match
---
operator: ** [11040,11042]
operator: ** [10987,10989]
===
match
---
name: dialect [35849,35856]
name: dialect [35074,35081]
===
match
---
name: TaskInstance [2543,2555]
name: TaskInstance [2490,2502]
===
match
---
trailer [8546,8569]
trailer [8493,8516]
===
match
---
operator: , [41789,41790]
operator: , [40928,40929]
===
match
---
simple_stmt [23256,23271]
simple_stmt [23203,23218]
===
match
---
name: DagRunState [34730,34741]
name: DagRunState [33955,33966]
===
match
---
name: id [24871,24873]
name: id [24818,24820]
===
match
---
name: dag_id [44540,44546]
name: dag_id [43679,43685]
===
match
---
operator: , [21514,21515]
operator: , [21461,21462]
===
match
---
name: subdir [24606,24612]
name: subdir [24553,24559]
===
match
---
name: start [24979,24984]
name: start [24926,24931]
===
match
---
atom_expr [12068,12083]
atom_expr [12015,12030]
===
match
---
atom_expr [42200,42379]
atom_expr [41339,41518]
===
match
---
trailer [6952,6959]
trailer [6899,6906]
===
match
---
operator: = [8880,8881]
operator: = [8827,8828]
===
match
---
operator: , [12019,12020]
operator: , [11966,11967]
===
match
---
parameters [26249,26255]
parameters [26196,26202]
===
match
---
name: sig_name [6642,6650]
name: sig_name [6589,6597]
===
match
---
name: session [41791,41798]
name: session [40930,40937]
===
match
---
name: self [49576,49580]
name: self [48715,48719]
===
match
---
name: pickle_id [18609,18618]
name: pickle_id [18556,18565]
===
match
---
name: filter [42341,42347]
name: filter [41480,41486]
===
match
---
name: full_filepath [42738,42751]
name: full_filepath [41877,41890]
===
match
---
name: DefaultDict [12004,12015]
name: DefaultDict [11951,11962]
===
match
---
atom_expr [47137,47212]
atom_expr [46276,46351]
===
match
---
atom_expr [37517,37533]
atom_expr [36699,36715]
===
match
---
atom_expr [10398,10406]
atom_expr [10345,10353]
===
match
---
simple_stmt [21162,21231]
simple_stmt [21109,21178]
===
match
---
name: self [28370,28374]
name: self [28317,28321]
===
match
---
comparison [35986,36012]
comparison [35211,35237]
===
match
---
trailer [25036,25038]
trailer [24983,24985]
===
match
---
comparison [35836,35872]
comparison [35061,35097]
===
match
---
subscriptlist [11708,11730]
subscriptlist [11655,11677]
===
match
---
name: timing [40523,40529]
name: timing [39705,39711]
===
match
---
atom_expr [47694,47765]
atom_expr [46833,46904]
===
match
---
name: to_reset [49656,49664]
name: to_reset [48795,48803]
===
match
---
operator: , [18898,18899]
operator: , [18845,18846]
===
match
---
if_stmt [6157,6271]
if_stmt [6104,6218]
===
match
---
name: sys [6429,6432]
name: sys [6376,6379]
===
match
---
string: 'timed_out' [42901,42912]
string: 'timed_out' [42040,42051]
===
match
---
name: DAG [1598,1601]
name: DAG [1545,1548]
===
match
---
argument [23783,23798]
argument [23730,23745]
===
match
---
name: dm [36125,36127]
name: dm [35350,35352]
===
match
---
name: isoformat [25527,25536]
name: isoformat [25474,25483]
===
match
---
name: timezone [25021,25029]
name: timezone [24968,24976]
===
match
---
name: self [26184,26188]
name: self [26131,26135]
===
match
---
suite [12649,12774]
suite [12596,12721]
===
match
---
trailer [17381,17384]
trailer [17328,17331]
===
match
---
name: num_times_parse_dags [4448,4468]
name: num_times_parse_dags [4395,4415]
===
match
---
name: session [12227,12234]
name: session [12174,12181]
===
match
---
trailer [24942,24944]
trailer [24889,24891]
===
match
---
name: self [7620,7624]
name: self [7567,7571]
===
match
---
trailer [16884,16895]
trailer [16831,16842]
===
match
---
atom_expr [15471,15492]
atom_expr [15418,15439]
===
match
---
name: self [5483,5487]
name: self [5430,5434]
===
match
---
name: run_type [10361,10369]
name: run_type [10308,10316]
===
match
---
name: dag [45690,45693]
name: dag [44829,44832]
===
match
---
name: _create_dag_runs [35312,35328]
name: _create_dag_runs [34537,34553]
===
match
---
trailer [17917,17934]
trailer [17864,17881]
===
match
---
trailer [48544,48549]
trailer [47683,47688]
===
match
---
trailer [44949,44982]
trailer [44088,44121]
===
match
---
name: queue [18689,18694]
name: queue [18636,18641]
===
match
---
atom_expr [35347,35367]
atom_expr [34572,34592]
===
match
---
atom_expr [24476,24520]
atom_expr [24423,24467]
===
match
---
operator: , [38686,38687]
operator: , [37868,37869]
===
match
---
import_from [1785,1874]
import_from [1732,1821]
===
match
---
operator: , [4607,4608]
operator: , [4554,4555]
===
match
---
name: self [26026,26030]
name: self [25973,25977]
===
match
---
suite [45799,46187]
suite [44938,45326]
===
match
---
arglist [36662,36692]
arglist [35887,35917]
===
match
---
trailer [29897,29918]
trailer [29844,29865]
===
match
---
name: task_instance [42470,42483]
name: task_instance [41609,41622]
===
match
---
operator: , [36946,36947]
operator: , [36171,36172]
===
match
---
expr_stmt [5234,5249]
expr_stmt [5181,5196]
===
match
---
operator: -> [19052,19054]
operator: -> [18999,19001]
===
match
---
name: queued_tis [20478,20488]
name: queued_tis [20425,20435]
===
match
---
trailer [48808,48816]
trailer [47947,47955]
===
match
---
operator: , [7924,7925]
operator: , [7871,7872]
===
match
---
with_stmt [31689,34653]
with_stmt [31636,33878]
===
match
---
atom_expr [7685,7706]
atom_expr [7632,7653]
===
match
---
expr_stmt [47254,47633]
expr_stmt [46393,46772]
===
match
---
name: TI [8559,8561]
name: TI [8506,8508]
===
match
---
atom_expr [22855,22863]
atom_expr [22802,22810]
===
match
---
name: task_id [17024,17031]
name: task_id [16971,16978]
===
match
---
simple_stmt [33421,33443]
simple_stmt [32646,32668]
===
match
---
atom_expr [47790,47854]
atom_expr [46929,46993]
===
match
---
suite [39157,41409]
suite [38339,40548]
===
match
---
name: of [10992,10994]
name: of [10939,10941]
===
match
---
operator: , [7553,7554]
operator: , [7500,7501]
===
match
---
trailer [24151,24172]
trailer [24098,24119]
===
match
---
operator: , [36012,36013]
operator: , [35237,35238]
===
match
---
simple_stmt [17345,17410]
simple_stmt [17292,17357]
===
match
---
trailer [21503,21514]
trailer [21450,21461]
===
match
---
trailer [48396,48414]
trailer [47535,47553]
===
match
---
atom_expr [49605,49666]
atom_expr [48744,48805]
===
match
---
trailer [12199,12217]
trailer [12146,12164]
===
match
---
dotted_name [2153,2174]
dotted_name [2100,2121]
===
match
---
atom_expr [2794,2832]
atom_expr [2741,2779]
===
match
---
trailer [22511,22517]
trailer [22458,22464]
===
match
---
atom_expr [44297,44393]
atom_expr [43436,43532]
===
match
---
not_test [24334,24355]
not_test [24281,24302]
===
match
---
name: expected_start_date [40481,40500]
name: expected_start_date [39663,39682]
===
match
---
tfpdef [8994,9006]
tfpdef [8941,8953]
===
match
---
name: Stats [40517,40522]
name: Stats [39699,39704]
===
match
---
name: DagCallbackRequest [42702,42720]
name: DagCallbackRequest [41841,41859]
===
match
---
simple_stmt [45808,45857]
simple_stmt [44947,44996]
===
match
---
atom_expr [33274,33337]
atom_expr [32499,32562]
===
match
---
operator: < [7724,7725]
operator: < [7671,7672]
===
match
---
name: active_runs [40902,40913]
name: active_runs [40041,40052]
===
match
---
atom_expr [39731,39744]
atom_expr [38913,38926]
===
match
---
expr_stmt [49428,49454]
expr_stmt [48567,48593]
===
match
---
name: multiprocessing [844,859]
name: multiprocessing [844,859]
===
match
---
argument [43364,43379]
argument [42503,42518]
===
match
---
parameters [41435,41507]
parameters [40574,40646]
===
match
---
name: num_runs [4386,4394]
name: num_runs [4333,4341]
===
match
---
name: tasks [45352,45357]
name: tasks [44491,44496]
===
match
---
name: self [29316,29320]
name: self [29263,29267]
===
match
---
expr_stmt [36584,37028]
expr_stmt [35809,36253]
===
match
---
trailer [28383,28393]
trailer [28330,28340]
===
match
---
trailer [9850,9858]
trailer [9797,9805]
===
match
---
name: pickle_id [18586,18595]
name: pickle_id [18533,18542]
===
match
---
trailer [22104,22120]
trailer [22051,22067]
===
match
---
name: SerializedDagModel [44162,44180]
name: SerializedDagModel [43301,43319]
===
match
---
name: dag_processing [1355,1369]
name: dag_processing [1355,1369]
===
match
---
name: make_transient [18050,18064]
name: make_transient [17997,18011]
===
match
---
trailer [36849,36856]
trailer [36074,36081]
===
match
---
atom_expr [48695,48707]
atom_expr [47834,47846]
===
match
---
trailer [39454,39461]
trailer [38636,38643]
===
match
---
simple_stmt [2487,2530]
simple_stmt [2434,2477]
===
match
---
operator: , [27453,27454]
operator: , [27400,27401]
===
match
---
name: name [6676,6680]
name: name [6623,6627]
===
match
---
trailer [10306,10314]
trailer [10253,10261]
===
match
---
operator: , [12083,12084]
operator: , [12030,12031]
===
match
---
trailer [37460,37470]
trailer [36646,36652]
===
match
---
name: RUNNING [47410,47417]
name: RUNNING [46549,46556]
===
match
---
expr_stmt [42470,42505]
expr_stmt [41609,41644]
===
match
---
name: task_id [8771,8778]
name: task_id [8718,8725]
===
match
---
argument [5195,5203]
argument [5142,5150]
===
match
---
name: QUEUED [22294,22300]
name: QUEUED [22241,22247]
===
match
---
simple_stmt [2091,2148]
simple_stmt [2038,2095]
===
match
---
simple_stmt [23724,23800]
simple_stmt [23671,23747]
===
match
---
string: 'MainProcess' [2836,2849]
string: 'MainProcess' [2783,2796]
===
match
---
name: log [25938,25941]
name: log [25885,25888]
===
match
---
atom_expr [26184,26220]
atom_expr [26131,26167]
===
match
---
operator: >= [29387,29389]
operator: >= [29334,29336]
===
match
---
name: done [29691,29695]
name: done [29638,29642]
===
match
---
atom_expr [20400,20458]
atom_expr [20347,20405]
===
match
---
operator: += [41360,41362]
operator: += [40499,40501]
===
match
---
name: log [51369,51372]
name: log [50508,50511]
===
match
---
name: max_tis [8994,9001]
name: max_tis [8941,8948]
===
match
---
simple_stmt [884,895]
simple_stmt [884,895]
===
match
---
operator: = [5443,5444]
operator: = [5390,5391]
===
match
---
name: RUNNING [7640,7647]
name: RUNNING [7587,7594]
===
match
---
name: dag_runs [31922,31930]
name: dag_runs [31869,31877]
===
match
---
suite [4684,5727]
suite [4631,5674]
===
match
---
name: signal [6653,6659]
name: signal [6600,6606]
===
match
---
name: or_ [1088,1091]
name: or_ [1088,1091]
===
match
---
expr_stmt [10224,10670]
expr_stmt [10171,10617]
===
match
---
arglist [39591,39694]
arglist [38773,38876]
===
match
---
operator: = [39346,39347]
operator: = [38528,38529]
===
match
---
name: DAG [25580,25583]
name: DAG [25527,25530]
===
match
---
name: dag [37650,37653]
name: dag [36832,36835]
===
match
---
trailer [6667,6675]
trailer [6614,6622]
===
match
---
name: unfinished_task_instances [42427,42452]
name: unfinished_task_instances [41566,41591]
===
match
---
trailer [2586,2595]
trailer [2533,2542]
===
match
---
arglist [24106,24172]
arglist [24053,24119]
===
match
---
comparison [15803,15853]
comparison [15750,15800]
===
match
---
operator: == [11318,11320]
operator: == [11265,11267]
===
match
---
name: log [26189,26192]
name: log [26136,26139]
===
match
---
trailer [7920,7930]
trailer [7867,7877]
===
match
---
simple_stmt [9583,9648]
simple_stmt [9530,9595]
===
match
---
atom [36292,36342]
atom [35517,35567]
===
match
---
operator: == [35862,35864]
operator: == [35087,35089]
===
match
---
atom_expr [44532,44546]
atom_expr [43671,43685]
===
match
---
name: DagRun [48695,48701]
name: DagRun [47834,47840]
===
match
---
trailer [16818,16825]
trailer [16765,16772]
===
match
---
atom_expr [11696,11731]
atom_expr [11643,11678]
===
match
---
simple_stmt [46284,46324]
simple_stmt [45423,45463]
===
match
---
name: dag_run [44249,44256]
name: dag_run [43388,43395]
===
match
---
name: state [22512,22517]
name: state [22459,22464]
===
match
---
if_stmt [44811,44904]
if_stmt [43950,44043]
===
match
---
parameters [6027,6048]
parameters [5974,5995]
===
match
---
name: state [22858,22863]
name: state [22805,22810]
===
match
---
name: self [20247,20251]
name: self [20194,20198]
===
match
---
string: """Find DagRuns in queued state and decide moving them to running state""" [39166,39240]
string: """Find DagRuns in queued state and decide moving them to running state""" [38348,38422]
===
match
---
trailer [35153,35175]
trailer [34378,34400]
===
match
---
simple_stmt [40517,40585]
simple_stmt [39699,39767]
===
match
---
trailer [6675,6680]
trailer [6622,6627]
===
match
---
name: dr [39615,39617]
name: dr [38797,38799]
===
match
---
arglist [5907,5944]
arglist [5854,5891]
===
match
---
name: log [43210,43213]
name: log [42349,42352]
===
match
---
name: ti_concurrency_query [8364,8384]
name: ti_concurrency_query [8311,8331]
===
match
---
string: 'dag_model' [21956,21967]
string: 'dag_model' [21903,21914]
===
match
---
string: 'scheduler.tasks.starving' [17141,17167]
string: 'scheduler.tasks.starving' [17088,17114]
===
match
---
arglist [5525,5557]
arglist [5472,5504]
===
match
---
name: self [14563,14567]
name: self [14510,14514]
===
match
---
name: lock_rows [9615,9624]
name: lock_rows [9562,9571]
===
match
---
name: existing_dagruns_filter [35886,35909]
name: existing_dagruns_filter [35111,35134]
===
match
---
name: models [45816,45822]
name: models [44955,44961]
===
match
---
import_from [1571,1601]
import_from [1518,1548]
===
match
---
atom_expr [5567,5587]
atom_expr [5514,5534]
===
match
---
name: log [15888,15891]
name: log [15835,15838]
===
match
---
trailer [33278,33311]
trailer [32503,32536]
===
match
---
simple_stmt [47254,47634]
simple_stmt [46393,46773]
===
match
---
name: tis_to_reset_or_adopt [49738,49759]
name: tis_to_reset_or_adopt [48877,48898]
===
match
---
operator: = [9025,9026]
operator: = [8972,8973]
===
match
---
name: append [11863,11869]
name: append [11810,11816]
===
match
---
operator: = [15651,15652]
operator: = [15598,15599]
===
match
---
argument [35933,36159]
argument [35158,35384]
===
match
---
atom_expr [5315,5359]
atom_expr [5262,5306]
===
match
---
name: airflow [2245,2252]
name: airflow [2192,2199]
===
match
---
operator: , [36546,36547]
operator: , [35771,35772]
===
match
---
if_stmt [15563,16158]
if_stmt [15510,16105]
===
match
---
atom_expr [8852,8879]
atom_expr [8799,8826]
===
match
---
operator: = [9387,9388]
operator: = [9334,9335]
===
match
---
testlist [8903,8920]
testlist [8850,8867]
===
match
---
atom_expr [23627,23681]
atom_expr [23574,23628]
===
match
---
name: _create_dagruns_for_dags [31793,31817]
name: _create_dagruns_for_dags [31740,31764]
===
match
---
trailer [17140,17194]
trailer [17087,17141]
===
match
---
name: Stats [34455,34460]
name: Stats [33680,33685]
===
match
---
name: FAILED [21561,21567]
name: FAILED [21508,21514]
===
match
---
name: datetime [796,804]
name: datetime [796,804]
===
match
---
trailer [21417,21425]
trailer [21364,21372]
===
match
---
trailer [32854,32861]
trailer [32255,32262]
===
match
---
operator: = [46727,46728]
operator: = [45866,45867]
===
match
---
simple_stmt [5071,5127]
simple_stmt [5018,5074]
===
match
---
name: self [31933,31937]
name: self [31880,31884]
===
match
---
atom [20930,20932]
atom [20877,20879]
===
match
---
atom_expr [5847,5860]
atom_expr [5794,5807]
===
match
---
name: dag_id [15273,15279]
name: dag_id [15220,15226]
===
match
---
name: executable_tis [18084,18098]
name: executable_tis [18031,18045]
===
match
---
sync_comp_for [36121,36141]
sync_comp_for [35346,35366]
===
match
---
operator: = [36604,36605]
operator: = [35829,35830]
===
match
---
name: start_date [39893,39903]
name: start_date [39075,39085]
===
match
---
name: ti [23041,23043]
name: ti [22988,22990]
===
match
---
string: "Skipping SLA check for %s because no tasks in DAG have SLAs" [45387,45448]
string: "Skipping SLA check for %s because no tasks in DAG have SLAs" [44526,44587]
===
match
---
name: session [15289,15296]
name: session [15236,15243]
===
match
---
name: log [46654,46657]
name: log [45793,45796]
===
match
---
trailer [27839,27852]
trailer [27786,27799]
===
match
---
trailer [45822,45827]
trailer [44961,44966]
===
match
---
trailer [21589,21596]
trailer [21536,21543]
===
match
---
trailer [21574,21582]
trailer [21521,21529]
===
match
---
atom_expr [27242,27317]
atom_expr [27189,27264]
===
match
---
name: len [50452,50455]
name: len [49591,49594]
===
match
---
name: next_dagrun [36308,36319]
name: next_dagrun [35533,35544]
===
match
---
simple_stmt [1266,1303]
simple_stmt [1266,1303]
===
match
---
name: log [29718,29721]
name: log [29665,29668]
===
match
---
name: pop [22172,22175]
name: pop [22119,22122]
===
match
---
name: self [47801,47805]
name: self [46940,46944]
===
match
---
not_test [6502,6526]
not_test [6449,6473]
===
match
---
name: callback [45067,45075]
name: callback [44206,44214]
===
match
---
operator: , [22413,22414]
operator: , [22360,22361]
===
match
---
name: query [35077,35082]
name: query [34302,34307]
===
match
---
name: task_instance [16988,17001]
name: task_instance [16935,16948]
===
match
---
arglist [17141,17193]
arglist [17088,17140]
===
match
---
trailer [5517,5524]
trailer [5464,5471]
===
match
---
name: getint [5518,5524]
name: getint [5465,5471]
===
match
---
trailer [49692,49697]
trailer [48831,48836]
===
match
---
atom_expr [17915,17934]
atom_expr [17862,17881]
===
match
---
trailer [22526,22533]
trailer [22473,22480]
===
match
---
name: DagRun [36984,36990]
name: DagRun [36209,36215]
===
match
---
name: session [50525,50532]
name: session [49664,49671]
===
match
---
name: log [6883,6886]
name: log [6830,6833]
===
match
---
trailer [27255,27317]
trailer [27202,27264]
===
match
---
dotted_name [1576,1590]
dotted_name [1523,1537]
===
match
---
name: e [34249,34250]
name: e [33474,33475]
===
match
---
trailer [47902,47909]
trailer [47041,47048]
===
match
---
simple_stmt [25573,25626]
simple_stmt [25520,25573]
===
match
---
suite [25850,25887]
suite [25797,25834]
===
match
---
trailer [22493,22504]
trailer [22440,22451]
===
match
---
name: SchedulerJob [47382,47394]
name: SchedulerJob [46521,46533]
===
match
---
trailer [48593,48751]
trailer [47732,47890]
===
match
---
name: models [2580,2586]
name: models [2527,2533]
===
match
---
atom_expr [42068,42086]
atom_expr [41207,41225]
===
match
---
atom_expr [49554,49573]
atom_expr [48693,48712]
===
match
---
simple_stmt [37551,37560]
simple_stmt [36733,36742]
===
match
---
string: "Processor agent is not started." [44869,44902]
string: "Processor agent is not started." [44008,44041]
===
match
---
operator: , [8778,8779]
operator: , [8725,8726]
===
match
---
name: dag_id [37215,37221]
name: dag_id [36440,36446]
===
match
---
name: provide_session [43948,43963]
name: provide_session [43087,43102]
===
match
---
operator: = [10023,10024]
operator: = [9970,9971]
===
match
---
operator: , [8453,8454]
operator: , [8400,8401]
===
match
---
atom_expr [39843,39856]
atom_expr [39025,39038]
===
match
---
import_name [870,883]
import_name [870,883]
===
match
---
suite [45268,45288]
suite [44407,44427]
===
match
---
name: filter [10515,10521]
name: filter [10462,10468]
===
match
---
name: query [8437,8442]
name: query [8384,8389]
===
match
---
operator: , [44026,44027]
operator: , [43165,43166]
===
match
---
name: num_starving_tasks [13744,13762]
name: num_starving_tasks [13691,13709]
===
match
---
name: dag_max_active_tasks_map [14085,14109]
name: dag_max_active_tasks_map [14032,14056]
===
match
---
name: utils [2104,2109]
name: utils [2051,2056]
===
match
---
suite [49811,50126]
suite [48950,49265]
===
match
---
trailer [46740,46789]
trailer [45879,45928]
===
match
---
name: self [26893,26897]
name: self [26840,26844]
===
match
---
name: signum [6034,6040]
name: signum [5981,5987]
===
match
---
simple_stmt [22085,22133]
simple_stmt [22032,22080]
===
match
---
expr_stmt [20735,20819]
expr_stmt [20682,20766]
===
match
---
operator: = [17981,17982]
operator: = [17928,17929]
===
match
---
atom_expr [33644,33702]
atom_expr [32869,32927]
===
match
---
import_name [805,821]
import_name [805,821]
===
match
---
trailer [24409,24447]
trailer [24356,24394]
===
match
---
simple_stmt [14948,14993]
simple_stmt [14895,14940]
===
match
---
param [6028,6033]
param [5975,5980]
===
match
---
trailer [8457,8464]
trailer [8404,8411]
===
match
---
tfpdef [45766,45782]
tfpdef [44905,44921]
===
match
---
trailer [18524,18540]
trailer [18471,18487]
===
match
---
name: State [21569,21574]
name: State [21516,21521]
===
match
---
trailer [14576,14901]
trailer [14523,14848]
===
match
---
name: task_instances_to_examine [10907,10932]
name: task_instances_to_examine [10854,10879]
===
match
---
name: query [50779,50784]
name: query [49918,49923]
===
match
---
atom_expr [10246,10660]
atom_expr [10193,10607]
===
match
---
operator: = [22157,22158]
operator: = [22104,22105]
===
match
---
name: task_concurrency_map [15653,15673]
name: task_concurrency_map [15600,15620]
===
match
---
dotted_name [1688,1709]
dotted_name [1635,1656]
===
match
---
name: count [36682,36687]
name: count [35907,35912]
===
match
---
simple_stmt [6751,6834]
simple_stmt [6698,6781]
===
match
---
atom_expr [42563,42578]
atom_expr [41702,41717]
===
match
---
trailer [37594,37604]
trailer [36776,36786]
===
match
---
name: provide_session [45717,45732]
name: provide_session [44856,44871]
===
match
---
number: 0 [10764,10765]
number: 0 [10711,10712]
===
match
---
trailer [36232,36270]
trailer [35457,35495]
===
match
---
trailer [6764,6833]
trailer [6711,6780]
===
match
---
name: Stats [49687,49692]
name: Stats [48826,48831]
===
match
---
operator: , [23583,23584]
operator: , [23530,23531]
===
match
---
trailer [36044,36059]
trailer [35269,35284]
===
match
---
operator: == [48708,48710]
operator: == [47847,47849]
===
match
---
atom_expr [25933,25992]
atom_expr [25880,25939]
===
match
---
string: "Critical section lock held by another Scheduler" [34384,34433]
string: "Critical section lock held by another Scheduler" [33609,33658]
===
match
---
atom_expr [42788,42798]
atom_expr [41927,41937]
===
match
---
name: using_sqlite [5373,5385]
name: using_sqlite [5320,5332]
===
match
---
annassign [5505,5558]
annassign [5452,5505]
===
match
---
name: airflow [1576,1583]
name: airflow [1523,1530]
===
match
---
import_name [822,836]
import_name [822,836]
===
match
---
name: Session [9017,9024]
name: Session [8964,8971]
===
match
---
dictorsetmaker [36867,36897]
dictorsetmaker [36092,36122]
===
match
---
atom_expr [18826,18977]
atom_expr [18773,18924]
===
match
---
name: Session [39135,39142]
name: Session [38317,38324]
===
match
---
expr_stmt [28458,28526]
expr_stmt [28405,28473]
===
match
---
name: filter_for_tis [17679,17693]
name: filter_for_tis [17626,17640]
===
match
---
name: session [44221,44228]
name: session [43360,43367]
===
match
---
atom_expr [11042,11070]
atom_expr [10989,11017]
===
match
---
atom_expr [10522,10530]
atom_expr [10469,10477]
===
match
---
string: "Processing each file at most %s times" [24106,24145]
string: "Processing each file at most %s times" [24053,24092]
===
match
---
comp_op [12636,12642]
comp_op [12583,12589]
===
match
---
string: "Figuring out tasks to run in Pool(name=%s) with %s open slots " [12908,12972]
string: "Figuring out tasks to run in Pool(name=%s) with %s open slots " [12855,12919]
===
match
---
name: execution_date [13250,13264]
name: execution_date [13197,13211]
===
match
---
name: self [24338,24342]
name: self [24285,24289]
===
match
---
comparison [48482,48517]
comparison [47621,47656]
===
match
---
operator: >= [15828,15830]
operator: >= [15775,15777]
===
match
---
trailer [45673,45681]
trailer [44812,44820]
===
match
---
name: session [44548,44555]
name: session [43687,43694]
===
match
---
name: num_runs [4728,4736]
name: num_runs [4675,4683]
===
match
---
name: session [15281,15288]
name: session [15228,15235]
===
match
---
name: read_dags_from_db [5682,5699]
name: read_dags_from_db [5629,5646]
===
match
---
name: self [12147,12151]
name: self [12094,12098]
===
match
---
name: using_sqlite [24343,24355]
name: using_sqlite [24290,24302]
===
match
---
name: dag [45125,45128]
name: dag [44264,44267]
===
match
---
name: session [36648,36655]
name: session [35873,35880]
===
match
---
trailer [25156,25158]
trailer [25103,25105]
===
match
---
return_stmt [43919,43941]
return_stmt [43058,43080]
===
match
---
name: log [22370,22373]
name: log [22317,22320]
===
match
---
trailer [11717,11730]
trailer [11664,11677]
===
match
---
name: session [35167,35174]
name: session [34392,34399]
===
match
---
simple_stmt [5368,5418]
simple_stmt [5315,5365]
===
match
---
atom_expr [23316,23340]
atom_expr [23263,23287]
===
match
---
trailer [50831,50837]
trailer [49970,49976]
===
match
---
name: DagFileProcessorAgent [1385,1406]
name: DagFileProcessorAgent [1385,1406]
===
match
---
atom_expr [10642,10659]
atom_expr [10589,10606]
===
match
---
atom [32862,32888]
atom [32263,32289]
===
match
---
operator: != [10370,10372]
operator: != [10317,10319]
===
match
---
string: "Processor agent is not started." [20692,20725]
string: "Processor agent is not started." [20639,20672]
===
match
---
operator: = [44531,44532]
operator: = [43670,43671]
===
match
---
name: on_failure_callback [23321,23340]
name: on_failure_callback [23268,23287]
===
match
---
atom_expr [34604,34618]
atom_expr [33829,33843]
===
match
---
arglist [10358,10428]
arglist [10305,10375]
===
match
---
atom_expr [10831,10857]
atom_expr [10778,10804]
===
match
---
suite [40618,41409]
suite [39800,40548]
===
match
---
atom_expr [25417,25556]
atom_expr [25364,25503]
===
match
---
simple_stmt [6843,6870]
simple_stmt [6790,6817]
===
match
---
not_test [45300,45358]
not_test [44439,44497]
===
match
---
expr_stmt [16635,16664]
expr_stmt [16582,16611]
===
match
---
string: "Starting the scheduler" [23889,23913]
string: "Starting the scheduler" [23836,23860]
===
match
---
operator: = [38437,38438]
operator: = [37619,37620]
===
match
---
trailer [50926,51309]
trailer [50065,50448]
===
match
---
trailer [44516,44524]
trailer [43655,43663]
===
match
---
atom_expr [39939,39961]
atom_expr [39121,39143]
===
match
---
if_stmt [44996,45077]
if_stmt [44135,44216]
===
match
---
atom_expr [48806,48816]
atom_expr [47945,47955]
===
match
---
name: count [8882,8887]
name: count [8829,8834]
===
match
---
name: DagRunType [10373,10383]
name: DagRunType [10320,10330]
===
match
---
tfpdef [46242,46258]
tfpdef [45381,45397]
===
match
---
simple_stmt [40902,40952]
simple_stmt [40041,40091]
===
match
---
expr_stmt [35077,35123]
expr_stmt [34302,34348]
===
match
---
atom_expr [29568,29581]
atom_expr [29515,29528]
===
match
---
string: 'max_tis_per_query' [5538,5557]
string: 'max_tis_per_query' [5485,5504]
===
match
---
name: sql_conn [5299,5307]
name: sql_conn [5246,5254]
===
match
---
trailer [10421,10428]
trailer [10368,10375]
===
match
---
name: EXECUTION_STATES [1955,1971]
name: EXECUTION_STATES [1902,1918]
===
match
---
operator: , [2460,2461]
operator: , [2407,2408]
===
match
---
argument [44548,44563]
argument [43687,43702]
===
match
---
name: dag_id [44386,44392]
name: dag_id [43525,43531]
===
match
---
name: _start_queued_dagruns [39081,39102]
name: _start_queued_dagruns [38263,38284]
===
match
---
name: task_instance_str [50081,50098]
name: task_instance_str [49220,49237]
===
match
---
operator: = [42822,42823]
operator: = [41961,41962]
===
match
---
trailer [43153,43155]
trailer [42292,42294]
===
match
---
number: 15.0 [27498,27502]
number: 15.0 [27445,27449]
===
match
---
name: _get_next_dagruns_to_examine [34688,34716]
name: _get_next_dagruns_to_examine [33913,33941]
===
match
---
argument [38671,38686]
argument [37853,37868]
===
match
---
name: session [46242,46249]
name: session [45381,45388]
===
match
---
if_stmt [23287,23800]
if_stmt [23234,23747]
===
match
---
name: dag_runs [32192,32200]
name: dag_runs [32139,32147]
===
match
---
name: state [8506,8511]
name: state [8453,8458]
===
match
---
trailer [33652,33658]
trailer [32877,32883]
===
match
---
arglist [6294,6347]
arglist [6241,6294]
===
match
---
atom_expr [45308,45337]
atom_expr [44447,44476]
===
match
---
operator: = [32160,32161]
operator: = [32107,32108]
===
match
---
arith_expr [42048,42086]
arith_expr [41187,41225]
===
match
---
funcdef [6453,6902]
funcdef [6400,6849]
===
match
---
simple_stmt [1206,1265]
simple_stmt [1206,1265]
===
match
---
trailer [16936,16944]
trailer [16883,16891]
===
match
---
name: dagbag [44510,44516]
name: dagbag [43649,43655]
===
match
---
name: msg [42897,42900]
name: msg [42036,42039]
===
match
---
operator: = [49041,49042]
operator: = [48180,48181]
===
match
---
name: debug [34378,34383]
name: debug [33603,33608]
===
match
---
operator: , [1003,1004]
operator: , [1003,1004]
===
match
---
trailer [39685,39693]
trailer [38867,38875]
===
match
---
expr_stmt [5567,5627]
expr_stmt [5514,5574]
===
match
---
trailer [45693,45700]
trailer [44832,44839]
===
match
---
trailer [20284,20300]
trailer [20231,20247]
===
match
---
annassign [4241,4300]
annassign [4188,4247]
===
match
---
comparison [42295,42322]
comparison [41434,41461]
===
match
---
atom_expr [22057,22071]
atom_expr [22004,22018]
===
match
---
name: signal [5961,5967]
name: signal [5908,5914]
===
match
---
operator: , [13031,13032]
operator: , [12978,12979]
===
match
---
if_stmt [10775,10860]
if_stmt [10722,10807]
===
match
---
string: '*' [36688,36691]
string: '*' [35913,35916]
===
match
---
trailer [27757,27763]
trailer [27704,27710]
===
match
---
simple_stmt [49605,49667]
simple_stmt [48744,48806]
===
match
---
name: not_ [10482,10486]
name: not_ [10429,10433]
===
match
---
operator: , [23576,23577]
operator: , [23523,23524]
===
match
---
operator: @ [46329,46330]
operator: @ [45468,45469]
===
match
---
atom_expr [10622,10640]
atom_expr [10569,10587]
===
match
---
name: func [1076,1080]
name: func [1076,1080]
===
match
---
trailer [11350,11389]
trailer [11297,11336]
===
match
---
name: dag_hash [38708,38716]
name: dag_hash [37890,37898]
===
match
---
operator: } [4226,4227]
operator: } [4173,4174]
===
match
---
trailer [28816,28822]
trailer [28763,28769]
===
match
---
atom_expr [37185,37222]
atom_expr [36410,36447]
===
match
---
trailer [44429,44438]
trailer [43568,43577]
===
match
---
trailer [39730,39745]
trailer [38912,38927]
===
match
---
name: session [41484,41491]
name: session [40623,40630]
===
match
---
arglist [42605,42665]
arglist [41744,41804]
===
match
---
name: dag_run [33213,33220]
name: dag_run [32438,32445]
===
match
---
trailer [12151,12174]
trailer [12098,12121]
===
match
---
atom_expr [44422,44438]
atom_expr [43561,43577]
===
match
---
string: """Register signals that stop child processes""" [5776,5824]
string: """Register signals that stop child processes""" [5723,5771]
===
match
---
subscriptlist [12016,12024]
subscriptlist [11963,11971]
===
match
---
param [34945,34951]
param [34170,34176]
===
match
---
name: states [8516,8522]
name: states [8463,8469]
===
match
---
name: slot_stats [45965,45975]
name: slot_stats [45104,45114]
===
match
---
name: query [39404,39409]
name: query [38586,38591]
===
match
---
name: pools [9871,9876]
name: pools [9818,9823]
===
match
---
operator: , [11026,11027]
operator: , [10973,10974]
===
match
---
simple_stmt [870,884]
simple_stmt [870,884]
===
match
---
arglist [46930,47102]
arglist [46069,46241]
===
match
---
try_stmt [47229,50436]
try_stmt [46368,49575]
===
match
---
name: self [33644,33648]
name: self [32869,32873]
===
match
---
trailer [43346,43380]
trailer [42485,42519]
===
match
---
trailer [7639,7647]
trailer [7586,7594]
===
match
---
atom_expr [23041,23051]
atom_expr [22988,22998]
===
match
---
operator: = [5386,5387]
operator: = [5333,5334]
===
match
---
atom_expr [42308,42322]
atom_expr [41447,41461]
===
match
---
decorator [50471,50488]
decorator [49610,49627]
===
match
---
if_stmt [47655,47855]
if_stmt [46794,46994]
===
match
---
name: job_id [24857,24863]
name: job_id [24804,24810]
===
match
---
operator: = [37337,37338]
operator: = [36541,36542]
===
match
---
simple_stmt [789,805]
simple_stmt [789,805]
===
match
---
trailer [49006,49115]
trailer [48145,48254]
===
match
---
arglist [28823,28862]
arglist [28770,28809]
===
match
---
name: dag [40968,40971]
name: dag [40107,40110]
===
match
---
trailer [15891,15896]
trailer [15838,15843]
===
match
---
trailer [27082,27084]
trailer [27029,27031]
===
match
---
simple_stmt [10907,11088]
simple_stmt [10854,11035]
===
match
---
name: key [13210,13213]
name: key [13157,13160]
===
match
---
suite [6185,6271]
suite [6132,6218]
===
match
---
trailer [42213,42217]
trailer [41352,41356]
===
match
---
trailer [43167,43191]
trailer [42306,42330]
===
match
---
import_as_names [2274,2305]
import_as_names [2221,2252]
===
match
---
trailer [50818,50906]
trailer [49957,50045]
===
match
---
atom_expr [14224,14455]
atom_expr [14171,14402]
===
match
---
return_stmt [43291,43299]
return_stmt [42430,42438]
===
match
---
name: DagRun [35986,35992]
name: DagRun [35211,35217]
===
match
---
suite [49298,49455]
suite [48437,48594]
===
match
---
name: __get_concurrency_maps [7799,7821]
name: __get_concurrency_maps [7746,7768]
===
match
---
trailer [35263,35270]
trailer [34488,34495]
===
match
---
trailer [10284,10292]
trailer [10231,10239]
===
match
---
operator: , [17944,17945]
operator: , [17891,17892]
===
match
---
operator: = [9624,9625]
operator: = [9571,9572]
===
match
---
trailer [5988,6000]
trailer [5935,5947]
===
match
---
simple_stmt [20592,20626]
simple_stmt [20539,20573]
===
match
---
name: state [10401,10406]
name: state [10348,10353]
===
match
---
trailer [10400,10406]
trailer [10347,10353]
===
match
---
name: dag_model [38826,38835]
name: dag_model [38008,38017]
===
match
---
expr_stmt [32760,32818]
expr_stmt [32165,32223]
===
match
---
name: exception [25728,25737]
name: exception [25675,25684]
===
match
---
name: self [45119,45123]
name: self [44258,44262]
===
match
---
simple_stmt [13744,13780]
simple_stmt [13691,13727]
===
match
---
name: self [27686,27690]
name: self [27633,27637]
===
match
---
simple_stmt [41324,41365]
simple_stmt [40463,40504]
===
match
---
tfpdef [46390,46406]
tfpdef [45529,45545]
===
match
---
atom_expr [42255,42269]
atom_expr [41394,41408]
===
match
---
argument [38538,38556]
argument [37720,37738]
===
match
---
name: filter_for_tis [17591,17605]
name: filter_for_tis [17538,17552]
===
match
---
name: signum [6341,6347]
name: signum [6288,6294]
===
match
---
import_from [1602,1641]
import_from [1549,1588]
===
match
---
argument [11054,11069]
argument [11001,11016]
===
match
---
name: self [43205,43209]
name: self [42344,42348]
===
match
---
operator: = [44228,44229]
operator: = [43367,43368]
===
match
---
simple_stmt [33079,33094]
simple_stmt [32304,32319]
===
match
---
name: stats [10721,10726]
name: stats [10668,10673]
===
match
---
simple_stmt [43469,43567]
simple_stmt [42608,42706]
===
match
---
trailer [9948,9971]
trailer [9895,9918]
===
match
---
funcdef [41414,43942]
funcdef [40553,43081]
===
match
---
comparison [10522,10549]
comparison [10469,10496]
===
match
---
arglist [48451,48517]
arglist [47590,47656]
===
match
---
name: settings [31745,31753]
name: settings [31692,31700]
===
match
---
trailer [40802,40864]
trailer [39941,40003]
===
match
---
name: dag_id [36297,36303]
name: dag_id [35522,35528]
===
match
---
trailer [22373,22378]
trailer [22320,22325]
===
match
---
name: ti [49283,49285]
name: ti [48422,48424]
===
match
---
simple_stmt [17052,17120]
simple_stmt [16999,17067]
===
match
---
name: int [20579,20582]
name: int [20526,20529]
===
match
---
trailer [49347,49357]
trailer [48486,48496]
===
match
---
sync_comp_for [36877,36897]
sync_comp_for [36102,36122]
===
match
---
trailer [48450,48518]
trailer [47589,47657]
===
match
---
trailer [40788,40792]
trailer [39931,39935]
===
match
---
atom [7606,7768]
atom [7553,7715]
===
match
---
trailer [24485,24520]
trailer [24432,24467]
===
match
---
atom_expr [28765,28791]
atom_expr [28712,28738]
===
match
---
annassign [8660,8714]
annassign [8607,8661]
===
match
---
string: " scheduler loops" [29853,29871]
string: " scheduler loops" [29800,29818]
===
match
---
name: pool_slots [16885,16895]
name: pool_slots [16832,16842]
===
match
---
simple_stmt [41381,41409]
simple_stmt [40520,40548]
===
match
---
name: pool_name [10696,10705]
name: pool_name [10643,10652]
===
match
---
arglist [41775,41806]
arglist [40914,40945]
===
match
---
simple_stmt [31788,31834]
simple_stmt [31735,31781]
===
match
---
simple_stmt [12765,12774]
simple_stmt [12712,12721]
===
match
---
trailer [5018,5039]
trailer [4965,4986]
===
match
---
name: task_instance [15726,15739]
name: task_instance [15673,15686]
===
match
---
import_from [2487,2529]
import_from [2434,2476]
===
match
---
name: query [17662,17667]
name: query [17609,17614]
===
match
---
operator: , [21393,21394]
operator: , [21340,21341]
===
match
---
name: processor_agent [26031,26046]
name: processor_agent [25978,25993]
===
match
---
name: session [34024,34031]
name: session [33249,33256]
===
match
---
trailer [37608,37620]
trailer [36790,36802]
===
match
---
name: in_ [42357,42360]
name: in_ [41496,41499]
===
match
---
suite [45135,45711]
suite [44274,44850]
===
match
---
operator: , [27657,27658]
operator: , [27604,27605]
===
match
---
trailer [32782,32800]
trailer [32187,32205]
===
match
---
atom_expr [5589,5620]
atom_expr [5536,5567]
===
match
---
trailer [17278,17284]
trailer [17225,17231]
===
match
---
name: session [49054,49061]
name: session [48193,48200]
===
match
---
name: executor [49158,49166]
name: executor [48297,48305]
===
match
---
trailer [36296,36303]
trailer [35521,35528]
===
match
---
name: models [1286,1292]
name: models [1286,1292]
===
match
---
trailer [6867,6869]
trailer [6814,6816]
===
match
---
trailer [17057,17063]
trailer [17004,17010]
===
match
---
name: total_queued [37170,37182]
name: total_queued [36395,36407]
===
match
---
operator: , [6812,6813]
operator: , [6759,6760]
===
match
---
import_from [1875,1906]
import_from [1822,1853]
===
match
---
operator: , [45963,45964]
operator: , [45102,45103]
===
match
---
name: _run_scheduler_loop [26230,26249]
name: _run_scheduler_loop [26177,26196]
===
match
---
name: conf [27607,27611]
name: conf [27554,27558]
===
match
---
name: event_buffer [21750,21762]
name: event_buffer [21697,21709]
===
match
---
operator: = [2578,2579]
operator: = [2525,2526]
===
match
---
name: active_runs_of_dags [39326,39345]
name: active_runs_of_dags [38508,38527]
===
match
---
name: self [28093,28097]
name: self [28040,28044]
===
match
---
simple_stmt [9817,9888]
simple_stmt [9764,9835]
===
match
---
funcdef [4306,5727]
funcdef [4253,5674]
===
match
---
trailer [48474,48480]
trailer [47613,47619]
===
match
---
operator: , [9840,9841]
operator: , [9787,9788]
===
match
---
name: next_event [28752,28762]
name: next_event [28699,28709]
===
match
---
trailer [11344,11350]
trailer [11291,11297]
===
match
---
name: msg [22839,22842]
name: msg [22786,22789]
===
match
---
name: flush [50322,50327]
name: flush [49461,49466]
===
match
---
atom_expr [42110,42141]
atom_expr [41249,41280]
===
match
---
name: incr [22557,22561]
name: incr [22504,22508]
===
match
---
atom_expr [16988,17008]
atom_expr [16935,16955]
===
match
---
operator: , [46041,46042]
operator: , [45180,45181]
===
match
---
exprlist [13332,13360]
exprlist [13279,13307]
===
match
---
name: repr [17377,17381]
name: repr [17324,17328]
===
match
---
name: dag_hash [44257,44265]
name: dag_hash [43396,43404]
===
match
---
try_stmt [6625,6742]
try_stmt [6572,6689]
===
match
---
operator: = [39258,39259]
operator: = [38440,38441]
===
match
---
arglist [17285,17334]
arglist [17232,17281]
===
match
---
operator: , [35165,35166]
operator: , [34390,34391]
===
match
---
trailer [49430,49447]
trailer [48569,48586]
===
match
---
name: dag_id [44525,44531]
name: dag_id [43664,43670]
===
match
---
trailer [45589,45605]
trailer [44728,44744]
===
match
---
atom_expr [10410,10428]
atom_expr [10357,10375]
===
match
---
atom [47479,47527]
atom [46618,46666]
===
match
---
expr_stmt [44422,44455]
expr_stmt [43561,43594]
===
match
---
trailer [29394,29403]
trailer [29341,29350]
===
match
---
trailer [12811,12819]
trailer [12758,12766]
===
match
---
simple_stmt [8852,8888]
simple_stmt [8799,8835]
===
match
---
name: state [39671,39676]
name: state [38853,38858]
===
match
---
arglist [9839,9886]
arglist [9786,9833]
===
match
---
name: update [17695,17701]
name: update [17642,17648]
===
match
---
name: x [11522,11523]
name: x [11469,11470]
===
match
---
parameters [45118,45134]
parameters [44257,44273]
===
match
---
name: task_concurrency_map [16966,16986]
name: task_concurrency_map [16913,16933]
===
match
---
name: pool [16543,16547]
name: pool [16490,16494]
===
match
---
name: current_max_active_tasks_per_dag [14475,14507]
name: current_max_active_tasks_per_dag [14422,14454]
===
match
---
trailer [41845,41849]
trailer [40984,40988]
===
match
---
operator: = [37384,37385]
operator: = [36588,36589]
===
match
---
name: getint [4254,4260]
name: getint [4201,4207]
===
match
---
tfpdef [4617,4636]
tfpdef [4564,4583]
===
match
---
operator: , [6473,6474]
operator: , [6420,6421]
===
match
---
suite [25833,26221]
suite [25780,26168]
===
match
---
trailer [7707,7721]
trailer [7654,7668]
===
match
---
atom_expr [39348,39775]
atom_expr [38530,38957]
===
match
---
trailer [36681,36687]
trailer [35906,35912]
===
match
---
name: max_active_tasks_per_dag_limit [14134,14164]
name: max_active_tasks_per_dag_limit [14081,14111]
===
match
---
trailer [28101,28107]
trailer [28048,28054]
===
match
---
name: timer [33763,33768]
name: timer [32988,32993]
===
match
---
atom_expr [48447,48518]
atom_expr [47586,47657]
===
match
---
trailer [25579,25583]
trailer [25526,25530]
===
match
---
trailer [11615,11642]
trailer [11562,11589]
===
match
---
simple_stmt [2007,2091]
simple_stmt [1954,2038]
===
match
---
arglist [27024,27048]
arglist [26971,26995]
===
match
---
trailer [43120,43135]
trailer [42259,42274]
===
match
---
atom_expr [49911,50125]
atom_expr [49050,49264]
===
match
---
simple_stmt [41735,41808]
simple_stmt [40874,40947]
===
match
---
string: "next_method" [51136,51149]
string: "next_method" [50275,50288]
===
match
---
funcdef [46350,50466]
funcdef [45489,49605]
===
match
---
name: num_times_parse_dags [24640,24660]
name: num_times_parse_dags [24587,24607]
===
match
---
simple_stmt [44913,44937]
simple_stmt [44052,44076]
===
match
---
operator: } [39643,39644]
operator: } [38825,38826]
===
match
---
name: dag_run [44919,44926]
name: dag_run [44058,44065]
===
match
---
comparison [10747,10765]
comparison [10694,10712]
===
match
---
operator: = [27310,27311]
operator: = [27257,27258]
===
match
---
name: self [46841,46845]
name: self [45980,45984]
===
match
---
name: pools [45808,45813]
name: pools [44947,44952]
===
match
---
operator: = [34283,34284]
operator: = [33508,33509]
===
match
---
trailer [50327,50329]
trailer [49466,49468]
===
match
---
name: dag [41007,41010]
name: dag [40146,40149]
===
match
---
import_as_names [1171,1205]
import_as_names [1171,1205]
===
match
---
param [20551,20574]
param [20498,20521]
===
match
---
name: self [5426,5430]
name: self [5373,5377]
===
match
---
name: gauge [17279,17284]
name: gauge [17226,17231]
===
match
---
name: Pool [9598,9602]
name: Pool [9545,9549]
===
match
---
operator: , [8557,8558]
operator: , [8504,8505]
===
match
---
fstring [45933,45963]
fstring [45072,45102]
===
match
---
trailer [25723,25727]
trailer [25670,25674]
===
match
---
simple_stmt [5637,5727]
simple_stmt [5584,5674]
===
match
---
name: conf [46729,46733]
name: conf [45868,45872]
===
match
---
atom_expr [39425,39440]
atom_expr [38607,38622]
===
match
---
name: queued_by_job_id [49557,49573]
name: queued_by_job_id [48696,48712]
===
match
---
name: exception [37461,37470]
name: error [36647,36652]
===
match
---
name: start [27764,27769]
name: start [27711,27716]
===
match
---
name: task_instances [13194,13208]
name: task_instances [13141,13155]
===
match
---
name: pool [11857,11861]
name: pool [11804,11808]
===
match
---
name: os [6438,6440]
name: os [6385,6387]
===
match
---
name: queue [18700,18705]
name: queue [18647,18652]
===
match
---
operator: , [1248,1249]
operator: , [1248,1249]
===
match
---
atom_expr [5234,5243]
atom_expr [5181,5190]
===
match
---
name: RUNNING [39865,39872]
name: RUNNING [39047,39054]
===
match
---
testlist_comp [16988,17031]
testlist_comp [16935,16978]
===
match
---
operator: * [35933,35934]
operator: * [35158,35159]
===
match
---
name: provide_session [2290,2305]
name: provide_session [2237,2252]
===
match
---
name: self [6280,6284]
name: self [6227,6231]
===
match
---
operator: , [39693,39694]
operator: , [38875,38876]
===
match
---
name: TaskCallbackRequest [2071,2090]
name: TaskCallbackRequest [2018,2037]
===
match
---
name: datetime [20799,20807]
name: datetime [20746,20754]
===
match
---
param [6475,6482]
param [6422,6429]
===
match
---
name: query [10805,10810]
name: query [10752,10757]
===
match
---
operator: = [20841,20842]
operator: = [20788,20789]
===
match
---
expr_stmt [28303,28348]
expr_stmt [28250,28295]
===
match
---
name: settings [25639,25647]
name: settings [25586,25594]
===
match
---
name: dag [41183,41186]
name: dag [40322,40325]
===
match
---
atom_expr [8503,8523]
atom_expr [8450,8470]
===
match
---
atom [35934,36159]
atom [35159,35384]
===
match
---
name: all [36483,36486]
name: all [35708,35711]
===
match
---
name: dag_run [44491,44498]
name: dag_run [43630,43637]
===
match
---
name: is_unit_test [28967,28979]
name: is_unit_test [28914,28926]
===
match
---
simple_stmt [13137,13280]
simple_stmt [13084,13227]
===
match
---
trailer [21642,21650]
trailer [21589,21597]
===
match
---
name: task_id [48809,48816]
name: task_id [47948,47955]
===
match
---
trailer [6364,6380]
trailer [6311,6327]
===
match
---
simple_stmt [2531,2556]
simple_stmt [2478,2503]
===
match
---
argument [38578,38605]
argument [37760,37787]
===
match
---
simple_stmt [10805,10860]
simple_stmt [10752,10807]
===
match
---
name: self [16237,16241]
name: self [16184,16188]
===
match
---
arglist [49032,49093]
arglist [48171,48232]
===
match
---
trailer [8561,8568]
trailer [8508,8515]
===
match
---
atom_expr [21883,21891]
atom_expr [21830,21838]
===
match
---
atom_expr [28093,28168]
atom_expr [28040,28115]
===
match
---
atom_expr [17418,17504]
atom_expr [17365,17451]
===
match
---
name: ti_key [21380,21386]
name: ti_key [21327,21333]
===
match
---
trailer [6755,6759]
trailer [6702,6706]
===
match
---
trailer [9040,9044]
trailer [8987,8991]
===
match
---
operator: , [39423,39424]
operator: , [38605,38606]
===
match
---
name: dag_models [36131,36141]
name: dag_models [35356,35366]
===
match
---
operator: , [27300,27301]
operator: , [27247,27248]
===
match
---
name: List [9036,9040]
name: List [8983,8987]
===
match
---
trailer [35992,35999]
trailer [35217,35224]
===
match
---
comparison [44249,44283]
comparison [43388,43422]
===
match
---
atom_expr [22824,22870]
atom_expr [22771,22817]
===
match
---
trailer [5974,5982]
trailer [5921,5929]
===
match
---
trailer [50896,50903]
trailer [50035,50042]
===
match
---
expr_stmt [13744,13779]
expr_stmt [13691,13726]
===
match
---
trailer [6284,6288]
trailer [6231,6235]
===
match
---
expr_stmt [43469,43566]
expr_stmt [42608,42705]
===
match
---
string: 'scheduler_health_check_threshold' [7555,7589]
string: 'scheduler_health_check_threshold' [7502,7536]
===
match
---
parameters [34716,34760]
parameters [33941,33985]
===
match
---
trailer [20691,20726]
trailer [20638,20673]
===
match
---
name: ti_key [21643,21649]
name: ti_key [21590,21596]
===
match
---
simple_stmt [28370,28396]
simple_stmt [28317,28343]
===
match
---
atom_expr [35154,35165]
atom_expr [34379,34390]
===
match
---
trailer [21918,21934]
trailer [21865,21881]
===
match
---
trailer [25363,25379]
trailer [25310,25326]
===
match
---
atom_expr [45372,45454]
atom_expr [44511,44593]
===
match
---
trailer [12174,12244]
trailer [12121,12191]
===
match
---
expr_stmt [24843,24873]
expr_stmt [24790,24820]
===
match
---
name: count [8834,8839]
name: count [8781,8786]
===
match
---
name: load_op_links [5706,5719]
name: load_op_links [5653,5666]
===
match
---
operator: = [8413,8414]
operator: = [8360,8361]
===
match
---
tfpdef [6926,6959]
tfpdef [6873,6906]
===
match
---
atom_expr [37452,37534]
atom_expr [36638,36716]
===
match
---
parameters [39802,39829]
parameters [38984,39011]
===
match
---
atom_expr [27428,27503]
atom_expr [27375,27450]
===
match
---
name: self [47694,47698]
name: self [46833,46837]
===
match
---
simple_stmt [1683,1724]
simple_stmt [1630,1671]
===
match
---
trailer [48652,48665]
trailer [47791,47804]
===
match
---
and_test [24014,24082]
and_test [23961,24029]
===
match
---
testlist_comp [38314,38347]
testlist_comp [37496,37529]
===
match
---
trailer [5657,5726]
trailer [5604,5673]
===
match
---
operator: { [46029,46030]
operator: { [45168,45169]
===
match
---
argument [24784,24805]
argument [24731,24752]
===
match
---
simple_stmt [50735,51320]
simple_stmt [49874,50459]
===
match
---
expr_stmt [12787,12819]
expr_stmt [12734,12766]
===
match
---
name: timezone [47480,47488]
name: timezone [46619,46627]
===
match
---
atom_expr [36248,36269]
atom_expr [35473,35494]
===
match
---
operator: = [43354,43355]
operator: = [42493,42494]
===
match
---
decorated [34884,35273]
decorated [34109,34498]
===
match
---
atom_expr [24843,24863]
atom_expr [24790,24810]
===
match
---
trailer [6288,6293]
trailer [6235,6240]
===
match
---
expr_stmt [37572,37620]
expr_stmt [36754,36802]
===
match
---
name: timezone [7665,7673]
name: timezone [7612,7620]
===
match
---
arglist [36843,36947]
arglist [36068,36172]
===
match
---
number: 0 [33730,33731]
number: 0 [32955,32956]
===
match
---
name: adopt_or_reset_orphaned_tasks [46354,46383]
name: adopt_or_reset_orphaned_tasks [45493,45522]
===
match
---
name: Stats [27791,27796]
name: Stats [27738,27743]
===
match
---
simple_stmt [21615,21651]
simple_stmt [21562,21598]
===
match
---
trailer [38335,38347]
trailer [37517,37529]
===
match
---
name: task_concurrency_limit [15566,15588]
name: task_concurrency_limit [15513,15535]
===
match
---
arglist [35154,35174]
arglist [34379,34399]
===
match
---
operator: += [38844,38846]
operator: += [38026,38028]
===
match
---
atom_expr [33079,33093]
atom_expr [32304,32318]
===
match
---
operator: , [13081,13082]
operator: , [13028,13029]
===
match
---
operator: = [38762,38763]
operator: = [37944,37945]
===
match
---
name: str [21031,21034]
name: str [20978,20981]
===
match
---
atom_expr [50038,50051]
atom_expr [49177,49190]
===
match
---
trailer [21449,21456]
trailer [21396,21403]
===
match
---
atom_expr [22521,22533]
atom_expr [22468,22480]
===
match
---
operator: = [2559,2560]
operator: = [2506,2507]
===
match
---
name: has_task [15336,15344]
name: has_task [15283,15291]
===
match
---
fstring_start: f' [46109,46111]
fstring_start: f' [45248,45250]
===
match
---
simple_stmt [10679,10767]
simple_stmt [10626,10714]
===
match
---
operator: = [2534,2535]
operator: = [2481,2482]
===
match
---
name: state [23571,23576]
name: state [23518,23523]
===
match
---
operator: , [22846,22847]
operator: , [22793,22794]
===
match
---
name: dag_run [43049,43056]
name: dag_run [42188,42195]
===
match
---
trailer [20404,20446]
trailer [20351,20393]
===
match
---
atom_expr [45021,45076]
atom_expr [44160,44215]
===
match
---
name: prohibit_commit [31694,31709]
name: prohibit_commit [31641,31656]
===
match
---
trailer [25536,25538]
trailer [25483,25485]
===
match
---
name: dag_id [37527,37533]
name: dag_id [36709,36715]
===
match
---
not_test [43160,43191]
not_test [42299,42330]
===
match
---
atom_expr [27748,27772]
atom_expr [27695,27719]
===
match
---
operator: , [23781,23782]
operator: , [23728,23729]
===
match
---
name: dag_run [40936,40943]
name: dag_run [40075,40082]
===
match
---
trailer [25655,25662]
trailer [25602,25609]
===
match
---
trailer [41519,41539]
trailer [40658,40678]
===
match
---
string: "Marked %d SchedulerJob instances as failed" [47708,47752]
string: "Marked %d SchedulerJob instances as failed" [46847,46891]
===
match
---
name: send_callback_to_execute [45042,45066]
name: send_callback_to_execute [44181,44205]
===
match
---
name: DagRunType [48642,48652]
name: DagRunType [47781,47791]
===
match
---
tfpdef [4386,4399]
tfpdef [4333,4346]
===
match
---
trailer [34383,34434]
trailer [33608,33659]
===
match
---
operator: = [23497,23498]
operator: = [23444,23445]
===
match
---
trailer [22293,22300]
trailer [22240,22247]
===
match
---
dictorsetmaker [47588,47609]
dictorsetmaker [46727,46748]
===
match
---
tfpdef [35369,35385]
tfpdef [34594,34610]
===
match
---
name: dag_run [44378,44385]
name: dag_run [43517,43524]
===
match
---
expr_stmt [16591,16614]
expr_stmt [16538,16561]
===
match
---
name: gauge [17058,17063]
name: gauge [17005,17010]
===
match
---
name: run_with_db_retries [2220,2239]
name: run_with_db_retries [2167,2186]
===
match
---
trailer [36713,36961]
trailer [35938,36186]
===
match
---
name: self [45490,45494]
name: self [44629,44633]
===
match
---
name: state [48702,48707]
name: state [47841,47846]
===
match
---
atom_expr [11612,11642]
atom_expr [11559,11589]
===
match
---
trailer [6437,6447]
trailer [6384,6394]
===
match
---
name: dag_id [39618,39624]
name: dag_id [38800,38806]
===
match
---
atom_expr [17365,17409]
atom_expr [17312,17356]
===
match
---
trailer [47306,47320]
trailer [46445,46459]
===
match
---
name: processor_timeout [24692,24709]
name: processor_timeout [24639,24656]
===
match
---
atom_expr [7903,7966]
atom_expr [7850,7913]
===
match
---
name: len [49734,49737]
name: len [48873,48876]
===
match
---
trailer [37612,37619]
trailer [36794,36801]
===
match
---
operator: , [24612,24613]
operator: , [24559,24560]
===
match
---
name: TaskInstanceState [2469,2486]
name: TaskInstanceState [2416,2433]
===
match
---
trailer [39461,39708]
trailer [38643,38890]
===
match
---
name: dag [45450,45453]
name: dag [44589,44592]
===
match
---
name: data_interval [37634,37647]
name: data_interval [36816,36829]
===
match
---
atom_expr [38390,38789]
atom_expr [37572,37971]
===
match
---
expr_stmt [28752,28791]
expr_stmt [28699,28738]
===
match
---
trailer [13373,13405]
trailer [13320,13352]
===
match
---
atom [10232,10670]
atom [10179,10617]
===
match
---
name: ti [13221,13223]
name: ti [13168,13170]
===
match
---
atom_expr [43504,43566]
atom_expr [42643,42705]
===
match
---
name: task_instance [11764,11777]
name: task_instance [11711,11724]
===
match
---
trailer [23043,23051]
trailer [22990,22998]
===
match
---
operator: , [7835,7836]
operator: , [7782,7783]
===
match
---
trailer [25737,25798]
trailer [25684,25745]
===
match
---
name: eagerload [10315,10324]
name: eagerload [10262,10271]
===
match
---
name: dag_run [42651,42658]
name: dag_run [41790,41797]
===
match
---
arglist [36413,36449]
arglist [35638,35674]
===
match
---
trailer [47800,47854]
trailer [46939,46993]
===
match
---
atom_expr [49323,49357]
atom_expr [48462,48496]
===
match
---
name: settings [1294,1302]
name: settings [1294,1302]
===
match
---
operator: = [49151,49152]
operator: = [48290,48291]
===
match
---
string: "%s\n%s received, printing debug\n%s" [6765,6802]
string: "%s\n%s received, printing debug\n%s" [6712,6749]
===
match
---
name: queue_command [18840,18853]
name: queue_command [18787,18800]
===
match
---
trailer [20910,20927]
trailer [20857,20874]
===
match
---
suite [6381,6421]
suite [6328,6368]
===
match
---
name: task_id [21418,21425]
name: task_id [21365,21372]
===
match
---
operator: = [8625,8626]
operator: = [8572,8573]
===
match
---
name: self [29390,29394]
name: self [29337,29341]
===
match
---
argument [11011,11026]
argument [10958,10973]
===
match
---
comparison [2794,2849]
comparison [2741,2796]
===
match
---
trailer [35843,35848]
trailer [35068,35073]
===
match
---
operator: == [36060,36062]
operator: == [35285,35287]
===
match
---
simple_stmt [39249,39317]
simple_stmt [38431,38499]
===
match
---
trailer [22468,22479]
trailer [22415,22426]
===
match
---
operator: = [23747,23748]
operator: = [23694,23695]
===
match
---
name: self [23875,23879]
name: self [23822,23826]
===
match
---
operator: = [43502,43503]
operator: = [42641,42642]
===
match
---
name: queued_tis [20447,20457]
name: queued_tis [20394,20404]
===
match
---
name: session [11054,11061]
name: session [11001,11008]
===
match
---
suite [21598,21651]
suite [21545,21598]
===
match
---
name: loop_count [29940,29950]
name: loop_count [29887,29897]
===
match
---
operator: , [2370,2371]
operator: , [2317,2318]
===
match
---
annassign [10932,11087]
annassign [10879,11034]
===
match
---
operator: == [36931,36933]
operator: == [36156,36158]
===
match
---
operator: , [15724,15725]
operator: , [15671,15672]
===
match
---
operator: @ [43947,43948]
operator: @ [43086,43087]
===
match
---
atom_expr [36233,36246]
atom_expr [35458,35471]
===
match
---
atom_expr [41992,42010]
atom_expr [41131,41149]
===
match
---
name: self [20323,20327]
name: self [20270,20274]
===
match
---
operator: , [44731,44732]
operator: , [43870,43871]
===
match
---
operator: , [29345,29346]
operator: , [29292,29293]
===
match
---
trailer [40558,40565]
trailer [39740,39747]
===
match
---
atom_expr [42492,42505]
atom_expr [41631,41644]
===
match
---
name: stats [10747,10752]
name: stats [10694,10699]
===
match
---
operator: = [5244,5245]
operator: = [5191,5192]
===
match
---
operator: = [14010,14011]
operator: = [13957,13958]
===
match
---
name: tis_to_reset_or_adopt [49192,49213]
name: tis_to_reset_or_adopt [48331,48352]
===
match
---
name: str [4350,4353]
name: str [4297,4300]
===
match
---
comparison [7664,7758]
comparison [7611,7705]
===
match
---
name: pool [9863,9867]
name: pool [9810,9814]
===
match
---
operator: = [17363,17364]
operator: = [17310,17311]
===
match
---
string: "Exiting scheduler loop as requested DAG parse count (%d) has been reached after %d" [29748,29832]
string: "Exiting scheduler loop as requested DAG parse count (%d) has been reached after %d" [29695,29779]
===
match
---
string: "Processor agent is not started." [26944,26977]
string: "Processor agent is not started." [26891,26924]
===
match
---
name: commit [34610,34616]
name: commit [33835,33841]
===
match
---
atom_expr [23107,23170]
atom_expr [23054,23117]
===
match
---
name: terminate [25147,25156]
name: terminate [25094,25103]
===
match
---
trailer [17208,17214]
trailer [17155,17161]
===
match
---
trailer [23879,23883]
trailer [23826,23830]
===
match
---
simple_stmt [43011,43079]
simple_stmt [42150,42218]
===
match
---
operator: = [49254,49255]
operator: = [48393,48394]
===
match
---
trailer [10830,10858]
trailer [10777,10805]
===
match
---
operator: = [49448,49449]
operator: = [48587,48588]
===
match
---
operator: , [21567,21568]
operator: , [21514,21515]
===
match
---
trailer [5238,5243]
trailer [5185,5190]
===
match
---
name: Stats [17052,17057]
name: Stats [16999,17004]
===
match
---
name: timezone [43138,43146]
name: timezone [42277,42285]
===
match
---
name: dagbag [5642,5648]
name: dagbag [5589,5595]
===
match
---
operator: { [36866,36867]
operator: { [36091,36092]
===
match
---
operator: { [51068,51069]
operator: { [50207,50208]
===
match
---
name: session [9008,9015]
name: session [8955,8962]
===
match
---
dictorsetmaker [39615,39643]
dictorsetmaker [38797,38825]
===
match
---
operator: , [23158,23159]
operator: , [23105,23106]
===
match
---
operator: , [4438,4439]
operator: , [4385,4386]
===
match
---
name: dag [41992,41995]
name: dag [41131,41134]
===
match
---
operator: = [37183,37184]
operator: = [36408,36409]
===
match
---
atom_expr [46894,47120]
atom_expr [46033,46259]
===
match
---
operator: , [5330,5331]
operator: , [5277,5278]
===
match
---
name: dag [39939,39942]
name: dag [39121,39124]
===
match
---
name: dag [43164,43167]
name: dag [42303,42306]
===
match
---
simple_stmt [36507,36575]
simple_stmt [35732,35800]
===
match
---
trailer [39359,39775]
trailer [38541,38957]
===
match
---
string: "but there are %s open slots in the pool %s." [16347,16392]
string: "but there are %s open slots in the pool %s." [16294,16339]
===
match
---
param [46390,46413]
param [45529,45552]
===
match
---
trailer [45642,45710]
trailer [44781,44849]
===
match
---
name: fallback [27302,27310]
name: fallback [27249,27257]
===
match
---
name: dag [44913,44916]
name: dag [44052,44055]
===
match
---
arglist [45319,45336]
arglist [44458,44475]
===
match
---
name: not_ [1082,1086]
name: not_ [1082,1086]
===
match
---
atom_expr [16457,16481]
atom_expr [16404,16428]
===
match
---
trailer [17911,17913]
trailer [17858,17860]
===
match
---
trailer [5866,5883]
trailer [5813,5830]
===
match
---
string: "next_kwargs" [51183,51196]
string: "next_kwargs" [50322,50335]
===
match
---
name: dag_run [44011,44018]
name: dag_run [43150,43157]
===
match
---
trailer [7949,7959]
trailer [7896,7906]
===
match
---
simple_stmt [40366,40427]
simple_stmt [39548,39609]
===
match
---
name: SchedulerJob [47307,47319]
name: SchedulerJob [46446,46458]
===
match
---
name: timeout [47518,47525]
name: timeout [46657,46664]
===
match
---
simple_stmt [44422,44456]
simple_stmt [43561,43595]
===
match
---
name: state [7625,7630]
name: state [7572,7577]
===
match
---
trailer [22100,22104]
trailer [22047,22051]
===
match
---
trailer [31972,31980]
trailer [31919,31927]
===
match
---
simple_stmt [46894,47121]
simple_stmt [46033,46260]
===
match
---
trailer [27441,27503]
trailer [27388,27450]
===
match
---
name: execution_date [36255,36269]
name: execution_date [35480,35494]
===
match
---
atom_expr [20126,20148]
atom_expr [20073,20095]
===
match
---
atom_expr [12845,12864]
atom_expr [12792,12811]
===
match
---
operator: , [27487,27488]
operator: , [27434,27435]
===
match
---
name: DagRun [1717,1723]
name: DagRun [1664,1670]
===
match
---
atom_expr [20243,20301]
atom_expr [20190,20248]
===
match
---
name: to_reset [49767,49775]
name: to_reset [48906,48914]
===
match
---
suite [23703,23800]
suite [23650,23747]
===
match
---
number: 1 [17037,17038]
number: 1 [16984,16985]
===
match
---
name: filter [50812,50818]
name: filter [49951,49957]
===
match
---
trailer [37204,37222]
trailer [36429,36447]
===
match
---
atom_expr [38326,38347]
atom_expr [37508,37529]
===
match
---
name: task [23021,23025]
name: task [22968,22972]
===
match
---
trailer [23516,23520]
trailer [23463,23467]
===
match
---
trailer [17318,17334]
trailer [17265,17281]
===
match
---
name: dag_id [40701,40707]
name: dag_id [39862,39868]
===
match
---
name: run_type [38429,38437]
name: run_type [37611,37619]
===
match
---
trailer [41759,41766]
trailer [40898,40905]
===
match
---
name: incr [46290,46294]
name: incr [45429,45433]
===
match
---
name: session [23783,23790]
name: session [23730,23737]
===
match
---
operator: = [12609,12610]
operator: = [12556,12557]
===
match
---
name: self [34369,34373]
name: self [33594,33598]
===
match
---
name: datetime [20790,20798]
name: datetime [20737,20745]
===
match
---
name: _exit_gracefully [5928,5944]
name: _exit_gracefully [5875,5891]
===
match
---
atom_expr [5171,5204]
atom_expr [5118,5151]
===
match
---
name: State [2462,2467]
name: State [2409,2414]
===
match
---
atom_expr [37609,37619]
atom_expr [36791,36801]
===
match
---
try_stmt [33488,34591]
try_stmt [32713,33816]
===
match
---
atom_expr [21195,21209]
atom_expr [21142,21156]
===
match
---
dotted_name [1211,1233]
dotted_name [1211,1233]
===
match
---
operator: , [18804,18805]
operator: , [18751,18752]
===
match
---
name: session [45766,45773]
name: session [44905,44912]
===
match
---
name: ti [49480,49482]
name: ti [48619,48621]
===
match
---
for_stmt [18012,18069]
for_stmt [17959,18016]
===
match
---
simple_stmt [34560,34569]
simple_stmt [33785,33794]
===
match
---
operator: , [51276,51277]
operator: , [50415,50416]
===
match
---
funcdef [43968,44676]
funcdef [43107,43815]
===
match
---
operator: = [44555,44556]
operator: = [43694,43695]
===
match
---
trailer [25662,25664]
trailer [25609,25611]
===
match
---
name: task_instance [16826,16839]
name: task_instance [16773,16786]
===
match
---
name: gauge [46003,46008]
name: gauge [45142,45147]
===
match
---
suite [49529,49584]
suite [48668,48723]
===
match
---
trailer [5597,5620]
trailer [5544,5567]
===
match
---
name: getint [7535,7541]
name: getint [7482,7488]
===
match
---
name: starved_pools [10679,10692]
name: starved_pools [10626,10639]
===
match
---
string: 'scheduler' [27442,27453]
string: 'scheduler' [27389,27400]
===
match
---
operator: , [49037,49038]
operator: , [48176,48177]
===
match
---
raise_stmt [44852,44903]
raise_stmt [43991,44042]
===
match
---
annassign [5307,5359]
annassign [5254,5306]
===
match
---
operator: { [39614,39615]
operator: { [38796,38797]
===
match
---
atom_expr [22970,23000]
atom_expr [22917,22947]
===
match
---
trailer [12583,12585]
trailer [12530,12532]
===
match
---
term [6892,6900]
term [6839,6847]
===
match
---
name: airflow [1607,1614]
name: airflow [1554,1561]
===
match
---
decorated [43947,44676]
decorated [43086,43815]
===
match
---
atom_expr [6506,6526]
atom_expr [6453,6473]
===
match
---
not_test [28984,29002]
not_test [28931,28949]
===
match
---
parameters [46235,46266]
parameters [45374,45405]
===
match
---
name: filter [17672,17678]
name: filter [17619,17625]
===
match
---
not_test [41820,41827]
not_test [40959,40966]
===
match
---
name: attempt_number [47051,47065]
name: attempt_number [46190,46204]
===
match
---
name: group_by [36975,36983]
name: group_by [36200,36208]
===
match
---
trailer [42535,42550]
trailer [41674,41689]
===
match
---
trailer [48794,48828]
trailer [47933,47967]
===
match
---
name: msg [22615,22618]
name: msg [22562,22565]
===
match
---
name: ti [18788,18790]
name: ti [18735,18737]
===
match
---
name: state [10525,10530]
name: state [10472,10477]
===
match
---
name: start_date [40468,40478]
name: start_date [39650,39660]
===
match
---
expr_stmt [40653,40725]
expr_stmt [39814,39886]
===
match
---
trailer [24925,24942]
trailer [24872,24889]
===
match
---
atom_expr [43255,43277]
atom_expr [42394,42416]
===
match
---
name: executor_class [24038,24052]
name: executor_class [23985,23999]
===
match
---
simple_stmt [25126,25159]
simple_stmt [25073,25106]
===
match
---
name: timers [28765,28771]
name: timers [28712,28718]
===
match
---
atom_expr [8466,8481]
atom_expr [8413,8428]
===
match
---
name: log [49916,49919]
name: log [49055,49058]
===
match
---
string: "Exception when executing DagFileProcessorAgent.end" [26118,26170]
string: "Exception when executing DagFileProcessorAgent.end" [26065,26117]
===
match
---
name: start [33830,33835]
name: start [33055,33060]
===
match
---
arglist [12188,12234]
arglist [12135,12181]
===
match
---
name: dag [41749,41752]
name: dag [40888,40891]
===
match
---
operator: = [11732,11733]
operator: = [11679,11680]
===
match
---
operator: , [2400,2401]
operator: , [2347,2348]
===
match
---
trailer [44822,44838]
trailer [43961,43977]
===
match
---
operator: , [43362,43363]
operator: , [42501,42502]
===
match
---
atom_expr [41344,41358]
atom_expr [40483,40497]
===
match
---
atom_expr [14563,14901]
atom_expr [14510,14848]
===
match
---
operator: % [23752,23753]
operator: % [23699,23700]
===
match
---
trailer [50398,50407]
trailer [49537,49546]
===
match
---
number: 1 [16663,16664]
number: 1 [16610,16611]
===
match
---
simple_stmt [34770,34817]
simple_stmt [33995,34042]
===
match
---
suite [2623,2850]
suite [2570,2797]
===
match
---
name: State [39294,39299]
name: State [38476,38481]
===
match
---
trailer [46108,46170]
trailer [45247,45309]
===
match
---
simple_stmt [49142,49215]
simple_stmt [48281,48354]
===
match
---
name: repr [11510,11514]
name: repr [11457,11461]
===
match
---
suite [11807,11885]
suite [11754,11832]
===
match
---
atom_expr [34369,34434]
atom_expr [33594,33659]
===
match
---
name: int [7926,7929]
name: int [7873,7876]
===
match
---
return_stmt [23809,23833]
return_stmt [23756,23780]
===
match
---
name: BACKFILL_JOB [48653,48665]
name: BACKFILL_JOB [47792,47804]
===
match
---
except_clause [6689,6705]
except_clause [6636,6652]
===
match
---
dotted_name [2012,2043]
dotted_name [1959,1990]
===
match
---
name: to_reset [49289,49297]
name: to_reset [48428,48436]
===
match
---
name: executor_loader [1483,1498]
name: executor_loader [1430,1445]
===
match
---
name: TI [48818,48820]
name: TI [47957,47959]
===
match
---
name: DagRun [39664,39670]
name: DagRun [38846,38852]
===
match
---
number: 80 [6898,6900]
number: 80 [6845,6847]
===
match
---
atom_expr [37650,37687]
atom_expr [36832,36869]
===
match
---
trailer [49076,49093]
trailer [48215,48232]
===
match
---
simple_stmt [9984,10006]
simple_stmt [9931,9953]
===
match
---
atom_expr [46054,46066]
atom_expr [45193,45205]
===
match
---
simple_stmt [28877,28947]
simple_stmt [28824,28894]
===
match
---
atom_expr [38438,38458]
atom_expr [37620,37640]
===
match
---
name: execute_start_time [25508,25526]
name: execute_start_time [25455,25473]
===
match
---
atom_expr [45585,45710]
atom_expr [44724,44849]
===
match
---
atom [8861,8878]
atom [8808,8825]
===
match
---
name: filter_for_tis [17611,17625]
name: filter_for_tis [17558,17572]
===
match
---
param [23852,23856]
param [23799,23803]
===
match
---
operator: , [13108,13109]
operator: , [13055,13056]
===
match
---
operator: = [20568,20569]
operator: = [20515,20516]
===
match
---
and_test [7620,7758]
and_test [7567,7705]
===
match
---
atom_expr [28480,28526]
atom_expr [28427,28473]
===
match
---
string: 'scheduler' [5525,5536]
string: 'scheduler' [5472,5483]
===
match
---
import_as_names [1241,1264]
import_as_names [1241,1264]
===
match
---
suite [27853,28232]
suite [27800,28179]
===
match
---
trailer [35848,35856]
trailer [35073,35081]
===
match
---
arglist [49954,50099]
arglist [49093,49238]
===
match
---
trailer [48586,48593]
trailer [47725,47732]
===
match
---
expr_stmt [26987,27049]
expr_stmt [26934,26996]
===
match
---
expr_stmt [15626,15774]
expr_stmt [15573,15721]
===
match
---
param [44011,44027]
param [43150,43166]
===
match
---
trailer [5140,5150]
trailer [5087,5097]
===
match
---
trailer [17001,17008]
trailer [16948,16955]
===
match
---
name: log [22829,22832]
name: log [22776,22779]
===
match
---
name: to_reset [50042,50050]
name: to_reset [49181,49189]
===
match
---
atom_expr [32778,32818]
atom_expr [32183,32223]
===
match
---
trailer [48029,48062]
trailer [47168,47201]
===
match
---
suite [6629,6681]
suite [6576,6628]
===
match
---
operator: , [2196,2197]
operator: , [2143,2144]
===
match
---
trailer [41782,41789]
trailer [40921,40928]
===
match
---
atom_expr [24338,24355]
atom_expr [24285,24302]
===
match
---
trailer [40666,40670]
trailer [39827,39831]
===
match
---
trailer [41058,41289]
trailer [40197,40428]
===
match
---
operator: = [4737,4738]
operator: = [4684,4685]
===
match
---
trailer [24037,24052]
trailer [23984,23999]
===
match
---
trailer [49580,49583]
trailer [48719,48722]
===
match
---
name: session [7870,7877]
name: session [7817,7824]
===
match
---
string: "open" [12812,12818]
string: "open" [12759,12765]
===
match
---
name: List [21883,21887]
name: List [21830,21834]
===
match
---
string: "Not executing %s since the task concurrency for" [15930,15979]
string: "Not executing %s since the task concurrency for" [15877,15926]
===
match
---
simple_stmt [24000,24083]
simple_stmt [23947,24030]
===
match
---
name: TI [42295,42297]
name: TI [41434,41436]
===
match
---
name: self [29670,29674]
name: self [29617,29621]
===
match
---
trailer [28209,28229]
trailer [28156,28176]
===
match
---
name: not_ [10826,10830]
name: not_ [10773,10777]
===
match
---
atom [42182,42393]
atom [41321,41532]
===
match
---
name: log [46899,46902]
name: log [46038,46041]
===
match
---
name: queued_by_job_id [48454,48470]
name: queued_by_job_id [47593,47609]
===
match
---
operator: = [5668,5669]
operator: = [5615,5616]
===
match
---
expr_stmt [33953,34032]
expr_stmt [33178,33257]
===
match
---
name: get_event_buffer [20857,20873]
name: get_event_buffer [20804,20820]
===
match
---
name: models [1615,1621]
name: models [1562,1568]
===
match
---
trailer [45351,45357]
trailer [44490,44496]
===
match
---
name: filter_for_tis [21919,21933]
name: filter_for_tis [21866,21880]
===
match
---
trailer [25421,25425]
trailer [25368,25372]
===
match
---
atom_expr [18172,18180]
atom_expr [18119,18127]
===
match
---
name: List [1024,1028]
name: List [1024,1028]
===
match
---
expr_stmt [47876,47925]
expr_stmt [47015,47064]
===
match
---
suite [6527,6616]
suite [6474,6563]
===
match
---
name: calculate_dagrun_date_fields [38871,38899]
name: calculate_dagrun_date_fields [38053,38081]
===
match
---
atom_expr [6843,6869]
atom_expr [6790,6816]
===
match
---
name: gauge [46103,46108]
name: gauge [45242,45247]
===
match
---
simple_stmt [43205,43279]
simple_stmt [42344,42418]
===
match
---
operator: = [24474,24475]
operator: = [24421,24422]
===
match
---
atom_expr [14012,14032]
atom_expr [13959,13979]
===
match
---
name: DefaultDict [12056,12067]
name: DefaultDict [12003,12014]
===
match
---
name: session [34521,34528]
name: session [33746,33753]
===
match
---
name: Optional [5589,5597]
name: Optional [5536,5544]
===
match
---
name: dm [36867,36869]
name: dm [36092,36094]
===
match
---
name: callback_to_run [32872,32887]
name: callback_to_run [32273,32288]
===
match
---
trailer [44256,44265]
trailer [43395,43404]
===
match
---
trailer [49398,49403]
trailer [48537,48542]
===
match
---
name: log [12671,12674]
name: log [12618,12621]
===
match
---
atom_expr [13247,13264]
atom_expr [13194,13211]
===
match
---
suite [51351,51453]
suite [50490,50592]
===
match
---
simple_stmt [15883,16121]
simple_stmt [15830,16068]
===
match
---
atom_expr [21213,21230]
atom_expr [21160,21177]
===
match
---
name: dm [36003,36005]
name: dm [35228,35230]
===
match
---
expr_stmt [39249,39316]
expr_stmt [38431,38498]
===
match
---
name: pool [9846,9850]
name: pool [9793,9797]
===
match
---
atom_expr [5637,5648]
atom_expr [5584,5595]
===
match
---
name: rollback [34529,34537]
name: rollback [33754,33762]
===
match
---
operator: != [48501,48503]
operator: != [47640,47642]
===
match
---
trailer [8673,8695]
trailer [8620,8642]
===
match
---
name: dag_id [8862,8868]
name: dag_id [8809,8815]
===
match
---
trailer [14190,14207]
trailer [14137,14154]
===
match
---
name: self [5567,5571]
name: self [5514,5518]
===
match
---
name: pool_name [46131,46140]
name: pool_name [45270,45279]
===
match
---
atom_expr [36662,36675]
atom_expr [35887,35900]
===
match
---
number: 0 [13440,13441]
number: 0 [13387,13388]
===
match
---
arglist [25452,25538]
arglist [25399,25485]
===
match
---
operator: = [12194,12195]
operator: = [12141,12142]
===
match
---
simple_stmt [837,860]
simple_stmt [837,860]
===
match
---
string: "Not scheduling since there are %s open slots in pool %s" [13477,13534]
string: "Not scheduling since there are %s open slots in pool %s" [13424,13481]
===
match
---
atom_expr [8386,8412]
atom_expr [8333,8359]
===
match
---
name: str [7921,7924]
name: str [7868,7871]
===
match
---
operator: = [41798,41799]
operator: = [40937,40938]
===
match
---
trailer [15518,15541]
trailer [15465,15488]
===
match
---
name: airflow [2422,2429]
name: airflow [2369,2376]
===
match
---
name: tis_with_right_state [21705,21725]
name: tis_with_right_state [21652,21672]
===
match
---
atom_expr [48818,48827]
atom_expr [47957,47966]
===
match
---
trailer [15896,16120]
trailer [15843,16067]
===
match
---
atom_expr [51364,51452]
atom_expr [50503,50591]
===
match
---
name: state [23164,23169]
name: state [23111,23116]
===
match
---
annassign [24390,24447]
annassign [24337,24394]
===
match
---
atom [24731,24733]
atom [24678,24680]
===
match
---
atom_expr [28544,28576]
atom_expr [28491,28523]
===
match
---
expr_stmt [49836,49886]
expr_stmt [48975,49025]
===
match
---
name: is_alive [6911,6919]
name: is_alive [6858,6866]
===
match
---
name: skip_locked [49065,49076]
name: skip_locked [48204,48215]
===
match
---
trailer [29721,29726]
trailer [29668,29673]
===
match
---
argument [18951,18962]
argument [18898,18909]
===
match
---
name: ti_primary_key_to_try_number_map [21162,21194]
name: ti_primary_key_to_try_number_map [21109,21141]
===
match
---
annassign [21881,21975]
annassign [21828,21922]
===
match
---
atom_expr [50391,50409]
atom_expr [49530,49548]
===
match
---
atom_expr [8455,8464]
atom_expr [8402,8411]
===
match
---
trailer [22556,22561]
trailer [22503,22508]
===
match
---
suite [46851,50436]
suite [45990,49575]
===
match
---
operator: = [6728,6729]
operator: = [6675,6676]
===
match
---
trailer [7673,7680]
trailer [7620,7627]
===
match
---
operator: == [2833,2835]
operator: == [2780,2782]
===
match
---
suite [7356,7482]
suite [7303,7429]
===
match
---
import_name [884,894]
import_name [884,894]
===
match
---
name: dag_max_active_tasks_map [12098,12122]
name: dag_max_active_tasks_map [12045,12069]
===
match
---
name: int [30034,30037]
name: int [29981,29984]
===
match
---
name: conf [27428,27432]
name: conf [27375,27379]
===
match
---
name: session [28340,28347]
name: session [28287,28294]
===
match
---
simple_stmt [45021,45077]
simple_stmt [44160,44216]
===
match
---
atom_expr [42128,42140]
atom_expr [41267,41279]
===
match
---
operator: = [42700,42701]
operator: = [41839,41840]
===
match
---
name: query [36656,36661]
name: query [35881,35886]
===
match
---
name: is_alive [7438,7446]
name: is_alive [7385,7393]
===
match
---
trailer [25583,25605]
trailer [25530,25552]
===
match
---
name: send [34279,34283]
name: send [33504,33508]
===
match
---
string: "Executor full, skipping critical section" [33659,33701]
string: "Executor full, skipping critical section" [32884,32926]
===
match
---
operator: , [33220,33221]
operator: , [32445,32446]
===
match
---
if_stmt [6357,6421]
if_stmt [6304,6368]
===
match
---
trailer [8822,8830]
trailer [8769,8777]
===
match
---
name: startswith [5454,5464]
name: startswith [5401,5411]
===
match
---
atom_expr [41755,41807]
atom_expr [40894,40946]
===
match
---
name: conf [27242,27246]
name: conf [27189,27193]
===
match
---
arglist [5658,5725]
arglist [5605,5672]
===
match
---
operator: -> [5759,5761]
operator: -> [5706,5708]
===
match
---
trailer [8390,8412]
trailer [8337,8359]
===
match
---
name: num_ready [12833,12842]
name: num_ready [12780,12789]
===
match
---
comparison [43113,43155]
comparison [42252,42294]
===
match
---
atom_expr [39906,39923]
atom_expr [39088,39105]
===
match
---
simple_stmt [16635,16665]
simple_stmt [16582,16612]
===
match
---
param [30016,30021]
param [29963,29968]
===
match
---
name: processor_poll_interval [4488,4511]
name: processor_poll_interval [4435,4458]
===
match
---
trailer [28564,28574]
trailer [28511,28521]
===
match
---
atom_expr [28931,28945]
atom_expr [28878,28892]
===
match
---
simple_stmt [35077,35124]
simple_stmt [34302,34349]
===
match
---
name: is_ [48471,48474]
name: is_ [47610,47613]
===
match
---
suite [42453,42551]
suite [41592,41690]
===
match
---
trailer [28885,28891]
trailer [28832,28838]
===
match
---
param [34723,34742]
param [33948,33967]
===
match
---
atom_expr [27154,27190]
atom_expr [27101,27137]
===
match
---
name: len [20474,20477]
name: len [20421,20424]
===
match
---
trailer [45256,45267]
trailer [44395,44406]
===
match
---
operator: == [22518,22520]
operator: == [22465,22467]
===
match
---
atom_expr [40936,40950]
atom_expr [40075,40089]
===
match
---
atom_expr [49652,49665]
atom_expr [48791,48804]
===
match
---
arglist [27607,27710]
arglist [27554,27657]
===
match
---
trailer [11856,11861]
trailer [11803,11808]
===
match
---
name: ti [23517,23519]
name: ti [23464,23466]
===
match
---
name: MAX_DB_RETRIES [47087,47101]
name: MAX_DB_RETRIES [46226,46240]
===
match
---
arglist [32801,32817]
arglist [32206,32222]
===
match
---
operator: , [4425,4426]
operator: , [4372,4373]
===
match
---
name: log [40789,40792]
name: log [39932,39935]
===
match
---
atom_expr [23290,23312]
atom_expr [23237,23259]
===
match
---
name: DagRun [44020,44026]
name: DagRun [43159,43165]
===
match
---
dotted_name [1149,1163]
dotted_name [1149,1163]
===
match
---
trailer [8709,8714]
trailer [8656,8661]
===
match
---
operator: } [45961,45962]
operator: } [45100,45101]
===
match
---
operator: , [50855,50856]
operator: , [49994,49995]
===
match
---
expr_stmt [37333,37393]
expr_stmt [36537,36597]
===
match
---
trailer [37604,37608]
trailer [36786,36790]
===
match
---
simple_stmt [28416,28438]
simple_stmt [28363,28385]
===
match
---
comparison [38313,38372]
comparison [37495,37554]
===
match
---
name: subdir [4342,4348]
name: subdir [4289,4295]
===
match
---
string: 'open' [9851,9857]
string: 'open' [9798,9804]
===
match
---
arglist [15930,16090]
arglist [15877,16037]
===
match
---
return_stmt [11402,11423]
return_stmt [11349,11370]
===
match
---
operator: , [16042,16043]
operator: , [15989,15990]
===
match
---
name: session [20374,20381]
name: session [20321,20328]
===
match
---
if_stmt [40965,41409]
if_stmt [40104,40548]
===
match
---
simple_stmt [25867,25887]
simple_stmt [25814,25834]
===
match
---
operator: = [22342,22343]
operator: = [22289,22290]
===
match
---
name: self [25359,25363]
name: self [25306,25310]
===
match
---
name: dependencies_states [1928,1947]
name: dependencies_states [1875,1894]
===
match
---
return_stmt [34825,34878]
return_stmt [34050,34103]
===
match
---
atom_expr [48992,49121]
atom_expr [48131,48260]
===
match
---
atom_expr [24958,24986]
atom_expr [24905,24933]
===
match
---
name: session [34743,34750]
name: session [33968,33975]
===
match
---
string: 'scheduler.tasks.killed_externally' [22562,22597]
string: 'scheduler.tasks.killed_externally' [22509,22544]
===
match
---
trailer [22981,22989]
trailer [22928,22936]
===
match
---
argument [12188,12217]
argument [12135,12164]
===
match
---
name: _send_sla_callbacks_to_processor [44950,44982]
name: _send_sla_callbacks_to_processor [44089,44121]
===
match
---
arglist [13477,13552]
arglist [13424,13499]
===
match
---
name: data_interval [38578,38591]
name: data_interval [37760,37773]
===
match
---
name: airflow [1647,1654]
name: airflow [1594,1601]
===
match
---
trailer [49191,49214]
trailer [48330,48353]
===
match
---
trailer [28435,28437]
trailer [28382,28384]
===
match
---
operator: = [36224,36225]
operator: = [35449,35450]
===
match
---
suite [42097,43101]
suite [41236,42240]
===
match
---
atom_expr [12147,12244]
atom_expr [12094,12191]
===
match
---
trailer [42133,42140]
trailer [41272,41279]
===
match
---
name: items [45900,45905]
name: items [45039,45044]
===
match
---
name: slot_stats [46043,46053]
name: slot_stats [45182,45192]
===
match
---
trailer [36412,36450]
trailer [35637,35675]
===
match
---
trailer [40677,40684]
trailer [39838,39845]
===
match
---
trailer [28775,28791]
trailer [28722,28738]
===
match
---
name: execution_date [43121,43135]
name: execution_date [42260,42274]
===
match
---
trailer [40943,40950]
trailer [40082,40089]
===
match
---
subscriptlist [7944,7964]
subscriptlist [7891,7911]
===
match
---
trailer [27802,27804]
trailer [27749,27751]
===
match
---
suite [44284,44413]
suite [43423,43552]
===
match
---
trailer [8537,8546]
trailer [8484,8493]
===
match
---
simple_stmt [6985,7316]
simple_stmt [6932,7263]
===
match
---
name: conf [5315,5319]
name: conf [5262,5266]
===
match
---
expr_stmt [16912,16949]
expr_stmt [16859,16896]
===
match
---
atom_expr [36648,37017]
atom_expr [35873,36242]
===
match
---
for_stmt [11760,11885]
for_stmt [11707,11832]
===
match
---
simple_stmt [16966,17039]
simple_stmt [16913,16986]
===
match
---
operator: = [34344,34345]
operator: = [33569,33570]
===
match
---
argument [20374,20389]
argument [20321,20336]
===
match
---
name: values [9877,9883]
name: values [9824,9830]
===
match
---
name: session [11019,11026]
name: session [10966,10973]
===
match
---
name: grace_multiplier [6926,6942]
name: grace_multiplier [6873,6889]
===
match
---
trailer [10314,10337]
trailer [10261,10284]
===
match
---
name: _send_dag_callbacks_to_processor [44685,44717]
name: _send_dag_callbacks_to_processor [43824,43856]
===
match
---
operator: = [20241,20242]
operator: = [20188,20189]
===
match
---
name: self [46649,46653]
name: self [45788,45792]
===
match
---
name: dag_run [48553,48560]
name: dag_run [47692,47699]
===
match
---
simple_stmt [49836,49887]
simple_stmt [48975,49026]
===
match
---
operator: , [1292,1293]
operator: , [1292,1293]
===
match
---
name: int [4396,4399]
name: int [4343,4346]
===
match
---
atom_expr [31895,31909]
atom_expr [31842,31856]
===
match
---
operator: , [21425,21426]
operator: , [21372,21373]
===
match
---
trailer [5927,5944]
trailer [5874,5891]
===
match
---
name: self [20545,20549]
name: self [20492,20496]
===
match
---
atom_expr [49763,49776]
atom_expr [48902,48915]
===
match
---
name: synchronize_session [17962,17981]
name: synchronize_session [17909,17928]
===
match
---
expr_stmt [21162,21230]
expr_stmt [21109,21177]
===
match
---
operator: , [40567,40568]
operator: , [39749,39750]
===
match
---
name: state [23759,23764]
name: state [23706,23711]
===
match
---
simple_stmt [33953,34033]
simple_stmt [33178,33258]
===
match
---
string: """Get Next DagRuns to Examine with retries""" [34770,34816]
string: """Get Next DagRuns to Examine with retries""" [33995,34041]
===
match
---
argument [42816,42837]
argument [41955,41976]
===
match
---
trailer [5913,5921]
trailer [5860,5868]
===
match
---
trailer [5351,5357]
trailer [5298,5304]
===
match
---
param [8988,8993]
param [8935,8940]
===
match
---
arglist [43220,43277]
arglist [42359,42416]
===
match
---
name: signum [6734,6740]
name: signum [6681,6687]
===
match
---
trailer [39604,39608]
trailer [38786,38790]
===
match
---
string: 'scheduler' [4261,4272]
string: 'scheduler' [4208,4219]
===
match
---
name: Optional [6944,6952]
name: Optional [6891,6899]
===
match
---
operator: , [13208,13209]
operator: , [13155,13156]
===
match
---
trailer [48716,48724]
trailer [47855,47863]
===
match
---
name: dag_run [44733,44740]
name: dag_run [43872,43879]
===
match
---
name: log [34374,34377]
name: log [33599,33602]
===
match
---
trailer [31937,31966]
trailer [31884,31913]
===
match
---
name: schedulable_tis [43884,43899]
name: schedulable_tis [43023,43038]
===
match
---
dotted_name [1607,1625]
dotted_name [1554,1572]
===
match
---
simple_stmt [16591,16615]
simple_stmt [16538,16562]
===
match
---
operator: , [4574,4575]
operator: , [4521,4522]
===
match
---
argument [24674,24709]
argument [24621,24656]
===
match
---
trailer [6182,6184]
trailer [6129,6131]
===
match
---
operator: = [42874,42875]
operator: = [42013,42014]
===
match
---
name: task_id [8550,8557]
name: task_id [8497,8504]
===
match
---
operator: , [34741,34742]
operator: , [33966,33967]
===
match
---
trailer [15673,15774]
trailer [15620,15721]
===
match
---
atom_expr [43164,43191]
atom_expr [42303,42330]
===
match
---
name: max_tis [20167,20174]
name: max_tis [20114,20121]
===
match
---
expr_stmt [22964,23000]
expr_stmt [22911,22947]
===
match
---
name: getfloat [4526,4534]
name: getfloat [4473,4481]
===
match
---
name: dag [38314,38317]
name: dag [37496,37499]
===
match
---
name: DagBag [5651,5657]
name: DagBag [5598,5604]
===
match
---
atom_expr [42027,42045]
atom_expr [41166,41184]
===
match
---
atom [20817,20819]
atom [20764,20766]
===
match
---
name: async_mode [24795,24805]
name: async_mode [24742,24752]
===
match
---
operator: += [16945,16947]
operator: += [16892,16894]
===
match
---
name: timetable [39943,39952]
name: timetable [39125,39134]
===
match
---
simple_stmt [14134,14208]
simple_stmt [14081,14155]
===
match
---
trailer [21248,21252]
trailer [21195,21199]
===
match
---
name: error [22833,22838]
name: error [22780,22785]
===
match
---
atom_expr [15345,15366]
atom_expr [15292,15313]
===
match
---
except_clause [50346,50369]
except_clause [49485,49508]
===
match
---
operator: , [36303,36304]
operator: , [35528,35529]
===
match
---
name: int [8691,8694]
name: int [8638,8641]
===
match
---
name: dm [36881,36883]
name: dm [36106,36108]
===
match
---
operator: , [6924,6925]
operator: , [6871,6872]
===
match
---
name: itertools [27748,27757]
name: itertools [27695,27704]
===
match
---
name: adopt_or_reset_orphaned_tasks [27159,27188]
name: adopt_or_reset_orphaned_tasks [27106,27135]
===
match
---
suite [18499,18978]
suite [18446,18925]
===
match
---
name: func [36677,36681]
name: func [35902,35906]
===
match
---
trailer [37676,37687]
trailer [36858,36869]
===
match
---
name: processor_agent [6365,6380]
name: processor_agent [6312,6327]
===
match
---
operator: , [43253,43254]
operator: , [42392,42393]
===
match
---
name: execute_start_time [25000,25018]
name: execute_start_time [24947,24965]
===
match
---
trailer [45041,45066]
trailer [44180,44205]
===
match
---
name: active_runs_of_dags [41324,41343]
name: active_runs_of_dags [40463,40482]
===
match
---
name: incr [47796,47800]
name: incr [46935,46939]
===
match
---
name: logging [829,836]
name: logging [829,836]
===
match
---
name: dag_run [42635,42642]
name: dag_run [41774,41781]
===
match
---
simple_stmt [42680,42928]
simple_stmt [41819,42067]
===
match
---
import_from [1100,1143]
import_from [1100,1143]
===
match
---
term [23748,23781]
term [23695,23728]
===
match
---
atom_expr [45490,45510]
atom_expr [44629,44649]
===
match
---
name: TI [21908,21910]
name: TI [21855,21857]
===
match
---
name: subdir [4707,4713]
name: subdir [4654,4660]
===
match
---
operator: { [17855,17856]
operator: { [17802,17803]
===
match
---
name: self [34717,34721]
name: self [33942,33946]
===
match
---
trailer [33516,33525]
trailer [32741,32750]
===
match
---
trailer [27894,27918]
trailer [27841,27865]
===
match
---
trailer [11570,11575]
trailer [11517,11522]
===
match
---
trailer [46053,46067]
trailer [45192,45206]
===
match
---
name: State [50841,50846]
name: State [49980,49985]
===
match
---
name: SCHEDULED [51105,51114]
name: SCHEDULED [50244,50253]
===
match
---
trailer [48552,48560]
trailer [47691,47699]
===
match
---
name: filter [48587,48593]
name: filter [47726,47732]
===
match
---
name: total_seconds [7708,7721]
name: total_seconds [7655,7668]
===
match
---
suite [13406,17039]
suite [13353,16986]
===
match
---
if_stmt [29667,29992]
if_stmt [29614,29939]
===
match
---
name: SerializedDagNotFound [40745,40766]
name: dag [39906,39909]
===
match
---
trailer [9942,9948]
trailer [9889,9895]
===
match
---
name: on_retry_callback [23295,23312]
name: on_retry_callback [23242,23259]
===
match
---
if_stmt [16175,16787]
if_stmt [16122,16734]
===
match
---
simple_stmt [27874,27921]
simple_stmt [27821,27868]
===
match
---
name: session [20382,20389]
name: session [20329,20336]
===
match
---
trailer [43219,43278]
trailer [42358,42417]
===
match
---
simple_stmt [18199,18434]
simple_stmt [18146,18381]
===
match
---
suite [6490,6902]
suite [6437,6849]
===
match
---
name: self [44727,44731]
name: self [43866,43870]
===
match
---
name: dag_run [42027,42034]
name: dag_run [41166,41173]
===
match
---
expr_stmt [2575,2595]
expr_stmt [2522,2542]
===
match
---
operator: , [2218,2219]
operator: , [2165,2166]
===
match
---
raise_stmt [45524,45575]
raise_stmt [44663,44714]
===
match
---
atom [49256,49258]
atom [48395,48397]
===
match
---
simple_stmt [1571,1602]
simple_stmt [1518,1549]
===
match
---
operator: , [18568,18569]
operator: , [18515,18516]
===
match
---
name: self [44297,44301]
name: self [43436,43440]
===
match
---
suite [41540,43942]
suite [40679,43081]
===
match
---
suite [23341,23682]
suite [23288,23629]
===
match
---
expr_stmt [24000,24082]
expr_stmt [23947,24029]
===
match
---
operator: = [28478,28479]
operator: = [28425,28426]
===
match
---
operator: = [10811,10812]
operator: = [10758,10759]
===
match
---
trailer [25076,25078]
trailer [25023,25025]
===
match
---
atom_expr [44858,44903]
atom_expr [43997,44042]
===
match
---
trailer [47409,47417]
trailer [46548,46556]
===
match
---
operator: = [5313,5314]
operator: = [5260,5261]
===
match
---
operator: = [22022,22023]
operator: = [21969,21970]
===
match
---
name: self [27517,27521]
name: self [27464,27468]
===
match
---
string: 'scheduler.orphaned_tasks.cleared' [49616,49650]
string: 'scheduler.orphaned_tasks.cleared' [48755,48789]
===
match
---
arglist [13194,13265]
arglist [13141,13212]
===
match
---
atom_expr [48623,48638]
atom_expr [47762,47777]
===
match
---
name: result [8796,8802]
name: result [8743,8749]
===
match
---
atom_expr [33757,33807]
atom_expr [32982,33032]
===
match
---
simple_stmt [13656,13724]
simple_stmt [13603,13671]
===
match
---
name: types [2506,2511]
name: types [2453,2458]
===
match
---
name: ValueError [45530,45540]
name: ValueError [44669,44679]
===
match
---
atom_expr [6438,6446]
atom_expr [6385,6393]
===
match
---
argument [34339,34346]
argument [33564,33571]
===
match
---
sync_comp_for [9859,9885]
sync_comp_for [9806,9832]
===
match
---
operator: = [24332,24333]
operator: = [24279,24280]
===
match
---
name: ti [49554,49556]
name: ti [48693,48695]
===
match
---
operator: @ [7774,7775]
operator: @ [7721,7722]
===
match
---
param [34743,34759]
param [33968,33984]
===
match
---
operator: , [21362,21363]
operator: , [21309,21310]
===
match
---
trailer [12577,12583]
trailer [12524,12530]
===
match
---
operator: = [11018,11019]
operator: = [10965,10966]
===
match
---
operator: , [37515,37516]
operator: , [36697,36698]
===
match
---
trailer [28771,28775]
trailer [28718,28722]
===
match
---
atom_expr [10025,10054]
atom_expr [9972,10001]
===
match
---
name: only_if_necessary [28664,28681]
name: only_if_necessary [28611,28628]
===
match
---
trailer [34373,34377]
trailer [33598,33602]
===
match
---
trailer [39416,39423]
trailer [38598,38605]
===
match
---
name: self [37583,37587]
name: self [36765,36769]
===
match
---
name: info [12886,12890]
name: info [12833,12837]
===
match
---
trailer [34460,34465]
trailer [33685,33690]
===
match
---
atom_expr [25052,25078]
atom_expr [24999,25025]
===
match
---
name: _is_parent_process [2602,2620]
name: _is_parent_process [2549,2567]
===
match
---
name: _emit_pool_metrics [27691,27709]
name: _emit_pool_metrics [27638,27656]
===
match
---
name: DagRun [36233,36239]
name: DagRun [35458,35464]
===
match
---
atom_expr [49687,49777]
atom_expr [48826,48916]
===
match
---
operator: * [6828,6829]
operator: * [6775,6776]
===
match
---
atom_expr [42295,42304]
atom_expr [41434,41443]
===
match
---
number: 0 [34567,34568]
number: 0 [33792,33793]
===
match
---
decorator [34658,34680]
decorator [33883,33905]
===
match
---
name: task_instances_to_examine [11527,11552]
name: task_instances_to_examine [11474,11499]
===
match
---
trailer [10383,10396]
trailer [10330,10343]
===
match
---
atom_expr [20990,21010]
atom_expr [20937,20957]
===
match
---
argument [17962,17987]
argument [17909,17934]
===
match
---
name: dag_hash [44430,44438]
name: dag_hash [43569,43577]
===
match
---
arglist [6765,6832]
arglist [6712,6779]
===
match
---
suite [19059,20490]
suite [19006,20437]
===
match
---
name: task_concurrency_limit [15831,15853]
name: task_concurrency_limit [15778,15800]
===
match
---
operator: = [18595,18596]
operator: = [18542,18543]
===
match
---
name: all_files_processed [25380,25399]
name: all_files_processed [25327,25346]
===
match
---
name: session [49077,49084]
name: session [48216,48223]
===
match
---
name: TI [17668,17670]
name: TI [17615,17617]
===
match
---
name: dag_directory [24587,24600]
name: dag_directory [24534,24547]
===
match
---
trailer [15272,15297]
trailer [15219,15244]
===
match
---
name: int [7524,7527]
name: int [7471,7474]
===
match
---
name: self [20400,20404]
name: self [20347,20351]
===
match
---
trailer [29690,29695]
trailer [29637,29642]
===
match
---
atom_expr [37359,37375]
atom_expr [36563,36579]
===
match
---
argument [45683,45700]
argument [44822,44839]
===
match
---
name: session [10246,10253]
name: session [10193,10200]
===
match
---
trailer [46845,46849]
trailer [45984,45988]
===
match
---
name: create_dagrun [38394,38407]
name: create_dagrun [37576,37589]
===
match
---
trailer [28193,28209]
trailer [28140,28156]
===
match
---
operator: , [13546,13547]
operator: , [13493,13494]
===
match
---
name: Exception [26072,26081]
name: Exception [26019,26028]
===
match
---
trailer [27246,27255]
trailer [27193,27202]
===
match
---
expr_stmt [24456,24520]
expr_stmt [24403,24467]
===
match
---
simple_stmt [31922,31991]
simple_stmt [31869,31938]
===
match
---
name: tis_with_right_state [21848,21868]
name: tis_with_right_state [21795,21815]
===
match
---
simple_stmt [17654,18003]
simple_stmt [17601,17950]
===
match
---
name: DefaultDict [1005,1016]
name: DefaultDict [1005,1016]
===
match
---
trailer [29674,29690]
trailer [29621,29637]
===
match
---
arglist [10621,10659]
arglist [10568,10606]
===
match
---
trailer [15739,15747]
trailer [15686,15694]
===
match
---
name: executor [25872,25880]
name: executor [25819,25827]
===
match
---
operator: , [28929,28930]
operator: , [28876,28877]
===
match
---
simple_stmt [12254,12280]
simple_stmt [12201,12227]
===
match
---
name: _log [5239,5243]
name: _log [5186,5190]
===
match
---
if_stmt [20123,20302]
if_stmt [20070,20249]
===
match
---
arglist [17855,17988]
arglist [17802,17935]
===
match
---
name: remove [25656,25662]
name: remove [25603,25609]
===
match
---
expr_stmt [23021,23052]
expr_stmt [22968,22999]
===
match
---
simple_stmt [27154,27191]
simple_stmt [27101,27138]
===
match
---
if_stmt [6499,6616]
if_stmt [6446,6563]
===
match
---
trailer [24402,24409]
trailer [24349,24356]
===
match
---
name: buffer_key [22085,22095]
name: buffer_key [22032,22042]
===
match
---
expr_stmt [9583,9647]
expr_stmt [9530,9594]
===
match
---
suite [22943,23053]
suite [22890,23000]
===
match
---
trailer [17904,17911]
trailer [17851,17858]
===
match
---
atom_expr [41741,41752]
atom_expr [40880,40891]
===
match
---
trailer [12848,12864]
trailer [12795,12811]
===
match
---
expr_stmt [8364,8585]
expr_stmt [8311,8532]
===
match
---
trailer [47050,47065]
trailer [46189,46204]
===
match
---
trailer [28339,28348]
trailer [28286,28295]
===
match
---
name: TI [49042,49044]
name: TI [48181,48183]
===
match
---
annassign [9376,9391]
annassign [9323,9338]
===
match
---
argument [9631,9646]
argument [9578,9593]
===
match
---
name: self [46894,46898]
name: self [46033,46037]
===
match
---
string: 'sqlite' [5408,5416]
string: 'sqlite' [5355,5363]
===
match
---
name: self [39260,39264]
name: self [38442,38446]
===
match
---
name: num_failed [47754,47764]
name: num_failed [46893,46903]
===
match
---
name: airflow [2311,2318]
name: airflow [2258,2265]
===
match
---
atom_expr [26026,26052]
atom_expr [25973,25999]
===
match
---
trailer [23888,23914]
trailer [23835,23861]
===
match
---
atom_expr [33512,33541]
atom_expr [32737,32766]
===
match
---
name: processor_poll_interval [5103,5126]
name: processor_poll_interval [5050,5073]
===
match
---
name: ti [22855,22857]
name: ti [22802,22804]
===
match
---
trailer [42056,42063]
trailer [41195,41202]
===
match
---
name: heartbeat [28384,28393]
name: heartbeat [28331,28340]
===
match
---
trailer [15035,15063]
trailer [14982,15010]
===
match
---
trailer [34537,34539]
trailer [33762,33764]
===
match
---
operator: = [5511,5512]
operator: = [5458,5459]
===
match
---
trailer [36865,36899]
trailer [36090,36124]
===
match
---
name: TI [48550,48552]
name: TI [47689,47691]
===
match
---
atom_expr [10826,10858]
atom_expr [10773,10805]
===
match
---
operator: , [19032,19033]
operator: , [18979,18980]
===
match
---
simple_stmt [46097,46187]
simple_stmt [45236,45326]
===
match
---
trailer [42360,42378]
trailer [41499,41517]
===
match
---
simple_stmt [21878,21976]
simple_stmt [21825,21923]
===
match
---
trailer [15025,15035]
trailer [14972,14982]
===
match
---
suite [33547,33732]
suite [32772,32957]
===
match
---
trailer [47698,47702]
trailer [46837,46841]
===
match
---
parameters [8987,9032]
parameters [8934,8979]
===
match
---
name: self [27154,27158]
name: self [27101,27105]
===
match
---
operator: , [14878,14879]
operator: , [14825,14826]
===
match
---
name: Session [45775,45782]
name: Session [44914,44921]
===
match
---
simple_stmt [12666,12749]
simple_stmt [12613,12696]
===
match
---
trailer [35856,35861]
trailer [35081,35086]
===
match
---
atom_expr [14972,14985]
atom_expr [14919,14932]
===
match
---
trailer [47151,47212]
trailer [46290,46351]
===
match
---
operator: + [47833,47834]
operator: + [46972,46973]
===
match
---
operator: , [8683,8684]
operator: , [8630,8631]
===
match
---
arglist [39294,39315]
arglist [38476,38497]
===
match
---
operator: = [10230,10231]
operator: = [10177,10178]
===
match
---
operator: = [40716,40717]
operator: = [39877,39878]
===
match
---
operator: , [37375,37376]
operator: , [36579,36580]
===
match
---
return_stmt [50445,50465]
return_stmt [49584,49604]
===
match
---
name: dag [41395,41398]
name: dag [40534,40537]
===
match
---
factor [10621,10640]
factor [10568,10587]
===
match
---
name: state [38538,38543]
name: state [37720,37725]
===
match
---
simple_stmt [974,1046]
simple_stmt [974,1046]
===
match
---
name: TaskInstanceKey [20911,20926]
name: TaskInstanceKey [20858,20873]
===
match
---
name: sqlalchemy [1149,1159]
name: sqlalchemy [1149,1159]
===
match
---
name: commit [35264,35270]
name: commit [34489,34495]
===
match
---
param [4448,4479]
param [4395,4426]
===
match
---
name: session [33421,33428]
name: session [32646,32653]
===
match
---
operator: = [36526,36527]
operator: = [35751,35752]
===
match
---
expr_stmt [20884,20932]
expr_stmt [20831,20879]
===
match
---
simple_stmt [895,907]
simple_stmt [895,907]
===
match
---
name: tis_with_right_state [21615,21635]
name: tis_with_right_state [21562,21582]
===
match
---
trailer [33974,34015]
trailer [33199,33240]
===
match
---
name: dagbag [37588,37594]
name: dagbag [36770,36776]
===
match
---
name: active_runs [40992,41003]
name: active_runs [40131,40142]
===
match
---
trailer [47702,47707]
trailer [46841,46846]
===
match
---
operator: ** [5195,5197]
operator: ** [5142,5144]
===
match
---
name: is_unit_test [26987,26999]
name: is_unit_test [26934,26946]
===
match
---
name: getfloat [27433,27441]
name: getfloat [27380,27388]
===
match
---
operator: { [17086,17087]
operator: { [17033,17034]
===
match
---
atom_expr [26099,26171]
atom_expr [26046,26118]
===
match
---
operator: , [39142,39143]
operator: , [38324,38325]
===
match
---
name: with_row_locks [48992,49006]
name: with_row_locks [48131,48145]
===
match
---
name: heartbeat [28654,28663]
name: heartbeat [28601,28610]
===
match
---
operator: = [12843,12844]
operator: = [12790,12791]
===
match
---
name: self [33970,33974]
name: self [33195,33199]
===
match
---
trailer [8445,8453]
trailer [8392,8400]
===
match
---
trailer [7943,7965]
trailer [7890,7912]
===
match
---
atom [47587,47610]
atom [46726,46749]
===
match
---
arglist [45933,45983]
arglist [45072,45122]
===
match
---
simple_stmt [22964,23001]
simple_stmt [22911,22948]
===
match
---
atom_expr [27331,27365]
atom_expr [27278,27312]
===
match
---
name: dag_runs [39249,39257]
name: dag_runs [38431,38439]
===
match
---
simple_stmt [37452,37535]
simple_stmt [36638,36717]
===
match
---
dotted_name [1729,1758]
dotted_name [1676,1705]
===
match
---
name: open_slots [13536,13546]
name: open_slots [13483,13493]
===
match
---
expr_stmt [20310,20390]
expr_stmt [20257,20337]
===
match
---
operator: } [17096,17097]
operator: } [17043,17044]
===
match
---
parameters [4318,4683]
parameters [4265,4630]
===
match
---
operator: = [38716,38717]
operator: = [37898,37899]
===
match
---
trailer [47394,47400]
trailer [46533,46539]
===
match
---
name: executable_tis [11409,11423]
name: executable_tis [11356,11370]
===
match
---
trailer [4253,4260]
trailer [4200,4207]
===
match
---
simple_stmt [11336,11390]
simple_stmt [11283,11337]
===
match
---
name: session [43364,43371]
name: session [42503,42510]
===
match
---
param [6926,6966]
param [6873,6913]
===
match
---
argument [45656,45681]
argument [44795,44820]
===
match
---
try_stmt [22939,23240]
try_stmt [22886,23187]
===
match
---
name: DagRun [39731,39737]
name: DagRun [38913,38919]
===
match
---
string: "Running SchedulerJob.adopt_or_reset_orphaned_tasks with retries. Try %d of %d" [46930,47009]
string: "Running SchedulerJob.adopt_or_reset_orphaned_tasks with retries. Try %d of %d" [46069,46148]
===
match
---
tfpdef [41484,41500]
tfpdef [40623,40639]
===
match
---
trailer [22561,22598]
trailer [22508,22545]
===
match
---
funcdef [26226,29992]
funcdef [26173,29939]
===
match
---
name: state [23561,23566]
name: state [23508,23513]
===
match
---
name: DagFileProcessorAgent [24552,24573]
name: DagFileProcessorAgent [24499,24520]
===
match
---
atom_expr [29301,29359]
atom_expr [29248,29306]
===
match
---
simple_stmt [1144,1206]
simple_stmt [1144,1206]
===
match
---
argument [23477,23520]
argument [23424,23467]
===
match
---
name: DefaultDict [8603,8614]
name: DefaultDict [8550,8561]
===
match
---
name: self [28480,28484]
name: self [28427,28431]
===
match
---
trailer [29726,29969]
trailer [29673,29916]
===
match
---
name: set [49515,49518]
name: set [48654,48657]
===
match
---
param [5753,5757]
param [5700,5704]
===
match
---
import_from [2240,2305]
import_from [2187,2252]
===
match
---
trailer [47509,47526]
trailer [46648,46665]
===
match
---
suite [39830,40585]
suite [39012,39767]
===
match
---
param [35329,35334]
param [34554,34559]
===
match
---
trailer [26117,26171]
trailer [26064,26118]
===
match
---
expr_stmt [16966,17038]
expr_stmt [16913,16985]
===
match
---
suite [5767,6002]
suite [5714,5949]
===
match
---
atom_expr [5954,6001]
atom_expr [5901,5948]
===
match
---
trailer [7689,7706]
trailer [7636,7653]
===
match
---
name: options [21935,21942]
name: options [21882,21889]
===
match
---
name: __class__ [47806,47815]
name: __class__ [46945,46954]
===
match
---
arglist [8443,8481]
arglist [8390,8428]
===
match
---
simple_stmt [39166,39241]
simple_stmt [38348,38423]
===
match
---
trailer [47824,47830]
trailer [46963,46969]
===
match
---
name: airflow [1308,1315]
name: airflow [1308,1315]
===
match
---
atom_expr [27008,27049]
atom_expr [26955,26996]
===
match
---
operator: += [17034,17036]
operator: += [16981,16983]
===
match
---
arglist [4414,4437]
arglist [4361,4384]
===
match
---
argument [42897,42912]
argument [42036,42051]
===
match
---
comparison [22466,22504]
comparison [22413,22451]
===
match
---
return_stmt [34631,34652]
return_stmt [33856,33877]
===
match
---
import_from [1144,1205]
import_from [1144,1205]
===
match
---
arglist [27256,27316]
arglist [27203,27263]
===
match
---
atom_expr [7909,7930]
atom_expr [7856,7877]
===
match
---
atom_expr [46144,46169]
atom_expr [45283,45308]
===
match
---
name: DagBag [1676,1682]
name: DagBag [1623,1629]
===
match
---
simple_stmt [2148,2240]
simple_stmt [2095,2187]
===
match
---
decorated [8926,18099]
decorated [8873,18046]
===
match
---
simple_stmt [1907,1972]
simple_stmt [1854,1919]
===
match
---
name: join [48545,48549]
name: join [47684,47688]
===
match
---
name: settings [4356,4364]
name: settings [4303,4311]
===
match
---
name: starved_pools [10778,10791]
name: starved_pools [10725,10738]
===
match
---
name: pool_to_task_instances [11672,11694]
name: pool_to_task_instances [11619,11641]
===
match
---
name: self [23852,23856]
name: self [23799,23803]
===
match
---
operator: , [2387,2388]
operator: , [2334,2335]
===
match
---
argument [9846,9885]
argument [9793,9832]
===
match
---
number: 1 [16948,16949]
number: 1 [16895,16896]
===
match
---
trailer [27012,27023]
trailer [26959,26970]
===
match
---
simple_stmt [45524,45576]
simple_stmt [44663,44715]
===
match
---
simple_stmt [40784,40865]
simple_stmt [39927,40004]
===
match
---
trailer [25727,25737]
trailer [25674,25684]
===
match
---
operator: = [28763,28764]
operator: = [28710,28711]
===
match
---
name: log [45377,45380]
name: log [44516,44519]
===
match
---
trailer [18598,18608]
trailer [18545,18555]
===
match
---
argument [27764,27771]
argument [27711,27718]
===
match
---
arglist [43525,43565]
arglist [42664,42704]
===
match
---
annassign [14970,14992]
annassign [14917,14939]
===
match
---
for_stmt [13328,17039]
for_stmt [13275,16986]
===
match
---
name: session [44028,44035]
name: session [43167,43174]
===
match
---
trailer [6891,6901]
trailer [6838,6848]
===
match
---
simple_stmt [16912,16950]
simple_stmt [16859,16897]
===
match
---
arglist [51378,51451]
arglist [50517,50590]
===
match
---
name: Logger [4630,4636]
name: Logger [4577,4583]
===
match
---
operator: >= [37251,37253]
operator: >= [36476,36478]
===
match
---
operator: = [43371,43372]
operator: = [42510,42511]
===
match
---
atom_expr [47911,47924]
atom_expr [47050,47063]
===
match
---
atom_expr [33421,33442]
atom_expr [32646,32667]
===
match
---
expr_stmt [45808,45856]
expr_stmt [44947,44995]
===
match
---
arglist [20247,20300]
arglist [20194,20247]
===
match
---
simple_stmt [6642,6681]
simple_stmt [6589,6628]
===
match
---
trailer [36661,36693]
trailer [35886,35918]
===
match
---
simple_stmt [1529,1571]
simple_stmt [1476,1518]
===
match
---
name: run_id [42831,42837]
name: run_id [41970,41976]
===
match
---
operator: - [7683,7684]
operator: - [7630,7631]
===
match
---
if_stmt [5214,5250]
if_stmt [5161,5197]
===
match
---
trailer [20798,20807]
trailer [20745,20754]
===
match
---
name: load_only [1182,1191]
name: load_only [1182,1191]
===
match
---
name: pool [12631,12635]
name: pool [12578,12582]
===
match
---
name: loop_count [27734,27744]
name: loop_count [27681,27691]
===
match
---
trailer [7721,7723]
trailer [7668,7670]
===
match
---
trailer [10752,10760]
trailer [10699,10707]
===
match
---
trailer [46898,46902]
trailer [46037,46041]
===
match
---
if_stmt [15009,16158]
if_stmt [14956,16105]
===
match
---
operator: = [6651,6652]
operator: = [6598,6599]
===
match
---
name: pool_name [10710,10719]
name: pool_name [10657,10666]
===
match
---
trailer [43524,43566]
trailer [42663,42705]
===
match
---
arith_expr [7665,7706]
arith_expr [7612,7653]
===
match
---
simple_stmt [33274,33338]
simple_stmt [32499,32563]
===
match
---
name: signal [5907,5913]
name: signal [5854,5860]
===
match
---
suite [8758,8888]
suite [8705,8835]
===
match
---
name: TI [48030,48032]
name: TI [47169,47171]
===
match
---
atom_expr [4723,4736]
atom_expr [4670,4683]
===
match
---
simple_stmt [34825,34879]
simple_stmt [34050,34104]
===
match
---
name: BaseJob [1563,1570]
name: BaseJob [1510,1517]
===
match
---
atom_expr [34521,34539]
atom_expr [33746,33764]
===
match
---
name: filter [39455,39461]
name: filter [38637,38643]
===
match
---
trailer [42642,42649]
trailer [41781,41788]
===
match
---
name: exception [26108,26117]
name: exception [26055,26064]
===
match
---
trailer [48820,48827]
trailer [47959,47966]
===
match
---
operator: = [24864,24865]
operator: = [24811,24812]
===
match
---
name: execute_start_time [25606,25624]
name: execute_start_time [25553,25571]
===
match
---
name: TI [8547,8549]
name: TI [8494,8496]
===
match
---
operator: > [29404,29405]
operator: > [29351,29352]
===
match
---
argument [15281,15296]
argument [15228,15243]
===
match
---
trailer [11504,11509]
trailer [11451,11456]
===
match
---
name: latest_version [44145,44159]
name: latest_version [43284,43298]
===
match
---
operator: } [40565,40566]
operator: } [39747,39748]
===
match
---
operator: = [10994,10995]
operator: = [10941,10942]
===
match
---
name: schedule_delay [40569,40583]
name: schedule_delay [39751,39765]
===
match
---
name: query [10224,10229]
name: query [10171,10176]
===
match
---
arglist [17064,17118]
arglist [17011,17065]
===
match
---
name: session [34870,34877]
name: session [34095,34102]
===
match
---
arglist [46009,46067]
arglist [45148,45206]
===
match
---
number: 0 [13314,13315]
number: 0 [13261,13262]
===
match
---
trailer [34273,34278]
trailer [33498,33503]
===
match
---
name: pool [12531,12535]
name: pool [12478,12482]
===
match
---
trailer [16986,17033]
trailer [16933,16980]
===
match
---
name: UNPICKLEABLE_EXECUTORS [1506,1528]
name: UNPICKLEABLE_EXECUTORS [1453,1475]
===
match
---
operator: , [46316,46317]
operator: , [45455,45456]
===
match
---
atom_expr [10325,10335]
atom_expr [10272,10282]
===
match
---
name: State [21584,21589]
name: State [21531,21536]
===
match
---
name: dag_id [14816,14822]
name: dag_id [14763,14769]
===
match
---
fstring_expr [40554,40566]
fstring_expr [39736,39748]
===
match
---
trailer [10644,10659]
trailer [10591,10606]
===
match
---
operator: == [10531,10533]
operator: == [10478,10480]
===
match
---
name: RUNNING [31973,31980]
name: RUNNING [31920,31927]
===
match
---
simple_stmt [11978,12026]
simple_stmt [11925,11973]
===
match
---
operator: , [24733,24734]
operator: , [24680,24681]
===
match
---
simple_stmt [1460,1529]
simple_stmt [1407,1476]
===
match
---
name: ti [22098,22100]
name: ti [22045,22047]
===
match
---
trailer [48470,48474]
trailer [47609,47613]
===
match
---
testlist_comp [10696,10765]
testlist_comp [10643,10712]
===
match
---
exprlist [10710,10726]
exprlist [10657,10673]
===
match
---
string: "\n\t" [11498,11504]
string: "\n\t" [11445,11451]
===
match
---
trailer [6524,6526]
trailer [6471,6473]
===
match
---
for_stmt [45865,46187]
for_stmt [45004,45326]
===
match
---
name: State [39859,39864]
name: State [39041,39046]
===
match
---
name: State [46155,46160]
name: State [45294,45299]
===
match
---
trailer [8436,8442]
trailer [8383,8389]
===
match
---
trailer [5673,5680]
trailer [5620,5627]
===
match
---
name: dag_id [38836,38842]
name: dag_id [38018,38024]
===
match
---
name: conf [7530,7534]
name: conf [7477,7481]
===
match
---
operator: , [51161,51162]
operator: , [50300,50301]
===
match
---
name: schedule_delay [40443,40457]
name: schedule_delay [39625,39639]
===
match
---
name: self [35132,35136]
name: self [34357,34361]
===
match
---
simple_stmt [12034,12090]
simple_stmt [11981,12037]
===
match
---
operator: = [44035,44036]
operator: = [43174,43175]
===
match
---
name: num_runs [4739,4747]
name: num_runs [4686,4694]
===
match
---
operator: , [41500,41501]
operator: , [40639,40640]
===
match
---
name: session [28416,28423]
name: session [28363,28370]
===
match
---
trailer [49867,49886]
trailer [49006,49025]
===
match
---
atom_expr [9871,9885]
atom_expr [9818,9832]
===
match
---
number: 5.0 [27668,27671]
number: 5.0 [27615,27618]
===
match
---
trailer [42366,42377]
trailer [41505,41516]
===
match
---
for_stmt [12527,17120]
for_stmt [12474,17067]
===
match
---
operator: = [13312,13313]
operator: = [13259,13260]
===
match
---
simple_stmt [29986,29992]
simple_stmt [29933,29939]
===
match
---
simple_stmt [42110,42142]
simple_stmt [41249,41281]
===
match
---
trailer [21907,21911]
trailer [21854,21858]
===
match
---
simple_stmt [22824,22871]
simple_stmt [22771,22818]
===
match
---
operator: , [41270,41271]
operator: , [40409,40410]
===
match
---
atom_expr [40916,40951]
atom_expr [40055,40090]
===
match
---
trailer [25379,25399]
trailer [25326,25346]
===
match
---
string: "Tasks using non-existent pool '%s' will not be scheduled" [12683,12741]
string: "Tasks using non-existent pool '%s' will not be scheduled" [12630,12688]
===
match
---
name: dag_run [32181,32188]
name: dag_run [32128,32135]
===
match
---
name: self [20271,20275]
name: self [20218,20222]
===
match
---
trailer [40413,40422]
trailer [39595,39604]
===
match
---
atom_expr [22159,22187]
atom_expr [22106,22134]
===
match
---
name: prohibit_commit [2372,2387]
name: prohibit_commit [2319,2334]
===
match
---
operator: = [42751,42752]
operator: = [41890,41891]
===
match
---
atom_expr [34311,34347]
atom_expr [33536,33572]
===
match
---
expr_stmt [4232,4300]
expr_stmt [4179,4247]
===
match
---
trailer [28423,28435]
trailer [28370,28382]
===
match
---
name: pool_to_task_instances [12555,12577]
name: pool_to_task_instances [12502,12524]
===
match
---
name: RUNNING [46161,46168]
name: RUNNING [45300,45307]
===
match
---
atom_expr [38861,38919]
atom_expr [38043,38101]
===
match
---
param [34939,34944]
param [34164,34169]
===
match
---
string: "Resetting orphaned tasks for active dag runs" [46663,46709]
string: "Resetting orphaned tasks for active dag runs" [45802,45848]
===
match
---
trailer [8502,8524]
trailer [8449,8471]
===
match
---
atom_expr [40784,40864]
atom_expr [39927,40003]
===
match
---
name: priority_weight [10625,10640]
name: priority_weight [10572,10587]
===
match
---
fstring_end: ' [46040,46041]
fstring_end: ' [45179,45180]
===
match
---
trailer [48784,48829]
trailer [47923,47968]
===
match
---
simple_stmt [8896,8921]
simple_stmt [8843,8868]
===
match
---
arglist [48795,48827]
arglist [47934,47966]
===
match
---
name: timers [27565,27571]
name: timers [27512,27518]
===
match
---
atom_expr [28254,28270]
atom_expr [28201,28217]
===
match
---
atom_expr [5136,5150]
atom_expr [5083,5097]
===
match
---
atom_expr [41248,41270]
atom_expr [40387,40409]
===
match
---
name: info [21253,21257]
name: info [21200,21204]
===
match
---
atom_expr [42470,42489]
atom_expr [41609,41628]
===
match
---
trailer [45376,45380]
trailer [44515,44519]
===
match
---
expr_stmt [42154,42393]
expr_stmt [41293,41532]
===
match
---
atom_expr [23372,23606]
atom_expr [23319,23553]
===
match
---
name: dag_id [8823,8829]
name: dag_id [8770,8776]
===
match
---
name: session [20551,20558]
name: session [20498,20505]
===
match
---
not_test [45244,45267]
not_test [44383,44406]
===
match
---
argument [12219,12234]
argument [12166,12181]
===
match
---
name: _do_scheduling [30001,30015]
name: _do_scheduling [29948,29962]
===
match
---
operator: , [20783,20784]
operator: , [20730,20731]
===
match
---
name: dag [22964,22967]
name: dag [22911,22914]
===
match
---
name: queued_runs_of_dags [36584,36603]
name: queued_runs_of_dags [35809,35828]
===
match
---
arglist [44312,44392]
arglist [43451,43531]
===
match
---
trailer [48042,48061]
trailer [47181,47200]
===
match
---
arglist [40803,40863]
arglist [39942,40002]
===
match
---
argument [24587,24612]
argument [24534,24559]
===
match
---
name: run_id [42816,42822]
name: run_id [41955,41961]
===
match
---
name: executors [1473,1482]
name: executors [1420,1429]
===
match
---
name: DAGS_FOLDER [4365,4376]
name: DAGS_FOLDER [4312,4323]
===
match
---
parameters [44717,44801]
parameters [43856,43940]
===
match
---
atom_expr [20271,20300]
atom_expr [20218,20247]
===
match
---
name: run_id [42316,42322]
name: run_id [41455,41461]
===
match
---
name: self [5923,5927]
name: self [5870,5874]
===
match
---
name: session [42200,42207]
name: session [41339,41346]
===
match
---
atom_expr [44919,44936]
atom_expr [44058,44075]
===
match
---
atom_expr [47500,47526]
atom_expr [46639,46665]
===
match
---
trailer [11340,11344]
trailer [11287,11291]
===
match
---
trailer [36532,36539]
trailer [35757,35764]
===
match
---
name: task_instances_to_examine [11781,11806]
name: task_instances_to_examine [11728,11753]
===
match
---
name: num_starving_tasks_total [13800,13824]
name: num_starving_tasks_total [13747,13771]
===
match
---
name: async_mode [24321,24331]
name: async_mode [24268,24278]
===
match
---
name: pool [10834,10838]
name: pool [10781,10785]
===
match
---
testlist_comp [21555,21596]
testlist_comp [21502,21543]
===
match
---
name: session [41799,41806]
name: session [40938,40945]
===
match
---
operator: , [29871,29872]
operator: , [29818,29819]
===
match
---
name: _enqueue_task_instances_with_queued_state [18108,18149]
name: _enqueue_task_instances_with_queued_state [18055,18096]
===
match
---
simple_stmt [46719,46790]
simple_stmt [45858,45929]
===
match
---
atom_expr [22509,22517]
atom_expr [22456,22464]
===
match
---
operator: , [10719,10720]
operator: , [10666,10667]
===
match
---
name: utils [2319,2324]
name: utils [2266,2271]
===
match
---
argument [38747,38770]
argument [37929,37952]
===
match
---
trailer [24342,24355]
trailer [24289,24302]
===
match
---
name: task_instance [15471,15484]
name: task_instance [15418,15431]
===
match
---
name: run_with_db_retries [46814,46833]
name: run_with_db_retries [45953,45972]
===
match
---
suite [23866,26221]
suite [23813,26168]
===
match
---
name: info [18727,18731]
name: info [18674,18678]
===
match
---
operator: } [36897,36898]
operator: } [36122,36123]
===
match
---
name: session [1226,1233]
name: session [1226,1233]
===
match
---
trailer [33091,33093]
trailer [32316,32318]
===
match
---
name: DR [10642,10644]
name: DR [10589,10591]
===
match
---
if_stmt [22463,23800]
if_stmt [22410,23747]
===
match
---
funcdef [6007,6448]
funcdef [5954,6395]
===
match
---
simple_stmt [44945,44988]
simple_stmt [44084,44127]
===
match
---
name: ti [45319,45321]
name: ti [44458,44460]
===
match
---
simple_stmt [1342,1407]
simple_stmt [1342,1407]
===
match
---
name: ti [23724,23726]
name: ti [23671,23673]
===
match
---
operator: , [16431,16432]
operator: , [16378,16379]
===
match
---
simple_stmt [27386,27556]
simple_stmt [27333,27503]
===
match
---
name: MAX_DB_RETRIES [2182,2196]
name: MAX_DB_RETRIES [2129,2143]
===
match
---
if_stmt [35833,36357]
if_stmt [35058,35582]
===
match
---
simple_stmt [34455,34501]
simple_stmt [33680,33726]
===
match
---
simple_stmt [47876,47926]
simple_stmt [47015,47065]
===
match
---
number: 1 [46321,46322]
number: 1 [45460,45461]
===
match
---
atom_expr [25867,25886]
atom_expr [25814,25833]
===
match
---
simple_stmt [40443,40501]
simple_stmt [39625,39683]
===
match
---
operator: , [4676,4677]
operator: , [4623,4624]
===
match
---
operator: , [7953,7954]
operator: , [7900,7901]
===
match
---
atom_expr [8698,8714]
atom_expr [8645,8661]
===
match
---
name: max_queued_dagruns [37254,37272]
name: max_queued_dagruns [36479,36497]
===
match
---
name: subdir [4698,4704]
name: subdir [4645,4651]
===
match
---
trailer [17667,17671]
trailer [17614,17618]
===
match
---
operator: = [10875,10876]
operator: = [10822,10823]
===
match
---
trailer [41995,42010]
trailer [41134,41149]
===
match
---
operator: , [45123,45124]
operator: , [44262,44263]
===
match
---
testlist_comp [36294,36319]
testlist_comp [35519,35544]
===
match
---
trailer [36254,36269]
trailer [35479,35494]
===
match
---
atom_expr [9846,9858]
atom_expr [9793,9805]
===
match
---
name: dag_model [18599,18608]
name: dag_model [18546,18555]
===
match
---
name: utils [1985,1990]
name: utils [1932,1937]
===
match
---
operator: = [11496,11497]
operator: = [11443,11444]
===
match
---
import_as_names [993,1045]
import_as_names [993,1045]
===
match
---
expr_stmt [5426,5473]
expr_stmt [5373,5420]
===
match
---
name: info [22865,22869]
name: info [22812,22816]
===
match
---
name: List [9378,9382]
name: List [9325,9329]
===
match
---
name: task_instance_str [11478,11495]
name: task_instance_str [11425,11442]
===
match
---
trailer [36419,36426]
trailer [35644,35651]
===
match
---
atom_expr [45894,45907]
atom_expr [45033,45046]
===
match
---
trailer [42287,42294]
trailer [41426,41433]
===
match
---
operator: , [32870,32871]
operator: , [32271,32272]
===
match
---
trailer [49919,49924]
trailer [49058,49063]
===
match
---
name: dag_run [10328,10335]
name: dag_run [10275,10282]
===
match
---
name: info [6289,6293]
name: info [6236,6240]
===
match
---
string: '\n\t' [49856,49862]
string: '\n\t' [48995,49001]
===
match
---
name: num_times_parse_dags [5019,5039]
name: num_times_parse_dags [4966,4986]
===
match
---
name: dag_id [37369,37375]
name: dag_id [36573,36579]
===
match
---
trailer [37350,37358]
trailer [36554,36562]
===
match
---
name: try_number [22121,22131]
name: try_number [22068,22078]
===
match
---
funcdef [34684,34879]
funcdef [33909,34104]
===
match
---
trailer [5407,5417]
trailer [5354,5364]
===
match
---
name: end [25881,25884]
name: end [25828,25831]
===
match
---
name: len [11612,11615]
name: len [11559,11562]
===
match
---
simple_stmt [6066,6149]
simple_stmt [6013,6096]
===
match
---
name: dags_hash [37595,37604]
name: dags_hash [36777,36786]
===
match
---
simple_stmt [35886,36174]
simple_stmt [35111,35399]
===
match
---
operator: = [13168,13169]
operator: = [13115,13116]
===
match
---
arglist [36631,37018]
arglist [35856,36243]
===
match
---
trailer [22056,22072]
trailer [22003,22019]
===
match
---
name: self [5753,5757]
name: self [5700,5704]
===
match
---
expr_stmt [21878,21975]
expr_stmt [21825,21922]
===
match
---
name: self [37339,37343]
name: self [36543,36547]
===
match
---
simple_stmt [49554,49584]
simple_stmt [48693,48723]
===
match
---
atom_expr [36305,36319]
atom_expr [35530,35544]
===
match
---
trailer [20364,20390]
trailer [20311,20337]
===
match
---
operator: , [36426,36427]
operator: , [35651,35652]
===
match
---
trailer [24899,24905]
trailer [24846,24852]
===
match
---
name: RUNNING [47917,47924]
name: RUNNING [47056,47063]
===
match
---
expr_stmt [10805,10859]
expr_stmt [10752,10806]
===
match
---
name: task [23290,23294]
name: task [23237,23241]
===
match
---
atom_expr [21615,21650]
atom_expr [21562,21597]
===
match
---
expr_stmt [21024,21034]
expr_stmt [20971,20981]
===
match
---
name: int [8710,8713]
name: int [8657,8660]
===
match
---
trailer [42063,42065]
trailer [41202,41204]
===
match
---
trailer [22175,22187]
trailer [22122,22134]
===
match
---
name: do_pickle [24019,24028]
name: do_pickle [23966,23975]
===
match
---
name: query [10254,10259]
name: query [10201,10206]
===
match
---
fstring_expr [46130,46141]
fstring_expr [45269,45280]
===
match
---
subscriptlist [7921,7929]
subscriptlist [7868,7876]
===
match
---
simple_stmt [45585,45711]
simple_stmt [44724,44850]
===
match
---
string: 'mssql' [35865,35872]
string: 'mssql' [35090,35097]
===
match
---
name: attempt [46869,46876]
name: attempt [46008,46015]
===
match
---
simple_stmt [33824,33838]
simple_stmt [33049,33063]
===
match
---
atom_expr [39591,39646]
atom_expr [38773,38828]
===
match
---
atom_expr [17315,17334]
atom_expr [17262,17281]
===
match
---
name: self [21244,21248]
name: self [21191,21195]
===
match
---
trailer [20190,20206]
trailer [20137,20153]
===
match
---
param [7870,7893]
param [7817,7840]
===
match
---
suite [29696,29992]
suite [29643,29939]
===
match
---
operator: = [24730,24731]
operator: = [24677,24678]
===
match
---
name: _get_next_dagruns_to_examine [39265,39293]
name: _get_next_dagruns_to_examine [38447,38475]
===
match
---
trailer [20327,20364]
trailer [20274,20311]
===
match
---
operator: , [12535,12536]
operator: , [12482,12483]
===
match
---
operator: , [13345,13346]
operator: , [13292,13293]
===
match
---
name: Tuple [8674,8679]
name: Tuple [8621,8626]
===
match
---
simple_stmt [25639,25681]
simple_stmt [25586,25628]
===
match
---
name: self [12666,12670]
name: self [12613,12617]
===
match
---
for_stmt [42406,42551]
for_stmt [41545,41690]
===
match
---
simple_stmt [907,943]
simple_stmt [907,943]
===
match
---
trailer [47805,47815]
trailer [46944,46954]
===
match
---
name: current_max_active_tasks_per_dag [14050,14082]
name: current_max_active_tasks_per_dag [13997,14029]
===
match
---
name: set_state [42118,42127]
name: set_state [41257,41266]
===
match
---
trailer [33648,33652]
trailer [32873,32877]
===
match
---
name: try_number [21504,21514]
name: try_number [21451,21461]
===
match
---
name: async_mode [24784,24794]
name: async_mode [24731,24741]
===
match
---
trailer [14109,14117]
trailer [14056,14064]
===
match
---
name: sorted [13170,13176]
name: sorted [13117,13123]
===
match
---
atom_expr [22466,22479]
atom_expr [22413,22426]
===
match
---
name: int [24392,24395]
name: int [24339,24342]
===
match
---
for_stmt [32177,33066]
for_stmt [32124,32291]
===
match
---
operator: } [51294,51295]
operator: } [50433,50434]
===
match
---
trailer [9883,9885]
trailer [9830,9832]
===
match
---
operator: += [13763,13765]
operator: += [13710,13712]
===
match
---
parameters [20544,20575]
parameters [20491,20522]
===
match
---
name: execution_date [41256,41270]
name: execution_date [40395,40409]
===
match
---
trailer [10584,10597]
trailer [10531,10544]
===
match
---
trailer [31792,31817]
trailer [31739,31764]
===
match
---
name: info [13472,13476]
name: info [13419,13423]
===
match
---
param [46242,46265]
param [45381,45404]
===
match
---
comp_op [15589,15595]
comp_op [15536,15542]
===
match
---
name: execution_date [36435,36449]
name: execution_date [35660,35674]
===
match
---
operator: = [7463,7464]
operator: = [7410,7411]
===
match
---
trailer [40522,40529]
trailer [39704,39711]
===
match
---
tfpdef [7837,7868]
tfpdef [7784,7815]
===
match
---
name: dag_run [41459,41466]
name: dag_run [40598,40605]
===
match
---
operator: - [49761,49762]
operator: - [48900,48901]
===
match
---
simple_stmt [10015,10055]
simple_stmt [9962,10002]
===
match
---
trailer [42234,42241]
trailer [41373,41380]
===
match
---
simple_stmt [12787,12820]
simple_stmt [12734,12767]
===
match
---
trailer [20873,20875]
trailer [20820,20822]
===
match
---
name: do_pickle [5153,5162]
name: do_pickle [5100,5109]
===
match
---
name: signum [6668,6674]
name: signum [6615,6621]
===
match
---
expr_stmt [18512,18633]
expr_stmt [18459,18580]
===
match
---
operator: = [5040,5041]
operator: = [4987,4988]
===
match
---
name: DM [10487,10489]
name: DM [10434,10436]
===
match
---
operator: = [24396,24397]
operator: = [24343,24344]
===
match
---
name: getfloat [27247,27255]
name: getfloat [27194,27202]
===
match
---
name: self [24092,24096]
name: self [24039,24043]
===
match
---
name: session [28274,28281]
name: session [28221,28228]
===
match
---
name: num_timed_out_tasks [50735,50754]
name: num_timed_out_tasks [49874,49893]
===
match
---
name: processor_agent [5572,5587]
name: processor_agent [5519,5534]
===
match
---
expr_stmt [21047,21063]
expr_stmt [20994,21010]
===
match
---
trailer [11514,11517]
trailer [11461,11464]
===
match
---
operator: , [27317,27318]
operator: , [27264,27265]
===
match
---
atom_expr [9036,9044]
atom_expr [8983,8991]
===
match
---
name: bool [27001,27005]
name: bool [26948,26952]
===
match
---
dotted_name [1534,1555]
dotted_name [1481,1502]
===
match
---
name: session [43525,43532]
name: session [42664,42671]
===
match
---
name: log [41049,41052]
name: log [40188,40191]
===
match
---
name: seconds [47510,47517]
name: seconds [46649,46656]
===
match
---
string: "Run %s of %s has timed-out" [42605,42633]
string: "Run %s of %s has timed-out" [41744,41772]
===
match
---
name: task_instances [12849,12863]
name: task_instances [12796,12810]
===
match
---
trailer [6398,6414]
trailer [6345,6361]
===
match
---
name: session [39396,39403]
name: session [38578,38585]
===
match
---
trailer [48549,48561]
trailer [47688,47700]
===
match
---
trailer [8495,8502]
trailer [8442,8449]
===
match
---
simple_stmt [2306,2417]
simple_stmt [2253,2364]
===
match
---
trailer [50811,50818]
trailer [49950,49957]
===
match
---
name: utcnow [39915,39921]
name: utcnow [39097,39103]
===
match
---
simple_stmt [5954,6002]
simple_stmt [5901,5949]
===
match
---
name: dagbag [41760,41766]
name: dagbag [40899,40905]
===
match
---
name: QUEUED [39300,39306]
name: QUEUED [38482,38488]
===
match
---
atom_expr [23256,23263]
atom_expr [23203,23210]
===
match
---
trailer [23631,23647]
trailer [23578,23594]
===
match
---
with_stmt [46864,50436]
with_stmt [46003,49575]
===
match
---
atom [51198,51236]
atom [50337,50375]
===
match
---
name: processor_agent [23632,23647]
name: processor_agent [23579,23594]
===
match
---
number: 0 [12278,12279]
number: 0 [12225,12226]
===
match
---
simple_stmt [20467,20490]
simple_stmt [20414,20437]
===
match
---
trailer [24870,24873]
trailer [24817,24820]
===
match
---
name: NONE [49399,49403]
name: NONE [48538,48542]
===
match
---
annassign [20767,20819]
annassign [20714,20766]
===
match
---
name: func [8466,8470]
name: func [8413,8417]
===
match
---
expr_stmt [8652,8714]
expr_stmt [8599,8661]
===
match
---
trailer [13467,13471]
trailer [13414,13418]
===
match
---
name: execution_date [43263,43277]
name: execution_date [42402,42416]
===
match
---
atom_expr [48795,48804]
atom_expr [47934,47943]
===
match
---
string: 'core' [27024,27030]
string: 'core' [26971,26977]
===
match
---
atom_expr [25719,25798]
atom_expr [25666,25745]
===
match
---
trailer [43511,43524]
trailer [42650,42663]
===
match
---
operator: , [34943,34944]
operator: , [34168,34169]
===
match
---
name: dag [1622,1625]
name: dag [1569,1572]
===
match
---
operator: = [42787,42788]
operator: = [41926,41927]
===
match
---
trailer [17371,17376]
trailer [17318,17323]
===
match
---
name: dag_id [39738,39744]
name: dag_id [38920,38926]
===
match
---
expr_stmt [44145,44237]
expr_stmt [43284,43376]
===
match
---
atom_expr [45997,46068]
atom_expr [45136,45207]
===
match
---
name: log [37457,37460]
name: log [36643,36646]
===
match
---
operator: { [4187,4188]
operator: { [4134,4135]
===
match
---
name: manager [1370,1377]
name: manager [1370,1377]
===
match
---
import_from [1683,1723]
import_from [1630,1670]
===
match
---
string: "Trigger/execution timeout" [51208,51235]
string: "Trigger/execution timeout" [50347,50374]
===
match
---
comparison [10358,10396]
comparison [10305,10343]
===
match
---
simple_stmt [17203,17265]
simple_stmt [17150,17212]
===
match
---
operator: , [22853,22854]
operator: , [22800,22801]
===
match
---
operator: < [50886,50887]
operator: < [50025,50026]
===
match
---
trailer [47345,47352]
trailer [46484,46491]
===
match
---
trailer [28393,28395]
trailer [28340,28342]
===
match
---
trailer [49737,49760]
trailer [48876,48899]
===
match
---
name: processor_agent [25364,25379]
name: processor_agent [25311,25326]
===
match
---
import_from [1642,1682]
import_from [1589,1629]
===
match
---
fstring_expr [17086,17097]
fstring_expr [17033,17044]
===
match
---
operator: , [47417,47418]
operator: , [46556,46557]
===
match
---
atom_expr [5513,5558]
atom_expr [5460,5505]
===
match
---
trailer [46160,46168]
trailer [45299,45307]
===
match
---
operator: = [23026,23027]
operator: = [22973,22974]
===
match
---
name: executor [6848,6856]
name: executor [6795,6803]
===
match
---
operator: , [11642,11643]
operator: , [11589,11590]
===
match
---
name: guard [31895,31900]
name: guard [31842,31847]
===
match
---
arglist [47708,47764]
arglist [46847,46903]
===
match
---
string: 'core' [24410,24416]
string: 'core' [24357,24363]
===
match
---
trailer [6847,6856]
trailer [6794,6803]
===
match
---
dictorsetmaker [17856,17943]
dictorsetmaker [17803,17890]
===
match
---
suite [34761,34879]
suite [33986,34104]
===
match
---
operator: - [13226,13227]
operator: - [13173,13174]
===
match
---
operator: , [8868,8869]
operator: , [8815,8816]
===
match
---
name: num_tasks_in_executor [17242,17263]
name: num_tasks_in_executor [17189,17210]
===
match
---
trailer [34838,34862]
trailer [34063,34087]
===
match
---
operator: = [49854,49855]
operator: = [48993,48994]
===
match
---
suite [25706,25817]
suite [25653,25764]
===
match
---
atom_expr [10487,10499]
atom_expr [10434,10446]
===
match
---
operator: , [35367,35368]
operator: , [34592,34593]
===
match
---
trailer [43313,43346]
trailer [42452,42485]
===
match
---
name: filter [8496,8502]
name: filter [8443,8449]
===
match
---
simple_stmt [35404,35575]
simple_stmt [34629,34800]
===
match
---
name: getfloat [27612,27620]
name: getfloat [27559,27567]
===
match
---
trailer [40422,40426]
trailer [39604,39608]
===
match
---
argument [43525,43540]
argument [42664,42679]
===
match
---
name: ti_concurrency_query [8737,8757]
name: ti_concurrency_query [8684,8704]
===
match
---
operator: = [39857,39858]
operator: = [39039,39040]
===
match
---
name: deactivate_stale_dags [25584,25605]
name: deactivate_stale_dags [25531,25552]
===
match
---
operator: <= [13437,13439]
operator: <= [13384,13386]
===
match
---
simple_stmt [25933,25993]
simple_stmt [25880,25940]
===
match
---
name: time [29301,29305]
name: time [29248,29252]
===
match
---
comparison [15566,15600]
comparison [15513,15547]
===
match
---
name: pool_name [17087,17096]
name: pool_name [17034,17043]
===
match
---
atom_expr [39410,39423]
atom_expr [38592,38605]
===
match
---
name: local [18558,18563]
name: local [18505,18510]
===
match
---
name: dag_id [45683,45689]
name: dag_id [44822,44828]
===
match
---
simple_stmt [40653,40726]
simple_stmt [39814,39887]
===
match
---
atom_expr [20681,20726]
atom_expr [20628,20673]
===
match
---
atom_expr [36226,36356]
atom_expr [35451,35581]
===
match
---
name: pools [12643,12648]
name: pools [12590,12595]
===
match
---
name: dag_id [35993,35999]
name: dag_id [35218,35224]
===
match
---
simple_stmt [25000,25039]
simple_stmt [24947,24986]
===
match
---
comparison [12631,12648]
comparison [12578,12595]
===
match
---
operator: = [14165,14166]
operator: = [14112,14113]
===
match
---
simple_stmt [22318,22349]
simple_stmt [22265,22296]
===
match
---
expr_stmt [22318,22348]
expr_stmt [22265,22295]
===
match
---
name: ti [21988,21990]
name: ti [21935,21937]
===
match
---
trailer [41748,41752]
trailer [40887,40891]
===
match
---
atom_expr [7944,7959]
atom_expr [7891,7906]
===
match
---
name: List [11713,11717]
name: List [11660,11664]
===
match
---
name: query [10877,10882]
name: query [10824,10829]
===
match
---
simple_stmt [38861,38920]
simple_stmt [38043,38102]
===
match
---
param [45125,45133]
param [44264,44272]
===
match
---
name: Stats [17129,17134]
name: Stats [17076,17081]
===
match
---
name: dag [45348,45351]
name: dag [44487,44490]
===
match
---
operator: = [44666,44667]
operator: = [43805,43806]
===
match
---
trailer [39409,39441]
trailer [38591,38623]
===
match
---
name: len [11287,11290]
name: len [11234,11237]
===
match
---
name: Tuple [20774,20779]
name: Tuple [20721,20726]
===
match
---
name: grace_multiplier [7447,7463]
name: grace_multiplier [7394,7410]
===
match
---
trailer [24890,24899]
trailer [24837,24846]
===
match
---
name: queue [18957,18962]
name: queue [18904,18909]
===
match
---
name: str [7955,7958]
name: str [7902,7905]
===
match
---
suite [45359,45474]
suite [44498,44613]
===
match
---
name: Session [7879,7886]
name: Session [7826,7833]
===
match
---
atom_expr [11498,11553]
atom_expr [11445,11500]
===
match
---
comparison [37238,37272]
comparison [36463,36497]
===
match
---
expr_stmt [36200,36356]
expr_stmt [35425,35581]
===
match
---
atom_expr [13463,13553]
atom_expr [13410,13500]
===
match
---
operator: = [13670,13671]
operator: = [13617,13618]
===
match
---
trailer [50041,50051]
trailer [49180,49190]
===
match
---
name: DagRun [36413,36419]
name: DagRun [35638,35644]
===
match
---
atom_expr [21555,21567]
atom_expr [21502,21514]
===
match
---
trailer [20477,20489]
trailer [20424,20436]
===
match
---
trailer [26897,26913]
trailer [26844,26860]
===
match
---
trailer [22857,22863]
trailer [22804,22810]
===
match
---
atom_expr [23191,23210]
atom_expr [23138,23157]
===
match
---
trailer [7680,7682]
trailer [7627,7629]
===
match
---
trailer [15344,15367]
trailer [15291,15314]
===
match
---
number: 0 [12398,12399]
number: 0 [12345,12346]
===
match
---
atom_expr [5426,5442]
atom_expr [5373,5389]
===
match
---
name: self [41755,41759]
name: self [40894,40898]
===
match
---
operator: , [16392,16393]
operator: , [16339,16340]
===
match
---
suite [21726,21764]
suite [21673,21711]
===
match
---
atom_expr [23724,23799]
atom_expr [23671,23746]
===
match
---
expr_stmt [21813,21869]
expr_stmt [21760,21816]
===
match
---
operator: , [5704,5705]
operator: , [5651,5652]
===
match
---
suite [34961,35273]
suite [34186,34498]
===
match
---
name: task_instance_str [49836,49853]
name: task_instance_str [48975,48992]
===
match
---
operator: , [47009,47010]
operator: , [46148,46149]
===
match
---
trailer [49384,49390]
trailer [48523,48529]
===
match
---
trailer [49489,49512]
trailer [48628,48651]
===
match
---
name: processor_agent [25131,25146]
name: processor_agent [25078,25093]
===
match
---
atom_expr [7634,7647]
atom_expr [7581,7594]
===
match
---
name: ti [22509,22511]
name: ti [22456,22458]
===
match
---
name: timeout [46719,46726]
name: timeout [45858,45865]
===
match
---
name: timers [27059,27065]
name: timers [27006,27012]
===
match
---
name: SUCCESS [21575,21582]
name: SUCCESS [21522,21529]
===
match
---
name: log [25724,25727]
name: log [25671,25674]
===
match
---
operator: , [16481,16482]
operator: , [16428,16429]
===
match
---
operator: = [32776,32777]
operator: = [32181,32182]
===
match
---
raise_stmt [26927,26978]
raise_stmt [26874,26925]
===
match
---
name: register_signals [5736,5752]
name: register_signals [5683,5699]
===
match
---
import_as_names [1286,1302]
import_as_names [1286,1302]
===
match
---
atom_expr [16966,17033]
atom_expr [16913,16980]
===
match
---
operator: , [6040,6041]
operator: , [5987,5988]
===
match
---
operator: , [45325,45326]
operator: , [44464,44465]
===
match
---
name: airflow [1465,1472]
name: airflow [1412,1419]
===
match
---
suite [26009,26053]
suite [25956,26000]
===
match
---
trailer [28107,28168]
trailer [28054,28115]
===
match
---
name: next_dagrun [38336,38347]
name: next_dagrun [37518,37529]
===
match
---
fstring_string: pool.running_slots. [46111,46130]
fstring_string: pool.running_slots. [45250,45269]
===
match
---
name: external_trigger [38627,38643]
name: external_trigger [37809,37825]
===
match
---
name: ti_primary_key_to_try_number_map [22024,22056]
name: ti_primary_key_to_try_number_map [21971,22003]
===
match
---
atom_expr [28808,28863]
atom_expr [28755,28810]
===
match
---
trailer [40971,40987]
trailer [40110,40126]
===
match
---
import_as_names [2051,2090]
import_as_names [1998,2037]
===
match
---
name: session [39126,39133]
name: session [38308,38315]
===
match
---
simple_stmt [28752,28792]
simple_stmt [28699,28739]
===
match
---
simple_stmt [13800,13842]
simple_stmt [13747,13789]
===
match
---
funcdef [50492,51453]
funcdef [49631,50592]
===
match
---
simple_stmt [16149,16158]
simple_stmt [16096,16105]
===
match
---
trailer [8638,8643]
trailer [8585,8590]
===
match
---
name: session [11011,11018]
name: session [10958,10965]
===
match
---
name: DagRun [36843,36849]
name: DagRun [36068,36074]
===
match
---
name: dag [42788,42791]
name: dag [41927,41930]
===
match
---
trailer [40792,40802]
trailer [39935,39941]
===
match
---
name: session [35836,35843]
name: session [35061,35068]
===
match
---
operator: = [8696,8697]
operator: = [8643,8644]
===
match
---
name: self [29568,29572]
name: self [29515,29519]
===
match
---
operator: = [23549,23550]
operator: = [23496,23497]
===
match
---
operator: = [38678,38679]
operator: = [37860,37861]
===
match
---
name: executor [28375,28383]
name: executor [28322,28330]
===
match
---
suite [20662,20727]
suite [20609,20674]
===
match
---
trailer [47579,47586]
trailer [46718,46725]
===
match
---
trailer [6733,6741]
trailer [6680,6688]
===
match
---
trailer [18726,18731]
trailer [18673,18678]
===
match
---
name: Stats [1901,1906]
name: Stats [1848,1853]
===
match
---
trailer [36482,36486]
trailer [35707,35711]
===
match
---
string: "\n\t" [17365,17371]
string: "\n\t" [17312,17318]
===
match
---
name: key [22101,22104]
name: key [22048,22051]
===
match
---
operator: = [5621,5622]
operator: = [5568,5569]
===
match
---
operator: = [42180,42181]
operator: = [41319,41320]
===
match
---
name: schedulable_tis [43469,43484]
name: schedulable_tis [42608,42623]
===
match
---
trailer [12067,12089]
trailer [12014,12036]
===
match
---
annassign [20904,20932]
annassign [20851,20879]
===
match
---
name: self [28649,28653]
name: self [28596,28600]
===
match
---
trailer [10486,10500]
trailer [10433,10447]
===
match
---
name: count [27758,27763]
name: count [27705,27710]
===
match
---
atom_expr [45348,45357]
atom_expr [44487,44496]
===
match
---
trailer [47300,47306]
trailer [46439,46445]
===
match
---
operator: -> [7900,7902]
operator: -> [7847,7849]
===
match
---
sync_comp_for [36321,36341]
sync_comp_for [35546,35566]
===
match
---
name: unfinished_task_instances [42154,42179]
name: unfinished_task_instances [41293,41318]
===
match
---
name: timezone [50888,50896]
name: timezone [50027,50035]
===
match
---
trailer [36983,36998]
trailer [36208,36223]
===
match
---
name: stop [34194,34198]
name: stop [33419,33423]
===
match
---
expr_stmt [49554,49583]
expr_stmt [48693,48722]
===
match
---
operator: , [5982,5983]
operator: , [5929,5930]
===
match
---
name: Stats [22551,22556]
name: Stats [22498,22503]
===
match
---
operator: = [41753,41754]
operator: = [40892,40893]
===
match
---
name: queue [18951,18956]
name: queue [18898,18903]
===
match
---
simple_stmt [7490,7591]
simple_stmt [7437,7538]
===
match
---
comparison [42242,42269]
comparison [41381,41408]
===
match
---
name: log [23112,23115]
name: log [23059,23062]
===
match
---
not_test [45486,45510]
not_test [44625,44649]
===
match
---
simple_stmt [6394,6421]
simple_stmt [6341,6368]
===
match
---
arglist [42738,42913]
arglist [41877,42052]
===
match
---
name: _send_dag_callbacks_to_processor [33279,33311]
name: _send_dag_callbacks_to_processor [32504,32536]
===
match
---
tfpdef [7870,7886]
tfpdef [7817,7833]
===
match
---
name: filter [47346,47352]
name: filter [46485,46491]
===
match
---
trailer [24100,24105]
trailer [24047,24052]
===
match
---
import_from [1907,1971]
import_from [1854,1918]
===
match
---
name: task_instance [15345,15358]
name: task_instance [15292,15305]
===
match
---
trailer [42755,42763]
trailer [41894,41902]
===
match
---
name: len [49763,49766]
name: len [48902,48905]
===
match
---
fstring_start: f' [40530,40532]
fstring_start: f' [39712,39714]
===
match
---
string: 'scheduler_heartbeat' [46295,46316]
string: 'scheduler_heartbeat' [45434,45455]
===
match
---
trailer [46059,46066]
trailer [45198,45205]
===
match
---
trailer [28822,28863]
trailer [28769,28810]
===
match
---
string: "No tasks to consider for execution." [11351,11388]
string: "No tasks to consider for execution." [11298,11335]
===
match
---
return_stmt [34560,34568]
return_stmt [33785,33793]
===
match
---
name: _executable_task_instances_to_queued [8951,8987]
name: _executable_task_instances_to_queued [8898,8934]
===
match
---
trailer [28484,28509]
trailer [28431,28456]
===
match
---
expr_stmt [22085,22132]
expr_stmt [22032,22079]
===
match
---
trailer [28548,28564]
trailer [28495,28511]
===
match
---
suite [27773,29992]
suite [27720,29939]
===
match
---
trailer [47815,47824]
trailer [46954,46963]
===
match
---
name: info [46658,46662]
name: info [45797,45801]
===
match
---
name: max [9835,9838]
name: max [9782,9785]
===
match
---
trailer [43209,43213]
trailer [42348,42352]
===
match
---
expr_stmt [8852,8887]
expr_stmt [8799,8834]
===
match
---
trailer [36990,36997]
trailer [36215,36222]
===
match
---
name: dag_id [38318,38324]
name: dag_id [37500,37506]
===
match
---
operator: , [11070,11071]
operator: , [11017,11018]
===
match
---
string: 'processor_poll_interval' [4548,4573]
string: 'processor_poll_interval' [4495,4520]
===
match
---
name: Stats [33757,33762]
name: Stats [32982,32987]
===
match
---
trailer [45066,45076]
trailer [44205,44215]
===
match
---
name: dag [40388,40391]
name: dag [39570,39573]
===
match
---
simple_stmt [16857,16896]
simple_stmt [16804,16843]
===
match
---
operator: } [47609,47610]
operator: } [46748,46749]
===
match
---
trailer [27796,27802]
trailer [27743,27749]
===
match
---
name: session [47980,47987]
name: session [47119,47126]
===
match
---
operator: , [41161,41162]
operator: , [40300,40301]
===
match
---
trailer [5176,5178]
trailer [5123,5125]
===
match
---
atom_expr [29893,29918]
atom_expr [29840,29865]
===
match
---
trailer [6432,6437]
trailer [6379,6384]
===
match
---
trailer [47830,47832]
trailer [46969,46971]
===
match
---
name: models [1798,1804]
name: models [1745,1751]
===
match
---
name: dagrun_timeout [42072,42086]
name: dagrun_timeout [41211,41225]
===
match
---
expr_stmt [50735,51319]
expr_stmt [49874,50458]
===
match
---
number: 0 [39381,39382]
number: 0 [38563,38564]
===
match
---
string: "Exception when executing Executor.end" [25952,25991]
string: "Exception when executing Executor.end" [25899,25938]
===
match
---
operator: , [10640,10641]
operator: , [10587,10588]
===
match
---
name: self [46384,46388]
name: self [45523,45527]
===
match
---
simple_stmt [8652,8715]
simple_stmt [8599,8662]
===
match
---
simple_stmt [24886,24908]
simple_stmt [24833,24855]
===
match
---
simple_stmt [36584,37029]
simple_stmt [35809,36254]
===
match
---
simple_stmt [49428,49455]
simple_stmt [48567,48594]
===
match
---
trailer [17701,18002]
trailer [17648,17949]
===
match
---
simple_stmt [28544,28577]
simple_stmt [28491,28524]
===
match
---
operator: = [20815,20816]
operator: = [20762,20763]
===
match
---
trailer [40529,40584]
trailer [39711,39766]
===
match
---
atom_expr [6751,6833]
atom_expr [6698,6780]
===
match
---
string: 'SCHEDULER_HEARTBEAT_SEC' [4274,4299]
string: 'SCHEDULER_HEARTBEAT_SEC' [4221,4246]
===
match
---
factor [4476,4478]
factor [4423,4425]
===
match
---
simple_stmt [20167,20207]
simple_stmt [20114,20154]
===
match
---
expr_stmt [10869,10897]
expr_stmt [10816,10844]
===
match
---
trailer [36974,36983]
trailer [36199,36208]
===
match
---
atom_expr [41324,41359]
atom_expr [40463,40498]
===
match
---
name: end [40423,40426]
name: end [39605,39608]
===
match
---
operator: > [16203,16204]
operator: > [16150,16151]
===
match
---
trailer [37526,37533]
trailer [36708,36715]
===
match
---
trailer [17678,17694]
trailer [17625,17641]
===
match
---
name: total_queued [37238,37250]
name: total_queued [36463,36475]
===
match
---
operator: , [37017,37018]
operator: , [36242,36243]
===
match
---
name: utils [2500,2505]
name: utils [2447,2452]
===
match
---
trailer [18699,18705]
trailer [18646,18652]
===
match
---
name: DefaultDict [8662,8673]
name: DefaultDict [8609,8620]
===
match
---
trailer [39762,39764]
trailer [38944,38946]
===
match
---
atom_expr [20474,20489]
atom_expr [20421,20436]
===
match
---
number: 80 [6830,6832]
number: 80 [6777,6779]
===
match
---
import_from [1047,1099]
import_from [1047,1099]
===
match
---
number: 0 [43099,43100]
number: 0 [42238,42239]
===
match
---
name: int [19055,19058]
name: int [19002,19005]
===
match
---
name: heartbeat [28565,28574]
name: heartbeat [28512,28521]
===
match
---
name: TaskInstanceState [7850,7867]
name: TaskInstanceState [7797,7814]
===
match
---
name: all [49116,49119]
name: all [48255,48258]
===
match
---
trailer [11707,11731]
trailer [11654,11678]
===
match
---
trailer [9602,9614]
trailer [9549,9561]
===
match
---
name: options [10564,10571]
name: options [10511,10518]
===
match
---
operator: , [49732,49733]
operator: , [48871,48872]
===
match
---
name: task [23266,23270]
name: task [23213,23217]
===
match
---
name: EX_OK [6441,6446]
name: EX_OK [6388,6393]
===
match
---
trailer [46653,46657]
trailer [45792,45796]
===
match
---
name: defaultdict [36606,36617]
name: defaultdict [35831,35842]
===
match
---
trailer [43213,43219]
trailer [42352,42358]
===
match
---
name: and_ [1070,1074]
name: and_ [1070,1074]
===
match
---
operator: , [40847,40848]
operator: , [39986,39987]
===
match
---
trailer [23125,23170]
trailer [23072,23117]
===
match
---
name: TI [9041,9043]
name: TI [8988,8990]
===
match
---
name: taskinstance [1805,1817]
name: taskinstance [1752,1764]
===
match
---
name: info [47703,47707]
name: info [46842,46846]
===
match
---
funcdef [29997,34653]
funcdef [29944,33878]
===
match
---
trailer [5357,5359]
trailer [5304,5306]
===
match
---
name: str [8615,8618]
name: str [8562,8565]
===
match
---
operator: = [45783,45784]
operator: = [44922,44923]
===
match
---
name: self [5637,5641]
name: self [5584,5588]
===
match
---
name: TI [10995,10997]
name: TI [10942,10944]
===
match
---
atom_expr [15418,15541]
atom_expr [15365,15488]
===
match
---
name: ti_key [21443,21449]
name: ti_key [21390,21396]
===
match
---
name: self [27835,27839]
name: self [27782,27786]
===
match
---
name: int [8639,8642]
name: int [8586,8589]
===
match
---
name: num_failed [47843,47853]
name: num_failed [46982,46992]
===
match
---
operator: , [42763,42764]
operator: , [41902,41903]
===
match
---
simple_stmt [44634,44676]
simple_stmt [43773,43815]
===
match
---
atom [50757,51319]
atom [49896,50458]
===
match
---
suite [15854,16158]
suite [15801,16105]
===
match
---
trailer [12073,12083]
trailer [12020,12030]
===
match
---
name: airflow [1729,1736]
name: airflow [1676,1683]
===
match
---
annassign [11694,11751]
annassign [11641,11698]
===
match
---
trailer [46662,46710]
trailer [45801,45849]
===
match
---
name: _is_parent_process [6164,6182]
name: _is_parent_process [6111,6129]
===
match
---
name: SCHEDULED [10540,10549]
name: SCHEDULED [10487,10496]
===
match
---
atom_expr [35132,35175]
atom_expr [34357,34400]
===
match
---
trailer [44641,44658]
trailer [43780,43797]
===
match
---
argument [28664,28686]
argument [28611,28633]
===
match
---
name: jobs [1542,1546]
name: jobs [1489,1493]
===
match
---
argument [28510,28525]
argument [28457,28472]
===
match
---
name: Session [46399,46406]
name: Session [45538,45545]
===
match
---
simple_stmt [12877,13124]
simple_stmt [12824,13071]
===
match
---
comparison [13426,13441]
comparison [13373,13388]
===
match
---
operator: , [31980,31981]
operator: , [31927,31928]
===
match
---
trailer [8505,8511]
trailer [8452,8458]
===
match
---
atom_expr [11510,11517]
atom_expr [11457,11464]
===
match
---
trailer [37368,37375]
trailer [36572,36579]
===
match
---
name: try_number [21220,21230]
name: try_number [21167,21177]
===
match
---
param [4584,4608]
param [4531,4555]
===
match
---
name: reset_tis_message [49868,49885]
name: reset_tis_message [49007,49024]
===
match
---
name: TI [8455,8457]
name: TI [8402,8404]
===
match
---
trailer [18176,18180]
trailer [18123,18127]
===
match
---
name: create_session [2274,2288]
name: create_session [2221,2235]
===
match
---
simple_stmt [43863,43910]
simple_stmt [43002,43049]
===
match
---
atom_expr [48451,48480]
atom_expr [47590,47619]
===
match
---
trailer [49352,49356]
trailer [48491,48495]
===
match
---
trailer [29433,29438]
trailer [29380,29385]
===
match
---
parameters [46383,46414]
parameters [45522,45553]
===
match
---
string: "DAG %s not changed structure, skipping dagrun.verify_integrity" [44312,44376]
string: "DAG %s not changed structure, skipping dagrun.verify_integrity" [43451,43515]
===
match
---
trailer [28268,28270]
trailer [28215,28217]
===
match
---
operator: , [36634,36635]
operator: , [35859,35860]
===
match
---
operator: , [38605,38606]
operator: , [37787,37788]
===
match
---
if_stmt [39936,40585]
if_stmt [39118,39767]
===
match
---
trailer [23741,23799]
trailer [23688,23746]
===
match
---
name: name [2828,2832]
name: name [2775,2779]
===
match
---
name: dag [44983,44986]
name: dag [44122,44125]
===
match
---
param [39813,39828]
param [38995,39010]
===
match
---
name: filter [10351,10357]
name: filter [10298,10304]
===
match
---
expr_stmt [49142,49214]
expr_stmt [48281,48353]
===
match
---
expr_stmt [25000,25038]
expr_stmt [24947,24985]
===
match
---
arglist [23742,23798]
arglist [23689,23745]
===
match
---
name: TI [48397,48399]
name: TI [47536,47538]
===
match
---
name: schedule_tis [43871,43883]
name: schedule_tis [43010,43022]
===
match
---
name: self [25126,25130]
name: self [25073,25077]
===
match
---
operator: , [47527,47528]
operator: , [46666,46667]
===
match
---
name: command [18891,18898]
name: command [18838,18845]
===
match
---
trailer [43048,43078]
trailer [42187,42217]
===
match
---
trailer [45321,45325]
trailer [44460,44464]
===
match
---
name: to_reset [50456,50464]
name: to_reset [49595,49603]
===
match
---
atom_expr [35258,35272]
atom_expr [34483,34497]
===
match
---
operator: , [50051,50052]
operator: , [49190,49191]
===
match
---
funcdef [2598,2850]
funcdef [2545,2797]
===
match
---
name: num_unhandled [13766,13779]
name: num_unhandled [13713,13726]
===
match
---
simple_stmt [7423,7482]
simple_stmt [7370,7429]
===
match
---
atom [13225,13265]
atom [13172,13212]
===
match
---
name: DagFileProcessorAgent [5598,5619]
name: DagFileProcessorAgent [5545,5566]
===
match
---
simple_stmt [26184,26221]
simple_stmt [26131,26168]
===
match
---
trailer [36450,36457]
trailer [35675,35682]
===
match
---
name: TI [2531,2533]
name: TI [2478,2480]
===
match
---
operator: == [47401,47403]
operator: == [46540,46542]
===
match
---
trailer [20251,20269]
trailer [20198,20216]
===
match
---
suite [25916,25993]
suite [25863,25940]
===
match
---
operator: == [36000,36002]
operator: == [35225,35227]
===
match
---
name: open_slots [12787,12797]
name: open_slots [12734,12744]
===
match
---
operator: , [17484,17485]
operator: , [17431,17432]
===
match
---
name: processor_agent [45026,45041]
name: processor_agent [44165,44180]
===
match
---
trailer [5906,5945]
trailer [5853,5892]
===
match
---
name: sig_name [6814,6822]
name: sig_name [6761,6769]
===
match
---
name: update [50920,50926]
name: update [50059,50065]
===
match
---
name: with_try_number [22105,22120]
name: with_try_number [22052,22067]
===
match
---
atom_expr [38544,38556]
atom_expr [37726,37738]
===
match
---
atom_expr [12666,12748]
atom_expr [12613,12695]
===
match
---
simple_stmt [31895,31910]
simple_stmt [31842,31857]
===
match
---
name: multiprocessing [2794,2809]
name: multiprocessing [2741,2756]
===
match
---
atom_expr [12004,12025]
atom_expr [11951,11972]
===
match
---
name: str [8402,8405]
name: str [8349,8352]
===
match
---
trailer [10838,10842]
trailer [10785,10789]
===
match
---
name: tis [21878,21881]
name: tis [21825,21828]
===
match
---
arith_expr [47801,47841]
arith_expr [46940,46980]
===
match
---
trailer [49697,49777]
trailer [48836,48916]
===
match
---
simple_stmt [8364,8586]
simple_stmt [8311,8533]
===
match
---
trailer [10888,10897]
trailer [10835,10844]
===
match
---
trailer [17625,17641]
trailer [17572,17588]
===
match
---
comparison [47447,47527]
comparison [46586,46666]
===
match
---
name: max_tis [10889,10896]
name: max_tis [10836,10843]
===
match
---
trailer [5453,5464]
trailer [5400,5411]
===
match
---
name: log [16242,16245]
name: log [16189,16192]
===
match
---
expr_stmt [11478,11553]
expr_stmt [11425,11500]
===
match
---
string: "open" [45976,45982]
string: "open" [45115,45121]
===
match
---
operator: , [18618,18619]
operator: , [18565,18566]
===
match
---
atom_expr [12877,13123]
atom_expr [12824,13070]
===
match
---
param [44727,44732]
param [43866,43871]
===
match
---
simple_stmt [44852,44904]
simple_stmt [43991,44043]
===
match
---
operator: , [14436,14437]
operator: , [14383,14384]
===
match
---
comparison [20126,20153]
comparison [20073,20100]
===
match
---
name: self [38763,38767]
name: self [37945,37949]
===
match
---
atom_expr [11562,11662]
atom_expr [11509,11609]
===
match
---
name: ti [18016,18018]
name: ti [17963,17965]
===
match
---
name: and_ [35956,35960]
name: and_ [35181,35185]
===
match
---
trailer [22320,22341]
trailer [22267,22288]
===
match
---
trailer [48797,48804]
trailer [47936,47943]
===
match
---
atom_expr [21584,21596]
atom_expr [21531,21543]
===
match
---
trailer [44385,44392]
trailer [43524,43531]
===
match
---
atom_expr [21894,21975]
atom_expr [21841,21922]
===
match
---
atom_expr [13170,13279]
atom_expr [13117,13226]
===
match
---
name: log [14229,14232]
name: log [14176,14179]
===
match
---
name: TI [17915,17917]
name: TI [17862,17864]
===
match
---
operator: = [15288,15289]
operator: = [15235,15236]
===
match
---
tfpdef [44750,44788]
tfpdef [43889,43927]
===
match
---
name: info [29722,29726]
name: info [29669,29673]
===
match
---
name: in_ [39605,39608]
name: in_ [38787,38790]
===
match
---
trailer [8470,8476]
trailer [8417,8423]
===
match
---
operator: , [17240,17241]
operator: , [17187,17188]
===
match
---
name: self [35329,35333]
name: self [34554,34558]
===
match
---
trailer [41849,41855]
trailer [40988,40994]
===
match
---
atom_expr [11713,11730]
atom_expr [11660,11677]
===
match
---
name: gauge [45927,45932]
name: gauge [45066,45071]
===
match
---
operator: , [12217,12218]
operator: , [12164,12165]
===
match
---
simple_stmt [51364,51453]
simple_stmt [50503,50592]
===
match
---
simple_stmt [17129,17195]
simple_stmt [17076,17142]
===
match
---
name: pools [10730,10735]
name: pools [10677,10682]
===
match
---
name: Pool [45823,45827]
name: Pool [44962,44966]
===
match
---
funcdef [45082,45711]
funcdef [44221,44850]
===
match
---
number: 1 [41363,41364]
number: 1 [40502,40503]
===
match
---
arglist [20365,20389]
arglist [20312,20336]
===
match
---
name: query [47301,47306]
name: query [46440,46445]
===
match
---
simple_stmt [18050,18069]
simple_stmt [17997,18016]
===
match
---
string: 'core' [36540,36546]
string: 'core' [35765,35771]
===
match
---
simple_stmt [44406,44413]
simple_stmt [43545,43552]
===
match
---
name: self [42591,42595]
name: self [41730,41734]
===
match
---
name: all [8580,8583]
name: all [8527,8530]
===
match
---
operator: != [10407,10409]
operator: != [10354,10356]
===
match
---
operator: , [38516,38517]
operator: , [37698,37699]
===
match
---
tfpdef [34723,34741]
tfpdef [33948,33966]
===
match
---
not_test [28963,28979]
not_test [28910,28926]
===
match
---
trailer [11869,11884]
trailer [11816,11831]
===
match
---
operator: = [35083,35084]
operator: = [34308,34309]
===
match
---
trailer [29717,29721]
trailer [29664,29668]
===
match
---
name: exception [23116,23125]
name: exception [23063,23072]
===
match
---
atom_expr [36677,36692]
atom_expr [35902,35917]
===
match
---
simple_stmt [49236,49259]
simple_stmt [48375,48398]
===
match
---
name: State [47597,47602]
name: State [46736,46741]
===
match
---
name: Tuple [8391,8396]
name: Tuple [8338,8343]
===
match
---
trailer [18540,18633]
trailer [18487,18580]
===
match
---
name: state [21047,21052]
name: state [20994,20999]
===
match
---
simple_stmt [14003,14033]
simple_stmt [13950,13980]
===
match
---
atom_expr [21569,21582]
atom_expr [21516,21529]
===
match
---
name: dag [40555,40558]
name: dag [39737,39740]
===
match
---
simple_stmt [34970,35069]
simple_stmt [34195,34294]
===
match
---
operator: , [2467,2468]
operator: , [2414,2415]
===
match
---
name: self [44505,44509]
name: self [43644,43648]
===
match
---
trailer [48038,48042]
trailer [47177,47181]
===
match
---
name: self [5014,5018]
name: self [4961,4965]
===
match
---
name: dag_run [43504,43511]
name: dag_run [42643,42650]
===
match
---
name: _update_state [41381,41394]
name: _update_state [40520,40533]
===
match
---
simple_stmt [21813,21870]
simple_stmt [21760,21817]
===
match
---
simple_stmt [4232,4301]
simple_stmt [4179,4248]
===
match
---
name: str [11708,11711]
name: str [11655,11658]
===
match
---
fstring_start: f' [17064,17066]
fstring_start: f' [17011,17013]
===
match
---
parameters [2620,2622]
parameters [2567,2569]
===
match
---
trailer [36270,36274]
trailer [35495,35499]
===
match
---
string: "Sending %s to executor with priority %s and queue %s" [18732,18786]
string: "Sending %s to executor with priority %s and queue %s" [18679,18733]
===
match
---
operator: , [40707,40708]
operator: , [39868,39869]
===
match
---
name: self [5136,5140]
name: self [5083,5087]
===
match
---
atom_expr [36918,36930]
atom_expr [36143,36155]
===
match
---
trailer [22838,22870]
trailer [22785,22817]
===
match
---
name: getint [46734,46740]
name: getint [45873,45879]
===
match
---
trailer [31817,31833]
trailer [31764,31780]
===
match
---
name: executor [20182,20190]
name: executor [20129,20137]
===
match
---
name: dag_id [42792,42798]
name: dag_id [41931,41937]
===
match
---
name: State [47404,47409]
name: State [46543,46548]
===
match
---
name: DagModel [1633,1641]
name: DagModel [1580,1588]
===
match
---
name: str [8685,8688]
name: str [8632,8635]
===
match
---
name: task_concurrency_limit [14948,14970]
name: task_concurrency_limit [14895,14917]
===
match
---
name: tis [21994,21997]
name: tis [21941,21944]
===
match
---
trailer [21002,21008]
trailer [20949,20955]
===
match
---
argument [23417,23451]
argument [23364,23398]
===
match
---
name: num_failed [47254,47264]
name: num_failed [46393,46403]
===
match
---
atom_expr [6944,6959]
atom_expr [6891,6906]
===
match
---
string: 'scheduler' [27256,27267]
string: 'scheduler' [27203,27214]
===
match
---
operator: , [41892,41893]
operator: , [41031,41032]
===
match
---
name: ti [45342,45344]
name: ti [44481,44483]
===
match
---
string: "Reset the following %s orphaned TaskInstances:\n\t%s" [49954,50008]
string: "Reset the following %s orphaned TaskInstances:\n\t%s" [49093,49147]
===
match
---
name: current_task_concurrency [15803,15827]
name: current_task_concurrency [15750,15774]
===
match
---
name: dr [39629,39631]
name: dr [38811,38813]
===
match
---
funcdef [18983,20490]
funcdef [18930,20437]
===
match
---
name: callback_tuples [33241,33256]
name: callback_tuples [32466,32481]
===
match
---
atom_expr [28320,28348]
atom_expr [28267,28295]
===
match
---
name: dag_run [41400,41407]
name: dag_run [40539,40546]
===
match
---
name: _run_scheduler_loop [25057,25076]
name: _run_scheduler_loop [25004,25023]
===
match
---
trailer [34616,34618]
trailer [33841,33843]
===
match
---
atom_expr [39885,39903]
atom_expr [39067,39085]
===
match
---
expr_stmt [10679,10766]
expr_stmt [10626,10713]
===
match
---
name: kwargs [5197,5203]
name: kwargs [5144,5150]
===
match
---
simple_stmt [34631,34653]
simple_stmt [33856,33878]
===
match
---
name: dag_id [22993,22999]
name: dag_id [22940,22946]
===
match
---
trailer [23203,23210]
trailer [23150,23157]
===
match
---
atom_expr [25359,25399]
atom_expr [25306,25346]
===
match
---
trailer [9876,9883]
trailer [9823,9830]
===
match
---
name: _debug_dump [5989,6000]
name: _debug_dump [5936,5947]
===
match
---
trailer [10539,10549]
trailer [10486,10496]
===
match
---
expr_stmt [11672,11751]
expr_stmt [11619,11698]
===
match
---
atom_expr [36038,36059]
atom_expr [35263,35284]
===
match
---
trailer [8679,8689]
trailer [8626,8636]
===
match
---
if_stmt [25356,25626]
if_stmt [25303,25573]
===
match
---
atom [51068,51295]
atom [50207,50434]
===
match
---
trailer [28574,28576]
trailer [28521,28523]
===
match
---
name: Stats [46284,46289]
name: Stats [45423,45428]
===
match
---
simple_stmt [47790,47855]
simple_stmt [46929,46994]
===
match
---
name: DagModel [35358,35366]
name: DagModel [34583,34591]
===
match
---
simple_stmt [34188,34210]
simple_stmt [33413,33435]
===
match
---
param [44005,44010]
param [43144,43149]
===
match
---
name: duration [28937,28945]
name: duration [28884,28892]
===
match
---
name: num_starving_tasks_total [17169,17193]
name: num_starving_tasks_total [17116,17140]
===
match
---
name: QUEUED [36940,36946]
name: QUEUED [36165,36171]
===
match
---
suite [34251,34591]
suite [33476,33816]
===
match
---
operator: , [4546,4547]
operator: , [4493,4494]
===
match
---
name: get_run_data_interval [40392,40413]
name: get_run_data_interval [39574,39595]
===
match
---
name: seconds [24486,24493]
name: seconds [24433,24440]
===
match
---
testlist_comp [23755,23780]
testlist_comp [23702,23727]
===
match
---
funcdef [39785,40585]
funcdef [38967,39767]
===
match
---
operator: >= [14508,14510]
operator: >= [14455,14457]
===
match
---
operator: } [51235,51236]
operator: } [50374,50375]
===
match
---
operator: , [41398,41399]
operator: , [40537,40538]
===
match
---
name: State [48504,48509]
name: State [47643,47648]
===
match
---
name: airflow [1977,1984]
name: airflow [1924,1931]
===
match
---
name: TaskInstance [50819,50831]
name: TaskInstance [49958,49970]
===
match
---
operator: > [17536,17537]
operator: > [17483,17484]
===
match
---
name: self [26250,26254]
name: self [26197,26201]
===
match
---
string: "Next timed event is in %f" [28823,28850]
string: "Next timed event is in %f" [28770,28797]
===
match
---
trailer [41343,41359]
trailer [40482,40498]
===
match
---
suite [25400,25626]
suite [25347,25573]
===
match
---
atom_expr [45248,45267]
atom_expr [44387,44406]
===
match
---
atom [21554,21597]
atom [21501,21544]
===
match
---
name: getint [24403,24409]
name: getint [24350,24356]
===
match
---
name: str [12079,12082]
name: str [12026,12029]
===
match
---
name: processor_agent [6399,6414]
name: processor_agent [6346,6361]
===
match
---
name: state [42484,42489]
name: state [41623,41628]
===
match
---
simple_stmt [16237,16571]
simple_stmt [16184,16518]
===
match
---
expr_stmt [5136,5162]
expr_stmt [5083,5109]
===
match
---
atom_expr [51099,51114]
atom_expr [50238,50253]
===
match
---
name: self [44818,44822]
name: self [43957,43961]
===
match
---
trailer [25056,25076]
trailer [25003,25023]
===
match
---
operator: , [24770,24771]
operator: , [24717,24718]
===
match
---
name: super [7430,7435]
name: super [7377,7382]
===
match
---
expr_stmt [7490,7590]
expr_stmt [7437,7537]
===
match
---
trailer [10620,10660]
trailer [10567,10607]
===
match
---
name: states [7837,7843]
name: states [7784,7790]
===
match
---
operator: , [45878,45879]
operator: , [45017,45018]
===
match
---
suite [17540,18003]
suite [17487,17950]
===
match
---
atom_expr [49153,49214]
atom_expr [48292,48353]
===
match
---
atom_expr [5445,5473]
atom_expr [5392,5420]
===
match
---
trailer [2567,2574]
trailer [2514,2521]
===
match
---
name: to_reset [49519,49527]
name: to_reset [48658,48666]
===
match
---
trailer [17671,17678]
trailer [17618,17625]
===
match
---
trailer [15257,15264]
trailer [15204,15211]
===
match
---
name: ti [18697,18699]
name: ti [18644,18646]
===
match
---
expr_stmt [14134,14207]
expr_stmt [14081,14154]
===
match
---
trailer [42315,42322]
trailer [41454,41461]
===
match
---
atom_expr [20774,20808]
atom_expr [20721,20755]
===
match
---
name: float [4513,4518]
name: float [4460,4465]
===
match
---
arglist [33312,33336]
arglist [32537,32561]
===
match
---
trailer [23294,23312]
trailer [23241,23259]
===
match
---
name: QUEUED [17872,17878]
name: QUEUED [17819,17825]
===
match
---
decorated [34658,34879]
decorated [33883,34104]
===
match
---
argument [7447,7480]
argument [7394,7427]
===
match
---
name: all [11082,11085]
name: all [11029,11032]
===
match
---
atom_expr [28416,28437]
atom_expr [28363,28384]
===
match
---
name: dm [36305,36307]
name: dm [35530,35532]
===
match
---
simple_stmt [25052,25079]
simple_stmt [24999,25026]
===
match
---
name: request [23362,23369]
name: request [23309,23316]
===
match
---
name: to_reset [49802,49810]
name: to_reset [48941,48949]
===
match
---
simple_stmt [6878,6902]
simple_stmt [6825,6849]
===
match
---
argument [27302,27316]
argument [27249,27263]
===
match
---
trailer [10276,10281]
trailer [10223,10228]
===
match
---
suite [33492,34210]
suite [32717,33435]
===
match
---
operator: % [23554,23555]
operator: % [23501,23502]
===
match
---
operator: = [23264,23265]
operator: = [23211,23212]
===
match
---
name: dag_max_active_tasks_map [16912,16936]
name: dag_max_active_tasks_map [16859,16883]
===
match
---
atom_expr [36294,36303]
atom_expr [35519,35528]
===
match
---
simple_stmt [18689,18706]
simple_stmt [18636,18653]
===
match
---
expr_stmt [35886,36173]
expr_stmt [35111,35398]
===
match
---
name: ti [13227,13229]
name: ti [13174,13176]
===
match
---
name: num_starving_tasks_total [16635,16659]
name: num_starving_tasks_total [16582,16606]
===
match
---
name: float [6953,6958]
name: float [6900,6905]
===
match
---
name: dag_id [48798,48804]
name: dag_id [47937,47943]
===
match
---
trailer [14180,14190]
trailer [14127,14137]
===
match
---
name: list [12195,12199]
name: list [12142,12146]
===
match
---
name: task_instance_str [17345,17362]
name: task_instance_str [17292,17309]
===
match
---
name: all [35160,35163]
name: all [34385,34388]
===
match
---
name: Stats [46097,46102]
name: Stats [45236,45241]
===
match
---
name: self [15883,15887]
name: self [15830,15834]
===
match
---
string: "All pools are full!" [9949,9970]
string: "All pools are full!" [9896,9917]
===
match
---
name: State [22288,22293]
name: State [22235,22240]
===
match
---
name: num_finished_events [28458,28477]
name: num_finished_events [28405,28424]
===
match
---
trailer [17376,17409]
trailer [17323,17356]
===
match
---
name: query [21902,21907]
name: query [21849,21854]
===
match
---
operator: = [20175,20176]
operator: = [20122,20123]
===
match
---
name: selectinload [1193,1205]
name: selectinload [1193,1205]
===
match
---
atom_expr [31847,31882]
atom_expr [31794,31829]
===
match
---
name: call_regular_interval [27572,27593]
name: call_regular_interval [27519,27540]
===
match
---
operator: , [46142,46143]
operator: , [45281,45282]
===
match
---
trailer [8579,8583]
trailer [8526,8530]
===
match
---
trailer [44768,44788]
trailer [43907,43927]
===
match
---
name: items [21003,21008]
name: items [20950,20955]
===
match
---
name: dags_needing_dagruns [35094,35114]
name: dags_needing_dagruns [34319,34339]
===
match
---
name: priority_weight [13230,13245]
name: priority_weight [13177,13192]
===
match
---
operator: , [1038,1039]
operator: , [1038,1039]
===
match
---
parameters [39102,39149]
parameters [38284,38331]
===
match
---
tfpdef [50525,50541]
tfpdef [49664,49680]
===
match
---
name: log [25422,25425]
name: log [25369,25372]
===
match
---
simple_stmt [25811,25817]
simple_stmt [25758,25764]
===
match
---
name: List [18172,18176]
name: List [18119,18123]
===
match
---
name: timedelta [964,973]
name: timedelta [964,973]
===
match
---
name: Stats [17273,17278]
name: Stats [17220,17225]
===
match
---
trailer [9838,9887]
trailer [9785,9834]
===
match
---
tfpdef [39126,39142]
tfpdef [38308,38324]
===
match
---
operator: , [1843,1844]
operator: , [1790,1791]
===
match
---
trailer [10514,10521]
trailer [10461,10468]
===
match
---
name: Tuple [12068,12073]
name: Tuple [12015,12020]
===
match
---
operator: = [24550,24551]
operator: = [24497,24498]
===
match
---
trailer [27432,27441]
trailer [27379,27388]
===
match
---
trailer [27620,27672]
trailer [27567,27619]
===
match
---
trailer [15432,15441]
trailer [15379,15388]
===
match
---
name: dm [36294,36296]
name: dm [35519,35521]
===
match
---
name: sys [891,894]
name: sys [891,894]
===
match
---
trailer [48509,48517]
trailer [47648,47656]
===
match
---
trailer [5430,5442]
trailer [5377,5389]
===
match
---
arglist [27442,27502]
arglist [27389,27449]
===
match
---
parameters [30015,30030]
parameters [29962,29977]
===
match
---
name: models [1655,1661]
name: models [1602,1608]
===
match
---
name: _debug_dump [6457,6468]
name: _debug_dump [6404,6415]
===
match
---
suite [43192,43300]
suite [42331,42439]
===
match
---
operator: - [10621,10622]
operator: - [10568,10569]
===
match
---
operator: = [46840,46841]
operator: = [45979,45980]
===
match
---
trailer [10818,10825]
trailer [10765,10772]
===
match
---
comparison [22509,22533]
comparison [22456,22480]
===
match
---
operator: , [7930,7931]
operator: , [7877,7878]
===
match
---
import_as_names [1070,1099]
import_as_names [1070,1099]
===
match
---
trailer [48032,48038]
trailer [47171,47177]
===
match
---
atom_expr [17273,17335]
atom_expr [17220,17282]
===
match
---
operator: = [4185,4186]
operator: = [4132,4133]
===
match
---
atom [23754,23781]
atom [23701,23728]
===
match
---
string: 'dag_file_processor_timeout' [24418,24446]
string: 'dag_file_processor_timeout' [24365,24393]
===
match
---
tfpdef [4342,4353]
tfpdef [4289,4300]
===
match
---
argument [5706,5725]
argument [5653,5672]
===
match
---
trailer [24984,24986]
trailer [24931,24933]
===
match
---
trailer [44305,44311]
trailer [43444,43450]
===
match
---
annassign [21029,21034]
annassign [20976,20981]
===
match
---
string: "Executor reports execution of %s.%s run_id=%s exited with status %s for try_number %s" [21275,21362]
string: "Executor reports execution of %s.%s run_id=%s exited with status %s for try_number %s" [21222,21309]
===
match
---
trailer [10450,10460]
trailer [10397,10407]
===
match
---
subscriptlist [8615,8623]
subscriptlist [8562,8570]
===
match
---
arglist [39410,39440]
arglist [38592,38622]
===
match
---
operator: , [32808,32809]
operator: , [32213,32214]
===
match
---
name: fallback [27659,27667]
name: fallback [27606,27614]
===
match
---
simple_stmt [27200,27377]
simple_stmt [27147,27324]
===
match
---
atom_expr [46649,46710]
atom_expr [45788,45849]
===
match
---
operator: ** [49063,49065]
operator: ** [48202,48204]
===
match
---
atom_expr [27200,27376]
atom_expr [27147,27323]
===
match
---
operator: } [46039,46040]
operator: } [45178,45179]
===
match
---
param [35335,35368]
param [34560,34593]
===
match
---
atom_expr [2536,2555]
atom_expr [2483,2502]
===
match
---
simple_stmt [39885,39924]
simple_stmt [39067,39106]
===
match
---
name: session [9631,9638]
name: session [9578,9585]
===
match
---
testlist_star_expr [22145,22156]
testlist_star_expr [22092,22103]
===
match
---
name: session [38671,38678]
name: session [37853,37860]
===
match
---
arith_expr [49486,49528]
arith_expr [48625,48667]
===
match
---
atom_expr [35956,36100]
atom_expr [35181,35325]
===
match
---
name: log [23880,23883]
name: log [23827,23830]
===
match
---
arglist [9615,9646]
arglist [9562,9593]
===
match
---
atom_expr [22551,22598]
atom_expr [22498,22545]
===
match
---
argument [47510,47525]
argument [46649,46664]
===
match
---
atom_expr [8391,8411]
atom_expr [8338,8358]
===
match
---
lambdef [39373,39382]
lambdef [38555,38564]
===
match
---
suite [37273,37299]
suite [36498,36524]
===
match
---
atom_expr [50857,50885]
atom_expr [49996,50024]
===
match
---
atom_expr [45530,45575]
atom_expr [44669,44714]
===
match
---
operator: , [5193,5194]
operator: , [5140,5141]
===
match
---
trailer [10357,10429]
trailer [10304,10376]
===
match
---
trailer [36687,36692]
trailer [35912,35917]
===
match
---
atom_expr [5893,5945]
atom_expr [5840,5892]
===
match
---
atom_expr [24147,24172]
atom_expr [24094,24119]
===
match
---
expr_stmt [14050,14117]
expr_stmt [13997,14064]
===
match
---
simple_stmt [18647,18677]
simple_stmt [18594,18624]
===
match
---
simple_stmt [6609,6616]
simple_stmt [6556,6563]
===
insert-node
---
name: SchedulerJob [2805,2817]
to
classdef [2852,51453]
at 0
===
insert-node
---
name: BaseJob [2818,2825]
to
classdef [2852,51453]
at 1
===
insert-tree
---
simple_stmt [2832,4111]
    string: """     This SchedulerJob runs for a specific time interval and schedules the jobs     that are ready to run. It figures out the latest runs for each     task and sees if the dependencies for the next schedules are met.     If so, it creates appropriate TaskInstances and sends run commands to the     executor. It does this for each task in each DAG and repeats.      :param subdir: directory containing Python files with Airflow DAG         definitions, or a specific path to a file     :type subdir: str     :param num_runs: The number of times to run the scheduling loop. If you         have a large number of DAG files this could complete before each file         has been parsed. -1 for unlimited times.     :type num_runs: int     :param num_times_parse_dags: The number of times to try to parse each DAG file.         -1 for unlimited times.     :type num_times_parse_dags: int     :param processor_poll_interval: The number of seconds to wait between         polls of running processors     :type processor_poll_interval: int     :param do_pickle: once a DAG object is obtained by executing the Python         file, whether to serialize the DAG object to the DB     :type do_pickle: bool     :param log: override the default Logger     :type log: logging.Logger     """ [2832,4110]
to
suite [2880,51453]
at 0
===
move-tree
---
simple_stmt [37333,37394]
    expr_stmt [37333,37393]
        name: dag [37333,37336]
        operator: = [37337,37338]
        atom_expr [37339,37393]
            name: self [37339,37343]
            trailer [37343,37350]
                name: dagbag [37344,37350]
            trailer [37350,37358]
                name: get_dag [37351,37358]
            trailer [37358,37393]
                arglist [37359,37392]
                    atom_expr [37359,37375]
                        name: dag_model [37359,37368]
                        trailer [37368,37375]
                            name: dag_id [37369,37375]
                    operator: , [37375,37376]
                    argument [37377,37392]
                        name: session [37377,37384]
                        operator: = [37384,37385]
                        name: session [37385,37392]
to
suite [37066,38920]
at 2
===
insert-node
---
if_stmt [36610,36742]
to
suite [37066,38920]
at 3
===
move-tree
---
simple_stmt [40653,40726]
    expr_stmt [40653,40725]
        name: dag [40653,40656]
        operator: = [40657,40658]
        atom_expr [40659,40670]
            name: dag_run [40659,40666]
            trailer [40666,40670]
                name: dag [40667,40670]
        operator: = [40671,40672]
        atom_expr [40673,40725]
            name: self [40673,40677]
            trailer [40677,40684]
                name: dagbag [40678,40684]
            trailer [40684,40692]
                name: get_dag [40685,40692]
            trailer [40692,40725]
                arglist [40693,40724]
                    atom_expr [40693,40707]
                        name: dag_run [40693,40700]
                        trailer [40700,40707]
                            name: dag_id [40701,40707]
                    operator: , [40707,40708]
                    argument [40709,40724]
                        name: session [40709,40716]
                        operator: = [40716,40717]
                        name: session [40717,40724]
to
suite [40618,41409]
at 0
===
insert-node
---
if_stmt [39899,40029]
to
suite [40618,41409]
at 1
===
move-tree
---
suite [32739,32890]
    simple_stmt [32760,32819]
        expr_stmt [32760,32818]
            name: callback_to_run [32760,32775]
            operator: = [32776,32777]
            atom_expr [32778,32818]
                name: self [32778,32782]
                trailer [32782,32800]
                    name: _schedule_dag_run [32783,32800]
                trailer [32800,32818]
                    arglist [32801,32817]
                        name: dag_run [32801,32808]
                        operator: , [32808,32809]
                        name: session [32810,32817]
    simple_stmt [32839,32890]
        atom_expr [32839,32889]
            name: callback_tuples [32839,32854]
            trailer [32854,32861]
                name: append [32855,32861]
            trailer [32861,32889]
                atom [32862,32888]
                    testlist_comp [32863,32887]
                        name: dag_run [32863,32870]
                        operator: , [32870,32871]
                        name: callback_to_run [32872,32887]
to
for_stmt [32177,33066]
at 2
===
insert-node
---
not_test [36613,36620]
to
if_stmt [36610,36742]
at 0
===
move-tree
---
suite [37435,37560]
    simple_stmt [37452,37535]
        atom_expr [37452,37534]
            name: self [37452,37456]
            trailer [37456,37460]
                name: log [37457,37460]
            trailer [37460,37470]
                name: exception [37461,37470]
            trailer [37470,37534]
                arglist [37471,37533]
                    string: "DAG '%s' not found in serialized_dag table" [37471,37515]
                    operator: , [37515,37516]
                    atom_expr [37517,37533]
                        name: dag_model [37517,37526]
                        trailer [37526,37533]
                            name: dag_id [37527,37533]
    simple_stmt [37551,37560]
to
if_stmt [36610,36742]
at 1
===
insert-node
---
not_test [39902,39909]
to
if_stmt [39899,40029]
at 0
===
move-tree
---
suite [40767,40890]
    simple_stmt [40784,40865]
        atom_expr [40784,40864]
            name: self [40784,40788]
            trailer [40788,40792]
                name: log [40789,40792]
            trailer [40792,40802]
                name: exception [40793,40802]
            trailer [40802,40864]
                arglist [40803,40863]
                    string: "DAG '%s' not found in serialized_dag table" [40803,40847]
                    operator: , [40847,40848]
                    atom_expr [40849,40863]
                        name: dag_run [40849,40856]
                        trailer [40856,40863]
                            name: dag_id [40857,40863]
    simple_stmt [40881,40890]
to
if_stmt [39899,40029]
at 1
===
update-node
---
name: SerializedDagNotFound [37413,37434]
replace SerializedDagNotFound by dag
===
move-tree
---
name: SerializedDagNotFound [37413,37434]
to
not_test [36613,36620]
at 0
===
update-node
---
name: SerializedDagNotFound [40745,40766]
replace SerializedDagNotFound by dag
===
move-tree
---
name: SerializedDagNotFound [40745,40766]
to
not_test [39902,39909]
at 0
===
update-node
---
name: exception [37461,37470]
replace exception by error
===
update-node
---
name: exception [40793,40802]
replace exception by error
===
delete-tree
---
simple_stmt [1407,1460]
    import_from [1407,1459]
        dotted_name [1412,1430]
            name: airflow [1412,1419]
            name: exceptions [1420,1430]
        name: SerializedDagNotFound [1438,1459]
===
delete-node
---
name: SchedulerJob [2858,2870]
===
===
delete-node
---
name: BaseJob [2871,2878]
===
===
delete-tree
---
simple_stmt [2885,4164]
    string: """     This SchedulerJob runs for a specific time interval and schedules the jobs     that are ready to run. It figures out the latest runs for each     task and sees if the dependencies for the next schedules are met.     If so, it creates appropriate TaskInstances and sends run commands to the     executor. It does this for each task in each DAG and repeats.      :param subdir: directory containing Python files with Airflow DAG         definitions, or a specific path to a file     :type subdir: str     :param num_runs: The number of times to run the scheduling loop. If you         have a large number of DAG files this could complete before each file         has been parsed. -1 for unlimited times.     :type num_runs: int     :param num_times_parse_dags: The number of times to try to parse each DAG file.         -1 for unlimited times.     :type num_times_parse_dags: int     :param processor_poll_interval: The number of seconds to wait between         polls of running processors     :type processor_poll_interval: int     :param do_pickle: once a DAG object is obtained by executing the Python         file, whether to serialize the DAG object to the DB     :type do_pickle: bool     :param log: override the default Logger     :type log: logging.Logger     """ [2885,4163]
===
delete-node
---
try_stmt [32735,33066]
===
===
delete-node
---
suite [32201,33066]
===
===
delete-node
---
suite [37316,37394]
===
===
delete-node
---
except_clause [37406,37434]
===
===
delete-node
---
try_stmt [37312,37560]
===
===
delete-node
---
suite [40636,40726]
===
===
delete-node
---
except_clause [40738,40766]
===
===
delete-node
---
try_stmt [40632,40890]
===
