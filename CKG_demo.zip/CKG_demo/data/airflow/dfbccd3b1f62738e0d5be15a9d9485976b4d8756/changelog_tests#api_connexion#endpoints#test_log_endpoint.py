===
match
---
fstring_expr [6356,6370]
fstring_expr [6356,6370]
===
match
---
atom [4293,4328]
atom [4293,4328]
===
match
---
atom [6414,6444]
atom [6414,6444]
===
match
---
comparison [8439,8505]
comparison [9554,9620]
===
match
---
atom [6476,6499]
atom [6476,6499]
===
match
---
name: session [7048,7055]
name: session [7048,7055]
===
match
---
name: execution_date [3224,3238]
name: execution_date [3224,3238]
===
match
---
atom_expr [4200,4237]
atom_expr [4200,4237]
===
match
---
string: 'text/plain' [12611,12623]
string: 'text/plain' [13726,13738]
===
match
---
trailer [4736,4795]
trailer [4736,4795]
===
match
---
trailer [10840,10848]
trailer [11955,11963]
===
match
---
string: '1st line' [9454,9464]
string: '1st line' [10569,10579]
===
match
---
atom_expr [9868,9916]
atom_expr [10983,11031]
===
match
---
operator: = [7485,7486]
operator: = [7485,7486]
===
match
---
argument [11462,11500]
argument [12577,12615]
===
match
---
dictorsetmaker [11533,11554]
dictorsetmaker [12648,12669]
===
match
---
argument [2625,2655]
argument [2625,2655]
===
match
---
name: mock [907,911]
name: mock [907,911]
===
match
---
string: 'status' [11641,11649]
string: 'status' [12756,12764]
===
match
---
trailer [4220,4236]
trailer [4220,4236]
===
match
---
name: airflow [1044,1051]
name: airflow [1044,1051]
===
match
---
name: shutil [836,842]
name: shutil [836,842]
===
match
---
operator: } [6390,6391]
operator: } [6390,6391]
===
match
---
name: configure_logging [4608,4625]
name: configure_logging [4608,4625]
===
match
---
string: 'detail' [11036,11044]
string: 'detail' [12151,12159]
===
match
---
string: 'filename_template' [3716,3735]
string: 'filename_template' [3716,3735]
===
match
---
comparison [12721,12748]
comparison [13836,13863]
===
match
---
atom [2144,2392]
atom [2144,2392]
===
match
---
atom_expr [8065,8087]
atom_expr [9180,9202]
===
match
---
name: merge [5147,5152]
name: merge [5147,5152]
===
match
---
operator: , [10614,10615]
operator: , [11729,11730]
===
match
---
simple_stmt [10634,10663]
simple_stmt [11749,11778]
===
match
---
param [3061,3068]
param [3061,3068]
===
match
---
name: headers [12137,12144]
name: headers [13252,13259]
===
match
---
trailer [2982,3001]
trailer [2982,3001]
===
match
---
name: environ_overrides [8328,8345]
name: environ_overrides [9443,9460]
===
match
---
name: test_get_logs_with_metadata_as_download_large_file [8536,8586]
name: test_get_logs_with_metadata_as_download_large_file [9651,9701]
===
match
---
strings [9183,9309]
strings [10298,10424]
===
match
---
atom_expr [4108,4132]
atom_expr [4108,4132]
===
match
---
name: token [12361,12366]
name: token [13476,13481]
===
match
---
atom [1890,1964]
atom [1890,1964]
===
match
---
trailer [3247,3253]
trailer [3247,3253]
===
match
---
atom_expr [7698,7718]
atom_expr [7698,7718]
===
match
---
argument [4524,4536]
argument [4524,4536]
===
match
---
atom_expr [4564,4586]
atom_expr [4564,4586]
===
match
---
fstring_string: /dagRuns/TEST_DAG_RUN_ID/ [8222,8247]
fstring_string: /dagRuns/TEST_DAG_RUN_ID/ [9337,9362]
===
match
---
trailer [5455,5457]
trailer [5455,5457]
===
match
---
name: config [7118,7124]
name: config [7118,7124]
===
match
---
name: dumps [6194,6199]
name: dumps [6194,6199]
===
match
---
trailer [2819,2827]
trailer [2819,2827]
===
match
---
name: permissions [1314,1325]
name: permissions [1314,1325]
===
match
---
trailer [4512,4523]
trailer [4512,4523]
===
match
---
expr_stmt [3527,3581]
expr_stmt [3527,3581]
===
match
---
atom_expr [2313,2340]
atom_expr [2313,2340]
===
match
---
arglist [4844,4865]
arglist [4844,4865]
===
match
---
number: 403 [12745,12748]
number: 403 [13860,13863]
===
match
---
name: session [3419,3426]
name: session [3419,3426]
===
match
---
operator: , [4303,4304]
operator: , [4303,4304]
===
match
---
name: key [11892,11895]
name: key [13007,13010]
===
match
---
trailer [11987,11991]
trailer [13102,13106]
===
match
---
trailer [8657,8663]
trailer [9772,9778]
===
match
---
operator: = [4671,4672]
operator: = [4671,4672]
===
match
---
name: dagrun_model [3079,3091]
name: dagrun_model [3079,3091]
===
match
---
trailer [5924,5938]
trailer [5924,5938]
===
match
---
name: settings [4599,4607]
name: settings [4599,4607]
===
match
---
string: "test" [10971,10977]
string: "test" [12086,12092]
===
match
---
string: 'Accept' [12146,12154]
string: 'Accept' [13261,13269]
===
match
---
name: os [5314,5316]
name: os [5314,5316]
===
match
---
atom_expr [9873,9901]
atom_expr [10988,11016]
===
match
---
operator: { [7400,7401]
operator: { [7400,7401]
===
match
---
string: 'REMOTE_USER' [9396,9409]
string: 'REMOTE_USER' [10511,10524]
===
match
---
operator: { [10893,10894]
operator: { [12008,12009]
===
match
---
name: replace [5285,5292]
name: replace [5285,5292]
===
match
---
fstring_string: api/v1/dags/ [11327,11339]
fstring_string: api/v1/dags/ [12442,12454]
===
match
---
trailer [2926,2934]
trailer [2926,2934]
===
match
---
simple_stmt [4829,4867]
simple_stmt [4829,4867]
===
match
---
name: self [5760,5764]
name: self [5760,5764]
===
match
---
atom_expr [3924,3942]
atom_expr [3924,3942]
===
match
---
testlist_comp [8976,9002]
testlist_comp [10091,10117]
===
match
---
atom_expr [2412,2495]
atom_expr [2412,2495]
===
match
---
name: response [10134,10142]
name: response [11249,11257]
===
match
---
trailer [2769,2773]
trailer [2769,2773]
===
match
---
name: decode [10538,10544]
name: decode [11653,11659]
===
match
---
name: self [5190,5194]
name: self [5190,5194]
===
match
---
argument [3344,3365]
argument [3344,3365]
===
match
---
name: self [5837,5841]
name: self [5837,5841]
===
match
---
dotted_name [1240,1263]
dotted_name [1240,1263]
===
match
---
atom_expr [4776,4793]
atom_expr [4776,4793]
===
match
---
atom_expr [7971,7999]
atom_expr [9086,9114]
===
match
---
name: response [8439,8447]
name: response [9554,9562]
===
match
---
operator: @ [1829,1830]
operator: @ [1829,1830]
===
match
---
trailer [9982,9996]
trailer [11097,11111]
===
match
---
operator: { [8921,8922]
operator: { [10036,10037]
===
match
---
name: TaskInstance [4931,4943]
name: TaskInstance [4931,4943]
===
match
---
expr_stmt [9961,9996]
expr_stmt [11076,11111]
===
match
---
string: 'should never be read' [9643,9665]
string: 'should never be read' [10758,10780]
===
match
---
name: response [12207,12215]
name: response [13322,13330]
===
match
---
name: setUp [2666,2671]
name: setUp [2666,2671]
===
match
---
atom_expr [9919,9951]
atom_expr [11034,11066]
===
match
---
operator: { [12145,12146]
operator: { [13260,13261]
===
match
---
name: serializer [7147,7157]
name: serializer [7147,7157]
===
match
---
fstring_string: taskInstances/ [11411,11425]
fstring_string: taskInstances/ [12526,12540]
===
match
---
trailer [7761,7768]
trailer [7761,7768]
===
match
---
name: DagRun [1214,1220]
name: DagRun [1214,1220]
===
match
---
trailer [9686,9693]
trailer [10801,10808]
===
match
---
assert_stmt [9510,9560]
assert_stmt [10625,10675]
===
match
---
expr_stmt [4498,4537]
expr_stmt [4498,4537]
===
match
---
operator: , [6444,6445]
operator: , [6444,6445]
===
match
---
operator: { [6356,6357]
operator: { [6356,6357]
===
match
---
expr_stmt [3668,3832]
expr_stmt [3668,3832]
===
match
---
name: response [7698,7706]
name: response [7698,7706]
===
match
---
fstring_end: " [8247,8248]
fstring_end: " [9362,9363]
===
match
---
atom_expr [7603,7614]
atom_expr [7603,7614]
===
match
---
argument [3184,3210]
argument [3184,3210]
===
match
---
trailer [11300,11307]
trailer [12415,12422]
===
match
---
fstring [8195,8248]
fstring [9310,9363]
===
match
---
string: ":" [6646,6649]
string: ":" [6646,6649]
===
match
---
name: URLSafeSerializer [8065,8082]
name: URLSafeSerializer [9180,9197]
===
match
---
expr_stmt [10713,10989]
expr_stmt [11828,12104]
===
match
---
simple_stmt [9868,9952]
simple_stmt [10983,11067]
===
match
---
name: self [11823,11827]
name: self [12938,12942]
===
match
---
name: self [7616,7620]
name: self [7616,7620]
===
match
---
fstring_string: api/v1/dags/ [12462,12474]
fstring_string: api/v1/dags/ [13577,13589]
===
match
---
string: '' [8826,8828]
string: '' [9941,9943]
===
match
---
suite [6041,6977]
suite [6041,6977]
===
match
---
name: DAG_ID [3126,3132]
name: DAG_ID [3126,3132]
===
match
---
string: 'task' [3617,3623]
string: 'task' [3617,3623]
===
match
---
name: json [11591,11595]
name: json [12706,12710]
===
match
---
atom [12656,12694]
atom [13771,13809]
===
match
---
operator: = [4929,4930]
operator: = [4929,4930]
===
match
---
name: app [2428,2431]
name: app [2428,2431]
===
match
---
operator: , [11627,11628]
operator: , [12742,12743]
===
match
---
trailer [4775,4794]
trailer [4775,4794]
===
match
---
name: settings_folder [5842,5857]
name: settings_folder [5842,5857]
===
match
---
operator: = [12599,12600]
operator: = [13714,13715]
===
match
---
funcdef [5167,5458]
funcdef [5167,5458]
===
match
---
parameters [5189,5195]
parameters [5189,5195]
===
match
---
name: app [4678,4681]
name: app [4678,4681]
===
match
---
string: 'handlers' [3683,3693]
string: 'handlers' [3683,3693]
===
match
---
operator: } [6369,6370]
operator: } [6369,6370]
===
match
---
atom_expr [2918,2935]
atom_expr [2918,2935]
===
match
---
atom_expr [11718,11742]
atom_expr [12833,12857]
===
match
---
operator: , [6649,6650]
operator: , [6649,6650]
===
match
---
trailer [5316,5325]
trailer [5316,5325]
===
match
---
atom_expr [4921,4928]
atom_expr [4921,4928]
===
match
---
name: modules [5740,5747]
name: modules [5740,5747]
===
match
---
name: key [6162,6165]
name: key [6162,6165]
===
match
---
fstring_string: [('', '*** Reading local file:  [6737,6768]
fstring_string: [('', '*** Reading local file:  [6737,6768]
===
match
---
string: "Accept" [9336,9344]
string: "Accept" [10451,10459]
===
match
---
trailer [3984,4000]
trailer [3984,4000]
===
match
---
simple_stmt [9636,9703]
simple_stmt [10751,10818]
===
match
---
name: mock [9709,9713]
name: mock [10824,10828]
===
match
---
operator: , [10349,10350]
operator: , [11464,11465]
===
match
---
atom_expr [5219,5231]
atom_expr [5219,5231]
===
match
---
dotted_name [1331,1344]
dotted_name [1331,1344]
===
match
---
atom_expr [2236,2263]
atom_expr [2236,2263]
===
match
---
comparison [11582,11753]
comparison [12697,12868]
===
match
---
atom_expr [5795,5811]
atom_expr [5795,5811]
===
match
---
string: 'title' [11668,11675]
string: 'title' [12783,12790]
===
match
---
operator: } [7508,7509]
operator: } [7508,7509]
===
match
---
simple_stmt [2796,2830]
simple_stmt [2796,2830]
===
match
---
name: config [11832,11838]
name: config [12947,12953]
===
match
---
simple_stmt [8432,8506]
simple_stmt [9547,9621]
===
match
---
atom [10381,10404]
atom [11496,11519]
===
match
---
name: serializer [12317,12327]
name: serializer [13432,13442]
===
match
---
number: 200 [7691,7694]
number: 200 [7691,7694]
===
match
---
decorated [6982,7872]
decorated [6982,7872]
===
match
---
atom_expr [3544,3581]
atom_expr [3544,3581]
===
match
---
operator: == [11019,11021]
operator: == [12134,12136]
===
match
---
name: TASK_ID [12548,12555]
name: TASK_ID [13663,13670]
===
match
---
name: response [9468,9476]
name: response [10583,10591]
===
match
---
fstring_string: /logs/1?full_content=True [9283,9308]
fstring_string: /logs/1?full_content=True [10398,10423]
===
match
---
atom_expr [7616,7628]
atom_expr [7616,7628]
===
match
---
trailer [7647,7655]
trailer [7647,7655]
===
match
---
string: '.' [5298,5301]
string: '.' [5298,5301]
===
match
---
fstring_expr [12570,12577]
fstring_expr [13685,13692]
===
match
---
trailer [9971,9975]
trailer [11086,11090]
===
match
---
name: self [12431,12435]
name: self [13546,13550]
===
match
---
atom [8789,8791]
atom [9904,9906]
===
match
---
simple_stmt [9043,9126]
simple_stmt [10158,10241]
===
match
---
dictorsetmaker [12657,12693]
dictorsetmaker [13772,13808]
===
match
---
operator: } [8940,8941]
operator: } [10055,10056]
===
match
---
name: self [10724,10728]
name: self [11839,11843]
===
match
---
string: 'Accept' [12601,12609]
string: 'Accept' [13716,13724]
===
match
---
string: 'REMOTE_USER' [8347,8360]
string: 'REMOTE_USER' [9462,9475]
===
match
---
expr_stmt [7103,7138]
expr_stmt [7103,7138]
===
match
---
operator: = [10380,10381]
operator: = [11495,11496]
===
match
---
name: airflow [1192,1199]
name: airflow [1192,1199]
===
match
---
name: client [7266,7272]
name: client [7266,7272]
===
match
---
name: return_value [9889,9901]
name: return_value [11004,11016]
===
match
---
operator: } [9417,9418]
operator: } [10532,10533]
===
match
---
string: 'text/plain' [9346,9358]
string: 'text/plain' [10461,10473]
===
match
---
operator: = [2143,2144]
operator: = [2143,2144]
===
match
---
param [10616,10623]
param [11731,11738]
===
match
---
argument [10937,10978]
argument [12052,12093]
===
match
---
name: response [11005,11013]
name: response [12120,12128]
===
match
---
expr_stmt [6519,6665]
expr_stmt [6519,6665]
===
match
---
simple_stmt [1763,1805]
simple_stmt [1763,1805]
===
match
---
operator: = [12655,12656]
operator: = [13770,13771]
===
match
---
simple_stmt [4921,5092]
simple_stmt [4921,5092]
===
match
---
name: self [5267,5271]
name: self [5267,5271]
===
match
---
name: permissions [2265,2276]
name: permissions [2265,2276]
===
match
---
import_from [1187,1234]
import_from [1187,1234]
===
match
---
fstring [11409,11448]
fstring [12524,12563]
===
match
---
simple_stmt [1005,1039]
simple_stmt [1005,1039]
===
match
---
operator: { [10381,10382]
operator: { [11496,11497]
===
match
---
fstring_start: f" [4058,4060]
fstring_start: f" [4058,4060]
===
match
---
trailer [7768,7777]
trailer [7768,7777]
===
match
---
operator: = [3746,3747]
operator: = [3746,3747]
===
match
---
name: dumps [7210,7215]
name: dumps [7210,7215]
===
match
---
name: permissions [2192,2203]
name: permissions [2192,2203]
===
match
---
name: file [5384,5388]
name: file [5384,5388]
===
match
---
name: _create_dagrun [7071,7085]
name: _create_dagrun [7071,7085]
===
match
---
comparison [6905,6933]
comparison [6905,6933]
===
match
---
trailer [6293,6300]
trailer [6293,6300]
===
match
---
atom_expr [9043,9064]
atom_expr [10158,10179]
===
match
---
operator: = [8970,8971]
operator: = [10085,10086]
===
match
---
name: DagRunType [3193,3203]
name: DagRunType [3193,3203]
===
match
---
assert_stmt [10424,10458]
assert_stmt [11539,11573]
===
match
---
name: session [5139,5146]
name: session [5139,5146]
===
match
---
simple_stmt [8389,8424]
simple_stmt [9504,9539]
===
match
---
dictorsetmaker [12601,12623]
dictorsetmaker [13716,13738]
===
match
---
argument [9327,9359]
argument [10442,10474]
===
match
---
name: environ_overrides [9377,9394]
name: environ_overrides [10492,10509]
===
match
---
operator: = [4861,4862]
operator: = [4861,4862]
===
match
---
trailer [10728,10735]
trailer [11843,11850]
===
match
---
name: sys [5821,5824]
name: sys [5821,5824]
===
match
---
argument [10363,10404]
argument [11478,11519]
===
match
---
name: commit [3427,3433]
name: commit [3427,3433]
===
match
---
name: status_code [10447,10458]
name: status_code [11562,11573]
===
match
---
trailer [8120,8145]
trailer [9235,9260]
===
match
---
decorated [8511,9703]
decorated [9626,10818]
===
match
---
name: headers [7422,7429]
name: headers [7422,7429]
===
match
---
operator: = [9944,9945]
operator: = [11059,11060]
===
match
---
name: TASK_ID [1763,1770]
name: TASK_ID [1763,1770]
===
match
---
name: get [10157,10160]
name: get [11272,11275]
===
match
---
number: 1 [5125,5126]
number: 1 [5125,5126]
===
match
---
string: '2nd line' [9517,9527]
string: '2nd line' [10632,10642]
===
match
---
fstring_start: f" [11325,11327]
fstring_start: f" [12440,12442]
===
match
---
operator: } [8143,8144]
operator: } [9258,9259]
===
match
---
trailer [10532,10537]
trailer [11647,11652]
===
match
---
name: session [6032,6039]
name: session [6032,6039]
===
match
---
string: 'end_of_log' [8922,8934]
string: 'end_of_log' [10037,10049]
===
match
---
trailer [6097,6101]
trailer [6097,6101]
===
match
---
operator: , [7659,7660]
operator: , [7659,7660]
===
match
---
operator: { [9197,9198]
operator: { [10312,10313]
===
match
---
name: self [5058,5062]
name: self [5058,5062]
===
match
---
trailer [7215,7240]
trailer [7215,7240]
===
match
---
name: root_dag [4853,4861]
name: root_dag [4853,4861]
===
match
---
argument [2132,2392]
argument [2132,2392]
===
match
---
name: start_date [3286,3296]
name: start_date [3286,3296]
===
match
---
simple_stmt [8155,8381]
simple_stmt [9270,9496]
===
match
---
assert_stmt [10998,11221]
assert_stmt [12113,12336]
===
match
---
operator: { [1890,1891]
operator: { [1890,1891]
===
match
---
trailer [2276,2293]
trailer [2276,2293]
===
match
---
trailer [4780,4793]
trailer [4780,4793]
===
match
---
trailer [7377,7385]
trailer [7377,7385]
===
match
---
name: role_name [2102,2111]
name: role_name [2102,2111]
===
match
---
name: replace [6638,6645]
name: replace [6638,6645]
===
match
---
operator: } [5365,5366]
operator: } [5365,5366]
===
match
---
operator: } [11554,11555]
operator: } [12669,12670]
===
match
---
atom_expr [5043,5076]
atom_expr [5043,5076]
===
match
---
expr_stmt [10134,10415]
expr_stmt [11249,11530]
===
match
---
trailer [12024,12031]
trailer [13139,13146]
===
match
---
operator: = [4965,4966]
operator: = [4965,4966]
===
match
---
name: provide_session [10560,10575]
name: provide_session [11675,11690]
===
match
---
name: parse [5052,5057]
name: parse [5052,5057]
===
match
---
strings [6274,6392]
strings [6274,6392]
===
match
---
comp_op [9666,9672]
comp_op [10781,10787]
===
match
---
operator: , [10404,10405]
operator: , [11519,11520]
===
match
---
operator: } [1963,1964]
operator: } [1963,1964]
===
match
---
name: self [7603,7607]
name: self [7603,7607]
===
match
---
parameters [4648,4654]
parameters [4648,4654]
===
match
---
name: response [11965,11973]
name: response [13080,13088]
===
match
---
param [5190,5194]
param [5190,5194]
===
match
---
with_stmt [4247,4628]
with_stmt [4247,4628]
===
match
---
dictorsetmaker [8347,8368]
dictorsetmaker [9462,9483]
===
match
---
trailer [2615,2656]
trailer [2615,2656]
===
match
---
atom_expr [3646,3658]
atom_expr [3646,3658]
===
match
---
simple_stmt [6087,6123]
simple_stmt [6087,6123]
===
match
---
name: patch [8658,8663]
name: patch [9773,9778]
===
match
---
atom_expr [2558,2595]
atom_expr [2558,2595]
===
match
---
operator: , [2392,2393]
operator: , [2392,2393]
===
match
---
simple_stmt [6519,6666]
simple_stmt [6519,6666]
===
match
---
trailer [4607,4625]
trailer [4607,4625]
===
match
---
name: token [12571,12576]
name: token [13686,13691]
===
match
---
name: app [9972,9975]
name: app [11087,11090]
===
match
---
fstring_start: f" [5264,5266]
fstring_start: f" [5264,5266]
===
match
---
trailer [12206,12216]
trailer [13321,13331]
===
match
---
name: cls [1979,1982]
name: cls [1979,1982]
===
match
---
trailer [5955,5964]
trailer [5955,5964]
===
match
---
simple_stmt [1979,2018]
simple_stmt [1979,2018]
===
match
---
atom [4275,4474]
atom [4275,4474]
===
match
---
simple_stmt [4156,4192]
simple_stmt [4156,4192]
===
match
---
trailer [8630,8639]
trailer [9745,9754]
===
match
---
trailer [7607,7614]
trailer [7607,7614]
===
match
---
name: key [12348,12351]
name: key [13463,13466]
===
match
---
trailer [9614,9623]
trailer [10729,10738]
===
match
---
operator: = [6243,6244]
operator: = [6243,6244]
===
match
---
name: expected_filename [7822,7839]
name: expected_filename [7822,7839]
===
match
---
trailer [2785,2787]
trailer [2785,2787]
===
match
---
funcdef [10580,11222]
funcdef [11695,12337]
===
match
---
trailer [5841,5857]
trailer [5841,5857]
===
match
---
strings [11325,11448]
strings [12440,12563]
===
match
---
param [7953,7960]
param [9068,9075]
===
match
---
fstring_start: f" [10819,10821]
fstring_start: f" [11934,11936]
===
match
---
atom_expr [4966,5010]
atom_expr [4966,5010]
===
match
---
trailer [6161,6166]
trailer [6161,6166]
===
match
---
name: config [9976,9982]
name: config [11091,11097]
===
match
---
suite [12264,12749]
suite [13379,13864]
===
match
---
atom_expr [12279,12308]
atom_expr [13394,13423]
===
match
---
trailer [4502,4506]
trailer [4502,4506]
===
match
---
operator: , [8918,8919]
operator: , [10033,10034]
===
match
---
name: cls [1861,1864]
name: cls [1861,1864]
===
match
---
name: test_bad_signature_raises [10584,10609]
name: test_bad_signature_raises [11699,11724]
===
match
---
atom_expr [8210,8221]
atom_expr [9325,9336]
===
match
---
simple_stmt [3590,3659]
simple_stmt [3590,3659]
===
match
---
name: TASK_ID [6362,6369]
name: TASK_ID [6362,6369]
===
match
---
operator: } [10290,10291]
operator: } [11405,11406]
===
match
---
trailer [1982,1986]
trailer [1982,1986]
===
match
---
simple_stmt [2558,2596]
simple_stmt [2558,2596]
===
match
---
trailer [6846,6852]
trailer [6846,6852]
===
match
---
testlist_comp [9068,9124]
testlist_comp [10183,10239]
===
match
---
simple_stmt [7250,7521]
simple_stmt [7250,7521]
===
match
---
name: open [4108,4112]
name: open [4108,4112]
===
match
---
name: response [9531,9539]
name: response [10646,10654]
===
match
---
name: self [8166,8170]
name: self [9281,9285]
===
match
---
assert_stmt [10467,10553]
assert_stmt [11582,11668]
===
match
---
string: "test_no_permissions" [2442,2463]
string: "test_no_permissions" [2442,2463]
===
match
---
string: 'end_of_log' [8847,8859]
string: 'end_of_log' [9962,9974]
===
match
---
comparison [9517,9560]
comparison [10632,10675]
===
match
---
trailer [5806,5811]
trailer [5806,5811]
===
match
---
operator: , [3210,3211]
operator: , [3210,3211]
===
match
---
simple_stmt [7971,8000]
simple_stmt [9086,9115]
===
match
---
name: self [4550,4554]
name: self [4550,4554]
===
match
---
name: token [10285,10290]
name: token [11400,11405]
===
match
---
suite [2549,2657]
suite [2549,2657]
===
match
---
argument [10306,10349]
argument [11421,11464]
===
match
---
name: self [8014,8018]
name: self [9129,9133]
===
match
---
operator: } [12623,12624]
operator: } [13738,13739]
===
match
---
name: DummyOperator [4966,4979]
name: DummyOperator [4966,4979]
===
match
---
simple_stmt [3385,3411]
simple_stmt [3385,3411]
===
match
---
name: settings_folder [3906,3921]
name: settings_folder [3906,3921]
===
match
---
atom_expr [2424,2431]
atom_expr [2424,2431]
===
match
---
name: writelines [4163,4173]
name: writelines [4163,4173]
===
match
---
name: url_safe [970,978]
name: url_safe [970,978]
===
match
---
operator: } [8866,8867]
operator: } [9981,9982]
===
match
---
operator: , [2377,2378]
operator: , [2377,2378]
===
match
---
simple_stmt [5549,5565]
simple_stmt [5549,5565]
===
match
---
trailer [2203,2216]
trailer [2203,2216]
===
match
---
expr_stmt [5104,5126]
expr_stmt [5104,5126]
===
match
---
fstring_string: /logs/1?token= [12556,12570]
fstring_string: /logs/1?token= [13671,13685]
===
match
---
name: RESOURCE_DAG_RUN [2277,2293]
name: RESOURCE_DAG_RUN [2277,2293]
===
match
---
operator: } [12576,12577]
operator: } [13691,13692]
===
match
---
name: security [1298,1306]
name: security [1298,1306]
===
match
---
simple_stmt [12317,12353]
simple_stmt [13432,13468]
===
match
---
operator: } [8221,8222]
operator: } [9336,9337]
===
match
---
simple_stmt [12361,12411]
simple_stmt [13476,13526]
===
match
---
atom_expr [10524,10553]
atom_expr [11639,11668]
===
match
---
dotted_name [1635,1654]
dotted_name [1635,1654]
===
match
---
operator: = [3360,3361]
operator: = [3360,3361]
===
match
---
name: setUpClass [1850,1860]
name: setUpClass [1850,1860]
===
match
---
name: default_time [6625,6637]
name: default_time [6625,6637]
===
match
---
trailer [12294,12308]
trailer [13409,13423]
===
match
---
import_from [1326,1360]
import_from [1326,1360]
===
match
---
trailer [7620,7628]
trailer [7620,7628]
===
match
---
name: TASK_ID [7378,7385]
name: TASK_ID [7378,7385]
===
match
---
simple_stmt [9961,9997]
simple_stmt [11076,11112]
===
match
---
name: self [9836,9840]
name: self [10951,10955]
===
match
---
parameters [11269,11275]
parameters [12384,12390]
===
match
---
testlist_comp [2236,2293]
testlist_comp [2236,2293]
===
match
---
name: tempfile [861,869]
name: tempfile [861,869]
===
match
---
fstring_expr [12115,12122]
fstring_expr [13230,13237]
===
match
---
name: dumps [10068,10073]
name: dumps [11183,11188]
===
match
---
atom_expr [5104,5122]
atom_expr [5104,5122]
===
match
---
atom_expr [8166,8380]
atom_expr [9281,9495]
===
match
---
simple_stmt [2944,2970]
simple_stmt [2944,2970]
===
match
---
expr_stmt [4039,4094]
expr_stmt [4039,4094]
===
match
---
fstring_end: " [6391,6392]
fstring_end: " [6391,6392]
===
match
---
decorator [8511,8528]
decorator [9626,9643]
===
match
---
atom_expr [4156,4191]
atom_expr [4156,4191]
===
match
---
atom_expr [4252,4484]
atom_expr [4252,4484]
===
match
---
trailer [3650,3658]
trailer [3650,3658]
===
match
---
name: get [11988,11991]
name: get [13103,13106]
===
match
---
operator: = [7158,7159]
operator: = [7158,7159]
===
match
---
operator: = [3238,3239]
operator: = [3238,3239]
===
match
---
fstring_string: taskInstances/ [6342,6356]
fstring_string: taskInstances/ [6342,6356]
===
match
---
string: 'task' [3695,3701]
string: 'task' [3695,3701]
===
match
---
name: provide_session [7878,7893]
name: provide_session [8993,9008]
===
match
---
name: test_utils [1509,1519]
name: test_utils [1509,1519]
===
match
---
name: session [8631,8638]
name: session [9746,9753]
===
match
---
name: TASK_ID [7621,7628]
name: TASK_ID [7621,7628]
===
match
---
name: client [4555,4561]
name: client [4555,4561]
===
match
---
trailer [6101,6108]
trailer [6101,6108]
===
match
---
operator: -> [2541,2543]
operator: -> [2541,2543]
===
match
---
operator: = [5214,5215]
operator: = [5214,5215]
===
match
---
trailer [7575,7675]
trailer [7575,7675]
===
match
---
name: loads [6847,6852]
name: loads [6847,6852]
===
match
---
name: self [12258,12262]
name: self [13373,13377]
===
match
---
operator: @ [5972,5973]
operator: @ [5972,5973]
===
match
---
operator: == [6910,6912]
operator: == [6910,6912]
===
match
---
trailer [11590,11595]
trailer [12705,12710]
===
match
---
operator: , [11742,11743]
operator: , [12857,12858]
===
match
---
string: "test" [9411,9417]
string: "test" [10526,10532]
===
match
---
trailer [5157,5160]
trailer [5157,5160]
===
match
---
name: append [4209,4215]
name: append [4209,4215]
===
match
---
string: 'end_of_log' [9009,9021]
string: 'end_of_log' [10124,10136]
===
match
---
fstring_end: " [9308,9309]
fstring_end: " [10423,10424]
===
match
---
operator: { [6913,6914]
operator: { [6913,6914]
===
match
---
atom_expr [7199,7240]
atom_expr [7199,7240]
===
match
---
trailer [10156,10160]
trailer [11271,11275]
===
match
---
name: json [6704,6708]
name: json [6704,6708]
===
match
---
trailer [4979,5010]
trailer [4979,5010]
===
match
---
fstring_end: " [7342,7343]
fstring_end: " [7342,7343]
===
match
---
atom_expr [10438,10458]
atom_expr [11553,11573]
===
match
---
string: "test_no_permissions" [2634,2655]
string: "test_no_permissions" [2634,2655]
===
match
---
fstring_expr [12019,12032]
fstring_expr [13134,13147]
===
match
---
string: "test" [2082,2088]
string: "test" [2082,2088]
===
match
---
name: response [7250,7258]
name: response [7250,7258]
===
match
---
trailer [3979,4030]
trailer [3979,4030]
===
match
---
operator: = [1987,1988]
operator: = [1987,1988]
===
match
---
trailer [4835,4843]
trailer [4835,4843]
===
match
---
string: "{}/{}/{}/{}/1.log" [7549,7568]
string: "{}/{}/{}/{}/1.log" [7549,7568]
===
match
---
name: handle [4156,4162]
name: handle [4156,4162]
===
match
---
trailer [5146,5152]
trailer [5146,5152]
===
match
---
name: client [12436,12442]
name: client [13551,13557]
===
match
---
name: status_code [12730,12741]
name: status_code [13845,13856]
===
match
---
name: m [5731,5732]
name: m [5731,5732]
===
match
---
expr_stmt [6175,6225]
expr_stmt [6175,6225]
===
match
---
string: "download_logs" [7217,7232]
string: "download_logs" [7217,7232]
===
match
---
simple_stmt [8806,8870]
simple_stmt [9921,9985]
===
match
---
string: "airflow_local_settings.py" [4002,4029]
string: "airflow_local_settings.py" [4002,4029]
===
match
---
string: 'TEST_DAG_RUN_ID' [3153,3170]
string: 'TEST_DAG_RUN_ID' [3153,3170]
===
match
---
operator: , [3170,3171]
operator: , [3170,3171]
===
match
---
sync_comp_for [5727,5776]
sync_comp_for [5727,5776]
===
match
---
funcdef [2518,2657]
funcdef [2518,2657]
===
match
---
trailer [6597,6604]
trailer [6597,6604]
===
match
---
name: role_name [2465,2474]
name: role_name [2465,2474]
===
match
---
parameters [6025,6040]
parameters [6025,6040]
===
match
---
operator: = [9334,9335]
operator: = [10449,10450]
===
match
---
name: self [7042,7046]
name: self [7042,7046]
===
match
---
name: self [7589,7593]
name: self [7589,7593]
===
match
---
simple_stmt [7147,7183]
simple_stmt [7147,7183]
===
match
---
dictorsetmaker [6914,6932]
dictorsetmaker [6914,6932]
===
match
---
name: self [9150,9154]
name: self [10265,10269]
===
match
---
name: environ_overrides [6458,6475]
name: environ_overrides [6458,6475]
===
match
---
trailer [3311,3330]
trailer [3311,3330]
===
match
---
name: settings_file [3951,3964]
name: settings_file [3951,3964]
===
match
---
operator: = [7547,7548]
operator: = [7547,7548]
===
match
---
atom_expr [8653,8723]
atom_expr [9768,9838]
===
match
---
operator: = [10677,10678]
operator: = [11792,11793]
===
match
---
simple_stmt [5911,5939]
simple_stmt [5911,5939]
===
match
---
dictorsetmaker [9009,9027]
dictorsetmaker [10124,10142]
===
match
---
operator: , [6392,6393]
operator: , [6392,6393]
===
match
---
string: 'airflow_local_settings.LOGGING_CONFIG' [4330,4369]
string: 'airflow_local_settings.LOGGING_CONFIG' [4330,4369]
===
match
---
name: response [9673,9681]
name: response [10788,10796]
===
match
---
trailer [8082,8087]
trailer [9197,9202]
===
match
---
operator: @ [2501,2502]
operator: @ [2501,2502]
===
match
---
parameters [1860,1865]
parameters [1860,1865]
===
match
---
fstring_expr [11425,11439]
fstring_expr [12540,12554]
===
match
---
atom [8897,8943]
atom [10012,10058]
===
match
---
name: create_user [1559,1570]
name: create_user [1559,1570]
===
match
---
parameters [5475,5481]
parameters [5475,5481]
===
match
---
dictorsetmaker [11613,11743]
dictorsetmaker [12728,12858]
===
match
---
name: dagbag [4664,4670]
name: dagbag [4664,4670]
===
match
---
fstring_end: " [10805,10806]
fstring_end: " [11920,11921]
===
match
---
operator: { [4077,4078]
operator: { [4077,4078]
===
match
---
atom [11470,11500]
atom [12585,12615]
===
match
---
name: create_session [1395,1409]
name: create_session [1395,1409]
===
match
---
trailer [2573,2577]
trailer [2573,2577]
===
match
---
trailer [9551,9560]
trailer [10666,10675]
===
match
---
name: response [10524,10532]
name: response [11639,11647]
===
match
---
dictorsetmaker [8922,8940]
dictorsetmaker [10037,10055]
===
match
---
with_stmt [8648,9703]
with_stmt [9763,10818]
===
match
---
fstring_expr [10256,10270]
fstring_expr [11371,11385]
===
match
---
name: parse [4770,4775]
name: parse [4770,4775]
===
match
---
expr_stmt [7250,7520]
expr_stmt [7250,7520]
===
match
---
operator: = [2111,2112]
operator: = [2111,2112]
===
match
---
expr_stmt [1979,2017]
expr_stmt [1979,2017]
===
match
---
del_stmt [5791,5811]
del_stmt [5791,5811]
===
match
---
string: 'REMOTE_USER' [12657,12670]
string: 'REMOTE_USER' [13772,13785]
===
match
---
atom_expr [6695,6719]
atom_expr [6695,6719]
===
match
---
trailer [4894,4896]
trailer [4894,4896]
===
match
---
expr_stmt [12317,12352]
expr_stmt [13432,13467]
===
match
---
operator: , [8369,8370]
operator: , [9484,9485]
===
match
---
operator: , [11164,11165]
operator: , [12279,12280]
===
match
---
strings [10174,10292]
strings [11289,11407]
===
match
---
trailer [10537,10544]
trailer [11652,11659]
===
match
---
name: self [5248,5252]
name: self [5248,5252]
===
match
---
fstring_string: / [5246,5247]
fstring_string: / [5246,5247]
===
match
---
atom [7216,7239]
atom [7216,7239]
===
match
---
trailer [5057,5076]
trailer [5057,5076]
===
match
---
dictorsetmaker [4293,4460]
dictorsetmaker [4293,4460]
===
match
---
trailer [12446,12705]
trailer [13561,13820]
===
match
---
atom_expr [2899,2915]
atom_expr [2899,2915]
===
match
---
simple_stmt [4039,4095]
simple_stmt [4039,4095]
===
match
---
atom_expr [11874,11896]
atom_expr [12989,13011]
===
match
---
name: shutil [5911,5917]
name: shutil [5911,5917]
===
match
---
expr_stmt [3951,4030]
expr_stmt [3951,4030]
===
match
---
testlist_comp [1892,1913]
testlist_comp [1892,1913]
===
match
---
atom_expr [12330,12352]
atom_expr [13445,13467]
===
match
---
name: delete_user [2604,2615]
name: delete_user [2604,2615]
===
match
---
operator: = [4847,4848]
operator: = [4847,4848]
===
match
---
operator: = [3092,3093]
operator: = [3092,3093]
===
match
---
import_from [1584,1629]
import_from [1584,1629]
===
match
---
trailer [6708,6719]
trailer [6708,6719]
===
match
---
expr_stmt [9043,9125]
expr_stmt [10158,10240]
===
match
---
arglist [9183,9419]
arglist [10298,10534]
===
match
---
name: DAG_ID [6294,6300]
name: DAG_ID [6294,6300]
===
match
---
fstring_start: f" [7290,7292]
fstring_start: f" [7290,7292]
===
match
---
atom_expr [1695,1712]
atom_expr [1695,1712]
===
match
---
simple_stmt [1719,1759]
simple_stmt [1719,1759]
===
match
---
trailer [8615,8630]
trailer [9730,9745]
===
match
---
atom_expr [3668,3745]
atom_expr [3668,3745]
===
match
---
arglist [3114,3366]
arglist [3114,3366]
===
match
---
simple_stmt [11965,12187]
simple_stmt [13080,13302]
===
match
---
fstring_end: " [9235,9236]
fstring_end: " [10350,10351]
===
match
---
trailer [7756,7761]
trailer [7756,7761]
===
match
---
operator: = [4056,4057]
operator: = [4056,4057]
===
match
---
trailer [2827,2829]
trailer [2827,2829]
===
match
---
param [12258,12262]
param [13373,13377]
===
match
---
testlist_comp [8973,9029]
testlist_comp [10088,10144]
===
match
---
simple_stmt [4727,4796]
simple_stmt [4727,4796]
===
match
---
name: self [9967,9971]
name: self [11082,11086]
===
match
---
fstring_string: /logs/1?token= [7386,7400]
fstring_string: /logs/1?token= [7386,7400]
===
match
---
operator: = [9917,9918]
operator: = [11032,11033]
===
match
---
name: log_dir [5224,5231]
name: log_dir [5224,5231]
===
match
---
operator: } [5260,5261]
operator: } [5260,5261]
===
match
---
atom [9007,9029]
atom [10122,10144]
===
match
---
operator: } [4473,4474]
operator: } [4473,4474]
===
match
---
param [6032,6039]
param [6032,6039]
===
match
---
simple_stmt [854,870]
simple_stmt [854,870]
===
match
---
operator: , [1897,1898]
operator: , [1897,1898]
===
match
---
simple_stmt [1104,1187]
simple_stmt [1104,1187]
===
match
---
name: log_dir [6584,6591]
name: log_dir [6584,6591]
===
match
---
trailer [7568,7575]
trailer [7568,7575]
===
match
---
dotted_name [1432,1451]
dotted_name [1432,1451]
===
match
---
fstring_start: f" [6735,6737]
fstring_start: f" [6735,6737]
===
match
---
simple_stmt [8750,8794]
simple_stmt [9865,9909]
===
match
---
name: first_return [9068,9080]
name: first_return [10183,10195]
===
match
---
atom_expr [11186,11210]
atom_expr [12301,12325]
===
match
---
trailer [5325,5335]
trailer [5325,5335]
===
match
---
atom_expr [4829,4866]
atom_expr [4829,4866]
===
match
---
name: session [7953,7960]
name: session [9068,9075]
===
match
---
import_as_names [1547,1583]
import_as_names [1547,1583]
===
match
---
operator: = [2081,2082]
operator: = [2081,2082]
===
match
---
trailer [5829,5836]
trailer [5829,5836]
===
match
---
dotted_name [1192,1206]
dotted_name [1192,1206]
===
match
---
name: DAG_ID [7310,7316]
name: DAG_ID [7310,7316]
===
match
---
operator: = [7107,7108]
operator: = [7107,7108]
===
match
---
name: mkdtemp [3933,3940]
name: mkdtemp [3933,3940]
===
match
---
trailer [12547,12555]
trailer [13662,13670]
===
match
---
param [9836,9841]
param [10951,10956]
===
match
---
dictorsetmaker [1891,1963]
dictorsetmaker [1891,1963]
===
match
---
fstring_start: f" [6340,6342]
fstring_start: f" [6340,6342]
===
match
---
name: session [8593,8600]
name: session [9708,9715]
===
match
---
dictorsetmaker [11471,11499]
dictorsetmaker [12586,12614]
===
match
---
simple_stmt [10467,10554]
simple_stmt [11582,11669]
===
match
---
dictorsetmaker [10075,10097]
dictorsetmaker [11190,11212]
===
match
---
expr_stmt [3590,3658]
expr_stmt [3590,3658]
===
match
---
atom_expr [7305,7316]
atom_expr [7305,7316]
===
match
---
expr_stmt [12361,12410]
expr_stmt [13476,13525]
===
match
---
operator: } [10779,10780]
operator: } [11894,11895]
===
match
---
name: rmtree [5918,5924]
name: rmtree [5918,5924]
===
match
---
fstring_string: \n*** Reading local file:  [7795,7821]
fstring_string: \n*** Reading local file:  [7795,7821]
===
match
---
name: URLSafeSerializer [11874,11891]
name: URLSafeSerializer [12989,13006]
===
match
---
trailer [3682,3694]
trailer [3682,3694]
===
match
---
trailer [5836,5858]
trailer [5836,5858]
===
match
---
arglist [4980,5009]
arglist [4980,5009]
===
match
---
name: config [812,818]
name: config [812,818]
===
match
---
name: ACTION_CAN_READ [2248,2263]
name: ACTION_CAN_READ [2248,2263]
===
match
---
operator: { [10955,10956]
operator: { [12070,12071]
===
match
---
parameters [8586,8601]
parameters [9701,9716]
===
match
---
operator: , [2431,2432]
operator: , [2431,2432]
===
match
---
name: sys [2923,2926]
name: sys [2923,2926]
===
match
---
string: "test" [10397,10403]
string: "test" [11512,11518]
===
match
---
fstring_string: api/v1/dags/ [9185,9197]
fstring_string: api/v1/dags/ [10300,10312]
===
match
---
argument [11514,11555]
argument [12629,12670]
===
match
---
name: self [6606,6610]
name: self [6606,6610]
===
match
---
trailer [2038,2403]
trailer [2038,2403]
===
match
---
trailer [2948,2967]
trailer [2948,2967]
===
match
---
name: username [2625,2633]
name: username [2625,2633]
===
match
---
operator: @ [8511,8512]
operator: @ [9626,9627]
===
match
---
simple_stmt [11285,11567]
simple_stmt [12400,12682]
===
match
---
name: delete_user [2558,2569]
name: delete_user [2558,2569]
===
match
---
comparison [9580,9623]
comparison [10695,10738]
===
match
---
atom_expr [7261,7520]
atom_expr [7261,7520]
===
match
---
atom [9335,9359]
atom [10450,10474]
===
match
---
strings [12005,12123]
strings [13120,13238]
===
match
---
expr_stmt [11285,11566]
expr_stmt [12400,12681]
===
match
---
atom_expr [11823,11852]
atom_expr [12938,12967]
===
match
---
param [5476,5480]
param [5476,5480]
===
match
---
name: response [6853,6861]
name: response [6853,6861]
===
match
---
operator: } [11438,11439]
operator: } [12553,12554]
===
match
---
fstring_string: /logs/1?token= [12101,12115]
fstring_string: /logs/1?token= [13216,13230]
===
match
---
atom_expr [6836,6889]
atom_expr [6836,6889]
===
match
---
simple_stmt [7191,7241]
simple_stmt [7191,7241]
===
match
---
funcdef [9786,10554]
funcdef [10901,11669]
===
match
---
name: self [5234,5238]
name: self [5234,5238]
===
match
---
name: key [8008,8011]
name: key [9123,9126]
===
match
---
name: token [6175,6180]
name: token [6175,6180]
===
match
---
trailer [10073,10099]
trailer [11188,11214]
===
match
---
fstring [7356,7408]
fstring [7356,7408]
===
match
---
trailer [9975,9982]
trailer [11090,11097]
===
match
---
trailer [11980,11987]
trailer [13095,13102]
===
match
---
fstring_start: f" [8261,8263]
fstring_start: f" [9376,9378]
===
match
---
name: app [2620,2623]
name: app [2620,2623]
===
match
---
import_name [785,796]
import_name [785,796]
===
match
---
funcdef [3036,3436]
funcdef [3036,3436]
===
match
---
testlist_comp [4388,4409]
testlist_comp [4388,4409]
===
match
---
operator: , [6604,6605]
operator: , [6604,6605]
===
match
---
fstring_start: f" [7793,7795]
fstring_start: f" [7793,7795]
===
match
---
import_from [912,950]
import_from [912,950]
===
match
---
operator: } [4092,4093]
operator: } [4092,4093]
===
match
---
name: test_get_logs_for_handler_without_read_method [9790,9835]
name: test_get_logs_for_handler_without_read_method [10905,10950]
===
match
---
trailer [3253,3272]
trailer [3253,3272]
===
match
---
decorated [2501,2657]
decorated [2501,2657]
===
match
---
fstring_end: " [8313,8314]
fstring_end: " [9428,9429]
===
match
---
atom_expr [2342,2376]
atom_expr [2342,2376]
===
match
---
decorator [1829,1842]
decorator [1829,1842]
===
match
---
operator: { [12019,12020]
operator: { [13134,13135]
===
match
---
assert_stmt [7727,7871]
assert_stmt [7727,7871]
===
match
---
parameters [7041,7056]
parameters [7041,7056]
===
match
---
name: conf_vars [1620,1629]
name: conf_vars [1620,1629]
===
match
---
atom [9395,9418]
atom [10510,10533]
===
match
---
operator: , [3365,3366]
operator: , [3365,3366]
===
match
---
name: default_time [3317,3329]
name: default_time [3317,3329]
===
match
---
trailer [4162,4173]
trailer [4162,4173]
===
match
---
atom [8921,8941]
atom [10036,10056]
===
match
---
suite [5778,5812]
suite [5778,5812]
===
match
---
string: "TestNoPermissions" [2475,2494]
string: "TestNoPermissions" [2475,2494]
===
match
---
trailer [8452,8462]
trailer [9567,9577]
===
match
---
fstring_string: \\nLog for testing.')] [6787,6809]
fstring_string: \\nLog for testing.')] [6787,6809]
===
match
---
trailer [6852,6889]
trailer [6852,6889]
===
match
---
name: dag [4844,4847]
name: dag [4844,4847]
===
match
---
name: serializer [6836,6846]
name: serializer [6836,6846]
===
match
---
fstring_expr [7304,7317]
fstring_expr [7304,7317]
===
match
---
trailer [7265,7272]
trailer [7265,7272]
===
match
---
fstring [7793,7861]
fstring [7793,7861]
===
match
---
arglist [2570,2594]
arglist [2570,2594]
===
match
---
fstring_start: f" [6274,6276]
fstring_start: f" [6274,6276]
===
match
---
operator: = [11294,11295]
operator: = [12409,12410]
===
match
---
trailer [11430,11438]
trailer [12545,12553]
===
match
---
operator: } [11499,11500]
operator: } [12614,12615]
===
match
---
name: default_time [2700,2712]
name: default_time [2700,2712]
===
match
---
fstring_end: " [10291,10292]
fstring_end: " [11406,11407]
===
match
---
simple_stmt [912,951]
simple_stmt [912,951]
===
match
---
name: settings [1030,1038]
name: settings [1030,1038]
===
match
---
trailer [8029,8043]
trailer [9144,9158]
===
match
---
atom_expr [4673,4689]
atom_expr [4673,4689]
===
match
---
string: 'w' [4128,4131]
string: 'w' [4128,4131]
===
match
---
name: flush [5450,5455]
name: flush [5450,5455]
===
match
---
trailer [5412,5432]
trailer [5412,5432]
===
match
---
dictorsetmaker [9336,9358]
dictorsetmaker [10451,10473]
===
match
---
name: join [3975,3979]
name: join [3975,3979]
===
match
---
atom [8972,9030]
atom [10087,10145]
===
match
---
expr_stmt [8096,8145]
expr_stmt [9211,9260]
===
match
---
argument [4853,4865]
argument [4853,4865]
===
match
---
name: default_time [5063,5075]
name: default_time [5063,5075]
===
match
---
atom_expr [5736,5747]
atom_expr [5736,5747]
===
match
---
dotted_name [957,978]
dotted_name [957,978]
===
match
---
string: '' [8976,8978]
string: '' [10091,10093]
===
match
---
operator: { [6288,6289]
operator: { [6288,6289]
===
match
---
expr_stmt [8008,8043]
expr_stmt [9123,9158]
===
match
---
trailer [11311,11566]
trailer [12426,12681]
===
match
---
string: 'REMOTE_USER' [10956,10969]
string: 'REMOTE_USER' [12071,12084]
===
match
---
atom [6913,6933]
atom [6913,6933]
===
match
---
name: self [12020,12024]
name: self [13135,13139]
===
match
---
name: token [11905,11910]
name: token [13020,13025]
===
match
---
dotted_name [1503,1539]
dotted_name [1503,1539]
===
match
---
trailer [5238,5245]
trailer [5238,5245]
===
match
---
atom_expr [4804,4820]
atom_expr [4804,4820]
===
match
---
trailer [6610,6618]
trailer [6610,6618]
===
match
---
parameters [3054,3069]
parameters [3054,3069]
===
match
---
simple_stmt [4498,4538]
simple_stmt [4498,4538]
===
match
---
operator: , [7614,7615]
operator: , [7614,7615]
===
match
---
operator: , [8771,8772]
operator: , [9886,9887]
===
match
---
expr_stmt [7191,7240]
expr_stmt [7191,7240]
===
match
---
fstring_string: taskInstances/ [10821,10835]
fstring_string: taskInstances/ [11936,11950]
===
match
---
strings [8195,8314]
strings [9310,9429]
===
match
---
name: response [7748,7756]
name: response [7748,7756]
===
match
---
suite [9859,10554]
suite [10974,11669]
===
match
---
atom [8900,8916]
atom [10015,10031]
===
match
---
name: self [6620,6624]
name: self [6620,6624]
===
match
---
trailer [5964,5966]
trailer [5964,5966]
===
match
---
testlist_comp [2313,2376]
testlist_comp [2313,2376]
===
match
---
name: key [6087,6090]
name: key [6087,6090]
===
match
---
suite [5389,5458]
suite [5389,5458]
===
match
---
string: 'REMOTE_USER' [7487,7500]
string: 'REMOTE_USER' [7487,7500]
===
match
---
atom_expr [5911,5938]
atom_expr [5911,5938]
===
match
---
trailer [6645,6655]
trailer [6645,6655]
===
match
---
trailer [3316,3329]
trailer [3316,3329]
===
match
---
trailer [9888,9901]
trailer [11003,11016]
===
match
---
name: EXCEPTIONS_LINK_MAP [11186,11205]
name: EXCEPTIONS_LINK_MAP [12301,12320]
===
match
---
name: read_mock [8727,8736]
name: read_mock [9842,9851]
===
match
---
simple_stmt [1285,1326]
simple_stmt [1285,1326]
===
match
---
name: task_id [4980,4987]
name: task_id [4980,4987]
===
match
---
suite [4485,4628]
suite [4485,4628]
===
match
---
operator: { [11470,11471]
operator: { [12585,12586]
===
match
---
name: session [4900,4907]
name: session [4900,4907]
===
match
---
param [9842,9857]
param [10957,10972]
===
match
---
string: 'logging' [4294,4303]
string: 'logging' [4294,4303]
===
match
---
atom_expr [6289,6300]
atom_expr [6289,6300]
===
match
---
number: 200 [6949,6952]
number: 200 [6949,6952]
===
match
---
name: self [6050,6054]
name: self [6050,6054]
===
match
---
simple_stmt [6674,6821]
simple_stmt [6674,6821]
===
match
---
testlist_comp [8766,8792]
testlist_comp [9881,9907]
===
match
---
atom_expr [2796,2808]
atom_expr [2796,2808]
===
match
---
name: token [8307,8312]
name: token [9422,9427]
===
match
---
name: environ_overrides [10363,10380]
name: environ_overrides [11478,11495]
===
match
---
trailer [12435,12442]
trailer [13550,13557]
===
match
---
fstring_end: " [6326,6327]
fstring_end: " [6326,6327]
===
match
---
trailer [4925,4928]
trailer [4925,4928]
===
match
---
name: add [3393,3396]
name: add [3393,3396]
===
match
---
simple_stmt [886,912]
simple_stmt [886,912]
===
match
---
operator: , [8843,8844]
operator: , [9958,9959]
===
match
---
decorator [9708,9782]
decorator [10823,10897]
===
match
---
fstring_start: f" [10240,10242]
fstring_start: f" [11355,11357]
===
match
---
arglist [6579,6655]
arglist [6579,6655]
===
match
---
string: 'Accept' [11471,11479]
string: 'Accept' [12586,12594]
===
match
---
name: airflow [1109,1116]
name: airflow [1109,1116]
===
match
---
dotted_name [1475,1486]
dotted_name [1475,1486]
===
match
---
param [2536,2539]
param [2536,2539]
===
match
---
trailer [8177,8181]
trailer [9292,9296]
===
match
---
trailer [4112,4132]
trailer [4112,4132]
===
match
---
trailer [3426,3433]
trailer [3426,3433]
===
match
---
atom_expr [10189,10200]
atom_expr [11304,11315]
===
match
---
name: logging_config [3590,3604]
name: logging_config [3590,3604]
===
match
---
trailer [11827,11831]
trailer [12942,12946]
===
match
---
atom [12145,12175]
atom [13260,13290]
===
match
---
simple_stmt [3527,3582]
simple_stmt [3527,3582]
===
match
---
fstring_expr [7400,7407]
fstring_expr [7400,7407]
===
match
---
atom_expr [1989,2017]
atom_expr [1989,2017]
===
match
---
trailer [2773,2785]
trailer [2773,2785]
===
match
---
trailer [2247,2263]
trailer [2247,2263]
===
match
---
trailer [4769,4775]
trailer [4769,4775]
===
match
---
atom_expr [4599,4627]
atom_expr [4599,4627]
===
match
---
arglist [4737,4794]
arglist [4737,4794]
===
match
---
name: self [4564,4568]
name: self [4564,4568]
===
match
---
suite [2686,3031]
suite [2686,3031]
===
match
---
name: token [7191,7196]
name: token [7191,7196]
===
match
---
fstring_string: /dagRuns/TEST_DAG_RUN_ID/ [10780,10805]
fstring_string: /dagRuns/TEST_DAG_RUN_ID/ [11895,11920]
===
match
---
atom_expr [2978,3003]
atom_expr [2978,3003]
===
match
---
operator: == [8463,8465]
operator: == [9578,9580]
===
match
---
operator: { [11532,11533]
operator: { [12647,12648]
===
match
---
trailer [4203,4208]
trailer [4203,4208]
===
match
---
decorator [6982,6999]
decorator [6982,6999]
===
match
---
operator: , [10978,10979]
operator: , [12093,12094]
===
match
---
name: test_should_raise_403_forbidden [12226,12257]
name: test_should_raise_403_forbidden [13341,13372]
===
match
---
atom_expr [12369,12410]
atom_expr [13484,13525]
===
match
---
operator: { [5218,5219]
operator: { [5218,5219]
===
match
---
name: airflow [1010,1017]
name: airflow [1010,1017]
===
match
---
simple_stmt [3668,3833]
simple_stmt [3668,3833]
===
match
---
name: TaskInstance [1222,1234]
name: TaskInstance [1222,1234]
===
match
---
operator: , [11500,11501]
operator: , [12615,12616]
===
match
---
simple_stmt [952,1004]
simple_stmt [952,1004]
===
match
---
fstring_end: " [5262,5263]
fstring_end: " [5262,5263]
===
match
---
trailer [3604,3616]
trailer [3604,3616]
===
match
---
operator: { [6414,6415]
operator: { [6414,6415]
===
match
---
argument [3286,3330]
argument [3286,3330]
===
match
---
atom [8824,8842]
atom [9939,9957]
===
match
---
name: _create_dagrun [8616,8630]
name: _create_dagrun [9731,9745]
===
match
---
atom_expr [2163,2190]
atom_expr [2163,2190]
===
match
---
operator: { [7216,7217]
operator: { [7216,7217]
===
match
---
simple_stmt [5205,5306]
simple_stmt [5205,5306]
===
match
---
name: self [7066,7070]
name: self [7066,7070]
===
match
---
atom_expr [3094,3376]
atom_expr [3094,3376]
===
match
---
atom [8973,9005]
atom [10088,10120]
===
match
---
simple_stmt [3419,3436]
simple_stmt [3419,3436]
===
match
---
expr_stmt [3901,3942]
expr_stmt [3901,3942]
===
match
---
name: dir_path [5205,5213]
name: dir_path [5205,5213]
===
match
---
name: config [5499,5505]
name: config [5499,5505]
===
match
---
name: tearDownClass [2522,2535]
name: tearDownClass [2522,2535]
===
match
---
name: app [1494,1497]
name: app [1494,1497]
===
match
---
name: DAG_ID [4742,4748]
name: DAG_ID [4742,4748]
===
match
---
expr_stmt [8882,8943]
expr_stmt [9997,10058]
===
match
---
operator: , [10292,10293]
operator: , [11407,11408]
===
match
---
name: response [8155,8163]
name: response [9270,9278]
===
match
---
operator: = [8763,8764]
operator: = [9878,9879]
===
match
---
operator: , [1557,1558]
operator: , [1557,1558]
===
match
---
operator: = [8345,8346]
operator: = [9460,9461]
===
match
---
param [7048,7055]
param [7048,7055]
===
match
---
simple_stmt [10998,11222]
simple_stmt [12113,12337]
===
match
---
atom [8975,9003]
atom [10090,10118]
===
match
---
operator: } [11351,11352]
operator: } [12466,12467]
===
match
---
simple_stmt [6829,6890]
simple_stmt [6829,6890]
===
match
---
name: unittest [877,885]
name: unittest [877,885]
===
match
---
name: expected_filename [7529,7546]
name: expected_filename [7529,7546]
===
match
---
suite [7962,8506]
suite [9077,9621]
===
match
---
expr_stmt [10005,10040]
expr_stmt [11120,11155]
===
match
---
name: self [5881,5885]
name: self [5881,5885]
===
match
---
trailer [6861,6866]
trailer [6861,6866]
===
match
---
atom_expr [5058,5075]
atom_expr [5058,5075]
===
match
---
name: provide_session [5973,5988]
name: provide_session [5973,5988]
===
match
---
name: task [4961,4965]
name: task [4961,4965]
===
match
---
name: external_trigger [3344,3360]
name: external_trigger [3344,3360]
===
match
---
operator: , [7046,7047]
operator: , [7046,7047]
===
match
---
trailer [8663,8723]
trailer [9778,9838]
===
match
---
name: key [9961,9964]
name: key [11076,11079]
===
match
---
operator: { [12656,12657]
operator: { [13771,13772]
===
match
---
name: self [2695,2699]
name: self [2695,2699]
===
match
---
name: _configure_loggers [2983,3001]
name: _configure_loggers [2983,3001]
===
match
---
param [11802,11806]
param [12917,12921]
===
match
---
expr_stmt [12420,12705]
expr_stmt [13535,13820]
===
match
---
operator: } [6443,6444]
operator: } [6443,6444]
===
match
---
with_item [5349,5388]
with_item [5349,5388]
===
match
---
operator: { [9269,9270]
operator: { [10384,10385]
===
match
---
name: self [11340,11344]
name: self [12455,12459]
===
match
---
fstring [12071,12123]
fstring [13186,13238]
===
match
---
fstring_string: / [5303,5304]
fstring_string: / [5303,5304]
===
match
---
string: 'continuation_token' [6867,6887]
string: 'continuation_token' [6867,6887]
===
match
---
atom [8825,8841]
atom [9940,9956]
===
match
---
name: data [7757,7761]
name: data [7757,7761]
===
match
---
simple_stmt [1498,1584]
simple_stmt [1498,1584]
===
match
---
name: sys [5795,5798]
name: sys [5795,5798]
===
match
---
atom_expr [10768,10779]
atom_expr [11883,11894]
===
match
---
operator: = [9148,9149]
operator: = [10263,10264]
===
match
---
name: mod [5807,5810]
name: mod [5807,5810]
===
match
---
string: "test" [7502,7508]
string: "test" [7502,7508]
===
match
---
name: self [10634,10638]
name: self [11749,11753]
===
match
---
simple_stmt [9447,9498]
simple_stmt [10562,10613]
===
match
---
name: json [8448,8452]
name: json [9563,9567]
===
match
---
import_from [1005,1038]
import_from [1005,1038]
===
match
---
operator: { [5247,5248]
operator: { [5247,5248]
===
match
---
name: tests [1503,1508]
name: tests [1503,1508]
===
match
---
atom [8765,8793]
atom [9880,9908]
===
match
---
string: 'dag_for_testing_log_endpoint' [1728,1758]
string: 'dag_for_testing_log_endpoint' [1728,1758]
===
match
---
file_input [785,12749]
file_input [785,13864]
===
match
---
name: old_modules [2904,2915]
name: old_modules [2904,2915]
===
match
---
name: www [1483,1486]
name: www [1483,1486]
===
match
---
name: key [11817,11820]
name: key [12932,12935]
===
match
---
with_item [8653,8736]
with_item [9768,9851]
===
match
---
dictorsetmaker [10315,10348]
dictorsetmaker [11430,11463]
===
match
---
trailer [9481,9488]
trailer [10596,10603]
===
match
---
string: 'application/json' [10904,10922]
string: 'application/json' [12019,12037]
===
match
---
atom_expr [4737,4748]
atom_expr [4737,4748]
===
match
---
name: DummyOperator [1271,1284]
name: DummyOperator [1271,1284]
===
match
---
expr_stmt [2751,2787]
expr_stmt [2751,2787]
===
match
---
trailer [11838,11852]
trailer [12953,12967]
===
match
---
operator: , [9418,9419]
operator: , [10533,10534]
===
match
---
parameters [2535,2540]
parameters [2535,2540]
===
match
---
name: logging_config [3668,3682]
name: logging_config [3668,3682]
===
match
---
simple_stmt [10424,10459]
simple_stmt [11539,11574]
===
match
---
suite [5482,5967]
suite [5482,5967]
===
match
---
operator: = [9065,9066]
operator: = [10180,10181]
===
match
---
suite [8602,9703]
suite [9717,10818]
===
match
---
trailer [5449,5455]
trailer [5449,5455]
===
match
---
fstring_start: f" [9183,9185]
fstring_start: f" [10298,10300]
===
match
---
name: response [9594,9602]
name: response [10709,10717]
===
match
---
name: remove [5830,5836]
name: remove [5830,5836]
===
match
---
fstring_end: " [11374,11375]
fstring_end: " [12489,12490]
===
match
---
operator: , [4369,4370]
operator: , [4369,4370]
===
match
---
trailer [2174,2190]
trailer [2174,2190]
===
match
---
operator: { [7304,7305]
operator: { [7304,7305]
===
match
---
name: environ_overrides [10937,10954]
name: environ_overrides [12052,12069]
===
match
---
simple_stmt [1809,1824]
simple_stmt [1809,1824]
===
match
---
name: response [12420,12428]
name: response [13535,13543]
===
match
---
fstring [5216,5263]
fstring [5216,5263]
===
match
---
operator: = [8820,8821]
operator: = [9935,9936]
===
match
---
name: self [3254,3258]
name: self [3254,3258]
===
match
---
string: 'REMOTE_USER' [11533,11546]
string: 'REMOTE_USER' [12648,12661]
===
match
---
dictorsetmaker [10680,10702]
dictorsetmaker [11795,11817]
===
match
---
fstring_end: " [11447,11448]
fstring_end: " [12562,12563]
===
match
---
trailer [2619,2623]
trailer [2619,2623]
===
match
---
name: tempfile [3924,3932]
name: tempfile [3924,3932]
===
match
---
operator: , [11210,11211]
operator: , [12325,12326]
===
match
---
operator: = [6181,6182]
operator: = [6181,6182]
===
match
---
atom_expr [5234,5245]
atom_expr [5234,5245]
===
match
---
fstring_expr [5247,5261]
fstring_expr [5247,5261]
===
match
---
name: self [3901,3905]
name: self [3901,3905]
===
match
---
atom_expr [9531,9560]
atom_expr [10646,10675]
===
match
---
atom_expr [11582,11595]
atom_expr [12697,12710]
===
match
---
string: '' [8769,8771]
string: '' [9884,9886]
===
match
---
simple_stmt [12714,12749]
simple_stmt [13829,13864]
===
match
---
comparison [6949,6976]
comparison [6949,6976]
===
match
---
atom_expr [10145,10415]
atom_expr [11260,11530]
===
match
---
name: sys [5736,5739]
name: sys [5736,5739]
===
match
---
import_name [870,885]
import_name [870,885]
===
match
---
operator: { [10835,10836]
operator: { [11950,11951]
===
match
---
simple_stmt [10005,10041]
simple_stmt [11120,11156]
===
match
---
atom_expr [4988,5000]
atom_expr [4988,5000]
===
match
---
trailer [7309,7316]
trailer [7309,7316]
===
match
---
trailer [9274,9282]
trailer [10389,10397]
===
match
---
operator: = [12144,12145]
operator: = [13259,13260]
===
match
---
name: timezone [3239,3247]
name: timezone [3239,3247]
===
match
---
strings [12460,12578]
strings [13575,13693]
===
match
---
name: path [5825,5829]
name: path [5825,5829]
===
match
---
trailer [6260,6510]
trailer [6260,6510]
===
match
---
name: copy [3544,3548]
name: copy [3544,3548]
===
match
---
assert_stmt [12714,12748]
assert_stmt [13829,13863]
===
match
---
operator: = [6834,6835]
operator: = [6834,6835]
===
match
---
trailer [4584,4586]
trailer [4584,4586]
===
match
---
import_from [1285,1325]
import_from [1285,1325]
===
match
---
trailer [8022,8029]
trailer [9137,9144]
===
match
---
name: dummy [1258,1263]
name: dummy [1258,1263]
===
match
---
operator: , [3330,3331]
operator: , [3330,3331]
===
match
---
fstring [10240,10292]
fstring [11355,11407]
===
match
---
simple_stmt [1630,1676]
simple_stmt [1630,1676]
===
match
---
operator: , [11654,11655]
operator: , [12769,12770]
===
match
---
trailer [6249,6256]
trailer [6249,6256]
===
match
---
trailer [7593,7601]
trailer [7593,7601]
===
match
---
fstring_end: " [12512,12513]
fstring_end: " [13627,13628]
===
match
---
name: clear_db_runs [5549,5562]
name: clear_db_runs [5549,5562]
===
match
---
name: serializer [8052,8062]
name: serializer [9167,9177]
===
match
---
trailer [3974,3979]
trailer [3974,3979]
===
match
---
name: self [12279,12283]
name: self [13394,13398]
===
match
---
import_name [843,853]
import_name [843,853]
===
match
---
operator: } [11220,11221]
operator: } [12335,12336]
===
match
---
trailer [5824,5829]
trailer [5824,5829]
===
match
---
suite [3470,4628]
suite [3470,4628]
===
match
---
name: operators [1248,1257]
name: operators [1248,1257]
===
match
---
operator: } [5245,5246]
operator: } [5245,5246]
===
match
---
parameters [10609,10624]
parameters [11724,11739]
===
match
---
name: dir_path [5357,5365]
name: dir_path [5357,5365]
===
match
---
operator: } [6498,6499]
operator: } [6498,6499]
===
match
---
operator: { [11022,11023]
operator: { [12137,12138]
===
match
---
name: decode [9608,9614]
name: decode [10723,10729]
===
match
---
atom [6200,6224]
atom [6200,6224]
===
match
---
fstring_string: taskInstances/ [7358,7372]
fstring_string: taskInstances/ [7358,7372]
===
match
---
arglist [7589,7665]
arglist [7589,7665]
===
match
---
simple_stmt [797,819]
simple_stmt [797,819]
===
match
---
string: 'end_of_log' [6914,6926]
string: 'end_of_log' [6914,6926]
===
match
---
trailer [4173,4191]
trailer [4173,4191]
===
match
---
simple_stmt [5821,5859]
simple_stmt [5821,5859]
===
match
---
string: "auth_backend" [4395,4409]
string: "auth_backend" [4395,4409]
===
match
---
atom [6681,6820]
atom [6681,6820]
===
match
---
testlist_comp [2162,2378]
testlist_comp [2162,2378]
===
match
---
trailer [7655,7665]
trailer [7655,7665]
===
match
---
string: "Task instance did not exist in the DB" [8466,8505]
string: "Task instance did not exist in the DB" [9581,9620]
===
match
---
name: self [10836,10840]
name: self [11951,11955]
===
match
---
name: exceptions [1066,1076]
name: exceptions [1066,1076]
===
match
---
name: data [10533,10537]
name: data [11648,11652]
===
match
---
string: 'REMOTE_USER' [10382,10395]
string: 'REMOTE_USER' [11497,11510]
===
match
---
param [8593,8600]
param [9708,9715]
===
match
---
operator: , [7509,7510]
operator: , [7509,7510]
===
match
---
name: token [6385,6390]
name: token [6385,6390]
===
match
---
atom_expr [2604,2656]
atom_expr [2604,2656]
===
match
---
trailer [9476,9481]
trailer [10591,10596]
===
match
---
atom_expr [9270,9282]
atom_expr [10385,10397]
===
match
---
operator: , [12123,12124]
operator: , [13238,13239]
===
match
---
atom_expr [6093,6122]
atom_expr [6093,6122]
===
match
---
atom_expr [5402,5432]
atom_expr [5402,5432]
===
match
---
name: DAG_ID [9203,9209]
name: DAG_ID [10318,10324]
===
match
---
argument [10885,10923]
argument [12000,12038]
===
match
---
operator: } [7453,7454]
operator: } [7453,7454]
===
match
---
operator: } [12693,12694]
operator: } [13808,13809]
===
match
---
trailer [11344,11351]
trailer [12459,12466]
===
match
---
atom [11532,11555]
atom [12647,12670]
===
match
---
testlist_comp [2163,2216]
testlist_comp [2163,2216]
===
match
---
atom_expr [7549,7675]
atom_expr [7549,7675]
===
match
---
expr_stmt [3079,3376]
expr_stmt [3079,3376]
===
match
---
suite [3070,3436]
suite [3070,3436]
===
match
---
name: unittest [917,925]
name: unittest [917,925]
===
match
---
trailer [4681,4689]
trailer [4681,4689]
===
match
---
expr_stmt [9868,9951]
expr_stmt [10983,11066]
===
match
---
trailer [2353,2376]
trailer [2353,2376]
===
match
---
name: serializer [10057,10067]
name: serializer [11172,11182]
===
match
---
name: dumps [11924,11929]
name: dumps [13039,13044]
===
match
---
name: _create_dagrun [3040,3054]
name: _create_dagrun [3040,3054]
===
match
---
simple_stmt [10134,10416]
simple_stmt [11249,11531]
===
match
---
string: 'title' [11091,11098]
string: 'title' [12206,12213]
===
match
---
name: RESOURCE_DAG [2204,2216]
name: RESOURCE_DAG [2204,2216]
===
match
---
name: key [8083,8086]
name: key [9198,9201]
===
match
---
name: TASK_ID [11431,11438]
name: TASK_ID [12546,12553]
===
match
---
fstring_expr [6384,6391]
fstring_expr [6384,6391]
===
match
---
argument [12638,12694]
argument [13753,13809]
===
match
---
operator: = [11872,11873]
operator: = [12987,12988]
===
match
---
name: parse [3248,3253]
name: parse [3248,3253]
===
match
---
atom_expr [5925,5937]
atom_expr [5925,5937]
===
match
---
operator: , [1409,1410]
operator: , [1409,1410]
===
match
---
fstring_string: /dagRuns/TEST_DAG_RUN_ID/ [6301,6326]
fstring_string: /dagRuns/TEST_DAG_RUN_ID/ [6301,6326]
===
match
---
atom_expr [12475,12486]
atom_expr [13590,13601]
===
match
---
operator: , [12624,12625]
operator: , [13739,13740]
===
match
---
import_from [1039,1103]
import_from [1039,1103]
===
match
---
name: cls [2570,2573]
name: cls [2570,2573]
===
match
---
name: app [6098,6101]
name: app [6098,6101]
===
match
---
name: self [7630,7634]
name: self [7630,7634]
===
match
---
name: dag [5002,5005]
name: dag [5002,5005]
===
match
---
trailer [6193,6199]
trailer [6193,6199]
===
match
---
trailer [4208,4215]
trailer [4208,4215]
===
match
---
string: 'utf-8' [9694,9701]
string: 'utf-8' [10809,10816]
===
match
---
string: 'content' [6709,6718]
string: 'content' [6709,6718]
===
match
---
simple_stmt [5948,5967]
simple_stmt [5948,5967]
===
match
---
name: expected_filename [6519,6536]
name: expected_filename [6519,6536]
===
match
---
name: self [8587,8591]
name: self [9702,9706]
===
match
---
trailer [5498,5505]
trailer [5498,5505]
===
match
---
string: "api" [1892,1897]
string: "api" [1892,1897]
===
match
---
name: airflow [1475,1482]
name: airflow [1475,1482]
===
match
---
name: settings_folder [3985,4000]
name: settings_folder [3985,4000]
===
match
---
name: self [8611,8615]
name: self [9726,9730]
===
match
---
atom_expr [8014,8043]
atom_expr [9129,9158]
===
match
---
operator: , [5076,5077]
operator: , [5076,5077]
===
match
---
operator: } [10097,10098]
operator: } [11212,11213]
===
match
---
atom_expr [3590,3643]
atom_expr [3590,3643]
===
match
---
fstring_expr [10767,10780]
fstring_expr [11882,11895]
===
match
---
atom_expr [5837,5857]
atom_expr [5837,5857]
===
match
---
name: username [2073,2081]
name: username [2073,2081]
===
match
---
funcdef [11227,11754]
funcdef [12342,12869]
===
match
---
trailer [6637,6645]
trailer [6637,6645]
===
match
---
argument [4844,4851]
argument [4844,4851]
===
match
---
operator: } [12486,12487]
operator: } [13601,13602]
===
match
---
name: m [5725,5726]
name: m [5725,5726]
===
match
---
expr_stmt [2796,2829]
expr_stmt [2796,2829]
===
match
---
fstring_expr [7372,7386]
fstring_expr [7372,7386]
===
match
---
name: TASK_ID [10262,10269]
name: TASK_ID [11377,11384]
===
match
---
fstring_string: /logs/1?token= [10849,10863]
fstring_string: /logs/1?token= [11964,11978]
===
match
---
name: _prepare_log_files [2949,2967]
name: _prepare_log_files [2949,2967]
===
match
---
name: self [5219,5223]
name: self [5219,5223]
===
match
---
name: cls [2052,2055]
name: cls [2052,2055]
===
match
---
name: headers [11462,11469]
name: headers [12577,12584]
===
match
---
name: get [11308,11311]
name: get [12423,12426]
===
match
---
arglist [3980,4029]
arglist [3980,4029]
===
match
---
assert_stmt [9573,9623]
assert_stmt [10688,10738]
===
match
---
string: 'Accept' [7431,7439]
string: 'Accept' [7431,7439]
===
match
---
simple_stmt [3079,3377]
simple_stmt [3079,3377]
===
match
---
fstring_string: api/v1/dags/ [12007,12019]
fstring_string: api/v1/dags/ [13122,13134]
===
match
---
name: serializer [10005,10015]
name: serializer [11120,11130]
===
match
---
name: session [1380,1387]
name: session [1380,1387]
===
match
---
fstring_expr [5266,5303]
fstring_expr [5266,5303]
===
match
---
operator: } [10200,10201]
operator: } [11315,11316]
===
match
---
trailer [3016,3028]
trailer [3016,3028]
===
match
---
atom_expr [12088,12100]
atom_expr [13203,13215]
===
match
---
trailer [5252,5260]
trailer [5252,5260]
===
match
---
name: provide_session [6983,6998]
name: provide_session [6983,6998]
===
match
---
fstring_expr [7821,7840]
fstring_expr [7821,7840]
===
match
---
simple_stmt [4550,4587]
simple_stmt [4550,4587]
===
match
---
name: response [9139,9147]
name: response [10254,10262]
===
match
---
atom_expr [9594,9623]
atom_expr [10709,10738]
===
match
---
fstring_string: LOGGING_CONFIG =  [4060,4077]
fstring_string: LOGGING_CONFIG =  [4060,4077]
===
match
---
atom_expr [11913,11955]
atom_expr [13028,13070]
===
match
---
with_item [4880,4907]
with_item [4880,4907]
===
match
---
operator: , [9109,9110]
operator: , [10224,10225]
===
match
---
argument [3114,3132]
argument [3114,3132]
===
match
---
name: data [9603,9607]
name: data [10718,10722]
===
match
---
atom_expr [8611,8639]
atom_expr [9726,9754]
===
match
---
name: key [12273,12276]
name: key [13388,13391]
===
match
---
operator: , [6618,6619]
operator: , [6618,6619]
===
match
---
name: self [11270,11274]
name: self [12385,12389]
===
match
---
operator: = [2633,2634]
operator: = [2633,2634]
===
match
---
dotted_name [1290,1306]
dotted_name [1290,1306]
===
match
---
name: type [9868,9872]
name: type [10983,10987]
===
match
---
operator: , [9080,9081]
operator: , [10195,10196]
===
match
---
expr_stmt [4664,4689]
expr_stmt [4664,4689]
===
match
---
name: create_user [2027,2038]
name: create_user [2027,2038]
===
match
---
operator: { [6476,6477]
operator: { [6476,6477]
===
match
---
atom [10314,10349]
atom [11429,11464]
===
match
---
name: test_get_logs_response_with_ti_equal_to_none [7902,7946]
name: test_get_logs_response_with_ti_equal_to_none [9017,9061]
===
match
---
operator: , [1570,1571]
operator: , [1570,1571]
===
match
---
name: decode [9482,9488]
name: decode [10597,10603]
===
match
---
name: file [5445,5449]
name: file [5445,5449]
===
match
---
trailer [1992,2003]
trailer [1992,2003]
===
match
---
arglist [2052,2393]
arglist [2052,2393]
===
match
---
name: path [4204,4208]
name: path [4204,4208]
===
match
---
argument [5002,5009]
argument [5002,5009]
===
match
---
name: os [826,828]
name: os [826,828]
===
match
---
string: "2020-06-10T20:00:00+00:00" [2715,2742]
string: "2020-06-10T20:00:00+00:00" [2715,2742]
===
match
---
fstring_string: / [5261,5262]
fstring_string: / [5261,5262]
===
match
---
fstring_start: f" [9253,9255]
fstring_start: f" [10368,10370]
===
match
---
import_from [1470,1497]
import_from [1470,1497]
===
match
---
name: ti [4926,4928]
name: ti [4926,4928]
===
match
---
operator: , [4393,4394]
operator: , [4393,4394]
===
match
---
operator: , [4748,4749]
operator: , [4748,4749]
===
match
---
atom_expr [5445,5457]
atom_expr [5445,5457]
===
match
---
atom [9067,9125]
atom [10182,10240]
===
match
---
simple_stmt [5491,5541]
simple_stmt [5491,5541]
===
match
---
name: mock_log_reader [9842,9857]
name: mock_log_reader [10957,10972]
===
match
---
dotted_name [917,930]
dotted_name [917,930]
===
match
---
trailer [10160,10415]
trailer [11275,11530]
===
match
---
atom_expr [9673,9702]
atom_expr [10788,10817]
===
match
---
funcdef [1846,2496]
funcdef [1846,2496]
===
match
---
trailer [2967,2969]
trailer [2967,2969]
===
match
---
trailer [5284,5292]
trailer [5284,5292]
===
match
---
name: self [11976,11980]
name: self [13091,13095]
===
match
---
operator: = [5123,5124]
operator: = [5123,5124]
===
match
---
operator: { [8346,8347]
operator: { [9461,9462]
===
match
---
atom_expr [3385,3410]
atom_expr [3385,3410]
===
match
---
name: dumps [8115,8120]
name: dumps [9230,9235]
===
match
---
trailer [9544,9551]
trailer [10659,10666]
===
match
---
trailer [4992,5000]
trailer [4992,5000]
===
match
---
import_as_names [1025,1038]
import_as_names [1025,1038]
===
match
---
name: response [11285,11293]
name: response [12400,12408]
===
match
---
operator: = [12277,12278]
operator: = [13392,13393]
===
match
---
name: copy [792,796]
name: copy [792,796]
===
match
---
name: supports_read [9903,9916]
name: supports_read [11018,11031]
===
match
---
fstring_expr [10863,10870]
fstring_expr [11978,11985]
===
match
---
name: app [4509,4512]
name: app [4509,4512]
===
match
---
atom_expr [4550,4561]
atom_expr [4550,4561]
===
match
---
operator: , [8978,8979]
operator: , [10093,10094]
===
match
---
operator: = [2441,2442]
operator: = [2441,2442]
===
match
---
name: config [12288,12294]
name: config [13403,13409]
===
match
---
expr_stmt [9139,9433]
expr_stmt [10254,10548]
===
match
---
name: client [11301,11307]
name: client [12416,12422]
===
match
---
fstring_string: api/v1/dags/ [6276,6288]
fstring_string: api/v1/dags/ [6276,6288]
===
match
---
name: fourth_return [8956,8969]
name: fourth_return [10071,10084]
===
match
---
atom_expr [8439,8462]
atom_expr [9554,9577]
===
match
---
atom [2162,2217]
atom [2162,2217]
===
match
---
fstring_end: " [7407,7408]
fstring_end: " [7407,7408]
===
match
---
assert_stmt [6674,6820]
assert_stmt [6674,6820]
===
match
---
trailer [5353,5380]
trailer [5353,5380]
===
match
---
atom [8346,8369]
atom [9461,9484]
===
match
---
operator: } [12174,12175]
operator: } [13289,13290]
===
match
---
atom_expr [4931,5091]
atom_expr [4931,5091]
===
match
---
trailer [8214,8221]
trailer [9329,9336]
===
match
---
name: headers [12592,12599]
name: headers [13707,13714]
===
match
---
name: tearDown [5467,5475]
name: tearDown [5467,5475]
===
match
---
name: classmethod [1830,1841]
name: classmethod [1830,1841]
===
match
---
operator: = [7259,7260]
operator: = [7259,7260]
===
match
---
name: self [7261,7265]
name: self [7261,7265]
===
match
---
string: 'base_log_folder' [3625,3642]
string: 'base_log_folder' [3625,3642]
===
match
---
name: create_app [1993,2003]
name: create_app [1993,2003]
===
match
---
string: 'utf-8' [7769,7776]
string: 'utf-8' [7769,7776]
===
match
---
atom [10679,10703]
atom [11794,11818]
===
match
---
argument [9377,9418]
argument [10492,10533]
===
match
---
name: self [3312,3316]
name: self [3312,3316]
===
match
---
atom_expr [2027,2403]
atom_expr [2027,2403]
===
match
---
name: m [5751,5752]
name: m [5751,5752]
===
match
---
simple_stmt [9510,9561]
simple_stmt [10625,10676]
===
match
---
name: client [2756,2762]
name: client [2756,2762]
===
match
---
import_name [854,869]
import_name [854,869]
===
match
---
atom_expr [2052,2059]
atom_expr [2052,2059]
===
match
---
operator: , [2340,2341]
operator: , [2340,2341]
===
match
---
name: utils [1339,1344]
name: utils [1339,1344]
===
match
---
string: 'detail' [8453,8461]
string: 'detail' [9568,9576]
===
match
---
operator: == [10435,10437]
operator: == [11550,11552]
===
match
---
trailer [9165,9433]
trailer [10280,10548]
===
match
---
trailer [2427,2431]
trailer [2427,2431]
===
match
---
string: 'type' [11710,11716]
string: 'type' [12825,12831]
===
match
---
name: client [8171,8177]
name: client [9286,9292]
===
match
---
trailer [6256,6260]
trailer [6256,6260]
===
match
---
simple_stmt [1326,1361]
simple_stmt [1326,1361]
===
match
---
string: 'Accept' [6415,6423]
string: 'Accept' [6415,6423]
===
match
---
name: get [12443,12446]
name: get [13558,13561]
===
match
---
name: environ_overrides [7468,7485]
name: environ_overrides [7468,7485]
===
match
---
atom [11022,11221]
atom [12137,12336]
===
match
---
name: test_should_raises_401_unauthenticated [11763,11801]
name: test_should_raises_401_unauthenticated [12878,12916]
===
match
---
fstring_string: api/v1/dags/ [10755,10767]
fstring_string: api/v1/dags/ [11870,11882]
===
match
---
name: app [11828,11831]
name: app [12943,12946]
===
match
---
dictorsetmaker [7431,7453]
dictorsetmaker [7431,7453]
===
match
---
atom_expr [6144,6166]
atom_expr [6144,6166]
===
match
---
strings [10753,10871]
strings [11868,11986]
===
match
---
name: settings_file [4113,4126]
name: settings_file [4113,4126]
===
match
---
operator: = [10892,10893]
operator: = [12007,12008]
===
match
---
operator: == [7695,7697]
operator: == [7695,7697]
===
match
---
trailer [1703,1712]
trailer [1703,1712]
===
match
---
with_item [4108,4142]
with_item [4108,4142]
===
match
---
trailer [5873,5880]
trailer [5873,5880]
===
match
---
simple_stmt [870,886]
simple_stmt [870,886]
===
match
---
operator: = [3922,3923]
operator: = [3922,3923]
===
match
---
operator: } [10848,10849]
operator: } [11963,11964]
===
match
---
fstring_end: " [12577,12578]
fstring_end: " [13692,13693]
===
match
---
expr_stmt [5205,5305]
expr_stmt [5205,5305]
===
match
---
operator: = [10055,10056]
operator: = [11170,11171]
===
match
---
name: self [4498,4502]
name: self [4498,4502]
===
match
---
operator: { [7430,7431]
operator: { [7430,7431]
===
match
---
string: 'application/json' [6425,6443]
string: 'application/json' [6425,6443]
===
match
---
trailer [5108,5111]
trailer [5108,5111]
===
match
---
name: self [7109,7113]
name: self [7109,7113]
===
match
---
name: data [9682,9686]
name: data [10797,10801]
===
match
---
trailer [3433,3435]
trailer [3433,3435]
===
match
---
operator: , [2623,2624]
operator: , [2623,2624]
===
match
---
operator: { [6200,6201]
operator: { [6200,6201]
===
match
---
fstring_end: " [12057,12058]
fstring_end: " [13172,13173]
===
match
---
name: key [7103,7106]
name: key [7103,7106]
===
match
---
atom_expr [5867,5902]
atom_expr [5867,5902]
===
match
---
name: headers [9327,9334]
name: headers [10442,10449]
===
match
---
name: decode [9687,9693]
name: decode [10802,10808]
===
match
---
name: mock [8653,8657]
name: mock [9768,9772]
===
match
---
dictorsetmaker [6477,6498]
dictorsetmaker [6477,6498]
===
match
---
string: "SECRET_KEY" [6109,6121]
string: "SECRET_KEY" [6109,6121]
===
match
---
testlist_comp [8823,8868]
testlist_comp [9938,9983]
===
match
---
atom_expr [5139,5161]
atom_expr [5139,5161]
===
match
---
name: username [2579,2587]
name: username [2579,2587]
===
match
---
expr_stmt [1809,1823]
expr_stmt [1809,1823]
===
match
---
operator: , [7454,7455]
operator: , [7454,7455]
===
match
---
operator: { [5356,5357]
operator: { [5356,5357]
===
match
---
expr_stmt [2695,2742]
expr_stmt [2695,2742]
===
match
---
trailer [6703,6708]
trailer [6703,6708]
===
match
---
argument [8328,8369]
argument [9443,9484]
===
match
---
operator: { [9008,9009]
operator: { [10123,10124]
===
match
---
atom_expr [3239,3272]
atom_expr [3239,3272]
===
match
---
fstring_start: f" [7356,7358]
fstring_start: f" [7356,7358]
===
match
---
string: "download_logs" [10680,10695]
string: "download_logs" [11795,11810]
===
match
---
atom_expr [12431,12705]
atom_expr [13546,13820]
===
match
---
parameters [11801,11807]
parameters [12916,12922]
===
match
---
operator: } [10403,10404]
operator: } [11518,11519]
===
match
---
simple_stmt [2695,2743]
simple_stmt [2695,2743]
===
match
---
simple_stmt [12420,12706]
simple_stmt [13535,13821]
===
match
---
atom_expr [2811,2829]
atom_expr [2811,2829]
===
match
---
operator: = [1771,1772]
operator: = [1771,1772]
===
match
---
name: self [8210,8214]
name: self [9325,9329]
===
match
---
operator: = [7429,7430]
operator: = [7429,7430]
===
match
---
suite [10625,11222]
suite [11740,12337]
===
match
---
assert_stmt [9447,9497]
assert_stmt [10562,10612]
===
match
---
name: status_code [7707,7718]
name: status_code [7707,7718]
===
match
---
expr_stmt [8956,9030]
expr_stmt [10071,10145]
===
match
---
name: DEFAULT_LOGGING_CONFIG [5517,5539]
name: DEFAULT_LOGGING_CONFIG [5517,5539]
===
match
---
atom [8846,8867]
atom [9961,9982]
===
match
---
operator: = [2763,2764]
operator: = [2763,2764]
===
match
---
name: first_return [8750,8762]
name: first_return [9865,9877]
===
match
---
simple_stmt [4200,4238]
simple_stmt [4200,4238]
===
match
---
operator: , [6591,6592]
operator: , [6591,6592]
===
match
---
simple_stmt [12196,12217]
simple_stmt [13311,13332]
===
match
---
trailer [8170,8177]
trailer [9285,9292]
===
match
---
comp_op [5753,5759]
comp_op [5753,5759]
===
match
---
expr_stmt [1763,1804]
expr_stmt [1763,1804]
===
match
---
simple_stmt [8008,8044]
simple_stmt [9123,9159]
===
match
---
trailer [10067,10073]
trailer [11182,11188]
===
match
---
name: environ_overrides [11514,11531]
name: environ_overrides [12629,12646]
===
match
---
name: self [6026,6030]
name: self [6026,6030]
===
match
---
dotted_name [1109,1156]
dotted_name [1109,1156]
===
match
---
string: '{{ ti.dag_id }}/{{ ti.task_id }}/{{ ts | replace(":", ".") }}/{{ try_number }}.log' [3748,3832]
string: '{{ ti.dag_id }}/{{ ti.task_id }}/{{ ts | replace(":", ".") }}/{{ try_number }}.log' [3748,3832]
===
match
---
trailer [6054,6069]
trailer [6054,6069]
===
match
---
operator: , [8786,8787]
operator: , [9901,9902]
===
match
---
trailer [3932,3940]
trailer [3932,3940]
===
match
---
atom_expr [2192,2216]
atom_expr [2192,2216]
===
match
---
name: json [6862,6866]
name: json [6862,6866]
===
match
---
name: serializer [6183,6193]
name: serializer [6183,6193]
===
match
---
suite [4655,5162]
suite [4655,5162]
===
match
---
atom_expr [11340,11351]
atom_expr [12455,12466]
===
match
---
atom_expr [3901,3921]
atom_expr [3901,3921]
===
match
---
atom_expr [6606,6618]
atom_expr [6606,6618]
===
match
---
atom_expr [3012,3030]
atom_expr [3012,3030]
===
match
---
expr_stmt [11965,12186]
expr_stmt [13080,13301]
===
match
---
simple_stmt [4599,4628]
simple_stmt [4599,4628]
===
match
---
name: token [7401,7406]
name: token [7401,7406]
===
match
---
name: _create_dagrun [6055,6069]
name: _create_dagrun [6055,6069]
===
match
---
string: "SECRET_KEY" [7125,7137]
string: "SECRET_KEY" [7125,7137]
===
match
---
name: TestCase [1704,1712]
name: TestCase [1704,1712]
===
match
---
name: self [5104,5108]
name: self [5104,5108]
===
match
---
trailer [3396,3410]
trailer [3396,3410]
===
match
---
fstring_end: " [5372,5373]
fstring_end: " [5372,5373]
===
match
---
atom_expr [6620,6655]
atom_expr [6620,6655]
===
match
---
name: self [10768,10772]
name: self [11883,11887]
===
match
---
operator: , [12578,12579]
operator: , [13693,13694]
===
match
---
atom_expr [12721,12741]
atom_expr [13836,13856]
===
match
---
suite [8737,9703]
suite [9852,10818]
===
match
---
operator: = [1726,1727]
operator: = [1726,1727]
===
match
---
trailer [3905,3921]
trailer [3905,3921]
===
match
---
operator: { [10256,10257]
operator: { [11371,11372]
===
match
---
operator: , [11448,11449]
operator: , [12563,12564]
===
match
---
atom_expr [5821,5858]
atom_expr [5821,5858]
===
match
---
name: serializer [6131,6141]
name: serializer [6131,6141]
===
match
---
fstring_expr [12474,12487]
fstring_expr [13589,13602]
===
match
---
atom_expr [6853,6888]
atom_expr [6853,6888]
===
match
---
atom [8767,8785]
atom [9882,9900]
===
match
---
atom_expr [11426,11438]
atom_expr [12541,12553]
===
match
---
simple_stmt [843,854]
simple_stmt [843,854]
===
match
---
name: ACTION_CAN_READ [2325,2340]
name: ACTION_CAN_READ [2325,2340]
===
match
---
name: deepcopy [3549,3557]
name: deepcopy [3549,3557]
===
match
---
trailer [3392,3396]
trailer [3392,3396]
===
match
---
name: _prepare_db [3017,3028]
name: _prepare_db [3017,3028]
===
match
---
name: self [4649,4653]
name: self [4649,4653]
===
match
---
trailer [11891,11896]
trailer [13006,13011]
===
match
---
atom [7430,7454]
atom [7430,7454]
===
match
---
operator: } [9282,9283]
operator: } [10397,10398]
===
match
---
simple_stmt [785,797]
simple_stmt [785,797]
===
match
---
operator: { [4275,4276]
operator: { [4275,4276]
===
match
---
operator: , [10923,10924]
operator: , [12038,12039]
===
match
---
argument [3224,3272]
argument [3224,3272]
===
match
---
name: timezone [3297,3305]
name: timezone [3297,3305]
===
match
---
operator: { [10284,10285]
operator: { [11399,11400]
===
match
---
string: 'utf-8' [9615,9622]
string: 'utf-8' [10730,10737]
===
match
---
operator: { [10188,10189]
operator: { [11303,11304]
===
match
---
import_from [952,1003]
import_from [952,1003]
===
match
---
trailer [12379,12385]
trailer [13494,13500]
===
match
---
operator: , [3132,3133]
operator: , [3132,3133]
===
match
---
simple_stmt [10049,10100]
simple_stmt [11164,11215]
===
match
---
operator: , [2463,2464]
operator: , [2463,2464]
===
match
---
name: cls [2616,2619]
name: cls [2616,2619]
===
match
---
number: 400 [8420,8423]
number: 400 [9535,9538]
===
match
---
name: self [7373,7377]
name: self [7373,7377]
===
match
---
fstring_string: /dagRuns/TEST_DAG_RUN/ [11352,11374]
fstring_string: /dagRuns/TEST_DAG_RUN/ [12467,12489]
===
match
---
name: data [9540,9544]
name: data [10655,10659]
===
match
---
testlist_comp [8901,8915]
testlist_comp [10016,10030]
===
match
---
operator: , [8828,8829]
operator: , [9943,9944]
===
match
---
operator: , [6030,6031]
operator: , [6030,6031]
===
match
---
name: dag [5006,5009]
name: dag [5006,5009]
===
match
---
fstring_expr [10835,10849]
fstring_expr [11950,11964]
===
match
---
string: 'should never be read' [8980,9002]
string: 'should never be read' [10095,10117]
===
match
---
name: _prepare_db [4637,4648]
name: _prepare_db [4637,4648]
===
match
---
import_from [1427,1469]
import_from [1427,1469]
===
match
---
fstring [10174,10227]
fstring [11289,11342]
===
match
---
operator: { [12542,12543]
operator: { [13657,13658]
===
match
---
name: side_effect [9053,9064]
name: side_effect [10168,10179]
===
match
---
name: permissions [2163,2174]
name: permissions [2163,2174]
===
match
---
operator: , [9005,9006]
operator: , [10120,10121]
===
match
---
operator: { [9395,9396]
operator: { [10510,10511]
===
match
---
simple_stmt [7066,7095]
simple_stmt [7066,7095]
===
match
---
expr_stmt [7147,7182]
expr_stmt [7147,7182]
===
match
---
name: decode [7762,7768]
name: decode [7762,7768]
===
match
---
operator: = [10016,10017]
operator: = [11131,11132]
===
match
---
name: create_app [4513,4523]
name: create_app [4513,4523]
===
match
---
atom_expr [11005,11018]
atom_expr [12120,12133]
===
match
---
operator: = [5005,5006]
operator: = [5005,5006]
===
match
---
simple_stmt [1584,1630]
simple_stmt [1584,1630]
===
match
---
string: "download_logs" [8122,8137]
string: "download_logs" [9237,9252]
===
match
---
name: mock [926,930]
name: mock [926,930]
===
match
---
name: third_return [8882,8894]
name: third_return [9997,10009]
===
match
---
atom_expr [6593,6604]
atom_expr [6593,6604]
===
match
---
fstring [12526,12578]
fstring [13641,13693]
===
match
---
simple_stmt [8611,8640]
simple_stmt [9726,9755]
===
match
---
name: second_return [8806,8819]
name: second_return [9921,9934]
===
match
---
name: get [6257,6260]
name: get [6257,6260]
===
match
---
trailer [9681,9686]
trailer [10796,10801]
===
match
---
operator: = [11469,11470]
operator: = [12584,12585]
===
match
---
operator: , [11696,11697]
operator: , [12811,12812]
===
match
---
string: "test" [2588,2594]
string: "test" [2588,2594]
===
match
---
string: "SECRET_KEY" [11839,11851]
string: "SECRET_KEY" [12954,12966]
===
match
---
fstring_start: f" [11409,11411]
fstring_start: f" [12524,12526]
===
match
---
expr_stmt [4550,4586]
expr_stmt [4550,4586]
===
match
---
trailer [12347,12352]
trailer [13462,13467]
===
match
---
with_stmt [1875,2018]
with_stmt [1875,2018]
===
match
---
dictorsetmaker [10894,10922]
dictorsetmaker [12009,12037]
===
match
---
name: get [9162,9165]
name: get [10277,10280]
===
match
---
trailer [12283,12287]
trailer [13398,13402]
===
match
---
fstring_string: taskInstances/ [10242,10256]
fstring_string: taskInstances/ [11357,11371]
===
match
---
arglist [6274,6500]
arglist [6274,6500]
===
match
---
operator: = [6475,6476]
operator: = [6475,6476]
===
match
---
trailer [5271,5284]
trailer [5271,5284]
===
match
---
trailer [2423,2495]
trailer [2423,2495]
===
match
---
simple_stmt [12273,12309]
simple_stmt [13388,13424]
===
match
---
atom_expr [10057,10099]
atom_expr [11172,11214]
===
match
---
operator: = [6142,6143]
operator: = [6142,6143]
===
match
---
name: ti [5158,5160]
name: ti [5158,5160]
===
match
---
fstring [6340,6392]
fstring [6340,6392]
===
match
---
fstring_string: /dagRuns/TEST_DAG_RUN_ID/ [12032,12057]
fstring_string: /dagRuns/TEST_DAG_RUN_ID/ [13147,13172]
===
match
---
argument [4961,5010]
argument [4961,5010]
===
match
---
decorator [7877,7894]
decorator [8992,9009]
===
match
---
trailer [10739,10989]
trailer [11854,12104]
===
match
---
atom_expr [6183,6225]
atom_expr [6183,6225]
===
match
---
name: client [6250,6256]
name: client [6250,6256]
===
match
---
operator: , [3059,3060]
operator: , [3059,3060]
===
match
---
name: session [10616,10623]
name: session [11731,11738]
===
match
---
atom_expr [10257,10269]
atom_expr [11372,11384]
===
match
---
string: "." [6651,6654]
string: "." [6651,6654]
===
match
---
trailer [6866,6888]
trailer [6866,6888]
===
match
---
comparison [10431,10458]
comparison [11546,11573]
===
match
---
name: status_code [8405,8416]
name: status_code [9520,9531]
===
match
---
name: log_dir [7594,7601]
name: log_dir [7594,7601]
===
match
---
name: settings_folder [4221,4236]
name: settings_folder [4221,4236]
===
match
---
fstring_end: " [7860,7861]
fstring_end: " [7860,7861]
===
match
---
funcdef [7003,7872]
funcdef [7003,7872]
===
match
---
simple_stmt [3901,3943]
simple_stmt [3901,3943]
===
match
---
trailer [5152,5161]
trailer [5152,5161]
===
match
---
atom [8766,8786]
atom [9881,9901]
===
match
---
operator: = [4531,4532]
operator: = [4531,4532]
===
match
---
trailer [4554,4561]
trailer [4554,4561]
===
match
---
name: TRY_NUMBER [1809,1819]
name: TRY_NUMBER [1809,1819]
===
match
---
arglist [2616,2655]
arglist [2616,2655]
===
match
---
name: test_raises_404_for_invalid_dag_run_id [11231,11269]
name: test_raises_404_for_invalid_dag_run_id [12346,12384]
===
match
---
name: makedirs [5317,5325]
name: makedirs [5317,5325]
===
match
---
name: client [9155,9161]
name: client [10270,10276]
===
match
---
fstring_string: /logs/1?token= [10270,10284]
fstring_string: /logs/1?token= [11385,11399]
===
match
---
name: assert_401 [12196,12206]
name: assert_401 [13311,13321]
===
match
---
name: clear_db_runs [1662,1675]
name: clear_db_runs [1662,1675]
===
match
---
trailer [6361,6369]
trailer [6361,6369]
===
match
---
name: TASK_ID [6611,6618]
name: TASK_ID [6611,6618]
===
match
---
atom_expr [6245,6510]
atom_expr [6245,6510]
===
match
---
simple_stmt [5314,5336]
simple_stmt [5314,5336]
===
match
---
atom_expr [2265,2293]
atom_expr [2265,2293]
===
match
---
arglist [2424,2494]
arglist [2424,2494]
===
match
---
operator: = [12429,12430]
operator: = [13544,13545]
===
match
---
dotted_name [9709,9719]
dotted_name [10824,10834]
===
match
---
operator: } [12121,12122]
operator: } [13236,13237]
===
match
---
atom_expr [9150,9433]
atom_expr [10265,10548]
===
match
---
suite [11808,12217]
suite [12923,13332]
===
match
---
fstring [9253,9309]
fstring [10368,10424]
===
match
---
simple_stmt [5867,5903]
simple_stmt [5867,5903]
===
match
---
name: parse [3306,3311]
name: parse [3306,3311]
===
match
---
name: tearDown [5956,5964]
name: tearDown [5956,5964]
===
match
---
operator: = [11531,11532]
operator: = [12646,12647]
===
match
---
trailer [3001,3003]
trailer [3001,3003]
===
match
---
name: permissions [2132,2143]
name: permissions [2132,2143]
===
match
---
operator: { [8789,8790]
operator: { [9904,9905]
===
match
---
fstring_string: /logs/1?token= [6370,6384]
fstring_string: /logs/1?token= [6370,6384]
===
match
---
atom_expr [11976,12186]
atom_expr [13091,13301]
===
match
---
name: client [10729,10735]
name: client [11844,11850]
===
match
---
atom_expr [7748,7777]
atom_expr [7748,7777]
===
match
---
trailer [2699,2712]
trailer [2699,2712]
===
match
---
name: self [7971,7975]
name: self [9086,9090]
===
match
---
operator: } [10977,10978]
operator: } [12092,12093]
===
match
---
suite [4143,4192]
suite [4143,4192]
===
match
---
operator: = [2809,2810]
operator: = [2809,2810]
===
match
---
operator: = [9965,9966]
operator: = [11080,11081]
===
match
---
operator: , [8903,8904]
operator: , [10018,10019]
===
match
---
operator: { [6384,6385]
operator: { [6384,6385]
===
match
---
argument [6406,6444]
argument [6406,6444]
===
match
---
operator: = [5042,5043]
operator: = [5042,5043]
===
match
---
string: "test" [11548,11554]
string: "test" [12663,12669]
===
match
---
param [2672,2676]
param [2672,2676]
===
match
---
simple_stmt [8882,8944]
simple_stmt [9997,10059]
===
match
---
trailer [6558,6565]
trailer [6558,6565]
===
match
---
decorated [9708,10554]
decorated [10823,11669]
===
match
---
operator: , [11050,11051]
operator: , [12165,12166]
===
match
---
name: serializer [12369,12379]
name: serializer [13484,13494]
===
match
---
operator: = [12367,12368]
operator: = [13482,13483]
===
match
---
name: self [3980,3984]
name: self [3980,3984]
===
match
---
name: format [7569,7575]
name: format [7569,7575]
===
match
---
atom_expr [10724,10989]
atom_expr [11839,12104]
===
match
---
parameters [12257,12263]
parameters [13372,13378]
===
match
---
name: key [10036,10039]
name: key [11151,11154]
===
match
---
trailer [11737,11742]
trailer [12852,12857]
===
match
---
expr_stmt [8750,8793]
expr_stmt [9865,9908]
===
match
---
name: ti [5109,5111]
name: ti [5109,5111]
===
match
---
trailer [7117,7124]
trailer [7117,7124]
===
match
---
name: EXCEPTIONS_LINK_MAP [11718,11737]
name: EXCEPTIONS_LINK_MAP [12833,12852]
===
match
---
import_as_names [1395,1426]
import_as_names [1395,1426]
===
match
---
fstring [8261,8314]
fstring [9376,9429]
===
match
---
name: self [3121,3125]
name: self [3121,3125]
===
match
---
name: app [2056,2059]
name: app [2056,2059]
===
match
---
operator: = [8164,8165]
operator: = [9279,9280]
===
match
---
operator: { [5233,5234]
operator: { [5233,5234]
===
match
---
decorated [1829,2496]
decorated [1829,2496]
===
match
---
argument [7422,7454]
argument [7422,7454]
===
match
---
trailer [10446,10458]
trailer [11561,11573]
===
match
---
operator: } [10922,10923]
operator: } [12037,12038]
===
match
---
string: 'application/jso' [10331,10348]
string: 'application/jso' [11446,11463]
===
match
---
operator: } [6300,6301]
operator: } [6300,6301]
===
match
---
trailer [9872,9902]
trailer [10987,11017]
===
match
---
operator: { [12600,12601]
operator: { [13715,13716]
===
match
---
fstring_expr [11339,11352]
fstring_expr [12454,12467]
===
match
---
simple_stmt [2027,2404]
simple_stmt [2027,2404]
===
match
---
dictorsetmaker [6201,6223]
dictorsetmaker [6201,6223]
===
match
---
atom_expr [3297,3330]
atom_expr [3297,3330]
===
match
---
trailer [6069,6078]
trailer [6069,6078]
===
match
---
operator: = [1820,1821]
operator: = [1820,1821]
===
match
---
arglist [7290,7510]
arglist [7290,7510]
===
match
---
trailer [8404,8416]
trailer [9519,9531]
===
match
---
name: status_code [6965,6976]
name: status_code [6965,6976]
===
match
---
expr_stmt [11861,11896]
expr_stmt [12976,13011]
===
match
---
expr_stmt [4921,5091]
expr_stmt [4921,5091]
===
match
---
operator: } [7406,7407]
operator: } [7406,7407]
===
match
---
name: DAG_ID [7608,7614]
name: DAG_ID [7608,7614]
===
match
---
name: sync_to_db [4808,4818]
name: sync_to_db [4808,4818]
===
match
---
string: ':' [5293,5296]
string: ':' [5293,5296]
===
match
---
string: "tests.test_utils.remote_user_api_auth_backend" [4412,4459]
string: "tests.test_utils.remote_user_api_auth_backend" [4412,4459]
===
match
---
expr_stmt [2899,2935]
expr_stmt [2899,2935]
===
match
---
atom_expr [5349,5380]
atom_expr [5349,5380]
===
match
---
trailer [6583,6591]
trailer [6583,6591]
===
match
---
expr_stmt [7529,7675]
expr_stmt [7529,7675]
===
match
---
atom_expr [9967,9996]
atom_expr [11082,11111]
===
match
---
parameters [3463,3469]
parameters [3463,3469]
===
match
---
name: logging_config [4078,4092]
name: logging_config [4078,4092]
===
match
---
atom_expr [4509,4537]
atom_expr [4509,4537]
===
match
---
name: permissions [2342,2353]
name: permissions [2342,2353]
===
match
---
operator: = [3296,3297]
operator: = [3296,3297]
===
match
---
name: classmethod [2502,2513]
name: classmethod [2502,2513]
===
match
---
name: URLSafeSerializer [986,1003]
name: URLSafeSerializer [986,1003]
===
match
---
argument [7468,7509]
argument [7468,7509]
===
match
---
trailer [3203,3210]
trailer [3203,3210]
===
match
---
for_stmt [5713,5812]
for_stmt [5713,5812]
===
match
---
name: response [6956,6964]
name: response [6956,6964]
===
match
---
dictorsetmaker [7487,7508]
dictorsetmaker [7487,7508]
===
match
---
name: self [6357,6361]
name: self [6357,6361]
===
match
---
strings [5216,5305]
strings [5216,5305]
===
match
---
atom [8788,8792]
atom [9903,9907]
===
match
---
operator: , [9359,9360]
operator: , [10474,10475]
===
match
---
simple_stmt [2751,2788]
simple_stmt [2751,2788]
===
match
---
fstring_start: f" [5354,5356]
fstring_start: f" [5354,5356]
===
match
---
name: RESOURCE_TASK_INSTANCE [2354,2376]
name: RESOURCE_TASK_INSTANCE [2354,2376]
===
match
---
simple_stmt [7529,7676]
simple_stmt [7529,7676]
===
match
---
name: self [2944,2948]
name: self [2944,2948]
===
match
---
import_name [797,818]
import_name [797,818]
===
match
---
trailer [6199,6225]
trailer [6199,6225]
===
match
---
param [7042,7047]
param [7042,7047]
===
match
---
name: os [3967,3969]
name: os [3967,3969]
===
match
---
name: TASK_ID [10841,10848]
name: TASK_ID [11956,11963]
===
match
---
dictorsetmaker [11931,11953]
dictorsetmaker [13046,13068]
===
match
---
trailer [7177,7182]
trailer [7177,7182]
===
match
---
name: new_logging_file [4039,4055]
name: new_logging_file [4039,4055]
===
match
---
string: "SECRET_KEY" [8030,8042]
string: "SECRET_KEY" [9145,9157]
===
match
---
trailer [3258,3271]
trailer [3258,3271]
===
match
---
atom_expr [11296,11566]
atom_expr [12411,12681]
===
match
---
parameters [2671,2677]
parameters [2671,2677]
===
match
---
testlist_comp [4294,4327]
testlist_comp [4294,4327]
===
match
---
simple_stmt [10671,10704]
simple_stmt [11786,11819]
===
match
---
trailer [11929,11955]
trailer [13044,13070]
===
match
---
name: self [2978,2982]
name: self [2978,2982]
===
match
---
name: airflow [1331,1338]
name: airflow [1331,1338]
===
match
---
fstring [12005,12058]
fstring [13120,13173]
===
match
---
trailer [4572,4584]
trailer [4572,4584]
===
match
---
string: '1st line' [8773,8783]
string: '1st line' [9888,9898]
===
match
---
string: 'type' [11178,11184]
string: 'type' [12293,12299]
===
match
---
string: "airflow.utils.log.file_task_handler.FileTaskHandler.read" [8664,8722]
string: "airflow.utils.log.file_task_handler.FileTaskHandler.read" [9779,9837]
===
match
---
name: URLSafeSerializer [7160,7177]
name: URLSafeSerializer [7160,7177]
===
match
---
funcdef [5993,6977]
funcdef [5993,6977]
===
match
---
simple_stmt [6234,6511]
simple_stmt [6234,6511]
===
match
---
arglist [7656,7664]
arglist [7656,7664]
===
match
---
operator: = [11974,11975]
operator: = [13089,13090]
===
match
---
argument [3146,3170]
argument [3146,3170]
===
match
---
operator: , [8314,8315]
operator: , [9429,9430]
===
match
---
fstring_string: /logs/1? [11439,11447]
fstring_string: /logs/1? [12554,12562]
===
match
---
argument [2465,2494]
argument [2465,2494]
===
match
---
name: logging_config [3527,3541]
name: logging_config [3527,3541]
===
match
---
trailer [3028,3030]
trailer [3028,3030]
===
match
---
operator: { [12087,12088]
operator: { [13202,13203]
===
match
---
suite [1966,2018]
suite [1966,2018]
===
match
---
assert_stmt [6898,6933]
assert_stmt [6898,6933]
===
match
---
arglist [12460,12695]
arglist [13575,13810]
===
match
---
trailer [2922,2935]
trailer [2922,2935]
===
match
---
arglist [11325,11556]
arglist [12440,12671]
===
match
---
operator: { [11599,11600]
operator: { [12714,12715]
===
match
---
name: self [6579,6583]
name: self [6579,6583]
===
match
---
name: self [10610,10614]
name: self [11725,11729]
===
match
---
operator: { [10314,10315]
operator: { [11429,11430]
===
match
---
fstring_start: f" [12460,12462]
fstring_start: f" [13575,13577]
===
match
---
name: self [4776,4780]
name: self [4776,4780]
===
match
---
operator: == [12742,12744]
operator: == [13857,13859]
===
match
---
operator: } [5231,5232]
operator: } [5231,5232]
===
match
---
simple_stmt [9139,9434]
simple_stmt [10254,10549]
===
match
---
fstring_end: " [10226,10227]
fstring_end: " [11341,11342]
===
match
---
name: app [2770,2773]
name: app [2770,2773]
===
match
---
fstring_expr [5356,5366]
fstring_expr [5356,5366]
===
match
---
operator: , [5373,5374]
operator: , [5373,5374]
===
match
---
name: session [7086,7093]
name: session [7086,7093]
===
match
---
atom [11930,11954]
atom [13045,13069]
===
match
---
expr_stmt [8052,8087]
expr_stmt [9167,9202]
===
match
---
name: TASK_ID [9275,9282]
name: TASK_ID [10390,10397]
===
match
---
trailer [6108,6122]
trailer [6108,6122]
===
match
---
simple_stmt [4804,4821]
simple_stmt [4804,4821]
===
match
---
name: super [5948,5953]
name: super [5948,5953]
===
match
---
atom_expr [6956,6976]
atom_expr [6956,6976]
===
match
---
fstring_start: f" [10174,10176]
fstring_start: f" [11289,11291]
===
match
---
operator: = [3152,3153]
operator: = [3152,3153]
===
match
---
name: self [10257,10261]
name: self [11372,11376]
===
match
---
atom_expr [1880,1965]
atom_expr [1880,1965]
===
match
---
name: info [6905,6909]
name: info [6905,6909]
===
match
---
operator: , [1028,1029]
operator: , [1028,1029]
===
match
---
dictorsetmaker [11036,11211]
dictorsetmaker [12151,12326]
===
match
---
import_from [1630,1675]
import_from [1630,1675]
===
match
---
arglist [4961,5077]
arglist [4961,5077]
===
match
---
name: api_connexion_utils [1520,1539]
name: api_connexion_utils [1520,1539]
===
match
---
string: ':' [7656,7659]
string: ':' [7656,7659]
===
match
---
name: itsdangerous [957,969]
name: itsdangerous [957,969]
===
match
---
number: 1 [1822,1823]
number: 1 [1822,1823]
===
match
---
name: data [9477,9481]
name: data [10592,10596]
===
match
---
atom [10955,10978]
atom [12070,12093]
===
match
---
operator: , [5010,5011]
operator: , [5010,5011]
===
match
---
trailer [4818,4820]
trailer [4818,4820]
===
match
---
name: path [3970,3974]
name: path [3970,3974]
===
match
---
operator: } [8790,8791]
operator: } [9905,9906]
===
match
---
string: "Log for testing." [5413,5431]
string: "Log for testing." [5413,5431]
===
match
---
atom_expr [4880,4896]
atom_expr [4880,4896]
===
match
---
operator: } [6786,6787]
operator: } [6786,6787]
===
match
---
trailer [3616,3624]
trailer [3616,3624]
===
match
---
string: "{}/{}/{}/{}/1.log" [6539,6558]
string: "{}/{}/{}/{}/1.log" [6539,6558]
===
match
---
name: response [6234,6242]
name: response [6234,6242]
===
match
---
dictorsetmaker [10956,10977]
dictorsetmaker [12071,12092]
===
match
---
expr_stmt [1719,1758]
expr_stmt [1719,1758]
===
match
---
operator: @ [9708,9709]
operator: @ [10823,10824]
===
match
---
name: DAG_ID [8215,8221]
name: DAG_ID [9330,9336]
===
match
---
string: 'utf-8' [9552,9559]
string: 'utf-8' [10667,10674]
===
match
---
fstring_string: /dagRuns/TEST_DAG_RUN_ID/ [12487,12512]
fstring_string: /dagRuns/TEST_DAG_RUN_ID/ [13602,13627]
===
match
---
operator: = [10313,10314]
operator: = [11428,11429]
===
match
---
name: dict [2918,2922]
name: dict [2918,2922]
===
match
---
name: _prepare_log_files [5171,5189]
name: _prepare_log_files [5171,5189]
===
match
---
trailer [5885,5901]
trailer [5885,5901]
===
match
---
atom [9008,9028]
atom [10123,10143]
===
match
---
operator: } [12408,12409]
operator: } [13523,13524]
===
match
---
operator: } [12100,12101]
operator: } [13215,13216]
===
match
---
name: old_modules [5765,5776]
name: old_modules [5765,5776]
===
match
---
name: airflow_local_settings [1134,1156]
name: airflow_local_settings [1134,1156]
===
match
---
fstring_expr [8209,8222]
fstring_expr [9324,9337]
===
match
---
name: timezone [1352,1360]
name: timezone [1352,1360]
===
match
---
name: self [7305,7309]
name: self [7305,7309]
===
match
---
trailer [2003,2017]
trailer [2003,2017]
===
match
---
fstring_string: taskInstances/ [9255,9269]
fstring_string: taskInstances/ [10370,10384]
===
match
---
suite [11276,11754]
suite [12391,12869]
===
match
---
name: modules [2927,2934]
name: modules [2927,2934]
===
match
---
trailer [5880,5902]
trailer [5880,5902]
===
match
---
trailer [4625,4627]
trailer [4625,4627]
===
match
---
atom [5724,5777]
atom [5724,5777]
===
match
---
string: '2nd line' [8830,8840]
string: '2nd line' [9945,9955]
===
match
---
fstring [9183,9236]
fstring [10298,10351]
===
match
---
simple_stmt [1427,1470]
simple_stmt [1427,1470]
===
match
---
fstring [12460,12513]
fstring [13575,13628]
===
match
---
name: create_user [2412,2423]
name: create_user [2412,2423]
===
match
---
name: dag_id [3114,3120]
name: dag_id [3114,3120]
===
match
---
import_from [1498,1583]
import_from [1498,1583]
===
match
---
decorated [7877,8506]
decorated [8992,9621]
===
match
---
trailer [10653,10662]
trailer [11768,11777]
===
match
---
atom [7486,7509]
atom [7486,7509]
===
match
---
fstring_expr [12087,12101]
fstring_expr [13202,13216]
===
match
---
fstring_string: api/v1/dags/ [7292,7304]
fstring_string: api/v1/dags/ [7292,7304]
===
match
---
simple_stmt [6942,6977]
simple_stmt [6942,6977]
===
match
---
strings [7290,7408]
strings [7290,7408]
===
match
---
operator: , [1220,1221]
operator: , [1220,1221]
===
match
---
name: log_dir [3651,3658]
name: log_dir [3651,3658]
===
match
---
operator: = [12328,12329]
operator: = [13443,13444]
===
match
---
name: self [4988,4992]
name: self [4988,4992]
===
match
---
name: default_time [4781,4793]
name: default_time [4781,4793]
===
match
---
name: format [6559,6565]
name: format [6559,6565]
===
match
---
atom_expr [5153,5160]
atom_expr [5153,5160]
===
match
---
name: tests [1589,1594]
name: tests [1589,1594]
===
match
---
name: _create_dagrun [10639,10653]
name: _create_dagrun [11754,11768]
===
match
---
operator: , [9309,9310]
operator: , [10424,10425]
===
match
---
name: self [12088,12092]
name: self [13203,13207]
===
match
---
fstring [5264,5305]
fstring [5264,5305]
===
match
---
operator: , [2263,2264]
operator: , [2263,2264]
===
match
---
fstring_start: f" [10753,10755]
fstring_start: f" [11868,11870]
===
match
---
operator: = [7197,7198]
operator: = [7197,7198]
===
match
---
assert_stmt [7684,7718]
assert_stmt [7684,7718]
===
match
---
name: json [11014,11018]
name: json [12129,12133]
===
match
---
name: replace [7648,7655]
name: replace [7648,7655]
===
match
---
fstring_string: /dagRuns/TEST_DAG_RUN_ID/ [7317,7342]
fstring_string: /dagRuns/TEST_DAG_RUN_ID/ [7317,7342]
===
match
---
dictorsetmaker [6415,6443]
dictorsetmaker [6415,6443]
===
match
---
name: assert_401 [1547,1557]
name: assert_401 [1547,1557]
===
match
---
name: mkdtemp [2820,2827]
name: mkdtemp [2820,2827]
===
match
---
operator: } [7385,7386]
operator: } [7385,7386]
===
match
---
simple_stmt [11817,11853]
simple_stmt [12932,12968]
===
match
---
atom_expr [3312,3329]
atom_expr [3312,3329]
===
match
---
name: headers [10885,10892]
name: headers [12000,12007]
===
match
---
assert_stmt [9636,9702]
assert_stmt [10751,10817]
===
match
---
atom_expr [6050,6078]
atom_expr [6050,6078]
===
match
---
atom_expr [7066,7094]
atom_expr [7066,7094]
===
match
---
trailer [11205,11210]
trailer [12320,12325]
===
match
---
trailer [12092,12100]
trailer [13207,13215]
===
match
---
operator: , [7951,7952]
operator: , [9066,9067]
===
match
---
operator: } [7238,7239]
operator: } [7238,7239]
===
match
---
name: file [5402,5406]
name: file [5402,5406]
===
match
---
name: TASK_ID [4993,5000]
name: TASK_ID [4993,5000]
===
match
---
string: '3rd line' [9580,9590]
string: '3rd line' [10695,10705]
===
match
---
operator: == [6953,6955]
operator: == [6953,6955]
===
match
---
operator: -> [2678,2680]
operator: -> [2678,2680]
===
match
---
trailer [3100,3376]
trailer [3100,3376]
===
match
---
with_stmt [4103,4192]
with_stmt [4103,4192]
===
match
---
fstring_end: " [12122,12123]
fstring_end: " [13237,13238]
===
match
---
name: dir_path [5326,5334]
name: dir_path [5326,5334]
===
match
---
atom_expr [5314,5335]
atom_expr [5314,5335]
===
match
---
trailer [3557,3581]
trailer [3557,3581]
===
match
---
atom_expr [10634,10662]
atom_expr [11749,11777]
===
match
---
string: 'application/json' [12156,12174]
string: 'application/json' [13271,13289]
===
match
---
name: dag [4804,4807]
name: dag [4804,4807]
===
match
---
trailer [3624,3643]
trailer [3624,3643]
===
match
---
simple_stmt [11861,11897]
simple_stmt [12976,13012]
===
match
---
atom_expr [10018,10040]
atom_expr [11133,11155]
===
match
---
operator: , [8591,8592]
operator: , [9706,9707]
===
match
---
fstring_start: f" [12071,12073]
fstring_start: f" [13186,13188]
===
match
---
suite [1714,12749]
suite [1714,13864]
===
match
---
atom_expr [4498,4506]
atom_expr [4498,4506]
===
match
---
name: DEFAULT_LOGGING_CONFIG [1164,1186]
name: DEFAULT_LOGGING_CONFIG [1164,1186]
===
match
---
simple_stmt [2604,2657]
simple_stmt [2604,2657]
===
match
---
name: timezone [4761,4769]
name: timezone [4761,4769]
===
match
---
atom [11599,11753]
atom [12714,12868]
===
match
---
name: headers [6406,6413]
name: headers [6406,6413]
===
match
---
name: provide_session [8512,8527]
name: provide_session [9627,9642]
===
match
---
operator: == [7790,7792]
operator: == [7790,7792]
===
match
---
name: self [2899,2903]
name: self [2899,2903]
===
match
---
funcdef [7898,8506]
funcdef [9013,9621]
===
match
---
name: self [3646,3650]
name: self [3646,3650]
===
match
---
trailer [9052,9064]
trailer [10167,10179]
===
match
---
name: token [8096,8101]
name: token [9211,9216]
===
match
---
funcdef [4633,5162]
funcdef [4633,5162]
===
match
---
comparison [7691,7718]
comparison [7691,7718]
===
match
---
param [7947,7952]
param [9062,9067]
===
match
---
name: info [6829,6833]
name: info [6829,6833]
===
match
---
name: testing [4524,4531]
name: testing [4524,4531]
===
match
---
name: DAG_ID [10194,10200]
name: DAG_ID [11309,11315]
===
match
---
atom_expr [8104,8145]
atom_expr [9219,9260]
===
match
---
simple_stmt [3012,3031]
simple_stmt [3012,3031]
===
match
---
operator: } [10869,10870]
operator: } [11984,11985]
===
match
---
arglist [6646,6654]
arglist [6646,6654]
===
match
---
simple_stmt [1470,1498]
simple_stmt [1470,1498]
===
match
---
atom [8823,8843]
atom [9938,9958]
===
match
---
atom_expr [3254,3271]
atom_expr [3254,3271]
===
match
---
name: self [3464,3468]
name: self [3464,3468]
===
match
---
operator: = [2587,2588]
operator: = [2587,2588]
===
match
---
name: write [5407,5412]
name: write [5407,5412]
===
match
---
trailer [10035,10040]
trailer [11150,11155]
===
match
---
trailer [12479,12486]
trailer [13594,13601]
===
match
---
funcdef [11759,12217]
funcdef [12874,13332]
===
match
---
operator: { [10863,10864]
operator: { [11978,11979]
===
match
---
name: decode [9545,9551]
name: decode [10660,10666]
===
match
---
name: self [3055,3059]
name: self [3055,3059]
===
match
---
expr_stmt [8806,8869]
expr_stmt [9921,9984]
===
match
---
atom [10893,10923]
atom [12008,12038]
===
match
---
arglist [4113,4131]
arglist [4113,4131]
===
match
---
trailer [4568,4572]
trailer [4568,4572]
===
match
---
operator: = [8063,8064]
operator: = [9178,9179]
===
match
---
operator: = [4507,4508]
operator: = [4507,4508]
===
match
---
name: app [12284,12287]
name: app [13399,13402]
===
match
---
name: log_dir [2801,2808]
name: log_dir [2801,2808]
===
match
---
operator: , [4000,4001]
operator: , [4000,4001]
===
match
---
fstring_start: f" [8195,8197]
fstring_start: f" [9310,9312]
===
match
---
atom_expr [5549,5564]
atom_expr [5549,5564]
===
match
---
name: run_type [3184,3192]
name: run_type [3184,3192]
===
match
---
dictorsetmaker [8122,8143]
dictorsetmaker [9237,9258]
===
match
---
comparison [11005,11221]
comparison [12120,12336]
===
match
---
atom [12600,12624]
atom [13715,13739]
===
match
---
fstring_expr [6288,6301]
fstring_expr [6288,6301]
===
match
---
name: self [4673,4677]
name: self [4673,4677]
===
match
---
trailer [3125,3132]
trailer [3125,3132]
===
match
---
simple_stmt [5402,5433]
simple_stmt [5402,5433]
===
match
---
atom [2235,2294]
atom [2235,2294]
===
match
---
atom [10074,10098]
atom [11189,11213]
===
match
---
atom_expr [6539,6665]
atom_expr [6539,6665]
===
match
---
name: utils [1440,1445]
name: utils [1440,1445]
===
match
---
simple_stmt [4664,4719]
simple_stmt [4664,4719]
===
match
---
atom_expr [2944,2969]
atom_expr [2944,2969]
===
match
---
operator: } [8368,8369]
operator: } [9483,9484]
===
match
---
atom_expr [1979,1986]
atom_expr [1979,1986]
===
match
---
name: session [6070,6077]
name: session [6070,6077]
===
match
---
name: log_dir [5930,5937]
name: log_dir [5930,5937]
===
match
---
simple_stmt [11905,11956]
simple_stmt [13020,13071]
===
match
---
trailer [7085,7094]
trailer [7085,7094]
===
match
---
dictorsetmaker [10382,10403]
dictorsetmaker [11497,11518]
===
match
---
trailer [5562,5564]
trailer [5562,5564]
===
match
---
name: session [10654,10661]
name: session [11769,11776]
===
match
---
operator: { [7372,7373]
operator: { [7372,7373]
===
match
---
operator: } [8312,8313]
operator: } [9427,9428]
===
match
---
operator: } [7839,7840]
operator: } [7839,7840]
===
match
---
fstring_end: " [10870,10871]
fstring_end: " [11985,11986]
===
match
---
name: token [10864,10869]
name: token [11979,11984]
===
match
---
name: open [5349,5353]
name: open [5349,5353]
===
match
---
param [3464,3468]
param [3464,3468]
===
match
---
argument [2579,2594]
argument [2579,2594]
===
match
---
operator: = [6091,6092]
operator: = [6091,6092]
===
match
---
name: client [10150,10156]
name: client [11265,11271]
===
match
---
name: mod [5717,5720]
name: mod [5717,5720]
===
match
---
name: app [8019,8022]
name: app [9134,9137]
===
match
---
name: run_id [3146,3152]
name: run_id [3146,3152]
===
match
---
trailer [9607,9614]
trailer [10722,10729]
===
match
---
operator: @ [7877,7878]
operator: @ [8992,8993]
===
match
---
simple_stmt [8096,8146]
simple_stmt [9211,9261]
===
match
---
operator: = [8102,8103]
operator: = [9217,9218]
===
match
---
trailer [9902,9916]
trailer [11017,11031]
===
match
---
name: airflow [1432,1439]
name: airflow [1432,1439]
===
match
---
atom_expr [2923,2934]
atom_expr [2923,2934]
===
match
---
string: 'text/plain' [7441,7453]
string: 'text/plain' [7441,7453]
===
match
---
import_from [1235,1284]
import_from [1235,1284]
===
match
---
operator: { [7486,7487]
operator: { [7486,7487]
===
match
---
string: '' [8901,8903]
string: '' [10016,10018]
===
match
---
operator: , [11555,11556]
operator: , [12670,12671]
===
match
---
string: 'status' [11064,11072]
string: 'status' [12179,12187]
===
match
---
atom [8920,8942]
atom [10035,10057]
===
match
---
name: timezone [5043,5051]
name: timezone [5043,5051]
===
match
---
name: key [7178,7181]
name: key [7178,7181]
===
match
---
trailer [7209,7215]
trailer [7209,7215]
===
match
---
trailer [6565,6665]
trailer [6565,6665]
===
match
---
string: 'utf-8' [10545,10552]
string: 'utf-8' [11660,11667]
===
match
---
fstring [10819,10871]
fstring [11934,11986]
===
match
---
decorator [2501,2514]
decorator [2501,2514]
===
match
---
atom_expr [12020,12031]
atom_expr [13135,13146]
===
match
---
atom_expr [12196,12216]
atom_expr [13311,13331]
===
match
---
name: api_connexion [1052,1065]
name: api_connexion [1052,1065]
===
match
---
trailer [11013,11018]
trailer [12128,12133]
===
match
---
string: "download_logs" [12387,12402]
string: "download_logs" [13502,13517]
===
match
---
simple_stmt [819,829]
simple_stmt [819,829]
===
match
---
string: "download_logs" [10075,10090]
string: "download_logs" [11190,11205]
===
match
---
operator: , [2059,2060]
operator: , [2059,2060]
===
match
---
simple_stmt [1039,1104]
simple_stmt [1039,1104]
===
match
---
testlist_comp [8769,8783]
testlist_comp [9884,9898]
===
match
---
name: DagRunType [1459,1469]
name: DagRunType [1459,1469]
===
match
---
operator: @ [6982,6983]
operator: @ [6982,6983]
===
match
---
name: app [1983,1986]
name: app [1983,1986]
===
match
---
string: "airflow.api_connexion.endpoints.log_endpoint.TaskLogReader" [9720,9780]
string: "airflow.api_connexion.endpoints.log_endpoint.TaskLogReader" [10835,10895]
===
match
---
atom_expr [6579,6591]
atom_expr [6579,6591]
===
match
---
operator: = [4760,4761]
operator: = [4760,4761]
===
match
---
operator: = [3965,3966]
operator: = [3965,3966]
===
match
---
name: self [12475,12479]
name: self [13590,13594]
===
match
---
argument [4750,4794]
argument [4750,4794]
===
match
---
number: 400 [11074,11077]
number: 400 [12189,12192]
===
match
---
expr_stmt [6829,6889]
expr_stmt [6829,6889]
===
match
---
string: 'REMOTE_USER' [6477,6490]
string: 'REMOTE_USER' [6477,6490]
===
match
---
simple_stmt [7727,7872]
simple_stmt [7727,7872]
===
match
---
name: config [1606,1612]
name: config [1606,1612]
===
match
---
name: get [7273,7276]
name: get [7273,7276]
===
match
---
fstring_expr [6768,6787]
fstring_expr [6768,6787]
===
match
---
parameters [9835,9858]
parameters [10950,10973]
===
match
---
name: self [5925,5929]
name: self [5925,5929]
===
match
---
name: create_session [4880,4894]
name: create_session [4880,4894]
===
match
---
atom_expr [3980,4000]
atom_expr [3980,4000]
===
match
---
string: "w+" [5375,5379]
string: "w+" [5375,5379]
===
match
---
trailer [10638,10653]
trailer [11753,11768]
===
match
---
expr_stmt [4727,4795]
expr_stmt [4727,4795]
===
match
---
suite [4908,5162]
suite [4908,5162]
===
match
---
operator: , [2217,2218]
operator: , [2217,2218]
===
match
---
simple_stmt [8052,8088]
simple_stmt [9167,9203]
===
match
---
operator: , [5296,5297]
operator: , [5296,5297]
===
match
---
name: serializer [7199,7209]
name: serializer [7199,7209]
===
match
---
simple_stmt [6131,6167]
simple_stmt [6131,6167]
===
match
---
name: app [7114,7117]
name: app [7114,7117]
===
match
---
name: return_value [9932,9944]
name: return_value [11047,11059]
===
match
---
name: provide_session [1411,1426]
name: provide_session [1411,1426]
===
match
---
arglist [5354,5379]
arglist [5354,5379]
===
match
---
expr_stmt [6234,6510]
expr_stmt [6234,6510]
===
match
---
simple_stmt [6175,6226]
simple_stmt [6175,6226]
===
match
---
operator: , [2294,2295]
operator: , [2294,2295]
===
match
---
name: test_utils [1595,1605]
name: test_utils [1595,1605]
===
match
---
atom_expr [7630,7665]
atom_expr [7630,7665]
===
match
---
simple_stmt [5139,5162]
simple_stmt [5139,5162]
===
match
---
dictorsetmaker [12387,12408]
dictorsetmaker [13502,13523]
===
match
---
name: DagRun [3094,3100]
name: DagRun [3094,3100]
===
match
---
name: self [4216,4220]
name: self [4216,4220]
===
match
---
expr_stmt [6131,6166]
expr_stmt [6131,6166]
===
match
---
name: third_return [9097,9109]
name: third_return [10212,10224]
===
match
---
operator: = [8012,8013]
operator: = [9127,9128]
===
match
---
fstring_string: taskInstances/ [12528,12542]
fstring_string: taskInstances/ [13643,13657]
===
match
---
simple_stmt [11575,11754]
simple_stmt [12690,12869]
===
match
---
name: self [5476,5480]
name: self [5476,5480]
===
match
---
trailer [8447,8452]
trailer [9562,9567]
===
match
---
operator: , [2577,2578]
operator: , [2577,2578]
===
match
---
name: airflow [1366,1373]
name: airflow [1366,1373]
===
match
---
string: 'Task log handler does not support read logs.' [10474,10520]
string: 'Task log handler does not support read logs.' [11589,11635]
===
match
---
atom_expr [10836,10848]
atom_expr [11951,11963]
===
match
---
name: dag [4848,4851]
name: dag [4848,4851]
===
match
---
name: test_should_respond_200_json [5997,6025]
name: test_should_respond_200_json [5997,6025]
===
match
---
operator: , [11077,11078]
operator: , [12192,12193]
===
match
---
operator: , [4851,4852]
operator: , [4851,4852]
===
match
---
argument [2073,2088]
argument [2073,2088]
===
match
---
trailer [5051,5057]
trailer [5051,5057]
===
match
---
name: self [10145,10149]
name: self [11260,11264]
===
match
---
name: mock_log_reader [9873,9888]
name: mock_log_reader [10988,11003]
===
match
---
fstring_start: f" [5216,5218]
fstring_start: f" [5216,5218]
===
match
---
operator: = [8895,8896]
operator: = [10010,10011]
===
match
---
string: 'utf-8' [9489,9496]
string: 'utf-8' [10604,10611]
===
match
---
string: "Test" [2112,2118]
string: "Test" [2112,2118]
===
match
---
trailer [11831,11838]
trailer [12946,12953]
===
match
---
trailer [2755,2762]
trailer [2755,2762]
===
match
---
atom [4387,4410]
atom [4387,4410]
===
match
---
argument [2004,2016]
argument [2004,2016]
===
match
---
trailer [3548,3557]
trailer [3548,3557]
===
match
---
name: dumps [12380,12385]
name: dumps [13495,13500]
===
match
---
trailer [7124,7138]
trailer [7124,7138]
===
match
---
name: test_utils [1641,1651]
name: test_utils [1641,1651]
===
match
---
argument [5028,5076]
argument [5028,5076]
===
match
---
simple_stmt [10713,10990]
simple_stmt [11828,12105]
===
match
---
operator: } [10348,10349]
operator: } [11463,11464]
===
match
---
fstring_string: taskInstances/Invalid-Task-ID/logs/1?token= [8263,8306]
fstring_string: taskInstances/Invalid-Task-ID/logs/1?token= [9378,9421]
===
match
---
operator: , [4459,4460]
operator: , [4459,4460]
===
match
---
trailer [7272,7276]
trailer [7272,7276]
===
match
---
fstring_string: /1.log [5366,5372]
fstring_string: /1.log [5366,5372]
===
match
---
string: '3rd line' [8905,8915]
string: '3rd line' [10020,10030]
===
match
---
operator: { [10767,10768]
operator: { [11882,11883]
===
match
---
expr_stmt [12273,12308]
expr_stmt [13388,13423]
===
match
---
dotted_name [1044,1076]
dotted_name [1044,1076]
===
match
---
arglist [10753,10979]
arglist [11868,12094]
===
match
---
operator: , [2190,2191]
operator: , [2190,2191]
===
match
---
trailer [9161,9165]
trailer [10276,10280]
===
match
---
name: self [6593,6597]
name: self [6593,6597]
===
match
---
name: get [8178,8181]
name: get [9293,9296]
===
match
---
atom [1891,1914]
atom [1891,1914]
===
match
---
name: MANUAL [3204,3210]
name: MANUAL [3204,3210]
===
match
---
name: shutil [5867,5873]
name: shutil [5867,5873]
===
match
---
name: unittest [891,899]
name: unittest [891,899]
===
match
---
fstring [4058,4094]
fstring [4058,4094]
===
match
---
simple_stmt [2899,2936]
simple_stmt [2899,2936]
===
match
---
testlist_comp [8898,8942]
testlist_comp [10013,10057]
===
match
---
arglist [10174,10405]
arglist [11289,11520]
===
match
---
name: self [11296,11300]
name: self [12411,12415]
===
match
---
simple_stmt [6050,6079]
simple_stmt [6050,6079]
===
match
---
param [3055,3060]
param [3055,3060]
===
match
---
arglist [12005,12176]
arglist [13120,13291]
===
match
---
name: permissions [2236,2247]
name: permissions [2236,2247]
===
match
---
comparison [5751,5776]
comparison [5751,5776]
===
match
---
name: self [4737,4741]
name: self [4737,4741]
===
match
---
operator: = [4731,4732]
operator: = [4731,4732]
===
match
---
string: "api" [4388,4393]
string: "api" [4388,4393]
===
match
---
name: conf_vars [1880,1889]
name: conf_vars [1880,1889]
===
match
---
name: headers [10306,10313]
name: headers [11421,11428]
===
match
---
name: modules [5799,5806]
name: modules [5799,5806]
===
match
---
number: 400 [11206,11209]
number: 400 [12321,12324]
===
match
---
name: ACTION_CAN_READ [2175,2190]
name: ACTION_CAN_READ [2175,2190]
===
match
---
fstring_expr [8306,8313]
fstring_expr [9421,9428]
===
match
---
name: DAG_ID [6598,6604]
name: DAG_ID [6598,6604]
===
match
---
name: handle [4136,4142]
name: handle [4136,4142]
===
match
---
name: self [3012,3016]
name: self [3012,3016]
===
match
---
fstring_end: " [6809,6810]
fstring_end: " [6809,6810]
===
match
---
trailer [4843,4866]
trailer [4843,4866]
===
match
---
argument [6458,6499]
argument [6458,6499]
===
match
---
atom_expr [5267,5302]
atom_expr [5267,5302]
===
match
---
operator: } [6223,6224]
operator: } [6223,6224]
===
match
---
trailer [7706,7718]
trailer [7706,7718]
===
match
---
name: conf_vars [4252,4261]
name: conf_vars [4252,4261]
===
match
---
operator: = [2011,2012]
operator: = [2011,2012]
===
match
---
operator: == [8417,8419]
operator: == [9532,9534]
===
match
---
assert_stmt [11575,11753]
assert_stmt [12690,12868]
===
match
---
dictorsetmaker [12146,12174]
dictorsetmaker [13261,13289]
===
match
---
name: dictConfig [5506,5516]
name: dictConfig [5506,5516]
===
match
---
fstring [11325,11375]
fstring [12440,12490]
===
match
---
name: PropertyMock [9919,9931]
name: PropertyMock [11034,11046]
===
match
---
name: dagbag [4829,4835]
name: dagbag [4829,4835]
===
match
---
decorated [5972,6977]
decorated [5972,6977]
===
match
---
name: tempfile [2811,2819]
name: tempfile [2811,2819]
===
match
---
decorator [5972,5989]
decorator [5972,5989]
===
match
---
operator: { [8209,8210]
operator: { [9324,9325]
===
match
---
name: PropertyMock [938,950]
name: PropertyMock [938,950]
===
match
---
name: environ_overrides [12638,12655]
name: environ_overrides [13753,13770]
===
match
---
param [6026,6031]
param [6026,6031]
===
match
---
name: TASK_ID [12093,12100]
name: TASK_ID [13208,13215]
===
match
---
name: read_mock [9043,9052]
name: read_mock [10158,10167]
===
match
---
trailer [5929,5937]
trailer [5929,5937]
===
match
---
atom_expr [5248,5260]
atom_expr [5248,5260]
===
match
---
trailer [9931,9951]
trailer [11046,11066]
===
match
---
trailer [10261,10269]
trailer [11376,11384]
===
match
---
trailer [4523,4537]
trailer [4523,4537]
===
match
---
operator: { [6768,6769]
operator: { [6768,6769]
===
match
---
trailer [7276,7520]
trailer [7276,7520]
===
match
---
simple_stmt [9573,9624]
simple_stmt [10688,10739]
===
match
---
operator: , [9095,9096]
operator: , [10210,10211]
===
match
---
name: session [3385,3392]
name: session [3385,3392]
===
match
---
expr_stmt [10049,10099]
expr_stmt [11164,11214]
===
match
---
string: 'logging_config_class' [4305,4327]
string: 'logging_config_class' [4305,4327]
===
match
---
trailer [11923,11929]
trailer [13038,13044]
===
match
---
name: response [10713,10721]
name: response [11828,11836]
===
match
---
name: fourth_return [9111,9124]
name: fourth_return [10226,10239]
===
match
---
name: response [8396,8404]
name: response [9511,9519]
===
match
---
trailer [12385,12410]
trailer [13500,13525]
===
match
---
fstring [5354,5373]
fstring [5354,5373]
===
match
---
name: models [1200,1206]
name: models [1200,1206]
===
match
---
trailer [3305,3311]
trailer [3305,3311]
===
match
---
fstring_expr [9197,9210]
fstring_expr [10312,10325]
===
match
---
trailer [5111,5122]
trailer [5111,5122]
===
match
---
trailer [3702,3745]
trailer [3702,3745]
===
match
---
trailer [10544,10553]
trailer [11659,11668]
===
match
---
name: username [2433,2441]
name: username [2433,2441]
===
match
---
with_stmt [4875,5162]
with_stmt [4875,5162]
===
match
---
trailer [5505,5516]
trailer [5505,5516]
===
match
---
operator: } [9209,9210]
operator: } [10324,10325]
===
match
---
fstring_expr [4077,4093]
fstring_expr [4077,4093]
===
match
---
trailer [4943,5091]
trailer [4943,5091]
===
match
---
comparison [7748,7861]
comparison [7748,7861]
===
match
---
name: test_client [4573,4584]
name: test_client [4573,4584]
===
match
---
atom_expr [2570,2577]
atom_expr [2570,2577]
===
match
---
import_from [886,911]
import_from [886,911]
===
match
---
assert_stmt [8432,8505]
assert_stmt [9547,9620]
===
match
---
name: unittest [1695,1703]
name: unittest [1695,1703]
===
match
---
name: self [4921,4925]
name: self [4921,4925]
===
match
---
operator: , [12175,12176]
operator: , [13290,13291]
===
match
---
name: app [4569,4572]
name: app [4569,4572]
===
match
---
decorator [10559,10576]
decorator [11674,11691]
===
match
---
operator: } [6932,6933]
operator: } [6932,6933]
===
match
---
name: response [12721,12729]
name: response [13836,13844]
===
match
---
operator: = [3542,3543]
operator: = [3542,3543]
===
match
---
arglist [8195,8370]
arglist [9310,9485]
===
match
---
name: test_client [2774,2785]
name: test_client [2774,2785]
===
match
---
fstring_end: " [5304,5305]
fstring_end: " [5304,5305]
===
match
---
name: sys [4200,4203]
name: sys [4200,4203]
===
match
---
name: DAG [4733,4736]
name: DAG [4733,4736]
===
match
---
operator: { [12474,12475]
operator: { [13589,13590]
===
match
---
trailer [6624,6637]
trailer [6624,6637]
===
match
---
operator: , [4126,4127]
operator: , [4126,4127]
===
match
---
string: 'task_for_testing_log_endpoint' [1773,1804]
string: 'task_for_testing_log_endpoint' [1773,1804]
===
match
---
operator: , [7601,7602]
operator: , [7601,7602]
===
match
---
atom_expr [4761,4794]
atom_expr [4761,4794]
===
match
---
name: self [6093,6097]
name: self [6093,6097]
===
match
---
atom_expr [2616,2623]
atom_expr [2616,2623]
===
match
---
operator: { [10679,10680]
operator: { [11794,11795]
===
match
---
assert_stmt [6942,6976]
assert_stmt [6942,6976]
===
match
---
atom_expr [5881,5901]
atom_expr [5881,5901]
===
match
---
trailer [3969,3974]
trailer [3969,3974]
===
match
---
operator: { [8846,8847]
operator: { [9961,9962]
===
match
---
dotted_name [1366,1387]
dotted_name [1366,1387]
===
match
---
name: app [1989,1992]
name: app [1989,1992]
===
match
---
argument [4980,5000]
argument [4980,5000]
===
match
---
operator: = [10954,10955]
operator: = [12069,12070]
===
match
---
operator: } [11752,11753]
operator: } [12867,12868]
===
match
---
operator: = [10722,10723]
operator: = [11837,11838]
===
match
---
expr_stmt [6087,6122]
expr_stmt [6087,6122]
===
match
---
atom_expr [3193,3210]
atom_expr [3193,3210]
===
match
---
trailer [11991,12186]
trailer [13106,13301]
===
match
---
name: default_time [3259,3271]
name: default_time [3259,3271]
===
match
---
operator: == [6732,6734]
operator: == [6732,6734]
===
match
---
parameters [7946,7961]
parameters [9061,9076]
===
match
---
operator: = [4987,4988]
operator: = [4987,4988]
===
match
---
operator: { [12115,12116]
operator: { [13230,13231]
===
match
---
simple_stmt [5445,5458]
simple_stmt [5445,5458]
===
match
---
name: self [12543,12547]
name: self [13658,13662]
===
match
---
operator: = [3644,3645]
operator: = [3644,3645]
===
match
---
trailer [6964,6976]
trailer [6964,6976]
===
match
---
operator: } [7316,7317]
operator: } [7316,7317]
===
match
---
name: self [11426,11430]
name: self [12541,12545]
===
match
---
operator: } [12555,12556]
operator: } [13670,13671]
===
match
---
argument [2102,2118]
argument [2102,2118]
===
match
---
name: logging [5491,5498]
name: logging [5491,5498]
===
match
---
operator: , [3272,3273]
operator: , [3272,3273]
===
match
---
comparison [6695,6810]
comparison [6695,6810]
===
match
---
string: 'Content-Type' [10315,10329]
string: 'Content-Type' [11430,11444]
===
match
---
operator: { [12570,12571]
operator: { [13685,13686]
===
match
---
argument [12592,12624]
argument [13707,13739]
===
match
---
expr_stmt [10671,10703]
expr_stmt [11786,11818]
===
match
---
param [1861,1864]
param [1861,1864]
===
match
---
name: DAG_ID [12480,12486]
name: DAG_ID [13595,13601]
===
match
---
operator: = [3192,3193]
operator: = [3192,3193]
===
match
---
operator: , [12694,12695]
operator: , [13809,13810]
===
match
---
argument [2433,2463]
argument [2433,2463]
===
match
---
name: serializer [11913,11923]
name: serializer [13028,13038]
===
match
---
operator: = [10143,10144]
operator: = [11258,11259]
===
match
---
atom_expr [5948,5966]
atom_expr [5948,5966]
===
match
---
expr_stmt [11905,11955]
expr_stmt [13020,13070]
===
match
---
name: second_return [9082,9095]
name: second_return [10197,10210]
===
match
---
expr_stmt [11817,11852]
expr_stmt [12932,12967]
===
match
---
dotted_name [804,818]
dotted_name [804,818]
===
match
---
trailer [5223,5231]
trailer [5223,5231]
===
match
---
string: "test_no_permissions" [12672,12693]
string: "test_no_permissions" [13787,13808]
===
match
---
import_name [819,828]
import_name [819,828]
===
match
---
comp_if [5748,5776]
comp_if [5748,5776]
===
match
---
simple_stmt [1361,1427]
simple_stmt [1361,1427]
===
match
---
number: 404 [11738,11741]
number: 404 [12853,12856]
===
match
---
atom [8974,9004]
atom [10089,10119]
===
match
---
name: self [10189,10193]
name: self [11304,11308]
===
match
---
name: app [4503,4506]
name: app [4503,4506]
===
match
---
fstring [6274,6327]
fstring [6274,6327]
===
match
---
name: dagrun_model [3397,3409]
name: dagrun_model [3397,3409]
===
match
---
assert_stmt [8389,8423]
assert_stmt [9504,9538]
===
match
---
trailer [4807,4818]
trailer [4807,4818]
===
match
---
atom_expr [4216,4236]
atom_expr [4216,4236]
===
match
---
operator: , [10871,10872]
operator: , [11986,11987]
===
match
---
name: session [7991,7998]
name: session [9106,9113]
===
match
---
trailer [4677,4681]
trailer [4677,4681]
===
match
---
trailer [7070,7085]
trailer [7070,7085]
===
match
---
name: app [2574,2577]
name: app [2574,2577]
===
match
---
fstring [6735,6810]
fstring [6735,6810]
===
match
---
operator: { [5266,5267]
operator: { [5266,5267]
===
match
---
name: URLSafeSerializer [10018,10035]
name: URLSafeSerializer [11133,11150]
===
match
---
operator: = [11911,11912]
operator: = [13026,13027]
===
match
---
atom_expr [7160,7182]
atom_expr [7160,7182]
===
match
---
name: sys [850,853]
name: sys [850,853]
===
match
---
string: 'Accept' [10894,10902]
string: 'Accept' [12009,12017]
===
match
---
trailer [3940,3942]
trailer [3940,3942]
===
match
---
operator: { [7821,7822]
operator: { [7821,7822]
===
match
---
name: rmtree [5874,5880]
name: rmtree [5874,5880]
===
match
---
name: self [2796,2800]
name: self [2796,2800]
===
match
---
atom [2312,2377]
atom [2312,2377]
===
match
---
name: DAG_ID [1719,1725]
name: DAG_ID [1719,1725]
===
match
---
atom_expr [9468,9497]
atom_expr [10583,10612]
===
match
---
funcdef [12222,12749]
funcdef [13337,13864]
===
match
---
simple_stmt [3951,4031]
simple_stmt [3951,4031]
===
match
---
name: self [7947,7951]
name: self [9062,9066]
===
match
---
operator: } [12031,12032]
operator: } [13146,13147]
===
match
---
with_stmt [5344,5458]
with_stmt [5344,5458]
===
match
---
trailer [5798,5806]
trailer [5798,5806]
===
match
---
name: token [12116,12121]
name: token [13231,13236]
===
match
---
trailer [5406,5412]
trailer [5406,5412]
===
match
---
funcdef [8532,9703]
funcdef [9647,10818]
===
match
---
name: logging [804,811]
name: logging [804,811]
===
match
---
atom [8121,8144]
atom [9236,9259]
===
match
---
simple_stmt [5104,5127]
simple_stmt [5104,5127]
===
match
---
atom_expr [3967,4030]
atom_expr [3967,4030]
===
match
---
operator: = [9394,9395]
operator: = [10509,10510]
===
match
---
name: _configure_loggers [3445,3463]
name: _configure_loggers [3445,3463]
===
match
---
fstring_string: taskInstances/ [12073,12087]
fstring_string: taskInstances/ [13188,13202]
===
match
---
name: settings_folder [5886,5901]
name: settings_folder [5886,5901]
===
match
---
name: config [8023,8029]
name: config [9138,9144]
===
match
---
operator: = [2474,2475]
operator: = [2474,2475]
===
match
---
atom [7734,7871]
atom [7734,7871]
===
match
---
import_from [1361,1426]
import_from [1361,1426]
===
match
---
name: test_should_respond_200_text_plain [7007,7041]
name: test_should_respond_200_text_plain [7007,7041]
===
match
---
trailer [8181,8380]
trailer [9296,9495]
===
match
---
funcdef [5463,5967]
funcdef [5463,5967]
===
match
---
trailer [5917,5924]
trailer [5917,5924]
===
match
---
name: DAG_ID [5239,5245]
name: DAG_ID [5239,5245]
===
match
---
name: default_time [5272,5284]
name: default_time [5272,5284]
===
match
---
operator: , [7628,7629]
operator: , [7628,7629]
===
match
---
name: client [11981,11987]
name: client [13096,13102]
===
match
---
name: dag_bag [4682,4689]
name: dag_bag [4682,4689]
===
match
---
fstring_expr [9269,9283]
fstring_expr [10384,10398]
===
match
---
string: "SECRET_KEY" [9983,9995]
string: "SECRET_KEY" [11098,11110]
===
match
---
classdef [1678,12749]
classdef [1678,13864]
===
match
---
name: db [1652,1654]
name: db [1652,1654]
===
match
---
name: DAG_ID [12025,12031]
name: DAG_ID [13140,13146]
===
match
---
operator: , [7408,7409]
operator: , [7408,7409]
===
match
---
trailer [10735,10739]
trailer [11850,11854]
===
match
---
string: "test" [8362,8368]
string: "test" [9477,9483]
===
match
---
fstring_string: /dagRuns/TEST_DAG_RUN_ID/ [9210,9235]
fstring_string: /dagRuns/TEST_DAG_RUN_ID/ [10325,10350]
===
match
---
name: self [6289,6293]
name: self [6289,6293]
===
match
---
trailer [12729,12741]
trailer [13844,13856]
===
match
---
trailer [9488,9497]
trailer [10603,10612]
===
match
---
fstring_expr [10284,10291]
fstring_expr [11399,11406]
===
match
---
fstring_expr [5218,5232]
fstring_expr [5218,5232]
===
match
---
string: "download_logs" [6201,6216]
string: "download_logs" [6201,6216]
===
match
---
trailer [5516,5540]
trailer [5516,5540]
===
match
---
dictorsetmaker [9396,9417]
dictorsetmaker [10511,10532]
===
match
---
fstring_string: \nLog for testing.\n [7840,7860]
fstring_string: \nLog for testing.\n [7840,7860]
===
match
---
trailer [10149,10156]
trailer [11264,11271]
===
match
---
operator: , [6499,6500]
operator: , [6499,6500]
===
match
---
atom_expr [12543,12555]
atom_expr [13658,13670]
===
match
---
operator: { [8306,8307]
operator: { [9421,9422]
===
match
---
simple_stmt [5791,5812]
simple_stmt [5791,5812]
===
match
---
simple_stmt [829,843]
simple_stmt [829,843]
===
match
---
name: serializer [11861,11871]
name: serializer [12976,12986]
===
match
---
trailer [9693,9702]
trailer [10808,10817]
===
match
---
name: config_templates [1117,1133]
name: config_templates [1117,1133]
===
match
---
atom [8768,8784]
atom [9883,9899]
===
match
---
name: token [10049,10054]
name: token [11164,11169]
===
match
---
operator: = [4562,4563]
operator: = [4562,4563]
===
match
---
name: EXCEPTIONS_LINK_MAP [1084,1103]
name: EXCEPTIONS_LINK_MAP [1084,1103]
===
match
---
name: self [5153,5157]
name: self [5153,5157]
===
match
---
operator: } [10702,10703]
operator: } [11817,11818]
===
match
---
simple_stmt [2978,3004]
simple_stmt [2978,3004]
===
match
---
string: "SECRET_KEY" [12295,12307]
string: "SECRET_KEY" [13410,13422]
===
match
---
atom [8899,8917]
atom [10014,10032]
===
match
---
atom_expr [9198,9209]
atom_expr [10313,10324]
===
match
---
name: try_number [5112,5122]
name: try_number [5112,5122]
===
match
---
atom_expr [7373,7385]
atom_expr [7373,7385]
===
match
---
trailer [9202,9209]
trailer [10317,10324]
===
match
---
string: 'handlers' [3605,3615]
string: 'handlers' [3605,3615]
===
match
---
decorated [10559,11222]
decorated [11674,12337]
===
match
---
funcdef [2662,3031]
funcdef [2662,3031]
===
match
---
atom_expr [6357,6369]
atom_expr [6357,6369]
===
match
---
name: utils [1374,1379]
name: utils [1374,1379]
===
match
---
name: TASK_ID [5253,5260]
name: TASK_ID [5253,5260]
===
match
---
operator: { [11339,11340]
operator: { [12454,12455]
===
match
---
atom [8898,8918]
atom [10013,10033]
===
match
---
atom [8822,8869]
atom [9937,9984]
===
match
---
name: self [2751,2755]
name: self [2751,2755]
===
match
---
name: new_logging_file [4174,4190]
name: new_logging_file [4174,4190]
===
match
---
comparison [9643,9702]
comparison [10758,10817]
===
match
---
simple_stmt [2412,2496]
simple_stmt [2412,2496]
===
match
---
dotted_name [1589,1612]
dotted_name [1589,1612]
===
match
---
trailer [12442,12446]
trailer [13557,13561]
===
match
---
suite [1866,2496]
suite [1866,2496]
===
match
---
fstring_expr [12542,12556]
fstring_expr [13657,13671]
===
match
---
string: "test" [6492,6498]
string: "test" [6492,6498]
===
match
---
fstring_end: " [4093,4094]
fstring_end: " [4093,4094]
===
match
---
import_name [829,842]
import_name [829,842]
===
match
---
trailer [5292,5302]
trailer [5292,5302]
===
match
---
atom_expr [5491,5540]
atom_expr [5491,5540]
===
match
---
trailer [7990,7999]
trailer [9105,9114]
===
match
---
simple_stmt [7684,7719]
simple_stmt [7684,7719]
===
match
---
operator: } [10269,10270]
operator: } [11384,11385]
===
match
---
import_from [1104,1186]
import_from [1104,1186]
===
match
---
name: response [11582,11590]
name: response [12697,12705]
===
match
---
atom_expr [2695,2712]
atom_expr [2695,2712]
===
match
---
trailer [9539,9544]
trailer [10654,10659]
===
match
---
argument [9932,9950]
argument [11047,11065]
===
match
---
trailer [3694,3702]
trailer [3694,3702]
===
match
---
operator: { [8121,8122]
operator: { [9236,9237]
===
match
---
operator: == [11596,11598]
operator: == [12711,12713]
===
match
---
string: "DAG Run not found" [11677,11696]
string: "DAG Run not found" [12792,12811]
===
match
---
funcdef [3441,4628]
funcdef [3441,4628]
===
match
---
string: "Bad Signature. Please use only the tokens provided by the API." [11100,11164]
string: "Bad Signature. Please use only the tokens provided by the API." [12215,12279]
===
match
---
comparison [10474,10553]
comparison [11589,11668]
===
match
---
trailer [5953,5955]
trailer [5953,5955]
===
match
---
name: DAG_ID [11345,11351]
name: DAG_ID [12460,12466]
===
match
---
operator: { [11425,11426]
operator: { [12540,12541]
===
match
---
trailer [12287,12294]
trailer [13402,13409]
===
match
---
number: 400 [10431,10434]
number: 400 [11546,11549]
===
match
---
string: "tests.test_utils.remote_user_api_auth_backend" [1916,1963]
string: "tests.test_utils.remote_user_api_auth_backend" [1916,1963]
===
match
---
name: self [2672,2676]
name: self [2672,2676]
===
match
---
operator: = [6537,6538]
operator: = [6537,6538]
===
match
---
name: dag [4862,4865]
name: dag [4862,4865]
===
match
---
fstring [10753,10806]
fstring [11868,11921]
===
match
---
name: self [11802,11806]
name: self [12917,12921]
===
match
---
trailer [2903,2915]
trailer [2903,2915]
===
match
---
name: _create_dagrun [7976,7990]
name: _create_dagrun [9091,9105]
===
match
---
trailer [4215,4237]
trailer [4215,4237]
===
match
---
string: 'detail' [11613,11621]
string: 'detail' [12728,12736]
===
match
---
name: serializer [8104,8114]
name: serializer [9219,9229]
===
match
---
fstring_start: f" [12005,12007]
fstring_start: f" [13120,13122]
===
match
---
name: execution_date [5028,5042]
name: execution_date [5028,5042]
===
match
---
trailer [4741,4748]
trailer [4741,4748]
===
match
---
trailer [10193,10200]
trailer [11308,11315]
===
match
---
trailer [7634,7647]
trailer [7634,7647]
===
match
---
atom_expr [2751,2762]
atom_expr [2751,2762]
===
match
---
name: config [6102,6108]
name: config [6102,6108]
===
match
---
atom_expr [4733,4795]
atom_expr [4733,4795]
===
match
---
trailer [2569,2595]
trailer [2569,2595]
===
match
---
name: response [10438,10446]
name: response [11553,11561]
===
match
---
operator: { [12386,12387]
operator: { [13501,13502]
===
match
---
string: '.' [7661,7664]
string: '.' [7661,7664]
===
match
---
param [4649,4653]
param [4649,4653]
===
match
---
simple_stmt [8956,9031]
simple_stmt [10071,10146]
===
match
---
suite [7057,7872]
suite [7057,7872]
===
match
---
name: cls [2536,2539]
name: cls [2536,2539]
===
match
---
atom_expr [5760,5776]
atom_expr [5760,5776]
===
match
---
simple_stmt [1187,1235]
simple_stmt [1187,1235]
===
match
---
name: types [1446,1451]
name: types [1446,1451]
===
match
---
string: 'application/json' [11481,11499]
string: 'application/json' [12596,12614]
===
match
---
atom [8845,8868]
atom [9960,9983]
===
match
---
name: default_time [7635,7647]
name: default_time [7635,7647]
===
match
---
operator: { [10074,10075]
operator: { [11189,11190]
===
match
---
name: dag [4727,4730]
name: dag [4727,4730]
===
match
---
operator: , [2118,2119]
operator: , [2118,2119]
===
match
---
fstring_string: api/v1/dags/ [8197,8209]
fstring_string: api/v1/dags/ [9312,9324]
===
match
---
atom_expr [2765,2787]
atom_expr [2765,2787]
===
match
---
trailer [1889,1965]
trailer [1889,1965]
===
match
---
name: bag_dag [4836,4843]
name: bag_dag [4836,4843]
===
match
---
trailer [7113,7117]
trailer [7113,7117]
===
match
---
operator: = [2916,2917]
operator: = [2916,2917]
===
match
---
simple_stmt [1235,1285]
simple_stmt [1235,1285]
===
match
---
operator: { [9335,9336]
operator: { [10450,10451]
===
match
---
name: self [6245,6249]
name: self [6245,6249]
===
match
---
fstring_string: api/v1/dags/ [10176,10188]
fstring_string: api/v1/dags/ [11291,11303]
===
match
---
trailer [5739,5747]
trailer [5739,5747]
===
match
---
name: expected_filename [6769,6786]
name: expected_filename [6769,6786]
===
match
---
operator: } [9358,9359]
operator: } [10473,10474]
===
match
---
trailer [4261,4484]
trailer [4261,4484]
===
match
---
name: permissions [2313,2324]
name: permissions [2313,2324]
===
match
---
name: airflow [1290,1297]
name: airflow [1290,1297]
===
match
---
name: self [9198,9202]
name: self [10313,10317]
===
match
---
fstring_expr [10188,10201]
fstring_expr [11303,11316]
===
match
---
name: airflow [1240,1247]
name: airflow [1240,1247]
===
match
---
name: session [3061,3068]
name: session [3061,3068]
===
match
---
fstring_expr [5233,5246]
fstring_expr [5233,5246]
===
match
---
expr_stmt [8155,8380]
expr_stmt [9270,9495]
===
match
---
trailer [10772,10779]
trailer [11887,11894]
===
match
---
name: start_date [4750,4760]
name: start_date [4750,4760]
===
match
---
operator: } [9027,9028]
operator: } [10142,10143]
===
match
---
name: self [9270,9274]
name: self [10385,10389]
===
match
---
atom_expr [3121,3132]
atom_expr [3121,3132]
===
match
---
name: URLSafeSerializer [6144,6161]
name: URLSafeSerializer [6144,6161]
===
match
---
name: testing [2004,2011]
name: testing [2004,2011]
===
match
---
name: patch [9714,9719]
name: patch [10829,10834]
===
match
---
name: response [6695,6703]
name: response [6695,6703]
===
match
---
name: DAG_ID [10773,10779]
name: DAG_ID [11888,11894]
===
match
---
trailer [2800,2808]
trailer [2800,2808]
===
match
---
name: token [10671,10676]
name: token [11786,11791]
===
match
---
string: "auth_backend" [1899,1913]
string: "auth_backend" [1899,1913]
===
match
---
comparison [8396,8423]
comparison [9511,9538]
===
match
---
operator: , [2088,2089]
operator: , [2088,2089]
===
match
---
string: "download_logs" [11931,11946]
string: "download_logs" [13046,13061]
===
match
---
operator: = [11821,11822]
operator: = [12936,12937]
===
match
---
operator: { [11930,11931]
operator: { [13045,13046]
===
match
---
fstring_string: / [5232,5233]
fstring_string: / [5232,5233]
===
match
---
testlist_comp [5725,5776]
testlist_comp [5725,5776]
===
match
---
simple_stmt [7103,7139]
simple_stmt [7103,7139]
===
match
---
trailer [9602,9607]
trailer [10717,10722]
===
match
---
operator: , [9840,9841]
operator: , [10955,10956]
===
match
---
dictorsetmaker [7217,7238]
dictorsetmaker [7217,7238]
===
match
---
fstring_string: /dagRuns/TEST_DAG_RUN_ID/ [10201,10226]
fstring_string: /dagRuns/TEST_DAG_RUN_ID/ [11316,11341]
===
match
---
name: get [10736,10739]
name: get [11851,11854]
===
match
---
operator: } [5302,5303]
operator: } [5302,5303]
===
match
---
atom_expr [7109,7138]
atom_expr [7109,7138]
===
match
---
operator: } [11953,11954]
operator: } [13068,13069]
===
match
---
comparison [9454,9497]
comparison [10569,10612]
===
match
---
trailer [2055,2059]
trailer [2055,2059]
===
match
---
name: self [2765,2769]
name: self [2765,2769]
===
match
---
operator: = [6413,6414]
operator: = [6413,6414]
===
match
---
param [11270,11274]
param [12385,12389]
===
match
---
operator: = [3120,3121]
operator: = [3120,3121]
===
match
---
trailer [8018,8022]
trailer [9133,9137]
===
match
---
number: 404 [11651,11654]
number: 404 [12766,12769]
===
match
---
name: tests [1635,1640]
name: tests [1635,1640]
===
match
---
name: cls [2424,2427]
name: cls [2424,2427]
===
match
---
atom_expr [8396,8416]
atom_expr [9511,9531]
===
match
---
operator: , [5000,5001]
operator: , [5000,5001]
===
match
---
testlist_comp [8826,8840]
testlist_comp [9941,9955]
===
match
---
trailer [2324,2340]
trailer [2324,2340]
===
match
---
name: DAG [1025,1028]
name: DAG [1025,1028]
===
match
---
param [8587,8592]
param [9702,9707]
===
match
---
trailer [7975,7990]
trailer [9090,9105]
===
match
---
atom_expr [3419,3435]
atom_expr [3419,3435]
===
match
---
trailer [5764,5776]
trailer [5764,5776]
===
match
---
arglist [5293,5301]
arglist [5293,5301]
===
match
---
suite [5196,5458]
suite [5196,5458]
===
match
---
simple_stmt [6898,6934]
simple_stmt [6898,6934]
===
match
---
dictorsetmaker [8847,8866]
dictorsetmaker [9962,9981]
===
match
---
name: DEFAULT_LOGGING_CONFIG [3558,3580]
name: DEFAULT_LOGGING_CONFIG [3558,3580]
===
match
---
trailer [11307,11311]
trailer [12422,12426]
===
match
---
param [10610,10615]
param [11725,11730]
===
match
---
fstring [7290,7343]
fstring [7290,7343]
===
match
---
trailer [9154,9161]
trailer [10269,10276]
===
match
---
trailer [5062,5075]
trailer [5062,5075]
===
match
---
operator: @ [10559,10560]
operator: @ [11674,11675]
===
match
---
import_as_names [1214,1234]
import_as_names [1214,1234]
===
match
---
atom_expr [7589,7601]
atom_expr [7589,7601]
===
match
---
trailer [8114,8120]
trailer [9229,9235]
===
match
---
name: delete_user [1572,1583]
name: delete_user [1572,1583]
===
match
---
operator: = [2713,2714]
operator: = [2713,2714]
===
match
---
atom [12386,12409]
atom [13501,13524]
===
match
---
name: URLSafeSerializer [12330,12347]
name: URLSafeSerializer [13445,13462]
===
match
---
fstring_start: f" [12526,12528]
fstring_start: f" [13641,13643]
===
match
---
argument [12137,12175]
argument [13252,13290]
===
insert-node
---
name: TestGetLog [1684,1694]
to
classdef [1678,12749]
at 0
===
insert-tree
---
decorated [7877,8987]
    decorator [7877,7894]
        operator: @ [7877,7878]
        name: provide_session [7878,7893]
    funcdef [7898,8987]
        name: test_get_logs_of_removed_task [7902,7931]
        parameters [7931,7946]
            param [7932,7937]
                name: self [7932,7936]
                operator: , [7936,7937]
            param [7938,7945]
                name: session [7938,7945]
        suite [7947,8987]
            simple_stmt [7956,7985]
                atom_expr [7956,7984]
                    name: self [7956,7960]
                    trailer [7960,7975]
                        name: _create_dagrun [7961,7975]
                    trailer [7975,7984]
                        name: session [7976,7983]
            simple_stmt [8031,8086]
                expr_stmt [8031,8056]
                    name: dagbag [8031,8037]
                    operator: = [8038,8039]
                    atom_expr [8040,8056]
                        name: self [8040,8044]
                        trailer [8044,8048]
                            name: app [8045,8048]
                        trailer [8048,8056]
                            name: dag_bag [8049,8056]
            simple_stmt [8094,8163]
                expr_stmt [8094,8162]
                    name: dag [8094,8097]
                    operator: = [8098,8099]
                    atom_expr [8100,8162]
                        name: DAG [8100,8103]
                        trailer [8103,8162]
                            arglist [8104,8161]
                                atom_expr [8104,8115]
                                    name: self [8104,8108]
                                    trailer [8108,8115]
                                        name: DAG_ID [8109,8115]
                                operator: , [8115,8116]
                                argument [8117,8161]
                                    name: start_date [8117,8127]
                                    operator: = [8127,8128]
                                    atom_expr [8128,8161]
                                        name: timezone [8128,8136]
                                        trailer [8136,8142]
                                            name: parse [8137,8142]
                                        trailer [8142,8161]
                                            atom_expr [8143,8160]
                                                name: self [8143,8147]
                                                trailer [8147,8160]
                                                    name: default_time [8148,8160]
            simple_stmt [8171,8209]
                atom_expr [8171,8208]
                    name: dagbag [8171,8177]
                    trailer [8177,8185]
                        name: bag_dag [8178,8185]
                    trailer [8185,8208]
                        arglist [8186,8207]
                            argument [8186,8193]
                                name: dag [8186,8189]
                                operator: = [8189,8190]
                                name: dag [8190,8193]
                            operator: , [8193,8194]
                            argument [8195,8207]
                                name: root_dag [8195,8203]
                                operator: = [8203,8204]
                                name: dag [8204,8207]
            simple_stmt [8218,8254]
                expr_stmt [8218,8253]
                    name: key [8218,8221]
                    operator: = [8222,8223]
                    atom_expr [8224,8253]
                        name: self [8224,8228]
                        trailer [8228,8232]
                            name: app [8229,8232]
                        trailer [8232,8239]
                            name: config [8233,8239]
                        trailer [8239,8253]
                            string: "SECRET_KEY" [8240,8252]
            simple_stmt [8262,8298]
                expr_stmt [8262,8297]
                    name: serializer [8262,8272]
                    operator: = [8273,8274]
                    atom_expr [8275,8297]
                        name: URLSafeSerializer [8275,8292]
                        trailer [8292,8297]
                            name: key [8293,8296]
            simple_stmt [8306,8356]
                expr_stmt [8306,8355]
                    name: token [8306,8311]
                    operator: = [8312,8313]
                    atom_expr [8314,8355]
                        name: serializer [8314,8324]
                        trailer [8324,8330]
                            name: dumps [8325,8330]
                        trailer [8330,8355]
                            atom [8331,8354]
                                operator: { [8331,8332]
                                dictorsetmaker [8332,8353]
                                    string: "download_logs" [8332,8347]
                                operator: } [8353,8354]
            simple_stmt [8365,8636]
                expr_stmt [8365,8635]
                    name: response [8365,8373]
                    operator: = [8374,8375]
                    atom_expr [8376,8635]
                        name: self [8376,8380]
                        trailer [8380,8387]
                            name: client [8381,8387]
                        trailer [8387,8391]
                            name: get [8388,8391]
                        trailer [8391,8635]
                            arglist [8405,8625]
                                strings [8405,8523]
                                    fstring [8405,8458]
                                        fstring_start: f" [8405,8407]
                                        fstring_string: api/v1/dags/ [8407,8419]
                                        fstring_expr [8419,8432]
                                            operator: { [8419,8420]
                                            atom_expr [8420,8431]
                                                name: self [8420,8424]
                                                trailer [8424,8431]
                                                    name: DAG_ID [8425,8431]
                                            operator: } [8431,8432]
                                        fstring_string: /dagRuns/TEST_DAG_RUN_ID/ [8432,8457]
                                        fstring_end: " [8457,8458]
                                    fstring [8471,8523]
                                        fstring_start: f" [8471,8473]
                                        fstring_string: taskInstances/ [8473,8487]
                                        fstring_expr [8487,8501]
                                            operator: { [8487,8488]
                                            atom_expr [8488,8500]
                                                name: self [8488,8492]
                                                trailer [8492,8500]
                                                    name: TASK_ID [8493,8500]
                                            operator: } [8500,8501]
                                        fstring_string: /logs/1?token= [8501,8515]
                                        fstring_expr [8515,8522]
                                            operator: { [8515,8516]
                                            name: token [8516,8521]
                                            operator: } [8521,8522]
                                        fstring_end: " [8522,8523]
                                operator: , [8523,8524]
                                argument [8537,8569]
                                    name: headers [8537,8544]
                                    operator: = [8544,8545]
                                    atom [8545,8569]
                                        operator: { [8545,8546]
                                        dictorsetmaker [8546,8568]
                                            string: 'Accept' [8546,8554]
                                            string: 'text/plain' [8556,8568]
                                        operator: } [8568,8569]
                                operator: , [8569,8570]
                                argument [8583,8624]
                                    name: environ_overrides [8583,8600]
                                    operator: = [8600,8601]
                                    atom [8601,8624]
                                        operator: { [8601,8602]
                                        dictorsetmaker [8602,8623]
                                            string: 'REMOTE_USER' [8602,8615]
                                            string: "test" [8617,8623]
                                        operator: } [8623,8624]
                                operator: , [8624,8625]
            simple_stmt [8644,8791]
                expr_stmt [8644,8790]
                    name: expected_filename [8644,8661]
                    operator: = [8662,8663]
                    atom_expr [8664,8790]
                        string: "{}/{}/{}/{}/1.log" [8664,8683]
                        trailer [8683,8690]
                            name: format [8684,8690]
                        trailer [8690,8790]
                            arglist [8704,8780]
                                atom_expr [8704,8716]
                                    name: self [8704,8708]
                                    trailer [8708,8716]
                                        name: log_dir [8709,8716]
                                operator: , [8716,8717]
                                atom_expr [8718,8729]
                                    name: self [8718,8722]
                                    trailer [8722,8729]
                                        name: DAG_ID [8723,8729]
                                operator: , [8729,8730]
                                atom_expr [8731,8743]
                                    name: self [8731,8735]
                                    trailer [8735,8743]
                                        name: TASK_ID [8736,8743]
                                operator: , [8743,8744]
                                atom_expr [8745,8780]
                                    name: self [8745,8749]
                                    trailer [8749,8762]
                                        name: default_time [8750,8762]
                                    trailer [8762,8770]
                                        name: replace [8763,8770]
                                    trailer [8770,8780]
                                        arglist [8771,8779]
                                            string: ':' [8771,8774]
                                            operator: , [8774,8775]
                                            string: '.' [8776,8779]
            simple_stmt [8799,8834]
                assert_stmt [8799,8833]
                    comparison [8806,8833]
                        number: 200 [8806,8809]
                        operator: == [8810,8812]
                        atom_expr [8813,8833]
                            name: response [8813,8821]
                            trailer [8821,8833]
                                name: status_code [8822,8833]
            simple_stmt [8842,8987]
                assert_stmt [8842,8986]
                    atom [8849,8986]
                        comparison [8863,8976]
                            atom_expr [8863,8892]
                                name: response [8863,8871]
                                trailer [8871,8876]
                                    name: data [8872,8876]
                                trailer [8876,8883]
                                    name: decode [8877,8883]
                                trailer [8883,8892]
                                    string: 'utf-8' [8884,8891]
                            operator: == [8905,8907]
                            fstring [8908,8976]
                                fstring_start: f" [8908,8910]
                                fstring_string: \n*** Reading local file:  [8910,8936]
                                fstring_expr [8936,8955]
                                    operator: { [8936,8937]
                                    name: expected_filename [8937,8954]
                                    operator: } [8954,8955]
                                fstring_string: \nLog for testing.\n [8955,8975]
                                fstring_end: " [8975,8976]
to
suite [1714,12749]
at 13
===
delete-node
---
name: TestGetLog [1684,1694]
===
