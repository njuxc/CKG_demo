===
match
---
operator: = [2761,2762]
operator: = [2805,2806]
===
match
---
name: dag_id [2422,2428]
name: dag_id [2466,2472]
===
match
---
expr_stmt [2224,2257]
expr_stmt [2268,2301]
===
match
---
string: """Get logs for specific task instance""" [1676,1717]
string: """Get logs for specific task instance""" [1720,1761]
===
match
---
testlist_comp [1347,1400]
testlist_comp [1391,1444]
===
match
---
name: ACTION_CAN_READ [1493,1508]
name: ACTION_CAN_READ [1537,1552]
===
match
---
string: "Content-Type" [3512,3526]
string: "Content-Type" [3619,3633]
===
match
---
trailer [2057,2074]
trailer [2101,2118]
===
match
---
dotted_name [1162,1178]
dotted_name [1206,1222]
===
match
---
operator: , [1374,1375]
operator: , [1418,1419]
===
match
---
trailer [1739,1746]
trailer [1783,1790]
===
match
---
name: content [3362,3369]
name: content [3469,3476]
===
match
---
name: dag_id [2432,2438]
name: dag_id [2476,2482]
===
match
---
name: detail [2704,2710]
name: detail [2748,2754]
===
match
---
atom_expr [1728,1760]
atom_expr [1772,1804]
===
match
---
string: 'download_logs' [2194,2209]
string: 'download_logs' [2238,2253]
===
match
---
expr_stmt [1787,1800]
expr_stmt [1831,1844]
===
match
---
trailer [2821,2826]
trailer [2882,2887]
===
match
---
name: models [1136,1142]
name: models [1180,1186]
===
match
---
simple_stmt [1253,1303]
simple_stmt [1297,1347]
===
match
---
atom [1480,1545]
atom [1524,1589]
===
match
---
atom_expr [3318,3375]
atom_expr [3425,3482]
===
match
---
name: metadata [2015,2023]
name: metadata [2059,2067]
===
match
---
trailer [3135,3166]
trailer [3242,3273]
===
match
---
name: dag [2757,2760]
name: dag [2801,2804]
===
match
---
comp_op [3209,3215]
comp_op [3316,3322]
===
match
---
name: return_type [3528,3539]
name: return_type [3635,3646]
===
match
---
name: utils [1211,1216]
name: utils [1255,1260]
===
match
---
operator: , [1109,1110]
operator: , [1109,1110]
===
match
---
name: security [1306,1314]
name: security [1350,1358]
===
match
---
string: "Task instance did not exist in the DB" [2711,2750]
string: "Task instance did not exist in the DB" [2755,2794]
===
match
---
import_from [877,928]
import_from [877,928]
===
match
---
simple_stmt [1787,1801]
simple_stmt [1831,1845]
===
match
---
operator: } [1799,1800]
operator: } [1843,1844]
===
match
---
name: api_connexion [1052,1065]
name: api_connexion [1052,1065]
===
match
---
name: get_dag [2783,2790]
name: get_dag [2827,2834]
===
match
---
atom_expr [2829,2853]
atom_expr [2890,2914]
===
match
---
name: logs [3175,3179]
name: logs [3282,3286]
===
match
---
trailer [2703,2751]
trailer [2747,2795]
===
match
---
name: airflow [1258,1265]
name: airflow [1302,1309]
===
match
---
simple_stmt [3406,3476]
simple_stmt [3513,3583]
===
match
---
atom [3511,3540]
atom [3618,3647]
===
match
---
name: query [2394,2399]
name: query [2438,2443]
===
match
---
simple_stmt [1039,1123]
simple_stmt [1039,1123]
===
match
---
simple_stmt [3175,3231]
simple_stmt [3282,3338]
===
match
---
trailer [1387,1400]
trailer [1431,1444]
===
match
---
simple_stmt [2532,2568]
simple_stmt [2576,2612]
===
match
---
atom_expr [2842,2852]
atom_expr [2903,2913]
===
match
---
not_test [2511,2522]
not_test [2555,2566]
===
match
---
decorator [1555,1572]
decorator [1599,1616]
===
match
---
simple_stmt [973,1039]
simple_stmt [973,1039]
===
match
---
trailer [1940,2006]
trailer [1984,2050]
===
match
---
number: 0 [3187,3188]
number: 0 [3294,3295]
===
match
---
name: dag_bag [2775,2782]
name: dag_bag [2819,2826]
===
match
---
import_from [1198,1252]
import_from [1242,1296]
===
match
---
name: DagRun [2400,2406]
name: DagRun [2444,2450]
===
match
---
name: exc [853,856]
name: exc [853,856]
===
match
---
trailer [1423,1439]
trailer [1467,1483]
===
match
---
name: task_log_reader [3104,3119]
name: task_log_reader [3211,3226]
===
match
---
dotted_name [882,903]
dotted_name [882,903]
===
match
---
name: best_match [2898,2908]
name: best_match [3005,3015]
===
match
---
name: ti [2819,2821]
name: ti [2880,2882]
===
match
---
dotted_name [1044,1084]
dotted_name [1044,1084]
===
match
---
expr_stmt [2573,2621]
expr_stmt [2617,2665]
===
match
---
operator: = [2871,2872]
operator: = [2978,2979]
===
match
---
trailer [2774,2782]
trailer [2818,2826]
===
match
---
arglist [3136,3165]
arglist [3243,3272]
===
match
---
simple_stmt [2687,2752]
simple_stmt [2731,2796]
===
match
---
string: 'download_logs' [2058,2073]
string: 'download_logs' [2102,2117]
===
match
---
operator: = [2576,2577]
operator: = [2620,2621]
===
match
---
name: logs [3497,3501]
name: logs [3604,3608]
===
match
---
if_stmt [2626,2752]
if_stmt [2670,2796]
===
match
---
trailer [2546,2567]
trailer [2590,2611]
===
match
---
decorated [1305,3542]
decorated [1349,3649]
===
match
---
name: query [2378,2383]
name: query [2422,2427]
===
match
---
trailer [2421,2428]
trailer [2465,2472]
===
match
---
trailer [3186,3189]
trailer [3293,3296]
===
match
---
name: LogResponseObject [3318,3335]
name: LogResponseObject [3425,3442]
===
match
---
name: first [2496,2501]
name: first [2540,2545]
===
match
---
name: key [1865,1868]
name: key [1909,1912]
===
match
---
simple_stmt [1722,1761]
simple_stmt [1766,1805]
===
match
---
simple_stmt [1198,1253]
simple_stmt [1242,1297]
===
match
---
simple_stmt [2224,2258]
simple_stmt [2268,2302]
===
match
---
atom_expr [1481,1508]
atom_expr [1525,1552]
===
match
---
name: logs [3406,3410]
name: logs [3513,3517]
===
match
---
name: query [2454,2459]
name: query [2498,2503]
===
match
---
name: flask [791,796]
name: flask [791,796]
===
match
---
name: Response [3488,3496]
name: Response [3595,3603]
===
match
---
raise_stmt [2308,2372]
raise_stmt [2352,2416]
===
match
---
name: current_app [2763,2774]
name: current_app [2807,2818]
===
match
---
name: dag_run_id [1601,1611]
name: dag_run_id [1645,1655]
===
match
---
import_from [1123,1156]
import_from [1167,1200]
===
match
---
operator: , [3155,3156]
operator: , [3262,3263]
===
match
---
trailer [2142,2159]
trailer [2186,2203]
===
match
---
name: return_type [3010,3021]
name: return_type [3117,3128]
===
match
---
name: permissions [1376,1387]
name: permissions [1420,1431]
===
match
---
testlist_comp [1412,1469]
testlist_comp [1456,1513]
===
match
---
name: permissions [1347,1358]
name: permissions [1391,1402]
===
match
---
operator: @ [1555,1556]
operator: @ [1599,1600]
===
match
---
string: 'end_of_log' [2658,2670]
string: 'end_of_log' [2702,2714]
===
match
---
simple_stmt [2819,2854]
simple_stmt [2880,2915]
===
match
---
import_from [786,834]
import_from [786,834]
===
match
---
name: token [1659,1664]
name: token [1703,1708]
===
match
---
name: accept_mimetypes [2881,2897]
name: accept_mimetypes [2988,3004]
===
match
---
name: metadata [2649,2657]
name: metadata [2693,2701]
===
match
---
atom [1336,1552]
atom [1380,1596]
===
match
---
operator: = [2240,2241]
operator: = [2284,2285]
===
match
---
atom_expr [2819,2826]
atom_expr [2880,2887]
===
match
---
name: task_try_number [1622,1637]
name: task_try_number [1666,1681]
===
match
---
operator: , [3447,3448]
operator: , [3554,3555]
===
match
---
name: api_connexion [986,999]
name: api_connexion [986,999]
===
match
---
name: airflow [935,942]
name: airflow [935,942]
===
match
---
simple_stmt [1836,1883]
simple_stmt [1880,1927]
===
match
---
not_test [1768,1777]
not_test [1812,1821]
===
match
---
name: read_log_stream [3429,3444]
name: read_log_stream [3536,3551]
===
match
---
trailer [2193,2210]
trailer [2237,2254]
===
match
---
string: "Bad Signature. Please use only the tokens provided by the API." [1941,2005]
string: "Bad Signature. Please use only the tokens provided by the API." [1985,2049]
===
match
---
operator: == [2429,2431]
operator: == [2473,2475]
===
match
---
operator: , [1401,1402]
operator: , [1445,1446]
===
match
---
trailer [2027,2044]
trailer [2071,2088]
===
match
---
operator: , [3091,3092]
operator: , [3198,3199]
===
match
---
name: read_log_chunks [3120,3135]
name: read_log_chunks [3227,3242]
===
match
---
operator: { [1798,1799]
operator: { [1842,1843]
===
match
---
raise_stmt [2532,2567]
raise_stmt [2576,2611]
===
match
---
trailer [2255,2257]
trailer [2299,2301]
===
match
---
if_stmt [3007,3377]
if_stmt [3114,3484]
===
match
---
name: logs_schema [3301,3312]
name: logs_schema [3408,3419]
===
match
---
atom_expr [2242,2257]
atom_expr [2286,2301]
===
match
---
atom_expr [2693,2751]
atom_expr [2737,2795]
===
match
---
operator: { [3511,3512]
operator: { [3618,3619]
===
match
---
simple_stmt [2757,2799]
simple_stmt [2801,2843]
===
match
---
name: permissions [1186,1197]
name: permissions [1230,1241]
===
match
---
expr_stmt [2649,2678]
expr_stmt [2693,2722]
===
match
---
name: itsdangerous [882,894]
name: itsdangerous [882,894]
===
match
---
trailer [2407,2414]
trailer [2451,2458]
===
match
---
name: filter [2408,2414]
name: filter [2452,2458]
===
match
---
trailer [3312,3317]
trailer [3419,3424]
===
match
---
param [1659,1669]
param [1703,1713]
===
match
---
dotted_name [978,1010]
dotted_name [978,1010]
===
match
---
dotted_name [1258,1279]
dotted_name [1302,1323]
===
match
---
operator: = [2827,2828]
operator: = [2888,2889]
===
match
---
name: metadata [3157,3165]
name: metadata [3264,3272]
===
match
---
operator: = [1845,1846]
operator: = [1889,1890]
===
match
---
name: airflow [1044,1051]
name: airflow [1044,1051]
===
match
---
operator: , [1620,1621]
operator: , [1664,1665]
===
match
---
name: BadSignature [1898,1910]
name: BadSignature [1942,1954]
===
match
---
name: get_log [1576,1583]
name: get_log [1620,1627]
===
match
---
suite [1671,3542]
suite [1715,3649]
===
match
---
atom_expr [1510,1544]
atom_expr [1554,1588]
===
match
---
name: exceptions [1000,1010]
name: exceptions [1000,1010]
===
match
---
operator: , [3360,3361]
operator: , [3467,3468]
===
match
---
atom_expr [2763,2798]
atom_expr [2807,2842]
===
match
---
param [1639,1658]
param [1683,1702]
===
match
---
atom_expr [2873,2944]
atom_expr [2980,3051]
===
match
---
name: full_content [1639,1651]
name: full_content [1683,1695]
===
match
---
atom_expr [1847,1882]
atom_expr [1891,1926]
===
match
---
operator: } [3539,3540]
operator: } [3646,3647]
===
match
---
operator: , [1439,1440]
operator: , [1483,1484]
===
match
---
import_from [1253,1302]
import_from [1297,1346]
===
match
---
operator: == [2481,2483]
operator: == [2525,2527]
===
match
---
name: URLSafeSerializer [3247,3264]
name: URLSafeSerializer [3354,3371]
===
match
---
comparison [2467,2494]
comparison [2511,2538]
===
match
---
name: dag_run [2578,2585]
name: dag_run [2622,2629]
===
match
---
name: security [1170,1178]
name: security [1214,1222]
===
match
---
name: return_type [2859,2870]
name: return_type [2966,2977]
===
match
---
return_stmt [3481,3541]
return_stmt [3588,3648]
===
match
---
atom_expr [1376,1400]
atom_expr [1420,1444]
===
match
---
trailer [2459,2466]
trailer [2503,2510]
===
match
---
name: Response [804,812]
name: Response [804,812]
===
match
---
simple_stmt [3294,3377]
simple_stmt [3401,3484]
===
match
---
operator: = [3180,3181]
operator: = [3287,3288]
===
match
---
suite [2176,2219]
suite [2220,2263]
===
match
---
trailer [1875,1882]
trailer [1919,1926]
===
match
---
except_clause [1891,1910]
except_clause [1935,1954]
===
match
---
import_as_names [804,834]
import_as_names [804,834]
===
match
---
trailer [1452,1469]
trailer [1496,1513]
===
match
---
and_test [2015,2074]
and_test [2059,2118]
===
match
---
atom_expr [2454,2503]
atom_expr [2498,2547]
===
match
---
simple_stmt [2444,2504]
simple_stmt [2488,2548]
===
match
---
operator: = [1726,1727]
operator: = [1770,1771]
===
match
---
comparison [3047,3066]
comparison [3154,3173]
===
match
---
name: provide_session [1556,1571]
name: provide_session [1600,1615]
===
match
---
operator: , [1657,1658]
operator: , [1701,1702]
===
match
---
operator: , [3501,3502]
operator: , [3608,3609]
===
match
---
dotted_name [935,956]
dotted_name [935,956]
===
match
---
name: security [964,972]
name: security [964,972]
===
match
---
simple_stmt [1123,1157]
simple_stmt [1167,1201]
===
match
---
dictorsetmaker [3512,3539]
dictorsetmaker [3619,3646]
===
match
---
operator: = [3369,3370]
operator: = [3476,3477]
===
match
---
name: provide_session [1287,1302]
name: provide_session [1331,1346]
===
match
---
name: metadata [3466,3474]
name: metadata [3573,3581]
===
match
---
name: session [2386,2393]
name: session [2430,2437]
===
match
---
simple_stmt [877,929]
simple_stmt [877,929]
===
match
---
name: get [2024,2027]
name: get [2068,2071]
===
match
---
trailer [1521,1544]
trailer [1565,1588]
===
match
---
suite [1778,1801]
suite [1822,1845]
===
match
---
trailer [2414,2439]
trailer [2458,2483]
===
match
---
name: request [827,834]
name: request [827,834]
===
match
---
name: NotFound [1030,1038]
name: NotFound [1030,1038]
===
match
---
name: logs [3226,3230]
name: logs [3333,3337]
===
match
---
decorators [1305,1572]
decorators [1349,1616]
===
match
---
name: dag_id [2791,2797]
name: dag_id [2835,2841]
===
match
---
name: key [1722,1725]
name: key [1766,1769]
===
match
---
name: task_id [1613,1620]
name: task_id [1657,1664]
===
match
---
raise_stmt [1924,2006]
raise_stmt [1968,2050]
===
match
---
atom_expr [3182,3189]
atom_expr [3289,3296]
===
match
---
comparison [2415,2438]
comparison [2459,2482]
===
match
---
name: current_app [814,825]
name: current_app [814,825]
===
match
---
operator: , [825,826]
operator: , [825,826]
===
match
---
operator: = [1651,1652]
operator: = [1695,1696]
===
match
---
name: BadRequest [1018,1028]
name: BadRequest [1018,1028]
===
match
---
expr_stmt [3239,3285]
expr_stmt [3346,3392]
===
match
---
name: DagRun [2415,2421]
name: DagRun [2459,2465]
===
match
---
string: "SECRET_KEY" [1747,1759]
string: "SECRET_KEY" [1791,1803]
===
match
---
param [1593,1600]
param [1637,1644]
===
match
---
atom_expr [2314,2372]
atom_expr [2358,2416]
===
match
---
expr_stmt [3406,3475]
expr_stmt [3513,3582]
===
match
---
import_as_names [1018,1038]
import_as_names [1018,1038]
===
match
---
comparison [3010,3043]
comparison [3117,3150]
===
match
---
simple_stmt [786,835]
simple_stmt [786,835]
===
match
---
name: airflow [1162,1169]
name: airflow [1206,1213]
===
match
---
param [1613,1621]
param [1657,1665]
===
match
---
operator: @ [1305,1306]
operator: @ [1349,1350]
===
match
---
name: BadRequest [2314,2324]
name: BadRequest [2358,2368]
===
match
---
trailer [2790,2798]
trailer [2834,2842]
===
match
---
not_test [2265,2298]
not_test [2309,2342]
===
match
---
operator: , [1470,1471]
operator: , [1514,1515]
===
match
---
string: 'application/json' [3025,3043]
string: 'application/json' [3132,3150]
===
match
---
name: session [1584,1591]
name: session [1628,1635]
===
match
---
operator: , [1599,1600]
operator: , [1643,1644]
===
match
---
name: api_connexion [943,956]
name: api_connexion [943,956]
===
match
---
expr_stmt [3087,3166]
expr_stmt [3194,3273]
===
match
---
suite [2125,2167]
suite [2169,2211]
===
match
---
operator: , [1637,1638]
operator: , [1681,1682]
===
match
---
simple_stmt [2649,2679]
simple_stmt [2693,2723]
===
match
---
simple_stmt [930,973]
simple_stmt [930,973]
===
match
---
name: ti [2629,2631]
name: ti [2673,2675]
===
match
---
trailer [1864,1869]
trailer [1908,1913]
===
match
---
name: continuation_token [3336,3354]
name: continuation_token [3443,3461]
===
match
---
trailer [2501,2503]
trailer [2545,2547]
===
match
---
trailer [2657,2671]
trailer [2701,2715]
===
match
---
name: task_id [2845,2852]
name: task_id [2906,2913]
===
match
---
trailer [3317,3376]
trailer [3424,3483]
===
match
---
name: airflow [978,985]
name: airflow [978,985]
===
match
---
name: metadata [3276,3284]
name: metadata [3383,3391]
===
match
---
if_stmt [2803,2854]
if_stmt [2847,2961]
===
match
---
parameters [1583,1670]
parameters [1627,1714]
===
match
---
atom_expr [2015,2044]
atom_expr [2059,2088]
===
match
---
name: full_content [2084,2096]
name: full_content [2128,2140]
===
match
---
param [1601,1612]
param [1645,1656]
===
match
---
name: permissions [1481,1492]
name: permissions [1525,1536]
===
match
---
operator: , [3464,3465]
operator: , [3571,3572]
===
match
---
suite [2640,2752]
suite [2684,2796]
===
match
---
expr_stmt [2819,2853]
expr_stmt [2880,2914]
===
match
---
name: RESOURCE_DAG [1388,1400]
name: RESOURCE_DAG [1432,1444]
===
match
---
trailer [2585,2603]
trailer [2629,2647]
===
match
---
name: itsdangerous [840,852]
name: itsdangerous [840,852]
===
match
---
atom_expr [3413,3475]
atom_expr [3520,3582]
===
match
---
argument [3503,3540]
argument [3610,3647]
===
match
---
name: task_log_reader [2224,2239]
name: task_log_reader [2268,2283]
===
match
---
simple_stmt [3481,3542]
simple_stmt [3588,3649]
===
match
---
arglist [3497,3540]
arglist [3604,3647]
===
match
---
name: metadata [1836,1844]
name: metadata [1880,1888]
===
match
---
name: get_task_instance [2586,2603]
name: get_task_instance [2630,2647]
===
match
---
operator: , [2922,2923]
operator: , [3029,3030]
===
match
---
name: LogResponseObject [1092,1109]
name: LogResponseObject [1092,1109]
===
match
---
trailer [3119,3135]
trailer [3226,3242]
===
match
---
name: task_id [2604,2611]
name: task_id [2648,2655]
===
match
---
name: metadata [3093,3101]
name: metadata [3200,3208]
===
match
---
simple_stmt [3239,3286]
simple_stmt [3346,3393]
===
match
---
if_stmt [1765,2007]
if_stmt [1809,2051]
===
match
---
operator: = [3102,3103]
operator: = [3209,3210]
===
match
---
or_test [3010,3066]
or_test [3117,3173]
===
match
---
import_from [1157,1197]
import_from [1201,1241]
===
match
---
trailer [3269,3275]
trailer [3376,3382]
===
match
---
dotted_name [1203,1231]
dotted_name [1247,1275]
===
match
---
name: BadRequest [1930,1940]
name: BadRequest [1974,1984]
===
match
---
atom_expr [2049,2074]
atom_expr [2093,2118]
===
match
---
trailer [2023,2027]
trailer [2067,2071]
===
match
---
string: "Task log handler does not support read logs." [2325,2371]
string: "Task log handler does not support read logs." [2369,2415]
===
match
---
atom_expr [3104,3166]
atom_expr [3211,3273]
===
match
---
simple_stmt [2573,2622]
simple_stmt [2617,2666]
===
match
---
operator: = [3510,3511]
operator: = [3617,3618]
===
match
---
name: metadata [2185,2193]
name: metadata [2229,2237]
===
match
---
name: ti [2573,2575]
name: ti [2617,2619]
===
match
---
name: return_type [3047,3058]
name: return_type [3154,3165]
===
match
---
operator: = [2672,2673]
operator: = [2716,2717]
===
match
---
import_from [973,1038]
import_from [973,1038]
===
match
---
operator: = [2097,2098]
operator: = [2141,2142]
===
match
---
trailer [1746,1760]
trailer [1790,1804]
===
match
---
simple_stmt [2308,2373]
simple_stmt [2352,2417]
===
match
---
name: token [1772,1777]
name: token [1816,1821]
===
match
---
trailer [2466,2495]
trailer [2510,2539]
===
match
---
name: task [2822,2826]
name: task [2883,2887]
===
match
---
if_stmt [2508,2568]
if_stmt [2552,2612]
===
match
---
name: dag [2806,2809]
name: dag [2850,2853]
===
match
---
trailer [3496,3541]
trailer [3603,3648]
===
match
---
name: ti [3445,3447]
name: ti [3552,3554]
===
match
---
trailer [2603,2621]
trailer [2647,2665]
===
match
---
suite [2075,2104]
suite [2119,2148]
===
match
---
name: metadata [2134,2142]
name: metadata [2178,2186]
===
match
---
name: airflow [1128,1135]
name: airflow [1172,1179]
===
match
---
atom_expr [2415,2428]
atom_expr [2459,2472]
===
match
---
param [1584,1592]
param [1628,1636]
===
match
---
suite [1810,2007]
suite [1854,2051]
===
match
---
name: supports_read [2285,2298]
name: supports_read [2329,2342]
===
match
---
suite [3078,3377]
suite [3185,3484]
===
match
---
atom_expr [3301,3376]
atom_expr [3408,3483]
===
match
---
operator: , [1028,1029]
operator: , [1028,1029]
===
match
---
atom [1411,1470]
atom [1455,1514]
===
match
---
operator: = [3411,3412]
operator: = [3518,3519]
===
match
---
name: BadSignature [864,876]
name: BadSignature [864,876]
===
match
---
string: 'download_logs' [2028,2043]
string: 'download_logs' [2072,2087]
===
match
---
name: TaskLogReader [1239,1252]
name: TaskLogReader [1283,1296]
===
match
---
argument [3362,3374]
argument [3469,3481]
===
match
---
name: request [2873,2880]
name: request [2980,2987]
===
match
---
string: 'text/plain' [2910,2922]
string: 'text/plain' [3017,3029]
===
match
---
simple_stmt [2134,2167]
simple_stmt [2178,2211]
===
match
---
name: logs_schema [1111,1122]
name: logs_schema [1111,1122]
===
match
---
suite [1911,2007]
suite [1955,2051]
===
match
---
name: TaskLogReader [2242,2255]
name: TaskLogReader [2286,2299]
===
match
---
atom_expr [1441,1469]
atom_expr [1485,1513]
===
match
---
string: 'download_logs' [2143,2158]
string: 'download_logs' [2187,2202]
===
match
---
name: airflow [1203,1210]
name: airflow [1247,1254]
===
match
---
operator: = [1664,1665]
operator: = [1708,1709]
===
match
---
import_from [1039,1122]
import_from [1039,1122]
===
match
---
name: dag_id [1593,1599]
name: dag_id [1637,1643]
===
match
---
name: RESOURCE_DAG_RUN [1453,1469]
name: RESOURCE_DAG_RUN [1497,1513]
===
match
---
atom_expr [1412,1439]
atom_expr [1456,1483]
===
match
---
name: loads [1870,1875]
name: loads [1914,1919]
===
match
---
trailer [2832,2841]
trailer [2893,2902]
===
match
---
argument [2704,2750]
argument [2748,2794]
===
match
---
name: run_id [2474,2480]
name: run_id [2518,2524]
===
match
---
trailer [2844,2852]
trailer [2905,2913]
===
match
---
arglist [3445,3474]
arglist [3552,3581]
===
match
---
operator: , [812,813]
operator: , [812,813]
===
match
---
trailer [2908,2944]
trailer [3015,3051]
===
match
---
operator: , [1508,1509]
operator: , [1552,1553]
===
match
---
name: task_log_reader [2269,2284]
name: task_log_reader [2313,2328]
===
match
---
trailer [3275,3285]
trailer [3382,3392]
===
match
---
atom_expr [2134,2159]
atom_expr [2178,2203]
===
match
---
trailer [2897,2908]
trailer [3004,3015]
===
match
---
operator: = [2710,2711]
operator: = [2754,2755]
===
match
---
operator: = [1796,1797]
operator: = [1840,1841]
===
match
---
simple_stmt [1157,1198]
simple_stmt [1201,1242]
===
match
---
name: dag_run_id [2484,2494]
name: dag_run_id [2528,2538]
===
match
---
trailer [2393,2399]
trailer [2437,2443]
===
match
---
atom_expr [1347,1374]
atom_expr [1391,1418]
===
match
---
arglist [3336,3374]
arglist [3443,3481]
===
match
---
trailer [2399,2407]
trailer [2443,2451]
===
match
---
name: session [2613,2620]
name: session [2657,2664]
===
match
---
name: utils [1266,1271]
name: utils [1310,1315]
===
match
---
if_stmt [2012,2104]
if_stmt [2056,2148]
===
match
---
name: ACTION_CAN_READ [1359,1374]
name: ACTION_CAN_READ [1403,1418]
===
match
---
name: dumps [3270,3275]
name: dumps [3377,3382]
===
match
---
operator: , [1545,1546]
operator: , [1589,1590]
===
match
---
raise_stmt [2687,2751]
raise_stmt [2731,2795]
===
match
---
name: permissions [1510,1521]
name: permissions [1554,1565]
===
match
---
atom [1798,1800]
atom [1842,1844]
===
match
---
name: RESOURCE_TASK_INSTANCE [1522,1544]
name: RESOURCE_TASK_INSTANCE [1566,1588]
===
match
---
suite [2299,2373]
suite [2343,2417]
===
match
---
name: url_safe [895,903]
name: url_safe [895,903]
===
match
---
testlist_comp [1481,1544]
testlist_comp [1525,1588]
===
match
---
trailer [3335,3375]
trailer [3442,3482]
===
match
---
dotted_name [1306,1330]
dotted_name [1350,1374]
===
match
---
operator: = [3245,3246]
operator: = [3352,3353]
===
match
---
atom_expr [1930,2006]
atom_expr [1974,2050]
===
match
---
testlist_comp [1346,1546]
testlist_comp [1390,1590]
===
match
---
simple_stmt [835,877]
simple_stmt [835,877]
===
match
---
trailer [3428,3444]
trailer [3535,3551]
===
match
---
operator: == [3022,3024]
operator: == [3129,3131]
===
match
---
atom [2909,2943]
atom [3016,3050]
===
match
---
simple_stmt [2185,2219]
simple_stmt [2229,2263]
===
match
---
dotted_name [1128,1142]
dotted_name [1172,1186]
===
match
---
atom_expr [2467,2480]
atom_expr [2511,2524]
===
match
---
testlist_star_expr [3087,3101]
testlist_star_expr [3194,3208]
===
match
---
atom_expr [2185,2210]
atom_expr [2229,2254]
===
match
---
string: 'application/json' [2924,2942]
string: 'application/json' [3031,3049]
===
match
---
name: key [3265,3268]
name: key [3372,3375]
===
match
---
operator: , [3138,3139]
operator: , [3245,3246]
===
match
---
name: config [1740,1746]
name: config [1784,1790]
===
match
---
trailer [2324,2372]
trailer [2368,2416]
===
match
---
name: dag [2829,2832]
name: dag [2890,2893]
===
match
---
trailer [2841,2853]
trailer [2902,2914]
===
match
---
name: task_try_number [3140,3155]
name: task_try_number [3247,3262]
===
match
---
trailer [1869,1875]
trailer [1913,1919]
===
match
---
name: token [3355,3360]
name: token [3462,3467]
===
match
---
expr_stmt [1836,1882]
expr_stmt [1880,1926]
===
match
---
atom_expr [2578,2621]
atom_expr [2622,2665]
===
match
---
name: ti [3136,3138]
name: ti [3243,3245]
===
match
---
name: requires_access [1315,1330]
name: requires_access [1359,1374]
===
match
---
funcdef [1572,3542]
funcdef [1616,3649]
===
match
---
suite [2523,2568]
suite [2567,2612]
===
match
---
simple_stmt [3087,3167]
simple_stmt [3194,3274]
===
match
---
name: dag_run [2444,2451]
name: dag_run [2488,2495]
===
match
---
name: NotFound [2538,2546]
name: NotFound [2582,2590]
===
match
---
name: URLSafeSerializer [911,928]
name: URLSafeSerializer [911,928]
===
match
---
decorator [1305,1555]
decorator [1349,1599]
===
match
---
trailer [3444,3475]
trailer [3551,3582]
===
match
---
name: headers [3503,3510]
name: headers [3610,3617]
===
match
---
arglist [2604,2620]
arglist [2648,2664]
===
match
---
argument [3336,3360]
argument [3443,3467]
===
match
---
operator: , [1611,1612]
operator: , [1655,1656]
===
match
---
name: task_try_number [3449,3464]
name: task_try_number [3556,3571]
===
match
---
name: ACTION_CAN_READ [1424,1439]
name: ACTION_CAN_READ [1468,1483]
===
match
---
operator: = [3354,3355]
operator: = [3461,3462]
===
match
---
name: metadata [1787,1795]
name: metadata [1831,1839]
===
match
---
operator: = [2452,2453]
operator: = [2496,2497]
===
match
---
return_stmt [3294,3376]
return_stmt [3401,3483]
===
match
---
expr_stmt [2859,2944]
expr_stmt [2966,3051]
===
match
---
name: permissions [1441,1452]
name: permissions [1485,1496]
===
match
---
name: current_app [1728,1739]
name: current_app [1772,1783]
===
match
---
if_stmt [2109,2219]
if_stmt [2153,2263]
===
match
---
name: schemas [1066,1073]
name: schemas [1066,1073]
===
match
---
atom_expr [2538,2567]
atom_expr [2582,2611]
===
match
---
file_input [786,3542]
file_input [786,3649]
===
match
---
string: "DAG Run not found" [2547,2566]
string: "DAG Run not found" [2591,2610]
===
match
---
try_stmt [1819,2007]
try_stmt [1863,2051]
===
match
---
suite [2810,2854]
suite [2867,2915]
===
match
---
suite [1823,1883]
suite [1867,1927]
===
match
---
name: DagRun [1150,1156]
name: DagRun [1194,1200]
===
match
---
simple_stmt [1676,1718]
simple_stmt [1720,1762]
===
match
---
name: metadata [2049,2057]
name: metadata [2093,2101]
===
match
---
expr_stmt [2757,2798]
expr_stmt [2801,2842]
===
match
---
name: log [1217,1220]
name: log [1261,1264]
===
match
---
operator: , [1591,1592]
operator: , [1635,1636]
===
match
---
operator: = [2384,2385]
operator: = [2428,2429]
===
match
---
trailer [2473,2480]
trailer [2517,2524]
===
match
---
simple_stmt [2084,2104]
simple_stmt [2128,2148]
===
match
---
name: get_task [2833,2841]
name: get_task [2894,2902]
===
match
---
import_as_names [1092,1122]
import_as_names [1092,1122]
===
match
---
if_stmt [2262,2373]
if_stmt [2306,2417]
===
match
---
name: logs [3182,3186]
name: logs [3289,3293]
===
match
---
simple_stmt [2378,2440]
simple_stmt [2422,2484]
===
match
---
name: full_content [2112,2124]
name: full_content [2156,2168]
===
match
---
trailer [2782,2790]
trailer [2826,2834]
===
match
---
trailer [2284,2298]
trailer [2328,2342]
===
match
---
expr_stmt [2134,2166]
expr_stmt [2178,2210]
===
match
---
trailer [2880,2897]
trailer [2987,3004]
===
match
---
name: log_schema [1074,1084]
name: log_schema [1074,1084]
===
match
---
operator: = [2211,2212]
operator: = [2255,2256]
===
match
---
name: token [1876,1881]
name: token [1920,1925]
===
match
---
expr_stmt [3175,3230]
expr_stmt [3282,3337]
===
match
---
atom_expr [3488,3541]
atom_expr [3595,3648]
===
match
---
testlist_comp [2910,2942]
testlist_comp [3017,3049]
===
match
---
expr_stmt [2084,2103]
expr_stmt [2128,2147]
===
match
---
atom_expr [2269,2298]
atom_expr [2313,2342]
===
match
---
comparison [2629,2639]
comparison [2673,2683]
===
match
---
simple_stmt [2859,2945]
simple_stmt [2966,3052]
===
match
---
operator: = [2160,2161]
operator: = [2204,2205]
===
match
---
name: ti [2842,2844]
name: ti [2903,2905]
===
match
---
expr_stmt [1722,1760]
expr_stmt [1766,1804]
===
match
---
param [1622,1638]
param [1666,1682]
===
match
---
name: logs [3370,3374]
name: logs [3477,3481]
===
match
---
import_from [930,972]
import_from [930,972]
===
match
---
dotted_name [840,856]
dotted_name [840,856]
===
match
---
trailer [1358,1374]
trailer [1402,1418]
===
match
---
name: URLSafeSerializer [1847,1864]
name: URLSafeSerializer [1891,1908]
===
match
---
atom_expr [2386,2439]
atom_expr [2430,2483]
===
match
---
name: session [1272,1279]
name: session [1316,1323]
===
match
---
comparison [3193,3220]
comparison [3300,3327]
===
match
---
name: task_try_number [3193,3208]
name: task_try_number [3300,3315]
===
match
---
atom [1346,1401]
atom [1390,1445]
===
match
---
name: token [3239,3244]
name: token [3346,3351]
===
match
---
expr_stmt [2185,2218]
expr_stmt [2229,2262]
===
match
---
expr_stmt [2378,2439]
expr_stmt [2422,2483]
===
match
---
atom_expr [2649,2671]
atom_expr [2693,2715]
===
match
---
import_from [835,876]
import_from [835,876]
===
match
---
name: log_reader [1221,1231]
name: log_reader [1265,1275]
===
match
---
atom_expr [3247,3285]
atom_expr [3354,3392]
===
match
---
name: BadRequest [2693,2703]
name: BadRequest [2737,2747]
===
match
---
name: dag_run [2515,2522]
name: dag_run [2559,2566]
===
match
---
name: task_log_reader [3413,3428]
name: task_log_reader [3520,3535]
===
match
---
operator: , [2611,2612]
operator: , [2655,2656]
===
match
---
trailer [2495,2501]
trailer [2539,2545]
===
match
---
name: permissions [1412,1423]
name: permissions [1456,1467]
===
match
---
simple_stmt [1924,2007]
simple_stmt [1968,2051]
===
match
---
trailer [3264,3269]
trailer [3371,3376]
===
match
---
trailer [1492,1508]
trailer [1536,1552]
===
match
---
name: filter [2460,2466]
name: filter [2504,2510]
===
match
---
name: DagRun [2467,2473]
name: DagRun [2511,2517]
===
match
---
expr_stmt [2444,2503]
expr_stmt [2488,2547]
===
match
---
test [3182,3230]
test [3289,3337]
===
match
---
name: dump [3313,3317]
name: dump [3420,3424]
===
match
---
name: logs [3087,3091]
name: logs [3194,3198]
===
insert-tree
---
simple_stmt [1123,1167]
    import_from [1123,1166]
        dotted_name [1128,1146]
            name: airflow [1128,1135]
            name: exceptions [1136,1146]
        name: TaskNotFound [1154,1166]
to
file_input [786,3542]
at 6
===
insert-node
---
suite [2854,2961]
to
if_stmt [2803,2854]
at 1
===
insert-node
---
try_stmt [2863,2961]
to
suite [2854,2961]
at 0
===
move-tree
---
suite [2810,2854]
    simple_stmt [2819,2854]
        expr_stmt [2819,2853]
            atom_expr [2819,2826]
                name: ti [2819,2821]
                trailer [2821,2826]
                    name: task [2822,2826]
            operator: = [2827,2828]
            atom_expr [2829,2853]
                name: dag [2829,2832]
                trailer [2832,2841]
                    name: get_task [2833,2841]
                trailer [2841,2853]
                    atom_expr [2842,2852]
                        name: ti [2842,2844]
                        trailer [2844,2852]
                            name: task_id [2845,2852]
to
try_stmt [2863,2961]
at 0
