===
match
---
name: Any [2362,2365]
name: Any [2362,2365]
===
match
---
import_from [1053,1104]
import_from [1053,1104]
===
match
---
name: self [2464,2468]
name: self [2464,2468]
===
match
---
expr_stmt [2111,2131]
expr_stmt [2111,2131]
===
match
---
simple_stmt [1868,1935]
simple_stmt [1868,1935]
===
match
---
operator: , [1908,1909]
operator: , [1908,1909]
===
match
---
name: aws_conn_id [3051,3062]
name: aws_conn_id [3051,3062]
===
match
---
name: dict [2614,2618]
name: dict [2614,2618]
===
match
---
trailer [2672,2715]
trailer [2672,2715]
===
match
---
operator: @ [2914,2915]
operator: @ [2914,2915]
===
match
---
testlist_comp [2025,2037]
testlist_comp [2025,2037]
===
match
---
param [2237,2271]
param [2237,2271]
===
match
---
name: query_execution_id [2469,2487]
name: query_execution_id [2469,2487]
===
match
---
name: sleep_time [2322,2332]
name: sleep_time [2322,2332]
===
match
---
import_from [892,935]
import_from [892,935]
===
match
---
expr_stmt [2007,2038]
expr_stmt [2007,2038]
===
match
---
param [2179,2184]
param [2179,2184]
===
match
---
expr_stmt [1939,2002]
expr_stmt [1939,2002]
===
match
---
parameters [2598,2619]
parameters [2598,2619]
===
match
---
operator: , [2036,2037]
operator: , [2036,2037]
===
match
---
name: kwargs [2354,2360]
name: kwargs [2354,2360]
===
match
---
simple_stmt [2976,3017]
simple_stmt [2976,3017]
===
match
---
try_stmt [821,936]
try_stmt [821,936]
===
match
---
name: SUCCESS_STATES [2007,2021]
name: SUCCESS_STATES [2007,2021]
===
match
---
string: 'Athena sensor failed' [2793,2815]
string: 'Athena sensor failed' [2793,2815]
===
match
---
atom [2062,2084]
atom [2062,2084]
===
match
---
operator: , [1995,1996]
operator: , [1995,1996]
===
match
---
import_from [937,984]
import_from [937,984]
===
match
---
arglist [2673,2714]
arglist [2673,2714]
===
match
---
tfpdef [2605,2618]
tfpdef [2605,2618]
===
match
---
param [2599,2604]
param [2599,2604]
===
match
---
atom_expr [2737,2756]
atom_expr [2737,2756]
===
match
---
operator: = [2338,2339]
operator: = [2338,2339]
===
match
---
operator: = [2022,2023]
operator: = [2022,2023]
===
match
---
simple_stmt [2089,2107]
simple_stmt [2089,2107]
===
match
---
operator: = [2120,2121]
operator: = [2120,2121]
===
match
---
param [2322,2343]
param [2322,2343]
===
match
---
trailer [2842,2862]
trailer [2842,2862]
===
match
---
trailer [2649,2654]
trailer [2649,2654]
===
match
---
operator: = [2488,2489]
operator: = [2488,2489]
===
match
---
name: super [2390,2395]
name: super [2390,2395]
===
match
---
name: state [2637,2642]
name: state [2637,2642]
===
match
---
trailer [2702,2714]
trailer [2702,2714]
===
match
---
name: AWSAthenaHook [1039,1052]
name: AWSAthenaHook [1039,1052]
===
match
---
expr_stmt [2554,2584]
expr_stmt [2554,2584]
===
match
---
suite [1198,3081]
suite [1198,3092]
===
match
---
simple_stmt [2111,2132]
simple_stmt [2111,2132]
===
match
---
string: '#66c3ff' [2122,2131]
string: '#66c3ff' [2122,2131]
===
match
---
expr_stmt [2425,2455]
expr_stmt [2425,2455]
===
match
---
except_clause [868,886]
except_clause [868,886]
===
match
---
name: hooks [1019,1024]
name: hooks [1019,1024]
===
match
---
simple_stmt [1105,1157]
simple_stmt [1105,1157]
===
match
---
string: """Create and return an AWSAthenaHook""" [2976,3016]
string: """Create and return an AWSAthenaHook""" [2976,3016]
===
match
---
string: 'QUEUED' [1900,1908]
string: 'QUEUED' [1900,1908]
===
match
---
import_from [1105,1156]
import_from [1105,1156]
===
match
---
name: bool [2623,2627]
name: bool [2623,2627]
===
match
---
suite [2757,2817]
suite [2757,2817]
===
match
---
name: self [2737,2741]
name: self [2737,2741]
===
match
---
operator: , [2270,2271]
operator: , [2270,2271]
===
match
---
name: cached_property [852,867]
name: cached_property [852,867]
===
match
---
simple_stmt [2464,2509]
simple_stmt [2464,2509]
===
match
---
expr_stmt [2044,2084]
expr_stmt [2044,2084]
===
match
---
simple_stmt [2390,2417]
simple_stmt [2390,2417]
===
match
---
atom_expr [2698,2714]
atom_expr [2698,2714]
===
match
---
name: INTERMEDIATE_STATES [2843,2862]
name: INTERMEDIATE_STATES [2843,2862]
===
match
---
operator: @ [2137,2138]
operator: @ [2137,2138]
===
match
---
name: self [2425,2429]
name: self [2425,2429]
===
match
---
name: sleep_time [2522,2532]
name: sleep_time [2522,2532]
===
match
---
name: AirflowException [968,984]
name: AirflowException [968,984]
===
match
---
param [2605,2618]
param [2605,2618]
===
match
---
atom [2024,2038]
atom [2024,2038]
===
match
---
number: 10 [2340,2342]
number: 10 [2340,2342]
===
match
---
operator: , [2227,2228]
operator: , [2227,2228]
===
match
---
trailer [2258,2263]
trailer [2258,2263]
===
match
---
atom_expr [2673,2696]
atom_expr [2673,2696]
===
match
---
tfpdef [2280,2296]
tfpdef [2280,2296]
===
match
---
atom_expr [2645,2715]
atom_expr [2645,2715]
===
match
---
operator: , [3062,3063]
operator: , [3062,3063]
===
match
---
operator: = [2643,2644]
operator: = [2643,2644]
===
match
---
name: BaseSensorOperator [1178,1196]
name: BaseSensorOperator [1178,1196]
===
match
---
suite [2381,2585]
suite [2381,2585]
===
match
---
name: AWSAthenaHook [2953,2966]
name: AWSAthenaHook [2953,2966]
===
match
---
import_from [985,1052]
import_from [985,1052]
===
match
---
operator: -> [2620,2622]
operator: -> [2620,2622]
===
match
---
name: BaseSensorOperator [1086,1104]
name: BaseSensorOperator [1086,1104]
===
match
---
operator: , [809,810]
operator: , [809,810]
===
match
---
string: 'RUNNING' [1918,1927]
string: 'RUNNING' [1918,1927]
===
match
---
simple_stmt [787,820]
simple_stmt [787,820]
===
match
---
name: AirflowException [2776,2792]
name: AirflowException [2776,2792]
===
match
---
name: query_execution_id [2678,2696]
name: query_execution_id [2678,2696]
===
match
---
trailer [2406,2416]
trailer [2406,2416]
===
match
---
atom_expr [2464,2487]
atom_expr [2464,2487]
===
match
---
name: sleep_time [3069,3079]
name: sleep_time [3080,3090]
===
match
---
name: self [2179,2183]
name: self [2179,2183]
===
match
---
name: template_ext [2089,2101]
name: template_ext [2089,2101]
===
match
---
operator: = [2264,2265]
operator: = [2264,2265]
===
match
---
classdef [1159,3081]
classdef [1159,3092]
===
match
---
simple_stmt [892,936]
simple_stmt [892,936]
===
match
---
name: cached_property [897,912]
name: cached_property [897,912]
===
match
---
parameters [2943,2949]
parameters [2943,2949]
===
match
---
name: exceptions [950,960]
name: exceptions [950,960]
===
match
---
name: typing [792,798]
name: typing [792,798]
===
match
---
testlist_comp [1900,1928]
testlist_comp [1900,1928]
===
match
---
funcdef [2935,3081]
funcdef [2935,3092]
===
match
---
suite [887,936]
suite [887,936]
===
match
---
name: max_retries [2703,2714]
name: max_retries [2703,2714]
===
match
---
operator: -> [2373,2375]
operator: -> [2373,2375]
===
match
---
name: amazon [1008,1014]
name: amazon [1008,1014]
===
match
---
simple_stmt [2425,2456]
simple_stmt [2425,2456]
===
match
---
operator: * [2193,2194]
operator: * [2193,2194]
===
match
---
param [2280,2313]
param [2280,2313]
===
match
---
atom_expr [2425,2441]
atom_expr [2425,2441]
===
match
---
trailer [3045,3080]
trailer [3045,3091]
===
match
---
comparison [2829,2862]
comparison [2829,2862]
===
match
---
operator: -> [2950,2952]
operator: -> [2950,2952]
===
match
---
atom_expr [2554,2570]
atom_expr [2554,2570]
===
match
---
atom_expr [3046,3062]
atom_expr [3046,3062]
===
match
---
string: """     Asks for the state of the Query until it reaches a failure state or success state.     If the query fails, the task will fail.      :param query_execution_id: query_execution_id to check the state of     :type query_execution_id: str     :param max_retries: Number of times to poll for query state before         returning the current state, defaults to None     :type max_retries: int     :param aws_conn_id: aws connection to use, defaults to 'aws_default'     :type aws_conn_id: str     :param sleep_time: Time in seconds to wait between two consecutive call to         check query status on athena, defaults to 10     :type sleep_time: int     """ [1203,1862]
string: """     Asks for the state of the Query until it reaches a failure state or success state.     If the query fails, the task will fail.      :param query_execution_id: query_execution_id to check the state of     :type query_execution_id: str     :param max_retries: Number of times to poll for query state before         returning the current state, defaults to None     :type max_retries: int     :param aws_conn_id: aws connection to use, defaults to 'aws_default'     :type aws_conn_id: str     :param sleep_time: Time in seconds to wait between two consecutive call to         check query status on athena, defaults to 10     :type sleep_time: int     """ [1203,1862]
===
match
---
expr_stmt [2089,2106]
expr_stmt [2089,2106]
===
match
---
import_from [787,819]
import_from [787,819]
===
match
---
name: self [2698,2702]
name: self [2698,2702]
===
match
---
param [2352,2366]
param [2352,2366]
===
match
---
dotted_name [1110,1134]
dotted_name [1110,1134]
===
match
---
expr_stmt [2517,2545]
expr_stmt [2517,2545]
===
match
---
operator: , [2183,2184]
operator: , [2183,2184]
===
match
---
name: max_retries [2573,2584]
name: max_retries [2573,2584]
===
match
---
suite [2967,3081]
suite [2967,3092]
===
match
---
atom [1956,2002]
atom [1956,2002]
===
match
---
simple_stmt [830,868]
simple_stmt [830,868]
===
match
---
name: airflow [1058,1065]
name: airflow [1058,1065]
===
match
---
name: state [2829,2834]
name: state [2829,2834]
===
match
---
name: sensors [1066,1073]
name: sensors [1066,1073]
===
match
---
tfpdef [2322,2337]
tfpdef [2322,2337]
===
match
---
operator: = [2297,2298]
operator: = [2297,2298]
===
match
---
return_stmt [2876,2888]
return_stmt [2876,2888]
===
match
---
trailer [2468,2487]
trailer [2468,2487]
===
match
---
arglist [3046,3079]
arglist [3046,3090]
===
match
---
operator: , [2312,2313]
operator: , [2312,2313]
===
match
---
operator: , [2603,2604]
operator: , [2603,2604]
===
match
---
return_stmt [2897,2908]
return_stmt [2897,2908]
===
match
---
string: 'SUCCEEDED' [2025,2036]
string: 'SUCCEEDED' [2025,2036]
===
match
---
string: 'CANCELLED' [1984,1995]
string: 'CANCELLED' [1984,1995]
===
match
---
simple_stmt [2770,2817]
simple_stmt [2770,2817]
===
match
---
name: airflow [990,997]
name: airflow [990,997]
===
match
---
funcdef [2590,2909]
funcdef [2590,2909]
===
match
---
name: apply_defaults [2138,2152]
name: apply_defaults [2138,2152]
===
match
---
name: self [3046,3050]
name: self [3046,3050]
===
match
---
atom_expr [3064,3079]
atom_expr [3075,3090]
===
match
---
name: state [2728,2733]
name: state [2728,2733]
===
match
---
operator: , [2342,2343]
operator: , [2342,2343]
===
match
---
name: providers [998,1007]
name: providers [998,1007]
===
match
---
trailer [2429,2441]
trailer [2429,2441]
===
match
---
name: aws_conn_id [2430,2441]
name: aws_conn_id [2430,2441]
===
match
---
funcdef [2157,2585]
funcdef [2157,2585]
===
match
---
name: query_execution_id [2204,2222]
name: query_execution_id [2204,2222]
===
match
---
name: query_execution_id [2490,2508]
name: query_execution_id [2490,2508]
===
match
---
dotted_name [990,1031]
dotted_name [990,1031]
===
match
---
simple_stmt [2554,2585]
simple_stmt [2554,2585]
===
match
---
name: FAILURE_STATES [2742,2756]
name: FAILURE_STATES [2742,2756]
===
match
---
name: cached_property [2915,2930]
name: cached_property [2915,2930]
===
match
---
simple_stmt [3025,3081]
simple_stmt [3025,3092]
===
match
---
suite [2863,2889]
suite [2863,2889]
===
match
---
atom_expr [2776,2816]
atom_expr [2776,2816]
===
match
---
operator: ** [2352,2354]
operator: ** [2352,2354]
===
match
---
name: aws [1015,1018]
name: aws [1015,1018]
===
match
---
name: max_retries [2559,2570]
name: max_retries [2559,2570]
===
match
---
name: base [1074,1078]
name: base [1074,1078]
===
match
---
name: ui_color [2111,2119]
name: ui_color [2111,2119]
===
match
---
name: self [2645,2649]
name: self [2645,2649]
===
match
---
operator: , [2194,2195]
operator: , [2194,2195]
===
match
---
atom_expr [2517,2532]
atom_expr [2517,2532]
===
match
---
name: str [2224,2227]
name: str [2224,2227]
===
match
---
operator: , [2365,2366]
operator: , [2365,2366]
===
match
---
name: airflow [1110,1117]
name: airflow [1110,1117]
===
match
---
dotted_name [942,960]
dotted_name [942,960]
===
match
---
tfpdef [2204,2227]
tfpdef [2204,2227]
===
match
---
decorator [2137,2153]
decorator [2137,2153]
===
match
---
name: sleep_time [2535,2545]
name: sleep_time [2535,2545]
===
match
---
simple_stmt [985,1053]
simple_stmt [985,1053]
===
match
---
name: hook [2650,2654]
name: hook [2650,2654]
===
match
---
string: 'FAILED' [1966,1974]
string: 'FAILED' [1966,1974]
===
match
---
raise_stmt [2770,2816]
raise_stmt [2770,2816]
===
match
---
simple_stmt [1203,1863]
simple_stmt [1203,1863]
===
match
---
operator: = [1888,1889]
operator: = [1888,1889]
===
match
---
decorator [2914,2931]
decorator [2914,2931]
===
match
---
name: Any [806,809]
name: Any [806,809]
===
match
---
trailer [2792,2816]
trailer [2792,2816]
===
match
---
atom [2104,2106]
atom [2104,2106]
===
match
---
atom_expr [3032,3080]
atom_expr [3032,3091]
===
match
---
param [2944,2948]
param [2944,2948]
===
match
---
name: str [2293,2296]
name: str [2293,2296]
===
match
---
import_as_names [806,819]
import_as_names [806,819]
===
match
---
simple_stmt [937,985]
simple_stmt [937,985]
===
match
---
name: apply_defaults [1142,1156]
name: apply_defaults [1142,1156]
===
match
---
simple_stmt [2007,2039]
simple_stmt [2007,2039]
===
match
---
return_stmt [3025,3080]
return_stmt [3025,3091]
===
match
---
name: self [2838,2842]
name: self [2838,2842]
===
match
---
operator: , [1927,1928]
operator: , [1927,1928]
===
match
---
name: context [2605,2612]
name: context [2605,2612]
===
match
---
tfpdef [2354,2365]
tfpdef [2354,2365]
===
match
---
name: ImportError [875,886]
name: ImportError [875,886]
===
match
---
trailer [3050,3062]
trailer [3050,3062]
===
match
---
argument [2407,2415]
argument [2407,2415]
===
match
---
suite [2628,2909]
suite [2628,2909]
===
match
---
tfpdef [2237,2263]
tfpdef [2237,2263]
===
match
---
trailer [2558,2570]
trailer [2558,2570]
===
match
---
name: decorators [1124,1134]
name: decorators [1124,1134]
===
match
---
name: kwargs [2409,2415]
name: kwargs [2409,2415]
===
match
---
simple_stmt [1053,1105]
simple_stmt [1053,1105]
===
match
---
name: poll_query_status [2655,2672]
name: poll_query_status [2655,2672]
===
match
---
import_from [830,867]
import_from [830,867]
===
match
---
name: self [2599,2603]
name: self [2599,2603]
===
match
---
trailer [3068,3079]
trailer [3079,3090]
===
match
---
operator: = [2442,2443]
operator: = [2442,2443]
===
match
---
simple_stmt [1939,2003]
simple_stmt [1939,2003]
===
match
---
name: INTERMEDIATE_STATES [1868,1887]
name: INTERMEDIATE_STATES [1868,1887]
===
match
---
operator: = [2533,2534]
operator: = [2533,2534]
===
match
---
string: 'query_execution_id' [2063,2083]
string: 'query_execution_id' [2063,2083]
===
match
---
decorated [2137,2585]
decorated [2137,2585]
===
match
---
trailer [2397,2406]
trailer [2397,2406]
===
match
---
atom_expr [2250,2263]
atom_expr [2250,2263]
===
match
---
atom_expr [2390,2416]
atom_expr [2390,2416]
===
match
---
operator: , [2696,2697]
operator: , [2696,2697]
===
match
---
name: int [2259,2262]
name: int [2259,2262]
===
match
---
trailer [2654,2672]
trailer [2654,2672]
===
match
---
name: int [2334,2337]
name: int [2334,2337]
===
match
---
name: self [3064,3068]
name: self [3075,3079]
===
match
---
name: aws_conn_id [2444,2455]
name: aws_conn_id [2444,2455]
===
match
---
name: hook [2939,2943]
name: hook [2939,2943]
===
match
---
name: athena [1025,1031]
name: athena [1025,1031]
===
match
---
name: Optional [811,819]
name: Optional [811,819]
===
match
---
atom [1890,1934]
atom [1890,1934]
===
match
---
expr_stmt [1868,1934]
expr_stmt [1868,1934]
===
match
---
simple_stmt [2637,2716]
simple_stmt [2637,2716]
===
match
---
trailer [2677,2696]
trailer [2677,2696]
===
match
---
trailer [2521,2532]
trailer [2521,2532]
===
match
---
name: FAILURE_STATES [1939,1953]
name: FAILURE_STATES [1939,1953]
===
match
---
simple_stmt [2044,2085]
simple_stmt [2044,2085]
===
match
---
name: aws_conn_id [2280,2291]
name: aws_conn_id [2280,2291]
===
match
---
expr_stmt [2464,2508]
expr_stmt [2464,2508]
===
match
---
file_input [787,3081]
file_input [787,3092]
===
match
---
if_stmt [2725,2817]
if_stmt [2725,2817]
===
match
---
name: airflow [942,949]
name: airflow [942,949]
===
match
---
name: max_retries [2237,2248]
name: max_retries [2237,2248]
===
match
---
name: self [2517,2521]
name: self [2517,2521]
===
match
---
if_stmt [2826,2889]
if_stmt [2826,2889]
===
match
---
suite [825,868]
suite [825,868]
===
match
---
operator: = [2571,2572]
operator: = [2571,2572]
===
match
---
name: AthenaSensor [1165,1177]
name: AthenaSensor [1165,1177]
===
match
---
comparison [2728,2756]
comparison [2728,2756]
===
match
---
trailer [2395,2397]
trailer [2395,2397]
===
match
---
operator: ** [2407,2409]
operator: ** [2407,2409]
===
match
---
name: self [2554,2558]
name: self [2554,2558]
===
match
---
name: self [2673,2677]
name: self [2673,2677]
===
match
---
name: template_fields [2044,2059]
name: template_fields [2044,2059]
===
match
---
atom_expr [2838,2862]
atom_expr [2838,2862]
===
match
---
operator: = [2060,2061]
operator: = [2060,2061]
===
match
---
simple_stmt [2876,2889]
simple_stmt [2876,2889]
===
match
---
name: Optional [2250,2258]
name: Optional [2250,2258]
===
match
---
operator: = [1954,1955]
operator: = [1954,1955]
===
match
---
string: 'aws_default' [2299,2312]
string: 'aws_default' [2299,2312]
===
match
---
name: __init__ [2398,2406]
name: __init__ [2398,2406]
===
match
---
name: functools [835,844]
name: functools [835,844]
===
match
---
decorated [2914,3081]
decorated [2914,3092]
===
match
---
testlist_comp [1966,1996]
testlist_comp [1966,1996]
===
match
---
param [2204,2228]
param [2204,2228]
===
match
---
trailer [2741,2756]
trailer [2741,2756]
===
match
---
parameters [2169,2372]
parameters [2169,2372]
===
match
---
simple_stmt [2517,2546]
simple_stmt [2517,2546]
===
match
---
dotted_name [1058,1078]
dotted_name [1058,1078]
===
match
---
operator: = [2102,2103]
operator: = [2102,2103]
===
match
---
operator: , [1974,1975]
operator: , [1974,1975]
===
match
---
name: cached_property [920,935]
name: cached_property [920,935]
===
match
---
name: poke [2594,2598]
name: poke [2594,2598]
===
match
---
expr_stmt [2637,2715]
expr_stmt [2637,2715]
===
match
---
name: self [2944,2948]
name: self [2944,2948]
===
match
---
name: __init__ [2161,2169]
name: __init__ [2161,2169]
===
match
---
name: utils [1118,1123]
name: utils [1118,1123]
===
match
---
simple_stmt [2897,2909]
simple_stmt [2897,2909]
===
match
---
name: AWSAthenaHook [3032,3045]
name: AWSAthenaHook [3032,3045]
===
insert-node
---
argument [3064,3090]
to
arglist [3046,3079]
at 2
===
move-tree
---
atom_expr [3064,3079]
    name: self [3064,3068]
    trailer [3068,3079]
        name: sleep_time [3069,3079]
to
argument [3064,3090]
at 2
