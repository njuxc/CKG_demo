===
match
---
atom_expr [2400,2426]
atom_expr [2427,2453]
===
match
---
import_from [1072,1133]
import_from [1072,1133]
===
match
---
atom_expr [3259,3305]
atom_expr [3286,3332]
===
match
---
string: "/taskreschedule/list/?_flt_0_execution_date=2018-10-09+22:44:31" [3954,4019]
string: "/taskreschedule/list/?_flt_0_execution_date=2018-10-09+22:44:31" [3981,4046]
===
match
---
expr_stmt [4178,4206]
expr_stmt [4205,4233]
===
match
---
operator: , [4595,4596]
operator: , [4622,4623]
===
match
---
name: mock [5110,5114]
name: mock [5137,5141]
===
match
---
number: 3.12 [5514,5518]
number: 3.12 [5541,5545]
===
match
---
dotted_name [1031,1054]
dotted_name [1031,1054]
===
match
---
operator: , [4073,4074]
operator: , [4100,4101]
===
match
---
simple_stmt [3219,3254]
simple_stmt [3246,3281]
===
match
---
string: "<em>$PLUGINS_FOLDER/</em>test_plugin.py" [2811,2852]
string: "<em>$PLUGINS_FOLDER/</em>test_plugin.py" [2838,2879]
===
match
---
arglist [2289,2302]
arglist [2316,2329]
===
match
---
name: tests [1077,1082]
name: tests [1077,1082]
===
match
---
name: truncate_task_duration [5663,5685]
name: truncate_task_duration [5690,5712]
===
match
---
simple_stmt [3012,3158]
simple_stmt [3039,3185]
===
match
---
name: mock_plugin [3196,3207]
name: mock_plugin [3223,3234]
===
match
---
trailer [3718,3745]
trailer [3745,3772]
===
match
---
operator: , [1317,1318]
operator: , [1317,1318]
===
match
---
trailer [2356,2359]
trailer [2383,2386]
===
match
---
trailer [2038,2096]
trailer [2065,2123]
===
match
---
atom_expr [3033,3157]
atom_expr [3060,3184]
===
match
---
operator: , [5543,5544]
operator: , [5570,5571]
===
match
---
operator: , [3738,3739]
operator: , [3765,3766]
===
match
---
name: mark [4431,4435]
name: mark [4458,4462]
===
match
---
operator: , [4162,4163]
operator: , [4189,4190]
===
match
---
atom_expr [2229,2254]
atom_expr [2256,2281]
===
match
---
string: "http://localhost:8080/trigger?dag_id=test_dag&origin=%2Ftree%3Fdag_id%3Dtest_dag" [5005,5087]
string: "http://localhost:8080/trigger?dag_id=test_dag&origin=%2Ftree%3Fdag_id%3Dtest_dag" [5032,5114]
===
match
---
string: 'True' [1927,1933]
string: 'True' [1954,1960]
===
match
---
comparison [2400,2523]
comparison [2427,2550]
===
match
---
import_name [787,796]
import_name [787,796]
===
match
---
atom [4605,4736]
atom [4632,4763]
===
match
---
name: get [3239,3242]
name: get [3266,3269]
===
match
---
param [5201,5213]
param [5228,5240]
===
match
---
name: test_plugin_endpoint_should_not_be_unauthenticated [3510,3560]
name: test_plugin_endpoint_should_not_be_unauthenticated [3537,3587]
===
match
---
string: "List Task Instance" [3899,3919]
string: "List Task Instance" [3926,3946]
===
match
---
dictorsetmaker [1305,1344]
dictorsetmaker [1305,1344]
===
match
---
atom_expr [3012,3030]
atom_expr [3039,3057]
===
match
---
testlist_comp [5561,5573]
testlist_comp [5588,5600]
===
match
---
trailer [2359,2364]
trailer [2386,2391]
===
match
---
simple_stmt [3693,3746]
simple_stmt [3720,3773]
===
match
---
name: check_content_in_response [2013,2038]
name: check_content_in_response [2040,2065]
===
match
---
operator: , [2063,2064]
operator: , [2090,2091]
===
match
---
name: app [5186,5189]
name: app [5213,5216]
===
match
---
string: "Sign In - Airflow" [3719,3738]
string: "Sign In - Airflow" [3746,3765]
===
match
---
operator: == [2427,2429]
operator: == [2454,2456]
===
match
---
arglist [3059,3151]
arglist [3086,3178]
===
match
---
string: '# Your Airflow administrator chose not to expose the configuration, ' [1510,1580]
string: '# Your Airflow administrator chose not to expose the configuration, ' [1510,1580]
===
match
---
trailer [1964,1968]
trailer [1991,1995]
===
match
---
operator: = [2992,2993]
operator: = [3019,3020]
===
match
---
operator: , [3792,3793]
operator: , [3819,3820]
===
match
---
simple_stmt [2594,2629]
simple_stmt [2621,2656]
===
match
---
trailer [3667,3688]
trailer [3694,3715]
===
match
---
expr_stmt [3571,3633]
expr_stmt [3598,3660]
===
match
---
name: initialize_config [1855,1872]
name: initialize_config [1862,1879]
===
match
---
simple_stmt [959,1026]
simple_stmt [959,1026]
===
match
---
string: "36539'%3balert(1)%2f%2f166" [4557,4585]
string: "36539'%3balert(1)%2f%2f166" [4584,4612]
===
match
---
operator: } [2522,2523]
operator: } [2549,2550]
===
match
---
decorator [4423,5109]
decorator [4450,5136]
===
match
---
atom_expr [1952,2008]
atom_expr [1979,2035]
===
match
---
operator: = [4082,4083]
operator: = [4109,4110]
===
match
---
argument [5290,5322]
argument [5317,5349]
===
match
---
trailer [3068,3070]
trailer [3095,3097]
===
match
---
trailer [5268,5289]
trailer [5295,5316]
===
match
---
trailer [4201,4206]
trailer [4228,4233]
===
match
---
decorators [4423,5150]
decorators [4450,5177]
===
match
---
param [2922,2934]
param [2949,2961]
===
match
---
argument [1986,2007]
argument [2013,2034]
===
match
---
trailer [2412,2426]
trailer [2439,2453]
===
match
---
parameters [3560,3565]
parameters [3587,3592]
===
match
---
atom_expr [3226,3253]
atom_expr [3253,3280]
===
match
---
name: resp [2775,2779]
name: resp [2802,2806]
===
match
---
dotted_name [964,981]
dotted_name [964,981]
===
match
---
trailer [3186,3209]
trailer [3213,3236]
===
match
---
atom_expr [3693,3745]
atom_expr [3720,3772]
===
match
---
funcdef [4113,4421]
funcdef [4140,4448]
===
match
---
string: 'webserver' [1896,1907]
string: 'webserver' [1923,1934]
===
match
---
name: name [2360,2364]
name: name [2387,2391]
===
match
---
arglist [2659,2678]
arglist [2686,2705]
===
match
---
name: parametrize [5394,5405]
name: parametrize [5421,5432]
===
match
---
string: "source" [2765,2773]
string: "source" [2792,2800]
===
match
---
operator: = [3031,3032]
operator: = [3058,3059]
===
match
---
operator: == [5701,5703]
operator: == [5728,5730]
===
match
---
operator: , [5184,5185]
operator: , [5211,5212]
===
match
---
atom [1305,1335]
atom [1305,1335]
===
match
---
testlist_comp [5462,5476]
testlist_comp [5489,5503]
===
match
---
name: resp [3498,3502]
name: resp [3525,3529]
===
match
---
name: expected_duration [5704,5721]
name: expected_duration [5731,5748]
===
match
---
number: 0 [2410,2411]
number: 0 [2437,2438]
===
match
---
trailer [1872,1874]
trailer [1879,1881]
===
match
---
operator: } [1933,1934]
operator: } [1960,1961]
===
match
---
atom_expr [2975,2991]
atom_expr [3002,3018]
===
match
---
name: patch [5115,5120]
name: patch [5142,5147]
===
match
---
operator: , [5469,5470]
operator: , [5496,5497]
===
match
---
assert_stmt [5656,5721]
assert_stmt [5683,5748]
===
match
---
operator: , [3681,3682]
operator: , [3708,3709]
===
match
---
arglist [1459,1654]
arglist [1459,1654]
===
match
---
operator: , [4536,4537]
operator: , [4563,4564]
===
match
---
name: tests [1031,1036]
name: tests [1031,1036]
===
match
---
with_stmt [1879,2009]
with_stmt [1906,2036]
===
match
---
dotted_name [1139,1159]
dotted_name [1139,1159]
===
match
---
suite [5324,5379]
suite [5351,5406]
===
match
---
string: 'openapi_spec_url' [2440,2458]
string: 'openapi_spec_url' [2467,2485]
===
match
---
name: admin_client [2601,2613]
name: admin_client [2628,2640]
===
match
---
name: truncate_task_duration [1003,1025]
name: truncate_task_duration [1003,1025]
===
match
---
operator: , [1984,1985]
operator: , [2011,2012]
===
match
---
name: admin_client [2229,2241]
name: admin_client [2256,2268]
===
match
---
operator: , [1639,1640]
operator: , [1639,1640]
===
match
---
operator: , [1496,1497]
operator: , [1496,1497]
===
match
---
atom_expr [3578,3633]
atom_expr [3605,3660]
===
match
---
string: 'test-entrypoint-testpluginview' [3117,3149]
string: 'test-entrypoint-testpluginview' [3144,3176]
===
match
---
name: os [1680,1682]
name: os [1680,1682]
===
match
---
name: pytest [4424,4430]
name: pytest [4451,4457]
===
match
---
name: parametrize [4436,4447]
name: parametrize [4463,4474]
===
match
---
simple_stmt [1026,1072]
simple_stmt [1026,1072]
===
match
---
name: content [4164,4171]
name: content [4191,4198]
===
match
---
operator: , [4704,4705]
operator: , [4731,4732]
===
match
---
argument [3082,3097]
argument [3109,3124]
===
match
---
name: test_duration [5617,5630]
name: test_duration [5644,5657]
===
match
---
operator: , [4477,4478]
operator: , [4504,4505]
===
match
---
atom [4516,4546]
atom [4543,4573]
===
match
---
simple_stmt [2633,2680]
simple_stmt [2660,2707]
===
match
---
string: 'expose_config' [1319,1334]
string: 'expose_config' [1319,1334]
===
match
---
string: "Airflow Plugins" [2710,2727]
string: "Airflow Plugins" [2737,2754]
===
match
---
operator: = [5246,5247]
operator: = [5273,5274]
===
match
---
trailer [2409,2412]
trailer [2436,2439]
===
match
---
operator: , [3353,3354]
operator: , [3380,3381]
===
match
---
atom [5535,5550]
atom [5562,5577]
===
match
---
name: resp [1945,1949]
name: resp [1972,1976]
===
match
---
trailer [2319,2330]
trailer [2346,2357]
===
match
---
atom_expr [5340,5362]
atom_expr [5367,5389]
===
match
---
name: ids [4079,4082]
name: ids [4106,4109]
===
match
---
operator: { [1304,1305]
operator: { [1304,1305]
===
match
---
operator: , [4094,4095]
operator: , [4121,4122]
===
match
---
string: "List Task Reschedule" [4033,4055]
string: "List Task Reschedule" [4060,4082]
===
match
---
name: url [4202,4205]
name: url [4229,4232]
===
match
---
simple_stmt [2975,3008]
simple_stmt [3002,3035]
===
match
---
name: mock_plugin [3012,3023]
name: mock_plugin [3039,3050]
===
match
---
operator: } [1344,1345]
operator: } [1344,1345]
===
match
---
string: 'most likely for security reasons.' [1593,1628]
string: 'most likely for security reasons.' [1593,1628]
===
match
---
string: "test_url, expected_url" [4453,4477]
string: "test_url, expected_url" [4480,4504]
===
match
---
suite [1347,1420]
suite [1347,1420]
===
match
---
number: 10 [5571,5573]
number: 10 [5598,5600]
===
match
---
trailer [3436,3503]
trailer [3463,3530]
===
match
---
name: pytest [5382,5388]
name: pytest [5409,5415]
===
match
---
param [5617,5631]
param [5644,5658]
===
match
---
name: AirflowPlugin [2955,2968]
name: AirflowPlugin [2982,2995]
===
match
---
operator: , [3930,3931]
operator: , [3957,3958]
===
match
---
trailer [3284,3305]
trailer [3311,3332]
===
match
---
name: source [3024,3030]
name: source [3051,3057]
===
match
---
trailer [2658,2679]
trailer [2685,2706]
===
match
---
arglist [3391,3405]
arglist [3418,3432]
===
match
---
operator: , [4874,4875]
operator: , [4901,4902]
===
match
---
decorator [3748,4113]
decorator [3775,4140]
===
match
---
import_as_names [927,958]
import_as_names [927,958]
===
match
---
trailer [4405,4420]
trailer [4432,4447]
===
match
---
operator: @ [1663,1664]
operator: @ [1663,1664]
===
match
---
operator: , [4413,4414]
operator: , [4440,4441]
===
match
---
name: resp [2674,2678]
name: resp [2701,2705]
===
match
---
testlist_comp [4760,4875]
testlist_comp [4787,4902]
===
match
---
with_stmt [1289,1420]
with_stmt [1289,1420]
===
match
---
simple_stmt [1356,1420]
simple_stmt [1356,1420]
===
match
---
name: templates [2347,2356]
name: templates [2374,2383]
===
match
---
simple_stmt [3638,3689]
simple_stmt [3665,3716]
===
match
---
name: admin_client [2922,2934]
name: admin_client [2949,2961]
===
match
---
dotted_name [1077,1106]
dotted_name [1077,1106]
===
match
---
testlist_comp [4084,4108]
testlist_comp [4111,4135]
===
match
---
operator: , [1192,1193]
operator: , [1192,1193]
===
match
---
name: AirflowPlugin [927,940]
name: AirflowPlugin [927,940]
===
match
---
operator: , [5105,5106]
operator: , [5132,5133]
===
match
---
operator: { [1894,1895]
operator: { [1921,1922]
===
match
---
string: 'expose_config' [1909,1924]
string: 'expose_config' [1936,1951]
===
match
---
name: check_content_in_response [2739,2764]
name: check_content_in_response [2766,2791]
===
match
---
string: 'Airflow Configuration' [2040,2063]
string: 'Airflow Configuration' [2067,2090]
===
match
---
name: app [3578,3581]
name: app [3605,3608]
===
match
---
name: base_url [5290,5298]
name: base_url [5317,5325]
===
match
---
operator: , [3298,3299]
operator: , [3325,3326]
===
match
---
simple_stmt [2222,2255]
simple_stmt [2249,2282]
===
match
---
funcdef [2862,3504]
funcdef [2889,3531]
===
match
---
arglist [3285,3304]
arglist [3312,3331]
===
match
---
trailer [2986,2991]
trailer [3013,3018]
===
match
---
name: get [3596,3599]
name: get [3623,3626]
===
match
---
name: admin_client [1773,1785]
name: admin_client [1773,1785]
===
match
---
operator: , [4585,4586]
operator: , [4612,4613]
===
match
---
operator: , [5525,5526]
operator: , [5552,5553]
===
match
---
simple_stmt [1134,1224]
simple_stmt [1134,1224]
===
match
---
operator: = [2953,2954]
operator: = [2980,2981]
===
match
---
operator: == [2365,2367]
operator: == [2392,2394]
===
match
---
name: airflow [964,971]
name: airflow [964,971]
===
match
---
trailer [1375,1379]
trailer [1375,1379]
===
match
---
name: www [972,975]
name: www [972,975]
===
match
---
expr_stmt [2222,2254]
expr_stmt [2249,2281]
===
match
---
name: check_content_in_response [3411,3436]
name: check_content_in_response [3438,3463]
===
match
---
name: mock_plugins [1094,1106]
name: mock_plugins [1094,1106]
===
match
---
string: "url, content" [3778,3792]
string: "url, content" [3805,3819]
===
match
---
operator: = [3627,3628]
operator: = [3654,3655]
===
match
---
strings [1510,1628]
strings [1510,1628]
===
match
---
simple_stmt [2684,2735]
simple_stmt [2711,2762]
===
match
---
trailer [3049,3157]
trailer [3076,3184]
===
match
---
operator: = [1950,1951]
operator: = [1977,1978]
===
match
---
trailer [2810,2859]
trailer [2837,2886]
===
match
---
name: patch [1669,1674]
name: patch [1669,1674]
===
match
---
atom_expr [5663,5700]
atom_expr [5690,5727]
===
match
---
param [5186,5190]
param [5213,5217]
===
match
---
name: check_content_in_response [3365,3390]
name: check_content_in_response [3392,3417]
===
match
---
dictorsetmaker [1693,1733]
dictorsetmaker [1693,1733]
===
match
---
funcdef [5585,5722]
funcdef [5612,5749]
===
match
---
trailer [2709,2734]
trailer [2736,2761]
===
match
---
operator: = [4183,4184]
operator: = [4210,4211]
===
match
---
operator: @ [3748,3749]
operator: @ [3775,3776]
===
match
---
name: check_content_in_response [2263,2288]
name: check_content_in_response [2290,2315]
===
match
---
name: templates [2400,2409]
name: templates [2427,2436]
===
match
---
operator: , [3399,3400]
operator: , [3426,3427]
===
match
---
decorator [5381,5585]
decorator [5408,5612]
===
match
---
name: resp [3401,3405]
name: resp [3428,3432]
===
match
---
operator: , [940,941]
operator: , [940,941]
===
match
---
name: check_content_in_response [2633,2658]
name: check_content_in_response [2660,2685]
===
match
---
name: dict [1675,1679]
name: dict [1675,1679]
===
match
---
operator: , [5569,5570]
operator: , [5596,5597]
===
match
---
testlist_comp [4619,4726]
testlist_comp [4646,4753]
===
match
---
dotted_name [844,865]
dotted_name [844,865]
===
match
---
parameters [4144,4172]
parameters [4171,4199]
===
match
---
arglist [3778,4110]
arglist [3805,4137]
===
match
---
operator: { [3108,3109]
operator: { [3135,3136]
===
match
---
param [2156,2168]
param [2183,2195]
===
match
---
operator: , [3097,3098]
operator: , [3124,3125]
===
match
---
operator: , [5477,5478]
operator: , [5504,5505]
===
match
---
number: 3.12 [5520,5524]
number: 3.12 [5547,5551]
===
match
---
suite [3566,3746]
suite [3593,3773]
===
match
---
operator: , [3496,3497]
operator: , [3523,3524]
===
match
---
string: "/home" [4498,4505]
string: "/home" [4525,4532]
===
match
---
argument [4079,4109]
argument [4106,4136]
===
match
---
trailer [2613,2617]
trailer [2640,2644]
===
match
---
name: version [3082,3089]
name: version [3109,3116]
===
match
---
testlist_comp [4493,5099]
testlist_comp [4520,5126]
===
match
---
suite [1284,1661]
suite [1284,1661]
===
match
---
trailer [2197,2199]
trailer [2224,2226]
===
match
---
import_from [1026,1071]
import_from [1026,1071]
===
match
---
name: get [1965,1968]
name: get [1992,1995]
===
match
---
number: 1 [2334,2335]
number: 1 [2361,2362]
===
match
---
operator: , [1690,1691]
operator: , [1690,1691]
===
match
---
operator: , [3609,3610]
operator: , [3636,3637]
===
match
---
operator: { [1692,1693]
operator: { [1692,1693]
===
match
---
atom [4483,5105]
atom [4510,5132]
===
match
---
expr_stmt [2594,2628]
expr_stmt [2621,2655]
===
match
---
name: mock [818,822]
name: mock [818,822]
===
match
---
operator: , [4157,4158]
operator: , [4184,4185]
===
match
---
string: "http://localhost:8080/trigger?dag_id=test_dag&origin=%2Ftree%3Fdag_id%3Dtest_dag" [4909,4991]
string: "http://localhost:8080/trigger?dag_id=test_dag&origin=%2Ftree%3Fdag_id%3Dtest_dag" [4936,5018]
===
match
---
arglist [3082,3150]
arglist [3109,3177]
===
match
---
decorated [5381,5722]
decorated [5408,5749]
===
match
---
atom [3195,3208]
atom [3222,3235]
===
match
---
name: test_url [5353,5361]
name: test_url [5380,5388]
===
match
---
simple_stmt [4380,4421]
simple_stmt [4407,4448]
===
match
---
atom_expr [3411,3503]
atom_expr [3438,3530]
===
match
---
string: "/home" [4538,4545]
string: "/home" [4565,4572]
===
match
---
name: check_content_in_response [4380,4405]
name: check_content_in_response [4407,4432]
===
match
---
param [3561,3564]
param [3588,3591]
===
match
---
name: content [4406,4413]
name: content [4433,4440]
===
match
---
name: EntryPointSource [942,958]
name: EntryPointSource [942,958]
===
match
---
operator: @ [4423,4424]
operator: @ [4450,4451]
===
match
---
name: resp [2729,2733]
name: resp [2756,2760]
===
match
---
string: "/home" [4587,4594]
string: "/home" [4614,4621]
===
match
---
trailer [1303,1346]
trailer [1303,1346]
===
match
---
operator: , [5630,5631]
operator: , [5657,5658]
===
match
---
name: resp [2594,2598]
name: resp [2621,2625]
===
match
---
operator: , [2672,2673]
operator: , [2699,2700]
===
match
---
string: 'Redoc' [2289,2296]
string: 'Redoc' [2316,2323]
===
match
---
atom [3808,3930]
atom [3835,3957]
===
match
---
testlist_comp [4909,5088]
testlist_comp [4936,5115]
===
match
---
string: 'rest_api_enabled' [2492,2510]
string: 'rest_api_enabled' [2519,2537]
===
match
---
string: 'configuration' [1380,1395]
string: 'configuration' [1380,1395]
===
match
---
param [2575,2587]
param [2602,2614]
===
match
---
argument [3611,3632]
argument [3638,3659]
===
match
---
simple_stmt [824,838]
simple_stmt [824,838]
===
match
---
operator: , [5098,5099]
operator: , [5125,5126]
===
match
---
name: admin_client [4185,4197]
name: admin_client [4212,4224]
===
match
---
atom_expr [2013,2096]
atom_expr [2040,2123]
===
match
---
name: views [976,981]
name: views [976,981]
===
match
---
operator: , [4496,4497]
operator: , [4523,4524]
===
match
---
name: parametrize [3761,3772]
name: parametrize [3788,3799]
===
match
---
argument [1397,1418]
argument [1397,1418]
===
match
---
name: os [794,796]
name: os [794,796]
===
match
---
funcdef [1226,1661]
funcdef [1226,1661]
===
match
---
operator: { [2430,2431]
operator: { [2457,2458]
===
match
---
name: check_content_in_response [1424,1449]
name: check_content_in_response [1424,1449]
===
match
---
operator: = [3194,3195]
operator: = [3221,3222]
===
match
---
atom_expr [3365,3406]
atom_expr [3392,3433]
===
match
---
operator: } [1733,1734]
operator: } [1733,1734]
===
match
---
dotted_name [896,919]
dotted_name [896,919]
===
match
---
name: test_plugin_should_list_on_page_with_details [2530,2574]
name: test_plugin_should_list_on_page_with_details [2557,2601]
===
match
---
trailer [5685,5700]
trailer [5712,5727]
===
match
---
arglist [1969,2007]
arglist [1996,2034]
===
match
---
import_as_names [989,1025]
import_as_names [989,1025]
===
match
---
testlist_comp [4494,4505]
testlist_comp [4521,4532]
===
match
---
string: "" [4494,4496]
string: "" [4521,4523]
===
match
---
simple_stmt [3411,3504]
simple_stmt [3438,3531]
===
match
---
number: 10.01232 [5561,5569]
number: 10.01232 [5588,5596]
===
match
---
name: pytest [3749,3755]
name: pytest [3776,3782]
===
match
---
parameters [2136,2169]
parameters [2163,2196]
===
match
---
simple_stmt [5656,5722]
simple_stmt [5683,5749]
===
match
---
operator: , [1001,1002]
operator: , [1001,1002]
===
match
---
operator: = [3224,3225]
operator: = [3251,3252]
===
match
---
name: plugins_manager [904,919]
name: plugins_manager [904,919]
===
match
---
param [1270,1282]
param [1270,1282]
===
match
---
name: check_content_in_response [3310,3335]
name: check_content_in_response [3337,3362]
===
match
---
string: "/home" [5248,5255]
string: "/home" [5275,5282]
===
match
---
string: "http://localhost:8080/trigger?dag_id=test&origin=36539%27%3balert(1)%2f%2f166&abc=2" [4619,4704]
string: "http://localhost:8080/trigger?dag_id=test&origin=36539%27%3balert(1)%2f%2f166&abc=2" [4646,4731]
===
match
---
dotted_name [3749,3772]
dotted_name [3776,3799]
===
match
---
comparison [5340,5378]
comparison [5367,5405]
===
match
---
simple_stmt [787,797]
simple_stmt [787,797]
===
match
---
operator: , [5518,5519]
operator: , [5545,5546]
===
match
---
simple_stmt [3365,3407]
simple_stmt [3392,3434]
===
match
---
name: resp [1356,1360]
name: resp [1356,1360]
===
match
---
string: "/taskinstance/list/?_flt_0_execution_date=2018-10-09+22:44:31" [3822,3885]
string: "/taskinstance/list/?_flt_0_execution_date=2018-10-09+22:44:31" [3849,3912]
===
match
---
name: test_configuration_expose_config [1740,1772]
name: test_configuration_expose_config [1740,1772]
===
match
---
with_stmt [5260,5379]
with_stmt [5287,5406]
===
match
---
atom [2430,2523]
atom [2457,2550]
===
match
---
suite [5215,5379]
suite [5242,5406]
===
match
---
name: url [4159,4162]
name: url [4186,4189]
===
match
---
trailer [5352,5362]
trailer [5379,5389]
===
match
---
simple_stmt [3310,3361]
simple_stmt [3337,3388]
===
match
---
arglist [3336,3359]
arglist [3363,3386]
===
match
---
arglist [4406,4419]
arglist [4433,4446]
===
match
---
name: resp [1649,1653]
name: resp [1649,1653]
===
match
---
name: conf_vars [1884,1893]
name: conf_vars [1911,1920]
===
match
---
simple_stmt [2309,2336]
simple_stmt [2336,2363]
===
match
---
string: "source" [3391,3399]
string: "source" [3418,3426]
===
match
---
string: '/plugin' [3600,3609]
string: '/plugin' [3627,3636]
===
match
---
name: mock_plugin [2941,2952]
name: mock_plugin [2968,2979]
===
match
---
parameters [1772,1786]
parameters [1772,1786]
===
match
---
decorated [1663,2097]
decorated [1663,2124]
===
match
---
simple_stmt [2941,2971]
simple_stmt [2968,2998]
===
match
---
atom_expr [1680,1690]
atom_expr [1680,1690]
===
match
---
string: 'redoc' [2246,2253]
string: 'redoc' [2273,2280]
===
match
---
operator: } [3149,3150]
operator: } [3176,3177]
===
match
---
trailer [2968,2970]
trailer [2995,2997]
===
match
---
name: mock [3072,3076]
name: mock [3099,3103]
===
match
---
operator: = [2227,2228]
operator: = [2254,2255]
===
match
---
name: mock_plugin_manager [1114,1133]
name: mock_plugin_manager [1114,1133]
===
match
---
name: test_configuration_do_not_expose_config [1230,1269]
name: test_configuration_do_not_expose_config [1230,1269]
===
match
---
atom_expr [1424,1660]
atom_expr [1424,1660]
===
match
---
name: capture_templates [2180,2197]
name: capture_templates [2207,2224]
===
match
---
parameters [5616,5650]
parameters [5643,5677]
===
match
---
arglist [2765,2779]
arglist [2792,2806]
===
match
---
arglist [4453,5106]
arglist [4480,5133]
===
match
---
operator: , [4991,4992]
operator: , [5018,5019]
===
match
---
parameters [5171,5214]
parameters [5198,5241]
===
match
---
string: "Airflow Plugins" [3336,3353]
string: "Airflow Plugins" [3363,3380]
===
match
---
name: check_content_not_in_response [3638,3667]
name: check_content_not_in_response [3665,3694]
===
match
---
suite [4173,4421]
suite [4200,4448]
===
match
---
trailer [1449,1660]
trailer [1449,1660]
===
match
---
atom [4895,5098]
atom [4922,5125]
===
match
---
expr_stmt [2941,2970]
expr_stmt [2968,2997]
===
match
---
trailer [3023,3030]
trailer [3050,3057]
===
match
---
atom [4083,4109]
atom [4110,4136]
===
match
---
atom [5487,5503]
atom [5514,5530]
===
match
---
name: test_utils [1037,1047]
name: test_utils [1037,1047]
===
match
---
name: mock_plugin_manager [3167,3186]
name: mock_plugin_manager [3194,3213]
===
match
---
operator: , [4725,4726]
operator: , [4752,4753]
===
match
---
atom [1459,1639]
atom [1459,1639]
===
match
---
operator: , [4546,4547]
operator: , [4573,4574]
===
match
---
name: check_content_in_response [3259,3284]
name: check_content_in_response [3286,3311]
===
match
---
string: "http://google.com" [4517,4536]
string: "http://google.com" [4544,4563]
===
match
---
funcdef [2099,2524]
funcdef [2126,2551]
===
match
---
name: mock [1664,1668]
name: mock [1664,1668]
===
match
---
name: follow_redirects [1397,1413]
name: follow_redirects [1397,1413]
===
match
---
testlist_comp [5488,5502]
testlist_comp [5515,5529]
===
match
---
testlist_comp [5461,5575]
testlist_comp [5488,5602]
===
match
---
arglist [2710,2733]
arglist [2737,2760]
===
match
---
operator: , [5199,5200]
operator: , [5226,5227]
===
match
---
operator: , [1907,1908]
operator: , [1934,1935]
===
match
---
simple_stmt [2739,2781]
simple_stmt [2766,2808]
===
match
---
name: check_content_in_response [2684,2709]
name: check_content_in_response [2711,2736]
===
match
---
operator: , [5581,5582]
operator: , [5608,5609]
===
match
---
import_from [1134,1223]
import_from [1134,1223]
===
match
---
number: 0.124 [5497,5502]
number: 0.124 [5524,5529]
===
match
---
name: get [2614,2617]
name: get [2641,2644]
===
match
---
dictorsetmaker [1895,1933]
dictorsetmaker [1922,1960]
===
match
---
name: test_redoc_should_render_template [2103,2136]
name: test_redoc_should_render_template [2130,2163]
===
match
---
decorated [4423,5379]
decorated [4450,5406]
===
match
---
atom [1895,1925]
atom [1922,1952]
===
match
---
assert_stmt [5333,5378]
assert_stmt [5360,5405]
===
match
---
testlist_comp [5514,5524]
testlist_comp [5541,5551]
===
match
---
with_stmt [2175,2304]
with_stmt [2202,2331]
===
match
---
name: admin_client [3226,3238]
name: admin_client [3253,3265]
===
match
---
string: "test_plugin" [3668,3681]
string: "test_plugin" [3695,3708]
===
match
---
operator: = [1413,1414]
operator: = [1413,1414]
===
match
---
name: pytest [831,837]
name: pytest [831,837]
===
match
---
parameters [2921,2935]
parameters [2948,2962]
===
match
---
operator: @ [5109,5110]
operator: @ [5136,5137]
===
match
---
operator: , [5087,5088]
operator: , [5114,5115]
===
match
---
name: app [5265,5268]
name: app [5292,5295]
===
match
---
trailer [3593,3595]
trailer [3620,3622]
===
match
---
trailer [3599,3633]
trailer [3626,3660]
===
match
---
string: '/plugin' [2618,2627]
string: '/plugin' [2645,2654]
===
match
---
testlist_comp [1896,1924]
testlist_comp [1923,1951]
===
match
---
simple_stmt [891,959]
simple_stmt [891,959]
===
match
---
testlist_comp [4557,4594]
testlist_comp [4584,4621]
===
match
---
atom_expr [2347,2364]
atom_expr [2374,2391]
===
match
---
number: 0.12345 [5462,5469]
number: 0.12345 [5489,5496]
===
match
---
operator: == [5363,5365]
operator: == [5390,5392]
===
match
---
expr_stmt [2975,3007]
expr_stmt [3002,3034]
===
match
---
name: test_utils [1083,1093]
name: test_utils [1083,1093]
===
match
---
param [5172,5185]
param [5199,5212]
===
match
---
name: resp [3219,3223]
name: resp [3246,3250]
===
match
---
simple_stmt [1424,1661]
simple_stmt [1424,1661]
===
match
---
name: return_value [5233,5245]
name: return_value [5260,5272]
===
match
---
name: resp [4415,4419]
name: resp [4442,4446]
===
match
---
string: '1.0.0' [3090,3097]
string: '1.0.0' [3117,3124]
===
match
---
testlist_comp [1306,1334]
testlist_comp [1306,1334]
===
match
---
arglist [3719,3744]
arglist [3746,3771]
===
match
---
expr_stmt [1356,1419]
expr_stmt [1356,1419]
===
match
---
name: EntryPointSource [3033,3049]
name: EntryPointSource [3060,3076]
===
match
---
decorator [1663,1736]
decorator [1663,1736]
===
match
---
testlist_comp [4517,4545]
testlist_comp [4544,4572]
===
match
---
string: "/home" [4867,4874]
string: "/home" [4894,4901]
===
match
---
number: 0.12355 [5488,5495]
number: 0.12355 [5515,5522]
===
match
---
string: "airflow.www.views.url_for" [5121,5148]
string: "airflow.www.views.url_for" [5148,5175]
===
match
---
name: len [2316,2319]
name: len [2343,2346]
===
match
---
number: 9.99999 [5536,5543]
number: 9.99999 [5563,5570]
===
match
---
name: get_safe_url [989,1001]
name: get_safe_url [989,1001]
===
match
---
name: resp [3300,3304]
name: resp [3327,3331]
===
match
---
name: conf_vars [1062,1071]
name: conf_vars [1062,1071]
===
match
---
string: 'Running Configuration' [2065,2088]
string: 'Running Configuration' [2092,2115]
===
match
---
name: mock_url_for [5220,5232]
name: mock_url_for [5247,5259]
===
match
---
name: expected_url [5366,5378]
name: expected_url [5393,5405]
===
match
---
operator: = [3576,3577]
operator: = [3603,3604]
===
match
---
suite [2213,2304]
suite [2240,2331]
===
match
---
name: follow_redirects [3611,3627]
name: follow_redirects [3638,3654]
===
match
---
name: mark [3756,3760]
name: mark [3783,3787]
===
match
---
name: tests [1139,1144]
name: tests [1139,1144]
===
match
---
atom_expr [1363,1419]
atom_expr [1363,1419]
===
match
---
string: "instance" [4084,4094]
string: "instance" [4111,4121]
===
match
---
name: test_duration [5686,5699]
name: test_duration [5713,5726]
===
match
---
string: "/home" [4718,4725]
string: "/home" [4745,4752]
===
match
---
argument [3187,3208]
argument [3214,3235]
===
match
---
decorator [5109,5150]
decorator [5136,5177]
===
match
---
import_as_names [1167,1223]
import_as_names [1167,1223]
===
match
---
operator: = [1361,1362]
operator: = [1361,1362]
===
match
---
string: 'Airflow Configuration' [1473,1496]
string: 'Airflow Configuration' [1473,1496]
===
match
---
simple_stmt [3259,3306]
simple_stmt [3286,3333]
===
match
---
trailer [2288,2303]
trailer [2315,2330]
===
match
---
operator: @ [5381,5382]
operator: @ [5408,5409]
===
match
---
atom [5451,5581]
atom [5478,5608]
===
match
---
assert_stmt [2309,2335]
assert_stmt [2336,2362]
===
match
---
name: expected_url [5201,5213]
name: expected_url [5228,5240]
===
match
---
string: "AIRFLOW__CORE__UNIT_TEST_MODE" [1693,1724]
string: "AIRFLOW__CORE__UNIT_TEST_MODE" [1693,1724]
===
match
---
string: "test_plugin" [3285,3298]
string: "test_plugin" [3312,3325]
===
match
---
param [4145,4158]
param [4172,4185]
===
match
---
name: templates [2320,2329]
name: templates [2347,2356]
===
match
---
name: resp [3683,3687]
name: resp [3710,3714]
===
match
---
trailer [3238,3242]
trailer [3265,3269]
===
match
---
name: check_content_in_response [3693,3718]
name: check_content_in_response [3720,3745]
===
match
---
arglist [3437,3502]
arglist [3464,3529]
===
match
---
name: mock_url_for [5172,5184]
name: mock_url_for [5199,5211]
===
match
---
name: check_content_not_in_response [1194,1223]
name: check_content_not_in_response [1194,1223]
===
match
---
atom_expr [1294,1346]
atom_expr [1294,1346]
===
match
---
trailer [3335,3360]
trailer [3362,3387]
===
match
---
param [4159,4163]
param [4186,4190]
===
match
---
string: "reschedule" [4096,4108]
string: "reschedule" [4123,4135]
===
match
---
atom_expr [3638,3688]
atom_expr [3665,3715]
===
match
---
name: environ [1683,1690]
name: environ [1683,1690]
===
match
---
name: mock [3059,3063]
name: mock [3086,3090]
===
match
---
string: "test_plugin" [2994,3007]
string: "test_plugin" [3021,3034]
===
match
---
atom [3108,3150]
atom [3135,3177]
===
match
---
atom_expr [3072,3151]
atom_expr [3099,3178]
===
match
---
operator: , [4853,4854]
operator: , [4880,4881]
===
match
---
atom [4493,4506]
atom [4520,4533]
===
match
---
arglist [5411,5582]
arglist [5438,5609]
===
match
---
name: resp [4178,4182]
name: resp [4205,4209]
===
match
---
trailer [3595,3599]
trailer [3622,3626]
===
match
---
expr_stmt [5220,5255]
expr_stmt [5247,5282]
===
match
---
simple_stmt [2785,2860]
simple_stmt [2812,2887]
===
match
---
atom_expr [2785,2859]
atom_expr [2812,2886]
===
match
---
arglist [3668,3687]
arglist [3695,3714]
===
match
---
atom_expr [2180,2199]
atom_expr [2207,2226]
===
match
---
simple_stmt [3571,3634]
simple_stmt [3598,3661]
===
match
---
atom_expr [2316,2330]
atom_expr [2343,2357]
===
match
---
name: mark [5389,5393]
name: mark [5416,5420]
===
match
---
expr_stmt [3012,3157]
expr_stmt [3039,3184]
===
match
---
atom [2039,2089]
atom [2066,2116]
===
match
---
dotted_name [4424,4447]
dotted_name [4451,4474]
===
match
---
name: get [1376,1379]
name: get [1376,1379]
===
match
---
dictorsetmaker [3109,3149]
dictorsetmaker [3136,3176]
===
match
---
parameters [2574,2588]
parameters [2601,2615]
===
match
---
operator: , [5550,5551]
operator: , [5577,5578]
===
match
---
operator: , [2773,2774]
operator: , [2800,2801]
===
match
---
operator: , [2516,2517]
operator: , [2543,2544]
===
match
---
operator: , [4019,4020]
operator: , [4046,4047]
===
match
---
name: get [2242,2245]
name: get [2269,2272]
===
match
---
import_from [959,1025]
import_from [959,1025]
===
match
---
atom [5513,5525]
atom [5540,5552]
===
match
---
atom [3798,4073]
atom [3825,4100]
===
match
---
trailer [3581,3593]
trailer [3608,3620]
===
match
---
simple_stmt [1072,1134]
simple_stmt [1072,1134]
===
match
---
operator: , [4066,4067]
operator: , [4093,4094]
===
match
---
with_item [2180,2212]
with_item [2207,2239]
===
match
---
name: get [4198,4201]
name: get [4225,4228]
===
match
---
name: initialize_config [873,890]
name: initialize_config [873,890]
===
match
---
name: mock_plugin [2975,2986]
name: mock_plugin [3002,3013]
===
match
---
trailer [2617,2628]
trailer [2644,2655]
===
match
---
atom_expr [4185,4206]
atom_expr [4212,4233]
===
match
---
testlist_comp [2040,2088]
testlist_comp [2067,2115]
===
match
---
suite [2589,2860]
suite [2616,2887]
===
match
---
trailer [4197,4201]
trailer [4224,4228]
===
match
---
operator: , [2852,2853]
operator: , [2879,2880]
===
match
---
atom_expr [2633,2679]
atom_expr [2660,2706]
===
match
---
trailer [5232,5245]
trailer [5259,5272]
===
match
---
string: 'airflow/redoc.html' [2368,2388]
string: 'airflow/redoc.html' [2395,2415]
===
match
---
param [4164,4171]
param [4191,4198]
===
match
---
name: unittest [802,810]
name: unittest [802,810]
===
match
---
trailer [2241,2245]
trailer [2268,2272]
===
match
---
operator: , [3885,3886]
operator: , [3912,3913]
===
match
---
name: capture_templates [2137,2154]
name: capture_templates [2164,2181]
===
match
---
name: test_plugin_should_list_entrypoint_on_page_with_details [2866,2921]
name: test_plugin_should_list_entrypoint_on_page_with_details [2893,2948]
===
match
---
atom [3940,4066]
atom [3967,4093]
===
match
---
simple_stmt [797,823]
simple_stmt [797,823]
===
match
---
atom [4746,4885]
atom [4773,4912]
===
match
---
name: get_safe_url [5340,5352]
name: get_safe_url [5367,5379]
===
match
---
trailer [1379,1419]
trailer [1379,1419]
===
match
---
string: "test_duration, expected_duration" [5411,5445]
string: "test_duration, expected_duration" [5438,5472]
===
match
---
comparison [5663,5721]
comparison [5690,5748]
===
match
---
simple_stmt [2340,2389]
simple_stmt [2367,2416]
===
match
---
testlist_comp [5536,5549]
testlist_comp [5563,5576]
===
match
---
argument [3099,3150]
argument [3126,3177]
===
match
---
trailer [1893,1935]
trailer [1920,1962]
===
match
---
comparison [2347,2388]
comparison [2374,2415]
===
match
---
name: check_content_in_response [2785,2810]
name: check_content_in_response [2812,2837]
===
match
---
atom [5461,5477]
atom [5488,5504]
===
match
---
name: check_content_in_response [1167,1192]
name: check_content_in_response [1167,1192]
===
match
---
name: configuration [852,865]
name: configuration [852,865]
===
match
---
suite [2170,2524]
suite [2197,2551]
===
match
---
atom [5560,5574]
atom [5587,5601]
===
match
---
name: admin_client [1363,1375]
name: admin_client [1363,1375]
===
match
---
simple_stmt [1945,2009]
simple_stmt [1972,2036]
===
match
---
expr_stmt [3219,3253]
expr_stmt [3246,3280]
===
match
---
atom_expr [5265,5323]
atom_expr [5292,5350]
===
match
---
atom_expr [3059,3070]
atom_expr [3086,3097]
===
match
---
name: Mock [3064,3068]
name: Mock [3091,3095]
===
match
---
expr_stmt [1945,2008]
expr_stmt [1972,2035]
===
match
---
atom_expr [2739,2780]
atom_expr [2766,2807]
===
match
---
trailer [1682,1690]
trailer [1682,1690]
===
match
---
trailer [2764,2780]
trailer [2791,2807]
===
match
---
atom_expr [2263,2303]
atom_expr [2290,2330]
===
match
---
dotted_name [1664,1679]
dotted_name [1664,1679]
===
match
---
import_from [797,822]
import_from [797,822]
===
match
---
number: 0.123 [5471,5476]
number: 0.123 [5498,5503]
===
match
---
suite [1936,2009]
suite [1963,2036]
===
match
---
operator: , [3919,3920]
operator: , [3946,3947]
===
match
---
trailer [5289,5323]
trailer [5316,5350]
===
match
---
operator: = [2599,2600]
operator: = [2626,2627]
===
match
---
suite [5651,5722]
suite [5678,5749]
===
match
---
atom_expr [1884,1935]
atom_expr [1911,1962]
===
match
---
name: Mock [3077,3081]
name: Mock [3104,3108]
===
match
---
string: "http://localhost:8080" [5299,5322]
string: "http://localhost:8080" [5326,5349]
===
match
---
simple_stmt [2393,2524]
simple_stmt [2420,2551]
===
match
---
testlist_comp [3822,3920]
testlist_comp [3849,3947]
===
match
---
string: "http://localhost:8080/trigger?dag_id=test_dag&origin=%2Ftree%3Fdag_id%test_dag';alert(33)//" [4760,4853]
string: "http://localhost:8080/trigger?dag_id=test_dag&origin=%2Ftree%3Fdag_id%test_dag';alert(33)//" [4787,4880]
===
match
---
name: admin_client [2575,2587]
name: admin_client [2602,2614]
===
match
---
atom [4556,4595]
atom [4583,4622]
===
match
---
operator: , [5495,5496]
operator: , [5522,5523]
===
match
---
funcdef [1736,2097]
funcdef [1736,2124]
===
match
---
trailer [2245,2254]
trailer [2272,2281]
===
match
---
simple_stmt [1855,1875]
simple_stmt [1855,1882]
===
match
---
name: resp [3355,3359]
name: resp [3382,3386]
===
match
---
name: app [3561,3564]
name: app [3588,3591]
===
match
---
operator: , [1395,1396]
operator: , [1395,1396]
===
match
---
operator: , [4885,4886]
operator: , [4912,4913]
===
match
---
name: test_task_start_date_filter [4117,4144]
name: test_task_start_date_filter [4144,4171]
===
match
---
simple_stmt [2263,2304]
simple_stmt [2290,2331]
===
match
---
arglist [2039,2095]
arglist [2066,2122]
===
match
---
trailer [3081,3151]
trailer [3108,3178]
===
match
---
name: test_utils [1145,1155]
name: test_utils [1145,1155]
===
match
---
name: templates [2203,2212]
name: templates [2230,2239]
===
match
---
string: "<em>test-entrypoint-testpluginview==1.0.0:</em> <Mock id=" [3437,3496]
string: "<em>test-entrypoint-testpluginview==1.0.0:</em> <Mock id=" [3464,3523]
===
match
---
name: admin_client [4145,4157]
name: admin_client [4172,4184]
===
match
---
suite [3210,3254]
suite [3237,3281]
===
match
---
funcdef [2526,2860]
funcdef [2553,2887]
===
match
---
operator: , [5189,5190]
operator: , [5216,5217]
===
match
---
operator: = [5298,5299]
operator: = [5325,5326]
===
match
---
atom_expr [1855,1874]
atom_expr [1862,1881]
===
match
---
import_from [839,890]
import_from [839,890]
===
match
---
operator: , [2727,2728]
operator: , [2754,2755]
===
match
---
simple_stmt [5333,5379]
simple_stmt [5360,5406]
===
match
---
operator: , [2089,2090]
operator: , [2116,2117]
===
match
---
operator: , [5574,5575]
operator: , [5601,5602]
===
match
---
parameters [1269,1283]
parameters [1269,1283]
===
match
---
decorated [3748,4421]
decorated [3775,4448]
===
match
---
name: airflow [896,903]
name: airflow [896,903]
===
match
---
operator: , [1628,1629]
operator: , [1628,1629]
===
match
---
name: resp [2091,2095]
name: resp [2118,2122]
===
match
---
number: 10.0 [5545,5549]
number: 10.0 [5572,5576]
===
match
---
name: test_truncate_task_duration [5589,5616]
name: test_truncate_task_duration [5616,5643]
===
match
---
atom_expr [2684,2734]
atom_expr [2711,2761]
===
match
---
dotted_name [5110,5120]
dotted_name [5137,5147]
===
match
---
assert_stmt [2393,2523]
assert_stmt [2420,2550]
===
match
---
name: resp [3740,3744]
name: resp [3767,3771]
===
match
---
trailer [3242,3253]
trailer [3269,3280]
===
match
---
param [5632,5649]
param [5659,5676]
===
match
---
atom_expr [3310,3360]
atom_expr [3337,3387]
===
match
---
string: '/api/v1/openapi.yaml' [2460,2482]
string: '/api/v1/openapi.yaml' [2487,2509]
===
match
---
string: 'False' [1337,1344]
string: 'False' [1337,1344]
===
match
---
operator: = [3107,3108]
operator: = [3134,3135]
===
match
---
funcdef [5150,5379]
funcdef [5177,5406]
===
match
---
trailer [3063,3068]
trailer [3090,3095]
===
match
---
name: test_url [5191,5199]
name: test_url [5218,5226]
===
match
---
simple_stmt [2013,2097]
simple_stmt [2040,2124]
===
match
---
string: 'configuration' [1969,1984]
string: 'configuration' [1996,2011]
===
match
---
funcdef [3506,3746]
funcdef [3533,3773]
===
match
---
name: resp [2298,2302]
name: resp [2325,2329]
===
match
---
name: local_context [2413,2426]
name: local_context [2440,2453]
===
match
---
atom_expr [5220,5245]
atom_expr [5247,5272]
===
match
---
comparison [2316,2335]
comparison [2343,2362]
===
match
---
dotted_name [5382,5405]
dotted_name [5409,5432]
===
match
---
param [5191,5200]
param [5218,5227]
===
match
---
number: 0 [2357,2358]
number: 0 [2384,2385]
===
match
---
atom [1692,1734]
atom [1692,1734]
===
match
---
name: admin_client [1952,1964]
name: admin_client [1979,1991]
===
match
---
name: expected_duration [5632,5649]
name: expected_duration [5659,5676]
===
match
---
operator: , [4506,4507]
operator: , [4533,4534]
===
match
---
operator: , [5445,5446]
operator: , [5472,5473]
===
match
---
name: test_get_safe_url [5154,5171]
name: test_get_safe_url [5181,5198]
===
match
---
simple_stmt [5220,5256]
simple_stmt [5247,5283]
===
match
---
string: 'webserver' [1306,1317]
string: 'webserver' [1306,1317]
===
match
---
name: config [1048,1054]
name: config [1048,1054]
===
match
---
atom [1304,1345]
atom [1304,1345]
===
match
---
arglist [1380,1418]
arglist [1380,1418]
===
match
---
suite [2936,3504]
suite [2963,3531]
===
match
---
simple_stmt [839,891]
simple_stmt [839,891]
===
match
---
operator: == [2331,2333]
operator: == [2358,2360]
===
match
---
testlist_comp [1473,1629]
testlist_comp [1473,1629]
===
match
---
operator: , [3070,3071]
operator: , [3097,3098]
===
match
---
name: plugins [3187,3194]
name: plugins [3214,3221]
===
match
---
name: airflow [844,851]
name: airflow [844,851]
===
match
---
trailer [3390,3406]
trailer [3417,3433]
===
match
---
operator: , [2296,2297]
operator: , [2323,2324]
===
match
---
atom_expr [4380,4420]
atom_expr [4407,4447]
===
match
---
atom_expr [3167,3209]
atom_expr [3194,3236]
===
match
---
string: "test_plugin" [2659,2672]
string: "test_plugin" [2686,2699]
===
match
---
operator: , [4055,4056]
operator: , [4082,4083]
===
match
---
arglist [1680,1734]
arglist [1680,1734]
===
match
---
operator: , [2482,2483]
operator: , [2509,2510]
===
match
---
testlist_comp [3808,4067]
testlist_comp [3835,4094]
===
match
---
name: follow_redirects [1986,2002]
name: follow_redirects [2013,2029]
===
match
---
operator: , [1653,1654]
operator: , [1653,1654]
===
match
---
operator: = [2002,2003]
operator: = [2029,2030]
===
match
---
testlist_comp [3954,4056]
testlist_comp [3981,4083]
===
match
---
name: resp [3571,3575]
name: resp [3598,3602]
===
match
---
arglist [3600,3632]
arglist [3627,3659]
===
match
---
arglist [2811,2858]
arglist [2838,2885]
===
match
---
param [2137,2155]
param [2164,2182]
===
match
---
assert_stmt [2340,2388]
assert_stmt [2367,2415]
===
match
---
dictorsetmaker [2440,2517]
dictorsetmaker [2467,2544]
===
match
---
atom_expr [2955,2970]
atom_expr [2982,2997]
===
match
---
with_stmt [3162,3254]
with_stmt [3189,3281]
===
match
---
string: '/plugin' [3243,3252]
string: '/plugin' [3270,3279]
===
match
---
operator: , [2154,2155]
operator: , [2181,2182]
===
match
---
name: name [2987,2991]
name: name [3014,3018]
===
match
---
name: test_request_context [5269,5289]
name: test_request_context [5296,5316]
===
match
---
name: conf_vars [1294,1303]
name: conf_vars [1294,1303]
===
match
---
suite [1787,2097]
suite [1787,2124]
===
match
---
operator: , [4736,4737]
operator: , [4763,4764]
===
match
---
operator: , [5503,5504]
operator: , [5530,5531]
===
match
---
name: admin_client [1270,1282]
name: admin_client [1270,1282]
===
match
---
import_name [824,837]
import_name [824,837]
===
match
---
string: 'name' [3109,3115]
string: 'name' [3136,3142]
===
match
---
operator: , [4109,4110]
operator: , [4136,4137]
===
match
---
string: "False" [1726,1733]
string: "False" [1726,1733]
===
match
---
name: www [1156,1159]
name: www [1156,1159]
===
match
---
name: admin_client [2156,2168]
name: admin_client [2183,2195]
===
match
---
file_input [787,5722]
file_input [787,5749]
===
match
---
import_from [891,958]
import_from [891,958]
===
match
---
simple_stmt [4178,4207]
simple_stmt [4205,4234]
===
match
---
operator: = [3089,3090]
operator: = [3116,3117]
===
match
---
atom_expr [2601,2628]
atom_expr [2628,2655]
===
match
---
param [1773,1785]
param [1773,1785]
===
match
---
name: metadata [3099,3107]
name: metadata [3126,3134]
===
match
---
name: resp [2854,2858]
name: resp [2881,2885]
===
match
---
name: test_client [3582,3593]
name: test_client [3609,3620]
===
match
---
trailer [3076,3081]
trailer [3103,3108]
===
match
---
trailer [1968,2008]
trailer [1995,2035]
===
match
---
name: resp [2222,2226]
name: resp [2249,2253]
===
match
---
atom [1894,1934]
atom [1921,1961]
===
insert-tree
---
simple_stmt [1886,1902]
    atom_expr [1886,1901]
        name: conf [1886,1890]
        trailer [1890,1899]
            name: validate [1891,1899]
        trailer [1899,1901]
to
suite [1787,2097]
at 1
===
insert-node
---
expr_stmt [1855,1881]
to
simple_stmt [1855,1875]
at 0
===
move-tree
---
atom_expr [1855,1874]
    name: initialize_config [1855,1872]
    trailer [1872,1874]
to
expr_stmt [1855,1881]
at 2
