===
match
---
name: logging [1514,1521]
name: logging [1514,1521]
===
match
---
string: 'AIRFLOW_HOME' [31980,31994]
string: 'AIRFLOW_HOME' [31980,31994]
===
match
---
name: int [19143,19146]
name: int [19143,19146]
===
match
---
testlist_comp [5197,5233]
testlist_comp [5197,5233]
===
match
---
comp_op [18337,18343]
comp_op [18337,18343]
===
match
---
operator: , [5312,5313]
operator: , [5312,5313]
===
match
---
trailer [15266,15295]
trailer [15266,15295]
===
match
---
name: self [21599,21603]
name: self [21599,21603]
===
match
---
operator: , [28458,28459]
operator: , [28458,28459]
===
match
---
string: 'core' [5369,5375]
string: 'core' [5369,5375]
===
match
---
name: config_sources [26067,26081]
name: config_sources [26067,26081]
===
match
---
operator: , [29569,29570]
operator: , [29569,29570]
===
match
---
name: self [12240,12244]
name: self [12240,12244]
===
match
---
name: environ [13768,13775]
name: environ [13768,13775]
===
match
---
arglist [15952,15964]
arglist [15952,15964]
===
match
---
name: AIRFLOW_CONFIG [34827,34841]
name: AIRFLOW_CONFIG [34827,34841]
===
match
---
argument [41339,41352]
argument [41317,41330]
===
match
---
expr_stmt [4572,7509]
expr_stmt [4572,7509]
===
match
---
operator: , [24094,24095]
operator: , [24094,24095]
===
match
---
suite [11401,11845]
suite [11401,11845]
===
match
---
import_from [1109,1185]
import_from [1109,1185]
===
match
---
name: args [37446,37450]
name: args [37424,37428]
===
match
---
name: sys [44429,44432]
name: sys [44423,44426]
===
match
---
name: section [29631,29638]
name: section [29631,29638]
===
match
---
trailer [20739,20777]
trailer [20739,20777]
===
match
---
name: super [17609,17614]
name: super [17609,17614]
===
match
---
name: AirflowConfigException [10084,10106]
name: AirflowConfigException [10084,10106]
===
match
---
trailer [10152,10172]
trailer [10152,10172]
===
match
---
name: section [18938,18945]
name: section [18938,18945]
===
match
---
trailer [41960,41962]
trailer [41938,41940]
===
match
---
operator: = [23958,23959]
operator: = [23958,23959]
===
match
---
name: display_sensitive [27111,27128]
name: display_sensitive [27111,27128]
===
match
---
atom_expr [10505,10527]
atom_expr [10505,10527]
===
match
---
name: section [12179,12186]
name: section [12179,12186]
===
match
---
operator: , [17167,17168]
operator: , [17167,17168]
===
match
---
funcdef [29390,29748]
funcdef [29390,29748]
===
match
---
trailer [22739,22745]
trailer [22739,22745]
===
match
---
name: section [26649,26656]
name: section [26649,26656]
===
match
---
argument [40750,40755]
argument [40728,40733]
===
match
---
name: all_vars [33012,33020]
name: all_vars [33012,33020]
===
match
---
operator: = [14898,14899]
operator: = [14898,14899]
===
match
---
arglist [16670,16718]
arglist [16670,16718]
===
match
---
if_stmt [26675,27062]
if_stmt [26675,27062]
===
match
---
operator: , [15151,15152]
operator: , [15151,15152]
===
match
---
name: __name__ [1532,1540]
name: __name__ [1532,1540]
===
match
---
expr_stmt [22430,22478]
expr_stmt [22430,22478]
===
match
---
name: Dict [21786,21790]
name: Dict [21786,21790]
===
match
---
trailer [10910,10914]
trailer [10910,10914]
===
match
---
atom_expr [22509,22526]
atom_expr [22509,22526]
===
match
---
comparison [28093,28104]
comparison [28093,28104]
===
match
---
name: Optional [21777,21785]
name: Optional [21777,21785]
===
match
---
operator: * [8587,8588]
operator: * [8587,8588]
===
match
---
operator: = [14706,14707]
operator: = [14706,14707]
===
match
---
name: ConfigParser [3519,3531]
name: ConfigParser [3519,3531]
===
match
---
atom_expr [9189,9258]
atom_expr [9189,9258]
===
match
---
trailer [13158,13172]
trailer [13158,13172]
===
match
---
trailer [23812,23870]
trailer [23812,23870]
===
match
---
name: remove_option [21703,21716]
name: remove_option [21703,21716]
===
match
---
name: opt [27491,27494]
name: opt [27491,27494]
===
match
---
trailer [20729,20739]
trailer [20729,20739]
===
match
---
fstring_end: ' [19000,19001]
fstring_end: ' [19000,19001]
===
match
---
trailer [10847,10874]
trailer [10847,10874]
===
match
---
simple_stmt [16541,16610]
simple_stmt [16541,16610]
===
match
---
name: display_source [26525,26539]
name: display_source [26525,26539]
===
match
---
simple_stmt [7669,8165]
simple_stmt [7669,8165]
===
match
---
string: '_sections' [31798,31809]
string: '_sections' [31798,31809]
===
match
---
name: conf [20104,20108]
name: conf [20104,20108]
===
match
---
name: secrets_client [2956,2970]
name: secrets_client [2956,2970]
===
match
---
atom_expr [42798,42867]
atom_expr [42776,42845]
===
match
---
param [30477,30481]
param [30477,30481]
===
match
---
name: deprecated_section [15631,15649]
name: deprecated_section [15631,15649]
===
match
---
suite [18628,18673]
suite [18628,18673]
===
match
---
fstring_string: " key in " [19290,19300]
fstring_string: " key in " [19290,19300]
===
match
---
atom_expr [22387,22419]
atom_expr [22387,22419]
===
match
---
string: 'logging' [4681,4690]
string: 'logging' [4681,4690]
===
match
---
suite [14047,14370]
suite [14047,14370]
===
match
---
trailer [22258,22267]
trailer [22258,22267]
===
match
---
name: items [29617,29622]
name: items [29617,29622]
===
match
---
operator: = [22217,22218]
operator: = [22217,22218]
===
match
---
name: dict [3251,3255]
name: dict [3251,3255]
===
match
---
trailer [23150,23156]
trailer [23150,23156]
===
match
---
string: "deprecated. Please access the configuration from the 'configuration.conf' object via " [39291,39378]
string: "deprecated. Please access the configuration from the 'configuration.conf' object via " [39269,39356]
===
match
---
param [17340,17347]
param [17340,17347]
===
match
---
return_stmt [20197,20208]
return_stmt [20197,20208]
===
match
---
name: replace [22610,22617]
name: replace [22610,22617]
===
match
---
name: secrets_backend_list [41052,41072]
name: secrets_backend_list [41030,41050]
===
match
---
string: 'default_test.cfg' [42507,42525]
string: 'default_test.cfg' [42485,42503]
===
match
---
atom [14571,14585]
atom [14571,14585]
===
match
---
operator: ** [40369,40371]
operator: ** [40347,40349]
===
match
---
name: display_sensitive [26388,26405]
name: display_sensitive [26388,26405]
===
match
---
operator: , [17346,17347]
operator: , [17346,17347]
===
match
---
name: warning [28126,28133]
name: warning [28126,28133]
===
match
---
name: decode [2475,2481]
name: decode [2475,2481]
===
match
---
string: 'celery' [7166,7174]
string: 'celery' [7166,7174]
===
match
---
testlist_comp [25770,25802]
testlist_comp [25770,25802]
===
match
---
name: shlex [895,900]
name: shlex [895,900]
===
match
---
atom_expr [17692,17746]
atom_expr [17692,17746]
===
match
---
argument [43069,43081]
argument [43047,43059]
===
match
---
name: warning [16107,16114]
name: warning [16107,16114]
===
match
---
name: interpolated [2060,2072]
name: interpolated [2060,2072]
===
match
---
operator: = [42310,42311]
operator: = [42288,42289]
===
match
---
atom_expr [22780,22818]
atom_expr [22780,22818]
===
match
---
atom_expr [33920,34004]
atom_expr [33920,34004]
===
match
---
suite [26176,26268]
suite [26176,26268]
===
match
---
expr_stmt [2060,2127]
expr_stmt [2060,2127]
===
match
---
simple_stmt [32555,32564]
simple_stmt [32555,32564]
===
match
---
name: key [22832,22835]
name: key [22832,22835]
===
match
---
name: DeprecationWarning [36965,36983]
name: DeprecationWarning [36943,36961]
===
match
---
name: e [20307,20308]
name: e [20307,20308]
===
match
---
name: self [20678,20682]
name: self [20678,20682]
===
match
---
name: warn [42941,42945]
name: warn [42919,42923]
===
match
---
name: kwargs [39968,39974]
name: kwargs [39946,39952]
===
match
---
expr_stmt [11486,11564]
expr_stmt [11486,11564]
===
match
---
import_from [10237,10280]
import_from [10237,10280]
===
match
---
subscriptlist [25721,25729]
subscriptlist [25721,25729]
===
match
---
simple_stmt [11094,11334]
simple_stmt [11094,11334]
===
match
---
atom_expr [42932,43092]
atom_expr [42910,43070]
===
match
---
expr_stmt [32309,32400]
expr_stmt [32309,32400]
===
match
---
name: DeprecationWarning [40263,40281]
name: DeprecationWarning [40241,40259]
===
match
---
atom_expr [9137,9168]
atom_expr [9137,9168]
===
match
---
trailer [43870,43875]
trailer [43848,43853]
===
match
---
name: key [18923,18926]
name: key [18923,18926]
===
match
---
name: name [9022,9026]
name: name [9022,9026]
===
match
---
atom_expr [31544,31563]
atom_expr [31544,31563]
===
match
---
operator: , [6844,6845]
operator: , [6844,6845]
===
match
---
operator: , [18577,18578]
operator: , [18577,18578]
===
match
---
string: '# ----------------------- TEMPLATE BEGINS HERE -----------------------\n' [32326,32400]
string: '# ----------------------- TEMPLATE BEGINS HERE -----------------------\n' [32326,32400]
===
match
---
fstring_end: " [2703,2704]
fstring_end: " [2703,2704]
===
match
---
trailer [14593,14617]
trailer [14593,14617]
===
match
---
name: OrderedDict [28944,28955]
name: OrderedDict [28944,28955]
===
match
---
name: env_var [2117,2124]
name: env_var [2117,2124]
===
match
---
trailer [32159,32188]
trailer [32159,32188]
===
match
---
trailer [18664,18670]
trailer [18664,18670]
===
match
---
simple_stmt [33548,33580]
simple_stmt [33548,33580]
===
match
---
string: 'metrics' [6758,6767]
string: 'metrics' [6758,6767]
===
match
---
operator: , [21805,21806]
operator: , [21805,21806]
===
match
---
string: """Historical getboolean""" [37481,37508]
string: """Historical getboolean""" [37459,37486]
===
match
---
atom_expr [9062,9103]
atom_expr [9062,9103]
===
match
---
name: fallback [41520,41528]
name: fallback [41498,41506]
===
match
---
string: 'core' [5197,5203]
string: 'core' [5197,5203]
===
match
---
operator: = [41901,41902]
operator: = [41879,41880]
===
match
---
name: _env_var_name [13159,13172]
name: _env_var_name [13159,13172]
===
match
---
trailer [34596,34625]
trailer [34596,34625]
===
match
---
arglist [10848,10873]
arglist [10848,10873]
===
match
---
arglist [18131,18143]
arglist [18131,18143]
===
match
---
operator: , [19780,19781]
operator: , [19780,19781]
===
match
---
operator: , [30500,30501]
operator: , [30500,30501]
===
match
---
string: 'utf-8' [44215,44222]
string: 'utf-8' [44193,44200]
===
match
---
name: kwargs [19789,19795]
name: kwargs [19789,19795]
===
match
---
simple_stmt [23661,23742]
simple_stmt [23661,23742]
===
match
---
name: os [3181,3183]
name: os [3181,3183]
===
match
---
operator: , [5630,5631]
operator: , [5630,5631]
===
match
---
name: full_qualified_path [20256,20275]
name: full_qualified_path [20256,20275]
===
match
---
name: sqlite3 [10505,10512]
name: sqlite3 [10505,10512]
===
match
---
trailer [17138,17154]
trailer [17138,17154]
===
match
---
string: '0' [18770,18773]
string: '0' [18770,18773]
===
match
---
atom_expr [33673,33723]
atom_expr [33673,33723]
===
match
---
operator: , [20569,20570]
operator: , [20569,20570]
===
match
---
name: collections [980,991]
name: collections [980,991]
===
match
---
name: key [17164,17167]
name: key [17164,17167]
===
match
---
string: '#' [18617,18620]
string: '#' [18617,18620]
===
match
---
param [23285,23290]
param [23285,23290]
===
match
---
simple_stmt [830,853]
simple_stmt [830,853]
===
match
---
atom_expr [14329,14349]
atom_expr [14329,14349]
===
match
---
testlist_comp [4759,4786]
testlist_comp [4759,4786]
===
match
---
name: section [18565,18572]
name: section [18565,18572]
===
match
---
trailer [13579,13592]
trailer [13579,13592]
===
match
---
name: space_around_delimiters [23488,23511]
name: space_around_delimiters [23488,23511]
===
match
---
name: config_sources [29456,29470]
name: config_sources [29456,29470]
===
match
---
argument [31452,31464]
argument [31452,31464]
===
match
---
operator: , [40253,40254]
operator: , [40231,40232]
===
match
---
funcdef [20556,20659]
funcdef [20556,20659]
===
match
---
trailer [43654,43661]
trailer [43632,43639]
===
match
---
name: section [27558,27565]
name: section [27558,27565]
===
match
---
trailer [23637,23647]
trailer [23637,23647]
===
match
---
expr_stmt [43686,43722]
expr_stmt [43664,43700]
===
match
---
simple_stmt [11486,11565]
simple_stmt [11486,11565]
===
match
---
operator: ** [19465,19467]
operator: ** [19465,19467]
===
match
---
name: functools [42416,42425]
name: functools [42394,42403]
===
match
---
simple_stmt [33920,34005]
simple_stmt [33920,34005]
===
match
---
param [29042,29057]
param [29042,29057]
===
match
---
operator: , [37776,37777]
operator: , [37754,37755]
===
match
---
atom_expr [15585,15664]
atom_expr [15585,15664]
===
match
---
name: self [28253,28257]
name: self [28253,28257]
===
match
---
atom_expr [16010,16075]
atom_expr [16010,16075]
===
match
---
name: airflow_defaults [22157,22173]
name: airflow_defaults [22157,22173]
===
match
---
atom_expr [11346,11400]
atom_expr [11346,11400]
===
match
---
operator: { [23540,23541]
operator: { [23540,23541]
===
match
---
operator: , [17333,17334]
operator: , [17333,17334]
===
match
---
name: self [17293,17297]
name: self [17293,17297]
===
match
---
if_stmt [14199,14350]
if_stmt [14199,14350]
===
match
---
name: _get_option_from_commands [15434,15459]
name: _get_option_from_commands [15434,15459]
===
match
---
atom_expr [36452,36508]
atom_expr [36452,36508]
===
match
---
parameters [14850,14880]
parameters [14850,14880]
===
match
---
operator: = [43750,43751]
operator: = [43728,43729]
===
match
---
string: 'log_format' [5632,5644]
string: 'log_format' [5632,5644]
===
match
---
atom_expr [11795,11823]
atom_expr [11795,11823]
===
match
---
name: _DEFAULT_CONFIG [42282,42297]
name: _DEFAULT_CONFIG [42260,42275]
===
match
---
string: 'logging' [4919,4928]
string: 'logging' [4919,4928]
===
match
---
name: section [31372,31379]
name: section [31372,31379]
===
match
---
suite [18775,18801]
suite [18775,18801]
===
match
---
suite [8764,9579]
suite [8764,9579]
===
match
---
name: option [15521,15527]
name: option [15521,15527]
===
match
---
operator: } [19677,19678]
operator: } [19677,19678]
===
match
---
name: deprecated_section [16509,16527]
name: deprecated_section [16509,16527]
===
match
---
atom_expr [23147,23158]
atom_expr [23147,23158]
===
match
---
trailer [34402,34418]
trailer [34402,34418]
===
match
---
operator: , [39406,39407]
operator: , [39384,39385]
===
match
---
trailer [30587,30961]
trailer [30587,30961]
===
match
---
name: append [42186,42192]
name: append [42164,42170]
===
match
---
name: val [19357,19360]
name: val [19357,19360]
===
match
---
simple_stmt [1291,1345]
simple_stmt [1291,1345]
===
match
---
operator: , [26116,26117]
operator: , [26116,26117]
===
match
---
trailer [33246,33254]
trailer [33246,33254]
===
match
---
expr_stmt [31779,31810]
expr_stmt [31779,31810]
===
match
---
trailer [38757,38762]
trailer [38735,38740]
===
match
---
string: 'task_log_reader' [6217,6234]
string: 'task_log_reader' [6217,6234]
===
match
---
name: conf [40322,40326]
name: conf [40300,40304]
===
match
---
simple_stmt [9633,9780]
simple_stmt [9633,9780]
===
match
---
param [19773,19781]
param [19773,19781]
===
match
---
name: key [18030,18033]
name: key [18030,18033]
===
match
---
with_item [42370,42386]
with_item [42348,42364]
===
match
---
fstring_string: section/key [ [16216,16229]
fstring_string: section/key [ [16216,16229]
===
match
---
name: airflow_defaults [22077,22093]
name: airflow_defaults [22077,22093]
===
match
---
string: 'airflow_defaults' [31667,31685]
string: 'airflow_defaults' [31667,31685]
===
match
---
import_name [36333,36346]
import_name [36333,36346]
===
match
---
name: get_airflow_test_config [44130,44153]
name: get_airflow_test_config [44108,44131]
===
match
---
name: key [30821,30824]
name: key [30821,30824]
===
match
---
suite [2163,2196]
suite [2163,2196]
===
match
---
arglist [38362,38617]
arglist [38340,38595]
===
match
---
expr_stmt [43350,43383]
expr_stmt [43328,43361]
===
match
---
fstring_expr [19285,19290]
fstring_expr [19285,19290]
===
match
---
name: realpath [43604,43612]
name: realpath [43582,43590]
===
match
---
atom_expr [13154,13186]
atom_expr [13154,13186]
===
match
---
return_stmt [26436,26457]
return_stmt [26436,26457]
===
match
---
operator: != [2582,2584]
operator: != [2582,2584]
===
match
---
expr_stmt [44111,44167]
expr_stmt [44089,44145]
===
match
---
name: val [22982,22985]
name: val [22982,22985]
===
match
---
atom_expr [22844,22860]
atom_expr [22844,22860]
===
match
---
name: self [8714,8718]
name: self [8714,8718]
===
match
---
trailer [13003,13005]
trailer [13003,13005]
===
match
---
param [13043,13051]
param [13043,13051]
===
match
---
operator: = [30820,30821]
operator: = [30820,30821]
===
match
---
operator: , [7201,7202]
operator: , [7201,7202]
===
match
---
testlist_comp [4232,4255]
testlist_comp [4232,4255]
===
match
---
atom [4055,4077]
atom [4055,4077]
===
match
---
name: IGNORECASE [7868,7878]
name: IGNORECASE [7868,7878]
===
match
---
suite [8498,8740]
suite [8498,8740]
===
match
---
fstring_string: Current value: " [18977,18993]
fstring_string: Current value: " [18977,18993]
===
match
---
atom_expr [15738,15798]
atom_expr [15738,15798]
===
match
---
try_stmt [22874,23214]
try_stmt [22874,23214]
===
match
---
name: stacklevel [39878,39888]
name: stacklevel [39856,39866]
===
match
---
name: AirflowConfigException [16191,16213]
name: AirflowConfigException [16191,16213]
===
match
---
name: Popen [2340,2345]
name: Popen [2340,2345]
===
match
---
argument [37418,37426]
argument [37396,37404]
===
match
---
simple_stmt [14890,14921]
simple_stmt [14890,14921]
===
match
---
suite [3256,3491]
suite [3256,3491]
===
match
---
simple_stmt [4572,7510]
simple_stmt [4572,7510]
===
match
---
operator: , [10921,10922]
operator: , [10921,10922]
===
match
---
trailer [18650,18656]
trailer [18650,18656]
===
match
---
trailer [29177,29179]
trailer [29177,29179]
===
match
---
return_stmt [16758,16769]
return_stmt [16758,16769]
===
match
---
trailer [35796,35820]
trailer [35796,35820]
===
match
---
suite [18044,18487]
suite [18044,18487]
===
match
---
trailer [32645,32687]
trailer [32645,32687]
===
match
---
trailer [22993,22998]
trailer [22993,22998]
===
match
---
name: version [9506,9513]
name: version [9506,9513]
===
match
---
operator: , [21724,21725]
operator: , [21724,21725]
===
match
---
name: kwargs [19054,19060]
name: kwargs [19054,19060]
===
match
---
name: getdefaultencoding [2486,2504]
name: getdefaultencoding [2486,2504]
===
match
---
for_stmt [29594,29748]
for_stmt [29594,29748]
===
match
---
name: process [2563,2570]
name: process [2563,2570]
===
match
---
trailer [1632,1697]
trailer [1632,1697]
===
match
---
return_stmt [2996,3040]
return_stmt [2996,3040]
===
match
---
string: 'logging' [5419,5428]
string: 'logging' [5419,5428]
===
match
---
simple_stmt [14427,14478]
simple_stmt [14427,14478]
===
match
---
simple_stmt [29197,29367]
simple_stmt [29197,29367]
===
match
---
fstring_expr [11794,11824]
fstring_expr [11794,11824]
===
match
---
trailer [23856,23858]
trailer [23856,23858]
===
match
---
name: opt [27977,27980]
name: opt [27977,27980]
===
match
---
suite [29680,29722]
suite [29680,29722]
===
match
---
name: config_file [3435,3446]
name: config_file [3435,3446]
===
match
---
comparison [9825,9935]
comparison [9825,9935]
===
match
---
string: 'w' [34722,34725]
string: 'w' [34722,34725]
===
match
---
name: warn [40033,40037]
name: warn [40011,40015]
===
match
---
string: 'AIRFLOW_CONFIG' [32226,32242]
string: 'AIRFLOW_CONFIG' [32226,32242]
===
match
---
arglist [14221,14242]
arglist [14221,14242]
===
match
---
simple_stmt [19071,19110]
simple_stmt [19071,19110]
===
match
---
name: warnings [937,945]
name: warnings [937,945]
===
match
---
suite [13220,13276]
suite [13220,13276]
===
match
---
if_stmt [41968,42057]
if_stmt [41946,42035]
===
match
---
name: warn [12393,12397]
name: warn [12393,12397]
===
match
---
funcdef [9584,11845]
funcdef [9584,11845]
===
match
---
operator: = [32324,32325]
operator: = [32324,32325]
===
match
---
trailer [34796,34842]
trailer [34796,34842]
===
match
---
not_test [1584,1603]
not_test [1584,1603]
===
match
---
trailer [31768,31770]
trailer [31768,31770]
===
match
---
name: args [38648,38652]
name: args [38626,38630]
===
match
---
arglist [15042,15076]
arglist [15042,15076]
===
match
---
trailer [21603,21620]
trailer [21603,21620]
===
match
---
with_item [32458,32474]
with_item [32458,32474]
===
match
---
atom_expr [8507,8540]
atom_expr [8507,8540]
===
match
---
arglist [19086,19108]
arglist [19086,19108]
===
match
---
if_stmt [15362,15411]
if_stmt [15362,15411]
===
match
---
funcdef [8441,8740]
funcdef [8441,8740]
===
match
---
operator: , [18399,18400]
operator: , [18399,18400]
===
match
---
simple_stmt [38628,38664]
simple_stmt [38606,38642]
===
match
---
trailer [28133,28175]
trailer [28133,28175]
===
match
---
trailer [12178,12193]
trailer [12178,12193]
===
match
---
atom_expr [34484,34551]
atom_expr [34484,34551]
===
match
---
name: start_method_options [10954,10974]
name: start_method_options [10954,10974]
===
match
---
name: get [14716,14719]
name: get [14716,14719]
===
match
---
trailer [22784,22804]
trailer [22784,22804]
===
match
---
operator: } [4299,4300]
operator: } [4299,4300]
===
match
---
operator: = [8732,8733]
operator: = [8732,8733]
===
match
---
name: _validate_config_dependencies [8779,8808]
name: _validate_config_dependencies [8779,8808]
===
match
---
atom_expr [17403,17435]
atom_expr [17403,17435]
===
match
---
if_stmt [28090,28201]
if_stmt [28090,28201]
===
match
---
trailer [29978,29980]
trailer [29978,29980]
===
match
---
del_stmt [27613,27654]
del_stmt [27613,27654]
===
match
---
name: msg [34943,34946]
name: msg [34943,34946]
===
match
---
expr_stmt [27920,27960]
expr_stmt [27920,27960]
===
match
---
operator: , [43023,43024]
operator: , [43001,43002]
===
match
---
name: DeprecationWarning [37343,37361]
name: DeprecationWarning [37321,37339]
===
match
---
atom_expr [10588,10819]
atom_expr [10588,10819]
===
match
---
funcdef [41159,41717]
funcdef [41137,41695]
===
match
---
simple_stmt [9125,9169]
simple_stmt [9125,9169]
===
match
---
trailer [32154,32159]
trailer [32154,32159]
===
match
---
trailer [8927,8929]
trailer [8927,8929]
===
match
---
simple_stmt [32193,32245]
simple_stmt [32193,32245]
===
match
---
suite [22961,22999]
suite [22961,22999]
===
match
---
fstring_start: f" [10632,10634]
fstring_start: f" [10632,10634]
===
match
---
suite [13057,14002]
suite [13057,14002]
===
match
---
name: path [2078,2082]
name: path [2078,2082]
===
match
---
operator: , [27921,27922]
operator: , [27921,27922]
===
match
---
simple_stmt [39171,39464]
simple_stmt [39149,39442]
===
match
---
name: section [11990,11997]
name: section [11990,11997]
===
match
---
string: 'f' [23163,23166]
string: 'f' [23163,23166]
===
match
---
trailer [12397,12840]
trailer [12397,12840]
===
match
---
trailer [16910,16926]
trailer [16910,16926]
===
match
---
name: _default_config_file_path [3047,3072]
name: _default_config_file_path [3047,3072]
===
match
---
parameters [27088,27150]
parameters [27088,27150]
===
match
---
arith_expr [11683,11826]
arith_expr [11683,11826]
===
match
---
name: items [23851,23856]
name: items [23851,23856]
===
match
---
atom_expr [41048,41073]
atom_expr [41026,41051]
===
match
---
suite [17357,17952]
suite [17357,17952]
===
match
---
suite [18232,18467]
suite [18232,18467]
===
match
---
name: section [19773,19780]
name: section [19773,19780]
===
match
---
suite [13887,13982]
suite [13887,13982]
===
match
---
if_stmt [2560,2765]
if_stmt [2560,2765]
===
match
---
operator: ** [15860,15862]
operator: ** [15860,15862]
===
match
---
trailer [15589,15614]
trailer [15589,15614]
===
match
---
name: remove_default [21238,21252]
name: remove_default [21238,21252]
===
match
---
name: globals [32939,32946]
name: globals [32939,32946]
===
match
---
atom_expr [9825,9853]
atom_expr [9825,9853]
===
match
---
name: _get_env_var_option [27988,28007]
name: _get_env_var_option [27988,28007]
===
match
---
name: kwargs [16067,16073]
name: kwargs [16067,16073]
===
match
---
atom_expr [3391,3430]
atom_expr [3391,3430]
===
match
---
name: self [23541,23545]
name: self [23541,23545]
===
match
---
operator: = [11504,11505]
operator: = [11504,11505]
===
match
---
name: deprecated_section [14961,14979]
name: deprecated_section [14961,14979]
===
match
---
strings [19604,19733]
strings [19604,19733]
===
match
---
operator: , [12829,12830]
operator: , [12829,12830]
===
match
---
argument [9461,9480]
argument [9461,9480]
===
match
---
name: ImportError [20292,20303]
name: ImportError [20292,20303]
===
match
---
trailer [33928,34004]
trailer [33928,34004]
===
match
---
operator: = [33671,33672]
operator: = [33671,33672]
===
match
---
atom [5623,5654]
atom [5623,5654]
===
match
---
import_name [863,877]
import_name [863,877]
===
match
---
name: _update_env_var [11968,11983]
name: _update_env_var [11968,11983]
===
match
---
trailer [15024,15028]
trailer [15024,15028]
===
match
---
strings [37135,37333]
strings [37113,37311]
===
match
---
dotted_name [1350,1365]
dotted_name [1350,1365]
===
match
---
operator: = [35786,35787]
operator: = [35786,35787]
===
match
---
suite [37082,37428]
suite [37060,37406]
===
match
---
suite [18814,19016]
suite [18814,19016]
===
match
---
operator: ** [16065,16067]
operator: ** [16065,16067]
===
match
---
arglist [21518,21533]
arglist [21518,21533]
===
match
---
operator: } [27598,27599]
operator: } [27598,27599]
===
match
---
arglist [26958,26980]
arglist [26958,26980]
===
match
---
operator: , [14995,14996]
operator: , [14995,14996]
===
match
---
operator: , [9026,9027]
operator: , [9026,9027]
===
match
---
atom_expr [14157,14185]
atom_expr [14157,14185]
===
match
---
operator: } [16243,16244]
operator: } [16243,16244]
===
match
---
import_name [853,862]
import_name [853,862]
===
match
---
name: kwargs [37454,37460]
name: kwargs [37432,37438]
===
match
---
operator: = [22734,22735]
operator: = [22734,22735]
===
match
---
operator: , [6484,6485]
operator: , [6484,6485]
===
match
---
operator: , [18033,18034]
operator: , [18033,18034]
===
match
---
name: stacklevel [30934,30944]
name: stacklevel [30934,30944]
===
match
---
string: 'core' [10915,10921]
string: 'core' [10915,10921]
===
match
---
trailer [17710,17746]
trailer [17710,17746]
===
match
---
fstring_start: f' [18873,18875]
fstring_start: f' [18873,18875]
===
match
---
name: key [16936,16939]
name: key [16936,16939]
===
match
---
name: fallback [21078,21086]
name: fallback [21078,21086]
===
match
---
atom_expr [44347,44366]
atom_expr [44325,44344]
===
match
---
name: deprecated_section [16684,16702]
name: deprecated_section [16684,16702]
===
match
---
arglist [26067,26121]
arglist [26067,26121]
===
match
---
name: kwargs [40371,40377]
name: kwargs [40349,40355]
===
match
---
operator: , [4238,4239]
operator: , [4238,4239]
===
match
---
param [29502,29513]
param [29502,29513]
===
match
---
name: _get_option_from_config_file [17264,17292]
name: _get_option_from_config_file [17264,17292]
===
match
---
trailer [27186,27210]
trailer [27186,27210]
===
match
---
trailer [20375,20550]
trailer [20375,20550]
===
match
---
operator: , [7123,7124]
operator: , [7123,7124]
===
match
---
trailer [29550,29561]
trailer [29550,29561]
===
match
---
simple_stmt [42562,42579]
simple_stmt [42540,42557]
===
match
---
suite [23086,23122]
suite [23086,23122]
===
match
---
name: configs [25917,25924]
name: configs [25917,25924]
===
match
---
operator: { [20512,20513]
operator: { [20512,20513]
===
match
---
operator: = [26749,26750]
operator: = [26749,26750]
===
match
---
trailer [41446,41452]
trailer [41424,41430]
===
match
---
simple_stmt [21179,21192]
simple_stmt [21179,21192]
===
match
---
name: val [22895,22898]
name: val [22895,22898]
===
match
---
name: getimport [41310,41319]
name: getimport [41288,41297]
===
match
---
trailer [7753,7759]
trailer [7753,7759]
===
match
---
operator: , [16058,16059]
operator: , [16058,16059]
===
match
---
operator: , [43633,43634]
operator: , [43611,43612]
===
match
---
name: config [31834,31840]
name: config [31834,31840]
===
match
---
atom_expr [24076,24101]
atom_expr [24076,24101]
===
match
---
operator: = [39454,39455]
operator: = [39432,39433]
===
match
---
trailer [13257,13265]
trailer [13257,13265]
===
match
---
operator: , [40722,40723]
operator: , [40700,40701]
===
match
---
dotted_name [42416,42435]
dotted_name [42394,42413]
===
match
---
atom_expr [2408,2423]
atom_expr [2408,2423]
===
match
---
name: section [14140,14147]
name: section [14140,14147]
===
match
---
simple_stmt [16185,16268]
simple_stmt [16185,16268]
===
match
---
atom_expr [32583,32622]
atom_expr [32583,32622]
===
match
---
argument [35692,35719]
argument [35692,35719]
===
match
---
trailer [19450,19474]
trailer [19450,19474]
===
match
---
name: os [43868,43870]
name: os [43846,43848]
===
match
---
name: key [18522,18525]
name: key [18522,18525]
===
match
---
atom_expr [18556,18588]
atom_expr [18556,18588]
===
match
---
operator: , [16342,16343]
operator: , [16342,16343]
===
match
---
name: section [28494,28501]
name: section [28494,28501]
===
match
---
trailer [14943,14949]
trailer [14943,14949]
===
match
---
simple_stmt [16758,16770]
simple_stmt [16758,16770]
===
match
---
param [19417,19425]
param [19417,19425]
===
match
---
name: old [9144,9147]
name: old [9144,9147]
===
match
---
simple_stmt [40734,40767]
simple_stmt [40712,40745]
===
match
---
operator: , [27956,27957]
operator: , [27956,27957]
===
match
---
name: self [23765,23769]
name: self [23765,23769]
===
match
---
name: _get_secret_option [14379,14397]
name: _get_secret_option [14379,14397]
===
match
---
return_stmt [37395,37427]
return_stmt [37373,37405]
===
match
---
expr_stmt [16541,16609]
expr_stmt [16541,16609]
===
match
---
simple_stmt [19436,19475]
simple_stmt [19436,19475]
===
match
---
name: raw [27146,27149]
name: raw [27146,27149]
===
match
---
string: "deprecated. Please access the configuration from the 'configuration.conf' object via " [38869,38956]
string: "deprecated. Please access the configuration from the 'configuration.conf' object via " [38847,38934]
===
match
---
string: '2.0.0' [5226,5233]
string: '2.0.0' [5226,5233]
===
match
---
simple_stmt [16897,16941]
simple_stmt [16897,16941]
===
match
---
trailer [33186,33217]
trailer [33186,33217]
===
match
---
number: 2 [39889,39890]
number: 2 [39867,39868]
===
match
---
fstring_string: module  [43155,43162]
fstring_string: module  [43133,43140]
===
match
---
operator: = [44345,44346]
operator: = [44323,44324]
===
match
---
arglist [8524,8539]
arglist [8524,8539]
===
match
---
string: """Get Secret Backend if defined in airflow.cfg""" [41228,41278]
string: """Get Secret Backend if defined in airflow.cfg""" [41206,41256]
===
match
---
simple_stmt [8947,8972]
simple_stmt [8947,8972]
===
match
---
operator: , [16934,16935]
operator: , [16934,16935]
===
match
---
fstring_string: ).  [10697,10700]
fstring_string: ).  [10697,10700]
===
match
---
name: warn [36717,36721]
name: warn [36695,36699]
===
match
---
operator: , [40340,40341]
operator: , [40318,40319]
===
match
---
operator: , [8036,8037]
operator: , [8036,8037]
===
match
---
if_stmt [30528,31480]
if_stmt [30528,31480]
===
match
---
arglist [34597,34624]
arglist [34597,34624]
===
match
---
name: warn [38348,38352]
name: warn [38326,38330]
===
match
---
name: conf [44340,44344]
name: conf [44318,44322]
===
match
---
name: get_docs_url [10325,10337]
name: get_docs_url [10325,10337]
===
match
---
operator: = [22899,22900]
operator: = [22899,22900]
===
match
---
name: deprecated_options [4572,4590]
name: deprecated_options [4572,4590]
===
match
---
name: self [11871,11875]
name: self [11871,11875]
===
match
---
parameters [14026,14046]
parameters [14026,14046]
===
match
---
trailer [30747,30754]
trailer [30747,30754]
===
match
---
if_stmt [33815,34301]
if_stmt [33815,34301]
===
match
---
name: section [41320,41327]
name: section [41298,41305]
===
match
---
name: _warn_deprecate [30452,30467]
name: _warn_deprecate [30452,30467]
===
match
---
trailer [2082,2093]
trailer [2082,2093]
===
match
---
trailer [17408,17410]
trailer [17408,17410]
===
match
---
name: open [34701,34705]
name: open [34701,34705]
===
match
---
operator: = [25732,25733]
operator: = [25732,25733]
===
match
---
operator: , [35288,35289]
operator: , [35288,35289]
===
match
---
name: _sections [23770,23779]
name: _sections [23770,23779]
===
match
---
string: 'SequentialExecutor' [9904,9924]
string: 'SequentialExecutor' [9904,9924]
===
match
---
suite [22861,23246]
suite [22861,23246]
===
match
---
import_from [1202,1242]
import_from [1202,1242]
===
match
---
name: section [23754,23761]
name: section [23754,23761]
===
match
---
trailer [33002,33009]
trailer [33002,33009]
===
match
---
name: _validate_config_dependencies [9588,9617]
name: _validate_config_dependencies [9588,9617]
===
match
---
param [12005,12014]
param [12005,12014]
===
match
---
return_stmt [31517,31710]
return_stmt [31517,31710]
===
match
---
atom [4231,4256]
atom [4231,4256]
===
match
---
name: self [9825,9829]
name: self [9825,9829]
===
match
---
name: display_source [26407,26421]
name: display_source [26407,26421]
===
match
---
funcdef [31485,31711]
funcdef [31485,31711]
===
match
---
argument [35856,35883]
argument [35856,35883]
===
match
---
operator: , [21810,21811]
operator: , [21810,21811]
===
match
---
operator: , [29638,29639]
operator: , [29638,29639]
===
match
---
atom_expr [29610,29648]
atom_expr [29610,29648]
===
match
---
strings [36731,36955]
strings [36709,36933]
===
match
---
name: FERNET_KEY [33555,33565]
name: FERNET_KEY [33555,33565]
===
match
---
name: env_var [28167,28174]
name: env_var [28167,28174]
===
match
---
funcdef [14007,14370]
funcdef [14007,14370]
===
match
---
atom [21134,21165]
atom [21134,21165]
===
match
---
operator: , [29335,29336]
operator: , [29335,29336]
===
match
---
name: sub [9140,9143]
name: sub [9140,9143]
===
match
---
operator: = [2915,2916]
operator: = [2915,2916]
===
match
---
name: WEBSERVER_CONFIG [44289,44305]
name: WEBSERVER_CONFIG [44267,44283]
===
match
---
trailer [33836,33854]
trailer [33836,33854]
===
match
---
name: os [43596,43598]
name: os [43574,43576]
===
match
---
name: _env_var_name [28258,28271]
name: _env_var_name [28258,28271]
===
match
---
param [14871,14879]
param [14871,14879]
===
match
---
name: stacklevel [31452,31462]
name: stacklevel [31452,31462]
===
match
---
name: option [15253,15259]
name: option [15253,15259]
===
match
---
simple_stmt [12846,12875]
simple_stmt [12846,12875]
===
match
---
atom_expr [43850,43950]
atom_expr [43828,43928]
===
match
---
trailer [34314,34331]
trailer [34314,34331]
===
match
---
simple_stmt [39599,39898]
simple_stmt [39577,39876]
===
match
---
name: config_sources [27532,27546]
name: config_sources [27532,27546]
===
match
---
operator: = [29643,29644]
operator: = [29643,29644]
===
match
---
trailer [44073,44078]
trailer [44051,44056]
===
match
---
suite [9624,11845]
suite [9624,11845]
===
match
---
trailer [27578,27580]
trailer [27578,27580]
===
match
---
operator: , [6163,6164]
operator: , [6163,6164]
===
match
---
expr_stmt [15420,15509]
expr_stmt [15420,15509]
===
match
---
arglist [31019,31465]
arglist [31019,31465]
===
match
---
atom_expr [38749,39041]
atom_expr [38727,39019]
===
match
---
name: key [19412,19415]
name: key [19412,19415]
===
match
---
name: full_qualified_path [20513,20532]
name: full_qualified_path [20513,20532]
===
match
---
name: realpath [43908,43916]
name: realpath [43886,43894]
===
match
---
name: Path [34025,34029]
name: Path [34025,34029]
===
match
---
name: os [32215,32217]
name: os [32215,32217]
===
match
---
parameters [33305,33307]
parameters [33305,33307]
===
match
---
simple_stmt [42221,42241]
simple_stmt [42199,42219]
===
match
---
expr_stmt [7669,8164]
expr_stmt [7669,8164]
===
match
---
operator: = [41440,41441]
operator: = [41418,41419]
===
match
---
arglist [17711,17745]
arglist [17711,17745]
===
match
---
name: section [18513,18520]
name: section [18513,18520]
===
match
---
name: kwargs [17923,17929]
name: kwargs [17923,17929]
===
match
---
simple_stmt [26048,26123]
simple_stmt [26048,26123]
===
match
---
suite [2840,3041]
suite [2840,3041]
===
match
---
name: args [39529,39533]
name: args [39507,39511]
===
match
---
simple_stmt [26436,26458]
simple_stmt [26436,26458]
===
match
---
trailer [28965,28977]
trailer [28965,28977]
===
match
---
name: opt [26887,26890]
name: opt [26887,26890]
===
match
---
argument [29623,29638]
argument [29623,29638]
===
match
---
atom_expr [41935,41962]
atom_expr [41913,41940]
===
match
---
name: deprecated_section [17657,17675]
name: deprecated_section [17657,17675]
===
match
---
name: raw [26118,26121]
name: raw [26118,26121]
===
match
---
with_stmt [32453,32623]
with_stmt [32453,32623]
===
match
---
operator: + [27049,27050]
operator: + [27049,27050]
===
match
---
except_clause [19527,19544]
except_clause [19527,19544]
===
match
---
name: section [12975,12982]
name: section [12975,12982]
===
match
---
simple_stmt [19136,19152]
simple_stmt [19136,19152]
===
match
---
trailer [44202,44206]
trailer [44180,44184]
===
match
---
name: path [43567,43571]
name: path [43545,43549]
===
match
---
string: '2.0.0' [5914,5921]
string: '2.0.0' [5914,5921]
===
match
---
name: update [22380,22386]
name: update [22380,22386]
===
match
---
name: path [43650,43654]
name: path [43628,43632]
===
match
---
operator: , [16682,16683]
operator: , [16682,16683]
===
match
---
name: val [23202,23205]
name: val [23202,23205]
===
match
---
trailer [44214,44223]
trailer [44192,44201]
===
match
---
name: info [30328,30332]
name: info [30328,30332]
===
match
---
trailer [32214,32244]
trailer [32214,32244]
===
match
---
atom [14139,14153]
atom [14139,14153]
===
match
---
atom_expr [12202,12231]
atom_expr [12202,12231]
===
match
---
trailer [8718,8731]
trailer [8718,8731]
===
match
---
fstring_start: f' [20393,20395]
fstring_start: f' [20393,20395]
===
match
---
trailer [22348,22357]
trailer [22348,22357]
===
match
---
atom_expr [12384,12840]
atom_expr [12384,12840]
===
match
---
atom [5698,5736]
atom [5698,5736]
===
match
---
trailer [21631,21648]
trailer [21631,21648]
===
match
---
fstring_string: " key in " [18927,18937]
fstring_string: " key in " [18927,18937]
===
match
---
operator: = [35700,35701]
operator: = [35700,35701]
===
match
---
name: display_sensitive [23941,23958]
name: display_sensitive [23941,23958]
===
match
---
arglist [18387,18435]
arglist [18387,18435]
===
match
---
trailer [28955,28957]
trailer [28955,28957]
===
match
---
arglist [42716,42763]
arglist [42694,42741]
===
match
---
strings [35437,35670]
strings [35437,35670]
===
match
---
return_stmt [19136,19151]
return_stmt [19136,19151]
===
match
---
operator: , [22473,22474]
operator: , [22473,22474]
===
match
---
name: new_value [9238,9247]
name: new_value [9238,9247]
===
match
---
comparison [11581,11615]
comparison [11581,11615]
===
match
---
comp_op [15205,15211]
comp_op [15205,15211]
===
match
---
fstring_expr [12974,12991]
fstring_expr [12974,12991]
===
match
---
arglist [16927,16939]
arglist [16927,16939]
===
match
---
param [31733,31738]
param [31733,31738]
===
match
---
name: WEBSERVER_CONFIG [36201,36217]
name: WEBSERVER_CONFIG [36201,36217]
===
match
---
arglist [41320,41352]
arglist [41298,41330]
===
match
---
arglist [12179,12192]
arglist [12179,12192]
===
match
---
operator: = [22703,22704]
operator: = [22703,22704]
===
match
---
argument [42264,42276]
argument [42242,42254]
===
match
---
testlist_star_expr [14961,14998]
testlist_star_expr [14961,14998]
===
match
---
string: 'remote_base_log_folder' [4930,4954]
string: 'remote_base_log_folder' [4930,4954]
===
match
---
string: 'The {name} setting in [{section}] has the old default value ' [12411,12473]
string: 'The {name} setting in [{section}] has the old default value ' [12411,12473]
===
match
---
operator: , [7887,7888]
operator: , [7887,7888]
===
match
---
simple_stmt [30988,31480]
simple_stmt [30988,31480]
===
match
---
name: secrets_backend_cls [42193,42212]
name: secrets_backend_cls [42171,42190]
===
match
---
operator: , [27733,27734]
operator: , [27733,27734]
===
match
---
arith_expr [13711,13730]
arith_expr [13711,13730]
===
match
---
name: lru_cache [42254,42263]
name: lru_cache [42232,42241]
===
match
---
arglist [27558,27580]
arglist [27558,27580]
===
match
---
try_stmt [19119,19379]
try_stmt [19119,19379]
===
match
---
name: self [23602,23606]
name: self [23602,23606]
===
match
---
name: validate [8749,8757]
name: validate [8749,8757]
===
match
---
operator: , [12224,12225]
operator: , [12224,12225]
===
match
---
name: key [14501,14504]
name: key [14501,14504]
===
match
---
operator: , [31305,31306]
operator: , [31305,31306]
===
match
---
simple_stmt [33868,33907]
simple_stmt [33868,33907]
===
match
---
operator: * [40335,40336]
operator: * [40313,40314]
===
match
---
simple_stmt [23111,23122]
simple_stmt [23111,23122]
===
match
---
operator: , [29326,29327]
operator: , [29326,29327]
===
match
---
atom [5368,5408]
atom [5368,5408]
===
match
---
simple_stmt [42117,42165]
simple_stmt [42095,42143]
===
match
---
operator: , [7765,7766]
operator: , [7765,7766]
===
match
---
name: command [2263,2270]
name: command [2263,2270]
===
match
---
param [8488,8496]
param [8488,8496]
===
match
---
string: 'core' [35345,35351]
string: 'core' [35345,35351]
===
match
---
name: section [15952,15959]
name: section [15952,15959]
===
match
---
argument [20130,20137]
argument [20130,20137]
===
match
---
name: fallback [9028,9036]
name: fallback [9028,9036]
===
match
---
name: val [29744,29747]
name: val [29744,29747]
===
match
---
expr_stmt [18245,18314]
expr_stmt [18245,18314]
===
match
---
simple_stmt [25690,25737]
simple_stmt [25690,25737]
===
match
---
name: AirflowConfigException [19564,19586]
name: AirflowConfigException [19564,19586]
===
match
---
operator: ** [39966,39968]
operator: ** [39944,39946]
===
match
---
trailer [43764,43786]
trailer [43742,43764]
===
match
---
trailer [9143,9168]
trailer [9143,9168]
===
match
---
operator: , [38162,38163]
operator: , [38140,38141]
===
match
---
operator: } [8156,8157]
operator: } [8156,8157]
===
match
---
import_from [33868,33906]
import_from [33868,33906]
===
match
---
expr_stmt [44169,44223]
expr_stmt [44147,44201]
===
match
---
operator: = [44016,44017]
operator: = [43994,43995]
===
match
---
suite [43681,43723]
suite [43659,43701]
===
match
---
trailer [11288,11293]
trailer [11288,11293]
===
match
---
operator: = [44427,44428]
operator: = [44421,44422]
===
match
---
name: log [33920,33923]
name: log [33920,33923]
===
match
---
name: stderr [2401,2407]
name: stderr [2401,2407]
===
match
---
operator: , [21068,21069]
operator: , [21068,21069]
===
match
---
string: '%%' [28395,28399]
string: '%%' [28395,28399]
===
match
---
name: getfloat [38236,38244]
name: getfloat [38214,38222]
===
match
---
name: deprecated_key [17994,18008]
name: deprecated_key [17994,18008]
===
match
---
testlist_comp [6107,6185]
testlist_comp [6107,6185]
===
match
---
string: """Historical remove_option""" [39564,39594]
string: """Historical remove_option""" [39542,39572]
===
match
---
name: new [8952,8955]
name: new [8952,8955]
===
match
---
string: "Accessing configuration method 'load_test_config' directly from the configuration module is " [36731,36825]
string: "Accessing configuration method 'load_test_config' directly from the configuration module is " [36709,36803]
===
match
---
operator: -> [8403,8405]
operator: -> [8403,8405]
===
match
---
simple_stmt [15576,15665]
simple_stmt [15576,15665]
===
match
---
operator: , [7759,7760]
operator: , [7759,7760]
===
match
---
trailer [33149,33157]
trailer [33149,33157]
===
match
---
string: "file_parsing_sort_mode" [11448,11472]
string: "file_parsing_sort_mode" [11448,11472]
===
match
---
string: 'Airflow {version}.' [12650,12670]
string: 'Airflow {version}.' [12650,12670]
===
match
---
name: display_source [29307,29321]
name: display_source [29307,29321]
===
match
---
trailer [3183,3188]
trailer [3183,3188]
===
match
---
name: name [9227,9231]
name: name [9227,9231]
===
match
---
with_stmt [42365,42413]
with_stmt [42343,42391]
===
match
---
suite [35756,35885]
suite [35756,35885]
===
match
---
trailer [23545,23557]
trailer [23545,23557]
===
match
---
fstring_string: Template marker not found in  [32648,32677]
fstring_string: Template marker not found in  [32648,32677]
===
match
---
suite [28431,28471]
suite [28431,28471]
===
match
---
name: self [29994,29998]
name: self [29994,29998]
===
match
---
trailer [21060,21094]
trailer [21060,21094]
===
match
---
name: fernet [34450,34456]
name: fernet [34450,34456]
===
match
---
trailer [43603,43612]
trailer [43581,43590]
===
match
---
name: raw [29644,29647]
name: raw [29644,29647]
===
match
---
expr_stmt [10954,11016]
expr_stmt [10954,11016]
===
match
---
annassign [25704,25736]
annassign [25704,25736]
===
match
---
fstring_string: Cannot execute  [2640,2655]
fstring_string: Cannot execute  [2640,2655]
===
match
---
name: _delimiters [23607,23618]
name: _delimiters [23607,23618]
===
match
---
operator: * [39928,39929]
operator: * [39906,39907]
===
match
---
arglist [1633,1696]
arglist [1633,1696]
===
match
---
operator: , [36955,36956]
operator: , [36933,36934]
===
match
---
string: '< hidden >' [28321,28333]
string: '< hidden >' [28321,28333]
===
match
---
arglist [12411,12830]
arglist [12411,12830]
===
match
---
funcdef [17260,17952]
funcdef [17260,17952]
===
match
---
operator: , [11988,11989]
operator: , [11988,11989]
===
match
---
trailer [41452,41548]
trailer [41430,41526]
===
match
---
arglist [3123,3168]
arglist [3123,3168]
===
match
---
operator: , [23815,23816]
operator: , [23815,23816]
===
match
---
operator: , [6364,6365]
operator: , [6364,6365]
===
match
---
param [14851,14856]
param [14851,14856]
===
match
---
suite [42108,42216]
suite [42086,42194]
===
match
---
operator: , [15499,15500]
operator: , [15499,15500]
===
match
---
name: getint [19025,19031]
name: getint [19025,19031]
===
match
---
name: section [14653,14660]
name: section [14653,14660]
===
match
---
name: has_option [39092,39102]
name: has_option [39070,39080]
===
match
---
simple_stmt [14261,14306]
simple_stmt [14261,14306]
===
match
---
name: config_sources [27021,27035]
name: config_sources [27021,27035]
===
match
---
return_stmt [41129,41156]
return_stmt [41107,41134]
===
match
---
trailer [38352,38623]
trailer [38330,38601]
===
match
---
raise_stmt [11633,11844]
raise_stmt [11633,11844]
===
match
---
if_stmt [26699,26764]
if_stmt [26699,26764]
===
match
---
name: initialize_secrets_backends [41095,41122]
name: initialize_secrets_backends [41073,41100]
===
match
---
simple_stmt [28879,28897]
simple_stmt [28879,28897]
===
match
---
name: join [32155,32159]
name: join [32155,32159]
===
match
---
name: sensitive_config_values [13509,13532]
name: sensitive_config_values [13509,13532]
===
match
---
arith_expr [27641,27653]
arith_expr [27641,27653]
===
match
---
arglist [40474,40723]
arglist [40452,40701]
===
match
---
testlist_comp [5699,5735]
testlist_comp [5699,5735]
===
match
---
simple_stmt [8507,8541]
simple_stmt [8507,8541]
===
match
---
operator: , [5152,5153]
operator: , [5152,5153]
===
match
---
name: section [12714,12721]
name: section [12714,12721]
===
match
---
trailer [34395,34402]
trailer [34395,34402]
===
match
---
simple_stmt [43384,43434]
simple_stmt [43362,43412]
===
match
---
trailer [31793,31797]
trailer [31793,31797]
===
match
---
operator: , [15787,15788]
operator: , [15787,15788]
===
match
---
trailer [7745,7753]
trailer [7745,7753]
===
match
---
param [19403,19411]
param [19403,19411]
===
match
---
atom_expr [13557,13593]
atom_expr [13557,13593]
===
match
---
atom_expr [13209,13219]
atom_expr [13209,13219]
===
match
---
arglist [17155,17203]
arglist [17155,17203]
===
match
---
operator: , [25838,25839]
operator: , [25838,25839]
===
match
---
name: backend_list [42228,42240]
name: backend_list [42206,42218]
===
match
---
operator: { [26989,26990]
operator: { [26989,26990]
===
match
---
simple_stmt [39139,39167]
simple_stmt [39117,39145]
===
match
---
trailer [1521,1531]
trailer [1521,1531]
===
match
---
string: 'airflow' [1687,1696]
string: 'airflow' [1687,1696]
===
match
---
trailer [43566,43571]
trailer [43544,43549]
===
match
---
name: has_option [11351,11361]
name: has_option [11351,11361]
===
match
---
name: kwargs [17340,17346]
name: kwargs [17340,17346]
===
match
---
operator: , [14411,14412]
operator: , [14411,14412]
===
match
---
arglist [29283,29348]
arglist [29283,29348]
===
match
---
operator: , [1154,1155]
operator: , [1154,1155]
===
match
---
trailer [44207,44214]
trailer [44185,44192]
===
match
---
suite [32049,32245]
suite [32049,32245]
===
match
---
simple_stmt [44422,44456]
simple_stmt [44416,44450]
===
match
---
name: lower [14913,14918]
name: lower [14913,14918]
===
match
---
name: key [15855,15858]
name: key [15855,15858]
===
match
---
operator: { [12974,12975]
operator: { [12974,12975]
===
match
---
param [32715,32723]
param [32715,32723]
===
match
---
fstring_expr [10143,10173]
fstring_expr [10143,10173]
===
match
---
return_stmt [15230,15243]
return_stmt [15230,15243]
===
match
---
operator: , [7263,7264]
operator: , [7263,7264]
===
match
---
operator: } [11563,11564]
operator: } [11563,11564]
===
match
---
name: log [30324,30327]
name: log [30324,30327]
===
match
---
operator: , [21228,21229]
operator: , [21228,21229]
===
match
---
simple_stmt [43996,44039]
simple_stmt [43974,44017]
===
match
---
param [26490,26505]
param [26490,26505]
===
match
---
argument [12752,12771]
argument [12752,12771]
===
match
---
operator: , [29491,29492]
operator: , [29491,29492]
===
match
---
trailer [16046,16050]
trailer [16046,16050]
===
match
---
operator: @ [12280,12281]
operator: @ [12280,12281]
===
match
---
not_test [22034,22063]
not_test [22034,22063]
===
match
---
trailer [35340,35344]
trailer [35340,35344]
===
match
---
testlist_comp [14140,14152]
testlist_comp [14140,14152]
===
match
---
name: ensure_secrets_loaded [40773,40794]
name: ensure_secrets_loaded [40751,40772]
===
match
---
suite [15384,15411]
suite [15384,15411]
===
match
---
for_stmt [42062,42216]
for_stmt [42040,42194]
===
match
---
name: path [32463,32467]
name: path [32463,32467]
===
match
---
name: deprecated_section [15153,15171]
name: deprecated_section [15153,15171]
===
match
---
operator: = [1786,1787]
operator: = [1786,1787]
===
match
---
simple_stmt [44367,44420]
simple_stmt [44345,44398]
===
match
---
name: DeprecationWarning [37758,37776]
name: DeprecationWarning [37736,37754]
===
match
---
name: option [17110,17116]
name: option [17110,17116]
===
match
---
operator: , [17633,17634]
operator: , [17633,17634]
===
match
---
trailer [9193,9209]
trailer [9193,9209]
===
match
---
trailer [22511,22519]
trailer [22511,22519]
===
match
---
string: 'fab_logging_level' [5174,5193]
string: 'fab_logging_level' [5174,5193]
===
match
---
string: 'hostname_callable' [7721,7740]
string: 'hostname_callable' [7721,7740]
===
match
---
arglist [38245,38260]
arglist [38223,38238]
===
match
---
name: key [19047,19050]
name: key [19047,19050]
===
match
---
strings [37536,37748]
strings [37514,37726]
===
match
---
fstring [20393,20477]
fstring [20393,20477]
===
match
---
name: fallback_key [14292,14304]
name: fallback_key [14292,14304]
===
match
---
name: AirflowConfigParser [3499,3518]
name: AirflowConfigParser [3499,3518]
===
match
---
param [37058,37066]
param [37036,37044]
===
match
---
name: __name__ [44511,44519]
name: __name__ [44505,44513]
===
match
---
operator: , [2399,2400]
operator: , [2399,2400]
===
match
---
trailer [25900,25946]
trailer [25900,25946]
===
match
---
name: DeprecationWarning [38994,39012]
name: DeprecationWarning [38972,38990]
===
match
---
param [21221,21229]
param [21221,21229]
===
match
---
operator: , [37748,37749]
operator: , [37726,37727]
===
match
---
expr_stmt [41911,41962]
expr_stmt [41889,41940]
===
match
---
name: opt [26678,26681]
name: opt [26678,26681]
===
match
---
name: filename [32439,32447]
name: filename [32439,32447]
===
match
---
trailer [42410,42412]
trailer [42388,42390]
===
match
---
name: env_var [13368,13375]
name: env_var [13368,13375]
===
match
---
atom_expr [26189,26267]
atom_expr [26189,26267]
===
match
---
expr_stmt [9788,9935]
expr_stmt [9788,9935]
===
match
---
param [20678,20683]
param [20678,20683]
===
match
---
name: get_airflow_home [43365,43381]
name: get_airflow_home [43343,43359]
===
match
---
trailer [17784,17834]
trailer [17784,17834]
===
match
---
name: _replace_section_config_with_display_sources [29217,29261]
name: _replace_section_config_with_display_sources [29217,29261]
===
match
---
argument [38252,38260]
argument [38230,38238]
===
match
---
atom_expr [28494,28509]
atom_expr [28494,28509]
===
match
---
trailer [1617,1632]
trailer [1617,1632]
===
match
---
operator: = [9336,9337]
operator: = [9336,9337]
===
match
---
atom_expr [25706,25731]
atom_expr [25706,25731]
===
match
---
name: section [15656,15663]
name: section [15656,15663]
===
match
---
simple_stmt [17134,17205]
simple_stmt [17134,17205]
===
match
---
trailer [15028,15086]
trailer [15028,15086]
===
match
---
comparison [30531,30560]
comparison [30531,30560]
===
match
---
name: env_var [2028,2035]
name: env_var [2028,2035]
===
match
---
import_from [33313,33351]
import_from [33313,33351]
===
match
---
name: pop [31794,31797]
name: pop [31794,31797]
===
match
---
name: partial [42708,42715]
name: partial [42686,42693]
===
match
---
parameters [15839,15869]
parameters [15839,15869]
===
match
---
name: display_source [27719,27733]
name: display_source [27719,27733]
===
match
---
operator: , [31379,31380]
operator: , [31379,31380]
===
match
---
name: info [8967,8971]
name: info [8967,8971]
===
match
---
parameters [8757,8763]
parameters [8757,8763]
===
match
---
operator: = [19440,19441]
operator: = [19440,19441]
===
match
---
string: 'scheduler' [6535,6546]
string: 'scheduler' [6535,6546]
===
match
---
atom_expr [32120,32130]
atom_expr [32120,32130]
===
match
---
del_stmt [27017,27061]
del_stmt [27017,27061]
===
match
---
name: info [30130,30134]
name: info [30130,30134]
===
match
---
arglist [44084,44107]
arglist [44062,44085]
===
match
---
fstring [42959,43023]
fstring [42937,43001]
===
match
---
name: AIRFLOW_CONFIG [34403,34417]
name: AIRFLOW_CONFIG [34403,34417]
===
match
---
string: 'statsd_on' [6295,6306]
string: 'statsd_on' [6295,6306]
===
match
---
fstring_end: ' [20535,20536]
fstring_end: ' [20535,20536]
===
match
---
name: _parameterized_config_from_template [33602,33637]
name: _parameterized_config_from_template [33602,33637]
===
match
---
operator: , [26908,26909]
operator: , [26908,26909]
===
match
---
simple_stmt [37017,37041]
simple_stmt [36995,37019]
===
match
---
string: 'logging' [5843,5852]
string: 'logging' [5843,5852]
===
match
---
fstring_end: ' [19732,19733]
fstring_end: ' [19732,19733]
===
match
---
name: val [22905,22908]
name: val [22905,22908]
===
match
---
number: 2 [38211,38212]
number: 2 [38189,38190]
===
match
---
string: 'stat_name_handler' [6682,6701]
string: 'stat_name_handler' [6682,6701]
===
match
---
simple_stmt [29697,29722]
simple_stmt [29697,29722]
===
match
---
simple_stmt [1452,1507]
simple_stmt [1452,1507]
===
match
---
operator: , [7028,7029]
operator: , [7028,7029]
===
match
---
operator: @ [30430,30431]
operator: @ [30430,30431]
===
match
---
simple_stmt [36091,36115]
simple_stmt [36091,36115]
===
match
---
name: airflow [10299,10306]
name: airflow [10299,10306]
===
match
---
atom [4957,5000]
atom [4957,5000]
===
match
---
name: display_sensitive [26228,26245]
name: display_sensitive [26228,26245]
===
match
---
comparison [32096,32130]
comparison [32096,32130]
===
match
---
atom_expr [43868,43928]
atom_expr [43846,43906]
===
match
---
not_test [34384,34418]
not_test [34384,34418]
===
match
---
testlist_comp [6505,6531]
testlist_comp [6505,6531]
===
match
---
string: """Historical set""" [40426,40446]
string: """Historical set""" [40404,40424]
===
match
---
name: conf [39909,39913]
name: conf [39887,39891]
===
match
---
name: AttributeError [43138,43152]
name: AttributeError [43116,43130]
===
match
---
name: val [19071,19074]
name: val [19071,19074]
===
match
---
string: 'core' [5543,5549]
string: 'core' [5543,5549]
===
match
---
name: opt [27441,27444]
name: opt [27441,27444]
===
match
---
name: expand_env_var [13240,13254]
name: expand_env_var [13240,13254]
===
match
---
param [30502,30517]
param [30502,30517]
===
match
---
raise_stmt [43132,43198]
raise_stmt [43110,43176]
===
match
---
suite [31508,31711]
suite [31508,31711]
===
match
---
trailer [32438,32448]
trailer [32438,32448]
===
match
---
operator: , [16677,16678]
operator: , [16677,16678]
===
match
---
string: 't' [18692,18695]
string: 't' [18692,18695]
===
match
---
name: section [13841,13848]
name: section [13841,13848]
===
match
---
fstring_expr [43190,43196]
fstring_expr [43168,43174]
===
match
---
decorated [42243,42413]
decorated [42221,42391]
===
match
---
operator: = [10904,10905]
operator: = [10904,10905]
===
match
---
atom [9861,9935]
atom [9861,9935]
===
match
---
operator: , [28942,28943]
operator: , [28942,28943]
===
match
---
operator: = [9135,9136]
operator: = [9135,9136]
===
match
---
trailer [28888,28894]
trailer [28888,28894]
===
match
---
operator: = [31786,31787]
operator: = [31786,31787]
===
match
---
operator: , [6573,6574]
operator: , [6573,6574]
===
match
---
operator: , [13180,13181]
operator: , [13180,13181]
===
match
---
operator: , [40672,40673]
operator: , [40650,40651]
===
match
---
name: fh [32472,32474]
name: fh [32472,32474]
===
match
---
for_stmt [8820,9545]
for_stmt [8820,9545]
===
match
---
name: AIRFLOW_CONFIG [34706,34720]
name: AIRFLOW_CONFIG [34706,34720]
===
match
---
atom_expr [34852,34877]
atom_expr [34852,34877]
===
match
---
trailer [16653,16669]
trailer [16653,16669]
===
match
---
name: key [26990,26993]
name: key [26990,26993]
===
match
---
suite [29981,30023]
suite [29981,30023]
===
match
---
operator: = [14933,14934]
operator: = [14933,14934]
===
match
---
name: opt [26893,26896]
name: opt [26893,26896]
===
match
---
name: AirflowConfigException [11100,11122]
name: AirflowConfigException [11100,11122]
===
match
---
operator: , [25803,25804]
operator: , [25803,25804]
===
match
---
atom [5842,5878]
atom [5842,5878]
===
match
---
atom_expr [30212,30267]
atom_expr [30212,30267]
===
match
---
argument [19100,19108]
argument [19100,19108]
===
match
---
argument [12695,12704]
argument [12695,12704]
===
match
---
trailer [22093,22105]
trailer [22093,22105]
===
match
---
param [26541,26544]
param [26541,26544]
===
match
---
name: args [38246,38250]
name: args [38224,38228]
===
match
---
trailer [43119,43125]
trailer [43097,43103]
===
match
---
name: stderr [2746,2752]
name: stderr [2746,2752]
===
match
---
name: has_option [39480,39490]
name: has_option [39458,39468]
===
match
---
arglist [33187,33216]
arglist [33187,33216]
===
match
---
atom_expr [28378,28400]
atom_expr [28378,28400]
===
match
---
trailer [29561,29585]
trailer [29561,29585]
===
match
---
suite [19545,19748]
suite [19545,19748]
===
match
---
param [29774,29778]
param [29774,29778]
===
match
---
operator: = [34619,34620]
operator: = [34619,34620]
===
match
---
simple_stmt [16406,16453]
simple_stmt [16406,16453]
===
match
---
atom_expr [29197,29366]
atom_expr [29197,29366]
===
match
---
atom [27764,27885]
atom [27764,27885]
===
match
---
with_stmt [34149,34301]
with_stmt [34149,34301]
===
match
---
string: '3.15.0' [10467,10475]
string: '3.15.0' [10467,10475]
===
match
---
operator: } [7508,7509]
operator: } [7508,7509]
===
match
---
string: 'core' [7455,7461]
string: 'core' [7455,7461]
===
match
---
name: DeprecationWarning [31416,31434]
name: DeprecationWarning [31416,31434]
===
match
---
comparison [18617,18627]
comparison [18617,18627]
===
match
---
name: deprecated_key [15137,15151]
name: deprecated_key [15137,15151]
===
match
---
operator: } [19729,19730]
operator: } [19729,19730]
===
match
---
trailer [11661,11844]
trailer [11661,11844]
===
match
---
param [11999,12004]
param [11999,12004]
===
match
---
simple_stmt [1833,1993]
simple_stmt [1833,1993]
===
match
---
operator: { [42972,42973]
operator: { [42950,42951]
===
match
---
simple_stmt [40024,40311]
simple_stmt [40002,40289]
===
match
---
name: warnings [40451,40459]
name: warnings [40429,40437]
===
match
---
arglist [39622,39891]
arglist [39600,39869]
===
match
---
name: default_config [8460,8474]
name: default_config [8460,8474]
===
match
---
name: fp [23813,23815]
name: fp [23813,23815]
===
match
---
name: category [1651,1659]
name: category [1651,1659]
===
match
---
operator: , [37870,37871]
operator: , [37848,37849]
===
match
---
simple_stmt [31850,31878]
simple_stmt [31850,31878]
===
match
---
atom_expr [32994,33021]
atom_expr [32994,33021]
===
match
---
atom_expr [2532,2553]
atom_expr [2532,2553]
===
match
---
testlist_comp [6584,6614]
testlist_comp [6584,6614]
===
match
---
atom_expr [26350,26427]
atom_expr [26350,26427]
===
match
---
atom_expr [3463,3490]
atom_expr [3463,3490]
===
match
---
simple_stmt [18475,18487]
simple_stmt [18475,18487]
===
match
---
string: 'statsd_host' [6396,6409]
string: 'statsd_host' [6396,6409]
===
match
---
name: exists [43962,43968]
name: exists [43940,43946]
===
match
---
name: update [27582,27588]
name: update [27582,27588]
===
match
---
dictorsetmaker [11507,11563]
dictorsetmaker [11507,11563]
===
match
---
trailer [36051,36077]
trailer [36051,36077]
===
match
---
operator: , [5576,5577]
operator: , [5576,5577]
===
match
---
if_stmt [13483,13594]
if_stmt [13483,13594]
===
match
---
name: self [22332,22336]
name: self [22332,22336]
===
match
---
operator: = [24004,24005]
operator: = [24004,24005]
===
match
---
fstring_expr [19669,19678]
fstring_expr [19669,19678]
===
match
---
name: super [14202,14207]
name: super [14202,14207]
===
match
---
name: optionxform [8369,8380]
name: optionxform [8369,8380]
===
match
---
fstring_start: f' [19707,19709]
fstring_start: f' [19707,19709]
===
match
---
trailer [42945,43092]
trailer [42923,43070]
===
match
---
atom_expr [42569,42578]
atom_expr [42547,42556]
===
match
---
trailer [9833,9853]
trailer [9833,9853]
===
match
---
string: '2.0.0' [4816,4823]
string: '2.0.0' [4816,4823]
===
match
---
fstring [12951,13007]
fstring [12951,13007]
===
match
---
argument [20640,20657]
argument [20640,20657]
===
match
---
parameters [21214,21258]
parameters [21214,21258]
===
match
---
atom_expr [22502,22527]
atom_expr [22502,22527]
===
match
---
name: environ [13952,13959]
name: environ [13952,13959]
===
match
---
simple_stmt [930,946]
simple_stmt [930,946]
===
match
---
atom_expr [44192,44206]
atom_expr [44170,44184]
===
match
---
funcdef [40354,40767]
funcdef [40332,40745]
===
match
---
trailer [16024,16075]
trailer [16024,16075]
===
match
---
name: section [27632,27639]
name: section [27632,27639]
===
match
---
trailer [23769,23779]
trailer [23769,23779]
===
match
---
operator: , [11880,11881]
operator: , [11880,11881]
===
match
---
trailer [14207,14209]
trailer [14207,14209]
===
match
---
atom_expr [19442,19474]
atom_expr [19442,19474]
===
match
---
operator: , [41518,41519]
operator: , [41496,41497]
===
match
---
arglist [42959,43082]
arglist [42937,43060]
===
match
---
simple_stmt [34943,35210]
simple_stmt [34943,35210]
===
match
---
trailer [38244,38261]
trailer [38222,38239]
===
match
---
suite [23325,23871]
suite [23325,23871]
===
match
---
simple_stmt [786,803]
simple_stmt [786,803]
===
match
---
trailer [41474,41478]
trailer [41452,41456]
===
match
---
simple_stmt [19191,19379]
simple_stmt [19191,19379]
===
match
---
param [18035,18042]
param [18035,18042]
===
match
---
string: 'logging_level' [5127,5142]
string: 'logging_level' [5127,5142]
===
match
---
string: 'core' [5981,5987]
string: 'core' [5981,5987]
===
match
---
atom_expr [28909,28977]
atom_expr [28909,28977]
===
match
---
suite [29649,29748]
suite [29649,29748]
===
match
---
string: '2.0.0' [5646,5653]
string: '2.0.0' [5646,5653]
===
match
---
name: has_section [22043,22054]
name: has_section [22043,22054]
===
match
---
operator: , [26965,26966]
operator: , [26965,26966]
===
match
---
operator: , [31260,31261]
operator: , [31260,31261]
===
match
---
string: 'default_test.cfg' [30098,30116]
string: 'default_test.cfg' [30098,30116]
===
match
---
argument [40342,40350]
argument [40320,40328]
===
match
---
name: deprecated_key [15460,15474]
name: deprecated_key [15460,15474]
===
match
---
param [26506,26524]
param [26506,26524]
===
match
---
atom_expr [22332,22357]
atom_expr [22332,22357]
===
match
---
operator: = [32411,32412]
operator: = [32411,32412]
===
match
---
atom_expr [26893,26915]
atom_expr [26893,26915]
===
match
---
argument [39878,39890]
argument [39856,39868]
===
match
---
string: 'default_test.cfg' [34249,34267]
string: 'default_test.cfg' [34249,34267]
===
match
---
trailer [33254,33277]
trailer [33254,33277]
===
match
---
string: 'logging' [5163,5172]
string: 'logging' [5163,5172]
===
match
---
string: '%' [27509,27512]
string: '%' [27509,27512]
===
match
---
parameters [3245,3247]
parameters [3245,3247]
===
match
---
trailer [34024,34029]
trailer [34024,34029]
===
match
---
trailer [11799,11804]
trailer [11799,11804]
===
match
---
param [14033,14041]
param [14033,14041]
===
match
---
name: re [7974,7976]
name: re [7974,7976]
===
match
---
simple_stmt [33666,33724]
simple_stmt [33666,33724]
===
match
---
atom_expr [14935,14951]
atom_expr [14935,14951]
===
match
---
operator: , [5482,5483]
operator: , [5482,5483]
===
match
---
argument [38245,38250]
argument [38223,38228]
===
match
---
operator: , [6195,6196]
operator: , [6195,6196]
===
match
---
name: section [14572,14579]
name: section [14572,14579]
===
match
---
trailer [20112,20148]
trailer [20112,20148]
===
match
---
argument [20139,20147]
argument [20139,20147]
===
match
---
trailer [17042,17058]
trailer [17042,17058]
===
match
---
atom_expr [43546,43643]
atom_expr [43524,43621]
===
match
---
atom [25734,25736]
atom [25734,25736]
===
match
---
name: default_config [33708,33722]
name: default_config [33708,33722]
===
match
---
string: 'AIRFLOW_HOME' [35225,35239]
string: 'AIRFLOW_HOME' [35225,35239]
===
match
---
operator: ** [18527,18529]
operator: ** [18527,18529]
===
match
---
simple_stmt [14056,14084]
simple_stmt [14056,14084]
===
match
---
name: AirflowConfigException [20353,20375]
name: AirflowConfigException [20353,20375]
===
match
---
testlist_comp [6758,6793]
testlist_comp [6758,6793]
===
match
---
simple_stmt [20322,20335]
simple_stmt [20322,20335]
===
match
---
comparison [23147,23176]
comparison [23147,23176]
===
match
---
name: conf [37402,37406]
name: conf [37380,37384]
===
match
---
name: section [28008,28015]
name: section [28008,28015]
===
match
---
param [18522,18526]
param [18522,18526]
===
match
---
operator: } [25735,25736]
operator: } [25735,25736]
===
match
---
name: WEBSERVER_CONFIG [36306,36322]
name: WEBSERVER_CONFIG [36306,36322]
===
match
---
simple_stmt [9788,9936]
simple_stmt [9788,9936]
===
match
---
name: path [33825,33829]
name: path [33825,33829]
===
match
---
name: log [28122,28125]
name: log [28122,28125]
===
match
---
name: yaml [3463,3467]
name: yaml [3463,3467]
===
match
---
return_stmt [41705,41716]
return_stmt [41683,41694]
===
match
---
name: self [16415,16419]
name: self [16415,16419]
===
match
---
suite [12375,12841]
suite [12375,12841]
===
match
---
arith_expr [11144,11315]
arith_expr [11144,11315]
===
match
---
fstring [19338,19364]
fstring [19338,19364]
===
match
---
operator: , [1678,1679]
operator: , [1678,1679]
===
match
---
dotted_name [1296,1314]
dotted_name [1296,1314]
===
match
---
suite [15990,16076]
suite [15990,16076]
===
match
---
fstring_expr [42961,42971]
fstring_expr [42939,42949]
===
match
---
name: warn [38758,38762]
name: warn [38736,38740]
===
match
---
trailer [12204,12212]
trailer [12204,12212]
===
match
---
name: read [20560,20564]
name: read [20560,20564]
===
match
---
fstring_string: Current value: " [19709,19725]
fstring_string: Current value: " [19709,19725]
===
match
---
name: lower [23151,23156]
name: lower [23151,23156]
===
match
---
simple_stmt [3576,3653]
simple_stmt [3576,3653]
===
match
---
param [17299,17314]
param [17299,17314]
===
match
---
name: backend_list [41888,41900]
name: backend_list [41866,41878]
===
match
---
name: path [43957,43961]
name: path [43935,43939]
===
match
---
name: section [14720,14727]
name: section [14720,14727]
===
match
---
name: option [15576,15582]
name: option [15576,15582]
===
match
---
parameters [41750,41752]
parameters [41728,41730]
===
match
---
return_stmt [16003,16075]
return_stmt [16003,16075]
===
match
---
arglist [34493,34550]
arglist [34493,34550]
===
match
---
simple_stmt [27434,27453]
simple_stmt [27434,27453]
===
match
---
atom_expr [12411,12802]
atom_expr [12411,12802]
===
match
---
operator: , [39456,39457]
operator: , [39434,39435]
===
match
---
name: deprecated_key [17819,17833]
name: deprecated_key [17819,17833]
===
match
---
atom_expr [30195,30268]
atom_expr [30195,30268]
===
match
---
fstring_start: f' [18975,18977]
fstring_start: f' [18975,18977]
===
match
---
arglist [12249,12273]
arglist [12249,12273]
===
match
---
operator: , [37333,37334]
operator: , [37311,37312]
===
match
---
param [8454,8459]
param [8454,8459]
===
match
---
comp_op [41993,41999]
comp_op [41971,41977]
===
match
---
string: 'scheduler' [6891,6902]
string: 'scheduler' [6891,6902]
===
match
---
operator: , [43777,43778]
operator: , [43755,43756]
===
match
---
name: conf [39475,39479]
name: conf [39453,39457]
===
match
---
name: path [43549,43553]
name: path [43527,43531]
===
match
---
atom_expr [11426,11473]
atom_expr [11426,11473]
===
match
---
name: super [17873,17878]
name: super [17873,17878]
===
match
---
strings [30605,30747]
strings [30605,30747]
===
match
---
name: airflow_home [33187,33199]
name: airflow_home [33187,33199]
===
match
---
name: option [15404,15410]
name: option [15404,15410]
===
match
---
name: mkdir [34044,34049]
name: mkdir [34044,34049]
===
match
---
funcdef [29001,29367]
funcdef [29001,29367]
===
match
---
atom_expr [26967,26980]
atom_expr [26967,26980]
===
match
---
name: get [10911,10914]
name: get [10911,10914]
===
match
---
trailer [19586,19747]
trailer [19586,19747]
===
match
---
simple_stmt [23590,23622]
simple_stmt [23590,23622]
===
match
---
arglist [37411,37426]
arglist [37389,37404]
===
match
---
name: key [16448,16451]
name: key [16448,16451]
===
match
---
operator: , [26245,26246]
operator: , [26245,26246]
===
match
---
atom_expr [14900,14920]
atom_expr [14900,14920]
===
match
---
operator: , [16446,16447]
operator: , [16446,16447]
===
match
---
atom [15058,15076]
atom [15058,15076]
===
match
---
param [19412,19416]
param [19412,19416]
===
match
---
name: read [34857,34861]
name: read [34857,34861]
===
match
---
name: raw [23974,23977]
name: raw [23974,23977]
===
match
---
operator: , [8458,8459]
operator: , [8458,8459]
===
match
---
operator: , [15959,15960]
operator: , [15959,15960]
===
match
---
name: config_sources [27095,27109]
name: config_sources [27095,27109]
===
match
---
string: '<dict>' [20703,20711]
string: '<dict>' [20703,20711]
===
match
---
operator: , [31434,31435]
operator: , [31434,31435]
===
match
---
trailer [12958,12973]
trailer [12958,12973]
===
match
---
operator: , [27565,27566]
operator: , [27565,27566]
===
match
---
name: full_qualified_path [20082,20101]
name: full_qualified_path [20082,20101]
===
match
---
name: sqlite3 [10217,10224]
name: sqlite3 [10217,10224]
===
match
---
operator: = [27372,27373]
operator: = [27372,27373]
===
match
---
operator: , [25940,25941]
operator: , [25940,25941]
===
match
---
operator: = [22778,22779]
operator: = [22778,22779]
===
match
---
trailer [22076,22093]
trailer [22076,22093]
===
match
---
trailer [43852,43857]
trailer [43830,43835]
===
match
---
trailer [23234,23239]
trailer [23234,23239]
===
match
---
trailer [21555,21569]
trailer [21555,21569]
===
match
---
atom_expr [21777,21826]
atom_expr [21777,21826]
===
match
---
fstring_expr [2745,2753]
fstring_expr [2745,2753]
===
match
---
atom_expr [33364,33394]
atom_expr [33364,33394]
===
match
---
trailer [18555,18589]
trailer [18555,18589]
===
match
---
operator: , [31338,31339]
operator: , [31338,31339]
===
match
---
operator: ** [19787,19789]
operator: ** [19787,19789]
===
match
---
name: section [23842,23849]
name: section [23842,23849]
===
match
---
trailer [40326,40334]
trailer [40304,40312]
===
match
---
operator: , [23901,23902]
operator: , [23901,23902]
===
match
---
simple_stmt [14929,14952]
simple_stmt [14929,14952]
===
match
---
arglist [26905,26914]
arglist [26905,26914]
===
match
---
trailer [14282,14305]
trailer [14282,14305]
===
match
---
operator: = [34650,34651]
operator: = [34650,34651]
===
match
---
name: filename [32287,32295]
name: filename [32287,32295]
===
match
---
name: expand_env_var [32200,32214]
name: expand_env_var [32200,32214]
===
match
---
trailer [35792,35796]
trailer [35792,35796]
===
match
---
string: 'logging' [5333,5342]
string: 'logging' [5333,5342]
===
match
---
simple_stmt [32309,32401]
simple_stmt [32309,32401]
===
match
---
and_test [22034,22114]
and_test [22034,22114]
===
match
---
name: _section [23226,23234]
name: _section [23226,23234]
===
match
---
name: display_sensitive [27333,27350]
name: display_sensitive [27333,27350]
===
match
---
name: read_string [8677,8688]
name: read_string [8677,8688]
===
match
---
simple_stmt [39564,39595]
simple_stmt [39542,39573]
===
match
---
trailer [37821,37832]
trailer [37799,37810]
===
match
---
testlist_comp [7212,7252]
testlist_comp [7212,7252]
===
match
---
fstring_expr [19725,19730]
fstring_expr [19725,19730]
===
match
---
name: ValueError [28041,28051]
name: ValueError [28041,28051]
===
match
---
string: 'default_test.cfg' [30248,30266]
string: 'default_test.cfg' [30248,30266]
===
match
---
testlist_comp [5881,5921]
testlist_comp [5881,5921]
===
match
---
dictorsetmaker [7939,8147]
dictorsetmaker [7939,8147]
===
match
---
name: os [13209,13211]
name: os [13209,13211]
===
match
---
atom_expr [3110,3169]
atom_expr [3110,3169]
===
match
---
operator: * [39959,39960]
operator: * [39937,39938]
===
match
---
atom_expr [42370,42380]
atom_expr [42348,42358]
===
match
---
expr_stmt [22730,22747]
expr_stmt [22730,22747]
===
match
---
operator: , [38616,38617]
operator: , [38594,38595]
===
match
---
name: self [8550,8554]
name: self [8550,8554]
===
match
---
fstring_start: f' [12951,12953]
fstring_start: f' [12951,12953]
===
match
---
name: self [30397,30401]
name: self [30397,30401]
===
match
---
operator: = [31334,31335]
operator: = [31334,31335]
===
match
---
expr_stmt [32406,32448]
expr_stmt [32406,32448]
===
match
---
operator: = [16904,16905]
operator: = [16904,16905]
===
match
---
name: items [22253,22258]
name: items [22253,22258]
===
match
---
operator: + [13376,13377]
operator: + [13376,13377]
===
match
---
name: raw [26862,26865]
name: raw [26862,26865]
===
match
---
arglist [31552,31562]
arglist [31552,31562]
===
match
---
operator: = [14269,14270]
operator: = [14269,14270]
===
match
---
name: fh [32604,32606]
name: fh [32604,32606]
===
match
---
simple_stmt [37481,37509]
simple_stmt [37459,37487]
===
match
---
name: deprecated_key [17905,17919]
name: deprecated_key [17905,17919]
===
match
---
simple_stmt [30126,30187]
simple_stmt [30126,30187]
===
match
---
operator: , [7060,7061]
operator: , [7060,7061]
===
match
---
operator: = [2073,2074]
operator: = [2073,2074]
===
match
---
atom_expr [7838,7879]
atom_expr [7838,7879]
===
match
---
atom_expr [25716,25730]
atom_expr [25716,25730]
===
match
---
trailer [35279,35284]
trailer [35279,35284]
===
match
---
name: secrets_backend_list [41136,41156]
name: secrets_backend_list [41114,41134]
===
match
---
atom_expr [33732,33773]
atom_expr [33732,33773]
===
match
---
suite [14881,15799]
suite [14881,15799]
===
match
---
suite [26337,26428]
suite [26337,26428]
===
match
---
simple_stmt [22699,22714]
simple_stmt [22699,22714]
===
match
---
name: TEST_CONFIG_FILE [33837,33853]
name: TEST_CONFIG_FILE [33837,33853]
===
match
---
name: exist_ok [34064,34072]
name: exist_ok [34064,34072]
===
match
---
trailer [23665,23680]
trailer [23665,23680]
===
match
---
testlist_comp [31606,31686]
testlist_comp [31606,31686]
===
match
---
name: DeprecationWarning [35701,35719]
name: DeprecationWarning [35701,35719]
===
match
---
name: expand_env_var [33229,33243]
name: expand_env_var [33229,33243]
===
match
---
name: name [8896,8900]
name: name [8896,8900]
===
match
---
name: self [20565,20569]
name: self [20565,20569]
===
match
---
fstring_string: .  [2701,2703]
fstring_string: .  [2701,2703]
===
match
---
return_stmt [2770,2783]
return_stmt [2770,2783]
===
match
---
name: args [40336,40340]
name: args [40314,40318]
===
match
---
name: self [8848,8852]
name: self [8848,8852]
===
match
---
string: 'dags' [43779,43785]
string: 'dags' [43757,43763]
===
match
---
atom_expr [20322,20334]
atom_expr [20322,20334]
===
match
---
name: env_var [27938,27945]
name: env_var [27938,27945]
===
match
---
simple_stmt [41911,41963]
simple_stmt [41889,41941]
===
match
---
name: os [860,862]
name: os [860,862]
===
match
---
suite [22282,22320]
suite [22282,22320]
===
match
---
atom [25755,25849]
atom [25755,25849]
===
match
---
fstring_string: The object could not be loaded. Please check " [20395,20441]
fstring_string: The object could not be loaded. Please check " [20395,20441]
===
match
---
string: 'airflow_home' [35805,35819]
string: 'airflow_home' [35805,35819]
===
match
---
atom_expr [15262,15353]
atom_expr [15262,15353]
===
match
---
atom_expr [43108,43127]
atom_expr [43086,43105]
===
match
---
name: __init__ [8515,8523]
name: __init__ [8515,8523]
===
match
---
parameters [33418,33420]
parameters [33418,33420]
===
match
---
operator: , [7502,7503]
operator: , [7502,7503]
===
match
---
name: _warn_deprecate [17769,17784]
name: _warn_deprecate [17769,17784]
===
match
---
name: kwargs [19467,19473]
name: kwargs [19467,19473]
===
match
---
name: OrderedDict [22219,22230]
name: OrderedDict [22219,22230]
===
match
---
trailer [26904,26915]
trailer [26904,26915]
===
match
---
trailer [32603,32622]
trailer [32603,32622]
===
match
---
operator: , [18028,18029]
operator: , [18028,18029]
===
match
---
name: self [9554,9558]
name: self [9554,9558]
===
match
---
string: 'config_templates' [3150,3168]
string: 'config_templates' [3150,3168]
===
match
---
tfpdef [21760,21772]
tfpdef [21760,21772]
===
match
---
operator: , [4024,4025]
operator: , [4024,4025]
===
match
---
operator: , [6925,6926]
operator: , [6925,6926]
===
match
---
name: os [32147,32149]
name: os [32147,32149]
===
match
---
name: d [32933,32934]
name: d [32933,32934]
===
match
---
operator: } [7905,7906]
operator: } [7905,7906]
===
match
---
suite [19178,19379]
suite [19178,19379]
===
match
---
name: has_section [22174,22185]
name: has_section [22174,22185]
===
match
---
fstring_string: " key in " [19659,19669]
fstring_string: " key in " [19659,19669]
===
match
---
string: """Runs command and returns stdout""" [2277,2314]
string: """Runs command and returns stdout""" [2277,2314]
===
match
---
comparison [35336,35384]
comparison [35336,35384]
===
match
---
simple_stmt [38224,38262]
simple_stmt [38202,38240]
===
match
---
string: 'TEST_CONFIG_FILE_PATH' [42673,42696]
string: 'TEST_CONFIG_FILE_PATH' [42651,42674]
===
match
---
simple_stmt [18546,18606]
simple_stmt [18546,18606]
===
match
---
trailer [42033,42056]
trailer [42011,42034]
===
match
---
simple_stmt [21836,22023]
simple_stmt [21836,22023]
===
match
---
name: deprecated_key [16704,16718]
name: deprecated_key [16704,16718]
===
match
---
string: 'statsd_custom_client_path' [7001,7028]
string: 'statsd_custom_client_path' [7001,7028]
===
match
---
name: _get_secret_option [16555,16573]
name: _get_secret_option [16555,16573]
===
match
---
testlist_comp [23073,23084]
testlist_comp [23073,23084]
===
match
---
string: 'scheduler' [7049,7060]
string: 'scheduler' [7049,7060]
===
match
---
expr_stmt [27491,27519]
expr_stmt [27491,27519]
===
match
---
parameters [17987,18043]
parameters [17987,18043]
===
match
---
param [18507,18512]
param [18507,18512]
===
match
---
name: _include_envs [26053,26066]
name: _include_envs [26053,26066]
===
match
---
operator: = [42271,42272]
operator: = [42249,42250]
===
match
---
name: key [22730,22733]
name: key [22730,22733]
===
match
---
simple_stmt [26189,26268]
simple_stmt [26189,26268]
===
match
---
return_stmt [15708,15721]
return_stmt [15708,15721]
===
match
---
comparison [13840,13886]
comparison [13840,13886]
===
match
---
testlist_comp [4088,4110]
testlist_comp [4088,4110]
===
match
---
string: '%' [26905,26908]
string: '%' [26905,26908]
===
match
---
name: fh [42403,42405]
name: fh [42381,42383]
===
match
---
testlist_comp [5089,5115]
testlist_comp [5089,5115]
===
match
---
suite [21668,21734]
suite [21668,21734]
===
match
---
name: Path [34572,34576]
name: Path [34572,34576]
===
match
---
simple_stmt [28484,28510]
simple_stmt [28484,28510]
===
match
---
operator: , [4641,4642]
operator: , [4641,4642]
===
match
---
operator: , [5794,5795]
operator: , [5794,5795]
===
match
---
name: args [40363,40367]
name: args [40341,40345]
===
match
---
param [17994,18009]
param [17994,18009]
===
match
---
operator: , [30475,30476]
operator: , [30475,30476]
===
match
---
trailer [9083,9103]
trailer [9083,9103]
===
match
---
name: file [34285,34289]
name: file [34285,34289]
===
match
---
name: min_sqlite_version [10446,10464]
name: min_sqlite_version [10446,10464]
===
match
---
operator: } [2700,2701]
operator: } [2700,2701]
===
match
---
decorated [30430,31480]
decorated [30430,31480]
===
match
---
atom_expr [23226,23239]
atom_expr [23226,23239]
===
match
---
name: _TEST_DAGS_FOLDER [43705,43722]
name: _TEST_DAGS_FOLDER [43683,43700]
===
match
---
operator: , [5068,5069]
operator: , [5068,5069]
===
match
---
testlist_comp [4163,4189]
testlist_comp [4163,4189]
===
match
---
name: json [1207,1211]
name: json [1207,1211]
===
match
---
operator: , [20128,20129]
operator: , [20128,20129]
===
match
---
atom_expr [23765,23779]
atom_expr [23765,23779]
===
match
---
testlist_comp [28455,28469]
testlist_comp [28455,28469]
===
match
---
operator: = [23318,23319]
operator: = [23318,23319]
===
match
---
operator: { [2681,2682]
operator: { [2681,2682]
===
match
---
name: option [16897,16903]
name: option [16897,16903]
===
match
---
atom_expr [22371,22420]
atom_expr [22371,22420]
===
match
---
string: 'core' [33748,33754]
string: 'core' [33748,33754]
===
match
---
atom_expr [34652,34682]
atom_expr [34652,34682]
===
match
---
atom_expr [42403,42412]
atom_expr [42381,42390]
===
match
---
operator: , [42764,42765]
operator: , [42742,42743]
===
match
---
name: returncode [2690,2700]
name: returncode [2690,2700]
===
match
---
name: DeprecationWarning [39416,39434]
name: DeprecationWarning [39394,39412]
===
match
---
operator: , [5408,5409]
operator: , [5408,5409]
===
match
---
suite [2587,2765]
suite [2587,2765]
===
match
---
name: get [14279,14282]
name: get [14279,14282]
===
match
---
operator: , [29305,29306]
operator: , [29305,29306]
===
match
---
name: section [21061,21068]
name: section [21061,21068]
===
match
---
name: _get_env_var_option [18259,18278]
name: _get_env_var_option [18259,18278]
===
match
---
trailer [12982,12988]
trailer [12982,12988]
===
match
---
trailer [27843,27854]
trailer [27843,27854]
===
match
---
operator: , [38984,38985]
operator: , [38962,38963]
===
match
---
param [20582,20595]
param [20582,20595]
===
match
---
testlist_comp [27441,27451]
testlist_comp [27441,27451]
===
match
---
string: "Reading test configuration from %s" [30333,30369]
string: "Reading test configuration from %s" [30333,30369]
===
match
---
atom_expr [17134,17204]
atom_expr [17134,17204]
===
match
---
name: self [26189,26193]
name: self [26189,26193]
===
match
---
operator: , [13050,13051]
operator: , [13050,13051]
===
match
---
name: k [29599,29600]
name: k [29599,29600]
===
match
---
argument [31230,31260]
argument [31230,31260]
===
match
---
trailer [14652,14675]
trailer [14652,14675]
===
match
---
trailer [33923,33928]
trailer [33923,33928]
===
match
---
return_stmt [39046,39085]
return_stmt [39024,39063]
===
match
---
string: "'conf.load_test_config'" [36930,36955]
string: "'conf.load_test_config'" [36908,36933]
===
match
---
dictorsetmaker [7721,7774]
dictorsetmaker [7721,7774]
===
match
---
name: val [23147,23150]
name: val [23147,23150]
===
match
---
operator: { [12953,12954]
operator: { [12953,12954]
===
match
---
trailer [16050,16074]
trailer [16050,16074]
===
match
---
name: DeprecationWarning [1660,1678]
name: DeprecationWarning [1660,1678]
===
match
---
return_stmt [18453,18466]
return_stmt [18453,18466]
===
match
---
trailer [43125,43127]
trailer [43103,43105]
===
match
---
string: 'DEFAULT_CONFIG' [42601,42617]
string: 'DEFAULT_CONFIG' [42579,42595]
===
match
---
for_stmt [8892,9545]
for_stmt [8892,9545]
===
match
---
trailer [8688,8704]
trailer [8688,8704]
===
match
---
operator: , [7419,7420]
operator: , [7419,7420]
===
match
---
comp_op [8630,8636]
comp_op [8630,8636]
===
match
---
subscriptlist [25711,25730]
subscriptlist [25711,25730]
===
match
---
testlist_comp [2468,2553]
testlist_comp [2468,2553]
===
match
---
atom [4634,4670]
atom [4634,4670]
===
match
---
param [23295,23323]
param [23295,23323]
===
match
---
trailer [14639,14641]
trailer [14639,14641]
===
match
---
trailer [23680,23741]
trailer [23680,23741]
===
match
---
name: kwargs [19102,19108]
name: kwargs [19102,19108]
===
match
---
expr_stmt [14486,14516]
expr_stmt [14486,14516]
===
match
---
trailer [32973,32979]
trailer [32973,32979]
===
match
---
operator: } [12973,12974]
operator: } [12973,12974]
===
match
---
trailer [17699,17710]
trailer [17699,17710]
===
match
---
trailer [30199,30211]
trailer [30199,30211]
===
match
---
argument [39444,39456]
argument [39422,39434]
===
match
---
name: key [13496,13499]
name: key [13496,13499]
===
match
---
name: len [41048,41051]
name: len [41026,41029]
===
match
---
trailer [3122,3169]
trailer [3122,3169]
===
match
---
arglist [27251,27263]
arglist [27251,27263]
===
match
---
trailer [20613,20618]
trailer [20613,20618]
===
match
---
name: get_airflow_config [43401,43419]
name: get_airflow_config [43379,43397]
===
match
---
return_stmt [2176,2195]
return_stmt [2176,2195]
===
match
---
trailer [28894,28896]
trailer [28894,28896]
===
match
---
return_stmt [14826,14837]
return_stmt [14826,14837]
===
match
---
name: self [11346,11350]
name: self [11346,11350]
===
match
---
suite [18537,19016]
suite [18537,19016]
===
match
---
operator: , [1282,1283]
operator: , [1282,1283]
===
match
---
name: default_config [33585,33599]
name: default_config [33585,33599]
===
match
---
return_stmt [16736,16749]
return_stmt [16736,16749]
===
match
---
operator: , [16850,16851]
operator: , [16850,16851]
===
match
---
trailer [17878,17880]
trailer [17878,17880]
===
match
---
name: option [15560,15566]
name: option [15560,15566]
===
match
---
trailer [3188,3193]
trailer [3188,3193]
===
match
---
name: path [43903,43907]
name: path [43881,43885]
===
match
---
atom_expr [26625,26662]
atom_expr [26625,26662]
===
match
---
not_test [28216,28237]
not_test [28216,28237]
===
match
---
name: generate_key [34112,34124]
name: generate_key [34112,34124]
===
match
---
import_from [1345,1420]
import_from [1345,1420]
===
match
---
fstring [2638,2704]
fstring [2638,2704]
===
match
---
simple_stmt [18788,18801]
simple_stmt [18788,18801]
===
match
---
name: str [25721,25724]
name: str [25721,25724]
===
match
---
name: sqlite_version [10513,10527]
name: sqlite_version [10513,10527]
===
match
---
atom [4593,7509]
atom [4593,7509]
===
match
---
testlist_comp [13841,13853]
testlist_comp [13841,13853]
===
match
---
param [16324,16343]
param [16324,16343]
===
match
---
with_stmt [42531,42579]
with_stmt [42509,42557]
===
match
---
param [29472,29487]
param [29472,29487]
===
match
---
name: warn [35411,35415]
name: warn [35411,35415]
===
match
---
atom_expr [31965,32008]
atom_expr [31965,32008]
===
match
---
simple_stmt [21052,21095]
simple_stmt [21052,21095]
===
match
---
trailer [18258,18278]
trailer [18258,18278]
===
match
---
fstring_string: Failed to convert value to bool. Please check " [18875,18922]
fstring_string: Failed to convert value to bool. Please check " [18875,18922]
===
match
---
testlist_comp [4122,4151]
testlist_comp [4122,4151]
===
match
---
operator: = [4591,4592]
operator: = [4591,4592]
===
match
---
name: load_test_config [34315,34331]
name: load_test_config [34315,34331]
===
match
---
string: "'conf.has_option'" [39387,39406]
string: "'conf.has_option'" [39365,39384]
===
match
---
funcdef [18492,19016]
funcdef [18492,19016]
===
match
---
if_stmt [28213,28401]
if_stmt [28213,28401]
===
match
---
name: self [23285,23289]
name: self [23285,23289]
===
match
---
name: deprecated_section [17169,17187]
name: deprecated_section [17169,17187]
===
match
---
operator: ** [17635,17637]
operator: ** [17635,17637]
===
match
---
param [13037,13042]
param [13037,13042]
===
match
---
name: key [22814,22817]
name: key [22814,22817]
===
match
---
param [29493,29501]
param [29493,29501]
===
match
---
name: old [11921,11924]
name: old [11921,11924]
===
match
---
name: self [26577,26581]
name: self [26577,26581]
===
match
---
string: 'remote_base_log_folder' [4966,4990]
string: 'remote_base_log_folder' [4966,4990]
===
match
---
if_stmt [41359,41701]
if_stmt [41337,41679]
===
match
---
expr_stmt [14929,14951]
expr_stmt [14929,14951]
===
match
---
name: List [1268,1272]
name: List [1268,1272]
===
match
---
name: _using_old_value [9067,9083]
name: _using_old_value [9067,9083]
===
match
---
name: self [26484,26488]
name: self [26484,26488]
===
match
---
string: """Historical getsection""" [38717,38744]
string: """Historical getsection""" [38695,38722]
===
match
---
simple_stmt [23793,23871]
simple_stmt [23793,23871]
===
match
---
atom_expr [31950,32009]
atom_expr [31950,32009]
===
match
---
string: 'core' [5699,5705]
string: 'core' [5699,5705]
===
match
---
operator: = [14999,15000]
operator: = [14999,15000]
===
match
---
name: keys [22520,22524]
name: keys [22520,22524]
===
match
---
raise_stmt [18827,19015]
raise_stmt [18827,19015]
===
match
---
name: os [43546,43548]
name: os [43524,43526]
===
match
---
string: "Accessing configuration method 'get' directly from the configuration module is " [37135,37216]
string: "Accessing configuration method 'get' directly from the configuration module is " [37113,37194]
===
match
---
trailer [42192,42215]
trailer [42170,42193]
===
match
---
name: docs [10313,10317]
name: docs [10313,10317]
===
match
---
dictorsetmaker [31538,31700]
dictorsetmaker [31538,31700]
===
match
---
name: name [11999,12003]
name: name [11999,12003]
===
match
---
name: stdout [2377,2383]
name: stdout [2377,2383]
===
match
---
operator: , [20638,20639]
operator: , [20638,20639]
===
match
---
arglist [21717,21732]
arglist [21717,21732]
===
match
---
operator: , [30861,30862]
operator: , [30861,30862]
===
match
---
decorator [42415,42450]
decorator [42393,42428]
===
match
---
name: getsection [39058,39068]
name: getsection [39036,39046]
===
match
---
argument [9408,9435]
argument [9408,9435]
===
match
---
fstring [18873,18958]
fstring [18873,18958]
===
match
---
string: 'log_format' [5608,5620]
string: 'log_format' [5608,5620]
===
match
---
funcdef [42873,43199]
funcdef [42851,43177]
===
match
---
atom_expr [3181,3219]
atom_expr [3181,3219]
===
match
---
trailer [14918,14920]
trailer [14918,14920]
===
match
---
name: kwargs [39112,39118]
name: kwargs [39090,39096]
===
match
---
name: functools [42244,42253]
name: functools [42222,42231]
===
match
---
atom_expr [34890,34929]
atom_expr [34890,34929]
===
match
---
atom_expr [33174,33217]
atom_expr [33174,33217]
===
match
---
expr_stmt [2450,2554]
expr_stmt [2450,2554]
===
match
---
trailer [34905,34929]
trailer [34905,34929]
===
match
---
string: 'metrics' [6946,6955]
string: 'metrics' [6946,6955]
===
match
---
name: conf [38231,38235]
name: conf [38209,38213]
===
match
---
name: args [37866,37870]
name: args [37844,37848]
===
match
---
atom_expr [42173,42215]
atom_expr [42151,42193]
===
match
---
string: """Historical has_option""" [39139,39166]
string: """Historical has_option""" [39117,39144]
===
match
---
atom [31524,31710]
atom [31524,31710]
===
match
---
operator: , [12916,12917]
operator: , [12916,12917]
===
match
---
operator: ** [39110,39112]
operator: ** [39088,39090]
===
match
---
trailer [14641,14652]
trailer [14641,14652]
===
match
---
name: self [29965,29969]
name: self [29965,29969]
===
match
---
operator: , [6563,6564]
operator: , [6563,6564]
===
match
---
if_stmt [18153,18202]
if_stmt [18153,18202]
===
match
---
name: _write_section [23798,23812]
name: _write_section [23798,23812]
===
match
---
arglist [15137,15185]
arglist [15137,15185]
===
match
---
name: fallback_key [14662,14674]
name: fallback_key [14662,14674]
===
match
---
arglist [20740,20776]
arglist [20740,20776]
===
match
---
suite [32475,32623]
suite [32475,32623]
===
match
---
trailer [43883,43928]
trailer [43861,43906]
===
match
---
atom [7133,7163]
atom [7133,7163]
===
match
---
except_clause [20285,20308]
except_clause [20285,20308]
===
match
---
name: path [30065,30069]
name: path [30065,30069]
===
match
---
suite [34735,34779]
suite [34735,34779]
===
match
---
trailer [33385,33392]
trailer [33385,33392]
===
match
---
testlist_comp [7085,7122]
testlist_comp [7085,7122]
===
match
---
atom_expr [13255,13274]
atom_expr [13255,13274]
===
match
---
name: val [18684,18687]
name: val [18684,18687]
===
match
---
name: args [39960,39964]
name: args [39938,39942]
===
match
---
return_stmt [41639,41700]
return_stmt [41617,41678]
===
match
---
name: opt [26995,26998]
name: opt [26995,26998]
===
match
---
atom_expr [8550,8571]
atom_expr [8550,8571]
===
match
---
expr_stmt [8988,9042]
expr_stmt [8988,9042]
===
match
---
trailer [27951,27960]
trailer [27951,27960]
===
match
---
argument [16065,16073]
argument [16065,16073]
===
match
---
decorated [28983,29367]
decorated [28983,29367]
===
match
---
atom_expr [34788,34842]
atom_expr [34788,34842]
===
match
---
number: 2 [38615,38616]
number: 2 [38593,38594]
===
match
---
name: get_custom_secret_backend [41163,41188]
name: get_custom_secret_backend [41141,41166]
===
match
---
not_test [27329,27350]
not_test [27329,27350]
===
match
---
atom_expr [39475,39507]
atom_expr [39453,39485]
===
match
---
fstring_start: f" [11759,11761]
fstring_start: f" [11759,11761]
===
match
---
name: v [32967,32968]
name: v [32967,32968]
===
match
---
operator: ** [8531,8533]
operator: ** [8531,8533]
===
match
---
atom_expr [9004,9042]
atom_expr [9004,9042]
===
match
---
operator: , [19410,19411]
operator: , [19410,19411]
===
match
---
name: deprecated_key [15615,15629]
name: deprecated_key [15615,15629]
===
match
---
atom_expr [43580,43623]
atom_expr [43558,43601]
===
match
---
arglist [23813,23869]
arglist [23813,23869]
===
match
---
try_stmt [22957,23214]
try_stmt [22957,23214]
===
match
---
operator: , [23983,23984]
operator: , [23983,23984]
===
match
---
trailer [42715,42764]
trailer [42693,42742]
===
match
---
arglist [9084,9102]
arglist [9084,9102]
===
match
---
arglist [17885,17929]
arglist [17885,17929]
===
match
---
name: warn [30583,30587]
name: warn [30583,30587]
===
match
---
name: name [9332,9336]
name: name [9332,9336]
===
match
---
name: warn [37121,37125]
name: warn [37099,37103]
===
match
---
operator: , [8900,8901]
operator: , [8900,8901]
===
match
---
trailer [31854,31863]
trailer [31854,31863]
===
match
---
operator: = [38614,38615]
operator: = [38592,38593]
===
match
---
operator: , [32948,32949]
operator: , [32948,32949]
===
match
---
simple_stmt [9279,9545]
simple_stmt [9279,9545]
===
match
---
atom_expr [11921,11946]
atom_expr [11921,11946]
===
match
---
operator: , [22632,22633]
operator: , [22632,22633]
===
match
---
strings [40047,40253]
strings [40025,40231]
===
match
---
simple_stmt [10078,10176]
simple_stmt [10078,10176]
===
match
---
name: os [2094,2096]
name: os [2094,2096]
===
match
---
trailer [8659,8676]
trailer [8659,8676]
===
match
---
atom_expr [35271,35318]
atom_expr [35271,35318]
===
match
---
fstring_end: ' [18957,18958]
fstring_end: ' [18957,18958]
===
match
---
param [20696,20711]
param [20696,20711]
===
match
---
name: PY37 [44463,44467]
name: PY37 [44457,44461]
===
match
---
operator: , [41496,41497]
operator: , [41474,41475]
===
match
---
name: get [16047,16050]
name: get [16047,16050]
===
match
---
arglist [31230,31380]
arglist [31230,31380]
===
match
---
trailer [31833,31841]
trailer [31833,31841]
===
match
---
atom_expr [35402,35738]
atom_expr [35402,35738]
===
match
---
trailer [37021,37038]
trailer [36999,37016]
===
match
---
operator: = [18252,18253]
operator: = [18252,18253]
===
match
---
except_clause [19160,19177]
except_clause [19160,19177]
===
match
---
name: warnings [30988,30996]
name: warnings [30988,30996]
===
match
---
atom_expr [37513,37805]
atom_expr [37491,37783]
===
match
---
name: airflow [1426,1433]
name: airflow [1426,1433]
===
match
---
name: parents [34597,34604]
name: parents [34597,34604]
===
match
---
trailer [9139,9143]
trailer [9139,9143]
===
match
---
name: deprecated_section [17059,17077]
name: deprecated_section [17059,17077]
===
match
---
name: _section [23261,23269]
name: _section [23261,23269]
===
match
---
name: section_prefix [22430,22444]
name: section_prefix [22430,22444]
===
match
---
name: super [14271,14276]
name: super [14271,14276]
===
match
---
operator: { [20441,20442]
operator: { [20441,20442]
===
match
---
operator: , [15844,15845]
operator: , [15844,15845]
===
match
---
name: sys [1588,1591]
name: sys [1588,1591]
===
match
---
param [21215,21220]
param [21215,21220]
===
match
---
name: cryptography [33318,33330]
name: cryptography [33318,33330]
===
match
---
string: 'The {old_key} option in [{old_section}] has been moved to the {new_key} option in ' [31019,31103]
string: 'The {old_key} option in [{old_section}] has been moved to the {new_key} option in ' [31019,31103]
===
match
---
testlist_comp [7166,7200]
testlist_comp [7166,7200]
===
match
---
name: exist_ok [34611,34619]
name: exist_ok [34611,34619]
===
match
---
trailer [22252,22258]
trailer [22252,22258]
===
match
---
arglist [10915,10940]
arglist [10915,10940]
===
match
---
operator: , [39496,39497]
operator: , [39474,39475]
===
match
---
param [14027,14032]
param [14027,14032]
===
match
---
expr_stmt [29529,29585]
expr_stmt [29529,29585]
===
match
---
simple_stmt [28315,28334]
simple_stmt [28315,28334]
===
match
---
return_stmt [17940,17951]
return_stmt [17940,17951]
===
match
---
fstring_expr [20456,20465]
fstring_expr [20456,20465]
===
match
---
expr_stmt [15576,15664]
expr_stmt [15576,15664]
===
match
---
name: old [8947,8950]
name: old [8947,8950]
===
match
---
name: sect [29734,29738]
name: sect [29734,29738]
===
match
---
if_stmt [34381,34779]
if_stmt [34381,34779]
===
match
---
simple_stmt [11914,11959]
simple_stmt [11914,11959]
===
match
---
if_stmt [13393,13594]
if_stmt [13393,13594]
===
match
---
name: AIRFLOW_HOME [44084,44096]
name: AIRFLOW_HOME [44062,44074]
===
match
---
simple_stmt [40451,40730]
simple_stmt [40429,40708]
===
match
---
operator: , [17992,17993]
operator: , [17992,17993]
===
match
---
name: self [15840,15844]
name: self [15840,15844]
===
match
---
name: self [31552,31556]
name: self [31552,31556]
===
match
---
testlist_star_expr [2450,2464]
testlist_star_expr [2450,2464]
===
match
---
simple_stmt [44224,44289]
simple_stmt [44202,44267]
===
match
---
name: v [32927,32928]
name: v [32927,32928]
===
match
---
name: secrets_backend_cls [41646,41665]
name: secrets_backend_cls [41624,41643]
===
match
---
name: super [20606,20611]
name: super [20606,20611]
===
match
---
operator: , [20811,20812]
operator: , [20811,20812]
===
match
---
name: stacklevel [37786,37796]
name: stacklevel [37764,37774]
===
match
---
string: 'core' [9977,9983]
string: 'core' [9977,9983]
===
match
---
subscriptlist [24091,24099]
subscriptlist [24091,24099]
===
match
---
operator: } [28975,28976]
operator: } [28975,28976]
===
match
---
string: 'environment variable and remove the config file entry.' [35139,35195]
string: 'environment variable and remove the config file entry.' [35139,35195]
===
match
---
param [39966,39974]
param [39944,39952]
===
match
---
param [37865,37871]
param [37843,37849]
===
match
---
testlist_comp [5119,5151]
testlist_comp [5119,5151]
===
match
---
name: optionstr [8426,8435]
name: optionstr [8426,8435]
===
match
---
suite [17436,17646]
suite [17436,17646]
===
match
---
operator: = [28452,28453]
operator: = [28452,28453]
===
match
---
suite [11077,11334]
suite [11077,11334]
===
match
---
operator: , [9521,9522]
operator: , [9521,9522]
===
match
---
operator: , [5654,5655]
operator: , [5654,5655]
===
match
---
operator: , [19093,19094]
operator: , [19093,19094]
===
match
---
atom_expr [21548,21586]
atom_expr [21548,21586]
===
match
---
name: file_parser_modes [11805,11822]
name: file_parser_modes [11805,11822]
===
match
---
trailer [29738,29741]
trailer [29738,29741]
===
match
---
name: remove_section [29999,30013]
name: remove_section [29999,30013]
===
match
---
trailer [31797,31810]
trailer [31797,31810]
===
match
---
name: self [10832,10836]
name: self [10832,10836]
===
match
---
name: self [22152,22156]
name: self [22152,22156]
===
match
---
name: section [16349,16356]
name: section [16349,16356]
===
match
---
name: re [9137,9139]
name: re [9137,9139]
===
match
---
name: key [22705,22708]
name: key [22705,22708]
===
match
---
atom_expr [3386,3431]
atom_expr [3386,3431]
===
match
---
name: deprecated_section [18010,18028]
name: deprecated_section [18010,18028]
===
match
---
atom_expr [9279,9544]
atom_expr [9279,9544]
===
match
---
name: List [40800,40804]
name: List [40778,40782]
===
match
---
name: version_info [44433,44445]
name: version_info [44427,44439]
===
match
---
operator: , [18768,18769]
operator: , [18768,18769]
===
match
---
suite [2272,2784]
suite [2272,2784]
===
match
---
trailer [8778,8808]
trailer [8778,8808]
===
match
---
argument [9332,9341]
argument [9332,9341]
===
match
---
comparison [15365,15383]
comparison [15365,15383]
===
match
---
simple_stmt [42305,42361]
simple_stmt [42283,42339]
===
match
---
name: replacement [8910,8921]
name: replacement [8910,8921]
===
match
---
name: os [36291,36293]
name: os [36291,36293]
===
match
---
string: 'dag_processor_manager_log_location' [6127,6163]
string: 'dag_processor_manager_log_location' [6127,6163]
===
match
---
operator: , [9341,9342]
operator: , [9341,9342]
===
match
---
string: """Historical get""" [37087,37107]
string: """Historical get""" [37065,37085]
===
match
---
suite [23177,23214]
suite [23177,23214]
===
match
---
testlist_comp [6238,6272]
testlist_comp [6238,6272]
===
match
---
trailer [11122,11333]
trailer [11122,11333]
===
match
---
name: deprecated_section [15476,15494]
name: deprecated_section [15476,15494]
===
match
---
simple_stmt [37112,37391]
simple_stmt [37090,37369]
===
match
---
arglist [8587,8602]
arglist [8587,8602]
===
match
---
name: self [9968,9972]
name: self [9968,9972]
===
match
---
strings [31019,31201]
strings [31019,31201]
===
match
---
arglist [20619,20657]
arglist [20619,20657]
===
match
---
fstring [10722,10801]
fstring [10722,10801]
===
match
---
name: config [29283,29289]
name: config [29283,29289]
===
match
---
trailer [23727,23729]
trailer [23727,23729]
===
match
---
operator: , [29486,29487]
operator: , [29486,29487]
===
match
---
param [38275,38281]
param [38253,38259]
===
match
---
simple_stmt [14961,15087]
simple_stmt [14961,15087]
===
match
---
operator: , [5078,5079]
operator: , [5078,5079]
===
match
---
string: "'conf.getsection'" [38965,38984]
string: "'conf.getsection'" [38943,38962]
===
match
---
atom [5332,5366]
atom [5332,5366]
===
match
---
operator: , [38686,38687]
operator: , [38664,38665]
===
match
---
operator: = [44306,44307]
operator: = [44284,44285]
===
match
---
operator: { [19356,19357]
operator: { [19356,19357]
===
match
---
fstring_end: " [43196,43197]
fstring_end: " [43174,43175]
===
match
---
operator: , [20137,20138]
operator: , [20137,20138]
===
match
---
atom_expr [20242,20276]
atom_expr [20242,20276]
===
match
---
tfpdef [3073,3087]
tfpdef [3073,3087]
===
match
---
return_stmt [38628,38663]
return_stmt [38606,38641]
===
match
---
operator: , [6244,6245]
operator: , [6244,6245]
===
match
---
string: 'scheduler' [6310,6321]
string: 'scheduler' [6310,6321]
===
match
---
param [15846,15854]
param [15846,15854]
===
match
---
operator: , [17162,17163]
operator: , [17162,17163]
===
match
---
string: 'true' [18697,18703]
string: 'true' [18697,18703]
===
match
---
trailer [2366,2375]
trailer [2366,2375]
===
match
---
param [23897,23902]
param [23897,23902]
===
match
---
name: self [27983,27987]
name: self [27983,27987]
===
match
---
trailer [36095,36112]
trailer [36095,36112]
===
match
---
name: deprecated_section [16324,16342]
name: deprecated_section [16324,16342]
===
match
---
suite [41223,41717]
suite [41201,41695]
===
match
---
trailer [34331,34333]
trailer [34331,34333]
===
match
---
operator: = [42443,42444]
operator: = [42421,42422]
===
match
---
if_stmt [44456,44521]
if_stmt [44450,44515]
===
match
---
arglist [1726,1796]
arglist [1726,1796]
===
match
---
simple_stmt [2450,2555]
simple_stmt [2450,2555]
===
match
---
testlist_comp [6891,6934]
testlist_comp [6891,6934]
===
match
---
parameters [31900,31902]
parameters [31900,31902]
===
match
---
simple_stmt [22596,22638]
simple_stmt [22596,22638]
===
match
---
name: os [43900,43902]
name: os [43878,43880]
===
match
---
operator: , [14290,14291]
operator: , [14290,14291]
===
match
---
name: key [27932,27935]
name: key [27932,27935]
===
match
---
param [39535,39543]
param [39513,39521]
===
match
---
operator: = [33600,33601]
operator: = [33600,33601]
===
match
---
name: section [12904,12911]
name: section [12904,12911]
===
match
---
string: '_cmd' [14077,14083]
string: '_cmd' [14077,14083]
===
match
---
funcdef [12298,12841]
funcdef [12298,12841]
===
match
---
atom [32938,32959]
atom [32938,32959]
===
match
---
if_stmt [9059,9545]
if_stmt [9059,9545]
===
match
---
operator: = [20769,20770]
operator: = [20769,20770]
===
match
---
trailer [31967,31975]
trailer [31967,31975]
===
match
---
atom_expr [30324,30388]
atom_expr [30324,30388]
===
match
---
return_stmt [40315,40351]
return_stmt [40293,40329]
===
match
---
atom [5010,5040]
atom [5010,5040]
===
match
---
decorator [12280,12294]
decorator [12280,12294]
===
match
---
argument [42436,42448]
argument [42414,42426]
===
match
---
name: self [9062,9066]
name: self [9062,9066]
===
match
---
name: option [21527,21533]
name: option [21527,21533]
===
match
---
operator: = [29630,29631]
operator: = [29630,29631]
===
match
---
argument [39928,39933]
argument [39906,39911]
===
match
---
if_stmt [36033,36115]
if_stmt [36033,36115]
===
match
---
name: display_sensitive [27700,27717]
name: display_sensitive [27700,27717]
===
match
---
trailer [3390,3431]
trailer [3390,3431]
===
match
---
simple_stmt [27532,27601]
simple_stmt [27532,27601]
===
match
---
name: os_environment [27829,27843]
name: os_environment [27829,27843]
===
match
---
testlist_comp [7356,7401]
testlist_comp [7356,7401]
===
match
---
name: section [28484,28491]
name: section [28484,28491]
===
match
---
operator: , [16845,16846]
operator: , [16845,16846]
===
match
---
operator: , [25915,25916]
operator: , [25915,25916]
===
match
---
string: 'simple_log_format' [5676,5695]
string: 'simple_log_format' [5676,5695]
===
match
---
name: self [10906,10910]
name: self [10906,10910]
===
match
---
name: name [43120,43124]
name: name [43098,43102]
===
match
---
string: "deprecated. Please access the configuration from the 'configuration.conf' object via " [39722,39809]
string: "deprecated. Please access the configuration from the 'configuration.conf' object via " [39700,39787]
===
match
---
name: _UNSET [1134,1140]
name: _UNSET [1134,1140]
===
match
---
simple_stmt [2319,2446]
simple_stmt [2319,2446]
===
match
---
import_from [1243,1289]
import_from [1243,1289]
===
match
---
name: remove_option [39514,39527]
name: remove_option [39492,39505]
===
match
---
operator: , [1266,1267]
operator: , [1266,1267]
===
match
---
trailer [36364,36431]
trailer [36364,36431]
===
match
---
name: deprecated_key [17189,17203]
name: deprecated_key [17189,17203]
===
match
---
return_stmt [22128,22139]
return_stmt [22128,22139]
===
match
---
name: env_var [28242,28249]
name: env_var [28242,28249]
===
match
---
arglist [40750,40765]
arglist [40728,40743]
===
match
---
arglist [13173,13185]
arglist [13173,13185]
===
match
---
name: r [32683,32684]
name: r [32683,32684]
===
match
---
return_stmt [8419,8435]
return_stmt [8419,8435]
===
match
---
fstring_end: ' [19320,19321]
fstring_end: ' [19320,19321]
===
match
---
name: raw [29083,29086]
name: raw [29083,29086]
===
match
---
parameters [14397,14417]
parameters [14397,14417]
===
match
---
name: get [19082,19085]
name: get [19082,19085]
===
match
---
name: path [2097,2101]
name: path [2097,2101]
===
match
---
trailer [44417,44419]
trailer [44395,44397]
===
match
---
string: 'false' [18761,18768]
string: 'false' [18761,18768]
===
match
---
name: compile [7977,7984]
name: compile [7977,7984]
===
match
---
argument [37840,37848]
argument [37818,37826]
===
match
---
trailer [36293,36298]
trailer [36293,36298]
===
match
---
operator: , [41337,41338]
operator: , [41315,41316]
===
match
---
string: 'logging' [5503,5512]
string: 'logging' [5503,5512]
===
match
---
name: NoOptionError [21135,21148]
name: NoOptionError [21135,21148]
===
match
---
simple_stmt [16736,16750]
simple_stmt [16736,16750]
===
match
---
fstring_end: " [10700,10701]
fstring_end: " [10700,10701]
===
match
---
operator: , [26523,26524]
operator: , [26523,26524]
===
match
---
param [16302,16307]
param [16302,16307]
===
match
---
suite [9104,9545]
suite [9104,9545]
===
match
---
simple_stmt [15708,15722]
simple_stmt [15708,15722]
===
match
---
import_from [10294,10337]
import_from [10294,10337]
===
match
---
trailer [43907,43916]
trailer [43885,43894]
===
match
---
operator: ** [38252,38254]
operator: ** [38230,38232]
===
match
---
operator: , [18008,18009]
operator: , [18008,18009]
===
match
---
comparison [41971,42004]
comparison [41949,41982]
===
match
---
atom [4789,4824]
atom [4789,4824]
===
match
---
operator: = [9572,9573]
operator: = [9572,9573]
===
match
---
string: 'log_filename_template' [5854,5877]
string: 'log_filename_template' [5854,5877]
===
match
---
operator: , [4964,4965]
operator: , [4964,4965]
===
match
---
operator: + [11282,11283]
operator: + [11282,11283]
===
match
---
name: section [22410,22417]
name: section [22410,22417]
===
match
---
funcdef [26463,27062]
funcdef [26463,27062]
===
match
---
suite [31903,32010]
suite [31903,32010]
===
match
---
suite [42005,42057]
suite [41983,42035]
===
match
---
return_stmt [17243,17254]
return_stmt [17243,17254]
===
match
---
name: int [22901,22904]
name: int [22901,22904]
===
match
---
name: generate_key [33371,33383]
name: generate_key [33371,33383]
===
match
---
string: 'AIRFLOW_HOME' [34914,34928]
string: 'AIRFLOW_HOME' [34914,34928]
===
match
---
string: '~/airflow' [31996,32007]
string: '~/airflow' [31996,32007]
===
match
---
number: 2 [43080,43081]
number: 2 [43058,43059]
===
match
---
simple_stmt [17221,17235]
simple_stmt [17221,17235]
===
match
---
operator: , [40367,40368]
operator: , [40345,40346]
===
match
---
trailer [17608,17645]
trailer [17608,17645]
===
match
---
name: val [22837,22840]
name: val [22837,22840]
===
match
---
testlist_comp [4790,4823]
testlist_comp [4790,4823]
===
match
---
param [12331,12339]
param [12331,12339]
===
match
---
name: get_custom_secret_backend [2917,2942]
name: get_custom_secret_backend [2917,2942]
===
match
---
testlist_comp [25769,25839]
testlist_comp [25769,25839]
===
match
---
operator: -> [40797,40799]
operator: -> [40775,40777]
===
match
---
trailer [35415,35738]
trailer [35415,35738]
===
match
---
suite [12016,12275]
suite [12016,12275]
===
match
---
name: section [14033,14040]
name: section [14033,14040]
===
match
---
name: section [14904,14911]
name: section [14904,14911]
===
match
---
operator: , [7392,7393]
operator: , [7392,7393]
===
match
---
name: os_environment [27797,27811]
name: os_environment [27797,27811]
===
match
---
string: """     Generates a configuration from the provided template + variables defined in     current scope      :param template: a config content templated with {{variables}}     """ [32730,32907]
string: """     Generates a configuration from the provided template + variables defined in     current scope      :param template: a config content templated with {{variables}}     """ [32730,32907]
===
match
---
atom [5596,5621]
atom [5596,5621]
===
match
---
name: key [14149,14152]
name: key [14149,14152]
===
match
---
simple_stmt [17587,17646]
simple_stmt [17587,17646]
===
match
---
name: subprocess [2384,2394]
name: subprocess [2384,2394]
===
match
---
name: option [16464,16470]
name: option [16464,16470]
===
match
---
param [27719,27734]
param [27719,27734]
===
match
---
simple_stmt [2980,2992]
simple_stmt [2980,2992]
===
match
---
operator: { [7807,7808]
operator: { [7807,7808]
===
match
---
fstring_expr [19300,19309]
fstring_expr [19300,19309]
===
match
---
name: self [25833,25837]
name: self [25833,25837]
===
match
---
trailer [31208,31398]
trailer [31208,31398]
===
match
---
atom_expr [42014,42056]
atom_expr [41992,42034]
===
match
---
name: environ [33150,33157]
name: environ [33150,33157]
===
match
---
return_stmt [17221,17234]
return_stmt [17221,17234]
===
match
---
trailer [17768,17784]
trailer [17768,17784]
===
match
---
string: """     Read Airflow configs from YAML file      :return: Python dictionary containing configs & their info     """ [3261,3376]
string: """     Read Airflow configs from YAML file      :return: Python dictionary containing configs & their info     """ [3261,3376]
===
match
---
atom_expr [1588,1603]
atom_expr [1588,1603]
===
match
---
expr_stmt [2900,2944]
expr_stmt [2900,2944]
===
match
---
return_stmt [38224,38261]
return_stmt [38202,38239]
===
match
---
string: 'kubernetes_environment_variables' [28827,28861]
string: 'kubernetes_environment_variables' [28827,28861]
===
match
---
arglist [38647,38662]
arglist [38625,38640]
===
match
---
simple_stmt [42396,42413]
simple_stmt [42374,42391]
===
match
---
if_stmt [17654,17932]
if_stmt [17654,17932]
===
match
---
trailer [22230,22268]
trailer [22230,22268]
===
match
---
trailer [32225,32243]
trailer [32225,32243]
===
match
---
operator: , [4898,4899]
operator: , [4898,4899]
===
match
---
argument [33693,33722]
argument [33693,33722]
===
match
---
simple_stmt [35402,35739]
simple_stmt [35402,35739]
===
match
---
operator: , [4111,4112]
operator: , [4111,4112]
===
match
---
operator: , [27109,27110]
operator: , [27109,27110]
===
match
---
testlist_comp [5843,5877]
testlist_comp [5843,5877]
===
match
---
simple_stmt [18366,18437]
simple_stmt [18366,18437]
===
match
---
argument [20113,20128]
argument [20113,20128]
===
match
---
simple_stmt [44169,44224]
simple_stmt [44147,44202]
===
match
---
name: TEST_CONFIG_FILE [33987,34003]
name: TEST_CONFIG_FILE [33987,34003]
===
match
---
simple_stmt [14826,14838]
simple_stmt [14826,14838]
===
match
---
string: "executor" [9842,9852]
string: "executor" [9842,9852]
===
match
---
name: _default_config_file_path [42816,42841]
name: _default_config_file_path [42794,42819]
===
match
---
operator: } [18997,18998]
operator: } [18997,18998]
===
match
---
dotted_name [33873,33892]
dotted_name [33873,33892]
===
match
---
argument [37371,37383]
argument [37349,37361]
===
match
---
string: ". Possible values are " [11237,11261]
string: ". Possible values are " [11237,11261]
===
match
---
suite [14618,14818]
suite [14618,14818]
===
match
---
name: self [16550,16554]
name: self [16550,16554]
===
match
---
trailer [22519,22524]
trailer [22519,22524]
===
match
---
name: key [27641,27644]
name: key [27641,27644]
===
match
---
name: key [15784,15787]
name: key [15784,15787]
===
match
---
if_stmt [43951,44109]
if_stmt [43929,44087]
===
match
---
trailer [2485,2504]
trailer [2485,2504]
===
match
---
name: _warn_deprecate [18371,18386]
name: _warn_deprecate [18371,18386]
===
match
---
suite [29134,29367]
suite [29134,29367]
===
match
---
operator: = [15583,15584]
operator: = [15583,15584]
===
match
---
name: has_option [21621,21631]
name: has_option [21621,21631]
===
match
---
not_test [2000,2011]
not_test [2000,2011]
===
match
---
name: _parameterized_config_from_template [30212,30247]
name: _parameterized_config_from_template [30212,30247]
===
match
---
trailer [13767,13775]
trailer [13767,13775]
===
match
---
trailer [33181,33186]
trailer [33181,33186]
===
match
---
param [33060,33072]
param [33060,33072]
===
match
---
comp_op [15372,15378]
comp_op [15372,15378]
===
match
---
name: env_var_cmd [13580,13591]
name: env_var_cmd [13580,13591]
===
match
---
name: dirname [43892,43899]
name: dirname [43870,43877]
===
match
---
arglist [37954,38213]
arglist [37932,38191]
===
match
---
name: kwargs [37420,37426]
name: kwargs [37398,37404]
===
match
---
simple_stmt [17851,17932]
simple_stmt [17851,17932]
===
match
---
testlist_star_expr [8947,8964]
testlist_star_expr [8947,8964]
===
match
---
operator: , [17797,17798]
operator: , [17797,17798]
===
match
---
operator: , [37416,37417]
operator: , [37394,37395]
===
match
---
testlist_comp [7974,8132]
testlist_comp [7974,8132]
===
match
---
suite [3089,3220]
suite [3089,3220]
===
match
---
string: "'conf.get'" [37321,37333]
string: "'conf.get'" [37299,37311]
===
match
---
atom_expr [38339,38623]
atom_expr [38317,38601]
===
match
---
name: delimiter [23860,23869]
name: delimiter [23860,23869]
===
match
---
testlist_comp [26560,26572]
testlist_comp [26560,26572]
===
match
---
string: '2.0.0' [4740,4747]
string: '2.0.0' [4740,4747]
===
match
---
name: search [11925,11931]
name: search [11925,11931]
===
match
---
trailer [2418,2423]
trailer [2418,2423]
===
match
---
operator: + [11197,11198]
operator: + [11197,11198]
===
match
---
name: option [17228,17234]
name: option [17228,17234]
===
match
---
name: str [21802,21805]
name: str [21802,21805]
===
match
---
fstring_string: error: cannot use sqlite with the  [10109,10143]
fstring_string: error: cannot use sqlite with the  [10109,10143]
===
match
---
atom_expr [34285,34300]
atom_expr [34285,34300]
===
match
---
name: _section [22371,22379]
name: _section [22371,22379]
===
match
---
simple_stmt [28448,28471]
simple_stmt [28448,28471]
===
match
---
import_name [901,918]
import_name [901,918]
===
match
---
name: _get_secret_option [16420,16438]
name: _get_secret_option [16420,16438]
===
match
---
atom [4200,4221]
atom [4200,4221]
===
match
---
trailer [8514,8523]
trailer [8514,8523]
===
match
---
exprlist [8824,8844]
exprlist [8824,8844]
===
match
---
atom_expr [21599,21648]
atom_expr [21599,21648]
===
match
---
name: _replace_config_with_display_sources [25864,25900]
name: _replace_config_with_display_sources [25864,25900]
===
match
---
arglist [39069,39084]
arglist [39047,39062]
===
match
---
name: set [12245,12248]
name: set [12245,12248]
===
match
---
name: format [31202,31208]
name: format [31202,31208]
===
match
---
name: key [27174,27177]
name: key [27174,27177]
===
match
---
name: pep562 [44478,44484]
name: pep562 [44472,44478]
===
match
---
name: __name__ [42962,42970]
name: __name__ [42940,42948]
===
match
---
param [38282,38290]
param [38260,38268]
===
match
---
name: environ [13212,13219]
name: environ [13212,13219]
===
match
---
operator: = [41625,41626]
operator: = [41603,41604]
===
match
---
operator: = [28883,28884]
operator: = [28883,28884]
===
match
---
trailer [11924,11931]
trailer [11924,11931]
===
match
---
name: _delimiters [23546,23557]
name: _delimiters [23546,23557]
===
match
---
fstring [10632,10701]
fstring [10632,10701]
===
match
---
string: 'env var' [28460,28469]
string: 'env var' [28460,28469]
===
match
---
operator: , [5512,5513]
operator: , [5512,5513]
===
match
---
parameters [19031,19061]
parameters [19031,19061]
===
match
---
string: 'celery' [4163,4171]
string: 'celery' [4163,4171]
===
match
---
operator: , [18759,18760]
operator: , [18759,18760]
===
match
---
operator: != [32520,32522]
operator: != [32520,32522]
===
match
---
fstring_string:  has no attribute  [43172,43190]
fstring_string:  has no attribute  [43150,43168]
===
match
---
name: stacklevel [40291,40301]
name: stacklevel [40269,40279]
===
match
---
testlist_comp [7743,7772]
testlist_comp [7743,7772]
===
match
---
operator: , [7895,7896]
operator: , [7895,7896]
===
match
---
suite [1604,1798]
suite [1604,1798]
===
match
---
string: "'conf.getboolean'" [37729,37748]
string: "'conf.getboolean'" [37707,37726]
===
match
---
operator: , [14579,14580]
operator: , [14579,14580]
===
match
---
simple_stmt [22730,22748]
simple_stmt [22730,22748]
===
match
---
string: '__' [27952,27956]
string: '__' [27952,27956]
===
match
---
name: deprecated_name [30780,30795]
name: deprecated_name [30780,30795]
===
match
---
trailer [38235,38244]
trailer [38213,38222]
===
match
---
name: airflow_defaults [21686,21702]
name: airflow_defaults [21686,21702]
===
match
---
expr_stmt [43733,43786]
expr_stmt [43711,43764]
===
match
---
suite [42923,43128]
suite [42901,43106]
===
match
---
operator: { [42595,42596]
operator: { [42573,42574]
===
match
---
simple_stmt [16649,16720]
simple_stmt [16649,16720]
===
match
---
trailer [17421,17435]
trailer [17421,17435]
===
match
---
name: encoding [20640,20648]
name: encoding [20640,20648]
===
match
---
string: "deprecated. Please access the configuration from the 'configuration.conf' object via " [38049,38136]
string: "deprecated. Please access the configuration from the 'configuration.conf' object via " [38027,38114]
===
match
---
atom_expr [41646,41700]
atom_expr [41624,41678]
===
match
---
string: 'tests' [43626,43633]
string: 'tests' [43604,43611]
===
match
---
trailer [2481,2517]
trailer [2481,2517]
===
match
---
name: val [29704,29707]
name: val [29704,29707]
===
match
---
operator: = [31462,31463]
operator: = [31462,31463]
===
match
---
trailer [43587,43595]
trailer [43565,43573]
===
match
---
operator: , [15858,15859]
operator: , [15858,15859]
===
match
---
name: super [21499,21504]
name: super [21499,21504]
===
match
---
param [29083,29086]
param [29083,29086]
===
match
---
string: 'logging' [5089,5098]
string: 'logging' [5089,5098]
===
match
---
operator: = [9954,9955]
operator: = [9954,9955]
===
match
---
trailer [21801,21824]
trailer [21801,21824]
===
match
---
name: section [21760,21767]
name: section [21760,21767]
===
match
---
trailer [43902,43907]
trailer [43880,43885]
===
match
---
name: os [12202,12204]
name: os [12202,12204]
===
match
---
argument [20619,20638]
argument [20619,20638]
===
match
---
trailer [26066,26122]
trailer [26066,26122]
===
match
---
trailer [2093,2127]
trailer [2093,2127]
===
match
---
name: self [27182,27186]
name: self [27182,27186]
===
match
---
operator: ** [14871,14873]
operator: ** [14871,14873]
===
match
---
arglist [10153,10171]
arglist [10153,10171]
===
match
---
name: environ [31968,31975]
name: environ [31968,31975]
===
match
---
trailer [2360,2366]
trailer [2360,2366]
===
match
---
string: 'core' [4958,4964]
string: 'core' [4958,4964]
===
match
---
name: deprecated_key [17731,17745]
name: deprecated_key [17731,17745]
===
match
---
operator: = [3108,3109]
operator: = [3108,3109]
===
match
---
name: get [19447,19450]
name: get [19447,19450]
===
match
---
operator: , [33754,33755]
operator: , [33754,33755]
===
match
---
trailer [40749,40766]
trailer [40727,40744]
===
match
---
name: ValueError [19534,19544]
name: ValueError [19534,19544]
===
match
---
trailer [34043,34049]
trailer [34043,34049]
===
match
---
operator: , [5644,5645]
operator: , [5644,5645]
===
match
---
import_name [888,900]
import_name [888,900]
===
match
---
parameters [36648,36650]
parameters [36626,36628]
===
match
---
expr_stmt [41408,41548]
expr_stmt [41386,41526]
===
match
---
name: env_var [13266,13273]
name: env_var [13266,13273]
===
match
---
name: pop [12213,12216]
name: pop [12213,12216]
===
match
---
trailer [39607,39612]
trailer [39585,39590]
===
match
---
trailer [7840,7848]
trailer [7840,7848]
===
match
---
strings [20393,20536]
strings [20393,20536]
===
match
---
return_stmt [39468,39507]
return_stmt [39446,39485]
===
match
---
atom_expr [38635,38663]
atom_expr [38613,38641]
===
match
---
string: 'Specifying airflow_home in the config file is deprecated. As you ' [35437,35504]
string: 'Specifying airflow_home in the config file is deprecated. As you ' [35437,35504]
===
match
---
atom_expr [8574,8603]
atom_expr [8574,8603]
===
match
---
try_stmt [20218,20551]
try_stmt [20218,20551]
===
match
---
trailer [3125,3130]
trailer [3125,3130]
===
match
---
return_stmt [17851,17931]
return_stmt [17851,17931]
===
match
---
name: Dict [24076,24080]
name: Dict [24076,24080]
===
match
---
trailer [33176,33181]
trailer [33176,33181]
===
match
---
operator: , [6834,6835]
operator: , [6834,6835]
===
match
---
operator: { [16229,16230]
operator: { [16229,16230]
===
match
---
simple_stmt [28372,28401]
simple_stmt [28372,28401]
===
match
---
atom_expr [44429,44445]
atom_expr [44423,44439]
===
match
---
name: section [30468,30475]
name: section [30468,30475]
===
match
---
if_stmt [26160,26268]
if_stmt [26160,26268]
===
match
---
string: """     Ensure that all secrets backends are loaded.     If the secrets_backend_list contains only 2 default backends, reload it.     """ [40830,40967]
string: """     Ensure that all secrets backends are loaded.     If the secrets_backend_list contains only 2 default backends, reload it.     """ [40808,40945]
===
match
---
trailer [15940,15951]
trailer [15940,15951]
===
match
---
string: 'sql_alchemy_conn' [4026,4044]
string: 'sql_alchemy_conn' [4026,4044]
===
match
---
param [26525,26540]
param [26525,26540]
===
match
---
trailer [28271,28297]
trailer [28271,28297]
===
match
---
simple_stmt [1243,1290]
simple_stmt [1243,1290]
===
match
---
operator: , [6716,6717]
operator: , [6716,6717]
===
match
---
name: lru_cache [42426,42435]
name: lru_cache [42404,42413]
===
match
---
trailer [18110,18130]
trailer [18110,18130]
===
match
---
trailer [30996,31001]
trailer [30996,31001]
===
match
---
name: replace [27501,27508]
name: replace [27501,27508]
===
match
---
return_stmt [42562,42578]
return_stmt [42540,42556]
===
match
---
name: kwargs [38254,38260]
name: kwargs [38232,38238]
===
match
---
name: Fernet [33364,33370]
name: Fernet [33364,33370]
===
match
---
argument [9506,9521]
argument [9506,9521]
===
match
---
suite [16528,16750]
suite [16528,16750]
===
match
---
name: typing [1248,1254]
name: typing [1248,1254]
===
match
---
operator: -> [21774,21776]
operator: -> [21774,21776]
===
match
---
operator: , [14864,14865]
operator: , [14864,14865]
===
match
---
atom [5244,5279]
atom [5244,5279]
===
match
---
name: as_dict [40327,40334]
name: as_dict [40305,40312]
===
match
---
operator: = [30779,30780]
operator: = [30779,30780]
===
match
---
argument [1651,1678]
argument [1651,1678]
===
match
---
dotted_name [10242,10259]
dotted_name [10242,10259]
===
match
---
suite [21259,21734]
suite [21259,21734]
===
match
---
name: info [36360,36364]
name: info [36360,36364]
===
match
---
name: self [8381,8385]
name: self [8381,8385]
===
match
---
name: state [31788,31793]
name: state [31788,31793]
===
match
---
trailer [22409,22418]
trailer [22409,22418]
===
match
---
fstring_start: f" [2717,2719]
fstring_start: f" [2717,2719]
===
match
---
operator: , [8108,8109]
operator: , [8108,8109]
===
match
---
string: 'core' [5454,5460]
string: 'core' [5454,5460]
===
match
---
name: sensitive_config_values [14162,14185]
name: sensitive_config_values [14162,14185]
===
match
---
operator: = [23115,23116]
operator: = [23115,23116]
===
match
---
atom [34949,35209]
atom [34949,35209]
===
match
---
string: """Custom Airflow Configparser supporting defaults and deprecated options""" [3576,3652]
string: """Custom Airflow Configparser supporting defaults and deprecated options""" [3576,3652]
===
match
---
param [14413,14416]
param [14413,14416]
===
match
---
name: self [14157,14161]
name: self [14157,14161]
===
match
---
name: section [18035,18042]
name: section [18035,18042]
===
match
---
suite [3571,31878]
suite [3571,31878]
===
match
---
trailer [42185,42192]
trailer [42163,42170]
===
match
---
atom_expr [12975,12990]
atom_expr [12975,12990]
===
match
---
trailer [23721,23727]
trailer [23721,23727]
===
match
---
trailer [2339,2345]
trailer [2339,2345]
===
match
---
name: os [43564,43566]
name: os [43542,43544]
===
match
---
operator: = [21252,21253]
operator: = [21252,21253]
===
match
---
operator: = [36239,36240]
operator: = [36239,36240]
===
match
---
string: 'navbar_color' [7821,7835]
string: 'navbar_color' [7821,7835]
===
match
---
funcdef [14843,15799]
funcdef [14843,15799]
===
match
---
suite [2209,2245]
suite [2209,2245]
===
match
---
expr_stmt [12150,12193]
expr_stmt [12150,12193]
===
match
---
name: staticmethod [29373,29385]
name: staticmethod [29373,29385]
===
match
---
name: section [30854,30861]
name: section [30854,30861]
===
match
---
trailer [18386,18436]
trailer [18386,18436]
===
match
---
name: template [32994,33002]
name: template [32994,33002]
===
match
---
atom [6093,6195]
atom [6093,6195]
===
match
---
operator: { [19654,19655]
operator: { [19654,19655]
===
match
---
trailer [34576,34590]
trailer [34576,34590]
===
match
---
name: remove_option [21201,21214]
name: remove_option [21201,21214]
===
match
---
and_test [21599,21667]
and_test [21599,21667]
===
match
---
operator: = [9374,9375]
operator: = [9374,9375]
===
match
---
name: min_sqlite_version [10678,10696]
name: min_sqlite_version [10678,10696]
===
match
---
operator: , [6999,7000]
operator: , [6999,7000]
===
match
---
name: self [12898,12902]
name: self [12898,12902]
===
match
---
atom_expr [36708,37012]
atom_expr [36686,36990]
===
match
---
operator: , [15494,15495]
operator: , [15494,15495]
===
match
---
name: getboolean [37434,37444]
name: getboolean [37412,37422]
===
match
---
atom_expr [14708,14742]
atom_expr [14708,14742]
===
match
---
name: conf [38635,38639]
name: conf [38613,38617]
===
match
---
operator: , [4293,4294]
operator: , [4293,4294]
===
match
---
name: __setstate__ [31720,31732]
name: __setstate__ [31720,31732]
===
match
---
number: 2 [40302,40303]
number: 2 [40280,40281]
===
match
---
operator: @ [28983,28984]
operator: @ [28983,28984]
===
match
---
string: """Historical getfloat""" [37901,37926]
string: """Historical getfloat""" [37879,37904]
===
match
---
arglist [9332,9522]
arglist [9332,9522]
===
match
---
testlist_comp [5011,5039]
testlist_comp [5011,5039]
===
match
---
name: has_option [20787,20797]
name: has_option [20787,20797]
===
match
---
parameters [40794,40796]
parameters [40772,40774]
===
match
---
return_stmt [13904,13981]
return_stmt [13904,13981]
===
match
---
operator: , [15649,15650]
operator: , [15649,15650]
===
match
---
trailer [43558,43643]
trailer [43536,43621]
===
match
---
name: default_config [34763,34777]
name: default_config [34763,34777]
===
match
---
argument [39022,39034]
argument [39000,39012]
===
match
---
name: get_all_start_methods [10993,11014]
name: get_all_start_methods [10993,11014]
===
match
---
operator: = [23600,23601]
operator: = [23600,23601]
===
match
---
trailer [23841,23850]
trailer [23841,23850]
===
match
---
operator: , [6032,6033]
operator: , [6032,6033]
===
match
---
name: _env_var_name [12884,12897]
name: _env_var_name [12884,12897]
===
match
---
trailer [22317,22319]
trailer [22317,22319]
===
match
---
string: "random_seeded_by_host" [11524,11547]
string: "random_seeded_by_host" [11524,11547]
===
match
---
name: key [22773,22776]
name: key [22773,22776]
===
match
---
name: section [15501,15508]
name: section [15501,15508]
===
match
---
arglist [26649,26661]
arglist [26649,26661]
===
match
---
name: display_source [26247,26261]
name: display_source [26247,26261]
===
match
---
name: self [31502,31506]
name: self [31502,31506]
===
match
---
operator: } [42970,42971]
operator: } [42948,42949]
===
match
---
atom [5502,5540]
atom [5502,5540]
===
match
---
name: self [12954,12958]
name: self [12954,12958]
===
match
---
trailer [43857,43862]
trailer [43835,43840]
===
match
---
suite [22115,22140]
suite [22115,22140]
===
match
---
subscript [22709,22712]
subscript [22709,22712]
===
match
---
name: args [37834,37838]
name: args [37812,37816]
===
match
---
simple_stmt [43132,43199]
simple_stmt [43110,43177]
===
match
---
simple_stmt [41593,41630]
simple_stmt [41571,41608]
===
match
---
testlist_comp [9875,9925]
testlist_comp [9875,9925]
===
match
---
expr_stmt [36222,36278]
expr_stmt [36222,36278]
===
match
---
simple_stmt [13904,13982]
simple_stmt [13904,13982]
===
match
---
string: 'core' [36052,36058]
string: 'core' [36052,36058]
===
match
---
trailer [40464,40729]
trailer [40442,40707]
===
match
---
name: filenames [20619,20628]
name: filenames [20619,20628]
===
match
---
name: JSONDecodeError [1227,1242]
name: JSONDecodeError [1227,1242]
===
match
---
return_stmt [12944,13007]
return_stmt [12944,13007]
===
match
---
name: _get_option_from_default_config [15743,15774]
name: _get_option_from_default_config [15743,15774]
===
match
---
string: 'fab_logging_level' [5205,5224]
string: 'fab_logging_level' [5205,5224]
===
match
---
trailer [7867,7878]
trailer [7867,7878]
===
match
---
trailer [27500,27508]
trailer [27500,27508]
===
match
---
name: self [8774,8778]
name: self [8774,8778]
===
match
---
name: section [17348,17355]
name: section [17348,17355]
===
match
---
simple_stmt [2770,2784]
simple_stmt [2770,2784]
===
match
---
name: section [19670,19677]
name: section [19670,19677]
===
match
---
name: opt [26819,26822]
name: opt [26819,26822]
===
match
---
name: option [21641,21647]
name: option [21641,21647]
===
match
---
suite [28355,28401]
suite [28355,28401]
===
match
---
string: '2.0.0' [4992,4999]
string: '2.0.0' [4992,4999]
===
match
---
name: env_var [12217,12224]
name: env_var [12217,12224]
===
match
---
arglist [30333,30387]
arglist [30333,30387]
===
match
---
operator: = [2434,2435]
operator: = [2434,2435]
===
match
---
simple_stmt [30065,30118]
simple_stmt [30065,30118]
===
match
---
return_stmt [32140,32188]
return_stmt [32140,32188]
===
match
---
name: split [27946,27951]
name: split [27946,27951]
===
match
---
trailer [14938,14943]
trailer [14938,14943]
===
match
---
trailer [15295,15353]
trailer [15295,15353]
===
match
---
fstring [2717,2754]
fstring [2717,2754]
===
match
---
name: conf [41470,41474]
name: conf [41448,41452]
===
match
---
name: self [26625,26629]
name: self [26625,26629]
===
match
---
name: run_command [2251,2262]
name: run_command [2251,2262]
===
match
---
string: 'metrics' [6430,6439]
string: 'metrics' [6430,6439]
===
match
---
name: opt [28455,28458]
name: opt [28455,28458]
===
match
---
atom_expr [32972,32981]
atom_expr [32972,32981]
===
match
---
simple_stmt [33357,33395]
simple_stmt [33357,33395]
===
match
---
atom_expr [29994,30022]
atom_expr [29994,30022]
===
match
---
operator: , [35803,35804]
operator: , [35803,35804]
===
match
---
param [40362,40368]
param [40340,40346]
===
match
---
atom_expr [7865,7878]
atom_expr [7865,7878]
===
match
---
fstring_expr [2655,2664]
fstring_expr [2655,2664]
===
match
---
param [12355,12365]
param [12355,12365]
===
match
---
suite [22358,22421]
suite [22358,22421]
===
match
---
operator: , [24009,24010]
operator: , [24009,24010]
===
match
---
string: '2.0.0' [6486,6493]
string: '2.0.0' [6486,6493]
===
match
---
atom_expr [10906,10941]
atom_expr [10906,10941]
===
match
---
trailer [29622,29648]
trailer [29622,29648]
===
match
---
raise_stmt [20347,20550]
raise_stmt [20347,20550]
===
match
---
name: key [22736,22739]
name: key [22736,22739]
===
match
---
operator: , [25714,25715]
operator: , [25714,25715]
===
match
---
name: section [29493,29500]
name: section [29493,29500]
===
match
---
name: functools [42798,42807]
name: functools [42776,42785]
===
match
---
trailer [33392,33394]
trailer [33392,33394]
===
match
---
string: '2.0.0' [6652,6659]
string: '2.0.0' [6652,6659]
===
match
---
operator: , [9225,9226]
operator: , [9225,9226]
===
match
---
operator: , [5887,5888]
operator: , [5887,5888]
===
match
---
atom [4087,4111]
atom [4087,4111]
===
match
---
name: get [14847,14850]
name: get [14847,14850]
===
match
---
trailer [36477,36508]
trailer [36477,36508]
===
match
---
trailer [22105,22114]
trailer [22105,22114]
===
match
---
expr_stmt [26819,26840]
expr_stmt [26819,26840]
===
match
---
fstring_start: f" [43153,43155]
fstring_start: f" [43131,43133]
===
match
---
trailer [34124,34126]
trailer [34124,34126]
===
match
---
operator: , [5492,5493]
operator: , [5492,5493]
===
match
---
name: conf [40741,40745]
name: conf [40719,40723]
===
match
---
atom_expr [17594,17645]
atom_expr [17594,17645]
===
match
---
trailer [33829,33836]
trailer [33829,33836]
===
match
---
operator: , [4096,4097]
operator: , [4096,4097]
===
match
---
name: file_parser_modes [11486,11503]
name: file_parser_modes [11486,11503]
===
match
---
testlist_comp [4681,4709]
testlist_comp [4681,4709]
===
match
---
simple_stmt [8550,8604]
simple_stmt [8550,8604]
===
match
---
string: 'AIRFLOW_TEST_CONFIG' [33118,33139]
string: 'AIRFLOW_TEST_CONFIG' [33118,33139]
===
match
---
string: '2.1.0' [7394,7401]
string: '2.1.0' [7394,7401]
===
match
---
comp_op [32113,32119]
comp_op [32113,32119]
===
match
---
simple_stmt [31517,31711]
simple_stmt [31517,31711]
===
match
---
name: key [18396,18399]
name: key [18396,18399]
===
match
---
atom_expr [10491,10528]
atom_expr [10491,10528]
===
match
---
name: include_secret [26322,26336]
name: include_secret [26322,26336]
===
match
---
operator: , [25831,25832]
operator: , [25831,25832]
===
match
---
dictorsetmaker [26990,26998]
dictorsetmaker [26990,26998]
===
match
---
expr_stmt [8714,8739]
expr_stmt [8714,8739]
===
match
---
operator: = [20102,20103]
operator: = [20102,20103]
===
match
---
testlist_comp [4870,4907]
testlist_comp [4870,4907]
===
match
---
operator: { [11506,11507]
operator: { [11506,11507]
===
match
---
name: fh [42550,42552]
name: fh [42528,42530]
===
match
---
name: _warn_deprecate [17139,17154]
name: _warn_deprecate [17139,17154]
===
match
---
name: subprocess [908,918]
name: subprocess [908,918]
===
match
---
funcdef [31716,31878]
funcdef [31716,31878]
===
match
---
operator: , [9152,9153]
operator: , [9152,9153]
===
match
---
simple_stmt [3261,3377]
simple_stmt [3261,3377]
===
match
---
global_stmt [33548,33579]
global_stmt [33548,33579]
===
match
---
trailer [30134,30186]
trailer [30134,30186]
===
match
---
name: key [13052,13055]
name: key [13052,13055]
===
match
---
name: _replace_section_config_with_display_sources [29394,29438]
name: _replace_section_config_with_display_sources [29394,29438]
===
match
---
suite [14676,14818]
suite [14676,14818]
===
match
---
name: file [34752,34756]
name: file [34752,34756]
===
match
---
exprlist [8896,8906]
exprlist [8896,8906]
===
match
---
name: open [34154,34158]
name: open [34154,34158]
===
match
---
trailer [11931,11946]
trailer [11931,11946]
===
match
---
atom_expr [44504,44520]
atom_expr [44498,44514]
===
match
---
atom [25769,25803]
atom [25769,25803]
===
match
---
operator: , [11547,11548]
operator: , [11547,11548]
===
match
---
name: option [18195,18201]
name: option [18195,18201]
===
match
---
simple_stmt [34017,34079]
simple_stmt [34017,34079]
===
match
---
operator: = [27936,27937]
operator: = [27936,27937]
===
match
---
string: '#fff' [7881,7887]
string: '#fff' [7881,7887]
===
match
---
name: _get_environment_variables [17961,17987]
name: _get_environment_variables [17961,17987]
===
match
---
operator: , [7461,7462]
operator: , [7461,7462]
===
match
---
string: 'logging' [5747,5756]
string: 'logging' [5747,5756]
===
match
---
operator: { [18993,18994]
operator: { [18993,18994]
===
match
---
if_stmt [22329,22421]
if_stmt [22329,22421]
===
match
---
atom_expr [41756,41780]
atom_expr [41734,41758]
===
match
---
name: key [27590,27593]
name: key [27590,27593]
===
match
---
trailer [22708,22713]
trailer [22708,22713]
===
match
---
testlist_comp [5043,5077]
testlist_comp [5043,5077]
===
match
---
trailer [20255,20276]
trailer [20255,20276]
===
match
---
name: stream [2522,2528]
name: stream [2522,2528]
===
match
---
simple_stmt [1202,1243]
simple_stmt [1202,1243]
===
match
---
name: getsection [23831,23841]
name: getsection [23831,23841]
===
match
---
operator: , [8955,8956]
operator: , [8955,8956]
===
match
---
simple_stmt [27491,27520]
simple_stmt [27491,27520]
===
match
---
name: join [3118,3122]
name: join [3118,3122]
===
match
---
param [20804,20812]
param [20804,20812]
===
match
---
name: raw [29640,29643]
name: raw [29640,29643]
===
match
---
name: _default_config_file_path [36452,36477]
name: _default_config_file_path [36452,36477]
===
match
---
expr_stmt [14961,15086]
expr_stmt [14961,15086]
===
match
---
trailer [40037,40310]
trailer [40015,40288]
===
match
---
atom [6854,6888]
atom [6854,6888]
===
match
---
atom_expr [22219,22268]
atom_expr [22219,22268]
===
match
---
simple_stmt [42474,42527]
simple_stmt [42452,42505]
===
match
---
name: args [8482,8486]
name: args [8482,8486]
===
match
---
trailer [37125,37390]
trailer [37103,37368]
===
match
---
string: 'w' [34177,34180]
string: 'w' [34177,34180]
===
match
---
not_test [20160,20183]
not_test [20160,20183]
===
match
---
import_from [975,1010]
import_from [975,1010]
===
match
---
argument [37786,37798]
argument [37764,37776]
===
match
---
name: option [18156,18162]
name: option [18156,18162]
===
match
---
parameters [2827,2839]
parameters [2827,2839]
===
match
---
name: FERNET_KEY [34639,34649]
name: FERNET_KEY [34639,34649]
===
match
---
name: get [17881,17884]
name: get [17881,17884]
===
match
---
name: section [17785,17792]
name: section [17785,17792]
===
match
---
string: 'core' [6238,6244]
string: 'core' [6238,6244]
===
match
---
name: current_value [12737,12750]
name: current_value [12737,12750]
===
match
---
name: all_vars [32912,32920]
name: all_vars [32912,32920]
===
match
---
name: airflow_defaults [8660,8676]
name: airflow_defaults [8660,8676]
===
match
---
name: join [44079,44083]
name: join [44057,44061]
===
match
---
simple_stmt [32912,32983]
simple_stmt [32912,32983]
===
match
---
trailer [16029,16046]
trailer [16029,16046]
===
match
---
testlist_comp [44450,44454]
testlist_comp [44444,44448]
===
match
---
operator: = [32921,32922]
operator: = [32921,32922]
===
match
---
simple_stmt [18097,18145]
simple_stmt [18097,18145]
===
match
---
operator: , [35351,35352]
operator: , [35351,35352]
===
match
---
atom_expr [22306,22319]
atom_expr [22306,22319]
===
match
---
simple_stmt [28192,28201]
simple_stmt [28192,28201]
===
match
---
name: config_key [3029,3039]
name: config_key [3029,3039]
===
match
---
name: args [8588,8592]
name: args [8588,8592]
===
match
---
string: 'celery' [4088,4096]
string: 'celery' [4088,4096]
===
match
---
name: is_sqlite [9944,9953]
name: is_sqlite [9944,9953]
===
match
---
trailer [13568,13593]
trailer [13568,13593]
===
match
---
suite [12935,13008]
suite [12935,13008]
===
match
---
name: self [27678,27682]
name: self [27678,27682]
===
match
---
operator: , [6650,6651]
operator: , [6650,6651]
===
match
---
operator: = [18104,18105]
operator: = [18104,18105]
===
match
---
name: args [39492,39496]
name: args [39470,39474]
===
match
---
trailer [37410,37427]
trailer [37388,37405]
===
match
---
operator: , [12721,12722]
operator: , [12721,12722]
===
match
---
name: environ [32123,32130]
name: environ [32123,32130]
===
match
---
expr_stmt [25745,25849]
expr_stmt [25745,25849]
===
match
---
atom [11506,11564]
atom [11506,11564]
===
match
---
name: option [18097,18103]
name: option [18097,18103]
===
match
---
name: self [27089,27093]
name: self [27089,27093]
===
match
---
testlist_comp [27165,27177]
testlist_comp [27165,27177]
===
match
---
simple_stmt [41088,41125]
simple_stmt [41066,41103]
===
match
---
operator: , [5460,5461]
operator: , [5460,5461]
===
match
---
name: name [12188,12192]
name: name [12188,12192]
===
match
---
fstring_string: ". [19730,19732]
fstring_string: ". [19730,19732]
===
match
---
raise_stmt [32627,32687]
raise_stmt [32627,32687]
===
match
---
string: "Accessing configuration method 'set' directly from the configuration module is " [40474,40555]
string: "Accessing configuration method 'set' directly from the configuration module is " [40452,40533]
===
match
---
argument [40757,40765]
argument [40735,40743]
===
match
---
funcdef [19021,19379]
funcdef [19021,19379]
===
match
---
trailer [21685,21702]
trailer [21685,21702]
===
match
---
operator: , [26829,26830]
operator: , [26829,26830]
===
match
---
string: '1.10.14' [7113,7122]
string: '1.10.14' [7113,7122]
===
match
---
name: is_executor_without_sqlite_support [9788,9822]
name: is_executor_without_sqlite_support [9788,9822]
===
match
---
operator: , [26081,26082]
operator: , [26081,26082]
===
match
---
operator: , [2375,2376]
operator: , [2375,2376]
===
match
---
simple_stmt [12384,12841]
simple_stmt [12384,12841]
===
match
---
operator: , [27093,27094]
operator: , [27093,27094]
===
match
---
name: isfile [33830,33836]
name: isfile [33830,33836]
===
match
---
trailer [32946,32948]
trailer [32946,32948]
===
match
---
parameters [23284,23324]
parameters [23284,23324]
===
match
---
name: returncode [2571,2581]
name: returncode [2571,2581]
===
match
---
name: section [13043,13050]
name: section [13043,13050]
===
match
---
operator: = [12761,12762]
operator: = [12761,12762]
===
match
---
trailer [17058,17094]
trailer [17058,17094]
===
match
---
operator: = [31241,31242]
operator: = [31241,31242]
===
match
---
trailer [27854,27875]
trailer [27854,27875]
===
match
---
name: getboolean [37822,37832]
name: getboolean [37800,37810]
===
match
---
expr_stmt [43996,44038]
expr_stmt [43974,44016]
===
match
---
name: expand_env_var [16010,16024]
name: expand_env_var [16010,16024]
===
match
---
name: key [19095,19098]
name: key [19095,19098]
===
match
---
return_stmt [15731,15798]
return_stmt [15731,15798]
===
match
---
atom_expr [27497,27519]
atom_expr [27497,27519]
===
match
---
operator: , [17297,17298]
operator: , [17297,17298]
===
match
---
atom_expr [2468,2517]
atom_expr [2468,2517]
===
match
---
name: display_source [28416,28430]
name: display_source [28416,28430]
===
match
---
operator: , [4768,4769]
operator: , [4768,4769]
===
match
---
atom_expr [44182,44223]
atom_expr [44160,44201]
===
match
---
name: section [20457,20464]
name: section [20457,20464]
===
match
---
name: super [17692,17697]
name: super [17692,17697]
===
match
---
name: config_sources [26212,26226]
name: config_sources [26212,26226]
===
match
---
trailer [20325,20331]
trailer [20325,20331]
===
match
---
operator: , [27682,27683]
operator: , [27682,27683]
===
match
---
simple_stmt [3174,3220]
simple_stmt [3174,3220]
===
match
---
param [16852,16859]
param [16852,16859]
===
match
---
return_stmt [11914,11958]
return_stmt [11914,11958]
===
match
---
simple_stmt [8988,9043]
simple_stmt [8988,9043]
===
match
---
name: include_env [23993,24004]
name: include_env [23993,24004]
===
match
---
suite [24102,26458]
suite [24102,26458]
===
match
---
name: expandvars [2102,2112]
name: expandvars [2102,2112]
===
match
---
trailer [30754,30880]
trailer [30754,30880]
===
match
---
arglist [16439,16451]
arglist [16439,16451]
===
match
---
comparison [42903,42922]
comparison [42881,42900]
===
match
---
trailer [3112,3117]
trailer [3112,3117]
===
match
---
simple_stmt [30574,30962]
simple_stmt [30574,30962]
===
match
---
trailer [22852,22858]
trailer [22852,22858]
===
match
---
name: self [23826,23830]
name: self [23826,23830]
===
match
---
operator: , [15343,15344]
operator: , [15343,15344]
===
match
---
atom_expr [19077,19109]
atom_expr [19077,19109]
===
match
---
simple_stmt [29734,29748]
simple_stmt [29734,29748]
===
match
---
name: BaseSecretsBackend [41203,41221]
name: BaseSecretsBackend [41181,41199]
===
match
---
operator: , [29707,29708]
operator: , [29707,29708]
===
match
---
param [27130,27145]
param [27130,27145]
===
match
---
name: read_string [30200,30211]
name: read_string [30200,30211]
===
match
---
name: TEMPLATE_START [32309,32323]
name: TEMPLATE_START [32309,32323]
===
match
---
operator: , [30880,30881]
operator: , [30880,30881]
===
match
---
trailer [41760,41780]
trailer [41738,41758]
===
match
---
simple_stmt [23226,23246]
simple_stmt [23226,23246]
===
match
---
string: 'airflow.cfg' [25818,25831]
string: 'airflow.cfg' [25818,25831]
===
match
---
name: os [43884,43886]
name: os [43862,43864]
===
match
---
name: deprecated_section [16827,16845]
name: deprecated_section [16827,16845]
===
match
---
comparison [2139,2162]
comparison [2139,2162]
===
match
---
parameters [19396,19426]
parameters [19396,19426]
===
match
---
operator: = [41528,41529]
operator: = [41506,41507]
===
match
---
string: 'logging' [6206,6215]
string: 'logging' [6206,6215]
===
match
---
simple_stmt [24111,25682]
simple_stmt [24111,25682]
===
match
---
name: self [15001,15005]
name: self [15001,15005]
===
match
---
operator: , [5288,5289]
operator: , [5288,5289]
===
match
---
operator: * [37445,37446]
operator: * [37423,37424]
===
match
---
return_stmt [13233,13275]
return_stmt [13233,13275]
===
match
---
name: AIRFLOW_HOME [44154,44166]
name: AIRFLOW_HOME [44132,44144]
===
match
---
string: 'executor' [10161,10171]
string: 'executor' [10161,10171]
===
match
---
name: section [28816,28823]
name: section [28816,28823]
===
match
---
import_name [803,814]
import_name [803,814]
===
match
---
operator: = [18645,18646]
operator: = [18645,18646]
===
match
---
string: """     * import secrets backend classes     * instantiate them and return them in a list     """ [41786,41883]
string: """     * import secrets backend classes     * instantiate them and return them in a list     """ [41764,41861]
===
match
---
classdef [3493,31878]
classdef [3493,31878]
===
match
---
name: StrictVersion [10531,10544]
name: StrictVersion [10531,10544]
===
match
---
name: option [16491,16497]
name: option [16491,16497]
===
match
---
operator: = [13152,13153]
operator: = [13152,13153]
===
match
---
trailer [41051,41073]
trailer [41029,41051]
===
match
---
if_stmt [10184,10820]
if_stmt [10184,10820]
===
match
---
arglist [31980,32007]
arglist [31980,32007]
===
match
---
trailer [39913,39927]
trailer [39891,39905]
===
match
---
string: 'core' [5788,5794]
string: 'core' [5788,5794]
===
match
---
operator: } [41628,41629]
operator: } [41606,41607]
===
match
---
simple_stmt [28069,28078]
simple_stmt [28069,28078]
===
match
---
atom_expr [18647,18672]
atom_expr [18647,18672]
===
match
---
operator: * [38647,38648]
operator: * [38625,38626]
===
match
---
name: min_sqlite_version [10545,10563]
name: min_sqlite_version [10545,10563]
===
match
---
simple_stmt [21681,21734]
simple_stmt [21681,21734]
===
match
---
return_stmt [21107,21118]
return_stmt [21107,21118]
===
match
---
atom_expr [16191,16267]
atom_expr [16191,16267]
===
match
---
name: self [31733,31737]
name: self [31733,31737]
===
match
---
name: environ [32218,32225]
name: environ [32218,32225]
===
match
---
name: AIRFLOW_CONFIG [34862,34876]
name: AIRFLOW_CONFIG [34862,34876]
===
match
---
if_stmt [1581,1798]
if_stmt [1581,1798]
===
match
---
operator: , [13848,13849]
operator: , [13848,13849]
===
match
---
string: 'default_test.cfg' [42744,42762]
string: 'default_test.cfg' [42722,42740]
===
match
---
atom [42595,42870]
atom [42573,42848]
===
match
---
testlist_comp [7455,7501]
testlist_comp [7455,7501]
===
match
---
suite [21535,21587]
suite [21535,21587]
===
match
---
name: conf [34852,34856]
name: conf [34852,34856]
===
match
---
name: path [43887,43891]
name: path [43865,43869]
===
match
---
operator: = [34604,34605]
operator: = [34604,34605]
===
match
---
operator: , [4130,4131]
operator: , [4130,4131]
===
match
---
trailer [22054,22063]
trailer [22054,22063]
===
match
---
param [29067,29082]
param [29067,29082]
===
match
---
fstring_string: " key in " [20446,20456]
fstring_string: " key in " [20446,20456]
===
match
---
funcdef [3043,3220]
funcdef [3043,3220]
===
match
---
name: display_source [29067,29081]
name: display_source [29067,29081]
===
match
---
atom [13486,13500]
atom [13486,13500]
===
match
---
string: '2.1' [7889,7894]
string: '2.1' [7889,7894]
===
match
---
parameters [32714,32724]
parameters [32714,32724]
===
match
---
trailer [2474,2481]
trailer [2474,2481]
===
match
---
name: section [29623,29630]
name: section [29623,29630]
===
match
---
name: set [40358,40361]
name: set [40336,40339]
===
match
---
number: 3 [44450,44451]
number: 3 [44444,44445]
===
match
---
trailer [36359,36364]
trailer [36359,36364]
===
match
---
trailer [44432,44445]
trailer [44426,44439]
===
match
---
name: opt [28378,28381]
name: opt [28378,28381]
===
match
---
name: key [15961,15964]
name: key [15961,15964]
===
match
---
name: Fernet [34464,34470]
name: Fernet [34464,34470]
===
match
---
operator: , [15330,15331]
operator: , [15330,15331]
===
match
---
operator: , [16809,16810]
operator: , [16809,16810]
===
match
---
atom_expr [22072,22114]
atom_expr [22072,22114]
===
match
---
name: os [22509,22511]
name: os [22509,22511]
===
match
---
string: 'secret' [26831,26839]
string: 'secret' [26831,26839]
===
match
---
name: strip [18598,18603]
name: strip [18598,18603]
===
match
---
param [30482,30501]
param [30482,30501]
===
match
---
strings [10632,10801]
strings [10632,10801]
===
match
---
atom_expr [16415,16452]
atom_expr [16415,16452]
===
match
---
operator: = [31371,31372]
operator: = [31371,31372]
===
match
---
return_stmt [2021,2035]
return_stmt [2021,2035]
===
match
---
param [31739,31744]
param [31739,31744]
===
match
---
name: start_method_options [11294,11314]
name: start_method_options [11294,11314]
===
match
---
name: environ [13572,13579]
name: environ [13572,13579]
===
match
---
string: 'core' [7413,7419]
string: 'core' [7413,7419]
===
match
---
simple_stmt [2996,3041]
simple_stmt [2996,3041]
===
match
---
name: __file__ [43917,43925]
name: __file__ [43895,43903]
===
match
---
atom [5453,5492]
atom [5453,5492]
===
match
---
atom_expr [10144,10172]
atom_expr [10144,10172]
===
match
---
name: _include_secrets [26355,26371]
name: _include_secrets [26355,26371]
===
match
---
simple_stmt [3094,3170]
simple_stmt [3094,3170]
===
match
---
name: command [14341,14348]
name: command [14341,14348]
===
match
---
simple_stmt [21548,21587]
simple_stmt [21548,21587]
===
match
---
operator: , [25724,25725]
operator: , [25724,25725]
===
match
---
name: name [12258,12262]
name: name [12258,12262]
===
match
---
name: config_sources [26372,26386]
name: config_sources [26372,26386]
===
match
---
operator: = [43363,43364]
operator: = [43341,43342]
===
match
---
name: safe_load [3468,3477]
name: safe_load [3468,3477]
===
match
---
name: airflow [1457,1464]
name: airflow [1457,1464]
===
match
---
fstring_end: " [16265,16266]
fstring_end: " [16265,16266]
===
match
---
name: getLogger [1522,1531]
name: getLogger [1522,1531]
===
match
---
atom_expr [34105,34135]
atom_expr [34105,34135]
===
match
---
simple_stmt [44504,44521]
simple_stmt [44498,44515]
===
match
---
funcdef [15804,16268]
funcdef [15804,16268]
===
match
---
name: cryptography [34437,34449]
name: cryptography [34437,34449]
===
match
---
name: self [21681,21685]
name: self [21681,21685]
===
match
---
operator: , [2456,2457]
operator: , [2456,2457]
===
match
---
trailer [31759,31768]
trailer [31759,31768]
===
match
---
name: _deprecated [42581,42592]
name: _deprecated [42559,42570]
===
match
---
operator: , [4824,4825]
operator: , [4824,4825]
===
match
---
name: BaseSecretsBackend [1402,1420]
name: BaseSecretsBackend [1402,1420]
===
match
---
decorator [42243,42278]
decorator [42221,42256]
===
match
---
trailer [1591,1603]
trailer [1591,1603]
===
match
---
name: str [3084,3087]
name: str [3084,3087]
===
match
---
trailer [16438,16452]
trailer [16438,16452]
===
match
---
operator: < [10529,10530]
operator: < [10529,10530]
===
match
---
trailer [10544,10564]
trailer [10544,10564]
===
match
---
simple_stmt [975,1011]
simple_stmt [975,1011]
===
match
---
name: json [810,814]
name: json [810,814]
===
match
---
string: 'default_webserver_config.py' [36478,36507]
string: 'default_webserver_config.py' [36478,36507]
===
match
---
param [17988,17993]
param [17988,17993]
===
match
---
atom_expr [18106,18144]
atom_expr [18106,18144]
===
match
---
string: "section/key [%s/%s] not found in config" [16115,16156]
string: "section/key [%s/%s] not found in config" [16115,16156]
===
match
---
name: section [26958,26965]
name: section [26958,26965]
===
match
---
param [8381,8386]
param [8381,8386]
===
match
---
operator: , [18394,18395]
operator: , [18394,18395]
===
match
---
name: pathlib [870,877]
name: pathlib [870,877]
===
match
---
name: AirflowConfigException [2602,2624]
name: AirflowConfigException [2602,2624]
===
match
---
tfpdef [8387,8401]
tfpdef [8387,8401]
===
match
---
name: section [21632,21639]
name: section [21632,21639]
===
match
---
name: NoOptionError [1156,1169]
name: NoOptionError [1156,1169]
===
match
---
parameters [11983,12015]
parameters [11983,12015]
===
match
---
operator: , [28278,28279]
operator: , [28278,28279]
===
match
---
name: config_sources [29536,29550]
name: config_sources [29536,29550]
===
match
---
operator: , [38280,38281]
operator: , [38258,38259]
===
match
---
string: 'colored_log_format' [5462,5482]
string: 'colored_log_format' [5462,5482]
===
match
---
except_clause [21127,21165]
except_clause [21127,21165]
===
match
---
name: staticmethod [30431,30443]
name: staticmethod [30431,30443]
===
match
---
operator: = [17036,17037]
operator: = [17036,17037]
===
match
---
trailer [22185,22194]
trailer [22185,22194]
===
match
---
atom_expr [22544,22578]
atom_expr [22544,22578]
===
match
---
trailer [23830,23841]
trailer [23830,23841]
===
match
---
with_item [34701,34734]
with_item [34701,34734]
===
match
---
name: _get_option_from_secrets [15590,15614]
name: _get_option_from_secrets [15590,15614]
===
match
---
string: 'statsd_datadog_enabled' [6810,6834]
string: 'statsd_datadog_enabled' [6810,6834]
===
match
---
suite [19805,20551]
suite [19805,20551]
===
match
---
trailer [23689,23705]
trailer [23689,23705]
===
match
---
trailer [31870,31877]
trailer [31870,31877]
===
match
---
trailer [10106,10175]
trailer [10106,10175]
===
match
---
operator: , [20694,20695]
operator: , [20694,20695]
===
match
---
trailer [38762,39041]
trailer [38740,39019]
===
match
---
name: lower [14944,14949]
name: lower [14944,14949]
===
match
---
dictorsetmaker [4017,4294]
dictorsetmaker [4017,4294]
===
match
---
funcdef [38666,39086]
funcdef [38644,39064]
===
match
---
arglist [7849,7878]
arglist [7849,7878]
===
match
---
name: key [26658,26661]
name: key [26658,26661]
===
match
---
trailer [10148,10152]
trailer [10148,10152]
===
match
---
name: environ [12205,12212]
name: environ [12205,12212]
===
match
---
arglist [16574,16608]
arglist [16574,16608]
===
match
---
string: """         Returns the current configuration as an OrderedDict of OrderedDicts.          :param display_source: If False, the option value is returned. If True,             a tuple of (option_value, source) is returned. Source is either             'airflow.cfg', 'default', 'env var', or 'cmd'.         :type display_source: bool         :param display_sensitive: If True, the values of options set by env             vars and bash commands will be displayed. If False, those options             are shown as '< hidden >'         :type display_sensitive: bool         :param raw: Should the values be output as interpolated values, or the             "raw" form that can be fed back in to ConfigParser         :type raw: bool         :param include_env: Should the value of configuration from AIRFLOW__             environment variables be included or not         :type include_env: bool         :param include_cmds: Should the result of calling any *_cmd config be             set (True, default), or should the _cmd options be left as the             command to run (False)         :type include_cmds: bool         :param include_secret: Should the result of calling any *_secret config be             set (True, default), or should the _secret options be left as the             path to get the secret from (False)         :type include_secret: bool         :rtype: Dict[str, Dict[str, str]]         :return: Dictionary, where the key is the name of the section and the content is             the dictionary with the name of the parameter and its value.         """ [24111,25681]
string: """         Returns the current configuration as an OrderedDict of OrderedDicts.          :param display_source: If False, the option value is returned. If True,             a tuple of (option_value, source) is returned. Source is either             'airflow.cfg', 'default', 'env var', or 'cmd'.         :type display_source: bool         :param display_sensitive: If True, the values of options set by env             vars and bash commands will be displayed. If False, those options             are shown as '< hidden >'         :type display_sensitive: bool         :param raw: Should the values be output as interpolated values, or the             "raw" form that can be fed back in to ConfigParser         :type raw: bool         :param include_env: Should the value of configuration from AIRFLOW__             environment variables be included or not         :type include_env: bool         :param include_cmds: Should the result of calling any *_cmd config be             set (True, default), or should the _cmd options be left as the             command to run (False)         :type include_cmds: bool         :param include_secret: Should the result of calling any *_secret config be             set (True, default), or should the _secret options be left as the             path to get the secret from (False)         :type include_secret: bool         :rtype: Dict[str, Dict[str, str]]         :return: Dictionary, where the key is the name of the section and the content is             the dictionary with the name of the parameter and its value.         """ [24111,25681]
===
match
---
param [32035,32047]
param [32035,32047]
===
match
---
param [18527,18535]
param [18527,18535]
===
match
---
name: key [27260,27263]
name: key [27260,27263]
===
match
---
parameters [18506,18536]
parameters [18506,18536]
===
match
---
name: raw [26423,26426]
name: raw [26423,26426]
===
match
---
with_item [34154,34189]
with_item [34154,34189]
===
match
---
string: 'celery' [4122,4130]
string: 'celery' [4122,4130]
===
match
---
trailer [2624,2764]
trailer [2624,2764]
===
match
---
trailer [26052,26066]
trailer [26052,26066]
===
match
---
name: opt [28972,28975]
name: opt [28972,28975]
===
match
---
operator: , [5398,5399]
operator: , [5398,5399]
===
match
---
operator: , [34912,34913]
operator: , [34912,34913]
===
match
---
name: section [13173,13180]
name: section [13173,13180]
===
match
---
operator: , [23729,23730]
operator: , [23729,23730]
===
match
---
operator: , [14855,14856]
operator: , [14855,14856]
===
match
---
if_stmt [14568,14818]
if_stmt [14568,14818]
===
match
---
atom_expr [43138,43198]
atom_expr [43116,43176]
===
match
---
operator: } [19308,19309]
operator: } [19308,19309]
===
match
---
suite [18175,18202]
suite [18175,18202]
===
match
---
suite [22878,22910]
suite [22878,22910]
===
match
---
suite [2051,2245]
suite [2051,2245]
===
match
---
operator: , [5736,5737]
operator: , [5736,5737]
===
match
---
operator: = [18550,18551]
operator: = [18550,18551]
===
match
---
operator: } [19289,19290]
operator: } [19289,19290]
===
match
---
name: source [20696,20702]
name: source [20696,20702]
===
match
---
operator: { [11761,11762]
operator: { [11761,11762]
===
match
---
name: backend_list [42173,42185]
name: backend_list [42151,42163]
===
match
---
name: _parameterized_config_from_template [32251,32286]
name: _parameterized_config_from_template [32251,32286]
===
match
---
param [9618,9622]
param [9618,9622]
===
match
---
string: '2.1.0' [7193,7200]
string: '2.1.0' [7193,7200]
===
match
---
name: read [30402,30406]
name: read [30402,30406]
===
match
---
argument [21078,21093]
argument [21078,21093]
===
match
---
simple_stmt [21107,21119]
simple_stmt [21107,21119]
===
match
---
operator: , [4876,4877]
operator: , [4876,4877]
===
match
---
operator: , [16306,16307]
operator: , [16306,16307]
===
match
---
parameters [12324,12374]
parameters [12324,12374]
===
match
---
name: _section [22208,22216]
name: _section [22208,22216]
===
match
---
operator: , [6113,6114]
operator: , [6113,6114]
===
match
---
atom_expr [19564,19747]
atom_expr [19564,19747]
===
match
---
atom_expr [18552,18605]
atom_expr [18552,18605]
===
match
---
string: 'core' [35797,35803]
string: 'core' [35797,35803]
===
match
---
string: 'core' [7318,7324]
string: 'core' [7318,7324]
===
match
---
param [20684,20695]
param [20684,20695]
===
match
---
string: 't' [23073,23076]
string: 't' [23073,23076]
===
match
---
trailer [9829,9833]
trailer [9829,9833]
===
match
---
operator: * [37411,37412]
operator: * [37389,37390]
===
match
---
parameters [13036,13056]
parameters [13036,13056]
===
match
---
atom_expr [34564,34625]
atom_expr [34564,34625]
===
match
---
name: multiprocessing [837,852]
name: multiprocessing [837,852]
===
match
---
suite [41395,41549]
suite [41373,41527]
===
match
---
name: self [31755,31759]
name: self [31755,31759]
===
match
---
simple_stmt [32140,32189]
simple_stmt [32140,32189]
===
match
---
atom_expr [32147,32188]
atom_expr [32147,32188]
===
match
---
argument [8531,8539]
argument [8531,8539]
===
match
---
operator: { [32923,32924]
operator: { [32923,32924]
===
match
---
import_name [878,887]
import_name [878,887]
===
match
---
name: getattr [31544,31551]
name: getattr [31544,31551]
===
match
---
raise_stmt [11094,11333]
raise_stmt [11094,11333]
===
match
---
atom [15042,15056]
atom [15042,15056]
===
match
---
string: 'logging' [6043,6052]
string: 'logging' [6043,6052]
===
match
---
string: 'unit_test_mode' [36060,36076]
string: 'unit_test_mode' [36060,36076]
===
match
---
trailer [26211,26267]
trailer [26211,26267]
===
match
---
atom_expr [23602,23621]
atom_expr [23602,23621]
===
match
---
name: key [20130,20133]
name: key [20130,20133]
===
match
---
name: AirflowConfigException [11639,11661]
name: AirflowConfigException [11639,11661]
===
match
---
operator: , [18511,18512]
operator: , [18511,18512]
===
match
---
simple_stmt [22208,22269]
simple_stmt [22208,22269]
===
match
---
operator: , [9382,9383]
operator: , [9382,9383]
===
match
---
param [11984,11989]
param [11984,11989]
===
match
---
name: DEFAULT_SECRETS_SEARCH_PATH [1373,1400]
name: DEFAULT_SECRETS_SEARCH_PATH [1373,1400]
===
match
---
simple_stmt [18827,19016]
simple_stmt [18827,19016]
===
match
---
operator: , [8146,8147]
operator: , [8146,8147]
===
match
---
string: 'config.yml' [3417,3429]
string: 'config.yml' [3417,3429]
===
match
---
atom_expr [36291,36323]
atom_expr [36291,36323]
===
match
---
name: source [20763,20769]
name: source [20763,20769]
===
match
---
name: section [30014,30021]
name: section [30014,30021]
===
match
---
fstring_string: ". [18998,19000]
fstring_string: ". [18998,19000]
===
match
---
trailer [9283,9306]
trailer [9283,9306]
===
match
---
name: section [27165,27172]
name: section [27165,27172]
===
match
---
expr_stmt [3981,4300]
expr_stmt [3981,4300]
===
match
---
operator: , [12329,12330]
operator: , [12329,12330]
===
match
---
parameters [29438,29519]
parameters [29438,29519]
===
match
---
subscriptlist [21791,21824]
subscriptlist [21791,21824]
===
match
---
trailer [23060,23066]
trailer [23060,23066]
===
match
---
name: current_value [11932,11945]
name: current_value [11932,11945]
===
match
---
name: key [19782,19785]
name: key [19782,19785]
===
match
---
trailer [14220,14243]
trailer [14220,14243]
===
match
---
name: process [2319,2326]
name: process [2319,2326]
===
match
---
name: self [16805,16809]
name: self [16805,16809]
===
match
---
operator: , [37450,37451]
operator: , [37428,37429]
===
match
---
suite [38306,38664]
suite [38284,38642]
===
match
---
name: os [33244,33246]
name: os [33244,33246]
===
match
---
string: 'mp_start_method' [10856,10873]
string: 'mp_start_method' [10856,10873]
===
match
---
operator: = [41501,41502]
operator: = [41479,41480]
===
match
---
arglist [15775,15797]
arglist [15775,15797]
===
match
---
trailer [18855,19015]
trailer [18855,19015]
===
match
---
atom_expr [27855,27874]
atom_expr [27855,27874]
===
match
---
name: DeprecationWarning [30898,30916]
name: DeprecationWarning [30898,30916]
===
match
---
atom_expr [15001,15086]
atom_expr [15001,15086]
===
match
---
simple_stmt [39995,40020]
simple_stmt [39973,39998]
===
match
---
operator: = [2383,2384]
operator: = [2383,2384]
===
match
---
name: getsection [38670,38680]
name: getsection [38648,38658]
===
match
---
atom_expr [10084,10175]
atom_expr [10084,10175]
===
match
---
name: _include_commands [27071,27088]
name: _include_commands [27071,27088]
===
match
---
operator: = [28492,28493]
operator: = [28492,28493]
===
match
---
if_stmt [18210,18467]
if_stmt [18210,18467]
===
match
---
name: ConfigParser [8574,8586]
name: ConfigParser [8574,8586]
===
match
---
expr_stmt [26619,26662]
expr_stmt [26619,26662]
===
match
---
operator: , [24084,24085]
operator: , [24084,24085]
===
match
---
operator: + [27645,27646]
operator: + [27645,27646]
===
match
---
atom_expr [13765,13775]
atom_expr [13765,13775]
===
match
---
simple_stmt [23254,23270]
simple_stmt [23254,23270]
===
match
---
operator: , [40700,40701]
operator: , [40678,40679]
===
match
---
operator: = [19075,19076]
operator: = [19075,19076]
===
match
---
name: Dict [25706,25710]
name: Dict [25706,25710]
===
match
---
name: path [3184,3188]
name: path [3184,3188]
===
match
---
name: warnings [30574,30582]
name: warnings [30574,30582]
===
match
---
name: option [20813,20819]
name: option [20813,20819]
===
match
---
simple_stmt [36440,36528]
simple_stmt [36440,36528]
===
match
---
operator: , [8157,8158]
operator: , [8157,8158]
===
match
---
param [17293,17298]
param [17293,17298]
===
match
---
name: _get_option_from_default_config [15808,15839]
name: _get_option_from_default_config [15808,15839]
===
match
---
name: lower [18590,18595]
name: lower [18590,18595]
===
match
---
string: "Reading default test configuration from %s" [30135,30179]
string: "Reading default test configuration from %s" [30135,30179]
===
match
---
name: getfloat [37856,37864]
name: getfloat [37834,37842]
===
match
---
name: str [24081,24084]
name: str [24081,24084]
===
match
---
testlist_comp [6535,6572]
testlist_comp [6535,6572]
===
match
---
expr_stmt [3094,3169]
expr_stmt [3094,3169]
===
match
---
name: conf [34310,34314]
name: conf [34310,34314]
===
match
---
name: self [15262,15266]
name: self [15262,15266]
===
match
---
string: """         Validate that config values aren't invalid given other config values         or system-level limitations and requirements.         """ [9633,9779]
string: """         Validate that config values aren't invalid given other config values         or system-level limitations and requirements.         """ [9633,9779]
===
match
---
suite [42300,42413]
suite [42278,42391]
===
match
---
operator: , [15310,15311]
operator: , [15310,15311]
===
match
---
string: "scheduler" [11362,11373]
string: "scheduler" [11362,11373]
===
match
---
name: b64encode [44182,44191]
name: b64encode [44160,44169]
===
match
---
string: 'secrets' [41487,41496]
string: 'secrets' [41465,41474]
===
match
---
name: current_value [9154,9167]
name: current_value [9154,9167]
===
match
---
param [19032,19037]
param [19032,19037]
===
match
---
string: 'unittests.cfg' [33201,33216]
string: 'unittests.cfg' [33201,33216]
===
match
---
if_stmt [23630,23742]
if_stmt [23630,23742]
===
match
---
trailer [26648,26662]
trailer [26648,26662]
===
match
---
trailer [42374,42380]
trailer [42352,42358]
===
match
---
trailer [9558,9571]
trailer [9558,9571]
===
match
---
suite [10875,11334]
suite [10875,11334]
===
match
---
return_stmt [32987,33021]
return_stmt [32987,33021]
===
match
---
arglist [21061,21093]
arglist [21061,21093]
===
match
---
comparison [18748,18774]
comparison [18748,18774]
===
match
---
testlist_comp [5543,5585]
testlist_comp [5543,5585]
===
match
---
name: conf [41305,41309]
name: conf [41283,41287]
===
match
---
comp_op [11591,11597]
comp_op [11591,11597]
===
match
---
name: key [15332,15335]
name: key [15332,15335]
===
match
---
string: 'operators' [7134,7145]
string: 'operators' [7134,7145]
===
match
---
simple_stmt [40830,40968]
simple_stmt [40808,40946]
===
match
---
fstring_expr [16239,16244]
fstring_expr [16239,16244]
===
match
---
operator: , [5020,5021]
operator: , [5020,5021]
===
match
---
name: section [22466,22473]
name: section [22466,22473]
===
match
---
trailer [13172,13186]
trailer [13172,13186]
===
match
---
name: deprecated_key [17299,17313]
name: deprecated_key [17299,17313]
===
match
---
atom_expr [41442,41548]
atom_expr [41420,41526]
===
match
---
trailer [9306,9544]
trailer [9306,9544]
===
match
---
if_stmt [11030,11334]
if_stmt [11030,11334]
===
match
---
simple_stmt [38749,39042]
simple_stmt [38727,39020]
===
match
---
name: re [885,887]
name: re [885,887]
===
match
---
name: val [18994,18997]
name: val [18994,18997]
===
match
---
suite [19427,19748]
suite [19427,19748]
===
match
---
suite [28052,28078]
suite [28052,28078]
===
match
---
atom_expr [44390,44419]
atom_expr [44368,44397]
===
match
---
trailer [30247,30267]
trailer [30247,30267]
===
match
---
number: 2 [39455,39456]
number: 2 [39433,39434]
===
match
---
simple_stmt [36194,36218]
simple_stmt [36194,36218]
===
match
---
atom_expr [21052,21094]
atom_expr [21052,21094]
===
match
---
arglist [40047,40304]
arglist [40025,40282]
===
match
---
arglist [36365,36430]
arglist [36365,36430]
===
match
---
operator: , [4690,4691]
operator: , [4690,4691]
===
match
---
trailer [16114,16171]
trailer [16114,16171]
===
match
---
trailer [34492,34551]
trailer [34492,34551]
===
match
---
suite [29520,29748]
suite [29520,29748]
===
match
---
atom_expr [44071,44108]
atom_expr [44049,44086]
===
match
---
name: key [17630,17633]
name: key [17630,17633]
===
match
---
operator: { [4593,4594]
operator: { [4593,4594]
===
match
---
name: self [17038,17042]
name: self [17038,17042]
===
match
---
expr_stmt [19436,19474]
expr_stmt [19436,19474]
===
match
---
string: 'metrics' [6671,6680]
string: 'metrics' [6671,6680]
===
match
---
operator: , [26261,26262]
operator: , [26261,26262]
===
match
---
operator: , [31464,31465]
operator: , [31464,31465]
===
match
---
atom_expr [42536,42546]
atom_expr [42514,42524]
===
match
---
string: 'parsing_processes' [7062,7081]
string: 'parsing_processes' [7062,7081]
===
match
---
simple_stmt [36554,36566]
simple_stmt [36532,36544]
===
match
---
simple_stmt [26932,27001]
simple_stmt [26932,27001]
===
match
---
operator: , [8529,8530]
operator: , [8529,8530]
===
match
---
operator: { [18922,18923]
operator: { [18922,18923]
===
match
---
string: "Accessing configuration method 'getsection' directly from the configuration module is " [38772,38860]
string: "Accessing configuration method 'getsection' directly from the configuration module is " [38750,38838]
===
match
---
atom [6429,6455]
atom [6429,6455]
===
match
---
name: kwargs [8533,8539]
name: kwargs [8533,8539]
===
match
---
operator: , [18520,18521]
operator: , [18520,18521]
===
match
---
trailer [22379,22386]
trailer [22379,22386]
===
match
---
name: sensitive_config_values [3981,4004]
name: sensitive_config_values [3981,4004]
===
match
---
operator: , [7324,7325]
operator: , [7324,7325]
===
match
---
name: action [1726,1732]
name: action [1726,1732]
===
match
---
param [39959,39965]
param [39937,39943]
===
match
---
trailer [42576,42578]
trailer [42554,42556]
===
match
---
name: _get_config_value_from_secret_backend [13911,13948]
name: _get_config_value_from_secret_backend [13911,13948]
===
match
---
operator: ** [8594,8596]
operator: ** [8594,8596]
===
match
---
number: 2 [37797,37798]
number: 2 [37775,37776]
===
match
---
name: get_custom_secret_backend [41935,41960]
name: get_custom_secret_backend [41913,41938]
===
match
---
operator: , [36983,36984]
operator: , [36961,36962]
===
match
---
arglist [9977,10003]
arglist [9977,10003]
===
match
---
operator: { [27589,27590]
operator: { [27589,27590]
===
match
---
suite [8642,8705]
suite [8642,8705]
===
match
---
operator: = [28319,28320]
operator: = [28319,28320]
===
match
---
suite [22579,22819]
suite [22579,22819]
===
match
---
operator: , [17817,17818]
operator: , [17817,17818]
===
match
---
operator: { [19300,19301]
operator: { [19300,19301]
===
match
---
trailer [27859,27874]
trailer [27859,27874]
===
match
---
arglist [38772,39035]
arglist [38750,39013]
===
match
---
fstring_string: . [11824,11825]
fstring_string: . [11824,11825]
===
match
---
if_stmt [13195,13276]
if_stmt [13195,13276]
===
match
---
name: self [17988,17992]
name: self [17988,17992]
===
match
---
name: DeprecationWarning [40682,40700]
name: DeprecationWarning [40660,40678]
===
match
---
comp_op [11049,11055]
comp_op [11049,11055]
===
match
---
name: os [13411,13413]
name: os [13411,13413]
===
match
---
atom_expr [22736,22747]
atom_expr [22736,22747]
===
match
---
operator: , [5942,5943]
operator: , [5942,5943]
===
match
---
trailer [42807,42815]
trailer [42785,42793]
===
match
---
operator: } [19658,19659]
operator: } [19658,19659]
===
match
---
operator: = [20750,20751]
operator: = [20750,20751]
===
match
---
operator: , [37383,37384]
operator: , [37361,37362]
===
match
---
return_stmt [23254,23269]
return_stmt [23254,23269]
===
match
---
trailer [30013,30022]
trailer [30013,30022]
===
match
---
suite [36324,36528]
suite [36324,36528]
===
match
---
suite [34419,34779]
suite [34419,34779]
===
match
---
not_test [44459,44467]
not_test [44453,44461]
===
match
---
name: self [22447,22451]
name: self [22447,22451]
===
match
---
name: key [41339,41342]
name: key [41317,41320]
===
match
---
string: "file_parsing_sort_mode" [11375,11399]
string: "file_parsing_sort_mode" [11375,11399]
===
match
---
string: 'logging' [5597,5606]
string: 'logging' [5597,5606]
===
match
---
atom_expr [30574,30961]
atom_expr [30574,30961]
===
match
---
name: val [22994,22997]
name: val [22994,22997]
===
match
---
atom_expr [34154,34181]
atom_expr [34154,34181]
===
match
---
name: Dict [24086,24090]
name: Dict [24086,24090]
===
match
---
arglist [11435,11472]
arglist [11435,11472]
===
match
---
trailer [36112,36114]
trailer [36112,36114]
===
match
---
name: section [22106,22113]
name: section [22106,22113]
===
match
---
name: _TEST_CONFIG [42655,42667]
name: _TEST_CONFIG [42633,42645]
===
match
---
simple_stmt [2277,2315]
simple_stmt [2277,2315]
===
match
---
name: section [16230,16237]
name: section [16230,16237]
===
match
---
suite [21166,21192]
suite [21166,21192]
===
match
---
atom_expr [42139,42164]
atom_expr [42117,42142]
===
match
---
name: category [35290,35298]
name: category [35290,35298]
===
match
---
name: interpolated [2139,2151]
name: interpolated [2139,2151]
===
match
---
trailer [7984,8036]
trailer [7984,8036]
===
match
---
if_stmt [22031,22140]
if_stmt [22031,22140]
===
match
---
testlist_comp [6043,6090]
testlist_comp [6043,6090]
===
match
---
name: old [11877,11880]
name: old [11877,11880]
===
match
---
operator: { [32677,32678]
operator: { [32677,32678]
===
match
---
operator: , [2506,2507]
operator: , [2506,2507]
===
match
---
name: display_sensitive [28220,28237]
name: display_sensitive [28220,28237]
===
match
---
simple_stmt [34484,34552]
simple_stmt [34484,34552]
===
match
---
trailer [43759,43764]
trailer [43737,43742]
===
match
---
simple_stmt [15420,15510]
simple_stmt [15420,15510]
===
match
---
name: subprocess [2329,2339]
name: subprocess [2329,2339]
===
match
---
name: section [14857,14864]
name: section [14857,14864]
===
match
---
operator: , [30480,30481]
operator: , [30480,30481]
===
match
---
string: '_secret' [14507,14516]
string: '_secret' [14507,14516]
===
match
---
atom [6534,6573]
atom [6534,6573]
===
match
---
simple_stmt [25745,25850]
simple_stmt [25745,25850]
===
match
---
name: DeprecationWarning [39850,39868]
name: DeprecationWarning [39828,39846]
===
match
---
atom_expr [39599,39897]
atom_expr [39577,39875]
===
match
---
argument [30817,30824]
argument [30817,30824]
===
match
---
name: _section [22295,22303]
name: _section [22295,22303]
===
match
---
atom_expr [27567,27580]
atom_expr [27567,27580]
===
match
---
trailer [27945,27951]
trailer [27945,27951]
===
match
---
trailer [33736,33747]
trailer [33736,33747]
===
match
---
testlist_comp [6705,6746]
testlist_comp [6705,6746]
===
match
---
trailer [22465,22478]
trailer [22465,22478]
===
match
---
suite [41781,42241]
suite [41759,42219]
===
match
---
testlist_comp [14572,14584]
testlist_comp [14572,14584]
===
match
---
name: section [16439,16446]
name: section [16439,16446]
===
match
---
param [20798,20803]
param [20798,20803]
===
match
---
string: '2.0.0' [6024,6031]
string: '2.0.0' [6024,6031]
===
match
---
name: new_value [12752,12761]
name: new_value [12752,12761]
===
match
---
argument [38200,38212]
argument [38178,38190]
===
match
---
operator: , [4221,4222]
operator: , [4221,4222]
===
match
---
operator: , [9435,9436]
operator: , [9435,9436]
===
match
---
dictorsetmaker [32924,32981]
dictorsetmaker [32924,32981]
===
match
---
comparison [14571,14617]
comparison [14571,14617]
===
match
---
trailer [37038,37040]
trailer [37016,37018]
===
match
---
trailer [13862,13886]
trailer [13862,13886]
===
match
---
testlist_comp [5665,5695]
testlist_comp [5665,5695]
===
match
---
suite [21827,23270]
suite [21827,23270]
===
match
---
trailer [33243,33278]
trailer [33243,33278]
===
match
---
string: 'smtp' [4232,4238]
string: 'smtp' [4232,4238]
===
match
---
arglist [18279,18313]
arglist [18279,18313]
===
match
---
name: __getstate__ [31489,31501]
name: __getstate__ [31489,31501]
===
match
---
argument [40291,40303]
argument [40269,40281]
===
match
---
name: filterwarnings [1618,1632]
name: filterwarnings [1618,1632]
===
match
---
string: '_SECRET' [13721,13730]
string: '_SECRET' [13721,13730]
===
match
---
testlist_comp [4635,4669]
testlist_comp [4635,4669]
===
match
---
name: _include_commands [26194,26211]
name: _include_commands [26194,26211]
===
match
---
trailer [9976,10004]
trailer [9976,10004]
===
match
---
funcdef [27660,28978]
funcdef [27660,28978]
===
match
---
operator: , [6419,6420]
operator: , [6419,6420]
===
match
---
name: secrets [1358,1365]
name: secrets [1358,1365]
===
match
---
name: deprecated_key [18299,18313]
name: deprecated_key [18299,18313]
===
match
---
funcdef [33397,36566]
funcdef [33397,36544]
===
match
---
expr_stmt [25690,25736]
expr_stmt [25690,25736]
===
match
---
suite [27211,27655]
suite [27211,27655]
===
match
---
operator: = [13366,13367]
operator: = [13366,13367]
===
match
---
name: self [22072,22076]
name: self [22072,22076]
===
match
---
operator: , [6955,6956]
operator: , [6955,6956]
===
match
---
operator: , [21236,21237]
operator: , [21236,21237]
===
match
---
operator: * [38681,38682]
operator: * [38659,38660]
===
match
---
string: 'worker_precheck' [4614,4631]
string: 'worker_precheck' [4614,4631]
===
match
---
name: category [35692,35700]
name: category [35692,35700]
===
match
---
param [21760,21772]
param [21760,21772]
===
match
---
suite [10065,10176]
suite [10065,10176]
===
match
---
atom_expr [36036,36077]
atom_expr [36036,36077]
===
match
---
name: self [8454,8458]
name: self [8454,8458]
===
match
---
suite [33074,33279]
suite [33074,33279]
===
match
---
param [23291,23294]
param [23291,23294]
===
match
---
string: 'logging_level' [5100,5115]
string: 'logging_level' [5100,5115]
===
match
---
param [23941,23965]
param [23941,23965]
===
match
---
operator: = [10975,10976]
operator: = [10975,10976]
===
match
---
operator: = [21086,21087]
operator: = [21086,21087]
===
match
---
try_stmt [41391,41630]
try_stmt [41369,41608]
===
match
---
operator: = [23925,23926]
operator: = [23925,23926]
===
match
---
name: self [27855,27859]
name: self [27855,27859]
===
match
---
name: section [12249,12256]
name: section [12249,12256]
===
match
---
atom_expr [2094,2126]
atom_expr [2094,2126]
===
match
---
string: 'simple_log_format' [5707,5726]
string: 'simple_log_format' [5707,5726]
===
match
---
testlist_comp [7134,7162]
testlist_comp [7134,7162]
===
match
---
expr_stmt [13354,13384]
expr_stmt [13354,13384]
===
match
---
arglist [2482,2516]
arglist [2482,2516]
===
match
---
name: class_name [42066,42076]
name: class_name [42044,42054]
===
match
---
suite [40825,41157]
suite [40803,41135]
===
match
---
trailer [14903,14912]
trailer [14903,14912]
===
match
---
string: 'have left it at the default value you should remove the setting ' [35525,35591]
string: 'have left it at the default value you should remove the setting ' [35525,35591]
===
match
---
name: has_option [17411,17421]
name: has_option [17411,17421]
===
match
---
name: option [17029,17035]
name: option [17029,17035]
===
match
---
simple_stmt [42932,43093]
simple_stmt [42910,43071]
===
match
---
parameters [17292,17356]
parameters [17292,17356]
===
match
---
name: bool [21819,21823]
name: bool [21819,21823]
===
match
---
funcdef [42450,42579]
funcdef [42428,42557]
===
match
---
name: get [9830,9833]
name: get [9830,9833]
===
match
---
simple_stmt [20235,20277]
simple_stmt [20235,20277]
===
match
---
expr_stmt [23590,23621]
expr_stmt [23590,23621]
===
match
---
name: OrderedDict [999,1010]
name: OrderedDict [999,1010]
===
match
---
name: conf [35336,35340]
name: conf [35336,35340]
===
match
---
trailer [8876,8878]
trailer [8876,8878]
===
match
---
name: fh [32496,32498]
name: fh [32496,32498]
===
match
---
name: self [27230,27234]
name: self [27230,27234]
===
match
---
funcdef [31880,32010]
funcdef [31880,32010]
===
match
---
name: DEFAULT_SECRETS_SEARCH_PATH [42080,42107]
name: DEFAULT_SECRETS_SEARCH_PATH [42058,42085]
===
match
---
simple_stmt [15397,15411]
simple_stmt [15397,15411]
===
match
---
string: 'statsd_allow_list' [6595,6614]
string: 'statsd_allow_list' [6595,6614]
===
match
---
name: deprecated_section [31242,31260]
name: deprecated_section [31242,31260]
===
match
---
name: format [30748,30754]
name: format [30748,30754]
===
match
---
operator: = [33707,33708]
operator: = [33707,33708]
===
match
---
argument [34050,34062]
argument [34050,34062]
===
match
---
return_stmt [19501,19518]
return_stmt [19501,19518]
===
match
---
parameters [29773,29779]
parameters [29773,29779]
===
match
---
name: delimiter [23731,23740]
name: delimiter [23731,23740]
===
match
---
string: 'scheduler' [6705,6716]
string: 'scheduler' [6705,6716]
===
match
---
atom [7454,7502]
atom [7454,7502]
===
match
---
simple_stmt [14358,14370]
simple_stmt [14358,14370]
===
match
---
parameters [21753,21773]
parameters [21753,21773]
===
match
---
arith_expr [13368,13384]
arith_expr [13368,13384]
===
match
---
name: AirflowConfigException [10588,10610]
name: AirflowConfigException [10588,10610]
===
match
---
param [29448,29455]
param [29448,29455]
===
match
---
operator: , [12003,12004]
operator: , [12003,12004]
===
match
---
param [38681,38687]
param [38659,38665]
===
match
---
atom_expr [27230,27264]
atom_expr [27230,27264]
===
match
---
dictorsetmaker [28967,28975]
dictorsetmaker [28967,28975]
===
match
---
import_name [830,852]
import_name [830,852]
===
match
---
atom_expr [40024,40310]
atom_expr [40002,40288]
===
match
---
trailer [18661,18664]
trailer [18661,18664]
===
match
---
string: 'statsd_allow_list' [6631,6650]
string: 'statsd_allow_list' [6631,6650]
===
match
---
name: self [15738,15742]
name: self [15738,15742]
===
match
---
expr_stmt [42474,42526]
expr_stmt [42452,42504]
===
match
---
operator: = [10465,10466]
operator: = [10465,10466]
===
match
---
if_stmt [35222,35885]
if_stmt [35222,35885]
===
match
---
name: is_sqlite [10016,10025]
name: is_sqlite [10016,10025]
===
match
---
atom_expr [21796,21824]
atom_expr [21796,21824]
===
match
---
if_stmt [16949,16986]
if_stmt [16949,16986]
===
match
---
name: DeprecationWarning [43037,43055]
name: DeprecationWarning [43015,43033]
===
match
---
atom [6042,6091]
atom [6042,6091]
===
match
---
name: str [24091,24094]
name: str [24091,24094]
===
match
---
trailer [12216,12231]
trailer [12216,12231]
===
match
---
if_stmt [20157,20209]
if_stmt [20157,20209]
===
match
---
name: _get_secret_option [26630,26648]
name: _get_secret_option [26630,26648]
===
match
---
fstring_expr [10728,10800]
fstring_expr [10728,10800]
===
match
---
operator: , [22812,22813]
operator: , [22812,22813]
===
match
---
operator: , [7038,7039]
operator: , [7038,7039]
===
match
---
atom [7165,7201]
atom [7165,7201]
===
match
---
operator: , [15063,15064]
operator: , [15063,15064]
===
match
---
simple_stmt [18188,18202]
simple_stmt [18188,18202]
===
match
---
trailer [8676,8688]
trailer [8676,8688]
===
match
---
expr_stmt [14693,14742]
expr_stmt [14693,14742]
===
match
---
name: replace [26897,26904]
name: replace [26897,26904]
===
match
---
return_stmt [21179,21191]
return_stmt [21179,21191]
===
match
---
name: kwargs [14873,14879]
name: kwargs [14873,14879]
===
match
---
operator: , [16322,16323]
operator: , [16322,16323]
===
match
---
atom_expr [27532,27600]
atom_expr [27532,27600]
===
match
---
expr_stmt [43526,43643]
expr_stmt [43504,43621]
===
match
---
operator: , [6593,6594]
operator: , [6593,6594]
===
match
---
expr_stmt [27368,27386]
expr_stmt [27368,27386]
===
match
---
name: val [19514,19517]
name: val [19514,19517]
===
match
---
operator: = [20702,20703]
operator: = [20702,20703]
===
match
---
fstring_expr [43162,43172]
fstring_expr [43140,43150]
===
match
---
simple_stmt [8655,8705]
simple_stmt [8655,8705]
===
match
---
name: new_key [31327,31334]
name: new_key [31327,31334]
===
match
---
operator: , [4670,4671]
operator: , [4670,4671]
===
match
---
name: info [8902,8906]
name: info [8902,8906]
===
match
---
operator: , [15474,15475]
operator: , [15474,15475]
===
match
---
name: path [33177,33181]
name: path [33177,33181]
===
match
---
string: 'logging' [5011,5020]
string: 'logging' [5011,5020]
===
match
---
name: option [21579,21585]
name: option [21579,21585]
===
match
---
argument [20763,20776]
argument [20763,20776]
===
match
---
parameters [38274,38291]
parameters [38252,38269]
===
match
---
trailer [13265,13274]
trailer [13265,13274]
===
match
---
trailer [16419,16438]
trailer [16419,16438]
===
match
---
name: dictionary [20740,20750]
name: dictionary [20740,20750]
===
match
---
operator: , [1400,1401]
operator: , [1400,1401]
===
match
---
expr_stmt [44289,44310]
expr_stmt [44267,44288]
===
match
---
operator: , [16165,16166]
operator: , [16165,16166]
===
match
---
testlist_comp [4201,4220]
testlist_comp [4201,4220]
===
match
---
simple_stmt [10888,10942]
simple_stmt [10888,10942]
===
match
---
string: 'default_airflow.cfg' [42338,42359]
string: 'default_airflow.cfg' [42316,42337]
===
match
---
atom [6205,6235]
atom [6205,6235]
===
match
---
trailer [7848,7879]
trailer [7848,7879]
===
match
---
atom_expr [25781,25802]
atom_expr [25781,25802]
===
match
---
name: open [3386,3390]
name: open [3386,3390]
===
match
---
trailer [14713,14715]
trailer [14713,14715]
===
match
---
simple_stmt [12202,12232]
simple_stmt [12202,12232]
===
match
---
expr_stmt [2319,2445]
expr_stmt [2319,2445]
===
match
---
name: fernet [33331,33337]
name: fernet [33331,33337]
===
match
---
trailer [35410,35415]
trailer [35410,35415]
===
match
---
simple_stmt [27224,27265]
simple_stmt [27224,27265]
===
match
---
atom_expr [34310,34333]
atom_expr [34310,34333]
===
match
---
simple_stmt [22128,22140]
simple_stmt [22128,22140]
===
match
---
string: "Accessing configuration method 'remove_option' directly from the configuration module is " [39622,39713]
string: "Accessing configuration method 'remove_option' directly from the configuration module is " [39600,39691]
===
match
---
param [15840,15845]
param [15840,15845]
===
match
---
operator: , [16156,16157]
operator: , [16156,16157]
===
match
---
name: lower [23061,23066]
name: lower [23061,23066]
===
match
---
if_stmt [8612,8705]
if_stmt [8612,8705]
===
match
---
operator: = [12158,12159]
operator: = [12158,12159]
===
match
---
atom_expr [14634,14675]
atom_expr [14634,14675]
===
match
---
trailer [2942,2944]
trailer [2942,2944]
===
match
---
expr_stmt [18641,18672]
expr_stmt [18641,18672]
===
match
---
name: default_config [8615,8629]
name: default_config [8615,8629]
===
match
---
name: expand_env_var [17858,17872]
name: expand_env_var [17858,17872]
===
match
---
name: kwargs [19419,19425]
name: kwargs [19419,19425]
===
match
---
arglist [28272,28296]
arglist [28272,28296]
===
match
---
fstring [43153,43197]
fstring [43131,43175]
===
match
---
name: has_option [34895,34905]
name: has_option [34895,34905]
===
match
---
operator: , [39034,39035]
operator: , [39012,39013]
===
match
---
argument [15789,15797]
argument [15789,15797]
===
match
---
if_stmt [33729,36115]
if_stmt [33729,36115]
===
match
---
atom [23072,23085]
atom [23072,23085]
===
match
---
param [30468,30476]
param [30468,30476]
===
match
---
param [19397,19402]
param [19397,19402]
===
match
---
trailer [26193,26211]
trailer [26193,26211]
===
match
---
operator: , [7906,7907]
operator: , [7906,7907]
===
match
---
trailer [16926,16940]
trailer [16926,16940]
===
match
---
string: 'secrets' [41328,41337]
string: 'secrets' [41306,41315]
===
match
---
name: section [18131,18138]
name: section [18131,18138]
===
match
---
strings [40474,40672]
strings [40452,40650]
===
match
---
operator: , [4062,4063]
operator: , [4062,4063]
===
match
---
arglist [29562,29584]
arglist [29562,29584]
===
match
---
operator: , [4190,4191]
operator: , [4190,4191]
===
match
---
string: '2.0.0' [5400,5407]
string: '2.0.0' [5400,5407]
===
match
---
name: args [38276,38280]
name: args [38254,38258]
===
match
---
simple_stmt [23525,23564]
simple_stmt [23525,23564]
===
match
---
operator: , [7174,7175]
operator: , [7174,7175]
===
match
---
param [21230,21237]
param [21230,21237]
===
match
---
name: option [15676,15682]
name: option [15676,15682]
===
match
---
operator: , [18297,18298]
operator: , [18297,18298]
===
match
---
if_stmt [2136,2245]
if_stmt [2136,2245]
===
match
---
name: StrictVersion [10267,10280]
name: StrictVersion [10267,10280]
===
match
---
expr_stmt [13144,13186]
expr_stmt [13144,13186]
===
match
---
string: '_secret' [27051,27060]
string: '_secret' [27051,27060]
===
match
---
name: deprecated_section [17711,17729]
name: deprecated_section [17711,17729]
===
match
---
name: config_key [2828,2838]
name: config_key [2828,2838]
===
match
---
number: 3 [31463,31464]
number: 3 [31463,31464]
===
match
---
name: OrderedDict [22387,22398]
name: OrderedDict [22387,22398]
===
match
---
trailer [39490,39507]
trailer [39468,39485]
===
match
---
trailer [32979,32981]
trailer [32979,32981]
===
match
---
string: '2.0.0' [6177,6184]
string: '2.0.0' [6177,6184]
===
match
---
operator: , [39964,39965]
operator: , [39942,39943]
===
match
---
trailer [43649,43654]
trailer [43627,43632]
===
match
---
operator: , [29600,29601]
operator: , [29600,29601]
===
match
---
name: warn [37522,37526]
name: warn [37500,37504]
===
match
---
fstring_string: , Stderr:  [2735,2745]
fstring_string: , Stderr:  [2735,2745]
===
match
---
expr_stmt [8947,8971]
expr_stmt [8947,8971]
===
match
---
suite [27740,28978]
suite [27740,28978]
===
match
---
trailer [10610,10819]
trailer [10610,10819]
===
match
---
simple_stmt [16003,16076]
simple_stmt [16003,16076]
===
match
---
comparison [28816,28861]
comparison [28816,28861]
===
match
---
simple_stmt [43733,43787]
simple_stmt [43711,43765]
===
match
---
name: stacklevel [38604,38614]
name: stacklevel [38582,38592]
===
match
---
name: option [16625,16631]
name: option [16625,16631]
===
match
---
name: section [20804,20811]
name: section [20804,20811]
===
match
---
if_stmt [2949,2992]
if_stmt [2949,2992]
===
match
---
simple_stmt [2900,2945]
simple_stmt [2900,2945]
===
match
---
name: warn [37940,37944]
name: warn [37918,37922]
===
match
---
name: DeprecationWarning [38172,38190]
name: DeprecationWarning [38150,38168]
===
match
---
trailer [43595,43623]
trailer [43573,43601]
===
match
---
atom_expr [1609,1697]
atom_expr [1609,1697]
===
match
---
if_stmt [42900,43128]
if_stmt [42878,43106]
===
match
---
operator: = [9217,9218]
operator: = [9217,9218]
===
match
---
name: val [18641,18644]
name: val [18641,18644]
===
match
---
argument [31327,31338]
argument [31327,31338]
===
match
---
string: '2.0.0' [6265,6272]
string: '2.0.0' [6265,6272]
===
match
---
operator: == [30539,30541]
operator: == [30539,30541]
===
match
---
name: log [1508,1511]
name: log [1508,1511]
===
match
---
name: copy [36447,36451]
name: copy [36447,36451]
===
match
---
name: setdefault [27547,27557]
name: setdefault [27547,27557]
===
match
---
suite [41382,41701]
suite [41360,41679]
===
match
---
string: 'statsd_prefix' [6548,6563]
string: 'statsd_prefix' [6548,6563]
===
match
---
operator: = [11424,11425]
operator: = [11424,11425]
===
match
---
operator: , [19458,19459]
operator: , [19458,19459]
===
match
---
name: self [13037,13041]
name: self [13037,13041]
===
match
---
name: output [2777,2783]
name: output [2777,2783]
===
match
---
atom [4869,4908]
atom [4869,4908]
===
match
---
operator: + [11235,11236]
operator: + [11235,11236]
===
match
---
simple_stmt [8419,8436]
simple_stmt [8419,8436]
===
match
---
name: config_file [3478,3489]
name: config_file [3478,3489]
===
match
---
name: stacklevel [39022,39032]
name: stacklevel [39000,39010]
===
match
---
name: get [21057,21060]
name: get [21057,21060]
===
match
---
trailer [34756,34762]
trailer [34756,34762]
===
match
---
fstring_end: ' [20476,20477]
fstring_end: ' [20476,20477]
===
match
---
suite [14186,14350]
suite [14186,14350]
===
match
---
name: path [42305,42309]
name: path [42283,42287]
===
match
---
name: _default_config_file_path [30072,30097]
name: _default_config_file_path [30072,30097]
===
match
---
simple_stmt [22982,22999]
simple_stmt [22982,22999]
===
match
---
atom_expr [34213,34268]
atom_expr [34213,34268]
===
match
---
name: warn [39608,39612]
name: warn [39586,39590]
===
match
---
trailer [33692,33723]
trailer [33692,33723]
===
match
---
name: self [26048,26052]
name: self [26048,26052]
===
match
---
operator: * [38245,38246]
operator: * [38223,38224]
===
match
---
trailer [7976,7984]
trailer [7976,7984]
===
match
---
operator: , [13041,13042]
operator: , [13041,13042]
===
match
---
arglist [11362,11399]
arglist [11362,11399]
===
match
---
string: 'howto/set-up-database.rst#setting-up-a-sqlite-database' [10742,10798]
string: 'howto/set-up-database.rst#setting-up-a-sqlite-database' [10742,10798]
===
match
---
simple_stmt [9189,9259]
simple_stmt [9189,9259]
===
match
---
operator: , [15654,15655]
operator: , [15654,15655]
===
match
---
name: _get_option_from_secrets [16277,16301]
name: _get_option_from_secrets [16277,16301]
===
match
---
suite [20597,20659]
suite [20597,20659]
===
match
---
name: deprecated_section [16574,16592]
name: deprecated_section [16574,16592]
===
match
---
trailer [17614,17616]
trailer [17614,17616]
===
match
---
name: opt [28448,28451]
name: opt [28448,28451]
===
match
---
name: read [32607,32611]
name: read [32607,32611]
===
match
---
funcdef [39947,40352]
funcdef [39925,40330]
===
match
---
name: DeprecationWarning [38576,38594]
name: DeprecationWarning [38554,38572]
===
match
---
testlist_comp [5747,5784]
testlist_comp [5747,5784]
===
match
---
atom_expr [8774,8810]
atom_expr [8774,8810]
===
match
---
operator: = [34057,34058]
operator: = [34057,34058]
===
match
---
atom_expr [16906,16940]
atom_expr [16906,16940]
===
match
---
fstring_start: f' [19237,19239]
fstring_start: f' [19237,19239]
===
match
---
name: self [17134,17138]
name: self [17134,17138]
===
match
---
string: "core" [9834,9840]
string: "core" [9834,9840]
===
match
---
name: option [16743,16749]
name: option [16743,16749]
===
match
---
suite [26724,26764]
suite [26724,26764]
===
match
---
name: old [9084,9087]
name: old [9084,9087]
===
match
---
suite [16358,16770]
suite [16358,16770]
===
match
---
comparison [8615,8641]
comparison [8615,8641]
===
match
---
operator: = [15260,15261]
operator: = [15260,15261]
===
match
---
suite [27474,27520]
suite [27474,27520]
===
match
---
atom_expr [30397,30424]
atom_expr [30397,30424]
===
match
---
fstring_expr [10677,10697]
fstring_expr [10677,10697]
===
match
---
name: self [16025,16029]
name: self [16025,16029]
===
match
---
name: _replace_config_with_display_sources [29005,29041]
name: _replace_config_with_display_sources [29005,29041]
===
match
---
name: fallback_key [14486,14498]
name: fallback_key [14486,14498]
===
match
---
trailer [15951,15965]
trailer [15951,15965]
===
match
---
name: configs [29058,29065]
name: configs [29058,29065]
===
match
---
name: Fernet [34105,34111]
name: Fernet [34105,34111]
===
match
---
operator: } [31709,31710]
operator: } [31709,31710]
===
match
---
atom [4918,4955]
atom [4918,4955]
===
match
---
simple_stmt [1345,1421]
simple_stmt [1345,1421]
===
match
---
operator: , [5674,5675]
operator: , [5674,5675]
===
match
---
name: raw [29488,29491]
name: raw [29488,29491]
===
match
---
name: state [31871,31876]
name: state [31871,31876]
===
match
---
operator: , [28165,28166]
operator: , [28165,28166]
===
match
---
param [27735,27738]
param [27735,27738]
===
match
---
name: airflow_home [32035,32047]
name: airflow_home [32035,32047]
===
match
---
name: PIPE [2395,2399]
name: PIPE [2395,2399]
===
match
---
name: log [36356,36359]
name: log [36356,36359]
===
match
---
argument [39498,39506]
argument [39476,39484]
===
match
---
name: section [9210,9217]
name: section [9210,9217]
===
match
---
name: self [20798,20802]
name: self [20798,20802]
===
match
---
trailer [23606,23618]
trailer [23606,23618]
===
match
---
name: getboolean [18496,18506]
name: getboolean [18496,18506]
===
match
---
trailer [32611,32613]
trailer [32611,32613]
===
match
---
atom_expr [10977,11016]
atom_expr [10977,11016]
===
match
---
atom_expr [22705,22713]
atom_expr [22705,22713]
===
match
---
trailer [22551,22562]
trailer [22551,22562]
===
match
---
operator: , [6293,6294]
operator: , [6293,6294]
===
match
---
string: 'statsd_port' [6441,6454]
string: 'statsd_port' [6441,6454]
===
match
---
testlist_comp [6988,7037]
testlist_comp [6988,7037]
===
match
---
name: new_value [12264,12273]
name: new_value [12264,12273]
===
match
---
suite [16959,16986]
suite [16959,16986]
===
match
---
name: new_section [31360,31371]
name: new_section [31360,31371]
===
match
---
trailer [34762,34778]
trailer [34762,34778]
===
match
---
name: endswith [22661,22669]
name: endswith [22661,22669]
===
match
---
name: section [15043,15050]
name: section [15043,15050]
===
match
---
operator: ** [15789,15791]
operator: ** [15789,15791]
===
match
---
string: 'setting has been used, but please update your config.' [30692,30747]
string: 'setting has been used, but please update your config.' [30692,30747]
===
match
---
suite [26606,27062]
suite [26606,27062]
===
match
---
name: remove_default [21653,21667]
name: remove_default [21653,21667]
===
match
---
expr_stmt [22982,22998]
expr_stmt [22982,22998]
===
match
---
operator: = [27228,27229]
operator: = [27228,27229]
===
match
---
trailer [25785,25802]
trailer [25785,25802]
===
match
---
name: val [29697,29700]
name: val [29697,29700]
===
match
---
param [23911,23932]
param [23911,23932]
===
match
---
name: staticmethod [12281,12293]
name: staticmethod [12281,12293]
===
match
---
funcdef [21739,23270]
funcdef [21739,23270]
===
match
---
name: config [29115,29121]
name: config [29115,29121]
===
match
---
suite [14418,14838]
suite [14418,14838]
===
match
---
comparison [15969,15989]
comparison [15969,15989]
===
match
---
if_stmt [34887,35885]
if_stmt [34887,35885]
===
match
---
if_stmt [16461,16498]
if_stmt [16461,16498]
===
match
---
trailer [17697,17699]
trailer [17697,17699]
===
match
---
name: file [34730,34734]
name: file [34730,34734]
===
match
---
trailer [36298,36305]
trailer [36298,36305]
===
match
---
atom_expr [13569,13592]
atom_expr [13569,13592]
===
match
---
suite [15695,15722]
suite [15695,15722]
===
match
---
operator: = [43703,43704]
operator: = [43681,43682]
===
match
---
name: interpolated [2183,2195]
name: interpolated [2183,2195]
===
match
---
atom_expr [9968,10004]
atom_expr [9968,10004]
===
match
---
string: "Accessing configuration method 'has_option' directly from the configuration module is " [39194,39282]
string: "Accessing configuration method 'has_option' directly from the configuration module is " [39172,39260]
===
match
---
comparison [11921,11958]
comparison [11921,11958]
===
match
---
atom_expr [22399,22418]
atom_expr [22399,22418]
===
match
---
operator: = [30853,30854]
operator: = [30853,30854]
===
match
---
operator: , [14660,14661]
operator: , [14660,14661]
===
match
---
string: 'email_backend' [7939,7954]
string: 'email_backend' [7939,7954]
===
match
---
name: self [18106,18110]
name: self [18106,18110]
===
match
---
name: distutils [10242,10251]
name: distutils [10242,10251]
===
match
---
argument [37411,37416]
argument [37389,37394]
===
match
---
name: val [23242,23245]
name: val [23242,23245]
===
match
---
string: 'default_queue' [7176,7191]
string: 'default_queue' [7176,7191]
===
match
---
name: int [21807,21810]
name: int [21807,21810]
===
match
---
trailer [22660,22669]
trailer [22660,22669]
===
match
---
string: r'^airflow\.contrib\.utils\.sendgrid\.send_email$' [7985,8035]
string: r'^airflow\.contrib\.utils\.sendgrid\.send_email$' [7985,8035]
===
match
---
atom [42843,42866]
atom [42821,42844]
===
match
---
param [17335,17339]
param [17335,17339]
===
match
---
name: info [34488,34492]
name: info [34488,34492]
===
match
---
return_stmt [15553,15566]
return_stmt [15553,15566]
===
match
---
atom_expr [40741,40766]
atom_expr [40719,40744]
===
match
---
operator: , [16825,16826]
operator: , [16825,16826]
===
match
---
atom_expr [37817,37849]
atom_expr [37795,37827]
===
match
---
atom_expr [39171,39463]
atom_expr [39149,39441]
===
match
---
name: AirflowConfigException [18833,18855]
name: AirflowConfigException [18833,18855]
===
match
---
file_input [786,44521]
file_input [786,44515]
===
match
---
trailer [26629,26648]
trailer [26629,26648]
===
match
---
operator: = [8572,8573]
operator: = [8572,8573]
===
match
---
operator: , [11997,11998]
operator: , [11997,11998]
===
match
---
atom_expr [43954,43990]
atom_expr [43932,43968]
===
match
---
name: upper [12983,12988]
name: upper [12983,12988]
===
match
---
name: sensitive_config_values [14594,14617]
name: sensitive_config_values [14594,14617]
===
match
---
operator: = [4005,4006]
operator: = [4005,4006]
===
match
---
testlist_comp [21135,21164]
testlist_comp [21135,21164]
===
match
---
parameters [23887,24072]
parameters [23887,24072]
===
match
---
if_stmt [23485,23622]
if_stmt [23485,23622]
===
match
---
operator: , [4171,4172]
operator: , [4171,4172]
===
match
---
string: '2.0.0' [6739,6746]
string: '2.0.0' [6739,6746]
===
match
---
name: lower [28889,28894]
name: lower [28889,28894]
===
match
---
trailer [28389,28400]
trailer [28389,28400]
===
match
---
atom_expr [41470,41534]
atom_expr [41448,41512]
===
match
---
name: start_method_options [11056,11076]
name: start_method_options [11056,11076]
===
match
---
atom_expr [16550,16609]
atom_expr [16550,16609]
===
match
---
trailer [30097,30117]
trailer [30097,30117]
===
match
---
name: close_fds [2425,2434]
name: close_fds [2425,2434]
===
match
---
expr_stmt [23226,23245]
expr_stmt [23226,23245]
===
match
---
name: key [28967,28970]
name: key [28967,28970]
===
match
---
name: items [8871,8876]
name: items [8871,8876]
===
match
---
name: warnings [39171,39179]
name: warnings [39149,39157]
===
match
---
simple_stmt [863,878]
simple_stmt [863,878]
===
match
---
name: str [12931,12934]
name: str [12931,12934]
===
match
---
atom_expr [38231,38261]
atom_expr [38209,38239]
===
match
---
name: airflow [1296,1303]
name: airflow [1296,1303]
===
match
---
trailer [42707,42715]
trailer [42685,42693]
===
match
---
name: msg [35851,35854]
name: msg [35851,35854]
===
match
---
argument [40710,40722]
argument [40688,40700]
===
match
---
name: mkdir [34591,34596]
name: mkdir [34591,34596]
===
match
---
name: TEST_DAGS_FOLDER [43686,43702]
name: TEST_DAGS_FOLDER [43664,43680]
===
match
---
simple_stmt [41408,41549]
simple_stmt [41386,41527]
===
match
---
operator: , [39434,39435]
operator: , [39412,39413]
===
match
---
string: 'logging_config_class' [5256,5278]
string: 'logging_config_class' [5256,5278]
===
match
---
suite [40421,40767]
suite [40399,40745]
===
match
---
raise_stmt [2596,2764]
raise_stmt [2596,2764]
===
match
---
string: 'worker_precheck' [4643,4660]
string: 'worker_precheck' [4643,4660]
===
match
---
operator: = [9513,9514]
operator: = [9513,9514]
===
match
---
name: val [29602,29605]
name: val [29602,29605]
===
match
---
operator: } [20532,20533]
operator: } [20532,20533]
===
match
---
operator: = [27495,27496]
operator: = [27495,27496]
===
match
---
name: parameterized_config [32583,32603]
name: parameterized_config [32583,32603]
===
match
---
name: self [22399,22403]
name: self [22399,22403]
===
match
---
trailer [40745,40749]
trailer [40723,40727]
===
match
---
suite [32725,33030]
suite [32725,33030]
===
match
---
simple_stmt [17243,17255]
simple_stmt [17243,17255]
===
match
---
name: section [13487,13494]
name: section [13487,13494]
===
match
---
argument [29640,29647]
argument [29640,29647]
===
match
---
operator: , [6747,6748]
operator: , [6747,6748]
===
match
---
simple_stmt [40315,40352]
simple_stmt [40293,40330]
===
match
---
return_stmt [33357,33394]
return_stmt [33357,33394]
===
match
---
operator: , [24036,24037]
operator: , [24036,24037]
===
match
---
name: section [15846,15853]
name: section [15846,15853]
===
match
---
name: self [19767,19771]
name: self [19767,19771]
===
match
---
operator: { [7689,7690]
operator: { [7689,7690]
===
match
---
simple_stmt [41228,41279]
simple_stmt [41206,41257]
===
match
---
atom_expr [21786,21825]
atom_expr [21786,21825]
===
match
---
atom [13840,13854]
atom [13840,13854]
===
match
---
param [27111,27129]
param [27111,27129]
===
match
---
strings [39622,39840]
strings [39600,39818]
===
match
---
name: strip [32614,32619]
name: strip [32614,32619]
===
match
---
operator: { [41627,41628]
operator: { [41605,41606]
===
match
---
trailer [34126,34133]
trailer [34126,34133]
===
match
---
parameters [31732,31745]
parameters [31732,31745]
===
match
---
name: _warn_deprecate [16654,16669]
name: _warn_deprecate [16654,16669]
===
match
---
atom [31588,31700]
atom [31588,31700]
===
match
---
simple_stmt [41705,41717]
simple_stmt [41683,41695]
===
match
---
simple_stmt [19501,19519]
simple_stmt [19501,19519]
===
match
---
suite [26866,26916]
suite [26866,26916]
===
match
---
name: name [12325,12329]
name: name [12325,12329]
===
match
---
operator: , [4990,4991]
operator: , [4990,4991]
===
match
---
string: 'Creating new FAB webserver config file in: %s' [36365,36412]
string: 'Creating new FAB webserver config file in: %s' [36365,36412]
===
match
---
name: current_value [9089,9102]
name: current_value [9089,9102]
===
match
---
name: alternative_secrets_config_dict [41593,41624]
name: alternative_secrets_config_dict [41571,41602]
===
match
---
number: 3 [30945,30946]
number: 3 [30945,30946]
===
match
---
arglist [9834,9852]
arglist [9834,9852]
===
match
---
atom_expr [22901,22909]
atom_expr [22901,22909]
===
match
---
name: file_parser_modes [11598,11615]
name: file_parser_modes [11598,11615]
===
match
---
fstring_end: " [32685,32686]
fstring_end: " [32685,32686]
===
match
---
operator: , [20761,20762]
operator: , [20761,20762]
===
match
---
operator: , [34825,34826]
operator: , [34825,34826]
===
match
---
trailer [3017,3028]
trailer [3017,3028]
===
match
---
operator: , [19045,19046]
operator: , [19045,19046]
===
match
---
atom_expr [31788,31810]
atom_expr [31788,31810]
===
match
---
string: 'Creating new Airflow config file for unit tests in: %s' [33929,33985]
string: 'Creating new Airflow config file for unit tests in: %s' [33929,33985]
===
match
---
funcdef [27067,27655]
funcdef [27067,27655]
===
match
---
name: secrets_path [14804,14816]
name: secrets_path [14804,14816]
===
match
---
argument [19465,19473]
argument [19465,19473]
===
match
---
trailer [22858,22860]
trailer [22858,22860]
===
match
---
atom_expr [32604,32621]
atom_expr [32604,32621]
===
match
---
operator: , [35854,35855]
operator: , [35854,35855]
===
match
---
name: get [41475,41478]
name: get [41453,41456]
===
match
---
expr_stmt [15253,15353]
expr_stmt [15253,15353]
===
match
---
testlist_comp [6383,6418]
testlist_comp [6383,6418]
===
match
---
operator: , [6514,6515]
operator: , [6514,6515]
===
match
---
operator: , [7773,7774]
operator: , [7773,7774]
===
match
---
name: join [11289,11293]
name: join [11289,11293]
===
match
---
operator: , [30916,30917]
operator: , [30916,30917]
===
match
---
param [42889,42893]
param [42867,42871]
===
match
---
trailer [13508,13532]
trailer [13508,13532]
===
match
---
name: process [2532,2539]
name: process [2532,2539]
===
match
---
string: 'statsd_datadog_enabled' [6769,6793]
string: 'statsd_datadog_enabled' [6769,6793]
===
match
---
suite [22678,22714]
suite [22678,22714]
===
match
---
name: config_sources [25690,25704]
name: config_sources [25690,25704]
===
match
---
trailer [27546,27557]
trailer [27546,27557]
===
match
---
atom [7255,7307]
atom [7255,7307]
===
match
---
name: args [39104,39108]
name: args [39082,39086]
===
match
---
atom_expr [28885,28896]
atom_expr [28885,28896]
===
match
---
simple_stmt [901,919]
simple_stmt [901,919]
===
match
---
string: 'AIRFLOW__' [12863,12874]
string: 'AIRFLOW__' [12863,12874]
===
match
---
operator: , [8831,8832]
operator: , [8831,8832]
===
match
---
name: key [16344,16347]
name: key [16344,16347]
===
match
---
simple_stmt [33426,33544]
simple_stmt [33426,33544]
===
match
---
operator: , [16702,16703]
operator: , [16702,16703]
===
match
---
simple_stmt [37901,37927]
simple_stmt [37879,37905]
===
match
---
name: WEBSERVER_CONFIG [36510,36526]
name: WEBSERVER_CONFIG [36510,36526]
===
match
---
operator: >= [44446,44448]
operator: >= [44440,44442]
===
match
---
string: "alphabetical" [11549,11563]
string: "alphabetical" [11549,11563]
===
match
---
name: append [42027,42033]
name: append [42005,42011]
===
match
---
param [8460,8480]
param [8460,8480]
===
match
---
expr_stmt [9944,10004]
expr_stmt [9944,10004]
===
match
---
name: airflow [1350,1357]
name: airflow [1350,1357]
===
match
---
return_stmt [20235,20276]
return_stmt [20235,20276]
===
match
---
name: isfile [36299,36305]
name: isfile [36299,36305]
===
match
---
operator: = [34103,34104]
operator: = [34103,34104]
===
match
---
atom_expr [23057,23068]
atom_expr [23057,23068]
===
match
---
operator: , [6864,6865]
operator: , [6864,6865]
===
match
---
operator: , [18419,18420]
operator: , [18419,18420]
===
match
---
simple_stmt [13990,14002]
simple_stmt [13990,14002]
===
match
---
trailer [18656,18661]
trailer [18656,18661]
===
match
---
operator: , [34720,34721]
operator: , [34720,34721]
===
match
---
operator: @ [42415,42416]
operator: @ [42393,42394]
===
match
---
name: process [2682,2689]
name: process [2682,2689]
===
match
---
trailer [15774,15798]
trailer [15774,15798]
===
match
---
operator: } [19360,19361]
operator: } [19360,19361]
===
match
---
name: str [21769,21772]
name: str [21769,21772]
===
match
---
atom_expr [17858,17931]
atom_expr [17858,17931]
===
match
---
operator: { [20456,20457]
operator: { [20456,20457]
===
match
---
string: '%%' [27514,27518]
string: '%%' [27514,27518]
===
match
---
name: option [15198,15204]
name: option [15198,15204]
===
match
---
operator: = [39032,39033]
operator: = [39010,39011]
===
match
---
name: section [15775,15782]
name: section [15775,15782]
===
match
---
name: str [8398,8401]
name: str [8398,8401]
===
match
---
operator: } [11823,11824]
operator: } [11823,11824]
===
match
---
name: os [43850,43852]
name: os [43828,43830]
===
match
---
string: "'conf.as_dict'" [40237,40253]
string: "'conf.as_dict'" [40215,40231]
===
match
---
operator: , [38652,38653]
operator: , [38630,38631]
===
match
---
name: key [14939,14942]
name: key [14939,14942]
===
match
---
name: self [22231,22235]
name: self [22231,22235]
===
match
---
name: super [14634,14639]
name: super [14634,14639]
===
match
---
param [12340,12354]
param [12340,12354]
===
match
---
name: _get_option_from_commands [16779,16804]
name: _get_option_from_commands [16779,16804]
===
match
---
operator: , [32172,32173]
operator: , [32172,32173]
===
match
---
string: "'conf.getfloat'" [38145,38162]
string: "'conf.getfloat'" [38123,38140]
===
match
---
string: 'fallback' [15969,15979]
string: 'fallback' [15969,15979]
===
match
---
trailer [13211,13219]
trailer [13211,13219]
===
match
---
name: os [43954,43956]
name: os [43932,43934]
===
match
---
trailer [8921,8927]
trailer [8921,8927]
===
match
---
operator: , [5342,5343]
operator: , [5342,5343]
===
match
---
argument [35290,35317]
argument [35290,35317]
===
match
---
suite [17747,17932]
suite [17747,17932]
===
match
---
operator: { [12993,12994]
operator: { [12993,12994]
===
match
---
name: env_var [13711,13718]
name: env_var [13711,13718]
===
match
---
trailer [34705,34726]
trailer [34705,34726]
===
match
---
parameters [37864,37881]
parameters [37842,37859]
===
match
---
name: get_docs_url [10729,10741]
name: get_docs_url [10729,10741]
===
match
---
name: config_sources [27617,27631]
name: config_sources [27617,27631]
===
match
---
parameters [19766,19796]
parameters [19766,19796]
===
match
---
operator: = [2327,2328]
operator: = [2327,2328]
===
match
---
name: name [31580,31584]
name: name [31580,31584]
===
match
---
atom [6309,6344]
atom [6309,6344]
===
match
---
operator: } [13005,13006]
operator: } [13005,13006]
===
match
---
operator: ** [39498,39500]
operator: ** [39476,39478]
===
match
---
string: 'broker_url' [4098,4110]
string: 'broker_url' [4098,4110]
===
match
---
atom [7956,8146]
atom [7956,8146]
===
match
---
string: "Accessing configuration method 'getint' directly from the configuration module is " [38362,38446]
string: "Accessing configuration method 'getint' directly from the configuration module is " [38340,38424]
===
match
---
name: configs [25745,25752]
name: configs [25745,25752]
===
match
---
name: List [41756,41760]
name: List [41734,41738]
===
match
---
name: ENV_VAR_PREFIX [27860,27874]
name: ENV_VAR_PREFIX [27860,27874]
===
match
---
name: section [16158,16165]
name: section [16158,16165]
===
match
---
atom [4603,4632]
atom [4603,4632]
===
match
---
simple_stmt [23202,23214]
simple_stmt [23202,23214]
===
match
---
return_stmt [41088,41124]
return_stmt [41066,41102]
===
match
---
trailer [11804,11823]
trailer [11804,11823]
===
match
---
trailer [9972,9976]
trailer [9972,9976]
===
match
---
name: opt [27434,27437]
name: opt [27434,27437]
===
match
---
simple_stmt [14486,14517]
simple_stmt [14486,14517]
===
match
---
atom_expr [23633,23647]
atom_expr [23633,23647]
===
match
---
operator: , [4278,4279]
operator: , [4278,4279]
===
match
---
funcdef [32012,32245]
funcdef [32012,32245]
===
match
---
atom_expr [30605,30880]
atom_expr [30605,30880]
===
match
---
testlist_comp [6855,6887]
testlist_comp [6855,6887]
===
match
---
return_stmt [14759,14817]
return_stmt [14759,14817]
===
match
---
name: _get_env_var_option [22785,22804]
name: _get_env_var_option [22785,22804]
===
match
---
operator: , [16347,16348]
operator: , [16347,16348]
===
match
---
name: custom_secret_backend [41911,41932]
name: custom_secret_backend [41889,41910]
===
match
---
operator: , [5234,5235]
operator: , [5234,5235]
===
match
---
simple_stmt [35773,35821]
simple_stmt [35773,35821]
===
match
---
operator: { [42961,42962]
operator: { [42939,42940]
===
match
---
string: """     Load the Airflow config files.      Called for you automatically as part of the Airflow boot process.     """ [33426,33543]
string: """     Load the Airflow config files.      Called for you automatically as part of the Airflow boot process.     """ [33426,33543]
===
match
---
simple_stmt [29994,30023]
simple_stmt [29994,30023]
===
match
---
operator: , [40281,40282]
operator: , [40259,40260]
===
match
---
testlist_comp [7256,7306]
testlist_comp [7256,7306]
===
match
---
comparison [18156,18174]
comparison [18156,18174]
===
match
---
operator: = [29742,29743]
operator: = [29742,29743]
===
match
---
suite [14244,14350]
suite [14244,14350]
===
match
---
string: '2.0.0' [5728,5735]
string: '2.0.0' [5728,5735]
===
match
---
atom_expr [34701,34726]
atom_expr [34701,34726]
===
match
---
param [23974,23984]
param [23974,23984]
===
match
---
name: str [2113,2116]
name: str [2113,2116]
===
match
---
arglist [9013,9041]
arglist [9013,9041]
===
match
---
if_stmt [17689,17932]
if_stmt [17689,17932]
===
match
---
trailer [35245,35253]
trailer [35245,35253]
===
match
---
operator: == [41074,41076]
operator: == [41052,41054]
===
match
---
simple_stmt [2222,2245]
simple_stmt [2222,2245]
===
match
---
operator: ** [19100,19102]
operator: ** [19100,19102]
===
match
---
name: self [23661,23665]
name: self [23661,23665]
===
match
---
fstring [19604,19690]
fstring [19604,19690]
===
match
---
trailer [3193,3219]
trailer [3193,3219]
===
match
---
testlist_comp [6946,6984]
testlist_comp [6946,6984]
===
match
---
suite [26035,26123]
suite [26035,26123]
===
match
---
simple_stmt [27920,27961]
simple_stmt [27920,27961]
===
match
---
name: write [23279,23284]
name: write [23279,23284]
===
match
---
atom_expr [43647,43680]
atom_expr [43625,43658]
===
match
---
name: OrderedDict [27567,27578]
name: OrderedDict [27567,27578]
===
match
---
name: self [21754,21758]
name: self [21754,21758]
===
match
---
name: environ [22512,22519]
name: environ [22512,22519]
===
match
---
operator: * [39103,39104]
operator: * [39081,39082]
===
match
---
simple_stmt [15096,15187]
simple_stmt [15096,15187]
===
match
---
atom_expr [31019,31398]
atom_expr [31019,31398]
===
match
---
name: log [20322,20325]
name: log [20322,20325]
===
match
---
name: env_var [22544,22551]
name: env_var [22544,22551]
===
match
---
suite [43728,43787]
suite [43706,43765]
===
match
---
operator: = [26823,26824]
operator: = [26823,26824]
===
match
---
fstring_expr [12953,12974]
fstring_expr [12953,12974]
===
match
---
arglist [14283,14304]
arglist [14283,14304]
===
match
---
string: 'statsd_on' [6323,6334]
string: 'statsd_on' [6323,6334]
===
match
---
name: mp_start_method [11033,11048]
name: mp_start_method [11033,11048]
===
match
---
expr_stmt [33585,33660]
expr_stmt [33585,33660]
===
match
---
trailer [31001,31479]
trailer [31001,31479]
===
match
---
suite [20834,21119]
suite [20834,21119]
===
match
---
name: _env_var_name [22452,22465]
name: _env_var_name [22452,22465]
===
match
---
operator: , [26539,26540]
operator: , [26539,26540]
===
match
---
if_stmt [14136,14350]
if_stmt [14136,14350]
===
match
---
funcdef [32247,32688]
funcdef [32247,32688]
===
match
---
name: partial [42808,42815]
name: partial [42786,42793]
===
match
---
atom_expr [15105,15186]
atom_expr [15105,15186]
===
match
---
name: filterwarnings [1711,1725]
name: filterwarnings [1711,1725]
===
match
---
name: env_var [2155,2162]
name: env_var [2155,2162]
===
match
---
string: 'password' [4210,4220]
string: 'password' [4210,4220]
===
match
---
suite [8879,9545]
suite [8879,9545]
===
match
---
import_from [946,974]
import_from [946,974]
===
match
---
operator: , [18703,18704]
operator: , [18703,18704]
===
match
---
arglist [27509,27518]
arglist [27509,27518]
===
match
---
operator: , [39012,39013]
operator: , [38990,38991]
===
match
---
trailer [43862,43950]
trailer [43840,43928]
===
match
---
operator: , [29470,29471]
operator: , [29470,29471]
===
match
---
string: 'celery' [4604,4612]
string: 'celery' [4604,4612]
===
match
---
name: AIRFLOW_HOME [35773,35785]
name: AIRFLOW_HOME [35773,35785]
===
match
---
suite [8410,8436]
suite [8410,8436]
===
match
---
expr_stmt [17029,17094]
expr_stmt [17029,17094]
===
match
---
string: '#' [18657,18660]
string: '#' [18657,18660]
===
match
---
decorated [12280,12841]
decorated [12280,12841]
===
match
---
param [16827,16846]
param [16827,16846]
===
match
---
string: 'AIRFLOW_TEST_CONFIG' [33255,33276]
string: 'AIRFLOW_TEST_CONFIG' [33255,33276]
===
match
---
name: read [42572,42576]
name: read [42550,42554]
===
match
---
name: _section [22844,22852]
name: _section [22844,22852]
===
match
---
name: name [12695,12699]
name: name [12695,12699]
===
match
---
name: float [19508,19513]
name: float [19508,19513]
===
match
---
simple_stmt [20722,20778]
simple_stmt [20722,20778]
===
match
---
simple_stmt [946,975]
simple_stmt [946,975]
===
match
---
atom_expr [8848,8878]
atom_expr [8848,8878]
===
match
---
trailer [19513,19518]
trailer [19513,19518]
===
match
---
simple_stmt [8774,8811]
simple_stmt [8774,8811]
===
match
---
name: encoding [20582,20590]
name: encoding [20582,20590]
===
match
---
name: set [40746,40749]
name: set [40724,40727]
===
match
---
name: _ [14997,14998]
name: _ [14997,14998]
===
match
---
simple_stmt [27613,27655]
simple_stmt [27613,27655]
===
match
---
simple_stmt [44111,44168]
simple_stmt [44089,44146]
===
match
---
dictorsetmaker [4603,7503]
dictorsetmaker [4603,7503]
===
match
---
operator: , [7145,7146]
operator: , [7145,7146]
===
match
---
operator: } [18945,18946]
operator: } [18945,18946]
===
match
---
name: config_sources [26932,26946]
name: config_sources [26932,26946]
===
match
---
name: args [39070,39074]
name: args [39048,39052]
===
match
---
name: deprecated_key [16811,16825]
name: deprecated_key [16811,16825]
===
match
---
return_stmt [37810,37849]
return_stmt [37788,37827]
===
match
---
name: fh [42569,42571]
name: fh [42547,42549]
===
match
---
string: "Accessing configuration method 'getfloat' directly from the configuration module is " [37954,38040]
string: "Accessing configuration method 'getfloat' directly from the configuration module is " [37932,38018]
===
match
---
funcdef [38264,38664]
funcdef [38242,38642]
===
match
---
name: AIRFLOW_HOME [43350,43362]
name: AIRFLOW_HOME [43328,43340]
===
match
---
name: key [16847,16850]
name: key [16847,16850]
===
match
---
name: opt [27284,27287]
name: opt [27284,27287]
===
match
---
operator: , [14727,14728]
operator: , [14727,14728]
===
match
---
trailer [32462,32468]
trailer [32462,32468]
===
match
---
trailer [27640,27654]
trailer [27640,27654]
===
match
---
or_test [15919,15989]
or_test [15919,15989]
===
match
---
atom [7412,7452]
atom [7412,7452]
===
match
---
operator: , [12256,12257]
operator: , [12256,12257]
===
match
---
expr_stmt [34092,34135]
expr_stmt [34092,34135]
===
match
---
string: 'log_filename_template' [5889,5912]
string: 'log_filename_template' [5889,5912]
===
match
---
string: '2.0.0' [5144,5151]
string: '2.0.0' [5144,5151]
===
match
---
import_from [1452,1506]
import_from [1452,1506]
===
match
---
trailer [20108,20112]
trailer [20108,20112]
===
match
---
atom_expr [21681,21733]
atom_expr [21681,21733]
===
match
---
comparison [13742,13775]
comparison [13742,13775]
===
match
---
name: load_test_config [36632,36648]
name: load_test_config [36610,36626]
===
match
---
parameters [39958,39975]
parameters [39936,39953]
===
match
---
name: args [39929,39933]
name: args [39907,39911]
===
match
---
string: "`[scheduler] file_parsing_sort_mode` should not be " [11683,11736]
string: "`[scheduler] file_parsing_sort_mode` should not be " [11683,11736]
===
match
---
trailer [2345,2445]
trailer [2345,2445]
===
match
---
name: getimport [19757,19766]
name: getimport [19757,19766]
===
match
---
operator: = [44180,44181]
operator: = [44158,44159]
===
match
---
sync_comp_for [32960,32981]
sync_comp_for [32960,32981]
===
match
---
return_stmt [42396,42412]
return_stmt [42374,42390]
===
match
---
name: environ [33247,33254]
name: environ [33247,33254]
===
match
---
expr_stmt [14056,14083]
expr_stmt [14056,14083]
===
match
---
suite [37476,37850]
suite [37454,37828]
===
match
---
arglist [17059,17093]
arglist [17059,17093]
===
match
---
name: warnings [36708,36716]
name: warnings [36686,36694]
===
match
---
operator: = [23977,23978]
operator: = [23977,23978]
===
match
---
operator: , [12902,12903]
operator: , [12902,12903]
===
match
---
simple_stmt [3456,3491]
simple_stmt [3456,3491]
===
match
---
operator: = [43848,43849]
operator: = [43826,43827]
===
match
---
dotted_name [1426,1439]
dotted_name [1426,1439]
===
match
---
arglist [30135,30185]
arglist [30135,30185]
===
match
---
name: self [12160,12164]
name: self [12160,12164]
===
match
---
if_stmt [22541,22819]
if_stmt [22541,22819]
===
match
---
string: "Accessing configuration method 'as_dict' directly from the configuration module is " [40047,40132]
string: "Accessing configuration method 'as_dict' directly from the configuration module is " [40025,40110]
===
match
---
argument [1633,1649]
argument [1633,1649]
===
match
---
name: section [17621,17628]
name: section [17621,17628]
===
match
---
suite [37896,38262]
suite [37874,38240]
===
match
---
trailer [34680,34682]
trailer [34680,34682]
===
match
---
string: "deprecated. Please access the configuration from the 'configuration.conf' object via " [36834,36921]
string: "deprecated. Please access the configuration from the 'configuration.conf' object via " [36812,36899]
===
match
---
atom [4758,4787]
atom [4758,4787]
===
match
---
name: str [8406,8409]
name: str [8406,8409]
===
match
---
operator: , [43081,43082]
operator: , [43059,43060]
===
match
---
string: 'logging' [4835,4844]
string: 'logging' [4835,4844]
===
match
---
name: kwargs [8596,8602]
name: kwargs [8596,8602]
===
match
---
name: _parameterized_config_from_template [34213,34248]
name: _parameterized_config_from_template [34213,34248]
===
match
---
operator: , [17077,17078]
operator: , [17077,17078]
===
match
---
trailer [38646,38663]
trailer [38624,38641]
===
match
---
trailer [38639,38646]
trailer [38617,38624]
===
match
---
trailer [28958,28965]
trailer [28958,28965]
===
match
---
atom_expr [14766,14817]
atom_expr [14766,14817]
===
match
---
name: deprecated_section [17799,17817]
name: deprecated_section [17799,17817]
===
match
---
atom_expr [18254,18314]
atom_expr [18254,18314]
===
match
---
trailer [26896,26904]
trailer [26896,26904]
===
match
---
operator: , [9480,9481]
operator: , [9480,9481]
===
match
---
comparison [15521,15539]
comparison [15521,15539]
===
match
---
fstring_string: error: sqlite C library version too old (<  [10634,10677]
fstring_string: error: sqlite C library version too old (<  [10634,10677]
===
match
---
trailer [22336,22348]
trailer [22336,22348]
===
match
---
argument [1680,1696]
argument [1680,1696]
===
match
---
trailer [27234,27250]
trailer [27234,27250]
===
match
---
parameters [29041,29087]
parameters [29041,29087]
===
match
---
name: deprecated_key [14981,14995]
name: deprecated_key [14981,14995]
===
match
---
name: self [9189,9193]
name: self [9189,9193]
===
match
---
name: option [18460,18466]
name: option [18460,18466]
===
match
---
parameters [39102,39119]
parameters [39080,39097]
===
match
---
operator: , [26100,26101]
operator: , [26100,26101]
===
match
---
trailer [33637,33660]
trailer [33637,33660]
===
match
---
operator: = [1659,1660]
operator: = [1659,1660]
===
match
---
name: PY37 [44422,44426]
name: PY37 [44416,44420]
===
match
---
operator: , [7363,7364]
operator: , [7363,7364]
===
match
---
atom_expr [30988,31479]
atom_expr [30988,31479]
===
match
---
operator: = [44128,44129]
operator: = [44106,44107]
===
match
---
simple_stmt [1609,1698]
simple_stmt [1609,1698]
===
match
---
suite [34930,35885]
suite [34930,35885]
===
match
---
string: 'metrics' [6584,6593]
string: 'metrics' [6584,6593]
===
match
---
parameters [11870,11896]
parameters [11870,11896]
===
match
---
trailer [32606,32611]
trailer [32606,32611]
===
match
---
operator: ** [33010,33012]
operator: ** [33010,33012]
===
match
---
number: 2 [40721,40722]
number: 2 [40699,40700]
===
match
---
name: self [11984,11988]
name: self [11984,11988]
===
match
---
arglist [19451,19473]
arglist [19451,19473]
===
match
---
parameters [38680,38697]
parameters [38658,38675]
===
match
---
operator: , [5098,5099]
operator: , [5098,5099]
===
match
---
testlist_comp [27778,27875]
testlist_comp [27778,27875]
===
match
---
simple_stmt [14322,14350]
simple_stmt [14322,14350]
===
match
---
param [14857,14865]
param [14857,14865]
===
match
---
name: key [15651,15654]
name: key [15651,15654]
===
match
---
name: conf [36091,36095]
name: conf [36091,36095]
===
match
---
suite [16632,16750]
suite [16632,16750]
===
match
---
param [39103,39109]
param [39081,39087]
===
match
---
name: key [31335,31338]
name: key [31335,31338]
===
match
---
atom_expr [2113,2125]
atom_expr [2113,2125]
===
match
---
string: """Get Path to airflow.cfg path""" [32054,32088]
string: """Get Path to airflow.cfg path""" [32054,32088]
===
match
---
name: section [9218,9225]
name: section [9218,9225]
===
match
---
atom_expr [12994,13005]
atom_expr [12994,13005]
===
match
---
name: mp_start_method [11199,11214]
name: mp_start_method [11199,11214]
===
match
---
name: _get_environment_variables [15110,15136]
name: _get_environment_variables [15110,15136]
===
match
---
string: 'metrics' [6855,6864]
string: 'metrics' [6855,6864]
===
match
---
operator: ** [17921,17923]
operator: ** [17921,17923]
===
match
---
name: alternative_secrets_config_dict [41408,41439]
name: alternative_secrets_config_dict [41386,41417]
===
match
---
operator: = [15427,15428]
operator: = [15427,15428]
===
match
---
atom_expr [31850,31877]
atom_expr [31850,31877]
===
match
---
operator: , [42634,42635]
operator: , [42612,42613]
===
match
---
operator: { [43162,43163]
operator: { [43140,43141]
===
match
---
trailer [33824,33829]
trailer [33824,33829]
===
match
---
trailer [28007,28021]
trailer [28007,28021]
===
match
---
string: '/webserver_config.py' [36256,36278]
string: '/webserver_config.py' [36256,36278]
===
match
---
simple_stmt [35271,35319]
simple_stmt [35271,35319]
===
match
---
simple_stmt [41786,41884]
simple_stmt [41764,41862]
===
match
---
string: 'remote_logging' [4798,4814]
string: 'remote_logging' [4798,4814]
===
match
---
operator: } [7783,7784]
operator: } [7783,7784]
===
match
---
operator: , [9924,9925]
operator: , [9924,9925]
===
match
---
name: setdefault [26947,26957]
name: setdefault [26947,26957]
===
match
---
trailer [37526,37805]
trailer [37504,37783]
===
match
---
testlist_comp [5419,5450]
testlist_comp [5419,5450]
===
match
---
name: fp [23681,23683]
name: fp [23681,23683]
===
match
---
name: items [32974,32979]
name: items [32974,32979]
===
match
---
operator: ** [38282,38284]
operator: ** [38260,38262]
===
match
---
arglist [43868,43948]
arglist [43846,43926]
===
match
---
if_stmt [27326,27387]
if_stmt [27326,27387]
===
match
---
string: '2.0.0' [6836,6843]
string: '2.0.0' [6836,6843]
===
match
---
name: name [9232,9236]
name: name [9232,9236]
===
match
---
argument [9227,9236]
argument [9227,9236]
===
match
---
name: conf [34890,34894]
name: conf [34890,34894]
===
match
---
arglist [35797,35819]
arglist [35797,35819]
===
match
---
return_stmt [32193,32244]
return_stmt [32193,32244]
===
match
---
trailer [22524,22526]
trailer [22524,22526]
===
match
---
atom_expr [27617,27654]
atom_expr [27617,27654]
===
match
---
operator: { [28966,28967]
operator: { [28966,28967]
===
match
---
fstring [23537,23563]
fstring [23537,23563]
===
match
---
expr_stmt [29734,29747]
expr_stmt [29734,29747]
===
match
---
name: warnings [35837,35845]
name: warnings [35837,35845]
===
match
---
simple_stmt [18245,18315]
simple_stmt [18245,18315]
===
match
---
suite [32131,32189]
suite [32131,32189]
===
match
---
name: key [12994,12997]
name: key [12994,12997]
===
match
---
argument [34064,34077]
argument [34064,34077]
===
match
---
name: msg [35285,35288]
name: msg [35285,35288]
===
match
---
trailer [30327,30332]
trailer [30327,30332]
===
match
---
if_stmt [28813,28897]
if_stmt [28813,28897]
===
match
---
atom_expr [20353,20550]
atom_expr [20353,20550]
===
match
---
trailer [18670,18672]
trailer [18670,18672]
===
match
---
param [16811,16826]
param [16811,16826]
===
match
---
argument [30846,30861]
argument [30846,30861]
===
match
---
strings [19237,19364]
strings [19237,19364]
===
match
---
name: get [9009,9012]
name: get [9009,9012]
===
match
---
string: 'core' [5043,5049]
string: 'core' [5043,5049]
===
match
---
operator: , [15050,15051]
operator: , [15050,15051]
===
match
---
argument [38654,38662]
argument [38632,38640]
===
match
---
simple_stmt [36333,36347]
simple_stmt [36333,36347]
===
match
---
operator: ** [37872,37874]
operator: ** [37850,37852]
===
match
---
simple_stmt [10210,10225]
simple_stmt [10210,10225]
===
match
---
trailer [14719,14742]
trailer [14719,14742]
===
match
---
if_stmt [23054,23214]
if_stmt [23054,23214]
===
match
---
arglist [29623,29647]
arglist [29623,29647]
===
match
---
param [11871,11876]
param [11871,11876]
===
match
---
testlist_comp [4919,4954]
testlist_comp [4919,4954]
===
match
---
trailer [43571,43579]
trailer [43549,43557]
===
match
---
simple_stmt [15253,15354]
simple_stmt [15253,15354]
===
match
---
testlist_star_expr [27920,27935]
testlist_star_expr [27920,27935]
===
match
---
trailer [43582,43587]
trailer [43560,43565]
===
match
---
except_clause [41557,41579]
except_clause [41535,41557]
===
match
---
name: cfg [34296,34299]
name: cfg [34296,34299]
===
match
---
param [8387,8401]
param [8387,8401]
===
match
---
trailer [27044,27061]
trailer [27044,27061]
===
match
---
if_stmt [10829,11334]
if_stmt [10829,11334]
===
match
---
operator: , [17919,17920]
operator: , [17919,17920]
===
match
---
string: 'default_airflow.cfg' [42844,42865]
string: 'default_airflow.cfg' [42822,42843]
===
match
---
name: warnings [42932,42940]
name: warnings [42910,42918]
===
match
---
atom_expr [31819,31841]
atom_expr [31819,31841]
===
match
---
testlist_comp [23163,23175]
testlist_comp [23163,23175]
===
match
---
operator: , [9236,9237]
operator: , [9236,9237]
===
match
---
atom_expr [25859,25946]
atom_expr [25859,25946]
===
match
---
name: expanduser [2083,2093]
name: expanduser [2083,2093]
===
match
---
expr_stmt [44422,44455]
expr_stmt [44416,44449]
===
match
---
string: '2.0.0' [5824,5831]
string: '2.0.0' [5824,5831]
===
match
---
string: 'running config, but please update your config before Apache ' [12575,12637]
string: 'running config, but please update your config before Apache ' [12575,12637]
===
match
---
name: getboolean [33737,33747]
name: getboolean [33737,33747]
===
match
---
simple_stmt [39046,39086]
simple_stmt [39024,39064]
===
match
---
suite [20222,20277]
suite [20222,20277]
===
match
---
name: TEMPLATE_START [32523,32537]
name: TEMPLATE_START [32523,32537]
===
match
---
operator: , [9983,9984]
operator: , [9983,9984]
===
match
---
string: 'Specifying both AIRFLOW_HOME environment variable and airflow_home ' [34967,35036]
string: 'Specifying both AIRFLOW_HOME environment variable and airflow_home ' [34967,35036]
===
match
---
name: items [8922,8927]
name: items [8922,8927]
===
match
---
name: path [42375,42379]
name: path [42353,42357]
===
match
---
name: os [13765,13767]
name: os [13765,13767]
===
match
---
param [31502,31506]
param [31502,31506]
===
match
---
simple_stmt [10237,10281]
simple_stmt [10237,10281]
===
match
---
trailer [41665,41700]
trailer [41643,41678]
===
match
---
simple_stmt [34285,34301]
simple_stmt [34285,34301]
===
match
---
operator: , [26421,26422]
operator: , [26421,26422]
===
match
---
name: join [33182,33186]
name: join [33182,33186]
===
match
---
operator: , [33199,33200]
operator: , [33199,33200]
===
match
---
string: """Get path to Airflow Home""" [31908,31938]
string: """Get path to Airflow Home""" [31908,31938]
===
match
---
operator: { [18937,18938]
operator: { [18937,18938]
===
match
---
trailer [34289,34295]
trailer [34289,34295]
===
match
---
name: deprecated_section [17885,17903]
name: deprecated_section [17885,17903]
===
match
---
name: get [37407,37410]
name: get [37385,37388]
===
match
---
atom_expr [35788,35820]
atom_expr [35788,35820]
===
match
---
name: backend_list [42014,42026]
name: backend_list [41992,42004]
===
match
---
string: "sqlite" [9956,9964]
string: "sqlite" [9956,9964]
===
match
---
comparison [44429,44455]
comparison [44423,44449]
===
match
---
name: urandom [44195,44202]
name: urandom [44173,44180]
===
match
---
arith_expr [36241,36278]
arith_expr [36241,36278]
===
match
---
name: warn [40460,40464]
name: warn [40438,40442]
===
match
---
string: r'airflow.providers.sendgrid.utils.emailer.send_email' [8054,8108]
string: r'airflow.providers.sendgrid.utils.emailer.send_email' [8054,8108]
===
match
---
trailer [30129,30134]
trailer [30129,30134]
===
match
---
name: _ [27920,27921]
name: _ [27920,27921]
===
match
---
name: info [33924,33928]
name: info [33924,33928]
===
match
---
operator: = [29701,29702]
operator: = [29701,29702]
===
match
---
fstring_start: f" [23537,23539]
fstring_start: f" [23537,23539]
===
match
---
atom_expr [14202,14243]
atom_expr [14202,14243]
===
match
---
name: self [23685,23689]
name: self [23685,23689]
===
match
---
trailer [41122,41124]
trailer [41100,41102]
===
match
---
name: templates_dir [3094,3107]
name: templates_dir [3094,3107]
===
match
---
name: warnings [38749,38757]
name: warnings [38727,38735]
===
match
---
string: 'smtp_password' [4240,4255]
string: 'smtp_password' [4240,4255]
===
match
---
param [20571,20581]
param [20571,20581]
===
match
---
operator: , [9087,9088]
operator: , [9087,9088]
===
match
---
name: path [43599,43603]
name: path [43577,43581]
===
match
---
name: has_option [10837,10847]
name: has_option [10837,10847]
===
match
---
trailer [34295,34300]
trailer [34295,34300]
===
match
---
string: 'dags' [43635,43641]
string: 'dags' [43613,43619]
===
match
---
name: section [16051,16058]
name: section [16051,16058]
===
match
---
name: kwargs [18581,18587]
name: kwargs [18581,18587]
===
match
---
operator: * [39528,39529]
operator: * [39506,39507]
===
match
---
name: items [22853,22858]
name: items [22853,22858]
===
match
---
fstring [32646,32686]
fstring [32646,32686]
===
match
---
operator: , [5606,5607]
operator: , [5606,5607]
===
match
---
operator: , [6215,6216]
operator: , [6215,6216]
===
match
---
fstring_end: ' [13006,13007]
fstring_end: ' [13006,13007]
===
match
---
name: utils [1465,1470]
name: utils [1465,1470]
===
match
---
fstring_conversion [32682,32684]
fstring_conversion [32682,32684]
===
match
---
simple_stmt [36222,36279]
simple_stmt [36222,36279]
===
match
---
operator: = [34072,34073]
operator: = [34072,34073]
===
match
---
atom [6704,6747]
atom [6704,6747]
===
match
---
name: new_value [12005,12014]
name: new_value [12005,12014]
===
match
---
trailer [26946,26957]
trailer [26946,26957]
===
match
---
atom [29101,29122]
atom [29101,29122]
===
match
---
operator: } [10696,10697]
operator: } [10696,10697]
===
match
---
name: str [32300,32303]
name: str [32300,32303]
===
match
---
atom [5281,5322]
atom [5281,5322]
===
match
---
trailer [41319,41353]
trailer [41297,41331]
===
match
---
fstring_expr [16229,16238]
fstring_expr [16229,16238]
===
match
---
arith_expr [14501,14516]
arith_expr [14501,14516]
===
match
---
fstring_end: " [43022,43023]
fstring_end: " [43000,43001]
===
match
---
name: _deprecated [43108,43119]
name: _deprecated [43086,43097]
===
match
---
name: airflow_defaults [25786,25802]
name: airflow_defaults [25786,25802]
===
match
---
argument [39491,39496]
argument [39469,39474]
===
match
---
simple_stmt [41888,41906]
simple_stmt [41866,41884]
===
match
---
name: section [21518,21525]
name: section [21518,21525]
===
match
---
expr_stmt [22596,22637]
expr_stmt [22596,22637]
===
match
---
string: '' [22475,22477]
string: '' [22475,22477]
===
match
---
name: key [30477,30480]
name: key [30477,30480]
===
match
---
operator: , [32965,32966]
operator: , [32965,32966]
===
match
---
name: sensitive_config_values [26582,26605]
name: sensitive_config_values [26582,26605]
===
match
---
string: 'statsd_prefix' [6516,6531]
string: 'statsd_prefix' [6516,6531]
===
match
---
operator: , [31685,31686]
operator: , [31685,31686]
===
match
---
name: current_value [12340,12353]
name: current_value [12340,12353]
===
match
---
suite [13776,13982]
suite [13776,13982]
===
match
---
expr_stmt [22208,22268]
expr_stmt [22208,22268]
===
match
---
number: 16 [44203,44205]
number: 16 [44181,44183]
===
match
---
atom [5196,5234]
atom [5196,5234]
===
match
---
name: kwargs [15983,15989]
name: kwargs [15983,15989]
===
match
---
operator: , [10159,10160]
operator: , [10159,10160]
===
match
---
operator: , [15056,15057]
operator: , [15056,15057]
===
match
---
operator: , [23824,23825]
operator: , [23824,23825]
===
match
---
name: _TEST_PLUGINS_FOLDER [43969,43989]
name: _TEST_PLUGINS_FOLDER [43947,43967]
===
match
---
name: section [19301,19308]
name: section [19301,19308]
===
match
---
string: r':' [7754,7758]
string: r':' [7754,7758]
===
match
---
atom [26559,26573]
atom [26559,26573]
===
match
---
funcdef [13013,14002]
funcdef [13013,14002]
===
match
---
name: section_prefix [22618,22632]
name: section_prefix [22618,22632]
===
match
---
operator: ** [41666,41668]
operator: ** [41644,41646]
===
match
---
string: 'remote_log_conn_id' [4846,4866]
string: 'remote_log_conn_id' [4846,4866]
===
match
---
name: env_var [22602,22609]
name: env_var [22602,22609]
===
match
---
expr_stmt [44340,44366]
expr_stmt [44318,44344]
===
match
---
operator: , [6902,6903]
operator: , [6902,6903]
===
match
---
name: source_name [29502,29513]
name: source_name [29502,29513]
===
match
---
expr_stmt [23111,23121]
expr_stmt [23111,23121]
===
match
---
operator: , [5832,5833]
operator: , [5832,5833]
===
match
---
string: '< hidden >' [27374,27386]
string: '< hidden >' [27374,27386]
===
match
---
name: TEST_CONFIG_FILE [34159,34175]
name: TEST_CONFIG_FILE [34159,34175]
===
match
---
name: section [14404,14411]
name: section [14404,14411]
===
match
---
string: 'base_log_folder' [4692,4709]
string: 'base_log_folder' [4692,4709]
===
match
---
funcdef [23275,23871]
funcdef [23275,23871]
===
match
---
fstring_string: Current value: " [20496,20512]
fstring_string: Current value: " [20496,20512]
===
match
---
name: path [43755,43759]
name: path [43733,43737]
===
match
---
atom_expr [32633,32687]
atom_expr [32633,32687]
===
match
---
name: RuntimeError [32633,32645]
name: RuntimeError [32633,32645]
===
match
---
param [29058,29066]
param [29058,29066]
===
match
---
atom_expr [23541,23560]
atom_expr [23541,23560]
===
match
---
trailer [15459,15509]
trailer [15459,15509]
===
match
---
raise_stmt [19558,19747]
raise_stmt [19558,19747]
===
match
---
argument [34597,34609]
argument [34597,34609]
===
match
---
name: module_loading [1471,1485]
name: module_loading [1471,1485]
===
match
---
name: replacement [8833,8844]
name: replacement [8833,8844]
===
match
---
operator: , [21148,21149]
operator: , [21148,21149]
===
match
---
name: secrets_backend_cls [41362,41381]
name: secrets_backend_cls [41340,41359]
===
match
---
operator: ** [8488,8490]
operator: ** [8488,8490]
===
match
---
name: opt [27497,27500]
name: opt [27497,27500]
===
match
---
name: get_airflow_home [31884,31900]
name: get_airflow_home [31884,31900]
===
match
---
name: env_var [2004,2011]
name: env_var [2004,2011]
===
match
---
atom [5932,5978]
atom [5932,5978]
===
match
---
suite [23512,23564]
suite [23512,23564]
===
match
---
operator: } [26998,26999]
operator: } [26998,26999]
===
match
---
atom_expr [27829,27875]
atom_expr [27829,27875]
===
match
---
trailer [37406,37410]
trailer [37384,37388]
===
match
---
import_from [1421,1451]
import_from [1421,1451]
===
match
---
trailer [17410,17421]
trailer [17410,17421]
===
match
---
arglist [28935,28957]
arglist [28935,28957]
===
match
---
suite [38712,39086]
suite [38690,39064]
===
match
---
expr_stmt [14261,14305]
expr_stmt [14261,14305]
===
match
---
trailer [42940,42945]
trailer [42918,42923]
===
match
---
name: decode [44208,44214]
name: decode [44186,44192]
===
match
---
operator: , [11875,11876]
operator: , [11875,11876]
===
match
---
name: new_value [12762,12771]
name: new_value [12762,12771]
===
match
---
string: """Historical load_test_config""" [36670,36703]
string: """Historical load_test_config""" [36648,36681]
===
match
---
string: '2.0.0' [6565,6572]
string: '2.0.0' [6565,6572]
===
match
---
operator: = [9421,9422]
operator: = [9421,9422]
===
match
---
operator: = [29534,29535]
operator: = [29534,29535]
===
match
---
trailer [12670,12677]
trailer [12670,12677]
===
match
---
operator: , [39890,39891]
operator: , [39868,39869]
===
match
---
simple_stmt [42173,42216]
simple_stmt [42151,42194]
===
match
---
name: section [19086,19093]
name: section [19086,19093]
===
match
---
operator: , [39840,39841]
operator: , [39818,39819]
===
match
---
trailer [29582,29584]
trailer [29582,29584]
===
match
---
string: 'core' [4056,4062]
string: 'core' [4056,4062]
===
match
---
atom [4680,4710]
atom [4680,4710]
===
match
---
name: self [15585,15589]
name: self [15585,15589]
===
match
---
name: section [29151,29158]
name: section [29151,29158]
===
match
---
operator: , [3148,3149]
operator: , [3148,3149]
===
match
---
operator: = [26623,26624]
operator: = [26623,26624]
===
match
---
param [2828,2838]
param [2828,2838]
===
match
---
operator: = [22986,22987]
operator: = [22986,22987]
===
match
---
name: Union [21796,21801]
name: Union [21796,21801]
===
match
---
atom_expr [20722,20777]
atom_expr [20722,20777]
===
match
---
operator: = [13709,13710]
operator: = [13709,13710]
===
match
---
name: getboolean [36041,36051]
name: getboolean [36041,36051]
===
match
---
name: AIRFLOW_HOME [43765,43777]
name: AIRFLOW_HOME [43743,43755]
===
match
---
atom [5542,5586]
atom [5542,5586]
===
match
---
and_test [10016,10064]
and_test [10016,10064]
===
match
---
atom_expr [39909,39944]
atom_expr [39887,39922]
===
match
---
operator: , [4719,4720]
operator: , [4719,4720]
===
match
---
trailer [12988,12990]
trailer [12988,12990]
===
match
---
simple_stmt [14693,14743]
simple_stmt [14693,14743]
===
match
---
atom_expr [22602,22637]
atom_expr [22602,22637]
===
match
---
operator: { [19669,19670]
operator: { [19669,19670]
===
match
---
name: section [12331,12338]
name: section [12331,12338]
===
match
---
testlist_comp [5933,5977]
testlist_comp [5933,5977]
===
match
---
operator: , [23076,23077]
operator: , [23076,23077]
===
match
---
operator: , [19463,19464]
operator: , [19463,19464]
===
match
---
name: section [15178,15185]
name: section [15178,15185]
===
match
---
trailer [34390,34395]
trailer [34390,34395]
===
match
---
name: airflow_defaults [8555,8571]
name: airflow_defaults [8555,8571]
===
match
---
param [18030,18034]
param [18030,18034]
===
match
---
name: format [33003,33009]
name: format [33003,33009]
===
match
---
atom_expr [13949,13980]
atom_expr [13949,13980]
===
match
---
name: ENV_VAR_PREFIX [12959,12973]
name: ENV_VAR_PREFIX [12959,12973]
===
match
---
name: path [42474,42478]
name: path [42452,42456]
===
match
---
simple_stmt [34432,34471]
simple_stmt [34432,34471]
===
match
---
argument [39076,39084]
argument [39054,39062]
===
match
---
operator: , [29056,29057]
operator: , [29056,29057]
===
match
---
testlist_comp [5282,5321]
testlist_comp [5282,5321]
===
match
---
name: self [25781,25785]
name: self [25781,25785]
===
match
---
operator: , [27930,27931]
operator: , [27930,27931]
===
match
---
arglist [41479,41533]
arglist [41457,41511]
===
match
---
trailer [2077,2082]
trailer [2077,2082]
===
match
---
name: has_option [21507,21517]
name: has_option [21507,21517]
===
match
---
comparison [18330,18348]
comparison [18330,18348]
===
match
---
atom_expr [32458,32468]
atom_expr [32458,32468]
===
match
---
trailer [32613,32619]
trailer [32613,32619]
===
match
---
name: import_string [1493,1506]
name: import_string [1493,1506]
===
match
---
trailer [10512,10527]
trailer [10512,10527]
===
match
---
name: airflow_defaults [21604,21620]
name: airflow_defaults [21604,21620]
===
match
---
name: deprecated_key [15296,15310]
name: deprecated_key [15296,15310]
===
match
---
name: str [14935,14938]
name: str [14935,14938]
===
match
---
param [19038,19046]
param [19038,19046]
===
match
---
if_stmt [29662,29722]
if_stmt [29662,29722]
===
match
---
name: conf [35788,35792]
name: conf [35788,35792]
===
match
---
operator: , [37005,37006]
operator: , [36983,36984]
===
match
---
name: warn [35846,35850]
name: warn [35846,35850]
===
match
---
operator: , [27717,27718]
operator: , [27717,27718]
===
match
---
operator: -> [41191,41193]
operator: -> [41169,41171]
===
match
---
name: val [19436,19439]
name: val [19436,19439]
===
match
---
name: path [30181,30185]
name: path [30181,30185]
===
match
---
operator: , [31556,31557]
operator: , [31556,31557]
===
match
---
operator: , [37361,37362]
operator: , [37339,37340]
===
match
---
name: validate [36538,36546]
name: validate [44403,44411]
===
match
---
arglist [35851,35883]
arglist [35851,35883]
===
match
---
suite [19062,19379]
suite [19062,19379]
===
match
---
name: new_value [9461,9470]
name: new_value [9461,9470]
===
match
---
operator: = [15103,15104]
operator: = [15103,15104]
===
match
---
string: 'default' [1733,1742]
string: 'default' [1733,1742]
===
match
---
operator: , [4612,4613]
operator: , [4612,4613]
===
match
---
fstring_expr [18922,18927]
fstring_expr [18922,18927]
===
match
---
string: 'logging' [5665,5674]
string: 'logging' [5665,5674]
===
match
---
name: list_mode [11762,11771]
name: list_mode [11762,11771]
===
match
---
name: key [23235,23238]
name: key [23235,23238]
===
match
---
name: path [32150,32154]
name: path [32150,32154]
===
match
---
atom_expr [20606,20658]
atom_expr [20606,20658]
===
match
---
name: _default_config_file_path [32413,32438]
name: _default_config_file_path [32413,32438]
===
match
---
name: yaml [1447,1451]
name: yaml [1447,1451]
===
match
---
atom [7084,7123]
atom [7084,7123]
===
match
---
operator: -> [24073,24075]
operator: -> [24073,24075]
===
match
---
atom_expr [3003,3040]
atom_expr [3003,3040]
===
match
---
name: conf [36561,36565]
name: conf [36539,36543]
===
match
---
name: val [19726,19729]
name: val [19726,19729]
===
match
---
testlist_comp [7049,7081]
testlist_comp [7049,7081]
===
match
---
name: deprecated_section [30482,30500]
name: deprecated_section [30482,30500]
===
match
---
operator: , [21794,21795]
operator: , [21794,21795]
===
match
---
name: log [30126,30129]
name: log [30126,30129]
===
match
---
trailer [24080,24101]
trailer [24080,24101]
===
match
---
name: join [3189,3193]
name: join [3189,3193]
===
match
---
operator: , [4077,4078]
operator: , [4077,4078]
===
match
---
name: shutil [36440,36446]
name: shutil [36440,36446]
===
match
---
string: 'airflow' [1787,1796]
string: 'airflow' [1787,1796]
===
match
---
name: AIRFLOW_CONFIG [34536,34550]
name: AIRFLOW_CONFIG [34536,34550]
===
match
---
operator: , [19098,19099]
operator: , [19098,19099]
===
match
---
operator: == [35369,35371]
operator: == [35369,35371]
===
match
---
trailer [42212,42214]
trailer [42190,42192]
===
match
---
atom_expr [42481,42526]
atom_expr [42459,42504]
===
match
---
name: option [16406,16412]
name: option [16406,16412]
===
match
---
string: """         Reads options, imports the full qualified name, and returns the object.          In case of failure, it throws an exception a clear message with the key aad the section names          :return: The object or None, if the option is empty         """ [19814,20073]
string: """         Reads options, imports the full qualified name, and returns the object.          In case of failure, it throws an exception a clear message with the key aad the section names          :return: The object or None, if the option is empty         """ [19814,20073]
===
match
---
atom_expr [30072,30117]
atom_expr [30072,30117]
===
match
---
trailer [9209,9258]
trailer [9209,9258]
===
match
---
trailer [14340,14349]
trailer [14340,14349]
===
match
---
name: __file__ [43613,43621]
name: __file__ [43591,43599]
===
match
---
trailer [27987,28007]
trailer [27987,28007]
===
match
---
name: _DEFAULT_CONFIG [42619,42634]
name: _DEFAULT_CONFIG [42597,42612]
===
match
---
simple_stmt [43101,43128]
simple_stmt [43079,43106]
===
match
---
argument [8587,8592]
argument [8587,8592]
===
match
---
name: fernet [33886,33892]
name: fernet [33886,33892]
===
match
---
simple_stmt [1508,1542]
simple_stmt [1508,1542]
===
match
---
fstring_start: f' [20494,20496]
fstring_start: f' [20494,20496]
===
match
---
fstring_expr [32677,32685]
fstring_expr [32677,32685]
===
match
---
atom [41903,41905]
atom [41881,41883]
===
match
---
operator: , [6469,6470]
operator: , [6469,6470]
===
match
---
atom_expr [8655,8704]
atom_expr [8655,8704]
===
match
---
parameters [32286,32296]
parameters [32286,32296]
===
match
---
name: dirname [3131,3138]
name: dirname [3131,3138]
===
match
---
name: error [20326,20331]
name: error [20326,20331]
===
match
---
operator: , [30179,30180]
operator: , [30179,30180]
===
match
---
name: WEBSERVER_CONFIG [36414,36430]
name: WEBSERVER_CONFIG [36414,36430]
===
match
---
parameters [8453,8497]
parameters [8453,8497]
===
match
---
simple_stmt [29789,29886]
simple_stmt [29789,29886]
===
match
---
operator: @ [29372,29373]
operator: @ [29372,29373]
===
match
---
name: join [43858,43862]
name: join [43836,43840]
===
match
---
trailer [18370,18386]
trailer [18370,18386]
===
match
---
name: self [18556,18560]
name: self [18556,18560]
===
match
---
name: ENV_VAR_PREFIX [12846,12860]
name: ENV_VAR_PREFIX [12846,12860]
===
match
---
operator: , [16592,16593]
operator: , [16592,16593]
===
match
---
name: Fernet [33900,33906]
name: Fernet [33900,33906]
===
match
---
operator: = [24031,24032]
operator: = [24031,24032]
===
match
---
trailer [3130,3138]
trailer [3130,3138]
===
match
---
simple_stmt [44289,44339]
simple_stmt [44267,44317]
===
match
---
string: 'statsd_custom_client_path' [6957,6984]
string: 'statsd_custom_client_path' [6957,6984]
===
match
---
operator: , [7096,7097]
operator: , [7096,7097]
===
match
---
operator: * [8481,8482]
operator: * [8481,8482]
===
match
---
string: 'backend_kwargs' [41502,41518]
string: 'backend_kwargs' [41480,41496]
===
match
---
operator: , [4748,4749]
operator: , [4748,4749]
===
match
---
param [37445,37451]
param [37423,37429]
===
match
---
name: read_dict [20730,20739]
name: read_dict [20730,20739]
===
match
---
suite [19123,19152]
suite [19123,19152]
===
match
---
testlist_comp [15043,15055]
testlist_comp [15043,15055]
===
match
---
param [17348,17355]
param [17348,17355]
===
match
---
argument [9210,9225]
argument [9210,9225]
===
match
---
funcdef [39088,39508]
funcdef [39066,39486]
===
match
---
testlist_comp [5503,5539]
testlist_comp [5503,5539]
===
match
---
operator: = [30070,30071]
operator: = [30070,30071]
===
match
---
operator: , [5726,5727]
operator: , [5726,5727]
===
match
---
dictorsetmaker [7821,7896]
dictorsetmaker [7821,7896]
===
match
---
simple_stmt [18453,18467]
simple_stmt [18453,18467]
===
match
---
name: kwargs [39078,39084]
name: kwargs [39056,39062]
===
match
---
argument [8524,8529]
argument [8524,8529]
===
match
---
arglist [28134,28174]
arglist [28134,28174]
===
match
---
operator: { [2655,2656]
operator: { [2655,2656]
===
match
---
trailer [21504,21506]
trailer [21504,21506]
===
match
---
name: deprecated_section [30542,30560]
name: deprecated_section [30542,30560]
===
match
---
name: path [32678,32682]
name: path [32678,32682]
===
match
---
import_name [10210,10224]
import_name [10210,10224]
===
match
---
name: section [19451,19458]
name: section [19451,19458]
===
match
---
name: current_value [9408,9421]
name: current_value [9408,9421]
===
match
---
trailer [42405,42410]
trailer [42383,42388]
===
match
---
trailer [42571,42576]
trailer [42549,42554]
===
match
---
name: AirflowConfigParser [33673,33692]
name: AirflowConfigParser [33673,33692]
===
match
---
operator: , [26226,26227]
operator: , [26226,26227]
===
match
---
simple_stmt [17764,17835]
simple_stmt [17764,17835]
===
match
---
suite [22940,23214]
suite [22940,23214]
===
match
---
arglist [16115,16170]
arglist [16115,16170]
===
match
---
comparison [15198,15216]
comparison [15198,15216]
===
match
---
trailer [33009,33021]
trailer [33009,33021]
===
match
---
atom [28966,28976]
atom [28966,28976]
===
match
---
operator: , [4208,4209]
operator: , [4208,4209]
===
match
---
operator: , [25779,25780]
operator: , [25779,25780]
===
match
---
name: config_sources [26443,26457]
name: config_sources [26443,26457]
===
match
---
operator: , [26386,26387]
operator: , [26386,26387]
===
match
---
atom_expr [32200,32244]
atom_expr [32200,32244]
===
match
---
trailer [36716,36721]
trailer [36694,36699]
===
match
---
atom_expr [16649,16719]
atom_expr [16649,16719]
===
match
---
string: 'tests' [43930,43937]
string: 'tests' [43908,43915]
===
match
---
operator: , [42867,42868]
operator: , [42845,42846]
===
match
---
operator: = [12736,12737]
operator: = [12736,12737]
===
match
---
trailer [29969,29978]
trailer [29969,29978]
===
match
---
suite [16861,17255]
suite [16861,17255]
===
match
---
name: _get_env_var_option [18111,18130]
name: _get_env_var_option [18111,18130]
===
match
---
trailer [34049,34078]
trailer [34049,34078]
===
match
---
atom_expr [29965,29980]
atom_expr [29965,29980]
===
match
---
name: has_option [15941,15951]
name: has_option [15941,15951]
===
match
---
name: templates_dir [3194,3207]
name: templates_dir [3194,3207]
===
match
---
trailer [42506,42526]
trailer [42484,42504]
===
match
---
operator: } [20445,20446]
operator: } [20445,20446]
===
match
---
param [37452,37460]
param [37430,37438]
===
match
---
trailer [13254,13275]
trailer [13254,13275]
===
match
---
string: 'statsd_host' [6366,6379]
string: 'statsd_host' [6366,6379]
===
match
---
param [11877,11881]
param [11877,11881]
===
match
---
atom [26825,26840]
atom [26825,26840]
===
match
---
atom_expr [26932,27000]
atom_expr [26932,27000]
===
match
---
sync_comp_for [2518,2553]
sync_comp_for [2518,2553]
===
match
---
name: super [20722,20727]
name: super [20722,20727]
===
match
---
dictorsetmaker [7699,8158]
dictorsetmaker [7699,8158]
===
match
---
name: get [9973,9976]
name: get [9973,9976]
===
match
---
name: split [18651,18656]
name: split [18651,18656]
===
match
---
strings [34967,35195]
strings [34967,35195]
===
match
---
operator: , [36508,36509]
operator: , [36508,36509]
===
match
---
argument [8594,8602]
argument [8594,8602]
===
match
---
string: 'colored_formatter_class' [5551,5576]
string: 'colored_formatter_class' [5551,5576]
===
match
---
name: section [23817,23824]
name: section [23817,23824]
===
match
---
name: open [32458,32462]
name: open [32458,32462]
===
match
---
arglist [17785,17833]
arglist [17785,17833]
===
match
---
suite [19488,19519]
suite [19488,19519]
===
match
---
name: k [32964,32965]
name: k [32964,32965]
===
match
---
name: opt [27224,27227]
name: opt [27224,27227]
===
match
---
name: _default_config_file_path [3391,3416]
name: _default_config_file_path [3391,3416]
===
match
---
simple_stmt [28122,28176]
simple_stmt [28122,28176]
===
match
---
argument [17635,17643]
argument [17635,17643]
===
match
---
arglist [18565,18587]
arglist [18565,18587]
===
match
---
name: deprecated_values [7669,7686]
name: deprecated_values [7669,7686]
===
match
---
operator: } [16237,16238]
operator: } [16237,16238]
===
match
---
fstring [19707,19733]
fstring [19707,19733]
===
match
---
trailer [44083,44108]
trailer [44061,44086]
===
match
---
simple_stmt [18641,18673]
simple_stmt [18641,18673]
===
match
---
operator: , [28393,28394]
operator: , [28393,28394]
===
match
---
operator: ** [37418,37420]
operator: ** [37396,37398]
===
match
---
name: initialize_config [44347,44364]
name: initialize_config [44325,44342]
===
match
---
trailer [12677,12802]
trailer [12677,12802]
===
match
---
name: read [20614,20618]
name: read [20614,20618]
===
match
---
trailer [16213,16267]
trailer [16213,16267]
===
match
---
operator: , [21758,21759]
operator: , [21758,21759]
===
match
---
funcdef [16775,17255]
funcdef [16775,17255]
===
match
---
trailer [30401,30406]
trailer [30401,30406]
===
match
---
name: env_var [1819,1826]
name: env_var [1819,1826]
===
match
---
operator: , [19050,19051]
operator: , [19050,19051]
===
match
---
string: 'task_log_prefix_template' [5796,5822]
string: 'task_log_prefix_template' [5796,5822]
===
match
---
param [12366,12373]
param [12366,12373]
===
match
---
operator: , [26504,26505]
operator: , [26504,26505]
===
match
---
name: has_option [17700,17710]
name: has_option [17700,17710]
===
match
---
simple_stmt [16484,16498]
simple_stmt [16484,16498]
===
match
---
trailer [43916,43926]
trailer [43894,43904]
===
match
---
operator: , [12771,12772]
operator: , [12771,12772]
===
match
---
argument [18579,18587]
argument [18579,18587]
===
match
---
operator: , [10854,10855]
operator: , [10854,10855]
===
match
---
name: display_source [29665,29679]
name: display_source [29665,29679]
===
match
---
atom_expr [42698,42764]
atom_expr [42676,42742]
===
match
---
atom [18691,18709]
atom [18691,18709]
===
match
---
funcdef [32690,33030]
funcdef [32690,33030]
===
match
---
operator: = [41486,41487]
operator: = [41464,41465]
===
match
---
parameters [27677,27739]
parameters [27677,27739]
===
match
---
simple_stmt [44049,44109]
simple_stmt [44027,44087]
===
match
---
name: Optional [41194,41202]
name: Optional [41172,41180]
===
match
---
simple_stmt [39468,39508]
simple_stmt [39446,39486]
===
match
---
simple_stmt [43350,43384]
simple_stmt [43328,43362]
===
match
---
operator: = [23240,23241]
operator: = [23240,23241]
===
match
---
arglist [28390,28399]
arglist [28390,28399]
===
match
---
param [21754,21759]
param [21754,21759]
===
match
---
expr_stmt [28448,28470]
expr_stmt [28448,28470]
===
match
---
operator: , [15335,15336]
operator: , [15335,15336]
===
match
---
name: _include_envs [27664,27677]
name: _include_envs [27664,27677]
===
match
---
operator: = [44235,44236]
operator: = [44213,44214]
===
match
---
arglist [34906,34928]
arglist [34906,34928]
===
match
---
name: load_test_config [36096,36112]
name: load_test_config [36096,36112]
===
match
---
operator: , [37838,37839]
operator: , [37816,37817]
===
match
---
atom_expr [17038,17094]
atom_expr [17038,17094]
===
match
---
arglist [12217,12230]
arglist [12217,12230]
===
match
---
trailer [39479,39490]
trailer [39457,39468]
===
match
---
suite [33421,36566]
suite [33421,36544]
===
match
---
operator: , [31617,31618]
operator: , [31617,31618]
===
match
---
name: _get_cmd_option [14011,14026]
name: _get_cmd_option [14011,14026]
===
match
---
arglist [22466,22477]
arglist [22466,22477]
===
match
---
trailer [2116,2125]
trailer [2116,2125]
===
match
---
name: option [21070,21076]
name: option [21070,21076]
===
match
---
trailer [13959,13980]
trailer [13959,13980]
===
match
---
trailer [17872,17931]
trailer [17872,17931]
===
match
---
expr_stmt [19071,19109]
expr_stmt [19071,19109]
===
match
---
argument [41320,41337]
argument [41298,41315]
===
match
---
name: optionstr [8387,8396]
name: optionstr [8387,8396]
===
match
---
decorator [30430,30444]
decorator [30430,30444]
===
match
---
trailer [42337,42360]
trailer [42315,42338]
===
match
---
name: is_executor_without_sqlite_support [10030,10064]
name: is_executor_without_sqlite_support [10030,10064]
===
match
---
name: get [37047,37050]
name: get [37025,37028]
===
match
---
and_test [28216,28297]
and_test [28216,28297]
===
match
---
name: raw [28351,28354]
name: raw [28351,28354]
===
match
---
name: warn [39180,39184]
name: warn [39158,39162]
===
match
---
name: AIRFLOW_HOME [34577,34589]
name: AIRFLOW_HOME [34577,34589]
===
match
---
operator: , [5756,5757]
operator: , [5756,5757]
===
match
---
simple_stmt [11633,11845]
simple_stmt [11633,11845]
===
match
---
operator: , [5822,5823]
operator: , [5822,5823]
===
match
---
argument [12723,12750]
argument [12723,12750]
===
match
---
name: log [34484,34487]
name: log [34484,34487]
===
match
---
atom_expr [13240,13275]
atom_expr [13240,13275]
===
match
---
atom_expr [36533,36548]
atom_expr [44398,44413]
===
match
---
atom [5118,5152]
atom [5118,5152]
===
match
---
factor [22710,22712]
factor [22710,22712]
===
match
---
atom_expr [37402,37427]
atom_expr [37380,37405]
===
match
---
operator: , [44096,44097]
operator: , [44074,44075]
===
match
---
name: stacklevel [38200,38210]
name: stacklevel [38178,38188]
===
match
---
funcdef [37430,37850]
funcdef [37408,37828]
===
match
---
param [27700,27718]
param [27700,27718]
===
match
---
atom_expr [23661,23741]
atom_expr [23661,23741]
===
match
---
name: config [29448,29454]
name: config [29448,29454]
===
match
---
name: key [17431,17434]
name: key [17431,17434]
===
match
---
fstring_string:   [23561,23562]
fstring_string:   [23561,23562]
===
match
---
atom_expr [13411,13421]
atom_expr [13411,13421]
===
match
---
testlist_comp [29704,29720]
testlist_comp [29704,29720]
===
match
---
expr_stmt [34207,34268]
expr_stmt [34207,34268]
===
match
---
trailer [11293,11315]
trailer [11293,11315]
===
match
---
simple_stmt [20606,20659]
simple_stmt [20606,20659]
===
match
---
atom_expr [41305,41353]
atom_expr [41283,41331]
===
match
---
operator: != [28824,28826]
operator: != [28824,28826]
===
match
---
atom_expr [30126,30186]
atom_expr [30126,30186]
===
match
---
name: section [19403,19410]
name: section [19403,19410]
===
match
---
param [27089,27094]
param [27089,27094]
===
match
---
name: self [8758,8762]
name: self [8758,8762]
===
match
---
name: section [29954,29961]
name: section [29954,29961]
===
match
---
name: class_name [42153,42163]
name: class_name [42131,42141]
===
match
---
name: __init__ [8445,8453]
name: __init__ [8445,8453]
===
match
---
atom_expr [10531,10564]
atom_expr [10531,10564]
===
match
---
operator: } [42977,42978]
operator: } [42955,42956]
===
match
---
name: maxsize [42264,42271]
name: maxsize [42242,42249]
===
match
---
param [19047,19051]
param [19047,19051]
===
match
---
trailer [17154,17204]
trailer [17154,17204]
===
match
---
if_stmt [26319,26428]
if_stmt [26319,26428]
===
match
---
argument [31360,31379]
argument [31360,31379]
===
match
---
name: decode [34127,34133]
name: decode [34127,34133]
===
match
---
if_stmt [1997,2036]
if_stmt [1997,2036]
===
match
---
name: warn [35280,35284]
name: warn [35280,35284]
===
match
---
trailer [3028,3040]
trailer [3028,3040]
===
match
---
operator: , [5125,5126]
operator: , [5125,5126]
===
match
---
operator: , [15176,15177]
operator: , [15176,15177]
===
match
---
dotted_name [10299,10317]
dotted_name [10299,10317]
===
match
---
operator: , [5922,5923]
operator: , [5922,5923]
===
match
---
parameters [20797,20820]
parameters [20797,20820]
===
match
---
string: '_cmd' [27647,27653]
string: '_cmd' [27647,27653]
===
match
---
simple_stmt [31908,31939]
simple_stmt [31908,31939]
===
match
---
expr_stmt [18546,18605]
expr_stmt [18546,18605]
===
match
---
trailer [29261,29366]
trailer [29261,29366]
===
match
---
name: section [16927,16934]
name: section [16927,16934]
===
match
---
arglist [20113,20147]
arglist [20113,20147]
===
match
---
name: _include_secrets [26467,26483]
name: _include_secrets [26467,26483]
===
match
---
operator: = [40301,40302]
operator: = [40279,40280]
===
match
---
string: '2.0.0' [7030,7037]
string: '2.0.0' [7030,7037]
===
match
---
name: command [14261,14268]
name: command [14261,14268]
===
match
---
trailer [14278,14282]
trailer [14278,14282]
===
match
---
not_test [26702,26723]
not_test [26702,26723]
===
match
---
argument [41520,41533]
argument [41498,41511]
===
match
---
name: upper [12998,13003]
name: upper [12998,13003]
===
match
---
operator: , [21219,21220]
operator: , [21219,21220]
===
match
---
operator: , [29454,29455]
operator: , [29454,29455]
===
match
---
operator: , [7863,7864]
operator: , [7863,7864]
===
match
---
name: version [12366,12373]
name: version [12366,12373]
===
match
---
name: section [21717,21724]
name: section [21717,21724]
===
match
---
comparison [32515,32537]
comparison [32515,32537]
===
match
---
name: subprocess [2408,2418]
name: subprocess [2408,2418]
===
match
---
atom_expr [10729,10799]
atom_expr [10729,10799]
===
match
---
trailer [37521,37526]
trailer [37499,37504]
===
match
---
name: env_var [13198,13205]
name: env_var [13198,13205]
===
match
---
name: expand_env_var [1804,1818]
name: expand_env_var [1804,1818]
===
match
---
simple_stmt [815,830]
simple_stmt [815,830]
===
match
---
operator: , [37056,37057]
operator: , [37034,37035]
===
match
---
simple_stmt [26619,26663]
simple_stmt [26619,26663]
===
match
---
testlist_comp [5597,5620]
testlist_comp [5597,5620]
===
match
---
atom_expr [28944,28957]
atom_expr [28944,28957]
===
match
---
operator: ** [38688,38690]
operator: ** [38666,38668]
===
match
---
testlist_comp [7413,7451]
testlist_comp [7413,7451]
===
match
---
operator: = [42479,42480]
operator: = [42457,42458]
===
match
---
testlist_comp [5624,5653]
testlist_comp [5624,5653]
===
match
---
operator: , [14869,14870]
operator: , [14869,14870]
===
match
---
name: command [2656,2663]
name: command [2656,2663]
===
match
---
dotted_name [1457,1485]
dotted_name [1457,1485]
===
match
---
atom [7807,7906]
atom [7807,7906]
===
match
---
name: self [31850,31854]
name: self [31850,31854]
===
match
---
operator: { [16239,16240]
operator: { [16239,16240]
===
match
---
trailer [22042,22054]
trailer [22042,22054]
===
match
---
trailer [34133,34135]
trailer [34133,34135]
===
match
---
operator: } [11771,11772]
operator: } [11771,11772]
===
match
---
name: has_section [22094,22105]
name: has_section [22094,22105]
===
match
---
name: os [31965,31967]
name: os [31965,31967]
===
match
---
name: kwargs [39937,39943]
name: kwargs [39915,39921]
===
match
---
string: 'remote_logging' [4770,4786]
string: 'remote_logging' [4770,4786]
===
match
---
argument [38604,38616]
argument [38582,38594]
===
match
---
name: re [7838,7840]
name: re [7838,7840]
===
match
---
simple_stmt [36356,36432]
simple_stmt [36356,36432]
===
match
---
expr_stmt [10888,10941]
expr_stmt [10888,10941]
===
match
---
trailer [29998,30013]
trailer [29998,30013]
===
match
---
testlist_comp [4056,4076]
testlist_comp [4056,4076]
===
match
---
trailer [22669,22677]
trailer [22669,22677]
===
match
---
arglist [28008,28020]
arglist [28008,28020]
===
match
---
name: option [16541,16547]
name: option [16541,16547]
===
match
---
simple_stmt [1109,1202]
simple_stmt [1109,1202]
===
match
---
atom_expr [33147,33157]
atom_expr [33147,33157]
===
match
---
atom_expr [28122,28175]
atom_expr [28122,28175]
===
match
---
arglist [37536,37799]
arglist [37514,37777]
===
match
---
name: _section [22764,22772]
name: _section [22764,22772]
===
match
---
trailer [22451,22465]
trailer [22451,22465]
===
match
---
name: isfile [34396,34402]
name: isfile [34396,34402]
===
match
---
import_name [815,829]
import_name [815,829]
===
match
---
expr_stmt [29697,29721]
expr_stmt [29697,29721]
===
match
---
number: 0 [23619,23620]
number: 0 [23619,23620]
===
match
---
name: key [16167,16170]
name: key [16167,16170]
===
match
---
param [19787,19795]
param [19787,19795]
===
match
---
fstring_start: f" [10722,10724]
fstring_start: f" [10722,10724]
===
match
---
simple_stmt [41283,41354]
simple_stmt [41261,41332]
===
match
---
testlist_comp [18692,18708]
testlist_comp [18692,18708]
===
match
---
trailer [34894,34905]
trailer [34894,34905]
===
match
---
name: airflow_home [33060,33072]
name: airflow_home [33060,33072]
===
match
---
name: initialize_secrets_backends [41723,41750]
name: initialize_secrets_backends [41701,41728]
===
match
---
testlist_comp [6310,6343]
testlist_comp [6310,6343]
===
match
---
string: 'DEFAULT_CONFIG_FILE_PATH' [42770,42796]
string: 'DEFAULT_CONFIG_FILE_PATH' [42748,42774]
===
match
---
operator: = [12861,12862]
operator: = [12861,12862]
===
match
---
name: str [21791,21794]
name: str [21791,21794]
===
match
---
operator: = [9247,9248]
operator: = [9247,9248]
===
match
---
string: "_CMD" [22670,22676]
string: "_CMD" [22670,22676]
===
match
---
name: initialize_config [33401,33418]
name: initialize_config [33401,33418]
===
match
---
operator: , [20580,20581]
operator: , [20580,20581]
===
match
---
for_stmt [22828,23246]
for_stmt [22828,23246]
===
match
---
operator: , [11446,11447]
operator: , [11446,11447]
===
match
---
operator: = [1752,1753]
operator: = [1752,1753]
===
match
---
param [40369,40377]
param [40347,40355]
===
match
---
fstring_string: Failed to convert value to int. Please check " [19239,19285]
fstring_string: Failed to convert value to int. Please check " [19239,19285]
===
match
---
simple_stmt [11414,11474]
simple_stmt [11414,11474]
===
match
---
with_stmt [3381,3491]
with_stmt [3381,3491]
===
match
---
operator: { [2727,2728]
operator: { [2727,2728]
===
match
---
argument [2401,2423]
argument [2401,2423]
===
match
---
name: Fernet [33345,33351]
name: Fernet [33345,33351]
===
match
---
name: name [42973,42977]
name: name [42951,42955]
===
match
---
number: 2 [37382,37383]
number: 2 [37360,37361]
===
match
---
trailer [39612,39897]
trailer [39590,39875]
===
match
---
name: generate_key [34659,34671]
name: generate_key [34659,34671]
===
match
---
name: kwargs [38690,38696]
name: kwargs [38668,38674]
===
match
---
name: warnings [38339,38347]
name: warnings [38317,38325]
===
match
---
operator: = [41342,41343]
operator: = [41320,41321]
===
match
---
name: _get_cmd_option [27235,27250]
name: _get_cmd_option [27235,27250]
===
match
---
try_stmt [27899,28078]
try_stmt [27899,28078]
===
match
---
name: warnings [35402,35410]
name: warnings [35402,35410]
===
match
---
fstring_string: ] not found in config [16244,16265]
fstring_string: ] not found in config [16244,16265]
===
match
---
name: communicate [2540,2551]
name: communicate [2540,2551]
===
match
---
name: warnings [37112,37120]
name: warnings [37090,37098]
===
match
---
atom_expr [43564,43624]
atom_expr [43542,43602]
===
match
---
atom [6945,6985]
atom [6945,6985]
===
match
---
string: '_CMD' [13378,13384]
string: '_CMD' [13378,13384]
===
match
---
name: kwargs [40344,40350]
name: kwargs [40322,40328]
===
match
---
fstring_start: f' [19604,19606]
fstring_start: f' [19604,19606]
===
match
---
param [27095,27110]
param [27095,27110]
===
match
---
number: 0 [18662,18663]
number: 0 [18662,18663]
===
match
---
funcdef [37852,38262]
funcdef [37830,38240]
===
match
---
operator: , [38250,38251]
operator: , [38228,38229]
===
match
---
operator: , [7111,7112]
operator: , [7111,7112]
===
match
---
with_item [3386,3446]
with_item [3386,3446]
===
match
---
string: '2.0.0' [5314,5321]
string: '2.0.0' [5314,5321]
===
match
---
name: sensitive_config_values [13863,13886]
name: sensitive_config_values [13863,13886]
===
match
---
atom_expr [35243,35253]
atom_expr [35243,35253]
===
match
---
operator: { [7925,7926]
operator: { [7925,7926]
===
match
---
simple_stmt [15230,15244]
simple_stmt [15230,15244]
===
match
---
name: dictionary [20751,20761]
name: dictionary [20751,20761]
===
match
---
parameters [26483,26545]
parameters [26483,26545]
===
match
---
name: compile [7746,7753]
name: compile [7746,7753]
===
match
---
if_stmt [22654,22714]
if_stmt [22654,22714]
===
match
---
param [16308,16323]
param [16308,16323]
===
match
---
expr_stmt [9554,9578]
expr_stmt [9554,9578]
===
match
---
name: filenames [20571,20580]
name: filenames [20571,20580]
===
match
---
param [16805,16810]
param [16805,16810]
===
match
---
name: section [16670,16677]
name: section [16670,16677]
===
match
---
expr_stmt [22295,22319]
expr_stmt [22295,22319]
===
match
---
name: section [29328,29335]
name: section [29328,29335]
===
match
---
trailer [22508,22527]
trailer [22508,22527]
===
match
---
atom [6890,6935]
atom [6890,6935]
===
match
---
fstring_expr [23540,23561]
fstring_expr [23540,23561]
===
match
---
suite [13533,13594]
suite [13533,13594]
===
match
---
name: secrets_client [2900,2914]
name: secrets_client [2900,2914]
===
match
---
param [14042,14045]
param [14042,14045]
===
match
---
string: 'default' [25770,25779]
string: 'default' [25770,25779]
===
match
---
name: secrets_backend_list [44367,44387]
name: secrets_backend_list [44345,44365]
===
match
---
name: _write_section [23666,23680]
name: _write_section [23666,23680]
===
match
---
string: '2.1' [8126,8131]
string: '2.1' [8126,8131]
===
match
---
param [18513,18521]
param [18513,18521]
===
match
---
operator: { [10677,10678]
operator: { [10677,10678]
===
match
---
arglist [33748,33772]
arglist [33748,33772]
===
match
---
funcdef [14375,14838]
funcdef [14375,14838]
===
match
---
operator: , [21639,21640]
operator: , [21639,21640]
===
match
---
string: 'default_airflow.cfg' [33638,33659]
string: 'default_airflow.cfg' [33638,33659]
===
match
---
testlist_comp [7838,7894]
testlist_comp [7838,7894]
===
match
---
name: TEST_PLUGINS_FOLDER [43996,44015]
name: TEST_PLUGINS_FOLDER [43974,43993]
===
match
---
suite [15540,15567]
suite [15540,15567]
===
match
---
trailer [18560,18564]
trailer [18560,18564]
===
match
---
name: display_sensitive [26083,26100]
name: display_sensitive [26083,26100]
===
match
---
name: TEST_CONFIG_FILE [30371,30387]
name: TEST_CONFIG_FILE [30371,30387]
===
match
---
trailer [31975,31979]
trailer [31975,31979]
===
match
---
name: self [16906,16910]
name: self [16906,16910]
===
match
---
not_test [27280,27287]
not_test [27280,27287]
===
match
---
operator: , [14402,14403]
operator: , [14402,14403]
===
match
---
suite [27886,28978]
suite [27886,28978]
===
match
---
atom_expr [39053,39085]
atom_expr [39031,39063]
===
match
---
trailer [44194,44202]
trailer [44172,44180]
===
match
---
operator: , [30824,30825]
operator: , [30824,30825]
===
match
---
trailer [21506,21517]
trailer [21506,21517]
===
match
---
name: str [25711,25714]
name: str [25711,25714]
===
match
---
atom_expr [12240,12274]
atom_expr [12240,12274]
===
match
---
atom [23162,23176]
atom [23162,23176]
===
match
---
trailer [2551,2553]
trailer [2551,2553]
===
match
---
atom_expr [27182,27210]
atom_expr [27182,27210]
===
match
---
trailer [37944,38219]
trailer [37922,38197]
===
match
---
atom [5787,5832]
atom [5787,5832]
===
match
---
comp_op [15683,15689]
comp_op [15683,15689]
===
match
---
name: self [29774,29778]
name: self [29774,29778]
===
match
---
operator: = [37003,37004]
operator: = [36981,36982]
===
match
---
suite [15217,15244]
suite [15217,15244]
===
match
---
fstring_expr [19356,19361]
fstring_expr [19356,19361]
===
match
---
name: section [27923,27930]
name: section [27923,27930]
===
match
---
trailer [26981,26988]
trailer [26981,26988]
===
match
---
atom_expr [40322,40351]
atom_expr [40300,40329]
===
match
---
name: dirname [43876,43883]
name: dirname [43854,43861]
===
match
---
name: AIRFLOW_HOME [43420,43432]
name: AIRFLOW_HOME [43398,43410]
===
match
---
suite [42469,42579]
suite [42447,42557]
===
match
---
operator: , [5852,5853]
operator: , [5852,5853]
===
match
---
param [11990,11998]
param [11990,11998]
===
match
---
suite [29088,29367]
suite [29088,29367]
===
match
---
atom [4712,4748]
atom [4712,4748]
===
match
---
name: _using_old_value [11854,11870]
name: _using_old_value [11854,11870]
===
match
---
return_stmt [13990,14001]
return_stmt [13990,14001]
===
match
---
string: "deprecated. Please access the configuration from the 'configuration.conf' object via " [40141,40228]
string: "deprecated. Please access the configuration from the 'configuration.conf' object via " [40119,40206]
===
match
---
simple_stmt [12240,12275]
simple_stmt [12240,12275]
===
match
---
operator: , [7784,7785]
operator: , [7784,7785]
===
match
---
simple_stmt [20347,20551]
simple_stmt [20347,20551]
===
match
---
testlist_comp [4604,4631]
testlist_comp [4604,4631]
===
match
---
operator: , [6263,6264]
operator: , [6263,6264]
===
match
---
fstring_string: " section.  [19309,19320]
fstring_string: " section.  [19309,19320]
===
match
---
operator: } [18926,18927]
operator: } [18926,18927]
===
match
---
string: 'core' [4018,4024]
string: 'core' [4018,4024]
===
match
---
param [16344,16348]
param [16344,16348]
===
match
---
suite [18710,18735]
suite [18710,18735]
===
match
---
atom_expr [23826,23858]
atom_expr [23826,23858]
===
match
---
expr_stmt [1508,1541]
expr_stmt [1508,1541]
===
match
---
suite [1828,2245]
suite [1828,2245]
===
match
---
string: '2.1.0' [7299,7306]
string: '2.1.0' [7299,7306]
===
match
---
comp_op [18163,18169]
comp_op [18163,18169]
===
match
---
simple_stmt [27368,27387]
simple_stmt [27368,27387]
===
match
---
if_stmt [28413,28471]
if_stmt [28413,28471]
===
match
---
arglist [39194,39457]
arglist [39172,39435]
===
match
---
name: warnings [37931,37939]
name: warnings [37909,37917]
===
match
---
string: 'scheduler' [6618,6629]
string: 'scheduler' [6618,6629]
===
match
---
expr_stmt [28315,28333]
expr_stmt [28315,28333]
===
match
---
dotted_name [34437,34456]
dotted_name [34437,34456]
===
match
---
trailer [14949,14951]
trailer [14949,14951]
===
match
---
name: section [22186,22193]
name: section [22186,22193]
===
match
---
operator: * [39069,39070]
operator: * [39047,39048]
===
match
---
for_stmt [22487,22819]
for_stmt [22487,22819]
===
match
---
name: conf [37817,37821]
name: conf [37795,37799]
===
match
---
funcdef [36628,37041]
funcdef [36606,37019]
===
match
---
name: space_around_delimiters [23295,23318]
name: space_around_delimiters [23295,23318]
===
match
---
operator: , [25924,25925]
operator: , [25924,25925]
===
match
---
atom_expr [2384,2399]
atom_expr [2384,2399]
===
match
---
name: get [35341,35344]
name: get [35341,35344]
===
match
---
string: '1' [18705,18708]
string: '1' [18705,18708]
===
match
---
string: 'unit_test_mode' [33756,33772]
string: 'unit_test_mode' [33756,33772]
===
match
---
name: fh [42384,42386]
name: fh [42362,42364]
===
match
---
string: '' [22634,22636]
string: '' [22634,22636]
===
match
---
trailer [44153,44167]
trailer [44131,44145]
===
match
---
name: args [40751,40755]
name: args [40729,40733]
===
match
---
trailer [8852,8870]
trailer [8852,8870]
===
match
---
atom_expr [11100,11333]
atom_expr [11100,11333]
===
match
---
return_stmt [15397,15410]
return_stmt [15397,15410]
===
match
---
name: sect [29529,29533]
name: sect [29529,29533]
===
match
---
trailer [43968,43990]
trailer [43946,43968]
===
match
---
name: _get_config_value_from_secret_backend [2790,2827]
name: _get_config_value_from_secret_backend [2790,2827]
===
match
---
operator: , [17313,17314]
operator: , [17313,17314]
===
match
---
name: configparser [1114,1126]
name: configparser [1114,1126]
===
match
---
operator: + [14075,14076]
operator: + [14075,14076]
===
match
---
expr_stmt [32912,32982]
expr_stmt [32912,32982]
===
match
---
funcdef [17957,18487]
funcdef [17957,18487]
===
match
---
trailer [36451,36527]
trailer [36451,36527]
===
match
---
trailer [43548,43553]
trailer [43526,43531]
===
match
---
string: 'metrics' [6284,6293]
string: 'metrics' [6284,6293]
===
match
---
string: r'.' [7761,7765]
string: r'.' [7761,7765]
===
match
---
name: update [31864,31870]
name: update [31864,31870]
===
match
---
atom_expr [2482,2506]
atom_expr [2482,2506]
===
match
---
expr_stmt [11414,11473]
expr_stmt [11414,11473]
===
match
---
name: opt [28372,28375]
name: opt [28372,28375]
===
match
---
name: old [30776,30779]
name: old [30776,30779]
===
match
---
string: 'in the config file is deprecated. Please use only the AIRFLOW_HOME ' [35053,35122]
string: 'in the config file is deprecated. Please use only the AIRFLOW_HOME ' [35053,35122]
===
match
---
operator: , [6334,6335]
operator: , [6334,6335]
===
match
---
trailer [23850,23856]
trailer [23850,23856]
===
match
---
operator: = [1732,1733]
operator: = [1732,1733]
===
match
---
name: conf [37017,37021]
name: conf [36995,36999]
===
match
---
trailer [35344,35368]
trailer [35344,35368]
===
match
---
return_stmt [18475,18486]
return_stmt [18475,18486]
===
match
---
trailer [28381,28389]
trailer [28381,28389]
===
match
---
suite [28862,28897]
suite [28862,28897]
===
match
---
atom [7742,7773]
atom [7742,7773]
===
match
---
name: key [22596,22599]
name: key [22596,22599]
===
match
---
name: __dict__ [31855,31863]
name: __dict__ [31855,31863]
===
match
---
name: str [18552,18555]
name: str [18552,18555]
===
match
---
simple_stmt [37087,37108]
simple_stmt [37065,37086]
===
match
---
operator: , [8592,8593]
operator: , [8592,8593]
===
match
---
arglist [15296,15352]
arglist [15296,15352]
===
match
---
name: current_value [8988,9001]
name: current_value [8988,9001]
===
match
---
expr_stmt [20082,20148]
expr_stmt [20082,20148]
===
match
---
name: read [42406,42410]
name: read [42384,42388]
===
match
---
strings [37954,38162]
strings [37932,38140]
===
match
---
name: self [23897,23901]
name: self [23897,23901]
===
match
---
operator: , [30946,30947]
operator: , [30946,30947]
===
match
---
name: airflow_home [32160,32172]
name: airflow_home [32160,32172]
===
match
---
param [17315,17334]
param [17315,17334]
===
match
---
argument [41479,41496]
argument [41457,41474]
===
match
---
name: current_value [12723,12736]
name: current_value [12723,12736]
===
match
---
if_stmt [26780,26916]
if_stmt [26780,26916]
===
match
---
simple_stmt [32406,32449]
simple_stmt [32406,32449]
===
match
---
trailer [18564,18588]
trailer [18564,18588]
===
match
---
trailer [2504,2506]
trailer [2504,2506]
===
match
---
simple_stmt [33585,33661]
simple_stmt [33585,33661]
===
match
---
trailer [39057,39068]
trailer [39035,39046]
===
match
---
name: config_sources [26490,26504]
name: config_sources [26490,26504]
===
match
---
operator: , [19415,19416]
operator: , [19415,19416]
===
match
---
atom_expr [14271,14305]
atom_expr [14271,14305]
===
match
---
atom_expr [19143,19151]
atom_expr [19143,19151]
===
match
---
operator: , [26405,26406]
operator: , [26405,26406]
===
match
---
atom_expr [16025,16074]
atom_expr [16025,16074]
===
match
---
operator: = [20120,20121]
operator: = [20120,20121]
===
match
---
atom_expr [29571,29584]
atom_expr [29571,29584]
===
match
---
name: Pep562 [44492,44498]
name: Pep562 [44486,44492]
===
match
---
name: update [26982,26988]
name: update [26982,26988]
===
match
---
suite [27151,27655]
suite [27151,27655]
===
match
---
for_stmt [29950,30023]
for_stmt [29950,30023]
===
match
---
expr_stmt [34943,35209]
expr_stmt [34943,35209]
===
match
---
name: ValueError [23022,23032]
name: ValueError [23022,23032]
===
match
---
name: key [13850,13853]
name: key [13850,13853]
===
match
---
string: '< hidden >' [26751,26763]
string: '< hidden >' [26751,26763]
===
match
---
name: exceptions [1304,1314]
name: exceptions [1304,1314]
===
match
---
fstring_expr [2681,2701]
fstring_expr [2681,2701]
===
match
---
operator: } [43195,43196]
operator: } [43173,43174]
===
match
---
testlist_comp [4958,4999]
testlist_comp [4958,4999]
===
match
---
simple_stmt [42014,42057]
simple_stmt [41992,42035]
===
match
---
suite [8930,9545]
suite [8930,9545]
===
match
---
try_stmt [19484,19748]
try_stmt [19484,19748]
===
match
---
suite [41079,41125]
suite [41057,41103]
===
match
---
name: configs [29126,29133]
name: configs [29126,29133]
===
match
---
name: os [43647,43649]
name: os [43625,43627]
===
match
---
string: r'\A#007A87\Z' [7849,7863]
string: r'\A#007A87\Z' [7849,7863]
===
match
---
string: 'core' [4635,4641]
string: 'core' [4635,4641]
===
match
---
testlist_comp [5981,6031]
testlist_comp [5981,6031]
===
match
---
simple_stmt [25859,25947]
simple_stmt [25859,25947]
===
match
---
atom_expr [3123,3148]
atom_expr [3123,3148]
===
match
---
import_as_names [1373,1420]
import_as_names [1373,1420]
===
match
---
name: stacklevel [36993,37003]
name: stacklevel [36971,36981]
===
match
---
name: PIPE [2419,2423]
name: PIPE [2419,2423]
===
match
---
fstring_end: ' [19689,19690]
fstring_end: ' [19689,19690]
===
match
---
trailer [43875,43883]
trailer [43853,43861]
===
match
---
name: current_value [11882,11895]
name: current_value [11882,11895]
===
match
---
operator: , [12750,12751]
operator: , [12750,12751]
===
match
---
name: self [16302,16306]
name: self [16302,16306]
===
match
---
name: self [23793,23797]
name: self [23793,23797]
===
match
---
simple_stmt [8714,8740]
simple_stmt [8714,8740]
===
match
---
name: Dict [25716,25720]
name: Dict [25716,25720]
===
match
---
simple_stmt [38311,38335]
simple_stmt [38289,38313]
===
match
---
atom [6757,6794]
atom [6757,6794]
===
match
---
operator: , [15853,15854]
operator: , [15853,15854]
===
match
---
expr_stmt [16406,16452]
expr_stmt [16406,16452]
===
match
---
suite [17016,17235]
suite [17016,17235]
===
match
---
operator: , [33985,33986]
operator: , [33985,33986]
===
match
---
name: display_source [26102,26116]
name: display_source [26102,26116]
===
match
---
string: """         Remove an option if it exists in config from a file or         default config. If both of config have the same option, this removes         the option in both configs unless remove_default=False.         """ [21268,21487]
string: """         Remove an option if it exists in config from a file or         default config. If both of config have the same option, this removes         the option in both configs unless remove_default=False.         """ [21268,21487]
===
match
---
atom_expr [22038,22063]
atom_expr [22038,22063]
===
match
---
atom_expr [16103,16171]
atom_expr [16103,16171]
===
match
---
simple_stmt [31779,31811]
simple_stmt [31779,31811]
===
match
---
trailer [42815,42867]
trailer [42793,42845]
===
match
---
trailer [20331,20334]
trailer [20331,20334]
===
match
---
name: env_var_secret_path [13960,13979]
name: env_var_secret_path [13960,13979]
===
match
---
comp_op [33140,33146]
comp_op [33140,33146]
===
match
---
if_stmt [43644,43787]
if_stmt [43622,43765]
===
match
---
simple_stmt [22371,22421]
simple_stmt [22371,22421]
===
match
---
atom [44449,44455]
atom [44443,44449]
===
match
---
name: key [14929,14932]
name: key [14929,14932]
===
match
---
operator: } [12990,12991]
operator: } [12990,12991]
===
match
---
expr_stmt [28879,28896]
expr_stmt [28879,28896]
===
match
---
name: StrictVersion [10491,10504]
name: StrictVersion [10491,10504]
===
match
---
arglist [21570,21585]
arglist [21570,21585]
===
match
---
operator: ** [20139,20141]
operator: ** [20139,20141]
===
match
---
trailer [42152,42164]
trailer [42130,42142]
===
match
---
atom_expr [29536,29585]
atom_expr [29536,29585]
===
match
---
simple_stmt [30195,30269]
simple_stmt [30195,30269]
===
match
---
name: path [43583,43587]
name: path [43561,43565]
===
match
---
trailer [31979,32008]
trailer [31979,32008]
===
match
---
simple_stmt [13354,13385]
simple_stmt [13354,13385]
===
match
---
trailer [28923,28934]
trailer [28923,28934]
===
match
---
param [37051,37057]
param [37029,37035]
===
match
---
trailer [34861,34877]
trailer [34861,34877]
===
match
---
atom [7048,7082]
atom [7048,7082]
===
match
---
return_stmt [40734,40766]
return_stmt [40712,40744]
===
match
---
string: 'admin' [7356,7363]
string: 'admin' [7356,7363]
===
match
---
trailer [28125,28133]
trailer [28125,28133]
===
match
---
operator: , [14228,14229]
operator: , [14228,14229]
===
match
---
trailer [9008,9012]
trailer [9008,9012]
===
match
---
param [32287,32295]
param [32287,32295]
===
match
---
operator: , [5000,5001]
operator: , [5000,5001]
===
match
---
name: items [23722,23727]
name: items [23722,23727]
===
match
---
argument [34611,34624]
argument [34611,34624]
===
match
---
name: version [12773,12780]
name: version [12773,12780]
===
match
---
funcdef [37043,37428]
funcdef [37021,37406]
===
match
---
operator: , [34175,34176]
operator: , [34175,34176]
===
match
---
string: 'logging' [5933,5942]
string: 'logging' [5933,5942]
===
match
---
operator: = [41327,41328]
operator: = [41305,41306]
===
match
---
suite [33855,34301]
suite [33855,34301]
===
match
---
suite [17117,17235]
suite [17117,17235]
===
match
---
expr_stmt [26887,26915]
expr_stmt [26887,26915]
===
match
---
name: self [15429,15433]
name: self [15429,15433]
===
match
---
param [18010,18029]
param [18010,18029]
===
match
---
number: 2 [27958,27959]
number: 2 [27958,27959]
===
match
---
name: delimiter [23590,23599]
name: delimiter [23590,23599]
===
match
---
trailer [14912,14918]
trailer [14912,14918]
===
match
---
suite [42387,42413]
suite [42365,42391]
===
match
---
argument [41498,41518]
argument [41476,41496]
===
match
---
atom [5664,5696]
atom [5664,5696]
===
match
---
name: version [9514,9521]
name: version [9514,9521]
===
match
---
trailer [15742,15774]
trailer [15742,15774]
===
match
---
name: warnoptions [1592,1603]
name: warnoptions [1592,1603]
===
match
---
if_stmt [18614,18673]
if_stmt [18614,18673]
===
match
---
string: "mp_start_method should not be " [11144,11176]
string: "mp_start_method should not be " [11144,11176]
===
match
---
argument [2425,2439]
argument [2425,2439]
===
match
---
fstring [10107,10174]
fstring [10107,10174]
===
match
---
operator: , [35670,35671]
operator: , [35670,35671]
===
match
---
trailer [1710,1725]
trailer [1710,1725]
===
match
---
name: remove_option [39914,39927]
name: remove_option [39892,39905]
===
match
---
operator: , [29289,29290]
operator: , [29289,29290]
===
match
---
operator: = [2230,2231]
operator: = [2230,2231]
===
match
---
param [20813,20819]
param [20813,20819]
===
match
---
return_stmt [16972,16985]
return_stmt [16972,16985]
===
match
---
atom_expr [43365,43383]
atom_expr [43343,43361]
===
match
---
name: has_option [14210,14220]
name: has_option [14210,14220]
===
match
---
operator: , [5254,5255]
operator: , [5254,5255]
===
match
---
name: strip [18665,18670]
name: strip [18665,18670]
===
match
---
operator: , [6737,6738]
operator: , [6737,6738]
===
match
---
atom [4834,4867]
atom [4834,4867]
===
match
---
name: raw [25942,25945]
name: raw [25942,25945]
===
match
---
param [29488,29492]
param [29488,29492]
===
match
---
tfpdef [12918,12926]
tfpdef [12918,12926]
===
match
---
trailer [37939,37944]
trailer [37917,37922]
===
match
---
import_from [1291,1344]
import_from [1291,1344]
===
match
---
simple_stmt [9554,9579]
simple_stmt [9554,9579]
===
match
---
name: self [13504,13508]
name: self [13504,13508]
===
match
---
string: 'unit_test_mode' [28280,28296]
string: 'unit_test_mode' [28280,28296]
===
match
---
simple_stmt [21268,21488]
simple_stmt [21268,21488]
===
match
---
import_name [786,802]
import_name [786,802]
===
match
---
name: include_cmds [26163,26175]
name: include_cmds [26163,26175]
===
match
---
suite [27903,28022]
suite [27903,28022]
===
match
---
name: TEST_PLUGINS_FOLDER [44049,44068]
name: TEST_PLUGINS_FOLDER [44027,44046]
===
match
---
simple_stmt [34310,34334]
simple_stmt [34310,34334]
===
match
---
simple_stmt [853,863]
simple_stmt [853,863]
===
match
---
string: '%' [28390,28393]
string: '%' [28390,28393]
===
match
---
funcdef [20664,20778]
funcdef [20664,20778]
===
match
---
name: key [28017,28020]
name: key [28017,28020]
===
match
---
string: 'DebugExecutor' [9875,9890]
string: 'DebugExecutor' [9875,9890]
===
match
---
simple_stmt [34639,34683]
simple_stmt [34639,34683]
===
match
---
fstring_expr [18937,18946]
fstring_expr [18937,18946]
===
match
---
atom_expr [28253,28297]
atom_expr [28253,28297]
===
match
---
testlist_comp [6430,6454]
testlist_comp [6430,6454]
===
match
---
suite [13422,13594]
suite [13422,13594]
===
match
---
operator: = [16413,16414]
operator: = [16413,16414]
===
match
---
atom_expr [33602,33660]
atom_expr [33602,33660]
===
match
---
operator: , [19401,19402]
operator: , [19401,19402]
===
match
---
operator: , [43055,43056]
operator: , [43033,43034]
===
match
---
parameters [9617,9623]
parameters [9617,9623]
===
match
---
operator: = [35298,35299]
operator: = [35298,35299]
===
match
---
operator: = [38210,38211]
operator: = [38188,38189]
===
match
---
testlist_comp [5245,5278]
testlist_comp [5245,5278]
===
match
---
string: 'metrics' [6355,6364]
string: 'metrics' [6355,6364]
===
match
---
name: getsection [21743,21753]
name: getsection [21743,21753]
===
match
---
string: 'core' [6107,6113]
string: 'core' [6107,6113]
===
match
---
string: 'core' [34906,34912]
string: 'core' [34906,34912]
===
match
---
fstring_start: f" [32646,32648]
fstring_start: f" [32646,32648]
===
match
---
number: 7 [44453,44454]
number: 7 [44447,44448]
===
match
---
testlist_comp [5163,5193]
testlist_comp [5163,5193]
===
match
---
raise_stmt [10078,10175]
raise_stmt [10078,10175]
===
match
---
operator: , [29321,29322]
operator: , [29321,29322]
===
match
---
name: environ [27818,27825]
name: environ [27818,27825]
===
match
---
trailer [36537,36546]
trailer [44402,44411]
===
match
---
operator: , [4844,4845]
operator: , [4844,4845]
===
match
---
name: section [29562,29569]
name: section [29562,29569]
===
match
---
atom_expr [31755,31770]
atom_expr [31755,31770]
===
match
---
name: self [23633,23637]
name: self [23633,23637]
===
match
---
decorated [29372,29748]
decorated [29372,29748]
===
match
---
name: TEST_CONFIG_FILE [30407,30423]
name: TEST_CONFIG_FILE [30407,30423]
===
match
---
atom_expr [32215,32243]
atom_expr [32215,32243]
===
match
---
trailer [27581,27588]
trailer [27581,27588]
===
match
---
name: cfg [34207,34210]
name: cfg [34207,34210]
===
match
---
name: _get_cmd_option [17043,17058]
name: _get_cmd_option [17043,17058]
===
match
---
trailer [35845,35850]
trailer [35845,35850]
===
match
---
trailer [42540,42546]
trailer [42518,42524]
===
match
---
operator: , [5428,5429]
operator: , [5428,5429]
===
match
---
operator: , [15782,15783]
operator: , [15782,15783]
===
match
---
atom [7707,7784]
atom [7707,7784]
===
match
---
expr_stmt [44367,44419]
expr_stmt [44345,44397]
===
match
---
arglist [9210,9257]
arglist [9210,9257]
===
match
---
name: name [31558,31562]
name: name [31558,31562]
===
match
---
name: re [7743,7745]
name: re [7743,7745]
===
match
---
string: 'plugins' [43939,43948]
string: 'plugins' [43917,43926]
===
match
---
operator: } [42869,42870]
operator: } [42847,42848]
===
match
---
string: 'from your airflow.cfg and suffer no change in behaviour.' [35612,35670]
string: 'from your airflow.cfg and suffer no change in behaviour.' [35612,35670]
===
match
---
name: update [28959,28965]
name: update [28959,28965]
===
match
---
operator: = [43399,43400]
operator: = [43377,43378]
===
match
---
trailer [22772,22777]
trailer [22772,22777]
===
match
---
name: AIRFLOW_HOME [35372,35384]
name: AIRFLOW_HOME [35372,35384]
===
match
---
name: self [17764,17768]
name: self [17764,17768]
===
match
---
suite [11616,11845]
suite [11616,11845]
===
match
---
operator: , [4152,4153]
operator: , [4152,4153]
===
match
---
arglist [17621,17643]
arglist [17621,17643]
===
match
---
simple_stmt [26819,26841]
simple_stmt [26819,26841]
===
match
---
param [27684,27699]
param [27684,27699]
===
match
---
arglist [37135,37384]
arglist [37113,37362]
===
match
---
try_stmt [20830,21192]
try_stmt [20830,21192]
===
match
---
if_stmt [22149,22320]
if_stmt [22149,22320]
===
match
---
name: shutil [36340,36346]
name: shutil [36340,36346]
===
match
---
operator: = [12780,12781]
operator: = [12780,12781]
===
match
---
dotted_name [33318,33337]
dotted_name [33318,33337]
===
match
---
argument [9367,9382]
argument [9367,9382]
===
match
---
trailer [19219,19378]
trailer [19219,19378]
===
match
---
exprlist [22832,22840]
exprlist [22832,22840]
===
match
---
name: base64 [951,957]
name: base64 [951,957]
===
match
---
string: """Get Config option values from Secret Backend""" [2845,2895]
string: """Get Config option values from Secret Backend""" [2845,2895]
===
match
---
name: key [14581,14584]
name: key [14581,14584]
===
match
---
trailer [30582,30587]
trailer [30582,30587]
===
match
---
name: raw [27470,27473]
name: raw [27470,27473]
===
match
---
suite [34190,34301]
suite [34190,34301]
===
match
---
fstring_expr [18993,18998]
fstring_expr [18993,18998]
===
match
---
simple_stmt [34564,34626]
simple_stmt [34564,34626]
===
match
---
operator: = [8965,8966]
operator: = [8965,8966]
===
match
---
atom_expr [13504,13532]
atom_expr [13504,13532]
===
match
---
name: key [18574,18577]
name: key [18574,18577]
===
match
---
atom_expr [36091,36114]
atom_expr [36091,36114]
===
match
---
trailer [21553,21555]
trailer [21553,21555]
===
match
---
parameters [37050,37067]
parameters [37028,37045]
===
match
---
name: deprecated_section [15312,15330]
name: deprecated_section [15312,15330]
===
match
---
suite [30519,31480]
suite [30519,31480]
===
match
---
string: 'dag_processor_manager_log_location' [6054,6090]
string: 'dag_processor_manager_log_location' [6054,6090]
===
match
---
atom [29703,29721]
atom [29703,29721]
===
match
---
trailer [28501,28507]
trailer [28501,28507]
===
match
---
if_stmt [33115,33218]
if_stmt [33115,33218]
===
match
---
name: full_qualified_path [20164,20183]
name: full_qualified_path [20164,20183]
===
match
---
trailer [22386,22420]
trailer [22386,22420]
===
match
---
operator: , [6660,6661]
operator: , [6660,6661]
===
match
---
trailer [12212,12216]
trailer [12212,12216]
===
match
---
operator: ** [37058,37060]
operator: ** [37036,37038]
===
match
---
name: remove_option [21556,21569]
name: remove_option [21556,21569]
===
match
---
name: raw [27735,27738]
name: raw [27735,27738]
===
match
---
name: kwargs [37842,37848]
name: kwargs [37820,37826]
===
match
---
name: stacklevel [43069,43079]
name: stacklevel [43047,43057]
===
match
---
operator: ! [32682,32683]
operator: ! [32682,32683]
===
match
---
string: '2.0.0' [6411,6418]
string: '2.0.0' [6411,6418]
===
match
---
trailer [39068,39085]
trailer [39046,39063]
===
match
---
name: run_command [13557,13568]
name: run_command [13557,13568]
===
match
---
atom_expr [7743,7759]
atom_expr [7743,7759]
===
match
---
trailer [15136,15186]
trailer [15136,15186]
===
match
---
string: '' [44308,44310]
string: '' [44286,44288]
===
match
---
operator: , [5586,5587]
operator: , [5586,5587]
===
match
---
trailer [44078,44083]
trailer [44056,44061]
===
match
---
operator: , [39533,39534]
operator: , [39511,39512]
===
match
---
operator: + [36254,36255]
operator: + [36254,36255]
===
match
---
simple_stmt [878,888]
simple_stmt [878,888]
===
match
---
operator: * [8524,8525]
operator: * [8524,8525]
===
match
---
name: deprecated_key [17079,17093]
name: deprecated_key [17079,17093]
===
match
---
string: ", " [11284,11288]
string: ", " [11284,11288]
===
match
---
operator: , [5375,5376]
operator: , [5375,5376]
===
match
---
suite [20309,20551]
suite [20309,20551]
===
match
---
expr_stmt [22699,22713]
expr_stmt [22699,22713]
===
match
---
operator: , [28015,28016]
operator: , [28015,28016]
===
match
---
return_stmt [33222,33278]
return_stmt [33222,33278]
===
match
---
operator: } [10172,10173]
operator: } [10172,10173]
===
match
---
simple_stmt [20197,20209]
simple_stmt [20197,20209]
===
match
---
name: display_source [23911,23925]
name: display_source [23911,23925]
===
match
---
name: category [35856,35864]
name: category [35856,35864]
===
match
---
name: _TEST_PLUGINS_FOLDER [44018,44038]
name: _TEST_PLUGINS_FOLDER [43996,44016]
===
match
---
arglist [40335,40350]
arglist [40313,40328]
===
match
---
name: config [29162,29168]
name: config [29162,29168]
===
match
---
expr_stmt [34639,34682]
expr_stmt [34639,34682]
===
match
---
name: kwargs [38656,38662]
name: kwargs [38634,38640]
===
match
---
string: '1.10.4' [7493,7501]
string: '1.10.4' [7493,7501]
===
match
---
operator: != [28250,28252]
operator: != [28250,28252]
===
match
---
name: name [9337,9341]
name: name [9337,9341]
===
match
---
string: 'backend' [41343,41352]
string: 'backend' [41321,41330]
===
match
---
trailer [15005,15024]
trailer [15005,15024]
===
match
---
fstring_end: " [2753,2754]
fstring_end: " [2753,2754]
===
match
---
string: 'max_threads' [7098,7111]
string: 'max_threads' [7098,7111]
===
match
---
name: section [22349,22356]
name: section [22349,22356]
===
match
---
operator: = [43544,43545]
operator: = [43522,43523]
===
match
---
atom_expr [22764,22777]
atom_expr [22764,22777]
===
match
---
name: join [11800,11804]
name: join [11800,11804]
===
match
---
simple_stmt [2845,2896]
simple_stmt [2845,2896]
===
match
---
name: display_source [29472,29486]
name: display_source [29472,29486]
===
match
---
simple_stmt [39902,39945]
simple_stmt [39880,39923]
===
match
---
operator: } [23560,23561]
operator: } [23560,23561]
===
match
---
simple_stmt [26745,26764]
simple_stmt [26745,26764]
===
match
---
suite [34343,36115]
suite [34343,36115]
===
match
---
name: os [35243,35245]
name: os [35243,35245]
===
match
---
name: self [11426,11430]
name: self [11426,11430]
===
match
---
operator: , [7491,7492]
operator: , [7491,7492]
===
match
---
simple_stmt [34752,34779]
simple_stmt [34752,34779]
===
match
---
trailer [8523,8540]
trailer [8523,8540]
===
match
---
name: kwargs [15862,15868]
name: kwargs [15862,15868]
===
match
---
expr_stmt [44049,44108]
expr_stmt [44027,44086]
===
match
---
simple_stmt [803,815]
simple_stmt [803,815]
===
match
---
trailer [32122,32130]
trailer [32122,32130]
===
match
---
argument [9028,9041]
argument [9028,9041]
===
match
---
return_stmt [14358,14369]
return_stmt [14358,14369]
===
match
---
name: expand_env_var [17594,17608]
name: expand_env_var [17594,17608]
===
match
---
name: deprecated_section [18213,18231]
name: deprecated_section [18213,18231]
===
match
---
name: self [15105,15109]
name: self [15105,15109]
===
match
---
simple_stmt [34788,34843]
simple_stmt [34788,34843]
===
match
---
simple_stmt [31943,32010]
simple_stmt [31943,32010]
===
match
---
name: self [21215,21219]
name: self [21215,21219]
===
match
---
atom [6504,6532]
atom [6504,6532]
===
match
---
atom_expr [12160,12193]
atom_expr [12160,12193]
===
match
---
argument [20740,20761]
argument [20740,20761]
===
match
---
arglist [34050,34077]
arglist [34050,34077]
===
match
---
fstring_string: . [42971,42972]
fstring_string: . [42949,42950]
===
match
---
return_stmt [32576,32622]
return_stmt [32576,32622]
===
match
---
raise_stmt [10582,10819]
raise_stmt [10582,10819]
===
match
---
if_stmt [16994,17235]
if_stmt [16994,17235]
===
match
---
trailer [37120,37125]
trailer [37098,37103]
===
match
---
trailer [15923,15940]
trailer [15923,15940]
===
match
---
name: os [43580,43582]
name: os [43558,43560]
===
match
---
operator: ** [39535,39537]
operator: ** [39513,39515]
===
match
---
expr_stmt [41593,41629]
expr_stmt [41571,41607]
===
match
---
name: kwargs [18529,18535]
name: kwargs [18529,18535]
===
match
---
if_stmt [21596,21734]
if_stmt [21596,21734]
===
match
---
string: '[{new_section}] - the old setting has been used, but please update your config.' [31120,31201]
string: '[{new_section}] - the old setting has been used, but please update your config.' [31120,31201]
===
match
---
operator: = [8474,8475]
operator: = [8474,8475]
===
match
---
atom_expr [43596,43622]
atom_expr [43574,43600]
===
match
---
expr_stmt [8550,8603]
expr_stmt [8550,8603]
===
match
---
fstring [20494,20536]
fstring [20494,20536]
===
match
---
operator: , [27698,27699]
operator: , [27698,27699]
===
match
---
operator: , [17903,17904]
operator: , [17903,17904]
===
match
---
parameters [12897,12927]
parameters [12897,12927]
===
match
---
testlist_comp [7318,7352]
testlist_comp [7318,7352]
===
match
---
atom_expr [33822,33854]
atom_expr [33822,33854]
===
match
---
trailer [10914,10941]
trailer [10914,10941]
===
match
---
trailer [19085,19109]
trailer [19085,19109]
===
match
---
fstring_string:   [23539,23540]
fstring_string:   [23539,23540]
===
match
---
operator: , [30369,30370]
operator: , [30369,30370]
===
match
---
name: staticmethod [28984,28996]
name: staticmethod [28984,28996]
===
match
---
testlist_comp [6797,6843]
testlist_comp [6797,6843]
===
match
---
trailer [25720,25730]
trailer [25720,25730]
===
match
---
operator: = [26891,26892]
operator: = [26891,26892]
===
match
---
funcdef [30448,31480]
funcdef [30448,31480]
===
match
---
operator: = [30944,30945]
operator: = [30944,30945]
===
match
---
string: 'webserver' [4267,4278]
string: 'webserver' [4267,4278]
===
match
---
number: 2 [37004,37005]
number: 2 [36982,36983]
===
match
---
param [24046,24066]
param [24046,24066]
===
match
---
name: OrderedDict [29571,29582]
name: OrderedDict [29571,29582]
===
match
---
name: format [12671,12677]
name: format [12671,12677]
===
match
---
name: name [42889,42893]
name: name [42867,42871]
===
match
---
arglist [12695,12788]
arglist [12695,12788]
===
match
---
name: BaseSecretsBackend [41761,41779]
name: BaseSecretsBackend [41739,41757]
===
match
---
simple_stmt [13233,13276]
simple_stmt [13233,13276]
===
match
---
param [19767,19772]
param [19767,19772]
===
match
---
trailer [13951,13959]
trailer [13951,13959]
===
match
---
name: key [16240,16243]
name: key [16240,16243]
===
match
---
argument [30776,30795]
argument [30776,30795]
===
match
---
comp_op [9854,9860]
comp_op [9854,9860]
===
match
---
simple_stmt [36670,36704]
simple_stmt [36648,36682]
===
match
---
name: TEST_DAGS_FOLDER [43733,43749]
name: TEST_DAGS_FOLDER [43711,43727]
===
match
---
name: NoSectionError [1171,1185]
name: NoSectionError [1171,1185]
===
match
---
funcdef [41719,42241]
funcdef [41697,42219]
===
match
---
suite [2012,2036]
suite [2012,2036]
===
match
---
operator: = [23206,23207]
operator: = [23206,23207]
===
match
---
name: category [1744,1752]
name: category [1744,1752]
===
match
---
string: 'fernet_key' [4064,4076]
string: 'fernet_key' [4064,4076]
===
match
---
operator: -> [12928,12930]
operator: -> [12928,12930]
===
match
---
number: 0 [2585,2586]
number: 0 [2585,2586]
===
match
---
name: opt [28093,28096]
name: opt [28093,28096]
===
match
---
name: warnings [1609,1617]
name: warnings [1609,1617]
===
match
---
argument [2377,2399]
argument [2377,2399]
===
match
---
name: str [12913,12916]
name: str [12913,12916]
===
match
---
suite [23577,23622]
suite [23577,23622]
===
match
---
for_stmt [23750,23871]
for_stmt [23750,23871]
===
match
---
return_stmt [14322,14349]
return_stmt [14322,14349]
===
match
---
operator: = [16548,16549]
operator: = [16548,16549]
===
match
---
parameters [3072,3088]
parameters [3072,3088]
===
match
---
expr_stmt [28372,28400]
expr_stmt [28372,28400]
===
match
---
operator: , [4908,4909]
operator: , [4908,4909]
===
match
---
name: section [17422,17429]
name: section [17422,17429]
===
match
---
name: secrets_backend_cls [41283,41302]
name: secrets_backend_cls [41261,41280]
===
match
---
name: stream [2468,2474]
name: stream [2468,2474]
===
match
---
atom_expr [17609,17644]
atom_expr [17609,17644]
===
match
---
name: self [13154,13158]
name: self [13154,13158]
===
match
---
trailer [13413,13421]
trailer [13413,13421]
===
match
---
name: kwargs [15791,15797]
name: kwargs [15791,15797]
===
match
---
name: val [18546,18549]
name: val [18546,18549]
===
match
---
simple_stmt [30397,30425]
simple_stmt [30397,30425]
===
match
---
trailer [42026,42033]
trailer [42004,42011]
===
match
---
simple_stmt [44473,44499]
simple_stmt [44467,44493]
===
match
---
name: source_name [29709,29720]
name: source_name [29709,29720]
===
match
---
operator: ** [37452,37454]
operator: ** [37430,37432]
===
match
---
arglist [34706,34725]
arglist [34706,34725]
===
match
---
suite [32304,32688]
suite [32304,32688]
===
match
---
return_stmt [2980,2991]
return_stmt [2980,2991]
===
match
---
operator: , [4256,4257]
operator: , [4256,4257]
===
match
---
name: option [15096,15102]
name: option [15096,15102]
===
match
---
string: '{}' [41529,41533]
string: '{}' [41507,41511]
===
match
---
param [21238,21257]
param [21238,21257]
===
match
---
operator: , [1169,1170]
operator: , [1169,1170]
===
match
---
testlist_comp [5333,5365]
testlist_comp [5333,5365]
===
match
---
simple_stmt [12150,12194]
simple_stmt [12150,12194]
===
match
---
trailer [34671,34673]
trailer [34671,34673]
===
match
---
name: d [32972,32973]
name: d [32972,32973]
===
match
---
name: fallback_key [14056,14068]
name: fallback_key [14056,14068]
===
match
---
number: 2 [41077,41078]
number: 2 [41055,41056]
===
match
---
name: functools [42698,42707]
name: functools [42676,42685]
===
match
---
suite [26546,27062]
suite [26546,27062]
===
match
---
trailer [27817,27825]
trailer [27817,27825]
===
match
---
atom_expr [29162,29179]
atom_expr [29162,29179]
===
match
---
trailer [39184,39463]
trailer [39162,39441]
===
match
---
testlist_comp [6618,6659]
testlist_comp [6618,6659]
===
match
---
funcdef [8745,9579]
funcdef [8745,9579]
===
match
---
name: section [30846,30853]
name: section [30846,30853]
===
match
---
string: '2.1' [7767,7772]
string: '2.1' [7767,7772]
===
match
---
name: env_var [22491,22498]
name: env_var [22491,22498]
===
match
---
string: 'colored_console_log' [5377,5398]
string: 'colored_console_log' [5377,5398]
===
match
---
simple_stmt [16103,16172]
simple_stmt [16103,16172]
===
match
---
trailer [21716,21733]
trailer [21716,21733]
===
match
---
name: source_name [29102,29113]
name: source_name [29102,29113]
===
match
---
string: 'core' [4870,4876]
string: 'core' [4870,4876]
===
match
---
name: has_section [22337,22348]
name: has_section [22337,22348]
===
match
---
name: os [44192,44194]
name: os [44170,44172]
===
match
---
string: 'email' [7916,7923]
string: 'email' [7916,7923]
===
match
---
name: _env_var_name [12165,12178]
name: _env_var_name [12165,12178]
===
match
---
atom_expr [26048,26122]
atom_expr [26048,26122]
===
match
---
suite [20821,21192]
suite [20821,21192]
===
match
---
operator: = [42593,42594]
operator: = [42571,42572]
===
match
---
trailer [43553,43558]
trailer [43531,43536]
===
match
---
name: key [12918,12921]
name: key [12918,12921]
===
match
---
atom_expr [18366,18436]
atom_expr [18366,18436]
===
match
---
operator: , [16063,16064]
operator: , [16063,16064]
===
match
---
name: path [32406,32410]
name: path [32406,32410]
===
match
---
trailer [18597,18603]
trailer [18597,18603]
===
match
---
operator: } [2734,2735]
operator: } [2734,2735]
===
match
---
name: os [34388,34390]
name: os [34388,34390]
===
match
---
simple_stmt [26350,26428]
simple_stmt [26350,26428]
===
match
---
name: decode [34674,34680]
name: decode [34674,34680]
===
match
---
operator: , [8486,8487]
operator: , [8486,8487]
===
match
---
atom_expr [27938,27960]
atom_expr [27938,27960]
===
match
---
comparison [14139,14185]
comparison [14139,14185]
===
match
---
atom_expr [21499,21534]
atom_expr [21499,21534]
===
match
---
if_stmt [13837,13982]
if_stmt [13837,13982]
===
match
---
strings [18873,19001]
strings [18873,19001]
===
match
---
argument [12773,12788]
argument [12773,12788]
===
match
---
operator: = [31289,31290]
operator: = [31289,31290]
===
match
---
operator: , [40303,40304]
operator: , [40281,40282]
===
match
---
operator: , [4045,4046]
operator: , [4045,4046]
===
match
---
string: 'task_log_reader' [6246,6263]
string: 'task_log_reader' [6246,6263]
===
match
---
name: deprecated_section [18401,18419]
name: deprecated_section [18401,18419]
===
match
---
name: warnings [37513,37521]
name: warnings [37491,37499]
===
match
---
trailer [43381,43383]
trailer [43359,43361]
===
match
---
name: output [2728,2734]
name: output [2728,2734]
===
match
---
testlist_comp [4018,4044]
testlist_comp [4018,4044]
===
match
---
expr_stmt [9125,9168]
expr_stmt [9125,9168]
===
match
---
atom_expr [10832,10874]
atom_expr [10832,10874]
===
match
---
return_stmt [36554,36565]
return_stmt [36532,36543]
===
match
---
param [12904,12917]
param [12904,12917]
===
match
---
name: deprecated_values [8853,8870]
name: deprecated_values [8853,8870]
===
match
---
name: get [18561,18564]
name: get [18561,18564]
===
match
---
trailer [40804,40824]
trailer [40782,40802]
===
match
---
trailer [23711,23721]
trailer [23711,23721]
===
match
---
name: old_section [31230,31241]
name: old_section [31230,31241]
===
match
---
funcdef [16273,16770]
funcdef [16273,16770]
===
match
---
atom_expr [37112,37390]
atom_expr [37090,37368]
===
match
---
name: key [17335,17338]
name: key [17335,17338]
===
match
---
not_test [22068,22114]
not_test [22068,22114]
===
match
---
operator: -> [3248,3250]
operator: -> [3248,3250]
===
match
---
name: items [22404,22409]
name: items [22404,22409]
===
match
---
name: _defaults [23638,23647]
name: _defaults [23638,23647]
===
match
---
atom [7837,7895]
atom [7837,7895]
===
match
---
operator: , [6808,6809]
operator: , [6808,6809]
===
match
---
param [29456,29471]
param [29456,29471]
===
match
---
name: Union [1284,1289]
name: Union [1284,1289]
===
match
---
name: kwargs [15337,15343]
name: kwargs [15337,15343]
===
match
---
operator: * [38275,38276]
operator: * [38253,38254]
===
match
---
name: Fernet [34652,34658]
name: Fernet [34652,34658]
===
match
---
expr_stmt [42305,42360]
expr_stmt [42283,42338]
===
match
---
name: has_option [14642,14652]
name: has_option [14642,14652]
===
match
---
name: key [15173,15176]
name: key [15173,15176]
===
match
---
name: getint [38640,38646]
name: getint [38618,38624]
===
match
---
operator: , [4738,4739]
operator: , [4738,4739]
===
match
---
operator: , [6184,6185]
operator: , [6184,6185]
===
match
---
fstring_string: " section.  [18946,18957]
fstring_string: " section.  [18946,18957]
===
match
---
trailer [18603,18605]
trailer [18603,18605]
===
match
---
operator: , [1649,1650]
operator: , [1649,1650]
===
match
---
name: re [7865,7867]
name: re [7865,7867]
===
match
---
name: self [14398,14402]
name: self [14398,14402]
===
match
---
name: custom_secret_backend [42034,42055]
name: custom_secret_backend [42012,42033]
===
match
---
suite [27351,27387]
suite [27351,27387]
===
match
---
trailer [21620,21631]
trailer [21620,21631]
===
match
---
atom_expr [37931,38219]
atom_expr [37909,38197]
===
match
---
simple_stmt [38717,38745]
simple_stmt [38695,38723]
===
match
---
operator: , [18138,18139]
operator: , [18138,18139]
===
match
---
return_stmt [18188,18201]
return_stmt [18188,18201]
===
match
---
simple_stmt [15553,15567]
simple_stmt [15553,15567]
===
match
---
name: display_source [25926,25940]
name: display_source [25926,25940]
===
match
---
fstring_string: Current value: " [19340,19356]
fstring_string: Current value: " [19340,19356]
===
match
---
name: section [22805,22812]
name: section [22805,22812]
===
match
---
name: name [31538,31542]
name: name [31538,31542]
===
match
---
operator: , [5549,5550]
operator: , [5549,5550]
===
match
---
string: 'statsd_port' [6471,6484]
string: 'statsd_port' [6471,6484]
===
match
---
funcdef [12880,13008]
funcdef [12880,13008]
===
match
---
name: dictionary [20684,20694]
name: dictionary [20684,20694]
===
match
---
name: k [32924,32925]
name: k [32924,32925]
===
match
---
name: environ [13414,13421]
name: environ [13414,13421]
===
match
---
funcdef [19753,20551]
funcdef [19753,20551]
===
match
---
name: get [20109,20112]
name: get [20109,20112]
===
match
---
name: os [27815,27817]
name: os [27815,27817]
===
match
---
comp_if [27826,27875]
comp_if [27826,27875]
===
match
---
trailer [35284,35318]
trailer [35284,35318]
===
match
---
operator: , [24065,24066]
operator: , [24065,24066]
===
match
---
name: conf [33732,33736]
name: conf [33732,33736]
===
match
---
atom [4266,4293]
atom [4266,4293]
===
match
---
operator: , [4660,4661]
operator: , [4660,4661]
===
match
---
trailer [18595,18597]
trailer [18595,18597]
===
match
---
if_stmt [14631,14818]
if_stmt [14631,14818]
===
match
---
trailer [34158,34181]
trailer [34158,34181]
===
match
---
operator: , [39074,39075]
operator: , [39052,39053]
===
match
---
name: key [14071,14074]
name: key [14071,14074]
===
match
---
operator: , [17338,17339]
operator: , [17338,17339]
===
match
---
simple_stmt [37395,37428]
simple_stmt [37373,37406]
===
match
---
fstring_end: ' [19363,19364]
fstring_end: ' [19363,19364]
===
match
---
name: replace [28382,28389]
name: replace [28382,28389]
===
match
---
trailer [14715,14719]
trailer [14715,14719]
===
match
---
atom_expr [29734,29741]
atom_expr [29734,29741]
===
match
---
name: _get_cmd_option [16911,16926]
name: _get_cmd_option [16911,16926]
===
match
---
subscriptlist [24081,24100]
subscriptlist [24081,24100]
===
match
---
suite [35385,35739]
suite [35385,35739]
===
match
---
sync_comp_for [32929,32981]
sync_comp_for [32929,32981]
===
match
---
simple_stmt [32730,32908]
simple_stmt [32730,32908]
===
match
---
trailer [32956,32958]
trailer [32956,32958]
===
match
---
name: warnings [1702,1710]
name: warnings [1702,1710]
===
match
---
name: fallback_key [14230,14242]
name: fallback_key [14230,14242]
===
match
---
name: section [27036,27043]
name: section [27036,27043]
===
match
---
operator: -> [32297,32299]
operator: -> [32297,32299]
===
match
---
trailer [22904,22909]
trailer [22904,22909]
===
match
---
name: compile [7841,7848]
name: compile [7841,7848]
===
match
---
decorator [28983,28997]
decorator [28983,28997]
===
match
---
operator: , [38190,38191]
operator: , [38168,38169]
===
match
---
name: startswith [27844,27854]
name: startswith [27844,27854]
===
match
---
fstring_start: f" [42959,42961]
fstring_start: f" [42937,42939]
===
match
---
name: source [20770,20776]
name: source [20770,20776]
===
match
---
operator: ** [38654,38656]
operator: ** [38632,38634]
===
match
---
operator: , [14031,14032]
operator: , [14031,14032]
===
match
---
name: getfloat [19388,19396]
name: getfloat [19388,19396]
===
match
---
name: option [21230,21236]
name: option [21230,21236]
===
match
---
atom_expr [35837,35884]
atom_expr [35837,35884]
===
match
---
name: decode [33386,33392]
name: decode [33386,33392]
===
match
---
name: section [28935,28942]
name: section [28935,28942]
===
match
---
name: args [37412,37416]
name: args [37390,37394]
===
match
---
atom [6382,6419]
atom [6382,6419]
===
match
---
tfpdef [12904,12916]
tfpdef [12904,12916]
===
match
---
atom_expr [22447,22478]
atom_expr [22447,22478]
===
match
---
atom_expr [8714,8731]
atom_expr [8714,8731]
===
match
---
if_stmt [15518,15567]
if_stmt [15518,15567]
===
match
---
name: loads [41447,41452]
name: loads [41425,41430]
===
match
---
if_stmt [21496,21587]
if_stmt [21496,21587]
===
match
---
atom_expr [13911,13981]
atom_expr [13911,13981]
===
match
---
trailer [9012,9042]
trailer [9012,9042]
===
match
---
atom_expr [40451,40729]
atom_expr [40429,40707]
===
match
---
operator: , [21525,21526]
operator: , [21525,21526]
===
match
---
operator: = [1686,1687]
operator: = [1686,1687]
===
match
---
simple_stmt [3981,4301]
simple_stmt [3981,4301]
===
match
---
operator: ** [39076,39078]
operator: ** [39054,39056]
===
match
---
name: config_sources [29042,29056]
name: config_sources [29042,29056]
===
match
---
string: 'Creating new Airflow config file in: %s' [34493,34534]
string: 'Creating new Airflow config file in: %s' [34493,34534]
===
match
---
string: 'sql_alchemy_conn' [9985,10003]
string: 'sql_alchemy_conn' [9985,10003]
===
match
---
atom_expr [17764,17834]
atom_expr [17764,17834]
===
match
---
operator: , [21577,21578]
operator: , [21577,21578]
===
match
---
operator: , [42667,42668]
operator: , [42645,42646]
===
match
---
comparison [11033,11076]
comparison [11033,11076]
===
match
---
name: FutureWarning [12816,12829]
name: FutureWarning [12816,12829]
===
match
---
atom_expr [22231,22267]
atom_expr [22231,22267]
===
match
---
name: sections [29970,29978]
name: sections [29970,29978]
===
match
---
import_from [34432,34470]
import_from [34432,34470]
===
match
---
operator: } [43171,43172]
operator: } [43149,43150]
===
match
---
parameters [8380,8402]
parameters [8380,8402]
===
match
---
arglist [14720,14741]
arglist [14720,14741]
===
match
---
argument [1780,1796]
argument [1780,1796]
===
match
---
trailer [28257,28271]
trailer [28257,28271]
===
match
---
trailer [40032,40037]
trailer [40010,40015]
===
match
---
operator: , [8479,8480]
operator: , [8479,8480]
===
match
---
simple_stmt [34852,34878]
simple_stmt [34852,34878]
===
match
---
atom_expr [9554,9571]
atom_expr [9554,9571]
===
match
---
trailer [33747,33773]
trailer [33747,33773]
===
match
---
param [8481,8487]
param [8481,8487]
===
match
---
name: self [19442,19446]
name: self [19442,19446]
===
match
---
name: display_sensitive [26706,26723]
name: display_sensitive [26706,26723]
===
match
---
operator: , [12338,12339]
operator: , [12338,12339]
===
match
---
param [16349,16356]
param [16349,16356]
===
match
---
atom_expr [43884,43927]
atom_expr [43862,43905]
===
match
---
operator: == [2152,2154]
operator: == [2152,2154]
===
match
---
suite [36078,36115]
suite [36078,36115]
===
match
---
atom_expr [2563,2581]
atom_expr [2563,2581]
===
match
---
name: lower [22740,22745]
name: lower [22740,22745]
===
match
---
funcdef [40769,41157]
funcdef [40747,41135]
===
match
---
suite [30561,30962]
suite [30561,30962]
===
match
---
operator: = [44069,44070]
operator: = [44047,44048]
===
match
---
operator: , [8131,8132]
operator: , [8131,8132]
===
match
---
while_stmt [2040,2245]
while_stmt [2040,2245]
===
match
---
trailer [31863,31870]
trailer [31863,31870]
===
match
---
operator: { [43190,43191]
operator: { [43168,43169]
===
match
---
operator: , [38594,38595]
operator: , [38572,38573]
===
match
---
name: get [31976,31979]
name: get [31976,31979]
===
match
---
atom [5088,5116]
atom [5088,5116]
===
match
---
atom_expr [23793,23870]
atom_expr [23793,23870]
===
match
---
name: TEST_CONFIG_FILE [44111,44127]
name: TEST_CONFIG_FILE [44089,44105]
===
match
---
arglist [34159,34180]
arglist [34159,34180]
===
match
---
name: conf [36036,36040]
name: conf [36036,36040]
===
match
---
name: float [22988,22993]
name: float [22988,22993]
===
match
---
atom_expr [23707,23729]
atom_expr [23707,23729]
===
match
---
name: option [16952,16958]
name: option [16952,16958]
===
match
---
operator: = [9036,9037]
operator: = [9036,9037]
===
match
---
param [39528,39534]
param [39506,39512]
===
match
---
simple_stmt [26887,26916]
simple_stmt [26887,26916]
===
match
---
string: "Ignoring unknown env var '%s'" [28134,28165]
string: "Ignoring unknown env var '%s'" [28134,28165]
===
match
---
string: '2.0.0' [6336,6343]
string: '2.0.0' [6336,6343]
===
match
---
name: display_source [26783,26797]
name: display_source [26783,26797]
===
match
---
name: line [32488,32492]
name: line [32488,32492]
===
match
---
name: new [9149,9152]
name: new [9149,9152]
===
match
---
trailer [8586,8603]
trailer [8586,8603]
===
match
---
suite [27288,27314]
suite [27288,27314]
===
match
---
trailer [2112,2126]
trailer [2112,2126]
===
match
---
string: 'airflow_home' [35353,35367]
string: 'airflow_home' [35353,35367]
===
match
---
name: getint [38268,38274]
name: getint [38246,38252]
===
match
---
operator: , [20682,20683]
operator: , [20682,20683]
===
match
---
name: os [33147,33149]
name: os [33147,33149]
===
match
---
operator: , [31737,31738]
operator: , [31737,31738]
===
match
---
testlist_comp [5369,5407]
testlist_comp [5369,5407]
===
match
---
string: 'default_queue' [7147,7162]
string: 'default_queue' [7147,7162]
===
match
---
operator: , [23683,23684]
operator: , [23683,23684]
===
match
---
name: dirname [43572,43579]
name: dirname [43550,43557]
===
match
---
if_stmt [17400,17646]
if_stmt [17400,17646]
===
match
---
string: '2.0.0' [4900,4907]
string: '2.0.0' [4900,4907]
===
match
---
operator: , [5172,5173]
operator: , [5172,5173]
===
match
---
trailer [21569,21586]
trailer [21569,21586]
===
match
---
atom [6617,6660]
atom [6617,6660]
===
match
---
funcdef [11850,11959]
funcdef [11850,11959]
===
match
---
trailer [32619,32621]
trailer [32619,32621]
===
match
---
name: _get_option_from_config_file [15267,15295]
name: _get_option_from_config_file [15267,15295]
===
match
---
atom_expr [27815,27825]
atom_expr [27815,27825]
===
match
---
trailer [43152,43198]
trailer [43130,43176]
===
match
---
string: '2.0.0' [5070,5077]
string: '2.0.0' [5070,5077]
===
match
---
testlist_comp [13487,13499]
testlist_comp [13487,13499]
===
match
---
atom_expr [17873,17930]
atom_expr [17873,17930]
===
match
---
trailer [22745,22747]
trailer [22745,22747]
===
match
---
suite [33158,33218]
suite [33158,33218]
===
match
---
atom [5880,5922]
atom [5880,5922]
===
match
---
suite [20713,20778]
suite [20713,20778]
===
match
---
trailer [27250,27264]
trailer [27250,27264]
===
match
---
trailer [11014,11016]
trailer [11014,11016]
===
match
---
fstring_string: __ [12991,12993]
fstring_string: __ [12991,12993]
===
match
---
name: locals [32950,32956]
name: locals [32950,32956]
===
match
---
name: custom_secret_backend [41971,41992]
name: custom_secret_backend [41949,41970]
===
match
---
operator: , [12186,12187]
operator: , [12186,12187]
===
match
---
simple_stmt [41639,41701]
simple_stmt [41617,41679]
===
match
---
argument [41666,41699]
argument [41644,41677]
===
match
---
string: '%%' [26910,26914]
string: '%%' [26910,26914]
===
match
---
name: join [43554,43558]
name: join [43532,43536]
===
match
---
string: 'TEST_CONFIG' [42640,42653]
string: 'TEST_CONFIG' [42618,42631]
===
match
---
atom [27440,27452]
atom [27440,27452]
===
match
---
name: os [44071,44073]
name: os [44049,44051]
===
match
---
operator: , [1272,1273]
operator: , [1272,1273]
===
match
---
string: 'admin' [7256,7263]
string: 'admin' [7256,7263]
===
match
---
param [15860,15868]
param [15860,15868]
===
match
---
operator: , [29500,29501]
operator: , [29500,29501]
===
match
---
return_stmt [16484,16497]
return_stmt [16484,16497]
===
match
---
name: _TEST_DAGS_FOLDER [43526,43543]
name: _TEST_DAGS_FOLDER [43504,43521]
===
match
---
suite [22195,22269]
suite [22195,22269]
===
match
---
operator: , [5224,5225]
operator: , [5224,5225]
===
match
---
string: '2.0.0' [5578,5585]
string: '2.0.0' [5578,5585]
===
match
---
operator: , [5049,5050]
operator: , [5049,5050]
===
match
---
operator: , [7218,7219]
operator: , [7218,7219]
===
match
---
operator: = [9823,9824]
operator: = [9823,9824]
===
match
---
trailer [20618,20658]
trailer [20618,20658]
===
match
---
suite [30975,31480]
suite [30975,31480]
===
match
---
comparison [9956,10004]
comparison [9956,10004]
===
match
---
name: key [14413,14416]
name: key [14413,14416]
===
match
---
trailer [22156,22173]
trailer [22156,22173]
===
match
---
trailer [8554,8571]
trailer [8554,8571]
===
match
---
operator: , [6273,6274]
operator: , [6273,6274]
===
match
---
name: self [8655,8659]
name: self [8655,8659]
===
match
---
name: key [22657,22660]
name: key [22657,22660]
===
match
---
trailer [21056,21060]
trailer [21056,21060]
===
match
---
trailer [13948,13981]
trailer [13948,13981]
===
match
---
name: section [27251,27258]
name: section [27251,27258]
===
match
---
name: self [31819,31823]
name: self [31819,31823]
===
match
---
simple_stmt [2176,2196]
simple_stmt [2176,2196]
===
match
---
name: section [19038,19045]
name: section [19038,19045]
===
match
---
suite [28105,28201]
suite [28105,28201]
===
match
---
operator: , [7879,7880]
operator: , [7879,7880]
===
match
---
name: self [21052,21056]
name: self [21052,21056]
===
match
---
operator: = [39888,39889]
operator: = [39866,39867]
===
match
---
suite [44468,44521]
suite [44462,44515]
===
match
---
operator: , [27172,27173]
operator: , [27172,27173]
===
match
---
operator: , [6494,6495]
operator: , [6494,6495]
===
match
---
arglist [2355,2439]
arglist [2355,2439]
===
match
---
comparison [13198,13219]
comparison [13198,13219]
===
match
---
name: self [23707,23711]
name: self [23707,23711]
===
match
---
operator: { [2745,2746]
operator: { [2745,2746]
===
match
---
trailer [2539,2551]
trailer [2539,2551]
===
match
---
trailer [41309,41319]
trailer [41287,41297]
===
match
---
name: option [15715,15721]
name: option [15715,15721]
===
match
---
name: default_config [33693,33707]
name: default_config [33693,33707]
===
match
---
string: 'The {old} option in [{section}] has been renamed to {new} - the old ' [30605,30675]
string: 'The {old} option in [{section}] has been renamed to {new} - the old ' [30605,30675]
===
match
---
name: self [16649,16653]
name: self [16649,16653]
===
match
---
simple_stmt [27017,27062]
simple_stmt [27017,27062]
===
match
---
name: path [43853,43857]
name: path [43831,43835]
===
match
---
name: raw [26263,26266]
name: raw [26263,26266]
===
match
---
if_stmt [18681,19016]
if_stmt [18681,19016]
===
match
---
trailer [34658,34671]
trailer [34658,34671]
===
match
---
string: 'logging' [5245,5254]
string: 'logging' [5245,5254]
===
match
---
string: 'core' [5282,5288]
string: 'core' [5282,5288]
===
match
---
operator: ** [19417,19419]
operator: ** [19417,19419]
===
match
---
operator: , [23705,23706]
operator: , [23705,23706]
===
match
---
funcdef [11964,12275]
funcdef [11964,12275]
===
match
---
name: AirflowConfigException [1322,1344]
name: AirflowConfigException [1322,1344]
===
match
---
testlist_comp [26826,26839]
testlist_comp [26826,26839]
===
match
---
name: section [16852,16859]
name: section [16852,16859]
===
match
---
fstring_end: " [23562,23563]
fstring_end: " [23562,23563]
===
match
---
simple_stmt [43827,43951]
simple_stmt [43805,43929]
===
match
---
operator: = [25753,25754]
operator: = [25753,25754]
===
match
---
string: """Historical as_dict""" [39995,40019]
string: """Historical as_dict""" [39973,39997]
===
match
---
atom_expr [2602,2764]
atom_expr [2602,2764]
===
match
---
trailer [25710,25731]
trailer [25710,25731]
===
match
---
operator: = [37796,37797]
operator: = [37774,37775]
===
match
---
simple_stmt [28909,28978]
simple_stmt [28909,28978]
===
match
---
atom_expr [15919,15965]
atom_expr [15919,15965]
===
match
---
fstring_start: f" [16214,16216]
fstring_start: f" [16214,16216]
===
match
---
name: display_source [27130,27144]
name: display_source [27130,27144]
===
match
---
trailer [15614,15664]
trailer [15614,15664]
===
match
---
name: env_var [2222,2229]
name: env_var [2222,2229]
===
match
---
trailer [43891,43899]
trailer [43869,43877]
===
match
---
name: airflow_defaults [15924,15940]
name: airflow_defaults [15924,15940]
===
match
---
trailer [16106,16114]
trailer [16106,16114]
===
match
---
name: os [43752,43754]
name: os [43730,43732]
===
match
---
name: warnings [35271,35279]
name: warnings [35271,35279]
===
match
---
operator: , [22835,22836]
operator: , [22835,22836]
===
match
---
name: display_source [27402,27416]
name: display_source [27402,27416]
===
match
---
operator: , [39868,39869]
operator: , [39846,39847]
===
match
---
param [12325,12330]
param [12325,12330]
===
match
---
expr_stmt [27434,27452]
expr_stmt [27434,27452]
===
match
---
name: stacklevel [39444,39454]
name: stacklevel [39422,39432]
===
match
---
atom_expr [43752,43786]
atom_expr [43730,43764]
===
match
---
string: 'core' [10848,10854]
string: 'core' [10848,10854]
===
match
---
argument [30934,30946]
argument [30934,30946]
===
match
---
name: deprecated_key [18421,18435]
name: deprecated_key [18421,18435]
===
match
---
atom [32923,32982]
atom [32923,32982]
===
match
---
name: fp [23291,23293]
name: fp [23291,23293]
===
match
---
name: AIRFLOW_HOME [34030,34042]
name: AIRFLOW_HOME [34030,34042]
===
match
---
name: WEBSERVER_CONFIG [36222,36238]
name: WEBSERVER_CONFIG [36222,36238]
===
match
---
trailer [13571,13579]
trailer [13571,13579]
===
match
---
name: file_name [3073,3082]
name: file_name [3073,3082]
===
match
---
funcdef [2247,2784]
funcdef [2247,2784]
===
match
---
name: os_environment [27778,27792]
name: os_environment [27778,27792]
===
match
---
operator: , [30795,30796]
operator: , [30795,30796]
===
match
---
name: sys [2482,2485]
name: sys [2482,2485]
===
match
---
name: DeprecationWarning [35299,35317]
name: DeprecationWarning [35299,35317]
===
match
---
atom_expr [33244,33277]
atom_expr [33244,33277]
===
match
---
fstring_string: ". [19361,19363]
fstring_string: ". [19361,19363]
===
match
---
atom [5162,5194]
atom [5162,5194]
===
match
---
param [1819,1826]
param [1819,1826]
===
match
---
name: key [19286,19289]
name: key [19286,19289]
===
match
---
simple_stmt [888,901]
simple_stmt [888,901]
===
match
---
name: fallback_key [14729,14741]
name: fallback_key [14729,14741]
===
match
---
string: "'conf.getint'" [38551,38566]
string: "'conf.getint'" [38529,38544]
===
match
---
atom [18755,18774]
atom [18755,18774]
===
match
---
trailer [44191,44207]
trailer [44169,44185]
===
match
---
string: 'core' [4790,4796]
string: 'core' [4790,4796]
===
match
---
atom [29598,29606]
atom [29598,29606]
===
match
---
operator: , [34609,34610]
operator: , [34609,34610]
===
match
---
name: import_string [20242,20255]
name: import_string [20242,20255]
===
match
---
operator: , [31398,31399]
operator: , [31398,31399]
===
match
---
argument [12706,12721]
argument [12706,12721]
===
match
---
comparison [18684,18709]
comparison [18684,18709]
===
match
---
trailer [27508,27519]
trailer [27508,27519]
===
match
---
atom [6354,6380]
atom [6354,6380]
===
match
---
operator: { [11794,11795]
operator: { [11794,11795]
===
match
---
trailer [12997,13003]
trailer [12997,13003]
===
match
---
atom_expr [41095,41124]
atom_expr [41073,41102]
===
match
---
operator: = [34211,34212]
operator: = [34211,34212]
===
match
---
trailer [15109,15136]
trailer [15109,15136]
===
match
---
operator: , [7191,7192]
operator: , [7191,7192]
===
match
---
name: key [41498,41501]
name: key [41476,41479]
===
match
---
name: section [18387,18394]
name: section [18387,18394]
===
match
---
suite [35254,35319]
suite [35254,35319]
===
match
---
name: read_dict [31824,31833]
name: read_dict [31824,31833]
===
match
---
atom_expr [36440,36527]
atom_expr [36440,36527]
===
match
---
operator: , [7307,7308]
operator: , [7307,7308]
===
match
---
name: self [22038,22042]
name: self [22038,22042]
===
match
---
arglist [35285,35317]
arglist [35285,35317]
===
match
---
suite [26798,26841]
suite [26798,26841]
===
match
---
trailer [34248,34268]
trailer [34248,34268]
===
match
---
operator: , [42741,42742]
operator: , [42719,42720]
===
match
---
atom_expr [41194,41222]
atom_expr [41172,41200]
===
match
---
name: val [18748,18751]
name: val [18748,18751]
===
match
---
comparison [35225,35253]
comparison [35225,35253]
===
match
---
operator: , [34062,34063]
operator: , [34062,34063]
===
match
---
arglist [43765,43785]
arglist [43743,43763]
===
match
---
name: key [16060,16063]
name: key [16060,16063]
===
match
---
name: _deprecated [42911,42922]
name: _deprecated [42889,42900]
===
match
---
atom_expr [32950,32958]
atom_expr [32950,32958]
===
match
---
trailer [27588,27600]
trailer [27588,27600]
===
match
---
trailer [31551,31563]
trailer [31551,31563]
===
match
---
name: str [12923,12926]
name: str [12923,12926]
===
match
---
name: env_var_secret_path [13742,13761]
name: env_var_secret_path [13742,13761]
===
match
---
name: super [21548,21553]
name: super [21548,21553]
===
match
---
operator: , [6022,6023]
operator: , [6022,6023]
===
match
---
name: key [18140,18143]
name: key [18140,18143]
===
match
---
expr_stmt [2222,2244]
expr_stmt [2222,2244]
===
match
---
except_clause [28034,28051]
except_clause [28034,28051]
===
match
---
trailer [3416,3430]
trailer [3416,3430]
===
match
---
name: expand_env_var [31950,31964]
name: expand_env_var [31950,31964]
===
match
---
simple_stmt [37513,37806]
simple_stmt [37491,37784]
===
match
---
string: 'statsd_datadog_tags' [6904,6925]
string: 'statsd_datadog_tags' [6904,6925]
===
match
---
trailer [29616,29622]
trailer [29616,29622]
===
match
---
string: 'sensitive_var_conn_names' [7326,7352]
string: 'sensitive_var_conn_names' [7326,7352]
===
match
---
operator: , [9890,9891]
operator: , [9890,9891]
===
match
---
atom_expr [12954,12973]
atom_expr [12954,12973]
===
match
---
simple_stmt [33313,33352]
simple_stmt [33313,33352]
===
match
---
name: env_var_cmd [13354,13365]
name: env_var_cmd [13354,13365]
===
match
---
funcdef [21197,21734]
funcdef [21197,21734]
===
match
---
name: read_dict [20668,20677]
name: read_dict [20668,20677]
===
match
---
name: pathlib [34017,34024]
name: pathlib [34017,34024]
===
match
---
operator: = [42137,42138]
operator: = [42115,42116]
===
match
---
arglist [22618,22636]
arglist [22618,22636]
===
match
---
atom [6457,6494]
atom [6457,6494]
===
match
---
name: new_value [12355,12364]
name: new_value [12355,12364]
===
match
---
return_stmt [42221,42240]
return_stmt [42199,42218]
===
match
---
if_stmt [10488,10820]
if_stmt [10488,10820]
===
match
---
atom_expr [13858,13886]
atom_expr [13858,13886]
===
match
---
argument [40335,40340]
argument [40313,40318]
===
match
---
string: 'plugins' [44098,44107]
string: 'plugins' [44076,44085]
===
match
---
except_clause [23015,23032]
except_clause [23015,23032]
===
match
---
name: config_sources [27684,27698]
name: config_sources [27684,27698]
===
match
---
atom [6237,6273]
atom [6237,6273]
===
match
---
operator: , [6546,6547]
operator: , [6546,6547]
===
match
---
name: file [34185,34189]
name: file [34185,34189]
===
match
---
string: 'webserver' [7794,7805]
string: 'webserver' [7794,7805]
===
match
---
testlist_comp [4713,4747]
testlist_comp [4713,4747]
===
match
---
string: 'encrypt_s3_logs' [5022,5039]
string: 'encrypt_s3_logs' [5022,5039]
===
match
---
param [13052,13055]
param [13052,13055]
===
match
---
simple_stmt [13689,13731]
simple_stmt [13689,13731]
===
match
---
string: "'conf.remove_option'" [39818,39840]
string: "'conf.remove_option'" [39796,39818]
===
match
---
string: "deprecated. Please access the configuration from the 'configuration.conf' object via " [37225,37312]
string: "deprecated. Please access the configuration from the 'configuration.conf' object via " [37203,37290]
===
match
---
parameters [16804,16860]
parameters [16804,16860]
===
match
---
operator: , [38212,38213]
operator: , [38190,38191]
===
match
---
trailer [34856,34861]
trailer [34856,34861]
===
match
---
if_stmt [10013,10176]
if_stmt [10013,10176]
===
match
---
name: section [20113,20120]
name: section [20113,20120]
===
match
---
param [20565,20570]
param [20565,20570]
===
match
---
name: path [3113,3117]
name: path [3113,3117]
===
match
---
testlist_comp [29599,29605]
testlist_comp [29599,29605]
===
match
---
sync_comp_for [31576,31700]
sync_comp_for [31576,31700]
===
match
---
expr_stmt [16897,16940]
expr_stmt [16897,16940]
===
match
---
param [37872,37880]
param [37850,37858]
===
match
---
name: _TEST_DAGS_FOLDER [43662,43679]
name: _TEST_DAGS_FOLDER [43640,43657]
===
match
---
name: AirflowConfigParser [29197,29216]
name: AirflowConfigParser [29197,29216]
===
match
---
atom_expr [33229,33278]
atom_expr [33229,33278]
===
match
---
trailer [17880,17884]
trailer [17880,17884]
===
match
---
atom [6987,7038]
atom [6987,7038]
===
match
---
trailer [36305,36323]
trailer [36305,36323]
===
match
---
atom [7355,7402]
atom [7355,7402]
===
match
---
operator: , [17429,17430]
operator: , [17429,17430]
===
match
---
arglist [22805,22817]
arglist [22805,22817]
===
match
---
trailer [23618,23621]
trailer [23618,23621]
===
match
---
trailer [30332,30388]
trailer [30332,30388]
===
match
---
operator: , [1778,1779]
operator: , [1778,1779]
===
match
---
simple_stmt [32987,33030]
simple_stmt [32987,33030]
===
match
---
operator: , [12262,12263]
operator: , [12262,12263]
===
match
---
operator: , [6439,6440]
operator: , [6439,6440]
===
match
---
atom_expr [2917,2944]
atom_expr [2917,2944]
===
match
---
name: conf [33666,33670]
name: conf [33666,33670]
===
match
---
string: 'true' [23078,23084]
string: 'true' [23078,23084]
===
match
---
name: self [18254,18258]
name: self [18254,18258]
===
match
---
name: section [21221,21228]
name: section [21221,21228]
===
match
---
arglist [26212,26266]
arglist [26212,26266]
===
match
---
string: 'log_processor_filename_template' [5989,6022]
string: 'log_processor_filename_template' [5989,6022]
===
match
---
name: env_var_secret_path [13689,13708]
name: env_var_secret_path [13689,13708]
===
match
---
fstring [18975,19001]
fstring [18975,19001]
===
match
---
fstring_expr [20441,20446]
fstring_expr [20441,20446]
===
match
---
name: key [26569,26572]
name: key [26569,26572]
===
match
---
simple_stmt [33167,33218]
simple_stmt [33167,33218]
===
match
---
operator: ** [39935,39937]
operator: ** [39913,39915]
===
match
---
name: FERNET_KEY [44224,44234]
name: FERNET_KEY [44202,44212]
===
match
---
operator: , [5912,5913]
operator: , [5912,5913]
===
match
---
name: env_var_cmd [13396,13407]
name: env_var_cmd [13396,13407]
===
match
---
simple_stmt [2596,2765]
simple_stmt [2596,2765]
===
match
---
fstring_end: " [11825,11826]
fstring_end: " [11825,11826]
===
match
---
arglist [27952,27959]
arglist [27952,27959]
===
match
---
return_stmt [43101,43127]
return_stmt [43079,43105]
===
match
---
simple_stmt [27977,28022]
simple_stmt [27977,28022]
===
match
---
suite [43991,44039]
suite [43969,44017]
===
match
---
suite [31746,31878]
suite [31746,31878]
===
match
---
simple_stmt [22430,22479]
simple_stmt [22430,22479]
===
match
---
trailer [40459,40464]
trailer [40437,40442]
===
match
---
argument [17921,17929]
argument [17921,17929]
===
match
---
arglist [43564,43641]
arglist [43542,43619]
===
match
---
operator: { [19285,19286]
operator: { [19285,19286]
===
match
---
string: 'ignore' [2508,2516]
string: 'ignore' [2508,2516]
===
match
---
trailer [17616,17620]
trailer [17616,17620]
===
match
---
trailer [24090,24100]
trailer [24090,24100]
===
match
---
fstring_expr [42972,42978]
fstring_expr [42950,42956]
===
match
---
name: option [21726,21732]
name: option [21726,21732]
===
match
---
name: self [19077,19081]
name: self [19077,19081]
===
match
---
name: os [32120,32122]
name: os [32120,32122]
===
match
---
string: """         Returns the section as a dict. Values are converted to int, float, bool         as required.          :param section: section from the config         :rtype: dict         """ [21836,22022]
string: """         Returns the section as a dict. Values are converted to int, float, bool         as required.          :param section: section from the config         :rtype: dict         """ [21836,22022]
===
match
---
name: _defaults [23712,23721]
name: _defaults [23712,23721]
===
match
---
name: key [15052,15055]
name: key [15052,15055]
===
match
---
name: import_string [42139,42152]
name: import_string [42117,42130]
===
match
---
funcdef [29753,30425]
funcdef [29753,30425]
===
match
---
name: conf [39053,39057]
name: conf [39031,39035]
===
match
---
fstring_expr [11761,11772]
fstring_expr [11761,11772]
===
match
---
name: opt [27595,27598]
name: opt [27595,27598]
===
match
---
testlist_comp [5454,5491]
testlist_comp [5454,5491]
===
match
---
name: get_airflow_config [32016,32034]
name: get_airflow_config [32016,32034]
===
match
---
name: warnings [40024,40032]
name: warnings [40002,40010]
===
match
---
name: self [18366,18370]
name: self [18366,18370]
===
match
---
name: encoding [20649,20657]
name: encoding [20649,20657]
===
match
---
name: new [30817,30820]
name: new [30817,30820]
===
match
---
operator: = [14069,14070]
operator: = [14069,14070]
===
match
---
expr_stmt [33666,33723]
expr_stmt [33666,33723]
===
match
---
trailer [10836,10847]
trailer [10836,10847]
===
match
---
name: key [17794,17797]
name: key [17794,17797]
===
match
---
suite [16090,16268]
suite [16090,16268]
===
match
---
operator: , [17628,17629]
operator: , [17628,17629]
===
match
---
trailer [14276,14278]
trailer [14276,14278]
===
match
---
atom [4162,4190]
atom [4162,4190]
===
match
---
simple_stmt [33222,33279]
simple_stmt [33222,33279]
===
match
---
operator: , [27128,27129]
operator: , [27128,27129]
===
match
---
string: """Get Config option values from Secret Backend""" [14427,14477]
string: """Get Config option values from Secret Backend""" [14427,14477]
===
match
---
atom [4017,4045]
atom [4017,4045]
===
match
---
operator: , [6680,6681]
operator: , [6680,6681]
===
match
---
name: _default_config_file_path [42312,42337]
name: _default_config_file_path [42290,42315]
===
match
---
testlist_comp [6206,6234]
testlist_comp [6206,6234]
===
match
---
simple_stmt [35837,35885]
simple_stmt [35837,35885]
===
match
---
operator: } [10799,10800]
operator: } [10799,10800]
===
match
---
trailer [22562,22578]
trailer [22562,22578]
===
match
---
if_stmt [17107,17235]
if_stmt [17107,17235]
===
match
---
operator: + [14505,14506]
operator: + [14505,14506]
===
match
---
atom_expr [26577,26605]
atom_expr [26577,26605]
===
match
---
name: self [9279,9283]
name: self [9279,9283]
===
match
---
name: delimiter [23525,23534]
name: delimiter [23525,23534]
===
match
---
name: template [32715,32723]
name: template [32715,32723]
===
match
---
trailer [16669,16719]
trailer [16669,16719]
===
match
---
trailer [35850,35884]
trailer [35850,35884]
===
match
---
name: _generate_fernet_key [33285,33305]
name: _generate_fernet_key [33285,33305]
===
match
---
name: _TEST_CONFIG [42454,42466]
name: _TEST_CONFIG [42432,42444]
===
match
---
simple_stmt [40426,40447]
simple_stmt [40404,40425]
===
match
---
operator: , [26656,26657]
operator: , [26656,26657]
===
match
---
atom_expr [35336,35368]
atom_expr [35336,35368]
===
match
---
name: section [14890,14897]
name: section [14890,14897]
===
match
---
name: section [15345,15352]
name: section [15345,15352]
===
match
---
operator: @ [42243,42244]
operator: @ [42221,42222]
===
match
---
operator: , [44451,44452]
operator: , [44445,44446]
===
match
---
atom_expr [7974,8036]
atom_expr [7974,8036]
===
match
---
operator: , [23289,23290]
operator: , [23289,23290]
===
match
---
if_stmt [36284,36528]
if_stmt [36284,36528]
===
match
---
name: section [14283,14290]
name: section [14283,14290]
===
match
---
trailer [19146,19151]
trailer [19146,19151]
===
match
---
trailer [25863,25900]
trailer [25863,25900]
===
match
---
trailer [43961,43968]
trailer [43939,43946]
===
match
---
simple_stmt [43526,43644]
simple_stmt [43504,43622]
===
match
---
trailer [21517,21534]
trailer [21517,21534]
===
match
---
name: kwargs [38284,38290]
name: kwargs [38262,38268]
===
match
---
string: 'cmd' [27446,27451]
string: 'cmd' [27446,27451]
===
match
---
trailer [34029,34043]
trailer [34029,34043]
===
match
---
operator: ** [40757,40759]
operator: ** [40735,40737]
===
match
---
simple_stmt [38339,38624]
simple_stmt [38317,38602]
===
match
---
simple_stmt [2021,2036]
simple_stmt [2021,2036]
===
match
---
parameters [31501,31507]
parameters [31501,31507]
===
match
---
name: Pep562 [44504,44510]
name: Pep562 [44498,44504]
===
match
---
parameters [42888,42894]
parameters [42866,42872]
===
match
---
string: 'log_processor_filename_template' [5944,5977]
string: 'log_processor_filename_template' [5944,5977]
===
match
---
name: section [12706,12713]
name: section [12706,12713]
===
match
---
trailer [43956,43961]
trailer [43934,43939]
===
match
---
operator: { [31524,31525]
operator: { [31524,31525]
===
match
---
expr_stmt [41888,41905]
expr_stmt [41866,41883]
===
match
---
name: deprecated_section [17315,17333]
name: deprecated_section [17315,17333]
===
match
---
param [19052,19060]
param [19052,19060]
===
match
---
trailer [43612,43622]
trailer [43590,43600]
===
match
---
suite [11905,11959]
suite [11905,11959]
===
match
---
simple_stmt [14759,14818]
simple_stmt [14759,14818]
===
match
---
name: filenames [20629,20638]
name: filenames [20629,20638]
===
match
---
name: section [30531,30538]
name: section [30531,30538]
===
match
---
suite [32499,32623]
suite [32499,32623]
===
match
---
name: is_validated [8719,8731]
name: is_validated [8719,8731]
===
match
---
atom [6670,6702]
atom [6670,6702]
===
match
---
name: default_section [23690,23705]
name: default_section [23690,23705]
===
match
---
name: env_var [13144,13151]
name: env_var [13144,13151]
===
match
---
operator: , [17729,17730]
operator: , [17729,17730]
===
match
---
name: deprecated_name [30502,30517]
name: deprecated_name [30502,30517]
===
match
---
name: config_sources [29291,29305]
name: config_sources [29291,29305]
===
match
---
suite [29180,29367]
suite [29180,29367]
===
match
---
string: 'is_validated' [31635,31649]
string: 'is_validated' [31635,31649]
===
match
---
operator: , [5322,5323]
operator: , [5322,5323]
===
match
---
name: val [23057,23060]
name: val [23057,23060]
===
match
---
operator: , [36412,36413]
operator: , [36412,36413]
===
match
---
expr_stmt [12846,12874]
expr_stmt [12846,12874]
===
match
---
for_stmt [32484,32623]
for_stmt [32484,32623]
===
match
---
simple_stmt [2060,2128]
simple_stmt [2060,2128]
===
match
---
string: 'airflow.cfg' [32174,32187]
string: 'airflow.cfg' [32174,32187]
===
match
---
atom [6283,6307]
atom [6283,6307]
===
match
---
name: os [13949,13951]
name: os [13949,13951]
===
match
---
name: section [9013,9020]
name: section [9013,9020]
===
match
---
operator: , [15069,15070]
operator: , [15069,15070]
===
match
---
name: ValueError [22929,22939]
name: ValueError [22929,22939]
===
match
---
trailer [12248,12274]
trailer [12248,12274]
===
match
---
name: self [15919,15923]
name: self [15919,15923]
===
match
---
simple_stmt [22764,22819]
simple_stmt [22764,22819]
===
match
---
name: setdefault [28924,28934]
name: setdefault [28924,28934]
===
match
---
operator: } [2663,2664]
operator: } [2663,2664]
===
match
---
operator: , [1140,1141]
operator: , [1140,1141]
===
match
---
testlist_comp [6671,6701]
testlist_comp [6671,6701]
===
match
---
suite [10197,10820]
suite [10197,10820]
===
match
---
string: 'of {current_value!r}. This value has been changed to {new_value!r} in the ' [12486,12562]
string: 'of {current_value!r}. This value has been changed to {new_value!r} in the ' [12486,12562]
===
match
---
string: 'default_pool_task_slot_count' [7421,7451]
string: 'default_pool_task_slot_count' [7421,7451]
===
match
---
trailer [3477,3490]
trailer [3477,3490]
===
match
---
operator: , [27512,27513]
operator: , [27512,27513]
===
match
---
name: include_secret [24046,24060]
name: include_secret [24046,24060]
===
match
---
atom_expr [22657,22677]
atom_expr [22657,22677]
===
match
---
name: section [22259,22266]
name: section [22259,22266]
===
match
---
operator: , [5987,5988]
operator: , [5987,5988]
===
match
---
suite [42895,43199]
suite [42873,43177]
===
match
---
fstring_expr [2727,2735]
fstring_expr [2727,2735]
===
match
---
name: super [17403,17408]
name: super [17403,17408]
===
match
---
name: val [23111,23114]
name: val [23111,23114]
===
match
---
arglist [35437,35720]
arglist [35437,35720]
===
match
---
return_stmt [13550,13593]
return_stmt [13550,13593]
===
match
---
name: AIRFLOW_HOME [36241,36253]
name: AIRFLOW_HOME [36241,36253]
===
match
---
string: 'stat_name_handler' [6718,6737]
string: 'stat_name_handler' [6718,6737]
===
match
---
name: self [19397,19401]
name: self [19397,19401]
===
match
---
string: 'hide_sensitive_variable_fields' [7265,7297]
string: 'hide_sensitive_variable_fields' [7265,7297]
===
match
---
name: opt [26745,26748]
name: opt [26745,26748]
===
match
---
string: 'hide_sensitive_var_conn_fields' [7220,7252]
string: 'hide_sensitive_var_conn_fields' [7220,7252]
===
match
---
name: parameterized_config [32694,32714]
name: parameterized_config [32694,32714]
===
match
---
operator: , [42841,42842]
operator: , [42819,42820]
===
match
---
operator: * [40750,40751]
operator: * [40728,40729]
===
match
---
atom [6796,6844]
atom [6796,6844]
===
match
---
operator: , [20802,20803]
operator: , [20802,20803]
===
match
---
string: "modified_time" [11507,11522]
string: "modified_time" [11507,11522]
===
match
---
trailer [22403,22409]
trailer [22403,22409]
===
match
---
comparison [41048,41078]
comparison [41026,41056]
===
match
---
operator: , [6344,6345]
operator: , [6344,6345]
===
match
---
expr_stmt [43384,43433]
expr_stmt [43362,43411]
===
match
---
trailer [40334,40351]
trailer [40312,40329]
===
match
---
operator: { [7707,7708]
operator: { [7707,7708]
===
match
---
operator: , [6629,6630]
operator: , [6629,6630]
===
match
---
import_as_names [1134,1185]
import_as_names [1134,1185]
===
match
---
import_name [919,929]
import_name [919,929]
===
match
---
dictorsetmaker [42601,42868]
dictorsetmaker [42579,42846]
===
match
---
string: "scheduler" [11435,11446]
string: "scheduler" [11435,11446]
===
match
---
import_as_names [1262,1289]
import_as_names [1262,1289]
===
match
---
trailer [31964,32009]
trailer [31964,32009]
===
match
---
trailer [17884,17930]
trailer [17884,17930]
===
match
---
if_stmt [27399,27520]
if_stmt [27399,27520]
===
match
---
trailer [43661,43680]
trailer [43639,43658]
===
match
---
operator: = [7687,7688]
operator: = [7687,7688]
===
match
---
return_stmt [17587,17645]
return_stmt [17587,17645]
===
match
---
trailer [20727,20729]
trailer [20727,20729]
===
match
---
suite [22528,22819]
suite [22528,22819]
===
match
---
name: default_config_yaml [3226,3245]
name: default_config_yaml [3226,3245]
===
match
---
trailer [36446,36451]
trailer [36446,36451]
===
match
---
trailer [32149,32154]
trailer [32149,32154]
===
match
---
trailer [8512,8514]
trailer [8512,8514]
===
match
---
operator: , [23293,23294]
operator: , [23293,23294]
===
match
---
operator: = [35864,35865]
operator: = [35864,35865]
===
match
---
name: path [3126,3130]
name: path [3126,3130]
===
match
---
name: kwargs [20141,20147]
name: kwargs [20141,20147]
===
match
---
string: """Historical getint""" [38311,38334]
string: """Historical getint""" [38289,38312]
===
match
---
string: """Get path to unittests.cfg""" [33079,33110]
string: """Get path to unittests.cfg""" [33079,33110]
===
match
---
trailer [21702,21716]
trailer [21702,21716]
===
match
---
arglist [39491,39506]
arglist [39469,39484]
===
match
---
trailer [33370,33383]
trailer [33370,33383]
===
match
---
name: cryptography [33873,33885]
name: cryptography [33873,33885]
===
match
---
name: info [34792,34796]
name: info [34792,34796]
===
match
---
name: stderr [2458,2464]
name: stderr [2458,2464]
===
match
---
string: 'core' [5624,5630]
string: 'core' [5624,5630]
===
match
---
operator: = [1512,1513]
operator: = [1512,1513]
===
match
---
param [16847,16851]
param [16847,16851]
===
match
---
atom [7925,8157]
atom [7925,8157]
===
match
---
testlist_comp [29102,29121]
testlist_comp [29102,29121]
===
match
---
name: kwargs [17637,17643]
name: kwargs [17637,17643]
===
match
---
atom_expr [22152,22194]
atom_expr [22152,22194]
===
match
---
name: __init__ [31760,31768]
name: __init__ [31760,31768]
===
match
---
name: write [34290,34295]
name: write [34290,34295]
===
match
---
arglist [14653,14674]
arglist [14653,14674]
===
match
---
operator: , [31649,31650]
operator: , [31649,31650]
===
match
---
name: output [2450,2456]
name: output [2450,2456]
===
match
---
operator: , [8950,8951]
operator: , [8950,8951]
===
match
---
name: DeprecationWarning [35865,35883]
name: DeprecationWarning [35865,35883]
===
match
---
expr_stmt [41283,41353]
expr_stmt [41261,41331]
===
match
---
trailer [10504,10528]
trailer [10504,10528]
===
match
---
suite [41580,41630]
suite [41558,41608]
===
match
---
name: dirname [43588,43595]
name: dirname [43566,43573]
===
match
---
operator: , [35719,35720]
operator: , [35719,35720]
===
match
---
fstring_expr [19654,19659]
fstring_expr [19654,19659]
===
match
---
operator: } [32684,32685]
operator: } [32684,32685]
===
match
---
atom_expr [42193,42214]
atom_expr [42171,42192]
===
match
---
trailer [10741,10799]
trailer [10741,10799]
===
match
---
operator: = [22304,22305]
operator: = [22304,22305]
===
match
---
dotted_name [1207,1219]
dotted_name [1207,1219]
===
match
---
operator: + [13719,13720]
operator: + [13719,13720]
===
match
---
string: 'f' [18756,18759]
string: 'f' [18756,18759]
===
match
---
comparison [2563,2586]
comparison [2563,2586]
===
match
---
string: 'secret_key' [4280,4292]
string: 'secret_key' [4280,4292]
===
match
---
string: 'core' [5119,5125]
string: 'core' [5119,5125]
===
match
---
param [27146,27149]
param [27146,27149]
===
match
---
trailer [18130,18144]
trailer [18130,18144]
===
match
---
name: self [9618,9622]
name: self [9618,9622]
===
match
---
sync_comp_for [27793,27875]
sync_comp_for [27793,27875]
===
match
---
operator: , [39933,39934]
operator: , [39911,39912]
===
match
---
fstring_string: " section.  [19678,19689]
fstring_string: " section.  [19678,19689]
===
match
---
name: log [16103,16106]
name: log [16103,16106]
===
match
---
atom_expr [11284,11315]
atom_expr [11284,11315]
===
match
---
simple_stmt [17029,17095]
simple_stmt [17029,17095]
===
match
---
param [23993,24010]
param [23993,24010]
===
match
---
atom [25817,25838]
atom [25817,25838]
===
match
---
expr_stmt [26745,26763]
expr_stmt [26745,26763]
===
match
---
name: section [20121,20128]
name: section [20121,20128]
===
match
---
testlist_comp [25818,25837]
testlist_comp [25818,25837]
===
match
---
suite [33308,33395]
suite [33308,33395]
===
match
---
suite [33774,34334]
suite [33774,34334]
===
match
---
simple_stmt [10954,11017]
simple_stmt [10954,11017]
===
match
---
suite [3447,3491]
suite [3447,3491]
===
match
---
operator: = [9231,9232]
operator: = [9231,9232]
===
match
---
name: lower [28502,28507]
name: lower [28502,28507]
===
match
---
operator: , [4796,4797]
operator: , [4796,4797]
===
match
---
subscriptlist [21802,21823]
subscriptlist [21802,21823]
===
match
---
trailer [39927,39944]
trailer [39905,39922]
===
match
---
name: open [42536,42540]
name: open [42514,42518]
===
match
---
operator: * [37833,37834]
operator: * [37811,37812]
===
match
---
string: 'scheduler' [6383,6394]
string: 'scheduler' [6383,6394]
===
match
---
name: val [18624,18627]
name: val [18624,18627]
===
match
---
expr_stmt [27977,28021]
expr_stmt [27977,28021]
===
match
---
global_stmt [36194,36217]
global_stmt [36194,36217]
===
match
---
name: decoder [1212,1219]
name: decoder [1212,1219]
===
match
---
name: kwargs [40759,40765]
name: kwargs [40737,40743]
===
match
---
return_stmt [18723,18734]
return_stmt [18723,18734]
===
match
---
name: key [20442,20445]
name: key [20442,20445]
===
match
---
name: version [12781,12788]
name: version [12781,12788]
===
match
---
argument [39069,39074]
argument [39047,39052]
===
match
---
if_stmt [18327,18467]
if_stmt [18327,18467]
===
match
---
name: mp_start_method [10888,10903]
name: mp_start_method [10888,10903]
===
match
---
name: config [29610,29616]
name: config [29610,29616]
===
match
---
name: environ [13258,13265]
name: environ [13258,13265]
===
match
---
param [38688,38696]
param [38666,38674]
===
match
---
operator: = [2465,2466]
operator: = [2465,2466]
===
match
---
name: key [19460,19463]
name: key [19460,19463]
===
match
---
operator: = [20133,20134]
operator: = [20133,20134]
===
match
---
arglist [23681,23740]
arglist [23681,23740]
===
match
---
atom [7317,7353]
atom [7317,7353]
===
match
---
param [19782,19786]
param [19782,19786]
===
match
---
atom [42743,42763]
atom [42721,42741]
===
match
---
trailer [26988,27000]
trailer [26988,27000]
===
match
---
for_stmt [29097,29367]
for_stmt [29097,29367]
===
match
---
name: PendingDeprecationWarning [1753,1778]
name: PendingDeprecationWarning [1753,1778]
===
match
---
name: kwargs [39500,39506]
name: kwargs [39478,39484]
===
match
---
strings [38362,38566]
strings [38340,38544]
===
match
---
arith_expr [27045,27060]
arith_expr [27045,27060]
===
match
---
simple_stmt [32627,32688]
simple_stmt [32627,32688]
===
match
---
expr_stmt [10446,10475]
expr_stmt [10446,10475]
===
match
---
expr_stmt [13689,13730]
expr_stmt [13689,13730]
===
match
---
name: self [9004,9008]
name: self [9004,9008]
===
match
---
trailer [23797,23812]
trailer [23797,23812]
===
match
---
trailer [34571,34576]
trailer [34571,34576]
===
match
---
string: 'core' [10153,10159]
string: 'core' [10153,10159]
===
match
---
name: file_name [3209,3218]
name: file_name [3209,3218]
===
match
---
operator: { [10143,10144]
operator: { [10143,10144]
===
match
---
name: os [3123,3125]
name: os [3123,3125]
===
match
---
if_stmt [27277,27314]
if_stmt [27277,27314]
===
match
---
arglist [36052,36076]
arglist [36052,36076]
===
match
---
name: pathlib [34564,34571]
name: pathlib [34564,34571]
===
match
---
param [12918,12926]
param [12918,12926]
===
match
---
atom_expr [2682,2700]
atom_expr [2682,2700]
===
match
---
operator: = [43079,43080]
operator: = [43057,43058]
===
match
---
simple_stmt [12944,13008]
simple_stmt [12944,13008]
===
match
---
name: sections [29169,29177]
name: sections [29169,29177]
===
match
---
operator: , [31994,31995]
operator: , [31994,31995]
===
match
---
comparison [15676,15694]
comparison [15676,15694]
===
match
---
name: val [18647,18650]
name: val [18647,18650]
===
match
---
argument [39935,39943]
argument [39913,39921]
===
match
---
testlist_comp [18756,18773]
testlist_comp [18756,18773]
===
match
---
name: name [42903,42907]
name: name [42881,42885]
===
match
---
operator: , [12364,12365]
operator: , [12364,12365]
===
match
---
trailer [12392,12397]
trailer [12392,12397]
===
match
---
argument [36993,37005]
argument [36971,36983]
===
match
---
operator: = [2407,2408]
operator: = [2407,2408]
===
match
---
return_stmt [31943,32009]
return_stmt [31943,32009]
===
match
---
name: join [43760,43764]
name: join [43738,43742]
===
match
---
name: os [2075,2077]
name: os [2075,2077]
===
match
---
atom [6583,6615]
atom [6583,6615]
===
match
---
name: super [14708,14713]
name: super [14708,14713]
===
match
---
trailer [19446,19450]
trailer [19446,19450]
===
match
---
trailer [2570,2581]
trailer [2570,2581]
===
match
---
funcdef [2786,3041]
funcdef [2786,3041]
===
match
---
trailer [21790,21825]
trailer [21790,21825]
===
match
---
atom_expr [44130,44167]
atom_expr [44108,44145]
===
match
---
operator: , [43937,43938]
operator: , [43915,43916]
===
match
---
name: section [9375,9382]
name: section [9375,9382]
===
match
---
argument [9238,9257]
argument [9238,9257]
===
match
---
operator: = [1639,1640]
operator: = [1639,1640]
===
match
---
operator: , [23166,23167]
operator: , [23166,23167]
===
match
---
string: 'false' [23168,23175]
string: 'false' [23168,23175]
===
match
---
simple_stmt [22895,22910]
simple_stmt [22895,22910]
===
match
---
simple_stmt [16972,16986]
simple_stmt [16972,16986]
===
match
---
import_from [44473,44498]
import_from [44467,44492]
===
match
---
simple_stmt [1421,1452]
simple_stmt [1421,1452]
===
match
---
string: '2.0.0' [5484,5491]
string: '2.0.0' [5484,5491]
===
match
---
operator: ** [19052,19054]
operator: ** [19052,19054]
===
match
---
name: AirflowConfigException [19197,19219]
name: AirflowConfigException [19197,19219]
===
match
---
trailer [11434,11473]
trailer [11434,11473]
===
match
---
simple_stmt [30324,30389]
simple_stmt [30324,30389]
===
match
---
arglist [32160,32187]
arglist [32160,32187]
===
match
---
expr_stmt [42117,42164]
expr_stmt [42095,42142]
===
match
---
trailer [11430,11434]
trailer [11430,11434]
===
match
---
operator: , [21817,21818]
operator: , [21817,21818]
===
match
---
trailer [34791,34796]
trailer [34791,34796]
===
match
---
testlist_comp [5788,5831]
testlist_comp [5788,5831]
===
match
---
trailer [3467,3477]
trailer [3467,3477]
===
match
---
string: "'conf.set'" [40660,40672]
string: "'conf.set'" [40638,40650]
===
match
---
name: get [15025,15028]
name: get [15025,15028]
===
match
---
trailer [44510,44520]
trailer [44504,44514]
===
match
---
fstring [19237,19321]
fstring [19237,19321]
===
match
---
atom_expr [43401,43433]
atom_expr [43379,43411]
===
match
---
name: name [12700,12704]
name: name [12700,12704]
===
match
---
name: source_name [29337,29348]
name: source_name [29337,29348]
===
match
---
simple_stmt [44340,44367]
simple_stmt [44318,44345]
===
match
---
name: section_prefix [22563,22577]
name: section_prefix [22563,22577]
===
match
---
name: os [33822,33824]
name: os [33822,33824]
===
match
---
with_item [42536,42552]
with_item [42514,42530]
===
match
---
atom_expr [23685,23705]
atom_expr [23685,23705]
===
match
---
operator: , [23931,23932]
operator: , [23931,23932]
===
match
---
name: environ [35246,35253]
name: environ [35246,35253]
===
match
---
operator: , [7402,7403]
operator: , [7402,7403]
===
match
---
operator: , [40755,40756]
operator: , [40733,40734]
===
match
---
trailer [11361,11400]
trailer [11361,11400]
===
match
---
fstring_string: . Possible values are  [11772,11794]
fstring_string: . Possible values are  [11772,11794]
===
match
---
comparison [10491,10564]
comparison [10491,10564]
===
match
---
if_stmt [32512,32564]
if_stmt [32512,32564]
===
match
---
name: warnings [12384,12392]
name: warnings [12384,12392]
===
match
---
name: deprecated_section [16997,17015]
name: deprecated_section [16997,17015]
===
match
---
name: key [22699,22702]
name: key [22699,22702]
===
match
---
name: self [25859,25863]
name: self [25859,25863]
===
match
---
number: 4 [22711,22712]
number: 4 [22711,22712]
===
match
---
name: stacklevel [37371,37381]
name: stacklevel [37349,37359]
===
match
---
operator: } [20464,20465]
operator: } [20464,20465]
===
match
---
trailer [29168,29177]
trailer [29168,29177]
===
match
---
name: opt [26826,26829]
name: opt [26826,26829]
===
match
---
expr_stmt [28484,28509]
expr_stmt [28484,28509]
===
match
---
name: _TEST_PLUGINS_FOLDER [43827,43847]
name: _TEST_PLUGINS_FOLDER [43805,43825]
===
match
---
name: key [28885,28888]
name: key [28885,28888]
===
match
---
argument [1726,1742]
argument [1726,1742]
===
match
---
operator: = [34947,34948]
operator: = [34947,34948]
===
match
---
operator: = [23535,23536]
operator: = [23535,23536]
===
match
---
trailer [26581,26605]
trailer [26581,26605]
===
match
---
atom [5042,5078]
atom [5042,5078]
===
match
---
trailer [22609,22617]
trailer [22609,22617]
===
match
---
trailer [38347,38352]
trailer [38325,38330]
===
match
---
parameters [1818,1827]
parameters [1818,1827]
===
match
---
operator: , [4928,4929]
operator: , [4928,4929]
===
match
---
trailer [30406,30424]
trailer [30406,30424]
===
match
---
string: "deprecated. Please access the configuration from the 'configuration.conf' object via " [40564,40651]
string: "deprecated. Please access the configuration from the 'configuration.conf' object via " [40542,40629]
===
match
---
if_stmt [15916,16268]
if_stmt [15916,16268]
===
match
---
trailer [39179,39184]
trailer [39157,39162]
===
match
---
name: ValueError [19167,19177]
name: ValueError [19167,19177]
===
match
---
operator: = [20648,20649]
operator: = [20648,20649]
===
match
---
trailer [2101,2112]
trailer [2101,2112]
===
match
---
operator: , [3207,3208]
operator: , [3207,3208]
===
match
---
trailer [12164,12178]
trailer [12164,12178]
===
match
---
name: deprecated_key [16308,16322]
name: deprecated_key [16308,16322]
===
match
---
operator: { [4007,4008]
operator: { [4007,4008]
===
match
---
simple_stmt [13550,13594]
simple_stmt [13550,13594]
===
match
---
string: 'remote_log_conn_id' [4878,4898]
string: 'remote_log_conn_id' [4878,4898]
===
match
---
name: utils [10307,10312]
name: utils [10307,10312]
===
match
---
trailer [16573,16609]
trailer [16573,16609]
===
match
---
except_clause [22922,22939]
except_clause [22922,22939]
===
match
---
string: 'result_backend' [4173,4189]
string: 'result_backend' [4173,4189]
===
match
---
atom_expr [37017,37040]
atom_expr [36995,37018]
===
match
---
expr_stmt [42581,42870]
expr_stmt [42559,42848]
===
match
---
operator: , [19036,19037]
operator: , [19036,19037]
===
match
---
atom_expr [19508,19518]
atom_expr [19508,19518]
===
match
---
arglist [36731,37006]
arglist [36709,36984]
===
match
---
operator: , [2423,2424]
operator: , [2423,2424]
===
match
---
trailer [37832,37849]
trailer [37810,37827]
===
match
---
atom_expr [11639,11844]
atom_expr [11639,11844]
===
match
---
if_stmt [32093,32189]
if_stmt [32093,32189]
===
match
---
string: 'core' [4713,4719]
string: 'core' [4713,4719]
===
match
---
strings [2638,2754]
strings [2638,2754]
===
match
---
name: option [15237,15243]
name: option [15237,15243]
===
match
---
name: option [18330,18336]
name: option [18330,18336]
===
match
---
string: '' [44237,44239]
string: '' [44215,44217]
===
match
---
name: __getattr__ [42877,42888]
name: __getattr__ [42855,42866]
===
match
---
simple_stmt [919,930]
simple_stmt [919,930]
===
match
---
string: '2.0.0' [6927,6934]
string: '2.0.0' [6927,6934]
===
match
---
atom_expr [8910,8929]
atom_expr [8910,8929]
===
match
---
operator: = [9470,9471]
operator: = [9470,9471]
===
match
---
operator: , [6321,6322]
operator: , [6321,6322]
===
match
---
name: str [25726,25729]
name: str [25726,25729]
===
match
---
number: 2 [39033,39034]
number: 2 [39011,39012]
===
match
---
if_stmt [16622,16750]
if_stmt [16622,16750]
===
match
---
name: section [41479,41486]
name: section [41457,41464]
===
match
---
trailer [21785,21826]
trailer [21785,21826]
===
match
---
arglist [42816,42866]
arglist [42794,42844]
===
match
---
atom [27164,27178]
atom [27164,27178]
===
match
---
atom_expr [34388,34418]
atom_expr [34388,34418]
===
match
---
name: AIRFLOW_HOME [33567,33579]
name: AIRFLOW_HOME [33567,33579]
===
match
---
expr_stmt [14890,14920]
expr_stmt [14890,14920]
===
match
---
suite [23033,23214]
suite [23033,23214]
===
match
---
name: args [37052,37056]
name: args [37030,37034]
===
match
---
trailer [17620,17644]
trailer [17620,17644]
===
match
---
operator: , [18695,18696]
operator: , [18695,18696]
===
match
---
trailer [22173,22185]
trailer [22173,22185]
===
match
---
atom_expr [19197,19378]
atom_expr [19197,19378]
===
match
---
name: OrderedDict [26967,26978]
name: OrderedDict [26967,26978]
===
match
---
trailer [43419,43433]
trailer [43397,43411]
===
match
---
operator: = [12699,12700]
operator: = [12699,12700]
===
match
---
name: get [17617,17620]
name: get [17617,17620]
===
match
---
operator: , [19785,19786]
operator: , [19785,19786]
===
match
---
string: 'sensitive_variable_fields' [7365,7392]
string: 'sensitive_variable_fields' [7365,7392]
===
match
---
operator: , [8385,8386]
operator: , [8385,8386]
===
match
---
trailer [15433,15459]
trailer [15433,15459]
===
match
---
trailer [43579,43624]
trailer [43557,43602]
===
match
---
name: _UNSET [21087,21093]
name: _UNSET [21087,21093]
===
match
---
trailer [28934,28958]
trailer [28934,28958]
===
match
---
name: split [2361,2366]
name: split [2361,2366]
===
match
---
name: is_validated [9559,9571]
name: is_validated [9559,9571]
===
match
---
raise_stmt [16185,16267]
raise_stmt [16185,16267]
===
match
---
string: 'colored_formatter_class' [5514,5539]
string: 'colored_formatter_class' [5514,5539]
===
match
---
fstring_string: See  [10724,10728]
fstring_string: See  [10724,10728]
===
match
---
number: 0 [23558,23559]
number: 0 [23558,23559]
===
match
---
name: _update_env_var [9194,9209]
name: _update_env_var [9194,9209]
===
match
---
name: option [16979,16985]
name: option [16979,16985]
===
match
---
name: deprecated_options [15006,15024]
name: deprecated_options [15006,15024]
===
match
---
arglist [34797,34841]
arglist [34797,34841]
===
match
---
suite [17676,17932]
suite [17676,17932]
===
match
---
name: maxsize [42436,42443]
name: maxsize [42414,42421]
===
match
---
operator: , [23858,23859]
operator: , [23858,23859]
===
match
---
fstring_start: f' [19338,19340]
fstring_start: f' [19338,19340]
===
match
---
import_name [930,945]
import_name [930,945]
===
match
---
name: option [18245,18251]
name: option [18245,18251]
===
match
---
simple_stmt [34092,34136]
simple_stmt [34092,34136]
===
match
---
name: secrets_client [3003,3017]
name: secrets_client [3003,3017]
===
match
---
name: AIRFLOW_CONFIG [43384,43398]
name: AIRFLOW_CONFIG [43362,43376]
===
match
---
atom [26989,26999]
atom [26989,26999]
===
match
---
expr_stmt [35773,35820]
expr_stmt [35773,35820]
===
match
---
name: utils [1434,1439]
name: utils [1434,1439]
===
match
---
trailer [18278,18314]
trailer [18278,18314]
===
match
---
operator: , [29113,29114]
operator: , [29113,29114]
===
match
---
atom_expr [34017,34078]
atom_expr [34017,34078]
===
match
---
string: 'logging' [4759,4768]
string: 'logging' [4759,4768]
===
match
---
comparison [13486,13532]
comparison [13486,13532]
===
match
---
name: section [21570,21577]
name: section [21570,21577]
===
match
---
name: list_mode [11414,11423]
name: list_mode [11414,11423]
===
match
---
atom_expr [22988,22998]
atom_expr [22988,22998]
===
match
---
fstring_string: . Error code is:  [2664,2681]
fstring_string: . Error code is:  [2664,2681]
===
match
---
suite [27417,27453]
suite [27417,27453]
===
match
---
trailer [33383,33385]
trailer [33383,33385]
===
match
---
string: 'task_log_prefix_template' [5758,5784]
string: 'task_log_prefix_template' [5758,5784]
===
match
---
name: section [26560,26567]
name: section [26560,26567]
===
match
---
operator: ** [18579,18581]
operator: ** [18579,18581]
===
match
---
fstring_string:  is deprecated and will be removed in future [42978,43022]
fstring_string:  is deprecated and will be removed in future [42956,43000]
===
match
---
arglist [15460,15508]
arglist [15460,15508]
===
match
---
parameters [16301,16357]
parameters [16301,16357]
===
match
---
name: old_key [31282,31289]
name: old_key [31282,31289]
===
match
---
string: 'colored_console_log' [5344,5365]
string: 'colored_console_log' [5344,5365]
===
match
---
funcdef [20783,21192]
funcdef [20783,21192]
===
match
---
param [14404,14412]
param [14404,14412]
===
match
---
expr_stmt [27224,27264]
expr_stmt [27224,27264]
===
match
---
trailer [27557,27581]
trailer [27557,27581]
===
match
---
operator: , [6767,6768]
operator: , [6767,6768]
===
match
---
name: config [31779,31785]
name: config [31779,31785]
===
match
---
strings [38772,38984]
strings [38750,38962]
===
match
---
operator: = [27438,27439]
operator: = [27438,27439]
===
match
---
operator: , [39108,39109]
operator: , [39086,39087]
===
match
---
arglist [17422,17434]
arglist [17422,17434]
===
match
---
fstring_string: Failed to convert value to float. Please check " [19606,19654]
fstring_string: Failed to convert value to float. Please check " [19606,19654]
===
match
---
name: kwargs [37874,37880]
name: kwargs [37852,37858]
===
match
---
trailer [2096,2101]
trailer [2096,2101]
===
match
---
if_stmt [11578,11845]
if_stmt [11578,11845]
===
match
---
operator: , [26488,26489]
operator: , [26488,26489]
===
match
---
argument [37833,37838]
argument [37811,37816]
===
match
---
return_stmt [3456,3490]
return_stmt [3456,3490]
===
match
---
funcdef [1800,2245]
funcdef [1800,2245]
===
match
---
trailer [28507,28509]
trailer [28507,28509]
===
match
---
fstring_end: " [10800,10801]
fstring_end: " [10800,10801]
===
match
---
name: section [22055,22062]
name: section [22055,22062]
===
match
---
name: path [34391,34395]
name: path [34391,34395]
===
match
---
string: 'base_log_folder' [4721,4738]
string: 'base_log_folder' [4721,4738]
===
match
---
name: self [26350,26354]
name: self [26350,26354]
===
match
---
name: warn [30997,31001]
name: warn [30997,31001]
===
match
---
name: super [8507,8512]
name: super [8507,8512]
===
match
---
atom_expr [40800,40824]
atom_expr [40778,40802]
===
match
---
atom_expr [15429,15509]
atom_expr [15429,15509]
===
match
---
comp_op [15528,15534]
comp_op [15528,15534]
===
match
---
return_stmt [33167,33217]
return_stmt [33167,33217]
===
match
---
atom [41627,41629]
atom [41605,41607]
===
match
---
atom [5746,5785]
atom [5746,5785]
===
match
---
operator: , [12704,12705]
operator: , [12704,12705]
===
match
---
name: version [8957,8964]
name: version [8957,8964]
===
match
---
name: key [15496,15499]
name: key [15496,15499]
===
match
---
name: self [14027,14031]
name: self [14027,14031]
===
match
---
operator: } [32981,32982]
operator: } [32981,32982]
===
match
---
trailer [43899,43927]
trailer [43877,43905]
===
match
---
trailer [41478,41534]
trailer [41456,41512]
===
match
---
atom_expr [2329,2445]
atom_expr [2329,2445]
===
match
---
trailer [10992,11014]
trailer [10992,11014]
===
match
---
name: args [38682,38686]
name: args [38660,38664]
===
match
---
name: key [14866,14869]
name: key [14866,14869]
===
match
---
operator: ** [37840,37842]
operator: ** [37818,37820]
===
match
---
not_test [33818,33854]
not_test [33818,33854]
===
match
---
name: env_var [12150,12157]
name: env_var [12150,12157]
===
match
---
operator: , [34534,34535]
operator: , [34534,34535]
===
match
---
trailer [26354,26371]
trailer [26354,26371]
===
match
---
operator: , [18525,18526]
operator: , [18525,18526]
===
match
---
simple_stmt [32054,32089]
simple_stmt [32054,32089]
===
match
---
fstring [11759,11826]
fstring [11759,11826]
===
match
---
operator: = [44388,44389]
operator: = [44366,44367]
===
match
---
name: __name__ [43163,43171]
name: __name__ [43141,43149]
===
match
---
parameters [41188,41190]
parameters [41166,41168]
===
match
---
testlist_comp [32939,32958]
testlist_comp [32939,32958]
===
match
---
trailer [1531,1541]
trailer [1531,1541]
===
match
---
operator: * [40362,40363]
operator: * [40340,40341]
===
match
---
name: conf [36533,36537]
name: conf [44398,44402]
===
match
---
string: 'core' [28272,28278]
string: 'core' [28272,28278]
===
match
---
string: ', ' [11795,11799]
string: ', ' [11795,11799]
===
match
---
string: 'scheduler' [6797,6808]
string: 'scheduler' [6797,6808]
===
match
---
parameters [40361,40378]
parameters [40339,40356]
===
match
---
name: stacklevel [40710,40720]
name: stacklevel [40688,40698]
===
match
---
string: '2.0.0' [4662,4669]
string: '2.0.0' [4662,4669]
===
match
---
operator: { [10728,10729]
operator: { [10728,10729]
===
match
---
operator: , [29081,29082]
operator: , [29081,29082]
===
match
---
exprlist [32964,32968]
exprlist [32964,32968]
===
match
---
name: include_cmds [24019,24031]
name: include_cmds [24019,24031]
===
match
---
for_stmt [26555,27062]
for_stmt [26555,27062]
===
match
---
testlist_comp [15059,15075]
testlist_comp [15059,15075]
===
match
---
trailer [18589,18595]
trailer [18589,18595]
===
match
---
string: 'core' [7212,7218]
string: 'core' [7212,7218]
===
match
---
arglist [26372,26426]
arglist [26372,26426]
===
match
---
parameters [32034,32048]
parameters [32034,32048]
===
match
---
name: as_dict [23880,23887]
name: as_dict [23880,23887]
===
match
---
name: __file__ [3139,3147]
name: __file__ [3139,3147]
===
match
---
atom [4121,4152]
atom [4121,4152]
===
match
---
param [39110,39118]
param [39088,39096]
===
match
---
operator: , [27258,27259]
operator: , [27258,27259]
===
match
---
atom_expr [32413,32448]
atom_expr [32413,32448]
===
match
---
operator: = [41303,41304]
operator: = [41281,41282]
===
match
---
simple_stmt [37810,37850]
simple_stmt [37788,37828]
===
match
---
name: new_value [9125,9134]
name: new_value [9125,9134]
===
match
---
fstring_expr [12993,13006]
fstring_expr [12993,13006]
===
match
---
name: kwargs [37060,37066]
name: kwargs [37038,37044]
===
match
---
testlist_comp [4835,4866]
testlist_comp [4835,4866]
===
match
---
atom [5980,6032]
atom [5980,6032]
===
match
---
name: sorted [22502,22508]
name: sorted [22502,22508]
===
match
---
arglist [37833,37848]
arglist [37811,37826]
===
match
---
parameters [42466,42468]
parameters [42444,42446]
===
match
---
suite [2971,2992]
suite [2971,2992]
===
match
---
operator: , [27444,27445]
operator: , [27444,27445]
===
match
---
name: new_value [9248,9257]
name: new_value [9248,9257]
===
match
---
name: deprecated_section [18279,18297]
name: deprecated_section [18279,18297]
===
match
---
name: self [30195,30199]
name: self [30195,30199]
===
match
---
name: key [19655,19658]
name: key [19655,19658]
===
match
---
simple_stmt [15731,15799]
simple_stmt [15731,15799]
===
match
---
operator: , [26567,26568]
operator: , [26567,26568]
===
match
---
parameters [20564,20596]
parameters [20564,20596]
===
match
---
trailer [30211,30268]
trailer [30211,30268]
===
match
---
operator: , [4814,4815]
operator: , [4814,4815]
===
match
---
expr_stmt [44224,44239]
expr_stmt [44202,44217]
===
match
---
if_stmt [13739,13982]
if_stmt [13739,13982]
===
match
---
name: display_sensitive [26506,26523]
name: display_sensitive [26506,26523]
===
match
---
name: self [13858,13862]
name: self [13858,13862]
===
match
---
parameters [37444,37461]
parameters [37422,37439]
===
match
---
operator: , [5705,5706]
operator: , [5705,5706]
===
match
---
fstring_end: " [10173,10174]
fstring_end: " [10173,10174]
===
match
---
trailer [22398,22419]
trailer [22398,22419]
===
match
---
param [11882,11895]
param [11882,11895]
===
match
---
string: 'non_pooled_task_slot_count' [7463,7491]
string: 'non_pooled_task_slot_count' [7463,7491]
===
match
---
string: 'atlas' [4201,4208]
string: 'atlas' [4201,4208]
===
match
---
name: deprecated_name [31290,31305]
name: deprecated_name [31290,31305]
===
match
---
trailer [29216,29261]
trailer [29216,29261]
===
match
---
return_stmt [39902,39944]
return_stmt [39880,39922]
===
match
---
name: self [14589,14593]
name: self [14589,14593]
===
match
---
fstring_string: / [16238,16239]
fstring_string: / [16238,16239]
===
match
---
return_stmt [18788,18800]
return_stmt [18788,18800]
===
match
---
param [27678,27683]
param [27678,27683]
===
match
---
atom [28454,28470]
atom [28454,28470]
===
match
---
argument [33010,33020]
argument [33010,33020]
===
match
---
param [26484,26489]
param [26484,26489]
===
match
---
name: load_test_config [29757,29773]
name: load_test_config [29757,29773]
===
match
---
testlist_comp [4267,4292]
testlist_comp [4267,4292]
===
match
---
expr_stmt [15096,15186]
expr_stmt [15096,15186]
===
match
---
trailer [16554,16573]
trailer [16554,16573]
===
match
---
parameters [2262,2271]
parameters [2262,2271]
===
match
---
arglist [25901,25945]
arglist [25901,25945]
===
match
---
arglist [9144,9167]
arglist [9144,9167]
===
match
---
name: run_command [14329,14340]
name: run_command [14329,14340]
===
match
---
string: 'flower_basic_auth' [4132,4151]
string: 'flower_basic_auth' [4132,4151]
===
match
---
suite [28298,28334]
suite [28298,28334]
===
match
---
string: 'default' [1640,1649]
string: 'default' [1640,1649]
===
match
---
name: config_sources [25901,25915]
name: config_sources [25901,25915]
===
match
---
trailer [27631,27640]
trailer [27631,27640]
===
match
---
atom_expr [18833,19015]
atom_expr [18833,19015]
===
match
---
name: path [42541,42545]
name: path [42519,42523]
===
match
---
operator: , [6394,6395]
operator: , [6394,6395]
===
match
---
name: args [8525,8529]
name: args [8525,8529]
===
match
---
testlist_comp [6284,6306]
testlist_comp [6284,6306]
===
match
---
trailer [1725,1797]
trailer [1725,1797]
===
match
---
for_stmt [27160,27655]
for_stmt [27160,27655]
===
match
---
operator: , [14979,14980]
operator: , [14979,14980]
===
match
---
name: self [18507,18511]
name: self [18507,18511]
===
match
---
not_test [2952,2970]
not_test [2952,2970]
===
match
---
name: val [19147,19150]
name: val [19147,19150]
===
match
---
simple_stmt [29529,29586]
simple_stmt [29529,29586]
===
match
---
trailer [20611,20613]
trailer [20611,20613]
===
match
---
decorator [29372,29386]
decorator [29372,29386]
===
match
---
parameters [42297,42299]
parameters [42275,42277]
===
match
---
simple_stmt [42581,42871]
simple_stmt [42559,42849]
===
match
---
trailer [43754,43759]
trailer [43732,43737]
===
match
---
name: JSONDecodeError [41564,41579]
name: JSONDecodeError [41542,41557]
===
match
---
atom_expr [34752,34778]
atom_expr [34752,34778]
===
match
---
operator: * [37051,37052]
operator: * [37029,37030]
===
match
---
name: interpolated [2232,2244]
name: interpolated [2232,2244]
===
match
---
operator: , [14040,14041]
operator: , [14040,14041]
===
match
---
atom_expr [27021,27061]
atom_expr [27021,27061]
===
match
---
simple_stmt [41129,41157]
simple_stmt [41107,41135]
===
match
---
operator: , [11522,11523]
operator: , [11522,11523]
===
match
---
atom_expr [2075,2127]
atom_expr [2075,2127]
===
match
---
atom [2467,2554]
atom [2467,2554]
===
match
---
param [14398,14403]
param [14398,14403]
===
match
---
simple_stmt [10294,10338]
simple_stmt [10294,10338]
===
match
---
if_stmt [11343,11845]
if_stmt [11343,11845]
===
match
---
arglist [16051,16073]
arglist [16051,16073]
===
match
---
trailer [34487,34492]
trailer [34487,34492]
===
match
---
simple_stmt [19814,20074]
simple_stmt [19814,20074]
===
match
---
comparison [23057,23085]
comparison [23057,23085]
===
match
---
trailer [36546,36548]
trailer [44411,44413]
===
match
---
if_stmt [16506,16750]
if_stmt [16506,16750]
===
match
---
trailer [43886,43891]
trailer [43864,43869]
===
match
---
operator: , [6409,6410]
operator: , [6409,6410]
===
match
---
name: warnings [39599,39607]
name: warnings [39577,39585]
===
match
---
operator: , [12353,12354]
operator: , [12353,12354]
===
match
---
expr_stmt [22764,22818]
expr_stmt [22764,22818]
===
match
---
name: opt [27368,27371]
name: opt [27368,27371]
===
match
---
operator: , [29065,29066]
operator: , [29065,29066]
===
match
---
parameters [39527,39544]
parameters [39505,39522]
===
match
---
name: key [27045,27048]
name: key [27045,27048]
===
match
---
simple_stmt [32576,32623]
simple_stmt [32576,32623]
===
match
---
name: os [13255,13257]
name: os [13255,13257]
===
match
---
name: _get_config_value_from_secret_backend [14766,14803]
name: _get_config_value_from_secret_backend [14766,14803]
===
match
---
atom_expr [36356,36431]
atom_expr [36356,36431]
===
match
---
arith_expr [14071,14083]
arith_expr [14071,14083]
===
match
---
name: section [14221,14228]
name: section [14221,14228]
===
match
---
name: name [43191,43195]
name: name [43169,43173]
===
match
---
name: is_sqlite [10187,10196]
name: is_sqlite [10187,10196]
===
match
---
name: key [16679,16682]
name: key [16679,16682]
===
match
---
operator: , [7297,7298]
operator: , [7297,7298]
===
match
---
name: open [42370,42374]
name: open [42348,42352]
===
match
---
expr_stmt [23202,23213]
expr_stmt [23202,23213]
===
match
---
operator: = [27981,27982]
operator: = [27981,27982]
===
match
---
trailer [22617,22637]
trailer [22617,22637]
===
match
---
suite [29780,30425]
suite [29780,30425]
===
match
---
name: self [22780,22784]
name: self [22780,22784]
===
match
---
atom [7689,8164]
atom [7689,8164]
===
match
---
operator: , [14147,14148]
operator: , [14147,14148]
===
match
---
arglist [39928,39943]
arglist [39906,39921]
===
match
---
name: secrets_backend_cls [42117,42136]
name: secrets_backend_cls [42095,42114]
===
match
---
trailer [8808,8810]
trailer [8808,8810]
===
match
---
arglist [15615,15663]
arglist [15615,15663]
===
match
---
name: _default_config_file_path [42716,42741]
name: _default_config_file_path [42694,42719]
===
match
---
name: section [17155,17162]
name: section [17155,17162]
===
match
---
name: key [13182,13185]
name: key [13182,13185]
===
match
---
suite [20184,20209]
suite [20184,20209]
===
match
---
funcdef [33032,33279]
funcdef [33032,33279]
===
match
---
name: _default_config_file_path [42481,42506]
name: _default_config_file_path [42459,42484]
===
match
---
name: _get_env_var_option [13017,13036]
name: _get_env_var_option [13017,13036]
===
match
---
string: 'metrics' [6505,6514]
string: 'metrics' [6505,6514]
===
match
---
trailer [11350,11361]
trailer [11350,11361]
===
match
---
name: ConfigParser [1142,1154]
name: ConfigParser [1142,1154]
===
match
---
trailer [26978,26980]
trailer [26978,26980]
===
match
---
name: path [43871,43875]
name: path [43849,43853]
===
match
---
operator: = [14499,14500]
operator: = [14499,14500]
===
match
---
string: """         Load the unit test configuration.          Note: this is not reversible.         """ [29789,29885]
string: """         Load the unit test configuration.          Note: this is not reversible.         """ [29789,29885]
===
match
---
expr_stmt [18097,18144]
expr_stmt [18097,18144]
===
match
---
string: "deprecated. Please access the configuration from the 'configuration.conf' object via " [37633,37720]
string: "deprecated. Please access the configuration from the 'configuration.conf' object via " [37611,37698]
===
match
---
suite [16471,16498]
suite [16471,16498]
===
match
---
param [12898,12903]
param [12898,12903]
===
match
---
fstring_expr [20512,20533]
fstring_expr [20512,20533]
===
match
---
atom_expr [2355,2375]
atom_expr [2355,2375]
===
match
---
funcdef [23876,26458]
funcdef [23876,26458]
===
match
---
string: 'mp_start_method' [10923,10940]
string: 'mp_start_method' [10923,10940]
===
match
---
operator: , [15171,15172]
operator: , [15171,15172]
===
match
---
operator: = [28376,28377]
operator: = [28376,28377]
===
match
---
name: sensitive_config_values [27187,27210]
name: sensitive_config_values [27187,27210]
===
match
---
string: "deprecated. Please access the configuration from the 'configuration.conf' object via " [38455,38542]
string: "deprecated. Please access the configuration from the 'configuration.conf' object via " [38433,38520]
===
match
---
operator: , [5142,5143]
operator: , [5142,5143]
===
match
---
suite [39559,39945]
suite [39537,39923]
===
match
---
name: secrets_path [14693,14705]
name: secrets_path [14693,14705]
===
match
---
operator: , [6935,6936]
operator: , [6935,6936]
===
match
---
name: OrderedDict [22306,22317]
name: OrderedDict [22306,22317]
===
match
---
operator: = [22600,22601]
operator: = [22600,22601]
===
match
---
name: os [3110,3112]
name: os [3110,3112]
===
match
---
fstring_string: " section.  [20465,20476]
fstring_string: " section.  [20465,20476]
===
match
---
name: initialize_secrets_backends [44390,44417]
name: initialize_secrets_backends [44368,44395]
===
match
---
name: section [8824,8831]
name: section [8824,8831]
===
match
---
name: e [20332,20333]
name: e [20332,20333]
===
match
---
atom [5418,5451]
atom [5418,5451]
===
match
---
expr_stmt [30065,30117]
expr_stmt [30065,30117]
===
match
---
dictorsetmaker [27590,27598]
dictorsetmaker [27590,27598]
===
match
---
string: '_sections' [31606,31617]
string: '_sections' [31606,31617]
===
match
---
simple_stmt [18723,18735]
simple_stmt [18723,18735]
===
match
---
funcdef [33281,33395]
funcdef [33281,33395]
===
match
---
operator: - [22710,22711]
operator: - [22710,22711]
===
match
---
testlist_comp [6355,6379]
testlist_comp [6355,6379]
===
match
---
trailer [9066,9083]
trailer [9066,9083]
===
match
---
atom_expr [43900,43926]
atom_expr [43878,43904]
===
match
---
name: alternative_secrets_config_dict [41668,41699]
name: alternative_secrets_config_dict [41646,41677]
===
match
---
name: str [14900,14903]
name: str [14900,14903]
===
match
---
param [15855,15859]
param [15855,15859]
===
match
---
fstring_start: f" [10107,10109]
fstring_start: f" [10107,10109]
===
match
---
trailer [43598,43603]
trailer [43576,43581]
===
match
---
simple_stmt [31755,31771]
simple_stmt [31755,31771]
===
match
---
name: option [15365,15371]
name: option [15365,15371]
===
match
---
suite [23648,23742]
suite [23648,23742]
===
match
---
funcdef [8365,8436]
funcdef [8365,8436]
===
match
---
name: opt [26619,26622]
name: opt [26619,26622]
===
match
---
operator: * [39491,39492]
operator: * [39469,39470]
===
match
---
if_stmt [41045,41125]
if_stmt [41023,41103]
===
match
---
suite [18349,18467]
suite [18349,18467]
===
match
---
trailer [27035,27044]
trailer [27035,27044]
===
match
---
operator: , [12802,12803]
operator: , [12802,12803]
===
match
---
name: Optional [1274,1282]
name: Optional [1274,1282]
===
match
---
expr_stmt [22895,22909]
expr_stmt [22895,22909]
===
match
---
trailer [22235,22252]
trailer [22235,22252]
===
match
---
operator: -> [41753,41755]
operator: -> [41731,41733]
===
match
---
name: str [24096,24099]
name: str [24096,24099]
===
match
---
trailer [26957,26981]
trailer [26957,26981]
===
match
---
trailer [34673,34680]
trailer [34673,34680]
===
match
---
operator: , [17187,17188]
operator: , [17187,17188]
===
match
---
raise_stmt [19191,19378]
raise_stmt [19191,19378]
===
match
---
name: raw [29323,29326]
name: raw [29323,29326]
===
match
---
funcdef [3222,3491]
funcdef [3222,3491]
===
match
---
name: parents [34050,34057]
name: parents [34050,34057]
===
match
---
atom_expr [1702,1797]
atom_expr [1702,1797]
===
match
---
arglist [3194,3218]
arglist [3194,3218]
===
match
---
operator: , [5203,5204]
operator: , [5203,5204]
===
match
---
operator: , [6052,6053]
operator: , [6052,6053]
===
match
---
string: 'scheduler' [7085,7096]
string: 'scheduler' [7085,7096]
===
match
---
simple_stmt [37931,38220]
simple_stmt [37909,38198]
===
match
---
trailer [31823,31833]
trailer [31823,31833]
===
match
---
operator: } [8163,8164]
operator: } [8163,8164]
===
match
---
suite [23780,23871]
suite [23780,23871]
===
match
---
not_test [36287,36323]
not_test [36287,36323]
===
match
---
operator: , [9020,9021]
operator: , [9020,9021]
===
match
---
operator: , [23964,23965]
operator: , [23964,23965]
===
match
---
argument [1744,1778]
argument [1744,1778]
===
match
---
simple_stmt [9944,10005]
simple_stmt [9944,10005]
===
match
---
operator: , [9147,9148]
operator: , [9147,9148]
===
match
---
fstring [16214,16266]
fstring [16214,16266]
===
match
---
name: Dict [1262,1266]
name: Dict [1262,1266]
===
match
---
operator: , [1742,1743]
operator: , [1742,1743]
===
match
---
trailer [41202,41222]
trailer [41180,41200]
===
match
---
name: get [10149,10152]
name: get [10149,10152]
===
match
---
simple_stmt [20082,20149]
simple_stmt [20082,20149]
===
match
---
name: load_test_config [37022,37038]
name: load_test_config [37000,37016]
===
match
---
name: get_config [3018,3028]
name: get_config [3018,3028]
===
match
---
arglist [33929,34003]
arglist [33929,34003]
===
match
---
simple_stmt [27305,27314]
simple_stmt [27305,27314]
===
match
---
name: os [33174,33176]
name: os [33174,33176]
===
match
---
return_stmt [3174,3219]
return_stmt [3174,3219]
===
match
---
if_stmt [15673,15722]
if_stmt [15673,15722]
===
match
---
trailer [3117,3122]
trailer [3117,3122]
===
match
---
operator: , [21076,21077]
operator: , [21076,21077]
===
match
---
name: setdefault [29551,29561]
name: setdefault [29551,29561]
===
match
---
name: option [15420,15426]
name: option [15420,15426]
===
match
---
name: NoSectionError [21150,21164]
name: NoSectionError [21150,21164]
===
match
---
argument [31282,31305]
argument [31282,31305]
===
match
---
expr_stmt [43827,43950]
expr_stmt [43805,43928]
===
match
---
operator: = [41933,41934]
operator: = [41911,41912]
===
match
---
name: as_dict [39951,39958]
name: as_dict [39929,39936]
===
match
---
name: include_env [26023,26034]
name: include_env [26023,26034]
===
match
---
name: exists [43655,43661]
name: exists [43633,43639]
===
match
---
decorated [42415,42579]
decorated [42393,42557]
===
match
---
name: key [20134,20137]
name: key [20134,20137]
===
match
---
for_stmt [27749,28978]
for_stmt [27749,28978]
===
match
---
operator: = [20628,20629]
operator: = [20628,20629]
===
match
---
fstring_start: f" [2638,2640]
fstring_start: f" [2638,2640]
===
match
---
operator: { [19725,19726]
operator: { [19725,19726]
===
match
---
trailer [36721,37012]
trailer [36699,36990]
===
match
---
suite [42553,42579]
suite [42531,42557]
===
match
---
name: module [1780,1786]
name: module [1780,1786]
===
match
---
suite [36665,37041]
suite [36643,37019]
===
match
---
trailer [19081,19085]
trailer [19081,19085]
===
match
---
fstring_string: Output:  [2719,2727]
fstring_string: Output:  [2719,2727]
===
match
---
string: 'colored_log_format' [5430,5450]
string: 'colored_log_format' [5430,5450]
===
match
---
operator: + [11757,11758]
operator: + [11757,11758]
===
match
---
name: command [2367,2374]
name: command [2367,2374]
===
match
---
name: startswith [22552,22562]
name: startswith [22552,22562]
===
match
---
trailer [36040,36051]
trailer [36040,36051]
===
match
---
name: version [10252,10259]
name: version [10252,10259]
===
match
---
simple_stmt [43686,43723]
simple_stmt [43664,43701]
===
match
---
suite [10565,10820]
suite [10565,10820]
===
match
---
simple_stmt [17940,17952]
simple_stmt [17940,17952]
===
match
---
comp_op [11947,11953]
comp_op [11947,11953]
===
match
---
name: state [31739,31744]
name: state [31739,31744]
===
match
---
name: SECRET_KEY [44169,44179]
name: SECRET_KEY [44147,44157]
===
match
---
simple_stmt [33079,33111]
simple_stmt [33079,33111]
===
match
---
atom_expr [20104,20148]
atom_expr [20104,20148]
===
match
---
trailer [14209,14220]
trailer [14209,14220]
===
match
---
simple_stmt [1702,1798]
simple_stmt [1702,1798]
===
match
---
atom_expr [32939,32948]
atom_expr [32939,32948]
===
match
---
operator: ** [40342,40344]
operator: ** [40320,40322]
===
match
---
name: write [34757,34762]
name: write [34757,34762]
===
match
---
operator: , [11373,11374]
operator: , [11373,11374]
===
match
---
string: "Reading the config from %s" [34797,34825]
string: "Reading the config from %s" [34797,34825]
===
match
---
trailer [44364,44366]
trailer [44342,44344]
===
match
---
atom_expr [1514,1541]
atom_expr [1514,1541]
===
match
---
simple_stmt [36708,37013]
simple_stmt [36686,36991]
===
match
---
atom [4007,4300]
atom [4007,4300]
===
match
---
simple_stmt [13144,13187]
simple_stmt [13144,13187]
===
match
---
name: opt [28315,28318]
name: opt [28315,28318]
===
match
---
suite [32538,32564]
suite [32538,32564]
===
match
---
name: config_sources [28909,28923]
name: config_sources [28909,28923]
===
match
---
param [14866,14870]
param [14866,14870]
===
match
---
trailer [12244,12248]
trailer [12244,12248]
===
match
---
operator: , [17792,17793]
operator: , [17792,17793]
===
match
---
name: float [21812,21817]
name: float [21812,21817]
===
match
---
name: logging [822,829]
name: logging [822,829]
===
match
---
trailer [31201,31208]
trailer [31201,31208]
===
match
---
name: FERNET_KEY [34092,34102]
name: FERNET_KEY [34092,34102]
===
match
---
operator: = [24060,24061]
operator: = [24060,24061]
===
match
---
funcdef [39510,39945]
funcdef [39488,39923]
===
match
---
name: log [34788,34791]
name: log [34788,34791]
===
match
---
name: self [10144,10148]
name: self [10144,10148]
===
match
---
name: module [1680,1686]
name: module [1680,1686]
===
match
---
atom_expr [24086,24100]
atom_expr [24086,24100]
===
match
---
for_stmt [29147,29367]
for_stmt [29147,29367]
===
match
---
trailer [34590,34596]
trailer [34590,34596]
===
match
---
operator: , [43928,43929]
operator: , [43906,43907]
===
match
---
parameters [20677,20712]
parameters [20677,20712]
===
match
---
name: new_value [9471,9480]
name: new_value [9471,9480]
===
match
---
operator: { [25734,25735]
operator: { [25734,25735]
===
match
---
name: path [36294,36298]
name: path [36294,36298]
===
match
---
param [24019,24037]
param [24019,24037]
===
match
---
name: list_mode [11581,11590]
name: list_mode [11581,11590]
===
match
---
name: _create_future_warning [12302,12324]
name: _create_future_warning [12302,12324]
===
match
---
arglist [36452,36526]
arglist [36452,36526]
===
match
---
param [8758,8762]
param [8758,8762]
===
match
---
string: 'encrypt_s3_logs' [5051,5068]
string: 'encrypt_s3_logs' [5051,5068]
===
match
---
name: self [14851,14855]
name: self [14851,14855]
===
match
---
name: get_airflow_test_config [33036,33059]
name: get_airflow_test_config [33036,33059]
===
match
---
funcdef [42278,42413]
funcdef [42256,42391]
===
match
---
name: json [41442,41446]
name: json [41420,41424]
===
match
---
with_stmt [34696,34779]
with_stmt [34696,34779]
===
match
---
atom_expr [27983,28021]
atom_expr [27983,28021]
===
match
---
parameters [33059,33073]
parameters [33059,33073]
===
match
---
trailer [2689,2700]
trailer [2689,2700]
===
match
---
operator: = [20590,20591]
operator: = [20590,20591]
===
match
---
operator: , [13494,13495]
operator: , [13494,13495]
===
match
---
string: 'scheduler' [6988,6999]
string: 'scheduler' [6988,6999]
===
match
---
trailer [23156,23158]
trailer [23156,23158]
===
match
---
trailer [2394,2399]
trailer [2394,2399]
===
match
---
name: get [11431,11434]
name: get [11431,11434]
===
match
---
trailer [22804,22818]
trailer [22804,22818]
===
match
---
name: BaseSecretsBackend [40805,40823]
name: BaseSecretsBackend [40783,40801]
===
match
---
strings [39194,39406]
strings [39172,39384]
===
match
---
name: kwargs [8490,8496]
name: kwargs [8490,8496]
===
match
---
name: default_config [8689,8703]
name: default_config [8689,8703]
===
match
---
name: os [13569,13571]
name: os [13569,13571]
===
match
---
string: "Accessing configuration method 'getboolean' directly from the configuration module is " [37536,37624]
string: "Accessing configuration method 'getboolean' directly from the configuration module is " [37514,37602]
===
match
---
name: _create_future_warning [9284,9306]
name: _create_future_warning [9284,9306]
===
match
---
trailer [14161,14185]
trailer [14161,14185]
===
match
---
name: airflow_defaults [22236,22252]
name: airflow_defaults [22236,22252]
===
match
---
fstring_string: ". [20533,20535]
fstring_string: ". [20533,20535]
===
match
---
trailer [3138,3148]
trailer [3138,3148]
===
match
---
arglist [30605,30947]
arglist [30605,30947]
===
match
---
simple_stmt [19558,19748]
simple_stmt [19558,19748]
===
match
---
name: b64encode [965,974]
name: b64encode [965,974]
===
match
---
argument [38647,38652]
argument [38625,38630]
===
match
---
string: """     Expands (potentially nested) env vars by repeatedly applying     `expandvars` and `expanduser` until interpolation stops having     any effect.     """ [1833,1992]
string: """     Expands (potentially nested) env vars by repeatedly applying     `expandvars` and `expanduser` until interpolation stops having     any effect.     """ [1833,1992]
===
match
---
param [2263,2270]
param [2263,2270]
===
match
---
atom_expr [14589,14617]
atom_expr [14589,14617]
===
match
---
arglist [21632,21647]
arglist [21632,21647]
===
match
---
name: self [19032,19036]
name: self [19032,19036]
===
match
---
name: current_value [9422,9435]
name: current_value [9422,9435]
===
match
---
testlist_comp [6458,6493]
testlist_comp [6458,6493]
===
match
---
suite [39134,39508]
suite [39112,39486]
===
match
---
suite [39990,40352]
suite [39968,40330]
===
match
---
dotted_name [42244,42263]
dotted_name [42222,42241]
===
match
---
operator: = [9002,9003]
operator: = [9002,9003]
===
match
---
suite [15870,16268]
suite [15870,16268]
===
match
---
simple_stmt [36533,36549]
simple_stmt [44398,44414]
===
match
---
name: env_var [27753,27760]
name: env_var [27753,27760]
===
match
---
name: sys [926,929]
name: sys [926,929]
===
match
---
name: line [32515,32519]
name: line [32515,32519]
===
match
---
strings [12411,12670]
strings [12411,12670]
===
match
---
param [3073,3087]
param [3073,3087]
===
match
---
comparison [33118,33157]
comparison [33118,33157]
===
match
---
name: shlex [2355,2360]
name: shlex [2355,2360]
===
match
---
atom [7211,7253]
atom [7211,7253]
===
match
---
trailer [34111,34124]
trailer [34111,34124]
===
match
---
operator: , [18572,18573]
operator: , [18572,18573]
===
match
---
suite [26682,27062]
suite [26682,27062]
===
match
---
expr_stmt [23525,23563]
expr_stmt [23525,23563]
===
match
---
name: functools [793,802]
name: functools [793,802]
===
match
---
trailer [26371,26427]
trailer [26371,26427]
===
match
---
string: 'scheduler' [6458,6469]
string: 'scheduler' [6458,6469]
===
match
---
trailer [8870,8876]
trailer [8870,8876]
===
match
---
atom [27589,27599]
atom [27589,27599]
===
match
---
name: section [9367,9374]
name: section [9367,9374]
===
match
---
if_stmt [26020,26123]
if_stmt [26020,26123]
===
match
---
string: 'logging_config_class' [5290,5312]
string: 'logging_config_class' [5290,5312]
===
match
---
operator: , [36058,36059]
operator: , [36058,36059]
===
match
---
name: path [44074,44078]
name: path [44052,44056]
===
match
---
simple_stmt [10446,10476]
simple_stmt [10446,10476]
===
match
---
arglist [30776,30862]
arglist [30776,30862]
===
match
---
operator: = [37381,37382]
operator: = [37359,37360]
===
match
---
operator: , [33565,33566]
operator: , [33565,33566]
===
match
---
name: multiprocessing [10977,10992]
name: multiprocessing [10977,10992]
===
match
---
name: action [1633,1639]
name: action [1633,1639]
===
match
---
name: k [29739,29740]
name: k [29739,29740]
===
match
---
simple_stmt [22295,22320]
simple_stmt [22295,22320]
===
match
---
operator: = [22445,22446]
operator: = [22445,22446]
===
match
---
operator: , [37798,37799]
operator: , [37776,37777]
===
match
---
parameters [30467,30518]
parameters [30467,30518]
===
match
---
trailer [32217,32225]
trailer [32217,32225]
===
match
---
name: raw [26541,26544]
name: raw [26541,26544]
===
match
---
operator: , [9840,9841]
operator: , [9840,9841]
===
match
---
comparison [28242,28297]
comparison [28242,28297]
===
match
---
comparison [13396,13421]
comparison [13396,13421]
===
match
---
string: 'core' [7699,7705]
string: 'core' [7699,7705]
===
match
---
operator: , [15629,15630]
operator: , [15629,15630]
===
match
---
name: key [14042,14045]
name: key [14042,14045]
===
match
---
trailer [23066,23068]
trailer [23066,23068]
===
match
---
atom_expr [42312,42360]
atom_expr [42290,42338]
===
match
---
name: deprecated_key [16594,16608]
name: deprecated_key [16594,16608]
===
match
---
string: 'statsd_datadog_tags' [6866,6887]
string: 'statsd_datadog_tags' [6866,6887]
===
match
---
name: key [28879,28882]
name: key [28879,28882]
===
match
---
string: 'core' [5881,5887]
string: 'core' [5881,5887]
===
match
---
arglist [35345,35367]
arglist [35345,35367]
===
match
---
trailer [23557,23560]
trailer [23557,23560]
===
match
---
operator: , [27144,27145]
operator: , [27144,27145]
===
match
---
operator: * [37865,37866]
operator: * [37843,37844]
===
match
---
name: kwargs [39537,39543]
name: kwargs [39515,39521]
===
match
---
operator: = [12713,12714]
operator: = [12713,12714]
===
match
---
operator: , [19771,19772]
operator: , [19771,19772]
===
match
---
funcdef [19384,19748]
funcdef [19384,19748]
===
match
---
simple_stmt [31819,31842]
simple_stmt [31819,31842]
===
match
---
if_stmt [15195,15244]
if_stmt [15195,15244]
===
match
---
name: airflow_defaults [16030,16046]
name: airflow_defaults [16030,16046]
===
match
---
operator: = [40720,40721]
operator: = [40698,40699]
===
match
---
name: get [35793,35796]
name: get [35793,35796]
===
match
---
string: 'AIRFLOW_CONFIG' [32096,32112]
string: 'AIRFLOW_CONFIG' [32096,32112]
===
match
---
simple_stmt [10582,10820]
simple_stmt [10582,10820]
===
match
---
suite [44044,44109]
suite [44022,44087]
===
match
---
operator: } [2752,2753]
operator: } [2752,2753]
===
match
---
operator: , [38566,38567]
operator: , [38544,38545]
===
match
---
operator: , [43624,43625]
operator: , [43602,43603]
===
match
---
trailer [14803,14817]
trailer [14803,14817]
===
match
---
simple_stmt [34207,34269]
simple_stmt [34207,34269]
===
move-tree
---
simple_stmt [36533,36549]
    atom_expr [36533,36548]
        name: conf [36533,36537]
        trailer [36537,36546]
            name: validate [36538,36546]
        trailer [36546,36548]
to
file_input [786,44521]
at 64
