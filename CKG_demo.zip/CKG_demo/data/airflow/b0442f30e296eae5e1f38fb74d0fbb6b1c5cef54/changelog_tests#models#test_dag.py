===
match
---
atom_expr [61923,61968]
atom_expr [61954,61999]
===
match
---
trailer [38092,38096]
trailer [38123,38127]
===
match
---
name: MANUAL [50716,50722]
name: MANUAL [50747,50753]
===
match
---
argument [13147,13180]
argument [13178,13211]
===
match
---
name: settings [13213,13221]
name: settings [13244,13252]
===
match
---
operator: , [2179,2180]
operator: , [2210,2211]
===
match
---
simple_stmt [77528,77626]
simple_stmt [79152,79250]
===
match
---
name: models [1653,1659]
name: models [1659,1665]
===
match
---
expr_stmt [26476,26547]
expr_stmt [26507,26578]
===
match
---
string: 'owner1' [7519,7527]
string: 'owner1' [7550,7558]
===
match
---
argument [59292,59307]
argument [59323,59338]
===
match
---
trailer [25542,25552]
trailer [25573,25583]
===
match
---
name: prev [24070,24074]
name: prev [24101,24105]
===
match
---
atom_expr [33120,33154]
atom_expr [33151,33185]
===
match
---
operator: == [11315,11317]
operator: == [11346,11348]
===
match
---
name: NamedTemporaryFile [20767,20785]
name: NamedTemporaryFile [20798,20816]
===
match
---
operator: = [75296,75297]
operator: = [76920,76921]
===
match
---
operator: = [52426,52427]
operator: = [52457,52458]
===
match
---
operator: = [12894,12895]
operator: = [12925,12926]
===
match
---
name: DEFAULT_DATE [10264,10276]
name: DEFAULT_DATE [10295,10307]
===
match
---
trailer [15620,15626]
trailer [15651,15657]
===
match
---
arith_expr [14076,14081]
arith_expr [14107,14112]
===
match
---
expr_stmt [36129,36152]
expr_stmt [36160,36183]
===
match
---
atom_expr [25619,25708]
atom_expr [25650,25739]
===
match
---
name: DummyOperator [7316,7329]
name: DummyOperator [7347,7360]
===
match
---
simple_stmt [76457,76510]
simple_stmt [78081,78134]
===
match
---
trailer [58687,58691]
trailer [58718,58722]
===
match
---
name: State [54106,54111]
name: State [54137,54142]
===
match
---
operator: = [75932,75933]
operator: = [77556,77557]
===
match
---
name: delta [57889,57894]
name: delta [57920,57925]
===
match
---
simple_stmt [51810,51872]
simple_stmt [51841,51903]
===
match
---
string: 'owner2' [7243,7251]
string: 'owner2' [7274,7282]
===
match
---
name: stage [13901,13906]
name: stage [13932,13937]
===
match
---
name: dag_subclass_diff_name [48177,48199]
name: dag_subclass_diff_name [48208,48230]
===
match
---
assert_stmt [28511,28785]
assert_stmt [28542,28816]
===
match
---
comparison [50526,50561]
comparison [50557,50592]
===
match
---
name: session [37106,37113]
name: session [37137,37144]
===
match
---
trailer [8856,8883]
trailer [8887,8914]
===
match
---
string: 'test-dag' [29844,29854]
string: 'test-dag' [29875,29885]
===
match
---
number: 10 [64089,64091]
number: 10 [65713,65715]
===
match
---
operator: } [77558,77559]
operator: } [79182,79183]
===
match
---
operator: == [36043,36045]
operator: == [36074,36076]
===
match
---
trailer [64072,64095]
trailer [65696,65719]
===
match
---
trailer [49915,49917]
trailer [49946,49948]
===
match
---
atom_expr [23332,23418]
atom_expr [23363,23449]
===
match
---
operator: = [18098,18099]
operator: = [18129,18130]
===
match
---
trailer [22848,22854]
trailer [22879,22885]
===
match
---
name: dag_subdag [65019,65029]
name: dag_subdag [66643,66653]
===
match
---
simple_stmt [41328,41399]
simple_stmt [41359,41430]
===
match
---
name: dag [22941,22944]
name: dag [22972,22975]
===
match
---
number: 0 [18778,18779]
number: 0 [18809,18810]
===
match
---
name: op3 [42079,42082]
name: op3 [42110,42113]
===
match
---
trailer [54922,54929]
trailer [54953,54960]
===
match
---
name: create_dagrun [51106,51119]
name: create_dagrun [51137,51150]
===
match
---
name: including_subdags [35330,35347]
name: including_subdags [35361,35378]
===
match
---
atom_expr [46926,47150]
atom_expr [46957,47181]
===
match
---
parameters [50897,50903]
parameters [50928,50934]
===
match
---
atom_expr [2628,2657]
atom_expr [2659,2688]
===
match
---
trailer [22999,23007]
trailer [23030,23038]
===
match
---
operator: = [55376,55377]
operator: = [55407,55408]
===
match
---
trailer [36504,36557]
trailer [36535,36588]
===
match
---
atom [17308,17327]
atom [17339,17358]
===
match
---
expr_stmt [37500,37582]
expr_stmt [37531,37613]
===
match
---
name: num [74313,74316]
name: num [75937,75940]
===
match
---
name: DAG [50444,50447]
name: DAG [50475,50478]
===
match
---
name: state [76480,76485]
name: state [78104,78109]
===
match
---
dictorsetmaker [66275,66331]
dictorsetmaker [67899,67955]
===
match
---
trailer [36606,36617]
trailer [36637,36648]
===
match
---
atom_expr [32742,32773]
atom_expr [32773,32804]
===
match
---
operator: >> [59555,59557]
operator: >> [59586,59588]
===
match
---
atom_expr [17930,17956]
atom_expr [17961,17987]
===
match
---
simple_stmt [7613,7642]
simple_stmt [7644,7673]
===
match
---
assert_stmt [6989,7010]
assert_stmt [7020,7041]
===
match
---
expr_stmt [40626,40682]
expr_stmt [40657,40713]
===
match
---
operator: == [28409,28411]
operator: == [28440,28442]
===
match
---
name: dag [12593,12596]
name: dag [12624,12627]
===
match
---
number: 2 [70436,70437]
number: 2 [72060,72061]
===
match
---
name: values [16908,16914]
name: values [16939,16945]
===
match
---
atom_expr [11048,11065]
atom_expr [11079,11096]
===
match
---
trailer [24112,24114]
trailer [24143,24145]
===
match
---
trailer [22840,22848]
trailer [22871,22879]
===
match
---
atom_expr [29924,29976]
atom_expr [29955,30007]
===
match
---
name: test_fails_if_arg_not_set [72723,72748]
name: test_fails_if_arg_not_set [74347,74372]
===
match
---
and_test [63886,63961]
and_test [65510,65585]
===
match
---
operator: = [59337,59338]
operator: = [59368,59369]
===
match
---
decorator [2660,2676]
decorator [2691,2707]
===
match
---
atom_expr [22610,22633]
atom_expr [22641,22664]
===
match
---
name: topological_list [9900,9916]
name: topological_list [9931,9947]
===
match
---
name: op4 [9654,9657]
name: op4 [9685,9688]
===
match
---
name: session [69417,69424]
name: session [71041,71048]
===
match
---
argument [32553,32566]
argument [32584,32597]
===
match
---
name: DagTag [1550,1556]
name: DagTag [1556,1562]
===
match
---
name: session [19035,19042]
name: session [19066,19073]
===
match
---
expr_stmt [14461,14507]
expr_stmt [14492,14538]
===
match
---
number: 1 [16804,16805]
number: 1 [16835,16836]
===
match
---
name: DagModel [45237,45245]
name: DagModel [45268,45276]
===
match
---
name: jinja2 [20587,20593]
name: jinja2 [20618,20624]
===
match
---
number: 2 [11231,11232]
number: 2 [11262,11263]
===
match
---
funcdef [39628,40248]
funcdef [39659,40279]
===
match
---
name: self [51262,51266]
name: self [51293,51297]
===
match
---
trailer [17989,18003]
trailer [18020,18034]
===
match
---
operator: = [51884,51885]
operator: = [51915,51916]
===
match
---
fstring_expr [64767,64783]
fstring_expr [66391,66407]
===
match
---
trailer [38074,38081]
trailer [38105,38112]
===
match
---
operator: , [56039,56040]
operator: , [56070,56071]
===
match
---
name: correct_weight [15772,15786]
name: correct_weight [15803,15817]
===
match
---
string: 'test-default_orientation' [6346,6372]
string: 'test-default_orientation' [6377,6403]
===
match
---
name: add [67789,67792]
name: add [69413,69416]
===
match
---
name: loaded_value [77002,77014]
name: loaded_value [78626,78638]
===
match
---
name: start [58749,58754]
name: start [58780,58785]
===
match
---
name: DAG [17259,17262]
name: DAG [17290,17293]
===
match
---
string: "@yearly" [50154,50163]
string: "@yearly" [50185,50194]
===
match
---
argument [31470,31476]
argument [31501,31507]
===
match
---
argument [22512,22543]
argument [22543,22574]
===
match
---
operator: , [50025,50026]
operator: , [50056,50057]
===
match
---
name: f [21468,21469]
name: f [21499,21500]
===
match
---
name: model [31411,31416]
name: model [31442,31447]
===
match
---
name: next_local [23869,23879]
name: next_local [23900,23910]
===
match
---
suite [7778,7830]
suite [7809,7861]
===
match
---
string: 'faketastic' [58222,58234]
string: 'faketastic' [58253,58265]
===
match
---
name: tzname [27336,27342]
name: tzname [27367,27373]
===
match
---
atom_expr [52906,52918]
atom_expr [52937,52949]
===
match
---
string: 'start_date' [38394,38406]
string: 'start_date' [38425,38437]
===
match
---
atom_expr [32467,32483]
atom_expr [32498,32514]
===
match
---
trailer [71064,71066]
trailer [72688,72690]
===
match
---
arith_expr [69084,69116]
arith_expr [70708,70740]
===
match
---
string: "faketastic" [46815,46827]
string: "faketastic" [46846,46858]
===
match
---
name: datetime [56854,56862]
name: datetime [56885,56893]
===
match
---
name: NONE [54284,54288]
name: NONE [54315,54319]
===
match
---
suite [72000,72028]
suite [73624,73652]
===
match
---
comparison [73966,73994]
comparison [75590,75618]
===
match
---
operator: , [12396,12397]
operator: , [12427,12428]
===
match
---
operator: = [19539,19540]
operator: = [19570,19571]
===
match
---
string: 'dummy' [31148,31155]
string: 'dummy' [31179,31186]
===
match
---
operator: = [40580,40581]
operator: = [40611,40612]
===
match
---
number: 1 [12919,12920]
number: 1 [12950,12951]
===
match
---
string: "test3" [18036,18043]
string: "test3" [18067,18074]
===
match
---
name: row [29421,29424]
name: row [29452,29455]
===
match
---
name: DAG [46727,46730]
name: DAG [46758,46761]
===
match
---
name: dag [48367,48370]
name: dag [48398,48401]
===
match
---
name: datetime [67713,67721]
name: datetime [69337,69345]
===
match
---
atom_expr [74435,74452]
atom_expr [76059,76076]
===
match
---
expr_stmt [42092,42175]
expr_stmt [42123,42206]
===
match
---
name: isoformat [24977,24986]
name: isoformat [25008,25017]
===
match
---
atom_expr [15305,15324]
atom_expr [15336,15355]
===
match
---
name: task_id [38850,38857]
name: task_id [38881,38888]
===
match
---
assert_stmt [50779,50836]
assert_stmt [50810,50867]
===
match
---
simple_stmt [28093,28193]
simple_stmt [28124,28224]
===
match
---
number: 25 [27442,27444]
number: 25 [27473,27475]
===
match
---
operator: = [72068,72069]
operator: = [73692,73693]
===
match
---
operator: { [66355,66356]
operator: { [67979,67980]
===
match
---
name: pytest [73144,73150]
name: pytest [74768,74774]
===
match
---
operator: >> [42076,42078]
operator: >> [42107,42109]
===
match
---
trailer [73680,73687]
trailer [75304,75311]
===
match
---
name: task [21835,21839]
name: task [21866,21870]
===
match
---
name: DEFAULT_DATE [78339,78351]
name: DEFAULT_DATE [79963,79975]
===
match
---
name: start_date [9332,9342]
name: start_date [9363,9373]
===
match
---
operator: , [62097,62098]
operator: , [62128,62129]
===
match
---
assert_stmt [9046,9113]
assert_stmt [9077,9144]
===
match
---
operator: , [22510,22511]
operator: , [22541,22542]
===
match
---
string: 'op4' [7338,7343]
string: 'op4' [7369,7374]
===
match
---
for_stmt [14158,14567]
for_stmt [14189,14598]
===
match
---
name: test_dag [17742,17750]
name: test_dag [17773,17781]
===
match
---
argument [61543,61583]
argument [61574,61614]
===
match
---
assert_stmt [58620,58666]
assert_stmt [58651,58697]
===
match
---
name: DAG [66491,66494]
name: DAG [68115,68118]
===
match
---
string: 'Europe/Zurich' [23299,23314]
string: 'Europe/Zurich' [23330,23345]
===
match
---
suite [28231,28271]
suite [28262,28302]
===
match
---
string: 'test' [71745,71751]
string: 'test' [73369,73375]
===
match
---
argument [73853,73881]
argument [75477,75505]
===
match
---
operator: , [24480,24481]
operator: , [24511,24512]
===
match
---
atom_expr [47364,47386]
atom_expr [47395,47417]
===
match
---
simple_stmt [27214,27244]
simple_stmt [27245,27275]
===
match
---
name: State [76391,76396]
name: State [78015,78020]
===
match
---
atom_expr [44425,44447]
atom_expr [44456,44478]
===
match
---
trailer [53748,53762]
trailer [53779,53793]
===
match
---
name: default_args [12597,12609]
name: default_args [12628,12640]
===
match
---
name: session [52293,52300]
name: session [52324,52331]
===
match
---
arglist [63681,63702]
arglist [65305,65326]
===
match
---
operator: = [65206,65207]
operator: = [66830,66831]
===
match
---
string: 'end_date' [12651,12661]
string: 'end_date' [12682,12692]
===
match
---
name: dag_subclass [48689,48701]
name: dag_subclass [48720,48732]
===
match
---
simple_stmt [62770,62847]
simple_stmt [62801,62878]
===
match
---
name: dates [58660,58665]
name: dates [58691,58696]
===
match
---
atom_expr [7989,7996]
atom_expr [8020,8027]
===
match
---
suite [26389,26731]
suite [26420,26762]
===
match
---
operator: } [17326,17327]
operator: } [17357,17358]
===
match
---
name: clear_db_dags [2875,2888]
name: clear_db_dags [2906,2919]
===
match
---
argument [76053,76082]
argument [77677,77706]
===
match
---
trailer [30760,30763]
trailer [30791,30794]
===
match
---
simple_stmt [9122,9189]
simple_stmt [9153,9220]
===
match
---
argument [42127,42148]
argument [42158,42179]
===
match
---
trailer [61695,61712]
trailer [61726,61743]
===
match
---
argument [19840,19881]
argument [19871,19912]
===
match
---
name: dag2 [7130,7134]
name: dag2 [7161,7165]
===
match
---
name: DEFAULT_ARGS [70663,70675]
name: DEFAULT_ARGS [72287,72299]
===
match
---
name: default_args [38482,38494]
name: default_args [38513,38525]
===
match
---
name: states [19249,19255]
name: states [19280,19286]
===
match
---
atom_expr [33874,33905]
atom_expr [33905,33936]
===
match
---
trailer [76303,76310]
trailer [77927,77934]
===
match
---
param [22068,22072]
param [22099,22103]
===
match
---
expr_stmt [66683,66724]
expr_stmt [68307,68348]
===
match
---
name: get_num_task_instances [18878,18900]
name: get_num_task_instances [18909,18931]
===
match
---
simple_stmt [3861,3891]
simple_stmt [3892,3922]
===
match
---
trailer [44779,44844]
trailer [44810,44875]
===
match
---
number: 1 [70898,70899]
number: 1 [72522,72523]
===
match
---
string: 'owner' [17309,17316]
string: 'owner' [17340,17347]
===
match
---
operator: , [32551,32552]
operator: , [32582,32583]
===
match
---
name: DAG [20989,20992]
name: DAG [21020,21023]
===
match
---
operator: = [22939,22940]
operator: = [22970,22971]
===
match
---
simple_stmt [28069,28085]
simple_stmt [28100,28116]
===
match
---
operator: == [39127,39129]
operator: == [39158,39160]
===
match
---
expr_stmt [14917,15276]
expr_stmt [14948,15307]
===
match
---
trailer [30654,30658]
trailer [30685,30689]
===
match
---
name: default_args [6737,6749]
name: default_args [6768,6780]
===
match
---
name: DummyOperator [7613,7626]
name: DummyOperator [7644,7657]
===
match
---
simple_stmt [3433,3525]
simple_stmt [3464,3556]
===
match
---
operator: = [7912,7913]
operator: = [7943,7944]
===
match
---
name: datetime [57897,57905]
name: datetime [57928,57936]
===
match
---
expr_stmt [61680,61718]
expr_stmt [61711,61749]
===
match
---
simple_stmt [50438,50511]
simple_stmt [50469,50542]
===
match
---
trailer [52339,52346]
trailer [52370,52377]
===
match
---
param [70199,70204]
param [71823,71828]
===
match
---
simple_stmt [17736,17822]
simple_stmt [17767,17853]
===
match
---
name: hours [78561,78566]
name: hours [80185,80190]
===
match
---
argument [61625,61631]
argument [61656,61662]
===
match
---
param [8091,8095]
param [8122,8126]
===
match
---
trailer [73615,73617]
trailer [75239,75241]
===
match
---
arglist [13622,13686]
arglist [13653,13717]
===
match
---
arglist [62464,62474]
arglist [62495,62505]
===
match
---
name: execution_date [53666,53680]
name: execution_date [53697,53711]
===
match
---
simple_stmt [35155,35257]
simple_stmt [35186,35288]
===
match
---
trailer [28996,29013]
trailer [29027,29044]
===
match
---
operator: } [66208,66209]
operator: } [67832,67833]
===
match
---
for_stmt [70297,70402]
for_stmt [71921,72026]
===
match
---
name: set2 [11189,11193]
name: set2 [11220,11224]
===
match
---
expr_stmt [34216,34299]
expr_stmt [34247,34330]
===
match
---
atom [19861,19881]
atom [19892,19912]
===
match
---
simple_stmt [71192,71196]
simple_stmt [72816,72820]
===
match
---
expr_stmt [73510,73538]
expr_stmt [75134,75162]
===
match
---
parameters [12717,12723]
parameters [12748,12754]
===
match
---
trailer [47879,47911]
trailer [47910,47942]
===
match
---
expr_stmt [74419,74452]
expr_stmt [76043,76076]
===
match
---
name: delete [49811,49817]
name: delete [49842,49848]
===
match
---
name: all [28479,28482]
name: all [28510,28513]
===
match
---
name: max_active_runs [68520,68535]
name: max_active_runs [70144,70159]
===
match
---
testlist_comp [69556,69586]
testlist_comp [71180,71210]
===
match
---
name: session [77431,77438]
name: session [79055,79062]
===
match
---
suite [17195,17456]
suite [17226,17487]
===
match
---
dictorsetmaker [74724,74742]
dictorsetmaker [76348,76366]
===
match
---
name: self [11670,11674]
name: self [11701,11705]
===
match
---
name: capacity [20421,20429]
name: capacity [20452,20460]
===
match
---
name: dag_models [67908,67918]
name: dag_models [69532,69542]
===
match
---
name: self [12718,12722]
name: self [12749,12753]
===
match
---
atom_expr [69316,69333]
atom_expr [70940,70957]
===
match
---
name: dag [46781,46784]
name: dag [46812,46815]
===
match
---
with_item [13618,13694]
with_item [13649,13725]
===
match
---
atom [19915,19929]
atom [19946,19960]
===
match
---
operator: = [21049,21050]
operator: = [21080,21081]
===
match
---
atom_expr [34795,34835]
atom_expr [34826,34866]
===
match
---
param [57750,57754]
param [57781,57785]
===
match
---
comparison [12515,12577]
comparison [12546,12608]
===
match
---
trailer [56406,56419]
trailer [56437,56450]
===
match
---
simple_stmt [28511,28786]
simple_stmt [28542,28817]
===
match
---
name: DEFAULT_DATE [53640,53652]
name: DEFAULT_DATE [53671,53683]
===
match
---
param [61267,61271]
param [61298,61302]
===
match
---
operator: = [10562,10563]
operator: = [10593,10594]
===
match
---
argument [21005,21028]
argument [21036,21059]
===
match
---
parameters [71532,71534]
parameters [73156,73158]
===
match
---
argument [76731,76750]
argument [78355,78374]
===
match
---
operator: , [62421,62422]
operator: , [62452,62453]
===
match
---
string: 'dag' [32072,32077]
string: 'dag' [32103,32108]
===
match
---
simple_stmt [47425,47455]
simple_stmt [47456,47486]
===
match
---
name: cron_timetable [50109,50123]
name: cron_timetable [50140,50154]
===
match
---
expr_stmt [78889,79052]
expr_stmt [80513,80676]
===
match
---
name: session [75681,75688]
name: session [77305,77312]
===
match
---
dictorsetmaker [13161,13179]
dictorsetmaker [13192,13210]
===
match
---
atom_expr [14232,14244]
atom_expr [14263,14275]
===
match
---
operator: } [59135,59136]
operator: } [59166,59167]
===
match
---
name: add [69172,69175]
name: add [70796,70799]
===
match
---
operator: , [67432,67433]
operator: , [69056,69057]
===
match
---
operator: = [45119,45120]
operator: = [45150,45151]
===
match
---
arith_expr [15471,15476]
arith_expr [15502,15507]
===
match
---
expr_stmt [65259,65425]
expr_stmt [66883,67049]
===
match
---
name: dag_run [44074,44081]
name: dag_run [44105,44112]
===
match
---
name: State [73801,73806]
name: State [75425,75430]
===
match
---
atom_expr [37137,37152]
atom_expr [37168,37183]
===
match
---
name: orm_dag [68512,68519]
name: orm_dag [70136,70143]
===
match
---
name: schedule_interval [44795,44812]
name: schedule_interval [44826,44843]
===
match
---
name: op1 [7026,7029]
name: op1 [7057,7060]
===
match
---
simple_stmt [37096,37186]
simple_stmt [37127,37217]
===
match
---
name: dag [41894,41897]
name: dag [41925,41928]
===
match
---
trailer [73868,73881]
trailer [75492,75505]
===
match
---
operator: , [73814,73815]
operator: , [75438,75439]
===
match
---
simple_stmt [30197,30371]
simple_stmt [30228,30402]
===
match
---
fstring_string: . [15025,15026]
fstring_string: . [15056,15057]
===
match
---
atom_expr [6701,6770]
atom_expr [6732,6801]
===
match
---
trailer [4766,4780]
trailer [4797,4811]
===
match
---
atom_expr [78452,78588]
atom_expr [80076,80212]
===
match
---
trailer [54943,54947]
trailer [54974,54978]
===
match
---
sync_comp_for [77542,77558]
sync_comp_for [79166,79182]
===
match
---
simple_stmt [74306,74317]
simple_stmt [75930,75941]
===
match
---
name: task_id [38896,38903]
name: task_id [38927,38934]
===
match
---
name: dag_id [35596,35602]
name: dag_id [35627,35633]
===
match
---
operator: , [18366,18367]
operator: , [18397,18398]
===
match
---
atom_expr [60113,60140]
atom_expr [60144,60171]
===
match
---
operator: = [21693,21694]
operator: = [21724,21725]
===
match
---
name: next_local [23816,23826]
name: next_local [23847,23857]
===
match
---
arglist [62090,62100]
arglist [62121,62131]
===
match
---
name: set2 [11022,11026]
name: set2 [11053,11057]
===
match
---
name: dag3 [60781,60785]
name: dag3 [60812,60816]
===
match
---
dotted_name [2086,2104]
dotted_name [2117,2135]
===
match
---
name: next_dagrun [45435,45446]
name: next_dagrun [45466,45477]
===
match
---
comparison [52829,52846]
comparison [52860,52877]
===
match
---
simple_stmt [45144,45161]
simple_stmt [45175,45192]
===
match
---
atom_expr [44282,44324]
atom_expr [44313,44355]
===
match
---
string: 'parameter1' [4602,4614]
string: 'parameter1' [4633,4645]
===
match
---
name: RUNNING [19263,19270]
name: RUNNING [19294,19301]
===
match
---
argument [33889,33904]
argument [33920,33935]
===
match
---
atom_expr [28430,28436]
atom_expr [28461,28467]
===
match
---
argument [5151,5164]
argument [5182,5195]
===
match
---
arglist [19359,19433]
arglist [19390,19464]
===
match
---
comparison [25775,25823]
comparison [25806,25854]
===
match
---
trailer [20692,20702]
trailer [20723,20733]
===
match
---
operator: == [57057,57059]
operator: == [57088,57090]
===
match
---
assert_stmt [76957,77023]
assert_stmt [78581,78647]
===
match
---
assert_stmt [37894,37931]
assert_stmt [37925,37962]
===
match
---
arglist [72112,72120]
arglist [73736,73744]
===
match
---
trailer [33714,33813]
trailer [33745,33844]
===
match
---
trailer [68892,68900]
trailer [70516,70524]
===
match
---
name: iter_dagrun_infos_between [78904,78929]
name: iter_dagrun_infos_between [80528,80553]
===
match
---
atom_expr [78114,78280]
atom_expr [79738,79904]
===
match
---
name: clear_db_dags [27692,27705]
name: clear_db_dags [27723,27736]
===
match
---
operator: { [28121,28122]
operator: { [28152,28153]
===
match
---
atom_expr [50705,50722]
atom_expr [50736,50753]
===
match
---
simple_stmt [11288,11322]
simple_stmt [11319,11353]
===
match
---
trailer [78242,78252]
trailer [79866,79876]
===
match
---
trailer [20116,20123]
trailer [20147,20154]
===
match
---
name: dag [64195,64198]
name: dag [65819,65822]
===
match
---
parameters [72748,72754]
parameters [74372,74378]
===
match
---
argument [8750,8768]
argument [8781,8799]
===
match
---
name: days [55446,55450]
name: days [55477,55481]
===
match
---
suite [14083,14145]
suite [14114,14176]
===
match
---
atom_expr [36995,37053]
atom_expr [37026,37084]
===
match
---
trailer [30658,30660]
trailer [30689,30691]
===
match
---
operator: = [5256,5257]
operator: = [5287,5288]
===
match
---
name: op2 [8658,8661]
name: op2 [8689,8692]
===
match
---
name: task_id [64174,64181]
name: task_id [65798,65805]
===
match
---
atom_expr [56302,56320]
atom_expr [56333,56351]
===
match
---
trailer [76904,76912]
trailer [78528,78536]
===
match
---
operator: , [22268,22269]
operator: , [22299,22300]
===
match
---
name: DagRunType [50705,50715]
name: DagRunType [50736,50746]
===
match
---
atom_expr [34225,34299]
atom_expr [34256,34330]
===
match
---
name: DAG [9321,9324]
name: DAG [9352,9355]
===
match
---
trailer [64303,64316]
trailer [65927,65940]
===
match
---
name: DAG [47533,47536]
name: DAG [47564,47567]
===
match
---
name: self [11817,11821]
name: self [11848,11852]
===
match
---
expr_stmt [69218,69271]
expr_stmt [70842,70895]
===
match
---
name: op8 [7989,7992]
name: op8 [8020,8023]
===
match
---
name: SCHEDULED [45006,45015]
name: SCHEDULED [45037,45046]
===
match
---
name: dag_id [35903,35909]
name: dag_id [35934,35940]
===
match
---
trailer [30730,30732]
trailer [30761,30763]
===
match
---
name: dagrun [76000,76006]
name: dagrun [77624,77630]
===
match
---
name: DEFAULT_ARGS [72886,72898]
name: DEFAULT_ARGS [74510,74522]
===
match
---
simple_stmt [3841,3853]
simple_stmt [3872,3884]
===
match
---
argument [64740,64784]
argument [66364,66408]
===
match
---
funcdef [56000,57288]
funcdef [56031,57319]
===
match
---
return_stmt [27292,27318]
return_stmt [27323,27349]
===
match
---
name: test_dag_id [47880,47891]
name: test_dag_id [47911,47922]
===
match
---
parameters [25984,25990]
parameters [26015,26021]
===
match
---
name: xcom_arg [73510,73518]
name: xcom_arg [75134,75142]
===
match
---
argument [68974,69007]
argument [70598,70631]
===
match
---
argument [55366,55389]
argument [55397,55420]
===
match
---
argument [64846,64863]
argument [66470,66487]
===
match
---
operator: = [20892,20893]
operator: = [20923,20924]
===
match
---
simple_stmt [13309,13319]
simple_stmt [13340,13350]
===
match
---
name: orm_dag [32654,32661]
name: orm_dag [32685,32692]
===
match
---
name: iterator [79087,79095]
name: iterator [80711,80719]
===
match
---
argument [56503,56530]
argument [56534,56561]
===
match
---
string: 't3' [42347,42351]
string: 't3' [42378,42382]
===
match
---
name: start_date [32275,32285]
name: start_date [32306,32316]
===
match
---
operator: + [17928,17929]
operator: + [17959,17960]
===
match
---
trailer [19964,19981]
trailer [19995,20012]
===
match
---
name: dag_run [42963,42970]
name: dag_run [42994,43001]
===
match
---
name: pytest [5406,5412]
name: pytest [5437,5443]
===
match
---
name: self [68016,68020]
name: self [69640,69644]
===
match
---
string: "2018-03-24T03:00:00+01:00" [25215,25242]
string: "2018-03-24T03:00:00+01:00" [25246,25273]
===
match
---
operator: , [78280,78281]
operator: , [79904,79905]
===
match
---
name: Session [18619,18626]
name: Session [18650,18657]
===
match
---
name: dag [25561,25564]
name: dag [25592,25595]
===
match
---
string: 'dag-bulk-sync-1' [29343,29360]
string: 'dag-bulk-sync-1' [29374,29391]
===
match
---
name: dag [76643,76646]
name: dag [78267,78270]
===
match
---
sync_comp_for [27929,28008]
sync_comp_for [27960,28039]
===
match
---
assert_stmt [49543,49591]
assert_stmt [49574,49622]
===
match
---
name: DummyOperator [39317,39330]
name: DummyOperator [39348,39361]
===
match
---
name: airflow [2051,2058]
name: airflow [2082,2089]
===
match
---
trailer [22233,22241]
trailer [22264,22272]
===
match
---
parameters [71176,71178]
parameters [72800,72802]
===
match
---
string: 'airflow' [67440,67449]
string: 'airflow' [69064,69073]
===
match
---
simple_stmt [43034,43180]
simple_stmt [43065,43211]
===
match
---
name: data_interval [62899,62912]
name: data_interval [62930,62943]
===
match
---
simple_stmt [46365,46416]
simple_stmt [46396,46447]
===
match
---
atom_expr [21130,21145]
atom_expr [21161,21176]
===
match
---
name: dag [7596,7599]
name: dag [7627,7630]
===
match
---
simple_stmt [47527,47569]
simple_stmt [47558,47600]
===
match
---
argument [17713,17725]
argument [17744,17756]
===
match
---
trailer [76670,76773]
trailer [78294,78397]
===
match
---
atom_expr [2899,2920]
atom_expr [2930,2951]
===
match
---
name: six_hours_ago_to_the_hour [60907,60932]
name: six_hours_ago_to_the_hour [60938,60963]
===
match
---
dotted_name [1435,1453]
dotted_name [1441,1459]
===
match
---
simple_stmt [21725,21761]
simple_stmt [21756,21792]
===
match
---
simple_stmt [39873,39907]
simple_stmt [39904,39938]
===
match
---
name: DEFAULT_DATE [56518,56530]
name: DEFAULT_DATE [56549,56561]
===
match
---
name: Param [5145,5150]
name: Param [5176,5181]
===
match
---
number: 3 [18244,18245]
number: 3 [18275,18276]
===
match
---
atom_expr [35814,35832]
atom_expr [35845,35863]
===
match
---
atom_expr [34987,35002]
atom_expr [35018,35033]
===
match
---
atom_expr [76593,76606]
atom_expr [78217,78230]
===
match
---
name: prev_local [24743,24753]
name: prev_local [24774,24784]
===
match
---
name: task_id [31140,31147]
name: task_id [31171,31178]
===
match
---
trailer [40747,40755]
trailer [40778,40786]
===
match
---
operator: = [58092,58093]
operator: = [58123,58124]
===
match
---
atom_expr [7928,7935]
atom_expr [7959,7966]
===
match
---
operator: = [78258,78259]
operator: = [79882,79883]
===
match
---
atom_expr [70946,70961]
atom_expr [72570,72585]
===
match
---
operator: = [26238,26239]
operator: = [26269,26270]
===
match
---
argument [48233,48250]
argument [48264,48281]
===
match
---
trailer [44285,44301]
trailer [44316,44332]
===
match
---
argument [38850,38862]
argument [38881,38893]
===
match
---
argument [71879,71909]
argument [73503,73533]
===
match
---
name: session [18691,18698]
name: session [18722,18729]
===
match
---
comparison [7708,7737]
comparison [7739,7768]
===
match
---
operator: , [53323,53324]
operator: , [53354,53355]
===
match
---
suite [67047,67224]
suite [68671,68848]
===
match
---
trailer [45937,45946]
trailer [45968,45977]
===
match
---
operator: = [49426,49427]
operator: = [49457,49458]
===
match
---
with_stmt [39715,40248]
with_stmt [39746,40279]
===
match
---
assert_stmt [63172,63248]
assert_stmt [63203,63279]
===
match
---
param [74284,74287]
param [75908,75911]
===
match
---
atom_expr [14481,14507]
atom_expr [14512,14538]
===
match
---
expr_stmt [48778,48802]
expr_stmt [48809,48833]
===
match
---
atom [54263,54331]
atom [54294,54362]
===
match
---
name: tags [28152,28156]
name: tags [28183,28187]
===
match
---
name: pytest [77629,77635]
name: pytest [79253,79259]
===
match
---
argument [18291,18308]
argument [18322,18339]
===
match
---
simple_stmt [10109,10143]
simple_stmt [10140,10174]
===
match
---
name: DagModel [35423,35431]
name: DagModel [35454,35462]
===
match
---
assert_stmt [12818,12858]
assert_stmt [12849,12889]
===
match
---
operator: , [51435,51436]
operator: , [51466,51467]
===
match
---
operator: { [19861,19862]
operator: { [19892,19893]
===
match
---
name: query [28745,28750]
name: query [28776,28781]
===
match
---
string: """         Test that the dag file processor creates multiple dagruns         if a dag is scheduled with 'timedelta' and catchup=True         """ [62184,62329]
string: """         Test that the dag file processor creates multiple dagruns         if a dag is scheduled with 'timedelta' and catchup=True         """ [62215,62360]
===
match
---
string: "t1" [39809,39813]
string: "t1" [39840,39844]
===
match
---
atom_expr [24430,24515]
atom_expr [24461,24546]
===
match
---
arglist [63237,63247]
arglist [63268,63278]
===
match
---
trailer [24753,24763]
trailer [24784,24794]
===
match
---
name: dag_id [52987,52993]
name: dag_id [53018,53024]
===
match
---
operator: = [50977,50978]
operator: = [51008,51009]
===
match
---
name: datetime [62674,62682]
name: datetime [62705,62713]
===
match
---
operator: , [35101,35102]
operator: , [35132,35133]
===
match
---
trailer [13358,13366]
trailer [13389,13397]
===
match
---
argument [71475,71505]
argument [73099,73129]
===
match
---
operator: @ [3141,3142]
operator: @ [3172,3173]
===
match
---
expr_stmt [22978,23013]
expr_stmt [23009,23044]
===
match
---
name: session [37752,37759]
name: session [37783,37790]
===
match
---
name: instance [79003,79011]
name: instance [80627,80635]
===
match
---
operator: + [14430,14431]
operator: + [14461,14462]
===
match
---
number: 2016 [64338,64342]
number: 2016 [65962,65966]
===
match
---
atom [35500,35519]
atom [35531,35550]
===
match
---
simple_stmt [19993,20029]
simple_stmt [20024,20060]
===
match
---
name: task_id [21746,21753]
name: task_id [21777,21784]
===
match
---
atom_expr [61615,61632]
atom_expr [61646,61663]
===
match
---
atom_expr [23559,23585]
atom_expr [23590,23616]
===
match
---
name: DEFAULT_DATE [41877,41889]
name: DEFAULT_DATE [41908,41920]
===
match
---
name: operator [70975,70983]
name: operator [72599,72607]
===
match
---
name: extend [11053,11059]
name: extend [11084,11090]
===
match
---
operator: , [54389,54390]
operator: , [54420,54421]
===
match
---
name: owner [33577,33582]
name: owner [33608,33613]
===
match
---
atom_expr [19561,19574]
atom_expr [19592,19605]
===
match
---
atom_expr [58582,58610]
atom_expr [58613,58641]
===
match
---
trailer [43605,43607]
trailer [43636,43638]
===
match
---
atom_expr [55783,55795]
atom_expr [55814,55826]
===
match
---
trailer [52183,52189]
trailer [52214,52220]
===
match
---
name: datetime [77871,77879]
name: datetime [79495,79503]
===
match
---
expr_stmt [39827,39860]
expr_stmt [39858,39891]
===
match
---
name: utc [22806,22809]
name: utc [22837,22840]
===
match
---
operator: = [45834,45835]
operator: = [45865,45866]
===
match
---
operator: = [26188,26189]
operator: = [26219,26220]
===
match
---
trailer [63202,63215]
trailer [63233,63246]
===
match
---
assert_stmt [45471,45532]
assert_stmt [45502,45563]
===
match
---
name: run_id [18379,18385]
name: run_id [18410,18416]
===
match
---
trailer [36291,36302]
trailer [36322,36333]
===
match
---
expr_stmt [67497,67772]
expr_stmt [69121,69396]
===
match
---
name: task_id [32518,32525]
name: task_id [32549,32556]
===
match
---
number: 3 [28977,28978]
number: 3 [29008,29009]
===
match
---
name: op2 [9870,9873]
name: op2 [9901,9904]
===
match
---
string: 'airflow' [68177,68186]
string: 'airflow' [69801,69810]
===
match
---
name: new_value [74911,74920]
name: new_value [76535,76544]
===
match
---
trailer [47378,47386]
trailer [47409,47417]
===
match
---
operator: = [24924,24925]
operator: = [24955,24956]
===
match
---
trailer [41498,41512]
trailer [41529,41543]
===
match
---
name: timedelta [77995,78004]
name: timedelta [79619,79628]
===
match
---
simple_stmt [56930,57111]
simple_stmt [56961,57142]
===
match
---
funcdef [73449,73497]
funcdef [75073,75121]
===
match
---
string: "0 0 1 */3 *" [50124,50137]
string: "0 0 1 */3 *" [50155,50168]
===
match
---
name: hash [49361,49365]
name: hash [49392,49396]
===
match
---
atom_expr [59155,59365]
atom_expr [59186,59396]
===
match
---
operator: , [21003,21004]
operator: , [21034,21035]
===
match
---
atom [66903,66935]
atom [68527,68559]
===
match
---
simple_stmt [70946,70962]
simple_stmt [72570,72586]
===
match
---
operator: - [14078,14079]
operator: - [14109,14110]
===
match
---
name: subdag [53430,53436]
name: subdag [53461,53467]
===
match
---
operator: = [48162,48163]
operator: = [48193,48194]
===
match
---
trailer [15126,15135]
trailer [15157,15166]
===
match
---
simple_stmt [72130,72165]
simple_stmt [73754,73789]
===
match
---
trailer [69624,69654]
trailer [71248,71278]
===
match
---
simple_stmt [8810,8884]
simple_stmt [8841,8915]
===
match
---
operator: = [25724,25725]
operator: = [25755,25756]
===
match
---
trailer [37875,37885]
trailer [37906,37916]
===
match
---
name: dag [11390,11393]
name: dag [11421,11424]
===
match
---
name: delta [44813,44818]
name: delta [44844,44849]
===
match
---
string: """Test that set_task_instance_state updates the TaskInstance state and clear downstream failed""" [75458,75556]
string: """Test that set_task_instance_state updates the TaskInstance state and clear downstream failed""" [77082,77180]
===
match
---
expr_stmt [9519,9551]
expr_stmt [9550,9582]
===
match
---
name: self [55275,55279]
name: self [55306,55310]
===
match
---
simple_stmt [7432,7454]
simple_stmt [7463,7485]
===
match
---
with_stmt [20984,21117]
with_stmt [21015,21148]
===
match
---
operator: = [27480,27481]
operator: = [27511,27512]
===
match
---
operator: == [25904,25906]
operator: == [25935,25937]
===
match
---
trailer [56683,56690]
trailer [56714,56721]
===
match
---
operator: = [28156,28157]
operator: = [28187,28188]
===
match
---
name: dag [65242,65245]
name: dag [66866,66869]
===
match
---
arith_expr [46964,46996]
arith_expr [46995,47027]
===
match
---
atom [28518,28729]
atom [28549,28760]
===
match
---
atom_expr [4109,4131]
atom_expr [4140,4162]
===
match
---
argument [65340,65410]
argument [66964,67034]
===
match
---
comp_op [49580,49586]
comp_op [49611,49617]
===
match
---
name: run_type [52014,52022]
name: run_type [52045,52053]
===
match
---
operator: = [18844,18845]
operator: = [18875,18876]
===
match
---
trailer [76619,76625]
trailer [78243,78249]
===
match
---
arglist [32244,32299]
arglist [32275,32330]
===
match
---
parameters [2827,2833]
parameters [2858,2864]
===
match
---
name: self [30823,30827]
name: self [30854,30858]
===
match
---
arglist [78858,78882]
arglist [80482,80506]
===
match
---
operator: = [48123,48124]
operator: = [48154,48155]
===
match
---
trailer [25891,25901]
trailer [25922,25932]
===
match
---
name: test_set_dag_id [71354,71369]
name: test_set_dag_id [72978,72993]
===
match
---
param [27187,27192]
param [27218,27223]
===
match
---
expr_stmt [60521,60563]
expr_stmt [60552,60594]
===
match
---
operator: = [47059,47060]
operator: = [47090,47091]
===
match
---
name: isoformat [27608,27617]
name: isoformat [27639,27648]
===
match
---
operator: , [16524,16525]
operator: , [16555,16556]
===
match
---
atom_expr [35406,35421]
atom_expr [35437,35452]
===
match
---
atom_expr [35871,35911]
atom_expr [35902,35942]
===
match
---
expr_stmt [38025,38098]
expr_stmt [38056,38129]
===
match
---
name: dr [31687,31689]
name: dr [31718,31720]
===
match
---
trailer [59609,59616]
trailer [59640,59647]
===
match
---
trailer [17948,17956]
trailer [17979,17987]
===
match
---
trailer [8981,8995]
trailer [9012,9026]
===
match
---
expr_stmt [59028,59136]
expr_stmt [59059,59167]
===
match
---
fstring_string: dag_run.execution_date did not match expectation:  [43104,43154]
fstring_string: dag_run.execution_date did not match expectation:  [43135,43185]
===
match
---
operator: , [56208,56209]
operator: , [56239,56240]
===
match
---
arglist [68110,68120]
arglist [69734,69744]
===
match
---
name: instance [78957,78965]
name: instance [80581,80589]
===
match
---
name: run_id [18174,18180]
name: run_id [18205,18211]
===
match
---
arglist [12796,12806]
arglist [12827,12837]
===
match
---
arglist [76033,76082]
arglist [77657,77706]
===
match
---
expr_stmt [51880,51925]
expr_stmt [51911,51956]
===
match
---
name: timedelta [78363,78372]
name: timedelta [79987,79996]
===
match
---
argument [33672,33686]
argument [33703,33717]
===
match
---
name: self [74954,74958]
name: self [76578,76582]
===
match
---
name: i [15471,15472]
name: i [15502,15503]
===
match
---
atom_expr [56356,56541]
atom_expr [56387,56572]
===
match
---
trailer [10577,10590]
trailer [10608,10621]
===
match
---
name: dag [32451,32454]
name: dag [32482,32485]
===
match
---
argument [15056,15078]
argument [15087,15109]
===
match
---
operator: + [58006,58007]
operator: + [58037,58038]
===
match
---
name: orm_subdag [33021,33031]
name: orm_subdag [33052,33062]
===
match
---
name: pathlib [954,961]
name: pathlib [954,961]
===
match
---
operator: , [5436,5437]
operator: , [5467,5468]
===
match
---
expr_stmt [13346,13388]
expr_stmt [13377,13419]
===
match
---
name: timedelta [31849,31858]
name: timedelta [31880,31889]
===
match
---
name: DummyOperator [7848,7861]
name: DummyOperator [7879,7892]
===
match
---
comparison [49250,49275]
comparison [49281,49306]
===
match
---
atom_expr [26127,26148]
atom_expr [26158,26179]
===
match
---
name: NONE [55864,55868]
name: NONE [55895,55899]
===
match
---
trailer [44229,44245]
trailer [44260,44276]
===
match
---
name: dags [29256,29260]
name: dags [29287,29291]
===
match
---
simple_stmt [76879,76913]
simple_stmt [78503,78537]
===
match
---
simple_stmt [51709,51748]
simple_stmt [51740,51779]
===
match
---
argument [74685,74704]
argument [76309,76328]
===
match
---
number: 2038 [67373,67377]
number: 2038 [68997,69001]
===
match
---
argument [18094,18100]
argument [18125,18131]
===
match
---
name: hours [57916,57921]
name: hours [57947,57952]
===
match
---
name: isoformat [26289,26298]
name: isoformat [26320,26329]
===
match
---
name: task_id [40748,40755]
name: task_id [40779,40786]
===
match
---
trailer [56603,56659]
trailer [56634,56690]
===
match
---
name: make_dag [59894,59902]
name: make_dag [59925,59933]
===
match
---
operator: , [53583,53584]
operator: , [53614,53615]
===
match
---
atom_expr [66637,66669]
atom_expr [68261,68293]
===
match
---
trailer [42217,42233]
trailer [42248,42264]
===
match
---
name: t_1 [56604,56607]
name: t_1 [56635,56638]
===
match
---
trailer [41240,41248]
trailer [41271,41279]
===
match
---
name: task_3 [76472,76478]
name: task_3 [78096,78102]
===
match
---
arglist [13816,13824]
arglist [13847,13855]
===
match
---
name: session [3241,3248]
name: session [3272,3279]
===
match
---
classdef [47756,47797]
classdef [47787,47828]
===
match
---
trailer [54488,54497]
trailer [54519,54528]
===
match
---
name: is_active [37876,37885]
name: is_active [37907,37916]
===
match
---
simple_stmt [21774,21823]
simple_stmt [21805,21854]
===
match
---
arglist [17263,17327]
arglist [17294,17358]
===
match
---
atom_expr [67961,67976]
atom_expr [69585,69600]
===
match
---
name: DEFAULT_DATE [45450,45462]
name: DEFAULT_DATE [45481,45493]
===
match
---
atom_expr [12873,12925]
atom_expr [12904,12956]
===
match
---
operator: = [68829,68830]
operator: = [70453,70454]
===
match
---
trailer [48213,48251]
trailer [48244,48282]
===
match
---
name: dag_id [49472,49478]
name: dag_id [49503,49509]
===
match
---
atom [70142,70147]
atom [71766,71771]
===
match
---
simple_stmt [48958,48990]
simple_stmt [48989,49021]
===
match
---
with_stmt [36937,37186]
with_stmt [36968,37217]
===
match
---
name: f [20857,20858]
name: f [20888,20889]
===
match
---
string: "test_schedule_dag_relativedelta" [25479,25512]
string: "test_schedule_dag_relativedelta" [25510,25543]
===
match
---
trailer [29473,29475]
trailer [29504,29506]
===
match
---
name: state [51154,51159]
name: state [51185,51190]
===
match
---
simple_stmt [42003,42037]
simple_stmt [42034,42068]
===
match
---
trailer [7545,7592]
trailer [7576,7623]
===
match
---
operator: = [67325,67326]
operator: = [68949,68950]
===
match
---
string: '0 3 * * *' [23530,23541]
string: '0 3 * * *' [23561,23572]
===
match
---
suite [6226,6449]
suite [6257,6480]
===
match
---
operator: , [52509,52510]
operator: , [52540,52541]
===
match
---
atom_expr [13852,13867]
atom_expr [13883,13898]
===
match
---
trailer [10736,10741]
trailer [10767,10772]
===
match
---
fstring [43102,43179]
fstring [43133,43210]
===
match
---
trailer [20108,20116]
trailer [20139,20147]
===
match
---
operator: , [75648,75649]
operator: , [77272,77273]
===
match
---
string: 'params' [4707,4715]
string: 'params' [4738,4746]
===
match
---
name: dag2 [6974,6978]
name: dag2 [7005,7009]
===
match
---
string: "0 0 * * 0" [50012,50023]
string: "0 0 * * 0" [50043,50054]
===
match
---
trailer [45081,45089]
trailer [45112,45120]
===
match
---
atom [29323,29399]
atom [29354,29430]
===
match
---
operator: , [18043,18044]
operator: , [18074,18075]
===
match
---
atom_expr [47930,47965]
atom_expr [47961,47996]
===
match
---
atom_expr [36288,36304]
atom_expr [36319,36335]
===
match
---
atom_expr [35392,35554]
atom_expr [35423,35585]
===
match
---
operator: = [53821,53822]
operator: = [53852,53853]
===
match
---
name: dag [5728,5731]
name: dag [5759,5762]
===
match
---
trailer [23340,23348]
trailer [23371,23379]
===
match
---
operator: = [17740,17741]
operator: = [17771,17772]
===
match
---
name: local_tz [38324,38332]
name: local_tz [38355,38363]
===
match
---
operator: , [58992,58993]
operator: , [59023,59024]
===
match
---
parameters [51261,51267]
parameters [51292,51298]
===
match
---
dotted_name [1896,1912]
dotted_name [1902,1918]
===
match
---
atom_expr [36983,37054]
atom_expr [37014,37085]
===
match
---
name: dag [78900,78903]
name: dag [80524,80527]
===
match
---
trailer [49783,49810]
trailer [49814,49841]
===
match
---
simple_stmt [31747,31798]
simple_stmt [31778,31829]
===
match
---
name: test_leaves [39150,39161]
name: test_leaves [39181,39192]
===
match
---
operator: , [55453,55454]
operator: , [55484,55485]
===
match
---
name: execution_date [17900,17914]
name: execution_date [17931,17945]
===
match
---
trailer [66177,66208]
trailer [67801,67832]
===
match
---
atom_expr [43278,43289]
atom_expr [43309,43320]
===
match
---
name: create_dagrun [74526,74539]
name: create_dagrun [76150,76163]
===
match
---
expr_stmt [51277,51288]
expr_stmt [51308,51319]
===
match
---
operator: , [37033,37034]
operator: , [37064,37065]
===
match
---
name: op5 [39087,39090]
name: op5 [39118,39121]
===
match
---
string: 'test-dag2' [30578,30589]
string: 'test-dag2' [30609,30620]
===
match
---
number: 1 [78567,78568]
number: 1 [80191,80192]
===
match
---
operator: { [27881,27882]
operator: { [27912,27913]
===
match
---
name: self [2988,2992]
name: self [3019,3023]
===
match
---
name: keep_trailing_newline [20360,20381]
name: keep_trailing_newline [20391,20412]
===
match
---
operator: = [19753,19754]
operator: = [19784,19785]
===
match
---
name: timezone [2072,2080]
name: timezone [2103,2111]
===
match
---
trailer [56968,56974]
trailer [56999,57005]
===
match
---
trailer [78372,78381]
trailer [79996,80005]
===
match
---
name: test_task_id [17699,17711]
name: test_task_id [17730,17742]
===
match
---
atom_expr [41683,41694]
atom_expr [41714,41725]
===
match
---
name: conf [32918,32922]
name: conf [32949,32953]
===
match
---
simple_stmt [71637,71651]
simple_stmt [73261,73275]
===
match
---
operator: + [18073,18074]
operator: + [18104,18105]
===
match
---
trailer [10843,10860]
trailer [10874,10891]
===
match
---
name: datetime [23349,23357]
name: datetime [23380,23388]
===
match
---
name: session [68874,68881]
name: session [70498,70505]
===
match
---
suite [8270,8361]
suite [8301,8392]
===
match
---
arglist [67408,67449]
arglist [69032,69073]
===
match
---
string: 'owner2' [32788,32796]
string: 'owner2' [32819,32827]
===
match
---
arglist [17765,17820]
arglist [17796,17851]
===
match
---
operator: = [33896,33897]
operator: = [33927,33928]
===
match
---
operator: , [62690,62691]
operator: , [62721,62722]
===
match
---
name: tags [27770,27774]
name: tags [27801,27805]
===
match
---
argument [32186,32200]
argument [32217,32231]
===
match
---
name: session [37625,37632]
name: session [37656,37663]
===
match
---
simple_stmt [36288,36305]
simple_stmt [36319,36336]
===
match
---
suite [61273,62054]
suite [61304,62085]
===
match
---
name: task_id [41738,41745]
name: task_id [41769,41776]
===
match
---
trailer [78308,78317]
trailer [79932,79941]
===
match
---
operator: , [57432,57433]
operator: , [57463,57464]
===
match
---
name: tearDown [3027,3035]
name: tearDown [3058,3066]
===
match
---
name: hours [78069,78074]
name: hours [79693,79698]
===
match
---
operator: } [14894,14895]
operator: } [14925,14926]
===
match
---
string: 'test_get_dates' [78768,78784]
string: 'test_get_dates' [80392,80408]
===
match
---
operator: , [69772,69773]
operator: , [71396,71397]
===
match
---
fstring_string: . [16354,16355]
fstring_string: . [16385,16386]
===
match
---
operator: = [68949,68950]
operator: = [70573,70574]
===
match
---
name: self [5904,5908]
name: self [5935,5939]
===
match
---
name: task_id [75925,75932]
name: task_id [77549,77556]
===
match
---
parameters [5903,5909]
parameters [5934,5940]
===
match
---
name: DummyOperator [16297,16310]
name: DummyOperator [16328,16341]
===
match
---
argument [67639,67665]
argument [69263,69289]
===
match
---
name: test_dag_topological_sort2 [10194,10220]
name: test_dag_topological_sort2 [10225,10251]
===
match
---
operator: , [21871,21872]
operator: , [21902,21903]
===
match
---
simple_stmt [58478,58497]
simple_stmt [58509,58528]
===
match
---
suite [69963,70614]
suite [71587,72238]
===
match
---
argument [76704,76729]
argument [78328,78353]
===
match
---
operator: , [26513,26514]
operator: , [26544,26545]
===
match
---
name: t [27926,27927]
name: t [27957,27958]
===
match
---
trailer [51448,51453]
trailer [51479,51484]
===
match
---
operator: < [60752,60753]
operator: < [60783,60784]
===
match
---
suite [57330,57703]
suite [57361,57734]
===
match
---
expr_stmt [57889,57924]
expr_stmt [57920,57955]
===
match
---
simple_stmt [21933,21963]
simple_stmt [21964,21994]
===
match
---
fstring [19724,19739]
fstring [19755,19770]
===
match
---
name: dump [48778,48782]
name: dump [48809,48813]
===
match
---
operator: , [60051,60052]
operator: , [60082,60083]
===
match
---
name: dag_id [68755,68761]
name: dag_id [70379,70385]
===
match
---
name: self [66827,66831]
name: self [68451,68455]
===
match
---
trailer [77286,77292]
trailer [78910,78916]
===
match
---
argument [24609,24638]
argument [24640,24669]
===
match
---
simple_stmt [46520,46543]
simple_stmt [46551,46574]
===
match
---
trailer [69952,69961]
trailer [71576,71585]
===
match
---
name: DummyOperator [78844,78857]
name: DummyOperator [80468,80481]
===
match
---
simple_stmt [44226,44270]
simple_stmt [44257,44301]
===
match
---
param [3569,3571]
param [3600,3602]
===
match
---
expr_stmt [75902,75942]
expr_stmt [77526,77566]
===
match
---
trailer [35274,35287]
trailer [35305,35318]
===
match
---
name: t [77536,77537]
name: t [79160,79161]
===
match
---
name: utc [24678,24681]
name: utc [24709,24712]
===
match
---
argument [54071,54098]
argument [54102,54129]
===
match
---
atom_expr [71637,71650]
atom_expr [73261,73274]
===
match
---
name: delta_timetable [50276,50291]
name: delta_timetable [50307,50322]
===
match
---
operator: = [59686,59687]
operator: = [59717,59718]
===
match
---
funcdef [68605,69516]
funcdef [70229,71140]
===
match
---
name: dag [38465,38468]
name: dag [38496,38499]
===
match
---
arglist [50448,50509]
arglist [50479,50540]
===
match
---
number: 3 [26508,26509]
number: 3 [26539,26540]
===
match
---
arglist [54066,54119]
arglist [54097,54150]
===
match
---
atom_expr [9615,9641]
atom_expr [9646,9672]
===
match
---
trailer [30693,30699]
trailer [30724,30730]
===
match
---
operator: = [59815,59816]
operator: = [59846,59847]
===
match
---
operator: , [54753,54754]
operator: , [54784,54785]
===
match
---
name: start [26262,26267]
name: start [26293,26298]
===
match
---
name: timezone [24388,24396]
name: timezone [24419,24427]
===
match
---
atom [31731,31736]
atom [31762,31767]
===
match
---
name: set_upstream [14121,14133]
name: set_upstream [14152,14164]
===
match
---
name: pattern [14218,14225]
name: pattern [14249,14256]
===
match
---
simple_stmt [65570,65594]
simple_stmt [67194,67218]
===
match
---
trailer [27847,27849]
trailer [27878,27880]
===
match
---
name: get_ti_from_db [76514,76528]
name: get_ti_from_db [78138,78152]
===
match
---
simple_stmt [2386,2424]
simple_stmt [2417,2455]
===
match
---
param [55200,55213]
param [55231,55244]
===
match
---
suite [44510,45565]
suite [44541,45596]
===
match
---
trailer [16897,16907]
trailer [16928,16938]
===
match
---
operator: == [18780,18782]
operator: == [18811,18813]
===
match
---
testlist_comp [55850,55926]
testlist_comp [55881,55957]
===
match
---
suite [27683,28023]
suite [27714,28054]
===
match
---
name: convert_to_utc [24540,24554]
name: convert_to_utc [24571,24585]
===
match
---
trailer [57234,57240]
trailer [57265,57271]
===
match
---
comparison [38627,38661]
comparison [38658,38692]
===
match
---
name: set_upstream [16845,16857]
name: set_upstream [16876,16888]
===
match
---
name: DEFAULT_DATE [69084,69096]
name: DEFAULT_DATE [70708,70720]
===
match
---
parameters [71590,71595]
parameters [73214,73219]
===
match
---
name: dag2 [7938,7942]
name: dag2 [7969,7973]
===
match
---
trailer [49254,49262]
trailer [49285,49293]
===
match
---
expr_stmt [69844,69865]
expr_stmt [71468,71489]
===
match
---
atom_expr [63766,63822]
atom_expr [65390,65446]
===
match
---
trailer [45546,45556]
trailer [45577,45587]
===
match
---
name: op1 [41473,41476]
name: op1 [41504,41507]
===
match
---
atom_expr [16894,16916]
atom_expr [16925,16947]
===
match
---
atom_expr [29453,29468]
atom_expr [29484,29499]
===
match
---
argument [19035,19050]
argument [19066,19081]
===
match
---
string: "2015-01-02T01:00:00+00:00" [25796,25823]
string: "2015-01-02T01:00:00+00:00" [25827,25854]
===
match
---
operator: , [11405,11406]
operator: , [11436,11437]
===
match
---
suite [4936,5265]
suite [4967,5296]
===
match
---
name: self [40835,40839]
name: self [40866,40870]
===
match
---
trailer [21178,21194]
trailer [21209,21225]
===
match
---
expr_stmt [20300,20334]
expr_stmt [20331,20365]
===
match
---
atom_expr [68207,68225]
atom_expr [69831,69849]
===
match
---
name: next_dagrun [31577,31588]
name: next_dagrun [31608,31619]
===
match
---
string: 'parameter1' [4767,4779]
string: 'parameter1' [4798,4810]
===
match
---
trailer [62603,62609]
trailer [62634,62640]
===
match
---
operator: == [20430,20432]
operator: == [20461,20463]
===
match
---
expr_stmt [39873,39906]
expr_stmt [39904,39937]
===
match
---
atom_expr [21554,21560]
atom_expr [21585,21591]
===
match
---
if_stmt [16671,16711]
if_stmt [16702,16742]
===
match
---
operator: = [17914,17915]
operator: = [17945,17946]
===
match
---
simple_stmt [43278,43290]
simple_stmt [43309,43321]
===
match
---
name: jinja_env [20044,20053]
name: jinja_env [20075,20084]
===
match
---
name: get_ti_from_db [76360,76374]
name: get_ti_from_db [77984,77998]
===
match
---
trailer [13621,13687]
trailer [13652,13718]
===
match
---
name: dag [5849,5852]
name: dag [5880,5883]
===
match
---
operator: , [18835,18836]
operator: , [18866,18867]
===
match
---
arith_expr [77856,77898]
arith_expr [79480,79522]
===
match
---
trailer [66451,66471]
trailer [68075,68095]
===
match
---
name: dag [38627,38630]
name: dag [38658,38661]
===
match
---
trailer [24165,24175]
trailer [24196,24206]
===
match
---
name: dag_pickle [47577,47587]
name: dag_pickle [47608,47618]
===
match
---
trailer [27617,27619]
trailer [27648,27650]
===
match
---
operator: { [64749,64750]
operator: { [66373,66374]
===
match
---
string: 'owner1' [10301,10309]
string: 'owner1' [10332,10340]
===
match
---
name: op2 [41479,41482]
name: op2 [41510,41513]
===
match
---
expr_stmt [7885,7919]
expr_stmt [7916,7950]
===
match
---
name: dr3 [17975,17978]
name: dr3 [18006,18009]
===
match
---
trailer [74658,74671]
trailer [76282,76295]
===
match
---
name: DEFAULT_DATE [77716,77728]
name: DEFAULT_DATE [79340,79352]
===
match
---
suite [38315,38662]
suite [38346,38693]
===
match
---
name: self [17493,17497]
name: self [17524,17528]
===
match
---
trailer [58417,58427]
trailer [58448,58458]
===
match
---
name: conf [1371,1375]
name: conf [1377,1381]
===
match
---
simple_stmt [54968,55005]
simple_stmt [54999,55036]
===
match
---
name: op1 [41571,41574]
name: op1 [41602,41605]
===
match
---
name: MANUAL [53796,53802]
name: MANUAL [53827,53833]
===
match
---
atom_expr [35682,35745]
atom_expr [35713,35776]
===
match
---
name: DEFAULT_DATE [18205,18217]
name: DEFAULT_DATE [18236,18248]
===
match
---
atom_expr [11129,11148]
atom_expr [11160,11179]
===
match
---
name: set_is_paused [35716,35729]
name: set_is_paused [35747,35760]
===
match
---
name: dag [50438,50441]
name: dag [50469,50472]
===
match
---
name: Path [969,973]
name: Path [969,973]
===
match
---
expr_stmt [21523,21561]
expr_stmt [21554,21592]
===
match
---
name: task_dict [41720,41729]
name: task_dict [41751,41760]
===
match
---
suite [44061,44325]
suite [44092,44356]
===
match
---
trailer [34104,34106]
trailer [34135,34137]
===
match
---
operator: == [18871,18873]
operator: == [18902,18904]
===
match
---
name: self [41313,41317]
name: self [41344,41348]
===
match
---
operator: == [27900,27902]
operator: == [27931,27933]
===
match
---
simple_stmt [50974,51037]
simple_stmt [51005,51068]
===
match
---
simple_stmt [2759,2778]
simple_stmt [2790,2809]
===
match
---
trailer [23719,23729]
trailer [23750,23760]
===
match
---
comparison [38524,38558]
comparison [38555,38589]
===
match
---
atom [77692,78621]
atom [79316,80245]
===
match
---
simple_stmt [33187,33215]
simple_stmt [33218,33246]
===
match
---
operator: = [76687,76688]
operator: = [78311,78312]
===
match
---
trailer [49626,49645]
trailer [49657,49676]
===
match
---
atom_expr [8900,8961]
atom_expr [8931,8992]
===
match
---
name: op4 [7408,7411]
name: op4 [7439,7442]
===
match
---
trailer [40106,40112]
trailer [40137,40143]
===
match
---
name: task [21130,21134]
name: task [21161,21165]
===
match
---
param [6486,6490]
param [6517,6521]
===
match
---
expr_stmt [70905,70915]
expr_stmt [72529,72539]
===
match
---
string: """         Test if there is a DAG with not None schedule_interval and have some params that         don't have a default value raise a error while DAG parsing         """ [4945,5116]
string: """         Test if there is a DAG with not None schedule_interval and have some params that         don't have a default value raise a error while DAG parsing         """ [4976,5147]
===
match
---
trailer [7233,7239]
trailer [7264,7270]
===
match
---
name: strip [72677,72682]
name: strip [74301,74306]
===
match
---
name: child_dag [8260,8269]
name: child_dag [8291,8300]
===
match
---
operator: = [13792,13793]
operator: = [13823,13824]
===
match
---
expr_stmt [48177,48251]
expr_stmt [48208,48282]
===
match
---
operator: , [47548,47549]
operator: , [47579,47580]
===
match
---
atom_expr [78354,78381]
atom_expr [79978,80005]
===
match
---
name: dag [33874,33877]
name: dag [33905,33908]
===
match
---
atom_expr [75364,75383]
atom_expr [76988,77007]
===
match
---
string: """Verify that same tasks with Duplicate task_id do not raise error""" [41328,41398]
string: """Verify that same tasks with Duplicate task_id do not raise error""" [41359,41429]
===
match
---
name: sync_to_db [37741,37751]
name: sync_to_db [37772,37782]
===
match
---
name: e [3809,3810]
name: e [3840,3841]
===
match
---
name: task_id [39377,39384]
name: task_id [39408,39415]
===
match
---
operator: } [4617,4618]
operator: } [4648,4649]
===
match
---
name: get_ti_from_db [77264,77278]
name: get_ti_from_db [78888,78902]
===
match
---
with_stmt [30074,30143]
with_stmt [30105,30174]
===
match
---
import_from [2131,2196]
import_from [2162,2227]
===
match
---
operator: = [21109,21110]
operator: = [21140,21141]
===
match
---
operator: , [45980,45981]
operator: , [46011,46012]
===
match
---
operator: = [59743,59744]
operator: = [59774,59775]
===
match
---
assert_stmt [24736,24796]
assert_stmt [24767,24827]
===
match
---
param [30823,30827]
param [30854,30858]
===
match
---
name: DummyOperator [41485,41498]
name: DummyOperator [41516,41529]
===
match
---
expr_stmt [11022,11039]
expr_stmt [11053,11070]
===
match
---
trailer [14485,14507]
trailer [14516,14538]
===
match
---
suite [16681,16711]
suite [16712,16742]
===
match
---
simple_stmt [22978,23014]
simple_stmt [23009,23045]
===
match
---
trailer [46478,46503]
trailer [46509,46534]
===
match
---
string: 'DAG' [11689,11694]
string: 'DAG' [11720,11725]
===
match
---
atom [55623,55767]
atom [55654,55798]
===
match
---
with_stmt [8255,8361]
with_stmt [8286,8392]
===
match
---
arglist [57362,57459]
arglist [57393,57490]
===
match
---
trailer [51760,51770]
trailer [51791,51801]
===
match
---
suite [33397,34107]
suite [33428,34138]
===
match
---
trailer [76338,76342]
trailer [77962,77966]
===
match
---
name: dag_id [3473,3479]
name: dag_id [3504,3510]
===
match
---
name: FAILED [53609,53615]
name: FAILED [53640,53646]
===
match
---
operator: , [22272,22273]
operator: , [22303,22304]
===
match
---
funcdef [3159,3525]
funcdef [3190,3556]
===
match
---
trailer [24387,24396]
trailer [24418,24427]
===
match
---
name: add_task [44857,44865]
name: add_task [44888,44896]
===
match
---
name: dag [14900,14903]
name: dag [14931,14934]
===
match
---
operator: = [38597,38598]
operator: = [38628,38629]
===
match
---
operator: { [30390,30391]
operator: { [30421,30422]
===
match
---
name: remove [10985,10991]
name: remove [11016,11022]
===
match
---
atom_expr [11568,11621]
atom_expr [11599,11652]
===
match
---
name: orm_dag [67793,67800]
name: orm_dag [69417,69424]
===
match
---
return_stmt [65012,65029]
return_stmt [66636,66653]
===
match
---
expr_stmt [51810,51871]
expr_stmt [51841,51902]
===
match
---
simple_stmt [17830,17967]
simple_stmt [17861,17998]
===
match
---
comparison [47198,47230]
comparison [47229,47261]
===
match
---
trailer [76157,76161]
trailer [77781,77785]
===
match
---
comparison [15910,15945]
comparison [15941,15976]
===
match
---
operator: , [75977,75978]
operator: , [77601,77602]
===
match
---
string: """         Tests scheduling a dag with no previous runs         """ [42453,42521]
string: """         Tests scheduling a dag with no previous runs         """ [42484,42552]
===
match
---
name: match [14210,14215]
name: match [14241,14246]
===
match
---
name: dag [71733,71736]
name: dag [73357,73360]
===
match
---
operator: , [35510,35511]
operator: , [35541,35542]
===
match
---
name: topological_list [11081,11097]
name: topological_list [11112,11128]
===
match
---
atom [59043,59136]
atom [59074,59167]
===
match
---
trailer [24438,24446]
trailer [24469,24477]
===
match
---
operator: = [71487,71488]
operator: = [73111,73112]
===
match
---
trailer [49766,49776]
trailer [49797,49807]
===
match
---
name: op3 [59489,59492]
name: op3 [59520,59523]
===
match
---
with_item [21411,21454]
with_item [21442,21485]
===
match
---
trailer [23348,23418]
trailer [23379,23449]
===
match
---
arglist [8135,8235]
arglist [8166,8266]
===
match
---
operator: = [55450,55451]
operator: = [55481,55482]
===
match
---
trailer [76536,76542]
trailer [78160,78166]
===
match
---
name: utc [23581,23584]
name: utc [23612,23615]
===
match
---
testlist_comp [69684,69718]
testlist_comp [71308,71342]
===
match
---
number: 0 [11009,11010]
number: 0 [11040,11041]
===
match
---
trailer [50310,50318]
trailer [50341,50349]
===
match
---
comp_op [34024,34030]
comp_op [34055,34061]
===
match
---
operator: , [53912,53913]
operator: , [53943,53944]
===
match
---
operator: , [74810,74811]
operator: , [76434,76435]
===
match
---
operator: = [54668,54669]
operator: = [54699,54700]
===
match
---
trailer [46380,46386]
trailer [46411,46417]
===
match
---
name: RUNNING [55116,55123]
name: RUNNING [55147,55154]
===
match
---
name: name [38640,38644]
name: name [38671,38675]
===
match
---
testlist_comp [46402,46413]
testlist_comp [46433,46444]
===
match
---
dotted_name [1342,1363]
dotted_name [1348,1369]
===
match
---
name: dag [6695,6698]
name: dag [6726,6729]
===
match
---
name: TEST_DATE [67199,67208]
name: TEST_DATE [68823,68832]
===
match
---
parameters [11552,11558]
parameters [11583,11589]
===
match
---
argument [51394,51435]
argument [51425,51466]
===
match
---
trailer [44047,44049]
trailer [44078,44080]
===
match
---
expr_stmt [31192,31220]
expr_stmt [31223,31251]
===
match
---
name: remove [9943,9949]
name: remove [9974,9980]
===
match
---
operator: - [59660,59661]
operator: - [59691,59692]
===
match
---
suite [29303,29977]
suite [29334,30008]
===
match
---
argument [17410,17431]
argument [17441,17462]
===
match
---
assert_stmt [48682,48708]
assert_stmt [48713,48739]
===
match
---
operator: , [56636,56637]
operator: , [56667,56668]
===
match
---
atom_expr [35783,35945]
atom_expr [35814,35976]
===
match
---
number: 42 [70913,70915]
number: 42 [72537,72539]
===
match
---
operator: = [59781,59782]
operator: = [59812,59813]
===
match
---
trailer [11182,11185]
trailer [11213,11216]
===
match
---
name: dag_id [29949,29955]
name: dag_id [29980,29986]
===
match
---
operator: = [14848,14849]
operator: = [14879,14880]
===
match
---
name: dt [27349,27351]
name: dt [27380,27382]
===
match
---
expr_stmt [23474,23542]
expr_stmt [23505,23573]
===
match
---
name: model [45429,45434]
name: model [45460,45465]
===
match
---
name: tearDown [71032,71040]
name: tearDown [72656,72664]
===
match
---
argument [53666,53693]
argument [53697,53724]
===
match
---
atom_expr [17396,17455]
atom_expr [17427,17486]
===
match
---
trailer [69847,69855]
trailer [71471,71479]
===
match
---
atom_expr [73567,73584]
atom_expr [75191,75208]
===
match
---
arglist [13858,13866]
arglist [13889,13897]
===
match
---
name: DagRunInfo [77930,77940]
name: DagRunInfo [79554,79564]
===
match
---
name: correct_weight [14552,14566]
name: correct_weight [14583,14597]
===
match
---
name: when [43909,43913]
name: when [43940,43944]
===
match
---
arith_expr [18205,18246]
arith_expr [18236,18277]
===
match
---
operator: , [35520,35521]
operator: , [35551,35552]
===
match
---
argument [76752,76767]
argument [78376,78391]
===
match
---
atom_expr [22650,22667]
atom_expr [22681,22698]
===
match
---
atom_expr [27692,27707]
atom_expr [27723,27738]
===
match
---
operator: , [64077,64078]
operator: , [65701,65702]
===
match
---
operator: , [37571,37572]
operator: , [37602,37603]
===
match
---
argument [17632,17655]
argument [17663,17686]
===
match
---
name: session [32628,32635]
name: session [32659,32666]
===
match
---
number: 42 [51286,51288]
number: 42 [51317,51319]
===
match
---
operator: } [9388,9389]
operator: } [9419,9420]
===
match
---
name: os [20894,20896]
name: os [20925,20927]
===
match
---
number: 1 [64344,64345]
number: 1 [65968,65969]
===
match
---
trailer [4162,4169]
trailer [4193,4200]
===
match
---
name: asserts [2446,2453]
name: asserts [2477,2484]
===
match
---
trailer [31011,31084]
trailer [31042,31115]
===
match
---
operator: = [38033,38034]
operator: = [38064,38065]
===
match
---
number: 1 [63687,63688]
number: 1 [65311,65312]
===
match
---
trailer [53404,53415]
trailer [53435,53446]
===
match
---
simple_stmt [1115,1131]
simple_stmt [1121,1137]
===
match
---
trailer [27065,27075]
trailer [27096,27106]
===
match
---
operator: = [68152,68153]
operator: = [69776,69777]
===
match
---
name: self [70035,70039]
name: self [71659,71663]
===
match
---
trailer [27806,27817]
trailer [27837,27848]
===
match
---
trailer [74777,74781]
trailer [76401,76405]
===
match
---
simple_stmt [57214,57257]
simple_stmt [57245,57288]
===
match
---
trailer [52832,52841]
trailer [52863,52872]
===
match
---
parameters [6219,6225]
parameters [6250,6256]
===
match
---
name: DagModel [38066,38074]
name: DagModel [38097,38105]
===
match
---
assert_stmt [63879,63961]
assert_stmt [65503,65585]
===
match
---
name: task_id [6908,6915]
name: task_id [6939,6946]
===
match
---
name: dag [64191,64194]
name: dag [65815,65818]
===
match
---
argument [44986,45015]
argument [45017,45046]
===
match
---
name: dag [44405,44408]
name: dag [44436,44439]
===
match
---
string: "\n" [40113,40117]
string: "\n" [40144,40148]
===
match
---
trailer [19624,19626]
trailer [19655,19657]
===
match
---
atom_expr [75715,75746]
atom_expr [77339,77370]
===
match
---
name: tempfile [979,987]
name: tempfile [979,987]
===
match
---
name: raises [73151,73157]
name: raises [74775,74781]
===
match
---
expr_stmt [27476,27542]
expr_stmt [27507,27573]
===
match
---
name: query [46381,46386]
name: query [46412,46417]
===
match
---
name: dag [39764,39767]
name: dag [39795,39798]
===
match
---
string: "test_fractional_seconds" [46687,46712]
string: "test_fractional_seconds" [46718,46743]
===
match
---
name: task_id [9674,9681]
name: task_id [9705,9712]
===
match
---
trailer [54540,54793]
trailer [54571,54824]
===
match
---
name: datetime [18220,18228]
name: datetime [18251,18259]
===
match
---
name: datetime [22242,22250]
name: datetime [22273,22281]
===
match
---
name: start [26078,26083]
name: start [26109,26114]
===
match
---
arglist [24465,24479]
arglist [24496,24510]
===
match
---
name: bulk_write_to_db [29239,29255]
name: bulk_write_to_db [29270,29286]
===
match
---
simple_stmt [34091,34107]
simple_stmt [34122,34138]
===
match
---
atom_expr [73182,73197]
atom_expr [74806,74821]
===
match
---
name: schedule_interval [8426,8443]
name: schedule_interval [8457,8474]
===
match
---
simple_stmt [59544,59562]
simple_stmt [59575,59593]
===
match
---
name: args [47806,47810]
name: args [47837,47841]
===
match
---
expr_stmt [10423,10455]
expr_stmt [10454,10486]
===
match
---
operator: = [55621,55622]
operator: = [55652,55653]
===
match
---
operator: , [40952,40953]
operator: , [40983,40984]
===
match
---
operator: + [25549,25550]
operator: + [25580,25581]
===
match
---
name: execution_date [45029,45043]
name: execution_date [45060,45074]
===
match
---
operator: = [37504,37505]
operator: = [37535,37536]
===
match
---
name: topological_list [9171,9187]
name: topological_list [9202,9218]
===
match
---
name: DEFAULT_DATE [21660,21672]
name: DEFAULT_DATE [21691,21703]
===
match
---
name: DEFAULT_ARGS [71137,71149]
name: DEFAULT_ARGS [72761,72773]
===
match
---
operator: , [9873,9874]
operator: , [9904,9905]
===
match
---
arglist [12743,12808]
arglist [12774,12839]
===
match
---
trailer [75728,75746]
trailer [77352,77370]
===
match
---
name: make_dag [60325,60333]
name: make_dag [60356,60364]
===
match
---
decorated [71864,72055]
decorated [73488,73679]
===
match
---
name: task_id [67408,67415]
name: task_id [69032,69039]
===
match
---
operator: == [69294,69296]
operator: == [70918,70920]
===
match
---
name: catchup [59006,59013]
name: catchup [59037,59044]
===
match
---
trailer [38160,38222]
trailer [38191,38253]
===
match
---
atom_expr [57491,57517]
atom_expr [57522,57548]
===
match
---
string: 'b_parent' [9159,9169]
string: 'b_parent' [9190,9200]
===
match
---
operator: , [29545,29546]
operator: , [29576,29577]
===
match
---
atom_expr [30116,30142]
atom_expr [30147,30173]
===
match
---
name: DagModel [49767,49775]
name: DagModel [49798,49806]
===
match
---
atom_expr [67315,67385]
atom_expr [68939,69009]
===
match
---
name: timedelta [56863,56872]
name: timedelta [56894,56903]
===
match
---
trailer [20864,20866]
trailer [20895,20897]
===
match
---
expr_stmt [13291,13300]
expr_stmt [13322,13331]
===
match
---
trailer [74220,74226]
trailer [75844,75850]
===
match
---
name: start_date [33448,33458]
name: start_date [33479,33489]
===
match
---
assert_stmt [45878,45925]
assert_stmt [45909,45956]
===
match
---
suite [72755,73198]
suite [74379,74822]
===
match
---
assert_stmt [48425,48442]
assert_stmt [48456,48473]
===
match
---
atom_expr [65044,65238]
atom_expr [66668,66862]
===
match
---
name: subdag [55340,55346]
name: subdag [55371,55377]
===
match
---
name: path [21541,21545]
name: path [21572,21576]
===
match
---
name: following_schedule [27562,27580]
name: following_schedule [27593,27611]
===
match
---
trailer [47649,47656]
trailer [47680,47687]
===
match
---
name: timezone [62072,62080]
name: timezone [62103,62111]
===
match
---
operator: } [13179,13180]
operator: } [13210,13211]
===
match
---
name: DEFAULT_DATE [44831,44843]
name: DEFAULT_DATE [44862,44874]
===
match
---
trailer [37269,37271]
trailer [37300,37302]
===
match
---
trailer [25790,25792]
trailer [25821,25823]
===
match
---
name: settings [12841,12849]
name: settings [12872,12880]
===
match
---
trailer [27128,27131]
trailer [27159,27162]
===
match
---
string: "sleep 1" [40672,40681]
string: "sleep 1" [40703,40712]
===
match
---
simple_stmt [29156,29185]
simple_stmt [29187,29216]
===
match
---
name: schedule_interval [50390,50407]
name: schedule_interval [50421,50438]
===
match
---
trailer [39970,39985]
trailer [40001,40016]
===
match
---
simple_stmt [31710,31738]
simple_stmt [31741,31769]
===
match
---
expr_stmt [21774,21822]
expr_stmt [21805,21853]
===
match
---
simple_stmt [22163,22209]
simple_stmt [22194,22240]
===
match
---
name: ti [74895,74897]
name: ti [76519,76521]
===
match
---
trailer [40112,40118]
trailer [40143,40149]
===
match
---
operator: = [23827,23828]
operator: = [23858,23859]
===
match
---
name: start_date [34265,34275]
name: start_date [34296,34306]
===
match
---
argument [25543,25551]
argument [25574,25582]
===
match
---
trailer [50256,50266]
trailer [50287,50297]
===
match
---
name: utils [2350,2355]
name: utils [2381,2386]
===
match
---
param [74040,74044]
param [75664,75668]
===
match
---
name: run_type [42757,42765]
name: run_type [42788,42796]
===
match
---
name: DagModel [37941,37949]
name: DagModel [37972,37980]
===
match
---
operator: = [10263,10264]
operator: = [10294,10295]
===
match
---
operator: = [48094,48095]
operator: = [48125,48126]
===
match
---
name: subdag [32431,32437]
name: subdag [32462,32468]
===
match
---
trailer [61016,61022]
trailer [61047,61053]
===
match
---
import_from [949,973]
import_from [949,973]
===
match
---
trailer [39119,39125]
trailer [39150,39156]
===
match
---
operator: , [2030,2031]
operator: , [2061,2062]
===
match
---
name: get_template_env [20316,20332]
name: get_template_env [20347,20363]
===
match
---
operator: = [31610,31611]
operator: = [31641,31642]
===
match
---
name: self [51679,51683]
name: self [51710,51714]
===
match
---
operator: = [51838,51839]
operator: = [51869,51870]
===
match
---
operator: = [55480,55481]
operator: = [55511,55512]
===
match
---
comparison [10072,10100]
comparison [10103,10131]
===
match
---
name: DEFAULT_DATE [31445,31457]
name: DEFAULT_DATE [31476,31488]
===
match
---
operator: = [12871,12872]
operator: = [12902,12903]
===
match
---
operator: == [5846,5848]
operator: == [5877,5879]
===
match
---
operator: = [8116,8117]
operator: = [8147,8148]
===
match
---
trailer [19566,19574]
trailer [19597,19605]
===
match
---
atom [66274,66332]
atom [67898,67956]
===
match
---
operator: = [62866,62867]
operator: = [62897,62898]
===
match
---
comparison [4759,4808]
comparison [4790,4839]
===
match
---
operator: = [59599,59600]
operator: = [59630,59631]
===
match
---
atom_expr [20946,20970]
atom_expr [20977,21001]
===
match
---
trailer [66133,66164]
trailer [67757,67788]
===
match
---
atom_expr [61998,62020]
atom_expr [62029,62051]
===
match
---
operator: , [44818,44819]
operator: , [44849,44850]
===
match
---
name: create_dagrun [17845,17858]
name: create_dagrun [17876,17889]
===
match
---
name: airflow [2086,2093]
name: airflow [2117,2124]
===
match
---
operator: = [6326,6327]
operator: = [6357,6358]
===
match
---
funcdef [72475,72523]
funcdef [74099,74147]
===
match
---
name: start_date [31060,31070]
name: start_date [31091,31101]
===
match
---
arglist [35871,35912]
arglist [35902,35943]
===
match
---
name: DAG [8118,8121]
name: DAG [8149,8152]
===
match
---
expr_stmt [74517,74754]
expr_stmt [76141,76378]
===
match
---
name: current_task [15503,15515]
name: current_task [15534,15546]
===
match
---
name: dag_id [46406,46412]
name: dag_id [46437,46443]
===
match
---
name: dag [31271,31274]
name: dag [31302,31305]
===
match
---
operator: , [63695,63696]
operator: , [65319,65320]
===
match
---
trailer [76598,76606]
trailer [78222,78230]
===
match
---
comparison [34051,34082]
comparison [34082,34113]
===
match
---
suite [11559,11622]
suite [11590,11653]
===
match
---
name: dag2 [8030,8034]
name: dag2 [8061,8065]
===
match
---
parameters [40834,40840]
parameters [40865,40871]
===
match
---
atom_expr [2923,2979]
atom_expr [2954,3010]
===
match
---
atom_expr [19180,19298]
atom_expr [19211,19329]
===
match
---
atom_expr [9053,9113]
atom_expr [9084,9144]
===
match
---
expr_stmt [10513,10545]
expr_stmt [10544,10576]
===
match
---
trailer [9942,9949]
trailer [9973,9980]
===
match
---
arglist [62361,62551]
arglist [62392,62582]
===
match
---
comparison [23030,23083]
comparison [23061,23114]
===
match
---
operator: , [9878,9879]
operator: , [9909,9910]
===
match
---
name: __class__ [27226,27235]
name: __class__ [27257,27266]
===
match
---
operator: = [73863,73864]
operator: = [75487,75488]
===
match
---
name: DEFAULT_ARGS [71897,71909]
name: DEFAULT_ARGS [73521,73533]
===
match
---
dotted_name [69522,69545]
dotted_name [71146,71169]
===
match
---
name: dag [41116,41119]
name: dag [41147,41150]
===
match
---
simple_stmt [55340,55605]
simple_stmt [55371,55636]
===
match
---
simple_stmt [24913,24950]
simple_stmt [24944,24981]
===
match
---
name: topological_list [10944,10960]
name: topological_list [10975,10991]
===
match
---
string: ', ' [32767,32771]
string: ', ' [32798,32802]
===
match
---
name: merge [56558,56563]
name: merge [56589,56594]
===
match
---
operator: , [68773,68774]
operator: , [70397,70398]
===
match
---
param [19669,19673]
param [19700,19704]
===
match
---
name: write [21470,21475]
name: write [21501,21506]
===
match
---
argument [8700,8716]
argument [8731,8747]
===
match
---
name: op3 [11318,11321]
name: op3 [11349,11352]
===
match
---
trailer [73896,73909]
trailer [75520,75533]
===
match
---
name: _ [60109,60110]
name: _ [60140,60141]
===
match
---
simple_stmt [10558,10591]
simple_stmt [10589,10622]
===
match
---
name: DEFAULT_DATE [77777,77789]
name: DEFAULT_DATE [79401,79413]
===
match
---
string: 'dag' [9325,9330]
string: 'dag' [9356,9361]
===
match
---
trailer [43252,43269]
trailer [43283,43300]
===
match
---
suite [67245,69924]
suite [68869,71548]
===
match
---
decorator [71548,71564]
decorator [73172,73188]
===
match
---
trailer [38152,38160]
trailer [38183,38191]
===
match
---
name: params1 [4759,4766]
name: params1 [4790,4797]
===
match
---
simple_stmt [75458,75557]
simple_stmt [77082,77181]
===
match
---
name: xcom_arg [74435,74443]
name: xcom_arg [76059,76067]
===
match
---
trailer [38343,38352]
trailer [38374,38383]
===
match
---
expr_stmt [65602,65625]
expr_stmt [67226,67249]
===
match
---
arglist [78939,79046]
arglist [80563,80670]
===
match
---
assert_stmt [67901,67924]
assert_stmt [69525,69548]
===
match
---
name: calculated_weight [14461,14478]
name: calculated_weight [14492,14509]
===
match
---
name: all [52797,52800]
name: all [52828,52831]
===
match
---
simple_stmt [974,1014]
simple_stmt [974,1014]
===
match
---
operator: } [64979,64980]
operator: } [66603,66604]
===
match
---
simple_stmt [18120,18257]
simple_stmt [18151,18288]
===
match
---
name: name [21556,21560]
name: name [21587,21591]
===
match
---
trailer [44972,45135]
trailer [45003,45166]
===
match
---
operator: } [30604,30605]
operator: } [30635,30636]
===
match
---
trailer [3015,3017]
trailer [3046,3048]
===
match
---
argument [55508,55528]
argument [55539,55559]
===
match
---
argument [54100,54119]
argument [54131,54150]
===
match
---
string: 'dag_default_view' [5818,5836]
string: 'dag_default_view' [5849,5867]
===
match
---
operator: , [29806,29807]
operator: , [29837,29838]
===
match
---
name: DummyOperator [8736,8749]
name: DummyOperator [8767,8780]
===
match
---
name: DummyOperator [7891,7904]
name: DummyOperator [7922,7935]
===
match
---
name: i [64974,64975]
name: i [66598,66599]
===
match
---
argument [78561,78568]
argument [80185,80192]
===
match
---
name: one [76339,76342]
name: one [77963,77966]
===
match
---
operator: = [57343,57344]
operator: = [57374,57375]
===
match
---
argument [11579,11620]
argument [11610,11651]
===
match
---
name: task_dict [42202,42211]
name: task_dict [42233,42242]
===
match
---
name: local_tz [22991,22999]
name: local_tz [23022,23030]
===
match
---
name: pytest [40401,40407]
name: pytest [40432,40438]
===
match
---
fstring_end: ' [19738,19739]
fstring_end: ' [19769,19770]
===
match
---
assert_stmt [71314,71344]
assert_stmt [72938,72968]
===
match
---
name: convert_to_utc [22443,22457]
name: convert_to_utc [22474,22488]
===
match
---
argument [50923,50964]
argument [50954,50995]
===
match
---
name: conf [74718,74722]
name: conf [76342,76346]
===
match
---
argument [45843,45868]
argument [45874,45899]
===
match
---
operator: , [65751,65752]
operator: , [67375,67376]
===
match
---
arglist [20204,20290]
arglist [20235,20321]
===
match
---
trailer [27075,27090]
trailer [27106,27121]
===
match
---
trailer [60540,60557]
trailer [60571,60588]
===
match
---
simple_stmt [51097,51172]
simple_stmt [51128,51203]
===
match
---
param [58803,58807]
param [58834,58838]
===
match
---
name: DEFAULT_DATE [31071,31083]
name: DEFAULT_DATE [31102,31114]
===
match
---
operator: , [59411,59412]
operator: , [59442,59443]
===
match
---
trailer [19322,19345]
trailer [19353,19376]
===
match
---
expr_stmt [5728,5780]
expr_stmt [5759,5811]
===
match
---
parameters [25352,25358]
parameters [25383,25389]
===
match
---
testlist_comp [27776,27792]
testlist_comp [27807,27823]
===
match
---
operator: , [28369,28370]
operator: , [28400,28401]
===
match
---
name: filter [36678,36684]
name: filter [36709,36715]
===
match
---
operator: = [39384,39385]
operator: = [39415,39416]
===
match
---
atom_expr [22714,22736]
atom_expr [22745,22767]
===
match
---
trailer [73531,73538]
trailer [75155,75162]
===
match
---
name: orm_dag [33915,33922]
name: orm_dag [33946,33953]
===
match
---
name: DEFAULT_DATE [14849,14861]
name: DEFAULT_DATE [14880,14892]
===
match
---
name: default_args [14863,14875]
name: default_args [14894,14906]
===
match
---
comparison [27967,28001]
comparison [27998,28032]
===
match
---
trailer [34836,34843]
trailer [34867,34874]
===
match
---
string: "10 10 * * *" [64127,64140]
string: "10 10 * * *" [65751,65764]
===
match
---
trailer [58490,58496]
trailer [58521,58527]
===
match
---
simple_stmt [21886,21921]
simple_stmt [21917,21952]
===
match
---
expr_stmt [53342,53389]
expr_stmt [53373,53420]
===
match
---
funcdef [72974,73022]
funcdef [74598,74646]
===
match
---
assert_stmt [35965,36062]
assert_stmt [35996,36093]
===
match
---
atom_expr [61774,61803]
atom_expr [61805,61834]
===
match
---
atom [35595,35609]
atom [35626,35640]
===
match
---
atom_expr [24577,24639]
atom_expr [24608,24670]
===
match
---
trailer [69703,69718]
trailer [71327,71342]
===
match
---
simple_stmt [21311,21348]
simple_stmt [21342,21379]
===
match
---
trailer [20420,20429]
trailer [20451,20460]
===
match
---
arith_expr [56839,56880]
arith_expr [56870,56911]
===
match
---
name: hash [49225,49229]
name: hash [49256,49260]
===
match
---
simple_stmt [58675,58704]
simple_stmt [58706,58735]
===
match
---
arith_expr [55849,55973]
arith_expr [55880,56004]
===
match
---
expr_stmt [41082,41124]
expr_stmt [41113,41155]
===
match
---
name: self [47691,47695]
name: self [47722,47726]
===
match
---
operator: , [53088,53089]
operator: , [53119,53120]
===
match
---
trailer [70548,70556]
trailer [72172,72180]
===
match
---
dictorsetmaker [30302,30356]
dictorsetmaker [30333,30387]
===
match
---
simple_stmt [23772,23808]
simple_stmt [23803,23839]
===
match
---
name: DummyOperator [59440,59453]
name: DummyOperator [59471,59484]
===
match
---
simple_stmt [13346,13389]
simple_stmt [13377,13420]
===
match
---
atom [49895,49918]
atom [49926,49949]
===
match
---
name: max_active_runs [31097,31112]
name: max_active_runs [31128,31143]
===
match
---
trailer [38179,38186]
trailer [38210,38217]
===
match
---
trailer [17262,17328]
trailer [17293,17359]
===
match
---
name: query [35791,35796]
name: query [35822,35827]
===
match
---
operator: } [74742,74743]
operator: } [76366,76367]
===
match
---
simple_stmt [32839,32879]
simple_stmt [32870,32910]
===
match
---
trailer [32753,32760]
trailer [32784,32791]
===
match
---
assert_stmt [28325,28498]
assert_stmt [28356,28529]
===
match
---
operator: = [45075,45076]
operator: = [45106,45107]
===
match
---
operator: == [41625,41627]
operator: == [41656,41658]
===
match
---
operator: = [56476,56477]
operator: = [56507,56508]
===
match
---
atom_expr [37245,37271]
atom_expr [37276,37302]
===
match
---
operator: = [44318,44319]
operator: = [44349,44350]
===
match
---
name: dag [59523,59526]
name: dag [59554,59557]
===
match
---
name: dag_decorator [75047,75060]
name: dag_decorator [76671,76684]
===
match
---
simple_stmt [56237,56283]
simple_stmt [56268,56314]
===
match
---
atom_expr [52332,52348]
atom_expr [52363,52379]
===
match
---
operator: , [9157,9158]
operator: , [9188,9189]
===
match
---
import_from [1300,1336]
import_from [1306,1342]
===
match
---
name: noop_pipeline [72565,72578]
name: noop_pipeline [74189,74202]
===
match
---
name: create_session [36942,36956]
name: create_session [36973,36987]
===
match
---
trailer [37322,37324]
trailer [37353,37355]
===
match
---
name: dag [68839,68842]
name: dag [70463,70466]
===
match
---
name: dag_run [44302,44309]
name: dag_run [44333,44340]
===
match
---
factor [3694,3696]
factor [3725,3727]
===
match
---
trailer [31469,31477]
trailer [31500,31508]
===
match
---
simple_stmt [10065,10101]
simple_stmt [10096,10132]
===
match
---
name: end_date [58145,58153]
name: end_date [58176,58184]
===
match
---
operator: , [59274,59275]
operator: , [59305,59306]
===
match
---
simple_stmt [53196,53271]
simple_stmt [53227,53302]
===
match
---
assert_stmt [40217,40247]
assert_stmt [40248,40278]
===
match
---
atom_expr [19319,19443]
atom_expr [19350,19474]
===
match
---
argument [68848,68863]
argument [70472,70487]
===
match
---
name: op2 [7094,7097]
name: op2 [7125,7128]
===
match
---
for_stmt [13894,14145]
for_stmt [13925,14176]
===
match
---
number: 30 [59816,59818]
number: 30 [59847,59849]
===
match
---
argument [18438,18452]
argument [18469,18483]
===
match
---
simple_stmt [34764,34893]
simple_stmt [34795,34924]
===
match
---
name: DAG [59155,59158]
name: DAG [59186,59189]
===
match
---
number: 0 [16582,16583]
number: 0 [16613,16614]
===
match
---
atom_expr [26086,26149]
atom_expr [26117,26180]
===
match
---
name: start_date [24591,24601]
name: start_date [24622,24632]
===
match
---
string: 'test-dag' [29646,29656]
string: 'test-dag' [29677,29687]
===
match
---
atom_expr [58740,58754]
atom_expr [58771,58785]
===
match
---
argument [19273,19288]
argument [19304,19319]
===
match
---
atom_expr [37737,37768]
atom_expr [37768,37799]
===
match
---
atom_expr [12739,12809]
atom_expr [12770,12840]
===
match
---
trailer [35405,35442]
trailer [35436,35473]
===
match
---
name: parent_dag [65577,65587]
name: parent_dag [67201,67211]
===
match
---
funcdef [20708,21348]
funcdef [20739,21379]
===
match
---
arglist [46120,46196]
arglist [46151,46227]
===
match
---
operator: == [29921,29923]
operator: == [29952,29954]
===
match
---
arglist [40932,41008]
arglist [40963,41039]
===
match
---
simple_stmt [34943,35146]
simple_stmt [34974,35177]
===
match
---
trailer [31778,31782]
trailer [31809,31813]
===
match
---
trailer [40016,40026]
trailer [40047,40057]
===
match
---
atom_expr [57573,57602]
atom_expr [57604,57633]
===
match
---
trailer [16522,16532]
trailer [16553,16563]
===
match
---
atom_expr [9821,9851]
atom_expr [9852,9882]
===
match
---
name: DummyOperator [53348,53361]
name: DummyOperator [53379,53392]
===
match
---
argument [78875,78882]
argument [80499,80506]
===
match
---
operator: , [19416,19417]
operator: , [19447,19448]
===
match
---
with_stmt [28279,28900]
with_stmt [28310,28931]
===
match
---
operator: , [56994,56995]
operator: , [57025,57026]
===
match
---
trailer [23943,23953]
trailer [23974,23984]
===
match
---
atom_expr [23349,23383]
atom_expr [23380,23414]
===
match
---
simple_stmt [49664,49698]
simple_stmt [49695,49729]
===
match
---
number: 1 [67382,67383]
number: 1 [69006,69007]
===
match
---
name: TestCase [70648,70656]
name: TestCase [72272,72280]
===
match
---
trailer [22442,22457]
trailer [22473,22488]
===
match
---
trailer [28750,28778]
trailer [28781,28809]
===
match
---
operator: , [65757,65758]
operator: , [67381,67382]
===
match
---
operator: , [18188,18189]
operator: , [18219,18220]
===
match
---
string: 'task' [33569,33575]
string: 'task' [33600,33606]
===
match
---
trailer [61926,61943]
trailer [61957,61974]
===
match
---
arglist [72607,72615]
arglist [74231,74239]
===
match
---
operator: = [60447,60448]
operator: = [60478,60479]
===
match
---
trailer [77810,77819]
trailer [79434,79443]
===
match
---
trailer [25644,25707]
trailer [25675,25738]
===
match
---
atom_expr [68584,68599]
atom_expr [70208,70223]
===
match
---
atom [18914,18928]
atom [18945,18959]
===
match
---
simple_stmt [31680,31702]
simple_stmt [31711,31733]
===
match
---
name: dag [71205,71208]
name: dag [72829,72832]
===
match
---
name: dag_id [46738,46744]
name: dag_id [46769,46775]
===
match
---
comparison [7094,7115]
comparison [7125,7146]
===
match
---
number: 0 [29425,29426]
number: 0 [29456,29457]
===
match
---
expr_stmt [50438,50510]
expr_stmt [50469,50541]
===
match
---
simple_stmt [40217,40248]
simple_stmt [40248,40279]
===
match
---
trailer [23580,23585]
trailer [23611,23616]
===
match
---
atom_expr [27921,27928]
atom_expr [27952,27959]
===
match
---
name: dag_id [27974,27980]
name: dag_id [28005,28011]
===
match
---
trailer [45434,45446]
trailer [45465,45477]
===
match
---
name: list_ [3727,3732]
name: list_ [3758,3763]
===
match
---
simple_stmt [20037,20084]
simple_stmt [20068,20115]
===
match
---
trailer [68276,68283]
trailer [69900,69907]
===
match
---
string: 'op8' [7913,7918]
string: 'op8' [7944,7949]
===
match
---
simple_stmt [70452,70614]
simple_stmt [72076,72238]
===
match
---
trailer [77504,77506]
trailer [79128,79130]
===
match
---
operator: = [5526,5527]
operator: = [5557,5558]
===
match
---
name: weight_rule [15104,15115]
name: weight_rule [15135,15146]
===
match
---
arith_expr [57995,58026]
arith_expr [58026,58057]
===
match
---
operator: , [64352,64353]
operator: , [65976,65977]
===
match
---
name: cron_timetable [49943,49957]
name: cron_timetable [49974,49988]
===
match
---
trailer [57511,57517]
trailer [57542,57548]
===
match
---
simple_stmt [56113,56136]
simple_stmt [56144,56167]
===
match
---
name: DummyOperator [6894,6907]
name: DummyOperator [6925,6938]
===
match
---
testlist_comp [19541,19574]
testlist_comp [19572,19605]
===
match
---
testlist_comp [21793,21821]
testlist_comp [21824,21852]
===
match
---
operator: == [13952,13954]
operator: == [13983,13985]
===
match
---
expr_stmt [41911,41944]
expr_stmt [41942,41975]
===
match
---
simple_stmt [75804,75845]
simple_stmt [77428,77469]
===
match
---
expr_stmt [72559,72580]
expr_stmt [74183,74204]
===
match
---
trailer [15685,15688]
trailer [15716,15719]
===
match
---
trailer [9715,9727]
trailer [9746,9758]
===
match
---
name: dag_id [37395,37401]
name: dag_id [37426,37432]
===
match
---
name: dag [10406,10409]
name: dag [10437,10440]
===
match
---
trailer [37827,37834]
trailer [37858,37865]
===
match
---
trailer [42022,42036]
trailer [42053,42067]
===
match
---
parameters [66826,66832]
parameters [68450,68456]
===
match
---
operator: , [54014,54015]
operator: , [54045,54046]
===
match
---
argument [24591,24607]
argument [24622,24638]
===
match
---
assert_stmt [40131,40161]
assert_stmt [40162,40192]
===
match
---
name: bash_command [40659,40671]
name: bash_command [40690,40702]
===
match
---
name: TI [52227,52229]
name: TI [52258,52260]
===
match
---
operator: , [2653,2654]
operator: , [2684,2685]
===
match
---
name: BaseOperator [58201,58213]
name: BaseOperator [58232,58244]
===
match
---
string: 'op6' [7732,7737]
string: 'op6' [7763,7768]
===
match
---
name: next_dagrun_create_after [69059,69083]
name: next_dagrun_create_after [70683,70707]
===
match
---
trailer [46090,46092]
trailer [46121,46123]
===
match
---
name: schedule_interval [26196,26213]
name: schedule_interval [26227,26244]
===
match
---
trailer [6704,6770]
trailer [6735,6801]
===
match
---
operator: , [51593,51594]
operator: , [51624,51625]
===
match
---
trailer [26660,26667]
trailer [26691,26698]
===
match
---
trailer [9916,9919]
trailer [9947,9950]
===
match
---
trailer [22564,22583]
trailer [22595,22614]
===
match
---
parameters [3172,3185]
parameters [3203,3216]
===
match
---
simple_stmt [35364,35565]
simple_stmt [35395,35596]
===
match
---
simple_stmt [41614,41632]
simple_stmt [41645,41663]
===
match
---
name: utcnow [70769,70775]
name: utcnow [72393,72399]
===
match
---
argument [32275,32298]
argument [32306,32329]
===
match
---
operator: @ [49850,49851]
operator: @ [49881,49882]
===
match
---
operator: = [41961,41962]
operator: = [41992,41993]
===
match
---
param [42438,42442]
param [42469,42473]
===
match
---
trailer [33064,33098]
trailer [33095,33129]
===
match
---
operator: = [44011,44012]
operator: = [44042,44043]
===
match
---
operator: = [36574,36575]
operator: = [36605,36606]
===
match
---
number: 4 [28228,28229]
number: 4 [28259,28260]
===
match
---
comparison [31687,31701]
comparison [31718,31732]
===
match
---
operator: , [45089,45090]
operator: , [45120,45121]
===
match
---
name: datetime [61783,61791]
name: datetime [61814,61822]
===
match
---
operator: = [31070,31071]
operator: = [31101,31102]
===
match
---
name: dag_decorator [71865,71878]
name: dag_decorator [73489,73502]
===
match
---
atom_expr [53078,53133]
atom_expr [53109,53164]
===
match
---
simple_stmt [43560,43608]
simple_stmt [43591,43639]
===
match
---
atom_expr [38882,38909]
atom_expr [38913,38940]
===
match
---
name: dag_id [68277,68283]
name: dag_id [69901,69907]
===
match
---
name: params [4788,4794]
name: params [4819,4825]
===
match
---
name: session [31277,31284]
name: session [31308,31315]
===
match
---
name: timedelta [62507,62516]
name: timedelta [62538,62547]
===
match
---
expr_stmt [39311,39344]
expr_stmt [39342,39375]
===
match
---
expr_stmt [20546,20604]
expr_stmt [20577,20635]
===
match
---
operator: == [31442,31444]
operator: == [31473,31475]
===
match
---
arglist [16336,16465]
arglist [16367,16496]
===
match
---
atom_expr [65347,65410]
atom_expr [66971,67034]
===
match
---
atom [41733,41769]
atom [41764,41800]
===
match
---
simple_stmt [37431,37492]
simple_stmt [37462,37523]
===
match
---
simple_stmt [804,814]
simple_stmt [804,814]
===
match
---
name: dagruns [52833,52840]
name: dagruns [52864,52871]
===
match
---
testlist_comp [28586,28615]
testlist_comp [28617,28646]
===
match
---
name: task_dict [41223,41232]
name: task_dict [41254,41263]
===
match
---
name: default_args [47550,47562]
name: default_args [47581,47593]
===
match
---
operator: , [30540,30541]
operator: , [30571,30572]
===
match
---
name: task [21774,21778]
name: task [21805,21809]
===
match
---
trailer [77372,77378]
trailer [78996,79002]
===
match
---
operator: = [63842,63843]
operator: = [65466,65467]
===
match
---
name: access_control [66529,66543]
name: access_control [68153,68167]
===
match
---
operator: = [32559,32560]
operator: = [32590,32591]
===
match
---
dotted_name [1505,1519]
dotted_name [1511,1525]
===
match
---
name: task_dict [14174,14183]
name: task_dict [14205,14214]
===
match
---
atom_expr [51945,51963]
atom_expr [51976,51994]
===
match
---
operator: , [24472,24473]
operator: , [24503,24504]
===
match
---
for_stmt [16882,17146]
for_stmt [16913,17177]
===
match
---
trailer [76258,76266]
trailer [77882,77890]
===
match
---
string: "t4" [38996,39000]
string: "t4" [39027,39031]
===
match
---
atom_expr [70233,70288]
atom_expr [71857,71912]
===
match
---
name: local_tz [23270,23278]
name: local_tz [23301,23309]
===
match
---
name: session [30613,30620]
name: session [30644,30651]
===
match
---
simple_stmt [16115,16125]
simple_stmt [16146,16156]
===
match
---
simple_stmt [43298,43321]
simple_stmt [43329,43352]
===
match
---
operator: = [8827,8828]
operator: = [8858,8859]
===
match
---
assert_stmt [52899,52935]
assert_stmt [52930,52966]
===
match
---
operator: = [56438,56439]
operator: = [56469,56470]
===
match
---
decorator [55818,55996]
decorator [55849,56027]
===
match
---
atom_expr [69625,69645]
atom_expr [71249,71269]
===
match
---
atom_expr [65696,65725]
atom_expr [67320,67349]
===
match
---
name: suffix [21430,21436]
name: suffix [21461,21467]
===
match
---
expr_stmt [52855,52874]
expr_stmt [52886,52905]
===
match
---
testlist_comp [39082,39090]
testlist_comp [39113,39121]
===
match
---
trailer [52033,52046]
trailer [52064,52077]
===
match
---
operator: = [21015,21016]
operator: = [21046,21047]
===
match
---
trailer [31367,31379]
trailer [31398,31410]
===
match
---
name: state [56433,56438]
name: state [56464,56469]
===
match
---
assert_stmt [39586,39622]
assert_stmt [39617,39653]
===
match
---
trailer [23050,23052]
trailer [23081,23083]
===
match
---
name: dag2 [7288,7292]
name: dag2 [7319,7323]
===
match
---
operator: { [15022,15023]
operator: { [15053,15054]
===
match
---
name: safe_dag_id [33241,33252]
name: safe_dag_id [33272,33283]
===
match
---
operator: = [58123,58124]
operator: = [58154,58155]
===
match
---
operator: = [51159,51160]
operator: = [51190,51191]
===
match
---
atom_expr [58542,58565]
atom_expr [58573,58596]
===
match
---
simple_stmt [72041,72055]
simple_stmt [73665,73679]
===
match
---
trailer [59797,59807]
trailer [59828,59838]
===
match
---
trailer [75131,75137]
trailer [76755,76761]
===
match
---
name: next_info [64294,64303]
name: next_info [65918,65927]
===
match
---
with_stmt [29193,29262]
with_stmt [29224,29293]
===
match
---
string: 'op5' [7385,7390]
string: 'op5' [7416,7421]
===
match
---
operator: , [35633,35634]
operator: , [35664,35665]
===
match
---
operator: , [19531,19532]
operator: , [19562,19563]
===
match
---
trailer [17064,17086]
trailer [17095,17117]
===
match
---
simple_stmt [4141,4177]
simple_stmt [4172,4208]
===
match
---
name: value [75121,75126]
name: value [76745,76750]
===
match
---
atom_expr [52442,52468]
atom_expr [52473,52499]
===
match
---
name: dag_id [31012,31018]
name: dag_id [31043,31049]
===
match
---
arglist [22260,22279]
arglist [22291,22310]
===
match
---
string: '@daily' [8189,8197]
string: '@daily' [8220,8228]
===
match
---
expr_stmt [17975,18111]
expr_stmt [18006,18142]
===
match
---
param [71995,71998]
param [73619,73622]
===
match
---
trailer [26533,26542]
trailer [26564,26573]
===
match
---
argument [13654,13686]
argument [13685,13717]
===
match
---
name: DagModel [35797,35805]
name: DagModel [35828,35836]
===
match
---
operator: = [65310,65311]
operator: = [66934,66935]
===
match
---
name: depth [14396,14401]
name: depth [14427,14432]
===
match
---
parameters [46575,46581]
parameters [46606,46612]
===
match
---
trailer [67886,67890]
trailer [69510,69514]
===
match
---
trailer [49365,49370]
trailer [49396,49401]
===
match
---
name: dag [48705,48708]
name: dag [48736,48739]
===
match
---
name: datetime [65738,65746]
name: datetime [67362,67370]
===
match
---
name: test_tree_view [39632,39646]
name: test_tree_view [39663,39677]
===
match
---
name: dag [31229,31232]
name: dag [31260,31263]
===
match
---
simple_stmt [8970,9038]
simple_stmt [9001,9069]
===
match
---
operator: , [76266,76267]
operator: , [77890,77891]
===
match
---
operator: , [19545,19546]
operator: , [19576,19577]
===
match
---
number: 1 [78259,78260]
number: 1 [79883,79884]
===
match
---
name: repr [27921,27925]
name: repr [27952,27956]
===
match
---
arglist [55366,55594]
arglist [55397,55625]
===
match
---
arglist [2640,2656]
arglist [2671,2687]
===
match
---
trailer [12742,12809]
trailer [12773,12840]
===
match
---
number: 0 [28186,28187]
number: 0 [28217,28218]
===
match
---
parameters [27186,27196]
parameters [27217,27227]
===
match
---
decorator [74241,74257]
decorator [75865,75881]
===
match
---
operator: @ [55818,55819]
operator: @ [55849,55850]
===
match
---
name: tasks_count [70312,70323]
name: tasks_count [71936,71947]
===
match
---
name: task_id [41241,41248]
name: task_id [41272,41279]
===
match
---
string: '@once' [60875,60882]
string: '@once' [60906,60913]
===
match
---
string: 'dag-bulk-sync-1' [28352,28369]
string: 'dag-bulk-sync-1' [28383,28400]
===
match
---
trailer [62041,62053]
trailer [62072,62084]
===
match
---
trailer [69256,69265]
trailer [70880,70889]
===
match
---
operator: == [7516,7518]
operator: == [7547,7549]
===
match
---
atom_expr [27482,27542]
atom_expr [27513,27573]
===
match
---
operator: , [70126,70127]
operator: , [71750,71751]
===
match
---
name: next_date [60521,60530]
name: next_date [60552,60561]
===
match
---
name: rollback [55021,55029]
name: rollback [55052,55060]
===
match
---
operator: = [17890,17891]
operator: = [17921,17922]
===
match
---
name: session [33337,33344]
name: session [33368,33375]
===
match
---
trailer [22891,22893]
trailer [22922,22924]
===
match
---
name: paused_dag_ids [49601,49615]
name: paused_dag_ids [49632,49646]
===
match
---
name: prev_local [25189,25199]
name: prev_local [25220,25230]
===
match
---
simple_stmt [68480,68496]
simple_stmt [70104,70120]
===
match
---
name: subdag_id [35501,35510]
name: subdag_id [35532,35541]
===
match
---
name: query [37114,37119]
name: query [37145,37150]
===
match
---
name: self [47364,47368]
name: self [47395,47399]
===
match
---
operator: , [65227,65228]
operator: , [66851,66852]
===
match
---
simple_stmt [75325,75349]
simple_stmt [76949,76973]
===
match
---
operator: , [56607,56608]
operator: , [56638,56639]
===
match
---
decorator [72853,72900]
decorator [74477,74524]
===
match
---
decorator [71104,71151]
decorator [72728,72775]
===
match
---
atom_expr [30686,30732]
atom_expr [30717,30763]
===
match
---
argument [60015,60051]
argument [60046,60082]
===
match
---
comparison [64294,64357]
comparison [65918,65981]
===
match
---
trailer [3368,3375]
trailer [3399,3406]
===
match
---
name: args [48163,48167]
name: args [48194,48198]
===
match
---
operator: { [14876,14877]
operator: { [14907,14908]
===
match
---
argument [54016,54035]
argument [54047,54066]
===
match
---
name: timezone [67355,67363]
name: timezone [68979,68987]
===
match
---
operator: = [57938,57939]
operator: = [57969,57970]
===
match
---
operator: == [21995,21997]
operator: == [22026,22028]
===
match
---
atom_expr [16156,16225]
atom_expr [16187,16256]
===
match
---
name: DAGS_FOLDER [38002,38013]
name: DAGS_FOLDER [38033,38044]
===
match
---
arglist [18017,18101]
arglist [18048,18132]
===
match
---
name: days [18239,18243]
name: days [18270,18274]
===
match
---
operator: == [52759,52761]
operator: == [52790,52792]
===
match
---
number: 1 [57922,57923]
number: 1 [57953,57954]
===
match
---
suite [73237,73995]
suite [74861,75619]
===
match
---
atom [6836,6855]
atom [6867,6886]
===
match
---
expr_stmt [23816,23852]
expr_stmt [23847,23883]
===
match
---
atom_expr [73764,73781]
atom_expr [75388,75405]
===
match
---
name: jinja_env [20300,20309]
name: jinja_env [20331,20340]
===
match
---
name: start_date [78786,78796]
name: start_date [80410,80420]
===
match
---
name: task_id [17691,17698]
name: task_id [17722,17729]
===
match
---
suite [71596,71624]
suite [73220,73248]
===
match
---
name: op4 [9880,9883]
name: op4 [9911,9914]
===
match
---
atom_expr [58201,58254]
atom_expr [58232,58285]
===
match
---
number: 1 [3695,3696]
number: 1 [3726,3727]
===
match
---
name: prev_local [22819,22829]
name: prev_local [22850,22860]
===
match
---
simple_stmt [26926,26997]
simple_stmt [26957,27028]
===
match
---
trailer [27580,27587]
trailer [27611,27618]
===
match
---
atom_expr [7363,7391]
atom_expr [7394,7422]
===
match
---
operator: @ [71548,71549]
operator: @ [73172,73173]
===
match
---
operator: = [70984,70985]
operator: = [72608,72609]
===
match
---
import_from [1194,1227]
import_from [1200,1233]
===
match
---
name: self [74163,74167]
name: self [75787,75791]
===
match
---
name: dag [67060,67063]
name: dag [68684,68687]
===
match
---
number: 50 [20433,20435]
number: 50 [20464,20466]
===
match
---
trailer [65353,65410]
trailer [66977,67034]
===
match
---
name: dags [29014,29018]
name: dags [29045,29049]
===
match
---
expr_stmt [38830,38863]
expr_stmt [38861,38894]
===
match
---
operator: = [58042,58043]
operator: = [58073,58074]
===
match
---
operator: == [41730,41732]
operator: == [41761,41763]
===
match
---
atom_expr [28824,28849]
atom_expr [28855,28880]
===
match
---
atom_expr [4148,4176]
atom_expr [4179,4207]
===
match
---
name: DummyOperator [17677,17690]
name: DummyOperator [17708,17721]
===
match
---
trailer [70469,70613]
trailer [72093,72237]
===
match
---
name: session [67810,67817]
name: session [69434,69441]
===
match
---
atom_expr [55955,55971]
atom_expr [55986,56002]
===
match
---
suite [58809,61151]
suite [58840,61182]
===
match
---
name: test_timetable_from_schedule_interval [50346,50383]
name: test_timetable_from_schedule_interval [50377,50414]
===
match
---
simple_stmt [32214,32314]
simple_stmt [32245,32345]
===
match
---
name: setUp [2822,2827]
name: setUp [2853,2858]
===
match
---
name: parent_dag [8582,8592]
name: parent_dag [8613,8623]
===
match
---
dotted_name [1592,1619]
dotted_name [1598,1625]
===
match
---
trailer [42593,42608]
trailer [42624,42639]
===
match
---
trailer [49817,49844]
trailer [49848,49875]
===
match
---
name: op2 [10684,10687]
name: op2 [10715,10718]
===
match
---
atom_expr [9204,9263]
atom_expr [9235,9294]
===
match
---
name: op3 [41696,41699]
name: op3 [41727,41730]
===
match
---
operator: = [75762,75763]
operator: = [77386,77387]
===
match
---
trailer [76974,77023]
trailer [78598,78647]
===
match
---
suite [25991,26332]
suite [26022,26363]
===
match
---
trailer [63121,63138]
trailer [63152,63169]
===
match
---
name: dag_id [30343,30349]
name: dag_id [30374,30380]
===
match
---
name: dag [6871,6874]
name: dag [6902,6905]
===
match
---
trailer [63847,63864]
trailer [65471,65488]
===
match
---
trailer [14284,14290]
trailer [14315,14321]
===
match
---
operator: = [59653,59654]
operator: = [59684,59685]
===
match
---
suite [39298,39623]
suite [39329,39654]
===
match
---
operator: >> [8787,8789]
operator: >> [8818,8820]
===
match
---
atom_expr [7199,7206]
atom_expr [7230,7237]
===
match
---
atom_expr [20452,20471]
atom_expr [20483,20502]
===
match
---
name: user_defined_filters [19840,19860]
name: user_defined_filters [19871,19891]
===
match
---
suite [55215,55813]
suite [55246,55844]
===
match
---
operator: , [62094,62095]
operator: , [62125,62126]
===
match
---
fstring_expr [13771,13774]
fstring_expr [13802,13805]
===
match
---
simple_stmt [75853,75894]
simple_stmt [77477,77518]
===
match
---
operator: = [70841,70842]
operator: = [72465,72466]
===
match
---
name: match [15605,15610]
name: match [15636,15641]
===
match
---
trailer [38772,38809]
trailer [38803,38840]
===
match
---
operator: = [54564,54565]
operator: = [54595,54596]
===
match
---
param [50898,50902]
param [50929,50933]
===
match
---
name: DAG [4677,4680]
name: DAG [4708,4711]
===
match
---
atom_expr [45934,46023]
atom_expr [45965,46054]
===
match
---
operator: ... [71192,71195]
operator: ... [72816,72819]
===
match
---
parameters [75194,75199]
parameters [76818,76823]
===
match
---
trailer [38474,38508]
trailer [38505,38539]
===
match
---
name: dag_fileloc [37431,37442]
name: dag_fileloc [37462,37473]
===
match
---
operator: , [43999,44000]
operator: , [44030,44031]
===
match
---
name: op1 [41911,41914]
name: op1 [41942,41945]
===
match
---
trailer [33981,33985]
trailer [34012,34016]
===
match
---
number: 0 [13816,13817]
number: 0 [13847,13848]
===
match
---
operator: , [43404,43405]
operator: , [43435,43436]
===
match
---
suite [7293,7345]
suite [7324,7376]
===
match
---
param [50384,50389]
param [50415,50420]
===
match
---
arith_expr [45512,45532]
arith_expr [45543,45563]
===
match
---
argument [42800,42824]
argument [42831,42855]
===
match
---
name: dag_run_state [52482,52495]
name: dag_run_state [52513,52526]
===
match
---
simple_stmt [56668,56697]
simple_stmt [56699,56728]
===
match
---
string: 'test-invalid-orientation' [6125,6151]
string: 'test-invalid-orientation' [6156,6182]
===
match
---
name: DEFAULT_DATE [17643,17655]
name: DEFAULT_DATE [17674,17686]
===
match
---
operator: = [25098,25099]
operator: = [25129,25130]
===
match
---
name: value [74578,74583]
name: value [76202,76207]
===
match
---
operator: = [51003,51004]
operator: = [51034,51035]
===
match
---
name: models [2397,2403]
name: models [2428,2434]
===
match
---
name: range [16576,16581]
name: range [16607,16612]
===
match
---
parameters [70034,70040]
parameters [71658,71664]
===
match
---
simple_stmt [76562,76607]
simple_stmt [78186,78231]
===
match
---
name: runs [58366,58370]
name: runs [58397,58401]
===
match
---
simple_stmt [66574,66623]
simple_stmt [68198,68247]
===
match
---
atom_expr [49468,49509]
atom_expr [49499,49540]
===
match
---
name: setUp [70925,70930]
name: setUp [72549,72554]
===
match
---
atom_expr [14275,14294]
atom_expr [14306,14325]
===
match
---
name: value [73390,73395]
name: value [75014,75019]
===
match
---
trailer [69614,69619]
trailer [71238,71243]
===
match
---
trailer [77515,77522]
trailer [79139,79146]
===
match
---
name: RUNNING [54311,54318]
name: RUNNING [54342,54349]
===
match
---
name: undefined [20462,20471]
name: undefined [20493,20502]
===
match
---
expr_stmt [18566,18591]
expr_stmt [18597,18622]
===
match
---
atom [41664,41700]
atom [41695,41731]
===
match
---
string: 'dag-test-dagtag' [27726,27743]
string: 'dag-test-dagtag' [27757,27774]
===
match
---
name: task_id [34556,34563]
name: task_id [34587,34594]
===
match
---
name: TestQueries [69932,69943]
name: TestQueries [71556,71567]
===
match
---
name: test_dag_invalid_orientation [5875,5903]
name: test_dag_invalid_orientation [5906,5934]
===
match
---
name: _clean_up [47369,47378]
name: _clean_up [47400,47409]
===
match
---
name: session [37788,37795]
name: session [37819,37826]
===
match
---
simple_stmt [7148,7183]
simple_stmt [7179,7214]
===
match
---
atom [5134,5166]
atom [5165,5197]
===
match
---
trailer [76742,76750]
trailer [78366,78374]
===
match
---
trailer [45827,45869]
trailer [45858,45900]
===
match
---
operator: , [68431,68432]
operator: , [70055,70056]
===
match
---
name: current_task [14007,14019]
name: current_task [14038,14050]
===
match
---
operator: } [33177,33178]
operator: } [33208,33209]
===
match
---
argument [21674,21706]
argument [21705,21737]
===
match
---
name: DagRunType [44132,44142]
name: DagRunType [44163,44173]
===
match
---
argument [59523,59530]
argument [59554,59561]
===
match
---
name: op3 [39403,39406]
name: op3 [39434,39437]
===
match
---
suite [21455,21963]
suite [21486,21994]
===
match
---
simple_stmt [69280,69307]
simple_stmt [70904,70931]
===
match
---
string: "2018-03-24T03:00:00+01:00" [24769,24796]
string: "2018-03-24T03:00:00+01:00" [24800,24827]
===
match
---
operator: = [24575,24576]
operator: = [24606,24607]
===
match
---
name: delta [45527,45532]
name: delta [45558,45563]
===
match
---
atom_expr [11685,11764]
atom_expr [11716,11795]
===
match
---
operator: = [73395,73396]
operator: = [75019,75020]
===
match
---
trailer [6113,6117]
trailer [6144,6148]
===
match
---
trailer [42378,42393]
trailer [42409,42424]
===
match
---
atom_expr [32846,32866]
atom_expr [32877,32897]
===
match
---
suite [47697,49371]
suite [47728,49402]
===
match
---
operator: = [56803,56804]
operator: = [56834,56835]
===
match
---
expr_stmt [68234,68442]
expr_stmt [69858,70066]
===
match
---
number: 1 [25550,25551]
number: 1 [25581,25582]
===
match
---
arglist [53082,53132]
arglist [53113,53163]
===
match
---
operator: = [25577,25578]
operator: = [25608,25609]
===
match
---
trailer [32959,32965]
trailer [32990,32996]
===
match
---
name: State [51583,51588]
name: State [51614,51619]
===
match
---
atom_expr [74560,74583]
atom_expr [76184,76207]
===
match
---
argument [67095,67129]
argument [68719,68753]
===
match
---
operator: - [58688,58689]
operator: - [58719,58720]
===
match
---
name: task_id [41977,41984]
name: task_id [42008,42015]
===
match
---
name: timedelta [54624,54633]
name: timedelta [54655,54664]
===
match
---
name: DEFAULT_DATE [2411,2423]
name: DEFAULT_DATE [2442,2454]
===
match
---
number: 5 [62689,62690]
number: 5 [62720,62721]
===
match
---
name: create_session [44033,44047]
name: create_session [44064,44078]
===
match
---
name: dags [29138,29142]
name: dags [29169,29173]
===
match
---
atom_expr [71321,71332]
atom_expr [72945,72956]
===
match
---
simple_stmt [39014,39048]
simple_stmt [39045,39079]
===
match
---
trailer [75924,75942]
trailer [77548,77566]
===
match
---
name: args [47960,47964]
name: args [47991,47995]
===
match
---
trailer [35890,35911]
trailer [35921,35942]
===
match
---
trailer [75367,75374]
trailer [76991,76998]
===
match
---
atom_expr [5181,5212]
atom_expr [5212,5243]
===
match
---
name: run_type [31602,31610]
name: run_type [31633,31641]
===
match
---
name: dag [70227,70230]
name: dag [71851,71854]
===
match
---
name: t_1 [53982,53985]
name: t_1 [54013,54016]
===
match
---
operator: = [13297,13298]
operator: = [13328,13329]
===
match
---
trailer [35659,35672]
trailer [35690,35703]
===
match
---
operator: , [48080,48081]
operator: , [48111,48112]
===
match
---
name: test_params_not_passed_is_empty_dict [3900,3936]
name: test_params_not_passed_is_empty_dict [3931,3967]
===
match
---
operator: { [35162,35163]
operator: { [35193,35194]
===
match
---
name: DagModel [36685,36693]
name: DagModel [36716,36724]
===
match
---
shift_expr [41594,41604]
shift_expr [41625,41635]
===
match
---
operator: = [69856,69857]
operator: = [71480,71481]
===
match
---
name: self [21390,21394]
name: self [21421,21425]
===
match
---
string: 'owner1' [33159,33167]
string: 'owner1' [33190,33198]
===
match
---
name: jinja2 [1108,1114]
name: jinja2 [1114,1120]
===
match
---
name: dag [61445,61448]
name: dag [61476,61479]
===
match
---
string: 'a_parent' [8634,8644]
string: 'a_parent' [8665,8675]
===
match
---
name: DummyOperator [7363,7376]
name: DummyOperator [7394,7407]
===
match
---
arith_expr [15790,15812]
arith_expr [15821,15843]
===
match
---
name: test_replace_outdated_access_control_actions [65934,65978]
name: test_replace_outdated_access_control_actions [67558,67602]
===
match
---
shift_expr [39541,39572]
shift_expr [39572,39603]
===
match
---
trailer [14290,14293]
trailer [14321,14324]
===
match
---
trailer [5843,5845]
trailer [5874,5876]
===
match
---
simple_stmt [66485,66566]
simple_stmt [68109,68190]
===
match
---
operator: , [9169,9170]
operator: , [9200,9201]
===
match
---
name: session [46373,46380]
name: session [46404,46411]
===
match
---
trailer [22483,22544]
trailer [22514,22575]
===
match
---
operator: = [51981,51982]
operator: = [52012,52013]
===
match
---
operator: , [50215,50216]
operator: , [50246,50247]
===
match
---
name: range [64901,64906]
name: range [66525,66530]
===
match
---
trailer [44101,44167]
trailer [44132,44198]
===
match
---
simple_stmt [77203,77253]
simple_stmt [78827,78877]
===
match
---
operator: = [53977,53978]
operator: = [54008,54009]
===
match
---
string: 'test-dag' [29745,29755]
string: 'test-dag' [29776,29786]
===
match
---
suite [40559,40710]
suite [40590,40741]
===
match
---
name: model [31295,31300]
name: model [31326,31331]
===
match
---
operator: , [6821,6822]
operator: , [6852,6853]
===
match
---
operator: = [22830,22831]
operator: = [22861,22862]
===
match
---
name: task_id [3811,3818]
name: task_id [3842,3849]
===
match
---
string: "owner" [70688,70695]
string: "owner" [72312,72319]
===
match
---
trailer [58739,58755]
trailer [58770,58786]
===
match
---
trailer [31210,31218]
trailer [31241,31249]
===
match
---
name: start_date [27496,27506]
name: start_date [27527,27537]
===
match
---
name: self [25353,25357]
name: self [25384,25388]
===
match
---
operator: == [27981,27983]
operator: == [28012,28014]
===
match
---
operator: = [9867,9868]
operator: = [9898,9899]
===
match
---
import_from [1839,1890]
import_from [1845,1896]
===
match
---
trailer [45158,45160]
trailer [45189,45191]
===
match
---
atom_expr [6996,7003]
atom_expr [7027,7034]
===
match
---
name: earliest [78939,78947]
name: earliest [80563,80571]
===
match
---
name: next_info [63886,63895]
name: next_info [65510,65519]
===
match
---
atom_expr [66070,66097]
atom_expr [67694,67721]
===
match
---
operator: = [10450,10451]
operator: = [10481,10482]
===
match
---
name: jinja_udf [20074,20083]
name: jinja_udf [20105,20114]
===
match
---
trailer [9743,9756]
trailer [9774,9787]
===
match
---
atom [34959,35145]
atom [34990,35176]
===
match
---
operator: = [39900,39901]
operator: = [39931,39932]
===
match
---
trailer [78471,78588]
trailer [80095,80212]
===
match
---
simple_stmt [42340,42394]
simple_stmt [42371,42425]
===
match
---
simple_stmt [55261,55307]
simple_stmt [55292,55338]
===
match
---
name: rollback [67942,67950]
name: rollback [69566,69574]
===
match
---
arglist [47880,47910]
arglist [47911,47941]
===
match
---
name: DAG [22480,22483]
name: DAG [22511,22514]
===
match
---
atom_expr [38145,38222]
atom_expr [38176,38253]
===
match
---
sync_comp_for [55870,55926]
sync_comp_for [55901,55957]
===
match
---
name: create_dagrun [46106,46119]
name: create_dagrun [46137,46150]
===
match
---
operator: , [70262,70263]
operator: , [71886,71887]
===
match
---
expr_stmt [76633,76773]
expr_stmt [78257,78397]
===
match
---
name: is_paused [69324,69333]
name: is_paused [70948,70957]
===
match
---
name: match [40437,40442]
name: match [40468,40473]
===
match
---
expr_stmt [9564,9596]
expr_stmt [9595,9627]
===
match
---
comparison [66740,66781]
comparison [68364,68405]
===
match
---
operator: = [31753,31754]
operator: = [31784,31785]
===
match
---
operator: = [78194,78195]
operator: = [79818,79819]
===
match
---
comparison [61112,61150]
comparison [61143,61181]
===
match
---
operator: , [68403,68404]
operator: , [70027,70028]
===
match
---
name: needed [69287,69293]
name: needed [70911,70917]
===
match
---
trailer [18786,18809]
trailer [18817,18840]
===
match
---
trailer [41101,41124]
trailer [41132,41155]
===
match
---
name: key [77538,77541]
name: key [79162,79165]
===
match
---
name: DagTag [29957,29963]
name: DagTag [29988,29994]
===
match
---
trailer [72111,72121]
trailer [73735,73745]
===
match
---
name: self [61267,61271]
name: self [61298,61302]
===
match
---
arglist [44102,44166]
arglist [44133,44197]
===
match
---
simple_stmt [47975,48032]
simple_stmt [48006,48063]
===
match
---
name: noop_pipeline [72070,72083]
name: noop_pipeline [73694,73707]
===
match
---
trailer [10622,10635]
trailer [10653,10666]
===
match
---
arglist [56387,56531]
arglist [56418,56562]
===
match
---
arglist [42643,42704]
arglist [42674,42735]
===
match
---
atom_expr [49943,49970]
atom_expr [49974,50001]
===
match
---
string: 'owner1' [32192,32200]
string: 'owner1' [32223,32231]
===
match
---
operator: == [69458,69460]
operator: == [71082,71084]
===
match
---
simple_stmt [4295,4583]
simple_stmt [4326,4614]
===
match
---
string: 'owner' [6751,6758]
string: 'owner' [6782,6789]
===
match
---
argument [52558,52581]
argument [52589,52612]
===
match
---
number: 1 [61578,61579]
number: 1 [61609,61610]
===
match
---
name: dag_subdag [64706,64716]
name: dag_subdag [66330,66340]
===
match
---
operator: , [33505,33506]
operator: , [33536,33537]
===
match
---
trailer [49343,49357]
trailer [49374,49388]
===
match
---
expr_stmt [39014,39047]
expr_stmt [39045,39078]
===
match
---
arglist [10246,10310]
arglist [10277,10341]
===
match
---
atom_expr [74793,74810]
atom_expr [76417,76434]
===
match
---
atom_expr [60291,60308]
atom_expr [60322,60339]
===
match
---
name: task_instance_2 [54182,54197]
name: task_instance_2 [54213,54228]
===
match
---
trailer [66367,66383]
trailer [67991,68007]
===
match
---
operator: , [39566,39567]
operator: , [39597,39598]
===
match
---
name: op4 [7469,7472]
name: op4 [7500,7503]
===
match
---
name: next_local [24966,24976]
name: next_local [24997,25007]
===
match
---
name: subdag [53317,53323]
name: subdag [53348,53354]
===
match
---
operator: = [56517,56518]
operator: = [56548,56549]
===
match
---
string: 'test' [72644,72650]
string: 'test' [74268,74274]
===
match
---
assert_stmt [23708,23762]
assert_stmt [23739,23793]
===
match
---
name: ti1 [76846,76849]
name: ti1 [78470,78473]
===
match
---
operator: , [13775,13776]
operator: , [13806,13807]
===
match
---
operator: , [6796,6797]
operator: , [6827,6828]
===
match
---
atom_expr [39116,39125]
atom_expr [39147,39156]
===
match
---
suite [16233,17146]
suite [16264,17177]
===
match
---
exprlist [16622,16630]
exprlist [16653,16661]
===
match
---
name: DummyOperator [41143,41156]
name: DummyOperator [41174,41187]
===
match
---
operator: } [50834,50835]
operator: } [50865,50866]
===
match
---
operator: , [51595,51596]
operator: , [51626,51627]
===
match
---
operator: == [62662,62664]
operator: == [62693,62695]
===
match
---
trailer [38042,38048]
trailer [38073,38079]
===
match
---
trailer [63148,63162]
trailer [63179,63193]
===
match
---
name: test_dag [17981,17989]
name: test_dag [18012,18020]
===
match
---
operator: , [64080,64081]
operator: , [65704,65705]
===
match
---
name: dr [74517,74519]
name: dr [76141,76143]
===
match
---
name: dag [68162,68165]
name: dag [69786,69789]
===
match
---
operator: , [46827,46828]
operator: , [46858,46859]
===
match
---
name: utils [2144,2149]
name: utils [2175,2180]
===
match
---
name: is_paused_upon_creation [37543,37566]
name: is_paused_upon_creation [37574,37597]
===
match
---
name: start [23505,23510]
name: start [23536,23541]
===
match
---
trailer [22655,22665]
trailer [22686,22696]
===
match
---
name: TestDagDecorator [70622,70638]
name: TestDagDecorator [72246,72262]
===
match
---
operator: == [47299,47301]
operator: == [47330,47332]
===
match
---
atom_expr [21886,21903]
atom_expr [21917,21934]
===
match
---
operator: = [14723,14724]
operator: = [14754,14755]
===
match
---
operator: = [48245,48246]
operator: = [48276,48277]
===
match
---
name: now [59844,59847]
name: now [59875,59878]
===
match
---
name: default_args [6823,6835]
name: default_args [6854,6866]
===
match
---
name: state [46177,46182]
name: state [46208,46213]
===
match
---
simple_stmt [49419,49454]
simple_stmt [49450,49485]
===
match
---
name: include_parentdag [55542,55559]
name: include_parentdag [55573,55590]
===
match
---
parameters [26382,26388]
parameters [26413,26419]
===
match
---
operator: = [42030,42031]
operator: = [42061,42062]
===
match
---
argument [50997,51017]
argument [51028,51048]
===
match
---
funcdef [33358,34107]
funcdef [33389,34138]
===
match
---
trailer [28185,28191]
trailer [28216,28222]
===
match
---
name: set2 [11202,11206]
name: set2 [11233,11237]
===
match
---
expr_stmt [58035,58079]
expr_stmt [58066,58110]
===
match
---
atom_expr [10992,11011]
atom_expr [11023,11042]
===
match
---
suite [64412,65925]
suite [66036,67549]
===
match
---
operator: = [41552,41553]
operator: = [41583,41584]
===
match
---
expr_stmt [59595,59618]
expr_stmt [59626,59649]
===
match
---
expr_stmt [58088,58179]
expr_stmt [58119,58210]
===
match
---
operator: , [46744,46745]
operator: , [46775,46776]
===
match
---
number: 52 [74506,74508]
number: 52 [76130,76132]
===
match
---
argument [53776,53802]
argument [53807,53833]
===
match
---
comparison [48536,48556]
comparison [48567,48587]
===
match
---
argument [43798,43827]
argument [43829,43858]
===
match
---
suite [30829,32009]
suite [30860,32040]
===
match
---
operator: } [65408,65409]
operator: } [67032,67033]
===
match
---
name: default_args [12750,12762]
name: default_args [12781,12793]
===
match
---
name: next_dagrun_info [65658,65674]
name: next_dagrun_info [67282,67298]
===
match
---
trailer [18549,18556]
trailer [18580,18587]
===
match
---
name: DEFAULT_DATE [31383,31395]
name: DEFAULT_DATE [31414,31426]
===
match
---
atom_expr [38574,38611]
atom_expr [38605,38642]
===
match
---
expr_stmt [59828,59877]
expr_stmt [59859,59908]
===
match
---
comparison [19067,19159]
comparison [19098,19190]
===
match
---
arglist [56793,56910]
arglist [56824,56941]
===
match
---
name: expand [55833,55839]
name: expand [55864,55870]
===
match
---
string: "start_date" [70746,70758]
string: "start_date" [72370,72382]
===
match
---
operator: = [49503,49504]
operator: = [49534,49535]
===
match
---
trailer [18704,18709]
trailer [18735,18740]
===
match
---
operator: , [62550,62551]
operator: , [62581,62582]
===
match
---
name: orm_dag [32746,32753]
name: orm_dag [32777,32784]
===
match
---
name: dag_diff_name [48040,48053]
name: dag_diff_name [48071,48084]
===
match
---
operator: = [68426,68427]
operator: = [70050,70051]
===
match
---
param [52963,52968]
param [52994,52999]
===
match
---
comparison [23646,23699]
comparison [23677,23730]
===
match
---
expr_stmt [43560,43607]
expr_stmt [43591,43638]
===
match
---
name: is_active [33205,33214]
name: is_active [33236,33245]
===
match
---
trailer [52668,52707]
trailer [52699,52738]
===
match
---
argument [38785,38808]
argument [38816,38839]
===
match
---
atom_expr [21979,21994]
atom_expr [22010,22025]
===
match
---
expr_stmt [38465,38508]
expr_stmt [38496,38539]
===
match
---
trailer [51030,51035]
trailer [51061,51066]
===
match
---
testlist_comp [75963,75993]
testlist_comp [77587,77617]
===
match
---
name: DAG [12873,12876]
name: DAG [12904,12907]
===
match
---
funcdef [36068,36434]
funcdef [36099,36465]
===
match
---
parameters [36479,36485]
parameters [36510,36516]
===
match
---
trailer [9810,9812]
trailer [9841,9843]
===
match
---
assert_stmt [36832,36856]
assert_stmt [36863,36887]
===
match
---
operator: = [57451,57452]
operator: = [57482,57483]
===
match
---
arith_expr [14395,14433]
arith_expr [14426,14464]
===
match
---
atom_expr [30627,30640]
atom_expr [30658,30671]
===
match
---
simple_stmt [14210,14246]
simple_stmt [14241,14277]
===
match
---
dictorsetmaker [66356,66412]
dictorsetmaker [67980,68036]
===
match
---
trailer [15314,15324]
trailer [15345,15355]
===
match
---
name: synchronize_session [3302,3321]
name: synchronize_session [3333,3352]
===
match
---
trailer [70953,70959]
trailer [72577,72583]
===
match
---
arglist [78155,78262]
arglist [79779,79886]
===
match
---
operator: = [32221,32222]
operator: = [32252,32253]
===
match
---
name: value [73532,73537]
name: value [75156,75161]
===
match
---
operator: } [64765,64766]
operator: } [66389,66390]
===
match
---
operator: , [69669,69670]
operator: , [71293,71294]
===
match
---
name: dag_run_state [51685,51698]
name: dag_run_state [51716,51729]
===
match
---
arglist [31523,31661]
arglist [31554,31692]
===
match
---
trailer [28757,28764]
trailer [28788,28795]
===
match
---
operator: , [31164,31165]
operator: , [31195,31196]
===
match
---
name: session [29439,29446]
name: session [29470,29477]
===
match
---
operator: , [68160,68161]
operator: , [69784,69785]
===
match
---
name: bulk_write_to_db [28997,29013]
name: bulk_write_to_db [29028,29044]
===
match
---
trailer [76072,76082]
trailer [77696,77706]
===
match
---
dotted_name [70080,70100]
dotted_name [71704,71724]
===
match
---
simple_stmt [30116,30143]
simple_stmt [30147,30174]
===
match
---
operator: , [60423,60424]
operator: , [60454,60455]
===
match
---
simple_stmt [38107,38136]
simple_stmt [38138,38167]
===
match
---
name: one [36727,36730]
name: one [36758,36761]
===
match
---
name: topological_list [9986,10002]
name: topological_list [10017,10033]
===
match
---
number: 0 [42234,42235]
number: 0 [42265,42266]
===
match
---
trailer [7717,7720]
trailer [7748,7751]
===
match
---
string: 'subtask' [32526,32535]
string: 'subtask' [32557,32566]
===
match
---
name: DagRunType [73670,73680]
name: DagRunType [75294,75304]
===
match
---
name: task_depth [14405,14415]
name: task_depth [14436,14446]
===
match
---
operator: , [28567,28568]
operator: , [28598,28599]
===
match
---
atom_expr [3464,3479]
atom_expr [3495,3510]
===
match
---
funcdef [25311,25935]
funcdef [25342,25966]
===
match
---
simple_stmt [853,863]
simple_stmt [853,863]
===
match
---
name: models [6107,6113]
name: models [6138,6144]
===
match
---
name: xcom_pass_to_op [75331,75346]
name: xcom_pass_to_op [76955,76970]
===
match
---
operator: , [54320,54321]
operator: , [54351,54352]
===
match
---
operator: , [68117,68118]
operator: , [69741,69742]
===
match
---
assert_stmt [43034,43179]
assert_stmt [43065,43210]
===
match
---
name: when [26631,26635]
name: when [26662,26666]
===
match
---
name: two_hours_ago [60665,60678]
name: two_hours_ago [60696,60709]
===
match
---
number: 1 [14418,14419]
number: 1 [14449,14450]
===
match
---
operator: = [14779,14780]
operator: = [14810,14811]
===
match
---
name: paused_dags [35364,35375]
name: paused_dags [35395,35406]
===
match
---
name: timezone [12829,12837]
name: timezone [12860,12868]
===
match
---
operator: = [74722,74723]
operator: = [76346,76347]
===
match
---
name: Session [36585,36592]
name: Session [36616,36623]
===
match
---
name: dag [47646,47649]
name: dag [47677,47680]
===
match
---
atom_expr [7154,7182]
atom_expr [7185,7213]
===
match
---
atom_expr [28751,28764]
atom_expr [28782,28795]
===
match
---
name: session [54826,54833]
name: session [54857,54864]
===
match
---
trailer [5232,5236]
trailer [5263,5267]
===
match
---
trailer [62463,62475]
trailer [62494,62506]
===
match
---
name: args [47463,47467]
name: args [47494,47498]
===
match
---
comparison [65696,65764]
comparison [67320,67388]
===
match
---
suite [23181,24209]
suite [23212,24240]
===
match
---
name: datetime [57412,57420]
name: datetime [57443,57451]
===
match
---
assert_stmt [19307,19443]
assert_stmt [19338,19474]
===
match
---
operator: == [39609,39611]
operator: == [39640,39642]
===
match
---
simple_stmt [61445,61671]
simple_stmt [61476,61702]
===
match
---
atom_expr [29439,29475]
atom_expr [29470,29506]
===
match
---
string: "@daily" [49933,49941]
string: "@daily" [49964,49972]
===
match
---
operator: = [70384,70385]
operator: = [72008,72009]
===
match
---
operator: == [19461,19463]
operator: == [19492,19494]
===
match
---
parameters [13021,13027]
parameters [13052,13058]
===
match
---
parameters [20745,20751]
parameters [20776,20782]
===
match
---
atom [28332,28408]
atom [28363,28439]
===
match
---
trailer [65397,65408]
trailer [67021,67032]
===
match
---
trailer [73575,73584]
trailer [75199,75208]
===
match
---
name: freeze_time [62060,62071]
name: freeze_time [62091,62102]
===
match
---
operator: , [17882,17883]
operator: , [17913,17914]
===
match
---
arglist [4681,4741]
arglist [4712,4772]
===
match
---
operator: { [40743,40744]
operator: { [40774,40775]
===
match
---
atom_expr [37819,37834]
atom_expr [37850,37865]
===
match
---
trailer [55644,55650]
trailer [55675,55681]
===
match
---
name: timezone [62817,62825]
name: timezone [62848,62856]
===
match
---
name: dag [12515,12518]
name: dag [12546,12549]
===
match
---
parameters [68648,68654]
parameters [70272,70278]
===
match
---
operator: , [59720,59721]
operator: , [59751,59752]
===
match
---
trailer [52071,52078]
trailer [52102,52109]
===
match
---
name: get_ti_from_db [76408,76422]
name: get_ti_from_db [78032,78046]
===
match
---
trailer [29238,29255]
trailer [29269,29286]
===
match
---
name: dag [42726,42729]
name: dag [42757,42760]
===
match
---
trailer [11128,11149]
trailer [11159,11180]
===
match
---
name: os [20946,20948]
name: os [20977,20979]
===
match
---
operator: , [5554,5555]
operator: , [5585,5586]
===
match
---
arglist [39724,39759]
arglist [39755,39790]
===
match
---
name: schedule_interval [58155,58172]
name: schedule_interval [58186,58203]
===
match
---
argument [11407,11430]
argument [11438,11461]
===
match
---
name: datetime [12904,12912]
name: datetime [12935,12943]
===
match
---
string: """         Test the subdags are never marked to have dagruns created, as they are         handled by the SubDagOperator, not the scheduler         """ [64421,64572]
string: """         Test the subdags are never marked to have dagruns created, as they are         handled by the SubDagOperator, not the scheduler         """ [66045,66196]
===
match
---
name: isinstance [76964,76974]
name: isinstance [78588,78598]
===
match
---
trailer [23357,23366]
trailer [23388,23397]
===
match
---
operator: = [17770,17771]
operator: = [17801,17802]
===
match
---
atom_expr [33847,33865]
atom_expr [33878,33896]
===
match
---
operator: = [16121,16122]
operator: = [16152,16153]
===
match
---
trailer [46386,46396]
trailer [46417,46427]
===
match
---
name: values [14184,14190]
name: values [14215,14221]
===
match
---
trailer [28470,28477]
trailer [28501,28508]
===
match
---
operator: = [66501,66502]
operator: = [68125,68126]
===
match
---
name: when [26683,26687]
name: when [26714,26718]
===
match
---
trailer [21636,21707]
trailer [21667,21738]
===
match
---
atom_expr [76297,76310]
atom_expr [77921,77934]
===
match
---
name: utcnow [60763,60769]
name: utcnow [60794,60800]
===
match
---
operator: == [73981,73983]
operator: == [75605,75607]
===
match
---
name: relativedelta [1180,1193]
name: relativedelta [1186,1199]
===
match
---
suite [8593,8801]
suite [8624,8832]
===
match
---
number: 25 [26113,26115]
number: 25 [26144,26146]
===
match
---
name: name [30649,30653]
name: name [30680,30684]
===
match
---
number: 2020 [75587,75591]
number: 2020 [77211,77215]
===
match
---
atom_expr [7230,7239]
atom_expr [7261,7270]
===
match
---
trailer [68821,68864]
trailer [70445,70488]
===
match
---
name: values [15579,15585]
name: values [15610,15616]
===
match
---
string: "Task id 't1' has already been added to the DAG" [40443,40491]
string: "Task id 't1' has already been added to the DAG" [40474,40522]
===
match
---
argument [18523,18537]
argument [18554,18568]
===
match
---
atom_expr [78050,78077]
atom_expr [79674,79701]
===
match
---
name: start_date [60015,60025]
name: start_date [60046,60056]
===
match
---
name: DummyOperator [9570,9583]
name: DummyOperator [9601,9614]
===
match
---
name: dag_id [32704,32710]
name: dag_id [32735,32741]
===
match
---
string: 'owner' [6837,6844]
string: 'owner' [6868,6875]
===
match
---
name: path [20949,20953]
name: path [20980,20984]
===
match
---
simple_stmt [51297,51350]
simple_stmt [51328,51381]
===
match
---
trailer [57049,57056]
trailer [57080,57087]
===
match
---
operator: = [57622,57623]
operator: = [57653,57654]
===
match
---
operator: = [18405,18406]
operator: = [18436,18437]
===
match
---
name: DAG [70233,70236]
name: DAG [71857,71860]
===
match
---
param [74210,74226]
param [75834,75850]
===
match
---
name: DEFAULT_DATE [6809,6821]
name: DEFAULT_DATE [6840,6852]
===
match
---
name: session [55224,55231]
name: session [55255,55262]
===
match
---
operator: , [44115,44116]
operator: , [44146,44147]
===
match
---
arglist [8996,9036]
arglist [9027,9067]
===
match
---
name: dagrun [76297,76303]
name: dagrun [77921,77927]
===
match
---
trailer [31621,31631]
trailer [31652,31662]
===
match
---
argument [27450,27466]
argument [27481,27497]
===
match
---
operator: = [53714,53715]
operator: = [53745,53746]
===
match
---
string: 'test_clear_dag' [56088,56104]
string: 'test_clear_dag' [56119,56135]
===
match
---
testlist_comp [21999,22024]
testlist_comp [22030,22055]
===
match
---
name: get [32923,32926]
name: get [32954,32957]
===
match
---
number: 19800 [27084,27089]
number: 19800 [27115,27120]
===
match
---
name: DEFAULT_DATE [34276,34288]
name: DEFAULT_DATE [34307,34319]
===
match
---
name: timezone [38631,38639]
name: timezone [38662,38670]
===
match
---
atom_expr [10109,10142]
atom_expr [10140,10173]
===
match
---
operator: , [16464,16465]
operator: , [16495,16496]
===
match
---
trailer [34098,34104]
trailer [34129,34135]
===
match
---
string: 'C' [9637,9640]
string: 'C' [9668,9671]
===
match
---
atom_expr [44995,45015]
atom_expr [45026,45046]
===
match
---
name: dag [72632,72635]
name: dag [74256,74259]
===
match
---
operator: = [66924,66925]
operator: = [68548,68549]
===
match
---
arith_expr [78527,78569]
arith_expr [80151,80193]
===
match
---
name: params [4163,4169]
name: params [4194,4200]
===
match
---
expr_stmt [53072,53133]
expr_stmt [53103,53164]
===
match
---
simple_stmt [9654,9687]
simple_stmt [9685,9718]
===
match
---
trailer [61571,61583]
trailer [61602,61614]
===
match
---
funcdef [26736,27651]
funcdef [26767,27682]
===
match
---
operator: , [35002,35003]
operator: , [35033,35034]
===
match
---
operator: , [8489,8490]
operator: , [8520,8521]
===
match
---
name: _name [27144,27149]
name: _name [27175,27180]
===
match
---
suite [75200,75228]
suite [76824,76852]
===
match
---
comparison [7959,7973]
comparison [7990,8004]
===
match
---
not_test [36410,36433]
not_test [36441,36464]
===
match
---
atom_expr [77099,77112]
atom_expr [78723,78736]
===
match
---
atom_expr [55110,55123]
atom_expr [55141,55154]
===
match
---
assert_stmt [12586,12669]
assert_stmt [12617,12700]
===
match
---
name: TypeError [73158,73167]
name: TypeError [74782,74791]
===
match
---
expr_stmt [59627,59755]
expr_stmt [59658,59786]
===
match
---
name: dag [63579,63582]
name: dag [65203,65206]
===
match
---
comparison [25258,25305]
comparison [25289,25336]
===
match
---
expr_stmt [65994,66220]
expr_stmt [67618,67844]
===
match
---
atom_expr [3200,3216]
atom_expr [3231,3247]
===
match
---
name: op2 [9564,9567]
name: op2 [9595,9598]
===
match
---
param [23175,23179]
param [23206,23210]
===
match
---
assert_stmt [23092,23110]
assert_stmt [23123,23141]
===
match
---
operator: = [50315,50316]
operator: = [50346,50347]
===
match
---
suite [37724,37769]
suite [37755,37800]
===
match
---
testlist_comp [30459,30489]
testlist_comp [30490,30520]
===
match
---
number: 0 [57191,57192]
number: 0 [57222,57223]
===
match
---
name: dag [53072,53075]
name: dag [53103,53106]
===
match
---
operator: { [66017,66018]
operator: { [67641,67642]
===
match
---
argument [47117,47139]
argument [47148,47170]
===
match
---
name: RUNNING [67159,67166]
name: RUNNING [68783,68790]
===
match
---
param [71089,71093]
param [72713,72717]
===
match
---
name: default_view [32854,32866]
name: default_view [32885,32897]
===
match
---
string: 'test_scheduler_dagrun_once_with_timedelta_and_catchup_false' [61468,61529]
string: 'test_scheduler_dagrun_once_with_timedelta_and_catchup_false' [61499,61560]
===
match
---
trailer [9324,9390]
trailer [9355,9421]
===
match
---
name: six_hours_ago_to_the_hour [61125,61150]
name: six_hours_ago_to_the_hour [61156,61181]
===
match
---
trailer [52275,52283]
trailer [52306,52314]
===
match
---
name: subdag_id [35082,35091]
name: subdag_id [35113,35122]
===
match
---
simple_stmt [18691,18710]
simple_stmt [18722,18741]
===
match
---
name: row [28803,28806]
name: row [28834,28837]
===
match
---
name: interval [78125,78133]
name: interval [79749,79757]
===
match
---
name: ti3 [18481,18484]
name: ti3 [18512,18515]
===
match
---
atom_expr [55883,55900]
atom_expr [55914,55931]
===
match
---
name: logical_date [61758,61770]
name: logical_date [61789,61801]
===
match
---
comparison [52745,52768]
comparison [52776,52799]
===
match
---
trailer [76889,76895]
trailer [78513,78519]
===
match
---
simple_stmt [9609,9642]
simple_stmt [9640,9673]
===
match
---
operator: = [53784,53785]
operator: = [53815,53816]
===
match
---
operator: , [47832,47833]
operator: , [47863,47864]
===
match
---
name: task_id [39893,39900]
name: task_id [39924,39931]
===
match
---
name: op8 [7842,7845]
name: op8 [7873,7876]
===
match
---
name: success [44255,44262]
name: success [44286,44293]
===
match
---
trailer [46119,46197]
trailer [46150,46228]
===
match
---
operator: = [26524,26525]
operator: = [26555,26556]
===
match
---
name: task_depth [15790,15800]
name: task_depth [15821,15831]
===
match
---
name: template_dir [21050,21062]
name: template_dir [21081,21093]
===
match
---
trailer [36661,36667]
trailer [36692,36698]
===
match
---
operator: , [47230,47231]
operator: , [47261,47262]
===
match
---
simple_stmt [48110,48169]
simple_stmt [48141,48200]
===
match
---
parameters [10220,10226]
parameters [10251,10257]
===
match
---
expr_stmt [20879,20917]
expr_stmt [20910,20948]
===
match
---
with_stmt [6866,6980]
with_stmt [6897,7011]
===
match
---
name: op2 [41747,41750]
name: op2 [41778,41781]
===
match
---
simple_stmt [32467,32491]
simple_stmt [32498,32522]
===
match
---
name: tags [29160,29164]
name: tags [29191,29195]
===
match
---
with_item [39250,39297]
with_item [39281,39328]
===
match
---
operator: = [60816,60817]
operator: = [60847,60848]
===
match
---
operator: , [52544,52545]
operator: , [52575,52576]
===
match
---
name: datetime [23358,23366]
name: datetime [23389,23397]
===
match
---
operator: = [53497,53498]
operator: = [53528,53529]
===
match
---
simple_stmt [34432,34510]
simple_stmt [34463,34541]
===
match
---
assert_stmt [48958,48989]
assert_stmt [48989,49020]
===
match
---
name: DagRun [77016,77022]
name: DagRun [78640,78646]
===
match
---
name: TI [18520,18522]
name: TI [18551,18553]
===
match
---
trailer [45230,45236]
trailer [45261,45267]
===
match
---
name: DummyOperator [42009,42022]
name: DummyOperator [42040,42053]
===
match
---
operator: = [61449,61450]
operator: = [61480,61481]
===
match
---
name: hours [44692,44697]
name: hours [44723,44728]
===
match
---
name: sync_to_db [46080,46090]
name: sync_to_db [46111,46121]
===
match
---
operator: = [10630,10631]
operator: = [10661,10662]
===
match
---
parameters [73230,73236]
parameters [74854,74860]
===
match
---
name: dr1 [17736,17739]
name: dr1 [17767,17770]
===
match
---
argument [17777,17791]
argument [17808,17822]
===
match
---
name: self [36921,36925]
name: self [36952,36956]
===
match
---
operator: = [17783,17784]
operator: = [17814,17815]
===
match
---
simple_stmt [72094,72122]
simple_stmt [73718,73746]
===
match
---
string: "test_dag" [41416,41426]
string: "test_dag" [41447,41457]
===
match
---
atom_expr [50631,50664]
atom_expr [50662,50695]
===
match
---
operator: , [52262,52263]
operator: , [52293,52294]
===
match
---
trailer [18321,18327]
trailer [18352,18358]
===
match
---
trailer [19206,19298]
trailer [19237,19329]
===
match
---
suite [29143,29185]
suite [29174,29216]
===
match
---
assert_stmt [20398,20435]
assert_stmt [20429,20466]
===
match
---
name: DagModel [34987,34995]
name: DagModel [35018,35026]
===
match
---
string: '.template' [21437,21448]
string: '.template' [21468,21479]
===
match
---
operator: , [25665,25666]
operator: , [25696,25697]
===
match
---
name: _ [60991,60992]
name: _ [61022,61023]
===
match
---
simple_stmt [55224,55253]
simple_stmt [55255,55284]
===
match
---
decorator [3530,3544]
decorator [3561,3575]
===
match
---
trailer [22734,22736]
trailer [22765,22767]
===
match
---
simple_stmt [27144,27160]
simple_stmt [27175,27191]
===
match
---
expr_stmt [58385,58427]
expr_stmt [58416,58458]
===
match
---
fstring_end: ' [64980,64981]
fstring_end: ' [66604,66605]
===
match
---
argument [78189,78196]
argument [79813,79820]
===
match
---
operator: = [21730,21731]
operator: = [21761,21762]
===
match
---
name: session [29928,29935]
name: session [29959,29966]
===
match
---
atom_expr [23715,23731]
atom_expr [23746,23762]
===
match
---
name: schedule_interval [50492,50509]
name: schedule_interval [50523,50540]
===
match
---
expr_stmt [4103,4131]
expr_stmt [4134,4162]
===
match
---
parameters [40317,40323]
parameters [40348,40354]
===
match
---
operator: , [39545,39546]
operator: , [39576,39577]
===
match
---
param [38309,38313]
param [38340,38344]
===
match
---
name: default_args [12553,12565]
name: default_args [12584,12596]
===
match
---
operator: , [19005,19006]
operator: , [19036,19037]
===
match
---
expr_stmt [70227,70288]
expr_stmt [71851,71912]
===
match
---
atom_expr [6107,6175]
atom_expr [6138,6206]
===
match
---
operator: @ [43326,43327]
operator: @ [43357,43358]
===
match
---
argument [21430,21448]
argument [21461,21479]
===
match
---
operator: -> [2834,2836]
operator: -> [2865,2867]
===
match
---
atom_expr [77350,77378]
atom_expr [78974,79002]
===
match
---
name: query [52663,52668]
name: query [52694,52699]
===
match
---
operator: , [28350,28351]
operator: , [28381,28382]
===
match
---
suite [13957,13987]
suite [13988,14018]
===
match
---
trailer [56373,56541]
trailer [56404,56572]
===
match
---
trailer [69395,69416]
trailer [71019,71040]
===
match
---
name: dag [12825,12828]
name: dag [12856,12859]
===
match
---
string: "test-dag2" [29172,29183]
string: "test-dag2" [29203,29214]
===
match
---
decorated [55037,55813]
decorated [55068,55844]
===
match
---
operator: = [65652,65653]
operator: = [67276,67277]
===
match
---
trailer [67063,67077]
trailer [68687,68701]
===
match
---
argument [42757,42786]
argument [42788,42817]
===
match
---
expr_stmt [16246,16605]
expr_stmt [16277,16636]
===
match
---
trailer [71896,71909]
trailer [73520,73533]
===
match
---
decorator [75046,75093]
decorator [76670,76717]
===
match
---
string: 'test-dag2' [30478,30489]
string: 'test-dag2' [30509,30520]
===
match
---
operator: = [67756,67757]
operator: = [69380,69381]
===
match
---
atom_expr [67934,67952]
atom_expr [69558,69576]
===
match
---
simple_stmt [59887,60090]
simple_stmt [59918,60121]
===
match
---
name: warns [66446,66451]
name: warns [68070,68075]
===
match
---
operator: { [15026,15027]
operator: { [15057,15058]
===
match
---
name: parameterized [54233,54246]
name: parameterized [54264,54277]
===
match
---
trailer [3133,3135]
trailer [3164,3166]
===
match
---
arglist [57047,57067]
arglist [57078,57098]
===
match
---
operator: , [70377,70378]
operator: , [72001,72002]
===
match
---
trailer [38194,38221]
trailer [38225,38252]
===
match
---
with_item [39720,39767]
with_item [39751,39798]
===
match
---
arglist [68822,68863]
arglist [70446,70487]
===
match
---
simple_stmt [2235,2294]
simple_stmt [2266,2325]
===
match
---
argument [39736,39759]
argument [39767,39790]
===
match
---
operator: - [78352,78353]
operator: - [79976,79977]
===
match
---
operator: , [33434,33435]
operator: , [33465,33466]
===
match
---
arglist [60347,60501]
arglist [60378,60532]
===
match
---
operator: == [19069,19071]
operator: == [19100,19102]
===
match
---
atom_expr [32813,32830]
atom_expr [32844,32861]
===
match
---
operator: = [59299,59300]
operator: = [59330,59331]
===
match
---
operator: = [53203,53204]
operator: = [53234,53235]
===
match
---
string: "t4" [39477,39481]
string: "t4" [39508,39512]
===
match
---
simple_stmt [48348,48383]
simple_stmt [48379,48414]
===
match
---
atom_expr [25529,25552]
atom_expr [25560,25583]
===
match
---
operator: = [41027,41028]
operator: = [41058,41059]
===
match
---
trailer [33102,33104]
trailer [33133,33135]
===
match
---
name: len [52829,52832]
name: len [52860,52863]
===
match
---
argument [51437,51453]
argument [51468,51484]
===
match
---
argument [42643,42663]
argument [42674,42694]
===
match
---
trailer [10806,10811]
trailer [10837,10842]
===
match
---
name: max_active_runs [56210,56225]
name: max_active_runs [56241,56256]
===
match
---
name: DAG [40511,40514]
name: DAG [40542,40545]
===
match
---
operator: , [8234,8235]
operator: , [8265,8266]
===
match
---
name: dag_id [36694,36700]
name: dag_id [36725,36731]
===
match
---
name: prev [24812,24816]
name: prev [24843,24847]
===
match
---
decorator [75152,75168]
decorator [76776,76792]
===
match
---
name: get_ti_from_db [76457,76471]
name: get_ti_from_db [78081,78095]
===
match
---
string: 'test_subdag_operator' [65068,65090]
string: 'test_subdag_operator' [66692,66714]
===
match
---
param [27349,27351]
param [27380,27382]
===
match
---
expr_stmt [52209,52284]
expr_stmt [52240,52315]
===
match
---
name: datetime [78170,78178]
name: datetime [79794,79802]
===
match
---
atom_expr [42630,42705]
atom_expr [42661,42736]
===
match
---
atom_expr [76643,76773]
atom_expr [78267,78397]
===
match
---
name: hours [78189,78194]
name: hours [79813,79818]
===
match
---
simple_stmt [50625,50665]
simple_stmt [50656,50696]
===
match
---
dotted_name [2051,2064]
dotted_name [2082,2095]
===
match
---
number: 1 [70842,70843]
number: 1 [72466,72467]
===
match
---
trailer [23562,23580]
trailer [23593,23611]
===
match
---
arglist [6019,6092]
arglist [6050,6123]
===
match
---
simple_stmt [2081,2131]
simple_stmt [2112,2162]
===
match
---
operator: , [21210,21211]
operator: , [21241,21242]
===
match
---
comparison [30757,30775]
comparison [30788,30806]
===
match
---
param [26790,26794]
param [26821,26825]
===
match
---
name: next_subdag_info [65774,65790]
name: next_subdag_info [67398,67414]
===
match
---
simple_stmt [69374,69432]
simple_stmt [70998,71056]
===
match
---
trailer [55702,55709]
trailer [55733,55740]
===
match
---
operator: , [69144,69145]
operator: , [70768,70769]
===
match
---
operator: == [66759,66761]
operator: == [68383,68385]
===
match
---
decorated [71452,71651]
decorated [73076,73275]
===
match
---
name: altered [76633,76640]
name: altered [78257,78264]
===
match
---
operator: = [70542,70543]
operator: = [72166,72167]
===
match
---
atom_expr [62737,62760]
atom_expr [62768,62791]
===
match
---
name: test_dag_id [19099,19110]
name: test_dag_id [19130,19141]
===
match
---
name: run_id [17884,17890]
name: run_id [17915,17921]
===
match
---
trailer [34810,34814]
trailer [34841,34845]
===
match
---
atom_expr [45223,45265]
atom_expr [45254,45296]
===
match
---
simple_stmt [64421,64573]
simple_stmt [66045,66197]
===
match
---
operator: == [8027,8029]
operator: == [8058,8060]
===
match
---
atom_expr [4849,4873]
atom_expr [4880,4904]
===
match
---
name: op2 [41628,41631]
name: op2 [41659,41662]
===
match
---
trailer [3096,3098]
trailer [3127,3129]
===
match
---
name: hours [77890,77895]
name: hours [79514,79519]
===
match
---
atom_expr [64294,64316]
atom_expr [65918,65940]
===
match
---
atom_expr [75331,75348]
atom_expr [76955,76972]
===
match
---
trailer [50634,50664]
trailer [50665,50695]
===
match
---
atom_expr [72881,72898]
atom_expr [74505,74522]
===
match
---
expr_stmt [75325,75348]
expr_stmt [76949,76972]
===
match
---
trailer [35287,35299]
trailer [35318,35330]
===
match
---
atom_expr [76514,76542]
atom_expr [78138,78166]
===
match
---
name: get [6394,6397]
name: get [6425,6428]
===
match
---
name: test_following_schedule_datetime_timezone_utc0530 [26740,26789]
name: test_following_schedule_datetime_timezone_utc0530 [26771,26820]
===
match
---
string: "in-dag-restriction" [78632,78652]
string: "in-dag-restriction" [80256,80276]
===
match
---
expr_stmt [53196,53270]
expr_stmt [53227,53301]
===
match
---
atom_expr [71892,71909]
atom_expr [73516,73533]
===
match
---
name: self [13022,13026]
name: self [13053,13057]
===
match
---
name: operator [74424,74432]
name: operator [76048,76056]
===
match
---
name: test_dag_topological_sort1 [9273,9299]
name: test_dag_topological_sort1 [9304,9330]
===
match
---
suite [70439,70614]
suite [72063,72238]
===
match
---
string: "string" [5156,5164]
string: "string" [5187,5195]
===
match
---
name: _next [24025,24030]
name: _next [24056,24061]
===
match
---
name: suffix [20786,20792]
name: suffix [20817,20823]
===
match
---
trailer [24976,24986]
trailer [25007,25017]
===
match
---
number: 1 [15475,15476]
number: 1 [15506,15507]
===
match
---
operator: = [33923,33924]
operator: = [33954,33955]
===
match
---
trailer [7472,7478]
trailer [7503,7509]
===
match
---
name: lower [32960,32965]
name: lower [32991,32996]
===
match
---
operator: = [32053,32054]
operator: = [32084,32085]
===
match
---
trailer [2766,2775]
trailer [2797,2806]
===
match
---
dictorsetmaker [38394,38454]
dictorsetmaker [38425,38485]
===
match
---
name: DEFAULT_DATE [69033,69045]
name: DEFAULT_DATE [70657,70669]
===
match
---
name: group [15680,15685]
name: group [15711,15716]
===
match
---
name: prev_local [23646,23656]
name: prev_local [23677,23687]
===
match
---
trailer [74577,74583]
trailer [76201,76207]
===
match
---
atom_expr [35480,35520]
atom_expr [35511,35551]
===
match
---
argument [51307,51348]
argument [51338,51379]
===
match
---
operator: = [14479,14480]
operator: = [14510,14511]
===
match
---
string: """         Tests if a start_date of None in default_args         works.         """ [13037,13121]
string: """         Tests if a start_date of None in default_args         works.         """ [13068,13152]
===
match
---
atom_expr [62639,62661]
atom_expr [62670,62692]
===
match
---
simple_stmt [52631,52813]
simple_stmt [52662,52844]
===
match
---
simple_stmt [7019,7048]
simple_stmt [7050,7079]
===
match
---
operator: = [54638,54639]
operator: = [54669,54670]
===
match
---
atom_expr [55727,55737]
atom_expr [55758,55768]
===
match
---
argument [51853,51870]
argument [51884,51901]
===
match
---
name: basename [20954,20962]
name: basename [20985,20993]
===
match
---
name: start_date [44820,44830]
name: start_date [44851,44861]
===
match
---
trailer [14278,14294]
trailer [14309,14325]
===
match
---
argument [32628,32643]
argument [32659,32674]
===
match
---
name: all [57095,57098]
name: all [57126,57129]
===
match
---
name: dates [58682,58687]
name: dates [58713,58718]
===
match
---
number: 1 [31864,31865]
number: 1 [31895,31896]
===
match
---
atom [49646,49654]
atom [49677,49685]
===
match
---
atom_expr [77382,77395]
atom_expr [79006,79019]
===
match
---
name: dag [22474,22477]
name: dag [22505,22508]
===
match
---
name: TEST_DATE [42815,42824]
name: TEST_DATE [42846,42855]
===
match
---
operator: = [45860,45861]
operator: = [45891,45892]
===
match
---
string: 'b_child' [9223,9232]
string: 'b_child' [9254,9263]
===
match
---
operator: = [53169,53170]
operator: = [53200,53201]
===
match
---
arglist [19504,19592]
arglist [19535,19623]
===
match
---
name: dag [42584,42587]
name: dag [42615,42618]
===
match
---
name: dag [41120,41123]
name: dag [41151,41154]
===
match
---
name: merge [18672,18677]
name: merge [18703,18708]
===
match
---
simple_stmt [38697,38756]
simple_stmt [38728,38787]
===
match
---
trailer [42743,42868]
trailer [42774,42899]
===
match
---
name: DagModel [38161,38169]
name: DagModel [38192,38200]
===
match
---
trailer [13751,13800]
trailer [13782,13831]
===
match
---
name: subdag [34731,34737]
name: subdag [34762,34768]
===
match
---
number: 2016 [63944,63948]
number: 2016 [65568,65572]
===
match
---
name: DEFAULT_DATE [38796,38808]
name: DEFAULT_DATE [38827,38839]
===
match
---
suite [49410,49845]
suite [49441,49876]
===
match
---
name: ti3 [18429,18432]
name: ti3 [18460,18463]
===
match
---
name: topological_list [9771,9787]
name: topological_list [9802,9818]
===
match
---
expr_stmt [70970,70990]
expr_stmt [72594,72614]
===
match
---
name: test_dag_param_resolves [73207,73230]
name: test_dag_param_resolves [74831,74854]
===
match
---
operator: , [15294,15295]
operator: , [15325,15326]
===
match
---
number: 1 [10053,10054]
number: 1 [10084,10085]
===
match
---
trailer [42776,42786]
trailer [42807,42817]
===
match
---
trailer [44439,44447]
trailer [44470,44478]
===
match
---
name: self [2899,2903]
name: self [2930,2934]
===
match
---
name: _clean_up [51761,51770]
name: _clean_up [51792,51801]
===
match
---
arith_expr [78339,78381]
arith_expr [79963,80005]
===
match
---
string: 'parent_dag.child_dag' [8135,8157]
string: 'parent_dag.child_dag' [8166,8188]
===
match
---
trailer [75078,75091]
trailer [76702,76715]
===
match
---
assert_stmt [46425,46457]
assert_stmt [46456,46488]
===
match
---
operator: = [31113,31114]
operator: = [31144,31145]
===
match
---
simple_stmt [65259,65426]
simple_stmt [66883,67050]
===
match
---
and_test [64280,64357]
and_test [65904,65981]
===
match
---
name: args [48246,48250]
name: args [48277,48281]
===
match
---
trailer [51953,51961]
trailer [51984,51992]
===
match
---
name: self [56019,56023]
name: self [56050,56054]
===
match
---
string: 'owner' [13668,13675]
string: 'owner' [13699,13706]
===
match
---
atom_expr [46893,46910]
atom_expr [46924,46941]
===
match
---
atom_expr [28069,28084]
atom_expr [28100,28115]
===
match
---
trailer [50066,50079]
trailer [50097,50110]
===
match
---
name: start_date [11407,11417]
name: start_date [11438,11448]
===
match
---
simple_stmt [1131,1145]
simple_stmt [1137,1151]
===
match
---
name: query [3441,3446]
name: query [3472,3477]
===
match
---
trailer [47536,47568]
trailer [47567,47599]
===
match
---
operator: = [74653,74654]
operator: = [76277,76278]
===
match
---
name: pendulum [24491,24499]
name: pendulum [24522,24530]
===
match
---
name: ACTION_CAN_EDIT [66316,66331]
name: ACTION_CAN_EDIT [67940,67955]
===
match
---
simple_stmt [70970,70991]
simple_stmt [72594,72615]
===
match
---
arglist [69555,69731]
arglist [71179,71355]
===
match
---
with_stmt [7537,7642]
with_stmt [7568,7673]
===
match
---
name: test_dag_id [19504,19515]
name: test_dag_id [19535,19546]
===
match
---
param [14627,14631]
param [14658,14662]
===
match
---
operator: = [17642,17643]
operator: = [17673,17674]
===
match
---
operator: , [47070,47071]
operator: , [47101,47102]
===
match
---
name: task_id [13752,13759]
name: task_id [13783,13790]
===
match
---
name: dag_diff_load_time [48572,48590]
name: dag_diff_load_time [48603,48621]
===
match
---
argument [45828,45841]
argument [45859,45872]
===
match
---
name: name [21609,21613]
name: name [21640,21644]
===
match
---
operator: , [53250,53251]
operator: , [53281,53282]
===
match
---
simple_stmt [32431,32455]
simple_stmt [32462,32486]
===
match
---
string: "test_set_task_instance_state" [75618,75648]
string: "test_set_task_instance_state" [77242,77272]
===
match
---
operator: = [68242,68243]
operator: = [69866,69867]
===
match
---
operator: = [20550,20551]
operator: = [20581,20582]
===
match
---
name: parameterized [70080,70093]
name: parameterized [71704,71717]
===
match
---
suite [6492,8035]
suite [6523,8066]
===
match
---
trailer [14173,14183]
trailer [14204,14214]
===
match
---
name: i [14076,14077]
name: i [14107,14108]
===
match
---
name: self [70199,70203]
name: self [71823,71827]
===
match
---
operator: = [56643,56644]
operator: = [56674,56675]
===
match
---
suite [30733,30776]
suite [30764,30807]
===
match
---
name: fileloc [37909,37916]
name: fileloc [37940,37947]
===
match
---
name: str [56064,56067]
name: str [56095,56098]
===
match
---
name: subdag [34581,34587]
name: subdag [34612,34618]
===
match
---
atom_expr [42766,42786]
atom_expr [42797,42817]
===
match
---
atom_expr [23281,23315]
atom_expr [23312,23346]
===
match
---
operator: = [16400,16401]
operator: = [16431,16432]
===
match
---
name: DEFAULT_DATE [56839,56851]
name: DEFAULT_DATE [56870,56882]
===
match
---
comparison [48930,48949]
comparison [48961,48980]
===
match
---
operator: = [53933,53934]
operator: = [53964,53965]
===
match
---
trailer [46437,46449]
trailer [46468,46480]
===
match
---
arglist [37284,37315]
arglist [37315,37346]
===
match
---
dictorsetmaker [35986,36032]
dictorsetmaker [36017,36063]
===
match
---
suite [66670,66725]
suite [68294,68349]
===
match
---
operator: = [78898,78899]
operator: = [80522,80523]
===
match
---
operator: , [67129,67130]
operator: , [68753,68754]
===
match
---
operator: , [62994,62995]
operator: , [63025,63026]
===
match
---
name: expected_timetable [50543,50561]
name: expected_timetable [50574,50592]
===
match
---
name: Session [67479,67486]
name: Session [69103,69110]
===
match
---
name: timezone [62665,62673]
name: timezone [62696,62704]
===
match
---
name: DuplicateTaskIdFound [40415,40435]
name: DuplicateTaskIdFound [40446,40466]
===
match
---
assert_stmt [71271,71305]
assert_stmt [72895,72929]
===
match
---
trailer [33863,33865]
trailer [33894,33896]
===
match
---
name: dag [46926,46929]
name: dag [46957,46960]
===
match
---
name: local_tz [23607,23615]
name: local_tz [23638,23646]
===
match
---
name: MANUAL [74571,74577]
name: MANUAL [76195,76201]
===
match
---
trailer [6436,6448]
trailer [6467,6479]
===
match
---
name: dag [24003,24006]
name: dag [24034,24037]
===
match
---
argument [46957,46996]
argument [46988,47027]
===
match
---
atom_expr [37506,37582]
atom_expr [37537,37613]
===
match
---
name: current_task [16731,16743]
name: current_task [16762,16774]
===
match
---
name: args [48026,48030]
name: args [48057,48061]
===
match
---
name: datetime [2270,2278]
name: datetime [2301,2309]
===
match
---
name: convert_to_utc [23443,23457]
name: convert_to_utc [23474,23488]
===
match
---
trailer [34555,34588]
trailer [34586,34619]
===
match
---
trailer [54433,54441]
trailer [54464,54472]
===
match
---
simple_stmt [16095,16107]
simple_stmt [16126,16138]
===
match
---
simple_stmt [23270,23316]
simple_stmt [23301,23347]
===
match
---
trailer [20061,20070]
trailer [20092,20101]
===
match
---
trailer [76646,76670]
trailer [78270,78294]
===
match
---
simple_stmt [18771,18854]
simple_stmt [18802,18885]
===
match
---
trailer [68144,68187]
trailer [69768,69811]
===
match
---
trailer [76584,76590]
trailer [78208,78214]
===
match
---
atom_expr [12841,12858]
atom_expr [12872,12889]
===
match
---
name: dag [73594,73597]
name: dag [75218,75221]
===
match
---
suite [27197,27244]
suite [27228,27275]
===
match
---
parameters [5303,5309]
parameters [5334,5340]
===
match
---
simple_stmt [56770,56921]
simple_stmt [56801,56952]
===
match
---
name: dag [69844,69847]
name: dag [71468,71471]
===
match
---
name: datetime [26095,26103]
name: datetime [26126,26134]
===
match
---
name: permissions [66041,66052]
name: permissions [67665,67676]
===
match
---
operator: == [19316,19318]
operator: == [19347,19349]
===
match
---
atom_expr [69699,69718]
atom_expr [71323,71342]
===
match
---
name: dag2 [7419,7423]
name: dag2 [7450,7454]
===
match
---
dictorsetmaker [29421,29475]
dictorsetmaker [29452,29506]
===
match
---
operator: = [78865,78866]
operator: = [80489,80490]
===
match
---
name: next_info [62791,62800]
name: next_info [62822,62831]
===
match
---
arglist [59916,60079]
arglist [59947,60110]
===
match
---
name: models [5226,5232]
name: models [5257,5263]
===
match
---
arith_expr [55412,55453]
arith_expr [55443,55484]
===
match
---
argument [9332,9355]
argument [9363,9386]
===
match
---
trailer [39422,39436]
trailer [39453,39467]
===
match
---
expr_stmt [42716,42868]
expr_stmt [42747,42899]
===
match
---
name: match [40954,40959]
name: match [40985,40990]
===
match
---
name: get_default_view [37253,37269]
name: get_default_view [37284,37300]
===
match
---
name: e [3750,3751]
name: e [3781,3782]
===
match
---
name: setUp [70954,70959]
name: setUp [72578,72583]
===
match
---
operator: , [27444,27445]
operator: , [27475,27476]
===
match
---
name: ti1 [18318,18321]
name: ti1 [18349,18352]
===
match
---
name: pipeline [15462,15470]
name: pipeline [15493,15501]
===
match
---
simple_stmt [65689,65765]
simple_stmt [67313,67389]
===
match
---
suite [20752,21348]
suite [20783,21379]
===
match
---
shift_expr [42049,42059]
shift_expr [42080,42090]
===
match
---
name: args [48095,48099]
name: args [48126,48130]
===
match
---
atom_expr [24704,24726]
atom_expr [24735,24757]
===
match
---
name: include_subdags [52523,52538]
name: include_subdags [52554,52569]
===
match
---
trailer [12531,12545]
trailer [12562,12576]
===
match
---
atom_expr [34051,34071]
atom_expr [34082,34102]
===
match
---
name: mock_callback_with_exception [43616,43644]
name: mock_callback_with_exception [43647,43675]
===
match
---
operator: = [31160,31161]
operator: = [31191,31192]
===
match
---
string: 'dummy' [68153,68160]
string: 'dummy' [69777,69784]
===
match
---
string: """         Test that when 'params' exists as a key passed to the default_args dict         in addition to params being passed explicitly as an argument to the         dag, that the 'params' key of the default_args dict is merged with the         dict of the params argument.         """ [4295,4582]
string: """         Test that when 'params' exists as a key passed to the default_args dict         in addition to params being passed explicitly as an argument to the         dag, that the 'params' key of the default_args dict is merged with the         dict of the params argument.         """ [4326,4613]
===
match
---
trailer [50300,50310]
trailer [50331,50341]
===
match
---
name: dag [70397,70400]
name: dag [72021,72024]
===
match
---
funcdef [11327,11511]
funcdef [11358,11542]
===
match
---
name: session [19611,19618]
name: session [19642,19649]
===
match
---
name: params [75368,75374]
name: params [76992,76998]
===
match
---
name: schedule_interval [65189,65206]
name: schedule_interval [66813,66830]
===
match
---
trailer [50715,50722]
trailer [50746,50753]
===
match
---
name: self [23175,23179]
name: self [23206,23210]
===
match
---
name: test_dag_handle_callback_crash [43369,43399]
name: test_dag_handle_callback_crash [43400,43430]
===
match
---
parameters [3035,3041]
parameters [3066,3072]
===
match
---
operator: , [75440,75441]
operator: , [77064,77065]
===
match
---
name: is_subdag [53437,53446]
name: is_subdag [53468,53477]
===
match
---
name: sync_to_db [36165,36175]
name: sync_to_db [36196,36206]
===
match
---
name: dag_id [44440,44446]
name: dag_id [44471,44477]
===
match
---
name: op2 [41137,41140]
name: op2 [41168,41171]
===
match
---
operator: - [3694,3695]
operator: - [3725,3726]
===
match
---
name: DagModel [68921,68929]
name: DagModel [70545,70553]
===
match
---
name: owner [32186,32191]
name: owner [32217,32222]
===
match
---
assert_stmt [77203,77252]
assert_stmt [78827,78876]
===
match
---
operator: = [42814,42815]
operator: = [42845,42846]
===
match
---
trailer [18970,18993]
trailer [19001,19024]
===
match
---
simple_stmt [788,804]
simple_stmt [788,804]
===
match
---
operator: { [13767,13768]
operator: { [13798,13799]
===
match
---
name: pendulum [38335,38343]
name: pendulum [38366,38374]
===
match
---
name: dagrun_1 [56564,56572]
name: dagrun_1 [56595,56603]
===
match
---
name: pickle [846,852]
name: pickle [846,852]
===
match
---
atom_expr [56854,56880]
atom_expr [56885,56911]
===
match
---
expr_stmt [73627,73825]
expr_stmt [75251,75449]
===
match
---
trailer [63943,63961]
trailer [65567,65585]
===
match
---
atom [28412,28498]
atom [28443,28529]
===
match
---
trailer [32760,32766]
trailer [32791,32797]
===
match
---
operator: -> [69984,69986]
operator: -> [71608,71610]
===
match
---
name: PRE_TRANSITION [22300,22314]
name: PRE_TRANSITION [22331,22345]
===
match
---
operator: , [71711,71712]
operator: , [73335,73336]
===
match
---
funcdef [38667,39141]
funcdef [38698,39172]
===
match
---
trailer [53022,53032]
trailer [53053,53063]
===
match
---
name: session [76760,76767]
name: session [78384,78391]
===
match
---
name: prev [23099,23103]
name: prev [23130,23134]
===
match
---
arglist [18438,18471]
arglist [18469,18502]
===
match
---
name: query [30694,30699]
name: query [30725,30730]
===
match
---
trailer [11399,11465]
trailer [11430,11496]
===
match
---
name: dst_rule [22282,22290]
name: dst_rule [22313,22321]
===
match
---
trailer [23837,23845]
trailer [23868,23876]
===
match
---
name: dag [65590,65593]
name: dag [67214,67217]
===
match
---
trailer [53762,53952]
trailer [53793,53983]
===
match
---
expr_stmt [38568,38611]
expr_stmt [38599,38642]
===
match
---
funcdef [40253,40762]
funcdef [40284,40793]
===
match
---
name: dagrun [54975,54981]
name: dagrun [55006,55012]
===
match
---
name: datetime [62826,62834]
name: datetime [62857,62865]
===
match
---
name: fileloc [37595,37602]
name: fileloc [37626,37633]
===
match
---
operator: = [69385,69386]
operator: = [71009,71010]
===
match
---
simple_stmt [79057,79097]
simple_stmt [80681,80721]
===
match
---
string: """         Tests following_schedule a dag with a relativedelta schedule_interval         """ [25368,25461]
string: """         Tests following_schedule a dag with a relativedelta schedule_interval         """ [25399,25492]
===
match
---
argument [70264,70287]
argument [71888,71911]
===
match
---
name: expected_relative [69906,69923]
name: expected_relative [71530,71547]
===
match
---
arglist [35480,35521]
arglist [35511,35552]
===
match
---
name: tags [30042,30046]
name: tags [30073,30077]
===
match
---
name: dr1 [18298,18301]
name: dr1 [18329,18332]
===
match
---
operator: , [12803,12804]
operator: , [12834,12835]
===
match
---
operator: = [39746,39747]
operator: = [39777,39778]
===
match
---
simple_stmt [67394,67451]
simple_stmt [69018,69075]
===
match
---
string: '_neq' [48074,48080]
string: '_neq' [48105,48111]
===
match
---
operator: = [50929,50930]
operator: = [50960,50961]
===
match
---
name: dag [4103,4106]
name: dag [4134,4137]
===
match
---
simple_stmt [26631,26668]
simple_stmt [26662,26699]
===
match
---
trailer [51380,51487]
trailer [51411,51518]
===
match
---
operator: , [36031,36032]
operator: , [36062,36063]
===
match
---
name: test_create_dagrun_job_id_is_set [51229,51261]
name: test_create_dagrun_job_id_is_set [51260,51292]
===
match
---
operator: = [65346,65347]
operator: = [66970,66971]
===
match
---
name: filters [20054,20061]
name: filters [20085,20092]
===
match
---
operator: , [54716,54717]
operator: , [54747,54748]
===
match
---
trailer [54833,54839]
trailer [54864,54870]
===
match
---
operator: = [68035,68036]
operator: = [69659,69660]
===
match
---
funcdef [40767,41255]
funcdef [40798,41286]
===
match
---
trailer [33041,33047]
trailer [33072,33078]
===
match
---
atom_expr [9740,9761]
atom_expr [9771,9792]
===
match
---
atom_expr [71697,71717]
atom_expr [73321,73341]
===
match
---
trailer [53293,53333]
trailer [53324,53364]
===
match
---
trailer [35036,35043]
trailer [35067,35074]
===
match
---
trailer [18378,18385]
trailer [18409,18416]
===
match
---
atom_expr [59655,59755]
atom_expr [59686,59786]
===
match
---
trailer [39330,39344]
trailer [39361,39375]
===
match
---
name: DagRunType [44995,45005]
name: DagRunType [45026,45036]
===
match
---
operator: = [70359,70360]
operator: = [71983,71984]
===
match
---
trailer [68564,68573]
trailer [70188,70197]
===
match
---
trailer [5187,5194]
trailer [5218,5225]
===
match
---
trailer [42201,42211]
trailer [42232,42242]
===
match
---
assert_stmt [77343,77395]
assert_stmt [78967,79019]
===
match
---
simple_stmt [37067,37084]
simple_stmt [37098,37115]
===
match
---
comparison [60653,60678]
comparison [60684,60709]
===
match
---
comparison [49784,49809]
comparison [49815,49840]
===
match
---
name: self [45597,45601]
name: self [45628,45632]
===
match
---
param [70035,70039]
param [71659,71663]
===
match
---
operator: , [17775,17776]
operator: , [17806,17807]
===
match
---
testlist_comp [21198,21211]
testlist_comp [21229,21242]
===
match
---
atom_expr [10474,10500]
atom_expr [10505,10531]
===
match
---
comparison [4824,4873]
comparison [4855,4904]
===
match
---
trailer [17690,17726]
trailer [17721,17757]
===
match
---
name: dag [51810,51813]
name: dag [51841,51844]
===
match
---
trailer [9966,9969]
trailer [9997,10000]
===
match
---
name: fileloc [71325,71332]
name: fileloc [72949,72956]
===
match
---
operator: , [27768,27769]
operator: , [27799,27800]
===
match
---
simple_stmt [7701,7738]
simple_stmt [7732,7769]
===
match
---
with_stmt [28202,28271]
with_stmt [28233,28302]
===
match
---
name: get [31327,31330]
name: get [31358,31361]
===
match
---
trailer [33204,33214]
trailer [33235,33245]
===
match
---
arglist [63994,64141]
arglist [65618,65765]
===
match
---
expr_stmt [51097,51171]
expr_stmt [51128,51202]
===
match
---
name: test_resolve_template_files_list [21357,21389]
name: test_resolve_template_files_list [21388,21420]
===
match
---
comparison [25886,25934]
comparison [25917,25965]
===
match
---
atom_expr [50759,50769]
atom_expr [50790,50800]
===
match
---
operator: } [66331,66332]
operator: } [67955,67956]
===
match
---
argument [31602,31631]
argument [31633,31662]
===
match
---
operator: = [60993,60994]
operator: = [61024,61025]
===
match
---
argument [36528,36556]
argument [36559,36587]
===
match
---
name: dag [49141,49144]
name: dag [49172,49175]
===
match
---
atom_expr [16445,16464]
atom_expr [16476,16495]
===
match
---
name: start_date [23494,23504]
name: start_date [23525,23535]
===
match
---
atom_expr [51886,51925]
atom_expr [51917,51956]
===
match
---
operator: = [71131,71132]
operator: = [72755,72756]
===
match
---
trailer [74825,74838]
trailer [76449,76462]
===
match
---
comparison [37137,37178]
comparison [37168,37209]
===
match
---
operator: = [78947,78948]
operator: = [80571,80572]
===
match
---
comparison [51187,51219]
comparison [51218,51250]
===
match
---
atom [58008,58018]
atom [58039,58049]
===
match
---
operator: = [39315,39316]
operator: = [39346,39347]
===
match
---
name: timedelta [78179,78188]
name: timedelta [79803,79812]
===
match
---
string: """         Make sure DST transitions are properly observed         """ [23190,23261]
string: """         Make sure DST transitions are properly observed         """ [23221,23292]
===
match
---
simple_stmt [20546,20605]
simple_stmt [20577,20636]
===
match
---
with_item [46324,46351]
with_item [46355,46382]
===
match
---
name: utc [26145,26148]
name: utc [26176,26179]
===
match
---
string: "2018-10-28T02:50:00+02:00" [22897,22924]
string: "2018-10-28T02:50:00+02:00" [22928,22955]
===
match
---
name: value [74400,74405]
name: value [76024,76029]
===
match
---
name: close [19619,19624]
name: close [19650,19655]
===
match
---
atom_expr [31126,31182]
atom_expr [31157,31213]
===
match
---
name: next_dagrun_info [62587,62603]
name: next_dagrun_info [62618,62634]
===
match
---
with_item [28284,28311]
with_item [28315,28342]
===
match
---
param [58967,58974]
param [58998,59005]
===
match
---
atom_expr [46129,46149]
atom_expr [46160,46180]
===
match
---
atom_expr [62024,62053]
atom_expr [62055,62084]
===
match
---
operator: , [29693,29694]
operator: , [29724,29725]
===
match
---
arglist [65303,65411]
arglist [66927,67035]
===
match
---
string: 'D' [10586,10589]
string: 'D' [10617,10620]
===
match
---
name: state [43220,43225]
name: state [43251,43256]
===
match
---
name: provide_session [2181,2196]
name: provide_session [2212,2227]
===
match
---
name: set [32742,32745]
name: set [32773,32776]
===
match
---
atom_expr [52227,52284]
atom_expr [52258,52315]
===
match
---
trailer [58191,58200]
trailer [58222,58231]
===
match
---
atom_expr [10788,10811]
atom_expr [10819,10842]
===
match
---
parameters [3565,3578]
parameters [3596,3609]
===
match
---
name: execution_date [17793,17807]
name: execution_date [17824,17838]
===
match
---
trailer [75391,75397]
trailer [77015,77021]
===
match
---
trailer [69265,69269]
trailer [70889,70893]
===
match
---
simple_stmt [29502,29977]
simple_stmt [29533,30008]
===
match
---
name: is_paused [35013,35022]
name: is_paused [35044,35053]
===
match
---
name: os [21590,21592]
name: os [21621,21623]
===
match
---
operator: { [66251,66252]
operator: { [67875,67876]
===
match
---
name: test_dag_id [19359,19370]
name: test_dag_id [19390,19401]
===
match
---
suite [3943,4213]
suite [3974,4244]
===
match
---
expr_stmt [59149,59365]
expr_stmt [59180,59396]
===
match
---
atom_expr [55940,55953]
atom_expr [55971,55984]
===
match
---
name: make_dag [60788,60796]
name: make_dag [60819,60827]
===
match
---
expr_stmt [41957,41990]
expr_stmt [41988,42021]
===
match
---
simple_stmt [42617,42707]
simple_stmt [42648,42738]
===
match
---
operator: , [63244,63245]
operator: , [63275,63276]
===
match
---
name: dag_run_state [55200,55213]
name: dag_run_state [55231,55244]
===
match
---
simple_stmt [24571,24640]
simple_stmt [24602,24671]
===
match
---
name: execution_date [53885,53899]
name: execution_date [53916,53930]
===
match
---
atom_expr [62583,62609]
atom_expr [62614,62640]
===
match
---
trailer [6011,6018]
trailer [6042,6049]
===
match
---
trailer [30354,30356]
trailer [30385,30387]
===
match
---
atom [39562,39572]
atom [39593,39603]
===
match
---
trailer [33123,33154]
trailer [33154,33185]
===
match
---
argument [60347,60382]
argument [60378,60413]
===
match
---
name: query [37796,37801]
name: query [37827,37832]
===
match
---
name: task_id [33637,33644]
name: task_id [33668,33675]
===
match
---
trailer [28976,28979]
trailer [29007,29010]
===
match
---
name: dag_models [69447,69457]
name: dag_models [71071,71081]
===
match
---
name: raises [6012,6018]
name: raises [6043,6049]
===
match
---
name: i [16352,16353]
name: i [16383,16384]
===
match
---
name: isinstance [4148,4158]
name: isinstance [4179,4189]
===
match
---
name: task_id [51908,51915]
name: task_id [51939,51946]
===
match
---
atom_expr [9699,9727]
atom_expr [9730,9758]
===
match
---
operator: = [58241,58242]
operator: = [58272,58273]
===
match
---
name: external_trigger [43253,43269]
name: external_trigger [43284,43300]
===
match
---
atom_expr [51610,51623]
atom_expr [51641,51654]
===
match
---
param [4930,4934]
param [4961,4965]
===
match
---
parameters [42437,42443]
parameters [42468,42474]
===
match
---
expr_stmt [60098,60140]
expr_stmt [60129,60171]
===
match
---
argument [7330,7343]
argument [7361,7374]
===
match
---
operator: != [55910,55912]
operator: != [55941,55943]
===
match
---
name: cron_timetable [49997,50011]
name: cron_timetable [50028,50042]
===
match
---
for_stmt [48261,48383]
for_stmt [48292,48414]
===
match
---
name: DagRunType [46129,46139]
name: DagRunType [46160,46170]
===
match
---
name: test_following_schedule_datetime_timezone [26341,26382]
name: test_following_schedule_datetime_timezone [26372,26413]
===
match
---
trailer [3294,3301]
trailer [3325,3332]
===
match
---
name: default_args [47947,47959]
name: default_args [47978,47990]
===
match
---
arglist [51900,51924]
arglist [51931,51955]
===
match
---
trailer [42193,42241]
trailer [42224,42272]
===
match
---
simple_stmt [10980,11013]
simple_stmt [11011,11044]
===
match
---
string: 'dummy' [67416,67423]
string: 'dummy' [69040,69047]
===
match
---
name: dag [44282,44285]
name: dag [44313,44316]
===
match
---
expr_stmt [46920,47150]
expr_stmt [46951,47181]
===
match
---
name: test_dag_id [48214,48225]
name: test_dag_id [48245,48256]
===
match
---
parameters [41829,41835]
parameters [41860,41866]
===
match
---
atom_expr [73718,73735]
atom_expr [75342,75359]
===
match
---
operator: , [52046,52047]
operator: , [52077,52078]
===
match
---
argument [46177,46196]
argument [46208,46227]
===
match
---
operator: , [57425,57426]
operator: , [57456,57457]
===
match
---
trailer [18238,18246]
trailer [18269,18277]
===
match
---
parameters [64405,64411]
parameters [66029,66035]
===
match
---
trailer [31782,31797]
trailer [31813,31828]
===
match
---
operator: == [3480,3482]
operator: == [3511,3513]
===
match
---
name: RUNNING [55946,55953]
name: RUNNING [55977,55984]
===
match
---
trailer [29090,29096]
trailer [29121,29127]
===
match
---
assert_stmt [29316,29489]
assert_stmt [29347,29520]
===
match
---
trailer [58200,58255]
trailer [58231,58286]
===
match
---
trailer [18900,18946]
trailer [18931,18977]
===
match
---
name: row [30313,30316]
name: row [30344,30347]
===
match
---
comparison [26683,26730]
comparison [26714,26761]
===
match
---
trailer [40931,41009]
trailer [40962,41040]
===
match
---
param [9300,9304]
param [9331,9335]
===
match
---
name: dagrun [55783,55789]
name: dagrun [55814,55820]
===
match
---
name: airflow [1305,1312]
name: airflow [1311,1318]
===
match
---
name: catchup [59300,59307]
name: catchup [59331,59338]
===
match
---
atom_expr [5796,5845]
atom_expr [5827,5876]
===
match
---
atom_expr [34541,34588]
atom_expr [34572,34619]
===
match
---
name: RUNNING [19408,19415]
name: RUNNING [19439,19446]
===
match
---
expr_stmt [62571,62609]
expr_stmt [62602,62640]
===
match
---
name: dag_id [28758,28764]
name: dag_id [28789,28795]
===
match
---
name: timezone [73718,73726]
name: timezone [75342,75350]
===
match
---
name: op7 [7959,7962]
name: op7 [7990,7993]
===
match
---
name: DAG [5741,5744]
name: DAG [5772,5775]
===
match
---
name: unittest [870,878]
name: unittest [870,878]
===
match
---
trailer [11008,11011]
trailer [11039,11042]
===
match
---
string: 'dag-bulk-sync-3' [30262,30279]
string: 'dag-bulk-sync-3' [30293,30310]
===
match
---
name: dag [71708,71711]
name: dag [73332,73335]
===
match
---
name: task_instances [57176,57190]
name: task_instances [57207,57221]
===
match
---
argument [31060,31083]
argument [31091,31114]
===
match
---
trailer [72546,72549]
trailer [74170,74173]
===
match
---
name: dag [36495,36498]
name: dag [36526,36529]
===
match
---
name: default_args [38378,38390]
name: default_args [38409,38421]
===
match
---
operator: = [42724,42725]
operator: = [42755,42756]
===
match
---
atom_expr [64320,64357]
atom_expr [65944,65981]
===
match
---
argument [13629,13652]
argument [13660,13683]
===
match
---
simple_stmt [63766,63823]
simple_stmt [65390,65447]
===
match
---
name: following_schedule [26642,26660]
name: following_schedule [26673,26691]
===
match
---
atom_expr [31710,31737]
atom_expr [31741,31768]
===
match
---
simple_stmt [31229,31241]
simple_stmt [31260,31272]
===
match
---
trailer [37973,38015]
trailer [38004,38046]
===
match
---
name: op1 [10181,10184]
name: op1 [10212,10215]
===
match
---
name: DEFAULT_DATE [31834,31846]
name: DEFAULT_DATE [31865,31877]
===
match
---
atom_expr [55234,55252]
atom_expr [55265,55283]
===
match
---
operator: = [65114,65115]
operator: = [66738,66739]
===
match
---
operator: = [4668,4669]
operator: = [4699,4700]
===
match
---
atom_expr [45252,45262]
atom_expr [45283,45293]
===
match
---
operator: , [18027,18028]
operator: , [18058,18059]
===
match
---
atom_expr [50165,50192]
atom_expr [50196,50223]
===
match
---
simple_stmt [12934,12975]
simple_stmt [12965,13006]
===
match
---
name: dag [41175,41178]
name: dag [41206,41209]
===
match
---
dotted_name [77629,77652]
dotted_name [79253,79276]
===
match
---
name: session [55315,55322]
name: session [55346,55353]
===
match
---
trailer [44408,44414]
trailer [44439,44445]
===
match
---
decorator [72946,72962]
decorator [74570,74586]
===
match
---
atom_expr [51983,52167]
atom_expr [52014,52198]
===
match
---
name: dumps [48792,48797]
name: dumps [48823,48828]
===
match
---
name: all [58627,58630]
name: all [58658,58661]
===
match
---
string: 'parameter2' [4638,4650]
string: 'parameter2' [4669,4681]
===
match
---
fstring [13760,13775]
fstring [13791,13806]
===
match
---
operator: , [61632,61633]
operator: , [61663,61664]
===
match
---
trailer [58483,58490]
trailer [58514,58521]
===
match
---
number: 2 [63953,63954]
number: 2 [65577,65578]
===
match
---
name: days [18094,18098]
name: days [18125,18129]
===
match
---
atom_expr [28462,28477]
atom_expr [28493,28508]
===
match
---
trailer [22299,22314]
trailer [22330,22345]
===
match
---
arglist [50997,51035]
arglist [51028,51066]
===
match
---
name: next_info [62737,62746]
name: next_info [62768,62777]
===
match
---
trailer [73848,73852]
trailer [75472,75476]
===
match
---
name: start_date [67655,67665]
name: start_date [69279,69289]
===
match
---
operator: , [54069,54070]
operator: , [54100,54101]
===
match
---
argument [42838,42857]
argument [42869,42888]
===
match
---
operator: , [63685,63686]
operator: , [65309,65310]
===
match
---
atom [28634,28665]
atom [28665,28696]
===
match
---
atom [19517,19531]
atom [19548,19562]
===
match
---
expr_stmt [24525,24561]
expr_stmt [24556,24592]
===
match
---
string: 'test-dag2' [30528,30539]
string: 'test-dag2' [30559,30570]
===
match
---
trailer [26288,26298]
trailer [26319,26329]
===
match
---
operator: = [41506,41507]
operator: = [41537,41538]
===
match
---
operator: , [49918,49919]
operator: , [49949,49950]
===
match
---
operator: = [32525,32526]
operator: = [32556,32557]
===
match
---
string: b'{{ ds }}' [20832,20843]
string: b'{{ ds }}' [20863,20874]
===
match
---
operator: , [9018,9019]
operator: , [9049,9050]
===
match
---
name: test_dag_id [17508,17519]
name: test_dag_id [17539,17550]
===
match
---
dotted_name [55038,55058]
dotted_name [55069,55089]
===
match
---
string: 'dag-bulk-sync-2' [29362,29379]
string: 'dag-bulk-sync-2' [29393,29410]
===
match
---
name: dag [33406,33409]
name: dag [33437,33440]
===
match
---
operator: , [58111,58112]
operator: , [58142,58143]
===
match
---
operator: = [51470,51471]
operator: = [51501,51502]
===
match
---
atom_expr [54129,54159]
atom_expr [54160,54190]
===
match
---
expr_stmt [9654,9686]
expr_stmt [9685,9717]
===
match
---
dictorsetmaker [35595,35642]
dictorsetmaker [35626,35673]
===
match
---
expr_stmt [25093,25128]
expr_stmt [25124,25159]
===
match
---
assert_stmt [48923,48949]
assert_stmt [48954,48980]
===
match
---
name: operator [73576,73584]
name: operator [75200,75208]
===
match
---
trailer [61791,61803]
trailer [61822,61834]
===
match
---
name: local_tz [23829,23837]
name: local_tz [23860,23868]
===
match
---
operator: = [74520,74521]
operator: = [76144,76145]
===
match
---
atom_expr [62868,62913]
atom_expr [62899,62944]
===
match
---
name: logging [10871,10878]
name: logging [10902,10909]
===
match
---
simple_stmt [5319,5393]
simple_stmt [5350,5424]
===
match
---
operator: >> [8794,8796]
operator: >> [8825,8827]
===
match
---
operator: , [77014,77015]
operator: , [78638,78639]
===
match
---
name: start [23458,23463]
name: start [23489,23494]
===
match
---
trailer [31858,31866]
trailer [31889,31897]
===
match
---
name: second [59722,59728]
name: second [59753,59759]
===
match
---
trailer [28461,28478]
trailer [28492,28509]
===
match
---
number: 2 [10089,10090]
number: 2 [10120,10121]
===
match
---
trailer [34441,34509]
trailer [34472,34540]
===
match
---
assert_stmt [42998,43025]
assert_stmt [43029,43056]
===
match
---
name: merge [54137,54142]
name: merge [54168,54173]
===
match
---
atom_expr [15462,15477]
atom_expr [15493,15508]
===
match
---
name: DAG [48056,48059]
name: DAG [48087,48090]
===
match
---
arith_expr [48214,48231]
arith_expr [48245,48262]
===
match
---
name: following_schedule [24881,24899]
name: following_schedule [24912,24930]
===
match
---
arglist [38773,38808]
arglist [38804,38839]
===
match
---
operator: { [64951,64952]
operator: { [66575,66576]
===
match
---
name: run [74778,74781]
name: run [76402,76405]
===
match
---
name: roots [39120,39125]
name: roots [39151,39156]
===
match
---
expr_stmt [11390,11465]
expr_stmt [11421,11496]
===
match
---
simple_stmt [6501,6687]
simple_stmt [6532,6718]
===
match
---
name: session [2680,2687]
name: session [2711,2718]
===
match
---
name: DummyOperator [39833,39846]
name: DummyOperator [39864,39877]
===
match
---
atom_expr [43155,43177]
atom_expr [43186,43208]
===
match
---
suite [32143,32568]
suite [32174,32599]
===
match
---
with_stmt [9497,9762]
with_stmt [9528,9793]
===
match
---
suite [70325,70402]
suite [71949,72026]
===
match
---
operator: == [24178,24180]
operator: == [24209,24211]
===
match
---
atom_expr [68037,68122]
atom_expr [69661,69746]
===
match
---
comparison [42963,42989]
comparison [42994,43020]
===
match
---
atom_expr [10564,10590]
atom_expr [10595,10621]
===
match
---
name: topological_list [11214,11230]
name: topological_list [11245,11261]
===
match
---
string: "scheduled__" [51004,51017]
string: "scheduled__" [51035,51048]
===
match
---
simple_stmt [27407,27468]
simple_stmt [27438,27499]
===
match
---
name: test_utils [2493,2503]
name: test_utils [2524,2534]
===
match
---
trailer [56117,56127]
trailer [56148,56158]
===
match
---
name: operator [74444,74452]
name: operator [76068,76076]
===
match
---
param [24273,24277]
param [24304,24308]
===
match
---
assert_stmt [35155,35256]
assert_stmt [35186,35287]
===
match
---
name: self [71089,71093]
name: self [72713,72717]
===
match
---
trailer [24006,24024]
trailer [24037,24055]
===
match
---
funcdef [58954,59586]
funcdef [58985,59617]
===
match
---
name: tasks [10095,10100]
name: tasks [10126,10131]
===
match
---
simple_stmt [44955,45136]
simple_stmt [44986,45167]
===
match
---
simple_stmt [36186,36217]
simple_stmt [36217,36248]
===
match
---
atom_expr [15627,15639]
atom_expr [15658,15670]
===
match
---
operator: = [73630,73631]
operator: = [75254,75255]
===
match
---
name: dagrun [52855,52861]
name: dagrun [52886,52892]
===
match
---
operator: , [29792,29793]
operator: , [29823,29824]
===
match
---
atom_expr [75813,75844]
atom_expr [77437,77468]
===
match
---
operator: , [50193,50194]
operator: , [50224,50225]
===
match
---
name: last_loaded [48353,48364]
name: last_loaded [48384,48395]
===
match
---
parameters [70930,70936]
parameters [72554,72560]
===
match
---
name: dag [37737,37740]
name: dag [37768,37771]
===
match
---
name: MANUAL [51213,51219]
name: MANUAL [51244,51250]
===
match
---
operator: = [46182,46183]
operator: = [46213,46214]
===
match
---
operator: , [45056,45057]
operator: , [45087,45088]
===
match
---
name: DAG [51303,51306]
name: DAG [51334,51337]
===
match
---
atom_expr [49712,49728]
atom_expr [49743,49759]
===
match
---
arglist [13140,13180]
arglist [13171,13211]
===
match
---
operator: , [63638,63639]
operator: , [65262,65263]
===
match
---
arglist [59712,59745]
arglist [59743,59776]
===
match
---
dictorsetmaker [11593,11619]
dictorsetmaker [11624,11650]
===
match
---
operator: = [53301,53302]
operator: = [53332,53333]
===
match
---
name: start_date [57392,57402]
name: start_date [57423,57433]
===
match
---
operator: , [27440,27441]
operator: , [27471,27472]
===
match
---
trailer [42247,42256]
trailer [42278,42287]
===
match
---
simple_stmt [55315,55331]
simple_stmt [55346,55362]
===
match
---
operator: , [26176,26177]
operator: , [26207,26208]
===
match
---
simple_stmt [25028,25084]
simple_stmt [25059,25115]
===
match
---
atom_expr [21607,21613]
atom_expr [21638,21644]
===
match
---
name: xcom_arg [75241,75249]
name: xcom_arg [76865,76873]
===
match
---
trailer [33877,33888]
trailer [33908,33919]
===
match
---
name: query [31311,31316]
name: query [31342,31347]
===
match
---
testlist_comp [21246,21258]
testlist_comp [21277,21289]
===
match
---
operator: = [71209,71210]
operator: = [72833,72834]
===
match
---
atom_expr [21590,21614]
atom_expr [21621,21645]
===
match
---
name: query [29447,29452]
name: query [29478,29483]
===
match
---
operator: = [11591,11592]
operator: = [11622,11623]
===
match
---
name: dag [33530,33533]
name: dag [33561,33564]
===
match
---
name: datetime [22251,22259]
name: datetime [22282,22290]
===
match
---
atom_expr [70452,70613]
atom_expr [72076,72237]
===
match
---
operator: = [39407,39408]
operator: = [39438,39439]
===
match
---
operator: , [66068,66069]
operator: , [67692,67693]
===
match
---
name: DAG [5233,5236]
name: DAG [5264,5267]
===
match
---
parameters [50609,50615]
parameters [50640,50646]
===
match
---
simple_stmt [73182,73198]
simple_stmt [74806,74822]
===
match
---
simple_stmt [57479,57518]
simple_stmt [57510,57549]
===
match
---
number: 2020 [62042,62046]
number: 2020 [62073,62077]
===
match
---
operator: >> [39559,39561]
operator: >> [39590,39592]
===
match
---
decorator [54232,54338]
decorator [54263,54369]
===
match
---
name: self [24273,24277]
name: self [24304,24308]
===
match
---
name: dag_fileloc [37920,37931]
name: dag_fileloc [37951,37962]
===
match
---
operator: >> [41196,41198]
operator: >> [41227,41229]
===
match
---
name: next_info [63106,63115]
name: next_info [63137,63146]
===
match
---
arglist [23349,23417]
arglist [23380,23448]
===
match
---
name: start_date [75562,75572]
name: start_date [77186,77196]
===
match
---
decorated [2660,2778]
decorated [2691,2809]
===
match
---
name: pipeline [16644,16652]
name: pipeline [16675,16683]
===
match
---
name: minutes [70834,70841]
name: minutes [72458,72465]
===
match
---
dotted_name [1073,1086]
dotted_name [1079,1092]
===
match
---
trailer [29941,29969]
trailer [29972,30000]
===
match
---
string: '2019-06-05' [11750,11762]
string: '2019-06-05' [11781,11793]
===
match
---
param [54391,54404]
param [54422,54435]
===
match
---
atom_expr [71733,71743]
atom_expr [73357,73367]
===
match
---
name: match [14226,14231]
name: match [14257,14262]
===
match
---
name: timedelta [17939,17948]
name: timedelta [17970,17979]
===
match
---
expr_stmt [10558,10590]
expr_stmt [10589,10621]
===
match
---
name: isoformat [25200,25209]
name: isoformat [25231,25240]
===
match
---
name: dst [27261,27264]
name: dst [27292,27295]
===
match
---
simple_stmt [52358,52622]
simple_stmt [52389,52653]
===
match
---
name: dag_id [46731,46737]
name: dag_id [46762,46768]
===
match
---
assert_stmt [4141,4176]
assert_stmt [4172,4207]
===
match
---
name: dag_run_state [52496,52509]
name: dag_run_state [52527,52540]
===
match
---
comparison [40726,40761]
comparison [40757,40792]
===
match
---
argument [75673,75688]
argument [77297,77312]
===
match
---
trailer [62952,62965]
trailer [62983,62996]
===
match
---
trailer [28482,28484]
trailer [28513,28515]
===
match
---
atom_expr [25100,25128]
atom_expr [25131,25159]
===
match
---
name: DummyOperator [75862,75875]
name: DummyOperator [77486,77499]
===
match
---
trailer [18809,18853]
trailer [18840,18884]
===
match
---
trailer [68458,68462]
trailer [70082,70086]
===
match
---
name: session [49732,49739]
name: session [49763,49770]
===
match
---
atom_expr [60325,60511]
atom_expr [60356,60542]
===
match
---
name: return_num [73521,73531]
name: return_num [75145,75155]
===
match
---
name: next_info [61998,62007]
name: next_info [62029,62038]
===
match
---
trailer [38941,38955]
trailer [38972,38986]
===
match
---
atom [21245,21259]
atom [21276,21290]
===
match
---
expr_stmt [27551,27587]
expr_stmt [27582,27618]
===
match
---
string: 'dag-bulk-sync-0' [29324,29341]
string: 'dag-bulk-sync-0' [29355,29372]
===
match
---
atom_expr [37275,37324]
atom_expr [37306,37355]
===
match
---
trailer [35939,35943]
trailer [35970,35974]
===
match
---
atom_expr [18461,18471]
atom_expr [18492,18502]
===
match
---
atom_expr [55013,55031]
atom_expr [55044,55062]
===
match
---
simple_stmt [54168,54199]
simple_stmt [54199,54230]
===
match
---
name: session [54767,54774]
name: session [54798,54805]
===
match
---
trailer [4158,4176]
trailer [4189,4207]
===
match
---
atom_expr [16791,16806]
atom_expr [16822,16837]
===
match
---
name: dag_id [31788,31794]
name: dag_id [31819,31825]
===
match
---
name: start [26587,26592]
name: start [26618,26623]
===
match
---
string: "test_dag" [41854,41864]
string: "test_dag" [41885,41895]
===
match
---
name: one [32721,32724]
name: one [32752,32755]
===
match
---
trailer [6338,6373]
trailer [6369,6404]
===
match
---
operator: { [4706,4707]
operator: { [4737,4738]
===
match
---
string: 'dag-bulk-sync-0' [29577,29594]
string: 'dag-bulk-sync-0' [29608,29625]
===
match
---
suite [16654,16869]
suite [16685,16900]
===
match
---
name: create_dagrun [46930,46943]
name: create_dagrun [46961,46974]
===
match
---
string: 'Also fake' [44907,44918]
string: 'Also fake' [44938,44949]
===
match
---
name: dag [7774,7777]
name: dag [7805,7808]
===
match
---
name: task_id [53049,53056]
name: task_id [53080,53087]
===
match
---
operator: = [17520,17521]
operator: = [17551,17552]
===
match
---
operator: , [11694,11695]
operator: , [11725,11726]
===
match
---
name: _next [23846,23851]
name: _next [23877,23882]
===
match
---
name: task_dict [41651,41660]
name: task_dict [41682,41691]
===
match
---
atom [14928,15276]
atom [14959,15307]
===
match
---
trailer [4794,4808]
trailer [4825,4839]
===
match
---
argument [73663,73693]
argument [75287,75317]
===
match
---
name: run [47302,47305]
name: run [47333,47336]
===
match
---
simple_stmt [37395,37423]
simple_stmt [37426,37454]
===
match
---
expr_stmt [18600,18628]
expr_stmt [18631,18659]
===
match
---
name: RUNNING [18413,18420]
name: RUNNING [18444,18451]
===
match
---
string: 'keep_trailing_newline' [20242,20265]
string: 'keep_trailing_newline' [20273,20296]
===
match
---
name: altered [77551,77558]
name: altered [79175,79182]
===
match
---
name: op5 [10924,10927]
name: op5 [10955,10958]
===
match
---
name: datetime [12787,12795]
name: datetime [12818,12826]
===
match
---
suite [42444,43321]
suite [42475,43352]
===
match
---
param [41830,41834]
param [41861,41865]
===
match
---
operator: } [39139,39140]
operator: } [39170,39171]
===
match
---
operator: , [69007,69008]
operator: , [70631,70632]
===
match
---
simple_stmt [15503,15540]
simple_stmt [15534,15571]
===
match
---
atom_expr [40232,40247]
atom_expr [40263,40278]
===
match
---
assert_stmt [7056,7078]
assert_stmt [7087,7109]
===
match
---
trailer [55297,55306]
trailer [55328,55337]
===
match
---
trailer [28455,28461]
trailer [28486,28492]
===
match
---
string: """         Tests avoid crashes from calling dag callbacks exceptions         """ [43427,43508]
string: """         Tests avoid crashes from calling dag callbacks exceptions         """ [43458,43539]
===
match
---
name: SubDagOperator [33605,33619]
name: SubDagOperator [33636,33650]
===
match
---
atom_expr [24812,24828]
atom_expr [24843,24859]
===
match
---
name: name [19733,19737]
name: name [19764,19768]
===
match
---
expr_stmt [44709,44761]
expr_stmt [44740,44792]
===
match
---
atom_expr [39593,39608]
atom_expr [39624,39639]
===
match
---
string: 'DAG' [11572,11577]
string: 'DAG' [11603,11608]
===
match
---
name: DAG [41850,41853]
name: DAG [41881,41884]
===
match
---
operator: { [59043,59044]
operator: { [59074,59075]
===
match
---
name: dag [71660,71663]
name: dag [73284,73287]
===
match
---
name: dag [14170,14173]
name: dag [14201,14204]
===
match
---
arglist [74782,74838]
arglist [76406,76462]
===
match
---
name: task_id [9629,9636]
name: task_id [9660,9667]
===
match
---
atom_expr [32918,32967]
atom_expr [32949,32998]
===
match
---
atom_expr [77536,77541]
atom_expr [79160,79165]
===
match
---
atom_expr [4824,4845]
atom_expr [4855,4876]
===
match
---
number: 2038 [68110,68114]
number: 2038 [69734,69738]
===
match
---
arglist [49472,49508]
arglist [49503,49539]
===
match
---
name: op3 [39933,39936]
name: op3 [39964,39967]
===
match
---
simple_stmt [64706,64879]
simple_stmt [66330,66503]
===
match
---
atom_expr [25258,25274]
atom_expr [25289,25305]
===
match
---
fstring_expr [15022,15025]
fstring_expr [15053,15056]
===
match
---
comparison [58719,58763]
comparison [58750,58794]
===
match
---
atom_expr [31202,31220]
atom_expr [31233,31251]
===
match
---
name: start_date [74597,74607]
name: start_date [76221,76231]
===
match
---
name: decorators [1389,1399]
name: decorators [1395,1405]
===
match
---
operator: } [32796,32797]
operator: } [32827,32828]
===
match
---
param [50390,50408]
param [50421,50439]
===
match
---
param [55194,55199]
param [55225,55230]
===
match
---
operator: = [53267,53268]
operator: = [53298,53299]
===
match
---
operator: = [12762,12763]
operator: = [12793,12794]
===
match
---
expr_stmt [12368,12499]
expr_stmt [12399,12530]
===
match
---
trailer [40514,40551]
trailer [40545,40582]
===
match
---
string: 'tag-1' [27882,27889]
string: 'tag-1' [27913,27920]
===
match
---
parameters [73389,73407]
parameters [75013,75031]
===
match
---
name: dag [41023,41026]
name: dag [41054,41057]
===
match
---
operator: , [17431,17432]
operator: , [17462,17463]
===
match
---
expr_stmt [20613,20647]
expr_stmt [20644,20678]
===
match
---
name: next_dagrun [69021,69032]
name: next_dagrun [70645,70656]
===
match
---
name: dag_subclass [48297,48309]
name: dag_subclass [48328,48340]
===
match
---
comp_op [31690,31696]
comp_op [31721,31727]
===
match
---
operator: == [7729,7731]
operator: == [7760,7762]
===
match
---
trailer [76044,76051]
trailer [77668,77675]
===
match
---
atom [19112,19126]
atom [19143,19157]
===
match
---
atom [29527,29558]
atom [29558,29589]
===
match
---
trailer [37279,37283]
trailer [37310,37314]
===
match
---
operator: = [53602,53603]
operator: = [53633,53634]
===
match
---
name: dag [48553,48556]
name: dag [48584,48587]
===
match
---
atom_expr [46974,46996]
atom_expr [47005,47027]
===
match
---
operator: , [21918,21919]
operator: , [21949,21950]
===
match
---
name: file [2100,2104]
name: file [2131,2135]
===
match
---
operator: } [19737,19738]
operator: } [19768,19769]
===
match
---
trailer [47095,47103]
trailer [47126,47134]
===
match
---
operator: = [51814,51815]
operator: = [51845,51846]
===
match
---
operator: != [49358,49360]
operator: != [49389,49391]
===
match
---
argument [17765,17775]
argument [17796,17806]
===
match
---
expr_stmt [9609,9641]
expr_stmt [9640,9672]
===
match
---
name: start_date [74782,74792]
name: start_date [76406,76416]
===
match
---
assert_stmt [7223,7251]
assert_stmt [7254,7282]
===
match
---
atom [70678,70851]
atom [72302,72475]
===
match
---
operator: = [54001,54002]
operator: = [54032,54033]
===
match
---
name: task_states [55889,55900]
name: task_states [55920,55931]
===
match
---
operator: , [14836,14837]
operator: , [14867,14868]
===
match
---
string: 'dag_orientation' [6411,6428]
string: 'dag_orientation' [6442,6459]
===
match
---
name: run_id [17777,17783]
name: run_id [17808,17814]
===
match
---
atom_expr [21501,21510]
atom_expr [21532,21541]
===
match
---
trailer [22805,22810]
trailer [22836,22841]
===
match
---
suite [36120,36434]
suite [36151,36465]
===
match
---
expr_stmt [17597,17656]
expr_stmt [17628,17687]
===
match
---
name: data_interval [62747,62760]
name: data_interval [62778,62791]
===
match
---
operator: == [22737,22739]
operator: == [22768,22770]
===
match
---
decorator [34112,34129]
decorator [34143,34160]
===
match
---
name: State [53822,53827]
name: State [53853,53858]
===
match
---
funcdef [17151,17456]
funcdef [17182,17487]
===
match
---
atom_expr [65729,65764]
atom_expr [67353,67388]
===
match
---
operator: , [9232,9233]
operator: , [9263,9264]
===
match
---
name: DEFAULT_DATE [77971,77983]
name: DEFAULT_DATE [79595,79607]
===
match
---
string: '/tmp/foo.py' [69704,69717]
string: '/tmp/foo.py' [71328,71341]
===
match
---
string: "@once" [50208,50215]
string: "@once" [50239,50246]
===
match
---
name: mock [1063,1067]
name: mock [1069,1073]
===
match
---
simple_stmt [67961,67977]
simple_stmt [69585,69601]
===
match
---
operator: = [68853,68854]
operator: = [70477,70478]
===
match
---
assert_stmt [42340,42393]
assert_stmt [42371,42424]
===
match
---
operator: , [70128,70129]
operator: , [71752,71753]
===
match
---
number: 2 [11183,11184]
number: 2 [11214,11215]
===
match
---
name: op1 [39061,39064]
name: op1 [39092,39095]
===
match
---
simple_stmt [33021,33105]
simple_stmt [33052,33136]
===
match
---
trailer [37145,37152]
trailer [37176,37183]
===
match
---
trailer [61186,61198]
trailer [61217,61229]
===
match
---
atom_expr [56113,56135]
atom_expr [56144,56166]
===
match
---
trailer [20964,20969]
trailer [20995,21000]
===
match
---
name: return_num [73453,73463]
name: return_num [75077,75087]
===
match
---
trailer [25166,25172]
trailer [25197,25203]
===
match
---
name: dag_diff_name [48282,48295]
name: dag_diff_name [48313,48326]
===
match
---
name: session [28737,28744]
name: session [28768,28775]
===
match
---
operator: } [64782,64783]
operator: } [66406,66407]
===
match
---
atom_expr [39409,39436]
atom_expr [39440,39467]
===
match
---
name: DAG [38574,38577]
name: DAG [38605,38608]
===
match
---
operator: = [66249,66250]
operator: = [67873,67874]
===
match
---
atom_expr [76886,76895]
atom_expr [78510,78519]
===
match
---
number: 0 [65762,65763]
number: 0 [67386,67387]
===
match
---
simple_stmt [41137,41180]
simple_stmt [41168,41211]
===
match
---
simple_stmt [21225,21260]
simple_stmt [21256,21291]
===
match
---
name: pytest [2661,2667]
name: pytest [2692,2698]
===
match
---
argument [52092,52115]
argument [52123,52146]
===
match
---
name: test_field [21135,21145]
name: test_field [21166,21176]
===
match
---
argument [70352,70377]
argument [71976,72001]
===
match
---
operator: >> [41598,41600]
operator: >> [41629,41631]
===
match
---
name: dag [41171,41174]
name: dag [41202,41205]
===
match
---
suite [17329,17456]
suite [17360,17487]
===
match
---
operator: , [71288,71289]
operator: , [72912,72913]
===
match
---
argument [46807,46827]
argument [46838,46858]
===
match
---
name: dag [36161,36164]
name: dag [36192,36195]
===
match
---
operator: = [51361,51362]
operator: = [51392,51393]
===
match
---
with_stmt [2695,2778]
with_stmt [2726,2809]
===
match
---
name: DummyOperator [39455,39468]
name: DummyOperator [39486,39499]
===
match
---
comparison [41716,41769]
comparison [41747,41800]
===
match
---
name: mock_stats [43406,43416]
name: mock_stats [43437,43447]
===
match
---
string: "faketastic" [42651,42663]
string: "faketastic" [42682,42694]
===
match
---
name: dag_subclass_diff_name [48311,48333]
name: dag_subclass_diff_name [48342,48364]
===
match
---
trailer [68597,68599]
trailer [70221,70223]
===
match
---
simple_stmt [27874,28023]
simple_stmt [27905,28054]
===
match
---
trailer [21276,21299]
trailer [21307,21330]
===
match
---
name: dag_ [48265,48269]
name: dag_ [48296,48300]
===
match
---
string: 'hello' [20000,20007]
string: 'hello' [20031,20038]
===
match
---
operator: , [55856,55857]
operator: , [55887,55888]
===
match
---
operator: = [17807,17808]
operator: = [17838,17839]
===
match
---
simple_stmt [27103,27132]
simple_stmt [27134,27163]
===
match
---
operator: == [23104,23106]
operator: == [23135,23137]
===
match
---
testlist_comp [54278,54289]
testlist_comp [54309,54320]
===
match
---
simple_stmt [1268,1299]
simple_stmt [1274,1305]
===
match
---
simple_stmt [18862,18947]
simple_stmt [18893,18978]
===
match
---
name: add_task [45938,45946]
name: add_task [45969,45977]
===
match
---
name: State [55083,55088]
name: State [55114,55119]
===
match
---
arglist [40645,40681]
arglist [40676,40712]
===
match
---
trailer [45188,45190]
trailer [45219,45221]
===
match
---
name: test_dag_topological_sort_dag_without_tasks [11331,11374]
name: test_dag_topological_sort_dag_without_tasks [11362,11405]
===
match
---
simple_stmt [23996,24032]
simple_stmt [24027,24063]
===
match
---
comparison [49671,49697]
comparison [49702,49728]
===
match
---
parameters [11669,11675]
parameters [11700,11706]
===
match
---
name: State [77099,77104]
name: State [78723,78728]
===
match
---
atom_expr [30700,30725]
atom_expr [30731,30756]
===
match
---
trailer [12377,12499]
trailer [12408,12530]
===
match
---
name: timezone [60754,60762]
name: timezone [60785,60793]
===
match
---
string: "t3" [38950,38954]
string: "t3" [38981,38985]
===
match
---
trailer [4852,4859]
trailer [4883,4890]
===
match
---
trailer [73347,73360]
trailer [74971,74984]
===
match
---
name: TaskInstance [1568,1580]
name: TaskInstance [1574,1586]
===
match
---
name: DEFAULT_DATE [17808,17820]
name: DEFAULT_DATE [17839,17851]
===
match
---
parameters [70198,70217]
parameters [71822,71841]
===
match
---
argument [10443,10454]
argument [10474,10485]
===
match
---
trailer [20645,20647]
trailer [20676,20678]
===
match
---
trailer [42236,42240]
trailer [42267,42271]
===
match
---
string: "foo" [19916,19921]
string: "foo" [19947,19952]
===
match
---
operator: = [6042,6043]
operator: = [6073,6074]
===
match
---
trailer [33964,33971]
trailer [33995,34002]
===
match
---
name: dag_id [67540,67546]
name: dag_id [69164,69170]
===
match
---
operator: , [70893,70894]
operator: , [72517,72518]
===
match
---
operator: = [52575,52576]
operator: = [52606,52607]
===
match
---
simple_stmt [71613,71624]
simple_stmt [73237,73248]
===
match
---
trailer [16799,16806]
trailer [16830,16837]
===
match
---
name: task_decorator [74242,74256]
name: task_decorator [75866,75880]
===
match
---
operator: = [75680,75681]
operator: = [77304,77305]
===
match
---
trailer [39982,39984]
trailer [40013,40015]
===
match
---
operator: = [58395,58396]
operator: = [58426,58427]
===
match
---
operator: , [28616,28617]
operator: , [28647,28648]
===
match
---
trailer [34803,34810]
trailer [34834,34841]
===
match
---
name: subdag [32467,32473]
name: subdag [32498,32504]
===
match
---
name: DAG [50919,50922]
name: DAG [50950,50953]
===
match
---
simple_stmt [74848,74880]
simple_stmt [76472,76504]
===
match
---
parameters [72925,72932]
parameters [74549,74556]
===
match
---
atom_expr [75127,75137]
atom_expr [76751,76761]
===
match
---
operator: } [28123,28124]
operator: } [28154,28155]
===
match
---
name: stage [15418,15423]
name: stage [15449,15454]
===
match
---
argument [67560,67578]
argument [69184,69202]
===
match
---
assert_stmt [32806,32830]
assert_stmt [32837,32861]
===
match
---
expr_stmt [7310,7344]
expr_stmt [7341,7375]
===
match
---
trailer [19490,19602]
trailer [19521,19633]
===
match
---
atom_expr [32664,32726]
atom_expr [32695,32757]
===
match
---
string: """         Test that DagModel.next_dagrun_create_after is set to NULL when the dag cannot be created due to max         active runs being hit.         """ [30838,30993]
string: """         Test that DagModel.next_dagrun_create_after is set to NULL when the dag cannot be created due to max         active runs being hit.         """ [30869,31024]
===
match
---
name: prev [24649,24653]
name: prev [24680,24684]
===
match
---
name: test_schedule_dag_no_previous_runs [42403,42437]
name: test_schedule_dag_no_previous_runs [42434,42468]
===
match
---
name: dag_id [35489,35495]
name: dag_id [35520,35526]
===
match
---
atom [52641,52812]
atom [52672,52843]
===
match
---
operator: , [75591,75592]
operator: , [77215,77216]
===
match
---
trailer [61454,61670]
trailer [61485,61701]
===
match
---
name: start_date [47288,47298]
name: start_date [47319,47329]
===
match
---
name: isoformat [23720,23729]
name: isoformat [23751,23760]
===
match
---
operator: , [70844,70845]
operator: , [72468,72469]
===
match
---
simple_stmt [38568,38612]
simple_stmt [38599,38643]
===
match
---
simple_stmt [23428,23465]
simple_stmt [23459,23496]
===
match
---
string: 'dag-bulk-sync-0' [30205,30222]
string: 'dag-bulk-sync-0' [30236,30253]
===
match
---
operator: , [26115,26116]
operator: , [26146,26147]
===
match
---
argument [56185,56208]
argument [56216,56239]
===
match
---
trailer [60999,61016]
trailer [61030,61047]
===
match
---
operator: = [46963,46964]
operator: = [46994,46995]
===
match
---
string: 'op1' [6916,6921]
string: 'op1' [6947,6952]
===
match
---
number: 2 [26117,26118]
number: 2 [26148,26149]
===
match
---
operator: = [18442,18443]
operator: = [18473,18474]
===
match
---
simple_stmt [8328,8361]
simple_stmt [8359,8392]
===
match
---
name: set [35656,35659]
name: set [35687,35690]
===
match
---
operator: -> [70041,70043]
operator: -> [71665,71667]
===
match
---
operator: , [62991,62992]
operator: , [63022,63023]
===
match
---
param [64593,64609]
param [66217,66233]
===
match
---
operator: , [16583,16584]
operator: , [16614,16615]
===
match
---
name: schedule_interval [59218,59235]
name: schedule_interval [59249,59266]
===
match
---
trailer [25040,25050]
trailer [25071,25081]
===
match
---
operator: = [59526,59527]
operator: = [59557,59558]
===
match
---
suite [3228,3525]
suite [3259,3556]
===
match
---
name: DagRun [3255,3261]
name: DagRun [3286,3292]
===
match
---
trailer [39800,39814]
trailer [39831,39845]
===
match
---
operator: = [52465,52466]
operator: = [52496,52497]
===
match
---
name: settings [67470,67478]
name: settings [69094,69102]
===
match
---
name: State [18407,18412]
name: State [18438,18443]
===
match
---
name: a [3763,3764]
name: a [3794,3795]
===
match
---
name: RUNNING [54112,54119]
name: RUNNING [54143,54150]
===
match
---
operator: , [54682,54683]
operator: , [54713,54714]
===
match
---
string: "2018-03-24T02:00:00+00:00" [24832,24859]
string: "2018-03-24T02:00:00+00:00" [24863,24890]
===
match
---
with_stmt [73139,73198]
with_stmt [74763,74822]
===
match
---
name: weight [15072,15078]
name: weight [15103,15109]
===
match
---
atom [51568,51636]
atom [51599,51667]
===
match
---
atom_expr [3809,3818]
atom_expr [3840,3849]
===
match
---
atom_expr [52270,52283]
atom_expr [52301,52314]
===
match
---
name: next_info [63832,63841]
name: next_info [65456,65465]
===
match
---
comparison [19314,19443]
comparison [19345,19474]
===
match
---
atom [50207,50233]
atom [50238,50264]
===
match
---
name: interval [77754,77762]
name: interval [79378,79386]
===
match
---
trailer [46338,46340]
trailer [46369,46371]
===
match
---
return_stmt [73011,73021]
return_stmt [74635,74645]
===
match
---
trailer [58587,58594]
trailer [58618,58625]
===
match
---
number: 1 [62048,62049]
number: 1 [62079,62080]
===
match
---
operator: = [72315,72316]
operator: = [73939,73940]
===
match
---
trailer [21134,21145]
trailer [21165,21176]
===
match
---
operator: = [75073,75074]
operator: = [76697,76698]
===
match
---
argument [7568,7591]
argument [7599,7622]
===
match
---
name: session [36983,36990]
name: session [37014,37021]
===
match
---
trailer [49318,49323]
trailer [49349,49354]
===
match
---
name: next_local [22714,22724]
name: next_local [22745,22755]
===
match
---
string: 'creating_dag_in_cm' [7546,7566]
string: 'creating_dag_in_cm' [7577,7597]
===
match
---
name: next_info [63900,63909]
name: next_info [65524,65533]
===
match
---
argument [67147,67166]
argument [68771,68790]
===
match
---
assert_stmt [9197,9263]
assert_stmt [9228,9294]
===
match
---
name: globals [20109,20116]
name: globals [20140,20147]
===
match
---
trailer [21299,21301]
trailer [21330,21332]
===
match
---
trailer [11230,11233]
trailer [11261,11264]
===
match
---
operator: = [56086,56087]
operator: = [56117,56118]
===
match
---
name: test_get_num_task_instances [17465,17492]
name: test_get_num_task_instances [17496,17523]
===
match
---
operator: { [12763,12764]
operator: { [12794,12795]
===
match
---
comparison [7063,7078]
comparison [7094,7109]
===
match
---
trailer [56718,56735]
trailer [56749,56766]
===
match
---
name: start_date [58113,58123]
name: start_date [58144,58154]
===
match
---
assert_stmt [32839,32878]
assert_stmt [32870,32909]
===
match
---
operator: , [49971,49972]
operator: , [50002,50003]
===
match
---
string: 'dag' [34418,34423]
string: 'dag' [34449,34454]
===
match
---
argument [43841,43889]
argument [43872,43920]
===
match
---
string: 'owner1' [11455,11463]
string: 'owner1' [11486,11494]
===
match
---
name: task_id [15632,15639]
name: task_id [15663,15670]
===
match
---
atom_expr [70760,70777]
atom_expr [72384,72401]
===
match
---
comp_if [55901,55926]
comp_if [55932,55957]
===
match
---
trailer [74797,74810]
trailer [76421,76434]
===
match
---
name: state [57235,57240]
name: state [57266,57271]
===
match
---
trailer [74483,74485]
trailer [76107,76109]
===
match
---
dictorsetmaker [66031,66210]
dictorsetmaker [67655,67834]
===
match
---
operator: = [37047,37048]
operator: = [37078,37079]
===
match
---
name: run [47160,47163]
name: run [47191,47194]
===
match
---
name: DagModel [31317,31325]
name: DagModel [31348,31356]
===
match
---
operator: = [50738,50739]
operator: = [50769,50770]
===
match
---
name: run_id [18539,18545]
name: run_id [18570,18576]
===
match
---
atom_expr [19072,19159]
atom_expr [19103,19190]
===
match
---
trailer [22259,22280]
trailer [22290,22311]
===
match
---
name: return_num [75184,75194]
name: return_num [76808,76818]
===
match
---
suite [41460,41605]
suite [41491,41636]
===
match
---
parameters [8090,8096]
parameters [8121,8127]
===
match
---
operator: == [69903,69905]
operator: == [71527,71529]
===
match
---
trailer [59453,59476]
trailer [59484,59507]
===
match
---
atom_expr [7708,7728]
atom_expr [7739,7759]
===
match
---
name: in_ [35077,35080]
name: in_ [35108,35111]
===
match
---
expr_stmt [21225,21259]
expr_stmt [21256,21290]
===
match
---
string: 'cache_size' [20273,20285]
string: 'cache_size' [20304,20316]
===
match
---
import_from [2294,2336]
import_from [2325,2367]
===
match
---
name: DEFAULT_DATE [68786,68798]
name: DEFAULT_DATE [70410,70422]
===
match
---
name: _clean_up [46525,46534]
name: _clean_up [46556,46565]
===
match
---
string: "test-dag" [20556,20566]
string: "test-dag" [20587,20597]
===
match
---
trailer [45899,45909]
trailer [45930,45940]
===
match
---
name: schedule_interval [61597,61614]
name: schedule_interval [61628,61645]
===
match
---
trailer [10028,10035]
trailer [10059,10066]
===
match
---
parameters [75432,75452]
parameters [77056,77076]
===
match
---
assert_stmt [61977,62053]
assert_stmt [62008,62084]
===
match
---
param [46576,46580]
param [46607,46611]
===
match
---
arglist [71467,71505]
arglist [73091,73129]
===
match
---
name: dag_id [42530,42536]
name: dag_id [42561,42567]
===
match
---
operator: != [43008,43010]
operator: != [43039,43041]
===
match
---
trailer [33301,33309]
trailer [33332,33340]
===
match
---
name: ti1 [76886,76889]
name: ti1 [78510,78513]
===
match
---
suite [9306,10185]
suite [9337,10216]
===
match
---
atom [47470,47518]
atom [47501,47549]
===
match
---
expr_stmt [14377,14443]
expr_stmt [14408,14474]
===
match
---
number: 1 [52466,52467]
number: 1 [52497,52498]
===
match
---
name: next_info [61944,61953]
name: next_info [61975,61984]
===
match
---
atom_expr [10036,10055]
atom_expr [10067,10086]
===
match
---
name: DagParam [74355,74363]
name: DagParam [75979,75987]
===
match
---
suite [73469,73497]
suite [75093,75121]
===
match
---
operator: , [38783,38784]
operator: , [38814,38815]
===
match
---
operator: = [43657,43658]
operator: = [43688,43689]
===
match
---
operator: = [43914,43915]
operator: = [43945,43946]
===
match
---
atom_expr [7542,7592]
atom_expr [7573,7623]
===
match
---
simple_stmt [57889,57925]
simple_stmt [57920,57956]
===
match
---
operator: , [54641,54642]
operator: , [54672,54673]
===
match
---
name: DummyOperator [38974,38987]
name: DummyOperator [39005,39018]
===
match
---
name: dag_id [38085,38091]
name: dag_id [38116,38122]
===
match
---
expr_stmt [41137,41179]
expr_stmt [41168,41210]
===
match
---
trailer [75875,75893]
trailer [77499,77517]
===
match
---
operator: , [62839,62840]
operator: , [62870,62871]
===
match
---
name: dag [4664,4667]
name: dag [4695,4698]
===
match
---
trailer [77949,78096]
trailer [79573,79720]
===
match
---
name: model [45215,45220]
name: model [45246,45251]
===
match
---
name: session [53934,53941]
name: session [53965,53972]
===
match
---
atom_expr [45885,45925]
atom_expr [45916,45956]
===
match
---
trailer [65132,65144]
trailer [66756,66768]
===
match
---
name: unpaused_dags [34943,34956]
name: unpaused_dags [34974,34987]
===
match
---
expr_stmt [32431,32454]
expr_stmt [32462,32485]
===
match
---
trailer [24899,24904]
trailer [24930,24935]
===
match
---
comparison [7230,7251]
comparison [7261,7282]
===
match
---
name: dag [49005,49008]
name: dag [49036,49039]
===
match
---
arglist [56992,56995]
arglist [57023,57026]
===
match
---
name: convert [24439,24446]
name: convert [24470,24477]
===
match
---
atom_expr [24966,24988]
atom_expr [24997,25019]
===
match
---
expr_stmt [65774,65822]
expr_stmt [67398,67446]
===
match
---
name: timezone [38528,38536]
name: timezone [38559,38567]
===
match
---
expr_stmt [62856,62913]
expr_stmt [62887,62944]
===
match
---
string: "2018-03-25T01:00:00+00:00" [25056,25083]
string: "2018-03-25T01:00:00+00:00" [25087,25114]
===
match
---
assert_stmt [22324,22418]
assert_stmt [22355,22449]
===
match
---
name: DagModel [34795,34803]
name: DagModel [34826,34834]
===
match
---
atom_expr [6328,6373]
atom_expr [6359,6404]
===
match
---
argument [47947,47964]
argument [47978,47995]
===
match
---
name: dag [46294,46297]
name: dag [46325,46328]
===
match
---
argument [59468,59475]
argument [59499,59506]
===
match
---
trailer [54633,54641]
trailer [54664,54672]
===
match
---
trailer [10052,10055]
trailer [10083,10086]
===
match
---
operator: == [12954,12956]
operator: == [12985,12987]
===
match
---
operator: = [19134,19135]
operator: = [19165,19166]
===
match
---
operator: == [30281,30283]
operator: == [30312,30314]
===
match
---
argument [59722,59730]
argument [59753,59761]
===
match
---
name: dag [22561,22564]
name: dag [22592,22595]
===
match
---
number: 1 [44698,44699]
number: 1 [44729,44730]
===
match
---
comp_op [31997,32003]
comp_op [32028,32034]
===
match
---
simple_stmt [7795,7830]
simple_stmt [7826,7861]
===
match
---
trailer [69633,69645]
trailer [71257,71269]
===
match
---
atom_expr [14968,15158]
atom_expr [14999,15189]
===
match
---
name: DummyOperator [33547,33560]
name: DummyOperator [33578,33591]
===
match
---
sync_comp_for [16508,16532]
sync_comp_for [16539,16563]
===
match
---
parameters [74953,74959]
parameters [76577,76583]
===
match
---
name: test_task_id [19113,19125]
name: test_task_id [19144,19156]
===
match
---
testlist_comp [19008,19032]
testlist_comp [19039,19063]
===
match
---
atom_expr [69193,69208]
atom_expr [70817,70832]
===
match
---
simple_stmt [59434,59477]
simple_stmt [59465,59508]
===
match
---
trailer [61624,61632]
trailer [61655,61663]
===
match
---
atom_expr [70871,70900]
atom_expr [72495,72524]
===
match
---
name: State [19402,19407]
name: State [19433,19438]
===
match
---
simple_stmt [24288,24360]
simple_stmt [24319,24391]
===
match
---
arglist [47537,47567]
arglist [47568,47598]
===
match
---
name: bulk_write_to_db [29074,29090]
name: bulk_write_to_db [29105,29121]
===
match
---
comparison [57221,57256]
comparison [57252,57287]
===
match
---
name: execution_date [47216,47230]
name: execution_date [47247,47261]
===
match
---
operator: == [32915,32917]
operator: == [32946,32948]
===
match
---
name: schedule_interval [26594,26611]
name: schedule_interval [26625,26642]
===
match
---
argument [33448,33471]
argument [33479,33502]
===
match
---
name: close [34099,34104]
name: close [34130,34135]
===
match
---
arith_expr [78219,78261]
arith_expr [79843,79885]
===
match
---
atom_expr [43947,44017]
atom_expr [43978,44048]
===
match
---
simple_stmt [49332,49371]
simple_stmt [49363,49402]
===
match
---
name: filter [49777,49783]
name: filter [49808,49814]
===
match
---
suite [6094,6176]
suite [6125,6207]
===
match
---
operator: , [20566,20567]
operator: , [20597,20598]
===
match
---
operator: = [6962,6963]
operator: = [6993,6994]
===
match
---
operator: = [64205,64206]
operator: = [65829,65830]
===
match
---
trailer [7861,7876]
trailer [7892,7907]
===
match
---
param [72926,72931]
param [74550,74555]
===
match
---
assert_stmt [21972,22025]
assert_stmt [22003,22056]
===
match
---
simple_stmt [35965,36063]
simple_stmt [35996,36094]
===
match
---
atom_expr [4670,4742]
atom_expr [4701,4773]
===
match
---
name: value [72926,72931]
name: value [74550,74555]
===
match
---
param [43400,43405]
param [43431,43436]
===
match
---
simple_stmt [23324,23419]
simple_stmt [23355,23450]
===
match
---
funcdef [69742,69924]
funcdef [71366,71548]
===
match
---
assert_stmt [37861,37885]
assert_stmt [37892,37916]
===
match
---
name: is_paused [35730,35739]
name: is_paused [35761,35770]
===
match
---
atom_expr [47212,47230]
atom_expr [47243,47261]
===
match
---
arglist [30627,30653]
arglist [30658,30684]
===
match
---
name: start_date [47025,47035]
name: start_date [47056,47066]
===
match
---
operator: , [65175,65176]
operator: , [66799,66800]
===
match
---
atom_expr [72137,72147]
atom_expr [73761,73771]
===
match
---
name: start_date [22494,22504]
name: start_date [22525,22535]
===
match
---
name: expand [51552,51558]
name: expand [51583,51589]
===
match
---
argument [50724,50751]
argument [50755,50782]
===
match
---
name: list [79082,79086]
name: list [80706,80710]
===
match
---
operator: , [30260,30261]
operator: , [30291,30292]
===
match
---
atom_expr [67651,67665]
atom_expr [69275,69289]
===
match
---
string: 'dag.subdag' [34195,34207]
string: 'dag.subdag' [34226,34238]
===
match
---
operator: , [5816,5817]
operator: , [5847,5848]
===
match
---
atom_expr [18610,18628]
atom_expr [18641,18659]
===
match
---
name: State [51610,51615]
name: State [51641,51646]
===
match
---
comparison [22650,22698]
comparison [22681,22729]
===
match
---
simple_stmt [49462,49510]
simple_stmt [49493,49541]
===
match
---
name: pytest [40918,40924]
name: pytest [40949,40955]
===
match
---
name: prev_task [15529,15538]
name: prev_task [15560,15569]
===
match
---
name: DagRunType [51067,51077]
name: DagRunType [51098,51108]
===
match
---
string: "t5" [39042,39046]
string: "t5" [39073,39077]
===
match
---
arglist [23367,23382]
arglist [23398,23413]
===
match
---
atom_expr [24531,24561]
atom_expr [24562,24592]
===
match
---
atom_expr [32586,32604]
atom_expr [32617,32635]
===
match
---
expr_stmt [34731,34754]
expr_stmt [34762,34785]
===
match
---
atom_expr [49314,49323]
atom_expr [49345,49354]
===
match
---
operator: { [28518,28519]
operator: { [28549,28550]
===
match
---
name: op4 [39082,39085]
name: op4 [39113,39116]
===
match
---
operator: = [9369,9370]
operator: = [9400,9401]
===
match
---
expr_stmt [75853,75893]
expr_stmt [77477,77517]
===
match
---
comparison [77067,77112]
comparison [78691,78736]
===
match
---
trailer [49957,49970]
trailer [49988,50001]
===
match
---
name: test_next_dagrun_info_timedelta_schedule_and_catchup_false [61208,61266]
name: test_next_dagrun_info_timedelta_schedule_and_catchup_false [61239,61297]
===
match
---
name: DAG [53205,53208]
name: DAG [53236,53239]
===
match
---
operator: = [10427,10428]
operator: = [10458,10459]
===
match
---
argument [59732,59745]
argument [59763,59776]
===
match
---
atom_expr [66275,66302]
atom_expr [67899,67926]
===
match
---
trailer [20593,20603]
trailer [20624,20634]
===
match
---
name: utils [2307,2312]
name: utils [2338,2343]
===
match
---
trailer [55346,55352]
trailer [55377,55383]
===
match
---
argument [25667,25684]
argument [25698,25715]
===
match
---
name: DagTag [30642,30648]
name: DagTag [30673,30679]
===
match
---
arglist [53162,53186]
arglist [53193,53217]
===
match
---
name: session [34917,34924]
name: session [34948,34955]
===
match
---
name: DagModel [67848,67856]
name: DagModel [69472,69480]
===
match
---
operator: = [53076,53077]
operator: = [53107,53108]
===
match
---
decorated [34112,36063]
decorated [34143,36094]
===
match
---
name: op4 [39563,39566]
name: op4 [39594,39597]
===
match
---
trailer [49295,49310]
trailer [49326,49341]
===
match
---
atom_expr [27967,27980]
atom_expr [27998,28011]
===
match
---
trailer [3463,3490]
trailer [3494,3521]
===
match
---
trailer [46994,46996]
trailer [47025,47027]
===
match
---
comp_op [32867,32873]
comp_op [32898,32904]
===
match
---
name: set_downstream [10652,10666]
name: set_downstream [10683,10697]
===
match
---
simple_stmt [7357,7392]
simple_stmt [7388,7423]
===
match
---
name: next_info [62625,62634]
name: next_info [62656,62665]
===
match
---
number: 3 [14725,14726]
number: 3 [14756,14757]
===
match
---
expr_stmt [46365,46415]
expr_stmt [46396,46446]
===
match
---
operator: = [42100,42101]
operator: = [42131,42132]
===
match
---
name: schedule_interval [58975,58992]
name: schedule_interval [59006,59023]
===
match
---
atom_expr [73144,73168]
atom_expr [74768,74792]
===
match
---
operator: = [33458,33459]
operator: = [33489,33490]
===
match
---
with_stmt [34519,34589]
with_stmt [34550,34620]
===
match
---
comparison [32846,32878]
comparison [32877,32909]
===
match
---
name: dag_id [45557,45563]
name: dag_id [45588,45594]
===
match
---
name: mock [2923,2927]
name: mock [2954,2958]
===
match
---
operator: == [4846,4848]
operator: == [4877,4879]
===
match
---
trailer [40069,40071]
trailer [40100,40102]
===
match
---
name: stage [16747,16752]
name: stage [16778,16783]
===
match
---
trailer [37751,37768]
trailer [37782,37799]
===
match
---
name: dirname [20902,20909]
name: dirname [20933,20940]
===
match
---
trailer [35853,35926]
trailer [35884,35957]
===
match
---
operator: - [78048,78049]
operator: - [79672,79673]
===
match
---
tfpdef [56041,56068]
tfpdef [56072,56099]
===
match
---
atom_expr [9321,9390]
atom_expr [9352,9421]
===
match
---
simple_stmt [9519,9552]
simple_stmt [9550,9583]
===
match
---
operator: = [16177,16178]
operator: = [16208,16209]
===
match
---
name: synchronize_session [3394,3413]
name: synchronize_session [3425,3444]
===
match
---
name: DummyOperator [59495,59508]
name: DummyOperator [59526,59539]
===
match
---
trailer [25050,25052]
trailer [25081,25083]
===
match
---
name: timedelta [57906,57915]
name: timedelta [57937,57946]
===
match
---
trailer [66396,66412]
trailer [68020,68036]
===
match
---
simple_stmt [8283,8316]
simple_stmt [8314,8347]
===
match
---
string: 'dummy' [68830,68837]
string: 'dummy' [70454,70461]
===
match
---
string: 'DAG' [12743,12748]
string: 'DAG' [12774,12779]
===
match
---
comparison [14531,14566]
comparison [14562,14597]
===
match
---
trailer [37740,37751]
trailer [37771,37782]
===
match
---
classdef [70616,75398]
classdef [72240,77022]
===
match
---
number: 1 [19067,19068]
number: 1 [19098,19099]
===
match
---
trailer [65216,65227]
trailer [66840,66851]
===
match
---
name: op1 [39311,39314]
name: op1 [39342,39345]
===
match
---
trailer [56176,56228]
trailer [56207,56259]
===
match
---
assert_stmt [51496,51531]
assert_stmt [51527,51562]
===
match
---
trailer [41222,41232]
trailer [41253,41263]
===
match
---
string: 'dag2' [6790,6796]
string: 'dag2' [6821,6827]
===
match
---
string: "hello" [19862,19869]
string: "hello" [19893,19900]
===
match
---
name: commit [52340,52346]
name: commit [52371,52377]
===
match
---
expr_stmt [13708,13881]
expr_stmt [13739,13912]
===
match
---
simple_stmt [69164,69185]
simple_stmt [70788,70809]
===
match
---
name: DagRunInfo [78452,78462]
name: DagRunInfo [80076,80086]
===
match
---
trailer [55709,55738]
trailer [55740,55769]
===
match
---
simple_stmt [19452,19603]
simple_stmt [19483,19634]
===
match
---
operator: = [67313,67314]
operator: = [68937,68938]
===
match
---
operator: >> [39923,39925]
operator: >> [39954,39956]
===
match
---
name: self [44425,44429]
name: self [44456,44460]
===
match
---
expr_stmt [4664,4742]
expr_stmt [4695,4773]
===
match
---
suite [10410,10812]
suite [10441,10843]
===
match
---
param [28054,28058]
param [28085,28089]
===
match
---
name: settings [68884,68892]
name: settings [70508,70516]
===
match
---
trailer [56779,56920]
trailer [56810,56951]
===
match
---
name: f [20824,20825]
name: f [20855,20856]
===
match
---
operator: = [31301,31302]
operator: = [31332,31333]
===
match
---
string: "Pre-condition: start date is in DST" [22381,22418]
string: "Pre-condition: start date is in DST" [22412,22449]
===
match
---
suite [70658,75398]
suite [72282,77022]
===
match
---
operator: = [67415,67416]
operator: = [69039,69040]
===
match
---
dictorsetmaker [28333,28407]
dictorsetmaker [28364,28438]
===
match
---
operator: == [7104,7106]
operator: == [7135,7137]
===
match
---
argument [7905,7918]
argument [7936,7949]
===
match
---
simple_stmt [14917,15277]
simple_stmt [14948,15308]
===
match
---
testlist_comp [29577,29607]
testlist_comp [29608,29638]
===
match
---
simple_stmt [34699,34723]
simple_stmt [34730,34754]
===
match
---
operator: = [61921,61922]
operator: = [61952,61953]
===
match
---
number: 5 [61196,61197]
number: 5 [61227,61228]
===
match
---
assert_stmt [76879,76912]
assert_stmt [78503,78536]
===
match
---
number: 1 [65753,65754]
number: 1 [67377,67378]
===
match
---
string: 'tag-1' [27776,27783]
string: 'tag-1' [27807,27814]
===
match
---
name: rollback [2767,2775]
name: rollback [2798,2806]
===
match
---
argument [60437,60473]
argument [60468,60504]
===
match
---
operator: = [56395,56396]
operator: = [56426,56427]
===
match
---
name: add_task [43938,43946]
name: add_task [43969,43977]
===
match
---
expr_stmt [6935,6979]
expr_stmt [6966,7010]
===
match
---
name: dag_decorator [71453,71466]
name: dag_decorator [73077,73090]
===
match
---
atom_expr [20663,20682]
atom_expr [20694,20713]
===
match
---
string: 'new_nonexisting_dag' [36505,36526]
string: 'new_nonexisting_dag' [36536,36557]
===
match
---
name: dag_id [7662,7668]
name: dag_id [7693,7699]
===
match
---
atom_expr [15503,15539]
atom_expr [15534,15570]
===
match
---
import_from [974,1013]
import_from [974,1013]
===
match
---
name: clear_db_dags [3083,3096]
name: clear_db_dags [3114,3127]
===
match
---
name: next_dagrun [67639,67650]
name: next_dagrun [69263,69274]
===
match
---
operator: = [52249,52250]
operator: = [52280,52281]
===
match
---
name: airflow [1505,1512]
name: airflow [1511,1518]
===
match
---
expr_stmt [69316,69340]
expr_stmt [70940,70964]
===
match
---
name: datetime [27110,27118]
name: datetime [27141,27149]
===
match
---
trailer [41156,41179]
trailer [41187,41210]
===
match
---
trailer [9793,9810]
trailer [9824,9841]
===
match
---
comparison [4192,4212]
comparison [4223,4243]
===
match
---
name: SUCCESS [45082,45089]
name: SUCCESS [45113,45120]
===
match
---
name: TIMEZONE [12850,12858]
name: TIMEZONE [12881,12889]
===
match
---
trailer [28744,28750]
trailer [28775,28781]
===
match
---
trailer [28478,28482]
trailer [28509,28513]
===
match
---
operator: == [38082,38084]
operator: == [38113,38115]
===
match
---
atom [19007,19033]
atom [19038,19064]
===
match
---
name: DagModel [37819,37827]
name: DagModel [37850,37858]
===
match
---
suite [36486,36881]
suite [36517,36912]
===
match
---
name: t_1 [52230,52233]
name: t_1 [52261,52264]
===
match
---
operator: = [71664,71665]
operator: = [73288,73289]
===
match
---
name: test_relative_fileloc [69746,69767]
name: test_relative_fileloc [71370,71391]
===
match
---
name: RUNNING [54028,54035]
name: RUNNING [54059,54066]
===
match
---
trailer [57420,57432]
trailer [57451,57463]
===
match
---
name: datetime [17930,17938]
name: datetime [17961,17969]
===
match
---
expr_stmt [28093,28192]
expr_stmt [28124,28223]
===
match
---
name: DEFAULT_DATE [74798,74810]
name: DEFAULT_DATE [76422,76434]
===
match
---
testlist_comp [55083,55094]
testlist_comp [55114,55125]
===
match
---
operator: = [20623,20624]
operator: = [20654,20655]
===
match
---
atom_expr [73551,73564]
atom_expr [75175,75188]
===
match
---
operator: = [36133,36134]
operator: = [36164,36165]
===
match
---
name: Session [55243,55250]
name: Session [55274,55281]
===
match
---
name: test_following_previous_schedule_daily_dag_cest_to_cet [23120,23174]
name: test_following_previous_schedule_daily_dag_cest_to_cet [23151,23205]
===
match
---
name: pickle [47594,47600]
name: pickle [47625,47631]
===
match
---
name: inspect [1291,1298]
name: inspect [1297,1304]
===
match
---
argument [68041,68079]
argument [69665,69703]
===
match
---
assert_stmt [61727,61803]
assert_stmt [61758,61834]
===
match
---
string: """         Test scheduling a dag where there is a prior DagRun         which has the same run_id as the next run should have         """ [44519,44656]
string: """         Test scheduling a dag where there is a prior DagRun         which has the same run_id as the next run should have         """ [44550,44687]
===
match
---
expr_stmt [21574,21614]
expr_stmt [21605,21645]
===
match
---
trailer [30708,30725]
trailer [30739,30756]
===
match
---
dotted_name [1794,1817]
dotted_name [1800,1823]
===
match
---
atom_expr [52066,52078]
atom_expr [52097,52109]
===
match
---
with_item [41412,41459]
with_item [41443,41490]
===
match
---
operator: , [64095,64096]
operator: , [65719,65720]
===
match
---
operator: , [52468,52469]
operator: , [52499,52500]
===
match
---
atom_expr [51160,51170]
atom_expr [51191,51201]
===
match
---
operator: , [65090,65091]
operator: , [66714,66715]
===
match
---
operator: } [6768,6769]
operator: } [6799,6800]
===
match
---
name: max_active_runs [53252,53267]
name: max_active_runs [53283,53298]
===
match
---
atom_expr [15188,15203]
atom_expr [15219,15234]
===
match
---
simple_stmt [76846,76875]
simple_stmt [78470,78499]
===
match
---
arith_expr [77777,77819]
arith_expr [79401,79443]
===
match
---
parameters [39161,39167]
parameters [39192,39198]
===
match
---
name: expand [49865,49871]
name: expand [49896,49902]
===
match
---
atom [55939,55972]
atom [55970,56003]
===
match
---
name: session [75673,75680]
name: session [77297,77304]
===
match
---
param [58975,58993]
param [59006,59024]
===
match
---
parameters [32033,32039]
parameters [32064,32070]
===
match
---
operator: , [12453,12454]
operator: , [12484,12485]
===
match
---
name: re [13356,13358]
name: re [13387,13389]
===
match
---
name: self [9204,9208]
name: self [9235,9239]
===
match
---
operator: = [27531,27532]
operator: = [27562,27563]
===
match
---
trailer [70455,70469]
trailer [72079,72093]
===
match
---
suite [49740,49845]
suite [49771,49876]
===
match
---
shift_expr [40699,40709]
shift_expr [40730,40740]
===
match
---
simple_stmt [68031,68123]
simple_stmt [69655,69747]
===
match
---
expr_stmt [14735,14744]
expr_stmt [14766,14775]
===
match
---
name: dagrun [55614,55620]
name: dagrun [55645,55651]
===
match
---
number: 1 [50316,50317]
number: 1 [50347,50348]
===
match
---
string: 'test-dag2' [29596,29607]
string: 'test-dag2' [29627,29638]
===
match
---
name: start_date [16167,16177]
name: start_date [16198,16208]
===
match
---
yield_expr [2737,2750]
yield_expr [2768,2781]
===
match
---
name: state [70537,70542]
name: state [72161,72166]
===
match
---
simple_stmt [58035,58080]
simple_stmt [58066,58111]
===
match
---
trailer [35313,35354]
trailer [35344,35385]
===
match
---
atom_expr [18637,18655]
atom_expr [18668,18686]
===
match
---
simple_stmt [78844,78884]
simple_stmt [80468,80508]
===
match
---
string: 'test_set_task_instance_state' [77565,77595]
string: 'test_set_task_instance_state' [79189,79219]
===
match
---
simple_stmt [11074,11109]
simple_stmt [11105,11140]
===
match
---
name: dag [24877,24880]
name: dag [24908,24911]
===
match
---
simple_stmt [46466,46512]
simple_stmt [46497,46543]
===
match
---
comparison [38066,38091]
comparison [38097,38122]
===
match
---
name: sub_dag [42092,42099]
name: sub_dag [42123,42130]
===
match
---
name: dag [72607,72610]
name: dag [74231,74234]
===
match
---
trailer [23666,23668]
trailer [23697,23699]
===
match
---
name: settings [56302,56310]
name: settings [56333,56341]
===
match
---
name: dag [7067,7070]
name: dag [7098,7101]
===
match
---
simple_stmt [14524,14567]
simple_stmt [14555,14598]
===
match
---
operator: = [35323,35324]
operator: = [35354,35355]
===
match
---
simple_stmt [66229,66425]
simple_stmt [67853,68049]
===
match
---
atom_expr [28993,29019]
atom_expr [29024,29050]
===
match
---
name: self [36114,36118]
name: self [36145,36149]
===
match
---
string: 'Also fake' [58242,58253]
string: 'Also fake' [58273,58284]
===
match
---
string: "@monthly" [50040,50050]
string: "@monthly" [50071,50081]
===
match
---
assert_stmt [62618,62694]
assert_stmt [62649,62725]
===
match
---
operator: = [63811,63812]
operator: = [65435,65436]
===
match
---
operator: = [21753,21754]
operator: = [21784,21785]
===
match
---
expr_stmt [47463,47518]
expr_stmt [47494,47549]
===
match
---
atom_expr [65354,65364]
atom_expr [66978,66988]
===
match
---
operator: == [24766,24768]
operator: == [24797,24799]
===
match
---
assert_stmt [17103,17145]
assert_stmt [17134,17176]
===
match
---
trailer [11311,11314]
trailer [11342,11345]
===
match
---
name: task_id [40596,40603]
name: task_id [40627,40634]
===
match
---
name: timezone [62969,62977]
name: timezone [63000,63008]
===
match
---
atom_expr [40632,40682]
atom_expr [40663,40713]
===
match
---
trailer [50788,50795]
trailer [50819,50826]
===
match
---
argument [64200,64215]
argument [65824,65839]
===
match
---
name: MANUAL [53577,53583]
name: MANUAL [53608,53614]
===
match
---
suite [5213,5265]
suite [5244,5296]
===
match
---
name: DagModel [49618,49626]
name: DagModel [49649,49657]
===
match
---
comparison [23715,23762]
comparison [23746,23793]
===
match
---
name: a_index [3782,3789]
name: a_index [3813,3820]
===
match
---
name: logical_date [57557,57569]
name: logical_date [57588,57600]
===
match
---
argument [45070,45089]
argument [45101,45120]
===
match
---
comparison [31411,31477]
comparison [31442,31508]
===
match
---
atom_expr [74468,74485]
atom_expr [76092,76109]
===
match
---
name: warns [66644,66649]
name: warns [68268,68273]
===
match
---
atom_expr [25567,25610]
atom_expr [25598,25641]
===
match
---
name: dag [40013,40016]
name: dag [40044,40047]
===
match
---
operator: == [45447,45449]
operator: == [45478,45480]
===
match
---
operator: } [12807,12808]
operator: } [12838,12839]
===
match
---
name: DummyOperator [10609,10622]
name: DummyOperator [10640,10653]
===
match
---
atom_expr [44866,44944]
atom_expr [44897,44975]
===
match
---
name: DagParam [1725,1733]
name: DagParam [1731,1739]
===
match
---
simple_stmt [59828,59878]
simple_stmt [59859,59909]
===
match
---
trailer [22182,22191]
trailer [22213,22222]
===
match
---
trailer [11206,11213]
trailer [11237,11244]
===
match
---
name: query [34981,34986]
name: query [35012,35017]
===
match
---
name: DummyOperator [38928,38941]
name: DummyOperator [38959,38972]
===
match
---
name: doc_md [72670,72676]
name: doc_md [74294,74300]
===
match
---
comparison [57685,57702]
comparison [57716,57733]
===
match
---
operator: , [52692,52693]
operator: , [52723,52724]
===
match
---
operator: = [64948,64949]
operator: = [66572,66573]
===
match
---
simple_stmt [57612,57670]
simple_stmt [57643,57701]
===
match
---
simple_stmt [9937,9971]
simple_stmt [9968,10002]
===
match
---
name: DuplicateTaskIdFound [40932,40952]
name: DuplicateTaskIdFound [40963,40983]
===
match
---
atom [59655,59690]
atom [59686,59721]
===
match
---
operator: = [22608,22609]
operator: = [22639,22640]
===
match
---
argument [44001,44016]
argument [44032,44047]
===
match
---
name: return_num [72536,72546]
name: return_num [74160,74170]
===
match
---
arglist [28751,28777]
arglist [28782,28808]
===
match
---
operator: = [9788,9789]
operator: = [9819,9820]
===
match
---
trailer [33057,33064]
trailer [33088,33095]
===
match
---
trailer [71281,71288]
trailer [72905,72912]
===
match
---
trailer [51986,52000]
trailer [52017,52031]
===
match
---
name: create_dagrun [17990,18003]
name: create_dagrun [18021,18034]
===
match
---
name: name [38657,38661]
name: name [38688,38692]
===
match
---
operator: , [19929,19930]
operator: , [19960,19961]
===
match
---
name: set1 [10980,10984]
name: set1 [11011,11015]
===
match
---
name: return_num [71984,71994]
name: return_num [73608,73618]
===
match
---
operator: = [21146,21147]
operator: = [21177,21178]
===
match
---
name: pytest [1138,1144]
name: pytest [1144,1150]
===
match
---
trailer [20203,20291]
trailer [20234,20322]
===
match
---
operator: = [41164,41165]
operator: = [41195,41196]
===
match
---
name: DAG [47774,47777]
name: DAG [47805,47808]
===
match
---
name: DEFAULT_DATE [57963,57975]
name: DEFAULT_DATE [57994,58006]
===
match
---
simple_stmt [68874,68903]
simple_stmt [70498,70527]
===
match
---
name: DagRun [55710,55716]
name: DagRun [55741,55747]
===
match
---
name: t_1 [53142,53145]
name: t_1 [53173,53176]
===
match
---
atom_expr [58595,58609]
atom_expr [58626,58640]
===
match
---
trailer [5515,5519]
trailer [5546,5550]
===
match
---
name: session [32576,32583]
name: session [32607,32614]
===
match
---
name: ti_state_end [56041,56053]
name: ti_state_end [56072,56084]
===
match
---
simple_stmt [32735,32798]
simple_stmt [32766,32829]
===
match
---
name: self [9300,9304]
name: self [9331,9335]
===
match
---
operator: = [19959,19960]
operator: = [19990,19991]
===
match
---
name: b [3822,3823]
name: b [3853,3854]
===
match
---
operator: , [35421,35422]
operator: , [35452,35453]
===
match
---
name: weight_rule [16433,16444]
name: weight_rule [16464,16475]
===
match
---
trailer [53361,53389]
trailer [53392,53420]
===
match
---
trailer [77387,77395]
trailer [79011,79019]
===
match
---
name: params1 [4717,4724]
name: params1 [4748,4755]
===
match
---
trailer [32901,32914]
trailer [32932,32945]
===
match
---
argument [68344,68360]
argument [69968,69984]
===
match
---
operator: = [76007,76008]
operator: = [77631,77632]
===
match
---
trailer [28823,28850]
trailer [28854,28881]
===
match
---
atom_expr [10242,10311]
atom_expr [10273,10342]
===
match
---
string: 't1' [59407,59411]
string: 't1' [59438,59442]
===
match
---
name: next_info [62929,62938]
name: next_info [62960,62969]
===
match
---
atom_expr [76545,76557]
atom_expr [78169,78181]
===
match
---
number: 5 [13336,13337]
number: 5 [13367,13368]
===
match
---
operator: = [47905,47906]
operator: = [47936,47937]
===
match
---
name: datetime [50248,50256]
name: datetime [50279,50287]
===
match
---
name: dag_id [49419,49425]
name: dag_id [49450,49456]
===
match
---
trailer [77753,77762]
trailer [79377,79386]
===
match
---
operator: = [17280,17281]
operator: = [17311,17312]
===
match
---
param [20531,20535]
param [20562,20566]
===
match
---
trailer [66957,66964]
trailer [68581,68588]
===
match
---
simple_stmt [42049,42060]
simple_stmt [42080,42091]
===
match
---
atom [30390,30605]
atom [30421,30636]
===
match
---
name: next_info [57685,57694]
name: next_info [57716,57725]
===
match
---
name: op3 [41578,41581]
name: op3 [41609,41612]
===
match
---
funcdef [20138,20498]
funcdef [20169,20529]
===
match
---
assert_stmt [23862,23922]
assert_stmt [23893,23953]
===
match
---
name: range [15188,15193]
name: range [15219,15224]
===
match
---
operator: = [26213,26214]
operator: = [26244,26245]
===
match
---
operator: = [24529,24530]
operator: = [24560,24561]
===
match
---
assert_stmt [41640,41700]
assert_stmt [41671,41731]
===
match
---
name: convert [25159,25166]
name: convert [25190,25197]
===
match
---
expr_stmt [14716,14726]
expr_stmt [14747,14757]
===
match
---
name: template_ext [21230,21242]
name: template_ext [21261,21273]
===
match
---
number: 1 [67379,67380]
number: 1 [69003,69004]
===
match
---
expr_stmt [21725,21760]
expr_stmt [21756,21791]
===
match
---
operator: , [1733,1734]
operator: , [1739,1740]
===
match
---
atom_expr [77871,77898]
atom_expr [79495,79522]
===
match
---
comparison [30204,30370]
comparison [30235,30401]
===
match
---
string: 't1' [53059,53063]
string: 't1' [53090,53094]
===
match
---
name: StrictUndefined [20482,20497]
name: StrictUndefined [20513,20528]
===
match
---
operator: = [17058,17059]
operator: = [17089,17090]
===
match
---
name: utc [22428,22431]
name: utc [22459,22462]
===
match
---
name: dag [63118,63121]
name: dag [63149,63152]
===
match
---
expr_stmt [8106,8245]
expr_stmt [8137,8276]
===
match
---
string: 'depends_on_past' [59097,59114]
string: 'depends_on_past' [59128,59145]
===
match
---
operator: , [35183,35184]
operator: , [35214,35215]
===
match
---
number: 2 [18099,18100]
number: 2 [18130,18131]
===
match
---
name: dag_decorator [72854,72867]
name: dag_decorator [74478,74491]
===
match
---
name: task_id [10623,10630]
name: task_id [10654,10661]
===
match
---
testlist_comp [35177,35190]
testlist_comp [35208,35221]
===
match
---
trailer [27966,28002]
trailer [27997,28033]
===
match
---
name: dag_id [47650,47656]
name: dag_id [47681,47687]
===
match
---
name: xcom_pull [74898,74907]
name: xcom_pull [76522,76531]
===
match
---
atom_expr [21225,21242]
atom_expr [21256,21273]
===
match
---
operator: = [50629,50630]
operator: = [50660,50661]
===
match
---
suite [41010,41203]
suite [41041,41234]
===
match
---
operator: { [77535,77536]
operator: { [79159,79160]
===
match
---
trailer [49270,49275]
trailer [49301,49306]
===
match
---
operator: == [24829,24831]
operator: == [24860,24862]
===
match
---
suite [34528,34589]
suite [34559,34620]
===
match
---
atom_expr [53979,54036]
atom_expr [54010,54067]
===
match
---
name: State [77242,77247]
name: State [78866,78871]
===
match
---
with_stmt [7769,7830]
with_stmt [7800,7861]
===
match
---
operator: = [46165,46166]
operator: = [46196,46197]
===
match
---
trailer [3111,3128]
trailer [3142,3159]
===
match
---
argument [6737,6769]
argument [6768,6800]
===
match
---
argument [64941,64981]
argument [66565,66605]
===
match
---
number: 1 [69114,69115]
number: 1 [70738,70739]
===
match
---
operator: = [53182,53183]
operator: = [53213,53214]
===
match
---
name: mock [43591,43595]
name: mock [43622,43626]
===
match
---
trailer [41544,41558]
trailer [41575,41589]
===
match
---
param [3566,3568]
param [3597,3599]
===
match
---
parameters [11374,11380]
parameters [11405,11411]
===
match
---
operator: = [21086,21087]
operator: = [21117,21118]
===
match
---
name: task_id [38942,38949]
name: task_id [38973,38980]
===
match
---
trailer [25729,25748]
trailer [25760,25779]
===
match
---
name: datetime [78354,78362]
name: datetime [79978,79986]
===
match
---
atom_expr [43068,43090]
atom_expr [43099,43121]
===
match
---
operator: } [16223,16224]
operator: } [16254,16255]
===
match
---
name: session [54129,54136]
name: session [54160,54167]
===
match
---
expr_stmt [38378,38455]
expr_stmt [38409,38486]
===
match
---
trailer [38425,38454]
trailer [38456,38485]
===
match
---
testlist_comp [70125,70127]
testlist_comp [71749,71751]
===
match
---
assert_stmt [26277,26331]
assert_stmt [26308,26362]
===
match
---
operator: = [15668,15669]
operator: = [15699,15700]
===
match
---
funcdef [55147,55813]
funcdef [55178,55844]
===
match
---
decorated [77628,79097]
decorated [79252,80721]
===
match
---
operator: = [10585,10586]
operator: = [10616,10617]
===
match
---
operator: = [11708,11709]
operator: = [11739,11740]
===
match
---
name: dag [4159,4162]
name: dag [4190,4193]
===
match
---
name: DEFAULT_DATE [53101,53113]
name: DEFAULT_DATE [53132,53144]
===
match
---
name: test_roots [38671,38681]
name: test_roots [38702,38712]
===
match
---
expr_stmt [41473,41512]
expr_stmt [41504,41543]
===
match
---
simple_stmt [18745,18762]
simple_stmt [18776,18793]
===
match
---
name: task_depth [14262,14272]
name: task_depth [14293,14303]
===
match
---
atom_expr [75608,75689]
atom_expr [77232,77313]
===
match
---
atom_expr [41963,41990]
atom_expr [41994,42021]
===
match
---
name: tasks [7712,7717]
name: tasks [7743,7748]
===
match
---
name: owner [33672,33677]
name: owner [33703,33708]
===
match
---
trailer [47368,47378]
trailer [47399,47409]
===
match
---
funcdef [71576,71624]
funcdef [73200,73248]
===
match
---
operator: = [6345,6346]
operator: = [6376,6377]
===
match
---
atom_expr [62943,62965]
atom_expr [62974,62996]
===
match
---
operator: , [48309,48310]
operator: , [48340,48341]
===
match
---
expr_stmt [50913,50965]
expr_stmt [50944,50996]
===
match
---
atom_expr [70306,70324]
atom_expr [71930,71948]
===
match
---
name: __table__ [38170,38179]
name: __table__ [38201,38210]
===
match
---
trailer [47635,47642]
trailer [47666,47673]
===
match
---
name: next_date [60279,60288]
name: next_date [60310,60319]
===
match
---
operator: = [59874,59875]
operator: = [59905,59906]
===
match
---
operator: } [66934,66935]
operator: } [68558,68559]
===
match
---
atom [9370,9389]
atom [9401,9420]
===
match
---
trailer [24455,24464]
trailer [24486,24495]
===
match
---
operator: , [72147,72148]
operator: , [73771,73772]
===
match
---
name: settings [31202,31210]
name: settings [31233,31241]
===
match
---
parameters [19668,19674]
parameters [19699,19705]
===
match
---
trailer [49726,49728]
trailer [49757,49759]
===
match
---
expr_stmt [63579,63757]
expr_stmt [65203,65381]
===
match
---
name: FAILED [76045,76051]
name: FAILED [77669,77675]
===
match
---
name: paused_dags [35660,35671]
name: paused_dags [35691,35702]
===
match
---
string: "bar" [19923,19928]
string: "bar" [19954,19959]
===
match
---
argument [13752,13775]
argument [13783,13806]
===
match
---
trailer [67407,67450]
trailer [69031,69074]
===
match
---
operator: , [59307,59308]
operator: , [59338,59339]
===
match
---
suite [71376,71752]
suite [73000,73376]
===
match
---
operator: >> [39552,39554]
operator: >> [39583,39585]
===
match
---
name: a [3566,3567]
name: a [3597,3598]
===
match
---
trailer [15252,15262]
trailer [15283,15293]
===
match
---
name: self [4280,4284]
name: self [4311,4315]
===
match
---
name: num [73493,73496]
name: num [75117,75120]
===
match
---
name: dag [16894,16897]
name: dag [16925,16928]
===
match
---
name: match [14279,14284]
name: match [14310,14315]
===
match
---
atom_expr [33291,33309]
atom_expr [33322,33340]
===
match
---
string: 'a_parent' [8919,8929]
string: 'a_parent' [8950,8960]
===
match
---
name: all [28779,28782]
name: all [28810,28813]
===
match
---
simple_stmt [14108,14145]
simple_stmt [14139,14176]
===
match
---
atom_expr [15613,15640]
atom_expr [15644,15671]
===
match
---
atom_expr [37974,38014]
atom_expr [38005,38045]
===
match
---
operator: { [32777,32778]
operator: { [32808,32809]
===
match
---
operator: , [28764,28765]
operator: , [28795,28796]
===
match
---
trailer [36164,36175]
trailer [36195,36206]
===
match
---
simple_stmt [25718,25760]
simple_stmt [25749,25791]
===
match
---
trailer [33344,33350]
trailer [33375,33381]
===
match
---
name: DEFAULT_DATE [78155,78167]
name: DEFAULT_DATE [79779,79791]
===
match
---
simple_stmt [65012,65030]
simple_stmt [66636,66654]
===
match
---
trailer [69206,69208]
trailer [70830,70832]
===
match
---
operator: = [42694,42695]
operator: = [42725,42726]
===
match
---
name: jinja_env [20011,20020]
name: jinja_env [20042,20051]
===
match
---
string: '2' [48228,48231]
string: '2' [48259,48262]
===
match
---
name: dag [49366,49369]
name: dag [49397,49400]
===
match
---
trailer [55088,55093]
trailer [55119,55124]
===
match
---
trailer [21745,21760]
trailer [21776,21791]
===
match
---
atom_expr [10158,10177]
atom_expr [10189,10208]
===
match
---
name: _occur_before [3552,3565]
name: _occur_before [3583,3596]
===
match
---
trailer [53208,53270]
trailer [53239,53301]
===
match
---
name: utils [2094,2099]
name: utils [2125,2130]
===
match
---
atom_expr [8328,8360]
atom_expr [8359,8391]
===
match
---
string: 'a.py' [69647,69653]
string: 'a.py' [71271,71277]
===
match
---
trailer [8904,8918]
trailer [8935,8949]
===
match
---
string: 'owner1' [13677,13685]
string: 'owner1' [13708,13716]
===
match
---
funcdef [54342,55032]
funcdef [54373,55063]
===
match
---
name: TEST_DATE [25749,25758]
name: TEST_DATE [25780,25789]
===
match
---
funcdef [2818,3018]
funcdef [2849,3049]
===
match
---
argument [16385,16407]
argument [16416,16438]
===
match
---
name: child_dag_name [64610,64624]
name: child_dag_name [66234,66248]
===
match
---
operator: } [13773,13774]
operator: } [13804,13805]
===
match
---
name: prev_task [14134,14143]
name: prev_task [14165,14174]
===
match
---
operator: } [30369,30370]
operator: } [30400,30401]
===
match
---
trailer [76382,76388]
trailer [78006,78012]
===
match
---
arglist [65061,65228]
arglist [66685,66852]
===
match
---
name: DEFAULT_DATE [53900,53912]
name: DEFAULT_DATE [53931,53943]
===
match
---
atom_expr [61748,61770]
atom_expr [61779,61801]
===
match
---
trailer [19552,19559]
trailer [19583,19590]
===
match
---
simple_stmt [6107,6176]
simple_stmt [6138,6207]
===
match
---
argument [67319,67342]
argument [68943,68966]
===
match
---
operator: , [30590,30591]
operator: , [30621,30622]
===
match
---
string: """Test that checks you can set dag_id from decorator.""" [71385,71442]
string: """Test that checks you can set dag_id from decorator.""" [73009,73066]
===
match
---
argument [54767,54782]
argument [54798,54813]
===
match
---
trailer [68519,68535]
trailer [70143,70159]
===
match
---
name: dag_run [43212,43219]
name: dag_run [43243,43250]
===
match
---
dictorsetmaker [30408,30591]
dictorsetmaker [30439,30622]
===
match
---
operator: = [7175,7176]
operator: = [7206,7207]
===
match
---
param [25353,25357]
param [25384,25388]
===
match
---
string: "test_create_dagrun_job_id_is_set" [51314,51348]
string: "test_create_dagrun_job_id_is_set" [51345,51379]
===
match
---
name: start [26476,26481]
name: start [26507,26512]
===
match
---
with_item [45174,45201]
with_item [45205,45232]
===
match
---
assert_stmt [5789,5865]
assert_stmt [5820,5896]
===
match
---
simple_stmt [36495,36558]
simple_stmt [36526,36589]
===
match
---
expr_stmt [56167,56228]
expr_stmt [56198,56259]
===
match
---
assert_stmt [7952,7973]
assert_stmt [7983,8004]
===
match
---
simple_stmt [34216,34300]
simple_stmt [34247,34331]
===
match
---
atom_expr [36839,36856]
atom_expr [36870,36887]
===
match
---
factor [58688,58690]
factor [58719,58721]
===
match
---
name: TI [57047,57049]
name: TI [57078,57080]
===
match
---
trailer [78462,78471]
trailer [80086,80095]
===
match
---
argument [17793,17820]
argument [17824,17851]
===
match
---
atom_expr [27558,27587]
atom_expr [27589,27618]
===
match
---
name: dag [45144,45147]
name: dag [45175,45178]
===
match
---
name: dag [50913,50916]
name: dag [50944,50947]
===
match
---
simple_stmt [21574,21615]
simple_stmt [21605,21646]
===
match
---
name: dr [31487,31489]
name: dr [31518,31520]
===
match
---
argument [52461,52467]
argument [52492,52498]
===
match
---
param [47410,47414]
param [47441,47445]
===
match
---
param [64626,64630]
param [66250,66254]
===
match
---
atom_expr [48818,48836]
atom_expr [48849,48867]
===
match
---
trailer [76550,76557]
trailer [78174,78181]
===
match
---
operator: = [37566,37567]
operator: = [37597,37598]
===
match
---
decorator [72288,72335]
decorator [73912,73959]
===
match
---
operator: } [4724,4725]
operator: } [4755,4756]
===
match
---
trailer [70435,70438]
trailer [72059,72062]
===
match
---
funcdef [36439,36881]
funcdef [36470,36912]
===
match
---
name: start_date [58994,59004]
name: start_date [59025,59035]
===
match
---
name: jinja_udf [19688,19697]
name: jinja_udf [19719,19728]
===
match
---
expr_stmt [45215,45265]
expr_stmt [45246,45296]
===
match
---
operator: == [62814,62816]
operator: == [62845,62847]
===
match
---
comparison [9900,9928]
comparison [9931,9959]
===
match
---
name: PRE_TRANSITION [23403,23417]
name: PRE_TRANSITION [23434,23448]
===
match
---
trailer [65799,65816]
trailer [67423,67440]
===
match
---
name: DagModel [34778,34786]
name: DagModel [34809,34817]
===
match
---
name: task_id [16336,16343]
name: task_id [16367,16374]
===
match
---
string: 'tag-2' [27891,27898]
string: 'tag-2' [27922,27929]
===
match
---
argument [56793,56816]
argument [56824,56847]
===
match
---
atom_expr [49291,49310]
atom_expr [49322,49341]
===
match
---
operator: , [52156,52157]
operator: , [52187,52188]
===
match
---
trailer [50291,50319]
trailer [50322,50350]
===
match
---
name: row [30679,30682]
name: row [30710,30713]
===
match
---
name: op2 [41734,41737]
name: op2 [41765,41768]
===
match
---
arglist [36236,36278]
arglist [36267,36309]
===
match
---
operator: { [77563,77564]
operator: { [79187,79188]
===
match
---
name: convert [24713,24720]
name: convert [24744,24751]
===
match
---
name: start [23324,23329]
name: start [23355,23360]
===
match
---
operator: = [35376,35377]
operator: = [35407,35408]
===
match
---
name: partial_subset [42106,42120]
name: partial_subset [42137,42151]
===
match
---
operator: = [43589,43590]
operator: = [43620,43621]
===
match
---
atom_expr [65207,65227]
atom_expr [66831,66851]
===
match
---
string: 'dag-bulk-sync-1' [29676,29693]
string: 'dag-bulk-sync-1' [29707,29724]
===
match
---
name: session [33897,33904]
name: session [33928,33935]
===
match
---
trailer [24539,24554]
trailer [24570,24585]
===
match
---
name: VALUE [73989,73994]
name: VALUE [75613,75618]
===
match
---
name: DAG [32223,32226]
name: DAG [32254,32257]
===
match
---
string: 'test_subdag' [52996,53009]
string: 'test_subdag' [53027,53040]
===
match
---
string: 'Invalid values of dag.default_view: only support' [5444,5494]
string: 'Invalid values of dag.default_view: only support' [5475,5525]
===
match
---
simple_stmt [74517,74755]
simple_stmt [76141,76379]
===
match
---
atom [55082,55095]
atom [55113,55126]
===
match
---
name: i [15242,15243]
name: i [15273,15274]
===
match
---
name: get_dagmodel [35691,35703]
name: get_dagmodel [35722,35734]
===
match
---
name: DAG [21633,21636]
name: DAG [21664,21667]
===
match
---
name: outdated_permissions [66704,66724]
name: outdated_permissions [68328,68348]
===
match
---
trailer [46079,46090]
trailer [46110,46121]
===
match
---
assert_stmt [72659,72713]
assert_stmt [74283,74337]
===
match
---
name: models [5509,5515]
name: models [5540,5546]
===
match
---
simple_stmt [65602,65626]
simple_stmt [67226,67250]
===
match
---
string: 'Europe/Zurich' [38353,38368]
string: 'Europe/Zurich' [38384,38399]
===
match
---
operator: = [17698,17699]
operator: = [17729,17730]
===
match
---
operator: { [16205,16206]
operator: { [16236,16237]
===
match
---
operator: = [17675,17676]
operator: = [17706,17707]
===
match
---
string: 'dummy' [78866,78873]
string: 'dummy' [80490,80497]
===
match
---
string: 'test_scheduler_dagrun_once' [57362,57390]
string: 'test_scheduler_dagrun_once' [57393,57421]
===
match
---
expr_stmt [52987,53009]
expr_stmt [53018,53040]
===
match
---
operator: , [50233,50234]
operator: , [50264,50265]
===
match
---
argument [18454,18471]
argument [18485,18502]
===
match
---
operator: { [66121,66122]
operator: { [67745,67746]
===
match
---
name: all [29470,29473]
name: all [29501,29504]
===
match
---
name: timezone [62446,62454]
name: timezone [62477,62485]
===
match
---
name: isoformat [25892,25901]
name: isoformat [25923,25932]
===
match
---
argument [65158,65175]
argument [66782,66799]
===
match
---
name: convert [22234,22241]
name: convert [22265,22272]
===
match
---
name: DagRun [3270,3276]
name: DagRun [3301,3307]
===
match
---
trailer [42849,42857]
trailer [42880,42888]
===
match
---
expr_stmt [4591,4618]
expr_stmt [4622,4649]
===
match
---
expr_stmt [52631,52812]
expr_stmt [52662,52843]
===
match
---
name: run_type [50696,50704]
name: run_type [50727,50735]
===
match
---
shift_expr [39060,39091]
shift_expr [39091,39122]
===
match
---
trailer [65674,65680]
trailer [67298,67304]
===
match
---
import_from [1640,1691]
import_from [1646,1697]
===
match
---
name: execution_date [53987,54001]
name: execution_date [54018,54032]
===
match
---
atom_expr [75298,75315]
atom_expr [76922,76939]
===
match
---
name: State [77296,77301]
name: State [78920,78925]
===
match
---
name: dagrun_1 [51972,51980]
name: dagrun_1 [52003,52011]
===
match
---
testlist_star_expr [54452,54463]
testlist_star_expr [54483,54494]
===
match
---
name: section_1 [65444,65453]
name: section_1 [67068,67077]
===
match
---
atom_expr [45174,45190]
atom_expr [45205,45221]
===
match
---
simple_stmt [70905,70916]
simple_stmt [72529,72540]
===
match
---
atom_expr [50979,51036]
atom_expr [51010,51067]
===
match
---
operator: } [43177,43178]
operator: } [43208,43209]
===
match
---
operator: , [23492,23493]
operator: , [23523,23524]
===
match
---
trailer [25158,25166]
trailer [25189,25197]
===
match
---
trailer [44958,44972]
trailer [44989,45003]
===
match
---
arglist [58098,58178]
arglist [58129,58209]
===
match
---
string: """Test that dag param is correctly resolved by operator""" [73246,73305]
string: """Test that dag param is correctly resolved by operator""" [74870,74929]
===
match
---
name: interval [78309,78317]
name: interval [79933,79941]
===
match
---
argument [38942,38954]
argument [38973,38985]
===
match
---
operator: @ [71952,71953]
operator: @ [73576,73577]
===
match
---
string: """             Regular DAG documentation             """ [72376,72433]
string: """             Regular DAG documentation             """ [74000,74057]
===
match
---
atom_expr [41665,41676]
atom_expr [41696,41707]
===
match
---
name: session [68480,68487]
name: session [70104,70111]
===
match
---
name: default_args [75061,75073]
name: default_args [76685,76697]
===
match
---
atom [48273,48334]
atom [48304,48365]
===
match
---
name: include_subdags [54696,54711]
name: include_subdags [54727,54742]
===
match
---
string: 'dag__dot__subtask' [33256,33275]
string: 'dag__dot__subtask' [33287,33306]
===
match
---
suite [22074,23111]
suite [22105,23142]
===
match
---
string: "2018-10-27T01:00:00+00:00" [24181,24208]
string: "2018-10-27T01:00:00+00:00" [24212,24239]
===
match
---
operator: == [25793,25795]
operator: == [25824,25826]
===
match
---
param [51679,51684]
param [51710,51715]
===
match
---
suite [24279,25306]
suite [24310,25337]
===
match
---
operator: == [55724,55726]
operator: == [55755,55757]
===
match
---
simple_stmt [42716,42869]
simple_stmt [42747,42900]
===
match
---
trailer [22626,22633]
trailer [22657,22664]
===
match
---
operator: } [35233,35234]
operator: } [35264,35265]
===
match
---
trailer [46105,46119]
trailer [46136,46150]
===
match
---
param [67294,67298]
param [68918,68922]
===
match
---
name: sync_to_db [49522,49532]
name: sync_to_db [49553,49563]
===
match
---
name: state [77287,77292]
name: state [78911,78916]
===
match
---
atom_expr [61554,61583]
atom_expr [61585,61614]
===
match
---
atom_expr [70415,70438]
atom_expr [72039,72062]
===
match
---
trailer [28082,28084]
trailer [28113,28115]
===
match
---
trailer [64722,64878]
trailer [66346,66502]
===
match
---
name: noop_pipeline [71163,71176]
name: noop_pipeline [72787,72800]
===
match
---
operator: = [40671,40672]
operator: = [40702,40703]
===
match
---
suite [19675,20133]
suite [19706,20164]
===
match
---
name: local_tz [24926,24934]
name: local_tz [24957,24965]
===
match
---
trailer [3269,3294]
trailer [3300,3325]
===
match
---
argument [19803,19826]
argument [19834,19857]
===
match
---
parameters [64592,64631]
parameters [66216,66255]
===
match
---
simple_stmt [45934,46024]
simple_stmt [45965,46055]
===
match
---
name: dag_id [51709,51715]
name: dag_id [51740,51746]
===
match
---
number: 0 [4192,4193]
number: 0 [4223,4224]
===
match
---
operator: } [30279,30280]
operator: } [30310,30311]
===
match
---
operator: + [78540,78541]
operator: + [80164,80165]
===
match
---
operator: , [68960,68961]
operator: , [70584,70585]
===
match
---
name: next_info [62856,62865]
name: next_info [62887,62896]
===
match
---
operator: = [54085,54086]
operator: = [54116,54117]
===
match
---
name: run_type [53776,53784]
name: run_type [53807,53815]
===
match
---
simple_stmt [14716,14727]
simple_stmt [14747,14758]
===
match
---
trailer [55115,55123]
trailer [55146,55154]
===
match
---
operator: = [76759,76760]
operator: = [78383,78384]
===
match
---
name: os [69612,69614]
name: os [71236,71238]
===
match
---
comparison [43195,43225]
comparison [43226,43256]
===
match
---
operator: , [60843,60844]
operator: , [60874,60875]
===
match
---
name: DagRun [54899,54905]
name: DagRun [54930,54936]
===
match
---
operator: = [3849,3850]
operator: = [3880,3881]
===
match
---
number: 1 [65174,65175]
number: 1 [66798,66799]
===
match
---
simple_stmt [31404,31478]
simple_stmt [31435,31509]
===
match
---
trailer [58551,58565]
trailer [58582,58596]
===
match
---
number: 2 [22274,22275]
number: 2 [22305,22306]
===
match
---
expr_stmt [36566,36594]
expr_stmt [36597,36625]
===
match
---
param [43406,43416]
param [43437,43447]
===
match
---
name: include_upstream [42127,42143]
name: include_upstream [42158,42174]
===
match
---
trailer [15673,15689]
trailer [15704,15720]
===
match
---
arglist [12877,12924]
arglist [12908,12955]
===
match
---
testlist_star_expr [55261,55272]
testlist_star_expr [55292,55303]
===
match
---
name: row [29432,29435]
name: row [29463,29466]
===
match
---
operator: = [3692,3693]
operator: = [3723,3724]
===
match
---
name: task_id [10578,10585]
name: task_id [10609,10616]
===
match
---
operator: , [25684,25685]
operator: , [25715,25716]
===
match
---
name: utils [2248,2253]
name: utils [2279,2284]
===
match
---
name: add [36991,36994]
name: add [37022,37025]
===
match
---
name: filter [52721,52727]
name: filter [52752,52758]
===
match
---
atom [35891,35910]
atom [35922,35941]
===
match
---
argument [52129,52156]
argument [52160,52187]
===
match
---
operator: , [77728,77729]
operator: , [79352,79353]
===
match
---
trailer [77422,77439]
trailer [79046,79063]
===
match
---
operator: , [78077,78078]
operator: , [79701,79702]
===
match
---
operator: = [53639,53640]
operator: = [53670,53671]
===
match
---
expr_stmt [59764,59819]
expr_stmt [59795,59850]
===
match
---
name: dag [68950,68953]
name: dag [70574,70577]
===
match
---
operator: @ [61156,61157]
operator: @ [61187,61188]
===
match
---
operator: = [59406,59407]
operator: = [59437,59438]
===
match
---
param [27677,27681]
param [27708,27712]
===
match
---
funcdef [27332,27398]
funcdef [27363,27429]
===
match
---
operator: = [31528,31529]
operator: = [31559,31560]
===
match
---
operator: = [44697,44698]
operator: = [44728,44729]
===
match
---
string: 'child_dag' [8687,8698]
string: 'child_dag' [8718,8729]
===
match
---
simple_stmt [27047,27091]
simple_stmt [27078,27122]
===
match
---
operator: = [20944,20945]
operator: = [20975,20976]
===
match
---
operator: = [57489,57490]
operator: = [57520,57521]
===
match
---
name: dag_id [51307,51313]
name: dag_id [51338,51344]
===
match
---
name: fileloc [69858,69865]
name: fileloc [71482,71489]
===
match
---
atom_expr [56744,56760]
atom_expr [56775,56791]
===
match
---
expr_stmt [35364,35564]
expr_stmt [35395,35595]
===
match
---
trailer [50447,50510]
trailer [50478,50541]
===
match
---
name: self [74419,74423]
name: self [76043,76047]
===
match
---
name: jinja_env [20613,20622]
name: jinja_env [20644,20653]
===
match
---
name: dag_id [35987,35993]
name: dag_id [36018,36024]
===
match
---
trailer [73555,73564]
trailer [75179,75188]
===
match
---
operator: = [71891,71892]
operator: = [73515,73516]
===
match
---
trailer [58213,58254]
trailer [58244,58285]
===
match
---
name: num [71591,71594]
name: num [73215,73218]
===
match
---
name: dag [36129,36132]
name: dag [36160,36163]
===
match
---
operator: = [56877,56878]
operator: = [56908,56909]
===
match
---
atom_expr [28810,28856]
atom_expr [28841,28887]
===
match
---
argument [51019,51035]
argument [51050,51066]
===
match
---
operator: = [27774,27775]
operator: = [27805,27806]
===
match
---
assert_stmt [77257,77306]
assert_stmt [78881,78930]
===
match
---
operator: , [56530,56531]
operator: , [56561,56562]
===
match
---
comparison [26284,26331]
comparison [26315,26362]
===
match
---
atom_expr [18493,18505]
atom_expr [18524,18536]
===
match
---
name: following_schedule [22565,22583]
name: following_schedule [22596,22614]
===
match
---
atom [4706,4725]
atom [4737,4756]
===
match
---
name: name [38537,38541]
name: name [38568,38572]
===
match
---
name: session [19151,19158]
name: session [19182,19189]
===
match
---
operator: = [75573,75574]
operator: = [77197,77198]
===
match
---
atom_expr [23607,23629]
atom_expr [23638,23660]
===
match
---
name: start [3010,3015]
name: start [3041,3046]
===
match
---
operator: , [68079,68080]
operator: , [69703,69704]
===
match
---
name: orm_dag [32894,32901]
name: orm_dag [32925,32932]
===
match
---
name: topological_list [11251,11267]
name: topological_list [11282,11298]
===
match
---
operator: = [46737,46738]
operator: = [46768,46769]
===
match
---
name: child_dag_name [64952,64966]
name: child_dag_name [66576,66590]
===
match
---
operator: , [2597,2598]
operator: , [2628,2629]
===
match
---
arglist [46957,47140]
arglist [46988,47171]
===
match
---
name: start_date [78966,78976]
name: start_date [80590,80600]
===
match
---
funcdef [23116,24209]
funcdef [23147,24240]
===
match
---
simple_stmt [20343,20390]
simple_stmt [20374,20421]
===
match
---
operator: } [19928,19929]
operator: } [19959,19960]
===
match
---
assert_stmt [7019,7047]
assert_stmt [7050,7078]
===
match
---
suite [3050,3136]
suite [3081,3167]
===
match
---
number: 4 [71648,71649]
number: 4 [73272,73273]
===
match
---
name: session [55578,55585]
name: session [55609,55616]
===
match
---
operator: = [9681,9682]
operator: = [9712,9713]
===
match
---
name: subdag [53196,53202]
name: subdag [53227,53233]
===
match
---
string: "test_schedule_dag_start_end_dates" [58044,58079]
string: "test_schedule_dag_start_end_dates" [58075,58110]
===
match
---
trailer [12637,12650]
trailer [12668,12681]
===
match
---
name: include_parentdag [54730,54747]
name: include_parentdag [54761,54778]
===
match
---
atom_expr [25841,25870]
atom_expr [25872,25901]
===
match
---
name: re [860,862]
name: re [860,862]
===
match
---
name: orm_dag [37901,37908]
name: orm_dag [37932,37939]
===
match
---
parameters [22067,22073]
parameters [22098,22104]
===
match
---
name: op4 [7310,7313]
name: op4 [7341,7344]
===
match
---
name: dag [71253,71256]
name: dag [72877,72880]
===
match
---
trailer [31971,31996]
trailer [32002,32027]
===
match
---
operator: == [76896,76898]
operator: == [78520,78522]
===
match
---
atom_expr [76852,76874]
atom_expr [78476,78498]
===
match
---
atom_expr [31332,31342]
atom_expr [31363,31373]
===
match
---
name: self [46576,46580]
name: self [46607,46611]
===
match
---
name: conf [5796,5800]
name: conf [5827,5831]
===
match
---
trailer [48830,48836]
trailer [48861,48867]
===
match
---
atom_expr [14067,14082]
atom_expr [14098,14113]
===
match
---
trailer [20896,20901]
trailer [20927,20932]
===
match
---
name: child_dag [8707,8716]
name: child_dag [8738,8747]
===
match
---
atom_expr [62344,62561]
atom_expr [62375,62592]
===
match
---
operator: , [3567,3568]
operator: , [3598,3599]
===
match
---
name: setUp [69972,69977]
name: setUp [71596,71601]
===
match
---
trailer [65657,65674]
trailer [67281,67298]
===
match
---
expr_stmt [3684,3696]
expr_stmt [3715,3727]
===
match
---
trailer [31218,31220]
trailer [31249,31251]
===
match
---
name: timezone [70871,70879]
name: timezone [72495,72503]
===
match
---
number: 3 [23381,23382]
number: 3 [23412,23413]
===
match
---
name: timezone [65729,65737]
name: timezone [67353,67361]
===
match
---
assert_stmt [48998,49033]
assert_stmt [49029,49064]
===
match
---
simple_stmt [63971,64152]
simple_stmt [65595,65776]
===
match
---
operator: = [57174,57175]
operator: = [57205,57206]
===
match
---
trailer [31330,31345]
trailer [31361,31376]
===
match
---
simple_stmt [34183,34208]
simple_stmt [34214,34239]
===
match
---
name: is_subdag [65609,65618]
name: is_subdag [67233,67242]
===
match
---
name: State [77510,77515]
name: State [79134,79139]
===
match
---
name: expand [70094,70100]
name: expand [71718,71724]
===
match
---
name: dag_id [76202,76208]
name: dag_id [77826,77832]
===
match
---
operator: = [74215,74216]
operator: = [75839,75840]
===
match
---
simple_stmt [7056,7079]
simple_stmt [7087,7110]
===
match
---
operator: = [7936,7937]
operator: = [7967,7968]
===
match
---
testlist_comp [69611,69720]
testlist_comp [71235,71344]
===
match
---
name: task_id [41669,41676]
name: task_id [41700,41707]
===
match
---
atom_expr [20910,20916]
atom_expr [20941,20947]
===
match
---
atom_expr [49518,49534]
atom_expr [49549,49565]
===
match
---
trailer [52000,52167]
trailer [52031,52198]
===
match
---
atom_expr [45076,45089]
atom_expr [45107,45120]
===
match
---
name: dag_id [58098,58104]
name: dag_id [58129,58135]
===
match
---
trailer [56974,57009]
trailer [57005,57040]
===
match
---
atom [28683,28714]
atom [28714,28745]
===
match
---
name: default_args [48150,48162]
name: default_args [48181,48193]
===
match
---
name: is_subdag [34738,34747]
name: is_subdag [34769,34778]
===
match
---
operator: , [39734,39735]
operator: , [39765,39766]
===
match
---
operator: = [52065,52066]
operator: = [52096,52097]
===
match
---
operator: == [22668,22670]
operator: == [22699,22701]
===
match
---
testlist_comp [28101,28191]
testlist_comp [28132,28222]
===
match
---
atom [21197,21212]
atom [21228,21243]
===
match
---
dictorsetmaker [6751,6768]
dictorsetmaker [6782,6799]
===
match
---
name: _make_test_subdag [52945,52962]
name: _make_test_subdag [52976,52993]
===
match
---
fstring_end: ' [28124,28125]
fstring_end: ' [28155,28156]
===
match
---
argument [51455,51477]
argument [51486,51508]
===
match
---
trailer [53507,53515]
trailer [53538,53546]
===
match
---
decorated [62059,63249]
decorated [62090,63280]
===
match
---
name: DagRunType [76062,76072]
name: DagRunType [77686,77696]
===
match
---
atom_expr [26240,26268]
atom_expr [26271,26299]
===
match
---
name: timezone [74608,74616]
name: timezone [76232,76240]
===
match
---
name: dags_needing_dagruns [69396,69416]
name: dags_needing_dagruns [71020,71040]
===
match
---
trailer [35455,35462]
trailer [35486,35493]
===
match
---
name: self [39647,39651]
name: self [39678,39682]
===
match
---
name: settings [51945,51953]
name: settings [51976,51984]
===
match
---
simple_stmt [69349,69365]
simple_stmt [70973,70989]
===
match
---
trailer [35707,35714]
trailer [35738,35745]
===
match
---
name: ti [73919,73921]
name: ti [75543,75545]
===
match
---
string: "2018-03-25T05:30:00+00:00" [27623,27650]
string: "2018-03-25T05:30:00+00:00" [27654,27681]
===
match
---
trailer [36431,36433]
trailer [36462,36464]
===
match
---
simple_stmt [4664,4743]
simple_stmt [4695,4774]
===
match
---
name: datetime [18075,18083]
name: datetime [18106,18114]
===
match
---
atom_expr [50052,50079]
atom_expr [50083,50110]
===
match
---
operator: , [36248,36249]
operator: , [36279,36280]
===
match
---
assert_stmt [60735,60771]
assert_stmt [60766,60802]
===
match
---
expr_stmt [60318,60511]
expr_stmt [60349,60542]
===
match
---
funcdef [4218,4874]
funcdef [4249,4905]
===
match
---
simple_stmt [31806,31867]
simple_stmt [31837,31898]
===
match
---
name: DAG [6335,6338]
name: DAG [6366,6369]
===
match
---
argument [65061,65090]
argument [66685,66714]
===
match
---
operator: - [14402,14403]
operator: - [14433,14434]
===
match
---
name: timedelta [27119,27128]
name: timedelta [27150,27159]
===
match
---
name: dag [11488,11491]
name: dag [11519,11522]
===
match
---
name: session [2759,2766]
name: session [2790,2797]
===
match
---
trailer [35488,35495]
trailer [35519,35526]
===
match
---
name: merge [52184,52189]
name: merge [52215,52220]
===
match
---
trailer [50011,50024]
trailer [50042,50055]
===
match
---
atom_expr [75252,75269]
atom_expr [76876,76893]
===
match
---
operator: = [52391,52392]
operator: = [52422,52423]
===
match
---
operator: , [60107,60108]
operator: , [60138,60139]
===
match
---
decorated [69521,69924]
decorated [71145,71548]
===
match
---
suite [10227,11322]
suite [10258,11353]
===
match
---
string: 'new_nonexisting_dag' [36704,36725]
string: 'new_nonexisting_dag' [36735,36756]
===
match
---
comparison [7439,7453]
comparison [7470,7484]
===
match
---
operator: { [50809,50810]
operator: { [50840,50841]
===
match
---
argument [68266,68283]
argument [69890,69907]
===
match
---
expr_stmt [13327,13337]
expr_stmt [13358,13368]
===
match
---
trailer [10757,10770]
trailer [10788,10801]
===
match
---
string: 'child_dag' [8931,8942]
string: 'child_dag' [8962,8973]
===
match
---
assert_stmt [62922,62998]
assert_stmt [62953,63029]
===
match
---
number: 3 [10175,10176]
number: 3 [10206,10207]
===
match
---
testlist_star_expr [60980,60992]
testlist_star_expr [61011,61023]
===
match
---
comparison [3270,3293]
comparison [3301,3324]
===
match
---
number: 1 [57427,57428]
number: 1 [57458,57459]
===
match
---
operator: , [18821,18822]
operator: , [18852,18853]
===
match
---
simple_stmt [55013,55032]
simple_stmt [55044,55063]
===
match
---
name: settings [37635,37643]
name: settings [37666,37674]
===
match
---
string: 't2' [41985,41989]
string: 't2' [42016,42020]
===
match
---
name: dag [61692,61695]
name: dag [61723,61726]
===
match
---
name: execution_date [43076,43090]
name: execution_date [43107,43121]
===
match
---
operator: = [68919,68920]
operator: = [70543,70544]
===
match
---
operator: { [20241,20242]
operator: { [20272,20273]
===
match
---
argument [18837,18852]
argument [18868,18883]
===
match
---
trailer [38048,38058]
trailer [38079,38089]
===
match
---
atom_expr [49225,49234]
atom_expr [49256,49265]
===
match
---
operator: == [51199,51201]
operator: == [51230,51232]
===
match
---
trailer [29053,29056]
trailer [29084,29087]
===
match
---
operator: = [32285,32286]
operator: = [32316,32317]
===
match
---
name: dag_run_state [54655,54668]
name: dag_run_state [54686,54699]
===
match
---
trailer [43937,43946]
trailer [43968,43977]
===
match
---
name: VALUE [75392,75397]
name: VALUE [77016,77021]
===
match
---
simple_stmt [22643,22699]
simple_stmt [22674,22730]
===
match
---
name: DAG [32055,32058]
name: DAG [32086,32089]
===
match
---
name: DAG [11396,11399]
name: DAG [11427,11430]
===
match
---
operator: = [23279,23280]
operator: = [23310,23311]
===
match
---
string: "graph" [34075,34082]
string: "graph" [34106,34113]
===
match
---
name: _occur_before [9209,9222]
name: _occur_before [9240,9253]
===
match
---
atom_expr [76009,76083]
atom_expr [77633,77707]
===
match
---
trailer [23298,23315]
trailer [23329,23346]
===
match
---
name: op3 [41525,41528]
name: op3 [41556,41559]
===
match
---
name: task_4 [75853,75859]
name: task_4 [77477,77483]
===
match
---
string: 'dag-bulk-sync-2' [28371,28388]
string: 'dag-bulk-sync-2' [28402,28419]
===
match
---
assert_stmt [57526,57602]
assert_stmt [57557,57633]
===
match
---
name: dag [12867,12870]
name: dag [12898,12901]
===
match
---
operator: = [63608,63609]
operator: = [65232,65233]
===
match
---
parameters [69977,69983]
parameters [71601,71607]
===
match
---
name: op1 [41192,41195]
name: op1 [41223,41226]
===
match
---
trailer [21540,21545]
trailer [21571,21576]
===
match
---
operator: == [55796,55798]
operator: == [55827,55829]
===
match
---
expr_stmt [65635,65680]
expr_stmt [67259,67304]
===
match
---
string: 'test_clear_set_dagrun_state' [51718,51747]
string: 'test_clear_set_dagrun_state' [51749,51778]
===
match
---
param [33391,33395]
param [33422,33426]
===
match
---
argument [33485,33505]
argument [33516,33536]
===
match
---
operator: = [8734,8735]
operator: = [8765,8766]
===
match
---
trailer [31762,31768]
trailer [31793,31799]
===
match
---
name: template_file [20930,20943]
name: template_file [20961,20974]
===
match
---
name: airflow [2136,2143]
name: airflow [2167,2174]
===
match
---
name: dag [66740,66743]
name: dag [68364,68367]
===
match
---
operator: = [77895,77896]
operator: = [79519,79520]
===
match
---
atom_expr [59440,59476]
atom_expr [59471,59507]
===
match
---
name: default_view [34011,34023]
name: default_view [34042,34054]
===
match
---
simple_stmt [73246,73306]
simple_stmt [74870,74930]
===
match
---
atom_expr [32503,32567]
atom_expr [32534,32598]
===
match
---
param [73231,73235]
param [74855,74859]
===
match
---
name: subdag [65340,65346]
name: subdag [66964,66970]
===
match
---
trailer [72320,72333]
trailer [73944,73957]
===
match
---
parameters [52962,52977]
parameters [52993,53008]
===
match
---
trailer [4680,4742]
trailer [4711,4773]
===
match
---
atom_expr [30156,30172]
atom_expr [30187,30203]
===
match
---
name: op2 [39136,39139]
name: op2 [39167,39170]
===
match
---
trailer [12623,12630]
trailer [12654,12661]
===
match
---
operator: , [64087,64088]
operator: , [65711,65712]
===
match
---
name: DagRunType [53785,53795]
name: DagRunType [53816,53826]
===
match
---
name: ti4 [18514,18517]
name: ti4 [18545,18548]
===
match
---
simple_stmt [17508,17556]
simple_stmt [17539,17587]
===
match
---
number: 5 [62096,62097]
number: 5 [62127,62128]
===
match
---
name: io [39971,39973]
name: io [40002,40004]
===
match
---
operator: , [66098,66099]
operator: , [67722,67723]
===
match
---
argument [28152,28169]
argument [28183,28200]
===
match
---
string: 'parameter2' [4832,4844]
string: 'parameter2' [4863,4875]
===
match
---
atom_expr [58094,58179]
atom_expr [58125,58210]
===
match
---
atom_expr [67355,67384]
atom_expr [68979,69008]
===
match
---
atom_expr [38471,38508]
atom_expr [38502,38539]
===
match
---
atom_expr [21272,21301]
atom_expr [21303,21332]
===
match
---
name: job_id [51471,51477]
name: job_id [51502,51508]
===
match
---
name: task_id [41157,41164]
name: task_id [41188,41195]
===
match
---
number: 1 [54639,54640]
number: 1 [54670,54671]
===
match
---
name: schedule_interval [50474,50491]
name: schedule_interval [50505,50522]
===
match
---
atom_expr [41219,41232]
atom_expr [41250,41263]
===
match
---
name: set [35238,35241]
name: set [35269,35272]
===
match
---
operator: = [24654,24655]
operator: = [24685,24686]
===
match
---
argument [38438,38453]
argument [38469,38484]
===
match
---
simple_stmt [68505,68548]
simple_stmt [70129,70172]
===
match
---
simple_stmt [76360,76404]
simple_stmt [77984,78028]
===
match
---
name: DEFAULT_DATE [56624,56636]
name: DEFAULT_DATE [56655,56667]
===
match
---
number: 2016 [64073,64077]
number: 2016 [65697,65701]
===
match
---
atom_expr [49902,49917]
atom_expr [49933,49948]
===
match
---
trailer [30333,30350]
trailer [30364,30381]
===
match
---
trailer [19183,19206]
trailer [19214,19237]
===
match
---
trailer [29073,29090]
trailer [29104,29121]
===
match
---
simple_stmt [42877,42904]
simple_stmt [42908,42935]
===
match
---
simple_stmt [24154,24209]
simple_stmt [24185,24240]
===
match
---
name: self [46520,46524]
name: self [46551,46555]
===
match
---
trailer [37849,37851]
trailer [37880,37882]
===
match
---
simple_stmt [48040,48101]
simple_stmt [48071,48132]
===
match
---
operator: , [70777,70778]
operator: , [72401,72402]
===
match
---
operator: = [45822,45823]
operator: = [45853,45854]
===
match
---
dictorsetmaker [27921,28008]
dictorsetmaker [27952,28039]
===
match
---
name: days [56873,56877]
name: days [56904,56908]
===
match
---
simple_stmt [53430,53454]
simple_stmt [53461,53485]
===
match
---
name: dag [36288,36291]
name: dag [36319,36322]
===
match
---
parameters [57323,57329]
parameters [57354,57360]
===
match
---
operator: } [41699,41700]
operator: } [41730,41731]
===
match
---
name: mark [69529,69533]
name: mark [71153,71157]
===
match
---
argument [38988,39000]
argument [39019,39031]
===
match
---
atom_expr [38627,38644]
atom_expr [38658,38675]
===
match
---
atom_expr [66740,66758]
atom_expr [68364,68382]
===
match
---
name: self [50898,50902]
name: self [50929,50933]
===
match
---
name: is_active [68417,68426]
name: is_active [70041,70050]
===
match
---
operator: { [11592,11593]
operator: { [11623,11624]
===
match
---
name: State [44102,44107]
name: State [44133,44138]
===
match
---
simple_stmt [21272,21302]
simple_stmt [21303,21333]
===
match
---
trailer [55863,55868]
trailer [55894,55899]
===
match
---
operator: = [41141,41142]
operator: = [41172,41173]
===
match
---
argument [64191,64198]
argument [65815,65822]
===
match
---
operator: = [5732,5733]
operator: = [5763,5764]
===
match
---
name: next_info [57645,57654]
name: next_info [57676,57685]
===
match
---
trailer [25199,25209]
trailer [25230,25240]
===
match
---
argument [67747,67761]
argument [69371,69385]
===
match
---
arglist [41157,41178]
arglist [41188,41209]
===
match
---
trailer [27561,27580]
trailer [27592,27611]
===
match
---
name: state [53816,53821]
name: state [53847,53852]
===
match
---
name: dst_rule [23385,23393]
name: dst_rule [23416,23424]
===
match
---
operator: == [33253,33255]
operator: == [33284,33286]
===
match
---
expr_stmt [48040,48100]
expr_stmt [48071,48131]
===
match
---
operator: == [76251,76253]
operator: == [77875,77877]
===
match
---
trailer [22944,22962]
trailer [22975,22993]
===
match
---
testlist_comp [35987,35999]
testlist_comp [36018,36030]
===
match
---
name: dag_id [35708,35714]
name: dag_id [35739,35745]
===
match
---
string: 'webserver' [32927,32938]
string: 'webserver' [32958,32969]
===
match
---
name: self [57324,57328]
name: self [57355,57359]
===
match
---
name: weight [14437,14443]
name: weight [14468,14474]
===
match
---
number: 1 [56878,56879]
number: 1 [56909,56910]
===
match
---
name: _next [22553,22558]
name: _next [22584,22589]
===
match
---
name: dag [25619,25622]
name: dag [25650,25653]
===
match
---
expr_stmt [34183,34207]
expr_stmt [34214,34238]
===
match
---
name: datetime [24447,24455]
name: datetime [24478,24486]
===
match
---
name: op1 [39919,39922]
name: op1 [39950,39953]
===
match
---
argument [18275,18289]
argument [18306,18320]
===
match
---
argument [50474,50509]
argument [50505,50540]
===
match
---
name: interval [58327,58335]
name: interval [58358,58366]
===
match
---
atom [39130,39140]
atom [39161,39171]
===
match
---
operator: , [3570,3571]
operator: , [3601,3602]
===
match
---
name: pendulum [1122,1130]
name: pendulum [1128,1136]
===
match
---
name: session [56550,56557]
name: session [56581,56588]
===
match
---
not_test [38114,38135]
not_test [38145,38166]
===
match
---
atom_expr [55858,55868]
atom_expr [55889,55899]
===
match
---
operator: = [27413,27414]
operator: = [27444,27445]
===
match
---
atom_expr [36942,36958]
atom_expr [36973,36989]
===
match
---
argument [53310,53323]
argument [53341,53354]
===
match
---
operator: , [51453,51454]
operator: , [51484,51485]
===
match
---
trailer [76866,76874]
trailer [78490,78498]
===
match
---
operator: } [16353,16354]
operator: } [16384,16385]
===
match
---
trailer [62898,62912]
trailer [62929,62943]
===
match
---
name: schedule_interval [46746,46763]
name: schedule_interval [46777,46794]
===
match
---
name: _clean_up [57270,57279]
name: _clean_up [57301,57310]
===
match
---
simple_stmt [16832,16869]
simple_stmt [16863,16900]
===
match
---
name: task_instance_1 [56583,56598]
name: task_instance_1 [56614,56629]
===
match
---
trailer [67877,67886]
trailer [69501,69510]
===
match
---
trailer [48797,48802]
trailer [48828,48833]
===
match
---
trailer [31096,31112]
trailer [31127,31143]
===
match
---
name: start [27581,27586]
name: start [27612,27617]
===
match
---
atom [16275,16550]
atom [16306,16581]
===
match
---
name: start_date [47049,47059]
name: start_date [47080,47090]
===
match
---
trailer [9673,9686]
trailer [9704,9717]
===
match
---
param [11553,11557]
param [11584,11588]
===
match
---
name: all [69266,69269]
name: all [70890,70893]
===
match
---
name: dag [62338,62341]
name: dag [62369,62372]
===
match
---
suite [39653,40248]
suite [39684,40279]
===
match
---
atom_expr [4784,4808]
atom_expr [4815,4839]
===
match
---
name: self [54466,54470]
name: self [54497,54501]
===
match
---
comparison [47618,47656]
comparison [47649,47687]
===
match
---
funcdef [75400,77626]
funcdef [77024,79250]
===
match
---
operator: = [22223,22224]
operator: = [22254,22255]
===
match
---
simple_stmt [62338,62562]
simple_stmt [62369,62593]
===
match
---
name: session [38035,38042]
name: session [38066,38073]
===
match
---
name: dag [67309,67312]
name: dag [68933,68936]
===
match
---
atom_expr [65602,65618]
atom_expr [67226,67242]
===
match
---
trailer [68109,68121]
trailer [69733,69745]
===
match
---
argument [69059,69116]
argument [70683,70740]
===
match
---
name: timedelta [78059,78068]
name: timedelta [79683,79692]
===
match
---
operator: = [43987,43988]
operator: = [44018,44019]
===
match
---
parameters [72198,72204]
parameters [73822,73828]
===
match
---
atom_expr [34902,34933]
atom_expr [34933,34964]
===
match
---
name: _make_test_subdag [54471,54488]
name: _make_test_subdag [54502,54519]
===
match
---
name: t_2 [54066,54069]
name: t_2 [54097,54100]
===
match
---
param [16006,16010]
param [16037,16041]
===
match
---
atom_expr [61169,61198]
atom_expr [61200,61229]
===
match
---
simple_stmt [1145,1194]
simple_stmt [1151,1200]
===
match
---
name: session [34091,34098]
name: session [34122,34129]
===
match
---
simple_stmt [15657,15690]
simple_stmt [15688,15721]
===
match
---
trailer [41853,41890]
trailer [41884,41921]
===
match
---
string: "run_type_is_obtained_from_run_id" [50930,50964]
string: "run_type_is_obtained_from_run_id" [50961,50995]
===
match
---
assert_stmt [32735,32797]
assert_stmt [32766,32828]
===
match
---
trailer [2927,2933]
trailer [2958,2964]
===
match
---
comparison [20405,20435]
comparison [20436,20466]
===
match
---
atom [30508,30540]
atom [30539,30571]
===
match
---
simple_stmt [75562,75599]
simple_stmt [77186,77223]
===
match
---
atom_expr [38545,38558]
atom_expr [38576,38589]
===
match
---
argument [43982,43999]
argument [44013,44030]
===
match
---
name: airflow [1984,1991]
name: airflow [2015,2022]
===
match
---
trailer [76982,76987]
trailer [78606,78611]
===
match
---
name: default_view [34059,34071]
name: default_view [34090,34102]
===
match
---
argument [75827,75843]
argument [77451,77467]
===
match
---
name: name [38554,38558]
name: name [38585,38589]
===
match
---
operator: = [73717,73718]
operator: = [75341,75342]
===
match
---
atom_expr [42009,42036]
atom_expr [42040,42067]
===
match
---
operator: == [62966,62968]
operator: == [62997,62999]
===
match
---
trailer [36693,36700]
trailer [36724,36731]
===
match
---
name: name [19698,19702]
name: name [19729,19733]
===
match
---
name: self [72316,72320]
name: self [73940,73944]
===
match
---
trailer [37818,37845]
trailer [37849,37876]
===
match
---
arglist [46807,46868]
arglist [46838,46899]
===
match
---
name: default_args [12519,12531]
name: default_args [12550,12562]
===
match
---
operator: = [14926,14927]
operator: = [14957,14958]
===
match
---
operator: == [29400,29402]
operator: == [29431,29433]
===
match
---
name: test_task [18528,18537]
name: test_task [18559,18568]
===
match
---
simple_stmt [17040,17087]
simple_stmt [17071,17118]
===
match
---
operator: , [48231,48232]
operator: , [48262,48263]
===
match
---
operator: = [78755,78756]
operator: = [80379,80380]
===
match
---
trailer [26135,26144]
trailer [26166,26175]
===
match
---
trailer [35043,35116]
trailer [35074,35147]
===
match
---
operator: = [52269,52270]
operator: = [52300,52301]
===
match
---
simple_stmt [41911,41945]
simple_stmt [41942,41976]
===
match
---
trailer [31252,31269]
trailer [31283,31300]
===
match
---
atom_expr [67507,67772]
atom_expr [69131,69396]
===
match
---
expr_stmt [16133,16142]
expr_stmt [16164,16173]
===
match
---
name: execution_date [50724,50738]
name: execution_date [50755,50769]
===
match
---
operator: = [4599,4600]
operator: = [4630,4631]
===
match
---
operator: , [59350,59351]
operator: , [59381,59382]
===
match
---
string: "test-dag" [30054,30064]
string: "test-dag" [30085,30095]
===
match
---
trailer [30699,30726]
trailer [30730,30757]
===
match
---
parameters [47409,47415]
parameters [47440,47446]
===
match
---
operator: + [14416,14417]
operator: + [14447,14448]
===
match
---
name: _next [25035,25040]
name: _next [25066,25071]
===
match
---
trailer [35552,35554]
trailer [35583,35585]
===
match
---
assert_stmt [31404,31477]
assert_stmt [31435,31508]
===
match
---
simple_stmt [15903,15946]
simple_stmt [15934,15977]
===
match
---
number: 10 [64085,64087]
number: 10 [65709,65711]
===
match
---
name: task_id [7330,7337]
name: task_id [7361,7368]
===
match
---
operator: = [19914,19915]
operator: = [19945,19946]
===
match
---
atom_expr [77488,77506]
atom_expr [79112,79130]
===
match
---
simple_stmt [25833,25871]
simple_stmt [25864,25902]
===
match
---
name: task [21174,21178]
name: task [21205,21209]
===
match
---
name: user_defined_macros [19895,19914]
name: user_defined_macros [19926,19945]
===
match
---
name: test_duplicate_task_ids_not_allowed_with_dag_context_manager [40257,40317]
name: test_duplicate_task_ids_not_allowed_with_dag_context_manager [40288,40348]
===
match
---
trailer [38244,38246]
trailer [38275,38277]
===
match
---
trailer [60796,60970]
trailer [60827,61001]
===
match
---
operator: = [7869,7870]
operator: = [7900,7901]
===
match
---
argument [53252,53269]
argument [53283,53300]
===
match
---
name: task_id [38988,38995]
name: task_id [39019,39026]
===
match
---
simple_stmt [4817,4874]
simple_stmt [4848,4905]
===
match
---
decorated [3530,3891]
decorated [3561,3922]
===
match
---
string: 'owner' [14877,14884]
string: 'owner' [14908,14915]
===
match
---
atom_expr [3750,3759]
atom_expr [3781,3790]
===
match
---
simple_stmt [32976,33012]
simple_stmt [33007,33043]
===
match
---
argument [59413,59420]
argument [59444,59451]
===
match
---
assert_stmt [31355,31395]
assert_stmt [31386,31426]
===
match
---
trailer [68100,68109]
trailer [69724,69733]
===
match
---
arglist [63602,63747]
arglist [65226,65371]
===
match
---
import_from [1789,1838]
import_from [1795,1844]
===
match
---
trailer [2903,2920]
trailer [2934,2951]
===
match
---
atom_expr [10684,10707]
atom_expr [10715,10738]
===
match
---
simple_stmt [20656,20703]
simple_stmt [20687,20734]
===
match
---
name: test_pickling [47396,47409]
name: test_pickling [47427,47440]
===
match
---
string: 'C' [10541,10544]
string: 'C' [10572,10575]
===
match
---
name: session [27938,27945]
name: session [27969,27976]
===
match
---
operator: - [16802,16803]
operator: - [16833,16834]
===
match
---
suite [28980,29020]
suite [29011,29051]
===
match
---
operator: == [41233,41235]
operator: == [41264,41266]
===
match
---
name: dag [47590,47593]
name: dag [47621,47624]
===
match
---
atom_expr [29235,29261]
atom_expr [29266,29292]
===
match
---
assert_stmt [7432,7453]
assert_stmt [7463,7484]
===
match
---
number: 2 [62844,62845]
number: 2 [62875,62876]
===
match
---
simple_stmt [9893,9929]
simple_stmt [9924,9960]
===
match
---
number: 1 [61630,61631]
number: 1 [61661,61662]
===
match
---
atom_expr [30613,30660]
atom_expr [30644,30691]
===
match
---
name: self [43298,43302]
name: self [43329,43333]
===
match
---
argument [6823,6855]
argument [6854,6886]
===
match
---
trailer [46929,46943]
trailer [46960,46974]
===
match
---
trailer [73726,73733]
trailer [75350,75357]
===
match
---
arglist [5520,5578]
arglist [5551,5609]
===
match
---
string: 'start_date' [11593,11605]
string: 'start_date' [11624,11636]
===
match
---
name: QUEUED [19553,19559]
name: QUEUED [19584,19590]
===
match
---
argument [25645,25665]
argument [25676,25696]
===
match
---
argument [65189,65227]
argument [66813,66851]
===
match
---
simple_stmt [14771,14814]
simple_stmt [14802,14845]
===
match
---
name: test_user_defined_filters_macros [19636,19668]
name: test_user_defined_filters_macros [19667,19699]
===
match
---
name: utcnow [74617,74623]
name: utcnow [76241,76247]
===
match
---
string: "t2" [39385,39389]
string: "t2" [39416,39420]
===
match
---
name: all [29970,29973]
name: all [30001,30004]
===
match
---
name: timezone [63219,63227]
name: timezone [63250,63258]
===
match
---
name: dag_id [69821,69827]
name: dag_id [71445,71451]
===
match
---
argument [56274,56281]
argument [56305,56312]
===
match
---
argument [17884,17898]
argument [17915,17929]
===
match
---
name: j [13772,13773]
name: j [13803,13804]
===
match
---
name: local_tz [24704,24712]
name: local_tz [24735,24743]
===
match
---
name: session [69164,69171]
name: session [70788,70795]
===
match
---
argument [70487,70519]
argument [72111,72143]
===
match
---
param [40835,40839]
param [40866,40870]
===
match
---
name: dag [20625,20628]
name: dag [20656,20659]
===
match
---
operator: { [41664,41665]
operator: { [41695,41696]
===
match
---
atom [20241,20290]
atom [20272,20321]
===
match
---
name: isinstance [71697,71707]
name: isinstance [73321,73331]
===
match
---
name: dag_id [58967,58973]
name: dag_id [58998,59004]
===
match
---
operator: = [18433,18434]
operator: = [18464,18465]
===
match
---
trailer [36990,36994]
trailer [37021,37025]
===
match
---
trailer [77889,77898]
trailer [79513,79522]
===
match
---
string: """Test that dag param is correctly overwritten when set in dag run""" [74055,74125]
string: """Test that dag param is correctly overwritten when set in dag run""" [75679,75749]
===
match
---
name: b_index [3841,3848]
name: b_index [3872,3879]
===
match
---
name: task_id [76243,76250]
name: task_id [77867,77874]
===
match
---
name: timedelta [65207,65216]
name: timedelta [66831,66840]
===
match
---
name: commit [56752,56758]
name: commit [56783,56789]
===
match
---
operator: , [19881,19882]
operator: , [19912,19913]
===
match
---
atom_expr [73924,73950]
atom_expr [75548,75574]
===
match
---
arglist [27486,27541]
arglist [27517,27572]
===
match
---
name: dag [23474,23477]
name: dag [23505,23508]
===
match
---
operator: = [59471,59472]
operator: = [59502,59503]
===
match
---
atom_expr [55637,55757]
atom_expr [55668,55788]
===
match
---
expr_stmt [45818,45869]
expr_stmt [45849,45900]
===
match
---
number: 3 [29054,29055]
number: 3 [29085,29086]
===
match
---
trailer [63980,64151]
trailer [65604,65775]
===
match
---
name: dag [6433,6436]
name: dag [6464,6467]
===
match
---
string: 'b_parent' [8758,8768]
string: 'b_parent' [8789,8799]
===
match
---
name: DEFAULT_DATE [52392,52404]
name: DEFAULT_DATE [52423,52435]
===
match
---
name: hours [78373,78378]
name: hours [79997,80002]
===
match
---
trailer [74623,74625]
trailer [76247,76249]
===
match
---
trailer [77089,77095]
trailer [78713,78719]
===
match
---
trailer [22881,22891]
trailer [22912,22922]
===
match
---
name: i [16800,16801]
name: i [16831,16832]
===
match
---
atom_expr [57645,57668]
atom_expr [57676,57699]
===
match
---
trailer [50529,50539]
trailer [50560,50570]
===
match
---
operator: - [77984,77985]
operator: - [79608,79609]
===
match
---
operator: = [66889,66890]
operator: = [68513,68514]
===
match
---
name: unpaused_dags [35242,35255]
name: unpaused_dags [35273,35286]
===
match
---
name: fileloc [33321,33328]
name: fileloc [33352,33359]
===
match
---
string: 'op3' [7176,7181]
string: 'op3' [7207,7212]
===
match
---
simple_stmt [23639,23700]
simple_stmt [23670,23731]
===
match
---
operator: = [11027,11028]
operator: = [11058,11059]
===
match
---
name: io [811,813]
name: io [811,813]
===
match
---
operator: , [65410,65411]
operator: , [67034,67035]
===
match
---
simple_stmt [24085,24146]
simple_stmt [24116,24177]
===
match
---
atom_expr [64238,64264]
atom_expr [65862,65888]
===
match
---
atom_expr [68921,69155]
atom_expr [70545,70779]
===
match
---
trailer [33560,33592]
trailer [33591,33623]
===
match
---
param [17189,17193]
param [17220,17224]
===
match
---
operator: } [66423,66424]
operator: } [68047,68048]
===
match
---
name: DEFAULT_DATE [73769,73781]
name: DEFAULT_DATE [75393,75405]
===
match
---
name: dirname [21546,21553]
name: dirname [21577,21584]
===
match
---
atom_expr [8383,8500]
atom_expr [8414,8531]
===
match
---
name: BaseOperator [44866,44878]
name: BaseOperator [44897,44909]
===
match
---
name: session [52332,52339]
name: session [52363,52370]
===
match
---
with_item [38769,38816]
with_item [38800,38847]
===
match
---
operator: = [42143,42144]
operator: = [42174,42175]
===
match
---
name: parametrize [69534,69545]
name: parametrize [71158,71169]
===
match
---
operator: , [31342,31343]
operator: , [31373,31374]
===
match
---
name: synchronize_session [49818,49837]
name: synchronize_session [49849,49868]
===
match
---
simple_stmt [9046,9114]
simple_stmt [9077,9145]
===
match
---
name: start_date [55366,55376]
name: start_date [55397,55407]
===
match
---
operator: = [39808,39809]
operator: = [39839,39840]
===
match
---
atom_expr [10720,10741]
atom_expr [10751,10772]
===
match
---
operator: , [72684,72685]
operator: , [74308,74309]
===
match
---
suite [62175,63249]
suite [62206,63280]
===
match
---
operator: = [42537,42538]
operator: = [42568,42569]
===
match
---
trailer [33888,33905]
trailer [33919,33936]
===
match
---
trailer [76174,76181]
trailer [77798,77805]
===
match
---
trailer [19407,19415]
trailer [19438,19446]
===
match
---
name: NONE [51166,51170]
name: NONE [51197,51201]
===
match
---
atom_expr [56705,56735]
atom_expr [56736,56766]
===
match
---
expr_stmt [50974,51036]
expr_stmt [51005,51067]
===
match
---
name: _offset [27047,27054]
name: _offset [27078,27085]
===
match
---
name: DEFAULT_DATE [8222,8234]
name: DEFAULT_DATE [8253,8265]
===
match
---
trailer [68929,69155]
trailer [70553,70779]
===
match
---
name: self [67294,67298]
name: self [68918,68922]
===
match
---
expr_stmt [18120,18256]
expr_stmt [18151,18287]
===
match
---
name: test_next_dagrun_info_start_end_dates [57712,57749]
name: test_next_dagrun_info_start_end_dates [57743,57780]
===
match
---
name: TEST_DATE [25697,25706]
name: TEST_DATE [25728,25737]
===
match
---
simple_stmt [26676,26731]
simple_stmt [26707,26762]
===
match
---
name: dag1 [59887,59891]
name: dag1 [59918,59922]
===
match
---
operator: = [73891,73892]
operator: = [75515,75516]
===
match
---
name: DEFAULT_DATE [16178,16190]
name: DEFAULT_DATE [16209,16221]
===
match
---
simple_stmt [6779,6857]
simple_stmt [6810,6888]
===
match
---
name: xcom_pass_to_op [74194,74209]
name: xcom_pass_to_op [75818,75833]
===
match
---
arglist [42121,42174]
arglist [42152,42205]
===
match
---
funcdef [70022,70074]
funcdef [71646,71698]
===
match
---
trailer [61712,61718]
trailer [61743,61749]
===
match
---
trailer [20948,20953]
trailer [20979,20984]
===
match
---
atom_expr [78170,78197]
atom_expr [79794,79821]
===
match
---
name: execution_date [47010,47024]
name: execution_date [47041,47055]
===
match
---
name: parent_dag_name [64750,64765]
name: parent_dag_name [66374,66389]
===
match
---
and_test [62929,62998]
and_test [62960,63029]
===
match
---
name: RUNNING [44108,44115]
name: RUNNING [44139,44146]
===
match
---
string: "t2" [38904,38908]
string: "t2" [38935,38939]
===
match
---
comparison [46473,46511]
comparison [46504,46542]
===
match
---
comparison [65838,65862]
comparison [67462,67486]
===
match
---
name: next_info [62777,62786]
name: next_info [62808,62817]
===
match
---
name: pickle [48818,48824]
name: pickle [48849,48855]
===
match
---
simple_stmt [26233,26269]
simple_stmt [26264,26300]
===
match
---
string: 'tag-2' [27785,27792]
string: 'tag-2' [27816,27823]
===
match
---
atom_expr [42919,42929]
atom_expr [42950,42960]
===
match
---
name: test_task_id [18915,18927]
name: test_task_id [18946,18958]
===
match
---
atom_expr [61692,61718]
atom_expr [61723,61749]
===
match
---
name: op5 [7439,7442]
name: op5 [7470,7473]
===
match
---
operator: = [52602,52603]
operator: = [52633,52634]
===
match
---
atom_expr [33412,33516]
atom_expr [33443,33547]
===
match
---
name: next_date [60742,60751]
name: next_date [60773,60782]
===
match
---
name: hash [49291,49295]
name: hash [49322,49326]
===
match
---
operator: , [13817,13818]
operator: , [13848,13849]
===
match
---
name: all [30655,30658]
name: all [30686,30689]
===
match
---
name: prev [25258,25262]
name: prev [25289,25293]
===
match
---
operator: == [49800,49802]
operator: == [49831,49833]
===
match
---
operator: { [35581,35582]
operator: { [35612,35613]
===
match
---
operator: , [38430,38431]
operator: , [38461,38462]
===
match
---
name: datetime [63672,63680]
name: datetime [65296,65304]
===
match
---
simple_stmt [56744,56761]
simple_stmt [56775,56792]
===
match
---
expr_stmt [10821,10862]
expr_stmt [10852,10893]
===
match
---
trailer [26103,26149]
trailer [26134,26180]
===
match
---
operator: , [62049,62050]
operator: , [62080,62081]
===
match
---
name: dag [53179,53182]
name: dag [53210,53213]
===
match
---
operator: = [7889,7890]
operator: = [7920,7921]
===
match
---
operator: , [65137,65138]
operator: , [66761,66762]
===
match
---
atom_expr [22174,22208]
atom_expr [22205,22239]
===
match
---
name: prev [23715,23719]
name: prev [23746,23750]
===
match
---
operator: == [17128,17130]
operator: == [17159,17161]
===
match
---
simple_stmt [9821,9852]
simple_stmt [9852,9883]
===
match
---
number: 1 [61193,61194]
number: 1 [61224,61225]
===
match
---
operator: = [59728,59729]
operator: = [59759,59760]
===
match
---
argument [18017,18027]
argument [18048,18058]
===
match
---
simple_stmt [6322,6374]
simple_stmt [6353,6405]
===
match
---
operator: , [64784,64785]
operator: , [66408,66409]
===
match
---
arglist [78493,78570]
arglist [80117,80194]
===
match
---
atom_expr [41917,41944]
atom_expr [41948,41975]
===
match
---
name: State [51443,51448]
name: State [51474,51479]
===
match
---
name: permissions [66166,66177]
name: permissions [67790,67801]
===
match
---
name: task_1 [76375,76381]
name: task_1 [77999,78005]
===
match
---
string: 'test-dag' [28556,28566]
string: 'test-dag' [28587,28597]
===
match
---
name: datetime [78234,78242]
name: datetime [79858,79866]
===
match
---
operator: = [34275,34276]
operator: = [34306,34307]
===
match
---
operator: = [33032,33033]
operator: = [33063,33064]
===
match
---
name: State [2229,2234]
name: State [2260,2265]
===
match
---
name: correct_weight [15931,15945]
name: correct_weight [15962,15976]
===
match
---
atom_expr [58682,58691]
atom_expr [58713,58722]
===
match
---
operator: , [4725,4726]
operator: , [4756,4757]
===
match
---
trailer [79086,79096]
trailer [80710,80720]
===
match
---
name: test_dag_none_default_args_start_date [12984,13021]
name: test_dag_none_default_args_start_date [13015,13052]
===
match
---
fstring_string: dummy_task_ [70362,70373]
fstring_string: dummy_task_ [71986,71997]
===
match
---
name: start_date [6798,6808]
name: start_date [6829,6839]
===
match
---
trailer [63864,63870]
trailer [65488,65494]
===
match
---
name: dag [44770,44773]
name: dag [44801,44804]
===
match
---
trailer [25844,25863]
trailer [25875,25894]
===
match
---
assert_stmt [8012,8034]
assert_stmt [8043,8065]
===
match
---
argument [56830,56880]
argument [56861,56911]
===
match
---
operator: != [48702,48704]
operator: != [48733,48735]
===
match
---
testlist_comp [54305,54319]
testlist_comp [54336,54350]
===
match
---
atom_expr [18435,18472]
atom_expr [18466,18503]
===
match
---
trailer [24942,24949]
trailer [24973,24980]
===
match
---
trailer [35495,35499]
trailer [35526,35530]
===
match
---
name: _occur_before [8905,8918]
name: _occur_before [8936,8949]
===
match
---
atom_expr [6005,6093]
atom_expr [6036,6124]
===
match
---
name: DEFAULT_DATE [45044,45056]
name: DEFAULT_DATE [45075,45087]
===
match
---
trailer [27225,27235]
trailer [27256,27266]
===
match
---
dictorsetmaker [32778,32796]
dictorsetmaker [32809,32827]
===
match
---
string: 'fakename' [18824,18834]
string: 'fakename' [18855,18865]
===
match
---
assert_stmt [72625,72650]
assert_stmt [74249,74274]
===
match
---
name: num [73018,73021]
name: num [74642,74645]
===
match
---
name: utc [23428,23431]
name: utc [23459,23462]
===
match
---
atom_expr [17677,17726]
atom_expr [17708,17757]
===
match
---
name: raises [40408,40414]
name: raises [40439,40445]
===
match
---
name: dag_id [34827,34833]
name: dag_id [34858,34864]
===
match
---
operator: , [23371,23372]
operator: , [23402,23403]
===
match
---
trailer [43287,43289]
trailer [43318,43320]
===
match
---
trailer [32703,32710]
trailer [32734,32741]
===
match
---
atom_expr [25775,25792]
atom_expr [25806,25823]
===
match
---
trailer [35069,35076]
trailer [35100,35107]
===
match
---
name: simple [2003,2009]
name: simple [2034,2040]
===
match
---
trailer [35012,35022]
trailer [35043,35053]
===
match
---
name: airflow [1592,1599]
name: airflow [1598,1605]
===
match
---
atom_expr [70058,70073]
atom_expr [71682,71697]
===
match
---
name: start_date [73853,73863]
name: start_date [75477,75487]
===
match
---
atom [4601,4618]
atom [4632,4649]
===
match
---
operator: , [29842,29843]
operator: , [29873,29874]
===
match
---
operator: >> [75959,75961]
operator: >> [77583,77585]
===
match
---
name: DAG [10242,10245]
name: DAG [10273,10276]
===
match
---
trailer [68252,68442]
trailer [69876,70066]
===
match
---
operator: , [13899,13900]
operator: , [13930,13931]
===
match
---
operator: = [25477,25478]
operator: = [25508,25509]
===
match
---
argument [63806,63821]
argument [65430,65445]
===
match
---
name: session [45223,45230]
name: session [45254,45261]
===
match
---
name: weight_rule [2356,2367]
name: weight_rule [2387,2398]
===
match
---
name: dag_fileloc [37605,37616]
name: dag_fileloc [37636,37647]
===
match
---
operator: = [9568,9569]
operator: = [9599,9600]
===
match
---
operator: , [50320,50321]
operator: , [50351,50352]
===
match
---
operator: = [38880,38881]
operator: = [38911,38912]
===
match
---
operator: = [64236,64237]
operator: = [65860,65861]
===
match
---
simple_stmt [42956,42990]
simple_stmt [42987,43021]
===
match
---
operator: , [53693,53694]
operator: , [53724,53725]
===
match
---
name: stdout_lines [40232,40244]
name: stdout_lines [40263,40275]
===
match
---
with_stmt [66632,66725]
with_stmt [68256,68349]
===
match
---
operator: } [11463,11464]
operator: } [11494,11495]
===
match
---
expr_stmt [53961,54036]
expr_stmt [53992,54067]
===
match
---
name: add_task [25623,25631]
name: add_task [25654,25662]
===
match
---
operator: = [53680,53681]
operator: = [53711,53712]
===
match
---
trailer [74874,74876]
trailer [76498,76500]
===
match
---
simple_stmt [74419,74453]
simple_stmt [76043,76077]
===
match
---
operator: = [33568,33569]
operator: = [33599,33600]
===
match
---
operator: = [69083,69084]
operator: = [70707,70708]
===
match
---
name: _next [23772,23777]
name: _next [23803,23808]
===
match
---
number: 2018 [22260,22264]
number: 2018 [22291,22295]
===
match
---
operator: = [52994,52995]
operator: = [53025,53026]
===
match
---
name: start_date [44001,44011]
name: start_date [44032,44042]
===
match
---
simple_stmt [41640,41701]
simple_stmt [41671,41732]
===
match
---
comparison [58682,58703]
comparison [58713,58734]
===
match
---
simple_stmt [56144,56159]
simple_stmt [56175,56190]
===
match
---
trailer [40644,40682]
trailer [40675,40713]
===
match
---
with_stmt [21628,21761]
with_stmt [21659,21792]
===
match
---
simple_stmt [36832,36857]
simple_stmt [36863,36888]
===
match
---
name: patch [1094,1099]
name: patch [1100,1105]
===
match
---
funcdef [72170,72714]
funcdef [73794,74338]
===
match
---
trailer [52346,52348]
trailer [52377,52379]
===
match
---
comparison [3464,3489]
comparison [3495,3520]
===
match
---
name: dag [67425,67428]
name: dag [69049,69052]
===
match
---
trailer [65576,65587]
trailer [67200,67211]
===
match
---
with_stmt [39950,40072]
with_stmt [39981,40103]
===
match
---
operator: = [48783,48784]
operator: = [48814,48815]
===
match
---
name: include_subdags [55508,55523]
name: include_subdags [55539,55554]
===
match
---
name: start_date [59253,59263]
name: start_date [59284,59294]
===
match
---
name: ti [73966,73968]
name: ti [75590,75592]
===
match
---
name: pattern [14771,14778]
name: pattern [14802,14809]
===
match
---
name: run_id [74553,74559]
name: run_id [76177,76183]
===
match
---
name: self [26383,26387]
name: self [26414,26418]
===
match
---
operator: = [18022,18023]
operator: = [18053,18054]
===
match
---
name: dag_id [25470,25476]
name: dag_id [25501,25507]
===
match
---
expr_stmt [23428,23464]
expr_stmt [23459,23495]
===
match
---
operator: , [47891,47892]
operator: , [47922,47923]
===
match
---
simple_stmt [68131,68188]
simple_stmt [69755,69812]
===
match
---
name: DAG [11568,11571]
name: DAG [11599,11602]
===
match
---
trailer [71031,71040]
trailer [72655,72664]
===
match
---
name: a_index [3873,3880]
name: a_index [3904,3911]
===
match
---
trailer [55960,55971]
trailer [55991,56002]
===
match
---
operator: = [24428,24429]
operator: = [24459,24460]
===
match
---
param [36114,36118]
param [36145,36149]
===
match
---
fstring_string: . [64766,64767]
fstring_string: . [66390,66391]
===
match
---
param [52969,52976]
param [53000,53007]
===
match
---
trailer [57581,57590]
trailer [57612,57621]
===
match
---
funcdef [5585,5866]
funcdef [5616,5897]
===
match
---
name: one [33982,33985]
name: one [34013,34016]
===
match
---
comparison [69447,69463]
comparison [71071,71087]
===
match
---
operator: = [6784,6785]
operator: = [6815,6816]
===
match
---
name: sync_to_db [53467,53477]
name: sync_to_db [53498,53508]
===
match
---
name: topological_list [10072,10088]
name: topological_list [10103,10119]
===
match
---
atom_expr [69612,69654]
atom_expr [71236,71278]
===
match
---
suite [37386,38247]
suite [37417,38278]
===
match
---
name: parameterized [1254,1267]
name: parameterized [1260,1273]
===
match
---
operator: = [8757,8758]
operator: = [8788,8789]
===
match
---
comparison [12941,12974]
comparison [12972,13005]
===
match
---
comparison [42347,42393]
comparison [42378,42424]
===
match
---
string: 't1' [51797,51801]
string: 't1' [51828,51832]
===
match
---
trailer [24986,24988]
trailer [25017,25019]
===
match
---
trailer [12786,12795]
trailer [12817,12826]
===
match
---
classdef [2780,67224]
classdef [2811,68848]
===
match
---
trailer [57279,57287]
trailer [57310,57318]
===
match
---
operator: = [58221,58222]
operator: = [58252,58253]
===
match
---
operator: , [69730,69731]
operator: , [71354,71355]
===
match
---
trailer [76694,76702]
trailer [78318,78326]
===
match
---
expr_stmt [2899,2979]
expr_stmt [2930,3010]
===
match
---
name: op3 [8730,8733]
name: op3 [8761,8764]
===
match
---
operator: , [42824,42825]
operator: , [42855,42856]
===
match
---
trailer [71707,71717]
trailer [73331,73341]
===
match
---
name: op3 [39555,39558]
name: op3 [39586,39589]
===
match
---
name: next_dagrun_create_after [31417,31441]
name: next_dagrun_create_after [31448,31472]
===
match
---
operator: = [36551,36552]
operator: = [36582,36583]
===
match
---
operator: == [77560,77562]
operator: == [79184,79186]
===
match
---
trailer [73968,73978]
trailer [75592,75602]
===
match
---
name: session [77423,77430]
name: session [79047,79054]
===
match
---
argument [31645,31660]
argument [31676,31691]
===
match
---
atom [77702,77832]
atom [79326,79456]
===
match
---
trailer [21555,21560]
trailer [21586,21591]
===
match
---
expr_stmt [26158,26224]
expr_stmt [26189,26255]
===
match
---
simple_stmt [35682,35746]
simple_stmt [35713,35777]
===
match
---
param [39162,39166]
param [39193,39197]
===
match
---
simple_stmt [74462,74486]
simple_stmt [76086,76110]
===
match
---
name: session [36618,36625]
name: session [36649,36656]
===
match
---
name: dag [63971,63974]
name: dag [65595,65598]
===
match
---
atom_expr [36197,36216]
atom_expr [36228,36247]
===
match
---
operator: , [66870,66871]
operator: , [68494,68495]
===
match
---
trailer [69660,69668]
trailer [71284,71292]
===
match
---
expr_stmt [21886,21920]
expr_stmt [21917,21951]
===
match
---
name: start_date [47198,47208]
name: start_date [47229,47239]
===
match
---
atom_expr [26525,26546]
atom_expr [26556,26577]
===
match
---
param [64406,64410]
param [66030,66034]
===
match
---
testlist_comp [70124,70148]
testlist_comp [71748,71772]
===
match
---
simple_stmt [56705,56736]
simple_stmt [56736,56767]
===
match
---
argument [7627,7640]
argument [7658,7671]
===
match
---
operator: = [47437,47438]
operator: = [47468,47469]
===
match
---
trailer [24826,24828]
trailer [24857,24859]
===
match
---
trailer [77940,77949]
trailer [79564,79573]
===
match
---
operator: = [53100,53101]
operator: = [53131,53132]
===
match
---
operator: = [37443,37444]
operator: = [37474,37475]
===
match
---
argument [56638,56658]
argument [56669,56689]
===
match
---
assert_stmt [7651,7692]
assert_stmt [7682,7723]
===
match
---
name: State [42844,42849]
name: State [42875,42880]
===
match
---
comparison [41647,41700]
comparison [41678,41731]
===
match
---
trailer [32724,32726]
trailer [32755,32757]
===
match
---
argument [43700,43713]
argument [43731,43744]
===
match
---
name: dag [52358,52361]
name: dag [52389,52392]
===
match
---
name: DEFAULT_DATE [54565,54577]
name: DEFAULT_DATE [54596,54608]
===
match
---
operator: == [20124,20126]
operator: == [20155,20157]
===
match
---
name: query [49761,49766]
name: query [49792,49797]
===
match
---
arglist [64073,64094]
arglist [65697,65718]
===
match
---
simple_stmt [67835,67893]
simple_stmt [69459,69517]
===
match
---
trailer [43162,43177]
trailer [43193,43208]
===
match
---
suite [16012,17146]
suite [16043,17177]
===
match
---
operator: = [38834,38835]
operator: = [38865,38866]
===
match
---
simple_stmt [31487,31672]
simple_stmt [31518,31703]
===
match
---
simple_stmt [38324,38370]
simple_stmt [38355,38401]
===
match
---
atom_expr [13356,13388]
atom_expr [13387,13419]
===
match
---
argument [17612,17630]
argument [17643,17661]
===
match
---
name: DagModel [28462,28470]
name: DagModel [28493,28501]
===
match
---
simple_stmt [76514,76558]
simple_stmt [78138,78182]
===
match
---
dictorsetmaker [12764,12807]
dictorsetmaker [12795,12838]
===
match
---
argument [6798,6821]
argument [6829,6852]
===
match
---
string: "out-of-dag-restriction" [78654,78678]
string: "out-of-dag-restriction" [80278,80302]
===
match
---
assert_stmt [71235,71262]
assert_stmt [72859,72886]
===
match
---
import_from [1228,1267]
import_from [1234,1273]
===
match
---
atom_expr [20011,20028]
atom_expr [20042,20059]
===
match
---
operator: = [15787,15788]
operator: = [15818,15819]
===
match
---
name: MANUAL [73681,73687]
name: MANUAL [75305,75311]
===
match
---
import_from [2543,2614]
import_from [2574,2645]
===
match
---
operator: { [11709,11710]
operator: { [11740,11741]
===
match
---
trailer [22618,22626]
trailer [22649,22657]
===
match
---
operator: == [35235,35237]
operator: == [35266,35268]
===
match
---
funcdef [74190,74453]
funcdef [75814,76077]
===
match
---
string: '@hourly' [26214,26223]
string: '@hourly' [26245,26254]
===
match
---
expr_stmt [75706,75746]
expr_stmt [77330,77370]
===
match
---
arith_expr [59844,59877]
arith_expr [59875,59908]
===
match
---
name: DAG [66855,66858]
name: DAG [68479,68482]
===
match
---
name: value [75263,75268]
name: value [76887,76892]
===
match
---
operator: == [7997,7999]
operator: == [8028,8030]
===
match
---
name: DAG [51816,51819]
name: DAG [51847,51850]
===
match
---
arglist [61468,61660]
arglist [61499,61691]
===
match
---
trailer [20992,21063]
trailer [21023,21094]
===
match
---
name: schedule_interval [63717,63734]
name: schedule_interval [65341,65358]
===
match
---
string: 'test' [69828,69834]
string: 'test' [71452,71458]
===
match
---
comparison [48689,48708]
comparison [48720,48739]
===
match
---
argument [21030,21062]
argument [21061,21093]
===
match
---
trailer [29969,29973]
trailer [30000,30004]
===
match
---
name: dag_id [3369,3375]
name: dag_id [3400,3406]
===
match
---
trailer [49571,49579]
trailer [49602,49610]
===
match
---
name: task [76254,76258]
name: task [77878,77882]
===
match
---
name: dag [31157,31160]
name: dag [31188,31191]
===
match
---
comparison [49005,49033]
comparison [49036,49064]
===
match
---
name: __class__ [27382,27391]
name: __class__ [27413,27422]
===
match
---
name: execute [38153,38160]
name: execute [38184,38191]
===
match
---
name: set_task_instance_state [76647,76670]
name: set_task_instance_state [78271,78294]
===
match
---
atom_expr [46373,46415]
atom_expr [46404,46446]
===
match
---
name: dag [27716,27719]
name: dag [27747,27750]
===
match
---
simple_stmt [45422,45463]
simple_stmt [45453,45494]
===
match
---
trailer [73806,73814]
trailer [75430,75438]
===
match
---
name: subdag_id [35624,35633]
name: subdag_id [35655,35664]
===
match
---
name: test_task_id [19020,19032]
name: test_task_id [19051,19063]
===
match
---
name: dag_run_state [52922,52935]
name: dag_run_state [52953,52966]
===
match
---
expr_stmt [3663,3675]
expr_stmt [3694,3706]
===
match
---
operator: = [18545,18546]
operator: = [18576,18577]
===
match
---
name: task_id [44879,44886]
name: task_id [44910,44917]
===
match
---
sync_comp_for [13843,13867]
sync_comp_for [13874,13898]
===
match
---
assert_stmt [18955,19051]
assert_stmt [18986,19082]
===
match
---
operator: = [44716,44717]
operator: = [44747,44748]
===
match
---
name: topological_list [9834,9850]
name: topological_list [9865,9881]
===
match
---
operator: = [50641,50642]
operator: = [50672,50673]
===
match
---
name: DAG [47996,47999]
name: DAG [48027,48030]
===
match
---
operator: @ [3530,3531]
operator: @ [3561,3562]
===
match
---
operator: , [23383,23384]
operator: , [23414,23415]
===
match
---
name: dag_id [35292,35298]
name: dag_id [35323,35329]
===
match
---
trailer [3810,3818]
trailer [3841,3849]
===
match
---
simple_stmt [1337,1376]
simple_stmt [1343,1382]
===
match
---
atom_expr [18566,18575]
atom_expr [18597,18606]
===
match
---
suite [28312,28900]
suite [28343,28931]
===
match
---
name: DEFAULT_DATE [56477,56489]
name: DEFAULT_DATE [56508,56520]
===
match
---
operator: == [13210,13212]
operator: == [13241,13243]
===
match
---
number: 2015 [57421,57425]
number: 2015 [57452,57456]
===
match
---
fstring_expr [64749,64766]
fstring_expr [66373,66390]
===
match
---
argument [6955,6968]
argument [6986,6999]
===
match
---
assert_stmt [24959,25019]
assert_stmt [24990,25050]
===
match
---
operator: + [48226,48227]
operator: + [48257,48258]
===
match
---
name: self [72749,72753]
name: self [74373,74377]
===
match
---
expr_stmt [22217,22315]
expr_stmt [22248,22346]
===
match
---
name: session [69473,69480]
name: session [71097,71104]
===
match
---
trailer [76444,76452]
trailer [78068,78076]
===
match
---
operator: , [65377,65378]
operator: , [67001,67002]
===
match
---
number: 0 [63701,63702]
number: 0 [65325,65326]
===
match
---
trailer [30327,30333]
trailer [30358,30364]
===
match
---
operator: == [33310,33312]
operator: == [33341,33343]
===
match
---
name: dag [13691,13694]
name: dag [13722,13725]
===
match
---
number: 0 [52872,52873]
number: 0 [52903,52904]
===
match
---
suite [11823,12670]
suite [11854,12701]
===
match
---
arglist [11400,11464]
arglist [11431,11495]
===
match
---
with_stmt [65039,65426]
with_stmt [66663,67050]
===
match
---
trailer [68591,68597]
trailer [70215,70221]
===
match
---
name: test_bulk_write_to_db_max_active_runs [30785,30822]
name: test_bulk_write_to_db_max_active_runs [30816,30853]
===
match
---
comparison [40138,40161]
comparison [40169,40192]
===
match
---
funcdef [12675,12975]
funcdef [12706,13006]
===
match
---
name: get_ti_from_db [77067,77081]
name: get_ti_from_db [78691,78705]
===
match
---
simple_stmt [23816,23853]
simple_stmt [23847,23884]
===
match
---
name: task_id [53294,53301]
name: task_id [53325,53332]
===
match
---
arglist [14831,14895]
arglist [14862,14926]
===
match
---
decorator [69521,69738]
decorator [71145,71362]
===
match
---
name: session [2743,2750]
name: session [2774,2781]
===
match
---
name: create_dagrun [44088,44101]
name: create_dagrun [44119,44132]
===
match
---
operator: , [60932,60933]
operator: , [60963,60964]
===
match
---
operator: , [63954,63955]
operator: , [65578,65579]
===
match
---
trailer [38895,38909]
trailer [38926,38940]
===
match
---
operator: = [18491,18492]
operator: = [18522,18523]
===
match
---
operator: = [42588,42589]
operator: = [42619,42620]
===
match
---
trailer [10687,10702]
trailer [10718,10733]
===
match
---
string: 'tz_dag' [23484,23492]
string: 'tz_dag' [23515,23523]
===
match
---
name: isoformat [25263,25272]
name: isoformat [25294,25303]
===
match
---
atom_expr [35061,35101]
atom_expr [35092,35132]
===
match
---
operator: = [56599,56600]
operator: = [56630,56631]
===
match
---
assert_stmt [27596,27650]
assert_stmt [27627,27681]
===
match
---
operator: = [13759,13760]
operator: = [13790,13791]
===
match
---
trailer [46806,46869]
trailer [46837,46900]
===
match
---
argument [78761,78784]
argument [80385,80408]
===
match
---
arglist [70237,70287]
arglist [71861,71911]
===
match
---
expr_stmt [15657,15689]
expr_stmt [15688,15720]
===
match
---
trailer [22191,22208]
trailer [22222,22239]
===
match
---
name: dag [58088,58091]
name: dag [58119,58122]
===
match
---
argument [41931,41943]
argument [41962,41974]
===
match
---
comparison [61998,62053]
comparison [62029,62084]
===
match
---
name: TEST_DATE [46166,46175]
name: TEST_DATE [46197,46206]
===
match
---
name: datetime [77986,77994]
name: datetime [79610,79618]
===
match
---
name: dag [49462,49465]
name: dag [49493,49496]
===
match
---
trailer [10114,10121]
trailer [10145,10152]
===
match
---
funcdef [70921,70991]
funcdef [72545,72615]
===
match
---
atom_expr [76562,76590]
atom_expr [78186,78214]
===
match
---
argument [43960,43980]
argument [43991,44011]
===
match
---
string: "2018-10-26T01:00:00+00:00" [23735,23762]
string: "2018-10-26T01:00:00+00:00" [23766,23793]
===
match
---
fstring_expr [64973,64980]
fstring_expr [66597,66604]
===
match
---
assert_stmt [51045,51087]
assert_stmt [51076,51118]
===
match
---
atom [14395,14421]
atom [14426,14452]
===
match
---
operator: , [51851,51852]
operator: , [51882,51883]
===
match
---
name: start_date [64044,64054]
name: start_date [65668,65678]
===
match
---
argument [73883,73909]
argument [75507,75533]
===
match
---
name: i [28122,28123]
name: i [28153,28154]
===
match
---
simple_stmt [24736,24797]
simple_stmt [24767,24828]
===
match
---
suite [72205,72714]
suite [73829,74338]
===
match
---
operator: = [32584,32585]
operator: = [32615,32616]
===
match
---
atom_expr [12549,12577]
atom_expr [12580,12608]
===
match
---
argument [62435,62475]
argument [62466,62506]
===
match
---
decorated [54232,55032]
decorated [54263,55063]
===
match
---
name: dag_id [38214,38220]
name: dag_id [38245,38251]
===
match
---
decorator [49850,50338]
decorator [49881,50369]
===
match
---
trailer [37992,38014]
trailer [38023,38045]
===
match
---
fstring_expr [16351,16354]
fstring_expr [16382,16385]
===
match
---
string: 'dag.subtask' [33736,33749]
string: 'dag.subtask' [33767,33780]
===
match
---
simple_stmt [47706,47747]
simple_stmt [47737,47778]
===
match
---
testlist_star_expr [60521,60533]
testlist_star_expr [60552,60564]
===
match
---
operator: , [9355,9356]
operator: , [9386,9387]
===
match
---
atom_expr [76975,77014]
atom_expr [78599,78638]
===
match
---
name: DummyOperator [53148,53161]
name: DummyOperator [53179,53192]
===
match
---
operator: @ [62059,62060]
operator: @ [62090,62091]
===
match
---
name: test_dag_id [48137,48148]
name: test_dag_id [48168,48179]
===
match
---
atom_expr [37868,37885]
atom_expr [37899,37916]
===
match
---
name: j [16356,16357]
name: j [16387,16388]
===
match
---
name: utcoffset [27177,27186]
name: utcoffset [27208,27217]
===
match
---
name: DAG [72117,72120]
name: DAG [73741,73744]
===
match
---
name: dr [50786,50788]
name: dr [50817,50819]
===
match
---
trailer [78124,78133]
trailer [79748,79757]
===
match
---
operator: { [29403,29404]
operator: { [29434,29435]
===
match
---
trailer [20481,20497]
trailer [20512,20528]
===
match
---
atom [10291,10310]
atom [10322,10341]
===
match
---
name: dag [51921,51924]
name: dag [51952,51955]
===
match
---
sync_comp_for [30309,30356]
sync_comp_for [30340,30387]
===
match
---
operator: = [3671,3672]
operator: = [3702,3703]
===
match
---
name: datetime [64064,64072]
name: datetime [65688,65696]
===
match
---
name: set_is_paused [35300,35313]
name: set_is_paused [35331,35344]
===
match
---
trailer [49792,49799]
trailer [49823,49830]
===
match
---
name: AirflowException [5195,5211]
name: AirflowException [5226,5242]
===
match
---
name: task_id [41545,41552]
name: task_id [41576,41583]
===
match
---
atom_expr [44853,44945]
atom_expr [44884,44976]
===
match
---
atom_expr [60995,61022]
atom_expr [61026,61053]
===
match
---
simple_stmt [23552,23586]
simple_stmt [23583,23617]
===
match
---
comparison [69287,69306]
comparison [70911,70930]
===
match
---
operator: == [19177,19179]
operator: == [19208,19210]
===
match
---
name: DAG [19180,19183]
name: DAG [19211,19214]
===
match
---
name: dag [9315,9318]
name: dag [9346,9349]
===
match
---
not_test [43241,43269]
not_test [43272,43300]
===
match
---
atom [14876,14895]
atom [14907,14926]
===
match
---
name: return_num [74273,74283]
name: return_num [75897,75907]
===
match
---
arglist [17872,17956]
arglist [17903,17987]
===
match
---
trailer [78760,78839]
trailer [80384,80463]
===
match
---
name: self [73764,73768]
name: self [75388,75392]
===
match
---
operator: = [58540,58541]
operator: = [58571,58572]
===
match
---
name: timezone [64055,64063]
name: timezone [65679,65687]
===
match
---
simple_stmt [7928,7943]
simple_stmt [7959,7974]
===
match
---
atom_expr [42963,42977]
atom_expr [42994,43008]
===
match
---
trailer [54513,54519]
trailer [54544,54550]
===
match
---
string: "test_create_dagrun_job_id_is_set" [51401,51435]
string: "test_create_dagrun_job_id_is_set" [51432,51466]
===
match
---
name: task_1 [75706,75712]
name: task_1 [77330,77336]
===
match
---
name: dag_id [3173,3179]
name: dag_id [3204,3210]
===
match
---
arglist [45896,45924]
arglist [45927,45955]
===
match
---
assert_stmt [9122,9188]
assert_stmt [9153,9219]
===
match
---
simple_stmt [36603,36635]
simple_stmt [36634,36666]
===
match
---
operator: = [51284,51285]
operator: = [51315,51316]
===
match
---
operator: , [69781,69782]
operator: , [71405,71406]
===
match
---
name: DagModel [69387,69395]
name: DagModel [71011,71019]
===
match
---
trailer [46730,46772]
trailer [46761,46803]
===
match
---
name: query [30328,30333]
name: query [30359,30364]
===
match
---
name: DEFAULT_ARGS [71493,71505]
name: DEFAULT_ARGS [73117,73129]
===
match
---
number: 4 [19459,19460]
number: 4 [19490,19491]
===
match
---
name: start_date [76719,76729]
name: start_date [78343,78353]
===
match
---
atom_expr [57265,57287]
atom_expr [57296,57318]
===
match
---
atom_expr [19961,19983]
atom_expr [19992,20014]
===
match
---
name: get_ti_from_db [76093,76107]
name: get_ti_from_db [77717,77731]
===
match
---
name: pytest [5181,5187]
name: pytest [5212,5218]
===
match
---
name: dag_id [50635,50641]
name: dag_id [50666,50672]
===
match
---
name: session [19043,19050]
name: session [19074,19081]
===
match
---
parameters [74283,74288]
parameters [75907,75912]
===
match
---
trailer [42970,42977]
trailer [43001,43008]
===
match
---
atom_expr [17259,17328]
atom_expr [17290,17359]
===
match
---
parameters [36920,36926]
parameters [36951,36957]
===
match
---
atom_expr [68092,68121]
atom_expr [69716,69745]
===
match
---
dotted_name [2299,2318]
dotted_name [2330,2349]
===
match
---
operator: = [9591,9592]
operator: = [9622,9623]
===
match
---
simple_stmt [8106,8246]
simple_stmt [8137,8277]
===
match
---
expr_stmt [60781,60970]
expr_stmt [60812,61001]
===
match
---
name: dag [58397,58400]
name: dag [58428,58431]
===
match
---
number: 1 [62692,62693]
number: 1 [62723,62724]
===
match
---
name: dag [62716,62719]
name: dag [62747,62750]
===
match
---
arglist [5420,5494]
arglist [5451,5525]
===
match
---
string: 'test_pickling' [47439,47454]
string: 'test_pickling' [47470,47485]
===
match
---
operator: , [67342,67343]
operator: , [68966,68967]
===
match
---
parameters [36113,36119]
parameters [36144,36150]
===
match
---
simple_stmt [28244,28271]
simple_stmt [28275,28302]
===
match
---
operator: = [70231,70232]
operator: = [71855,71856]
===
match
---
argument [28127,28150]
argument [28158,28181]
===
match
---
operator: == [7669,7671]
operator: == [7700,7702]
===
match
---
atom_expr [6389,6429]
atom_expr [6420,6460]
===
match
---
simple_stmt [69316,69341]
simple_stmt [70940,70965]
===
match
---
testlist_comp [29825,29854]
testlist_comp [29856,29885]
===
match
---
name: State [76439,76444]
name: State [78063,78068]
===
match
---
argument [78005,78012]
argument [79629,79636]
===
match
---
simple_stmt [36983,37055]
simple_stmt [37014,37086]
===
match
---
name: test_dag_id [18810,18821]
name: test_dag_id [18841,18852]
===
match
---
decorator [70079,70165]
decorator [71703,71789]
===
match
---
operator: , [57598,57599]
operator: , [57629,57630]
===
match
---
number: 0 [10961,10962]
number: 0 [10992,10993]
===
match
---
name: session [30686,30693]
name: session [30717,30724]
===
match
---
name: default_args [48013,48025]
name: default_args [48044,48056]
===
match
---
name: orm_dag [34003,34010]
name: orm_dag [34034,34041]
===
match
---
expr_stmt [60980,61022]
expr_stmt [61011,61053]
===
match
---
name: DAG [68037,68040]
name: DAG [69661,69664]
===
match
---
parameters [27676,27682]
parameters [27707,27713]
===
match
---
name: write [20826,20831]
name: write [20857,20862]
===
match
---
import_as_names [2583,2614]
import_as_names [2614,2645]
===
match
---
operator: = [22290,22291]
operator: = [22321,22322]
===
match
---
expr_stmt [74462,74485]
expr_stmt [76086,76109]
===
match
---
simple_stmt [20398,20436]
simple_stmt [20429,20467]
===
match
---
trailer [49776,49783]
trailer [49807,49814]
===
match
---
assert_stmt [43234,43269]
assert_stmt [43265,43300]
===
match
---
name: DAGsubclass [48125,48136]
name: DAGsubclass [48156,48167]
===
match
---
trailer [30612,30661]
trailer [30643,30692]
===
match
---
operator: = [16343,16344]
operator: = [16374,16375]
===
match
---
atom_expr [28956,28979]
atom_expr [28987,29010]
===
match
---
simple_stmt [74378,74407]
simple_stmt [76002,76031]
===
match
---
trailer [67941,67950]
trailer [69565,69574]
===
match
---
expr_stmt [53489,53517]
expr_stmt [53520,53548]
===
match
---
trailer [74399,74406]
trailer [76023,76030]
===
match
---
operator: = [59416,59417]
operator: = [59447,59448]
===
match
---
name: Session [68893,68900]
name: Session [70517,70524]
===
match
---
operator: == [52842,52844]
operator: == [52873,52875]
===
match
---
suite [34174,36063]
suite [34205,36094]
===
match
---
number: 10 [23373,23375]
number: 10 [23404,23406]
===
match
---
name: isinstance [72101,72111]
name: isinstance [73725,73735]
===
match
---
operator: , [78809,78810]
operator: , [80433,80434]
===
match
---
name: test_dag_naive_default_args_start_date_with_timezone [38256,38308]
name: test_dag_naive_default_args_start_date_with_timezone [38287,38339]
===
match
---
operator: == [50796,50798]
operator: == [50827,50829]
===
match
---
argument [53162,53177]
argument [53193,53208]
===
match
---
name: query [28818,28823]
name: query [28849,28854]
===
match
---
param [69978,69982]
param [71602,71606]
===
match
---
name: isinstance [74337,74347]
name: isinstance [75961,75971]
===
match
---
atom_expr [51503,51521]
atom_expr [51534,51552]
===
match
---
simple_stmt [53279,53334]
simple_stmt [53310,53365]
===
match
---
argument [35730,35744]
argument [35761,35775]
===
match
---
argument [68775,68798]
argument [70399,70422]
===
match
---
name: parent_dag [32438,32448]
name: parent_dag [32469,32479]
===
match
---
name: task_id [39847,39854]
name: task_id [39878,39885]
===
match
---
atom [65379,65409]
atom [67003,67033]
===
match
---
assert_stmt [64273,64357]
assert_stmt [65897,65981]
===
match
---
name: type [66920,66924]
name: type [68544,68548]
===
match
---
name: one [37180,37183]
name: one [37211,37214]
===
match
---
simple_stmt [71024,71043]
simple_stmt [72648,72667]
===
match
---
name: State [56439,56444]
name: State [56470,56475]
===
match
---
arglist [77658,78680]
arglist [79282,80304]
===
match
---
name: start_date [7568,7578]
name: start_date [7599,7609]
===
match
---
name: self [69768,69772]
name: self [71392,71396]
===
match
---
atom [13737,13826]
atom [13768,13857]
===
match
---
operator: , [50163,50164]
operator: , [50194,50195]
===
match
---
name: ti4 [18566,18569]
name: ti4 [18597,18600]
===
match
---
trailer [65816,65822]
trailer [67440,67446]
===
match
---
name: timezone [63926,63934]
name: timezone [65550,65558]
===
match
---
atom_expr [7848,7876]
atom_expr [7879,7907]
===
match
---
number: 0 [73948,73949]
number: 0 [75572,75573]
===
match
---
name: NONE [55089,55093]
name: NONE [55120,55124]
===
match
---
name: logical_date [62801,62813]
name: logical_date [62832,62844]
===
match
---
atom_expr [62072,62101]
atom_expr [62103,62132]
===
match
---
string: "0 0 * * *" [49958,49969]
string: "0 0 * * *" [49989,50000]
===
match
---
simple_stmt [24422,24516]
simple_stmt [24453,24547]
===
match
---
trailer [34814,34835]
trailer [34845,34866]
===
match
---
name: prev [24721,24725]
name: prev [24752,24756]
===
match
---
number: 1 [15811,15812]
number: 1 [15842,15843]
===
match
---
atom_expr [49339,49357]
atom_expr [49370,49388]
===
match
---
expr_stmt [76360,76403]
expr_stmt [77984,78027]
===
match
---
operator: @ [51537,51538]
operator: @ [51568,51569]
===
match
---
name: datetime [57582,57590]
name: datetime [57613,57621]
===
match
---
trailer [26167,26224]
trailer [26198,26255]
===
match
---
operator: , [58134,58135]
operator: , [58165,58166]
===
match
---
operator: , [24469,24470]
operator: , [24500,24501]
===
match
---
argument [68171,68186]
argument [69795,69810]
===
match
---
name: task [21979,21983]
name: task [22010,22014]
===
match
---
name: SubDagOperator [8664,8678]
name: SubDagOperator [8695,8709]
===
match
---
operator: , [50407,50408]
operator: , [50438,50439]
===
match
---
name: create_dagrun [51987,52000]
name: create_dagrun [52018,52031]
===
match
---
trailer [67515,67772]
trailer [69139,69396]
===
match
---
name: logical_date [63910,63922]
name: logical_date [65534,65546]
===
match
---
expr_stmt [51935,51963]
expr_stmt [51966,51994]
===
match
---
name: params2 [4734,4741]
name: params2 [4765,4772]
===
match
---
dictorsetmaker [19916,19928]
dictorsetmaker [19947,19959]
===
match
---
trailer [21229,21242]
trailer [21260,21273]
===
match
---
dictorsetmaker [41665,41699]
dictorsetmaker [41696,41730]
===
match
---
atom_expr [31492,31671]
atom_expr [31523,31702]
===
match
---
operator: , [26509,26510]
operator: , [26540,26541]
===
match
---
trailer [40729,40739]
trailer [40760,40770]
===
match
---
argument [39515,39527]
argument [39546,39558]
===
match
---
number: 1 [57597,57598]
number: 1 [57628,57629]
===
match
---
simple_stmt [2543,2615]
simple_stmt [2574,2646]
===
match
---
string: 't3' [42031,42035]
string: 't3' [42062,42066]
===
match
---
expr_stmt [55261,55306]
expr_stmt [55292,55337]
===
match
---
testlist_comp [50208,50232]
testlist_comp [50239,50263]
===
match
---
name: DAG [19464,19467]
name: DAG [19495,19498]
===
match
---
name: start [24422,24427]
name: start [24453,24458]
===
match
---
with_stmt [33525,33829]
with_stmt [33556,33860]
===
match
---
simple_stmt [1194,1228]
simple_stmt [1200,1234]
===
match
---
name: int [15670,15673]
name: int [15701,15704]
===
match
---
param [13022,13026]
param [13053,13057]
===
match
---
name: TaskFail [1558,1566]
name: TaskFail [1564,1572]
===
match
---
atom_expr [57624,57669]
atom_expr [57655,57700]
===
match
---
name: parametrize [77641,77652]
name: parametrize [79265,79276]
===
match
---
name: orm_subdag [33291,33301]
name: orm_subdag [33322,33332]
===
match
---
assert_stmt [69280,69306]
assert_stmt [70904,70930]
===
match
---
name: task_id [76259,76266]
name: task_id [77883,77890]
===
match
---
suite [26796,27651]
suite [26827,27682]
===
match
---
argument [41545,41557]
argument [41576,41588]
===
match
---
name: all [28851,28854]
name: all [28882,28885]
===
match
---
simple_stmt [27596,27651]
simple_stmt [27627,27682]
===
match
---
name: dag [41647,41650]
name: dag [41678,41681]
===
match
---
suite [54406,55032]
suite [54437,55063]
===
match
---
parameters [71936,71938]
parameters [73560,73562]
===
match
---
trailer [6393,6397]
trailer [6424,6428]
===
match
---
name: datetime [59789,59797]
name: datetime [59820,59828]
===
match
---
operator: , [78728,78729]
operator: , [80352,80353]
===
match
---
number: 12 [70143,70145]
number: 12 [71767,71769]
===
match
---
name: pytest [17347,17353]
name: pytest [17378,17384]
===
match
---
atom_expr [48125,48168]
atom_expr [48156,48199]
===
match
---
term [14395,14429]
term [14426,14460]
===
match
---
operator: - [78168,78169]
operator: - [79792,79793]
===
match
---
arglist [9148,9187]
arglist [9179,9218]
===
match
---
shift_expr [59544,59561]
shift_expr [59575,59592]
===
match
---
trailer [63909,63922]
trailer [65533,65546]
===
match
---
operator: { [6750,6751]
operator: { [6781,6782]
===
match
---
with_item [40511,40558]
with_item [40542,40589]
===
match
---
name: test_dag [17597,17605]
name: test_dag [17628,17636]
===
match
---
name: datetime [61178,61186]
name: datetime [61209,61217]
===
match
---
number: 2 [24478,24479]
number: 2 [24509,24510]
===
match
---
atom_expr [75764,75795]
atom_expr [77388,77419]
===
match
---
argument [12750,12808]
argument [12781,12839]
===
match
---
operator: } [4653,4654]
operator: } [4684,4685]
===
match
---
name: dag_id [60347,60353]
name: dag_id [60378,60384]
===
match
---
trailer [29424,29427]
trailer [29455,29458]
===
match
---
argument [72303,72333]
argument [73927,73957]
===
match
---
operator: , [12920,12921]
operator: , [12951,12952]
===
match
---
operator: , [79045,79046]
operator: , [80669,80670]
===
match
---
atom_expr [19464,19602]
atom_expr [19495,19633]
===
match
---
operator: } [39621,39622]
operator: } [39652,39653]
===
match
---
name: dag [45934,45937]
name: dag [45965,45968]
===
match
---
simple_stmt [47281,47356]
simple_stmt [47312,47387]
===
match
---
operator: == [11485,11487]
operator: == [11516,11518]
===
match
---
operator: , [30241,30242]
operator: , [30272,30273]
===
match
---
name: run_id [50997,51003]
name: run_id [51028,51034]
===
match
---
comparison [20099,20132]
comparison [20130,20163]
===
match
---
name: dag [8023,8026]
name: dag [8054,8057]
===
match
---
trailer [32687,32694]
trailer [32718,32725]
===
match
---
comparison [20350,20389]
comparison [20381,20420]
===
match
---
name: weight [16095,16101]
name: weight [16126,16132]
===
match
---
argument [46848,46868]
argument [46879,46899]
===
match
---
testlist_comp [51582,51626]
testlist_comp [51613,51657]
===
match
---
name: settings [33847,33855]
name: settings [33878,33886]
===
match
---
operator: = [54105,54106]
operator: = [54136,54137]
===
match
---
operator: = [36273,36274]
operator: = [36304,36305]
===
match
---
argument [78373,78380]
argument [79997,80004]
===
match
---
operator: = [21588,21589]
operator: = [21619,21620]
===
match
---
name: query [55645,55650]
name: query [55676,55681]
===
match
---
operator: @ [75046,75047]
operator: @ [76670,76671]
===
match
---
name: SubDagOperator [65271,65285]
name: SubDagOperator [66895,66909]
===
match
---
operator: , [54577,54578]
operator: , [54608,54609]
===
match
---
fstring_start: f' [70360,70362]
fstring_start: f' [71984,71986]
===
match
---
name: tzinfo [26518,26524]
name: tzinfo [26549,26555]
===
match
---
trailer [27432,27467]
trailer [27463,27498]
===
match
---
trailer [33938,33948]
trailer [33969,33979]
===
match
---
name: DAG [67315,67318]
name: DAG [68939,68942]
===
match
---
string: 'dummy_task' [34372,34384]
string: 'dummy_task' [34403,34415]
===
match
---
name: models [1705,1711]
name: models [1711,1717]
===
match
---
atom_expr [64719,64878]
atom_expr [66343,66502]
===
match
---
operator: @ [72447,72448]
operator: @ [74071,74072]
===
match
---
atom_expr [33124,33153]
atom_expr [33155,33184]
===
match
---
name: self [40318,40322]
name: self [40349,40353]
===
match
---
atom_expr [40054,40071]
atom_expr [40085,40102]
===
match
---
simple_stmt [21972,22026]
simple_stmt [22003,22057]
===
match
---
name: op2 [39357,39360]
name: op2 [39388,39391]
===
match
---
atom_expr [24926,24949]
atom_expr [24957,24980]
===
match
---
name: test_dag [18126,18134]
name: test_dag [18157,18165]
===
match
---
trailer [23007,23013]
trailer [23038,23044]
===
match
---
name: op1 [41665,41668]
name: op1 [41696,41699]
===
match
---
simple_stmt [44519,44657]
simple_stmt [44550,44688]
===
match
---
operator: , [74353,74354]
operator: , [75977,75978]
===
match
---
name: dag [8000,8003]
name: dag [8031,8034]
===
match
---
assert_stmt [24805,24859]
assert_stmt [24836,24890]
===
match
---
simple_stmt [70058,70074]
simple_stmt [71682,71698]
===
match
---
name: dag_id [58105,58111]
name: dag_id [58136,58142]
===
match
---
name: template_dir [21523,21535]
name: template_dir [21554,21566]
===
match
---
param [71009,71013]
param [72633,72637]
===
match
---
name: start_date [8211,8221]
name: start_date [8242,8252]
===
match
---
name: DAG [63977,63980]
name: DAG [65601,65604]
===
match
---
operator: = [59041,59042]
operator: = [59072,59073]
===
match
---
name: logical_date [63203,63215]
name: logical_date [63234,63246]
===
match
---
trailer [43686,43900]
trailer [43717,43931]
===
match
---
import_name [1115,1130]
import_name [1121,1136]
===
match
---
operator: = [11417,11418]
operator: = [11448,11449]
===
match
---
name: session [19577,19584]
name: session [19608,19615]
===
match
---
name: session [37760,37767]
name: session [37791,37798]
===
match
---
classdef [69926,70614]
classdef [71550,72238]
===
match
---
name: orm_dag [37096,37103]
name: orm_dag [37127,37134]
===
match
---
argument [40527,40550]
argument [40558,40581]
===
match
---
simple_stmt [25137,25173]
simple_stmt [25168,25204]
===
match
---
operator: , [50080,50081]
operator: , [50111,50112]
===
match
---
assert_stmt [42877,42903]
assert_stmt [42908,42934]
===
match
---
parameters [45596,45602]
parameters [45627,45633]
===
match
---
name: DagModel [69227,69235]
name: DagModel [70851,70859]
===
match
---
trailer [78965,78977]
trailer [80589,80601]
===
match
---
string: 'noop_pipeline' [72149,72164]
string: 'noop_pipeline' [73773,73788]
===
match
---
trailer [51505,51521]
trailer [51536,51552]
===
match
---
name: dag_id [5520,5526]
name: dag_id [5551,5557]
===
match
---
trailer [31139,31182]
trailer [31170,31213]
===
match
---
name: self [49404,49408]
name: self [49435,49439]
===
match
---
name: task [1407,1411]
name: task [1413,1417]
===
match
---
trailer [16159,16225]
trailer [16190,16256]
===
match
---
trailer [31495,31509]
trailer [31526,31540]
===
match
---
simple_stmt [25182,25243]
simple_stmt [25213,25274]
===
match
---
simple_stmt [71796,71855]
simple_stmt [73420,73479]
===
match
---
name: owner [64200,64205]
name: owner [65824,65829]
===
match
---
fstring_start: f' [15015,15017]
fstring_start: f' [15046,15048]
===
match
---
name: dag_id [28471,28477]
name: dag_id [28502,28508]
===
match
---
name: start_date [44920,44930]
name: start_date [44951,44961]
===
match
---
operator: , [29379,29380]
operator: , [29410,29411]
===
match
---
testlist_comp [36015,36030]
testlist_comp [36046,36061]
===
match
---
argument [52235,52262]
argument [52266,52293]
===
match
---
simple_stmt [38517,38559]
simple_stmt [38548,38590]
===
match
---
trailer [52912,52918]
trailer [52943,52949]
===
match
---
name: test_next_dagrun_after_fake_scheduled_previous [44457,44503]
name: test_next_dagrun_after_fake_scheduled_previous [44488,44534]
===
match
---
trailer [47163,47179]
trailer [47194,47210]
===
match
---
name: start [27507,27512]
name: start [27538,27543]
===
match
---
assert_stmt [48529,48556]
assert_stmt [48560,48587]
===
match
---
operator: { [70373,70374]
operator: { [71997,71998]
===
match
---
assert_stmt [40719,40761]
assert_stmt [40750,40792]
===
match
---
expr_stmt [61911,61968]
expr_stmt [61942,61999]
===
match
---
simple_stmt [76000,76084]
simple_stmt [77624,77708]
===
match
---
name: task_id [9584,9591]
name: task_id [9615,9622]
===
match
---
simple_stmt [58327,58343]
simple_stmt [58358,58374]
===
match
---
argument [32170,32184]
argument [32201,32215]
===
match
---
name: dag [41219,41222]
name: dag [41250,41253]
===
match
---
name: dag [26638,26641]
name: dag [26669,26672]
===
match
---
name: DEFAULT_DATE [78493,78505]
name: DEFAULT_DATE [80117,80129]
===
match
---
name: dag [30038,30041]
name: dag [30069,30072]
===
match
---
decorator [73315,73362]
decorator [74939,74986]
===
match
---
name: dag [7443,7446]
name: dag [7474,7477]
===
match
---
name: _next [24869,24874]
name: _next [24900,24905]
===
match
---
name: RUNNING [19567,19574]
name: RUNNING [19598,19605]
===
match
---
argument [47893,47910]
argument [47924,47941]
===
match
---
trailer [5837,5843]
trailer [5868,5874]
===
match
---
name: test_dag_id [48060,48071]
name: test_dag_id [48091,48102]
===
match
---
name: session [31303,31310]
name: session [31334,31341]
===
match
---
name: DagModel [30334,30342]
name: DagModel [30365,30373]
===
match
---
operator: > [60663,60664]
operator: > [60694,60695]
===
match
---
name: clear [52362,52367]
name: clear [52393,52398]
===
match
---
name: dag_id [42923,42929]
name: dag_id [42954,42960]
===
match
---
decorated [72853,73053]
decorated [74477,74677]
===
match
---
name: return_num [71637,71647]
name: return_num [73261,73271]
===
match
---
trailer [39892,39906]
trailer [39923,39937]
===
match
---
simple_stmt [47463,47519]
simple_stmt [47494,47550]
===
match
---
trailer [62986,62998]
trailer [63017,63029]
===
match
---
fstring_start: f' [13760,13762]
fstring_start: f' [13791,13793]
===
match
---
trailer [29289,29291]
trailer [29320,29322]
===
match
---
number: 0 [13955,13956]
number: 0 [13986,13987]
===
match
---
operator: = [73519,73520]
operator: = [75143,75144]
===
match
---
name: width [14735,14740]
name: width [14766,14771]
===
match
---
simple_stmt [52822,52847]
simple_stmt [52853,52878]
===
match
---
operator: = [74466,74467]
operator: = [76090,76091]
===
match
---
string: 'dag_without_catchup_hourly' [60354,60382]
string: 'dag_without_catchup_hourly' [60385,60413]
===
match
---
operator: = [34223,34224]
operator: = [34254,34255]
===
match
---
operator: , [40525,40526]
operator: , [40556,40557]
===
match
---
simple_stmt [14262,14295]
simple_stmt [14293,14326]
===
match
---
name: NONE [50765,50769]
name: NONE [50796,50800]
===
match
---
simple_stmt [14461,14508]
simple_stmt [14492,14539]
===
match
---
number: 1 [2646,2647]
number: 1 [2677,2678]
===
match
---
name: DEFAULT_DATE [33782,33794]
name: DEFAULT_DATE [33813,33825]
===
match
---
name: weight [13793,13799]
name: weight [13824,13830]
===
match
---
name: UTC0530 [27457,27464]
name: UTC0530 [27488,27495]
===
match
---
name: num [72519,72522]
name: num [74143,74146]
===
match
---
number: 0 [74877,74878]
number: 0 [76501,76502]
===
match
---
with_stmt [29028,29097]
with_stmt [29059,29128]
===
match
---
name: DummyOperator [7154,7167]
name: DummyOperator [7185,7198]
===
match
---
atom_expr [26683,26699]
atom_expr [26714,26730]
===
match
---
trailer [76493,76509]
trailer [78117,78133]
===
match
---
arglist [76199,76311]
arglist [77823,77935]
===
match
---
name: next_info [57479,57488]
name: next_info [57510,57519]
===
match
---
argument [19128,19141]
argument [19159,19172]
===
match
---
atom_expr [73521,73538]
atom_expr [75145,75162]
===
match
---
simple_stmt [20092,20133]
simple_stmt [20123,20164]
===
match
---
atom_expr [74337,74364]
atom_expr [75961,75988]
===
match
---
name: session [49753,49760]
name: session [49784,49791]
===
match
---
trailer [72676,72682]
trailer [74300,74306]
===
match
---
argument [39423,39435]
argument [39454,39466]
===
match
---
name: dag [20312,20315]
name: dag [20343,20346]
===
match
---
name: contextlib [884,894]
name: contextlib [884,894]
===
match
---
name: permissions [66070,66081]
name: permissions [67694,67705]
===
match
---
name: next_info [63179,63188]
name: next_info [63210,63219]
===
match
---
name: BaseOperator [43947,43959]
name: BaseOperator [43978,43990]
===
match
---
dotted_name [2202,2221]
dotted_name [2233,2252]
===
match
---
string: 'airflow' [47823,47832]
string: 'airflow' [47854,47863]
===
match
---
operator: , [55123,55124]
operator: , [55154,55155]
===
match
---
operator: = [13315,13316]
operator: = [13346,13347]
===
match
---
string: 'dag' [11400,11405]
string: 'dag' [11431,11436]
===
match
---
simple_stmt [40085,40119]
simple_stmt [40116,40150]
===
match
---
operator: , [36526,36527]
operator: , [36557,36558]
===
match
---
expr_stmt [26233,26268]
expr_stmt [26264,26299]
===
match
---
name: t_2 [53342,53345]
name: t_2 [53373,53376]
===
match
---
trailer [18583,18591]
trailer [18614,18622]
===
match
---
name: task [21272,21276]
name: task [21303,21307]
===
match
---
trailer [24934,24942]
trailer [24965,24973]
===
match
---
comparison [18778,18853]
comparison [18809,18884]
===
match
---
string: 'A' [9547,9550]
string: 'A' [9578,9581]
===
match
---
sync_comp_for [58648,58665]
sync_comp_for [58679,58696]
===
match
---
simple_stmt [7885,7920]
simple_stmt [7916,7951]
===
match
---
string: 'dag_default_view' [37297,37315]
string: 'dag_default_view' [37328,37346]
===
match
---
name: dag_run_state [54991,55004]
name: dag_run_state [55022,55035]
===
match
---
assert_stmt [42912,42947]
assert_stmt [42943,42978]
===
match
---
trailer [48136,48168]
trailer [48167,48199]
===
match
---
operator: , [48011,48012]
operator: , [48042,48043]
===
match
---
name: op4 [38968,38971]
name: op4 [38999,39002]
===
match
---
operator: = [51301,51302]
operator: = [51332,51333]
===
match
---
argument [39801,39813]
argument [39832,39844]
===
match
---
atom_expr [39955,39985]
atom_expr [39986,40016]
===
match
---
name: DagModel [35480,35488]
name: DagModel [35511,35519]
===
match
---
name: DummyOperator [68808,68821]
name: DummyOperator [70432,70445]
===
match
---
name: DEFAULT_DATE [17281,17293]
name: DEFAULT_DATE [17312,17324]
===
match
---
atom_expr [18745,18761]
atom_expr [18776,18792]
===
match
---
name: get_template_env [19965,19981]
name: get_template_env [19996,20012]
===
match
---
operator: , [34384,34385]
operator: , [34415,34416]
===
match
---
trailer [36846,36856]
trailer [36877,36887]
===
match
---
name: dag [7932,7935]
name: dag [7963,7966]
===
match
---
name: create_session [49712,49726]
name: create_session [49743,49757]
===
match
---
operator: = [37633,37634]
operator: = [37664,37665]
===
match
---
name: task [21933,21937]
name: task [21964,21968]
===
match
---
expr_stmt [42003,42036]
expr_stmt [42034,42067]
===
match
---
atom_expr [7408,7415]
atom_expr [7439,7446]
===
match
---
arglist [4159,4175]
arglist [4190,4206]
===
match
---
trailer [51366,51380]
trailer [51397,51411]
===
match
---
name: pickle [48785,48791]
name: pickle [48816,48822]
===
match
---
arglist [70889,70899]
arglist [72513,72523]
===
match
---
operator: = [68205,68206]
operator: = [69829,69830]
===
match
---
string: "test1" [17784,17791]
string: "test1" [17815,17822]
===
match
---
name: RUNNING [52276,52283]
name: RUNNING [52307,52314]
===
match
---
operator: = [78074,78075]
operator: = [79698,79699]
===
match
---
assert_stmt [65689,65764]
assert_stmt [67313,67388]
===
match
---
trailer [38125,38135]
trailer [38156,38166]
===
match
---
comparison [32894,32967]
comparison [32925,32998]
===
match
---
string: "task_5" [75933,75941]
string: "task_5" [77557,77565]
===
match
---
trailer [10035,10056]
trailer [10066,10087]
===
match
---
operator: @ [75152,75153]
operator: @ [76776,76777]
===
match
---
trailer [24880,24899]
trailer [24911,24930]
===
match
---
name: session [31653,31660]
name: session [31684,31691]
===
match
---
string: 'a.py' [69661,69667]
string: 'a.py' [71285,71291]
===
match
---
name: DAG [65044,65047]
name: DAG [66668,66671]
===
match
---
argument [48082,48099]
argument [48113,48130]
===
match
---
atom_expr [73892,73909]
atom_expr [75516,75533]
===
match
---
string: 'test' [53302,53308]
string: 'test' [53333,53339]
===
match
---
string: 'task_1' [77597,77605]
string: 'task_1' [79221,79229]
===
match
---
argument [18029,18043]
argument [18060,18074]
===
match
---
trailer [63227,63236]
trailer [63258,63267]
===
match
---
trailer [30119,30136]
trailer [30150,30167]
===
match
---
operator: = [73763,73764]
operator: = [75387,75388]
===
match
---
trailer [69171,69175]
trailer [70795,70799]
===
match
---
operator: = [41915,41916]
operator: = [41946,41947]
===
match
---
expr_stmt [53430,53453]
expr_stmt [53461,53484]
===
match
---
simple_stmt [9979,10015]
simple_stmt [10010,10046]
===
match
---
name: default_args [59028,59040]
name: default_args [59059,59071]
===
match
---
arglist [34364,34385]
arglist [34395,34416]
===
match
---
param [11817,11821]
param [11848,11852]
===
match
---
trailer [4831,4845]
trailer [4862,4876]
===
match
---
atom [49881,50331]
atom [49912,50362]
===
match
---
comparison [51503,51531]
comparison [51534,51562]
===
match
---
trailer [38639,38644]
trailer [38670,38675]
===
match
---
argument [74150,74180]
argument [75774,75804]
===
match
---
name: DAG [29070,29073]
name: DAG [29101,29104]
===
match
---
simple_stmt [74969,75037]
simple_stmt [76593,76661]
===
match
---
name: owners [33135,33141]
name: owners [33166,33172]
===
match
---
simple_stmt [47806,47862]
simple_stmt [47837,47893]
===
match
---
trailer [25622,25631]
trailer [25653,25662]
===
match
---
simple_stmt [26078,26150]
simple_stmt [26109,26181]
===
match
---
operator: == [58692,58694]
operator: == [58723,58725]
===
match
---
string: 'dag-bulk-sync-3' [28684,28701]
string: 'dag-bulk-sync-3' [28715,28732]
===
match
---
name: datetime [78542,78550]
name: datetime [80166,80174]
===
match
---
expr_stmt [70663,70851]
expr_stmt [72287,72475]
===
match
---
simple_stmt [47792,47797]
simple_stmt [47823,47828]
===
match
---
assert_stmt [39105,39140]
assert_stmt [39136,39171]
===
match
---
with_stmt [75603,75995]
with_stmt [77227,77619]
===
match
---
atom_expr [69349,69364]
atom_expr [70973,70988]
===
match
---
number: 2020 [62683,62687]
number: 2020 [62714,62718]
===
match
---
simple_stmt [54506,54522]
simple_stmt [54537,54553]
===
match
---
expr_stmt [39495,39528]
expr_stmt [39526,39559]
===
match
---
parameters [4279,4285]
parameters [4310,4316]
===
match
---
comparison [11251,11278]
comparison [11282,11309]
===
match
---
operator: = [59516,59517]
operator: = [59547,59548]
===
match
---
name: task_5 [75987,75993]
name: task_5 [77611,77617]
===
match
---
suite [69992,70017]
suite [71616,71641]
===
match
---
import_from [2235,2293]
import_from [2266,2324]
===
match
---
simple_stmt [49205,49235]
simple_stmt [49236,49266]
===
match
---
name: DummyOperator [41531,41544]
name: DummyOperator [41562,41575]
===
match
---
operator: , [38433,38434]
operator: , [38464,38465]
===
match
---
simple_stmt [21501,21511]
simple_stmt [21532,21542]
===
match
---
string: 'child_dag' [8996,9007]
string: 'child_dag' [9027,9038]
===
match
---
operator: = [51442,51443]
operator: = [51473,51474]
===
match
---
name: state [55790,55795]
name: state [55821,55826]
===
match
---
argument [45960,45980]
argument [45991,46011]
===
match
---
argument [20216,20290]
argument [20247,20321]
===
match
---
trailer [5800,5804]
trailer [5831,5835]
===
match
---
operator: = [38903,38904]
operator: = [38934,38935]
===
match
---
trailer [27817,27819]
trailer [27848,27850]
===
match
---
name: task_3 [75971,75977]
name: task_3 [77595,77601]
===
match
---
dictorsetmaker [40744,40760]
dictorsetmaker [40775,40791]
===
match
---
funcdef [19684,19740]
funcdef [19715,19771]
===
match
---
name: DummyOperator [7801,7814]
name: DummyOperator [7832,7845]
===
match
---
name: orm_dag [37778,37785]
name: orm_dag [37809,37816]
===
match
---
string: 'test_scheduler_dagrun_once_with_timedelta_and_catchup_true' [62361,62421]
string: 'test_scheduler_dagrun_once_with_timedelta_and_catchup_true' [62392,62452]
===
match
---
operator: , [77821,77822]
operator: , [79445,79446]
===
match
---
trailer [54065,54120]
trailer [54096,54151]
===
match
---
atom_expr [14170,14192]
atom_expr [14201,14223]
===
match
---
name: op2 [10468,10471]
name: op2 [10499,10502]
===
match
---
operator: , [19247,19248]
operator: , [19278,19279]
===
match
---
expr_stmt [17564,17587]
expr_stmt [17595,17618]
===
match
---
simple_stmt [8730,8770]
simple_stmt [8761,8801]
===
match
---
name: start_date [27745,27755]
name: start_date [27776,27786]
===
match
---
name: dag_id [53033,53039]
name: dag_id [53064,53070]
===
match
---
comparison [5796,5865]
comparison [5827,5896]
===
match
---
param [69783,69800]
param [71407,71424]
===
match
---
name: params2 [4824,4831]
name: params2 [4855,4862]
===
match
---
simple_stmt [53072,53134]
simple_stmt [53103,53165]
===
match
---
operator: , [31275,31276]
operator: , [31306,31307]
===
match
---
argument [68839,68846]
argument [70463,70470]
===
match
---
param [54385,54390]
param [54416,54421]
===
match
---
operator: , [58153,58154]
operator: , [58184,58185]
===
match
---
operator: = [73565,73566]
operator: = [75189,75190]
===
match
---
name: datetime [26493,26501]
name: datetime [26524,26532]
===
match
---
string: "t1" [38858,38862]
string: "t1" [38889,38893]
===
match
---
operator: = [75883,75884]
operator: = [77507,77508]
===
match
---
name: orm_dag [37201,37208]
name: orm_dag [37232,37239]
===
match
---
trailer [70879,70888]
trailer [72503,72512]
===
match
---
atom_expr [74608,74625]
atom_expr [76232,76249]
===
match
---
trailer [66286,66302]
trailer [67910,67926]
===
match
---
atom_expr [22832,22854]
atom_expr [22863,22885]
===
match
---
atom_expr [75282,75295]
atom_expr [76906,76919]
===
match
---
name: airflow [1794,1801]
name: airflow [1800,1807]
===
match
---
atom_expr [28766,28777]
atom_expr [28797,28808]
===
match
---
name: create_dagrun [67064,67077]
name: create_dagrun [68688,68701]
===
match
---
with_item [39955,39995]
with_item [39986,40026]
===
match
---
name: session [52603,52610]
name: session [52634,52641]
===
match
---
string: "test" [70697,70703]
string: "test" [72321,72327]
===
match
---
simple_stmt [74055,74126]
simple_stmt [75679,75750]
===
match
---
assert_stmt [71690,71717]
assert_stmt [73314,73341]
===
match
---
simple_stmt [27716,27795]
simple_stmt [27747,27826]
===
match
---
argument [74553,74583]
argument [76177,76207]
===
match
---
operator: , [32298,32299]
operator: , [32329,32330]
===
match
---
name: schedule_interval [23512,23529]
name: schedule_interval [23543,23560]
===
match
---
name: id [42245,42247]
name: id [42276,42278]
===
match
---
string: """         Make sure DST transitions are properly observed         """ [22083,22154]
string: """         Make sure DST transitions are properly observed         """ [22114,22185]
===
match
---
operator: , [64342,64343]
operator: , [65966,65967]
===
match
---
operator: , [55528,55529]
operator: , [55559,55560]
===
match
---
trailer [36200,36214]
trailer [36231,36245]
===
match
---
simple_stmt [27551,27588]
simple_stmt [27582,27619]
===
match
---
atom_expr [53822,53834]
atom_expr [53853,53865]
===
match
---
name: op4 [39449,39452]
name: op4 [39480,39483]
===
match
---
operator: = [18374,18375]
operator: = [18405,18406]
===
match
---
testlist_comp [30509,30539]
testlist_comp [30540,30570]
===
match
---
atom_expr [57403,57432]
atom_expr [57434,57463]
===
match
---
name: task_instance [57160,57173]
name: task_instance [57191,57204]
===
match
---
operator: , [53615,53616]
operator: , [53646,53647]
===
match
---
atom_expr [54916,54929]
atom_expr [54947,54960]
===
match
---
operator: = [62581,62582]
operator: = [62612,62613]
===
match
---
trailer [18301,18308]
trailer [18332,18339]
===
match
---
name: state [18570,18575]
name: state [18601,18606]
===
match
---
argument [18352,18366]
argument [18383,18397]
===
match
---
trailer [29935,29941]
trailer [29966,29972]
===
match
---
simple_stmt [16702,16711]
simple_stmt [16733,16742]
===
match
---
name: State [19561,19566]
name: State [19592,19597]
===
match
---
simple_stmt [29316,29490]
simple_stmt [29347,29521]
===
match
---
name: task_decorator [72947,72961]
name: task_decorator [74571,74585]
===
match
---
operator: = [47928,47929]
operator: = [47959,47960]
===
match
---
atom [49985,50025]
atom [50016,50056]
===
match
---
import_from [1268,1298]
import_from [1274,1304]
===
match
---
operator: { [49689,49690]
operator: { [49720,49721]
===
match
---
name: TI [1584,1586]
name: TI [1590,1592]
===
match
---
trailer [31818,31830]
trailer [31849,31861]
===
match
---
name: start_date [57950,57960]
name: start_date [57981,57991]
===
match
---
simple_stmt [48425,48443]
simple_stmt [48456,48474]
===
match
---
operator: , [57428,57429]
operator: , [57459,57460]
===
match
---
operator: , [29756,29757]
operator: , [29787,29788]
===
match
---
assert_stmt [49332,49370]
assert_stmt [49363,49401]
===
match
---
number: 2020 [62464,62468]
number: 2020 [62495,62499]
===
match
---
operator: , [76051,76052]
operator: , [77675,77676]
===
match
---
funcdef [10190,11322]
funcdef [10221,11353]
===
match
---
name: get_dagmodel [49559,49571]
name: get_dagmodel [49590,49602]
===
match
---
simple_stmt [41473,41513]
simple_stmt [41504,41544]
===
match
---
trailer [28736,28785]
trailer [28767,28816]
===
match
---
assert_stmt [36403,36433]
assert_stmt [36434,36464]
===
match
---
param [5304,5308]
param [5335,5339]
===
match
---
operator: , [50139,50140]
operator: , [50170,50171]
===
match
---
name: task_instance_1 [54143,54158]
name: task_instance_1 [54174,54189]
===
match
---
operator: , [27437,27438]
operator: , [27468,27469]
===
match
---
decorator [61156,61200]
decorator [61187,61231]
===
match
---
parameters [13275,13281]
parameters [13306,13312]
===
match
---
expr_stmt [38968,39001]
expr_stmt [38999,39032]
===
match
---
name: dag [13130,13133]
name: dag [13161,13164]
===
match
---
operator: = [35767,35768]
operator: = [35798,35799]
===
match
---
trailer [24677,24682]
trailer [24708,24713]
===
match
---
trailer [18671,18677]
trailer [18702,18708]
===
match
---
operator: , [63703,63704]
operator: , [65327,65328]
===
match
---
simple_stmt [47160,47182]
simple_stmt [47191,47213]
===
match
---
assert_stmt [72130,72164]
assert_stmt [73754,73788]
===
match
---
trailer [46901,46908]
trailer [46932,46939]
===
match
---
operator: , [28701,28702]
operator: , [28732,28733]
===
match
---
name: OnceTimetable [50217,50230]
name: OnceTimetable [50248,50261]
===
match
---
atom_expr [11295,11314]
atom_expr [11326,11345]
===
match
---
atom_expr [2700,2716]
atom_expr [2731,2747]
===
match
---
argument [53597,53615]
argument [53628,53646]
===
match
---
argument [59325,59350]
argument [59356,59381]
===
match
---
suite [40324,40762]
suite [40355,40793]
===
match
---
expr_stmt [41525,41558]
expr_stmt [41556,41589]
===
match
---
simple_stmt [7982,8004]
simple_stmt [8013,8035]
===
match
---
number: 10 [64350,64352]
number: 10 [65974,65976]
===
match
---
string: 'no rule' [17445,17454]
string: 'no rule' [17476,17485]
===
match
---
atom_expr [29070,29096]
atom_expr [29101,29127]
===
match
---
name: re [14781,14783]
name: re [14812,14814]
===
match
---
string: "dag run start_date loses precision " [47318,47355]
string: "dag run start_date loses precision " [47349,47386]
===
match
---
name: next_info [58385,58394]
name: next_info [58416,58425]
===
match
---
name: dag_id [64740,64746]
name: dag_id [66364,66370]
===
match
---
operator: == [22894,22896]
operator: == [22925,22927]
===
match
---
with_item [44033,44060]
with_item [44064,44091]
===
match
---
name: dag [62868,62871]
name: dag [62899,62902]
===
match
---
name: self [75282,75286]
name: self [76906,76910]
===
match
---
arglist [64174,64215]
arglist [65798,65839]
===
match
---
operator: = [58336,58337]
operator: = [58367,58368]
===
match
---
simple_stmt [9771,9813]
simple_stmt [9802,9844]
===
match
---
name: tzinfo [26905,26911]
name: tzinfo [26936,26942]
===
match
---
operator: = [16255,16256]
operator: = [16286,16287]
===
match
---
operator: + [56852,56853]
operator: + [56883,56884]
===
match
---
assert_stmt [58675,58703]
assert_stmt [58706,58734]
===
match
---
arglist [18275,18308]
arglist [18306,18339]
===
match
---
simple_stmt [43934,44019]
simple_stmt [43965,44050]
===
match
---
trailer [18618,18626]
trailer [18649,18657]
===
match
---
expr_stmt [42530,42575]
expr_stmt [42561,42606]
===
match
---
atom [11445,11464]
atom [11476,11495]
===
match
---
expr_stmt [22428,22464]
expr_stmt [22459,22495]
===
match
---
name: subdag [54916,54922]
name: subdag [54947,54953]
===
match
---
operator: == [76209,76211]
operator: == [77833,77835]
===
match
---
operator: , [53834,53835]
operator: , [53865,53866]
===
match
---
number: 1 [65756,65757]
number: 1 [67380,67381]
===
match
---
operator: , [77832,77833]
operator: , [79456,79457]
===
match
---
name: datetime [62978,62986]
name: datetime [63009,63017]
===
match
---
name: merge [18699,18704]
name: merge [18730,18735]
===
match
---
simple_stmt [53049,53064]
simple_stmt [53080,53095]
===
match
---
trailer [62586,62603]
trailer [62617,62634]
===
match
---
operator: , [27889,27890]
operator: , [27920,27921]
===
match
---
operator: } [64966,64967]
operator: } [66590,66591]
===
match
---
trailer [55755,55757]
trailer [55786,55788]
===
match
---
name: DEFAULT_DATE [45512,45524]
name: DEFAULT_DATE [45543,45555]
===
match
---
name: unittest [70639,70647]
name: unittest [72263,72271]
===
match
---
name: start_date [25686,25696]
name: start_date [25717,25727]
===
match
---
param [17493,17497]
param [17524,17528]
===
match
---
operator: , [68846,68847]
operator: , [70470,70471]
===
match
---
expr_stmt [56079,56104]
expr_stmt [56110,56135]
===
match
---
fstring [15015,15030]
fstring [15046,15061]
===
match
---
atom_expr [55427,55453]
atom_expr [55458,55484]
===
match
---
name: task_id [3752,3759]
name: task_id [3783,3790]
===
match
---
trailer [17750,17764]
trailer [17781,17795]
===
match
---
operator: = [58314,58315]
operator: = [58345,58346]
===
match
---
operator: = [44262,44263]
operator: = [44293,44294]
===
match
---
name: value [74210,74215]
name: value [75834,75839]
===
match
---
string: "2018-10-28T02:55:00+02:00" [22352,22379]
string: "2018-10-28T02:55:00+02:00" [22383,22410]
===
match
---
name: models [1320,1326]
name: models [1326,1332]
===
match
---
operator: = [70676,70677]
operator: = [72300,72301]
===
match
---
number: 2 [19175,19176]
number: 2 [19206,19207]
===
match
---
atom_expr [30302,30308]
atom_expr [30333,30339]
===
match
---
trailer [51212,51219]
trailer [51243,51250]
===
match
---
operator: == [32774,32776]
operator: == [32805,32807]
===
match
---
operator: == [30606,30608]
operator: == [30637,30639]
===
match
---
string: 'webserver' [37284,37295]
string: 'webserver' [37315,37326]
===
match
---
name: dag [38568,38571]
name: dag [38599,38602]
===
match
---
name: incr [44345,44349]
name: incr [44376,44380]
===
match
---
name: days [62517,62521]
name: days [62548,62552]
===
match
---
with_item [14827,14903]
with_item [14858,14934]
===
match
---
trailer [37949,37973]
trailer [37980,38004]
===
match
---
name: dag [6970,6973]
name: dag [7001,7004]
===
match
---
atom [77563,77625]
atom [79187,79249]
===
match
---
arglist [62683,62693]
arglist [62714,62724]
===
match
---
name: start_date [21649,21659]
name: start_date [21680,21690]
===
match
---
atom_expr [43011,43025]
atom_expr [43042,43056]
===
match
---
string: 'end_date' [12455,12465]
string: 'end_date' [12486,12496]
===
match
---
name: settings [18610,18618]
name: settings [18641,18649]
===
match
---
name: dag_id [3277,3283]
name: dag_id [3308,3314]
===
match
---
operator: = [19584,19585]
operator: = [19615,19616]
===
match
---
name: DAG [36501,36504]
name: DAG [36532,36535]
===
match
---
argument [38482,38507]
argument [38513,38538]
===
match
---
argument [70834,70843]
argument [72458,72467]
===
match
---
assert_stmt [4752,4808]
assert_stmt [4783,4839]
===
match
---
simple_stmt [6989,7011]
simple_stmt [7020,7042]
===
match
---
atom_expr [69500,69515]
atom_expr [71124,71139]
===
match
---
comparison [60742,60771]
comparison [60773,60802]
===
match
---
arglist [67319,67384]
arglist [68943,69008]
===
match
---
expr_stmt [17000,17023]
expr_stmt [17031,17054]
===
match
---
operator: == [61771,61773]
operator: == [61802,61804]
===
match
---
exprlist [15293,15301]
exprlist [15324,15332]
===
match
---
name: info [9829,9833]
name: info [9860,9864]
===
match
---
atom_expr [24743,24765]
atom_expr [24774,24796]
===
match
---
name: dag_diff_name [49296,49309]
name: dag_diff_name [49327,49340]
===
match
---
argument [31140,31155]
argument [31171,31186]
===
match
---
operator: = [43817,43818]
operator: = [43848,43849]
===
match
---
atom_expr [24053,24075]
atom_expr [24084,24106]
===
match
---
operator: } [29488,29489]
operator: } [29519,29520]
===
match
---
argument [78253,78260]
argument [79877,79884]
===
match
---
suite [73169,73198]
suite [74793,74822]
===
match
---
operator: == [7240,7242]
operator: == [7271,7273]
===
match
---
trailer [60762,60769]
trailer [60793,60800]
===
match
---
name: permissions [66356,66367]
name: permissions [67980,67991]
===
match
---
operator: = [41876,41877]
operator: = [41907,41908]
===
match
---
name: split [40107,40112]
name: split [40138,40143]
===
match
---
operator: = [46834,46835]
operator: = [46865,46866]
===
match
---
name: DummyOperator [39363,39376]
name: DummyOperator [39394,39407]
===
match
---
operator: , [1556,1557]
operator: , [1562,1563]
===
match
---
suite [71179,71196]
suite [72803,72820]
===
match
---
trailer [70768,70775]
trailer [72392,72399]
===
match
---
name: operators [1852,1861]
name: operators [1858,1867]
===
match
---
number: 2 [78075,78076]
number: 2 [79699,79700]
===
match
---
name: ids [78627,78630]
name: ids [80251,80254]
===
match
---
name: default_args [74150,74162]
name: default_args [75774,75786]
===
match
---
name: owner [68848,68853]
name: owner [70472,70477]
===
match
---
name: logical_date [64304,64316]
name: logical_date [65928,65940]
===
match
---
trailer [37113,37119]
trailer [37144,37150]
===
match
---
operator: == [57241,57243]
operator: == [57272,57274]
===
match
---
name: op5 [39568,39571]
name: op5 [39599,39602]
===
match
---
atom_expr [74389,74406]
atom_expr [76013,76030]
===
match
---
trailer [2802,2811]
trailer [2833,2842]
===
match
---
name: jinja_env [20099,20108]
name: jinja_env [20130,20139]
===
match
---
operator: = [53416,53417]
operator: = [53447,53448]
===
match
---
operator: , [13145,13146]
operator: , [13176,13177]
===
match
---
atom_expr [50109,50138]
atom_expr [50140,50169]
===
match
---
simple_stmt [13327,13338]
simple_stmt [13358,13369]
===
match
---
arglist [6955,6978]
arglist [6986,7009]
===
match
---
trailer [67974,67976]
trailer [69598,69600]
===
match
---
comparison [20000,20028]
comparison [20031,20059]
===
match
---
name: dag [55727,55730]
name: dag [55758,55761]
===
match
---
atom_expr [68512,68535]
atom_expr [70136,70159]
===
match
---
testlist_comp [28537,28566]
testlist_comp [28568,28597]
===
match
---
name: timezone [26534,26542]
name: timezone [26565,26573]
===
match
---
name: DummyOperator [9660,9673]
name: DummyOperator [9691,9704]
===
match
---
name: dag [75325,75328]
name: dag [76949,76952]
===
match
---
name: f [20809,20810]
name: f [20840,20841]
===
match
---
trailer [55918,55926]
trailer [55949,55957]
===
match
---
name: dag [49319,49322]
name: dag [49350,49353]
===
match
---
operator: , [32257,32258]
operator: , [32288,32289]
===
match
---
assert_stmt [72589,72616]
assert_stmt [74213,74240]
===
match
---
simple_stmt [11159,11194]
simple_stmt [11190,11225]
===
match
---
fstring_end: ' [43178,43179]
fstring_end: ' [43209,43210]
===
match
---
name: filter [35037,35043]
name: filter [35068,35074]
===
match
---
atom_expr [17347,17378]
atom_expr [17378,17409]
===
match
---
trailer [11121,11128]
trailer [11152,11159]
===
match
---
atom_expr [39787,39814]
atom_expr [39818,39845]
===
match
---
atom_expr [5509,5579]
atom_expr [5540,5610]
===
match
---
name: args [64859,64863]
name: args [66483,66487]
===
match
---
operator: == [3376,3378]
operator: == [3407,3409]
===
match
---
atom_expr [39597,39607]
atom_expr [39628,39638]
===
match
---
name: task_id [10488,10495]
name: task_id [10519,10526]
===
match
---
name: DagRunType [51202,51212]
name: DagRunType [51233,51243]
===
match
---
trailer [72885,72898]
trailer [74509,74522]
===
match
---
name: dag_id [3287,3293]
name: dag_id [3318,3324]
===
match
---
operator: , [69045,69046]
operator: , [70669,70670]
===
match
---
operator: , [10276,10277]
operator: , [10307,10308]
===
match
---
arglist [28105,28169]
arglist [28136,28200]
===
match
---
name: handle_callback [44286,44301]
name: handle_callback [44317,44332]
===
match
---
atom_expr [54506,54521]
atom_expr [54537,54552]
===
match
---
atom_expr [40726,40739]
atom_expr [40757,40770]
===
match
---
atom_expr [35238,35256]
atom_expr [35269,35287]
===
match
---
trailer [57269,57279]
trailer [57300,57310]
===
match
---
param [71591,71594]
param [73215,73218]
===
match
---
operator: { [9370,9371]
operator: { [9401,9402]
===
match
---
operator: = [45987,45988]
operator: = [46018,46019]
===
match
---
name: dag [66485,66488]
name: dag [68109,68112]
===
match
---
trailer [24720,24726]
trailer [24751,24757]
===
match
---
expr_stmt [38922,38955]
expr_stmt [38953,38986]
===
match
---
string: 'task' [53370,53376]
string: 'task' [53401,53407]
===
match
---
atom_expr [17836,17966]
atom_expr [17867,17997]
===
match
---
trailer [24069,24075]
trailer [24100,24106]
===
match
---
funcdef [72908,73053]
funcdef [74532,74677]
===
match
---
string: "@once" [57452,57459]
string: "@once" [57483,57490]
===
match
---
name: state [54100,54105]
name: state [54131,54136]
===
match
---
atom [66017,66220]
atom [67641,67844]
===
match
---
suite [8097,9264]
suite [8128,9295]
===
match
---
atom_expr [66581,66599]
atom_expr [68205,68223]
===
match
---
string: "/usr/local/airflow/dags/non_existing_path.py" [37445,37491]
string: "/usr/local/airflow/dags/non_existing_path.py" [37476,37522]
===
match
---
trailer [43281,43287]
trailer [43312,43318]
===
match
---
name: query [27946,27951]
name: query [27977,27982]
===
match
---
name: DEFAULT_DATE [73869,73881]
name: DEFAULT_DATE [75493,75505]
===
match
---
name: stdout [40100,40106]
name: stdout [40131,40137]
===
match
---
name: DAG [8383,8386]
name: DAG [8414,8417]
===
match
---
number: 0 [9967,9968]
number: 0 [9998,9999]
===
match
---
operator: , [60882,60883]
operator: , [60913,60914]
===
match
---
suite [5310,5580]
suite [5341,5611]
===
match
---
operator: , [76310,76311]
operator: , [77934,77935]
===
match
---
trailer [12662,12669]
trailer [12693,12700]
===
match
---
simple_stmt [7087,7116]
simple_stmt [7118,7147]
===
match
---
number: 2016 [63681,63685]
number: 2016 [65305,65309]
===
match
---
atom_expr [62716,62761]
atom_expr [62747,62792]
===
match
---
name: test_create_dagrun_run_id_is_generated [50571,50609]
name: test_create_dagrun_run_id_is_generated [50602,50640]
===
match
---
operator: , [31542,31543]
operator: , [31573,31574]
===
match
---
atom_expr [36501,36557]
atom_expr [36532,36588]
===
match
---
name: expected_timetable [50409,50427]
name: expected_timetable [50440,50458]
===
match
---
string: "2018-10-26T03:00:00+02:00" [23672,23699]
string: "2018-10-26T03:00:00+02:00" [23703,23730]
===
match
---
operator: , [32114,32115]
operator: , [32145,32146]
===
match
---
operator: == [34072,34074]
operator: == [34103,34105]
===
match
---
operator: = [26084,26085]
operator: = [26115,26116]
===
match
---
name: dag [24656,24659]
name: dag [24687,24690]
===
match
---
name: dr [51358,51360]
name: dr [51389,51391]
===
match
---
trailer [39723,39760]
trailer [39754,39791]
===
match
---
operator: = [46763,46764]
operator: = [46794,46795]
===
match
---
comparison [49291,49323]
comparison [49322,49354]
===
match
---
name: date [58631,58635]
name: date [58662,58666]
===
match
---
name: task_dict [16898,16907]
name: task_dict [16929,16938]
===
match
---
argument [66977,67045]
argument [68601,68669]
===
match
---
name: access_control [66744,66758]
name: access_control [68368,68382]
===
match
---
trailer [20628,20645]
trailer [20659,20676]
===
match
---
atom_expr [24379,24413]
atom_expr [24410,24444]
===
match
---
name: dag [12634,12637]
name: dag [12665,12668]
===
match
---
atom_expr [5406,5495]
atom_expr [5437,5526]
===
match
---
trailer [32517,32567]
trailer [32548,32598]
===
match
---
name: DagModel [37120,37128]
name: DagModel [37151,37159]
===
match
---
name: prev_local [24040,24050]
name: prev_local [24071,24081]
===
match
---
assert_stmt [19060,19159]
assert_stmt [19091,19190]
===
match
---
simple_stmt [20879,20918]
simple_stmt [20910,20949]
===
match
---
argument [33577,33591]
argument [33608,33622]
===
match
---
operator: = [17618,17619]
operator: = [17649,17650]
===
match
---
name: timedelta [69099,69108]
name: timedelta [70723,70732]
===
match
---
argument [10578,10589]
argument [10609,10620]
===
match
---
name: settings [32586,32594]
name: settings [32617,32625]
===
match
---
arglist [44246,44268]
arglist [44277,44299]
===
match
---
comp_op [42352,42358]
comp_op [42383,42389]
===
match
---
trailer [2933,2979]
trailer [2964,3010]
===
match
---
param [78730,78744]
param [80354,80368]
===
match
---
name: self [38682,38686]
name: self [38713,38717]
===
match
---
name: datetime [59662,59670]
name: datetime [59693,59701]
===
match
---
trailer [43302,43312]
trailer [43333,43343]
===
match
---
with_stmt [40396,40710]
with_stmt [40427,40741]
===
match
---
comparison [39112,39140]
comparison [39143,39171]
===
match
---
simple_stmt [34731,34755]
simple_stmt [34762,34786]
===
match
---
name: clear_db_runs [2529,2542]
name: clear_db_runs [2560,2573]
===
match
---
name: owners [32754,32760]
name: owners [32785,32791]
===
match
---
trailer [43075,43090]
trailer [43106,43121]
===
match
---
name: default_args [16192,16204]
name: default_args [16223,16235]
===
match
---
funcdef [6181,6449]
funcdef [6212,6480]
===
match
---
trailer [57494,57511]
trailer [57525,57542]
===
match
---
parameters [33390,33396]
parameters [33421,33427]
===
match
---
suite [57756,58764]
suite [57787,58795]
===
match
---
name: test_dag_id [18994,19005]
name: test_dag_id [19025,19036]
===
match
---
name: session [45194,45201]
name: session [45225,45232]
===
match
---
trailer [78178,78188]
trailer [79802,79812]
===
match
---
name: schedule_interval [66872,66889]
name: schedule_interval [68496,68513]
===
match
---
name: FAILED [52072,52078]
name: FAILED [52103,52109]
===
match
---
suite [3579,3891]
suite [3610,3922]
===
match
---
operator: , [52078,52079]
operator: , [52109,52110]
===
match
---
string: """         Test invalid `default_view` of DAG initialization         """ [5319,5392]
string: """         Test invalid `default_view` of DAG initialization         """ [5350,5423]
===
match
---
name: self [45542,45546]
name: self [45573,45577]
===
match
---
name: task_id [21102,21109]
name: task_id [21133,21140]
===
match
---
parameters [54384,54405]
parameters [54415,54436]
===
match
---
simple_stmt [57678,57703]
simple_stmt [57709,57734]
===
match
---
operator: , [56909,56910]
operator: , [56940,56941]
===
match
---
name: logical_date [62649,62661]
name: logical_date [62680,62692]
===
match
---
atom_expr [27603,27619]
atom_expr [27634,27650]
===
match
---
atom_expr [76964,77023]
atom_expr [78588,78647]
===
match
---
name: _name [27392,27397]
name: _name [27423,27428]
===
match
---
testlist_comp [55082,55126]
testlist_comp [55113,55157]
===
match
---
atom [19256,19271]
atom [19287,19302]
===
match
---
simple_stmt [47191,47273]
simple_stmt [47222,47304]
===
match
---
trailer [12965,12974]
trailer [12996,13005]
===
match
---
trailer [3365,3386]
trailer [3396,3417]
===
match
---
operator: , [77775,77776]
operator: , [79399,79400]
===
match
---
name: subdag [65570,65576]
name: subdag [67194,67200]
===
match
---
argument [44901,44918]
argument [44932,44949]
===
match
---
arglist [77971,78078]
arglist [79595,79702]
===
match
---
name: clear_db_runs [2851,2864]
name: clear_db_runs [2882,2895]
===
match
---
name: dag_diff_load_time [47975,47993]
name: dag_diff_load_time [48006,48024]
===
match
---
name: width [13291,13296]
name: width [13322,13327]
===
match
---
atom_expr [21318,21333]
atom_expr [21349,21364]
===
match
---
name: self [6220,6224]
name: self [6251,6255]
===
match
---
name: get_is_paused [36201,36214]
name: get_is_paused [36232,36245]
===
match
---
simple_stmt [36403,36434]
simple_stmt [36434,36465]
===
match
---
operator: , [27347,27348]
operator: , [27378,27379]
===
match
---
for_stmt [16618,16869]
for_stmt [16649,16900]
===
match
---
name: tzinfo [12663,12669]
name: tzinfo [12694,12700]
===
match
---
name: self [41830,41834]
name: self [41861,41865]
===
match
---
name: DummyOperator [14968,14981]
name: DummyOperator [14999,15012]
===
match
---
expr_stmt [75755,75795]
expr_stmt [77379,77419]
===
match
---
trailer [18148,18256]
trailer [18179,18287]
===
match
---
lambdef [43818,43827]
lambdef [43849,43858]
===
match
---
string: 'a_child' [9148,9157]
string: 'a_child' [9179,9188]
===
match
---
name: topological_list [9246,9262]
name: topological_list [9277,9293]
===
match
---
operator: == [75384,75386]
operator: == [77008,77010]
===
match
---
name: is_subdag [32474,32483]
name: is_subdag [32505,32514]
===
match
---
string: 'test_max_active_runs_not_none' [68048,68079]
string: 'test_max_active_runs_not_none' [69672,69703]
===
match
---
atom_expr [16576,16591]
atom_expr [16607,16622]
===
match
---
sync_comp_for [15238,15262]
sync_comp_for [15269,15293]
===
match
---
name: delete [3295,3301]
name: delete [3326,3332]
===
match
---
expr_stmt [8658,8717]
expr_stmt [8689,8748]
===
match
---
arglist [65354,65409]
arglist [66978,67033]
===
match
---
name: self [72881,72885]
name: self [74505,74509]
===
match
---
name: dr3 [18461,18464]
name: dr3 [18492,18495]
===
match
---
name: dag [29156,29159]
name: dag [29187,29190]
===
match
---
name: start_date [21005,21015]
name: start_date [21036,21046]
===
match
---
atom [45251,45264]
atom [45282,45295]
===
match
---
trailer [23623,23629]
trailer [23654,23660]
===
match
---
name: datetime [12895,12903]
name: datetime [12926,12934]
===
match
---
parameters [74039,74045]
parameters [75663,75669]
===
match
---
operator: , [77620,77621]
operator: , [79244,79245]
===
match
---
param [3572,3577]
param [3603,3608]
===
match
---
name: dag [58719,58722]
name: dag [58750,58753]
===
match
---
funcdef [28028,30776]
funcdef [28059,30807]
===
match
---
number: 1 [65225,65226]
number: 1 [66849,66850]
===
match
---
expr_stmt [68031,68122]
expr_stmt [69655,69746]
===
match
---
argument [76680,76702]
argument [78304,78326]
===
match
---
name: state [54982,54987]
name: state [55013,55018]
===
match
---
name: task [76108,76112]
name: task [77732,77736]
===
match
---
atom_expr [36046,36062]
atom_expr [36077,36093]
===
match
---
operator: @ [74135,74136]
operator: @ [75759,75760]
===
match
---
name: DummyOperator [9525,9538]
name: DummyOperator [9556,9569]
===
match
---
name: get_task_instances [74856,74874]
name: get_task_instances [76480,76498]
===
match
---
simple_stmt [33284,33329]
simple_stmt [33315,33360]
===
match
---
name: Session [53508,53515]
name: Session [53539,53546]
===
match
---
name: needed [69218,69224]
name: needed [70842,70848]
===
match
---
name: session [37067,37074]
name: session [37098,37105]
===
match
---
operator: , [78013,78014]
operator: , [79637,79638]
===
match
---
suite [6875,6980]
suite [6906,7011]
===
match
---
name: super [71024,71029]
name: super [72648,72653]
===
match
---
name: State [76593,76598]
name: State [78217,78222]
===
match
---
operator: = [67101,67102]
operator: = [68725,68726]
===
match
---
name: State [67153,67158]
name: State [68777,68782]
===
match
---
operator: == [23956,23958]
operator: == [23987,23989]
===
match
---
operator: = [38949,38950]
operator: = [38980,38981]
===
match
---
simple_stmt [22217,22316]
simple_stmt [22248,22347]
===
match
---
with_stmt [5176,5265]
with_stmt [5207,5296]
===
match
---
atom_expr [68557,68575]
atom_expr [70181,70199]
===
match
---
name: DEPRECATED_ACTION_CAN_DAG_READ [66134,66164]
name: DEPRECATED_ACTION_CAN_DAG_READ [67758,67788]
===
match
---
operator: , [47139,47140]
operator: , [47170,47171]
===
match
---
simple_stmt [43517,43552]
simple_stmt [43548,43583]
===
match
---
atom_expr [20686,20702]
atom_expr [20717,20733]
===
match
---
parameters [71780,71786]
parameters [73404,73410]
===
match
---
funcdef [44453,45565]
funcdef [44484,45596]
===
match
---
operator: >> [42053,42055]
operator: >> [42084,42086]
===
match
---
name: when [44117,44121]
name: when [44148,44152]
===
match
---
name: dag_decorator [71105,71118]
name: dag_decorator [72729,72742]
===
match
---
operator: == [47209,47211]
operator: == [47240,47242]
===
match
---
name: state [2216,2221]
name: state [2247,2252]
===
match
---
atom_expr [8664,8717]
atom_expr [8695,8748]
===
match
---
operator: , [76750,76751]
operator: , [78374,78375]
===
match
---
name: assert_called_with [44350,44368]
name: assert_called_with [44381,44399]
===
match
---
name: _offset [27236,27243]
name: _offset [27267,27274]
===
match
---
atom_expr [25726,25759]
atom_expr [25757,25790]
===
match
---
operator: , [4691,4692]
operator: , [4722,4723]
===
match
---
operator: , [60500,60501]
operator: , [60531,60532]
===
match
---
trailer [54839,54878]
trailer [54870,54909]
===
match
---
operator: , [54782,54783]
operator: , [54813,54814]
===
match
---
assert_stmt [19452,19602]
assert_stmt [19483,19633]
===
match
---
atom_expr [10840,10862]
atom_expr [10871,10893]
===
match
---
operator: { [33158,33159]
operator: { [33189,33190]
===
match
---
name: dagrun [52906,52912]
name: dagrun [52937,52943]
===
match
---
assert_stmt [65831,65924]
assert_stmt [67455,67548]
===
match
---
simple_stmt [21174,21213]
simple_stmt [21205,21244]
===
match
---
name: state [18017,18022]
name: state [18048,18053]
===
match
---
number: 10 [27446,27448]
number: 10 [27477,27479]
===
match
---
simple_stmt [38922,38956]
simple_stmt [38953,38987]
===
match
---
operator: , [70799,70800]
operator: , [72423,72424]
===
match
---
return_stmt [73486,73496]
return_stmt [75110,75120]
===
match
---
name: DAG [36135,36138]
name: DAG [36166,36169]
===
match
---
operator: = [51716,51717]
operator: = [51747,51748]
===
match
---
name: params [4205,4211]
name: params [4236,4242]
===
match
---
dotted_name [1381,1399]
dotted_name [1387,1405]
===
match
---
name: DummyOperator [63766,63779]
name: DummyOperator [65390,65403]
===
match
---
name: RUNNING [51616,51623]
name: RUNNING [51647,51654]
===
match
---
trailer [54891,54898]
trailer [54922,54929]
===
match
---
funcdef [38252,38662]
funcdef [38283,38693]
===
match
---
operator: = [61614,61615]
operator: = [61645,61646]
===
match
---
atom_expr [76899,76912]
atom_expr [78523,78536]
===
match
---
with_stmt [41845,42083]
with_stmt [41876,42114]
===
match
---
name: num [75195,75198]
name: num [76819,76822]
===
match
---
name: following_schedule [23784,23802]
name: following_schedule [23815,23833]
===
match
---
operator: , [30440,30441]
operator: , [30471,30472]
===
match
---
simple_stmt [45776,45810]
simple_stmt [45807,45841]
===
match
---
comparison [57547,57602]
comparison [57578,57633]
===
match
---
trailer [12518,12531]
trailer [12549,12562]
===
match
---
name: execution_date [31556,31570]
name: execution_date [31587,31601]
===
match
---
trailer [33932,33938]
trailer [33963,33969]
===
match
---
name: unittest [69944,69952]
name: unittest [71568,71576]
===
match
---
simple_stmt [60521,60564]
simple_stmt [60552,60595]
===
match
---
expr_stmt [63971,64151]
expr_stmt [65595,65775]
===
match
---
operator: , [45999,46000]
operator: , [46030,46031]
===
match
---
assert_stmt [55776,55812]
assert_stmt [55807,55843]
===
match
---
number: 5 [14743,14744]
number: 5 [14774,14775]
===
match
---
operator: = [8686,8687]
operator: = [8717,8718]
===
match
---
parameters [21389,21395]
parameters [21420,21426]
===
match
---
name: _next [25775,25780]
name: _next [25806,25811]
===
match
---
trailer [76422,76430]
trailer [78046,78054]
===
match
---
name: State [74691,74696]
name: State [76315,76320]
===
match
---
atom_expr [65394,65408]
atom_expr [67018,67032]
===
match
---
operator: , [49941,49942]
operator: , [49972,49973]
===
match
---
name: DAG [37506,37509]
name: DAG [37537,37540]
===
match
---
operator: = [72563,72564]
operator: = [74187,74188]
===
match
---
operator: @ [71104,71105]
operator: @ [72728,72729]
===
match
---
operator: = [8304,8305]
operator: = [8335,8336]
===
match
---
simple_stmt [44853,44946]
simple_stmt [44884,44977]
===
match
---
name: task_id [68822,68829]
name: task_id [70446,70453]
===
match
---
string: "t3" [39431,39435]
string: "t3" [39462,39466]
===
match
---
operator: = [68761,68762]
operator: = [70385,70386]
===
match
---
trailer [65712,65725]
trailer [67336,67349]
===
match
---
simple_stmt [3684,3697]
simple_stmt [3715,3728]
===
match
---
name: self [37380,37384]
name: self [37411,37415]
===
match
---
expr_stmt [18343,18386]
expr_stmt [18374,18417]
===
match
---
assert_stmt [21311,21347]
assert_stmt [21342,21378]
===
match
---
operator: = [21536,21537]
operator: = [21567,21568]
===
match
---
trailer [5740,5744]
trailer [5771,5775]
===
match
---
operator: = [27556,27557]
operator: = [27587,27588]
===
match
---
name: session [69257,69264]
name: session [70881,70888]
===
match
---
name: task_instance_1 [52307,52322]
name: task_instance_1 [52338,52353]
===
match
---
name: TI [76284,76286]
name: TI [77908,77910]
===
match
---
argument [61646,61659]
argument [61677,61690]
===
match
---
argument [45103,45124]
argument [45134,45155]
===
match
---
name: timedelta [18084,18093]
name: timedelta [18115,18124]
===
match
---
name: dag [43677,43680]
name: dag [43708,43711]
===
match
---
operator: = [26126,26127]
operator: = [26157,26158]
===
match
---
name: dag [53463,53466]
name: dag [53494,53497]
===
match
---
trailer [62673,62682]
trailer [62704,62713]
===
match
---
trailer [66052,66068]
trailer [67676,67692]
===
match
---
name: dag [48517,48520]
name: dag [48548,48551]
===
match
---
name: datetime [70880,70888]
name: datetime [72504,72512]
===
match
---
trailer [32926,32959]
trailer [32957,32990]
===
match
---
name: dag_eq [49255,49261]
name: dag_eq [49286,49292]
===
match
---
argument [64109,64140]
argument [65733,65764]
===
match
---
trailer [77301,77306]
trailer [78925,78930]
===
match
---
expr_stmt [57339,57469]
expr_stmt [57370,57500]
===
match
---
atom_expr [55913,55926]
atom_expr [55944,55957]
===
match
---
name: start [22331,22336]
name: start [22362,22367]
===
match
---
atom_expr [36576,36594]
atom_expr [36607,36625]
===
match
---
trailer [37801,37811]
trailer [37832,37842]
===
match
---
string: 'test_' [46964,46971]
string: 'test_' [46995,47002]
===
match
---
simple_stmt [33874,33906]
simple_stmt [33905,33937]
===
match
---
name: six_hours_ago_to_the_hour [60026,60051]
name: six_hours_ago_to_the_hour [60057,60082]
===
match
---
number: 1 [31475,31476]
number: 1 [31506,31507]
===
match
---
operator: = [53899,53900]
operator: = [53930,53931]
===
match
---
expr_stmt [18395,18420]
expr_stmt [18426,18451]
===
match
---
assert_stmt [33996,34035]
assert_stmt [34027,34066]
===
match
---
name: dag_id [37004,37010]
name: dag_id [37035,37041]
===
match
---
name: TI [18435,18437]
name: TI [18466,18468]
===
match
---
expr_stmt [14262,14294]
expr_stmt [14293,14325]
===
match
---
name: task_3 [75804,75810]
name: task_3 [77428,77434]
===
match
---
name: tasks [10023,10028]
name: tasks [10054,10059]
===
match
---
name: match [5438,5443]
name: match [5469,5474]
===
match
---
operator: = [50442,50443]
operator: = [50473,50474]
===
match
---
name: DummyOperator [75715,75728]
name: DummyOperator [77339,77352]
===
match
---
param [2828,2832]
param [2859,2863]
===
match
---
name: pendulum [23394,23402]
name: pendulum [23425,23433]
===
match
---
atom_expr [9790,9812]
atom_expr [9821,9843]
===
match
---
argument [33704,33813]
argument [33735,33844]
===
match
---
operator: = [18035,18036]
operator: = [18066,18067]
===
match
---
name: state [77090,77095]
name: state [78714,78719]
===
match
---
name: TestCase [2803,2811]
name: TestCase [2834,2842]
===
match
---
trailer [26542,26546]
trailer [26573,26577]
===
match
---
operator: = [7822,7823]
operator: = [7853,7854]
===
match
---
atom_expr [17981,18111]
atom_expr [18012,18142]
===
match
---
name: patch [37672,37677]
name: patch [37703,37708]
===
match
---
argument [44780,44793]
argument [44811,44824]
===
match
---
operator: , [39064,39065]
operator: , [39095,39096]
===
match
---
expr_stmt [39403,39436]
expr_stmt [39434,39467]
===
match
---
fstring_string: manual__ [50801,50809]
fstring_string: manual__ [50832,50840]
===
match
---
trailer [55250,55252]
trailer [55281,55283]
===
match
---
funcdef [72343,72550]
funcdef [73967,74174]
===
match
---
simple_stmt [49518,49535]
simple_stmt [49549,49566]
===
match
---
argument [20568,20603]
argument [20599,20634]
===
match
---
trailer [78252,78261]
trailer [79876,79885]
===
match
---
string: "task_3" [75835,75843]
string: "task_3" [77459,77467]
===
match
---
operator: , [70703,70704]
operator: , [72327,72328]
===
match
---
name: _next [24943,24948]
name: _next [24974,24979]
===
match
---
name: jinja_env [19949,19958]
name: jinja_env [19980,19989]
===
match
---
operator: , [39616,39617]
operator: , [39647,39648]
===
match
---
name: topological_list [11295,11311]
name: topological_list [11326,11342]
===
match
---
name: start_date [62435,62445]
name: start_date [62466,62476]
===
match
---
name: dag_id [34804,34810]
name: dag_id [34835,34841]
===
match
---
name: VALUE [70905,70910]
name: VALUE [72529,72534]
===
match
---
comparison [48507,48520]
comparison [48538,48551]
===
match
---
operator: == [64317,64319]
operator: == [65941,65943]
===
match
---
funcdef [21353,22026]
funcdef [21384,22057]
===
match
---
name: State [55858,55863]
name: State [55889,55894]
===
match
---
trailer [8918,8961]
trailer [8949,8992]
===
match
---
name: latest [78987,78993]
name: latest [80611,80617]
===
match
---
name: isoformat [25781,25790]
name: isoformat [25812,25821]
===
match
---
atom_expr [43591,43607]
atom_expr [43622,43638]
===
match
---
operator: , [10922,10923]
operator: , [10953,10954]
===
match
---
trailer [44429,44439]
trailer [44460,44470]
===
match
---
shift_expr [41571,41581]
shift_expr [41602,41612]
===
match
---
name: dag [72112,72115]
name: dag [73736,73739]
===
match
---
name: close [67969,67974]
name: close [69593,69598]
===
match
---
name: DAG [19319,19322]
name: DAG [19350,19353]
===
match
---
name: timedelta [44682,44691]
name: timedelta [44713,44722]
===
match
---
trailer [11052,11059]
trailer [11083,11090]
===
match
---
operator: = [70911,70912]
operator: = [72535,72536]
===
match
---
trailer [35399,35405]
trailer [35430,35436]
===
match
---
operator: , [14861,14862]
operator: , [14892,14893]
===
match
---
name: self [74654,74658]
name: self [76278,76282]
===
match
---
trailer [78058,78068]
trailer [79682,79692]
===
match
---
atom_expr [76612,76627]
atom_expr [78236,78251]
===
match
---
comparison [11482,11510]
comparison [11513,11541]
===
match
---
name: dag [31093,31096]
name: dag [31124,31127]
===
match
---
trailer [54947,54949]
trailer [54978,54980]
===
match
---
suite [29057,29097]
suite [29088,29128]
===
match
---
simple_stmt [74888,74921]
simple_stmt [76512,76545]
===
match
---
operator: = [67505,67506]
operator: = [69129,69130]
===
match
---
argument [21102,21115]
argument [21133,21146]
===
match
---
expr_stmt [23552,23585]
expr_stmt [23583,23616]
===
match
---
name: dag_id [45776,45782]
name: dag_id [45807,45813]
===
match
---
name: tasks [10109,10114]
name: tasks [10140,10145]
===
match
---
operator: , [52768,52769]
operator: , [52799,52800]
===
match
---
fstring_end: ' [16358,16359]
fstring_end: ' [16389,16390]
===
match
---
name: days [61625,61629]
name: days [61656,61660]
===
match
---
name: dag_id [43313,43319]
name: dag_id [43344,43350]
===
match
---
assert_stmt [24154,24208]
assert_stmt [24185,24239]
===
match
---
name: test_task_id [19234,19246]
name: test_task_id [19265,19277]
===
match
---
name: test_next_dagrun_info_once [57297,57323]
name: test_next_dagrun_info_once [57328,57354]
===
match
---
name: flush [69357,69362]
name: flush [70981,70986]
===
match
---
name: filter [3359,3365]
name: filter [3390,3396]
===
match
---
assert_stmt [50519,50561]
assert_stmt [50550,50592]
===
match
---
name: utc [24525,24528]
name: utc [24556,24559]
===
match
---
number: 3 [77896,77897]
number: 3 [79520,79521]
===
match
---
import_from [1979,2045]
import_from [2010,2076]
===
match
---
simple_stmt [41023,41070]
simple_stmt [41054,41101]
===
match
---
name: dag_id [51820,51826]
name: dag_id [51851,51857]
===
match
---
atom_expr [73600,73617]
atom_expr [75224,75241]
===
match
---
name: len [57127,57130]
name: len [57158,57161]
===
match
---
atom_expr [49266,49275]
atom_expr [49297,49306]
===
match
---
atom_expr [57047,57056]
atom_expr [57078,57087]
===
match
---
atom [54304,54320]
atom [54335,54351]
===
match
---
operator: = [27150,27151]
operator: = [27181,27182]
===
match
---
name: session [32636,32643]
name: session [32667,32674]
===
match
---
number: 5 [62051,62052]
number: 5 [62082,62083]
===
match
---
atom_expr [65570,65587]
atom_expr [67194,67211]
===
match
---
dictorsetmaker [11446,11463]
dictorsetmaker [11477,11494]
===
match
---
argument [66495,66527]
argument [68119,68151]
===
match
---
string: 'a_child' [9009,9018]
string: 'a_child' [9040,9049]
===
match
---
funcdef [74269,74317]
funcdef [75893,75941]
===
match
---
operator: = [64746,64747]
operator: = [66370,66371]
===
match
---
atom_expr [71211,71226]
atom_expr [72835,72850]
===
match
---
arglist [35314,35353]
arglist [35345,35384]
===
match
---
expr_stmt [25718,25759]
expr_stmt [25749,25790]
===
match
---
trailer [34905,34916]
trailer [34936,34947]
===
match
---
operator: = [38494,38495]
operator: = [38525,38526]
===
match
---
operator: , [44309,44310]
operator: , [44340,44341]
===
match
---
number: 25 [26511,26513]
number: 25 [26542,26544]
===
match
---
trailer [36872,36878]
trailer [36903,36909]
===
match
---
name: relative_fileloc [69886,69902]
name: relative_fileloc [71510,71526]
===
match
---
trailer [32473,32483]
trailer [32504,32514]
===
match
---
simple_stmt [1500,1587]
simple_stmt [1506,1593]
===
match
---
operator: = [5568,5569]
operator: = [5599,5600]
===
match
---
name: timezone [60291,60299]
name: timezone [60322,60330]
===
match
---
name: test_next_dagrun_after_auto_align [63258,63291]
name: test_next_dagrun_after_auto_align [64882,64915]
===
match
---
name: start_date [13629,13639]
name: start_date [13660,13670]
===
match
---
name: pattern [15613,15620]
name: pattern [15644,15651]
===
match
---
operator: = [78878,78879]
operator: = [80502,80503]
===
match
---
operator: = [68785,68786]
operator: = [70409,70410]
===
match
---
name: TEST_DATE [46859,46868]
name: TEST_DATE [46890,46899]
===
match
---
dictorsetmaker [28430,28484]
dictorsetmaker [28461,28515]
===
match
---
operator: = [52102,52103]
operator: = [52133,52134]
===
match
---
string: "test_schedule_dag_once" [45785,45809]
string: "test_schedule_dag_once" [45816,45840]
===
match
---
simple_stmt [38830,38864]
simple_stmt [38861,38895]
===
match
---
name: op2 [7063,7066]
name: op2 [7094,7097]
===
match
---
operator: = [9636,9637]
operator: = [9667,9668]
===
match
---
argument [63652,63703]
argument [65276,65327]
===
match
---
name: DEFAULT_ARGS [73348,73360]
name: DEFAULT_ARGS [74972,74984]
===
match
---
operator: = [69032,69033]
operator: = [70656,70657]
===
match
---
name: get_state [77495,77504]
name: get_state [79119,79128]
===
match
---
operator: = [40442,40443]
operator: = [40473,40474]
===
match
---
atom_expr [37788,37851]
atom_expr [37819,37882]
===
match
---
name: dr [51052,51054]
name: dr [51083,51085]
===
match
---
trailer [12565,12577]
trailer [12596,12608]
===
match
---
simple_stmt [44665,44701]
simple_stmt [44696,44732]
===
match
---
atom_expr [27938,28008]
atom_expr [27969,28039]
===
match
---
name: state [76383,76388]
name: state [78007,78012]
===
match
---
string: """Verify if dag.roots returns the root tasks of a DAG.""" [38697,38755]
string: """Verify if dag.roots returns the root tasks of a DAG.""" [38728,38786]
===
match
---
name: append [58484,58490]
name: append [58515,58521]
===
match
---
testlist_comp [35624,35640]
testlist_comp [35655,35671]
===
match
---
name: next_dagrun_info [63122,63138]
name: next_dagrun_info [63153,63169]
===
match
---
atom_expr [18220,18246]
atom_expr [18251,18277]
===
match
---
trailer [75262,75269]
trailer [76886,76893]
===
match
---
suite [30184,30776]
suite [30215,30807]
===
match
---
assert_stmt [33187,33214]
assert_stmt [33218,33245]
===
match
---
name: TEST_DATE [43916,43925]
name: TEST_DATE [43947,43956]
===
match
---
name: dag [71321,71324]
name: dag [72945,72948]
===
match
---
name: b_index [3684,3691]
name: b_index [3715,3722]
===
match
---
name: session [31645,31652]
name: session [31676,31683]
===
match
---
trailer [12903,12912]
trailer [12934,12943]
===
match
---
arglist [20556,20603]
arglist [20587,20634]
===
match
---
name: operator [75287,75295]
name: operator [76911,76919]
===
match
---
operator: = [40537,40538]
operator: = [40568,40569]
===
match
---
trailer [8749,8769]
trailer [8780,8800]
===
match
---
comparison [58631,58647]
comparison [58662,58678]
===
match
---
atom_expr [71488,71505]
atom_expr [73112,73129]
===
match
---
trailer [76286,76293]
trailer [77910,77917]
===
match
---
trailer [45246,45250]
trailer [45277,45281]
===
match
---
trailer [39973,39982]
trailer [40004,40013]
===
match
---
name: end_date [55403,55411]
name: end_date [55434,55442]
===
match
---
trailer [25570,25610]
trailer [25601,25641]
===
match
---
string: 'airflow.models.dag.Stats' [43333,43359]
string: 'airflow.models.dag.Stats' [43364,43390]
===
match
---
simple_stmt [12818,12859]
simple_stmt [12849,12890]
===
match
---
atom_expr [6786,6856]
atom_expr [6817,6887]
===
match
---
number: 10 [22266,22268]
number: 10 [22297,22299]
===
match
---
string: 'test_dagrun_query_count' [70237,70262]
string: 'test_dagrun_query_count' [71861,71886]
===
match
---
arglist [15194,15202]
arglist [15225,15233]
===
match
---
name: task_id [63780,63787]
name: task_id [65404,65411]
===
match
---
trailer [9702,9715]
trailer [9733,9746]
===
match
---
operator: = [61553,61554]
operator: = [61584,61585]
===
match
---
atom_expr [76240,76250]
atom_expr [77864,77874]
===
match
---
name: subdag [65602,65608]
name: subdag [67226,67232]
===
match
---
name: QUEUED [77516,77522]
name: QUEUED [79140,79146]
===
match
---
operator: = [12372,12373]
operator: = [12403,12404]
===
match
---
operator: = [75329,75330]
operator: = [76953,76954]
===
match
---
name: hash [49339,49343]
name: hash [49370,49374]
===
match
---
argument [54554,54577]
argument [54585,54608]
===
match
---
name: dag [44853,44856]
name: dag [44884,44887]
===
match
---
name: dag [66842,66845]
name: dag [68466,68469]
===
match
---
name: expand [54247,54253]
name: expand [54278,54284]
===
match
---
argument [68822,68837]
argument [70446,70461]
===
match
---
assert_stmt [30197,30370]
assert_stmt [30228,30401]
===
match
---
simple_stmt [76957,77024]
simple_stmt [78581,78648]
===
match
---
string: 'role1' [66265,66272]
string: 'role1' [67889,67896]
===
match
---
name: start_date [73707,73717]
name: start_date [75331,75341]
===
match
---
name: op4 [10558,10561]
name: op4 [10589,10592]
===
match
---
atom_expr [40189,40204]
atom_expr [40220,40235]
===
match
---
name: on_failure_callback [43841,43860]
name: on_failure_callback [43872,43891]
===
match
---
string: '.template' [21907,21918]
string: '.template' [21938,21949]
===
match
---
name: set2 [11117,11121]
name: set2 [11148,11152]
===
match
---
atom_expr [76144,76344]
atom_expr [77768,77968]
===
match
---
simple_stmt [40719,40762]
simple_stmt [40750,40793]
===
match
---
name: path [20897,20901]
name: path [20928,20932]
===
match
---
suite [45603,46543]
suite [45634,46574]
===
match
---
simple_stmt [37194,37230]
simple_stmt [37225,37261]
===
match
---
atom_expr [17060,17086]
atom_expr [17091,17117]
===
match
---
name: subdag [53310,53316]
name: subdag [53341,53347]
===
match
---
operator: = [17877,17878]
operator: = [17908,17909]
===
match
---
name: job_id [51277,51283]
name: job_id [51308,51314]
===
match
---
trailer [62719,62736]
trailer [62750,62767]
===
match
---
name: dag [71278,71281]
name: dag [72902,72905]
===
match
---
name: tests [2548,2553]
name: tests [2579,2584]
===
match
---
name: timedelta [61615,61624]
name: timedelta [61646,61655]
===
match
---
expr_stmt [22597,22633]
expr_stmt [22628,22664]
===
match
---
operator: , [54290,54291]
operator: , [54321,54322]
===
match
---
operator: = [39831,39832]
operator: = [39862,39863]
===
match
---
simple_stmt [21130,21162]
simple_stmt [21161,21193]
===
match
---
decorator [43326,43361]
decorator [43357,43392]
===
match
---
param [71781,71785]
param [73405,73409]
===
match
---
name: session [33925,33932]
name: session [33956,33963]
===
match
---
argument [58113,58134]
argument [58144,58165]
===
match
---
trailer [39514,39528]
trailer [39545,39559]
===
match
---
simple_stmt [53342,53390]
simple_stmt [53373,53421]
===
match
---
string: 'Also fake' [42671,42682]
string: 'Also fake' [42702,42713]
===
match
---
fstring_string: -task- [64967,64973]
fstring_string: -task- [66591,66597]
===
match
---
trailer [43959,44017]
trailer [43990,44048]
===
match
---
trailer [46405,46412]
trailer [46436,46443]
===
match
---
name: task_3 [77225,77231]
name: task_3 [78849,78855]
===
match
---
name: DAG [14827,14830]
name: DAG [14858,14861]
===
match
---
name: state [76537,76542]
name: state [78161,78166]
===
match
---
atom_expr [44673,44700]
atom_expr [44704,44731]
===
match
---
trailer [54519,54521]
trailer [54550,54552]
===
match
---
assert_stmt [41212,41254]
assert_stmt [41243,41285]
===
match
---
name: dag [51102,51105]
name: dag [51133,51136]
===
match
---
trailer [20414,20420]
trailer [20445,20451]
===
match
---
operator: = [64181,64182]
operator: = [65805,65806]
===
match
---
name: op7 [7795,7798]
name: op7 [7826,7829]
===
match
---
atom_expr [77400,77439]
atom_expr [79024,79063]
===
match
---
name: topological_sort [11492,11508]
name: topological_sort [11523,11539]
===
match
---
arglist [7546,7591]
arglist [7577,7622]
===
match
---
atom_expr [10072,10091]
atom_expr [10103,10122]
===
match
---
trailer [23802,23807]
trailer [23833,23838]
===
match
---
assert_stmt [19168,19298]
assert_stmt [19199,19329]
===
match
---
arglist [17410,17454]
arglist [17441,17485]
===
match
---
trailer [31238,31240]
trailer [31269,31271]
===
match
---
argument [52264,52283]
argument [52295,52314]
===
match
---
name: create_session [2700,2714]
name: create_session [2731,2745]
===
match
---
import_from [1376,1429]
import_from [1382,1435]
===
match
---
atom_expr [55315,55330]
atom_expr [55346,55361]
===
match
---
name: op1 [40576,40579]
name: op1 [40607,40610]
===
match
---
name: dag [7970,7973]
name: dag [8001,8004]
===
match
---
name: hash [49266,49270]
name: hash [49297,49301]
===
match
---
atom_expr [70543,70556]
atom_expr [72167,72180]
===
match
---
simple_stmt [34044,34083]
simple_stmt [34075,34114]
===
match
---
simple_stmt [8370,8501]
simple_stmt [8401,8532]
===
match
---
name: run_type [44986,44994]
name: run_type [45017,45025]
===
match
---
name: catchup [61646,61653]
name: catchup [61677,61684]
===
match
---
decorator [77628,78683]
decorator [79252,80307]
===
match
---
trailer [76151,76157]
trailer [77775,77781]
===
match
---
name: task_id [42023,42030]
name: task_id [42054,42061]
===
match
---
testlist_comp [29775,29805]
testlist_comp [29806,29836]
===
match
---
operator: = [31006,31007]
operator: = [31037,31038]
===
match
---
string: "depends_on_past" [70713,70730]
string: "depends_on_past" [72337,72354]
===
match
---
name: dr [50673,50675]
name: dr [50704,50706]
===
match
---
name: attrs [76988,76993]
name: attrs [78612,78617]
===
match
---
simple_stmt [20194,20292]
simple_stmt [20225,20323]
===
match
---
operator: >> [41575,41577]
operator: >> [41606,41608]
===
match
---
simple_stmt [56583,56660]
simple_stmt [56614,56691]
===
match
---
atom_expr [39971,39984]
atom_expr [40002,40015]
===
match
---
trailer [37081,37083]
trailer [37112,37114]
===
match
---
trailer [67486,67488]
trailer [69110,69112]
===
match
---
operator: = [68842,68843]
operator: = [70466,70467]
===
match
---
name: dag [53183,53186]
name: dag [53214,53217]
===
match
---
operator: = [54423,54424]
operator: = [54454,54455]
===
match
---
name: DummyOperator [41917,41930]
name: DummyOperator [41948,41961]
===
match
---
arglist [13752,13799]
arglist [13783,13830]
===
match
---
trailer [52662,52668]
trailer [52693,52699]
===
match
---
name: dag_id [52762,52768]
name: dag_id [52793,52799]
===
match
---
operator: @ [77628,77629]
operator: @ [79252,79253]
===
match
---
operator: = [54810,54811]
operator: = [54841,54842]
===
match
---
operator: == [48837,48839]
operator: == [48868,48870]
===
match
---
operator: = [59986,59987]
operator: = [60017,60018]
===
match
---
comparison [48965,48989]
comparison [48996,49020]
===
match
---
trailer [18484,18490]
trailer [18515,18521]
===
match
---
simple_stmt [66733,66782]
simple_stmt [68357,68406]
===
match
---
name: synchronize_session [3498,3517]
name: synchronize_session [3529,3548]
===
match
---
argument [70537,70556]
argument [72161,72180]
===
match
---
comparison [54899,54929]
comparison [54930,54960]
===
match
---
simple_stmt [69844,69866]
simple_stmt [71468,71490]
===
match
---
trailer [11688,11764]
trailer [11719,11795]
===
match
---
simple_stmt [56167,56229]
simple_stmt [56198,56260]
===
match
---
name: DEFAULT_DATE [74659,74671]
name: DEFAULT_DATE [76283,76295]
===
match
---
atom_expr [52745,52758]
atom_expr [52776,52789]
===
match
---
atom_expr [11251,11270]
atom_expr [11282,11301]
===
match
---
name: task_id [17410,17417]
name: task_id [17441,17448]
===
match
---
name: test_next_dagrun_after_not_for_subdags [64367,64405]
name: test_next_dagrun_after_not_for_subdags [65991,66029]
===
match
---
simple_stmt [53142,53188]
simple_stmt [53173,53219]
===
match
---
name: b [3569,3570]
name: b [3600,3601]
===
match
---
expr_stmt [10603,10635]
expr_stmt [10634,10666]
===
match
---
name: dr [50974,50976]
name: dr [51005,51007]
===
match
---
funcdef [75101,75316]
funcdef [76725,76940]
===
match
---
operator: == [10178,10180]
operator: == [10209,10211]
===
match
---
string: 'test_scheduler_verify_max_active_runs' [31019,31058]
string: 'test_scheduler_verify_max_active_runs' [31050,31089]
===
match
---
string: '{{ ds }}' [21999,22009]
string: '{{ ds }}' [22030,22040]
===
match
---
name: task_id [15007,15014]
name: task_id [15038,15045]
===
match
---
operator: , [29955,29956]
operator: , [29986,29987]
===
match
---
assert_stmt [19993,20028]
assert_stmt [20024,20059]
===
match
---
simple_stmt [68745,68800]
simple_stmt [70369,70424]
===
match
---
comparison [76240,76266]
comparison [77864,77890]
===
match
---
name: child_dag_name [64768,64782]
name: child_dag_name [66392,66406]
===
match
---
number: 1 [3674,3675]
number: 1 [3705,3706]
===
match
---
name: test_validate_params_on_trigger_dag [66791,66826]
name: test_validate_params_on_trigger_dag [68415,68450]
===
match
---
operator: >> [39071,39073]
operator: >> [39102,39104]
===
match
---
argument [64174,64189]
argument [65798,65813]
===
match
---
simple_stmt [37591,37617]
simple_stmt [37622,37648]
===
match
---
comparison [7989,8003]
comparison [8020,8034]
===
match
---
name: start_date [56793,56803]
name: start_date [56824,56834]
===
match
---
trailer [3497,3524]
trailer [3528,3555]
===
match
---
name: tzinfo [12624,12630]
name: tzinfo [12655,12661]
===
match
---
atom_expr [10609,10635]
atom_expr [10640,10666]
===
match
---
name: when [26284,26288]
name: when [26315,26319]
===
match
---
name: dag_id [60810,60816]
name: dag_id [60841,60847]
===
match
---
name: DAG [23480,23483]
name: DAG [23511,23514]
===
match
---
argument [53629,53652]
argument [53660,53683]
===
match
---
trailer [3386,3393]
trailer [3417,3424]
===
match
---
for_stmt [15445,15540]
for_stmt [15476,15571]
===
match
---
name: DummyOperator [67394,67407]
name: DummyOperator [69018,69031]
===
match
---
operator: , [21806,21807]
operator: , [21837,21838]
===
match
---
atom_expr [38648,38661]
atom_expr [38679,38692]
===
match
---
name: op3 [7230,7233]
name: op3 [7261,7264]
===
match
---
assert_stmt [12934,12974]
assert_stmt [12965,13005]
===
match
---
import_from [1500,1586]
import_from [1506,1592]
===
match
---
operator: = [38444,38445]
operator: = [38475,38476]
===
match
---
trailer [5236,5264]
trailer [5267,5295]
===
match
---
operator: == [65726,65728]
operator: == [67350,67352]
===
match
---
trailer [56127,56135]
trailer [56158,56166]
===
match
---
parameters [71994,71999]
parameters [73618,73623]
===
match
---
arglist [31012,31083]
arglist [31043,31114]
===
match
---
name: next_info [64226,64235]
name: next_info [65850,65859]
===
match
---
simple_stmt [49543,49592]
simple_stmt [49574,49623]
===
match
---
argument [5520,5554]
argument [5551,5585]
===
match
---
atom_expr [5734,5780]
atom_expr [5765,5811]
===
match
---
operator: = [26560,26561]
operator: = [26591,26592]
===
match
---
trailer [46188,46196]
trailer [46219,46227]
===
match
---
atom_expr [18272,18309]
atom_expr [18303,18340]
===
match
---
name: session [53926,53933]
name: session [53957,53964]
===
match
---
string: 'dag-bulk-sync-2' [30509,30526]
string: 'dag-bulk-sync-2' [30540,30557]
===
match
---
string: 'D' [9682,9685]
string: 'D' [9713,9716]
===
match
---
argument [73749,73781]
argument [75373,75405]
===
match
---
name: test_dag_task_priority_weight_total_using_absolute [15955,16005]
name: test_dag_task_priority_weight_total_using_absolute [15986,16036]
===
match
---
name: op2 [39547,39550]
name: op2 [39578,39581]
===
match
---
param [73464,73467]
param [75088,75091]
===
match
---
name: TaskFail [3447,3455]
name: TaskFail [3478,3486]
===
match
---
comparison [33065,33097]
comparison [33096,33128]
===
match
---
dictorsetmaker [14877,14894]
dictorsetmaker [14908,14925]
===
match
---
name: SubDagOperator [53279,53293]
name: SubDagOperator [53310,53324]
===
match
---
trailer [23845,23852]
trailer [23876,23883]
===
match
---
simple_stmt [73510,73539]
simple_stmt [75134,75163]
===
match
---
number: 1 [15686,15687]
number: 1 [15717,15718]
===
match
---
operator: , [29905,29906]
operator: , [29936,29937]
===
match
---
trailer [41415,41452]
trailer [41446,41483]
===
match
---
argument [74639,74671]
argument [76263,76295]
===
match
---
operator: = [65224,65225]
operator: = [66848,66849]
===
match
---
name: self [5304,5308]
name: self [5335,5339]
===
match
---
expr_stmt [51358,51487]
expr_stmt [51389,51518]
===
match
---
simple_stmt [73551,73585]
simple_stmt [75175,75209]
===
match
---
simple_stmt [76633,76774]
simple_stmt [78257,78398]
===
match
---
testlist_comp [35892,35909]
testlist_comp [35923,35940]
===
match
---
name: start_date [14838,14848]
name: start_date [14869,14879]
===
match
---
atom [14946,15221]
atom [14977,15252]
===
match
---
simple_stmt [12586,12670]
simple_stmt [12617,12701]
===
match
---
with_stmt [66434,66566]
with_stmt [68058,68190]
===
match
---
arglist [8400,8490]
arglist [8431,8521]
===
match
---
name: dag [59582,59585]
name: dag [59613,59616]
===
match
---
name: delete [34837,34843]
name: delete [34868,34874]
===
match
---
name: dag [25841,25844]
name: dag [25872,25875]
===
match
---
atom_expr [14827,14896]
atom_expr [14858,14927]
===
match
---
name: state [17765,17770]
name: state [17796,17801]
===
match
---
suite [20537,20703]
suite [20568,20734]
===
match
---
operator: , [22492,22493]
operator: , [22523,22524]
===
match
---
atom_expr [48367,48382]
atom_expr [48398,48413]
===
match
---
trailer [3472,3479]
trailer [3503,3510]
===
match
---
simple_stmt [47921,47966]
simple_stmt [47952,47997]
===
match
---
trailer [34787,34794]
trailer [34818,34825]
===
match
---
name: DagModel [46387,46395]
name: DagModel [46418,46426]
===
match
---
atom [69597,69730]
atom [71221,71354]
===
match
---
operator: = [63583,63584]
operator: = [65207,65208]
===
match
---
atom_expr [21774,21789]
atom_expr [21805,21820]
===
match
---
name: session [38231,38238]
name: session [38262,38269]
===
match
---
suite [51700,52936]
suite [51731,52967]
===
match
---
string: 'owner2' [6846,6854]
string: 'owner2' [6877,6885]
===
match
---
name: DEFAULT_DATE [27756,27768]
name: DEFAULT_DATE [27787,27799]
===
match
---
operator: = [63662,63663]
operator: = [65286,65287]
===
match
---
suite [68655,69516]
suite [70279,71140]
===
match
---
import_as_names [2514,2542]
import_as_names [2545,2573]
===
match
---
trailer [10088,10091]
trailer [10119,10122]
===
match
---
atom_expr [18349,18386]
atom_expr [18380,18417]
===
match
---
name: start_date [54554,54564]
name: start_date [54585,54595]
===
match
---
name: timezone [26136,26144]
name: timezone [26167,26175]
===
match
---
operator: = [17953,17954]
operator: = [17984,17985]
===
match
---
name: op2 [41957,41960]
name: op2 [41988,41991]
===
match
---
name: op3 [8797,8800]
name: op3 [8828,8831]
===
match
---
trailer [36138,36152]
trailer [36169,36183]
===
match
---
with_stmt [3195,3525]
with_stmt [3226,3556]
===
match
---
name: dag [12941,12944]
name: dag [12972,12975]
===
match
---
assert_stmt [30750,30775]
assert_stmt [30781,30806]
===
match
---
operator: = [41055,41056]
operator: = [41086,41087]
===
match
---
expr_stmt [66229,66424]
expr_stmt [67853,68048]
===
match
---
string: 'dag_default_view_old' [37156,37178]
string: 'dag_default_view_old' [37187,37209]
===
match
---
string: 'start_date' [12532,12544]
string: 'start_date' [12563,12575]
===
match
---
string: 'dag-bulk-sync-0' [28333,28350]
string: 'dag-bulk-sync-0' [28364,28381]
===
match
---
atom_expr [29928,29975]
atom_expr [29959,30006]
===
match
---
name: dr2 [17830,17833]
name: dr2 [17861,17864]
===
match
---
atom_expr [66491,66565]
atom_expr [68115,68189]
===
match
---
name: default_args [38585,38597]
name: default_args [38616,38628]
===
match
---
operator: } [29919,29920]
operator: } [29950,29951]
===
match
---
atom_expr [21088,21116]
atom_expr [21119,21147]
===
match
---
operator: , [3710,3711]
operator: , [3741,3742]
===
match
---
trailer [61177,61186]
trailer [61208,61217]
===
match
---
name: DAG [43683,43686]
name: DAG [43714,43717]
===
match
---
name: noop_pipeline [73182,73195]
name: noop_pipeline [74806,74819]
===
match
---
import_as_names [2017,2045]
import_as_names [2048,2076]
===
match
---
atom_expr [43298,43320]
atom_expr [43329,43351]
===
match
---
name: dag_id [17612,17618]
name: dag_id [17643,17649]
===
match
---
name: DAG [5516,5519]
name: DAG [5547,5550]
===
match
---
name: filter [33058,33064]
name: filter [33089,33095]
===
match
---
parameters [67293,67299]
parameters [68917,68923]
===
match
---
trailer [38058,38065]
trailer [38089,38096]
===
match
---
name: create_session [2165,2179]
name: create_session [2196,2210]
===
match
---
name: dag [31492,31495]
name: dag [31523,31526]
===
match
---
operator: = [23605,23606]
operator: = [23636,23637]
===
match
---
trailer [3072,3074]
trailer [3103,3105]
===
match
---
atom_expr [52293,52323]
atom_expr [52324,52354]
===
match
---
name: i [3709,3710]
name: i [3740,3741]
===
match
---
name: model [31813,31818]
name: model [31844,31849]
===
match
---
atom_expr [15247,15262]
atom_expr [15278,15293]
===
match
---
simple_stmt [27370,27398]
simple_stmt [27401,27429]
===
match
---
expr_stmt [62704,62761]
expr_stmt [62735,62792]
===
match
---
name: dag_id [76216,76222]
name: dag_id [77840,77846]
===
match
---
trailer [23783,23802]
trailer [23814,23833]
===
match
---
operator: = [74607,74608]
operator: = [76231,76232]
===
match
---
suite [67300,67977]
suite [68924,69601]
===
match
---
string: 'dag.subtask' [33084,33097]
string: 'dag.subtask' [33115,33128]
===
match
---
trailer [50179,50192]
trailer [50210,50223]
===
match
---
dictorsetmaker [5135,5165]
dictorsetmaker [5166,5196]
===
match
---
trailer [69480,69489]
trailer [71104,71113]
===
match
---
name: sync_to_db [36292,36302]
name: sync_to_db [36323,36333]
===
match
---
name: RUNNING [73807,73814]
name: RUNNING [75431,75438]
===
match
---
param [68649,68653]
param [70273,70277]
===
match
---
simple_stmt [75902,75943]
simple_stmt [77526,77567]
===
match
---
atom_expr [8829,8883]
atom_expr [8860,8914]
===
match
---
name: local_tz [24053,24061]
name: local_tz [24084,24092]
===
match
---
name: depth [13861,13866]
name: depth [13892,13897]
===
match
---
atom_expr [66914,66934]
atom_expr [68538,68558]
===
match
---
name: orm_dag [32983,32990]
name: orm_dag [33014,33021]
===
match
---
operator: = [6808,6809]
operator: = [6839,6840]
===
match
---
name: task_instance_1 [53961,53976]
name: task_instance_1 [53992,54007]
===
match
---
name: timedelta [55436,55445]
name: timedelta [55467,55476]
===
match
---
name: BaseOperator [46794,46806]
name: BaseOperator [46825,46837]
===
match
---
argument [74782,74810]
argument [76406,76434]
===
match
---
name: dag_id [34409,34415]
name: dag_id [34440,34446]
===
match
---
dictorsetmaker [35176,35224]
dictorsetmaker [35207,35255]
===
match
---
param [41313,41317]
param [41344,41348]
===
match
---
atom_expr [18578,18591]
atom_expr [18609,18622]
===
match
---
atom_expr [34438,34509]
atom_expr [34469,34540]
===
match
---
funcdef [75180,75228]
funcdef [76804,76852]
===
match
---
atom_expr [2759,2777]
atom_expr [2790,2808]
===
match
---
operator: , [59121,59122]
operator: , [59152,59153]
===
match
---
trailer [65737,65746]
trailer [67361,67370]
===
match
---
operator: = [75713,75714]
operator: = [77337,77338]
===
match
---
simple_stmt [24649,24683]
simple_stmt [24680,24714]
===
match
---
operator: = [69815,69816]
operator: = [71439,71440]
===
match
---
name: _clean_up [56118,56127]
name: _clean_up [56149,56158]
===
match
---
simple_stmt [70856,70901]
simple_stmt [72480,72525]
===
match
---
name: flush [69201,69206]
name: flush [70825,70830]
===
match
---
name: default_view [37209,37221]
name: default_view [37240,37252]
===
match
---
name: prev_task [14054,14063]
name: prev_task [14085,14094]
===
match
---
trailer [20901,20909]
trailer [20932,20940]
===
match
---
parameters [2687,2689]
parameters [2718,2720]
===
match
---
name: op1 [11030,11033]
name: op1 [11061,11064]
===
match
---
assert_stmt [13190,13230]
assert_stmt [13221,13261]
===
match
---
name: self [56113,56117]
name: self [56144,56148]
===
match
---
name: orm_dag [34051,34058]
name: orm_dag [34082,34089]
===
match
---
atom_expr [68273,68283]
atom_expr [69897,69907]
===
match
---
operator: = [56623,56624]
operator: = [56654,56655]
===
match
---
argument [34556,34572]
argument [34587,34603]
===
match
---
string: 'tz_dag' [22484,22492]
string: 'tz_dag' [22515,22523]
===
match
---
arglist [48060,48099]
arglist [48091,48130]
===
match
---
param [13276,13280]
param [13307,13311]
===
match
---
operator: , [74671,74672]
operator: , [76295,76296]
===
match
---
simple_stmt [13291,13301]
simple_stmt [13322,13332]
===
match
---
name: add [68459,68462]
name: add [70083,70086]
===
match
---
suite [17499,19627]
suite [17530,19658]
===
match
---
name: refresh_from_db [47164,47179]
name: refresh_from_db [47195,47210]
===
match
---
string: 'role2' [66346,66353]
string: 'role2' [67970,67977]
===
match
---
string: 'airflow' [59070,59079]
string: 'airflow' [59101,59110]
===
match
---
name: task_id [75876,75883]
name: task_id [77500,77507]
===
match
---
simple_stmt [31126,31183]
simple_stmt [31157,31214]
===
match
---
param [4280,4284]
param [4311,4315]
===
match
---
simple_stmt [16246,16606]
simple_stmt [16277,16637]
===
match
---
operator: = [14875,14876]
operator: = [14906,14907]
===
match
---
trailer [30053,30065]
trailer [30084,30096]
===
match
---
name: state [55851,55856]
name: state [55882,55887]
===
match
---
trailer [35822,35832]
trailer [35853,35863]
===
match
---
operator: , [30576,30577]
operator: , [30607,30608]
===
match
---
name: test_clear_set_dagrun_state_for_parent_dag [55151,55193]
name: test_clear_set_dagrun_state_for_parent_dag [55182,55224]
===
match
---
atom_expr [35266,35354]
atom_expr [35297,35385]
===
match
---
operator: , [18912,18913]
operator: , [18943,18944]
===
match
---
simple_stmt [38231,38247]
simple_stmt [38262,38278]
===
match
---
trailer [29218,29221]
trailer [29249,29252]
===
match
---
funcdef [13236,14567]
funcdef [13267,14598]
===
match
---
trailer [51961,51963]
trailer [51992,51994]
===
match
---
atom_expr [52864,52874]
atom_expr [52895,52905]
===
match
---
atom_expr [40013,40028]
atom_expr [40044,40059]
===
match
---
trailer [39468,39482]
trailer [39499,39513]
===
match
---
operator: - [59848,59849]
operator: - [59879,59880]
===
match
---
name: jinja2 [20475,20481]
name: jinja2 [20506,20512]
===
match
---
dictorsetmaker [16206,16223]
dictorsetmaker [16237,16254]
===
match
---
name: datetime_tz [2282,2293]
name: datetime_tz [2313,2324]
===
match
---
trailer [36617,36634]
trailer [36648,36665]
===
match
---
simple_stmt [60735,60772]
simple_stmt [60766,60803]
===
match
---
name: timedelta [77880,77889]
name: timedelta [79504,79513]
===
match
---
argument [27514,27541]
argument [27545,27572]
===
match
---
operator: , [72610,72611]
operator: , [74234,74235]
===
match
---
name: dag [59527,59530]
name: dag [59558,59561]
===
match
---
operator: >> [40703,40705]
operator: >> [40734,40736]
===
match
---
argument [63602,63638]
argument [65226,65262]
===
match
---
name: state [47084,47089]
name: state [47115,47120]
===
match
---
name: session [55013,55020]
name: session [55044,55051]
===
match
---
parameters [16005,16011]
parameters [16036,16042]
===
match
---
name: staticmethod [3531,3543]
name: staticmethod [3562,3574]
===
match
---
atom_expr [23646,23668]
atom_expr [23677,23699]
===
match
---
suite [71939,72055]
suite [73563,73679]
===
match
---
operator: , [35215,35216]
operator: , [35246,35247]
===
match
---
name: query [33042,33047]
name: query [33073,33078]
===
match
---
arglist [78761,78838]
arglist [80385,80462]
===
match
---
operator: { [66040,66041]
operator: { [67664,67665]
===
match
---
name: session [3220,3227]
name: session [3251,3258]
===
match
---
string: "faketastic" [45968,45980]
string: "faketastic" [45999,46011]
===
match
---
atom_expr [47876,47911]
atom_expr [47907,47942]
===
match
---
name: dag_diff_name [48536,48549]
name: dag_diff_name [48567,48580]
===
match
---
name: is_paused_upon_creation [49480,49503]
name: is_paused_upon_creation [49511,49534]
===
match
---
operator: = [53447,53448]
operator: = [53478,53479]
===
match
---
simple_stmt [20613,20648]
simple_stmt [20644,20679]
===
match
---
simple_stmt [38876,38910]
simple_stmt [38907,38941]
===
match
---
arith_expr [18060,18101]
arith_expr [18091,18132]
===
match
---
operator: = [68091,68092]
operator: = [69715,69716]
===
match
---
arglist [66495,66564]
arglist [68119,68188]
===
match
---
trailer [70951,70953]
trailer [72575,72577]
===
match
---
suite [71535,71651]
suite [73159,73275]
===
match
---
name: create_dagrun [42730,42743]
name: create_dagrun [42761,42774]
===
match
---
argument [53362,53376]
argument [53393,53407]
===
match
---
simple_stmt [68197,68226]
simple_stmt [69821,69850]
===
match
---
comparison [18962,19051]
comparison [18993,19082]
===
match
---
string: 'Europe/Zurich' [22192,22207]
string: 'Europe/Zurich' [22223,22238]
===
match
---
name: NONE [77248,77252]
name: NONE [78872,78876]
===
match
---
operator: = [67354,67355]
operator: = [68978,68979]
===
match
---
name: session [27853,27860]
name: session [27884,27891]
===
match
---
simple_stmt [51358,51488]
simple_stmt [51389,51519]
===
match
---
sync_comp_for [15179,15203]
sync_comp_for [15210,15234]
===
match
---
param [56019,56024]
param [56050,56055]
===
match
---
import_from [879,917]
import_from [879,917]
===
match
---
operator: = [42168,42169]
operator: = [42199,42200]
===
match
---
name: dag [66581,66584]
name: dag [68205,68208]
===
match
---
name: start_date [39266,39276]
name: start_date [39297,39307]
===
match
---
string: "2018-10-28T02:00:00+01:00" [22740,22767]
string: "2018-10-28T02:00:00+01:00" [22771,22798]
===
match
---
operator: = [53369,53370]
operator: = [53400,53401]
===
match
---
atom_expr [57221,57240]
atom_expr [57252,57271]
===
match
---
name: isoformat [23041,23050]
name: isoformat [23072,23081]
===
match
---
suite [39168,39623]
suite [39199,39654]
===
match
---
name: dag [35704,35707]
name: dag [35735,35738]
===
match
---
atom_expr [35704,35714]
atom_expr [35735,35745]
===
match
---
atom_expr [45824,45869]
atom_expr [45855,45900]
===
match
---
simple_stmt [8783,8801]
simple_stmt [8814,8832]
===
match
---
argument [78786,78809]
argument [80410,80433]
===
match
---
simple_stmt [64927,64999]
simple_stmt [66551,66623]
===
match
---
suite [28060,30776]
suite [28091,30807]
===
match
---
name: DEFAULT_DATE [9343,9355]
name: DEFAULT_DATE [9374,9386]
===
match
---
name: dummy [1812,1817]
name: dummy [1818,1823]
===
match
---
atom_expr [19611,19626]
atom_expr [19642,19657]
===
match
---
simple_stmt [10648,10672]
simple_stmt [10679,10703]
===
match
---
atom_expr [31784,31794]
atom_expr [31815,31825]
===
match
---
name: models [66848,66854]
name: models [68472,68478]
===
match
---
name: get_paused_dag_ids [49627,49645]
name: get_paused_dag_ids [49658,49676]
===
match
---
trailer [35299,35313]
trailer [35330,35344]
===
match
---
argument [59869,59876]
argument [59900,59907]
===
match
---
trailer [9628,9641]
trailer [9659,9672]
===
match
---
operator: , [13627,13628]
operator: , [13658,13659]
===
match
---
name: test_dagtag_repr [27660,27676]
name: test_dagtag_repr [27691,27707]
===
match
---
string: '.template' [21246,21257]
string: '.template' [21277,21288]
===
match
---
argument [8679,8698]
argument [8710,8729]
===
match
---
argument [67344,67384]
argument [68968,69008]
===
match
---
name: start_date [75661,75671]
name: start_date [77285,77295]
===
match
---
operator: = [47718,47719]
operator: = [47749,47750]
===
match
---
name: on_success_callback [43798,43817]
name: on_success_callback [43829,43848]
===
match
---
name: TI [53979,53981]
name: TI [54010,54012]
===
match
---
operator: = [39361,39362]
operator: = [39392,39393]
===
match
---
assert_stmt [34044,34082]
assert_stmt [34075,34113]
===
match
---
name: TIMEZONE [12966,12974]
name: TIMEZONE [12997,13005]
===
match
---
name: task_id [78858,78865]
name: task_id [80482,80489]
===
match
---
name: when [27603,27607]
name: when [27634,27638]
===
match
---
atom [28157,28169]
atom [28188,28200]
===
match
---
number: 0 [15350,15351]
number: 0 [15381,15382]
===
match
---
trailer [65357,65364]
trailer [66981,66988]
===
match
---
trailer [14075,14082]
trailer [14106,14113]
===
match
---
atom [29626,29657]
atom [29657,29688]
===
match
---
operator: , [69565,69566]
operator: , [71189,71190]
===
match
---
string: 'B' [10496,10499]
string: 'B' [10527,10530]
===
match
---
name: task_instance_1 [56719,56734]
name: task_instance_1 [56750,56765]
===
match
---
funcdef [27656,28023]
funcdef [27687,28054]
===
match
---
expr_stmt [43517,43551]
expr_stmt [43548,43582]
===
match
---
atom_expr [41716,41729]
atom_expr [41747,41760]
===
match
---
operator: = [60323,60324]
operator: = [60354,60355]
===
match
---
simple_stmt [35574,35673]
simple_stmt [35605,35704]
===
match
---
name: test_dag_task_priority_weight_total_using_upstream [14576,14626]
name: test_dag_task_priority_weight_total_using_upstream [14607,14657]
===
match
---
name: state [18485,18490]
name: state [18516,18521]
===
match
---
name: timezone [23434,23442]
name: timezone [23465,23473]
===
match
---
trailer [39253,39290]
trailer [39284,39321]
===
match
---
simple_stmt [38025,38099]
simple_stmt [38056,38130]
===
match
---
expr_stmt [50625,50664]
expr_stmt [50656,50695]
===
match
---
name: task [21725,21729]
name: task [21756,21760]
===
match
---
atom_expr [54168,54198]
atom_expr [54199,54229]
===
match
---
name: session [28810,28817]
name: session [28841,28848]
===
match
---
name: dag_id [78761,78767]
name: dag_id [80385,80391]
===
match
---
simple_stmt [72625,72651]
simple_stmt [74249,74275]
===
match
---
name: dag [70393,70396]
name: dag [72017,72020]
===
match
---
name: max_active_runs [53115,53130]
name: max_active_runs [53146,53161]
===
match
---
name: self [3036,3040]
name: self [3067,3071]
===
match
---
param [78718,78729]
param [80342,80353]
===
match
---
atom_expr [77242,77252]
atom_expr [78866,78876]
===
match
---
name: session [3433,3440]
name: session [3464,3471]
===
match
---
name: timezone [61169,61177]
name: timezone [61200,61208]
===
match
---
name: DagModel [35266,35274]
name: DagModel [35297,35305]
===
match
---
atom [10918,10928]
atom [10949,10959]
===
match
---
name: op2 [39066,39069]
name: op2 [39097,39100]
===
match
---
trailer [40244,40247]
trailer [40275,40278]
===
match
---
trailer [66445,66451]
trailer [68069,68075]
===
match
---
name: state [45070,45075]
name: state [45101,45106]
===
match
---
operator: = [37402,37403]
operator: = [37433,37434]
===
match
---
trailer [35291,35298]
trailer [35322,35329]
===
match
---
name: xcom_arg [73567,73575]
name: xcom_arg [75191,75199]
===
match
---
name: ACTION_CAN_READ [66053,66068]
name: ACTION_CAN_READ [67677,67692]
===
match
---
operator: , [64091,64092]
operator: , [65715,65716]
===
match
---
name: test_task [17665,17674]
name: test_task [17696,17705]
===
match
---
operator: == [62021,62023]
operator: == [62052,62054]
===
match
---
name: models [1600,1606]
name: models [1606,1612]
===
match
---
name: timezone [2254,2262]
name: timezone [2285,2293]
===
match
---
name: isoformat [46985,46994]
name: isoformat [47016,47025]
===
match
---
operator: = [7634,7635]
operator: = [7665,7666]
===
match
---
name: minutes [65217,65224]
name: minutes [66841,66848]
===
match
---
simple_stmt [8606,8646]
simple_stmt [8637,8677]
===
match
---
expr_stmt [64226,64264]
expr_stmt [65850,65888]
===
match
---
argument [59808,59818]
argument [59839,59849]
===
match
---
operator: , [47316,47317]
operator: , [47347,47348]
===
match
---
simple_stmt [59489,59532]
simple_stmt [59520,59563]
===
match
---
atom_expr [75862,75893]
atom_expr [77486,77517]
===
match
---
operator: = [68355,68356]
operator: = [69979,69980]
===
match
---
name: BaseOperator [42630,42642]
name: BaseOperator [42661,42673]
===
match
---
name: DummyOperator [17396,17409]
name: DummyOperator [17427,17440]
===
match
---
expr_stmt [15605,15640]
expr_stmt [15636,15671]
===
match
---
name: task_id [10533,10540]
name: task_id [10564,10571]
===
match
---
name: start_date [47306,47316]
name: start_date [47337,47347]
===
match
---
trailer [43200,43208]
trailer [43231,43239]
===
match
---
name: job_id [51525,51531]
name: job_id [51556,51562]
===
match
---
trailer [77800,77810]
trailer [79424,79434]
===
match
---
comparison [12825,12858]
comparison [12856,12889]
===
match
---
operator: == [40740,40742]
operator: == [40771,40773]
===
match
---
name: op3 [9740,9743]
name: op3 [9771,9774]
===
match
---
name: State [70543,70548]
name: State [72167,72172]
===
match
---
testlist_comp [28684,28713]
testlist_comp [28715,28744]
===
match
---
name: topological_list [10884,10900]
name: topological_list [10915,10931]
===
match
---
name: previous_schedule [24660,24677]
name: previous_schedule [24691,24708]
===
match
---
name: dag_run [42884,42891]
name: dag_run [42915,42922]
===
match
---
operator: = [46685,46686]
operator: = [46716,46717]
===
match
---
name: task_id [8297,8304]
name: task_id [8328,8335]
===
match
---
expr_stmt [57933,57941]
expr_stmt [57964,57972]
===
match
---
name: start_date [57995,58005]
name: start_date [58026,58036]
===
match
---
name: utc [22584,22587]
name: utc [22615,22618]
===
match
---
name: orm_dag [69176,69183]
name: orm_dag [70800,70807]
===
match
---
trailer [7066,7070]
trailer [7097,7101]
===
match
---
expr_stmt [54415,54443]
expr_stmt [54446,54474]
===
match
---
atom_expr [32431,32448]
atom_expr [32462,32479]
===
match
---
operator: = [64126,64127]
operator: = [65750,65751]
===
match
---
atom_expr [75074,75091]
atom_expr [76698,76715]
===
match
---
simple_stmt [13037,13122]
simple_stmt [13068,13153]
===
match
---
name: op4 [10919,10922]
name: op4 [10950,10953]
===
match
---
name: all [28003,28006]
name: all [28034,28037]
===
match
---
trailer [45147,45158]
trailer [45178,45189]
===
match
---
name: dag [76212,76215]
name: dag [77836,77839]
===
match
---
trailer [15578,15585]
trailer [15609,15616]
===
match
---
name: op2 [40706,40709]
name: op2 [40737,40740]
===
match
---
operator: = [56691,56692]
operator: = [56722,56723]
===
match
---
trailer [21502,21508]
trailer [21533,21539]
===
match
---
operator: = [60072,60073]
operator: = [60103,60104]
===
match
---
name: dag_id [37828,37834]
name: dag_id [37859,37865]
===
match
---
string: '*/5 * * * *' [22530,22543]
string: '*/5 * * * *' [22561,22574]
===
match
---
expr_stmt [47527,47568]
expr_stmt [47558,47599]
===
match
---
name: remove [11207,11213]
name: remove [11238,11244]
===
match
---
name: all [67887,67890]
name: all [69511,69514]
===
match
---
operator: , [69719,69720]
operator: , [71343,71344]
===
match
---
name: set1 [10911,10915]
name: set1 [10942,10946]
===
match
---
argument [3394,3419]
argument [3425,3450]
===
match
---
operator: = [47874,47875]
operator: = [47905,47906]
===
match
---
name: t [77546,77547]
name: t [79170,79171]
===
match
---
trailer [24024,24031]
trailer [24055,24062]
===
match
---
atom_expr [40918,41009]
atom_expr [40949,41040]
===
match
---
simple_stmt [56079,56105]
simple_stmt [56110,56136]
===
match
---
param [75442,75451]
param [77066,77075]
===
match
---
operator: == [77096,77098]
operator: == [78720,78722]
===
match
---
name: ti2 [18343,18346]
name: ti2 [18374,18377]
===
match
---
operator: = [57895,57896]
operator: = [57926,57927]
===
match
---
name: weight [14716,14722]
name: weight [14747,14753]
===
match
---
name: owner [7030,7035]
name: owner [7061,7066]
===
match
---
operator: @ [54232,54233]
operator: @ [54263,54264]
===
match
---
trailer [20962,20970]
trailer [20993,21001]
===
match
---
name: get_num_task_instances [18971,18993]
name: get_num_task_instances [19002,19024]
===
match
---
name: isoformat [24817,24826]
name: isoformat [24848,24857]
===
match
---
atom_expr [54305,54318]
atom_expr [54336,54349]
===
match
---
expr_stmt [75804,75844]
expr_stmt [77428,77468]
===
match
---
name: test_create_dagrun_run_type_is_obtained_from_run_id [50846,50897]
name: test_create_dagrun_run_type_is_obtained_from_run_id [50877,50928]
===
match
---
atom_expr [9900,9919]
atom_expr [9931,9950]
===
match
---
operator: * [58019,58020]
operator: * [58050,58051]
===
match
---
trailer [47215,47230]
trailer [47246,47261]
===
match
---
atom_expr [22242,22280]
atom_expr [22273,22311]
===
match
---
expr_stmt [78751,78839]
expr_stmt [80375,80463]
===
match
---
operator: , [29707,29708]
operator: , [29738,29739]
===
match
---
decorated [72946,73022]
decorated [74570,74646]
===
match
---
argument [74812,74838]
argument [76436,76462]
===
match
---
atom_expr [28737,28784]
atom_expr [28768,28815]
===
match
---
string: "custom_is_set_to_manual" [51127,51152]
string: "custom_is_set_to_manual" [51158,51183]
===
match
---
name: i [70301,70302]
name: i [71925,71926]
===
match
---
for_stmt [29127,29185]
for_stmt [29158,29216]
===
match
---
name: one [38093,38096]
name: one [38124,38127]
===
match
---
trailer [46908,46910]
trailer [46939,46941]
===
match
---
operator: , [31660,31661]
operator: , [31691,31692]
===
match
---
simple_stmt [32156,32202]
simple_stmt [32187,32233]
===
match
---
argument [33561,33575]
argument [33592,33606]
===
match
---
funcdef [46548,47387]
funcdef [46579,47418]
===
match
---
name: airflow [1844,1851]
name: airflow [1850,1857]
===
match
---
atom_expr [66683,66701]
atom_expr [68307,68325]
===
match
---
number: 1 [14291,14292]
number: 1 [14322,14323]
===
match
---
name: self [9129,9133]
name: self [9160,9164]
===
match
---
name: has_task_concurrency_limits [68974,69001]
name: has_task_concurrency_limits [70598,70625]
===
match
---
name: op2 [40626,40629]
name: op2 [40657,40660]
===
match
---
name: jinja2 [20686,20692]
name: jinja2 [20717,20723]
===
match
---
name: test_dag_naive_default_args_start_date [12679,12717]
name: test_dag_naive_default_args_start_date [12710,12748]
===
match
---
trailer [58603,58609]
trailer [58634,58640]
===
match
---
expr_stmt [55614,55767]
expr_stmt [55645,55798]
===
match
---
simple_stmt [3341,3421]
simple_stmt [3372,3452]
===
match
---
simple_stmt [77343,77396]
simple_stmt [78967,79020]
===
match
---
name: Path [69699,69703]
name: Path [71323,71327]
===
match
---
simple_stmt [9699,9728]
simple_stmt [9730,9759]
===
match
---
arglist [61187,61197]
arglist [61218,61228]
===
match
---
trailer [3254,3262]
trailer [3285,3293]
===
match
---
operator: = [14392,14393]
operator: = [14423,14424]
===
match
---
name: dag [31784,31787]
name: dag [31815,31818]
===
match
---
atom_expr [28180,28191]
atom_expr [28211,28222]
===
match
---
suite [3734,3853]
suite [3765,3884]
===
match
---
simple_stmt [36226,36280]
simple_stmt [36257,36311]
===
match
---
trailer [42120,42175]
trailer [42151,42206]
===
match
---
name: _next [25864,25869]
name: _next [25895,25900]
===
match
---
suite [40493,40710]
suite [40524,40741]
===
match
---
name: self [14627,14631]
name: self [14658,14662]
===
match
---
operator: = [18460,18461]
operator: = [18491,18492]
===
match
---
name: test_dag_task_priority_weight_total [13240,13275]
name: test_dag_task_priority_weight_total [13271,13306]
===
match
---
trailer [18752,18759]
trailer [18783,18790]
===
match
---
string: 'section-1' [65311,65322]
string: 'section-1' [66935,66946]
===
match
---
name: dag [53325,53328]
name: dag [53356,53359]
===
match
---
name: pytest [66439,66445]
name: pytest [68063,68069]
===
match
---
trailer [21937,21960]
trailer [21968,21991]
===
match
---
name: orm_dag [67497,67504]
name: orm_dag [69121,69128]
===
match
---
trailer [9949,9970]
trailer [9980,10001]
===
match
---
expr_stmt [47806,47861]
expr_stmt [47837,47892]
===
match
---
simple_stmt [68584,68600]
simple_stmt [70208,70224]
===
match
---
operator: , [30490,30491]
operator: , [30521,30522]
===
match
---
simple_stmt [10720,10742]
simple_stmt [10751,10773]
===
match
---
simple_stmt [26556,26623]
simple_stmt [26587,26654]
===
match
---
string: 'A' [10451,10454]
string: 'A' [10482,10485]
===
match
---
arglist [38475,38507]
arglist [38506,38538]
===
match
---
name: remove [11122,11128]
name: remove [11153,11159]
===
match
---
name: expected_infos [78730,78744]
name: expected_infos [80354,80368]
===
match
---
for_stmt [14003,14145]
for_stmt [14034,14176]
===
match
---
trailer [69362,69364]
trailer [70986,70988]
===
match
---
name: close [36873,36878]
name: close [36904,36909]
===
match
---
name: dag_id [66495,66501]
name: dag_id [68119,68125]
===
match
---
argument [34475,34498]
argument [34506,34529]
===
match
---
name: models [19755,19761]
name: models [19786,19792]
===
match
---
trailer [62834,62846]
trailer [62865,62877]
===
match
---
atom [28100,28192]
atom [28131,28223]
===
match
---
trailer [15470,15477]
trailer [15501,15508]
===
match
---
import_as_name [1568,1586]
import_as_name [1574,1592]
===
match
---
argument [66896,66935]
argument [68520,68559]
===
match
---
simple_stmt [67810,67826]
simple_stmt [69434,69450]
===
match
---
trailer [20953,20962]
trailer [20984,20993]
===
match
---
operator: = [31652,31653]
operator: = [31683,31684]
===
match
---
operator: = [37759,37760]
operator: = [37790,37791]
===
match
---
atom_expr [50810,50834]
atom_expr [50841,50865]
===
match
---
operator: , [74743,74744]
operator: , [76367,76368]
===
match
---
assert_stmt [48811,48843]
assert_stmt [48842,48874]
===
match
---
name: SUCCESS [77105,77112]
name: SUCCESS [78729,78736]
===
match
---
argument [53294,53308]
argument [53325,53339]
===
match
---
name: start_date [34475,34485]
name: start_date [34506,34516]
===
match
---
simple_stmt [10871,10902]
simple_stmt [10902,10933]
===
match
---
param [70931,70935]
param [72555,72559]
===
match
---
name: DagModel [31769,31777]
name: DagModel [31800,31808]
===
match
---
operator: = [25565,25566]
operator: = [25596,25597]
===
match
---
atom_expr [40146,40161]
atom_expr [40177,40192]
===
match
---
assert_stmt [57214,57256]
assert_stmt [57245,57287]
===
match
---
simple_stmt [59627,59756]
simple_stmt [59658,59787]
===
match
---
arglist [48214,48250]
arglist [48245,48281]
===
match
---
name: DagModel [28824,28832]
name: DagModel [28855,28863]
===
match
---
operator: , [48148,48149]
operator: , [48179,48180]
===
match
---
expr_stmt [21174,21212]
expr_stmt [21205,21243]
===
match
---
name: RUNNING [70549,70556]
name: RUNNING [72173,72180]
===
match
---
expr_stmt [76000,76083]
expr_stmt [77624,77707]
===
match
---
name: dates [58582,58587]
name: dates [58613,58618]
===
match
---
atom_expr [19547,19559]
atom_expr [19578,19590]
===
match
---
string: "task_4" [75884,75892]
string: "task_4" [77508,77516]
===
match
---
simple_stmt [18718,18737]
simple_stmt [18749,18768]
===
match
---
trailer [31269,31285]
trailer [31300,31316]
===
match
---
number: 1 [68116,68117]
number: 1 [69740,69741]
===
match
---
parameters [39646,39652]
parameters [39677,39683]
===
match
---
comparison [33956,33980]
comparison [33987,34011]
===
match
---
funcdef [14572,15946]
funcdef [14603,15977]
===
match
---
atom_expr [76737,76750]
atom_expr [78361,78374]
===
match
---
name: set2 [11104,11108]
name: set2 [11135,11139]
===
match
---
trailer [57905,57915]
trailer [57936,57946]
===
match
---
string: 'dag_without_catchup_once' [60817,60843]
string: 'dag_without_catchup_once' [60848,60874]
===
match
---
name: OnceTimetable [2032,2045]
name: OnceTimetable [2063,2076]
===
match
---
trailer [62825,62834]
trailer [62856,62865]
===
match
---
atom [54277,54290]
atom [54308,54321]
===
match
---
expr_stmt [67309,67385]
expr_stmt [68933,69009]
===
match
---
arglist [67095,67209]
arglist [68719,68833]
===
match
---
arglist [53557,53723]
arglist [53588,53754]
===
match
---
name: self [50384,50388]
name: self [50415,50419]
===
match
---
argument [40437,40491]
argument [40468,40522]
===
match
---
name: subdag [33704,33710]
name: subdag [33735,33741]
===
match
---
name: session [69349,69356]
name: session [70973,70980]
===
match
---
trailer [37594,37602]
trailer [37625,37633]
===
match
---
simple_stmt [75357,75398]
simple_stmt [76981,77022]
===
match
---
name: model [46365,46370]
name: model [46396,46401]
===
match
---
trailer [35729,35745]
trailer [35760,35776]
===
match
---
name: datetime [62081,62089]
name: datetime [62112,62120]
===
match
---
simple_stmt [48177,48252]
simple_stmt [48208,48283]
===
match
---
operator: = [31474,31475]
operator: = [31505,31506]
===
match
---
atom_expr [40100,40118]
atom_expr [40131,40149]
===
match
---
name: TI [56992,56994]
name: TI [57023,57025]
===
match
---
name: dag [47870,47873]
name: dag [47901,47904]
===
match
---
trailer [34916,34933]
trailer [34947,34964]
===
match
---
name: dates [58308,58313]
name: dates [58339,58344]
===
match
---
trailer [7720,7728]
trailer [7751,7759]
===
match
---
name: dag_id [67529,67535]
name: dag_id [69153,69159]
===
match
---
suite [14904,15946]
suite [14935,15977]
===
match
---
name: pytest [69522,69528]
name: pytest [71146,71152]
===
match
---
expr_stmt [20194,20291]
expr_stmt [20225,20322]
===
match
---
name: op3 [7199,7202]
name: op3 [7230,7233]
===
match
---
fstring [64747,64784]
fstring [66371,66408]
===
match
---
name: filter [57023,57029]
name: filter [57054,57060]
===
match
---
name: task_id [56265,56272]
name: task_id [56296,56303]
===
match
---
atom_expr [20857,20866]
atom_expr [20888,20897]
===
match
---
operator: + [15809,15810]
operator: + [15840,15841]
===
match
---
funcdef [71980,72028]
funcdef [73604,73652]
===
match
---
trailer [53032,53040]
trailer [53063,53071]
===
match
---
name: test_resolve_template_files_value [20712,20745]
name: test_resolve_template_files_value [20743,20776]
===
match
---
name: interval [78463,78471]
name: interval [80087,80095]
===
match
---
arglist [39254,39289]
arglist [39285,39320]
===
match
---
trailer [64328,64337]
trailer [65952,65961]
===
match
---
operator: = [41529,41530]
operator: = [41560,41561]
===
match
---
name: DAG [16156,16159]
name: DAG [16187,16190]
===
match
---
with_item [36942,36969]
with_item [36973,37000]
===
match
---
operator: = [63116,63117]
operator: = [63147,63148]
===
match
---
parameters [47690,47696]
parameters [47721,47727]
===
match
---
name: all [35940,35943]
name: all [35971,35974]
===
match
---
name: set_upstream [15516,15528]
name: set_upstream [15547,15559]
===
match
---
name: task_id [25645,25652]
name: task_id [25676,25683]
===
match
---
operator: , [34498,34499]
operator: , [34529,34530]
===
match
---
name: deactivate_deleted_dags [37950,37973]
name: deactivate_deleted_dags [37981,38004]
===
match
---
atom_expr [67060,67223]
atom_expr [68684,68847]
===
match
---
operator: , [43889,43890]
operator: , [43920,43921]
===
match
---
name: dag_id [42601,42607]
name: dag_id [42632,42638]
===
match
---
simple_stmt [54045,54121]
simple_stmt [54076,54152]
===
match
---
atom_expr [13738,13800]
atom_expr [13769,13831]
===
match
---
name: subdag [65347,65353]
name: subdag [66971,66977]
===
match
---
name: DummyOperator [1825,1838]
name: DummyOperator [1831,1844]
===
match
---
name: start_date [28127,28137]
name: start_date [28158,28168]
===
match
---
atom_expr [78542,78569]
atom_expr [80166,80193]
===
match
---
name: start_date [51828,51838]
name: start_date [51859,51869]
===
match
---
name: schedule_interval [45843,45860]
name: schedule_interval [45874,45891]
===
match
---
parameters [50383,50428]
parameters [50414,50459]
===
match
---
trailer [37795,37801]
trailer [37826,37832]
===
match
---
name: DAG [4116,4119]
name: DAG [4147,4150]
===
match
---
trailer [16857,16868]
trailer [16888,16899]
===
match
---
name: dag [40726,40729]
name: dag [40757,40760]
===
match
---
arglist [64941,64997]
arglist [66565,66621]
===
match
---
name: isinstance [72596,72606]
name: isinstance [74220,74230]
===
match
---
arglist [52745,52769]
arglist [52776,52800]
===
match
---
name: self [3107,3111]
name: self [3138,3142]
===
match
---
suite [75697,75995]
suite [77321,77619]
===
match
---
atom_expr [30038,30065]
atom_expr [30069,30096]
===
match
---
expr_stmt [39781,39814]
expr_stmt [39812,39845]
===
match
---
comparison [77488,77522]
comparison [79112,79146]
===
match
---
atom_expr [31611,31631]
atom_expr [31642,31662]
===
match
---
comparison [77350,77395]
comparison [78974,79019]
===
match
---
string: 'dag-bulk-sync-1' [30224,30241]
string: 'dag-bulk-sync-1' [30255,30272]
===
match
---
name: dag [44955,44958]
name: dag [44986,44989]
===
match
---
simple_stmt [69440,69464]
simple_stmt [71064,71088]
===
match
---
name: DEFAULT_DATE [52427,52439]
name: DEFAULT_DATE [52458,52470]
===
match
---
assert_stmt [25028,25083]
assert_stmt [25059,25114]
===
match
---
argument [61597,61632]
argument [61628,61663]
===
match
---
name: airflow [1435,1442]
name: airflow [1441,1448]
===
match
---
string: 'stage(\\d*).(\\d*)' [13367,13387]
string: 'stage(\\d*).(\\d*)' [13398,13418]
===
match
---
string: 'dag_with_outdated_perms' [66502,66527]
string: 'dag_with_outdated_perms' [68126,68151]
===
match
---
trailer [68573,68575]
trailer [70197,70199]
===
match
---
simple_stmt [1376,1430]
simple_stmt [1382,1436]
===
match
---
operator: , [37529,37530]
operator: , [37560,37561]
===
match
---
name: topological_list [8944,8960]
name: topological_list [8975,8991]
===
match
---
name: create_session [3200,3214]
name: create_session [3231,3245]
===
match
---
atom [66251,66424]
atom [67875,68048]
===
match
---
assert_stmt [52822,52846]
assert_stmt [52853,52877]
===
match
---
name: set [28733,28736]
name: set [28764,28767]
===
match
---
suite [20811,21302]
suite [20842,21333]
===
match
---
simple_stmt [41957,41991]
simple_stmt [41988,42022]
===
match
---
operator: , [6968,6969]
operator: , [6999,7000]
===
match
---
number: 1 [14080,14081]
number: 1 [14111,14112]
===
match
---
import_as_name [2270,2293]
import_as_name [2301,2324]
===
match
---
atom_expr [77986,78013]
atom_expr [79610,79637]
===
match
---
name: self [2828,2832]
name: self [2859,2863]
===
match
---
name: default_args [71475,71487]
name: default_args [73099,73111]
===
match
---
trailer [42642,42705]
trailer [42673,42736]
===
match
---
operator: = [64986,64987]
operator: = [66610,66611]
===
match
---
name: dag_id [59176,59182]
name: dag_id [59207,59213]
===
match
---
operator: = [69001,69002]
operator: = [70625,70626]
===
match
---
expr_stmt [48110,48168]
expr_stmt [48141,48199]
===
match
---
expr_stmt [43677,43900]
expr_stmt [43708,43931]
===
match
---
simple_stmt [23931,23987]
simple_stmt [23962,24018]
===
match
---
trailer [38203,38210]
trailer [38234,38241]
===
match
---
atom_expr [27457,27466]
atom_expr [27488,27497]
===
match
---
name: logical_date [62953,62965]
name: logical_date [62984,62996]
===
match
---
comparison [48572,48597]
comparison [48603,48628]
===
match
---
parameters [44503,44509]
parameters [44534,44540]
===
match
---
assert_stmt [49118,49144]
assert_stmt [49149,49175]
===
match
---
comparison [32695,32719]
comparison [32726,32750]
===
match
---
expr_stmt [44665,44700]
expr_stmt [44696,44731]
===
match
---
string: 'B' [9592,9595]
string: 'B' [9623,9626]
===
match
---
simple_stmt [47870,47912]
simple_stmt [47901,47943]
===
match
---
funcdef [3023,3136]
funcdef [3054,3167]
===
match
---
number: 0 [13858,13859]
number: 0 [13889,13890]
===
match
---
name: priority_weight_total [15865,15886]
name: priority_weight_total [15896,15917]
===
match
---
name: dag_run_state [54669,54682]
name: dag_run_state [54700,54713]
===
match
---
simple_stmt [29235,29262]
simple_stmt [29266,29293]
===
match
---
atom_expr [69817,69835]
atom_expr [71441,71459]
===
match
---
name: handle_callback [44230,44245]
name: handle_callback [44261,44276]
===
match
---
atom_expr [73835,73910]
atom_expr [75459,75534]
===
match
---
atom_expr [67536,67546]
atom_expr [69160,69170]
===
match
---
name: timedelta [77801,77810]
name: timedelta [79425,79434]
===
match
---
assert_stmt [25879,25934]
assert_stmt [25910,25965]
===
match
---
operator: = [52862,52863]
operator: = [52893,52894]
===
match
---
decorated [49850,50562]
decorated [49881,50593]
===
match
---
operator: = [44671,44672]
operator: = [44702,44703]
===
match
---
assert_stmt [38620,38661]
assert_stmt [38651,38692]
===
match
---
param [62169,62173]
param [62200,62204]
===
match
---
arglist [44986,45125]
arglist [45017,45156]
===
match
---
name: VALUE [73401,73406]
name: VALUE [75025,75030]
===
match
---
name: template_dir [21694,21706]
name: template_dir [21725,21737]
===
match
---
and_test [62777,62846]
and_test [62808,62877]
===
match
---
operator: = [74820,74821]
operator: = [76444,76445]
===
match
---
atom_expr [58627,58666]
atom_expr [58658,58697]
===
match
---
trailer [59807,59819]
trailer [59838,59850]
===
match
---
name: _dst [27314,27318]
name: _dst [27345,27349]
===
match
---
number: 1 [64082,64083]
number: 1 [65706,65707]
===
match
---
trailer [5744,5780]
trailer [5775,5811]
===
match
---
comparison [47288,47316]
comparison [47319,47347]
===
match
---
argument [50753,50769]
argument [50784,50800]
===
match
---
operator: , [29644,29645]
operator: , [29675,29676]
===
match
---
decorated [74241,74317]
decorated [75865,75941]
===
match
---
simple_stmt [73011,73022]
simple_stmt [74635,74646]
===
match
---
atom_expr [20405,20429]
atom_expr [20436,20460]
===
match
---
operator: } [12488,12489]
operator: } [12519,12520]
===
match
---
name: interval [58531,58539]
name: interval [58562,58570]
===
match
---
trailer [74897,74907]
trailer [76521,76531]
===
match
---
name: new_value [74494,74503]
name: new_value [76118,76127]
===
match
---
operator: = [8610,8611]
operator: = [8641,8642]
===
match
---
expr_stmt [47921,47965]
expr_stmt [47952,47996]
===
match
---
string: '.template' [20793,20804]
string: '.template' [20824,20835]
===
match
---
trailer [15528,15539]
trailer [15559,15570]
===
match
---
expr_stmt [59489,59531]
expr_stmt [59520,59562]
===
match
---
name: state [18322,18327]
name: state [18353,18358]
===
match
---
operator: = [15858,15859]
operator: = [15889,15890]
===
match
---
trailer [32594,32602]
trailer [32625,32633]
===
match
---
name: isoformat [22656,22665]
name: isoformat [22687,22696]
===
match
---
simple_stmt [58620,58667]
simple_stmt [58651,58698]
===
match
---
name: DagModel [67507,67515]
name: DagModel [69131,69139]
===
match
---
name: start [22458,22463]
name: start [22489,22494]
===
match
---
name: return_num [74389,74399]
name: return_num [76013,76023]
===
match
---
name: DummyOperator [75813,75826]
name: DummyOperator [77437,77450]
===
match
---
name: query [38043,38048]
name: query [38074,38079]
===
match
---
number: 4 [18962,18963]
number: 4 [18993,18994]
===
match
---
assert_stmt [33284,33328]
assert_stmt [33315,33359]
===
match
---
atom_expr [77510,77522]
atom_expr [79134,79146]
===
match
---
atom_expr [40582,40609]
atom_expr [40613,40640]
===
match
---
atom_expr [62817,62846]
atom_expr [62848,62877]
===
match
---
argument [39893,39905]
argument [39924,39936]
===
match
---
simple_stmt [73594,73618]
simple_stmt [75218,75242]
===
match
---
operator: , [35993,35994]
operator: , [36024,36025]
===
match
---
name: DEFAULT_DATE [78403,78415]
name: DEFAULT_DATE [80027,80039]
===
match
---
name: num [73464,73467]
name: num [75088,75091]
===
match
---
string: "test2" [17891,17898]
string: "test2" [17922,17929]
===
match
---
name: session [32664,32671]
name: session [32695,32702]
===
match
---
name: dag [37500,37503]
name: dag [37531,37534]
===
match
---
name: TI [76199,76201]
name: TI [77823,77825]
===
match
---
name: SubDagOperator [32503,32517]
name: SubDagOperator [32534,32548]
===
match
---
suite [58514,58611]
suite [58545,58642]
===
match
---
param [64610,64625]
param [66234,66249]
===
match
---
simple_stmt [71385,71443]
simple_stmt [73009,73067]
===
match
---
operator: == [12838,12840]
operator: == [12869,12871]
===
match
---
operator: = [66846,66847]
operator: = [68470,68471]
===
match
---
name: timedelta [50301,50310]
name: timedelta [50332,50341]
===
match
---
operator: = [69827,69828]
operator: = [71451,71452]
===
match
---
parameters [65978,65984]
parameters [67602,67608]
===
match
---
argument [37752,37767]
argument [37783,37798]
===
match
---
operator: , [47945,47946]
operator: , [47976,47977]
===
match
---
trailer [65608,65618]
trailer [67232,67242]
===
match
---
operator: } [27898,27899]
operator: } [27929,27930]
===
match
---
trailer [24763,24765]
trailer [24794,24796]
===
match
---
operator: , [8412,8413]
operator: , [8443,8444]
===
match
---
name: set_upstream [9703,9715]
name: set_upstream [9734,9746]
===
match
---
arglist [29942,29968]
arglist [29973,29999]
===
match
---
name: lower [5838,5843]
name: lower [5869,5874]
===
match
---
simple_stmt [68557,68576]
simple_stmt [70181,70200]
===
match
---
simple_stmt [51935,51964]
simple_stmt [51966,51995]
===
match
---
operator: = [21790,21791]
operator: = [21821,21822]
===
match
---
operator: , [53113,53114]
operator: , [53144,53145]
===
match
---
operator: , [35812,35813]
operator: , [35843,35844]
===
match
---
argument [47010,47035]
argument [47041,47066]
===
match
---
name: self [43400,43404]
name: self [43431,43435]
===
match
---
assert_stmt [40174,40204]
assert_stmt [40205,40235]
===
match
---
dictorsetmaker [39131,39139]
dictorsetmaker [39162,39170]
===
match
---
trailer [62080,62089]
trailer [62111,62120]
===
match
---
name: dag [1660,1663]
name: dag [1666,1669]
===
match
---
number: 1 [10003,10004]
number: 1 [10034,10035]
===
match
---
import_from [1145,1193]
import_from [1151,1199]
===
match
---
name: start_date [19803,19813]
name: start_date [19834,19844]
===
match
---
name: test_task [18280,18289]
name: test_task [18311,18320]
===
match
---
atom_expr [77210,77238]
atom_expr [78834,78862]
===
match
---
simple_stmt [73835,73911]
simple_stmt [75459,75535]
===
match
---
operator: { [41236,41237]
operator: { [41267,41268]
===
match
---
trailer [56359,56373]
trailer [56390,56404]
===
match
---
with_stmt [41407,41605]
with_stmt [41438,41636]
===
match
---
atom_expr [21468,21488]
atom_expr [21499,21519]
===
match
---
suite [34320,34400]
suite [34351,34431]
===
match
---
trailer [20785,20805]
trailer [20816,20836]
===
match
---
simple_stmt [24691,24727]
simple_stmt [24722,24758]
===
match
---
name: dag [38813,38816]
name: dag [38844,38847]
===
match
---
expr_stmt [31093,31116]
expr_stmt [31124,31147]
===
match
---
operator: = [5751,5752]
operator: = [5782,5783]
===
match
---
operator: , [35328,35329]
operator: , [35359,35360]
===
match
---
name: dr [51503,51505]
name: dr [51534,51536]
===
match
---
simple_stmt [1101,1115]
simple_stmt [1107,1121]
===
match
---
number: 1 [57430,57431]
number: 1 [57461,57462]
===
match
---
number: 28 [22270,22272]
number: 28 [22301,22303]
===
match
---
name: dag_id [49803,49809]
name: dag_id [49834,49840]
===
match
---
operator: , [7566,7567]
operator: , [7597,7598]
===
match
---
name: ACTION_CAN_READ [66287,66302]
name: ACTION_CAN_READ [67911,67926]
===
match
---
testlist_comp [9870,9883]
testlist_comp [9901,9914]
===
match
---
name: DEFAULT_DATE [53681,53693]
name: DEFAULT_DATE [53712,53724]
===
match
---
atom_expr [37201,37221]
atom_expr [37232,37252]
===
match
---
atom_expr [20044,20070]
atom_expr [20075,20101]
===
match
---
funcdef [71350,71752]
funcdef [72974,73376]
===
match
---
argument [6037,6092]
argument [6068,6123]
===
match
---
comparison [20663,20702]
comparison [20694,20733]
===
match
---
simple_stmt [58385,58428]
simple_stmt [58416,58459]
===
match
---
name: compile [14784,14791]
name: compile [14815,14822]
===
match
---
atom_expr [41647,41660]
atom_expr [41678,41691]
===
match
---
name: dags [30020,30024]
name: dags [30051,30055]
===
match
---
simple_stmt [18481,18506]
simple_stmt [18512,18537]
===
match
---
atom_expr [6433,6448]
atom_expr [6464,6479]
===
match
---
operator: , [4169,4170]
operator: , [4200,4201]
===
match
---
simple_stmt [55614,55768]
simple_stmt [55645,55799]
===
match
---
name: prev_local [23030,23040]
name: prev_local [23061,23071]
===
match
---
operator: + [54613,54614]
operator: + [54644,54645]
===
match
---
name: default_args [47893,47905]
name: default_args [47924,47936]
===
match
---
name: merge [18726,18731]
name: merge [18757,18762]
===
match
---
name: op3 [39873,39876]
name: op3 [39904,39907]
===
match
---
string: "2018-03-24T02:00:00+00:00" [25278,25305]
string: "2018-03-24T02:00:00+00:00" [25309,25336]
===
match
---
operator: , [67578,67579]
operator: , [69202,69203]
===
match
---
trailer [38553,38558]
trailer [38584,38589]
===
match
---
number: 4 [63246,63247]
number: 4 [63277,63278]
===
match
---
trailer [76201,76208]
trailer [77825,77832]
===
match
---
name: get_num_task_instances [19076,19098]
name: get_num_task_instances [19107,19129]
===
match
---
operator: , [61191,61192]
operator: , [61222,61223]
===
match
---
name: TestDagModel [67232,67244]
name: TestDagModel [68856,68868]
===
match
---
name: DAG [69817,69820]
name: DAG [71441,71444]
===
match
---
operator: = [16444,16445]
operator: = [16475,16476]
===
match
---
name: xcom_pass_to_op [74468,74483]
name: xcom_pass_to_op [76092,76107]
===
match
---
string: 'end_date' [11738,11748]
string: 'end_date' [11769,11779]
===
match
---
name: datetime [62033,62041]
name: datetime [62064,62072]
===
match
---
trailer [36878,36880]
trailer [36909,36911]
===
match
---
name: local_tz [38445,38453]
name: local_tz [38476,38484]
===
match
---
name: state [76033,76038]
name: state [77657,77662]
===
match
---
atom_expr [35797,35812]
atom_expr [35828,35843]
===
match
---
atom_expr [78994,79025]
atom_expr [80618,80649]
===
match
---
trailer [64258,64264]
trailer [65882,65888]
===
match
---
name: days [50311,50315]
name: days [50342,50346]
===
match
---
atom_expr [30757,30763]
atom_expr [30788,30794]
===
match
---
expr_stmt [37096,37185]
expr_stmt [37127,37216]
===
match
---
name: dagruns [52631,52638]
name: dagruns [52662,52669]
===
match
---
operator: , [19271,19272]
operator: , [19302,19303]
===
match
---
simple_stmt [33915,33988]
simple_stmt [33946,34019]
===
match
---
name: self [51756,51760]
name: self [51787,51791]
===
match
---
string: 'test_field' [21198,21210]
string: 'test_field' [21229,21241]
===
match
---
assert_stmt [74330,74364]
assert_stmt [75954,75988]
===
match
---
atom_expr [62969,62998]
atom_expr [63000,63029]
===
match
---
name: next_dagrun_create_after [67679,67703]
name: next_dagrun_create_after [69303,69327]
===
match
---
dictorsetmaker [30205,30279]
dictorsetmaker [30236,30310]
===
match
---
operator: = [74690,74691]
operator: = [76314,76315]
===
match
---
trailer [17611,17656]
trailer [17642,17687]
===
match
---
name: i [28175,28176]
name: i [28206,28207]
===
match
---
simple_stmt [52899,52936]
simple_stmt [52930,52967]
===
match
---
trailer [62648,62661]
trailer [62679,62692]
===
match
---
argument [48150,48167]
argument [48181,48198]
===
match
---
atom_expr [72041,72054]
atom_expr [73665,73678]
===
match
---
simple_stmt [72214,72279]
simple_stmt [73838,73903]
===
match
---
operator: = [50271,50272]
operator: = [50302,50303]
===
match
---
name: dag [46076,46079]
name: dag [46107,46110]
===
match
---
expr_stmt [26078,26149]
expr_stmt [26109,26180]
===
match
---
simple_stmt [46880,46911]
simple_stmt [46911,46942]
===
match
---
atom_expr [21732,21760]
atom_expr [21763,21791]
===
match
---
number: 3 [57940,57941]
number: 3 [57971,57972]
===
match
---
trailer [63680,63703]
trailer [65304,65327]
===
match
---
name: dag_subclass [49344,49356]
name: dag_subclass [49375,49387]
===
match
---
operator: = [56838,56839]
operator: = [56869,56870]
===
match
---
name: parent_dag [53405,53415]
name: parent_dag [53436,53446]
===
match
---
number: 5 [13299,13300]
number: 5 [13330,13331]
===
match
---
atom_expr [30642,30653]
atom_expr [30673,30684]
===
match
---
operator: = [74162,74163]
operator: = [75786,75787]
===
match
---
trailer [29171,29184]
trailer [29202,29215]
===
match
---
trailer [59902,60089]
trailer [59933,60120]
===
match
---
operator: = [17417,17418]
operator: = [17448,17449]
===
match
---
trailer [3726,3733]
trailer [3757,3764]
===
match
---
atom_expr [6941,6979]
atom_expr [6972,7010]
===
match
---
trailer [68900,68902]
trailer [70524,70526]
===
match
---
trailer [77364,77372]
trailer [78988,78996]
===
match
---
operator: , [70896,70897]
operator: , [72520,72521]
===
match
---
param [47691,47695]
param [47722,47726]
===
match
---
expr_stmt [27407,27467]
expr_stmt [27438,27498]
===
match
---
trailer [31326,31330]
trailer [31357,31361]
===
match
---
trailer [45946,46023]
trailer [45977,46054]
===
match
---
simple_stmt [15772,15823]
simple_stmt [15803,15854]
===
match
---
parameters [72360,72362]
parameters [73984,73986]
===
match
---
trailer [64241,64258]
trailer [65865,65882]
===
match
---
operator: = [56195,56196]
operator: = [56226,56227]
===
match
---
operator: , [63746,63747]
operator: , [65370,65371]
===
match
---
name: next_dagrun [31819,31830]
name: next_dagrun [31850,31861]
===
match
---
arglist [70352,70400]
arglist [71976,72024]
===
match
---
expr_stmt [57160,57193]
expr_stmt [57191,57224]
===
match
---
name: add_task [42621,42629]
name: add_task [42652,42660]
===
match
---
name: self [74764,74768]
name: self [76388,76392]
===
match
---
trailer [51306,51349]
trailer [51337,51380]
===
match
---
atom_expr [19402,19415]
atom_expr [19433,19446]
===
match
---
name: data_interval [57655,57668]
name: data_interval [57686,57699]
===
match
---
string: 'test_dags' [68762,68773]
string: 'test_dags' [70386,70397]
===
match
---
name: dag_id [49690,49696]
name: dag_id [49721,49727]
===
match
---
name: i [16571,16572]
name: i [16602,16603]
===
match
---
string: "dag.callback_exceptions" [44369,44394]
string: "dag.callback_exceptions" [44400,44425]
===
match
---
operator: , [2644,2645]
operator: , [2675,2676]
===
match
---
name: timedelta [27066,27075]
name: timedelta [27097,27106]
===
match
---
operator: = [21243,21244]
operator: = [21274,21275]
===
match
---
atom_expr [29033,29056]
atom_expr [29064,29087]
===
match
---
atom_expr [11166,11185]
atom_expr [11197,11216]
===
match
---
trailer [15568,15578]
trailer [15599,15609]
===
match
---
name: default_args [17295,17307]
name: default_args [17326,17338]
===
match
---
name: dag [34719,34722]
name: dag [34750,34753]
===
match
---
string: 'role1' [66031,66038]
string: 'role1' [67655,67662]
===
match
---
trailer [20672,20682]
trailer [20703,20713]
===
match
---
atom [69555,69587]
atom [71179,71211]
===
match
---
comparison [57047,57066]
comparison [57078,57097]
===
match
---
suite [58372,58611]
suite [58403,58642]
===
match
---
param [11670,11674]
param [11701,11705]
===
match
---
testlist_comp [35082,35099]
testlist_comp [35113,35130]
===
match
---
trailer [20461,20471]
trailer [20492,20502]
===
match
---
operator: , [13652,13653]
operator: , [13683,13684]
===
match
---
name: assert_queries_count [70415,70435]
name: assert_queries_count [72039,72059]
===
match
---
name: half_an_hour_ago [60247,60263]
name: half_an_hour_ago [60278,60294]
===
match
---
simple_stmt [52293,52324]
simple_stmt [52324,52355]
===
match
---
simple_stmt [18514,18558]
simple_stmt [18545,18589]
===
match
---
assert_stmt [22707,22767]
assert_stmt [22738,22798]
===
match
---
name: timetable [50530,50539]
name: timetable [50561,50570]
===
match
---
atom_expr [34973,35135]
atom_expr [35004,35166]
===
match
---
operator: , [8929,8930]
operator: , [8960,8961]
===
match
---
trailer [72140,72147]
trailer [73764,73771]
===
match
---
trailer [7411,7415]
trailer [7442,7446]
===
match
---
operator: = [46371,46372]
operator: = [46402,46403]
===
match
---
trailer [31316,31326]
trailer [31347,31357]
===
match
---
trailer [10723,10736]
trailer [10754,10767]
===
match
---
name: State [76899,76904]
name: State [78523,78528]
===
match
---
simple_stmt [18566,18592]
simple_stmt [18597,18623]
===
match
---
operator: , [19231,19232]
operator: , [19262,19263]
===
match
---
name: DagRunType [31611,31621]
name: DagRunType [31642,31652]
===
match
---
name: default_args [38598,38610]
name: default_args [38629,38641]
===
match
---
name: default_args [13147,13159]
name: default_args [13178,13190]
===
match
---
argument [23512,23541]
argument [23543,23572]
===
match
---
name: clear_db_runs [70058,70071]
name: clear_db_runs [71682,71695]
===
match
---
trailer [37129,37136]
trailer [37160,37167]
===
match
---
operator: = [78828,78829]
operator: = [80452,80453]
===
match
---
trailer [41668,41676]
trailer [41699,41707]
===
match
---
name: assert_queries_count [2461,2481]
name: assert_queries_count [2492,2512]
===
match
---
operator: , [51625,51626]
operator: , [51656,51657]
===
match
---
name: dag2 [7074,7078]
name: dag2 [7105,7109]
===
match
---
number: 2 [59875,59876]
number: 2 [59906,59907]
===
match
---
simple_stmt [37894,37932]
simple_stmt [37925,37963]
===
match
---
trailer [32922,32926]
trailer [32953,32957]
===
match
---
atom [55849,55927]
atom [55880,55958]
===
match
---
name: next_dagrun_create_after [46479,46503]
name: next_dagrun_create_after [46510,46534]
===
match
---
assert_stmt [23931,23986]
assert_stmt [23962,24017]
===
match
---
name: start_date [53848,53858]
name: start_date [53879,53889]
===
match
---
name: state [55874,55879]
name: state [55905,55910]
===
match
---
name: subdag [34699,34705]
name: subdag [34730,34736]
===
match
---
atom [12763,12808]
atom [12794,12839]
===
match
---
operator: = [68398,68399]
operator: = [70022,70023]
===
match
---
operator: , [32184,32185]
operator: , [32215,32216]
===
match
---
name: hours [77811,77816]
name: hours [79435,79440]
===
match
---
name: parent_dag [8829,8839]
name: parent_dag [8860,8870]
===
match
---
name: row [30302,30305]
name: row [30333,30336]
===
match
---
name: b_index [3883,3890]
name: b_index [3914,3921]
===
match
---
testlist_comp [50095,50138]
testlist_comp [50126,50169]
===
match
---
string: 'test_scheduler_auto_align_2' [64001,64030]
string: 'test_scheduler_auto_align_2' [65625,65654]
===
match
---
name: State [55913,55918]
name: State [55944,55949]
===
match
---
name: session [44053,44060]
name: session [44084,44091]
===
match
---
operator: , [54218,54219]
operator: , [54249,54250]
===
match
---
atom [29824,29855]
atom [29855,29886]
===
match
---
operator: = [73922,73923]
operator: = [75546,75547]
===
match
---
name: TEST_DATE [46012,46021]
name: TEST_DATE [46043,46052]
===
match
---
operator: = [67650,67651]
operator: = [69274,69275]
===
match
---
operator: = [4705,4706]
operator: = [4736,4737]
===
match
---
suite [16807,16869]
suite [16838,16900]
===
match
---
name: i [13898,13899]
name: i [13929,13930]
===
match
---
atom_expr [42102,42175]
atom_expr [42133,42206]
===
match
---
trailer [67372,67384]
trailer [68996,69008]
===
match
---
argument [58136,58153]
argument [58167,58184]
===
match
---
trailer [39376,39390]
trailer [39407,39421]
===
match
---
operator: == [48436,48438]
operator: == [48467,48469]
===
match
---
operator: , [6710,6711]
operator: , [6741,6742]
===
match
---
name: session [35392,35399]
name: session [35423,35430]
===
match
---
funcdef [70169,70614]
funcdef [71793,72238]
===
match
---
testlist_comp [50154,50192]
testlist_comp [50185,50223]
===
match
---
number: 4 [63959,63960]
number: 4 [65583,65584]
===
match
---
name: DummyOperator [10519,10532]
name: DummyOperator [10550,10563]
===
match
---
atom_expr [37993,38013]
atom_expr [38024,38044]
===
match
---
trailer [34843,34892]
trailer [34874,34923]
===
match
---
atom [46401,46414]
atom [46432,46445]
===
match
---
operator: } [41253,41254]
operator: } [41284,41285]
===
match
---
atom [58316,58318]
atom [58347,58349]
===
match
---
operator: = [18576,18577]
operator: = [18607,18608]
===
match
---
operator: == [48514,48516]
operator: == [48545,48547]
===
match
---
name: start_date [39736,39746]
name: start_date [39767,39777]
===
match
---
name: dag_id [57060,57066]
name: dag_id [57091,57097]
===
match
---
simple_stmt [40576,40610]
simple_stmt [40607,40641]
===
match
---
name: super [70946,70951]
name: super [72570,72575]
===
match
---
name: session [19281,19288]
name: session [19312,19319]
===
match
---
expr_stmt [66485,66565]
expr_stmt [68109,68189]
===
match
---
name: DAG [29235,29238]
name: DAG [29266,29269]
===
match
---
name: include_downstream [42150,42168]
name: include_downstream [42181,42199]
===
match
---
argument [10488,10499]
argument [10519,10530]
===
match
---
name: get [37280,37283]
name: get [37311,37314]
===
match
---
name: test_field [21984,21994]
name: test_field [22015,22025]
===
match
---
operator: = [42843,42844]
operator: = [42874,42875]
===
match
---
operator: , [66383,66384]
operator: , [68007,68008]
===
match
---
expr_stmt [69811,69835]
expr_stmt [71435,71459]
===
match
---
number: 2020 [61792,61796]
number: 2020 [61823,61827]
===
match
---
string: 'test-dag' [28654,28664]
string: 'test-dag' [28685,28695]
===
match
---
trailer [55279,55297]
trailer [55310,55328]
===
match
---
name: depth [16585,16590]
name: depth [16616,16621]
===
match
---
operator: == [77239,77241]
operator: == [78863,78865]
===
match
---
trailer [63779,63822]
trailer [65403,65446]
===
match
---
atom_expr [65271,65425]
atom_expr [66895,67049]
===
match
---
string: 't1' [42212,42216]
string: 't1' [42243,42247]
===
match
---
name: DEFAULT_DATE [41056,41068]
name: DEFAULT_DATE [41087,41099]
===
match
---
operator: = [18243,18244]
operator: = [18274,18275]
===
match
---
argument [54591,54641]
argument [54622,54672]
===
match
---
trailer [34705,34716]
trailer [34736,34747]
===
match
---
name: op3 [41683,41686]
name: op3 [41714,41717]
===
match
---
string: "2015-01-02T02:00:00+00:00" [25907,25934]
string: "2015-01-02T02:00:00+00:00" [25938,25965]
===
match
---
name: dag_id [35415,35421]
name: dag_id [35446,35452]
===
match
---
trailer [37643,37651]
trailer [37674,37682]
===
match
---
number: 1 [77622,77623]
number: 1 [79246,79247]
===
match
---
name: state [18162,18167]
name: state [18193,18198]
===
match
---
number: 1 [17954,17955]
number: 1 [17985,17986]
===
match
---
name: days [52461,52465]
name: days [52492,52496]
===
match
---
name: _clean_up [45547,45556]
name: _clean_up [45578,45587]
===
match
---
operator: = [19280,19281]
operator: = [19311,19312]
===
match
---
atom_expr [55275,55306]
atom_expr [55306,55337]
===
match
---
simple_stmt [68911,69156]
simple_stmt [70535,70780]
===
match
---
arglist [52686,52693]
arglist [52717,52724]
===
match
---
trailer [34346,34399]
trailer [34377,34430]
===
match
---
trailer [46396,46400]
trailer [46427,46431]
===
match
---
string: 'stage(\\d*).(\\d*)' [14792,14812]
string: 'stage(\\d*).(\\d*)' [14823,14843]
===
match
---
atom_expr [43195,43208]
atom_expr [43226,43239]
===
match
---
name: datetime [26086,26094]
name: datetime [26117,26125]
===
match
---
arglist [6398,6428]
arglist [6429,6459]
===
match
---
trailer [10791,10806]
trailer [10822,10837]
===
match
---
argument [8426,8452]
argument [8457,8483]
===
match
---
operator: = [50676,50677]
operator: = [50707,50708]
===
match
---
atom [35176,35191]
atom [35207,35222]
===
match
---
atom_expr [4197,4212]
atom_expr [4228,4243]
===
match
---
operator: = [76486,76487]
operator: = [78110,78111]
===
match
---
name: catchup [60946,60953]
name: catchup [60977,60984]
===
match
---
operator: = [7361,7362]
operator: = [7392,7393]
===
match
---
name: permissions [66275,66286]
name: permissions [67899,67910]
===
match
---
name: flush [54514,54519]
name: flush [54545,54550]
===
match
---
trailer [72578,72580]
trailer [74202,74204]
===
match
---
string: 'owner' [11446,11453]
string: 'owner' [11477,11484]
===
match
---
name: range [58360,58365]
name: range [58391,58396]
===
match
---
name: dag [42237,42240]
name: dag [42268,42271]
===
match
---
operator: = [22782,22783]
operator: = [22813,22814]
===
match
---
name: six_hours_ago_to_the_hour [59627,59652]
name: six_hours_ago_to_the_hour [59658,59683]
===
match
---
trailer [33619,33828]
trailer [33650,33859]
===
match
---
simple_stmt [54452,54498]
simple_stmt [54483,54529]
===
match
---
operator: = [19860,19861]
operator: = [19891,19892]
===
match
---
trailer [49558,49571]
trailer [49589,49602]
===
match
---
operator: = [7152,7153]
operator: = [7183,7184]
===
match
---
parameters [71369,71375]
parameters [72993,72999]
===
match
---
name: filter [3263,3269]
name: filter [3294,3300]
===
match
---
trailer [56256,56282]
trailer [56287,56313]
===
match
---
name: minutes [59808,59815]
name: minutes [59839,59846]
===
match
---
name: task_dict [15569,15578]
name: task_dict [15600,15609]
===
match
---
arglist [31140,31181]
arglist [31171,31212]
===
match
---
trailer [27303,27313]
trailer [27334,27344]
===
match
---
name: width [16115,16120]
name: width [16146,16151]
===
match
---
name: set_upstream [9744,9756]
name: set_upstream [9775,9787]
===
match
---
name: xcom_pass_to_op [73374,73389]
name: xcom_pass_to_op [74998,75013]
===
match
---
name: id [42191,42193]
name: id [42222,42224]
===
match
---
argument [41045,41068]
argument [41076,41099]
===
match
---
number: 5 [63243,63244]
number: 5 [63274,63275]
===
match
---
operator: , [74704,74705]
operator: , [76328,76329]
===
match
---
operator: = [33644,33645]
operator: = [33675,33676]
===
match
---
atom_expr [76408,76436]
atom_expr [78032,78060]
===
match
---
name: create_dagrun [18135,18148]
name: create_dagrun [18166,18179]
===
match
---
trailer [62454,62463]
trailer [62485,62494]
===
match
---
name: op1 [41678,41681]
name: op1 [41709,41712]
===
match
---
name: OnceTimetable [45911,45924]
name: OnceTimetable [45942,45955]
===
match
---
comparison [32742,32797]
comparison [32773,32828]
===
match
---
name: isoformat [23880,23889]
name: isoformat [23911,23920]
===
match
---
dotted_name [49851,49871]
dotted_name [49882,49902]
===
match
---
name: jinja_env [20663,20672]
name: jinja_env [20694,20703]
===
match
---
name: bulk_write_to_db [28248,28264]
name: bulk_write_to_db [28279,28295]
===
match
---
name: i [15293,15294]
name: i [15324,15325]
===
match
---
atom_expr [41734,41745]
atom_expr [41765,41776]
===
match
---
name: op2 [10754,10757]
name: op2 [10785,10788]
===
match
---
string: """Test that @dag uses function name as default dag id.""" [71796,71854]
string: """Test that @dag uses function name as default dag id.""" [73420,73478]
===
match
---
operator: == [4194,4196]
operator: == [4225,4227]
===
match
---
name: task_decorator [71953,71967]
name: task_decorator [73577,73591]
===
match
---
operator: = [7337,7338]
operator: = [7368,7369]
===
match
---
name: self [71892,71896]
name: self [73516,73520]
===
match
---
string: 'start_date' [65380,65392]
string: 'start_date' [67004,67016]
===
match
---
operator: == [6430,6432]
operator: == [6461,6463]
===
match
---
atom_expr [71278,71288]
atom_expr [72902,72912]
===
match
---
decorator [74135,74182]
decorator [75759,75806]
===
match
---
operator: , [65760,65761]
operator: , [67384,67385]
===
match
---
argument [75729,75745]
argument [77353,77369]
===
match
---
trailer [66584,66599]
trailer [68208,68223]
===
match
---
atom_expr [70338,70401]
atom_expr [71962,72025]
===
match
---
simple_stmt [32887,32968]
simple_stmt [32918,32999]
===
match
---
comparison [25035,25083]
comparison [25066,25114]
===
match
---
name: DAG [31249,31252]
name: DAG [31280,31283]
===
match
---
name: ACTION_CAN_EDIT [66397,66412]
name: ACTION_CAN_EDIT [68021,68036]
===
match
---
operator: = [52495,52496]
operator: = [52526,52527]
===
match
---
simple_stmt [10423,10456]
simple_stmt [10454,10487]
===
match
---
atom_expr [31966,31996]
atom_expr [31997,32027]
===
match
---
atom_expr [50292,50318]
atom_expr [50323,50349]
===
match
---
trailer [10532,10545]
trailer [10563,10576]
===
match
---
name: parent_dag [34706,34716]
name: parent_dag [34737,34747]
===
match
---
atom_expr [9525,9551]
atom_expr [9556,9582]
===
match
---
expr_stmt [8370,8500]
expr_stmt [8401,8531]
===
match
---
comparison [30390,30661]
comparison [30421,30692]
===
match
---
name: state [74685,74690]
name: state [76309,76314]
===
match
---
operator: , [43980,43981]
operator: , [44011,44012]
===
match
---
trailer [67788,67792]
trailer [69412,69416]
===
match
---
operator: , [15195,15196]
operator: , [15226,15227]
===
match
---
argument [17691,17711]
argument [17722,17742]
===
match
---
name: DummyOperator [32156,32169]
name: DummyOperator [32187,32200]
===
match
---
operator: = [50917,50918]
operator: = [50948,50949]
===
match
---
funcdef [74926,75398]
funcdef [76550,77022]
===
match
---
operator: , [69654,69655]
operator: , [71278,71279]
===
match
---
expr_stmt [10236,10311]
expr_stmt [10267,10342]
===
match
---
operator: = [56171,56172]
operator: = [56202,56203]
===
match
---
operator: = [32101,32102]
operator: = [32132,32133]
===
match
---
atom_expr [28733,28785]
atom_expr [28764,28816]
===
match
---
string: 'b_child' [9085,9094]
string: 'b_child' [9116,9125]
===
match
---
operator: = [59718,59719]
operator: = [59749,59750]
===
match
---
operator: , [31631,31632]
operator: , [31662,31663]
===
match
---
name: test_previous_schedule_datetime_timezone [25944,25984]
name: test_previous_schedule_datetime_timezone [25975,26015]
===
match
---
name: default_args [38495,38507]
name: default_args [38526,38538]
===
match
---
param [51262,51266]
param [51293,51297]
===
match
---
name: next_dagrun_info [57495,57511]
name: next_dagrun_info [57526,57542]
===
match
---
atom_expr [18075,18101]
atom_expr [18106,18132]
===
match
---
trailer [42940,42947]
trailer [42971,42978]
===
match
---
trailer [31310,31316]
trailer [31341,31347]
===
match
---
operator: , [19789,19790]
operator: , [19820,19821]
===
match
---
simple_stmt [35755,35956]
simple_stmt [35786,35987]
===
match
---
suite [14633,15946]
suite [14664,15977]
===
match
---
name: topological_sort [10844,10860]
name: topological_sort [10875,10891]
===
match
---
name: create_dagrun [53530,53543]
name: create_dagrun [53561,53574]
===
match
---
assert_stmt [37238,37324]
assert_stmt [37269,37355]
===
match
---
operator: , [43713,43714]
operator: , [43744,43745]
===
match
---
operator: = [69225,69226]
operator: = [70849,70850]
===
match
---
simple_stmt [48500,48521]
simple_stmt [48531,48552]
===
match
---
operator: , [44918,44919]
operator: , [44949,44950]
===
match
---
param [72199,72203]
param [73823,73827]
===
match
---
operator: , [78415,78416]
operator: , [80039,80040]
===
match
---
name: TI [56601,56603]
name: TI [56632,56634]
===
match
---
trailer [6789,6856]
trailer [6820,6887]
===
match
---
atom_expr [9986,10005]
atom_expr [10017,10036]
===
match
---
trailer [67539,67546]
trailer [69163,69170]
===
match
---
atom_expr [47160,47181]
atom_expr [47191,47212]
===
match
---
trailer [46984,46994]
trailer [47015,47025]
===
match
---
suite [3824,3853]
suite [3855,3884]
===
match
---
operator: , [78505,78506]
operator: , [80129,80130]
===
match
---
operator: = [4733,4734]
operator: = [4764,4765]
===
match
---
comparison [63900,63961]
comparison [65524,65585]
===
match
---
operator: = [39877,39878]
operator: = [39908,39909]
===
match
---
name: tzinfo [27450,27456]
name: tzinfo [27481,27487]
===
match
---
name: subdag_id [35206,35215]
name: subdag_id [35237,35246]
===
match
---
expr_stmt [70856,70900]
expr_stmt [72480,72524]
===
match
---
name: start [24602,24607]
name: start [24633,24638]
===
match
---
name: dag [53526,53529]
name: dag [53557,53560]
===
match
---
name: orm_dag [33313,33320]
name: orm_dag [33344,33351]
===
match
---
argument [19388,19416]
argument [19419,19447]
===
match
---
assert_stmt [48500,48520]
assert_stmt [48531,48551]
===
match
---
name: create_session [30156,30170]
name: create_session [30187,30201]
===
match
---
argument [46746,46771]
argument [46777,46802]
===
match
---
name: filter [54892,54898]
name: filter [54923,54929]
===
match
---
name: run_type [51055,51063]
name: run_type [51086,51094]
===
match
---
argument [73330,73360]
argument [74954,74984]
===
match
---
arglist [68041,68121]
arglist [69665,69745]
===
match
---
string: 'dag' [6705,6710]
string: 'dag' [6736,6741]
===
match
---
name: create_dagrun [76019,76032]
name: create_dagrun [77643,77656]
===
match
---
operator: = [39338,39339]
operator: = [39369,39370]
===
match
---
argument [19533,19575]
argument [19564,19606]
===
match
---
name: State [55110,55115]
name: State [55141,55146]
===
match
---
name: dag2 [60318,60322]
name: dag2 [60349,60353]
===
match
---
name: f [21501,21502]
name: f [21532,21533]
===
match
---
trailer [44349,44368]
trailer [44380,44399]
===
match
---
trailer [69108,69116]
trailer [70732,70740]
===
match
---
trailer [42629,42706]
trailer [42660,42737]
===
match
---
arglist [27726,27793]
arglist [27757,27824]
===
match
---
simple_stmt [23190,23262]
simple_stmt [23221,23293]
===
match
---
simple_stmt [74330,74365]
simple_stmt [75954,75989]
===
match
---
trailer [23366,23383]
trailer [23397,23414]
===
match
---
operator: , [51826,51827]
operator: , [51857,51858]
===
match
---
simple_stmt [25470,25513]
simple_stmt [25501,25544]
===
match
---
operator: , [55264,55265]
operator: , [55295,55296]
===
match
---
trailer [56862,56872]
trailer [56893,56903]
===
match
---
with_item [2700,2727]
with_item [2731,2758]
===
match
---
name: DagModel [35004,35012]
name: DagModel [35035,35043]
===
match
---
trailer [36667,36677]
trailer [36698,36708]
===
match
---
argument [22494,22510]
argument [22525,22541]
===
match
---
assert_stmt [57678,57702]
assert_stmt [57709,57733]
===
match
---
simple_stmt [39177,39237]
simple_stmt [39208,39268]
===
match
---
name: match [15621,15626]
name: match [15652,15657]
===
match
---
factor [3673,3675]
factor [3704,3706]
===
match
---
argument [31523,31542]
argument [31554,31573]
===
match
---
assert_stmt [10151,10184]
assert_stmt [10182,10215]
===
match
---
simple_stmt [8012,8035]
simple_stmt [8043,8066]
===
match
---
operator: , [32786,32787]
operator: , [32817,32818]
===
match
---
suite [50429,50562]
suite [50460,50593]
===
match
---
string: "Invalid input for param param1: None is not of type 'string'" [66983,67045]
string: "Invalid input for param param1: None is not of type 'string'" [68607,68669]
===
match
---
comparison [28518,28785]
comparison [28549,28816]
===
match
---
name: self [70931,70935]
name: self [72555,72559]
===
match
---
name: is_active [38126,38135]
name: is_active [38157,38166]
===
match
---
atom_expr [68751,68799]
atom_expr [70375,70423]
===
match
---
atom_expr [62665,62694]
atom_expr [62696,62725]
===
match
---
name: patch [43327,43332]
name: patch [43358,43363]
===
match
---
assert_stmt [45422,45462]
assert_stmt [45453,45493]
===
match
---
name: tasks_count [70205,70216]
name: tasks_count [71829,71840]
===
match
---
operator: = [67619,67620]
operator: = [69243,69244]
===
match
---
name: topological_list [10122,10138]
name: topological_list [10153,10169]
===
match
---
suite [41836,42394]
suite [41867,42425]
===
match
---
operator: , [53376,53377]
operator: , [53407,53408]
===
match
---
name: has_task_concurrency_limits [67592,67619]
name: has_task_concurrency_limits [69216,69243]
===
match
---
trailer [36730,36732]
trailer [36761,36763]
===
match
---
operator: = [38391,38392]
operator: = [38422,38423]
===
match
---
name: test_documentation_added [72174,72198]
name: test_documentation_added [73798,73822]
===
match
---
operator: = [65791,65792]
operator: = [67415,67416]
===
match
---
name: models [4670,4676]
name: models [4701,4707]
===
match
---
name: next_dagrun_info [60118,60134]
name: next_dagrun_info [60149,60165]
===
match
---
name: DEFAULT_DATE [18060,18072]
name: DEFAULT_DATE [18091,18103]
===
match
---
name: access_control [66585,66599]
name: access_control [68209,68223]
===
match
---
string: 'section-1' [65366,65377]
string: 'section-1' [66990,67001]
===
match
---
import_name [863,878]
import_name [863,878]
===
match
---
parameters [69767,69801]
parameters [71391,71425]
===
match
---
trailer [65746,65764]
trailer [67370,67388]
===
match
---
argument [38585,38610]
argument [38616,38641]
===
match
---
arglist [71708,71716]
arglist [73332,73340]
===
match
---
name: stdout [40054,40060]
name: stdout [40085,40091]
===
match
---
atom [77912,78603]
atom [79536,80227]
===
match
---
name: DummyOperator [64927,64940]
name: DummyOperator [66551,66564]
===
match
---
trailer [60134,60140]
trailer [60165,60171]
===
match
---
atom_expr [7469,7478]
atom_expr [7500,7509]
===
match
---
name: dag_id [65061,65067]
name: dag_id [66685,66691]
===
match
---
name: Session [33856,33863]
name: Session [33887,33894]
===
match
---
name: convert [23838,23845]
name: convert [23869,23876]
===
match
---
simple_stmt [60272,60309]
simple_stmt [60303,60340]
===
match
---
assert_stmt [69875,69923]
assert_stmt [71499,71547]
===
match
---
name: DagTag [28766,28772]
name: DagTag [28797,28803]
===
match
---
name: dag [38524,38527]
name: dag [38555,38558]
===
match
---
operator: = [23504,23505]
operator: = [23535,23536]
===
match
---
operator: = [19042,19043]
operator: = [19073,19074]
===
match
---
atom_expr [38118,38135]
atom_expr [38149,38166]
===
match
---
trailer [67712,67721]
trailer [69336,69345]
===
match
---
atom_expr [11214,11233]
atom_expr [11245,11264]
===
match
---
operator: + [55936,55937]
operator: + [55967,55968]
===
match
---
operator: == [71333,71335]
operator: == [72957,72959]
===
match
---
name: op5 [7357,7360]
name: op5 [7388,7391]
===
match
---
trailer [31232,31238]
trailer [31263,31269]
===
match
---
parameters [56018,56069]
parameters [56049,56100]
===
match
---
argument [59200,59235]
argument [59231,59266]
===
match
---
name: session [67460,67467]
name: session [69084,69091]
===
match
---
trailer [36684,36726]
trailer [36715,36757]
===
match
---
name: op5 [10603,10606]
name: op5 [10634,10637]
===
match
---
trailer [54310,54318]
trailer [54341,54349]
===
match
---
fstring [28105,28125]
fstring [28136,28156]
===
match
---
name: dags [29091,29095]
name: dags [29122,29126]
===
match
---
testlist_comp [29874,29904]
testlist_comp [29905,29935]
===
match
---
trailer [69323,69333]
trailer [70947,70957]
===
match
---
name: local_tz [25150,25158]
name: local_tz [25181,25189]
===
match
---
atom_expr [31008,31084]
atom_expr [31039,31115]
===
match
---
operator: = [39476,39477]
operator: = [39507,39508]
===
match
---
name: dr [73924,73926]
name: dr [75548,75550]
===
match
---
operator: , [22275,22276]
operator: , [22306,22307]
===
match
---
trailer [29159,29164]
trailer [29190,29195]
===
match
---
atom_expr [4159,4169]
atom_expr [4190,4200]
===
match
---
name: datetime_tz [75575,75586]
name: datetime_tz [77199,77210]
===
match
---
name: test_dag_id [19220,19231]
name: test_dag_id [19251,19262]
===
match
---
name: SCHEDULED [76073,76082]
name: SCHEDULED [77697,77706]
===
match
---
arglist [52014,52157]
arglist [52045,52188]
===
match
---
funcdef [9269,10185]
funcdef [9300,10216]
===
match
---
string: 'tz_dag' [27486,27494]
string: 'tz_dag' [27517,27525]
===
match
---
argument [42684,42704]
argument [42715,42735]
===
match
---
name: dag [32049,32052]
name: dag [32080,32083]
===
match
---
name: session [56705,56712]
name: session [56736,56743]
===
match
---
operator: , [35609,35610]
operator: , [35640,35641]
===
match
---
operator: , [33794,33795]
operator: , [33825,33826]
===
match
---
testlist_comp [29726,29755]
testlist_comp [29757,29786]
===
match
---
expr_stmt [55224,55252]
expr_stmt [55255,55283]
===
match
---
param [3036,3040]
param [3067,3071]
===
match
---
operator: = [8476,8477]
operator: = [8507,8508]
===
match
---
trailer [18731,18736]
trailer [18762,18767]
===
match
---
atom_expr [48348,48364]
atom_expr [48379,48395]
===
match
---
atom_expr [21633,21707]
atom_expr [21664,21738]
===
match
---
name: op1 [40757,40760]
name: op1 [40788,40791]
===
match
---
operator: = [33845,33846]
operator: = [33876,33877]
===
match
---
name: DummyOperator [39787,39800]
name: DummyOperator [39818,39831]
===
match
---
operator: = [17307,17308]
operator: = [17338,17339]
===
match
---
simple_stmt [53961,54037]
simple_stmt [53992,54068]
===
match
---
atom_expr [77264,77292]
atom_expr [78888,78916]
===
match
---
name: days [31859,31863]
name: days [31890,31894]
===
match
---
operator: = [33410,33411]
operator: = [33441,33442]
===
match
---
operator: , [59955,59956]
operator: , [59986,59987]
===
match
---
trailer [31730,31737]
trailer [31761,31768]
===
match
---
operator: == [23892,23894]
operator: == [23923,23925]
===
match
---
expr_stmt [31295,31345]
expr_stmt [31326,31376]
===
match
---
name: DEFAULT_DATE [33459,33471]
name: DEFAULT_DATE [33490,33502]
===
match
---
trailer [43595,43605]
trailer [43626,43636]
===
match
---
operator: = [6915,6916]
operator: = [6946,6947]
===
match
---
operator: = [57402,57403]
operator: = [57433,57434]
===
match
---
atom_expr [7658,7668]
atom_expr [7689,7699]
===
match
---
import_as_name [1407,1429]
import_as_name [1413,1435]
===
match
---
funcdef [64582,65030]
funcdef [66206,66654]
===
match
---
name: next_subdag_info [65838,65854]
name: next_subdag_info [67462,67478]
===
match
---
name: test_max_active_runs_not_none [67986,68015]
name: test_max_active_runs_not_none [69610,69639]
===
match
---
atom_expr [57127,57146]
atom_expr [57158,57177]
===
match
---
trailer [26298,26300]
trailer [26329,26331]
===
match
---
trailer [75286,75295]
trailer [76910,76919]
===
match
---
trailer [71736,71743]
trailer [73360,73367]
===
match
---
operator: , [12917,12918]
operator: , [12948,12949]
===
match
---
assert_stmt [75357,75397]
assert_stmt [76981,77021]
===
match
---
operator: = [17606,17607]
operator: = [17637,17638]
===
match
---
for_stmt [3705,3853]
for_stmt [3736,3884]
===
match
---
trailer [10442,10455]
trailer [10473,10486]
===
match
---
trailer [18351,18386]
trailer [18382,18417]
===
match
---
trailer [9057,9071]
trailer [9088,9102]
===
match
---
name: DAG [44776,44779]
name: DAG [44807,44810]
===
match
---
funcdef [26337,26731]
funcdef [26368,26762]
===
match
---
operator: = [47468,47469]
operator: = [47499,47500]
===
match
---
import_as_names [1725,1740]
import_as_names [1731,1746]
===
match
---
string: 'DAG' [13140,13145]
string: 'DAG' [13171,13176]
===
match
---
suite [50616,50837]
suite [50647,50868]
===
match
---
param [27343,27348]
param [27374,27379]
===
match
---
string: 'owner1' [32778,32786]
string: 'owner1' [32809,32817]
===
match
---
atom_expr [52176,52199]
atom_expr [52207,52230]
===
match
---
operator: = [23529,23530]
operator: = [23560,23561]
===
match
---
parameters [58802,58808]
parameters [58833,58839]
===
match
---
name: State [46183,46188]
name: State [46214,46219]
===
match
---
name: state [31523,31528]
name: state [31554,31559]
===
match
---
name: end_date [58136,58144]
name: end_date [58167,58175]
===
match
---
operator: = [47024,47025]
operator: = [47055,47056]
===
match
---
trailer [22665,22667]
trailer [22696,22698]
===
match
---
trailer [74907,74909]
trailer [76531,76533]
===
match
---
operator: = [68882,68883]
operator: = [70506,70507]
===
match
---
name: default_args [12638,12650]
name: default_args [12669,12681]
===
match
---
simple_stmt [44770,44845]
simple_stmt [44801,44876]
===
match
---
simple_stmt [67781,67802]
simple_stmt [69405,69426]
===
match
---
operator: = [53237,53238]
operator: = [53268,53269]
===
match
---
operator: = [6722,6723]
operator: = [6753,6754]
===
match
---
operator: = [20586,20587]
operator: = [20617,20618]
===
match
---
name: DagModel [33048,33056]
name: DagModel [33079,33087]
===
match
---
atom_expr [67394,67450]
atom_expr [69018,69074]
===
match
---
arglist [55668,55675]
arglist [55699,55706]
===
match
---
atom_expr [68244,68442]
atom_expr [69868,70066]
===
match
---
operator: , [76729,76730]
operator: , [78353,78354]
===
match
---
arglist [62987,62997]
arglist [63018,63028]
===
match
---
operator: * [14435,14436]
operator: * [14466,14467]
===
match
---
operator: = [62506,62507]
operator: = [62537,62538]
===
match
---
name: e [3712,3713]
name: e [3743,3744]
===
match
---
name: DagModel [37137,37145]
name: DagModel [37168,37176]
===
match
---
name: convert [22619,22626]
name: convert [22650,22657]
===
match
---
trailer [21508,21510]
trailer [21539,21541]
===
match
---
dictorsetmaker [12412,12488]
dictorsetmaker [12443,12519]
===
match
---
name: timedelta [939,948]
name: timedelta [939,948]
===
match
---
trailer [58630,58666]
trailer [58661,58697]
===
match
---
name: types [2313,2318]
name: types [2344,2349]
===
match
---
comparison [39593,39622]
comparison [39624,39653]
===
match
---
name: assert_queries_count [29198,29218]
name: assert_queries_count [29229,29249]
===
match
---
return_stmt [59575,59585]
return_stmt [59606,59616]
===
match
---
operator: = [60874,60875]
operator: = [60905,60906]
===
match
---
name: where [38189,38194]
name: where [38220,38225]
===
match
---
name: op1 [39781,39784]
name: op1 [39812,39815]
===
match
---
atom_expr [66439,66471]
atom_expr [68063,68095]
===
match
---
name: last_loaded [48371,48382]
name: last_loaded [48402,48413]
===
match
---
name: dates [58478,58483]
name: dates [58509,58514]
===
match
---
operator: , [39085,39086]
operator: , [39116,39117]
===
match
---
with_item [41850,41897]
with_item [41881,41928]
===
match
---
operator: } [77624,77625]
operator: } [79248,79249]
===
match
---
name: state [17872,17877]
name: state [17903,17908]
===
match
---
trailer [41976,41990]
trailer [42007,42021]
===
match
---
operator: == [26700,26702]
operator: == [26731,26733]
===
match
---
name: DagModel [35682,35690]
name: DagModel [35713,35721]
===
match
---
argument [19143,19158]
argument [19174,19189]
===
match
---
funcdef [47662,49371]
funcdef [47693,49402]
===
match
---
expr_stmt [22934,22969]
expr_stmt [22965,23000]
===
match
---
trailer [59698,59755]
trailer [59729,59786]
===
match
---
name: dag_id [43517,43523]
name: dag_id [43548,43554]
===
match
---
name: task_5 [75902,75908]
name: task_5 [77526,77532]
===
match
---
operator: , [64608,64609]
operator: , [66232,66233]
===
match
---
trailer [59690,59698]
trailer [59721,59729]
===
match
---
atom_expr [4759,4780]
atom_expr [4790,4811]
===
match
---
number: 0 [59729,59730]
number: 0 [59760,59761]
===
match
---
decorated [43326,44448]
decorated [43357,44479]
===
match
---
trailer [70959,70961]
trailer [72583,72585]
===
match
---
operator: > [49139,49140]
operator: > [49170,49171]
===
match
---
name: dag2 [6779,6783]
name: dag2 [6810,6814]
===
match
---
trailer [50266,50274]
trailer [50297,50305]
===
match
---
assert_stmt [20656,20702]
assert_stmt [20687,20733]
===
match
---
string: "+0530" [27152,27159]
string: "+0530" [27183,27190]
===
match
---
trailer [46943,47150]
trailer [46974,47181]
===
match
---
name: default_args [12398,12410]
name: default_args [12429,12441]
===
match
---
simple_stmt [31295,31346]
simple_stmt [31326,31377]
===
match
---
name: dag [39597,39600]
name: dag [39628,39631]
===
match
---
trailer [53161,53187]
trailer [53192,53218]
===
match
---
operator: = [6164,6165]
operator: = [6195,6196]
===
match
---
trailer [79011,79025]
trailer [80635,80649]
===
match
---
operator: = [41938,41939]
operator: = [41969,41970]
===
match
---
operator: = [10838,10839]
operator: = [10869,10870]
===
match
---
name: self [9053,9057]
name: self [9084,9088]
===
match
---
dotted_name [1697,1717]
dotted_name [1703,1723]
===
match
---
name: filter [38059,38065]
name: filter [38090,38096]
===
match
---
simple_stmt [57526,57603]
simple_stmt [57557,57634]
===
match
---
operator: = [48365,48366]
operator: = [48396,48397]
===
match
---
name: dag [40555,40558]
name: dag [40586,40589]
===
match
---
simple_stmt [22474,22545]
simple_stmt [22505,22576]
===
match
---
operator: = [78566,78567]
operator: = [80190,80191]
===
match
---
argument [3302,3327]
argument [3333,3358]
===
match
---
name: pytest [6005,6011]
name: pytest [6036,6042]
===
match
---
trailer [44301,44324]
trailer [44332,44355]
===
match
---
name: orm_dag [68234,68241]
name: orm_dag [69858,69865]
===
match
---
name: op2 [41199,41202]
name: op2 [41230,41233]
===
match
---
expr_stmt [12867,12925]
expr_stmt [12898,12956]
===
match
---
sync_comp_for [13801,13825]
sync_comp_for [13832,13856]
===
match
---
with_stmt [70410,70614]
with_stmt [72034,72238]
===
match
---
name: noop_pipeline [72912,72925]
name: noop_pipeline [74536,74549]
===
match
---
trailer [42620,42629]
trailer [42651,42660]
===
match
---
atom_expr [3107,3135]
atom_expr [3138,3166]
===
match
---
simple_stmt [62618,62695]
simple_stmt [62649,62726]
===
match
---
arglist [32518,32566]
arglist [32549,32597]
===
match
---
name: DagTag [29942,29948]
name: DagTag [29973,29979]
===
match
---
atom_expr [31849,31866]
atom_expr [31880,31897]
===
match
---
suite [50904,51220]
suite [50935,51251]
===
match
---
atom_expr [20989,21063]
atom_expr [21020,21094]
===
match
---
trailer [37509,37582]
trailer [37540,37613]
===
match
---
trailer [72083,72085]
trailer [73707,73709]
===
match
---
argument [55542,55564]
argument [55573,55595]
===
match
---
operator: , [30222,30223]
operator: , [30253,30254]
===
match
---
name: i [15023,15024]
name: i [15054,15055]
===
match
---
atom_expr [49361,49370]
atom_expr [49392,49401]
===
match
---
name: DAG [41029,41032]
name: DAG [41060,41063]
===
match
---
dotted_name [1844,1868]
dotted_name [1850,1874]
===
match
---
atom_expr [46473,46503]
atom_expr [46504,46534]
===
match
---
suite [21064,21117]
suite [21095,21148]
===
match
---
fstring_start: f' [64949,64951]
fstring_start: f' [66573,66575]
===
match
---
operator: = [64819,64820]
operator: = [66443,66444]
===
match
---
return_stmt [27370,27397]
return_stmt [27401,27428]
===
match
---
name: task_id [7627,7634]
name: task_id [7658,7665]
===
match
---
string: 'param1' [66904,66912]
string: 'param1' [68528,68536]
===
match
---
arglist [53294,53332]
arglist [53325,53363]
===
match
---
trailer [64173,64216]
trailer [65797,65840]
===
match
---
with_stmt [37662,37769]
with_stmt [37693,37800]
===
match
---
name: DAG [33711,33714]
name: DAG [33742,33745]
===
match
---
operator: = [32484,32485]
operator: = [32515,32516]
===
match
---
operator: = [46858,46859]
operator: = [46889,46890]
===
match
---
name: op3 [59558,59561]
name: op3 [59589,59592]
===
match
---
trailer [21101,21116]
trailer [21132,21147]
===
match
---
atom [67922,67924]
atom [69546,69548]
===
match
---
comparison [24161,24208]
comparison [24192,24239]
===
match
---
name: timezone [64320,64328]
name: timezone [65944,65952]
===
match
---
atom [50247,50320]
atom [50278,50351]
===
match
---
name: DEFAULT_DATE [73897,73909]
name: DEFAULT_DATE [75521,75533]
===
match
---
fstring_start: f' [19724,19726]
fstring_start: f' [19755,19757]
===
match
---
atom [31331,31344]
atom [31362,31375]
===
match
---
atom_expr [40744,40755]
atom_expr [40775,40786]
===
match
---
atom_expr [56173,56228]
atom_expr [56204,56259]
===
match
---
operator: , [53722,53723]
operator: , [53753,53754]
===
match
---
simple_stmt [59575,59586]
simple_stmt [59606,59617]
===
match
---
operator: { [11445,11446]
operator: { [11476,11477]
===
match
---
funcdef [32014,33353]
funcdef [32045,33384]
===
match
---
atom_expr [50276,50319]
atom_expr [50307,50350]
===
match
---
operator: , [50751,50752]
operator: , [50782,50783]
===
match
---
trailer [27959,27966]
trailer [27990,27997]
===
match
---
operator: , [39264,39265]
operator: , [39295,39296]
===
match
---
trailer [77613,77620]
trailer [79237,79244]
===
match
---
operator: , [63948,63949]
operator: , [65572,65573]
===
match
---
operator: , [28714,28715]
operator: , [28745,28746]
===
match
---
param [44504,44508]
param [44535,44539]
===
match
---
dictorsetmaker [19862,19880]
dictorsetmaker [19893,19911]
===
match
---
atom_expr [2988,3017]
atom_expr [3019,3048]
===
match
---
name: op3 [10703,10706]
name: op3 [10734,10737]
===
match
---
number: 5 [62841,62842]
number: 5 [62872,62873]
===
match
---
name: task_instances [57131,57145]
name: task_instances [57162,57176]
===
match
---
atom_expr [12778,12807]
atom_expr [12809,12838]
===
match
---
trailer [13139,13181]
trailer [13170,13212]
===
match
---
name: task_2 [75963,75969]
name: task_2 [77587,77593]
===
match
---
operator: = [52143,52144]
operator: = [52174,52175]
===
match
---
name: set_upstream [10724,10736]
name: set_upstream [10755,10767]
===
match
---
atom_expr [46183,46196]
atom_expr [46214,46227]
===
match
---
trailer [42922,42929]
trailer [42953,42960]
===
match
---
name: DAG [62344,62347]
name: DAG [62375,62378]
===
match
---
arglist [66859,66935]
arglist [68483,68559]
===
match
---
simple_stmt [44425,44448]
simple_stmt [44456,44479]
===
match
---
string: 'b_child' [8350,8359]
string: 'b_child' [8381,8390]
===
match
---
trailer [32627,32644]
trailer [32658,32675]
===
match
---
name: DagModel [36668,36676]
name: DagModel [36699,36707]
===
match
---
trailer [21592,21597]
trailer [21623,21628]
===
match
---
name: topological_list [10992,11008]
name: topological_list [11023,11039]
===
match
---
simple_stmt [23474,23543]
simple_stmt [23505,23574]
===
match
---
name: test_set_jinja_env_additional_option [20142,20178]
name: test_set_jinja_env_additional_option [20173,20209]
===
match
---
trailer [32745,32773]
trailer [32776,32804]
===
match
---
trailer [61757,61770]
trailer [61788,61801]
===
match
---
name: task_2 [76423,76429]
name: task_2 [78047,78053]
===
match
---
operator: = [43967,43968]
operator: = [43998,43999]
===
match
---
name: list_ [3572,3577]
name: list_ [3603,3608]
===
match
---
name: start_date [6712,6722]
name: start_date [6743,6753]
===
match
---
name: end_date [54591,54599]
name: end_date [54622,54630]
===
match
---
name: op1 [10423,10426]
name: op1 [10454,10457]
===
match
---
simple_stmt [59595,59619]
simple_stmt [59626,59650]
===
match
---
number: 0 [30306,30307]
number: 0 [30337,30338]
===
match
---
name: task_id [64941,64948]
name: task_id [66565,66572]
===
match
---
name: default_view [32902,32914]
name: default_view [32933,32945]
===
match
---
string: 'airflow' [68854,68863]
string: 'airflow' [70478,70487]
===
match
---
trailer [54142,54159]
trailer [54173,54190]
===
match
---
name: downstream_list [42218,42233]
name: downstream_list [42249,42264]
===
match
---
operator: = [8349,8350]
operator: = [8380,8381]
===
match
---
name: calculated_weight [17040,17057]
name: calculated_weight [17071,17088]
===
match
---
operator: = [70869,70870]
operator: = [72493,72494]
===
match
---
arglist [27433,27466]
arglist [27464,27497]
===
match
---
string: """Test that @dag uses function docs as doc_md for DAG object""" [72214,72278]
string: """Test that @dag uses function docs as doc_md for DAG object""" [73838,73902]
===
match
---
name: next_info [57547,57556]
name: next_info [57578,57587]
===
match
---
name: stage [15296,15301]
name: stage [15327,15332]
===
match
---
simple_stmt [8893,8962]
simple_stmt [8924,8993]
===
match
---
argument [44820,44843]
argument [44851,44874]
===
match
---
name: tearDown [71000,71008]
name: tearDown [72624,72632]
===
match
---
name: dag [41716,41719]
name: dag [41747,41750]
===
match
---
trailer [62800,62813]
trailer [62831,62844]
===
match
---
trailer [60333,60511]
trailer [60364,60542]
===
match
---
trailer [76993,77001]
trailer [78617,78625]
===
match
---
name: test_set_task_instance_state [75404,75432]
name: test_set_task_instance_state [77028,77056]
===
match
---
trailer [51189,51198]
trailer [51220,51229]
===
match
---
name: datetime [65115,65123]
name: datetime [66739,66747]
===
match
---
name: self [73343,73347]
name: self [74967,74971]
===
match
---
operator: , [55953,55954]
operator: , [55984,55985]
===
match
---
name: timezone [61774,61782]
name: timezone [61805,61813]
===
match
---
name: range [13852,13857]
name: range [13883,13888]
===
match
---
trailer [73978,73980]
trailer [75602,75604]
===
match
---
parameters [62168,62174]
parameters [62199,62205]
===
match
---
string: "test_dag_callback_crash" [43526,43551]
string: "test_dag_callback_crash" [43557,43582]
===
match
---
operator: , [62524,62525]
operator: , [62555,62556]
===
match
---
trailer [56318,56320]
trailer [56349,56351]
===
match
---
name: local_tz [24430,24438]
name: local_tz [24461,24469]
===
match
---
name: session [52969,52976]
name: session [53000,53007]
===
match
---
trailer [32602,32604]
trailer [32633,32635]
===
match
---
name: schedule_interval [64802,64819]
name: schedule_interval [66426,66443]
===
match
---
name: dag [56770,56773]
name: dag [56801,56804]
===
match
---
name: all [35130,35133]
name: all [35161,35164]
===
match
---
operator: { [66274,66275]
operator: { [67898,67899]
===
match
---
name: isoformat [24103,24112]
name: isoformat [24134,24143]
===
match
---
operator: , [63957,63958]
operator: , [65581,65582]
===
match
---
atom_expr [11202,11234]
atom_expr [11233,11265]
===
match
---
atom_expr [11117,11149]
atom_expr [11148,11180]
===
match
---
funcdef [41775,42394]
funcdef [41806,42425]
===
match
---
simple_stmt [11117,11150]
simple_stmt [11148,11181]
===
match
---
expr_stmt [20930,20970]
expr_stmt [20961,21001]
===
match
---
operator: , [16359,16360]
operator: , [16390,16391]
===
match
---
string: "test-dag" [28158,28168]
string: "test-dag" [28189,28199]
===
match
---
expr_stmt [32576,32604]
expr_stmt [32607,32635]
===
match
---
testlist_comp [49896,49917]
testlist_comp [49927,49948]
===
match
---
arglist [24447,24514]
arglist [24478,24545]
===
match
---
operator: = [56277,56278]
operator: = [56308,56309]
===
match
---
string: 'end_date' [12566,12576]
string: 'end_date' [12597,12607]
===
match
---
atom_expr [19257,19270]
atom_expr [19288,19301]
===
match
---
simple_stmt [11022,11040]
simple_stmt [11053,11071]
===
match
---
operator: == [79079,79081]
operator: == [80703,80705]
===
match
---
trailer [55789,55795]
trailer [55820,55826]
===
match
---
atom_expr [12593,12630]
atom_expr [12624,12661]
===
match
---
trailer [63934,63943]
trailer [65558,65567]
===
match
---
name: params [5250,5256]
name: params [5281,5287]
===
match
---
name: conf [6389,6393]
name: conf [6420,6424]
===
match
---
number: 4 [72052,72053]
number: 4 [73676,73677]
===
match
---
operator: , [73881,73882]
operator: , [75505,75506]
===
match
---
atom_expr [76439,76452]
atom_expr [78063,78076]
===
match
---
simple_stmt [42912,42948]
simple_stmt [42943,42979]
===
match
---
operator: , [53177,53178]
operator: , [53208,53209]
===
match
---
with_item [49712,49739]
with_item [49743,49770]
===
match
---
name: session [18938,18945]
name: session [18969,18976]
===
match
---
import_as_names [1527,1586]
import_as_names [1533,1592]
===
match
---
arglist [34556,34587]
arglist [34587,34618]
===
match
---
trailer [35499,35520]
trailer [35530,35551]
===
match
---
parameters [71088,71094]
parameters [72712,72718]
===
match
---
name: task_id [14237,14244]
name: task_id [14268,14275]
===
match
---
string: 'parameter1' [4795,4807]
string: 'parameter1' [4826,4838]
===
match
---
name: default_args [59325,59337]
name: default_args [59356,59368]
===
match
---
string: 'dag-bulk-sync-0' [29528,29545]
string: 'dag-bulk-sync-0' [29559,29576]
===
match
---
trailer [74423,74432]
trailer [76047,76056]
===
match
---
name: noop_pipeline [71923,71936]
name: noop_pipeline [73547,73560]
===
match
---
trailer [10960,10963]
trailer [10991,10994]
===
match
---
name: schedule_interval [60396,60413]
name: schedule_interval [60427,60444]
===
match
---
trailer [56063,56068]
trailer [56094,56099]
===
match
---
atom_expr [20587,20603]
atom_expr [20618,20634]
===
match
---
name: run_id [51394,51400]
name: run_id [51425,51431]
===
match
---
name: assert_queries_count [28207,28227]
name: assert_queries_count [28238,28258]
===
match
---
operator: = [27055,27056]
operator: = [27086,27087]
===
match
---
number: 0 [64093,64094]
number: 0 [65717,65718]
===
match
---
name: timedelta [59671,59680]
name: timedelta [59702,59711]
===
match
---
name: State [47090,47095]
name: State [47121,47126]
===
match
---
testlist_comp [29528,29557]
testlist_comp [29559,29588]
===
match
---
name: State [51160,51165]
name: State [51191,51196]
===
match
---
name: self [64406,64410]
name: self [66030,66034]
===
match
---
parameters [23174,23180]
parameters [23205,23211]
===
match
---
comparison [37901,37931]
comparison [37932,37962]
===
match
---
arglist [41854,41889]
arglist [41885,41920]
===
match
---
operator: , [19018,19019]
operator: , [19049,19050]
===
match
---
operator: = [63800,63801]
operator: = [65424,65425]
===
match
---
name: DagModel [30700,30708]
name: DagModel [30731,30739]
===
match
---
argument [54696,54716]
argument [54727,54747]
===
match
---
simple_stmt [21835,21874]
simple_stmt [21866,21905]
===
match
---
operator: , [20271,20272]
operator: , [20302,20303]
===
match
---
trailer [54898,54930]
trailer [54929,54961]
===
match
---
operator: = [10472,10473]
operator: = [10503,10504]
===
match
---
name: DEFAULT_DATE [50739,50751]
name: DEFAULT_DATE [50770,50782]
===
match
---
argument [64044,64095]
argument [65668,65719]
===
match
---
operator: , [35641,35642]
operator: , [35672,35673]
===
match
---
simple_stmt [68664,68737]
simple_stmt [70288,70361]
===
match
---
operator: == [63923,63925]
operator: == [65547,65549]
===
match
---
suite [45202,45266]
suite [45233,45297]
===
match
---
name: current_task [14108,14120]
name: current_task [14139,14151]
===
match
---
trailer [20332,20334]
trailer [20363,20365]
===
match
---
name: start_date [10253,10263]
name: start_date [10284,10294]
===
match
---
comparison [13950,13956]
comparison [13981,13987]
===
match
---
atom_expr [24161,24177]
atom_expr [24192,24208]
===
match
---
trailer [20359,20381]
trailer [20390,20412]
===
match
---
name: operator [74769,74777]
name: operator [76393,76401]
===
match
---
atom_expr [38066,38081]
atom_expr [38097,38112]
===
match
---
atom_expr [73984,73994]
atom_expr [75608,75618]
===
match
---
name: is_active [67747,67756]
name: is_active [69371,69380]
===
match
---
name: next_dagrun_info [61000,61016]
name: next_dagrun_info [61031,61047]
===
match
---
operator: = [67152,67153]
operator: = [68776,68777]
===
match
---
atom_expr [37106,37185]
atom_expr [37137,37216]
===
match
---
name: dag [31161,31164]
name: dag [31192,31195]
===
match
---
atom_expr [58478,58496]
atom_expr [58509,58527]
===
match
---
operator: == [7036,7038]
operator: == [7067,7069]
===
match
---
argument [44920,44943]
argument [44951,44974]
===
match
---
name: DEFAULT_DATE [55377,55389]
name: DEFAULT_DATE [55408,55420]
===
match
---
operator: , [44793,44794]
operator: , [44824,44825]
===
match
---
operator: , [67546,67547]
operator: , [69170,69171]
===
match
---
expr_stmt [32654,32726]
expr_stmt [32685,32757]
===
match
---
trailer [37651,37653]
trailer [37682,37684]
===
match
---
trailer [14236,14244]
trailer [14267,14275]
===
match
---
name: DAG [18783,18786]
name: DAG [18814,18817]
===
match
---
with_stmt [16151,17146]
with_stmt [16182,17177]
===
match
---
operator: = [40652,40653]
operator: = [40683,40684]
===
match
---
simple_stmt [53018,53041]
simple_stmt [53049,53072]
===
match
---
trailer [29948,29955]
trailer [29979,29986]
===
match
---
arglist [40415,40491]
arglist [40446,40522]
===
match
---
assert_stmt [23639,23699]
assert_stmt [23670,23730]
===
match
---
arglist [37004,37052]
arglist [37035,37083]
===
match
---
import_name [853,862]
import_name [853,862]
===
match
---
name: cron_timetable [50052,50066]
name: cron_timetable [50083,50097]
===
match
---
trailer [36677,36684]
trailer [36708,36715]
===
match
---
assert_stmt [60272,60308]
assert_stmt [60303,60339]
===
match
---
operator: , [33471,33472]
operator: , [33502,33503]
===
match
---
expr_stmt [67460,67488]
expr_stmt [69084,69112]
===
match
---
operator: < [49009,49010]
operator: < [49040,49041]
===
match
---
trailer [66643,66649]
trailer [68267,68273]
===
match
---
name: self [52963,52967]
name: self [52994,52998]
===
match
---
trailer [13366,13388]
trailer [13397,13419]
===
match
---
simple_stmt [72512,72523]
simple_stmt [74136,74147]
===
match
---
name: pipeline [16246,16254]
name: pipeline [16277,16285]
===
match
---
expr_stmt [74378,74406]
expr_stmt [76002,76030]
===
match
---
decorator [51537,51643]
decorator [51568,51674]
===
match
---
simple_stmt [46076,46093]
simple_stmt [46107,46124]
===
match
---
argument [50696,50722]
argument [50727,50753]
===
match
---
atom_expr [20767,20805]
atom_expr [20798,20836]
===
match
---
arglist [53982,54035]
arglist [54013,54066]
===
match
---
operator: = [15014,15015]
operator: = [15045,15046]
===
match
---
simple_stmt [52987,53010]
simple_stmt [53018,53041]
===
match
---
name: get_num_task_instances [18787,18809]
name: get_num_task_instances [18818,18840]
===
match
---
name: dag_id [44709,44715]
name: dag_id [44740,44746]
===
match
---
name: dag [29131,29134]
name: dag [29162,29165]
===
match
---
name: task_id [75778,75785]
name: task_id [77402,77409]
===
match
---
comparison [32983,33011]
comparison [33014,33042]
===
match
---
simple_stmt [61977,62054]
simple_stmt [62008,62085]
===
match
---
return_stmt [54208,54226]
return_stmt [54239,54257]
===
match
---
simple_stmt [7499,7528]
simple_stmt [7530,7559]
===
match
---
name: local_tz [24368,24376]
name: local_tz [24399,24407]
===
match
---
atom_expr [38769,38809]
atom_expr [38800,38840]
===
match
---
simple_stmt [19060,19160]
simple_stmt [19091,19191]
===
match
---
name: next_local [24913,24923]
name: next_local [24944,24954]
===
match
---
argument [60487,60500]
argument [60518,60531]
===
match
---
atom_expr [26484,26547]
atom_expr [26515,26578]
===
match
---
operator: { [13771,13772]
operator: { [13802,13803]
===
match
---
simple_stmt [77400,77440]
simple_stmt [79024,79064]
===
match
---
name: run_id [51120,51126]
name: run_id [51151,51157]
===
match
---
simple_stmt [33223,33276]
simple_stmt [33254,33307]
===
match
---
expr_stmt [22163,22208]
expr_stmt [22194,22239]
===
match
---
operator: = [26482,26483]
operator: = [26513,26514]
===
match
---
name: _task_group [42367,42378]
name: _task_group [42398,42409]
===
match
---
name: DAG [53078,53081]
name: DAG [53109,53112]
===
match
---
suite [75139,75316]
suite [76763,76940]
===
match
---
trailer [18412,18420]
trailer [18443,18451]
===
match
---
simple_stmt [67060,67224]
simple_stmt [68684,68848]
===
match
---
operator: , [62468,62469]
operator: , [62499,62500]
===
match
---
operator: >> [39930,39932]
operator: >> [39961,39963]
===
match
---
name: next_info [61680,61689]
name: next_info [61711,61720]
===
match
---
simple_stmt [37861,37886]
simple_stmt [37892,37917]
===
match
---
expr_stmt [33021,33104]
expr_stmt [33052,33135]
===
match
---
name: lower [37317,37322]
name: lower [37348,37353]
===
match
---
name: DAG [1527,1530]
name: DAG [1533,1536]
===
match
---
atom_expr [67781,67801]
atom_expr [69405,69425]
===
match
---
trailer [18725,18731]
trailer [18756,18762]
===
match
---
argument [67592,67625]
argument [69216,69249]
===
match
---
operator: } [19880,19881]
operator: } [19911,19912]
===
match
---
string: 'test' [70385,70391]
string: 'test' [72009,72015]
===
match
---
name: DEFAULT_DATE [11418,11430]
name: DEFAULT_DATE [11449,11461]
===
match
---
name: datetime_tz [2628,2639]
name: datetime_tz [2659,2670]
===
match
---
trailer [48059,48100]
trailer [48090,48131]
===
match
---
name: pipeline [15315,15323]
name: pipeline [15346,15354]
===
match
---
operator: , [55494,55495]
operator: , [55525,55526]
===
match
---
name: ti4 [18732,18735]
name: ti4 [18763,18766]
===
match
---
name: get [46397,46400]
name: get [46428,46431]
===
match
---
testlist_comp [31784,31795]
testlist_comp [31815,31826]
===
match
---
testlist_comp [51610,51624]
testlist_comp [51641,51655]
===
match
---
name: dag_id [3483,3489]
name: dag_id [3514,3520]
===
match
---
operator: , [65322,65323]
operator: , [66946,66947]
===
match
---
atom_expr [45896,45909]
atom_expr [45927,45940]
===
match
---
trailer [8625,8645]
trailer [8656,8676]
===
match
---
atom_expr [73632,73825]
atom_expr [75256,75449]
===
match
---
parameters [73463,73468]
parameters [75087,75092]
===
match
---
operator: , [9083,9084]
operator: , [9114,9115]
===
match
---
suite [71787,72165]
suite [73411,73789]
===
match
---
arglist [5805,5836]
arglist [5836,5867]
===
match
---
atom_expr [53205,53270]
atom_expr [53236,53301]
===
match
---
trailer [30342,30349]
trailer [30373,30380]
===
match
---
name: model [31966,31971]
name: model [31997,32002]
===
match
---
trailer [50123,50138]
trailer [50154,50169]
===
match
---
trailer [28772,28777]
trailer [28803,28808]
===
match
---
name: rollback [69481,69489]
name: rollback [71105,71113]
===
match
---
trailer [36584,36592]
trailer [36615,36623]
===
match
---
operator: = [75250,75251]
operator: = [76874,76875]
===
match
---
name: dag_id [25578,25584]
name: dag_id [25609,25615]
===
match
---
arglist [15007,15136]
arglist [15038,15167]
===
match
---
atom_expr [43245,43269]
atom_expr [43276,43300]
===
match
---
trailer [41686,41694]
trailer [41717,41725]
===
match
---
trailer [40407,40414]
trailer [40438,40445]
===
match
---
atom_expr [32055,32125]
atom_expr [32086,32156]
===
match
---
operator: { [64973,64974]
operator: { [66597,66598]
===
match
---
string: 'Also fake' [45988,45999]
string: 'Also fake' [46019,46030]
===
match
---
name: self [71781,71785]
name: self [73405,73409]
===
match
---
trailer [42105,42120]
trailer [42136,42151]
===
match
---
expr_stmt [56345,56541]
expr_stmt [56376,56572]
===
match
---
atom_expr [73343,73360]
atom_expr [74967,74984]
===
match
---
operator: = [68749,68750]
operator: = [70373,70374]
===
match
---
trailer [65453,65460]
trailer [67077,67084]
===
match
---
assert_stmt [37194,37229]
assert_stmt [37225,37260]
===
match
---
name: DAG [38471,38474]
name: DAG [38502,38505]
===
match
---
atom_expr [29156,29184]
atom_expr [29187,29215]
===
match
---
trailer [65285,65425]
trailer [66909,67049]
===
match
---
testlist_comp [30559,30589]
testlist_comp [30590,30620]
===
match
---
trailer [74616,74623]
trailer [76240,76247]
===
match
---
expr_stmt [14753,14762]
expr_stmt [14784,14793]
===
match
---
atom_expr [66041,66068]
atom_expr [67665,67692]
===
match
---
trailer [9833,9851]
trailer [9864,9882]
===
match
---
expr_stmt [6888,6922]
expr_stmt [6919,6953]
===
match
---
trailer [24061,24069]
trailer [24092,24100]
===
match
---
name: DagModel [33065,33073]
name: DagModel [33096,33104]
===
match
---
argument [57434,57459]
argument [57465,57490]
===
match
---
arglist [62042,62052]
arglist [62073,62083]
===
match
---
name: dag_models [69374,69384]
name: dag_models [70998,71008]
===
match
---
name: compile [13359,13366]
name: compile [13390,13397]
===
match
---
assert_stmt [12508,12577]
assert_stmt [12539,12608]
===
match
---
arglist [52230,52283]
arglist [52261,52314]
===
match
---
name: test_dag_default_view_default_value [5589,5624]
name: test_dag_default_view_default_value [5620,5655]
===
match
---
simple_stmt [863,879]
simple_stmt [863,879]
===
match
---
operator: , [47035,47036]
operator: , [47066,47067]
===
match
---
dotted_name [55819,55839]
dotted_name [55850,55870]
===
match
---
name: next_dagrun_info [64242,64258]
name: next_dagrun_info [65866,65882]
===
match
---
simple_stmt [32806,32831]
simple_stmt [32837,32862]
===
match
---
name: noop_pipeline [71519,71532]
name: noop_pipeline [73143,73156]
===
match
---
operator: , [78652,78653]
operator: , [80276,80277]
===
match
---
suite [5631,5866]
suite [5662,5897]
===
match
---
trailer [53543,53733]
trailer [53574,53764]
===
match
---
name: task_5 [76577,76583]
name: task_5 [78201,78207]
===
match
---
operator: = [23432,23433]
operator: = [23463,23464]
===
match
---
name: settings [1328,1336]
name: settings [1334,1342]
===
match
---
name: datetime [24456,24464]
name: datetime [24487,24495]
===
match
---
trailer [27925,27928]
trailer [27956,27959]
===
match
---
operator: == [63216,63218]
operator: == [63247,63249]
===
match
---
trailer [37908,37916]
trailer [37939,37947]
===
match
---
name: models [4109,4115]
name: models [4140,4146]
===
match
---
simple_stmt [69500,69516]
simple_stmt [71124,71140]
===
match
---
name: SCHEDULED [46140,46149]
name: SCHEDULED [46171,46180]
===
match
---
name: inspect [76975,76982]
name: inspect [78599,78606]
===
match
---
atom [11482,11484]
atom [11513,11515]
===
match
---
simple_stmt [22777,22811]
simple_stmt [22808,22842]
===
match
---
operator: == [43065,43067]
operator: == [43096,43098]
===
match
---
name: task [15627,15631]
name: task [15658,15662]
===
match
---
name: dag [50678,50681]
name: dag [50709,50712]
===
match
---
atom_expr [7801,7829]
atom_expr [7832,7860]
===
match
---
trailer [38188,38194]
trailer [38219,38225]
===
match
---
name: DagModel [38195,38203]
name: DagModel [38226,38234]
===
match
---
trailer [10702,10707]
trailer [10733,10738]
===
match
---
name: dag_id [63994,64000]
name: dag_id [65618,65624]
===
match
---
trailer [45005,45015]
trailer [45036,45046]
===
match
---
name: owner [45982,45987]
name: owner [46013,46018]
===
match
---
testlist_comp [29627,29656]
testlist_comp [29658,29687]
===
match
---
name: prev [22934,22938]
name: prev [22965,22969]
===
match
---
simple_stmt [10151,10185]
simple_stmt [10182,10216]
===
match
---
atom_expr [18126,18256]
atom_expr [18157,18287]
===
match
---
name: now [59783,59786]
name: now [59814,59817]
===
match
---
trailer [18644,18650]
trailer [18675,18681]
===
match
---
argument [25571,25584]
argument [25602,25615]
===
match
---
name: datetime [38417,38425]
name: datetime [38448,38456]
===
match
---
suite [64632,65030]
suite [66256,66654]
===
match
---
simple_stmt [8658,8718]
simple_stmt [8689,8749]
===
match
---
trailer [67654,67665]
trailer [69278,69289]
===
match
---
name: topological_list [11166,11182]
name: topological_list [11197,11213]
===
match
---
operator: = [61629,61630]
operator: = [61660,61661]
===
match
---
trailer [66686,66701]
trailer [68310,68325]
===
match
---
argument [26120,26148]
argument [26151,26179]
===
match
---
dotted_name [2429,2453]
dotted_name [2460,2484]
===
match
---
trailer [52229,52284]
trailer [52260,52315]
===
match
---
trailer [29461,29468]
trailer [29492,29499]
===
match
---
trailer [55751,55755]
trailer [55782,55786]
===
match
---
name: dagrun [77400,77406]
name: dagrun [79024,79030]
===
match
---
argument [18368,18385]
argument [18399,18416]
===
match
---
name: isoformat [50823,50832]
name: isoformat [50854,50863]
===
match
---
trailer [32671,32677]
trailer [32702,32708]
===
match
---
name: filters [20021,20028]
name: filters [20052,20059]
===
match
---
simple_stmt [36566,36595]
simple_stmt [36597,36626]
===
match
---
name: DAG [31710,31713]
name: DAG [31741,31744]
===
match
---
trailer [24396,24413]
trailer [24427,24444]
===
match
---
name: DEFAULT_DATE [39747,39759]
name: DEFAULT_DATE [39778,39790]
===
match
---
atom_expr [67810,67825]
atom_expr [69434,69449]
===
match
---
expr_stmt [24422,24515]
expr_stmt [24453,24546]
===
match
---
simple_stmt [18318,18335]
simple_stmt [18349,18366]
===
match
---
assert_stmt [15903,15945]
assert_stmt [15934,15976]
===
match
---
string: 'dag-bulk-sync-3' [30559,30576]
string: 'dag-bulk-sync-3' [30590,30607]
===
match
---
suite [72495,72523]
suite [74119,74147]
===
match
---
simple_stmt [65994,66221]
simple_stmt [67618,67845]
===
match
---
simple_stmt [9197,9264]
simple_stmt [9228,9295]
===
match
---
trailer [33147,33153]
trailer [33178,33184]
===
match
---
atom_expr [58719,58755]
atom_expr [58750,58786]
===
match
---
name: run_id [18029,18035]
name: run_id [18060,18066]
===
match
---
simple_stmt [38620,38662]
simple_stmt [38651,38693]
===
match
---
testlist_comp [77565,77623]
testlist_comp [79189,79247]
===
match
---
operator: == [25275,25277]
operator: == [25306,25308]
===
match
---
operator: , [59182,59183]
operator: , [59213,59214]
===
match
---
trailer [10121,10142]
trailer [10152,10173]
===
match
---
simple_stmt [39781,39815]
simple_stmt [39812,39846]
===
match
---
operator: = [76718,76719]
operator: = [78342,78343]
===
match
---
operator: = [66982,66983]
operator: = [68606,68607]
===
match
---
atom_expr [7316,7344]
atom_expr [7347,7375]
===
match
---
expr_stmt [75241,75269]
expr_stmt [76865,76893]
===
match
---
decorator [55037,55143]
decorator [55068,55174]
===
match
---
param [69774,69782]
param [71398,71406]
===
match
---
simple_stmt [46920,47151]
simple_stmt [46951,47182]
===
match
---
name: stdout [40045,40051]
name: stdout [40076,40082]
===
match
---
name: datetime [44673,44681]
name: datetime [44704,44712]
===
match
---
assert_stmt [73959,73994]
assert_stmt [75583,75618]
===
match
---
name: session [46344,46351]
name: session [46375,46382]
===
match
---
name: calculated_weight [14531,14548]
name: calculated_weight [14562,14579]
===
match
---
name: DEFAULT_DATE [28138,28150]
name: DEFAULT_DATE [28169,28181]
===
match
---
atom_expr [53148,53187]
atom_expr [53179,53218]
===
match
---
argument [44311,44323]
argument [44342,44354]
===
match
---
operator: == [27620,27622]
operator: == [27651,27653]
===
match
---
name: calculated_weight [15910,15927]
name: calculated_weight [15941,15958]
===
match
---
operator: , [48280,48281]
operator: , [48311,48312]
===
match
---
name: dag [67536,67539]
name: dag [69160,69163]
===
match
---
atom_expr [73396,73406]
atom_expr [75020,75030]
===
match
---
operator: == [42930,42932]
operator: == [42961,42963]
===
match
---
operator: , [59466,59467]
operator: , [59497,59498]
===
match
---
atom_expr [46324,46340]
atom_expr [46355,46371]
===
match
---
trailer [14120,14133]
trailer [14151,14164]
===
match
---
operator: , [55198,55199]
operator: , [55229,55230]
===
match
---
simple_stmt [63106,63164]
simple_stmt [63137,63195]
===
match
---
name: t [27933,27934]
name: t [27964,27965]
===
match
---
simple_stmt [1979,2046]
simple_stmt [2010,2077]
===
match
---
expr_stmt [68911,69155]
expr_stmt [70535,70779]
===
match
---
name: start_date [26576,26586]
name: start_date [26607,26617]
===
match
---
simple_stmt [75282,75316]
simple_stmt [76906,76940]
===
match
---
name: op2 [42056,42059]
name: op2 [42087,42090]
===
match
---
atom_expr [51052,51063]
atom_expr [51083,51094]
===
match
---
operator: = [73669,73670]
operator: = [75293,75294]
===
match
---
simple_stmt [7462,7491]
simple_stmt [7493,7522]
===
match
---
trailer [57094,57098]
trailer [57125,57129]
===
match
---
name: self [27377,27381]
name: self [27408,27412]
===
match
---
operator: = [11444,11445]
operator: = [11475,11476]
===
match
---
operator: = [31171,31172]
operator: = [31202,31203]
===
match
---
operator: == [14549,14551]
operator: == [14580,14582]
===
match
---
operator: = [19394,19395]
operator: = [19425,19426]
===
match
---
atom_expr [7959,7966]
atom_expr [7990,7997]
===
match
---
operator: = [53565,53566]
operator: = [53596,53597]
===
match
---
trailer [76215,76222]
trailer [77839,77846]
===
match
---
operator: , [65754,65755]
operator: , [67378,67379]
===
match
---
trailer [66919,66934]
trailer [68543,68558]
===
match
---
name: timezone [12945,12953]
name: timezone [12976,12984]
===
match
---
name: test_task_id [19373,19385]
name: test_task_id [19404,19416]
===
match
---
name: self [69978,69982]
name: self [71602,71606]
===
match
---
trailer [14783,14791]
trailer [14814,14822]
===
match
---
name: topological_list [10158,10174]
name: topological_list [10189,10205]
===
match
---
expr_stmt [23324,23418]
expr_stmt [23355,23449]
===
match
---
argument [75650,75671]
argument [77274,77295]
===
match
---
operator: , [47103,47104]
operator: , [47134,47135]
===
match
---
argument [67184,67208]
argument [68808,68832]
===
match
---
funcdef [57293,57703]
funcdef [57324,57734]
===
match
---
simple_stmt [54208,54227]
simple_stmt [54239,54258]
===
match
---
simple_stmt [51277,51289]
simple_stmt [51308,51320]
===
match
---
name: query [33933,33938]
name: query [33964,33969]
===
match
---
name: priority_weight_total [17065,17086]
name: priority_weight_total [17096,17117]
===
match
---
simple_stmt [60228,60264]
simple_stmt [60259,60295]
===
match
---
simple_stmt [46781,46871]
simple_stmt [46812,46902]
===
match
---
operator: = [54061,54062]
operator: = [54092,54093]
===
match
---
simple_stmt [11685,11765]
simple_stmt [11716,11796]
===
match
---
funcdef [39146,39623]
funcdef [39177,39654]
===
match
---
operator: = [16204,16205]
operator: = [16235,16236]
===
match
---
testlist_comp [50248,50319]
testlist_comp [50279,50350]
===
match
---
expr_stmt [9315,9390]
expr_stmt [9346,9421]
===
match
---
atom_expr [18481,18490]
atom_expr [18512,18521]
===
match
---
name: op2 [39827,39830]
name: op2 [39858,39861]
===
match
---
trailer [67318,67385]
trailer [68942,69009]
===
match
---
operator: = [33582,33583]
operator: = [33613,33614]
===
match
---
name: resolve_template_files [21277,21299]
name: resolve_template_files [21308,21330]
===
match
---
name: i [3792,3793]
name: i [3823,3824]
===
match
---
name: mock [37667,37671]
name: mock [37698,37702]
===
match
---
name: test_dag_task_invalid_weight_rule [17155,17188]
name: test_dag_task_invalid_weight_rule [17186,17219]
===
match
---
dotted_name [1746,1768]
dotted_name [1752,1774]
===
match
---
operator: { [19915,19916]
operator: { [19946,19947]
===
match
---
operator: == [3819,3821]
operator: == [3850,3852]
===
match
---
atom_expr [74691,74704]
atom_expr [76315,76328]
===
match
---
arglist [76680,76767]
arglist [78304,78391]
===
match
---
simple_stmt [949,974]
simple_stmt [949,974]
===
match
---
trailer [21960,21962]
trailer [21991,21993]
===
match
---
name: RUNNING [43201,43208]
name: RUNNING [43232,43239]
===
match
---
import_as_name [1671,1691]
import_as_name [1677,1697]
===
match
---
operator: = [4635,4636]
operator: = [4666,4667]
===
match
---
name: now [59595,59598]
name: now [59626,59629]
===
match
---
operator: , [8157,8158]
operator: , [8188,8189]
===
match
---
atom [69461,69463]
atom [71085,71087]
===
match
---
expr_stmt [24368,24413]
expr_stmt [24399,24444]
===
match
---
operator: = [45221,45222]
operator: = [45252,45253]
===
match
---
arglist [36505,36556]
arglist [36536,36587]
===
match
---
name: DAG [41412,41415]
name: DAG [41443,41446]
===
match
---
atom [55938,55973]
atom [55969,56004]
===
match
---
name: op3 [7148,7151]
name: op3 [7179,7182]
===
match
---
trailer [26261,26268]
trailer [26292,26299]
===
match
---
name: dag [48798,48801]
name: dag [48829,48832]
===
match
---
assert_stmt [42184,42256]
assert_stmt [42215,42287]
===
match
---
atom_expr [21933,21962]
atom_expr [21964,21993]
===
match
---
arith_expr [16800,16805]
arith_expr [16831,16836]
===
match
---
operator: = [42670,42671]
operator: = [42701,42702]
===
match
---
operator: , [42857,42858]
operator: , [42888,42889]
===
match
---
atom_expr [51303,51349]
atom_expr [51334,51380]
===
match
---
atom_expr [51443,51453]
atom_expr [51474,51484]
===
match
---
argument [59399,59411]
argument [59430,59442]
===
match
---
import_from [1430,1499]
import_from [1436,1505]
===
match
---
operator: == [37272,37274]
operator: == [37303,37305]
===
match
---
simple_stmt [45542,45565]
simple_stmt [45573,45596]
===
match
---
name: settings [68207,68215]
name: settings [69831,69839]
===
match
---
operator: = [63734,63735]
operator: = [65358,65359]
===
match
---
name: close [68592,68597]
name: close [70216,70221]
===
match
---
simple_stmt [46678,46713]
simple_stmt [46709,46744]
===
match
---
suite [14029,14145]
suite [14060,14176]
===
match
---
name: model [31571,31576]
name: model [31602,31607]
===
match
---
trailer [78956,78965]
trailer [80580,80589]
===
match
---
name: DummyOperator [21732,21745]
name: DummyOperator [21763,21776]
===
match
---
name: add_task [58192,58200]
name: add_task [58223,58231]
===
match
---
name: timezone [23290,23298]
name: timezone [23321,23329]
===
match
---
operator: , [52610,52611]
operator: , [52641,52642]
===
match
---
funcdef [50342,50562]
funcdef [50373,50593]
===
match
---
number: 2020 [63237,63241]
number: 2020 [63268,63272]
===
match
---
name: task_2 [77082,77088]
name: task_2 [78706,78712]
===
match
---
name: dag [63801,63804]
name: dag [65425,65428]
===
match
---
atom_expr [71024,71042]
atom_expr [72648,72666]
===
match
---
name: safe_dag_id [32991,33002]
name: safe_dag_id [33022,33033]
===
match
---
arglist [12913,12923]
arglist [12944,12954]
===
match
---
expr_stmt [74848,74879]
expr_stmt [76472,76503]
===
match
---
number: 2020 [62090,62094]
number: 2020 [62121,62125]
===
match
---
atom_expr [22941,22969]
atom_expr [22972,23000]
===
match
---
trailer [46524,46534]
trailer [46555,46565]
===
match
---
name: DummyOperator [6941,6954]
name: DummyOperator [6972,6985]
===
match
---
trailer [69820,69835]
trailer [71444,71459]
===
match
---
name: test_dag_naive_start_date_string [11520,11552]
name: test_dag_naive_start_date_string [11551,11583]
===
match
---
operator: , [46149,46150]
operator: , [46180,46181]
===
match
---
argument [27745,27768]
argument [27776,27799]
===
match
---
name: dag [43934,43937]
name: dag [43965,43968]
===
match
---
argument [60065,60078]
argument [60096,60109]
===
match
---
number: 0 [27129,27130]
number: 0 [27160,27161]
===
match
---
name: op2 [39926,39929]
name: op2 [39957,39960]
===
match
---
operator: , [29594,29595]
operator: , [29625,29626]
===
match
---
decorated [75152,75228]
decorated [76776,76852]
===
match
---
name: num [71620,71623]
name: num [73244,73247]
===
match
---
operator: , [54288,54289]
operator: , [54319,54320]
===
match
---
name: run_type [44123,44131]
name: run_type [44154,44162]
===
match
---
name: NullTimetable [2017,2030]
name: NullTimetable [2048,2061]
===
match
---
atom_expr [20200,20291]
atom_expr [20231,20322]
===
match
---
operator: = [37104,37105]
operator: = [37135,37136]
===
match
---
number: 3 [78011,78012]
number: 3 [79635,79636]
===
match
---
simple_stmt [45215,45266]
simple_stmt [45246,45297]
===
match
---
name: _next [22650,22655]
name: _next [22681,22686]
===
match
---
expr_stmt [21835,21873]
expr_stmt [21866,21904]
===
match
---
simple_stmt [57160,57206]
simple_stmt [57191,57237]
===
match
---
name: FAILED [76551,76557]
name: FAILED [78175,78181]
===
match
---
funcdef [19632,20133]
funcdef [19663,20164]
===
match
---
trailer [67792,67801]
trailer [69416,69425]
===
match
---
operator: == [20071,20073]
operator: == [20102,20104]
===
match
---
name: DagModel [33956,33964]
name: DagModel [33987,33995]
===
match
---
string: 'dag-test-dagtag' [27984,28001]
string: 'dag-test-dagtag' [28015,28032]
===
match
---
name: state [52913,52918]
name: state [52944,52949]
===
match
---
argument [78939,78977]
argument [80563,80601]
===
match
---
atom_expr [38195,38210]
atom_expr [38226,38241]
===
match
---
operator: = [24051,24052]
operator: = [24082,24083]
===
match
---
name: start_date [58124,58134]
name: start_date [58155,58165]
===
match
---
operator: = [65067,65068]
operator: = [66691,66692]
===
match
---
operator: , [50472,50473]
operator: , [50503,50504]
===
match
---
name: orm_dag [37868,37875]
name: orm_dag [37899,37906]
===
match
---
parameters [3936,3942]
parameters [3967,3973]
===
match
---
argument [18045,18101]
argument [18076,18132]
===
match
---
argument [52523,52544]
argument [52554,52575]
===
match
---
comparison [45429,45462]
comparison [45460,45493]
===
match
---
comparison [6996,7010]
comparison [7027,7041]
===
match
---
trailer [47305,47316]
trailer [47336,47347]
===
match
---
name: query [29936,29941]
name: query [29967,29972]
===
match
---
trailer [35886,35890]
trailer [35917,35921]
===
match
---
operator: , [41169,41170]
operator: , [41200,41201]
===
match
---
name: dag_id [46535,46541]
name: dag_id [46566,46572]
===
match
---
name: dag_id [30634,30640]
name: dag_id [30665,30671]
===
match
---
trailer [57590,57602]
trailer [57621,57633]
===
match
---
string: 'op1' [21754,21759]
string: 'op1' [21785,21790]
===
match
---
simple_stmt [31002,31085]
simple_stmt [31033,31116]
===
match
---
operator: = [27506,27507]
operator: = [27537,27538]
===
match
---
name: logging [821,828]
name: logging [821,828]
===
match
---
name: self [73864,73868]
name: self [75488,75492]
===
match
---
simple_stmt [69811,69836]
simple_stmt [71435,71460]
===
match
---
parameters [55193,55214]
parameters [55224,55245]
===
match
---
name: _ [58355,58356]
name: _ [58386,58387]
===
match
---
name: RUNNING [18584,18591]
name: RUNNING [18615,18622]
===
match
---
decorator [73421,73437]
decorator [75045,75061]
===
match
---
trailer [7962,7966]
trailer [7993,7997]
===
match
---
name: get_ti_from_db [77350,77364]
name: get_ti_from_db [78974,78988]
===
match
---
trailer [37316,37322]
trailer [37347,37353]
===
match
---
atom_expr [39317,39344]
atom_expr [39348,39375]
===
match
---
name: pendulum [22291,22299]
name: pendulum [22322,22330]
===
match
---
string: "2018-10-28T01:00:00+00:00" [22671,22698]
string: "2018-10-28T01:00:00+00:00" [22702,22729]
===
match
---
name: task [21318,21322]
name: task [21349,21353]
===
match
---
operator: == [54913,54915]
operator: == [54944,54946]
===
match
---
argument [7168,7181]
argument [7199,7212]
===
match
---
operator: = [48025,48026]
operator: = [48056,48057]
===
match
---
name: operator [73556,73564]
name: operator [75180,75188]
===
match
---
trailer [54111,54119]
trailer [54142,54150]
===
match
---
simple_stmt [47577,47603]
simple_stmt [47608,47634]
===
match
---
atom [33158,33178]
atom [33189,33209]
===
match
---
name: task [21081,21085]
name: task [21112,21116]
===
match
---
expr_stmt [33915,33987]
expr_stmt [33946,34018]
===
match
---
operator: , [64863,64864]
operator: , [66487,66488]
===
match
---
name: task_id [7377,7384]
name: task_id [7408,7415]
===
match
---
operator: = [56241,56242]
operator: = [56272,56273]
===
match
---
simple_stmt [64160,64217]
simple_stmt [65784,65841]
===
match
---
trailer [30726,30730]
trailer [30757,30761]
===
match
---
simple_stmt [37941,38016]
simple_stmt [37972,38047]
===
match
---
simple_stmt [7651,7693]
simple_stmt [7682,7724]
===
match
---
comparison [23938,23986]
comparison [23969,24017]
===
match
---
comparison [51052,51087]
comparison [51083,51118]
===
match
---
name: session [28448,28455]
name: session [28479,28486]
===
match
---
trailer [24712,24720]
trailer [24743,24751]
===
match
---
operator: @ [73421,73422]
operator: @ [75045,75046]
===
match
---
atom [30558,30590]
atom [30589,30621]
===
match
---
trailer [22346,22348]
trailer [22377,22379]
===
match
---
atom_expr [22991,23013]
atom_expr [23022,23044]
===
match
---
trailer [44865,44945]
trailer [44896,44976]
===
match
---
name: max_active_tasks [67560,67576]
name: max_active_tasks [69184,69200]
===
match
---
trailer [63138,63163]
trailer [63169,63194]
===
match
---
number: 2 [2649,2650]
number: 2 [2680,2681]
===
match
---
arglist [35061,35102]
arglist [35092,35133]
===
match
---
name: state [42838,42843]
name: state [42869,42874]
===
match
---
name: task_1 [75952,75958]
name: task_1 [77576,77582]
===
match
---
atom_expr [23780,23807]
atom_expr [23811,23838]
===
match
---
comparison [41219,41254]
comparison [41250,41285]
===
match
---
operator: = [10517,10518]
operator: = [10548,10549]
===
match
---
expr_stmt [44074,44167]
expr_stmt [44105,44198]
===
match
---
suite [15424,15540]
suite [15455,15571]
===
match
---
operator: } [28407,28408]
operator: } [28438,28439]
===
match
---
expr_stmt [23594,23629]
expr_stmt [23625,23660]
===
match
---
operator: = [55411,55412]
operator: = [55442,55443]
===
match
---
simple_stmt [70338,70402]
simple_stmt [71962,72026]
===
match
---
operator: , [70147,70148]
operator: , [71771,71772]
===
match
---
name: end_date [57984,57992]
name: end_date [58015,58023]
===
match
---
string: "t5" [39523,39527]
string: "t5" [39554,39558]
===
match
---
atom_expr [21538,21561]
atom_expr [21569,21592]
===
match
---
name: test_bulk_write_to_db [28032,28053]
name: test_bulk_write_to_db [28063,28084]
===
match
---
trailer [17764,17821]
trailer [17795,17852]
===
match
---
operator: = [33497,33498]
operator: = [33528,33529]
===
match
---
string: 'dummy' [64182,64189]
string: 'dummy' [65806,65813]
===
match
---
name: dag [56356,56359]
name: dag [56387,56390]
===
match
---
operator: = [7314,7315]
operator: = [7345,7346]
===
match
---
operator: = [23478,23479]
operator: = [23509,23510]
===
match
---
simple_stmt [10603,10636]
simple_stmt [10634,10667]
===
match
---
operator: } [66219,66220]
operator: } [67843,67844]
===
match
---
operator: = [10495,10496]
operator: = [10526,10527]
===
match
---
name: self [72199,72203]
name: self [73823,73827]
===
match
---
name: DEFAULT_DATE [47505,47517]
name: DEFAULT_DATE [47536,47548]
===
match
---
trailer [30620,30626]
trailer [30651,30657]
===
match
---
string: 'test_field' [21859,21871]
string: 'test_field' [21890,21902]
===
match
---
name: catchup [60487,60494]
name: catchup [60518,60525]
===
match
---
name: dt [27193,27195]
name: dt [27224,27226]
===
match
---
atom_expr [7613,7641]
atom_expr [7644,7672]
===
match
---
argument [45029,45056]
argument [45060,45087]
===
match
---
operator: = [51400,51401]
operator: = [51431,51432]
===
match
---
string: 'test-dag' [29547,29557]
string: 'test-dag' [29578,29588]
===
match
---
operator: = [19150,19151]
operator: = [19181,19182]
===
match
---
atom_expr [74216,74226]
atom_expr [75840,75850]
===
match
---
name: provide_session [34113,34128]
name: provide_session [34144,34159]
===
match
---
string: 'owner1' [16215,16223]
string: 'owner1' [16246,16254]
===
match
---
atom_expr [7063,7070]
atom_expr [7094,7101]
===
match
---
number: 2 [10139,10140]
number: 2 [10170,10171]
===
match
---
number: 0 [9917,9918]
number: 0 [9948,9949]
===
match
---
simple_stmt [32613,32645]
simple_stmt [32644,32676]
===
match
---
trailer [57644,57669]
trailer [57675,57700]
===
match
---
name: name [20965,20969]
name: name [20996,21000]
===
match
---
operator: = [20792,20793]
operator: = [20823,20824]
===
match
---
trailer [39115,39126]
trailer [39146,39157]
===
match
---
trailer [35129,35133]
trailer [35160,35164]
===
match
---
name: test_dag_start_date_propagates_to_end_date [11774,11816]
name: test_dag_start_date_propagates_to_end_date [11805,11847]
===
match
---
name: query [54834,54839]
name: query [54865,54870]
===
match
---
operator: , [51623,51624]
operator: , [51654,51655]
===
match
---
funcdef [72719,73198]
funcdef [74343,74822]
===
match
---
expr_stmt [57950,57975]
expr_stmt [57981,58006]
===
match
---
funcdef [34133,36063]
funcdef [34164,36094]
===
match
---
atom_expr [35656,35672]
atom_expr [35687,35703]
===
match
---
operator: = [24601,24602]
operator: = [24632,24633]
===
match
---
atom_expr [58188,58255]
atom_expr [58219,58286]
===
match
---
number: 10 [16104,16106]
number: 10 [16135,16137]
===
match
---
name: utcnow [60300,60306]
name: utcnow [60331,60337]
===
match
---
assert_stmt [72094,72121]
assert_stmt [73718,73745]
===
match
---
trailer [46534,46542]
trailer [46565,46573]
===
match
---
string: 'test-dag2' [29695,29706]
string: 'test-dag2' [29726,29737]
===
match
---
operator: { [27903,27904]
operator: { [27934,27935]
===
match
---
operator: = [42600,42601]
operator: = [42631,42632]
===
match
---
name: task [17060,17064]
name: task [17091,17095]
===
match
---
operator: , [68837,68838]
operator: , [70461,70462]
===
match
---
simple_stmt [28874,28900]
simple_stmt [28905,28931]
===
match
---
expr_stmt [37431,37491]
expr_stmt [37462,37522]
===
match
---
name: operator [75307,75315]
name: operator [76931,76939]
===
match
---
name: timezone [57573,57581]
name: timezone [57604,57612]
===
match
---
argument [75925,75941]
argument [77549,77565]
===
match
---
name: DummyOperator [70338,70351]
name: DummyOperator [71962,71975]
===
match
---
atom_expr [62446,62475]
atom_expr [62477,62506]
===
match
---
simple_stmt [17975,18112]
simple_stmt [18006,18143]
===
match
---
operator: , [61659,61660]
operator: , [61690,61691]
===
match
---
name: start_date [40527,40537]
name: start_date [40558,40568]
===
match
---
name: datetime [26127,26135]
name: datetime [26158,26166]
===
match
---
atom_expr [8118,8245]
atom_expr [8149,8276]
===
match
---
comparison [3366,3385]
comparison [3397,3416]
===
match
---
argument [14863,14895]
argument [14894,14926]
===
match
---
name: DagModel [35814,35822]
name: DagModel [35845,35853]
===
match
---
trailer [31787,31794]
trailer [31818,31825]
===
match
---
name: ti1 [18651,18654]
name: ti1 [18682,18685]
===
match
---
name: dag_id [51771,51777]
name: dag_id [51802,51808]
===
match
---
trailer [9222,9263]
trailer [9253,9294]
===
match
---
name: test_template_undefined [20507,20530]
name: test_template_undefined [20538,20561]
===
match
---
trailer [43312,43320]
trailer [43343,43351]
===
match
---
trailer [74781,74839]
trailer [76405,76463]
===
match
---
name: tasks [9923,9928]
name: tasks [9954,9959]
===
match
---
string: "faketastic" [25653,25665]
string: "faketastic" [25684,25696]
===
match
---
name: SubDagOperator [34541,34555]
name: SubDagOperator [34572,34586]
===
match
---
operator: , [9007,9008]
operator: , [9038,9039]
===
match
---
return_stmt [76123,76354]
return_stmt [77747,77978]
===
match
---
trailer [74570,74577]
trailer [76194,76201]
===
match
---
number: 4 [18869,18870]
number: 4 [18900,18901]
===
match
---
name: num [71995,71998]
name: num [73619,73622]
===
match
---
name: TI [3355,3357]
name: TI [3386,3388]
===
match
---
name: max_active_runs [51853,51868]
name: max_active_runs [51884,51899]
===
match
---
name: unittest [1073,1081]
name: unittest [1079,1087]
===
match
---
simple_stmt [22553,22589]
simple_stmt [22584,22620]
===
match
---
argument [56609,56636]
argument [56640,56667]
===
match
---
argument [32518,32535]
argument [32549,32566]
===
match
---
name: path [69615,69619]
name: path [71239,71243]
===
match
---
simple_stmt [29070,29097]
simple_stmt [29101,29128]
===
match
---
operator: = [73800,73801]
operator: = [75424,75425]
===
match
---
comparison [17110,17145]
comparison [17141,17176]
===
match
---
expr_stmt [36226,36279]
expr_stmt [36257,36310]
===
match
---
name: DEFAULT_DATE [6723,6735]
name: DEFAULT_DATE [6754,6766]
===
match
---
trailer [3248,3254]
trailer [3279,3285]
===
match
---
atom_expr [25886,25903]
atom_expr [25917,25934]
===
match
---
simple_stmt [10468,10501]
simple_stmt [10499,10532]
===
match
---
operator: = [60111,60112]
operator: = [60142,60143]
===
match
---
suite [71095,71345]
suite [72719,72969]
===
match
---
string: "t1" [40653,40657]
string: "t1" [40684,40688]
===
match
---
number: 2 [4652,4653]
number: 2 [4683,4684]
===
match
---
argument [78069,78076]
argument [79693,79700]
===
match
---
simple_stmt [75952,75995]
simple_stmt [77576,77619]
===
match
---
name: raises [40925,40931]
name: raises [40956,40962]
===
match
---
operator: , [26574,26575]
operator: , [26605,26606]
===
match
---
trailer [5419,5495]
trailer [5450,5526]
===
match
---
atom_expr [31571,31588]
atom_expr [31602,31619]
===
match
---
name: owner [43982,43987]
name: owner [44013,44018]
===
match
---
name: session [56902,56909]
name: session [56933,56940]
===
match
---
name: next_parent_info [65696,65712]
name: next_parent_info [67320,67336]
===
match
---
expr_stmt [57479,57517]
expr_stmt [57510,57548]
===
match
---
simple_stmt [25521,25553]
simple_stmt [25552,25584]
===
match
---
trailer [14225,14231]
trailer [14256,14262]
===
match
---
operator: = [56354,56355]
operator: = [56385,56386]
===
match
---
operator: = [34717,34718]
operator: = [34748,34749]
===
match
---
name: NullTimetable [49902,49915]
name: NullTimetable [49933,49946]
===
match
---
trailer [62746,62760]
trailer [62777,62791]
===
match
---
simple_stmt [72017,72028]
simple_stmt [73641,73652]
===
match
---
import_as_names [1320,1336]
import_as_names [1326,1342]
===
match
---
operator: , [75671,75672]
operator: , [77295,77296]
===
match
---
trailer [52450,52460]
trailer [52481,52491]
===
match
---
name: set_downstream [10792,10806]
name: set_downstream [10823,10837]
===
match
---
assert_stmt [66733,66781]
assert_stmt [68357,68405]
===
match
---
name: dag_eq [47921,47927]
name: dag_eq [47952,47958]
===
match
---
expr_stmt [14210,14245]
expr_stmt [14241,14276]
===
match
---
operator: , [12748,12749]
operator: , [12779,12780]
===
match
---
atom_expr [39363,39390]
atom_expr [39394,39421]
===
match
---
atom [39081,39091]
atom [39112,39122]
===
match
---
operator: , [62471,62472]
operator: , [62502,62503]
===
match
---
simple_stmt [28325,28499]
simple_stmt [28356,28530]
===
match
---
operator: = [33677,33678]
operator: = [33708,33709]
===
match
---
trailer [75374,75383]
trailer [76998,77007]
===
match
---
name: num [72024,72027]
name: num [73648,73651]
===
match
---
name: SUCCESS [76743,76750]
name: SUCCESS [78367,78374]
===
match
---
funcdef [64363,65925]
funcdef [65987,67549]
===
match
---
expr_stmt [34699,34722]
expr_stmt [34730,34753]
===
match
---
trailer [14791,14813]
trailer [14822,14844]
===
match
---
trailer [10770,10775]
trailer [10801,10806]
===
match
---
arglist [45828,45868]
arglist [45859,45899]
===
match
---
atom_expr [27110,27131]
atom_expr [27141,27162]
===
match
---
name: test_fileloc [71076,71088]
name: test_fileloc [72700,72712]
===
match
---
comparison [36685,36725]
comparison [36716,36756]
===
match
---
argument [42594,42607]
argument [42625,42638]
===
match
---
name: DAG [63585,63588]
name: DAG [65209,65212]
===
match
---
parameters [5624,5630]
parameters [5655,5661]
===
match
---
trailer [78068,78077]
trailer [79692,79701]
===
match
---
name: DEFAULT_DATE [40538,40550]
name: DEFAULT_DATE [40569,40581]
===
match
---
atom_expr [77067,77095]
atom_expr [78691,78719]
===
match
---
operator: , [21028,21029]
operator: , [21059,21060]
===
match
---
name: clear [44409,44414]
name: clear [44440,44445]
===
match
---
name: self [74040,74044]
name: self [75664,75668]
===
match
---
name: RUNNING [42850,42857]
name: RUNNING [42881,42888]
===
match
---
simple_stmt [18664,18683]
simple_stmt [18695,18714]
===
match
---
trailer [36049,36062]
trailer [36080,36093]
===
match
---
testlist_comp [50040,50079]
testlist_comp [50071,50110]
===
match
---
name: session [54415,54422]
name: session [54446,54453]
===
match
---
name: depth [13309,13314]
name: depth [13340,13345]
===
match
---
comparison [31362,31395]
comparison [31393,31426]
===
match
---
arglist [64338,64356]
arglist [65962,65980]
===
match
---
name: dr [51097,51099]
name: dr [51128,51130]
===
match
---
operator: , [70203,70204]
operator: , [71827,71828]
===
match
---
expr_stmt [7148,7182]
expr_stmt [7179,7213]
===
match
---
trailer [13815,13825]
trailer [13846,13856]
===
match
---
string: """         Tests that a start_date string with a timezone and an end_date string without a timezone         are accepted and that the timezone from the start carries over the end          This test is a little indirect, it works by setting start and end equal except for the         timezone and then testing for equality after the DAG construction.  They'll be equal         only if the same timezone was applied to both.          An explicit check the `tzinfo` attributes for both are the same is an extra check.         """ [11832,12359]
string: """         Tests that a start_date string with a timezone and an end_date string without a timezone         are accepted and that the timezone from the start carries over the end          This test is a little indirect, it works by setting start and end equal except for the         timezone and then testing for equality after the DAG construction.  They'll be equal         only if the same timezone was applied to both.          An explicit check the `tzinfo` attributes for both are the same is an extra check.         """ [11863,12390]
===
match
---
name: dag_id [35512,35518]
name: dag_id [35543,35549]
===
match
---
comparison [28332,28498]
comparison [28363,28529]
===
match
---
simple_stmt [2131,2197]
simple_stmt [2162,2228]
===
match
---
atom_expr [66848,66936]
atom_expr [68472,68560]
===
match
---
simple_stmt [6935,6980]
simple_stmt [6966,7011]
===
match
---
operator: = [45967,45968]
operator: = [45998,45999]
===
match
---
operator: , [53871,53872]
operator: , [53902,53903]
===
match
---
trailer [19981,19983]
trailer [20012,20014]
===
match
---
param [73390,73406]
param [75014,75030]
===
match
---
name: freeze_time [1216,1227]
name: freeze_time [1222,1233]
===
match
---
name: is_paused [36847,36856]
name: is_paused [36878,36887]
===
match
---
string: 'dag-bulk-sync-0' [30409,30426]
string: 'dag-bulk-sync-0' [30440,30457]
===
match
---
trailer [18677,18682]
trailer [18708,18713]
===
match
---
assert_stmt [11244,11278]
assert_stmt [11275,11309]
===
match
---
import_from [1042,1067]
import_from [1048,1073]
===
match
---
atom [35623,35641]
atom [35654,35672]
===
match
---
argument [63717,63746]
argument [65341,65370]
===
match
---
suite [41319,41770]
suite [41350,41801]
===
match
---
fstring_end: ' [64783,64784]
fstring_end: ' [66407,66408]
===
match
---
simple_stmt [43427,43509]
simple_stmt [43458,43540]
===
match
---
name: DAG [12374,12377]
name: DAG [12405,12408]
===
match
---
operator: @ [34112,34113]
operator: @ [34143,34144]
===
match
---
name: task_id [41931,41938]
name: task_id [41962,41969]
===
match
---
operator: = [67576,67577]
operator: = [69200,69201]
===
match
---
string: "faketastic" [44887,44899]
string: "faketastic" [44918,44930]
===
match
---
trailer [5194,5212]
trailer [5225,5243]
===
match
---
trailer [21475,21488]
trailer [21506,21519]
===
match
---
name: DagModel [37802,37810]
name: DagModel [37833,37841]
===
match
---
atom_expr [24491,24514]
atom_expr [24522,24545]
===
match
---
name: dag_id [31336,31342]
name: dag_id [31367,31373]
===
match
---
name: noop_pipeline [71211,71224]
name: noop_pipeline [72835,72848]
===
match
---
operator: = [13666,13667]
operator: = [13697,13698]
===
match
---
name: get_is_paused [36418,36431]
name: get_is_paused [36449,36462]
===
match
---
comparison [43005,43025]
comparison [43036,43056]
===
match
---
string: 'owner' [16206,16213]
string: 'owner' [16237,16244]
===
match
---
name: dag_run [43011,43018]
name: dag_run [43042,43049]
===
match
---
operator: , [63691,63692]
operator: , [65315,65316]
===
match
---
argument [59969,60001]
argument [60000,60032]
===
match
---
trailer [66858,66936]
trailer [68482,68560]
===
match
---
atom_expr [30334,30349]
atom_expr [30365,30380]
===
match
---
name: following_schedule [25730,25748]
name: following_schedule [25761,25779]
===
match
---
name: next_info [62943,62952]
name: next_info [62974,62983]
===
match
---
argument [49480,49508]
argument [49511,49539]
===
match
---
operator: = [20198,20199]
operator: = [20229,20230]
===
match
---
trailer [77879,77889]
trailer [79503,79513]
===
match
---
atom_expr [33065,33080]
atom_expr [33096,33111]
===
match
---
name: BaseOperator [45947,45959]
name: BaseOperator [45978,45990]
===
match
---
operator: , [49995,49996]
operator: , [50026,50027]
===
match
---
name: execution_date [42800,42814]
name: execution_date [42831,42845]
===
match
---
name: DEFAULT_DATE [19814,19826]
name: DEFAULT_DATE [19845,19857]
===
match
---
atom_expr [8019,8026]
atom_expr [8050,8057]
===
match
---
simple_stmt [19749,19941]
simple_stmt [19780,19972]
===
match
---
operator: , [10251,10252]
operator: , [10282,10283]
===
match
---
atom_expr [16297,16487]
atom_expr [16328,16518]
===
match
---
atom_expr [31460,31477]
atom_expr [31491,31508]
===
match
---
name: task_id [41102,41109]
name: task_id [41133,41140]
===
match
---
operator: = [56152,56153]
operator: = [56183,56184]
===
match
---
expr_stmt [31747,31797]
expr_stmt [31778,31828]
===
match
---
atom_expr [66385,66412]
atom_expr [68009,68036]
===
match
---
trailer [74525,74539]
trailer [76149,76163]
===
match
---
testlist_comp [77930,78589]
testlist_comp [79554,80213]
===
match
---
expr_stmt [19949,19983]
expr_stmt [19980,20014]
===
match
---
name: execution_date [46151,46165]
name: execution_date [46182,46196]
===
match
---
argument [39331,39343]
argument [39362,39374]
===
match
---
testlist_comp [45252,45263]
testlist_comp [45283,45294]
===
match
---
name: create_dagrun [17751,17764]
name: create_dagrun [17782,17795]
===
match
---
atom [6750,6769]
atom [6781,6800]
===
match
---
operator: = [33710,33711]
operator: = [33741,33742]
===
match
---
name: self [73835,73839]
name: self [75459,75463]
===
match
---
simple_stmt [59764,59820]
simple_stmt [59795,59851]
===
match
---
atom_expr [12374,12499]
atom_expr [12405,12530]
===
match
---
name: task_id [51787,51794]
name: task_id [51818,51825]
===
match
---
name: session [34165,34172]
name: session [34196,34203]
===
match
---
name: timezone [70760,70768]
name: timezone [72384,72392]
===
match
---
name: name [29964,29968]
name: name [29995,29999]
===
match
---
number: 55 [22277,22279]
number: 55 [22308,22310]
===
match
---
operator: = [25672,25673]
operator: = [25703,25704]
===
match
---
name: session [56894,56901]
name: session [56925,56932]
===
match
---
atom_expr [51583,51593]
atom_expr [51614,51624]
===
match
---
name: RESTARTING [55961,55971]
name: RESTARTING [55992,56002]
===
match
---
name: task [15860,15864]
name: task [15891,15895]
===
match
---
operator: = [32662,32663]
operator: = [32693,32694]
===
match
---
name: dag [7708,7711]
name: dag [7739,7742]
===
match
---
trailer [54441,54443]
trailer [54472,54474]
===
match
---
trailer [64940,64998]
trailer [66564,66622]
===
match
---
name: test_count_number_queries [70173,70198]
name: test_count_number_queries [71797,71822]
===
match
---
trailer [16844,16857]
trailer [16875,16888]
===
match
---
name: split [33142,33147]
name: split [33173,33178]
===
match
---
operator: = [2921,2922]
operator: = [2952,2953]
===
match
---
name: dag_subclass_diff_name [49011,49033]
name: dag_subclass_diff_name [49042,49064]
===
match
---
name: previous_schedule [22788,22805]
name: previous_schedule [22819,22836]
===
match
---
trailer [44414,44416]
trailer [44445,44447]
===
match
---
assert_stmt [58712,58763]
assert_stmt [58743,58794]
===
match
---
name: default_view [5556,5568]
name: default_view [5587,5599]
===
match
---
suite [15478,15540]
suite [15509,15571]
===
match
---
name: add_task [46785,46793]
name: add_task [46816,46824]
===
match
---
atom_expr [69844,69855]
atom_expr [71468,71479]
===
match
---
with_item [75608,75696]
with_item [77232,77320]
===
match
---
trailer [50230,50232]
trailer [50261,50263]
===
match
---
simple_stmt [9740,9762]
simple_stmt [9771,9793]
===
match
---
name: model [46432,46437]
name: model [46463,46468]
===
match
---
name: topological_list [9020,9036]
name: topological_list [9051,9067]
===
match
---
trailer [37183,37185]
trailer [37214,37216]
===
match
---
trailer [20555,20604]
trailer [20586,20635]
===
match
---
name: j [16512,16513]
name: j [16543,16544]
===
match
---
return_stmt [75217,75227]
return_stmt [76841,76851]
===
match
---
name: dag [67651,67654]
name: dag [69275,69278]
===
match
---
trailer [42233,42236]
trailer [42264,42267]
===
match
---
parameters [20530,20536]
parameters [20561,20567]
===
match
---
atom [35162,35234]
atom [35193,35265]
===
match
---
expr_stmt [69374,69431]
expr_stmt [70998,71055]
===
match
---
name: correct_weight [17131,17145]
name: correct_weight [17162,17176]
===
match
---
operator: , [56023,56024]
operator: , [56054,56055]
===
match
---
number: 2038 [67722,67726]
number: 2038 [69346,69350]
===
match
---
operator: = [66902,66903]
operator: = [68526,68527]
===
match
---
trailer [69200,69206]
trailer [70824,70830]
===
match
---
simple_stmt [40131,40162]
simple_stmt [40162,40193]
===
match
---
trailer [62736,62761]
trailer [62767,62792]
===
match
---
simple_stmt [20445,20498]
simple_stmt [20476,20529]
===
match
---
string: 'dag' [17263,17268]
string: 'dag' [17294,17299]
===
match
---
name: args [47563,47567]
name: args [47594,47598]
===
match
---
operator: , [68283,68284]
operator: , [69907,69908]
===
match
---
name: start_date [32091,32101]
name: start_date [32122,32132]
===
match
---
atom_expr [37667,37723]
atom_expr [37698,37754]
===
match
---
name: xcom_arg [75298,75306]
name: xcom_arg [76922,76930]
===
match
---
operator: = [67535,67536]
operator: = [69159,69160]
===
match
---
expr_stmt [21081,21116]
expr_stmt [21112,21147]
===
match
---
name: dag_diff_name [49125,49138]
name: dag_diff_name [49156,49169]
===
match
---
assert_stmt [77481,77522]
assert_stmt [79105,79146]
===
match
---
name: datetime [26484,26492]
name: datetime [26515,26523]
===
match
---
name: DEFAULT_DATE [32102,32114]
name: DEFAULT_DATE [32133,32145]
===
match
---
testlist_comp [9717,9725]
testlist_comp [9748,9756]
===
match
---
name: params [4727,4733]
name: params [4758,4764]
===
match
---
name: session [34925,34932]
name: session [34956,34963]
===
match
---
string: "faketastic" [43968,43980]
string: "faketastic" [43999,44011]
===
match
---
parameters [19697,19703]
parameters [19728,19734]
===
match
---
trailer [36302,36304]
trailer [36333,36335]
===
match
---
trailer [16907,16914]
trailer [16938,16945]
===
match
---
name: State [19547,19552]
name: State [19578,19583]
===
match
---
trailer [49471,49509]
trailer [49502,49540]
===
match
---
name: dag_run [43245,43252]
name: dag_run [43276,43283]
===
match
---
atom_expr [33925,33987]
atom_expr [33956,34018]
===
match
---
name: self [42438,42442]
name: self [42469,42473]
===
match
---
atom_expr [18318,18327]
atom_expr [18349,18358]
===
match
---
return_stmt [72512,72522]
return_stmt [74136,74146]
===
match
---
dotted_name [2391,2403]
dotted_name [2422,2434]
===
match
---
operator: { [6836,6837]
operator: { [6867,6868]
===
match
---
operator: = [76038,76039]
operator: = [77662,77663]
===
match
---
operator: = [76591,76592]
operator: = [78215,78216]
===
match
---
trailer [25262,25272]
trailer [25293,25303]
===
match
---
simple_stmt [49601,49656]
simple_stmt [49632,49687]
===
match
---
simple_stmt [44074,44168]
simple_stmt [44105,44199]
===
match
---
trailer [7814,7829]
trailer [7845,7860]
===
match
---
atom_expr [29421,29427]
atom_expr [29452,29458]
===
match
---
comparison [7408,7423]
comparison [7439,7454]
===
match
---
simple_stmt [4185,4213]
simple_stmt [4216,4244]
===
match
---
operator: , [66209,66210]
operator: , [67833,67834]
===
match
---
name: DAG [39250,39253]
name: DAG [39281,39284]
===
match
---
name: patcher_dag_code [2904,2920]
name: patcher_dag_code [2935,2951]
===
match
---
comparison [40224,40247]
comparison [40255,40278]
===
match
---
name: dag_id [55731,55737]
name: dag_id [55762,55768]
===
match
---
name: start_date [47060,47070]
name: start_date [47091,47101]
===
match
---
trailer [66494,66565]
trailer [68118,68189]
===
match
---
name: TestCase [69953,69961]
name: TestCase [71577,71585]
===
match
---
name: dag [54452,54455]
name: dag [54483,54486]
===
match
---
operator: , [73735,73736]
operator: , [75359,75360]
===
match
---
operator: = [31200,31201]
operator: = [31231,31232]
===
match
---
operator: = [63975,63976]
operator: = [65599,65600]
===
match
---
name: DAG [28101,28104]
name: DAG [28132,28135]
===
match
---
name: DAG [12739,12742]
name: DAG [12770,12773]
===
match
---
name: self [68649,68653]
name: self [70273,70277]
===
match
---
trailer [11097,11100]
trailer [11128,11131]
===
match
---
simple_stmt [39311,39345]
simple_stmt [39342,39376]
===
match
---
trailer [76528,76536]
trailer [78152,78160]
===
match
---
argument [60946,60959]
argument [60977,60990]
===
match
---
trailer [10860,10862]
trailer [10891,10893]
===
match
---
string: 't1' [40138,40142]
string: 't1' [40169,40173]
===
match
---
atom_expr [71242,71262]
atom_expr [72866,72886]
===
match
---
expr_stmt [27047,27090]
expr_stmt [27078,27121]
===
match
---
fstring_string: dag-bulk-sync- [28107,28121]
fstring_string: dag-bulk-sync- [28138,28152]
===
match
---
trailer [49532,49534]
trailer [49563,49565]
===
match
---
name: DEFAULT_DATE [54002,54014]
name: DEFAULT_DATE [54033,54045]
===
match
---
string: 'owner' [59061,59068]
string: 'owner' [59092,59099]
===
match
---
operator: , [59004,59005]
operator: , [59035,59036]
===
match
---
name: prev_local [24092,24102]
name: prev_local [24123,24133]
===
match
---
arith_expr [78155,78197]
arith_expr [79779,79821]
===
match
---
argument [31859,31865]
argument [31890,31896]
===
match
---
import_from [1587,1639]
import_from [1593,1645]
===
match
---
name: dag [68843,68846]
name: dag [70467,70470]
===
match
---
operator: = [54021,54022]
operator: = [54052,54053]
===
match
---
name: DEFAULT_DATE [39277,39289]
name: DEFAULT_DATE [39308,39320]
===
match
---
name: pickle [47629,47635]
name: pickle [47660,47666]
===
match
---
suite [30025,30066]
suite [30056,30097]
===
match
---
string: "test_dagrun_query_count" [70494,70519]
string: "test_dagrun_query_count" [72118,72143]
===
match
---
operator: , [64981,64982]
operator: , [66605,66606]
===
match
---
argument [33771,33794]
argument [33802,33825]
===
match
---
name: hash [49250,49254]
name: hash [49281,49285]
===
match
---
arglist [16160,16224]
arglist [16191,16255]
===
match
---
name: dag [57491,57494]
name: dag [57522,57525]
===
match
---
string: 'test-dag' [28703,28713]
string: 'test-dag' [28734,28744]
===
match
---
operator: = [75736,75737]
operator: = [77360,77361]
===
match
---
argument [53227,53250]
argument [53258,53281]
===
match
---
import_from [2337,2385]
import_from [2368,2416]
===
match
---
parameters [74209,74227]
parameters [75833,75851]
===
match
---
operator: , [43100,43101]
operator: , [43131,43132]
===
match
---
testlist_comp [55851,55868]
testlist_comp [55882,55899]
===
match
---
trailer [15626,15640]
trailer [15657,15671]
===
match
---
operator: } [47860,47861]
operator: } [47891,47892]
===
match
---
operator: = [56300,56301]
operator: = [56331,56332]
===
match
---
name: list_py_file_paths [37974,37992]
name: list_py_file_paths [38005,38023]
===
match
---
expr_stmt [56292,56320]
expr_stmt [56323,56351]
===
match
---
suite [70218,70614]
suite [71842,72238]
===
match
---
operator: , [35191,35192]
operator: , [35222,35223]
===
match
---
name: self [4930,4934]
name: self [4961,4965]
===
match
---
name: session [44159,44166]
name: session [44190,44197]
===
match
---
name: clear_db_runs [3059,3072]
name: clear_db_runs [3090,3103]
===
match
---
name: isoformat [23944,23953]
name: isoformat [23975,23984]
===
match
---
operator: = [18527,18528]
operator: = [18558,18559]
===
match
---
param [36480,36484]
param [36511,36515]
===
match
---
name: sync_to_db [45148,45158]
name: sync_to_db [45179,45189]
===
match
---
name: template_file [21148,21161]
name: template_file [21179,21192]
===
match
---
simple_stmt [72659,72714]
simple_stmt [74283,74338]
===
match
---
argument [34265,34288]
argument [34296,34319]
===
match
---
name: return_num [72041,72051]
name: return_num [73665,73675]
===
match
---
name: op3 [10513,10516]
name: op3 [10544,10547]
===
match
---
name: start_date [65398,65408]
name: start_date [67022,67032]
===
match
---
trailer [45483,45508]
trailer [45514,45539]
===
match
---
operator: == [32711,32713]
operator: == [32742,32744]
===
match
---
simple_stmt [38465,38509]
simple_stmt [38496,38540]
===
match
---
trailer [11213,11234]
trailer [11244,11265]
===
match
---
argument [55578,55593]
argument [55609,55624]
===
match
---
funcdef [17461,19627]
funcdef [17492,19658]
===
match
---
atom_expr [62791,62813]
atom_expr [62822,62844]
===
match
---
operator: { [39612,39613]
operator: { [39643,39644]
===
match
---
name: param [1712,1717]
name: param [1718,1723]
===
match
---
comparison [37245,37324]
comparison [37276,37355]
===
match
---
trailer [21322,21333]
trailer [21353,21364]
===
match
---
argument [53885,53912]
argument [53916,53943]
===
match
---
name: start_date [53227,53237]
name: start_date [53258,53268]
===
match
---
arglist [24581,24638]
arglist [24612,24669]
===
match
---
simple_stmt [49753,49845]
simple_stmt [49784,49876]
===
match
---
string: """Test that @dag decorated function fails if positional argument is not set""" [72764,72843]
string: """Test that @dag decorated function fails if positional argument is not set""" [74388,74467]
===
match
---
name: self [74793,74797]
name: self [76417,76421]
===
match
---
suite [7135,7183]
suite [7166,7214]
===
match
---
name: state [77373,77378]
name: state [78997,79002]
===
match
---
simple_stmt [7952,7974]
simple_stmt [7983,8005]
===
match
---
number: 0 [59744,59745]
number: 0 [59775,59776]
===
match
---
argument [17949,17955]
argument [17980,17986]
===
match
---
string: 'owner1' [7039,7047]
string: 'owner1' [7070,7078]
===
match
---
operator: == [38211,38213]
operator: == [38242,38244]
===
match
---
atom_expr [41850,41890]
atom_expr [41881,41921]
===
match
---
name: permissions [66304,66315]
name: permissions [67928,67939]
===
match
---
operator: , [55593,55594]
operator: , [55624,55625]
===
match
---
trailer [29963,29968]
trailer [29994,29999]
===
match
---
simple_stmt [19717,19740]
simple_stmt [19748,19771]
===
match
---
trailer [71252,71262]
trailer [72876,72886]
===
match
---
expr_stmt [38324,38369]
expr_stmt [38355,38400]
===
match
---
operator: - [78232,78233]
operator: - [79856,79857]
===
match
---
name: dag [44084,44087]
name: dag [44115,44118]
===
match
---
operator: , [78261,78262]
operator: , [79885,79886]
===
match
---
name: dag_id [33074,33080]
name: dag_id [33105,33111]
===
match
---
trailer [12912,12924]
trailer [12943,12955]
===
match
---
name: start [26189,26194]
name: start [26220,26225]
===
match
---
trailer [58594,58610]
trailer [58625,58641]
===
match
---
name: dag [30013,30016]
name: dag [30044,30047]
===
match
---
simple_stmt [10684,10708]
simple_stmt [10715,10739]
===
match
---
trailer [11571,11621]
trailer [11602,11652]
===
match
---
argument [37543,37571]
argument [37574,37602]
===
match
---
name: self [71370,71374]
name: self [72994,72998]
===
match
---
atom_expr [63663,63703]
atom_expr [65287,65327]
===
match
---
name: task_id [65303,65310]
name: task_id [66927,66934]
===
match
---
arith_expr [48060,48080]
arith_expr [48091,48111]
===
match
---
name: NONE [51031,51035]
name: NONE [51062,51066]
===
match
---
trailer [5519,5579]
trailer [5550,5610]
===
match
---
arith_expr [53209,53225]
arith_expr [53240,53256]
===
match
---
simple_stmt [814,829]
simple_stmt [814,829]
===
match
---
name: test_task [18357,18366]
name: test_task [18388,18397]
===
match
---
operator: , [44149,44150]
operator: , [44180,44181]
===
match
---
name: timezone [67704,67712]
name: timezone [69328,69336]
===
match
---
simple_stmt [51045,51088]
simple_stmt [51076,51119]
===
match
---
string: "0 0 1 1 *" [50180,50191]
string: "0 0 1 1 *" [50211,50222]
===
match
---
simple_stmt [54129,54160]
simple_stmt [54160,54191]
===
match
---
atom [13667,13686]
atom [13698,13717]
===
match
---
operator: = [66543,66544]
operator: = [68167,68168]
===
match
---
number: 2016 [70889,70893]
number: 2016 [72513,72517]
===
match
---
operator: == [7967,7969]
operator: == [7998,8000]
===
match
---
name: TI [54063,54065]
name: TI [54094,54096]
===
match
---
atom_expr [21174,21194]
atom_expr [21205,21225]
===
match
---
name: DEFAULT_DATE [52103,52115]
name: DEFAULT_DATE [52134,52146]
===
match
---
with_stmt [27828,28023]
with_stmt [27859,28054]
===
match
---
name: default_args [48082,48094]
name: default_args [48113,48125]
===
match
---
argument [32091,32114]
argument [32122,32145]
===
match
---
name: DagModel [49550,49558]
name: DagModel [49581,49589]
===
match
---
expr_stmt [51972,52167]
expr_stmt [52003,52198]
===
match
---
trailer [36592,36594]
trailer [36623,36625]
===
match
---
trailer [23289,23298]
trailer [23320,23329]
===
match
---
operator: , [56880,56881]
operator: , [56911,56912]
===
match
---
name: dag [9502,9505]
name: dag [9533,9536]
===
match
---
trailer [52800,52802]
trailer [52831,52833]
===
match
---
argument [41866,41889]
argument [41897,41920]
===
match
---
fstring_end: ' [70376,70377]
fstring_end: ' [72000,72001]
===
match
---
atom_expr [46402,46412]
atom_expr [46433,46443]
===
match
---
operator: } [28021,28022]
operator: } [28052,28053]
===
match
---
number: 1 [78379,78380]
number: 1 [80003,80004]
===
match
---
trailer [74167,74180]
trailer [75791,75804]
===
match
---
operator: = [21856,21857]
operator: = [21887,21888]
===
match
---
name: resolve_template_files [21938,21960]
name: resolve_template_files [21969,21991]
===
match
---
name: State [55883,55888]
name: State [55914,55919]
===
match
---
testlist_comp [70143,70146]
testlist_comp [71767,71770]
===
match
---
number: 5 [62993,62994]
number: 5 [63024,63025]
===
match
---
trailer [19345,19443]
trailer [19376,19474]
===
match
---
simple_stmt [42072,42083]
simple_stmt [42103,42114]
===
match
---
string: 'owner' [10292,10299]
string: 'owner' [10323,10330]
===
match
---
argument [4727,4741]
argument [4758,4772]
===
match
---
atom_expr [31362,31379]
atom_expr [31393,31410]
===
match
---
string: "t1" [39339,39343]
string: "t1" [39370,39374]
===
match
---
arith_expr [17915,17956]
arith_expr [17946,17987]
===
match
---
shift_expr [41192,41202]
shift_expr [41223,41233]
===
match
---
simple_stmt [14753,14763]
simple_stmt [14784,14794]
===
match
---
testlist_comp [19396,19415]
testlist_comp [19427,19446]
===
match
---
argument [51154,51170]
argument [51185,51201]
===
match
---
atom [19372,19386]
atom [19403,19417]
===
match
---
atom_expr [34764,34892]
atom_expr [34795,34923]
===
match
---
trailer [25748,25759]
trailer [25779,25790]
===
match
---
atom_expr [34333,34399]
atom_expr [34364,34430]
===
match
---
operator: , [47489,47490]
operator: , [47520,47521]
===
match
---
trailer [4676,4680]
trailer [4707,4711]
===
match
---
operator: , [28652,28653]
operator: , [28683,28684]
===
match
---
name: session [55637,55644]
name: session [55668,55675]
===
match
---
atom_expr [65654,65680]
atom_expr [67278,67304]
===
match
---
simple_stmt [50913,50966]
simple_stmt [50944,50997]
===
match
---
trailer [53081,53133]
trailer [53112,53164]
===
match
---
atom_expr [77792,77819]
atom_expr [79416,79443]
===
match
---
argument [20786,20804]
argument [20817,20835]
===
match
---
name: execution_date [18190,18204]
name: execution_date [18221,18235]
===
match
---
expr_stmt [58531,58565]
expr_stmt [58562,58596]
===
match
---
name: next_info [57612,57621]
name: next_info [57643,57652]
===
match
---
trailer [70071,70073]
trailer [71695,71697]
===
match
---
operator: , [67665,67666]
operator: , [69289,69290]
===
match
---
trailer [30136,30142]
trailer [30167,30173]
===
match
---
suite [59015,59586]
suite [59046,59617]
===
match
---
trailer [6397,6429]
trailer [6428,6460]
===
match
---
arglist [33736,33795]
arglist [33767,33826]
===
match
---
operator: { [64767,64768]
operator: { [66391,66392]
===
match
---
argument [75061,75091]
argument [76685,76715]
===
match
---
string: 'should_fail' [17418,17431]
string: 'should_fail' [17449,17462]
===
match
---
name: task_id [76680,76687]
name: task_id [78304,78311]
===
match
---
name: datetime [38408,38416]
name: datetime [38439,38447]
===
match
---
operator: , [8197,8198]
operator: , [8228,8229]
===
match
---
name: template_searchpath [21030,21049]
name: template_searchpath [21061,21080]
===
match
---
operator: = [57993,57994]
operator: = [58024,58025]
===
match
---
operator: + [31847,31848]
operator: + [31878,31879]
===
match
---
name: model [45478,45483]
name: model [45509,45514]
===
match
---
string: 'owner1' [6760,6768]
string: 'owner1' [6791,6799]
===
match
---
name: Session [54434,54441]
name: Session [54465,54472]
===
match
---
string: 'dag_paused' [36139,36151]
string: 'dag_paused' [36170,36182]
===
match
---
trailer [38630,38639]
trailer [38661,38670]
===
match
---
trailer [37671,37677]
trailer [37702,37708]
===
match
---
operator: = [45043,45044]
operator: = [45074,45075]
===
match
---
arith_expr [78035,78077]
arith_expr [79659,79701]
===
match
---
operator: , [52581,52582]
operator: , [52612,52613]
===
match
---
name: self [8091,8095]
name: self [8122,8126]
===
match
---
trailer [73157,73168]
trailer [74781,74792]
===
match
---
atom_expr [46781,46870]
atom_expr [46812,46901]
===
match
---
funcdef [20503,20703]
funcdef [20534,20734]
===
match
---
name: refresh_from_db [77407,77422]
name: refresh_from_db [79031,79046]
===
match
---
name: dag [12549,12552]
name: dag [12580,12583]
===
match
---
atom [50153,50193]
atom [50184,50224]
===
match
---
number: 0 [3868,3869]
number: 0 [3899,3900]
===
match
---
operator: = [34485,34486]
operator: = [34516,34517]
===
match
---
string: 'airflow' [47480,47489]
string: 'airflow' [47511,47520]
===
match
---
param [71370,71374]
param [72994,72998]
===
match
---
argument [4693,4725]
argument [4724,4756]
===
match
---
argument [62517,62523]
argument [62548,62554]
===
match
---
trailer [35690,35703]
trailer [35721,35734]
===
match
---
name: ti_state_end [57244,57256]
name: ti_state_end [57275,57287]
===
match
---
name: dag_run_state [54391,54404]
name: dag_run_state [54422,54435]
===
match
---
name: f [20963,20964]
name: f [20994,20995]
===
match
---
arglist [35406,35441]
arglist [35437,35472]
===
match
---
atom [35081,35100]
atom [35112,35131]
===
match
---
name: dag [56278,56281]
name: dag [56309,56312]
===
match
---
name: staticmethod [3142,3154]
name: staticmethod [3173,3185]
===
match
---
operator: , [78977,78978]
operator: , [80601,80602]
===
match
---
trailer [13857,13867]
trailer [13888,13898]
===
match
---
trailer [5804,5837]
trailer [5835,5868]
===
match
---
name: calculated_weight [15840,15857]
name: calculated_weight [15871,15888]
===
match
---
name: a_index [3663,3670]
name: a_index [3694,3701]
===
match
---
trailer [33415,33516]
trailer [33446,33547]
===
match
---
name: getvalue [40061,40069]
name: getvalue [40092,40100]
===
match
---
name: DEFAULT_DATE [54086,54098]
name: DEFAULT_DATE [54117,54129]
===
match
---
name: parent_dag [8370,8380]
name: parent_dag [8401,8411]
===
match
---
atom [34815,34834]
atom [34846,34865]
===
match
---
name: test_clear_set_dagrun_state_for_subdag [54346,54384]
name: test_clear_set_dagrun_state_for_subdag [54377,54415]
===
match
---
name: updated_permissions [66762,66781]
name: updated_permissions [68386,68405]
===
match
---
name: DagModel [35061,35069]
name: DagModel [35092,35100]
===
match
---
name: DummyOperator [9615,9628]
name: DummyOperator [9646,9659]
===
match
---
name: next_info [62889,62898]
name: next_info [62920,62929]
===
match
---
name: subdag [64586,64592]
name: subdag [66210,66216]
===
match
---
name: local_tz [22225,22233]
name: local_tz [22256,22264]
===
match
---
name: dag_id [57280,57286]
name: dag_id [57311,57317]
===
match
---
operator: @ [73315,73316]
operator: @ [74939,74940]
===
match
---
trailer [78362,78372]
trailer [79986,79996]
===
match
---
atom_expr [53018,53040]
atom_expr [53049,53071]
===
match
---
name: task_instance_2 [54045,54060]
name: task_instance_2 [54076,54091]
===
match
---
assert_stmt [74888,74920]
assert_stmt [76512,76544]
===
match
---
operator: = [23330,23331]
operator: = [23361,23362]
===
match
---
simple_stmt [2988,3018]
simple_stmt [3019,3049]
===
match
---
argument [39847,39859]
argument [39878,39890]
===
match
---
trailer [28298,28300]
trailer [28329,28331]
===
match
---
name: dag_run [44246,44253]
name: dag_run [44277,44284]
===
match
---
operator: } [38454,38455]
operator: } [38485,38486]
===
match
---
name: session [18745,18752]
name: session [18776,18783]
===
match
---
funcdef [42399,43321]
funcdef [42430,43352]
===
match
---
name: dag_id [68266,68272]
name: dag_id [69890,69896]
===
match
---
operator: = [22172,22173]
operator: = [22203,22204]
===
match
---
atom_expr [13197,13209]
atom_expr [13228,13240]
===
match
---
string: 'fileloc' [69556,69565]
string: 'fileloc' [71180,71189]
===
match
---
atom [35378,35564]
atom [35409,35595]
===
match
---
operator: = [44158,44159]
operator: = [44189,44190]
===
match
---
simple_stmt [64226,64265]
simple_stmt [65850,65889]
===
match
---
name: schedule_interval [24609,24626]
name: schedule_interval [24640,24657]
===
match
---
name: DummyOperator [51886,51899]
name: DummyOperator [51917,51930]
===
match
---
with_stmt [28951,29020]
with_stmt [28982,29051]
===
match
---
atom_expr [12825,12837]
atom_expr [12856,12868]
===
match
---
argument [14838,14861]
argument [14869,14892]
===
match
---
parameters [17188,17194]
parameters [17219,17225]
===
match
---
name: os [21538,21540]
name: os [21569,21571]
===
match
---
string: 'subdag' [34564,34572]
string: 'subdag' [34595,34603]
===
match
---
simple_stmt [63832,63871]
simple_stmt [65456,65495]
===
match
---
atom_expr [58397,58427]
atom_expr [58428,58458]
===
match
---
string: "dag run execution_date loses precision" [47232,47272]
string: "dag run execution_date loses precision" [47263,47303]
===
match
---
name: start_date [75650,75660]
name: start_date [77274,77284]
===
match
---
argument [46731,46744]
argument [46762,46775]
===
match
---
expr_stmt [3782,3793]
expr_stmt [3813,3824]
===
match
---
name: pipeline [14067,14075]
name: pipeline [14098,14106]
===
match
---
atom_expr [36232,36279]
atom_expr [36263,36310]
===
match
---
import_name [804,813]
import_name [804,813]
===
match
---
name: NamedTemporaryFile [21411,21429]
name: NamedTemporaryFile [21442,21460]
===
match
---
atom_expr [41412,41452]
atom_expr [41443,41483]
===
match
---
operator: , [66413,66414]
operator: , [68037,68038]
===
match
---
atom_expr [8612,8645]
atom_expr [8643,8676]
===
match
---
param [50610,50614]
param [50641,50645]
===
match
---
operator: = [12410,12411]
operator: = [12441,12442]
===
match
---
name: dag_id [71282,71288]
name: dag_id [72906,72912]
===
match
---
string: 'task' [32178,32184]
string: 'task' [32209,32215]
===
match
---
simple_stmt [61282,61437]
simple_stmt [61313,61468]
===
match
---
trailer [27485,27542]
trailer [27516,27573]
===
match
---
decorated [75046,75316]
decorated [76670,76940]
===
match
---
trailer [74768,74777]
trailer [76392,76401]
===
match
---
operator: = [48054,48055]
operator: = [48085,48086]
===
match
---
name: DEFAULT_DATE [77763,77775]
name: DEFAULT_DATE [79387,79399]
===
match
---
name: ti3 [18705,18708]
name: ti3 [18736,18739]
===
match
---
operator: , [55674,55675]
operator: , [55705,55706]
===
match
---
name: task [15557,15561]
name: task [15588,15592]
===
match
---
funcdef [50842,51220]
funcdef [50873,51251]
===
match
---
argument [50267,50273]
argument [50298,50304]
===
match
---
atom_expr [14108,14144]
atom_expr [14139,14175]
===
match
---
number: 1 [68119,68120]
number: 1 [69743,69744]
===
match
---
fstring_start: f' [43102,43104]
fstring_start: f' [43133,43135]
===
match
---
simple_stmt [2482,2543]
simple_stmt [2513,2574]
===
match
---
string: 'dag' [32714,32719]
string: 'dag' [32745,32750]
===
match
---
atom_expr [41237,41248]
atom_expr [41268,41279]
===
match
---
name: start_date [60437,60447]
name: start_date [60468,60478]
===
match
---
operator: , [66527,66528]
operator: , [68151,68152]
===
match
---
name: self [73551,73555]
name: self [75175,75179]
===
match
---
name: session [67781,67788]
name: session [69405,69412]
===
match
---
atom_expr [63139,63162]
atom_expr [63170,63193]
===
match
---
operator: , [63804,63805]
operator: , [65428,65429]
===
match
---
trailer [52751,52758]
trailer [52782,52789]
===
match
---
name: is_active [32821,32830]
name: is_active [32852,32861]
===
match
---
argument [31166,31181]
argument [31197,31212]
===
match
---
operator: , [19575,19576]
operator: , [19606,19607]
===
match
---
atom_expr [25632,25707]
atom_expr [25663,25738]
===
match
---
trailer [78550,78560]
trailer [80174,80184]
===
match
---
argument [8857,8882]
argument [8888,8913]
===
match
---
arglist [74348,74363]
arglist [75972,75987]
===
match
---
atom_expr [20625,20647]
atom_expr [20656,20678]
===
match
---
with_stmt [14822,15946]
with_stmt [14853,15977]
===
match
---
suite [48335,48383]
suite [48366,48414]
===
match
---
name: dag [15565,15568]
name: dag [15596,15599]
===
match
---
operator: + [31458,31459]
operator: + [31489,31490]
===
match
---
with_item [3200,3227]
with_item [3231,3258]
===
match
---
trailer [4119,4131]
trailer [4150,4162]
===
match
---
number: 5 [13317,13318]
number: 5 [13348,13349]
===
match
---
name: prev_local [25137,25147]
name: prev_local [25168,25178]
===
match
---
name: task_id [39034,39041]
name: task_id [39065,39072]
===
match
---
suite [41898,42083]
suite [41929,42114]
===
match
---
argument [53378,53388]
argument [53409,53419]
===
match
---
name: task_dict [40730,40739]
name: task_dict [40761,40770]
===
match
---
name: task_decorator [71549,71563]
name: task_decorator [73173,73187]
===
match
---
operator: = [39430,39431]
operator: = [39461,39462]
===
match
---
expr_stmt [73551,73584]
expr_stmt [75175,75208]
===
match
---
simple_stmt [40045,40072]
simple_stmt [40076,40103]
===
match
---
trailer [52300,52306]
trailer [52331,52337]
===
match
---
operator: = [24377,24378]
operator: = [24408,24409]
===
match
---
comparison [76284,76310]
comparison [77908,77934]
===
match
---
suite [71015,71067]
suite [72639,72691]
===
match
---
name: access_control [66687,66701]
name: access_control [68311,68325]
===
match
---
operator: , [52233,52234]
operator: , [52264,52265]
===
match
---
string: 'dag-bulk-sync-2' [29775,29792]
string: 'dag-bulk-sync-2' [29806,29823]
===
match
---
name: prev_local [23594,23604]
name: prev_local [23625,23635]
===
match
---
name: TEST_DATE [70589,70598]
name: TEST_DATE [72213,72222]
===
match
---
trailer [53981,54036]
trailer [54012,54067]
===
match
---
import_from [2424,2481]
import_from [2455,2512]
===
match
---
name: session [54168,54175]
name: session [54199,54206]
===
match
---
name: dag_run_state [55467,55480]
name: dag_run_state [55498,55511]
===
match
---
expr_stmt [74494,74508]
expr_stmt [76118,76132]
===
match
---
atom_expr [27377,27397]
atom_expr [27408,27428]
===
match
---
argument [13777,13799]
argument [13808,13830]
===
match
---
atom_expr [68884,68902]
atom_expr [70508,70526]
===
match
---
trailer [30170,30172]
trailer [30201,30203]
===
match
---
string: 'start_date' [13161,13173]
string: 'start_date' [13192,13204]
===
match
---
expr_stmt [51787,51801]
expr_stmt [51818,51832]
===
match
---
number: 1 [58016,58017]
number: 1 [58047,58048]
===
match
---
operator: = [43681,43682]
operator: = [43712,43713]
===
match
---
simple_stmt [2899,2980]
simple_stmt [2930,3011]
===
match
---
argument [41499,41511]
argument [41530,41542]
===
match
---
trailer [18003,18111]
trailer [18034,18142]
===
match
---
expr_stmt [38876,38909]
expr_stmt [38907,38940]
===
match
---
operator: , [46412,46413]
operator: , [46443,46444]
===
match
---
simple_stmt [5789,5866]
simple_stmt [5820,5897]
===
match
---
name: Session [56311,56318]
name: Session [56342,56349]
===
match
---
trailer [11508,11510]
trailer [11539,11541]
===
match
---
name: timetables [1992,2002]
name: timetables [2023,2033]
===
match
---
atom_expr [58360,58371]
atom_expr [58391,58402]
===
match
---
arglist [50696,50769]
arglist [50727,50800]
===
match
---
name: Optional [56055,56063]
name: Optional [56086,56094]
===
match
---
name: run_id [76287,76293]
name: run_id [77911,77917]
===
match
---
operator: } [70375,70376]
operator: } [71999,72000]
===
match
---
name: op5 [39014,39017]
name: op5 [39045,39048]
===
match
---
name: dag [74522,74525]
name: dag [76146,76149]
===
match
---
number: 1 [4616,4617]
number: 1 [4647,4648]
===
match
---
trailer [10002,10005]
trailer [10033,10036]
===
match
---
assert_stmt [7401,7423]
assert_stmt [7432,7454]
===
match
---
name: tests [2487,2492]
name: tests [2518,2523]
===
match
---
dictorsetmaker [4602,4617]
dictorsetmaker [4633,4648]
===
match
---
funcdef [15951,17146]
funcdef [15982,17177]
===
match
---
name: isinstance [71242,71252]
name: isinstance [72866,72876]
===
match
---
atom [43041,43100]
atom [43072,43131]
===
match
---
name: i [16622,16623]
name: i [16653,16654]
===
match
---
name: default_args [48233,48245]
name: default_args [48264,48276]
===
match
---
suite [46582,47387]
suite [46613,47418]
===
match
---
name: redirect_stdout [902,917]
name: redirect_stdout [902,917]
===
match
---
trailer [11267,11270]
trailer [11298,11301]
===
match
---
operator: , [67377,67378]
operator: , [69001,69002]
===
match
---
simple_stmt [72559,72581]
simple_stmt [74183,74205]
===
match
---
suite [33534,33829]
suite [33565,33860]
===
match
---
name: subdag [32214,32220]
name: subdag [32245,32251]
===
match
---
trailer [33098,33102]
trailer [33129,33133]
===
match
---
operator: = [24490,24491]
operator: = [24521,24522]
===
match
---
funcdef [58769,61151]
funcdef [58800,61182]
===
match
---
name: __file__ [71336,71344]
name: __file__ [72960,72968]
===
match
---
atom_expr [38408,38454]
atom_expr [38439,38485]
===
match
---
operator: , [32938,32939]
operator: , [32969,32970]
===
match
---
name: set_downstream [10688,10702]
name: set_downstream [10719,10733]
===
match
---
string: """tzinfo derived concrete class named "+0530" with offset of 19800""" [26926,26996]
string: """tzinfo derived concrete class named "+0530" with offset of 19800""" [26957,27027]
===
match
---
atom_expr [24877,24904]
atom_expr [24908,24935]
===
match
---
name: dag_id [52752,52758]
name: dag_id [52783,52789]
===
match
---
atom_expr [54278,54288]
atom_expr [54309,54319]
===
match
---
trailer [4204,4211]
trailer [4235,4242]
===
match
---
name: task_id [70352,70359]
name: task_id [71976,71983]
===
match
---
assert_stmt [20445,20497]
assert_stmt [20476,20528]
===
match
---
operator: , [9720,9721]
operator: , [9751,9752]
===
match
---
name: get [45247,45250]
name: get [45278,45281]
===
match
---
operator: , [67380,67381]
operator: , [69004,69005]
===
match
---
operator: = [75811,75812]
operator: = [77435,77436]
===
match
---
string: 'bar' [20127,20132]
string: 'bar' [20158,20163]
===
match
---
trailer [70974,70983]
trailer [72598,72607]
===
match
---
name: datetime [27057,27065]
name: datetime [27088,27096]
===
match
---
simple_stmt [54531,54794]
simple_stmt [54562,54825]
===
match
---
testlist_comp [49933,49970]
testlist_comp [49964,50001]
===
match
---
expr_stmt [42584,42608]
expr_stmt [42615,42639]
===
match
---
name: freezegun [1199,1208]
name: freezegun [1205,1214]
===
match
---
atom_expr [57345,57469]
atom_expr [57376,57500]
===
match
---
param [12718,12722]
param [12749,12753]
===
match
---
operator: , [29360,29361]
operator: , [29391,29392]
===
match
---
simple_stmt [71271,71306]
simple_stmt [72895,72930]
===
match
---
atom_expr [9129,9188]
atom_expr [9160,9219]
===
match
---
argument [67408,67423]
argument [69032,69047]
===
match
---
string: "test_schedule_interval" [50448,50472]
string: "test_schedule_interval" [50479,50503]
===
match
---
name: dag [69811,69814]
name: dag [71435,71438]
===
match
---
name: dag [58188,58191]
name: dag [58219,58222]
===
match
---
name: dag [70452,70455]
name: dag [72076,72079]
===
match
---
atom [35972,36042]
atom [36003,36073]
===
match
---
simple_stmt [56345,56542]
simple_stmt [56376,56573]
===
match
---
operator: = [44812,44813]
operator: = [44843,44844]
===
match
---
string: """         Tests that an attempt to schedule a task after the Dag's end_date         does not succeed.         """ [57765,57880]
string: """         Tests that an attempt to schedule a task after the Dag's end_date         does not succeed.         """ [57796,57911]
===
match
---
name: test_existing_dag_default_view [36890,36920]
name: test_existing_dag_default_view [36921,36951]
===
match
---
trailer [20909,20917]
trailer [20940,20948]
===
match
---
operator: = [17979,17980]
operator: = [18010,18011]
===
match
---
simple_stmt [18266,18310]
simple_stmt [18297,18341]
===
match
---
funcdef [71919,72055]
funcdef [73543,73679]
===
match
---
name: dag_id [5745,5751]
name: dag_id [5776,5782]
===
match
---
trailer [26565,26622]
trailer [26596,26653]
===
match
---
atom_expr [59662,59689]
atom_expr [59693,59720]
===
match
---
comparison [48818,48843]
comparison [48849,48874]
===
match
---
simple_stmt [46425,46458]
simple_stmt [46456,46489]
===
match
---
name: filter [35847,35853]
name: filter [35878,35884]
===
match
---
argument [26178,26194]
argument [26209,26225]
===
match
---
name: previous_schedule [24007,24024]
name: previous_schedule [24038,24055]
===
match
---
name: SUCCESS [76905,76912]
name: SUCCESS [78529,78536]
===
match
---
argument [44795,44818]
argument [44826,44849]
===
match
---
name: depth [16133,16138]
name: depth [16164,16169]
===
match
---
operator: = [9613,9614]
operator: = [9644,9645]
===
match
---
name: is_paused_upon_creation [36250,36273]
name: is_paused_upon_creation [36281,36304]
===
match
---
string: "Regular DAG documentation" [72686,72713]
string: "Regular DAG documentation" [74310,74337]
===
match
---
name: test_field [21323,21333]
name: test_field [21354,21364]
===
match
---
string: 'dummy-dag' [5237,5248]
string: 'dummy-dag' [5268,5279]
===
match
---
name: dag_id [43700,43706]
name: dag_id [43731,43737]
===
match
---
number: 0 [40159,40160]
number: 0 [40190,40191]
===
match
---
trailer [18698,18704]
trailer [18729,18735]
===
match
---
for_stmt [30675,30776]
for_stmt [30706,30807]
===
match
---
trailer [44142,44149]
trailer [44173,44180]
===
match
---
trailer [18228,18238]
trailer [18259,18269]
===
match
---
name: next_dagrun_info [57628,57644]
name: next_dagrun_info [57659,57675]
===
match
---
string: 'op7' [7823,7828]
string: 'op7' [7854,7859]
===
match
---
argument [58631,58665]
argument [58662,58696]
===
match
---
atom_expr [38928,38955]
atom_expr [38959,38986]
===
match
---
atom_expr [44226,44269]
atom_expr [44257,44300]
===
match
---
arith_expr [64974,64979]
arith_expr [66598,66603]
===
match
---
name: dr4 [18546,18549]
name: dr4 [18577,18580]
===
match
---
string: 'start_date' [47491,47503]
string: 'start_date' [47522,47534]
===
match
---
trailer [7442,7446]
trailer [7473,7477]
===
match
---
operator: , [20214,20215]
operator: , [20245,20246]
===
match
---
atom [69297,69306]
atom [70921,70930]
===
match
---
name: dr [74853,74855]
name: dr [76477,76479]
===
match
---
name: DEFAULT_DATE [78797,78809]
name: DEFAULT_DATE [80421,80433]
===
match
---
argument [25586,25609]
argument [25617,25640]
===
match
---
name: next_date [60098,60107]
name: next_date [60129,60138]
===
match
---
name: timezone [57403,57411]
name: timezone [57434,57442]
===
match
---
name: session [38145,38152]
name: session [38176,38183]
===
match
---
argument [58214,58234]
argument [58245,58265]
===
match
---
number: 2018 [24465,24469]
number: 2018 [24496,24500]
===
match
---
arglist [6790,6855]
arglist [6821,6886]
===
match
---
atom_expr [36414,36433]
atom_expr [36445,36464]
===
match
---
name: task_id [8750,8757]
name: task_id [8781,8788]
===
match
---
name: dag_id [35806,35812]
name: dag_id [35837,35843]
===
match
---
name: op1 [39131,39134]
name: op1 [39162,39165]
===
match
---
simple_stmt [41594,41605]
simple_stmt [41625,41636]
===
match
---
operator: = [9546,9547]
operator: = [9577,9578]
===
match
---
name: dag [47527,47530]
name: dag [47558,47561]
===
match
---
name: i [3851,3852]
name: i [3882,3883]
===
match
---
name: dag [25726,25729]
name: dag [25757,25760]
===
match
---
operator: } [47517,47518]
operator: } [47548,47549]
===
match
---
operator: = [19255,19256]
operator: = [19286,19287]
===
match
---
number: 1 [64347,64348]
number: 1 [65971,65972]
===
match
---
comparison [55904,55926]
comparison [55935,55957]
===
match
---
argument [60396,60423]
argument [60427,60454]
===
match
---
trailer [36994,37054]
trailer [37025,37085]
===
match
---
name: State [76737,76742]
name: State [78361,78366]
===
match
---
trailer [16643,16653]
trailer [16674,16684]
===
match
---
name: State [50759,50764]
name: State [50790,50795]
===
match
---
operator: , [68114,68115]
operator: , [69738,69739]
===
match
---
trailer [54136,54142]
trailer [54167,54173]
===
match
---
operator: + [64976,64977]
operator: + [66600,66601]
===
match
---
argument [55467,55494]
argument [55498,55525]
===
match
---
simple_stmt [7842,7877]
simple_stmt [7873,7908]
===
match
---
arith_expr [77971,78013]
arith_expr [79595,79637]
===
match
---
operator: , [31155,31156]
operator: , [31186,31187]
===
match
---
name: start_date [70264,70274]
name: start_date [71888,71898]
===
match
---
atom_expr [31411,31441]
atom_expr [31442,31472]
===
match
---
trailer [28227,28230]
trailer [28258,28261]
===
match
---
comparison [55783,55812]
comparison [55814,55843]
===
match
---
operator: , [64828,64829]
operator: , [66452,66453]
===
match
---
operator: , [44899,44900]
operator: , [44930,44931]
===
match
---
name: subdag_id [34183,34192]
name: subdag_id [34214,34223]
===
match
---
trailer [35080,35101]
trailer [35111,35132]
===
match
---
comparison [27603,27650]
comparison [27634,27681]
===
match
---
name: convert [23341,23348]
name: convert [23372,23379]
===
match
---
operator: >> [59548,59550]
operator: >> [59579,59581]
===
match
---
name: merge [56713,56718]
name: merge [56744,56749]
===
match
---
name: dag [46102,46105]
name: dag [46133,46136]
===
match
---
trailer [71040,71042]
trailer [72664,72666]
===
match
---
assert_stmt [11475,11510]
assert_stmt [11506,11541]
===
match
---
name: subdag [53398,53404]
name: subdag [53429,53435]
===
match
---
name: dag [45252,45255]
name: dag [45283,45286]
===
match
---
name: execution_date [74639,74653]
name: execution_date [76263,76277]
===
match
---
comparison [27881,28022]
comparison [27912,28053]
===
match
---
operator: = [54747,54748]
operator: = [54778,54779]
===
match
---
operator: = [5443,5444]
operator: = [5474,5475]
===
match
---
atom_expr [74821,74838]
atom_expr [76445,76462]
===
match
---
name: logical_date [62008,62020]
name: logical_date [62039,62051]
===
match
---
name: self [71488,71492]
name: self [73112,73116]
===
match
---
name: default_args [72868,72880]
name: default_args [74492,74504]
===
match
---
with_stmt [10401,10812]
with_stmt [10432,10843]
===
match
---
suite [72363,72550]
suite [73987,74174]
===
match
---
name: dag_eq [48274,48280]
name: dag_eq [48305,48311]
===
match
---
name: assert_queries_count [29033,29053]
name: assert_queries_count [29064,29084]
===
match
---
name: state [55904,55909]
name: state [55935,55940]
===
match
---
expr_stmt [37395,37422]
expr_stmt [37426,37453]
===
match
---
name: states [19533,19539]
name: states [19564,19570]
===
match
---
suite [21708,21761]
suite [21739,21792]
===
match
---
argument [21746,21759]
argument [21777,21790]
===
match
---
name: make_dag [58958,58966]
name: make_dag [58989,58997]
===
match
---
operator: = [34371,34372]
operator: = [34402,34403]
===
match
---
trailer [54623,54633]
trailer [54654,54664]
===
match
---
testlist_comp [77856,78604]
testlist_comp [79480,80228]
===
match
---
name: expected_infos [79064,79078]
name: expected_infos [80688,80702]
===
match
---
operator: = [41477,41478]
operator: = [41508,41509]
===
match
---
name: task_depth [15657,15667]
name: task_depth [15688,15698]
===
match
---
trailer [27391,27397]
trailer [27422,27428]
===
match
---
atom_expr [30609,30661]
atom_expr [30640,30692]
===
match
---
string: "@daily" [64820,64828]
string: "@daily" [66444,66452]
===
match
---
name: fixture [2668,2675]
name: fixture [2699,2706]
===
match
---
operator: = [60413,60414]
operator: = [60444,60445]
===
match
---
trailer [9538,9551]
trailer [9569,9582]
===
match
---
arglist [78339,78416]
arglist [79963,80040]
===
match
---
atom [13719,13881]
atom [13750,13912]
===
match
---
argument [53987,54014]
argument [54018,54045]
===
match
---
name: task_instance_1 [56668,56683]
name: task_instance_1 [56699,56714]
===
match
---
argument [9584,9595]
argument [9615,9626]
===
match
---
trailer [4859,4873]
trailer [4890,4904]
===
match
---
name: Undefined [20693,20702]
name: Undefined [20724,20733]
===
match
---
trailer [64063,64072]
trailer [65687,65696]
===
match
---
suite [5496,5580]
suite [5527,5611]
===
match
---
trailer [70311,70324]
trailer [71935,71948]
===
match
---
operator: = [56225,56226]
operator: = [56256,56257]
===
match
---
trailer [69507,69513]
trailer [71131,71137]
===
match
---
simple_stmt [77481,77523]
simple_stmt [79105,79147]
===
match
---
name: subdag_id [36015,36024]
name: subdag_id [36046,36055]
===
match
---
operator: == [66600,66602]
operator: == [68224,68226]
===
match
---
operator: = [75860,75861]
operator: = [77484,77485]
===
match
---
atom_expr [60536,60563]
atom_expr [60567,60594]
===
match
---
name: parameterized [55819,55832]
name: parameterized [55850,55863]
===
match
---
name: dag [75364,75367]
name: dag [76988,76991]
===
match
---
name: orm_dag [68463,68470]
name: orm_dag [70087,70094]
===
match
---
operator: , [61529,61530]
operator: , [61560,61561]
===
match
---
atom [70110,70158]
atom [71734,71782]
===
match
---
simple_stmt [77060,77113]
simple_stmt [78684,78737]
===
match
---
name: dag [44226,44229]
name: dag [44257,44260]
===
match
---
number: 2020 [62835,62839]
number: 2020 [62866,62870]
===
match
---
number: 1 [38435,38436]
number: 1 [38466,38467]
===
match
---
simple_stmt [33337,33353]
simple_stmt [33368,33384]
===
match
---
trailer [69269,69271]
trailer [70893,70895]
===
match
---
atom_expr [18395,18404]
atom_expr [18426,18435]
===
match
---
expr_stmt [75562,75598]
expr_stmt [77186,77222]
===
match
---
trailer [76242,76250]
trailer [77866,77874]
===
match
---
name: op2 [59551,59554]
name: op2 [59582,59585]
===
match
---
name: is_paused [35432,35441]
name: is_paused [35463,35472]
===
match
---
trailer [74347,74364]
trailer [75971,75988]
===
match
---
dictorsetmaker [59061,59122]
dictorsetmaker [59092,59153]
===
match
---
comparison [62943,62998]
comparison [62974,63029]
===
match
---
name: get_ti_from_db [77210,77224]
name: get_ti_from_db [78834,78848]
===
match
---
suite [15325,15540]
suite [15356,15571]
===
match
---
name: get_num_task_instances [19323,19345]
name: get_num_task_instances [19354,19376]
===
match
---
name: next_dagrun_info [63848,63864]
name: next_dagrun_info [65472,65488]
===
match
---
trailer [44691,44700]
trailer [44722,44731]
===
match
---
name: DAG [19762,19765]
name: DAG [19793,19796]
===
match
---
name: flush [68488,68493]
name: flush [70112,70117]
===
match
---
operator: = [59153,59154]
operator: = [59184,59185]
===
match
---
name: dag [26240,26243]
name: dag [26271,26274]
===
match
---
name: self [53018,53022]
name: self [53049,53053]
===
match
---
operator: == [24989,24991]
operator: == [25020,25022]
===
match
---
name: next_info [62639,62648]
name: next_info [62670,62679]
===
match
---
simple_stmt [64645,64694]
simple_stmt [66269,66318]
===
match
---
suite [52978,54227]
suite [53009,54258]
===
match
---
classdef [26882,27398]
classdef [26913,27429]
===
match
---
operator: , [73693,73694]
operator: , [75317,75318]
===
match
---
operator: = [35739,35740]
operator: = [35770,35771]
===
match
---
name: prev [22849,22853]
name: prev [22880,22884]
===
match
---
simple_stmt [73919,73951]
simple_stmt [75543,75575]
===
match
---
arglist [33561,33591]
arglist [33592,33622]
===
match
---
string: """         Test if the schedule_interval will be auto aligned with the start_date         such that if the start_date coincides with the schedule the first         execution_date will be start_date, otherwise it will be start_date +         interval.         """ [63307,63570]
string: """         Test if the schedule_interval will be auto aligned with the start_date         such that if the start_date coincides with the schedule the first         execution_date will be start_date, otherwise it will be start_date +         interval.         """ [64931,65194]
===
match
---
name: MagicMock [43596,43605]
name: MagicMock [43627,43636]
===
match
---
name: prev [25093,25097]
name: prev [25124,25128]
===
match
---
operator: = [12737,12738]
operator: = [12768,12769]
===
match
---
operator: , [54318,54319]
operator: , [54349,54350]
===
match
---
operator: = [38995,38996]
operator: = [39026,39027]
===
match
---
name: info [10879,10883]
name: info [10910,10914]
===
match
---
name: next_dagrun_info [61696,61712]
name: next_dagrun_info [61727,61743]
===
match
---
name: prev [24161,24165]
name: prev [24192,24196]
===
match
---
name: rollback [68565,68573]
name: rollback [70189,70197]
===
match
---
atom_expr [78234,78261]
atom_expr [79858,79885]
===
match
---
string: 'airflow' [6165,6174]
string: 'airflow' [6196,6205]
===
match
---
name: patcher_dag_code [3112,3128]
name: patcher_dag_code [3143,3159]
===
match
---
operator: , [74583,74584]
operator: , [76207,76208]
===
match
---
name: dag_id [47636,47642]
name: dag_id [47667,47673]
===
match
---
name: next_info [62571,62580]
name: next_info [62602,62611]
===
match
---
number: 2018 [26502,26506]
number: 2018 [26533,26537]
===
match
---
operator: , [73781,73782]
operator: , [75405,75406]
===
match
---
with_stmt [7747,7877]
with_stmt [7778,7908]
===
match
---
trailer [12828,12837]
trailer [12859,12868]
===
match
---
assert_stmt [23023,23083]
assert_stmt [23054,23114]
===
match
---
name: session [19418,19425]
name: session [19449,19456]
===
match
---
simple_stmt [918,949]
simple_stmt [918,949]
===
match
---
atom_expr [47996,48031]
atom_expr [48027,48062]
===
match
---
operator: { [19732,19733]
operator: { [19763,19764]
===
match
---
name: dag [63844,63847]
name: dag [65468,65471]
===
match
---
name: patcher_dag_code [2993,3009]
name: patcher_dag_code [3024,3040]
===
match
---
operator: , [56419,56420]
operator: , [56450,56451]
===
match
---
assert_stmt [9979,10014]
assert_stmt [10010,10045]
===
match
---
arglist [18352,18385]
arglist [18383,18416]
===
match
---
name: create_dagrun [50682,50695]
name: create_dagrun [50713,50726]
===
match
---
name: self [22068,22072]
name: self [22099,22103]
===
match
---
name: timedelta [50257,50266]
name: timedelta [50288,50297]
===
match
---
operator: } [5165,5166]
operator: } [5196,5197]
===
match
---
name: test_dags_needing_dagruns_only_unpaused [68609,68648]
name: test_dags_needing_dagruns_only_unpaused [70233,70272]
===
match
---
operator: , [45015,45016]
operator: , [45046,45047]
===
match
---
atom [35986,36000]
atom [36017,36031]
===
match
---
trailer [51165,51170]
trailer [51196,51201]
===
match
---
operator: , [27512,27513]
operator: , [27543,27544]
===
match
---
atom_expr [22480,22544]
atom_expr [22511,22575]
===
match
---
string: "test_dag" [38773,38783]
string: "test_dag" [38804,38814]
===
match
---
parameters [75120,75138]
parameters [76744,76762]
===
match
---
arith_expr [31445,31477]
arith_expr [31476,31508]
===
match
---
trailer [3440,3446]
trailer [3471,3477]
===
match
---
name: next_date [60235,60244]
name: next_date [60266,60275]
===
match
---
assert_stmt [38107,38135]
assert_stmt [38138,38166]
===
match
---
name: dag_run [43155,43162]
name: dag_run [43186,43193]
===
match
---
comparison [33120,33178]
comparison [33151,33209]
===
match
---
atom [29725,29756]
atom [29756,29787]
===
match
---
atom_expr [74163,74180]
atom_expr [75787,75804]
===
match
---
name: patch [2928,2933]
name: patch [2959,2964]
===
match
---
atom_expr [76488,76509]
atom_expr [78112,78133]
===
match
---
trailer [3128,3133]
trailer [3159,3164]
===
match
---
name: test_iter_dagrun_infos_between [78687,78717]
name: test_iter_dagrun_infos_between [80311,80341]
===
match
---
name: default_args [13654,13666]
name: default_args [13685,13697]
===
match
---
simple_stmt [33547,33593]
simple_stmt [33578,33624]
===
match
---
atom_expr [35004,35022]
atom_expr [35035,35053]
===
match
---
number: 1 [12802,12803]
number: 1 [12833,12834]
===
match
---
name: subdag_id [34816,34825]
name: subdag_id [34847,34856]
===
match
---
name: ti_state_begin [56644,56658]
name: ti_state_begin [56675,56689]
===
match
---
name: dag [67429,67432]
name: dag [69053,69056]
===
match
---
for_stmt [14050,14145]
for_stmt [14081,14176]
===
match
---
simple_stmt [2875,2891]
simple_stmt [2906,2922]
===
match
---
simple_stmt [48682,48709]
simple_stmt [48713,48740]
===
match
---
simple_stmt [48565,48598]
simple_stmt [48596,48629]
===
match
---
name: DummyOperator [39879,39892]
name: DummyOperator [39910,39923]
===
match
---
trailer [71324,71332]
trailer [72948,72956]
===
match
---
trailer [9583,9596]
trailer [9614,9627]
===
match
---
expr_stmt [40085,40118]
expr_stmt [40116,40149]
===
match
---
trailer [28002,28006]
trailer [28033,28037]
===
match
---
operator: , [44121,44122]
operator: , [44152,44153]
===
match
---
parameters [38681,38687]
parameters [38712,38718]
===
match
---
operator: = [40603,40604]
operator: = [40634,40635]
===
match
---
trailer [33955,33981]
trailer [33986,34012]
===
match
---
string: 't2' [42121,42125]
string: 't2' [42152,42156]
===
match
---
string: "2018-03-25T01:00:00+00:00" [26304,26331]
string: "2018-03-25T01:00:00+00:00" [26335,26362]
===
match
---
arglist [9325,9389]
arglist [9356,9420]
===
match
---
atom_expr [51067,51087]
atom_expr [51098,51118]
===
match
---
operator: = [7846,7847]
operator: = [7877,7878]
===
match
---
atom_expr [10980,11012]
atom_expr [11011,11043]
===
match
---
string: 'dag-bulk-sync-3' [29825,29842]
string: 'dag-bulk-sync-3' [29856,29873]
===
match
---
operator: = [6835,6836]
operator: = [6866,6867]
===
match
---
simple_stmt [11475,11511]
simple_stmt [11506,11542]
===
match
---
atom_expr [51187,51198]
atom_expr [51218,51229]
===
match
---
dictorsetmaker [66904,66934]
dictorsetmaker [68528,68558]
===
match
---
atom [27775,27793]
atom [27806,27824]
===
match
---
name: topological_list [8810,8826]
name: topological_list [8841,8857]
===
match
---
operator: = [33781,33782]
operator: = [33812,33813]
===
match
---
name: settings [12957,12965]
name: settings [12988,12996]
===
match
---
argument [16433,16464]
argument [16464,16495]
===
match
---
testlist_comp [13738,13825]
testlist_comp [13769,13856]
===
match
---
atom_expr [27299,27318]
atom_expr [27330,27349]
===
match
---
operator: , [61796,61797]
operator: , [61827,61828]
===
match
---
comparison [45478,45532]
comparison [45509,45563]
===
match
---
simple_stmt [10911,10929]
simple_stmt [10942,10960]
===
match
---
operator: , [52115,52116]
operator: , [52146,52147]
===
match
---
simple_stmt [13708,13882]
simple_stmt [13739,13913]
===
match
---
argument [63797,63804]
argument [65421,65428]
===
match
---
name: stdout [39989,39995]
name: stdout [40020,40026]
===
match
---
argument [37035,37052]
argument [37066,37083]
===
match
---
simple_stmt [10821,10863]
simple_stmt [10852,10894]
===
match
---
name: utils [2059,2064]
name: utils [2090,2095]
===
match
---
atom_expr [67153,67166]
atom_expr [68777,68790]
===
match
---
number: 1 [70895,70896]
number: 1 [72519,72520]
===
match
---
simple_stmt [3241,3329]
simple_stmt [3272,3360]
===
match
---
trailer [70236,70288]
trailer [71860,71912]
===
match
---
number: 1 [55451,55452]
number: 1 [55482,55483]
===
match
---
argument [72868,72898]
argument [74492,74522]
===
match
---
arglist [52381,52611]
arglist [52412,52642]
===
match
---
testlist_comp [49895,50321]
testlist_comp [49926,50352]
===
match
---
name: dag_id [3379,3385]
name: dag_id [3410,3416]
===
match
---
import_from [1068,1099]
import_from [1074,1105]
===
match
---
name: DEFAULT_DATE [70275,70287]
name: DEFAULT_DATE [71899,71911]
===
match
---
string: """         We should never create dagruns for unpaused DAGs         """ [68664,68736]
string: """         We should never create dagruns for unpaused DAGs         """ [70288,70360]
===
match
---
expr_stmt [22553,22588]
expr_stmt [22584,22619]
===
match
---
comparison [16674,16680]
comparison [16705,16711]
===
match
---
arglist [22242,22314]
arglist [22273,22345]
===
match
---
suite [76114,76355]
suite [77738,77979]
===
match
---
string: """             Create a subdag.             """ [64645,64693]
string: """             Create a subdag.             """ [66269,66317]
===
match
---
name: dag [65654,65657]
name: dag [67278,67281]
===
match
---
atom [18823,18835]
atom [18854,18866]
===
match
---
funcdef [24214,25306]
funcdef [24245,25337]
===
match
---
string: 'dummy' [63788,63795]
string: 'dummy' [65412,65419]
===
match
---
operator: , [11430,11431]
operator: , [11461,11462]
===
match
---
string: 't2' [59462,59466]
string: 't2' [59493,59497]
===
match
---
arith_expr [14396,14420]
arith_expr [14427,14451]
===
match
---
comparison [25189,25242]
comparison [25220,25273]
===
match
---
argument [74597,74625]
argument [76221,76249]
===
match
---
name: i [64896,64897]
name: i [66520,66521]
===
match
---
with_item [27833,27860]
with_item [27864,27891]
===
match
---
comparison [6389,6448]
comparison [6420,6479]
===
match
---
trailer [43018,43025]
trailer [43049,43056]
===
match
---
atom [55109,55125]
atom [55140,55156]
===
match
---
operator: , [61579,61580]
operator: , [61610,61611]
===
match
---
operator: , [40435,40436]
operator: , [40466,40467]
===
match
---
name: commit [18753,18759]
name: commit [18784,18790]
===
match
---
simple_stmt [61105,61151]
simple_stmt [61136,61182]
===
match
---
name: delete [38180,38186]
name: delete [38211,38217]
===
match
---
trailer [26243,26261]
trailer [26274,26292]
===
match
---
name: DummyOperator [31126,31139]
name: DummyOperator [31157,31170]
===
match
---
name: dag [35288,35291]
name: dag [35319,35322]
===
match
---
trailer [3358,3365]
trailer [3389,3396]
===
match
---
trailer [23615,23623]
trailer [23646,23654]
===
match
---
expr_stmt [47975,48031]
expr_stmt [48006,48062]
===
match
---
name: DummyOperator [10474,10487]
name: DummyOperator [10505,10518]
===
match
---
operator: = [51795,51796]
operator: = [51826,51827]
===
match
---
string: 'dag-bulk-sync-1' [29627,29644]
string: 'dag-bulk-sync-1' [29658,29675]
===
match
---
with_stmt [34308,34400]
with_stmt [34339,34431]
===
match
---
name: owner [68171,68176]
name: owner [69795,69800]
===
match
---
string: 'owner1' [9380,9388]
string: 'owner1' [9411,9419]
===
match
---
argument [15104,15135]
argument [15135,15166]
===
match
---
name: self [3937,3941]
name: self [3968,3972]
===
match
---
string: 'value' [74724,74731]
string: 'value' [76348,76355]
===
match
---
parameters [78717,78745]
parameters [80341,80369]
===
match
---
assert_stmt [60646,60678]
assert_stmt [60677,60709]
===
match
---
name: session [69193,69200]
name: session [70817,70824]
===
match
---
trailer [2992,3009]
trailer [3023,3040]
===
match
---
name: topological_list [9096,9112]
name: topological_list [9127,9143]
===
match
---
operator: = [74387,74388]
operator: = [76011,76012]
===
match
---
atom_expr [2851,2866]
atom_expr [2882,2897]
===
match
---
simple_stmt [71690,71718]
simple_stmt [73314,73342]
===
match
---
argument [40659,40681]
argument [40690,40712]
===
match
---
operator: = [65442,65443]
operator: = [67066,67067]
===
match
---
trailer [59616,59618]
trailer [59647,59649]
===
match
---
suite [47779,47797]
suite [47810,47828]
===
match
---
param [72749,72753]
param [74373,74377]
===
match
---
operator: == [31380,31382]
operator: == [31411,31413]
===
match
---
operator: , [67625,67626]
operator: , [69249,69250]
===
match
---
name: self [50610,50614]
name: self [50641,50645]
===
match
---
name: dag [48840,48843]
name: dag [48871,48874]
===
match
---
atom_expr [36603,36634]
atom_expr [36634,36665]
===
match
---
atom_expr [56961,57100]
atom_expr [56992,57131]
===
match
---
expr_stmt [18481,18505]
expr_stmt [18512,18536]
===
match
---
expr_stmt [17508,17555]
expr_stmt [17539,17586]
===
match
---
name: op2 [9717,9720]
name: op2 [9748,9751]
===
match
---
operator: , [11033,11034]
operator: , [11064,11065]
===
match
---
expr_stmt [9771,9812]
expr_stmt [9802,9843]
===
match
---
atom [35769,35955]
atom [35800,35986]
===
match
---
atom_expr [71051,71066]
atom_expr [72675,72690]
===
match
---
string: """Verify if dag.leaves returns the leaf tasks of a DAG.""" [39177,39236]
string: """Verify if dag.leaves returns the leaf tasks of a DAG.""" [39208,39267]
===
match
---
name: state [18399,18404]
name: state [18430,18435]
===
match
---
name: dag [22784,22787]
name: dag [22815,22818]
===
match
---
name: filter [34788,34794]
name: filter [34819,34825]
===
match
---
fstring_expr [16355,16358]
fstring_expr [16386,16389]
===
match
---
operator: = [22529,22530]
operator: = [22560,22561]
===
match
---
comparison [77264,77306]
comparison [78888,78930]
===
match
---
operator: } [49696,49697]
operator: } [49727,49728]
===
match
---
atom_expr [53785,53802]
atom_expr [53816,53833]
===
match
---
name: data_interval [58552,58565]
name: data_interval [58583,58596]
===
match
---
trailer [69416,69425]
trailer [71040,71049]
===
match
---
atom_expr [3241,3328]
atom_expr [3272,3359]
===
match
---
number: 2020 [61187,61191]
number: 2020 [61218,61222]
===
match
---
argument [44151,44166]
argument [44182,44197]
===
match
---
trailer [58365,58371]
trailer [58396,58402]
===
match
---
testlist_comp [51583,51594]
testlist_comp [51614,51625]
===
match
---
name: self [71132,71136]
name: self [72756,72760]
===
match
---
simple_stmt [57265,57288]
simple_stmt [57296,57319]
===
match
---
argument [66920,66933]
argument [68544,68557]
===
match
---
operator: , [35223,35224]
operator: , [35254,35255]
===
match
---
simple_stmt [15840,15887]
simple_stmt [15871,15918]
===
match
---
name: dag_run_state [55799,55812]
name: dag_run_state [55830,55843]
===
match
---
operator: = [67846,67847]
operator: = [69470,69471]
===
match
---
arglist [22484,22543]
arglist [22515,22574]
===
match
---
trailer [78188,78197]
trailer [79812,79821]
===
match
---
name: VALUE [75132,75137]
name: VALUE [76756,76761]
===
match
---
with_stmt [66946,67224]
with_stmt [68570,68848]
===
match
---
trailer [62089,62101]
trailer [62120,62132]
===
match
---
name: pendulum [78994,79002]
name: pendulum [80618,80626]
===
match
---
operator: , [41864,41865]
operator: , [41895,41896]
===
match
---
name: dag [7752,7755]
name: dag [7783,7786]
===
match
---
expr_stmt [6322,6373]
expr_stmt [6353,6404]
===
match
---
argument [59253,59274]
argument [59284,59305]
===
match
---
atom_expr [20963,20969]
atom_expr [20994,21000]
===
match
---
argument [26576,26592]
argument [26607,26623]
===
match
---
operator: } [28728,28729]
operator: } [28759,28760]
===
match
---
name: max_active_runs [65158,65173]
name: max_active_runs [66782,66797]
===
match
---
trailer [21839,21855]
trailer [21870,21886]
===
match
---
trailer [35943,35945]
trailer [35974,35976]
===
match
---
name: test_dags_needing_dagruns_not_too_early [67254,67293]
name: test_dags_needing_dagruns_not_too_early [68878,68917]
===
match
---
trailer [76471,76479]
trailer [78095,78103]
===
match
---
operator: == [42242,42244]
operator: == [42273,42275]
===
match
---
atom_expr [59385,59421]
atom_expr [59416,59452]
===
match
---
dictorsetmaker [66265,66414]
dictorsetmaker [67889,68038]
===
match
---
name: xcom_pull [73969,73978]
name: xcom_pull [75593,75602]
===
match
---
trailer [35715,35729]
trailer [35746,35760]
===
match
---
import_from [2197,2234]
import_from [2228,2265]
===
match
---
operator: , [8698,8699]
operator: , [8729,8730]
===
match
---
simple_stmt [32576,32605]
simple_stmt [32607,32636]
===
match
---
trailer [42211,42217]
trailer [42242,42248]
===
match
---
assert_stmt [7192,7214]
assert_stmt [7223,7245]
===
match
---
name: settings [37993,38001]
name: settings [38024,38032]
===
match
---
name: op4 [10737,10740]
name: op4 [10768,10771]
===
match
---
argument [54655,54682]
argument [54686,54713]
===
match
---
atom_expr [41531,41558]
atom_expr [41562,41589]
===
match
---
name: i [16674,16675]
name: i [16705,16706]
===
match
---
name: template_fields [21179,21194]
name: template_fields [21210,21225]
===
match
---
import_as_names [1461,1499]
import_as_names [1467,1505]
===
match
---
operator: = [34580,34581]
operator: = [34611,34612]
===
match
---
atom_expr [63844,63870]
atom_expr [65468,65494]
===
match
---
name: next_info [58542,58551]
name: next_info [58573,58582]
===
match
---
arglist [32927,32958]
arglist [32958,32989]
===
match
---
operator: = [22478,22479]
operator: = [22509,22510]
===
match
---
name: dr4 [18120,18123]
name: dr4 [18151,18154]
===
match
---
operator: = [41174,41175]
operator: = [41205,41206]
===
match
---
simple_stmt [69875,69924]
simple_stmt [71499,71548]
===
match
---
name: utcnow [59610,59616]
name: utcnow [59641,59647]
===
match
---
assert_stmt [41709,41769]
assert_stmt [41740,41800]
===
match
---
and_test [61734,61803]
and_test [61765,61834]
===
match
---
simple_stmt [59028,59137]
simple_stmt [59059,59168]
===
match
---
trailer [75777,75795]
trailer [77401,77419]
===
match
---
name: j [15183,15184]
name: j [15214,15215]
===
match
---
string: "test_dag" [41033,41043]
string: "test_dag" [41064,41074]
===
match
---
arith_expr [52427,52468]
arith_expr [52458,52499]
===
match
---
trailer [28782,28784]
trailer [28813,28815]
===
match
---
operator: - [58014,58015]
operator: - [58045,58046]
===
match
---
trailer [13221,13230]
trailer [13252,13261]
===
match
---
trailer [33134,33141]
trailer [33165,33172]
===
match
---
name: all [30727,30730]
name: all [30758,30761]
===
match
---
trailer [41650,41660]
trailer [41681,41691]
===
match
---
assert_stmt [49205,49234]
assert_stmt [49236,49265]
===
match
---
operator: = [20240,20241]
operator: = [20271,20272]
===
match
---
argument [53325,53332]
argument [53356,53363]
===
match
---
atom_expr [48785,48802]
atom_expr [48816,48833]
===
match
---
expr_stmt [34409,34423]
expr_stmt [34440,34454]
===
match
---
name: datetime [795,803]
name: datetime [795,803]
===
match
---
trailer [7167,7182]
trailer [7198,7213]
===
match
---
arglist [11689,11763]
arglist [11720,11794]
===
match
---
name: task_id [40645,40652]
name: task_id [40676,40683]
===
match
---
param [68016,68020]
param [69640,69644]
===
match
---
atom_expr [54975,54987]
atom_expr [55006,55018]
===
match
---
operator: , [9330,9331]
operator: , [9361,9362]
===
match
---
for_stmt [64892,64999]
for_stmt [66516,66623]
===
match
---
atom_expr [76284,76293]
atom_expr [77908,77917]
===
match
---
simple_stmt [19611,19627]
simple_stmt [19642,19658]
===
match
---
name: airflow [1645,1652]
name: airflow [1651,1658]
===
match
---
name: next_dagrun_create_after [31972,31996]
name: next_dagrun_create_after [32003,32027]
===
match
---
simple_stmt [42092,42176]
simple_stmt [42123,42207]
===
match
---
name: run_id [76304,76310]
name: run_id [77928,77934]
===
match
---
atom_expr [28284,28300]
atom_expr [28315,28331]
===
match
---
atom [39060,39070]
atom [39091,39101]
===
match
---
name: session [75433,75440]
name: session [77057,77064]
===
match
---
simple_stmt [1068,1100]
simple_stmt [1074,1106]
===
match
---
trailer [67823,67825]
trailer [69447,69449]
===
match
---
assert_stmt [31959,32008]
assert_stmt [31990,32039]
===
match
---
name: op9 [7928,7931]
name: op9 [7959,7962]
===
match
---
comparison [29323,29489]
comparison [29354,29520]
===
match
---
atom_expr [53526,53733]
atom_expr [53557,53764]
===
match
---
trailer [48791,48797]
trailer [48822,48828]
===
match
---
suite [12724,12975]
suite [12755,13006]
===
match
---
trailer [42729,42743]
trailer [42760,42774]
===
match
---
name: delta [25521,25526]
name: delta [25552,25557]
===
match
---
atom_expr [45542,45564]
atom_expr [45573,45595]
===
match
---
trailer [26501,26547]
trailer [26532,26578]
===
match
---
simple_stmt [15373,15382]
simple_stmt [15404,15413]
===
match
---
trailer [52460,52468]
trailer [52491,52499]
===
match
---
name: set [30609,30612]
name: set [30640,30643]
===
match
---
name: NONE [51449,51453]
name: NONE [51480,51484]
===
match
---
trailer [16914,16916]
trailer [16945,16947]
===
match
---
name: DagModel [49784,49792]
name: DagModel [49815,49823]
===
match
---
operator: = [27456,27457]
operator: = [27487,27488]
===
match
---
simple_stmt [61911,61969]
simple_stmt [61942,62000]
===
match
---
trailer [18464,18471]
trailer [18495,18502]
===
match
---
name: model [31362,31367]
name: model [31393,31398]
===
match
---
parameters [9299,9305]
parameters [9330,9336]
===
match
---
name: start_date [60896,60906]
name: start_date [60927,60937]
===
match
---
operator: = [64054,64055]
operator: = [65678,65679]
===
match
---
comparison [49339,49370]
comparison [49370,49401]
===
match
---
simple_stmt [55776,55813]
simple_stmt [55807,55844]
===
match
---
trailer [73926,73945]
trailer [75550,75569]
===
match
---
operator: = [59438,59439]
operator: = [59469,59470]
===
match
---
atom_expr [17608,17656]
atom_expr [17639,17687]
===
match
---
for_stmt [16727,16869]
for_stmt [16758,16900]
===
match
---
name: catchup [60065,60072]
name: catchup [60096,60103]
===
match
---
name: set2 [11274,11278]
name: set2 [11305,11309]
===
match
---
number: 1 [67728,67729]
number: 1 [69352,69353]
===
match
---
trailer [40201,40204]
trailer [40232,40235]
===
match
---
string: 'Europe/Zurich' [24397,24412]
string: 'Europe/Zurich' [24428,24443]
===
match
---
operator: , [17268,17269]
operator: , [17299,17300]
===
match
---
trailer [53608,53615]
trailer [53639,53646]
===
match
---
operator: , [34251,34252]
operator: , [34282,34283]
===
match
---
atom [27903,28022]
atom [27934,28053]
===
match
---
arglist [23484,23541]
arglist [23515,23572]
===
match
---
operator: = [54711,54712]
operator: = [54742,54743]
===
match
---
comparison [49212,49234]
comparison [49243,49265]
===
match
---
trailer [34995,35002]
trailer [35026,35033]
===
match
---
name: pendulum [78948,78956]
name: pendulum [80572,80580]
===
match
---
operator: = [39453,39454]
operator: = [39484,39485]
===
match
---
name: DummyOperator [56243,56256]
name: DummyOperator [56274,56287]
===
match
---
name: task_id [39801,39808]
name: task_id [39832,39839]
===
match
---
atom_expr [39112,39126]
atom_expr [39143,39157]
===
match
---
name: DAG [27482,27485]
name: DAG [27513,27516]
===
match
---
name: DAG [17608,17611]
name: DAG [17639,17642]
===
match
---
name: session [30320,30327]
name: session [30351,30358]
===
match
---
trailer [29452,29469]
trailer [29483,29500]
===
match
---
name: outdated_permissions [65994,66014]
name: outdated_permissions [67618,67638]
===
match
---
operator: = [62714,62715]
operator: = [62745,62746]
===
match
---
name: Session [32595,32602]
name: Session [32626,32633]
===
match
---
name: dag [56274,56277]
name: dag [56305,56308]
===
match
---
dotted_name [54233,54253]
dotted_name [54264,54284]
===
match
---
assert_stmt [25768,25823]
assert_stmt [25799,25854]
===
match
---
trailer [36175,36177]
trailer [36206,36208]
===
match
---
name: dag [51983,51986]
name: dag [52014,52017]
===
match
---
assert_stmt [79057,79096]
assert_stmt [80681,80720]
===
match
---
trailer [53795,53802]
trailer [53826,53833]
===
match
---
name: pattern [13346,13353]
name: pattern [13377,13384]
===
match
---
name: dag [75693,75696]
name: dag [77317,77320]
===
match
---
trailer [74876,74879]
trailer [76500,76503]
===
match
---
name: microsecond [59732,59743]
name: microsecond [59763,59774]
===
match
---
name: task_id [41499,41506]
name: task_id [41530,41537]
===
match
---
name: dag [64983,64986]
name: dag [66607,66610]
===
match
---
name: configuration [1350,1363]
name: configuration [1356,1369]
===
match
---
operator: , [25584,25585]
operator: , [25615,25616]
===
match
---
string: "test_dag" [39254,39264]
string: "test_dag" [39285,39295]
===
match
---
trailer [56712,56718]
trailer [56743,56749]
===
match
---
arglist [54857,54864]
arglist [54888,54895]
===
match
---
trailer [67478,67486]
trailer [69102,69110]
===
match
---
atom_expr [3366,3375]
atom_expr [3397,3406]
===
match
---
operator: , [56183,56184]
operator: , [56214,56215]
===
match
---
argument [42023,42035]
argument [42054,42066]
===
match
---
string: 'dag-bulk-sync-1' [28586,28603]
string: 'dag-bulk-sync-1' [28617,28634]
===
match
---
name: datetime [63228,63236]
name: datetime [63259,63267]
===
match
---
simple_stmt [31249,31286]
simple_stmt [31280,31317]
===
match
---
name: test_not_none_schedule_with_non_default_params [4883,4929]
name: test_not_none_schedule_with_non_default_params [4914,4960]
===
match
---
argument [70379,70391]
argument [72003,72015]
===
match
---
operator: = [37786,37787]
operator: = [37817,37818]
===
match
---
string: 'DAG' [12391,12396]
string: 'DAG' [12422,12427]
===
match
---
atom_expr [10429,10455]
atom_expr [10460,10486]
===
match
---
name: self [8900,8904]
name: self [8931,8935]
===
match
---
argument [12884,12924]
argument [12915,12955]
===
match
---
trailer [18650,18655]
trailer [18681,18686]
===
match
---
atom_expr [26284,26300]
atom_expr [26315,26331]
===
match
---
operator: = [27108,27109]
operator: = [27139,27140]
===
match
---
atom_expr [54466,54497]
atom_expr [54497,54528]
===
match
---
comparison [54975,55004]
comparison [55006,55035]
===
match
---
import_name [1131,1144]
import_name [1137,1150]
===
match
---
name: session [55298,55305]
name: session [55329,55336]
===
match
---
name: value [73046,73051]
name: value [74670,74675]
===
match
---
name: creating_job_id [51506,51521]
name: creating_job_id [51537,51552]
===
match
---
trailer [32677,32687]
trailer [32708,32718]
===
match
---
suite [36927,37325]
suite [36958,37356]
===
match
---
operator: = [21659,21660]
operator: = [21690,21691]
===
match
---
comparison [76886,76912]
comparison [78510,78536]
===
match
---
operator: , [61583,61584]
operator: , [61614,61615]
===
match
---
atom_expr [20350,20381]
atom_expr [20381,20412]
===
match
---
atom_expr [69656,69668]
atom_expr [71280,71292]
===
match
---
simple_stmt [42530,42576]
simple_stmt [42561,42607]
===
match
---
number: 1 [50272,50273]
number: 1 [50303,50304]
===
match
---
expr_stmt [56144,56158]
expr_stmt [56175,56189]
===
match
---
name: self [5625,5629]
name: self [5656,5660]
===
match
---
name: op3 [38922,38925]
name: op3 [38953,38956]
===
match
---
name: dag2 [60536,60540]
name: dag2 [60567,60571]
===
match
---
atom_expr [9950,9969]
atom_expr [9981,10000]
===
match
---
trailer [60117,60134]
trailer [60148,60165]
===
match
---
trailer [36235,36279]
trailer [36266,36310]
===
match
---
string: """         Test that when 'params' is _not_ passed to a new Dag, that the params         attribute is set to an empty dictionary.         """ [3952,4094]
string: """         Test that when 'params' is _not_ passed to a new Dag, that the params         attribute is set to an empty dictionary.         """ [3983,4125]
===
match
---
argument [10253,10276]
argument [10284,10307]
===
match
---
name: orm_dag [38025,38032]
name: orm_dag [38056,38063]
===
match
---
string: 't1' [41939,41943]
string: 't1' [41970,41974]
===
match
---
parameters [6485,6491]
parameters [6516,6522]
===
match
---
number: 0 [16523,16524]
number: 0 [16554,16555]
===
match
---
name: topological_sort [9794,9810]
name: topological_sort [9825,9841]
===
match
---
atom_expr [30079,30102]
atom_expr [30110,30133]
===
match
---
trailer [6907,6922]
trailer [6938,6953]
===
match
---
arglist [17691,17725]
arglist [17722,17756]
===
match
---
atom_expr [20824,20844]
atom_expr [20855,20875]
===
match
---
trailer [59158,59365]
trailer [59189,59396]
===
match
---
operator: == [57570,57572]
operator: == [57601,57603]
===
match
---
trailer [2775,2777]
trailer [2806,2808]
===
match
---
atom_expr [53742,53952]
atom_expr [53773,53983]
===
match
---
name: enumerate [16634,16643]
name: enumerate [16665,16674]
===
match
---
assert_stmt [49243,49275]
assert_stmt [49274,49306]
===
match
---
argument [31012,31058]
argument [31043,31089]
===
match
---
trailer [56773,56779]
trailer [56804,56810]
===
match
---
trailer [77406,77422]
trailer [79030,79046]
===
match
---
simple_stmt [33837,33866]
simple_stmt [33868,33897]
===
match
---
name: delete [3491,3497]
name: delete [3522,3528]
===
match
---
string: """         Tests if fractional seconds are stored in the database         """ [46591,46669]
string: """         Tests if fractional seconds are stored in the database         """ [46622,46700]
===
match
---
name: session [31755,31762]
name: session [31786,31793]
===
match
---
arglist [68145,68186]
arglist [69769,69810]
===
match
---
arglist [68266,68432]
arglist [69890,70056]
===
match
---
name: self [6486,6490]
name: self [6517,6521]
===
match
---
testlist_comp [29676,29706]
testlist_comp [29707,29737]
===
match
---
name: get_ti_from_db [76562,76576]
name: get_ti_from_db [78186,78200]
===
match
---
simple_stmt [70001,70017]
simple_stmt [71625,71641]
===
match
---
trailer [62032,62041]
trailer [62063,62072]
===
match
---
trailer [56872,56880]
trailer [56903,56911]
===
match
---
operator: + [45525,45526]
operator: + [45556,45557]
===
match
---
testlist_comp [55110,55124]
testlist_comp [55141,55155]
===
match
---
trailer [33855,33863]
trailer [33886,33894]
===
match
---
trailer [60769,60771]
trailer [60800,60802]
===
match
---
operator: = [76543,76544]
operator: = [78167,78168]
===
match
---
trailer [49216,49221]
trailer [49247,49252]
===
match
---
operator: = [43706,43707]
operator: = [43737,43738]
===
match
---
name: schedule_interval [22512,22529]
name: schedule_interval [22543,22560]
===
match
---
expr_stmt [32049,32125]
expr_stmt [32080,32156]
===
match
---
name: DAG [6701,6704]
name: DAG [6732,6735]
===
match
---
simple_stmt [13190,13231]
simple_stmt [13221,13262]
===
match
---
operator: = [31490,31491]
operator: = [31521,31522]
===
match
---
name: DAG [34438,34441]
name: DAG [34469,34472]
===
match
---
name: session [18664,18671]
name: session [18695,18702]
===
match
---
expr_stmt [24649,24682]
expr_stmt [24680,24713]
===
match
---
name: DAG [13136,13139]
name: DAG [13167,13170]
===
match
---
operator: = [26636,26637]
operator: = [26667,26668]
===
match
---
expr_stmt [40576,40609]
expr_stmt [40607,40640]
===
match
---
name: delta [58021,58026]
name: delta [58052,58057]
===
match
---
funcdef [2676,2778]
funcdef [2707,2809]
===
match
---
trailer [67890,67892]
trailer [69514,69516]
===
match
---
name: data_interval [63149,63162]
name: data_interval [63180,63193]
===
match
---
dictorsetmaker [47471,47517]
dictorsetmaker [47502,47548]
===
match
---
trailer [61953,61967]
trailer [61984,61998]
===
match
---
name: delta [25604,25609]
name: delta [25635,25640]
===
match
---
number: 1 [70798,70799]
number: 1 [72422,72423]
===
match
---
name: dag_id [34996,35002]
name: dag_id [35027,35033]
===
match
---
operator: = [17444,17445]
operator: = [17475,17476]
===
match
---
not_test [36193,36216]
not_test [36224,36247]
===
match
---
name: dag_id [47379,47385]
name: dag_id [47410,47416]
===
match
---
operator: , [78603,78604]
operator: , [80227,80228]
===
match
---
atom_expr [70824,70844]
atom_expr [72448,72468]
===
match
---
name: task [18352,18356]
name: task [18383,18387]
===
match
---
name: test_dag_is_deactivated_upon_dagfile_deletion [37334,37379]
name: test_dag_is_deactivated_upon_dagfile_deletion [37365,37410]
===
match
---
operator: , [19370,19371]
operator: , [19401,19402]
===
match
---
trailer [54027,54035]
trailer [54058,54066]
===
match
---
name: DummyOperator [75911,75924]
name: DummyOperator [77535,77548]
===
match
---
trailer [60557,60563]
trailer [60588,60594]
===
match
---
name: test_schedule_dag_once [45574,45596]
name: test_schedule_dag_once [45605,45627]
===
match
---
fstring_expr [64951,64967]
fstring_expr [66575,66591]
===
match
---
comparison [3750,3764]
comparison [3781,3795]
===
match
---
string: 'airflow.models.dag.DagCode.bulk_sync_to_db' [37678,37722]
string: 'airflow.models.dag.DagCode.bulk_sync_to_db' [37709,37753]
===
match
---
number: 1 [61581,61582]
number: 1 [61612,61613]
===
match
---
name: utils [2210,2215]
name: utils [2241,2246]
===
match
---
atom [49689,49697]
atom [49720,49728]
===
match
---
atom_expr [2794,2811]
atom_expr [2825,2842]
===
match
---
trailer [32694,32720]
trailer [32725,32751]
===
match
---
name: op9 [8019,8022]
name: op9 [8050,8053]
===
match
---
string: 'test_scheduler_auto_align_1' [63609,63638]
string: 'test_scheduler_auto_align_1' [65233,65262]
===
match
---
comparison [76199,76222]
comparison [77823,77846]
===
match
---
trailer [71647,71650]
trailer [73271,73274]
===
match
---
name: dag [59468,59471]
name: dag [59499,59502]
===
match
---
arith_expr [59656,59689]
arith_expr [59687,59720]
===
match
---
operator: == [51064,51066]
operator: == [51095,51097]
===
match
---
name: sync_to_db [36607,36617]
name: sync_to_db [36638,36648]
===
match
---
name: dag [72064,72067]
name: dag [73688,73691]
===
match
---
expr_stmt [47706,47746]
expr_stmt [47737,47777]
===
match
---
name: run_id [18368,18374]
name: run_id [18399,18405]
===
match
---
name: Param [66914,66919]
name: Param [68538,68543]
===
match
---
name: dag_id [68041,68047]
name: dag_id [69665,69671]
===
match
---
operator: * [14422,14423]
operator: * [14453,14454]
===
match
---
funcdef [49376,49845]
funcdef [49407,49876]
===
match
---
atom [36014,36031]
atom [36045,36062]
===
match
---
comparison [7469,7490]
comparison [7500,7521]
===
match
---
string: 'role2' [66112,66119]
string: 'role2' [67736,67743]
===
match
---
trailer [76430,76436]
trailer [78054,78060]
===
match
---
name: task_id [6955,6962]
name: task_id [6986,6993]
===
match
---
string: '@daily' [8444,8452]
string: '@daily' [8475,8483]
===
match
---
suite [68022,68600]
suite [69646,70224]
===
match
---
operator: = [18059,18060]
operator: = [18090,18091]
===
match
---
atom_expr [42617,42706]
atom_expr [42648,42737]
===
match
---
atom_expr [47590,47602]
atom_expr [47621,47633]
===
match
---
with_stmt [30151,30776]
with_stmt [30182,30807]
===
match
---
name: task_instance_1 [52209,52224]
name: task_instance_1 [52240,52255]
===
match
---
atom_expr [31303,31345]
atom_expr [31334,31376]
===
match
---
name: interval [58418,58426]
name: interval [58449,58457]
===
match
---
atom_expr [49618,49655]
atom_expr [49649,49686]
===
match
---
name: remove [30047,30053]
name: remove [30078,30084]
===
match
---
operator: , [38583,38584]
operator: , [38614,38615]
===
match
---
operator: { [70678,70679]
operator: { [72302,72303]
===
match
---
atom_expr [5849,5865]
atom_expr [5880,5896]
===
match
---
operator: , [8452,8453]
operator: , [8483,8484]
===
match
---
operator: = [22432,22433]
operator: = [22463,22464]
===
match
---
atom_expr [18407,18420]
atom_expr [18438,18451]
===
match
---
expr_stmt [19749,19940]
expr_stmt [19780,19971]
===
match
---
operator: = [55523,55524]
operator: = [55554,55555]
===
match
---
atom_expr [50217,50232]
atom_expr [50248,50263]
===
match
---
parameters [61266,61272]
parameters [61297,61303]
===
match
---
with_stmt [7125,7183]
with_stmt [7156,7214]
===
match
---
suite [13282,14567]
suite [13313,14598]
===
match
---
argument [21649,21672]
argument [21680,21703]
===
match
---
operator: , [58973,58974]
operator: , [59004,59005]
===
match
---
arglist [33429,33506]
arglist [33460,33537]
===
match
---
operator: { [10291,10292]
operator: { [10322,10323]
===
match
---
fstring_expr [43154,43178]
fstring_expr [43185,43209]
===
match
---
name: orm_dag [32846,32853]
name: orm_dag [32877,32884]
===
match
---
atom [27881,27899]
atom [27912,27930]
===
match
---
simple_stmt [71235,71263]
simple_stmt [72859,72887]
===
match
---
argument [37004,37033]
argument [37035,37064]
===
match
---
operator: == [52919,52921]
operator: == [52950,52952]
===
match
---
number: 0 [15253,15254]
number: 0 [15284,15285]
===
match
---
string: 'dag_paused' [36236,36248]
string: 'dag_paused' [36267,36279]
===
match
---
number: 2015 [57591,57595]
number: 2015 [57622,57626]
===
match
---
comparison [77535,77625]
comparison [79159,79249]
===
match
---
operator: = [79040,79041]
operator: = [80664,80665]
===
match
---
atom [77742,77821]
atom [79366,79445]
===
match
---
string: 'test' [71467,71473]
string: 'test' [73091,73097]
===
match
---
trailer [52871,52874]
trailer [52902,52905]
===
match
---
trailer [30041,30046]
trailer [30072,30077]
===
match
---
trailer [73635,73649]
trailer [75259,75273]
===
match
---
atom_expr [68451,68471]
atom_expr [70075,70095]
===
match
---
trailer [15193,15203]
trailer [15224,15234]
===
match
---
name: DEFAULT_DATE [77856,77868]
name: DEFAULT_DATE [79480,79492]
===
match
---
trailer [58748,58754]
trailer [58779,58785]
===
match
---
decorated [3141,3525]
decorated [3172,3556]
===
match
---
name: i [15345,15346]
name: i [15376,15377]
===
match
---
operator: = [41086,41087]
operator: = [41117,41118]
===
match
---
parameters [43399,43417]
parameters [43430,43448]
===
match
---
expr_stmt [76457,76509]
expr_stmt [78081,78133]
===
match
---
trailer [13919,13929]
trailer [13950,13960]
===
match
---
simple_stmt [76612,76628]
simple_stmt [78236,78252]
===
match
---
operator: @ [71452,71453]
operator: @ [73076,73077]
===
match
---
trailer [27607,27617]
trailer [27638,27648]
===
match
---
simple_stmt [69193,69209]
simple_stmt [70817,70833]
===
match
---
trailer [35879,35886]
trailer [35910,35917]
===
match
---
atom_expr [53279,53333]
atom_expr [53310,53364]
===
match
---
operator: { [16355,16356]
operator: { [16386,16387]
===
match
---
simple_stmt [3083,3099]
simple_stmt [3114,3130]
===
match
---
atom_expr [37635,37653]
atom_expr [37666,37684]
===
match
---
operator: , [62046,62047]
operator: , [62077,62078]
===
match
---
comparison [12593,12669]
comparison [12624,12700]
===
match
---
trailer [35805,35812]
trailer [35836,35843]
===
match
---
operator: = [70493,70494]
operator: = [72117,72118]
===
match
---
name: all [69426,69429]
name: all [71050,71053]
===
match
---
name: DEFAULT_DATE [51839,51851]
name: DEFAULT_DATE [51870,51882]
===
match
---
dotted_name [2136,2157]
dotted_name [2167,2188]
===
match
---
name: state [53597,53602]
name: state [53628,53633]
===
match
---
trailer [18759,18761]
trailer [18790,18792]
===
match
---
operator: , [37295,37296]
operator: , [37326,37327]
===
match
---
argument [5438,5494]
argument [5469,5525]
===
match
---
name: orm_subdag [33194,33204]
name: orm_subdag [33225,33235]
===
match
---
name: session [68584,68591]
name: session [70208,70215]
===
match
---
trailer [21606,21614]
trailer [21637,21645]
===
match
---
operator: , [16190,16191]
operator: , [16221,16222]
===
match
---
name: DAG [13618,13621]
name: DAG [13649,13652]
===
match
---
name: range [16517,16522]
name: range [16548,16553]
===
match
---
trailer [47933,47965]
trailer [47964,47996]
===
match
---
simple_stmt [41192,41203]
simple_stmt [41223,41234]
===
match
---
name: DEFAULT_DATE [74826,74838]
name: DEFAULT_DATE [76450,76462]
===
match
---
name: query [56969,56974]
name: query [57000,57005]
===
match
---
simple_stmt [20824,20845]
simple_stmt [20855,20876]
===
match
---
name: execution_date [43163,43177]
name: execution_date [43194,43208]
===
match
---
name: DEFAULT_ARGS [72321,72333]
name: DEFAULT_ARGS [73945,73957]
===
match
---
name: task [16886,16890]
name: task [16917,16921]
===
match
---
name: subdag [65454,65460]
name: subdag [67078,67084]
===
match
---
operator: == [51522,51524]
operator: == [51553,51555]
===
match
---
name: dr [73627,73629]
name: dr [75251,75253]
===
match
---
name: self [57750,57754]
name: self [57781,57785]
===
match
---
name: dag [16229,16232]
name: dag [16260,16263]
===
match
---
simple_stmt [59379,59422]
simple_stmt [59410,59453]
===
match
---
atom_expr [73670,73693]
atom_expr [75294,75317]
===
match
---
trailer [28104,28170]
trailer [28135,28201]
===
match
---
with_stmt [5401,5580]
with_stmt [5432,5611]
===
match
---
name: self [54385,54389]
name: self [54416,54420]
===
match
---
name: TaskFail [3464,3472]
name: TaskFail [3495,3503]
===
match
---
number: 2015 [2640,2644]
number: 2015 [2671,2675]
===
match
---
operator: - [59787,59788]
operator: - [59818,59819]
===
match
---
name: dag_subclass [48110,48122]
name: dag_subclass [48141,48153]
===
match
---
trailer [35414,35421]
trailer [35445,35452]
===
match
---
trailer [15679,15685]
trailer [15710,15716]
===
match
---
name: dag [20194,20197]
name: dag [20225,20228]
===
match
---
name: State [77382,77387]
name: State [79006,79011]
===
match
---
arglist [59509,59530]
arglist [59540,59561]
===
match
---
comparison [62639,62694]
comparison [62670,62725]
===
match
---
operator: = [75834,75835]
operator: = [77458,77459]
===
match
---
funcdef [71072,71345]
funcdef [72696,72969]
===
match
---
name: DEFAULT_DATE [52250,52262]
name: DEFAULT_DATE [52281,52293]
===
match
---
simple_stmt [25879,25935]
simple_stmt [25910,25966]
===
match
---
atom_expr [62889,62912]
atom_expr [62920,62943]
===
match
---
name: dag [4784,4787]
name: dag [4815,4818]
===
match
---
operator: { [66903,66904]
operator: { [68527,68528]
===
match
---
name: previous_schedule [26244,26261]
name: previous_schedule [26275,26292]
===
match
---
name: when [44012,44016]
name: when [44043,44047]
===
match
---
operator: , [76222,76223]
operator: , [77846,77847]
===
match
---
atom_expr [47302,47316]
atom_expr [47333,47347]
===
match
---
number: 3 [27439,27440]
number: 3 [27470,27471]
===
match
---
atom_expr [16517,16532]
atom_expr [16548,16563]
===
match
---
name: _ [60532,60533]
name: _ [60563,60564]
===
match
---
name: State [53603,53608]
name: State [53634,53639]
===
match
---
argument [17295,17327]
argument [17326,17358]
===
match
---
atom_expr [28881,28887]
atom_expr [28912,28918]
===
match
---
name: test_sync_to_db [32018,32033]
name: test_sync_to_db [32049,32064]
===
match
---
operator: == [3760,3762]
operator: == [3791,3793]
===
match
---
operator: , [1326,1327]
operator: , [1332,1333]
===
match
---
operator: , [17630,17631]
operator: , [17661,17662]
===
match
---
string: 'owner1' [14886,14894]
string: 'owner1' [14917,14925]
===
match
---
name: self [75074,75078]
name: self [76698,76702]
===
match
---
simple_stmt [75217,75228]
simple_stmt [76841,76852]
===
match
---
arglist [53776,53942]
arglist [53807,53973]
===
match
---
operator: , [42786,42787]
operator: , [42817,42818]
===
match
---
name: ti1 [76983,76986]
name: ti1 [78607,78610]
===
match
---
atom_expr [76254,76266]
atom_expr [77878,77890]
===
match
---
name: create_dagrun [73636,73649]
name: create_dagrun [75260,75273]
===
match
---
string: ', ' [33148,33152]
string: ', ' [33179,33183]
===
match
---
atom_expr [38974,39001]
atom_expr [39005,39032]
===
match
---
parameters [26789,26795]
parameters [26820,26826]
===
match
---
param [32034,32038]
param [32065,32069]
===
match
---
trailer [20911,20916]
trailer [20942,20947]
===
match
---
trailer [23889,23891]
trailer [23920,23922]
===
match
---
name: f [21554,21555]
name: f [21585,21586]
===
match
---
simple_stmt [39495,39529]
simple_stmt [39526,39560]
===
match
---
simple_stmt [64273,64358]
simple_stmt [65897,65982]
===
match
---
name: timezone [38344,38352]
name: timezone [38375,38383]
===
match
---
trailer [24446,24515]
trailer [24477,24546]
===
match
---
operator: , [23379,23380]
operator: , [23410,23411]
===
match
---
trailer [48352,48364]
trailer [48383,48395]
===
match
---
parameters [63291,63297]
parameters [64915,64921]
===
match
---
simple_stmt [53489,53518]
simple_stmt [53520,53549]
===
match
---
simple_stmt [46591,46670]
simple_stmt [46622,46701]
===
match
---
operator: } [40760,40761]
operator: } [40791,40792]
===
match
---
name: next_date [60980,60989]
name: next_date [61011,61020]
===
match
---
operator: = [3413,3414]
operator: = [3444,3445]
===
match
---
name: dag [4201,4204]
name: dag [4232,4235]
===
match
---
atom_expr [2875,2890]
atom_expr [2906,2921]
===
match
---
name: start_date [52381,52391]
name: start_date [52412,52422]
===
match
---
atom_expr [15565,15587]
atom_expr [15596,15618]
===
match
---
operator: { [43154,43155]
operator: { [43185,43186]
===
match
---
operator: = [58104,58105]
operator: = [58135,58136]
===
match
---
argument [49818,49843]
argument [49849,49874]
===
match
---
number: 0 [28434,28435]
number: 0 [28465,28466]
===
match
---
operator: = [60025,60026]
operator: = [60056,60057]
===
match
---
name: task_id [10443,10450]
name: task_id [10474,10481]
===
match
---
atom_expr [48202,48251]
atom_expr [48233,48282]
===
match
---
comparison [31966,32008]
comparison [31997,32039]
===
match
---
name: priority_weight [13777,13792]
name: priority_weight [13808,13823]
===
match
---
name: t_1 [51880,51883]
name: t_1 [51911,51914]
===
match
---
simple_stmt [1300,1337]
simple_stmt [1306,1343]
===
match
---
operator: = [10540,10541]
operator: = [10571,10572]
===
match
---
funcdef [36886,37325]
funcdef [36917,37356]
===
match
---
operator: , [51152,51153]
operator: , [51183,51184]
===
match
---
operator: < [48934,48935]
operator: < [48965,48966]
===
match
---
atom_expr [22561,22588]
atom_expr [22592,22619]
===
match
---
operator: = [14741,14742]
operator: = [14772,14773]
===
match
---
operator: = [47133,47134]
operator: = [47164,47165]
===
match
---
operator: , [55093,55094]
operator: , [55124,55125]
===
match
---
string: '2019-06-01' [11607,11619]
string: '2019-06-01' [11638,11650]
===
match
---
simple_stmt [19307,19444]
simple_stmt [19338,19475]
===
match
---
trailer [65047,65238]
trailer [66671,66862]
===
match
---
trailer [8121,8245]
trailer [8152,8276]
===
match
---
name: model [31747,31752]
name: model [31778,31783]
===
match
---
name: DAG [36232,36235]
name: DAG [36263,36266]
===
match
---
for_stmt [15289,15540]
for_stmt [15320,15571]
===
match
---
trailer [54981,54987]
trailer [55012,55018]
===
match
---
name: test_dag_id [47425,47436]
name: test_dag_id [47456,47467]
===
match
---
name: start [24555,24560]
name: start [24586,24591]
===
match
---
atom_expr [34699,34716]
atom_expr [34730,34747]
===
match
---
expr_stmt [21130,21161]
expr_stmt [21161,21192]
===
match
---
name: dag_id [56079,56085]
name: dag_id [56110,56116]
===
match
---
arglist [21637,21706]
arglist [21668,21737]
===
match
---
name: test_utils [2435,2445]
name: test_utils [2466,2476]
===
match
---
argument [78811,78838]
argument [80435,80462]
===
match
---
assert_stmt [26676,26730]
assert_stmt [26707,26761]
===
match
---
operator: == [22349,22351]
operator: == [22380,22382]
===
match
---
atom [9869,9884]
atom [9900,9915]
===
match
---
atom_expr [24003,24031]
atom_expr [24034,24062]
===
match
---
name: task_id [7815,7822]
name: task_id [7846,7853]
===
match
---
trailer [11145,11148]
trailer [11176,11179]
===
match
---
operator: , [42125,42126]
operator: , [42156,42157]
===
match
---
name: updated_permissions [66229,66248]
name: updated_permissions [67853,67872]
===
match
---
trailer [8341,8360]
trailer [8372,8391]
===
match
---
argument [75778,75794]
argument [77402,77418]
===
match
---
operator: = [7384,7385]
operator: = [7415,7416]
===
match
---
operator: , [26108,26109]
operator: , [26139,26140]
===
match
---
testlist_comp [14946,15262]
testlist_comp [14977,15293]
===
match
---
name: bulk_write_to_db [31714,31730]
name: bulk_write_to_db [31745,31761]
===
match
---
name: orm_dag [68911,68918]
name: orm_dag [70535,70542]
===
match
---
name: DAG [20552,20555]
name: DAG [20583,20586]
===
match
---
atom_expr [52358,52621]
atom_expr [52389,52652]
===
match
---
operator: = [64717,64718]
operator: = [66341,66342]
===
match
---
operator: , [63241,63242]
operator: , [63272,63273]
===
match
---
operator: , [15135,15136]
operator: , [15166,15167]
===
match
---
name: one [54944,54947]
name: one [54975,54978]
===
match
---
expr_stmt [54452,54497]
expr_stmt [54483,54528]
===
match
---
trailer [43946,44018]
trailer [43977,44049]
===
match
---
atom_expr [64055,64095]
atom_expr [65679,65719]
===
match
---
name: self [33391,33395]
name: self [33422,33426]
===
match
---
operator: , [6735,6736]
operator: , [6766,6767]
===
match
---
simple_stmt [4591,4619]
simple_stmt [4622,4650]
===
match
---
name: merge [52301,52306]
name: merge [52332,52337]
===
match
---
trailer [46297,46308]
trailer [46328,46339]
===
match
---
name: template_dir [20879,20891]
name: template_dir [20910,20922]
===
match
---
operator: = [64000,64001]
operator: = [65624,65625]
===
match
---
name: dag [43278,43281]
name: dag [43309,43312]
===
match
---
name: weight [15816,15822]
name: weight [15847,15853]
===
match
---
name: DAGsubclass [48202,48213]
name: DAGsubclass [48233,48244]
===
match
---
atom_expr [33230,33252]
atom_expr [33261,33283]
===
match
---
string: '2019-06-05T00:00:00' [12467,12488]
string: '2019-06-05T00:00:00' [12498,12519]
===
match
---
operator: , [28150,28151]
operator: , [28181,28182]
===
match
---
operator: , [29743,29744]
operator: , [29774,29775]
===
match
---
name: one [55752,55755]
name: one [55783,55786]
===
match
---
comparison [33230,33275]
comparison [33261,33306]
===
match
---
name: cron_timetable [50165,50179]
name: cron_timetable [50196,50210]
===
match
---
name: task_id [53162,53169]
name: task_id [53193,53200]
===
match
---
name: start_date [33771,33781]
name: start_date [33802,33812]
===
match
---
name: value [73688,73693]
name: value [75312,75317]
===
match
---
operator: = [59892,59893]
operator: = [59923,59924]
===
match
---
trailer [34986,35023]
trailer [35017,35054]
===
match
---
argument [73707,73735]
argument [75331,75359]
===
match
---
name: flush [20859,20864]
name: flush [20890,20895]
===
match
---
atom [56947,57110]
atom [56978,57141]
===
match
---
name: subdag_id [35892,35901]
name: subdag_id [35923,35932]
===
match
---
trailer [38096,38098]
trailer [38127,38129]
===
match
---
arglist [46731,46771]
arglist [46762,46802]
===
match
---
atom_expr [44405,44416]
atom_expr [44436,44447]
===
match
---
trailer [20858,20864]
trailer [20889,20895]
===
match
---
name: dagrun_1 [52190,52198]
name: dagrun_1 [52221,52229]
===
match
---
trailer [55945,55953]
trailer [55976,55984]
===
match
---
classdef [67226,69924]
classdef [68850,71548]
===
match
---
operator: = [8188,8189]
operator: = [8219,8220]
===
match
---
arglist [41102,41123]
arglist [41133,41154]
===
match
---
atom_expr [10648,10671]
atom_expr [10679,10702]
===
match
---
atom_expr [56550,56573]
atom_expr [56581,56604]
===
match
---
name: dag [59413,59416]
name: dag [59444,59447]
===
match
---
trailer [28854,28856]
trailer [28885,28887]
===
match
---
param [25985,25989]
param [26016,26020]
===
match
---
name: session [18600,18607]
name: session [18631,18638]
===
match
---
simple_stmt [1587,1640]
simple_stmt [1593,1646]
===
match
---
name: DEFAULT_DATE [13640,13652]
name: DEFAULT_DATE [13671,13683]
===
match
---
argument [10533,10544]
argument [10564,10575]
===
match
---
string: """         Test `orientation` default value of DAG initialization         """ [6235,6313]
string: """         Test `orientation` default value of DAG initialization         """ [6266,6344]
===
match
---
name: test_dag_id [47934,47945]
name: test_dag_id [47965,47976]
===
match
---
name: datetime [52442,52450]
name: datetime [52473,52481]
===
match
---
simple_stmt [73035,73053]
simple_stmt [74659,74677]
===
match
---
atom_expr [53348,53389]
atom_expr [53379,53420]
===
match
---
operator: = [46814,46815]
operator: = [46845,46846]
===
match
---
atom_expr [76212,76222]
atom_expr [77836,77846]
===
match
---
string: 'task_1' [17579,17587]
string: 'task_1' [17610,17618]
===
match
---
trailer [67363,67372]
trailer [68987,68996]
===
match
---
operator: , [24607,24608]
operator: , [24638,24639]
===
match
---
fstring_end: " [50835,50836]
fstring_end: " [50866,50867]
===
match
---
funcdef [50567,50837]
funcdef [50598,50868]
===
match
---
atom_expr [50786,50795]
atom_expr [50817,50826]
===
match
---
simple_stmt [14735,14745]
simple_stmt [14766,14776]
===
match
---
atom [50039,50080]
atom [50070,50111]
===
match
---
funcdef [27257,27319]
funcdef [27288,27350]
===
match
---
dictorsetmaker [77536,77558]
dictorsetmaker [79160,79182]
===
match
---
param [5625,5629]
param [5656,5660]
===
match
---
operator: , [27191,27192]
operator: , [27222,27223]
===
match
---
name: session [3341,3348]
name: session [3372,3379]
===
match
---
name: dag [62583,62586]
name: dag [62614,62617]
===
match
---
atom_expr [69387,69431]
atom_expr [71011,71055]
===
match
---
operator: = [21436,21437]
operator: = [21467,21468]
===
match
---
assert_stmt [36186,36216]
assert_stmt [36217,36247]
===
match
---
name: owner [25667,25672]
name: owner [25698,25703]
===
match
---
simple_stmt [65774,65823]
simple_stmt [67398,67447]
===
match
---
trailer [68754,68799]
trailer [70378,70423]
===
match
---
operator: = [69139,69140]
operator: = [70763,70764]
===
match
---
name: prev_task [16778,16787]
name: prev_task [16809,16818]
===
match
---
name: DAG [31008,31011]
name: DAG [31039,31042]
===
match
---
atom_expr [13618,13687]
atom_expr [13649,13718]
===
match
---
operator: = [78767,78768]
operator: = [80391,80392]
===
match
---
atom_expr [5145,5165]
atom_expr [5176,5196]
===
match
---
name: DAG [6786,6789]
name: DAG [6817,6820]
===
match
---
trailer [33350,33352]
trailer [33381,33383]
===
match
---
operator: = [74433,74434]
operator: = [76057,76058]
===
match
---
name: isoformat [22337,22346]
name: isoformat [22368,22377]
===
match
---
name: state [73795,73800]
name: state [75419,75424]
===
match
---
comparison [35581,35672]
comparison [35612,35703]
===
match
---
argument [69109,69115]
argument [70733,70739]
===
match
---
argument [39377,39389]
argument [39408,39420]
===
match
---
operator: = [8706,8707]
operator: = [8737,8738]
===
match
---
argument [36618,36633]
argument [36649,36664]
===
match
---
name: utc [26543,26546]
name: utc [26574,26577]
===
match
---
name: start_date [53090,53100]
name: start_date [53121,53131]
===
match
---
operator: = [61690,61691]
operator: = [61721,61722]
===
match
---
atom_expr [11396,11465]
atom_expr [11427,11496]
===
match
---
operator: } [6854,6855]
operator: } [6885,6886]
===
match
---
operator: = [32635,32636]
operator: = [32666,32667]
===
match
---
operator: , [68360,68361]
operator: , [69984,69985]
===
match
---
argument [78987,79025]
argument [80611,80649]
===
match
---
assert_stmt [30383,30661]
assert_stmt [30414,30692]
===
match
---
suite [2690,2778]
suite [2721,2809]
===
match
---
operator: = [46011,46012]
operator: = [46042,46043]
===
match
---
operator: = [44886,44887]
operator: = [44917,44918]
===
match
---
simple_stmt [42453,42522]
simple_stmt [42484,42553]
===
match
---
trailer [35703,35715]
trailer [35734,35746]
===
match
---
name: AirflowException [17361,17377]
name: AirflowException [17392,17408]
===
match
---
name: DagModel [36995,37003]
name: DagModel [37026,37034]
===
match
---
operator: = [18347,18348]
operator: = [18378,18379]
===
match
---
name: set1 [11060,11064]
name: set1 [11091,11095]
===
match
---
simple_stmt [39541,39573]
simple_stmt [39572,39604]
===
match
---
name: states [19388,19394]
name: states [19419,19425]
===
match
---
param [75121,75137]
param [76745,76761]
===
match
---
simple_stmt [67309,67386]
simple_stmt [68933,69010]
===
match
---
name: DummyOperator [41088,41101]
name: DummyOperator [41119,41132]
===
match
---
trailer [76374,76382]
trailer [77998,78006]
===
match
---
operator: = [76389,76390]
operator: = [78013,78014]
===
match
---
funcdef [67982,68600]
funcdef [69606,70224]
===
match
---
arglist [34455,34499]
arglist [34486,34530]
===
match
---
name: dag [64238,64241]
name: dag [65862,65865]
===
match
---
name: self [75387,75391]
name: self [77011,77015]
===
match
---
atom [69611,69669]
atom [71235,71293]
===
match
---
name: task_id [33561,33568]
name: task_id [33592,33599]
===
match
---
operator: , [27448,27449]
operator: , [27479,27480]
===
match
---
trailer [56444,56452]
trailer [56475,56483]
===
match
---
name: timezone [59601,59609]
name: timezone [59632,59640]
===
match
---
string: "run_id_is_generated" [50642,50663]
string: "run_id_is_generated" [50673,50694]
===
match
---
simple_stmt [19168,19299]
simple_stmt [19199,19330]
===
match
---
atom_expr [63926,63961]
atom_expr [65550,65585]
===
match
---
operator: = [25548,25549]
operator: = [25579,25580]
===
match
---
trailer [65123,65132]
trailer [66747,66756]
===
match
---
arglist [37523,37572]
arglist [37554,37603]
===
match
---
name: days [17949,17953]
name: days [17980,17984]
===
match
---
name: dag [6322,6325]
name: dag [6353,6356]
===
match
---
argument [16192,16224]
argument [16223,16255]
===
match
---
trailer [37811,37818]
trailer [37842,37849]
===
match
---
name: filter [37812,37818]
name: filter [37843,37849]
===
match
---
trailer [46139,46149]
trailer [46170,46180]
===
match
---
name: owner [7234,7239]
name: owner [7265,7270]
===
match
---
operator: , [27783,27784]
operator: , [27814,27815]
===
match
---
assert_stmt [49664,49697]
assert_stmt [49695,49728]
===
match
---
name: Param [1735,1740]
name: Param [1741,1746]
===
match
---
name: num [75224,75227]
name: num [76848,76851]
===
match
---
name: cron_timetable [2583,2597]
name: cron_timetable [2614,2628]
===
match
---
name: get_template_env [20629,20645]
name: get_template_env [20660,20676]
===
match
---
name: DAG [25567,25570]
name: DAG [25598,25601]
===
match
---
argument [47550,47567]
argument [47581,47598]
===
match
---
operator: - [3673,3674]
operator: - [3704,3705]
===
match
---
number: 1 [11146,11147]
number: 1 [11177,11178]
===
match
---
number: 1 [67577,67578]
number: 1 [69201,69202]
===
match
---
expr_stmt [5125,5166]
expr_stmt [5156,5197]
===
match
---
name: dag [42919,42922]
name: dag [42950,42953]
===
match
---
atom [55850,55869]
atom [55881,55900]
===
match
---
operator: , [50722,50723]
operator: , [50753,50754]
===
match
---
name: DagModel [1532,1540]
name: DagModel [1538,1546]
===
match
---
string: 'test_rich_comparison_ops' [47720,47746]
string: 'test_rich_comparison_ops' [47751,47777]
===
match
---
simple_stmt [63579,63758]
simple_stmt [65203,65382]
===
match
---
atom_expr [75911,75942]
atom_expr [77535,77566]
===
match
---
simple_stmt [4752,4809]
simple_stmt [4783,4840]
===
match
---
simple_stmt [40699,40710]
simple_stmt [40730,40741]
===
match
---
name: task_id [7862,7869]
name: task_id [7893,7900]
===
match
---
simple_stmt [38378,38456]
simple_stmt [38409,38487]
===
match
---
name: test_utils [2554,2564]
name: test_utils [2585,2595]
===
match
---
trailer [22241,22315]
trailer [22272,22346]
===
match
---
assert_stmt [6382,6448]
assert_stmt [6413,6479]
===
match
---
operator: , [27743,27744]
operator: , [27774,27775]
===
match
---
expr_stmt [25833,25870]
expr_stmt [25864,25901]
===
match
---
trailer [37136,37179]
trailer [37167,37210]
===
match
---
name: task_4 [77279,77285]
name: task_4 [78903,78909]
===
match
---
name: dag [4849,4852]
name: dag [4880,4883]
===
match
---
term [58008,58026]
term [58039,58057]
===
match
---
name: TIMEZONE [13222,13230]
name: TIMEZONE [13253,13261]
===
match
---
argument [19249,19271]
argument [19280,19302]
===
match
---
simple_stmt [27476,27543]
simple_stmt [27507,27574]
===
match
---
atom_expr [53499,53517]
atom_expr [53530,53548]
===
match
---
operator: = [34876,34877]
operator: = [34907,34908]
===
match
---
operator: = [62545,62546]
operator: = [62576,62577]
===
match
---
name: self [13276,13280]
name: self [13307,13311]
===
match
---
name: dag [34524,34527]
name: dag [34555,34558]
===
match
---
trailer [55445,55453]
trailer [55476,55484]
===
match
---
atom_expr [74654,74671]
atom_expr [76278,76295]
===
match
---
operator: = [59922,59923]
operator: = [59953,59954]
===
match
---
name: timetables [2565,2575]
name: timetables [2596,2606]
===
match
---
name: DAG [42590,42593]
name: DAG [42621,42624]
===
match
---
trailer [73649,73825]
trailer [75273,75449]
===
match
---
argument [18190,18246]
argument [18221,18277]
===
match
---
operator: , [1566,1567]
operator: , [1572,1573]
===
match
---
operator: , [75969,75970]
operator: , [77593,77594]
===
match
---
name: run_type [56387,56395]
name: run_type [56418,56426]
===
match
---
simple_stmt [72536,72550]
simple_stmt [74160,74174]
===
match
---
atom_expr [40511,40551]
atom_expr [40542,40582]
===
match
---
name: dump [48831,48835]
name: dump [48862,48866]
===
match
---
decorated [73421,73497]
decorated [75045,75121]
===
match
---
name: previous_schedule [25104,25121]
name: previous_schedule [25135,25152]
===
match
---
name: permissions [1920,1931]
name: permissions [1926,1937]
===
match
---
trailer [14830,14896]
trailer [14861,14927]
===
match
---
trailer [23457,23464]
trailer [23488,23495]
===
match
---
operator: , [69697,69698]
operator: , [71321,71322]
===
match
---
suite [20185,20498]
suite [20216,20529]
===
match
---
simple_stmt [39662,39707]
simple_stmt [39693,39738]
===
match
---
comparison [31813,31866]
comparison [31844,31897]
===
match
---
operator: { [5134,5135]
operator: { [5165,5166]
===
match
---
name: op5 [39618,39621]
name: op5 [39649,39652]
===
match
---
operator: , [65140,65141]
operator: , [66764,66765]
===
match
---
operator: = [57961,57962]
operator: = [57992,57993]
===
match
---
string: 'dag-bulk-sync-3' [29381,29398]
string: 'dag-bulk-sync-3' [29412,29429]
===
match
---
name: test_dag_topological_sort_include_subdag_tasks [8044,8090]
name: test_dag_topological_sort_include_subdag_tasks [8075,8121]
===
match
---
name: DEFAULT_ARGS [75079,75091]
name: DEFAULT_ARGS [76703,76715]
===
match
---
argument [59916,59955]
argument [59947,59986]
===
match
---
name: return_num [71580,71590]
name: return_num [73204,73214]
===
match
---
atom_expr [26164,26224]
atom_expr [26195,26255]
===
match
---
trailer [35846,35853]
trailer [35877,35884]
===
match
---
trailer [18093,18101]
trailer [18124,18132]
===
match
---
name: f [21453,21454]
name: f [21484,21485]
===
match
---
name: get_num_task_instances [19184,19206]
name: get_num_task_instances [19215,19237]
===
match
---
name: DagModel [32678,32686]
name: DagModel [32709,32717]
===
match
---
name: AirflowException [1461,1477]
name: AirflowException [1467,1483]
===
match
---
operator: = [36499,36500]
operator: = [36530,36531]
===
match
---
expr_stmt [35755,35955]
expr_stmt [35786,35986]
===
match
---
string: 'foo' [20117,20122]
string: 'foo' [20148,20153]
===
match
---
operator: = [22504,22505]
operator: = [22535,22536]
===
match
---
atom_expr [8977,9037]
atom_expr [9008,9068]
===
match
---
with_stmt [40913,41203]
with_stmt [40944,41234]
===
match
---
atom_expr [27415,27467]
atom_expr [27446,27498]
===
match
---
operator: = [14216,14217]
operator: = [14247,14248]
===
match
---
trailer [54534,54540]
trailer [54565,54571]
===
match
---
trailer [24499,24514]
trailer [24530,24545]
===
match
---
atom_expr [12957,12974]
atom_expr [12988,13005]
===
match
---
atom [54812,54959]
atom [54843,54990]
===
match
---
string: "SubDags should never have DagRuns created by the scheduler" [65864,65924]
string: "SubDags should never have DagRuns created by the scheduler" [67488,67548]
===
match
---
simple_stmt [37500,37583]
simple_stmt [37531,37614]
===
match
---
operator: , [21672,21673]
operator: , [21703,21704]
===
match
---
operator: , [61576,61577]
operator: , [61607,61608]
===
match
---
name: dag2 [7210,7214]
name: dag2 [7241,7245]
===
match
---
trailer [10991,11012]
trailer [11022,11043]
===
match
---
name: schedule_interval [25586,25603]
name: schedule_interval [25617,25634]
===
match
---
arglist [6705,6769]
arglist [6736,6800]
===
match
---
operator: = [59217,59218]
operator: = [59248,59249]
===
match
---
assert_stmt [7462,7490]
assert_stmt [7493,7521]
===
match
---
atom_expr [39720,39760]
atom_expr [39751,39791]
===
match
---
name: datetime [27424,27432]
name: datetime [27455,27463]
===
match
---
name: dagrun_1 [56345,56353]
name: dagrun_1 [56376,56384]
===
match
---
atom_expr [36161,36177]
atom_expr [36192,36208]
===
match
---
simple_stmt [32654,32727]
simple_stmt [32685,32758]
===
match
---
number: 1 [31115,31116]
number: 1 [31146,31147]
===
match
---
expr_stmt [7357,7391]
expr_stmt [7388,7422]
===
match
---
operator: = [18167,18168]
operator: = [18198,18199]
===
match
---
operator: = [76736,76737]
operator: = [78360,78361]
===
match
---
simple_stmt [63879,63962]
simple_stmt [65503,65586]
===
match
---
name: task_id [59454,59461]
name: task_id [59485,59492]
===
match
---
name: op5 [39495,39498]
name: op5 [39526,39529]
===
match
---
name: DuplicateTaskIdFound [1479,1499]
name: DuplicateTaskIdFound [1485,1505]
===
match
---
argument [34917,34932]
argument [34948,34963]
===
match
---
atom_expr [76391,76403]
atom_expr [78015,78027]
===
match
---
operator: , [18452,18453]
operator: , [18483,18484]
===
match
---
atom_expr [15674,15688]
atom_expr [15705,15719]
===
match
---
testlist_comp [34816,34833]
testlist_comp [34847,34864]
===
match
---
name: test_dag_invalid_default_view [5274,5303]
name: test_dag_invalid_default_view [5305,5334]
===
match
---
testlist_comp [35206,35222]
testlist_comp [35237,35253]
===
match
---
atom [9716,9726]
atom [9747,9757]
===
match
---
trailer [38001,38013]
trailer [38032,38044]
===
match
---
argument [52014,52046]
argument [52045,52077]
===
match
---
arglist [53209,53269]
arglist [53240,53300]
===
match
---
trailer [22583,22588]
trailer [22614,22619]
===
match
---
name: task_id [32170,32177]
name: task_id [32201,32208]
===
match
---
name: DAG [49468,49471]
name: DAG [49499,49502]
===
match
---
operator: = [51313,51314]
operator: = [51344,51345]
===
match
---
name: op5 [10788,10791]
name: op5 [10819,10822]
===
match
---
string: "@hourly" [78829,78838]
string: "@hourly" [80453,80462]
===
match
---
name: DagRunType [52023,52033]
name: DagRunType [52054,52064]
===
match
---
name: align [79035,79040]
name: align [80659,80664]
===
match
---
simple_stmt [43909,43926]
simple_stmt [43940,43957]
===
match
---
name: topological_list [10821,10837]
name: topological_list [10852,10868]
===
match
---
name: dag3 [60995,60999]
name: dag3 [61026,61030]
===
match
---
atom_expr [20894,20917]
atom_expr [20925,20948]
===
match
---
trailer [77762,77820]
trailer [79386,79444]
===
match
---
trailer [19761,19765]
trailer [19792,19796]
===
match
---
name: test_sub_dag_updates_all_references_while_deepcopy [41779,41829]
name: test_sub_dag_updates_all_references_while_deepcopy [41810,41860]
===
match
---
expr_stmt [3841,3852]
expr_stmt [3872,3883]
===
match
---
name: pipeline [16791,16799]
name: pipeline [16822,16830]
===
match
---
operator: , [65364,65365]
operator: , [66988,66989]
===
match
---
name: expand [55052,55058]
name: expand [55083,55089]
===
match
---
trailer [25103,25121]
trailer [25134,25152]
===
match
---
name: clear [31233,31238]
name: clear [31264,31269]
===
match
---
number: 3 [70125,70126]
number: 3 [71749,71750]
===
match
---
operator: , [54455,54456]
operator: , [54486,54487]
===
match
---
simple_stmt [41082,41125]
simple_stmt [41113,41156]
===
match
---
expr_stmt [43909,43925]
expr_stmt [43940,43956]
===
match
---
name: op1 [9699,9702]
name: op1 [9730,9733]
===
match
---
simple_stmt [2294,2337]
simple_stmt [2325,2368]
===
match
---
atom_expr [47533,47568]
atom_expr [47564,47599]
===
match
---
name: dag [66683,66686]
name: dag [68307,68310]
===
match
---
name: permissions [66385,66396]
name: permissions [68009,68020]
===
match
---
string: 'dummy-dag' [66859,66870]
string: 'dummy-dag' [68483,68494]
===
match
---
name: dag [50625,50628]
name: dag [50656,50659]
===
match
---
funcdef [22031,23111]
funcdef [22062,23142]
===
match
---
trailer [24580,24639]
trailer [24611,24670]
===
match
---
suite [38817,39141]
suite [38848,39172]
===
match
---
trailer [27235,27243]
trailer [27266,27274]
===
match
---
atom_expr [51102,51171]
atom_expr [51133,51202]
===
match
---
string: "test4" [18181,18188]
string: "test4" [18212,18219]
===
match
---
name: name [28773,28777]
name: name [28804,28808]
===
match
---
operator: , [35911,35912]
operator: , [35942,35943]
===
match
---
name: test_next_dagrun_info_catchup [58773,58802]
name: test_next_dagrun_info_catchup [58804,58833]
===
match
---
name: data_interval [61954,61967]
name: data_interval [61985,61998]
===
match
---
name: self [65979,65983]
name: self [67603,67607]
===
match
---
funcdef [25940,26332]
funcdef [25971,26363]
===
match
---
name: session [67878,67885]
name: session [69502,69509]
===
match
---
atom_expr [30320,30356]
atom_expr [30351,30387]
===
match
---
name: session [56292,56299]
name: session [56323,56330]
===
match
---
name: dag_id [25571,25577]
name: dag_id [25602,25608]
===
match
---
simple_stmt [42584,42609]
simple_stmt [42615,42640]
===
match
---
atom_expr [10122,10141]
atom_expr [10153,10172]
===
match
---
trailer [22336,22346]
trailer [22367,22377]
===
match
---
name: end_date [58695,58703]
name: end_date [58726,58734]
===
match
---
operator: , [72115,72116]
operator: , [73739,73740]
===
match
---
atom [66121,66209]
atom [67745,67833]
===
match
---
trailer [34980,34986]
trailer [35011,35017]
===
match
---
name: dag [19749,19752]
name: dag [19780,19783]
===
match
---
name: timezone [22434,22442]
name: timezone [22465,22473]
===
match
---
atom_expr [46076,46092]
atom_expr [46107,46123]
===
match
---
expr_stmt [18318,18334]
expr_stmt [18349,18365]
===
match
---
funcdef [11627,11765]
funcdef [11658,11796]
===
match
---
name: default_args [11696,11708]
name: default_args [11727,11739]
===
match
---
trailer [30633,30640]
trailer [30664,30671]
===
match
---
operator: , [1548,1549]
operator: , [1554,1555]
===
match
---
name: op1 [41621,41624]
name: op1 [41652,41655]
===
match
---
operator: , [11577,11578]
operator: , [11608,11609]
===
match
---
number: 2018 [12796,12800]
number: 2018 [12827,12831]
===
match
---
simple_stmt [27292,27319]
simple_stmt [27323,27350]
===
match
---
atom_expr [33034,33104]
atom_expr [33065,33135]
===
match
---
assert_stmt [7982,8003]
assert_stmt [8013,8034]
===
match
---
name: start [26661,26666]
name: start [26692,26697]
===
match
---
comparison [7026,7047]
comparison [7057,7078]
===
match
---
name: i [13950,13951]
name: i [13981,13982]
===
match
---
suite [46352,46416]
suite [46383,46447]
===
match
---
atom_expr [72666,72684]
atom_expr [74290,74308]
===
match
---
trailer [29164,29171]
trailer [29195,29202]
===
match
---
name: delta [44665,44670]
name: delta [44696,44701]
===
match
---
expr_stmt [32214,32313]
expr_stmt [32245,32344]
===
match
---
operator: , [19141,19142]
operator: , [19172,19173]
===
match
---
operator: = [41109,41110]
operator: = [41140,41141]
===
match
---
trailer [62682,62694]
trailer [62713,62725]
===
match
---
name: test_rich_comparison_ops [47666,47690]
name: test_rich_comparison_ops [47697,47721]
===
match
---
name: dag [50526,50529]
name: dag [50557,50560]
===
match
---
operator: == [47643,47645]
operator: == [47674,47676]
===
match
---
atom_expr [56601,56659]
atom_expr [56632,56690]
===
match
---
argument [19577,19592]
argument [19608,19623]
===
match
---
simple_stmt [75706,75747]
simple_stmt [77330,77371]
===
match
---
argument [60810,60843]
argument [60841,60874]
===
match
---
number: 4 [62099,62100]
number: 4 [62130,62131]
===
match
---
name: i [70374,70375]
name: i [71998,71999]
===
match
---
name: weight_rule [17433,17444]
name: weight_rule [17464,17475]
===
match
---
number: 0 [16679,16680]
number: 0 [16710,16711]
===
match
---
name: start_date [41866,41876]
name: start_date [41897,41907]
===
match
---
operator: , [64030,64031]
operator: , [65654,65655]
===
match
---
name: filter [55703,55709]
name: filter [55734,55740]
===
match
---
name: state [50753,50758]
name: state [50784,50789]
===
match
---
string: "@once" [45861,45868]
string: "@once" [45892,45899]
===
match
---
operator: = [3321,3322]
operator: = [3352,3353]
===
match
---
name: subdag [32560,32566]
name: subdag [32591,32597]
===
match
---
name: dst_rule [24482,24490]
name: dst_rule [24513,24521]
===
match
---
atom [30458,30490]
atom [30489,30521]
===
match
---
atom_expr [29275,29291]
atom_expr [29306,29322]
===
match
---
expr_stmt [6695,6770]
expr_stmt [6726,6801]
===
match
---
comparison [7199,7214]
comparison [7230,7245]
===
match
---
testlist_comp [55940,55971]
testlist_comp [55971,56002]
===
match
---
param [11375,11379]
param [11406,11410]
===
match
---
trailer [27705,27707]
trailer [27736,27738]
===
match
---
argument [56257,56272]
argument [56288,56303]
===
match
---
operator: = [19425,19426]
operator: = [19456,19457]
===
match
---
name: models [1513,1519]
name: models [1519,1525]
===
match
---
name: dag_id [6118,6124]
name: dag_id [6149,6155]
===
match
---
operator: = [38926,38927]
operator: = [38957,38958]
===
match
---
string: "graph" [33498,33505]
string: "graph" [33529,33536]
===
match
---
operator: = [17716,17717]
operator: = [17747,17748]
===
match
---
argument [46829,46846]
argument [46860,46877]
===
match
---
operator: + [52440,52441]
operator: + [52471,52472]
===
match
---
with_item [16156,16232]
with_item [16187,16263]
===
match
---
operator: { [74723,74724]
operator: { [76347,76348]
===
match
---
trailer [60306,60308]
trailer [60337,60339]
===
match
---
name: dag_id [38075,38081]
name: dag_id [38106,38112]
===
match
---
shift_expr [39919,39936]
shift_expr [39950,39967]
===
match
---
name: start_date [63652,63662]
name: start_date [65276,65286]
===
match
---
simple_stmt [31959,32009]
simple_stmt [31990,32040]
===
match
---
atom [29576,29608]
atom [29607,29639]
===
match
---
name: previous_schedule [22945,22962]
name: previous_schedule [22976,22993]
===
match
---
name: op2 [8790,8793]
name: op2 [8821,8824]
===
match
---
trailer [21553,21561]
trailer [21584,21592]
===
match
---
name: isoformat [25041,25050]
name: isoformat [25072,25081]
===
match
---
name: ABSOLUTE [16456,16464]
name: ABSOLUTE [16487,16495]
===
match
---
number: 1 [43826,43827]
number: 1 [43857,43858]
===
match
---
name: session [2150,2157]
name: session [2181,2188]
===
match
---
operator: == [33155,33157]
operator: == [33186,33188]
===
match
---
operator: , [45124,45125]
operator: , [45155,45156]
===
match
---
simple_stmt [75755,75796]
simple_stmt [77379,77420]
===
match
---
name: DAG [26164,26167]
name: DAG [26195,26198]
===
match
---
name: is_paused_upon_creation [36528,36551]
name: is_paused_upon_creation [36559,36582]
===
match
---
expr_stmt [49462,49509]
expr_stmt [49493,49540]
===
match
---
name: raises [17354,17360]
name: raises [17385,17391]
===
match
---
atom_expr [38231,38246]
atom_expr [38262,38277]
===
match
---
name: dag [7658,7661]
name: dag [7689,7692]
===
match
---
argument [18174,18188]
argument [18205,18219]
===
match
---
funcdef [43365,44448]
funcdef [43396,44479]
===
match
---
string: "@weekly" [49986,49995]
string: "@weekly" [50017,50026]
===
match
---
name: op1 [8783,8786]
name: op1 [8814,8817]
===
match
---
operator: , [63951,63952]
operator: , [65575,65576]
===
match
---
operator: { [4601,4602]
operator: { [4632,4633]
===
match
---
name: State [43195,43200]
name: State [43226,43231]
===
match
---
arith_expr [59783,59819]
arith_expr [59814,59850]
===
match
---
simple_stmt [69473,69492]
simple_stmt [71097,71116]
===
match
---
simple_stmt [1692,1741]
simple_stmt [1698,1747]
===
match
---
param [49404,49408]
param [49435,49439]
===
match
---
suite [11676,11765]
suite [11707,11796]
===
match
---
suite [74228,74453]
suite [75852,76077]
===
match
---
operator: = [5155,5156]
operator: = [5186,5187]
===
match
---
simple_stmt [60098,60141]
simple_stmt [60129,60172]
===
match
---
assert_stmt [41614,41631]
assert_stmt [41645,41662]
===
match
---
operator: , [60989,60990]
operator: , [61020,61021]
===
match
---
simple_stmt [22707,22768]
simple_stmt [22738,22799]
===
match
---
trailer [8386,8500]
trailer [8417,8531]
===
match
---
argument [42150,42174]
argument [42181,42205]
===
match
---
name: prev [23008,23012]
name: prev [23039,23043]
===
match
---
operator: = [55232,55233]
operator: = [55263,55264]
===
match
---
name: NONE [51589,51593]
name: NONE [51620,51624]
===
match
---
name: session [68557,68564]
name: session [70181,70188]
===
match
---
expr_stmt [8606,8645]
expr_stmt [8637,8676]
===
match
---
expr_stmt [76562,76606]
expr_stmt [78186,78230]
===
match
---
expr_stmt [15840,15886]
expr_stmt [15871,15917]
===
match
---
name: convert [24062,24069]
name: convert [24093,24100]
===
match
---
argument [41428,41451]
argument [41459,41482]
===
match
---
name: BACKFILL_JOB [52034,52046]
name: BACKFILL_JOB [52065,52077]
===
match
---
operator: , [78569,78570]
operator: , [80193,80194]
===
match
---
expr_stmt [27103,27131]
expr_stmt [27134,27162]
===
match
---
operator: = [10607,10608]
operator: = [10638,10639]
===
match
---
argument [62538,62550]
argument [62569,62581]
===
match
---
operator: = [55585,55586]
operator: = [55616,55617]
===
match
---
trailer [75346,75348]
trailer [76970,76972]
===
match
---
trailer [21890,21903]
trailer [21921,21934]
===
match
---
atom_expr [18718,18736]
atom_expr [18749,18767]
===
match
---
trailer [70014,70016]
trailer [71638,71640]
===
match
---
expr_stmt [26631,26667]
expr_stmt [26662,26698]
===
match
---
operator: == [50540,50542]
operator: == [50571,50573]
===
match
---
name: flush [67818,67823]
name: flush [69442,69447]
===
match
---
operator: = [75909,75910]
operator: = [77533,77534]
===
match
---
name: convert [23000,23007]
name: convert [23031,23038]
===
match
---
trailer [32437,32448]
trailer [32468,32479]
===
match
---
expr_stmt [64706,64878]
expr_stmt [66330,66502]
===
match
---
number: 1 [65139,65140]
number: 1 [66763,66764]
===
match
---
trailer [36956,36958]
trailer [36987,36989]
===
match
---
trailer [51770,51778]
trailer [51801,51809]
===
match
---
name: default_args [71879,71891]
name: default_args [73503,73515]
===
match
---
arglist [26168,26223]
arglist [26199,26254]
===
match
---
operator: == [57147,57149]
operator: == [57178,57180]
===
match
---
atom_expr [45144,45160]
atom_expr [45175,45191]
===
match
---
operator: = [59263,59264]
operator: = [59294,59295]
===
match
---
simple_stmt [77257,77307]
simple_stmt [78881,78931]
===
match
---
if_stmt [58440,58611]
if_stmt [58471,58642]
===
match
---
atom_expr [16832,16868]
atom_expr [16863,16899]
===
match
---
simple_stmt [76123,76355]
simple_stmt [77747,77979]
===
match
---
name: range [15247,15252]
name: range [15278,15283]
===
match
---
name: dag [48432,48435]
name: dag [48463,48466]
===
match
---
trailer [52720,52727]
trailer [52751,52758]
===
match
---
suite [58461,58497]
suite [58492,58528]
===
match
---
string: 'some_string' [22011,22024]
string: 'some_string' [22042,22055]
===
match
---
simple_stmt [62571,62610]
simple_stmt [62602,62641]
===
match
---
suite [47416,47657]
suite [47447,47688]
===
match
---
operator: = [53858,53859]
operator: = [53889,53890]
===
match
---
name: DAG [78757,78760]
name: DAG [80381,80384]
===
match
---
trailer [76576,76584]
trailer [78200,78208]
===
match
---
operator: = [18270,18271]
operator: = [18301,18302]
===
match
---
trailer [56751,56758]
trailer [56782,56789]
===
match
---
simple_stmt [67901,67925]
simple_stmt [69525,69549]
===
match
---
name: airflow [1342,1349]
name: airflow [1348,1355]
===
match
---
name: datetime [62455,62463]
name: datetime [62486,62494]
===
match
---
assert_stmt [32976,33011]
assert_stmt [33007,33042]
===
match
---
operator: > [48969,48970]
operator: > [49000,49001]
===
match
---
trailer [68462,68471]
trailer [70086,70095]
===
match
---
number: 1 [65142,65143]
number: 1 [66766,66767]
===
match
---
atom_expr [53566,53583]
atom_expr [53597,53614]
===
match
---
string: 'op6' [7635,7640]
string: 'op6' [7666,7671]
===
match
---
operator: = [18518,18519]
operator: = [18549,18550]
===
match
---
argument [53926,53941]
argument [53957,53972]
===
match
---
name: dag [7000,7003]
name: dag [7031,7034]
===
match
---
assert_stmt [25251,25305]
assert_stmt [25282,25336]
===
match
---
operator: , [60959,60960]
operator: , [60990,60991]
===
match
---
name: session [52655,52662]
name: session [52686,52693]
===
match
---
operator: = [46725,46726]
operator: = [46756,46757]
===
match
---
string: """         Test to check that a DAG with catchup = False only schedules beginning now, not back to the start date         """ [58818,58944]
string: """         Test to check that a DAG with catchup = False only schedules beginning now, not back to the start date         """ [58849,58975]
===
match
---
number: 1 [75593,75594]
number: 1 [77217,77218]
===
match
---
name: dags [28093,28097]
name: dags [28124,28128]
===
match
---
atom_expr [65793,65822]
atom_expr [67417,67446]
===
match
---
simple_stmt [45878,45926]
simple_stmt [45909,45957]
===
match
---
param [21390,21394]
param [21421,21425]
===
match
---
atom_expr [53603,53615]
atom_expr [53634,53646]
===
match
---
simple_stmt [40013,40029]
simple_stmt [40044,40060]
===
match
---
trailer [74539,74754]
trailer [76163,76378]
===
match
---
suite [5910,6176]
suite [5941,6207]
===
match
---
operator: = [66702,66703]
operator: = [68326,68327]
===
match
---
trailer [75306,75315]
trailer [76930,76939]
===
match
---
trailer [76396,76403]
trailer [78020,78027]
===
match
---
atom [66040,66098]
atom [67664,67722]
===
match
---
atom_expr [43683,43900]
atom_expr [43714,43931]
===
match
---
atom_expr [22225,22315]
atom_expr [22256,22346]
===
match
---
arglist [38426,38453]
arglist [38457,38484]
===
match
---
name: DAG [68751,68754]
name: DAG [70375,70378]
===
match
---
suite [78746,79097]
suite [80370,80721]
===
match
---
name: dag [73632,73635]
name: dag [75256,75259]
===
match
---
atom_expr [19755,19940]
atom_expr [19786,19971]
===
match
---
operator: != [48591,48593]
operator: != [48622,48624]
===
match
---
testlist_comp [78632,78678]
testlist_comp [80256,80302]
===
match
---
trailer [31509,31671]
trailer [31540,31702]
===
match
---
string: 'dag-bulk-sync-3' [29874,29891]
string: 'dag-bulk-sync-3' [29905,29922]
===
match
---
name: clear_db_runs [70001,70014]
name: clear_db_runs [71625,71638]
===
match
---
operator: { [35972,35973]
operator: { [36003,36004]
===
match
---
arglist [25645,25706]
arglist [25676,25737]
===
match
---
name: dag [12733,12736]
name: dag [12764,12767]
===
match
---
operator: , [78873,78874]
operator: , [80497,80498]
===
match
---
atom [31783,31796]
atom [31814,31827]
===
match
---
expr_stmt [13130,13181]
expr_stmt [13161,13212]
===
match
---
name: subdag [65435,65441]
name: subdag [67059,67065]
===
match
---
number: 50 [20287,20289]
number: 50 [20318,20320]
===
match
---
operator: , [64140,64141]
operator: , [65764,65765]
===
match
---
operator: = [66015,66016]
operator: = [67639,67640]
===
match
---
simple_stmt [18955,19052]
simple_stmt [18986,19083]
===
match
---
name: split [32761,32766]
name: split [32792,32797]
===
match
---
decorator [71452,71507]
decorator [73076,73131]
===
match
---
suite [66833,67224]
suite [68457,68848]
===
match
---
atom_expr [76039,76051]
atom_expr [77663,77675]
===
match
---
string: 'test-dag2' [29794,29805]
string: 'test-dag2' [29825,29836]
===
match
---
name: subdag [34216,34222]
name: subdag [34247,34253]
===
match
---
simple_stmt [57984,58027]
simple_stmt [58015,58058]
===
match
---
trailer [63236,63248]
trailer [63267,63279]
===
match
---
operator: < [3881,3882]
operator: < [3912,3913]
===
match
---
name: run_type [51190,51198]
name: run_type [51221,51229]
===
match
---
trailer [70647,70656]
trailer [72271,72280]
===
match
---
trailer [74696,74704]
trailer [76320,76328]
===
match
---
name: start_date [56466,56476]
name: start_date [56497,56507]
===
match
---
atom_expr [77296,77306]
atom_expr [78920,78930]
===
match
---
fstring_expr [28121,28124]
fstring_expr [28152,28155]
===
match
---
operator: = [60353,60354]
operator: = [60384,60385]
===
match
---
name: session [54489,54496]
name: session [54520,54527]
===
match
---
name: start [22217,22222]
name: start [22248,22253]
===
match
---
operator: = [54774,54775]
operator: = [54805,54806]
===
match
---
name: self [8977,8981]
name: self [9008,9012]
===
match
---
simple_stmt [4103,4132]
simple_stmt [4134,4163]
===
match
---
trailer [56310,56318]
trailer [56341,56349]
===
match
---
operator: = [18328,18329]
operator: = [18359,18360]
===
match
---
name: prev_task [15449,15458]
name: prev_task [15480,15489]
===
match
---
name: DEFAULT_DATE [55412,55424]
name: DEFAULT_DATE [55443,55455]
===
match
---
operator: = [6939,6940]
operator: = [6970,6971]
===
match
---
name: create_dagrun [31496,31509]
name: create_dagrun [31527,31540]
===
match
---
operator: , [19033,19034]
operator: , [19064,19065]
===
match
---
name: range [70306,70311]
name: range [71930,71935]
===
match
---
operator: , [29855,29856]
operator: , [29886,29887]
===
match
---
atom_expr [33337,33352]
atom_expr [33368,33383]
===
match
---
operator: = [15071,15072]
operator: = [15102,15103]
===
match
---
name: session [35783,35790]
name: session [35814,35821]
===
match
---
funcdef [66787,67224]
funcdef [68411,68848]
===
match
---
operator: , [28388,28389]
operator: , [28419,28420]
===
match
---
argument [64802,64828]
argument [66426,66452]
===
match
---
simple_stmt [52855,52891]
simple_stmt [52886,52922]
===
match
---
name: _next [25886,25891]
name: _next [25917,25922]
===
match
---
name: TI [18349,18351]
name: TI [18380,18382]
===
match
---
simple_stmt [50673,50771]
simple_stmt [50704,50802]
===
match
---
operator: = [17834,17835]
operator: = [17865,17866]
===
match
---
name: op1 [6996,6999]
name: op1 [7027,7030]
===
match
---
name: self [27187,27191]
name: self [27218,27222]
===
match
---
trailer [52367,52621]
trailer [52398,52652]
===
match
---
simple_stmt [1228,1268]
simple_stmt [1234,1274]
===
match
---
atom_expr [32613,32644]
atom_expr [32644,32675]
===
match
---
name: run_id [18291,18297]
name: run_id [18322,18328]
===
match
---
name: owner [7510,7515]
name: owner [7541,7546]
===
match
---
atom_expr [25189,25211]
atom_expr [25220,25242]
===
match
---
argument [67425,67432]
argument [69049,69056]
===
match
---
name: state [76585,76590]
name: state [78209,78214]
===
match
---
trailer [47999,48031]
trailer [48030,48062]
===
match
---
trailer [44681,44691]
trailer [44712,44722]
===
match
---
name: when [26233,26237]
name: when [26264,26268]
===
match
---
atom_expr [63900,63922]
atom_expr [65524,65546]
===
match
---
comparison [68512,68547]
comparison [70136,70171]
===
match
---
name: params2 [4627,4634]
name: params2 [4658,4665]
===
match
---
decorated [55818,57288]
decorated [55849,57319]
===
match
---
arglist [51820,51870]
arglist [51851,51901]
===
match
---
atom_expr [56439,56452]
atom_expr [56470,56483]
===
match
---
assert_stmt [61105,61150]
assert_stmt [61136,61181]
===
match
---
trailer [33047,33057]
trailer [33078,33088]
===
match
---
arglist [56604,56658]
arglist [56635,56689]
===
match
---
name: dag [23559,23562]
name: dag [23590,23593]
===
match
---
funcdef [3548,3891]
funcdef [3579,3922]
===
match
---
trailer [35076,35080]
trailer [35107,35111]
===
match
---
simple_stmt [48923,48950]
simple_stmt [48954,48981]
===
match
---
string: 'dag_default_view' [32940,32958]
string: 'dag_default_view' [32971,32989]
===
match
---
name: State [54305,54310]
name: State [54336,54341]
===
match
---
import_from [1337,1375]
import_from [1343,1381]
===
match
---
name: fileloc [69848,69855]
name: fileloc [71472,71479]
===
match
---
trailer [9133,9147]
trailer [9164,9178]
===
match
---
atom_expr [59789,59819]
atom_expr [59820,59850]
===
match
---
operator: , [65862,65863]
operator: , [67486,67487]
===
match
---
name: dag [49271,49274]
name: dag [49302,49305]
===
match
---
name: self [25985,25989]
name: self [26016,26020]
===
match
---
name: dag [26158,26161]
name: dag [26189,26192]
===
match
---
trailer [59398,59421]
trailer [59429,59452]
===
match
---
name: iterator [78889,78897]
name: iterator [80513,80521]
===
match
---
operator: = [47562,47563]
operator: = [47593,47594]
===
match
---
operator: , [64083,64084]
operator: , [65707,65708]
===
match
---
arglist [45960,46021]
arglist [45991,46052]
===
match
---
parameters [24272,24278]
parameters [24303,24309]
===
match
---
atom_expr [46794,46869]
atom_expr [46825,46900]
===
match
---
operator: = [39018,39019]
operator: = [39049,39050]
===
match
---
string: 'dag.subtask' [32244,32257]
string: 'dag.subtask' [32275,32288]
===
match
---
operator: = [18356,18357]
operator: = [18387,18388]
===
match
---
atom_expr [9660,9686]
atom_expr [9691,9717]
===
match
---
number: 1 [63690,63691]
number: 1 [65314,65315]
===
match
---
name: prev [23996,24000]
name: prev [24027,24031]
===
match
---
trailer [70351,70401]
trailer [71975,72025]
===
match
---
trailer [6334,6338]
trailer [6365,6369]
===
match
---
expr_stmt [51709,51747]
expr_stmt [51740,51778]
===
match
---
simple_stmt [20857,20867]
simple_stmt [20888,20898]
===
match
---
name: is_paused [35314,35323]
name: is_paused [35345,35354]
===
match
---
operator: <= [3870,3872]
operator: <= [3901,3903]
===
match
---
parameters [71008,71014]
parameters [72632,72638]
===
match
---
trailer [51588,51593]
trailer [51619,51624]
===
match
---
name: __class__ [27304,27313]
name: __class__ [27335,27344]
===
match
---
funcdef [30781,32009]
funcdef [30812,32040]
===
match
---
name: tests [2429,2434]
name: tests [2460,2465]
===
match
---
atom_expr [3270,3283]
atom_expr [3301,3314]
===
match
---
operator: , [26118,26119]
operator: , [26149,26150]
===
match
---
trailer [57022,57029]
trailer [57053,57060]
===
match
---
comparison [35162,35256]
comparison [35193,35287]
===
match
---
name: op1 [39542,39545]
name: op1 [39573,39576]
===
match
---
name: execution_date [52129,52143]
name: execution_date [52160,52174]
===
match
---
operator: = [45783,45784]
operator: = [45814,45815]
===
match
---
assert_stmt [11074,11108]
assert_stmt [11105,11139]
===
match
---
argument [70393,70400]
argument [72017,72024]
===
match
---
name: clear [56774,56779]
name: clear [56805,56810]
===
match
---
comparison [23869,23922]
comparison [23900,23953]
===
match
---
argument [44692,44699]
argument [44723,44730]
===
match
---
simple_stmt [70227,70289]
simple_stmt [71851,71913]
===
match
---
trailer [7029,7035]
trailer [7060,7066]
===
match
---
name: orm_dag [37245,37252]
name: orm_dag [37276,37283]
===
match
---
simple_stmt [43616,43669]
simple_stmt [43647,43700]
===
match
---
trailer [7376,7391]
trailer [7407,7422]
===
match
---
expr_stmt [18266,18309]
expr_stmt [18297,18340]
===
match
---
trailer [4115,4119]
trailer [4146,4150]
===
match
---
import_from [2081,2130]
import_from [2112,2161]
===
match
---
assert_stmt [11159,11193]
assert_stmt [11190,11224]
===
match
---
name: task_id [34364,34371]
name: task_id [34395,34402]
===
match
---
atom_expr [12895,12924]
atom_expr [12926,12955]
===
match
---
trailer [53576,53583]
trailer [53607,53614]
===
match
---
atom [29774,29806]
atom [29805,29837]
===
match
---
trailer [39846,39860]
trailer [39877,39891]
===
match
---
trailer [52189,52199]
trailer [52220,52230]
===
match
---
name: datetime [68101,68109]
name: datetime [69725,69733]
===
match
---
name: dag_id [45256,45262]
name: dag_id [45287,45293]
===
match
---
name: query [3349,3354]
name: query [3380,3385]
===
match
---
simple_stmt [33406,33517]
simple_stmt [33437,33548]
===
match
---
name: DAGS_FOLDER [69634,69645]
name: DAGS_FOLDER [71258,71269]
===
match
---
atom_expr [17742,17821]
atom_expr [17773,17852]
===
match
---
name: DummyOperator [39020,39033]
name: DummyOperator [39051,39064]
===
match
---
simple_stmt [60646,60679]
simple_stmt [60677,60710]
===
match
---
trailer [72606,72616]
trailer [74230,74240]
===
match
---
name: session [54506,54513]
name: session [54537,54544]
===
match
---
trailer [71492,71505]
trailer [73116,73129]
===
match
---
name: task [18438,18442]
name: task [18469,18473]
===
match
---
param [27193,27195]
param [27224,27226]
===
match
---
name: row [28441,28444]
name: row [28472,28475]
===
match
---
simple_stmt [62704,62762]
simple_stmt [62735,62793]
===
match
---
name: task_id [76695,76702]
name: task_id [78319,78326]
===
match
---
argument [51917,51924]
argument [51948,51955]
===
match
---
simple_stmt [11390,11466]
simple_stmt [11421,11497]
===
match
---
name: dags_needing_dagruns [69236,69256]
name: dags_needing_dagruns [70860,70880]
===
match
---
name: NamedTemporaryFile [995,1013]
name: NamedTemporaryFile [995,1013]
===
match
---
argument [56466,56489]
argument [56497,56520]
===
match
---
argument [44879,44899]
argument [44910,44930]
===
match
---
string: 'airflow' [31172,31181]
string: 'airflow' [31203,31212]
===
match
---
operator: , [6151,6152]
operator: , [6182,6183]
===
match
---
atom_expr [6894,6922]
atom_expr [6925,6953]
===
match
---
name: width [15197,15202]
name: width [15228,15233]
===
match
---
atom_expr [78298,78434]
atom_expr [79922,80058]
===
match
---
name: correct_weight [17000,17014]
name: correct_weight [17031,17045]
===
match
---
with_stmt [49707,49845]
with_stmt [49738,49876]
===
match
---
operator: , [28603,28604]
operator: , [28634,28635]
===
match
---
operator: = [75660,75661]
operator: = [77284,77285]
===
match
---
trailer [7992,7996]
trailer [8023,8027]
===
match
---
argument [55446,55452]
argument [55477,55483]
===
match
---
trailer [71029,71031]
trailer [72653,72655]
===
match
---
string: '/tmp/foo.py' [69684,69697]
string: '/tmp/foo.py' [71308,71321]
===
match
---
fstring_end: ' [15029,15030]
fstring_end: ' [15060,15061]
===
match
---
name: self [10221,10225]
name: self [10252,10256]
===
match
---
name: test_next_dagrun_info_timedelta_schedule_and_catchup_true [62111,62168]
name: test_next_dagrun_info_timedelta_schedule_and_catchup_true [62142,62199]
===
match
---
trailer [61943,61968]
trailer [61974,61999]
===
match
---
arglist [40515,40550]
arglist [40546,40581]
===
match
---
expr_stmt [63832,63870]
expr_stmt [65456,65494]
===
match
---
trailer [64337,64357]
trailer [65961,65981]
===
match
---
name: _clean_up [43303,43312]
name: _clean_up [43334,43343]
===
match
---
simple_stmt [26277,26332]
simple_stmt [26308,26363]
===
match
---
expr_stmt [53142,53187]
expr_stmt [53173,53218]
===
match
---
name: owner [46829,46834]
name: owner [46860,46865]
===
match
---
assert_stmt [33113,33178]
assert_stmt [33144,33209]
===
match
---
operator: = [31018,31019]
operator: = [31049,31050]
===
match
---
argument [48013,48030]
argument [48044,48061]
===
match
---
string: '2019-06-05T00:00:00+05:00' [12426,12453]
string: '2019-06-05T00:00:00+05:00' [12457,12484]
===
match
---
atom_expr [23434,23464]
atom_expr [23465,23495]
===
match
---
name: dag [32613,32616]
name: dag [32644,32647]
===
match
---
name: DAG [38769,38772]
name: DAG [38800,38803]
===
match
---
name: DummyOperator [10564,10577]
name: DummyOperator [10595,10608]
===
match
---
name: datetime [26525,26533]
name: datetime [26556,26564]
===
match
---
trailer [8839,8856]
trailer [8870,8887]
===
match
---
suite [39768,40248]
suite [39799,40279]
===
match
---
operator: = [8633,8634]
operator: = [8664,8665]
===
match
---
operator: = [55273,55274]
operator: = [55304,55305]
===
match
---
trailer [12849,12858]
trailer [12880,12889]
===
match
---
simple_stmt [72064,72086]
simple_stmt [73688,73710]
===
match
---
name: dag_id [43707,43713]
name: dag_id [43738,43744]
===
match
---
name: DagModel [32695,32703]
name: DagModel [32726,32734]
===
match
---
name: dags_needing_dagruns [67857,67877]
name: dags_needing_dagruns [69481,69501]
===
match
---
name: state [54016,54021]
name: state [54047,54052]
===
match
---
argument [31556,31588]
argument [31587,31619]
===
match
---
string: 'child_dag' [9072,9083]
string: 'child_dag' [9103,9114]
===
match
---
trailer [29973,29975]
trailer [30004,30006]
===
match
---
name: state [56638,56643]
name: state [56669,56674]
===
match
---
number: 4 [61801,61802]
number: 4 [61832,61833]
===
match
---
argument [6339,6372]
argument [6370,6403]
===
match
---
expr_stmt [27716,27794]
expr_stmt [27747,27825]
===
match
---
argument [45982,45999]
argument [46013,46030]
===
match
---
expr_stmt [18514,18557]
expr_stmt [18545,18588]
===
match
---
argument [67679,67733]
argument [69303,69357]
===
match
---
name: previous_schedule [23563,23580]
name: previous_schedule [23594,23611]
===
match
---
trailer [10984,10991]
trailer [11015,11022]
===
match
---
argument [56873,56879]
argument [56904,56910]
===
match
---
funcdef [61204,62054]
funcdef [61235,62085]
===
match
---
operator: } [29398,29399]
operator: } [29429,29430]
===
match
---
operator: , [66332,66333]
operator: , [67956,67957]
===
match
---
operator: = [67468,67469]
operator: = [69092,69093]
===
match
---
name: dag_id [29462,29468]
name: dag_id [29493,29499]
===
match
---
name: utcnow [73727,73733]
name: utcnow [75351,75357]
===
match
---
expr_stmt [56583,56659]
expr_stmt [56614,56690]
===
match
---
trailer [55242,55250]
trailer [55273,55281]
===
match
---
name: op1 [59544,59547]
name: op1 [59575,59578]
===
match
---
simple_stmt [2616,2658]
simple_stmt [2647,2689]
===
match
---
name: state [52060,52065]
name: state [52091,52096]
===
match
---
arglist [38578,38610]
arglist [38609,38641]
===
match
---
trailer [4787,4794]
trailer [4818,4825]
===
match
---
name: WeightRule [16445,16455]
name: WeightRule [16476,16486]
===
match
---
trailer [12609,12623]
trailer [12640,12654]
===
match
---
name: start [22505,22510]
name: start [22536,22541]
===
match
---
expr_stmt [54045,54120]
expr_stmt [54076,54151]
===
match
---
trailer [30350,30354]
trailer [30381,30385]
===
match
---
atom_expr [16634,16653]
atom_expr [16665,16684]
===
match
---
parameters [20178,20184]
parameters [20209,20215]
===
match
---
funcdef [4879,5265]
funcdef [4910,5296]
===
match
---
trailer [23040,23050]
trailer [23071,23081]
===
match
---
operator: , [6035,6036]
operator: , [6066,6067]
===
match
---
name: next_date [61112,61121]
name: next_date [61143,61152]
===
match
---
simple_stmt [71314,71345]
simple_stmt [72938,72969]
===
match
---
with_stmt [7261,7392]
with_stmt [7292,7423]
===
match
---
trailer [28006,28008]
trailer [28037,28039]
===
match
---
operator: = [25839,25840]
operator: = [25870,25871]
===
match
---
name: dateutil [1150,1158]
name: dateutil [1156,1164]
===
match
---
name: pytest [66951,66957]
name: pytest [68575,68581]
===
match
---
name: section_1 [65259,65268]
name: section_1 [66883,66892]
===
match
---
trailer [9147,9188]
trailer [9178,9219]
===
match
---
name: self [58803,58807]
name: self [58834,58838]
===
match
---
name: priority_weight_total [14486,14507]
name: priority_weight_total [14517,14538]
===
match
---
name: width [16526,16531]
name: width [16557,16562]
===
match
---
comparison [35972,36062]
comparison [36003,36093]
===
match
---
arglist [26566,26621]
arglist [26597,26652]
===
match
---
operator: == [26301,26303]
operator: == [26332,26334]
===
match
---
comparison [46432,46457]
comparison [46463,46488]
===
match
---
name: DAG [30116,30119]
name: DAG [30147,30150]
===
match
---
suite [7600,7642]
suite [7631,7673]
===
match
---
argument [57916,57923]
argument [57947,57954]
===
match
---
operator: > [60245,60246]
operator: > [60276,60277]
===
match
---
trailer [49229,49234]
trailer [49260,49265]
===
match
---
operator: , [42148,42149]
operator: , [42179,42180]
===
match
---
simple_stmt [10754,10776]
simple_stmt [10785,10807]
===
match
---
string: 'owner2' [7482,7490]
string: 'owner2' [7513,7521]
===
match
---
name: mock_stats [44334,44344]
name: mock_stats [44365,44375]
===
match
---
name: Undefined [20594,20603]
name: Undefined [20625,20634]
===
match
---
name: run_id [73663,73669]
name: run_id [75287,75293]
===
match
---
name: session [53707,53714]
name: session [53738,53745]
===
match
---
arglist [62835,62845]
arglist [62866,62876]
===
match
---
funcdef [69968,70017]
funcdef [71592,71641]
===
match
---
string: 'owner2' [33678,33686]
string: 'owner2' [33709,33717]
===
match
---
name: session [68451,68458]
name: session [70075,70082]
===
match
---
trailer [26687,26697]
trailer [26718,26728]
===
match
---
trailer [62871,62888]
trailer [62902,62919]
===
match
---
name: pytest [66637,66643]
name: pytest [68261,68267]
===
match
---
name: schedule_interval [60857,60874]
name: schedule_interval [60888,60905]
===
match
---
atom_expr [18783,18853]
atom_expr [18814,18884]
===
match
---
comparison [37201,37229]
comparison [37232,37260]
===
match
---
simple_stmt [11048,11066]
simple_stmt [11079,11097]
===
match
---
string: 'b_parent' [9234,9244]
string: 'b_parent' [9265,9275]
===
match
---
trailer [50832,50834]
trailer [50863,50865]
===
match
---
operator: , [78096,78097]
operator: , [79720,79721]
===
match
---
simple_stmt [65435,65461]
simple_stmt [67059,67085]
===
match
---
operator: , [30526,30527]
operator: , [30557,30558]
===
match
---
string: 'owner2' [32543,32551]
string: 'owner2' [32574,32582]
===
match
---
trailer [72635,72642]
trailer [74259,74266]
===
match
---
name: self [73396,73400]
name: self [75020,75024]
===
match
---
trailer [27951,27959]
trailer [27982,27990]
===
match
---
operator: = [13717,13718]
operator: = [13748,13749]
===
match
---
expr_stmt [46880,46910]
expr_stmt [46911,46941]
===
match
---
name: params [4853,4859]
name: params [4884,4890]
===
match
---
name: timedelta [78551,78560]
name: timedelta [80175,80184]
===
match
---
number: 3 [19314,19315]
number: 3 [19345,19346]
===
match
---
atom_expr [55710,55723]
atom_expr [55741,55754]
===
match
---
trailer [37283,37316]
trailer [37314,37347]
===
match
---
number: 1 [53131,53132]
number: 1 [53162,53163]
===
match
---
atom_expr [70001,70016]
atom_expr [71625,71640]
===
match
---
name: op1 [41082,41085]
name: op1 [41113,41116]
===
match
---
name: set1 [10967,10971]
name: set1 [10998,11002]
===
match
---
trailer [38352,38369]
trailer [38383,38400]
===
match
---
name: dag_id [53082,53088]
name: dag_id [53113,53119]
===
match
---
name: SCHEDULED [51078,51087]
name: SCHEDULED [51109,51118]
===
match
---
trailer [20831,20844]
trailer [20862,20875]
===
match
---
assert_stmt [43188,43225]
assert_stmt [43219,43256]
===
match
---
suite [13695,14567]
suite [13726,14598]
===
match
---
name: DAG [71258,71261]
name: DAG [72882,72885]
===
match
---
trailer [45250,45265]
trailer [45281,45296]
===
match
---
if_stmt [3747,3794]
if_stmt [3778,3825]
===
match
---
simple_stmt [26476,26548]
simple_stmt [26507,26579]
===
match
---
dotted_name [51538,51558]
dotted_name [51569,51589]
===
match
---
comparison [52906,52935]
comparison [52937,52966]
===
match
---
atom [40743,40761]
atom [40774,40792]
===
match
---
operator: = [51024,51025]
operator: = [51055,51056]
===
match
---
name: DEFAULT_DATE [78035,78047]
name: DEFAULT_DATE [79659,79671]
===
match
---
name: dag [50979,50982]
name: dag [51010,51013]
===
match
---
name: start_date [12884,12894]
name: start_date [12915,12925]
===
match
---
argument [19418,19433]
argument [19449,19464]
===
match
---
expr_stmt [66842,66936]
expr_stmt [68466,68560]
===
match
---
expr_stmt [65570,65593]
expr_stmt [67194,67217]
===
match
---
arglist [56257,56281]
arglist [56288,56312]
===
match
---
name: dag [39116,39119]
name: dag [39147,39150]
===
match
---
name: get [5801,5804]
name: get [5832,5835]
===
match
---
name: DAG [50631,50634]
name: DAG [50662,50665]
===
match
---
trailer [28778,28782]
trailer [28809,28813]
===
match
---
trailer [3262,3269]
trailer [3293,3300]
===
match
---
operator: = [6699,6700]
operator: = [6730,6731]
===
match
---
operator: = [18204,18205]
operator: = [18235,18236]
===
match
---
arglist [12391,12489]
arglist [12422,12520]
===
match
---
expr_stmt [40045,40071]
expr_stmt [40076,40102]
===
match
---
trailer [4200,4212]
trailer [4231,4243]
===
match
---
atom_expr [35423,35441]
atom_expr [35454,35472]
===
match
---
atom_expr [62507,62524]
atom_expr [62538,62555]
===
match
---
name: row [28430,28433]
name: row [28461,28464]
===
match
---
operator: , [23375,23376]
operator: , [23406,23407]
===
match
---
atom_expr [25150,25172]
atom_expr [25181,25203]
===
match
---
name: stop [3129,3133]
name: stop [3160,3164]
===
match
---
number: 5 [14761,14762]
number: 5 [14792,14793]
===
match
---
import_from [1692,1740]
import_from [1698,1746]
===
match
---
name: SUCCESS [76445,76452]
name: SUCCESS [78069,78076]
===
match
---
trailer [78317,78434]
trailer [79941,80058]
===
match
---
atom_expr [74764,74839]
atom_expr [76388,76463]
===
match
---
name: _next [23938,23943]
name: _next [23969,23974]
===
match
---
operator: } [36041,36042]
operator: } [36072,36073]
===
match
---
operator: == [76294,76296]
operator: == [77918,77920]
===
match
---
name: op1 [40744,40747]
name: op1 [40775,40778]
===
match
---
operator: == [38645,38647]
operator: == [38676,38678]
===
match
---
arglist [19220,19288]
arglist [19251,19319]
===
match
---
operator: , [30476,30477]
operator: , [30507,30508]
===
match
---
name: DeprecationWarning [66452,66470]
name: DeprecationWarning [68076,68094]
===
match
---
operator: , [33749,33750]
operator: , [33780,33781]
===
match
---
comparison [11295,11321]
comparison [11326,11352]
===
match
---
trailer [18522,18557]
trailer [18553,18588]
===
match
---
operator: = [65588,65589]
operator: = [67212,67213]
===
match
---
trailer [7931,7935]
trailer [7962,7966]
===
match
---
operator: = [34563,34564]
operator: = [34594,34595]
===
match
---
expr_stmt [33837,33865]
expr_stmt [33868,33896]
===
match
---
trailer [53466,53477]
trailer [53497,53508]
===
match
---
expr_stmt [46721,46772]
expr_stmt [46752,46803]
===
match
---
arglist [8919,8960]
arglist [8950,8991]
===
match
---
dictorsetmaker [11710,11762]
dictorsetmaker [11741,11793]
===
match
---
name: airflow [2342,2349]
name: airflow [2373,2380]
===
match
---
operator: , [51915,51916]
operator: , [51946,51947]
===
match
---
atom_expr [45478,45508]
atom_expr [45509,45539]
===
match
---
string: 'dag' [13622,13627]
string: 'dag' [13653,13658]
===
match
---
name: RUNNING [55919,55926]
name: RUNNING [55950,55957]
===
match
---
name: DEFAULT_DATE [32286,32298]
name: DEFAULT_DATE [32317,32329]
===
match
---
atom_expr [43934,44018]
atom_expr [43965,44049]
===
match
---
string: "t2" [39855,39859]
string: "t2" [39886,39890]
===
match
---
expr_stmt [49419,49453]
expr_stmt [49450,49484]
===
match
---
name: dag [68273,68276]
name: dag [69897,69900]
===
match
---
argument [62489,62524]
argument [62520,62555]
===
match
---
name: DagModel [35406,35414]
name: DagModel [35437,35445]
===
match
---
argument [65303,65322]
argument [66927,66946]
===
match
---
simple_stmt [2424,2482]
simple_stmt [2455,2513]
===
match
---
name: _occur_before [9058,9071]
name: _occur_before [9089,9102]
===
match
---
name: current_task [16832,16844]
name: current_task [16863,16875]
===
match
---
trailer [36417,36431]
trailer [36448,36462]
===
match
---
string: 'DAG' [38578,38583]
string: 'DAG' [38609,38614]
===
match
---
operator: = [25696,25697]
operator: = [25727,25728]
===
match
---
operator: , [51017,51018]
operator: , [51048,51049]
===
match
---
name: DagTag [27952,27958]
name: DagTag [27983,27989]
===
match
---
trailer [51819,51871]
trailer [51850,51902]
===
match
---
number: 0 [2652,2653]
number: 0 [2683,2684]
===
match
---
trailer [27725,27794]
trailer [27756,27825]
===
match
---
trailer [29013,29019]
trailer [29044,29050]
===
match
---
trailer [42366,42378]
trailer [42397,42409]
===
match
---
name: end_date [56830,56838]
name: end_date [56861,56869]
===
match
---
atom [21998,22025]
atom [22029,22056]
===
match
---
operator: == [77507,77509]
operator: == [79131,79133]
===
match
---
name: self [26790,26794]
name: self [26821,26825]
===
match
---
testlist_comp [54277,54321]
testlist_comp [54308,54352]
===
match
---
atom [51582,51595]
atom [51613,51626]
===
match
---
trailer [56758,56760]
trailer [56789,56791]
===
match
---
operator: , [28187,28188]
operator: , [28218,28219]
===
match
---
expr_stmt [24869,24904]
expr_stmt [24900,24935]
===
match
---
name: paused_dags [36050,36061]
name: paused_dags [36081,36092]
===
match
---
name: datetime [55427,55435]
name: datetime [55458,55466]
===
match
---
argument [73795,73814]
argument [75419,75438]
===
match
---
expr_stmt [36644,36732]
expr_stmt [36675,36763]
===
match
---
trailer [58097,58179]
trailer [58128,58210]
===
match
---
operator: + [48072,48073]
operator: + [48103,48104]
===
match
---
trailer [28850,28854]
trailer [28881,28885]
===
match
---
atom [35581,35652]
atom [35612,35683]
===
match
---
trailer [34794,34836]
trailer [34825,34867]
===
match
---
arglist [18810,18852]
arglist [18841,18883]
===
match
---
dotted_name [2661,2675]
dotted_name [2692,2706]
===
match
---
operator: = [54599,54600]
operator: = [54630,54631]
===
match
---
name: op4 [9757,9760]
name: op4 [9788,9791]
===
match
---
atom_expr [69882,69902]
atom_expr [71506,71526]
===
match
---
trailer [41755,41763]
trailer [41786,41794]
===
match
---
fstring_start: f' [16344,16346]
fstring_start: f' [16375,16377]
===
match
---
number: 1 [57600,57601]
number: 1 [57631,57632]
===
match
---
name: noop_pipeline [71666,71679]
name: noop_pipeline [73290,73303]
===
match
---
name: task_id [58214,58221]
name: task_id [58245,58252]
===
match
---
operator: = [49837,49838]
operator: = [49868,49869]
===
match
---
atom_expr [13910,13929]
atom_expr [13941,13960]
===
match
---
comp_op [28888,28894]
comp_op [28919,28925]
===
match
---
expr_stmt [8810,8883]
expr_stmt [8841,8914]
===
match
---
operator: , [8942,8943]
operator: , [8973,8974]
===
match
---
simple_stmt [51496,51532]
simple_stmt [51527,51563]
===
match
---
name: parameterized [55038,55051]
name: parameterized [55069,55082]
===
match
---
atom_expr [14279,14293]
atom_expr [14310,14324]
===
match
---
operator: , [50274,50275]
operator: , [50305,50306]
===
match
---
trailer [10138,10141]
trailer [10169,10172]
===
match
---
simple_stmt [9315,9391]
simple_stmt [9346,9422]
===
match
---
name: op3 [41765,41768]
name: op3 [41796,41799]
===
match
---
if_stmt [3806,3853]
if_stmt [3837,3884]
===
match
---
operator: == [61122,61124]
operator: == [61153,61155]
===
match
---
atom [29873,29905]
atom [29904,29936]
===
match
---
operator: } [66412,66413]
operator: } [68036,68037]
===
match
---
expr_stmt [7842,7876]
expr_stmt [7873,7907]
===
match
---
operator: , [60078,60079]
operator: , [60109,60110]
===
match
---
suite [29222,29262]
suite [29253,29293]
===
match
---
parameters [34158,34173]
parameters [34189,34204]
===
match
---
operator: , [35602,35603]
operator: , [35633,35634]
===
match
---
trailer [12795,12807]
trailer [12826,12838]
===
match
---
arglist [18523,18556]
arglist [18554,18587]
===
match
---
with_stmt [17342,17456]
with_stmt [17373,17487]
===
match
---
name: append [58588,58594]
name: append [58619,58625]
===
match
---
simple_stmt [17564,17588]
simple_stmt [17595,17619]
===
match
---
name: DAG [56173,56176]
name: DAG [56204,56207]
===
match
---
name: ACTION_CAN_READ [66368,66383]
name: ACTION_CAN_READ [67992,68007]
===
match
---
suite [70049,70074]
suite [71673,71698]
===
match
---
operator: { [28332,28333]
operator: { [28363,28364]
===
match
---
name: DAG [47876,47879]
name: DAG [47907,47910]
===
match
---
name: dag_id [38204,38210]
name: dag_id [38235,38241]
===
match
---
string: 'owner' [9371,9378]
string: 'owner' [9402,9409]
===
match
---
trailer [21983,21994]
trailer [22014,22025]
===
match
---
operator: = [6749,6750]
operator: = [6780,6781]
===
match
---
operator: , [77595,77596]
operator: , [79219,79220]
===
match
---
name: bulk_write_to_db [30120,30136]
name: bulk_write_to_db [30151,30167]
===
match
---
name: args [47906,47910]
name: args [47937,47941]
===
match
---
operator: = [67439,67440]
operator: = [69063,69064]
===
match
---
assert_stmt [47281,47355]
assert_stmt [47312,47386]
===
match
---
name: UPSTREAM_FAILED [76494,76509]
name: UPSTREAM_FAILED [78118,78133]
===
match
---
name: NONE [77302,77306]
name: NONE [78926,78930]
===
match
---
simple_stmt [43677,43901]
simple_stmt [43708,43932]
===
match
---
atom_expr [70639,70656]
atom_expr [72263,72280]
===
match
---
atom [74723,74743]
atom [76347,76367]
===
match
---
number: 3 [24471,24472]
number: 3 [24502,24503]
===
match
---
atom_expr [28244,28270]
atom_expr [28275,28301]
===
match
---
operator: , [62687,62688]
operator: , [62718,62719]
===
match
---
atom_expr [3433,3524]
atom_expr [3464,3555]
===
match
---
operator: , [75985,75986]
operator: , [77609,77610]
===
match
---
atom_expr [77607,77620]
atom_expr [79231,79244]
===
match
---
name: dag_id [35093,35099]
name: dag_id [35124,35130]
===
match
---
operator: = [38795,38796]
operator: = [38826,38827]
===
match
---
trailer [32058,32125]
trailer [32089,32156]
===
match
---
atom_expr [75387,75397]
atom_expr [77011,77021]
===
match
---
number: 0 [28885,28886]
number: 0 [28916,28917]
===
match
---
assert_stmt [32887,32967]
assert_stmt [32918,32998]
===
match
---
simple_stmt [2046,2081]
simple_stmt [2077,2112]
===
match
---
atom_expr [78757,78839]
atom_expr [80381,80463]
===
match
---
shift_expr [8783,8800]
shift_expr [8814,8831]
===
match
---
atom_expr [55340,55604]
atom_expr [55371,55635]
===
match
---
name: orm_dag [69298,69305]
name: orm_dag [70922,70929]
===
match
---
operator: , [24476,24477]
operator: , [24507,24508]
===
match
---
atom_expr [72596,72616]
atom_expr [74220,74240]
===
match
---
parameters [58966,59014]
parameters [58997,59045]
===
match
---
operator: , [19826,19827]
operator: , [19857,19858]
===
match
---
atom [55068,55136]
atom [55099,55167]
===
match
---
simple_stmt [30383,30662]
simple_stmt [30414,30693]
===
match
---
atom_expr [49250,49262]
atom_expr [49281,49293]
===
match
---
if_stmt [15342,15382]
if_stmt [15373,15413]
===
match
---
atom_expr [23829,23852]
atom_expr [23860,23883]
===
match
---
parameters [30822,30828]
parameters [30853,30859]
===
match
---
trailer [12650,12662]
trailer [12681,12693]
===
match
---
name: logging [9821,9828]
name: logging [9852,9859]
===
match
---
simple_stmt [2737,2751]
simple_stmt [2768,2782]
===
match
---
name: dag_eq [48507,48513]
name: dag_eq [48538,48544]
===
match
---
operator: , [75594,75595]
operator: , [77218,77219]
===
match
---
sync_comp_for [28437,28484]
sync_comp_for [28468,28515]
===
match
---
operator: , [70519,70520]
operator: , [72143,72144]
===
match
---
operator: == [15928,15930]
operator: == [15959,15961]
===
match
---
operator: , [68330,68331]
operator: , [69954,69955]
===
match
---
name: self [27265,27269]
name: self [27296,27300]
===
match
---
name: width [15803,15808]
name: width [15834,15839]
===
match
---
name: State [19257,19262]
name: State [19288,19293]
===
match
---
name: start_date [53629,53639]
name: start_date [53660,53670]
===
match
---
name: create_dagrun [70456,70469]
name: create_dagrun [72080,72093]
===
match
---
name: DAG [28993,28996]
name: DAG [29024,29027]
===
match
---
argument [38896,38908]
argument [38927,38939]
===
match
---
name: query [3249,3254]
name: query [3280,3285]
===
match
---
simple_stmt [20930,20971]
simple_stmt [20961,21002]
===
match
---
operator: , [63688,63689]
operator: , [65312,65313]
===
match
---
string: 'a_child' [8305,8314]
string: 'a_child' [8336,8345]
===
match
---
suite [16917,17146]
suite [16948,17177]
===
match
---
with_item [30156,30183]
with_item [30187,30214]
===
match
---
name: test_get_paused_dag_ids [49380,49403]
name: test_get_paused_dag_ids [49411,49434]
===
match
---
fstring_expr [70373,70376]
fstring_expr [71997,72000]
===
match
---
decorated [71952,72028]
decorated [73576,73652]
===
match
---
name: datetime [923,931]
name: datetime [923,931]
===
match
---
simple_stmt [71660,71682]
simple_stmt [73284,73306]
===
match
---
trailer [7661,7668]
trailer [7692,7699]
===
match
---
name: int [14275,14278]
name: int [14306,14309]
===
match
---
atom_expr [22331,22348]
atom_expr [22362,22379]
===
match
---
operator: @ [71864,71865]
operator: @ [73488,73489]
===
match
---
name: interval [58595,58603]
name: interval [58626,58634]
===
match
---
trailer [51899,51925]
trailer [51930,51956]
===
match
---
trailer [26697,26699]
trailer [26728,26730]
===
match
---
simple_stmt [51972,52168]
simple_stmt [52003,52199]
===
match
---
name: DEFAULT_DATE [34486,34498]
name: DEFAULT_DATE [34517,34529]
===
match
---
name: DummyOperator [21088,21101]
name: DummyOperator [21119,21132]
===
match
---
atom_expr [69099,69116]
atom_expr [70723,70740]
===
match
---
trailer [76181,76325]
trailer [77805,77949]
===
match
---
simple_stmt [38145,38223]
simple_stmt [38176,38254]
===
match
---
name: UTC0530 [26888,26895]
name: UTC0530 [26919,26926]
===
match
---
assert_stmt [31680,31701]
assert_stmt [31711,31732]
===
match
---
trailer [23729,23731]
trailer [23760,23762]
===
match
---
name: self [70970,70974]
name: self [72594,72598]
===
match
---
name: execution_date [73749,73763]
name: execution_date [75373,75387]
===
match
---
name: next_dagrun [31368,31379]
name: next_dagrun [31399,31410]
===
match
---
trailer [55020,55029]
trailer [55051,55060]
===
match
---
operator: = [55559,55560]
operator: = [55590,55591]
===
match
---
name: session [34764,34771]
name: session [34795,34802]
===
match
---
import_as_names [2165,2196]
import_as_names [2196,2227]
===
match
---
name: dag_run [42716,42723]
name: dag_run [42747,42754]
===
match
---
operator: = [40098,40099]
operator: = [40129,40130]
===
match
---
arglist [17612,17655]
arglist [17643,17686]
===
match
---
argument [58155,58178]
argument [58186,58209]
===
match
---
name: operators [1802,1811]
name: operators [1808,1817]
===
match
---
number: 5 [16123,16124]
number: 5 [16154,16155]
===
match
---
name: self [47410,47414]
name: self [47441,47445]
===
match
---
operator: = [68165,68166]
operator: = [69789,69790]
===
match
---
param [57324,57328]
param [57355,57359]
===
match
---
argument [68374,68403]
argument [69998,70027]
===
match
---
trailer [68215,68223]
trailer [69839,69847]
===
match
---
argument [8297,8314]
argument [8328,8345]
===
match
---
file_input [788,79097]
file_input [788,81975]
===
match
---
param [58994,59005]
param [59025,59036]
===
match
---
name: model [46473,46478]
name: model [46504,46509]
===
match
---
operator: == [3284,3286]
operator: == [3315,3317]
===
match
---
trailer [33240,33252]
trailer [33271,33283]
===
match
---
name: dagrun [77607,77613]
name: dagrun [79231,79237]
===
match
---
decorator [71864,71911]
decorator [73488,73535]
===
match
---
argument [41116,41123]
argument [41147,41154]
===
match
---
operator: , [50107,50108]
operator: , [50138,50139]
===
match
---
name: session [33889,33896]
name: session [33920,33927]
===
match
---
name: _next [22963,22968]
name: _next [22994,22999]
===
match
---
name: self [17189,17193]
name: self [17220,17224]
===
match
---
operator: == [23732,23734]
operator: == [23763,23765]
===
match
---
name: DAG [18967,18970]
name: DAG [18998,19001]
===
match
---
argument [56210,56227]
argument [56241,56258]
===
match
---
name: subdag [54220,54226]
name: subdag [54251,54257]
===
match
---
name: calculated_weight [17110,17127]
name: calculated_weight [17141,17158]
===
match
---
name: timedelta [59859,59868]
name: timedelta [59890,59899]
===
match
---
atom_expr [36135,36152]
atom_expr [36166,36183]
===
match
---
atom_expr [59850,59877]
atom_expr [59881,59908]
===
match
---
simple_stmt [24869,24905]
simple_stmt [24900,24936]
===
match
---
operator: = [13134,13135]
operator: = [13165,13166]
===
match
---
trailer [3354,3358]
trailer [3385,3389]
===
match
---
operator: { [12411,12412]
operator: { [12442,12443]
===
match
---
name: dag [53329,53332]
name: dag [53360,53363]
===
match
---
name: task_id [53170,53177]
name: task_id [53201,53208]
===
match
---
name: days [69109,69113]
name: days [70733,70737]
===
match
---
suite [75453,77626]
suite [77077,79250]
===
match
---
name: test_duplicate_task_ids_for_same_task_is_allowed [41264,41312]
name: test_duplicate_task_ids_for_same_task_is_allowed [41295,41343]
===
match
---
name: sync_to_db [46298,46308]
name: sync_to_db [46329,46339]
===
match
---
name: dag [61923,61926]
name: dag [61954,61957]
===
match
---
name: session [44151,44158]
name: session [44182,44189]
===
match
---
comparison [7506,7527]
comparison [7537,7558]
===
match
---
operator: , [46996,46997]
operator: , [47027,47028]
===
match
---
trailer [35133,35135]
trailer [35164,35166]
===
match
---
simple_stmt [5509,5580]
simple_stmt [5540,5611]
===
match
---
name: states [19128,19134]
name: states [19159,19165]
===
match
---
operator: = [24702,24703]
operator: = [24733,24734]
===
match
---
funcdef [57708,58764]
funcdef [57739,58795]
===
match
---
simple_stmt [48778,48803]
simple_stmt [48809,48834]
===
match
---
name: run [73849,73852]
name: run [75473,75476]
===
match
---
string: 'dag' [14831,14836]
string: 'dag' [14862,14867]
===
match
---
name: TI [3366,3368]
name: TI [3397,3399]
===
match
---
name: datetime [63935,63943]
name: datetime [65559,65567]
===
match
---
trailer [78857,78883]
trailer [80481,80507]
===
match
---
comparison [62791,62846]
comparison [62822,62877]
===
match
---
funcdef [78683,79097]
funcdef [80307,80721]
===
match
---
atom_expr [33547,33592]
atom_expr [33578,33623]
===
match
---
and_test [62625,62694]
and_test [62656,62725]
===
match
---
argument [42665,42682]
argument [42696,42713]
===
match
---
comparison [55710,55737]
comparison [55741,55768]
===
match
---
trailer [68223,68225]
trailer [69847,69849]
===
match
---
import_name [814,828]
import_name [814,828]
===
match
---
simple_stmt [72376,72434]
simple_stmt [74000,74058]
===
match
---
name: DummyOperator [59385,59398]
name: DummyOperator [59416,59429]
===
match
---
name: task_id [41756,41763]
name: task_id [41787,41794]
===
match
---
name: DEFAULT_DATE [78527,78539]
name: DEFAULT_DATE [80151,80163]
===
match
---
name: FAILED [53828,53834]
name: FAILED [53859,53865]
===
match
---
factor [25549,25551]
factor [25580,25582]
===
match
---
name: DagRun [54857,54863]
name: DagRun [54888,54894]
===
match
---
name: airflow [1381,1388]
name: airflow [1387,1394]
===
match
---
name: task_id [59399,59406]
name: task_id [59430,59437]
===
match
---
term [15790,15808]
term [15821,15839]
===
match
---
operator: = [22989,22990]
operator: = [23020,23021]
===
match
---
atom [70124,70128]
atom [71748,71752]
===
match
---
argument [23385,23417]
argument [23416,23448]
===
match
---
assert_stmt [47191,47272]
assert_stmt [47222,47303]
===
match
---
string: 'start_date' [12764,12776]
string: 'start_date' [12795,12807]
===
match
---
arglist [70487,70599]
arglist [72111,72223]
===
match
---
trailer [51077,51087]
trailer [51108,51118]
===
match
---
decorator [71952,71968]
decorator [73576,73592]
===
match
---
assert_stmt [48565,48597]
assert_stmt [48596,48628]
===
match
---
name: days [31470,31474]
name: days [31501,31505]
===
match
---
argument [18239,18245]
argument [18270,18276]
===
match
---
trailer [35548,35552]
trailer [35579,35583]
===
match
---
trailer [44856,44865]
trailer [44887,44896]
===
match
---
operator: = [47588,47589]
operator: = [47619,47620]
===
match
---
name: clear_db_dags [2514,2527]
name: clear_db_dags [2545,2558]
===
match
---
name: jinja_udf [19871,19880]
name: jinja_udf [19902,19911]
===
match
---
simple_stmt [39919,39937]
simple_stmt [39950,39968]
===
match
---
name: dag [68745,68748]
name: dag [70369,70372]
===
match
---
name: filter [76175,76181]
name: filter [77799,77805]
===
match
---
atom [38393,38455]
atom [38424,38486]
===
match
---
with_stmt [32134,32568]
with_stmt [32165,32599]
===
match
---
name: task_id [39423,39430]
name: task_id [39454,39461]
===
match
---
name: execution_date [67184,67198]
name: execution_date [68808,68822]
===
match
---
operator: , [33686,33687]
operator: , [33717,33718]
===
match
---
trailer [9071,9113]
trailer [9102,9144]
===
match
---
name: DEFAULT_DATE [44931,44943]
name: DEFAULT_DATE [44962,44974]
===
match
---
trailer [37074,37081]
trailer [37105,37112]
===
match
---
operator: , [45909,45910]
operator: , [45940,45941]
===
match
---
simple_stmt [44282,44325]
simple_stmt [44313,44356]
===
match
---
arglist [60810,60960]
arglist [60841,60991]
===
match
---
name: dag [10236,10239]
name: dag [10267,10270]
===
match
---
operator: == [35653,35655]
operator: == [35684,35686]
===
match
---
testlist_comp [39563,39571]
testlist_comp [39594,39602]
===
match
---
operator: @ [70079,70080]
operator: @ [71703,71704]
===
match
---
string: 'expected_relative' [69567,69586]
string: 'expected_relative' [71191,71210]
===
match
---
argument [50635,50663]
argument [50666,50694]
===
match
---
name: filter [37130,37136]
name: filter [37161,37167]
===
match
---
operator: == [16676,16678]
operator: == [16707,16709]
===
match
---
name: query [28456,28461]
name: query [28487,28492]
===
match
---
name: dag_ [48348,48352]
name: dag_ [48379,48383]
===
match
---
trailer [34010,34023]
trailer [34041,34054]
===
match
---
atom_expr [23480,23542]
atom_expr [23511,23573]
===
match
---
name: dag_id [50923,50929]
name: dag_id [50954,50960]
===
match
---
operator: = [19813,19814]
operator: = [19844,19845]
===
match
---
trailer [38656,38661]
trailer [38687,38692]
===
match
---
argument [8342,8359]
argument [8373,8390]
===
match
---
number: 0 [30761,30762]
number: 0 [30792,30793]
===
match
---
name: freeze_time [61157,61168]
name: freeze_time [61188,61199]
===
match
---
number: 2018 [38426,38430]
number: 2018 [38457,38461]
===
match
---
name: get [31779,31782]
name: get [31810,31813]
===
match
---
trailer [2888,2890]
trailer [2919,2921]
===
match
---
name: append [29165,29171]
name: append [29196,29202]
===
match
---
simple_stmt [31355,31396]
simple_stmt [31386,31427]
===
match
---
expr_stmt [65435,65460]
expr_stmt [67059,67084]
===
match
---
argument [52060,52078]
argument [52091,52109]
===
match
---
argument [36250,36278]
argument [36281,36309]
===
match
---
import_from [918,948]
import_from [918,948]
===
match
---
trailer [10651,10666]
trailer [10682,10697]
===
match
---
name: runs [58009,58013]
name: runs [58040,58044]
===
match
---
name: remove [10115,10121]
name: remove [10146,10152]
===
match
---
operator: , [67166,67167]
operator: , [68790,68791]
===
match
---
name: session [36962,36969]
name: session [36993,37000]
===
match
---
operator: { [30204,30205]
operator: { [30235,30236]
===
match
---
number: 2 [64907,64908]
number: 2 [66531,66532]
===
match
---
trailer [50695,50770]
trailer [50726,50801]
===
match
---
operator: = [36625,36626]
operator: = [36656,36657]
===
match
---
name: dag [48965,48968]
name: dag [48996,48999]
===
match
---
argument [59681,59688]
argument [59712,59719]
===
match
---
name: dag_id [67319,67325]
name: dag_id [68943,68949]
===
match
---
simple_stmt [49118,49145]
simple_stmt [49149,49176]
===
match
---
comparison [29509,29976]
comparison [29540,30007]
===
match
---
simple_stmt [5640,5720]
simple_stmt [5671,5751]
===
match
---
trailer [77247,77252]
trailer [78871,78876]
===
match
---
trailer [38849,38863]
trailer [38880,38894]
===
match
---
name: dag_id [35880,35886]
name: dag_id [35911,35917]
===
match
---
name: dag_id [42594,42600]
name: dag_id [42625,42631]
===
match
---
dictorsetmaker [4707,4724]
dictorsetmaker [4738,4755]
===
match
---
trailer [43644,43656]
trailer [43675,43687]
===
match
---
trailer [7711,7717]
trailer [7742,7748]
===
match
---
name: run_id [18465,18471]
name: run_id [18496,18502]
===
match
---
atom_expr [33605,33828]
atom_expr [33636,33859]
===
match
---
simple_stmt [5919,5992]
simple_stmt [5950,6023]
===
match
---
argument [64983,64997]
argument [66607,66621]
===
match
---
name: dag_id [54923,54929]
name: dag_id [54954,54960]
===
match
---
name: num [72490,72493]
name: num [74114,74117]
===
match
---
trailer [18274,18309]
trailer [18305,18340]
===
match
---
operator: , [46175,46176]
operator: , [46206,46207]
===
match
---
atom_expr [12515,12545]
atom_expr [12546,12576]
===
match
---
name: leaves [39601,39607]
name: leaves [39632,39638]
===
match
---
dictorsetmaker [47814,47860]
dictorsetmaker [47845,47891]
===
match
---
simple_stmt [12733,12810]
simple_stmt [12764,12841]
===
match
---
name: exceptions [1443,1453]
name: exceptions [1449,1459]
===
match
---
atom [16257,16605]
atom [16288,16636]
===
match
---
atom_expr [39501,39528]
atom_expr [39532,39559]
===
match
---
trailer [67968,67974]
trailer [69592,69598]
===
match
---
atom_expr [71666,71681]
atom_expr [73290,73305]
===
match
---
name: test_dag [17836,17844]
name: test_dag [17867,17875]
===
match
---
trailer [34228,34299]
trailer [34259,34330]
===
match
---
name: enumerate [3717,3726]
name: enumerate [3748,3757]
===
match
---
parameters [28053,28059]
parameters [28084,28090]
===
match
---
name: session [53715,53722]
name: session [53746,53753]
===
match
---
simple_stmt [42998,43026]
simple_stmt [43029,43057]
===
match
---
atom_expr [64901,64909]
atom_expr [66525,66533]
===
match
---
operator: = [26611,26612]
operator: = [26642,26643]
===
match
---
param [10221,10225]
param [10252,10256]
===
match
---
name: session [29295,29302]
name: session [29326,29333]
===
match
---
funcdef [52941,54227]
funcdef [52972,54258]
===
match
---
name: DAG [64719,64722]
name: DAG [66343,66346]
===
match
---
name: task_id [9539,9546]
name: task_id [9570,9577]
===
match
---
trailer [23402,23417]
trailer [23433,23448]
===
match
---
name: dag [32139,32142]
name: dag [32170,32173]
===
match
---
atom_expr [44334,44395]
atom_expr [44365,44426]
===
match
---
name: Session [68216,68223]
name: Session [69840,69847]
===
match
---
arglist [34242,34289]
arglist [34273,34320]
===
match
---
name: topological_list [11129,11145]
name: topological_list [11160,11176]
===
match
---
simple_stmt [13130,13182]
simple_stmt [13161,13213]
===
match
---
operator: { [29509,29510]
operator: { [29540,29541]
===
match
---
trailer [66964,67046]
trailer [68588,68670]
===
match
---
simple_stmt [48811,48844]
simple_stmt [48842,48875]
===
match
---
name: DummyOperator [64160,64173]
name: DummyOperator [65784,65797]
===
match
---
operator: == [12631,12633]
operator: == [12662,12664]
===
match
---
operator: , [59079,59080]
operator: , [59110,59111]
===
match
---
expr_stmt [7795,7829]
expr_stmt [7826,7860]
===
match
---
name: run_type [53557,53565]
name: run_type [53588,53596]
===
match
---
simple_stmt [68234,68443]
simple_stmt [69858,70067]
===
match
---
expr_stmt [39357,39390]
expr_stmt [39388,39421]
===
match
---
atom_expr [54022,54035]
atom_expr [54053,54066]
===
match
---
atom_expr [45429,45446]
atom_expr [45460,45477]
===
match
---
name: query [32672,32677]
name: query [32703,32708]
===
match
---
operator: != [49311,49313]
operator: != [49342,49344]
===
match
---
name: include_parentdag [52558,52575]
name: include_parentdag [52589,52606]
===
match
---
trailer [54283,54288]
trailer [54314,54319]
===
match
---
name: self [75127,75131]
name: self [76751,76755]
===
match
---
operator: { [16351,16352]
operator: { [16382,16383]
===
match
---
atom [32777,32797]
atom [32808,32828]
===
match
---
operator: , [2647,2648]
operator: , [2678,2679]
===
match
---
name: DagRun [52686,52692]
name: DagRun [52717,52723]
===
match
---
atom_expr [78844,78883]
atom_expr [80468,80507]
===
match
---
atom_expr [48056,48100]
atom_expr [48087,48131]
===
match
---
fstring [16344,16359]
fstring [16375,16390]
===
match
---
name: filter [35456,35462]
name: filter [35487,35493]
===
match
---
operator: = [18180,18181]
operator: = [18211,18212]
===
match
---
name: assert_queries_count [28956,28976]
name: assert_queries_count [28987,29007]
===
match
---
name: self [20746,20750]
name: self [20777,20781]
===
match
---
name: task [18275,18279]
name: task [18306,18310]
===
match
---
atom [19540,19575]
atom [19571,19606]
===
match
---
comparison [8019,8034]
comparison [8050,8065]
===
match
---
name: parameterized [51538,51551]
name: parameterized [51569,51582]
===
match
---
operator: = [64858,64859]
operator: = [66482,66483]
===
match
---
simple_stmt [32503,32568]
simple_stmt [32534,32599]
===
match
---
name: DAG [72612,72615]
name: DAG [74236,74239]
===
match
---
trailer [66649,66669]
trailer [68273,68293]
===
match
---
name: orientation [6153,6164]
name: orientation [6184,6195]
===
match
---
trailer [52727,52783]
trailer [52758,52814]
===
match
---
operator: = [13334,13335]
operator: = [13365,13366]
===
match
---
comparison [3809,3823]
comparison [3840,3854]
===
match
---
trailer [71679,71681]
trailer [73303,73305]
===
match
---
argument [75876,75892]
argument [77500,77516]
===
match
---
operator: = [8662,8663]
operator: = [8693,8694]
===
match
---
name: dag [27803,27806]
name: dag [27834,27837]
===
match
---
atom_expr [12941,12953]
atom_expr [12972,12984]
===
match
---
name: dag_decorator [1678,1691]
name: dag_decorator [1684,1697]
===
match
---
trailer [49760,49766]
trailer [49791,49797]
===
match
---
operator: = [74559,74560]
operator: = [76183,76184]
===
match
---
simple_stmt [49284,49324]
simple_stmt [49315,49355]
===
match
---
trailer [68493,68495]
trailer [70117,70119]
===
match
---
name: basename [21598,21606]
name: basename [21629,21637]
===
match
---
simple_stmt [31192,31221]
simple_stmt [31223,31252]
===
match
---
name: create_session [27833,27847]
name: create_session [27864,27878]
===
match
---
trailer [37208,37221]
trailer [37239,37252]
===
match
---
funcdef [51647,52936]
funcdef [51678,52967]
===
match
---
argument [74718,74743]
argument [76342,76367]
===
match
---
name: dag_subdag [64987,64997]
name: dag_subdag [66611,66621]
===
match
---
trailer [7329,7344]
trailer [7360,7375]
===
match
---
name: DummyOperator [10429,10442]
name: DummyOperator [10460,10473]
===
match
---
operator: , [33813,33814]
operator: , [33844,33845]
===
match
---
atom_expr [46520,46542]
atom_expr [46551,46573]
===
match
---
expr_stmt [56930,57110]
expr_stmt [56961,57141]
===
match
---
expr_stmt [13309,13318]
expr_stmt [13340,13349]
===
match
---
simple_stmt [49243,49276]
simple_stmt [49274,49307]
===
match
---
operator: == [33081,33083]
operator: == [33112,33114]
===
match
---
trailer [51105,51119]
trailer [51136,51150]
===
match
---
name: op1 [8606,8609]
name: op1 [8637,8640]
===
match
---
trailer [66743,66758]
trailer [68367,68382]
===
match
---
operator: , [15254,15255]
operator: , [15285,15286]
===
match
---
name: self [44504,44508]
name: self [44535,44539]
===
match
---
name: owner [63806,63811]
name: owner [65430,65435]
===
match
---
simple_stmt [37625,37654]
simple_stmt [37656,37685]
===
match
---
string: 'test-dag' [4681,4691]
string: 'test-dag' [4712,4722]
===
match
---
name: topological_sort [8840,8856]
name: topological_sort [8871,8887]
===
match
---
atom_expr [56243,56282]
atom_expr [56274,56313]
===
match
---
arglist [44302,44323]
arglist [44333,44354]
===
match
---
string: 'E' [10631,10634]
string: 'E' [10662,10665]
===
match
---
expr_stmt [62338,62561]
expr_stmt [62369,62592]
===
match
---
trailer [30046,30053]
trailer [30077,30084]
===
match
---
argument [27496,27512]
argument [27527,27543]
===
match
---
expr_stmt [54803,54959]
expr_stmt [54834,54990]
===
match
---
comparison [10944,10971]
comparison [10975,11002]
===
match
---
testlist_comp [35596,35608]
testlist_comp [35627,35639]
===
match
---
name: task_id [75827,75834]
name: task_id [77451,77458]
===
match
---
string: "start_date, expected_infos" [77658,77686]
string: "start_date, expected_infos" [79282,79310]
===
match
---
operator: , [71473,71474]
operator: , [73097,73098]
===
match
---
argument [52418,52468]
argument [52449,52499]
===
match
---
simple_stmt [58582,58611]
simple_stmt [58613,58642]
===
match
---
name: priority_weight [15056,15071]
name: priority_weight [15087,15102]
===
match
---
expr_stmt [58327,58342]
expr_stmt [58358,58373]
===
match
---
assert_stmt [71726,71751]
assert_stmt [73350,73375]
===
match
---
trailer [67721,67733]
trailer [69345,69357]
===
match
---
name: task_decorator [72448,72462]
name: task_decorator [74072,74086]
===
match
---
string: 'webserver' [6398,6409]
string: 'webserver' [6429,6440]
===
match
---
operator: = [14759,14760]
operator: = [14790,14791]
===
match
---
expr_stmt [71205,71226]
expr_stmt [72829,72850]
===
match
---
name: dag_id [72636,72642]
name: dag_id [74260,74266]
===
match
---
simple_stmt [36644,36733]
simple_stmt [36675,36764]
===
match
---
argument [24482,24514]
argument [24513,24545]
===
match
---
name: DEFAULT_DATE [53238,53250]
name: DEFAULT_DATE [53269,53281]
===
match
---
operator: = [36230,36231]
operator: = [36261,36262]
===
match
---
name: isoformat [23657,23666]
name: isoformat [23688,23697]
===
match
---
string: """         Test that the dag file processor does not create multiple dagruns         if a dag is scheduled with 'timedelta' and catchup=False         """ [61282,61436]
string: """         Test that the dag file processor does not create multiple dagruns         if a dag is scheduled with 'timedelta' and catchup=False         """ [61313,61467]
===
match
---
assert_stmt [9893,9928]
assert_stmt [9924,9959]
===
match
---
name: DagRunType [42766,42776]
name: DagRunType [42797,42807]
===
match
---
trailer [56563,56573]
trailer [56594,56604]
===
match
---
name: op3 [9875,9878]
name: op3 [9906,9909]
===
match
---
trailer [59868,59877]
trailer [59899,59908]
===
match
---
string: '*/10 * * * *' [59987,60001]
string: '*/10 * * * *' [60018,60032]
===
match
---
trailer [38987,39001]
trailer [39018,39032]
===
match
---
comparison [15345,15351]
comparison [15376,15382]
===
match
---
name: dag1 [60113,60117]
name: dag1 [60144,60148]
===
match
---
simple_stmt [65831,65925]
simple_stmt [67455,67549]
===
match
---
trailer [8678,8717]
trailer [8709,8748]
===
match
---
comp_op [30764,30770]
comp_op [30795,30801]
===
match
---
name: in_ [35887,35890]
name: in_ [35918,35921]
===
match
---
atom_expr [32746,32772]
atom_expr [32777,32803]
===
match
---
simple_stmt [3059,3075]
simple_stmt [3090,3106]
===
match
---
param [75195,75198]
param [76819,76822]
===
match
---
operator: == [43209,43211]
operator: == [43240,43242]
===
match
---
simple_stmt [71726,71752]
simple_stmt [73350,73376]
===
match
---
name: dag [42617,42620]
name: dag [42648,42651]
===
match
---
trailer [27945,27951]
trailer [27976,27982]
===
match
---
string: """         Test DAG as a context manager.         When used as a context manager, Operators are automatically added to         the DAG (unless they specify a different DAG)         """ [6501,6686]
string: """         Test DAG as a context manager.         When used as a context manager, Operators are automatically added to         the DAG (unless they specify a different DAG)         """ [6532,6717]
===
match
---
expr_stmt [51297,51349]
expr_stmt [51328,51380]
===
match
---
simple_stmt [58088,58180]
simple_stmt [58119,58211]
===
match
---
name: Session [31211,31218]
name: Session [31242,31249]
===
match
---
operator: , [28125,28126]
operator: , [28156,28157]
===
match
---
parameters [27342,27352]
parameters [27373,27383]
===
match
---
trailer [22962,22969]
trailer [22993,23000]
===
match
---
atom_expr [54531,54793]
atom_expr [54562,54824]
===
match
---
operator: = [32449,32450]
operator: = [32480,32481]
===
match
---
simple_stmt [17597,17657]
simple_stmt [17628,17688]
===
match
---
name: task_decorator [73422,73436]
name: task_decorator [75046,75060]
===
match
---
expr_stmt [68197,68225]
expr_stmt [69821,69849]
===
match
---
arith_expr [31834,31866]
arith_expr [31865,31897]
===
match
---
assert_stmt [66574,66622]
assert_stmt [68198,68246]
===
match
---
arglist [34987,35022]
arglist [35018,35053]
===
match
---
name: query [35400,35405]
name: query [35431,35436]
===
match
---
operator: , [56816,56817]
operator: , [56847,56848]
===
match
---
operator: = [47089,47090]
operator: = [47120,47121]
===
match
---
name: DEPRECATED_ACTION_CAN_DAG_EDIT [66178,66208]
name: DEPRECATED_ACTION_CAN_DAG_EDIT [67802,67832]
===
match
---
expr_stmt [63106,63163]
expr_stmt [63137,63194]
===
match
---
operator: } [11619,11620]
operator: } [11650,11651]
===
match
---
operator: , [63699,63700]
operator: , [65323,65324]
===
match
---
name: session [52595,52602]
name: session [52626,52633]
===
match
---
trailer [74855,74874]
trailer [76479,76498]
===
match
---
simple_stmt [24525,24562]
simple_stmt [24556,24593]
===
match
---
argument [41157,41169]
argument [41188,41200]
===
match
---
atom_expr [37067,37083]
atom_expr [37098,37114]
===
match
---
atom_expr [27057,27090]
atom_expr [27088,27121]
===
match
---
trailer [73687,73693]
trailer [75311,75317]
===
match
---
operator: = [28098,28099]
operator: = [28129,28130]
===
match
---
operator: * [15801,15802]
operator: * [15832,15833]
===
match
---
name: dag [56167,56170]
name: dag [56198,56201]
===
match
---
name: create_dagrun [51367,51380]
name: create_dagrun [51398,51411]
===
match
---
name: task_1 [76688,76694]
name: task_1 [78312,78318]
===
match
---
atom_expr [44033,44049]
atom_expr [44064,44080]
===
match
---
operator: , [26111,26112]
operator: , [26142,26143]
===
match
---
atom_expr [41088,41124]
atom_expr [41119,41155]
===
match
---
name: DEFAULT_DATE [47848,47860]
name: DEFAULT_DATE [47879,47891]
===
match
---
operator: , [19559,19560]
operator: , [19590,19591]
===
match
---
expr_stmt [25521,25552]
expr_stmt [25552,25583]
===
match
---
testlist_comp [48274,48333]
testlist_comp [48305,48364]
===
match
---
name: self [27221,27225]
name: self [27252,27256]
===
match
---
simple_stmt [51180,51220]
simple_stmt [51211,51251]
===
match
---
name: create_session [45174,45188]
name: create_session [45205,45219]
===
match
---
decorator [72447,72463]
decorator [74071,74087]
===
match
---
argument [53090,53113]
argument [53121,53144]
===
match
---
simple_stmt [25368,25462]
simple_stmt [25399,25493]
===
match
---
atom_expr [31755,31797]
atom_expr [31786,31828]
===
match
---
dictorsetmaker [4638,4653]
dictorsetmaker [4669,4684]
===
match
---
string: "2018-10-28T02:55:00+02:00" [23056,23083]
string: "2018-10-28T02:55:00+02:00" [23087,23114]
===
match
---
name: session [19585,19592]
name: session [19616,19623]
===
match
---
operator: , [42663,42664]
operator: , [42694,42695]
===
match
---
name: start_date [8466,8476]
name: start_date [8497,8507]
===
match
---
trailer [78903,78929]
trailer [80527,80553]
===
match
---
arglist [9223,9262]
arglist [9254,9293]
===
match
---
operator: = [38333,38334]
operator: = [38364,38365]
===
match
---
atom_expr [42590,42608]
atom_expr [42621,42639]
===
match
---
operator: = [46128,46129]
operator: = [46159,46160]
===
match
---
trailer [40924,40931]
trailer [40955,40962]
===
match
---
suite [56070,57288]
suite [56101,57319]
===
match
---
name: default_view [33485,33497]
name: default_view [33516,33528]
===
match
---
number: 0 [15194,15195]
number: 0 [15225,15226]
===
match
---
testlist_comp [77702,78615]
testlist_comp [79326,80239]
===
match
---
atom_expr [27722,27794]
atom_expr [27753,27825]
===
match
---
parameters [27264,27274]
parameters [27295,27305]
===
match
---
atom_expr [18967,19051]
atom_expr [18998,19082]
===
match
---
atom_expr [74895,74909]
atom_expr [76519,76533]
===
match
---
name: State [18578,18583]
name: State [18609,18614]
===
match
---
operator: = [34436,34437]
operator: = [34467,34468]
===
match
---
operator: , [77686,77687]
operator: , [79310,79311]
===
match
---
name: session [30176,30183]
name: session [30207,30214]
===
match
---
trailer [59508,59531]
trailer [59539,59562]
===
match
---
atom_expr [18375,18385]
atom_expr [18406,18416]
===
match
---
decorated [71548,71624]
decorated [73172,73248]
===
match
---
atom_expr [15860,15886]
atom_expr [15891,15917]
===
match
---
simple_stmt [1891,1932]
simple_stmt [1897,1938]
===
match
---
string: "t1" [41110,41114]
string: "t1" [41141,41145]
===
match
---
suite [72933,73053]
suite [74557,74677]
===
match
---
assert_stmt [7087,7115]
assert_stmt [7118,7146]
===
match
---
atom_expr [53430,53446]
atom_expr [53461,53477]
===
match
---
simple_stmt [17665,17727]
simple_stmt [17696,17758]
===
match
---
simple_stmt [70663,70852]
simple_stmt [72287,72476]
===
match
---
expr_stmt [18429,18472]
expr_stmt [18460,18503]
===
match
---
number: 5 [16141,16142]
number: 5 [16172,16173]
===
match
---
name: one [37846,37849]
name: one [37877,37880]
===
match
---
name: template_ext [21891,21903]
name: template_ext [21922,21934]
===
match
---
operator: = [60786,60787]
operator: = [60817,60818]
===
match
---
expr_stmt [76514,76557]
expr_stmt [78138,78181]
===
match
---
assert_stmt [14524,14566]
assert_stmt [14555,14597]
===
match
---
argument [35314,35328]
argument [35345,35359]
===
match
---
trailer [66315,66331]
trailer [67939,67955]
===
match
---
argument [77423,77438]
argument [79047,79062]
===
match
---
name: op9 [7885,7888]
name: op9 [7916,7919]
===
match
---
operator: = [59493,59494]
operator: = [59524,59525]
===
match
---
simple_stmt [22819,22855]
simple_stmt [22850,22886]
===
match
---
trailer [78004,78013]
trailer [79628,79637]
===
match
---
operator: = [65619,65620]
operator: = [67243,67244]
===
match
---
assert_stmt [57120,57151]
assert_stmt [57151,57182]
===
match
---
name: test_task_id [19518,19530]
name: test_task_id [19549,19561]
===
match
---
arglist [56177,56227]
arglist [56208,56258]
===
match
---
name: State [52270,52275]
name: State [52301,52306]
===
match
---
operator: , [64345,64346]
operator: , [65969,65970]
===
match
---
name: path [21593,21597]
name: path [21624,21628]
===
match
---
atom_expr [7026,7035]
atom_expr [7057,7066]
===
match
---
name: dag [31002,31005]
name: dag [31033,31036]
===
match
---
funcdef [71159,71196]
funcdef [72783,72820]
===
match
---
operator: = [49466,49467]
operator: = [49497,49498]
===
match
---
param [20746,20750]
param [20777,20781]
===
match
---
expr_stmt [31487,31671]
expr_stmt [31518,31702]
===
match
---
atom_expr [72316,72333]
atom_expr [73940,73957]
===
match
---
trailer [19618,19624]
trailer [19649,19655]
===
match
---
string: "string" [66925,66933]
string: "string" [68549,68557]
===
match
---
param [40318,40322]
param [40349,40353]
===
match
---
trailer [40060,40069]
trailer [40091,40100]
===
match
---
name: mock_callback_with_exception [43861,43889]
name: mock_callback_with_exception [43892,43920]
===
match
---
operator: , [9094,9095]
operator: , [9125,9126]
===
match
---
name: op1 [10720,10723]
name: op1 [10751,10754]
===
match
---
trailer [51054,51063]
trailer [51085,51094]
===
match
---
string: 'subtask' [33645,33654]
string: 'subtask' [33676,33685]
===
match
---
name: topological_list [10036,10052]
name: topological_list [10067,10083]
===
match
---
trailer [23953,23955]
trailer [23984,23986]
===
match
---
name: session [18718,18725]
name: session [18749,18756]
===
match
---
trailer [2864,2866]
trailer [2895,2897]
===
match
---
trailer [39596,39608]
trailer [39627,39639]
===
match
---
name: start_date [56185,56195]
name: start_date [56216,56226]
===
match
---
expr_stmt [36495,36557]
expr_stmt [36526,36588]
===
match
---
operator: , [54098,54099]
operator: , [54129,54130]
===
match
---
name: set [33120,33123]
name: set [33151,33154]
===
match
---
simple_stmt [34409,34424]
simple_stmt [34440,34455]
===
match
---
name: run [47212,47215]
name: run [47243,47246]
===
match
---
operator: = [46924,46925]
operator: = [46955,46956]
===
match
---
name: models [6328,6334]
name: models [6359,6365]
===
match
---
expr_stmt [57612,57669]
expr_stmt [57643,57700]
===
match
---
operator: = [41984,41985]
operator: = [42015,42016]
===
match
---
number: 1 [77817,77818]
number: 1 [79441,79442]
===
match
---
name: prev_local [22978,22988]
name: prev_local [23009,23019]
===
match
---
name: depth [14753,14758]
name: depth [14784,14789]
===
match
---
operator: , [69116,69117]
operator: , [70740,70741]
===
match
---
name: task_id [7721,7728]
name: task_id [7752,7759]
===
match
---
trailer [10487,10500]
trailer [10518,10531]
===
match
---
funcdef [71757,72165]
funcdef [73381,73789]
===
match
---
operator: , [21647,21648]
operator: , [21678,21679]
===
match
---
name: DEFAULT_DATE [56196,56208]
name: DEFAULT_DATE [56227,56239]
===
match
---
simple_stmt [10513,10546]
simple_stmt [10544,10577]
===
match
---
return_stmt [72017,72027]
return_stmt [73641,73651]
===
match
---
assert_stmt [27874,28022]
assert_stmt [27905,28053]
===
match
---
operator: = [61653,61654]
operator: = [61684,61685]
===
match
---
operator: = [38857,38858]
operator: = [38888,38889]
===
match
---
expr_stmt [25561,25610]
expr_stmt [25592,25641]
===
match
---
name: test_dag_id [47537,47548]
name: test_dag_id [47568,47579]
===
match
---
operator: { [4637,4638]
operator: { [4668,4669]
===
match
---
name: list_py_file_paths [2112,2130]
name: list_py_file_paths [2143,2161]
===
match
---
name: start_date [17632,17642]
name: start_date [17663,17673]
===
match
---
trailer [73400,73406]
trailer [75024,75030]
===
match
---
name: dag [51363,51366]
name: dag [51394,51397]
===
match
---
name: set [36046,36049]
name: set [36077,36080]
===
match
---
trailer [29927,29976]
trailer [29958,30007]
===
match
---
atom_expr [63219,63248]
atom_expr [63250,63279]
===
match
---
name: isinstance [45885,45895]
name: isinstance [45916,45926]
===
match
---
simple_stmt [4627,4655]
simple_stmt [4658,4686]
===
match
---
name: jinja_env [20452,20461]
name: jinja_env [20483,20492]
===
match
---
simple_stmt [39105,39141]
simple_stmt [39136,39172]
===
match
---
name: _occur_before [9134,9147]
name: _occur_before [9165,9178]
===
match
---
name: self [73892,73896]
name: self [75516,75520]
===
match
---
trailer [32820,32830]
trailer [32851,32861]
===
match
---
simple_stmt [62922,62999]
simple_stmt [62953,63030]
===
match
---
name: session [54775,54782]
name: session [54806,54813]
===
match
---
name: interval [58740,58748]
name: interval [58771,58779]
===
match
---
string: "@once" [46764,46771]
string: "@once" [46795,46802]
===
match
---
argument [68081,68121]
argument [69705,69745]
===
match
---
operator: , [69587,69588]
operator: , [71211,71212]
===
match
---
suite [40841,41255]
suite [40872,41286]
===
match
---
operator: , [26194,26195]
operator: , [26225,26226]
===
match
---
dictorsetmaker [6837,6854]
dictorsetmaker [6868,6885]
===
match
---
name: RUNNING [56445,56452]
name: RUNNING [56476,56483]
===
match
---
name: DEFAULT_DATE [17915,17927]
name: DEFAULT_DATE [17946,17958]
===
match
---
suite [13028,13231]
suite [13059,13262]
===
match
---
simple_stmt [17396,17456]
simple_stmt [17427,17487]
===
match
---
name: dag_id [65358,65364]
name: dag_id [66982,66988]
===
match
---
name: DummyOperator [40582,40595]
name: DummyOperator [40613,40626]
===
match
---
arglist [66965,67045]
arglist [68589,68669]
===
match
---
operator: , [35091,35092]
operator: , [35122,35123]
===
match
---
string: 'start_date' [12412,12424]
string: 'start_date' [12443,12455]
===
match
---
string: 'test-dag' [4120,4130]
string: 'test-dag' [4151,4161]
===
match
---
atom_expr [50919,50965]
atom_expr [50950,50996]
===
match
---
atom_expr [57897,57924]
atom_expr [57928,57955]
===
match
---
atom_expr [66122,66164]
atom_expr [67746,67788]
===
match
---
param [69768,69773]
param [71392,71397]
===
match
---
name: dag_id [44787,44793]
name: dag_id [44818,44824]
===
match
---
expr_stmt [47577,47602]
expr_stmt [47608,47633]
===
match
---
assert_stmt [62770,62846]
assert_stmt [62801,62877]
===
match
---
name: local_tz [23332,23340]
name: local_tz [23363,23371]
===
match
---
string: 'DAG' [38475,38480]
string: 'DAG' [38506,38511]
===
match
---
simple_stmt [28993,29020]
simple_stmt [29024,29051]
===
match
---
name: task_id [39331,39338]
name: task_id [39362,39369]
===
match
---
string: """         Make sure DST transitions are properly observed         """ [24288,24359]
string: """         Make sure DST transitions are properly observed         """ [24319,24390]
===
match
---
name: return_num [75252,75262]
name: return_num [76876,76886]
===
match
---
trailer [32990,33002]
trailer [33021,33033]
===
match
---
name: dt [27271,27273]
name: dt [27302,27304]
===
match
---
simple_stmt [7192,7215]
simple_stmt [7223,7246]
===
match
---
name: task_id [56144,56151]
name: task_id [56175,56182]
===
match
---
operator: = [62445,62446]
operator: = [62476,62477]
===
match
---
name: get_num_task_instances [19468,19490]
name: get_num_task_instances [19499,19521]
===
match
---
trailer [32720,32724]
trailer [32751,32755]
===
match
---
name: test_dag_id [18901,18912]
name: test_dag_id [18932,18943]
===
match
---
simple_stmt [39449,39483]
simple_stmt [39480,39514]
===
match
---
trailer [35462,35535]
trailer [35493,35566]
===
match
---
atom_expr [72536,72549]
atom_expr [74160,74173]
===
match
---
simple_stmt [76408,76453]
simple_stmt [78032,78077]
===
match
---
name: settings [36576,36584]
name: settings [36607,36615]
===
match
---
name: return_num [72479,72489]
name: return_num [74103,74113]
===
match
---
atom_expr [60788,60970]
atom_expr [60819,61001]
===
match
---
funcdef [63254,64358]
funcdef [64878,65982]
===
match
---
operator: @ [55037,55038]
operator: @ [55068,55069]
===
match
---
name: subdag [34313,34319]
name: subdag [34344,34350]
===
match
---
name: ti2 [18395,18398]
name: ti2 [18426,18429]
===
match
---
trailer [53827,53834]
trailer [53858,53865]
===
match
---
simple_stmt [1789,1839]
simple_stmt [1795,1845]
===
match
---
string: 'dag-bulk-sync-0' [28537,28554]
string: 'dag-bulk-sync-0' [28568,28585]
===
match
---
name: paused_dags [35755,35766]
name: paused_dags [35786,35797]
===
match
---
atom_expr [10754,10775]
atom_expr [10785,10806]
===
match
---
name: dr2 [18375,18378]
name: dr2 [18406,18409]
===
match
---
operator: = [74504,74505]
operator: = [76128,76129]
===
match
---
trailer [20825,20831]
trailer [20856,20862]
===
match
---
atom_expr [3717,3733]
atom_expr [3748,3764]
===
match
---
argument [78627,78679]
argument [80251,80303]
===
match
---
operator: , [39134,39135]
operator: , [39165,39166]
===
match
---
decorator [3141,3155]
decorator [3172,3186]
===
match
---
atom_expr [63585,63757]
atom_expr [65209,65381]
===
match
---
name: convert [23616,23623]
name: convert [23647,23654]
===
match
---
operator: = [78630,78631]
operator: = [80254,80255]
===
match
---
fstring [64949,64981]
fstring [66573,66605]
===
match
---
trailer [18134,18148]
trailer [18165,18179]
===
match
---
name: hours [59681,59686]
name: hours [59712,59717]
===
match
---
argument [9674,9685]
argument [9705,9716]
===
match
---
name: test_clear_set_dagrun_state [51651,51678]
name: test_clear_set_dagrun_state [51682,51709]
===
match
---
name: dag_id [59916,59922]
name: dag_id [59947,59953]
===
match
---
name: tearDown [70026,70034]
name: tearDown [71650,71658]
===
match
---
name: sync_to_db [33878,33888]
name: sync_to_db [33909,33919]
===
match
---
name: stdout_lines [40146,40158]
name: stdout_lines [40177,40189]
===
match
---
trailer [15631,15639]
trailer [15662,15670]
===
match
---
simple_stmt [58818,58945]
simple_stmt [58849,58976]
===
match
---
atom_expr [55083,55093]
atom_expr [55114,55124]
===
match
---
name: start [58604,58609]
name: start [58635,58640]
===
match
---
operator: = [44994,44995]
operator: = [45025,45026]
===
match
---
number: 2015 [61572,61576]
number: 2015 [61603,61607]
===
match
---
name: TEST_DATE [43055,43064]
name: TEST_DATE [43086,43095]
===
match
---
fstring_expr [50809,50835]
fstring_expr [50840,50866]
===
match
---
expr_stmt [50673,50770]
expr_stmt [50704,50801]
===
match
---
simple_stmt [5226,5265]
simple_stmt [5257,5296]
===
match
---
argument [18539,18556]
argument [18570,18587]
===
match
---
name: test_following_schedule_relativedelta [25315,25352]
name: test_following_schedule_relativedelta [25346,25383]
===
match
---
operator: = [31147,31148]
operator: = [31178,31179]
===
match
---
operator: = [25527,25528]
operator: = [25558,25559]
===
match
---
name: dag [27476,27479]
name: dag [27507,27510]
===
match
---
operator: = [51868,51869]
operator: = [51899,51900]
===
match
---
testlist_comp [77716,77822]
testlist_comp [79340,79446]
===
match
---
atom [41236,41254]
atom [41267,41285]
===
match
---
suite [70937,70991]
suite [72561,72615]
===
match
---
trailer [69235,69256]
trailer [70859,70880]
===
match
---
name: synchronize_session [34857,34876]
name: synchronize_session [34888,34907]
===
match
---
operator: - [77869,77870]
operator: - [79493,79494]
===
match
---
number: 1 [57150,57151]
number: 1 [57181,57182]
===
match
---
fstring_expr [13767,13770]
fstring_expr [13798,13801]
===
match
---
name: dag [7007,7010]
name: dag [7038,7041]
===
match
---
name: DagModel [68244,68252]
name: DagModel [69868,69876]
===
match
---
suite [15588,15946]
suite [15619,15977]
===
match
---
atom_expr [49550,49579]
atom_expr [49581,49610]
===
match
---
trailer [18398,18404]
trailer [18429,18435]
===
match
---
name: undefined [20673,20682]
name: undefined [20704,20713]
===
match
---
operator: , [28554,28555]
operator: , [28585,28586]
===
match
---
name: test_task [18443,18452]
name: test_task [18474,18483]
===
match
---
atom [66355,66413]
atom [67979,68037]
===
match
---
operator: = [26586,26587]
operator: = [26617,26618]
===
match
---
operator: , [43827,43828]
operator: , [43858,43859]
===
match
---
name: str [3181,3184]
name: str [3212,3215]
===
match
---
operator: , [52404,52405]
operator: , [52435,52436]
===
match
---
param [70205,70216]
param [71829,71840]
===
match
---
expr_stmt [17665,17726]
expr_stmt [17696,17757]
===
match
---
name: topological_list [9950,9966]
name: topological_list [9981,9997]
===
match
---
trailer [29469,29473]
trailer [29500,29504]
===
match
---
operator: = [8381,8382]
operator: = [8412,8413]
===
match
---
trailer [55650,55689]
trailer [55681,55720]
===
match
---
name: dag [9790,9793]
name: dag [9821,9824]
===
match
---
funcdef [73370,73585]
funcdef [74994,75209]
===
match
---
arglist [77763,77819]
arglist [79387,79443]
===
match
---
operator: , [2650,2651]
operator: , [2681,2682]
===
match
---
arglist [42757,42858]
arglist [42788,42889]
===
match
---
name: run_id [50789,50795]
name: run_id [50820,50826]
===
match
---
atom [4637,4654]
atom [4668,4685]
===
match
---
trailer [40158,40161]
trailer [40189,40192]
===
match
---
argument [27770,27793]
argument [27801,27824]
===
match
---
name: session [68197,68204]
name: session [69821,69828]
===
match
---
name: dag_id [37523,37529]
name: dag_id [37554,37560]
===
match
---
number: 2 [67731,67732]
number: 2 [69355,69356]
===
match
---
name: session [19273,19280]
name: session [19304,19311]
===
match
---
operator: == [15347,15349]
operator: == [15378,15380]
===
match
---
name: task [21886,21890]
name: task [21917,21921]
===
match
---
string: """         Tests scheduling a dag scheduled for @once - should be scheduled the first time         it is called, and not scheduled the second.         """ [45612,45767]
string: """         Tests scheduling a dag scheduled for @once - should be scheduled the first time         it is called, and not scheduled the second.         """ [45643,45798]
===
match
---
trailer [60299,60306]
trailer [60330,60337]
===
match
---
expr_stmt [45776,45809]
expr_stmt [45807,45840]
===
match
---
simple_stmt [68808,68865]
simple_stmt [70432,70489]
===
match
---
name: dag [7450,7453]
name: dag [7481,7484]
===
match
---
suite [13930,14145]
suite [13961,14176]
===
match
---
funcdef [76089,76355]
funcdef [77713,77979]
===
match
---
return_stmt [3861,3890]
return_stmt [3892,3921]
===
match
---
simple_stmt [63172,63249]
simple_stmt [63203,63280]
===
match
---
name: local_tz [22610,22618]
name: local_tz [22641,22649]
===
match
---
string: "Task id 't1' has already been added to the DAG" [40960,41008]
string: "Task id 't1' has already been added to the DAG" [40991,41039]
===
match
---
name: dag [10840,10843]
name: dag [10871,10874]
===
match
---
comparison [77210,77252]
comparison [78834,78876]
===
match
---
atom_expr [51025,51035]
atom_expr [51056,51066]
===
match
---
suite [36970,37186]
suite [37001,37217]
===
match
---
arglist [53362,53388]
arglist [53393,53419]
===
match
---
expr_stmt [34943,35145]
expr_stmt [34974,35176]
===
match
---
operator: , [55125,55126]
operator: , [55156,55157]
===
match
---
simple_stmt [1640,1692]
simple_stmt [1646,1698]
===
match
---
comparison [28881,28899]
comparison [28912,28930]
===
match
---
number: 1 [61798,61799]
number: 1 [61829,61830]
===
match
---
name: task_id [41687,41694]
name: task_id [41718,41725]
===
match
---
name: op3 [39074,39077]
name: op3 [39105,39108]
===
match
---
assert_stmt [38517,38558]
assert_stmt [38548,38589]
===
match
---
arglist [61792,61802]
arglist [61823,61833]
===
match
---
name: DagModel [29453,29461]
name: DagModel [29484,29492]
===
match
---
parameters [14626,14632]
parameters [14657,14663]
===
match
---
name: task_id [56257,56264]
name: task_id [56288,56295]
===
match
---
atom_expr [26562,26622]
atom_expr [26593,26653]
===
match
---
atom_expr [7891,7919]
atom_expr [7922,7950]
===
match
---
trailer [69885,69902]
trailer [71509,71526]
===
match
---
dictorsetmaker [41734,41768]
dictorsetmaker [41765,41799]
===
match
---
dictorsetmaker [65380,65408]
dictorsetmaker [67004,67032]
===
match
---
atom [35205,35223]
atom [35236,35254]
===
match
---
operator: , [50388,50389]
operator: , [50419,50420]
===
match
---
string: 'test-invalid-default_view' [5527,5554]
string: 'test-invalid-default_view' [5558,5585]
===
match
---
trailer [10174,10177]
trailer [10205,10208]
===
match
---
expr_stmt [76846,76874]
expr_stmt [78470,78498]
===
match
---
number: 1 [11098,11099]
number: 1 [11129,11130]
===
match
---
simple_stmt [50519,50562]
simple_stmt [50550,50593]
===
match
---
operator: , [76702,76703]
operator: , [78326,78327]
===
match
---
operator: , [66894,66895]
operator: , [68518,68519]
===
match
---
operator: = [70274,70275]
operator: = [71898,71899]
===
match
---
name: session [36865,36872]
name: session [36896,36903]
===
match
---
name: State [54022,54027]
name: State [54053,54058]
===
match
---
simple_stmt [24959,25020]
simple_stmt [24990,25051]
===
match
---
name: xcom_pass_to_op [73600,73615]
name: xcom_pass_to_op [75224,75239]
===
match
---
trailer [10878,10883]
trailer [10909,10914]
===
match
---
name: end_date [52418,52426]
name: end_date [52449,52457]
===
match
---
simple_stmt [68451,68472]
simple_stmt [70075,70096]
===
match
---
trailer [17353,17360]
trailer [17384,17391]
===
match
---
argument [68162,68169]
argument [69786,69793]
===
match
---
trailer [69489,69491]
trailer [71113,71115]
===
match
---
name: self [63292,63296]
name: self [64916,64920]
===
match
---
simple_stmt [51756,51779]
simple_stmt [51787,51810]
===
match
---
simple_stmt [1839,1891]
simple_stmt [1845,1897]
===
match
---
string: 'Also fake' [43988,43999]
string: 'Also fake' [44019,44030]
===
match
---
string: "0 0 1 * *" [50067,50078]
string: "0 0 1 * *" [50098,50109]
===
match
---
name: task [18523,18527]
name: task [18554,18558]
===
match
---
operator: = [18937,18938]
operator: = [18968,18969]
===
match
---
atom_expr [32156,32201]
atom_expr [32187,32232]
===
match
---
atom [69683,69719]
atom [71307,71343]
===
match
---
trailer [32226,32313]
trailer [32257,32344]
===
match
---
name: raises [66958,66964]
name: raises [68582,68588]
===
match
---
operator: , [61799,61800]
operator: , [61830,61831]
===
match
---
comparison [40181,40204]
comparison [40212,40235]
===
match
---
simple_stmt [25093,25129]
simple_stmt [25124,25160]
===
match
---
name: timetable [45900,45909]
name: timetable [45931,45940]
===
match
---
name: dag_id [53209,53215]
name: dag_id [53240,53246]
===
match
---
trailer [8022,8026]
trailer [8053,8057]
===
match
---
name: self [19669,19673]
name: self [19700,19704]
===
match
---
name: DagRun [52745,52751]
name: DagRun [52776,52782]
===
match
---
argument [44255,44268]
argument [44286,44299]
===
match
---
name: SCHEDULED [42777,42786]
name: SCHEDULED [42808,42817]
===
match
---
assert_stmt [54968,55004]
assert_stmt [54999,55035]
===
match
---
expr_stmt [14771,14813]
expr_stmt [14802,14844]
===
match
---
trailer [27313,27318]
trailer [27344,27349]
===
match
---
trailer [70833,70844]
trailer [72457,72468]
===
match
---
trailer [18993,19051]
trailer [19024,19082]
===
match
---
suite [74289,74317]
suite [75913,75941]
===
match
---
name: sync_to_db [27807,27817]
name: sync_to_db [27838,27848]
===
match
---
name: BACKFILL_JOB [56407,56419]
name: BACKFILL_JOB [56438,56450]
===
match
---
operator: , [30426,30427]
operator: , [30457,30458]
===
match
---
name: dag_id [35070,35076]
name: dag_id [35101,35107]
===
match
---
testlist_comp [13737,13867]
testlist_comp [13768,13898]
===
match
---
trailer [22724,22734]
trailer [22755,22765]
===
match
---
name: SKIPPED [76599,76606]
name: SKIPPED [78223,78230]
===
match
---
simple_stmt [18637,18656]
simple_stmt [18668,18687]
===
match
---
simple_stmt [22597,22634]
simple_stmt [22628,22665]
===
match
---
name: timedelta [59798,59807]
name: timedelta [59829,59838]
===
match
---
name: DummyOperator [8612,8625]
name: DummyOperator [8643,8656]
===
match
---
operator: == [67919,67921]
operator: == [69543,69545]
===
match
---
name: dag [59472,59475]
name: dag [59503,59506]
===
match
---
name: next_dagrun [46438,46449]
name: next_dagrun [46469,46480]
===
match
---
name: TI [18272,18274]
name: TI [18303,18305]
===
match
---
name: start_date [65104,65114]
name: start_date [66728,66738]
===
match
---
name: DEFAULT_DATE [41439,41451]
name: DEFAULT_DATE [41470,41482]
===
match
---
with_stmt [21406,21963]
with_stmt [21437,21994]
===
match
---
string: '' [43005,43007]
string: '' [43036,43038]
===
match
---
number: 2018 [23367,23371]
number: 2018 [23398,23402]
===
match
---
name: run [46920,46923]
name: run [46951,46954]
===
match
---
name: dag [78875,78878]
name: dag [80499,80502]
===
match
---
atom [12411,12489]
atom [12442,12520]
===
match
---
atom [31270,31275]
atom [31301,31306]
===
match
---
trailer [66854,66858]
trailer [68478,68482]
===
match
---
operator: = [47811,47812]
operator: = [47842,47843]
===
match
---
simple_stmt [54415,54444]
simple_stmt [54446,54475]
===
match
---
operator: = [3790,3791]
operator: = [3821,3822]
===
match
---
name: filter [27960,27966]
name: filter [27991,27997]
===
match
---
simple_stmt [51880,51926]
simple_stmt [51911,51957]
===
match
---
trailer [62007,62020]
trailer [62038,62051]
===
match
---
testlist [54215,54226]
testlist [54246,54257]
===
match
---
atom [16205,16224]
atom [16236,16255]
===
match
---
import_from [1741,1788]
import_from [1747,1794]
===
match
---
string: 'parent_dag' [8400,8412]
string: 'parent_dag' [8431,8443]
===
match
---
operator: } [15024,15025]
operator: } [15055,15056]
===
match
---
name: relativedelta [25529,25542]
name: relativedelta [25560,25573]
===
match
---
argument [8171,8197]
argument [8202,8228]
===
match
---
name: enumerate [15305,15314]
name: enumerate [15336,15345]
===
match
---
argument [65104,65144]
argument [66728,66768]
===
match
---
trailer [38169,38179]
trailer [38200,38210]
===
match
---
trailer [63671,63680]
trailer [65295,65304]
===
match
---
trailer [47600,47602]
trailer [47631,47633]
===
match
---
simple_stmt [25768,25824]
simple_stmt [25799,25855]
===
match
---
simple_stmt [62856,62914]
simple_stmt [62887,62945]
===
match
---
string: """         Test invalid `orientation` of DAG initialization         """ [5919,5991]
string: """         Test invalid `orientation` of DAG initialization         """ [5950,6022]
===
match
---
name: DAG [71713,71716]
name: DAG [73337,73340]
===
match
---
funcdef [74000,74921]
funcdef [75624,76545]
===
match
---
name: create_session [46324,46338]
name: create_session [46355,46369]
===
match
---
name: dag [46402,46405]
name: dag [46433,46436]
===
match
---
parameters [11816,11822]
parameters [11847,11853]
===
match
---
trailer [76987,76993]
trailer [78611,78617]
===
match
---
atom [11029,11039]
atom [11060,11070]
===
match
---
name: last_parsed_time [30709,30725]
name: last_parsed_time [30740,30756]
===
match
---
simple_stmt [65635,65681]
simple_stmt [67259,67305]
===
match
---
name: half_an_hour_ago [59764,59780]
name: half_an_hour_ago [59795,59811]
===
match
---
trailer [53477,53479]
trailer [53508,53510]
===
match
---
trailer [62977,62986]
trailer [63008,63017]
===
match
---
name: f [21607,21608]
name: f [21638,21639]
===
match
---
name: prev_local [22871,22881]
name: prev_local [22902,22912]
===
match
---
comparison [79064,79096]
comparison [80688,80720]
===
match
---
name: dag [39294,39297]
name: dag [39325,39328]
===
match
---
name: db [2504,2506]
name: db [2535,2537]
===
match
---
trailer [3456,3463]
trailer [3487,3494]
===
match
---
name: in_ [35496,35499]
name: in_ [35527,35530]
===
match
---
name: dag_decorator [72289,72302]
name: dag_decorator [73913,73926]
===
match
---
name: task_instances [56930,56944]
name: task_instances [56961,56975]
===
match
---
argument [66872,66894]
argument [68496,68518]
===
match
---
atom_expr [63977,64151]
atom_expr [65601,65775]
===
match
---
operator: = [59461,59462]
operator: = [59492,59493]
===
match
---
number: 6 [59687,59688]
number: 6 [59718,59719]
===
match
---
simple_stmt [52209,52285]
simple_stmt [52240,52316]
===
match
---
trailer [35796,35833]
trailer [35827,35864]
===
match
---
string: 'dag-bulk-sync-1' [30459,30476]
string: 'dag-bulk-sync-1' [30490,30507]
===
match
---
operator: == [33003,33005]
operator: == [33034,33036]
===
match
---
expr_stmt [57984,58026]
expr_stmt [58015,58057]
===
match
---
operator: == [25212,25214]
operator: == [25243,25245]
===
match
---
name: dag [20546,20549]
name: dag [20577,20580]
===
match
---
expr_stmt [27144,27159]
expr_stmt [27175,27190]
===
match
---
atom [13160,13180]
atom [13191,13211]
===
match
---
string: "@quarterly" [50095,50107]
string: "@quarterly" [50126,50138]
===
match
---
string: '0 3 * * *' [24627,24638]
string: '0 3 * * *' [24658,24669]
===
match
---
trailer [38416,38425]
trailer [38447,38456]
===
match
---
dictorsetmaker [17309,17326]
dictorsetmaker [17340,17357]
===
match
---
name: task [21225,21229]
name: task [21256,21260]
===
match
---
operator: { [29323,29324]
operator: { [29354,29355]
===
match
---
expr_stmt [32467,32490]
expr_stmt [32498,32521]
===
match
---
name: dag [36197,36200]
name: dag [36228,36231]
===
match
---
trailer [37003,37053]
trailer [37034,37084]
===
match
---
arglist [51120,51170]
arglist [51151,51201]
===
match
---
atom_expr [76360,76388]
atom_expr [77984,78012]
===
match
---
trailer [35431,35441]
trailer [35462,35472]
===
match
---
name: next_info [62704,62713]
name: next_info [62735,62744]
===
match
---
name: Session [37644,37651]
name: Session [37675,37682]
===
match
---
operator: , [55389,55390]
operator: , [55420,55421]
===
match
---
string: "t1" [41165,41169]
string: "t1" [41196,41200]
===
match
---
operator: { [47813,47814]
operator: { [47844,47845]
===
match
---
atom_expr [44084,44167]
atom_expr [44115,44198]
===
match
---
import_from [2482,2542]
import_from [2513,2573]
===
match
---
operator: , [45841,45842]
operator: , [45872,45873]
===
match
---
expr_stmt [49601,49655]
expr_stmt [49632,49686]
===
match
---
operator: = [69334,69335]
operator: = [70958,70959]
===
match
---
atom_expr [26896,26911]
atom_expr [26927,26942]
===
match
---
argument [15007,15030]
argument [15038,15061]
===
match
---
operator: , [36000,36001]
operator: , [36031,36032]
===
match
---
name: return_num [72978,72988]
name: return_num [74602,74612]
===
match
---
trailer [3214,3216]
trailer [3245,3247]
===
match
---
atom_expr [43616,43656]
atom_expr [43647,43687]
===
match
---
param [72989,72992]
param [74613,74616]
===
match
---
testlist_comp [28635,28664]
testlist_comp [28666,28695]
===
match
---
name: next_dagrun_create_after [45484,45508]
name: next_dagrun_create_after [45515,45539]
===
match
---
operator: , [49900,49901]
operator: , [49931,49932]
===
match
---
name: task_id [45960,45967]
name: task_id [45991,45998]
===
match
---
dotted_name [2548,2575]
dotted_name [2579,2606]
===
match
---
name: hours [78253,78258]
name: hours [79877,79882]
===
match
---
name: dag [54215,54218]
name: dag [54246,54249]
===
match
---
name: local_tz [22832,22840]
name: local_tz [22863,22871]
===
match
---
name: minute [59712,59718]
name: minute [59743,59749]
===
match
---
name: set [39112,39115]
name: set [39143,39146]
===
match
---
trailer [17409,17455]
trailer [17440,17486]
===
match
---
string: 'dag' [33975,33980]
string: 'dag' [34006,34011]
===
match
---
comparison [49550,49591]
comparison [49581,49622]
===
match
---
string: "test_schedule_dag_no_previous_runs" [42539,42575]
string: "test_schedule_dag_no_previous_runs" [42570,42606]
===
match
---
name: DAG [11685,11688]
name: DAG [11716,11719]
===
match
---
name: session [56961,56968]
name: session [56992,56999]
===
match
---
operator: = [73342,73343]
operator: = [74966,74967]
===
match
---
trailer [26641,26660]
trailer [26672,26691]
===
match
---
operator: , [72642,72643]
operator: , [74266,74267]
===
match
---
name: used_group_ids [42379,42393]
name: used_group_ids [42410,42424]
===
match
---
name: dag [45818,45821]
name: dag [45849,45852]
===
match
---
trailer [70888,70900]
trailer [72512,72524]
===
match
---
comparison [22714,22767]
comparison [22745,22798]
===
match
---
name: dag [74462,74465]
name: dag [76086,76089]
===
match
---
name: task_5 [77365,77371]
name: task_5 [78989,78995]
===
match
---
param [6220,6224]
param [6251,6255]
===
match
---
string: "retry_delay" [70809,70822]
string: "retry_delay" [72433,72446]
===
match
---
operator: = [38469,38470]
operator: = [38500,38501]
===
match
---
operator: , [60530,60531]
operator: , [60561,60562]
===
match
---
name: unittest [1047,1055]
name: unittest [1053,1061]
===
match
---
name: DAG [28244,28247]
name: DAG [28275,28278]
===
match
---
name: timezone [22183,22191]
name: timezone [22214,22222]
===
match
---
operator: , [70556,70557]
operator: , [72180,72181]
===
match
---
name: run_id [67095,67101]
name: run_id [68719,68725]
===
match
---
trailer [74443,74452]
trailer [76067,76076]
===
match
---
atom_expr [64160,64216]
atom_expr [65784,65840]
===
match
---
trailer [25209,25211]
trailer [25240,25242]
===
match
---
name: params [5125,5131]
name: params [5156,5162]
===
match
---
name: State [76039,76044]
name: State [77663,77668]
===
match
---
name: permissions [66122,66133]
name: permissions [67746,67757]
===
match
---
funcdef [73203,73995]
funcdef [74827,75619]
===
match
---
atom_expr [41029,41069]
atom_expr [41060,41100]
===
match
---
funcdef [12980,13231]
funcdef [13011,13262]
===
match
---
name: t_1 [56237,56240]
name: t_1 [56268,56271]
===
match
---
name: prev [22777,22781]
name: prev [22808,22812]
===
match
---
trailer [38527,38536]
trailer [38558,38567]
===
match
---
operator: == [18964,18966]
operator: == [18995,18997]
===
match
---
string: 'owner2' [33169,33177]
string: 'owner2' [33200,33208]
===
match
---
argument [22282,22314]
argument [22313,22345]
===
match
---
operator: = [51100,51101]
operator: = [51131,51132]
===
match
---
operator: = [44082,44083]
operator: = [44113,44114]
===
match
---
operator: , [77605,77606]
operator: , [79229,79230]
===
match
---
trailer [21469,21475]
trailer [21500,21506]
===
match
---
param [51685,51698]
param [51716,51729]
===
match
---
argument [34574,34587]
argument [34605,34618]
===
match
---
operator: @ [72946,72947]
operator: @ [74570,74571]
===
match
---
name: filter [32688,32694]
name: filter [32719,32725]
===
match
---
suite [27861,28023]
suite [27892,28054]
===
match
---
name: DagRunInfo [78298,78308]
name: DagRunInfo [79922,79932]
===
match
---
name: DummyOperator [38882,38895]
name: DummyOperator [38913,38926]
===
match
---
trailer [8296,8315]
trailer [8327,8346]
===
match
---
operator: = [68047,68048]
operator: = [69671,69672]
===
match
---
name: dag [72559,72562]
name: dag [74183,74186]
===
match
---
comparison [19459,19602]
comparison [19490,19633]
===
match
---
name: self [74216,74220]
name: self [75840,75844]
===
match
---
simple_stmt [46294,46311]
simple_stmt [46325,46342]
===
match
---
trailer [27973,27980]
trailer [28004,28011]
===
match
---
name: execution_date [52235,52249]
name: execution_date [52266,52280]
===
match
---
comparison [19175,19298]
comparison [19206,19329]
===
match
---
trailer [23656,23666]
trailer [23687,23697]
===
match
---
trailer [7626,7641]
trailer [7657,7672]
===
match
---
name: DagTag [27967,27973]
name: DagTag [27998,28004]
===
match
---
trailer [75617,75689]
trailer [77241,77313]
===
match
---
decorated [73315,73585]
decorated [74939,75209]
===
match
---
argument [77811,77818]
argument [79435,79442]
===
match
---
operator: , [29558,29559]
operator: , [29589,29590]
===
match
---
expr_stmt [75282,75315]
expr_stmt [76906,76939]
===
match
---
atom_expr [72632,72642]
atom_expr [74256,74266]
===
match
---
arglist [75618,75688]
arglist [77242,77312]
===
match
---
expr_stmt [24691,24726]
expr_stmt [24722,24757]
===
match
---
name: default_args [9357,9369]
name: default_args [9388,9400]
===
match
---
name: pipeline [14917,14925]
name: pipeline [14948,14956]
===
match
---
name: op3 [42003,42006]
name: op3 [42034,42037]
===
match
---
arith_expr [14405,14419]
arith_expr [14436,14450]
===
match
---
name: DagRunInfo [78114,78124]
name: DagRunInfo [79738,79748]
===
match
---
parameters [68015,68021]
parameters [69639,69645]
===
match
---
trailer [50681,50695]
trailer [50712,50726]
===
match
---
name: new_value [74733,74742]
name: new_value [76357,76366]
===
match
---
atom_expr [63118,63163]
atom_expr [63149,63194]
===
match
---
name: dag [19961,19964]
name: dag [19992,19995]
===
match
---
atom [76130,76354]
atom [77754,77978]
===
match
---
string: 'op8' [7870,7875]
string: 'op8' [7901,7906]
===
match
---
atom_expr [45947,46022]
atom_expr [45978,46053]
===
match
---
operator: == [38542,38544]
operator: == [38573,38575]
===
match
---
atom_expr [31813,31830]
atom_expr [31844,31861]
===
match
---
trailer [22250,22259]
trailer [22281,22290]
===
match
---
trailer [37179,37183]
trailer [37210,37214]
===
match
---
atom_expr [66356,66383]
atom_expr [67980,68007]
===
match
---
operator: , [34288,34289]
operator: , [34319,34320]
===
match
---
atom_expr [69164,69184]
atom_expr [70788,70808]
===
match
---
trailer [50922,50965]
trailer [50953,50996]
===
match
---
operator: , [78588,78589]
operator: , [80212,80213]
===
match
---
string: 'tz_dag' [26168,26176]
string: 'tz_dag' [26199,26207]
===
match
---
trailer [12596,12609]
trailer [12627,12640]
===
match
---
atom_expr [31093,31112]
atom_expr [31124,31143]
===
match
---
argument [6153,6174]
argument [6184,6205]
===
match
---
number: 123 [56693,56696]
number: 123 [56724,56727]
===
match
---
name: self [32034,32038]
name: self [32065,32069]
===
match
---
trailer [69425,69429]
trailer [71049,71053]
===
match
---
name: RUNNING [31535,31542]
name: RUNNING [31566,31573]
===
match
---
name: side_effect [43645,43656]
name: side_effect [43676,43687]
===
match
---
argument [10278,10310]
argument [10309,10341]
===
match
---
operator: = [44906,44907]
operator: = [44937,44938]
===
match
---
string: 'noop_pipeline' [71290,71305]
string: 'noop_pipeline' [72914,72929]
===
match
---
name: next_info [61984,61993]
name: next_info [62015,62024]
===
match
---
arglist [16582,16590]
arglist [16613,16621]
===
match
---
param [3937,3941]
param [3968,3972]
===
match
---
testlist_comp [30409,30439]
testlist_comp [30440,30470]
===
match
---
trailer [31713,31730]
trailer [31744,31761]
===
match
---
name: sqlalchemy [1273,1283]
name: sqlalchemy [1279,1289]
===
match
---
operator: , [65144,65145]
operator: , [66768,66769]
===
match
---
operator: = [53130,53131]
operator: = [53161,53162]
===
match
---
string: 'op2' [6963,6968]
string: 'op2' [6994,6999]
===
match
---
simple_stmt [72589,72617]
simple_stmt [74213,74241]
===
match
---
simple_stmt [46102,46198]
simple_stmt [46133,46229]
===
match
---
name: state [67147,67152]
name: state [68771,68776]
===
match
---
atom_expr [79082,79096]
atom_expr [80706,80720]
===
match
---
name: owner [7098,7103]
name: owner [7129,7134]
===
match
---
simple_stmt [46721,46773]
simple_stmt [46752,46804]
===
match
---
operator: , [51683,51684]
operator: , [51714,51715]
===
match
---
name: ti [74848,74850]
name: ti [76472,76474]
===
match
---
atom_expr [46432,46449]
atom_expr [46463,46480]
===
match
---
name: dag [49230,49233]
name: dag [49261,49264]
===
match
---
trailer [53436,53446]
trailer [53467,53477]
===
match
---
argument [68755,68773]
argument [70379,70397]
===
match
---
trailer [28817,28823]
trailer [28848,28854]
===
match
---
operator: = [11394,11395]
operator: = [11425,11426]
===
match
---
comparison [11081,11108]
comparison [11112,11139]
===
match
---
simple_stmt [1430,1500]
simple_stmt [1436,1506]
===
match
---
name: hash [49314,49318]
name: hash [49345,49349]
===
match
---
atom [21906,21920]
atom [21937,21951]
===
match
---
number: 1 [63950,63951]
number: 1 [65574,65575]
===
match
---
name: orm_dag [32813,32820]
name: orm_dag [32844,32851]
===
match
---
atom [77564,77624]
atom [79188,79248]
===
match
---
suite [21396,22026]
suite [21427,22057]
===
match
---
atom_expr [36865,36880]
atom_expr [36896,36911]
===
match
---
name: session [18637,18644]
name: session [18668,18675]
===
match
---
name: flush [76620,76625]
name: flush [78244,78249]
===
match
---
trailer [41719,41729]
trailer [41750,41760]
===
match
---
name: next_dagrun_info [62720,62736]
name: next_dagrun_info [62751,62767]
===
match
---
trailer [14183,14190]
trailer [14214,14221]
===
match
---
operator: , [9244,9245]
operator: , [9275,9276]
===
match
---
name: dag [36226,36229]
name: dag [36257,36260]
===
match
---
trailer [37119,37129]
trailer [37150,37160]
===
match
---
name: timedelta [31460,31469]
name: timedelta [31491,31500]
===
match
---
name: default_args [4693,4705]
name: default_args [4724,4736]
===
match
---
name: owner [7473,7478]
name: owner [7504,7509]
===
match
---
name: dag [78879,78882]
name: dag [80503,80506]
===
match
---
operator: , [18928,18929]
operator: , [18959,18960]
===
match
---
name: sub_dag [42248,42255]
name: sub_dag [42279,42286]
===
match
---
trailer [63588,63757]
trailer [65212,65381]
===
match
---
trailer [57029,57081]
trailer [57060,57112]
===
match
---
name: dag [27558,27561]
name: dag [27589,27592]
===
match
---
name: self [27343,27347]
name: self [27374,27378]
===
match
---
trailer [6018,6093]
trailer [6049,6124]
===
match
---
atom_expr [63193,63215]
atom_expr [63224,63246]
===
match
---
operator: = [60906,60907]
operator: = [60937,60938]
===
match
---
string: """Verify tasks with Duplicate task_id raises error""" [40850,40904]
string: """Verify tasks with Duplicate task_id raises error""" [40881,40935]
===
match
---
operator: = [78993,78994]
operator: = [80617,80618]
===
match
---
operator: = [24001,24002]
operator: = [24032,24033]
===
match
---
trailer [57915,57924]
trailer [57946,57955]
===
match
---
string: '@hourly' [26612,26621]
string: '@hourly' [26643,26652]
===
match
---
simple_stmt [829,839]
simple_stmt [829,839]
===
match
---
operator: + [18218,18219]
operator: + [18249,18250]
===
match
---
name: name [20912,20916]
name: name [20943,20947]
===
match
---
name: hours [78005,78010]
name: hours [79629,79634]
===
match
---
name: width [13819,13824]
name: width [13850,13855]
===
match
---
name: include_subdag_tasks [8857,8877]
name: include_subdag_tasks [8888,8908]
===
match
---
trailer [7097,7103]
trailer [7128,7134]
===
match
---
funcdef [65930,66782]
funcdef [67554,68406]
===
match
---
name: dag [54531,54534]
name: dag [54562,54565]
===
match
---
name: execution_date [70574,70588]
name: execution_date [72198,72212]
===
match
---
atom [29675,29707]
atom [29706,29738]
===
match
---
operator: , [55564,55565]
operator: , [55595,55596]
===
match
---
name: num [74284,74287]
name: num [75908,75911]
===
match
---
operator: { [41733,41734]
operator: { [41764,41765]
===
match
---
name: BashOperator [40632,40644]
name: BashOperator [40663,40675]
===
match
---
trailer [25780,25790]
trailer [25811,25821]
===
match
---
argument [41102,41114]
argument [41133,41145]
===
match
---
simple_stmt [23023,23084]
simple_stmt [23054,23115]
===
match
---
argument [8211,8234]
argument [8242,8265]
===
match
---
string: 'Also fake' [46835,46846]
string: 'Also fake' [46866,46877]
===
match
---
operator: , [29608,29609]
operator: , [29639,29640]
===
match
---
operator: = [74792,74793]
operator: = [76416,76417]
===
match
---
param [72490,72493]
param [74114,74117]
===
match
---
term [15789,15822]
term [15820,15853]
===
match
---
name: State [31529,31534]
name: State [31560,31565]
===
match
---
atom_expr [33313,33328]
atom_expr [33344,33359]
===
match
---
name: commit [37075,37081]
name: commit [37106,37112]
===
match
---
expr_stmt [56237,56282]
expr_stmt [56268,56313]
===
match
---
string: 'test-default_default_view' [5752,5779]
string: 'test-default_default_view' [5783,5810]
===
match
---
simple_stmt [26158,26225]
simple_stmt [26189,26256]
===
match
---
name: dag [36603,36606]
name: dag [36634,36637]
===
match
---
operator: == [49686,49688]
operator: == [49717,49719]
===
match
---
simple_stmt [36129,36153]
simple_stmt [36160,36184]
===
match
---
name: op2 [6935,6938]
name: op2 [6966,6969]
===
match
---
atom_expr [11081,11100]
atom_expr [11112,11131]
===
match
---
trailer [44368,44395]
trailer [44399,44426]
===
match
---
name: end_date [73883,73891]
name: end_date [75507,75515]
===
match
---
operator: , [56489,56490]
operator: , [56520,56521]
===
match
---
operator: , [19126,19127]
operator: , [19157,19158]
===
match
---
operator: @ [2660,2661]
operator: @ [2691,2692]
===
match
---
arglist [41416,41451]
arglist [41447,41482]
===
match
---
name: dag_id [57050,57056]
name: dag_id [57081,57087]
===
match
---
simple_stmt [39827,39861]
simple_stmt [39858,39892]
===
match
---
number: 1 [64978,64979]
number: 1 [66602,66603]
===
match
---
name: hash [49212,49216]
name: hash [49243,49247]
===
match
---
argument [25686,25706]
argument [25717,25737]
===
match
---
operator: = [21904,21905]
operator: = [21935,21936]
===
match
---
operator: = [5132,5133]
operator: = [5163,5164]
===
match
---
name: DEFAULT_DATE [56804,56816]
name: DEFAULT_DATE [56835,56847]
===
match
---
name: default_args [11432,11444]
name: default_args [11463,11475]
===
match
---
with_stmt [45169,45266]
with_stmt [45200,45297]
===
match
---
name: replace [59691,59698]
name: replace [59722,59729]
===
match
---
trailer [9828,9833]
trailer [9859,9864]
===
match
---
fstring_start: f" [50799,50801]
fstring_start: f" [50830,50832]
===
match
---
operator: , [54863,54864]
operator: , [54894,54895]
===
match
---
expr_stmt [16095,16106]
expr_stmt [16126,16137]
===
match
---
operator: = [8877,8878]
operator: = [8908,8909]
===
match
---
operator: = [51920,51921]
operator: = [51951,51952]
===
match
---
trailer [18498,18505]
trailer [18529,18536]
===
match
---
trailer [52306,52323]
trailer [52337,52354]
===
match
---
trailer [67077,67223]
trailer [68701,68847]
===
match
---
param [34159,34164]
param [34190,34195]
===
match
---
trailer [33073,33080]
trailer [33104,33111]
===
match
---
number: 1 [12922,12923]
number: 1 [12953,12954]
===
match
---
trailer [12552,12565]
trailer [12583,12596]
===
match
---
name: task_id [8342,8349]
name: task_id [8373,8380]
===
match
---
name: default_view [37035,37047]
name: default_view [37066,37078]
===
match
---
assert_stmt [28874,28899]
assert_stmt [28905,28930]
===
match
---
comparison [33291,33328]
comparison [33322,33359]
===
match
---
trailer [73852,73910]
trailer [75476,75534]
===
match
---
number: 25 [24474,24476]
number: 25 [24505,24507]
===
match
---
name: fileloc [33302,33309]
name: fileloc [33333,33340]
===
match
---
name: i [13768,13769]
name: i [13799,13800]
===
match
---
arglist [9072,9112]
arglist [9103,9143]
===
match
---
name: dr [51187,51189]
name: dr [51218,51220]
===
match
---
operator: , [34163,34164]
operator: , [34194,34195]
===
match
---
name: dag [31732,31735]
name: dag [31763,31766]
===
match
---
arglist [43700,43890]
arglist [43731,43921]
===
match
---
operator: } [16357,16358]
operator: } [16388,16389]
===
match
---
atom_expr [34003,34023]
atom_expr [34034,34054]
===
match
---
comparison [66581,66622]
comparison [68205,68246]
===
match
---
trailer [26144,26148]
trailer [26175,26179]
===
match
---
name: orm_dag [38118,38125]
name: orm_dag [38149,38156]
===
match
---
with_stmt [46319,46416]
with_stmt [46350,46447]
===
match
---
name: dag [7412,7415]
name: dag [7443,7446]
===
match
---
name: DAG [34225,34228]
name: DAG [34256,34259]
===
match
---
atom_expr [39833,39860]
atom_expr [39864,39891]
===
match
---
atom_expr [72101,72121]
atom_expr [73725,73745]
===
match
---
trailer [47179,47181]
trailer [47210,47212]
===
match
---
argument [9539,9550]
argument [9570,9581]
===
match
---
name: return_num [73035,73045]
name: return_num [74659,74669]
===
match
---
assert_stmt [47611,47656]
assert_stmt [47642,47687]
===
match
---
argument [18162,18172]
argument [18193,18203]
===
match
---
string: "t3" [41553,41557]
string: "t3" [41584,41588]
===
match
---
simple_stmt [17103,17146]
simple_stmt [17134,17177]
===
match
---
string: 'dag-bulk-sync-2' [28635,28652]
string: 'dag-bulk-sync-2' [28666,28683]
===
match
---
trailer [25901,25903]
trailer [25932,25934]
===
match
---
trailer [7904,7919]
trailer [7935,7950]
===
match
---
name: subdag [53742,53748]
name: subdag [53773,53779]
===
match
---
name: op3 [9609,9612]
name: op3 [9640,9643]
===
match
---
name: catchup [59292,59299]
name: catchup [59323,59330]
===
match
---
name: datetime [67364,67372]
name: datetime [68988,68996]
===
match
---
with_stmt [7283,7345]
with_stmt [7314,7376]
===
match
---
atom_expr [41752,41763]
atom_expr [41783,41794]
===
match
---
name: next_info [63139,63148]
name: next_info [63170,63179]
===
match
---
name: test_params_passed_and_params_in_default_args_no_override [4222,4279]
name: test_params_passed_and_params_in_default_args_no_override [4253,4310]
===
match
---
number: 5 [62470,62471]
number: 5 [62501,62502]
===
match
---
trailer [17938,17948]
trailer [17969,17979]
===
match
---
operator: = [6892,6893]
operator: = [6923,6924]
===
match
---
trailer [20020,20028]
trailer [20051,20059]
===
match
---
name: dag_id [55717,55723]
name: dag_id [55748,55754]
===
match
---
atom_expr [53398,53415]
atom_expr [53429,53446]
===
match
---
simple_stmt [56550,56574]
simple_stmt [56581,56605]
===
match
---
name: session [36626,36633]
name: session [36657,36664]
===
match
---
dotted_name [1150,1172]
dotted_name [1156,1178]
===
match
---
atom_expr [33194,33214]
atom_expr [33225,33245]
===
match
---
arglist [47934,47964]
arglist [47965,47995]
===
match
---
name: next_info [63193,63202]
name: next_info [63224,63233]
===
match
---
name: task_id [43960,43967]
name: task_id [43991,43998]
===
match
---
name: set [29924,29927]
name: set [29955,29958]
===
match
---
argument [18930,18945]
argument [18961,18976]
===
match
---
argument [6712,6735]
argument [6743,6766]
===
match
---
trailer [7509,7515]
trailer [7540,7546]
===
match
---
operator: = [73598,73599]
operator: = [75222,75223]
===
match
---
simple_stmt [6695,6771]
simple_stmt [6726,6802]
===
match
---
trailer [26904,26911]
trailer [26935,26942]
===
match
---
for_stmt [16774,16869]
for_stmt [16805,16900]
===
match
---
testlist_comp [39061,39069]
testlist_comp [39092,39100]
===
match
---
trailer [27381,27391]
trailer [27412,27422]
===
match
---
simple_stmt [24040,24076]
simple_stmt [24071,24107]
===
match
---
name: DummyOperator [13738,13751]
name: DummyOperator [13769,13782]
===
match
---
arglist [11572,11620]
arglist [11603,11651]
===
match
---
name: dag [37591,37594]
name: dag [37622,37625]
===
match
---
operator: = [40052,40053]
operator: = [40083,40084]
===
match
---
operator: = [53146,53147]
operator: = [53177,53178]
===
match
---
string: 'tz_dag' [24581,24589]
string: 'tz_dag' [24612,24620]
===
match
---
operator: , [11736,11737]
operator: , [11767,11768]
===
match
---
name: task_id [51900,51907]
name: task_id [51931,51938]
===
match
---
funcdef [5270,5580]
funcdef [5301,5611]
===
match
---
testlist_comp [11030,11038]
testlist_comp [11061,11069]
===
match
---
assert_stmt [33223,33275]
assert_stmt [33254,33306]
===
match
---
atom_expr [21411,21449]
atom_expr [21442,21480]
===
match
---
operator: = [49616,49617]
operator: = [49647,49648]
===
match
---
operator: = [56945,56946]
operator: = [56976,56977]
===
match
---
sync_comp_for [28171,28191]
sync_comp_for [28202,28222]
===
match
---
name: start_date [38785,38795]
name: start_date [38816,38826]
===
match
---
funcdef [5871,6176]
funcdef [5902,6207]
===
match
---
name: task_id [39515,39522]
name: task_id [39546,39553]
===
match
---
operator: = [64194,64195]
operator: = [65818,65819]
===
match
---
name: self [73231,73235]
name: self [74855,74859]
===
match
---
trailer [21778,21789]
trailer [21809,21820]
===
match
---
argument [52482,52509]
argument [52513,52540]
===
match
---
argument [17900,17956]
argument [17931,17987]
===
match
---
fstring_start: f' [64747,64749]
fstring_start: f' [66371,66373]
===
match
---
atom_expr [67470,67488]
atom_expr [69094,69112]
===
match
---
name: dag_decorator [74136,74149]
name: dag_decorator [75760,75773]
===
match
---
suite [65985,66782]
suite [67609,68406]
===
match
---
atom_expr [27803,27819]
atom_expr [27834,27850]
===
match
---
atom_expr [51756,51778]
atom_expr [51787,51809]
===
match
---
name: dag_id [49647,49653]
name: dag_id [49678,49684]
===
match
---
arglist [69625,69653]
arglist [71249,71277]
===
match
---
name: DAG [39720,39723]
name: DAG [39751,39754]
===
match
---
argument [39034,39046]
argument [39065,39077]
===
match
---
atom_expr [72565,72580]
atom_expr [74189,74204]
===
match
---
atom_expr [37941,38015]
atom_expr [37972,38046]
===
match
---
name: orm_subdag [33124,33134]
name: orm_subdag [33155,33165]
===
match
---
name: session [36566,36573]
name: session [36597,36604]
===
match
---
simple_stmt [58308,58319]
simple_stmt [58339,58350]
===
match
---
name: next_info [61734,61743]
name: next_info [61765,61774]
===
match
---
operator: == [21334,21336]
operator: == [21365,21367]
===
match
---
expr_stmt [23270,23315]
expr_stmt [23301,23346]
===
match
---
trailer [71224,71226]
trailer [72848,72850]
===
match
---
name: DEFAULT_DATE [8477,8489]
name: DEFAULT_DATE [8508,8520]
===
match
---
name: dag_id [58035,58041]
name: dag_id [58066,58072]
===
match
---
argument [69021,69045]
argument [70645,70669]
===
match
---
name: test_task_id [17564,17576]
name: test_task_id [17595,17607]
===
match
---
atom_expr [9570,9596]
atom_expr [9601,9627]
===
match
---
atom_expr [42933,42947]
atom_expr [42964,42978]
===
match
---
trailer [61562,61571]
trailer [61593,61602]
===
match
---
assert_stmt [24085,24145]
assert_stmt [24116,24176]
===
match
---
expr_stmt [41023,41069]
expr_stmt [41054,41100]
===
match
---
suite [69802,69924]
suite [71426,71548]
===
match
---
funcdef [70996,71067]
funcdef [72620,72691]
===
match
---
atom_expr [49997,50024]
atom_expr [50028,50055]
===
match
---
name: airflow [1697,1704]
name: airflow [1703,1710]
===
match
---
name: MANUAL [44143,44149]
name: MANUAL [44174,44180]
===
match
---
operator: , [24589,24590]
operator: , [24620,24621]
===
match
---
simple_stmt [39586,39623]
simple_stmt [39617,39654]
===
match
---
name: conf [37275,37279]
name: conf [37306,37310]
===
match
---
name: schedule_interval [64109,64126]
name: schedule_interval [65733,65750]
===
match
---
name: dag_maker [76009,76018]
name: dag_maker [77633,77642]
===
match
---
operator: == [23669,23671]
operator: == [23700,23702]
===
match
---
name: i [13847,13848]
name: i [13878,13879]
===
match
---
dictorsetmaker [33159,33177]
dictorsetmaker [33190,33208]
===
match
---
atom_expr [53463,53479]
atom_expr [53494,53510]
===
match
---
trailer [55328,55330]
trailer [55359,55361]
===
match
---
operator: , [66975,66976]
operator: , [68599,68600]
===
match
---
expr_stmt [31002,31084]
expr_stmt [31033,31115]
===
match
---
operator: = [44930,44931]
operator: = [44961,44962]
===
match
---
assert_stmt [10065,10100]
assert_stmt [10096,10131]
===
match
---
number: 2 [78195,78196]
number: 2 [79819,79820]
===
match
---
simple_stmt [25619,25709]
simple_stmt [25650,25740]
===
match
---
argument [79035,79045]
argument [80659,80669]
===
match
---
operator: = [53381,53382]
operator: = [53412,53413]
===
match
---
argument [56894,56909]
argument [56925,56940]
===
match
---
param [76108,76112]
param [77732,77736]
===
match
---
with_stmt [38764,39141]
with_stmt [38795,39172]
===
match
---
trailer [72669,72676]
trailer [74293,74300]
===
match
---
simple_stmt [73486,73497]
simple_stmt [75110,75121]
===
match
---
name: set2 [11048,11052]
name: set2 [11079,11083]
===
match
---
arglist [71253,71261]
arglist [72877,72885]
===
match
---
name: execution_date [56503,56517]
name: execution_date [56534,56548]
===
match
---
comparison [42191,42256]
comparison [42222,42287]
===
match
---
number: 5 [63956,63957]
number: 5 [65580,65581]
===
match
---
atom_expr [35288,35298]
atom_expr [35319,35329]
===
match
---
operator: , [26506,26507]
operator: , [26537,26538]
===
match
---
name: dag [63797,63800]
name: dag [65421,65424]
===
match
---
simple_stmt [6888,6923]
simple_stmt [6919,6954]
===
match
---
expr_stmt [17830,17966]
expr_stmt [17861,17997]
===
match
---
string: 'test-dag2' [30428,30439]
string: 'test-dag2' [30459,30470]
===
match
---
name: flush [55323,55328]
name: flush [55354,55359]
===
match
---
suite [74960,75398]
suite [76584,77022]
===
match
---
name: test_following_previous_schedule_daily_dag_cet_to_cest [24218,24272]
name: test_following_previous_schedule_daily_dag_cet_to_cest [24249,24303]
===
match
---
argument [19895,19929]
argument [19926,19960]
===
match
---
string: '.test' [53218,53225]
string: '.test' [53249,53256]
===
match
---
argument [40954,41008]
argument [40985,41039]
===
match
---
atom_expr [10519,10545]
atom_expr [10550,10576]
===
match
---
name: SubDagOperator [1876,1890]
name: SubDagOperator [1882,1896]
===
match
---
trailer [68953,68960]
trailer [70577,70584]
===
match
---
name: self [62169,62173]
name: self [62200,62204]
===
match
---
string: "test_schedule_dag_fake_scheduled_previous" [44718,44761]
string: "test_schedule_dag_fake_scheduled_previous" [44749,44792]
===
match
---
simple_stmt [36865,36881]
simple_stmt [36896,36912]
===
match
---
with_stmt [17254,17456]
with_stmt [17285,17487]
===
match
---
operator: = [47959,47960]
operator: = [47990,47991]
===
match
---
trailer [31534,31542]
trailer [31565,31573]
===
match
---
name: datetime [54615,54623]
name: datetime [54646,54654]
===
match
---
name: task_id [8626,8633]
name: task_id [8657,8664]
===
match
---
name: dag_id [68954,68960]
name: dag_id [70578,70584]
===
match
---
name: DagModel [33939,33947]
name: DagModel [33970,33978]
===
match
---
atom_expr [59894,60089]
atom_expr [59925,60120]
===
match
---
operator: , [22379,22380]
operator: , [22410,22411]
===
match
---
operator: } [70850,70851]
operator: } [72474,72475]
===
match
---
simple_stmt [9861,9885]
simple_stmt [9892,9916]
===
match
---
string: 't1' [56154,56158]
string: 't1' [56185,56189]
===
match
---
atom_expr [8283,8315]
atom_expr [8314,8346]
===
match
---
operator: = [63787,63788]
operator: = [65411,65412]
===
match
---
comparison [24743,24796]
comparison [24774,24827]
===
match
---
operator: , [16623,16624]
operator: , [16654,16655]
===
match
---
expr_stmt [67835,67892]
expr_stmt [69459,69516]
===
match
---
name: op1 [10648,10651]
name: op1 [10679,10682]
===
match
---
expr_stmt [22777,22810]
expr_stmt [22808,22841]
===
match
---
trailer [15864,15886]
trailer [15895,15917]
===
match
---
operator: , [56452,56453]
operator: , [56483,56484]
===
match
---
suite [38688,39141]
suite [38719,39172]
===
match
---
name: test_existing_dag_is_paused_upon_creation [36072,36113]
name: test_existing_dag_is_paused_upon_creation [36103,36144]
===
match
---
operator: = [51943,51944]
operator: = [51974,51975]
===
match
---
name: catchup [62538,62545]
name: catchup [62569,62576]
===
match
---
name: test_fractional_seconds [46552,46575]
name: test_fractional_seconds [46583,46606]
===
match
---
name: self [71009,71013]
name: self [72633,72637]
===
match
---
name: xcom_pass_to_op [75105,75120]
name: xcom_pass_to_op [76729,76744]
===
match
---
name: dag [23780,23783]
name: dag [23811,23814]
===
match
---
name: close [33345,33350]
name: close [33376,33381]
===
match
---
name: task_4 [75979,75985]
name: task_4 [77603,77609]
===
match
---
atom [39612,39622]
atom [39643,39653]
===
match
---
atom [11709,11763]
atom [11740,11794]
===
match
---
simple_stmt [12867,12926]
simple_stmt [12898,12957]
===
match
---
number: 1 [52845,52846]
number: 1 [52876,52877]
===
match
---
atom_expr [32223,32313]
atom_expr [32254,32344]
===
match
---
operator: , [31794,31795]
operator: , [31825,31826]
===
match
---
number: 0 [59719,59720]
number: 0 [59750,59751]
===
match
---
assert_stmt [25182,25242]
assert_stmt [25213,25273]
===
match
---
parameters [38308,38314]
parameters [38339,38345]
===
match
---
arglist [28186,28190]
arglist [28217,28221]
===
match
---
operator: , [62842,62843]
operator: , [62873,62874]
===
match
---
suite [3765,3794]
suite [3796,3825]
===
match
---
name: success [44311,44318]
name: success [44342,44349]
===
match
---
atom_expr [49784,49799]
atom_expr [49815,49830]
===
match
---
trailer [33141,33147]
trailer [33172,33178]
===
match
---
dictorsetmaker [13668,13685]
dictorsetmaker [13699,13716]
===
match
---
name: task_decorator [75153,75167]
name: task_decorator [76777,76791]
===
match
---
string: "test_dag" [40515,40525]
string: "test_dag" [40546,40556]
===
match
---
argument [70574,70598]
argument [72198,72222]
===
match
---
name: fileloc [69774,69781]
name: fileloc [71398,71405]
===
match
---
operator: == [37917,37919]
operator: == [37948,37950]
===
match
---
name: _next [22627,22632]
name: _next [22658,22663]
===
match
---
string: "task_1" [75737,75745]
string: "task_1" [77361,77369]
===
match
---
simple_stmt [60781,60971]
simple_stmt [60812,61002]
===
match
---
return_stmt [27214,27243]
return_stmt [27245,27274]
===
match
---
operator: - [15473,15474]
operator: - [15504,15505]
===
match
---
atom_expr [31229,31240]
atom_expr [31260,31271]
===
match
---
atom [19395,19416]
atom [19426,19447]
===
match
---
name: hours [25543,25548]
name: hours [25574,25579]
===
match
---
trailer [51615,51623]
trailer [51646,51654]
===
match
---
argument [59712,59720]
argument [59743,59751]
===
match
---
and_test [63179,63248]
and_test [63210,63279]
===
match
---
operator: = [39041,39042]
operator: = [39072,39073]
===
match
---
operator: , [30640,30641]
operator: , [30671,30672]
===
match
---
atom_expr [44955,45135]
atom_expr [44986,45166]
===
match
---
atom_expr [74522,74754]
atom_expr [76146,76378]
===
match
---
suite [32040,33353]
suite [32071,33384]
===
match
---
atom_expr [24656,24682]
atom_expr [24687,24713]
===
match
---
operator: , [41750,41751]
operator: , [41781,41782]
===
match
---
name: relativedelta [1159,1172]
name: relativedelta [1165,1178]
===
match
---
param [66827,66831]
param [68451,68455]
===
match
---
trailer [6999,7003]
trailer [7030,7034]
===
match
---
argument [53115,53132]
argument [53146,53163]
===
match
---
number: 1 [75596,75597]
number: 1 [77220,77221]
===
match
---
name: session [18845,18852]
name: session [18876,18883]
===
match
---
dictorsetmaker [28536,28715]
dictorsetmaker [28567,28746]
===
match
---
operator: = [68324,68325]
operator: = [69948,69949]
===
match
---
trailer [77537,77541]
trailer [79161,79165]
===
match
---
name: op1 [59379,59382]
name: op1 [59410,59413]
===
match
---
atom_expr [51202,51219]
atom_expr [51233,51250]
===
match
---
atom_expr [76199,76208]
atom_expr [77823,77832]
===
match
---
name: weight [13327,13333]
name: weight [13358,13364]
===
match
---
string: 'old_existing_dag' [37404,37422]
string: 'old_existing_dag' [37435,37453]
===
match
---
arglist [57421,57431]
arglist [57452,57462]
===
match
---
argument [68145,68160]
argument [69769,69784]
===
match
---
name: dag [68166,68169]
name: dag [69790,69793]
===
match
---
name: timedelta [18229,18238]
name: timedelta [18260,18269]
===
match
---
simple_stmt [78889,79053]
simple_stmt [80513,80677]
===
match
---
trailer [16581,16591]
trailer [16612,16622]
===
match
---
name: dag_id [37146,37152]
name: dag_id [37177,37183]
===
match
---
simple_stmt [52176,52200]
simple_stmt [52207,52231]
===
match
---
name: set [39593,39596]
name: set [39624,39627]
===
match
---
comparison [24092,24145]
comparison [24123,24176]
===
match
---
name: DAG [7542,7545]
name: DAG [7573,7576]
===
match
---
name: op3 [10807,10810]
name: op3 [10838,10841]
===
match
---
argument [52595,52610]
argument [52626,52641]
===
match
---
comparison [37819,37844]
comparison [37850,37875]
===
match
---
trailer [71136,71149]
trailer [72760,72773]
===
match
---
atom_expr [9937,9970]
atom_expr [9968,10001]
===
match
---
comparison [43055,43090]
comparison [43086,43121]
===
match
---
name: orm_subdag [33230,33240]
name: orm_subdag [33261,33271]
===
match
---
name: set_upstream [10758,10770]
name: set_upstream [10789,10801]
===
match
---
name: sub_dag [42359,42366]
name: sub_dag [42390,42397]
===
match
---
argument [53707,53722]
argument [53738,53753]
===
match
---
string: 'airflow.models.dag.DagCode.bulk_sync_to_db' [2934,2978]
string: 'airflow.models.dag.DagCode.bulk_sync_to_db' [2965,3009]
===
match
---
trailer [57411,57420]
trailer [57442,57451]
===
match
---
suite [66472,66566]
suite [68096,68190]
===
match
---
expr_stmt [37625,37653]
expr_stmt [37656,37684]
===
match
---
expr_stmt [59887,60089]
expr_stmt [59918,60120]
===
match
---
operator: = [31863,31864]
operator: = [31894,31895]
===
match
---
trailer [22787,22805]
trailer [22818,22836]
===
match
---
trailer [28832,28849]
trailer [28863,28880]
===
match
---
name: op5 [7506,7509]
name: op5 [7537,7540]
===
match
---
name: dag_id [34455,34461]
name: dag_id [34486,34492]
===
match
---
name: bash [1764,1768]
name: bash [1770,1774]
===
match
---
simple_stmt [7223,7252]
simple_stmt [7254,7283]
===
match
---
operator: = [9319,9320]
operator: = [9350,9351]
===
match
---
atom_expr [70970,70983]
atom_expr [72594,72607]
===
match
---
operator: { [39130,39131]
operator: { [39161,39162]
===
match
---
trailer [45959,46022]
trailer [45990,46053]
===
match
---
decorated [61156,62054]
decorated [61187,62085]
===
match
---
expr_stmt [61445,61670]
expr_stmt [61476,61701]
===
match
---
exprlist [3709,3713]
exprlist [3740,3744]
===
match
---
trailer [14133,14144]
trailer [14164,14175]
===
match
---
trailer [52361,52367]
trailer [52392,52398]
===
match
---
string: 'start_date' [47834,47846]
string: 'start_date' [47865,47877]
===
match
---
operator: = [34957,34958]
operator: = [34988,34989]
===
match
---
operator: = [34416,34417]
operator: = [34447,34448]
===
match
---
string: 'dag_default_view_old' [37011,37033]
string: 'dag_default_view_old' [37042,37064]
===
match
---
operator: = [13354,13355]
operator: = [13385,13386]
===
match
---
string: "2018-10-28T02:00:00+00:00" [23959,23986]
string: "2018-10-28T02:00:00+00:00" [23990,24017]
===
match
---
operator: == [37835,37837]
operator: == [37866,37868]
===
match
---
trailer [45255,45262]
trailer [45286,45293]
===
match
---
name: DummyOperator [34333,34346]
name: DummyOperator [34364,34377]
===
match
---
name: dag_run [76994,77001]
name: dag_run [78618,78625]
===
match
---
argument [8466,8489]
argument [8497,8520]
===
match
---
assert_stmt [77060,77112]
assert_stmt [78684,78736]
===
match
---
trailer [23879,23889]
trailer [23910,23920]
===
match
---
argument [65217,65226]
argument [66841,66850]
===
match
---
name: six_hours_ago_to_the_hour [60448,60473]
name: six_hours_ago_to_the_hour [60479,60504]
===
match
---
string: 'parameter2' [4860,4872]
string: 'parameter2' [4891,4903]
===
match
---
operator: = [21195,21196]
operator: = [21226,21227]
===
match
---
operator: , [31058,31059]
operator: , [31089,31090]
===
match
---
name: match [66977,66982]
name: match [68601,68606]
===
match
---
comparison [48432,48442]
comparison [48463,48473]
===
match
---
atom_expr [29198,29221]
atom_expr [29229,29252]
===
match
---
name: template_undefined [20568,20586]
name: template_undefined [20599,20617]
===
match
---
testlist_comp [10919,10927]
testlist_comp [10950,10958]
===
match
---
string: 'test-dag' [20993,21003]
string: 'test-dag' [21024,21034]
===
match
---
atom_expr [18874,18946]
atom_expr [18905,18977]
===
match
---
suite [2813,67224]
suite [2844,68848]
===
match
---
name: test_clear_dag [56004,56018]
name: test_clear_dag [56035,56049]
===
match
---
testlist_comp [16297,16532]
testlist_comp [16328,16563]
===
match
---
expr_stmt [47870,47911]
expr_stmt [47901,47942]
===
match
---
dictorsetmaker [66122,66208]
dictorsetmaker [67746,67832]
===
match
---
name: pendulum [24379,24387]
name: pendulum [24410,24418]
===
match
---
trailer [19765,19940]
trailer [19796,19971]
===
match
---
simple_stmt [37238,37325]
simple_stmt [37269,37356]
===
match
---
expr_stmt [24040,24075]
expr_stmt [24071,24106]
===
match
---
trailer [55435,55445]
trailer [55466,55476]
===
match
---
number: 10 [63697,63699]
number: 10 [65321,65323]
===
match
---
name: task_2 [75755,75761]
name: task_2 [77379,77385]
===
match
---
atom_expr [20099,20123]
atom_expr [20130,20154]
===
match
---
atom_expr [56668,56690]
atom_expr [56699,56721]
===
match
---
simple_stmt [23862,23923]
simple_stmt [23893,23954]
===
match
---
argument [63780,63795]
argument [65404,65419]
===
match
---
atom_expr [73035,73052]
atom_expr [74659,74676]
===
match
---
operator: = [27720,27721]
operator: = [27751,27752]
===
match
---
trailer [3751,3759]
trailer [3782,3790]
===
match
---
dictorsetmaker [41237,41253]
dictorsetmaker [41268,41284]
===
match
---
number: 3 [62996,62997]
number: 3 [63027,63028]
===
match
---
argument [68417,68431]
argument [70041,70055]
===
match
---
dictorsetmaker [29324,29398]
dictorsetmaker [29355,29429]
===
match
---
atom_expr [77930,78096]
atom_expr [79554,79720]
===
match
---
simple_stmt [30838,30994]
simple_stmt [30869,31025]
===
match
---
string: 'airflow' [64206,64215]
string: 'airflow' [65830,65839]
===
match
---
name: _next [25833,25838]
name: _next [25864,25869]
===
match
---
atom_expr [37901,37916]
atom_expr [37932,37947]
===
match
---
trailer [61782,61791]
trailer [61813,61822]
===
match
---
atom_expr [20475,20497]
atom_expr [20506,20528]
===
match
---
name: dag_run [42933,42940]
name: dag_run [42964,42971]
===
match
---
simple_stmt [60980,61023]
simple_stmt [61011,61054]
===
match
---
name: state [51019,51024]
name: state [51050,51055]
===
match
---
name: Path [69656,69660]
name: Path [71280,71284]
===
match
---
name: date [58652,58656]
name: date [58683,58687]
===
match
---
suite [14193,14567]
suite [14224,14598]
===
match
---
name: op2 [59434,59437]
name: op2 [59465,59468]
===
match
---
name: UPSTREAM [15127,15135]
name: UPSTREAM [15158,15166]
===
match
---
name: row [30757,30760]
name: row [30788,30791]
===
match
---
name: prev_task [16858,16867]
name: prev_task [16889,16898]
===
match
---
name: current_task [15402,15414]
name: current_task [15433,15445]
===
match
---
simple_stmt [34541,34589]
simple_stmt [34572,34620]
===
match
---
name: clear [43282,43287]
name: clear [43313,43318]
===
match
---
with_stmt [20762,21302]
with_stmt [20793,21333]
===
match
---
atom_expr [52023,52046]
atom_expr [52054,52077]
===
match
---
string: 'Also fake' [25673,25684]
string: 'Also fake' [25704,25715]
===
match
---
trailer [57348,57469]
trailer [57379,57500]
===
match
---
name: test_field [21779,21789]
name: test_field [21810,21820]
===
match
---
trailer [33320,33328]
trailer [33351,33359]
===
match
---
operator: , [56272,56273]
operator: , [56303,56304]
===
match
---
name: in_ [34811,34814]
name: in_ [34842,34845]
===
match
---
atom_expr [33711,33813]
atom_expr [33742,33844]
===
match
---
name: BaseOperator [1627,1639]
name: BaseOperator [1633,1645]
===
match
---
name: get_ti_from_db [76852,76866]
name: get_ti_from_db [78476,78490]
===
match
---
simple_stmt [41709,41770]
simple_stmt [41740,41801]
===
match
---
name: BashOperator [1776,1788]
name: BashOperator [1782,1794]
===
match
---
atom_expr [42191,42241]
atom_expr [42222,42272]
===
match
---
name: pipeline [13920,13928]
name: pipeline [13951,13959]
===
match
---
comparison [38195,38220]
comparison [38226,38251]
===
match
---
param [19698,19702]
param [19729,19733]
===
match
---
name: State [54278,54283]
name: State [54309,54314]
===
match
---
name: test_set_params_for_dag [74930,74953]
name: test_set_params_for_dag [76554,76577]
===
match
---
name: DEFAULT_DATE [78219,78231]
name: DEFAULT_DATE [79843,79855]
===
match
---
name: test_duplicate_task_ids_not_allowed_without_dag_context_manager [40771,40834]
name: test_duplicate_task_ids_not_allowed_without_dag_context_manager [40802,40865]
===
match
---
arglist [76975,77022]
arglist [78599,78646]
===
match
---
operator: } [41768,41769]
operator: } [41799,41800]
===
match
---
operator: = [3517,3518]
operator: = [3548,3549]
===
match
---
expr_stmt [68745,68799]
expr_stmt [70369,70423]
===
match
---
name: settings [69625,69633]
name: settings [71249,71257]
===
match
---
atom_expr [31249,31285]
atom_expr [31280,31316]
===
match
---
operator: , [78679,78680]
operator: , [80303,80304]
===
match
---
number: 2 [26515,26516]
number: 2 [26546,26547]
===
match
---
name: test_dag_as_context_manager [6458,6485]
name: test_dag_as_context_manager [6489,6516]
===
match
---
assert_stmt [10937,10971]
assert_stmt [10968,11002]
===
match
---
param [34165,34172]
param [34196,34203]
===
match
---
name: schedule_interval [57434,57451]
name: schedule_interval [57465,57482]
===
match
---
trailer [77994,78004]
trailer [79618,79628]
===
match
---
name: dag [49518,49521]
name: dag [49549,49552]
===
match
---
trailer [34058,34071]
trailer [34089,34102]
===
match
---
trailer [50996,51036]
trailer [51027,51067]
===
match
---
import_name [839,852]
import_name [839,852]
===
match
---
operator: , [70391,70392]
operator: , [72015,72016]
===
match
---
name: DEFAULT_DATE [21016,21028]
name: DEFAULT_DATE [21047,21059]
===
match
---
name: datetime [26896,26904]
name: datetime [26927,26935]
===
match
---
simple_stmt [37737,37769]
simple_stmt [37768,37800]
===
match
---
name: owner [32537,32542]
name: owner [32568,32573]
===
match
---
expr_stmt [23772,23807]
expr_stmt [23803,23838]
===
match
---
atom_expr [61451,61670]
atom_expr [61482,61701]
===
match
---
simple_stmt [25561,25611]
simple_stmt [25592,25642]
===
match
---
atom_expr [69473,69491]
atom_expr [71097,71115]
===
match
---
operator: = [60494,60495]
operator: = [60525,60526]
===
match
---
simple_stmt [71051,71067]
simple_stmt [72675,72691]
===
match
---
argument [40645,40657]
argument [40676,40688]
===
match
---
trailer [69513,69515]
trailer [71137,71139]
===
match
---
name: following_schedule [25845,25863]
name: following_schedule [25876,25894]
===
match
---
tfpdef [3173,3184]
tfpdef [3204,3215]
===
match
---
operator: , [50050,50051]
operator: , [50081,50082]
===
match
---
name: timedelta [52451,52460]
name: timedelta [52482,52491]
===
match
---
fstring_string: Hello  [19726,19732]
fstring_string: Hello  [19757,19763]
===
match
---
name: self [11553,11557]
name: self [11584,11588]
===
match
---
name: start_date [46974,46984]
name: start_date [47005,47015]
===
match
---
string: 'creating_dag_in_cm' [7672,7692]
string: 'creating_dag_in_cm' [7703,7723]
===
match
---
name: subdag_id [34242,34251]
name: subdag_id [34273,34282]
===
match
---
argument [41977,41989]
argument [42008,42020]
===
match
---
suite [11381,11511]
suite [11412,11542]
===
match
---
name: session [19426,19433]
name: session [19457,19464]
===
match
---
dotted_name [2487,2506]
dotted_name [2518,2537]
===
match
---
name: delta [58173,58178]
name: delta [58204,58209]
===
match
---
name: DagRunType [74560,74570]
name: DagRunType [76184,76194]
===
match
---
operator: , [17791,17792]
operator: , [17822,17823]
===
match
---
name: dag [48930,48933]
name: dag [48961,48964]
===
match
---
simple_stmt [39060,39092]
simple_stmt [39091,39123]
===
match
---
atom_expr [42726,42868]
atom_expr [42757,42899]
===
match
---
operator: { [28412,28413]
operator: { [28443,28444]
===
match
---
trailer [41032,41069]
trailer [41063,41100]
===
match
---
name: self [20179,20183]
name: self [20210,20214]
===
match
---
operator: } [66097,66098]
operator: } [67721,67722]
===
match
---
trailer [49810,49817]
trailer [49841,49848]
===
match
---
trailer [3446,3456]
trailer [3477,3487]
===
match
---
trailer [38186,38188]
trailer [38217,38219]
===
match
---
name: dict [4171,4175]
name: dict [4202,4206]
===
match
---
simple_stmt [10937,10972]
simple_stmt [10968,11003]
===
match
---
name: merge [18645,18650]
name: merge [18676,18681]
===
match
---
comparison [7658,7692]
comparison [7689,7723]
===
match
---
name: dag_id [68943,68949]
name: dag_id [70567,70573]
===
match
---
simple_stmt [53526,53734]
simple_stmt [53557,53765]
===
match
---
trailer [24102,24112]
trailer [24133,24143]
===
match
---
arglist [15253,15261]
arglist [15284,15292]
===
match
---
simple_stmt [48529,48557]
simple_stmt [48560,48588]
===
match
---
trailer [26094,26103]
trailer [26125,26134]
===
match
---
name: run_id [43019,43025]
name: run_id [43050,43056]
===
match
---
atom_expr [46102,46197]
atom_expr [46133,46228]
===
match
---
arglist [48137,48167]
arglist [48168,48198]
===
match
---
funcdef [41260,41770]
funcdef [41291,41801]
===
match
---
simple_stmt [72764,72844]
simple_stmt [74388,74468]
===
match
---
atom_expr [37591,37602]
atom_expr [37622,37633]
===
match
---
operator: } [10309,10310]
operator: } [10340,10341]
===
match
---
simple_stmt [31093,31117]
simple_stmt [31124,31148]
===
match
---
argument [53179,53186]
argument [53210,53217]
===
match
---
trailer [67950,67952]
trailer [69574,69576]
===
match
---
name: DAG [6114,6117]
name: DAG [6145,6148]
===
match
---
operator: , [38480,38481]
operator: , [38511,38512]
===
match
---
simple_stmt [40626,40683]
simple_stmt [40657,40714]
===
match
---
parameters [72988,72993]
parameters [74612,74617]
===
match
---
operator: == [54988,54990]
operator: == [55019,55021]
===
match
---
name: timezone [68092,68100]
name: timezone [69716,69724]
===
match
---
name: dag [7203,7206]
name: dag [7234,7237]
===
match
---
operator: = [76061,76062]
operator: = [77685,77686]
===
match
---
operator: , [32535,32536]
operator: , [32566,32567]
===
match
---
name: DAG [18874,18877]
name: DAG [18905,18908]
===
match
---
name: dag [31332,31335]
name: dag [31363,31366]
===
match
---
comparison [42919,42947]
comparison [42950,42978]
===
match
---
operator: = [34748,34749]
operator: = [34779,34780]
===
match
---
trailer [73045,73052]
trailer [74669,74676]
===
match
---
name: execution_date [56609,56623]
name: execution_date [56640,56654]
===
match
---
name: orientation [6437,6448]
name: orientation [6468,6479]
===
match
---
operator: { [13667,13668]
operator: { [13698,13699]
===
match
---
string: 'param1' [5135,5143]
string: 'param1' [5166,5174]
===
match
---
suite [74046,74921]
suite [75670,76545]
===
match
---
operator: = [7799,7800]
operator: = [7830,7831]
===
match
---
trailer [45556,45564]
trailer [45587,45595]
===
match
---
trailer [38238,38244]
trailer [38269,38275]
===
match
---
operator: , [34825,34826]
operator: , [34856,34857]
===
match
---
param [56025,56040]
param [56056,56071]
===
match
---
atom_expr [50248,50274]
atom_expr [50279,50305]
===
match
---
string: "test-dag" [20204,20214]
string: "test-dag" [20235,20245]
===
match
---
simple_stmt [23594,23630]
simple_stmt [23625,23661]
===
match
---
number: 2 [40245,40246]
number: 2 [40276,40277]
===
match
---
operator: >> [39078,39080]
operator: >> [39109,39111]
===
match
---
arith_expr [58009,58017]
arith_expr [58040,58048]
===
match
---
number: 1 [40202,40203]
number: 1 [40233,40234]
===
match
---
arglist [33637,33814]
arglist [33668,33845]
===
match
---
name: bulk_write_to_db [31253,31269]
name: bulk_write_to_db [31284,31300]
===
match
---
name: dag [17713,17716]
name: dag [17744,17747]
===
match
---
atom_expr [15116,15135]
atom_expr [15147,15166]
===
match
---
trailer [31416,31441]
trailer [31447,31472]
===
match
---
name: _clean_up [44430,44439]
name: _clean_up [44461,44470]
===
match
---
dotted_name [2240,2262]
dotted_name [2271,2293]
===
match
---
name: self [16006,16010]
name: self [16037,16041]
===
match
---
trailer [24554,24561]
trailer [24585,24592]
===
match
---
name: next_local [22597,22607]
name: next_local [22628,22638]
===
match
---
simple_stmt [10023,10057]
simple_stmt [10054,10088]
===
match
---
name: owner [70379,70384]
name: owner [72003,72008]
===
match
---
name: parameterized [49851,49864]
name: parameterized [49882,49895]
===
match
---
simple_stmt [18600,18629]
simple_stmt [18631,18660]
===
match
---
arglist [57591,57601]
arglist [57622,57632]
===
match
---
suite [65246,65426]
suite [66870,67050]
===
match
---
operator: , [79025,79026]
operator: , [80649,80650]
===
match
---
name: _dst [27103,27107]
name: _dst [27134,27138]
===
match
---
simple_stmt [20300,20335]
simple_stmt [20331,20366]
===
match
---
atom_expr [64927,64998]
atom_expr [66551,66622]
===
match
---
name: default_args [71119,71131]
name: default_args [72743,72755]
===
match
---
string: 'hello' [20062,20069]
string: 'hello' [20093,20100]
===
match
---
argument [68297,68330]
argument [69921,69954]
===
match
---
trailer [76018,76032]
trailer [77642,77656]
===
match
---
arglist [73853,73909]
arglist [75477,75533]
===
match
---
trailer [55322,55328]
trailer [55353,55359]
===
match
---
operator: , [63795,63796]
operator: , [65419,65420]
===
match
---
number: 10 [64354,64356]
number: 10 [65978,65980]
===
match
---
suite [28857,28900]
suite [28888,28931]
===
match
---
simple_stmt [44709,44762]
simple_stmt [44740,44793]
===
match
---
name: next_info [64280,64289]
name: next_info [65904,65913]
===
match
---
comparison [49125,49144]
comparison [49156,49175]
===
match
---
name: start_date [68775,68785]
name: start_date [70399,70409]
===
match
---
name: dag_diff_name [48936,48949]
name: dag_diff_name [48967,48980]
===
match
---
operator: { [30284,30285]
operator: { [30315,30316]
===
match
---
trailer [73945,73947]
trailer [75569,75571]
===
match
---
name: SKIPPED [77388,77395]
name: SKIPPED [79012,79019]
===
match
---
arglist [26502,26546]
arglist [26533,26577]
===
match
---
name: test_dag [17717,17725]
name: test_dag [17748,17756]
===
match
---
name: DagModel [38049,38057]
name: DagModel [38080,38088]
===
match
---
name: session [67934,67941]
name: session [69558,69565]
===
match
---
operator: , [44253,44254]
operator: , [44284,44285]
===
match
---
operator: , [38436,38437]
operator: , [38467,38468]
===
match
---
simple_stmt [74494,74509]
simple_stmt [76118,76133]
===
match
---
trailer [26492,26501]
trailer [26523,26532]
===
match
---
name: interval [77941,77949]
name: interval [79565,79573]
===
match
---
operator: = [17015,17016]
operator: = [17046,17047]
===
match
---
trailer [14190,14192]
trailer [14221,14223]
===
match
---
expr_stmt [59434,59476]
expr_stmt [59465,59507]
===
match
---
trailer [20053,20061]
trailer [20084,20092]
===
match
---
simple_stmt [67934,67953]
simple_stmt [69558,69577]
===
match
---
operator: , [57390,57391]
operator: , [57421,57422]
===
match
---
decorated [51537,52936]
decorated [51568,52967]
===
match
---
atom_expr [14218,14245]
atom_expr [14249,14276]
===
match
---
for_stmt [15553,15946]
for_stmt [15584,15977]
===
match
---
name: self [39162,39166]
name: self [39193,39197]
===
match
---
argument [34364,34384]
argument [34395,34415]
===
match
---
operator: == [33972,33974]
operator: == [34003,34005]
===
match
---
trailer [32616,32627]
trailer [32647,32658]
===
match
---
simple_stmt [23092,23111]
simple_stmt [23123,23142]
===
match
---
simple_stmt [53398,53422]
simple_stmt [53429,53453]
===
match
---
operator: , [17898,17899]
operator: , [17929,17930]
===
match
---
name: DagTag [30627,30633]
name: DagTag [30658,30664]
===
match
---
comparison [24812,24859]
comparison [24843,24890]
===
match
---
operator: == [25053,25055]
operator: == [25084,25086]
===
match
---
name: schedule_interval [59200,59217]
name: schedule_interval [59231,59248]
===
match
---
name: raises [5413,5419]
name: raises [5444,5450]
===
match
---
testlist_comp [14968,15203]
testlist_comp [14999,15234]
===
match
---
operator: , [67733,67734]
operator: , [69357,69358]
===
match
---
arglist [67373,67383]
arglist [68997,69007]
===
match
---
operator: = [67428,67429]
operator: = [69052,69053]
===
match
---
operator: , [18172,18173]
operator: , [18203,18204]
===
match
---
trailer [45895,45925]
trailer [45926,45956]
===
match
---
name: self [27299,27303]
name: self [27330,27334]
===
match
---
simple_stmt [67460,67489]
simple_stmt [69084,69113]
===
match
---
trailer [24175,24177]
trailer [24206,24208]
===
match
---
name: tests [2391,2396]
name: tests [2422,2427]
===
match
---
arglist [43960,44016]
arglist [43991,44047]
===
match
---
name: task_id [46807,46814]
name: task_id [46838,46845]
===
match
---
trailer [54175,54181]
trailer [54206,54212]
===
match
---
trailer [58400,58417]
trailer [58431,58448]
===
match
---
simple_stmt [27803,27820]
simple_stmt [27834,27851]
===
match
---
name: get_dagmodel [35275,35287]
name: get_dagmodel [35306,35318]
===
match
---
operator: = [6124,6125]
operator: = [6155,6156]
===
match
---
arglist [51394,51477]
arglist [51425,51508]
===
match
---
operator: = [18279,18280]
operator: = [18310,18311]
===
match
---
name: subdag [8700,8706]
name: subdag [8731,8737]
===
match
---
name: VALUE [74221,74226]
name: VALUE [75845,75850]
===
match
---
name: DummyOperator [75764,75777]
name: DummyOperator [77388,77401]
===
match
---
trailer [77001,77014]
trailer [78625,78638]
===
match
---
simple_stmt [18395,18421]
simple_stmt [18426,18452]
===
match
---
name: params1 [4591,4598]
name: params1 [4622,4629]
===
match
---
name: session [31192,31199]
name: session [31223,31230]
===
match
---
name: prev [23552,23556]
name: prev [23583,23587]
===
match
---
testlist_comp [35501,35518]
testlist_comp [35532,35549]
===
match
---
operator: } [15028,15029]
operator: } [15059,15060]
===
match
---
operator: , [69645,69646]
operator: , [71269,71270]
===
match
---
expr_stmt [7928,7942]
expr_stmt [7959,7973]
===
match
---
trailer [32169,32201]
trailer [32200,32232]
===
match
---
name: stage [14023,14028]
name: stage [14054,14059]
===
match
---
decorated [74135,74453]
decorated [75759,76077]
===
match
---
simple_stmt [73959,73995]
simple_stmt [75583,75619]
===
match
---
atom [19135,19141]
atom [19166,19172]
===
match
---
name: self [20531,20535]
name: self [20562,20566]
===
match
---
return_stmt [71613,71623]
return_stmt [73237,73247]
===
match
---
name: DummyOperator [41963,41976]
name: DummyOperator [41994,42007]
===
match
---
name: timezone [62024,62032]
name: timezone [62055,62063]
===
match
---
simple_stmt [48998,49034]
simple_stmt [49029,49065]
===
match
---
argument [26594,26621]
argument [26625,26652]
===
match
---
operator: = [4107,4108]
operator: = [4138,4139]
===
match
---
operator: = [59383,59384]
operator: = [59414,59415]
===
match
---
atom_expr [51816,51871]
atom_expr [51847,51902]
===
match
---
simple_stmt [66842,66937]
simple_stmt [68466,68561]
===
match
---
funcdef [47392,47657]
funcdef [47423,47688]
===
match
---
trailer [75826,75844]
trailer [77450,77468]
===
match
---
name: DAG [20200,20203]
name: DAG [20231,20234]
===
match
---
assert_stmt [22864,22924]
assert_stmt [22895,22955]
===
match
---
atom_expr [50444,50510]
atom_expr [50475,50541]
===
match
---
trailer [24659,24677]
trailer [24690,24708]
===
match
---
name: run_type [76053,76061]
name: run_type [77677,77685]
===
match
---
trailer [57627,57644]
trailer [57658,57675]
===
match
---
operator: = [34193,34194]
operator: = [34224,34225]
===
match
---
expr_stmt [53049,53063]
expr_stmt [53080,53094]
===
match
---
string: 'test_get_num_task_instances_dag' [17522,17555]
string: 'test_get_num_task_instances_dag' [17553,17586]
===
match
---
name: logical_date [65713,65725]
name: logical_date [67337,67349]
===
match
---
trailer [44878,44944]
trailer [44909,44975]
===
match
---
name: default_args [11579,11591]
name: default_args [11610,11622]
===
match
---
operator: , [74909,74910]
operator: , [76533,76534]
===
match
---
operator: , [6409,6410]
operator: , [6440,6441]
===
match
---
name: op1 [41250,41253]
name: op1 [41281,41284]
===
match
---
name: start_date [41428,41438]
name: start_date [41459,41469]
===
match
---
name: convert [24935,24942]
name: convert [24966,24973]
===
match
---
name: days [50267,50271]
name: days [50298,50302]
===
match
---
name: SCHEDULED [31622,31631]
name: SCHEDULED [31653,31662]
===
match
---
simple_stmt [78751,78840]
simple_stmt [80375,80464]
===
match
---
trailer [10666,10671]
trailer [10697,10702]
===
match
---
trailer [69429,69431]
trailer [71053,71055]
===
match
---
with_stmt [40506,40710]
with_stmt [40537,40741]
===
match
---
string: """Verify tasks with Duplicate task_id raises error""" [40333,40387]
string: """Verify tasks with Duplicate task_id raises error""" [40364,40418]
===
match
---
expr_stmt [37591,37616]
expr_stmt [37622,37647]
===
match
---
dictorsetmaker [27882,27898]
dictorsetmaker [27913,27929]
===
match
---
atom_expr [78900,79052]
atom_expr [80524,80676]
===
match
---
name: test_dag_param_dagrun_parameterized [74004,74039]
name: test_dag_param_dagrun_parameterized [75628,75663]
===
match
---
atom_expr [34731,34747]
atom_expr [34762,34778]
===
match
---
simple_stmt [66683,66725]
simple_stmt [68307,68349]
===
match
---
operator: = [47531,47532]
operator: = [47562,47563]
===
match
---
trailer [67158,67166]
trailer [68782,68790]
===
match
---
trailer [35790,35796]
trailer [35821,35827]
===
match
---
operator: , [61194,61195]
operator: , [61225,61226]
===
match
---
trailer [9208,9222]
trailer [9239,9253]
===
match
---
operator: , [67726,67727]
operator: , [69350,69351]
===
match
---
testlist_comp [49986,50024]
testlist_comp [50017,50055]
===
match
---
comparison [41621,41631]
comparison [41652,41662]
===
match
---
string: 'far_future_dag' [67326,67342]
string: 'far_future_dag' [68950,68966]
===
match
---
atom_expr [60754,60771]
atom_expr [60785,60802]
===
match
---
name: Exception [43659,43668]
name: Exception [43690,43699]
===
match
---
trailer [9756,9761]
trailer [9787,9792]
===
match
---
expr_stmt [17736,17821]
expr_stmt [17767,17852]
===
match
---
arglist [68943,69145]
arglist [70567,70769]
===
match
---
argument [47049,47070]
argument [47080,47101]
===
match
---
trailer [18626,18628]
trailer [18657,18659]
===
match
---
argument [54634,54640]
argument [54665,54671]
===
match
---
testlist_comp [69612,69668]
testlist_comp [71236,71292]
===
match
---
name: dag_id [42941,42947]
name: dag_id [42972,42978]
===
match
---
name: dag_id [49793,49799]
name: dag_id [49824,49830]
===
match
---
trailer [3009,3015]
trailer [3040,3046]
===
match
---
operator: , [57595,57596]
operator: , [57626,57627]
===
match
---
comparison [60279,60308]
comparison [60310,60339]
===
match
---
name: airflow [2202,2209]
name: airflow [2233,2240]
===
match
---
comparison [9986,10014]
comparison [10017,10045]
===
match
---
operator: = [23557,23558]
operator: = [23588,23589]
===
match
---
name: datetime [59850,59858]
name: datetime [59881,59889]
===
match
---
name: session [18930,18937]
name: session [18961,18968]
===
match
---
with_stmt [13613,14567]
with_stmt [13644,14598]
===
match
---
name: start_date [61543,61553]
name: start_date [61574,61584]
===
match
---
name: subdag [1862,1868]
name: subdag [1868,1874]
===
match
---
atom_expr [57547,57569]
atom_expr [57578,57600]
===
match
---
name: settings [55234,55242]
name: settings [55265,55273]
===
match
---
name: ti2 [18678,18681]
name: ti2 [18709,18712]
===
match
---
name: delta_timetable [2599,2614]
name: delta_timetable [2630,2645]
===
match
---
name: filter [33949,33955]
name: filter [33980,33986]
===
match
---
atom_expr [34091,34106]
atom_expr [34122,34137]
===
match
---
trailer [44107,44115]
trailer [44138,44146]
===
match
---
name: task_id [7168,7175]
name: task_id [7199,7206]
===
match
---
name: dag [13197,13200]
name: dag [13228,13231]
===
match
---
number: 3 [11268,11269]
number: 3 [11299,11300]
===
match
---
simple_stmt [69218,69272]
simple_stmt [70842,70896]
===
match
---
trailer [52796,52800]
trailer [52827,52831]
===
match
---
suite [25359,25935]
suite [25390,25966]
===
match
---
trailer [59680,59689]
trailer [59711,59720]
===
match
---
assert_stmt [18862,18946]
assert_stmt [18893,18977]
===
match
---
simple_stmt [74764,74840]
simple_stmt [76388,76464]
===
match
---
name: assert_queries_count [30079,30099]
name: assert_queries_count [30110,30130]
===
match
---
trailer [14981,15158]
trailer [15012,15189]
===
match
---
simple_stmt [41525,41559]
simple_stmt [41556,41590]
===
match
---
operator: = [9523,9524]
operator: = [9554,9555]
===
match
---
trailer [73988,73994]
trailer [75612,75618]
===
match
---
number: 1 [62522,62523]
number: 1 [62553,62554]
===
match
---
fstring [50799,50836]
fstring [50830,50867]
===
match
---
name: schedule_interval [8171,8188]
name: schedule_interval [8202,8219]
===
match
---
name: TEST_DATE [42695,42704]
name: TEST_DATE [42726,42735]
===
match
---
simple_stmt [6235,6314]
simple_stmt [6266,6345]
===
match
---
name: test_default_dag_id [71761,71780]
name: test_default_dag_id [73385,73404]
===
match
---
dictorsetmaker [66041,66097]
dictorsetmaker [67665,67721]
===
match
---
name: self [36480,36484]
name: self [36511,36515]
===
match
---
atom_expr [26638,26667]
atom_expr [26669,26698]
===
match
---
dictorsetmaker [20242,20289]
dictorsetmaker [20273,20320]
===
match
---
expr_stmt [2616,2657]
expr_stmt [2647,2688]
===
match
---
name: days [54634,54638]
name: days [54665,54669]
===
match
---
string: """Verify correctness of dag.tree_view().""" [39662,39706]
string: """Verify correctness of dag.tree_view().""" [39693,39737]
===
match
---
atom_expr [24092,24114]
atom_expr [24123,24145]
===
match
---
operator: , [53941,53942]
operator: , [53972,53973]
===
match
---
name: start_date [26178,26188]
name: start_date [26209,26219]
===
match
---
name: default_args [64846,64858]
name: default_args [66470,66482]
===
match
---
simple_stmt [73627,73826]
simple_stmt [75251,75450]
===
match
---
shift_expr [75952,75994]
shift_expr [77576,77618]
===
match
---
name: State [51025,51030]
name: State [51056,51061]
===
match
---
with_stmt [39245,39623]
with_stmt [39276,39654]
===
match
---
name: BaseOperator [25632,25644]
name: BaseOperator [25663,25675]
===
match
---
name: datetime [12778,12786]
name: datetime [12809,12817]
===
match
---
simple_stmt [839,853]
simple_stmt [839,853]
===
match
---
operator: , [19515,19516]
operator: , [19546,19547]
===
match
---
operator: , [67423,67424]
operator: , [69047,69048]
===
match
---
name: dag_pickle [47618,47628]
name: dag_pickle [47649,47659]
===
match
---
trailer [77494,77504]
trailer [79118,79128]
===
match
---
simple_stmt [59149,59366]
simple_stmt [59180,59397]
===
match
---
atom_expr [50678,50770]
atom_expr [50709,50801]
===
match
---
name: task_id [8679,8686]
name: task_id [8710,8717]
===
match
---
atom [77535,77559]
atom [79159,79183]
===
match
---
suite [27353,27398]
suite [27384,27429]
===
match
---
name: template_fields [21840,21855]
name: template_fields [21871,21886]
===
match
---
name: dag_diff_load_time [48971,48989]
name: dag_diff_load_time [49002,49020]
===
match
---
string: 'fakename' [19008,19018]
string: 'fakename' [19039,19049]
===
match
---
name: DAG [45824,45827]
name: DAG [45855,45858]
===
match
---
operator: = [42007,42008]
operator: = [42038,42039]
===
match
---
name: one [33099,33102]
name: one [33130,33133]
===
match
---
number: 2019 [65133,65137]
number: 2019 [66757,66761]
===
match
---
operator: , [49478,49479]
operator: , [49509,49510]
===
match
---
name: params [66896,66902]
name: params [68520,68526]
===
match
---
name: query [45231,45236]
name: query [45262,45267]
===
match
---
name: depth [15256,15261]
name: depth [15287,15292]
===
match
---
name: owner [31166,31171]
name: owner [31197,31202]
===
match
---
operator: = [2626,2627]
operator: = [2657,2658]
===
match
---
expr_stmt [26556,26622]
expr_stmt [26587,26653]
===
match
---
name: row [28881,28884]
name: row [28912,28915]
===
match
---
simple_stmt [33605,33829]
simple_stmt [33636,33860]
===
match
---
suite [3186,3525]
suite [3217,3556]
===
match
---
operator: , [22264,22265]
operator: , [22295,22296]
===
match
---
operator: = [32177,32178]
operator: = [32208,32209]
===
match
---
fstring_expr [15026,15029]
fstring_expr [15057,15060]
===
match
---
expr_stmt [25137,25172]
expr_stmt [25168,25203]
===
match
---
name: dag_models [67835,67845]
name: dag_models [69459,69469]
===
match
---
trailer [13200,13209]
trailer [13231,13240]
===
match
---
expr_stmt [56668,56696]
expr_stmt [56699,56727]
===
match
---
name: DagModel [35871,35879]
name: DagModel [35902,35910]
===
match
---
arglist [73663,73815]
arglist [75287,75439]
===
match
---
trailer [69356,69362]
trailer [70980,70986]
===
match
---
atom_expr [52829,52841]
atom_expr [52860,52872]
===
match
---
operator: = [35347,35348]
operator: = [35378,35379]
===
match
---
name: paused_dag_ids [49671,49685]
name: paused_dag_ids [49702,49716]
===
match
---
operator: , [16165,16166]
operator: , [16196,16197]
===
match
---
atom_expr [18691,18709]
atom_expr [18722,18740]
===
match
---
trailer [62347,62561]
trailer [62378,62592]
===
match
---
name: run_id [77614,77620]
name: run_id [79238,79244]
===
match
---
trailer [28884,28887]
trailer [28915,28918]
===
match
---
name: prev_local [24691,24701]
name: prev_local [24722,24732]
===
match
---
dictorsetmaker [9371,9388]
dictorsetmaker [9402,9419]
===
match
---
simple_stmt [67497,67773]
simple_stmt [69121,69397]
===
match
---
fstring [70360,70377]
fstring [71984,72001]
===
match
---
name: TI [76158,76160]
name: TI [77782,77784]
===
match
---
name: is_active [69130,69139]
name: is_active [70754,70763]
===
match
---
operator: -> [3042,3044]
operator: -> [3073,3075]
===
match
---
assert_stmt [4817,4873]
assert_stmt [4848,4904]
===
match
---
name: start_date [46848,46858]
name: start_date [46879,46889]
===
match
---
name: utc [23107,23110]
name: utc [23138,23141]
===
match
---
atom_expr [22434,22464]
atom_expr [22465,22495]
===
match
---
parameters [51678,51699]
parameters [51709,51730]
===
match
---
argument [34857,34882]
argument [34888,34913]
===
match
---
atom [50094,50139]
atom [50125,50170]
===
match
---
operator: , [15078,15079]
operator: , [15109,15110]
===
match
---
trailer [25631,25708]
trailer [25662,25739]
===
match
---
trailer [32965,32967]
trailer [32996,32998]
===
match
---
operator: = [51126,51127]
operator: = [51157,51158]
===
match
---
name: dags [28265,28269]
name: dags [28296,28300]
===
match
---
name: DagRunType [56396,56406]
name: DagRunType [56427,56437]
===
match
---
arglist [35797,35832]
arglist [35828,35863]
===
match
---
operator: = [9658,9659]
operator: = [9689,9690]
===
match
---
trailer [31576,31588]
trailer [31607,31619]
===
match
---
name: jinja_env [20350,20359]
name: jinja_env [20381,20390]
===
match
---
argument [9357,9389]
argument [9388,9420]
===
match
---
number: 4 [30100,30101]
number: 4 [30131,30132]
===
match
---
testlist_comp [21859,21872]
testlist_comp [21890,21903]
===
match
---
operator: } [11762,11763]
operator: } [11793,11794]
===
match
---
atom_expr [73864,73881]
atom_expr [75488,75505]
===
match
---
atom_expr [67848,67892]
atom_expr [69472,69516]
===
match
---
atom_expr [13810,13825]
atom_expr [13841,13856]
===
match
---
name: pendulum [22174,22182]
name: pendulum [22205,22213]
===
match
---
operator: { [47470,47471]
operator: { [47501,47502]
===
match
---
name: DEFAULT_DATE [53859,53871]
name: DEFAULT_DATE [53890,53902]
===
match
---
expr_stmt [76408,76452]
expr_stmt [78032,78076]
===
match
---
atom_expr [28207,28230]
atom_expr [28238,28261]
===
match
---
trailer [44245,44269]
trailer [44276,44300]
===
match
---
comparison [60235,60263]
comparison [60266,60294]
===
match
---
trailer [46400,46415]
trailer [46431,46446]
===
match
---
simple_stmt [71205,71227]
simple_stmt [72829,72851]
===
match
---
atom_expr [65444,65460]
atom_expr [67068,67084]
===
match
---
funcdef [8040,9264]
funcdef [8071,9295]
===
match
---
trailer [32853,32866]
trailer [32884,32897]
===
match
---
operator: = [44774,44775]
operator: = [44805,44806]
===
match
---
name: timezone [61554,61562]
name: timezone [61585,61593]
===
match
---
comparison [75364,75397]
comparison [76988,77021]
===
match
---
expr_stmt [68874,68902]
expr_stmt [70498,70526]
===
match
---
name: dag [34902,34905]
name: dag [34933,34936]
===
match
---
argument [57392,57432]
argument [57423,57463]
===
match
---
name: dagruns [52864,52871]
name: dagruns [52895,52902]
===
match
---
param [36921,36925]
param [36952,36956]
===
match
---
expr_stmt [58308,58318]
expr_stmt [58339,58349]
===
match
---
name: tasks [9937,9942]
name: tasks [9968,9973]
===
match
---
name: dag_id [54906,54912]
name: dag_id [54937,54943]
===
match
---
simple_stmt [11244,11279]
simple_stmt [11275,11310]
===
match
---
name: priority_weight [16385,16400]
name: priority_weight [16416,16431]
===
match
---
operator: , [27494,27495]
operator: , [27525,27526]
===
match
---
funcdef [3896,4213]
funcdef [3927,4244]
===
match
---
operator: = [20310,20311]
operator: = [20341,20342]
===
match
---
name: jinja_env [20405,20414]
name: jinja_env [20436,20445]
===
match
---
name: DAG [26562,26565]
name: DAG [26593,26596]
===
match
---
name: start_date [59264,59274]
name: start_date [59295,59305]
===
match
---
operator: = [50704,50705]
operator: = [50735,50736]
===
match
---
operator: , [29341,29342]
operator: , [29372,29373]
===
match
---
trailer [62516,62524]
trailer [62547,62555]
===
match
---
operator: { [17308,17309]
operator: { [17339,17340]
===
match
---
string: 'owner' [47471,47478]
string: 'owner' [47502,47509]
===
match
---
name: dag [65354,65357]
name: dag [66978,66981]
===
match
---
trailer [78560,78569]
trailer [80184,80193]
===
match
---
name: pendulum [23281,23289]
name: pendulum [23312,23320]
===
match
---
trailer [43219,43225]
trailer [43250,43256]
===
match
---
operator: = [10240,10241]
operator: = [10271,10272]
===
match
---
operator: = [41119,41120]
operator: = [41150,41151]
===
match
---
suite [63298,64358]
suite [64922,65982]
===
match
---
operator: == [37153,37155]
operator: == [37184,37186]
===
match
---
name: datetime [61563,61571]
name: datetime [61594,61602]
===
match
---
operator: = [6973,6974]
operator: = [7004,7005]
===
match
---
arglist [32170,32200]
arglist [32201,32231]
===
match
---
atom_expr [47618,47642]
atom_expr [47649,47673]
===
match
---
trailer [25121,25128]
trailer [25152,25159]
===
match
---
operator: = [27755,27756]
operator: = [27786,27787]
===
match
---
expr_stmt [24913,24949]
expr_stmt [24944,24980]
===
match
---
parameters [72489,72494]
parameters [74113,74118]
===
match
---
comparison [21979,22025]
comparison [22010,22056]
===
match
---
operator: , [57066,57067]
operator: , [57097,57098]
===
match
---
operator: * [15814,15815]
operator: * [15845,15846]
===
match
---
trailer [27464,27466]
trailer [27495,27497]
===
match
---
name: self [28054,28058]
name: self [28085,28089]
===
match
---
operator: , [48295,48296]
operator: , [48326,48327]
===
match
---
atom_expr [36685,36700]
atom_expr [36716,36731]
===
match
---
atom_expr [36654,36732]
atom_expr [36685,36763]
===
match
---
trailer [14231,14245]
trailer [14262,14276]
===
match
---
name: dag_id [46678,46684]
name: dag_id [46709,46715]
===
match
---
atom_expr [39879,39906]
atom_expr [39910,39937]
===
match
---
name: airflow [1746,1753]
name: airflow [1752,1759]
===
match
---
trailer [67856,67877]
trailer [69480,69501]
===
match
---
name: remove [10029,10035]
name: remove [10060,10066]
===
match
---
simple_stmt [22428,22465]
simple_stmt [22459,22496]
===
match
---
name: dag [65394,65397]
name: dag [67018,67021]
===
match
---
operator: , [55095,55096]
operator: , [55126,55127]
===
match
---
string: b'{{ ds }}' [21476,21487]
string: b'{{ ds }}' [21507,21518]
===
match
---
import_from [2386,2423]
import_from [2417,2454]
===
match
---
expr_stmt [22474,22544]
expr_stmt [22505,22575]
===
match
---
operator: = [32191,32192]
operator: = [32222,32223]
===
match
---
import_name [788,803]
import_name [788,803]
===
match
---
operator: = [23778,23779]
operator: = [23809,23810]
===
match
---
name: clear_db_runs [71051,71064]
name: clear_db_runs [72675,72688]
===
match
---
name: DummyOperator [38836,38849]
name: DummyOperator [38867,38880]
===
match
---
trailer [73195,73197]
trailer [74819,74821]
===
match
---
name: self [27677,27681]
name: self [27708,27712]
===
match
---
arglist [48000,48030]
arglist [48031,48061]
===
match
---
name: session [51935,51942]
name: session [51966,51973]
===
match
---
trailer [72682,72684]
trailer [74306,74308]
===
match
---
simple_stmt [41571,41582]
simple_stmt [41602,41613]
===
match
---
comp_op [68536,68542]
comp_op [70160,70166]
===
match
---
operator: @ [72288,72289]
operator: @ [73912,73913]
===
match
---
string: 'owner' [47814,47821]
string: 'owner' [47845,47852]
===
match
---
atom_expr [32983,33002]
atom_expr [33014,33033]
===
match
---
atom_expr [51363,51487]
atom_expr [51394,51518]
===
match
---
name: DagRunInfo [77743,77753]
name: DagRunInfo [79367,79377]
===
match
---
simple_stmt [51787,51802]
simple_stmt [51818,51833]
===
match
---
name: task [14162,14166]
name: task [14193,14197]
===
match
---
comparison [3868,3890]
comparison [3899,3921]
===
match
---
name: dag [45896,45899]
name: dag [45927,45930]
===
match
---
trailer [57130,57146]
trailer [57161,57177]
===
match
---
expr_stmt [48348,48382]
expr_stmt [48379,48413]
===
match
---
name: DAG [27722,27725]
name: DAG [27753,27756]
===
match
---
name: child_dag [8106,8115]
name: child_dag [8137,8146]
===
match
---
operator: , [13859,13860]
operator: , [13890,13891]
===
match
---
for_stmt [30009,30066]
for_stmt [30040,30097]
===
match
---
name: stdout_lines [40189,40201]
name: stdout_lines [40220,40232]
===
match
---
trailer [16455,16464]
trailer [16486,16495]
===
match
---
name: query [36662,36667]
name: query [36693,36698]
===
match
---
suite [7270,7392]
suite [7301,7423]
===
match
---
atom_expr [3083,3098]
atom_expr [3114,3129]
===
match
---
assert_stmt [20092,20132]
assert_stmt [20123,20163]
===
match
---
comparison [58443,58460]
comparison [58474,58491]
===
match
---
operator: = [24875,24876]
operator: = [24906,24907]
===
match
---
import_from [2046,2080]
import_from [2077,2111]
===
match
---
funcdef [71515,71651]
funcdef [73139,73275]
===
match
---
name: tree_view [40017,40026]
name: tree_view [40048,40057]
===
match
---
trailer [28247,28264]
trailer [28278,28295]
===
match
---
simple_stmt [42184,42257]
simple_stmt [42215,42288]
===
match
---
name: session [18837,18844]
name: session [18868,18875]
===
match
---
name: WeightRule [15116,15126]
name: WeightRule [15147,15157]
===
match
---
trailer [53529,53543]
trailer [53560,53574]
===
match
---
trailer [28433,28436]
trailer [28464,28467]
===
match
---
name: DAG [57345,57348]
name: DAG [57376,57379]
===
match
---
name: run_id [18550,18556]
name: run_id [18581,18587]
===
match
---
trailer [44344,44349]
trailer [44375,44380]
===
match
---
name: external_trigger [45103,45119]
name: external_trigger [45134,45150]
===
match
---
atom_expr [67704,67733]
atom_expr [69328,69357]
===
match
---
operator: , [34461,34462]
operator: , [34492,34493]
===
match
---
name: dag [78751,78754]
name: dag [80375,80378]
===
match
---
suite [19704,19740]
suite [19735,19771]
===
match
---
operator: = [10916,10917]
operator: = [10947,10948]
===
match
---
argument [11696,11763]
argument [11727,11794]
===
match
---
assert_stmt [7701,7737]
assert_stmt [7732,7768]
===
match
---
expr_stmt [9861,9884]
expr_stmt [9892,9915]
===
match
---
operator: = [60953,60954]
operator: = [60984,60985]
===
match
---
trailer [40595,40609]
trailer [40626,40640]
===
match
---
atom [28585,28616]
atom [28616,28647]
===
match
---
atom_expr [42194,42240]
atom_expr [42225,42271]
===
match
---
name: next_info [61748,61757]
name: next_info [61779,61788]
===
match
---
parameters [57749,57755]
parameters [57780,57786]
===
match
---
number: 4 [72547,72548]
number: 4 [74171,74172]
===
match
---
name: start_date [68081,68091]
name: start_date [69705,69715]
===
match
---
name: range [28180,28185]
name: range [28211,28216]
===
match
---
name: query [76152,76157]
name: query [77776,77781]
===
match
---
atom_expr [56055,56068]
atom_expr [56086,56099]
===
match
---
dictorsetmaker [10292,10309]
dictorsetmaker [10323,10340]
===
match
---
operator: == [77379,77381]
operator: == [79003,79005]
===
match
---
suite [17379,17456]
suite [17410,17487]
===
match
---
operator: == [24115,24117]
operator: == [24146,24148]
===
match
---
name: State [55940,55945]
name: State [55971,55976]
===
match
---
number: 1 [53268,53269]
number: 1 [53299,53300]
===
match
---
name: session [52176,52183]
name: session [52207,52214]
===
match
---
name: dag_maker [75608,75617]
name: dag_maker [77232,77241]
===
match
---
atom_expr [3059,3074]
atom_expr [3090,3105]
===
match
---
operator: , [40657,40658]
operator: , [40688,40689]
===
match
---
name: dag_run [43068,43075]
name: dag_run [43099,43106]
===
match
---
atom_expr [7094,7103]
atom_expr [7125,7134]
===
match
---
atom_expr [77743,77820]
atom_expr [79367,79444]
===
match
---
name: match [6037,6042]
name: match [6068,6073]
===
match
---
operator: = [51907,51908]
operator: = [51938,51939]
===
match
---
operator: = [15611,15612]
operator: = [15642,15643]
===
match
---
simple_stmt [24368,24414]
simple_stmt [24399,24445]
===
match
---
trailer [10245,10311]
trailer [10276,10342]
===
match
---
name: op3 [41601,41604]
name: op3 [41632,41635]
===
match
---
trailer [12944,12953]
trailer [12975,12984]
===
match
---
parameters [76107,76113]
parameters [77731,77737]
===
match
---
operator: } [35651,35652]
operator: } [35682,35683]
===
match
---
operator: , [64624,64625]
operator: , [66248,66249]
===
match
---
assert_stmt [20343,20389]
assert_stmt [20374,20420]
===
match
---
argument [53816,53834]
argument [53847,53865]
===
match
---
trailer [54470,54488]
trailer [54501,54519]
===
match
---
operator: = [25148,25149]
operator: = [25179,25180]
===
match
---
operator: = [53057,53058]
operator: = [53088,53089]
===
match
---
atom_expr [42359,42393]
atom_expr [42390,42424]
===
match
---
operator: = [78010,78011]
operator: = [79634,79635]
===
match
---
name: dag [69882,69885]
name: dag [71506,71509]
===
match
---
trailer [7202,7206]
trailer [7233,7237]
===
match
---
expr_stmt [59379,59421]
expr_stmt [59410,59452]
===
match
---
name: run_id [18454,18460]
name: run_id [18485,18491]
===
match
---
atom_expr [10944,10963]
atom_expr [10975,10994]
===
match
---
name: test_is_paused_subdag [34137,34158]
name: test_is_paused_subdag [34168,34189]
===
match
---
atom_expr [23394,23417]
atom_expr [23425,23448]
===
match
---
name: utc [24900,24903]
name: utc [24931,24934]
===
match
---
name: test_following_previous_schedule [22035,22067]
name: test_following_previous_schedule [22066,22098]
===
match
---
string: '{{ ds }}' [21337,21347]
string: '{{ ds }}' [21368,21378]
===
match
---
simple_stmt [6382,6449]
simple_stmt [6413,6480]
===
match
---
simple_stmt [3588,3655]
simple_stmt [3619,3686]
===
match
---
name: subdag [54457,54463]
name: subdag [54488,54494]
===
match
---
argument [77890,77897]
argument [79514,79521]
===
match
---
name: next_info [58443,58452]
name: next_info [58474,58483]
===
match
---
name: f [20910,20911]
name: f [20941,20942]
===
match
---
operator: , [33654,33655]
operator: , [33685,33686]
===
match
---
simple_stmt [7310,7345]
simple_stmt [7341,7376]
===
match
---
suite [27275,27319]
suite [27306,27350]
===
match
---
trailer [66081,66097]
trailer [67705,67721]
===
match
---
name: enumerate [13910,13919]
name: enumerate [13941,13950]
===
match
---
funcdef [11770,12670]
funcdef [11801,12701]
===
match
---
operator: == [49222,49224]
operator: == [49253,49255]
===
match
---
simple_stmt [57933,57942]
simple_stmt [57964,57973]
===
match
---
argument [60857,60882]
argument [60888,60913]
===
match
---
string: 'start_date' [11710,11722]
string: 'start_date' [11741,11753]
===
match
---
assert_stmt [68505,68547]
assert_stmt [70129,70171]
===
match
---
expr_stmt [23996,24031]
expr_stmt [24027,24062]
===
match
---
operator: = [25652,25653]
operator: = [25683,25684]
===
match
---
name: DummyOperator [8328,8341]
name: DummyOperator [8359,8372]
===
match
---
trailer [69175,69184]
trailer [70799,70808]
===
match
---
operator: , [78434,78435]
operator: , [80058,80059]
===
match
---
name: ACTION_CAN_EDIT [66082,66097]
name: ACTION_CAN_EDIT [67706,67721]
===
match
---
operator: = [15115,15116]
operator: = [15146,15147]
===
match
---
name: DEFAULT_DATE [7579,7591]
name: DEFAULT_DATE [7610,7622]
===
match
---
simple_stmt [50779,50837]
simple_stmt [50810,50868]
===
match
---
simple_stmt [11202,11235]
simple_stmt [11233,11266]
===
match
---
dictorsetmaker [70688,70845]
dictorsetmaker [72312,72469]
===
match
---
name: dag [24571,24574]
name: dag [24602,24605]
===
match
---
funcdef [27173,27244]
funcdef [27204,27275]
===
match
---
trailer [33985,33987]
trailer [34016,34018]
===
match
---
operator: } [20289,20290]
operator: } [20320,20321]
===
match
---
name: stage [16625,16630]
name: stage [16656,16661]
===
match
---
name: cache [20415,20420]
name: cache [20446,20451]
===
match
---
operator: = [18124,18125]
operator: = [18155,18156]
===
match
---
funcdef [45570,46543]
funcdef [45601,46574]
===
match
---
trailer [11491,11508]
trailer [11522,11539]
===
match
---
trailer [79002,79011]
trailer [80626,80635]
===
match
---
comp_op [42892,42898]
comp_op [42923,42929]
===
match
---
trailer [57098,57100]
trailer [57129,57131]
===
match
---
name: start_date [42684,42694]
name: start_date [42715,42725]
===
match
---
operator: } [13769,13770]
operator: } [13800,13801]
===
match
---
operator: = [78796,78797]
operator: = [80420,80421]
===
match
---
name: datetime [64329,64337]
name: datetime [65953,65961]
===
match
---
operator: = [70396,70397]
operator: = [72020,72021]
===
match
---
operator: , [19386,19387]
operator: , [19417,19418]
===
match
---
operator: = [38972,38973]
operator: = [39003,39004]
===
match
---
argument [31157,31164]
argument [31188,31195]
===
match
---
name: DagRunType [53566,53576]
name: DagRunType [53597,53607]
===
match
---
argument [67529,67546]
argument [69153,69170]
===
match
---
assert_stmt [42956,42989]
assert_stmt [42987,43020]
===
match
---
argument [16336,16359]
argument [16367,16390]
===
match
---
trailer [23442,23457]
trailer [23473,23488]
===
match
---
number: 10 [63693,63695]
number: 10 [65317,65319]
===
match
---
trailer [62888,62913]
trailer [62919,62944]
===
match
---
name: dag_id [35177,35183]
name: dag_id [35208,35214]
===
match
---
name: value [74348,74353]
name: value [75972,75977]
===
match
---
simple_stmt [63307,63571]
simple_stmt [64931,65195]
===
match
---
trailer [56557,56563]
trailer [56588,56594]
===
match
---
name: datetime [50292,50300]
name: datetime [50323,50331]
===
match
---
name: tzinfo [26120,26126]
name: tzinfo [26151,26157]
===
match
---
operator: , [41043,41044]
operator: , [41074,41075]
===
match
---
name: task_id [68145,68152]
name: task_id [69769,69776]
===
match
---
trailer [50822,50832]
trailer [50853,50863]
===
match
---
and_test [61984,62053]
and_test [62015,62084]
===
match
---
atom_expr [22784,22810]
atom_expr [22815,22841]
===
match
---
operator: = [67198,67199]
operator: = [68822,68823]
===
match
---
dotted_name [1645,1663]
dotted_name [1651,1669]
===
match
---
trailer [32766,32772]
trailer [32797,32803]
===
match
---
name: operator [73840,73848]
name: operator [75464,75472]
===
match
---
simple_stmt [58712,58764]
simple_stmt [58743,58795]
===
match
---
operator: + [55425,55426]
operator: + [55456,55457]
===
match
---
atom_expr [73966,73980]
atom_expr [75590,75604]
===
match
---
string: 'some_string' [21808,21821]
string: 'some_string' [21839,21852]
===
match
---
fstring_end: ' [13774,13775]
fstring_end: ' [13805,13806]
===
match
---
trailer [10883,10901]
trailer [10914,10932]
===
match
---
expr_stmt [10468,10500]
expr_stmt [10499,10531]
===
match
---
operator: = [43524,43525]
operator: = [43555,43556]
===
match
---
atom_expr [47090,47103]
atom_expr [47121,47134]
===
match
---
arglist [44879,44943]
arglist [44910,44974]
===
match
---
number: 1 [56226,56227]
number: 1 [56257,56258]
===
match
---
trailer [78929,79052]
trailer [80553,80676]
===
match
---
suite [64910,64999]
suite [66534,66623]
===
match
---
simple_stmt [45612,45768]
simple_stmt [45643,45799]
===
match
---
atom_expr [50526,50539]
atom_expr [50557,50570]
===
match
---
expr_stmt [34432,34509]
expr_stmt [34463,34540]
===
match
---
operator: = [70588,70589]
operator: = [72212,72213]
===
match
---
name: tzinfo [38438,38444]
name: tzinfo [38469,38475]
===
match
---
name: all [30351,30354]
name: all [30382,30385]
===
match
---
string: '2019-06-01' [11724,11736]
string: '2019-06-01' [11755,11767]
===
match
---
string: 'dag-bulk-sync-2' [29726,29743]
string: 'dag-bulk-sync-2' [29757,29774]
===
match
---
argument [6118,6151]
argument [6149,6182]
===
match
---
name: self [74821,74825]
name: self [76445,76449]
===
match
---
name: dagrun [77488,77494]
name: dagrun [79112,79118]
===
match
---
arglist [58214,58253]
arglist [58245,58284]
===
match
---
simple_stmt [38968,39002]
simple_stmt [38999,39033]
===
match
---
trailer [57654,57668]
trailer [57685,57699]
===
match
---
atom_expr [5226,5264]
atom_expr [5257,5295]
===
match
---
operator: = [25603,25604]
operator: = [25634,25635]
===
match
---
simple_stmt [21468,21489]
simple_stmt [21499,21520]
===
match
---
trailer [21597,21606]
trailer [21628,21637]
===
match
---
name: default_args [73330,73342]
name: default_args [74954,74966]
===
match
---
operator: == [12546,12548]
operator: == [12577,12579]
===
match
---
arglist [54554,54783]
arglist [54585,54814]
===
match
---
name: get_task_instances [73927,73945]
name: get_task_instances [75551,75569]
===
match
---
with_item [7542,7599]
with_item [7573,7630]
===
match
---
operator: = [77816,77817]
operator: = [79440,79441]
===
match
---
comparison [24966,25019]
comparison [24997,25050]
===
match
---
trailer [31335,31342]
trailer [31366,31373]
===
match
---
operator: = [22559,22560]
operator: = [22590,22591]
===
match
---
name: DEFAULT_DATE [70856,70868]
name: DEFAULT_DATE [72480,72492]
===
match
---
name: dag_id [33965,33971]
name: dag_id [33996,34002]
===
match
---
trailer [24464,24480]
trailer [24495,24511]
===
match
---
atom_expr [42245,42256]
atom_expr [42276,42287]
===
match
---
testlist_comp [16275,16591]
testlist_comp [16306,16622]
===
match
---
trailer [76625,76627]
trailer [78249,78251]
===
match
---
name: session [76752,76759]
name: session [78376,78383]
===
match
---
name: owner [42665,42670]
name: owner [42696,42701]
===
match
---
simple_stmt [47364,47387]
simple_stmt [47395,47418]
===
match
---
with_item [65044,65245]
with_item [66668,66869]
===
match
---
trailer [2714,2716]
trailer [2745,2747]
===
match
---
name: local_tz [38545,38553]
name: local_tz [38576,38584]
===
match
---
name: dagrun [54803,54809]
name: dagrun [54834,54840]
===
match
---
operator: , [67761,67762]
operator: , [69385,69386]
===
match
---
simple_stmt [25251,25306]
simple_stmt [25282,25337]
===
match
---
argument [17270,17293]
argument [17301,17324]
===
match
---
operator: , [78197,78198]
operator: , [79821,79822]
===
match
---
string: 'start_date' [12610,12622]
string: 'start_date' [12641,12653]
===
match
---
operator: , [16407,16408]
operator: , [16438,16439]
===
match
---
name: Session [51954,51961]
name: Session [51985,51992]
===
match
---
trailer [55352,55604]
trailer [55383,55635]
===
match
---
arglist [32072,32115]
arglist [32103,32146]
===
match
---
trailer [44087,44101]
trailer [44118,44132]
===
match
---
assert_stmt [77528,77625]
assert_stmt [79152,79249]
===
match
---
string: 'op1' [21110,21115]
string: 'op1' [21141,21146]
===
match
---
simple_stmt [2851,2867]
simple_stmt [2882,2898]
===
match
---
operator: = [68272,68273]
operator: = [69896,69897]
===
match
---
atom_expr [28101,28170]
atom_expr [28132,28201]
===
match
---
string: 't3' [40224,40228]
string: 't3' [40255,40259]
===
match
---
name: clear [55347,55352]
name: clear [55378,55383]
===
match
---
string: "2018-03-25T03:00:00+00:00" [26703,26730]
string: "2018-03-25T03:00:00+00:00" [26734,26761]
===
match
---
name: create_session [29275,29289]
name: create_session [29306,29320]
===
match
---
operator: = [59842,59843]
operator: = [59873,59874]
===
match
---
name: has_task_concurrency_limits [68297,68324]
name: has_task_concurrency_limits [69921,69948]
===
match
---
operator: = [52538,52539]
operator: = [52569,52570]
===
match
---
name: op1 [9519,9522]
name: op1 [9550,9553]
===
match
---
argument [7862,7875]
argument [7893,7906]
===
match
---
operator: = [24626,24627]
operator: = [24657,24658]
===
match
---
with_item [20767,20810]
with_item [20798,20841]
===
match
---
name: external_trigger [47117,47133]
name: external_trigger [47148,47164]
===
match
---
name: j [13805,13806]
name: j [13836,13837]
===
match
---
term [14394,14443]
term [14425,14474]
===
match
---
expr_stmt [71660,71681]
expr_stmt [73284,73305]
===
match
---
argument [58236,58253]
argument [58267,58284]
===
match
---
trailer [53515,53517]
trailer [53546,53548]
===
match
---
funcdef [67250,67977]
funcdef [68874,69601]
===
match
---
operator: , [64189,64190]
operator: , [65813,65814]
===
match
---
name: unittest [2794,2802]
name: unittest [2825,2833]
===
match
---
operator: = [62342,62343]
operator: = [62373,62374]
===
match
---
name: isoformat [24754,24763]
name: isoformat [24785,24794]
===
match
---
name: next_dagrun_info [58723,58739]
name: next_dagrun_info [58754,58770]
===
match
---
trailer [12876,12925]
trailer [12907,12956]
===
match
---
operator: + [53216,53217]
operator: + [53247,53248]
===
match
---
name: timedelta [78243,78252]
name: timedelta [79867,79876]
===
match
---
trailer [76479,76485]
trailer [78103,78109]
===
match
---
simple_stmt [11568,11622]
simple_stmt [11599,11653]
===
match
---
arglist [6118,6174]
arglist [6149,6205]
===
match
---
name: delete [3387,3393]
name: delete [3418,3424]
===
match
---
atom_expr [54615,54641]
atom_expr [54646,54672]
===
match
---
atom_expr [39250,39290]
atom_expr [39281,39321]
===
match
---
atom_expr [69227,69271]
atom_expr [70851,70895]
===
match
---
number: 1 [14432,14433]
number: 1 [14463,14464]
===
match
---
name: State [55955,55960]
name: State [55986,55991]
===
match
---
simple_stmt [62184,62330]
simple_stmt [62215,62361]
===
match
---
operator: , [67729,67730]
operator: , [69353,69354]
===
match
---
name: ValueError [66965,66975]
name: ValueError [68589,68599]
===
match
---
atom_expr [7439,7446]
atom_expr [7470,7477]
===
match
---
atom_expr [40401,40492]
atom_expr [40432,40523]
===
match
---
trailer [77278,77286]
trailer [78902,78910]
===
match
---
operator: = [18608,18609]
operator: = [18639,18640]
===
match
---
simple_stmt [14377,14444]
simple_stmt [14408,14475]
===
match
---
comparison [13197,13230]
comparison [13228,13261]
===
match
---
operator: = [58172,58173]
operator: = [58203,58204]
===
match
---
name: baseoperator [1607,1619]
name: baseoperator [1613,1625]
===
match
---
name: session [55586,55593]
name: session [55617,55624]
===
match
---
number: 2018 [12913,12917]
number: 2018 [12944,12948]
===
match
---
operator: = [65173,65174]
operator: = [66797,66798]
===
match
---
operator: = [53316,53317]
operator: = [53347,53348]
===
match
---
trailer [37677,37723]
trailer [37708,37754]
===
match
---
name: WeightRule [2375,2385]
name: WeightRule [2406,2416]
===
match
---
operator: = [76641,76642]
operator: = [78265,78266]
===
match
---
name: state [76431,76436]
name: state [78055,78060]
===
match
---
atom_expr [8736,8769]
atom_expr [8767,8800]
===
match
---
name: stdout_lines [40085,40097]
name: stdout_lines [40116,40128]
===
match
---
comparison [71321,71344]
comparison [72945,72968]
===
match
---
string: """         Test `default_view` default value of DAG initialization         """ [5640,5719]
string: """         Test `default_view` default value of DAG initialization         """ [5671,5750]
===
match
---
simple_stmt [17000,17024]
simple_stmt [17031,17055]
===
match
---
name: dag_id [72141,72147]
name: dag_id [73765,73771]
===
match
---
name: dag_id [71737,71743]
name: dag_id [73361,73367]
===
match
---
operator: = [39522,39523]
operator: = [39553,39554]
===
match
---
name: range [13810,13815]
name: range [13841,13846]
===
match
---
number: 4 [28189,28190]
number: 4 [28220,28221]
===
match
---
operator: = [17577,17578]
operator: = [17608,17609]
===
match
---
operator: = [68176,68177]
operator: = [69800,69801]
===
match
---
name: task_id [39469,39476]
name: task_id [39500,39507]
===
match
---
argument [11432,11464]
argument [11463,11495]
===
match
---
name: op1 [6888,6891]
name: op1 [6919,6922]
===
match
---
operator: == [77293,77295]
operator: == [78917,78919]
===
match
---
name: default_args [72303,72315]
name: default_args [73927,73939]
===
match
---
name: tasks [10009,10014]
name: tasks [10040,10045]
===
match
---
name: ti_state_begin [56025,56039]
name: ti_state_begin [56056,56070]
===
match
---
trailer [19262,19270]
trailer [19293,19301]
===
match
---
trailer [76032,76083]
trailer [77656,77707]
===
match
---
trailer [41737,41745]
trailer [41768,41776]
===
match
---
atom [14404,14420]
atom [14435,14451]
===
match
---
operator: = [42650,42651]
operator: = [42681,42682]
===
match
---
arglist [67529,67762]
arglist [69153,69386]
===
match
---
operator: = [8221,8222]
operator: = [8252,8253]
===
match
---
operator: , [42682,42683]
operator: , [42713,42714]
===
match
---
simple_stmt [2337,2386]
simple_stmt [2368,2417]
===
match
---
operator: , [70145,70146]
operator: , [71769,71770]
===
match
---
name: end_date [74812,74820]
name: end_date [76436,76444]
===
match
---
name: test_dag_id [17619,17630]
name: test_dag_id [17650,17661]
===
match
---
atom_expr [65115,65144]
atom_expr [66739,66768]
===
match
---
simple_stmt [61680,61719]
simple_stmt [61711,61750]
===
match
---
operator: = [52022,52023]
operator: = [52053,52054]
===
match
---
atom_expr [23869,23891]
atom_expr [23900,23922]
===
match
---
atom_expr [38035,38098]
atom_expr [38066,38129]
===
match
---
trailer [3393,3420]
trailer [3424,3451]
===
match
---
atom_expr [10871,10901]
atom_expr [10902,10932]
===
match
---
simple_stmt [21523,21562]
simple_stmt [21554,21593]
===
match
---
trailer [47593,47600]
trailer [47624,47631]
===
match
---
string: 'dag-bulk-sync-3' [28390,28407]
string: 'dag-bulk-sync-3' [28421,28438]
===
match
---
atom_expr [29957,29968]
atom_expr [29988,29999]
===
match
---
trailer [38536,38541]
trailer [38567,38572]
===
match
---
name: dag_id [63602,63608]
name: dag_id [65226,65232]
===
match
---
operator: = [43860,43861]
operator: = [43891,43892]
===
match
---
name: state [76731,76736]
name: state [78355,78360]
===
match
---
operator: = [72880,72881]
operator: = [74504,74505]
===
match
---
expr_stmt [8730,8769]
expr_stmt [8761,8800]
===
match
---
operator: , [64198,64199]
operator: , [65822,65823]
===
match
---
param [74954,74958]
param [76578,76582]
===
match
---
simple_stmt [3107,3136]
simple_stmt [3138,3167]
===
match
---
argument [9629,9640]
argument [9660,9671]
===
match
---
simple_stmt [57339,57470]
simple_stmt [57370,57501]
===
match
---
arglist [61572,61582]
arglist [61603,61613]
===
match
---
name: last_parsed_time [28833,28849]
name: last_parsed_time [28864,28880]
===
match
---
operator: , [74625,74626]
operator: , [76249,76250]
===
match
---
suite [73408,73585]
suite [75032,75209]
===
match
---
simple_stmt [57765,57881]
simple_stmt [57796,57912]
===
match
---
name: start_date [67344,67354]
name: start_date [68968,68978]
===
match
---
atom_expr [32695,32710]
atom_expr [32726,32741]
===
match
---
simple_stmt [56292,56337]
simple_stmt [56323,56368]
===
match
---
name: op4 [10771,10774]
name: op4 [10802,10805]
===
match
---
trailer [5150,5165]
trailer [5181,5196]
===
match
---
string: """Test that dag param is correctly set when using dag decorator""" [74969,75036]
string: """Test that dag param is correctly set when using dag decorator""" [76593,76660]
===
match
---
simple_stmt [5728,5781]
simple_stmt [5759,5812]
===
match
---
simple_stmt [45471,45533]
simple_stmt [45502,45564]
===
match
---
number: 1 [62473,62474]
number: 1 [62504,62505]
===
match
---
name: DagRunType [2326,2336]
name: DagRunType [2357,2367]
===
match
---
operator: , [46846,46847]
operator: , [46877,46878]
===
match
---
name: next_parent_info [65635,65651]
name: next_parent_info [67259,67275]
===
match
---
name: state [52264,52269]
name: state [52295,52300]
===
match
---
atom_expr [71132,71149]
atom_expr [72756,72773]
===
match
---
simple_stmt [36161,36178]
simple_stmt [36192,36209]
===
match
---
string: 'webserver' [5805,5816]
string: 'webserver' [5836,5847]
===
match
---
name: next_dagrun_info [65800,65816]
name: next_dagrun_info [67424,67440]
===
match
---
atom_expr [43212,43225]
atom_expr [43243,43256]
===
match
---
argument [44123,44149]
argument [44154,44180]
===
match
---
name: dag [68031,68034]
name: dag [69655,69658]
===
match
---
funcdef [37330,38247]
funcdef [37361,38278]
===
match
---
expr_stmt [16115,16124]
expr_stmt [16146,16155]
===
match
---
comparison [20044,20083]
comparison [20075,20114]
===
match
---
trailer [25272,25274]
trailer [25303,25305]
===
match
---
arglist [8679,8716]
arglist [8710,8747]
===
match
---
atom_expr [41485,41512]
atom_expr [41516,41543]
===
match
---
atom_expr [59601,59618]
atom_expr [59632,59649]
===
match
---
operator: , [77898,77899]
operator: , [79522,79523]
===
match
---
name: correct_weight [14377,14391]
name: correct_weight [14408,14422]
===
match
---
name: num [72989,72992]
name: num [74613,74616]
===
match
---
dotted_name [1984,2009]
dotted_name [2015,2040]
===
match
---
name: timezone [63663,63671]
name: timezone [65287,65295]
===
match
---
expr_stmt [4627,4654]
expr_stmt [4658,4685]
===
match
---
name: template_searchpath [21674,21693]
name: template_searchpath [21705,21724]
===
match
---
arglist [65747,65763]
arglist [67371,67387]
===
match
---
name: filter [3457,3463]
name: filter [3488,3494]
===
match
---
name: dag [49217,49220]
name: dag [49248,49251]
===
match
---
suite [4286,4874]
suite [4317,4905]
===
match
---
argument [56387,56419]
argument [56418,56450]
===
match
---
name: creating_job_id [51455,51470]
name: creating_job_id [51486,51501]
===
match
---
string: 't3' [59517,59521]
string: 't3' [59548,59552]
===
match
---
trailer [3301,3328]
trailer [3332,3359]
===
match
---
name: datetime [27415,27423]
name: datetime [27446,27454]
===
match
---
argument [32537,32551]
argument [32568,32582]
===
match
---
number: 0 [65759,65760]
number: 0 [67383,67384]
===
match
---
name: settings [53499,53507]
name: settings [53530,53538]
===
match
---
arglist [26104,26148]
arglist [26135,26179]
===
match
---
trailer [37252,37269]
trailer [37283,37300]
===
match
---
expr_stmt [6779,6856]
expr_stmt [6810,6887]
===
match
---
argument [40596,40608]
argument [40627,40639]
===
match
---
argument [35330,35353]
argument [35361,35384]
===
match
---
simple_stmt [75241,75270]
simple_stmt [76865,76894]
===
match
---
name: next_info [57533,57542]
name: next_info [57564,57573]
===
match
---
name: datetime [65124,65132]
name: datetime [66748,66756]
===
match
---
assert_stmt [8970,9037]
assert_stmt [9001,9068]
===
match
---
simple_stmt [18343,18387]
simple_stmt [18374,18418]
===
match
---
string: "2018-10-27T03:00:00+02:00" [24118,24145]
string: "2018-10-27T03:00:00+02:00" [24149,24176]
===
match
---
atom [21858,21873]
atom [21889,21904]
===
match
---
for_stmt [58351,58611]
for_stmt [58382,58642]
===
match
---
argument [53848,53871]
argument [53879,53902]
===
match
---
operator: = [10290,10291]
operator: = [10321,10322]
===
match
---
trailer [73947,73950]
trailer [75571,75574]
===
match
---
expr_stmt [72064,72085]
expr_stmt [73688,73709]
===
match
---
trailer [17360,17378]
trailer [17391,17409]
===
match
---
comparison [63193,63248]
comparison [63224,63279]
===
match
---
atom [29509,29920]
atom [29540,29951]
===
match
---
param [39647,39651]
param [39678,39682]
===
match
---
operator: = [37010,37011]
operator: = [37041,37042]
===
match
---
argument [23494,23510]
argument [23525,23541]
===
match
---
argument [68943,68960]
argument [70567,70584]
===
match
---
number: 27 [23377,23379]
number: 27 [23408,23410]
===
match
---
comparison [34003,34035]
comparison [34034,34066]
===
match
---
name: utc [23803,23806]
name: utc [23834,23837]
===
match
---
operator: == [49263,49265]
operator: == [49294,49296]
===
match
---
assert_stmt [29502,29976]
assert_stmt [29533,30007]
===
match
---
dotted_name [2342,2367]
dotted_name [2373,2398]
===
match
---
name: schedule_interval [59969,59986]
name: schedule_interval [60000,60017]
===
match
---
trailer [70775,70777]
trailer [72399,72401]
===
match
---
with_stmt [8577,8801]
with_stmt [8608,8832]
===
match
---
name: two_hours_ago [59828,59841]
name: two_hours_ago [59859,59872]
===
match
---
trailer [77224,77232]
trailer [78848,78856]
===
match
---
operator: = [36652,36653]
operator: = [36683,36684]
===
match
---
name: op4 [39613,39616]
name: op4 [39644,39647]
===
match
---
assert_stmt [22643,22698]
assert_stmt [22674,22729]
===
match
---
trailer [77104,77112]
trailer [78728,78736]
===
match
---
comparison [42884,42903]
comparison [42915,42934]
===
match
---
trailer [51119,51171]
trailer [51150,51202]
===
match
---
expr_stmt [15772,15822]
expr_stmt [15803,15853]
===
match
---
trailer [55029,55031]
trailer [55060,55062]
===
match
---
string: 'test-dag2' [29893,29904]
string: 'test-dag2' [29924,29935]
===
match
---
argument [5745,5779]
argument [5776,5810]
===
match
---
trailer [76342,76344]
trailer [77966,77968]
===
match
---
param [63292,63296]
param [64916,64920]
===
match
---
name: dag [53418,53421]
name: dag [53449,53452]
===
match
---
name: op2 [11035,11038]
name: op2 [11066,11069]
===
match
---
trailer [37845,37849]
trailer [37876,37880]
===
match
---
trailer [73150,73157]
trailer [74774,74781]
===
match
---
atom_expr [21835,21855]
atom_expr [21866,21886]
===
match
---
simple_stmt [39403,39437]
simple_stmt [39434,39468]
===
match
---
name: DEFAULT_ARGS [74168,74180]
name: DEFAULT_ARGS [75792,75804]
===
match
---
simple_stmt [45818,45870]
simple_stmt [45849,45901]
===
match
---
decorated [72288,72550]
decorated [73912,74174]
===
match
---
name: weight [16401,16407]
name: weight [16432,16438]
===
match
---
name: DAGsubclass [47762,47773]
name: DAGsubclass [47793,47804]
===
match
---
name: schedule_interval [27514,27531]
name: schedule_interval [27545,27562]
===
match
---
operator: , [17293,17294]
operator: , [17324,17325]
===
match
---
name: prev [23624,23628]
name: prev [23655,23659]
===
match
---
param [56041,56068]
param [56072,56099]
===
match
---
param [27271,27273]
param [27302,27304]
===
match
---
operator: = [42765,42766]
operator: = [42796,42797]
===
match
---
name: self [73984,73988]
name: self [75608,75612]
===
match
---
simple_stmt [24805,24860]
simple_stmt [24836,24891]
===
match
---
name: run_id [70487,70493]
name: run_id [72111,72117]
===
match
---
trailer [28264,28270]
trailer [28295,28301]
===
match
---
suite [15352,15382]
suite [15383,15413]
===
match
---
name: self [34159,34163]
name: self [34190,34194]
===
match
---
name: DAG [58094,58097]
name: DAG [58125,58128]
===
match
---
atom_expr [14781,14813]
atom_expr [14812,14844]
===
match
---
name: create_session [28284,28298]
name: create_session [28315,28329]
===
match
---
name: op2 [38876,38879]
name: op2 [38907,38910]
===
match
---
simple_stmt [39357,39391]
simple_stmt [39388,39422]
===
match
---
name: weight [17017,17023]
name: weight [17048,17054]
===
match
---
trailer [58722,58739]
trailer [58753,58770]
===
match
---
arglist [16523,16531]
arglist [16554,16562]
===
match
---
atom_expr [68950,68960]
atom_expr [70574,70584]
===
match
---
name: DummyOperator [68131,68144]
name: DummyOperator [69755,69768]
===
match
---
operator: = [16102,16103]
operator: = [16133,16134]
===
match
---
atom_expr [56770,56920]
atom_expr [56801,56951]
===
match
---
name: DEFAULT_DATE [50810,50822]
name: DEFAULT_DATE [50841,50853]
===
match
---
atom_expr [66304,66331]
atom_expr [67928,67955]
===
match
---
name: raises [5188,5194]
name: raises [5219,5225]
===
match
---
expr_stmt [44770,44844]
expr_stmt [44801,44875]
===
match
---
name: sync_to_db [32617,32627]
name: sync_to_db [32648,32658]
===
match
---
name: TI [76240,76242]
name: TI [77864,77866]
===
match
---
operator: , [31588,31589]
operator: , [31619,31620]
===
match
---
sync_comp_for [29428,29475]
sync_comp_for [29459,29506]
===
match
---
name: clear_db_dags [28069,28082]
name: clear_db_dags [28100,28113]
===
match
---
operator: = [48200,48201]
operator: = [48231,48232]
===
match
---
atom_expr [73801,73814]
atom_expr [75425,75438]
===
match
---
atom_expr [56396,56419]
atom_expr [56427,56450]
===
match
---
arglist [5237,5263]
arglist [5268,5294]
===
match
---
operator: , [60001,60002]
operator: , [60032,60033]
===
match
---
operator: , [22009,22010]
operator: , [22040,22041]
===
match
---
operator: , [26516,26517]
operator: , [26547,26548]
===
match
---
atom_expr [54063,54120]
atom_expr [54094,54151]
===
match
---
comparison [61748,61803]
comparison [61779,61834]
===
match
---
trailer [11059,11065]
trailer [11090,11096]
===
match
---
operator: = [14273,14274]
operator: = [14304,14305]
===
match
---
argument [56433,56452]
argument [56464,56483]
===
match
---
operator: , [45262,45263]
operator: , [45293,45294]
===
match
---
atom_expr [18298,18308]
atom_expr [18329,18339]
===
match
---
expr_stmt [43616,43668]
expr_stmt [43647,43699]
===
match
---
param [27265,27270]
param [27296,27301]
===
match
---
arglist [75587,75597]
arglist [77211,77221]
===
match
---
suite [2728,2778]
suite [2759,2809]
===
match
---
operator: , [68169,68170]
operator: , [69793,69794]
===
match
---
name: dag [72137,72140]
name: dag [73761,73764]
===
match
---
argument [53557,53583]
argument [53588,53614]
===
match
---
name: task_decorator [1415,1429]
name: task_decorator [1421,1435]
===
match
---
argument [78858,78873]
argument [80482,80497]
===
match
---
trailer [40414,40492]
trailer [40445,40523]
===
match
---
name: state [76890,76895]
name: state [78514,78519]
===
match
---
atom_expr [24447,24480]
atom_expr [24478,24511]
===
match
---
number: 2019 [65747,65751]
number: 2019 [67371,67375]
===
match
---
name: dag [51297,51300]
name: dag [51328,51331]
===
match
---
atom [47813,47861]
atom [47844,47892]
===
match
---
simple_stmt [22864,22925]
simple_stmt [22895,22956]
===
match
---
name: orm_dag [69316,69323]
name: orm_dag [70940,70947]
===
match
---
name: next_dagrun_info [58401,58417]
name: next_dagrun_info [58432,58448]
===
match
---
return_stmt [74306,74316]
return_stmt [75930,75940]
===
match
---
operator: = [38572,38573]
operator: = [38603,38604]
===
match
---
operator: , [18289,18290]
operator: , [18320,18321]
===
match
---
argument [5250,5263]
argument [5281,5294]
===
match
---
name: subdag [34574,34580]
name: subdag [34605,34611]
===
match
---
operator: , [21257,21258]
operator: , [21288,21289]
===
match
---
number: 1 [58689,58690]
number: 1 [58720,58721]
===
match
---
simple_stmt [7401,7424]
simple_stmt [7432,7455]
===
match
---
number: 1 [64079,64080]
number: 1 [65703,65704]
===
match
---
trailer [34777,34787]
trailer [34808,34818]
===
match
---
name: dag [51917,51920]
name: dag [51948,51951]
===
match
---
arith_expr [54600,54641]
arith_expr [54631,54672]
===
match
---
argument [60896,60932]
argument [60927,60963]
===
match
---
atom_expr [27221,27243]
atom_expr [27252,27274]
===
match
---
name: State [76545,76550]
name: State [78169,78174]
===
match
---
name: DagRun [55668,55674]
name: DagRun [55699,55705]
===
match
---
simple_stmt [40333,40388]
simple_stmt [40364,40419]
===
match
---
simple_stmt [44334,44396]
simple_stmt [44365,44427]
===
match
---
trailer [31768,31778]
trailer [31799,31809]
===
match
---
operator: , [71743,71744]
operator: , [73367,73368]
===
match
---
name: dag_decorator [73316,73329]
name: dag_decorator [74940,74953]
===
match
---
name: op1 [40699,40702]
name: op1 [40730,40733]
===
match
---
trailer [18569,18575]
trailer [18600,18606]
===
match
---
name: RUNNING [47096,47103]
name: RUNNING [47127,47134]
===
match
---
name: op1 [42049,42052]
name: op1 [42080,42083]
===
match
---
argument [17872,17882]
argument [17903,17913]
===
match
---
expr_stmt [10911,10928]
expr_stmt [10942,10959]
===
match
---
simple_stmt [22083,22155]
simple_stmt [22114,22186]
===
match
---
argument [8626,8644]
argument [8657,8675]
===
match
---
name: State [18493,18498]
name: State [18524,18529]
===
match
---
operator: , [59730,59731]
operator: , [59761,59762]
===
match
---
trailer [18437,18472]
trailer [18468,18503]
===
match
---
operator: = [37603,37604]
operator: = [37634,37635]
===
match
---
name: dag_id [56177,56183]
name: dag_id [56208,56214]
===
match
---
expr_stmt [22819,22854]
expr_stmt [22850,22885]
===
match
---
operator: = [60534,60535]
operator: = [60565,60566]
===
match
---
operator: = [34924,34925]
operator: = [34955,34956]
===
match
---
name: group [14285,14290]
name: group [14316,14321]
===
match
---
name: subdag [55266,55272]
name: subdag [55297,55303]
===
match
---
name: sub_dag [42194,42201]
name: sub_dag [42225,42232]
===
match
---
number: 2018 [26104,26108]
number: 2018 [26135,26139]
===
match
---
name: State [76488,76493]
name: State [78112,78117]
===
match
---
atom_expr [54425,54443]
atom_expr [54456,54474]
===
match
---
name: test_dag_id [48000,48011]
name: test_dag_id [48031,48042]
===
match
---
atom_expr [39455,39482]
atom_expr [39486,39513]
===
match
---
simple_stmt [34333,34400]
simple_stmt [34364,34431]
===
match
---
atom_expr [4201,4211]
atom_expr [4232,4242]
===
match
---
expr_stmt [46678,46712]
expr_stmt [46709,46743]
===
match
---
operator: = [39785,39786]
operator: = [39816,39817]
===
match
---
atom_expr [18546,18556]
atom_expr [18577,18587]
===
match
---
trailer [49645,49655]
trailer [49676,49686]
===
match
---
simple_stmt [11832,12360]
simple_stmt [11863,12391]
===
match
---
comparison [20452,20497]
comparison [20483,20528]
===
match
---
atom_expr [22291,22314]
atom_expr [22322,22345]
===
match
---
string: 'owner1' [17318,17326]
string: 'owner1' [17349,17357]
===
match
---
import_name [1101,1114]
import_name [1107,1120]
===
match
---
name: DagTag [28751,28757]
name: DagTag [28782,28788]
===
match
---
trailer [64906,64909]
trailer [66530,66533]
===
match
---
operator: == [41661,41663]
operator: == [41692,41694]
===
match
---
dictorsetmaker [39613,39621]
dictorsetmaker [39644,39652]
===
match
---
name: DAG [61451,61454]
name: DAG [61482,61485]
===
match
---
with_item [29275,29302]
with_item [29306,29333]
===
match
---
simple_stmt [30750,30776]
simple_stmt [30781,30807]
===
match
---
atom_expr [72070,72085]
atom_expr [73694,73709]
===
match
---
string: 't2' [40181,40185]
string: 't2' [40212,40216]
===
match
---
atom_expr [27833,27849]
atom_expr [27864,27880]
===
match
---
operator: , [67208,67209]
operator: , [68832,68833]
===
match
---
name: _clean_up [53023,53032]
name: _clean_up [53054,53063]
===
match
---
atom_expr [49212,49221]
atom_expr [49243,49252]
===
match
---
name: dag [7993,7996]
name: dag [8024,8027]
===
match
---
parameters [4929,4935]
parameters [4960,4966]
===
match
---
operator: , [28665,28666]
operator: , [28696,28697]
===
match
---
name: session [69500,69507]
name: session [71124,71131]
===
match
---
simple_stmt [33996,34036]
simple_stmt [34027,34067]
===
match
---
param [38682,38686]
param [38713,38717]
===
match
---
trailer [68040,68122]
trailer [69664,69746]
===
match
---
atom_expr [59495,59531]
atom_expr [59526,59562]
===
match
---
name: airflow [2240,2247]
name: airflow [2271,2278]
===
match
---
operator: = [77430,77431]
operator: = [79054,79055]
===
match
---
operator: = [23393,23394]
operator: = [23424,23425]
===
match
---
number: 3 [26110,26111]
number: 3 [26141,26142]
===
match
---
trailer [30305,30308]
trailer [30336,30339]
===
match
---
name: xcom_arg [74378,74386]
name: xcom_arg [76002,76010]
===
match
---
name: isoformat [22882,22891]
name: isoformat [22913,22922]
===
match
---
operator: { [13160,13161]
operator: { [13191,13192]
===
match
---
operator: = [65269,65270]
operator: = [66893,66894]
===
match
---
name: dag_id [37838,37844]
name: dag_id [37869,37875]
===
match
---
name: security [1904,1912]
name: security [1910,1918]
===
match
---
simple_stmt [40174,40205]
simple_stmt [40205,40236]
===
match
---
name: TEST_DATE [2616,2625]
name: TEST_DATE [2647,2656]
===
match
---
name: self [38309,38313]
name: self [38340,38344]
===
match
---
assert_stmt [8893,8961]
assert_stmt [8924,8992]
===
match
---
atom_expr [38836,38863]
atom_expr [38867,38894]
===
match
---
name: RUNNING [74697,74704]
name: RUNNING [76321,76328]
===
match
---
name: session [53489,53496]
name: session [53520,53527]
===
match
---
operator: = [75785,75786]
operator: = [77409,77410]
===
match
---
operator: , [1477,1478]
operator: , [1483,1484]
===
match
---
simple_stmt [44405,44417]
simple_stmt [44436,44448]
===
match
---
operator: = [75126,75127]
operator: = [76750,76751]
===
match
---
suite [9506,9762]
suite [9537,9793]
===
match
---
atom_expr [76457,76485]
atom_expr [78081,78109]
===
match
---
atom_expr [42844,42857]
atom_expr [42875,42888]
===
match
---
name: seconds [27076,27083]
name: seconds [27107,27114]
===
match
---
name: type [5151,5155]
name: type [5182,5186]
===
match
---
operator: , [58234,58235]
operator: , [58265,58266]
===
match
---
argument [51900,51915]
argument [51931,51946]
===
match
---
operator: = [40630,40631]
operator: = [40661,40662]
===
match
---
arglist [41033,41068]
arglist [41064,41099]
===
match
---
name: query [34772,34777]
name: query [34803,34808]
===
match
---
name: models [5734,5740]
name: models [5765,5771]
===
match
---
name: timezone [13201,13209]
name: timezone [13232,13240]
===
match
---
operator: , [32077,32078]
operator: , [32108,32109]
===
match
---
trailer [50982,50996]
trailer [51013,51027]
===
match
---
trailer [34737,34747]
trailer [34768,34778]
===
match
---
name: task_id [7905,7912]
name: task_id [7936,7943]
===
match
---
trailer [36214,36216]
trailer [36245,36247]
===
match
---
assert_stmt [49284,49323]
assert_stmt [49315,49354]
===
match
---
argument [46151,46175]
argument [46182,46206]
===
match
---
simple_stmt [22324,22419]
simple_stmt [22355,22450]
===
match
---
argument [10623,10634]
argument [10654,10665]
===
match
---
name: task_1 [76867,76873]
name: task_1 [78491,78497]
===
match
---
name: pipeline [13708,13716]
name: pipeline [13739,13747]
===
match
---
comparison [11166,11193]
comparison [11197,11224]
===
match
---
operator: { [65379,65380]
operator: { [67003,67004]
===
match
---
param [3173,3184]
param [3204,3215]
===
match
---
simple_stmt [52332,52349]
simple_stmt [52363,52380]
===
match
---
name: dag [7266,7269]
name: dag [7297,7300]
===
match
---
expr_stmt [73919,73950]
expr_stmt [75543,75574]
===
match
---
string: "t1" [41507,41511]
string: "t1" [41538,41542]
===
match
---
string: "retries" [70787,70796]
string: "retries" [72411,72420]
===
match
---
operator: = [40959,40960]
operator: = [40990,40991]
===
match
---
atom_expr [13136,13181]
atom_expr [13167,13212]
===
match
---
operator: , [33575,33576]
operator: , [33606,33607]
===
match
---
name: State [45076,45081]
name: State [45107,45112]
===
match
---
name: AirflowException [5420,5436]
name: AirflowException [5451,5467]
===
match
---
name: create_dagrun [50983,50996]
name: create_dagrun [51014,51027]
===
match
---
name: State [52066,52071]
name: State [52097,52102]
===
match
---
atom [75962,75994]
atom [77586,77618]
===
match
---
with_stmt [44028,44325]
with_stmt [44059,44356]
===
match
---
trailer [39033,39047]
trailer [39064,39078]
===
match
---
assert_stmt [11288,11321]
assert_stmt [11319,11352]
===
match
---
name: next_date [60653,60662]
name: next_date [60684,60693]
===
match
---
parameters [17492,17498]
parameters [17523,17529]
===
match
---
simple_stmt [12508,12578]
simple_stmt [12539,12609]
===
match
---
arglist [63944,63960]
arglist [65568,65584]
===
match
---
name: PRE_TRANSITION [24500,24514]
name: PRE_TRANSITION [24531,24545]
===
match
---
trailer [72051,72054]
trailer [73675,73678]
===
match
---
string: "2018-10-28T03:00:00+01:00" [23895,23922]
string: "2018-10-28T03:00:00+01:00" [23926,23953]
===
match
---
atom_expr [11488,11510]
atom_expr [11519,11541]
===
match
---
operator: , [60382,60383]
operator: , [60413,60414]
===
match
---
trailer [68487,68493]
trailer [70111,70117]
===
match
---
argument [76033,76051]
argument [77657,77675]
===
match
---
name: owner [44901,44906]
name: owner [44932,44937]
===
match
---
argument [3498,3523]
argument [3529,3554]
===
match
---
expr_stmt [53398,53421]
expr_stmt [53429,53452]
===
match
---
name: default_args [10278,10290]
name: default_args [10309,10321]
===
match
---
string: "test_get_paused_dag_ids" [49428,49453]
string: "test_get_paused_dag_ids" [49459,49484]
===
match
---
name: dag_id [6339,6345]
name: dag_id [6370,6376]
===
match
---
number: 4 [11312,11313]
number: 4 [11343,11344]
===
match
---
operator: = [39276,39277]
operator: = [39307,39308]
===
match
---
operator: = [76437,76438]
operator: = [78061,78062]
===
match
---
arglist [18162,18246]
arglist [18193,18277]
===
match
---
name: default_args [59338,59350]
name: default_args [59369,59381]
===
match
---
name: test_sync_to_db_default_view [33362,33390]
name: test_sync_to_db_default_view [33393,33421]
===
match
---
operator: , [52967,52968]
operator: , [52998,52999]
===
match
---
trailer [8995,9037]
trailer [9026,9068]
===
match
---
name: flush [21503,21508]
name: flush [21534,21539]
===
match
---
operator: , [53225,53226]
operator: , [53256,53257]
===
match
---
name: len [4197,4200]
name: len [4228,4231]
===
match
---
simple_stmt [60318,60512]
simple_stmt [60349,60543]
===
match
---
operator: , [12882,12883]
operator: , [12913,12914]
===
match
---
atom [39541,39551]
atom [39572,39582]
===
match
---
name: start_date [78718,78728]
name: start_date [80342,80352]
===
match
---
expr_stmt [33406,33516]
expr_stmt [33437,33547]
===
match
---
operator: = [52225,52226]
operator: = [52256,52257]
===
match
---
name: session [76144,76151]
name: session [77768,77775]
===
match
---
expr_stmt [24571,24639]
expr_stmt [24602,24670]
===
match
---
decorated [72447,72523]
decorated [74071,74147]
===
match
---
name: next_dagrun_info [60541,60557]
name: next_dagrun_info [60572,60588]
===
match
---
string: 'DAG' [12877,12882]
string: 'DAG' [12908,12913]
===
match
---
operator: , [41426,41427]
operator: , [41457,41458]
===
match
---
atom_expr [28448,28484]
atom_expr [28479,28515]
===
match
---
argument [58098,58111]
argument [58129,58142]
===
match
---
simple_stmt [19949,19984]
simple_stmt [19980,20015]
===
match
---
simple_stmt [37778,37852]
simple_stmt [37809,37883]
===
match
---
assert_stmt [4185,4212]
assert_stmt [4216,4243]
===
match
---
string: "2018-03-25T03:00:00+02:00" [24992,25019]
string: "2018-03-25T03:00:00+02:00" [25023,25050]
===
match
---
atom_expr [10023,10056]
atom_expr [10054,10087]
===
match
---
name: task [14232,14236]
name: task [14263,14267]
===
match
---
name: prev [25167,25171]
name: prev [25198,25202]
===
match
---
name: tasks [9861,9866]
name: tasks [9892,9897]
===
match
---
name: _make_test_subdag [55280,55297]
name: _make_test_subdag [55311,55328]
===
match
---
atom_expr [20312,20334]
atom_expr [20343,20365]
===
match
---
name: op1 [41237,41240]
name: op1 [41268,41271]
===
match
---
trailer [57556,57569]
trailer [57587,57600]
===
match
---
operator: , [66302,66303]
operator: , [67926,67927]
===
match
---
name: redirect_stdout [39955,39970]
name: redirect_stdout [39986,40001]
===
match
---
operator: , [27269,27270]
operator: , [27300,27301]
===
match
---
expr_stmt [25470,25512]
expr_stmt [25501,25543]
===
match
---
trailer [34771,34777]
trailer [34802,34808]
===
match
---
name: hours [59869,59874]
name: hours [59900,59905]
===
match
---
name: sync_to_db [34906,34916]
name: sync_to_db [34937,34947]
===
match
---
operator: = [16139,16140]
operator: = [16170,16171]
===
match
---
operator: = [56901,56902]
operator: = [56932,56933]
===
match
---
name: close [38239,38244]
name: close [38270,38275]
===
match
---
expr_stmt [17040,17086]
expr_stmt [17071,17117]
===
match
---
atom_expr [29942,29955]
atom_expr [29973,29986]
===
match
---
name: datetime [77792,77800]
name: datetime [79416,79424]
===
match
---
operator: , [59235,59236]
operator: , [59266,59267]
===
match
---
arglist [19099,19158]
arglist [19130,19189]
===
match
---
for_stmt [28799,28900]
for_stmt [28830,28931]
===
match
---
name: DEFAULT_DATE [79012,79024]
name: DEFAULT_DATE [80636,80648]
===
match
---
argument [7815,7828]
argument [7846,7859]
===
match
---
trailer [59670,59680]
trailer [59701,59711]
===
match
---
atom_expr [54899,54912]
atom_expr [54930,54943]
===
match
---
operator: @ [74241,74242]
operator: @ [75865,75866]
===
match
---
operator: , [71256,71257]
operator: , [72880,72881]
===
match
---
trailer [21608,21613]
trailer [21639,21644]
===
match
---
comparison [50786,50836]
comparison [50817,50867]
===
match
---
operator: , [29891,29892]
operator: , [29922,29923]
===
match
---
arglist [63780,63821]
arglist [65404,65445]
===
match
---
and_test [57533,57602]
and_test [57564,57633]
===
match
---
argument [52381,52404]
argument [52412,52435]
===
match
---
name: isoformat [22725,22734]
name: isoformat [22756,22765]
===
match
---
operator: , [1540,1541]
operator: , [1546,1547]
===
match
---
name: dag_id [56128,56134]
name: dag_id [56159,56165]
===
match
---
dictorsetmaker [29527,29906]
dictorsetmaker [29558,29937]
===
match
---
operator: , [2527,2528]
operator: , [2558,2559]
===
match
---
operator: = [62521,62522]
operator: = [62552,62553]
===
match
---
operator: = [46891,46892]
operator: = [46922,46923]
===
match
---
string: 'dag' [10246,10251]
string: 'dag' [10277,10282]
===
match
---
name: loads [48825,48830]
name: loads [48856,48861]
===
match
---
name: self [55194,55198]
name: self [55225,55229]
===
match
---
name: session [33034,33041]
name: session [33065,33072]
===
match
---
arglist [19779,19930]
arglist [19810,19961]
===
match
---
atom_expr [23030,23052]
atom_expr [23061,23083]
===
match
---
arglist [25571,25609]
arglist [25602,25640]
===
match
---
name: dag_id [49572,49578]
name: dag_id [49603,49609]
===
match
---
operator: , [53802,53803]
operator: , [53833,53834]
===
match
---
name: template_file [21793,21806]
name: template_file [21824,21837]
===
match
---
comparison [23099,23110]
comparison [23130,23141]
===
match
---
operator: = [67703,67704]
operator: = [69327,69328]
===
match
---
name: dag [48439,48442]
name: dag [48470,48473]
===
match
---
param [65979,65983]
param [67603,67607]
===
match
---
name: width [14424,14429]
name: width [14455,14460]
===
match
---
operator: = [44786,44787]
operator: = [44817,44818]
===
match
---
name: task_instance [57221,57234]
name: task_instance [57252,57265]
===
match
---
operator: = [31570,31571]
operator: = [31601,31602]
===
match
---
name: start_date [46001,46011]
name: start_date [46032,46042]
===
match
---
trailer [67817,67823]
trailer [69441,69447]
===
match
---
funcdef [62107,63249]
funcdef [62138,63280]
===
match
---
atom_expr [18664,18682]
atom_expr [18695,18713]
===
match
---
simple_stmt [5125,5167]
simple_stmt [5156,5198]
===
match
---
trailer [30648,30653]
trailer [30679,30684]
===
match
---
name: session [67961,67968]
name: session [69585,69592]
===
match
---
argument [5556,5578]
argument [5587,5609]
===
match
---
with_stmt [6000,6176]
with_stmt [6031,6207]
===
match
---
name: DAG [24577,24580]
name: DAG [24608,24611]
===
match
---
trailer [38065,38092]
trailer [38096,38123]
===
match
---
name: task_id [59509,59516]
name: task_id [59540,59547]
===
match
---
trailer [3348,3354]
trailer [3379,3385]
===
match
---
operator: == [4781,4783]
operator: == [4812,4814]
===
match
---
trailer [73768,73781]
trailer [75392,75405]
===
match
---
operator: = [44131,44132]
operator: = [44162,44163]
===
match
---
arglist [74553,74744]
arglist [76177,76368]
===
match
---
name: start_date [17270,17280]
name: start_date [17301,17311]
===
match
---
argument [51120,51152]
argument [51151,51183]
===
match
---
name: parent_dag_name [64593,64608]
name: parent_dag_name [66217,66232]
===
match
---
trailer [27423,27432]
trailer [27454,27463]
===
match
---
simple_stmt [3782,3794]
simple_stmt [3813,3825]
===
match
---
name: match [15674,15679]
name: match [15705,15710]
===
match
---
operator: , [36024,36025]
operator: , [36055,36056]
===
match
---
argument [66529,66564]
argument [68153,68188]
===
match
---
trailer [21429,21449]
trailer [21460,21480]
===
match
---
name: QUEUED [18499,18505]
name: QUEUED [18530,18536]
===
match
---
atom_expr [46727,46772]
atom_expr [46758,46803]
===
match
---
name: dag [72666,72669]
name: dag [74290,74293]
===
match
---
name: dag [1671,1674]
name: dag [1677,1680]
===
match
---
argument [6970,6978]
argument [7001,7009]
===
match
---
trailer [3276,3283]
trailer [3307,3314]
===
match
---
name: SUCCESS [46189,46196]
name: SUCCESS [46220,46227]
===
match
---
for_stmt [15398,15540]
for_stmt [15429,15571]
===
match
---
trailer [45236,45246]
trailer [45267,45277]
===
match
---
name: mock_callback_with_exception [43560,43588]
name: mock_callback_with_exception [43591,43619]
===
match
---
argument [39266,39289]
argument [39297,39320]
===
match
---
operator: , [59521,59522]
operator: , [59552,59553]
===
match
---
name: updated_permissions [66603,66622]
name: updated_permissions [68227,68246]
===
match
---
operator: = [53328,53329]
operator: = [53359,53360]
===
match
---
atom [15789,15813]
atom [15820,15844]
===
match
---
operator: + [77790,77791]
operator: + [79414,79415]
===
match
---
simple_stmt [32049,32126]
simple_stmt [32080,32157]
===
match
---
string: "t3" [39901,39905]
string: "t3" [39932,39936]
===
match
---
atom_expr [68808,68864]
atom_expr [70432,70488]
===
match
---
operator: , [33167,33168]
operator: , [33198,33199]
===
match
---
trailer [46793,46870]
trailer [46824,46901]
===
match
---
fstring_start: f' [28105,28107]
fstring_start: f' [28136,28138]
===
match
---
atom_expr [61944,61967]
atom_expr [61975,61998]
===
match
---
name: start_date [52092,52102]
name: start_date [52123,52133]
===
match
---
name: execution_date [18045,18059]
name: execution_date [18076,18090]
===
match
---
name: isoformat [24166,24175]
name: isoformat [24197,24206]
===
match
---
operator: == [23053,23055]
operator: == [23084,23086]
===
match
---
atom_expr [44132,44149]
atom_expr [44163,44180]
===
match
---
operator: == [31831,31833]
operator: == [31862,31864]
===
match
---
trailer [19075,19098]
trailer [19106,19129]
===
match
---
operator: = [7578,7579]
operator: = [7609,7610]
===
match
---
simple_stmt [18429,18473]
simple_stmt [18460,18504]
===
match
---
trailer [33948,33955]
trailer [33979,33986]
===
match
---
simple_stmt [33113,33179]
simple_stmt [33144,33210]
===
match
---
operator: , [64348,64349]
operator: , [65972,65973]
===
match
---
arglist [18994,19050]
arglist [19025,19081]
===
match
---
string: 'airflow' [5569,5578]
string: 'airflow' [5600,5609]
===
match
---
name: mark [77636,77640]
name: mark [79260,79264]
===
match
---
string: "4 5 * * *" [63735,63746]
string: "4 5 * * *" [65359,65370]
===
match
---
name: is_paused [35823,35832]
name: is_paused [35854,35863]
===
match
---
name: dag [34432,34435]
name: dag [34463,34466]
===
match
---
arglist [64740,64864]
arglist [66364,66488]
===
match
---
name: dag_id [45835,45841]
name: dag_id [45866,45872]
===
match
---
trailer [21545,21553]
trailer [21576,21584]
===
match
---
assert_stmt [60228,60263]
assert_stmt [60259,60294]
===
match
---
simple_stmt [10236,10312]
simple_stmt [10267,10343]
===
match
---
comparison [22871,22924]
comparison [22902,22955]
===
match
---
atom_expr [66951,67046]
atom_expr [68575,68670]
===
match
---
name: next_info [61911,61920]
name: next_info [61942,61951]
===
match
---
name: op2 [41594,41597]
name: op2 [41625,41628]
===
match
---
arglist [44780,44843]
arglist [44811,44874]
===
match
---
simple_stmt [27692,27708]
simple_stmt [27723,27739]
===
match
---
return_stmt [19717,19739]
return_stmt [19748,19770]
===
match
---
argument [63994,64030]
argument [65618,65654]
===
match
---
name: execution_date [54071,54085]
name: execution_date [54102,54116]
===
match
---
name: op3 [9722,9725]
name: op3 [9753,9756]
===
match
---
simple_stmt [40850,40905]
simple_stmt [40881,40936]
===
match
---
atom_expr [38524,38541]
atom_expr [38555,38572]
===
match
---
arglist [65133,65143]
arglist [66757,66767]
===
match
---
argument [51828,51851]
argument [51859,51882]
===
match
---
assert_stmt [69440,69463]
assert_stmt [71064,71087]
===
match
---
trailer [29446,29452]
trailer [29477,29483]
===
match
---
atom_expr [38161,38221]
atom_expr [38192,38252]
===
match
---
operator: , [17711,17712]
operator: , [17742,17743]
===
match
---
trailer [46784,46793]
trailer [46815,46824]
===
match
---
operator: + [69097,69098]
operator: + [70721,70722]
===
match
---
comparison [10158,10184]
comparison [10189,10215]
===
match
---
name: dag [53378,53381]
name: dag [53409,53412]
===
match
---
name: start_date [41045,41055]
name: start_date [41076,41086]
===
match
---
atom_expr [54826,54949]
atom_expr [54857,54980]
===
match
---
param [26383,26387]
param [26414,26418]
===
match
---
operator: = [13639,13640]
operator: = [13670,13671]
===
match
---
operator: , [1530,1531]
operator: , [1536,1537]
===
match
---
trailer [49521,49532]
trailer [49552,49563]
===
match
---
atom [14394,14434]
atom [14425,14465]
===
match
---
name: DEFAULT_DATE [52144,52156]
name: DEFAULT_DATE [52175,52187]
===
match
---
name: DummyOperator [8283,8296]
name: DummyOperator [8314,8327]
===
match
---
name: job_id [56684,56690]
name: job_id [56715,56721]
===
match
---
trailer [73839,73848]
trailer [75463,75472]
===
match
---
operator: , [26592,26593]
operator: , [26623,26624]
===
match
---
arglist [59176,59351]
arglist [59207,59382]
===
match
---
sync_comp_for [16567,16591]
sync_comp_for [16598,16622]
===
match
---
suite [16753,16869]
suite [16784,16900]
===
match
---
atom_expr [44102,44115]
atom_expr [44133,44146]
===
match
---
atom [51609,51625]
atom [51640,51656]
===
match
---
string: 'dag' [16160,16165]
string: 'dag' [16191,16196]
===
match
---
suite [26913,27398]
suite [26944,27429]
===
match
---
simple_stmt [58531,58566]
simple_stmt [58562,58597]
===
match
---
name: subdag [32553,32559]
name: subdag [32584,32590]
===
match
---
arglist [68755,68798]
arglist [70379,70422]
===
match
---
trailer [18877,18900]
trailer [18908,18931]
===
match
---
comparison [22331,22379]
comparison [22362,22410]
===
match
---
name: AirflowException [6019,6035]
name: AirflowException [6050,6066]
===
match
---
operator: } [28497,28498]
operator: } [28528,28529]
===
match
---
name: task_id [53362,53369]
name: task_id [53393,53400]
===
match
---
trailer [6954,6979]
trailer [6985,7010]
===
match
---
name: DAG [19072,19075]
name: DAG [19103,19106]
===
match
---
operator: @ [72853,72854]
operator: @ [74477,74478]
===
match
---
operator: = [57921,57922]
operator: = [57952,57953]
===
match
---
trailer [17844,17858]
trailer [17875,17889]
===
match
---
trailer [3490,3497]
trailer [3521,3528]
===
match
---
with_stmt [29270,29977]
with_stmt [29301,30008]
===
match
---
atom_expr [41143,41179]
atom_expr [41174,41210]
===
match
---
name: _next [25122,25127]
name: _next [25153,25158]
===
match
---
arglist [20993,21062]
arglist [21024,21093]
===
match
---
name: now [59656,59659]
name: now [59687,59690]
===
match
---
name: parameterized [1233,1246]
name: parameterized [1239,1252]
===
match
---
parameters [37379,37385]
parameters [37410,37416]
===
match
---
name: state [77233,77238]
name: state [78857,78862]
===
match
---
number: 4 [29219,29220]
number: 4 [29250,29251]
===
match
---
trailer [25863,25870]
trailer [25894,25901]
===
match
---
name: params [5257,5263]
name: params [5288,5294]
===
match
---
comparison [69882,69923]
comparison [71506,71547]
===
match
---
operator: = [41483,41484]
operator: = [41514,41515]
===
match
---
name: operators [1754,1763]
name: operators [1760,1769]
===
match
---
atom_expr [68480,68495]
atom_expr [70104,70119]
===
match
---
atom_expr [18520,18557]
atom_expr [18551,18588]
===
match
---
name: timezone [24531,24539]
name: timezone [24562,24570]
===
match
---
operator: = [8443,8444]
operator: = [8474,8475]
===
match
---
trailer [39600,39607]
trailer [39631,39638]
===
match
---
number: 1 [12805,12806]
number: 1 [12836,12837]
===
match
---
simple_stmt [47611,47657]
simple_stmt [47642,47688]
===
match
---
name: ti1 [18266,18269]
name: ti1 [18297,18300]
===
match
---
name: orm_dag [36839,36846]
name: orm_dag [36870,36877]
===
match
---
operator: = [39854,39855]
operator: = [39885,39886]
===
match
---
operator: = [41438,41439]
operator: = [41469,41470]
===
match
---
name: session [33837,33844]
name: session [33868,33875]
===
match
---
operator: = [50758,50759]
operator: = [50789,50790]
===
match
---
atom [19233,19247]
atom [19264,19278]
===
match
---
number: 1 [51869,51870]
number: 1 [51900,51901]
===
match
---
operator: , [12800,12801]
operator: , [12831,12832]
===
match
---
string: 'dag' [33429,33434]
string: 'dag' [33460,33465]
===
match
---
name: default_view [5853,5865]
name: default_view [5884,5896]
===
match
---
name: join [69620,69624]
name: join [71244,71248]
===
match
---
name: schedule_interval [62489,62506]
name: schedule_interval [62520,62537]
===
match
---
trailer [50764,50769]
trailer [50795,50800]
===
match
---
atom_expr [52655,52802]
atom_expr [52686,52833]
===
match
---
atom_expr [15670,15689]
atom_expr [15701,15720]
===
match
---
testlist_star_expr [60098,60110]
testlist_star_expr [60129,60141]
===
match
---
name: session [36654,36661]
name: session [36685,36692]
===
match
---
argument [71119,71149]
argument [72743,72773]
===
match
---
name: start_date [46880,46890]
name: start_date [46911,46921]
===
match
---
atom_expr [7506,7515]
atom_expr [7537,7546]
===
match
---
suite [7756,7877]
suite [7787,7908]
===
match
---
argument [46001,46021]
argument [46032,46052]
===
match
---
simple_stmt [54803,54960]
simple_stmt [54834,54991]
===
match
---
operator: = [27083,27084]
operator: = [27114,27115]
===
match
---
atom_expr [66166,66208]
atom_expr [67790,67832]
===
match
---
name: all [35549,35552]
name: all [35580,35583]
===
match
---
simple_stmt [61727,61804]
simple_stmt [61758,61835]
===
match
---
operator: = [44830,44831]
operator: = [44861,44862]
===
match
---
trailer [77232,77238]
trailer [78856,78862]
===
match
---
suite [30103,30143]
suite [30134,30174]
===
match
---
name: execution_date [76704,76718]
name: execution_date [78328,78342]
===
match
---
operator: = [76850,76851]
operator: = [78474,78475]
===
match
---
atom [77842,78614]
atom [79466,80238]
===
match
---
parameters [49403,49409]
parameters [49434,49440]
===
match
---
name: isoformat [26688,26697]
name: isoformat [26719,26728]
===
match
---
trailer [69619,69624]
trailer [71243,71248]
===
match
---
fstring_string: . [13770,13771]
fstring_string: . [13801,13802]
===
match
---
argument [46120,46149]
argument [46151,46180]
===
match
---
simple_stmt [9564,9597]
simple_stmt [9595,9628]
===
match
---
operator: , [23510,23511]
operator: , [23541,23542]
===
match
---
atom [21792,21822]
atom [21823,21853]
===
match
---
shift_expr [42072,42082]
shift_expr [42103,42113]
===
match
---
name: os [836,838]
name: os [836,838]
===
match
---
string: 'test-dag' [28605,28615]
string: 'test-dag' [28636,28646]
===
match
---
name: owner [67434,67439]
name: owner [69058,69063]
===
match
---
name: dag [46721,46724]
name: dag [46752,46755]
===
match
---
argument [16167,16190]
argument [16198,16221]
===
match
---
operator: , [19110,19111]
operator: , [19141,19142]
===
match
---
argument [59509,59521]
argument [59540,59552]
===
match
---
funcdef [51225,51532]
funcdef [51256,51563]
===
match
---
name: query [30621,30626]
name: query [30652,30657]
===
match
---
expr_stmt [39449,39482]
expr_stmt [39480,39513]
===
match
---
string: 'airflow' [63812,63821]
string: 'airflow' [65436,65445]
===
match
---
arglist [31270,31284]
arglist [31301,31315]
===
match
---
name: template_file [21574,21587]
name: template_file [21605,21618]
===
match
---
operator: , [70598,70599]
operator: , [72222,72223]
===
match
---
param [37380,37384]
param [37411,37415]
===
match
---
string: 'value' [75375,75382]
string: 'value' [76999,77006]
===
match
---
atom_expr [78948,78977]
atom_expr [80572,80601]
===
match
---
argument [17433,17454]
argument [17464,17485]
===
match
---
name: _next [25718,25723]
name: _next [25749,25754]
===
match
---
name: subdag [65793,65799]
name: subdag [67417,67423]
===
match
---
string: 'test-dag' [21637,21647]
string: 'test-dag' [21668,21678]
===
match
---
argument [69821,69834]
argument [71445,71458]
===
match
---
operator: } [13685,13686]
operator: } [13716,13717]
===
match
---
testlist_comp [31332,31343]
testlist_comp [31363,31374]
===
match
---
operator: , [62475,62476]
operator: , [62506,62507]
===
match
---
simple_stmt [4945,5117]
simple_stmt [4976,5148]
===
match
---
operator: = [54464,54465]
operator: = [54495,54496]
===
match
---
name: dag [57339,57342]
name: dag [57370,57373]
===
match
---
operator: = [69113,69114]
operator: = [70737,70738]
===
match
---
simple_stmt [16133,16143]
simple_stmt [16164,16174]
===
match
---
string: '@hourly' [60414,60423]
string: '@hourly' [60445,60454]
===
match
---
atom_expr [25035,25052]
atom_expr [25066,25083]
===
match
---
decorated [71104,71196]
decorated [72728,72820]
===
match
---
name: dag_maker [75442,75451]
name: dag_maker [77066,77075]
===
match
---
simple_stmt [879,918]
simple_stmt [879,918]
===
match
---
operator: , [78614,78615]
operator: , [80238,80239]
===
match
---
string: 'Invalid values of dag.orientation: only support' [6043,6092]
string: 'Invalid values of dag.orientation: only support' [6074,6123]
===
match
---
string: 'tz_dag' [26566,26574]
string: 'tz_dag' [26597,26605]
===
match
---
name: DEFAULT_DATE [54600,54612]
name: DEFAULT_DATE [54631,54643]
===
match
---
trailer [29255,29261]
trailer [29286,29292]
===
match
---
name: dag [42102,42105]
name: dag [42133,42136]
===
match
---
name: test_dag_naive_start_end_dates_strings [11631,11669]
name: test_dag_naive_start_end_dates_strings [11662,11700]
===
match
---
operator: = [66489,66490]
operator: = [68113,68114]
===
match
---
argument [26196,26223]
argument [26227,26254]
===
match
---
suite [51268,51532]
suite [51299,51563]
===
match
---
assert_stmt [46466,46511]
assert_stmt [46497,46542]
===
match
---
name: op2 [42072,42075]
name: op2 [42103,42106]
===
match
---
string: "test_dagrun_missing_param" [67102,67129]
string: "test_dagrun_missing_param" [68726,68753]
===
match
---
fstring_string: stage [13762,13767]
fstring_string: stage [13793,13798]
===
match
---
name: DAG [47930,47933]
name: DAG [47961,47964]
===
match
---
operator: = [74851,74852]
operator: = [76475,76476]
===
match
---
atom [28536,28567]
atom [28567,28598]
===
match
---
param [20179,20183]
param [20210,20214]
===
match
---
argument [12398,12489]
argument [12429,12520]
===
match
---
operator: , [18537,18538]
operator: , [18568,18569]
===
match
---
param [5904,5908]
param [5935,5939]
===
match
---
simple_stmt [35266,35355]
simple_stmt [35297,35386]
===
match
---
comparison [57127,57151]
comparison [57158,57182]
===
match
---
argument [59454,59466]
argument [59485,59497]
===
match
---
name: create_dagrun [44959,44972]
name: create_dagrun [44990,45003]
===
match
---
operator: , [15030,15031]
operator: , [15061,15062]
===
match
---
operator: = [9342,9343]
operator: = [9373,9374]
===
match
---
name: dag [26556,26559]
name: dag [26587,26590]
===
match
---
atom_expr [20552,20604]
atom_expr [20583,20635]
===
match
---
name: _occur_before [8982,8995]
name: _occur_before [9013,9026]
===
match
---
name: next_dagrun_info [62872,62888]
name: next_dagrun_info [62903,62919]
===
match
---
atom_expr [3341,3420]
atom_expr [3372,3451]
===
match
---
fstring_string: stage [15017,15022]
fstring_string: stage [15048,15053]
===
match
---
trailer [41930,41944]
trailer [41961,41975]
===
match
---
name: expected_relative [69783,69800]
name: expected_relative [71407,71424]
===
match
---
argument [7377,7390]
argument [7408,7421]
===
match
---
trailer [19467,19490]
trailer [19498,19521]
===
match
---
simple_stmt [58188,58256]
simple_stmt [58219,58287]
===
match
---
argument [47084,47103]
argument [47115,47134]
===
match
---
atom_expr [39020,39047]
atom_expr [39051,39078]
===
match
---
name: dag [7963,7966]
name: dag [7994,7997]
===
match
---
fstring_string: stage [16346,16351]
fstring_string: stage [16377,16382]
===
match
---
atom_expr [46294,46310]
atom_expr [46325,46341]
===
match
---
string: """         Assert that a occurs before b in the list.         """ [3588,3654]
string: """         Assert that a occurs before b in the list.         """ [3619,3685]
===
match
---
trailer [15515,15528]
trailer [15546,15559]
===
match
---
operator: , [34572,34573]
operator: , [34603,34604]
===
match
---
argument [69130,69144]
argument [70754,70768]
===
match
---
name: args [64626,64630]
name: args [66250,66254]
===
match
---
name: next_dagrun_info [61927,61943]
name: next_dagrun_info [61958,61974]
===
match
---
atom_expr [23938,23955]
atom_expr [23969,23986]
===
match
---
fstring_expr [19732,19738]
fstring_expr [19763,19769]
===
match
---
name: dag [55261,55264]
name: dag [55292,55295]
===
match
---
operator: @ [69521,69522]
operator: @ [71145,71146]
===
match
---
operator: = [58144,58145]
operator: = [58175,58176]
===
match
---
expr_stmt [12733,12809]
expr_stmt [12764,12840]
===
match
---
argument [26518,26546]
argument [26549,26577]
===
match
---
trailer [77081,77089]
trailer [78705,78713]
===
match
---
name: create_dagrun [56360,56373]
name: create_dagrun [56391,56404]
===
match
---
trailer [57190,57193]
trailer [57221,57224]
===
match
---
trailer [6117,6175]
trailer [6148,6206]
===
match
---
operator: , [5248,5249]
operator: , [5279,5280]
===
match
---
name: airflow [1896,1903]
name: airflow [1902,1909]
===
match
---
trailer [15585,15587]
trailer [15616,15618]
===
match
---
operator: , [22280,22281]
operator: , [22311,22312]
===
match
---
argument [50311,50317]
argument [50342,50348]
===
match
---
string: "task_2" [75786,75794]
string: "task_2" [77410,77418]
===
match
---
atom_expr [12634,12669]
atom_expr [12665,12700]
===
match
---
name: local_tz [38648,38656]
name: local_tz [38679,38687]
===
match
---
parameters [41312,41318]
parameters [41343,41349]
===
match
---
arglist [59454,59475]
arglist [59485,59506]
===
match
---
operator: + [46972,46973]
operator: + [47003,47004]
===
match
---
simple_stmt [15605,15641]
simple_stmt [15636,15672]
===
match
---
simple_stmt [3663,3676]
simple_stmt [3694,3707]
===
match
---
atom [29403,29489]
atom [29434,29520]
===
match
---
atom_expr [69944,69961]
atom_expr [71568,71585]
===
match
---
trailer [19098,19159]
trailer [19129,19190]
===
match
---
name: subdag [53382,53388]
name: subdag [53413,53419]
===
match
---
simple_stmt [53463,53480]
simple_stmt [53494,53511]
===
match
---
name: DAG [33412,33415]
name: DAG [33443,33446]
===
match
---
name: op3 [10667,10670]
name: op3 [10698,10701]
===
match
---
trailer [24816,24826]
trailer [24847,24857]
===
match
---
name: dag [59149,59152]
name: dag [59180,59183]
===
match
---
atom [78631,78679]
atom [80255,80303]
===
match
---
name: dag_run_state [55481,55494]
name: dag_run_state [55512,55525]
===
match
---
atom_expr [76688,76702]
atom_expr [78312,78326]
===
match
---
name: j [15027,15028]
name: j [15058,15059]
===
match
---
simple_stmt [57120,57152]
simple_stmt [57151,57183]
===
match
---
assert_stmt [20037,20083]
assert_stmt [20068,20114]
===
match
---
expr_stmt [73594,73617]
expr_stmt [75218,75241]
===
match
---
if_stmt [13947,13987]
if_stmt [13978,14018]
===
match
---
name: session [56744,56751]
name: session [56775,56782]
===
match
---
trailer [23483,23542]
trailer [23514,23573]
===
match
---
operator: != [48550,48552]
operator: != [48581,48583]
===
match
---
testlist_comp [21907,21919]
testlist_comp [21938,21950]
===
match
---
trailer [46308,46310]
trailer [46339,46341]
===
match
---
atom_expr [76062,76082]
atom_expr [77686,77706]
===
match
---
operator: = [39499,39500]
operator: = [39530,39531]
===
match
---
simple_stmt [43234,43270]
simple_stmt [43265,43301]
===
match
---
name: DummyOperator [39409,39422]
name: DummyOperator [39440,39453]
===
match
---
name: run_id [18302,18308]
name: run_id [18333,18339]
===
match
---
decorated [70079,70614]
decorated [71703,72238]
===
match
---
trailer [16310,16487]
trailer [16341,16518]
===
match
---
operator: , [19400,19401]
operator: , [19431,19432]
===
match
---
name: op3 [41752,41755]
name: op3 [41783,41786]
===
match
---
trailer [27118,27128]
trailer [27149,27159]
===
match
---
operator: , [78621,78622]
operator: , [80245,80246]
===
match
---
funcdef [6454,8035]
funcdef [6485,8066]
===
match
---
atom_expr [75575,75598]
atom_expr [77199,77222]
===
match
---
trailer [59858,59868]
trailer [59889,59899]
===
match
---
trailer [48370,48382]
trailer [48401,48413]
===
match
---
trailer [55730,55737]
trailer [55761,55768]
===
match
---
operator: == [7479,7481]
operator: == [7510,7512]
===
match
---
string: 'test-dag' [19779,19789]
string: 'test-dag' [19810,19820]
===
match
---
name: mock [1082,1086]
name: mock [1088,1092]
===
match
---
expr_stmt [37778,37851]
expr_stmt [37809,37882]
===
match
---
name: owner [58236,58241]
name: owner [58267,58272]
===
match
---
exprlist [13898,13906]
exprlist [13929,13937]
===
match
---
operator: = [78378,78379]
operator: = [80002,80003]
===
match
---
argument [27076,27089]
argument [27107,27120]
===
match
---
name: DummyOperator [39501,39514]
name: DummyOperator [39532,39545]
===
match
---
param [59006,59013]
param [59037,59044]
===
match
---
atom [30204,30280]
atom [30235,30311]
===
match
---
trailer [40026,40028]
trailer [40057,40059]
===
match
---
name: DagRun [1542,1548]
name: DagRun [1548,1554]
===
match
---
trailer [30626,30654]
trailer [30657,30685]
===
match
---
name: merge [54176,54181]
name: merge [54207,54212]
===
match
---
param [50409,50427]
param [50440,50458]
===
match
---
name: create_dagrun [53749,53762]
name: create_dagrun [53780,53793]
===
match
---
number: 0 [2655,2656]
number: 0 [2686,2687]
===
match
---
arglist [67722,67732]
arglist [69346,69356]
===
match
---
name: when [27551,27555]
name: when [27582,27586]
===
match
---
trailer [36726,36730]
trailer [36757,36761]
===
match
---
operator: , [53652,53653]
operator: , [53683,53684]
===
match
---
name: task [14481,14485]
name: task [14512,14516]
===
match
---
atom_expr [33956,33971]
atom_expr [33987,34002]
===
match
---
name: schedule_interval [78811,78828]
name: schedule_interval [80435,80452]
===
match
---
assert_stmt [7499,7527]
assert_stmt [7530,7558]
===
match
---
string: 'dag_without_catchup_ten_minute' [59923,59955]
string: 'dag_without_catchup_ten_minute' [59954,59986]
===
match
---
param [75433,75441]
param [77057,77065]
===
match
---
operator: , [53985,53986]
operator: , [54016,54017]
===
match
---
suite [2842,3018]
suite [2873,3049]
===
match
---
string: 'owner1' [33583,33591]
string: 'owner1' [33614,33622]
===
match
---
arglist [59399,59420]
arglist [59430,59451]
===
match
---
name: run_id [46957,46963]
name: run_id [46988,46994]
===
match
---
trailer [2639,2657]
trailer [2670,2688]
===
match
---
suite [72994,73022]
suite [74618,74646]
===
match
---
name: clear [54535,54540]
name: clear [54566,54571]
===
match
---
operator: == [36701,36703]
operator: == [36732,36734]
===
match
---
name: dag [41456,41459]
name: dag [41487,41490]
===
match
---
operator: = [56264,56265]
operator: = [56295,56296]
===
match
---
name: session [76612,76619]
name: session [78236,78243]
===
match
---
name: task_id [75729,75736]
name: task_id [77353,77360]
===
match
---
atom [30284,30370]
atom [30315,30401]
===
match
---
trailer [73733,73735]
trailer [75357,75359]
===
match
---
atom_expr [54106,54119]
atom_expr [54137,54150]
===
match
---
comparison [21318,21347]
comparison [21349,21378]
===
match
---
name: utcnow [46902,46908]
name: utcnow [46933,46939]
===
match
---
number: 1 [38432,38433]
number: 1 [38463,38464]
===
match
---
atom_expr [49753,49844]
atom_expr [49784,49875]
===
match
---
trailer [78133,78280]
trailer [79757,79904]
===
match
---
operator: = [47994,47995]
operator: = [48025,48026]
===
match
---
operator: , [66164,66165]
operator: , [67788,67789]
===
match
---
atom_expr [44776,44844]
atom_expr [44807,44875]
===
match
---
argument [39469,39481]
argument [39500,39512]
===
match
---
trailer [22457,22464]
trailer [22488,22495]
===
match
---
name: dag [57624,57627]
name: dag [57655,57658]
===
match
---
comp_op [58636,58642]
comp_op [58667,58673]
===
match
---
simple_stmt [1741,1789]
simple_stmt [1747,1795]
===
match
---
operator: , [70736,70737]
operator: , [72360,72361]
===
match
---
name: close [69508,69513]
name: close [71132,71137]
===
match
---
name: timedelta [70824,70833]
name: timedelta [72448,72457]
===
match
---
argument [6908,6921]
argument [6939,6952]
===
match
---
suite [39996,40072]
suite [40027,40103]
===
match
---
name: dag [12368,12371]
name: dag [12399,12402]
===
match
---
name: session [28304,28311]
name: session [28335,28342]
===
match
---
comp_op [42978,42984]
comp_op [43009,43015]
===
match
---
name: self [57265,57269]
name: self [57296,57300]
===
match
---
comparison [18869,18946]
comparison [18900,18977]
===
match
---
param [45597,45601]
param [45628,45632]
===
match
---
trailer [75586,75598]
trailer [77210,77222]
===
match
---
name: dag [36414,36417]
name: dag [36445,36448]
===
match
---
operator: , [35901,35902]
operator: , [35932,35933]
===
match
---
name: test_new_dag_is_paused_upon_creation [36443,36479]
name: test_new_dag_is_paused_upon_creation [36474,36510]
===
match
---
assert_stmt [31806,31866]
assert_stmt [31837,31897]
===
match
---
operator: = [18297,18298]
operator: = [18328,18329]
===
match
---
name: dag_id [45828,45834]
name: dag_id [45859,45865]
===
match
---
operator: = [13159,13160]
operator: = [13190,13191]
===
match
---
atom_expr [68131,68187]
atom_expr [69755,69811]
===
match
---
name: run_id [42971,42977]
name: run_id [43002,43008]
===
match
---
string: 'dag-bulk-sync-2' [30243,30260]
string: 'dag-bulk-sync-2' [30274,30291]
===
match
---
trailer [38577,38611]
trailer [38608,38642]
===
match
---
name: test_dag_orientation_default_value [6185,6219]
name: test_dag_orientation_default_value [6216,6250]
===
match
---
expr_stmt [47425,47454]
expr_stmt [47456,47485]
===
match
---
atom_expr [74419,74432]
atom_expr [76043,76056]
===
match
---
atom_expr [22871,22893]
atom_expr [22902,22924]
===
match
---
operator: < [60289,60290]
operator: < [60320,60321]
===
match
---
name: start [27407,27412]
name: start [27438,27443]
===
match
---
number: 2020 [62987,62991]
number: 2020 [63018,63022]
===
match
---
assert_stmt [35574,35672]
assert_stmt [35605,35703]
===
match
---
funcdef [11516,11622]
funcdef [11547,11653]
===
match
---
name: dags [30137,30141]
name: dags [30168,30172]
===
match
---
name: next_dagrun [68344,68355]
name: next_dagrun [69968,69979]
===
match
---
name: StringIO [39974,39982]
name: StringIO [40005,40013]
===
match
---
trailer [55716,55723]
trailer [55747,55754]
===
match
---
trailer [54905,54912]
trailer [54936,54943]
===
match
---
simple_stmt [57950,57976]
simple_stmt [57981,58007]
===
match
---
string: 'dag' [33006,33011]
string: 'dag' [33037,33042]
===
match
---
operator: , [41114,41115]
operator: , [41145,41146]
===
match
---
argument [67434,67449]
argument [69058,69073]
===
match
---
comparison [67908,67924]
comparison [69532,69548]
===
match
---
simple_stmt [30038,30066]
simple_stmt [30069,30097]
===
match
---
operator: = [26162,26163]
operator: = [26193,26194]
===
match
---
name: op1 [38830,38833]
name: op1 [38861,38864]
===
match
---
suite [43418,44448]
suite [43449,44479]
===
match
---
atom_expr [74853,74879]
atom_expr [76477,76503]
===
match
---
simple_stmt [21081,21117]
simple_stmt [21112,21148]
===
match
---
argument [41171,41178]
argument [41202,41209]
===
match
---
number: 0 [7718,7719]
number: 0 [7749,7750]
===
match
---
string: '@hourly' [27532,27541]
string: '@hourly' [27563,27572]
===
match
---
simple_stmt [22934,22970]
simple_stmt [22965,23001]
===
match
---
name: next_dagrun_create_after [68374,68398]
name: next_dagrun_create_after [69998,70022]
===
match
---
operator: , [78784,78785]
operator: , [80408,80409]
===
match
---
name: dag_id [44780,44786]
name: dag_id [44811,44817]
===
match
---
simple_stmt [12368,12500]
simple_stmt [12399,12531]
===
match
---
trailer [5412,5419]
trailer [5443,5450]
===
match
---
simple_stmt [23708,23763]
simple_stmt [23739,23794]
===
match
---
simple_stmt [53742,53953]
simple_stmt [53773,53984]
===
match
---
trailer [18083,18093]
trailer [18114,18124]
===
match
---
number: 2018 [27433,27437]
number: 2018 [27464,27468]
===
match
---
name: self [11375,11379]
name: self [11406,11410]
===
match
---
trailer [48824,48830]
trailer [48855,48861]
===
match
---
name: orm_dag [36644,36651]
name: orm_dag [36675,36682]
===
match
---
name: runs [57933,57937]
name: runs [57964,57968]
===
match
---
trailer [5852,5865]
trailer [5883,5896]
===
match
---
simple_stmt [2197,2235]
simple_stmt [2228,2266]
===
match
---
atom_expr [47646,47656]
atom_expr [47677,47687]
===
match
---
name: _clean_up [3163,3172]
name: _clean_up [3194,3203]
===
match
---
assert_stmt [51180,51219]
assert_stmt [51211,51250]
===
match
---
operator: { [38393,38394]
operator: { [38424,38425]
===
match
---
atom [11592,11620]
atom [11623,11651]
===
match
---
decorator [62059,62103]
decorator [62090,62134]
===
match
---
simple_stmt [1042,1068]
simple_stmt [1048,1074]
===
match
---
simple_stmt [3952,4095]
simple_stmt [3983,4126]
===
match
---
name: FAILED [76397,76403]
name: FAILED [78021,78027]
===
match
---
atom [49932,49971]
atom [49963,50002]
===
match
---
operator: , [53308,53309]
operator: , [53339,53340]
===
match
---
trailer [20315,20332]
trailer [20346,20363]
===
match
---
name: DeprecationWarning [66650,66668]
name: DeprecationWarning [68274,68292]
===
match
---
atom_expr [31529,31542]
atom_expr [31560,31573]
===
match
---
name: airflow [2299,2306]
name: airflow [2330,2337]
===
match
---
assert_stmt [18771,18853]
assert_stmt [18802,18884]
===
match
---
string: "test_dag" [39724,39734]
string: "test_dag" [39755,39765]
===
match
---
name: datetime [78050,78058]
name: datetime [79674,79682]
===
match
---
simple_stmt [43188,43226]
simple_stmt [43219,43257]
===
match
---
atom_expr [38335,38369]
atom_expr [38366,38400]
===
match
---
operator: = [53346,53347]
operator: = [53377,53378]
===
match
---
trailer [35241,35256]
trailer [35272,35287]
===
match
---
atom_expr [32894,32914]
atom_expr [32925,32945]
===
match
---
simple_stmt [34902,34934]
simple_stmt [34933,34965]
===
match
---
trailer [30099,30102]
trailer [30130,30133]
===
match
---
operator: , [78381,78382]
operator: , [80005,80006]
===
match
---
name: state [51437,51442]
name: state [51468,51473]
===
match
---
import_name [829,838]
import_name [829,838]
===
match
---
trailer [47628,47635]
trailer [47659,47666]
===
match
---
testlist_comp [39542,39550]
testlist_comp [39573,39581]
===
match
---
operator: == [45509,45511]
operator: == [45540,45542]
===
match
---
atom [30408,30440]
atom [30439,30471]
===
match
---
arglist [18901,18945]
arglist [18932,18976]
===
match
---
import_from [1891,1931]
import_from [1897,1937]
===
match
---
operator: , [60473,60474]
operator: , [60504,60505]
===
match
---
name: convert [22841,22848]
name: convert [22872,22879]
===
match
---
trailer [55888,55900]
trailer [55919,55931]
===
match
---
name: test_dag_id [47706,47717]
name: test_dag_id [47737,47748]
===
match
---
simple_stmt [10788,10812]
simple_stmt [10819,10843]
===
match
---
name: query [31763,31768]
name: query [31794,31799]
===
match
---
atom_expr [13213,13230]
atom_expr [13244,13261]
===
match
---
trailer [17858,17966]
trailer [17889,17997]
===
match
---
argument [55403,55453]
argument [55434,55484]
===
match
---
name: session [34973,34980]
name: session [35004,35011]
===
match
---
operator: , [41681,41682]
operator: , [41712,41713]
===
match
---
name: session [2720,2727]
name: session [2751,2758]
===
match
---
name: settings [54425,54433]
name: settings [54456,54464]
===
match
---
string: "t1" [40604,40608]
string: "t1" [40635,40639]
===
match
---
name: dag [59417,59420]
name: dag [59448,59451]
===
match
---
atom_expr [57176,57193]
atom_expr [57207,57224]
===
match
---
operator: = [50491,50492]
operator: = [50522,50523]
===
match
---
name: task_4 [76529,76535]
name: task_4 [78153,78159]
===
match
---
name: task_id [42643,42650]
name: task_id [42674,42681]
===
match
---
name: timezone [46893,46901]
name: timezone [46924,46932]
===
match
---
argument [54730,54753]
argument [54761,54784]
===
match
---
operator: = [52639,52640]
operator: = [52670,52671]
===
match
---
name: dag [25100,25103]
name: dag [25131,25134]
===
match
---
operator: = [28137,28138]
operator: = [28168,28169]
===
match
---
name: outdated_permissions [66544,66564]
name: outdated_permissions [68168,68188]
===
match
---
simple_stmt [13978,13987]
simple_stmt [14009,14018]
===
match
---
name: jinja_environment_kwargs [20216,20240]
name: jinja_environment_kwargs [20247,20271]
===
match
---
operator: , [29657,29658]
operator: , [29688,29689]
===
match
---
name: local_tz [22163,22171]
name: local_tz [22194,22202]
===
match
---
operator: = [32542,32543]
operator: = [32573,32574]
===
match
---
name: dag [48594,48597]
name: dag [48625,48628]
===
match
---
name: noop_pipeline [72347,72360]
name: noop_pipeline [73971,73984]
===
match
---
name: run_type [46120,46128]
name: run_type [46151,46159]
===
match
---
argument [33637,33654]
argument [33668,33685]
===
match
---
operator: == [28730,28732]
operator: == [28761,28763]
===
match
---
name: session [19143,19150]
name: session [19174,19181]
===
match
---
string: 'owner2' [7107,7115]
string: 'owner2' [7138,7146]
===
match
---
simple_stmt [41212,41255]
simple_stmt [41243,41286]
===
match
---
trailer [54181,54198]
trailer [54212,54229]
===
insert-tree
---
simple_stmt [1014,1048]
    import_from [1014,1047]
        name: typing [1019,1025]
        import_as_names [1033,1047]
            name: List [1033,1037]
            operator: , [1037,1038]
            name: Optional [1039,1047]
to
file_input [788,79097]
at 11
===
insert-tree
---
simple_stmt [1938,2010]
    import_from [1938,2009]
        dotted_name [1943,1966]
            name: airflow [1943,1950]
            name: timetables [1951,1961]
            name: base [1962,1966]
        import_as_names [1974,2009]
            name: DagRunInfo [1974,1984]
            operator: , [1984,1985]
            name: DataInterval [1986,1998]
            operator: , [1998,1999]
            name: Timetable [2000,2009]
to
file_input [788,79097]
at 34
===
insert-tree
---
funcdef [80723,81975]
    name: test_iter_dagrun_infos_between_error [80727,80763]
    parameters [80763,80771]
        param [80764,80770]
            name: caplog [80764,80770]
    suite [80772,81975]
        simple_stmt [80777,80847]
            expr_stmt [80777,80846]
                name: start [80777,80782]
                operator: = [80783,80784]
                atom_expr [80785,80846]
                    name: pendulum [80785,80793]
                    trailer [80793,80802]
                        name: instance [80794,80802]
                    trailer [80802,80846]
                        arith_expr [80803,80845]
                            name: DEFAULT_DATE [80803,80815]
                            operator: - [80816,80817]
                            atom_expr [80818,80845]
                                name: datetime [80818,80826]
                                trailer [80826,80836]
                                    name: timedelta [80827,80836]
                                trailer [80836,80845]
                                    argument [80837,80844]
                                        name: hours [80837,80842]
                                        operator: = [80842,80843]
                                        number: 1 [80843,80844]
        simple_stmt [80851,80889]
            expr_stmt [80851,80888]
                name: end [80851,80854]
                operator: = [80855,80856]
                atom_expr [80857,80888]
                    name: pendulum [80857,80865]
                    trailer [80865,80874]
                        name: instance [80866,80874]
                    trailer [80874,80888]
                        name: DEFAULT_DATE [80875,80887]
        classdef [80894,81169]
            name: FailingAfterOneTimetable [80900,80924]
            name: Timetable [80925,80934]
            suite [80936,81169]
                funcdef [80945,81169]
                    name: next_dagrun_info [80949,80965]
                    parameters [80965,81014]
                        param [80966,80971]
                            name: self [80966,80970]
                            operator: , [80970,80971]
                        param [80972,81001]
                            name: last_automated_data_interval [80972,81000]
                            operator: , [81000,81001]
                        param [81002,81013]
                            name: restriction [81002,81013]
                    suite [81015,81169]
                        if_stmt [81028,81124]
                            comparison [81031,81067]
                                name: last_automated_data_interval [81031,81059]
                            suite [81068,81124]
                                simple_stmt [81085,81124]
                                    return_stmt [81085,81123]
                                        atom_expr [81092,81123]
                                            name: DagRunInfo [81092,81102]
                                            trailer [81102,81111]
                                                name: interval [81103,81111]
                                            trailer [81111,81123]
                                                arglist [81112,81122]
                                                    name: start [81112,81117]
                                                    operator: , [81117,81118]
                                                    name: end [81119,81122]
                        simple_stmt [81136,81169]
                            raise_stmt [81136,81168]
                                atom_expr [81142,81168]
                                    name: RuntimeError [81142,81154]
                                    trailer [81154,81168]
                                        string: "this fails" [81155,81167]
        simple_stmt [81174,81325]
            expr_stmt [81174,81324]
                name: dag [81174,81177]
                operator: = [81178,81179]
                atom_expr [81180,81324]
                    name: DAG [81180,81183]
                    trailer [81183,81324]
                        arglist [81193,81318]
                            argument [81193,81238]
                                name: dag_id [81193,81199]
                                operator: = [81199,81200]
                                string: 'test_iter_dagrun_infos_between_error' [81200,81238]
                            operator: , [81238,81239]
                            argument [81248,81271]
                                name: start_date [81248,81258]
                                operator: = [81258,81259]
                                name: DEFAULT_DATE [81259,81271]
                            operator: , [81271,81272]
                            argument [81281,81317]
                                name: timetable [81281,81290]
                                operator: = [81290,81291]
                                atom_expr [81291,81317]
                                    name: FailingAfterOneTimetable [81291,81315]
                                    trailer [81315,81317]
                            operator: , [81317,81318]
        simple_stmt [81330,81411]
            expr_stmt [81330,81410]
                name: iterator [81330,81338]
                operator: = [81339,81340]
                atom_expr [81341,81410]
                    name: dag [81341,81344]
                    trailer [81344,81370]
                        name: iter_dagrun_infos_between [81345,81370]
                    trailer [81370,81410]
                        arglist [81371,81409]
                            argument [81371,81385]
                                name: earliest [81371,81379]
                                operator: = [81379,81380]
                                name: start [81380,81385]
                            operator: , [81385,81386]
                            argument [81387,81397]
                                name: latest [81387,81393]
                                operator: = [81393,81394]
                                name: end [81394,81397]
                            operator: , [81397,81398]
                            argument [81399,81409]
                                name: align [81399,81404]
                                operator: = [81404,81405]
        with_stmt [81415,81483]
            atom_expr [81420,81450]
                name: caplog [81420,81426]
                trailer [81426,81435]
                    name: at_level [81427,81435]
                trailer [81435,81450]
                    atom_expr [81436,81449]
                        name: logging [81436,81443]
                        trailer [81443,81449]
                            name: ERROR [81444,81449]
            suite [81451,81483]
                simple_stmt [81460,81483]
                    expr_stmt [81460,81482]
                        name: infos [81460,81465]
                        operator: = [81466,81467]
                        atom_expr [81468,81482]
                            name: list [81468,81472]
                            trailer [81472,81482]
                                name: iterator [81473,81481]
        simple_stmt [81598,81648]
            assert_stmt [81598,81647]
                comparison [81605,81647]
                    name: infos [81605,81610]
                    operator: == [81611,81613]
                    atom [81614,81647]
                        atom_expr [81615,81646]
                            name: DagRunInfo [81615,81625]
                            trailer [81625,81634]
                                name: interval [81626,81634]
                            trailer [81634,81646]
                                arglist [81635,81645]
                                    name: start [81635,81640]
                                    operator: , [81640,81641]
                                    name: end [81642,81645]
        simple_stmt [81653,81889]
            assert_stmt [81653,81888]
                comparison [81660,81888]
                    atom_expr [81660,81680]
                        name: caplog [81660,81666]
                        trailer [81666,81680]
                            name: record_tuples [81667,81680]
                    operator: == [81681,81683]
                    atom [81684,81888]
                        testlist_comp [81694,81882]
                            atom [81694,81881]
                                testlist_comp [81708,81871]
                                    string: "airflow.models.dag.DAG" [81708,81732]
                                    operator: , [81732,81733]
                                    atom_expr [81746,81759]
                                        name: logging [81746,81753]
                                        trailer [81753,81759]
                                            name: ERROR [81754,81759]
                                    operator: , [81759,81760]
                                    fstring [81773,81870]
                                        fstring_start: f" [81773,81775]
                                        fstring_string: Failed to fetch run info after data interval  [81775,81820]
                                        fstring_expr [81820,81846]
                                            operator: { [81820,81821]
                                            atom_expr [81821,81845]
                                                name: DataInterval [81821,81833]
                                                trailer [81833,81845]
                                                    arglist [81834,81844]
                                                        name: start [81834,81839]
                                                        operator: , [81839,81840]
                                                        name: end [81841,81844]
                                            operator: } [81845,81846]
                                        fstring_string:  for DAG  [81846,81855]
                                        fstring_expr [81855,81869]
                                            operator: { [81855,81856]
                                            atom_expr [81856,81866]
                                                name: dag [81856,81859]
                                                trailer [81859,81866]
                                                    name: dag_id [81860,81866]
                                            fstring_conversion [81866,81868]
                                                operator: ! [81866,81867]
                                                name: r [81867,81868]
                                            operator: } [81868,81869]
                                        fstring_end: " [81869,81870]
                                    operator: , [81870,81871]
                            operator: , [81881,81882]
        simple_stmt [81893,81975]
            assert_stmt [81893,81974]
                comparison [81900,81938]
                    atom_expr [81900,81926]
                        name: caplog [81900,81906]
                        trailer [81906,81914]
                            name: records [81907,81914]
                        trailer [81914,81917]
                            number: 0 [81915,81916]
                        trailer [81917,81926]
                            name: exc_info [81918,81926]
                    comp_op [81927,81933]
                operator: , [81938,81939]
                string: "should contain exception context" [81940,81974]
to
file_input [788,79097]
at 56
===
insert-node
---
name: TestDag [2817,2824]
to
classdef [2780,67224]
at 0
===
insert-tree
---
funcdef [63285,64873]
    name: test_next_dagrun_info_timetable_exception [63289,63330]
    parameters [63330,63336]
        param [63331,63335]
            name: self [63331,63335]
    suite [63337,64873]
        simple_stmt [63346,63432]
            string: """Test the DAG does not crash the scheduler if the timetable raises an exception.""" [63346,63431]
        classdef [63441,63608]
            name: FailingTimetable [63447,63463]
            name: Timetable [63464,63473]
            suite [63475,63608]
                funcdef [63488,63608]
                    name: next_dagrun_info [63492,63508]
                    parameters [63508,63557]
                        param [63509,63514]
                            name: self [63509,63513]
                            operator: , [63513,63514]
                        param [63515,63544]
                            name: last_automated_data_interval [63515,63543]
                            operator: , [63543,63544]
                        param [63545,63556]
                            name: restriction [63545,63556]
                    suite [63558,63608]
                        simple_stmt [63575,63608]
                            raise_stmt [63575,63607]
                                atom_expr [63581,63607]
                                    name: RuntimeError [63581,63593]
                                    trailer [63593,63607]
                                        string: "this fails" [63594,63606]
        simple_stmt [63617,63817]
            expr_stmt [63617,63816]
                name: dag [63617,63620]
                operator: = [63621,63622]
                atom_expr [63623,63816]
                    name: DAG [63623,63626]
                    trailer [63626,63816]
                        arglist [63640,63806]
                            string: "test_next_dagrun_info_timetable_exception" [63640,63683]
                            operator: , [63683,63684]
                            argument [63697,63737]
                                name: start_date [63697,63707]
                                operator: = [63707,63708]
                                atom_expr [63708,63737]
                                    name: timezone [63708,63716]
                                    trailer [63716,63725]
                                        name: datetime [63717,63725]
                                    trailer [63725,63737]
                                        arglist [63726,63736]
                                            number: 2020 [63726,63730]
                                            operator: , [63730,63731]
                                            number: 5 [63732,63733]
                                            operator: , [63733,63734]
                                            number: 1 [63735,63736]
                            operator: , [63737,63738]
                            argument [63751,63779]
                                name: timetable [63751,63760]
                                operator: = [63760,63761]
                                atom_expr [63761,63779]
                                    name: FailingTimetable [63761,63777]
                                    trailer [63777,63779]
                            operator: , [63779,63780]
                            argument [63793,63805]
                                name: catchup [63793,63800]
                                operator: = [63800,63801]
                            operator: , [63805,63806]
        funcdef [63826,64268]
            name: _check_logs [63830,63841]
            parameters [63841,63904]
                param [63842,63875]
                    tfpdef [63842,63874]
                        name: records [63842,63849]
                        atom_expr [63851,63874]
                            name: List [63851,63855]
                            trailer [63855,63874]
                                atom_expr [63856,63873]
                                    name: logging [63856,63863]
                                    trailer [63863,63873]
                                        name: LogRecord [63864,63873]
                    operator: , [63874,63875]
                param [63876,63903]
                    tfpdef [63876,63903]
                        name: data_interval [63876,63889]
                        name: DataInterval [63891,63903]
            operator: -> [63905,63907]
            suite [63913,64268]
                simple_stmt [63926,63951]
                    assert_stmt [63926,63950]
                        comparison [63933,63950]
                            atom_expr [63933,63945]
                                name: len [63933,63936]
                                trailer [63936,63945]
                                    name: records [63937,63944]
                            operator: == [63946,63948]
                            number: 1 [63949,63950]
                simple_stmt [63963,63983]
                    expr_stmt [63963,63982]
                        name: record [63963,63969]
                        operator: = [63970,63971]
                        atom_expr [63972,63982]
                            name: records [63972,63979]
                            trailer [63979,63982]
                                number: 0 [63980,63981]
                simple_stmt [63995,64058]
                    assert_stmt [63995,64057]
                        comparison [64002,64029]
                            atom_expr [64002,64017]
                                name: record [64002,64008]
                                trailer [64008,64017]
                                    name: exc_info [64009,64017]
                            comp_op [64018,64024]
                        operator: , [64029,64030]
                        string: "Should contain exception" [64031,64057]
                simple_stmt [64070,64268]
                    assert_stmt [64070,64267]
                        comparison [64077,64267]
                            atom_expr [64077,64096]
                                name: record [64077,64083]
                                trailer [64083,64094]
                                    name: getMessage [64084,64094]
                                trailer [64094,64096]
                            operator: == [64097,64099]
                            atom [64100,64267]
                                strings [64118,64253]
                                    fstring [64118,64182]
                                        fstring_start: f" [64118,64120]
                                        fstring_string: Failed to fetch run info after data interval  [64120,64165]
                                        fstring_expr [64165,64180]
                                            operator: { [64165,64166]
                                            name: data_interval [64166,64179]
                                            operator: } [64179,64180]
                                        fstring_string:   [64180,64181]
                                        fstring_end: " [64181,64182]
                                    fstring [64199,64253]
                                        fstring_start: f" [64199,64201]
                                        fstring_string: for DAG 'test_next_dagrun_info_timetable_exception' [64201,64252]
                                        fstring_end: " [64252,64253]
        with_stmt [64277,64387]
            with_item [64282,64334]
                atom_expr [64282,64327]
                    name: self [64282,64286]
                    trailer [64286,64297]
                        name: assertLogs [64287,64297]
                    trailer [64297,64327]
                        arglist [64298,64326]
                            atom_expr [64298,64305]
                                name: dag [64298,64301]
                                trailer [64301,64305]
                                    name: log [64302,64305]
                            operator: , [64305,64306]
                            argument [64307,64326]
                                name: level [64307,64312]
                                operator: = [64312,64313]
                                atom_expr [64313,64326]
                                    name: logging [64313,64320]
                                    trailer [64320,64326]
                                        name: ERROR [64321,64326]
                name: ctx [64331,64334]
            suite [64335,64387]
                simple_stmt [64348,64387]
                    expr_stmt [64348,64386]
                        name: next_info [64348,64357]
                        operator: = [64358,64359]
                        atom_expr [64360,64386]
                            name: dag [64360,64363]
                            trailer [64363,64380]
                                name: next_dagrun_info [64364,64380]
                            trailer [64380,64386]
        simple_stmt [64395,64466]
            assert_stmt [64395,64465]
                comparison [64402,64419]
                    name: next_info [64402,64411]
                operator: , [64419,64420]
                string: "failed next_dagrun_info should return None" [64421,64465]
        simple_stmt [64474,64519]
            atom_expr [64474,64518]
                name: _check_logs [64474,64485]
                trailer [64485,64518]
                    arglist [64486,64517]
                        atom_expr [64486,64497]
                            name: ctx [64486,64489]
                            trailer [64489,64497]
                                name: records [64490,64497]
                        operator: , [64497,64498]
                        argument [64499,64517]
                            name: data_interval [64499,64512]
                            operator: = [64512,64513]
        simple_stmt [64528,64619]
            expr_stmt [64528,64618]
                name: data_interval [64528,64541]
                operator: = [64542,64543]
                atom_expr [64544,64618]
                    name: DataInterval [64544,64556]
                    trailer [64556,64618]
                        arglist [64557,64617]
                            atom_expr [64557,64586]
                                name: timezone [64557,64565]
                                trailer [64565,64574]
                                    name: datetime [64566,64574]
                                trailer [64574,64586]
                                    arglist [64575,64585]
                                        number: 2020 [64575,64579]
                                        operator: , [64579,64580]
                                        number: 5 [64581,64582]
                                        operator: , [64582,64583]
                                        number: 1 [64584,64585]
                            operator: , [64586,64587]
                            atom_expr [64588,64617]
                                name: timezone [64588,64596]
                                trailer [64596,64605]
                                    name: datetime [64597,64605]
                                trailer [64605,64617]
                                    arglist [64606,64616]
                                        number: 2020 [64606,64610]
                                        operator: , [64610,64611]
                                        number: 5 [64612,64613]
                                        operator: , [64613,64614]
                                        number: 2 [64615,64616]
        with_stmt [64627,64746]
            with_item [64632,64684]
                atom_expr [64632,64677]
                    name: self [64632,64636]
                    trailer [64636,64647]
                        name: assertLogs [64637,64647]
                    trailer [64647,64677]
                        arglist [64648,64676]
                            atom_expr [64648,64655]
                                name: dag [64648,64651]
                                trailer [64651,64655]
                                    name: log [64652,64655]
                            operator: , [64655,64656]
                            argument [64657,64676]
                                name: level [64657,64662]
                                operator: = [64662,64663]
                                atom_expr [64663,64676]
                                    name: logging [64663,64670]
                                    trailer [64670,64676]
                                        name: ERROR [64671,64676]
                name: ctx [64681,64684]
            suite [64685,64746]
                simple_stmt [64698,64746]
                    expr_stmt [64698,64745]
                        name: next_info [64698,64707]
                        operator: = [64708,64709]
                        atom_expr [64710,64745]
                            name: dag [64710,64713]
                            trailer [64713,64730]
                                name: next_dagrun_info [64714,64730]
                            trailer [64730,64745]
                                name: data_interval [64731,64744]
        simple_stmt [64754,64825]
            assert_stmt [64754,64824]
                comparison [64761,64778]
                    name: next_info [64761,64770]
                operator: , [64778,64779]
                string: "failed next_dagrun_info should return None" [64780,64824]
        simple_stmt [64833,64873]
            atom_expr [64833,64872]
                name: _check_logs [64833,64844]
                trailer [64844,64872]
                    arglist [64845,64871]
                        atom_expr [64845,64856]
                            name: ctx [64845,64848]
                            trailer [64848,64856]
                                name: records [64849,64856]
                        operator: , [64856,64857]
                        name: data_interval [64858,64871]
to
suite [2813,67224]
at 78
===
delete-tree
---
simple_stmt [1014,1042]
    import_from [1014,1041]
        name: typing [1019,1025]
        name: Optional [1033,1041]
===
delete-tree
---
simple_stmt [1932,1979]
    import_from [1932,1978]
        dotted_name [1937,1960]
            name: airflow [1937,1944]
            name: timetables [1945,1955]
            name: base [1956,1960]
        name: DagRunInfo [1968,1978]
===
delete-node
---
name: TestDag [2786,2793]
===
