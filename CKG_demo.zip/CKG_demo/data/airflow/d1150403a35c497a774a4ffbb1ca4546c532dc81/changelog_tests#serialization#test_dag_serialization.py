===
match
---
string: "{{ task.task_id }}" [29678,29698]
string: "{{ task.task_id }}" [29584,29604]
===
match
---
simple_stmt [28789,28871]
simple_stmt [28695,28777]
===
match
---
atom_expr [15936,15975]
atom_expr [15842,15881]
===
match
---
atom_expr [24234,24262]
atom_expr [24140,24168]
===
match
---
operator: { [14485,14486]
operator: { [14391,14392]
===
match
---
string: 'google' [24305,24313]
string: 'google' [24211,24219]
===
match
---
operator: = [6308,6309]
operator: = [6308,6309]
===
match
---
operator: = [7589,7590]
operator: = [7589,7590]
===
match
---
atom_expr [39999,40017]
atom_expr [39905,39923]
===
match
---
argument [24342,24358]
argument [24248,24264]
===
match
---
operator: = [18476,18477]
operator: = [18382,18383]
===
match
---
name: BaseOperator [41933,41945]
name: BaseOperator [41839,41851]
===
match
---
name: dags [12380,12384]
name: dags [12380,12384]
===
match
---
if_stmt [8010,8334]
if_stmt [8010,8334]
===
match
---
operator: , [20791,20792]
operator: , [20697,20698]
===
match
---
argument [23354,23374]
argument [23260,23280]
===
match
---
operator: , [18179,18180]
operator: , [18085,18086]
===
match
---
operator: , [5054,5055]
operator: , [5054,5055]
===
match
---
name: serialized_dag [13736,13750]
name: serialized_dag [13642,13656]
===
match
---
name: dag_dict [38932,38940]
name: dag_dict [38838,38846]
===
match
---
operator: , [3286,3287]
operator: , [3286,3287]
===
match
---
simple_stmt [43151,43207]
simple_stmt [43886,43960]
===
match
---
atom [3431,3433]
atom [3431,3433]
===
match
---
name: serialized_task [15462,15477]
name: serialized_task [15368,15383]
===
match
---
name: start_date [25711,25721]
name: start_date [25617,25627]
===
match
---
operator: , [20471,20472]
operator: , [20377,20378]
===
match
---
atom_expr [18072,18113]
atom_expr [17978,18019]
===
match
---
trailer [25830,25838]
trailer [25736,25744]
===
match
---
string: 'task_1' [42461,42469]
string: 'task_1' [42367,42375]
===
match
---
operator: , [3821,3822]
operator: , [3821,3822]
===
match
---
name: dag [41839,41842]
name: dag [41745,41748]
===
match
---
argument [38705,38736]
argument [38611,38642]
===
match
---
operator: , [19547,19548]
operator: , [19453,19454]
===
match
---
atom_expr [5623,5666]
atom_expr [5623,5666]
===
match
---
number: 0 [19018,19019]
number: 0 [18924,18925]
===
match
---
number: 0 [17195,17196]
number: 0 [17101,17102]
===
match
---
name: super [33424,33429]
name: super [33330,33335]
===
match
---
string: "/vol/" [1960,1967]
string: "/vol/" [1960,1967]
===
match
---
trailer [43256,43278]
trailer [44009,44031]
===
match
---
name: dag [19030,19033]
name: dag [18936,18939]
===
match
---
operator: , [6204,6205]
operator: , [6204,6205]
===
match
---
operator: , [40815,40816]
operator: , [40721,40722]
===
match
---
operator: = [7791,7792]
operator: = [7791,7792]
===
match
---
number: 1 [4479,4480]
number: 1 [4479,4480]
===
match
---
simple_stmt [40916,40974]
simple_stmt [40822,40880]
===
match
---
operator: , [7778,7779]
operator: , [7778,7779]
===
match
---
name: dag_id [12075,12081]
name: dag_id [12075,12081]
===
match
---
atom_expr [1824,1986]
atom_expr [1824,1986]
===
match
---
string: "BigQuery Console #1" [28361,28382]
string: "BigQuery Console #1" [28267,28288]
===
match
---
assert_stmt [13579,13719]
assert_stmt [13485,13625]
===
match
---
operator: , [2267,2268]
operator: , [2267,2268]
===
match
---
name: key [10737,10740]
name: key [10737,10740]
===
match
---
operator: , [17970,17971]
operator: , [17876,17877]
===
match
---
argument [7639,7652]
argument [7639,7652]
===
match
---
arglist [16548,16579]
arglist [16454,16485]
===
match
---
comparison [13736,13785]
comparison [13642,13691]
===
match
---
comparison [15542,15562]
comparison [15448,15468]
===
match
---
string: "simple_task" [22648,22661]
string: "simple_task" [22554,22567]
===
match
---
string: "doc_md" [4336,4344]
string: "doc_md" [4336,4344]
===
match
---
return_stmt [8635,8646]
return_stmt [8635,8646]
===
match
---
suite [18739,18940]
suite [18645,18846]
===
match
---
atom_expr [11384,11407]
atom_expr [11384,11407]
===
match
---
operator: , [34276,34277]
operator: , [34182,34183]
===
match
---
trailer [20388,20406]
trailer [20294,20312]
===
match
---
atom [6657,6694]
atom [6657,6694]
===
match
---
name: expected_field [31698,31712]
name: expected_field [31604,31618]
===
match
---
atom_expr [28117,28173]
atom_expr [28023,28079]
===
match
---
name: downstream_task_ids [15198,15217]
name: downstream_task_ids [15104,15123]
===
match
---
name: datetime [921,929]
name: datetime [921,929]
===
match
---
name: dag [40786,40789]
name: dag [40692,40695]
===
match
---
operator: = [23443,23444]
operator: = [23349,23350]
===
match
---
expr_stmt [44731,44862]
expr_stmt [45484,45615]
===
match
---
name: self [13836,13840]
name: self [13742,13746]
===
match
---
name: DAG [40658,40661]
name: DAG [40564,40567]
===
match
---
param [40243,40257]
param [40149,40163]
===
match
---
trailer [33004,33009]
trailer [32910,32915]
===
match
---
operator: , [28091,28092]
operator: , [27997,27998]
===
match
---
testlist_comp [16091,16181]
testlist_comp [15997,16087]
===
match
---
operator: , [16388,16389]
operator: , [16294,16295]
===
match
---
string: "task1" [38788,38795]
string: "task1" [38694,38701]
===
match
---
string: 'email' [34573,34580]
string: 'email' [34479,34486]
===
match
---
name: SerializedDAG [41090,41103]
name: SerializedDAG [40996,41009]
===
match
---
simple_stmt [37556,37639]
simple_stmt [37462,37545]
===
match
---
expr_stmt [1735,1989]
expr_stmt [1735,1989]
===
match
---
comparison [33181,33231]
comparison [33087,33137]
===
match
---
name: end_date [18600,18608]
name: end_date [18506,18514]
===
match
---
atom [19683,19972]
atom [19589,19878]
===
match
---
expr_stmt [38809,38847]
expr_stmt [38715,38753]
===
match
---
name: getattr [32408,32415]
name: getattr [32314,32321]
===
match
---
testlist_comp [42442,43037]
testlist_comp [42348,43772]
===
match
---
operator: = [30895,30896]
operator: = [30801,30802]
===
match
---
operator: = [17356,17357]
operator: = [17262,17263]
===
match
---
dictorsetmaker [30135,30162]
dictorsetmaker [30041,30068]
===
match
---
dotted_name [1407,1429]
dotted_name [1407,1429]
===
match
---
trailer [8816,8820]
trailer [8816,8820]
===
match
---
number: 7 [18294,18295]
number: 7 [18200,18201]
===
match
---
name: json_dag [39026,39034]
name: json_dag [38932,38940]
===
match
---
atom [8188,8333]
atom [8188,8333]
===
match
---
simple_stmt [28300,28384]
simple_stmt [28206,28290]
===
match
---
atom_expr [37325,37351]
atom_expr [37231,37257]
===
match
---
name: path [5642,5646]
name: path [5642,5646]
===
match
---
arglist [18511,18521]
arglist [18417,18427]
===
match
---
assert_stmt [27612,27862]
assert_stmt [27518,27768]
===
match
---
atom_expr [5679,5688]
atom_expr [5679,5688]
===
match
---
name: task_id [37111,37118]
name: task_id [37017,37024]
===
match
---
operator: } [29824,29825]
operator: } [29730,29731]
===
match
---
name: utc [16310,16313]
name: utc [16216,16219]
===
match
---
atom [34762,34764]
atom [34668,34670]
===
match
---
name: dag_id [26896,26902]
name: dag_id [26802,26808]
===
match
---
string: 'trigger_rule' [35582,35596]
string: 'trigger_rule' [35488,35502]
===
match
---
operator: { [19745,19746]
operator: { [19651,19652]
===
match
---
operator: , [19748,19749]
operator: , [19654,19655]
===
match
---
operator: , [5254,5255]
operator: , [5254,5255]
===
match
---
atom [3615,3638]
atom [3615,3638]
===
match
---
operator: , [18239,18240]
operator: , [18145,18146]
===
match
---
operator: = [25782,25783]
operator: = [25688,25689]
===
match
---
string: "_operator_extra_links" [4751,4774]
string: "_operator_extra_links" [4751,4774]
===
match
---
dictorsetmaker [2158,2425]
dictorsetmaker [2158,2425]
===
match
---
name: dummy [36543,36548]
name: dummy [36449,36454]
===
match
---
fstring_string:  does not match [15433,15448]
fstring_string:  does not match [15339,15354]
===
match
---
atom [2028,5572]
atom [2028,5572]
===
match
---
simple_stmt [19621,19984]
simple_stmt [19527,19890]
===
match
---
name: expected_val [21829,21841]
name: expected_val [21735,21747]
===
match
---
name: serialized_task [15107,15122]
name: serialized_task [15013,15028]
===
match
---
atom [27780,27851]
atom [27686,27757]
===
match
---
name: self [29256,29260]
name: self [29162,29166]
===
match
---
trailer [1766,1989]
trailer [1766,1989]
===
match
---
simple_stmt [25960,26000]
simple_stmt [25866,25906]
===
match
---
atom_expr [15304,15335]
atom_expr [15210,15241]
===
match
---
atom [29638,29640]
atom [29544,29546]
===
match
---
comparison [21774,21813]
comparison [21680,21719]
===
match
---
parameters [43096,43141]
parameters [43831,43876]
===
match
---
trailer [7818,7825]
trailer [7818,7825]
===
match
---
trailer [44308,44316]
trailer [45061,45069]
===
match
---
string: "dag" [2054,2059]
string: "dag" [2054,2059]
===
match
---
comparison [20977,20997]
comparison [20883,20903]
===
match
---
name: set [24234,24237]
name: set [24140,24143]
===
match
---
simple_stmt [27086,27145]
simple_stmt [26992,27051]
===
match
---
number: 1 [20455,20456]
number: 1 [20361,20362]
===
match
---
operator: = [10740,10741]
operator: = [10740,10741]
===
match
---
string: "### Task Tutorial Documentation" [4346,4379]
string: "### Task Tutorial Documentation" [4346,4379]
===
match
---
simple_stmt [14329,14381]
simple_stmt [14235,14287]
===
match
---
string: '_dag' [34155,34161]
string: '_dag' [34061,34067]
===
match
---
operator: , [34210,34211]
operator: , [34116,34117]
===
match
---
name: tzinfo [17852,17858]
name: tzinfo [17758,17764]
===
match
---
trailer [44830,44851]
trailer [45583,45604]
===
match
---
operator: , [25916,25917]
operator: , [25822,25823]
===
match
---
name: custom_inbuilt_link [24646,24665]
name: custom_inbuilt_link [24552,24571]
===
match
---
string: 'execution_timeout' [34704,34723]
string: 'execution_timeout' [34610,34629]
===
match
---
string: "_task_type" [3839,3851]
string: "_task_type" [3839,3851]
===
match
---
with_item [38669,38744]
with_item [38575,38650]
===
match
---
trailer [15402,15409]
trailer [15308,15315]
===
match
---
string: "@weekly" [19272,19281]
string: "@weekly" [19178,19187]
===
match
---
string: 'resources' [35246,35257]
string: 'resources' [35152,35163]
===
match
---
operator: , [38703,38704]
operator: , [38609,38610]
===
match
---
name: serialized_task [15182,15197]
name: serialized_task [15088,15103]
===
match
---
atom_expr [13101,13120]
atom_expr [13130,13179]
===
match
---
name: dag [12597,12600]
name: dag [12597,12600]
===
match
---
number: 2019 [17565,17569]
number: 2019 [17471,17475]
===
match
---
string: 'simple_task' [16814,16827]
string: 'simple_task' [16720,16733]
===
match
---
simple_stmt [23513,23572]
simple_stmt [23419,23478]
===
match
---
assert_stmt [15100,15166]
assert_stmt [15006,15072]
===
match
---
simple_stmt [12159,12324]
simple_stmt [12159,12324]
===
match
---
string: "task1" [42932,42939]
string: "task1" [43512,43519]
===
match
---
number: 1 [35199,35200]
number: 1 [35105,35106]
===
match
---
operator: , [28209,28210]
operator: , [28115,28116]
===
match
---
name: child [38360,38365]
name: child [38266,38271]
===
match
---
number: 1 [17849,17850]
number: 1 [17755,17756]
===
match
---
string: "test" [32367,32373]
string: "test" [32273,32279]
===
match
---
name: serialized_dag [38393,38407]
name: serialized_dag [38299,38313]
===
match
---
string: "UTC" [5249,5254]
string: "UTC" [5249,5254]
===
match
---
string: '"use_proxy": "False", ' [9339,9363]
string: '"use_proxy": "False", ' [9339,9363]
===
match
---
name: deserialize_dag [37447,37462]
name: deserialize_dag [37353,37368]
===
match
---
argument [32141,32155]
argument [32047,32061]
===
match
---
argument [6612,6627]
argument [6612,6627]
===
match
---
atom [8059,8072]
atom [8059,8072]
===
match
---
funcdef [40169,41205]
funcdef [40075,41111]
===
match
---
string: 'bash_command' [4942,4956]
string: 'bash_command' [4942,4956]
===
match
---
string: "task2" [42986,42993]
string: "task2" [43566,43573]
===
match
---
trailer [38779,38796]
trailer [38685,38702]
===
match
---
testlist_comp [29984,30064]
testlist_comp [29890,29970]
===
match
---
trailer [22348,22353]
trailer [22254,22259]
===
match
---
suite [38745,38923]
suite [38651,38829]
===
match
---
operator: = [43839,43840]
operator: = [44592,44593]
===
match
---
param [43103,43124]
param [43838,43859]
===
match
---
atom_expr [6455,6492]
atom_expr [6455,6492]
===
match
---
param [29422,29427]
param [29328,29333]
===
match
---
name: volume_mounts [1901,1914]
name: volume_mounts [1901,1914]
===
match
---
string: "{{ task.task_id }}" [30454,30474]
string: "{{ task.task_id }}" [30360,30380]
===
match
---
name: models [1113,1119]
name: models [1113,1119]
===
match
---
simple_stmt [24738,24820]
simple_stmt [24644,24726]
===
match
---
simple_stmt [26012,26049]
simple_stmt [25918,25955]
===
match
---
operator: } [5536,5537]
operator: } [5536,5537]
===
match
---
atom_expr [28322,28383]
atom_expr [28228,28289]
===
match
---
operator: = [37299,37300]
operator: = [37205,37206]
===
match
---
name: dag [23649,23652]
name: dag [23555,23558]
===
match
---
name: dag_id [15403,15409]
name: dag_id [15309,15315]
===
match
---
atom_expr [9733,9745]
atom_expr [9733,9745]
===
match
---
argument [6527,6546]
argument [6527,6546]
===
match
---
argument [34023,34035]
argument [33929,33941]
===
match
---
operator: } [8629,8630]
operator: } [8629,8630]
===
match
---
atom_expr [32994,33011]
atom_expr [32900,32917]
===
match
---
atom_expr [25686,25743]
atom_expr [25592,25649]
===
match
---
atom_expr [20644,20672]
atom_expr [20550,20578]
===
match
---
simple_stmt [8990,9006]
simple_stmt [8990,9006]
===
match
---
simple_stmt [1030,1083]
simple_stmt [1030,1083]
===
match
---
operator: = [18501,18502]
operator: = [18407,18408]
===
match
---
expr_stmt [36986,37020]
expr_stmt [36892,36926]
===
match
---
operator: , [42527,42528]
operator: , [42433,42434]
===
match
---
argument [21302,21321]
argument [21208,21227]
===
match
---
string: 'CornflowerBlue' [2742,2758]
string: 'CornflowerBlue' [2742,2758]
===
match
---
string: '_BaseOperator__instantiated' [34106,34135]
string: '_BaseOperator__instantiated' [34012,34041]
===
match
---
operator: , [42573,42574]
operator: , [42479,42480]
===
match
---
name: task [14170,14174]
name: task [14076,14080]
===
match
---
argument [30767,30926]
argument [30673,30832]
===
match
---
trailer [27652,27677]
trailer [27558,27583]
===
match
---
simple_stmt [37361,37407]
simple_stmt [37267,37313]
===
match
---
operator: } [44596,44597]
operator: } [45349,45350]
===
match
---
name: glob [8388,8392]
name: glob [8388,8392]
===
match
---
trailer [40108,40114]
trailer [40014,40020]
===
match
---
name: val [22058,22061]
name: val [21964,21967]
===
match
---
assert_stmt [20095,20153]
assert_stmt [20001,20059]
===
match
---
funcdef [29342,29396]
funcdef [29248,29302]
===
match
---
suite [19612,20234]
suite [19518,20140]
===
match
---
name: DummyOperator [36990,37003]
name: DummyOperator [36896,36909]
===
match
---
name: serialized_task [16009,16024]
name: serialized_task [15915,15930]
===
match
---
comparison [13504,13536]
comparison [13410,13442]
===
match
---
operator: , [10735,10736]
operator: , [10735,10736]
===
match
---
operator: = [18648,18649]
operator: = [18554,18555]
===
match
---
trailer [17185,17194]
trailer [17091,17100]
===
match
---
for_stmt [29159,29235]
for_stmt [29065,29141]
===
match
---
simple_stmt [32867,32964]
simple_stmt [32773,32870]
===
match
---
name: pardir [5682,5688]
name: pardir [5682,5688]
===
match
---
name: sensors [39492,39499]
name: sensors [39398,39405]
===
match
---
operator: = [9708,9709]
operator: = [9708,9709]
===
match
---
simple_stmt [10677,10769]
simple_stmt [10677,10769]
===
match
---
atom_expr [10704,10768]
atom_expr [10704,10768]
===
match
---
trailer [8834,8842]
trailer [8834,8842]
===
match
---
name: dag_start_date [16769,16783]
name: dag_start_date [16675,16689]
===
match
---
simple_stmt [23323,23376]
simple_stmt [23229,23282]
===
match
---
name: dag [13674,13677]
name: dag [13580,13583]
===
match
---
atom [11590,11592]
atom [11590,11592]
===
match
---
atom_expr [11893,11916]
atom_expr [11893,11916]
===
match
---
or_test [15516,15562]
or_test [15422,15468]
===
match
---
operator: { [6775,6776]
operator: { [6775,6776]
===
match
---
simple_stmt [32519,32694]
simple_stmt [32425,32600]
===
match
---
suite [8362,8476]
suite [8362,8476]
===
match
---
name: MyOperator [33514,33524]
name: MyOperator [33420,33430]
===
match
---
string: "{{ task.task_id }}" [30229,30249]
string: "{{ task.task_id }}" [30135,30155]
===
match
---
trailer [16368,16372]
trailer [16274,16278]
===
match
---
argument [1949,1967]
argument [1949,1967]
===
match
---
string: "foo" [30213,30218]
string: "foo" [30119,30124]
===
match
---
operator: } [27849,27850]
operator: } [27755,27756]
===
match
---
operator: , [23352,23353]
operator: , [23258,23259]
===
match
---
string: "max_retry_delay" [4536,4553]
string: "max_retry_delay" [4536,4553]
===
match
---
name: field [15259,15264]
name: field [15165,15170]
===
match
---
name: GoogleLink [1723,1733]
name: GoogleLink [1723,1733]
===
match
---
name: poke_interval [39699,39712]
name: poke_interval [39605,39618]
===
match
---
string: """Verify non-airflow operators are casted to BaseOperator.""" [14191,14253]
string: """Verify non-airflow operators are casted to BaseOperator.""" [14097,14159]
===
match
---
name: level [43652,43657]
name: level [44405,44410]
===
match
---
name: set [32881,32884]
name: set [32787,32790]
===
match
---
argument [16560,16579]
argument [16466,16485]
===
match
---
testlist_comp [2620,2643]
testlist_comp [2620,2643]
===
match
---
simple_stmt [7664,7803]
simple_stmt [7664,7803]
===
match
---
operator: == [15622,15624]
operator: == [15528,15530]
===
match
---
dotted_name [852,866]
dotted_name [852,866]
===
match
---
atom_expr [44555,44587]
atom_expr [45308,45340]
===
match
---
operator: ** [29136,29138]
operator: ** [29042,29044]
===
match
---
name: test_date [24375,24384]
name: test_date [24281,24290]
===
match
---
operator: , [16156,16157]
operator: , [16062,16063]
===
match
---
trailer [17631,17654]
trailer [17537,17560]
===
match
---
operator: } [5525,5526]
operator: } [5525,5526]
===
match
---
arglist [18022,18053]
arglist [17928,17959]
===
match
---
string: 'task_1' [42606,42614]
string: 'task_1' [42512,42520]
===
match
---
atom [2828,2830]
atom [2828,2830]
===
match
---
name: SerializedDAG [32213,32226]
name: SerializedDAG [32119,32132]
===
match
---
param [17500,17504]
param [17406,17410]
===
match
---
name: task [15625,15629]
name: task [15531,15535]
===
match
---
number: 2 [20669,20670]
number: 2 [20575,20576]
===
match
---
expr_stmt [10781,10952]
expr_stmt [10781,10952]
===
match
---
atom [20512,20595]
atom [20418,20501]
===
match
---
name: expected_value [42075,42089]
name: expected_value [41981,41995]
===
match
---
operator: } [2688,2689]
operator: } [2688,2689]
===
match
---
operator: , [6058,6059]
operator: , [6058,6059]
===
match
---
atom [7590,7629]
atom [7590,7629]
===
match
---
trailer [11909,11914]
trailer [11909,11914]
===
match
---
operator: == [15842,15844]
operator: == [15748,15750]
===
match
---
atom_expr [6353,6380]
atom_expr [6353,6380]
===
match
---
name: dag_id [11807,11813]
name: dag_id [11807,11813]
===
match
---
string: 'on_success_callback' [14826,14847]
string: 'on_success_callback' [14732,14753]
===
match
---
name: c [44520,44521]
name: c [45273,45274]
===
match
---
simple_stmt [41839,41925]
simple_stmt [41745,41831]
===
match
---
number: 100.0 [4585,4590]
number: 100.0 [4585,4590]
===
match
---
argument [1847,1980]
argument [1847,1980]
===
match
---
atom [44746,44862]
atom [45499,45615]
===
match
---
name: realpath [5647,5655]
name: realpath [5647,5655]
===
match
---
string: 'simple_dag' [23340,23352]
string: 'simple_dag' [23246,23258]
===
match
---
operator: } [9711,9712]
operator: } [9711,9712]
===
match
---
suite [9746,9881]
suite [9746,9881]
===
match
---
trailer [38830,38847]
trailer [38736,38753]
===
match
---
simple_stmt [16727,16785]
simple_stmt [16633,16691]
===
match
---
string: "ClassWithCustomAttributes(" [31193,31221]
string: "ClassWithCustomAttributes(" [31099,31127]
===
match
---
trailer [22514,22517]
trailer [22420,22423]
===
match
---
operator: { [4002,4003]
operator: { [4002,4003]
===
match
---
simple_stmt [1991,5573]
simple_stmt [1991,5573]
===
match
---
operator: , [2117,2118]
operator: , [2117,2118]
===
match
---
name: v [9865,9866]
name: v [9865,9866]
===
match
---
string: "dag" [32759,32764]
string: "dag" [32665,32670]
===
match
---
atom_expr [28815,28870]
atom_expr [28721,28776]
===
match
---
name: datetime [25722,25730]
name: datetime [25628,25636]
===
match
---
string: '__var' [4062,4069]
string: '__var' [4062,4069]
===
match
---
name: dag_dict [10711,10719]
name: dag_dict [10711,10719]
===
match
---
operator: , [41326,41327]
operator: , [41232,41233]
===
match
---
simple_stmt [33036,33090]
simple_stmt [32942,32996]
===
match
---
number: 8 [26872,26873]
number: 8 [26778,26779]
===
match
---
suite [42090,42161]
suite [41996,42067]
===
match
---
atom [12821,13038]
atom [12821,13038]
===
match
---
operator: = [30955,30956]
operator: = [30861,30862]
===
match
---
name: permissions [5436,5447]
name: permissions [5436,5447]
===
match
---
trailer [18021,18054]
trailer [17927,17960]
===
match
---
atom_expr [38817,38847]
atom_expr [38723,38753]
===
match
---
testlist_comp [29678,29720]
testlist_comp [29584,29626]
===
match
---
trailer [14406,14426]
trailer [14312,14332]
===
match
---
operator: , [34141,34142]
operator: , [34047,34048]
===
match
---
trailer [12447,12475]
trailer [12447,12475]
===
match
---
name: self [29130,29134]
name: self [29036,29040]
===
match
---
atom_expr [7932,7949]
atom_expr [7932,7949]
===
match
---
trailer [16575,16579]
trailer [16481,16485]
===
match
---
operator: = [6617,6618]
operator: = [6617,6618]
===
match
---
operator: , [7358,7359]
operator: , [7358,7359]
===
match
---
trailer [20073,20085]
trailer [19979,19991]
===
match
---
name: test_date [28163,28172]
name: test_date [28069,28078]
===
match
---
operator: , [2830,2831]
operator: , [2830,2831]
===
match
---
name: dag_folder [8147,8157]
name: dag_folder [8147,8157]
===
match
---
name: level [43673,43678]
name: level [44426,44431]
===
match
---
operator: , [43002,43003]
operator: , [43582,43583]
===
match
---
operator: = [16743,16744]
operator: = [16649,16650]
===
match
---
assert_stmt [39871,39896]
assert_stmt [39777,39802]
===
match
---
atom [5283,5537]
atom [5283,5537]
===
match
---
operator: { [5983,5984]
operator: { [5983,5984]
===
match
---
param [33821,33825]
param [33727,33731]
===
match
---
parameters [10075,10109]
parameters [10075,10109]
===
match
---
name: dag [20169,20172]
name: dag [20075,20078]
===
match
---
string: 'children' [2593,2603]
string: 'children' [2593,2603]
===
match
---
string: 'executor_config' [34743,34760]
string: 'executor_config' [34649,34666]
===
match
---
assert_stmt [17137,17197]
assert_stmt [17043,17103]
===
match
---
comparison [24585,24665]
comparison [24491,24571]
===
match
---
for_stmt [38304,38367]
for_stmt [38210,38273]
===
match
---
operator: , [41309,41310]
operator: , [41215,41216]
===
match
---
name: minutes [6048,6055]
name: minutes [6048,6055]
===
match
---
trailer [43707,43710]
trailer [44460,44463]
===
match
---
name: DAG [36685,36688]
name: DAG [36591,36594]
===
match
---
string: "echo" [27307,27313]
string: "echo" [27213,27219]
===
match
---
fstring_expr [15411,15425]
fstring_expr [15317,15331]
===
match
---
atom [8146,8158]
atom [8146,8158]
===
match
---
operator: , [7419,7420]
operator: , [7419,7420]
===
match
---
number: 1 [6008,6009]
number: 1 [6008,6009]
===
match
---
operator: { [2028,2029]
operator: { [2028,2029]
===
match
---
trailer [13914,13923]
trailer [13820,13829]
===
match
---
fstring_expr [8409,8418]
fstring_expr [8409,8418]
===
match
---
simple_stmt [37041,37076]
simple_stmt [36947,36982]
===
match
---
parameters [5715,5728]
parameters [5715,5728]
===
match
---
suite [22448,22518]
suite [22354,22424]
===
match
---
name: join [5618,5622]
name: join [5618,5622]
===
match
---
name: dag [21469,21472]
name: dag [21375,21378]
===
match
---
operator: , [42779,42780]
operator: , [42685,42686]
===
match
---
operator: , [14174,14175]
operator: , [14080,14081]
===
match
---
operator: = [44473,44474]
operator: = [45226,45227]
===
match
---
operator: , [4518,4519]
operator: , [4518,4519]
===
match
---
atom_expr [44239,44276]
atom_expr [44992,45029]
===
match
---
name: from_json [39051,39060]
name: from_json [38957,38966]
===
match
---
fstring_expr [15426,15433]
fstring_expr [15332,15339]
===
match
---
operator: , [13000,13001]
operator: , [13000,13001]
===
match
---
operator: , [7234,7235]
operator: , [7234,7235]
===
match
---
atom [20284,20360]
atom [20190,20266]
===
match
---
name: test_utils [1660,1670]
name: test_utils [1660,1670]
===
match
---
name: dag_id [18470,18476]
name: dag_id [18376,18382]
===
match
---
dictorsetmaker [44760,44852]
dictorsetmaker [45513,45605]
===
match
---
atom_expr [33181,33223]
atom_expr [33087,33129]
===
match
---
name: dag [23323,23326]
name: dag [23229,23232]
===
match
---
operator: , [38732,38733]
operator: , [38638,38639]
===
match
---
name: PodGenerator [1253,1265]
name: PodGenerator [1253,1265]
===
match
---
operator: , [34895,34896]
operator: , [34801,34802]
===
match
---
name: dags [8788,8792]
name: dags [8788,8792]
===
match
---
trailer [37597,37602]
trailer [37503,37508]
===
match
---
name: set [32984,32987]
name: set [32890,32893]
===
match
---
name: task_end_date [18412,18425]
name: task_end_date [18318,18331]
===
match
---
name: self [16653,16657]
name: self [16559,16563]
===
match
---
operator: , [35137,35138]
operator: , [35043,35044]
===
match
---
name: simple_task [19084,19095]
name: simple_task [18990,19001]
===
match
---
trailer [20854,20859]
trailer [20760,20765]
===
match
---
simple_stmt [7312,7365]
simple_stmt [7312,7365]
===
match
---
name: dag_schema [32702,32712]
name: dag_schema [32608,32618]
===
match
---
name: ClassWithCustomAttributes [30720,30745]
name: ClassWithCustomAttributes [30626,30651]
===
match
---
operator: , [42634,42635]
operator: , [42540,42541]
===
match
---
operator: } [20729,20730]
operator: } [20635,20636]
===
match
---
name: serialize_subprocess [11454,11474]
name: serialize_subprocess [11454,11474]
===
match
---
simple_stmt [8135,8159]
simple_stmt [8135,8159]
===
match
---
name: default_args [13524,13536]
name: default_args [13430,13442]
===
match
---
string: "sar" [30319,30324]
string: "sar" [30225,30230]
===
match
---
atom [18142,18336]
atom [18048,18242]
===
match
---
argument [19412,19418]
argument [19318,19324]
===
match
---
string: "__var" [10816,10823]
string: "__var" [10816,10823]
===
match
---
name: do_xcom_push [33377,33389]
name: do_xcom_push [33283,33295]
===
match
---
string: 'simple_dag' [22189,22201]
string: 'simple_dag' [22095,22107]
===
match
---
trailer [37446,37462]
trailer [37352,37368]
===
match
---
testlist_comp [21952,21998]
testlist_comp [21858,21904]
===
match
---
name: test_serialized_objects_are_sorted [43062,43096]
name: test_serialized_objects_are_sorted [43797,43831]
===
match
---
trailer [33639,33643]
trailer [33545,33549]
===
match
---
name: dag [13902,13905]
name: dag [13808,13811]
===
match
---
for_stmt [8338,8476]
for_stmt [8338,8476]
===
match
---
string: "kubernetes" [44613,44625]
string: "kubernetes" [45366,45378]
===
match
---
atom [9110,9446]
atom [9110,9446]
===
match
---
operator: } [30327,30328]
operator: } [30233,30234]
===
match
---
name: operators [36533,36542]
name: operators [36439,36448]
===
match
---
simple_stmt [15018,15091]
simple_stmt [14924,14997]
===
match
---
trailer [15068,15090]
trailer [14974,14996]
===
match
---
trailer [8463,8474]
trailer [8463,8474]
===
match
---
string: 'simple_dag' [5948,5960]
string: 'simple_dag' [5948,5960]
===
match
---
operator: , [1721,1722]
operator: , [1721,1722]
===
match
---
trailer [9044,9049]
trailer [9044,9049]
===
match
---
string: "retry_delay" [2230,2243]
string: "retry_delay" [2230,2243]
===
match
---
name: dag [17358,17361]
name: dag [17264,17267]
===
match
---
operator: = [33389,33390]
operator: = [33295,33296]
===
match
---
atom [17936,18128]
atom [17842,18034]
===
match
---
name: tzinfo [17577,17583]
name: tzinfo [17483,17489]
===
match
---
name: dags [8642,8646]
name: dags [8642,8646]
===
match
---
name: return_value [9063,9075]
name: return_value [9063,9075]
===
match
---
string: "bar" [30135,30140]
string: "bar" [30041,30046]
===
match
---
trailer [24249,24261]
trailer [24155,24167]
===
match
---
atom_expr [12791,12818]
atom_expr [12791,12818]
===
match
---
name: task_id [36894,36901]
name: task_id [36800,36807]
===
match
---
atom_expr [16168,16180]
atom_expr [16074,16086]
===
match
---
trailer [44575,44587]
trailer [45328,45340]
===
match
---
testlist_comp [20284,20733]
testlist_comp [20190,20639]
===
match
---
trailer [11924,11937]
trailer [11924,11937]
===
match
---
operator: { [20711,20712]
operator: { [20617,20618]
===
match
---
name: dag_id [9867,9873]
name: dag_id [9867,9873]
===
match
---
operator: = [30774,30775]
operator: = [30680,30681]
===
match
---
string: 'default_args' [12986,13000]
string: 'default_args' [12986,13000]
===
match
---
name: pytest [44877,44883]
name: pytest [45630,45636]
===
match
---
operator: { [4113,4114]
operator: { [4113,4114]
===
match
---
simple_stmt [37089,37128]
simple_stmt [36995,37034]
===
match
---
trailer [17413,17424]
trailer [17319,17330]
===
match
---
name: dag [11701,11704]
name: dag [11701,11704]
===
match
---
atom [20270,20743]
atom [20176,20649]
===
match
---
string: 'bash' [3702,3708]
string: 'bash' [3702,3708]
===
match
---
annassign [32712,32779]
annassign [32618,32685]
===
match
---
name: start_date [23354,23364]
name: start_date [23260,23270]
===
match
---
name: parameterized [41211,41224]
name: parameterized [41117,41130]
===
match
---
name: dag [12535,12538]
name: dag [12535,12538]
===
match
---
name: test_roundtrip_relativedelta [20758,20786]
name: test_roundtrip_relativedelta [20664,20692]
===
match
---
name: task_id [26962,26969]
name: task_id [26868,26875]
===
match
---
name: task_id [38831,38838]
name: task_id [38737,38744]
===
match
---
atom_expr [18248,18260]
atom_expr [18154,18166]
===
match
---
atom_expr [17954,17995]
atom_expr [17860,17901]
===
match
---
string: "_dag_id" [3009,3018]
string: "_dag_id" [3009,3018]
===
match
---
suite [32510,33090]
suite [32416,32996]
===
match
---
atom_expr [39988,39995]
atom_expr [39894,39901]
===
match
---
trailer [44162,44167]
trailer [44915,44920]
===
match
---
trailer [37220,37228]
trailer [37126,37134]
===
match
---
name: utc [17917,17920]
name: utc [17823,17826]
===
match
---
operator: , [2689,2690]
operator: , [2689,2690]
===
match
---
param [41399,41404]
param [41305,41310]
===
match
---
number: 1 [23312,23313]
number: 1 [23218,23219]
===
match
---
string: 'downstream_group_ids' [2844,2866]
string: 'downstream_group_ids' [2844,2866]
===
match
---
name: task_end_date [18609,18622]
name: task_end_date [18515,18528]
===
match
---
suite [25476,25672]
suite [25382,25578]
===
match
---
argument [43942,43968]
argument [44695,44721]
===
match
---
name: expand [39311,39317]
name: expand [39217,39223]
===
match
---
trailer [27273,27302]
trailer [27179,27208]
===
match
---
name: dag [7827,7830]
name: dag [7827,7830]
===
match
---
argument [16501,16520]
argument [16407,16426]
===
match
---
trailer [16281,16314]
trailer [16187,16220]
===
match
---
operator: = [37095,37096]
operator: = [37001,37002]
===
match
---
not_test [29534,29556]
not_test [29440,29462]
===
match
---
name: serialized_dag [12519,12533]
name: serialized_dag [12519,12533]
===
match
---
atom_expr [7268,7306]
atom_expr [7268,7306]
===
match
---
operator: } [30121,30122]
operator: } [30027,30028]
===
match
---
string: "retries" [2200,2209]
string: "retries" [2200,2209]
===
match
---
suite [43985,45083]
suite [44738,45836]
===
match
---
name: SerializedDAG [20050,20063]
name: SerializedDAG [19956,19969]
===
match
---
simple_stmt [24979,25175]
simple_stmt [24885,25081]
===
match
---
name: serialized_dag [17164,17178]
name: serialized_dag [17070,17084]
===
match
---
name: v [13422,13423]
name: v [13328,13329]
===
match
---
expr_stmt [25800,25843]
expr_stmt [25706,25749]
===
match
---
name: name [1934,1938]
name: name [1934,1938]
===
match
---
operator: = [6278,6279]
operator: = [6278,6279]
===
match
---
param [10076,10081]
param [10076,10081]
===
match
---
param [36427,36431]
param [36333,36337]
===
match
---
operator: , [32089,32090]
operator: , [31995,31996]
===
match
---
suite [12602,14086]
suite [12602,13992]
===
match
---
name: children [37725,37733]
name: children [37631,37639]
===
match
---
string: 'ui_color' [2730,2740]
string: 'ui_color' [2730,2740]
===
match
---
simple_stmt [21292,21335]
simple_stmt [21198,21241]
===
match
---
operator: = [6398,6399]
operator: = [6398,6399]
===
match
---
operator: , [42500,42501]
operator: , [42406,42407]
===
match
---
atom_expr [9040,9470]
atom_expr [9040,9470]
===
match
---
atom [29677,29721]
atom [29583,29627]
===
match
---
string: 'pool_slots' [35151,35163]
string: 'pool_slots' [35057,35069]
===
match
---
dotted_name [19195,19215]
dotted_name [19101,19121]
===
match
---
number: 2020 [36660,36664]
number: 2020 [36566,36570]
===
match
---
name: self [29449,29453]
name: self [29355,29359]
===
match
---
operator: = [20665,20666]
operator: = [20571,20572]
===
match
---
name: multiprocessing [11384,11399]
name: multiprocessing [11384,11399]
===
match
---
name: operator [25371,25379]
name: operator [25277,25285]
===
match
---
name: SerializedDAG [20830,20843]
name: SerializedDAG [20736,20749]
===
match
---
trailer [39060,39088]
trailer [38966,38994]
===
match
---
name: task [14995,14999]
name: task [14901,14905]
===
match
---
argument [25775,25789]
argument [25681,25695]
===
match
---
trailer [39263,39273]
trailer [39169,39179]
===
match
---
operator: = [18464,18465]
operator: = [18370,18371]
===
match
---
operator: , [28024,28025]
operator: , [27930,27931]
===
match
---
name: serialized_dag [18633,18647]
name: serialized_dag [18539,18553]
===
match
---
name: module [45021,45027]
name: module [45774,45780]
===
match
---
trailer [20006,20022]
trailer [19912,19928]
===
match
---
name: pod_override [44731,44743]
name: pod_override [45484,45496]
===
match
---
operator: } [20468,20469]
operator: } [20374,20375]
===
match
---
operator: , [16373,16374]
operator: , [16279,16280]
===
match
---
name: dag_dict [39008,39016]
name: dag_dict [38914,38922]
===
match
---
atom_expr [18502,18522]
atom_expr [18408,18428]
===
match
---
expr_stmt [26061,26226]
expr_stmt [25967,26132]
===
match
---
arglist [26866,26876]
arglist [26772,26782]
===
match
---
operator: == [27951,27953]
operator: == [27857,27859]
===
match
---
simple_stmt [20162,20234]
simple_stmt [20068,20140]
===
match
---
name: getattr [13101,13108]
name: getattr [13130,13137]
===
match
---
string: 'fileloc' [10284,10293]
string: 'fileloc' [10284,10293]
===
match
---
comp_op [15905,15911]
comp_op [15811,15817]
===
match
---
suite [8916,43457]
suite [8916,44210]
===
match
---
atom_expr [13368,13392]
atom_expr [13274,13298]
===
match
---
name: name [43604,43608]
name: name [44357,44361]
===
match
---
atom_expr [32267,32306]
atom_expr [32173,32212]
===
match
---
string: "param_1" [21074,21083]
string: "param_1" [20980,20989]
===
match
---
name: dag [40782,40785]
name: dag [40688,40691]
===
match
---
trailer [38359,38366]
trailer [38265,38272]
===
match
---
name: tests [1654,1659]
name: tests [1654,1659]
===
match
---
atom_expr [33047,33074]
atom_expr [32953,32980]
===
match
---
operator: , [13900,13901]
operator: , [13806,13807]
===
match
---
trailer [41848,41924]
trailer [41754,41830]
===
match
---
atom [9710,9712]
atom [9710,9712]
===
match
---
string: 'on_retry_callback' [34950,34969]
string: 'on_retry_callback' [34856,34875]
===
match
---
argument [30948,31107]
argument [30854,31013]
===
match
---
arglist [40759,40822]
arglist [40665,40728]
===
match
---
trailer [42058,42063]
trailer [41964,41969]
===
match
---
name: test_templated_fields_exist_in_serialized_dag [31629,31674]
name: test_templated_fields_exist_in_serialized_dag [31535,31580]
===
match
---
arglist [24792,24818]
arglist [24698,24724]
===
match
---
lambdef [7600,7628]
lambdef [7600,7628]
===
match
---
if_stmt [15459,15640]
if_stmt [15365,15546]
===
match
---
operator: = [43657,43658]
operator: = [44410,44411]
===
match
---
trailer [28349,28383]
trailer [28255,28289]
===
match
---
name: raises [44884,44890]
name: raises [45637,45643]
===
match
---
operator: , [18054,18055]
operator: , [17960,17961]
===
match
---
string: 'template_fields' [14696,14713]
string: 'template_fields' [14602,14619]
===
match
---
string: "nested1" [31146,31155]
string: "nested1" [31052,31061]
===
match
---
operator: { [44475,44476]
operator: { [45228,45229]
===
match
---
operator: } [20357,20358]
operator: } [20263,20264]
===
match
---
simple_stmt [15929,15976]
simple_stmt [15835,15882]
===
match
---
atom_expr [22484,22517]
atom_expr [22390,22423]
===
match
---
expr_stmt [17290,17335]
expr_stmt [17196,17241]
===
match
---
trailer [40863,40871]
trailer [40769,40777]
===
match
---
atom [2385,2424]
atom [2385,2424]
===
match
---
atom [5367,5512]
atom [5367,5512]
===
match
---
operator: , [6238,6239]
operator: , [6238,6239]
===
match
---
trailer [10276,10283]
trailer [10276,10283]
===
match
---
string: 'timezone' [12899,12909]
string: 'timezone' [12899,12909]
===
match
---
operator: , [20732,20733]
operator: , [20638,20639]
===
match
---
expr_stmt [41839,41924]
expr_stmt [41745,41830]
===
match
---
name: os [5588,5590]
name: os [5588,5590]
===
match
---
name: dag_dict [37272,37280]
name: dag_dict [37178,37186]
===
match
---
atom [5983,6204]
atom [5983,6204]
===
match
---
argument [30853,30878]
argument [30759,30784]
===
match
---
name: task_dict [23653,23662]
name: task_dict [23559,23568]
===
match
---
string: "has_on_failure_callback" [42110,42135]
string: "has_on_failure_callback" [42016,42041]
===
match
---
while_stmt [11601,11821]
while_stmt [11601,11821]
===
match
---
trailer [44270,44276]
trailer [45023,45029]
===
match
---
trailer [27173,27183]
trailer [27079,27089]
===
match
---
argument [20658,20671]
argument [20564,20577]
===
match
---
operator: , [16286,16287]
operator: , [16192,16193]
===
match
---
argument [22268,22299]
argument [22174,22205]
===
match
---
trailer [12178,12323]
trailer [12178,12323]
===
match
---
trailer [37271,37281]
trailer [37177,37187]
===
match
---
trailer [15897,15904]
trailer [15803,15810]
===
match
---
atom_expr [17831,17872]
atom_expr [17737,17778]
===
match
---
name: start_date [22268,22278]
name: start_date [22174,22184]
===
match
---
exprlist [9725,9729]
exprlist [9725,9729]
===
match
---
name: val [22365,22368]
name: val [22271,22274]
===
match
---
name: passed_failure_callback [41900,41923]
name: passed_failure_callback [41806,41829]
===
match
---
name: SerializedDAG [17753,17766]
name: SerializedDAG [17659,17672]
===
match
---
operator: = [32988,32989]
operator: = [32894,32895]
===
match
---
string: "__type" [19718,19726]
string: "__type" [19624,19632]
===
match
---
trailer [24341,24385]
trailer [24247,24291]
===
match
---
string: "__var" [20568,20575]
string: "__var" [20474,20481]
===
match
---
operator: = [11480,11481]
operator: = [11480,11481]
===
match
---
atom_expr [33467,33484]
atom_expr [33373,33390]
===
match
---
atom_expr [11889,11917]
atom_expr [11889,11917]
===
match
---
name: dag_folder [8013,8023]
name: dag_folder [8013,8023]
===
match
---
operator: , [34383,34384]
operator: , [34289,34290]
===
match
---
number: 8 [16288,16289]
number: 8 [16194,16195]
===
match
---
string: "__version" [2034,2045]
string: "__version" [2034,2045]
===
match
---
name: task [14407,14411]
name: task [14313,14317]
===
match
---
name: timezone [18188,18196]
name: timezone [18094,18102]
===
match
---
name: test_no_new_fields_added_to_base_operator [33779,33820]
name: test_no_new_fields_added_to_base_operator [33685,33726]
===
match
---
name: BaseHook [1199,1207]
name: BaseHook [1199,1207]
===
match
---
number: 1 [2211,2212]
number: 1 [2211,2212]
===
match
---
name: deserialize_operator [38013,38033]
name: deserialize_operator [37919,37939]
===
match
---
trailer [11730,11733]
trailer [11730,11733]
===
match
---
try_stmt [37688,38291]
try_stmt [37594,38197]
===
match
---
trailer [38392,38419]
trailer [38298,38325]
===
match
---
string: "ui_fgcolor" [4884,4896]
string: "ui_fgcolor" [4884,4896]
===
match
---
trailer [33620,33639]
trailer [33526,33545]
===
match
---
name: compute_next_execution_date [7203,7230]
name: compute_next_execution_date [7203,7230]
===
match
---
operator: { [19683,19684]
operator: { [19589,19590]
===
match
---
simple_stmt [38168,38180]
simple_stmt [38074,38086]
===
match
---
name: self [14131,14135]
name: self [14037,14041]
===
match
---
string: "true" [27016,27022]
string: "true" [26922,26928]
===
match
---
operator: , [43940,43941]
operator: , [44693,44694]
===
match
---
name: expected_val [21183,21195]
name: expected_val [21089,21101]
===
match
---
testlist_comp [16090,16596]
testlist_comp [15996,16502]
===
match
---
name: tzinfo [16235,16241]
name: tzinfo [16141,16147]
===
match
---
name: self [9947,9951]
name: self [9947,9951]
===
match
---
operator: , [25735,25736]
operator: , [25641,25642]
===
match
---
atom_expr [37097,37127]
atom_expr [37003,37033]
===
match
---
atom_expr [11786,11814]
atom_expr [11786,11814]
===
match
---
name: bash_command [6560,6572]
name: bash_command [6560,6572]
===
match
---
argument [11476,11512]
argument [11476,11512]
===
match
---
string: "group234" [36835,36845]
string: "group234" [36741,36751]
===
match
---
string: "timezone" [5237,5247]
string: "timezone" [5237,5247]
===
match
---
trailer [42153,42160]
trailer [42059,42066]
===
match
---
string: "__var" [2345,2352]
string: "__var" [2345,2352]
===
match
---
name: dag [37347,37350]
name: dag [37253,37256]
===
match
---
string: "task3" [43004,43011]
string: "task3" [43584,43591]
===
match
---
atom [30025,30064]
atom [29931,29970]
===
match
---
simple_stmt [6843,7194]
simple_stmt [6843,7194]
===
match
---
strings [26098,26212]
strings [26004,26118]
===
match
---
assert_stmt [13497,13536]
assert_stmt [13403,13442]
===
match
---
string: "sla" [4578,4583]
string: "sla" [4578,4583]
===
match
---
operator: , [18201,18202]
operator: , [18107,18108]
===
match
---
simple_stmt [29209,29235]
simple_stmt [29115,29141]
===
match
---
trailer [17839,17872]
trailer [17745,17778]
===
match
---
name: dag [17290,17293]
name: dag [17196,17199]
===
match
---
operator: { [19359,19360]
operator: { [19265,19266]
===
match
---
argument [37111,37126]
argument [37017,37032]
===
match
---
assert_stmt [22461,22517]
assert_stmt [22367,22423]
===
match
---
parameters [43487,43489]
parameters [44240,44242]
===
match
---
name: dag_start_date [16659,16673]
name: dag_start_date [16565,16579]
===
match
---
atom_expr [44918,44966]
atom_expr [45671,45719]
===
match
---
testlist_comp [19240,19256]
testlist_comp [19146,19162]
===
match
---
simple_stmt [42103,42161]
simple_stmt [42009,42067]
===
match
---
comparison [26246,26279]
comparison [26152,26185]
===
match
---
operator: , [22245,22246]
operator: , [22151,22152]
===
match
---
number: 1 [38731,38732]
number: 1 [38637,38638]
===
match
---
operator: { [41324,41325]
operator: { [41230,41231]
===
match
---
simple_stmt [20868,20898]
simple_stmt [20774,20804]
===
match
---
expr_stmt [26845,26877]
expr_stmt [26751,26783]
===
match
---
testlist_comp [42664,42702]
testlist_comp [42570,42608]
===
match
---
argument [17975,17994]
argument [17881,17900]
===
match
---
name: start_date [21388,21398]
name: start_date [21294,21304]
===
match
---
operator: { [29796,29797]
operator: { [29702,29703]
===
match
---
expr_stmt [28300,28383]
expr_stmt [28206,28289]
===
match
---
operator: = [1914,1915]
operator: = [1914,1915]
===
match
---
simple_stmt [28535,28619]
simple_stmt [28441,28525]
===
match
---
operator: , [20566,20567]
operator: , [20472,20473]
===
match
---
atom_expr [6501,6759]
atom_expr [6501,6759]
===
match
---
comparison [20169,20233]
comparison [20075,20139]
===
match
---
name: task [15542,15546]
name: task [15448,15452]
===
match
---
name: name [1798,1802]
name: name [1798,1802]
===
match
---
operator: == [28459,28461]
operator: == [28365,28367]
===
match
---
atom_expr [17520,17598]
atom_expr [17426,17504]
===
match
---
atom_expr [22178,22202]
atom_expr [22084,22108]
===
match
---
string: "__var" [5426,5433]
string: "__var" [5426,5433]
===
match
---
name: SerializedDAG [19036,19049]
name: SerializedDAG [18942,18955]
===
match
---
name: ground_truth_dag [11019,11035]
name: ground_truth_dag [11019,11035]
===
match
---
expr_stmt [22310,22353]
expr_stmt [22216,22259]
===
match
---
string: "Precondition check! If this fails the test won't make sense" [33243,33304]
string: "Precondition check! If this fails the test won't make sense" [33149,33210]
===
match
---
atom [29634,29636]
atom [29540,29542]
===
match
---
name: test_date [24792,24801]
name: test_date [24698,24707]
===
match
---
name: stringified_dags [11893,11909]
name: stringified_dags [11893,11909]
===
match
---
atom [24161,24163]
atom [24067,24069]
===
match
---
dictorsetmaker [29994,30021]
dictorsetmaker [29900,29927]
===
match
---
expr_stmt [42258,42316]
expr_stmt [42164,42222]
===
match
---
simple_stmt [43215,43279]
simple_stmt [43968,44032]
===
match
---
operator: = [7861,7862]
operator: = [7861,7862]
===
match
---
operator: == [32405,32407]
operator: == [32311,32313]
===
match
---
name: target [11447,11453]
name: target [11447,11453]
===
match
---
name: utc [16576,16579]
name: utc [16482,16485]
===
match
---
name: BaseHook [9014,9022]
name: BaseHook [9014,9022]
===
match
---
name: glob [972,976]
name: glob [972,976]
===
match
---
trailer [11061,11071]
trailer [11061,11071]
===
match
---
trailer [10759,10764]
trailer [10759,10764]
===
match
---
trailer [38672,38737]
trailer [38578,38643]
===
match
---
funcdef [18358,19189]
funcdef [18264,19095]
===
match
---
name: FR [20666,20668]
name: FR [20572,20574]
===
match
---
name: datetime [16140,16148]
name: datetime [16046,16054]
===
match
---
name: v [13363,13364]
name: v [13269,13270]
===
match
---
atom [5004,5006]
atom [5004,5006]
===
match
---
return_stmt [5812,5830]
return_stmt [5812,5830]
===
match
---
name: SerializedDAG [25960,25973]
name: SerializedDAG [25866,25879]
===
match
---
simple_stmt [38809,38848]
simple_stmt [38715,38754]
===
match
---
suite [17606,17780]
suite [17512,17686]
===
match
---
operator: , [16227,16228]
operator: , [16133,16134]
===
match
---
if_stmt [43287,43408]
if_stmt [44040,44161]
===
match
---
string: """Make very simple DAG to verify serialization result.""" [5860,5918]
string: """Make very simple DAG to verify serialization result.""" [5860,5918]
===
match
---
trailer [7924,7931]
trailer [7924,7931]
===
match
---
string: 'dag' [10277,10282]
string: 'dag' [10277,10282]
===
match
---
operator: = [43647,43648]
operator: = [44400,44401]
===
match
---
number: 100.0 [3353,3358]
number: 100.0 [3353,3358]
===
match
---
number: 1 [6243,6244]
number: 1 [6243,6244]
===
match
---
trailer [8862,8868]
trailer [8862,8868]
===
match
---
dictorsetmaker [5354,5512]
dictorsetmaker [5354,5512]
===
match
---
trailer [7350,7363]
trailer [7350,7363]
===
match
---
atom [29796,29825]
atom [29702,29731]
===
match
---
param [37669,37673]
param [37575,37579]
===
match
---
or_test [18688,18738]
or_test [18594,18644]
===
match
---
atom [21951,21999]
atom [21857,21905]
===
match
---
trailer [42300,42316]
trailer [42206,42222]
===
match
---
number: 8 [16229,16230]
number: 8 [16135,16136]
===
match
---
expr_stmt [8087,8108]
expr_stmt [8087,8108]
===
match
---
operator: , [41976,41977]
operator: , [41882,41883]
===
match
---
atom [40068,40122]
atom [39974,40028]
===
match
---
atom_expr [13902,13923]
atom_expr [13808,13829]
===
match
---
operator: } [6380,6381]
operator: } [6380,6381]
===
match
---
operator: , [28069,28070]
operator: , [27975,27976]
===
match
---
dictorsetmaker [20541,20593]
dictorsetmaker [20447,20499]
===
match
---
dictorsetmaker [29873,29909]
dictorsetmaker [29779,29815]
===
match
---
trailer [44890,44904]
trailer [45643,45657]
===
match
---
argument [6214,6245]
argument [6214,6245]
===
match
---
simple_stmt [1402,1450]
simple_stmt [1402,1450]
===
match
---
name: airflow [38615,38622]
name: airflow [38521,38528]
===
match
---
atom_expr [38978,39017]
atom_expr [38884,38923]
===
match
---
name: timezone [16448,16456]
name: timezone [16354,16362]
===
match
---
number: 300.0 [2278,2283]
number: 300.0 [2278,2283]
===
match
---
comparison [40923,40973]
comparison [40829,40879]
===
match
---
name: __import__ [43815,43825]
name: __import__ [44568,44578]
===
match
---
assert_stmt [24227,24314]
assert_stmt [24133,24220]
===
match
---
trailer [11438,11446]
trailer [11438,11446]
===
match
---
name: node [38175,38179]
name: node [38081,38085]
===
match
---
trailer [28584,28618]
trailer [28490,28524]
===
match
---
simple_stmt [44146,44222]
simple_stmt [44899,44975]
===
match
---
atom_expr [15596,15621]
atom_expr [15502,15527]
===
match
---
operator: , [34936,34937]
operator: , [34842,34843]
===
match
---
name: datetime [17556,17564]
name: datetime [17462,17470]
===
match
---
simple_stmt [13579,13720]
simple_stmt [13485,13626]
===
match
---
atom_expr [33598,33643]
atom_expr [33504,33549]
===
match
---
import_from [967,988]
import_from [967,988]
===
match
---
param [18398,18411]
param [18304,18317]
===
match
---
atom_expr [7342,7363]
atom_expr [7342,7363]
===
match
---
testlist_comp [42809,42847]
testlist_comp [42715,42753]
===
match
---
atom_expr [22401,22434]
atom_expr [22307,22340]
===
match
---
factor [20466,20468]
factor [20372,20374]
===
match
---
operator: = [19034,19035]
operator: = [18940,18941]
===
match
---
operator: = [37431,37432]
operator: = [37337,37338]
===
match
---
atom_expr [10873,10938]
atom_expr [10873,10938]
===
match
---
operator: , [18515,18516]
operator: , [18421,18422]
===
match
---
string: '#000' [2786,2792]
string: '#000' [2786,2792]
===
match
---
atom_expr [16332,16373]
atom_expr [16238,16279]
===
match
---
name: BaseOperator [16793,16805]
name: BaseOperator [16699,16711]
===
match
---
operator: , [35568,35569]
operator: , [35474,35475]
===
match
---
operator: = [37011,37012]
operator: = [36917,36918]
===
match
---
trailer [39101,39127]
trailer [39007,39033]
===
match
---
name: SerializedBaseOperator [38203,38225]
name: SerializedBaseOperator [38109,38131]
===
match
---
operator: } [2449,2450]
operator: } [2449,2450]
===
match
---
atom_expr [18219,18261]
atom_expr [18125,18167]
===
match
---
name: executor_config_pod [6674,6693]
name: executor_config_pod [6674,6693]
===
match
---
atom [29920,29949]
atom [29826,29855]
===
match
---
name: edgemodifier [38629,38641]
name: edgemodifier [38535,38547]
===
match
---
number: 5 [6056,6057]
number: 5 [6056,6057]
===
match
---
operator: == [29463,29465]
operator: == [29369,29371]
===
match
---
argument [26962,26983]
argument [26868,26889]
===
match
---
name: SerializedDAG [25817,25830]
name: SerializedDAG [25723,25736]
===
match
---
operator: , [16255,16256]
operator: , [16161,16162]
===
match
---
operator: - [20355,20356]
operator: - [20261,20262]
===
match
---
name: dags [7906,7910]
name: dags [7906,7910]
===
match
---
arglist [16488,16520]
arglist [16394,16426]
===
match
---
comparison [43688,43726]
comparison [44441,44479]
===
match
---
trailer [19430,19438]
trailer [19336,19344]
===
match
---
arglist [9976,10041]
arglist [9976,10041]
===
match
---
name: _ [9725,9726]
name: _ [9725,9726]
===
match
---
name: Connection [9076,9086]
name: Connection [9076,9086]
===
match
---
trailer [21535,21542]
trailer [21441,21448]
===
match
---
name: SerializedDAG [16892,16905]
name: SerializedDAG [16798,16811]
===
match
---
name: AttributeError [37762,37776]
name: AttributeError [37668,37682]
===
match
---
arglist [21356,21419]
arglist [21262,21325]
===
match
---
string: 'priority_weight' [35180,35197]
string: 'priority_weight' [35086,35103]
===
match
---
name: group234 [37149,37157]
name: group234 [37055,37063]
===
match
---
atom [21055,21057]
atom [20961,20963]
===
match
---
name: __dict__ [34068,34076]
name: __dict__ [33974,33982]
===
match
---
string: "0 0 * * 0" [19294,19305]
string: "0 0 * * 0" [19200,19211]
===
match
---
name: load_dag_schema_dict [32721,32741]
name: load_dag_schema_dict [32627,32647]
===
match
---
operator: = [38085,38086]
operator: = [37991,37992]
===
match
---
expr_stmt [21690,21758]
expr_stmt [21596,21664]
===
match
---
string: "value_1" [21964,21973]
string: "value_1" [21870,21879]
===
match
---
strings [30536,30673]
strings [30442,30579]
===
match
---
atom [43648,43650]
atom [44401,44403]
===
match
---
simple_stmt [1208,1266]
simple_stmt [1208,1266]
===
match
---
name: dag_folder [8681,8691]
name: dag_folder [8681,8691]
===
match
---
operator: { [3685,3686]
operator: { [3685,3686]
===
match
---
arglist [28350,28382]
arglist [28256,28288]
===
match
---
trailer [23662,23677]
trailer [23568,23583]
===
match
---
name: dag_end_date [18533,18545]
name: dag_end_date [18439,18451]
===
match
---
number: 23 [39713,39715]
number: 23 [39619,39621]
===
match
---
name: airflow [36525,36532]
name: airflow [36431,36438]
===
match
---
simple_stmt [21502,21543]
simple_stmt [21408,21449]
===
match
---
name: template_fields [30476,30491]
name: template_fields [30382,30397]
===
match
---
trailer [28826,28842]
trailer [28732,28748]
===
match
---
arglist [16429,16460]
arglist [16335,16366]
===
match
---
argument [33194,33209]
argument [33100,33115]
===
match
---
atom [42605,42645]
atom [42511,42551]
===
match
---
name: resources [15630,15639]
name: resources [15536,15545]
===
match
---
name: get_extra_links [24524,24539]
name: get_extra_links [24430,24445]
===
match
---
string: "dag" [10790,10795]
string: "dag" [10790,10795]
===
match
---
string: "{{ task.task_id }}" [30427,30447]
string: "{{ task.task_id }}" [30333,30353]
===
match
---
assert_stmt [27086,27144]
assert_stmt [26992,27050]
===
match
---
import_from [1649,1733]
import_from [1649,1733]
===
match
---
testlist_comp [27307,27321]
testlist_comp [27213,27227]
===
match
---
atom_expr [15339,15389]
atom_expr [15245,15295]
===
match
---
expr_stmt [12407,12475]
expr_stmt [12407,12475]
===
match
---
number: 8 [16155,16156]
number: 8 [16061,16062]
===
match
---
classdef [28943,29557]
classdef [28849,29463]
===
match
---
operator: , [43883,43884]
operator: , [44636,44637]
===
match
---
string: "custom_task" [4437,4450]
string: "custom_task" [4437,4450]
===
match
---
operator: } [2956,2957]
operator: } [2956,2957]
===
match
---
operator: { [2140,2141]
operator: { [2140,2141]
===
match
---
argument [30476,30500]
argument [30382,30406]
===
match
---
comparison [21576,21613]
comparison [21482,21519]
===
match
---
atom_expr [10751,10767]
atom_expr [10751,10767]
===
match
---
funcdef [33358,33500]
funcdef [33264,33406]
===
match
---
operator: , [39604,39605]
operator: , [39510,39511]
===
match
---
expr_stmt [9759,9789]
expr_stmt [9759,9789]
===
match
---
operator: , [27014,27015]
operator: , [26920,26921]
===
match
---
name: SerializedDAG [43232,43245]
name: SerializedDAG [43985,43998]
===
match
---
operator: } [30325,30326]
operator: } [30231,30232]
===
match
---
testlist_comp [27008,27022]
testlist_comp [26914,26928]
===
match
---
argument [16112,16131]
argument [16018,16037]
===
match
---
arglist [44505,44511]
arglist [45258,45264]
===
match
---
atom_expr [39659,39716]
atom_expr [39565,39622]
===
match
---
arglist [43919,43968]
arglist [44672,44721]
===
match
---
trailer [5931,6438]
trailer [5931,6438]
===
match
---
simple_stmt [25489,25556]
simple_stmt [25395,25462]
===
match
---
testlist_comp [21927,22000]
testlist_comp [21833,21906]
===
match
---
operator: { [4777,4778]
operator: { [4777,4778]
===
match
---
operator: = [28813,28814]
operator: = [28719,28720]
===
match
---
name: templated_field [32170,32185]
name: templated_field [32076,32091]
===
match
---
decorator [16045,16613]
decorator [15951,16519]
===
match
---
atom_expr [16508,16520]
atom_expr [16414,16426]
===
match
---
operator: = [43618,43619]
operator: = [44371,44372]
===
match
---
atom_expr [18308,18320]
atom_expr [18214,18226]
===
match
---
testlist_comp [21049,21057]
testlist_comp [20955,20963]
===
match
---
name: params [22256,22262]
name: params [22162,22168]
===
match
---
comparison [15882,15916]
comparison [15788,15822]
===
match
---
comparison [42194,42248]
comparison [42100,42154]
===
match
---
string: "hi" [40109,40113]
string: "hi" [40015,40019]
===
match
---
assert_stmt [18881,18939]
assert_stmt [18787,18845]
===
match
---
atom [29660,29662]
atom [29566,29568]
===
match
---
string: "bar" [30221,30226]
string: "bar" [30127,30132]
===
match
---
comparison [38203,38267]
comparison [38109,38173]
===
match
---
name: __class__ [29290,29299]
name: __class__ [29196,29205]
===
match
---
operator: = [36901,36902]
operator: = [36807,36808]
===
match
---
arglist [13109,13119]
arglist [13155,13165]
===
match
---
dictorsetmaker [27781,27850]
dictorsetmaker [27687,27756]
===
match
---
operator: { [8564,8565]
operator: { [8564,8565]
===
match
---
name: call_args_list [44537,44551]
name: call_args_list [45290,45304]
===
match
---
operator: , [44851,44852]
operator: , [45604,45605]
===
match
---
operator: , [3724,3725]
operator: , [3724,3725]
===
match
---
operator: = [11382,11383]
operator: = [11382,11383]
===
match
---
name: dict [43317,43321]
name: dict [44070,44074]
===
match
---
param [43652,43659]
param [44405,44412]
===
match
---
suite [11123,12098]
suite [11123,12098]
===
match
---
atom [16076,16606]
atom [15982,16512]
===
match
---
param [5716,5727]
param [5716,5727]
===
match
---
operator: , [19328,19329]
operator: , [19234,19235]
===
match
---
atom_expr [15182,15217]
atom_expr [15088,15123]
===
match
---
operator: } [6203,6204]
operator: } [6203,6204]
===
match
---
name: base_operator [34054,34067]
name: base_operator [33960,33973]
===
match
---
atom_expr [5436,5463]
atom_expr [5436,5463]
===
match
---
funcdef [41356,42392]
funcdef [41262,42298]
===
match
---
name: expected_n_schedule_interval [20205,20233]
name: expected_n_schedule_interval [20111,20139]
===
match
---
string: 'dummy' [33202,33209]
string: 'dummy' [33108,33115]
===
match
---
operator: @ [42397,42398]
operator: @ [42303,42304]
===
match
---
operator: = [30491,30492]
operator: = [30397,30398]
===
match
---
trailer [25730,25742]
trailer [25636,25648]
===
match
---
atom_expr [11837,11873]
atom_expr [11837,11873]
===
match
---
atom_expr [16360,16372]
atom_expr [16266,16278]
===
match
---
operator: , [17973,17974]
operator: , [17879,17880]
===
match
---
trailer [17319,17335]
trailer [17225,17241]
===
match
---
name: serialize_operator [37903,37921]
name: serialize_operator [37809,37827]
===
match
---
testlist_comp [19359,19438]
testlist_comp [19265,19344]
===
match
---
string: """         Class for testing purpose: allows to create objects with custom attributes in one single statement.         """ [28984,29107]
string: """         Class for testing purpose: allows to create objects with custom attributes in one single statement.         """ [28890,29013]
===
match
---
comp_op [21585,21591]
comp_op [21491,21497]
===
match
---
operator: , [19244,19245]
operator: , [19150,19151]
===
match
---
string: 'simple_task' [18576,18589]
string: 'simple_task' [18482,18495]
===
match
---
simple_stmt [14959,15010]
simple_stmt [14865,14916]
===
match
---
number: 2019 [21408,21412]
number: 2019 [21314,21318]
===
match
---
trailer [44556,44561]
trailer [45309,45314]
===
match
---
trailer [37636,37638]
trailer [37542,37544]
===
match
---
name: test_extra_operator_links_logs_error_for_non_registered_extra_links [24896,24963]
name: test_extra_operator_links_logs_error_for_non_registered_extra_links [24802,24869]
===
match
---
string: "__type" [5297,5305]
string: "__type" [5297,5305]
===
match
---
name: test_date [24540,24549]
name: test_date [24446,24455]
===
match
---
string: "__var" [10930,10937]
string: "__var" [10930,10937]
===
match
---
atom_expr [40746,40823]
atom_expr [40652,40729]
===
match
---
number: 1 [18090,18091]
number: 1 [17996,17997]
===
match
---
suite [16718,17453]
suite [16624,17359]
===
match
---
param [22052,22057]
param [21958,21963]
===
match
---
atom_expr [34010,34036]
atom_expr [33916,33942]
===
match
---
operator: = [16890,16891]
operator: = [16796,16797]
===
match
---
operator: , [43123,43124]
operator: , [43858,43859]
===
match
---
atom_expr [11753,11773]
atom_expr [11753,11773]
===
match
---
simple_stmt [34045,34077]
simple_stmt [33951,33983]
===
match
---
trailer [37602,37604]
trailer [37508,37510]
===
match
---
name: util [44249,44253]
name: util [45002,45006]
===
match
---
string: 'upstream_task_ids' [2884,2903]
string: 'upstream_task_ids' [2884,2903]
===
match
---
trailer [23568,23571]
trailer [23474,23477]
===
match
---
factor [10225,10227]
factor [10225,10227]
===
match
---
operator: , [35473,35474]
operator: , [35379,35380]
===
match
---
trailer [25873,25932]
trailer [25779,25838]
===
match
---
atom [7327,7364]
atom [7327,7364]
===
match
---
if_stmt [40885,41062]
if_stmt [40791,40968]
===
match
---
name: self [12488,12492]
name: self [12488,12492]
===
match
---
simple_stmt [989,1015]
simple_stmt [989,1015]
===
match
---
decorated [41210,42392]
decorated [41116,42298]
===
match
---
name: list [8060,8064]
name: list [8060,8064]
===
match
---
testlist_comp [17954,18114]
testlist_comp [17860,18020]
===
match
---
atom [41255,41309]
atom [41161,41215]
===
match
---
param [43125,43140]
param [43860,43875]
===
match
---
trailer [9086,9460]
trailer [9086,9460]
===
match
---
simple_stmt [20970,20998]
simple_stmt [20876,20904]
===
match
---
operator: == [22691,22693]
operator: == [22597,22599]
===
match
---
assert_stmt [38168,38179]
assert_stmt [38074,38085]
===
match
---
simple_stmt [1558,1649]
simple_stmt [1558,1649]
===
match
---
string: "test2" [42923,42930]
string: "test2" [43503,43510]
===
match
---
trailer [17361,17371]
trailer [17267,17277]
===
match
---
name: serialized [20875,20885]
name: serialized [20781,20791]
===
match
---
trailer [15962,15969]
trailer [15868,15875]
===
match
---
suite [14182,16040]
suite [14088,15946]
===
match
---
operator: { [19717,19718]
operator: { [19623,19624]
===
match
---
operator: { [24112,24113]
operator: { [24018,24019]
===
match
---
operator: } [21118,21119]
operator: } [21024,21025]
===
match
---
name: google_link_from_plugin [24738,24761]
name: google_link_from_plugin [24644,24667]
===
match
---
dictorsetmaker [40070,40114]
dictorsetmaker [39976,40020]
===
match
---
name: module [44918,44924]
name: module [45671,45677]
===
match
---
argument [6470,6491]
argument [6470,6491]
===
match
---
comparison [18709,18738]
comparison [18615,18644]
===
match
---
simple_stmt [40746,40824]
simple_stmt [40652,40730]
===
match
---
operator: , [42624,42625]
operator: , [42530,42531]
===
match
---
operator: = [36988,36989]
operator: = [36894,36895]
===
match
---
operator: } [24163,24164]
operator: } [24069,24070]
===
match
---
string: "edge_info" [5547,5558]
string: "edge_info" [5547,5558]
===
match
---
trailer [13813,13822]
trailer [13719,13728]
===
match
---
string: "bash_command" [32440,32454]
string: "bash_command" [32346,32360]
===
match
---
name: v [11656,11657]
name: v [11656,11657]
===
match
---
simple_stmt [13729,13786]
simple_stmt [13635,13692]
===
match
---
arglist [5941,6432]
arglist [5941,6432]
===
match
---
string: 'search_query' [24407,24421]
string: 'search_query' [24313,24327]
===
match
---
simple_stmt [38196,38268]
simple_stmt [38102,38174]
===
match
---
operator: = [21296,21297]
operator: = [21202,21203]
===
match
---
name: simple_task [17402,17413]
name: simple_task [17308,17319]
===
match
---
operator: = [1755,1756]
operator: = [1755,1756]
===
match
---
operator: , [28359,28360]
operator: , [28265,28266]
===
match
---
operator: , [34304,34305]
operator: , [34210,34211]
===
match
---
string: 'doc_json' [34456,34466]
string: 'doc_json' [34362,34372]
===
match
---
dotted_name [38557,38580]
dotted_name [38463,38486]
===
match
---
string: 'simple_dag' [16744,16756]
string: 'simple_dag' [16650,16662]
===
match
---
name: self [25365,25369]
name: self [25271,25275]
===
match
---
name: other [29550,29555]
name: other [29456,29461]
===
match
---
name: timezone [18248,18256]
name: timezone [18154,18162]
===
match
---
atom_expr [15025,15061]
atom_expr [14931,14967]
===
match
---
trailer [13840,13867]
trailer [13746,13773]
===
match
---
string: 'on_execute_callback' [34868,34889]
string: 'on_execute_callback' [34774,34795]
===
match
---
operator: = [32265,32266]
operator: = [32171,32172]
===
match
---
name: mode [39693,39697]
name: mode [39599,39603]
===
match
---
assert_stmt [21767,21813]
assert_stmt [21673,21719]
===
match
---
name: self [25858,25862]
name: self [25764,25768]
===
match
---
name: split [44499,44504]
name: split [45252,45257]
===
match
---
operator: } [34763,34764]
operator: } [34669,34670]
===
match
---
trailer [32993,33012]
trailer [32899,32918]
===
match
---
operator: , [43637,43638]
operator: , [44390,44391]
===
match
---
dotted_name [39297,39317]
dotted_name [39203,39223]
===
match
---
atom [30295,30326]
atom [30201,30232]
===
match
---
name: task_type [15000,15009]
name: task_type [14906,14915]
===
match
---
name: utc [18257,18260]
name: utc [18163,18166]
===
match
---
operator: } [29329,29330]
operator: } [29235,29236]
===
match
---
string: 'ui_fgcolor' [2772,2784]
string: 'ui_fgcolor' [2772,2784]
===
match
---
name: startswith [44565,44575]
name: startswith [45318,45328]
===
match
---
dotted_name [29563,29583]
dotted_name [29469,29489]
===
match
---
name: test_operator_subclass_changing_base_defaults [33099,33144]
name: test_operator_subclass_changing_base_defaults [33005,33050]
===
match
---
exprlist [8581,8592]
exprlist [8581,8592]
===
match
---
simple_stmt [25404,25436]
simple_stmt [25310,25342]
===
match
---
trailer [42050,42058]
trailer [41956,41964]
===
match
---
string: "tests.test_utils.mock_operators.CustomOpLink" [4778,4824]
string: "tests.test_utils.mock_operators.CustomOpLink" [4778,4824]
===
match
---
name: setUp [8969,8974]
name: setUp [8969,8974]
===
match
---
name: node [38245,38249]
name: node [38151,38155]
===
match
---
arglist [8047,8072]
arglist [8047,8072]
===
match
---
classdef [25184,25436]
classdef [25090,25342]
===
match
---
operator: , [42537,42538]
operator: , [42443,42444]
===
match
---
argument [41849,41896]
argument [41755,41802]
===
match
---
number: 8 [16435,16436]
number: 8 [16341,16342]
===
match
---
operator: , [35200,35201]
operator: , [35106,35107]
===
match
---
expr_stmt [34045,34076]
expr_stmt [33951,33982]
===
match
---
name: keys [33005,33009]
name: keys [32911,32915]
===
match
---
comparison [13612,13647]
comparison [13518,13553]
===
match
---
expr_stmt [38758,38796]
expr_stmt [38664,38702]
===
match
---
string: "month" [20446,20453]
string: "month" [20352,20359]
===
match
---
trailer [37631,37636]
trailer [37537,37542]
===
match
---
atom [1858,1980]
atom [1858,1980]
===
match
---
string: 'echo {{ task.task_id }}' [6573,6598]
string: 'echo {{ task.task_id }}' [6573,6598]
===
match
---
atom_expr [39733,39778]
atom_expr [39639,39684]
===
match
---
operator: , [20406,20407]
operator: , [20312,20313]
===
match
---
operator: , [8057,8058]
operator: , [8057,8058]
===
match
---
assert_stmt [42103,42160]
assert_stmt [42009,42066]
===
match
---
operator: = [39731,39732]
operator: = [39637,39638]
===
match
---
expr_stmt [39152,39232]
expr_stmt [39058,39138]
===
match
---
assert_stmt [15509,15562]
assert_stmt [15415,15468]
===
match
---
number: 0 [22432,22433]
number: 0 [22338,22339]
===
match
---
name: task_id [41946,41953]
name: task_id [41852,41859]
===
match
---
atom_expr [16420,16461]
atom_expr [16326,16367]
===
match
---
simple_stmt [11830,11874]
simple_stmt [11830,11874]
===
match
---
name: relativedelta [20513,20526]
name: relativedelta [20419,20432]
===
match
---
name: dateutil [1035,1043]
name: dateutil [1035,1043]
===
match
---
decorator [20239,20750]
decorator [20145,20656]
===
match
---
trailer [13329,13342]
trailer [13235,13248]
===
match
---
string: "default_pool" [5147,5161]
string: "default_pool" [5147,5161]
===
match
---
trailer [39198,39232]
trailer [39104,39138]
===
match
---
name: dttm [25381,25385]
name: dttm [25287,25291]
===
match
---
string: "task2" [36902,36909]
string: "task2" [36808,36815]
===
match
---
argument [6392,6431]
argument [6392,6431]
===
match
---
string: "@weekly" [19283,19292]
string: "@weekly" [19189,19198]
===
match
---
operator: { [30212,30213]
operator: { [30118,30119]
===
match
---
name: args [44491,44495]
name: args [45244,45248]
===
match
---
operator: , [4480,4481]
operator: , [4480,4481]
===
match
---
name: template_fields [31129,31144]
name: template_fields [31035,31050]
===
match
---
parameters [33820,33826]
parameters [33726,33732]
===
match
---
name: expand [17800,17806]
name: expand [17706,17712]
===
match
---
name: __file__ [19818,19826]
name: __file__ [19724,19732]
===
match
---
name: items [8601,8606]
name: items [8601,8606]
===
match
---
number: 2 [16291,16292]
number: 2 [16197,16198]
===
match
---
simple_stmt [18555,18624]
simple_stmt [18461,18530]
===
match
---
operator: , [1986,1987]
operator: , [1986,1987]
===
match
---
trailer [8600,8606]
trailer [8600,8606]
===
match
---
atom [29993,30022]
atom [29899,29928]
===
match
---
operator: = [25696,25697]
operator: = [25602,25603]
===
match
---
operator: = [6108,6109]
operator: = [6108,6109]
===
match
---
operator: = [9038,9039]
operator: = [9038,9039]
===
match
---
arglist [18081,18112]
arglist [17987,18018]
===
match
---
name: dags [11830,11834]
name: dags [11830,11834]
===
match
---
dictorsetmaker [19648,19973]
dictorsetmaker [19554,19879]
===
match
---
suite [8024,8159]
suite [8024,8159]
===
match
---
name: BaseSensorOperator [39558,39576]
name: BaseSensorOperator [39464,39482]
===
match
---
operator: } [35704,35705]
operator: } [35610,35611]
===
match
---
expr_stmt [10268,10301]
expr_stmt [10268,10301]
===
match
---
name: base_operator [34259,34272]
name: base_operator [34165,34178]
===
match
---
operator: , [3578,3579]
operator: , [3578,3579]
===
match
---
name: expected_task_end_date [18427,18449]
name: expected_task_end_date [18333,18355]
===
match
---
simple_stmt [5734,5775]
simple_stmt [5734,5775]
===
match
---
trailer [5641,5646]
trailer [5641,5646]
===
match
---
name: print [40103,40108]
name: print [40009,40014]
===
match
---
suite [36433,38420]
suite [36339,38326]
===
match
---
atom_expr [28182,28246]
atom_expr [28088,28152]
===
match
---
name: dag_params [33079,33089]
name: dag_params [32985,32995]
===
match
---
suite [26351,28938]
suite [26257,28844]
===
match
---
atom [7484,7559]
atom [7484,7559]
===
match
---
string: 'echo "{{ next_execution_date(dag, execution_date) }}"' [7723,7778]
string: 'echo "{{ next_execution_date(dag, execution_date) }}"' [7723,7778]
===
match
---
name: self [29285,29289]
name: self [29191,29195]
===
match
---
parameters [29500,29513]
parameters [29406,29419]
===
match
---
atom [27306,27322]
atom [27212,27228]
===
match
---
name: set [15065,15068]
name: set [14971,14974]
===
match
---
trailer [34208,34210]
trailer [34114,34116]
===
match
---
atom_expr [18013,18054]
atom_expr [17919,17960]
===
match
---
name: tzinfo [18034,18040]
name: tzinfo [17940,17946]
===
match
---
operator: , [19306,19307]
operator: , [19212,19213]
===
match
---
with_item [5928,6445]
with_item [5928,6445]
===
match
---
argument [17545,17597]
argument [17451,17503]
===
match
---
trailer [22505,22514]
trailer [22411,22420]
===
match
---
name: serialized_schedule_interval [19929,19957]
name: serialized_schedule_interval [19835,19863]
===
match
---
comparison [43327,43353]
comparison [44080,44106]
===
match
---
operator: = [24327,24328]
operator: = [24233,24234]
===
match
---
testlist_comp [40068,40148]
testlist_comp [39974,40054]
===
match
---
operator: == [33076,33078]
operator: == [32982,32984]
===
match
---
operator: , [29658,29659]
operator: , [29564,29565]
===
match
---
atom_expr [9669,9683]
atom_expr [9669,9683]
===
match
---
trailer [8842,8847]
trailer [8842,8847]
===
match
---
name: fields [34045,34051]
name: fields [33951,33957]
===
match
---
atom [21072,21120]
atom [20978,21026]
===
match
---
trailer [11634,11638]
trailer [11634,11638]
===
match
---
name: keys [10760,10764]
name: keys [10760,10764]
===
match
---
string: "simple_task" [27236,27249]
string: "simple_task" [27142,27155]
===
match
---
atom_expr [37361,37406]
atom_expr [37267,37312]
===
match
---
name: path [5613,5617]
name: path [5613,5617]
===
match
---
suite [44905,44967]
suite [45658,45720]
===
match
---
atom_expr [12027,12097]
atom_expr [12027,12097]
===
match
---
operator: - [10225,10226]
operator: - [10225,10226]
===
match
---
name: get_serialized_fields [12795,12816]
name: get_serialized_fields [12795,12816]
===
match
---
name: task_id [22224,22231]
name: task_id [22130,22137]
===
match
---
atom_expr [40658,40737]
atom_expr [40564,40643]
===
match
---
name: simple_task [27208,27219]
name: simple_task [27114,27125]
===
match
---
name: dag_dict [10873,10881]
name: dag_dict [10873,10881]
===
match
---
name: end_date [19154,19162]
name: end_date [19060,19068]
===
match
---
name: SerializedDAG [17296,17309]
name: SerializedDAG [17202,17215]
===
match
---
arglist [28130,28172]
arglist [28036,28078]
===
match
---
arglist [17524,17597]
arglist [17430,17503]
===
match
---
assert_stmt [39242,39290]
assert_stmt [39148,39196]
===
match
---
string: "{{ task.task_id }}" [29835,29855]
string: "{{ task.task_id }}" [29741,29761]
===
match
---
name: dags [8741,8745]
name: dags [8741,8745]
===
match
---
operator: = [11534,11535]
operator: = [11534,11535]
===
match
---
number: 7 [18234,18235]
number: 7 [18140,18141]
===
match
---
operator: , [1947,1948]
operator: , [1947,1948]
===
match
---
name: to_dict [25831,25838]
name: to_dict [25737,25744]
===
match
---
name: task_id [18568,18575]
name: task_id [18474,18481]
===
match
---
name: ROOT_FOLDER [5574,5585]
name: ROOT_FOLDER [5574,5585]
===
match
---
name: timezone [17859,17867]
name: timezone [17765,17773]
===
match
---
string: '.' [44505,44508]
string: '.' [45258,45261]
===
match
---
string: "group34" [36943,36952]
string: "group34" [36849,36858]
===
match
---
name: dag [9832,9835]
name: dag [9832,9835]
===
match
---
name: datetime [22279,22287]
name: datetime [22185,22193]
===
match
---
operator: , [35232,35233]
operator: , [35138,35139]
===
match
---
param [29256,29260]
param [29162,29166]
===
match
---
fstring_string: ( [29309,29310]
fstring_string: ( [29215,29216]
===
match
---
comparison [27093,27144]
comparison [26999,27050]
===
match
---
name: to_dict [9779,9786]
name: to_dict [9779,9786]
===
match
---
string: 'task_4' [42684,42692]
string: 'task_4' [42590,42598]
===
match
---
operator: @ [20239,20240]
operator: @ [20145,20146]
===
match
---
operator: , [34764,34765]
operator: , [34670,34671]
===
match
---
comparison [39830,39844]
comparison [39736,39750]
===
match
---
string: "days" [20458,20464]
string: "days" [20364,20370]
===
match
---
expr_stmt [37041,37075]
expr_stmt [36947,36981]
===
match
---
name: test_deserialization_start_date [16621,16652]
name: test_deserialization_start_date [16527,16558]
===
match
---
arglist [40662,40736]
arglist [40568,40642]
===
match
---
arglist [18288,18320]
arglist [18194,18226]
===
match
---
operator: , [34975,34976]
operator: , [34881,34882]
===
match
---
trailer [17309,17319]
trailer [17215,17225]
===
match
---
atom [19358,19439]
atom [19264,19345]
===
match
---
string: "ClassWithCustomAttributes(" [30536,30564]
string: "ClassWithCustomAttributes(" [30442,30470]
===
match
---
argument [6294,6382]
argument [6294,6382]
===
match
---
operator: { [21934,21935]
operator: { [21840,21841]
===
match
---
atom_expr [11921,11937]
atom_expr [11921,11937]
===
match
---
operator: , [13273,13274]
operator: , [13179,13180]
===
match
---
operator: , [30180,30181]
operator: , [30086,30087]
===
match
---
name: queue [11376,11381]
name: queue [11376,11381]
===
match
---
name: self [39097,39101]
name: self [39003,39007]
===
match
---
string: '"use_ssl": "False"' [9384,9404]
string: '"use_ssl": "False"' [9384,9404]
===
match
---
suite [40259,41205]
suite [40165,41111]
===
match
---
comp_op [17157,17163]
comp_op [17063,17069]
===
match
---
operator: , [14160,14161]
operator: , [14066,14067]
===
match
---
testlist_comp [2662,2687]
testlist_comp [2662,2687]
===
match
---
return_stmt [43798,43897]
return_stmt [44551,44650]
===
match
---
operator: , [7700,7701]
operator: , [7700,7701]
===
match
---
fstring_expr [13673,13685]
fstring_expr [13579,13591]
===
match
---
name: FR [1065,1067]
name: FR [1065,1067]
===
match
---
name: nested1 [30767,30774]
name: nested1 [30673,30680]
===
match
---
parameters [19503,19611]
parameters [19409,19517]
===
match
---
expr_stmt [11625,11640]
expr_stmt [11625,11640]
===
match
---
name: level [43885,43890]
name: level [44638,44643]
===
match
---
name: serialized_task [15947,15962]
name: serialized_task [15853,15868]
===
match
---
parameters [40211,40258]
parameters [40117,40164]
===
match
---
trailer [22569,22585]
trailer [22475,22491]
===
match
---
name: name [28865,28869]
name: name [28771,28775]
===
match
---
operator: = [34008,34009]
operator: = [33914,33915]
===
match
---
operator: = [31076,31077]
operator: = [30982,30983]
===
match
---
name: do_xcom_push [33472,33484]
name: do_xcom_push [33378,33390]
===
match
---
string: "No module named 'kubernetes'" [43758,43788]
string: "No module named 'kubernetes'" [44511,44541]
===
match
---
name: SerializedBaseOperator [38087,38109]
name: SerializedBaseOperator [37993,38015]
===
match
---
operator: { [20346,20347]
operator: { [20252,20253]
===
match
---
atom_expr [15029,15060]
atom_expr [14935,14966]
===
match
---
atom [20540,20594]
atom [20446,20500]
===
match
---
funcdef [22021,22726]
funcdef [21927,22632]
===
match
---
name: parameterized [40024,40037]
name: parameterized [39930,39943]
===
match
---
import_as_names [1693,1733]
import_as_names [1693,1733]
===
match
---
name: from_dict [20064,20073]
name: from_dict [19970,19979]
===
match
---
param [8681,8691]
param [8681,8691]
===
match
---
name: serialized_dag [14042,14056]
name: serialized_dag [13948,13962]
===
match
---
simple_stmt [32972,33028]
simple_stmt [32878,32934]
===
match
---
expr_stmt [8741,8772]
expr_stmt [8741,8772]
===
match
---
trailer [39280,39290]
trailer [39186,39196]
===
match
---
operator: = [26988,26989]
operator: = [26894,26895]
===
match
---
operator: , [22061,22062]
operator: , [21967,21968]
===
match
---
trailer [14981,14991]
trailer [14887,14897]
===
match
---
arglist [18470,18545]
arglist [18376,18451]
===
match
---
expr_stmt [37290,37352]
expr_stmt [37196,37258]
===
match
---
trailer [5617,5622]
trailer [5617,5622]
===
match
---
number: 2019 [18511,18515]
number: 2019 [18417,18421]
===
match
---
operator: , [6748,6749]
operator: , [6748,6749]
===
match
---
trailer [12391,12393]
trailer [12391,12393]
===
match
---
name: k [13700,13701]
name: k [13606,13607]
===
match
---
dictorsetmaker [29881,29908]
dictorsetmaker [29787,29814]
===
match
---
simple_stmt [37416,37497]
simple_stmt [37322,37403]
===
match
---
string: "tasks" [24058,24065]
string: "tasks" [23964,23971]
===
match
---
fstring_expr [7621,7627]
fstring_expr [7621,7627]
===
match
---
argument [23422,23429]
argument [23328,23335]
===
match
---
name: parameterized [21004,21017]
name: parameterized [20910,20923]
===
match
---
simple_stmt [33160,33305]
simple_stmt [33066,33211]
===
match
---
param [14131,14136]
param [14037,14042]
===
match
---
trailer [25774,25790]
trailer [25680,25696]
===
match
---
trailer [32029,32097]
trailer [31935,32003]
===
match
---
string: "default_args" [2071,2085]
string: "default_args" [2071,2085]
===
match
---
string: 'json' [3717,3723]
string: 'json' [3717,3723]
===
match
---
parameters [29255,29261]
parameters [29161,29167]
===
match
---
name: start_date [16758,16768]
name: start_date [16664,16674]
===
match
---
trailer [33072,33074]
trailer [32978,32980]
===
match
---
operator: = [26902,26903]
operator: = [26808,26809]
===
match
---
name: from_dict [17310,17319]
name: from_dict [17216,17225]
===
match
---
string: "param_1" [21953,21962]
string: "param_1" [21859,21868]
===
match
---
import_from [1083,1126]
import_from [1083,1126]
===
match
---
name: serialized_dag [24036,24050]
name: serialized_dag [23942,23956]
===
match
---
expr_stmt [23282,23314]
expr_stmt [23188,23220]
===
match
---
trailer [37228,37233]
trailer [37134,37139]
===
match
---
string: 'depends_on_past' [34359,34376]
string: 'depends_on_past' [34265,34282]
===
match
---
operator: , [17922,17923]
operator: , [17828,17829]
===
match
---
testlist_comp [29796,29856]
testlist_comp [29702,29762]
===
match
---
string: "task2" [42914,42921]
string: "task2" [43494,43501]
===
match
---
name: key [29223,29226]
name: key [29129,29132]
===
match
---
trailer [12794,12816]
trailer [12794,12816]
===
match
---
string: 'simple_task' [40767,40780]
string: 'simple_task' [40673,40686]
===
match
---
name: dag [37402,37405]
name: dag [37308,37311]
===
match
---
atom_expr [20375,20406]
atom_expr [20281,20312]
===
match
---
name: __str__ [29248,29255]
name: __str__ [29154,29161]
===
match
---
trailer [16487,16521]
trailer [16393,16427]
===
match
---
argument [24360,24384]
argument [24266,24290]
===
match
---
name: key [29163,29166]
name: key [29069,29072]
===
match
---
operator: , [17543,17544]
operator: , [17449,17450]
===
match
---
arglist [16806,16864]
arglist [16712,16770]
===
match
---
funcdef [7199,7307]
funcdef [7199,7307]
===
match
---
operator: = [14452,14453]
operator: = [14358,14359]
===
match
---
operator: = [10295,10296]
operator: = [10295,10296]
===
match
---
operator: = [31038,31039]
operator: = [30944,30945]
===
match
---
name: expand [19209,19215]
name: expand [19115,19121]
===
match
---
operator: , [35289,35290]
operator: , [35195,35196]
===
match
---
name: Label [38649,38654]
name: Label [38555,38560]
===
match
---
number: 8 [18517,18518]
number: 8 [18423,18424]
===
match
---
atom_expr [44804,44851]
atom_expr [45557,45604]
===
match
---
trailer [10710,10768]
trailer [10710,10768]
===
match
---
trailer [1797,1813]
trailer [1797,1813]
===
match
---
trailer [25689,25743]
trailer [25595,25649]
===
match
---
string: 'task_4' [42781,42789]
string: 'task_4' [42687,42695]
===
match
---
trailer [37110,37127]
trailer [37016,37033]
===
match
---
string: 'task_5' [42471,42479]
string: 'task_5' [42377,42385]
===
match
---
string: "__type" [19360,19368]
string: "__type" [19266,19274]
===
match
---
name: multiprocessing [11423,11438]
name: multiprocessing [11423,11438]
===
match
---
name: dag_schema [32994,33004]
name: dag_schema [32900,32910]
===
match
---
argument [43850,43864]
argument [44603,44617]
===
match
---
argument [16441,16460]
argument [16347,16366]
===
match
---
operator: == [10229,10231]
operator: == [10229,10231]
===
match
---
operator: = [8096,8097]
operator: = [8096,8097]
===
match
---
operator: , [14938,14939]
operator: , [14844,14845]
===
match
---
assert_stmt [28879,28937]
assert_stmt [28785,28843]
===
match
---
dictorsetmaker [20310,20358]
dictorsetmaker [20216,20264]
===
match
---
name: validate_schema [9816,9831]
name: validate_schema [9816,9831]
===
match
---
number: 0 [26046,26047]
number: 0 [25952,25953]
===
match
---
name: collect_dags [9669,9681]
name: collect_dags [9669,9681]
===
match
---
name: test_deserialization_across_process [11081,11116]
name: test_deserialization_across_process [11081,11116]
===
match
---
name: self [9559,9563]
name: self [9559,9563]
===
match
---
arglist [18228,18260]
arglist [18134,18166]
===
match
---
name: serialized_op [33734,33747]
name: serialized_op [33640,33653]
===
match
---
string: 'https://console.cloud.google.com/bigquery?j=dummy_value_2' [28634,28693]
string: 'https://console.cloud.google.com/bigquery?j=dummy_value_2' [28540,28599]
===
match
---
operator: = [23406,23407]
operator: = [23312,23313]
===
match
---
string: "test3" [42905,42912]
string: "test3" [43485,43492]
===
match
---
name: k8s [1781,1784]
name: k8s [1781,1784]
===
match
---
name: utc [17868,17871]
name: utc [17774,17777]
===
match
---
name: serialized_task [15882,15897]
name: serialized_task [15788,15803]
===
match
---
operator: = [17639,17640]
operator: = [17545,17546]
===
match
---
atom [42428,43047]
atom [42334,43782]
===
match
---
name: json_dag [10268,10276]
name: json_dag [10268,10276]
===
match
---
testlist_comp [30084,30164]
testlist_comp [29990,30070]
===
match
---
name: SerializedDAG [39037,39050]
name: SerializedDAG [38943,38956]
===
match
---
comparison [10997,11071]
comparison [10997,11071]
===
match
---
number: 300 [35331,35334]
number: 300 [35237,35240]
===
match
---
string: "base" [1893,1899]
string: "base" [1893,1899]
===
match
---
operator: , [43608,43609]
operator: , [44361,44362]
===
match
---
operator: , [4957,4958]
operator: , [4957,4958]
===
match
---
trailer [15028,15061]
trailer [14934,14967]
===
match
---
operator: = [32148,32149]
operator: = [32054,32055]
===
match
---
operator: , [1707,1708]
operator: , [1707,1708]
===
match
---
expr_stmt [12773,13038]
expr_stmt [12773,13038]
===
match
---
atom_expr [39199,39231]
atom_expr [39105,39137]
===
match
---
argument [6560,6598]
argument [6560,6598]
===
match
---
trailer [36659,36671]
trailer [36565,36577]
===
match
---
name: serialized_dag [18987,19001]
name: serialized_dag [18893,18907]
===
match
---
atom_expr [36685,36748]
atom_expr [36591,36654]
===
match
---
trailer [29189,29191]
trailer [29095,29097]
===
match
---
operator: } [15409,15410]
operator: } [15315,15316]
===
match
---
argument [18241,18260]
argument [18147,18166]
===
match
---
operator: == [43679,43681]
operator: == [44432,44434]
===
match
---
operator: , [3867,3868]
operator: , [3867,3868]
===
match
---
operator: = [32338,32339]
operator: = [32244,32245]
===
match
---
name: test_date [23365,23374]
name: test_date [23271,23280]
===
match
---
simple_stmt [12407,12476]
simple_stmt [12407,12476]
===
match
---
atom_expr [8446,8474]
atom_expr [8446,8474]
===
match
---
assert_stmt [37556,37638]
assert_stmt [37462,37544]
===
match
---
fstring_string:  does not match [13297,13312]
fstring_string:  does not match [13203,13218]
===
match
---
argument [28130,28146]
argument [28036,28052]
===
match
---
name: fields_to_check [14436,14451]
name: fields_to_check [14342,14357]
===
match
---
operator: { [15426,15427]
operator: { [15332,15333]
===
match
---
param [22782,22786]
param [22688,22692]
===
match
---
operator: = [23364,23365]
operator: = [23270,23271]
===
match
---
comparison [14966,15009]
comparison [14872,14915]
===
match
---
string: "dag" [22416,22421]
string: "dag" [22322,22327]
===
match
---
testlist_comp [42895,43022]
testlist_comp [43475,43602]
===
match
---
name: start_date [38705,38715]
name: start_date [38611,38621]
===
match
---
name: mock__import__ [43589,43603]
name: mock__import__ [44342,44356]
===
match
---
trailer [38991,39007]
trailer [38897,38913]
===
match
---
trailer [10692,10701]
trailer [10692,10701]
===
match
---
trailer [5670,5677]
trailer [5670,5677]
===
match
---
atom [29655,29663]
atom [29561,29569]
===
match
---
operator: , [44781,44782]
operator: , [45534,45535]
===
match
---
name: x [41287,41288]
name: x [41193,41194]
===
match
---
trailer [18936,18939]
trailer [18842,18845]
===
match
---
string: 'tests.test_utils.mock_operators.CustomBaseIndexOpLink' [27696,27751]
string: 'tests.test_utils.mock_operators.CustomBaseIndexOpLink' [27602,27657]
===
match
---
comparison [23693,23739]
comparison [23599,23645]
===
match
---
param [20798,20806]
param [20704,20712]
===
match
---
atom_expr [5928,6438]
atom_expr [5928,6438]
===
match
---
dictorsetmaker [2071,5563]
dictorsetmaker [2071,5563]
===
match
---
name: dag [18672,18675]
name: dag [18578,18581]
===
match
---
operator: , [42479,42480]
operator: , [42385,42386]
===
match
---
trailer [17962,17995]
trailer [17868,17901]
===
match
---
operator: , [24801,24802]
operator: , [24707,24708]
===
match
---
string: "retry_delay" [6023,6036]
string: "retry_delay" [6023,6036]
===
match
---
name: serialized_dag [40952,40966]
name: serialized_dag [40858,40872]
===
match
---
atom_expr [15412,15424]
atom_expr [15318,15330]
===
match
---
atom_expr [13326,13342]
atom_expr [13232,13248]
===
match
---
name: relativedelta [20644,20657]
name: relativedelta [20550,20563]
===
match
---
string: 'bash_command' [3686,3700]
string: 'bash_command' [3686,3700]
===
match
---
name: test_dag_on_failure_callback_roundtrip [41360,41398]
name: test_dag_on_failure_callback_roundtrip [41266,41304]
===
match
---
trailer [33559,33572]
trailer [33465,33478]
===
match
---
string: 'start_date' [35455,35467]
string: 'start_date' [35361,35373]
===
match
---
operator: = [7646,7647]
operator: = [7646,7647]
===
match
---
simple_stmt [32196,32240]
simple_stmt [32102,32146]
===
match
---
atom_expr [37433,37496]
atom_expr [37339,37402]
===
match
---
atom [30125,30164]
atom [30031,30070]
===
match
---
number: 0 [43708,43709]
number: 0 [44461,44462]
===
match
---
string: 'task_4' [42829,42837]
string: 'task_2' [42735,42743]
===
match
---
dictorsetmaker [2525,2947]
dictorsetmaker [2525,2947]
===
match
---
fstring_string: . [15425,15426]
fstring_string: . [15331,15332]
===
match
---
assert_stmt [24578,24665]
assert_stmt [24484,24571]
===
match
---
funcdef [8965,9531]
funcdef [8965,9531]
===
match
---
with_stmt [5923,6795]
with_stmt [5923,6795]
===
match
---
name: validate_schema [37256,37271]
name: validate_schema [37162,37177]
===
match
---
atom [31077,31085]
atom [30983,30991]
===
match
---
name: _ [36876,36877]
name: _ [36782,36783]
===
match
---
name: deserialize_operator [33691,33711]
name: deserialize_operator [33597,33617]
===
match
---
string: 'k8s.V1Pod' [44770,44781]
string: 'k8s.V1Pod' [45523,45534]
===
match
---
parameters [39437,39469]
parameters [39343,39375]
===
match
---
import_name [867,889]
import_name [867,889]
===
match
---
trailer [38128,38151]
trailer [38034,38057]
===
match
---
trailer [37902,37921]
trailer [37808,37827]
===
match
---
operator: , [20595,20596]
operator: , [20501,20502]
===
match
---
name: json_dag [10187,10195]
name: json_dag [10187,10195]
===
match
---
trailer [1784,1797]
trailer [1784,1797]
===
match
---
funcdef [25623,25672]
funcdef [25529,25578]
===
match
---
simple_stmt [21569,21614]
simple_stmt [21475,21520]
===
match
---
name: isinstance [14340,14350]
name: isinstance [14246,14256]
===
match
---
number: 8 [17969,17970]
number: 8 [17875,17876]
===
match
---
operator: , [6193,6194]
operator: , [6193,6194]
===
match
---
string: "my-name" [1803,1812]
string: "my-name" [1803,1812]
===
match
---
trailer [13750,13759]
trailer [13656,13665]
===
match
---
name: nested2 [30948,30955]
name: nested2 [30854,30861]
===
match
---
dotted_name [36583,36607]
dotted_name [36489,36513]
===
match
---
trailer [19411,19419]
trailer [19317,19325]
===
match
---
operator: = [20048,20049]
operator: = [19954,19955]
===
match
---
trailer [8792,8799]
trailer [8792,8799]
===
match
---
operator: , [29781,29782]
operator: , [29687,29688]
===
match
---
name: datetime [16479,16487]
name: datetime [16385,16393]
===
match
---
operator: , [34729,34730]
operator: , [34635,34636]
===
match
---
argument [25711,25742]
argument [25617,25648]
===
match
---
name: other [29507,29512]
name: other [29413,29418]
===
match
---
name: collect_dags [8748,8760]
name: collect_dags [8748,8760]
===
match
---
string: "_access_control" [10797,10814]
string: "_access_control" [10797,10814]
===
match
---
operator: , [15327,15328]
operator: , [15233,15234]
===
match
---
name: RuntimeError [44891,44903]
name: RuntimeError [45644,45656]
===
match
---
operator: , [1316,1317]
operator: , [1316,1317]
===
match
---
simple_stmt [12027,12098]
simple_stmt [12027,12098]
===
match
---
name: serialized_dags [9976,9991]
name: serialized_dags [9976,9991]
===
match
---
operator: = [8144,8145]
operator: = [8144,8145]
===
match
---
decorator [29562,31621]
decorator [29468,31527]
===
match
---
trailer [27633,27640]
trailer [27539,27546]
===
match
---
operator: , [20672,20673]
operator: , [20578,20579]
===
match
---
atom_expr [5465,5492]
atom_expr [5465,5492]
===
match
---
for_stmt [11983,12098]
for_stmt [11983,12098]
===
match
---
operator: , [10005,10006]
operator: , [10005,10006]
===
match
---
name: get_connection [9023,9037]
name: get_connection [9023,9037]
===
match
---
name: executor_config [6641,6656]
name: executor_config [6641,6656]
===
match
---
trailer [13384,13390]
trailer [13290,13296]
===
match
---
number: 1 [17972,17973]
number: 1 [17878,17879]
===
match
---
name: serialized_dag [27034,27048]
name: serialized_dag [26940,26954]
===
match
---
trailer [32758,32765]
trailer [32664,32671]
===
match
---
operator: , [18085,18086]
operator: , [17991,17992]
===
match
---
number: 1 [20356,20357]
number: 1 [20262,20263]
===
match
---
atom [2087,2450]
atom [2087,2450]
===
match
---
trailer [39226,39231]
trailer [39132,39137]
===
match
---
operator: , [2439,2440]
operator: , [2439,2440]
===
match
---
number: 2019 [16149,16153]
number: 2019 [16055,16059]
===
match
---
atom [19717,19748]
atom [19623,19654]
===
match
---
operator: , [42863,42864]
operator: , [42769,42770]
===
match
---
simple_stmt [9849,9881]
simple_stmt [9849,9881]
===
match
---
operator: { [30093,30094]
operator: { [29999,30000]
===
match
---
trailer [30981,31107]
trailer [30887,31013]
===
match
---
string: "__type" [2386,2394]
string: "__type" [2386,2394]
===
match
---
param [41287,41288]
param [41193,41194]
===
match
---
name: serialized_dag [41114,41128]
name: serialized_dag [41020,41034]
===
match
---
funcdef [16617,17453]
funcdef [16523,17359]
===
match
---
operator: , [3248,3249]
operator: , [3248,3249]
===
match
---
expr_stmt [9662,9683]
expr_stmt [9662,9683]
===
match
---
arglist [30826,30904]
arglist [30732,30810]
===
match
---
suite [15496,15563]
suite [15402,15469]
===
match
---
string: 'weight_rule' [35667,35680]
string: 'weight_rule' [35573,35586]
===
match
---
name: tzinfo [16560,16566]
name: tzinfo [16466,16472]
===
match
---
operator: , [16657,16658]
operator: , [16563,16564]
===
match
---
name: SerializedDAG [20923,20936]
name: SerializedDAG [20829,20842]
===
match
---
name: patterns [8087,8095]
name: patterns [8087,8095]
===
match
---
operator: { [30034,30035]
operator: { [29940,29941]
===
match
---
name: group34 [37170,37177]
name: group34 [37076,37083]
===
match
---
name: BaseOperator [14413,14425]
name: BaseOperator [14319,14331]
===
match
---
arglist [15947,15974]
arglist [15853,15880]
===
match
---
operator: { [30025,30026]
operator: { [29931,29932]
===
match
---
name: dag [36752,36755]
name: dag [36658,36661]
===
match
---
trailer [28184,28194]
trailer [28090,28100]
===
match
---
name: get_link [25356,25364]
name: get_link [25262,25270]
===
match
---
operator: , [2182,2183]
operator: , [2182,2183]
===
match
---
name: DummyOperator [38588,38601]
name: DummyOperator [38494,38507]
===
match
---
param [12581,12596]
param [12581,12596]
===
match
---
string: """Loads DAGs from a module for test.""" [5734,5774]
string: """Loads DAGs from a module for test.""" [5734,5774]
===
match
---
number: 8 [40817,40818]
number: 8 [40723,40724]
===
match
---
name: dag_id [17524,17530]
name: dag_id [17430,17436]
===
match
---
operator: , [35016,35017]
operator: , [34922,34923]
===
match
---
trailer [28864,28869]
trailer [28770,28775]
===
match
---
operator: { [7913,7914]
operator: { [7913,7914]
===
match
---
operator: { [7327,7328]
operator: { [7327,7328]
===
match
---
atom [26080,26226]
atom [25986,26132]
===
match
---
name: other [29466,29471]
name: other [29372,29377]
===
match
---
name: queue [8811,8816]
name: queue [8811,8816]
===
match
---
name: custom_inbuilt_link [28300,28319]
name: custom_inbuilt_link [28206,28225]
===
match
---
trailer [44536,44551]
trailer [45289,45304]
===
match
---
operator: = [40656,40657]
operator: = [40562,40563]
===
match
---
dictorsetmaker [29985,30022]
dictorsetmaker [29891,29928]
===
match
---
number: 300.0 [4513,4518]
number: 300.0 [4513,4518]
===
match
---
name: task_id [13799,13806]
name: task_id [13705,13712]
===
match
---
operator: == [39274,39276]
operator: == [39180,39182]
===
match
---
string: 'owner' [35057,35064]
string: 'owner' [34963,34970]
===
match
---
name: log_output [25936,25946]
name: log_output [25842,25852]
===
match
---
operator: = [6572,6573]
operator: = [6572,6573]
===
match
---
simple_stmt [9947,10043]
simple_stmt [9947,10043]
===
match
---
dictorsetmaker [41257,41301]
dictorsetmaker [41163,41207]
===
match
---
string: "dag" [10882,10887]
string: "dag" [10882,10887]
===
match
---
operator: , [16439,16440]
operator: , [16345,16346]
===
match
---
operator: , [16499,16500]
operator: , [16405,16406]
===
match
---
suite [37777,38291]
suite [37683,38197]
===
match
---
simple_stmt [43495,43580]
simple_stmt [44248,44333]
===
match
---
name: task_id [33194,33201]
name: task_id [33100,33107]
===
match
---
parameters [14121,14181]
parameters [14027,14087]
===
match
---
atom [7913,7915]
atom [7913,7915]
===
match
---
trailer [33711,33717]
trailer [33617,33623]
===
match
---
atom_expr [8897,8914]
atom_expr [8897,8914]
===
match
---
name: getattr [13230,13237]
name: getattr [13096,13103]
===
match
---
number: 0 [35328,35329]
number: 0 [35234,35235]
===
match
---
operator: } [13288,13289]
operator: } [13194,13195]
===
match
---
string: "task_id" [3160,3169]
string: "task_id" [3160,3169]
===
match
---
operator: , [18176,18177]
operator: , [18082,18083]
===
match
---
comparison [28399,28481]
comparison [28305,28387]
===
match
---
name: expect_custom_deps [39450,39468]
name: expect_custom_deps [39356,39374]
===
match
---
atom_expr [37880,37949]
atom_expr [37786,37855]
===
match
---
operator: == [24095,24097]
operator: == [24001,24003]
===
match
---
trailer [11806,11813]
trailer [11806,11813]
===
match
---
name: Label [38869,38874]
name: Label [38775,38780]
===
match
---
operator: , [4733,4734]
operator: , [4733,4734]
===
match
---
atom [29735,29781]
atom [29641,29687]
===
match
---
string: 'bash_task' [2632,2643]
string: 'bash_task' [2632,2643]
===
match
---
operator: = [24762,24763]
operator: = [24668,24669]
===
match
---
suite [15862,15976]
suite [15768,15882]
===
match
---
argument [7464,7559]
argument [7464,7559]
===
match
---
operator: , [16132,16133]
operator: , [16038,16039]
===
match
---
operator: } [5561,5562]
operator: } [5561,5562]
===
match
---
string: "{{ task.task_id }}" [29737,29757]
string: "{{ task.task_id }}" [29643,29663]
===
match
---
operator: , [32092,32093]
operator: , [31998,31999]
===
match
---
operator: , [4299,4300]
operator: , [4299,4300]
===
match
---
operator: , [40139,40140]
operator: , [40045,40046]
===
match
---
operator: = [8562,8563]
operator: = [8562,8563]
===
match
---
string: "depends_on_past" [2158,2175]
string: "depends_on_past" [2158,2175]
===
match
---
string: "{{ task.task_id }}" [30831,30851]
string: "{{ task.task_id }}" [30737,30757]
===
match
---
atom_expr [16448,16460]
atom_expr [16354,16366]
===
match
---
name: path [5591,5595]
name: path [5591,5595]
===
match
---
operator: = [43632,43633]
operator: = [44385,44386]
===
match
---
name: serialized_task [14145,14160]
name: serialized_task [14051,14066]
===
match
---
string: "timedelta" [2396,2407]
string: "timedelta" [2396,2407]
===
match
---
name: dag [15399,15402]
name: dag [15305,15308]
===
match
---
arglist [16149,16180]
arglist [16055,16086]
===
match
---
name: name [25322,25326]
name: name [25228,25232]
===
match
---
name: self [33467,33471]
name: self [33373,33377]
===
match
---
string: "__type" [43327,43335]
string: "__type" [44080,44088]
===
match
---
trailer [9743,9745]
trailer [9743,9745]
===
match
---
operator: } [2438,2439]
operator: } [2438,2439]
===
match
---
name: permissions [6353,6364]
name: permissions [6353,6364]
===
match
---
trailer [37314,37324]
trailer [37220,37230]
===
match
---
name: serialized_dags [9849,9864]
name: serialized_dags [9849,9864]
===
match
---
atom [30084,30123]
atom [29990,30029]
===
match
---
operator: = [22544,22545]
operator: = [22450,22451]
===
match
---
name: str [29311,29314]
name: str [29217,29220]
===
match
---
string: """         Test that params work both on Serialized DAGs & Tasks         """ [21206,21283]
string: """         Test that params work both on Serialized DAGs & Tasks         """ [21112,21189]
===
match
---
string: "start_date" [2460,2472]
string: "start_date" [2460,2472]
===
match
---
atom_expr [33043,33075]
atom_expr [32949,32981]
===
match
---
dotted_name [16046,16066]
dotted_name [15952,15972]
===
match
---
operator: = [21308,21309]
operator: = [21214,21215]
===
match
---
dictorsetmaker [4778,4828]
dictorsetmaker [4778,4828]
===
match
---
operator: = [6477,6478]
operator: = [6477,6478]
===
match
---
name: stringified_dags [12058,12074]
name: stringified_dags [12058,12074]
===
match
---
atom [3128,5227]
atom [3128,5227]
===
match
---
operator: , [35383,35384]
operator: , [35289,35290]
===
match
---
string: '__type' [4143,4151]
string: '__type' [4143,4151]
===
match
---
operator: = [17907,17908]
operator: = [17813,17814]
===
match
---
parameters [25634,25649]
parameters [25540,25555]
===
match
---
name: default_args [5970,5982]
name: default_args [5970,5982]
===
match
---
atom_expr [16892,16918]
atom_expr [16798,16824]
===
match
---
string: "dag" [24051,24056]
string: "dag" [23957,23962]
===
match
---
operator: , [30123,30124]
operator: , [30029,30030]
===
match
---
name: params [22719,22725]
name: params [22625,22631]
===
match
---
expr_stmt [24324,24385]
expr_stmt [24230,24291]
===
match
---
suite [8981,9531]
suite [8981,9531]
===
match
---
operator: , [34442,34443]
operator: , [34348,34349]
===
match
---
operator: , [34660,34661]
operator: , [34566,34567]
===
match
---
operator: , [21321,21322]
operator: , [21227,21228]
===
match
---
name: deserialized_dag [32340,32356]
name: deserialized_dag [32246,32262]
===
match
---
operator: = [21363,21364]
operator: = [21269,21270]
===
match
---
if_stmt [39788,39897]
if_stmt [39694,39803]
===
match
---
operator: } [7914,7915]
operator: } [7914,7915]
===
match
---
string: "test_edge_info_serialization" [38673,38703]
string: "test_edge_info_serialization" [38579,38609]
===
match
---
trailer [15346,15389]
trailer [15252,15295]
===
match
---
name: BaseSensorOperator [39512,39530]
name: BaseSensorOperator [39418,39436]
===
match
---
assert_stmt [33550,33581]
assert_stmt [33456,33487]
===
match
---
trailer [17194,17197]
trailer [17100,17103]
===
match
---
operator: , [18032,18033]
operator: , [17938,17939]
===
match
---
dictorsetmaker [44489,44587]
dictorsetmaker [45242,45340]
===
match
---
name: make_example_dags [8446,8463]
name: make_example_dags [8446,8463]
===
match
---
string: "__var" [20702,20709]
string: "__var" [20608,20615]
===
match
---
trailer [37476,37490]
trailer [37382,37396]
===
match
---
simple_stmt [12773,13039]
simple_stmt [12773,13039]
===
match
---
trailer [33690,33711]
trailer [33596,33617]
===
match
---
testlist_comp [19321,19343]
testlist_comp [19227,19249]
===
match
---
dotted_name [1035,1057]
dotted_name [1035,1057]
===
match
---
trailer [41054,41061]
trailer [40960,40967]
===
match
---
atom_expr [36651,36671]
atom_expr [36557,36577]
===
match
---
atom_expr [17556,17597]
atom_expr [17462,17503]
===
match
---
comparison [10187,10259]
comparison [10187,10259]
===
match
---
name: get_task [13883,13891]
name: get_task [13789,13797]
===
match
---
number: 1 [26875,26876]
number: 1 [26781,26782]
===
match
---
trailer [26865,26877]
trailer [26771,26783]
===
match
---
name: start_date [41978,41988]
name: start_date [41884,41894]
===
match
---
trailer [39944,39965]
trailer [39850,39871]
===
match
---
operator: , [25379,25380]
operator: , [25285,25286]
===
match
---
operator: , [2048,2049]
operator: , [2048,2049]
===
match
---
name: timezone [13772,13780]
name: timezone [13678,13686]
===
match
---
arglist [23701,23728]
arglist [23607,23634]
===
match
---
name: dag [41973,41976]
name: dag [41879,41882]
===
match
---
atom_expr [37463,37495]
atom_expr [37369,37401]
===
match
---
atom [2061,5569]
atom [2061,5569]
===
match
---
operator: = [7441,7442]
operator: = [7441,7442]
===
match
---
operator: , [42718,42719]
operator: , [42624,42625]
===
match
---
name: extra_links [27938,27949]
name: extra_links [27844,27855]
===
match
---
operator: { [27954,27955]
operator: { [27860,27861]
===
match
---
import_as_names [1371,1401]
import_as_names [1371,1401]
===
match
---
name: SerializedBaseOperator [1611,1633]
name: SerializedBaseOperator [1611,1633]
===
match
---
param [18412,18426]
param [18318,18332]
===
match
---
trailer [24791,24819]
trailer [24697,24725]
===
match
---
string: "retries" [4468,4477]
string: "retries" [4468,4477]
===
match
---
atom [39327,39401]
atom [39233,39307]
===
match
---
name: c [44555,44556]
name: c [45308,45309]
===
match
---
atom_expr [43908,43969]
atom_expr [44661,44722]
===
match
---
string: 'task_2' [42529,42537]
string: 'task_5' [42435,42443]
===
match
---
decorator [42397,43054]
decorator [42303,43789]
===
match
---
operator: = [33485,33486]
operator: = [33391,33392]
===
match
---
operator: , [29663,29664]
operator: , [29569,29570]
===
match
---
return_stmt [29374,29395]
return_stmt [29280,29301]
===
match
---
string: "bar" [29881,29886]
string: "bar" [29787,29792]
===
match
---
atom_expr [38716,38736]
atom_expr [38622,38642]
===
match
---
atom [40137,40139]
atom [40043,40045]
===
match
---
atom_expr [33424,33450]
atom_expr [33330,33356]
===
match
---
name: serialized_obj [43367,43381]
name: serialized_obj [44120,44134]
===
match
---
argument [31007,31032]
argument [30913,30938]
===
match
---
param [10748,10749]
param [10748,10749]
===
match
---
name: dag [11803,11806]
name: dag [11803,11806]
===
match
---
name: timezone [958,966]
name: timezone [958,966]
===
match
---
operator: = [17583,17584]
operator: = [17489,17490]
===
match
---
trailer [15831,15841]
trailer [15737,15747]
===
match
---
name: SerializedDAG [37207,37220]
name: SerializedDAG [37113,37126]
===
match
---
trailer [15398,15402]
trailer [15304,15308]
===
match
---
simple_stmt [11683,11689]
simple_stmt [11683,11689]
===
match
---
operator: } [30326,30327]
operator: } [30232,30233]
===
match
---
name: BaseOperatorLink [25204,25220]
name: BaseOperatorLink [25110,25126]
===
match
---
trailer [29314,29329]
trailer [29220,29235]
===
match
---
name: self [20787,20791]
name: self [20693,20697]
===
match
---
name: custom_inbuilt_link [24490,24509]
name: custom_inbuilt_link [24396,24415]
===
match
---
trailer [7271,7290]
trailer [7271,7290]
===
match
---
name: CustomOperator [1693,1707]
name: CustomOperator [1693,1707]
===
match
---
dictorsetmaker [4143,4251]
dictorsetmaker [4143,4251]
===
match
---
operator: <= [18722,18724]
operator: <= [18628,18630]
===
match
---
simple_stmt [8434,8476]
simple_stmt [8434,8476]
===
match
---
string: "dict" [2111,2117]
string: "dict" [2111,2117]
===
match
---
string: "### Task Tutorial Documentation" [6715,6748]
string: "### Task Tutorial Documentation" [6715,6748]
===
match
---
string: "template_fields_renderers" [3656,3683]
string: "template_fields_renderers" [3656,3683]
===
match
---
operator: , [16558,16559]
operator: , [16464,16465]
===
match
---
arglist [36660,36670]
arglist [36566,36576]
===
match
---
trailer [38225,38244]
trailer [38131,38150]
===
match
---
operator: , [14135,14136]
operator: , [14041,14042]
===
match
---
atom [16402,16595]
atom [16308,16501]
===
match
---
testlist_comp [20513,20594]
testlist_comp [20419,20500]
===
match
---
atom_expr [23538,23571]
atom_expr [23444,23477]
===
match
---
string: 'custom_task' [2674,2687]
string: 'custom_task' [2674,2687]
===
match
---
operator: } [21056,21057]
operator: } [20962,20963]
===
match
---
assert_stmt [23686,23739]
assert_stmt [23592,23645]
===
match
---
string: "ui_color" [4848,4858]
string: "ui_color" [4848,4858]
===
match
---
arglist [40811,40821]
arglist [40717,40727]
===
match
---
name: SerializedDAG [18650,18663]
name: SerializedDAG [18556,18569]
===
match
---
trailer [20526,20538]
trailer [20432,20444]
===
match
---
comparison [17402,17452]
comparison [17308,17358]
===
match
---
operator: , [38729,38730]
operator: , [38635,38636]
===
match
---
operator: = [32719,32720]
operator: = [32625,32626]
===
match
---
atom_expr [39922,39971]
atom_expr [39828,39877]
===
match
---
operator: , [29505,29506]
operator: , [29411,29412]
===
match
---
name: datetime [38716,38724]
name: datetime [38622,38630]
===
match
---
assert_stmt [33160,33304]
assert_stmt [33066,33210]
===
match
---
simple_stmt [38932,38970]
simple_stmt [38838,38876]
===
match
---
string: "timedelta" [19370,19381]
string: "timedelta" [19276,19287]
===
match
---
trailer [5681,5688]
trailer [5681,5688]
===
match
---
name: serialized_dag [23538,23552]
name: serialized_dag [23444,23458]
===
match
---
argument [16829,16836]
argument [16735,16742]
===
match
---
number: 2019 [41998,42002]
number: 2019 [41904,41908]
===
match
---
number: 2019 [18288,18292]
number: 2019 [18194,18198]
===
match
---
operator: , [41403,41404]
operator: , [41309,41310]
===
match
---
name: task_ids [13814,13822]
name: task_ids [13720,13728]
===
match
---
name: dag [32235,32238]
name: dag [32141,32144]
===
match
---
suite [5855,6795]
suite [5855,6795]
===
match
---
string: 'task_2' [42674,42682]
string: 'task_2' [42580,42588]
===
match
---
import_from [1491,1557]
import_from [1491,1557]
===
match
---
trailer [16176,16180]
trailer [16082,16086]
===
match
---
param [39606,39613]
param [39512,39519]
===
match
---
name: poke [39595,39599]
name: poke [39501,39505]
===
match
---
name: CustomOpLink [24551,24563]
name: CustomOpLink [24457,24469]
===
match
---
name: get_task [13906,13914]
name: get_task [13812,13820]
===
match
---
trailer [38874,38888]
trailer [38780,38794]
===
match
---
expr_stmt [33591,33643]
expr_stmt [33497,33549]
===
match
---
comp_if [8609,8629]
comp_if [8609,8629]
===
match
---
string: "dummy_value_1" [28212,28227]
string: "dummy_value_1" [28118,28133]
===
match
---
operator: { [30084,30085]
operator: { [29990,29991]
===
match
---
argument [31061,31085]
argument [30967,30991]
===
match
---
expr_stmt [11522,11540]
expr_stmt [11522,11540]
===
match
---
import_as_names [937,966]
import_as_names [937,966]
===
match
---
operator: , [18336,18337]
operator: , [18242,18243]
===
match
---
name: weekday [20527,20534]
name: weekday [20433,20440]
===
match
---
name: custom_inbuilt_link [28462,28481]
name: custom_inbuilt_link [28368,28387]
===
match
---
name: group234 [36850,36858]
name: group234 [36756,36764]
===
match
---
trailer [38724,38736]
trailer [38630,38642]
===
match
---
atom_expr [39097,39142]
atom_expr [39003,39048]
===
match
---
trailer [38109,38128]
trailer [38015,38034]
===
match
---
operator: , [43315,43316]
operator: , [44068,44069]
===
match
---
assert_stmt [20162,20233]
assert_stmt [20068,20139]
===
match
---
atom_expr [16273,16314]
atom_expr [16179,16220]
===
match
---
name: json_dag [37392,37400]
name: json_dag [37298,37306]
===
match
---
trailer [39007,39017]
trailer [38913,38923]
===
match
---
simple_stmt [40268,40644]
simple_stmt [40174,40550]
===
match
---
name: timezone [16567,16575]
name: timezone [16473,16481]
===
match
---
name: serialized_dag [22401,22415]
name: serialized_dag [22307,22321]
===
match
---
simple_stmt [23635,23678]
simple_stmt [23541,23584]
===
match
---
name: test_extra_serialized_field_and_operator_links [22735,22781]
name: test_extra_serialized_field_and_operator_links [22641,22687]
===
match
---
name: DAG [26892,26895]
name: DAG [26798,26801]
===
match
---
number: 2019 [32085,32089]
number: 2019 [31991,31995]
===
match
---
operator: , [21053,21054]
operator: , [20959,20960]
===
match
---
string: '_task_type' [14532,14544]
string: '_task_type' [14438,14450]
===
match
---
atom_expr [34340,34345]
atom_expr [34246,34251]
===
match
---
operator: , [16673,16674]
operator: , [16579,16580]
===
match
---
funcdef [5694,5831]
funcdef [5694,5831]
===
match
---
operator: = [1892,1893]
operator: = [1892,1893]
===
match
---
suite [24970,26280]
suite [24876,26186]
===
match
---
atom [2944,2946]
atom [2944,2946]
===
match
---
operator: , [20396,20397]
operator: , [20302,20303]
===
match
---
expr_stmt [22594,22662]
expr_stmt [22500,22568]
===
match
---
number: 1 [19417,19418]
number: 1 [19323,19324]
===
match
---
name: test_date [28350,28359]
name: test_date [28256,28265]
===
match
---
trailer [15520,15530]
trailer [15426,15436]
===
match
---
operator: , [4830,4831]
operator: , [4830,4831]
===
match
---
argument [1772,1813]
argument [1772,1813]
===
match
---
operator: , [28852,28853]
operator: , [28758,28759]
===
match
---
comparison [14042,14085]
comparison [13948,13991]
===
match
---
atom_expr [40952,40973]
atom_expr [40858,40879]
===
match
---
name: dag_folder [7851,7861]
name: dag_folder [7851,7861]
===
match
---
funcdef [22731,24887]
funcdef [22637,24793]
===
match
---
import_name [845,866]
import_name [845,866]
===
match
---
string: '_log' [14630,14636]
string: '_log' [14536,14542]
===
match
---
atom [30896,30904]
atom [30802,30810]
===
match
---
operator: , [6598,6599]
operator: , [6598,6599]
===
match
---
string: 'hello' [7591,7598]
string: 'hello' [7591,7598]
===
match
---
testlist_comp [29607,31604]
testlist_comp [29513,31510]
===
match
---
classdef [8871,43457]
classdef [8871,44210]
===
match
---
operator: , [30926,30927]
operator: , [30832,30833]
===
match
---
name: from_dict [44943,44952]
name: from_dict [45696,45705]
===
match
---
atom_expr [12380,12393]
atom_expr [12380,12393]
===
match
---
trailer [36893,36910]
trailer [36799,36816]
===
match
---
name: deps [40013,40017]
name: deps [39919,39923]
===
match
---
name: DummyOperator [36777,36790]
name: DummyOperator [36683,36696]
===
match
---
name: ACTION_CAN_EDIT [6365,6380]
name: ACTION_CAN_EDIT [6365,6380]
===
match
---
expr_stmt [12159,12323]
expr_stmt [12159,12323]
===
match
---
string: 'dummy' [39679,39686]
string: 'dummy' [39585,39592]
===
match
---
expr_stmt [36634,36671]
expr_stmt [36540,36577]
===
match
---
name: expected_deserialized [37966,37987]
name: expected_deserialized [37872,37893]
===
match
---
trailer [39755,39774]
trailer [39661,39680]
===
match
---
name: task_id [25775,25782]
name: task_id [25681,25688]
===
match
---
name: serialized_dag [39152,39166]
name: serialized_dag [39058,39072]
===
match
---
name: dag [9877,9880]
name: dag [9877,9880]
===
match
---
operator: , [39136,39137]
operator: , [39042,39043]
===
match
---
if_stmt [11653,11689]
if_stmt [11653,11689]
===
match
---
operator: , [18026,18027]
operator: , [17932,17933]
===
match
---
name: serialized_dag [18906,18920]
name: serialized_dag [18812,18826]
===
match
---
name: to_dict [23492,23499]
name: to_dict [23398,23405]
===
match
---
name: print [41290,41295]
name: print [41196,41201]
===
match
---
simple_stmt [33652,33718]
simple_stmt [33558,33624]
===
match
---
operator: { [4826,4827]
operator: { [4826,4827]
===
match
---
arglist [38725,38735]
arglist [38631,38641]
===
match
---
name: serialized_op [39999,40012]
name: serialized_op [39905,39918]
===
match
---
name: dag [7815,7818]
name: dag [7815,7818]
===
match
---
string: "sla" [3346,3351]
string: "sla" [3346,3351]
===
match
---
operator: , [40780,40781]
operator: , [40686,40687]
===
match
---
expr_stmt [36769,36807]
expr_stmt [36675,36713]
===
match
---
operator: , [8587,8588]
operator: , [8587,8588]
===
match
---
trailer [23302,23314]
trailer [23208,23220]
===
match
---
operator: == [11918,11920]
operator: == [11918,11920]
===
match
---
name: att3 [31007,31011]
name: att3 [30913,30917]
===
match
---
name: dag [9759,9762]
name: dag [9759,9762]
===
match
---
name: user_defined_filters [7569,7589]
name: user_defined_filters [7569,7589]
===
match
---
operator: , [18396,18397]
operator: , [18302,18303]
===
match
---
arglist [41946,42009]
arglist [41852,41915]
===
match
---
name: fromlist [43866,43874]
name: fromlist [44619,44627]
===
match
---
simple_stmt [10781,10953]
simple_stmt [10781,10953]
===
match
---
name: DAG [1293,1296]
name: DAG [1293,1296]
===
match
---
simple_stmt [17137,17198]
simple_stmt [17043,17104]
===
match
---
name: serialized_dag [25800,25814]
name: serialized_dag [25706,25720]
===
match
---
atom [30212,30261]
atom [30118,30167]
===
match
---
atom_expr [41290,41301]
atom_expr [41196,41207]
===
match
---
string: "test3" [43013,43020]
string: "test3" [43593,43600]
===
match
---
operator: , [4040,4041]
operator: , [4040,4041]
===
match
---
operator: = [24510,24511]
operator: = [24416,24417]
===
match
---
trailer [15546,15556]
trailer [15452,15462]
===
match
---
name: test_date [23282,23291]
name: test_date [23188,23197]
===
match
---
name: task [15394,15398]
name: task [15300,15304]
===
match
---
string: "foo" [29797,29802]
string: "foo" [29703,29708]
===
match
---
trailer [11446,11513]
trailer [11446,11513]
===
match
---
simple_stmt [11625,11641]
simple_stmt [11625,11641]
===
match
---
trailer [22223,22300]
trailer [22129,22206]
===
match
---
atom_expr [1757,1989]
atom_expr [1757,1989]
===
match
---
expr_stmt [39726,39778]
expr_stmt [39632,39684]
===
match
---
trailer [5612,5617]
trailer [5612,5617]
===
match
---
name: expected_deserialized [38129,38150]
name: expected_deserialized [38035,38056]
===
match
---
operator: } [7628,7629]
operator: } [7628,7629]
===
match
---
name: client [1099,1105]
name: client [1099,1105]
===
match
---
atom [20309,20359]
atom [20215,20265]
===
match
---
number: 8 [16347,16348]
number: 8 [16253,16254]
===
match
---
name: serialized_obj [43215,43229]
name: serialized_obj [43968,43982]
===
match
---
simple_stmt [38860,38923]
simple_stmt [38766,38829]
===
match
---
string: 'subdag' [35487,35495]
string: 'subdag' [35393,35401]
===
match
---
name: dag [22172,22175]
name: dag [22078,22081]
===
match
---
name: SerializedBaseOperator [37990,38012]
name: SerializedBaseOperator [37896,37918]
===
match
---
name: TaskInstance [1318,1330]
name: TaskInstance [1318,1330]
===
match
---
trailer [13523,13536]
trailer [13429,13442]
===
match
---
name: airflow [1407,1414]
name: airflow [1407,1414]
===
match
---
name: dag_id [25690,25696]
name: dag_id [25596,25602]
===
match
---
trailer [22287,22299]
trailer [22193,22205]
===
match
---
name: glob [984,988]
name: glob [984,988]
===
match
---
if_stmt [13410,13720]
if_stmt [13316,13626]
===
match
---
name: update [7925,7931]
name: update [7925,7931]
===
match
---
atom_expr [7375,7659]
atom_expr [7375,7659]
===
match
---
trailer [24066,24069]
trailer [23972,23975]
===
match
---
operator: , [3084,3085]
operator: , [3084,3085]
===
match
---
dictorsetmaker [7815,7830]
dictorsetmaker [7815,7830]
===
match
---
atom_expr [22694,22725]
atom_expr [22600,22631]
===
match
---
argument [7710,7778]
argument [7710,7778]
===
match
---
name: datetime [36651,36659]
name: datetime [36557,36565]
===
match
---
name: datetime [16273,16281]
name: datetime [16179,16187]
===
match
---
simple_stmt [39823,39845]
simple_stmt [39729,39751]
===
match
---
operator: , [42848,42849]
operator: , [42754,42755]
===
match
---
arglist [41849,41923]
arglist [41755,41829]
===
match
---
string: 'run_as_user' [35397,35410]
string: 'run_as_user' [35303,35316]
===
match
---
argument [18470,18489]
argument [18376,18395]
===
match
---
operator: = [26927,26928]
operator: = [26833,26834]
===
match
---
string: "timezone" [19873,19883]
string: "timezone" [19779,19789]
===
match
---
operator: , [16756,16757]
operator: , [16662,16663]
===
match
---
operator: = [1938,1939]
operator: = [1938,1939]
===
match
---
simple_stmt [44285,44317]
simple_stmt [45038,45070]
===
match
---
operator: , [3433,3434]
operator: , [3433,3434]
===
match
---
string: 'dummy' [33533,33540]
string: 'dummy' [33439,33446]
===
match
---
simple_stmt [23686,23740]
simple_stmt [23592,23646]
===
match
---
trailer [39074,39082]
trailer [38980,38988]
===
match
---
suite [25947,26280]
suite [25853,26186]
===
match
---
operator: = [9109,9110]
operator: = [9109,9110]
===
match
---
simple_stmt [33424,33451]
simple_stmt [33330,33357]
===
match
---
trailer [13108,13120]
trailer [13137,13179]
===
match
---
expr_stmt [24738,24819]
expr_stmt [24644,24725]
===
match
---
operator: = [37043,37044]
operator: = [36949,36950]
===
match
---
string: "echo" [27008,27014]
string: "echo" [26914,26920]
===
match
---
operator: = [20828,20829]
operator: = [20734,20735]
===
match
---
trailer [10837,10846]
trailer [10837,10846]
===
match
---
string: 'test_dag_on_failure_callback_roundtrip' [41856,41896]
string: 'test_dag_on_failure_callback_roundtrip' [41762,41802]
===
match
---
name: tzinfo [16441,16447]
name: tzinfo [16347,16353]
===
match
---
atom_expr [11549,11561]
atom_expr [11549,11561]
===
match
---
string: 'on_failure_callback' [34909,34930]
string: 'on_failure_callback' [34815,34836]
===
match
---
name: execute [25627,25634]
name: execute [25533,25540]
===
match
---
atom [42518,42558]
atom [42424,42464]
===
match
---
atom [30702,31603]
atom [30608,31509]
===
match
---
suite [25751,25791]
suite [25657,25697]
===
match
---
name: serialized_dag [22310,22324]
name: serialized_dag [22216,22230]
===
match
---
trailer [12057,12097]
trailer [12057,12097]
===
match
---
operator: , [34586,34587]
operator: , [34492,34493]
===
match
---
with_stmt [25853,26280]
with_stmt [25759,26186]
===
match
---
operator: { [21976,21977]
operator: { [21882,21883]
===
match
---
operator: = [39167,39168]
operator: = [39073,39074]
===
match
---
testlist_comp [18160,18322]
testlist_comp [18066,18228]
===
match
---
atom_expr [36880,36910]
atom_expr [36786,36816]
===
match
---
assert_stmt [21822,21876]
assert_stmt [21728,21782]
===
match
---
fstring [8393,8419]
fstring [8393,8419]
===
match
---
atom_expr [22621,22662]
atom_expr [22527,22568]
===
match
---
name: datetime [18502,18510]
name: datetime [18408,18416]
===
match
---
atom_expr [7967,8003]
atom_expr [7967,8003]
===
match
---
operator: == [28911,28913]
operator: == [28817,28819]
===
match
---
operator: { [13673,13674]
operator: { [13579,13580]
===
match
---
name: task_end_date [18725,18738]
name: task_end_date [18631,18644]
===
match
---
atom_expr [16242,16254]
atom_expr [16148,16160]
===
match
---
simple_stmt [916,967]
simple_stmt [916,967]
===
match
---
string: "bar" [29994,29999]
string: "bar" [29900,29905]
===
match
---
name: deserialized_dag [21717,21733]
name: deserialized_dag [21623,21639]
===
match
---
comp_if [44552,44587]
comp_if [45305,45340]
===
match
---
trailer [37462,37496]
trailer [37368,37402]
===
match
---
string: "dag" [27634,27639]
string: "dag" [27540,27545]
===
match
---
name: serialized_task [14280,14295]
name: serialized_task [14186,14201]
===
match
---
name: expand [21897,21903]
name: expand [21803,21809]
===
match
---
name: keys [37598,37602]
name: keys [37504,37508]
===
match
---
name: serialize_operator [38226,38244]
name: serialize_operator [38132,38150]
===
match
---
param [29501,29506]
param [29407,29412]
===
match
---
atom [2619,2644]
atom [2619,2644]
===
match
---
name: datetime [32076,32084]
name: datetime [31982,31990]
===
match
---
simple_stmt [8635,8647]
simple_stmt [8635,8647]
===
match
---
operator: = [7722,7723]
operator: = [7722,7723]
===
match
---
name: V1VolumeMount [1920,1933]
name: V1VolumeMount [1920,1933]
===
match
---
operator: == [24263,24265]
operator: == [24169,24171]
===
match
---
testlist_comp [3616,3637]
testlist_comp [3616,3637]
===
match
---
operator: } [7363,7364]
operator: } [7363,7364]
===
match
---
string: 'simple_task' [22232,22245]
string: 'simple_task' [22138,22151]
===
match
---
comparison [27922,28102]
comparison [27828,28008]
===
match
---
trailer [27937,27949]
trailer [27843,27855]
===
match
---
simple_stmt [29374,29396]
simple_stmt [29280,29302]
===
match
---
atom_expr [26857,26877]
atom_expr [26763,26783]
===
match
---
arglist [11764,11772]
arglist [11764,11772]
===
match
---
import_from [39479,39530]
import_from [39385,39436]
===
match
---
atom [29984,30023]
atom [29890,29929]
===
match
---
operator: , [42614,42615]
operator: , [42520,42521]
===
match
---
string: "sar" [30252,30257]
string: "sar" [30158,30163]
===
match
---
trailer [40810,40822]
trailer [40716,40728]
===
match
---
simple_stmt [29275,29333]
simple_stmt [29181,29239]
===
match
---
atom_expr [11707,11733]
atom_expr [11707,11733]
===
match
---
name: dag [25839,25842]
name: dag [25745,25748]
===
match
---
name: xcom_push [24397,24406]
name: xcom_push [24303,24312]
===
match
---
name: self [43097,43101]
name: self [43832,43836]
===
match
---
arglist [16341,16372]
arglist [16247,16278]
===
match
---
name: set [32990,32993]
name: set [32896,32899]
===
match
---
suite [43490,45083]
suite [44243,45836]
===
match
---
name: v [13612,13613]
name: v [13518,13519]
===
match
---
simple_stmt [17619,17655]
simple_stmt [17525,17561]
===
match
---
name: task_id [13915,13922]
name: task_id [13821,13828]
===
match
---
simple_stmt [14191,14254]
simple_stmt [14097,14160]
===
match
---
simple_stmt [20095,20154]
simple_stmt [20001,20060]
===
match
---
atom [13586,13669]
atom [13492,13575]
===
match
---
operator: , [30328,30329]
operator: , [30234,30235]
===
match
---
atom [19239,19257]
atom [19145,19163]
===
match
---
testlist_comp [20644,20731]
testlist_comp [20550,20637]
===
match
---
trailer [10283,10294]
trailer [10283,10294]
===
match
---
operator: = [22325,22326]
operator: = [22231,22232]
===
match
---
argument [17901,17920]
argument [17807,17826]
===
match
---
operator: { [27753,27754]
operator: { [27659,27660]
===
match
---
atom_expr [33514,33541]
atom_expr [33420,33447]
===
match
---
operator: , [13361,13362]
operator: , [13267,13268]
===
match
---
name: op [39654,39656]
name: op [39560,39562]
===
match
---
atom [19853,19855]
atom [19759,19761]
===
match
---
number: 10 [7360,7362]
number: 10 [7360,7362]
===
match
---
name: getattr [27266,27273]
name: getattr [27172,27179]
===
match
---
name: proc [11522,11526]
name: proc [11522,11526]
===
match
---
operator: , [1899,1900]
operator: , [1899,1900]
===
match
---
name: from_dict [22560,22569]
name: from_dict [22466,22475]
===
match
---
atom_expr [30375,30518]
atom_expr [30281,30424]
===
match
---
name: passed_failure_callback [41405,41428]
name: passed_failure_callback [41311,41334]
===
match
---
number: 0 [22515,22516]
number: 0 [22421,22422]
===
match
---
operator: , [14636,14637]
operator: , [14542,14543]
===
match
---
name: utc [16128,16131]
name: utc [16034,16037]
===
match
---
param [21183,21195]
param [21089,21101]
===
match
---
operator: , [16107,16108]
operator: , [16013,16014]
===
match
---
simple_stmt [33994,34037]
simple_stmt [33900,33943]
===
match
---
operator: = [7325,7326]
operator: = [7325,7326]
===
match
---
argument [7569,7629]
argument [7569,7629]
===
match
---
string: '_task_group' [2496,2509]
string: '_task_group' [2496,2509]
===
match
---
string: "pod_override" [4097,4111]
string: "pod_override" [4097,4111]
===
match
---
name: make_simple_dag [45050,45065]
name: make_simple_dag [45803,45818]
===
match
---
operator: , [8679,8680]
operator: , [8679,8680]
===
match
---
simple_stmt [10119,10172]
simple_stmt [10119,10172]
===
match
---
name: task_id [37059,37066]
name: task_id [36965,36972]
===
match
---
string: 'custom_task' [6478,6491]
string: 'custom_task' [6478,6491]
===
match
---
name: att1 [30422,30426]
name: att1 [30328,30332]
===
match
---
string: "'nested2': ClassWithCustomAttributes({'att3': '{{ task.task_id }}', 'att4': " [31406,31484]
string: "'nested2': ClassWithCustomAttributes({'att3': '{{ task.task_id }}', 'att4': " [31312,31390]
===
match
---
comparison [44613,44649]
comparison [45366,45402]
===
match
---
name: k8s [1824,1827]
name: k8s [1824,1827]
===
match
---
operator: = [23339,23340]
operator: = [23245,23246]
===
match
---
number: 0 [27142,27143]
number: 0 [27048,27049]
===
match
---
operator: , [31156,31157]
operator: , [31062,31063]
===
match
---
trailer [37934,37948]
trailer [37840,37854]
===
match
---
operator: , [2424,2425]
operator: , [2424,2425]
===
match
---
name: simple_task [23701,23712]
name: simple_task [23607,23618]
===
match
---
fstring_start: f' [13275,13277]
fstring_start: f' [13181,13183]
===
match
---
name: SerializedDAG [12448,12461]
name: SerializedDAG [12448,12461]
===
match
---
operator: { [6657,6658]
operator: { [6657,6658]
===
match
---
for_stmt [13356,13720]
for_stmt [13262,13626]
===
match
---
number: 0 [27763,27764]
number: 0 [27669,27670]
===
match
---
name: timezone [16242,16250]
name: timezone [16148,16156]
===
match
---
name: SerializedDAG [22327,22340]
name: SerializedDAG [22233,22246]
===
match
---
string: "_inlets" [4652,4661]
string: "_inlets" [4652,4661]
===
match
---
atom [17830,17922]
atom [17736,17828]
===
match
---
operator: , [17995,17996]
operator: , [17901,17902]
===
match
---
param [21172,21177]
param [21078,21083]
===
match
---
param [10092,10108]
param [10092,10108]
===
match
---
arglist [30767,31157]
arglist [30673,31063]
===
match
---
simple_stmt [13223,13314]
simple_stmt [13089,13220]
===
match
---
operator: ** [40711,40713]
operator: ** [40617,40619]
===
match
---
string: "__var" [5327,5334]
string: "__var" [5327,5334]
===
match
---
name: os [5639,5641]
name: os [5639,5641]
===
match
---
name: BashOperator [6501,6513]
name: BashOperator [6501,6513]
===
match
---
trailer [19017,19020]
trailer [18923,18926]
===
match
---
atom_expr [18555,18623]
atom_expr [18461,18529]
===
match
---
simple_stmt [24490,24570]
simple_stmt [24396,24476]
===
match
---
simple_stmt [10268,10302]
simple_stmt [10268,10302]
===
match
---
string: """         Test TaskGroup serialization/deserialization.         """ [36442,36511]
string: """         Test TaskGroup serialization/deserialization.         """ [36348,36417]
===
match
---
atom [40136,40147]
atom [40042,40053]
===
match
---
string: "att1" [30897,30903]
string: "att1" [30803,30809]
===
match
---
name: realpath [5596,5604]
name: realpath [5596,5604]
===
match
---
name: airflow [1271,1278]
name: airflow [1271,1278]
===
match
---
operator: , [2957,2958]
operator: , [2957,2958]
===
match
---
operator: = [31011,31012]
operator: = [30917,30918]
===
match
---
atom_expr [12448,12474]
atom_expr [12448,12474]
===
match
---
name: tzinfo [16294,16300]
name: tzinfo [16200,16206]
===
match
---
operator: , [33241,33242]
operator: , [33147,33148]
===
match
---
operator: , [35416,35417]
operator: , [35322,35323]
===
match
---
simple_stmt [37242,37282]
simple_stmt [37148,37188]
===
match
---
trailer [43918,43969]
trailer [44671,44722]
===
match
---
trailer [10224,10228]
trailer [10224,10228]
===
match
---
name: dag [6790,6793]
name: dag [6790,6793]
===
match
---
dictorsetmaker [27696,27765]
dictorsetmaker [27602,27671]
===
match
---
atom_expr [24238,24261]
atom_expr [24144,24167]
===
match
---
trailer [44561,44564]
trailer [45314,45317]
===
match
---
operator: = [11588,11589]
operator: = [11588,11589]
===
match
---
trailer [44289,44296]
trailer [45042,45049]
===
match
---
name: items [9738,9743]
name: items [9738,9743]
===
match
---
operator: = [38815,38816]
operator: = [38721,38722]
===
match
---
operator: } [29308,29309]
operator: } [29214,29215]
===
match
---
name: globals_ [43840,43848]
name: globals_ [44593,44601]
===
match
---
trailer [34022,34036]
trailer [33928,33942]
===
match
---
string: "simple_task" [19112,19125]
string: "simple_task" [19018,19031]
===
match
---
fstring_start: f' [7613,7615]
fstring_start: f' [7613,7615]
===
match
---
trailer [16913,16918]
trailer [16819,16824]
===
match
---
name: getattr [23693,23700]
name: getattr [23599,23606]
===
match
---
operator: ** [41898,41900]
operator: ** [41804,41806]
===
match
---
name: deserialized_simple_task [22694,22718]
name: deserialized_simple_task [22600,22624]
===
match
---
name: SerializedBaseOperator [33668,33690]
name: SerializedBaseOperator [33574,33596]
===
match
---
name: dag_id [5941,5947]
name: dag_id [5941,5947]
===
match
---
operator: { [6309,6310]
operator: { [6309,6310]
===
match
---
operator: = [25590,25591]
operator: = [25496,25497]
===
match
---
suite [29262,29333]
suite [29168,29239]
===
match
---
arglist [26962,27023]
arglist [26868,26929]
===
match
---
comparison [20875,20897]
comparison [20781,20803]
===
match
---
trailer [19001,19008]
trailer [18907,18914]
===
match
---
name: kwargs [33443,33449]
name: kwargs [33349,33355]
===
match
---
expr_stmt [21430,21473]
expr_stmt [21336,21379]
===
match
---
funcdef [29490,29557]
funcdef [29396,29463]
===
match
---
name: args [44557,44561]
name: args [45310,45314]
===
match
---
return_stmt [39632,39644]
return_stmt [39538,39550]
===
match
---
funcdef [39412,40018]
funcdef [39318,39924]
===
match
---
name: self [33145,33149]
name: self [33051,33055]
===
match
---
expr_stmt [11571,11592]
expr_stmt [11571,11592]
===
match
---
atom_expr [29209,29234]
atom_expr [29115,29140]
===
match
---
expr_stmt [42020,42063]
expr_stmt [41926,41969]
===
match
---
name: task_id [40759,40766]
name: task_id [40665,40672]
===
match
---
operator: , [18091,18092]
operator: , [17997,17998]
===
match
---
if_stmt [21482,21614]
if_stmt [21388,21520]
===
match
---
operator: , [4450,4451]
operator: , [4450,4451]
===
match
---
name: dag [27154,27157]
name: dag [27060,27063]
===
match
---
string: 'max_retry_delay' [34831,34848]
string: 'max_retry_delay' [34737,34754]
===
match
---
arglist [5623,5688]
arglist [5623,5688]
===
match
---
operator: , [18232,18233]
operator: , [18138,18139]
===
match
---
arglist [20389,20405]
arglist [20295,20311]
===
match
---
simple_stmt [29527,29557]
simple_stmt [29433,29463]
===
match
---
name: SerializedDAG [21642,21655]
name: SerializedDAG [21548,21561]
===
match
---
string: "timedelta" [2332,2343]
string: "timedelta" [2332,2343]
===
match
---
atom [21073,21095]
atom [20979,21001]
===
match
---
operator: { [13699,13700]
operator: { [13605,13606]
===
match
---
argument [1901,1969]
argument [1901,1969]
===
match
---
suite [29429,29481]
suite [29335,29387]
===
match
---
operator: , [40115,40116]
operator: , [40021,40022]
===
match
---
trailer [19111,19126]
trailer [19017,19032]
===
match
---
testlist_comp [30720,31589]
testlist_comp [30626,31495]
===
match
---
string: "dummy_value_1" [24423,24438]
string: "dummy_value_1" [24329,24344]
===
match
---
operator: ** [33397,33399]
operator: ** [33303,33305]
===
match
---
operator: >> [38889,38891]
operator: >> [38795,38797]
===
match
---
argument [43832,43848]
argument [44585,44601]
===
match
---
fstring_string: ] does not match [13702,13718]
fstring_string: ] does not match [13608,13624]
===
match
---
string: "_access_control" [5264,5281]
string: "_access_control" [5264,5281]
===
match
---
name: bash_command [23431,23443]
name: bash_command [23337,23349]
===
match
---
name: stringified_dags [11997,12013]
name: stringified_dags [11997,12013]
===
match
---
with_item [36825,36858]
with_item [36731,36764]
===
match
---
dotted_name [1496,1529]
dotted_name [1496,1529]
===
match
---
testlist_comp [29983,30166]
testlist_comp [29889,30072]
===
match
---
atom_expr [43384,43407]
atom_expr [44137,44160]
===
match
---
operator: , [14812,14813]
operator: , [14718,14719]
===
match
---
string: 'tests.test_utils.mock_operators.CustomBaseIndexOpLink' [27781,27836]
string: 'tests.test_utils.mock_operators.CustomBaseIndexOpLink' [27687,27742]
===
match
---
operator: , [3783,3784]
operator: , [3783,3784]
===
match
---
argument [18568,18589]
argument [18474,18495]
===
match
---
operator: , [18321,18322]
operator: , [18227,18228]
===
match
---
expr_stmt [9692,9712]
expr_stmt [9692,9712]
===
match
---
trailer [34272,34276]
trailer [34178,34182]
===
match
---
trailer [23600,23610]
trailer [23506,23516]
===
match
---
dictorsetmaker [5297,5527]
dictorsetmaker [5297,5527]
===
match
---
trailer [37588,37597]
trailer [37494,37503]
===
match
---
atom_expr [38669,38737]
atom_expr [38575,38643]
===
match
---
expr_stmt [28112,28173]
expr_stmt [28018,28079]
===
match
---
trailer [32234,32239]
trailer [32140,32145]
===
match
---
name: task1 [36769,36774]
name: task1 [36675,36680]
===
match
---
simple_stmt [5779,5808]
simple_stmt [5779,5808]
===
match
---
argument [30422,30447]
argument [30328,30353]
===
match
---
dictorsetmaker [2246,2283]
dictorsetmaker [2246,2283]
===
match
---
operator: , [32438,32439]
operator: , [32344,32345]
===
match
---
return_stmt [29527,29556]
return_stmt [29433,29462]
===
match
---
operator: = [43890,43891]
operator: = [44643,44644]
===
match
---
atom_expr [10711,10735]
atom_expr [10711,10735]
===
match
---
operator: , [1813,1814]
operator: , [1813,1814]
===
match
---
operator: , [19337,19338]
operator: , [19243,19244]
===
match
---
trailer [9831,9836]
trailer [9831,9836]
===
match
---
trailer [41295,41301]
trailer [41201,41207]
===
match
---
testlist_comp [29737,29779]
testlist_comp [29643,29685]
===
match
---
operator: , [18292,18293]
operator: , [18198,18199]
===
match
---
operator: = [16832,16833]
operator: = [16738,16739]
===
match
---
atom [5336,5526]
atom [5336,5526]
===
match
---
assert_stmt [14389,14426]
assert_stmt [14295,14332]
===
match
---
operator: } [11591,11592]
operator: } [11591,11592]
===
match
---
name: dag [39277,39280]
name: dag [39183,39186]
===
match
---
simple_stmt [11132,11195]
simple_stmt [11132,11195]
===
match
---
string: "https://www.google.com" [24835,24859]
string: "https://www.google.com" [24741,24765]
===
match
---
atom_expr [15516,15530]
atom_expr [15422,15436]
===
match
---
name: passed_success_callback [40713,40736]
name: passed_success_callback [40619,40642]
===
match
---
atom_expr [25858,25932]
atom_expr [25764,25838]
===
match
---
operator: { [20408,20409]
operator: { [20314,20315]
===
match
---
trailer [5595,5604]
trailer [5595,5604]
===
match
---
simple_stmt [24029,24175]
simple_stmt [23935,24081]
===
match
---
operator: , [34690,34691]
operator: , [34596,34597]
===
match
---
simple_stmt [28984,29108]
simple_stmt [28890,29014]
===
match
---
simple_stmt [845,867]
simple_stmt [845,867]
===
match
---
name: utc [17991,17994]
name: utc [17897,17900]
===
match
---
trailer [9951,9975]
trailer [9951,9975]
===
match
---
trailer [13281,13288]
trailer [13187,13194]
===
match
---
name: other [29422,29427]
name: other [29328,29333]
===
match
---
operator: = [5982,5983]
operator: = [5982,5983]
===
match
---
operator: == [21842,21844]
operator: == [21748,21750]
===
match
---
name: expected_value [40243,40257]
name: expected_value [40149,40163]
===
match
---
assert_stmt [37506,37547]
assert_stmt [37412,37453]
===
match
---
assert_stmt [11882,11937]
assert_stmt [11882,11937]
===
match
---
string: 'doc_rst' [34514,34523]
string: 'doc_rst' [34420,34429]
===
match
---
arglist [14351,14379]
arglist [14257,14285]
===
match
---
operator: } [44861,44862]
operator: } [45614,45615]
===
match
---
trailer [39212,39226]
trailer [39118,39132]
===
match
---
trailer [39127,39142]
trailer [39033,39048]
===
match
---
operator: , [28146,28147]
operator: , [28052,28053]
===
match
---
string: 'simple_dag' [21309,21321]
string: 'simple_dag' [21215,21227]
===
match
---
trailer [42290,42300]
trailer [42196,42206]
===
match
---
name: dags [9662,9666]
name: dags [9662,9666]
===
match
---
assert_stmt [26239,26279]
assert_stmt [26145,26185]
===
match
---
number: 0 [44562,44563]
number: 0 [45315,45316]
===
match
---
trailer [37740,37742]
trailer [37646,37648]
===
match
---
suite [8074,8109]
suite [8074,8109]
===
match
---
simple_stmt [14262,14321]
simple_stmt [14168,14227]
===
match
---
operator: , [40709,40710]
operator: , [40615,40616]
===
match
---
operator: , [19855,19856]
operator: , [19761,19762]
===
match
---
argument [26994,27023]
argument [26900,26929]
===
match
---
operator: , [12082,12083]
operator: , [12082,12083]
===
match
---
operator: } [13701,13702]
operator: } [13607,13608]
===
match
---
string: "### DAG Tutorial Documentation" [3052,3084]
string: "### DAG Tutorial Documentation" [3052,3084]
===
match
---
name: test_roundtrip_provider_example_dags [12107,12143]
name: test_roundtrip_provider_example_dags [12107,12143]
===
match
---
operator: = [27006,27007]
operator: = [26912,26913]
===
match
---
operator: , [19575,19576]
operator: , [19481,19482]
===
match
---
trailer [10219,10224]
trailer [10219,10224]
===
match
---
atom_expr [21642,21681]
atom_expr [21548,21587]
===
match
---
name: isinstance [14269,14279]
name: isinstance [14175,14185]
===
match
---
operator: } [29948,29949]
operator: } [29854,29855]
===
match
---
name: deserialized_dag [42258,42274]
name: deserialized_dag [42164,42180]
===
match
---
name: serialize_pod [44817,44830]
name: serialize_pod [45570,45583]
===
match
---
param [31675,31680]
param [31581,31586]
===
match
---
testlist_comp [29608,29618]
testlist_comp [29514,29524]
===
match
---
atom_expr [18279,18321]
atom_expr [18185,18227]
===
match
---
operator: { [5283,5284]
operator: { [5283,5284]
===
match
---
atom_expr [14269,14320]
atom_expr [14175,14226]
===
match
---
trailer [24406,24439]
trailer [24312,24345]
===
match
---
suite [39578,39645]
suite [39484,39551]
===
match
---
atom_expr [41845,41924]
atom_expr [41751,41830]
===
match
---
trailer [34067,34076]
trailer [33973,33982]
===
match
---
name: dag [26886,26889]
name: dag [26792,26795]
===
match
---
string: "dag" [17262,17267]
string: "dag" [17168,17173]
===
match
---
name: MyOperator [33320,33330]
name: MyOperator [33226,33236]
===
match
---
trailer [33440,33450]
trailer [33346,33356]
===
match
---
atom_expr [15542,15556]
atom_expr [15448,15462]
===
match
---
fstring_end: ' [7627,7628]
fstring_end: ' [7627,7628]
===
match
---
name: simple_task [19142,19153]
name: simple_task [19048,19059]
===
match
---
name: template_fields [30880,30895]
name: template_fields [30786,30801]
===
match
---
atom_expr [8788,8801]
atom_expr [8788,8801]
===
match
---
operator: , [2792,2793]
operator: , [2792,2793]
===
match
---
string: 'simple_dag' [18477,18489]
string: 'simple_dag' [18383,18395]
===
match
---
atom_expr [33557,33572]
atom_expr [33463,33478]
===
match
---
name: to_dict [42051,42058]
name: to_dict [41957,41964]
===
match
---
name: serialized [19621,19631]
name: serialized [19527,19537]
===
match
---
name: spec [44271,44275]
name: spec [45024,45028]
===
match
---
param [12597,12600]
param [12597,12600]
===
match
---
name: DAG [16733,16736]
name: DAG [16639,16642]
===
match
---
suite [29146,29235]
suite [29052,29141]
===
match
---
argument [16758,16783]
argument [16664,16689]
===
match
---
name: sorted [10704,10710]
name: sorted [10704,10710]
===
match
---
simple_stmt [16793,16866]
simple_stmt [16699,16772]
===
match
---
simple_stmt [42326,42392]
simple_stmt [42232,42298]
===
match
---
name: operators [38565,38574]
name: operators [38471,38480]
===
match
---
assert_stmt [17224,17280]
assert_stmt [17130,17186]
===
match
---
name: node [37669,37673]
name: node [37575,37579]
===
match
---
testlist_comp [8060,8071]
testlist_comp [8060,8071]
===
match
---
simple_stmt [15875,15917]
simple_stmt [15781,15823]
===
match
---
atom [6775,6794]
atom [6775,6794]
===
match
---
simple_stmt [38758,38797]
simple_stmt [38664,38703]
===
match
---
trailer [33747,33760]
trailer [33653,33666]
===
match
---
param [31681,31697]
param [31587,31603]
===
match
---
suite [43142,43457]
suite [43877,44210]
===
match
---
comparison [23520,23571]
comparison [23426,23477]
===
match
---
operator: , [39442,39443]
operator: , [39348,39349]
===
match
---
operator: , [35075,35076]
operator: , [34981,34982]
===
match
---
atom [42750,42790]
atom [42656,42696]
===
match
---
operator: = [39035,39036]
operator: = [38941,38942]
===
match
---
name: end_date [18524,18532]
name: end_date [18430,18438]
===
match
---
atom [34788,34790]
atom [34694,34696]
===
match
---
name: fields_to_check [12773,12788]
name: fields_to_check [12773,12788]
===
match
---
operator: = [16447,16448]
operator: = [16353,16354]
===
match
---
string: "on_failure_callback" [41257,41278]
string: "on_failure_callback" [41163,41184]
===
match
---
atom_expr [9976,10005]
atom_expr [9976,10005]
===
match
---
operator: , [18088,18089]
operator: , [17994,17995]
===
match
---
name: tzinfo [18181,18187]
name: tzinfo [18087,18093]
===
match
---
atom_expr [8596,8608]
atom_expr [8596,8608]
===
match
---
string: """Test Serialized Lists, Sets and Tuples are sorted""" [43151,43206]
string: """Test Serialized Sets are sorted while list and tuple preserve order""" [43886,43959]
===
match
---
parameters [32503,32509]
parameters [32409,32415]
===
match
---
name: timezone [17982,17990]
name: timezone [17888,17896]
===
match
---
atom [39341,39356]
atom [39247,39262]
===
match
---
name: ACTION_CAN_READ [6336,6351]
name: ACTION_CAN_READ [6336,6351]
===
match
---
string: "{{ task.task_id }}" [30142,30162]
string: "{{ task.task_id }}" [30048,30068]
===
match
---
comparison [15827,15861]
comparison [15733,15767]
===
match
---
operator: , [20700,20701]
operator: , [20606,20607]
===
match
---
classdef [25445,25672]
classdef [25351,25578]
===
match
---
argument [43885,43896]
argument [44638,44649]
===
match
---
operator: } [30259,30260]
operator: } [30165,30166]
===
match
---
suite [39810,39845]
suite [39716,39751]
===
match
---
string: "__type" [20409,20417]
string: "__type" [20315,20323]
===
match
---
trailer [33050,33072]
trailer [32956,32978]
===
match
---
name: utc [18317,18320]
name: utc [18223,18226]
===
match
---
name: utils [36591,36596]
name: utils [36497,36502]
===
match
---
import_as_names [1611,1648]
import_as_names [1611,1648]
===
match
---
operator: , [19890,19891]
operator: , [19796,19797]
===
match
---
trailer [9003,9005]
trailer [9003,9005]
===
match
---
atom_expr [45021,45082]
atom_expr [45774,45835]
===
match
---
name: val [20977,20980]
name: val [20883,20886]
===
match
---
trailer [21301,21334]
trailer [21207,21240]
===
match
---
operator: = [18187,18188]
operator: = [18093,18094]
===
match
---
name: timedelta [6038,6047]
name: timedelta [6038,6047]
===
match
---
name: from_dict [32281,32290]
name: from_dict [32187,32196]
===
match
---
string: 'github' [24295,24303]
string: 'github' [24201,24209]
===
match
---
funcdef [25352,25436]
funcdef [25258,25342]
===
match
---
name: dag_dict [10781,10789]
name: dag_dict [10781,10789]
===
match
---
string: "_outlets" [3487,3497]
string: "_outlets" [3487,3497]
===
match
---
trailer [15225,15245]
trailer [15131,15151]
===
match
---
atom [20445,20469]
atom [20351,20375]
===
match
---
operator: , [3925,3926]
operator: , [3925,3926]
===
match
---
simple_stmt [1735,1990]
simple_stmt [1735,1990]
===
match
---
trailer [8619,8629]
trailer [8619,8629]
===
match
---
name: side_effect [43942,43953]
name: side_effect [44695,44706]
===
match
---
string: "tasks" [10727,10734]
string: "tasks" [10727,10734]
===
match
---
string: "ui_color" [3519,3529]
string: "ui_color" [3519,3529]
===
match
---
operator: { [30134,30135]
operator: { [30040,30041]
===
match
---
dotted_name [21004,21024]
dotted_name [20910,20930]
===
match
---
operator: , [1308,1309]
operator: , [1308,1309]
===
match
---
name: downstream_task_ids [15226,15245]
name: downstream_task_ids [15132,15151]
===
match
---
string: "default_pool" [3951,3965]
string: "default_pool" [3951,3965]
===
match
---
operator: { [7621,7622]
operator: { [7621,7622]
===
match
---
simple_stmt [7261,7307]
simple_stmt [7261,7307]
===
match
---
name: patterns [8353,8361]
name: patterns [8353,8361]
===
match
---
trailer [44167,44177]
trailer [44920,44930]
===
match
---
name: name [43826,43830]
name: name [44579,44583]
===
match
---
funcdef [32461,33090]
funcdef [32367,32996]
===
match
---
arglist [28585,28617]
arglist [28491,28523]
===
match
---
name: serialized_dag [12407,12421]
name: serialized_dag [12407,12421]
===
match
---
testlist_comp [20375,20470]
testlist_comp [20281,20376]
===
match
---
name: bash_command [26994,27006]
name: bash_command [26900,26912]
===
match
---
operator: , [20307,20308]
operator: , [20213,20214]
===
match
---
name: self [11117,11121]
name: self [11117,11121]
===
match
---
name: default_args [7442,7454]
name: default_args [7442,7454]
===
match
---
name: TaskGroup [36615,36624]
name: TaskGroup [36521,36530]
===
match
---
suite [22788,24887]
suite [22694,24793]
===
match
---
string: "on_success_callback" [40070,40091]
string: "on_success_callback" [39976,39997]
===
match
---
operator: , [35043,35044]
operator: , [34949,34950]
===
match
---
file_input [788,45083]
file_input [788,45836]
===
match
---
decorated [16045,17453]
decorated [15951,17359]
===
match
---
with_stmt [25681,25791]
with_stmt [25587,25697]
===
match
---
return_stmt [10965,10980]
return_stmt [10965,10980]
===
match
---
suite [11612,11821]
suite [11612,11821]
===
match
---
simple_stmt [26360,26837]
simple_stmt [26266,26743]
===
match
---
import_from [1402,1449]
import_from [1402,1449]
===
match
---
trailer [20172,20201]
trailer [20078,20107]
===
match
---
parameters [33144,33150]
parameters [33050,33056]
===
match
---
suite [29361,29396]
suite [29267,29302]
===
match
---
operator: } [29661,29662]
operator: } [29567,29568]
===
match
---
if_stmt [8033,8159]
if_stmt [8033,8159]
===
match
---
trailer [44952,44966]
trailer [45705,45719]
===
match
---
atom_expr [27926,27949]
atom_expr [27832,27855]
===
match
---
string: "airflow." [44576,44586]
string: "airflow." [45329,45339]
===
match
---
dictorsetmaker [6324,6380]
dictorsetmaker [6324,6380]
===
match
---
import_from [1558,1648]
import_from [1558,1648]
===
match
---
name: x [40100,40101]
name: x [40006,40007]
===
match
---
assert_stmt [40916,40973]
assert_stmt [40822,40879]
===
match
---
trailer [19153,19162]
trailer [19059,19068]
===
match
---
operator: , [16433,16434]
operator: , [16339,16340]
===
match
---
atom_expr [16567,16579]
atom_expr [16473,16485]
===
match
---
simple_stmt [15175,15246]
simple_stmt [15081,15152]
===
match
---
operator: { [29872,29873]
operator: { [29778,29779]
===
match
---
string: 'dict' [4034,4040]
string: 'dict' [4034,4040]
===
match
---
sync_comp_for [8577,8629]
sync_comp_for [8577,8629]
===
match
---
string: "template_fields" [4922,4939]
string: "template_fields" [4922,4939]
===
match
---
suite [12150,12540]
suite [12150,12540]
===
match
---
name: load_dag_schema_dict [1537,1557]
name: load_dag_schema_dict [1537,1557]
===
match
---
operator: = [22176,22177]
operator: = [22082,22083]
===
match
---
number: 1 [36666,36667]
number: 1 [36572,36573]
===
match
---
name: ti [24394,24396]
name: ti [24300,24302]
===
match
---
string: "_downstream_task_ids" [3376,3398]
string: "_downstream_task_ids" [3376,3398]
===
match
---
name: dag [18591,18594]
name: dag [18497,18500]
===
match
---
operator: , [17572,17573]
operator: , [17478,17479]
===
match
---
operator: = [16507,16508]
operator: = [16413,16414]
===
match
---
operator: , [29857,29858]
operator: , [29763,29764]
===
match
---
operator: , [7454,7455]
operator: , [7454,7455]
===
match
---
name: tzinfo [18241,18247]
name: tzinfo [18147,18153]
===
match
---
operator: = [31144,31145]
operator: = [31050,31051]
===
match
---
operator: , [41967,41968]
operator: , [41873,41874]
===
match
---
operator: , [18598,18599]
operator: , [18504,18505]
===
match
---
argument [37004,37019]
argument [36910,36925]
===
match
---
name: importlib [43805,43814]
name: importlib [44558,44567]
===
match
---
name: pattern [8410,8417]
name: pattern [8410,8417]
===
match
---
name: SerializedDAG [45028,45041]
name: SerializedDAG [45781,45794]
===
match
---
operator: = [32211,32212]
operator: = [32117,32118]
===
match
---
simple_stmt [7906,7916]
simple_stmt [7906,7916]
===
match
---
operator: } [7626,7627]
operator: } [7626,7627]
===
match
---
simple_stmt [33727,33770]
simple_stmt [33633,33676]
===
match
---
operator: - [20304,20305]
operator: - [20210,20211]
===
match
---
number: 0 [23569,23570]
number: 0 [23475,23476]
===
match
---
operator: = [16300,16301]
operator: = [16206,16207]
===
match
---
name: start_date [36722,36732]
name: start_date [36628,36638]
===
match
---
name: mode [39688,39692]
name: mode [39594,39598]
===
match
---
atom_expr [37242,37281]
atom_expr [37148,37187]
===
match
---
name: dag [8589,8592]
name: dag [8589,8592]
===
match
---
operator: { [29827,29828]
operator: { [29733,29734]
===
match
---
name: patch [43913,43918]
name: patch [44666,44671]
===
match
---
operator: , [39390,39391]
operator: , [39296,39297]
===
match
---
string: "_task_module" [3885,3899]
string: "_task_module" [3885,3899]
===
match
---
string: "pool" [3943,3949]
string: "pool" [3943,3949]
===
match
---
argument [16294,16313]
argument [16200,16219]
===
match
---
name: expected_schedule_interval [20127,20153]
name: expected_schedule_interval [20033,20059]
===
match
---
simple_stmt [1127,1167]
simple_stmt [1127,1167]
===
match
---
operator: { [30220,30221]
operator: { [30126,30127]
===
match
---
simple_stmt [29442,29481]
simple_stmt [29348,29387]
===
match
---
name: edge_info [39281,39290]
name: edge_info [39187,39196]
===
match
---
trailer [27125,27132]
trailer [27031,27038]
===
match
---
trailer [14279,14320]
trailer [14185,14226]
===
match
---
operator: , [8224,8225]
operator: , [8224,8225]
===
match
---
string: 'https://console.cloud.google.com/bigquery?j=dummy_value_1' [28399,28458]
string: 'https://console.cloud.google.com/bigquery?j=dummy_value_1' [28305,28364]
===
match
---
trailer [11763,11773]
trailer [11763,11773]
===
match
---
string: 'on_failure_callback' [14791,14812]
string: 'on_failure_callback' [14697,14718]
===
match
---
name: to_dict [45042,45049]
name: to_dict [45795,45802]
===
match
---
name: child [38308,38313]
name: child [38214,38219]
===
match
---
name: kwargs [29177,29183]
name: kwargs [29083,29089]
===
match
---
name: DAG [11769,11772]
name: DAG [11769,11772]
===
match
---
name: name [7607,7611]
name: name [7607,7611]
===
match
---
atom [41323,41334]
atom [41229,41240]
===
match
---
name: deserialized_test_task [32315,32337]
name: deserialized_test_task [32221,32243]
===
match
---
atom [25592,25609]
atom [25498,25515]
===
match
---
arglist [24407,24438]
arglist [24313,24344]
===
match
---
name: test_serialize_sensor [39416,39437]
name: test_serialize_sensor [39322,39343]
===
match
---
return_stmt [7261,7306]
return_stmt [7261,7306]
===
match
---
string: """         Tests edge_info serialization/deserialization.         """ [38473,38543]
string: """         Tests edge_info serialization/deserialization.         """ [38379,38449]
===
match
---
expr_stmt [22172,22202]
expr_stmt [22078,22108]
===
match
---
param [40212,40217]
param [40118,40123]
===
match
---
simple_stmt [41000,41062]
simple_stmt [40906,40968]
===
match
---
trailer [17990,17994]
trailer [17896,17900]
===
match
---
string: 'airflow' [6618,6627]
string: 'airflow' [6618,6627]
===
match
---
simple_stmt [21822,21877]
simple_stmt [21728,21783]
===
match
---
string: '_inlets' [34224,34233]
string: '_inlets' [34130,34139]
===
match
---
arglist [17889,17920]
arglist [17795,17826]
===
match
---
string: "max_retry_delay" [3304,3321]
string: "max_retry_delay" [3304,3321]
===
match
---
operator: , [35653,35654]
operator: , [35559,35560]
===
match
---
operator: , [42547,42548]
operator: , [42453,42454]
===
match
---
operator: , [5960,5961]
operator: , [5960,5961]
===
match
---
name: k [13645,13646]
name: k [13551,13552]
===
match
---
trailer [16099,16132]
trailer [16005,16038]
===
match
---
funcdef [24892,26280]
funcdef [24798,26186]
===
match
---
name: start [11554,11559]
name: start [11554,11559]
===
match
---
expr_stmt [19030,19075]
expr_stmt [18936,18981]
===
match
---
operator: , [25639,25640]
operator: , [25545,25546]
===
match
---
operator: , [3402,3403]
operator: , [3402,3403]
===
match
---
name: dag_id [41849,41855]
name: dag_id [41755,41761]
===
match
---
name: full_filepath [14057,14070]
name: full_filepath [13963,13976]
===
match
---
atom_expr [18188,18200]
atom_expr [18094,18106]
===
match
---
comparison [15025,15090]
comparison [14931,14996]
===
match
---
string: "foo1" [29985,29991]
string: "foo1" [29891,29897]
===
match
---
operator: = [28134,28135]
operator: = [28040,28041]
===
match
---
dictorsetmaker [21953,21973]
dictorsetmaker [21859,21879]
===
match
---
name: serialized_task [14966,14981]
name: serialized_task [14872,14887]
===
match
---
expr_stmt [18633,18676]
expr_stmt [18539,18582]
===
match
---
trailer [32366,32374]
trailer [32272,32280]
===
match
---
name: deserialized_dag [22527,22543]
name: deserialized_dag [22433,22449]
===
match
---
param [19513,19518]
param [19419,19424]
===
match
---
name: self [22782,22786]
name: self [22688,22692]
===
match
---
trailer [29183,29189]
trailer [29089,29095]
===
match
---
trailer [18469,18546]
trailer [18375,18452]
===
match
---
name: simple_task [24347,24358]
name: simple_task [24253,24264]
===
match
---
name: x [10748,10749]
name: x [10748,10749]
===
match
---
atom_expr [17908,17920]
atom_expr [17814,17826]
===
match
---
name: serialized_dag [25984,25998]
name: serialized_dag [25890,25904]
===
match
---
atom_expr [1916,1968]
atom_expr [1916,1968]
===
match
---
trailer [17774,17779]
trailer [17680,17685]
===
match
---
atom_expr [27111,27144]
atom_expr [27017,27050]
===
match
---
atom_expr [43746,43789]
atom_expr [44499,44542]
===
match
---
name: timedelta [947,956]
name: timedelta [947,956]
===
match
---
operator: , [14355,14356]
operator: , [14261,14262]
===
match
---
string: """         Additional Properties are disabled on DAGs. This test verifies that all the         keys in DAG.get_serialized_fields are listed in Schema definition.         """ [32519,32693]
string: """         Additional Properties are disabled on DAGs. This test verifies that all the         keys in DAG.get_serialized_fields are listed in Schema definition.         """ [32425,32599]
===
match
---
name: expand [16060,16066]
name: expand [15966,15972]
===
match
---
simple_stmt [24828,24887]
simple_stmt [24734,24793]
===
match
---
name: template_fields [15045,15060]
name: template_fields [14951,14966]
===
match
---
import_from [916,966]
import_from [916,966]
===
match
---
string: 'downstream' [35682,35694]
string: 'downstream' [35588,35600]
===
match
---
sync_comp_for [44516,44587]
sync_comp_for [45269,45340]
===
match
---
trailer [5476,5492]
trailer [5476,5492]
===
match
---
atom [20643,20732]
atom [20549,20638]
===
match
---
name: att2 [30449,30453]
name: att2 [30355,30359]
===
match
---
string: "att3" [31078,31084]
string: "att3" [30984,30990]
===
match
---
comparison [28634,28716]
comparison [28540,28622]
===
match
---
string: '' [2714,2716]
string: '' [2714,2716]
===
match
---
name: SerializedDAG [8821,8834]
name: SerializedDAG [8821,8834]
===
match
---
name: dag [7231,7234]
name: dag [7231,7234]
===
match
---
suite [7252,7307]
suite [7252,7307]
===
match
---
trailer [23610,23626]
trailer [23516,23532]
===
match
---
name: dags [8434,8438]
name: dags [8434,8438]
===
match
---
atom_expr [41989,42009]
atom_expr [41895,41915]
===
match
---
operator: , [19957,19958]
operator: , [19863,19864]
===
match
---
operator: , [40241,40242]
operator: , [40147,40148]
===
match
---
simple_stmt [21206,21284]
simple_stmt [21112,21190]
===
match
---
name: field [13114,13119]
name: field [13160,13165]
===
match
---
operator: == [15062,15064]
operator: == [14968,14970]
===
match
---
name: parameterized [39297,39310]
name: parameterized [39203,39216]
===
match
---
dotted_name [1336,1363]
dotted_name [1336,1363]
===
match
---
operator: , [35611,35612]
operator: , [35517,35518]
===
match
---
expr_stmt [32972,33027]
expr_stmt [32878,32933]
===
match
---
trailer [27064,27072]
trailer [26970,26978]
===
match
---
name: task_start_date [16675,16690]
name: task_start_date [16581,16596]
===
match
---
expr_stmt [17344,17386]
expr_stmt [17250,17292]
===
match
---
atom [2868,2870]
atom [2868,2870]
===
match
---
operator: = [16241,16242]
operator: = [16147,16148]
===
match
---
string: "dag" [10686,10691]
string: "dag" [10686,10691]
===
match
---
expr_stmt [20817,20859]
expr_stmt [20723,20765]
===
match
---
trailer [11934,11936]
trailer [11934,11936]
===
match
---
expr_stmt [19621,19983]
expr_stmt [19527,19889]
===
match
---
name: children [38317,38325]
name: children [38223,38231]
===
match
---
atom [4776,4830]
atom [4776,4830]
===
match
---
string: "max_retry_delay" [6072,6089]
string: "max_retry_delay" [6072,6089]
===
match
---
param [21178,21182]
param [21084,21088]
===
match
---
argument [26985,26992]
argument [26891,26898]
===
match
---
atom [19745,19747]
atom [19651,19653]
===
match
---
operator: , [18522,18523]
operator: , [18428,18429]
===
match
---
testlist_comp [17831,17921]
testlist_comp [17737,17827]
===
match
---
assert_stmt [32383,32455]
assert_stmt [32289,32361]
===
match
---
string: 'do_xcom_push' [34397,34411]
string: 'do_xcom_push' [34303,34317]
===
match
---
testlist_comp [5436,5492]
testlist_comp [5436,5492]
===
match
---
operator: == [14992,14994]
operator: == [14898,14900]
===
match
---
name: val [22263,22266]
name: val [22169,22172]
===
match
---
param [40218,40242]
param [40124,40148]
===
match
---
operator: { [2511,2512]
operator: { [2511,2512]
===
match
---
testlist_comp [41324,41333]
testlist_comp [41230,41239]
===
match
---
operator: , [36720,36721]
operator: , [36626,36627]
===
match
---
operator: { [15411,15412]
operator: { [15317,15318]
===
match
---
arglist [26896,26937]
arglist [26802,26843]
===
match
---
atom [21934,21936]
atom [21840,21842]
===
match
---
name: from_json [11721,11730]
name: from_json [11721,11730]
===
match
---
operator: = [16768,16769]
operator: = [16674,16675]
===
match
---
atom_expr [29311,29329]
atom_expr [29217,29235]
===
match
---
number: 2019 [16282,16286]
number: 2019 [16188,16192]
===
match
---
trailer [13771,13780]
trailer [13677,13686]
===
match
---
name: resources [15521,15530]
name: resources [15427,15436]
===
match
---
string: "__var" [2409,2416]
string: "__var" [2409,2416]
===
match
---
atom_expr [13617,13647]
atom_expr [13523,13553]
===
match
---
arglist [41998,42008]
arglist [41904,41914]
===
match
---
operator: , [7795,7796]
operator: , [7795,7796]
===
match
---
string: "has_on_success_callback" [32910,32935]
string: "has_on_success_callback" [32816,32841]
===
match
---
string: "hi" [41296,41300]
string: "hi" [41202,41206]
===
match
---
string: '_downstream_task_ids' [34181,34203]
string: '_downstream_task_ids' [34087,34109]
===
match
---
parameters [17499,17505]
parameters [17405,17411]
===
match
---
funcdef [43585,43898]
funcdef [44338,44651]
===
match
---
simple_stmt [33509,33542]
simple_stmt [33415,33448]
===
match
---
name: permissions [1479,1490]
name: permissions [1479,1490]
===
match
---
simple_stmt [36986,37021]
simple_stmt [36892,36927]
===
match
---
operator: , [4394,4395]
operator: , [4394,4395]
===
match
---
trailer [32140,32186]
trailer [32046,32092]
===
match
---
trailer [20949,20961]
trailer [20855,20867]
===
match
---
name: collect_dags [7838,7850]
name: collect_dags [7838,7850]
===
match
---
name: task_id [15417,15424]
name: task_id [15323,15330]
===
match
---
operator: = [16359,16360]
operator: = [16265,16266]
===
match
---
atom_expr [6038,6058]
atom_expr [6038,6058]
===
match
---
name: do_xcom_push [33560,33572]
name: do_xcom_push [33466,33478]
===
match
---
comparison [22389,22434]
comparison [22295,22340]
===
match
---
number: 300.0 [3281,3286]
number: 300.0 [3281,3286]
===
match
---
atom_expr [14396,14426]
atom_expr [14302,14332]
===
match
---
arglist [12058,12096]
arglist [12058,12096]
===
match
---
operator: { [29660,29661]
operator: { [29566,29567]
===
match
---
comparison [18973,19020]
comparison [18879,18926]
===
match
---
operator: , [22254,22255]
operator: , [22160,22161]
===
match
---
name: to_dict [16906,16913]
name: to_dict [16812,16819]
===
match
---
arglist [18169,18200]
arglist [18075,18106]
===
match
---
simple_stmt [26239,26280]
simple_stmt [26145,26186]
===
match
---
for_stmt [12369,12540]
for_stmt [12369,12540]
===
match
---
name: dag [22349,22352]
name: dag [22255,22258]
===
match
---
name: self [12575,12579]
name: self [12575,12579]
===
match
---
parameters [33370,33406]
parameters [33276,33312]
===
match
---
if_stmt [15824,16040]
if_stmt [15730,15946]
===
match
---
name: datetime [18219,18227]
name: datetime [18125,18133]
===
match
---
trailer [45027,45041]
trailer [45780,45794]
===
match
---
fstring_expr [13290,13297]
fstring_expr [13196,13203]
===
match
---
trailer [29393,29395]
trailer [29299,29301]
===
match
---
name: v [11731,11732]
name: v [11731,11732]
===
match
---
name: dag [38741,38744]
name: dag [38647,38650]
===
match
---
expr_stmt [7906,7915]
expr_stmt [7906,7915]
===
match
---
name: task [15144,15148]
name: task [15050,15054]
===
match
---
name: expected_serialized [37858,37877]
name: expected_serialized [37764,37783]
===
match
---
argument [32157,32185]
argument [32063,32091]
===
match
---
trailer [18168,18201]
trailer [18074,18107]
===
match
---
name: serialized_dag [21521,21535]
name: serialized_dag [21427,21441]
===
match
---
name: TaskStateLink [25593,25606]
name: TaskStateLink [25499,25512]
===
match
---
name: assertLogs [25863,25873]
name: assertLogs [25769,25779]
===
match
---
name: access_control [6294,6308]
name: access_control [6294,6308]
===
match
---
operator: , [2758,2759]
operator: , [2758,2759]
===
match
---
name: SerializedDAG [37301,37314]
name: SerializedDAG [37207,37220]
===
match
---
atom [6323,6381]
atom [6323,6381]
===
match
---
operator: , [5006,5007]
operator: , [5006,5007]
===
match
---
expr_stmt [26886,26938]
expr_stmt [26792,26844]
===
match
---
name: tzinfo [16161,16167]
name: tzinfo [16067,16073]
===
match
---
atom_expr [20923,20961]
atom_expr [20829,20867]
===
match
---
string: "__type" [2246,2254]
string: "__type" [2246,2254]
===
match
---
name: resources [15547,15556]
name: resources [15453,15462]
===
match
---
trailer [30800,30926]
trailer [30706,30832]
===
match
---
with_item [36933,36964]
with_item [36839,36870]
===
match
---
operator: , [17844,17845]
operator: , [17750,17751]
===
match
---
string: "tasks" [19009,19016]
string: "tasks" [18915,18922]
===
match
---
trailer [37365,37391]
trailer [37271,37297]
===
match
---
string: 'operator' [2662,2672]
string: 'operator' [2662,2672]
===
match
---
atom [4408,5216]
atom [4408,5216]
===
match
---
string: """Make DAGs with user defined macros and filters using locally defined methods.      For Webserver, we do not include ``user_defined_macros`` & ``user_defined_filters``.      The examples here test:         (1) functions can be successfully displayed on UI;         (2) templates with function macros have been rendered before serialization.     """ [6843,7193]
string: """Make DAGs with user defined macros and filters using locally defined methods.      For Webserver, we do not include ``user_defined_macros`` & ``user_defined_filters``.      The examples here test:         (1) functions can be successfully displayed on UI;         (2) templates with function macros have been rendered before serialization.     """ [6843,7193]
===
match
---
fstring [15391,15449]
fstring [15297,15355]
===
match
---
trailer [24523,24539]
trailer [24429,24445]
===
match
---
string: "{{ task.task_id }}" [30001,30021]
string: "{{ task.task_id }}" [29907,29927]
===
match
---
number: 30 [16497,16499]
number: 30 [16403,16405]
===
match
---
operator: , [20725,20726]
operator: , [20631,20632]
===
match
---
operator: @ [29562,29563]
operator: @ [29468,29469]
===
match
---
operator: , [43864,43865]
operator: , [44617,44618]
===
match
---
dictorsetmaker [5389,5494]
dictorsetmaker [5389,5494]
===
match
---
atom_expr [6324,6351]
atom_expr [6324,6351]
===
match
---
number: 2019 [16100,16104]
number: 2019 [16006,16010]
===
match
---
trailer [8799,8801]
trailer [8799,8801]
===
match
---
name: ROOT_FOLDER [8396,8407]
name: ROOT_FOLDER [8396,8407]
===
match
---
string: "bash_command" [23714,23728]
string: "bash_command" [23620,23634]
===
match
---
atom [29795,29857]
atom [29701,29763]
===
match
---
operator: = [26969,26970]
operator: = [26875,26876]
===
match
---
testlist_comp [21928,21936]
testlist_comp [21834,21842]
===
match
---
name: SerializedDAG [40850,40863]
name: SerializedDAG [40756,40769]
===
match
---
lambdef [10741,10767]
lambdef [10741,10767]
===
match
---
name: task1 [38758,38763]
name: task1 [38664,38669]
===
match
---
trailer [20843,20854]
trailer [20749,20760]
===
match
---
operator: } [2423,2424]
operator: } [2423,2424]
===
match
---
operator: , [4665,4666]
operator: , [4665,4666]
===
match
---
number: 2019 [16341,16345]
number: 2019 [16247,16251]
===
match
---
operator: , [42489,42490]
operator: , [42395,42396]
===
match
---
suite [38326,38367]
suite [38232,38273]
===
match
---
name: task [15516,15520]
name: task [15422,15426]
===
match
---
argument [9063,9460]
argument [9063,9460]
===
match
---
operator: = [37205,37206]
operator: = [37111,37112]
===
match
---
trailer [39965,39971]
trailer [39871,39877]
===
match
---
atom [42460,42500]
atom [42366,42406]
===
match
---
fstring_end: ' [13312,13313]
fstring_end: ' [13218,13219]
===
match
---
atom_expr [29381,29395]
atom_expr [29287,29301]
===
match
---
atom_expr [44285,44316]
atom_expr [45038,45069]
===
match
---
string: "true" [23444,23450]
string: "true" [23350,23356]
===
match
---
testlist_comp [8202,8323]
testlist_comp [8202,8323]
===
match
---
name: node [37720,37724]
name: node [37626,37630]
===
match
---
simple_stmt [38978,39018]
simple_stmt [38884,38924]
===
match
---
operator: , [43650,43651]
operator: , [44403,44404]
===
match
---
simple_stmt [23384,23452]
simple_stmt [23290,23358]
===
match
---
import_from [38552,38601]
import_from [38458,38507]
===
match
---
operator: = [9075,9076]
operator: = [9075,9076]
===
match
---
name: serialized_dag [21666,21680]
name: serialized_dag [21572,21586]
===
match
---
name: BaseOperator [18555,18567]
name: BaseOperator [18461,18473]
===
match
---
operator: , [30878,30879]
operator: , [30784,30785]
===
match
---
string: 'task_5' [42694,42702]
string: 'task_5' [42600,42608]
===
match
---
comparison [16953,16986]
comparison [16859,16892]
===
match
---
operator: , [30673,30674]
operator: , [30579,30580]
===
match
---
atom_expr [37563,37604]
atom_expr [37469,37510]
===
match
---
operator: = [8746,8747]
operator: = [8746,8747]
===
match
---
name: keys [11930,11934]
name: keys [11930,11934]
===
match
---
operator: } [15432,15433]
operator: } [15338,15339]
===
match
---
dictorsetmaker [29828,29855]
dictorsetmaker [29734,29761]
===
match
---
number: 1 [21417,21418]
number: 1 [21323,21324]
===
match
---
string: "bar" [30035,30040]
string: "bar" [29941,29946]
===
match
---
name: dag_id [11987,11993]
name: dag_id [11987,11993]
===
match
---
trailer [14999,15009]
trailer [14905,14915]
===
match
---
argument [40782,40789]
argument [40688,40695]
===
match
---
expr_stmt [32020,32097]
expr_stmt [31926,32003]
===
match
---
name: serialized_dag [13617,13631]
name: serialized_dag [13523,13537]
===
match
---
name: airflow [1336,1343]
name: airflow [1336,1343]
===
match
---
name: serialize_operator [39756,39774]
name: serialize_operator [39662,39680]
===
match
---
string: """         Test that params work both on Serialized DAGs & Tasks         """ [22086,22163]
string: """         Test that params work both on Serialized DAGs & Tasks         """ [21992,22069]
===
match
---
trailer [37611,37622]
trailer [37517,37528]
===
match
---
name: to_json [12462,12469]
name: to_json [12462,12469]
===
match
---
trailer [12088,12096]
trailer [12088,12096]
===
match
---
operator: } [20469,20470]
operator: } [20375,20376]
===
match
---
operator: = [37118,37119]
operator: = [37024,37025]
===
match
---
dictorsetmaker [3160,4380]
dictorsetmaker [3160,4380]
===
match
---
suite [9565,10043]
suite [9565,10043]
===
match
---
name: serialized_dag [41040,41054]
name: serialized_dag [40946,40960]
===
match
---
simple_stmt [39152,39233]
simple_stmt [39058,39139]
===
match
---
name: datetime [937,945]
name: datetime [937,945]
===
match
---
operator: , [42558,42559]
operator: , [42464,42465]
===
match
---
operator: } [5568,5569]
operator: } [5568,5569]
===
match
---
trailer [10757,10767]
trailer [10757,10767]
===
match
---
name: validate_deserialized_task [14095,14121]
name: validate_deserialized_task [14001,14027]
===
match
---
operator: @ [16045,16046]
operator: @ [15951,15952]
===
match
---
name: __init__ [33362,33370]
name: __init__ [33268,33276]
===
match
---
string: "_outlets" [4719,4729]
string: "_outlets" [4719,4729]
===
match
---
string: "__var" [10908,10915]
string: "__var" [10908,10915]
===
match
---
trailer [5622,5689]
trailer [5622,5689]
===
match
---
name: simple_task [28135,28146]
name: simple_task [28041,28052]
===
match
---
operator: { [21097,21098]
operator: { [21003,21004]
===
match
---
operator: = [39657,39658]
operator: = [39563,39564]
===
match
---
argument [20389,20396]
argument [20295,20302]
===
match
---
name: base_operator [33994,34007]
name: base_operator [33900,33913]
===
match
---
name: name [13760,13764]
name: name [13666,13670]
===
match
---
string: "{{ task.task_id }}" [29759,29779]
string: "{{ task.task_id }}" [29665,29685]
===
match
---
operator: , [12579,12580]
operator: , [12579,12580]
===
match
---
operator: , [25369,25370]
operator: , [25275,25276]
===
match
---
fstring_string: ) [29330,29331]
fstring_string: ) [29236,29237]
===
match
---
simple_stmt [40833,40877]
simple_stmt [40739,40783]
===
match
---
param [20793,20797]
param [20699,20703]
===
match
---
string: "CustomOperator" [5038,5054]
string: "CustomOperator" [5038,5054]
===
match
---
name: name [24564,24568]
name: name [24470,24474]
===
match
---
name: timezone [16508,16516]
name: timezone [16414,16422]
===
match
---
operator: = [32885,32886]
operator: = [32791,32792]
===
match
---
atom_expr [32408,32455]
atom_expr [32314,32361]
===
match
---
operator: , [18173,18174]
operator: , [18079,18080]
===
match
---
name: expected_schedule_interval [19549,19575]
name: expected_schedule_interval [19455,19481]
===
match
---
name: serialized [20074,20084]
name: serialized [19980,19990]
===
match
---
operator: } [5215,5216]
operator: } [5215,5216]
===
match
---
operator: , [40122,40123]
operator: , [40028,40029]
===
match
---
string: "__var" [20337,20344]
string: "__var" [20243,20250]
===
match
---
trailer [33471,33484]
trailer [33377,33390]
===
match
---
fstring_start: f" [8393,8395]
fstring_start: f" [8393,8395]
===
match
---
name: execution_date [7291,7305]
name: execution_date [7291,7305]
===
match
---
string: "weekday" [20578,20587]
string: "weekday" [20484,20493]
===
match
---
simple_stmt [11701,11734]
simple_stmt [11701,11734]
===
match
---
atom [40054,40158]
atom [39960,40064]
===
match
---
operator: , [21176,21177]
operator: , [21082,21083]
===
match
---
testlist_comp [41255,41335]
testlist_comp [41161,41241]
===
match
---
dictorsetmaker [21977,21997]
dictorsetmaker [21883,21903]
===
match
---
name: util [862,866]
name: util [862,866]
===
match
---
name: hooks [1181,1186]
name: hooks [1181,1186]
===
match
---
name: doc_md [6392,6398]
name: doc_md [6392,6398]
===
match
---
operator: , [16836,16837]
operator: , [16742,16743]
===
match
---
argument [22256,22266]
argument [22162,22172]
===
match
---
operator: = [33512,33513]
operator: = [33418,33419]
===
match
---
simple_stmt [32383,32456]
simple_stmt [32289,32362]
===
match
---
trailer [1919,1933]
trailer [1919,1933]
===
match
---
suite [25650,25672]
suite [25556,25578]
===
match
---
atom [27695,27766]
atom [27601,27672]
===
match
---
number: 0 [43658,43659]
number: 0 [44411,44412]
===
match
---
name: to_dict [17767,17774]
name: to_dict [17673,17680]
===
match
---
name: find_spec [44168,44177]
name: find_spec [44921,44930]
===
match
---
atom_expr [21521,21542]
atom_expr [21427,21448]
===
match
---
operator: , [18261,18262]
operator: , [18167,18168]
===
match
---
operator: , [30261,30262]
operator: , [30167,30168]
===
match
---
operator: = [40668,40669]
operator: = [40574,40575]
===
match
---
name: self [31675,31679]
name: self [31581,31585]
===
match
---
string: "{{ task.task_id }}" [30296,30316]
string: "{{ task.task_id }}" [30202,30222]
===
match
---
operator: = [21715,21716]
operator: = [21621,21622]
===
match
---
name: serialized [20023,20033]
name: serialized [19929,19939]
===
match
---
operator: = [40848,40849]
operator: = [40754,40755]
===
match
---
operator: , [20434,20435]
operator: , [20340,20341]
===
match
---
name: executor_config_pod [1735,1754]
name: executor_config_pod [1735,1754]
===
match
---
name: dags [8596,8600]
name: dags [8596,8600]
===
match
---
operator: { [27780,27781]
operator: { [27686,27687]
===
match
---
operator: , [43830,43831]
operator: , [44583,44584]
===
match
---
operator: { [13277,13278]
operator: { [13183,13184]
===
match
---
parameters [21171,21196]
parameters [21077,21102]
===
match
---
name: serialized_dag [42301,42315]
name: serialized_dag [42207,42221]
===
match
---
simple_stmt [38071,38152]
simple_stmt [37977,38058]
===
match
---
operator: , [23310,23311]
operator: , [23216,23217]
===
match
---
operator: , [2579,2580]
operator: , [2579,2580]
===
match
---
trailer [16127,16131]
trailer [16033,16037]
===
match
---
operator: , [42759,42760]
operator: , [42665,42666]
===
match
---
name: dag [17775,17778]
name: dag [17681,17684]
===
match
---
name: task5 [37181,37186]
name: task5 [37087,37092]
===
match
---
trailer [12437,12447]
trailer [12437,12447]
===
match
---
name: simple_task [24764,24775]
name: simple_task [24670,24681]
===
match
---
dotted_name [40024,40044]
dotted_name [39930,39950]
===
match
---
name: group34 [36957,36964]
name: group34 [36863,36870]
===
match
---
operator: = [44151,44152]
operator: = [44904,44905]
===
match
---
expr_stmt [23323,23375]
expr_stmt [23229,23281]
===
match
---
atom_expr [14454,14482]
atom_expr [14360,14388]
===
match
---
string: "airflow/providers/*/example_dags" [12210,12244]
string: "airflow/providers/*/example_dags" [12210,12244]
===
match
---
string: 'simple_task' [23407,23420]
string: 'simple_task' [23313,23326]
===
match
---
number: 1 [18520,18521]
number: 1 [18426,18427]
===
match
---
operator: { [3142,3143]
operator: { [3142,3143]
===
match
---
operator: , [21415,21416]
operator: , [21321,21322]
===
match
---
string: 'task_1' [42664,42672]
string: 'task_1' [42570,42578]
===
match
---
name: received_logs [26012,26025]
name: received_logs [25918,25931]
===
match
---
arglist [36689,36747]
arglist [36595,36653]
===
match
---
name: get_serialized_fields [14459,14480]
name: get_serialized_fields [14365,14386]
===
match
---
trailer [18196,18200]
trailer [18102,18106]
===
match
---
atom_expr [30720,31175]
atom_expr [30626,31081]
===
match
---
name: sorted [10849,10855]
name: sorted [10849,10855]
===
match
---
atom_expr [40103,40114]
atom_expr [40009,40020]
===
match
---
name: multiprocessing [874,889]
name: multiprocessing [874,889]
===
match
---
operator: , [7355,7356]
operator: , [7355,7356]
===
match
---
name: task_id [23399,23406]
name: task_id [23305,23312]
===
match
---
string: 'echo' [7694,7700]
string: 'echo' [7694,7700]
===
match
---
number: 1 [3247,3248]
number: 1 [3247,3248]
===
match
---
name: dag_id [22182,22188]
name: dag_id [22088,22094]
===
match
---
expr_stmt [11830,11873]
expr_stmt [11830,11873]
===
match
---
argument [36791,36806]
argument [36697,36712]
===
match
---
operator: { [42895,42896]
operator: { [43475,43476]
===
match
---
trailer [24069,24094]
trailer [23975,24000]
===
match
---
name: utc [18050,18053]
name: utc [17956,17959]
===
match
---
name: datetime [16420,16428]
name: datetime [16326,16334]
===
match
---
operator: , [4590,4591]
operator: , [4590,4591]
===
match
---
trailer [16805,16865]
trailer [16711,16771]
===
match
---
param [7236,7250]
param [7236,7250]
===
match
---
atom_expr [17247,17280]
atom_expr [17153,17186]
===
match
---
name: field [13051,13056]
name: field [13051,13056]
===
match
---
simple_stmt [20817,20860]
simple_stmt [20723,20766]
===
match
---
name: timezone [18041,18049]
name: timezone [17947,17955]
===
match
---
name: parameterized [16046,16059]
name: parameterized [15952,15965]
===
match
---
operator: , [39697,39698]
operator: , [39603,39604]
===
match
---
name: dag [22247,22250]
name: dag [22153,22156]
===
match
---
operator: = [41953,41954]
operator: = [41859,41860]
===
match
---
atom [30287,30327]
atom [30193,30233]
===
match
---
name: GoogleLink [24803,24813]
name: GoogleLink [24709,24719]
===
match
---
name: values [8793,8799]
name: values [8793,8799]
===
match
---
name: partition [43693,43702]
name: partition [44446,44455]
===
match
---
name: dag [22251,22254]
name: dag [22157,22160]
===
match
---
simple_stmt [43367,43408]
simple_stmt [44120,44161]
===
match
---
operator: = [10847,10848]
operator: = [10847,10848]
===
match
---
name: operators [1415,1424]
name: operators [1415,1424]
===
match
---
string: "__type" [20541,20549]
string: "__type" [20447,20455]
===
match
---
parameters [5852,5854]
parameters [5852,5854]
===
match
---
simple_stmt [27612,27863]
simple_stmt [27518,27769]
===
match
---
string: "task2" [38839,38846]
string: "task2" [38745,38752]
===
match
---
simple_stmt [38473,38544]
simple_stmt [38379,38450]
===
match
---
number: 1 [38734,38735]
number: 1 [38640,38641]
===
match
---
atom [30251,30258]
atom [30157,30164]
===
match
---
operator: @ [40023,40024]
operator: @ [39929,39930]
===
match
---
name: serialize_dag [37477,37490]
name: serialize_dag [37383,37396]
===
match
---
operator: , [2870,2871]
operator: , [2870,2871]
===
match
---
operator: , [34624,34625]
operator: , [34530,34531]
===
match
---
atom [17816,18347]
atom [17722,18253]
===
match
---
name: SerializedDAG [9802,9815]
name: SerializedDAG [9802,9815]
===
match
---
decorated [17785,19189]
decorated [17691,19095]
===
match
---
string: "relativedelta" [20551,20566]
string: "relativedelta" [20457,20472]
===
match
---
operator: } [6381,6382]
operator: } [6381,6382]
===
match
---
trailer [21606,21613]
trailer [21512,21519]
===
match
---
arglist [27274,27301]
arglist [27180,27207]
===
match
---
operator: == [17425,17427]
operator: == [17331,17333]
===
match
---
operator: , [25709,25710]
operator: , [25615,25616]
===
match
---
operator: } [30063,30064]
operator: } [29969,29970]
===
match
---
atom_expr [9479,9491]
atom_expr [9479,9491]
===
match
---
simple_stmt [22527,22586]
simple_stmt [22433,22492]
===
match
---
name: timezone [17908,17916]
name: timezone [17814,17822]
===
match
---
name: task_start_date [16849,16864]
name: task_start_date [16755,16770]
===
match
---
atom_expr [21717,21758]
atom_expr [21623,21664]
===
match
---
param [11117,11121]
param [11117,11121]
===
match
---
number: 1 [17574,17575]
number: 1 [17480,17481]
===
match
---
arglist [7686,7796]
arglist [7686,7796]
===
match
---
trailer [10855,10952]
trailer [10855,10952]
===
match
---
dictorsetmaker [4024,4300]
dictorsetmaker [4024,4300]
===
match
---
string: "https://www.google.com" [28886,28910]
string: "https://www.google.com" [28792,28816]
===
match
---
parameters [41398,41445]
parameters [41304,41351]
===
match
---
comparison [32390,32455]
comparison [32296,32361]
===
match
---
assert_stmt [15297,15449]
assert_stmt [15203,15355]
===
match
---
operator: = [39692,39693]
operator: = [39598,39599]
===
match
---
operator: = [21640,21641]
operator: = [21546,21547]
===
match
---
dictorsetmaker [6776,6793]
dictorsetmaker [6776,6793]
===
match
---
atom_expr [37513,37547]
atom_expr [37419,37453]
===
match
---
operator: } [3723,3724]
operator: } [3723,3724]
===
match
---
trailer [28568,28584]
trailer [28474,28490]
===
match
---
operator: , [3218,3219]
operator: , [3218,3219]
===
match
---
atom [7814,7831]
atom [7814,7831]
===
match
---
string: "tasks" [27641,27648]
string: "tasks" [27547,27554]
===
match
---
string: "_task_group" [13014,13027]
string: "_task_group" [13014,13027]
===
match
---
atom_expr [27160,27199]
atom_expr [27066,27105]
===
match
---
name: self [21172,21176]
name: self [21078,21082]
===
match
---
number: 1 [18178,18179]
number: 1 [18084,18085]
===
match
---
string: "@once" [19330,19337]
string: "@once" [19236,19243]
===
match
---
operator: , [41896,41897]
operator: , [41802,41803]
===
match
---
operator: , [34500,34501]
operator: , [34406,34407]
===
match
---
trailer [19008,19017]
trailer [18914,18923]
===
match
---
string: '__var' [4194,4201]
string: '__var' [4194,4201]
===
match
---
name: os [5668,5670]
name: os [5668,5670]
===
match
---
simple_stmt [8698,8737]
simple_stmt [8698,8737]
===
match
---
atom_expr [8811,8848]
atom_expr [8811,8848]
===
match
---
operator: , [6112,6113]
operator: , [6112,6113]
===
match
---
name: SerializedBaseOperator [14357,14379]
name: SerializedBaseOperator [14263,14285]
===
match
---
operator: = [9667,9668]
operator: = [9667,9668]
===
match
---
name: spec [1819,1823]
name: spec [1819,1823]
===
match
---
expr_stmt [7312,7364]
expr_stmt [7312,7364]
===
match
---
string: "my-vol" [1939,1947]
string: "my-vol" [1939,1947]
===
match
---
trailer [8445,8475]
trailer [8445,8475]
===
match
---
argument [39671,39686]
argument [39577,39592]
===
match
---
param [25381,25385]
param [25287,25291]
===
match
---
trailer [29542,29549]
trailer [29448,29455]
===
match
---
name: serialized_dag [21592,21606]
name: serialized_dag [21498,21512]
===
match
---
string: "start_date" [17231,17243]
string: "start_date" [17137,17149]
===
match
---
atom [19320,19344]
atom [19226,19250]
===
match
---
trailer [43912,43918]
trailer [44665,44671]
===
match
---
operator: = [9492,9493]
operator: = [9492,9493]
===
match
---
name: test_date [26928,26937]
name: test_date [26834,26843]
===
match
---
operator: , [35694,35695]
operator: , [35600,35601]
===
match
---
name: serialized_dag [17320,17334]
name: serialized_dag [17226,17240]
===
match
---
simple_stmt [43798,43898]
simple_stmt [44551,44651]
===
match
---
simple_stmt [9574,9654]
simple_stmt [9574,9654]
===
match
---
operator: , [23429,23430]
operator: , [23335,23336]
===
match
---
expr_stmt [9849,9880]
expr_stmt [9849,9880]
===
match
---
name: task_id [6470,6477]
name: task_id [6470,6477]
===
match
---
name: DummyOperator [36880,36893]
name: DummyOperator [36786,36799]
===
match
---
name: TaskInstance [28117,28129]
name: TaskInstance [28023,28035]
===
match
---
operator: , [23712,23713]
operator: , [23618,23619]
===
match
---
dictorsetmaker [30126,30163]
dictorsetmaker [30032,30069]
===
match
---
operator: } [7558,7559]
operator: } [7558,7559]
===
match
---
atom [29880,29909]
atom [29786,29815]
===
match
---
argument [32065,32096]
argument [31971,32002]
===
match
---
name: dag [13768,13771]
name: dag [13674,13677]
===
match
---
string: 'My Link' [25329,25338]
string: 'My Link' [25235,25244]
===
match
---
number: 0 [27650,27651]
number: 0 [27556,27557]
===
match
---
string: "test_role" [10825,10836]
string: "test_role" [10825,10836]
===
match
---
name: dag_id [8581,8587]
name: dag_id [8581,8587]
===
match
---
trailer [13759,13764]
trailer [13665,13670]
===
match
---
argument [36722,36747]
argument [36628,36653]
===
match
---
trailer [17371,17386]
trailer [17277,17292]
===
match
---
operator: , [22295,22296]
operator: , [22201,22202]
===
match
---
string: "airflow/providers/*/*/example_dags" [8286,8322]
string: "airflow/providers/*/*/example_dags" [8286,8322]
===
match
---
arglist [23303,23313]
arglist [23209,23219]
===
match
---
operator: { [4408,4409]
operator: { [4408,4409]
===
match
---
name: dag [26989,26992]
name: dag [26895,26898]
===
match
---
trailer [37346,37351]
trailer [37252,37257]
===
match
---
operator: , [27989,27990]
operator: , [27895,27896]
===
match
---
operator: , [19257,19258]
operator: , [19163,19164]
===
match
---
atom_expr [21298,21334]
atom_expr [21204,21240]
===
match
---
trailer [11553,11559]
trailer [11553,11559]
===
match
---
operator: , [18299,18300]
operator: , [18205,18206]
===
match
---
name: task_start_date [16971,16986]
name: task_start_date [16877,16892]
===
match
---
decorator [19194,19457]
decorator [19100,19363]
===
match
---
name: V1PodSpec [1828,1837]
name: V1PodSpec [1828,1837]
===
match
---
name: DAG [41845,41848]
name: DAG [41751,41754]
===
match
---
name: DAG [25686,25689]
name: DAG [25592,25595]
===
match
---
name: do_xcom_push [33487,33499]
name: do_xcom_push [33393,33405]
===
match
---
trailer [29471,29480]
trailer [29377,29386]
===
match
---
trailer [44564,44575]
trailer [45317,45328]
===
match
---
testlist_comp [40137,40146]
testlist_comp [40043,40052]
===
match
---
operator: = [7911,7912]
operator: = [7911,7912]
===
match
---
string: "airflow/providers/*/example_dags" [8238,8272]
string: "airflow/providers/*/example_dags" [8238,8272]
===
match
---
operator: , [32935,32936]
operator: , [32841,32842]
===
match
---
name: test_serialization [9540,9558]
name: test_serialization [9540,9558]
===
match
---
param [41430,41444]
param [41336,41350]
===
match
---
operator: = [1780,1781]
operator: = [1780,1781]
===
match
---
name: self [24964,24968]
name: self [24870,24874]
===
match
---
atom_expr [15221,15245]
atom_expr [15127,15151]
===
match
---
param [9559,9563]
param [9559,9563]
===
match
---
name: SerializedDAG [39169,39182]
name: SerializedDAG [39075,39088]
===
match
---
trailer [9049,9470]
trailer [9049,9470]
===
match
---
atom_expr [16301,16313]
atom_expr [16207,16219]
===
match
---
string: 'task_5' [42761,42769]
string: 'task_5' [42667,42675]
===
match
---
trailer [27235,27250]
trailer [27141,27156]
===
match
---
suite [7868,8647]
suite [7868,8647]
===
match
---
trailer [40012,40017]
trailer [39918,39923]
===
match
---
funcdef [6797,7832]
funcdef [6797,7832]
===
match
---
operator: } [32962,32963]
operator: } [32868,32869]
===
match
---
simple_stmt [9014,9471]
simple_stmt [9014,9471]
===
match
---
operator: , [18518,18519]
operator: , [18424,18425]
===
match
---
dictorsetmaker [19701,19958]
dictorsetmaker [19607,19864]
===
match
---
number: 1 [16557,16558]
number: 1 [16463,16464]
===
match
---
name: v [11625,11626]
name: v [11625,11626]
===
match
---
atom [30093,30122]
atom [29999,30028]
===
match
---
dictorsetmaker [12899,13028]
dictorsetmaker [12899,13028]
===
match
---
operator: , [16348,16349]
operator: , [16254,16255]
===
match
---
param [20787,20792]
param [20693,20698]
===
match
---
assert_stmt [14329,14380]
assert_stmt [14235,14286]
===
match
---
operator: , [42837,42838]
operator: , [42743,42744]
===
match
---
simple_stmt [25322,25339]
simple_stmt [25228,25245]
===
match
---
classdef [33314,33500]
classdef [33220,33406]
===
match
---
operator: } [13684,13685]
operator: } [13590,13591]
===
match
---
trailer [8905,8914]
trailer [8905,8914]
===
match
---
name: datetime [23294,23302]
name: datetime [23200,23208]
===
match
---
operator: , [24358,24359]
operator: , [24264,24265]
===
match
---
operator: } [42948,42949]
operator: } [43528,43529]
===
match
---
name: simple_task [28815,28826]
name: simple_task [28721,28732]
===
match
---
name: put [8817,8820]
name: put [8817,8820]
===
match
---
arglist [7351,7362]
arglist [7351,7362]
===
match
---
argument [6708,6748]
argument [6708,6748]
===
match
---
trailer [14458,14480]
trailer [14364,14386]
===
match
---
atom_expr [26028,26048]
atom_expr [25934,25954]
===
match
---
string: 'env' [3632,3637]
string: 'env' [3632,3637]
===
match
---
string: "dag" [10720,10725]
string: "dag" [10720,10725]
===
match
---
atom_expr [39061,39087]
atom_expr [38967,38993]
===
match
---
operator: , [40789,40790]
operator: , [40695,40696]
===
match
---
operator: , [19517,19518]
operator: , [19423,19424]
===
match
---
operator: = [19632,19633]
operator: = [19538,19539]
===
match
---
expr_stmt [21292,21334]
expr_stmt [21198,21240]
===
match
---
comp_op [22477,22483]
comp_op [22383,22389]
===
match
---
name: check_task_group [38343,38359]
name: check_task_group [38249,38265]
===
match
---
atom_expr [29285,29308]
atom_expr [29191,29214]
===
match
---
operator: = [9875,9876]
operator: = [9875,9876]
===
match
---
string: '__type' [4024,4032]
string: '__type' [4024,4032]
===
match
---
name: BashOperator [32128,32140]
name: BashOperator [32034,32046]
===
match
---
name: dag_folder [8047,8057]
name: dag_folder [8047,8057]
===
match
---
name: kubernetes [1088,1098]
name: kubernetes [1088,1098]
===
match
---
name: fileloc [14078,14085]
name: fileloc [13984,13991]
===
match
---
string: """Serialisation / deserialisation continues to work without kubernetes installed""" [43495,43579]
string: """Serialisation / deserialisation continues to work without kubernetes installed""" [44248,44332]
===
match
---
name: dag_id [13282,13288]
name: dag_id [13188,13194]
===
match
---
string: "deps" [39830,39836]
string: "deps" [39736,39742]
===
match
---
simple_stmt [37966,38055]
simple_stmt [37872,37961]
===
match
---
arglist [32085,32095]
arglist [31991,32001]
===
match
---
arglist [28195,28245]
arglist [28101,28151]
===
match
---
trailer [38033,38054]
trailer [37939,37960]
===
match
---
name: callable [13413,13421]
name: callable [13319,13327]
===
match
---
dictorsetmaker [2322,2359]
dictorsetmaker [2322,2359]
===
match
---
name: utc [16369,16372]
name: utc [16275,16278]
===
match
---
name: task [15221,15225]
name: task [15127,15131]
===
match
---
operator: = [21329,21330]
operator: = [21235,21236]
===
match
---
operator: } [30021,30022]
operator: } [29927,29928]
===
match
---
param [29416,29421]
param [29322,29327]
===
match
---
suite [20808,20998]
suite [20714,20904]
===
match
---
suite [21556,21614]
suite [21462,21520]
===
match
---
string: "pool" [5139,5145]
string: "pool" [5139,5145]
===
match
---
string: '"project_id": "mock", ' [9156,9180]
string: '"project_id": "mock", ' [9156,9180]
===
match
---
string: "tasks" [10693,10700]
string: "tasks" [10693,10700]
===
match
---
fstring_expr [29310,29330]
fstring_expr [29216,29236]
===
match
---
name: SerializedDAG [23587,23600]
name: SerializedDAG [23493,23506]
===
match
---
name: DagBag [5788,5794]
name: DagBag [5788,5794]
===
match
---
expr_stmt [39906,39971]
expr_stmt [39812,39877]
===
match
---
operator: } [4828,4829]
operator: } [4828,4829]
===
match
---
dictorsetmaker [30221,30259]
dictorsetmaker [30127,30165]
===
match
---
atom_expr [11803,11813]
atom_expr [11803,11813]
===
match
---
suite [6838,7832]
suite [6838,7832]
===
match
---
argument [31034,31059]
argument [30940,30965]
===
match
---
param [22058,22062]
param [21964,21968]
===
match
---
operator: { [35099,35100]
operator: { [35005,35006]
===
match
---
operator: , [43101,43102]
operator: , [43836,43837]
===
match
---
simple_stmt [27154,27200]
simple_stmt [27060,27106]
===
match
---
trailer [37324,37352]
trailer [37230,37258]
===
match
---
atom_expr [25817,25843]
atom_expr [25723,25749]
===
match
---
trailer [32765,32779]
trailer [32671,32685]
===
match
---
name: DAG [18466,18469]
name: DAG [18372,18375]
===
match
---
operator: , [16153,16154]
operator: , [16059,16060]
===
match
---
assert_stmt [38196,38267]
assert_stmt [38102,38173]
===
match
---
suite [11666,11689]
suite [11666,11689]
===
match
---
operator: = [10702,10703]
operator: = [10702,10703]
===
match
---
assert_stmt [39823,39844]
assert_stmt [39729,39750]
===
match
---
operator: } [5005,5006]
operator: } [5005,5006]
===
match
---
trailer [4229,4250]
trailer [4229,4250]
===
match
---
simple_stmt [22172,22203]
simple_stmt [22078,22109]
===
match
---
string: "timedelta" [2256,2267]
string: "timedelta" [2256,2267]
===
match
---
string: "pod_override" [6658,6672]
string: "pod_override" [6658,6672]
===
match
---
fstring_end: " [8418,8419]
fstring_end: " [8418,8419]
===
match
---
name: timedelta [35318,35327]
name: timedelta [35224,35233]
===
match
---
operator: { [42605,42606]
operator: { [42511,42512]
===
match
---
operator: == [14071,14073]
operator: == [13977,13979]
===
match
---
operator: = [38941,38942]
operator: = [38847,38848]
===
match
---
decorated [40023,41205]
decorated [39929,41111]
===
match
---
comparison [24835,24886]
comparison [24741,24792]
===
match
---
trailer [9737,9743]
trailer [9737,9743]
===
match
---
trailer [12816,12818]
trailer [12816,12818]
===
match
---
comparison [16009,16039]
comparison [15915,15945]
===
match
---
with_stmt [38664,38923]
with_stmt [38570,38829]
===
match
---
operator: , [2907,2908]
operator: , [2907,2908]
===
match
---
name: CustomOpLink [1709,1721]
name: CustomOpLink [1709,1721]
===
match
---
name: expected_val [22063,22075]
name: expected_val [21969,21981]
===
match
---
operator: = [27220,27221]
operator: = [27126,27127]
===
match
---
atom_expr [22279,22299]
atom_expr [22185,22205]
===
match
---
trailer [19059,19075]
trailer [18965,18981]
===
match
---
operator: { [2087,2088]
operator: { [2087,2088]
===
match
---
atom [8564,8630]
atom [8564,8630]
===
match
---
parameters [9558,9564]
parameters [9558,9564]
===
match
---
operator: , [6284,6285]
operator: , [6284,6285]
===
match
---
expr_stmt [26012,26048]
expr_stmt [25918,25954]
===
match
---
operator: { [4071,4072]
operator: { [4071,4072]
===
match
---
name: mode [39444,39448]
name: mode [39350,39354]
===
match
---
name: tuple [8066,8071]
name: tuple [8066,8071]
===
match
---
string: "bar" [30094,30099]
string: "bar" [30000,30005]
===
match
---
operator: == [43711,43713]
operator: == [44464,44466]
===
match
---
name: module [44309,44315]
name: module [45062,45068]
===
match
---
name: import_mock [44525,44536]
name: import_mock [45278,45289]
===
match
---
string: 'simple_task' [17640,17653]
string: 'simple_task' [17546,17559]
===
match
---
trailer [8001,8003]
trailer [8001,8003]
===
match
---
argument [22224,22245]
argument [22130,22151]
===
match
---
operator: = [23647,23648]
operator: = [23553,23554]
===
match
---
simple_stmt [1083,1127]
simple_stmt [1083,1127]
===
match
---
name: get_extra_links [24776,24791]
name: get_extra_links [24682,24697]
===
match
---
trailer [44883,44890]
trailer [45636,45643]
===
match
---
operator: = [33596,33597]
operator: = [33502,33503]
===
match
---
name: self [29355,29359]
name: self [29261,29265]
===
match
---
name: dagbag [5819,5825]
name: dagbag [5819,5825]
===
match
---
operator: { [2321,2322]
operator: { [2321,2322]
===
match
---
atom_expr [13278,13288]
atom_expr [13184,13194]
===
match
---
name: datetime [17831,17839]
name: datetime [17737,17745]
===
match
---
atom_expr [14966,14991]
atom_expr [14872,14897]
===
match
---
string: "_downstream_task_ids" [4608,4630]
string: "_downstream_task_ids" [4608,4630]
===
match
---
name: DummySensor [39659,39670]
name: DummySensor [39565,39576]
===
match
---
string: "bar" [29921,29926]
string: "bar" [29827,29832]
===
match
---
trailer [5590,5595]
trailer [5590,5595]
===
match
---
atom [29593,31614]
atom [29499,31520]
===
match
---
parameters [26344,26350]
parameters [26250,26256]
===
match
---
comparison [41007,41061]
comparison [40913,40967]
===
match
---
trailer [21355,21420]
trailer [21261,21326]
===
match
---
operator: = [21445,21446]
operator: = [21351,21352]
===
match
---
param [8674,8680]
param [8674,8680]
===
match
---
operator: , [16552,16553]
operator: , [16458,16459]
===
match
---
simple_stmt [17224,17281]
simple_stmt [17130,17187]
===
match
---
name: dag [41969,41972]
name: dag [41875,41878]
===
match
---
operator: } [13037,13038]
operator: } [13037,13038]
===
match
---
trailer [41162,41186]
trailer [41068,41092]
===
match
---
string: "params" [22389,22397]
string: "params" [22295,22303]
===
match
---
name: timedelta [6091,6100]
name: timedelta [6091,6100]
===
match
---
simple_stmt [7873,7902]
simple_stmt [7873,7902]
===
match
---
simple_stmt [18966,19021]
simple_stmt [18872,18927]
===
match
---
name: parameterized [29563,29576]
name: parameterized [29469,29482]
===
match
---
fstring_string: Hello  [7615,7621]
fstring_string: Hello  [7615,7621]
===
match
---
string: "properties" [32766,32778]
string: "properties" [32672,32684]
===
match
---
name: tzinfo [18301,18307]
name: tzinfo [18207,18213]
===
match
---
operator: = [26855,26856]
operator: = [26761,26762]
===
match
---
operator: = [18040,18041]
operator: = [17946,17947]
===
match
---
argument [41978,42009]
argument [41884,41915]
===
match
---
name: BashOperator [7664,7676]
name: BashOperator [7664,7676]
===
match
---
name: base [39500,39504]
name: base [39406,39410]
===
match
---
name: BaseOperator [17619,17631]
name: BaseOperator [17525,17537]
===
match
---
atom_expr [8036,8073]
atom_expr [8036,8073]
===
match
---
trailer [8606,8608]
trailer [8606,8608]
===
match
---
atom_expr [39037,39088]
atom_expr [38943,38994]
===
match
---
trailer [45049,45082]
trailer [45802,45835]
===
match
---
string: "foo" [29828,29833]
string: "foo" [29734,29739]
===
match
---
name: self [29315,29319]
name: self [29221,29225]
===
match
---
parameters [12143,12149]
parameters [12143,12149]
===
match
---
operator: = [6714,6715]
operator: = [6714,6715]
===
match
---
string: '__var' [44795,44802]
string: '__var' [45548,45555]
===
match
---
name: task_group [38408,38418]
name: task_group [38314,38324]
===
match
---
string: "tasks" [3119,3126]
string: "tasks" [3119,3126]
===
match
---
name: ImportError [43746,43757]
name: ImportError [44499,44510]
===
match
---
atom [19225,19450]
atom [19131,19356]
===
match
---
lambdef [41280,41301]
lambdef [41186,41207]
===
match
---
name: start_date [40791,40801]
name: start_date [40697,40707]
===
match
---
operator: = [1802,1803]
operator: = [1802,1803]
===
match
---
name: get [11635,11638]
name: get [11635,11638]
===
match
---
atom_expr [43805,43897]
atom_expr [44558,44650]
===
match
---
arglist [14280,14319]
arglist [14186,14225]
===
match
---
name: unittest [8897,8905]
name: unittest [8897,8905]
===
match
---
string: 'bash_command' [3616,3630]
string: 'bash_command' [3616,3630]
===
match
---
name: serialized_dag [22570,22584]
name: serialized_dag [22476,22490]
===
match
---
param [12575,12580]
param [12575,12580]
===
match
---
name: datetime [16332,16340]
name: datetime [16238,16246]
===
match
---
trailer [8820,8848]
trailer [8820,8848]
===
match
---
name: dag_id [7819,7825]
name: dag_id [7819,7825]
===
match
---
name: deserialized_dag [41146,41162]
name: deserialized_dag [41052,41068]
===
match
---
name: serialized_dag [32196,32210]
name: serialized_dag [32102,32116]
===
match
---
trailer [44253,44270]
trailer [45006,45023]
===
match
---
expr_stmt [11701,11733]
expr_stmt [11701,11733]
===
match
---
name: days [20398,20402]
name: days [20304,20308]
===
match
---
argument [38780,38795]
argument [38686,38701]
===
match
---
operator: , [6546,6547]
operator: , [6546,6547]
===
match
---
operator: = [22231,22232]
operator: = [22137,22138]
===
match
---
param [33397,33405]
param [33303,33311]
===
match
---
number: 2019 [16223,16227]
number: 2019 [16129,16133]
===
match
---
name: serialization [1571,1584]
name: serialization [1571,1584]
===
match
---
dictorsetmaker [30229,30258]
dictorsetmaker [30135,30164]
===
match
---
trailer [15416,15424]
trailer [15322,15330]
===
match
---
string: "dag" [19002,19007]
string: "dag" [18908,18913]
===
match
---
name: validate_deserialized_dag [12032,12057]
name: validate_deserialized_dag [12032,12057]
===
match
---
operator: == [39996,39998]
operator: == [39902,39904]
===
match
---
operator: } [29855,29856]
operator: } [29761,29762]
===
match
---
atom_expr [16793,16865]
atom_expr [16699,16771]
===
match
---
name: google_link_from_plugin [28789,28812]
name: google_link_from_plugin [28695,28718]
===
match
---
operator: , [41334,41335]
operator: , [41240,41241]
===
match
---
name: task_group [37612,37622]
name: task_group [37518,37528]
===
match
---
funcdef [10311,10981]
funcdef [10311,10981]
===
match
---
arglist [1772,1987]
arglist [1772,1987]
===
match
---
trailer [13631,13644]
trailer [13537,13550]
===
match
---
name: dag [7268,7271]
name: dag [7268,7271]
===
match
---
number: 2 [18031,18032]
number: 2 [17937,17938]
===
match
---
operator: , [42930,42931]
operator: , [43510,43511]
===
match
---
atom_expr [44489,44515]
atom_expr [45242,45268]
===
match
---
operator: = [23292,23293]
operator: = [23198,23199]
===
match
---
trailer [21743,21758]
trailer [21649,21664]
===
match
---
operator: @ [39296,39297]
operator: @ [39202,39203]
===
match
---
assert_stmt [20868,20897]
assert_stmt [20774,20803]
===
match
---
atom [4731,4733]
atom [4731,4733]
===
match
---
assert_stmt [14035,14085]
assert_stmt [13941,13991]
===
match
---
atom_expr [33668,33717]
atom_expr [33574,33623]
===
match
---
name: get_serialized_fields [33051,33072]
name: get_serialized_fields [32957,32978]
===
match
---
atom_expr [9802,9836]
atom_expr [9802,9836]
===
match
---
arglist [16100,16131]
arglist [16006,16037]
===
match
---
simple_stmt [828,845]
simple_stmt [828,845]
===
match
---
decorated [42397,43457]
decorated [42303,44210]
===
match
---
name: split [10214,10219]
name: split [10214,10219]
===
match
---
name: serialize_operator [38110,38128]
name: serialize_operator [38016,38034]
===
match
---
operator: == [38251,38253]
operator: == [38157,38159]
===
match
---
factor [20355,20357]
factor [20261,20263]
===
match
---
param [33371,33376]
param [33277,33282]
===
match
---
trailer [38407,38418]
trailer [38313,38324]
===
match
---
name: serialized [20817,20827]
name: serialized [20723,20733]
===
match
---
arglist [32141,32185]
arglist [32047,32091]
===
match
---
string: 'Google Custom' [24267,24282]
string: 'Google Custom' [24173,24188]
===
match
---
name: BaseOperator [33181,33193]
name: BaseOperator [33087,33099]
===
match
---
name: value [29168,29173]
name: value [29074,29079]
===
match
---
name: dag [23422,23425]
name: dag [23328,23331]
===
match
---
string: 'operator' [2620,2630]
string: 'operator' [2620,2630]
===
match
---
name: test_date [26845,26854]
name: test_date [26751,26760]
===
match
---
operator: = [28320,28321]
operator: = [28226,28227]
===
match
---
number: 1 [35165,35166]
number: 1 [35071,35072]
===
match
---
name: self [26345,26349]
name: self [26251,26255]
===
match
---
name: importlib [44239,44248]
name: importlib [44992,45001]
===
match
---
operator: = [40801,40802]
operator: = [40707,40708]
===
match
---
name: module_path [5795,5806]
name: module_path [5795,5806]
===
match
---
trailer [28194,28246]
trailer [28100,28152]
===
match
---
name: kwargs [33399,33405]
name: kwargs [33305,33311]
===
match
---
number: 2020 [38725,38729]
number: 2020 [38631,38635]
===
match
---
param [43604,43609]
param [44357,44362]
===
match
---
simple_stmt [10990,11072]
simple_stmt [10990,11072]
===
match
---
string: "simple_task" [21744,21757]
string: "simple_task" [21650,21663]
===
match
---
operator: } [27764,27765]
operator: } [27670,27671]
===
match
---
name: __ne__ [29494,29500]
name: __ne__ [29400,29406]
===
match
---
simple_stmt [43740,43790]
simple_stmt [44493,44543]
===
match
---
atom_expr [18100,18112]
atom_expr [18006,18018]
===
match
---
operator: = [32024,32025]
operator: = [31930,31931]
===
match
---
operator: = [30830,30831]
operator: = [30736,30737]
===
match
---
simple_stmt [7920,7951]
simple_stmt [7920,7951]
===
match
---
trailer [43692,43702]
trailer [44445,44455]
===
match
---
operator: { [34092,34093]
operator: { [33998,33999]
===
match
---
simple_stmt [11416,11514]
simple_stmt [11416,11514]
===
match
---
atom [20711,20730]
atom [20617,20636]
===
match
---
name: dag [7788,7791]
name: dag [7788,7791]
===
match
---
suite [12394,12540]
suite [12394,12540]
===
match
---
operator: , [28227,28228]
operator: , [28133,28134]
===
match
---
name: Connection [1298,1308]
name: Connection [1298,1308]
===
match
---
trailer [43245,43256]
trailer [43998,44009]
===
match
---
name: field [13254,13259]
name: field [13120,13125]
===
match
---
expr_stmt [9479,9498]
expr_stmt [9479,9498]
===
match
---
operator: , [29612,29613]
operator: , [29518,29519]
===
match
---
name: serialized_dag [32291,32305]
name: serialized_dag [32197,32211]
===
match
---
name: self [22052,22056]
name: self [21958,21962]
===
match
---
operator: == [19163,19165]
operator: == [19069,19071]
===
match
---
trailer [41997,42009]
trailer [41903,41915]
===
match
---
trailer [44177,44221]
trailer [44930,44974]
===
match
---
atom_expr [23693,23729]
atom_expr [23599,23635]
===
match
---
name: self [29381,29385]
name: self [29287,29291]
===
match
---
string: "__type" [2101,2109]
string: "__type" [2101,2109]
===
match
---
import_as_names [1293,1330]
import_as_names [1293,1330]
===
match
---
atom [2905,2907]
atom [2905,2907]
===
match
---
name: dict [32714,32718]
name: dict [32620,32624]
===
match
---
string: "__type" [5389,5397]
string: "__type" [5389,5397]
===
match
---
arglist [43826,43896]
arglist [44579,44649]
===
match
---
atom_expr [13768,13785]
atom_expr [13674,13691]
===
match
---
atom_expr [43290,43322]
atom_expr [44043,44075]
===
match
---
assert_stmt [15589,15639]
assert_stmt [15495,15545]
===
match
---
name: name [1888,1892]
name: name [1888,1892]
===
match
---
string: '"database_type": "postgres", ' [9287,9318]
string: '"database_type": "postgres", ' [9287,9318]
===
match
---
name: self [32504,32508]
name: self [32410,32414]
===
match
---
operator: == [20886,20888]
operator: == [20792,20794]
===
match
---
name: is_paused_upon_creation [6255,6278]
name: is_paused_upon_creation [6255,6278]
===
match
---
name: datetime [21399,21407]
name: datetime [21305,21313]
===
match
---
comparison [21509,21542]
comparison [21415,21448]
===
match
---
testlist_comp [11482,11511]
testlist_comp [11482,11511]
===
match
---
param [19549,19576]
param [19455,19482]
===
match
---
name: expand [42412,42418]
name: expand [42318,42324]
===
match
---
string: "#000" [4898,4904]
string: "#000" [4898,4904]
===
match
---
with_item [25686,25750]
with_item [25592,25656]
===
match
---
operator: = [43382,43383]
operator: = [44135,44136]
===
match
---
trailer [11018,11036]
trailer [11018,11036]
===
match
---
string: "foo2" [30026,30032]
string: "foo2" [29932,29938]
===
match
---
funcdef [29117,29235]
funcdef [29023,29141]
===
match
---
operator: == [21787,21789]
operator: == [21693,21695]
===
match
---
expr_stmt [5574,5691]
expr_stmt [5574,5691]
===
match
---
name: utc [18197,18200]
name: utc [18103,18106]
===
match
---
name: queue [8853,8858]
name: queue [8853,8858]
===
match
---
simple_stmt [900,916]
simple_stmt [900,916]
===
match
---
name: json_dag [10082,10090]
name: json_dag [10082,10090]
===
match
---
atom_expr [9765,9789]
atom_expr [9765,9789]
===
match
---
simple_stmt [8557,8631]
simple_stmt [8557,8631]
===
match
---
name: mock_operators [1671,1685]
name: mock_operators [1671,1685]
===
match
---
operator: , [21932,21933]
operator: , [21838,21839]
===
match
---
name: get_task [37926,37934]
name: get_task [37832,37840]
===
match
---
comparison [29449,29480]
comparison [29355,29386]
===
match
---
operator: { [5336,5337]
operator: { [5336,5337]
===
match
---
operator: , [20538,20539]
operator: , [20444,20445]
===
match
---
operator: = [11835,11836]
operator: = [11835,11836]
===
match
---
string: "doc_md" [3042,3050]
string: "doc_md" [3042,3050]
===
match
---
trailer [36688,36748]
trailer [36594,36654]
===
match
---
string: 'email_on_retry' [34638,34654]
string: 'email_on_retry' [34544,34560]
===
match
---
import_from [1208,1265]
import_from [1208,1265]
===
match
---
operator: { [27838,27839]
operator: { [27744,27745]
===
match
---
trailer [29319,29328]
trailer [29225,29234]
===
match
---
string: "tasks" [32901,32908]
string: "tasks" [32807,32814]
===
match
---
trailer [21869,21876]
trailer [21775,21782]
===
match
---
string: 'on_retry_callback' [14861,14880]
string: 'on_retry_callback' [14767,14786]
===
match
---
trailer [12518,12539]
trailer [12518,12539]
===
match
---
suite [15284,15450]
suite [15190,15356]
===
match
---
name: SerializedDAG [37433,37446]
name: SerializedDAG [37339,37352]
===
match
---
name: value [29228,29233]
name: value [29134,29139]
===
match
---
operator: } [6793,6794]
operator: } [6793,6794]
===
match
---
atom_expr [8990,9005]
atom_expr [8990,9005]
===
match
---
name: bash_command [7710,7722]
name: bash_command [7710,7722]
===
match
---
number: 1 [44513,44514]
number: 1 [45266,45267]
===
match
---
atom_expr [39169,39232]
atom_expr [39075,39138]
===
match
---
string: 'airflow' [35066,35075]
string: 'airflow' [34972,34981]
===
match
---
number: 2019 [6234,6238]
number: 2019 [6234,6238]
===
match
---
testlist_comp [42750,42849]
testlist_comp [42656,42755]
===
match
---
parameters [7850,7867]
parameters [7850,7867]
===
match
---
expr_stmt [11786,11820]
expr_stmt [11786,11820]
===
match
---
operator: , [5562,5563]
operator: , [5562,5563]
===
match
---
name: self [36427,36431]
name: self [36333,36337]
===
match
---
operator: = [22262,22263]
operator: = [22168,22169]
===
match
---
operator: = [5947,5948]
operator: = [5947,5948]
===
match
---
operator: , [29698,29699]
operator: , [29604,29605]
===
match
---
string: "test_serialized_template_fields" [32030,32063]
string: "test_serialized_template_fields" [31936,31969]
===
match
---
simple_stmt [40652,40738]
simple_stmt [40558,40644]
===
match
---
atom_expr [1781,1813]
atom_expr [1781,1813]
===
match
---
operator: , [42005,42006]
operator: , [41911,41912]
===
match
---
dotted_name [1455,1471]
dotted_name [1455,1471]
===
match
---
trailer [16222,16255]
trailer [16128,16161]
===
match
---
trailer [38012,38033]
trailer [37918,37939]
===
match
---
name: isinstance [8036,8046]
name: isinstance [8036,8046]
===
match
---
trailer [10764,10766]
trailer [10764,10766]
===
match
---
trailer [37622,37631]
trailer [37528,37537]
===
match
---
operator: = [26890,26891]
operator: = [26796,26797]
===
match
---
trailer [9864,9874]
trailer [9864,9874]
===
match
---
atom_expr [24329,24385]
atom_expr [24235,24291]
===
match
---
operator: , [29636,29637]
operator: , [29542,29543]
===
match
---
suite [25387,25436]
suite [25293,25342]
===
match
---
trailer [26895,26938]
trailer [26801,26844]
===
match
---
assert_stmt [27259,27322]
assert_stmt [27165,27228]
===
match
---
simple_stmt [39632,39645]
simple_stmt [39538,39551]
===
match
---
name: to_json [39075,39082]
name: to_json [38981,38988]
===
match
---
name: dag_dict [10337,10345]
name: dag_dict [10337,10345]
===
match
---
atom [12192,12313]
atom [12192,12313]
===
match
---
simple_stmt [39726,39779]
simple_stmt [39632,39685]
===
match
---
operator: = [37878,37879]
operator: = [37784,37785]
===
match
---
trailer [4215,4229]
trailer [4215,4229]
===
match
---
argument [25690,25709]
argument [25596,25615]
===
match
---
comparison [34092,35715]
comparison [33998,35621]
===
match
---
expr_stmt [33509,33541]
expr_stmt [33415,33447]
===
match
---
argument [21356,21377]
argument [21262,21283]
===
match
---
expr_stmt [10677,10768]
expr_stmt [10677,10768]
===
match
---
dictorsetmaker [27839,27849]
dictorsetmaker [27745,27755]
===
match
---
fstring_end: ' [13718,13719]
fstring_end: ' [13624,13625]
===
match
---
trailer [11638,11640]
trailer [11638,11640]
===
match
---
name: utc [16251,16254]
name: utc [16157,16160]
===
match
---
operator: , [31032,31033]
operator: , [30938,30939]
===
match
---
name: datetime [18279,18287]
name: datetime [18185,18193]
===
match
---
dictorsetmaker [20409,20469]
dictorsetmaker [20315,20375]
===
match
---
name: expected_val [22678,22690]
name: expected_val [22584,22596]
===
match
---
operator: , [8272,8273]
operator: , [8272,8273]
===
match
---
name: CustomOperator [23384,23398]
name: CustomOperator [23290,23304]
===
match
---
name: set [33043,33046]
name: set [32949,32952]
===
match
---
operator: = [43953,43954]
operator: = [44706,44707]
===
match
---
operator: { [5560,5561]
operator: { [5560,5561]
===
match
---
testlist_comp [3142,5217]
testlist_comp [3142,5217]
===
match
---
name: get_extra_links [28569,28584]
name: get_extra_links [28475,28490]
===
match
---
name: task_id [17632,17639]
name: task_id [17538,17545]
===
match
---
number: 8 [17846,17847]
number: 8 [17752,17753]
===
match
---
argument [23333,23352]
argument [23239,23258]
===
match
---
decorated [19194,20234]
decorated [19100,20140]
===
match
---
name: normalized_schedule_interval [20173,20201]
name: normalized_schedule_interval [20079,20107]
===
match
---
string: "{{ task.task_id }}" [29804,29824]
string: "{{ task.task_id }}" [29710,29730]
===
match
---
atom_expr [21845,21876]
atom_expr [21751,21782]
===
match
---
name: V1Container [1876,1887]
name: V1Container [1876,1887]
===
match
---
trailer [5655,5665]
trailer [5655,5665]
===
match
---
expr_stmt [8557,8630]
expr_stmt [8557,8630]
===
match
---
and_test [43673,43726]
and_test [44426,44479]
===
match
---
operator: - [20466,20467]
operator: - [20372,20373]
===
match
---
name: extra_links [24250,24261]
name: extra_links [24156,24167]
===
match
---
name: datetime [16214,16222]
name: datetime [16120,16128]
===
match
---
trailer [8858,8862]
trailer [8858,8862]
===
match
---
trailer [14350,14380]
trailer [14256,14286]
===
match
---
with_item [17520,17605]
with_item [17426,17511]
===
match
---
name: name [24814,24818]
name: name [24720,24724]
===
match
---
operator: , [39383,39384]
operator: , [39289,39290]
===
match
---
trailer [18080,18113]
trailer [17986,18019]
===
match
---
expr_stmt [1991,5572]
expr_stmt [1991,5572]
===
match
---
expr_stmt [39026,39088]
expr_stmt [38932,38994]
===
match
---
trailer [22422,22431]
trailer [22328,22337]
===
match
---
atom_expr [15882,15904]
atom_expr [15788,15810]
===
match
---
atom_expr [17859,17871]
atom_expr [17765,17777]
===
match
---
name: self [33821,33825]
name: self [33727,33731]
===
match
---
string: 'task_2' [42481,42489]
string: 'task_2' [42387,42395]
===
match
---
name: importlib [835,844]
name: importlib [835,844]
===
match
---
name: dag [18460,18463]
name: dag [18366,18369]
===
match
---
operator: , [16159,16160]
operator: , [16065,16066]
===
match
---
operator: , [12595,12596]
operator: , [12595,12596]
===
match
---
name: simple_task [28557,28568]
name: simple_task [28463,28474]
===
match
---
simple_stmt [38343,38367]
simple_stmt [38249,38273]
===
match
---
number: 0 [44496,44497]
number: 0 [45249,45250]
===
match
---
name: task_id [7686,7693]
name: task_id [7686,7693]
===
match
---
string: "has_on_success_callback" [40923,40948]
string: "has_on_success_callback" [40829,40854]
===
match
---
operator: , [6150,6151]
operator: , [6150,6151]
===
match
---
operator: = [22250,22251]
operator: = [22156,22157]
===
match
---
string: 'inlets' [34778,34786]
string: 'inlets' [34684,34692]
===
match
---
assert_stmt [41000,41061]
assert_stmt [40906,40967]
===
match
---
dotted_name [1088,1105]
dotted_name [1088,1105]
===
match
---
simple_stmt [19135,19189]
simple_stmt [19041,19095]
===
match
---
number: 1 [10226,10227]
number: 1 [10226,10227]
===
match
---
name: start_date [17545,17555]
name: start_date [17451,17461]
===
match
---
operator: , [21377,21378]
operator: , [21283,21284]
===
match
---
operator: , [4701,4702]
operator: , [4701,4702]
===
match
---
name: SerializedDAG [27160,27173]
name: SerializedDAG [27066,27079]
===
match
---
operator: = [27049,27050]
operator: = [26955,26956]
===
match
---
string: "__var" [19383,19390]
string: "__var" [19289,19296]
===
match
---
operator: } [13296,13297]
operator: } [13202,13203]
===
match
---
name: serialized_dag [40833,40847]
name: serialized_dag [40739,40753]
===
match
---
simple_stmt [18881,18940]
simple_stmt [18787,18846]
===
match
---
string: "simple_dag" [19777,19789]
string: "simple_dag" [19683,19695]
===
match
---
trailer [13891,13900]
trailer [13797,13806]
===
match
---
funcdef [5833,6795]
funcdef [5833,6795]
===
match
---
name: month [20389,20394]
name: month [20295,20300]
===
match
---
trailer [6180,6193]
trailer [6180,6193]
===
match
---
number: 8 [23309,23310]
number: 8 [23215,23216]
===
match
---
trailer [9815,9831]
trailer [9815,9831]
===
match
---
arglist [15364,15375]
arglist [15270,15281]
===
match
---
param [25365,25370]
param [25271,25276]
===
match
---
name: spec [44146,44150]
name: spec [44899,44903]
===
match
---
atom_expr [16733,16784]
atom_expr [16639,16690]
===
match
---
name: module_from_spec [44254,44270]
name: module_from_spec [45007,45023]
===
match
---
comparison [13230,13273]
comparison [13096,13179]
===
match
---
import_from [36520,36569]
import_from [36426,36475]
===
match
---
arglist [23399,23450]
arglist [23305,23356]
===
match
---
trailer [11802,11814]
trailer [11802,11814]
===
match
---
suite [38464,39291]
suite [38370,39197]
===
match
---
simple_stmt [15297,15450]
simple_stmt [15203,15356]
===
match
---
trailer [22340,22348]
trailer [22246,22254]
===
match
---
dictorsetmaker [42606,42644]
dictorsetmaker [42512,42550]
===
match
---
return_stmt [25404,25435]
return_stmt [25310,25341]
===
match
---
operator: = [41972,41973]
operator: = [41878,41879]
===
match
---
name: serialized_objects [1585,1603]
name: serialized_objects [1585,1603]
===
match
---
atom_expr [36990,37020]
atom_expr [36896,36926]
===
match
---
name: dag [37608,37611]
name: dag [37514,37517]
===
match
---
name: test_dag_serialized_fields_with_schema [32465,32503]
name: test_dag_serialized_fields_with_schema [32371,32409]
===
match
---
operator: , [21937,21938]
operator: , [21843,21844]
===
match
---
string: "has_on_failure_callback" [42194,42219]
string: "has_on_failure_callback" [42100,42125]
===
match
---
trailer [9483,9491]
trailer [9483,9491]
===
match
---
name: fields [35709,35715]
name: fields [35615,35621]
===
match
---
simple_stmt [1016,1030]
simple_stmt [1016,1030]
===
match
---
operator: = [5786,5787]
operator: = [5786,5787]
===
match
---
testlist_comp [30212,30329]
testlist_comp [30118,30235]
===
match
---
trailer [9778,9786]
trailer [9778,9786]
===
match
---
name: maxDiff [9484,9491]
name: maxDiff [9484,9491]
===
match
---
name: dags [9733,9737]
name: dags [9733,9737]
===
match
---
string: 'retry_delay' [35303,35316]
string: 'retry_delay' [35209,35222]
===
match
---
operator: = [39920,39921]
operator: = [39826,39827]
===
match
---
string: "schedule_interval" [19908,19927]
string: "schedule_interval" [19814,19833]
===
match
---
suite [33407,33500]
suite [33313,33406]
===
match
---
operator: , [6009,6010]
operator: , [6009,6010]
===
match
---
atom [42587,42718]
atom [42493,42624]
===
match
---
atom_expr [23384,23451]
atom_expr [23290,23357]
===
match
---
simple_stmt [28112,28174]
simple_stmt [28018,28080]
===
match
---
operator: } [30260,30261]
operator: } [30166,30167]
===
match
---
suite [5729,5831]
suite [5729,5831]
===
match
---
suite [8802,8849]
suite [8802,8849]
===
match
---
trailer [15477,15487]
trailer [15383,15393]
===
match
---
name: airflow [1563,1570]
name: airflow [1563,1570]
===
match
---
operator: == [37605,37607]
operator: == [37511,37513]
===
match
---
atom_expr [37990,38054]
atom_expr [37896,37960]
===
match
---
string: "deps" [39878,39884]
string: "deps" [39784,39790]
===
match
---
decorated [21882,22726]
decorated [21788,22632]
===
match
---
trailer [37003,37020]
trailer [36909,36926]
===
match
---
name: SerializedDAG [1635,1648]
name: SerializedDAG [1635,1648]
===
match
---
atom_expr [1872,1970]
atom_expr [1872,1970]
===
match
---
atom_expr [7955,8004]
atom_expr [7955,8004]
===
match
---
operator: { [30228,30229]
operator: { [30134,30135]
===
match
---
string: "BigQuery Console #2" [28596,28617]
string: "BigQuery Console #2" [28502,28523]
===
match
---
name: serialization [1504,1517]
name: serialization [1504,1517]
===
match
---
string: 'simple_task' [41954,41967]
string: 'simple_task' [41860,41873]
===
match
---
operator: { [21073,21074]
operator: { [20979,20980]
===
match
---
string: 'tests.test_utils.mock_operators.CustomOpLink' [24113,24159]
string: 'tests.test_utils.mock_operators.CustomOpLink' [24019,24065]
===
match
---
testlist_comp [42751,42789]
testlist_comp [42657,42695]
===
match
---
string: '_outlets' [34290,34300]
string: '_outlets' [34196,34206]
===
match
---
number: 1 [19436,19437]
number: 1 [19342,19343]
===
match
---
if_stmt [43670,43790]
if_stmt [44423,44543]
===
match
---
name: name [7622,7626]
name: name [7622,7626]
===
match
---
dotted_name [39484,39504]
dotted_name [39390,39410]
===
match
---
string: "airflow/providers/*/*/example_dags" [12262,12298]
string: "airflow/providers/*/*/example_dags" [12262,12298]
===
match
---
name: _ [37041,37042]
name: _ [36947,36948]
===
match
---
simple_stmt [39906,39972]
simple_stmt [39812,39878]
===
match
---
trailer [5447,5463]
trailer [5447,5463]
===
match
---
trailer [33524,33541]
trailer [33430,33447]
===
match
---
assert_stmt [34085,36387]
assert_stmt [33991,36293]
===
match
---
operator: , [37400,37401]
operator: , [37306,37307]
===
match
---
testlist_comp [39342,39355]
testlist_comp [39248,39261]
===
match
---
name: kubernetes [1221,1231]
name: kubernetes [1221,1231]
===
match
---
comparison [22468,22517]
comparison [22374,22423]
===
match
---
name: _ [36986,36987]
name: _ [36892,36893]
===
match
---
name: validate_deserialized_task [13841,13867]
name: validate_deserialized_task [13747,13773]
===
match
---
name: dummy [38575,38580]
name: dummy [38481,38486]
===
match
---
operator: = [37066,37067]
operator: = [36972,36973]
===
match
---
number: 2019 [18081,18085]
number: 2019 [17987,17991]
===
match
---
operator: { [30279,30280]
operator: { [30185,30186]
===
match
---
operator: { [30287,30288]
operator: { [30193,30194]
===
match
---
trailer [5825,5830]
trailer [5825,5830]
===
match
---
string: """Verify serialized DAGs match the ground truth.""" [10119,10171]
string: """Verify serialized DAGs match the ground truth.""" [10119,10171]
===
match
---
operator: { [30125,30126]
operator: { [30031,30032]
===
match
---
parameters [36426,36432]
parameters [36332,36338]
===
match
---
name: execution_date [36733,36747]
name: execution_date [36639,36653]
===
match
---
suite [41446,42392]
suite [41352,42298]
===
match
---
suite [40987,41062]
suite [40893,40968]
===
match
---
string: 'https://www.google.com' [25411,25435]
string: 'https://www.google.com' [25317,25341]
===
match
---
trailer [38964,38969]
trailer [38870,38875]
===
match
---
operator: , [19419,19420]
operator: , [19325,19326]
===
match
---
name: start_date [32065,32075]
name: start_date [31971,31981]
===
match
---
trailer [37925,37934]
trailer [37831,37840]
===
match
---
name: DummyOperator [37097,37110]
name: DummyOperator [37003,37016]
===
match
---
name: dag [23500,23503]
name: dag [23406,23409]
===
match
---
name: stringified_dags [11786,11802]
name: stringified_dags [11786,11802]
===
match
---
trailer [44924,44942]
trailer [45677,45695]
===
match
---
name: dag [23581,23584]
name: dag [23487,23490]
===
match
---
operator: , [29757,29758]
operator: , [29663,29664]
===
match
---
name: dag_id [12089,12095]
name: dag_id [12089,12095]
===
match
---
simple_stmt [38610,38655]
simple_stmt [38516,38561]
===
match
---
name: MyOperator [25764,25774]
name: MyOperator [25670,25680]
===
match
---
name: pod_generator [1232,1245]
name: pod_generator [1232,1245]
===
match
---
assert_stmt [13223,13313]
assert_stmt [13089,13219]
===
match
---
atom [21952,21974]
atom [21858,21880]
===
match
---
trailer [1887,1970]
trailer [1887,1970]
===
match
---
name: dag [39138,39141]
name: dag [39044,39047]
===
match
---
simple_stmt [14436,14950]
simple_stmt [14342,14856]
===
match
---
string: 'simple_dag' [26903,26915]
string: 'simple_dag' [26809,26821]
===
match
---
string: 'bash_task' [2606,2617]
string: 'bash_task' [2606,2617]
===
match
---
simple_stmt [25667,25672]
simple_stmt [25573,25578]
===
match
---
if_stmt [22362,22518]
if_stmt [22268,22424]
===
match
---
arglist [6527,6749]
arglist [6527,6749]
===
match
---
atom [4071,4299]
atom [4071,4299]
===
match
---
name: BaseOperator [40746,40758]
name: BaseOperator [40652,40664]
===
match
---
operator: } [30022,30023]
operator: } [29928,29929]
===
match
---
simple_stmt [28392,28482]
simple_stmt [28298,28388]
===
match
---
string: "retries" [5997,6006]
string: "retries" [5997,6006]
===
match
---
operator: , [32155,32156]
operator: , [32061,32062]
===
match
---
string: "__var" [2269,2276]
string: "__var" [2269,2276]
===
match
---
operator: } [14948,14949]
operator: } [14854,14855]
===
match
---
argument [18491,18522]
argument [18397,18428]
===
match
---
string: 'github' [28061,28069]
string: 'github' [27967,27975]
===
match
---
operator: , [19826,19827]
operator: , [19732,19733]
===
match
---
name: test_kubernetes_optional [43463,43487]
name: test_kubernetes_optional [44216,44240]
===
match
---
operator: , [31059,31060]
operator: , [30965,30966]
===
match
---
arglist [25874,25931]
arglist [25780,25837]
===
match
---
operator: , [1383,1384]
operator: , [1383,1384]
===
match
---
name: utc [16517,16520]
name: utc [16423,16426]
===
match
---
name: to_dict [22341,22348]
name: to_dict [22247,22254]
===
match
---
assert_stmt [44606,44649]
assert_stmt [45359,45402]
===
match
---
atom_expr [21592,21613]
atom_expr [21498,21519]
===
match
---
operator: @ [41210,41211]
operator: @ [41116,41117]
===
match
---
param [33377,33396]
param [33283,33302]
===
match
---
atom [41324,41326]
atom [41230,41232]
===
match
---
strings [9132,9428]
strings [9132,9428]
===
match
---
number: 0 [24067,24068]
number: 0 [23973,23974]
===
match
---
trailer [16456,16460]
trailer [16362,16366]
===
match
---
trailer [17564,17597]
trailer [17470,17503]
===
match
---
operator: , [19250,19251]
operator: , [19156,19157]
===
match
---
name: k8s [1916,1919]
name: k8s [1916,1919]
===
match
---
dictorsetmaker [6658,6693]
dictorsetmaker [6658,6693]
===
match
---
expr_stmt [43215,43278]
expr_stmt [43968,44031]
===
match
---
string: "__type" [2322,2330]
string: "__type" [2322,2330]
===
match
---
name: dict [10347,10351]
name: dict [10347,10351]
===
match
---
operator: , [22266,22267]
operator: , [22172,22173]
===
match
---
operator: } [4827,4828]
operator: } [4827,4828]
===
match
---
atom [30318,30325]
atom [30224,30231]
===
match
---
operator: = [6188,6189]
operator: = [6188,6189]
===
match
---
name: deserialized_simple_task [21845,21869]
name: deserialized_simple_task [21751,21775]
===
match
---
trailer [32084,32096]
trailer [31990,32002]
===
match
---
name: serialized_dag [39249,39263]
name: serialized_dag [39155,39169]
===
match
---
atom_expr [20830,20859]
atom_expr [20736,20765]
===
match
---
operator: , [6431,6432]
operator: , [6431,6432]
===
match
---
dictorsetmaker [29913,29949]
dictorsetmaker [29819,29855]
===
match
---
string: "relativedelta" [20320,20335]
string: "relativedelta" [20226,20241]
===
match
---
operator: , [29641,29642]
operator: , [29547,29548]
===
match
---
string: "__var" [20436,20443]
string: "__var" [20342,20349]
===
match
---
trailer [23559,23568]
trailer [23465,23474]
===
match
---
name: queue [11482,11487]
name: queue [11482,11487]
===
match
---
string: "simple_dag" [3020,3032]
string: "simple_dag" [3020,3032]
===
match
---
operator: = [24374,24375]
operator: = [24280,24281]
===
match
---
operator: , [17878,17879]
operator: , [17784,17785]
===
match
---
string: 'BigQuery Console #1' [27968,27989]
string: 'BigQuery Console #1' [27874,27895]
===
match
---
dotted_name [36525,36548]
dotted_name [36431,36454]
===
match
---
comparison [21829,21876]
comparison [21735,21782]
===
match
---
operator: } [2359,2360]
operator: } [2359,2360]
===
match
---
string: "'att2': '{{ task.task_id }}', 'template_fields': ['att1']}), " [31326,31389]
string: "'att2': '{{ task.task_id }}', 'template_fields': ['att1']}), " [31232,31295]
===
match
---
operator: = [25815,25816]
operator: = [25721,25722]
===
match
---
string: "{{ task.task_id }}" [31012,31032]
string: "{{ task.task_id }}" [30918,30938]
===
match
---
operator: , [2343,2344]
operator: , [2343,2344]
===
match
---
trailer [40966,40973]
trailer [40872,40879]
===
match
---
param [16659,16674]
param [16565,16580]
===
match
---
dictorsetmaker [42968,43020]
dictorsetmaker [43548,43600]
===
match
---
arglist [14407,14425]
arglist [14313,14331]
===
match
---
argument [39688,39697]
argument [39594,39603]
===
match
---
suite [10353,10981]
suite [10353,10981]
===
match
---
operator: , [19439,19440]
operator: , [19345,19346]
===
match
---
operator: , [34854,34855]
operator: , [34760,34761]
===
match
---
trailer [15311,15335]
trailer [15217,15241]
===
match
---
dotted_name [1563,1603]
dotted_name [1563,1603]
===
match
---
number: 0 [17278,17279]
number: 0 [17184,17185]
===
match
---
simple_stmt [16002,16040]
simple_stmt [15908,15946]
===
match
---
name: simple_task [17344,17355]
name: simple_task [17250,17261]
===
match
---
name: unittest [994,1002]
name: unittest [994,1002]
===
match
---
assert_stmt [24029,24174]
assert_stmt [23935,24080]
===
match
---
trailer [6100,6112]
trailer [6100,6112]
===
match
---
fstring_end: " [29331,29332]
fstring_end: " [29237,29238]
===
match
---
atom_expr [37922,37948]
atom_expr [37828,37854]
===
match
---
string: "ui_fgcolor" [3558,3570]
string: "ui_fgcolor" [3558,3570]
===
match
---
name: containers [1847,1857]
name: containers [1847,1857]
===
match
---
string: "is_subdag" [32888,32899]
string: "is_subdag" [32794,32805]
===
match
---
name: serialized_dag [27619,27633]
name: serialized_dag [27525,27539]
===
match
---
dotted_name [41211,41231]
dotted_name [41117,41137]
===
match
---
atom_expr [23649,23677]
atom_expr [23555,23583]
===
match
---
name: deserialized_dag [22621,22637]
name: deserialized_dag [22527,22543]
===
match
---
argument [25918,25931]
argument [25824,25837]
===
match
---
name: dag [13368,13371]
name: dag [13274,13277]
===
match
---
argument [6255,6284]
argument [6255,6284]
===
match
---
trailer [13390,13392]
trailer [13296,13298]
===
match
---
name: round_tripped [20984,20997]
name: round_tripped [20890,20903]
===
match
---
operator: , [11767,11768]
operator: , [11767,11768]
===
match
---
name: set [27922,27925]
name: set [27828,27831]
===
match
---
operator: , [16461,16462]
operator: , [16367,16368]
===
match
---
operator: } [4276,4277]
operator: } [4276,4277]
===
match
---
comparison [39249,39290]
comparison [39155,39196]
===
match
---
operator: = [20402,20403]
operator: = [20308,20309]
===
match
---
simple_stmt [28627,28717]
simple_stmt [28533,28623]
===
match
---
name: pod_override [44953,44965]
name: pod_override [45706,45718]
===
match
---
name: ignored_keys [33015,33027]
name: ignored_keys [32921,32933]
===
match
---
operator: , [2360,2361]
operator: , [2360,2361]
===
match
---
parameters [18391,18450]
parameters [18297,18356]
===
match
---
operator: } [27765,27766]
operator: } [27671,27672]
===
match
---
testlist_comp [21048,21121]
testlist_comp [20954,21027]
===
match
---
name: serialized_dag [42139,42153]
name: serialized_dag [42045,42059]
===
match
---
name: task_start_date [16934,16949]
name: task_start_date [16840,16855]
===
match
---
string: 'task_2' [42771,42779]
string: 'task_2' [42677,42685]
===
match
---
string: 'email_on_failure' [34600,34618]
string: 'email_on_failure' [34506,34524]
===
match
---
dictorsetmaker [30213,30260]
dictorsetmaker [30119,30166]
===
match
---
string: "bash_task" [3171,3182]
string: "bash_task" [3171,3182]
===
match
---
atom_expr [9865,9873]
atom_expr [9865,9873]
===
match
---
operator: , [16492,16493]
operator: , [16398,16399]
===
match
---
atom [21927,21937]
atom [21833,21843]
===
match
---
name: validate_deserialized_dag [37366,37391]
name: validate_deserialized_dag [37272,37297]
===
match
---
name: dag [12373,12376]
name: dag [12373,12376]
===
match
---
string: "template_fields" [3596,3613]
string: "template_fields" [3596,3613]
===
match
---
trailer [13237,13260]
trailer [13103,13126]
===
match
---
simple_stmt [18633,18677]
simple_stmt [18539,18583]
===
match
---
argument [36894,36909]
argument [36800,36815]
===
match
---
name: datetime [26857,26865]
name: datetime [26763,26771]
===
match
---
trailer [26038,26045]
trailer [25944,25951]
===
match
---
with_stmt [36928,37076]
with_stmt [36834,36982]
===
match
---
atom_expr [15462,15487]
atom_expr [15368,15393]
===
match
---
name: dag [39227,39230]
name: dag [39133,39136]
===
match
---
simple_stmt [27915,28103]
simple_stmt [27821,28009]
===
match
---
operator: = [20534,20535]
operator: = [20440,20441]
===
match
---
operator: , [3109,3110]
operator: , [3109,3110]
===
match
---
name: do_xcom_push [33211,33223]
name: do_xcom_push [33117,33129]
===
match
---
operator: = [11705,11706]
operator: = [11705,11706]
===
match
---
string: "simple_task" [17372,17385]
string: "simple_task" [17278,17291]
===
match
---
name: task_id [32141,32148]
name: task_id [32047,32054]
===
match
---
trailer [45065,45067]
trailer [45818,45820]
===
match
---
string: "task1" [42968,42975]
string: "task1" [43548,43555]
===
match
---
name: object_to_serialized [43103,43123]
name: object_to_serialized [43838,43858]
===
match
---
trailer [17888,17921]
trailer [17794,17827]
===
match
---
operator: , [31175,31176]
operator: , [31081,31082]
===
match
---
testlist_comp [42519,42557]
testlist_comp [42425,42463]
===
match
---
operator: = [23327,23328]
operator: = [23233,23234]
===
match
---
operator: , [35263,35264]
operator: , [35169,35170]
===
match
---
operator: , [30065,30066]
operator: , [29971,29972]
===
match
---
assert_stmt [17395,17452]
assert_stmt [17301,17358]
===
match
---
dictorsetmaker [2101,2440]
dictorsetmaker [2101,2440]
===
match
---
simple_stmt [13497,13537]
simple_stmt [13403,13443]
===
match
---
name: fromlist [43639,43647]
name: fromlist [44392,44400]
===
match
---
operator: , [4318,4319]
operator: , [4318,4319]
===
match
---
suite [13558,13720]
suite [13464,13626]
===
match
---
suite [8122,8159]
suite [8122,8159]
===
match
---
operator: == [15141,15143]
operator: == [15047,15049]
===
match
---
param [32504,32508]
param [32410,32414]
===
match
---
testlist_comp [19239,19440]
testlist_comp [19145,19346]
===
match
---
name: task_dict [17362,17371]
name: task_dict [17268,17277]
===
match
---
number: 8 [16106,16107]
number: 8 [16012,16013]
===
match
---
simple_stmt [24578,24666]
simple_stmt [24484,24572]
===
match
---
arglist [21302,21333]
arglist [21208,21239]
===
match
---
atom_expr [10677,10701]
atom_expr [10677,10701]
===
match
---
trailer [44490,44495]
trailer [45243,45248]
===
match
---
simple_stmt [1450,1491]
simple_stmt [1450,1491]
===
match
---
string: "dag" [17179,17184]
string: "dag" [17085,17090]
===
match
---
with_item [25858,25946]
with_item [25764,25852]
===
match
---
name: dagbag [5779,5785]
name: dagbag [5779,5785]
===
match
---
name: deserialized_simple_task [21690,21714]
name: deserialized_simple_task [21596,21620]
===
match
---
atom_expr [17164,17197]
atom_expr [17070,17103]
===
match
---
name: self [41399,41403]
name: self [41305,41309]
===
match
---
arglist [25690,25742]
arglist [25596,25648]
===
match
---
atom [4113,4277]
atom [4113,4277]
===
match
---
operator: , [24282,24283]
operator: , [24188,24189]
===
match
---
operator: } [20730,20731]
operator: } [20636,20637]
===
match
---
trailer [8392,8420]
trailer [8392,8420]
===
match
---
atom_expr [17753,17779]
atom_expr [17659,17685]
===
match
---
operator: = [18307,18308]
operator: = [18213,18214]
===
match
---
operator: { [20445,20446]
operator: { [20351,20352]
===
match
---
argument [7429,7454]
argument [7429,7454]
===
match
---
string: "dag" [41055,41060]
string: "dag" [40961,40966]
===
match
---
name: mock [43908,43912]
name: mock [44661,44665]
===
match
---
name: to_dict [40864,40871]
name: to_dict [40770,40777]
===
match
---
suite [18953,19021]
suite [18859,18927]
===
match
---
string: "params" [21509,21517]
string: "params" [21415,21423]
===
match
---
operator: , [26870,26871]
operator: , [26776,26777]
===
match
---
number: 1 [42007,42008]
number: 1 [41913,41914]
===
match
---
trailer [12384,12391]
trailer [12384,12391]
===
match
---
name: passed_success_callback [40218,40241]
name: passed_success_callback [40124,40147]
===
match
---
comparison [24234,24314]
comparison [24140,24220]
===
match
---
trailer [8046,8073]
trailer [8046,8073]
===
match
---
number: 2019 [22288,22292]
number: 2019 [22194,22198]
===
match
---
operator: , [3469,3470]
operator: , [3469,3470]
===
match
---
name: minutes [6101,6108]
name: minutes [6101,6108]
===
match
---
name: utc [16457,16460]
name: utc [16363,16366]
===
match
---
operator: = [17981,17982]
operator: = [17887,17888]
===
match
---
name: check_task_group [37652,37668]
name: check_task_group [37558,37574]
===
match
---
operator: , [945,946]
operator: , [945,946]
===
match
---
operator: , [11474,11475]
operator: , [11474,11475]
===
match
---
atom_expr [18906,18939]
atom_expr [18812,18845]
===
match
---
name: dag_dict [10677,10685]
name: dag_dict [10677,10685]
===
match
---
trailer [41113,41129]
trailer [41019,41035]
===
match
---
name: serialized_dag [13238,13252]
name: serialized_dag [13104,13118]
===
match
---
atom_expr [23587,23626]
atom_expr [23493,23532]
===
match
---
string: "foo" [30280,30285]
string: "foo" [30186,30191]
===
match
---
operator: = [41088,41089]
operator: = [40994,40995]
===
match
---
name: expand [20254,20260]
name: expand [20160,20166]
===
match
---
name: relativedelta [1044,1057]
name: relativedelta [1044,1057]
===
match
---
arith_expr [32990,33027]
arith_expr [32896,32933]
===
match
---
atom [21048,21058]
atom [20954,20964]
===
match
---
name: dag [17602,17605]
name: dag [17508,17511]
===
match
---
simple_stmt [23461,23505]
simple_stmt [23367,23411]
===
match
---
name: serialized_dag [12581,12595]
name: serialized_dag [12581,12595]
===
match
---
string: 'pool' [35115,35121]
string: 'pool' [35021,35027]
===
match
---
operator: , [29721,29722]
operator: , [29627,29628]
===
match
---
name: airflow [1173,1180]
name: airflow [1173,1180]
===
match
---
string: "test2" [42995,43002]
string: "test2" [43575,43582]
===
match
---
name: CustomOperator [6455,6469]
name: CustomOperator [6455,6469]
===
match
---
operator: , [13112,13113]
operator: , [13158,13159]
===
match
---
name: deps [39991,39995]
name: deps [39897,39901]
===
match
---
name: SerializedDAG [9765,9778]
name: SerializedDAG [9765,9778]
===
match
---
name: following_schedule [7272,7290]
name: following_schedule [7272,7290]
===
match
---
name: expected [20798,20806]
name: expected [20704,20712]
===
match
---
name: set [11889,11892]
name: set [11889,11892]
===
match
---
operator: } [21094,21095]
operator: } [21000,21001]
===
match
---
string: "test1" [42941,42948]
string: "test1" [43521,43528]
===
match
---
operator: = [36732,36733]
operator: = [36638,36639]
===
match
---
operator: = [38838,38839]
operator: = [38744,38745]
===
match
---
testlist_comp [42461,42499]
testlist_comp [42367,42405]
===
match
---
name: DAG [17520,17523]
name: DAG [17426,17429]
===
match
---
atom [29827,29856]
atom [29733,29762]
===
match
---
name: expand [41225,41231]
name: expand [41131,41137]
===
match
---
assert_stmt [42326,42391]
assert_stmt [42232,42297]
===
match
---
trailer [37058,37075]
trailer [36964,36981]
===
match
---
operator: , [28047,28048]
operator: , [27953,27954]
===
match
---
assert_stmt [21569,21613]
assert_stmt [21475,21519]
===
match
---
operator: , [2542,2543]
operator: , [2542,2543]
===
match
---
string: "dag" [42154,42159]
string: "dag" [42060,42065]
===
match
---
testlist_comp [29634,29640]
testlist_comp [29540,29546]
===
match
---
operator: } [20593,20594]
operator: } [20499,20500]
===
match
---
string: "SubDagOperator" [15845,15861]
string: "SubDagOperator" [15751,15767]
===
match
---
name: ti [28112,28114]
name: ti [28018,28020]
===
match
---
arglist [16223,16254]
arglist [16129,16160]
===
match
---
name: dag_id [13678,13684]
name: dag_id [13584,13590]
===
match
---
argument [23431,23450]
argument [23337,23356]
===
match
---
name: owner [6612,6617]
name: owner [6612,6617]
===
match
---
atom_expr [18987,19020]
atom_expr [18893,18926]
===
match
---
operator: == [28694,28696]
operator: == [28600,28602]
===
match
---
expr_stmt [32867,32963]
expr_stmt [32773,32869]
===
match
---
operator: { [7814,7815]
operator: { [7814,7815]
===
match
---
operator: , [35715,35716]
operator: , [35621,35622]
===
match
---
atom_expr [32213,32239]
atom_expr [32119,32145]
===
match
---
name: collect_dags [12166,12178]
name: collect_dags [12166,12178]
===
match
---
name: unittest [907,915]
name: unittest [907,915]
===
match
---
name: simple_task [24512,24523]
name: simple_task [24418,24429]
===
match
---
atom_expr [16214,16255]
atom_expr [16120,16161]
===
match
---
trailer [17178,17185]
trailer [17084,17091]
===
match
---
string: "airflow" [3209,3218]
string: "airflow" [3209,3218]
===
match
---
atom_expr [23478,23504]
atom_expr [23384,23410]
===
match
---
operator: , [21999,22000]
operator: , [21905,21906]
===
match
---
name: sorted_serialized_dag [10315,10336]
name: sorted_serialized_dag [10315,10336]
===
match
---
argument [1819,1986]
argument [1819,1986]
===
match
---
name: deserialized_dag [41071,41087]
name: deserialized_dag [40977,40993]
===
match
---
name: BaseOperator [34010,34022]
name: BaseOperator [33916,33928]
===
match
---
operator: , [42002,42003]
operator: , [41908,41909]
===
match
---
operator: , [21095,21096]
operator: , [21001,21002]
===
match
---
name: dag_params [32972,32982]
name: dag_params [32878,32888]
===
match
---
string: 'task_5' [42616,42624]
string: 'task_5' [42522,42530]
===
match
---
string: '"instance": "mock", ' [9244,9266]
string: '"instance": "mock", ' [9244,9266]
===
match
---
name: datetime [6225,6233]
name: datetime [6225,6233]
===
match
---
trailer [12031,12057]
trailer [12031,12057]
===
match
---
param [14170,14175]
param [14076,14081]
===
match
---
name: tzinfo [16112,16118]
name: tzinfo [16018,16024]
===
match
---
name: dag [12470,12473]
name: dag [12470,12473]
===
match
---
trailer [27225,27235]
trailer [27131,27141]
===
match
---
atom_expr [10268,10294]
atom_expr [10268,10294]
===
match
---
atom_expr [27051,27077]
atom_expr [26957,26983]
===
match
---
assert_stmt [22671,22725]
assert_stmt [22577,22631]
===
match
---
trailer [16148,16181]
trailer [16054,16087]
===
match
---
string: "tasks" [19844,19851]
string: "tasks" [19750,19757]
===
match
---
name: serialized_dag [37513,37527]
name: serialized_dag [37419,37433]
===
match
---
string: 'airflow' [24284,24293]
string: 'airflow' [24190,24199]
===
match
---
argument [18301,18320]
argument [18207,18226]
===
match
---
simple_stmt [20907,20962]
simple_stmt [20813,20868]
===
match
---
operator: , [28594,28595]
operator: , [28500,28501]
===
match
---
arglist [7388,7653]
arglist [7388,7653]
===
match
---
operator: - [14483,14484]
operator: - [14389,14390]
===
match
---
string: "BashOperator" [3853,3867]
string: "BashOperator" [3853,3867]
===
match
---
operator: { [7590,7591]
operator: { [7590,7591]
===
match
---
string: "test_role" [6310,6321]
string: "test_role" [6310,6321]
===
match
---
argument [5941,5960]
argument [5941,5960]
===
match
---
suite [15576,15640]
suite [15482,15546]
===
match
---
name: loader [44290,44296]
name: loader [45043,45049]
===
match
---
atom_expr [19993,20034]
atom_expr [19899,19940]
===
match
---
operator: >> [37146,37148]
operator: >> [37052,37054]
===
match
---
string: "ERROR" [25924,25931]
string: "ERROR" [25830,25837]
===
match
---
operator: { [20674,20675]
operator: { [20580,20581]
===
match
---
string: "{'att1': '{{ task.task_id }}', 'att2': '{{ task.task_id }}', 'template_fields': ['att1']})" [30581,30673]
string: "{'att1': '{{ task.task_id }}', 'att2': '{{ task.task_id }}', 'template_fields': ['att1']})" [30487,30579]
===
match
---
atom_expr [9076,9460]
atom_expr [9076,9460]
===
match
---
name: days [20299,20303]
name: days [20205,20209]
===
match
---
number: 8 [16554,16555]
number: 8 [16460,16461]
===
match
---
name: timezone [16168,16176]
name: timezone [16074,16082]
===
match
---
atom_expr [15625,15639]
atom_expr [15531,15545]
===
match
---
atom [16196,16388]
atom [16102,16294]
===
match
---
atom [2605,2689]
atom [2605,2689]
===
match
---
name: timedelta [6171,6180]
name: timedelta [6171,6180]
===
match
---
name: expected_task_start_date [16692,16716]
name: expected_task_start_date [16598,16622]
===
match
---
argument [23399,23420]
argument [23305,23326]
===
match
---
name: field [15427,15432]
name: field [15333,15338]
===
match
---
trailer [24775,24791]
trailer [24681,24697]
===
match
---
name: ACTION_CAN_EDIT [5477,5492]
name: ACTION_CAN_EDIT [5477,5492]
===
match
---
import_name [1016,1029]
import_name [1016,1029]
===
match
---
arglist [35328,35334]
arglist [35234,35240]
===
match
---
name: google_link_from_plugin [28914,28937]
name: google_link_from_plugin [28820,28843]
===
match
---
simple_stmt [36769,36808]
simple_stmt [36675,36714]
===
match
---
atom_expr [8748,8772]
atom_expr [8748,8772]
===
match
---
operator: , [18128,18129]
operator: , [18034,18035]
===
match
---
atom_expr [34054,34076]
atom_expr [33960,33982]
===
match
---
simple_stmt [8741,8773]
simple_stmt [8741,8773]
===
match
---
operator: , [16555,16556]
operator: , [16461,16462]
===
match
---
operator: = [22278,22279]
operator: = [22184,22185]
===
match
---
return_stmt [7807,7831]
return_stmt [7807,7831]
===
match
---
string: 'task_4' [42636,42644]
string: 'task_4' [42542,42550]
===
match
---
atom_expr [18160,18201]
atom_expr [18066,18107]
===
match
---
operator: , [42682,42683]
operator: , [42588,42589]
===
match
---
comp_op [39885,39891]
comp_op [39791,39797]
===
match
---
number: 2 [16350,16351]
number: 2 [16256,16257]
===
match
---
name: timedelta [19402,19411]
name: timedelta [19308,19317]
===
match
---
fstring_expr [13699,13702]
fstring_expr [13605,13608]
===
match
---
name: __eq__ [29409,29415]
name: __eq__ [29315,29321]
===
match
---
assert_stmt [15875,15916]
assert_stmt [15781,15822]
===
match
---
name: weekday [20658,20665]
name: weekday [20564,20571]
===
match
---
name: task_group [37528,37538]
name: task_group [37434,37444]
===
match
---
name: dag_id [8565,8571]
name: dag_id [8565,8571]
===
match
---
testlist_comp [16420,16581]
testlist_comp [16326,16487]
===
match
---
operator: , [34237,34238]
operator: , [34143,34144]
===
match
---
operator: , [2284,2285]
operator: , [2284,2285]
===
match
---
number: 8 [17571,17572]
number: 8 [17477,17478]
===
match
---
atom_expr [13509,13536]
atom_expr [13415,13442]
===
match
---
string: "__type" [20310,20318]
string: "__type" [20216,20224]
===
match
---
trailer [12074,12082]
trailer [12074,12082]
===
match
---
dictorsetmaker [30035,30062]
dictorsetmaker [29941,29968]
===
match
---
simple_stmt [14035,14086]
simple_stmt [13941,13992]
===
match
---
dictorsetmaker [19360,19399]
dictorsetmaker [19266,19305]
===
match
---
operator: , [35101,35102]
operator: , [35007,35008]
===
match
---
name: log_output [26028,26038]
name: log_output [25934,25944]
===
match
---
operator: , [20456,20457]
operator: , [20362,20363]
===
match
---
name: to_dict [21461,21468]
name: to_dict [21367,21374]
===
match
---
string: """Serialization and deserialization should work for every DAG and Operator.""" [9574,9653]
string: """Serialization and deserialization should work for every DAG and Operator.""" [9574,9653]
===
match
---
name: make_example_dags [5698,5715]
name: make_example_dags [5698,5715]
===
match
---
name: start_date [26917,26927]
name: start_date [26823,26833]
===
match
---
operator: , [39686,39687]
operator: , [39592,39593]
===
match
---
operator: , [34790,34791]
operator: , [34696,34697]
===
match
---
name: __str__ [29386,29393]
name: __str__ [29292,29299]
===
match
---
atom_expr [22211,22300]
atom_expr [22117,22206]
===
match
---
name: dag [11817,11820]
name: dag [11817,11820]
===
match
---
trailer [27649,27652]
trailer [27555,27558]
===
match
---
string: 'task_4' [42491,42499]
string: 'task_4' [42397,42405]
===
match
---
simple_stmt [36520,36570]
simple_stmt [36426,36476]
===
match
---
operator: , [14566,14567]
operator: , [14472,14473]
===
match
---
atom_expr [15069,15089]
atom_expr [14975,14995]
===
match
---
operator: , [10080,10081]
operator: , [10080,10081]
===
match
---
atom_expr [14074,14085]
atom_expr [13980,13991]
===
match
---
operator: = [18099,18100]
operator: = [18005,18006]
===
match
---
parameters [12574,12601]
parameters [12574,12601]
===
match
---
name: serialize_subprocess [8653,8673]
name: serialize_subprocess [8653,8673]
===
match
---
name: dag_folder [8761,8771]
name: dag_folder [8761,8771]
===
match
---
simple_stmt [11882,11938]
simple_stmt [11882,11938]
===
match
---
name: serialized [20950,20960]
name: serialized [20856,20866]
===
match
---
trailer [23499,23504]
trailer [23405,23410]
===
match
---
operator: } [19971,19972]
operator: } [19877,19878]
===
match
---
atom_expr [13736,13764]
atom_expr [13642,13670]
===
match
---
simple_stmt [32128,32187]
simple_stmt [32034,32093]
===
match
---
name: subdag [15898,15904]
name: subdag [15804,15810]
===
match
---
atom_expr [5788,5807]
atom_expr [5788,5807]
===
match
---
atom_expr [6091,6112]
atom_expr [6091,6112]
===
match
---
name: task2 [38809,38814]
name: task2 [38715,38720]
===
match
---
name: level [43891,43896]
name: level [44644,44649]
===
match
---
atom [2321,2360]
atom [2321,2360]
===
match
---
parameters [22051,22076]
parameters [21957,21982]
===
match
---
funcdef [26285,28938]
funcdef [26191,28844]
===
match
---
expr_stmt [24490,24569]
expr_stmt [24396,24475]
===
match
---
trailer [24813,24818]
trailer [24719,24724]
===
match
---
atom_expr [11522,11533]
atom_expr [11522,11533]
===
match
---
string: 'resources' [14927,14938]
string: 'resources' [14833,14844]
===
match
---
simple_stmt [12611,12765]
simple_stmt [12611,12765]
===
match
---
atom_expr [11925,11936]
atom_expr [11925,11936]
===
match
---
name: setattr [29209,29216]
name: setattr [29115,29122]
===
match
---
name: DAG [7375,7378]
name: DAG [7375,7378]
===
match
---
name: SerializedBaseOperator [39733,39755]
name: SerializedBaseOperator [39639,39661]
===
match
---
string: "#000" [3572,3578]
string: "#000" [3572,3578]
===
match
---
string: '{' [9132,9135]
string: '{' [9132,9135]
===
match
---
string: '_group_id' [2525,2536]
string: '_group_id' [2525,2536]
===
match
---
expr_stmt [37416,37496]
expr_stmt [37322,37402]
===
match
---
name: import_mock [43973,43984]
name: import_mock [44726,44737]
===
match
---
atom_expr [37608,37638]
atom_expr [37514,37544]
===
match
---
operator: = [18532,18533]
operator: = [18438,18439]
===
match
---
trailer [39082,39087]
trailer [38988,38993]
===
match
---
string: "definitions" [32744,32757]
string: "definitions" [32650,32663]
===
match
---
string: "airflow/example_dags" [8202,8224]
string: "airflow/example_dags" [8202,8224]
===
match
---
arglist [6234,6244]
arglist [6234,6244]
===
match
---
suite [43661,43898]
suite [44414,44651]
===
match
---
name: locals [43850,43856]
name: locals [44603,44609]
===
match
---
operator: , [23307,23308]
operator: , [23213,23214]
===
match
---
number: 30 [18297,18299]
number: 30 [18203,18205]
===
match
---
atom_expr [18650,18676]
atom_expr [18556,18582]
===
match
---
name: templated_field [31681,31696]
name: templated_field [31587,31602]
===
match
---
argument [18600,18622]
argument [18506,18528]
===
match
---
string: "task4" [37067,37074]
string: "task4" [36973,36980]
===
match
---
operator: = [43230,43231]
operator: = [43983,43984]
===
match
---
number: 1 [36669,36670]
number: 1 [36575,36576]
===
match
---
factor [20403,20405]
factor [20309,20311]
===
match
---
operator: { [44746,44747]
operator: { [45499,45500]
===
match
---
name: SerializedDAG [42277,42290]
name: SerializedDAG [42183,42196]
===
match
---
expr_stmt [25322,25338]
expr_stmt [25228,25244]
===
match
---
argument [16806,16827]
argument [16712,16733]
===
match
---
arith_expr [12791,13038]
arith_expr [12791,13038]
===
match
---
param [16675,16691]
param [16581,16597]
===
match
---
operator: , [14295,14296]
operator: , [14201,14202]
===
match
---
name: make_user_defined_macro_filter_dag [7967,8001]
name: make_user_defined_macro_filter_dag [7967,8001]
===
match
---
name: children [37539,37547]
name: children [37445,37453]
===
match
---
atom [35041,35043]
atom [34947,34949]
===
match
---
name: operator_extra_links [25569,25589]
name: operator_extra_links [25475,25495]
===
match
---
trailer [10796,10815]
trailer [10796,10815]
===
match
---
suite [31714,32456]
suite [31620,32362]
===
match
---
string: """         Verify that all example DAGs work with DAG Serialization by         checking fields between Serialized Dags & non-Serialized Dags         """ [12611,12764]
string: """         Verify that all example DAGs work with DAG Serialization by         checking fields between Serialized Dags & non-Serialized Dags         """ [12611,12764]
===
match
---
operator: = [21398,21399]
operator: = [21304,21305]
===
match
---
argument [16737,16756]
argument [16643,16662]
===
match
---
atom [41241,41345]
atom [41147,41251]
===
match
---
assert_stmt [19135,19188]
assert_stmt [19041,19094]
===
match
---
suite [28975,29557]
suite [28881,29463]
===
match
---
string: """ !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!       ACTION NEEDED! PLEASE READ THIS CAREFULLY AND CORRECT TESTS CAREFULLY   Some fields were added to the BaseOperator! Please add them to the list above and make sure that  you add support for DAG serialization - you should add the field to  `airflow/serialization/schema.json` - they should have correct type defined there.   Note that we do not support versioning yet so you should only add optional fields to BaseOperator.  !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!                          """ [35717,36387]
string: """ !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!       ACTION NEEDED! PLEASE READ THIS CAREFULLY AND CORRECT TESTS CAREFULLY   Some fields were added to the BaseOperator! Please add them to the list above and make sure that  you add support for DAG serialization - you should add the field to  `airflow/serialization/schema.json` - they should have correct type defined there.   Note that we do not support versioning yet so you should only add optional fields to BaseOperator.  !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!                          """ [35623,36293]
===
match
---
expr_stmt [11416,11513]
expr_stmt [11416,11513]
===
match
---
atom [3142,4394]
atom [3142,4394]
===
match
---
name: fields_to_check [15268,15283]
name: fields_to_check [15174,15189]
===
match
---
operator: , [16314,16315]
operator: , [16220,16221]
===
match
---
return_stmt [29442,29480]
return_stmt [29348,29386]
===
match
---
name: dags [12084,12088]
name: dags [12084,12088]
===
match
---
arglist [24540,24568]
arglist [24446,24474]
===
match
---
name: tzinfo [17975,17981]
name: tzinfo [17881,17887]
===
match
---
atom [29656,29658]
atom [29562,29564]
===
match
---
name: validate_deserialized_dag [39102,39127]
name: validate_deserialized_dag [39008,39033]
===
match
---
simple_stmt [9479,9531]
simple_stmt [9479,9531]
===
match
---
operator: } [19747,19748]
operator: } [19653,19654]
===
match
---
atom [29912,29950]
atom [29818,29856]
===
match
---
operator: == [27303,27305]
operator: == [27209,27211]
===
match
---
name: SerializedDAG [38978,38991]
name: SerializedDAG [38884,38897]
===
match
---
dotted_name [21883,21903]
dotted_name [21789,21809]
===
match
---
simple_stmt [15100,15167]
simple_stmt [15006,15073]
===
match
---
trailer [11399,11405]
trailer [11399,11405]
===
match
---
fstring_expr [8395,8408]
fstring_expr [8395,8408]
===
match
---
string: "10" [34031,34035]
string: "10" [33937,33941]
===
match
---
simple_stmt [27034,27078]
simple_stmt [26940,26984]
===
match
---
except_clause [37755,37776]
except_clause [37661,37682]
===
match
---
operator: == [15218,15220]
operator: == [15124,15126]
===
match
---
funcdef [43058,43457]
funcdef [43793,44210]
===
match
---
testlist_comp [20285,20359]
testlist_comp [20191,20265]
===
match
---
simple_stmt [42187,42249]
simple_stmt [42093,42155]
===
match
---
operator: , [35335,35336]
operator: , [35241,35242]
===
match
---
argument [31129,31156]
argument [31035,31062]
===
match
---
for_stmt [8371,8476]
for_stmt [8371,8476]
===
match
---
operator: = [7693,7694]
operator: = [7693,7694]
===
match
---
import_from [1450,1490]
import_from [1450,1490]
===
match
---
name: serialized_task [15596,15611]
name: serialized_task [15502,15517]
===
match
---
name: timezone [16119,16127]
name: timezone [16025,16033]
===
match
---
name: simple_task [27926,27937]
name: simple_task [27832,27843]
===
match
---
name: expand [21018,21024]
name: expand [20924,20930]
===
match
---
atom [30279,30328]
atom [30185,30234]
===
match
---
atom_expr [42037,42063]
atom_expr [41943,41969]
===
match
---
name: task_end_date [18692,18705]
name: task_end_date [18598,18611]
===
match
---
operator: , [30023,30024]
operator: , [29929,29930]
===
match
---
name: context [39606,39613]
name: context [39512,39519]
===
match
---
name: dags [5826,5830]
name: dags [5826,5830]
===
match
---
trailer [39050,39060]
trailer [38956,38966]
===
match
---
param [39444,39449]
param [39350,39355]
===
match
---
name: deserialized_dag [32248,32264]
name: deserialized_dag [32154,32170]
===
match
---
name: days [19431,19435]
name: days [19337,19341]
===
match
---
atom_expr [8616,8629]
atom_expr [8616,8629]
===
match
---
string: "{{ task.task_id }}" [30101,30121]
string: "{{ task.task_id }}" [30007,30027]
===
match
---
operator: , [36664,36665]
operator: , [36570,36571]
===
match
---
comparison [42333,42391]
comparison [42239,42297]
===
match
---
atom [16090,16182]
atom [15996,16088]
===
match
---
trailer [15122,15140]
trailer [15028,15046]
===
match
---
operator: } [4393,4394]
operator: } [4393,4394]
===
match
---
dictorsetmaker [20347,20357]
dictorsetmaker [20253,20263]
===
match
---
name: field [15329,15334]
name: field [15235,15240]
===
match
---
funcdef [43459,45083]
funcdef [44212,45836]
===
match
---
param [24964,24968]
param [24870,24874]
===
match
---
operator: = [20921,20922]
operator: = [20827,20828]
===
match
---
argument [39699,39715]
argument [39605,39621]
===
match
---
expr_stmt [37709,37742]
expr_stmt [37615,37648]
===
match
---
string: "__type" [20675,20683]
string: "__type" [20581,20589]
===
match
---
comparison [28886,28937]
comparison [28792,28843]
===
match
---
simple_stmt [1266,1331]
simple_stmt [1266,1331]
===
match
---
name: pytest [1023,1029]
name: pytest [1023,1029]
===
match
---
argument [7686,7700]
argument [7686,7700]
===
match
---
name: permissions [6324,6335]
name: permissions [6324,6335]
===
match
---
operator: , [39448,39449]
operator: , [39354,39355]
===
match
---
simple_stmt [38552,38602]
simple_stmt [38458,38508]
===
match
---
atom_expr [45050,45081]
atom_expr [45803,45834]
===
match
---
argument [41898,41923]
argument [41804,41829]
===
match
---
operator: , [12533,12534]
operator: , [12533,12534]
===
match
---
atom_expr [40850,40876]
atom_expr [40756,40782]
===
match
---
parameters [7230,7251]
parameters [7230,7251]
===
match
---
trailer [12492,12518]
trailer [12492,12518]
===
match
---
trailer [39182,39198]
trailer [39088,39104]
===
match
---
trailer [15629,15639]
trailer [15535,15545]
===
match
---
funcdef [20754,20998]
funcdef [20660,20904]
===
match
---
simple_stmt [11786,11821]
simple_stmt [11786,11821]
===
match
---
atom [27681,27862]
atom [27587,27768]
===
match
---
name: to_json [37339,37346]
name: to_json [37245,37252]
===
match
---
string: "retries" [3236,3245]
string: "retries" [3236,3245]
===
match
---
funcdef [31625,32456]
funcdef [31531,32362]
===
match
---
trailer [20063,20073]
trailer [19969,19979]
===
match
---
string: '__type' [44760,44768]
string: '__type' [45513,45521]
===
match
---
number: 8 [25737,25738]
number: 8 [25643,25644]
===
match
---
operator: == [24860,24862]
operator: == [24766,24768]
===
match
---
operator: , [5404,5405]
operator: , [5404,5405]
===
match
---
atom [21034,21131]
atom [20940,21037]
===
match
---
operator: = [42275,42276]
operator: = [42181,42182]
===
match
---
atom [30228,30259]
atom [30134,30165]
===
match
---
trailer [10789,10796]
trailer [10789,10796]
===
match
---
name: relativedelta [20285,20298]
name: relativedelta [20191,20204]
===
match
---
string: "_operator_extra_links" [24070,24093]
string: "_operator_extra_links" [23976,23999]
===
match
---
trailer [5604,5691]
trailer [5604,5691]
===
match
---
atom_expr [16091,16132]
atom_expr [15997,16038]
===
match
---
simple_stmt [37858,37950]
simple_stmt [37764,37856]
===
match
---
expr_stmt [38071,38151]
expr_stmt [37977,38057]
===
match
---
funcdef [14091,16040]
funcdef [13997,15946]
===
match
---
operator: = [17858,17859]
operator: = [17764,17765]
===
match
---
trailer [43825,43897]
trailer [44578,44650]
===
match
---
atom_expr [38869,38888]
atom_expr [38775,38794]
===
match
---
operator: @ [17785,17786]
operator: @ [17691,17692]
===
match
---
trailer [10907,10916]
trailer [10907,10916]
===
match
---
operator: , [16690,16691]
operator: , [16596,16597]
===
match
---
number: 2019 [16429,16433]
number: 2019 [16335,16339]
===
match
---
operator: , [4904,4905]
operator: , [4904,4905]
===
match
---
trailer [35327,35335]
trailer [35233,35241]
===
match
---
number: 4 [20724,20725]
number: 4 [20630,20631]
===
match
---
name: parameterized [21883,21896]
name: parameterized [21789,21802]
===
match
---
argument [30449,30474]
argument [30355,30380]
===
match
---
trailer [9022,9037]
trailer [9022,9037]
===
match
---
argument [30826,30851]
argument [30732,30757]
===
match
---
argument [22182,22201]
argument [22088,22107]
===
match
---
name: v [9728,9729]
name: v [9728,9729]
===
match
---
suite [22369,22435]
suite [22275,22341]
===
match
---
operator: } [20592,20593]
operator: } [20498,20499]
===
match
---
operator: = [43874,43875]
operator: = [44627,44628]
===
match
---
atom [42442,42573]
atom [42348,42479]
===
match
---
parameters [43603,43660]
parameters [44356,44413]
===
match
---
operator: = [11815,11816]
operator: = [11815,11816]
===
match
---
string: "airflow.operators.bash" [3901,3925]
string: "airflow.operators.bash" [3901,3925]
===
match
---
string: 'google' [28083,28091]
string: 'google' [27989,27997]
===
match
---
simple_stmt [37290,37353]
simple_stmt [37196,37259]
===
match
---
number: 86400.0 [19392,19399]
number: 86400.0 [19298,19305]
===
match
---
comparison [15596,15639]
comparison [15502,15545]
===
match
---
atom [30220,30260]
atom [30126,30166]
===
match
---
name: test_extra_serialized_field_and_multiple_operator_links [26289,26344]
name: test_extra_serialized_field_and_multiple_operator_links [26195,26250]
===
match
---
name: DAG [38669,38672]
name: DAG [38575,38578]
===
match
---
arglist [18568,18622]
arglist [18474,18528]
===
match
---
atom [24112,24164]
atom [24018,24070]
===
match
---
atom_expr [6225,6245]
atom_expr [6225,6245]
===
match
---
atom [3685,3724]
atom [3685,3724]
===
match
---
string: "value_1" [21085,21094]
string: "value_1" [20991,21000]
===
match
---
fstring_expr [13277,13289]
fstring_expr [13183,13195]
===
match
---
string: """         Test that templated_fields exists for all Operators in Serialized DAG          Since we don't want to inflate arbitrary python objects (it poses a RCE/security risk etc.)         we want check that non-"basic" objects are turned in to strings after deserializing.         """ [31723,32010]
string: """         Test that templated_fields exists for all Operators in Serialized DAG          Since we don't want to inflate arbitrary python objects (it poses a RCE/security risk etc.)         we want check that non-"basic" objects are turned in to strings after deserializing.         """ [31629,31916]
===
match
---
decorator [39296,39408]
decorator [39202,39314]
===
match
---
string: 'builtins.__import__' [43919,43940]
string: 'builtins.__import__' [44672,44693]
===
match
---
name: serialized_task [15029,15044]
name: serialized_task [14935,14950]
===
match
---
operator: , [12909,12910]
operator: , [12909,12910]
===
match
---
string: '_upstream_task_ids' [34318,34338]
string: '_upstream_task_ids' [34224,34244]
===
match
---
trailer [18663,18671]
trailer [18569,18577]
===
match
---
suite [8693,8869]
suite [8693,8869]
===
match
---
trailer [17523,17598]
trailer [17429,17504]
===
match
---
string: 'simple_dag' [17531,17543]
string: 'simple_dag' [17437,17449]
===
match
---
simple_stmt [39981,40018]
simple_stmt [39887,39924]
===
match
---
trailer [19049,19059]
trailer [18955,18965]
===
match
---
assert_stmt [20970,20997]
assert_stmt [20876,20903]
===
match
---
string: """             Sorts the "tasks" list and "access_control" permissions in the             serialised dag python dictionary. This is needed as the order of             items should not matter but assertEqual would fail if the order of             items changes in the dag dictionary             """ [10366,10664]
string: """             Sorts the "tasks" list and "access_control" permissions in the             serialised dag python dictionary. This is needed as the order of             items should not matter but assertEqual would fail if the order of             items changes in the dag dictionary             """ [10366,10664]
===
match
---
string: 'start_date' [7328,7340]
string: 'start_date' [7328,7340]
===
match
---
name: utc [16177,16180]
name: utc [16083,16086]
===
match
---
simple_stmt [11571,11593]
simple_stmt [11571,11593]
===
match
---
name: SerializedDAG [42037,42050]
name: SerializedDAG [41943,41956]
===
match
---
operator: , [7652,7653]
operator: , [7652,7653]
===
match
---
atom_expr [32076,32096]
atom_expr [31982,32002]
===
match
---
operator: , [39356,39357]
operator: , [39262,39263]
===
match
---
name: op [33640,33642]
name: op [33546,33548]
===
match
---
name: PodGenerator [4203,4215]
name: PodGenerator [4203,4215]
===
match
---
name: x [10758,10759]
name: x [10758,10759]
===
match
---
name: module_path [5716,5727]
name: module_path [5716,5727]
===
match
---
expr_stmt [27034,27077]
expr_stmt [26940,26983]
===
match
---
operator: = [28555,28556]
operator: = [28461,28462]
===
match
---
atom [42663,42703]
atom [42569,42609]
===
match
---
atom_expr [5819,5830]
atom_expr [5819,5830]
===
match
---
simple_stmt [43416,43457]
simple_stmt [44169,44210]
===
match
---
assert_stmt [27915,28102]
assert_stmt [27821,28008]
===
match
---
assert_stmt [18966,19020]
assert_stmt [18872,18926]
===
match
---
trailer [24563,24568]
trailer [24469,24474]
===
match
---
name: json_schema [1518,1529]
name: json_schema [1518,1529]
===
match
---
operator: , [30474,30475]
operator: , [30380,30381]
===
match
---
trailer [37527,37538]
trailer [37433,37444]
===
match
---
string: 'http://google.com/custom_base_link?search=dummy_value_1' [24585,24642]
string: 'http://google.com/custom_base_link?search=dummy_value_1' [24491,24548]
===
match
---
argument [1934,1947]
argument [1934,1947]
===
match
---
name: serialized_dag [16875,16889]
name: serialized_dag [16781,16795]
===
match
---
trailer [29216,29234]
trailer [29122,29140]
===
match
---
simple_stmt [11522,11541]
simple_stmt [11522,11541]
===
match
---
operator: } [8407,8408]
operator: } [8407,8408]
===
match
---
dictorsetmaker [30094,30121]
dictorsetmaker [30000,30027]
===
match
---
trailer [27132,27141]
trailer [27038,27047]
===
match
---
name: context [25641,25648]
name: context [25547,25554]
===
match
---
trailer [39774,39778]
trailer [39680,39684]
===
match
---
operator: { [40069,40070]
operator: { [39975,39976]
===
match
---
operator: , [5493,5494]
operator: , [5493,5494]
===
match
---
operator: } [40114,40115]
operator: } [40020,40021]
===
match
---
atom [29872,29910]
atom [29778,29816]
===
match
---
string: "dag" [27126,27131]
string: "dag" [27032,27037]
===
match
---
atom_expr [19421,19438]
atom_expr [19327,19344]
===
match
---
string: "bash_command" [23520,23534]
string: "bash_command" [23426,23440]
===
match
---
simple_stmt [11549,11562]
simple_stmt [11549,11562]
===
match
---
parameters [29354,29360]
parameters [29260,29266]
===
match
---
dictorsetmaker [4426,5202]
dictorsetmaker [4426,5202]
===
match
---
trailer [13677,13684]
trailer [13583,13590]
===
match
---
name: has_on_success_callback [41163,41186]
name: has_on_success_callback [41069,41092]
===
match
---
atom_expr [16539,16580]
atom_expr [16445,16486]
===
match
---
import_name [890,899]
import_name [890,899]
===
match
---
fstring [13275,13313]
fstring [13181,13219]
===
match
---
name: TaskGroup [36825,36834]
name: TaskGroup [36731,36740]
===
match
---
trailer [5638,5666]
trailer [5638,5666]
===
match
---
param [39450,39468]
param [39356,39374]
===
match
---
simple_stmt [22671,22726]
simple_stmt [22577,22632]
===
match
---
param [19519,19548]
param [19425,19454]
===
match
---
name: importlib [44153,44162]
name: importlib [44906,44915]
===
match
---
expr_stmt [40833,40876]
expr_stmt [40739,40782]
===
match
---
name: serialized_obj [43339,43353]
name: serialized_obj [44092,44106]
===
match
---
dotted_name [20240,20260]
dotted_name [20146,20166]
===
match
---
number: 2019 [17840,17844]
number: 2019 [17746,17750]
===
match
---
operator: , [8322,8323]
operator: , [8322,8323]
===
match
---
name: set [34205,34208]
name: set [34111,34114]
===
match
---
string: 'k8s.V1Pod' [4153,4164]
string: 'k8s.V1Pod' [4153,4164]
===
match
---
param [31698,31712]
param [31604,31618]
===
match
---
dictorsetmaker [20712,20729]
dictorsetmaker [20618,20635]
===
match
---
operator: == [15336,15338]
operator: == [15242,15244]
===
match
---
trailer [36790,36807]
trailer [36696,36713]
===
match
---
number: 1 [20404,20405]
number: 1 [20310,20311]
===
match
---
name: task_id [21356,21363]
name: task_id [21262,21269]
===
match
---
operator: , [43848,43849]
operator: , [44601,44602]
===
match
---
name: relativedelta [20375,20388]
name: relativedelta [20281,20294]
===
match
---
param [10082,10091]
param [10082,10091]
===
match
---
simple_stmt [7807,7832]
simple_stmt [7807,7832]
===
match
---
raise_stmt [43740,43789]
raise_stmt [44493,44542]
===
match
---
operator: { [2385,2386]
operator: { [2385,2386]
===
match
---
simple_stmt [31723,32011]
simple_stmt [31629,31917]
===
match
---
name: expected_value [41190,41204]
name: expected_value [41096,41110]
===
match
---
number: 0 [35288,35289]
number: 0 [35194,35195]
===
match
---
name: pardir [5671,5677]
name: pardir [5671,5677]
===
match
---
operator: , [5227,5228]
operator: , [5227,5228]
===
match
---
atom [33167,33241]
atom [33073,33147]
===
match
---
atom_expr [16009,16031]
atom_expr [15915,15937]
===
match
---
string: "_task_module" [5072,5086]
string: "_task_module" [5072,5086]
===
match
---
fstring_start: f" [29282,29284]
fstring_start: f" [29188,29190]
===
match
---
name: SerializedBaseOperator [33598,33620]
name: SerializedBaseOperator [33504,33526]
===
match
---
name: __dict__ [29472,29480]
name: __dict__ [29378,29386]
===
match
---
name: deserialize_operator [39945,39965]
name: deserialize_operator [39851,39871]
===
match
---
atom_expr [25960,25999]
atom_expr [25866,25905]
===
match
---
name: val [20793,20796]
name: val [20699,20702]
===
match
---
name: self [19513,19517]
name: self [19419,19423]
===
match
---
atom [21976,21998]
atom [21882,21904]
===
match
---
name: parameterized [42398,42411]
name: parameterized [42304,42317]
===
match
---
string: "value_1" [21988,21997]
string: "value_1" [21894,21903]
===
match
---
operator: { [8409,8410]
operator: { [8409,8410]
===
match
---
parameters [29129,29145]
parameters [29035,29051]
===
match
---
name: k [13360,13361]
name: k [13266,13267]
===
match
---
operator: { [29984,29985]
operator: { [29890,29891]
===
match
---
import_name [828,844]
import_name [828,844]
===
match
---
trailer [10881,10888]
trailer [10881,10888]
===
match
---
operator: { [27695,27696]
operator: { [27601,27602]
===
match
---
suite [33827,36388]
suite [33733,36294]
===
match
---
comparison [15304,15389]
comparison [15210,15295]
===
match
---
atom_expr [38203,38250]
atom_expr [38109,38156]
===
match
---
decorated [21003,21877]
decorated [20909,21783]
===
match
---
name: dag [8781,8784]
name: dag [8781,8784]
===
match
---
operator: } [24313,24314]
operator: } [24219,24220]
===
match
---
name: from_json [12438,12447]
name: from_json [12438,12447]
===
match
---
name: queue [11629,11634]
name: queue [11629,11634]
===
match
---
operator: , [6241,6242]
operator: , [6241,6242]
===
match
---
operator: == [13765,13767]
operator: == [13671,13673]
===
match
---
name: to_dict [18664,18671]
name: to_dict [18570,18577]
===
match
---
operator: = [11453,11454]
operator: = [11453,11454]
===
match
---
assert_stmt [41139,41204]
assert_stmt [41045,41110]
===
match
---
trailer [8438,8445]
trailer [8438,8445]
===
match
---
string: 'custom_task' [2646,2659]
string: 'custom_task' [2646,2659]
===
match
---
string: "tasks" [17269,17276]
string: "tasks" [17175,17182]
===
match
---
string: 'retries' [35277,35286]
string: 'retries' [35183,35192]
===
match
---
name: security [1463,1471]
name: security [1463,1471]
===
match
---
trailer [44495,44498]
trailer [45248,45251]
===
match
---
name: object_to_serialized [43257,43277]
name: object_to_serialized [44010,44030]
===
match
---
name: dag_id [40662,40668]
name: dag_id [40568,40574]
===
match
---
suite [40903,40974]
suite [40809,40880]
===
match
---
import_from [1030,1082]
import_from [1030,1082]
===
match
---
operator: , [42984,42985]
operator: , [43564,43565]
===
match
---
operator: , [42817,42818]
operator: , [42723,42724]
===
match
---
operator: == [11037,11039]
operator: == [11037,11039]
===
match
---
simple_stmt [13836,13925]
simple_stmt [13742,13831]
===
match
---
operator: , [18295,18296]
operator: , [18201,18202]
===
match
---
trailer [45041,45049]
trailer [45794,45802]
===
match
---
expr_stmt [37196,37233]
expr_stmt [37102,37139]
===
match
---
argument [28148,28172]
argument [28054,28078]
===
match
---
trailer [17867,17871]
trailer [17773,17777]
===
match
---
name: SerializedDAG [11707,11720]
name: SerializedDAG [11707,11720]
===
match
---
name: to_dict [27065,27072]
name: to_dict [26971,26978]
===
match
---
atom_expr [14995,15009]
atom_expr [14901,14915]
===
match
---
dictorsetmaker [4097,4277]
dictorsetmaker [4097,4277]
===
match
---
argument [17577,17596]
argument [17483,17502]
===
match
---
fstring [7613,7628]
fstring [7613,7628]
===
match
---
name: daemon [11527,11533]
name: daemon [11527,11533]
===
match
---
suite [37675,38367]
suite [37581,38273]
===
match
---
operator: = [6534,6535]
operator: = [6534,6535]
===
match
---
name: task [15069,15073]
name: task [14975,14979]
===
match
---
operator: , [18489,18490]
operator: , [18395,18396]
===
match
---
dictorsetmaker [29797,29824]
dictorsetmaker [29703,29730]
===
match
---
operator: - [12819,12820]
operator: - [12819,12820]
===
match
---
trailer [17592,17596]
trailer [17498,17502]
===
match
---
atom [42808,42848]
atom [42714,42754]
===
match
---
trailer [7378,7659]
trailer [7378,7659]
===
match
---
number: 2019 [18228,18232]
number: 2019 [18134,18138]
===
match
---
atom_expr [41933,42010]
atom_expr [41839,41916]
===
match
---
operator: - [33013,33014]
operator: - [32919,32920]
===
match
---
param [29130,29135]
param [29036,29041]
===
match
---
operator: , [19344,19345]
operator: , [19250,19251]
===
match
---
expr_stmt [37966,38054]
expr_stmt [37872,37960]
===
match
---
decorator [21003,21138]
decorator [20909,21044]
===
match
---
name: doc_md [6708,6714]
name: doc_md [6708,6714]
===
match
---
name: to_dict [32227,32234]
name: to_dict [32133,32140]
===
match
---
shift_expr [37140,37157]
shift_expr [37046,37063]
===
match
---
number: 8 [6240,6241]
number: 8 [6240,6241]
===
match
---
name: self [8975,8979]
name: self [8975,8979]
===
match
---
operator: } [30258,30259]
operator: } [30164,30165]
===
match
---
name: test_task_params_roundtrip [22025,22051]
name: test_task_params_roundtrip [21931,21957]
===
match
---
import_from [36578,36624]
import_from [36484,36530]
===
match
---
simple_stmt [37506,37548]
simple_stmt [37412,37454]
===
match
---
operator: { [21055,21056]
operator: { [20961,20962]
===
match
---
operator: } [41325,41326]
operator: } [41231,41232]
===
match
---
expr_stmt [23461,23504]
expr_stmt [23367,23410]
===
match
---
decorator [41210,41352]
decorator [41116,41258]
===
match
---
arglist [12519,12538]
arglist [12519,12538]
===
match
---
simple_stmt [41933,42011]
simple_stmt [41839,41917]
===
match
---
operator: , [11487,11488]
operator: , [11487,11488]
===
match
---
string: "foo" [29913,29918]
string: "foo" [29819,29824]
===
match
---
atom [29983,30065]
atom [29889,29971]
===
match
---
operator: , [34817,34818]
operator: , [34723,34724]
===
match
---
trailer [23398,23451]
trailer [23304,23357]
===
match
---
trailer [45067,45081]
trailer [45820,45834]
===
match
---
operator: = [28115,28116]
operator: = [28021,28022]
===
match
---
operator: , [19662,19663]
operator: , [19568,19569]
===
match
---
expr_stmt [27208,27250]
expr_stmt [27114,27156]
===
match
---
string: "'{{ task.task_id }}', 'template_fields': ['att3']}), 'template_fields': ['nested1']})" [31501,31588]
string: "'{{ task.task_id }}', 'template_fields': ['att3']}), 'template_fields': ['nested1']})" [31407,31494]
===
match
---
operator: , [39348,39349]
operator: , [39254,39255]
===
match
---
name: params [21323,21329]
name: params [21229,21235]
===
match
---
operator: , [956,957]
operator: , [956,957]
===
match
---
fstring_end: ' [15448,15449]
fstring_end: ' [15354,15355]
===
match
---
operator: , [30343,30344]
operator: , [30249,30250]
===
match
---
name: task_dict [22638,22647]
name: task_dict [22544,22553]
===
match
---
fstring_start: f' [13671,13673]
fstring_start: f' [13577,13579]
===
match
---
name: directory [8464,8473]
name: directory [8464,8473]
===
match
---
simple_stmt [32248,32307]
simple_stmt [32154,32213]
===
match
---
operator: { [29912,29913]
operator: { [29818,29819]
===
match
---
name: att2 [30853,30857]
name: att2 [30759,30763]
===
match
---
operator: , [15368,15369]
operator: , [15274,15275]
===
match
---
atom_expr [17982,17994]
atom_expr [17888,17900]
===
match
---
name: serialized_obj [43423,43437]
name: serialized_obj [44176,44190]
===
match
---
name: task [14351,14355]
name: task [14257,14261]
===
match
---
trailer [37939,37947]
trailer [37845,37853]
===
match
---
expr_stmt [21623,21681]
expr_stmt [21529,21587]
===
match
---
argument [5970,6204]
argument [5970,6204]
===
match
---
name: self [40212,40216]
name: self [40118,40122]
===
match
---
simple_stmt [22211,22301]
simple_stmt [22117,22207]
===
match
---
suite [32115,32187]
suite [32021,32093]
===
match
---
trailer [40871,40876]
trailer [40777,40782]
===
match
---
funcdef [33095,33770]
funcdef [33001,33676]
===
match
---
dictorsetmaker [30085,30122]
dictorsetmaker [29991,30028]
===
match
---
operator: = [25923,25924]
operator: = [25829,25830]
===
match
---
operator: , [42912,42913]
operator: , [43492,43493]
===
match
---
operator: , [18425,18426]
operator: , [18331,18332]
===
match
---
simple_stmt [33591,33644]
simple_stmt [33497,33550]
===
match
---
name: task [15364,15368]
name: task [15270,15274]
===
match
---
trailer [37391,37406]
trailer [37297,37312]
===
match
---
simple_stmt [41139,41205]
simple_stmt [41045,41111]
===
match
---
trailer [33431,33440]
trailer [33337,33346]
===
match
---
trailer [9786,9789]
trailer [9786,9789]
===
match
---
string: "tasks" [17186,17193]
string: "tasks" [17092,17099]
===
match
---
string: "params" [22468,22476]
string: "params" [22374,22382]
===
match
---
atom [4777,4829]
atom [4777,4829]
===
match
---
operator: , [6382,6383]
operator: , [6382,6383]
===
match
---
funcdef [37648,38367]
funcdef [37554,38273]
===
match
---
operator: = [38764,38765]
operator: = [38670,38671]
===
match
---
trailer [27925,27950]
trailer [27831,27856]
===
match
---
argument [16161,16180]
argument [16067,16086]
===
match
---
trailer [13882,13891]
trailer [13788,13797]
===
match
---
name: DAG [22178,22181]
name: DAG [22084,22087]
===
match
---
atom_expr [39277,39290]
atom_expr [39183,39196]
===
match
---
operator: , [42692,42693]
operator: , [42598,42599]
===
match
---
name: self [29416,29420]
name: self [29322,29326]
===
match
---
name: dag [13326,13329]
name: dag [13232,13235]
===
match
---
name: deserialized_test_task [32416,32438]
name: deserialized_test_task [32322,32344]
===
match
---
name: BaseOperator [21343,21355]
name: BaseOperator [21249,21261]
===
match
---
name: args [11476,11480]
name: args [11476,11480]
===
match
---
name: SerializedDAG [19993,20006]
name: SerializedDAG [19899,19912]
===
match
---
name: schedule_interval [20106,20123]
name: schedule_interval [20012,20029]
===
match
---
string: """OperatorLink not registered via Plugins nor a built-in OperatorLink""" [25235,25308]
string: """OperatorLink not registered via Plugins nor a built-in OperatorLink""" [25141,25214]
===
match
---
name: bash [1425,1429]
name: bash [1425,1429]
===
match
---
string: "tests.test_utils.mock_operators" [5088,5121]
string: "tests.test_utils.mock_operators" [5088,5121]
===
match
---
arglist [39671,39715]
arglist [39577,39621]
===
match
---
suite [43727,43790]
suite [44480,44543]
===
match
---
assert_stmt [28627,28716]
assert_stmt [28533,28622]
===
match
---
atom [28211,28245]
atom [28117,28151]
===
match
---
argument [21379,21386]
argument [21285,21292]
===
match
---
trailer [27072,27077]
trailer [26978,26983]
===
match
---
trailer [44504,44512]
trailer [45257,45265]
===
match
---
name: datetime [18013,18021]
name: datetime [17919,17927]
===
match
---
string: "param_1" [21977,21986]
string: "param_1" [21883,21892]
===
match
---
operator: , [29825,29826]
operator: , [29731,29732]
===
match
---
shift_expr [37170,37186]
shift_expr [37076,37092]
===
match
---
comparison [27619,27862]
comparison [27525,27768]
===
match
---
assert_stmt [14959,15009]
assert_stmt [14865,14915]
===
match
---
atom [19634,19983]
atom [19540,19889]
===
match
---
name: test_date [28585,28594]
name: test_date [28491,28500]
===
match
---
name: Process [11439,11446]
name: Process [11439,11446]
===
match
---
simple_stmt [41071,41130]
simple_stmt [40977,41036]
===
match
---
atom_expr [15065,15090]
atom_expr [14971,14996]
===
match
---
atom_expr [12084,12096]
atom_expr [12084,12096]
===
match
---
dictorsetmaker [6310,6381]
dictorsetmaker [6310,6381]
===
match
---
trailer [9991,10005]
trailer [9991,10005]
===
match
---
atom_expr [34259,34276]
atom_expr [34165,34182]
===
match
---
name: serialized_dag [37416,37430]
name: serialized_dag [37322,37336]
===
match
---
operator: = [37988,37989]
operator: = [37894,37895]
===
match
---
argument [18034,18053]
argument [17940,17959]
===
match
---
atom_expr [38766,38796]
atom_expr [38672,38702]
===
match
---
expr_stmt [20907,20961]
expr_stmt [20813,20867]
===
match
---
atom_expr [42277,42316]
atom_expr [42183,42222]
===
match
---
assert_stmt [39981,40017]
assert_stmt [39887,39923]
===
match
---
atom_expr [19098,19126]
atom_expr [19004,19032]
===
match
---
decorator [21882,22017]
decorator [21788,21923]
===
match
---
name: template_fields [15074,15089]
name: template_fields [14980,14995]
===
match
---
name: importlib [852,861]
name: importlib [852,861]
===
match
---
atom [42877,43036]
atom [43457,43616]
===
match
---
string: 'task_2' [42819,42827]
string: 'task_5' [42725,42733]
===
match
---
not_test [18688,18705]
not_test [18594,18611]
===
match
---
simple_stmt [25800,25844]
simple_stmt [25706,25750]
===
match
---
name: mock [9040,9044]
name: mock [9040,9044]
===
match
---
argument [17524,17543]
argument [17430,17449]
===
match
---
assert_stmt [15929,15975]
assert_stmt [15835,15881]
===
match
---
operator: = [18608,18609]
operator: = [18514,18515]
===
match
---
param [25635,25640]
param [25541,25546]
===
match
---
string: 'simple_dag' [25697,25709]
string: 'simple_dag' [25603,25615]
===
match
---
operator: , [8064,8065]
operator: , [8064,8065]
===
match
---
trailer [34343,34345]
trailer [34249,34251]
===
match
---
name: BaseOperator [22211,22223]
name: BaseOperator [22117,22129]
===
match
---
operator: = [32169,32170]
operator: = [32075,32076]
===
match
---
operator: { [32887,32888]
operator: { [32793,32794]
===
match
---
operator: = [12422,12423]
operator: = [12422,12423]
===
match
---
operator: = [19096,19097]
operator: = [19002,19003]
===
match
---
name: expected_dict [38254,38267]
name: expected_dict [38160,38173]
===
match
---
param [25641,25648]
param [25547,25554]
===
match
---
operator: , [29221,29222]
operator: , [29127,29128]
===
match
---
string: "simple_task" [23663,23676]
string: "simple_task" [23569,23582]
===
match
---
argument [20527,20537]
argument [20433,20443]
===
match
---
trailer [9866,9873]
trailer [9866,9873]
===
match
---
string: '}' [9425,9428]
string: '}' [9425,9428]
===
match
---
atom_expr [38343,38366]
atom_expr [38249,38272]
===
match
---
trailer [11559,11561]
trailer [11559,11561]
===
match
---
operator: , [23420,23421]
operator: , [23326,23327]
===
match
---
string: "value_1" [21109,21118]
string: "value_1" [21015,21024]
===
match
---
name: test_deserialization_end_date [18362,18391]
name: test_deserialization_end_date [18268,18297]
===
match
---
string: "test_task_group_serialization" [36689,36720]
string: "test_task_group_serialization" [36595,36626]
===
match
---
simple_stmt [37140,37158]
simple_stmt [37046,37064]
===
match
---
expr_stmt [33652,33717]
expr_stmt [33558,33623]
===
match
---
operator: = [34030,34031]
operator: = [33936,33937]
===
match
---
simple_stmt [36578,36625]
simple_stmt [36484,36531]
===
match
---
atom [41256,41302]
atom [41162,41208]
===
match
---
name: from_dict [42291,42300]
name: from_dict [42197,42206]
===
match
---
atom_expr [8434,8475]
atom_expr [8434,8475]
===
match
---
number: 2019 [17963,17967]
number: 2019 [17869,17873]
===
match
---
simple_stmt [9692,9713]
simple_stmt [9692,9713]
===
match
---
operator: , [18235,18236]
operator: , [18141,18142]
===
match
---
name: globals_ [43610,43618]
name: globals_ [44363,44371]
===
match
---
dictorsetmaker [30280,30327]
dictorsetmaker [30186,30233]
===
match
---
simple_stmt [21767,21814]
simple_stmt [21673,21720]
===
match
---
atom [29871,29951]
atom [29777,29857]
===
match
---
atom_expr [7920,7950]
atom_expr [7920,7950]
===
match
---
dictorsetmaker [8565,8629]
dictorsetmaker [8565,8629]
===
match
---
param [38458,38462]
param [38364,38368]
===
match
---
name: start_date [18491,18501]
name: start_date [18397,18407]
===
match
---
expr_stmt [7369,7659]
expr_stmt [7369,7659]
===
match
---
testlist_comp [40069,40121]
testlist_comp [39975,40027]
===
match
---
atom [27007,27023]
atom [26913,26929]
===
match
---
number: 1 [27848,27849]
number: 1 [27754,27755]
===
match
---
expr_stmt [8177,8333]
expr_stmt [8177,8333]
===
match
---
dictorsetmaker [29921,29948]
dictorsetmaker [29827,29854]
===
match
---
operator: = [20394,20395]
operator: = [20300,20301]
===
match
---
name: expand [29577,29583]
name: expand [29483,29489]
===
match
---
string: 'label' [34804,34811]
string: 'label' [34710,34717]
===
match
---
name: execution_date [28148,28162]
name: execution_date [28054,28068]
===
match
---
string: "att1" [30493,30499]
string: "att1" [30399,30405]
===
match
---
string: "@once" [19321,19328]
string: "@once" [19227,19234]
===
match
---
trailer [17261,17268]
trailer [17167,17174]
===
match
---
name: validate_deserialized_dag [12493,12518]
name: validate_deserialized_dag [12493,12518]
===
match
---
atom_expr [36825,36846]
atom_expr [36731,36752]
===
match
---
string: 'kubernetes' [43714,43726]
string: 'kubernetes' [44467,44479]
===
match
---
funcdef [8649,8869]
funcdef [8649,8869]
===
match
---
operator: = [40766,40767]
operator: = [40672,40673]
===
match
---
expr_stmt [25569,25609]
expr_stmt [25475,25515]
===
match
---
name: DAG [5928,5931]
name: DAG [5928,5931]
===
match
---
suite [22077,22726]
suite [21983,22632]
===
match
---
parameters [10336,10352]
parameters [10336,10352]
===
match
---
operator: , [42769,42770]
operator: , [42675,42676]
===
match
---
string: 'label' [3801,3808]
string: 'label' [3801,3808]
===
match
---
string: 'next_execution_date' [7498,7519]
string: 'next_execution_date' [7498,7519]
===
match
---
trailer [44248,44253]
trailer [45001,45006]
===
match
---
operator: , [34472,34473]
operator: , [34378,34379]
===
match
---
number: 4 [20590,20591]
number: 4 [20496,20497]
===
match
---
operator: , [44508,44509]
operator: , [45261,45262]
===
match
---
suite [13393,13720]
suite [13299,13626]
===
match
---
string: "__var" [10838,10845]
string: "__var" [10838,10845]
===
match
---
simple_stmt [25569,25610]
simple_stmt [25475,25516]
===
match
---
string: """Validate pickle in a subprocess.""" [8698,8736]
string: """Validate pickle in a subprocess.""" [8698,8736]
===
match
---
operator: , [33395,33396]
operator: , [33301,33302]
===
match
---
name: BaseOperator [1371,1383]
name: BaseOperator [1371,1383]
===
match
---
string: "dag" [22499,22504]
string: "dag" [22405,22410]
===
match
---
operator: , [21974,21975]
operator: , [21880,21881]
===
match
---
suite [17506,17780]
suite [17412,17686]
===
match
---
import_from [989,1014]
import_from [989,1014]
===
match
---
trailer [23700,23729]
trailer [23606,23635]
===
match
---
name: tzinfo [17901,17907]
name: tzinfo [17807,17813]
===
match
---
name: deserialized_dag [42333,42349]
name: deserialized_dag [42239,42255]
===
match
---
funcdef [7834,8647]
funcdef [7834,8647]
===
match
---
atom [21097,21119]
atom [21003,21025]
===
match
---
atom_expr [30956,31107]
atom_expr [30862,31013]
===
match
---
parameters [20786,20807]
parameters [20692,20713]
===
match
---
name: utils [38623,38628]
name: utils [38529,38534]
===
match
---
suite [6446,6795]
suite [6446,6795]
===
match
---
param [14145,14161]
param [14051,14067]
===
match
---
testlist_comp [17830,18337]
testlist_comp [17736,18243]
===
match
---
simple_stmt [5860,5919]
simple_stmt [5860,5919]
===
match
---
dictorsetmaker [27968,28092]
dictorsetmaker [27874,27998]
===
match
---
arglist [37392,37405]
arglist [37298,37311]
===
match
---
trailer [20936,20949]
trailer [20842,20855]
===
match
---
atom_expr [24764,24819]
atom_expr [24670,24725]
===
match
---
string: "bar" [30288,30293]
string: "bar" [30194,30199]
===
match
---
operator: , [2630,2631]
operator: , [2630,2631]
===
match
---
string: 'simple_dag' [6776,6788]
string: 'simple_dag' [6776,6788]
===
match
---
name: imported_airflow [44456,44472]
name: imported_airflow [45209,45225]
===
match
---
comparison [15182,15245]
comparison [15088,15151]
===
match
---
atom [4826,4828]
atom [4826,4828]
===
match
---
operator: = [33666,33667]
operator: = [33572,33573]
===
match
---
number: 600.0 [3323,3328]
number: 600.0 [3323,3328]
===
match
---
operator: , [30688,30689]
operator: , [30594,30595]
===
match
---
testlist_comp [16214,16374]
testlist_comp [16120,16280]
===
match
---
fstring_string: . [13289,13290]
fstring_string: . [13195,13196]
===
match
---
name: parameterized [1132,1145]
name: parameterized [1132,1145]
===
match
---
name: task_id [37004,37011]
name: task_id [36910,36917]
===
match
---
name: test_deserialization_with_dag_context [17462,17499]
name: test_deserialization_with_dag_context [17368,17405]
===
match
---
operator: } [19982,19983]
operator: } [19888,19889]
===
match
---
dictorsetmaker [24267,24313]
dictorsetmaker [24173,24219]
===
match
---
name: getattr [15304,15311]
name: getattr [15210,15217]
===
match
---
trailer [27183,27199]
trailer [27089,27105]
===
match
---
trailer [16905,16913]
trailer [16811,16819]
===
match
---
name: task_dict [21734,21743]
name: task_dict [21640,21649]
===
match
---
simple_stmt [23581,23627]
simple_stmt [23487,23533]
===
match
---
suite [18451,19189]
suite [18357,19095]
===
match
---
string: 'dag' [10196,10201]
string: 'dag' [10196,10201]
===
match
---
name: task_id [37940,37947]
name: task_id [37846,37853]
===
match
---
comparison [17231,17280]
comparison [17137,17186]
===
match
---
simple_stmt [5812,5831]
simple_stmt [5812,5831]
===
match
---
trailer [38244,38250]
trailer [38150,38156]
===
match
---
name: custom_inbuilt_link [28535,28554]
name: custom_inbuilt_link [28441,28460]
===
match
---
operator: , [2644,2645]
operator: , [2644,2645]
===
match
---
name: sorted_serialized_dag [10997,11018]
name: sorted_serialized_dag [10997,11018]
===
match
---
simple_stmt [7369,7660]
simple_stmt [7369,7660]
===
match
---
trailer [18510,18522]
trailer [18416,18428]
===
match
---
operator: = [37718,37719]
operator: = [37624,37625]
===
match
---
name: from_dict [27174,27183]
name: from_dict [27080,27089]
===
match
---
name: module [44230,44236]
name: module [44983,44989]
===
match
---
atom_expr [13230,13260]
atom_expr [13096,13126]
===
match
---
name: serialized_obj [43384,43398]
name: serialized_obj [44137,44151]
===
match
---
operator: , [35539,35540]
operator: , [35445,35446]
===
match
---
operator: = [28162,28163]
operator: = [28068,28069]
===
match
---
string: "is_paused_upon_creation" [2967,2992]
string: "is_paused_upon_creation" [2967,2992]
===
match
---
comparison [15462,15495]
comparison [15368,15401]
===
match
---
trailer [44816,44830]
trailer [45569,45583]
===
match
---
simple_stmt [21430,21474]
simple_stmt [21336,21380]
===
match
---
trailer [10929,10938]
trailer [10929,10938]
===
match
---
name: dag [8573,8576]
name: dag [8573,8576]
===
match
---
atom_expr [9014,9037]
atom_expr [9014,9037]
===
match
---
operator: , [43036,43037]
operator: , [43616,43617]
===
match
---
string: 'tooltip' [2703,2712]
string: 'tooltip' [2703,2712]
===
match
---
name: expected_dict [38071,38084]
name: expected_dict [37977,37990]
===
match
---
atom [24266,24314]
atom [24172,24220]
===
match
---
string: 'blah' [25783,25789]
string: 'blah' [25689,25695]
===
match
---
argument [21388,21419]
argument [21294,21325]
===
match
---
trailer [7676,7802]
trailer [7676,7802]
===
match
---
suite [21197,21877]
suite [21103,21783]
===
match
---
expr_stmt [16727,16784]
expr_stmt [16633,16690]
===
match
---
operator: } [24162,24163]
operator: } [24068,24069]
===
match
---
string: "retry_delay" [3266,3279]
string: "retry_delay" [3266,3279]
===
match
---
arglist [32416,32454]
arglist [32322,32360]
===
match
---
argument [20299,20306]
argument [20205,20212]
===
match
---
operator: = [23585,23586]
operator: = [23491,23492]
===
match
---
operator: , [17847,17848]
operator: , [17753,17754]
===
match
---
number: 2019 [16548,16552]
number: 2019 [16454,16458]
===
match
---
name: airflow [38557,38564]
name: airflow [38463,38470]
===
match
---
trailer [37577,37588]
trailer [37483,37494]
===
match
---
simple_stmt [24394,24440]
simple_stmt [24300,24346]
===
match
---
param [7851,7866]
param [7851,7866]
===
match
---
operator: = [11421,11422]
operator: = [11421,11422]
===
match
---
simple_stmt [37196,37234]
simple_stmt [37102,37140]
===
match
---
string: "max_retry_delay" [2302,2319]
string: "max_retry_delay" [2302,2319]
===
match
---
argument [11447,11474]
argument [11447,11474]
===
match
---
with_item [36685,36755]
with_item [36591,36661]
===
match
---
operator: - [20403,20404]
operator: - [20309,20310]
===
match
---
atom_expr [44877,44904]
atom_expr [45630,45657]
===
match
---
operator: == [20124,20126]
operator: == [20030,20032]
===
match
---
testlist_comp [30375,30674]
testlist_comp [30281,30580]
===
match
---
atom_expr [5639,5665]
atom_expr [5639,5665]
===
match
---
argument [26896,26915]
argument [26802,26821]
===
match
---
simple_stmt [39097,39143]
simple_stmt [39003,39049]
===
match
---
string: "set" [5399,5404]
string: "set" [5399,5404]
===
match
---
operator: } [29909,29910]
operator: } [29815,29816]
===
match
---
name: ClassWithCustomAttributes [30375,30400]
name: ClassWithCustomAttributes [30281,30306]
===
match
---
string: """         Assert extra field exists & OperatorLinks defined in Plugins and inbuilt Operator Links.          This tests also depends on GoogleLink() registered as a plugin         in tests/plugins/test_plugin.py          The function tests that if extra operator links are registered in plugin         in ``operator_extra_links`` and the same is also defined in         the Operator in ``BaseOperator.operator_extra_links``, it has the correct         extra link.         """ [22797,23273]
string: """         Assert extra field exists & OperatorLinks defined in Plugins and inbuilt Operator Links.          This tests also depends on GoogleLink() registered as a plugin         in tests/plugins/test_plugin.py          The function tests that if extra operator links are registered in plugin         in ``operator_extra_links`` and the same is also defined in         the Operator in ``BaseOperator.operator_extra_links``, it has the correct         extra link.         """ [22703,23179]
===
match
---
name: to_dict [38957,38964]
name: to_dict [38863,38870]
===
match
---
name: task_dict [19102,19111]
name: task_dict [19008,19017]
===
match
---
name: field [13291,13296]
name: field [13197,13202]
===
match
---
operator: { [40137,40138]
operator: { [40043,40044]
===
match
---
name: __repr__ [29346,29354]
name: __repr__ [29252,29260]
===
match
---
trailer [42349,42373]
trailer [42255,42279]
===
match
---
operator: , [19734,19735]
operator: , [19640,19641]
===
match
---
atom_expr [29466,29480]
atom_expr [29372,29386]
===
match
---
number: 1564617600.0 [2474,2486]
number: 1564617600.0 [2474,2486]
===
match
---
suite [15989,16040]
suite [15895,15946]
===
match
---
operator: , [5677,5678]
operator: , [5677,5678]
===
match
---
name: k8s [1757,1760]
name: k8s [1757,1760]
===
match
---
comparison [15516,15538]
comparison [15422,15444]
===
match
---
trailer [9975,10042]
trailer [9975,10042]
===
match
---
atom_expr [10997,11036]
atom_expr [10997,11036]
===
match
---
atom_expr [15107,15140]
atom_expr [15013,15046]
===
match
---
operator: = [7483,7484]
operator: = [7483,7484]
===
match
---
operator: { [6323,6324]
operator: { [6323,6324]
===
match
---
name: start_date [17414,17424]
name: start_date [17320,17330]
===
match
---
operator: , [21181,21182]
operator: , [21087,21088]
===
match
---
string: "fileloc" [19807,19816]
string: "fileloc" [19713,19722]
===
match
---
string: "task1" [36799,36806]
string: "task1" [36705,36712]
===
match
---
operator: , [34529,34530]
operator: , [34435,34436]
===
match
---
operator: = [40785,40786]
operator: = [40691,40692]
===
match
---
trailer [21655,21665]
trailer [21561,21571]
===
match
---
operator: = [41855,41856]
operator: = [41761,41762]
===
match
---
operator: { [7484,7485]
operator: { [7484,7485]
===
match
---
operator: = [26026,26027]
operator: = [25932,25933]
===
match
---
operator: = [16731,16732]
operator: = [16637,16638]
===
match
---
operator: , [31107,31108]
operator: , [31013,31014]
===
match
---
number: 8 [21414,21415]
number: 8 [21320,21321]
===
match
---
dotted_name [1213,1245]
dotted_name [1213,1245]
===
match
---
string: 'task_5' [42839,42847]
string: 'task_4' [42745,42753]
===
match
---
name: json_dag [11062,11070]
name: json_dag [11062,11070]
===
match
---
arglist [11447,11512]
arglist [11447,11512]
===
match
---
number: 100 [6189,6192]
number: 100 [6189,6192]
===
match
---
expr_stmt [44456,44597]
expr_stmt [45209,45350]
===
match
---
expr_stmt [16875,16918]
expr_stmt [16781,16824]
===
match
---
operator: } [21973,21974]
operator: } [21879,21880]
===
match
---
atom_expr [24551,24568]
atom_expr [24457,24474]
===
match
---
name: values [37734,37740]
name: values [37640,37646]
===
match
---
string: "{{ task.task_id }}" [29700,29720]
string: "{{ task.task_id }}" [29606,29626]
===
match
---
simple_stmt [867,890]
simple_stmt [867,890]
===
match
---
name: dags [11925,11929]
name: dags [11925,11929]
===
match
---
import_from [38610,38654]
import_from [38516,38560]
===
match
---
with_item [43908,43984]
with_item [44661,44737]
===
match
---
operator: , [4866,4867]
operator: , [4866,4867]
===
match
---
operator: , [30447,30448]
operator: , [30353,30354]
===
match
---
name: task [24342,24346]
name: task [24248,24252]
===
match
---
operator: { [34762,34763]
operator: { [34668,34669]
===
match
---
operator: = [5586,5587]
operator: = [5586,5587]
===
match
---
name: TaskGroup [36933,36942]
name: TaskGroup [36839,36848]
===
match
---
atom [3499,3501]
atom [3499,3501]
===
match
---
operator: , [34559,34560]
operator: , [34465,34466]
===
match
---
atom_expr [18041,18053]
atom_expr [17947,17959]
===
match
---
suite [37692,37743]
suite [37598,37649]
===
match
---
expr_stmt [11376,11407]
expr_stmt [11376,11407]
===
match
---
operator: , [2450,2451]
operator: , [2450,2451]
===
match
---
operator: , [20796,20797]
operator: , [20702,20703]
===
match
---
atom_expr [17296,17335]
atom_expr [17202,17241]
===
match
---
trailer [6047,6058]
trailer [6047,6058]
===
match
---
not_test [16930,16949]
not_test [16836,16855]
===
match
---
name: globals [43832,43839]
name: globals [44585,44592]
===
match
---
name: __name__ [29300,29308]
name: __name__ [29206,29214]
===
match
---
for_stmt [8777,8849]
for_stmt [8777,8849]
===
match
---
argument [40759,40780]
argument [40665,40686]
===
match
---
trailer [29549,29556]
trailer [29455,29462]
===
match
---
name: dirname [5631,5638]
name: dirname [5631,5638]
===
match
---
atom [5560,5562]
atom [5560,5562]
===
match
---
atom_expr [17358,17386]
atom_expr [17264,17292]
===
match
---
trailer [16516,16520]
trailer [16422,16426]
===
match
---
number: 2 [44510,44511]
number: 2 [45263,45264]
===
match
---
decorator [17785,18354]
decorator [17691,18260]
===
match
---
name: serialized_dag [19060,19074]
name: serialized_dag [18966,18980]
===
match
---
operator: , [5161,5162]
operator: , [5161,5162]
===
match
---
name: expected_err_msg [26061,26077]
name: expected_err_msg [25967,25983]
===
match
---
simple_stmt [11376,11408]
simple_stmt [11376,11408]
===
match
---
name: set [11921,11924]
name: set [11921,11924]
===
match
---
name: make_simple_dag [7932,7947]
name: make_simple_dag [7932,7947]
===
match
---
operator: @ [19194,19195]
operator: @ [19100,19101]
===
match
---
name: children [37709,37717]
name: children [37615,37623]
===
match
---
simple_stmt [1649,1734]
simple_stmt [1649,1734]
===
match
---
name: PodGenerator [44804,44816]
name: PodGenerator [45557,45569]
===
match
---
dictorsetmaker [2034,5570]
dictorsetmaker [2034,5570]
===
match
---
operator: = [30857,30858]
operator: = [30763,30764]
===
match
---
operator: , [17575,17576]
operator: , [17481,17482]
===
match
---
name: task2 [38892,38897]
name: task2 [38798,38803]
===
match
---
name: isinstance [14396,14406]
name: isinstance [14302,14312]
===
match
---
argument [6181,6192]
argument [6181,6192]
===
match
---
dictorsetmaker [7328,7363]
dictorsetmaker [7328,7363]
===
match
---
comparison [39988,40017]
comparison [39894,39923]
===
match
---
suite [21489,21543]
suite [21395,21449]
===
match
---
name: expected_value [41430,41444]
name: expected_value [41336,41350]
===
match
---
name: timezone [13751,13759]
name: timezone [13657,13665]
===
match
---
trailer [39670,39716]
trailer [39576,39622]
===
match
---
simple_stmt [26947,27025]
simple_stmt [26853,26931]
===
match
---
simple_stmt [26845,26878]
simple_stmt [26751,26784]
===
match
---
atom [4002,4318]
atom [4002,4318]
===
match
---
operator: = [16167,16168]
operator: = [16073,16074]
===
match
---
arglist [32030,32096]
arglist [31936,32002]
===
match
---
operator: = [19416,19417]
operator: = [19322,19323]
===
match
---
name: test_edge_info_serialization [38429,38457]
name: test_edge_info_serialization [38335,38363]
===
match
---
name: update [7960,7966]
name: update [7960,7966]
===
match
---
name: items [13385,13390]
name: items [13291,13296]
===
match
---
atom [30034,30063]
atom [29940,29969]
===
match
---
name: models [1279,1285]
name: models [1279,1285]
===
match
---
name: set [15025,15028]
name: set [14931,14934]
===
match
---
operator: , [7559,7560]
operator: , [7559,7560]
===
match
---
name: collect_dags [11837,11849]
name: collect_dags [11837,11849]
===
match
---
arglist [22224,22299]
arglist [22130,22205]
===
match
---
trailer [13421,13424]
trailer [13327,13330]
===
match
---
suite [12014,12098]
suite [12014,12098]
===
match
---
operator: } [35100,35101]
operator: } [35006,35007]
===
match
---
trailer [28129,28173]
trailer [28035,28079]
===
match
---
operator: } [21997,21998]
operator: } [21903,21904]
===
match
---
simple_stmt [39242,39291]
simple_stmt [39148,39197]
===
match
---
operator: , [16595,16596]
operator: , [16501,16502]
===
match
---
operator: , [25738,25739]
operator: , [25644,25645]
===
match
---
name: ground_truth_dag [10092,10108]
name: ground_truth_dag [10092,10108]
===
match
---
import_from [1331,1401]
import_from [1331,1401]
===
match
---
string: "retry_delay" [4498,4511]
string: "retry_delay" [4498,4511]
===
match
---
name: task_type [15832,15841]
name: task_type [15738,15747]
===
match
---
string: "test1" [42977,42984]
string: "test1" [43557,43564]
===
match
---
name: deserialized_dag [21790,21806]
name: deserialized_dag [21696,21712]
===
match
---
number: 30 [18237,18239]
number: 30 [18143,18145]
===
match
---
atom [27954,28102]
atom [27860,28008]
===
match
---
arglist [23333,23374]
arglist [23239,23280]
===
match
---
name: dag [27073,27076]
name: dag [26979,26982]
===
match
---
atom_expr [44525,44551]
atom_expr [45278,45304]
===
match
---
name: task1 [37140,37145]
name: task1 [37046,37051]
===
match
---
name: timezone [18100,18108]
name: timezone [18006,18014]
===
match
---
operator: , [16292,16293]
operator: , [16198,16199]
===
match
---
suite [42174,42249]
suite [42080,42155]
===
match
---
assert_stmt [42187,42248]
assert_stmt [42093,42154]
===
match
---
string: "relativedelta" [20419,20434]
string: "relativedelta" [20325,20340]
===
match
---
atom_expr [10781,10846]
atom_expr [10781,10846]
===
match
---
atom [34092,35705]
atom [33998,35611]
===
match
---
atom [30492,30500]
atom [30398,30406]
===
match
---
atom_expr [12488,12539]
atom_expr [12488,12539]
===
match
---
fstring_string: / [8408,8409]
fstring_string: / [8408,8409]
===
match
---
operator: , [16230,16231]
operator: , [16136,16137]
===
match
---
operator: , [2946,2947]
operator: , [2946,2947]
===
match
---
name: DummyOperator [37045,37058]
name: DummyOperator [36951,36964]
===
match
---
number: 1 [16109,16110]
number: 1 [16015,16016]
===
match
---
import_as_name [1113,1126]
import_as_name [1113,1126]
===
match
---
atom [42732,42863]
atom [42638,42769]
===
match
---
funcdef [9536,10043]
funcdef [9536,10043]
===
match
---
name: DAG [33047,33050]
name: DAG [32953,32956]
===
match
---
trailer [44296,44308]
trailer [45049,45061]
===
match
---
fstring_string: .default_args[ [13685,13699]
fstring_string: .default_args[ [13591,13605]
===
match
---
trailer [10213,10219]
trailer [10213,10219]
===
match
---
exprlist [29163,29173]
exprlist [29069,29079]
===
match
---
name: op [33557,33559]
name: op [33463,33465]
===
match
---
atom_expr [10187,10228]
atom_expr [10187,10228]
===
match
---
name: parameterized [17786,17799]
name: parameterized [17692,17705]
===
match
---
trailer [17916,17920]
trailer [17822,17826]
===
match
---
arglist [17565,17596]
arglist [17471,17502]
===
match
---
classdef [39540,39645]
classdef [39446,39551]
===
match
---
name: os [897,899]
name: os [897,899]
===
match
---
simple_stmt [28879,28938]
simple_stmt [28785,28844]
===
match
---
name: simple_task [23635,23646]
name: simple_task [23541,23552]
===
match
---
name: task1 [38860,38865]
name: task1 [38766,38771]
===
match
---
atom [20723,20729]
atom [20629,20635]
===
match
---
name: do_xcom_push [33748,33760]
name: do_xcom_push [33654,33666]
===
match
---
expr_stmt [38932,38969]
expr_stmt [38838,38875]
===
match
---
argument [10737,10767]
argument [10737,10767]
===
match
---
trailer [10916,10929]
trailer [10916,10929]
===
match
---
string: """Collects DAGs to test.""" [7873,7901]
string: """Collects DAGs to test.""" [7873,7901]
===
match
---
trailer [15044,15060]
trailer [14950,14966]
===
match
---
name: FR [20535,20537]
name: FR [20441,20443]
===
match
---
atom_expr [23329,23375]
atom_expr [23235,23281]
===
match
---
atom_expr [6171,6193]
atom_expr [6171,6193]
===
match
---
operator: == [20981,20983]
operator: == [20887,20889]
===
match
---
number: 7 [7357,7358]
number: 7 [7357,7358]
===
match
---
param [39438,39443]
param [39344,39349]
===
match
---
name: ti [24324,24326]
name: ti [24230,24232]
===
match
---
param [41405,41429]
param [41311,41335]
===
match
---
trailer [13867,13924]
trailer [13773,13830]
===
match
---
string: "days" [20347,20353]
string: "days" [20253,20259]
===
match
---
string: "end_date" [18888,18898]
string: "end_date" [18794,18804]
===
match
---
simple_stmt [21623,21682]
simple_stmt [21529,21588]
===
match
---
for_stmt [9721,9881]
for_stmt [9721,9881]
===
match
---
name: exec_module [44297,44308]
name: exec_module [45050,45061]
===
match
---
operator: { [30295,30296]
operator: { [30201,30202]
===
match
---
name: dag [16833,16836]
name: dag [16739,16742]
===
match
---
atom [11481,11512]
atom [11481,11512]
===
match
---
name: dag [40872,40875]
name: dag [40778,40781]
===
match
---
operator: = [24346,24347]
operator: = [24252,24253]
===
match
---
simple_stmt [8177,8334]
simple_stmt [8177,8334]
===
match
---
name: catchup [7639,7646]
name: catchup [7639,7646]
===
match
---
name: from_dict [23601,23610]
name: from_dict [23507,23516]
===
match
---
trailer [40758,40823]
trailer [40664,40729]
===
match
---
operator: = [11627,11628]
operator: = [11627,11628]
===
match
---
string: """         Test that when on_failure_callback is passed to the DAG, has_on_failure_callback is stored         in Serialized JSON blob. And when it is de-serialized dag.has_on_failure_callback is set to True.          When the callback is not set, has_on_failure_callback should not be stored in Serialized blob         and so default to False on de-serialization         """ [41455,41830]
string: """         Test that when on_failure_callback is passed to the DAG, has_on_failure_callback is stored         in Serialized JSON blob. And when it is de-serialized dag.has_on_failure_callback is set to True.          When the callback is not set, has_on_failure_callback should not be stored in Serialized blob         and so default to False on de-serialization         """ [41361,41736]
===
match
---
atom_expr [18466,18546]
atom_expr [18372,18452]
===
match
---
operator: { [13290,13291]
operator: { [13196,13197]
===
match
---
number: 1 [20305,20306]
number: 1 [20211,20212]
===
match
---
name: default_args [13330,13342]
name: default_args [13236,13248]
===
match
---
operator: , [22056,22057]
operator: , [21962,21963]
===
match
---
trailer [10202,10213]
trailer [10202,10213]
===
match
---
operator: , [14544,14545]
operator: , [14450,14451]
===
match
---
name: patterns [8135,8143]
name: patterns [8135,8143]
===
match
---
operator: = [25327,25328]
operator: = [25233,25234]
===
match
---
name: upstream_task_ids [15149,15166]
name: upstream_task_ids [15055,15072]
===
match
---
string: "reschedule" [39371,39383]
string: "reschedule" [39277,39289]
===
match
---
operator: { [29284,29285]
operator: { [29190,29191]
===
match
---
operator: = [18575,18576]
operator: = [18481,18482]
===
match
---
comparison [11889,11937]
comparison [11889,11937]
===
match
---
name: task_id [13892,13899]
name: task_id [13798,13805]
===
match
---
operator: = [7373,7374]
operator: = [7373,7374]
===
match
---
operator: , [27313,27314]
operator: , [27219,27220]
===
match
---
name: values [12385,12391]
name: values [12385,12391]
===
match
---
operator: } [15424,15425]
operator: } [15330,15331]
===
match
---
atom_expr [42333,42373]
atom_expr [42239,42279]
===
match
---
trailer [16736,16784]
trailer [16642,16690]
===
match
---
trailer [17277,17280]
trailer [17183,17186]
===
match
---
atom_expr [13674,13684]
atom_expr [13580,13590]
===
match
---
argument [21323,21333]
argument [21229,21239]
===
match
---
operator: , [14847,14848]
operator: , [14753,14754]
===
match
---
operator: = [22619,22620]
operator: = [22525,22526]
===
match
---
string: "task3" [37012,37019]
string: "task3" [36918,36925]
===
match
---
fstring_expr [29284,29309]
fstring_expr [29190,29215]
===
match
---
fstring [13671,13719]
fstring [13577,13625]
===
match
---
trailer [25973,25983]
trailer [25879,25889]
===
match
---
string: "__var" [2131,2138]
string: "__var" [2131,2138]
===
match
---
operator: } [4298,4299]
operator: } [4298,4299]
===
match
---
simple_stmt [39654,39717]
simple_stmt [39560,39623]
===
match
---
trailer [16309,16313]
trailer [16215,16219]
===
match
---
name: op [39775,39777]
name: op [39681,39683]
===
match
---
name: fields_to_check [13060,13075]
name: fields_to_check [13060,13075]
===
match
---
simple_stmt [10180,10260]
simple_stmt [10180,10260]
===
match
---
atom [27838,27850]
atom [27744,27756]
===
match
---
name: v [9787,9788]
name: v [9787,9788]
===
match
---
string: "tasks" [22506,22513]
string: "tasks" [22412,22419]
===
match
---
arglist [30422,30500]
arglist [30328,30406]
===
match
---
trailer [15073,15089]
trailer [14979,14995]
===
match
---
number: 1 [17898,17899]
number: 1 [17804,17805]
===
match
---
operator: } [8417,8418]
operator: } [8417,8418]
===
match
---
name: task_id [38780,38787]
name: task_id [38686,38693]
===
match
---
param [40100,40101]
param [40006,40007]
===
match
---
assert_stmt [22382,22434]
assert_stmt [22288,22340]
===
match
---
operator: = [22188,22189]
operator: = [22094,22095]
===
match
---
name: datetime [40802,40810]
name: datetime [40708,40716]
===
match
---
expr_stmt [32315,32374]
expr_stmt [32221,32280]
===
match
---
operator: , [17850,17851]
operator: , [17756,17757]
===
match
---
operator: , [30851,30852]
operator: , [30757,30758]
===
match
---
trailer [11526,11533]
trailer [11526,11533]
===
match
---
name: params [21807,21813]
name: params [21713,21719]
===
match
---
trailer [6335,6351]
trailer [6335,6351]
===
match
---
operator: = [44237,44238]
operator: = [44990,44991]
===
match
---
name: from_json [37315,37324]
name: from_json [37221,37230]
===
match
---
name: V1ObjectMeta [1785,1797]
name: V1ObjectMeta [1785,1797]
===
match
---
operator: = [6224,6225]
operator: = [6224,6225]
===
match
---
suite [13076,13314]
suite [13076,13220]
===
match
---
trailer [23491,23499]
trailer [23397,23405]
===
match
---
name: dag [21292,21295]
name: dag [21198,21201]
===
match
---
name: resources [15478,15487]
name: resources [15384,15393]
===
match
---
number: 1 [32094,32095]
number: 1 [32000,32001]
===
match
---
assert_stmt [15175,15245]
assert_stmt [15081,15151]
===
match
---
suite [39615,39645]
suite [39521,39551]
===
match
---
name: stringified_dags [11571,11587]
name: stringified_dags [11571,11587]
===
match
---
name: timezone [17584,17592]
name: timezone [17490,17498]
===
match
---
operator: { [20540,20541]
operator: { [20446,20447]
===
match
---
name: received_logs [26266,26279]
name: received_logs [26172,26185]
===
match
---
dictorsetmaker [7591,7628]
dictorsetmaker [7591,7628]
===
match
---
name: node [37935,37939]
name: node [37841,37845]
===
match
---
operator: , [42469,42470]
operator: , [42375,42376]
===
match
---
not_test [14336,14380]
not_test [14242,14286]
===
match
---
simple_stmt [14389,14427]
simple_stmt [14295,14333]
===
match
---
string: 'bash_task' [6535,6546]
string: 'bash_task' [6535,6546]
===
match
---
param [18427,18449]
param [18333,18355]
===
match
---
param [8975,8979]
param [8975,8979]
===
match
---
operator: , [31588,31589]
operator: , [31494,31495]
===
match
---
atom_expr [5668,5677]
atom_expr [5668,5677]
===
match
---
trailer [24539,24569]
trailer [24445,24475]
===
match
---
simple_stmt [32315,32375]
simple_stmt [32221,32281]
===
match
---
trailer [21468,21473]
trailer [21374,21379]
===
match
---
operator: , [10090,10091]
operator: , [10090,10091]
===
match
---
atom_expr [25593,25608]
atom_expr [25499,25514]
===
match
---
string: 'wait_for_downstream' [35625,35646]
string: 'wait_for_downstream' [35531,35552]
===
match
---
string: "test_role" [10917,10928]
string: "test_role" [10917,10928]
===
match
---
simple_stmt [34085,36388]
simple_stmt [33991,36294]
===
match
---
atom [34302,34304]
atom [34208,34210]
===
match
---
argument [16235,16254]
argument [16141,16160]
===
match
---
name: get_extra_links [28827,28842]
name: get_extra_links [28733,28748]
===
match
---
string: 'task_4' [42539,42547]
string: 'task_2' [42445,42453]
===
match
---
operator: , [18113,18114]
operator: , [18019,18020]
===
match
---
number: 1 [22297,22298]
number: 1 [22203,22204]
===
match
---
name: DAG [23329,23332]
name: DAG [23235,23238]
===
match
---
operator: = [23425,23426]
operator: = [23331,23332]
===
match
---
trailer [15148,15166]
trailer [15054,15072]
===
match
---
name: metadata [1772,1780]
name: metadata [1772,1780]
===
match
---
operator: } [27850,27851]
operator: } [27756,27757]
===
match
---
name: serialized_dag [13868,13882]
name: serialized_dag [13774,13788]
===
match
---
name: test_date [28843,28852]
name: test_date [28749,28758]
===
match
---
operator: = [38787,38788]
operator: = [38693,38694]
===
match
---
string: "tasks" [27133,27140]
string: "tasks" [27039,27046]
===
match
---
trailer [8995,8997]
trailer [8995,8997]
===
match
---
atom_expr [32026,32097]
atom_expr [31932,32003]
===
match
---
simple_stmt [39871,39897]
simple_stmt [39777,39803]
===
match
---
trailer [1837,1986]
trailer [1837,1986]
===
match
---
operator: { [12821,12822]
operator: { [12821,12822]
===
match
---
name: datetime [18160,18168]
name: datetime [18066,18074]
===
match
---
simple_stmt [26061,26227]
simple_stmt [25967,26133]
===
match
---
with_stmt [17515,17780]
with_stmt [17421,17686]
===
match
---
atom_expr [32721,32779]
atom_expr [32627,32685]
===
match
---
name: proc [11549,11553]
name: proc [11549,11553]
===
match
---
operator: == [13261,13263]
operator: == [13127,13129]
===
match
---
name: expected_serialized [38034,38053]
name: expected_serialized [37940,37959]
===
match
---
name: days [19412,19416]
name: days [19318,19322]
===
match
---
trailer [13780,13785]
trailer [13686,13691]
===
match
---
number: 1 [19661,19662]
number: 1 [19567,19568]
===
match
---
name: dag [13810,13813]
name: dag [13716,13719]
===
match
---
name: setUp [8998,9003]
name: setUp [8998,9003]
===
match
---
number: 2019 [7351,7355]
number: 2019 [7351,7355]
===
match
---
operator: , [30518,30519]
operator: , [30424,30425]
===
match
---
number: 2019 [16488,16492]
number: 2019 [16394,16398]
===
match
---
suite [29514,29557]
suite [29420,29463]
===
match
---
atom_expr [21399,21419]
atom_expr [21305,21325]
===
match
---
assert_stmt [10180,10259]
assert_stmt [10180,10259]
===
match
---
number: 1 [40820,40821]
number: 1 [40726,40727]
===
match
---
name: serialized_dags [9692,9707]
name: serialized_dags [9692,9707]
===
match
---
trailer [6513,6759]
trailer [6513,6759]
===
match
---
name: val [20855,20858]
name: val [20761,20764]
===
match
---
string: "not registered" [26196,26212]
string: "not registered" [26102,26118]
===
match
---
name: dag [7369,7372]
name: dag [7369,7372]
===
match
---
trailer [12461,12469]
trailer [12461,12469]
===
match
---
argument [16838,16864]
argument [16744,16770]
===
match
---
if_stmt [16927,17281]
if_stmt [16833,17187]
===
match
---
name: mock [1010,1014]
name: mock [1010,1014]
===
match
---
operator: = [33201,33202]
operator: = [33107,33108]
===
match
---
name: default_args [7429,7441]
name: default_args [7429,7441]
===
match
---
operator: == [13614,13616]
operator: == [13520,13522]
===
match
---
trailer [22647,22662]
trailer [22553,22568]
===
match
---
name: validate_deserialized_dag [12549,12574]
name: validate_deserialized_dag [12549,12574]
===
match
---
operator: , [16138,16139]
operator: , [16044,16045]
===
match
---
operator: , [3182,3183]
operator: , [3182,3183]
===
match
---
name: dag [39083,39086]
name: dag [38989,38992]
===
match
---
operator: , [7548,7549]
operator: , [7548,7549]
===
match
---
operator: { [29656,29657]
operator: { [29562,29563]
===
match
---
trailer [32280,32290]
trailer [32186,32196]
===
match
---
atom [20346,20358]
atom [20252,20264]
===
match
---
string: "_is_dummy" [4683,4694]
string: "_is_dummy" [4683,4694]
===
match
---
name: validate_serialized_dag [10052,10075]
name: validate_serialized_dag [10052,10075]
===
match
---
string: """         Test that when on_success_callback is passed to the DAG, has_on_success_callback is stored         in Serialized JSON blob. And when it is de-serialized dag.has_on_success_callback is set to True.          When the callback is not set, has_on_success_callback should not be stored in Serialized blob         and so default to False on de-serialization         """ [40268,40643]
string: """         Test that when on_success_callback is passed to the DAG, has_on_success_callback is stored         in Serialized JSON blob. And when it is de-serialized dag.has_on_success_callback is set to True.          When the callback is not set, has_on_success_callback should not be stored in Serialized blob         and so default to False on de-serialization         """ [40174,40549]
===
match
---
operator: { [21952,21953]
operator: { [21858,21859]
===
match
---
name: serialized_obj [43301,43315]
name: serialized_obj [44054,44068]
===
match
---
expr_stmt [43367,43407]
expr_stmt [44120,44160]
===
match
---
name: isinstance [11753,11763]
name: isinstance [11753,11763]
===
match
---
operator: = [1857,1858]
operator: = [1857,1858]
===
match
---
trailer [11849,11873]
trailer [11849,11873]
===
match
---
simple_stmt [17395,17453]
simple_stmt [17301,17359]
===
match
---
name: GoogleLink [28854,28864]
name: GoogleLink [28760,28770]
===
match
---
parameters [39599,39614]
parameters [39505,39520]
===
match
---
atom [2661,2688]
atom [2661,2688]
===
match
---
string: "airflow/example_dags" [11850,11872]
string: "airflow/example_dags" [11850,11872]
===
match
---
argument [9104,9446]
argument [9104,9446]
===
match
---
atom_expr [32128,32186]
atom_expr [32034,32092]
===
match
---
name: from_dict [19050,19059]
name: from_dict [18956,18965]
===
match
---
string: "default_args" [19701,19715]
string: "default_args" [19607,19621]
===
match
---
number: 8 [42004,42005]
number: 8 [41910,41911]
===
match
---
name: dags [8557,8561]
name: dags [8557,8561]
===
match
---
name: airflow [36583,36590]
name: airflow [36489,36496]
===
match
---
name: BaseSerialization [44925,44942]
name: BaseSerialization [45678,45695]
===
match
---
testlist_comp [28212,28244]
testlist_comp [28118,28150]
===
match
---
param [29136,29144]
param [29042,29050]
===
match
---
funcdef [33775,36388]
funcdef [33681,36294]
===
match
---
name: os [5623,5625]
name: os [5623,5625]
===
match
---
trailer [25838,25843]
trailer [25744,25749]
===
match
---
trailer [22181,22202]
trailer [22087,22108]
===
match
---
name: fromlist [43875,43883]
name: fromlist [44628,44636]
===
match
---
atom_expr [37720,37742]
atom_expr [37626,37648]
===
match
---
trailer [11720,11730]
trailer [11720,11730]
===
match
---
trailer [5794,5807]
trailer [5794,5807]
===
match
---
suite [17211,17281]
suite [17117,17187]
===
match
---
trailer [22431,22434]
trailer [22337,22340]
===
match
---
trailer [24057,24066]
trailer [23963,23972]
===
match
---
arglist [17963,17994]
arglist [17869,17900]
===
match
---
annassign [32879,32963]
annassign [32785,32869]
===
match
---
comparison [17144,17197]
comparison [17050,17103]
===
match
---
number: 8 [17895,17896]
number: 8 [17801,17802]
===
match
---
operator: , [13027,13028]
operator: , [13027,13028]
===
match
---
number: 1 [2047,2048]
number: 1 [2047,2048]
===
match
---
name: expected_task_end_date [19166,19188]
name: expected_task_end_date [19072,19094]
===
match
---
testlist_comp [19272,19305]
testlist_comp [19178,19211]
===
match
---
trailer [16428,16461]
trailer [16334,16367]
===
match
---
name: airflow [1213,1220]
name: airflow [1213,1220]
===
match
---
name: dag [21379,21382]
name: dag [21285,21288]
===
match
---
name: dag [19098,19101]
name: dag [19004,19007]
===
match
---
operator: { [2245,2246]
operator: { [2245,2246]
===
match
---
atom_expr [12058,12082]
atom_expr [12058,12082]
===
match
---
operator: >= [16968,16970]
operator: >= [16874,16876]
===
match
---
atom [30194,30343]
atom [30100,30249]
===
match
---
string: 'all_success' [35598,35611]
string: 'all_success' [35504,35517]
===
match
---
trailer [36834,36846]
trailer [36740,36752]
===
match
---
arglist [24342,24384]
arglist [24248,24290]
===
match
---
simple_stmt [8811,8849]
simple_stmt [8811,8849]
===
match
---
atom_expr [17880,17921]
atom_expr [17786,17827]
===
match
---
trailer [13371,13384]
trailer [13277,13290]
===
match
---
name: DummyOperator [38817,38830]
name: DummyOperator [38723,38736]
===
match
---
name: serialized_dag [22484,22498]
name: serialized_dag [22390,22404]
===
match
---
trailer [43814,43825]
trailer [44567,44578]
===
match
---
expr_stmt [23635,23677]
expr_stmt [23541,23583]
===
match
---
simple_stmt [24227,24315]
simple_stmt [24133,24221]
===
match
---
dictorsetmaker [7498,7549]
dictorsetmaker [7498,7549]
===
match
---
string: "dag" [21607,21612]
string: "dag" [21513,21518]
===
match
---
operator: } [5571,5572]
operator: } [5571,5572]
===
match
---
atom [6309,6382]
atom [6309,6382]
===
match
---
name: dag [27222,27225]
name: dag [27128,27131]
===
match
---
trailer [24050,24057]
trailer [23956,23963]
===
match
---
name: dag_dict [10972,10980]
name: dag_dict [10972,10980]
===
match
---
name: deserialize_dag [39183,39198]
name: deserialize_dag [39089,39104]
===
match
---
trailer [5625,5630]
trailer [5625,5630]
===
match
---
suite [36859,37076]
suite [36765,36982]
===
match
---
operator: , [21058,21059]
operator: , [20964,20965]
===
match
---
operator: == [35706,35708]
operator: == [35612,35614]
===
match
---
atom [4663,4665]
atom [4663,4665]
===
match
---
param [10337,10351]
param [10337,10351]
===
match
---
expr_stmt [27154,27199]
expr_stmt [27060,27105]
===
match
---
trailer [17268,17277]
trailer [17174,17183]
===
match
---
atom_expr [20513,20538]
atom_expr [20419,20444]
===
match
---
operator: = [41843,41844]
operator: = [41749,41750]
===
match
---
name: DagBag [1310,1316]
name: DagBag [1310,1316]
===
match
---
arglist [13238,13259]
arglist [13104,13125]
===
match
---
suite [13343,13720]
suite [13249,13626]
===
match
---
operator: , [20335,20336]
operator: , [20241,20242]
===
match
---
trailer [37724,37733]
trailer [37630,37639]
===
match
---
name: put [8859,8862]
name: put [8859,8862]
===
match
---
trailer [7931,7950]
trailer [7931,7950]
===
match
---
string: "foo1" [30085,30091]
string: "foo1" [29991,29997]
===
match
---
for_stmt [13047,13314]
for_stmt [13047,13220]
===
match
---
name: dag [8616,8619]
name: dag [8616,8619]
===
match
---
name: isinstance [43290,43300]
name: isinstance [44043,44053]
===
match
---
name: __eq__ [29543,29549]
name: __eq__ [29449,29455]
===
match
---
operator: , [40216,40217]
operator: , [40122,40123]
===
match
---
name: simple_task [24238,24249]
name: simple_task [24144,24155]
===
match
---
argument [19431,19437]
argument [19337,19343]
===
match
---
operator: , [24549,24550]
operator: , [24455,24456]
===
match
---
comparison [24036,24174]
comparison [23942,24080]
===
match
---
simple_stmt [8853,8869]
simple_stmt [8853,8869]
===
match
---
string: 'upstream_group_ids' [2806,2826]
string: 'upstream_group_ids' [2806,2826]
===
match
---
string: 'retry_exponential_backoff' [35349,35376]
string: 'retry_exponential_backoff' [35255,35282]
===
match
---
or_test [16930,16986]
or_test [16836,16892]
===
match
---
string: "fileloc" [3094,3103]
string: "fileloc" [3094,3103]
===
match
---
assert_stmt [28392,28481]
assert_stmt [28298,28387]
===
match
---
atom_expr [17619,17654]
atom_expr [17525,17560]
===
match
---
operator: , [40147,40148]
operator: , [40053,40054]
===
match
---
name: level [25918,25923]
name: level [25824,25829]
===
match
---
name: self [12027,12031]
name: self [12027,12031]
===
match
---
name: val [21330,21333]
name: val [21236,21239]
===
match
---
simple_stmt [9662,9684]
simple_stmt [9662,9684]
===
match
---
atom_expr [41146,41186]
atom_expr [41052,41092]
===
match
---
parameters [6835,6837]
parameters [6835,6837]
===
match
---
trailer [12469,12474]
trailer [12469,12474]
===
match
---
simple_stmt [15589,15640]
simple_stmt [15495,15546]
===
match
---
operator: { [11590,11591]
operator: { [11590,11591]
===
match
---
argument [43866,43883]
argument [44619,44636]
===
match
---
name: make_user_defined_macro_filter_dag [6801,6835]
name: make_user_defined_macro_filter_dag [6801,6835]
===
match
---
name: val [21485,21488]
name: val [21391,21394]
===
match
---
name: CustomOperator [26947,26961]
name: CustomOperator [26853,26867]
===
match
---
argument [33525,33540]
argument [33431,33446]
===
match
---
atom_expr [10758,10766]
atom_expr [10758,10766]
===
match
---
operator: , [17896,17897]
operator: , [17802,17803]
===
match
---
string: "__var" [43399,43406]
string: "__var" [44152,44159]
===
match
---
trailer [29289,29299]
trailer [29195,29205]
===
match
---
name: __init__ [29121,29129]
name: __init__ [29027,29035]
===
match
---
number: 2 [20727,20728]
number: 2 [20633,20634]
===
match
---
simple_stmt [6768,6795]
simple_stmt [6768,6795]
===
match
---
atom_expr [20169,20201]
atom_expr [20075,20107]
===
match
---
atom_expr [43232,43278]
atom_expr [43985,44031]
===
match
---
operator: = [26078,26079]
operator: = [25984,25985]
===
match
---
simple_stmt [36442,36512]
simple_stmt [36348,36418]
===
match
---
trailer [18567,18623]
trailer [18473,18529]
===
match
---
arglist [15312,15334]
arglist [15218,15240]
===
match
---
operator: { [24266,24267]
operator: { [24172,24173]
===
match
---
operator: , [24293,24294]
operator: , [24199,24200]
===
match
---
name: Mock [9045,9049]
name: Mock [9045,9049]
===
match
---
operator: , [19381,19382]
operator: , [19287,19288]
===
match
---
operator: , [17893,17894]
operator: , [17799,17800]
===
match
---
trailer [43757,43789]
trailer [44510,44542]
===
match
---
trailer [22637,22647]
trailer [22543,22553]
===
match
---
operator: , [41302,41303]
operator: , [41208,41209]
===
match
---
simple_stmt [38284,38291]
simple_stmt [38190,38197]
===
match
---
comparison [19142,19188]
comparison [19048,19094]
===
match
---
operator: = [12789,12790]
operator: = [12789,12790]
===
match
---
operator: , [16104,16105]
operator: , [16010,16011]
===
match
---
dotted_name [17786,17806]
dotted_name [17692,17712]
===
match
---
funcdef [36393,38420]
funcdef [36299,38326]
===
match
---
trailer [18287,18321]
trailer [18193,18227]
===
match
---
atom_expr [28557,28618]
atom_expr [28463,28524]
===
match
---
atom_expr [29177,29191]
atom_expr [29083,29097]
===
match
---
trailer [18227,18261]
trailer [18133,18167]
===
match
---
operator: = [16848,16849]
operator: = [16754,16755]
===
match
---
name: dags [7955,7959]
name: dags [7955,7959]
===
match
---
atom_expr [8388,8420]
atom_expr [8388,8420]
===
match
---
operator: , [31603,31604]
operator: , [31509,31510]
===
match
---
operator: , [6627,6628]
operator: , [6627,6628]
===
match
---
name: serialized_dag [27184,27198]
name: serialized_dag [27090,27104]
===
match
---
simple_stmt [36634,36672]
simple_stmt [36540,36578]
===
match
---
trailer [7966,8004]
trailer [7966,8004]
===
match
---
operator: = [8186,8187]
operator: = [8186,8187]
===
match
---
import_from [1168,1207]
import_from [1168,1207]
===
match
---
name: os [5679,5681]
name: os [5679,5681]
===
match
---
string: 'task_1' [42519,42527]
string: 'task_1' [42425,42433]
===
match
---
name: datetime [41989,41997]
name: datetime [41895,41903]
===
match
---
name: k8s [1123,1126]
name: k8s [1123,1126]
===
match
---
operator: , [4379,4380]
operator: , [4379,4380]
===
match
---
name: TaskStateLink [25190,25203]
name: TaskStateLink [25096,25109]
===
match
---
operator: , [14880,14881]
operator: , [14786,14787]
===
match
---
dictorsetmaker [42896,42948]
dictorsetmaker [43476,43528]
===
match
---
operator: , [26992,26993]
operator: , [26898,26899]
===
match
---
trailer [22498,22505]
trailer [22404,22411]
===
match
---
name: imported_airflow [44633,44649]
name: imported_airflow [45386,45402]
===
match
---
name: self [12144,12148]
name: self [12144,12148]
===
match
---
simple_stmt [16875,16919]
simple_stmt [16781,16825]
===
match
---
funcdef [10048,11072]
funcdef [10048,11072]
===
match
---
atom_expr [19402,19419]
atom_expr [19308,19325]
===
match
---
name: BashOperator [1437,1449]
name: BashOperator [1437,1449]
===
match
---
suite [36965,37076]
suite [36871,36982]
===
match
---
name: super [8990,8995]
name: super [8990,8995]
===
match
---
string: 'task_5' [42549,42557]
string: 'task_4' [42455,42463]
===
match
---
operator: { [24161,24162]
operator: { [24067,24068]
===
match
---
name: dag [25747,25750]
name: dag [25653,25656]
===
match
---
simple_stmt [890,900]
simple_stmt [890,900]
===
match
---
name: subdag [16025,16031]
name: subdag [15931,15937]
===
match
---
comparison [20102,20153]
comparison [20008,20059]
===
match
---
name: k8s [1872,1875]
name: k8s [1872,1875]
===
match
---
operator: , [16436,16437]
operator: , [16342,16343]
===
match
---
fstring_expr [15393,15410]
fstring_expr [15299,15316]
===
match
---
param [25371,25380]
param [25277,25286]
===
match
---
param [16653,16658]
param [16559,16564]
===
match
---
with_stmt [43903,45083]
with_stmt [44656,45836]
===
match
---
param [39600,39605]
param [39506,39511]
===
match
---
trailer [23552,23559]
trailer [23458,23465]
===
match
---
name: dag_id [16737,16743]
name: dag_id [16643,16649]
===
match
---
string: 'end_date' [34674,34684]
string: 'end_date' [34580,34590]
===
match
---
atom [29965,30180]
atom [29871,30086]
===
match
---
trailer [42241,42248]
trailer [42147,42154]
===
match
---
name: serialized_task [15312,15327]
name: serialized_task [15218,15233]
===
match
---
string: "bash_command" [27093,27107]
string: "bash_command" [26999,27013]
===
match
---
name: dag [21383,21386]
name: dag [21289,21292]
===
match
---
number: 2019 [25731,25735]
number: 2019 [25637,25641]
===
match
---
operator: , [5526,5527]
operator: , [5526,5527]
===
match
---
simple_stmt [10366,10665]
simple_stmt [10366,10665]
===
match
---
name: seconds [6181,6188]
name: seconds [6181,6188]
===
match
---
atom_expr [8821,8847]
atom_expr [8821,8847]
===
match
---
name: _deserialize [20937,20949]
name: _deserialize [20843,20855]
===
match
---
operator: , [14713,14714]
operator: , [14619,14620]
===
match
---
funcdef [29405,29481]
funcdef [29311,29387]
===
match
---
operator: == [43438,43440]
operator: == [44191,44193]
===
match
---
atom [40069,40115]
atom [39975,40021]
===
match
---
trailer [19101,19111]
trailer [19007,19017]
===
match
---
operator: , [20360,20361]
operator: , [20266,20267]
===
match
---
dictorsetmaker [20675,20730]
dictorsetmaker [20581,20636]
===
match
---
fstring_start: f' [15391,15393]
fstring_start: f' [15297,15299]
===
match
---
import_name [900,915]
import_name [900,915]
===
match
---
expr_stmt [8135,8158]
expr_stmt [8135,8158]
===
match
---
name: deserialized_simple_task [22594,22618]
name: deserialized_simple_task [22500,22524]
===
match
---
string: 'fileloc' [10203,10212]
string: 'fileloc' [10203,10212]
===
match
---
operator: , [12298,12299]
operator: , [12298,12299]
===
match
---
name: user_defined_macros [7464,7483]
name: user_defined_macros [7464,7483]
===
match
---
name: test_dag_params_roundtrip [21146,21171]
name: test_dag_params_roundtrip [21052,21077]
===
match
---
atom_expr [14340,14380]
atom_expr [14246,14286]
===
match
---
import_as_names [1065,1082]
import_as_names [1065,1082]
===
match
---
atom [21913,22010]
atom [21819,21916]
===
match
---
name: models [1344,1350]
name: models [1344,1350]
===
match
---
operator: , [2999,3000]
operator: , [2999,3000]
===
match
---
string: 'test_dag_serialization.py' [10232,10259]
string: 'test_dag_serialization.py' [10232,10259]
===
match
---
name: simple_task [28322,28333]
name: simple_task [28228,28239]
===
match
---
name: __dict__ [29454,29462]
name: __dict__ [29360,29368]
===
match
---
atom_expr [10849,10952]
atom_expr [10849,10952]
===
match
---
operator: = [16813,16814]
operator: = [16719,16720]
===
match
---
name: default_args [7312,7324]
name: default_args [7312,7324]
===
match
---
string: "{{ task.task_id }}" [29928,29948]
string: "{{ task.task_id }}" [29834,29854]
===
match
---
string: 'task_id' [35553,35562]
string: 'task_id' [35459,35468]
===
match
---
name: DAG [32026,32029]
name: DAG [31932,31935]
===
match
---
dictorsetmaker [20578,20592]
dictorsetmaker [20484,20498]
===
match
---
name: from_dict [41104,41113]
name: from_dict [41010,41019]
===
match
---
atom_expr [21447,21473]
atom_expr [21353,21379]
===
match
---
name: serialized_dag [42020,42034]
name: serialized_dag [41926,41940]
===
match
---
atom_expr [20666,20671]
atom_expr [20572,20577]
===
match
---
string: "bash_command" [3742,3756]
string: "bash_command" [3742,3756]
===
match
---
atom_expr [12424,12475]
atom_expr [12424,12475]
===
match
---
expr_stmt [37858,37949]
expr_stmt [37764,37855]
===
match
---
name: blob [39840,39844]
name: blob [39746,39750]
===
match
---
atom [32887,32963]
atom [32793,32869]
===
match
---
string: "start_date" [17144,17156]
string: "start_date" [17050,17062]
===
match
---
name: dag_id [21302,21308]
name: dag_id [21208,21214]
===
match
---
string: "dag" [21536,21541]
string: "dag" [21442,21447]
===
match
---
string: "airflow/example_dags" [11489,11511]
string: "airflow/example_dags" [11489,11511]
===
match
---
name: serialized_dag [23461,23475]
name: serialized_dag [23367,23381]
===
match
---
operator: == [23730,23732]
operator: == [23636,23638]
===
match
---
arglist [10711,10767]
arglist [10711,10767]
===
match
---
name: dags [12159,12163]
name: dags [12159,12163]
===
match
---
string: """         Assert extra field exists & OperatorLinks defined in Plugins and inbuilt Operator Links.          This tests also depends on GoogleLink() registered as a plugin         in tests/plugins/test_plugin.py          The function tests that if extra operator links are registered in plugin         in ``operator_extra_links`` and the same is also defined in         the Operator in ``BaseOperator.operator_extra_links``, it has the correct         extra link.         """ [26360,26836]
string: """         Assert extra field exists & OperatorLinks defined in Plugins and inbuilt Operator Links.          This tests also depends on GoogleLink() registered as a plugin         in tests/plugins/test_plugin.py          The function tests that if extra operator links are registered in plugin         in ``operator_extra_links`` and the same is also defined in         the Operator in ``BaseOperator.operator_extra_links``, it has the correct         extra link.         """ [26266,26742]
===
match
---
name: airflow [1455,1462]
name: airflow [1455,1462]
===
match
---
atom_expr [38087,38151]
atom_expr [37993,38057]
===
match
---
string: "owner" [3200,3207]
string: "owner" [3200,3207]
===
match
---
name: set [34340,34343]
name: set [34246,34249]
===
match
---
comparison [43673,43683]
comparison [44426,44436]
===
match
---
string: 'default' [35223,35232]
string: 'default' [35129,35138]
===
match
---
string: "bash_command" [27287,27301]
string: "bash_command" [27193,27207]
===
match
---
name: dag [12791,12794]
name: dag [12791,12794]
===
match
---
trailer [37921,37949]
trailer [37827,37855]
===
match
---
name: check_task_group [38376,38392]
name: check_task_group [38282,38298]
===
match
---
dictorsetmaker [30296,30325]
dictorsetmaker [30202,30231]
===
match
---
name: dag [32020,32023]
name: dag [31926,31929]
===
match
---
trailer [36942,36953]
trailer [36848,36859]
===
match
---
simple_stmt [44918,44967]
simple_stmt [45671,45720]
===
match
---
name: SerializedDAG [39199,39212]
name: SerializedDAG [39105,39118]
===
match
---
parameters [8673,8692]
parameters [8673,8692]
===
match
---
name: __dict__ [29320,29328]
name: __dict__ [29226,29234]
===
match
---
name: baseoperator [1351,1363]
name: baseoperator [1351,1363]
===
match
---
trailer [39990,39995]
trailer [39896,39901]
===
match
---
funcdef [12545,14086]
funcdef [12545,13992]
===
match
---
operator: >> [38866,38868]
operator: >> [38772,38774]
===
match
---
operator: , [5666,5667]
operator: , [5666,5667]
===
match
---
arglist [17840,17871]
arglist [17746,17777]
===
match
---
argument [41969,41976]
argument [41875,41882]
===
match
---
number: 0 [43682,43683]
number: 0 [44435,44436]
===
match
---
name: serialized_dag [21430,21444]
name: serialized_dag [21336,21350]
===
match
---
trailer [32290,32306]
trailer [32196,32212]
===
match
---
simple_stmt [44456,44598]
simple_stmt [45209,45351]
===
match
---
annassign [32982,33027]
annassign [32888,32933]
===
match
---
expr_stmt [14436,14949]
expr_stmt [14342,14855]
===
match
---
name: datetime [7342,7350]
name: datetime [7342,7350]
===
match
---
argument [18524,18545]
argument [18430,18451]
===
match
---
funcdef [21142,21877]
funcdef [21048,21783]
===
match
---
atom_expr [12166,12323]
atom_expr [12166,12323]
===
match
---
simple_stmt [15509,15563]
simple_stmt [15415,15469]
===
match
---
string: 'on_success_callback' [34989,35010]
string: 'on_success_callback' [34895,34916]
===
match
---
trailer [18927,18936]
trailer [18833,18842]
===
match
---
simple_stmt [36876,36911]
simple_stmt [36782,36817]
===
match
---
dictorsetmaker [21074,21094]
dictorsetmaker [20980,21000]
===
match
---
string: "_access_control" [10889,10906]
string: "_access_control" [10889,10906]
===
match
---
operator: , [29166,29167]
operator: , [29072,29073]
===
match
---
operator: , [5569,5570]
operator: , [5569,5570]
===
match
---
parameters [37668,37674]
parameters [37574,37580]
===
match
---
number: 2019 [40811,40815]
number: 2019 [40717,40721]
===
match
---
trailer [33210,33223]
trailer [33116,33129]
===
match
---
atom_expr [39249,39273]
atom_expr [39155,39179]
===
match
---
exprlist [13360,13364]
exprlist [13266,13270]
===
match
---
trailer [16024,16031]
trailer [15930,15937]
===
match
---
name: ClassWithCustomAttributes [28949,28974]
name: ClassWithCustomAttributes [28855,28880]
===
match
---
atom_expr [38943,38969]
atom_expr [38849,38875]
===
match
---
number: 8 [18175,18176]
number: 8 [18081,18082]
===
match
---
atom_expr [7664,7802]
atom_expr [7664,7802]
===
match
---
string: "Operator Link class 'tests.serialization.test_dag_serialization.TaskStateLink' " [26098,26179]
string: "Operator Link class 'tests.serialization.test_dag_serialization.TaskStateLink' " [26004,26085]
===
match
---
atom_expr [15827,15841]
atom_expr [15733,15747]
===
match
---
name: expand [40038,40044]
name: expand [39944,39950]
===
match
---
operator: , [17899,17900]
operator: , [17805,17806]
===
match
---
argument [6101,6111]
argument [6101,6111]
===
match
---
testlist_comp [29872,29950]
testlist_comp [29778,29856]
===
match
---
atom [20589,20592]
atom [20495,20498]
===
match
---
string: 'task_1' [42809,42817]
string: 'task_1' [42715,42723]
===
match
---
strings [31193,31588]
strings [31099,31494]
===
match
---
name: permissions [5465,5476]
name: permissions [5465,5476]
===
match
---
trailer [24396,24406]
trailer [24302,24312]
===
match
---
trailer [30745,31175]
trailer [30651,31081]
===
match
---
string: 'subdag' [14558,14566]
string: 'subdag' [14464,14472]
===
match
---
string: 'task_concurrency' [35515,35533]
string: 'task_concurrency' [35421,35439]
===
match
---
arglist [13868,13923]
arglist [13774,13829]
===
match
---
operator: } [4317,4318]
operator: } [4317,4318]
===
match
---
suite [25222,25436]
suite [25128,25342]
===
match
---
name: json_dag [39128,39136]
name: json_dag [39034,39042]
===
match
---
suite [8168,8334]
suite [8168,8334]
===
match
---
name: dag [38965,38968]
name: dag [38871,38874]
===
match
---
operator: = [17530,17531]
operator: = [17436,17437]
===
match
---
simple_stmt [23282,23315]
simple_stmt [23188,23221]
===
match
---
atom_expr [36933,36953]
atom_expr [36839,36859]
===
match
---
simple_stmt [26886,26939]
simple_stmt [26792,26845]
===
match
---
argument [17632,17653]
argument [17538,17559]
===
match
---
string: "airflow.serialization.serialized_objects" [44178,44220]
string: "airflow.serialization.serialized_objects" [44931,44973]
===
match
---
operator: , [13669,13670]
operator: , [13575,13576]
===
match
---
simple_stmt [21690,21759]
simple_stmt [21596,21665]
===
match
---
trailer [37338,37346]
trailer [37244,37252]
===
match
---
expr_stmt [32196,32239]
expr_stmt [32102,32145]
===
match
---
name: DAG [21298,21301]
name: DAG [21204,21207]
===
match
---
name: executor_config_pod [4230,4249]
name: executor_config_pod [4230,4249]
===
match
---
comp_op [41033,41039]
comp_op [40939,40945]
===
match
---
operator: { [29920,29921]
operator: { [29826,29827]
===
match
---
string: """         Assert OperatorLinks not registered via Plugins and if it is not an inbuilt Operator Link,         it can still deserialize the DAG (does not error) but just logs an error         """ [24979,25174]
string: """         Assert OperatorLinks not registered via Plugins and if it is not an inbuilt Operator Link,         it can still deserialize the DAG (does not error) but just logs an error         """ [24885,25080]
===
match
---
dotted_name [38615,38641]
dotted_name [38521,38547]
===
match
---
operator: } [19746,19747]
operator: } [19652,19653]
===
match
---
trailer [17766,17774]
trailer [17672,17680]
===
match
---
string: "tasks" [18928,18935]
string: "tasks" [18834,18841]
===
match
---
operator: , [2407,2408]
operator: , [2407,2408]
===
match
---
atom [42967,43021]
atom [43547,43601]
===
match
---
operator: } [29908,29909]
operator: } [29814,29815]
===
match
---
name: _serialize [43246,43256]
name: _serialize [43999,44009]
===
match
---
atom_expr [29449,29462]
atom_expr [29355,29368]
===
match
---
simple_stmt [28182,28247]
simple_stmt [28088,28153]
===
match
---
trailer [37490,37495]
trailer [37396,37401]
===
match
---
trailer [33193,33210]
trailer [33099,33116]
===
match
---
simple_stmt [19030,19076]
simple_stmt [18936,18982]
===
match
---
operator: = [1959,1960]
operator: = [1959,1960]
===
match
---
operator: , [6351,6352]
operator: , [6351,6352]
===
match
---
name: SerializedDAG [37242,37255]
name: SerializedDAG [37148,37161]
===
match
---
comparison [39878,39896]
comparison [39784,39802]
===
match
---
trailer [44498,44504]
trailer [45251,45257]
===
match
---
comparison [11656,11665]
comparison [11656,11665]
===
match
---
atom [42895,42949]
atom [43475,43529]
===
match
---
funcdef [12103,12540]
funcdef [12103,12540]
===
match
---
operator: = [17555,17556]
operator: = [17461,17462]
===
match
---
name: isinstance [15936,15946]
name: isinstance [15842,15852]
===
match
---
suite [16987,17198]
suite [16893,17104]
===
match
---
name: self [18392,18396]
name: self [18298,18302]
===
match
---
name: keys [37632,37636]
name: keys [37538,37542]
===
match
---
funcdef [17458,17780]
funcdef [17364,17686]
===
match
---
string: 'user_defined_macro_filter_dag' [7388,7419]
string: 'user_defined_macro_filter_dag' [7388,7419]
===
match
---
argument [33441,33449]
argument [33347,33355]
===
match
---
name: locals_ [43857,43864]
name: locals_ [44610,44617]
===
match
---
atom [27753,27765]
atom [27659,27671]
===
match
---
operator: , [43623,43624]
operator: , [44376,44377]
===
match
---
operator: = [32075,32076]
operator: = [31981,31982]
===
match
---
dictorsetmaker [21098,21118]
dictorsetmaker [21004,21024]
===
match
---
string: "dag" [42242,42247]
string: "dag" [42148,42153]
===
match
---
name: children [37623,37631]
name: children [37529,37537]
===
match
---
dictorsetmaker [20446,20468]
dictorsetmaker [20352,20374]
===
match
---
operator: == [27678,27680]
operator: == [27584,27586]
===
match
---
name: DummyOperator [38766,38779]
name: DummyOperator [38672,38685]
===
match
---
trailer [15611,15621]
trailer [15517,15527]
===
match
---
operator: { [19634,19635]
operator: { [19540,19541]
===
match
---
name: k [13504,13505]
name: k [13410,13411]
===
match
---
operator: { [41256,41257]
operator: { [41162,41163]
===
match
---
string: "tasks" [22423,22430]
string: "tasks" [22329,22336]
===
match
---
trailer [1875,1887]
trailer [1875,1887]
===
match
---
operator: , [35441,35442]
operator: , [35347,35348]
===
match
---
arglist [22288,22298]
arglist [22194,22204]
===
match
---
operator: { [9710,9711]
operator: { [9710,9711]
===
match
---
name: from_dict [21656,21665]
name: from_dict [21562,21571]
===
match
---
number: 2019 [17889,17893]
number: 2019 [17795,17799]
===
match
---
trailer [10726,10735]
trailer [10726,10735]
===
match
---
name: SerializedDAG [39061,39074]
name: SerializedDAG [38967,38980]
===
match
---
atom [19271,19306]
atom [19177,19212]
===
match
---
simple_stmt [24324,24386]
simple_stmt [24230,24292]
===
match
---
operator: , [32908,32909]
operator: , [32814,32815]
===
match
---
trailer [29385,29393]
trailer [29291,29299]
===
match
---
name: self [10076,10080]
name: self [10076,10080]
===
match
---
simple_stmt [21343,21421]
simple_stmt [21249,21327]
===
match
---
simple_stmt [12488,12540]
simple_stmt [12488,12540]
===
match
---
name: serialized_simple_dag_ground_truth [1991,2025]
name: serialized_simple_dag_ground_truth [1991,2025]
===
match
---
string: "depends_on_past" [6126,6143]
string: "depends_on_past" [6126,6143]
===
match
---
trailer [32743,32758]
trailer [32649,32664]
===
match
---
argument [41946,41967]
argument [41852,41873]
===
match
---
trailer [7959,7966]
trailer [7959,7966]
===
match
---
name: path [5626,5630]
name: path [5626,5630]
===
match
---
atom_expr [25722,25742]
atom_expr [25628,25648]
===
match
---
arglist [29217,29233]
arglist [29123,29139]
===
match
---
trailer [21665,21681]
trailer [21571,21587]
===
match
---
operator: , [3540,3541]
operator: , [3540,3541]
===
match
---
atom_expr [42139,42160]
atom_expr [42045,42066]
===
match
---
parameters [11116,11122]
parameters [11116,11122]
===
match
---
name: test_deserialization_schedule_interval [19465,19503]
name: test_deserialization_schedule_interval [19371,19409]
===
match
---
name: SerializedDAG [27051,27064]
name: SerializedDAG [26957,26970]
===
match
---
trailer [18108,18112]
trailer [18014,18018]
===
match
---
name: timezone [16301,16309]
name: timezone [16207,16215]
===
match
---
trailer [32226,32234]
trailer [32132,32140]
===
match
---
comparison [41146,41204]
comparison [41052,41110]
===
match
---
atom [30083,30165]
atom [29989,30071]
===
match
---
expr_stmt [44146,44221]
expr_stmt [44899,44974]
===
match
---
trailer [40661,40737]
trailer [40567,40643]
===
match
---
operator: , [21120,21121]
operator: , [21026,21027]
===
match
---
fstring [29282,29332]
fstring [29188,29238]
===
match
---
argument [38831,38846]
argument [38737,38752]
===
match
---
string: "foo2" [30126,30132]
string: "foo2" [30032,30038]
===
match
---
atom_expr [32990,33012]
atom_expr [32896,32918]
===
match
---
name: sorted_serialized_dag [11040,11061]
name: sorted_serialized_dag [11040,11061]
===
match
---
atom_expr [27922,27950]
atom_expr [27828,27856]
===
match
---
trailer [21733,21743]
trailer [21639,21649]
===
match
---
expr_stmt [9014,9470]
expr_stmt [9014,9470]
===
match
---
assert_stmt [43416,43456]
assert_stmt [44169,44209]
===
match
---
expr_stmt [19084,19126]
expr_stmt [18990,19032]
===
match
---
atom_expr [8853,8868]
atom_expr [8853,8868]
===
match
---
string: "_dag_id" [19766,19775]
string: "_dag_id" [19672,19681]
===
match
---
simple_stmt [25235,25309]
simple_stmt [25141,25215]
===
match
---
argument [20398,20405]
argument [20304,20311]
===
match
---
trailer [33429,33431]
trailer [33335,33337]
===
match
---
atom_expr [21790,21813]
atom_expr [21696,21719]
===
match
---
name: dag [13278,13281]
name: dag [13184,13187]
===
match
---
string: "dict" [5307,5313]
string: "dict" [5307,5313]
===
match
---
atom_expr [40802,40822]
atom_expr [40708,40728]
===
match
---
operator: = [21382,21383]
operator: = [21288,21289]
===
match
---
string: "_operator_extra_links" [27653,27676]
string: "_operator_extra_links" [27559,27582]
===
match
---
atom_expr [11423,11513]
atom_expr [11423,11513]
===
match
---
name: deserialized_dag [21623,21639]
name: deserialized_dag [21529,21545]
===
match
---
operator: == [20202,20204]
operator: == [20108,20110]
===
match
---
number: 8 [22294,22295]
number: 8 [22200,22201]
===
match
---
name: dag [16727,16730]
name: dag [16633,16636]
===
match
---
name: serialized_schedule_interval [19519,19547]
name: serialized_schedule_interval [19425,19453]
===
match
---
operator: = [39678,39679]
operator: = [39584,39585]
===
match
---
parameters [16652,16717]
parameters [16558,16623]
===
match
---
operator: { [20309,20310]
operator: { [20215,20216]
===
match
---
operator: , [5216,5217]
operator: , [5216,5217]
===
match
---
name: serialize_dag [39213,39226]
name: serialize_dag [39119,39132]
===
match
---
atom_expr [38376,38419]
atom_expr [38282,38325]
===
match
---
name: Queue [11400,11405]
name: Queue [11400,11405]
===
match
---
string: "test label" [38875,38887]
string: "test label" [38781,38793]
===
match
---
assert_stmt [13729,13785]
assert_stmt [13635,13691]
===
match
---
string: "dag" [40967,40972]
string: "dag" [40873,40878]
===
match
---
parameters [29415,29428]
parameters [29321,29334]
===
match
---
trailer [11914,11916]
trailer [11914,11916]
===
match
---
name: SerializedDAG [22546,22559]
name: SerializedDAG [22452,22465]
===
match
---
string: "task3" [42896,42903]
string: "task3" [43476,43483]
===
match
---
string: 'doc_md' [34486,34494]
string: 'doc_md' [34392,34400]
===
match
---
number: 1 [25740,25741]
number: 1 [25646,25647]
===
match
---
expr_stmt [5779,5807]
expr_stmt [5779,5807]
===
match
---
operator: = [30453,30454]
operator: = [30359,30360]
===
match
---
name: c [44489,44490]
name: c [45242,45243]
===
match
---
operator: = [36798,36799]
operator: = [36704,36705]
===
match
---
operator: , [7629,7630]
operator: , [7629,7630]
===
match
---
atom [30357,30688]
atom [30263,30594]
===
match
---
operator: , [27285,27286]
operator: , [27191,27192]
===
match
---
operator: , [19292,19293]
operator: , [19198,19199]
===
match
---
name: self [29501,29505]
name: self [29407,29411]
===
match
---
atom_expr [20050,20085]
atom_expr [19956,19991]
===
match
---
string: "simple_dag" [45068,45080]
string: "simple_dag" [45821,45833]
===
match
---
name: blob [39726,39730]
name: blob [39632,39636]
===
match
---
assert_stmt [33727,33769]
assert_stmt [33633,33675]
===
match
---
operator: == [24643,24645]
operator: == [24549,24551]
===
match
---
operator: , [1633,1634]
operator: , [1633,1634]
===
match
---
name: get_extra_links [28334,28349]
name: get_extra_links [28240,28255]
===
match
---
atom_expr [11629,11640]
atom_expr [11629,11640]
===
match
---
name: validate_schema [38992,39007]
name: validate_schema [38898,38913]
===
match
---
operator: } [40138,40139]
operator: } [40044,40045]
===
match
---
name: ClassWithCustomAttributes [30775,30800]
name: ClassWithCustomAttributes [30681,30706]
===
match
---
argument [1798,1812]
argument [1798,1812]
===
match
---
name: custom_inbuilt_link [28697,28716]
name: custom_inbuilt_link [28603,28622]
===
match
---
name: blob [33712,33716]
name: blob [33618,33622]
===
match
---
atom_expr [9947,10042]
atom_expr [9947,10042]
===
match
---
string: "weekday" [20712,20721]
string: "weekday" [20618,20627]
===
match
---
string: 'bash_task' [3810,3821]
string: 'bash_task' [3810,3821]
===
match
---
dotted_name [1271,1285]
dotted_name [1271,1285]
===
match
---
atom_expr [13413,13424]
atom_expr [13319,13330]
===
match
---
string: "true" [27315,27321]
string: "true" [27221,27227]
===
match
---
string: """         This test verifies that there are no new fields added to BaseOperator. And reminds that         tests should be added for it.         """ [33836,33985]
string: """         This test verifies that there are no new fields added to BaseOperator. And reminds that         tests should be added for it.         """ [33742,33891]
===
match
---
trailer [20657,20672]
trailer [20563,20578]
===
match
---
name: serialize_pod [4216,4229]
name: serialize_pod [4216,4229]
===
match
---
name: ClassWithCustomAttributes [30956,30981]
name: ClassWithCustomAttributes [30862,30887]
===
match
---
string: 'test_dag_on_success_callback_roundtrip' [40669,40709]
string: 'test_dag_on_success_callback_roundtrip' [40575,40615]
===
match
---
name: dag [16829,16832]
name: dag [16735,16738]
===
match
---
name: to_dict [37221,37228]
name: to_dict [37127,37134]
===
match
---
testlist_comp [12210,12299]
testlist_comp [12210,12299]
===
match
---
atom_expr [15394,15409]
atom_expr [15300,15315]
===
match
---
operator: , [29134,29135]
operator: , [29040,29041]
===
match
---
name: dag_id [23333,23339]
name: dag_id [23239,23245]
===
match
---
atom [24098,24174]
atom [24004,24080]
===
match
---
name: SerializedBaseOperator [14297,14319]
name: SerializedBaseOperator [14203,14225]
===
match
---
operator: , [2716,2717]
operator: , [2716,2717]
===
match
---
atom_expr [30775,30926]
atom_expr [30681,30832]
===
match
---
name: task_id [34023,34030]
name: task_id [33929,33936]
===
match
---
name: patterns [8177,8185]
name: patterns [8177,8185]
===
match
---
string: "#fff" [4860,4866]
string: "#fff" [4860,4866]
===
match
---
operator: } [30162,30163]
operator: } [30068,30069]
===
match
---
name: self [38458,38462]
name: self [38364,38368]
===
match
---
number: 8 [18087,18088]
number: 8 [17993,17994]
===
match
---
name: timezone [18308,18316]
name: timezone [18214,18222]
===
match
---
string: 'airflow' [28038,28047]
string: 'airflow' [27944,27953]
===
match
---
simple_stmt [19084,19127]
simple_stmt [18990,19033]
===
match
---
operator: , [34345,34346]
operator: , [34251,34252]
===
match
---
trailer [18316,18320]
trailer [18222,18226]
===
match
---
number: 7 [16494,16495]
number: 7 [16400,16401]
===
match
---
trailer [29453,29462]
trailer [29359,29368]
===
match
---
operator: , [4560,4561]
operator: , [4560,4561]
===
match
---
number: 600.0 [2354,2359]
number: 600.0 [2354,2359]
===
match
---
atom_expr [44153,44221]
atom_expr [44906,44974]
===
match
---
string: "dag" [23553,23558]
string: "dag" [23459,23464]
===
match
---
atom_expr [7815,7825]
atom_expr [7815,7825]
===
match
---
name: serialized_dag [37563,37577]
name: serialized_dag [37469,37483]
===
match
---
operator: , [32063,32064]
operator: , [31969,31970]
===
match
---
trailer [21407,21419]
trailer [21313,21325]
===
match
---
trailer [15197,15217]
trailer [15103,15123]
===
match
---
name: dag [37229,37232]
name: dag [37135,37138]
===
match
---
operator: ** [33441,33443]
operator: ** [33347,33349]
===
match
---
operator: , [15389,15390]
operator: , [15295,15296]
===
match
---
string: 'outlets' [35030,35039]
string: 'outlets' [34936,34945]
===
match
---
atom [39370,39390]
atom [39276,39296]
===
match
---
name: timezone [16360,16368]
name: timezone [16266,16274]
===
match
---
parameters [25364,25386]
parameters [25270,25292]
===
match
---
arglist [25731,25741]
arglist [25637,25647]
===
match
---
name: has_on_failure_callback [42350,42373]
name: has_on_failure_callback [42256,42279]
===
match
---
trailer [14480,14482]
trailer [14386,14388]
===
match
---
string: "task_id" [4426,4435]
string: "task_id" [4426,4435]
===
match
---
operator: = [17294,17295]
operator: = [17200,17201]
===
match
---
param [43625,43638]
param [44378,44391]
===
match
---
trailer [10824,10837]
trailer [10824,10837]
===
match
---
comparison [33734,33769]
comparison [33640,33675]
===
match
---
string: '"location": "mock", ' [9201,9223]
string: '"location": "mock", ' [9201,9223]
===
match
---
operator: , [34417,34418]
operator: , [34323,34324]
===
match
---
name: task [28130,28134]
name: task [28036,28040]
===
match
---
operator: , [31679,31680]
operator: , [31585,31586]
===
match
---
operator: , [17872,17873]
operator: , [17778,17779]
===
match
---
name: expected_output [43441,43456]
name: expected_output [44194,44209]
===
match
---
operator: , [34167,34168]
operator: , [34073,34074]
===
match
---
atom [20374,20471]
atom [20280,20377]
===
match
---
trailer [28333,28349]
trailer [28239,28255]
===
match
---
name: timedelta [19421,19430]
name: timedelta [19327,19336]
===
match
---
string: "foo" [29873,29878]
string: "foo" [29779,29784]
===
match
---
string: 'env' [3710,3715]
string: 'env' [3710,3715]
===
match
---
operator: = [12164,12165]
operator: = [12164,12165]
===
match
---
name: serialized_simple_dag_ground_truth [10007,10041]
name: serialized_simple_dag_ground_truth [10007,10041]
===
match
---
atom_expr [16140,16181]
atom_expr [16046,16087]
===
match
---
simple_stmt [44606,44650]
simple_stmt [45359,45403]
===
match
---
operator: , [17967,17968]
operator: , [17873,17874]
===
match
---
string: "_is_dummy" [3451,3462]
string: "_is_dummy" [3451,3462]
===
match
---
operator: , [3358,3359]
operator: , [3358,3359]
===
match
---
expr_stmt [44230,44276]
expr_stmt [44983,45029]
===
match
---
trailer [10195,10202]
trailer [10195,10202]
===
match
---
name: expected_task_start_date [17428,17452]
name: expected_task_start_date [17334,17358]
===
match
---
operator: , [29226,29227]
operator: , [29132,29133]
===
match
---
string: '/' [10220,10223]
string: '/' [10220,10223]
===
match
---
string: "{{ task.task_id }}" [29888,29908]
string: "{{ task.task_id }}" [29794,29814]
===
match
---
operator: , [6694,6695]
operator: , [6694,6695]
===
match
---
name: tzinfo [16501,16507]
name: tzinfo [16407,16413]
===
match
---
for_stmt [15255,15450]
for_stmt [15161,15356]
===
match
---
operator: { [15393,15394]
operator: { [15299,15300]
===
match
---
operator: = [42035,42036]
operator: = [41941,41942]
===
match
---
if_stmt [42072,42249]
if_stmt [41978,42155]
===
match
---
string: "task5" [37119,37126]
string: "task5" [37025,37032]
===
match
---
name: serialize_operator [33621,33639]
name: serialize_operator [33527,33545]
===
match
---
name: base [1187,1191]
name: base [1187,1191]
===
match
---
atom_expr [26947,27024]
atom_expr [26853,26930]
===
match
---
trailer [26961,27024]
trailer [26867,26930]
===
match
---
operator: , [29951,29952]
operator: , [29857,29858]
===
match
---
operator: = [27158,27159]
operator: = [27064,27065]
===
match
---
string: "params" [21576,21584]
string: "params" [21482,21490]
===
match
---
trailer [1827,1837]
trailer [1827,1837]
===
match
---
name: extra [9104,9109]
name: extra [9104,9109]
===
match
---
name: kwargs [29138,29144]
name: kwargs [29044,29050]
===
match
---
decorated [39296,40018]
decorated [39202,39924]
===
match
---
name: dag [7792,7795]
name: dag [7792,7795]
===
match
---
number: 8 [32091,32092]
number: 8 [31997,31998]
===
match
---
with_stmt [36680,37187]
with_stmt [36586,37093]
===
match
---
atom [2511,2957]
atom [2511,2957]
===
match
---
simple_stmt [22461,22518]
simple_stmt [22367,22424]
===
match
---
string: "sla" [2378,2383]
string: "sla" [2378,2383]
===
match
---
operator: , [29619,29620]
operator: , [29525,29526]
===
match
---
assert_stmt [33036,33089]
assert_stmt [32942,32995]
===
match
---
comparison [33043,33089]
comparison [32949,32995]
===
match
---
simple_stmt [32702,32780]
simple_stmt [32608,32686]
===
match
---
import_from [1127,1166]
import_from [1127,1166]
===
match
---
argument [26917,26937]
argument [26823,26843]
===
match
---
simple_stmt [1168,1208]
simple_stmt [1168,1208]
===
match
---
operator: , [24421,24422]
operator: , [24327,24328]
===
match
---
name: resources [15612,15621]
name: resources [15518,15527]
===
match
---
name: bash_command [32157,32169]
name: bash_command [32063,32075]
===
match
---
name: DAG [15971,15974]
name: DAG [15877,15880]
===
match
---
operator: , [5201,5202]
operator: , [5201,5202]
===
match
---
atom [20577,20593]
atom [20483,20499]
===
match
---
dictorsetmaker [27754,27764]
dictorsetmaker [27660,27670]
===
match
---
string: 'label' [5179,5186]
string: 'label' [5179,5186]
===
match
---
simple_stmt [44731,44863]
simple_stmt [45484,45616]
===
match
---
decorator [40023,40165]
decorator [39929,40071]
===
match
---
operator: @ [21003,21004]
operator: @ [20909,20910]
===
match
---
suite [33345,33500]
suite [33251,33406]
===
match
---
operator: = [6055,6056]
operator: = [6055,6056]
===
match
---
assert_stmt [16002,16039]
assert_stmt [15908,15945]
===
match
---
atom_expr [42227,42248]
atom_expr [42133,42154]
===
match
---
simple_stmt [32020,32098]
simple_stmt [31926,32004]
===
match
---
atom [29633,29641]
atom [29539,29547]
===
match
---
name: xcom_push [28185,28194]
name: xcom_push [28091,28100]
===
match
---
operator: , [30165,30166]
operator: , [30071,30072]
===
match
---
simple_stmt [20044,20086]
simple_stmt [19950,19992]
===
match
---
simple_stmt [1331,1402]
simple_stmt [1331,1402]
===
match
---
atom_expr [41040,41061]
atom_expr [40946,40967]
===
match
---
dictorsetmaker [30288,30326]
dictorsetmaker [30194,30232]
===
match
---
comparison [37563,37638]
comparison [37469,37544]
===
match
---
simple_stmt [27259,27323]
simple_stmt [27165,27229]
===
match
---
name: BaseOperator [25462,25474]
name: BaseOperator [25368,25380]
===
match
---
simple_stmt [44230,44277]
simple_stmt [44983,45030]
===
match
---
name: datetime [17880,17888]
name: datetime [17786,17794]
===
match
---
trailer [18049,18053]
trailer [17955,17959]
===
match
---
name: airflow [1496,1503]
name: airflow [1496,1503]
===
match
---
name: __init__ [33432,33440]
name: __init__ [33338,33346]
===
match
---
name: MyOperator [25451,25461]
name: MyOperator [25357,25367]
===
match
---
operator: { [5004,5005]
operator: { [5004,5005]
===
match
---
operator: } [5511,5512]
operator: } [5511,5512]
===
match
---
string: "echo {{ task.task_id }}" [3758,3783]
string: "echo {{ task.task_id }}" [3758,3783]
===
match
---
expr_stmt [32248,32306]
expr_stmt [32154,32212]
===
match
---
name: dag [42059,42062]
name: dag [41965,41968]
===
match
---
parameters [38457,38463]
parameters [38363,38369]
===
match
---
operator: { [29993,29994]
operator: { [29899,29900]
===
match
---
operator: , [42790,42791]
operator: , [42696,42697]
===
match
---
atom_expr [5588,5691]
atom_expr [5588,5691]
===
match
---
param [18392,18397]
param [18298,18303]
===
match
---
name: spec [44285,44289]
name: spec [45038,45042]
===
match
---
name: os [5610,5612]
name: os [5610,5612]
===
match
---
number: 1 [16438,16439]
number: 1 [16344,16345]
===
match
---
string: 'params' [35089,35097]
string: 'params' [34995,35003]
===
match
---
atom_expr [19142,19162]
atom_expr [19048,19068]
===
match
---
operator: } [30062,30063]
operator: } [29968,29969]
===
match
---
name: test_task_group_serialization [36397,36426]
name: test_task_group_serialization [36303,36332]
===
match
---
operator: { [42967,42968]
operator: { [43547,43548]
===
match
---
operator: , [19972,19973]
operator: , [19878,19879]
===
match
---
name: expected_field [32390,32404]
name: expected_field [32296,32310]
===
match
---
number: 0 [18937,18938]
number: 0 [18843,18844]
===
match
---
name: locals_ [43625,43632]
name: locals_ [44378,44385]
===
match
---
string: "true" [23733,23739]
string: "true" [23639,23645]
===
match
---
atom_expr [20102,20123]
atom_expr [20008,20029]
===
match
---
atom_expr [41090,41129]
atom_expr [40996,41035]
===
match
---
expr_stmt [28789,28870]
expr_stmt [28695,28776]
===
match
---
trailer [23652,23662]
trailer [23558,23568]
===
match
---
name: dag [26985,26988]
name: dag [26891,26894]
===
match
---
name: BaseOperator [33331,33343]
name: BaseOperator [33237,33249]
===
match
---
simple_stmt [7955,8005]
simple_stmt [7955,8005]
===
match
---
name: expect_custom_deps [39791,39809]
name: expect_custom_deps [39697,39715]
===
match
---
atom_expr [15947,15969]
atom_expr [15853,15875]
===
match
---
operator: , [35501,35502]
operator: , [35407,35408]
===
match
---
atom [44475,44597]
atom [45228,45350]
===
match
---
simple_stmt [41455,41831]
simple_stmt [41361,41737]
===
match
---
name: update [8439,8445]
name: update [8439,8445]
===
match
---
trailer [13644,13647]
trailer [13550,13553]
===
match
---
atom_expr [11040,11071]
atom_expr [11040,11071]
===
match
---
name: serialized_dag [23611,23625]
name: serialized_dag [23517,23531]
===
match
---
dictorsetmaker [3686,3723]
dictorsetmaker [3686,3723]
===
match
---
trailer [14056,14070]
trailer [13962,13976]
===
match
---
trailer [32741,32743]
trailer [32647,32649]
===
match
---
atom_expr [23294,23314]
atom_expr [23200,23220]
===
match
---
funcdef [39591,39645]
funcdef [39497,39551]
===
match
---
simple_stmt [37170,37187]
simple_stmt [37076,37093]
===
match
---
testlist_comp [29656,29662]
testlist_comp [29562,29568]
===
match
---
funcdef [19461,20234]
funcdef [19367,20140]
===
match
---
factor [20304,20306]
factor [20210,20212]
===
match
---
atom [15560,15562]
atom [15466,15468]
===
match
---
name: self [9479,9483]
name: self [9479,9483]
===
match
---
arglist [16737,16783]
arglist [16643,16689]
===
match
---
name: task5 [37089,37094]
name: task5 [36995,37000]
===
match
---
suite [43354,43408]
suite [44107,44161]
===
match
---
name: serialized_op [33652,33665]
name: serialized_op [33558,33571]
===
match
---
atom [5435,5493]
atom [5435,5493]
===
match
---
operator: = [23476,23477]
operator: = [23382,23383]
===
match
---
operator: , [26983,26984]
operator: , [26889,26890]
===
match
---
name: items [29184,29189]
name: items [29090,29095]
===
match
---
operator: , [6245,6246]
operator: , [6245,6246]
===
match
---
atom [14485,14949]
atom [14391,14855]
===
match
---
operator: , [42645,42646]
operator: , [42551,42552]
===
match
---
simple_stmt [967,989]
simple_stmt [967,989]
===
match
---
operator: , [1067,1068]
operator: , [1067,1068]
===
match
---
atom_expr [9849,9874]
atom_expr [9849,9874]
===
match
---
operator: { [2605,2606]
operator: { [2605,2606]
===
match
---
string: 'simple_task' [21364,21377]
string: 'simple_task' [21270,21283]
===
match
---
operator: = [18247,18248]
operator: = [18153,18154]
===
match
---
string: 'task_1' [42751,42759]
string: 'task_1' [42657,42665]
===
match
---
trailer [14077,14085]
trailer [13983,13991]
===
match
---
name: round_tripped [20907,20920]
name: round_tripped [20813,20826]
===
match
---
argument [7788,7795]
argument [7788,7795]
===
match
---
argument [16353,16372]
argument [16259,16278]
===
match
---
string: '.' [43703,43706]
string: '.' [44456,44459]
===
match
---
number: 1 [20395,20396]
number: 1 [20301,20302]
===
match
---
name: self [29538,29542]
name: self [29444,29448]
===
match
---
name: mount_path [1949,1959]
name: mount_path [1949,1959]
===
match
---
param [19577,19605]
param [19483,19511]
===
match
---
dictorsetmaker [32888,32962]
dictorsetmaker [32794,32868]
===
match
---
trailer [38956,38964]
trailer [38862,38870]
===
match
---
name: getattr [15339,15346]
name: getattr [15245,15252]
===
match
---
name: test_dag_on_success_callback_roundtrip [40173,40211]
name: test_dag_on_success_callback_roundtrip [40079,40117]
===
match
---
string: 'BigQuery Console #2' [28003,28024]
string: 'BigQuery Console #2' [27909,27930]
===
match
---
operator: , [15969,15970]
operator: , [15875,15876]
===
match
---
comp_op [42220,42226]
comp_op [42126,42132]
===
match
---
name: SerializedDAG [38943,38956]
name: SerializedDAG [38849,38862]
===
match
---
atom_expr [34205,34210]
atom_expr [34111,34116]
===
match
---
name: BaseOperatorLink [1385,1401]
name: BaseOperatorLink [1385,1401]
===
match
---
name: dag [11764,11767]
name: dag [11764,11767]
===
match
---
simple_stmt [6455,6493]
simple_stmt [6455,6493]
===
match
---
operator: } [30163,30164]
operator: } [30069,30070]
===
match
---
name: default_args [13372,13384]
name: default_args [13278,13290]
===
match
---
name: execution_date [7236,7250]
name: execution_date [7236,7250]
===
match
---
simple_stmt [33550,33582]
simple_stmt [33456,33488]
===
match
---
dictorsetmaker [30026,30063]
dictorsetmaker [29932,29969]
===
match
---
atom_expr [43688,43710]
atom_expr [44441,44463]
===
match
---
operator: , [2672,2673]
operator: , [2672,2673]
===
match
---
name: pattern [8342,8349]
name: pattern [8342,8349]
===
match
---
string: "{{ task.task_id }}" [31039,31059]
string: "{{ task.task_id }}" [30945,30965]
===
match
---
name: dag [32111,32114]
name: dag [32017,32020]
===
match
---
atom_expr [24512,24569]
atom_expr [24418,24475]
===
match
---
operator: , [4164,4165]
operator: , [4164,4165]
===
match
---
operator: , [43021,43022]
operator: , [43601,43602]
===
match
---
operator: } [2283,2284]
operator: } [2283,2284]
===
match
---
name: parameterized [1153,1166]
name: parameterized [1153,1166]
===
match
---
argument [6048,6057]
argument [6048,6057]
===
match
---
simple_stmt [39026,39089]
simple_stmt [38932,38995]
===
match
---
name: SerializedDAG [37463,37476]
name: SerializedDAG [37369,37382]
===
match
---
number: 2019 [18022,18026]
number: 2019 [17928,17932]
===
match
---
operator: , [27851,27852]
operator: , [27757,27758]
===
match
---
parameters [8974,8980]
parameters [8974,8980]
===
match
---
arglist [43301,43321]
arglist [44054,44074]
===
match
---
trailer [20668,20671]
trailer [20574,20577]
===
match
---
operator: , [14411,14412]
operator: , [14317,14318]
===
match
---
trailer [16547,16580]
trailer [16453,16486]
===
match
---
dictorsetmaker [19718,19747]
dictorsetmaker [19624,19653]
===
match
---
suite [36756,37187]
suite [36662,37093]
===
match
---
param [43610,43624]
param [44363,44377]
===
match
---
arith_expr [14454,14949]
arith_expr [14360,14855]
===
match
---
assert_stmt [23513,23571]
assert_stmt [23419,23477]
===
match
---
simple_stmt [10965,10981]
simple_stmt [10965,10981]
===
match
---
operator: } [19399,19400]
operator: } [19305,19306]
===
match
---
name: compute_next_execution_date [7521,7548]
name: compute_next_execution_date [7521,7548]
===
match
---
atom_expr [27266,27302]
atom_expr [27172,27208]
===
match
---
trailer [16250,16254]
trailer [16156,16160]
===
match
---
operator: , [5121,5122]
operator: , [5121,5122]
===
match
---
name: ignored_keys [32867,32879]
name: ignored_keys [32773,32785]
===
match
---
name: self [29217,29221]
name: self [29123,29127]
===
match
---
trailer [20022,20034]
trailer [19928,19940]
===
match
---
atom_expr [26892,26938]
atom_expr [26798,26844]
===
match
---
param [29507,29512]
param [29413,29418]
===
match
---
name: google_link_from_plugin [24863,24886]
name: google_link_from_plugin [24769,24792]
===
match
---
trailer [18920,18927]
trailer [18826,18833]
===
match
---
name: upstream_task_ids [15123,15140]
name: upstream_task_ids [15029,15046]
===
match
---
atom_expr [22546,22585]
atom_expr [22452,22491]
===
match
---
trailer [6469,6492]
trailer [6469,6492]
===
match
---
suite [8421,8476]
suite [8421,8476]
===
match
---
name: TaskInstance [24329,24341]
name: TaskInstance [24235,24247]
===
match
---
name: name [13781,13785]
name: name [13687,13691]
===
match
---
name: utc [17593,17596]
name: utc [17499,17502]
===
match
---
testlist_comp [39341,39391]
testlist_comp [39247,39297]
===
match
---
name: expected_val [21774,21786]
name: expected_val [21680,21692]
===
match
---
atom_expr [16479,16521]
atom_expr [16385,16427]
===
match
---
atom [31145,31156]
atom [31051,31062]
===
match
---
number: 2019 [26866,26870]
number: 2019 [26772,26776]
===
match
---
atom_expr [27222,27250]
atom_expr [27128,27156]
===
match
---
simple_stmt [25764,25791]
simple_stmt [25670,25697]
===
match
---
shift_expr [38860,38897]
shift_expr [38766,38803]
===
match
---
simple_stmt [33836,33986]
simple_stmt [33742,33892]
===
match
---
name: serialized_op [39906,39919]
name: serialized_op [39812,39825]
===
match
---
name: dag [37922,37925]
name: dag [37828,37831]
===
match
---
operator: } [29657,29658]
operator: } [29563,29564]
===
match
---
testlist_comp [42605,42704]
testlist_comp [42511,42610]
===
match
---
operator: , [16580,16581]
operator: , [16486,16487]
===
match
---
string: "test_role" [5354,5365]
string: "test_role" [5354,5365]
===
match
---
if_stmt [18685,19021]
if_stmt [18591,18927]
===
match
---
decorated [29562,32456]
decorated [29468,32362]
===
match
---
arglist [31007,31085]
arglist [30913,30991]
===
match
---
operator: , [4250,4251]
operator: , [4250,4251]
===
match
---
lambdef [40093,40114]
lambdef [39999,40020]
===
match
---
name: dag [20044,20047]
name: dag [19950,19953]
===
match
---
name: SerializedDAG [23478,23491]
name: SerializedDAG [23384,23397]
===
match
---
operator: , [31696,31697]
operator: , [31602,31603]
===
match
---
trailer [43702,43707]
trailer [44455,44460]
===
match
---
operator: , [18589,18590]
operator: , [18495,18496]
===
match
---
number: 1 [16232,16233]
number: 1 [16138,16139]
===
match
---
name: keys [11910,11914]
name: keys [11910,11914]
===
match
---
operator: , [16289,16290]
operator: , [16195,16196]
===
match
---
name: dag [6442,6445]
name: dag [6442,6445]
===
match
---
atom_expr [16119,16131]
atom_expr [16025,16037]
===
match
---
name: task_id [6527,6534]
name: task_id [6527,6534]
===
match
---
name: att1 [30826,30830]
name: att1 [30732,30736]
===
match
---
expr_stmt [36876,36910]
expr_stmt [36782,36816]
===
match
---
operator: , [1296,1297]
operator: , [1296,1297]
===
match
---
assert_stmt [24828,24886]
assert_stmt [24734,24792]
===
match
---
name: serialized_dag [42227,42241]
name: serialized_dag [42133,42147]
===
match
---
name: validate_serialized_dag [9952,9975]
name: validate_serialized_dag [9952,9975]
===
match
---
simple_stmt [6501,6760]
simple_stmt [6501,6760]
===
match
---
atom_expr [13810,13822]
atom_expr [13716,13728]
===
match
---
name: execution_date [36634,36648]
name: execution_date [36540,36554]
===
match
---
name: expected [20889,20897]
name: expected [20795,20803]
===
match
---
name: op [33509,33511]
name: op [33415,33417]
===
match
---
operator: , [4634,4635]
operator: , [4634,4635]
===
match
---
param [26345,26349]
param [26251,26255]
===
match
---
string: "{'nested1': ClassWithCustomAttributes({'att1': '{{ task.task_id }}', " [31238,31309]
string: "{'nested1': ClassWithCustomAttributes({'att1': '{{ task.task_id }}', " [31144,31215]
===
match
---
string: 'index' [27754,27761]
string: 'index' [27660,27667]
===
match
---
arglist [1934,1967]
arglist [1934,1967]
===
match
---
trailer [25862,25873]
trailer [25768,25779]
===
match
---
name: parameterized [19195,19208]
name: parameterized [19101,19114]
===
match
---
operator: , [41428,41429]
operator: , [41334,41335]
===
match
---
argument [18591,18598]
argument [18497,18504]
===
match
---
assert_stmt [15018,15090]
assert_stmt [14924,14996]
===
match
---
name: validate_schema [20007,20022]
name: validate_schema [19913,19928]
===
match
---
operator: , [5463,5464]
operator: , [5463,5464]
===
match
---
name: dag_dict [37196,37204]
name: dag_dict [37102,37110]
===
match
---
name: name [43688,43692]
name: name [44441,44445]
===
match
---
argument [22247,22254]
argument [22153,22160]
===
match
---
operator: { [29880,29881]
operator: { [29786,29787]
===
match
---
atom [20674,20731]
atom [20580,20637]
===
match
---
string: "dag" [19676,19681]
string: "dag" [19582,19587]
===
match
---
suite [33151,33770]
suite [33057,33676]
===
match
---
trailer [20298,20307]
trailer [20204,20213]
===
match
---
name: task_dict [27226,27235]
name: task_dict [27132,27141]
===
match
---
testlist_comp [39371,39389]
testlist_comp [39277,39295]
===
match
---
operator: = [44744,44745]
operator: = [45497,45498]
===
match
---
operator: , [5537,5538]
operator: , [5537,5538]
===
match
---
trailer [21806,21813]
trailer [21712,21719]
===
match
---
param [33145,33149]
param [33051,33055]
===
match
---
trailer [30400,30518]
trailer [30306,30424]
===
match
---
name: self [33371,33375]
name: self [33277,33281]
===
match
---
name: dag [23426,23429]
name: dag [23332,23335]
===
match
---
atom_expr [4203,4250]
atom_expr [4203,4250]
===
match
---
trailer [32415,32455]
trailer [32321,32361]
===
match
---
operator: , [19400,19401]
operator: , [19306,19307]
===
match
---
operator: , [42703,42704]
operator: , [42609,42610]
===
match
---
name: tzinfo [18093,18099]
name: tzinfo [17999,18005]
===
match
---
comp_op [18899,18905]
comp_op [18805,18811]
===
match
---
number: 10 [6109,6111]
number: 10 [6109,6111]
===
match
---
atom_expr [15144,15166]
atom_expr [15050,15072]
===
match
---
name: dag [8843,8846]
name: dag [8843,8846]
===
match
---
name: dag [18595,18598]
name: dag [18501,18504]
===
match
---
operator: , [18029,18030]
operator: , [17935,17936]
===
match
---
parameters [22781,22787]
parameters [22687,22693]
===
match
---
simple_stmt [17290,17336]
simple_stmt [17196,17242]
===
match
---
testlist_comp [20724,20728]
testlist_comp [20630,20634]
===
match
---
atom [2140,2439]
atom [2140,2439]
===
match
---
tfpdef [10337,10351]
tfpdef [10337,10351]
===
match
---
expr_stmt [23581,23626]
expr_stmt [23487,23532]
===
match
---
string: "param_1" [21098,21107]
string: "param_1" [21004,21013]
===
match
---
name: expected_value [40888,40902]
name: expected_value [40794,40808]
===
match
---
string: "UTC" [19885,19890]
string: "UTC" [19791,19796]
===
match
---
atom_expr [32340,32374]
atom_expr [32246,32280]
===
match
---
name: dag [37491,37494]
name: dag [37397,37400]
===
match
---
dictorsetmaker [2386,2423]
dictorsetmaker [2386,2423]
===
match
---
name: task [14454,14458]
name: task [14360,14364]
===
match
---
expr_stmt [33994,34036]
expr_stmt [33900,33942]
===
match
---
return_stmt [6768,6794]
return_stmt [6768,6794]
===
match
---
string: "dag" [18921,18926]
string: "dag" [18827,18832]
===
match
---
trailer [44512,44515]
trailer [45265,45268]
===
match
---
string: 'queue' [35214,35221]
string: 'queue' [35120,35127]
===
match
---
string: "tasks" [23560,23567]
string: "tasks" [23466,23473]
===
match
---
operator: } [30122,30123]
operator: } [30028,30029]
===
match
---
operator: , [12244,12245]
operator: , [12244,12245]
===
match
---
simple_stmt [22594,22663]
simple_stmt [22500,22569]
===
match
---
with_stmt [32106,32187]
with_stmt [32012,32093]
===
match
---
trailer [43398,43407]
trailer [44151,44160]
===
match
---
name: dag_end_date [18709,18721]
name: dag_end_date [18615,18627]
===
match
---
name: SerializedDAG [12424,12437]
name: SerializedDAG [12424,12437]
===
match
---
atom_expr [24803,24818]
atom_expr [24709,24724]
===
match
---
operator: , [19789,19790]
operator: , [19695,19696]
===
match
---
operator: , [3501,3502]
operator: , [3501,3502]
===
match
---
operator: , [16233,16234]
operator: , [16139,16140]
===
match
---
argument [40791,40822]
argument [40697,40728]
===
match
---
testlist_comp [41256,41308]
testlist_comp [41162,41214]
===
match
---
string: """A serialized DAG can be deserialized in another process.""" [11132,11194]
string: """A serialized DAG can be deserialized in another process.""" [11132,11194]
===
match
---
comparison [22678,22725]
comparison [22584,22631]
===
match
---
number: 2019 [23303,23307]
number: 2019 [23209,23213]
===
match
---
name: self [39438,39442]
name: self [39344,39348]
===
match
---
name: V1Pod [1761,1766]
name: V1Pod [1761,1766]
===
match
---
operator: { [8395,8396]
operator: { [8395,8396]
===
match
---
fstring_string: . [15410,15411]
fstring_string: . [15316,15317]
===
match
---
operator: = [16566,16567]
operator: = [16472,16473]
===
match
---
trailer [18671,18676]
trailer [18577,18582]
===
match
---
name: airflow [39484,39491]
name: airflow [39390,39397]
===
match
---
trailer [27640,27649]
trailer [27546,27555]
===
match
---
trailer [23332,23375]
trailer [23238,23281]
===
match
---
string: "sla" [6164,6169]
string: "sla" [6164,6169]
===
match
---
atom_expr [14042,14070]
atom_expr [13948,13976]
===
match
---
operator: , [19281,19282]
operator: , [19187,19188]
===
match
---
simple_stmt [33467,33500]
simple_stmt [33373,33406]
===
match
---
name: dag_end_date [18398,18410]
name: dag_end_date [18304,18316]
===
match
---
operator: , [2212,2213]
operator: , [2212,2213]
===
match
---
operator: , [17569,17570]
operator: , [17475,17476]
===
match
---
name: dag [16914,16917]
name: dag [16820,16823]
===
match
---
param [43639,43651]
param [44392,44404]
===
match
---
arglist [28843,28869]
arglist [28749,28775]
===
match
---
testlist_comp [42460,42559]
testlist_comp [42366,42465]
===
match
---
simple_stmt [22797,23274]
simple_stmt [22703,23180]
===
match
---
trailer [25983,25999]
trailer [25889,25905]
===
match
---
operator: , [18410,18411]
operator: , [18316,18317]
===
match
---
name: task [15412,15416]
name: task [15318,15322]
===
match
---
param [22063,22075]
param [21969,21981]
===
match
---
name: task_group [37578,37588]
name: task_group [37484,37494]
===
match
---
operator: = [25721,25722]
operator: = [25627,25628]
===
match
---
arglist [21408,21418]
arglist [21314,21324]
===
match
---
trailer [11929,11934]
trailer [11929,11934]
===
match
---
atom_expr [21343,21420]
atom_expr [21249,21326]
===
match
---
string: "dummy_value_2" [28229,28244]
string: "dummy_value_2" [28135,28150]
===
match
---
operator: } [29949,29950]
operator: } [29855,29856]
===
match
---
dictorsetmaker [5997,6194]
dictorsetmaker [5997,6194]
===
match
---
name: task_type [14982,14991]
name: task_type [14888,14897]
===
match
---
name: datetime [16091,16099]
name: datetime [15997,16005]
===
match
---
trailer [26045,26048]
trailer [25951,25954]
===
match
---
trailer [15946,15975]
trailer [15852,15881]
===
match
---
operator: , [35329,35330]
operator: , [35235,35236]
===
match
---
atom_expr [37301,37352]
atom_expr [37207,37258]
===
match
---
funcdef [11077,12098]
funcdef [11077,12098]
===
match
---
dotted_name [1173,1191]
dotted_name [1173,1191]
===
match
---
import_from [1266,1330]
import_from [1266,1330]
===
match
---
string: "__var" [19736,19743]
string: "__var" [19642,19649]
===
match
---
suite [13823,13925]
suite [13729,13831]
===
match
---
operator: = [43856,43857]
operator: = [44609,44610]
===
match
---
operator: , [5313,5314]
operator: , [5313,5314]
===
match
---
name: serialized_dag [27111,27125]
name: serialized_dag [27017,27031]
===
match
---
name: expected_n_schedule_interval [19577,19605]
name: expected_n_schedule_interval [19483,19511]
===
match
---
atom_expr [33734,33760]
atom_expr [33640,33666]
===
match
---
argument [30880,30904]
argument [30786,30810]
===
match
---
atom_expr [17584,17596]
atom_expr [17490,17502]
===
match
---
atom [30134,30163]
atom [30040,30069]
===
match
---
name: ti [28182,28184]
name: ti [28088,28090]
===
match
---
operator: , [3638,3639]
operator: , [3638,3639]
===
match
---
comparison [27266,27322]
comparison [27172,27228]
===
match
---
atom [4941,4957]
atom [4941,4957]
===
match
---
operator: = [39712,39713]
operator: = [39618,39619]
===
match
---
name: mock__import__ [43954,43968]
name: mock__import__ [44707,44721]
===
match
---
name: dag_folder [8098,8108]
name: dag_folder [8098,8108]
===
match
---
atom [34235,34237]
atom [34141,34143]
===
match
---
operator: , [32899,32900]
operator: , [32805,32806]
===
match
---
trailer [44942,44952]
trailer [45695,45705]
===
match
---
operator: = [20303,20304]
operator: = [20209,20210]
===
match
---
name: is_subdag [8620,8629]
name: is_subdag [8620,8629]
===
match
---
name: task_group [36597,36607]
name: task_group [36503,36513]
===
match
---
operator: , [21412,21413]
operator: , [21318,21319]
===
match
---
simple_stmt [42020,42064]
simple_stmt [41926,41970]
===
match
---
trailer [5630,5638]
trailer [5630,5638]
===
match
---
name: tzinfo [16353,16359]
name: tzinfo [16259,16265]
===
match
---
expr_stmt [22527,22585]
expr_stmt [22433,22491]
===
match
---
param [16692,16716]
param [16598,16622]
===
match
---
trailer [10815,10824]
trailer [10815,10824]
===
match
---
arglist [1888,1969]
arglist [1888,1969]
===
match
---
name: att4 [31034,31038]
name: att4 [30940,30944]
===
match
---
param [29355,29359]
param [29261,29265]
===
match
---
atom_expr [13868,13900]
atom_expr [13774,13806]
===
match
---
name: self [17500,17504]
name: self [17406,17410]
===
match
---
trailer [22559,22569]
trailer [22465,22475]
===
match
---
string: "#f0ede4" [3531,3540]
string: "#f0ede4" [3531,3540]
===
match
---
dotted_name [1654,1685]
dotted_name [1654,1685]
===
match
---
name: SerializedBaseOperator [39922,39944]
name: SerializedBaseOperator [39828,39850]
===
match
---
comparison [43423,43456]
comparison [44176,44209]
===
match
---
atom_expr [17402,17424]
atom_expr [17308,17330]
===
match
---
name: self [37361,37365]
name: self [37267,37271]
===
match
---
trailer [33046,33075]
trailer [32952,32981]
===
match
---
trailer [41103,41113]
trailer [41009,41019]
===
match
---
trailer [5646,5655]
trailer [5646,5655]
===
match
---
trailer [11405,11407]
trailer [11405,11407]
===
match
---
trailer [13905,13914]
trailer [13811,13820]
===
match
---
name: DummySensor [39546,39557]
name: DummySensor [39452,39463]
===
match
---
operator: { [20577,20578]
operator: { [20483,20484]
===
match
---
simple_stmt [9759,9790]
simple_stmt [9759,9790]
===
match
---
name: datetime [16539,16547]
name: datetime [16445,16453]
===
match
---
suite [39858,39897]
suite [39764,39803]
===
match
---
argument [6641,6694]
argument [6641,6694]
===
match
---
operator: } [20358,20359]
operator: } [20264,20265]
===
match
---
trailer [20105,20123]
trailer [20011,20029]
===
match
---
arglist [38673,38736]
arglist [38579,38642]
===
match
---
name: SerializedDAG [32267,32280]
name: SerializedDAG [32173,32186]
===
match
---
string: "__version" [19648,19659]
string: "__version" [19554,19565]
===
match
---
operator: } [21935,21936]
operator: } [21841,21842]
===
match
---
name: sorted [10751,10757]
name: sorted [10751,10757]
===
match
---
string: 'doc_yaml' [34543,34553]
string: 'doc_yaml' [34449,34459]
===
match
---
trailer [25606,25608]
trailer [25512,25514]
===
match
---
trailer [37538,37547]
trailer [37444,37453]
===
match
---
decorated [20239,20998]
decorated [20145,20904]
===
match
---
trailer [10685,10692]
trailer [10685,10692]
===
match
---
assert_stmt [21502,21542]
assert_stmt [21408,21448]
===
match
---
string: "template_fields_renderers" [4975,5002]
string: "template_fields_renderers" [4975,5002]
===
match
---
simple_stmt [17344,17387]
simple_stmt [17250,17293]
===
match
---
operator: , [26915,26916]
operator: , [26821,26822]
===
match
---
name: DummyOperator [36556,36569]
name: DummyOperator [36462,36475]
===
match
---
simple_stmt [17753,17780]
simple_stmt [17659,17686]
===
match
---
assert_stmt [14262,14320]
assert_stmt [14168,14226]
===
match
---
atom_expr [27619,27677]
atom_expr [27525,27583]
===
match
---
not_test [8612,8629]
not_test [8612,8629]
===
match
---
suite [10110,11072]
suite [10110,11072]
===
match
---
name: template_fields [31061,31076]
name: template_fields [30967,30982]
===
match
---
string: 'default_pool' [35123,35137]
string: 'default_pool' [35029,35043]
===
match
---
operator: @ [21882,21883]
operator: @ [21788,21789]
===
match
---
name: task_id [33525,33532]
name: task_id [33431,33438]
===
match
---
number: 8 [18028,18029]
number: 8 [17934,17935]
===
match
---
number: 600.0 [4555,4560]
number: 600.0 [4555,4560]
===
match
---
name: start_date [6214,6224]
name: start_date [6214,6224]
===
match
---
trailer [16340,16373]
trailer [16246,16279]
===
match
---
dictorsetmaker [24113,24163]
dictorsetmaker [24019,24069]
===
match
---
name: task_id [39671,39678]
name: task_id [39577,39584]
===
match
---
operator: = [1823,1824]
operator: = [1823,1824]
===
match
---
name: relativedelta [1069,1082]
name: relativedelta [1069,1082]
===
match
---
argument [40711,40736]
argument [40617,40642]
===
match
---
expr_stmt [41071,41129]
expr_stmt [40977,41035]
===
match
---
name: task_dict [32357,32366]
name: task_dict [32263,32272]
===
match
---
atom [35099,35101]
atom [35005,35007]
===
match
---
atom_expr [37207,37233]
atom_expr [37113,37139]
===
match
---
operator: , [16351,16352]
operator: , [16257,16258]
===
match
---
operator: = [9763,9764]
operator: = [9763,9764]
===
match
---
string: '10' [34813,34817]
string: '10' [34719,34723]
===
match
---
name: execution_date [24360,24374]
name: execution_date [24266,24280]
===
match
---
name: blob [39892,39896]
name: blob [39798,39802]
===
match
---
name: expected_err_msg [26246,26262]
name: expected_err_msg [26152,26168]
===
match
---
name: field [15370,15375]
name: field [15276,15281]
===
match
---
operator: , [16182,16183]
operator: , [16088,16089]
===
match
---
operator: , [16345,16346]
operator: , [16251,16252]
===
match
---
for_stmt [13795,13925]
for_stmt [13701,13831]
===
match
---
atom_expr [5610,5689]
atom_expr [5610,5689]
===
match
---
operator: , [26873,26874]
operator: , [26779,26780]
===
match
---
operator: , [21386,21387]
operator: , [21292,21293]
===
match
---
operator: { [2061,2062]
operator: { [2061,2062]
===
match
---
string: """Just a DummyOperator using above defined Extra Operator Link""" [25489,25555]
string: """Just a DummyOperator using above defined Extra Operator Link""" [25395,25461]
===
match
---
operator: = [36649,36650]
operator: = [36555,36556]
===
match
---
operator: , [13252,13253]
operator: , [13118,13119]
===
match
---
trailer [22718,22725]
trailer [22624,22631]
===
match
---
name: make_simple_dag [5837,5852]
name: make_simple_dag [5837,5852]
===
match
---
name: dags [7920,7924]
name: dags [7920,7924]
===
match
---
expr_stmt [20044,20085]
expr_stmt [19950,19991]
===
match
---
operator: , [3328,3329]
operator: , [3328,3329]
===
match
---
suite [13425,13537]
suite [13331,13443]
===
match
---
trailer [6364,6380]
trailer [6364,6380]
===
match
---
arglist [16282,16313]
arglist [16188,16219]
===
match
---
argument [17852,17871]
argument [17758,17777]
===
match
---
assert_stmt [11746,11773]
assert_stmt [11746,11773]
===
match
---
string: "end_date" [18973,18983]
string: "end_date" [18879,18889]
===
match
---
atom [29736,29780]
atom [29642,29686]
===
match
---
dictorsetmaker [14532,14939]
dictorsetmaker [14438,14845]
===
match
---
atom_expr [25764,25790]
atom_expr [25670,25696]
===
match
---
name: expected_value [42377,42391]
name: expected_value [42283,42297]
===
match
---
string: 'index' [27839,27846]
string: 'index' [27745,27752]
===
match
---
expr_stmt [32702,32779]
expr_stmt [32608,32685]
===
match
---
string: "{{ task.task_id }}" [30042,30062]
string: "{{ task.task_id }}" [29948,29968]
===
match
---
name: from_dict [25974,25983]
name: from_dict [25880,25889]
===
match
---
expr_stmt [40652,40737]
expr_stmt [40558,40643]
===
match
---
atom [20408,20470]
atom [20314,20376]
===
match
---
argument [18181,18200]
argument [18087,18106]
===
match
---
operator: = [38715,38716]
operator: = [38621,38622]
===
match
---
name: subdag [15963,15969]
name: subdag [15869,15875]
===
match
---
operator: , [29910,29911]
operator: , [29816,29817]
===
match
---
operator: = [30426,30427]
operator: = [30332,30333]
===
match
---
operator: , [16521,16522]
operator: , [16427,16428]
===
match
---
simple_stmt [5574,5692]
simple_stmt [5574,5692]
===
match
---
operator: , [16827,16828]
operator: , [16733,16734]
===
match
---
trailer [24237,24262]
trailer [24143,24168]
===
match
---
name: val [21178,21181]
name: val [21084,21087]
===
match
---
trailer [8760,8772]
trailer [8760,8772]
===
match
---
atom_expr [37935,37947]
atom_expr [37841,37853]
===
match
---
simple_stmt [11746,11774]
simple_stmt [11746,11774]
===
match
---
name: datetime [17954,17962]
name: datetime [17860,17868]
===
match
---
operator: { [29310,29311]
operator: { [29216,29217]
===
match
---
operator: = [2026,2027]
operator: = [2026,2027]
===
match
---
name: datetime [18072,18080]
name: datetime [17978,17986]
===
match
---
operator: , [3032,3033]
operator: , [3032,3033]
===
match
---
atom [2245,2284]
atom [2245,2284]
===
match
---
string: 'search_query' [28195,28209]
string: 'search_query' [28101,28115]
===
match
---
name: directory [8375,8384]
name: directory [8375,8384]
===
match
---
string: "relativedelta" [20685,20700]
string: "relativedelta" [20591,20606]
===
match
---
string: "_inlets" [3420,3429]
string: "_inlets" [3420,3429]
===
match
---
string: '_log' [34251,34257]
string: '_log' [34157,34163]
===
match
---
name: TestCase [8906,8914]
name: TestCase [8906,8914]
===
match
---
operator: >> [37178,37180]
operator: >> [37084,37086]
===
match
---
operator: = [36878,36879]
operator: = [36784,36785]
===
match
---
atom [29607,29619]
atom [29513,29525]
===
match
---
operator: } [6693,6694]
operator: } [6693,6694]
===
match
---
param [7231,7235]
param [7231,7235]
===
match
---
string: "### DAG Tutorial Documentation" [6399,6431]
string: "### DAG Tutorial Documentation" [6399,6431]
===
match
---
trailer [7290,7306]
trailer [7290,7306]
===
match
---
string: "{{ task.task_id }}" [30858,30878]
string: "{{ task.task_id }}" [30764,30784]
===
match
---
operator: , [16110,16111]
operator: , [16016,16017]
===
match
---
atom_expr [28854,28869]
atom_expr [28760,28775]
===
match
---
number: 1 [20467,20468]
number: 1 [20373,20374]
===
match
---
expr_stmt [18460,18546]
expr_stmt [18366,18452]
===
match
---
number: 1 [16158,16159]
number: 1 [16064,16065]
===
match
---
simple_stmt [38376,38420]
simple_stmt [38282,38326]
===
match
---
if_stmt [13323,13720]
if_stmt [13229,13626]
===
match
---
string: 'doc' [34431,34436]
string: 'doc' [34337,34342]
===
match
---
simple_stmt [22086,22164]
simple_stmt [21992,22070]
===
match
---
string: 'sla' [35430,35435]
string: 'sla' [35336,35341]
===
match
---
suite [29192,29235]
suite [29098,29141]
===
match
---
operator: = [34052,34053]
operator: = [33958,33959]
===
match
---
expr_stmt [37089,37127]
expr_stmt [36995,37033]
===
match
---
name: children [37589,37597]
name: children [37495,37503]
===
match
---
and_test [43290,43353]
and_test [44043,44106]
===
match
---
operator: , [42827,42828]
operator: , [42733,42734]
===
match
---
atom_expr [37045,37075]
atom_expr [36951,36981]
===
match
---
name: task [15827,15831]
name: task [15733,15737]
===
match
---
name: task_id [16806,16813]
name: task_id [16712,16719]
===
match
---
return_stmt [29275,29332]
return_stmt [29181,29238]
===
match
---
atom_expr [24394,24439]
atom_expr [24300,24345]
===
match
---
name: ACTION_CAN_READ [5448,5463]
name: ACTION_CAN_READ [5448,5463]
===
match
---
trailer [22415,22422]
trailer [22321,22328]
===
match
---
comparison [33557,33581]
comparison [33463,33487]
===
match
---
string: "has_on_success_callback" [41007,41032]
string: "has_on_success_callback" [40913,40938]
===
match
---
operator: , [3630,3631]
operator: , [3630,3631]
===
match
---
simple_stmt [45021,45083]
simple_stmt [45774,45836]
===
match
---
atom_expr [38393,38418]
atom_expr [38299,38324]
===
match
---
operator: , [3965,3966]
operator: , [3965,3966]
===
match
---
name: edge_info [39264,39273]
name: edge_info [39170,39179]
===
match
---
operator: } [41301,41302]
operator: } [41207,41208]
===
match
---
name: task_id [36791,36798]
name: task_id [36697,36704]
===
match
---
name: log [34273,34276]
name: log [34179,34182]
===
match
---
name: expected_output [43125,43140]
name: expected_output [43860,43875]
===
match
---
string: "_task_type" [5024,5036]
string: "_task_type" [5024,5036]
===
match
---
atom_expr [20285,20307]
atom_expr [20191,20213]
===
match
---
argument [37059,37074]
argument [36965,36980]
===
match
---
name: default_args [13632,13644]
name: default_args [13538,13550]
===
match
---
trailer [10719,10726]
trailer [10719,10726]
===
match
---
trailer [1933,1968]
trailer [1933,1968]
===
match
---
trailer [41945,42010]
trailer [41851,41916]
===
match
---
arglist [39128,39141]
arglist [39034,39047]
===
match
---
operator: } [7830,7831]
operator: } [7830,7831]
===
match
---
name: parameterized [20240,20253]
name: parameterized [20146,20159]
===
match
---
name: dag [20102,20105]
name: dag [20008,20011]
===
match
---
name: output [26039,26045]
name: output [25945,25951]
===
match
---
name: utc [18109,18112]
name: utc [18015,18018]
===
match
---
funcdef [38425,39291]
funcdef [38331,39197]
===
match
---
suite [39470,40018]
suite [39376,39924]
===
match
---
atom [3400,3402]
atom [3400,3402]
===
match
---
number: 2019 [18169,18173]
number: 2019 [18075,18079]
===
match
---
atom_expr [22327,22353]
atom_expr [22233,22259]
===
match
---
operator: , [36667,36668]
operator: , [36573,36574]
===
match
---
string: '10' [35564,35568]
string: '10' [35470,35474]
===
match
---
dictorsetmaker [2606,2688]
dictorsetmaker [2606,2688]
===
match
---
trailer [18256,18260]
trailer [18162,18166]
===
match
---
atom_expr [29315,29328]
atom_expr [29221,29234]
===
match
---
argument [18093,18112]
argument [17999,18018]
===
match
---
string: "poke" [39342,39348]
string: "poke" [39248,39254]
===
match
---
operator: { [5367,5368]
operator: { [5367,5368]
===
match
---
operator: = [41988,41989]
operator: = [41894,41895]
===
match
---
operator: , [29420,29421]
operator: , [29326,29327]
===
match
---
operator: , [9726,9727]
operator: , [9726,9727]
===
match
---
atom_expr [24036,24094]
atom_expr [23942,24000]
===
match
---
atom [1915,1969]
atom [1915,1969]
===
match
---
operator: = [36775,36776]
operator: = [36681,36682]
===
match
---
name: json_dag [37290,37298]
name: json_dag [37196,37204]
===
match
---
name: serialized_dag [17247,17261]
name: serialized_dag [17153,17167]
===
match
---
operator: } [42644,42645]
operator: } [42550,42551]
===
match
---
name: _serialize [20844,20854]
name: _serialize [20750,20760]
===
match
---
string: 'simple_task' [26970,26983]
string: 'simple_task' [26876,26889]
===
match
---
name: op [39988,39990]
name: op [39894,39896]
===
match
---
atom_expr [36777,36807]
atom_expr [36683,36713]
===
match
---
simple_stmt [22382,22435]
simple_stmt [22288,22341]
===
match
---
funcdef [29244,29333]
funcdef [29150,29239]
===
match
---
atom_expr [35318,35335]
atom_expr [35224,35241]
===
match
---
assert_stmt [10990,11071]
assert_stmt [10990,11071]
===
match
---
operator: , [42672,42673]
operator: , [42578,42579]
===
match
---
name: queue [8674,8679]
name: queue [8674,8679]
===
match
---
string: "test" [32149,32155]
string: "test" [32055,32061]
===
match
---
trailer [33009,33011]
trailer [32915,32917]
===
match
---
name: blob [33591,33595]
name: blob [33497,33501]
===
match
---
string: 'custom_task' [5188,5201]
string: 'custom_task' [5188,5201]
===
match
---
name: __file__ [5656,5664]
name: __file__ [5656,5664]
===
match
---
operator: } [28101,28102]
operator: } [28007,28008]
===
match
---
simple_stmt [19993,20035]
simple_stmt [19899,19941]
===
match
---
trailer [11892,11917]
trailer [11892,11917]
===
match
---
trailer [9681,9683]
trailer [9681,9683]
===
match
---
param [12144,12148]
param [12144,12148]
===
match
---
number: 100.0 [2418,2423]
number: 100.0 [2418,2423]
===
match
---
param [43097,43102]
param [43832,43837]
===
match
---
name: dag [40652,40655]
name: dag [40558,40561]
===
match
---
operator: , [27766,27767]
operator: , [27672,27673]
===
match
---
atom [19359,19400]
atom [19265,19306]
===
match
---
operator: , [35166,35167]
operator: , [35072,35073]
===
match
---
name: dag [13109,13112]
name: dag [13155,13158]
===
match
---
trailer [27141,27144]
trailer [27047,27050]
===
match
---
simple_stmt [22310,22354]
simple_stmt [22216,22260]
===
match
---
simple_stmt [27208,27251]
simple_stmt [27114,27157]
===
match
---
expr_stmt [33467,33499]
expr_stmt [33373,33405]
===
match
---
trailer [1760,1766]
trailer [1760,1766]
===
match
---
param [7607,7611]
param [7607,7611]
===
match
---
operator: == [15557,15559]
operator: == [15463,15465]
===
match
---
comp_op [44626,44632]
comp_op [45379,45385]
===
match
---
string: 'prefix_group_id' [2556,2573]
string: 'prefix_group_id' [2556,2573]
===
match
---
name: SerializedDAG [21447,21460]
name: SerializedDAG [21353,21366]
===
match
---
string: "dict" [19728,19734]
string: "dict" [19634,19640]
===
match
---
trailer [37255,37271]
trailer [37161,37177]
===
match
---
name: start_date [16838,16848]
name: start_date [16744,16754]
===
match
---
string: 'simple_dag' [9992,10004]
string: 'simple_dag' [9992,10004]
===
match
---
trailer [7947,7949]
trailer [7947,7949]
===
match
---
simple_stmt [1491,1558]
simple_stmt [1491,1558]
===
match
---
comparison [42110,42160]
comparison [42016,42066]
===
match
---
simple_stmt [39479,39531]
simple_stmt [39385,39437]
===
match
---
operator: , [16495,16496]
operator: , [16401,16402]
===
match
---
with_stmt [36820,37076]
with_stmt [36726,36982]
===
match
---
operator: = [33532,33533]
operator: = [33438,33439]
===
match
---
name: to_json [8835,8842]
name: to_json [8835,8842]
===
match
---
comparison [15107,15166]
comparison [15013,15072]
===
match
---
atom_expr [19036,19075]
atom_expr [18942,18981]
===
match
---
operator: , [42949,42950]
operator: , [43529,43530]
===
match
---
operator: = [18594,18595]
operator: = [18500,18501]
===
match
---
trailer [21460,21468]
trailer [21366,21374]
===
match
---
trailer [28842,28870]
trailer [28748,28776]
===
match
---
simple_stmt [9802,9837]
simple_stmt [9802,9837]
===
match
---
string: "airflow.serialization.serialized_objects" [25874,25916]
string: "airflow.serialization.serialized_objects" [25780,25822]
===
match
---
operator: , [2486,2487]
operator: , [2486,2487]
===
match
---
simple_stmt [18460,18547]
simple_stmt [18366,18453]
===
match
---
parameters [24963,24969]
parameters [24869,24875]
===
match
---
operator: , [24303,24304]
operator: , [24209,24210]
===
match
---
trailer [37733,37740]
trailer [37639,37646]
===
match
---
parameters [31674,31713]
parameters [31580,31619]
===
match
---
operator: , [3708,3709]
operator: , [3708,3709]
===
match
---
atom_expr [29538,29556]
atom_expr [29444,29462]
===
match
---
atom [4632,4634]
atom [4632,4634]
===
match
---
trailer [32356,32366]
trailer [32262,32272]
===
match
---
name: blob [39966,39970]
name: blob [39872,39876]
===
match
---
operator: , [22292,22293]
operator: , [22198,22199]
===
match
---
argument [40662,40709]
argument [40568,40615]
===
match
---
operator: , [40818,40819]
operator: , [40724,40725]
===
match
---
trailer [43300,43322]
trailer [44053,44075]
===
match
---
comparison [18888,18939]
comparison [18794,18845]
===
match
---
string: 'downstream_task_ids' [2921,2942]
string: 'downstream_task_ids' [2921,2942]
===
match
---
with_stmt [44872,44967]
with_stmt [45625,45720]
===
match
---
trailer [10888,10907]
trailer [10888,10907]
===
match
---
expr_stmt [28535,28618]
expr_stmt [28441,28524]
===
match
---
name: proc [11416,11420]
name: proc [11416,11420]
===
match
---
operator: = [6656,6657]
operator: = [6656,6657]
===
match
---
atom_expr [13836,13924]
atom_expr [13742,13830]
===
match
---
dotted_name [42398,42418]
dotted_name [42304,42324]
===
match
---
string: "has_on_failure_callback" [32937,32962]
string: "has_on_failure_callback" [32843,32868]
===
match
---
name: self [25635,25639]
name: self [25541,25545]
===
match
---
name: SerializedDAG [37325,37338]
name: SerializedDAG [37231,37244]
===
match
---
name: dag [14074,14077]
name: dag [13980,13983]
===
match
---
name: executor_config_pod [44831,44850]
name: executor_config_pod [45584,45603]
===
match
---
name: params [21870,21876]
name: params [21776,21782]
===
match
---
testlist_comp [21073,21119]
testlist_comp [20979,21025]
===
match
---
operator: } [43020,43021]
operator: } [43600,43601]
===
match
---
string: 'task_2' [42626,42634]
string: 'task_2' [42532,42540]
===
match
---
name: SerializedBaseOperator [37880,37902]
name: SerializedBaseOperator [37786,37808]
===
match
---
testlist_comp [27695,27852]
testlist_comp [27601,27758]
===
match
---
name: self [39600,39604]
name: self [39506,39510]
===
match
---
simple_stmt [42258,42317]
simple_stmt [42164,42223]
===
match
---
dictorsetmaker [34106,35695]
dictorsetmaker [34012,35601]
===
match
---
name: dag_start_date [16953,16967]
name: dag_start_date [16859,16873]
===
match
---
trailer [8997,9003]
trailer [8997,9003]
===
match
---
trailer [6233,6245]
trailer [6233,6245]
===
match
---
simple_stmt [8087,8109]
simple_stmt [8087,8109]
===
match
---
operator: , [33375,33376]
operator: , [33281,33282]
===
match
---
operator: = [19435,19436]
operator: = [19341,19342]
===
match
---
operator: = [16118,16119]
operator: = [16024,16025]
===
match
---
string: "executor_config" [3983,4000]
string: "executor_config" [3983,4000]
===
match
---
expr_stmt [39654,39716]
expr_stmt [39560,39622]
===
match
---
simple_stmt [37709,37743]
simple_stmt [37615,37649]
===
match
---
trailer [29299,29308]
trailer [29205,29214]
===
match
---
name: simple_task [27274,27285]
name: simple_task [27180,27191]
===
match
---
name: util [44163,44167]
name: util [44916,44920]
===
match
---
name: serialized_dag [13509,13523]
name: serialized_dag [13415,13429]
===
match
---
argument [1888,1899]
argument [1888,1899]
===
insert-tree
---
simple_stmt [788,827]
    string: """Unit tests for stringified DAGs.""" [788,826]
to
file_input [788,45083]
at 0
===
insert-node
---
name: TestStringifiedDAGs [8877,8896]
to
classdef [8871,43457]
at 0
===
insert-tree
---
simple_stmt [8921,8960]
    string: """Unit tests for stringified DAGs.""" [8921,8959]
to
suite [8916,43457]
at 0
===
insert-tree
---
atom [42783,43443]
    testlist_comp [42801,43429]
        atom [42801,43035]
            operator: { [42801,42802]
            dictorsetmaker [42823,43017]
                string: "staging_schema" [42823,42839]
                atom [42841,43017]
                    testlist_comp [42867,42995]
                        atom [42867,42898]
                            operator: { [42867,42868]
                            dictorsetmaker [42868,42897]
                                string: "key:" [42868,42874]
                                string: "foo" [42876,42881]
                                operator: , [42881,42882]
                                string: "value" [42883,42890]
                                string: "bar" [42892,42897]
                            operator: } [42897,42898]
                        operator: , [42898,42899]
                        atom [42924,42957]
                            operator: { [42924,42925]
                            dictorsetmaker [42925,42956]
                                string: "key:" [42925,42931]
                                string: "this" [42933,42939]
                                operator: , [42939,42940]
                                string: "value" [42941,42948]
                                string: "that" [42950,42956]
                            operator: } [42956,42957]
                        operator: , [42957,42958]
                        string: "test_conf" [42983,42994]
                        operator: , [42994,42995]
            operator: } [43034,43035]
        operator: , [43035,43036]
        atom [43053,43428]
            operator: { [43053,43054]
            dictorsetmaker [43075,43410]
                string: "staging_schema" [43075,43091]
                atom [43093,43410]
                    testlist_comp [43119,43388]
                        atom [43119,43179]
                            operator: { [43119,43120]
                            dictorsetmaker [43120,43178]
                                string: "__type" [43120,43128]
                                string: "dict" [43130,43136]
                                operator: , [43136,43137]
                                string: "__var" [43138,43145]
                                atom [43147,43178]
                                    operator: { [43147,43148]
                                    dictorsetmaker [43148,43177]
                                        string: "key:" [43148,43154]
                                        string: "foo" [43156,43161]
                                        operator: , [43161,43162]
                                        string: "value" [43163,43170]
                                        string: "bar" [43172,43177]
                                    operator: } [43177,43178]
                            operator: } [43178,43179]
                        operator: , [43179,43180]
                        atom [43205,43350]
                            operator: { [43205,43206]
                            dictorsetmaker [43235,43324]
                                string: "__type" [43235,43243]
                                string: "dict" [43245,43251]
                                operator: , [43251,43252]
                                string: "__var" [43281,43288]
                                atom [43290,43323]
                                    operator: { [43290,43291]
                                    dictorsetmaker [43291,43322]
                                        string: "key:" [43291,43297]
                                        string: "this" [43299,43305]
                                        operator: , [43305,43306]
                                        string: "value" [43307,43314]
                                        string: "that" [43316,43322]
                                    operator: } [43322,43323]
                                operator: , [43323,43324]
                            operator: } [43349,43350]
                        operator: , [43350,43351]
                        string: "test_conf" [43376,43387]
                        operator: , [43387,43388]
            operator: } [43427,43428]
        operator: , [43428,43429]
to
testlist_comp [42442,43037]
at 6
===
insert-node
---
operator: , [43443,43444]
to
testlist_comp [42442,43037]
at 7
===
insert-tree
---
atom [43630,43771]
    testlist_comp [43648,43757]
        atom [43648,43693]
            testlist_comp [43649,43692]
                string: 'task_1' [43649,43657]
                operator: , [43657,43658]
                string: 'task_5' [43659,43667]
                operator: , [43667,43668]
                string: 'task_2' [43669,43677]
                operator: , [43677,43678]
                number: 3 [43679,43680]
                operator: , [43680,43681]
                atom [43682,43692]
                    testlist_comp [43683,43691]
                        string: "x" [43683,43686]
                        operator: , [43686,43687]
                        string: "y" [43688,43691]
        operator: , [43693,43694]
        atom [43711,43756]
            testlist_comp [43712,43755]
                string: 'task_1' [43712,43720]
                operator: , [43720,43721]
                string: 'task_5' [43722,43730]
                operator: , [43730,43731]
                string: 'task_2' [43732,43740]
                operator: , [43740,43741]
                number: 3 [43742,43743]
                operator: , [43743,43744]
                atom [43745,43755]
                    testlist_comp [43746,43754]
                        string: "x" [43746,43749]
                        operator: , [43749,43750]
                        string: "y" [43751,43754]
        operator: , [43756,43757]
to
testlist_comp [42442,43037]
at 10
===
insert-node
---
operator: , [43771,43772]
to
testlist_comp [42442,43037]
at 11
===
update-node
---
string: """Test Serialized Lists, Sets and Tuples are sorted""" [43151,43206]
replace """Test Serialized Lists, Sets and Tuples are sorted""" by """Test Serialized Sets are sorted while list and tuple preserve order"""
===
move-tree
---
atom_expr [13101,13120]
    name: getattr [13101,13108]
    trailer [13108,13120]
        arglist [13109,13119]
            name: dag [13109,13112]
            operator: , [13112,13113]
            name: field [13114,13119]
to
comparison [13230,13273]
at 2
===
update-node
---
string: 'task_2' [42529,42537]
replace 'task_2' by 'task_5'
===
update-node
---
string: 'task_4' [42539,42547]
replace 'task_4' by 'task_2'
===
update-node
---
string: 'task_5' [42549,42557]
replace 'task_5' by 'task_4'
===
update-node
---
string: 'task_2' [42819,42827]
replace 'task_2' by 'task_5'
===
update-node
---
string: 'task_4' [42829,42837]
replace 'task_4' by 'task_2'
===
update-node
---
string: 'task_5' [42839,42847]
replace 'task_5' by 'task_4'
===
delete-tree
---
simple_stmt [788,827]
    string: """Unit tests for stringified DAGs.""" [788,826]
===
delete-node
---
name: TestStringifiedDAGs [8877,8896]
===
===
delete-tree
---
simple_stmt [8921,8960]
    string: """Unit tests for stringified DAGs.""" [8921,8959]
===
delete-node
---
expr_stmt [13089,13120]
===
===
delete-node
---
simple_stmt [13089,13121]
===
===
delete-tree
---
if_stmt [13133,13211]
    atom_expr [13136,13163]
        name: isinstance [13136,13146]
        trailer [13146,13163]
            arglist [13147,13162]
                name: dag_field [13147,13156]
                operator: , [13156,13157]
                name: list [13158,13162]
    suite [13164,13211]
        simple_stmt [13181,13211]
            expr_stmt [13181,13210]
                name: dag_field [13181,13190]
                operator: = [13191,13192]
                atom_expr [13193,13210]
                    name: sorted [13193,13199]
                    trailer [13199,13210]
                        name: dag_field [13200,13209]
===
delete-node
---
name: dag_field [13264,13273]
===
