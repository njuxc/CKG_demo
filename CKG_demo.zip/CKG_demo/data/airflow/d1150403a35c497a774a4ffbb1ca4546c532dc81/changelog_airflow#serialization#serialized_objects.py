===
match
---
name: _is_excluded [6953,6965]
name: _is_excluded [6953,6965]
===
match
---
operator: { [8288,8289]
operator: { [8288,8289]
===
match
---
comparison [6008,6019]
comparison [6008,6019]
===
match
---
funcdef [5539,5692]
funcdef [5539,5692]
===
match
---
sync_comp_for [12109,12121]
sync_comp_for [12232,12244]
===
match
---
operator: = [34265,34266]
operator: = [34388,34389]
===
match
---
trailer [34244,34264]
trailer [34367,34387]
===
match
---
tfpdef [20755,20763]
tfpdef [20878,20886]
===
match
---
atom_expr [11775,11787]
atom_expr [11898,11910]
===
match
---
name: cls [10051,10054]
name: cls [10180,10183]
===
match
---
name: airflow [1302,1309]
name: airflow [1302,1309]
===
match
---
atom_expr [29103,29240]
atom_expr [29226,29363]
===
match
---
fstring_expr [16567,16580]
fstring_expr [16690,16703]
===
match
---
operator: , [28954,28955]
operator: , [29077,29078]
===
match
---
string: "dag" [31113,31118]
string: "dag" [31236,31241]
===
match
---
atom [19828,19830]
atom [19951,19953]
===
match
---
operator: , [31330,31331]
operator: , [31453,31454]
===
match
---
name: PodGenerator [11601,11613]
name: PodGenerator [11724,11736]
===
match
---
name: encoded [9533,9540]
name: encoded [9527,9534]
===
match
---
trailer [32753,32764]
trailer [32876,32887]
===
match
---
name: v [9882,9883]
name: v [9897,9898]
===
match
---
atom_expr [12569,12604]
atom_expr [12692,12727]
===
match
---
operator: } [22396,22397]
operator: } [22519,22520]
===
match
---
name: self [14591,14595]
name: self [14714,14718]
===
match
---
expr_stmt [14154,14193]
expr_stmt [14277,14316]
===
match
---
name: timedelta [12578,12587]
name: timedelta [12701,12710]
===
match
---
operator: = [3375,3376]
operator: = [3375,3376]
===
match
---
simple_stmt [34335,34348]
simple_stmt [34458,34471]
===
match
---
atom_expr [8585,8621]
atom_expr [8579,8615]
===
match
---
name: isinstance [8483,8493]
name: isinstance [8477,8487]
===
match
---
name: _is_primitive [8007,8020]
name: _is_primitive [8007,8020]
===
match
---
parameters [4013,4073]
parameters [4013,4073]
===
match
---
trailer [20523,20540]
trailer [20646,20663]
===
match
---
name: import_string [1852,1865]
name: import_string [1852,1865]
===
match
---
operator: @ [31817,31818]
operator: @ [31940,31941]
===
match
---
operator: = [34076,34077]
operator: = [34199,34200]
===
match
---
atom_expr [11379,11407]
atom_expr [11502,11530]
===
match
---
name: var [8327,8330]
name: var [8327,8330]
===
match
---
name: list [3794,3798]
name: list [3794,3798]
===
match
---
operator: -> [17163,17165]
operator: -> [17286,17288]
===
match
---
atom_expr [23572,23611]
atom_expr [23695,23734]
===
match
---
name: isinstance [9928,9938]
name: isinstance [10057,10067]
===
match
---
name: exceptions [1242,1252]
name: exceptions [1242,1252]
===
match
---
expr_stmt [19049,19085]
expr_stmt [19172,19208]
===
match
---
name: bool [12894,12898]
name: bool [13017,13021]
===
match
---
name: cls [7468,7471]
name: cls [7468,7471]
===
match
---
name: op_link_arguments [25348,25365]
name: op_link_arguments [25471,25488]
===
match
---
operator: } [5196,5197]
operator: } [5196,5197]
===
match
---
name: instance [12876,12884]
name: instance [12999,13007]
===
match
---
operator: , [5557,5558]
operator: , [5557,5558]
===
match
---
name: var [31138,31141]
name: var [31261,31264]
===
match
---
name: str [21256,21259]
name: str [21379,21382]
===
match
---
suite [28655,28705]
suite [28778,28828]
===
match
---
name: serialize_operator [15216,15234]
name: serialize_operator [15339,15357]
===
match
---
return_stmt [24367,24399]
return_stmt [24490,24522]
===
match
---
name: json_pod [8523,8531]
name: json_pod [8517,8525]
===
match
---
name: op [15681,15683]
name: op [15804,15806]
===
match
---
suite [1060,1093]
suite [1060,1093]
===
match
---
atom_expr [5817,5854]
atom_expr [5817,5854]
===
match
---
expr_stmt [33681,33946]
expr_stmt [33804,34069]
===
match
---
atom_expr [10886,10958]
atom_expr [11009,11081]
===
match
---
atom_expr [21363,21407]
atom_expr [21486,21530]
===
match
---
if_stmt [5221,5516]
if_stmt [5221,5516]
===
match
---
atom_expr [14591,14606]
atom_expr [14714,14729]
===
match
---
name: encoded_op [17283,17293]
name: encoded_op [17406,17416]
===
match
---
operator: = [10108,10109]
operator: = [10231,10232]
===
match
---
name: downstream_task_ids [34245,34264]
name: downstream_task_ids [34368,34387]
===
match
---
fstring_string: Invalid type  [12316,12329]
fstring_string: Invalid type  [12439,12452]
===
match
---
trailer [28073,28076]
trailer [28196,28199]
===
match
---
trailer [8900,8937]
trailer [8894,8931]
===
match
---
operator: , [26234,26235]
operator: , [26357,26358]
===
match
---
simple_stmt [28672,28705]
simple_stmt [28795,28828]
===
match
---
comp_op [17326,17332]
comp_op [17449,17455]
===
match
---
simple_stmt [21129,21141]
simple_stmt [21252,21264]
===
match
---
atom_expr [16582,16596]
atom_expr [16705,16719]
===
match
---
string: "_date" [28646,28653]
string: "_date" [28769,28776]
===
match
---
atom_expr [4024,4072]
atom_expr [4024,4072]
===
match
---
trailer [11942,11950]
trailer [12065,12073]
===
match
---
expr_stmt [21291,21308]
expr_stmt [21414,21431]
===
match
---
atom_expr [27471,27498]
atom_expr [27594,27621]
===
match
---
name: cls [31859,31862]
name: cls [31982,31985]
===
match
---
trailer [9909,9913]
trailer [9924,9928]
===
match
---
expr_stmt [27408,27455]
expr_stmt [27531,27578]
===
match
---
trailer [12148,12154]
trailer [12271,12277]
===
match
---
name: upstream_group_ids [32692,32710]
name: upstream_group_ids [32815,32833]
===
match
---
atom_expr [5182,5194]
atom_expr [5182,5194]
===
match
---
name: param_to_attr [26175,26188]
name: param_to_attr [26298,26311]
===
match
---
name: cls [10430,10433]
name: cls [10553,10556]
===
match
---
name: task_dict [33719,33728]
name: task_dict [33842,33851]
===
match
---
fstring_start: f" [16488,16490]
fstring_start: f" [16611,16613]
===
match
---
name: getattr [16869,16876]
name: getattr [16992,16999]
===
match
---
atom_expr [26874,26923]
atom_expr [26997,27046]
===
match
---
testlist_comp [32483,32546]
testlist_comp [32606,32669]
===
match
---
string: "_is_dummy" [20637,20648]
string: "_is_dummy" [20760,20771]
===
match
---
suite [11862,12038]
suite [11985,12161]
===
match
---
trailer [25164,25397]
trailer [25287,25520]
===
match
---
comp_op [14337,14343]
comp_op [14460,14466]
===
match
---
simple_stmt [26391,26564]
simple_stmt [26514,26687]
===
match
---
operator: } [28565,28566]
operator: } [28688,28689]
===
match
---
suite [15153,15190]
suite [15276,15313]
===
match
---
not_test [31989,32003]
not_test [32112,32126]
===
match
---
trailer [19254,19273]
trailer [19377,19396]
===
match
---
arglist [6327,6351]
arglist [6327,6351]
===
match
---
for_stmt [16803,17054]
for_stmt [16926,17177]
===
match
---
operator: , [30068,30069]
operator: , [30191,30192]
===
match
---
name: SerializedTaskGroup [33597,33616]
name: SerializedTaskGroup [33720,33739]
===
match
---
arglist [18817,18886]
arglist [18940,19009]
===
match
---
simple_stmt [824,840]
simple_stmt [824,840]
===
match
---
fstring_conversion [16432,16434]
fstring_conversion [16555,16557]
===
match
---
name: _CONSTRUCTOR_PARAMS [12770,12789]
name: _CONSTRUCTOR_PARAMS [12893,12912]
===
match
---
trailer [8961,8986]
trailer [8955,8980]
===
match
---
arglist [8245,8254]
arglist [8245,8254]
===
match
---
name: Dict [33185,33189]
name: Dict [33308,33312]
===
match
---
string: "Can't load plugins" [22337,22357]
string: "Can't load plugins" [22460,22480]
===
match
---
suite [11171,11226]
suite [11294,11349]
===
match
---
name: Set [21265,21268]
name: Set [21388,21391]
===
match
---
name: deserialize_task_group [29123,29145]
name: deserialize_task_group [29246,29268]
===
match
---
param [5559,5569]
param [5559,5569]
===
match
---
arglist [16943,16968]
arglist [17066,17091]
===
match
---
name: serialize_to_json [6461,6478]
name: serialize_to_json [6461,6478]
===
match
---
simple_stmt [1811,1866]
simple_stmt [1811,1866]
===
match
---
name: type_ [11007,11012]
name: type_ [11130,11135]
===
match
---
trailer [27012,27018]
trailer [27135,27141]
===
match
---
atom_expr [21156,21195]
atom_expr [21279,21318]
===
match
---
name: type_ [11054,11059]
name: type_ [11177,11182]
===
match
---
operator: = [15635,15636]
operator: = [15758,15759]
===
match
---
operator: , [30023,30024]
operator: , [30146,30147]
===
match
---
not_test [16922,16969]
not_test [17045,17092]
===
match
---
name: op_link_arguments [25092,25109]
name: op_link_arguments [25215,25232]
===
match
---
operator: , [16948,16949]
operator: , [17071,17072]
===
match
---
atom_expr [3943,3959]
atom_expr [3943,3959]
===
match
---
name: DAT [11163,11166]
name: DAT [11286,11289]
===
match
---
name: key [6973,6976]
name: key [6973,6976]
===
match
---
suite [22301,22359]
suite [22424,22482]
===
match
---
name: cls [17130,17133]
name: cls [17253,17256]
===
match
---
atom_expr [19529,19569]
atom_expr [19652,19692]
===
match
---
trailer [32233,32241]
trailer [32356,32364]
===
match
---
name: keys_to_serialize [6685,6702]
name: keys_to_serialize [6685,6702]
===
match
---
operator: -> [4074,4076]
operator: -> [4074,4076]
===
match
---
name: bool [5750,5754]
name: bool [5750,5754]
===
match
---
name: _json_schema [5274,5286]
name: _json_schema [5274,5286]
===
match
---
suite [5257,5312]
suite [5257,5312]
===
match
---
name: _datetime_types [8852,8867]
name: _datetime_types [8846,8861]
===
match
---
operator: == [28096,28098]
operator: == [28219,28221]
===
match
---
operator: { [11092,11093]
operator: { [11215,11216]
===
match
---
name: template_field [16881,16895]
name: template_field [17004,17018]
===
match
---
name: _deserialize [34086,34098]
name: _deserialize [34209,34221]
===
match
---
name: SerializedTaskGroup [10180,10199]
name: SerializedTaskGroup [10303,10322]
===
match
---
suite [18279,18355]
suite [18402,18478]
===
match
---
parameters [26757,26772]
parameters [26880,26895]
===
match
---
name: __name__ [15453,15461]
name: __name__ [15576,15584]
===
match
---
atom [24148,24150]
atom [24271,24273]
===
match
---
simple_stmt [10880,10959]
simple_stmt [11003,11082]
===
match
---
name: models [1381,1387]
name: models [1381,1387]
===
match
---
name: serialize_operator_extra_links [25414,25444]
name: serialize_operator_extra_links [25537,25567]
===
match
---
dotted_name [1373,1398]
dotted_name [1373,1398]
===
match
---
simple_stmt [27408,27456]
simple_stmt [27531,27579]
===
match
---
suite [7146,7349]
suite [7146,7349]
===
match
---
simple_stmt [867,908]
simple_stmt [867,908]
===
match
---
name: type_ [12136,12141]
name: type_ [12259,12264]
===
match
---
argument [33636,33661]
argument [33759,33784]
===
match
---
trailer [32841,32852]
trailer [32964,32975]
===
match
---
name: classmethod [5698,5709]
name: classmethod [5698,5709]
===
match
---
string: 'has_on_failure_callback' [27530,27555]
string: 'has_on_failure_callback' [27653,27678]
===
match
---
name: k [26433,26434]
name: k [26556,26557]
===
match
---
atom [26191,26382]
atom [26314,26505]
===
match
---
operator: , [6491,6492]
operator: , [6491,6492]
===
match
---
name: s [12336,12337]
name: s [12459,12460]
===
match
---
name: import_string [21549,21562]
name: import_string [21672,21685]
===
match
---
name: serialize_task_group [10200,10220]
name: serialize_task_group [10323,10343]
===
match
---
return_stmt [34335,34347]
return_stmt [34458,34470]
===
match
---
name: encoded_var [10739,10750]
name: encoded_var [10862,10873]
===
match
---
tfpdef [10435,10451]
tfpdef [10558,10574]
===
match
---
name: utils [1879,1884]
name: utils [1879,1884]
===
match
---
string: "downstream_task_ids" [32902,32923]
string: "downstream_task_ids" [33025,33046]
===
match
---
trailer [29959,29961]
trailer [30082,30084]
===
match
---
param [4983,4987]
param [4983,4987]
===
match
---
trailer [26425,26429]
trailer [26548,26552]
===
match
---
operator: @ [12610,12611]
operator: @ [12733,12734]
===
match
---
operator: , [32497,32498]
operator: , [32620,32621]
===
match
---
trailer [31092,31111]
trailer [31215,31234]
===
match
---
param [31864,31885]
param [31987,32008]
===
match
---
simple_stmt [10515,10580]
simple_stmt [10638,10703]
===
match
---
name: qualname [21662,21670]
name: qualname [21785,21793]
===
match
---
name: op [15376,15378]
name: op [15499,15501]
===
match
---
atom_expr [15162,15177]
atom_expr [15285,15300]
===
match
---
if_stmt [25032,25115]
if_stmt [25155,25238]
===
match
---
name: v [8441,8442]
name: v [8435,8436]
===
match
---
name: classmethod [31818,31829]
name: classmethod [31941,31952]
===
match
---
simple_stmt [10771,10821]
simple_stmt [10894,10944]
===
match
---
name: op_predefined_extra_links [22367,22392]
name: op_predefined_extra_links [22490,22515]
===
match
---
atom_expr [26546,26553]
atom_expr [26669,26676]
===
match
---
funcdef [20733,21196]
funcdef [20856,21319]
===
match
---
operator: } [8338,8339]
operator: } [8338,8339]
===
match
---
trailer [14595,14606]
trailer [14718,14729]
===
match
---
string: 'access_control' [26336,26352]
string: 'access_control' [26459,26475]
===
match
---
if_stmt [11451,11583]
if_stmt [11574,11706]
===
match
---
annassign [6655,6676]
annassign [6655,6676]
===
match
---
name: cls [19529,19532]
name: cls [19652,19655]
===
match
---
simple_stmt [21149,21196]
simple_stmt [21272,21319]
===
match
---
name: var [9663,9666]
name: var [9657,9660]
===
match
---
operator: = [24979,24980]
operator: = [25102,25103]
===
match
---
classdef [2927,13870]
classdef [2927,13993]
===
match
---
name: v [28615,28616]
name: v [28738,28739]
===
match
---
return_stmt [15067,15089]
return_stmt [15190,15212]
===
match
---
string: "tasks" [26951,26958]
string: "tasks" [27074,27081]
===
match
---
suite [27391,27456]
suite [27514,27579]
===
match
---
decorator [21717,21730]
decorator [21840,21853]
===
match
---
simple_stmt [24141,24151]
simple_stmt [24264,24274]
===
match
---
name: task [26978,26982]
name: task [27101,27105]
===
match
---
name: field [20432,20437]
name: field [20555,20560]
===
match
---
name: v [19350,19351]
name: v [19473,19474]
===
match
---
funcdef [31834,33021]
funcdef [31957,33144]
===
match
---
dictorsetmaker [8289,8338]
dictorsetmaker [8289,8338]
===
match
---
name: _serialize_operator_extra_links [24426,24457]
name: _serialize_operator_extra_links [24549,24580]
===
match
---
tfpdef [5551,5557]
tfpdef [5551,5557]
===
match
---
atom_expr [14844,14869]
atom_expr [14967,14992]
===
match
---
name: list [18845,18849]
name: list [18968,18972]
===
match
---
name: airflow [1422,1429]
name: airflow [1422,1429]
===
match
---
name: Union [4024,4029]
name: Union [4024,4029]
===
match
---
simple_stmt [28806,28811]
simple_stmt [28929,28934]
===
match
---
import_name [840,851]
import_name [840,851]
===
match
---
name: add [29501,29504]
name: add [29624,29627]
===
match
---
name: to_dict [4006,4013]
name: to_dict [4006,4013]
===
match
---
name: _decorated_fields [26905,26922]
name: _decorated_fields [27028,27045]
===
match
---
dictorsetmaker [26205,26372]
dictorsetmaker [26328,26495]
===
match
---
import_as_names [1547,1581]
import_as_names [1547,1581]
===
match
---
suite [20299,20333]
suite [20422,20456]
===
match
---
operator: , [4733,4734]
operator: , [4733,4734]
===
match
---
trailer [19722,19729]
trailer [19845,19852]
===
match
---
classdef [25447,31694]
classdef [25570,31817]
===
match
---
trailer [20864,20873]
trailer [20987,20996]
===
match
---
name: dag [29430,29433]
name: dag [29553,29556]
===
match
---
name: __module__ [18216,18226]
name: __module__ [18339,18349]
===
match
---
operator: @ [4349,4350]
operator: @ [4349,4350]
===
match
---
name: isinstance [10728,10738]
name: isinstance [10851,10861]
===
match
---
atom_expr [14807,14835]
atom_expr [14930,14958]
===
match
---
trailer [24224,24252]
trailer [24347,24375]
===
match
---
expr_stmt [26937,27021]
expr_stmt [27060,27144]
===
match
---
dotted_name [1587,1616]
dotted_name [1587,1616]
===
match
---
name: cls [33454,33457]
name: cls [33577,33580]
===
match
---
name: set [4741,4744]
name: set [4741,4744]
===
match
---
subscriptlist [21809,21830]
subscriptlist [21932,21953]
===
match
---
decorator [4349,4362]
decorator [4349,4362]
===
match
---
fstring_string: The encoded_var should be dict and is  [10899,10937]
fstring_string: The encoded_var should be dict and is  [11022,11060]
===
match
---
name: attrname [13694,13702]
name: attrname [13817,13825]
===
match
---
name: classmethod [24406,24417]
name: classmethod [24529,24540]
===
match
---
parameters [31326,31353]
parameters [31449,31476]
===
match
---
testlist_comp [32387,32408]
testlist_comp [32510,32531]
===
match
---
atom_expr [9504,9515]
atom_expr [9498,9509]
===
match
---
suite [11438,11665]
suite [11561,11788]
===
match
---
name: ImportError [21595,21606]
name: ImportError [21718,21729]
===
match
---
string: "dagrun_timeout" [28549,28565]
string: "dagrun_timeout" [28672,28688]
===
match
---
string: """A JSON serializable representation of operator.      All operators are casted to SerializedBaseOperator after deserialization.     Class specific attributes used by UI are move to object attributes.     """ [13939,14148]
string: """A JSON serializable representation of operator.      All operators are casted to SerializedBaseOperator after deserialization.     Class specific attributes used by UI are move to object attributes.     """ [14062,14271]
===
match
---
name: Dict [33107,33111]
name: Dict [33230,33234]
===
match
---
atom_expr [20219,20245]
atom_expr [20342,20368]
===
match
---
arglist [10262,10312]
arglist [10385,10435]
===
match
---
atom_expr [9019,9038]
atom_expr [9013,9032]
===
match
---
param [21777,21799]
param [21900,21922]
===
match
---
parameters [27797,27831]
parameters [27920,27954]
===
match
---
expr_stmt [34049,34138]
expr_stmt [34172,34261]
===
match
---
atom_expr [8676,8708]
atom_expr [8670,8702]
===
match
---
name: k [11093,11094]
name: k [11216,11217]
===
match
---
trailer [15423,15437]
trailer [15546,15560]
===
match
---
suite [5357,5424]
suite [5357,5424]
===
match
---
tfpdef [7473,7481]
tfpdef [7473,7481]
===
match
---
name: str [33112,33115]
name: str [33235,33238]
===
match
---
name: ope [18349,18352]
name: ope [18472,18475]
===
match
---
trailer [26480,26494]
trailer [26603,26617]
===
match
---
fstring [31590,31634]
fstring [31713,31757]
===
match
---
name: v [19049,19050]
name: v [19172,19173]
===
match
---
trailer [16929,16942]
trailer [17052,17065]
===
match
---
name: items [27997,28002]
name: items [28120,28125]
===
match
---
expr_stmt [27210,27252]
expr_stmt [27333,27375]
===
match
---
name: extra_links_class_names [2867,2890]
name: extra_links_class_names [2867,2890]
===
match
---
trailer [19066,19082]
trailer [19189,19205]
===
match
---
name: get_operator_extra_links [23656,23680]
name: get_operator_extra_links [23779,23803]
===
match
---
arith_expr [29880,29961]
arith_expr [30003,30084]
===
match
---
name: operator [18133,18141]
name: operator [18256,18264]
===
match
---
name: TIMEDELTA [9050,9059]
name: TIMEDELTA [9044,9053]
===
match
---
name: serialization [1520,1533]
name: serialization [1520,1533]
===
match
---
name: var [9350,9353]
name: var [9344,9347]
===
match
---
atom_expr [16612,16632]
atom_expr [16735,16755]
===
match
---
trailer [9870,9881]
trailer [9885,9896]
===
match
---
atom_expr [18909,18927]
atom_expr [19032,19050]
===
match
---
operator: = [33433,33434]
operator: = [33556,33557]
===
match
---
atom_expr [19987,20011]
atom_expr [20110,20134]
===
match
---
trailer [32764,32803]
trailer [32887,32926]
===
match
---
name: operator [18207,18215]
name: operator [18330,18338]
===
match
---
expr_stmt [19848,19892]
expr_stmt [19971,20015]
===
match
---
expr_stmt [26569,26628]
expr_stmt [26692,26751]
===
match
---
name: deserialize_task_group [33047,33069]
name: deserialize_task_group [33170,33192]
===
match
---
name: v [12106,12107]
name: v [12229,12230]
===
match
---
name: _encode [9599,9606]
name: _encode [9593,9600]
===
match
---
comparison [17318,17343]
comparison [17441,17466]
===
match
---
fstring_expr [16397,16435]
fstring_expr [16520,16558]
===
match
---
atom_expr [8889,8937]
atom_expr [8883,8931]
===
match
---
name: op [16877,16879]
name: op [17000,17002]
===
match
---
trailer [14848,14869]
trailer [14971,14992]
===
match
---
trailer [10847,10866]
trailer [10970,10989]
===
match
---
name: DAT [12060,12063]
name: DAT [12183,12186]
===
match
---
name: BaseSerialization [31733,31750]
name: BaseSerialization [31856,31873]
===
match
---
atom [9248,9318]
atom [9242,9312]
===
match
---
comp_op [26539,26545]
comp_op [26662,26668]
===
match
---
name: ti_deps [2173,2180]
name: ti_deps [2173,2180]
===
match
---
name: cls [10652,10655]
name: cls [10775,10778]
===
match
---
operator: , [33121,33122]
operator: , [33244,33245]
===
match
---
trailer [30289,30319]
trailer [30412,30442]
===
match
---
import_from [1297,1367]
import_from [1297,1367]
===
match
---
expr_stmt [6886,6933]
expr_stmt [6886,6933]
===
match
---
atom_expr [16825,16843]
atom_expr [16948,16966]
===
match
---
name: datetime [11721,11729]
name: datetime [11844,11852]
===
match
---
name: list [23572,23576]
name: list [23695,23699]
===
match
---
decorated [24405,25445]
decorated [24528,25568]
===
match
---
operator: , [24461,24462]
operator: , [24584,24585]
===
match
---
expr_stmt [7318,7348]
expr_stmt [7318,7348]
===
match
---
name: dag [30070,30073]
name: dag [30193,30196]
===
match
---
name: endswith [28637,28645]
name: endswith [28760,28768]
===
match
---
atom_expr [21030,21061]
atom_expr [21153,21184]
===
match
---
simple_stmt [21019,21062]
simple_stmt [21142,21185]
===
match
---
simple_stmt [12747,12790]
simple_stmt [12870,12913]
===
match
---
name: SerializedDAG [27919,27932]
name: SerializedDAG [28042,28055]
===
match
---
name: set [34267,34270]
name: set [34390,34393]
===
match
---
trailer [6043,6065]
trailer [6043,6065]
===
match
---
trailer [20008,20011]
trailer [20131,20134]
===
match
---
trailer [4924,4940]
trailer [4924,4940]
===
match
---
trailer [8851,8867]
trailer [8845,8861]
===
match
---
name: type_ [11337,11342]
name: type_ [11460,11465]
===
match
---
operator: , [12862,12863]
operator: , [12985,12986]
===
match
---
string: "children" [32349,32359]
string: "children" [32472,32482]
===
match
---
name: var [9555,9558]
name: var [9549,9552]
===
match
---
for_stmt [18053,18355]
for_stmt [18176,18478]
===
match
---
decorator [30913,30926]
decorator [31036,31049]
===
match
---
name: serialized_obj [5336,5350]
name: serialized_obj [5336,5350]
===
match
---
name: bool [12691,12695]
name: bool [12814,12818]
===
match
---
trailer [32518,32539]
trailer [32641,32662]
===
match
---
trailer [17453,17462]
trailer [17576,17585]
===
match
---
decorator [14911,14921]
decorator [15034,15044]
===
match
---
simple_stmt [20183,20201]
simple_stmt [20306,20324]
===
match
---
name: k [19909,19910]
name: k [20032,20033]
===
match
---
simple_stmt [2160,2215]
simple_stmt [2160,2215]
===
match
---
name: dag_date [21103,21111]
name: dag_date [21226,21234]
===
match
---
name: op [15637,15639]
name: op [15760,15762]
===
match
---
if_stmt [18104,18355]
if_stmt [18227,18478]
===
match
---
atom_expr [32429,32460]
atom_expr [32552,32583]
===
match
---
trailer [27421,27448]
trailer [27544,27571]
===
match
---
name: group [33589,33594]
name: group [33712,33717]
===
match
---
simple_stmt [26649,26680]
simple_stmt [26772,26803]
===
match
---
trailer [10655,10669]
trailer [10778,10792]
===
match
---
name: BaseOperator [14752,14764]
name: BaseOperator [14875,14887]
===
match
---
decorator [12610,12623]
decorator [12733,12746]
===
match
---
name: validate_schema [4967,4982]
name: validate_schema [4967,4982]
===
match
---
suite [25075,25115]
suite [25198,25238]
===
match
---
return_stmt [4558,4606]
return_stmt [4558,4606]
===
match
---
atom_expr [16991,17019]
atom_expr [17114,17142]
===
match
---
name: default [14236,14243]
name: default [14359,14366]
===
match
---
suite [28855,28896]
suite [28978,29019]
===
match
---
name: ui_fgcolor [14765,14775]
name: ui_fgcolor [14888,14898]
===
match
---
suite [16307,16536]
suite [16430,16659]
===
match
---
atom_expr [34003,34038]
atom_expr [34126,34161]
===
match
---
name: var [11891,11894]
name: var [12014,12017]
===
match
---
operator: , [896,897]
operator: , [896,897]
===
match
---
atom_expr [11346,11358]
atom_expr [11469,11481]
===
match
---
operator: ! [16509,16510]
operator: ! [16632,16633]
===
match
---
suite [10506,12361]
suite [10629,12484]
===
match
---
comparison [14327,14351]
comparison [14450,14474]
===
match
---
name: task [30200,30204]
name: task [30323,30327]
===
match
---
name: var [11319,11322]
name: var [11442,11445]
===
match
---
name: json_dict [31281,31290]
name: json_dict [31404,31413]
===
match
---
name: setattr [18809,18816]
name: setattr [18932,18939]
===
match
---
operator: { [12329,12330]
operator: { [12452,12453]
===
match
---
name: var [8962,8965]
name: var [8956,8959]
===
match
---
name: k [20029,20030]
name: k [20152,20153]
===
match
---
trailer [10054,10062]
trailer [10183,10191]
===
match
---
raise_stmt [16328,16535]
raise_stmt [16451,16658]
===
match
---
atom_expr [19857,19891]
atom_expr [19980,20014]
===
match
---
simple_stmt [19909,19936]
simple_stmt [20032,20059]
===
match
---
param [27803,27830]
param [27926,27953]
===
match
---
atom_expr [34177,34229]
atom_expr [34300,34352]
===
match
---
name: inherits_from_dummy_operator [15640,15668]
name: inherits_from_dummy_operator [15763,15791]
===
match
---
operator: , [4033,4034]
operator: , [4033,4034]
===
match
---
return_stmt [8405,8450]
return_stmt [8405,8444]
===
match
---
import_from [1186,1227]
import_from [1186,1227]
===
match
---
atom [25112,25114]
atom [25235,25237]
===
match
---
name: value [16943,16948]
name: value [17066,17071]
===
match
---
atom_expr [30815,30887]
atom_expr [30938,31010]
===
match
---
simple_stmt [7082,7129]
simple_stmt [7082,7129]
===
match
---
name: _task_group [29394,29405]
name: _task_group [29517,29528]
===
match
---
name: op [16146,16148]
name: op [16269,16271]
===
match
---
trailer [16827,16843]
trailer [16950,16966]
===
match
---
import_from [1452,1506]
import_from [1452,1506]
===
match
---
suite [4082,4344]
suite [4082,4344]
===
match
---
atom_expr [31120,31142]
atom_expr [31243,31265]
===
match
---
name: operator_extra_links [14849,14869]
name: operator_extra_links [14972,14992]
===
match
---
simple_stmt [3605,3639]
simple_stmt [3605,3639]
===
match
---
name: json [3932,3936]
name: json [3932,3936]
===
match
---
trailer [10062,10119]
trailer [10191,10242]
===
match
---
name: op_predefined_extra_link [24331,24355]
name: op_predefined_extra_link [24454,24478]
===
match
---
trailer [3954,3959]
trailer [3954,3959]
===
match
---
operator: { [25112,25113]
operator: { [25235,25236]
===
match
---
operator: { [3688,3689]
operator: { [3688,3689]
===
match
---
suite [27631,27650]
suite [27754,27773]
===
match
---
name: _task_group [29089,29100]
name: _task_group [29212,29223]
===
match
---
argument [8918,8936]
argument [8912,8930]
===
match
---
operator: { [24148,24149]
operator: { [24271,24272]
===
match
---
expr_stmt [23538,23611]
expr_stmt [23661,23734]
===
match
---
dictorsetmaker [12089,12121]
dictorsetmaker [12212,12244]
===
match
---
param [5551,5558]
param [5551,5558]
===
match
---
return_stmt [32998,33020]
return_stmt [33121,33143]
===
match
---
operator: ! [12335,12336]
operator: ! [12458,12459]
===
match
---
name: cls [6332,6335]
name: cls [6332,6335]
===
match
---
and_test [9290,9317]
and_test [9284,9311]
===
match
---
trailer [21548,21575]
trailer [21671,21698]
===
match
---
operator: == [12142,12144]
operator: == [12265,12267]
===
match
---
name: DAG [8651,8654]
name: DAG [8645,8648]
===
match
---
comparison [28543,28566]
comparison [28666,28689]
===
match
---
trailer [9475,9483]
trailer [9469,9477]
===
match
---
param [30942,30946]
param [31065,31069]
===
match
---
if_stmt [29040,29511]
if_stmt [29163,29634]
===
match
---
name: parent_group [33636,33648]
name: parent_group [33759,33771]
===
match
---
trailer [28002,28004]
trailer [28125,28127]
===
match
---
name: error [21429,21434]
name: error [21552,21557]
===
match
---
name: serialized_obj [5235,5249]
name: serialized_obj [5235,5249]
===
match
---
simple_stmt [8523,8566]
simple_stmt [8517,8560]
===
match
---
atom_expr [28346,28395]
atom_expr [28469,28518]
===
match
---
name: parent_group [33649,33661]
name: parent_group [33772,33784]
===
match
---
name: cls [34082,34085]
name: cls [34205,34208]
===
match
---
trailer [6965,6998]
trailer [6965,6998]
===
match
---
name: cls [13748,13751]
name: cls [13871,13874]
===
match
---
arglist [29179,29226]
arglist [29302,29349]
===
match
---
name: encoded_var [10943,10954]
name: encoded_var [11066,11077]
===
match
---
comparison [19103,19170]
comparison [19226,19293]
===
match
---
simple_stmt [31931,31978]
simple_stmt [32054,32101]
===
match
---
trailer [16876,16902]
trailer [16999,17025]
===
match
---
funcdef [24422,25445]
funcdef [24545,25568]
===
match
---
for_stmt [6757,7349]
for_stmt [6757,7349]
===
match
---
operator: { [13805,13806]
operator: { [13928,13929]
===
match
---
operator: = [1160,1161]
operator: = [1160,1161]
===
match
---
name: k [8293,8294]
name: k [8293,8294]
===
match
---
name: setattr [30349,30356]
name: setattr [30472,30479]
===
match
---
if_stmt [29760,29852]
if_stmt [29883,29975]
===
match
---
atom_expr [11601,11641]
atom_expr [11724,11764]
===
match
---
name: var [6327,6330]
name: var [6327,6330]
===
match
---
simple_stmt [24266,24358]
simple_stmt [24389,24481]
===
match
---
operator: = [8612,8613]
operator: = [8606,8607]
===
match
---
operator: -> [31887,31889]
operator: -> [32010,32012]
===
match
---
name: template_fields [14820,14835]
name: template_fields [14943,14958]
===
match
---
trailer [28368,28389]
trailer [28491,28512]
===
match
---
trailer [22259,22292]
trailer [22382,22415]
===
match
---
name: cls [9848,9851]
name: cls [9863,9866]
===
match
---
suite [22454,24358]
suite [22577,24481]
===
match
---
expr_stmt [14199,14357]
expr_stmt [14322,14480]
===
match
---
atom_expr [27940,27962]
atom_expr [28063,28085]
===
match
---
name: Any [7478,7481]
name: Any [7478,7481]
===
match
---
trailer [24291,24298]
trailer [24414,24421]
===
match
---
operator: , [2607,2608]
operator: , [2607,2608]
===
match
---
name: module_name [16259,16270]
name: module_name [16382,16393]
===
match
---
name: Timezone [9090,9098]
name: Timezone [9084,9092]
===
match
---
dictorsetmaker [24300,24355]
dictorsetmaker [24423,24478]
===
match
---
arglist [3943,3978]
arglist [3943,3978]
===
match
---
trailer [11131,11137]
trailer [11254,11260]
===
match
---
if_stmt [28018,28896]
if_stmt [28141,29019]
===
match
---
expr_stmt [19983,20011]
expr_stmt [20106,20134]
===
match
---
if_stmt [5100,5212]
if_stmt [5100,5212]
===
match
---
string: "end_date" [30250,30260]
string: "end_date" [30373,30383]
===
match
---
argument [14432,14440]
argument [14555,14563]
===
match
---
name: cls [9120,9123]
name: cls [9114,9117]
===
match
---
name: isinstance [8234,8244]
name: isinstance [8234,8244]
===
match
---
arglist [10848,10865]
arglist [10971,10988]
===
match
---
name: kwargs [14434,14440]
name: kwargs [14557,14563]
===
match
---
funcdef [12812,13870]
funcdef [12935,13993]
===
match
---
name: label [32568,32573]
name: label [32691,32696]
===
match
---
operator: , [6971,6972]
operator: , [6971,6972]
===
match
---
del_stmt [26649,26679]
del_stmt [26772,26802]
===
match
---
atom_expr [24485,24511]
atom_expr [24608,24634]
===
match
---
simple_stmt [11801,11822]
simple_stmt [11924,11945]
===
match
---
name: BaseOperator [30185,30197]
name: BaseOperator [30308,30320]
===
match
---
simple_stmt [32998,33021]
simple_stmt [33121,33144]
===
match
---
return_stmt [7357,7381]
return_stmt [7357,7381]
===
match
---
name: providers_manager [1465,1482]
name: providers_manager [1465,1482]
===
match
---
name: json [1751,1755]
name: json [1751,1755]
===
match
---
operator: , [5922,5923]
operator: , [5922,5923]
===
match
---
trailer [33153,33164]
trailer [33276,33287]
===
match
---
comparison [23781,23858]
comparison [23904,23981]
===
match
---
comparison [28828,28854]
comparison [28951,28977]
===
match
---
trailer [20832,20840]
trailer [20955,20963]
===
match
---
name: _load_operator_extra_links [3605,3631]
name: _load_operator_extra_links [3605,3631]
===
match
---
atom_expr [7082,7104]
atom_expr [7082,7104]
===
match
---
name: deps [15889,15893]
name: deps [16012,16016]
===
match
---
atom_expr [11096,11115]
atom_expr [11219,11238]
===
match
---
decorator [20716,20729]
decorator [20839,20852]
===
match
---
name: format [25212,25218]
name: format [25335,25341]
===
match
---
tfpdef [30947,30955]
tfpdef [31070,31078]
===
match
---
name: children [33687,33695]
name: children [33810,33818]
===
match
---
name: instance [5924,5932]
name: instance [5924,5932]
===
match
---
expr_stmt [22367,22397]
expr_stmt [22490,22520]
===
match
---
name: encoded_dag [27803,27814]
name: encoded_dag [27926,27937]
===
match
---
return_stmt [10044,10119]
return_stmt [10173,10242]
===
match
---
param [6540,6561]
param [6540,6561]
===
match
---
name: Timezone [11808,11816]
name: Timezone [11931,11939]
===
match
---
trailer [11137,11139]
trailer [11260,11262]
===
match
---
atom_expr [30490,30514]
atom_expr [30613,30637]
===
match
---
atom_expr [15074,15089]
atom_expr [15197,15212]
===
match
---
funcdef [5877,6435]
funcdef [5877,6435]
===
match
---
name: cls [6488,6491]
name: cls [6488,6491]
===
match
---
name: r [16433,16434]
name: r [16556,16557]
===
match
---
name: cls [32925,32928]
name: cls [33048,33051]
===
match
---
name: from_timestamp [11388,11402]
name: from_timestamp [11511,11525]
===
match
---
name: _operator_links_source [22411,22433]
name: _operator_links_source [22534,22556]
===
match
---
string: "execution_timeout" [19124,19143]
string: "execution_timeout" [19247,19266]
===
match
---
subscriptlist [33190,33207]
subscriptlist [33313,33330]
===
match
---
name: classmethod [20717,20728]
name: classmethod [20840,20851]
===
match
---
operator: , [20648,20649]
operator: , [20771,20772]
===
match
---
name: op [20708,20710]
name: op [20831,20833]
===
match
---
operator: = [28068,28069]
operator: = [28191,28192]
===
match
---
name: endswith [20856,20864]
name: endswith [20979,20987]
===
match
---
name: weekday [9455,9462]
name: weekday [9449,9456]
===
match
---
atom_expr [8153,8162]
atom_expr [8153,8162]
===
match
---
name: seconds [12588,12595]
name: seconds [12711,12718]
===
match
---
simple_stmt [6237,6301]
simple_stmt [6237,6301]
===
match
---
expr_stmt [2252,2610]
expr_stmt [2252,2610]
===
match
---
suite [16790,17054]
suite [16913,17177]
===
match
---
trailer [27712,27755]
trailer [27835,27878]
===
match
---
comparison [18750,18791]
comparison [18873,18914]
===
match
---
suite [10160,10226]
suite [10283,10349]
===
match
---
comparison [5103,5127]
comparison [5103,5127]
===
match
---
operator: } [33945,33946]
operator: } [34068,34069]
===
match
---
operator: = [19352,19353]
operator: = [19475,19476]
===
match
---
arglist [26430,26434]
arglist [26553,26557]
===
match
---
trailer [12016,12030]
trailer [12139,12153]
===
match
---
expr_stmt [34239,34326]
expr_stmt [34362,34449]
===
match
---
trailer [9436,9447]
trailer [9430,9441]
===
match
---
trailer [30828,30837]
trailer [30951,30960]
===
match
---
name: dag [27363,27366]
name: dag [27486,27489]
===
match
---
subscriptlist [4415,4458]
subscriptlist [4415,4458]
===
match
---
operator: , [33082,33083]
operator: , [33205,33206]
===
match
---
string: "__type" [7240,7248]
string: "__type" [7240,7248]
===
match
---
trailer [3669,3685]
trailer [3669,3685]
===
match
---
trailer [34176,34230]
trailer [34299,34353]
===
match
---
decorator [7436,7449]
decorator [7436,7449]
===
match
---
name: __init__ [14416,14424]
name: __init__ [14539,14547]
===
match
---
param [12658,12672]
param [12781,12795]
===
match
---
suite [8752,8819]
suite [8746,8813]
===
match
---
name: Any [12886,12889]
name: Any [13009,13012]
===
match
---
operator: } [31142,31143]
operator: } [31265,31266]
===
match
---
operator: , [20533,20534]
operator: , [20656,20657]
===
match
---
trailer [26977,26983]
trailer [27100,27106]
===
match
---
name: cls [4983,4986]
name: cls [4983,4986]
===
match
---
suite [30659,30888]
suite [30782,31011]
===
match
---
atom_expr [4565,4606]
atom_expr [4565,4606]
===
match
---
decorator [27761,27774]
decorator [27884,27897]
===
match
---
atom_expr [20625,20691]
atom_expr [20748,20814]
===
match
---
name: __name__ [25316,25324]
name: __name__ [25439,25447]
===
match
---
name: cls [9007,9010]
name: cls [9001,9004]
===
match
---
name: DATETIME [8928,8936]
name: DATETIME [8922,8930]
===
match
---
name: task_dict [30819,30828]
name: task_dict [30942,30951]
===
match
---
trailer [8794,8813]
trailer [8788,8807]
===
match
---
name: task [29451,29455]
name: task [29574,29578]
===
match
---
trailer [33484,33489]
trailer [33607,33612]
===
match
---
trailer [25263,25273]
trailer [25386,25396]
===
match
---
atom [3066,3089]
atom [3066,3089]
===
match
---
expr_stmt [19909,19935]
expr_stmt [20032,20058]
===
match
---
string: "prefix_group_id" [32153,32170]
string: "prefix_group_id" [32276,32293]
===
match
---
simple_stmt [1417,1452]
simple_stmt [1417,1452]
===
match
---
trailer [16423,16431]
trailer [16546,16554]
===
match
---
name: var [8021,8024]
name: var [8021,8024]
===
match
---
atom_expr [17147,17161]
atom_expr [17270,17284]
===
match
---
trailer [26511,26513]
trailer [26634,26636]
===
match
---
name: _deserialize [33458,33470]
name: _deserialize [33581,33593]
===
match
---
arglist [9132,9165]
arglist [9126,9159]
===
match
---
string: "_task_module" [18241,18255]
string: "_task_module" [18364,18378]
===
match
---
operator: = [26013,26014]
operator: = [26136,26137]
===
match
---
atom_expr [3355,3374]
atom_expr [3355,3374]
===
match
---
suite [23859,24013]
suite [23982,24136]
===
match
---
trailer [4589,4605]
trailer [4589,4605]
===
match
---
fstring_string: Unsure how to deserialize version  [31592,31626]
fstring_string: Unsure how to deserialize version  [31715,31749]
===
match
---
name: encoded_op [18154,18164]
name: encoded_op [18277,18287]
===
match
---
comparison [12051,12067]
comparison [12174,12190]
===
match
---
name: self [15131,15135]
name: self [15254,15258]
===
match
---
name: instances [21702,21711]
name: instances [21825,21834]
===
match
---
return_stmt [9000,9060]
return_stmt [8994,9054]
===
match
---
trailer [15793,15848]
trailer [15916,15971]
===
match
---
operator: = [17020,17021]
operator: = [17143,17144]
===
match
---
trailer [20443,20459]
trailer [20566,20582]
===
match
---
trailer [12587,12604]
trailer [12710,12727]
===
match
---
simple_stmt [8181,8198]
simple_stmt [8181,8198]
===
match
---
name: task_type [15121,15130]
name: task_type [15244,15253]
===
match
---
suite [12155,12272]
suite [12278,12395]
===
match
---
trailer [2864,2866]
trailer [2864,2866]
===
match
---
operator: = [6703,6704]
operator: = [6703,6704]
===
match
---
simple_stmt [27913,27964]
simple_stmt [28036,28087]
===
match
---
operator: = [3632,3633]
operator: = [3632,3633]
===
match
---
name: cls [6040,6043]
name: cls [6040,6043]
===
match
---
operator: -> [6568,6570]
operator: -> [6568,6570]
===
match
---
trailer [11816,11821]
trailer [11939,11944]
===
match
---
annassign [3663,3690]
annassign [3663,3690]
===
match
---
name: self [14376,14380]
name: self [14499,14503]
===
match
---
trailer [30878,30886]
trailer [31001,31009]
===
match
---
operator: @ [26723,26724]
operator: @ [26846,26847]
===
match
---
operator: == [19956,19958]
operator: == [20079,20081]
===
match
---
atom [3688,3690]
atom [3688,3690]
===
match
---
string: "airflow.sensors.external_task_sensor.ExternalTaskSensorLink" [2546,2607]
string: "airflow.sensors.external_task_sensor.ExternalTaskSensorLink" [2546,2607]
===
match
---
funcdef [14363,14906]
funcdef [14486,15029]
===
match
---
name: encoded_op_links [22437,22453]
name: encoded_op_links [22560,22576]
===
match
---
name: var [9451,9454]
name: var [9445,9448]
===
match
---
operator: , [27978,27979]
operator: , [28101,28102]
===
match
---
name: k [19239,19240]
name: k [19362,19363]
===
match
---
operator: } [9317,9318]
operator: } [9311,9312]
===
match
---
trailer [30073,30081]
trailer [30196,30204]
===
match
---
suite [10683,10715]
suite [10806,10838]
===
match
---
operator: = [14607,14608]
operator: = [14730,14731]
===
match
---
name: r [27751,27752]
name: r [27874,27875]
===
match
---
file_input [786,34348]
file_input [786,34471]
===
match
---
suite [16970,17054]
suite [17093,17177]
===
match
---
simple_stmt [1229,1297]
simple_stmt [1229,1297]
===
match
---
trailer [29417,29429]
trailer [29540,29552]
===
match
---
trailer [5273,5286]
trailer [5273,5286]
===
match
---
trailer [26429,26435]
trailer [26552,26558]
===
match
---
name: BaseOperator [32447,32459]
name: BaseOperator [32570,32582]
===
match
---
atom_expr [12237,12256]
atom_expr [12360,12379]
===
match
---
atom_expr [21333,21342]
atom_expr [21456,21465]
===
match
---
return_stmt [2896,2924]
return_stmt [2896,2924]
===
match
---
name: endswith [19315,19323]
name: endswith [19438,19446]
===
match
---
trailer [20092,20094]
trailer [20215,20217]
===
match
---
name: serializable_task [30490,30507]
name: serializable_task [30613,30630]
===
match
---
name: v [19380,19381]
name: v [19503,19504]
===
match
---
name: SERIALIZER_VERSION [3696,3714]
name: SERIALIZER_VERSION [3696,3714]
===
match
---
decorated [21201,21712]
decorated [21324,21835]
===
match
---
trailer [30143,30147]
trailer [30266,30270]
===
match
---
name: encoded_group [34194,34207]
name: encoded_group [34317,34330]
===
match
---
subscriptlist [3769,3810]
subscriptlist [3769,3810]
===
match
---
name: TaskGroup [1903,1912]
name: TaskGroup [1903,1912]
===
match
---
decorated [4349,4607]
decorated [4349,4607]
===
match
---
atom_expr [19697,19757]
atom_expr [19820,19880]
===
match
---
name: isinstance [6316,6326]
name: isinstance [6316,6326]
===
match
---
trailer [6275,6300]
trailer [6275,6300]
===
match
---
operator: -> [15258,15260]
operator: -> [15381,15383]
===
match
---
name: _decorated_fields [15384,15401]
name: _decorated_fields [15507,15524]
===
match
---
name: keys [20259,20263]
name: keys [20382,20386]
===
match
---
string: "ui_color" [33545,33555]
string: "ui_color" [33668,33678]
===
match
---
name: v [18990,18991]
name: v [19113,19114]
===
match
---
simple_stmt [19188,19222]
simple_stmt [19311,19345]
===
match
---
operator: = [9448,9449]
operator: = [9442,9443]
===
match
---
simple_stmt [21291,21309]
simple_stmt [21414,21432]
===
match
---
name: k [9294,9295]
name: k [9288,9289]
===
match
---
atom_expr [15261,15275]
atom_expr [15384,15398]
===
match
---
name: k8s [1980,1983]
name: k8s [1980,1983]
===
match
---
trailer [11955,11966]
trailer [12078,12089]
===
match
---
trailer [33934,33936]
trailer [34057,34059]
===
match
---
funcdef [26095,26564]
funcdef [26218,26687]
===
match
---
funcdef [5714,5855]
funcdef [5714,5855]
===
match
---
name: AirflowException [1260,1276]
name: AirflowException [1260,1276]
===
match
---
name: cls [20034,20037]
name: cls [20157,20160]
===
match
---
trailer [17274,17305]
trailer [17397,17428]
===
match
---
param [15137,15151]
param [15260,15274]
===
match
---
atom_expr [28175,28224]
atom_expr [28298,28347]
===
match
---
tfpdef [20765,20778]
tfpdef [20888,20901]
===
match
---
name: encoded_group [33471,33484]
name: encoded_group [33594,33607]
===
match
---
atom_expr [32584,32611]
atom_expr [32707,32734]
===
match
---
tfpdef [5899,5907]
tfpdef [5899,5907]
===
match
---
suite [8392,8451]
suite [8392,8445]
===
match
---
try_stmt [21514,21687]
try_stmt [21637,21810]
===
match
---
atom_expr [27919,27963]
atom_expr [28042,28086]
===
match
---
name: from_dict [4633,4642]
name: from_dict [4633,4642]
===
match
---
atom_expr [31671,31692]
atom_expr [31794,31815]
===
match
---
trailer [19195,19218]
trailer [19318,19341]
===
match
---
simple_stmt [31063,31144]
simple_stmt [31186,31267]
===
match
---
name: classmethod [27762,27773]
name: classmethod [27885,27896]
===
match
---
name: classmethod [6441,6452]
name: classmethod [6441,6452]
===
match
---
arglist [6902,6932]
arglist [6902,6932]
===
match
---
operator: , [32803,32804]
operator: , [32926,32927]
===
match
---
testlist_comp [30236,30260]
testlist_comp [30359,30383]
===
match
---
name: _decorated_fields [14154,14171]
name: _decorated_fields [14277,14294]
===
match
---
param [17130,17134]
param [17253,17257]
===
match
---
except_clause [21588,21606]
except_clause [21711,21729]
===
match
---
name: dag [30103,30106]
name: dag [30226,30229]
===
match
---
name: encoded_op [20655,20665]
name: encoded_op [20778,20788]
===
match
---
atom_expr [26937,26959]
atom_expr [27060,27082]
===
match
---
param [33079,33083]
param [33202,33206]
===
match
---
name: value [6886,6891]
name: value [6886,6891]
===
match
---
simple_stmt [21624,21687]
simple_stmt [21747,21810]
===
match
---
operator: = [14805,14806]
operator: = [14928,14929]
===
match
---
operator: , [26431,26432]
operator: , [26554,26555]
===
match
---
name: _deserialize_timedelta [19196,19218]
name: _deserialize_timedelta [19319,19341]
===
match
---
trailer [11387,11402]
trailer [11510,11525]
===
match
---
atom_expr [16259,16306]
atom_expr [16382,16429]
===
match
---
name: cls [32838,32841]
name: cls [32961,32964]
===
match
---
parameters [4982,5021]
parameters [4982,5021]
===
match
---
string: """         Serialize Operator Links. Store the import path of the OperatorLink and the arguments         passed to it. Example         ``[{'airflow.providers.google.cloud.operators.bigquery.BigQueryConsoleLink': {}}]``          :param operator_extra_links: Operator Link         :return: Serialized Operator Link         """ [24522,24847]
string: """         Serialize Operator Links. Store the import path of the OperatorLink and the arguments         passed to it. Example         ``[{'airflow.providers.google.cloud.operators.bigquery.BigQueryConsoleLink': {}}]``          :param operator_extra_links: Operator Link         :return: Serialized Operator Link         """ [24645,24970]
===
match
---
trailer [19532,19566]
trailer [19655,19689]
===
match
---
try_stmt [26841,27756]
try_stmt [26964,27879]
===
match
---
name: k [28543,28544]
name: k [28666,28667]
===
match
---
trailer [32390,32393]
trailer [32513,32516]
===
match
---
suite [12285,12361]
suite [12408,12484]
===
match
---
atom_expr [26471,26513]
atom_expr [26594,26636]
===
match
---
operator: , [3959,3960]
operator: , [3959,3960]
===
match
---
trailer [28645,28654]
trailer [28768,28777]
===
match
---
operator: = [32054,32055]
operator: = [32177,32178]
===
match
---
name: field [20528,20533]
name: field [20651,20656]
===
match
---
comp_op [20061,20067]
comp_op [20184,20190]
===
match
---
simple_stmt [1154,1186]
simple_stmt [1154,1186]
===
match
---
comparison [11678,11700]
comparison [11801,11823]
===
match
---
return_stmt [21149,21195]
return_stmt [21272,21318]
===
match
---
exprlist [18901,18905]
exprlist [19024,19028]
===
match
---
trailer [29720,29744]
trailer [29843,29867]
===
match
---
name: str [14948,14951]
name: str [15071,15074]
===
match
---
trailer [17881,17902]
trailer [18004,18025]
===
match
---
simple_stmt [16113,16123]
simple_stmt [16236,16246]
===
match
---
param [15131,15136]
param [15254,15259]
===
match
---
comp_op [30453,30459]
comp_op [30576,30582]
===
match
---
suite [28567,28618]
suite [28690,28741]
===
match
---
name: __module__ [15514,15524]
name: __module__ [15637,15647]
===
match
---
atom_expr [27740,27750]
atom_expr [27863,27873]
===
match
---
simple_stmt [30009,30031]
simple_stmt [30132,30154]
===
match
---
name: POD [8617,8620]
name: POD [8611,8614]
===
match
---
atom_expr [9074,9099]
atom_expr [9068,9093]
===
match
---
suite [8026,8221]
suite [8026,8221]
===
match
---
trailer [22229,22231]
trailer [22352,22354]
===
match
---
trailer [14424,14441]
trailer [14547,14564]
===
match
---
name: var [9191,9194]
name: var [9185,9188]
===
match
---
operator: , [1571,1572]
operator: , [1571,1572]
===
match
---
operator: == [11343,11345]
operator: == [11466,11468]
===
match
---
name: decorated_fields [6540,6556]
name: decorated_fields [6540,6556]
===
match
---
name: airflow [1654,1661]
name: airflow [1654,1661]
===
match
---
suite [21343,21687]
suite [21466,21810]
===
match
---
simple_stmt [1649,1722]
simple_stmt [1649,1722]
===
match
---
if_stmt [11051,12361]
if_stmt [11174,12484]
===
match
---
operator: = [18992,18993]
operator: = [19115,19116]
===
match
---
trailer [20258,20263]
trailer [20381,20386]
===
match
---
name: var [6286,6289]
name: var [6286,6289]
===
match
---
suite [9951,10120]
suite [10080,10243]
===
match
---
name: x [5667,5668]
name: x [5667,5668]
===
match
---
name: bool [3072,3076]
name: bool [3072,3076]
===
match
---
name: weekday [9354,9361]
name: weekday [9348,9355]
===
match
---
operator: , [9942,9943]
operator: , [10071,10072]
===
match
---
name: var [8814,8817]
name: var [8808,8811]
===
match
---
name: lru_cache [1139,1148]
name: lru_cache [1139,1148]
===
match
---
atom_expr [9294,9311]
atom_expr [9288,9305]
===
match
---
simple_stmt [3829,3917]
simple_stmt [3829,3917]
===
match
---
operator: @ [31296,31297]
operator: @ [31419,31420]
===
match
---
operator: , [33115,33116]
operator: , [33238,33239]
===
match
---
atom_expr [8951,8986]
atom_expr [8945,8980]
===
match
---
return_stmt [26391,26563]
return_stmt [26514,26686]
===
match
---
atom_expr [15380,15401]
atom_expr [15503,15524]
===
match
---
arglist [31489,31517]
arglist [31612,31640]
===
match
---
atom_expr [17443,17462]
atom_expr [17566,17585]
===
match
---
expr_stmt [33426,33580]
expr_stmt [33549,33703]
===
match
---
name: plugins_manager [22244,22259]
name: plugins_manager [22367,22382]
===
match
---
name: task_type [15137,15146]
name: task_type [15260,15269]
===
match
---
suite [11895,11984]
suite [12018,12107]
===
match
---
for_stmt [22407,24358]
for_stmt [22530,24481]
===
match
---
suite [18083,18355]
suite [18206,18478]
===
match
---
atom_expr [33903,33936]
atom_expr [34026,34059]
===
match
---
name: task_type [15096,15105]
name: task_type [15219,15228]
===
match
---
name: json [4579,4583]
name: json [4579,4583]
===
match
---
suite [10867,10959]
suite [10990,11082]
===
match
---
name: serialize_dag [8690,8703]
name: serialize_dag [8684,8697]
===
match
---
name: _CONSTRUCTOR_PARAMS [13710,13729]
name: _CONSTRUCTOR_PARAMS [13833,13852]
===
match
---
name: type [10303,10307]
name: type [10426,10430]
===
match
---
expr_stmt [11912,11967]
expr_stmt [12035,12090]
===
match
---
operator: , [30398,30399]
operator: , [30521,30522]
===
match
---
tfpdef [4019,4072]
tfpdef [4019,4072]
===
match
---
name: k [19313,19314]
name: k [19436,19437]
===
match
---
name: task_id [17275,17282]
name: task_id [17398,17405]
===
match
---
atom_expr [28227,28257]
atom_expr [28350,28380]
===
match
---
trailer [18925,18927]
trailer [19048,19050]
===
match
---
trailer [32852,32888]
trailer [32975,33011]
===
match
---
name: ValueError [10886,10896]
name: ValueError [11009,11019]
===
match
---
operator: , [26277,26278]
operator: , [26400,26401]
===
match
---
name: task [30095,30099]
name: task [30218,30222]
===
match
---
atom [30235,30261]
atom [30358,30384]
===
match
---
name: items [23600,23605]
name: items [23723,23728]
===
match
---
trailer [8191,8197]
trailer [8191,8197]
===
match
---
operator: { [24299,24300]
operator: { [24422,24423]
===
match
---
if_stmt [7038,7349]
if_stmt [7038,7349]
===
match
---
param [3758,3811]
param [3758,3811]
===
match
---
operator: -> [12688,12690]
operator: -> [12811,12813]
===
match
---
simple_stmt [27210,27253]
simple_stmt [27333,27376]
===
match
---
simple_stmt [17247,17306]
simple_stmt [17370,17429]
===
match
---
simple_stmt [2067,2089]
simple_stmt [2067,2089]
===
match
---
string: "Dep class %r not registered" [21435,21464]
string: "Dep class %r not registered" [21558,21587]
===
match
---
string: "upstream_group_ids" [32639,32659]
string: "upstream_group_ids" [32762,32782]
===
match
---
atom_expr [30428,30452]
atom_expr [30551,30575]
===
match
---
fstring_string:  is not set. [5197,5209]
fstring_string:  is not set. [5197,5209]
===
match
---
name: qualname [21321,21329]
name: qualname [21444,21452]
===
match
---
name: var [6411,6414]
name: var [6411,6414]
===
match
---
name: Iterable [953,961]
name: Iterable [953,961]
===
match
---
simple_stmt [30974,31055]
simple_stmt [31097,31178]
===
match
---
operator: @ [6440,6441]
operator: @ [6440,6441]
===
match
---
trailer [9361,9363]
trailer [9355,9357]
===
match
---
name: ui_fgcolor [14739,14749]
name: ui_fgcolor [14862,14872]
===
match
---
simple_stmt [2113,2136]
simple_stmt [2113,2136]
===
match
---
atom_expr [23723,23763]
atom_expr [23846,23886]
===
match
---
name: k [11120,11121]
name: k [11243,11244]
===
match
---
operator: -> [14945,14947]
operator: -> [15068,15070]
===
match
---
string: """Deserializes an operator from a JSON object.""" [17188,17238]
string: """Deserializes an operator from a JSON object.""" [17311,17361]
===
match
---
name: cls [12237,12240]
name: cls [12360,12363]
===
match
---
atom_expr [29459,29468]
atom_expr [29582,29591]
===
match
---
trailer [11636,11641]
trailer [11759,11764]
===
match
---
comparison [12754,12789]
comparison [12877,12912]
===
match
---
parameters [33069,33215]
parameters [33192,33338]
===
match
---
simple_stmt [9533,9576]
simple_stmt [9527,9570]
===
match
---
if_stmt [27468,27564]
if_stmt [27591,27687]
===
match
---
string: "upstream_task_ids" [32817,32836]
string: "upstream_task_ids" [32940,32959]
===
match
---
name: cls [3943,3946]
name: cls [3943,3946]
===
match
---
atom_expr [18133,18150]
atom_expr [18256,18273]
===
match
---
atom_expr [33681,33695]
atom_expr [33804,33818]
===
match
---
name: to_json [3745,3752]
name: to_json [3745,3752]
===
match
---
operator: -> [21801,21803]
operator: -> [21924,21926]
===
match
---
suite [12068,12123]
suite [12191,12246]
===
match
---
name: DAT [9906,9909]
name: DAT [9921,9924]
===
match
---
trailer [32944,32976]
trailer [33067,33099]
===
match
---
trailer [15639,15668]
trailer [15762,15791]
===
match
---
operator: @ [5697,5698]
operator: @ [5697,5698]
===
match
---
atom_expr [8003,8025]
atom_expr [8003,8025]
===
match
---
operator: , [8151,8152]
operator: , [8151,8152]
===
match
---
name: cls [31089,31092]
name: cls [31212,31215]
===
match
---
operator: = [10971,10972]
operator: = [11094,11095]
===
match
---
name: timezone [12454,12462]
name: timezone [12577,12585]
===
match
---
trailer [32486,32497]
trailer [32609,32620]
===
match
---
trailer [14819,14835]
trailer [14942,14958]
===
match
---
name: module_loading [1830,1844]
name: module_loading [1830,1844]
===
match
---
name: BaseOperator [15876,15888]
name: BaseOperator [15999,16011]
===
match
---
param [20780,20796]
param [20903,20919]
===
match
---
atom_expr [9120,9166]
atom_expr [9114,9160]
===
match
---
trailer [34193,34229]
trailer [34316,34352]
===
match
---
trailer [11433,11437]
trailer [11556,11560]
===
match
---
name: module_name [16568,16579]
name: module_name [16691,16702]
===
match
---
trailer [11508,11582]
trailer [11631,11705]
===
match
---
trailer [33616,33672]
trailer [33739,33795]
===
match
---
name: pendulum [12390,12398]
name: pendulum [12513,12521]
===
match
---
name: task_group [27110,27120]
name: task_group [27233,27243]
===
match
---
string: "_" [9307,9310]
string: "_" [9301,9304]
===
match
---
atom_expr [31651,31693]
atom_expr [31774,31816]
===
match
---
name: tuple [9944,9949]
name: tuple [10073,10078]
===
match
---
atom_expr [20034,20055]
atom_expr [20157,20178]
===
match
---
operator: = [3064,3065]
operator: = [3064,3065]
===
match
---
name: var [10967,10970]
name: var [11090,11093]
===
match
---
name: TaskGroup [10149,10158]
name: TaskGroup [10272,10281]
===
match
---
name: BaseOperator [15244,15256]
name: BaseOperator [15367,15379]
===
match
---
atom_expr [21038,21044]
atom_expr [21161,21167]
===
match
---
name: Any [6667,6670]
name: Any [6667,6670]
===
match
---
simple_stmt [26858,26924]
simple_stmt [26981,27047]
===
match
---
operator: @ [3985,3986]
operator: @ [3985,3986]
===
match
---
atom_expr [14274,14295]
atom_expr [14397,14418]
===
match
---
arglist [9085,9098]
arglist [9079,9092]
===
match
---
for_stmt [20428,20541]
for_stmt [20551,20664]
===
match
---
name: setattr [20625,20632]
name: setattr [20748,20755]
===
match
---
name: attrname [20765,20773]
name: attrname [20888,20896]
===
match
---
name: template_field [16807,16821]
name: template_field [16930,16944]
===
match
---
if_stmt [17863,17975]
if_stmt [17986,18098]
===
match
---
name: serialize_task_group [32519,32539]
name: serialize_task_group [32642,32662]
===
match
---
atom_expr [9867,9884]
atom_expr [9882,9899]
===
match
---
param [12844,12848]
param [12967,12971]
===
match
---
trailer [28230,28257]
trailer [28353,28380]
===
match
---
comparison [13795,13812]
comparison [13918,13935]
===
match
---
name: serializable_task [30428,30445]
name: serializable_task [30551,30568]
===
match
---
name: str [33190,33193]
name: str [33313,33316]
===
match
---
name: list [32765,32769]
name: list [32888,32892]
===
match
---
operator: , [15378,15379]
operator: , [15501,15502]
===
match
---
name: _primitive_types [5837,5853]
name: _primitive_types [5837,5853]
===
match
---
trailer [9278,9284]
trailer [9272,9278]
===
match
---
atom [3195,3215]
atom [3195,3215]
===
match
---
operator: , [951,952]
operator: , [951,952]
===
match
---
name: date_attr [30222,30231]
name: date_attr [30345,30354]
===
match
---
decorated [15095,15190]
decorated [15218,15313]
===
match
---
name: DAT [11844,11847]
name: DAT [11967,11970]
===
match
---
name: v [14234,14235]
name: v [14357,14358]
===
match
---
name: v [12261,12262]
name: v [12384,12385]
===
match
---
simple_stmt [9841,9915]
simple_stmt [9856,9930]
===
match
---
atom_expr [11191,11225]
atom_expr [11314,11348]
===
match
---
operator: , [20193,20194]
operator: , [20316,20317]
===
match
---
trailer [15442,15452]
trailer [15565,15575]
===
match
---
suite [23683,23764]
suite [23806,23887]
===
match
---
name: airflow [1457,1464]
name: airflow [1457,1464]
===
match
---
trailer [33227,33238]
trailer [33350,33361]
===
match
---
trailer [29504,29510]
trailer [29627,29633]
===
match
---
atom_expr [32395,32408]
atom_expr [32518,32531]
===
match
---
name: BaseSerialization [13915,13932]
name: BaseSerialization [14038,14055]
===
match
---
trailer [15503,15513]
trailer [15626,15636]
===
match
---
name: k [20195,20196]
name: k [20318,20319]
===
match
---
operator: -> [21262,21264]
operator: -> [21385,21387]
===
match
---
simple_stmt [4901,4941]
simple_stmt [4901,4941]
===
match
---
import_from [1065,1092]
import_from [1065,1092]
===
match
---
operator: = [11927,11928]
operator: = [12050,12051]
===
match
---
operator: , [32198,32199]
operator: , [32321,32322]
===
match
---
string: "upstream_task_ids" [34208,34227]
string: "upstream_task_ids" [34331,34350]
===
match
---
name: dict [8250,8254]
name: dict [8250,8254]
===
match
---
name: has_on_failure_callback [27475,27498]
name: has_on_failure_callback [27598,27621]
===
match
---
name: dag [30017,30020]
name: dag [30140,30143]
===
match
---
name: dag [26896,26899]
name: dag [27019,27022]
===
match
---
import_from [867,907]
import_from [867,907]
===
match
---
trailer [5827,5854]
trailer [5827,5854]
===
match
---
operator: { [28548,28549]
operator: { [28671,28672]
===
match
---
operator: , [9088,9089]
operator: , [9082,9083]
===
match
---
name: cls [28588,28591]
name: cls [28711,28714]
===
match
---
trailer [9306,9311]
trailer [9300,9305]
===
match
---
name: Set [6558,6561]
name: Set [6558,6561]
===
match
---
name: SerializedBaseOperator [13878,13900]
name: SerializedBaseOperator [14001,14023]
===
match
---
string: "_task_group" [29191,29204]
string: "_task_group" [29314,29327]
===
match
---
name: connection [1388,1398]
name: connection [1388,1398]
===
match
---
import_from [1811,1865]
import_from [1811,1865]
===
match
---
raise_stmt [17928,17974]
raise_stmt [18051,18097]
===
match
---
or_test [13748,13813]
or_test [13871,13936]
===
match
---
funcdef [26740,27756]
funcdef [26863,27879]
===
match
---
simple_stmt [26790,26833]
simple_stmt [26913,26956]
===
match
---
name: set [28070,28073]
name: set [28193,28196]
===
match
---
name: classmethod [4350,4361]
name: classmethod [4350,4361]
===
match
---
operator: = [26589,26590]
operator: = [26712,26713]
===
match
---
string: 'concurrency' [26205,26218]
string: 'concurrency' [26328,26341]
===
match
---
atom [22395,22397]
atom [22518,22520]
===
match
---
simple_stmt [5764,5787]
simple_stmt [5764,5787]
===
match
---
atom_expr [27034,27062]
atom_expr [27157,27185]
===
match
---
simple_stmt [29817,29852]
simple_stmt [29940,29975]
===
match
---
name: timedelta [8976,8985]
name: timedelta [8970,8979]
===
match
---
string: '<not present>' [31502,31517]
string: '<not present>' [31625,31640]
===
match
---
if_stmt [10830,10959]
if_stmt [10953,11082]
===
match
---
param [6493,6539]
param [6493,6539]
===
match
---
operator: , [3792,3793]
operator: , [3792,3793]
===
match
---
operator: , [32335,32336]
operator: , [32458,32459]
===
match
---
name: set [33982,33985]
name: set [34105,34108]
===
match
---
name: v [19188,19189]
name: v [19311,19312]
===
match
---
name: _deserialize [12093,12105]
name: _deserialize [12216,12228]
===
match
---
name: cls [9867,9870]
name: cls [9882,9885]
===
match
---
funcdef [6457,7382]
funcdef [6457,7382]
===
match
---
operator: , [20763,20764]
operator: , [20886,20887]
===
match
---
name: TUPLE [12149,12154]
name: TUPLE [12272,12277]
===
match
---
name: key [33449,33452]
name: key [33572,33575]
===
match
---
name: op [15861,15863]
name: op [15984,15986]
===
match
---
fstring_string: JSON schema of  [5166,5181]
fstring_string: JSON schema of  [5166,5181]
===
match
---
name: v [9316,9317]
name: v [9310,9311]
===
match
---
name: v [8312,8313]
name: v [8312,8313]
===
match
---
name: SerializedTaskGroup [31702,31721]
name: SerializedTaskGroup [31825,31844]
===
match
---
suite [6020,6301]
suite [6020,6301]
===
match
---
name: TYPE [5679,5683]
name: TYPE [5679,5683]
===
match
---
operator: , [27801,27802]
operator: , [27924,27925]
===
match
---
name: Dict [17147,17151]
name: Dict [17270,17274]
===
match
---
trailer [2847,2891]
trailer [2847,2891]
===
match
---
trailer [30507,30514]
trailer [30630,30637]
===
match
---
comparison [7041,7064]
comparison [7041,7064]
===
match
---
atom_expr [34288,34324]
atom_expr [34411,34447]
===
match
---
expr_stmt [10967,10998]
expr_stmt [11090,11121]
===
match
---
trailer [14235,14243]
trailer [14358,14366]
===
match
---
name: _encode [5543,5550]
name: _encode [5543,5550]
===
match
---
name: ProvidersManager [1490,1506]
name: ProvidersManager [1490,1506]
===
match
---
atom_expr [20441,20459]
atom_expr [20564,20582]
===
match
---
suite [19966,20012]
suite [20089,20135]
===
match
---
atom_expr [30621,30658]
atom_expr [30744,30781]
===
match
---
name: __init__ [26485,26493]
name: __init__ [26608,26616]
===
match
---
operator: ** [14432,14434]
operator: ** [14555,14557]
===
match
---
comparison [11337,11358]
comparison [11460,11481]
===
match
---
name: _deserialize_timezone [28501,28522]
name: _deserialize_timezone [28624,28645]
===
match
---
string: """Types excluded from serialization.""" [5956,5996]
string: """Types excluded from serialization.""" [5956,5996]
===
match
---
string: '_dag_id' [27952,27961]
string: '_dag_id' [28075,28084]
===
match
---
name: TYPE [11036,11040]
name: TYPE [11159,11163]
===
match
---
argument [1172,1184]
argument [1172,1184]
===
match
---
number: 0 [23609,23610]
number: 0 [23732,23733]
===
match
---
trailer [8380,8391]
trailer [8380,8391]
===
match
---
atom_expr [30103,30125]
atom_expr [30226,30248]
===
match
---
simple_stmt [14734,14776]
simple_stmt [14857,14899]
===
match
---
decorator [15095,15113]
decorator [15218,15236]
===
match
---
arglist [25050,25073]
arglist [25173,25196]
===
match
---
operator: , [33893,33894]
operator: , [34016,34017]
===
match
---
for_stmt [16135,16600]
for_stmt [16258,16723]
===
match
---
name: Encoding [4678,4686]
name: Encoding [4678,4686]
===
match
---
name: serialize_op [15470,15482]
name: serialize_op [15593,15605]
===
match
---
trailer [34270,34326]
trailer [34393,34449]
===
match
---
atom_expr [34194,34228]
atom_expr [34317,34351]
===
match
---
operator: , [4434,4435]
operator: , [4434,4435]
===
match
---
expr_stmt [28584,28617]
expr_stmt [28707,28740]
===
match
---
simple_stmt [9113,9167]
simple_stmt [9107,9161]
===
match
---
simple_stmt [33589,33673]
simple_stmt [33712,33796]
===
match
---
trailer [3768,3811]
trailer [3768,3811]
===
match
---
simple_stmt [12223,12272]
simple_stmt [12346,12395]
===
match
---
atom [14221,14357]
atom [14344,14480]
===
match
---
name: key [33507,33510]
name: key [33630,33633]
===
match
---
trailer [31898,31921]
trailer [32021,32044]
===
match
---
name: Any [5554,5557]
name: Any [5554,5557]
===
match
---
atom_expr [15501,15524]
atom_expr [15624,15647]
===
match
---
simple_stmt [14784,14836]
simple_stmt [14907,14959]
===
match
---
raise_stmt [10880,10958]
raise_stmt [11003,11081]
===
match
---
name: is_subdag [30576,30585]
name: is_subdag [30699,30708]
===
match
---
atom_expr [24209,24252]
atom_expr [24332,24375]
===
match
---
name: cls [34177,34180]
name: cls [34300,34303]
===
match
---
name: type_ [11835,11840]
name: type_ [11958,11963]
===
match
---
operator: -> [31354,31356]
operator: -> [31477,31479]
===
match
---
name: _operator_link_class_path [23969,23994]
name: _operator_link_class_path [24092,24117]
===
match
---
name: Encoding [11027,11035]
name: Encoding [11150,11158]
===
match
---
name: dag [27740,27743]
name: dag [27863,27866]
===
match
---
trailer [11204,11220]
trailer [11327,11343]
===
match
---
simple_stmt [14154,14194]
simple_stmt [14277,14317]
===
match
---
atom_expr [15681,15704]
atom_expr [15804,15827]
===
match
---
name: dag [29817,29820]
name: dag [29940,29943]
===
match
---
name: deserialize_operator [17109,17129]
name: deserialize_operator [17232,17252]
===
match
---
name: isinstance [8722,8732]
name: isinstance [8716,8726]
===
match
---
or_test [21077,21111]
or_test [21200,21234]
===
match
---
name: TIMEZONE [9157,9165]
name: TIMEZONE [9151,9159]
===
match
---
name: parameters [26495,26505]
name: parameters [26618,26628]
===
match
---
string: "_is_dummy" [20670,20681]
string: "_is_dummy" [20793,20804]
===
match
---
name: attrname [6276,6284]
name: attrname [6276,6284]
===
match
---
name: __func__ [26618,26626]
name: __func__ [26741,26749]
===
match
---
atom_expr [30861,30886]
atom_expr [30984,31009]
===
match
---
name: group_id [33362,33370]
name: group_id [33485,33493]
===
match
---
name: _serialize [32665,32675]
name: _serialize [32788,32798]
===
match
---
expr_stmt [14688,14725]
expr_stmt [14811,14848]
===
match
---
operator: = [24207,24208]
operator: = [24330,24331]
===
match
---
trailer [27047,27062]
trailer [27170,27185]
===
match
---
name: encoded_dag [29179,29190]
name: encoded_dag [29302,29313]
===
match
---
name: get [31485,31488]
name: get [31608,31611]
===
match
---
name: ImportError [2096,2107]
name: ImportError [2096,2107]
===
match
---
simple_stmt [31644,31694]
simple_stmt [31767,31817]
===
match
---
atom_expr [16219,16235]
atom_expr [16342,16358]
===
match
---
name: datetime [12534,12542]
name: datetime [12657,12665]
===
match
---
operator: , [4053,4054]
operator: , [4053,4054]
===
match
---
trailer [14738,14749]
trailer [14861,14872]
===
match
---
name: __module__ [16225,16235]
name: __module__ [16348,16358]
===
match
---
operator: , [21660,21661]
operator: , [21783,21784]
===
match
---
argument [33663,33671]
argument [33786,33794]
===
match
---
simple_stmt [31274,31291]
simple_stmt [31397,31414]
===
match
---
sync_comp_for [32564,32611]
sync_comp_for [32687,32734]
===
match
---
if_stmt [11875,11984]
if_stmt [11998,12107]
===
match
---
dictorsetmaker [33449,33570]
dictorsetmaker [33572,33693]
===
match
---
name: cls [8889,8892]
name: cls [8883,8886]
===
match
---
atom_expr [26529,26538]
atom_expr [26652,26661]
===
match
---
comparison [20059,20094]
comparison [20182,20217]
===
match
---
and_test [20810,20873]
and_test [20933,20996]
===
match
---
operator: , [4047,4048]
operator: , [4047,4048]
===
match
---
trailer [18876,18883]
trailer [18999,19006]
===
match
---
operator: = [11013,11014]
operator: = [11136,11137]
===
match
---
name: cls [17656,17659]
name: cls [17779,17782]
===
match
---
atom_expr [25286,25324]
atom_expr [25409,25447]
===
match
---
name: _deserialize [10417,10429]
name: _deserialize [10540,10552]
===
match
---
name: BaseOperatorLink [1351,1367]
name: BaseOperatorLink [1351,1367]
===
match
---
operator: -> [33216,33218]
operator: -> [33339,33341]
===
match
---
return_stmt [24141,24150]
return_stmt [24264,24273]
===
match
---
name: cls [12512,12515]
name: cls [12635,12638]
===
match
---
suite [17729,18888]
suite [17852,19011]
===
match
---
atom_expr [8772,8818]
atom_expr [8766,8812]
===
match
---
trailer [5295,5311]
trailer [5295,5311]
===
match
---
trailer [11349,11358]
trailer [11472,11481]
===
match
---
operator: = [3299,3300]
operator: = [3299,3300]
===
match
---
name: items [8331,8336]
name: items [8331,8336]
===
match
---
name: value [7252,7257]
name: value [7252,7257]
===
match
---
trailer [25218,25346]
trailer [25341,25469]
===
match
---
name: setattr [28943,28950]
name: setattr [29066,29073]
===
match
---
suite [8256,8357]
suite [8256,8357]
===
match
---
name: set [34078,34081]
name: set [34201,34204]
===
match
---
operator: , [21243,21244]
operator: , [21366,21367]
===
match
---
operator: = [19850,19851]
operator: = [19973,19974]
===
match
---
name: op [16399,16401]
name: op [16522,16524]
===
match
---
name: _task_type [14596,14606]
name: _task_type [14719,14729]
===
match
---
exprlist [26463,26467]
exprlist [26586,26590]
===
match
---
arglist [21038,21060]
arglist [21161,21183]
===
match
---
atom_expr [6705,6748]
atom_expr [6705,6748]
===
match
---
string: """Deserializes a DAG from a JSON object.""" [27860,27904]
string: """Deserializes a DAG from a JSON object.""" [27983,28027]
===
match
---
atom_expr [31089,31111]
atom_expr [31212,31234]
===
match
---
name: tasks [29463,29468]
name: tasks [29586,29591]
===
match
---
name: keys [29955,29959]
name: keys [30078,30082]
===
match
---
name: var [8217,8220]
name: var [8217,8220]
===
match
---
and_test [13694,13823]
and_test [13817,13946]
===
match
---
trailer [15078,15089]
trailer [15201,15212]
===
match
---
name: single_op_link_class [23876,23896]
name: single_op_link_class [23999,24019]
===
match
---
return_stmt [11372,11407]
return_stmt [11495,11530]
===
match
---
trailer [16148,16153]
trailer [16271,16276]
===
match
---
atom_expr [26437,26446]
atom_expr [26560,26569]
===
match
---
operator: , [20778,20779]
operator: , [20901,20902]
===
match
---
trailer [34152,34170]
trailer [34275,34293]
===
match
---
name: cls [31651,31654]
name: cls [31774,31777]
===
match
---
atom [9450,9486]
atom [9444,9480]
===
match
---
name: op_predefined_extra_links [24266,24291]
name: op_predefined_extra_links [24389,24414]
===
match
---
name: op [15501,15503]
name: op [15624,15626]
===
match
---
name: cls [4908,4911]
name: cls [4908,4911]
===
match
---
import_from [1582,1648]
import_from [1582,1648]
===
match
---
name: str [3670,3673]
name: str [3670,3673]
===
match
---
name: task_dict [27003,27012]
name: task_dict [27126,27135]
===
match
---
trailer [6387,6434]
trailer [6387,6434]
===
match
---
operator: , [10147,10148]
operator: , [10270,10271]
===
match
---
atom_expr [20847,20873]
atom_expr [20970,20996]
===
match
---
operator: , [33844,33845]
operator: , [33967,33968]
===
match
---
operator: , [32888,32889]
operator: , [33011,33012]
===
match
---
operator: = [16633,16634]
operator: = [16756,16757]
===
match
---
name: signature [898,907]
name: signature [898,907]
===
match
---
name: pendulum [11379,11387]
name: pendulum [11502,11510]
===
match
---
atom_expr [10728,10757]
atom_expr [10851,10880]
===
match
---
simple_stmt [11654,11665]
simple_stmt [11777,11788]
===
match
---
operator: { [32056,32057]
operator: { [32179,32180]
===
match
---
suite [7258,7302]
suite [7258,7302]
===
match
---
atom_expr [33390,33416]
atom_expr [33513,33539]
===
match
---
subscriptlist [17152,17160]
subscriptlist [17275,17283]
===
match
---
name: deps [21337,21341]
name: deps [21460,21464]
===
match
---
atom [16120,16122]
atom [16243,16245]
===
match
---
atom_expr [34239,34264]
atom_expr [34362,34387]
===
match
---
name: deps [21245,21249]
name: deps [21368,21372]
===
match
---
name: models [1310,1316]
name: models [1310,1316]
===
match
---
expr_stmt [29390,29434]
expr_stmt [29513,29557]
===
match
---
name: list [19852,19856]
name: list [19975,19979]
===
match
---
name: TUPLE [10113,10118]
name: TUPLE [10236,10241]
===
match
---
trailer [28522,28525]
trailer [28645,28648]
===
match
---
name: dag [29085,29088]
name: dag [29208,29211]
===
match
---
atom_expr [15861,15868]
atom_expr [15984,15991]
===
match
---
atom_expr [26999,27020]
atom_expr [27122,27143]
===
match
---
funcdef [30930,31291]
funcdef [31053,31414]
===
match
---
operator: = [9152,9153]
operator: = [9146,9147]
===
match
---
trailer [32182,32198]
trailer [32305,32321]
===
match
---
name: PodGenerator [2033,2045]
name: PodGenerator [2033,2045]
===
match
---
simple_stmt [33426,33581]
simple_stmt [33549,33704]
===
match
---
trailer [10993,10997]
trailer [11116,11120]
===
match
---
operator: , [4440,4441]
operator: , [4440,4441]
===
match
---
name: cls [8585,8588]
name: cls [8579,8582]
===
match
---
operator: , [4383,4384]
operator: , [4383,4384]
===
match
---
simple_stmt [28175,28258]
simple_stmt [28298,28381]
===
match
---
dictorsetmaker [32379,32611]
dictorsetmaker [32502,32734]
===
match
---
name: Any [17157,17160]
name: Any [17280,17283]
===
match
---
name: task_group [32681,32691]
name: task_group [32804,32814]
===
match
---
name: list [32853,32857]
name: list [32976,32980]
===
match
---
trailer [5836,5853]
trailer [5836,5853]
===
match
---
trailer [28614,28617]
trailer [28737,28740]
===
match
---
suite [18928,20201]
suite [19051,20324]
===
match
---
name: _operator_link_class_path [23781,23806]
name: _operator_link_class_path [23904,23929]
===
match
---
trailer [4341,4343]
trailer [4341,4343]
===
match
---
import_from [1988,2045]
import_from [1988,2045]
===
match
---
name: airflow [1761,1768]
name: airflow [1761,1768]
===
match
---
name: items [33929,33934]
name: items [34052,34057]
===
match
---
trailer [21161,21163]
trailer [21284,21286]
===
match
---
trailer [2840,2847]
trailer [2840,2847]
===
match
---
name: setattr [30482,30489]
name: setattr [30605,30612]
===
match
---
simple_stmt [16328,16536]
simple_stmt [16451,16659]
===
match
---
atom_expr [10133,10159]
atom_expr [10256,10282]
===
match
---
arglist [25467,25489]
arglist [25590,25612]
===
match
---
name: _operator_links_source [23577,23599]
name: _operator_links_source [23700,23722]
===
match
---
name: upstream_task_ids [32869,32886]
name: upstream_task_ids [32992,33009]
===
match
---
name: type_ [11766,11771]
name: type_ [11889,11894]
===
match
---
trailer [26904,26922]
trailer [27027,27045]
===
match
---
operator: } [26381,26382]
operator: } [26504,26505]
===
match
---
name: _value_is_hardcoded_default [6360,6387]
name: _value_is_hardcoded_default [6360,6387]
===
match
---
name: dict [30960,30964]
name: dict [31083,31087]
===
match
---
suite [5947,6435]
suite [5947,6435]
===
match
---
import_from [1940,1983]
import_from [1940,1983]
===
match
---
trailer [27951,27962]
trailer [28074,28085]
===
match
---
suite [32004,32029]
suite [32127,32152]
===
match
---
trailer [12450,12453]
trailer [12573,12576]
===
match
---
name: Any [20760,20763]
name: Any [20883,20886]
===
match
---
name: Any [5742,5745]
name: Any [5742,5745]
===
match
---
atom_expr [19192,19221]
atom_expr [19315,19344]
===
match
---
name: _encode [9852,9859]
name: _encode [9867,9874]
===
match
---
atom_expr [6571,6585]
atom_expr [6571,6585]
===
match
---
name: serialize_dag [27408,27421]
name: serialize_dag [27531,27544]
===
match
---
operator: = [7341,7342]
operator: = [7341,7342]
===
match
---
trailer [5386,5395]
trailer [5386,5395]
===
match
---
trailer [8422,8433]
trailer [8416,8427]
===
match
---
atom_expr [2848,2890]
atom_expr [2848,2890]
===
match
---
name: cls [32750,32753]
name: cls [32873,32876]
===
match
---
string: '_is_dummy' [15622,15633]
string: '_is_dummy' [15745,15756]
===
match
---
atom_expr [26901,26922]
atom_expr [27024,27045]
===
match
---
atom_expr [30009,30030]
atom_expr [30132,30153]
===
match
---
name: DAT [32483,32486]
name: DAT [32606,32609]
===
match
---
atom_expr [10938,10955]
atom_expr [11061,11078]
===
match
---
operator: , [19150,19151]
operator: , [19273,19274]
===
match
---
operator: , [945,946]
operator: , [945,946]
===
match
---
operator: -> [7483,7485]
operator: -> [7483,7485]
===
match
---
name: SerializedBaseOperator [11275,11297]
name: SerializedBaseOperator [11398,11420]
===
match
---
name: data [24225,24229]
name: data [24348,24352]
===
match
---
operator: = [26698,26699]
operator: = [26821,26822]
===
match
---
operator: -> [4406,4408]
operator: -> [4406,4408]
===
match
---
name: AirflowException [5147,5163]
name: AirflowException [5147,5163]
===
match
---
comparison [28722,28738]
comparison [28845,28861]
===
match
---
atom_expr [34099,34136]
atom_expr [34222,34259]
===
match
---
atom_expr [11496,11582]
atom_expr [11619,11705]
===
match
---
simple_stmt [8669,8709]
simple_stmt [8663,8703]
===
match
---
operator: , [20635,20636]
operator: , [20758,20759]
===
match
---
name: encoded_dag [27940,27951]
name: encoded_dag [28063,28074]
===
match
---
parameters [20749,20797]
parameters [20872,20920]
===
match
---
atom_expr [27516,27556]
atom_expr [27639,27679]
===
match
---
atom_expr [33471,33489]
atom_expr [33594,33612]
===
match
---
name: setter [15106,15112]
name: setter [15229,15235]
===
match
---
atom_expr [8832,8868]
atom_expr [8826,8862]
===
match
---
trailer [20319,20332]
trailer [20442,20455]
===
match
---
operator: , [26322,26323]
operator: , [26445,26446]
===
match
---
name: value [8192,8197]
name: value [8192,8197]
===
match
---
trailer [33960,33979]
trailer [34083,34102]
===
match
---
name: isinstance [9729,9739]
name: isinstance [9723,9733]
===
match
---
trailer [27820,27830]
trailer [27943,27953]
===
match
---
operator: , [33164,33165]
operator: , [33287,33288]
===
match
---
suite [4753,4941]
suite [4753,4941]
===
match
---
expr_stmt [28427,28442]
expr_stmt [28550,28565]
===
match
---
operator: , [25284,25285]
operator: , [25407,25408]
===
match
---
name: _operator_link_class_path [23538,23563]
name: _operator_link_class_path [23661,23686]
===
match
---
expr_stmt [2113,2135]
expr_stmt [2113,2135]
===
match
---
trailer [22188,22229]
trailer [22311,22352]
===
match
---
operator: = [12440,12441]
operator: = [12563,12564]
===
match
---
atom_expr [27694,27755]
atom_expr [27817,27878]
===
match
---
trailer [34287,34325]
trailer [34410,34448]
===
match
---
atom [13794,13813]
atom [13917,13936]
===
match
---
name: serialize_dag [27583,27596]
name: serialize_dag [27706,27719]
===
match
---
operator: , [2404,2405]
operator: , [2404,2405]
===
match
---
name: task_id [30829,30836]
name: task_id [30952,30959]
===
match
---
name: cls [19192,19195]
name: cls [19315,19318]
===
match
---
return_stmt [3925,3979]
return_stmt [3925,3979]
===
match
---
subscriptlist [4678,4691]
subscriptlist [4678,4691]
===
match
---
trailer [31589,31635]
trailer [31712,31758]
===
match
---
not_test [6036,6085]
not_test [6036,6085]
===
match
---
name: upstream_task_ids [34153,34170]
name: upstream_task_ids [34276,34293]
===
match
---
atom_expr [12060,12067]
atom_expr [12183,12190]
===
match
---
string: '_concurrency' [26220,26234]
string: '_concurrency' [26343,26357]
===
match
---
name: TaskGroup [29408,29417]
name: TaskGroup [29531,29540]
===
match
---
name: items [18920,18925]
name: items [19043,19048]
===
match
---
expr_stmt [27913,27963]
expr_stmt [28036,28086]
===
match
---
name: cls [21772,21775]
name: cls [21895,21898]
===
match
---
operator: , [15135,15136]
operator: , [15258,15259]
===
match
---
name: Any [27826,27829]
name: Any [27949,27952]
===
match
---
param [6488,6492]
param [6488,6492]
===
match
---
param [31859,31863]
param [31982,31986]
===
match
---
trailer [21434,21475]
trailer [21557,21598]
===
match
---
testlist_comp [13805,13811]
testlist_comp [13928,13934]
===
match
---
tfpdef [6540,6561]
tfpdef [6540,6561]
===
match
---
param [5737,5745]
param [5737,5745]
===
match
---
name: cattr [24981,24986]
name: cattr [25104,25109]
===
match
---
name: set [4061,4064]
name: set [4061,4064]
===
match
---
trailer [21336,21342]
trailer [21459,21465]
===
match
---
name: k [28722,28723]
name: k [28845,28846]
===
match
---
trailer [31670,31693]
trailer [31793,31816]
===
match
---
if_stmt [18942,20136]
if_stmt [19065,20259]
===
match
---
string: '_task_module' [15483,15497]
string: '_task_module' [15606,15620]
===
match
---
trailer [10073,10084]
trailer [9999,10010]
===
match
---
atom_expr [27210,27236]
atom_expr [27333,27359]
===
match
---
name: self [14844,14848]
name: self [14967,14971]
===
match
---
expr_stmt [15718,15848]
expr_stmt [15841,15971]
===
match
---
name: operator_extra_links [24463,24483]
name: operator_extra_links [24586,24606]
===
match
---
expr_stmt [14844,14905]
expr_stmt [14967,15028]
===
match
---
atom_expr [29179,29205]
atom_expr [29302,29328]
===
match
---
trailer [29190,29205]
trailer [29313,29328]
===
match
---
dotted_name [1234,1252]
dotted_name [1234,1252]
===
match
---
operator: , [8649,8650]
operator: , [8643,8644]
===
match
---
if_stmt [27360,27456]
if_stmt [27483,27579]
===
match
---
simple_stmt [5450,5516]
simple_stmt [5450,5516]
===
match
---
operator: = [27237,27238]
operator: = [27360,27361]
===
match
---
string: "downstream_task_ids" [34302,34323]
string: "downstream_task_ids" [34425,34446]
===
match
---
name: attrname [12658,12666]
name: attrname [12781,12789]
===
match
---
name: serialize_dag [26744,26757]
name: serialize_dag [26867,26880]
===
match
---
name: cls [15380,15383]
name: cls [15503,15506]
===
match
---
expr_stmt [24164,24252]
expr_stmt [24287,24375]
===
match
---
name: SerializationError [27694,27712]
name: SerializationError [27817,27835]
===
match
---
decorator [5521,5535]
decorator [5521,5535]
===
match
---
expr_stmt [16113,16122]
expr_stmt [16236,16245]
===
match
---
simple_stmt [8578,8622]
simple_stmt [8572,8616]
===
match
---
fstring_string:  in deserialization. [12338,12358]
fstring_string:  in deserialization. [12461,12481]
===
match
---
trailer [33189,33208]
trailer [33312,33331]
===
match
---
trailer [10669,10682]
trailer [10792,10805]
===
match
---
name: serialize_template_field [1624,1648]
name: serialize_template_field [1624,1648]
===
match
---
name: task_type [15180,15189]
name: task_type [15303,15312]
===
match
---
name: cls [15758,15761]
name: cls [15881,15884]
===
match
---
param [10435,10451]
param [10558,10574]
===
match
---
exprlist [26988,26995]
exprlist [27111,27118]
===
match
---
atom_expr [11929,11967]
atom_expr [12052,12090]
===
match
---
not_test [16255,16306]
not_test [16378,16429]
===
match
---
name: Any [30952,30955]
name: Any [31075,31078]
===
match
---
name: op_extra_links_from_plugin [17546,17572]
name: op_extra_links_from_plugin [17669,17695]
===
match
---
operator: , [4655,4656]
operator: , [4655,4656]
===
match
---
return_stmt [9681,9715]
return_stmt [9675,9709]
===
match
---
operator: } [24149,24150]
operator: } [24272,24273]
===
match
---
operator: , [2540,2541]
operator: , [2540,2541]
===
match
---
name: classmethod [21202,21213]
name: classmethod [21325,21336]
===
match
---
name: cls [33986,33989]
name: cls [34109,34112]
===
match
---
name: relativedelta [12003,12016]
name: relativedelta [12126,12139]
===
match
---
atom [28328,28410]
atom [28451,28533]
===
match
---
name: SerializedTaskGroup [29103,29122]
name: SerializedTaskGroup [29226,29245]
===
match
---
trailer [12398,12413]
trailer [12521,12536]
===
match
---
trailer [32603,32609]
trailer [32726,32732]
===
match
---
name: op_predefined_extra_links [19501,19526]
name: op_predefined_extra_links [19624,19649]
===
match
---
simple_stmt [6212,6224]
simple_stmt [6212,6224]
===
match
---
operator: } [28409,28410]
operator: } [28532,28533]
===
match
---
arglist [5828,5853]
arglist [5828,5853]
===
match
---
expr_stmt [9533,9575]
expr_stmt [9527,9569]
===
match
---
suite [12696,12790]
suite [12819,12913]
===
match
---
operator: , [32625,32626]
operator: , [32748,32749]
===
match
---
decorator [6440,6453]
decorator [6440,6453]
===
match
---
suite [8656,8709]
suite [8650,8703]
===
match
---
atom_expr [8188,8197]
atom_expr [8188,8197]
===
match
---
name: update [18331,18337]
name: update [18454,18460]
===
match
---
operator: = [29878,29879]
operator: = [30001,30002]
===
match
---
and_test [18719,18791]
and_test [18842,18914]
===
match
---
arglist [24057,24123]
arglist [24180,24246]
===
match
---
name: _excluded_types [3283,3298]
name: _excluded_types [3283,3298]
===
match
---
name: dag [30530,30533]
name: dag [30653,30656]
===
match
---
name: _OPERATOR_EXTRA_LINKS [2252,2273]
name: _OPERATOR_EXTRA_LINKS [2252,2273]
===
match
---
if_stmt [2138,2215]
if_stmt [2138,2215]
===
match
---
simple_stmt [17546,17578]
simple_stmt [17669,17701]
===
match
---
parameters [21239,21261]
parameters [21362,21384]
===
match
---
trailer [8292,8295]
trailer [8292,8295]
===
match
---
name: self [14688,14692]
name: self [14811,14815]
===
match
---
name: plugins_manager [22148,22163]
name: plugins_manager [22271,22286]
===
match
---
trailer [20132,20135]
trailer [20255,20258]
===
match
---
name: serialize_to_json [15358,15375]
name: serialize_to_json [15481,15498]
===
match
---
name: timestamp [8905,8914]
name: timestamp [8899,8908]
===
match
---
name: enum [8153,8157]
name: enum [8153,8157]
===
match
---
trailer [23608,23611]
trailer [23731,23734]
===
match
---
atom_expr [21265,21281]
atom_expr [21388,21404]
===
match
---
decorated [15195,17083]
decorated [15318,17206]
===
match
---
atom_expr [31470,31518]
atom_expr [31593,31641]
===
match
---
suite [29996,30031]
suite [30119,30154]
===
match
---
trailer [31904,31920]
trailer [32027,32043]
===
match
---
name: HAS_KUBERNETES [11458,11472]
name: HAS_KUBERNETES [11581,11595]
===
match
---
name: classmethod [12469,12480]
name: classmethod [12592,12603]
===
match
---
simple_stmt [30815,30888]
simple_stmt [30938,31011]
===
match
---
operator: @ [12795,12796]
operator: @ [12918,12919]
===
match
---
name: has_on_failure_callback [29821,29844]
name: has_on_failure_callback [29944,29967]
===
match
---
name: dag [30395,30398]
name: dag [30518,30521]
===
match
---
name: isinstance [8951,8961]
name: isinstance [8945,8955]
===
match
---
name: maxsize [1172,1179]
name: maxsize [1172,1179]
===
match
---
name: Any [5934,5937]
name: Any [5934,5937]
===
match
---
string: 'Cast type %s to str in serialization.' [10262,10301]
string: 'Cast type %s to str in serialization.' [10385,10424]
===
match
---
atom [8288,8339]
atom [8288,8339]
===
match
---
name: var [12033,12036]
name: var [12156,12159]
===
match
---
dictorsetmaker [19109,19169]
dictorsetmaker [19232,19292]
===
match
---
atom_expr [9595,9640]
atom_expr [9589,9634]
===
match
---
name: get_serialized_fields [6725,6746]
name: get_serialized_fields [6725,6746]
===
match
---
operator: == [18151,18153]
operator: == [18274,18276]
===
match
---
atom_expr [16553,16599]
atom_expr [16676,16722]
===
match
---
name: cls [6244,6247]
name: cls [6244,6247]
===
match
---
suite [1918,2089]
suite [1918,2089]
===
match
---
name: cls [11096,11099]
name: cls [11219,11222]
===
match
---
decorated [26723,27756]
decorated [26846,27879]
===
match
---
operator: = [21028,21029]
operator: = [21151,21152]
===
match
---
operator: , [32712,32713]
operator: , [32835,32836]
===
match
---
name: var [6008,6011]
name: var [6008,6011]
===
match
---
arglist [7223,7234]
arglist [7223,7234]
===
match
---
arglist [30290,30318]
arglist [30413,30441]
===
match
---
trailer [28636,28645]
trailer [28759,28768]
===
match
---
name: label [33712,33717]
name: label [33835,33840]
===
match
---
atom_expr [28070,28076]
atom_expr [28193,28199]
===
match
---
trailer [14716,14725]
trailer [14839,14848]
===
match
---
name: qualname [21563,21571]
name: qualname [21686,21694]
===
match
---
atom_expr [9153,9165]
atom_expr [9147,9159]
===
match
---
name: dep [16139,16142]
name: dep [16262,16265]
===
match
---
trailer [26530,26538]
trailer [26653,26661]
===
match
---
name: ui_color [14717,14725]
name: ui_color [14840,14848]
===
match
---
argument [9867,9897]
argument [9882,9912]
===
match
---
name: _deserialize [4912,4924]
name: _deserialize [4912,4924]
===
match
---
suite [18792,18888]
suite [18915,19011]
===
match
---
name: deserialize_dag [19067,19082]
name: deserialize_dag [19190,19205]
===
match
---
expr_stmt [2067,2088]
expr_stmt [2067,2088]
===
match
---
suite [28739,28811]
suite [28862,28934]
===
match
---
decorated [27761,30908]
decorated [27884,31031]
===
match
---
simple_stmt [30166,30205]
simple_stmt [30289,30328]
===
match
---
name: v [8322,8323]
name: v [8322,8323]
===
match
---
name: child [32540,32545]
name: child [32663,32668]
===
match
---
simple_stmt [25407,25445]
simple_stmt [25530,25568]
===
match
---
simple_stmt [5270,5312]
simple_stmt [5270,5312]
===
match
---
string: "Invalid type: Only dict and str are supported." [5466,5514]
string: "Invalid type: Only dict and str are supported." [5466,5514]
===
match
---
param [4385,4404]
param [4385,4404]
===
match
---
simple_stmt [15609,15669]
simple_stmt [15732,15792]
===
match
---
name: Parameter [3675,3684]
name: Parameter [3675,3684]
===
match
---
name: type_ [9040,9045]
name: type_ [9034,9039]
===
match
---
atom_expr [19313,19332]
atom_expr [19436,19455]
===
match
---
simple_stmt [13939,14149]
simple_stmt [14062,14272]
===
match
---
atom_expr [16421,16431]
atom_expr [16544,16554]
===
match
---
trailer [8502,8508]
trailer [8496,8502]
===
match
---
dotted_name [1816,1844]
dotted_name [1816,1844]
===
match
---
or_test [20029,20094]
or_test [20152,20217]
===
match
---
trailer [7292,7301]
trailer [7292,7301]
===
match
---
atom_expr [17283,17304]
atom_expr [17406,17427]
===
match
---
trailer [12105,12108]
trailer [12228,12231]
===
match
---
name: BaseOperatorLink [24190,24206]
name: BaseOperatorLink [24313,24329]
===
match
---
operator: = [27557,27558]
operator: = [27680,27681]
===
match
---
parameters [12652,12687]
parameters [12775,12810]
===
match
---
operator: -> [5022,5024]
operator: -> [5022,5024]
===
match
---
trailer [9598,9606]
trailer [9592,9600]
===
match
---
name: classmethod [33027,33038]
name: classmethod [33150,33161]
===
match
---
name: __class__ [25264,25273]
name: __class__ [25387,25396]
===
match
---
name: group [33681,33686]
name: group [33804,33809]
===
match
---
comparison [20810,20825]
comparison [20933,20948]
===
match
---
name: models [1430,1436]
name: models [1430,1436]
===
match
---
atom_expr [28833,28854]
atom_expr [28956,28977]
===
match
---
trailer [18816,18887]
trailer [18939,19010]
===
match
---
atom_expr [10303,10312]
atom_expr [10426,10435]
===
match
---
operator: , [26035,26036]
operator: , [26158,26159]
===
match
---
string: "_group_id" [32070,32081]
string: "_group_id" [32193,32204]
===
match
---
fstring_end: ' [5209,5210]
fstring_end: ' [5209,5210]
===
match
---
expr_stmt [16612,16639]
expr_stmt [16735,16762]
===
match
---
operator: } [32624,32625]
operator: } [32747,32748]
===
match
---
if_stmt [23624,24151]
if_stmt [23747,24274]
===
match
---
name: cls [30942,30945]
name: cls [31065,31068]
===
match
---
atom_expr [17656,17686]
atom_expr [17779,17809]
===
match
---
name: DAT [8924,8927]
name: DAT [8918,8921]
===
match
---
trailer [11729,11739]
trailer [11852,11862]
===
match
---
operator: == [21100,21102]
operator: == [21223,21225]
===
match
---
param [5894,5898]
param [5894,5898]
===
match
---
name: Iterable [24485,24493]
name: Iterable [24608,24616]
===
match
---
atom_expr [12145,12154]
atom_expr [12268,12277]
===
match
---
trailer [30016,30030]
trailer [30139,30153]
===
match
---
trailer [20669,20689]
trailer [20792,20812]
===
match
---
name: airflow [1234,1241]
name: airflow [1234,1241]
===
match
---
simple_stmt [12418,12463]
simple_stmt [12541,12586]
===
match
---
simple_stmt [4091,4172]
simple_stmt [4091,4172]
===
match
---
atom_expr [3665,3685]
atom_expr [3665,3685]
===
match
---
simple_stmt [34239,34327]
simple_stmt [34362,34450]
===
match
---
trailer [20221,20243]
trailer [20344,20366]
===
match
---
name: Connection [1406,1416]
name: Connection [1406,1416]
===
match
---
name: op [16966,16968]
name: op [17089,17091]
===
match
---
name: serialization [1595,1608]
name: serialization [1595,1608]
===
match
---
name: op_predefined_extra_link [24164,24188]
name: op_predefined_extra_link [24287,24311]
===
match
---
string: '__version' [31489,31500]
string: '__version' [31612,31623]
===
match
---
operator: = [23721,23722]
operator: = [23844,23845]
===
match
---
operator: -> [3813,3815]
operator: -> [3813,3815]
===
match
---
trailer [14413,14415]
trailer [14536,14538]
===
match
---
expr_stmt [17247,17305]
expr_stmt [17370,17428]
===
match
---
simple_stmt [30897,30908]
simple_stmt [31020,31031]
===
match
---
name: utils [1824,1829]
name: utils [1824,1829]
===
match
---
trailer [29216,29226]
trailer [29339,29349]
===
match
---
simple_stmt [1988,2046]
simple_stmt [1988,2046]
===
match
---
operator: = [19527,19528]
operator: = [19650,19651]
===
match
---
atom [31075,31143]
atom [31198,31266]
===
match
---
trailer [9022,9036]
trailer [9016,9030]
===
match
---
dotted_name [1191,1211]
dotted_name [1191,1211]
===
match
---
atom_expr [31579,31635]
atom_expr [31702,31758]
===
match
---
name: child [32395,32400]
name: child [32518,32523]
===
match
---
trailer [28836,28854]
trailer [28959,28977]
===
match
---
name: var [8561,8564]
name: var [8555,8558]
===
match
---
suite [8164,8198]
suite [8164,8198]
===
match
---
name: str [15148,15151]
name: str [15271,15274]
===
match
---
operator: @ [2613,2614]
operator: @ [2613,2614]
===
match
---
simple_stmt [22367,22398]
simple_stmt [22490,22521]
===
match
---
suite [4460,4607]
suite [4460,4607]
===
match
---
name: dict [10861,10865]
name: dict [10984,10988]
===
match
---
string: "edge_info" [28727,28738]
string: "edge_info" [28850,28861]
===
match
---
trailer [28879,28892]
trailer [29002,29015]
===
match
---
return_stmt [11268,11323]
return_stmt [11391,11446]
===
match
---
fstring_string: s [5195,5196]
fstring_string: s [5195,5196]
===
match
---
name: var [9019,9022]
name: var [9013,9016]
===
match
---
name: v [26437,26438]
name: v [26560,26561]
===
match
---
name: _json_schema [5107,5119]
name: _json_schema [5107,5119]
===
match
---
name: operator_extra_links [14885,14905]
name: operator_extra_links [15008,15028]
===
match
---
comparison [13694,13729]
comparison [13817,13852]
===
match
---
operator: = [33648,33649]
operator: = [33771,33772]
===
match
---
expr_stmt [31063,31143]
expr_stmt [31186,31266]
===
match
---
import_from [22128,22163]
import_from [22251,22286]
===
match
---
arglist [8288,8355]
arglist [8288,8355]
===
match
---
if_stmt [21356,21501]
if_stmt [21479,21624]
===
match
---
operator: = [28874,28875]
operator: = [28997,28998]
===
match
---
operator: = [7285,7286]
operator: = [7285,7286]
===
match
---
name: cls [31120,31123]
name: cls [31243,31246]
===
match
---
operator: } [32987,32988]
operator: } [33110,33111]
===
match
---
string: '.' [16415,16418]
string: '.' [16538,16541]
===
match
---
name: attrname [6401,6409]
name: attrname [6401,6409]
===
match
---
atom_expr [32267,32286]
atom_expr [32390,32409]
===
match
---
trailer [5185,5194]
trailer [5185,5194]
===
match
---
atom_expr [11128,11139]
atom_expr [11251,11262]
===
match
---
arglist [21435,21474]
arglist [21558,21597]
===
match
---
name: str [5352,5355]
name: str [5352,5355]
===
match
---
name: DAT [11430,11433]
name: DAT [11553,11556]
===
match
---
name: instances [21535,21544]
name: instances [21658,21667]
===
match
---
name: str [12668,12671]
name: str [12791,12794]
===
match
---
atom_expr [22244,22292]
atom_expr [22367,22415]
===
match
---
name: get_serialized_fields [20071,20092]
name: get_serialized_fields [20194,20215]
===
match
---
import_from [1117,1148]
import_from [1117,1148]
===
match
---
atom_expr [9906,9913]
atom_expr [9921,9928]
===
match
---
return_stmt [12562,12604]
return_stmt [12685,12727]
===
match
---
trailer [12240,12253]
trailer [12363,12376]
===
match
---
atom_expr [7212,7235]
atom_expr [7212,7235]
===
match
---
name: cls [5732,5735]
name: cls [5732,5735]
===
match
---
atom_expr [8419,8436]
atom_expr [8413,8430]
===
match
---
trailer [27474,27498]
trailer [27597,27621]
===
match
---
return_stmt [30897,30907]
return_stmt [31020,31030]
===
match
---
arglist [9860,9913]
arglist [9875,9928]
===
match
---
atom [5652,5691]
atom [5652,5691]
===
match
---
atom_expr [30070,30081]
atom_expr [30193,30204]
===
match
---
return_stmt [33341,33352]
return_stmt [33464,33475]
===
match
---
name: serialize_dag [27034,27047]
name: serialize_dag [27157,27170]
===
match
---
trailer [18997,19000]
trailer [19120,19123]
===
match
---
trailer [6661,6671]
trailer [6661,6671]
===
match
---
string: """Deserializes json_str and reconstructs all DAGs and operators it contains.""" [4469,4549]
string: """Deserializes json_str and reconstructs all DAGs and operators it contains.""" [4469,4549]
===
match
---
name: Dict [6657,6661]
name: Dict [6657,6661]
===
match
---
sync_comp_for [33503,33570]
sync_comp_for [33626,33693]
===
match
---
comparison [7240,7257]
comparison [7240,7257]
===
match
---
trailer [9131,9166]
trailer [9125,9160]
===
match
---
decorator [17088,17101]
decorator [17211,17224]
===
match
---
name: operator_extra_links [24927,24947]
name: operator_extra_links [25050,25070]
===
match
---
trailer [25211,25218]
trailer [25334,25341]
===
match
---
trailer [4578,4606]
trailer [4578,4606]
===
match
---
atom_expr [6657,6671]
atom_expr [6657,6671]
===
match
---
trailer [23599,23605]
trailer [23722,23728]
===
match
---
name: tuple [3805,3810]
name: tuple [3805,3810]
===
match
---
name: isinstance [8370,8380]
name: isinstance [8370,8380]
===
match
---
trailer [20070,20092]
trailer [20193,20215]
===
match
---
trailer [29122,29145]
trailer [29245,29268]
===
match
---
name: cls [12653,12656]
name: cls [12776,12779]
===
match
---
atom_expr [20830,20842]
atom_expr [20953,20965]
===
match
---
name: k [9258,9259]
name: k [9252,9253]
===
match
---
name: _serialize [8301,8311]
name: _serialize [8301,8311]
===
match
---
parameters [5893,5938]
parameters [5893,5938]
===
match
---
name: airflow [1587,1594]
name: airflow [1587,1594]
===
match
---
suite [29704,29752]
suite [29827,29875]
===
match
---
trailer [4583,4589]
trailer [4583,4589]
===
match
---
name: op [20441,20443]
name: op [20564,20566]
===
match
---
operator: - [29929,29930]
operator: - [30052,30053]
===
match
---
name: serialized_object [7082,7099]
name: serialized_object [7082,7099]
===
match
---
arglist [21177,21194]
arglist [21300,21317]
===
match
---
atom_expr [4908,4940]
atom_expr [4908,4940]
===
match
---
funcdef [21218,21712]
funcdef [21341,21835]
===
match
---
trailer [29921,29926]
trailer [30044,30049]
===
match
---
atom_expr [18154,18178]
atom_expr [18277,18301]
===
match
---
name: task_group [32267,32277]
name: task_group [32390,32400]
===
match
---
trailer [12542,12552]
trailer [12665,12675]
===
match
---
if_stmt [6005,6301]
if_stmt [6005,6301]
===
match
---
name: type_ [8918,8923]
name: type_ [8912,8917]
===
match
---
name: lru_cache [1162,1171]
name: lru_cache [1162,1171]
===
match
---
trailer [5234,5256]
trailer [5234,5256]
===
match
---
arglist [8901,8936]
arglist [8895,8930]
===
match
---
name: type_ [11678,11683]
name: type_ [11801,11806]
===
match
---
trailer [32093,32103]
trailer [32216,32226]
===
match
---
comparison [19018,19031]
comparison [19141,19154]
===
match
---
name: log [21425,21428]
name: log [21548,21551]
===
match
---
trailer [9881,9884]
trailer [9896,9899]
===
match
---
atom_expr [11844,11861]
atom_expr [11967,11984]
===
match
---
name: v [27980,27981]
name: v [28103,28104]
===
match
---
operator: , [30307,30308]
operator: , [30430,30431]
===
match
---
atom_expr [9688,9715]
atom_expr [9682,9709]
===
match
---
name: relativedelta [1041,1054]
name: relativedelta [1041,1054]
===
match
---
parameters [5731,5746]
parameters [5731,5746]
===
match
---
exprlist [9258,9262]
exprlist [9252,9256]
===
match
---
decorated [21717,24400]
decorated [21840,24523]
===
match
---
string: '_description' [26263,26277]
string: '_description' [26386,26400]
===
match
---
trailer [32857,32887]
trailer [32980,33010]
===
match
---
trailer [8892,8900]
trailer [8886,8894]
===
match
---
name: cls [4380,4383]
name: cls [4380,4383]
===
match
---
parameters [15130,15152]
parameters [15253,15275]
===
match
---
sync_comp_for [12257,12269]
sync_comp_for [12380,12392]
===
match
---
atom_expr [12003,12037]
atom_expr [12126,12160]
===
match
---
string: 'weekday' [9437,9446]
string: 'weekday' [9431,9440]
===
match
---
name: keys [29922,29926]
name: keys [30045,30049]
===
match
---
string: '_default_view' [26307,26322]
string: '_default_view' [26430,26445]
===
match
---
fstring [16488,16513]
fstring [16611,16636]
===
match
---
name: v [10092,10093]
name: v [10215,10216]
===
match
---
trailer [32680,32711]
trailer [32803,32834]
===
match
---
operator: , [21180,21181]
operator: , [21303,21304]
===
match
---
trailer [31137,31142]
trailer [31260,31265]
===
match
---
operator: , [16964,16965]
operator: , [17087,17088]
===
match
---
trailer [18342,18347]
trailer [18465,18470]
===
match
---
name: _CONSTRUCTOR_PARAMS [20272,20291]
name: _CONSTRUCTOR_PARAMS [20395,20414]
===
match
---
operator: = [7105,7106]
operator: = [7105,7106]
===
match
---
trailer [19218,19221]
trailer [19341,19344]
===
match
---
trailer [4414,4459]
trailer [4414,4459]
===
match
---
if_stmt [15858,16640]
if_stmt [15981,16763]
===
match
---
name: relativedelta [11929,11942]
name: relativedelta [12052,12065]
===
match
---
name: warning [21628,21635]
name: warning [21751,21758]
===
match
---
expr_stmt [28872,28895]
expr_stmt [28995,29018]
===
match
---
simple_stmt [4762,4893]
simple_stmt [4762,4893]
===
match
---
name: DAT [9153,9156]
name: DAT [9147,9150]
===
match
---
param [21772,21776]
param [21895,21899]
===
match
---
suite [29469,29511]
suite [29592,29634]
===
match
---
atom_expr [32681,32710]
atom_expr [32804,32833]
===
match
---
name: functools [1122,1131]
name: functools [1122,1131]
===
match
---
trailer [15166,15177]
trailer [15289,15300]
===
match
---
dotted_name [1512,1539]
dotted_name [1512,1539]
===
match
---
trailer [9859,9914]
trailer [9874,9929]
===
match
---
expr_stmt [3696,3718]
expr_stmt [3696,3718]
===
match
---
simple_stmt [12366,12414]
simple_stmt [12489,12537]
===
match
---
name: Validator [1695,1704]
name: Validator [1695,1704]
===
match
---
atom_expr [11430,11437]
atom_expr [11553,11560]
===
match
---
string: "task_id" [28334,28343]
string: "task_id" [28457,28466]
===
match
---
name: dict [3788,3792]
name: dict [3788,3792]
===
match
---
arglist [9939,9949]
arglist [10068,10078]
===
match
---
operator: , [10101,10102]
operator: , [10224,10225]
===
match
---
operator: , [24229,24230]
operator: , [24352,24353]
===
match
---
name: isinstance [5817,5827]
name: isinstance [5817,5827]
===
match
---
operator: } [13806,13807]
operator: } [13929,13930]
===
match
---
string: "operator_extra_links" [19913,19935]
string: "operator_extra_links" [20036,20058]
===
match
---
simple_stmt [19049,19086]
simple_stmt [19172,19209]
===
match
---
operator: -> [12891,12893]
operator: -> [13014,13016]
===
match
---
operator: , [33193,33194]
operator: , [33316,33317]
===
match
---
param [21245,21260]
param [21368,21383]
===
match
---
tfpdef [27803,27830]
tfpdef [27926,27953]
===
match
---
simple_stmt [5039,5092]
simple_stmt [5039,5092]
===
match
---
suite [1112,1186]
suite [1112,1186]
===
match
---
name: BaseOperator [4035,4047]
name: BaseOperator [4035,4047]
===
match
---
trailer [30123,30125]
trailer [30246,30248]
===
match
---
operator: { [31626,31627]
operator: { [31749,31750]
===
match
---
trailer [34081,34138]
trailer [34204,34261]
===
match
---
name: set [21333,21336]
name: set [21456,21459]
===
match
---
expr_stmt [23876,24012]
expr_stmt [23999,24135]
===
match
---
tfpdef [4385,4404]
tfpdef [4385,4404]
===
match
---
dotted_name [1727,1743]
dotted_name [1727,1743]
===
match
---
name: cls [5270,5273]
name: cls [5270,5273]
===
match
---
name: op [20524,20526]
name: op [20647,20649]
===
match
---
name: encoded_dag [29060,29071]
name: encoded_dag [29183,29194]
===
match
---
dictorsetmaker [14231,14351]
dictorsetmaker [14354,14474]
===
match
---
atom_expr [33107,33121]
atom_expr [33230,33244]
===
match
---
atom [2286,2610]
atom [2286,2610]
===
match
---
name: serialize_task_group [27085,27105]
name: serialize_task_group [27208,27228]
===
match
---
name: startswith [16271,16281]
name: startswith [16394,16404]
===
match
---
comparison [22244,22300]
comparison [22367,22423]
===
match
---
trailer [4568,4578]
trailer [4568,4578]
===
match
---
string: '_operator_extra_links' [15731,15754]
string: '_operator_extra_links' [15854,15877]
===
match
---
atom_expr [26591,26628]
atom_expr [26714,26751]
===
match
---
operator: } [16511,16512]
operator: } [16634,16635]
===
match
---
name: var [11912,11915]
name: var [12035,12038]
===
match
---
trailer [9507,9515]
trailer [9501,9509]
===
match
---
name: weekday [9567,9574]
name: weekday [9561,9568]
===
match
---
simple_stmt [12908,13641]
simple_stmt [13031,13764]
===
match
---
operator: , [8320,8321]
operator: , [8320,8321]
===
match
---
trailer [9269,9278]
trailer [9263,9272]
===
match
---
name: v [12113,12114]
name: v [12236,12237]
===
match
---
atom_expr [25127,25397]
atom_expr [25250,25520]
===
match
---
name: k [28427,28428]
name: k [28550,28551]
===
match
---
name: weekday [9508,9515]
name: weekday [9502,9509]
===
match
---
name: op_extra_links_from_plugin [18850,18876]
name: op_extra_links_from_plugin [18973,18999]
===
match
---
string: "_date" [19324,19331]
string: "_date" [19447,19454]
===
match
---
suite [21518,21576]
suite [21641,21699]
===
match
---
expr_stmt [11007,11041]
expr_stmt [11130,11164]
===
match
---
simple_stmt [7357,7382]
simple_stmt [7357,7382]
===
match
---
simple_stmt [21535,21576]
simple_stmt [21658,21699]
===
match
---
trailer [34274,34287]
trailer [34397,34410]
===
match
---
param [12653,12657]
param [12776,12780]
===
match
---
name: ver [31530,31533]
name: ver [31653,31656]
===
match
---
trailer [14415,14424]
trailer [14538,14547]
===
match
---
exprlist [32568,32580]
exprlist [32691,32703]
===
match
---
name: cls [15354,15357]
name: cls [15477,15480]
===
match
---
name: Any [4688,4691]
name: Any [4688,4691]
===
match
---
name: edge_info [27243,27252]
name: edge_info [27366,27375]
===
match
---
arglist [5235,5255]
arglist [5235,5255]
===
match
---
name: set [3800,3803]
name: set [3800,3803]
===
match
---
name: _deserialize [33377,33389]
name: _deserialize [33500,33512]
===
match
---
name: encoded_op [19244,19254]
name: encoded_op [19367,19377]
===
match
---
tfpdef [5924,5937]
tfpdef [5924,5937]
===
match
---
dotted_name [1761,1785]
dotted_name [1761,1785]
===
match
---
atom [12236,12270]
atom [12359,12393]
===
match
---
string: "downstream_group_ids" [32726,32748]
string: "downstream_group_ids" [32849,32871]
===
match
---
operator: { [2286,2287]
operator: { [2286,2287]
===
match
---
dotted_name [1945,1962]
dotted_name [1945,1962]
===
match
---
name: pod [11661,11664]
name: pod [11784,11787]
===
match
---
trailer [11778,11787]
trailer [11901,11910]
===
match
---
trailer [20291,20296]
trailer [20414,20419]
===
match
---
operator: , [31500,31501]
operator: , [31623,31624]
===
match
---
trailer [24214,24224]
trailer [24337,24347]
===
match
---
name: task_group [31864,31874]
name: task_group [31987,31997]
===
match
---
trailer [30106,30116]
trailer [30229,30239]
===
match
---
name: Any [10448,10451]
name: Any [10571,10574]
===
match
---
name: type_ [11421,11426]
name: type_ [11544,11549]
===
match
---
name: __class__ [15504,15513]
name: __class__ [15627,15636]
===
match
---
simple_stmt [15067,15090]
simple_stmt [15190,15213]
===
match
---
name: v [28074,28075]
name: v [28197,28198]
===
match
---
name: _serialize [32929,32939]
name: _serialize [33052,33062]
===
match
---
operator: = [14750,14751]
operator: = [14873,14874]
===
match
---
comp_op [20814,20820]
comp_op [20937,20943]
===
match
---
string: 'weekday' [9541,9550]
string: 'weekday' [9535,9544]
===
match
---
return_stmt [31644,31693]
return_stmt [31767,31816]
===
match
---
fstring_end: " [10956,10957]
fstring_end: " [11079,11080]
===
match
---
expr_stmt [28324,28410]
expr_stmt [28447,28533]
===
match
---
return_stmt [11996,12037]
return_stmt [12119,12160]
===
match
---
name: _value_is_hardcoded_default [12816,12843]
name: _value_is_hardcoded_default [12939,12966]
===
match
---
comparison [31530,31559]
comparison [31653,31682]
===
match
---
name: TIMEZONE [11779,11787]
name: TIMEZONE [11902,11910]
===
match
---
name: Optional [31890,31898]
name: Optional [32013,32021]
===
match
---
name: Any [15271,15274]
name: Any [15394,15397]
===
match
---
operator: } [16434,16435]
operator: } [16557,16558]
===
match
---
operator: } [18352,18353]
operator: } [18475,18476]
===
match
---
name: BaseOperator [33195,33207]
name: BaseOperator [33318,33330]
===
match
---
name: SerializedTaskGroup [27065,27084]
name: SerializedTaskGroup [27188,27207]
===
match
---
name: BaseTIDep [2205,2214]
name: BaseTIDep [2205,2214]
===
match
---
name: serialized_obj [4988,5002]
name: serialized_obj [4988,5002]
===
match
---
name: instance [6076,6084]
name: instance [6076,6084]
===
match
---
simple_stmt [16205,16236]
simple_stmt [16328,16359]
===
match
---
classdef [13872,25445]
classdef [13995,25568]
===
match
---
trailer [27932,27963]
trailer [28055,28086]
===
match
---
trailer [32539,32546]
trailer [32662,32669]
===
match
---
expr_stmt [16171,16188]
expr_stmt [16294,16311]
===
match
---
if_stmt [8134,8198]
if_stmt [8134,8198]
===
match
---
dotted_name [1993,2025]
dotted_name [1993,2025]
===
match
---
decorator [21201,21214]
decorator [21324,21337]
===
match
---
name: str [21809,21812]
name: str [21932,21935]
===
match
---
funcdef [4002,4344]
funcdef [4002,4344]
===
match
---
sync_comp_for [8315,8338]
sync_comp_for [8315,8338]
===
match
---
trailer [28950,28961]
trailer [29073,29084]
===
match
---
operator: { [19108,19109]
operator: { [19231,19232]
===
match
---
name: values [19883,19889]
name: values [20006,20012]
===
match
---
name: default [14329,14336]
name: default [14452,14459]
===
match
---
name: self [14939,14943]
name: self [15062,15066]
===
match
---
trailer [21428,21434]
trailer [21551,21557]
===
match
---
operator: , [961,962]
operator: , [961,962]
===
match
---
operator: , [21054,21055]
operator: , [21177,21178]
===
match
---
simple_stmt [3283,3336]
simple_stmt [3283,3336]
===
match
---
name: get_operator_extra_links [2624,2648]
name: get_operator_extra_links [2624,2648]
===
match
---
trailer [27529,27556]
trailer [27652,27679]
===
match
---
name: Optional [33145,33153]
name: Optional [33268,33276]
===
match
---
operator: = [16118,16119]
operator: = [16241,16242]
===
match
---
atom_expr [27985,28004]
atom_expr [28108,28127]
===
match
---
atom_expr [12442,12462]
atom_expr [12565,12585]
===
match
---
name: str [5010,5013]
name: str [5010,5013]
===
match
---
operator: @ [27761,27762]
operator: @ [27884,27885]
===
match
---
string: "tooltip" [32212,32221]
string: "tooltip" [32335,32344]
===
match
---
name: var [8148,8151]
name: var [8148,8151]
===
match
---
operator: , [3076,3077]
operator: , [3076,3077]
===
match
---
name: group [33955,33960]
name: group [34078,34083]
===
match
---
suite [9225,9641]
suite [9219,9635]
===
match
---
atom_expr [26963,26983]
atom_expr [27086,27106]
===
match
---
raise_stmt [22314,22358]
raise_stmt [22437,22481]
===
match
---
trailer [6519,6538]
trailer [6519,6538]
===
match
---
arglist [20191,20199]
arglist [20314,20322]
===
match
---
name: __get_constructor_defaults [26591,26617]
name: __get_constructor_defaults [26714,26740]
===
match
---
trailer [20296,20298]
trailer [20419,20421]
===
match
---
funcdef [33043,34348]
funcdef [33166,34471]
===
match
---
name: var [5899,5902]
name: var [5899,5902]
===
match
---
trailer [27366,27390]
trailer [27489,27513]
===
match
---
name: cls [26758,26761]
name: cls [26881,26884]
===
match
---
name: str [3085,3088]
name: str [3085,3088]
===
match
---
trailer [8020,8025]
trailer [8020,8025]
===
match
---
name: __dict__ [9270,9278]
name: __dict__ [9264,9272]
===
match
---
atom_expr [21251,21260]
atom_expr [21374,21383]
===
match
---
funcdef [4963,5516]
funcdef [4963,5516]
===
match
---
name: val [33841,33844]
name: val [33964,33967]
===
match
---
name: code_utils [1775,1785]
name: code_utils [1775,1785]
===
match
---
name: dag [16402,16405]
name: dag [16525,16528]
===
match
---
operator: = [19911,19912]
operator: = [20034,20035]
===
match
---
atom_expr [12304,12360]
atom_expr [12427,12483]
===
match
---
operator: , [4446,4447]
operator: , [4446,4447]
===
match
---
except_clause [2089,2107]
except_clause [2089,2107]
===
match
---
operator: = [23570,23571]
operator: = [23693,23694]
===
match
---
name: _deserialize_datetime [12366,12387]
name: _deserialize_datetime [12489,12510]
===
match
---
name: hasattr [20480,20487]
name: hasattr [20603,20610]
===
match
---
suite [31922,33021]
suite [32045,33144]
===
match
---
name: pendulum [12442,12450]
name: pendulum [12565,12573]
===
match
---
comparison [11878,11894]
comparison [12001,12017]
===
match
---
fstring [12314,12359]
fstring [12437,12482]
===
match
---
dotted_name [1871,1895]
dotted_name [1871,1895]
===
match
---
operator: = [28225,28226]
operator: = [28348,28349]
===
match
---
name: setattr [20183,20190]
name: setattr [20306,20313]
===
match
---
import_from [1756,1810]
import_from [1756,1810]
===
match
---
name: cls [21240,21243]
name: cls [21363,21366]
===
match
---
name: label [32379,32384]
name: label [32502,32507]
===
match
---
atom_expr [9196,9223]
atom_expr [9190,9217]
===
match
---
operator: , [6926,6927]
operator: , [6926,6927]
===
match
---
fstring_end: " [16462,16463]
fstring_end: " [16585,16586]
===
match
---
expr_stmt [3605,3638]
expr_stmt [3605,3638]
===
match
---
operator: == [19402,19404]
operator: == [19525,19527]
===
match
---
atom_expr [14734,14749]
atom_expr [14857,14872]
===
match
---
name: k [8319,8320]
name: k [8319,8320]
===
match
---
parameters [15234,15257]
parameters [15357,15380]
===
match
---
name: SerializedBaseOperator [17252,17274]
name: SerializedBaseOperator [17375,17397]
===
match
---
name: plugins_manager [17999,18014]
name: plugins_manager [18122,18137]
===
match
---
name: self [15162,15166]
name: self [15285,15289]
===
match
---
atom_expr [9928,9950]
atom_expr [10057,10079]
===
match
---
name: value [7122,7127]
name: value [7122,7127]
===
match
---
string: "subdag" [19023,19031]
string: "subdag" [19146,19154]
===
match
---
name: Union [31899,31904]
name: Union [32022,32027]
===
match
---
suite [15276,17083]
suite [15399,17206]
===
match
---
suite [13824,13849]
suite [13947,13972]
===
match
---
name: op [20191,20193]
name: op [20314,20316]
===
match
---
trailer [9353,9361]
trailer [9347,9355]
===
match
---
name: cls [8297,8300]
name: cls [8297,8300]
===
match
---
atom_expr [5270,5311]
atom_expr [5270,5311]
===
match
---
comparison [28094,28106]
comparison [28217,28229]
===
match
---
if_stmt [16768,17054]
if_stmt [16891,17177]
===
match
---
raise_stmt [4316,4343]
raise_stmt [4316,4343]
===
match
---
name: deps [2181,2185]
name: deps [2181,2185]
===
match
---
name: TYPE_CHECKING [927,940]
name: TYPE_CHECKING [927,940]
===
match
---
name: Enum [8158,8162]
name: Enum [8158,8162]
===
match
---
trailer [34207,34228]
trailer [34330,34351]
===
match
---
name: property [14912,14920]
name: property [15035,15043]
===
match
---
string: """Primitive types.""" [5764,5786]
string: """Primitive types.""" [5764,5786]
===
match
---
name: cls [4565,4568]
name: cls [4565,4568]
===
match
---
import_as_names [1337,1367]
import_as_names [1337,1367]
===
match
---
name: logging [3302,3309]
name: logging [3302,3309]
===
match
---
operator: == [11427,11429]
operator: == [11550,11552]
===
match
---
operator: == [11245,11247]
operator: == [11368,11370]
===
match
---
name: str [9688,9691]
name: str [9682,9685]
===
match
---
name: encoded_group [33390,33403]
name: encoded_group [33513,33526]
===
match
---
name: qualname [21363,21371]
name: qualname [21486,21494]
===
match
---
decorated [4612,4941]
decorated [4612,4941]
===
match
---
trailer [12577,12587]
trailer [12700,12710]
===
match
---
atom_expr [28876,28895]
atom_expr [28999,29018]
===
match
---
atom_expr [14704,14725]
atom_expr [14827,14848]
===
match
---
name: getattr [21030,21037]
name: getattr [21153,21160]
===
match
---
suite [11788,11822]
suite [11911,11945]
===
match
---
param [14376,14381]
param [14499,14504]
===
match
---
expr_stmt [23700,23763]
expr_stmt [23823,23886]
===
match
---
name: var [8733,8736]
name: var [8727,8730]
===
match
---
operator: , [26989,26990]
operator: , [27112,27113]
===
match
---
name: str [10333,10336]
name: str [10456,10459]
===
match
---
fstring_conversion [12335,12337]
fstring_conversion [12458,12460]
===
match
---
name: empty [14346,14351]
name: empty [14469,14474]
===
match
---
atom_expr [27408,27448]
atom_expr [27531,27571]
===
match
---
trailer [12092,12105]
trailer [12215,12228]
===
match
---
trailer [6359,6387]
trailer [6359,6387]
===
match
---
trailer [11297,11318]
trailer [11420,11441]
===
match
---
operator: , [21190,21191]
operator: , [21313,21314]
===
match
---
operator: } [33579,33580]
operator: } [33702,33703]
===
match
---
name: task_group [32584,32594]
name: task_group [32707,32717]
===
match
---
name: _deserialize [20120,20132]
name: _deserialize [20243,20255]
===
match
---
name: cls [28227,28230]
name: cls [28350,28353]
===
match
---
string: """Helper function of depth first search for deserialization.""" [10515,10579]
string: """Helper function of depth first search for deserialization.""" [10638,10702]
===
match
---
name: dag [29717,29720]
name: dag [29840,29843]
===
match
---
fstring [16378,16463]
fstring [16501,16586]
===
match
---
trailer [26547,26553]
trailer [26670,26676]
===
match
---
subscriptlist [5010,5019]
subscriptlist [5010,5019]
===
match
---
atom_expr [3196,3213]
atom_expr [3196,3213]
===
match
---
name: ver [31627,31630]
name: ver [31750,31753]
===
match
---
trailer [16270,16281]
trailer [16393,16404]
===
match
---
if_stmt [21074,21141]
if_stmt [21197,21264]
===
match
---
suite [7065,7129]
suite [7065,7129]
===
match
---
name: var [5802,5805]
name: var [5802,5805]
===
match
---
atom_expr [26412,26435]
atom_expr [26535,26558]
===
match
---
sync_comp_for [26459,26553]
sync_comp_for [26582,26676]
===
match
---
not_test [10833,10866]
not_test [10956,10989]
===
match
---
name: ope [18339,18342]
name: ope [18462,18465]
===
match
---
trailer [7185,7192]
trailer [7185,7192]
===
match
---
simple_stmt [10044,10120]
simple_stmt [10173,10243]
===
match
---
argument [9147,9165]
argument [9141,9159]
===
match
---
name: tooltip [32234,32241]
name: tooltip [32357,32364]
===
match
---
name: single_op_link_class [23700,23720]
name: single_op_link_class [23823,23843]
===
match
---
name: instances [21291,21300]
name: instances [21414,21423]
===
match
---
name: op_link_arguments [25050,25067]
name: op_link_arguments [25173,25190]
===
match
---
name: BaseOperator [13901,13913]
name: BaseOperator [14024,14036]
===
match
---
import_from [17742,17777]
import_from [17865,17900]
===
match
---
dotted_name [15096,15112]
dotted_name [15219,15235]
===
match
---
trailer [19882,19889]
trailer [20005,20012]
===
match
---
name: task_dict [29217,29226]
name: task_dict [29340,29349]
===
match
---
expr_stmt [6638,6676]
expr_stmt [6638,6676]
===
match
---
name: tuple [12230,12235]
name: tuple [12353,12358]
===
match
---
suite [28005,28962]
suite [28128,29085]
===
match
---
name: var [11128,11131]
name: var [11251,11254]
===
match
---
or_test [5802,5854]
or_test [5802,5854]
===
match
---
name: var [21177,21180]
name: var [21300,21303]
===
match
---
simple_stmt [2896,2925]
simple_stmt [2896,2925]
===
match
---
trailer [33761,33764]
trailer [33884,33887]
===
match
---
name: deps [16149,16153]
name: deps [16272,16276]
===
match
---
operator: -> [5571,5573]
operator: -> [5571,5573]
===
match
---
atom_expr [32858,32886]
atom_expr [32981,33009]
===
match
---
name: v [20133,20134]
name: v [20256,20257]
===
match
---
simple_stmt [9588,9641]
simple_stmt [9582,9635]
===
match
---
trailer [34016,34038]
trailer [34139,34161]
===
match
---
suite [24948,25398]
suite [25071,25521]
===
match
---
atom_expr [17465,17486]
atom_expr [17588,17609]
===
match
---
arglist [8494,8508]
arglist [8488,8502]
===
match
---
simple_stmt [22128,22164]
simple_stmt [22251,22287]
===
match
---
name: v [10796,10797]
name: v [10919,10920]
===
match
---
trailer [26626,26628]
trailer [26749,26751]
===
match
---
name: serialize_dag [26937,26950]
name: serialize_dag [27060,27073]
===
match
---
name: AirflowException [22320,22336]
name: AirflowException [22443,22459]
===
match
---
operator: -> [4699,4701]
operator: -> [4699,4701]
===
match
---
name: _CONSTRUCTOR_PARAMS [13752,13771]
name: _CONSTRUCTOR_PARAMS [13875,13894]
===
match
---
name: dag [30150,30153]
name: dag [30273,30276]
===
match
---
simple_stmt [5645,5692]
simple_stmt [5645,5692]
===
match
---
name: n [9484,9485]
name: n [9478,9479]
===
match
---
atom_expr [6040,6085]
atom_expr [6040,6085]
===
match
---
trailer [16405,16412]
trailer [16528,16535]
===
match
---
name: plugins_manager [17791,17806]
name: plugins_manager [17914,17929]
===
match
---
name: deserialize_task_group [33818,33840]
name: deserialize_task_group [33941,33963]
===
match
---
name: v [20198,20199]
name: v [20321,20322]
===
match
---
name: int [12526,12529]
name: int [12649,12652]
===
match
---
param [4988,5020]
param [4988,5020]
===
match
---
trailer [15452,15461]
trailer [15575,15584]
===
match
---
trailer [29393,29405]
trailer [29516,29528]
===
match
---
name: seconds [11740,11747]
name: seconds [11863,11870]
===
match
---
annassign [2273,2610]
annassign [2273,2610]
===
match
---
name: values [18877,18883]
name: values [19000,19006]
===
match
---
for_stmt [18897,20201]
for_stmt [19020,20324]
===
match
---
import_from [1417,1451]
import_from [1417,1451]
===
match
---
atom_expr [10985,10997]
atom_expr [11108,11120]
===
match
---
name: var [11817,11820]
name: var [11940,11943]
===
match
---
trailer [10307,10312]
trailer [10430,10435]
===
match
---
trailer [28591,28614]
trailer [28714,28737]
===
match
---
atom [33435,33580]
atom [33558,33703]
===
match
---
trailer [9209,9223]
trailer [9203,9217]
===
match
---
name: classmethod [17089,17100]
name: classmethod [17212,17223]
===
match
---
argument [11740,11751]
argument [11863,11874]
===
match
---
atom_expr [22173,22231]
atom_expr [22296,22354]
===
match
---
comparison [15861,15893]
comparison [15984,16016]
===
match
---
name: type_ [11154,11159]
name: type_ [11277,11282]
===
match
---
simple_stmt [12562,12605]
simple_stmt [12685,12728]
===
match
---
trailer [26438,26446]
trailer [26561,26569]
===
match
---
simple_stmt [8210,8221]
simple_stmt [8210,8221]
===
match
---
name: _encode [9124,9131]
name: _encode [9118,9125]
===
match
---
operator: , [10301,10302]
operator: , [10424,10425]
===
match
---
trailer [32868,32886]
trailer [32991,33009]
===
match
---
string: 'default_args' [26037,26051]
string: 'default_args' [26160,26174]
===
match
---
operator: @ [14911,14912]
operator: @ [15034,15035]
===
match
---
name: type_ [8607,8612]
name: type_ [8601,8606]
===
match
---
name: classmethod [3986,3997]
name: classmethod [3986,3997]
===
match
---
atom_expr [34147,34170]
atom_expr [34270,34293]
===
match
---
trailer [20487,20498]
trailer [20610,20621]
===
match
---
simple_stmt [25496,25990]
simple_stmt [25619,26113]
===
match
---
simple_stmt [29861,29962]
simple_stmt [29984,30085]
===
match
---
suite [18036,18355]
suite [18159,18478]
===
match
---
string: "label" [17454,17461]
string: "label" [17577,17584]
===
match
---
testlist_comp [33888,33898]
testlist_comp [34011,34021]
===
match
---
simple_stmt [840,852]
simple_stmt [840,852]
===
match
---
name: cls [26963,26966]
name: cls [27086,27089]
===
match
---
name: serialize_group [32038,32053]
name: serialize_group [32161,32176]
===
match
---
trailer [20840,20842]
trailer [20963,20965]
===
match
---
name: Dict [21804,21808]
name: Dict [21927,21931]
===
match
---
simple_stmt [22314,22359]
simple_stmt [22437,22482]
===
match
---
name: TYPE_CHECKING [2141,2154]
name: TYPE_CHECKING [2141,2154]
===
match
---
name: kwargs [33426,33432]
name: kwargs [33549,33555]
===
match
---
testlist_comp [3196,3214]
testlist_comp [3196,3214]
===
match
---
name: _deserialize [12241,12253]
name: _deserialize [12364,12376]
===
match
---
trailer [20037,20055]
trailer [20160,20178]
===
match
---
operator: , [20325,20326]
operator: , [20448,20449]
===
match
---
simple_stmt [852,867]
simple_stmt [852,867]
===
match
---
name: Dict [5574,5578]
name: Dict [5574,5578]
===
match
---
and_test [9334,9363]
and_test [9328,9357]
===
match
---
operator: , [17133,17134]
operator: , [17256,17257]
===
match
---
name: subdag [30508,30514]
name: subdag [30631,30637]
===
match
---
name: setattr [20516,20523]
name: setattr [20639,20646]
===
match
---
operator: = [1179,1180]
operator: = [1179,1180]
===
match
---
operator: = [17250,17251]
operator: = [17373,17374]
===
match
---
string: "airflow.ti_deps.deps." [21383,21406]
string: "airflow.ti_deps.deps." [21506,21529]
===
match
---
suite [17344,17487]
suite [17467,17610]
===
match
---
name: dag [21041,21044]
name: dag [21164,21167]
===
match
---
name: cls [6949,6952]
name: cls [6949,6952]
===
match
---
trailer [16587,16596]
trailer [16710,16719]
===
match
---
atom_expr [6514,6538]
atom_expr [6514,6538]
===
match
---
trailer [27084,27105]
trailer [27207,27228]
===
match
---
operator: = [3973,3974]
operator: = [3973,3974]
===
match
---
name: log [24047,24050]
name: log [24170,24173]
===
match
---
name: classmethod [5861,5872]
name: classmethod [5861,5872]
===
match
---
trailer [27105,27121]
trailer [27228,27244]
===
match
---
trailer [21562,21572]
trailer [21685,21695]
===
match
---
name: type [3330,3334]
name: type [3330,3334]
===
match
---
name: Union [4702,4707]
name: Union [4702,4707]
===
match
---
name: Dict [3665,3669]
name: Dict [3665,3669]
===
match
---
name: _serialize [9871,9881]
name: _serialize [9886,9896]
===
match
---
dotted_name [1654,1687]
dotted_name [1654,1687]
===
match
---
name: Encoding [10985,10993]
name: Encoding [11108,11116]
===
match
---
name: encoded_op [17333,17343]
name: encoded_op [17456,17466]
===
match
---
trailer [8596,8621]
trailer [8590,8615]
===
match
---
trailer [28500,28522]
trailer [28623,28645]
===
match
---
return_stmt [10771,10820]
return_stmt [10894,10943]
===
match
---
name: var [11748,11751]
name: var [11871,11874]
===
match
---
expr_stmt [28672,28704]
expr_stmt [28795,28827]
===
match
---
operator: = [15499,15500]
operator: = [15622,15623]
===
match
---
param [5732,5736]
param [5732,5736]
===
match
---
atom_expr [10252,10313]
atom_expr [10375,10436]
===
match
---
string: 'has_on_success_callback' [27422,27447]
string: 'has_on_success_callback' [27545,27570]
===
match
---
atom_expr [29931,29961]
atom_expr [30054,30084]
===
match
---
name: _primitive_types [3047,3063]
name: _primitive_types [3047,3063]
===
match
---
operator: , [12874,12875]
operator: , [12997,12998]
===
match
---
name: list [4055,4059]
name: list [4055,4059]
===
match
---
name: loads [4584,4589]
name: loads [4584,4589]
===
match
---
trailer [13709,13729]
trailer [13832,13852]
===
match
---
name: v [28523,28524]
name: v [28646,28647]
===
match
---
name: child [32575,32580]
name: child [32698,32703]
===
match
---
name: cls [20268,20271]
name: cls [20391,20394]
===
match
---
operator: ** [33663,33665]
operator: ** [33786,33788]
===
match
---
name: _datetime_types [3177,3192]
name: _datetime_types [3177,3192]
===
match
---
name: Dict [27816,27820]
name: Dict [27939,27943]
===
match
---
simple_stmt [31464,31519]
simple_stmt [31587,31642]
===
match
---
trailer [32780,32801]
trailer [32903,32924]
===
match
---
name: serialization [1662,1675]
name: serialization [1662,1675]
===
match
---
atom_expr [11912,11926]
atom_expr [12035,12049]
===
match
---
operator: ** [14389,14391]
operator: ** [14512,14514]
===
match
---
expr_stmt [19501,19569]
expr_stmt [19624,19692]
===
match
---
trailer [14884,14905]
trailer [15007,15028]
===
match
---
except_clause [1093,1111]
except_clause [1093,1111]
===
match
---
suite [33328,33353]
suite [33451,33476]
===
match
---
trailer [3946,3954]
trailer [3946,3954]
===
match
---
return_stmt [4901,4940]
return_stmt [4901,4940]
===
match
---
simple_stmt [19350,19383]
simple_stmt [19473,19506]
===
match
---
string: "__var" [7293,7300]
string: "__var" [7293,7300]
===
match
---
operator: , [8605,8606]
operator: , [8599,8600]
===
match
---
name: registered_operator_link_classes [22260,22292]
name: registered_operator_link_classes [22383,22415]
===
match
---
trailer [17950,17974]
trailer [18073,18097]
===
match
---
trailer [8975,8985]
trailer [8969,8979]
===
match
---
name: cls [12766,12769]
name: cls [12889,12892]
===
match
---
name: key [6761,6764]
name: key [6761,6764]
===
match
---
fstring_start: f' [5164,5166]
fstring_start: f' [5164,5166]
===
match
---
atom_expr [32676,32711]
atom_expr [32799,32834]
===
match
---
expr_stmt [20112,20135]
expr_stmt [20235,20258]
===
match
---
atom_expr [12230,12271]
atom_expr [12353,12394]
===
match
---
name: Set [2275,2278]
name: Set [2275,2278]
===
match
---
parameters [30941,30956]
parameters [31064,31079]
===
match
---
expr_stmt [15470,15524]
expr_stmt [15593,15647]
===
match
---
expr_stmt [33955,34040]
expr_stmt [34078,34163]
===
match
---
string: "operator_extra_links" [18821,18843]
string: "operator_extra_links" [18944,18966]
===
match
---
simple_stmt [29486,29511]
simple_stmt [29609,29634]
===
match
---
operator: } [26070,26071]
operator: } [26193,26194]
===
match
---
string: """Serializes an object to json""" [6595,6629]
string: """Serializes an object to json""" [6595,6629]
===
match
---
return_stmt [11801,11821]
return_stmt [11924,11944]
===
match
---
arglist [9607,9639]
arglist [9601,9633]
===
match
---
atom_expr [5147,5211]
atom_expr [5147,5211]
===
match
---
string: "prefix_group_id" [33515,33532]
string: "prefix_group_id" [33638,33655]
===
match
---
decorator [5697,5710]
decorator [5697,5710]
===
match
---
trailer [9018,9060]
trailer [9012,9054]
===
match
---
name: DICT [8351,8355]
name: DICT [8351,8355]
===
match
---
name: attrname [13772,13780]
name: attrname [13895,13903]
===
match
---
tfpdef [33092,33121]
tfpdef [33215,33244]
===
match
---
name: encoded_var [11015,11026]
name: encoded_var [11138,11149]
===
match
---
operator: = [11599,11600]
operator: = [11722,11723]
===
match
---
name: downstream_group_ids [32781,32801]
name: downstream_group_ids [32904,32924]
===
match
---
operator: } [14192,14193]
operator: } [14315,14316]
===
match
---
operator: , [17155,17156]
operator: , [17278,17279]
===
match
---
tfpdef [12876,12889]
tfpdef [12999,13012]
===
match
---
name: group_id [33626,33634]
name: group_id [33749,33757]
===
match
---
expr_stmt [11595,11641]
expr_stmt [11718,11764]
===
match
---
atom_expr [20248,20265]
atom_expr [20371,20388]
===
match
---
string: "_operator_extra_links" [19405,19428]
string: "_operator_extra_links" [19528,19551]
===
match
---
atom [16398,16432]
atom [16521,16555]
===
match
---
atom_expr [4702,4752]
atom_expr [4702,4752]
===
match
---
atom_expr [14264,14315]
atom_expr [14387,14438]
===
match
---
name: cls [33373,33376]
name: cls [33496,33499]
===
match
---
tfpdef [12864,12874]
tfpdef [12987,12997]
===
match
---
name: task [26991,26995]
name: task [27114,27118]
===
match
---
name: var [8446,8449]
name: var [8440,8443]
===
match
---
not_test [21359,21407]
not_test [21482,21530]
===
match
---
decorated [31817,33021]
decorated [31940,33144]
===
match
---
expr_stmt [16991,17053]
expr_stmt [17114,17176]
===
match
---
operator: == [18947,18949]
operator: == [19070,19072]
===
match
---
atom_expr [32083,32103]
atom_expr [32206,32226]
===
match
---
name: datetime [8967,8975]
name: datetime [8961,8969]
===
match
---
operator: , [11121,11122]
operator: , [11244,11245]
===
match
---
suite [9750,9915]
suite [9839,9930]
===
match
---
atom_expr [9622,9639]
atom_expr [9616,9633]
===
match
---
operator: = [21680,21681]
operator: = [21803,21804]
===
match
---
simple_stmt [27516,27564]
simple_stmt [27639,27687]
===
match
---
operator: - [20246,20247]
operator: - [20369,20370]
===
match
---
trailer [34180,34193]
trailer [34303,34316]
===
match
---
trailer [18141,18150]
trailer [18264,18273]
===
match
---
name: pod_generator [2012,2025]
name: pod_generator [2012,2025]
===
match
---
name: deserialize_operator [11298,11318]
name: deserialize_operator [11421,11441]
===
match
---
name: task_id [30879,30886]
name: task_id [31002,31009]
===
match
---
operator: = [8346,8347]
operator: = [8346,8347]
===
match
---
name: cls [7171,7174]
name: cls [7171,7174]
===
match
---
return_stmt [27576,27596]
return_stmt [27699,27719]
===
match
---
operator: + [16419,16420]
operator: + [16542,16543]
===
match
---
name: cls [19987,19990]
name: cls [20110,20113]
===
match
---
expr_stmt [18990,19000]
expr_stmt [19113,19123]
===
match
---
name: op [16825,16827]
name: op [16948,16950]
===
match
---
operator: = [9621,9622]
operator: = [9615,9616]
===
match
---
operator: = [2128,2129]
operator: = [2128,2129]
===
match
---
tfpdef [6493,6538]
tfpdef [6493,6538]
===
match
---
atom_expr [6356,6434]
atom_expr [6356,6434]
===
match
---
simple_stmt [10326,10342]
simple_stmt [10449,10465]
===
match
---
atom_expr [31905,31919]
atom_expr [32028,32042]
===
match
---
atom_expr [15876,15893]
atom_expr [15999,16016]
===
match
---
name: _serialize [26967,26977]
name: _serialize [27090,27100]
===
match
---
trailer [24050,24056]
trailer [24173,24179]
===
match
---
atom_expr [8499,8508]
atom_expr [8493,8502]
===
match
---
trailer [15888,15893]
trailer [16011,16016]
===
match
---
return_stmt [10173,10225]
return_stmt [10296,10348]
===
match
---
operator: == [11772,11774]
operator: == [11895,11897]
===
match
---
name: super [14408,14413]
name: super [14531,14536]
===
match
---
suite [12553,12605]
suite [12676,12728]
===
match
---
funcdef [10413,12361]
funcdef [10536,12484]
===
match
---
simple_stmt [7163,7193]
simple_stmt [7163,7193]
===
match
---
return_stmt [12747,12789]
return_stmt [12870,12912]
===
match
---
name: dag [30815,30818]
name: dag [30938,30941]
===
match
---
suite [6786,7349]
suite [6786,7349]
===
match
---
name: startswith [9296,9306]
name: startswith [9290,9300]
===
match
---
atom_expr [3932,3979]
atom_expr [3932,3979]
===
match
---
name: classmethod [3725,3736]
name: classmethod [3725,3736]
===
match
---
name: BaseOperator [14274,14286]
name: BaseOperator [14397,14409]
===
match
---
param [7473,7481]
param [7473,7481]
===
match
---
operator: = [22393,22394]
operator: = [22516,22517]
===
match
---
suite [30328,30412]
suite [30451,30535]
===
match
---
atom_expr [17252,17305]
atom_expr [17375,17428]
===
match
---
suite [27851,30908]
suite [27974,31031]
===
match
---
operator: , [32977,32978]
operator: , [33100,33101]
===
match
---
name: attrname [12849,12857]
name: attrname [12972,12980]
===
match
---
operator: , [31913,31914]
operator: , [32036,32037]
===
match
---
simple_stmt [23700,23764]
simple_stmt [23823,23887]
===
match
---
name: _encode [8280,8287]
name: _encode [8280,8287]
===
match
---
suite [30262,30412]
suite [30385,30535]
===
match
---
string: 'SerializedDAG' [31357,31372]
string: 'SerializedDAG' [31480,31495]
===
match
---
atom_expr [17999,18035]
atom_expr [18122,18158]
===
match
---
name: ProvidersManager [2848,2864]
name: ProvidersManager [2848,2864]
===
match
---
argument [11951,11966]
argument [12074,12089]
===
match
---
exprlist [14256,14260]
exprlist [14379,14383]
===
match
---
trailer [30047,30082]
trailer [30170,30205]
===
match
---
simple_stmt [22173,22232]
simple_stmt [22296,22355]
===
match
---
operator: { [26015,26016]
operator: { [26138,26139]
===
match
---
name: DAG [26481,26484]
name: DAG [26604,26607]
===
match
---
param [14382,14388]
param [14505,14511]
===
match
---
name: encoded [9607,9614]
name: encoded [9601,9608]
===
match
---
operator: , [5735,5736]
operator: , [5735,5736]
===
match
---
atom_expr [30482,30534]
atom_expr [30605,30657]
===
match
---
trailer [6901,6933]
trailer [6901,6933]
===
match
---
sync_comp_for [10799,10819]
sync_comp_for [10922,10942]
===
match
---
trailer [28389,28395]
trailer [28512,28518]
===
match
---
name: list [4442,4446]
name: list [4442,4446]
===
match
---
fstring_expr [16581,16597]
fstring_expr [16704,16720]
===
match
---
comparison [18945,18972]
comparison [19068,19095]
===
match
---
string: """Stringifies DAGs and operators contained by var and returns a dict of var.""" [4091,4171]
string: """Stringifies DAGs and operators contained by var and returns a dict of var.""" [4091,4171]
===
match
---
annassign [30183,30204]
annassign [30306,30327]
===
match
---
decorated [5697,5855]
decorated [5697,5855]
===
match
---
arglist [33841,33862]
arglist [33964,33985]
===
match
---
param [12673,12686]
param [12796,12809]
===
match
---
name: encoded_var [10808,10819]
name: encoded_var [10931,10942]
===
match
---
return_stmt [12223,12271]
return_stmt [12346,12394]
===
match
---
atom_expr [5224,5256]
atom_expr [5224,5256]
===
match
---
atom_expr [11063,11071]
atom_expr [11186,11194]
===
match
---
name: _json_schema [5374,5386]
name: _json_schema [5374,5386]
===
match
---
trailer [9010,9018]
trailer [9004,9012]
===
match
---
name: cls [13706,13709]
name: cls [13829,13832]
===
match
---
atom_expr [32940,32976]
atom_expr [33063,33099]
===
match
---
name: _load_operator_extra_links [19453,19479]
name: _load_operator_extra_links [19576,19602]
===
match
---
name: weekday [9476,9483]
name: weekday [9470,9477]
===
match
---
trailer [16942,16969]
trailer [17065,17092]
===
match
---
trailer [33840,33863]
trailer [33963,33986]
===
match
---
expr_stmt [25995,26071]
expr_stmt [26118,26194]
===
match
---
if_stmt [19446,19831]
if_stmt [19569,19954]
===
match
---
operator: = [8532,8533]
operator: = [8526,8527]
===
match
---
operator: } [6675,6676]
operator: } [6675,6676]
===
match
---
argument [17275,17304]
argument [17398,17427]
===
match
---
comparison [30282,30327]
comparison [30405,30450]
===
match
---
trailer [33989,34002]
trailer [34112,34125]
===
match
---
operator: @ [4612,4613]
operator: @ [4612,4613]
===
match
---
name: task_group [32858,32868]
name: task_group [32981,32991]
===
match
---
operator: , [6579,6580]
operator: , [6579,6580]
===
match
---
fstring_string: module  [16490,16497]
fstring_string: module  [16613,16620]
===
match
---
operator: , [6074,6075]
operator: , [6074,6075]
===
match
---
name: k [19400,19401]
name: k [19523,19524]
===
match
---
fstring_expr [27739,27753]
fstring_expr [27862,27876]
===
match
---
trailer [24986,24998]
trailer [25109,25121]
===
match
---
return_stmt [32017,32028]
return_stmt [32140,32151]
===
match
---
name: serialize_dag [27516,27529]
name: serialize_dag [27639,27652]
===
match
---
atom_expr [24300,24329]
atom_expr [24423,24452]
===
match
---
trailer [34002,34039]
trailer [34125,34162]
===
match
---
name: v [26466,26467]
name: v [26589,26590]
===
match
---
name: op [17247,17249]
name: op [17370,17372]
===
match
---
trailer [5678,5683]
trailer [5678,5683]
===
match
---
operator: , [4986,4987]
operator: , [4986,4987]
===
match
---
trailer [16281,16306]
trailer [16404,16429]
===
match
---
trailer [9123,9131]
trailer [9117,9125]
===
match
---
name: dumps [3937,3942]
name: dumps [3937,3942]
===
match
---
name: SerializationError [16334,16352]
name: SerializationError [16457,16475]
===
match
---
atom [13805,13807]
atom [13928,13930]
===
match
---
atom_expr [34267,34326]
atom_expr [34390,34449]
===
match
---
name: serializable_task [30861,30878]
name: serializable_task [30984,31001]
===
match
---
tfpdef [21245,21260]
tfpdef [21368,21383]
===
match
---
atom_expr [8924,8936]
atom_expr [8918,8930]
===
match
---
simple_stmt [26175,26383]
simple_stmt [26298,26506]
===
match
---
operator: = [23897,23898]
operator: = [24020,24021]
===
match
---
simple_stmt [8882,8938]
simple_stmt [8876,8932]
===
match
---
trailer [5465,5515]
trailer [5465,5515]
===
match
---
simple_stmt [15162,15190]
simple_stmt [15285,15313]
===
match
---
argument [21672,21685]
argument [21795,21808]
===
match
---
trailer [14328,14336]
trailer [14451,14459]
===
match
---
param [31332,31352]
param [31455,31475]
===
match
---
operator: , [32445,32446]
operator: , [32568,32569]
===
match
---
trailer [32324,32335]
trailer [32447,32458]
===
match
---
simple_stmt [10252,10314]
simple_stmt [10375,10437]
===
match
---
operator: = [31468,31469]
operator: = [31591,31592]
===
match
---
operator: = [20114,20115]
operator: = [20237,20238]
===
match
---
trailer [10738,10757]
trailer [10861,10880]
===
match
---
name: v [18998,18999]
name: v [19121,19122]
===
match
---
name: cls [12089,12092]
name: cls [12212,12215]
===
match
---
operator: = [2082,2083]
operator: = [2082,2083]
===
match
---
subscriptlist [27821,27829]
subscriptlist [27944,27952]
===
match
---
name: bool [5942,5946]
name: bool [5942,5946]
===
match
---
try_stmt [1056,1186]
try_stmt [1056,1186]
===
match
---
suite [21282,21712]
suite [21405,21835]
===
match
---
trailer [31238,31254]
trailer [31361,31377]
===
match
---
name: encoded_group [34003,34016]
name: encoded_group [34126,34139]
===
match
---
if_stmt [20473,20541]
if_stmt [20596,20664]
===
match
---
simple_stmt [9238,9319]
simple_stmt [9232,9313]
===
match
---
operator: } [27752,27753]
operator: } [27875,27876]
===
match
---
atom [28548,28566]
atom [28671,28689]
===
match
---
string: '_access_control' [26053,26070]
string: '_access_control' [26176,26193]
===
match
---
strings [16378,16513]
strings [16501,16636]
===
match
---
operator: , [3786,3787]
operator: , [3786,3787]
===
match
---
name: k [18945,18946]
name: k [19068,19069]
===
match
---
suite [14399,14906]
suite [14522,15029]
===
match
---
name: signature [14264,14273]
name: signature [14387,14396]
===
match
---
name: json_schema [1676,1687]
name: json_schema [1676,1687]
===
match
---
name: _load_operator_extra_links [28198,28224]
name: _load_operator_extra_links [28321,28347]
===
match
---
operator: , [6414,6415]
operator: , [6414,6415]
===
match
---
parameters [26125,26127]
parameters [26248,26250]
===
match
---
operator: { [22395,22396]
operator: { [22518,22519]
===
match
---
for_stmt [30091,30888]
for_stmt [30214,31011]
===
match
---
return_stmt [25407,25444]
return_stmt [25530,25567]
===
match
---
simple_stmt [908,990]
simple_stmt [908,990]
===
match
---
operator: = [17573,17574]
operator: = [17696,17697]
===
match
---
name: DAG [4030,4033]
name: DAG [4030,4033]
===
match
---
operator: } [2609,2610]
operator: } [2609,2610]
===
match
---
operator: , [21812,21813]
operator: , [21935,21936]
===
match
---
name: items [11132,11137]
name: items [11255,11260]
===
match
---
simple_stmt [6595,6630]
simple_stmt [6595,6630]
===
match
---
name: typing [913,919]
name: typing [913,919]
===
match
---
trailer [9851,9859]
trailer [9866,9874]
===
match
---
name: Logger [3310,3316]
name: Logger [3310,3316]
===
match
---
trailer [28701,28704]
trailer [28824,28827]
===
match
---
simple_stmt [17063,17083]
simple_stmt [17186,17206]
===
match
---
name: encoded_op [20248,20258]
name: encoded_op [20371,20381]
===
match
---
trailer [2230,2240]
trailer [2230,2240]
===
match
---
tfpdef [12517,12529]
tfpdef [12640,12652]
===
match
---
name: op [16421,16423]
name: op [16544,16546]
===
match
---
trailer [8311,8314]
trailer [8311,8314]
===
match
---
arglist [10739,10756]
arglist [10862,10879]
===
match
---
name: fileloc [30074,30081]
name: fileloc [30197,30204]
===
match
---
name: type_ [9616,9621]
name: type_ [9610,9615]
===
match
---
simple_stmt [13837,13849]
simple_stmt [13960,13972]
===
match
---
atom_expr [11952,11966]
atom_expr [12075,12089]
===
match
---
trailer [24998,25019]
trailer [25121,25142]
===
match
---
arglist [24225,24251]
arglist [24348,24374]
===
match
---
fstring_format_spec [5194,5196]
fstring_format_spec [5194,5196]
===
match
---
string: "Cannot deserialize POD objects without kubernetes libraries installed!" [11509,11581]
string: "Cannot deserialize POD objects without kubernetes libraries installed!" [11632,11704]
===
match
---
atom [32361,32625]
atom [32484,32748]
===
match
---
argument [8341,8355]
argument [8341,8355]
===
match
---
name: encoded_op [18781,18791]
name: encoded_op [18904,18914]
===
match
---
name: TaskGroup [33228,33237]
name: TaskGroup [33351,33360]
===
match
---
name: serializable_task [30357,30374]
name: serializable_task [30480,30497]
===
match
---
name: type [16179,16183]
name: type [16302,16306]
===
match
---
suite [20798,21196]
suite [20921,21319]
===
match
---
operator: , [7471,7472]
operator: , [7471,7472]
===
match
---
simple_stmt [26685,26718]
simple_stmt [26808,26841]
===
match
---
name: cls [5103,5106]
name: cls [5103,5106]
===
match
---
name: PodGenerator [8534,8546]
name: PodGenerator [8528,8540]
===
match
---
name: dict [31348,31352]
name: dict [31471,31475]
===
match
---
operator: , [5668,5669]
operator: , [5668,5669]
===
match
---
simple_stmt [24164,24253]
simple_stmt [24287,24376]
===
match
---
param [15235,15239]
param [15358,15362]
===
match
---
arglist [30395,30409]
arglist [30518,30532]
===
match
---
name: task_group [32223,32233]
name: task_group [32346,32356]
===
match
---
name: classmethod [26724,26735]
name: classmethod [26847,26858]
===
match
---
name: object_to_serialize [6493,6512]
name: object_to_serialize [6493,6512]
===
match
---
name: v [19983,19984]
name: v [20106,20107]
===
match
---
trailer [19889,19891]
trailer [20012,20014]
===
match
---
trailer [10984,10998]
trailer [11107,11121]
===
match
---
arglist [8962,8985]
arglist [8956,8979]
===
match
---
name: logging [2223,2230]
name: logging [2223,2230]
===
match
---
trailer [18330,18337]
trailer [18453,18460]
===
match
---
trailer [5335,5356]
trailer [5335,5356]
===
match
---
trailer [31123,31137]
trailer [31246,31260]
===
match
---
name: deserialize_operator [28369,28389]
name: deserialize_operator [28492,28512]
===
match
---
name: serialized_obj [5296,5310]
name: serialized_obj [5296,5310]
===
match
---
trailer [32928,32939]
trailer [33051,33062]
===
match
---
name: dict [5015,5019]
name: dict [5015,5019]
===
match
---
name: ope [17992,17995]
name: ope [18115,18118]
===
match
---
name: timedelta [12543,12552]
name: timedelta [12666,12675]
===
match
---
name: models [1970,1976]
name: models [1970,1976]
===
match
---
name: k [30022,30023]
name: k [30145,30146]
===
match
---
atom_expr [30282,30319]
atom_expr [30405,30442]
===
match
---
atom_expr [18304,18354]
atom_expr [18427,18477]
===
match
---
name: v [28324,28325]
name: v [28447,28448]
===
match
---
name: _operator_link_class_path [23627,23652]
name: _operator_link_class_path [23750,23775]
===
match
---
comparison [26529,26553]
comparison [26652,26676]
===
match
---
name: update [24292,24298]
name: update [24415,24421]
===
match
---
name: encoded_op [17443,17453]
name: encoded_op [17566,17576]
===
match
---
suite [20460,20541]
suite [20583,20664]
===
match
---
raise_stmt [11490,11582]
raise_stmt [11613,11705]
===
match
---
comparison [11054,11071]
comparison [11177,11194]
===
match
---
string: 'executor_config' [14175,14192]
string: 'executor_config' [14298,14315]
===
match
---
arglist [6276,6299]
arglist [6276,6299]
===
match
---
param [5909,5923]
param [5909,5923]
===
match
---
string: 'BaseSerialization' [4415,4434]
string: 'BaseSerialization' [4415,4434]
===
match
---
name: serialize_op [15339,15351]
name: serialize_op [15462,15474]
===
match
---
arglist [33617,33671]
arglist [33740,33794]
===
match
---
name: v [28959,28960]
name: v [29082,29083]
===
match
---
name: cls [20116,20119]
name: cls [20239,20242]
===
match
---
name: template_field [16950,16964]
name: template_field [17073,17087]
===
match
---
simple_stmt [10967,10999]
simple_stmt [11090,11122]
===
match
---
name: cls [6356,6359]
name: cls [6356,6359]
===
match
---
name: HAS_KUBERNETES [2067,2081]
name: HAS_KUBERNETES [2067,2081]
===
match
---
parameters [7467,7482]
parameters [7467,7482]
===
match
---
operator: = [27939,27940]
operator: = [28062,28063]
===
match
---
fstring_end: ' [16597,16598]
fstring_end: ' [16720,16721]
===
match
---
name: var [8646,8649]
name: var [8640,8643]
===
match
---
operator: , [6665,6666]
operator: , [6665,6666]
===
match
---
arglist [20633,20690]
arglist [20756,20813]
===
match
---
trailer [5286,5295]
trailer [5286,5295]
===
match
---
trailer [32664,32675]
trailer [32787,32798]
===
match
---
operator: , [3798,3799]
operator: , [3798,3799]
===
match
---
trailer [8546,8560]
trailer [8540,8554]
===
match
---
name: pendulum [1011,1019]
name: pendulum [1011,1019]
===
match
---
decorator [15195,15208]
decorator [15318,15331]
===
match
---
name: attrname [12754,12762]
name: attrname [12877,12885]
===
match
---
string: 'schedule_interval' [26016,26035]
string: 'schedule_interval' [26139,26158]
===
match
---
name: dag [29459,29462]
name: dag [29582,29585]
===
match
---
name: baseoperator [1317,1329]
name: baseoperator [1317,1329]
===
match
---
trailer [26877,26895]
trailer [27000,27018]
===
match
---
atom_expr [15758,15848]
atom_expr [15881,15971]
===
match
---
string: "_operator_extra_links" [18750,18773]
string: "_operator_extra_links" [18873,18896]
===
match
---
name: op [20488,20490]
name: op [20611,20613]
===
match
---
trailer [11690,11700]
trailer [11813,11823]
===
match
---
trailer [19314,19323]
trailer [19437,19446]
===
match
---
string: 'full_filepath' [30053,30068]
string: 'full_filepath' [30176,30191]
===
match
---
simple_stmt [17742,17778]
simple_stmt [17865,17901]
===
match
---
simple_stmt [15285,15331]
simple_stmt [15408,15454]
===
match
---
atom_expr [8483,8509]
atom_expr [8477,8503]
===
match
---
name: r [16510,16511]
name: r [16633,16634]
===
match
---
atom_expr [9533,9551]
atom_expr [9527,9545]
===
match
---
simple_stmt [19501,19570]
simple_stmt [19624,19693]
===
match
---
expr_stmt [26858,26923]
expr_stmt [26981,27046]
===
match
---
trailer [14788,14804]
trailer [14911,14927]
===
match
---
operator: , [33543,33544]
operator: , [33666,33667]
===
match
---
name: items [9279,9284]
name: items [9273,9278]
===
match
---
name: DAT [32387,32390]
name: DAT [32510,32513]
===
match
---
suite [19480,19758]
suite [19603,19881]
===
match
---
name: tuple [4453,4458]
name: tuple [4453,4458]
===
match
---
suite [19779,19831]
suite [19902,19954]
===
match
---
expr_stmt [30551,30592]
expr_stmt [30674,30715]
===
match
---
trailer [15482,15498]
trailer [15605,15621]
===
match
---
atom_expr [28329,28344]
atom_expr [28452,28467]
===
match
---
name: _is_primitive [10656,10669]
name: _is_primitive [10779,10792]
===
match
---
operator: , [12671,12672]
operator: , [12794,12795]
===
match
---
atom_expr [21624,21686]
atom_expr [21747,21809]
===
match
---
name: serialize_operator_extra_links [25127,25157]
name: serialize_operator_extra_links [25250,25280]
===
match
---
name: _deserialize_deps [21222,21239]
name: _deserialize_deps [21345,21362]
===
match
---
fstring_string:  with `deps` from non-core  [16435,16462]
fstring_string:  with `deps` from non-core  [16558,16585]
===
match
---
atom_expr [20068,20094]
atom_expr [20191,20217]
===
match
---
operator: , [32241,32242]
operator: , [32364,32365]
===
match
---
trailer [16224,16235]
trailer [16347,16358]
===
match
---
operator: @ [17088,17089]
operator: @ [17211,17212]
===
match
---
name: _serialize [7111,7121]
name: _serialize [7111,7121]
===
match
---
name: k [19018,19019]
name: k [19141,19142]
===
match
---
trailer [9483,9485]
trailer [9477,9479]
===
match
---
name: Any [10456,10459]
name: Any [10579,10582]
===
match
---
atom_expr [26481,26493]
atom_expr [26604,26616]
===
match
---
name: __name__ [2241,2249]
name: __name__ [2241,2249]
===
match
---
suite [28107,28443]
suite [28230,28566]
===
match
---
atom_expr [11808,11821]
atom_expr [11931,11944]
===
match
---
trailer [3936,3942]
trailer [3936,3942]
===
match
---
operator: = [29101,29102]
operator: = [29224,29225]
===
match
---
trailer [6247,6275]
trailer [6247,6275]
===
match
---
atom_expr [8635,8655]
atom_expr [8629,8649]
===
match
---
trailer [6746,6748]
trailer [6746,6748]
===
match
---
arglist [20670,20688]
arglist [20793,20811]
===
match
---
name: op [20219,20221]
name: op [20342,20344]
===
match
---
name: isinstance [9180,9190]
name: isinstance [9174,9184]
===
match
---
atom_expr [28943,28961]
atom_expr [29066,29084]
===
match
---
name: _serialize [7457,7467]
name: _serialize [7457,7467]
===
match
---
name: key [33485,33488]
name: key [33608,33611]
===
match
---
name: _deserialize [10783,10795]
name: _deserialize [10906,10918]
===
match
---
exprlist [33880,33899]
exprlist [34003,34022]
===
match
---
name: airflow [1816,1823]
name: airflow [1816,1823]
===
match
---
simple_stmt [3925,3980]
simple_stmt [3925,3980]
===
match
---
trailer [23914,23947]
trailer [24037,24070]
===
match
---
simple_stmt [3696,3719]
simple_stmt [3696,3719]
===
match
---
name: op_extra_links_from_plugin [18719,18745]
name: op_extra_links_from_plugin [18842,18868]
===
match
---
string: """         Deserialize Operator Links if the Classes  are registered in Airflow Plugins.         Error is raised if the OperatorLink is not found in Plugins too.          :param encoded_op_links: Serialized Operator Link         :return: De-Serialized Operator Link         """ [21841,22119]
string: """         Deserialize Operator Links if the Classes  are registered in Airflow Plugins.         Error is raised if the OperatorLink is not found in Plugins too.          :param encoded_op_links: Serialized Operator Link         :return: De-Serialized Operator Link         """ [21964,22242]
===
match
---
operator: , [5831,5832]
operator: , [5831,5832]
===
match
---
name: Encoding [5670,5678]
name: Encoding [5670,5678]
===
match
---
name: deps [16553,16557]
name: deps [16676,16680]
===
match
---
for_stmt [20210,20333]
for_stmt [20333,20456]
===
match
---
expr_stmt [7082,7128]
expr_stmt [7082,7128]
===
match
---
comparison [29043,29071]
comparison [29166,29194]
===
match
---
string: "start_date" [30236,30248]
string: "start_date" [30359,30371]
===
match
---
name: task [28390,28394]
name: task [28513,28517]
===
match
---
simple_stmt [30482,30535]
simple_stmt [30605,30658]
===
match
---
simple_stmt [25995,26072]
simple_stmt [26118,26195]
===
match
---
tfpdef [31332,31352]
tfpdef [31455,31475]
===
match
---
name: cls [33079,33082]
name: cls [33202,33205]
===
match
---
trailer [34301,34324]
trailer [34424,34447]
===
match
---
trailer [8904,8914]
trailer [8898,8908]
===
match
---
if_stmt [16252,16536]
if_stmt [16375,16659]
===
match
---
fstring_start: f" [16378,16380]
fstring_start: f" [16501,16503]
===
match
---
name: _decorated_fields [20038,20055]
name: _decorated_fields [20161,20178]
===
match
---
name: DagAttributeTypes [1547,1564]
name: DagAttributeTypes [1547,1564]
===
match
---
atom_expr [18850,18885]
atom_expr [18973,19008]
===
match
---
name: get_serialized_fields [29884,29905]
name: get_serialized_fields [30007,30028]
===
match
---
name: items [27013,27018]
name: items [27136,27141]
===
match
---
operator: + [16413,16414]
operator: + [16536,16537]
===
match
---
trailer [15683,15704]
trailer [15806,15827]
===
match
---
trailer [11915,11926]
trailer [12038,12049]
===
match
---
trailer [4707,4752]
trailer [4707,4752]
===
match
---
string: "_downstream_task_ids" [28026,28048]
string: "_downstream_task_ids" [28149,28171]
===
match
---
name: BaseOperatorLink [21814,21830]
name: BaseOperatorLink [21937,21953]
===
match
---
name: type [10938,10942]
name: type [11061,11065]
===
match
---
atom_expr [34271,34325]
atom_expr [34394,34448]
===
match
---
simple_stmt [25127,25398]
simple_stmt [25250,25521]
===
match
---
name: var [3758,3761]
name: var [3758,3761]
===
match
---
string: """Serializes TaskGroup into a JSON object.""" [31931,31977]
string: """Serializes TaskGroup into a JSON object.""" [32054,32100]
===
match
---
name: str [17152,17155]
name: str [17275,17278]
===
match
---
name: get [26426,26429]
name: get [26549,26552]
===
match
---
trailer [33686,33695]
trailer [33809,33818]
===
match
---
operator: == [11160,11162]
operator: == [11283,11285]
===
match
---
decorated [3724,3980]
decorated [3724,3980]
===
match
---
name: BaseOperator [6520,6532]
name: BaseOperator [6520,6532]
===
match
---
trailer [30837,30856]
trailer [30960,30979]
===
match
---
import_name [1004,1019]
import_name [1004,1019]
===
match
---
name: enum [847,851]
name: enum [847,851]
===
match
---
fstring_end: " [31633,31634]
fstring_end: " [31756,31757]
===
match
---
operator: = [28429,28430]
operator: = [28552,28553]
===
match
---
operator: } [25113,25114]
operator: } [25236,25237]
===
match
---
name: serialize_template_field [17022,17046]
name: serialize_template_field [17145,17169]
===
match
---
name: exc_info [21672,21680]
name: exc_info [21795,21803]
===
match
---
param [14939,14943]
param [15062,15066]
===
match
---
trailer [15730,15755]
trailer [15853,15878]
===
match
---
param [20750,20754]
param [20873,20877]
===
match
---
simple_stmt [25092,25115]
simple_stmt [25215,25238]
===
match
---
suite [12899,13870]
suite [13022,13993]
===
match
---
name: set [34173,34176]
name: set [34296,34299]
===
match
---
operator: = [6672,6673]
operator: = [6672,6673]
===
match
---
atom_expr [21549,21574]
atom_expr [21672,21697]
===
match
---
name: deserialize_model_dict [11614,11636]
name: deserialize_model_dict [11737,11759]
===
match
---
tfpdef [26763,26771]
tfpdef [26886,26894]
===
match
---
return_stmt [11184,11225]
return_stmt [11307,11348]
===
match
---
name: BaseOperator [1337,1349]
name: BaseOperator [1337,1349]
===
match
---
atom_expr [29817,29844]
atom_expr [29940,29967]
===
match
---
operator: { [12088,12089]
operator: { [12211,12212]
===
match
---
name: dict [4729,4733]
name: dict [4729,4733]
===
match
---
simple_stmt [11007,11042]
simple_stmt [11130,11165]
===
match
---
name: isinstance [8635,8645]
name: isinstance [8629,8639]
===
match
---
name: to_dict [3947,3954]
name: to_dict [3947,3954]
===
match
---
name: DAT [8347,8350]
name: DAT [8347,8350]
===
match
---
expr_stmt [3283,3335]
expr_stmt [3283,3335]
===
match
---
arglist [30490,30533]
arglist [30613,30656]
===
match
---
trailer [3309,3316]
trailer [3309,3316]
===
match
---
parameters [4379,4405]
parameters [4379,4405]
===
match
---
name: op_predefined_extra_links [19857,19882]
name: op_predefined_extra_links [19980,20005]
===
match
---
name: List [21251,21255]
name: List [21374,21378]
===
match
---
name: add [21545,21548]
name: add [21668,21671]
===
match
---
operator: , [9259,9260]
operator: , [9253,9254]
===
match
---
atom_expr [27239,27252]
atom_expr [27362,27375]
===
match
---
name: dict [5251,5255]
name: dict [5251,5255]
===
match
---
atom_expr [27816,27830]
atom_expr [27939,27953]
===
match
---
trailer [23825,23858]
trailer [23948,23981]
===
match
---
atom [13809,13811]
atom [13932,13934]
===
match
---
name: task_id [16424,16431]
name: task_id [16547,16554]
===
match
---
name: json_pod [8597,8605]
name: json_pod [8591,8599]
===
match
---
suite [21607,21687]
suite [21730,21810]
===
match
---
import_as_names [1260,1296]
import_as_names [1260,1296]
===
match
---
string: """Stringifies DAGs and operators contained by var and returns a dict of var.""" [30974,31054]
string: """Stringifies DAGs and operators contained by var and returns a dict of var.""" [31097,31177]
===
match
---
name: template_fields [20444,20459]
name: template_fields [20567,20582]
===
match
---
trailer [10255,10261]
trailer [10378,10384]
===
match
---
decorated [4946,5516]
decorated [4946,5516]
===
match
---
trailer [32691,32710]
trailer [32814,32833]
===
match
---
simple_stmt [20312,20333]
simple_stmt [20435,20456]
===
match
---
except_clause [27658,27674]
except_clause [27781,27797]
===
match
---
operator: = [15756,15757]
operator: = [15879,15880]
===
match
---
name: from_dict [31317,31326]
name: from_dict [31440,31449]
===
match
---
suite [3820,3980]
suite [3820,3980]
===
match
---
atom_expr [10070,10087]
atom_expr [9996,10013]
===
match
---
name: TypeError [5456,5465]
name: TypeError [5456,5465]
===
match
---
annassign [24188,24252]
annassign [24311,24375]
===
match
---
return_stmt [20701,20710]
return_stmt [20824,20833]
===
match
---
simple_stmt [23876,24013]
simple_stmt [23999,24136]
===
match
---
name: children [32595,32603]
name: children [32718,32726]
===
match
---
trailer [21635,21686]
trailer [21758,21809]
===
match
---
name: encoded_var [10435,10446]
name: encoded_var [10558,10569]
===
match
---
tfpdef [17135,17161]
tfpdef [17258,17284]
===
match
---
operator: , [33555,33556]
operator: , [33678,33679]
===
match
---
tfpdef [33174,33208]
tfpdef [33297,33331]
===
match
---
name: Any [12683,12686]
name: Any [12806,12809]
===
match
---
atom_expr [9729,9749]
atom_expr [9723,9743]
===
match
---
name: keys_to_set_none [29979,29995]
name: keys_to_set_none [30102,30118]
===
match
---
trailer [32675,32712]
trailer [32798,32835]
===
match
---
name: v [20009,20010]
name: v [20132,20133]
===
match
---
trailer [29820,29844]
trailer [29943,29967]
===
match
---
fstring_start: f" [31590,31592]
fstring_start: f" [31713,31715]
===
match
---
atom_expr [32499,32546]
atom_expr [32622,32669]
===
match
---
name: value [16861,16866]
name: value [16984,16989]
===
match
---
atom_expr [32387,32393]
atom_expr [32510,32516]
===
match
---
operator: , [20681,20682]
operator: , [20804,20805]
===
match
---
suite [16844,17054]
suite [16967,17177]
===
match
---
suite [19032,19086]
suite [19155,19209]
===
match
---
name: object_to_serialize [6902,6921]
name: object_to_serialize [6902,6921]
===
match
---
simple_stmt [1507,1582]
simple_stmt [1507,1582]
===
match
---
name: enums [1534,1539]
name: enums [1534,1539]
===
match
---
trailer [8244,8255]
trailer [8244,8255]
===
match
---
trailer [20119,20132]
trailer [20242,20255]
===
match
---
arglist [16877,16901]
arglist [17000,17024]
===
match
---
name: cls [5370,5373]
name: cls [5370,5373]
===
match
---
name: var [9334,9337]
name: var [9328,9331]
===
match
---
operator: , [32573,32574]
operator: , [32696,32697]
===
match
---
operator: , [30051,30052]
operator: , [30174,30175]
===
match
---
comp_op [15869,15875]
comp_op [15992,15998]
===
match
---
decorated [3985,4344]
decorated [3985,4344]
===
match
---
name: isinstance [10133,10143]
name: isinstance [10256,10266]
===
match
---
name: k [26463,26464]
name: k [26586,26587]
===
match
---
string: '_task_type' [15424,15436]
string: '_task_type' [15547,15559]
===
match
---
name: Encoding [1573,1581]
name: Encoding [1573,1581]
===
match
---
atom_expr [30551,30585]
atom_expr [30674,30708]
===
match
---
name: ui_color [14693,14701]
name: ui_color [14816,14824]
===
match
---
simple_stmt [18304,18355]
simple_stmt [18427,18478]
===
match
---
name: op_extra_links_from_plugin [19730,19756]
name: op_extra_links_from_plugin [19853,19879]
===
match
---
atom [19108,19170]
atom [19231,19293]
===
match
---
suite [26781,27756]
suite [26904,27879]
===
match
---
name: startswith [21372,21382]
name: startswith [21495,21505]
===
match
---
suite [31373,31694]
suite [31496,31817]
===
match
---
name: classmethod [21718,21729]
name: classmethod [21841,21852]
===
match
---
trailer [23605,23607]
trailer [23728,23730]
===
match
---
exprlist [8319,8323]
exprlist [8319,8323]
===
match
---
string: "ui_color" [32255,32265]
string: "ui_color" [32378,32388]
===
match
---
atom_expr [16926,16969]
atom_expr [17049,17092]
===
match
---
atom_expr [23899,24012]
atom_expr [24022,24135]
===
match
---
name: Dict [947,951]
name: Dict [947,951]
===
match
---
name: log [10252,10255]
name: log [10375,10378]
===
match
---
for_stmt [24900,25398]
for_stmt [25023,25521]
===
match
---
name: dag [30144,30147]
name: dag [30267,30270]
===
match
---
if_stmt [7209,7302]
if_stmt [7209,7302]
===
match
---
name: var [11637,11640]
name: var [11760,11763]
===
match
---
simple_stmt [1020,1055]
simple_stmt [1020,1055]
===
match
---
atom_expr [3302,3316]
atom_expr [3302,3316]
===
match
---
simple_stmt [16991,17054]
simple_stmt [17114,17177]
===
match
---
operator: { [31075,31076]
operator: { [31198,31199]
===
match
---
name: var [20755,20758]
name: var [20878,20881]
===
match
---
name: _task_type [15079,15089]
name: _task_type [15202,15212]
===
match
---
atom_expr [19053,19085]
atom_expr [19176,19208]
===
match
---
operator: -> [30957,30959]
operator: -> [31080,31082]
===
match
---
name: Any [12871,12874]
name: Any [12994,12997]
===
match
---
atom_expr [19244,19273]
atom_expr [19367,19396]
===
match
---
operator: , [6330,6331]
operator: , [6330,6331]
===
match
---
trailer [9190,9224]
trailer [9184,9218]
===
match
---
expr_stmt [19800,19830]
expr_stmt [19923,19953]
===
match
---
trailer [21040,21044]
trailer [21163,21167]
===
match
---
trailer [5400,5406]
trailer [5400,5406]
===
match
---
param [30947,30955]
param [31070,31078]
===
match
---
trailer [9295,9306]
trailer [9289,9300]
===
match
---
string: "_task_group" [29043,29056]
string: "_task_group" [29166,29179]
===
match
---
expr_stmt [1154,1185]
expr_stmt [1154,1185]
===
match
---
atom_expr [5574,5593]
atom_expr [5574,5593]
===
match
---
simple_stmt [7318,7349]
simple_stmt [7318,7349]
===
match
---
atom_expr [7171,7192]
atom_expr [7171,7192]
===
match
---
for_stmt [30606,30888]
for_stmt [30729,31011]
===
match
---
operator: -> [26773,26775]
operator: -> [26896,26898]
===
match
---
name: DAT [9622,9625]
name: DAT [9616,9619]
===
match
---
name: instance [6416,6424]
name: instance [6416,6424]
===
match
---
operator: { [16581,16582]
operator: { [16704,16705]
===
match
---
simple_stmt [6886,6934]
simple_stmt [6886,6934]
===
match
---
trailer [7099,7104]
trailer [7099,7104]
===
match
---
operator: } [12121,12122]
operator: } [12244,12245]
===
match
---
atom [14174,14193]
atom [14297,14316]
===
match
---
name: _is_constructor_param [12631,12652]
name: _is_constructor_param [12754,12775]
===
match
---
name: SERIALIZER_VERSION [31541,31559]
name: SERIALIZER_VERSION [31664,31682]
===
match
---
atom_expr [34173,34230]
atom_expr [34296,34353]
===
match
---
param [31327,31331]
param [31450,31454]
===
match
---
operator: = [33696,33697]
operator: = [33819,33820]
===
match
---
trailer [33111,33121]
trailer [33234,33244]
===
match
---
name: deps [16635,16639]
name: deps [16758,16762]
===
match
---
simple_stmt [21425,21476]
simple_stmt [21548,21599]
===
match
---
operator: { [5181,5182]
operator: { [5181,5182]
===
match
---
operator: = [8923,8924]
operator: = [8917,8918]
===
match
---
arglist [28951,28960]
arglist [29074,29083]
===
match
---
operator: , [6538,6539]
operator: , [6538,6539]
===
match
---
parameters [4642,4698]
parameters [4642,4698]
===
match
---
trailer [16564,16599]
trailer [16687,16722]
===
match
---
comparison [19239,19273]
comparison [19362,19396]
===
match
---
name: var [9085,9088]
name: var [9079,9082]
===
match
---
atom_expr [5370,5423]
atom_expr [5370,5423]
===
match
---
atom_expr [21303,21308]
atom_expr [21426,21431]
===
match
---
name: SerializedDAG [8676,8689]
name: SerializedDAG [8670,8683]
===
match
---
trailer [18337,18354]
trailer [18460,18477]
===
match
---
name: weekday [9338,9345]
name: weekday [9332,9339]
===
match
---
trailer [11220,11225]
trailer [11343,11348]
===
match
---
name: group [33846,33851]
name: group [33969,33974]
===
match
---
name: _is_excluded [21164,21176]
name: _is_excluded [21287,21299]
===
match
---
name: var [10144,10147]
name: var [10267,10270]
===
match
---
atom_expr [17791,17849]
atom_expr [17914,17972]
===
match
---
name: task_dict [30107,30116]
name: task_dict [30230,30239]
===
match
---
name: serialized_object [7364,7381]
name: serialized_object [7364,7381]
===
match
---
trailer [34098,34137]
trailer [34221,34260]
===
match
---
atom [3301,3335]
atom [3301,3335]
===
match
---
import_as_name [1547,1571]
import_as_name [1547,1571]
===
match
---
name: _excluded_types [6336,6351]
name: _excluded_types [6336,6351]
===
match
---
decorator [31296,31309]
decorator [31419,31432]
===
match
---
fstring_end: ' [27753,27754]
fstring_end: ' [27876,27877]
===
match
---
name: dag [27106,27109]
name: dag [27229,27232]
===
match
---
suite [11072,11141]
suite [11195,11264]
===
match
---
operator: , [26761,26762]
operator: , [26884,26885]
===
match
---
name: encoded_dag [27985,27996]
name: encoded_dag [28108,28119]
===
match
---
name: dag [26763,26766]
name: dag [26886,26889]
===
match
---
trailer [5395,5423]
trailer [5395,5423]
===
match
---
atom_expr [14784,14804]
atom_expr [14907,14927]
===
match
---
name: attrname [6066,6074]
name: attrname [6066,6074]
===
match
---
atom_expr [5103,5119]
atom_expr [5103,5119]
===
match
---
arglist [25244,25324]
arglist [25367,25447]
===
match
---
suite [2108,2136]
suite [2108,2136]
===
match
---
subscriptlist [5579,5592]
subscriptlist [5579,5592]
===
match
---
operator: == [28462,28464]
operator: == [28585,28587]
===
match
---
name: cls [10779,10782]
name: cls [10902,10905]
===
match
---
expr_stmt [7163,7192]
expr_stmt [7163,7192]
===
match
---
name: serialized_object [6638,6655]
name: serialized_object [6638,6655]
===
match
---
name: v [19848,19849]
name: v [19971,19972]
===
match
---
name: list [4735,4739]
name: list [4735,4739]
===
match
---
arglist [14425,14440]
arglist [14548,14563]
===
match
---
funcdef [15117,15190]
funcdef [15240,15313]
===
match
---
operator: , [9145,9146]
operator: , [9139,9140]
===
match
---
trailer [19729,19757]
trailer [19852,19880]
===
match
---
simple_stmt [23538,23612]
simple_stmt [23661,23735]
===
match
---
name: cls [28833,28836]
name: cls [28956,28959]
===
match
---
operator: , [31111,31112]
operator: , [31234,31235]
===
match
---
operator: , [9470,9471]
operator: , [9464,9465]
===
match
---
fstring_start: f" [10897,10899]
fstring_start: f" [11020,11022]
===
match
---
trailer [12030,12037]
trailer [12153,12160]
===
match
---
string: "edge_info" [27224,27235]
string: "edge_info" [27347,27358]
===
match
---
name: utils [1769,1774]
name: utils [1769,1774]
===
match
---
operator: , [8916,8917]
operator: , [8910,8911]
===
match
---
name: var [10337,10340]
name: var [10460,10463]
===
match
---
fstring [27713,27754]
fstring [27836,27877]
===
match
---
trailer [27996,28002]
trailer [28119,28125]
===
match
---
name: serialize_operator_extra_links [24856,24886]
name: serialize_operator_extra_links [24979,25009]
===
match
---
operator: , [12847,12848]
operator: , [12970,12971]
===
match
---
tfpdef [24463,24511]
tfpdef [24586,24634]
===
match
---
atom_expr [24047,24124]
atom_expr [24170,24247]
===
match
---
name: type_ [12330,12335]
name: type_ [12453,12458]
===
match
---
name: v [28672,28673]
name: v [28795,28796]
===
match
---
name: args [14426,14430]
name: args [14549,14553]
===
match
---
name: v [14344,14345]
name: v [14467,14468]
===
match
---
name: isinstance [25039,25049]
name: isinstance [25162,25172]
===
match
---
atom_expr [24981,25019]
atom_expr [25104,25142]
===
match
---
suite [33239,34348]
suite [33362,34471]
===
match
---
if_stmt [30279,30412]
if_stmt [30402,30535]
===
match
---
operator: = [19190,19191]
operator: = [19313,19314]
===
match
---
operator: , [5013,5014]
operator: , [5013,5014]
===
match
---
name: SerializedBaseOperator [28175,28197]
name: SerializedBaseOperator [28298,28320]
===
match
---
trailer [14273,14296]
trailer [14396,14419]
===
match
---
name: isinstance [7212,7222]
name: isinstance [7212,7222]
===
match
---
name: cls [19354,19357]
name: cls [19477,19480]
===
match
---
operator: , [4739,4740]
operator: , [4739,4740]
===
match
---
operator: , [33661,33662]
operator: , [33784,33785]
===
match
---
trailer [30575,30585]
trailer [30698,30708]
===
match
---
simple_stmt [11085,11141]
simple_stmt [11208,11264]
===
match
---
simple_stmt [6685,6749]
simple_stmt [6685,6749]
===
match
---
name: type_ [11239,11244]
name: type_ [11362,11367]
===
match
---
dotted_name [1457,1482]
dotted_name [1457,1482]
===
match
---
param [26763,26771]
param [26886,26894]
===
match
---
fstring_conversion [16509,16511]
fstring_conversion [16632,16634]
===
match
---
atom_expr [14688,14701]
atom_expr [14811,14824]
===
match
---
atom_expr [15637,15668]
atom_expr [15760,15791]
===
match
---
name: var [21077,21080]
name: var [21200,21203]
===
match
---
operator: -> [10453,10455]
operator: -> [10576,10578]
===
match
---
trailer [8927,8936]
trailer [8921,8930]
===
match
---
atom_expr [33982,34040]
atom_expr [34105,34163]
===
match
---
name: cls [32661,32664]
name: cls [32784,32787]
===
match
---
operator: { [28328,28329]
operator: { [28451,28452]
===
match
---
name: dict [7230,7234]
name: dict [7230,7234]
===
match
---
simple_stmt [1452,1507]
simple_stmt [1452,1507]
===
match
---
decorator [24405,24418]
decorator [24528,24541]
===
match
---
simple_stmt [24856,24892]
simple_stmt [24979,25015]
===
match
---
simple_stmt [33362,33418]
simple_stmt [33485,33541]
===
match
---
trailer [9337,9345]
trailer [9331,9339]
===
match
---
name: var [10097,10100]
name: var [10220,10223]
===
match
---
operator: == [28023,28025]
operator: == [28146,28148]
===
match
---
operator: @ [30913,30914]
operator: @ [31036,31037]
===
match
---
param [33174,33209]
param [33297,33332]
===
match
---
simple_stmt [7279,7302]
simple_stmt [7279,7302]
===
match
---
operator: = [24887,24888]
operator: = [25010,25011]
===
match
---
atom_expr [14872,14905]
atom_expr [14995,15028]
===
match
---
param [33131,33165]
param [33254,33288]
===
match
---
expr_stmt [28175,28257]
expr_stmt [28298,28380]
===
match
---
name: var [11952,11955]
name: var [12075,12078]
===
match
---
name: upstream_group_ids [33961,33979]
name: upstream_group_ids [34084,34102]
===
match
---
arith_expr [20219,20298]
arith_expr [20342,20421]
===
match
---
expr_stmt [12418,12462]
expr_stmt [12541,12585]
===
match
---
trailer [9739,9749]
trailer [9733,9743]
===
match
---
simple_stmt [14844,14906]
simple_stmt [14967,15029]
===
match
---
decorated [20716,21196]
decorated [20839,21319]
===
match
---
atom_expr [8613,8620]
atom_expr [8607,8614]
===
match
---
param [12517,12529]
param [12640,12652]
===
match
---
name: cls [20750,20753]
name: cls [20873,20876]
===
match
---
name: classmethod [12611,12622]
name: classmethod [12734,12745]
===
match
---
name: import_string [23723,23736]
name: import_string [23846,23859]
===
match
---
comparison [5802,5813]
comparison [5802,5813]
===
match
---
name: template_fields [16828,16843]
name: template_fields [16951,16966]
===
match
---
suite [14952,15090]
suite [15075,15213]
===
match
---
name: list [32940,32944]
name: list [33063,33067]
===
match
---
subscriptlist [6662,6670]
subscriptlist [6662,6670]
===
match
---
operator: = [14172,14173]
operator: = [14295,14296]
===
match
---
name: v [26529,26530]
name: v [26652,26653]
===
match
---
name: var [11403,11406]
name: var [11526,11529]
===
match
---
name: downstream_task_ids [32956,32975]
name: downstream_task_ids [33079,33098]
===
match
---
operator: @ [12468,12469]
operator: @ [12591,12592]
===
match
---
name: str [4401,4404]
name: str [4401,4404]
===
match
---
trailer [10112,10118]
trailer [10235,10241]
===
match
---
name: set [9745,9748]
name: set [9739,9742]
===
match
---
name: List [963,967]
name: List [963,967]
===
match
---
atom_expr [14327,14336]
atom_expr [14450,14459]
===
match
---
atom_expr [9692,9714]
atom_expr [9686,9708]
===
match
---
name: encoded_var [10848,10859]
name: encoded_var [10971,10982]
===
match
---
parameters [3752,3812]
parameters [3752,3812]
===
match
---
name: VAR [10994,10997]
name: VAR [11117,11120]
===
match
---
name: SerializedTaskGroup [33798,33817]
name: SerializedTaskGroup [33921,33940]
===
match
---
operator: = [33980,33981]
operator: = [34103,34104]
===
match
---
simple_stmt [5141,5212]
simple_stmt [5141,5212]
===
match
---
operator: , [6532,6533]
operator: , [6532,6533]
===
match
---
atom_expr [18230,18256]
atom_expr [18353,18379]
===
match
---
dictorsetmaker [11093,11139]
dictorsetmaker [11216,11262]
===
match
---
name: deps [15864,15868]
name: deps [15987,15991]
===
match
---
name: Set [979,982]
name: Set [979,982]
===
match
---
operator: , [3803,3804]
operator: , [3803,3804]
===
match
---
operator: == [11060,11062]
operator: == [11183,11185]
===
match
---
testlist_comp [9451,9485]
testlist_comp [9445,9479]
===
match
---
trailer [4677,4692]
trailer [4677,4692]
===
match
---
name: klass [16171,16176]
name: klass [16294,16299]
===
match
---
or_test [6316,6434]
or_test [6316,6434]
===
match
---
trailer [19357,19379]
trailer [19480,19502]
===
match
---
string: "Error importing dep %r" [21636,21660]
string: "Error importing dep %r" [21759,21783]
===
match
---
atom_expr [28635,28654]
atom_expr [28758,28777]
===
match
---
name: signature [26471,26480]
name: signature [26594,26603]
===
match
---
operator: ! [27750,27751]
operator: ! [27873,27874]
===
match
---
simple_stmt [29390,29435]
simple_stmt [29513,29558]
===
match
---
operator: == [18227,18229]
operator: == [18350,18352]
===
match
---
operator: , [32286,32287]
operator: , [32409,32410]
===
match
---
trailer [32400,32408]
trailer [32523,32531]
===
match
---
atom_expr [12534,12552]
atom_expr [12657,12675]
===
match
---
string: """         Return true if ``value`` is the hard-coded default for the given attribute.          This takes in to account cases where the ``concurrency`` parameter is         stored in the ``_concurrency`` attribute.          And by using `is` here only and not `==` this copes with the case a         user explicitly specifies an attribute with the same "value" as the         default. (This is because ``"default" is "default"`` will be False as         they are different strings with the same characters.)          Also returns True if the value is an empty list or empty dict. This is done         to account for the case where the default value of the field is None but has the         ``field = field or {}`` set.         """ [12908,13640]
string: """         Return true if ``value`` is the hard-coded default for the given attribute.          This takes in to account cases where the ``concurrency`` parameter is         stored in the ``_concurrency`` attribute.          And by using `is` here only and not `==` this copes with the case a         user explicitly specifies an attribute with the same "value" as the         default. (This is because ``"default" is "default"`` will be False as         they are different strings with the same characters.)          Also returns True if the value is an empty list or empty dict. This is done         to account for the case where the default value of the field is None but has the         ``field = field or {}`` set.         """ [13031,13763]
===
match
---
name: object_to_serialize [6705,6724]
name: object_to_serialize [6705,6724]
===
match
---
operator: , [10750,10751]
operator: , [10873,10874]
===
match
---
for_stmt [21317,21687]
for_stmt [21440,21810]
===
match
---
name: k8s [8499,8502]
name: k8s [8493,8496]
===
match
---
name: str [6576,6579]
name: str [6576,6579]
===
match
---
atom_expr [32765,32802]
atom_expr [32888,32925]
===
match
---
expr_stmt [6685,6748]
expr_stmt [6685,6748]
===
match
---
operator: , [9743,9744]
operator: , [9737,9738]
===
match
---
name: list [32676,32680]
name: list [32799,32803]
===
match
---
arglist [30048,30081]
arglist [30171,30204]
===
match
---
trailer [28679,28701]
trailer [28802,28824]
===
match
---
atom_expr [10837,10866]
atom_expr [10960,10989]
===
match
---
name: task_dict [33174,33183]
name: task_dict [33297,33306]
===
match
---
trailer [19566,19569]
trailer [19689,19692]
===
match
---
atom_expr [29880,29907]
atom_expr [30003,30030]
===
match
---
arglist [10063,10118]
arglist [10192,10241]
===
match
---
operator: { [14221,14222]
operator: { [14344,14345]
===
match
---
simple_stmt [10173,10226]
simple_stmt [10296,10349]
===
match
---
name: AirflowException [17934,17950]
name: AirflowException [18057,18073]
===
match
---
param [20755,20764]
param [20878,20887]
===
match
---
operator: * [11951,11952]
operator: * [12074,12075]
===
match
---
operator: , [13913,13914]
operator: , [14036,14037]
===
match
---
name: tuple [4746,4751]
name: tuple [4746,4751]
===
match
---
param [24458,24462]
param [24581,24585]
===
match
---
trailer [24298,24357]
trailer [24421,24480]
===
match
---
name: DAT [9046,9049]
name: DAT [9040,9043]
===
match
---
atom_expr [8289,8295]
atom_expr [8289,8295]
===
match
---
name: k [28021,28022]
name: k [28144,28145]
===
match
---
trailer [18215,18226]
trailer [18338,18349]
===
match
---
trailer [12769,12789]
trailer [12892,12912]
===
match
---
operator: { [5652,5653]
operator: { [5652,5653]
===
match
---
annassign [3353,3381]
annassign [3353,3381]
===
match
---
suite [7555,10342]
suite [7555,10465]
===
match
---
name: op [20068,20070]
name: op [20191,20193]
===
match
---
operator: = [30148,30149]
operator: = [30271,30272]
===
match
---
name: dag [29390,29393]
name: dag [29513,29516]
===
match
---
name: cls [31537,31540]
name: cls [31660,31663]
===
match
---
return_stmt [8181,8197]
return_stmt [8181,8197]
===
match
---
atom_expr [31899,31920]
atom_expr [32022,32043]
===
match
---
simple_stmt [5370,5424]
simple_stmt [5370,5424]
===
match
---
operator: = [14870,14871]
operator: = [14993,14994]
===
match
---
string: "airflow.operators.dagrun_operator.TriggerDagRunLink" [2487,2540]
string: "airflow.operators.dagrun_operator.TriggerDagRunLink" [2487,2540]
===
match
---
string: """Deserializes a TaskGroup from a JSON object.""" [33248,33298]
string: """Deserializes a TaskGroup from a JSON object.""" [33371,33421]
===
match
---
operator: = [17282,17283]
operator: = [17405,17406]
===
match
---
name: task_group [32945,32955]
name: task_group [33068,33078]
===
match
---
trailer [5373,5386]
trailer [5373,5386]
===
match
---
atom_expr [31235,31265]
atom_expr [31358,31388]
===
match
---
string: 'task_id' [17294,17303]
string: 'task_id' [17417,17426]
===
match
---
suite [19274,19296]
suite [19397,19419]
===
match
---
name: op [20320,20322]
name: op [20443,20445]
===
match
---
atom_expr [10973,10998]
atom_expr [11096,11121]
===
match
---
name: downstream_task_ids [30639,30658]
name: downstream_task_ids [30762,30781]
===
match
---
atom_expr [11721,11752]
atom_expr [11844,11875]
===
match
---
operator: = [7169,7170]
operator: = [7169,7170]
===
match
---
comparison [29663,29703]
comparison [29786,29826]
===
match
---
simple_stmt [17443,17487]
simple_stmt [17566,17610]
===
match
---
name: dag [28951,28954]
name: dag [29074,29077]
===
match
---
trailer [16183,16188]
trailer [16306,16311]
===
match
---
name: loads [5401,5406]
name: loads [5401,5406]
===
match
---
operator: , [8497,8498]
operator: , [8491,8492]
===
match
---
trailer [21176,21195]
trailer [21299,21318]
===
match
---
name: timedelta [11730,11739]
name: timedelta [11853,11862]
===
match
---
name: name [24325,24329]
name: name [24448,24452]
===
match
---
name: v [28893,28894]
name: v [29016,29017]
===
match
---
name: initialize_extra_operators_links_plugins [17807,17847]
name: initialize_extra_operators_links_plugins [17930,17970]
===
match
---
trailer [29954,29959]
trailer [30077,30082]
===
match
---
operator: == [19020,19022]
operator: == [19143,19145]
===
match
---
name: group_id [33617,33625]
name: group_id [33740,33748]
===
match
---
name: op [16771,16773]
name: op [16894,16896]
===
match
---
string: "Can not load plugins" [17951,17973]
string: "Can not load plugins" [18074,18096]
===
match
---
name: operator [18057,18065]
name: operator [18180,18188]
===
match
---
operator: } [26562,26563]
operator: } [26685,26686]
===
match
---
return_stmt [8669,8708]
return_stmt [8663,8702]
===
match
---
name: k [28956,28957]
name: k [29079,29080]
===
match
---
atom_expr [9180,9224]
atom_expr [9174,9218]
===
match
---
atom_expr [18207,18226]
atom_expr [18330,18349]
===
match
---
name: debug [10256,10261]
name: debug [10379,10384]
===
match
---
tfpdef [12658,12671]
tfpdef [12781,12794]
===
match
---
suite [19171,19222]
suite [19294,19345]
===
match
---
trailer [25157,25164]
trailer [25280,25287]
===
match
---
trailer [29088,29100]
trailer [29211,29223]
===
match
---
operator: { [6674,6675]
operator: { [6674,6675]
===
match
---
trailer [25049,25074]
trailer [25172,25197]
===
match
---
trailer [9156,9165]
trailer [9150,9159]
===
match
---
name: DAT [11687,11690]
name: DAT [11810,11813]
===
match
---
argument [10103,10118]
argument [10226,10241]
===
match
---
arglist [9191,9223]
arglist [9185,9217]
===
match
---
trailer [6952,6965]
trailer [6952,6965]
===
match
---
decorated [12468,12605]
decorated [12591,12728]
===
match
---
name: dag_id [16406,16412]
name: dag_id [16529,16535]
===
match
---
atom_expr [33719,33733]
atom_expr [33842,33856]
===
match
---
operator: , [15238,15239]
operator: , [15361,15362]
===
match
---
simple_stmt [20112,20136]
simple_stmt [20235,20259]
===
match
---
trailer [4029,4072]
trailer [4029,4072]
===
match
---
operator: = [9045,9046]
operator: = [9039,9040]
===
match
---
atom_expr [14752,14775]
atom_expr [14875,14898]
===
match
---
name: value [17047,17052]
name: value [17170,17175]
===
match
---
testlist_comp [12237,12269]
testlist_comp [12360,12392]
===
match
---
name: str [15266,15269]
name: str [15389,15392]
===
match
---
name: encoded_var [10703,10714]
name: encoded_var [10826,10837]
===
match
---
name: var [8188,8191]
name: var [8188,8191]
===
match
---
name: dag [29880,29883]
name: dag [30003,30006]
===
match
---
atom_expr [16399,16412]
atom_expr [16522,16535]
===
match
---
name: cattr [998,1003]
name: cattr [998,1003]
===
match
---
name: op_link_arguments [24961,24978]
name: op_link_arguments [25084,25101]
===
match
---
trailer [6335,6351]
trailer [6335,6351]
===
match
---
operator: , [29205,29206]
operator: , [29328,29329]
===
match
---
trailer [11950,11967]
trailer [12073,12090]
===
match
---
operator: } [12337,12338]
operator: } [12460,12461]
===
match
---
suite [24030,24151]
suite [24153,24274]
===
match
---
trailer [29500,29504]
trailer [29623,29627]
===
match
---
fstring_start: f' [12314,12316]
fstring_start: f' [12437,12439]
===
match
---
simple_stmt [30349,30412]
simple_stmt [30472,30535]
===
match
---
name: dag [26999,27002]
name: dag [27122,27125]
===
match
---
name: _OPERATOR_EXTRA_LINKS [2903,2924]
name: _OPERATOR_EXTRA_LINKS [2903,2924]
===
match
---
name: v [19219,19220]
name: v [19342,19343]
===
match
---
expr_stmt [14784,14835]
expr_stmt [14907,14958]
===
match
---
simple_stmt [19800,19831]
simple_stmt [19923,19954]
===
match
---
name: cls [31235,31238]
name: cls [31358,31361]
===
match
---
name: var [30947,30950]
name: var [31070,31073]
===
match
---
operator: * [14382,14383]
operator: * [14505,14506]
===
match
---
operator: , [20526,20527]
operator: , [20649,20650]
===
match
---
name: v [28493,28494]
name: v [28616,28617]
===
match
---
name: task [30139,30143]
name: task [30262,30266]
===
match
---
atom_expr [18809,18887]
atom_expr [18932,19010]
===
match
---
name: cls [12844,12847]
name: cls [12967,12970]
===
match
---
name: v [9261,9262]
name: v [9255,9256]
===
match
---
operator: @ [20716,20717]
operator: @ [20839,20840]
===
match
---
atom_expr [9334,9345]
atom_expr [9328,9339]
===
match
---
trailer [11402,11407]
trailer [11525,11530]
===
match
---
name: airflow [22133,22140]
name: airflow [22256,22263]
===
match
---
argument [9616,9639]
argument [9610,9633]
===
match
---
name: classmethod [12796,12807]
name: classmethod [12919,12930]
===
match
---
operator: , [26899,26900]
operator: , [27022,27023]
===
match
---
operator: , [4017,4018]
operator: , [4017,4018]
===
match
---
import_as_names [887,907]
import_as_names [887,907]
===
match
---
simple_stmt [15339,15403]
simple_stmt [15462,15526]
===
match
---
name: dag [27239,27242]
name: dag [27362,27365]
===
match
---
expr_stmt [33362,33417]
expr_stmt [33485,33540]
===
match
---
return_stmt [13837,13848]
return_stmt [13960,13971]
===
match
---
name: setattr [30040,30047]
name: setattr [30163,30170]
===
match
---
decorator [31817,31830]
decorator [31940,31953]
===
match
---
name: getattr [6894,6901]
name: getattr [6894,6901]
===
match
---
import_from [1649,1721]
import_from [1649,1721]
===
match
---
name: TASK_GROUP [32487,32497]
name: TASK_GROUP [32610,32620]
===
match
---
atom_expr [7318,7340]
atom_expr [7318,7340]
===
match
---
name: str [5919,5922]
name: str [5919,5922]
===
match
---
name: k [28828,28829]
name: k [28951,28952]
===
match
---
name: Dict [6571,6575]
name: Dict [6571,6575]
===
match
---
trailer [19856,19892]
trailer [19979,20015]
===
match
---
dictorsetmaker [28329,28409]
dictorsetmaker [28452,28532]
===
match
---
decorated [14911,15090]
decorated [15034,15213]
===
match
---
trailer [8350,8355]
trailer [8350,8355]
===
match
---
simple_stmt [29085,29241]
simple_stmt [29208,29364]
===
match
---
suite [29072,29241]
suite [29195,29364]
===
match
---
simple_stmt [16861,16903]
simple_stmt [16984,17026]
===
match
---
name: _encode [8893,8900]
name: _encode [8887,8894]
===
match
---
trailer [32277,32286]
trailer [32400,32409]
===
match
---
atom_expr [15354,15402]
atom_expr [15477,15525]
===
match
---
operator: } [3689,3690]
operator: } [3689,3690]
===
match
---
simple_stmt [27644,27650]
simple_stmt [27767,27773]
===
match
---
trailer [8813,8818]
trailer [8807,8812]
===
match
---
simple_stmt [20701,20711]
simple_stmt [20824,20834]
===
match
---
atom_expr [22320,22358]
atom_expr [22443,22481]
===
match
---
name: encoded_group [34288,34301]
name: encoded_group [34411,34424]
===
match
---
arglist [6966,6997]
arglist [6966,6997]
===
match
---
expr_stmt [30166,30204]
expr_stmt [30289,30327]
===
match
---
decorator [12795,12808]
decorator [12918,12931]
===
match
---
decorated [7436,10342]
decorated [7436,10465]
===
match
---
suite [29804,29852]
suite [29927,29975]
===
match
---
name: v [28584,28585]
name: v [28707,28708]
===
match
---
decorated [5860,6435]
decorated [5860,6435]
===
match
---
atom_expr [29390,29405]
atom_expr [29513,29528]
===
match
---
atom_expr [23577,23607]
atom_expr [23700,23730]
===
match
---
name: BaseOperatorLink [24494,24510]
name: BaseOperatorLink [24617,24633]
===
match
---
name: str [2279,2282]
name: str [2279,2282]
===
match
---
trailer [17659,17686]
trailer [17782,17809]
===
match
---
trailer [20665,20669]
trailer [20788,20792]
===
match
---
simple_stmt [1297,1368]
simple_stmt [1297,1368]
===
match
---
trailer [14307,14313]
trailer [14430,14436]
===
match
---
comparison [20029,20055]
comparison [20152,20178]
===
match
---
name: encoded_var [10973,10984]
name: encoded_var [11096,11107]
===
match
---
tfpdef [5909,5922]
tfpdef [5909,5922]
===
match
---
sync_comp_for [33876,33936]
sync_comp_for [33999,34059]
===
match
---
atom_expr [8347,8355]
atom_expr [8347,8355]
===
match
---
operator: -> [5939,5941]
operator: -> [5939,5941]
===
match
---
trailer [2278,2283]
trailer [2278,2283]
===
match
---
simple_stmt [2819,2892]
simple_stmt [2819,2892]
===
match
---
operator: = [15438,15439]
operator: = [15561,15562]
===
match
---
number: 1 [3717,3718]
number: 1 [3717,3718]
===
match
---
atom [33698,33946]
atom [33821,34069]
===
match
---
fstring_string: Failed to serialize dag  [27715,27739]
fstring_string: Failed to serialize dag  [27838,27862]
===
match
---
operator: = [29745,29746]
operator: = [29868,29869]
===
match
---
trailer [9938,9950]
trailer [10067,10079]
===
match
---
fstring_conversion [31630,31632]
fstring_conversion [31753,31755]
===
match
---
arglist [20524,20539]
arglist [20647,20662]
===
match
---
atom_expr [33219,33238]
atom_expr [33342,33361]
===
match
---
name: datetime [3196,3204]
name: datetime [3196,3204]
===
match
---
argument [8607,8620]
argument [8601,8614]
===
match
---
trailer [15513,15524]
trailer [15636,15647]
===
match
---
subscriptlist [3670,3684]
subscriptlist [3670,3684]
===
match
---
string: 'deps' [16625,16631]
string: 'deps' [16748,16754]
===
match
---
trailer [34054,34075]
trailer [34177,34198]
===
match
---
name: dict [4049,4053]
name: dict [4049,4053]
===
match
---
name: _is_excluded [5881,5893]
name: _is_excluded [5881,5893]
===
match
---
name: has_dag [20833,20840]
name: has_dag [20956,20963]
===
match
---
name: parameters [14297,14307]
name: parameters [14420,14430]
===
match
---
operator: , [33885,33886]
operator: , [34008,34009]
===
match
---
trailer [27002,27012]
trailer [27125,27135]
===
match
---
name: settings [1735,1743]
name: settings [1735,1743]
===
match
---
name: value [12864,12869]
name: value [12987,12992]
===
match
---
name: task_group [1885,1895]
name: task_group [1885,1895]
===
match
---
atom_expr [9860,9898]
atom_expr [9875,9913]
===
match
---
atom_expr [14344,14351]
atom_expr [14467,14474]
===
match
---
operator: , [4451,4452]
operator: , [4451,4452]
===
match
---
name: SerializedBaseOperator [28346,28368]
name: SerializedBaseOperator [28469,28491]
===
match
---
atom_expr [8848,8867]
atom_expr [8842,8861]
===
match
---
suite [8987,9061]
suite [8981,9055]
===
match
---
string: "airflow.sensors.external_task.ExternalTaskSensorLink" [2350,2404]
string: "airflow.sensors.external_task.ExternalTaskSensorLink" [2350,2404]
===
match
---
simple_stmt [28427,28443]
simple_stmt [28550,28566]
===
match
---
simple_stmt [2656,2815]
simple_stmt [2656,2815]
===
match
---
name: date_attr [30309,30318]
name: date_attr [30432,30441]
===
match
---
simple_stmt [11184,11226]
simple_stmt [11307,11349]
===
match
---
name: v [11113,11114]
name: v [11236,11237]
===
match
---
atom_expr [33798,33863]
atom_expr [33921,33986]
===
match
---
name: str [31910,31913]
name: str [32033,32036]
===
match
---
operator: = [34171,34172]
operator: = [34294,34295]
===
match
---
arglist [15376,15401]
arglist [15499,15524]
===
match
---
operator: , [5249,5250]
operator: , [5249,5250]
===
match
---
name: staticmethod [26078,26090]
name: staticmethod [26201,26213]
===
match
---
atom_expr [34078,34138]
atom_expr [34201,34261]
===
match
---
suite [6086,6224]
suite [6086,6224]
===
match
---
atom_expr [29085,29100]
atom_expr [29208,29223]
===
match
---
suite [17179,20711]
suite [17302,20834]
===
match
---
name: var [9504,9507]
name: var [9498,9501]
===
match
---
import_from [1368,1416]
import_from [1368,1416]
===
match
---
trailer [31654,31670]
trailer [31777,31793]
===
match
---
name: self [14734,14738]
name: self [14857,14861]
===
match
---
name: v [28408,28409]
name: v [28531,28532]
===
match
---
name: Optional [3355,3363]
name: Optional [3355,3363]
===
match
---
trailer [30445,30452]
trailer [30568,30575]
===
match
---
atom_expr [33758,33764]
atom_expr [33881,33887]
===
match
---
trailer [19990,20008]
trailer [20113,20131]
===
match
---
expr_stmt [33589,33672]
expr_stmt [33712,33795]
===
match
---
name: items [32604,32609]
name: items [32727,32732]
===
match
---
trailer [26966,26977]
trailer [27089,27100]
===
match
---
name: v [12254,12255]
name: v [12377,12378]
===
match
---
trailer [14345,14351]
trailer [14468,14474]
===
match
---
name: k [20059,20060]
name: k [20182,20183]
===
match
---
atom_expr [25204,25346]
atom_expr [25327,25469]
===
match
---
arglist [32440,32459]
arglist [32563,32582]
===
match
---
simple_stmt [4469,4550]
simple_stmt [4469,4550]
===
match
---
atom_expr [2275,2283]
atom_expr [2275,2283]
===
match
---
operator: , [30528,30529]
operator: , [30651,30652]
===
match
---
name: value [13795,13800]
name: value [13918,13923]
===
match
---
operator: @ [7436,7437]
operator: @ [7436,7437]
===
match
---
name: name [18343,18347]
name: name [18466,18470]
===
match
---
fstring_end: ' [12358,12359]
fstring_end: ' [12481,12482]
===
match
---
name: BaseOperator [14704,14716]
name: BaseOperator [14827,14839]
===
match
---
operator: = [29845,29846]
operator: = [29968,29969]
===
match
---
name: Timezone [1219,1227]
name: Timezone [1219,1227]
===
match
---
name: serialize_op [16612,16624]
name: serialize_op [16735,16747]
===
match
---
name: op [21192,21194]
name: op [21315,21317]
===
match
---
operator: = [12595,12596]
operator: = [12718,12719]
===
match
---
simple_stmt [9000,9061]
simple_stmt [8994,9055]
===
match
---
name: has_on_success_callback [27367,27390]
name: has_on_success_callback [27490,27513]
===
match
---
string: """     A JSON serializable representation of DAG.      A stringified DAG can only be used in the scope of scheduler and webserver, because fields     that are not serializable, such as functions and customer defined classes, are casted to     strings.      Compared with SimpleDAG: SerializedDAG contains all information for webserver.     Compared with DagPickle: DagPickle contains all information for worker, but some DAGs are     not pickle-able. SerializedDAG works for all DAGs.     """ [25496,25989]
string: """     A JSON serializable representation of DAG.      A stringified DAG can only be used in the scope of scheduler and webserver, because fields     that are not serializable, such as functions and customer defined classes, are casted to     strings.      Compared with SimpleDAG: SerializedDAG contains all information for webserver.     Compared with DagPickle: DagPickle contains all information for worker, but some DAGs are     not pickle-able. SerializedDAG works for all DAGs.     """ [25619,26112]
===
match
---
trailer [8336,8338]
trailer [8336,8338]
===
match
---
name: downstream_group_ids [34055,34075]
name: downstream_group_ids [34178,34198]
===
match
---
name: _load_operator_extra_links [28231,28257]
name: _load_operator_extra_links [28354,28380]
===
match
---
trailer [25315,25324]
trailer [25438,25447]
===
match
---
atom_expr [18339,18347]
atom_expr [18462,18470]
===
match
---
name: _encode [10055,10062]
name: _encode [10184,10191]
===
match
---
simple_stmt [1756,1811]
simple_stmt [1756,1811]
===
match
---
trailer [23576,23608]
trailer [23699,23731]
===
match
---
name: seconds [12517,12524]
name: seconds [12640,12647]
===
match
---
name: __class__ [25306,25315]
name: __class__ [25429,25438]
===
match
---
atom_expr [14408,14441]
atom_expr [14531,14564]
===
match
---
name: cls [24458,24461]
name: cls [24581,24584]
===
match
---
trailer [6326,6352]
trailer [6326,6352]
===
match
---
atom_expr [12390,12413]
atom_expr [12513,12536]
===
match
---
simple_stmt [31757,31812]
simple_stmt [31880,31935]
===
match
---
trailer [15761,15793]
trailer [15884,15916]
===
match
---
name: var [21096,21099]
name: var [21219,21222]
===
match
---
decorated [30913,31291]
decorated [31036,31414]
===
match
---
trailer [7110,7121]
trailer [7110,7121]
===
match
---
param [17135,17161]
param [17258,17284]
===
match
---
comparison [21096,21111]
comparison [21219,21234]
===
match
---
trailer [26505,26511]
trailer [26628,26634]
===
match
---
name: OP [33762,33764]
name: OP [33885,33887]
===
match
---
expr_stmt [7279,7301]
expr_stmt [7279,7301]
===
match
---
name: serialize_op [15411,15423]
name: serialize_op [15534,15546]
===
match
---
operator: , [6921,6922]
operator: , [6921,6922]
===
match
---
trailer [14764,14775]
trailer [14887,14898]
===
match
---
decorated [26077,26564]
decorated [26200,26687]
===
match
---
expr_stmt [21019,21061]
expr_stmt [21142,21184]
===
match
---
operator: , [3070,3071]
operator: , [3070,3071]
===
match
---
atom_expr [29910,29928]
atom_expr [30033,30051]
===
match
---
name: _is_primitive [5718,5731]
name: _is_primitive [5718,5731]
===
match
---
parameters [5550,5570]
parameters [5550,5570]
===
match
---
expr_stmt [27516,27563]
expr_stmt [27639,27686]
===
match
---
name: value [7279,7284]
name: value [7279,7284]
===
match
---
name: dag_id [27933,27939]
name: dag_id [28056,28062]
===
match
---
name: client [1956,1962]
name: client [1956,1962]
===
match
---
name: dateutil [1025,1033]
name: dateutil [1025,1033]
===
match
---
name: getLogger [2231,2240]
name: getLogger [2231,2240]
===
match
---
trailer [8689,8703]
trailer [8683,8697]
===
match
---
operator: , [6976,6977]
operator: , [6976,6977]
===
match
---
simple_stmt [3047,3090]
simple_stmt [3047,3090]
===
match
---
trailer [29905,29907]
trailer [30028,30030]
===
match
---
trailer [33457,33470]
trailer [33580,33593]
===
match
---
param [4019,4072]
param [4019,4072]
===
match
---
name: type_ [9900,9905]
name: type_ [9915,9920]
===
match
---
name: set [4448,4451]
name: set [4448,4451]
===
match
---
name: _deserialize [34181,34193]
name: _deserialize [34304,34316]
===
match
---
arglist [8597,8620]
arglist [8591,8614]
===
match
---
expr_stmt [28066,28076]
expr_stmt [28189,28199]
===
match
---
trailer [8433,8436]
trailer [8427,8430]
===
match
---
simple_stmt [14408,14442]
simple_stmt [14531,14565]
===
match
---
operator: { [14174,14175]
operator: { [14297,14298]
===
match
---
name: pendulum [1191,1199]
name: pendulum [1191,1199]
===
match
---
simple_stmt [28066,28077]
simple_stmt [28189,28200]
===
match
---
name: serialized_object [7318,7335]
name: serialized_object [7318,7335]
===
match
---
comparison [11154,11170]
comparison [11277,11293]
===
match
---
name: bool [20650,20654]
name: bool [20773,20777]
===
match
---
name: ui_color [32278,32286]
name: ui_color [32401,32409]
===
match
---
name: key [6923,6926]
name: key [6923,6926]
===
match
---
name: field [20492,20497]
name: field [20615,20620]
===
match
---
name: var [8494,8497]
name: var [8488,8491]
===
match
---
suite [19333,19383]
suite [19456,19506]
===
match
---
trailer [2240,2250]
trailer [2240,2250]
===
match
---
name: Any [5566,5569]
name: Any [5566,5569]
===
match
---
name: str [20775,20778]
name: str [20898,20901]
===
match
---
raise_stmt [5141,5211]
raise_stmt [5141,5211]
===
match
---
parameters [10429,10452]
parameters [10552,10575]
===
match
---
name: validate_schema [31239,31254]
name: validate_schema [31362,31377]
===
match
---
name: k [26430,26431]
name: k [26553,26554]
===
match
---
atom_expr [9132,9145]
atom_expr [9126,9139]
===
match
---
trailer [9625,9639]
trailer [9619,9633]
===
match
---
string: 'BaseSerialization' [4708,4727]
string: 'BaseSerialization' [4708,4727]
===
match
---
suite [5128,5212]
suite [5128,5212]
===
match
---
name: r [31631,31632]
name: r [31754,31755]
===
match
---
suite [9516,9576]
suite [9510,9570]
===
match
---
sync_comp_for [14252,14351]
sync_comp_for [14375,14474]
===
match
---
decorated [2613,2925]
decorated [2613,2925]
===
match
---
if_stmt [6946,7025]
if_stmt [6946,7025]
===
match
---
simple_stmt [8765,8819]
simple_stmt [8759,8813]
===
match
---
funcdef [4366,4607]
funcdef [4366,4607]
===
match
---
name: log [2217,2220]
name: log [2217,2220]
===
match
---
name: parent_group [33131,33143]
name: parent_group [33254,33266]
===
match
---
trailer [22336,22358]
trailer [22459,22481]
===
match
---
return_stmt [8210,8220]
return_stmt [8210,8220]
===
match
---
name: cache [1087,1092]
name: cache [1087,1092]
===
match
---
trailer [8006,8020]
trailer [8006,8020]
===
match
---
atom [24889,24891]
atom [25012,25014]
===
match
---
atom [11092,11140]
atom [11215,11263]
===
match
---
string: 'description' [26248,26261]
string: 'description' [26371,26384]
===
match
---
name: serialize_group [33005,33020]
name: serialize_group [33128,33143]
===
match
---
simple_stmt [29717,29752]
simple_stmt [29840,29875]
===
match
---
name: weekday [11943,11950]
name: weekday [12066,12073]
===
match
---
name: append [25158,25164]
name: append [25281,25287]
===
match
---
name: SerializedDAG [11191,11204]
name: SerializedDAG [11314,11327]
===
match
---
if_stmt [8000,10342]
if_stmt [8000,10465]
===
match
---
name: op_predefined_extra_links [19800,19825]
name: op_predefined_extra_links [19923,19948]
===
match
---
trailer [20271,20291]
trailer [20394,20414]
===
match
---
trailer [8300,8311]
trailer [8300,8311]
===
match
---
trailer [17046,17053]
trailer [17169,17176]
===
match
---
name: DAG [1448,1451]
name: DAG [1448,1451]
===
match
---
name: var [12118,12121]
name: var [12241,12244]
===
match
---
name: BaseOperator [8738,8750]
name: BaseOperator [8732,8744]
===
match
---
subscriptlist [4708,4751]
subscriptlist [4708,4751]
===
match
---
string: "Operator Link class %r not registered" [24057,24096]
string: "Operator Link class %r not registered" [24180,24219]
===
match
---
atom_expr [9046,9059]
atom_expr [9040,9053]
===
match
---
operator: == [11841,11843]
operator: == [11964,11966]
===
match
---
name: airflow [1727,1734]
name: airflow [1727,1734]
===
match
---
fstring [10897,10957]
fstring [11020,11080]
===
match
---
name: cls [9595,9598]
name: cls [9589,9592]
===
match
---
atom_expr [33597,33672]
atom_expr [33720,33795]
===
match
---
atom [33887,33899]
atom [34010,34022]
===
match
---
name: cls [27798,27801]
name: cls [27921,27924]
===
match
---
name: registered_operator_link_classes [23826,23858]
name: registered_operator_link_classes [23949,23981]
===
match
---
operator: , [4744,4745]
operator: , [4744,4745]
===
match
---
operator: , [30514,30515]
operator: , [30637,30638]
===
match
---
atom_expr [7107,7128]
atom_expr [7107,7128]
===
match
---
trailer [14692,14701]
trailer [14815,14824]
===
match
---
string: "downstream_group_ids" [34113,34135]
string: "downstream_group_ids" [34236,34258]
===
match
---
name: classmethod [15196,15207]
name: classmethod [15319,15330]
===
match
---
simple_stmt [9429,9487]
simple_stmt [9423,9481]
===
match
---
trailer [10084,10087]
trailer [10010,10013]
===
match
---
simple_stmt [20516,20541]
simple_stmt [20639,20664]
===
match
---
operator: * [14425,14426]
operator: * [14548,14549]
===
match
---
name: airflow [17747,17754]
name: airflow [17870,17877]
===
match
---
suite [2651,2925]
suite [2651,2925]
===
match
---
if_stmt [31986,32029]
if_stmt [32109,32152]
===
match
---
name: cls [28676,28679]
name: cls [28799,28802]
===
match
---
name: serialize_task_group [31838,31858]
name: serialize_task_group [31961,31981]
===
match
---
trailer [30856,30860]
trailer [30979,30983]
===
match
---
comparison [11421,11437]
comparison [11544,11560]
===
match
---
simple_stmt [28872,28896]
simple_stmt [28995,29019]
===
match
---
operator: , [27824,27825]
operator: , [27947,27948]
===
match
---
operator: @ [3724,3725]
operator: @ [3724,3725]
===
match
---
param [5924,5937]
param [5924,5937]
===
match
---
decorator [5860,5873]
decorator [5860,5873]
===
match
---
name: v [18904,18905]
name: v [19027,19028]
===
match
---
simple_stmt [5795,5855]
simple_stmt [5795,5855]
===
match
---
tfpdef [15240,15256]
tfpdef [15363,15379]
===
match
---
suite [6999,7025]
suite [6999,7025]
===
match
---
name: DAT [8613,8616]
name: DAT [8607,8610]
===
match
---
name: get_python_source [1793,1810]
name: get_python_source [1793,1810]
===
match
---
suite [30126,30888]
suite [30249,31011]
===
match
---
atom_expr [27106,27120]
atom_expr [27229,27243]
===
match
---
name: _serialize [7175,7185]
name: _serialize [7175,7185]
===
match
---
suite [13934,25445]
suite [14057,25568]
===
match
---
simple_stmt [3644,3691]
simple_stmt [3644,3691]
===
match
---
atom_expr [20650,20690]
atom_expr [20773,20813]
===
match
---
trailer [11035,11040]
trailer [11158,11163]
===
match
---
trailer [12063,12067]
trailer [12186,12190]
===
match
---
operator: = [15352,15353]
operator: = [15475,15476]
===
match
---
name: serializable_task [30166,30183]
name: serializable_task [30289,30306]
===
match
---
return_stmt [21695,21711]
return_stmt [21818,21834]
===
match
---
expr_stmt [2217,2250]
expr_stmt [2217,2250]
===
match
---
name: SerializedDAG [25453,25466]
name: SerializedDAG [25576,25589]
===
match
---
atom [26398,26563]
atom [26521,26686]
===
match
---
trailer [19379,19382]
trailer [19502,19505]
===
match
---
name: dag [30048,30051]
name: dag [30171,30174]
===
match
---
operator: , [33208,33209]
operator: , [33331,33332]
===
match
---
name: k [14231,14232]
name: k [14354,14355]
===
match
---
simple_stmt [15718,15849]
simple_stmt [15841,15972]
===
match
---
if_stmt [20807,21141]
if_stmt [20930,21264]
===
match
---
name: HAS_KUBERNETES [2113,2127]
name: HAS_KUBERNETES [2113,2127]
===
match
---
operator: = [26872,26873]
operator: = [26995,26996]
===
match
---
expr_stmt [29861,29961]
expr_stmt [29984,30084]
===
match
---
atom_expr [15440,15461]
atom_expr [15563,15584]
===
match
---
name: v [10085,10086]
name: v [10011,10012]
===
match
---
name: k [20324,20325]
name: k [20447,20448]
===
match
---
test [32386,32547]
test [32509,32670]
===
match
---
operator: , [5897,5898]
operator: , [5897,5898]
===
match
---
simple_stmt [28493,28526]
simple_stmt [28616,28649]
===
match
---
trailer [34112,34136]
trailer [34235,34259]
===
match
---
operator: = [3715,3716]
operator: = [3715,3716]
===
match
---
atom [13734,13823]
atom [13857,13946]
===
match
---
name: plugins_manager [23810,23825]
name: plugins_manager [23933,23948]
===
match
---
funcdef [7453,10342]
funcdef [7453,10465]
===
match
---
name: POD [11434,11437]
name: POD [11557,11560]
===
match
---
name: _deserialize [33990,34002]
name: _deserialize [34113,34125]
===
match
---
atom_expr [18069,18082]
atom_expr [18192,18205]
===
match
---
name: Any [5904,5907]
name: Any [5904,5907]
===
match
---
name: _CONSTRUCTOR_PARAMS [29935,29954]
name: _CONSTRUCTOR_PARAMS [30058,30077]
===
match
---
return_stmt [6212,6223]
return_stmt [6212,6223]
===
match
---
trailer [21268,21281]
trailer [21391,21404]
===
match
---
arglist [9740,9748]
arglist [9734,9742]
===
match
---
name: label [33880,33885]
name: label [34003,34008]
===
match
---
name: cls [8848,8851]
name: cls [8842,8845]
===
match
---
comparison [28021,28048]
comparison [28144,28171]
===
match
---
simple_stmt [14688,14726]
simple_stmt [14811,14849]
===
match
---
name: RuntimeError [11496,11508]
name: RuntimeError [11619,11631]
===
match
---
dictorsetmaker [9249,9317]
dictorsetmaker [9243,9311]
===
match
---
simple_stmt [26569,26645]
simple_stmt [26692,26768]
===
match
---
simple_stmt [2217,2251]
simple_stmt [2217,2251]
===
match
---
operator: } [14356,14357]
operator: } [14479,14480]
===
match
---
comparison [21077,21092]
comparison [21200,21215]
===
match
---
atom [33514,33570]
atom [33637,33693]
===
match
---
name: serialize_operator [8795,8813]
name: serialize_operator [8789,8807]
===
match
---
name: timezone [1203,1211]
name: timezone [1203,1211]
===
match
---
operator: { [18338,18339]
operator: { [18461,18462]
===
match
---
fstring_expr [12329,12338]
fstring_expr [12452,12461]
===
match
---
string: "tooltip" [33534,33543]
string: "tooltip" [33657,33666]
===
match
---
subscriptlist [6520,6537]
subscriptlist [6520,6537]
===
match
---
atom_expr [19449,19479]
atom_expr [19572,19602]
===
match
---
trailer [26617,26626]
trailer [26740,26749]
===
match
---
expr_stmt [9429,9486]
expr_stmt [9423,9480]
===
match
---
trailer [9558,9566]
trailer [9552,9560]
===
match
---
testlist_comp [10779,10819]
testlist_comp [10902,10942]
===
match
---
simple_stmt [17791,17850]
simple_stmt [17914,17973]
===
match
---
operator: { [9248,9249]
operator: { [9242,9243]
===
match
---
name: var [9136,9139]
name: var [9130,9133]
===
match
---
operator: , [14257,14258]
operator: , [14380,14381]
===
match
---
string: 'dag' [31686,31691]
string: 'dag' [31809,31814]
===
match
---
name: type_ [9147,9152]
name: type_ [9141,9146]
===
match
---
name: relativedelta [12017,12030]
name: relativedelta [12140,12153]
===
match
---
name: task_dict [33853,33862]
name: task_dict [33976,33985]
===
match
---
trailer [15357,15375]
trailer [15480,15498]
===
match
---
suite [11359,11408]
suite [11482,11531]
===
match
---
trailer [11847,11861]
trailer [11970,11984]
===
match
---
trailer [34085,34098]
trailer [34208,34221]
===
match
---
name: plugins_manager [17866,17881]
name: plugins_manager [17989,18004]
===
match
---
comparison [12136,12154]
comparison [12259,12277]
===
match
---
if_stmt [31527,31636]
if_stmt [31650,31759]
===
match
---
trailer [9036,9038]
trailer [9030,9032]
===
match
---
testlist_comp [3067,3088]
testlist_comp [3067,3088]
===
match
---
try_stmt [1914,2136]
try_stmt [1914,2136]
===
match
---
trailer [1171,1185]
trailer [1171,1185]
===
match
---
name: self [15074,15078]
name: self [15197,15201]
===
match
---
string: "{}.{}" [25204,25211]
string: "{}.{}" [25327,25334]
===
match
---
return_stmt [6237,6300]
return_stmt [6237,6300]
===
match
---
suite [24513,25445]
suite [24636,25568]
===
match
---
name: Any [6581,6584]
name: Any [6581,6584]
===
match
---
if_stmt [16919,17054]
if_stmt [17042,17177]
===
match
---
atom_expr [8276,8356]
atom_expr [8276,8356]
===
match
---
name: kwargs [33665,33671]
name: kwargs [33788,33794]
===
match
---
name: instance [6291,6299]
name: instance [6291,6299]
===
match
---
atom_expr [20480,20498]
atom_expr [20603,20621]
===
match
---
atom_expr [29717,29744]
atom_expr [29840,29867]
===
match
---
arglist [8381,8390]
arglist [8381,8390]
===
match
---
name: name [9140,9144]
name: name [9134,9138]
===
match
---
name: var [4019,4022]
name: var [4019,4022]
===
match
---
atom_expr [15609,15634]
atom_expr [15732,15757]
===
match
---
operator: , [21464,21465]
operator: , [21587,21588]
===
match
---
string: 'BaseOperator' [14609,14623]
string: 'BaseOperator' [14732,14746]
===
match
---
atom_expr [11275,11323]
atom_expr [11398,11446]
===
match
---
trailer [31488,31518]
trailer [31611,31641]
===
match
---
operator: , [25067,25068]
operator: , [25190,25191]
===
match
---
suite [8869,8938]
suite [8863,8932]
===
match
---
import_as_name [1970,1983]
import_as_name [1970,1983]
===
match
---
expr_stmt [3341,3381]
expr_stmt [3341,3381]
===
match
---
comp_if [9287,9317]
comp_if [9281,9311]
===
match
---
name: serialized_obj [4925,4939]
name: serialized_obj [4925,4939]
===
match
---
atom_expr [5004,5020]
atom_expr [5004,5020]
===
match
---
name: v [11123,11124]
name: v [11246,11247]
===
match
---
operator: = [29406,29407]
operator: = [29529,29530]
===
match
---
name: BaseOperator [20784,20796]
name: BaseOperator [20907,20919]
===
match
---
param [26758,26762]
param [26881,26885]
===
match
---
string: """Serializes operator into a JSON object.""" [15285,15330]
string: """Serializes operator into a JSON object.""" [15408,15453]
===
match
---
name: _is_excluded [16930,16942]
name: _is_excluded [17053,17065]
===
match
---
atom_expr [2819,2891]
atom_expr [2819,2891]
===
match
---
string: """Helper function of depth first search for serialization.          The serialization protocol is:          (1) keeping JSON supported types: primitives, dict, list;         (2) encoding other types as ``{TYPE: 'foo', VAR: 'bar'}``, the deserialization             step decode VAR according to TYPE;         (3) Operator has a special field CLASS to record the original class             name for displaying in UI.         """ [7564,7991]
string: """Helper function of depth first search for serialization.          The serialization protocol is:          (1) keeping JSON supported types: primitives, dict, list;         (2) encoding other types as ``{TYPE: 'foo', VAR: 'bar'}``, the deserialization             step decode VAR according to TYPE;         (3) Operator has a special field CLASS to record the original class             name for displaying in UI.         """ [7564,7991]
===
match
---
trailer [31254,31265]
trailer [31377,31388]
===
match
---
trailer [30818,30828]
trailer [30941,30951]
===
match
---
simple_stmt [24367,24400]
simple_stmt [24490,24523]
===
match
---
name: param_to_attr [26412,26425]
name: param_to_attr [26535,26548]
===
match
---
arith_expr [16399,16431]
arith_expr [16522,16554]
===
match
---
atom_expr [20655,20689]
atom_expr [20778,20812]
===
match
---
raise_stmt [27688,27755]
raise_stmt [27811,27878]
===
match
---
atom_expr [32661,32712]
atom_expr [32784,32835]
===
match
---
simple_stmt [12081,12123]
simple_stmt [12204,12246]
===
match
---
operator: , [33634,33635]
operator: , [33757,33758]
===
match
---
expr_stmt [15339,15402]
expr_stmt [15462,15525]
===
match
---
name: op [15811,15813]
name: op [15934,15936]
===
match
---
atom_expr [27065,27121]
atom_expr [27188,27244]
===
match
---
simple_stmt [19291,19296]
simple_stmt [19414,19419]
===
match
---
operator: = [26189,26190]
operator: = [26312,26313]
===
match
---
suite [17911,17975]
suite [18034,18098]
===
match
---
atom_expr [4322,4343]
atom_expr [4322,4343]
===
match
---
if_stmt [30425,30593]
if_stmt [30548,30716]
===
match
---
trailer [30860,30887]
trailer [30983,31010]
===
match
---
name: total_seconds [9023,9036]
name: total_seconds [9017,9030]
===
match
---
name: DAT [12145,12148]
name: DAT [12268,12271]
===
match
---
operator: , [4727,4728]
operator: , [4727,4728]
===
match
---
simple_stmt [1866,1913]
simple_stmt [1866,1913]
===
match
---
dictorsetmaker [26016,26070]
dictorsetmaker [26139,26193]
===
match
---
name: attrname [5909,5917]
name: attrname [5909,5917]
===
match
---
name: var [8704,8707]
name: var [8698,8701]
===
match
---
expr_stmt [14734,14775]
expr_stmt [14857,14898]
===
match
---
trailer [21544,21548]
trailer [21667,21671]
===
match
---
trailer [19082,19085]
trailer [19205,19208]
===
match
---
name: tuple [4066,4071]
name: tuple [4066,4071]
===
match
---
trailer [8842,8868]
trailer [8836,8862]
===
match
---
atom_expr [28588,28617]
atom_expr [28711,28740]
===
match
---
param [7468,7472]
param [7468,7472]
===
match
---
string: "_task_type" [18165,18177]
string: "_task_type" [18288,18300]
===
match
---
name: group [34342,34347]
name: group [34465,34470]
===
match
---
import_from [1020,1054]
import_from [1020,1054]
===
match
---
name: type_ [8341,8346]
name: type_ [8341,8346]
===
match
---
name: Encoding [5653,5661]
name: Encoding [5653,5661]
===
match
---
atom_expr [4409,4459]
atom_expr [4409,4459]
===
match
---
name: value [7186,7191]
name: value [7186,7191]
===
match
---
operator: } [24355,24356]
operator: } [24478,24479]
===
match
---
atom_expr [4673,4692]
atom_expr [4673,4692]
===
match
---
name: _serialize [10074,10084]
name: _serialize [10000,10010]
===
match
---
comparison [13748,13790]
comparison [13871,13913]
===
match
---
name: TaskGroup [33154,33163]
name: TaskGroup [33277,33286]
===
match
---
trailer [33817,33840]
trailer [33940,33963]
===
match
---
atom_expr [11163,11170]
atom_expr [11286,11293]
===
match
---
name: var [3955,3958]
name: var [3955,3958]
===
match
---
name: deserialize_dag [27782,27797]
name: deserialize_dag [27905,27920]
===
match
---
name: dag [27471,27474]
name: dag [27594,27597]
===
match
---
atom_expr [6332,6351]
atom_expr [6332,6351]
===
match
---
name: op_predefined_extra_links [19697,19722]
name: op_predefined_extra_links [19820,19845]
===
match
---
operator: = [19826,19827]
operator: = [19949,19950]
===
match
---
name: deserialize_dag [31655,31670]
name: deserialize_dag [31778,31793]
===
match
---
operator: = [9905,9906]
operator: = [9920,9921]
===
match
---
simple_stmt [17188,17239]
simple_stmt [17311,17362]
===
match
---
trailer [33376,33389]
trailer [33499,33512]
===
match
---
return_stmt [10326,10341]
return_stmt [10449,10464]
===
match
---
trailer [17293,17304]
trailer [17416,17427]
===
match
---
atom_expr [4579,4605]
atom_expr [4579,4605]
===
match
---
trailer [29934,29954]
trailer [30057,30077]
===
match
---
sync_comp_for [9254,9317]
sync_comp_for [9248,9311]
===
match
---
dictorsetmaker [2292,2608]
dictorsetmaker [2292,2608]
===
match
---
tfpdef [5737,5745]
tfpdef [5737,5745]
===
match
---
expr_stmt [19350,19382]
expr_stmt [19473,19505]
===
match
---
suite [21832,24400]
suite [21955,24523]
===
match
---
param [10430,10434]
param [10553,10557]
===
match
---
name: BaseOperator [3774,3786]
name: BaseOperator [3774,3786]
===
match
---
operator: = [25110,25111]
operator: = [25233,25234]
===
match
---
atom [32386,32409]
atom [32509,32532]
===
match
---
name: json_dict [31063,31072]
name: json_dict [31186,31195]
===
match
---
trailer [12453,12462]
trailer [12576,12585]
===
match
---
name: _is_constructor_param [6044,6065]
name: _is_constructor_param [6044,6065]
===
match
---
name: ValueError [31579,31589]
name: ValueError [31702,31712]
===
match
---
atom_expr [31890,31921]
atom_expr [32013,32044]
===
match
---
name: encoded_group [33314,33327]
name: encoded_group [33437,33450]
===
match
---
expr_stmt [8523,8565]
expr_stmt [8517,8559]
===
match
---
name: value [7343,7348]
name: value [7343,7348]
===
match
---
name: update [19723,19729]
name: update [19846,19852]
===
match
---
name: plugins_manager [23899,23914]
name: plugins_manager [24022,24037]
===
match
---
decorator [26077,26091]
decorator [26200,26214]
===
match
---
name: k [28460,28461]
name: k [28583,28584]
===
match
---
simple_stmt [8269,8357]
simple_stmt [8269,8357]
===
match
---
decorator [4612,4625]
decorator [4612,4625]
===
match
---
operator: = [16177,16178]
operator: = [16300,16301]
===
match
---
name: isinstance [5224,5234]
name: isinstance [5224,5234]
===
match
---
atom_expr [32483,32497]
atom_expr [32606,32620]
===
match
---
name: Any [7486,7489]
name: Any [7486,7489]
===
match
---
name: _deserialize_deps [19991,20008]
name: _deserialize_deps [20114,20131]
===
match
---
fstring_end: " [16512,16513]
fstring_end: " [16635,16636]
===
match
---
expr_stmt [32038,32988]
expr_stmt [32161,33111]
===
match
---
name: deps [16113,16117]
name: deps [16236,16240]
===
match
---
name: op [15440,15442]
name: op [15563,15565]
===
match
---
parameters [12843,12890]
parameters [12966,13013]
===
match
---
return_stmt [31274,31290]
return_stmt [31397,31413]
===
match
---
operator: , [32103,32104]
operator: , [32226,32227]
===
match
---
name: operator_extra_link [24904,24923]
name: operator_extra_link [25027,25046]
===
match
---
trailer [19452,19479]
trailer [19575,19602]
===
match
---
simple_stmt [19983,20012]
simple_stmt [20106,20135]
===
match
---
atom_expr [8234,8255]
atom_expr [8234,8255]
===
match
---
name: Any [33117,33120]
name: Any [33240,33243]
===
match
---
trailer [20654,20690]
trailer [20777,20813]
===
match
---
name: op [20780,20782]
name: op [20903,20905]
===
match
---
return_stmt [9841,9914]
return_stmt [9856,9929]
===
match
---
trailer [8703,8708]
trailer [8697,8702]
===
match
---
operator: = [33371,33372]
operator: = [33494,33495]
===
match
---
operator: , [21044,21045]
operator: , [21167,21168]
===
match
---
simple_stmt [11595,11642]
simple_stmt [11718,11765]
===
match
---
operator: } [5690,5691]
operator: } [5690,5691]
===
match
---
name: attrname [20847,20855]
name: attrname [20970,20978]
===
match
---
name: cls [8419,8422]
name: cls [8413,8416]
===
match
---
operator: , [4064,4065]
operator: , [4064,4065]
===
match
---
name: get_python_source [9692,9709]
name: get_python_source [9686,9703]
===
match
---
operator: , [19143,19144]
operator: , [19266,19267]
===
match
---
operator: , [23563,23564]
operator: , [23686,23687]
===
match
---
atom_expr [1162,1185]
atom_expr [1162,1185]
===
match
---
argument [9900,9913]
argument [9915,9928]
===
match
---
atom_expr [21425,21475]
atom_expr [21548,21598]
===
match
---
trailer [11112,11115]
trailer [11235,11238]
===
match
---
expr_stmt [9238,9318]
expr_stmt [9232,9312]
===
match
---
trailer [27223,27236]
trailer [27346,27359]
===
match
---
tfpdef [12673,12686]
tfpdef [12796,12809]
===
match
---
name: _load_operator_extra_links [17660,17686]
name: _load_operator_extra_links [17783,17809]
===
match
---
name: serialize_dag [31124,31137]
name: serialize_dag [31247,31260]
===
match
---
simple_stmt [1722,1756]
simple_stmt [1722,1756]
===
match
---
simple_stmt [21841,22120]
simple_stmt [21964,22243]
===
match
---
trailer [5106,5119]
trailer [5106,5119]
===
match
---
name: str [9132,9135]
name: str [9126,9129]
===
match
---
name: type_ [5559,5564]
name: type_ [5559,5564]
===
match
---
operator: } [16579,16580]
operator: } [16702,16703]
===
match
---
name: value [6966,6971]
name: value [6966,6971]
===
match
---
name: validate [5287,5295]
name: validate [5287,5295]
===
match
---
operator: , [967,968]
operator: , [967,968]
===
match
---
atom_expr [20268,20298]
atom_expr [20391,20421]
===
match
---
name: serialized_obj [31671,31685]
name: serialized_obj [31794,31808]
===
match
---
name: default [26531,26538]
name: default [26654,26661]
===
match
---
argument [33617,33634]
argument [33740,33757]
===
match
---
trailer [8287,8356]
trailer [8287,8356]
===
match
---
import_from [2160,2214]
import_from [2160,2214]
===
match
---
operator: , [8248,8249]
operator: , [8248,8249]
===
match
---
simple_stmt [15470,15525]
simple_stmt [15593,15648]
===
match
---
operator: , [2344,2345]
operator: , [2344,2345]
===
match
---
name: var [7473,7476]
name: var [7473,7476]
===
match
---
return_stmt [13857,13869]
return_stmt [13980,13992]
===
match
---
operator: , [21775,21776]
operator: , [21898,21899]
===
match
---
return_stmt [11085,11140]
return_stmt [11208,11263]
===
match
---
name: _deserialize_datetime [19358,19379]
name: _deserialize_datetime [19481,19502]
===
match
---
operator: , [6409,6410]
operator: , [6409,6410]
===
match
---
name: airflow [1871,1878]
name: airflow [1871,1878]
===
match
---
name: dag [30904,30907]
name: dag [31027,31030]
===
match
---
name: RELATIVEDELTA [11848,11861]
name: RELATIVEDELTA [11971,11984]
===
match
---
not_test [9290,9311]
not_test [9284,9305]
===
match
---
suite [2951,13870]
suite [2951,13993]
===
match
---
name: TIMEDELTA [11691,11700]
name: TIMEDELTA [11814,11823]
===
match
---
name: BaseSerialization [25472,25489]
name: BaseSerialization [25595,25612]
===
match
---
not_test [20476,20498]
not_test [20599,20621]
===
match
---
arglist [26896,26922]
arglist [27019,27045]
===
match
---
name: Any [5589,5592]
name: Any [5589,5592]
===
match
---
string: "timezone" [28465,28475]
string: "timezone" [28588,28598]
===
match
---
atom_expr [33373,33417]
atom_expr [33496,33540]
===
match
---
trailer [30356,30411]
trailer [30479,30534]
===
match
---
trailer [33389,33417]
trailer [33512,33540]
===
match
---
param [24463,24511]
param [24586,24634]
===
match
---
name: serialize_op [15718,15730]
name: serialize_op [15841,15853]
===
match
---
suite [9668,9716]
suite [9662,9710]
===
match
---
operator: } [10955,10956]
operator: } [11078,11079]
===
match
---
atom [18107,18278]
atom [18230,18401]
===
match
---
atom [6674,6676]
atom [6674,6676]
===
match
---
param [4014,4018]
param [4014,4018]
===
match
---
exprlist [11120,11124]
exprlist [11243,11247]
===
match
---
operator: , [16879,16880]
operator: , [17002,17003]
===
match
---
trailer [11318,11323]
trailer [11441,11446]
===
match
---
name: json_dict [31255,31264]
name: json_dict [31378,31387]
===
match
---
name: _group_id [32094,32103]
name: _group_id [32217,32226]
===
match
---
name: cls [5894,5897]
name: cls [5894,5897]
===
match
---
trailer [15813,15834]
trailer [15936,15957]
===
match
---
return_stmt [5645,5691]
return_stmt [5645,5691]
===
match
---
name: _CONSTRUCTOR_PARAMS [14199,14218]
name: _CONSTRUCTOR_PARAMS [14322,14341]
===
match
---
simple_stmt [31235,31266]
simple_stmt [31358,31389]
===
match
---
name: str [27821,27824]
name: str [27944,27947]
===
match
---
name: update [2841,2847]
name: update [2841,2847]
===
match
---
trailer [23680,23682]
trailer [23803,23805]
===
match
---
param [4380,4384]
param [4380,4384]
===
match
---
dictorsetmaker [33712,33936]
dictorsetmaker [33835,34059]
===
match
---
suite [16154,16600]
suite [16277,16723]
===
match
---
name: _upstream_task_ids [30838,30856]
name: _upstream_task_ids [30961,30979]
===
match
---
comparison [33749,33764]
comparison [33872,33887]
===
match
---
arglist [9019,9059]
arglist [9013,9053]
===
match
---
simple_stmt [15411,15462]
simple_stmt [15534,15585]
===
match
---
atom_expr [28497,28525]
atom_expr [28620,28648]
===
match
---
trailer [21382,21407]
trailer [21505,21530]
===
match
---
arglist [5336,5355]
arglist [5336,5355]
===
match
---
atom_expr [30139,30147]
atom_expr [30262,30270]
===
match
---
atom_expr [24266,24357]
atom_expr [24389,24480]
===
match
---
name: _decorated_fields [28837,28854]
name: _decorated_fields [28960,28977]
===
match
---
name: setattr [20312,20319]
name: setattr [20435,20442]
===
match
---
name: SerializationError [1278,1296]
name: SerializationError [1278,1296]
===
match
---
name: serialized_obj [4657,4671]
name: serialized_obj [4657,4671]
===
match
---
arglist [8843,8867]
arglist [8837,8861]
===
match
---
comparison [19954,19965]
comparison [20077,20088]
===
match
---
trailer [8616,8620]
trailer [8610,8614]
===
match
---
trailer [8330,8336]
trailer [8330,8336]
===
match
---
subscriptlist [6576,6584]
subscriptlist [6576,6584]
===
match
---
comparison [23627,23682]
comparison [23750,23805]
===
match
---
name: cache [1154,1159]
name: cache [1154,1159]
===
match
---
name: serialize_to_json [26878,26895]
name: serialize_to_json [27001,27018]
===
match
---
name: module_name [16205,16216]
name: module_name [16328,16339]
===
match
---
operator: , [20753,20754]
operator: , [20876,20877]
===
match
---
atom_expr [12089,12108]
atom_expr [12212,12231]
===
match
---
name: k [27977,27978]
name: k [28100,28101]
===
match
---
atom_expr [16334,16535]
atom_expr [16457,16658]
===
match
---
simple_stmt [14591,14624]
simple_stmt [14714,14747]
===
match
---
name: var [12266,12269]
name: var [12389,12392]
===
match
---
string: """A JSON serializable representation of TaskGroup.""" [31757,31811]
string: """A JSON serializable representation of TaskGroup.""" [31880,31934]
===
match
---
string: """Deserializes a python dict stored with type decorators and         reconstructs all DAGs and operators it contains.         """ [4762,4892]
string: """Deserializes a python dict stored with type decorators and         reconstructs all DAGs and operators it contains.         """ [4762,4892]
===
match
---
argument [9040,9059]
argument [9034,9053]
===
match
---
operator: = [33595,33596]
operator: = [33718,33719]
===
match
---
atom_expr [6894,6933]
atom_expr [6894,6933]
===
match
---
name: keys [20292,20296]
name: keys [20415,20419]
===
match
---
name: json [5396,5400]
name: json [5396,5400]
===
match
---
name: operator_extra_link [25244,25263]
name: operator_extra_link [25367,25386]
===
match
---
atom_expr [33185,33208]
atom_expr [33308,33331]
===
match
---
atom_expr [15811,15834]
atom_expr [15934,15957]
===
match
---
suite [11255,11324]
suite [11378,11447]
===
match
---
operator: , [3083,3084]
operator: , [3083,3084]
===
match
---
trailer [33728,33733]
trailer [33851,33856]
===
match
---
name: _CONSTRUCTOR_PARAMS [26569,26588]
name: _CONSTRUCTOR_PARAMS [26692,26711]
===
match
---
name: isinstance [32429,32439]
name: isinstance [32552,32562]
===
match
---
atom_expr [8901,8916]
atom_expr [8895,8910]
===
match
---
trailer [8560,8565]
trailer [8554,8559]
===
match
---
trailer [11166,11170]
trailer [11289,11293]
===
match
---
decorator [33026,33039]
decorator [33149,33162]
===
match
---
name: items [14308,14313]
name: items [14431,14436]
===
match
---
import_name [991,1003]
import_name [991,1003]
===
match
---
name: template_field [17004,17018]
name: template_field [17127,17141]
===
match
---
import_as_names [927,989]
import_as_names [927,989]
===
match
---
name: object_to_serialize [6978,6997]
name: object_to_serialize [6978,6997]
===
match
---
suite [27675,27756]
suite [27798,27879]
===
match
---
trailer [5163,5211]
trailer [5163,5211]
===
match
---
decorator [3724,3737]
decorator [3724,3737]
===
match
---
name: str [8289,8292]
name: str [8289,8292]
===
match
---
name: op_predefined_extra_link [24300,24324]
name: op_predefined_extra_link [24423,24447]
===
match
---
name: SET [12064,12067]
name: SET [12187,12190]
===
match
---
name: classmethod [10397,10408]
name: classmethod [10520,10531]
===
match
---
suite [5437,5516]
suite [5437,5516]
===
match
---
atom_expr [10180,10225]
atom_expr [10303,10348]
===
match
---
import_name [824,839]
import_name [824,839]
===
match
---
operator: @ [15095,15096]
operator: @ [15218,15219]
===
match
---
funcdef [21734,24400]
funcdef [21857,24523]
===
match
---
name: attrname [21182,21190]
name: attrname [21305,21313]
===
match
---
raise_stmt [5450,5515]
raise_stmt [5450,5515]
===
match
---
name: dict [4436,4440]
name: dict [4436,4440]
===
match
---
trailer [30489,30534]
trailer [30612,30657]
===
match
---
name: single_op_link_class [24231,24251]
name: single_op_link_class [24354,24374]
===
match
---
tfpdef [4657,4692]
tfpdef [4657,4692]
===
match
---
name: Dict [4673,4677]
name: Dict [4673,4677]
===
match
---
param [15240,15256]
param [15363,15379]
===
match
---
name: task_group [31993,32003]
name: task_group [32116,32126]
===
match
---
name: var [10308,10311]
name: var [10431,10434]
===
match
---
simple_stmt [28584,28618]
simple_stmt [28707,28741]
===
match
---
return_stmt [11714,11752]
return_stmt [11837,11875]
===
match
---
string: "_group_id" [33404,33415]
string: "_group_id" [33527,33538]
===
match
---
name: Union [4409,4414]
name: Union [4409,4414]
===
match
---
fstring [16565,16598]
fstring [16688,16721]
===
match
---
tfpdef [15137,15151]
tfpdef [15260,15274]
===
match
---
operator: = [16867,16868]
operator: = [16990,16991]
===
match
---
atom_expr [21535,21575]
atom_expr [21658,21698]
===
match
---
param [27798,27802]
param [27921,27925]
===
match
---
operator: , [5907,5908]
operator: , [5907,5908]
===
match
---
trailer [11739,11752]
trailer [11862,11875]
===
match
---
atom_expr [5653,5665]
atom_expr [5653,5665]
===
match
---
name: encoded_dag [29910,29921]
name: encoded_dag [30033,30044]
===
match
---
name: weekday [9463,9470]
name: weekday [9457,9464]
===
match
---
name: encoded_var [10670,10681]
name: encoded_var [10793,10804]
===
match
---
dotted_name [1302,1329]
dotted_name [1302,1329]
===
match
---
arglist [6401,6424]
arglist [6401,6424]
===
match
---
suite [31752,34348]
suite [31875,34471]
===
match
---
operator: , [4686,4687]
operator: , [4686,4687]
===
match
---
name: prefix_group_id [32183,32198]
name: prefix_group_id [32306,32321]
===
match
---
trailer [24056,24124]
trailer [24179,24247]
===
match
---
name: cls [7107,7110]
name: cls [7107,7110]
===
match
---
name: _encode [9011,9018]
name: _encode [9005,9012]
===
match
---
suite [28476,28526]
suite [28599,28649]
===
match
---
expr_stmt [16861,16902]
expr_stmt [16984,17025]
===
match
---
atom_expr [6316,6352]
atom_expr [6316,6352]
===
match
---
string: "sla" [19145,19150]
string: "sla" [19268,19273]
===
match
---
fstring_expr [5181,5197]
fstring_expr [5181,5197]
===
match
---
name: _encode [8589,8596]
name: _encode [8583,8590]
===
match
---
name: klass [16582,16587]
name: klass [16705,16710]
===
match
---
trailer [31484,31488]
trailer [31607,31611]
===
match
---
expr_stmt [30139,30153]
expr_stmt [30262,30276]
===
match
---
name: _OPERATOR_EXTRA_LINKS [2819,2840]
name: _OPERATOR_EXTRA_LINKS [2819,2840]
===
match
---
operator: , [16895,16896]
operator: , [17018,17019]
===
match
---
name: k [28635,28636]
name: k [28758,28759]
===
match
---
funcdef [2620,2925]
funcdef [2620,2925]
===
match
---
operator: , [9038,9039]
operator: , [9032,9033]
===
match
---
name: kwargs [14391,14397]
name: kwargs [14514,14520]
===
match
---
trailer [8157,8162]
trailer [8157,8162]
===
match
---
name: _deserialize_timezone [12418,12439]
name: _deserialize_timezone [12541,12562]
===
match
---
string: '_task_group' [27048,27061]
string: '_task_group' [27171,27184]
===
match
---
dotted_name [1422,1440]
dotted_name [1422,1440]
===
match
---
atom_expr [14234,14243]
atom_expr [14357,14366]
===
match
---
trailer [8279,8287]
trailer [8279,8287]
===
match
---
suite [15705,15849]
suite [15828,15972]
===
match
---
name: subdag [30446,30452]
name: subdag [30569,30575]
===
match
---
atom_expr [20116,20135]
atom_expr [20239,20258]
===
match
---
operator: , [28957,28958]
operator: , [29080,29081]
===
match
---
name: var [5828,5831]
name: var [5828,5831]
===
match
---
trailer [6575,6585]
trailer [6575,6585]
===
match
---
name: instance [12673,12681]
name: instance [12796,12804]
===
match
---
if_stmt [33307,33353]
if_stmt [33430,33476]
===
match
---
name: dict [4077,4081]
name: dict [4077,4081]
===
match
---
name: datetime [3205,3213]
name: datetime [3205,3213]
===
match
---
if_stmt [22241,22359]
if_stmt [22364,22482]
===
match
---
name: __name__ [5186,5194]
name: __name__ [5186,5194]
===
match
---
trailer [32939,32977]
trailer [33062,33100]
===
match
---
name: var [20810,20813]
name: var [20933,20936]
===
match
---
operator: { [25182,25183]
operator: { [25305,25306]
===
match
---
trailer [10336,10341]
trailer [10459,10464]
===
match
---
trailer [26950,26959]
trailer [27073,27082]
===
match
---
name: _deserialize_datetime [28680,28701]
name: _deserialize_datetime [28803,28824]
===
match
---
name: _operator_link_class_path [24098,24123]
name: _operator_link_class_path [24221,24246]
===
match
---
simple_stmt [16612,16640]
simple_stmt [16735,16763]
===
match
---
name: seconds [12596,12603]
name: seconds [12719,12726]
===
match
---
trailer [17847,17849]
trailer [17970,17972]
===
match
---
atom_expr [19354,19382]
atom_expr [19477,19505]
===
match
---
trailer [15265,15275]
trailer [15388,15398]
===
match
---
name: from_dict [4569,4578]
name: from_dict [4569,4578]
===
match
---
name: task_group [32172,32182]
name: task_group [32295,32305]
===
match
---
name: Optional [969,977]
name: Optional [969,977]
===
match
---
operator: = [16217,16218]
operator: = [16340,16341]
===
match
---
and_test [8464,8509]
and_test [8458,8503]
===
match
---
sync_comp_for [9885,9897]
sync_comp_for [9900,9912]
===
match
---
simple_stmt [24522,24848]
simple_stmt [24645,24971]
===
match
---
operator: = [3193,3194]
operator: = [3193,3194]
===
match
---
atom_expr [10333,10341]
atom_expr [10456,10464]
===
match
---
name: dag [29486,29489]
name: dag [29609,29612]
===
match
---
operator: = [15178,15179]
operator: = [15301,15302]
===
match
---
name: Optional [33219,33227]
name: Optional [33342,33350]
===
match
---
name: var [8245,8248]
name: var [8245,8248]
===
match
---
name: cls [31327,31330]
name: cls [31450,31453]
===
match
---
name: Validator [3364,3373]
name: Validator [3364,3373]
===
match
---
atom_expr [20183,20200]
atom_expr [20306,20323]
===
match
---
name: operator_extra_link [25286,25305]
name: operator_extra_link [25409,25428]
===
match
---
name: DATETIME [11350,11358]
name: DATETIME [11473,11481]
===
match
---
return_stmt [21129,21140]
return_stmt [21252,21263]
===
match
---
simple_stmt [13857,13870]
simple_stmt [13980,13993]
===
match
---
suite [10758,10821]
suite [10881,10944]
===
match
---
trailer [28197,28224]
trailer [28320,28347]
===
match
---
trailer [11251,11254]
trailer [11374,11377]
===
match
---
name: Union [6514,6519]
name: Union [6514,6519]
===
match
---
atom_expr [8137,8163]
atom_expr [8137,8163]
===
match
---
trailer [10220,10225]
trailer [10343,10348]
===
match
---
trailer [9284,9286]
trailer [9278,9280]
===
match
---
tfpdef [5559,5569]
tfpdef [5559,5569]
===
match
---
subscriptlist [4030,4071]
subscriptlist [4030,4071]
===
match
---
name: k [28094,28095]
name: k [28217,28218]
===
match
---
simple_stmt [7564,7992]
simple_stmt [7564,7992]
===
match
---
name: __class__ [15443,15452]
name: __class__ [15566,15575]
===
match
---
name: task [28329,28333]
name: task [28452,28456]
===
match
---
name: k [9249,9250]
name: k [9243,9244]
===
match
---
trailer [18072,18082]
trailer [18195,18205]
===
match
---
atom_expr [15411,15437]
atom_expr [15534,15560]
===
match
---
name: __get_constructor_defaults [26099,26125]
name: __get_constructor_defaults [26222,26248]
===
match
---
simple_stmt [19848,19893]
simple_stmt [19971,20016]
===
match
---
trailer [10143,10159]
trailer [10266,10282]
===
match
---
string: '_access_control' [26354,26371]
string: '_access_control' [26477,26494]
===
match
---
trailer [24324,24329]
trailer [24447,24452]
===
match
---
name: var [11221,11224]
name: var [11344,11347]
===
match
---
string: "template_fields" [19255,19272]
string: "template_fields" [19378,19395]
===
match
---
name: Encoding [5579,5587]
name: Encoding [5579,5587]
===
match
---
atom_expr [32853,32887]
atom_expr [32976,33010]
===
match
---
funcdef [12627,12790]
funcdef [12750,12913]
===
match
---
return_stmt [8269,8356]
return_stmt [8269,8356]
===
match
---
param [4657,4692]
param [4657,4692]
===
match
---
name: cls [29931,29934]
name: cls [30054,30057]
===
match
---
name: v [9889,9890]
name: v [9904,9905]
===
match
---
name: _serialize [32842,32852]
name: _serialize [32965,32975]
===
match
---
name: RELATIVEDELTA [9626,9639]
name: RELATIVEDELTA [9620,9633]
===
match
---
exprlist [27977,27981]
exprlist [28100,28104]
===
match
---
atom_expr [17022,17053]
atom_expr [17145,17176]
===
match
---
import_from [908,989]
import_from [908,989]
===
match
---
name: _serialize [32754,32764]
name: _serialize [32877,32887]
===
match
---
simple_stmt [24961,25020]
simple_stmt [25084,25143]
===
match
---
suite [31560,31636]
suite [31683,31759]
===
match
---
and_test [7212,7257]
and_test [7212,7257]
===
match
---
operator: - [20266,20267]
operator: - [20389,20390]
===
match
---
atom_expr [5325,5356]
atom_expr [5325,5356]
===
match
---
name: task_group [32770,32780]
name: task_group [32893,32903]
===
match
---
if_stmt [9331,9576]
if_stmt [9325,9570]
===
match
---
fstring_expr [16497,16512]
fstring_expr [16620,16635]
===
match
---
atom [24299,24356]
atom [24422,24479]
===
match
---
operator: , [19122,19123]
operator: , [19245,19246]
===
match
---
name: Union [3763,3768]
name: Union [3763,3768]
===
match
---
expr_stmt [26175,26382]
expr_stmt [26298,26505]
===
match
---
atom_expr [28676,28704]
atom_expr [28799,28827]
===
match
---
name: list [21795,21799]
name: list [21918,21922]
===
match
---
testlist_comp [26963,27020]
testlist_comp [27086,27143]
===
match
---
trailer [27743,27750]
trailer [27866,27873]
===
match
---
name: set [18994,18997]
name: set [19117,19120]
===
match
---
trailer [29489,29500]
trailer [29612,29623]
===
match
---
return_stmt [5795,5854]
return_stmt [5795,5854]
===
match
---
suite [25491,31694]
suite [25614,31817]
===
match
---
expr_stmt [19188,19221]
expr_stmt [19311,19344]
===
match
---
expr_stmt [27034,27121]
expr_stmt [27157,27244]
===
match
---
operator: -> [5747,5749]
operator: -> [5747,5749]
===
match
---
param [12849,12863]
param [12972,12986]
===
match
---
atom_expr [2223,2250]
atom_expr [2223,2250]
===
match
---
atom_expr [27363,27390]
atom_expr [27486,27513]
===
match
---
trailer [8732,8751]
trailer [8726,8745]
===
match
---
atom_expr [13748,13781]
atom_expr [13871,13904]
===
match
---
atom_expr [9136,9144]
atom_expr [9130,9138]
===
match
---
trailer [33916,33928]
trailer [34039,34051]
===
match
---
name: cls [4014,4017]
name: cls [4014,4017]
===
match
---
decorator [2613,2620]
decorator [2613,2620]
===
match
---
trailer [31685,31692]
trailer [31808,31815]
===
match
---
trailer [21371,21382]
trailer [21494,21505]
===
match
---
return_stmt [9588,9640]
return_stmt [9582,9634]
===
match
---
name: OP [11252,11254]
name: OP [11375,11377]
===
match
---
name: classmethod [7437,7448]
name: classmethod [7437,7448]
===
match
---
trailer [16401,16405]
trailer [16524,16528]
===
match
---
name: serialized_obj [5407,5421]
name: serialized_obj [5407,5421]
===
match
---
arglist [8646,8654]
arglist [8640,8648]
===
match
---
operator: @ [26077,26078]
operator: @ [26200,26201]
===
match
---
trailer [20190,20200]
trailer [20313,20323]
===
match
---
atom_expr [32172,32198]
atom_expr [32295,32321]
===
match
---
trailer [15863,15868]
trailer [15986,15991]
===
match
---
trailer [33928,33934]
trailer [34051,34057]
===
match
---
atom_expr [9451,9470]
atom_expr [9445,9464]
===
match
---
arglist [30357,30410]
arglist [30480,30533]
===
match
---
trailer [12253,12256]
trailer [12376,12379]
===
match
---
atom_expr [9654,9667]
atom_expr [9648,9661]
===
match
---
name: getattr [30282,30289]
name: getattr [30405,30412]
===
match
---
name: _task_type [15167,15177]
name: _task_type [15290,15300]
===
match
---
name: __name__ [16588,16596]
name: __name__ [16711,16719]
===
match
---
name: task_type [14929,14938]
name: task_type [15052,15061]
===
match
---
name: DAT [11248,11251]
name: DAT [11371,11374]
===
match
---
name: self [14784,14788]
name: self [14907,14911]
===
match
---
atom_expr [9266,9286]
atom_expr [9260,9280]
===
match
---
sync_comp_for [11116,11139]
sync_comp_for [11239,11262]
===
match
---
decorated [12795,13870]
decorated [12918,13993]
===
match
---
string: 'weekday' [11916,11925]
string: 'weekday' [12039,12048]
===
match
---
name: airflow [1993,2000]
name: airflow [1993,2000]
===
match
---
atom_expr [21804,21831]
atom_expr [21927,21954]
===
match
---
name: SerializedDAG [19053,19066]
name: SerializedDAG [19176,19189]
===
match
---
comparison [11835,11861]
comparison [11958,11984]
===
match
---
name: var [8901,8904]
name: var [8895,8898]
===
match
---
trailer [5661,5665]
trailer [5661,5665]
===
match
---
name: var [9710,9713]
name: var [9704,9707]
===
match
---
name: op_extra_links_from_plugin [18304,18330]
name: op_extra_links_from_plugin [18427,18453]
===
match
---
operator: , [6284,6285]
operator: , [6284,6285]
===
match
---
operator: = [9552,9553]
operator: = [9546,9547]
===
match
---
operator: , [26464,26465]
operator: , [26587,26588]
===
match
---
name: _type [33749,33754]
name: _type [33872,33877]
===
match
---
name: op [15240,15242]
name: op [15363,15365]
===
match
---
name: encoded_op [17135,17145]
name: encoded_op [17258,17268]
===
match
---
operator: , [10433,10434]
operator: , [10556,10557]
===
match
---
name: cls [3753,3756]
name: cls [3753,3756]
===
match
---
tfpdef [3758,3811]
tfpdef [3758,3811]
===
match
---
trailer [13771,13781]
trailer [13894,13904]
===
match
---
operator: , [33851,33852]
operator: , [33974,33975]
===
match
---
operator: { [17575,17576]
operator: { [17698,17699]
===
match
---
name: initialize_extra_operators_links_plugins [22189,22229]
name: initialize_extra_operators_links_plugins [22312,22352]
===
match
---
not_test [25035,25074]
not_test [25158,25197]
===
match
---
trailer [11026,11041]
trailer [11149,11164]
===
match
---
operator: , [25470,25471]
operator: , [25593,25594]
===
match
---
operator: , [982,983]
operator: , [982,983]
===
match
---
name: get_serialized_fields [20222,20243]
name: get_serialized_fields [20345,20366]
===
match
---
operator: , [18843,18844]
operator: , [18966,18967]
===
match
---
expr_stmt [15162,15189]
expr_stmt [15285,15312]
===
match
---
classdef [31696,34348]
classdef [31819,34471]
===
match
---
name: BaseOperator [17166,17178]
name: BaseOperator [17289,17301]
===
match
---
param [4652,4656]
param [4652,4656]
===
match
---
trailer [29883,29905]
trailer [30006,30028]
===
match
---
trailer [30568,30575]
trailer [30691,30698]
===
match
---
operator: , [5350,5351]
operator: , [5350,5351]
===
match
---
dictorsetmaker [26412,26553]
dictorsetmaker [26535,26676]
===
match
---
expr_stmt [24961,25019]
expr_stmt [25084,25142]
===
match
---
string: "task_dict" [28431,28442]
string: "task_dict" [28554,28565]
===
match
---
name: val [33729,33732]
name: val [33852,33855]
===
match
---
name: value [13785,13790]
name: value [13908,13913]
===
match
---
string: "label" [17318,17325]
string: "label" [17441,17448]
===
match
---
operator: } [19829,19830]
operator: } [19952,19953]
===
match
---
string: """     Returns operator extra links - both the ones that are built in and the ones that come from     the providers.      :return: set of extra links     """ [2656,2814]
string: """     Returns operator extra links - both the ones that are built in and the ones that come from     the providers.      :return: set of extra links     """ [2656,2814]
===
match
---
atom_expr [8370,8391]
atom_expr [8370,8391]
===
match
---
string: "airflow.ti_deps.deps." [16282,16305]
string: "airflow.ti_deps.deps." [16405,16428]
===
match
---
operator: = [12388,12389]
operator: = [12511,12512]
===
match
---
trailer [19323,19332]
trailer [19446,19455]
===
match
---
name: k [19954,19955]
name: k [20077,20078]
===
match
---
atom_expr [32770,32801]
atom_expr [32893,32924]
===
match
---
subscriptlist [31910,31918]
subscriptlist [32033,32041]
===
match
---
operator: { [33698,33699]
operator: { [33821,33822]
===
match
---
trailer [16624,16632]
trailer [16747,16755]
===
match
---
name: serialize_op [16991,17003]
name: serialize_op [17114,17126]
===
match
---
name: str [3816,3819]
name: str [3816,3819]
===
match
---
simple_stmt [27034,27122]
simple_stmt [27157,27245]
===
match
---
trailer [15375,15402]
trailer [15498,15525]
===
match
---
name: cls [16926,16929]
name: cls [17049,17052]
===
match
---
suite [18973,19001]
suite [19096,19124]
===
match
---
arglist [20320,20331]
arglist [20443,20454]
===
match
---
name: int [3067,3070]
name: int [3067,3070]
===
match
---
name: _decorated_fields [25995,26012]
name: _decorated_fields [26118,26135]
===
match
---
atom_expr [31537,31559]
atom_expr [31660,31682]
===
match
---
name: dag [1437,1440]
name: dag [1437,1440]
===
match
---
name: keys_to_set_none [29861,29877]
name: keys_to_set_none [29984,30000]
===
match
---
name: v [9252,9253]
name: v [9246,9247]
===
match
---
atom_expr [32838,32888]
atom_expr [32961,33011]
===
match
---
string: "has_on_failure_callback" [29763,29788]
string: "has_on_failure_callback" [29886,29911]
===
match
---
atom_expr [19852,19892]
atom_expr [19975,20015]
===
match
---
trailer [20632,20691]
trailer [20755,20814]
===
match
---
argument [3961,3978]
argument [3961,3978]
===
match
---
atom_expr [16146,16153]
atom_expr [16269,16276]
===
match
---
name: tz [12451,12453]
name: tz [12574,12576]
===
match
---
operator: } [25382,25383]
operator: } [25505,25506]
===
match
---
argument [14425,14430]
argument [14548,14553]
===
match
---
trailer [20243,20245]
trailer [20366,20368]
===
match
---
decorator [3985,3998]
decorator [3985,3998]
===
match
---
if_stmt [17653,18888]
if_stmt [17776,19011]
===
match
---
name: airflow [1373,1380]
name: airflow [1373,1380]
===
match
---
atom_expr [32945,32975]
atom_expr [33068,33098]
===
match
---
trailer [30394,30410]
trailer [30517,30533]
===
match
---
name: cls [26874,26877]
name: cls [26997,27000]
===
match
---
trailer [30116,30123]
trailer [30239,30246]
===
match
---
if_stmt [17315,17487]
if_stmt [17438,17610]
===
match
---
trailer [26895,26923]
trailer [27018,27046]
===
match
---
operator: = [28674,28675]
operator: = [28797,28798]
===
match
---
name: _type [33888,33893]
name: _type [34011,34016]
===
match
---
operator: , [20322,20323]
operator: , [20445,20446]
===
match
---
param [20765,20779]
param [20888,20902]
===
match
---
trailer [31909,31919]
trailer [32032,32042]
===
match
---
expr_stmt [31464,31518]
expr_stmt [31587,31641]
===
match
---
name: DAT [33758,33761]
name: DAT [33881,33884]
===
match
---
for_stmt [17988,18355]
for_stmt [18111,18478]
===
match
---
trailer [10199,10220]
trailer [10322,10343]
===
match
---
name: v [28872,28873]
name: v [28995,28996]
===
match
---
funcdef [17105,20711]
funcdef [17228,20834]
===
match
---
name: DAT [10109,10112]
name: DAT [10232,10235]
===
match
---
name: k [19103,19104]
name: k [19226,19227]
===
match
---
atom_expr [32750,32803]
atom_expr [32873,32926]
===
match
---
name: relativedelta [9210,9223]
name: relativedelta [9204,9217]
===
match
---
suite [26845,27597]
suite [26968,27720]
===
match
---
name: encoded_dag [29692,29703]
name: encoded_dag [29815,29826]
===
match
---
atom_expr [29408,29434]
atom_expr [29531,29557]
===
match
---
name: encoded_op_links [21777,21793]
name: encoded_op_links [21900,21916]
===
match
---
name: to_dict [30934,30941]
name: to_dict [31057,31064]
===
match
---
atom [10778,10820]
atom [10901,10943]
===
match
---
funcdef [15212,17083]
funcdef [15335,17206]
===
match
---
operator: @ [21717,21718]
operator: @ [21840,21841]
===
match
---
string: "airflow.operators.trigger_dagrun.TriggerDagRunLink" [2292,2344]
string: "airflow.operators.trigger_dagrun.TriggerDagRunLink" [2292,2344]
===
match
---
name: has_on_success_callback [29721,29744]
name: has_on_success_callback [29844,29867]
===
match
---
comparison [29763,29803]
comparison [29886,29926]
===
match
---
name: getattr [30387,30394]
name: getattr [30510,30517]
===
match
---
trailer [23947,24012]
trailer [24070,24135]
===
match
---
trailer [26494,26505]
trailer [26617,26628]
===
match
---
name: module_name [16498,16509]
name: module_name [16621,16632]
===
match
---
name: plugins_manager [17762,17777]
name: plugins_manager [17885,17900]
===
match
---
name: dict [25069,25073]
name: dict [25192,25196]
===
match
---
name: operator_extra_links [15684,15704]
name: operator_extra_links [15807,15827]
===
match
---
decorator [26723,26736]
decorator [26846,26859]
===
match
---
import_from [1722,1755]
import_from [1722,1755]
===
match
---
operator: , [18902,18903]
operator: , [19025,19026]
===
match
---
suite [30965,31291]
suite [31088,31414]
===
match
---
simple_stmt [5603,5637]
simple_stmt [5603,5637]
===
match
---
expr_stmt [24856,24891]
expr_stmt [24979,25014]
===
match
---
expr_stmt [28493,28525]
expr_stmt [28616,28648]
===
match
---
simple_stmt [16171,16189]
simple_stmt [16294,16312]
===
match
---
atom_expr [23656,23682]
atom_expr [23779,23805]
===
match
---
operator: = [3686,3687]
operator: = [3686,3687]
===
match
---
string: """Deserializes a python dict in to the DAG and operators it contains.""" [31382,31455]
string: """Deserializes a python dict in to the DAG and operators it contains.""" [31505,31578]
===
match
---
name: Dict [31905,31909]
name: Dict [32028,32032]
===
match
---
name: DAG [25467,25470]
name: DAG [25590,25593]
===
match
---
atom_expr [23810,23858]
atom_expr [23933,23981]
===
match
---
operator: @ [10396,10397]
operator: @ [10519,10520]
===
match
---
operator: } [11139,11140]
operator: } [11262,11263]
===
match
---
name: SerializationError [27612,27630]
name: SerializationError [27735,27753]
===
match
---
fstring_expr [31626,31633]
fstring_expr [31749,31756]
===
match
---
string: "_downstream_task_ids" [18950,18972]
string: "_downstream_task_ids" [19073,19095]
===
match
---
name: isinstance [5325,5335]
name: isinstance [5325,5335]
===
match
---
name: _json_schema [26685,26697]
name: _json_schema [26808,26820]
===
match
---
simple_stmt [21492,21501]
simple_stmt [21615,21624]
===
match
---
name: isinstance [10837,10847]
name: isinstance [10960,10970]
===
match
---
operator: { [26398,26399]
operator: { [26521,26522]
===
match
---
atom_expr [9007,9060]
atom_expr [9001,9054]
===
match
---
trailer [12235,12271]
trailer [12358,12394]
===
match
---
string: """Encode data by a JSON dict.""" [5603,5636]
string: """Encode data by a JSON dict.""" [5603,5636]
===
match
---
name: serialized_obj [31470,31484]
name: serialized_obj [31593,31607]
===
match
---
operator: { [16567,16568]
operator: { [16690,16691]
===
match
---
parameters [12511,12530]
parameters [12634,12653]
===
match
---
name: task [29505,29509]
name: task [29628,29632]
===
match
---
name: _deserialize_operator_extra_links [19533,19566]
name: _deserialize_operator_extra_links [19656,19689]
===
match
---
trailer [4911,4924]
trailer [4911,4924]
===
match
---
name: callable [9654,9662]
name: callable [9648,9656]
===
match
---
arglist [20488,20497]
arglist [20611,20620]
===
match
---
operator: , [1349,1350]
operator: , [1349,1350]
===
match
---
name: serialized_obj [4590,4604]
name: serialized_obj [4590,4604]
===
match
---
simple_stmt [27576,27597]
simple_stmt [27699,27720]
===
match
---
return_stmt [8578,8621]
return_stmt [8572,8615]
===
match
---
name: op [20830,20832]
name: op [20953,20955]
===
match
---
comparison [11766,11787]
comparison [11889,11910]
===
match
---
operator: , [8339,8340]
operator: , [8339,8340]
===
match
---
name: cls [15235,15238]
name: cls [15358,15361]
===
match
---
funcdef [31313,31694]
funcdef [31436,31817]
===
match
---
simple_stmt [17928,17975]
simple_stmt [18051,18098]
===
match
---
expr_stmt [3047,3089]
expr_stmt [3047,3089]
===
match
---
simple_stmt [11268,11324]
simple_stmt [11391,11447]
===
match
---
name: airflow [1512,1519]
name: airflow [1512,1519]
===
match
---
name: cls [5182,5185]
name: cls [5182,5185]
===
match
---
trailer [18240,18256]
trailer [18363,18379]
===
match
---
comparison [17866,17910]
comparison [17989,18033]
===
match
---
decorated [17088,20711]
decorated [17211,20834]
===
match
---
trailer [9540,9551]
trailer [9534,9545]
===
match
---
name: serializable_task [30290,30307]
name: serializable_task [30413,30430]
===
match
---
name: template_fields [16774,16789]
name: template_fields [16897,16912]
===
match
---
name: add [30857,30860]
name: add [30980,30983]
===
match
---
name: ui_fgcolor [32325,32335]
name: ui_fgcolor [32448,32458]
===
match
---
for_stmt [29970,30031]
for_stmt [30093,30154]
===
match
---
name: Connection [3318,3328]
name: Connection [3318,3328]
===
match
---
name: isinstance [9074,9084]
name: isinstance [9068,9078]
===
match
---
param [12512,12516]
param [12635,12639]
===
match
---
trailer [11066,11071]
trailer [11189,11194]
===
match
---
name: encoded_dag [29792,29803]
name: encoded_dag [29915,29926]
===
match
---
operator: , [26371,26372]
operator: , [26494,26495]
===
match
---
import_as_names [1695,1721]
import_as_names [1695,1721]
===
match
---
subscriptlist [33112,33120]
subscriptlist [33235,33243]
===
match
---
name: datetime [12569,12577]
name: datetime [12692,12700]
===
match
---
string: "has_on_success_callback" [29663,29688]
string: "has_on_success_callback" [29786,29811]
===
match
---
atom_expr [11015,11041]
atom_expr [11138,11164]
===
match
---
simple_stmt [3177,3216]
simple_stmt [3177,3216]
===
match
---
name: k [18901,18902]
name: k [19024,19025]
===
match
---
string: "retry_delay" [19109,19122]
string: "retry_delay" [19232,19245]
===
match
---
name: __module__ [25274,25284]
name: __module__ [25397,25407]
===
match
---
operator: ** [12031,12033]
operator: ** [12154,12156]
===
match
---
operator: , [33532,33533]
operator: , [33655,33656]
===
match
---
return_stmt [9113,9166]
return_stmt [9107,9160]
===
match
---
funcdef [27778,30908]
funcdef [27901,31031]
===
match
---
decorated [6440,7382]
decorated [6440,7382]
===
match
---
trailer [9049,9059]
trailer [9043,9053]
===
match
---
name: load_dag_schema [1706,1721]
name: load_dag_schema [1706,1721]
===
match
---
operator: , [3772,3773]
operator: , [3772,3773]
===
match
---
atom [25182,25383]
atom [25305,25506]
===
match
---
operator: { [16397,16398]
operator: { [16520,16521]
===
match
---
trailer [26715,26717]
trailer [26838,26840]
===
match
---
trailer [20855,20864]
trailer [20978,20987]
===
match
---
operator: , [9194,9195]
operator: , [9188,9189]
===
match
---
trailer [3204,3213]
trailer [3204,3213]
===
match
---
arglist [30017,30029]
arglist [30140,30152]
===
match
---
trailer [14286,14295]
trailer [14409,14418]
===
match
---
name: k [14256,14257]
name: k [14379,14380]
===
match
---
comparison [28460,28475]
comparison [28583,28598]
===
match
---
operator: , [30385,30386]
operator: , [30508,30509]
===
match
---
atom_expr [11248,11254]
atom_expr [11371,11377]
===
match
---
string: "tasks" [28099,28106]
string: "tasks" [28222,28229]
===
match
---
name: date_attr [30376,30385]
name: date_attr [30499,30508]
===
match
---
string: 'SerializedDAG' [27835,27850]
string: 'SerializedDAG' [27958,27973]
===
match
---
name: cls [28876,28879]
name: cls [28999,29002]
===
match
---
atom_expr [6949,6998]
atom_expr [6949,6998]
===
match
---
atom [26962,27021]
atom [27085,27144]
===
match
---
simple_stmt [26937,27022]
simple_stmt [27060,27145]
===
match
---
trailer [10795,10798]
trailer [10918,10921]
===
match
---
string: 'parent_dag' [30516,30528]
string: 'parent_dag' [30639,30651]
===
match
---
name: keys_to_serialize [6768,6785]
name: keys_to_serialize [6768,6785]
===
match
---
name: value [7223,7228]
name: value [7223,7228]
===
match
---
trailer [16557,16564]
trailer [16680,16687]
===
match
---
arglist [31722,31750]
arglist [31845,31873]
===
match
---
trailer [15383,15401]
trailer [15506,15524]
===
match
---
return_stmt [10696,10714]
return_stmt [10819,10837]
===
match
---
name: var [9894,9897]
name: var [9909,9912]
===
match
---
name: cls [26901,26904]
name: cls [27024,27027]
===
match
---
simple_stmt [6309,6435]
simple_stmt [6309,6435]
===
match
---
trailer [14313,14315]
trailer [14436,14438]
===
match
---
simple_stmt [27860,27905]
simple_stmt [27983,28028]
===
match
---
atom_expr [10051,10119]
atom_expr [10180,10242]
===
match
---
string: """Stringifies DAGs and operators contained by var and returns a JSON string of var.""" [3829,3916]
string: """Stringifies DAGs and operators contained by var and returns a JSON string of var.""" [3829,3916]
===
match
---
operator: - [29908,29909]
operator: - [30031,30032]
===
match
---
suite [11701,11753]
suite [11824,11876]
===
match
---
fstring_string: Cannot serialize  [16380,16397]
fstring_string: Cannot serialize  [16503,16520]
===
match
---
operator: = [2221,2222]
operator: = [2221,2222]
===
match
---
simple_stmt [1065,1093]
simple_stmt [1065,1093]
===
match
---
name: Union [5004,5009]
name: Union [5004,5009]
===
match
---
operator: , [10859,10860]
operator: , [10982,10983]
===
match
---
name: v [28702,28703]
name: v [28825,28826]
===
match
---
trailer [25305,25315]
trailer [25428,25438]
===
match
---
trailer [7222,7235]
trailer [7222,7235]
===
match
---
operator: = [9246,9247]
operator: = [9240,9241]
===
match
---
operator: , [14430,14431]
operator: , [14553,14554]
===
match
---
atom_expr [34082,34137]
atom_expr [34205,34260]
===
match
---
name: get [20666,20669]
name: get [20789,20792]
===
match
---
decorator [4946,4959]
decorator [4946,4959]
===
match
---
name: serialize_pod [8547,8560]
name: serialize_pod [8541,8554]
===
match
---
simple_stmt [9681,9716]
simple_stmt [9675,9710]
===
match
---
operator: ! [16432,16433]
operator: ! [16555,16556]
===
match
---
trailer [18849,18886]
trailer [18972,19009]
===
match
---
suite [26166,26564]
suite [26289,26687]
===
match
---
name: ver [31464,31467]
name: ver [31587,31590]
===
match
---
name: Any [31915,31918]
name: Any [32038,32041]
===
match
---
raise_stmt [31573,31635]
raise_stmt [31696,31758]
===
match
---
atom_expr [18845,18886]
atom_expr [18968,19009]
===
match
---
tfpdef [12849,12862]
tfpdef [12972,12985]
===
match
---
param [3753,3757]
param [3753,3757]
===
match
---
operator: , [32393,32394]
operator: , [32516,32517]
===
match
---
atom_expr [20516,20540]
atom_expr [20639,20663]
===
match
---
name: attrname [21046,21054]
name: attrname [21169,21177]
===
match
---
testlist_comp [3302,3334]
testlist_comp [3302,3334]
===
match
---
trailer [21163,21176]
trailer [21286,21299]
===
match
---
name: task_id [32401,32408]
name: task_id [32524,32531]
===
match
---
operator: , [31731,31732]
operator: , [31854,31855]
===
match
---
atom_expr [11027,11040]
atom_expr [11150,11163]
===
match
---
name: var [8843,8846]
name: var [8837,8840]
===
match
---
name: cls [28497,28500]
name: cls [28620,28623]
===
match
---
simple_stmt [19697,19758]
simple_stmt [19820,19881]
===
match
---
string: "ui_fgcolor" [32300,32312]
string: "ui_fgcolor" [32423,32435]
===
match
---
atom_expr [8327,8338]
atom_expr [8327,8338]
===
match
---
except_clause [27605,27630]
except_clause [27728,27753]
===
match
---
trailer [29462,29468]
trailer [29585,29591]
===
match
---
name: task_group [32083,32093]
name: task_group [32206,32216]
===
match
---
atom_expr [33145,33164]
atom_expr [33268,33287]
===
match
---
name: dag [27913,27916]
name: dag [28036,28039]
===
match
---
operator: , [24096,24097]
operator: , [24219,24220]
===
match
---
name: DAG [26768,26771]
name: DAG [26891,26894]
===
match
---
name: serialize_op [17070,17082]
name: serialize_op [17193,17205]
===
match
---
name: _deserialize_timedelta [28592,28614]
name: _deserialize_timedelta [28715,28737]
===
match
---
operator: ! [31630,31631]
operator: ! [31753,31754]
===
match
---
name: var [5737,5740]
name: var [5737,5740]
===
match
---
suite [15894,16640]
suite [16017,16763]
===
match
---
name: operators [18073,18082]
name: operators [18196,18205]
===
match
---
name: dag [29213,29216]
name: dag [29336,29339]
===
match
---
name: data [23565,23569]
name: data [23688,23692]
===
match
---
tfpdef [21777,21799]
tfpdef [21900,21922]
===
match
---
operator: , [977,978]
operator: , [977,978]
===
match
---
name: staticmethod [5522,5534]
name: staticmethod [5522,5534]
===
match
---
name: ImportError [1100,1111]
name: ImportError [1100,1111]
===
match
---
comparison [30428,30464]
comparison [30551,30587]
===
match
---
trailer [8645,8655]
trailer [8639,8649]
===
match
---
suite [28049,28077]
suite [28172,28200]
===
match
---
trailer [13751,13771]
trailer [13874,13894]
===
match
---
operator: = [27449,27450]
operator: = [27572,27573]
===
match
---
atom_expr [9555,9574]
atom_expr [9549,9568]
===
match
---
name: isinstance [8137,8147]
name: isinstance [8137,8147]
===
match
---
name: key [7041,7044]
name: key [7041,7044]
===
match
---
operator: , [14380,14381]
operator: , [14503,14504]
===
match
---
name: cls [4652,4655]
name: cls [4652,4655]
===
match
---
name: encoded_op [18909,18919]
name: encoded_op [19032,19042]
===
match
---
name: v [26546,26547]
name: v [26669,26670]
===
match
---
operator: { [26191,26192]
operator: { [26314,26315]
===
match
---
simple_stmt [20625,20692]
simple_stmt [20748,20815]
===
match
---
return_stmt [11654,11664]
return_stmt [11777,11787]
===
match
---
string: 'weekday' [11956,11965]
string: 'weekday' [12079,12088]
===
match
---
name: encoded [9238,9245]
name: encoded [9232,9239]
===
match
---
parameters [21771,21800]
parameters [21894,21923]
===
match
---
simple_stmt [11996,12038]
simple_stmt [12119,12161]
===
match
---
name: serialized_obj [31332,31346]
name: serialized_obj [31455,31469]
===
match
---
trailer [6065,6085]
trailer [6065,6085]
===
match
---
name: V1Pod [8503,8508]
name: V1Pod [8497,8502]
===
match
---
dictorsetmaker [32070,32978]
dictorsetmaker [32193,33101]
===
match
---
trailer [9662,9667]
trailer [9656,9661]
===
match
---
atom [13804,13812]
atom [13927,13935]
===
match
---
name: classmethod [4947,4958]
name: classmethod [4947,4958]
===
match
---
name: operator_extra_links [18015,18035]
name: operator_extra_links [18138,18158]
===
match
---
expr_stmt [34147,34230]
expr_stmt [34270,34353]
===
match
---
name: template_fields [14789,14804]
name: template_fields [14912,14927]
===
match
---
name: op [21038,21040]
name: op [21161,21163]
===
match
---
name: _ [26988,26989]
name: _ [27111,27112]
===
match
---
name: value [7163,7168]
name: value [7163,7168]
===
match
---
simple_stmt [28943,28962]
simple_stmt [29066,29085]
===
match
---
atom_expr [33986,34039]
atom_expr [34109,34162]
===
match
---
name: Dict [15261,15265]
name: Dict [15384,15388]
===
match
---
name: deserialize_dag [11205,11220]
name: deserialize_dag [11328,11343]
===
match
---
atom_expr [9429,9447]
atom_expr [9423,9441]
===
match
---
operator: , [5587,5588]
operator: , [5587,5588]
===
match
---
trailer [21808,21831]
trailer [21931,21954]
===
match
---
sync_comp_for [10088,10100]
sync_comp_for [10211,10223]
===
match
---
name: klass [16219,16224]
name: klass [16342,16347]
===
match
---
name: encoded_group [33903,33916]
name: encoded_group [34026,34039]
===
match
---
atom_expr [9472,9485]
atom_expr [9466,9479]
===
match
---
trailer [15621,15634]
trailer [15744,15757]
===
match
---
simple_stmt [11372,11408]
simple_stmt [11495,11531]
===
match
---
name: serialize_op [15609,15621]
name: serialize_op [15732,15744]
===
match
---
simple_stmt [30551,30593]
simple_stmt [30674,30716]
===
match
---
operator: , [8736,8737]
operator: , [8730,8731]
===
match
---
name: datetime [831,839]
name: datetime [831,839]
===
match
---
simple_stmt [18990,19001]
simple_stmt [19113,19124]
===
match
---
operator: , [31862,31863]
operator: , [31985,31986]
===
match
---
string: "max_retry_delay" [19152,19169]
string: "max_retry_delay" [19275,19292]
===
match
---
simple_stmt [34049,34139]
simple_stmt [34172,34262]
===
match
---
name: v [8434,8435]
name: v [8428,8429]
===
match
---
atom_expr [29213,29226]
atom_expr [29336,29349]
===
match
---
suite [20095,20136]
suite [20218,20259]
===
match
---
expr_stmt [3644,3690]
expr_stmt [3644,3690]
===
match
---
atom_expr [26700,26717]
atom_expr [26823,26840]
===
match
---
trailer [26484,26493]
trailer [26607,26616]
===
match
---
operator: , [20490,20491]
operator: , [20613,20614]
===
match
---
simple_stmt [8405,8451]
simple_stmt [8405,8445]
===
match
---
simple_stmt [32038,32989]
simple_stmt [32161,33112]
===
match
---
name: kubernetes [2001,2011]
name: kubernetes [2001,2011]
===
match
---
tfpdef [33131,33164]
tfpdef [33254,33287]
===
match
---
string: "children" [33917,33927]
string: "children" [34040,34050]
===
match
---
param [14389,14397]
param [14512,14520]
===
match
---
simple_stmt [2252,2611]
simple_stmt [2252,2611]
===
match
---
trailer [8493,8509]
trailer [8487,8503]
===
match
---
operator: = [14219,14220]
operator: = [14342,14343]
===
match
---
trailer [31540,31559]
trailer [31663,31682]
===
match
---
trailer [7335,7340]
trailer [7335,7340]
===
match
---
operator: != [31534,31536]
operator: != [31657,31659]
===
match
---
name: child [32440,32445]
name: child [32563,32568]
===
match
---
trailer [5009,5020]
trailer [5009,5020]
===
match
---
fstring_expr [10937,10956]
fstring_expr [11060,11079]
===
match
---
operator: { [10937,10938]
operator: { [11060,11061]
===
match
---
if_stmt [10649,10821]
if_stmt [10772,10944]
===
match
---
trailer [8914,8916]
trailer [8908,8910]
===
match
---
trailer [30638,30658]
trailer [30761,30781]
===
match
---
operator: , [30020,30021]
operator: , [30143,30144]
===
match
---
trailer [18164,18178]
trailer [18287,18301]
===
match
---
simple_stmt [1186,1228]
simple_stmt [1186,1228]
===
match
---
atom_expr [33955,33979]
atom_expr [34078,34102]
===
match
---
name: var [8381,8384]
name: var [8381,8384]
===
match
---
name: args [14383,14387]
name: args [14506,14510]
===
match
---
operator: , [30248,30249]
operator: , [30371,30372]
===
match
---
atom_expr [8967,8985]
atom_expr [8961,8979]
===
match
---
atom_expr [30387,30410]
atom_expr [30510,30533]
===
match
---
simple_stmt [14199,14358]
simple_stmt [14322,14481]
===
match
---
atom [32056,32988]
atom [32179,33111]
===
match
---
atom_expr [32223,32241]
atom_expr [32346,32364]
===
match
---
trailer [23736,23763]
trailer [23859,23886]
===
match
---
operator: -> [27832,27834]
operator: -> [27955,27957]
===
match
---
simple_stmt [1368,1417]
simple_stmt [1368,1417]
===
match
---
operator: , [3328,3329]
operator: , [3328,3329]
===
match
---
if_stmt [13691,13849]
if_stmt [13814,13972]
===
match
---
name: super [21156,21161]
name: super [21279,21284]
===
match
---
comparison [11239,11254]
comparison [11362,11377]
===
match
---
name: pod [11595,11598]
name: pod [11718,11721]
===
match
---
decorated [33026,34348]
decorated [33149,34471]
===
match
---
name: dag_date [21084,21092]
name: dag_date [21207,21215]
===
match
---
operator: = [21301,21302]
operator: = [21424,21425]
===
match
---
atom [18338,18353]
atom [18461,18476]
===
match
---
simple_stmt [31382,31456]
simple_stmt [31505,31579]
===
match
---
testlist_comp [33515,33569]
testlist_comp [33638,33692]
===
match
---
atom_expr [9848,9914]
atom_expr [9863,9929]
===
match
---
argument [12031,12036]
argument [12154,12159]
===
match
---
trailer [9866,9898]
trailer [9881,9913]
===
match
---
name: _serialize [8423,8433]
name: _serialize [8417,8427]
===
match
---
name: var [9266,9269]
name: var [9260,9263]
===
match
---
if_stmt [6033,6224]
if_stmt [6033,6224]
===
match
---
simple_stmt [1004,1020]
simple_stmt [1004,1020]
===
match
---
name: _value_is_hardcoded_default [6248,6275]
name: _value_is_hardcoded_default [6248,6275]
===
match
---
atom_expr [20312,20332]
atom_expr [20435,20455]
===
match
---
name: DICT [11067,11071]
name: DICT [11190,11194]
===
match
---
operator: , [12515,12516]
operator: , [12638,12639]
===
match
---
parameters [17129,17162]
parameters [17252,17285]
===
match
---
operator: , [13807,13808]
operator: , [13930,13931]
===
match
---
name: type_ [10103,10108]
name: type_ [10226,10231]
===
match
---
string: "ui_fgcolor" [33557,33569]
string: "ui_fgcolor" [33680,33692]
===
match
---
atom_expr [13706,13729]
atom_expr [13829,13852]
===
match
---
operator: == [33755,33757]
operator: == [33878,33880]
===
match
---
trailer [6724,6746]
trailer [6724,6746]
===
match
---
simple_stmt [4558,4607]
simple_stmt [4558,4607]
===
match
---
subscriptlist [15266,15274]
subscriptlist [15389,15397]
===
match
---
simple_stmt [10696,10715]
simple_stmt [10819,10838]
===
match
---
trailer [2866,2890]
trailer [2866,2890]
===
match
---
trailer [27242,27252]
trailer [27365,27375]
===
match
---
operator: , [12656,12657]
operator: , [12779,12780]
===
match
---
operator: , [26051,26052]
operator: , [26174,26175]
===
match
---
atom_expr [15718,15755]
atom_expr [15841,15878]
===
match
---
parameters [2648,2650]
parameters [2648,2650]
===
match
---
name: task_group [32314,32324]
name: task_group [32437,32447]
===
match
---
trailer [33403,33416]
trailer [33526,33539]
===
match
---
sync_comp_for [8437,8449]
sync_comp_for [8431,8443]
===
match
---
simple_stmt [30139,30154]
simple_stmt [30262,30277]
===
match
---
trailer [7174,7185]
trailer [7174,7185]
===
match
---
atom_expr [8722,8751]
atom_expr [8716,8745]
===
match
---
trailer [10261,10313]
trailer [10384,10436]
===
match
---
string: 'weekday' [11878,11887]
string: 'weekday' [12001,12010]
===
match
---
trailer [5578,5593]
trailer [5578,5593]
===
match
---
name: HAS_KUBERNETES [8464,8478]
name: HAS_KUBERNETES [8458,8472]
===
match
---
trailer [21037,21061]
trailer [21160,21184]
===
match
---
trailer [9566,9574]
trailer [9560,9568]
===
match
---
trailer [27018,27020]
trailer [27141,27143]
===
match
---
argument [27933,27962]
argument [28056,28085]
===
match
---
simple_stmt [34147,34231]
simple_stmt [34270,34354]
===
match
---
atom_expr [10779,10798]
atom_expr [10902,10921]
===
match
---
name: BaseOperator [14872,14884]
name: BaseOperator [14995,15007]
===
match
---
operator: = [31073,31074]
operator: = [31196,31197]
===
match
---
suite [5755,5855]
suite [5755,5855]
===
match
---
name: base_ti_dep [2186,2197]
name: base_ti_dep [2186,2197]
===
match
---
operator: , [29211,29212]
operator: , [29334,29335]
===
match
---
expr_stmt [12366,12413]
expr_stmt [12489,12536]
===
match
---
name: n [9362,9363]
name: n [9356,9357]
===
match
---
name: v [14327,14328]
name: v [14450,14451]
===
match
---
name: unstructure [24987,24998]
name: unstructure [25110,25121]
===
match
---
return_stmt [6309,6434]
return_stmt [6309,6434]
===
match
---
trailer [18883,18885]
trailer [19006,19008]
===
match
---
name: _deserialize [11100,11112]
name: _deserialize [11223,11235]
===
match
---
not_test [11454,11472]
not_test [11577,11595]
===
match
---
suite [5030,5516]
suite [5030,5516]
===
match
---
name: list [8386,8390]
name: list [8386,8390]
===
match
---
simple_stmt [7016,7025]
simple_stmt [7016,7025]
===
match
---
name: _serialize_operator_extra_links [15762,15793]
name: _serialize_operator_extra_links [15885,15916]
===
match
---
name: op [20633,20635]
name: op [20756,20758]
===
match
---
operator: = [17463,17464]
operator: = [17586,17587]
===
match
---
name: encoded [9429,9436]
name: encoded [9423,9430]
===
match
---
name: str [6662,6665]
name: str [6662,6665]
===
match
---
operator: @ [33026,33027]
operator: @ [33149,33150]
===
match
---
string: """Serializes a DAG into a JSON object.""" [26790,26832]
string: """Serializes a DAG into a JSON object.""" [26913,26955]
===
match
---
name: qualname [21466,21474]
name: qualname [21589,21597]
===
match
---
name: inspect [872,879]
name: inspect [872,879]
===
match
---
atom_expr [30349,30411]
atom_expr [30472,30534]
===
match
---
name: cls [8276,8279]
name: cls [8276,8279]
===
match
---
for_stmt [27973,28962]
for_stmt [28096,29085]
===
match
---
name: VAR [5662,5665]
name: VAR [5662,5665]
===
match
---
atom_expr [25244,25284]
atom_expr [25367,25407]
===
match
---
operator: , [1704,1705]
operator: , [1704,1705]
===
match
---
name: list [10752,10756]
name: list [10875,10879]
===
match
---
arglist [21636,21685]
arglist [21759,21808]
===
match
---
atom_expr [16771,16789]
atom_expr [16894,16912]
===
match
---
name: cls [19449,19452]
name: cls [19572,19575]
===
match
---
suite [2155,2215]
suite [2155,2215]
===
match
---
name: operator_extra_link [24999,25018]
name: operator_extra_link [25122,25141]
===
match
---
name: from_timestamp [12399,12413]
name: from_timestamp [12522,12536]
===
match
---
operator: , [3756,3757]
operator: , [3756,3757]
===
match
---
funcdef [12485,12605]
funcdef [12608,12728]
===
match
---
sync_comp_for [28396,28409]
sync_comp_for [28519,28532]
===
match
---
trailer [16352,16535]
trailer [16475,16658]
===
match
---
operator: = [30198,30199]
operator: = [30321,30322]
===
match
---
name: __get_constructor_defaults [26653,26679]
name: __get_constructor_defaults [26776,26802]
===
match
---
simple_stmt [33681,33947]
simple_stmt [33804,34070]
===
match
---
operator: , [9614,9615]
operator: , [9608,9609]
===
match
---
expr_stmt [25092,25114]
expr_stmt [25215,25237]
===
match
---
name: from_json [4370,4379]
name: from_json [4370,4379]
===
match
---
trailer [3942,3979]
trailer [3942,3979]
===
match
---
name: encoded_op [18230,18240]
name: encoded_op [18353,18363]
===
match
---
suite [27499,27564]
suite [27622,27687]
===
match
---
trailer [9084,9099]
trailer [9078,9093]
===
match
---
name: key [7100,7103]
name: key [7100,7103]
===
match
---
atom_expr [3763,3811]
atom_expr [3763,3811]
===
match
---
trailer [17003,17019]
trailer [17126,17142]
===
match
---
suite [20499,20541]
suite [20622,20664]
===
match
---
parameters [14375,14398]
parameters [14498,14521]
===
match
---
return_stmt [8882,8937]
return_stmt [8876,8931]
===
match
---
comparison [19400,19428]
comparison [19523,19551]
===
match
---
if_stmt [29660,29752]
if_stmt [29783,29875]
===
match
---
operator: , [8384,8385]
operator: , [8384,8385]
===
match
---
name: SerializedBaseOperator [8772,8794]
name: SerializedBaseOperator [8766,8788]
===
match
---
decorated [10396,12361]
decorated [10519,12484]
===
match
---
arglist [6066,6084]
arglist [6066,6084]
===
match
---
trailer [3363,3374]
trailer [3363,3374]
===
match
---
name: type_ [5685,5690]
name: type_ [5685,5690]
===
match
---
name: operator_extra_links [15814,15834]
name: operator_extra_links [15937,15957]
===
match
---
name: float [3078,3083]
name: float [3078,3083]
===
match
---
name: dict [26776,26780]
name: dict [26899,26903]
===
match
---
simple_stmt [12298,12361]
simple_stmt [12421,12484]
===
match
---
name: setattr [30009,30016]
name: setattr [30132,30139]
===
match
---
name: Exception [27665,27674]
name: Exception [27788,27797]
===
match
---
operator: @ [15195,15196]
operator: @ [15318,15319]
===
match
---
name: load_dag_schema [26700,26715]
name: load_dag_schema [26823,26838]
===
match
---
operator: { [33435,33436]
operator: { [33558,33559]
===
match
---
name: _json_schema [3341,3353]
name: _json_schema [3341,3353]
===
match
---
name: BaseOperator [14807,14819]
name: BaseOperator [14930,14942]
===
match
---
raise_stmt [12298,12360]
raise_stmt [12421,12483]
===
match
---
name: v [19567,19568]
name: v [19690,19691]
===
match
---
dotted_name [2165,2197]
dotted_name [2165,2197]
===
match
---
name: var [9939,9942]
name: var [10068,10071]
===
match
---
simple_stmt [24047,24125]
simple_stmt [24170,24248]
===
match
---
simple_stmt [4316,4344]
simple_stmt [4316,4344]
===
match
---
operator: = [30586,30587]
operator: = [30709,30710]
===
match
---
operator: , [21670,21671]
operator: , [21793,21794]
===
match
---
simple_stmt [28324,28411]
simple_stmt [28447,28534]
===
match
---
for_stmt [29447,29511]
for_stmt [29570,29634]
===
match
---
name: cls [10070,10073]
name: cls [9996,9999]
===
match
---
trailer [20263,20265]
trailer [20386,20388]
===
match
---
atom_expr [11687,11700]
atom_expr [11810,11823]
===
match
---
trailer [7121,7128]
trailer [7121,7128]
===
match
---
decorator [12468,12481]
decorator [12591,12604]
===
match
---
trailer [12313,12360]
trailer [12436,12483]
===
match
---
and_test [18133,18256]
and_test [18256,18379]
===
match
---
trailer [21255,21260]
trailer [21378,21383]
===
match
---
simple_stmt [11490,11583]
simple_stmt [11613,11706]
===
match
---
name: v [28066,28067]
name: v [28189,28190]
===
match
---
arglist [8733,8750]
arglist [8727,8744]
===
match
---
name: values [30117,30123]
name: values [30240,30246]
===
match
---
name: var [10221,10224]
name: var [10344,10347]
===
match
---
param [33092,33122]
param [33215,33245]
===
match
---
name: cls [8003,8006]
name: cls [8003,8006]
===
match
---
name: serialized_obj [4385,4399]
name: serialized_obj [4385,4399]
===
match
---
name: DAG [3769,3772]
name: DAG [3769,3772]
===
match
---
not_test [33310,33327]
not_test [33433,33450]
===
match
---
string: "__version" [31076,31087]
string: "__version" [31199,31210]
===
match
---
name: subdag [30569,30575]
name: subdag [30692,30698]
===
match
---
name: _deserialize_timedelta [12489,12511]
name: _deserialize_timedelta [12612,12634]
===
match
---
operator: = [6892,6893]
operator: = [6892,6893]
===
match
---
trailer [29429,29434]
trailer [29552,29557]
===
match
---
name: cache [2614,2619]
name: cache [2614,2619]
===
match
---
atom_expr [5670,5683]
atom_expr [5670,5683]
===
match
---
comparison [18133,18178]
comparison [18256,18301]
===
match
---
import_from [1229,1296]
import_from [1229,1296]
===
match
---
trailer [8147,8163]
trailer [8147,8163]
===
match
---
simple_stmt [32017,32029]
simple_stmt [32140,32152]
===
match
---
name: date_attr [30400,30409]
name: date_attr [30523,30532]
===
match
---
operator: = [26960,26961]
operator: = [27083,27084]
===
match
---
atom_expr [8534,8565]
atom_expr [8528,8559]
===
match
---
atom_expr [17934,17974]
atom_expr [18057,18097]
===
match
---
operator: { [16497,16498]
operator: { [16620,16621]
===
match
---
operator: = [2284,2285]
operator: = [2284,2285]
===
match
---
simple_stmt [5956,5997]
simple_stmt [5956,5997]
===
match
---
name: helpers [1609,1616]
name: helpers [1609,1616]
===
match
---
tfpdef [4988,5020]
tfpdef [4988,5020]
===
match
---
operator: @ [21201,21202]
operator: @ [21324,21325]
===
match
---
return_stmt [8765,8818]
return_stmt [8759,8812]
===
match
---
operator: @ [5521,5522]
operator: @ [5521,5522]
===
match
---
name: op [18817,18819]
name: op [18940,18942]
===
match
---
trailer [16773,16789]
trailer [16896,16912]
===
match
---
trailer [18014,18035]
trailer [18137,18158]
===
match
---
name: empty [26548,26553]
name: empty [26671,26676]
===
match
---
trailer [24493,24511]
trailer [24616,24634]
===
match
---
name: type_ [12051,12056]
name: type_ [12174,12179]
===
match
---
name: serialize_dag [27210,27223]
name: serialize_dag [27333,27346]
===
match
---
atom_expr [12766,12789]
atom_expr [12889,12912]
===
match
---
name: default [26439,26446]
name: default [26562,26569]
===
match
---
name: operator_extra_links [17882,17902]
name: operator_extra_links [18005,18025]
===
match
---
name: _deserialize [28880,28892]
name: _deserialize [29003,29015]
===
match
---
name: NotImplementedError [4322,4341]
name: NotImplementedError [4322,4341]
===
match
---
operator: == [12057,12059]
operator: == [12180,12182]
===
match
---
name: DAT [1568,1571]
name: DAT [1568,1571]
===
match
---
trailer [25273,25284]
trailer [25396,25407]
===
match
---
name: weekday [9559,9566]
name: weekday [9553,9560]
===
match
---
atom_expr [17866,17902]
atom_expr [17989,18025]
===
match
---
suite [21408,21501]
suite [21531,21624]
===
match
---
suite [10239,10342]
suite [10362,10465]
===
match
---
atom_expr [32314,32335]
atom_expr [32437,32458]
===
match
---
atom_expr [5396,5422]
atom_expr [5396,5422]
===
match
---
parameters [31858,31886]
parameters [31981,32009]
===
match
---
name: dep [16184,16187]
name: dep [16307,16310]
===
match
---
operator: = [27917,27918]
operator: = [28040,28041]
===
match
---
trailer [9454,9462]
trailer [9448,9456]
===
match
---
name: key [7336,7339]
name: key [7336,7339]
===
match
---
operator: } [31632,31633]
operator: } [31755,31756]
===
match
---
name: group [34239,34244]
name: group [34362,34367]
===
match
---
name: ope [18069,18072]
name: ope [18192,18195]
===
match
---
name: structure [24215,24224]
name: structure [24338,24347]
===
match
---
expr_stmt [16205,16235]
expr_stmt [16328,16358]
===
match
---
expr_stmt [17443,17486]
expr_stmt [17566,17609]
===
match
---
operator: } [16596,16597]
operator: } [16719,16720]
===
match
---
trailer [18919,18925]
trailer [19042,19048]
===
match
---
trailer [10782,10795]
trailer [10905,10918]
===
match
---
simple_stmt [31573,31636]
simple_stmt [31696,31759]
===
match
---
trailer [27109,27120]
trailer [27232,27243]
===
match
---
operator: , [30945,30946]
operator: , [31068,31069]
===
match
---
name: k [29974,29975]
name: k [30097,30098]
===
match
---
operator: } [17576,17577]
operator: } [17699,17700]
===
match
---
name: v [19083,19084]
name: v [19206,19207]
===
match
---
operator: , [9898,9899]
operator: , [9913,9914]
===
match
---
funcdef [3741,3980]
funcdef [3741,3980]
===
match
---
parameters [24457,24512]
parameters [24580,24635]
===
match
---
return_stmt [17063,17082]
return_stmt [17186,17205]
===
match
---
simple_stmt [30040,30083]
simple_stmt [30163,30206]
===
match
---
expr_stmt [3177,3215]
expr_stmt [3177,3215]
===
match
---
name: var [9472,9475]
name: var [9466,9469]
===
match
---
atom_expr [30040,30082]
atom_expr [30163,30205]
===
match
---
trailer [33470,33490]
trailer [33593,33613]
===
match
---
parameters [14938,14944]
parameters [15061,15067]
===
match
---
operator: , [30374,30375]
operator: , [30497,30498]
===
match
---
arglist [8148,8162]
arglist [8148,8162]
===
match
---
trailer [32594,32603]
trailer [32717,32726]
===
match
---
suite [30465,30593]
suite [30588,30716]
===
match
---
suite [6586,7382]
suite [6586,7382]
===
match
---
name: value [7287,7292]
name: value [7287,7292]
===
match
---
name: plugins_manager [22173,22188]
name: plugins_manager [22296,22311]
===
match
---
trailer [10942,10955]
trailer [11065,11078]
===
match
---
import_name [852,866]
import_name [852,866]
===
match
---
atom_expr [10109,10118]
atom_expr [10232,10241]
===
match
---
name: _is_excluded [20737,20749]
name: _is_excluded [20860,20872]
===
match
---
name: SET [9910,9913]
name: SET [9925,9928]
===
match
---
name: TaskGroup [31722,31731]
name: TaskGroup [31845,31854]
===
match
---
name: SerializedTaskGroup [32499,32518]
name: SerializedTaskGroup [32622,32641]
===
match
---
name: DAG [6534,6537]
name: DAG [6534,6537]
===
match
---
if_stmt [18716,18888]
if_stmt [18839,19011]
===
match
---
trailer [32955,32975]
trailer [33078,33098]
===
match
---
trailer [9709,9714]
trailer [9703,9708]
===
match
---
expr_stmt [14591,14623]
expr_stmt [14714,14746]
===
match
---
funcdef [14925,15090]
funcdef [15048,15213]
===
match
---
suite [21112,21141]
suite [21235,21264]
===
match
---
string: "upstream_group_ids" [34017,34037]
string: "upstream_group_ids" [34140,34160]
===
match
---
string: "deps" [19959,19965]
string: "deps" [20082,20088]
===
match
---
name: isinstance [8832,8842]
name: isinstance [8826,8836]
===
match
---
trailer [21306,21308]
trailer [21429,21431]
===
match
---
operator: @ [24405,24406]
operator: @ [24528,24529]
===
match
---
name: serializable_task [30621,30638]
name: serializable_task [30744,30761]
===
match
---
name: classmethod [31297,31308]
name: classmethod [31420,31431]
===
match
---
operator: = [19051,19052]
operator: = [19174,19175]
===
match
---
simple_stmt [33955,34041]
simple_stmt [34078,34164]
===
match
---
suite [9100,9167]
suite [9094,9161]
===
match
---
expr_stmt [29817,29851]
expr_stmt [29940,29974]
===
match
---
operator: , [8846,8847]
operator: , [8840,8841]
===
match
---
fstring_start: f' [27713,27715]
fstring_start: f' [27836,27838]
===
match
---
suite [9364,9487]
suite [9358,9481]
===
match
---
simple_stmt [6638,6677]
simple_stmt [6638,6677]
===
match
---
expr_stmt [29085,29240]
expr_stmt [29208,29363]
===
match
---
name: kubernetes [1945,1955]
name: kubernetes [1945,1955]
===
match
---
name: classmethod [30914,30925]
name: classmethod [31037,31048]
===
match
---
trailer [9691,9715]
trailer [9685,9709]
===
match
---
suite [11473,11583]
suite [11596,11706]
===
match
---
param [5899,5908]
param [5899,5908]
===
match
---
trailer [9606,9640]
trailer [9600,9634]
===
match
---
atom_expr [16179,16188]
atom_expr [16302,16311]
===
match
---
simple_stmt [1117,1149]
simple_stmt [1117,1149]
===
match
---
name: cattr [24209,24214]
name: cattr [24332,24337]
===
match
---
operator: { [32361,32362]
operator: { [32484,32485]
===
match
---
name: var [9740,9743]
name: var [9734,9737]
===
match
---
name: serialize_dag [26858,26871]
name: serialize_dag [26981,26994]
===
match
---
string: """Validate serialized_obj satisfies JSON schema.""" [5039,5091]
string: """Validate serialized_obj satisfies JSON schema.""" [5039,5091]
===
match
---
atom_expr [16869,16902]
atom_expr [16992,17025]
===
match
---
import_from [1507,1581]
import_from [1507,1581]
===
match
---
operator: { [27739,27740]
operator: { [27862,27863]
===
match
---
simple_stmt [3341,3382]
simple_stmt [3341,3382]
===
match
---
atom_expr [18994,19000]
atom_expr [19117,19123]
===
match
---
name: sorted [9860,9866]
name: sorted [9875,9881]
===
match
---
operator: { [19828,19829]
operator: { [19951,19952]
===
match
---
name: task_id [30610,30617]
name: task_id [30733,30740]
===
match
---
name: val [33895,33898]
name: val [34018,34021]
===
match
---
operator: = [27063,27064]
operator: = [27186,27187]
===
match
---
name: v [14259,14260]
name: v [14382,14383]
===
match
---
operator: , [15269,15270]
operator: , [15392,15393]
===
match
---
comparison [18207,18256]
comparison [18330,18379]
===
match
---
name: set [21303,21306]
name: set [21426,21429]
===
match
---
name: error [24051,24056]
name: error [24174,24179]
===
match
---
name: DAG [11167,11170]
name: DAG [11290,11293]
===
match
---
operator: -> [12531,12533]
operator: -> [12654,12656]
===
match
---
trailer [17151,17161]
trailer [17274,17284]
===
match
---
trailer [9462,9470]
trailer [9456,9464]
===
match
---
trailer [32769,32802]
trailer [32892,32925]
===
match
---
atom_expr [10652,10682]
atom_expr [10775,10805]
===
match
---
atom_expr [5833,5853]
atom_expr [5833,5853]
===
match
---
name: k [20214,20215]
name: k [20337,20338]
===
match
---
name: DAT [11775,11778]
name: DAT [11898,11901]
===
match
---
atom_expr [9350,9363]
atom_expr [9344,9357]
===
match
---
name: Union [984,989]
name: Union [984,989]
===
match
---
simple_stmt [33248,33299]
simple_stmt [33371,33422]
===
match
---
operator: = [14702,14703]
operator: = [14825,14826]
===
match
---
suite [8510,8622]
suite [8504,8616]
===
match
---
name: x [5551,5552]
name: x [5551,5552]
===
match
---
fstring_conversion [27750,27752]
fstring_conversion [27873,27875]
===
match
---
tfpdef [20780,20796]
tfpdef [20903,20919]
===
match
---
comp_if [26526,26553]
comp_if [26649,26676]
===
match
---
expr_stmt [29717,29751]
expr_stmt [29840,29874]
===
match
---
name: validate [5387,5395]
name: validate [5387,5395]
===
match
---
param [12864,12875]
param [12987,12998]
===
match
---
name: DAT [11346,11349]
name: DAT [11469,11472]
===
match
---
fstring_string: . [16580,16581]
fstring_string: . [16703,16704]
===
match
---
trailer [11613,11636]
trailer [11736,11759]
===
match
---
operator: = [28495,28496]
operator: = [28618,28619]
===
match
---
name: create_root [29418,29429]
name: create_root [29541,29552]
===
match
---
name: serializable_task [30551,30568]
name: serializable_task [30674,30691]
===
match
---
arglist [13901,13932]
arglist [14024,14055]
===
match
---
name: v [20112,20113]
name: v [20235,20236]
===
match
---
name: airflow [2165,2172]
name: airflow [2165,2172]
===
match
---
suite [20874,21141]
suite [20997,21264]
===
match
---
name: registered_operator_link_classes [23915,23947]
name: registered_operator_link_classes [24038,24070]
===
match
---
atom_expr [5456,5515]
atom_expr [5456,5515]
===
match
---
arglist [10144,10158]
arglist [10267,10281]
===
match
---
operator: } [19169,19170]
operator: } [19292,19293]
===
match
---
name: relativedelta [9196,9209]
name: relativedelta [9190,9203]
===
match
---
simple_stmt [1940,1984]
simple_stmt [1940,1984]
===
match
---
trailer [33985,34040]
trailer [34108,34163]
===
match
---
operator: @ [4946,4947]
operator: @ [4946,4947]
===
match
---
dictorsetmaker [18339,18352]
dictorsetmaker [18462,18475]
===
match
---
expr_stmt [26685,26717]
expr_stmt [26808,26840]
===
match
---
name: _operator_link_class_path [23737,23762]
name: _operator_link_class_path [23860,23885]
===
match
---
simple_stmt [991,1004]
simple_stmt [991,1004]
===
match
---
atom [12088,12122]
atom [12211,12245]
===
match
---
decorated [5521,5692]
decorated [5521,5692]
===
match
---
trailer [32609,32611]
trailer [32732,32734]
===
match
---
name: dag_id [27744,27750]
name: dag_id [27867,27873]
===
match
---
name: classmethod [4613,4624]
name: classmethod [4613,4624]
===
match
---
name: cls [34271,34274]
name: cls [34394,34397]
===
match
---
param [12876,12889]
param [12999,13012]
===
match
---
name: Parameter [887,896]
name: Parameter [887,896]
===
match
---
simple_stmt [27688,27756]
simple_stmt [27811,27879]
===
match
---
simple_stmt [18809,18888]
simple_stmt [18932,19011]
===
match
---
string: "BaseTIDep" [21269,21280]
string: "BaseTIDep" [21392,21403]
===
match
---
string: "task_id" [17476,17485]
string: "task_id" [17599,17608]
===
match
---
operator: , [3316,3317]
operator: , [3316,3317]
===
match
---
name: SERIALIZER_VERSION [31093,31111]
name: SERIALIZER_VERSION [31216,31234]
===
match
---
if_stmt [15678,15849]
if_stmt [15801,15972]
===
match
---
name: decorated_fields [7048,7064]
name: decorated_fields [7048,7064]
===
match
---
atom_expr [33454,33490]
atom_expr [33577,33613]
===
match
---
atom_expr [29486,29510]
atom_expr [29609,29633]
===
match
---
name: _deserialize [34275,34287]
name: _deserialize [34398,34410]
===
match
---
expr_stmt [17546,17577]
expr_stmt [17669,17700]
===
match
---
operator: @ [5860,5861]
operator: @ [5860,5861]
===
match
---
string: 'default_view' [26291,26305]
string: 'default_view' [26414,26428]
===
match
---
operator: , [6289,6290]
operator: , [6289,6290]
===
match
---
operator: , [3213,3214]
operator: , [3213,3214]
===
match
---
atom_expr [32925,32977]
atom_expr [33048,33100]
===
match
---
expr_stmt [15411,15461]
expr_stmt [15534,15584]
===
match
---
trailer [32439,32460]
trailer [32562,32583]
===
match
---
operator: , [8965,8966]
operator: , [8959,8960]
===
match
---
simple_stmt [11714,11753]
simple_stmt [11837,11876]
===
match
---
parameters [6478,6567]
parameters [6478,6567]
===
match
---
decorated [12610,12790]
decorated [12733,12913]
===
match
---
for_stmt [30218,30412]
for_stmt [30341,30535]
===
match
---
suite [5594,5692]
suite [5594,5692]
===
match
---
comp_if [14324,14351]
comp_if [14447,14474]
===
match
---
operator: = [11747,11748]
operator: = [11870,11871]
===
match
---
name: tz [1200,1202]
name: tz [1200,1202]
===
match
---
operator: == [28724,28726]
operator: == [28847,28849]
===
match
---
simple_stmt [11912,11984]
simple_stmt [12035,12107]
===
match
---
operator: == [11684,11686]
operator: == [11807,11809]
===
match
---
test [33719,33863]
test [33842,33986]
===
match
---
name: __init__ [14287,14295]
name: __init__ [14410,14418]
===
match
---
operator: , [7228,7229]
operator: , [7228,7229]
===
match
---
tfpdef [31864,31885]
tfpdef [31987,32008]
===
match
---
operator: = [33625,33626]
operator: = [33748,33749]
===
match
---
operator: , [18819,18820]
operator: , [18942,18943]
===
match
---
name: logging [859,866]
name: logging [859,866]
===
match
---
name: dag_date [21019,21027]
name: dag_date [21142,21150]
===
match
---
atom [32482,32547]
atom [32605,32670]
===
match
---
atom_expr [15470,15498]
atom_expr [15593,15621]
===
match
---
decorated [31296,31694]
decorated [31419,31817]
===
match
---
name: encoded_group [34099,34112]
name: encoded_group [34222,34235]
===
match
---
simple_stmt [33341,33353]
simple_stmt [33464,33476]
===
match
---
operator: = [28586,28587]
operator: = [28709,28710]
===
match
---
trailer [10896,10958]
trailer [11019,11081]
===
match
---
dictorsetmaker [5653,5690]
dictorsetmaker [5653,5690]
===
match
---
name: group [34147,34152]
name: group [34270,34275]
===
match
---
decorator [10396,10409]
decorator [10519,10532]
===
match
---
simple_stmt [21695,21712]
simple_stmt [21818,21835]
===
match
---
atom [26015,26071]
atom [26138,26194]
===
match
---
import_from [1866,1912]
import_from [1866,1912]
===
match
---
simple_stmt [16553,16600]
simple_stmt [16676,16723]
===
match
---
name: cls [5833,5836]
name: cls [5833,5836]
===
match
---
trailer [17806,17847]
trailer [17929,17970]
===
match
---
name: TaskGroup [31876,31885]
name: TaskGroup [31999,32008]
===
match
---
name: encoded_op [17465,17475]
name: encoded_op [17588,17598]
===
match
---
name: op_predefined_extra_links [24374,24399]
name: op_predefined_extra_links [24497,24522]
===
match
---
atom_expr [8297,8314]
atom_expr [8297,8314]
===
match
---
name: group [34049,34054]
name: group [34172,34177]
===
match
---
fstring [5164,5210]
fstring [5164,5210]
===
match
---
name: task [28400,28404]
name: task [28523,28527]
===
match
---
suite [19429,19936]
suite [19552,20059]
===
match
---
testlist_star_expr [23538,23569]
testlist_star_expr [23661,23692]
===
match
---
suite [29254,29511]
suite [29377,29634]
===
match
---
dictorsetmaker [31076,31142]
dictorsetmaker [31199,31265]
===
match
---
trailer [9135,9145]
trailer [9129,9139]
===
match
---
name: _CONSTRUCTOR_PARAMS [3644,3663]
name: _CONSTRUCTOR_PARAMS [3644,3663]
===
match
---
name: encoded_group [33092,33105]
name: encoded_group [33215,33228]
===
match
---
trailer [14296,14307]
trailer [14419,14430]
===
match
---
expr_stmt [15609,15668]
expr_stmt [15732,15791]
===
match
---
simple_stmt [1582,1649]
simple_stmt [1582,1649]
===
match
---
operator: = [19985,19986]
operator: = [20108,20109]
===
match
---
funcdef [4629,4941]
funcdef [4629,4941]
===
match
---
name: str [12859,12862]
name: str [12982,12985]
===
match
---
trailer [9139,9144]
trailer [9133,9138]
===
match
---
name: append [16558,16564]
name: append [16681,16687]
===
match
---
name: task_group [29490,29500]
name: task_group [29613,29623]
===
match
---
argument [12588,12603]
argument [12711,12726]
===
match
---
trailer [29926,29928]
trailer [30049,30051]
===
match
---
name: DAT [11063,11066]
name: DAT [11186,11189]
===
match
---
name: TypeError [12304,12313]
name: TypeError [12427,12436]
===
match
---
dictorsetmaker [25204,25365]
dictorsetmaker [25327,25488]
===
match
---
name: ensure_ascii [3961,3973]
name: ensure_ascii [3961,3973]
===
match
---
atom_expr [34049,34075]
atom_expr [34172,34198]
===
match
---
sync_comp_for [26984,27020]
sync_comp_for [27107,27143]
===
match
---
return_stmt [12081,12122]
return_stmt [12204,12245]
===
match
---
comp_op [18774,18780]
comp_op [18897,18903]
===
match
---
trailer [21572,21574]
trailer [21695,21697]
===
match
---
trailer [21627,21635]
trailer [21750,21758]
===
match
---
trailer [5406,5422]
trailer [5406,5422]
===
match
---
operator: , [20196,20197]
operator: , [20319,20320]
===
match
---
name: functools [1070,1079]
name: functools [1070,1079]
===
match
---
trailer [8588,8596]
trailer [8582,8590]
===
match
---
trailer [29145,29240]
trailer [29268,29363]
===
match
---
operator: , [14387,14388]
operator: , [14510,14511]
===
match
---
fstring_start: f' [16565,16567]
fstring_start: f' [16688,16690]
===
match
---
operator: , [3673,3674]
operator: , [3673,3674]
===
match
---
operator: , [940,941]
operator: , [940,941]
===
match
---
operator: , [1276,1277]
operator: , [1276,1277]
===
match
---
string: "_date" [20865,20872]
string: "_date" [20988,20995]
===
match
---
operator: , [4059,4060]
operator: , [4059,4060]
===
match
---
name: Any [942,945]
name: Any [942,945]
===
match
---
name: log [21624,21627]
name: log [21747,21750]
===
match
---
name: items [26506,26511]
name: items [26629,26634]
===
match
---
trailer [28333,28344]
trailer [28456,28467]
===
match
---
name: v [10803,10804]
name: v [10926,10927]
===
match
---
atom_expr [25039,25074]
atom_expr [25162,25197]
===
match
---
atom_expr [6244,6300]
atom_expr [6244,6300]
===
match
---
atom_expr [7287,7301]
atom_expr [7287,7301]
===
match
---
trailer [17475,17486]
trailer [17598,17609]
===
match
---
operator: = [28326,28327]
operator: = [28449,28450]
===
match
---
trailer [11099,11112]
trailer [11222,11235]
===
match
---
atom [9554,9575]
atom [9548,9569]
===
match
---
name: _deserialize_operator_extra_links [21738,21771]
name: _deserialize_operator_extra_links [21861,21894]
===
match
---
name: __init__ [14367,14375]
name: __init__ [14490,14498]
===
match
---
atom [17575,17577]
atom [17698,17700]
===
match
---
trailer [28892,28895]
trailer [29015,29018]
===
match
---
param [21240,21244]
param [21363,21367]
===
match
---
name: __name__ [18142,18150]
name: __name__ [18265,18273]
===
match
---
name: OP [32391,32393]
name: OP [32514,32516]
===
insert-tree
---
simple_stmt [786,824]
    string: """Serialized DAG and BaseOperator""" [786,823]
to
file_input [786,34348]
at 0
===
insert-node
---
name: BaseSerialization [2933,2950]
to
classdef [2927,13870]
at 0
===
insert-tree
---
simple_stmt [2956,3014]
    string: """BaseSerialization provides utils for serialization.""" [2956,3013]
to
suite [2951,13870]
at 0
===
insert-node
---
suite [9744,10044]
to
if_stmt [8000,10342]
at 23
===
insert-node
---
try_stmt [9835,10044]
to
suite [9744,10044]
at 0
===
move-tree
---
suite [9750,9915]
    simple_stmt [9841,9915]
        return_stmt [9841,9914]
            atom_expr [9848,9914]
                name: cls [9848,9851]
                trailer [9851,9859]
                    name: _encode [9852,9859]
                trailer [9859,9914]
                    arglist [9860,9913]
                        atom_expr [9860,9898]
                            name: sorted [9860,9866]
                            trailer [9866,9898]
                                argument [9867,9897]
                                    atom_expr [9867,9884]
                                        name: cls [9867,9870]
                                        trailer [9870,9881]
                                            name: _serialize [9871,9881]
                                        trailer [9881,9884]
                                            name: v [9882,9883]
                                    sync_comp_for [9885,9897]
                                        name: v [9889,9890]
                                        name: var [9894,9897]
                        operator: , [9898,9899]
                        argument [9900,9913]
                            name: type_ [9900,9905]
                            operator: = [9905,9906]
                            atom_expr [9906,9913]
                                name: DAT [9906,9909]
                                trailer [9909,9913]
                                    name: SET [9910,9913]
to
try_stmt [9835,10044]
at 0
===
insert-node
---
suite [9959,10044]
to
try_stmt [9835,10044]
at 2
===
insert-node
---
atom [8412,8444]
to
return_stmt [8405,8450]
at 0
===
insert-node
---
simple_stmt [9976,10044]
to
suite [9959,10044]
at 0
===
insert-node
---
testlist_comp [8413,8443]
to
atom [8412,8444]
at 0
===
insert-node
---
return_stmt [9976,10043]
to
simple_stmt [9976,10044]
at 0
===
move-tree
---
atom_expr [8419,8436]
    name: cls [8419,8422]
    trailer [8422,8433]
        name: _serialize [8423,8433]
    trailer [8433,8436]
        name: v [8434,8435]
to
testlist_comp [8413,8443]
at 0
===
move-tree
---
sync_comp_for [8437,8449]
    name: v [8441,8442]
    name: var [8446,8449]
to
testlist_comp [8413,8443]
at 1
===
insert-node
---
atom_expr [9983,10043]
to
return_stmt [9976,10043]
at 0
===
insert-node
---
trailer [9994,10043]
to
atom_expr [9983,10043]
at 2
===
insert-node
---
atom [10192,10224]
to
arglist [10063,10118]
at 0
===
insert-node
---
arglist [9995,10042]
to
trailer [9994,10043]
at 0
===
insert-node
---
testlist_comp [10193,10223]
to
atom [10192,10224]
at 0
===
insert-node
---
atom [9995,10027]
to
arglist [9995,10042]
at 0
===
move-tree
---
sync_comp_for [10088,10100]
    name: v [10092,10093]
    name: var [10097,10100]
to
testlist_comp [10193,10223]
at 1
===
insert-node
---
testlist_comp [9996,10026]
to
atom [9995,10027]
at 0
===
move-tree
---
atom_expr [10070,10087]
    name: cls [10070,10073]
    trailer [10073,10084]
        name: _serialize [10074,10084]
    trailer [10084,10087]
        name: v [10085,10086]
to
testlist_comp [9996,10026]
at 0
===
delete-tree
---
simple_stmt [786,824]
    string: """Serialized DAG and BaseOperator""" [786,823]
===
delete-node
---
name: BaseSerialization [2933,2950]
===
===
delete-tree
---
simple_stmt [2956,3014]
    string: """BaseSerialization provides utils for serialization.""" [2956,3013]
===
delete-node
---
argument [8419,8449]
===
===
delete-node
---
trailer [8418,8450]
===
===
delete-node
---
atom_expr [8412,8450]
===
===
delete-node
---
argument [10070,10100]
===
===
delete-node
---
trailer [10069,10101]
===
===
delete-node
---
atom_expr [10063,10101]
===
