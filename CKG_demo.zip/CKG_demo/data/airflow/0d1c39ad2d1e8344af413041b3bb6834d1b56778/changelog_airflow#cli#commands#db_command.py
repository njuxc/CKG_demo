===
match
---
name: get_backend_name [2600,2616]
name: get_backend_name [2600,2616]
===
match
---
atom [2660,2685]
atom [2660,2685]
===
match
---
atom_expr [1956,1975]
atom_expr [1956,1975]
===
match
---
string: "my.cnf" [2088,2096]
string: "my.cnf" [2088,2096]
===
match
---
name: username [2259,2267]
name: username [2259,2267]
===
match
---
name: initdb [1181,1187]
name: initdb [1181,1187]
===
match
---
atom_expr [2799,2807]
atom_expr [2792,2800]
===
match
---
trailer [1614,1621]
trailer [1614,1621]
===
match
---
suite [1883,3205]
suite [1883,3198]
===
match
---
name: content [2116,2123]
name: content [2116,2123]
===
match
---
string: 'mysql' [2040,2047]
string: 'mysql' [2040,2047]
===
match
---
trailer [1417,1423]
trailer [1417,1423]
===
match
---
string: "sqlite3" [2661,2670]
string: "sqlite3" [2661,2670]
===
match
---
atom_expr [2576,2582]
atom_expr [2576,2582]
===
match
---
trailer [2034,2036]
trailer [2034,2036]
===
match
---
import_from [1004,1063]
import_from [1004,1063]
===
match
---
name: port [2349,2353]
name: port [2349,2353]
===
match
---
parameters [1669,1675]
parameters [1669,1675]
===
match
---
trailer [1634,1644]
trailer [1634,1644]
===
match
---
name: args [1077,1081]
name: args [1077,1081]
===
match
---
fstring_expr [2254,2268]
fstring_expr [2254,2268]
===
match
---
or_test [1336,1432]
or_test [1336,1432]
===
match
---
expr_stmt [2783,2813]
expr_stmt [2776,2806]
===
match
---
name: database [3071,3079]
name: database [3064,3072]
===
match
---
trailer [2599,2616]
trailer [2599,2616]
===
match
---
name: args [1237,1241]
name: args [1237,1241]
===
match
---
trailer [1187,1189]
trailer [1187,1189]
===
match
---
string: 'postgresql' [2729,2741]
string: 'postgresql' [2722,2734]
===
match
---
or_test [2842,2860]
or_test [2835,2853]
===
match
---
name: NamedTemporaryFile [2062,2080]
name: NamedTemporaryFile [2062,2080]
===
match
---
trailer [2577,2582]
trailer [2577,2582]
===
match
---
name: airflow [885,892]
name: airflow [885,892]
===
match
---
name: airflow [1009,1016]
name: airflow [1009,1016]
===
match
---
trailer [2348,2353]
trailer [2348,2353]
===
match
---
operator: { [2392,2393]
operator: { [2392,2393]
===
match
---
string: 'PGPORT' [2826,2834]
string: 'PGPORT' [2819,2827]
===
match
---
dotted_name [3208,3232]
dotted_name [3201,3225]
===
match
---
suite [1676,1839]
suite [1676,1839]
===
match
---
argument [3118,3125]
argument [3111,3118]
===
match
---
fstring_expr [2575,2583]
fstring_expr [2575,2583]
===
match
---
name: cli [983,986]
name: cli [983,986]
===
match
---
simple_stmt [1004,1064]
simple_stmt [1004,1064]
===
match
---
atom_expr [1178,1189]
atom_expr [1178,1189]
===
match
---
simple_stmt [3251,3310]
simple_stmt [3244,3303]
===
match
---
string: "psql" [3109,3115]
string: "psql" [3102,3108]
===
match
---
parameters [1876,1882]
parameters [1876,1882]
===
match
---
name: textwrap [2126,2134]
name: textwrap [2126,2134]
===
match
---
name: username [2890,2898]
name: username [2883,2891]
===
match
---
name: db [1782,1784]
name: db [1782,1784]
===
match
---
atom_expr [2886,2898]
atom_expr [2879,2891]
===
match
---
name: url [2297,2300]
name: url [2297,2300]
===
match
---
decorator [1841,1867]
decorator [1841,1867]
===
match
---
atom_expr [2499,2508]
atom_expr [2499,2508]
===
match
---
name: resetdb [1229,1236]
name: resetdb [1229,1236]
===
match
---
decorator [3207,3233]
decorator [3200,3226]
===
match
---
name: get_backend_name [2707,2723]
name: get_backend_name [2700,2716]
===
match
---
simple_stmt [3314,3325]
simple_stmt [3307,3318]
===
match
---
name: NamedTemporaryFile [860,878]
name: NamedTemporaryFile [860,878]
===
match
---
fstring_expr [2216,2226]
fstring_expr [2216,2226]
===
match
---
atom_expr [3067,3079]
atom_expr [3060,3072]
===
match
---
name: utils [1017,1022]
name: utils [1017,1022]
===
match
---
funcdef [1520,1647]
funcdef [1520,1647]
===
match
---
name: check_migrations [1653,1669]
name: check_migrations [1653,1669]
===
match
---
name: env [2822,2825]
name: env [2815,2818]
===
match
---
string: """Upgrades the metadata database""" [1545,1581]
string: """Upgrades the metadata database""" [1545,1581]
===
match
---
name: action_logging [1852,1866]
name: action_logging [1852,1866]
===
match
---
string: 'sqlite' [2622,2630]
string: 'sqlite' [2622,2630]
===
match
---
string: """Run a shell that allows to access metadata database""" [1888,1945]
string: """Run a shell that allows to access metadata database""" [1888,1945]
===
match
---
simple_stmt [3088,3127]
simple_stmt [3081,3120]
===
match
---
operator: , [2549,2550]
operator: , [2549,2550]
===
match
---
name: url [2799,2802]
name: url [2792,2795]
===
match
---
atom_expr [1586,1627]
atom_expr [1586,1627]
===
match
---
trailer [1160,1167]
trailer [1160,1167]
===
match
---
suite [2742,3127]
suite [2735,3120]
===
match
---
atom_expr [3000,3017]
atom_expr [2993,3010]
===
match
---
name: check [3237,3242]
name: check [3230,3235]
===
match
---
name: args [1877,1881]
name: args [1877,1881]
===
match
---
name: os [820,822]
name: os [820,822]
===
match
---
atom_expr [1336,1344]
atom_expr [1336,1344]
===
match
---
name: url [2000,2003]
name: url [2000,2003]
===
match
---
simple_stmt [2461,2487]
simple_stmt [2461,2487]
===
match
---
param [1077,1081]
param [1077,1081]
===
match
---
suite [1083,1223]
suite [1083,1223]
===
match
---
comparison [2014,2047]
comparison [2014,2047]
===
match
---
atom_expr [2255,2267]
atom_expr [2255,2267]
===
match
---
name: print [1194,1199]
name: print [1194,1199]
===
match
---
name: args [1810,1814]
name: args [1810,1814]
===
match
---
string: """Database sub-commands""" [785,812]
string: """Database sub-commands""" [785,812]
===
match
---
simple_stmt [1132,1174]
simple_stmt [1132,1174]
===
match
---
trailer [1151,1172]
trailer [1151,1172]
===
match
---
name: env [2870,2873]
name: env [2863,2866]
===
match
---
operator: == [2619,2621]
operator: == [2619,2621]
===
match
---
fstring_string: Unknown driver:  [3170,3186]
fstring_string: Unknown driver:  [3163,3179]
===
match
---
simple_stmt [1632,1647]
simple_stmt [1632,1647]
===
match
---
arglist [3108,3125]
arglist [3101,3118]
===
match
---
trailer [1444,1452]
trailer [1444,1452]
===
match
---
operator: = [3018,3019]
operator: = [3011,3012]
===
match
---
atom_expr [2126,2448]
atom_expr [2126,2448]
===
match
---
fstring [2159,2426]
fstring [2159,2426]
===
match
---
suite [2103,2587]
suite [2103,2587]
===
match
---
trailer [2300,2309]
trailer [2300,2309]
===
match
---
testlist_comp [2542,2584]
testlist_comp [2542,2584]
===
match
---
name: name [2578,2582]
name: name [2578,2582]
===
match
---
string: """Initializes the metadata database""" [1088,1127]
string: """Initializes the metadata database""" [1088,1127]
===
match
---
name: AirflowException [940,956]
name: AirflowException [940,956]
===
match
---
name: cli_utils [1495,1504]
name: cli_utils [1495,1504]
===
match
---
trailer [2540,2586]
trailer [2540,2586]
===
match
---
argument [2081,2096]
argument [2081,2096]
===
match
---
trailer [1964,1971]
trailer [1964,1971]
===
match
---
fstring_end: " [2583,2584]
fstring_end: " [2583,2584]
===
match
---
name: drivername [3191,3201]
name: drivername [3184,3194]
===
match
---
trailer [2759,2767]
trailer [2752,2760]
===
match
---
trailer [2675,2684]
trailer [2675,2684]
===
match
---
fstring_string:                  port     =  [2316,2344]
fstring_string:                  port     =  [2316,2344]
===
match
---
name: database [2397,2405]
name: database [2397,2405]
===
match
---
or_test [2345,2363]
or_test [2345,2363]
===
match
---
name: env [2751,2754]
name: env [2744,2747]
===
match
---
string: "Cancelled" [1479,1490]
string: "Cancelled" [1479,1490]
===
match
---
name: f [2499,2500]
name: f [2499,2500]
===
match
---
testlist_comp [2661,2684]
testlist_comp [2661,2684]
===
match
---
name: dedent [2135,2141]
name: dedent [2135,2141]
===
match
---
trailer [2786,2796]
trailer [2779,2789]
===
match
---
name: env [3047,3050]
name: env [3040,3043]
===
match
---
trailer [3070,3079]
trailer [3063,3072]
===
match
---
if_stmt [2011,3205]
if_stmt [2011,3198]
===
match
---
fstring_expr [2392,2406]
fstring_expr [2392,2406]
===
match
---
string: "" [2902,2904]
string: "" [2895,2897]
===
match
---
name: url [1972,1975]
name: url [1972,1975]
===
match
---
name: engine [1316,1322]
name: engine [1316,1322]
===
match
---
suite [2048,2587]
suite [2048,2587]
===
match
---
name: engine [1965,1971]
name: engine [1965,1971]
===
match
---
fstring_start: f" [2551,2553]
fstring_start: f" [2551,2553]
===
match
---
name: db [1178,1180]
name: db [1178,1180]
===
match
---
comparison [2703,2741]
comparison [2696,2734]
===
match
---
name: url [1622,1625]
name: url [1622,1625]
===
match
---
atom_expr [2521,2586]
atom_expr [2521,2586]
===
match
---
name: process_utils [1023,1036]
name: process_utils [1023,1036]
===
match
---
atom_expr [3314,3324]
atom_expr [3307,3317]
===
match
---
name: db [3314,3316]
name: db [3307,3309]
===
match
---
trailer [1322,1326]
trailer [1322,1326]
===
match
---
name: exceptions [922,932]
name: exceptions [922,932]
===
match
---
atom_expr [2672,2684]
atom_expr [2672,2684]
===
match
---
import_as_name [983,999]
import_as_name [983,999]
===
match
---
name: args [1670,1674]
name: args [1670,1674]
===
match
---
atom [3108,3116]
atom [3101,3109]
===
match
---
fstring_end: """ [2423,2426]
fstring_end: """ [2423,2426]
===
match
---
trailer [2825,2835]
trailer [2818,2828]
===
match
---
name: url [3187,3190]
name: url [3180,3183]
===
match
---
atom_expr [2469,2485]
atom_expr [2469,2485]
===
match
---
fstring_string:                  password =  [2268,2296]
fstring_string:                  password =  [2268,2296]
===
match
---
name: database [2676,2684]
name: database [2676,2684]
===
match
---
trailer [1353,1417]
trailer [1353,1417]
===
match
---
trailer [2616,2618]
trailer [2616,2618]
===
match
---
fstring_end: " [3202,3203]
fstring_end: " [3195,3196]
===
match
---
decorator [1494,1520]
decorator [1494,1520]
===
match
---
import_from [909,956]
import_from [909,956]
===
match
---
trailer [2440,2446]
trailer [2440,2446]
===
match
---
simple_stmt [1194,1223]
simple_stmt [1194,1223]
===
match
---
atom_expr [2217,2225]
atom_expr [2217,2225]
===
match
---
import_as_names [983,1003]
import_as_names [983,1003]
===
match
---
atom_expr [1995,2004]
atom_expr [1995,2004]
===
match
---
trailer [1292,1328]
trailer [1292,1328]
===
match
---
name: print [1980,1985]
name: print [1980,1985]
===
match
---
trailer [1591,1627]
trailer [1591,1627]
===
match
---
trailer [1621,1625]
trailer [1621,1625]
===
match
---
name: cli_utils [1842,1851]
name: cli_utils [1842,1851]
===
match
---
atom_expr [1147,1172]
atom_expr [1147,1172]
===
match
---
operator: = [2124,2125]
operator: = [2124,2125]
===
match
---
trailer [1814,1837]
trailer [1814,1837]
===
match
---
name: print [1132,1137]
name: print [1132,1137]
===
match
---
atom_expr [1307,1326]
atom_expr [1307,1326]
===
match
---
name: env [3118,3121]
name: env [3111,3114]
===
match
---
suite [1464,1492]
suite [1464,1492]
===
match
---
trailer [2462,2468]
trailer [2462,2468]
===
match
---
trailer [2468,2486]
trailer [2468,2486]
===
match
---
atom_expr [1132,1173]
atom_expr [1132,1173]
===
match
---
name: host [2221,2225]
name: host [2221,2225]
===
match
---
trailer [2772,2774]
trailer [2765,2767]
===
match
---
atom_expr [1810,1837]
atom_expr [1810,1837]
===
match
---
funcdef [1649,1839]
funcdef [1649,1839]
===
match
---
name: get_backend_name [2018,2034]
name: get_backend_name [2018,2034]
===
match
---
name: url [3020,3023]
name: url [3013,3016]
===
match
---
name: password [2301,2309]
name: password [2301,2309]
===
match
---
name: airflow [914,921]
name: airflow [914,921]
===
match
---
name: engine [1161,1167]
name: engine [1161,1167]
===
match
---
operator: } [2315,2316]
operator: } [2315,2316]
===
match
---
operator: { [2344,2345]
operator: { [2344,2345]
===
match
---
name: initdb [1070,1076]
name: initdb [1070,1076]
===
match
---
trailer [1180,1187]
trailer [1180,1187]
===
match
---
name: shell [1871,1876]
name: shell [1871,1876]
===
match
---
file_input [785,3325]
file_input [785,3318]
===
match
---
name: upper [1418,1423]
name: upper [1418,1423]
===
match
---
name: db [1001,1003]
name: db [1001,1003]
===
match
---
name: copy [2768,2772]
name: copy [2761,2765]
===
match
---
name: _ [3243,3244]
name: _ [3236,3237]
===
match
---
simple_stmt [839,879]
simple_stmt [839,879]
===
match
---
name: env [2783,2786]
name: env [2776,2779]
===
match
---
operator: { [2296,2297]
operator: { [2296,2297]
===
match
---
name: url [2345,2348]
name: url [2345,2348]
===
match
---
trailer [3316,3322]
trailer [3309,3315]
===
match
---
operator: + [1145,1146]
operator: + [1145,1146]
===
match
---
name: utils [970,975]
name: utils [970,975]
===
match
---
suite [1243,1492]
suite [1243,1492]
===
match
---
decorated [1494,1647]
decorated [1494,1647]
===
match
---
name: action_logging [3218,3232]
name: action_logging [3211,3225]
===
match
---
trailer [2017,2034]
trailer [2017,2034]
===
match
---
atom_expr [3187,3201]
atom_expr [3180,3194]
===
match
---
name: encode [2477,2483]
name: encode [2477,2483]
===
match
---
name: env [3122,3125]
name: env [3115,3118]
===
match
---
name: check [3317,3322]
name: check [3310,3315]
===
match
---
arith_expr [1138,1172]
arith_expr [1138,1172]
===
match
---
string: "DB: " [1138,1144]
string: "DB: " [1138,1144]
===
match
---
dotted_name [914,932]
dotted_name [914,932]
===
match
---
name: settings [900,908]
name: settings [900,908]
===
match
---
dotted_name [962,975]
dotted_name [962,975]
===
match
---
string: """Resets the metadata database""" [1248,1282]
string: """Resets the metadata database""" [1248,1282]
===
match
---
param [1877,1881]
param [1877,1881]
===
match
---
trailer [2706,2723]
trailer [2699,2716]
===
match
---
name: AirflowException [3151,3167]
name: AirflowException [3144,3160]
===
match
---
trailer [2873,2883]
trailer [2866,2876]
===
match
---
atom_expr [1194,1222]
atom_expr [1194,1222]
===
match
---
import_from [957,1003]
import_from [957,1003]
===
match
---
string: "PGPASSWORD" [3004,3016]
string: "PGPASSWORD" [2997,3009]
===
match
---
simple_stmt [813,823]
simple_stmt [813,823]
===
match
---
name: engine [1615,1621]
name: engine [1615,1621]
===
match
---
operator: { [3186,3187]
operator: { [3179,3180]
===
match
---
with_item [2062,2102]
with_item [2062,2102]
===
match
---
atom_expr [2640,2693]
atom_expr [2640,2686]
===
match
---
string: 'PGUSER' [2874,2882]
string: 'PGUSER' [2867,2875]
===
match
---
name: cli_utils [3208,3217]
name: cli_utils [3201,3210]
===
match
---
name: url [2842,2845]
name: url [2835,2838]
===
match
---
fstring_string:                  user     =  [2226,2254]
fstring_string:                  user     =  [2226,2254]
===
match
---
atom_expr [3020,3032]
atom_expr [3013,3025]
===
match
---
raise_stmt [3145,3204]
raise_stmt [3138,3197]
===
match
---
fstring [3168,3203]
fstring [3161,3196]
===
match
---
fstring_expr [2344,2364]
fstring_expr [2344,2364]
===
match
---
simple_stmt [3047,3080]
simple_stmt [3040,3073]
===
match
---
string: "Y" [1429,1432]
string: "Y" [1429,1432]
===
match
---
operator: } [3201,3202]
operator: } [3194,3195]
===
match
---
simple_stmt [2521,2587]
simple_stmt [2521,2587]
===
match
---
simple_stmt [880,909]
simple_stmt [880,909]
===
match
---
name: flush [2501,2506]
name: flush [2501,2506]
===
match
---
trailer [2446,2448]
trailer [2446,2448]
===
match
---
comparison [1348,1432]
comparison [1348,1432]
===
match
---
import_name [823,838]
import_name [823,838]
===
match
---
atom [2541,2585]
atom [2541,2585]
===
match
---
trailer [1801,1838]
trailer [1801,1838]
===
match
---
if_stmt [1333,1492]
if_stmt [1333,1492]
===
match
---
name: url [2672,2675]
name: url [2672,2675]
===
match
---
trailer [1306,1327]
trailer [1306,1327]
===
match
---
decorated [1841,3205]
decorated [1841,3198]
===
match
---
simple_stmt [1088,1128]
simple_stmt [1088,1128]
===
match
---
simple_stmt [2783,2814]
simple_stmt [2776,2807]
===
match
---
simple_stmt [2822,2862]
simple_stmt [2815,2855]
===
match
---
fstring_start: f" [3168,3170]
fstring_start: f" [3161,3163]
===
match
---
name: url [2255,2258]
name: url [2255,2258]
===
match
---
trailer [2767,2772]
trailer [2760,2765]
===
match
---
trailer [2506,2508]
trailer [2506,2508]
===
match
---
operator: } [2582,2583]
operator: } [2582,2583]
===
match
---
trailer [2134,2141]
trailer [2134,2141]
===
match
---
arith_expr [1592,1626]
arith_expr [1592,1626]
===
match
---
name: tempfile [844,852]
name: tempfile [844,852]
===
match
---
string: "Initialization done" [1200,1221]
string: "Initialization done" [1200,1221]
===
match
---
trailer [1167,1171]
trailer [1167,1171]
===
match
---
name: settings [1956,1964]
name: settings [1956,1964]
===
match
---
name: settings [1152,1160]
name: settings [1152,1160]
===
match
---
funcdef [1225,1492]
funcdef [1225,1492]
===
match
---
fstring_string:                   [2406,2423]
fstring_string:                   [2406,2423]
===
match
---
string: "DB: " [1592,1598]
string: "DB: " [1592,1598]
===
match
---
suite [1540,1647]
suite [1540,1647]
===
match
---
trailer [2841,2861]
trailer [2834,2854]
===
match
---
name: url [3067,3070]
name: url [3060,3063]
===
match
---
simple_stmt [2640,2694]
simple_stmt [2640,2687]
===
match
---
name: repr [1601,1605]
name: repr [1601,1605]
===
match
---
trailer [3050,3064]
trailer [3043,3057]
===
match
---
simple_stmt [1248,1283]
simple_stmt [1248,1283]
===
match
---
funcdef [1066,1223]
funcdef [1066,1223]
===
match
---
string: 'PGDATABASE' [3051,3063]
string: 'PGDATABASE' [3044,3056]
===
match
---
trailer [3003,3017]
trailer [2996,3010]
===
match
---
name: settings [1606,1614]
name: settings [1606,1614]
===
match
---
operator: + [1300,1301]
operator: + [1300,1301]
===
match
---
trailer [2723,2725]
trailer [2716,2718]
===
match
---
simple_stmt [2499,2509]
simple_stmt [2499,2509]
===
match
---
operator: = [2797,2798]
operator: = [2790,2791]
===
match
---
atom_expr [2783,2796]
atom_expr [2776,2789]
===
match
---
or_test [2886,2904]
or_test [2879,2897]
===
match
---
operator: = [3065,3066]
operator: = [3058,3059]
===
match
---
simple_stmt [909,957]
simple_stmt [909,957]
===
match
---
simple_stmt [1178,1190]
simple_stmt [1178,1190]
===
match
---
trailer [1478,1491]
trailer [1478,1491]
===
match
---
simple_stmt [1586,1628]
simple_stmt [1586,1628]
===
match
---
trailer [3023,3032]
trailer [3016,3025]
===
match
---
string: "mysql" [2542,2549]
string: "mysql" [2542,2549]
===
match
---
operator: , [2670,2671]
operator: , [2670,2671]
===
match
---
expr_stmt [2822,2861]
expr_stmt [2815,2854]
===
match
---
name: url [2703,2706]
name: url [2696,2699]
===
match
---
atom_expr [2870,2883]
atom_expr [2863,2876]
===
match
---
atom_expr [2345,2353]
atom_expr [2345,2353]
===
match
---
atom_expr [1980,2005]
atom_expr [1980,2005]
===
match
---
param [1670,1674]
param [1670,1674]
===
match
---
simple_stmt [957,1004]
simple_stmt [957,1004]
===
match
---
atom_expr [1152,1171]
atom_expr [1152,1171]
===
match
---
name: os [2757,2759]
name: os [2750,2752]
===
match
---
operator: + [1599,1600]
operator: + [1599,1600]
===
match
---
trailer [2802,2807]
trailer [2795,2800]
===
match
---
name: db [1442,1444]
name: db [1442,1444]
===
match
---
name: db [1632,1634]
name: db [1632,1634]
===
match
---
trailer [3322,3324]
trailer [3315,3317]
===
match
---
simple_stmt [3145,3205]
simple_stmt [3138,3198]
===
match
---
atom_expr [2393,2405]
atom_expr [2393,2405]
===
match
---
simple_stmt [2870,2905]
simple_stmt [2863,2898]
===
match
---
name: password [3024,3032]
name: password [3017,3025]
===
match
---
trailer [1315,1322]
trailer [1315,1322]
===
match
---
name: airflow [962,969]
name: airflow [962,969]
===
match
---
trailer [2141,2440]
trailer [2141,2440]
===
match
---
trailer [1199,1222]
trailer [1199,1222]
===
match
---
atom_expr [2014,2036]
atom_expr [2014,2036]
===
match
---
string: 'PGHOST' [2787,2795]
string: 'PGHOST' [2780,2788]
===
match
---
operator: = [1954,1955]
operator: = [1954,1955]
===
match
---
string: "This will drop existing tables if they exist. Proceed? (y/n)" [1354,1416]
string: "This will drop existing tables if they exist. Proceed? (y/n)" [1354,1416]
===
match
---
operator: @ [1494,1495]
operator: @ [1494,1495]
===
match
---
name: args [1534,1538]
name: args [1534,1538]
===
match
---
suite [1433,1455]
suite [1433,1455]
===
match
---
atom_expr [2842,2850]
atom_expr [2835,2843]
===
match
---
name: content [2469,2476]
name: content [2469,2476]
===
match
---
trailer [1971,1975]
trailer [1971,1975]
===
match
---
name: url [2217,2220]
name: url [2217,2220]
===
match
---
name: resetdb [1445,1452]
name: resetdb [1445,1452]
===
match
---
name: execute_interactive [2640,2659]
name: execute_interactive [2640,2659]
===
match
---
operator: == [2726,2728]
operator: == [2719,2721]
===
match
---
operator: @ [1841,1842]
operator: @ [1841,1842]
===
match
---
atom_expr [2822,2835]
atom_expr [2815,2828]
===
match
---
trailer [3167,3204]
trailer [3160,3197]
===
match
---
operator: } [2225,2226]
operator: } [2225,2226]
===
match
---
fstring_start: f""" [2159,2163]
fstring_start: f""" [2159,2163]
===
match
---
name: f [2461,2462]
name: f [2461,2462]
===
match
---
string: """Function to wait for all airflow migrations to complete. Used for launching airflow in k8s""" [1681,1777]
string: """Function to wait for all airflow migrations to complete. Used for launching airflow in k8s""" [1681,1777]
===
match
---
operator: { [2575,2576]
operator: { [2575,2576]
===
match
---
operator: + [1993,1994]
operator: + [1993,1994]
===
match
---
name: check_migrations [1785,1801]
name: check_migrations [1785,1801]
===
match
---
atom_expr [2757,2774]
atom_expr [2750,2767]
===
match
---
trailer [1137,1173]
trailer [1137,1173]
===
match
---
name: upgradedb [1524,1533]
name: upgradedb [1524,1533]
===
match
---
operator: } [2267,2268]
operator: } [2267,2268]
===
match
---
name: port [2846,2850]
name: port [2839,2843]
===
match
---
name: repr [1302,1306]
name: repr [1302,1306]
===
match
---
atom_expr [1442,1454]
atom_expr [1442,1454]
===
match
---
name: action_logging [1505,1519]
name: action_logging [1505,1519]
===
match
---
name: f [2576,2577]
name: f [2576,2577]
===
match
---
operator: } [2363,2364]
operator: } [2363,2364]
===
match
---
parameters [1076,1082]
parameters [1076,1082]
===
match
---
name: repr [1995,1999]
name: repr [1995,1999]
===
match
---
trailer [1644,1646]
trailer [1644,1646]
===
match
---
suite [3246,3325]
suite [3239,3318]
===
match
---
name: f [2101,2102]
name: f [2101,2102]
===
match
---
trailer [1340,1344]
trailer [1340,1344]
===
match
---
string: """Runs a check command that checks if db is available.""" [3251,3309]
string: """Runs a check command that checks if db is available.""" [3244,3302]
===
match
---
atom_expr [1606,1625]
atom_expr [1606,1625]
===
match
---
name: cli_utils [990,999]
name: cli_utils [990,999]
===
match
---
comparison [2596,2630]
comparison [2596,2630]
===
match
---
expr_stmt [2116,2448]
expr_stmt [2116,2448]
===
match
---
atom_expr [1302,1327]
atom_expr [1302,1327]
===
match
---
atom_expr [2297,2309]
atom_expr [2297,2309]
===
match
---
fstring [2551,2584]
fstring [2551,2584]
===
match
---
fstring_expr [2296,2316]
fstring_expr [2296,2316]
===
match
---
fstring_string:                  database =  [2364,2392]
fstring_string:                  database =  [2364,2392]
===
match
---
or_test [2297,2315]
or_test [2297,2315]
===
match
---
expr_stmt [2870,2904]
expr_stmt [2863,2897]
===
match
---
suite [2631,2694]
suite [2631,2687]
===
match
---
name: execute_interactive [1044,1063]
name: execute_interactive [1044,1063]
===
match
---
operator: { [2254,2255]
operator: { [2254,2255]
===
match
---
name: args [1336,1340]
name: args [1336,1340]
===
match
---
atom_expr [2062,2097]
atom_expr [2062,2097]
===
match
---
atom_expr [1287,1328]
atom_expr [1287,1328]
===
match
---
trailer [2483,2485]
trailer [2483,2485]
===
match
---
name: suffix [2081,2087]
name: suffix [2081,2087]
===
match
---
simple_stmt [823,839]
simple_stmt [823,839]
===
match
---
expr_stmt [2751,2774]
expr_stmt [2744,2767]
===
match
---
or_test [3020,3038]
or_test [3013,3031]
===
match
---
parameters [1533,1539]
parameters [1533,1539]
===
match
---
simple_stmt [1473,1492]
simple_stmt [1473,1492]
===
match
---
atom_expr [1632,1646]
atom_expr [1632,1646]
===
match
---
trailer [1985,2005]
trailer [1985,2005]
===
match
---
expr_stmt [3047,3079]
expr_stmt [3040,3072]
===
match
---
name: print [1473,1478]
name: print [1473,1478]
===
match
---
simple_stmt [1545,1582]
simple_stmt [1545,1582]
===
match
---
string: "DB: " [1293,1299]
string: "DB: " [1293,1299]
===
match
---
import_from [880,908]
import_from [880,908]
===
match
---
name: execute_interactive [3088,3107]
name: execute_interactive [3081,3100]
===
match
---
atom_expr [2703,2725]
atom_expr [2696,2718]
===
match
---
operator: = [2884,2885]
operator: = [2877,2878]
===
match
---
simple_stmt [1681,1778]
simple_stmt [1681,1778]
===
match
---
atom_expr [1782,1838]
atom_expr [1782,1838]
===
match
---
trailer [3107,3126]
trailer [3100,3119]
===
match
---
atom_expr [2461,2486]
atom_expr [2461,2486]
===
match
---
funcdef [1867,3205]
funcdef [1867,3198]
===
match
---
name: input [1348,1353]
name: input [1348,1353]
===
match
---
operator: } [2405,2406]
operator: } [2405,2406]
===
match
---
name: print [1586,1591]
name: print [1586,1591]
===
match
---
atom_expr [3088,3126]
atom_expr [3081,3119]
===
match
---
trailer [2080,2097]
trailer [2080,2097]
===
match
---
trailer [2889,2898]
trailer [2882,2891]
===
match
---
string: "" [3036,3038]
string: "" [3029,3031]
===
match
---
name: timeout [1802,1809]
name: timeout [1802,1809]
===
match
---
expr_stmt [3000,3038]
expr_stmt [2993,3031]
===
match
---
atom_expr [2596,2618]
atom_expr [2596,2618]
===
match
---
with_stmt [2057,2587]
with_stmt [2057,2587]
===
match
---
operator: = [2755,2756]
operator: = [2748,2749]
===
match
---
name: url [1168,1171]
name: url [1168,1171]
===
match
---
atom_expr [1601,1626]
atom_expr [1601,1626]
===
match
---
name: yes [1341,1344]
name: yes [1341,1344]
===
match
---
fstring_expr [3186,3202]
fstring_expr [3179,3195]
===
match
---
name: environ [2760,2767]
name: environ [2753,2760]
===
match
---
operator: { [2216,2217]
operator: { [2216,2217]
===
match
---
atom_expr [1348,1425]
atom_expr [1348,1425]
===
match
---
string: "3306" [2357,2363]
string: "3306" [2357,2363]
===
match
---
operator: = [1809,1810]
operator: = [1809,1810]
===
match
---
name: settings [1307,1315]
name: settings [1307,1315]
===
match
---
dotted_name [1842,1866]
dotted_name [1842,1866]
===
match
---
trailer [2220,2225]
trailer [2220,2225]
===
match
---
operator: == [2037,2039]
operator: == [2037,2039]
===
match
---
simple_stmt [1980,2006]
simple_stmt [1980,2006]
===
match
---
operator: = [2836,2837]
operator: = [2829,2830]
===
match
---
simple_stmt [785,813]
simple_stmt [785,813]
===
match
---
simple_stmt [3000,3039]
simple_stmt [2993,3032]
===
match
---
name: env [3000,3003]
name: env [2993,2996]
===
match
---
name: url [2393,2396]
name: url [2393,2396]
===
match
---
decorated [3207,3325]
decorated [3200,3318]
===
match
---
trailer [2396,2405]
trailer [2396,2405]
===
match
---
name: upgradedb [1635,1644]
name: upgradedb [1635,1644]
===
match
---
or_test [2799,2813]
or_test [2792,2806]
===
match
---
name: url [2596,2599]
name: url [2596,2599]
===
match
---
expr_stmt [1950,1975]
expr_stmt [1950,1975]
===
match
---
simple_stmt [1888,1946]
simple_stmt [1888,1946]
===
match
---
atom_expr [3151,3204]
atom_expr [3144,3197]
===
match
---
parameters [3242,3245]
parameters [3235,3238]
===
match
---
string: "DB: " [1986,1992]
string: "DB: " [1986,1992]
===
match
---
name: host [2803,2807]
name: host [2796,2800]
===
match
---
simple_stmt [1782,1839]
simple_stmt [1782,1839]
===
match
---
name: str [2838,2841]
name: str [2831,2834]
===
match
---
trailer [2659,2686]
trailer [2659,2686]
===
match
---
import_name [813,822]
import_name [813,822]
===
match
---
suite [3136,3205]
suite [3129,3198]
===
match
---
operator: == [1426,1428]
operator: == [1426,1428]
===
match
---
operator: @ [3207,3208]
operator: @ [3200,3201]
===
match
---
string: "5432" [2854,2860]
string: "5432" [2847,2853]
===
match
---
simple_stmt [1442,1455]
simple_stmt [1442,1455]
===
match
---
dotted_name [1495,1519]
dotted_name [1495,1519]
===
match
---
atom_expr [2838,2861]
atom_expr [2831,2854]
===
match
---
dotted_name [1009,1036]
dotted_name [1009,1036]
===
match
---
name: write [2463,2468]
name: write [2463,2468]
===
match
---
operator: , [3116,3117]
operator: , [3109,3110]
===
match
---
name: repr [1147,1151]
name: repr [1147,1151]
===
match
---
param [1534,1538]
param [1534,1538]
===
match
---
string: "" [2811,2813]
string: "" [2804,2806]
===
match
---
trailer [2845,2850]
trailer [2838,2843]
===
match
---
trailer [2500,2506]
trailer [2500,2506]
===
match
---
simple_stmt [1950,1976]
simple_stmt [1950,1976]
===
match
---
trailer [1452,1454]
trailer [1452,1454]
===
match
---
trailer [1784,1801]
trailer [1784,1801]
===
match
---
name: url [2014,2017]
name: url [2014,2017]
===
match
---
trailer [3190,3201]
trailer [3183,3194]
===
match
---
trailer [1423,1425]
trailer [1423,1425]
===
match
---
string: "" [2313,2315]
string: "" [2313,2315]
===
match
---
import_from [839,878]
import_from [839,878]
===
match
---
simple_stmt [2116,2449]
simple_stmt [2116,2449]
===
match
---
name: strip [2441,2446]
name: strip [2441,2446]
===
match
---
param [3243,3244]
param [3236,3237]
===
match
---
operator: , [999,1000]
operator: , [999,1000]
===
match
---
parameters [1236,1242]
parameters [1236,1242]
===
match
---
param [1237,1241]
param [1237,1241]
===
match
---
operator: = [2087,2088]
operator: = [2087,2088]
===
match
---
simple_stmt [1287,1329]
simple_stmt [1287,1329]
===
match
---
atom_expr [1473,1491]
atom_expr [1473,1491]
===
match
---
funcdef [3233,3325]
funcdef [3226,3318]
===
match
---
name: execute_interactive [2521,2540]
name: execute_interactive [2521,2540]
===
match
---
name: textwrap [830,838]
name: textwrap [830,838]
===
match
---
name: url [1950,1953]
name: url [1950,1953]
===
match
---
name: print [1287,1292]
name: print [1287,1292]
===
match
---
fstring_string: --defaults-extra-file= [2553,2575]
fstring_string: --defaults-extra-file= [2553,2575]
===
match
---
name: url [2886,2889]
name: url [2879,2882]
===
match
---
simple_stmt [2751,2775]
simple_stmt [2744,2768]
===
match
---
trailer [1605,1626]
trailer [1605,1626]
===
match
---
trailer [1999,2004]
trailer [1999,2004]
===
match
---
fstring_string:                  [client]                 host     =  [2163,2216]
fstring_string:                  [client]                 host     =  [2163,2216]
===
match
---
trailer [2476,2483]
trailer [2476,2483]
===
match
---
arith_expr [1293,1327]
arith_expr [1293,1327]
===
match
---
trailer [2258,2267]
trailer [2258,2267]
===
match
---
name: migration_wait_timeout [1815,1837]
name: migration_wait_timeout [1815,1837]
===
match
---
arith_expr [1986,2004]
arith_expr [1986,2004]
===
match
---
argument [1802,1837]
argument [1802,1837]
===
match
---
operator: = [3121,3122]
operator: = [3114,3115]
===
match
---
name: url [1323,1326]
name: url [1323,1326]
===
match
---
atom_expr [3047,3064]
atom_expr [3040,3057]
===
delete-tree
---
trailer [2686,2691]
    name: wait [2687,2691]
===
delete-node
---
trailer [2691,2693]
===
