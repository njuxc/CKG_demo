===
match
---
arglist [6367,6383]
arglist [6353,6369]
===
match
---
arglist [5651,5665]
arglist [5641,5651]
===
match
---
name: conf [1663,1667]
name: conf [1653,1657]
===
match
---
name: sensitive_fields [1843,1859]
name: sensitive_fields [1833,1849]
===
match
---
tfpdef [7637,7646]
tfpdef [7635,7644]
===
match
---
name: redact [6910,6916]
name: redact [6896,6902]
===
match
---
atom_expr [4925,4940]
atom_expr [4915,4930]
===
match
---
name: RedactableItem [1093,1107]
name: RedactableItem [1083,1097]
===
match
---
string: "" [4264,4266]
string: "" [4254,4256]
===
match
---
string: "RePatternType" [3507,3522]
string: "RePatternType" [3497,3512]
===
match
---
atom [6344,6422]
atom [6330,6408]
===
match
---
trailer [1932,1937]
trailer [1922,1927]
===
match
---
operator: , [1342,1343]
operator: , [1332,1333]
===
match
---
parameters [4440,4454]
parameters [4430,4444]
===
match
---
trailer [5405,5411]
trailer [5395,5401]
===
match
---
name: self [7092,7096]
name: self [7000,7004]
===
match
---
return_stmt [5763,5774]
return_stmt [5749,5760]
===
match
---
name: log [7253,7256]
name: log [7251,7254]
===
match
---
trailer [3674,3683]
trailer [3664,3673]
===
match
---
atom_expr [6905,6924]
atom_expr [6891,6910]
===
match
---
string: """Redact secrets from logs""" [3452,3482]
string: """Redact secrets from logs""" [3442,3472]
===
match
---
atom_expr [2902,2931]
atom_expr [2892,2921]
===
match
---
name: patterns [8161,8169]
name: patterns [8159,8167]
===
match
---
simple_stmt [1629,1668]
simple_stmt [1619,1658]
===
match
---
name: TypeVar [941,948]
name: TypeVar [931,938]
===
match
---
arglist [7747,7759]
arglist [7745,7757]
===
match
---
dictorsetmaker [6345,6421]
dictorsetmaker [6331,6407]
===
match
---
atom_expr [3498,3523]
atom_expr [3488,3513]
===
match
---
name: sensitive_fields [1951,1967]
name: sensitive_fields [1941,1957]
===
match
---
name: isinstance [6804,6814]
name: isinstance [6790,6800]
===
match
---
atom [5341,5414]
atom [5331,5404]
===
match
---
trailer [5411,5413]
trailer [5401,5403]
===
match
---
suite [4976,5135]
suite [4966,5125]
===
match
---
simple_stmt [1093,1136]
simple_stmt [1083,1126]
===
match
---
simple_stmt [872,882]
simple_stmt [862,872]
===
match
---
name: cache [1507,1512]
name: cache [1497,1502]
===
match
---
arglist [7862,7873]
arglist [7860,7871]
===
match
---
operator: , [8291,8292]
operator: , [8289,8290]
===
match
---
simple_stmt [5334,5415]
simple_stmt [5324,5405]
===
match
---
name: copy [1717,1721]
name: copy [1707,1711]
===
match
---
name: item [7014,7018]
name: item [7081,7085]
===
match
---
trailer [3650,3659]
trailer [3640,3649]
===
match
---
trailer [2254,2307]
trailer [2244,2297]
===
match
---
param [3746,3750]
param [3736,3740]
===
match
---
name: redact [3014,3020]
name: redact [3004,3010]
===
match
---
return_stmt [2244,2307]
return_stmt [2234,2297]
===
match
---
dictorsetmaker [1874,1937]
dictorsetmaker [1864,1927]
===
match
---
simple_stmt [3363,3409]
simple_stmt [3353,3399]
===
match
---
import_from [882,955]
import_from [872,945]
===
match
---
param [5870,5886]
param [5856,5872]
===
match
---
argument [4301,4314]
argument [4291,4304]
===
match
---
operator: = [5098,5099]
operator: = [5088,5089]
===
match
---
arglist [6308,6318]
arglist [6294,6304]
===
match
---
name: Optional [3498,3506]
name: Optional [3488,3496]
===
match
---
operator: , [2360,2361]
operator: , [2350,2351]
===
match
---
trailer [5005,5014]
trailer [4995,5004]
===
match
---
not_test [8015,8023]
not_test [8013,8021]
===
match
---
return_stmt [5569,5626]
return_stmt [5559,5616]
===
match
---
arglist [7832,7836]
arglist [7830,7834]
===
match
---
string: "SecretsMasker" [3217,3232]
string: "SecretsMasker" [3207,3222]
===
match
---
name: v [7832,7833]
name: v [7830,7831]
===
match
---
trailer [3257,3267]
trailer [3247,3257]
===
match
---
name: typing [887,893]
name: typing [877,883]
===
match
---
name: subval [5369,5375]
name: subval [5359,5365]
===
match
---
atom_expr [7092,7111]
atom_expr [7000,7019]
===
match
---
name: name [3177,3181]
name: name [3167,3171]
===
match
---
string: 'private_key' [1372,1385]
string: 'private_key' [1362,1375]
===
match
---
dictorsetmaker [5342,5413]
dictorsetmaker [5332,5403]
===
match
---
atom_expr [4945,4963]
atom_expr [4935,4953]
===
match
---
operator: , [2377,2378]
operator: , [2367,2368]
===
match
---
if_stmt [4922,5135]
if_stmt [4912,5125]
===
match
---
return_stmt [6892,6944]
return_stmt [6878,6930]
===
match
---
simple_stmt [7818,7838]
simple_stmt [7816,7836]
===
match
---
operator: , [948,949]
operator: , [938,939]
===
match
---
name: replacer [3488,3496]
name: replacer [3478,3486]
===
match
---
simple_stmt [4849,4858]
simple_stmt [4839,4848]
===
match
---
atom_expr [8136,8171]
atom_expr [8134,8169]
===
match
---
name: subval [7116,7122]
name: subval [7024,7030]
===
match
---
if_stmt [7888,7926]
if_stmt [7886,7924]
===
match
---
name: self [6728,6732]
name: self [6714,6718]
===
match
---
import_name [828,846]
import_name [828,846]
===
match
---
name: settings [2783,2791]
name: settings [2773,2781]
===
match
---
trailer [7256,7264]
trailer [7254,7262]
===
match
---
operator: = [3056,3057]
operator: = [3046,3047]
===
match
---
operator: = [4893,4894]
operator: = [4883,4884]
===
match
---
name: record [4874,4880]
name: record [4864,4870]
===
match
---
trailer [8215,8219]
trailer [8213,8217]
===
match
---
trailer [5708,5716]
trailer [5694,5702]
===
match
---
name: exc [5089,5092]
name: exc [5079,5082]
===
match
---
funcdef [3010,3183]
funcdef [3000,3173]
===
match
---
simple_stmt [882,956]
simple_stmt [872,946]
===
match
---
parameters [5839,5887]
parameters [5825,5873]
===
match
---
atom [5100,5134]
atom [5090,5124]
===
match
---
suite [1834,1940]
suite [1824,1930]
===
match
---
simple_stmt [4043,4355]
simple_stmt [4033,4345]
===
match
---
name: subval [6917,6923]
name: subval [6903,6909]
===
match
---
name: self [3628,3632]
name: self [3618,3622]
===
match
---
trailer [4407,4424]
trailer [4397,4414]
===
match
---
operator: , [5655,5656]
operator: , [5645,5646]
===
match
---
suite [7655,8299]
suite [7653,8297]
===
match
---
simple_stmt [4687,4699]
simple_stmt [4677,4689]
===
match
---
trailer [7103,7111]
trailer [7011,7019]
===
match
---
file_input [785,8299]
file_input [785,8297]
===
match
---
expr_stmt [1673,1723]
expr_stmt [1663,1713]
===
match
---
atom_expr [1874,1887]
atom_expr [1864,1877]
===
match
---
operator: , [1324,1325]
operator: , [1314,1315]
===
match
---
for_stmt [4738,4910]
for_stmt [4728,4900]
===
match
---
exprlist [4742,4746]
exprlist [4732,4736]
===
match
---
trailer [3548,3553]
trailer [3538,3543]
===
match
---
name: cache [994,999]
name: cache [984,989]
===
match
---
funcdef [5220,5775]
funcdef [5210,5761]
===
match
---
string: "RedactableItem" [3067,3083]
string: "RedactableItem" [3057,3073]
===
match
---
name: item [5621,5625]
name: item [5611,5615]
===
match
---
dotted_name [1634,1655]
dotted_name [1624,1645]
===
match
---
simple_stmt [3348,3359]
simple_stmt [3338,3349]
===
match
---
operator: = [7946,7947]
operator: = [7944,7945]
===
match
---
trailer [7096,7103]
trailer [7004,7011]
===
match
---
trailer [5163,5185]
trailer [5153,5175]
===
match
---
string: '***' [6746,6751]
string: '***' [6732,6737]
===
match
---
name: super [3643,3648]
name: super [3633,3638]
===
match
---
name: list [5687,5691]
name: list [5673,5677]
===
match
---
arglist [6451,6460]
arglist [6437,6446]
===
match
---
atom_expr [3250,3291]
atom_expr [3240,3281]
===
match
---
return_stmt [6337,6422]
return_stmt [6323,6408]
===
match
---
simple_stmt [828,847]
simple_stmt [828,847]
===
match
---
trailer [3659,3661]
trailer [3649,3651]
===
match
---
name: patterns [3675,3683]
name: patterns [3665,3673]
===
match
---
testlist_comp [6822,6832]
testlist_comp [6808,6818]
===
match
---
name: abc [8216,8219]
name: abc [8214,8217]
===
match
---
argument [2255,2306]
argument [2245,2296]
===
match
---
name: frozenset [4370,4379]
name: frozenset [4360,4369]
===
match
---
decorated [1506,1968]
decorated [1496,1958]
===
match
---
return_stmt [4363,4424]
return_stmt [4353,4414]
===
match
---
name: typing_compat [1053,1066]
name: typing_compat [1043,1056]
===
match
---
name: v [8247,8248]
name: v [8245,8246]
===
match
---
name: v [4907,4908]
name: v [4897,4898]
===
match
---
atom [1216,1410]
atom [1206,1400]
===
match
---
if_stmt [1018,1136]
if_stmt [1008,1126]
===
match
---
trailer [3169,3182]
trailer [3159,3172]
===
match
---
trailer [6274,6280]
trailer [6260,6266]
===
match
---
atom_expr [6355,6384]
atom_expr [6341,6370]
===
match
---
name: __dict__ [4757,4765]
name: __dict__ [4747,4755]
===
match
---
name: replacer [6487,6495]
name: replacer [6473,6481]
===
match
---
name: name [3002,3006]
name: name [2992,2996]
===
match
---
operator: @ [1506,1507]
operator: @ [1496,1497]
===
match
---
trailer [6909,6916]
trailer [6895,6902]
===
match
---
trailer [4880,4889]
trailer [4870,4879]
===
match
---
name: exc [4993,4996]
name: exc [4983,4986]
===
match
---
trailer [7957,7965]
trailer [7955,7963]
===
match
---
return_stmt [5463,5475]
return_stmt [5453,5465]
===
match
---
operator: = [2389,2390]
operator: = [2379,2380]
===
match
---
name: item [5651,5655]
name: item [5641,5645]
===
match
---
name: self [7818,7822]
name: self [7816,7820]
===
match
---
and_test [2150,2198]
and_test [2140,2188]
===
match
---
string: 'msg' [4409,4414]
string: 'msg' [4399,4404]
===
match
---
expr_stmt [5089,5134]
expr_stmt [5079,5124]
===
match
---
name: subval [6367,6373]
name: subval [6353,6359]
===
match
---
expr_stmt [3535,3553]
expr_stmt [3525,3543]
===
match
---
name: compat [970,976]
name: compat [960,966]
===
match
---
suite [4463,5215]
suite [4453,5205]
===
match
---
testlist_comp [5507,5517]
testlist_comp [5497,5507]
===
match
---
name: pattern [7938,7945]
name: pattern [7936,7943]
===
match
---
operator: , [934,935]
operator: , [924,925]
===
match
---
name: get [1761,1764]
name: get [1751,1754]
===
match
---
simple_stmt [2955,2962]
simple_stmt [2945,2952]
===
match
---
atom_expr [4052,4354]
atom_expr [4042,4344]
===
match
---
arglist [8196,8228]
arglist [8194,8226]
===
match
---
dotted_name [962,986]
dotted_name [952,976]
===
match
---
operator: , [1403,1404]
operator: , [1393,1394]
===
match
---
trailer [5650,5666]
trailer [5640,5652]
===
match
---
simple_stmt [5917,6165]
simple_stmt [5903,6151]
===
match
---
expr_stmt [4043,4354]
expr_stmt [4033,4344]
===
match
---
arglist [3170,3181]
arglist [3160,3171]
===
match
---
suite [5450,5476]
suite [5440,5466]
===
match
---
parameters [3211,3213]
parameters [3201,3203]
===
match
---
simple_stmt [8120,8172]
simple_stmt [8118,8170]
===
match
---
string: """     Mask a secret from appearing in the task logs.      If ``name`` is provided, then it will only be masked if the name matches     one of the configured "sensitive" names.      If ``secret`` is a dict or a iterable (excluding str) then it will be     recursively walked and keys with sensitive names will be hidden.     """ [2410,2739]
string: """     Mask a secret from appearing in the task logs.      If ``name`` is provided, then it will only be masked if the name matches     one of the configured "sensitive" names.      If ``secret`` is a dict or a iterable (excluding str) then it will be     recursively walked and keys with sensitive names will be hidden.     """ [2400,2729]
===
match
---
operator: , [7488,7489]
operator: , [7486,7487]
===
match
---
name: filters [3284,3291]
name: filters [3274,3281]
===
match
---
name: secret [7862,7868]
name: secret [7860,7866]
===
match
---
name: add [8091,8094]
name: add [8089,8092]
===
match
---
name: DEFAULT_SENSITIVE_FIELDS [1174,1198]
name: DEFAULT_SENSITIVE_FIELDS [1164,1188]
===
match
---
suite [3769,4425]
suite [3759,4415]
===
match
---
decorated [3185,3409]
decorated [3175,3399]
===
match
---
operator: , [4250,4251]
operator: , [4240,4241]
===
match
---
name: self [5840,5844]
name: self [5826,5830]
===
match
---
atom_expr [5143,5186]
atom_expr [5133,5176]
===
match
---
name: field [1874,1879]
name: field [1864,1869]
===
match
---
trailer [3162,3169]
trailer [3152,3159]
===
match
---
name: flt [3243,3246]
name: flt [3233,3236]
===
match
---
if_stmt [4472,4699]
if_stmt [4462,4689]
===
match
---
trailer [4906,4909]
trailer [4896,4899]
===
match
---
raise_stmt [3363,3408]
raise_stmt [3353,3398]
===
match
---
atom_expr [7996,8009]
atom_expr [7994,8007]
===
match
---
name: __dict__ [4512,4520]
name: __dict__ [4502,4510]
===
match
---
name: secret [7786,7792]
name: secret [7784,7790]
===
match
---
operator: , [7868,7869]
operator: , [7866,7867]
===
match
---
parameters [1547,1549]
parameters [1537,1539]
===
match
---
trailer [6419,6421]
trailer [6405,6407]
===
match
---
name: item [5439,5443]
name: item [5429,5433]
===
match
---
name: self [8276,8280]
name: self [8274,8278]
===
match
---
trailer [1872,1939]
trailer [1862,1929]
===
match
---
trailer [1926,1932]
trailer [1916,1922]
===
match
---
suite [6496,6759]
suite [6482,6745]
===
match
---
operator: , [6455,6456]
operator: , [6441,6442]
===
match
---
operator: = [4997,4998]
operator: = [4987,4988]
===
match
---
operator: , [5844,5845]
operator: , [5830,5831]
===
match
---
name: tuple [5507,5512]
name: tuple [5497,5502]
===
match
---
name: settings [2902,2910]
name: settings [2892,2900]
===
match
---
dictorsetmaker [4409,4422]
dictorsetmaker [4399,4412]
===
match
---
arglist [5439,5448]
arglist [5429,5438]
===
match
---
operator: , [4445,4446]
operator: , [4435,4436]
===
match
---
name: add_mask [7823,7831]
name: add_mask [7821,7829]
===
match
---
simple_stmt [5569,5627]
simple_stmt [5559,5617]
===
match
---
import_from [2763,2791]
import_from [2753,2781]
===
match
---
simple_stmt [6721,6759]
simple_stmt [6707,6745]
===
match
---
name: item [5846,5850]
name: item [5832,5836]
===
match
---
atom_expr [6440,6461]
atom_expr [6426,6447]
===
match
---
annassign [3543,3553]
annassign [3533,3543]
===
match
---
name: secret [7747,7753]
name: secret [7745,7751]
===
match
---
simple_stmt [6775,6787]
simple_stmt [6761,6773]
===
match
---
suite [7801,7838]
suite [7799,7836]
===
match
---
name: Iterable [916,924]
name: Iterable [906,914]
===
match
---
name: record [4447,4453]
name: record [4437,4443]
===
match
---
name: self [4475,4479]
name: self [4465,4469]
===
match
---
trailer [4386,4395]
trailer [4376,4385]
===
match
---
name: v [5120,5121]
name: v [5110,5111]
===
match
---
trailer [2227,2233]
trailer [2217,2223]
===
match
---
name: item [6753,6757]
name: item [6739,6743]
===
match
---
atom_expr [2274,2306]
atom_expr [2264,2296]
===
match
---
name: name [7637,7641]
name: name [7635,7639]
===
match
---
name: v [4745,4746]
name: v [4735,4736]
===
match
---
trailer [1210,1412]
trailer [1200,1402]
===
match
---
operator: , [6397,6398]
operator: , [6383,6384]
===
match
---
expr_stmt [2208,2235]
expr_stmt [2198,2225]
===
match
---
name: str [3052,3055]
name: str [3042,3045]
===
match
---
atom_expr [4380,4395]
atom_expr [4370,4385]
===
match
---
sync_comp_for [6925,6943]
sync_comp_for [6911,6929]
===
match
---
trailer [4396,4407]
trailer [4386,4397]
===
match
---
sync_comp_for [1888,1937]
sync_comp_for [1878,1927]
===
match
---
atom_expr [4895,4909]
atom_expr [4885,4899]
===
match
---
tfpdef [2343,2377]
tfpdef [2333,2367]
===
match
---
name: e [7453,7454]
name: e [7451,7452]
===
match
---
operator: } [4422,4423]
operator: } [4412,4413]
===
match
---
simple_stmt [8276,8299]
simple_stmt [8274,8297]
===
match
---
name: self [5159,5163]
name: self [5149,5153]
===
match
---
name: self [6258,6262]
name: self [6244,6248]
===
match
---
name: logging [1144,1151]
name: logging [1134,1141]
===
match
---
atom_expr [4201,4213]
atom_expr [4191,4203]
===
match
---
atom_expr [3755,3768]
atom_expr [3745,3758]
===
match
---
atom_expr [7253,7503]
atom_expr [7251,7501]
===
match
---
try_stmt [6173,7528]
try_stmt [6159,7526]
===
match
---
name: add_mask [2985,2993]
name: add_mask [2975,2983]
===
match
---
operator: , [7779,7780]
operator: , [7777,7778]
===
match
---
or_test [8015,8058]
or_test [8013,8056]
===
match
---
name: self [5582,5586]
name: self [5572,5576]
===
match
---
name: redact [5833,5839]
name: redact [5819,5825]
===
match
---
trailer [6904,6944]
trailer [6890,6930]
===
match
---
operator: , [5868,5869]
operator: , [5854,5855]
===
match
---
suite [4828,4858]
suite [4818,4848]
===
match
---
trailer [6262,6274]
trailer [6248,6260]
===
match
---
trailer [1117,1135]
trailer [1107,1125]
===
match
---
trailer [1721,1723]
trailer [1711,1713]
===
match
---
name: INFO [4209,4213]
name: INFO [4199,4203]
===
match
---
argument [5692,5735]
argument [5678,5721]
===
match
---
name: str [7615,7618]
name: str [7613,7616]
===
match
---
operator: , [7599,7600]
operator: , [7597,7598]
===
match
---
param [5840,5845]
param [5826,5831]
===
match
---
param [5242,5264]
param [5232,5254]
===
match
---
name: self [7996,8000]
name: self [7994,7998]
===
match
---
if_stmt [7978,8172]
if_stmt [7976,8170]
===
match
---
operator: = [8134,8135]
operator: = [8132,8133]
===
match
---
trailer [2356,2377]
trailer [2346,2367]
===
match
---
name: s [2269,2270]
name: s [2259,2260]
===
match
---
param [7637,7653]
param [7635,7651]
===
match
---
name: _secrets_masker [2967,2982]
name: _secrets_masker [2957,2972]
===
match
---
expr_stmt [5143,5193]
expr_stmt [5133,5183]
===
match
---
atom_expr [4799,4827]
atom_expr [4789,4817]
===
match
---
name: pattern [8095,8102]
name: pattern [8093,8100]
===
match
---
suite [6234,6281]
suite [6220,6267]
===
match
---
parameters [1999,2005]
parameters [1989,1995]
===
match
---
suite [8230,8299]
suite [8228,8297]
===
match
---
argument [5582,5625]
argument [5572,5615]
===
match
---
name: secret [8252,8258]
name: secret [8250,8256]
===
match
---
simple_stmt [7919,7926]
simple_stmt [7917,7924]
===
match
---
param [5236,5241]
param [5226,5231]
===
match
---
string: "RedactableItem" [5891,5907]
string: "RedactableItem" [5877,5893]
===
match
---
simple_stmt [3670,3692]
simple_stmt [3660,3682]
===
match
---
name: str [2357,2360]
name: str [2347,2350]
===
match
---
simple_stmt [6337,6423]
simple_stmt [6323,6409]
===
match
---
trailer [5499,5519]
trailer [5489,5509]
===
match
---
import_from [1040,1087]
import_from [1030,1077]
===
match
---
operator: , [1362,1363]
operator: , [1352,1353]
===
match
---
name: sub [6742,6745]
name: sub [6728,6731]
===
match
---
trailer [4285,4287]
trailer [4275,4277]
===
match
---
name: sensitive_variable_fields [1901,1926]
name: sensitive_variable_fields [1891,1916]
===
match
---
name: self [3670,3674]
name: self [3660,3664]
===
match
---
operator: , [4743,4744]
operator: , [4733,4734]
===
match
---
operator: , [6819,6820]
operator: , [6805,6806]
===
match
---
suite [6462,6787]
suite [6448,6773]
===
match
---
simple_stmt [2011,2109]
simple_stmt [2001,2099]
===
match
---
name: value [3170,3175]
name: value [3160,3165]
===
match
---
atom_expr [7482,7488]
atom_expr [7480,7486]
===
match
---
operator: , [5389,5390]
operator: , [5379,5380]
===
match
---
string: "RedactableItem" [5852,5868]
string: "RedactableItem" [5838,5854]
===
match
---
string: """Add a new secret to be masked to this filter instance.""" [7664,7724]
string: """Add a new secret to be masked to this filter instance.""" [7662,7722]
===
match
---
return_stmt [6721,6758]
return_stmt [6707,6744]
===
match
---
trailer [4951,4960]
trailer [4941,4950]
===
match
---
simple_stmt [5680,5737]
simple_stmt [5666,5723]
===
match
---
name: name [2215,2219]
name: name [2205,2209]
===
match
---
name: record [4750,4756]
name: record [4740,4746]
===
match
---
expr_stmt [1728,1800]
expr_stmt [1718,1790]
===
match
---
name: should_hide_value_for_key [1974,1999]
name: should_hide_value_for_key [1964,1989]
===
match
---
atom_expr [4874,4892]
atom_expr [4864,4882]
===
match
---
operator: = [4332,4333]
operator: = [4322,4323]
===
match
---
name: item [7426,7430]
name: item [7424,7428]
===
match
---
name: functools [977,986]
name: functools [967,976]
===
match
---
atom_expr [5101,5115]
atom_expr [5091,5105]
===
match
---
atom_expr [5582,5606]
atom_expr [5572,5596]
===
match
---
simple_stmt [2208,2236]
simple_stmt [2198,2226]
===
match
---
atom_expr [6202,6233]
atom_expr [6188,6219]
===
match
---
name: item [5770,5774]
name: item [5756,5760]
===
match
---
atom_expr [4370,4424]
atom_expr [4360,4414]
===
match
---
trailer [1764,1800]
trailer [1754,1790]
===
match
---
annassign [3496,3530]
annassign [3486,3520]
===
match
---
trailer [3506,3523]
trailer [3496,3513]
===
match
---
name: record [4925,4931]
name: record [4915,4921]
===
match
---
operator: , [914,915]
operator: , [904,905]
===
match
---
name: TYPE_CHECKING [901,914]
name: TYPE_CHECKING [891,904]
===
match
---
name: redact [7097,7103]
name: redact [7005,7011]
===
match
---
trailer [8150,8155]
trailer [8148,8153]
===
match
---
name: __dict__ [4387,4395]
name: __dict__ [4377,4385]
===
match
---
name: str [6457,6460]
name: str [6443,6446]
===
match
---
operator: , [1771,1772]
operator: , [1761,1762]
===
match
---
operator: = [1754,1755]
operator: = [1744,1745]
===
match
---
operator: = [5880,5881]
operator: = [5866,5867]
===
match
---
trailer [3283,3291]
trailer [3273,3281]
===
match
---
tfpdef [5870,5879]
tfpdef [5856,5865]
===
match
---
operator: , [5313,5314]
operator: , [5303,5304]
===
match
---
arglist [8290,8297]
arglist [8288,8295]
===
match
---
name: item [6451,6455]
name: item [6437,6441]
===
match
---
funcdef [3718,4425]
funcdef [3708,4415]
===
match
---
suite [5750,5775]
suite [5736,5761]
===
match
---
name: isinstance [6962,6972]
name: isinstance [6948,6958]
===
match
---
name: io [6979,6981]
name: list [6965,6969]
===
match
---
for_stmt [8243,8299]
for_stmt [8241,8297]
===
match
---
simple_stmt [5203,5215]
simple_stmt [5193,5205]
===
match
---
trailer [8052,8058]
trailer [8050,8056]
===
match
---
trailer [2984,2993]
trailer [2974,2983]
===
match
---
name: secret [8196,8202]
name: secret [8194,8200]
===
match
---
name: tuple [5576,5581]
name: tuple [5566,5571]
===
match
---
return_stmt [3348,3358]
return_stmt [3338,3348]
===
match
---
string: "__SecretsMasker_filtered" [3583,3609]
string: "__SecretsMasker_filtered" [3573,3599]
===
match
---
except_clause [7186,7207]
except_clause [7184,7205]
===
match
---
suite [6177,7178]
suite [6163,7086]
===
match
---
operator: , [999,1000]
operator: , [989,990]
===
match
---
operator: } [1937,1938]
operator: } [1927,1928]
===
match
---
simple_stmt [1138,1172]
simple_stmt [1128,1162]
===
match
---
string: 'apikey' [1269,1277]
string: 'apikey' [1259,1267]
===
match
---
name: k [7835,7836]
name: k [7833,7834]
===
match
---
atom_expr [3686,3691]
atom_expr [3676,3681]
===
match
---
operator: } [6421,6422]
operator: } [6407,6408]
===
match
---
atom_expr [6482,6495]
atom_expr [6468,6481]
===
match
---
number: 1 [5015,5016]
number: 1 [5005,5006]
===
match
---
operator: , [7635,7636]
operator: , [7633,7634]
===
match
---
funcdef [1513,1968]
funcdef [1503,1958]
===
match
---
name: subval [5611,5617]
name: subval [5601,5607]
===
match
---
trailer [5014,5017]
trailer [5004,5007]
===
match
---
suite [7240,7528]
suite [7238,7526]
===
match
---
name: _redact_all [5224,5235]
name: _redact_all [5214,5225]
===
match
---
argument [7092,7130]
argument [7000,7038]
===
match
---
trailer [3267,3283]
trailer [3257,3273]
===
match
---
trailer [8160,8169]
trailer [8158,8167]
===
match
---
name: isinstance [6297,6307]
name: isinstance [6283,6293]
===
match
---
suite [7902,7926]
suite [7900,7924]
===
match
---
name: isinstance [5298,5308]
name: isinstance [5288,5298]
===
match
---
name: frozenset [1863,1872]
name: frozenset [1853,1862]
===
match
---
simple_stmt [1944,1968]
simple_stmt [1934,1958]
===
match
---
trailer [7861,7874]
trailer [7859,7872]
===
match
---
trailer [6307,6319]
trailer [6293,6305]
===
match
---
name: isinstance [5640,5650]
name: isinstance [5630,5640]
===
match
---
name: self [6355,6359]
name: self [6341,6345]
===
match
---
name: sensitive_variable_fields [1808,1833]
name: sensitive_variable_fields [1798,1823]
===
match
---
trailer [8090,8094]
trailer [8088,8092]
===
match
---
atom_expr [4999,5017]
atom_expr [4989,5007]
===
match
---
name: warning [7257,7264]
name: warning [7255,7262]
===
match
---
string: """Get comma-separated sensitive Variable Fields from airflow.cfg.""" [1555,1624]
string: """Get comma-separated sensitive Variable Fields from airflow.cfg.""" [1545,1614]
===
match
---
name: secret [2939,2945]
name: secret [2929,2935]
===
match
---
operator: , [3044,3045]
operator: , [3034,3035]
===
match
---
name: airflow [1634,1641]
name: airflow [1624,1631]
===
match
---
funcdef [3615,3692]
funcdef [3605,3682]
===
match
---
parameters [7594,7654]
parameters [7592,7652]
===
match
---
trailer [6916,6924]
trailer [6902,6910]
===
match
---
trailer [5586,5598]
trailer [5576,5588]
===
match
---
name: str [5876,5879]
name: str [5862,5865]
===
match
---
simple_stmt [7516,7528]
simple_stmt [7514,7526]
===
match
---
trailer [3381,3408]
trailer [3371,3398]
===
match
---
name: secret [2343,2349]
name: secret [2333,2339]
===
match
---
sync_comp_for [7112,7130]
sync_comp_for [7020,7038]
===
match
---
param [7601,7636]
param [7599,7634]
===
match
---
atom_expr [2967,3007]
atom_expr [2957,2997]
===
match
---
name: frozenset [1201,1210]
name: frozenset [1191,1200]
===
match
---
name: RuntimeError [3369,3381]
name: RuntimeError [3359,3371]
===
match
---
tfpdef [2379,2388]
tfpdef [2369,2378]
===
match
---
name: Exception [7193,7202]
name: Exception [7191,7200]
===
match
---
operator: , [6977,6978]
operator: , [6963,6964]
===
match
---
name: name [2379,2383]
name: name [2369,2373]
===
match
---
name: redact [3163,3169]
name: redact [3153,3159]
===
match
---
operator: , [5512,5513]
operator: , [5502,5503]
===
match
---
atom [8014,8059]
atom [8012,8057]
===
match
---
trailer [5128,5133]
trailer [5118,5123]
===
match
---
trailer [1161,1171]
trailer [1151,1161]
===
match
---
name: Union [7609,7614]
name: Union [7607,7612]
===
match
---
name: __init__ [3619,3627]
name: __init__ [3609,3617]
===
match
---
return_stmt [7007,7018]
return_stmt [7074,7085]
===
match
---
name: any [2251,2254]
name: any [2241,2244]
===
match
---
name: str [7870,7873]
name: str [7868,7871]
===
match
---
return_stmt [5203,5214]
return_stmt [5193,5204]
===
match
---
name: items [5406,5411]
name: items [5396,5401]
===
match
---
trailer [3763,3768]
trailer [3753,3758]
===
match
---
atom_expr [6962,6989]
atom_expr [6948,6970]
===
match
---
name: s [2255,2256]
name: s [2245,2246]
===
match
---
trailer [6450,6461]
trailer [6436,6447]
===
match
---
suite [1550,1968]
suite [1540,1958]
===
match
---
name: dict [7620,7624]
name: dict [7618,7622]
===
match
---
arglist [7282,7489]
arglist [7280,7487]
===
match
---
trailer [5158,5186]
trailer [5148,5176]
===
match
---
name: subval [6929,6935]
name: subval [6915,6921]
===
match
---
trailer [5598,5606]
trailer [5588,5596]
===
match
---
trailer [8195,8229]
trailer [8193,8227]
===
match
---
if_stmt [4791,4858]
if_stmt [4781,4848]
===
match
---
name: Optional [926,934]
name: Optional [916,924]
===
match
---
trailer [1760,1764]
trailer [1750,1754]
===
match
---
string: "Unable to redact %r, please report this via <https://github.com/apache/airflow/issues>. " [7282,7372]
string: "Unable to redact %r, please report this via <https://github.com/apache/airflow/issues>. " [7280,7370]
===
match
---
name: str [3764,3767]
name: str [3754,3757]
===
match
---
trailer [8138,8146]
trailer [8136,8144]
===
match
---
expr_stmt [3670,3691]
expr_stmt [3660,3681]
===
match
---
suite [5667,5737]
suite [5653,5723]
===
match
---
atom_expr [2159,2198]
atom_expr [2149,2188]
===
match
---
comparison [2255,2264]
comparison [2245,2254]
===
match
---
name: join [8151,8155]
name: join [8149,8153]
===
match
---
name: logging [3250,3257]
name: logging [3240,3247]
===
match
---
name: __init__ [3651,3659]
name: __init__ [3641,3649]
===
match
---
atom_expr [5352,5376]
atom_expr [5342,5366]
===
match
---
string: "RedactableItem" [5269,5285]
string: "RedactableItem" [5259,5275]
===
match
---
sync_comp_for [5607,5625]
sync_comp_for [5597,5615]
===
match
---
operator: , [5240,5241]
operator: , [5230,5231]
===
match
---
return_stmt [5680,5736]
return_stmt [5666,5722]
===
match
---
name: ALREADY_FILTERED_FLAG [3559,3580]
name: ALREADY_FILTERED_FLAG [3549,3570]
===
match
---
atom_expr [4475,4501]
atom_expr [4465,4491]
===
match
---
param [4447,4453]
param [4437,4443]
===
match
---
suite [5520,5627]
suite [5510,5617]
===
match
---
name: k [4890,4891]
name: k [4880,4881]
===
match
---
param [2000,2004]
param [1990,1994]
===
match
---
param [4441,4446]
param [4431,4436]
===
match
---
param [5846,5869]
param [5832,5855]
===
match
---
argument [4328,4343]
argument [4318,4333]
===
match
---
trailer [5356,5368]
trailer [5346,5358]
===
match
---
name: getLogRecordFactory [4060,4079]
name: getLogRecordFactory [4050,4069]
===
match
---
simple_stmt [5463,5476]
simple_stmt [5453,5466]
===
match
---
suite [6320,6423]
suite [6306,6409]
===
match
---
suite [3233,3409]
suite [3223,3399]
===
match
---
operator: , [939,940]
operator: , [929,930]
===
match
---
name: dict [6314,6318]
name: dict [6300,6304]
===
match
---
argument [6905,6943]
argument [6891,6929]
===
match
---
decorated [3697,4425]
decorated [3687,4415]
===
match
---
string: "RedactableItem" [5248,5264]
string: "RedactableItem" [5238,5254]
===
match
---
arglist [5500,5518]
arglist [5490,5508]
===
match
---
import_as_names [994,1016]
import_as_names [984,1006]
===
match
---
operator: , [3318,3319]
operator: , [3308,3309]
===
match
---
name: settings [2159,2167]
name: settings [2149,2157]
===
match
---
name: items [7793,7798]
name: items [7791,7796]
===
match
---
name: name [2208,2212]
name: name [2198,2202]
===
match
---
trailer [8124,8133]
trailer [8122,8131]
===
match
---
name: _secrets_masker [3196,3211]
name: _secrets_masker [3186,3201]
===
match
---
trailer [4771,4773]
trailer [4761,4763]
===
match
---
atom_expr [6258,6280]
atom_expr [6244,6266]
===
match
---
suite [6835,6945]
suite [6821,6931]
===
match
---
name: self [6905,6909]
name: self [6891,6895]
===
match
---
testlist_comp [5101,5133]
testlist_comp [5091,5123]
===
match
---
name: str [5445,5448]
name: str [5435,5438]
===
match
---
name: subval [5391,5397]
name: subval [5381,5387]
===
match
---
simple_stmt [3559,3610]
simple_stmt [3549,3600]
===
match
---
expr_stmt [1174,1412]
expr_stmt [1164,1402]
===
match
---
operator: , [4414,4415]
operator: , [4404,4405]
===
match
---
parameters [3020,3063]
parameters [3010,3053]
===
match
---
trailer [4208,4213]
trailer [4198,4203]
===
match
---
name: re [7948,7950]
name: re [7946,7948]
===
match
---
trailer [7091,7131]
trailer [6999,7039]
===
match
---
name: exc_info [5006,5014]
name: exc_info [4996,5004]
===
match
---
name: tuple [6899,6904]
name: tuple [6885,6890]
===
match
---
sync_comp_for [5377,5413]
sync_comp_for [5367,5403]
===
match
---
name: self [4895,4899]
name: self [4885,4889]
===
match
---
name: configuration [1642,1655]
name: configuration [1632,1645]
===
match
---
suite [8259,8299]
suite [8257,8297]
===
match
---
classdef [3411,8299]
classdef [3401,8297]
===
match
---
not_test [2935,2945]
not_test [2925,2935]
===
match
---
return_stmt [7516,7527]
return_stmt [7514,7525]
===
match
---
atom_expr [6409,6421]
atom_expr [6395,6407]
===
match
---
name: item [6275,6279]
name: item [6261,6265]
===
match
---
expr_stmt [4993,5017]
expr_stmt [4983,5007]
===
match
---
name: re [879,881]
name: re [869,871]
===
match
---
trailer [5581,5626]
trailer [5571,5616]
===
match
---
name: _secrets_masker [3145,3160]
name: _secrets_masker [3135,3150]
===
match
---
trailer [5149,5158]
trailer [5139,5148]
===
match
---
simple_stmt [857,872]
simple_stmt [847,862]
===
match
---
atom_expr [2251,2307]
atom_expr [2241,2297]
===
match
---
trailer [4511,4520]
trailer [4501,4510]
===
match
---
trailer [4479,4501]
trailer [4469,4491]
===
match
---
atom_expr [1144,1171]
atom_expr [1134,1161]
===
match
---
atom_expr [1756,1800]
atom_expr [1746,1790]
===
match
---
name: compile [8139,8146]
name: compile [8137,8144]
===
match
---
name: record [5143,5149]
name: record [5133,5139]
===
match
---
simple_stmt [2967,3008]
simple_stmt [2957,2998]
===
match
---
expr_stmt [1843,1939]
expr_stmt [1833,1929]
===
match
---
trailer [4899,4906]
trailer [4889,4896]
===
match
---
name: Iterable [8220,8228]
name: Iterable [8218,8226]
===
match
---
simple_stmt [7253,7504]
simple_stmt [7251,7502]
===
match
---
decorator [3185,3192]
decorator [3175,3182]
===
match
---
atom_expr [2351,2377]
atom_expr [2341,2367]
===
match
---
name: exc_info [4932,4940]
name: exc_info [4922,4930]
===
match
---
trailer [5308,5320]
trailer [5298,5310]
===
match
---
trailer [6732,6741]
trailer [6718,6727]
===
match
---
string: "funcname" [4333,4343]
string: "funcname" [4323,4333]
===
match
---
operator: , [1259,1260]
operator: , [1249,1250]
===
match
---
expr_stmt [1138,1171]
expr_stmt [1128,1161]
===
match
---
name: name [2000,2004]
name: name [1990,1994]
===
match
---
expr_stmt [8120,8171]
expr_stmt [8118,8169]
===
match
---
atom_expr [1692,1723]
atom_expr [1682,1713]
===
match
---
name: set [5514,5517]
name: set [5504,5507]
===
match
---
atom_expr [4280,4287]
atom_expr [4270,4277]
===
match
---
atom_expr [8077,8103]
atom_expr [8075,8101]
===
match
---
operator: , [7430,7431]
operator: , [7428,7429]
===
match
---
trailer [6741,6745]
trailer [6727,6731]
===
match
---
trailer [7822,7831]
trailer [7820,7829]
===
match
---
trailer [4715,4724]
trailer [4705,4714]
===
match
---
trailer [3438,3445]
trailer [3428,3435]
===
match
---
if_stmt [7733,8299]
if_stmt [7731,8297]
===
match
---
simple_stmt [957,1017]
simple_stmt [947,1007]
===
match
---
if_stmt [1805,1940]
if_stmt [1795,1930]
===
match
---
name: Iterable [2368,2376]
name: Iterable [2358,2366]
===
match
---
trailer [6366,6384]
trailer [6352,6370]
===
match
---
if_stmt [3301,3359]
if_stmt [3291,3349]
===
match
---
name: set [3686,3689]
name: set [3676,3679]
===
match
---
operator: , [4314,4315]
operator: , [4304,4305]
===
match
---
suite [2199,2308]
suite [2189,2298]
===
match
---
return_stmt [4687,4698]
return_stmt [4677,4688]
===
match
---
atom_expr [1110,1135]
atom_expr [1100,1125]
===
match
---
simple_stmt [6892,6945]
simple_stmt [6878,6931]
===
match
---
name: split [1927,1932]
name: split [1917,1922]
===
match
---
trailer [5368,5376]
trailer [5358,5366]
===
match
---
name: name [2150,2154]
name: name [2140,2144]
===
match
---
name: filter [4434,4440]
name: filter [4424,4430]
===
match
---
name: dict_key [6389,6397]
name: dict_key [6375,6383]
===
match
---
operator: @ [3697,3698]
operator: @ [3687,3688]
===
match
---
name: __dict__ [4881,4889]
name: __dict__ [4871,4879]
===
match
---
simple_stmt [2410,2740]
simple_stmt [2400,2730]
===
match
---
operator: -> [5266,5268]
operator: -> [5256,5258]
===
match
---
operator: } [1409,1410]
operator: } [1399,1400]
===
match
---
operator: , [8202,8203]
operator: , [8200,8201]
===
match
---
funcdef [2327,3008]
funcdef [2317,2998]
===
match
---
if_stmt [6479,6759]
if_stmt [6465,6745]
===
match
---
operator: -> [2397,2399]
operator: -> [2387,2389]
===
match
---
atom_expr [5489,5519]
atom_expr [5479,5509]
===
match
---
tfpdef [5846,5868]
tfpdef [5832,5854]
===
match
---
name: flt [3355,3358]
name: flt [3345,3348]
===
match
---
atom_expr [5576,5626]
atom_expr [5566,5616]
===
match
---
operator: = [1142,1143]
operator: = [1132,1133]
===
match
---
for_stmt [3239,3359]
for_stmt [3229,3349]
===
match
---
simple_stmt [3535,3554]
simple_stmt [3525,3544]
===
match
---
simple_stmt [7080,7132]
simple_stmt [6988,7040]
===
match
---
name: item [6939,6943]
name: item [6925,6929]
===
match
---
simple_stmt [6251,6281]
simple_stmt [6237,6267]
===
match
---
if_stmt [2895,2962]
if_stmt [2885,2952]
===
match
---
sync_comp_for [6385,6421]
sync_comp_for [6371,6407]
===
match
---
atom_expr [8185,8229]
atom_expr [8183,8227]
===
match
---
atom_expr [8027,8058]
atom_expr [8025,8056]
===
match
---
name: self [6482,6486]
name: self [6468,6472]
===
match
---
simple_stmt [5089,5135]
simple_stmt [5079,5125]
===
match
---
name: args [5129,5133]
name: args [5119,5123]
===
match
---
string: 'access_token' [1226,1240]
string: 'access_token' [1216,1230]
===
match
---
operator: , [4213,4214]
operator: , [4203,4204]
===
match
---
name: conf [1756,1760]
name: conf [1746,1750]
===
match
---
name: dict_key [6345,6353]
name: dict_key [6331,6339]
===
match
---
if_stmt [6294,7178]
if_stmt [6280,7086]
===
match
---
atom_expr [7948,7965]
atom_expr [7946,7963]
===
match
---
name: cached_property [1001,1016]
name: cached_property [991,1006]
===
match
---
trailer [6972,6989]
trailer [6958,6970]
===
match
---
atom_expr [6297,6319]
atom_expr [6283,6305]
===
match
---
name: logging [3431,3438]
name: logging [3421,3428]
===
match
---
name: self [5236,5240]
name: self [5226,5230]
===
match
---
if_stmt [2147,2308]
if_stmt [2137,2298]
===
match
---
if_stmt [4708,5135]
if_stmt [4698,5125]
===
match
---
tfpdef [7601,7635]
tfpdef [7599,7633]
===
match
---
name: airflow [962,969]
name: airflow [952,959]
===
match
---
simple_stmt [3089,3134]
simple_stmt [3079,3124]
===
match
---
expr_stmt [3559,3609]
expr_stmt [3549,3599]
===
match
---
dictorsetmaker [1226,1404]
dictorsetmaker [1216,1394]
===
match
---
name: dict_key [6375,6383]
name: dict_key [6361,6369]
===
match
---
operator: , [1240,1241]
operator: , [1230,1231]
===
match
---
and_test [4925,4975]
and_test [4915,4965]
===
match
---
dotted_name [1045,1066]
dotted_name [1035,1056]
===
match
---
suite [2006,2325]
suite [1996,2315]
===
match
---
atom_expr [7609,7635]
atom_expr [7607,7633]
===
match
---
trailer [5105,5112]
trailer [5095,5102]
===
match
---
arglist [6973,6988]
arglist [6959,6969]
===
match
---
name: isinstance [3304,3314]
name: isinstance [3294,3304]
===
match
---
name: tuple [6822,6827]
name: tuple [6808,6813]
===
match
---
atom_expr [8120,8133]
atom_expr [8118,8131]
===
match
---
name: dict_key [5342,5350]
name: dict_key [5332,5340]
===
match
---
string: 'api_key' [1250,1259]
string: 'api_key' [1240,1249]
===
match
---
suite [5321,5415]
suite [5311,5405]
===
match
---
name: name [2260,2264]
name: name [2250,2254]
===
match
---
name: item [6409,6413]
name: item [6395,6399]
===
match
---
operator: , [4187,4188]
operator: , [4177,4178]
===
match
---
operator: , [6312,6313]
operator: , [6298,6299]
===
match
---
atom_expr [7786,7800]
atom_expr [7784,7798]
===
match
---
simple_stmt [7938,7966]
simple_stmt [7936,7964]
===
match
---
name: replacer [4716,4724]
name: replacer [4706,4714]
===
match
---
name: pattern [7981,7988]
name: pattern [7979,7986]
===
match
---
trailer [2225,2227]
trailer [2215,2217]
===
match
---
operator: , [6373,6374]
operator: , [6359,6360]
===
match
---
name: str [2385,2388]
name: str [2375,2378]
===
match
---
operator: , [6827,6828]
operator: , [6813,6814]
===
match
---
name: str [7482,7485]
name: str [7480,7483]
===
match
---
name: get_sensitive_variables_fields [2274,2304]
name: get_sensitive_variables_fields [2264,2294]
===
match
---
trailer [1716,1721]
trailer [1706,1711]
===
match
---
string: 'airflow.task' [3268,3282]
string: 'airflow.task' [3258,3272]
===
match
---
string: "No SecretsMasker found!" [3382,3407]
string: "No SecretsMasker found!" [3372,3397]
===
match
---
name: sensitive_variable_fields [1728,1753]
name: sensitive_variable_fields [1718,1743]
===
match
---
trailer [3648,3650]
trailer [3638,3640]
===
match
---
simple_stmt [1040,1088]
simple_stmt [1030,1078]
===
match
---
suite [5908,7528]
suite [5894,7526]
===
match
---
name: isinstance [6440,6450]
name: isinstance [6426,6436]
===
match
---
name: TypeVar [1110,1117]
name: TypeVar [1100,1107]
===
match
---
name: dict_key [5381,5389]
name: dict_key [5371,5379]
===
match
---
trailer [4889,4892]
trailer [4879,4882]
===
match
---
atom_expr [5298,5320]
atom_expr [5288,5310]
===
match
---
name: dict [7755,7759]
name: dict [7753,7757]
===
match
---
name: v [7781,7782]
name: v [7779,7780]
===
match
---
trailer [1151,1161]
trailer [1141,1151]
===
match
---
name: TYPE_CHECKING [1021,1034]
name: TYPE_CHECKING [1011,1024]
===
match
---
name: __dict__ [5150,5158]
name: __dict__ [5140,5148]
===
match
---
atom_expr [7087,7131]
atom_expr [6995,7039]
===
match
---
name: _redact_all [5587,5598]
name: _redact_all [5577,5588]
===
match
---
simple_stmt [4363,4425]
simple_stmt [4353,4415]
===
match
---
string: 'RedactableItem' [1118,1134]
string: 'RedactableItem' [1108,1124]
===
match
---
operator: , [1385,1386]
operator: , [1375,1376]
===
match
---
string: 'args' [4416,4422]
string: 'args' [4406,4412]
===
match
---
operator: -> [4455,4457]
operator: -> [4445,4447]
===
match
---
atom_expr [3643,3661]
atom_expr [3633,3651]
===
match
---
trailer [1885,1887]
trailer [1875,1877]
===
match
---
atom_expr [1901,1937]
atom_expr [1891,1927]
===
match
---
name: escape [7951,7957]
name: escape [7949,7955]
===
match
---
atom_expr [4505,4520]
atom_expr [4495,4510]
===
match
---
name: k [4742,4743]
name: k [4732,4733]
===
match
---
atom_expr [5401,5413]
atom_expr [5391,5403]
===
match
---
name: item [5309,5313]
name: item [5299,5303]
===
match
---
trailer [8289,8298]
trailer [8287,8296]
===
match
---
return_stmt [6251,6280]
return_stmt [6237,6266]
===
match
---
param [3046,3062]
param [3036,3052]
===
match
---
name: log [1138,1141]
name: log [1128,1131]
===
match
---
name: replacer [6733,6741]
name: replacer [6719,6727]
===
match
---
simple_stmt [1728,1801]
simple_stmt [1718,1791]
===
match
---
string: '|' [8147,8150]
string: '|' [8145,8148]
===
match
---
name: bool [4458,4462]
name: bool [4448,4452]
===
match
---
name: Union [2351,2356]
name: Union [2341,2346]
===
match
---
operator: , [2366,2367]
operator: , [2356,2357]
===
match
---
name: patterns [8001,8009]
name: patterns [7999,8007]
===
match
---
return_stmt [1944,1967]
return_stmt [1934,1957]
===
match
---
operator: , [3175,3176]
operator: , [3165,3166]
===
match
---
operator: , [3000,3001]
operator: , [2990,2991]
===
match
---
suite [5286,5775]
suite [5276,5761]
===
match
---
name: redact [4900,4906]
name: redact [4890,4896]
===
match
---
operator: = [7647,7648]
operator: = [7645,7646]
===
match
---
operator: = [3581,3582]
operator: = [3571,3572]
===
match
---
arglist [3315,3333]
arglist [3305,3323]
===
match
---
name: set [6829,6832]
name: set [6815,6818]
===
match
---
trailer [6486,6495]
trailer [6472,6481]
===
match
---
string: 'passphrase' [1312,1324]
string: 'passphrase' [1302,1314]
===
match
---
operator: -> [5888,5890]
operator: -> [5874,5876]
===
match
---
name: Set [3545,3548]
name: Set [3535,3538]
===
match
---
trailer [6745,6758]
trailer [6731,6744]
===
match
---
operator: -> [3064,3066]
operator: -> [3054,3056]
===
match
---
atom_expr [3145,3182]
atom_expr [3135,3172]
===
match
---
name: v [5113,5114]
name: v [5103,5104]
===
match
---
name: Iterable [5657,5665]
name: list [5647,5651]
===
match
---
name: add_mask [8281,8289]
name: add_mask [8279,8287]
===
match
---
funcdef [5829,7528]
funcdef [5815,7526]
===
match
---
string: 'secret' [1395,1403]
string: 'secret' [1385,1393]
===
match
---
decorator [3697,3714]
decorator [3687,3704]
===
match
---
suite [8060,8172]
suite [8058,8170]
===
match
---
name: logging [864,871]
name: logging [854,861]
===
match
---
atom_expr [5692,5716]
atom_expr [5678,5702]
===
match
---
name: name [6193,6197]
name: name [6179,6183]
===
match
---
exprlist [7778,7782]
exprlist [7776,7780]
===
match
---
and_test [7981,8059]
and_test [7979,8057]
===
match
---
atom_expr [1863,1939]
atom_expr [1853,1929]
===
match
---
string: 'authorization' [1287,1302]
string: 'authorization' [1277,1292]
===
match
---
operator: , [6751,6752]
operator: , [6737,6738]
===
match
---
operator: , [7408,7409]
operator: , [7406,7407]
===
match
---
comp_op [4964,4970]
comp_op [4954,4960]
===
match
---
suite [3634,3692]
suite [3624,3682]
===
match
---
name: patterns [3535,3543]
name: patterns [3525,3533]
===
match
---
name: dict [5315,5319]
name: dict [5305,5309]
===
match
---
name: self [5692,5696]
name: self [5678,5682]
===
match
---
operator: , [7753,7754]
operator: , [7751,7752]
===
match
---
trailer [8155,8170]
trailer [8153,8168]
===
match
---
name: item [5401,5405]
name: item [5391,5395]
===
match
---
decorator [1506,1513]
decorator [1496,1503]
===
match
---
trailer [4081,4354]
trailer [4071,4344]
===
match
---
atom [5506,5518]
atom [5496,5508]
===
match
---
trailer [4960,4963]
trailer [4950,4953]
===
match
---
atom_expr [3431,3445]
atom_expr [3421,3435]
===
match
---
atom_expr [1201,1412]
atom_expr [1191,1402]
===
match
---
trailer [7614,7635]
trailer [7612,7633]
===
match
---
name: str [7643,7646]
name: str [7641,7644]
===
match
---
name: DEFAULT_SENSITIVE_FIELDS [1692,1716]
name: DEFAULT_SENSITIVE_FIELDS [1682,1706]
===
match
---
not_test [7891,7901]
not_test [7889,7899]
===
match
---
name: ALREADY_FILTERED_FLAG [4480,4501]
name: ALREADY_FILTERED_FLAG [4470,4491]
===
match
---
name: cache [3186,3191]
name: cache [3176,3181]
===
match
---
name: item [6308,6312]
name: item [6294,6298]
===
match
---
trailer [2993,3007]
trailer [2983,2997]
===
match
---
operator: @ [3185,3186]
operator: @ [3175,3176]
===
match
---
name: subval [5721,5727]
name: subval [5707,5713]
===
match
---
atom_expr [8276,8298]
atom_expr [8274,8296]
===
match
---
and_test [6193,6233]
and_test [6179,6219]
===
match
---
string: 'core' [1765,1771]
string: 'core' [1755,1761]
===
match
---
return_stmt [2312,2324]
return_stmt [2302,2314]
===
match
---
atom_expr [3545,3553]
atom_expr [3535,3543]
===
match
---
atom_expr [5089,5097]
atom_expr [5079,5087]
===
match
---
name: strip [1880,1885]
name: strip [1870,1875]
===
match
---
name: isinstance [8185,8195]
name: isinstance [8183,8193]
===
match
---
name: field [1892,1897]
name: field [1882,1887]
===
match
---
atom_expr [3304,3334]
atom_expr [3294,3324]
===
match
---
trailer [7950,7957]
trailer [7948,7955]
===
match
---
atom_expr [7448,7464]
atom_expr [7446,7462]
===
match
---
suite [4774,4910]
suite [4764,4900]
===
match
---
atom_expr [7851,7874]
atom_expr [7849,7872]
===
match
---
if_stmt [6190,6281]
if_stmt [6176,6267]
===
match
---
name: item [6782,6786]
name: item [6768,6772]
===
match
---
comparison [4794,4827]
comparison [4784,4817]
===
match
---
funcdef [7582,8299]
funcdef [7580,8297]
===
match
---
name: subval [6399,6405]
name: subval [6385,6391]
===
match
---
name: _record_attrs_to_ignore [4804,4827]
name: _record_attrs_to_ignore [4794,4817]
===
match
---
number: 1 [4249,4250]
number: 1 [4239,4240]
===
match
---
trailer [6227,6233]
trailer [6213,6219]
===
match
---
operator: , [7833,7834]
operator: , [7831,7832]
===
match
---
trailer [6814,6834]
trailer [6800,6820]
===
match
---
name: flt [3315,3318]
name: flt [3305,3308]
===
match
---
name: MASK_SECRETS_IN_LOGS [2911,2931]
name: MASK_SECRETS_IN_LOGS [2901,2921]
===
match
---
atom_expr [6728,6758]
atom_expr [6714,6744]
===
match
---
operator: , [4287,4288]
operator: , [4277,4278]
===
match
---
param [3021,3045]
param [3011,3035]
===
match
---
string: """         Redact an any secrets found in ``item``, if it is a string.          If ``name`` is given, and it's a "sensitive" name (see         :func:`should_hide_value_for_key`) then all string values in the item         is redacted.          """ [5917,6164]
string: """         Redact an any secrets found in ``item``, if it is a string.          If ``name`` is given, and it's a "sensitive" name (see         :func:`should_hide_value_for_key`) then all string values in the item         is redacted.          """ [5903,6150]
===
match
---
funcdef [3192,3409]
funcdef [3182,3399]
===
match
---
import_as_names [901,955]
import_as_names [891,945]
===
match
---
simple_stmt [1174,1413]
simple_stmt [1164,1403]
===
match
---
operator: { [4408,4409]
operator: { [4398,4399]
===
match
---
trailer [4931,4940]
trailer [4921,4930]
===
match
---
simple_stmt [1555,1625]
simple_stmt [1545,1615]
===
match
---
comparison [4945,4975]
comparison [4935,4965]
===
match
---
name: ALREADY_FILTERED_FLAG [5164,5185]
name: ALREADY_FILTERED_FLAG [5154,5175]
===
match
---
name: isinstance [5428,5438]
name: isinstance [5418,5428]
===
match
---
name: lower [2228,2233]
name: lower [2218,2223]
===
match
---
string: 'sensitive_var_conn_names' [1773,1799]
string: 'sensitive_var_conn_names' [1763,1789]
===
match
---
simple_stmt [2312,2325]
simple_stmt [2302,2315]
===
match
---
string: "RedactableItem" [3028,3044]
string: "RedactableItem" [3018,3034]
===
match
---
string: '***' [5470,5475]
string: '***' [5460,5465]
===
match
---
name: _redact_all [6263,6274]
name: _redact_all [6249,6260]
===
match
---
simple_stmt [3488,3531]
simple_stmt [3478,3521]
===
match
---
name: _redact_all [5697,5708]
name: _redact_all [5683,5694]
===
match
---
strings [7282,7408]
strings [7280,7406]
===
match
---
suite [1035,1136]
suite [1025,1126]
===
match
---
arglist [6746,6757]
arglist [6732,6743]
===
match
---
operator: , [924,925]
operator: , [914,915]
===
match
---
comparison [4475,4520]
comparison [4465,4510]
===
match
---
trailer [4803,4827]
trailer [4793,4817]
===
match
---
parameters [5235,5265]
parameters [5225,5255]
===
match
---
import_from [2113,2141]
import_from [2103,2131]
===
match
---
name: name [5870,5874]
name: name [5856,5860]
===
match
---
name: difference [4397,4407]
name: difference [4387,4397]
===
match
---
operator: { [5341,5342]
operator: { [5331,5332]
===
match
---
name: v [8290,8291]
name: v [8288,8289]
===
match
---
simple_stmt [1843,1940]
simple_stmt [1833,1930]
===
match
---
subscriptlist [7615,7634]
subscriptlist [7613,7632]
===
match
---
name: self [8120,8124]
name: self [8118,8122]
===
match
---
simple_stmt [4874,4910]
simple_stmt [4864,4900]
===
match
---
operator: , [4343,4344]
operator: , [4333,4334]
===
match
---
funcdef [1970,2325]
funcdef [1960,2315]
===
match
---
name: k [4794,4795]
name: k [4784,4785]
===
match
---
atom_expr [5428,5449]
atom_expr [5418,5439]
===
match
---
comparison [7981,8009]
comparison [7979,8007]
===
match
---
name: HIDE_SENSITIVE_VAR_CONN_FIELDS [2168,2198]
name: HIDE_SENSITIVE_VAR_CONN_FIELDS [2158,2188]
===
match
---
tfpdef [5242,5264]
tfpdef [5232,5254]
===
match
---
trailer [3314,3334]
trailer [3304,3324]
===
match
---
name: dict [2362,2366]
name: dict [2352,2356]
===
match
---
for_stmt [7774,7838]
for_stmt [7772,7836]
===
match
---
operator: , [7624,7625]
operator: , [7622,7623]
===
match
---
name: secret [7895,7901]
name: secret [7893,7899]
===
match
---
trailer [2910,2931]
trailer [2900,2921]
===
match
---
funcdef [4430,5215]
funcdef [4420,5205]
===
match
---
subscriptlist [2357,2376]
subscriptlist [2347,2366]
===
match
---
name: exc_info [4301,4309]
name: exc_info [4291,4299]
===
match
---
expr_stmt [3488,3530]
expr_stmt [3478,3520]
===
match
---
exprlist [5381,5397]
exprlist [5371,5387]
===
match
---
simple_stmt [2244,2308]
simple_stmt [2234,2298]
===
match
---
suite [7063,7132]
suite [6971,7040]
===
match
---
operator: = [3684,3685]
operator: = [3674,3675]
===
match
---
name: secret [7601,7607]
name: secret [7599,7605]
===
match
---
name: mask_secret [2331,2342]
name: mask_secret [2321,2332]
===
match
---
name: airflow [2118,2125]
name: airflow [2108,2115]
===
match
---
name: self [4799,4803]
name: self [4789,4793]
===
match
---
name: strip [2220,2225]
name: strip [2210,2215]
===
match
---
operator: = [4050,4051]
operator: = [4040,4041]
===
match
---
atom_expr [4711,4724]
atom_expr [4701,4714]
===
match
---
atom_expr [5640,5666]
atom_expr [5630,5652]
===
match
---
name: exc_info [4952,4960]
name: exc_info [4942,4950]
===
match
---
name: isinstance [5489,5499]
name: isinstance [5479,5489]
===
match
---
operator: = [3524,3525]
operator: = [3514,3515]
===
match
---
name: Filter [3439,3445]
name: Filter [3429,3435]
===
match
---
name: SecretsMasker [3417,3430]
name: SecretsMasker [3407,3420]
===
match
---
simple_stmt [3452,3483]
simple_stmt [3442,3473]
===
match
---
name: name [3046,3050]
name: name [3036,3040]
===
match
---
operator: , [7618,7619]
operator: , [7616,7617]
===
match
---
return_stmt [3138,3182]
return_stmt [3128,3172]
===
match
---
name: subval [5599,5605]
name: subval [5589,5595]
===
match
---
name: collections [835,846]
name: collections [835,846]
===
match
---
trailer [4379,4396]
trailer [4369,4386]
===
match
---
name: replacer [8125,8133]
name: replacer [8123,8131]
===
match
---
operator: = [1199,1200]
operator: = [1189,1190]
===
match
---
parameters [2342,2396]
parameters [2332,2386]
===
match
---
name: collections [8204,8215]
name: collections [8202,8213]
===
match
---
name: secret [2994,3000]
name: secret [2984,2990]
===
match
---
trailer [8280,8289]
trailer [8278,8287]
===
match
---
operator: -> [3214,3216]
operator: -> [3204,3206]
===
match
---
return_stmt [6775,6786]
return_stmt [6761,6772]
===
match
---
name: re [8136,8138]
name: re [8134,8136]
===
match
---
number: 1 [4961,4962]
number: 1 [4951,4952]
===
match
---
trailer [7831,7837]
trailer [7829,7835]
===
match
---
name: __file__ [4227,4235]
name: __file__ [4217,4225]
===
match
---
trailer [8146,8171]
trailer [8144,8169]
===
match
---
atom_expr [4750,4773]
atom_expr [4740,4763]
===
match
---
name: record [4999,5005]
name: record [4989,4995]
===
match
---
name: self [7595,7599]
name: self [7593,7597]
===
match
---
trailer [7455,7464]
trailer [7453,7462]
===
match
---
name: item [6973,6977]
name: item [6959,6963]
===
match
---
trailer [7485,7488]
trailer [7483,7486]
===
match
---
operator: = [4309,4310]
operator: = [4299,4300]
===
match
---
name: str [3549,3552]
name: str [3539,3542]
===
match
---
name: settings [2133,2141]
name: settings [2123,2131]
===
match
---
name: record [4505,4511]
name: record [4495,4501]
===
match
---
name: self [5101,5105]
name: self [5091,5095]
===
match
---
sync_comp_for [5717,5735]
sync_comp_for [5703,5721]
===
match
---
return_stmt [7080,7131]
return_stmt [6988,7039]
===
match
---
operator: = [5187,5188]
operator: = [5177,5178]
===
match
---
expr_stmt [1093,1135]
expr_stmt [1083,1125]
===
match
---
trailer [4079,4081]
trailer [4069,4071]
===
match
---
operator: -> [3752,3754]
operator: -> [3742,3744]
===
match
---
name: add_mask [7586,7594]
name: add_mask [7584,7592]
===
match
---
suite [3447,8299]
suite [3437,8297]
===
match
---
operator: |= [1860,1862]
operator: |= [1850,1852]
===
match
---
trailer [5438,5449]
trailer [5428,5439]
===
match
---
name: self [5352,5356]
name: self [5342,5346]
===
match
---
operator: = [2213,2214]
operator: = [2203,2204]
===
match
---
name: should_hide_value_for_key [8027,8052]
name: should_hide_value_for_key [8025,8050]
===
match
---
tfpdef [3021,3044]
tfpdef [3011,3034]
===
match
---
name: name [8293,8297]
name: name [8291,8295]
===
match
---
import_name [857,871]
import_name [847,861]
===
match
---
atom [6821,6833]
atom [6807,6819]
===
match
---
operator: , [7464,7465]
operator: , [7462,7463]
===
match
---
trailer [5112,5115]
trailer [5102,5105]
===
match
---
suite [6990,7019]
suite [7057,7086]
===
match
---
operator: = [1108,1109]
operator: = [1098,1099]
===
match
---
trailer [4765,4771]
trailer [4755,4761]
===
match
---
arglist [4184,4344]
arglist [4174,4334]
===
match
---
name: isinstance [7736,7746]
name: isinstance [7734,7744]
===
match
---
name: name [8019,8023]
name: name [8017,8021]
===
match
---
simple_stmt [1673,1724]
simple_stmt [1663,1714]
===
match
---
suite [3084,3183]
suite [3074,3173]
===
match
---
trailer [7264,7503]
trailer [7262,7501]
===
match
---
param [3628,3632]
param [3618,3622]
===
match
---
trailer [8219,8228]
trailer [8217,8226]
===
match
---
operator: = [1690,1691]
operator: = [1680,1681]
===
match
---
trailer [2982,2984]
trailer [2972,2974]
===
match
---
operator: { [1873,1874]
operator: { [1863,1864]
===
match
---
name: airflow [1045,1052]
name: airflow [1035,1042]
===
match
---
atom [1873,1938]
atom [1863,1928]
===
match
---
name: exc [5125,5128]
name: exc [5115,5118]
===
match
---
name: self [8077,8081]
name: self [8075,8079]
===
match
---
name: item [6815,6819]
name: item [6801,6805]
===
match
---
simple_stmt [5763,5775]
simple_stmt [5749,5761]
===
match
---
expr_stmt [7938,7965]
expr_stmt [7936,7963]
===
match
---
trailer [2219,2225]
trailer [2209,2215]
===
match
---
trailer [3689,3691]
trailer [3679,3681]
===
match
---
name: args [5093,5097]
name: args [5083,5087]
===
match
---
name: name [6228,6232]
name: name [6214,6218]
===
match
---
sync_comp_for [5116,5133]
sync_comp_for [5106,5123]
===
match
---
trailer [2304,2306]
trailer [2294,2296]
===
match
---
name: items [4766,4771]
name: items [4756,4761]
===
match
---
atom_expr [7818,7837]
atom_expr [7816,7835]
===
match
---
simple_stmt [7664,7725]
simple_stmt [7662,7723]
===
match
---
name: logging [4052,4059]
name: logging [4042,4049]
===
match
---
name: item [7523,7527]
name: item [7521,7525]
===
match
---
name: name [8053,8057]
name: name [8051,8055]
===
match
---
atom_expr [8147,8170]
atom_expr [8145,8168]
===
match
---
name: self [8156,8160]
name: self [8154,8158]
===
match
---
string: 'passwd' [1334,1342]
string: 'passwd' [1324,1332]
===
match
---
trailer [7746,7760]
trailer [7744,7758]
===
match
---
trailer [4756,4765]
trailer [4746,4755]
===
match
---
name: item [7126,7130]
name: item [7034,7038]
===
match
---
name: tuple [4280,4285]
name: tuple [4270,4275]
===
match
---
name: redact [5106,5112]
name: redact [5096,5102]
===
match
---
atom_expr [5125,5133]
atom_expr [5115,5123]
===
match
---
simple_stmt [4993,5018]
simple_stmt [4983,5008]
===
match
---
trailer [2233,2235]
trailer [2223,2225]
===
match
---
name: cached_property [3698,3713]
name: cached_property [3688,3703]
===
match
---
simple_stmt [3138,3183]
simple_stmt [3128,3173]
===
match
---
trailer [5092,5097]
trailer [5082,5087]
===
match
---
parameters [3745,3751]
parameters [3735,3741]
===
match
---
trailer [8000,8009]
trailer [7998,8007]
===
match
---
name: subval [5709,5715]
name: subval [5695,5701]
===
match
---
string: "Error was: %s: %s" [7389,7408]
string: "Error was: %s: %s" [7387,7406]
===
match
---
trailer [5691,5736]
trailer [5677,5722]
===
match
---
name: patterns [8082,8090]
name: patterns [8080,8088]
===
match
---
param [2379,2395]
param [2369,2385]
===
match
---
import_from [1629,1667]
import_from [1619,1657]
===
match
---
name: item [5500,5504]
name: item [5490,5494]
===
match
---
trailer [7798,7800]
trailer [7796,7798]
===
match
---
param [2343,2378]
param [2333,2368]
===
match
---
trailer [6359,6366]
trailer [6345,6352]
===
match
---
simple_stmt [7007,7019]
simple_stmt [7074,7086]
===
match
---
name: isinstance [7851,7861]
name: isinstance [7849,7859]
===
match
---
atom_expr [5159,5185]
atom_expr [5149,5175]
===
match
---
name: record [4945,4951]
name: record [4935,4941]
===
match
---
atom [4408,4423]
atom [4398,4413]
===
match
---
atom_expr [6804,6834]
atom_expr [6790,6820]
===
match
---
atom_expr [6899,6944]
atom_expr [6885,6930]
===
match
---
string: ',' [1933,1936]
string: ',' [1923,1926]
===
match
---
name: e [7206,7207]
name: e [7204,7205]
===
match
---
arglist [2994,3006]
arglist [2984,2996]
===
match
---
import_from [957,1016]
import_from [947,1006]
===
match
---
name: Union [950,955]
name: Union [940,945]
===
match
---
arglist [1765,1799]
arglist [1755,1789]
===
match
---
operator: , [4266,4267]
operator: , [4256,4257]
===
match
---
operator: , [5443,5444]
operator: , [5433,5434]
===
match
---
return_stmt [5334,5414]
return_stmt [5324,5404]
===
match
---
comp_op [7989,7995]
comp_op [7987,7993]
===
match
---
name: _redact_all [5357,5368]
name: _redact_all [5347,5358]
===
match
---
operator: , [5504,5505]
operator: , [5494,5495]
===
match
---
sync_comp_for [2265,2306]
sync_comp_for [2255,2296]
===
match
---
simple_stmt [5143,5194]
simple_stmt [5133,5184]
===
match
---
tfpdef [3046,3055]
tfpdef [3036,3045]
===
match
---
suite [7761,7838]
suite [7759,7836]
===
match
---
string: """Redact any secrets found in ``value``.""" [3089,3133]
string: """Redact any secrets found in ``value``.""" [3079,3123]
===
match
---
atom_expr [5687,5736]
atom_expr [5673,5722]
===
match
---
suite [3292,3359]
suite [3282,3349]
===
match
---
atom_expr [7736,7760]
atom_expr [7734,7758]
===
match
---
name: k [7778,7779]
name: k [7776,7777]
===
match
---
name: secret [7958,7964]
name: secret [7956,7962]
===
match
---
name: redact [6360,6366]
name: redact [6346,6352]
===
match
---
atom_expr [3670,3683]
atom_expr [3660,3673]
===
match
---
trailer [7792,7798]
trailer [7790,7796]
===
match
---
arglist [6815,6833]
arglist [6801,6819]
===
match
---
name: record [4380,4386]
name: record [4370,4376]
===
match
---
operator: { [1216,1217]
operator: { [1206,1207]
===
match
---
trailer [6413,6419]
trailer [6399,6405]
===
match
---
suite [4725,5135]
suite [4715,5125]
===
match
---
string: """Should the value for this given name (Variable name, or key in conn.extra_dejson) be hidden""" [2011,2108]
string: """Should the value for this given name (Variable name, or key in conn.extra_dejson) be hidden""" [2001,2098]
===
match
---
name: _record_attrs_to_ignore [3722,3745]
name: _record_attrs_to_ignore [3712,3735]
===
match
---
trailer [2167,2198]
trailer [2157,2188]
===
match
---
name: airflow [2768,2775]
name: airflow [2758,2765]
===
match
---
simple_stmt [3643,3662]
simple_stmt [3633,3652]
===
match
---
string: 'password' [1352,1362]
string: 'password' [1342,1352]
===
match
---
name: Set [936,939]
name: Set [926,929]
===
match
---
name: getLogger [1152,1161]
name: getLogger [1142,1151]
===
match
---
trailer [7452,7455]
trailer [7450,7453]
===
match
---
exprlist [6389,6405]
exprlist [6375,6391]
===
match
---
operator: , [1277,1278]
operator: , [1267,1268]
===
match
---
atom_expr [2215,2235]
atom_expr [2205,2225]
===
match
---
name: __name__ [7456,7464]
name: __name__ [7454,7462]
===
match
---
operator: { [6344,6345]
operator: { [6330,6331]
===
match
---
name: item [5731,5735]
name: item [5717,5721]
===
match
---
suite [2405,3008]
suite [2395,2998]
===
match
---
arglist [5309,5319]
arglist [5299,5309]
===
match
---
param [7595,7600]
param [7593,7598]
===
match
---
name: __name__ [1162,1170]
name: __name__ [1152,1160]
===
match
---
name: value [3021,3026]
name: value [3011,3016]
===
match
---
simple_stmt [2113,2142]
simple_stmt [2103,2132]
===
match
---
name: list [7087,7091]
name: list [6995,6999]
===
match
---
name: self [4711,4715]
name: self [4701,4705]
===
match
---
suite [4521,4699]
suite [4511,4689]
===
match
---
name: e [7486,7487]
name: e [7484,7485]
===
match
---
expr_stmt [4874,4909]
expr_stmt [4864,4899]
===
match
---
operator: , [1302,1303]
operator: , [1292,1293]
===
match
---
name: self [3746,3750]
name: self [3736,3740]
===
match
---
operator: , [4235,4236]
operator: , [4225,4226]
===
match
---
atom_expr [8156,8169]
atom_expr [8154,8167]
===
match
---
name: type [7448,7452]
name: type [7446,7450]
===
match
---
trailer [1879,1885]
trailer [1869,1875]
===
match
---
name: subval [7104,7110]
name: subval [7012,7018]
===
match
---
name: sensitive_fields [1673,1689]
name: sensitive_fields [1663,1679]
===
match
---
trailer [5696,5708]
trailer [5682,5694]
===
match
---
name: items [6414,6419]
name: items [6400,6405]
===
match
---
name: get_sensitive_variables_fields [1517,1547]
name: get_sensitive_variables_fields [1507,1537]
===
match
---
or_test [2898,2945]
or_test [2888,2935]
===
match
---
name: getLogger [3258,3267]
name: getLogger [3248,3257]
===
match
---
not_test [2898,2931]
not_test [2888,2921]
===
match
---
atom_expr [8204,8228]
atom_expr [8202,8226]
===
match
---
simple_stmt [8077,8104]
simple_stmt [8075,8102]
===
match
---
atom_expr [3369,3408]
atom_expr [3359,3398]
===
match
---
trailer [3160,3162]
trailer [3150,3152]
===
match
---
name: logging [4201,4208]
name: logging [4191,4198]
===
match
---
name: func [4328,4332]
name: func [4318,4322]
===
match
---
parameters [3627,3633]
parameters [3617,3623]
===
match
---
suite [3335,3359]
suite [3325,3349]
===
match
---
suite [2946,2962]
suite [2936,2952]
===
match
---
name: RePatternType [1074,1087]
name: RePatternType [1064,1077]
===
match
---
import_name [872,881]
import_name [862,871]
===
match
---
name: Iterable [7626,7634]
name: Iterable [7624,7632]
===
match
---
name: item [5242,5246]
name: item [5232,5236]
===
match
---
trailer [8094,8103]
trailer [8092,8101]
===
match
---
string: "x" [4184,4187]
string: "x" [4174,4177]
===
match
---
name: should_hide_value_for_key [6202,6227]
name: should_hide_value_for_key [6188,6213]
===
match
---
name: self [4441,4445]
name: self [4431,4435]
===
match
---
name: record [4043,4049]
name: record [4033,4039]
===
match
---
suite [7875,8172]
suite [7873,8170]
===
match
---
name: SecretsMasker [3320,3333]
name: SecretsMasker [3310,3323]
===
match
---
if_stmt [5295,5775]
if_stmt [5285,5761]
===
match
---
trailer [4059,4079]
trailer [4049,4069]
===
match
---
trailer [8081,8090]
trailer [8079,8088]
===
match
---
name: Iterable [3755,3763]
name: Iterable [3745,3753]
===
match
---
simple_stmt [2763,2792]
simple_stmt [2753,2782]
===
match
---
operator: } [5413,5414]
operator: } [5403,5404]
===
insert-tree
---
simple_stmt [785,828]
    string: """Mask sensitive information from logs""" [785,827]
to
file_input [785,8299]
at 0
===
insert-tree
---
simple_stmt [1403,1494]
    string: """Names of fields (Connection extra, Variable key name etc.) that are deemed sensitive""" [1403,1493]
to
file_input [785,8299]
at 11
===
update-node
---
name: Iterable [5657,5665]
replace Iterable by list
===
update-node
---
name: io [6979,6981]
replace io by list
===
move-tree
---
name: io [6979,6981]
to
arglist [6973,6988]
at 2
===
delete-tree
---
simple_stmt [785,828]
    string: """Mask sensitive information from logs""" [785,827]
===
delete-tree
---
simple_stmt [847,857]
    import_name [847,856]
        name: io [854,856]
===
delete-tree
---
simple_stmt [1413,1504]
    string: """Names of fields (Connection extra, Variable key name etc.) that are deemed sensitive""" [1413,1503]
===
delete-node
---
atom_expr [6979,6988]
===
===
delete-tree
---
atom_expr [7036,7062]
    name: isinstance [7036,7046]
    trailer [7046,7062]
        arglist [7047,7061]
            name: item [7047,7051]
            operator: , [7051,7052]
            name: Iterable [7053,7061]
===
delete-tree
---
suite [7149,7178]
    simple_stmt [7166,7178]
        return_stmt [7166,7177]
            name: item [7173,7177]
