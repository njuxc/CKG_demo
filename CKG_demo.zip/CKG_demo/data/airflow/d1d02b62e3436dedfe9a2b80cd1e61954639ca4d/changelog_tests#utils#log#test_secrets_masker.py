===
match
---
operator: } [6972,6973]
operator: } [6431,6432]
===
match
---
atom [6400,6417]
atom [5859,5876]
===
match
---
assert_stmt [9215,9271]
assert_stmt [8674,8730]
===
match
---
operator: , [7060,7061]
operator: , [6519,6520]
===
match
---
operator: } [5952,5953]
operator: } [5411,5412]
===
match
---
string: "***" [7106,7111]
string: "***" [6565,6570]
===
match
---
atom [9074,9110]
atom [8533,8569]
===
match
---
operator: } [6416,6417]
operator: } [5875,5876]
===
match
---
atom [8520,8551]
atom [7979,8010]
===
match
---
name: reason [4108,4114]
name: reason [3567,3573]
===
match
---
string: "%(levelname)s %(message)s %(conn)s" [2870,2906]
string: "%(levelname)s %(message)s %(conn)s" [2329,2365]
===
match
---
name: test_mask_secret [6064,6080]
name: test_mask_secret [5523,5539]
===
match
---
assert_stmt [7888,7916]
assert_stmt [7347,7375]
===
match
---
name: airflow [884,891]
name: airflow [884,891]
===
match
---
suite [7951,9325]
suite [7410,8784]
===
match
---
name: should_hide_value_for_key [8330,8355]
name: should_hide_value_for_key [7789,7814]
===
match
---
trailer [1060,1067]
trailer [1060,1067]
===
match
---
operator: = [3120,3121]
operator: = [2579,2580]
===
match
---
parameters [2789,2811]
parameters [2248,2270]
===
match
---
testlist_comp [8041,8050]
testlist_comp [7500,7509]
===
match
---
operator: } [9142,9143]
operator: } [8601,8602]
===
match
---
except_clause [3206,3225]
except_clause [2665,2684]
===
match
---
string: "other" [5743,5750]
string: "other" [5202,5209]
===
match
---
atom [7049,7059]
atom [6508,6518]
===
match
---
arglist [9555,9600]
arglist [9014,9059]
===
match
---
operator: , [8070,8071]
operator: , [7529,7530]
===
match
---
name: lineno [4988,4994]
name: lineno [4447,4453]
===
match
---
testlist_comp [8610,8644]
testlist_comp [8069,8103]
===
match
---
operator: , [6505,6506]
operator: , [5964,5965]
===
match
---
operator: } [6814,6815]
operator: } [6273,6274]
===
match
---
param [7687,7693]
param [7146,7152]
===
match
---
dictorsetmaker [7079,7119]
dictorsetmaker [6538,6578]
===
match
---
name: logger [1901,1907]
name: logger [1901,1907]
===
match
---
operator: = [4986,4987]
operator: = [4445,4446]
===
match
---
suite [2812,3043]
suite [2271,2502]
===
match
---
suite [3226,3263]
suite [2685,2722]
===
match
---
name: logger [2821,2827]
name: logger [2280,2286]
===
match
---
assert_stmt [2988,3042]
assert_stmt [2447,2501]
===
match
---
arith_expr [3279,3291]
arith_expr [2738,2750]
===
match
---
name: INFO [1475,1479]
name: INFO [1475,1479]
===
match
---
atom [6688,6702]
atom [6147,6161]
===
match
---
string: "user:password" [2961,2976]
string: "user:password" [2420,2435]
===
match
---
dotted_name [8978,9010]
dotted_name [8437,8469]
===
match
---
param [4194,4200]
param [3653,3659]
===
match
---
name: expected_result [8947,8962]
name: expected_result [8406,8421]
===
match
---
param [8947,8962]
param [8406,8421]
===
match
---
name: filt [1808,1812]
name: filt [1808,1812]
===
match
---
name: name [6176,6180]
name: name [5635,5639]
===
match
---
atom_expr [7740,7762]
atom_expr [7199,7221]
===
match
---
operator: , [8690,8691]
operator: , [8149,8150]
===
match
---
param [9457,9465]
param [8916,8924]
===
match
---
string: "Cannot filter secrets in traceback source" [4115,4158]
string: "Cannot filter secrets in traceback source" [3574,3617]
===
match
---
operator: , [6368,6369]
operator: , [5827,5828]
===
match
---
trailer [9495,9511]
trailer [8954,8970]
===
match
---
name: dedent [3984,3990]
name: dedent [3443,3449]
===
match
---
suite [9370,9602]
suite [8829,9061]
===
match
---
string: "secret" [6760,6768]
string: "secret" [6219,6227]
===
match
---
dictorsetmaker [1224,1307]
dictorsetmaker [1224,1307]
===
match
---
param [9451,9456]
param [8910,8915]
===
match
---
string: "other" [7079,7086]
string: "other" [6538,6545]
===
match
---
arglist [8400,8875]
arglist [7859,8334]
===
match
---
atom_expr [8330,8360]
atom_expr [7789,7819]
===
match
---
atom [6544,6610]
atom [6003,6069]
===
match
---
operator: } [6777,6778]
operator: } [6236,6237]
===
match
---
name: value [6169,6174]
name: value [5628,5633]
===
match
---
string: "***" [7113,7118]
string: "***" [6572,6577]
===
match
---
testlist_comp [6668,6685]
testlist_comp [6127,6144]
===
match
---
operator: , [8271,8272]
operator: , [7730,7731]
===
match
---
operator: == [9238,9240]
operator: == [8697,8699]
===
match
---
name: logger [1684,1690]
name: logger [1684,1690]
===
match
---
name: text [3315,3319]
name: text [2774,2778]
===
match
---
dotted_name [1014,1028]
dotted_name [1014,1028]
===
match
---
name: value [7486,7491]
name: value [6945,6950]
===
match
---
name: logging [822,829]
name: logging [822,829]
===
match
---
name: replace [9547,9554]
name: replace [9006,9013]
===
match
---
suite [4935,4972]
suite [4394,4431]
===
match
---
name: logger [2916,2922]
name: logger [2375,2381]
===
match
---
name: add_mask [1868,1876]
name: add_mask [1868,1876]
===
match
---
simple_stmt [3239,3263]
simple_stmt [2698,2722]
===
match
---
name: caplog [7895,7901]
name: caplog [7354,7360]
===
match
---
testlist_comp [5726,5772]
testlist_comp [5185,5231]
===
match
---
suite [4202,5356]
suite [3661,4815]
===
match
---
operator: @ [1013,1014]
operator: @ [1013,1014]
===
match
---
simple_stmt [1863,1889]
simple_stmt [1863,1889]
===
match
---
atom [1168,1325]
atom [1168,1325]
===
match
---
name: logger [1962,1968]
name: logger [1962,1968]
===
match
---
atom [1392,1538]
atom [1392,1538]
===
match
---
name: self [6081,6085]
name: self [5540,5544]
===
match
---
string: 'GITHUB_mysecretword' [8692,8713]
string: 'GITHUB_mysecretword' [8151,8172]
===
match
---
operator: , [5402,5403]
operator: , [4861,4862]
===
match
---
atom_expr [2821,2849]
atom_expr [2280,2308]
===
match
---
trailer [1078,1616]
trailer [1078,1616]
===
match
---
atom [5933,5953]
atom [5392,5412]
===
match
---
trailer [6159,6168]
trailer [5618,5627]
===
match
---
trailer [5047,5355]
trailer [4506,4814]
===
match
---
string: "" [5995,5997]
string: "" [5454,5456]
===
match
---
name: config [1061,1067]
name: config [1061,1067]
===
match
---
dictorsetmaker [9074,9142]
dictorsetmaker [8533,8601]
===
match
---
string: 'foo' [7352,7357]
string: 'foo' [6811,6816]
===
match
---
trailer [3936,3943]
trailer [3395,3402]
===
match
---
name: caplog [3699,3705]
name: caplog [3158,3164]
===
match
---
parameters [6080,6114]
parameters [5539,5573]
===
match
---
decorator [5361,6056]
decorator [4820,5515]
===
match
---
name: test_utils [976,986]
name: test_utils [976,986]
===
match
---
operator: { [6571,6572]
operator: { [6030,6031]
===
match
---
raise_stmt [3150,3197]
raise_stmt [2609,2656]
===
match
---
operator: , [8622,8623]
operator: , [8081,8082]
===
match
---
operator: { [5190,5191]
operator: { [4649,4650]
===
match
---
operator: } [6609,6610]
operator: } [6068,6069]
===
match
---
operator: , [8720,8721]
operator: , [8179,8180]
===
match
---
atom_expr [7611,7635]
atom_expr [7070,7094]
===
match
---
param [3685,3690]
param [3144,3149]
===
match
---
operator: { [6759,6760]
operator: { [6218,6219]
===
match
---
name: caplog [1970,1976]
name: caplog [1970,1976]
===
match
---
simple_stmt [2022,2059]
simple_stmt [2022,2059]
===
match
---
name: info [2116,2120]
name: info [2116,2120]
===
match
---
operator: , [8645,8646]
operator: , [8104,8105]
===
match
---
trailer [9358,9368]
trailer [8817,8827]
===
match
---
operator: , [7093,7094]
operator: , [6552,6553]
===
match
---
operator: , [6973,6974]
operator: , [6432,6433]
===
match
---
string: 'api_key' [7377,7386]
string: 'api_key' [6836,6845]
===
match
---
atom [8565,8595]
atom [8024,8054]
===
match
---
operator: } [1537,1538]
operator: } [1537,1538]
===
match
---
name: formatted [9537,9546]
name: formatted [8996,9005]
===
match
---
operator: , [6610,6611]
operator: , [6069,6070]
===
match
---
name: f_lineno [9717,9725]
name: f_lineno [9176,9184]
===
match
---
name: self [7464,7468]
name: self [6923,6927]
===
match
---
trailer [2927,2978]
trailer [2386,2437]
===
match
---
name: handle [7822,7828]
name: handle [7281,7287]
===
match
---
name: line [3272,3276]
name: line [2731,2735]
===
match
---
name: parametrize [6247,6258]
name: parametrize [5706,5717]
===
match
---
operator: , [6589,6590]
operator: , [6048,6049]
===
match
---
operator: } [7409,7410]
operator: } [6868,6869]
===
match
---
operator: , [8499,8500]
operator: , [7958,7959]
===
match
---
trailer [3001,3006]
trailer [2460,2465]
===
match
---
string: "key" [7991,7996]
string: "key" [7450,7455]
===
match
---
atom [6382,6625]
atom [5841,6084]
===
match
---
string: "apikey" [6458,6466]
string: "apikey" [5917,5925]
===
match
---
string: "password" [6507,6517]
string: "password" [5966,5976]
===
match
---
atom [8040,8051]
atom [7499,7510]
===
match
---
testlist_comp [8660,8719]
testlist_comp [8119,8178]
===
match
---
operator: , [5527,5528]
operator: , [4986,4987]
===
match
---
trailer [6168,6181]
trailer [5627,5640]
===
match
---
operator: { [6400,6401]
operator: { [5859,5860]
===
match
---
funcdef [9604,9726]
funcdef [9063,9185]
===
match
---
dotted_name [884,916]
dotted_name [884,916]
===
match
---
name: filt [6124,6128]
name: filt [5583,5587]
===
match
---
string: "other" [6678,6685]
string: "other" [6137,6144]
===
match
---
arglist [6268,7437]
arglist [5727,6896]
===
match
---
simple_stmt [7604,7648]
simple_stmt [7063,7107]
===
match
---
atom_expr [2029,2040]
atom_expr [2029,2040]
===
match
---
string: 'GITHUB_APIKEY' [8573,8588]
string: 'GITHUB_APIKEY' [8032,8047]
===
match
---
with_stmt [7735,7829]
with_stmt [7194,7288]
===
match
---
dictorsetmaker [7019,7059]
dictorsetmaker [6478,6518]
===
match
---
operator: , [8435,8436]
operator: , [7894,7895]
===
match
---
string: 'loggers' [1353,1362]
string: 'loggers' [1353,1362]
===
match
---
operator: , [8078,8079]
operator: , [7537,7538]
===
match
---
operator: , [7468,7469]
operator: , [6927,6928]
===
match
---
string: 'disable_existing_loggers' [1566,1592]
string: 'disable_existing_loggers' [1566,1592]
===
match
---
operator: , [6037,6038]
operator: , [5496,5497]
===
match
---
operator: , [6694,6695]
operator: , [6153,6154]
===
match
---
name: filt [7512,7516]
name: filt [6971,6975]
===
match
---
trailer [3314,3319]
trailer [2773,2778]
===
match
---
atom_expr [7711,7726]
atom_expr [7170,7185]
===
match
---
operator: , [8841,8842]
operator: , [8300,8301]
===
match
---
trailer [9200,9202]
trailer [8659,8661]
===
match
---
simple_stmt [4853,4907]
simple_stmt [4312,4366]
===
match
---
simple_stmt [7786,7829]
simple_stmt [7245,7288]
===
match
---
atom [5693,5710]
atom [5152,5169]
===
match
---
string: "secret" [5633,5641]
string: "secret" [5092,5100]
===
match
---
file_input [785,9726]
file_input [785,9185]
===
match
---
operator: } [5479,5480]
operator: } [4938,4939]
===
match
---
string: ".../" [9565,9571]
string: ".../" [9024,9030]
===
match
---
operator: + [3190,3191]
operator: + [2649,2650]
===
match
---
trailer [1828,1830]
trailer [1828,1830]
===
match
---
name: parametrize [7969,7980]
name: parametrize [7428,7439]
===
match
---
classdef [1910,7917]
classdef [1910,7376]
===
match
---
atom_expr [3975,4083]
atom_expr [3434,3542]
===
match
---
name: value [6093,6098]
name: value [5552,5557]
===
match
---
comparison [8311,8360]
comparison [7770,7819]
===
match
---
trailer [1993,1998]
trailer [1993,1998]
===
match
---
operator: , [8051,8052]
operator: , [7510,7511]
===
match
---
number: 1 [1113,1114]
number: 1 [1113,1114]
===
match
---
name: lineno [3279,3285]
name: lineno [2738,2744]
===
match
---
operator: , [5702,5703]
operator: , [5161,5162]
===
match
---
operator: = [1785,1786]
operator: = [1785,1786]
===
match
---
dictorsetmaker [6572,6608]
dictorsetmaker [6031,6067]
===
match
---
name: pytest [4090,4096]
name: pytest [3549,3555]
===
match
---
decorated [6234,7648]
decorated [5693,7107]
===
match
---
string: "sensitive_variable_fields" [8401,8428]
string: "sensitive_variable_fields" [7860,7887]
===
match
---
name: line [4981,4985]
name: line [4440,4444]
===
match
---
string: "secret" [6335,6343]
string: "secret" [5794,5802]
===
match
---
operator: , [5468,5469]
operator: , [4927,4928]
===
match
---
atom [6333,6368]
atom [5792,5827]
===
match
---
operator: , [6350,6351]
operator: , [5809,5810]
===
match
---
atom_expr [3920,3943]
atom_expr [3379,3402]
===
match
---
trailer [1876,1888]
trailer [1876,1888]
===
match
---
operator: , [6476,6477]
operator: , [5935,5936]
===
match
---
argument [2946,2977]
argument [2405,2436]
===
match
---
atom_expr [3960,3971]
atom_expr [3419,3430]
===
match
---
name: self [9451,9455]
name: self [8910,8914]
===
match
---
trailer [4964,4971]
trailer [4423,4430]
===
match
---
name: filt [7704,7708]
name: filt [7163,7167]
===
match
---
string: "foo" [6411,6416]
string: "foo" [5870,5875]
===
match
---
string: "secret" [5694,5702]
string: "secret" [5153,5161]
===
match
---
atom_expr [2109,2161]
atom_expr [2109,2161]
===
match
---
suite [9617,9726]
suite [9076,9185]
===
match
---
operator: == [7911,7913]
operator: == [7370,7372]
===
match
---
operator: } [7357,7358]
operator: } [6816,6817]
===
match
---
string: "expected" [6298,6308]
string: "expected" [5757,5767]
===
match
---
operator: } [6815,6816]
operator: } [6274,6275]
===
match
---
simple_stmt [2821,2908]
simple_stmt [2280,2367]
===
match
---
raise_stmt [4853,4906]
raise_stmt [4312,4365]
===
match
---
string: "Err" [4965,4970]
string: "Err" [4424,4429]
===
match
---
atom_expr [7257,7262]
atom_expr [6716,6721]
===
match
---
string: "/dev/null" [7745,7756]
string: "/dev/null" [7204,7215]
===
match
---
dictorsetmaker [6458,6525]
dictorsetmaker [5917,5984]
===
match
---
name: log [898,901]
name: log [898,901]
===
match
---
testlist_comp [8066,8077]
testlist_comp [7525,7536]
===
match
---
suite [2100,2229]
suite [2100,2229]
===
match
---
name: key [8273,8276]
name: key [7732,7735]
===
match
---
trailer [1998,2012]
trailer [1998,2012]
===
match
---
simple_stmt [864,878]
simple_stmt [864,878]
===
match
---
operator: - [3288,3289]
operator: - [2747,2748]
===
match
---
string: "foo" [5704,5709]
string: "foo" [5163,5168]
===
match
---
name: self [8909,8913]
name: self [8368,8372]
===
match
---
string: "XpasswordY" [1999,2011]
string: "XpasswordY" [1999,2011]
===
match
---
expr_stmt [9476,9521]
expr_stmt [8935,8980]
===
match
---
trailer [1794,1802]
trailer [1794,1802]
===
match
---
simple_stmt [4211,4828]
simple_stmt [3670,4287]
===
match
---
string: 'key, token' [8610,8622]
string: 'key, token' [8069,8081]
===
match
---
trailer [1753,1764]
trailer [1753,1764]
===
match
---
string: "secret" [5517,5525]
string: "secret" [4976,4984]
===
match
---
atom [6818,6845]
atom [6277,6304]
===
match
---
testlist_comp [7106,7118]
testlist_comp [6565,6577]
===
match
---
arglist [7623,7634]
arglist [7082,7093]
===
match
---
operator: } [6843,6844]
operator: } [6302,6303]
===
match
---
atom_expr [1726,1764]
atom_expr [1726,1764]
===
match
---
trailer [3990,4083]
trailer [3449,3542]
===
match
---
operator: , [6686,6687]
operator: , [6145,6146]
===
match
---
testlist_comp [5733,5750]
testlist_comp [5192,5209]
===
match
---
atom [6963,6973]
atom [6422,6432]
===
match
---
operator: , [6409,6410]
operator: , [5868,5869]
===
match
---
name: extra [2946,2951]
name: extra [2405,2410]
===
match
---
dictorsetmaker [2953,2976]
dictorsetmaker [2412,2435]
===
match
---
atom [6759,6778]
atom [6218,6237]
===
match
---
string: "secret" [6806,6814]
string: "secret" [6265,6273]
===
match
---
operator: = [6129,6130]
operator: = [5588,5589]
===
match
---
expr_stmt [2821,2907]
expr_stmt [2280,2366]
===
match
---
atom [5615,5711]
atom [5074,5170]
===
match
---
param [7470,7479]
param [6929,6938]
===
match
---
name: filt [7611,7615]
name: filt [7070,7074]
===
match
---
operator: { [5693,5694]
operator: { [5152,5153]
===
match
---
string: "secret" [5733,5741]
string: "secret" [5192,5200]
===
match
---
suite [9145,9272]
suite [8604,8731]
===
match
---
dictorsetmaker [5754,5771]
dictorsetmaker [5213,5230]
===
match
---
string: 'TRELLO_TOKEN' [8624,8638]
string: 'TRELLO_TOKEN' [8083,8097]
===
match
---
classdef [7919,9325]
classdef [7378,8784]
===
match
---
operator: , [3697,3698]
operator: , [3156,3157]
===
match
---
atom [5453,5481]
atom [4912,4940]
===
match
---
suite [9467,9602]
suite [8926,9061]
===
match
---
atom_expr [9488,9521]
atom_expr [8947,8980]
===
match
---
operator: = [1691,1692]
operator: = [1691,1692]
===
match
---
simple_stmt [8304,8361]
simple_stmt [7763,7820]
===
match
---
string: """Returns the current line number in our program.""" [9622,9675]
string: """Returns the current line number in our program.""" [9081,9134]
===
match
---
param [1962,1969]
param [1962,1969]
===
match
---
testlist_comp [5922,5960]
testlist_comp [5381,5419]
===
match
---
string: "innocent" [6579,6589]
string: "innocent" [6038,6048]
===
match
---
string: "other" [6651,6658]
string: "other" [6110,6117]
===
match
---
dictorsetmaker [5623,5690]
dictorsetmaker [5082,5149]
===
match
---
atom_expr [1633,1679]
atom_expr [1633,1679]
===
match
---
atom [7018,7060]
atom [6477,6519]
===
match
---
string: 'other' [7395,7402]
string: 'other' [6854,6861]
===
match
---
operator: { [6795,6796]
operator: { [6254,6255]
===
match
---
trailer [1867,1876]
trailer [1867,1876]
===
match
---
suite [7773,7829]
suite [7232,7288]
===
match
---
trailer [3245,3255]
trailer [2704,2714]
===
match
---
arglist [6169,6180]
arglist [5628,5639]
===
match
---
trailer [4954,4964]
trailer [4413,4423]
===
match
---
param [2092,2098]
param [2092,2098]
===
match
---
name: config [987,993]
name: config [987,993]
===
match
---
string: 'propagate' [1501,1512]
string: 'propagate' [1501,1512]
===
match
---
string: "other" [7019,7026]
string: "other" [6478,6485]
===
match
---
operator: = [2951,2952]
operator: = [2410,2411]
===
match
---
funcdef [1029,1908]
funcdef [1029,1908]
===
match
---
name: test_redact [7452,7463]
name: test_redact [6911,6922]
===
match
---
simple_stmt [4948,4972]
simple_stmt [4407,4431]
===
match
---
operator: @ [7956,7957]
operator: @ [7415,7416]
===
match
---
name: secrets_masker [8996,9010]
name: secrets_masker [8455,8469]
===
match
---
name: __name__ [1158,1166]
name: __name__ [1158,1166]
===
match
---
string: "name" [5396,5402]
string: "name" [4855,4861]
===
match
---
simple_stmt [3716,3912]
simple_stmt [3175,3371]
===
match
---
operator: , [2794,2795]
operator: , [2253,2254]
===
match
---
operator: , [7037,7038]
operator: , [6496,6497]
===
match
---
operator: , [7053,7054]
operator: , [6512,6513]
===
match
---
operator: { [6818,6819]
operator: { [6277,6278]
===
match
---
decorator [7956,8238]
decorator [7415,7697]
===
match
---
operator: } [5195,5196]
operator: } [4654,4655]
===
match
---
operator: , [7285,7286]
operator: , [6744,6745]
===
match
---
funcdef [7653,7917]
funcdef [7112,7376]
===
match
---
trailer [4994,4996]
trailer [4453,4455]
===
match
---
name: SecretsMasker [1815,1828]
name: SecretsMasker [1815,1828]
===
match
---
operator: , [5730,5731]
operator: , [5189,5190]
===
match
---
operator: = [1813,1814]
operator: = [1813,1814]
===
match
---
string: 'token, mysecretword' [8820,8841]
string: 'token, mysecretword' [8279,8300]
===
match
---
simple_stmt [9158,9203]
simple_stmt [8617,8662]
===
match
---
suite [8295,8361]
suite [7754,7820]
===
match
---
operator: , [2944,2945]
operator: , [2403,2404]
===
match
---
name: getLogger [1701,1710]
name: getLogger [1701,1710]
===
match
---
operator: == [3972,3974]
operator: == [3431,3433]
===
match
---
testlist_comp [8093,8105]
testlist_comp [7552,7564]
===
match
---
string: 'key' [8521,8526]
string: 'key' [7980,7985]
===
match
---
testlist_comp [6640,6702]
testlist_comp [6099,6161]
===
match
---
testlist_comp [8197,8218]
testlist_comp [7656,7677]
===
match
---
testlist_comp [7257,7411]
testlist_comp [6716,6870]
===
match
---
atom [8092,8106]
atom [7551,7565]
===
match
---
trailer [9554,9601]
trailer [9013,9060]
===
match
---
operator: , [6360,6361]
operator: , [5819,5820]
===
match
---
suite [3102,3198]
suite [2561,2657]
===
match
---
name: logger [3920,3926]
name: logger [3379,3385]
===
match
---
operator: , [2090,2091]
operator: , [2090,2091]
===
match
---
name: cache_clear [9189,9200]
name: cache_clear [8648,8659]
===
match
---
classdef [9327,9602]
classdef [8786,9061]
===
match
---
operator: { [5753,5754]
operator: { [5212,5213]
===
match
---
suite [4840,4907]
suite [4299,4366]
===
match
---
name: get_sensitive_variables_fields [9018,9048]
name: get_sensitive_variables_fields [8477,8507]
===
match
---
operator: } [5690,5691]
operator: } [5149,5150]
===
match
---
operator: , [6846,6847]
operator: , [6305,6306]
===
match
---
atom_expr [7895,7910]
atom_expr [7354,7369]
===
match
---
string: "secret" [6401,6409]
string: "secret" [5860,5868]
===
match
---
name: handler [1795,1802]
name: handler [1795,1802]
===
match
---
atom [6795,6815]
atom [6254,6274]
===
match
---
operator: , [1968,1969]
operator: , [1968,1969]
===
match
---
operator: , [6778,6779]
operator: , [6237,6238]
===
match
---
string: 'version' [1102,1111]
string: 'version' [1102,1111]
===
match
---
param [2796,2803]
param [2255,2262]
===
match
---
name: add_mask [6160,6168]
name: add_mask [5619,5627]
===
match
---
operator: , [6625,6626]
operator: , [6084,6085]
===
match
---
name: self [1956,1960]
name: self [1956,1960]
===
match
---
atom_expr [1693,1720]
atom_expr [1693,1720]
===
match
---
operator: @ [4089,4090]
operator: @ [3548,3549]
===
match
---
string: "***" [6689,6694]
string: "***" [6148,6153]
===
match
---
name: logger [3073,3079]
name: logger [2532,2538]
===
match
---
simple_stmt [3301,3650]
simple_stmt [2760,3109]
===
match
---
name: exception [3927,3936]
name: exception [3386,3395]
===
match
---
simple_stmt [1726,1765]
simple_stmt [1726,1765]
===
match
---
trailer [1740,1753]
trailer [1740,1753]
===
match
---
name: cache_clear [9311,9322]
name: cache_clear [8770,8781]
===
match
---
simple_stmt [9375,9426]
simple_stmt [8834,8885]
===
match
---
string: 'stream' [1278,1286]
string: 'stream' [1278,1286]
===
match
---
operator: , [7341,7342]
operator: , [6800,6801]
===
match
---
string: """         Test that when ``logger.exception`` is called when there is no current exception we still log.          (This is a "bug" in user code, but we shouldn't die because of it!)         """ [3716,3911]
string: """         Test that when ``logger.exception`` is called when there is no current exception we still log.          (This is a "bug" in user code, but we shouldn't die because of it!)         """ [3175,3370]
===
match
---
name: logger [2796,2802]
name: logger [2255,2261]
===
match
---
operator: @ [8366,8367]
operator: @ [7825,7826]
===
match
---
operator: , [8940,8941]
operator: , [8399,8400]
===
match
---
name: formatException [9435,9450]
name: formatException [8894,8909]
===
match
---
string: "google_api_key" [8121,8137]
string: "google_api_key" [7580,7596]
===
match
---
atom [8465,8874]
atom [7924,8333]
===
match
---
operator: { [7018,7019]
operator: { [6477,6478]
===
match
---
trailer [9576,9581]
trailer [9035,9040]
===
match
---
string: "other" [5643,5650]
string: "other" [5102,5109]
===
match
---
atom [8196,8219]
atom [7655,7678]
===
match
---
name: add_mask [7581,7589]
name: add_mask [7040,7048]
===
match
---
trailer [6003,6005]
trailer [5462,5464]
===
match
---
suite [8964,9325]
suite [8423,8784]
===
match
---
operator: , [3071,3072]
operator: , [2530,2531]
===
match
---
operator: , [5762,5763]
operator: , [5221,5222]
===
match
---
operator: , [7000,7001]
operator: , [6459,6460]
===
match
---
suite [6115,6229]
suite [5574,5688]
===
match
---
operator: = [9486,9487]
operator: = [8945,8946]
===
match
---
operator: , [5641,5642]
operator: , [5100,5101]
===
match
---
name: caplog [1040,1046]
name: caplog [1040,1046]
===
match
---
operator: , [8182,8183]
operator: , [7641,7642]
===
match
---
dictorsetmaker [5653,5689]
dictorsetmaker [5112,5148]
===
match
---
atom [1426,1436]
atom [1426,1436]
===
match
---
operator: , [6417,6418]
operator: , [5876,5877]
===
match
---
string: 'mysecretword, mysensitivekey' [8660,8690]
string: 'mysecretword, mysensitivekey' [8119,8149]
===
match
---
trailer [9072,9144]
trailer [8531,8603]
===
match
---
operator: , [6768,6769]
operator: , [6227,6228]
===
match
---
testlist_comp [8776,8804]
testlist_comp [8235,8263]
===
match
---
name: os [9574,9576]
name: os [9033,9035]
===
match
---
operator: = [4114,4115]
operator: = [3573,3574]
===
match
---
name: line [3482,3486]
name: line [2941,2945]
===
match
---
name: test_hiding_config [8890,8908]
name: test_hiding_config [8349,8367]
===
match
---
name: f_back [9710,9716]
name: f_back [9169,9175]
===
match
---
operator: } [5997,5998]
operator: } [5456,5457]
===
match
---
name: line [5191,5195]
name: line [4650,4654]
===
match
---
comparison [9222,9271]
comparison [8681,8730]
===
match
---
operator: = [2850,2851]
operator: = [2309,2310]
===
match
---
fstring_string: \             ERROR Err             Traceback (most recent call last):               File ".../test_secrets_masker.py", line  [3356,3481]
fstring_string: \             ERROR Err             Traceback (most recent call last):               File ".../test_secrets_masker.py", line  [2815,2940]
===
match
---
operator: , [6344,6345]
operator: , [5803,5804]
===
match
---
trailer [1474,1479]
trailer [1474,1479]
===
match
---
string: "***" [6362,6367]
string: "***" [5821,5826]
===
match
---
name: conn [3192,3196]
name: conn [2651,2655]
===
match
---
simple_stmt [9530,9602]
simple_stmt [8989,9061]
===
match
---
name: caplog [5017,5023]
name: caplog [4476,4482]
===
match
---
trailer [1775,1784]
trailer [1775,1784]
===
match
---
simple_stmt [1808,1831]
simple_stmt [1808,1831]
===
match
---
string: "***" [6555,6560]
string: "***" [6014,6019]
===
match
---
operator: { [6786,6787]
operator: { [6245,6246]
===
match
---
operator: , [5773,5774]
operator: , [5232,5233]
===
match
---
simple_stmt [1621,1680]
simple_stmt [1621,1680]
===
match
---
string: "INFO X***Y\n" [2044,2058]
string: "INFO X***Y\n" [2044,2058]
===
match
---
atom [8400,8455]
atom [7859,7914]
===
match
---
operator: , [1599,1600]
operator: , [1599,1600]
===
match
---
trailer [7622,7635]
trailer [7081,7094]
===
match
---
operator: @ [6234,6235]
operator: @ [5693,5694]
===
match
---
operator: , [7436,7437]
operator: , [6895,6896]
===
match
---
atom_expr [1769,1784]
atom_expr [1769,1784]
===
match
---
string: "Cannot connect to " [3169,3189]
string: "Cannot connect to " [2628,2648]
===
match
---
operator: { [1364,1365]
operator: { [1364,1365]
===
match
---
param [1956,1961]
param [1956,1961]
===
match
---
operator: , [8016,8017]
operator: , [7475,7476]
===
match
---
param [3699,3705]
param [3158,3164]
===
match
---
string: 'masked based on key name' [7315,7341]
string: 'masked based on key name' [6774,6800]
===
match
---
trailer [7804,7818]
trailer [7263,7277]
===
match
---
name: caplog [2804,2810]
name: caplog [2263,2269]
===
match
---
string: "password" [5672,5682]
string: "password" [5131,5141]
===
match
---
simple_stmt [9680,9726]
simple_stmt [9139,9185]
===
match
---
name: mark [6242,6246]
name: mark [5701,5705]
===
match
---
operator: , [6526,6527]
operator: , [5985,5986]
===
match
---
string: "user:password" [3122,3137]
string: "user:password" [2581,2596]
===
match
---
operator: , [5514,5515]
operator: , [4973,4974]
===
match
---
atom [1088,1610]
atom [1088,1610]
===
match
---
operator: @ [5361,5362]
operator: @ [4820,4821]
===
match
---
dictorsetmaker [1414,1520]
dictorsetmaker [1414,1520]
===
match
---
funcdef [8886,9325]
funcdef [8345,8784]
===
match
---
fstring_expr [3481,3487]
fstring_expr [2940,2946]
===
match
---
testlist_comp [7050,7058]
testlist_comp [6509,6517]
===
match
---
with_stmt [9058,9272]
with_stmt [8517,8731]
===
match
---
atom_expr [9158,9202]
atom_expr [8617,8661]
===
match
---
atom [6667,6686]
atom [6126,6145]
===
match
---
string: 'TRELLO_API_KEY' [8528,8544]
string: 'TRELLO_API_KEY' [7987,8003]
===
match
---
param [2084,2091]
param [2084,2091]
===
match
---
name: self [3067,3071]
name: self [2526,2530]
===
match
---
atom [5470,5480]
atom [4929,4939]
===
match
---
name: TestSecretsMasker [1916,1933]
name: TestSecretsMasker [1916,1933]
===
match
---
testlist_comp [5616,5710]
testlist_comp [5075,5169]
===
match
---
name: value [7623,7628]
name: value [7082,7087]
===
match
---
atom_expr [4988,4996]
atom_expr [4447,4455]
===
match
---
operator: } [1609,1610]
operator: } [1609,1610]
===
match
---
string: "secret" [6964,6972]
string: "secret" [6423,6431]
===
match
---
operator: , [8595,8596]
operator: , [8054,8055]
===
match
---
assert_stmt [2171,2228]
assert_stmt [2171,2228]
===
match
---
simple_stmt [2171,2229]
simple_stmt [2171,2229]
===
match
---
atom_expr [9574,9600]
atom_expr [9033,9059]
===
match
---
name: super [9488,9493]
name: super [8947,8952]
===
match
---
operator: , [6659,6660]
operator: , [6118,6119]
===
match
---
name: logging [1693,1700]
name: logging [1693,1700]
===
match
---
operator: , [8175,8176]
operator: , [7634,7635]
===
match
---
trailer [4871,4906]
trailer [4330,4365]
===
match
---
trailer [7589,7594]
trailer [7048,7053]
===
match
---
name: __name__ [1711,1719]
name: __name__ [1711,1719]
===
match
---
dictorsetmaker [6545,6609]
dictorsetmaker [6004,6068]
===
match
---
operator: , [8783,8784]
operator: , [8242,8243]
===
match
---
operator: , [7628,7629]
operator: , [7087,7088]
===
match
---
testlist_comp [7991,8015]
testlist_comp [7450,7474]
===
match
---
trailer [7532,7534]
trailer [6991,6993]
===
match
---
operator: , [8098,8099]
operator: , [7557,7558]
===
match
---
string: 'TRELLO_KEY' [8487,8499]
string: 'TRELLO_KEY' [7946,7958]
===
match
---
string: 'env' [7280,7285]
string: 'env' [6739,6744]
===
match
---
string: "data" [6787,6793]
string: "data" [6246,6252]
===
match
---
except_clause [4915,4934]
except_clause [4374,4393]
===
match
---
name: handle [7766,7772]
name: handle [7225,7231]
===
match
---
atom_expr [9112,9142]
atom_expr [8571,8601]
===
match
---
operator: == [7636,7638]
operator: == [7095,7097]
===
match
---
string: "value" [6289,6296]
string: "value" [5748,5755]
===
match
---
string: "innocent" [5660,5670]
string: "innocent" [5119,5129]
===
match
---
testlist_comp [5453,6038]
testlist_comp [4912,5497]
===
match
---
atom [1364,1552]
atom [1364,1552]
===
match
---
operator: , [7491,7492]
operator: , [6950,6951]
===
match
---
name: filt [6198,6202]
name: filt [5657,5661]
===
match
---
name: filt [1852,1856]
name: filt [1852,1856]
===
match
---
param [6087,6092]
param [5546,5551]
===
match
---
operator: , [5751,5752]
operator: , [5210,5211]
===
match
---
trailer [3168,3197]
trailer [2627,2656]
===
match
---
decorated [8366,9325]
decorated [7825,8784]
===
match
---
operator: , [8805,8806]
operator: , [8264,8265]
===
match
---
name: RuntimeError [3213,3225]
name: RuntimeError [2672,2684]
===
match
---
atom_expr [9063,9144]
atom_expr [8522,8603]
===
match
---
name: inspect [9687,9694]
name: inspect [9146,9153]
===
match
---
simple_stmt [1894,1908]
simple_stmt [1894,1908]
===
match
---
operator: } [6525,6526]
operator: } [5984,5985]
===
match
---
operator: , [6029,6030]
operator: , [5488,5489]
===
match
---
operator: { [1392,1393]
operator: { [1392,1393]
===
match
---
assert_stmt [6191,6228]
assert_stmt [5650,5687]
===
match
---
name: __file__ [9555,9563]
name: __file__ [9014,9022]
===
match
---
operator: , [6703,6704]
operator: , [6162,6163]
===
match
---
atom [6020,6037]
atom [5479,5496]
===
match
---
suite [7695,7917]
suite [7154,7376]
===
match
---
operator: , [8863,8864]
operator: , [8322,8323]
===
match
---
name: pytest [6235,6241]
name: pytest [5694,5700]
===
match
---
string: "" [6027,6029]
string: "" [5486,5488]
===
match
---
string: "Cannot connect to %s" [2121,2143]
string: "Cannot connect to %s" [2121,2143]
===
match
---
operator: , [8137,8138]
operator: , [7596,7597]
===
match
---
decorated [4089,5356]
decorated [3548,4815]
===
match
---
atom [7376,7410]
atom [6835,6869]
===
match
---
trailer [2839,2849]
trailer [2298,2308]
===
match
---
string: "other" [6562,6569]
string: "other" [6021,6028]
===
match
---
name: expected [7639,7647]
name: expected [7098,7106]
===
match
---
import_name [864,877]
import_name [864,877]
===
match
---
trailer [2120,2161]
trailer [2120,2161]
===
match
---
operator: , [8544,8545]
operator: , [8003,8004]
===
match
---
atom [1787,1803]
atom [1787,1803]
===
match
---
atom [7105,7119]
atom [6564,6578]
===
match
---
atom [7303,7358]
atom [6762,6817]
===
match
---
operator: , [8753,8754]
operator: , [8212,8213]
===
match
---
name: basename [9582,9590]
name: basename [9041,9049]
===
match
---
number: 0 [2837,2838]
number: 0 [2296,2297]
===
match
---
trailer [2869,2907]
trailer [2328,2366]
===
match
---
simple_stmt [2988,3043]
simple_stmt [2447,2502]
===
match
---
name: patterns [6203,6211]
name: patterns [5662,5670]
===
match
---
string: "x" [7050,7053]
string: "x" [6509,6512]
===
match
---
name: should_hide_value_for_key [9241,9266]
name: should_hide_value_for_key [8700,8725]
===
match
---
expr_stmt [4981,5000]
expr_stmt [4440,4459]
===
match
---
testlist_comp [8121,8143]
testlist_comp [7580,7602]
===
match
---
assert_stmt [2022,2058]
assert_stmt [2022,2058]
===
match
---
trailer [2184,2189]
trailer [2184,2189]
===
match
---
operator: , [5953,5954]
operator: , [5412,5413]
===
match
---
operator: { [7078,7079]
operator: { [6537,6538]
===
match
---
atom_expr [2178,2189]
atom_expr [2178,2189]
===
match
---
atom [8026,8230]
atom [7485,7689]
===
match
---
string: 'class' [1224,1231]
string: 'class' [1224,1231]
===
match
---
name: inspect [792,799]
name: inspect [792,799]
===
match
---
name: exception [3246,3255]
name: exception [2705,2714]
===
match
---
name: sensitive_variable_fields [8915,8940]
name: sensitive_variable_fields [8374,8399]
===
match
---
operator: , [4192,4193]
operator: , [3651,3652]
===
match
---
name: secrets_masker [902,916]
name: secrets_masker [902,916]
===
match
---
string: "***" [6603,6608]
string: "***" [6062,6067]
===
match
---
simple_stmt [3115,3138]
simple_stmt [2574,2597]
===
match
---
name: test_hiding_defaults [8246,8266]
name: test_hiding_defaults [7705,7725]
===
match
---
operator: == [5029,5031]
operator: == [4488,4490]
===
match
---
atom [5921,5961]
atom [5380,5420]
===
match
---
operator: } [5525,5526]
operator: } [4984,4985]
===
match
---
param [6093,6099]
param [5552,5558]
===
match
---
string: "other" [6478,6485]
string: "other" [5937,5944]
===
match
---
operator: , [7484,7485]
operator: , [6943,6944]
===
match
---
name: handlers [1776,1784]
name: handlers [1776,1784]
===
match
---
param [3067,3072]
param [2526,2531]
===
match
---
atom_expr [5017,5028]
atom_expr [4476,4487]
===
match
---
fstring_end: """ [5342,5345]
fstring_end: """ [4801,4804]
===
match
---
string: "secret" [5460,5468]
string: "secret" [4919,4927]
===
match
---
operator: , [5931,5932]
operator: , [5390,5391]
===
match
---
operator: , [8945,8946]
operator: , [8404,8405]
===
match
---
string: "expected_result" [8437,8454]
string: "expected_result" [7896,7913]
===
match
---
trailer [2827,2836]
trailer [2286,2295]
===
match
---
simple_stmt [9215,9272]
simple_stmt [8674,8731]
===
match
---
operator: , [8506,8507]
operator: , [7965,7966]
===
match
---
decorator [6234,7444]
decorator [5693,6903]
===
match
---
string: 'ext://sys.stdout' [1288,1306]
string: 'ext://sys.stdout' [1288,1306]
===
match
---
number: 4 [3290,3291]
number: 4 [2749,2750]
===
match
---
name: caplog [3960,3966]
name: caplog [3419,3425]
===
match
---
operator: , [8874,8875]
operator: , [8333,8334]
===
match
---
atom_expr [3308,3319]
atom_expr [2767,2778]
===
match
---
name: expected_mask [6215,6228]
name: expected_mask [5674,5687]
===
match
---
name: Formatter [9359,9368]
name: Formatter [8818,8827]
===
match
---
arith_expr [3169,3196]
arith_expr [2628,2655]
===
match
---
string: 'TRELLO_API' [8741,8753]
string: 'TRELLO_API' [8200,8212]
===
match
---
operator: , [8276,8277]
operator: , [7735,7736]
===
match
---
string: "expected_result" [7998,8015]
string: "expected_result" [7457,7474]
===
match
---
string: "y" [7055,7058]
string: "y" [6514,6517]
===
match
---
atom_expr [1788,1802]
atom_expr [1788,1802]
===
match
---
name: expected_result [8278,8293]
name: expected_result [7737,7752]
===
match
---
operator: , [1306,1307]
operator: , [1306,1307]
===
match
---
operator: , [8526,8527]
operator: , [7985,7986]
===
match
---
name: path [9577,9581]
name: path [9036,9040]
===
match
---
decorated [1013,1908]
decorated [1013,1908]
===
match
---
param [7493,7501]
param [6952,6960]
===
match
---
operator: } [6844,6845]
operator: } [6303,6304]
===
match
---
trailer [7744,7762]
trailer [7203,7221]
===
match
---
arglist [7745,7761]
arglist [7204,7220]
===
match
---
testlist_comp [8566,8594]
testlist_comp [8025,8053]
===
match
---
simple_stmt [7576,7595]
simple_stmt [7035,7054]
===
match
---
name: exc_info [9457,9465]
name: exc_info [8916,8924]
===
match
---
fstring_end: """ [3636,3639]
fstring_end: """ [3095,3098]
===
match
---
parameters [8908,8963]
parameters [8367,8422]
===
match
---
string: "apikey" [5496,5504]
string: "apikey" [4955,4963]
===
match
---
operator: , [1519,1520]
operator: , [1519,1520]
===
match
---
string: 'logging.StreamHandler' [1233,1256]
string: 'logging.StreamHandler' [1233,1256]
===
match
---
trailer [1710,1720]
trailer [1710,1720]
===
match
---
name: self [4180,4184]
name: self [3639,3643]
===
match
---
simple_stmt [3920,3944]
simple_stmt [3379,3403]
===
match
---
param [7464,7469]
param [6923,6928]
===
match
---
simple_stmt [7704,7727]
simple_stmt [7163,7186]
===
match
---
name: pytest [8367,8373]
name: pytest [7826,7832]
===
match
---
parameters [3684,3706]
parameters [3143,3165]
===
match
---
param [8273,8277]
param [7732,7736]
===
match
---
name: text [3967,3971]
name: text [3426,3430]
===
match
---
name: ShortExcFormatter [9333,9350]
name: ShortExcFormatter [8792,8809]
===
match
---
string: "val" [6572,6577]
string: "val" [6031,6036]
===
match
---
with_item [7740,7772]
with_item [7199,7231]
===
match
---
operator: , [6279,6280]
operator: , [5738,5739]
===
match
---
parameters [7680,7694]
parameters [7139,7153]
===
match
---
funcdef [2064,2229]
funcdef [2064,2229]
===
match
---
string: 'other' [7343,7350]
string: 'other' [6802,6809]
===
match
---
parameters [4179,4201]
parameters [3638,3660]
===
match
---
name: caplog [4194,4200]
name: caplog [3653,3659]
===
match
---
expr_stmt [7512,7534]
expr_stmt [6971,6993]
===
match
---
import_from [8973,9048]
import_from [8432,8507]
===
match
---
trailer [9511,9521]
trailer [8970,8980]
===
match
---
funcdef [9431,9602]
funcdef [8890,9061]
===
match
---
name: formatter [1754,1763]
name: formatter [1754,1763]
===
match
---
trailer [5023,5028]
trailer [4482,4487]
===
match
---
dictorsetmaker [1158,1325]
dictorsetmaker [1158,1325]
===
match
---
operator: , [8855,8856]
operator: , [8314,8315]
===
match
---
comparison [2178,2228]
comparison [2178,2228]
===
match
---
trailer [6144,6146]
trailer [5603,5605]
===
match
---
simple_stmt [2109,2162]
simple_stmt [2109,2162]
===
match
---
operator: , [5998,5999]
operator: , [5457,5458]
===
match
---
name: exception [4955,4964]
name: exception [4414,4423]
===
match
---
dictorsetmaker [6401,6416]
dictorsetmaker [5860,5875]
===
match
---
operator: { [6827,6828]
operator: { [6286,6287]
===
match
---
atom [8734,8761]
atom [8193,8220]
===
match
---
operator: { [6334,6335]
operator: { [5793,5794]
===
match
---
name: redact [7798,7804]
name: redact [7257,7263]
===
match
---
name: pytest [5362,5368]
name: pytest [4821,4827]
===
match
---
operator: , [7262,7263]
operator: , [6721,6722]
===
match
---
operator: { [6963,6964]
operator: { [6422,6423]
===
match
---
name: SecretsMasker [924,937]
name: SecretsMasker [924,937]
===
match
---
string: "secret" [5754,5762]
string: "secret" [5213,5221]
===
match
---
name: parametrize [5374,5385]
name: parametrize [4833,4844]
===
match
---
testlist_comp [8479,8864]
testlist_comp [7938,8323]
===
match
---
string: 'handlers' [1414,1424]
string: 'handlers' [1414,1424]
===
match
---
expr_stmt [1808,1830]
expr_stmt [1808,1830]
===
match
---
atom [6639,6703]
atom [6098,6162]
===
match
---
string: "INFO Cannot connect user:***\n" [3010,3042]
string: "INFO Cannot connect user:***\n" [2469,2501]
===
match
---
param [2078,2083]
param [2078,2083]
===
match
---
operator: == [3320,3322]
operator: == [2779,2781]
===
match
---
operator: } [5709,5710]
operator: } [5168,5169]
===
match
---
dotted_name [822,836]
dotted_name [822,836]
===
match
---
name: set [6000,6003]
name: set [5459,5462]
===
match
---
name: formatter [2840,2849]
name: formatter [2299,2308]
===
match
---
name: caplog [3308,3314]
name: caplog [2767,2773]
===
match
---
operator: , [8571,8572]
operator: , [8030,8031]
===
match
---
atom_expr [6155,6181]
atom_expr [5614,5640]
===
match
---
operator: , [4184,4185]
operator: , [3643,3644]
===
match
---
string: "Cannot connect to user:password" [4872,4905]
string: "Cannot connect to user:password" [4331,4364]
===
match
---
param [4180,4185]
param [3639,3644]
===
match
---
name: __name__ [1382,1390]
name: __name__ [1382,1390]
===
match
---
atom [5725,5773]
atom [5184,5232]
===
match
---
dotted_name [8367,8390]
dotted_name [7826,7849]
===
match
---
name: tests [970,975]
name: tests [970,975]
===
match
---
string: '***' [7388,7393]
string: '***' [6847,6852]
===
match
---
name: self [8267,8271]
name: self [7726,7730]
===
match
---
dictorsetmaker [6641,6658]
dictorsetmaker [6100,6117]
===
match
---
atom [5439,6048]
atom [4898,5507]
===
match
---
operator: , [6006,6007]
operator: , [5465,5466]
===
match
---
atom [7914,7916]
atom [7373,7375]
===
match
---
name: __name__ [1427,1435]
name: __name__ [1427,1435]
===
match
---
dictorsetmaker [1382,1538]
dictorsetmaker [1382,1538]
===
match
---
trailer [8355,8360]
trailer [7814,7819]
===
match
---
trailer [9694,9707]
trailer [9153,9166]
===
match
---
string: "GOOGLE_APIKEY" [8197,8212]
string: "GOOGLE_APIKEY" [7656,7671]
===
match
---
name: dedent [5041,5047]
name: dedent [4500,4506]
===
match
---
dotted_name [7957,7980]
dotted_name [7416,7439]
===
match
---
operator: - [4997,4998]
operator: - [4456,4457]
===
match
---
name: currentframe [9695,9707]
name: currentframe [9154,9166]
===
match
---
expr_stmt [3272,3291]
expr_stmt [2731,2750]
===
match
---
atom_expr [5955,5960]
atom_expr [5414,5419]
===
match
---
assert_stmt [7604,7647]
assert_stmt [7063,7106]
===
match
---
operator: == [2041,2043]
operator: == [2041,2043]
===
match
---
operator: { [7303,7304]
operator: { [6762,6763]
===
match
---
dictorsetmaker [5934,5952]
dictorsetmaker [5393,5411]
===
match
---
decorator [4089,4160]
decorator [3548,3619]
===
match
---
name: filt [7576,7580]
name: filt [7035,7039]
===
match
---
atom [8120,8144]
atom [7579,7603]
===
match
---
atom_expr [7793,7818]
atom_expr [7252,7277]
===
match
---
atom [6758,6846]
atom [6217,6305]
===
match
---
simple_stmt [4981,5001]
simple_stmt [4440,4460]
===
match
---
trailer [1851,1857]
trailer [1851,1857]
===
match
---
name: SecretsMasker [7711,7724]
name: SecretsMasker [7170,7183]
===
match
---
dotted_name [5362,5385]
dotted_name [4821,4844]
===
match
---
trailer [3926,3936]
trailer [3385,3395]
===
match
---
name: test_redact_filehandles [7657,7680]
name: test_redact_filehandles [7116,7139]
===
match
---
arglist [5395,6049]
arglist [4854,5508]
===
match
---
operator: == [8327,8329]
operator: == [7786,7788]
===
match
---
operator: , [9563,9564]
operator: , [9022,9023]
===
match
---
funcdef [3048,3650]
funcdef [2507,3109]
===
match
---
comparison [7793,7828]
comparison [7252,7287]
===
match
---
simple_stmt [9280,9325]
simple_stmt [8739,8784]
===
match
---
string: 'api_key' [7304,7313]
string: 'api_key' [6763,6772]
===
match
---
dictorsetmaker [7377,7409]
dictorsetmaker [6836,6868]
===
match
---
string: "INFO Cannot connect to user:***\n" [2193,2228]
string: "INFO Cannot connect to user:***\n" [2193,2228]
===
match
---
param [8942,8946]
param [8401,8405]
===
match
---
operator: , [8761,8762]
operator: , [8220,8221]
===
match
---
name: filt [7793,7797]
name: filt [7252,7256]
===
match
---
string: "patterns" [6269,6279]
string: "patterns" [5728,5738]
===
match
---
number: 4 [4999,5000]
number: 4 [4458,4459]
===
match
---
suite [7563,7595]
suite [7022,7054]
===
match
---
simple_stmt [879,965]
simple_stmt [879,965]
===
match
---
operator: } [7119,7120]
operator: } [6578,6579]
===
match
---
name: __file__ [9591,9599]
name: __file__ [9050,9058]
===
match
---
import_name [847,862]
import_name [847,862]
===
match
---
operator: = [7517,7518]
operator: = [6976,6977]
===
match
---
trailer [7797,7804]
trailer [7256,7263]
===
match
---
name: test_args [2068,2077]
name: test_args [2068,2077]
===
match
---
testlist_comp [8820,8862]
testlist_comp [8279,8321]
===
match
---
name: conf_vars [9063,9072]
name: conf_vars [8522,8531]
===
match
---
trailer [2836,2839]
trailer [2295,2298]
===
match
---
name: name [6087,6091]
name: name [5546,5550]
===
match
---
string: "secret" [6668,6676]
string: "secret" [6127,6135]
===
match
---
for_stmt [7543,7595]
for_stmt [7002,7054]
===
match
---
name: val [7590,7593]
name: val [7049,7052]
===
match
---
trailer [7580,7589]
trailer [7039,7048]
===
match
---
name: logger [3691,3697]
name: logger [3150,3156]
===
match
---
name: conn [3115,3119]
name: conn [2574,2578]
===
match
---
operator: , [8219,8220]
operator: , [7678,7679]
===
match
---
string: "data" [6819,6825]
string: "data" [6278,6284]
===
match
---
dictorsetmaker [6787,6815]
dictorsetmaker [6246,6274]
===
match
---
string: "***" [6696,6701]
string: "***" [6155,6160]
===
match
---
trailer [9709,9716]
trailer [9168,9175]
===
match
---
trailer [2035,2040]
trailer [2035,2040]
===
match
---
import_from [965,1010]
import_from [965,1010]
===
match
---
trailer [9590,9600]
trailer [9049,9059]
===
match
---
name: logger [1033,1039]
name: logger [1033,1039]
===
match
---
atom [5652,5690]
atom [5111,5149]
===
match
---
simple_stmt [837,847]
simple_stmt [837,847]
===
match
---
name: addFilter [1842,1851]
name: addFilter [1842,1851]
===
match
---
name: sensitive_variable_fields [9116,9141]
name: sensitive_variable_fields [8575,8600]
===
match
---
operator: , [6676,6677]
operator: , [6135,6136]
===
match
---
atom [6319,7436]
atom [5778,6895]
===
match
---
name: pytest [7957,7963]
name: pytest [7416,7422]
===
match
---
name: set [5955,5958]
name: set [5414,5417]
===
match
---
param [8267,8272]
param [7726,7731]
===
match
---
name: caplog [3081,3087]
name: caplog [2540,2546]
===
match
---
name: utils [8986,8991]
name: utils [8445,8450]
===
match
---
operator: } [5771,5772]
operator: } [5230,5231]
===
match
---
name: xfail [4102,4107]
name: xfail [3561,3566]
===
match
---
operator: , [6560,6561]
operator: , [6019,6020]
===
match
---
simple_stmt [5010,5356]
simple_stmt [4469,4815]
===
match
---
operator: , [8797,8798]
operator: , [8256,8257]
===
match
---
string: "expected_mask" [5413,5428]
string: "expected_mask" [4872,4887]
===
match
---
trailer [7901,7910]
trailer [7360,7369]
===
match
---
atom_expr [3279,3287]
atom_expr [2738,2746]
===
match
---
name: logging [1053,1060]
name: logging [1053,1060]
===
match
---
atom_expr [6031,6036]
atom_expr [5490,5495]
===
match
---
name: key [9267,9270]
name: key [8726,8729]
===
match
---
operator: + [9572,9573]
operator: + [9031,9032]
===
match
---
string: "key" [8430,8435]
string: "key" [7889,7894]
===
match
---
simple_stmt [1835,1858]
simple_stmt [1835,1858]
===
match
---
name: formatter [1621,1630]
name: formatter [1621,1630]
===
match
---
dictorsetmaker [6828,6843]
dictorsetmaker [6287,6302]
===
match
---
parameters [1955,1977]
parameters [1955,1977]
===
match
---
name: info [2923,2927]
name: info [2382,2386]
===
match
---
operator: , [5691,5692]
operator: , [5150,5151]
===
match
---
name: RuntimeError [4922,4934]
name: RuntimeError [4381,4393]
===
match
---
name: name [7630,7634]
name: name [7089,7093]
===
match
---
trailer [9322,9324]
trailer [8781,8783]
===
match
---
name: textwrap [3323,3331]
name: textwrap [2782,2790]
===
match
---
operator: , [2143,2144]
operator: , [2143,2144]
===
match
---
atom_expr [2995,3006]
atom_expr [2454,2465]
===
match
---
name: caplog [1726,1732]
name: caplog [1726,1732]
===
match
---
string: 'conn' [2953,2959]
string: 'conn' [2412,2418]
===
match
---
operator: , [7358,7359]
operator: , [6817,6818]
===
match
---
operator: , [7393,7394]
operator: , [6852,6853]
===
match
---
name: logging [9351,9358]
name: logging [8810,8817]
===
match
---
operator: , [6174,6175]
operator: , [5633,5634]
===
match
---
dotted_name [4090,4107]
dotted_name [3549,3566]
===
match
---
operator: == [7819,7821]
operator: == [7278,7280]
===
match
---
name: test_extra [2779,2789]
name: test_extra [2238,2248]
===
match
---
param [8909,8914]
param [8368,8373]
===
match
---
operator: , [7410,7411]
operator: , [6869,6870]
===
match
---
name: caplog [2092,2098]
name: caplog [2092,2098]
===
match
---
operator: , [1256,1257]
operator: , [1256,1257]
===
match
---
operator: { [6640,6641]
operator: { [6099,6100]
===
match
---
operator: , [5458,5459]
operator: , [4917,4918]
===
match
---
operator: == [6212,6214]
operator: == [5671,5673]
===
match
---
trailer [9716,9725]
trailer [9175,9184]
===
match
---
parameters [7463,7502]
parameters [6922,6961]
===
match
---
name: messages [7902,7910]
name: messages [7361,7369]
===
match
---
string: "password" [6591,6601]
string: "password" [6050,6060]
===
match
---
name: text [5024,5028]
name: text [4483,4487]
===
match
---
operator: , [7685,7686]
operator: , [7144,7145]
===
match
---
funcdef [6060,6229]
funcdef [5519,5688]
===
match
---
atom_expr [9280,9324]
atom_expr [8739,8783]
===
match
---
string: "val" [5653,5658]
string: "val" [5112,5117]
===
match
---
atom_expr [9351,9368]
atom_expr [8810,8827]
===
match
---
name: expected_mask [6100,6113]
name: expected_mask [5559,5572]
===
match
---
atom_expr [5032,5355]
atom_expr [4491,4814]
===
match
---
import_as_names [924,964]
import_as_names [924,964]
===
match
---
name: handle [7805,7811]
name: handle [7264,7270]
===
match
---
operator: { [7376,7377]
operator: { [6835,6836]
===
match
---
name: log [8992,8995]
name: log [8451,8454]
===
match
---
operator: } [1551,1552]
operator: } [1551,1552]
===
match
---
name: expected_result [9222,9237]
name: expected_result [8681,8696]
===
match
---
name: val [7547,7550]
name: val [7006,7009]
===
match
---
string: "secret" [6828,6836]
string: "secret" [6287,6295]
===
match
---
parameters [3066,3088]
parameters [2525,2547]
===
match
---
operator: } [6608,6609]
operator: } [6067,6068]
===
match
---
string: "nested" [7095,7103]
string: "nested" [6554,6562]
===
match
---
name: patterns [7470,7478]
name: patterns [6929,6937]
===
match
---
atom [6786,6816]
atom [6245,6275]
===
match
---
string: 'handlers' [1128,1138]
string: 'handlers' [1128,1138]
===
match
---
name: get_sensitive_variables_fields [9158,9188]
name: get_sensitive_variables_fields [8617,8647]
===
match
---
dictorsetmaker [5694,5709]
dictorsetmaker [5153,5168]
===
match
---
string: 'password' [1877,1887]
string: 'password' [1877,1887]
===
match
---
testlist_comp [6963,7121]
testlist_comp [6422,6580]
===
match
---
name: mark [7964,7968]
name: mark [7423,7427]
===
match
---
name: open [7740,7744]
name: open [7199,7203]
===
match
---
dictorsetmaker [5983,5997]
dictorsetmaker [5442,5456]
===
match
---
string: "w" [7758,7761]
string: "w" [7217,7220]
===
match
---
operator: { [5516,5517]
operator: { [4975,4976]
===
match
---
dictorsetmaker [7304,7357]
dictorsetmaker [6763,6816]
===
match
---
operator: , [937,938]
operator: , [937,938]
===
match
---
atom_expr [3156,3197]
atom_expr [2615,2656]
===
match
---
operator: , [1960,1961]
operator: , [1960,1961]
===
match
---
name: self [3685,3689]
name: self [3144,3148]
===
match
---
trailer [1650,1679]
trailer [1650,1679]
===
match
---
decorated [5361,6229]
decorated [4820,5688]
===
match
---
testlist_comp [8159,8181]
testlist_comp [7618,7640]
===
match
---
operator: { [1168,1169]
operator: { [1168,1169]
===
match
---
operator: { [6544,6545]
operator: { [6003,6004]
===
match
---
simple_stmt [9622,9676]
simple_stmt [9081,9135]
===
match
---
simple_stmt [8973,9049]
simple_stmt [8432,8508]
===
match
---
operator: { [6457,6458]
operator: { [5916,5917]
===
match
---
operator: , [5481,5482]
operator: , [4940,4941]
===
match
---
testlist_comp [8480,8505]
testlist_comp [7939,7964]
===
match
---
operator: = [3277,3278]
operator: = [2736,2737]
===
match
---
atom [6571,6609]
atom [6030,6068]
===
match
---
name: parametrize [8379,8390]
name: parametrize [7838,7849]
===
match
---
parameters [2077,2099]
parameters [2077,2099]
===
match
---
operator: , [3689,3690]
operator: , [3148,3149]
===
match
---
operator: , [5620,5621]
operator: , [5079,5080]
===
match
---
operator: , [9455,9456]
operator: , [8914,8915]
===
match
---
operator: { [1088,1089]
operator: { [1088,1089]
===
match
---
atom_expr [7519,7534]
atom_expr [6978,6993]
===
match
---
trailer [9546,9554]
trailer [9005,9013]
===
match
---
name: textwrap [3975,3983]
name: textwrap [3434,3442]
===
match
---
atom_expr [9241,9271]
atom_expr [8700,8730]
===
match
---
name: formatException [9496,9511]
name: formatException [8955,8970]
===
match
---
decorator [1013,1029]
decorator [1013,1029]
===
match
---
fstring [3352,3639]
fstring [2811,3098]
===
match
---
import_name [785,799]
import_name [785,799]
===
match
---
name: logging [1467,1474]
name: logging [1467,1474]
===
match
---
name: TestShouldHideValueForKey [7925,7950]
name: TestShouldHideValueForKey [7384,7409]
===
match
---
arglist [2928,2977]
arglist [2387,2436]
===
match
---
atom_expr [1835,1857]
atom_expr [1835,1857]
===
match
---
string: 'core' [9075,9081]
string: 'core' [8534,8540]
===
match
---
atom_expr [4948,4971]
atom_expr [4407,4430]
===
match
---
name: logger [2109,2115]
name: logger [2109,2115]
===
match
---
trailer [1700,1710]
trailer [1700,1710]
===
match
---
atom_expr [1815,1830]
atom_expr [1815,1830]
===
match
---
operator: , [8551,8552]
operator: , [8010,8011]
===
match
---
atom [8609,8645]
atom [8068,8104]
===
match
---
operator: { [5933,5934]
operator: { [5392,5393]
===
match
---
arglist [2121,2160]
arglist [2121,2160]
===
match
---
dotted_name [970,993]
dotted_name [970,993]
===
match
---
simple_stmt [847,863]
simple_stmt [847,863]
===
match
---
operator: { [5982,5983]
operator: { [5441,5442]
===
match
---
string: 'key' [8480,8485]
string: 'key' [7939,7944]
===
match
---
atom [7078,7120]
atom [6537,6579]
===
match
---
param [8915,8941]
param [8374,8400]
===
match
---
return_stmt [9530,9601]
return_stmt [8989,9060]
===
match
---
operator: , [8230,8231]
operator: , [7689,7690]
===
match
---
name: textwrap [854,862]
name: textwrap [854,862]
===
match
---
name: exc_info [9512,9520]
name: exc_info [8971,8979]
===
match
---
operator: , [8638,8639]
operator: , [8097,8098]
===
match
---
param [2790,2795]
param [2249,2254]
===
match
---
atom [5982,5998]
atom [5441,5457]
===
match
---
operator: , [8144,8145]
operator: , [7603,7604]
===
match
---
name: logging [807,814]
name: logging [807,814]
===
match
---
string: "foo" [6519,6524]
string: "foo" [5978,5983]
===
match
---
testlist_comp [8401,8454]
testlist_comp [7860,7913]
===
match
---
expr_stmt [1684,1720]
expr_stmt [1684,1720]
===
match
---
operator: { [5652,5653]
operator: { [5111,5112]
===
match
---
dictorsetmaker [1102,1600]
dictorsetmaker [1102,1600]
===
match
---
name: caplog [2178,2184]
name: caplog [2178,2184]
===
match
---
testlist_comp [9075,9109]
testlist_comp [8534,8568]
===
match
---
atom [6268,6309]
atom [5727,5768]
===
match
---
operator: , [7425,7426]
operator: , [6884,6885]
===
match
---
name: airflow [8978,8985]
name: airflow [8437,8444]
===
match
---
operator: , [6649,6650]
operator: , [6108,6109]
===
match
---
assert_stmt [8304,8360]
assert_stmt [7763,7819]
===
match
---
simple_stmt [2916,2979]
simple_stmt [2375,2438]
===
match
---
name: logger [4948,4954]
name: logger [4407,4413]
===
match
---
name: pytest [871,877]
name: pytest [871,877]
===
match
---
name: logger [1987,1993]
name: logger [1987,1993]
===
match
---
name: patterns [7554,7562]
name: patterns [7013,7021]
===
match
---
string: "innoent" [5943,5952]
string: "innoent" [5402,5411]
===
match
---
comparison [6198,6228]
comparison [5657,5687]
===
match
---
string: 'token' [8776,8783]
string: 'token' [8235,8242]
===
match
---
param [3081,3087]
param [2540,2546]
===
match
---
name: RuntimeError [4859,4871]
name: RuntimeError [4318,4330]
===
match
---
operator: , [8106,8107]
operator: , [7565,7566]
===
match
---
string: "Cannot connect" [2928,2944]
string: "Cannot connect" [2387,2403]
===
match
---
assert_stmt [3953,4083]
assert_stmt [3412,3542]
===
match
---
atom_expr [6198,6211]
atom_expr [5657,5670]
===
match
---
comparison [7611,7647]
comparison [7070,7106]
===
match
---
string: "apikey" [6545,6553]
string: "apikey" [6004,6012]
===
match
---
atom [6640,6659]
atom [6099,6118]
===
match
---
suite [3707,4084]
suite [3166,3543]
===
match
---
string: "secret" [6468,6476]
string: "secret" [5927,5935]
===
match
---
name: fixture [1021,1028]
name: fixture [1021,1028]
===
match
---
operator: , [1479,1480]
operator: , [1479,1480]
===
match
---
atom_expr [3239,3262]
atom_expr [2698,2721]
===
match
---
atom_expr [1863,1888]
atom_expr [1863,1888]
===
match
---
suite [7503,7648]
suite [6962,7107]
===
match
---
atom [6334,6344]
atom [5793,5803]
===
match
---
testlist_comp [8521,8550]
testlist_comp [7980,8009]
===
match
---
param [3073,3080]
param [2532,2539]
===
match
---
string: "***" [7088,7093]
string: "***" [6547,6552]
===
match
---
name: caplog [2029,2035]
name: caplog [2029,2035]
===
match
---
operator: } [6343,6344]
operator: } [5802,5803]
===
match
---
testlist_comp [5976,6005]
testlist_comp [5435,5464]
===
match
---
suite [1978,2059]
suite [1978,2059]
===
match
---
name: name [7480,7484]
name: name [6939,6943]
===
match
---
operator: } [5689,5690]
operator: } [5148,5149]
===
match
---
string: "secret" [6352,6360]
string: "secret" [5811,5819]
===
match
---
testlist_comp [6400,6611]
testlist_comp [5859,6070]
===
match
---
trailer [7615,7622]
trailer [7074,7081]
===
match
---
atom_expr [2852,2907]
atom_expr [2311,2366]
===
match
---
expr_stmt [7704,7726]
expr_stmt [7163,7185]
===
match
---
string: "name" [6281,6287]
string: "name" [5740,5746]
===
match
---
operator: , [6098,6099]
operator: , [5557,5558]
===
match
---
dictorsetmaker [6488,6524]
dictorsetmaker [5947,5983]
===
match
---
name: caplog [2995,3001]
name: caplog [2454,2460]
===
match
---
trailer [3338,3649]
trailer [2797,3108]
===
match
---
simple_stmt [6124,6147]
simple_stmt [5583,5606]
===
match
---
string: "value" [5404,5411]
string: "value" [4863,4870]
===
match
---
name: handlers [2828,2836]
name: handlers [2287,2295]
===
match
---
operator: , [2082,2083]
operator: , [2082,2083]
===
match
---
atom_expr [3323,3649]
atom_expr [2782,3108]
===
match
---
trailer [3255,3262]
trailer [2714,2721]
===
match
---
atom [6487,6525]
atom [5946,5984]
===
match
---
string: "user:password" [2145,2160]
string: "user:password" [2145,2160]
===
match
---
operator: , [6048,6049]
operator: , [5507,5508]
===
match
---
name: caplog [7687,7693]
name: caplog [7146,7152]
===
match
---
string: "key" [8093,8098]
string: "key" [7552,7557]
===
match
---
atom [5495,5527]
atom [4954,4986]
===
match
---
string: """Don't include full path in exc_info messages""" [9375,9425]
string: """Don't include full path in exc_info messages""" [8834,8884]
===
match
---
dictorsetmaker [6819,6844]
dictorsetmaker [6278,6303]
===
match
---
operator: } [1338,1339]
operator: } [1338,1339]
===
match
---
simple_stmt [1684,1721]
simple_stmt [1684,1721]
===
match
---
string: "Err" [3256,3261]
string: "Err" [2715,2720]
===
match
---
trailer [9115,9142]
trailer [8574,8601]
===
match
---
string: "foo" [5684,5689]
string: "foo" [5143,5148]
===
match
---
param [4186,4193]
param [3645,3652]
===
match
---
try_stmt [4836,4972]
try_stmt [4295,4431]
===
match
---
fstring_expr [5190,5196]
fstring_expr [4649,4655]
===
match
---
suite [1048,1908]
suite [1048,1908]
===
match
---
trailer [3285,3287]
trailer [2744,2746]
===
match
---
atom [8158,8182]
atom [7617,7641]
===
match
---
parameters [8266,8294]
parameters [7725,7753]
===
match
---
string: 'key' [8566,8571]
string: 'key' [8025,8030]
===
match
---
simple_stmt [7512,7535]
simple_stmt [6971,6994]
===
match
---
atom [5732,5751]
atom [5191,5210]
===
match
---
trailer [5958,5960]
trailer [5417,5419]
===
match
---
trailer [3966,3971]
trailer [3425,3430]
===
match
---
trailer [3331,3338]
trailer [2790,2797]
===
match
---
string: """         Show it is not possible to filter secrets in the source.          It is not possible to (regularly/reliably) filter out secrets that         appear directly in the source code. This is because the formatting of         exc_info is not done in the filter, it is done after the filter is         called, and fixing this "properly" is hard/impossible.          (It would likely need to construct a custom traceback that changed the         source. I have no idead if that is even possible)          This test illustrates that, but ix marked xfail in case someone wants to         fix this later.         """ [4211,4827]
string: """         Show it is not possible to filter secrets in the source.          It is not possible to (regularly/reliably) filter out secrets that         appear directly in the source code. This is because the formatting of         exc_info is not done in the filter, it is done after the filter is         called, and fixing this "properly" is hard/impossible.          (It would likely need to construct a custom traceback that changed the         source. I have no idead if that is even possible)          This test illustrates that, but ix marked xfail in case someone wants to         fix this later.         """ [3670,4286]
===
match
---
testlist_comp [8735,8760]
testlist_comp [8194,8219]
===
match
---
simple_stmt [6155,6182]
simple_stmt [5614,5641]
===
match
---
name: info [1994,1998]
name: info [1994,1998]
===
match
---
trailer [9266,9271]
trailer [8725,8730]
===
match
---
simple_stmt [6191,6229]
simple_stmt [5650,5688]
===
match
---
atom [1140,1339]
atom [1140,1339]
===
match
---
operator: , [7756,7757]
operator: , [7215,7216]
===
match
---
atom_expr [4859,4906]
atom_expr [4318,4365]
===
match
---
funcdef [3655,4084]
funcdef [3114,3543]
===
match
---
operator: , [8739,8740]
operator: , [8198,8199]
===
match
---
name: filt [1863,1867]
name: filt [1863,1867]
===
match
---
param [6100,6113]
param [5559,5572]
===
match
---
decorated [7956,8361]
decorated [7415,7820]
===
match
---
atom_expr [2916,2978]
atom_expr [2375,2437]
===
match
---
import_from [879,964]
import_from [879,964]
===
match
---
name: expected_result [8311,8326]
name: expected_result [7770,7785]
===
match
---
operator: , [8713,8714]
operator: , [8172,8173]
===
match
---
name: textwrap [5032,5040]
name: textwrap [4491,4499]
===
match
---
testlist_comp [6759,6845]
testlist_comp [6218,6304]
===
match
---
atom [8775,8805]
atom [8234,8264]
===
match
---
atom [8659,8720]
atom [8118,8179]
===
match
---
decorator [8366,8882]
decorator [7825,8341]
===
match
---
trailer [6202,6211]
trailer [5661,5670]
===
match
---
arglist [7990,8231]
arglist [7449,7690]
===
match
---
string: "val" [6488,6493]
string: "val" [5947,5952]
===
match
---
name: test_exception [3052,3066]
name: test_exception [2511,2525]
===
match
---
operator: , [5411,5412]
operator: , [4870,4871]
===
match
---
name: set [6031,6034]
name: set [5490,5493]
===
match
---
string: "other" [5934,5941]
string: "other" [5393,5400]
===
match
---
name: mark [4097,4101]
name: mark [3556,3560]
===
match
---
simple_stmt [3953,4084]
simple_stmt [3412,3543]
===
match
---
operator: , [3079,3080]
operator: , [2538,2539]
===
match
---
simple_stmt [815,837]
simple_stmt [815,837]
===
match
---
import_name [815,836]
import_name [815,836]
===
match
---
dotted_name [6235,6258]
dotted_name [5694,5717]
===
match
---
name: SecretsMasker [6131,6144]
name: SecretsMasker [5590,5603]
===
match
---
operator: , [6816,6817]
operator: , [6275,6276]
===
match
---
operator: , [8428,8429]
operator: , [7887,7888]
===
match
---
string: "innocent" [6495,6505]
string: "innocent" [5954,5964]
===
match
---
atom_expr [7576,7594]
atom_expr [7035,7053]
===
match
---
string: "Err" [3937,3942]
string: "Err" [3396,3401]
===
match
---
atom_expr [9537,9601]
atom_expr [8996,9060]
===
match
---
operator: = [1631,1632]
operator: = [1631,1632]
===
match
---
fstring_string: \             ERROR Err             Traceback (most recent call last):               File ".../test_secrets_masker.py", line  [5065,5190]
fstring_string: \             ERROR Err             Traceback (most recent call last):               File ".../test_secrets_masker.py", line  [4524,4649]
===
match
---
atom [5516,5526]
atom [4975,4985]
===
match
---
operator: = [7709,7710]
operator: = [7168,7169]
===
match
---
atom [2952,2977]
atom [2411,2436]
===
match
---
operator: , [8043,8044]
operator: , [7502,7503]
===
match
---
string: "secret" [6796,6804]
string: "secret" [6255,6263]
===
match
---
operator: , [6296,6297]
operator: , [5755,5756]
===
match
---
string: "***" [6838,6843]
string: "***" [6297,6302]
===
match
---
atom_expr [6000,6005]
atom_expr [5459,5464]
===
match
---
operator: } [6524,6525]
operator: } [5983,5984]
===
match
---
string: "apikey" [5623,5631]
string: "apikey" [5082,5090]
===
match
---
operator: , [6784,6785]
operator: , [6243,6244]
===
match
---
string: 'TRELLO_KEY' [8785,8797]
string: 'TRELLO_KEY' [8244,8256]
===
match
---
name: setFormatter [1741,1753]
name: setFormatter [1741,1753]
===
match
---
string: "password" [5983,5993]
string: "password" [5442,5452]
===
match
---
trailer [5040,5047]
trailer [4499,4506]
===
match
---
operator: , [5429,5430]
operator: , [4888,4889]
===
match
---
atom_expr [6131,6146]
atom_expr [5590,5605]
===
match
---
atom [7149,7425]
atom [6608,6884]
===
match
---
name: mark [8374,8378]
name: mark [7833,7837]
===
match
---
fstring_start: f""" [5061,5065]
fstring_start: f""" [4520,4524]
===
match
---
operator: , [2802,2803]
operator: , [2261,2262]
===
match
---
testlist_comp [6334,6367]
testlist_comp [5793,5826]
===
match
---
operator: , [7135,7136]
operator: , [6594,6595]
===
match
---
arith_expr [4988,5000]
arith_expr [4447,4459]
===
match
---
trailer [7724,7726]
trailer [7183,7185]
===
match
---
operator: , [6091,6092]
operator: , [5550,5551]
===
match
---
assert_stmt [3301,3649]
assert_stmt [2760,3108]
===
match
---
string: "other" [6770,6777]
string: "other" [6229,6236]
===
match
---
name: RuntimeError [3156,3168]
name: RuntimeError [2615,2627]
===
match
---
trailer [3983,3990]
trailer [3442,3449]
===
match
---
trailer [9493,9495]
trailer [8952,8954]
===
match
---
simple_stmt [800,815]
simple_stmt [800,815]
===
match
---
import_name [800,814]
import_name [800,814]
===
match
---
atom [9073,9143]
atom [8532,8602]
===
match
---
trailer [2922,2927]
trailer [2381,2386]
===
match
---
atom_expr [1467,1479]
atom_expr [1467,1479]
===
match
---
name: logger [1769,1775]
name: logger [1769,1775]
===
match
---
expr_stmt [6124,6146]
expr_stmt [5583,5605]
===
match
---
trailer [9310,9322]
trailer [8769,8781]
===
match
---
param [7480,7485]
param [6939,6944]
===
match
---
operator: , [8485,8486]
operator: , [7944,7945]
===
match
---
argument [4108,4158]
argument [3567,3617]
===
match
---
funcdef [2775,3043]
funcdef [2234,2502]
===
match
---
simple_stmt [785,800]
simple_stmt [785,800]
===
match
---
string: "api_key" [5922,5931]
string: "api_key" [5381,5390]
===
match
---
string: "api_key" [6991,7000]
string: "api_key" [6450,6459]
===
match
---
operator: , [5711,5712]
operator: , [5170,5171]
===
match
---
suite [3089,3650]
suite [2548,3109]
===
match
---
param [1970,1976]
param [1970,1976]
===
match
---
string: "nested" [7039,7047]
string: "nested" [6498,6506]
===
match
---
param [8278,8293]
param [7737,7752]
===
match
---
atom_expr [1053,1616]
atom_expr [1053,1616]
===
match
---
operator: { [9073,9074]
operator: { [8532,8533]
===
match
---
trailer [9581,9590]
trailer [9040,9049]
===
match
---
return_stmt [1894,1907]
return_stmt [1894,1907]
===
match
---
string: "secret" [6641,6649]
string: "secret" [6100,6108]
===
match
---
testlist_comp [6333,7426]
testlist_comp [5792,6885]
===
match
---
operator: , [7120,7121]
operator: , [6579,6580]
===
match
---
name: logger [4186,4192]
name: logger [3645,3651]
===
match
---
name: key [8942,8945]
name: key [8401,8404]
===
match
---
operator: { [6487,6488]
operator: { [5946,5947]
===
match
---
simple_stmt [1987,2013]
simple_stmt [1987,2013]
===
match
---
atom [5975,6006]
atom [5434,5465]
===
match
---
name: conf_vars [1001,1010]
name: conf_vars [1001,1010]
===
match
---
operator: { [5622,5623]
operator: { [5081,5082]
===
match
---
simple_stmt [3150,3198]
simple_stmt [2609,2657]
===
match
---
parameters [9614,9616]
parameters [9073,9075]
===
match
---
atom [7990,8016]
atom [7449,7475]
===
match
---
name: pytest [1014,1020]
name: pytest [1014,1020]
===
match
---
simple_stmt [7888,7917]
simple_stmt [7347,7376]
===
match
---
param [3691,3698]
param [3150,3157]
===
match
---
operator: , [8588,8589]
operator: , [8047,8048]
===
match
---
operator: , [7996,7997]
operator: , [7455,7456]
===
match
---
atom [8065,8078]
atom [7524,7537]
===
match
---
simple_stmt [965,1011]
simple_stmt [965,1011]
===
match
---
string: """\             ERROR Err             NoneType: None             """ [4004,4073]
string: """\             ERROR Err             NoneType: None             """ [3463,3532]
===
match
---
comparison [5017,5355]
comparison [4476,4814]
===
match
---
string: "other" [5764,5771]
string: "other" [5223,5230]
===
match
---
name: logger [2084,2090]
name: logger [2084,2090]
===
match
---
atom_expr [1987,2012]
atom_expr [1987,2012]
===
match
---
fstring_start: f""" [3352,3356]
fstring_start: f""" [2811,2815]
===
match
---
testlist_comp [5396,5428]
testlist_comp [4855,4887]
===
match
---
comparison [2029,2058]
comparison [2029,2058]
===
match
---
assert_stmt [5010,5355]
assert_stmt [4469,4814]
===
match
---
simple_stmt [1769,1804]
simple_stmt [1769,1804]
===
match
---
operator: , [5741,5742]
operator: , [5200,5201]
===
match
---
name: text [2036,2040]
name: text [2036,2040]
===
match
---
string: "innoent" [7028,7037]
string: "innoent" [6487,6496]
===
match
---
fstring_string: , in test_exc_tb                 raise RuntimeError("Cannot connect to user:***)             RuntimeError: Cannot connect to user:***              [5196,5342]
fstring_string: , in test_exc_tb                 raise RuntimeError("Cannot connect to user:***)             RuntimeError: Cannot connect to user:***              [4655,4801]
===
match
---
trailer [7260,7262]
trailer [6719,6721]
===
match
---
operator: } [2976,2977]
operator: } [2435,2436]
===
match
---
atom [6457,6526]
atom [5916,5985]
===
match
---
name: logger [3239,3245]
name: logger [2698,2704]
===
match
---
comparison [3308,3649]
comparison [2767,3108]
===
match
---
name: config [830,836]
name: config [830,836]
===
match
---
expr_stmt [3115,3137]
expr_stmt [2574,2596]
===
match
---
operator: } [1324,1325]
operator: } [1324,1325]
===
match
---
name: str [9112,9115]
name: str [8571,8574]
===
match
---
testlist_comp [8040,8220]
testlist_comp [7499,7679]
===
match
---
atom [6860,7135]
atom [6319,6594]
===
match
---
testlist_comp [6269,6308]
testlist_comp [5728,5767]
===
match
---
operator: , [6439,6440]
operator: , [5898,5899]
===
match
---
testlist_comp [5496,5526]
testlist_comp [4955,4985]
===
match
---
funcdef [8242,8361]
funcdef [7701,7820]
===
match
---
simple_stmt [1053,1617]
simple_stmt [1053,1617]
===
match
---
operator: } [6658,6659]
operator: } [6117,6118]
===
match
---
operator: , [6665,6666]
operator: , [6124,6125]
===
match
---
operator: , [8212,8213]
operator: , [7671,7672]
===
match
---
atom [5753,5772]
atom [5212,5231]
===
match
---
trailer [1841,1851]
trailer [1841,1851]
===
match
---
dictorsetmaker [6760,6777]
dictorsetmaker [6219,6236]
===
match
---
string: 'sensitive_var_conn_names' [9083,9109]
string: 'sensitive_var_conn_names' [8542,8568]
===
match
---
name: expected [7493,7501]
name: expected [6952,6960]
===
match
---
name: self [2078,2082]
name: self [2078,2082]
===
match
---
name: set [7257,7260]
name: set [6716,6719]
===
match
---
operator: , [5980,5981]
operator: , [5439,5440]
===
match
---
string: "%(levelname)s %(message)s" [1651,1678]
string: "%(levelname)s %(message)s" [1651,1678]
===
match
---
string: 'TRELLO_KEY' [8843,8855]
string: 'TRELLO_KEY' [8302,8314]
===
match
---
string: "GOOGLE_API_KEY" [8159,8175]
string: "GOOGLE_API_KEY" [7618,7634]
===
match
---
atom [5395,5429]
atom [4854,4888]
===
match
---
atom [8479,8506]
atom [7938,7965]
===
match
---
comparison [2995,3042]
comparison [2454,2501]
===
match
---
param [6081,6086]
param [5540,5545]
===
match
---
param [7681,7686]
param [7140,7145]
===
match
---
name: filt [6155,6159]
name: filt [5614,5618]
===
match
---
funcdef [1939,2059]
funcdef [1939,2059]
===
match
---
name: should_hide_value_for_key [939,964]
name: should_hide_value_for_key [939,964]
===
match
---
funcdef [7448,7648]
funcdef [6907,7107]
===
match
---
name: mark [5369,5373]
name: mark [4828,4832]
===
match
---
operator: , [6287,6288]
operator: , [5746,5747]
===
match
---
trailer [1067,1078]
trailer [1067,1078]
===
match
---
operator: , [6025,6026]
operator: , [5484,5485]
===
match
---
operator: , [1114,1115]
operator: , [1114,1115]
===
match
---
operator: , [1339,1340]
operator: , [1339,1340]
===
match
---
atom [5622,5691]
atom [5081,5150]
===
match
---
funcdef [4164,5356]
funcdef [3623,4815]
===
match
---
name: self [7681,7685]
name: self [7140,7144]
===
match
---
operator: , [1436,1437]
operator: , [1436,1437]
===
match
---
dictorsetmaker [6796,6814]
dictorsetmaker [6255,6273]
===
match
---
operator: { [5470,5471]
operator: { [4929,4930]
===
match
---
trailer [6034,6036]
trailer [5493,5495]
===
match
---
name: utils [892,897]
name: utils [892,897]
===
match
---
name: SecretsMasker [7519,7532]
name: SecretsMasker [6978,6991]
===
match
---
name: test_message [1943,1955]
name: test_message [1943,1955]
===
match
---
atom [8819,8863]
atom [8278,8322]
===
match
---
trailer [9188,9200]
trailer [8647,8659]
===
match
---
string: "secret" [5471,5479]
string: "secret" [4930,4938]
===
match
---
fstring [5061,5345]
fstring [4520,4804]
===
match
---
comparison [3960,4083]
comparison [3419,3542]
===
match
---
try_stmt [3098,3263]
try_stmt [2557,2722]
===
match
---
operator: , [5504,5505]
operator: , [4963,4964]
===
match
---
name: text [3002,3006]
name: text [2461,2465]
===
match
---
operator: , [1552,1553]
operator: , [1552,1553]
===
match
---
simple_stmt [9476,9522]
simple_stmt [8935,8981]
===
match
---
testlist_comp [6689,6701]
testlist_comp [6148,6160]
===
match
---
assert_stmt [7786,7828]
assert_stmt [7245,7287]
===
match
---
param [7486,7492]
param [6945,6951]
===
match
---
operator: , [8913,8914]
operator: , [8372,8373]
===
match
---
name: dedent [3332,3338]
name: dedent [2791,2797]
===
match
---
operator: == [3007,3009]
operator: == [2466,2468]
===
match
---
operator: { [1140,1141]
operator: { [1140,1141]
===
match
---
trailer [1732,1740]
trailer [1732,1740]
===
match
---
name: ShortExcFormatter [2852,2869]
name: ShortExcFormatter [2311,2328]
===
match
---
string: 'foo' [7404,7409]
string: 'foo' [6863,6868]
===
match
---
atom_expr [9687,9725]
atom_expr [9146,9184]
===
match
---
name: key [8356,8359]
name: key [7815,7818]
===
match
---
comparison [7895,7916]
comparison [7354,7375]
===
match
---
operator: } [3486,3487]
operator: } [2945,2946]
===
match
---
simple_stmt [3272,3292]
simple_stmt [2731,2751]
===
match
---
operator: { [3481,3482]
operator: { [2940,2941]
===
match
---
testlist_comp [6021,6036]
testlist_comp [5480,5495]
===
match
---
operator: , [7111,7112]
operator: , [6570,6571]
===
match
---
operator: , [5670,5671]
operator: , [5129,5130]
===
match
---
name: text [2185,2189]
name: text [2185,2189]
===
match
---
arglist [7805,7817]
arglist [7264,7276]
===
match
---
string: "secret" [5506,5514]
string: "secret" [4965,4973]
===
match
---
operator: { [2952,2953]
operator: { [2411,2412]
===
match
---
operator: , [9081,9082]
operator: , [8540,8541]
===
match
---
param [1040,1046]
param [1040,1046]
===
match
---
fstring_string: , in test_exception                 raise RuntimeError("Cannot connect to " + conn)             RuntimeError: Cannot connect to user:***              [3487,3636]
fstring_string: , in test_exception                 raise RuntimeError("Cannot connect to " + conn)             RuntimeError: Cannot connect to user:***              [2946,3095]
===
match
---
name: ShortExcFormatter [1633,1650]
name: ShortExcFormatter [1633,1650]
===
match
---
name: get_sensitive_variables_fields [9280,9310]
name: get_sensitive_variables_fields [8739,8769]
===
match
---
name: dictConfig [1068,1078]
name: dictConfig [1068,1078]
===
match
---
operator: } [7059,7060]
operator: } [6518,6519]
===
match
---
return_stmt [9680,9725]
return_stmt [9139,9184]
===
match
---
operator: , [5961,5962]
operator: , [5420,5421]
===
match
---
string: '' [8041,8043]
string: '' [7500,7502]
===
match
---
operator: , [7811,7812]
operator: , [7270,7271]
===
match
---
name: lineno [9608,9614]
name: lineno [9067,9073]
===
match
---
expr_stmt [1621,1679]
expr_stmt [1621,1679]
===
match
---
testlist_comp [5454,5480]
testlist_comp [4913,4939]
===
match
---
string: 'level' [1458,1465]
string: 'level' [1458,1465]
===
match
---
operator: , [6085,6086]
operator: , [5544,5545]
===
match
---
name: redact [7616,7622]
name: redact [7075,7081]
===
match
---
operator: , [8455,8456]
operator: , [7914,7915]
===
match
---
name: os [844,846]
name: os [844,846]
===
match
---
param [2804,2810]
param [2263,2269]
===
match
---
trailer [9707,9709]
trailer [9166,9168]
===
match
---
name: handler [1733,1740]
name: handler [1733,1740]
===
match
---
arith_expr [9565,9600]
arith_expr [9024,9059]
===
match
---
name: test_exception_not_raised [3659,3684]
name: test_exception_not_raised [3118,3143]
===
match
---
name: test_exc_tb [4168,4179]
name: test_exc_tb [3627,3638]
===
match
---
parameters [9450,9466]
parameters [8909,8925]
===
match
---
name: formatted [9476,9485]
name: formatted [8935,8944]
===
match
---
name: self [2790,2794]
name: self [2249,2253]
===
match
---
expr_stmt [1769,1803]
expr_stmt [1769,1803]
===
match
---
trailer [2115,2120]
trailer [2115,2120]
===
match
---
import_name [837,846]
import_name [837,846]
===
match
---
atom [6827,6844]
atom [6286,6303]
===
match
---
operator: == [2190,2192]
operator: == [2190,2192]
===
match
---
parameters [1039,1047]
parameters [1039,1047]
===
match
---
name: logger [1835,1841]
name: logger [1835,1841]
===
match
---
operator: , [7478,7479]
operator: , [6937,6938]
===
match
---
name: caplog [1788,1794]
name: caplog [1788,1794]
===
match
---
operator: , [6309,6310]
operator: , [5768,5769]
===
match
---
suite [1934,7917]
suite [1934,7376]
===
delete-tree
---
funcdef [2234,2770]
    name: test_non_redactable [2238,2257]
    parameters [2257,2279]
        param [2258,2263]
            name: self [2258,2262]
            operator: , [2262,2263]
        param [2264,2271]
            name: logger [2264,2270]
            operator: , [2270,2271]
        param [2272,2278]
            name: caplog [2272,2278]
    suite [2280,2770]
        classdef [2289,2464]
            name: NonReactable [2295,2307]
            suite [2308,2464]
                funcdef [2321,2390]
                    name: __iter__ [2325,2333]
                    parameters [2333,2339]
                        param [2334,2338]
                            name: self [2334,2338]
                    suite [2340,2390]
                        simple_stmt [2357,2390]
                            raise_stmt [2357,2389]
                                atom_expr [2363,2389]
                                    name: RuntimeError [2363,2375]
                                    trailer [2375,2389]
                                        string: "force fail" [2376,2388]
                funcdef [2403,2464]
                    name: __repr__ [2407,2415]
                    parameters [2415,2421]
                        param [2416,2420]
                            name: self [2416,2420]
                    suite [2422,2464]
                        simple_stmt [2439,2464]
                            return_stmt [2439,2463]
                                string: "<NonRedactable>" [2446,2463]
        simple_stmt [2473,2515]
            atom_expr [2473,2514]
                name: logger [2473,2479]
                trailer [2479,2484]
                    name: info [2480,2484]
                trailer [2484,2514]
                    arglist [2485,2513]
                        string: "Logging %s" [2485,2497]
                        operator: , [2497,2498]
                        atom_expr [2499,2513]
                            name: NonReactable [2499,2511]
                            trailer [2511,2513]
        simple_stmt [2524,2770]
            assert_stmt [2524,2769]
                comparison [2531,2769]
                    atom_expr [2531,2546]
                        name: caplog [2531,2537]
                        trailer [2537,2546]
                            name: messages [2538,2546]
                    operator: == [2547,2549]
                    atom [2550,2769]
                        testlist_comp [2564,2759]
                            arith_expr [2564,2719]
                                string: "Unable to redact <NonRedactable>, please report this via " [2564,2623]
                                operator: + [2636,2637]
                                string: "<https://github.com/apache/airflow/issues>. Error was: RuntimeError: force fail" [2638,2719]
                            operator: , [2719,2720]
                            string: "Logging <NonRedactable>" [2733,2758]
                            operator: , [2758,2759]
