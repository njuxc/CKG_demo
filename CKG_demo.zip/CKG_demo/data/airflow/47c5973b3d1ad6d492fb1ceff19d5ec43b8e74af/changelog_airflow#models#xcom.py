===
match
---
name: dag_run [9639,9646]
name: dag_run [9670,9677]
===
match
---
if_stmt [12192,12283]
if_stmt [12223,12314]
===
match
---
trailer [9702,9711]
trailer [9733,9742]
===
match
---
trailer [9735,9737]
trailer [9766,9768]
===
match
---
dotted_name [1221,1242]
dotted_name [1221,1242]
===
match
---
atom_expr [8874,8897]
atom_expr [8905,8928]
===
match
---
trailer [13919,13936]
trailer [13950,13967]
===
match
---
expr_stmt [1420,1453]
expr_stmt [1420,1453]
===
match
---
name: dag_id [2984,2990]
name: dag_id [3015,3021]
===
match
---
trailer [1723,1772]
trailer [1723,1772]
===
match
---
import_from [1120,1180]
import_from [1120,1180]
===
match
---
atom_expr [12830,12877]
atom_expr [12861,12908]
===
match
---
trailer [2857,2861]
trailer [2888,2892]
===
match
---
string: "dag_run" [2489,2498]
string: "dag_run" [2520,2529]
===
match
---
name: serialize_value [12095,12110]
name: serialize_value [12126,12141]
===
match
---
simple_stmt [9689,9761]
simple_stmt [9720,9792]
===
match
---
string: " then you need to enable pickle support for XCom" [12561,12611]
string: " then you need to enable pickle support for XCom" [12592,12642]
===
match
---
name: timezone [1207,1215]
name: timezone [1207,1215]
===
match
---
string: 'UTF-8' [13043,13050]
string: 'UTF-8' [13074,13081]
===
match
---
comparison [8948,8969]
comparison [8979,9000]
===
match
---
name: task_id [2871,2878]
name: task_id [2902,2909]
===
match
---
operator: { [2882,2883]
operator: { [2913,2914]
===
match
---
name: cls [11992,11995]
name: cls [12023,12026]
===
match
---
operator: = [6722,6723]
operator: = [6753,6754]
===
match
---
parameters [3971,4321]
parameters [4002,4352]
===
match
---
name: key [6030,6033]
name: key [6061,6064]
===
match
---
expr_stmt [1683,1705]
expr_stmt [1683,1705]
===
match
---
name: append [8568,8574]
name: append [8599,8605]
===
match
---
name: value [12326,12331]
name: value [12357,12362]
===
match
---
name: TypeError [12377,12386]
name: TypeError [12408,12417]
===
match
---
decorator [3939,3956]
decorator [3970,3987]
===
match
---
operator: = [9492,9493]
operator: = [9523,9524]
===
match
---
trailer [6611,6616]
trailer [6642,6647]
===
match
---
trailer [12319,12325]
trailer [12350,12356]
===
match
---
try_stmt [12891,13053]
try_stmt [12922,13084]
===
match
---
name: dag_ids [8962,8969]
name: dag_ids [8993,9000]
===
match
---
trailer [12199,12210]
trailer [12230,12241]
===
match
---
name: filter [11694,11700]
name: filter [11725,11731]
===
match
---
suite [11821,11893]
suite [11852,11924]
===
match
---
atom_expr [4062,4075]
atom_expr [4093,4106]
===
match
---
operator: = [14134,14135]
operator: = [14165,14166]
===
match
---
string: "Could not serialize the XCom value into JSON." [12428,12475]
string: "Could not serialize the XCom value into JSON." [12459,12506]
===
match
---
name: __name__ [14059,14067]
name: __name__ [14090,14098]
===
match
---
trailer [12011,12036]
trailer [12042,12067]
===
match
---
simple_stmt [10114,10184]
simple_stmt [10145,10215]
===
match
---
name: execution_date [2992,3006]
name: execution_date [3023,3037]
===
match
---
name: result [6334,6340]
name: result [6365,6371]
===
match
---
fstring_expr [14009,14025]
fstring_expr [14040,14056]
===
match
---
suite [10054,10217]
suite [10085,10248]
===
match
---
trailer [13684,13702]
trailer [13715,13733]
===
match
---
operator: , [6662,6663]
operator: , [6693,6694]
===
match
---
name: dag_id [3876,3882]
name: dag_id [3907,3913]
===
match
---
trailer [13117,13147]
trailer [13148,13178]
===
match
---
xor_expr [5754,5797]
xor_expr [5785,5828]
===
match
---
name: DagRun [3374,3380]
name: DagRun [3405,3411]
===
match
---
param [6573,6626]
param [6604,6657]
===
match
---
name: delete [3720,3726]
name: delete [3751,3757]
===
match
---
trailer [12058,12065]
trailer [12089,12096]
===
match
---
expr_stmt [2761,2802]
expr_stmt [2792,2833]
===
match
---
name: execution_date [6440,6454]
name: execution_date [6471,6485]
===
match
---
suite [3176,3264]
suite [3207,3295]
===
match
---
name: Session [4300,4307]
name: Session [4331,4338]
===
match
---
not_test [3128,3175]
not_test [3159,3206]
===
match
---
operator: = [2033,2034]
operator: = [2033,2034]
===
match
---
simple_stmt [12046,12068]
simple_stmt [12077,12099]
===
match
---
name: pendulum [6465,6473]
name: pendulum [6496,6504]
===
match
---
param [3026,3038]
param [3057,3069]
===
match
---
trailer [12004,12011]
trailer [12035,12042]
===
match
---
operator: , [861,862]
operator: , [861,862]
===
match
---
arglist [2060,2110]
arglist [2060,2110]
===
match
---
name: sqlalchemy [901,911]
name: sqlalchemy [901,911]
===
match
---
trailer [12275,12282]
trailer [12306,12313]
===
match
---
trailer [9715,9730]
trailer [9746,9761]
===
match
---
trailer [9647,9654]
trailer [9678,9685]
===
match
---
trailer [13022,13052]
trailer [13053,13083]
===
match
---
operator: -> [13298,13300]
operator: -> [13329,13331]
===
match
---
operator: = [1560,1561]
operator: = [1560,1561]
===
match
---
atom_expr [13788,13879]
atom_expr [13819,13910]
===
match
---
operator: , [2982,2983]
operator: , [3013,3014]
===
match
---
name: ValueError [11589,11599]
name: ValueError [11620,11630]
===
match
---
name: task_id [8687,8694]
name: task_id [8718,8725]
===
match
---
tfpdef [4188,4231]
tfpdef [4219,4262]
===
match
---
trailer [9239,9305]
trailer [9270,9336]
===
match
---
trailer [12971,12987]
trailer [13002,13018]
===
match
---
expr_stmt [2462,2509]
expr_stmt [2493,2540]
===
match
---
trailer [8888,8897]
trailer [8919,8928]
===
match
---
arglist [2489,2508]
arglist [2520,2539]
===
match
---
name: self [2761,2765]
name: self [2792,2796]
===
match
---
atom_expr [8859,8898]
atom_expr [8890,8929]
===
match
---
funcdef [2808,2907]
funcdef [2839,2938]
===
match
---
atom_expr [12053,12067]
atom_expr [12084,12098]
===
match
---
name: value [13030,13035]
name: value [13061,13066]
===
match
---
name: DagRun [9655,9661]
name: DagRun [9686,9692]
===
match
---
atom_expr [6653,6678]
atom_expr [6684,6709]
===
match
---
name: airflow [1375,1382]
name: airflow [1375,1382]
===
match
---
number: 49344 [1562,1567]
number: 49344 [1562,1567]
===
match
---
raise_stmt [10114,10183]
raise_stmt [10145,10214]
===
match
---
argument [3859,3874]
argument [3890,3905]
===
match
---
name: cls [9439,9442]
name: cls [9470,9473]
===
match
---
tfpdef [10317,10360]
tfpdef [10348,10391]
===
match
---
if_stmt [6282,6342]
if_stmt [6313,6373]
===
match
---
simple_stmt [13227,13261]
simple_stmt [13258,13292]
===
match
---
operator: , [2020,2021]
operator: , [2020,2021]
===
match
---
parameters [2957,3039]
parameters [2988,3070]
===
match
---
trailer [3614,3618]
trailer [3645,3649]
===
match
---
name: delete [9904,9910]
name: delete [9935,9941]
===
match
---
if_stmt [11519,11658]
if_stmt [11550,11689]
===
match
---
operator: , [1166,1167]
operator: , [1166,1167]
===
match
---
trailer [3908,3914]
trailer [3939,3945]
===
match
---
import_name [800,814]
import_name [800,814]
===
match
---
trailer [6591,6618]
trailer [6622,6649]
===
match
---
expr_stmt [11667,11781]
expr_stmt [11698,11812]
===
match
---
operator: , [3625,3626]
operator: , [3656,3657]
===
match
---
atom [8528,8530]
atom [8559,8561]
===
match
---
decorated [3922,6362]
decorated [3953,6393]
===
match
---
return_stmt [12912,12945]
return_stmt [12943,12976]
===
match
---
import_from [1181,1215]
import_from [1181,1215]
===
match
---
name: task_ids [8774,8782]
name: task_ids [8805,8813]
===
match
---
operator: = [1424,1425]
operator: = [1424,1425]
===
match
---
name: with_entities [6218,6231]
name: with_entities [6249,6262]
===
match
---
trailer [10084,10096]
trailer [10115,10127]
===
match
---
suite [8804,8971]
suite [8835,9002]
===
match
---
operator: ^ [3157,3158]
operator: ^ [3188,3189]
===
match
---
suite [8651,8710]
suite [8682,8741]
===
match
---
atom_expr [4145,4170]
atom_expr [4176,4201]
===
match
---
atom_expr [5817,5885]
atom_expr [5848,5916]
===
match
---
suite [8916,8971]
suite [8947,9002]
===
match
---
operator: -> [4322,4324]
operator: -> [4353,4355]
===
match
---
trailer [13802,13879]
trailer [13833,13910]
===
match
---
trailer [8873,8898]
trailer [8904,8929]
===
match
---
name: key [3622,3625]
name: key [3653,3656]
===
match
---
atom_expr [2053,2111]
atom_expr [2053,2111]
===
match
---
param [3013,3025]
param [3044,3056]
===
match
---
return_stmt [6350,6361]
return_stmt [6381,6392]
===
match
---
name: result [6285,6291]
name: result [6316,6322]
===
match
---
operator: } [2878,2879]
operator: } [2909,2910]
===
match
---
operator: } [14024,14025]
operator: } [14055,14056]
===
match
---
simple_stmt [14111,14127]
simple_stmt [14142,14158]
===
match
---
trailer [9757,9759]
trailer [9788,9790]
===
match
---
decorator [2929,2946]
decorator [2960,2977]
===
match
---
name: in_ [8885,8888]
name: in_ [8916,8919]
===
match
---
name: xcoms [10021,10026]
name: xcoms [10052,10057]
===
match
---
name: dag_id [2044,2050]
name: dag_id [2044,2050]
===
match
---
operator: , [851,852]
operator: , [851,852]
===
match
---
simple_stmt [896,947]
simple_stmt [896,947]
===
match
---
comparison [3627,3663]
comparison [3658,3694]
===
match
---
trailer [13253,13259]
trailer [13284,13290]
===
match
---
suite [13066,13261]
suite [13097,13292]
===
match
---
trailer [10203,10210]
trailer [10234,10241]
===
match
---
tfpdef [10434,10445]
tfpdef [10465,10476]
===
match
---
atom_expr [9624,9679]
atom_expr [9655,9710]
===
match
---
trailer [5827,5885]
trailer [5858,5916]
===
match
---
name: Any [4334,4337]
name: Any [4365,4368]
===
match
---
operator: , [3663,3664]
operator: , [3694,3695]
===
match
---
name: append [8867,8873]
name: append [8898,8904]
===
match
---
name: cls [6232,6235]
name: cls [6263,6266]
===
match
---
atom_expr [6312,6341]
atom_expr [6343,6372]
===
match
---
arglist [13803,13878]
arglist [13834,13909]
===
match
---
parameters [2550,2556]
parameters [2581,2587]
===
match
---
name: key [3615,3618]
name: key [3646,3649]
===
match
---
name: task_id [3680,3687]
name: task_id [3711,3718]
===
match
---
funcdef [13711,14127]
funcdef [13742,14158]
===
match
---
string: """         Store an XCom value.          :return: None         """ [3049,3116]
string: """         Store an XCom value.          :return: None         """ [3080,3147]
===
match
---
operator: = [3398,3399]
operator: = [3429,3430]
===
match
---
name: Column [919,925]
name: Column [919,925]
===
match
---
name: BaseXCom [13676,13684]
name: BaseXCom [13707,13715]
===
match
---
operator: == [3700,3702]
operator: == [3731,3733]
===
match
---
name: ValueError [9229,9239]
name: ValueError [9260,9270]
===
match
---
operator: , [4314,4315]
operator: , [4345,4346]
===
match
---
name: execution_date [9355,9369]
name: execution_date [9386,9400]
===
match
---
name: task_id [6060,6067]
name: task_id [6091,6098]
===
match
---
simple_stmt [14094,14107]
simple_stmt [14125,14138]
===
match
---
name: provide_session [1354,1369]
name: provide_session [1354,1369]
===
match
---
operator: } [10180,10181]
operator: } [10211,10212]
===
match
---
name: models [1133,1139]
name: models [1133,1139]
===
match
---
trailer [3373,3381]
trailer [3404,3412]
===
match
---
file_input [788,14159]
file_input [788,14190]
===
match
---
name: cls [11855,11858]
name: cls [11886,11889]
===
match
---
fstring_string: " ( [2862,2865]
fstring_string: " ( [2893,2896]
===
match
---
name: airflow [9567,9574]
name: airflow [9598,9605]
===
match
---
operator: == [3646,3648]
operator: == [3677,3679]
===
match
---
name: task_id [11763,11770]
name: task_id [11794,11801]
===
match
---
name: query [12053,12058]
name: query [12084,12089]
===
match
---
param [12111,12121]
param [12142,12152]
===
match
---
string: "XCom" [12740,12746]
string: "XCom" [12771,12777]
===
match
---
return_stmt [13005,13052]
return_stmt [13036,13083]
===
match
---
comparison [9333,9369]
comparison [9364,9400]
===
match
---
name: Optional [4062,4070]
name: Optional [4093,4101]
===
match
---
name: timezone [1849,1857]
name: timezone [1849,1857]
===
match
---
name: desc [9753,9757]
name: desc [9784,9788]
===
match
---
string: " If you are using pickle instead of JSON for XCom," [12492,12544]
string: " If you are using pickle instead of JSON for XCom," [12523,12575]
===
match
---
atom_expr [8820,8841]
atom_expr [8851,8872]
===
match
---
atom [3159,3175]
atom [3190,3206]
===
match
---
expr_stmt [10012,10027]
expr_stmt [10043,10058]
===
match
---
name: run_id [12029,12035]
name: run_id [12060,12066]
===
match
---
trailer [1791,1804]
trailer [1791,1804]
===
match
---
suite [12123,12687]
suite [12154,12718]
===
match
---
name: Query [1036,1041]
name: Query [1036,1041]
===
match
---
name: DateTime [4028,4036]
name: DateTime [4059,4067]
===
match
---
atom_expr [8560,8590]
atom_expr [8591,8621]
===
match
---
operator: ** [2003,2005]
operator: ** [2003,2005]
===
match
---
argument [9520,9528]
argument [9551,9559]
===
match
---
name: Optional [6583,6591]
name: Optional [6614,6622]
===
match
---
fstring_expr [2865,2879]
fstring_expr [2896,2910]
===
match
---
atom_expr [2761,2771]
atom_expr [2792,2802]
===
match
---
return_stmt [13669,13708]
return_stmt [13700,13739]
===
match
---
name: clazz [13887,13892]
name: clazz [13918,13923]
===
match
---
atom_expr [9439,9457]
atom_expr [9470,9488]
===
match
---
name: run_id [3160,3166]
name: run_id [3191,3197]
===
match
---
operator: ^ [8402,8403]
operator: ^ [8433,8434]
===
match
---
simple_stmt [8434,8509]
simple_stmt [8465,8540]
===
match
---
suite [12295,12349]
suite [12326,12380]
===
match
---
param [4291,4315]
param [4322,4346]
===
match
---
operator: { [2865,2866]
operator: { [2896,2897]
===
match
---
atom_expr [12932,12944]
atom_expr [12963,12975]
===
match
---
atom_expr [9655,9668]
atom_expr [9686,9699]
===
match
---
name: session [3572,3579]
name: session [3603,3610]
===
match
---
atom_expr [1849,1864]
atom_expr [1849,1864]
===
match
---
name: dag_id [10377,10383]
name: dag_id [10408,10414]
===
match
---
atom [5904,6273]
atom [5935,6304]
===
match
---
name: __tablename__ [1683,1696]
name: __tablename__ [1683,1696]
===
match
---
name: LargeBinary [927,938]
name: LargeBinary [927,938]
===
match
---
comparison [3689,3709]
comparison [3720,3740]
===
match
---
subscriptlist [4211,4229]
subscriptlist [4242,4260]
===
match
---
import_as_names [919,946]
import_as_names [919,946]
===
match
---
operator: @ [2515,2516]
operator: @ [2546,2547]
===
match
---
atom [12364,12387]
atom [12395,12418]
===
match
---
atom_expr [3572,3728]
atom_expr [3603,3759]
===
match
---
operator: = [1848,1849]
operator: = [1848,1849]
===
match
---
trailer [3585,3590]
trailer [3616,3621]
===
match
---
name: cls [8874,8877]
name: cls [8905,8908]
===
match
---
trailer [13111,13117]
trailer [13142,13148]
===
match
---
name: reconstructor [1052,1065]
name: reconstructor [1052,1065]
===
match
---
suite [2827,2907]
suite [2858,2938]
===
match
---
name: str [4211,4214]
name: str [4242,4245]
===
match
---
name: key [3806,3809]
name: key [3837,3840]
===
match
---
name: dag_ids [8796,8803]
name: dag_ids [8827,8834]
===
match
---
name: is_container [8820,8832]
name: is_container [8851,8863]
===
match
---
name: filters [8518,8525]
name: filters [8549,8556]
===
match
---
name: filters [8560,8567]
name: filters [8591,8598]
===
match
---
trailer [3692,3699]
trailer [3723,3730]
===
match
---
operator: , [6766,6767]
operator: , [6797,6798]
===
match
---
name: utils [1333,1338]
name: utils [1333,1338]
===
match
---
simple_stmt [8518,8531]
simple_stmt [8549,8562]
===
match
---
string: "clear() missing required argument: task_id" [11464,11508]
string: "clear() missing required argument: task_id" [11495,11539]
===
match
---
if_stmt [3125,3264]
if_stmt [3156,3295]
===
match
---
param [2968,2974]
param [2999,3005]
===
match
---
arglist [1910,1939]
arglist [1910,1939]
===
match
---
name: task_id [11427,11434]
name: task_id [11458,11465]
===
match
---
operator: = [11979,11980]
operator: = [12010,12011]
===
match
---
simple_stmt [3350,3428]
simple_stmt [3381,3459]
===
match
---
name: Iterable [6664,6672]
name: Iterable [6695,6703]
===
match
---
name: loads [13241,13246]
name: loads [13272,13277]
===
match
---
expr_stmt [9689,9760]
expr_stmt [9720,9791]
===
match
---
operator: @ [3939,3940]
operator: @ [3970,3971]
===
match
---
operator: , [1041,1042]
operator: , [1041,1042]
===
match
---
tfpdef [12111,12121]
tfpdef [12142,12152]
===
match
---
name: json [13012,13016]
name: json [13043,13047]
===
match
---
simple_stmt [11834,11893]
simple_stmt [11865,11924]
===
match
---
trailer [9638,9646]
trailer [9669,9677]
===
match
---
name: decode [13036,13042]
name: decode [13067,13073]
===
match
---
operator: , [2073,2074]
operator: , [2073,2074]
===
match
---
operator: = [4038,4039]
operator: = [4069,4070]
===
match
---
name: ValueError [12365,12375]
name: ValueError [12396,12406]
===
match
---
name: execution_date [9384,9398]
name: execution_date [9415,9429]
===
match
---
name: default [1841,1848]
name: default [1841,1848]
===
match
---
operator: @ [9862,9863]
operator: @ [9893,9894]
===
match
---
name: str [10385,10388]
name: str [10416,10419]
===
match
---
name: execution_date [8378,8392]
name: execution_date [8409,8423]
===
match
---
name: include_prior_dates [8983,9002]
name: include_prior_dates [9014,9033]
===
match
---
name: str [10442,10445]
name: str [10473,10476]
===
match
---
name: Base [1176,1180]
name: Base [1176,1180]
===
match
---
expr_stmt [1809,1881]
expr_stmt [1809,1881]
===
match
---
simple_stmt [6350,6362]
simple_stmt [6381,6393]
===
match
---
decorator [12073,12087]
decorator [12104,12118]
===
match
---
simple_stmt [5811,5886]
simple_stmt [5842,5917]
===
match
---
trailer [6231,6242]
trailer [6262,6273]
===
match
---
operator: , [10452,10453]
operator: , [10483,10484]
===
match
---
name: dag_id [3392,3398]
name: dag_id [3423,3429]
===
match
---
name: clear [10289,10294]
name: clear [10320,10325]
===
match
---
trailer [3668,3676]
trailer [3699,3707]
===
match
---
name: getboolean [12835,12845]
name: getboolean [12866,12876]
===
match
---
name: filter [11848,11854]
name: filter [11879,11885]
===
match
---
name: JSONDecodeError [13173,13188]
name: JSONDecodeError [13204,13219]
===
match
---
name: Session [1043,1050]
name: Session [1043,1050]
===
match
---
atom_expr [8668,8709]
atom_expr [8699,8740]
===
match
---
name: dag_id [8952,8958]
name: dag_id [8983,8989]
===
match
---
name: execution_date [3828,3842]
name: execution_date [3859,3873]
===
match
---
name: execution_date [9443,9457]
name: execution_date [9474,9488]
===
match
---
subscriptlist [4151,4169]
subscriptlist [4182,4200]
===
match
---
name: pickle [13234,13240]
name: pickle [13265,13271]
===
match
---
argument [3828,3857]
argument [3859,3888]
===
match
---
trailer [1827,1881]
trailer [1827,1881]
===
match
---
import_name [880,895]
import_name [880,895]
===
match
---
name: execution_date [9019,9033]
name: execution_date [9050,9064]
===
match
---
name: value [6236,6241]
name: value [6267,6272]
===
match
---
param [10462,10486]
param [10493,10517]
===
match
---
name: run_id [5995,6001]
name: run_id [6026,6032]
===
match
---
trailer [9730,9735]
trailer [9761,9766]
===
match
---
trailer [13137,13146]
trailer [13168,13177]
===
match
---
tfpdef [4054,4075]
tfpdef [4085,4106]
===
match
---
suite [13738,14127]
suite [13769,14158]
===
match
---
name: airflow [1086,1093]
name: airflow [1086,1093]
===
match
---
suite [5798,5886]
suite [5829,5917]
===
match
---
name: query [9689,9694]
name: query [9720,9725]
===
match
---
trailer [12210,12242]
trailer [12241,12273]
===
match
---
atom_expr [1821,1881]
atom_expr [1821,1881]
===
match
---
name: Optional [863,871]
name: Optional [863,871]
===
match
---
name: str [4225,4228]
name: str [4256,4259]
===
match
---
argument [2094,2110]
argument [2094,2110]
===
match
---
name: flush [3746,3751]
name: flush [3777,3782]
===
match
---
name: association_proxy [2471,2488]
name: association_proxy [2502,2519]
===
match
---
fstring_end: " [13877,13878]
fstring_end: " [13908,13909]
===
match
---
dotted_name [1268,1299]
dotted_name [1268,1299]
===
match
---
name: String [1724,1730]
name: String [1724,1730]
===
match
---
trailer [11366,11411]
trailer [11397,11442]
===
match
---
operator: = [1874,1875]
operator: = [1874,1875]
===
match
---
operator: = [1979,1980]
operator: = [1979,1980]
===
match
---
name: dag_id [3693,3699]
name: dag_id [3724,3730]
===
match
---
operator: = [4308,4309]
operator: = [4339,4340]
===
match
---
operator: , [4044,4045]
operator: , [4075,4076]
===
match
---
expr_stmt [3490,3525]
expr_stmt [3521,3556]
===
match
---
name: session [3901,3908]
name: session [3932,3939]
===
match
---
simple_stmt [8933,8971]
simple_stmt [8964,9002]
===
match
---
operator: @ [10264,10265]
operator: @ [10295,10296]
===
match
---
operator: = [8526,8527]
operator: = [8557,8558]
===
match
---
name: provide_session [6385,6400]
name: provide_session [6416,6431]
===
match
---
argument [3407,3420]
argument [3438,3451]
===
match
---
trailer [3719,3726]
trailer [3750,3757]
===
match
---
trailer [9985,9998]
trailer [10016,10029]
===
match
---
string: """Delete Xcom""" [9946,9963]
string: """Delete Xcom""" [9977,9994]
===
match
---
string: """Serialize Xcom value to str or pickled object""" [12132,12183]
string: """Serialize Xcom value to str or pickled object""" [12163,12214]
===
match
---
name: append [8676,8682]
name: append [8707,8713]
===
match
---
tfpdef [6635,6679]
tfpdef [6666,6710]
===
match
---
trailer [13240,13246]
trailer [13271,13277]
===
match
---
trailer [11688,11693]
trailer [11719,11724]
===
match
---
name: conf [1115,1119]
name: conf [1115,1119]
===
match
---
name: decode [13131,13137]
name: decode [13162,13168]
===
match
---
name: key [8543,8546]
name: key [8574,8577]
===
match
---
name: result [12732,12738]
name: result [12763,12769]
===
match
---
return_stmt [2836,2906]
return_stmt [2867,2937]
===
match
---
parameters [10294,10492]
parameters [10325,10523]
===
match
---
name: ValueError [5817,5827]
name: ValueError [5848,5858]
===
match
---
operator: = [6029,6030]
operator: = [6060,6061]
===
match
---
name: query [9624,9629]
name: query [9655,9660]
===
match
---
operator: @ [2912,2913]
operator: @ [2943,2944]
===
match
---
name: classmethod [2913,2924]
name: classmethod [2944,2955]
===
match
---
name: pendulum [4019,4027]
name: pendulum [4050,4058]
===
match
---
atom_expr [13023,13051]
atom_expr [13054,13082]
===
match
---
name: task_id [11752,11759]
name: task_id [11783,11790]
===
match
---
argument [6117,6156]
argument [6148,6187]
===
match
---
atom_expr [13247,13259]
atom_expr [13278,13290]
===
match
---
operator: = [6619,6620]
operator: = [6650,6651]
===
match
---
comparison [8378,8400]
comparison [8409,8431]
===
match
---
simple_stmt [4348,5739]
simple_stmt [4379,5770]
===
match
---
name: execution_date [3133,3147]
name: execution_date [3164,3178]
===
match
---
operator: , [3024,3025]
operator: , [3055,3056]
===
match
---
name: cls [9911,9914]
name: cls [9942,9945]
===
match
---
operator: , [9991,9992]
operator: , [10022,10023]
===
match
---
atom [5781,5797]
atom [5812,5828]
===
match
---
name: pickle [12263,12269]
name: pickle [12294,12300]
===
match
---
atom_expr [9229,9305]
atom_expr [9260,9336]
===
match
---
simple_stmt [1683,1706]
simple_stmt [1683,1706]
===
match
---
simple_stmt [1009,1080]
simple_stmt [1009,1080]
===
match
---
suite [9831,9857]
suite [9862,9888]
===
match
---
param [10317,10368]
param [10348,10399]
===
match
---
param [4092,4118]
param [4123,4149]
===
match
---
atom_expr [5918,6263]
atom_expr [5949,6294]
===
match
---
name: get_many [6409,6417]
name: get_many [6440,6448]
===
match
---
name: TypeError [10120,10129]
name: TypeError [10151,10160]
===
match
---
operator: ** [2075,2077]
operator: ** [2075,2077]
===
match
---
suite [2557,2803]
suite [2588,2834]
===
match
---
operator: = [2051,2052]
operator: = [2051,2052]
===
match
---
trailer [13124,13130]
trailer [13155,13161]
===
match
---
operator: == [8771,8773]
operator: == [8802,8804]
===
match
---
operator: , [2966,2967]
operator: , [2997,2998]
===
match
---
name: cls [9635,9638]
name: cls [9666,9669]
===
match
---
name: execution_date [3994,4008]
name: execution_date [4025,4039]
===
match
---
arglist [1731,1752]
arglist [1731,1752]
===
match
---
operator: , [3687,3688]
operator: , [3718,3719]
===
match
---
atom_expr [3360,3427]
atom_expr [3391,3458]
===
match
---
name: result [12932,12938]
name: result [12963,12969]
===
match
---
trailer [8567,8574]
trailer [8598,8605]
===
match
---
name: __name__ [13868,13876]
name: __name__ [13899,13907]
===
match
---
name: XCom [14129,14133]
name: XCom [14160,14164]
===
match
---
name: cls [11689,11692]
name: cls [11720,11723]
===
match
---
trailer [13029,13035]
trailer [13060,13066]
===
match
---
string: """         Called by the ORM after the instance has been loaded from the DB or otherwise reconstituted         i.e automatically deserialize Xcom value when loading from DB.         """ [2566,2752]
string: """         Called by the ORM after the instance has been loaded from the DB or otherwise reconstituted         i.e automatically deserialize Xcom value when loading from DB.         """ [2597,2783]
===
match
---
atom_expr [14050,14067]
atom_expr [14081,14098]
===
match
---
param [3981,3985]
param [4012,4016]
===
match
---
name: str [6659,6662]
name: str [6690,6693]
===
match
---
trailer [3630,3645]
trailer [3661,3676]
===
match
---
name: task_ids [6051,6059]
name: task_ids [6082,6090]
===
match
---
name: COLLATION_ARGS [1738,1752]
name: COLLATION_ARGS [1738,1752]
===
match
---
name: sqlalchemy [952,962]
name: sqlalchemy [952,962]
===
match
---
operator: = [6680,6681]
operator: = [6711,6712]
===
match
---
name: conf [12830,12834]
name: conf [12861,12865]
===
match
---
name: provide_session [3940,3955]
name: provide_session [3971,3986]
===
match
---
name: primary_key [1923,1934]
name: primary_key [1923,1934]
===
match
---
trailer [1857,1864]
trailer [1857,1864]
===
match
---
arglist [1988,2038]
arglist [1988,2038]
===
match
---
trailer [6255,6261]
trailer [6286,6292]
===
match
---
operator: = [11840,11841]
operator: = [11871,11872]
===
match
---
operator: = [1934,1935]
operator: = [1934,1935]
===
match
---
atom_expr [11589,11657]
atom_expr [11620,11688]
===
match
---
trailer [3751,3753]
trailer [3782,3784]
===
match
---
param [10405,10425]
param [10436,10456]
===
match
---
name: key [1711,1714]
name: key [1711,1714]
===
match
---
name: query [11973,11978]
name: query [12004,12009]
===
match
---
param [10377,10396]
param [10408,10427]
===
match
---
operator: , [2961,2962]
operator: , [2992,2993]
===
match
---
name: session [9923,9930]
name: session [9954,9961]
===
match
---
operator: == [9458,9460]
operator: == [9489,9491]
===
match
---
expr_stmt [3350,3427]
expr_stmt [3381,3458]
===
match
---
comparison [3160,3174]
comparison [3191,3205]
===
match
---
name: execution_date [11794,11808]
name: execution_date [11825,11839]
===
match
---
string: """Deserialize XCom value from str or pickle object""" [12764,12818]
string: """Deserialize XCom value from str or pickle object""" [12795,12849]
===
match
---
simple_stmt [12681,12687]
simple_stmt [12712,12718]
===
match
---
simple_stmt [1971,2040]
simple_stmt [1971,2040]
===
match
---
operator: , [12217,12218]
operator: , [12248,12249]
===
match
---
import_from [947,1008]
import_from [947,1008]
===
match
---
expr_stmt [1886,1940]
expr_stmt [1886,1940]
===
match
---
name: utils [1276,1281]
name: utils [1276,1281]
===
match
---
param [2963,2967]
param [2994,2998]
===
match
---
simple_stmt [1886,1941]
simple_stmt [1886,1941]
===
match
---
trailer [11854,11892]
trailer [11885,11923]
===
match
---
operator: { [2852,2853]
operator: { [2883,2884]
===
match
---
trailer [6315,6333]
trailer [6346,6364]
===
match
---
operator: , [1050,1051]
operator: , [1050,1051]
===
match
---
name: session [4291,4298]
name: session [4322,4329]
===
match
---
simple_stmt [3901,3917]
simple_stmt [3932,3948]
===
match
---
atom_expr [10342,10359]
atom_expr [10373,10390]
===
match
---
operator: = [10389,10390]
operator: = [10420,10421]
===
match
---
tfpdef [10377,10388]
tfpdef [10408,10419]
===
match
---
operator: , [1864,1865]
operator: , [1864,1865]
===
match
---
name: dagrun [9582,9588]
name: dagrun [9613,9619]
===
match
---
parameters [13291,13297]
parameters [13322,13328]
===
match
---
name: json [795,799]
name: json [795,799]
===
match
---
argument [1736,1752]
argument [1736,1752]
===
match
---
name: str [6517,6520]
name: str [6548,6551]
===
match
---
trailer [3579,3585]
trailer [3610,3616]
===
match
---
simple_stmt [1777,1805]
simple_stmt [1777,1805]
===
match
---
name: sqlalchemy [1014,1024]
name: sqlalchemy [1014,1024]
===
match
---
name: classmethod [3923,3934]
name: classmethod [3954,3965]
===
match
---
trailer [10232,10239]
trailer [10263,10270]
===
match
---
trailer [6261,6263]
trailer [6292,6294]
===
match
---
trailer [13172,13188]
trailer [13203,13219]
===
match
---
suite [4339,6362]
suite [4370,6393]
===
match
---
operator: = [3842,3843]
operator: = [3873,3874]
===
match
---
param [2821,2825]
param [2852,2856]
===
match
---
atom [5754,5778]
atom [5785,5809]
===
match
---
expr_stmt [9616,9679]
expr_stmt [9647,9710]
===
match
---
string: """         Deserialize method which is used to reconstruct ORM XCom object.          This method should be overridden in custom XCom backends to avoid         unnecessary request or other resource consuming operations when         creating XCom orm model. This is used when viewing XCom listing         in the webserver, for example.         """ [13314,13660]
string: """         Deserialize method which is used to reconstruct ORM XCom object.          This method should be overridden in custom XCom backends to avoid         unnecessary request or other resource consuming operations when         creating XCom orm model. This is used when viewing XCom listing         in the webserver, for example.         """ [13345,13691]
===
match
---
trailer [14058,14067]
trailer [14089,14098]
===
match
---
operator: = [10446,10447]
operator: = [10477,10478]
===
match
---
atom_expr [11855,11873]
atom_expr [11886,11904]
===
match
---
comparison [11714,11734]
comparison [11745,11765]
===
match
---
arglist [2067,2091]
arglist [2067,2091]
===
match
---
operator: = [9930,9931]
operator: = [9961,9962]
===
match
---
name: ext [963,966]
name: ext [963,966]
===
match
---
name: dumps [12270,12275]
name: dumps [12301,12306]
===
match
---
name: task_id [4127,4134]
name: task_id [4158,4165]
===
match
---
suite [13893,14107]
suite [13924,14138]
===
match
---
name: task_id [2975,2982]
name: task_id [3006,3013]
===
match
---
tfpdef [4248,4273]
tfpdef [4279,4304]
===
match
---
dotted_name [1325,1346]
dotted_name [1325,1346]
===
match
---
expr_stmt [2044,2111]
expr_stmt [2044,2111]
===
match
---
name: cls [9333,9336]
name: cls [9364,9367]
===
match
---
name: delete [10204,10210]
name: delete [10235,10241]
===
match
---
name: configuration [1094,1107]
name: configuration [1094,1107]
===
match
---
expr_stmt [1546,1567]
expr_stmt [1546,1567]
===
match
---
operator: , [3011,3012]
operator: , [3042,3043]
===
match
---
parameters [6417,6806]
parameters [6448,6837]
===
match
---
simple_stmt [1181,1216]
simple_stmt [1181,1216]
===
match
---
operator: = [4076,4077]
operator: = [4107,4108]
===
match
---
trailer [12269,12275]
trailer [12300,12306]
===
match
---
trailer [1730,1753]
trailer [1730,1753]
===
match
---
operator: , [2973,2974]
operator: , [3004,3005]
===
match
---
name: conf [12195,12199]
name: conf [12226,12230]
===
match
---
name: query [9616,9621]
name: query [9647,9652]
===
match
---
operator: -> [10493,10495]
operator: -> [10524,10526]
===
match
---
atom_expr [9318,9370]
atom_expr [9349,9401]
===
match
---
decorator [10247,10260]
decorator [10278,10291]
===
match
---
trailer [4105,4110]
trailer [4136,4141]
===
match
---
name: Union [6592,6597]
name: Union [6623,6628]
===
match
---
operator: == [3619,3621]
operator: == [3650,3652]
===
match
---
simple_stmt [8668,8710]
simple_stmt [8699,8741]
===
match
---
trailer [9634,9647]
trailer [9665,9678]
===
match
---
decorator [2912,2925]
decorator [2943,2956]
===
match
---
name: Optional [4196,4204]
name: Optional [4227,4235]
===
match
---
name: provide_session [2930,2945]
name: provide_session [2961,2976]
===
match
---
name: execution_date [3466,3480]
name: execution_date [3497,3511]
===
match
---
trailer [9804,9810]
trailer [9835,9841]
===
match
---
number: 512 [1731,1734]
number: 512 [1731,1734]
===
match
---
raise_stmt [11448,11509]
raise_stmt [11479,11540]
===
match
---
operator: , [6799,6800]
operator: , [6830,6831]
===
match
---
operator: , [1839,1840]
operator: , [1839,1840]
===
match
---
operator: = [1697,1698]
operator: = [1697,1698]
===
match
---
trailer [3425,3427]
trailer [3456,3458]
===
match
---
name: value [12939,12944]
name: value [12970,12975]
===
match
---
trailer [11599,11657]
trailer [11630,11688]
===
match
---
name: dag_run [11996,12003]
name: dag_run [12027,12034]
===
match
---
suite [12878,13053]
suite [12909,13084]
===
match
---
name: task_ids [6573,6581]
name: task_ids [6604,6612]
===
match
---
strings [12428,12654]
strings [12459,12685]
===
match
---
suite [12388,12687]
suite [12419,12718]
===
match
---
param [6500,6529]
param [6531,6560]
===
match
---
operator: } [13876,13877]
operator: } [13907,13908]
===
match
---
name: include_prior_dates [6696,6715]
name: include_prior_dates [6727,6746]
===
match
---
operator: = [1766,1767]
operator: = [1766,1767]
===
match
---
name: utils [1229,1234]
name: utils [1229,1234]
===
match
---
fstring_string: `. [14068,14070]
fstring_string: `. [14099,14101]
===
match
---
xor_expr [8377,8420]
xor_expr [8408,8451]
===
match
---
comparison [8575,8589]
comparison [8606,8620]
===
match
---
funcdef [9900,10242]
funcdef [9931,10273]
===
match
---
name: loads [13017,13022]
name: loads [13048,13053]
===
match
---
name: String [2060,2066]
name: String [2060,2066]
===
match
---
simple_stmt [829,879]
simple_stmt [829,879]
===
match
---
operator: ** [1736,1738]
operator: ** [1736,1738]
===
match
---
suite [9999,10028]
suite [10030,10059]
===
match
---
except_clause [12958,12987]
except_clause [12989,13018]
===
match
---
name: order_by [9703,9711]
name: order_by [9734,9742]
===
match
---
operator: = [4172,4173]
operator: = [4203,4204]
===
match
---
trailer [4027,4036]
trailer [4058,4067]
===
match
---
trailer [12065,12067]
trailer [12096,12098]
===
match
---
string: """         Retrieve an XCom value, optionally meeting certain criteria. Returns None         of there are no results.          ``run_id`` and ``execution_date`` are mutually exclusive.          This method returns "full" XCom values (i.e. it uses ``deserialize_value`` from the XCom backend).         Please use :meth:`get_many` if you want the "shortened" value via ``orm_deserialize_value``          :param execution_date: Execution date for the task         :type execution_date: pendulum.datetime         :param run_id: Dag run id for the task         :type run_id: str         :param key: A key for the XCom. If provided, only XComs with matching             keys will be returned. To remove the filter, pass key=None.         :type key: str         :param task_id: Only XComs from task with matching id will be             pulled. Can pass None to remove the filter.         :type task_id: str         :param dag_id: If provided, only pulls XCom from this DAG.             If None (default), the DAG of the calling task is used.         :type dag_id: str         :param include_prior_dates: If False, only XCom from the current             execution_date are returned. If True, XCom from previous dates             are returned as well.         :type include_prior_dates: bool         :param session: database session         :type session: sqlalchemy.orm.session.Session         """ [4348,5738]
string: """         Retrieve an XCom value, optionally meeting certain criteria. Returns None         of there are no results.          ``run_id`` and ``execution_date`` are mutually exclusive.          This method returns "full" XCom values (i.e. it uses ``deserialize_value`` from the XCom backend).         Please use :meth:`get_many` if you want the "shortened" value via ``orm_deserialize_value``          :param execution_date: Execution date for the task         :type execution_date: pendulum.datetime         :param run_id: Dag run id for the task         :type run_id: str         :param key: A key for the XCom. If provided, only XComs with matching             keys will be returned. To remove the filter, pass key=None.         :type key: str         :param task_id: Only XComs from task with matching id will be             pulled. Can pass None to remove the filter.         :type task_id: str         :param dag_id: If provided, only pulls XCom from this DAG.             If None (default), the DAG of the calling task is used.         :type dag_id: str         :param include_prior_dates: If False, only XCom from the current             execution_date are returned. If True, XCom from previous dates             are returned as well.         :type include_prior_dates: bool         :param session: database session         :type session: sqlalchemy.orm.session.Session         """ [4379,5769]
===
match
---
simple_stmt [13100,13148]
simple_stmt [13131,13179]
===
match
---
decorator [9862,9875]
decorator [9893,9906]
===
match
---
atom_expr [3801,3890]
atom_expr [3832,3921]
===
match
---
arglist [1828,1880]
arglist [1828,1880]
===
match
---
suite [6816,9857]
suite [6847,9888]
===
match
---
atom_expr [4216,4229]
atom_expr [4247,4260]
===
match
---
name: query [3580,3585]
name: query [3611,3616]
===
match
---
atom_expr [4097,4110]
atom_expr [4128,4141]
===
match
---
operator: , [2092,2093]
operator: , [2092,2093]
===
match
---
fstring_end: " [14070,14071]
fstring_end: " [14101,14102]
===
match
---
not_test [5750,5797]
not_test [5781,5828]
===
match
---
name: typing [834,840]
name: typing [834,840]
===
match
---
trailer [10350,10359]
trailer [10381,10390]
===
match
---
name: session [3738,3745]
name: session [3769,3776]
===
match
---
atom_expr [3195,3263]
atom_expr [3226,3294]
===
match
---
trailer [2800,2802]
trailer [2831,2833]
===
match
---
tfpdef [10405,10417]
tfpdef [10436,10448]
===
match
---
suite [9003,9371]
suite [9034,9402]
===
match
---
trailer [4070,4075]
trailer [4101,4106]
===
match
---
xor_expr [3132,3175]
xor_expr [3163,3206]
===
match
---
name: dag_ids [8889,8896]
name: dag_ids [8920,8927]
===
match
---
name: Optional [6508,6516]
name: Optional [6539,6547]
===
match
---
operator: , [6729,6730]
operator: , [6760,6761]
===
match
---
operator: ^ [11551,11552]
operator: ^ [11582,11583]
===
match
---
atom_expr [8628,8650]
atom_expr [8659,8681]
===
match
---
name: cls [9712,9715]
name: cls [9743,9746]
===
match
---
fstring_start: f' [10130,10132]
fstring_start: f' [10161,10163]
===
match
---
argument [6174,6189]
argument [6205,6220]
===
match
---
import_name [815,828]
import_name [815,828]
===
match
---
suite [11906,12037]
suite [11937,12068]
===
match
---
name: xcom [10085,10089]
name: xcom [10116,10120]
===
match
---
operator: = [10418,10419]
operator: = [10449,10450]
===
match
---
operator: , [4178,4179]
operator: , [4209,4210]
===
match
---
simple_stmt [14129,14159]
simple_stmt [14160,14190]
===
match
---
name: flush [3909,3914]
name: flush [3940,3945]
===
match
---
operator: { [13858,13859]
operator: { [13889,13890]
===
match
---
operator: , [5977,5978]
operator: , [6008,6009]
===
match
---
name: reconstructor [2516,2529]
name: reconstructor [2547,2560]
===
match
---
name: self [2883,2887]
name: self [2914,2918]
===
match
---
name: XCOM_RETURN_KEY [1568,1583]
name: XCOM_RETURN_KEY [1568,1583]
===
match
---
atom_expr [9975,9998]
atom_expr [10006,10029]
===
match
---
name: ID_LEN [2067,2073]
name: ID_LEN [2067,2073]
===
match
---
name: Optional [4097,4105]
name: Optional [4128,4136]
===
match
---
name: Optional [6644,6652]
name: Optional [6675,6683]
===
match
---
name: Query [6810,6815]
name: Query [6841,6846]
===
match
---
simple_stmt [11583,11658]
simple_stmt [11614,11689]
===
match
---
param [4054,4083]
param [4085,4114]
===
match
---
arglist [3611,3709]
arglist [3642,3740]
===
match
---
trailer [1433,1443]
trailer [1433,1443]
===
match
---
name: clazz [14010,14015]
name: clazz [14041,14046]
===
match
---
atom_expr [6465,6482]
atom_expr [6496,6513]
===
match
---
tfpdef [6538,6556]
tfpdef [6569,6587]
===
match
---
name: query [11667,11672]
name: query [11698,11703]
===
match
---
expr_stmt [1568,1600]
expr_stmt [1568,1600]
===
match
---
name: UtcDateTime [1828,1839]
name: UtcDateTime [1828,1839]
===
match
---
name: result [13023,13029]
name: result [13054,13060]
===
match
---
name: execution_date [3649,3663]
name: execution_date [3680,3694]
===
match
---
atom_expr [3789,3891]
atom_expr [3820,3922]
===
match
---
name: result [5895,5901]
name: result [5926,5932]
===
match
---
atom_expr [4010,4037]
atom_expr [4041,4068]
===
match
---
operator: @ [3922,3923]
operator: @ [3953,3954]
===
match
---
argument [6051,6067]
argument [6082,6098]
===
match
---
trailer [1994,2020]
trailer [1994,2020]
===
match
---
simple_stmt [2566,2753]
simple_stmt [2597,2784]
===
match
---
name: Any [848,851]
name: Any [848,851]
===
match
---
arglist [12211,12241]
arglist [12242,12272]
===
match
---
operator: @ [2929,2930]
operator: @ [2960,2961]
===
match
---
fstring_string: ` is not a subclass of ` [14025,14049]
fstring_string: ` is not a subclass of ` [14056,14080]
===
match
---
name: is_container [8628,8640]
name: is_container [8659,8671]
===
match
---
decorator [9879,9896]
decorator [9910,9927]
===
match
---
atom_expr [4156,4169]
atom_expr [4187,4200]
===
match
---
dotted_name [1125,1144]
dotted_name [1125,1144]
===
match
---
simple_stmt [13780,13880]
simple_stmt [13811,13911]
===
match
---
atom_expr [1717,1772]
atom_expr [1717,1772]
===
match
---
simple_stmt [12764,12819]
simple_stmt [12795,12850]
===
match
---
atom_expr [13118,13146]
atom_expr [13149,13177]
===
match
---
operator: , [6430,6431]
operator: , [6461,6462]
===
match
---
name: execution_date [9461,9475]
name: execution_date [9492,9506]
===
match
---
param [9923,9935]
param [9954,9966]
===
match
---
if_stmt [9972,10028]
if_stmt [10003,10059]
===
match
---
atom_expr [13107,13147]
atom_expr [13138,13178]
===
match
---
operator: , [925,926]
operator: , [925,926]
===
match
---
name: ID_LEN [1168,1174]
name: ID_LEN [1168,1174]
===
match
---
tfpdef [4127,4171]
tfpdef [4158,4202]
===
match
---
name: append [8941,8947]
name: append [8972,8978]
===
match
---
operator: , [10485,10486]
operator: , [10516,10517]
===
match
---
name: filter_by [3382,3391]
name: filter_by [3413,3422]
===
match
---
name: execution_date [3843,3857]
name: execution_date [3874,3888]
===
match
---
atom_expr [3738,3753]
atom_expr [3769,3784]
===
match
---
not_test [13905,13936]
not_test [13936,13967]
===
match
---
raise_stmt [3189,3263]
raise_stmt [3220,3294]
===
match
---
name: session [6182,6189]
name: session [6213,6220]
===
match
---
trailer [11995,12003]
trailer [12026,12034]
===
match
---
atom_expr [8683,8708]
atom_expr [8714,8739]
===
match
---
name: self [2551,2555]
name: self [2582,2586]
===
match
---
import_from [9562,9602]
import_from [9593,9633]
===
match
---
atom_expr [12919,12945]
atom_expr [12950,12976]
===
match
---
trailer [8947,8970]
trailer [8978,9001]
===
match
---
operator: , [10367,10368]
operator: , [10398,10399]
===
match
---
name: error [12405,12410]
name: error [12436,12441]
===
match
---
trailer [6464,6483]
trailer [6495,6514]
===
match
---
trailer [3465,3480]
trailer [3496,3511]
===
match
---
simple_stmt [800,815]
simple_stmt [800,815]
===
match
---
string: "run_id" [2500,2508]
string: "run_id" [2531,2539]
===
match
---
if_stmt [9539,9680]
if_stmt [9570,9711]
===
match
---
trailer [8751,8758]
trailer [8782,8789]
===
match
---
name: key [3810,3813]
name: key [3841,3844]
===
match
---
name: json [13168,13172]
name: json [13199,13203]
===
match
---
raise_stmt [8434,8508]
raise_stmt [8465,8539]
===
match
---
param [6440,6491]
param [6471,6522]
===
match
---
param [2551,2555]
param [2582,2586]
===
match
---
string: 'enable_xcom_pickling' [12854,12876]
string: 'enable_xcom_pickling' [12885,12907]
===
match
---
name: Optional [6456,6464]
name: Optional [6487,6495]
===
match
---
simple_stmt [9946,9964]
simple_stmt [9977,9995]
===
match
---
atom_expr [2866,2878]
atom_expr [2897,2909]
===
match
---
name: __name__ [10172,10180]
name: __name__ [10203,10211]
===
match
---
name: timestamp [9743,9752]
name: timestamp [9774,9783]
===
match
---
name: airflow [1186,1193]
name: airflow [1186,1193]
===
match
---
argument [2003,2019]
argument [2003,2019]
===
match
---
name: session [9494,9501]
name: session [9525,9532]
===
match
---
simple_stmt [1420,1454]
simple_stmt [1420,1454]
===
match
---
tfpdef [10462,10478]
tfpdef [10493,10509]
===
match
---
operator: , [1065,1066]
operator: , [1065,1066]
===
match
---
funcdef [2534,2803]
funcdef [2565,2834]
===
match
---
simple_stmt [12256,12283]
simple_stmt [12287,12314]
===
match
---
name: classmethod [10248,10259]
name: classmethod [10279,10290]
===
match
---
name: issubclass [13909,13919]
name: issubclass [13940,13950]
===
match
---
name: dag_id [3703,3709]
name: dag_id [3734,3740]
===
match
---
name: cls [3627,3630]
name: cls [3658,3661]
===
match
---
tfpdef [3994,4037]
tfpdef [4025,4068]
===
match
---
name: run_id [9672,9678]
name: run_id [9703,9709]
===
match
---
tfpdef [12732,12746]
tfpdef [12763,12777]
===
match
---
atom_expr [1426,1453]
atom_expr [1426,1453]
===
match
---
name: session [6174,6181]
name: session [6205,6212]
===
match
---
trailer [11991,12004]
trailer [12022,12035]
===
match
---
name: execution_date [9337,9351]
name: execution_date [9368,9382]
===
match
---
name: xcom [10211,10215]
name: xcom [10242,10246]
===
match
---
operator: = [6092,6093]
operator: = [6123,6124]
===
match
---
trailer [13965,14085]
trailer [13996,14116]
===
match
---
name: filters [8933,8940]
name: filters [8964,8971]
===
match
---
name: pickle [822,828]
name: pickle [822,828]
===
match
---
name: primary_key [1755,1766]
name: primary_key [1755,1766]
===
match
---
operator: = [1901,1902]
operator: = [1901,1902]
===
match
---
param [2984,2991]
param [3015,3022]
===
match
---
name: dagrun [3316,3322]
name: dagrun [3347,3353]
===
match
---
operator: == [11725,11727]
operator: == [11756,11758]
===
match
---
name: query [3368,3373]
name: query [3399,3404]
===
match
---
decorator [6384,6401]
decorator [6415,6432]
===
match
---
expr_stmt [1711,1772]
expr_stmt [1711,1772]
===
match
---
name: run_id [9662,9668]
name: run_id [9693,9699]
===
match
---
name: dag_id [8878,8884]
name: dag_id [8909,8915]
===
match
---
name: query [11683,11688]
name: query [11714,11719]
===
match
---
atom_expr [14136,14158]
atom_expr [14167,14189]
===
match
---
string: "clear() missing required argument: dag_id" [11367,11410]
string: "clear() missing required argument: dag_id" [11398,11441]
===
match
---
name: join [9630,9634]
name: join [9661,9665]
===
match
---
trailer [8698,8708]
trailer [8729,8739]
===
match
---
trailer [8877,8884]
trailer [8908,8915]
===
match
---
name: nullable [1866,1874]
name: nullable [1866,1874]
===
match
---
comparison [9384,9410]
comparison [9415,9441]
===
match
---
name: query [9486,9491]
name: query [9517,9522]
===
match
---
name: is_container [1250,1262]
name: is_container [1250,1262]
===
match
---
param [10304,10308]
param [10335,10339]
===
match
---
name: value [1777,1782]
name: value [1777,1782]
===
match
---
if_stmt [9770,9857]
if_stmt [9801,9888]
===
match
---
operator: , [3984,3985]
operator: , [4015,4016]
===
match
---
trailer [3800,3891]
trailer [3831,3922]
===
match
---
operator: -> [6807,6809]
operator: -> [6838,6840]
===
match
---
return_stmt [13227,13260]
return_stmt [13258,13291]
===
match
---
atom_expr [4019,4036]
atom_expr [4050,4067]
===
match
---
trailer [3367,3373]
trailer [3398,3404]
===
match
---
trailer [12938,12944]
trailer [12969,12975]
===
match
---
fstring_string: airflow.models.xcom. [13838,13858]
fstring_string: airflow.models.xcom. [13869,13889]
===
match
---
simple_stmt [2761,2803]
simple_stmt [2792,2834]
===
match
---
simple_stmt [2044,2112]
simple_stmt [2044,2112]
===
match
---
name: session [1339,1346]
name: session [1339,1346]
===
match
---
atom_expr [8744,8783]
atom_expr [8775,8814]
===
match
---
operator: , [3826,3827]
operator: , [3857,3858]
===
match
---
atom_expr [6592,6617]
atom_expr [6623,6648]
===
match
---
trailer [3502,3518]
trailer [3533,3549]
===
match
---
operator: , [13925,13926]
operator: , [13956,13957]
===
match
---
operator: , [6686,6687]
operator: , [6717,6718]
===
match
---
parameters [9910,9936]
parameters [9941,9967]
===
match
---
arglist [1724,1771]
arglist [1724,1771]
===
match
---
simple_stmt [13314,13661]
simple_stmt [13345,13692]
===
match
---
operator: , [13188,13189]
operator: , [13219,13220]
===
match
---
trailer [1987,2039]
trailer [1987,2039]
===
match
---
trailer [11847,11854]
trailer [11878,11885]
===
match
---
name: ValueError [3195,3205]
name: ValueError [3226,3236]
===
match
---
atom_expr [11357,11411]
atom_expr [11388,11442]
===
match
---
name: xcoms [10012,10017]
name: xcoms [10043,10048]
===
match
---
operator: = [3456,3457]
operator: = [3487,3488]
===
match
---
name: Optional [6746,6754]
name: Optional [6777,6785]
===
match
---
name: models [11932,11938]
name: models [11963,11969]
===
match
---
arglist [9986,9997]
arglist [10017,10028]
===
match
---
trailer [12339,12348]
trailer [12370,12379]
===
match
---
name: execution_date [5963,5977]
name: execution_date [5994,6008]
===
match
---
name: String [1988,1994]
name: String [1988,1994]
===
match
---
name: value [13254,13259]
name: value [13285,13290]
===
match
---
name: cls [11714,11717]
name: cls [11745,11748]
===
match
---
arglist [5948,6190]
arglist [5979,6221]
===
match
---
name: ID_LEN [1995,2001]
name: ID_LEN [1995,2001]
===
match
---
trailer [4018,4037]
trailer [4049,4068]
===
match
---
name: run_id [8405,8411]
name: run_id [8436,8442]
===
match
---
name: association_proxy [991,1008]
name: association_proxy [991,1008]
===
match
---
operator: , [1921,1922]
operator: , [1921,1922]
===
match
---
trailer [12834,12845]
trailer [12865,12876]
===
match
---
operator: , [2990,2991]
operator: , [3021,3022]
===
match
---
name: cls [5918,5921]
name: cls [5949,5952]
===
match
---
operator: , [9737,9738]
operator: , [9768,9769]
===
match
---
name: filter [3591,3597]
name: filter [3622,3628]
===
match
---
name: primary_key [2094,2105]
name: primary_key [2094,2105]
===
match
---
name: getLogger [1434,1443]
name: getLogger [1434,1443]
===
match
---
decorator [3922,3935]
decorator [3953,3966]
===
match
---
name: helpers [1235,1242]
name: helpers [1235,1242]
===
match
---
operator: , [6528,6529]
operator: , [6559,6560]
===
match
---
name: XCom [9993,9997]
name: XCom [10024,10028]
===
match
---
operator: = [6136,6137]
operator: = [6167,6168]
===
match
---
operator: = [6793,6794]
operator: = [6824,6825]
===
match
---
suite [12243,12283]
suite [12274,12314]
===
match
---
decorators [3922,3956]
decorators [3953,3987]
===
match
---
operator: = [5902,5903]
operator: = [5933,5934]
===
match
---
name: session [3789,3796]
name: session [3820,3827]
===
match
---
param [2975,2983]
param [3006,3014]
===
match
---
name: execution_date [1886,1900]
name: execution_date [1886,1900]
===
match
---
name: dag_id [3399,3405]
name: dag_id [3430,3436]
===
match
---
suite [1638,13709]
suite [1638,13740]
===
match
---
param [6696,6730]
param [6727,6761]
===
match
---
name: xcoms [10048,10053]
name: xcoms [10079,10084]
===
match
---
comparison [11794,11820]
comparison [11825,11851]
===
match
---
expr_stmt [1971,2039]
expr_stmt [1971,2039]
===
match
---
name: orm_deserialize_value [13270,13291]
name: orm_deserialize_value [13301,13322]
===
match
---
suite [8421,8509]
suite [8452,8540]
===
match
---
name: __repr__ [2812,2820]
name: __repr__ [2843,2851]
===
match
---
operator: = [3019,3020]
operator: = [3050,3051]
===
match
---
name: BaseXCom [13927,13935]
name: BaseXCom [13958,13966]
===
match
---
name: json [12315,12319]
name: json [12346,12350]
===
match
---
except_clause [12357,12387]
except_clause [12388,12418]
===
match
---
comparison [5755,5777]
comparison [5786,5808]
===
match
---
string: "Exactly one of execution_date or run_id must be passed" [8451,8507]
string: "Exactly one of execution_date or run_id must be passed" [8482,8538]
===
match
---
operator: = [5962,5963]
operator: = [5993,5994]
===
match
---
name: Any [13301,13304]
name: Any [13332,13335]
===
match
---
name: DagRun [9596,9602]
name: DagRun [9627,9633]
===
match
---
trailer [4333,4338]
trailer [4364,4369]
===
match
---
operator: @ [10247,10248]
operator: @ [10278,10279]
===
match
---
operator: { [10156,10157]
operator: { [10187,10188]
===
match
---
atom_expr [12012,12025]
atom_expr [12043,12056]
===
match
---
simple_stmt [8859,8899]
simple_stmt [8890,8930]
===
match
---
trailer [3745,3751]
trailer [3776,3782]
===
match
---
suite [12988,13053]
suite [13019,13084]
===
match
---
simple_stmt [13743,13776]
simple_stmt [13774,13807]
===
match
---
return_stmt [6305,6341]
return_stmt [6336,6372]
===
match
---
name: task_id [3867,3874]
name: task_id [3898,3905]
===
match
---
import_from [896,946]
import_from [896,946]
===
match
---
trailer [6551,6556]
trailer [6582,6587]
===
match
---
not_test [11423,11434]
not_test [11454,11465]
===
match
---
xor_expr [11526,11569]
xor_expr [11557,11600]
===
match
---
name: cls [3665,3668]
name: cls [3696,3699]
===
match
---
name: key [6026,6029]
name: key [6057,6060]
===
match
---
dotted_name [1375,1399]
dotted_name [1375,1399]
===
match
---
suite [9549,9680]
suite [9580,9711]
===
match
---
simple_stmt [1216,1263]
simple_stmt [1216,1263]
===
match
---
arglist [9712,9759]
arglist [9743,9790]
===
match
---
trailer [8675,8682]
trailer [8706,8713]
===
match
---
dotted_name [1186,1199]
dotted_name [1186,1199]
===
match
---
comparison [11527,11549]
comparison [11558,11580]
===
match
---
fstring_start: f" [13836,13838]
fstring_start: f" [13867,13869]
===
match
---
string: "Exactly one of execution_date or run_id must be passed" [11600,11656]
string: "Exactly one of execution_date or run_id must be passed" [11631,11687]
===
match
---
trailer [9438,9476]
trailer [9469,9507]
===
match
---
name: fallback [13827,13835]
name: fallback [13858,13866]
===
match
---
import_from [1009,1079]
import_from [1009,1079]
===
match
---
fstring_start: f" [13983,13985]
fstring_start: f" [14014,14016]
===
match
---
name: LoggingMixin [1307,1319]
name: LoggingMixin [1307,1319]
===
match
---
atom_expr [2774,2802]
atom_expr [2805,2833]
===
match
---
decorators [2912,2946]
decorators [2943,2977]
===
match
---
name: loads [13112,13117]
name: loads [13143,13148]
===
match
---
name: clazz [13920,13925]
name: clazz [13951,13956]
===
match
---
trailer [8832,8841]
trailer [8863,8872]
===
match
---
decorators [9862,9896]
decorators [9893,9927]
===
match
---
name: airflow [3301,3308]
name: airflow [3332,3339]
===
match
---
try_stmt [12291,12687]
try_stmt [12322,12718]
===
match
---
atom_expr [9712,9737]
atom_expr [9743,9768]
===
match
---
if_stmt [12827,13261]
if_stmt [12858,13292]
===
match
---
trailer [9501,9507]
trailer [9532,9538]
===
match
---
name: execution_date [11877,11891]
name: execution_date [11908,11922]
===
match
---
name: value [2766,2771]
name: value [2797,2802]
===
match
---
trailer [6235,6241]
trailer [6266,6272]
===
match
---
name: run_id [4054,4060]
name: run_id [4085,4091]
===
match
---
atom_expr [9739,9759]
atom_expr [9770,9790]
===
match
---
simple_stmt [9424,9477]
simple_stmt [9455,9508]
===
match
---
trailer [4164,4169]
trailer [4195,4200]
===
match
---
funcdef [12710,13261]
funcdef [12741,13292]
===
match
---
simple_stmt [6825,8362]
simple_stmt [6856,8393]
===
match
---
trailer [10171,10180]
trailer [10202,10211]
===
match
---
name: run_id [6500,6506]
name: run_id [6531,6537]
===
match
---
funcdef [10285,12068]
funcdef [10316,12099]
===
match
---
name: run_id [5782,5788]
name: run_id [5813,5819]
===
match
---
expr_stmt [13780,13879]
expr_stmt [13811,13910]
===
match
---
name: task_ids [8641,8649]
name: task_ids [8672,8680]
===
match
---
name: execution_date [11527,11541]
name: execution_date [11558,11572]
===
match
---
name: execution_date [3631,3645]
name: execution_date [3662,3676]
===
match
---
tfpdef [6500,6521]
tfpdef [6531,6552]
===
match
---
if_stmt [8625,8784]
if_stmt [8656,8815]
===
match
---
atom_expr [6603,6616]
atom_expr [6634,6647]
===
match
---
fstring_expr [2882,2903]
fstring_expr [2913,2934]
===
match
---
operator: = [1584,1585]
operator: = [1584,1585]
===
match
---
name: Optional [4325,4333]
name: Optional [4356,4364]
===
match
---
argument [3806,3813]
argument [3837,3844]
===
match
---
atom_expr [4205,4230]
atom_expr [4236,4261]
===
match
---
name: str [6552,6555]
name: str [6583,6586]
===
match
---
name: key [4092,4095]
name: key [4123,4126]
===
match
---
import_from [1216,1262]
import_from [1216,1262]
===
match
---
simple_stmt [9844,9857]
simple_stmt [9875,9888]
===
match
---
trailer [12018,12025]
trailer [12049,12056]
===
match
---
operator: , [3874,3875]
operator: , [3905,3906]
===
match
---
name: DagRun [3330,3336]
name: DagRun [3361,3367]
===
match
---
operator: , [1753,1754]
operator: , [1753,1754]
===
match
---
simple_stmt [9223,9306]
simple_stmt [9254,9337]
===
match
---
simple_stmt [11448,11510]
simple_stmt [11479,11541]
===
match
---
try_stmt [13079,13261]
try_stmt [13110,13292]
===
match
---
name: filters [9318,9325]
name: filters [9349,9356]
===
match
---
name: Optional [4136,4144]
name: Optional [4167,4175]
===
match
---
name: result [13118,13124]
name: result [13149,13155]
===
match
---
name: task_id [10405,10412]
name: task_id [10436,10443]
===
match
---
expr_stmt [9486,9529]
expr_stmt [9517,9560]
===
match
---
name: self [13703,13707]
name: self [13734,13738]
===
match
---
return_stmt [13100,13147]
return_stmt [13131,13178]
===
match
---
dotted_name [952,983]
dotted_name [952,983]
===
match
---
name: limit [6739,6744]
name: limit [6770,6775]
===
match
---
operator: == [11760,11762]
operator: == [11791,11793]
===
match
---
trailer [12410,12668]
trailer [12441,12699]
===
match
---
trailer [9325,9332]
trailer [9356,9363]
===
match
---
simple_stmt [10196,10217]
simple_stmt [10227,10248]
===
match
---
import_from [1320,1369]
import_from [1320,1369]
===
match
---
atom_expr [13859,13876]
atom_expr [13890,13907]
===
match
---
name: dag_ids [8833,8840]
name: dag_ids [8864,8871]
===
match
---
atom_expr [8948,8958]
atom_expr [8979,8989]
===
match
---
operator: , [4082,4083]
operator: , [4113,4114]
===
match
---
name: json [13107,13111]
name: json [13138,13142]
===
match
---
name: value [3490,3495]
name: value [3521,3526]
===
match
---
name: Column [1717,1723]
name: Column [1717,1723]
===
match
---
name: init_on_load [2538,2550]
name: init_on_load [2569,2581]
===
match
---
trailer [9431,9438]
trailer [9462,9469]
===
match
---
trailer [8694,8698]
trailer [8725,8729]
===
match
---
operator: , [10395,10396]
operator: , [10426,10427]
===
match
---
operator: = [4111,4112]
operator: = [4142,4143]
===
match
---
name: Union [873,878]
name: Union [873,878]
===
match
---
simple_stmt [1568,1601]
simple_stmt [1568,1601]
===
match
---
trailer [12925,12931]
trailer [12956,12962]
===
match
---
trailer [6754,6759]
trailer [6785,6790]
===
match
---
trailer [11693,11700]
trailer [11724,11731]
===
match
---
trailer [6217,6231]
trailer [6248,6262]
===
match
---
simple_stmt [815,829]
simple_stmt [815,829]
===
match
---
simple_stmt [12132,12184]
simple_stmt [12163,12215]
===
match
---
name: __name__ [14016,14024]
name: __name__ [14047,14055]
===
match
---
simple_stmt [3572,3729]
simple_stmt [3603,3760]
===
match
---
name: COLLATION_ARGS [2005,2019]
name: COLLATION_ARGS [2005,2019]
===
match
---
name: one [3422,3425]
name: one [3453,3456]
===
match
---
parameters [2820,2826]
parameters [2851,2857]
===
match
---
name: cls [8575,8578]
name: cls [8606,8609]
===
match
---
simple_stmt [3296,3337]
simple_stmt [3327,3368]
===
match
---
suite [12755,13261]
suite [12786,13292]
===
match
---
import_as_names [848,878]
import_as_names [848,878]
===
match
---
name: String [940,946]
name: String [940,946]
===
match
---
name: include_prior_dates [4248,4267]
name: include_prior_dates [4279,4298]
===
match
---
name: dag_id [4188,4194]
name: dag_id [4219,4225]
===
match
---
raise_stmt [9223,9305]
raise_stmt [9254,9336]
===
match
---
if_stmt [13902,14086]
if_stmt [13933,14117]
===
match
---
name: execution_date [5755,5769]
name: execution_date [5786,5800]
===
match
---
name: run_id [3407,3413]
name: run_id [3438,3444]
===
match
---
name: cls [8759,8762]
name: cls [8790,8793]
===
match
---
expr_stmt [5895,6273]
expr_stmt [5926,6304]
===
match
---
operator: ^ [5779,5780]
operator: ^ [5810,5811]
===
match
---
name: deserialize_value [6316,6333]
name: deserialize_value [6347,6364]
===
match
---
trailer [3205,3263]
trailer [3236,3294]
===
match
---
name: dumps [12320,12325]
name: dumps [12351,12356]
===
match
---
name: clazz [14101,14106]
name: clazz [14132,14137]
===
match
---
simple_stmt [788,800]
simple_stmt [788,800]
===
match
---
atom_expr [1903,1940]
atom_expr [1903,1940]
===
match
---
name: Iterable [4216,4224]
name: Iterable [4247,4255]
===
match
---
return_stmt [9844,9856]
return_stmt [9875,9887]
===
match
---
name: append [8752,8758]
name: append [8783,8789]
===
match
---
name: Optional [4010,4018]
name: Optional [4041,4049]
===
match
---
operator: , [4154,4155]
operator: , [4185,4186]
===
match
---
simple_stmt [9562,9603]
simple_stmt [9593,9634]
===
match
---
atom_expr [1724,1753]
atom_expr [1724,1753]
===
match
---
import_from [1370,1418]
import_from [1370,1418]
===
match
---
parameters [12731,12747]
parameters [12762,12778]
===
match
---
operator: = [11673,11674]
operator: = [11704,11705]
===
match
---
name: Iterable [853,861]
name: Iterable [853,861]
===
match
---
string: 'UTF-8' [12340,12347]
string: 'UTF-8' [12371,12378]
===
match
---
simple_stmt [8560,8591]
simple_stmt [8591,8622]
===
match
---
operator: { [14009,14010]
operator: { [14040,14041]
===
match
---
argument [6026,6033]
argument [6057,6064]
===
match
---
atom_expr [8440,8508]
atom_expr [8471,8539]
===
match
---
simple_stmt [3490,3526]
simple_stmt [3521,3557]
===
match
---
dotted_name [9567,9588]
dotted_name [9598,9619]
===
match
---
name: desc [9731,9735]
name: desc [9762,9766]
===
match
---
for_stmt [10036,10217]
for_stmt [10067,10248]
===
match
---
atom [8404,8420]
atom [8435,8451]
===
match
---
name: models [3309,3315]
name: models [3340,3346]
===
match
---
name: append [9432,9438]
name: append [9463,9469]
===
match
---
atom_expr [9635,9646]
atom_expr [9666,9677]
===
match
---
operator: == [11874,11876]
operator: == [11905,11907]
===
match
---
operator: , [13825,13826]
operator: , [13856,13857]
===
match
---
simple_stmt [9486,9530]
simple_stmt [9517,9561]
===
match
---
name: run_id [9542,9548]
name: run_id [9573,9579]
===
match
---
classdef [1603,13709]
classdef [1603,13740]
===
match
---
fstring_string:  @  [2879,2882]
fstring_string:  @  [2910,2913]
===
match
---
operator: = [3496,3497]
operator: = [3527,3528]
===
match
---
decorators [10247,10281]
decorators [10278,10312]
===
match
---
name: str [10414,10417]
name: str [10445,10448]
===
match
---
comparison [3665,3687]
comparison [3696,3718]
===
match
---
parameters [12110,12122]
parameters [12141,12153]
===
match
---
suite [13083,13148]
suite [13114,13179]
===
match
---
name: str [4106,4109]
name: str [4137,4140]
===
match
---
name: encode [12333,12339]
name: encode [12364,12370]
===
match
---
testlist_comp [12365,12386]
testlist_comp [12396,12417]
===
match
---
string: """         Composes a query to get one or more values from the xcom table.          ``run_id`` and ``execution_date`` are mutually exclusive.          This function returns an SQLAlchemy query of full XCom objects. If you just want one stored value then         use :meth:`get_one`.          :param execution_date: Execution date for the task         :type execution_date: pendulum.datetime         :param run_id: Dag run id for the task         :type run_id: str         :param key: A key for the XCom. If provided, only XComs with matching             keys will be returned. To remove the filter, pass key=None.         :type key: str         :param task_ids: Only XComs from tasks with matching ids will be             pulled. Can pass None to remove the filter.         :type task_ids: str or iterable of strings (representing task_ids)         :param dag_ids: If provided, only pulls XComs from this DAG.             If None (default), the DAG of the calling task is used.         :type dag_ids: str         :param include_prior_dates: If False, only XComs from the current             execution_date are returned. If True, XComs from previous dates             are returned as well.         :type include_prior_dates: bool         :param limit: If required, limit the number of returned objects.             XCom objects can be quite big and you might want to limit the             number of rows.         :type limit: int         :param session: database session         :type session: sqlalchemy.orm.session.Session         """ [6825,8361]
string: """         Composes a query to get one or more values from the xcom table.          ``run_id`` and ``execution_date`` are mutually exclusive.          This function returns an SQLAlchemy query of full XCom objects. If you just want one stored value then         use :meth:`get_one`.          :param execution_date: Execution date for the task         :type execution_date: pendulum.datetime         :param run_id: Dag run id for the task         :type run_id: str         :param key: A key for the XCom. If provided, only XComs with matching             keys will be returned. To remove the filter, pass key=None.         :type key: str         :param task_ids: Only XComs from tasks with matching ids will be             pulled. Can pass None to remove the filter.         :type task_ids: str or iterable of strings (representing task_ids)         :param dag_ids: If provided, only pulls XComs from this DAG.             If None (default), the DAG of the calling task is used.         :type dag_ids: str         :param include_prior_dates: If False, only XComs from the current             execution_date are returned. If True, XComs from previous dates             are returned as well.         :type include_prior_dates: bool         :param limit: If required, limit the number of returned objects.             XCom objects can be quite big and you might want to limit the             number of rows.         :type limit: int         :param session: database session         :type session: sqlalchemy.orm.session.Session         """ [6856,8392]
===
match
---
operator: -> [12748,12750]
operator: -> [12779,12781]
===
match
---
trailer [1909,1940]
trailer [1909,1940]
===
match
---
atom_expr [10120,10183]
atom_expr [10151,10214]
===
match
---
name: run_id [6002,6008]
name: run_id [6033,6039]
===
match
---
trailer [3518,3525]
trailer [3549,3556]
===
match
---
operator: == [12026,12028]
operator: == [12057,12059]
===
match
---
name: Session [6785,6792]
name: Session [6816,6823]
===
match
---
comparison [9655,9678]
comparison [9686,9709]
===
match
---
name: associationproxy [967,983]
name: associationproxy [967,983]
===
match
---
operator: * [9520,9521]
operator: * [9551,9552]
===
match
---
name: XCom [10091,10095]
name: XCom [10122,10126]
===
match
---
trailer [8640,8650]
trailer [8671,8681]
===
match
---
name: set [2954,2957]
name: set [2985,2988]
===
match
---
trailer [11986,11991]
trailer [12017,12022]
===
match
---
argument [5995,6008]
argument [6026,6039]
===
match
---
comparison [11554,11568]
comparison [11585,11599]
===
match
---
name: include_prior_dates [6117,6136]
name: include_prior_dates [6148,6167]
===
match
---
trailer [2765,2771]
trailer [2796,2802]
===
match
---
name: LargeBinary [1792,1803]
name: LargeBinary [1792,1803]
===
match
---
argument [1755,1771]
argument [1755,1771]
===
match
---
param [6739,6767]
param [6770,6798]
===
match
---
name: Union [4145,4150]
name: Union [4176,4181]
===
match
---
trailer [9661,9668]
trailer [9692,9699]
===
match
---
if_stmt [11791,12037]
if_stmt [11822,12068]
===
match
---
string: "core" [13803,13809]
string: "core" [13834,13840]
===
match
---
trailer [6516,6521]
trailer [6547,6552]
===
match
---
operator: } [14067,14068]
operator: } [14098,14099]
===
match
---
import_as_names [1036,1079]
import_as_names [1036,1079]
===
match
---
operator: , [6601,6602]
operator: , [6632,6633]
===
match
---
atom [3132,3156]
atom [3163,3187]
===
match
---
operator: = [4274,4275]
operator: = [4305,4306]
===
match
---
operator: == [9669,9671]
operator: == [9700,9702]
===
match
---
operator: = [9695,9696]
operator: = [9726,9727]
===
match
---
name: airflow [1125,1132]
name: airflow [1125,1132]
===
match
---
name: DateTime [6474,6482]
name: DateTime [6505,6513]
===
match
---
operator: , [4214,4215]
operator: , [4245,4246]
===
match
---
return_stmt [9792,9817]
return_stmt [9823,9848]
===
match
---
decorated [2912,3917]
decorated [2943,3948]
===
match
---
decorators [6367,6401]
decorators [6398,6432]
===
match
---
atom_expr [8575,8582]
atom_expr [8606,8613]
===
match
---
trailer [8574,8590]
trailer [8605,8621]
===
match
---
suite [13210,13261]
suite [13241,13292]
===
match
---
name: getimport [13793,13802]
name: getimport [13824,13833]
===
match
---
atom [8377,8401]
atom [8408,8432]
===
match
---
suite [3283,3481]
suite [3314,3512]
===
match
---
name: sqlalchemy [1389,1399]
name: sqlalchemy [1389,1399]
===
match
---
tfpdef [4092,4110]
tfpdef [4123,4141]
===
match
---
name: utils [1383,1388]
name: utils [1383,1388]
===
match
---
name: TypeError [11357,11366]
name: TypeError [11388,11397]
===
match
---
operator: , [9921,9922]
operator: , [9952,9953]
===
match
---
decorated [6367,9857]
decorated [6398,9888]
===
match
---
operator: == [3677,3679]
operator: == [3708,3710]
===
match
---
trailer [14015,14024]
trailer [14046,14055]
===
match
---
atom_expr [3611,3618]
atom_expr [3642,3649]
===
match
---
trailer [9629,9634]
trailer [9660,9665]
===
match
---
param [2992,3012]
param [3023,3043]
===
match
---
trailer [8866,8873]
trailer [8897,8904]
===
match
---
name: deserialize_value [13685,13702]
name: deserialize_value [13716,13733]
===
match
---
name: query [9502,9507]
name: query [9533,9538]
===
match
---
name: append [9326,9332]
name: append [9357,9363]
===
match
---
if_stmt [8370,8509]
if_stmt [8401,8540]
===
match
---
not_test [11327,11337]
not_test [11358,11368]
===
match
---
name: session [11675,11682]
name: session [11706,11713]
===
match
---
atom_expr [10074,10096]
atom_expr [10105,10127]
===
match
---
return_stmt [12256,12282]
return_stmt [12287,12313]
===
match
---
param [6635,6687]
param [6666,6718]
===
match
---
fstring_string: Expected XCom; received  [10132,10156]
fstring_string: Expected XCom; received  [10163,10187]
===
match
---
name: limit [9811,9816]
name: limit [9842,9847]
===
match
---
comparison [3133,3155]
comparison [3164,3186]
===
match
---
arglist [12846,12876]
arglist [12877,12907]
===
match
---
name: airflow [1268,1275]
name: airflow [1268,1275]
===
match
---
atom_expr [12315,12348]
atom_expr [12346,12379]
===
match
---
name: Column [1821,1827]
name: Column [1821,1827]
===
match
---
simple_stmt [2836,2907]
simple_stmt [2867,2938]
===
match
---
argument [3815,3826]
argument [3846,3857]
===
match
---
string: """         Clears all XCom data from the database for the task instance          ``run_id`` and ``execution_date`` are mutually exclusive.          :param execution_date: Execution date for the task         :type execution_date: pendulum.datetime or None         :param dag_id: ID of DAG to clear the XCom for.         :type dag_id: str         :param task_id: Only XComs from task with matching id will be cleared.         :type task_id: str         :param run_id: Dag run id for the task         :type run_id: str or None         :param session: database session         :type session: sqlalchemy.orm.session.Session         """ [10510,11141]
string: """         Clears all XCom data from the database for the task instance          ``run_id`` and ``execution_date`` are mutually exclusive.          :param execution_date: Execution date for the task         :type execution_date: pendulum.datetime or None         :param dag_id: ID of DAG to clear the XCom for.         :type dag_id: str         :param task_id: Only XComs from task with matching id will be cleared.         :type task_id: str         :param run_id: Dag run id for the task         :type run_id: str or None         :param session: database session         :type session: sqlalchemy.orm.session.Session         """ [10541,11172]
===
match
---
trailer [9654,9679]
trailer [9685,9710]
===
match
---
name: classmethod [9863,9874]
name: classmethod [9894,9905]
===
match
---
trailer [4144,4171]
trailer [4175,4202]
===
match
---
simple_stmt [6305,6342]
simple_stmt [6336,6373]
===
match
---
param [6538,6564]
param [6569,6595]
===
match
---
trailer [10161,10171]
trailer [10192,10202]
===
match
---
name: str [6673,6676]
name: str [6704,6707]
===
match
---
atom_expr [9494,9529]
atom_expr [9525,9560]
===
match
---
atom [13167,13209]
atom [13198,13240]
===
match
---
arglist [13920,13935]
arglist [13951,13966]
===
match
---
atom_expr [11748,11759]
atom_expr [11779,11790]
===
match
---
trailer [13246,13260]
trailer [13277,13291]
===
match
---
param [13292,13296]
param [13323,13327]
===
match
---
trailer [6473,6482]
trailer [6504,6513]
===
match
---
atom_expr [12195,12242]
atom_expr [12226,12273]
===
match
---
fstring_end: ' [2905,2906]
fstring_end: ' [2936,2937]
===
match
---
name: dag_id [11728,11734]
name: dag_id [11759,11765]
===
match
---
name: bool [6717,6721]
name: bool [6748,6752]
===
match
---
not_test [11522,11569]
not_test [11553,11600]
===
match
---
atom_expr [11842,11892]
atom_expr [11873,11923]
===
match
---
name: log [12401,12404]
name: log [12432,12435]
===
match
---
atom_expr [4136,4171]
atom_expr [4167,4202]
===
match
---
funcdef [6405,9857]
funcdef [6436,9888]
===
match
---
name: str [4071,4074]
name: str [4102,4105]
===
match
---
if_stmt [9016,9306]
if_stmt [9047,9337]
===
match
---
trailer [9512,9519]
trailer [9543,9550]
===
match
---
operator: , [11770,11771]
operator: , [11801,11802]
===
match
---
operator: = [1715,1716]
operator: = [1715,1716]
===
match
---
suite [12895,12946]
suite [12926,12977]
===
match
---
name: int [6755,6758]
name: int [6786,6789]
===
match
---
name: airflow [11924,11931]
name: airflow [11955,11962]
===
match
---
param [10434,10453]
param [10465,10484]
===
match
---
trailer [8682,8709]
trailer [8713,8740]
===
match
---
trailer [6658,6678]
trailer [6689,6709]
===
match
---
simple_stmt [13669,13709]
simple_stmt [13700,13740]
===
match
---
atom_expr [2471,2509]
atom_expr [2502,2540]
===
match
---
trailer [9810,9817]
trailer [9841,9848]
===
match
---
trailer [2870,2878]
trailer [2901,2909]
===
match
---
trailer [3597,3719]
trailer [3628,3750]
===
match
---
trailer [8686,8694]
trailer [8717,8725]
===
match
---
operator: == [8959,8961]
operator: == [8990,8992]
===
match
---
operator: , [9914,9915]
operator: , [9945,9946]
===
match
---
name: execution_date [5948,5962]
name: execution_date [5979,5993]
===
match
---
name: dag_run [3458,3465]
name: dag_run [3489,3496]
===
match
---
tfpdef [6573,6618]
tfpdef [6604,6649]
===
match
---
name: __class__ [10162,10171]
name: __class__ [10193,10202]
===
match
---
atom_expr [10196,10216]
atom_expr [10227,10247]
===
match
---
operator: , [11734,11735]
operator: , [11765,11766]
===
match
---
operator: , [6189,6190]
operator: , [6220,6221]
===
match
---
suite [9411,9477]
suite [9442,9508]
===
match
---
atom_expr [1785,1804]
atom_expr [1785,1804]
===
match
---
simple_stmt [10510,11142]
simple_stmt [10541,11173]
===
match
---
operator: = [3413,3414]
operator: = [3444,3445]
===
match
---
atom_expr [3498,3525]
atom_expr [3529,3556]
===
match
---
name: run_id [10434,10440]
name: run_id [10465,10471]
===
match
---
name: utils [1194,1199]
name: utils [1194,1199]
===
match
---
operator: = [6760,6761]
operator: = [6791,6792]
===
match
---
argument [2075,2091]
argument [2075,2091]
===
match
---
name: self [2821,2825]
name: self [2852,2856]
===
match
---
not_test [8373,8420]
not_test [8404,8451]
===
match
---
name: logging [1426,1433]
name: logging [1426,1433]
===
match
---
operator: { [14049,14050]
operator: { [14080,14081]
===
match
---
atom_expr [13168,13188]
atom_expr [13199,13219]
===
match
---
trailer [4150,4170]
trailer [4181,4201]
===
match
---
name: commit [10233,10239]
name: commit [10264,10270]
===
match
---
trailer [10341,10360]
trailer [10372,10391]
===
match
---
name: pickle [12965,12971]
name: pickle [12996,13002]
===
match
---
simple_stmt [9792,9818]
simple_stmt [9823,9849]
===
match
---
trailer [9519,9529]
trailer [9550,9560]
===
match
---
name: BaseXCom [14050,14058]
name: BaseXCom [14081,14089]
===
match
---
funcdef [2950,3917]
funcdef [2981,3948]
===
match
---
atom_expr [1981,2039]
atom_expr [1981,2039]
===
match
---
name: filters [8744,8751]
name: filters [8775,8782]
===
match
---
trailer [3590,3597]
trailer [3621,3628]
===
match
---
name: Union [6653,6658]
name: Union [6684,6689]
===
match
---
return_stmt [12046,12067]
return_stmt [12077,12098]
===
match
---
import_from [1081,1119]
import_from [1081,1119]
===
match
---
comparison [5782,5796]
comparison [5813,5827]
===
match
---
suite [8612,8784]
suite [8643,8815]
===
match
---
expr_stmt [11973,12036]
expr_stmt [12004,12067]
===
match
---
name: dag_id [3883,3889]
name: dag_id [3914,3920]
===
match
---
name: TypeError [11454,11463]
name: TypeError [11485,11494]
===
match
---
atom [11526,11550]
atom [11557,11581]
===
match
---
name: include_prior_dates [6137,6156]
name: include_prior_dates [6168,6187]
===
match
---
argument [1923,1939]
argument [1923,1939]
===
match
---
atom_expr [6664,6677]
atom_expr [6695,6708]
===
match
---
trailer [2778,2800]
trailer [2809,2831]
===
match
---
string: " in your airflow config." [12628,12654]
string: " in your airflow config." [12659,12685]
===
match
---
operator: = [3820,3821]
operator: = [3851,3852]
===
match
---
atom_expr [4196,4231]
atom_expr [4227,4262]
===
match
---
operator: , [6033,6034]
operator: , [6064,6065]
===
match
---
simple_stmt [1320,1370]
simple_stmt [1320,1370]
===
match
---
name: cls [8683,8686]
name: cls [8714,8717]
===
match
---
trailer [2066,2092]
trailer [2066,2092]
===
match
---
decorated [10247,12068]
decorated [10278,12099]
===
match
---
operator: } [2902,2903]
operator: } [2933,2934]
===
match
---
dotted_name [11924,11945]
dotted_name [11955,11976]
===
match
---
name: Session [10471,10478]
name: Session [10502,10509]
===
match
---
atom_expr [2060,2092]
atom_expr [2060,2092]
===
match
---
trailer [13016,13022]
trailer [13047,13053]
===
match
---
if_stmt [8540,8591]
if_stmt [8571,8622]
===
match
---
atom_expr [9799,9817]
atom_expr [9830,9848]
===
match
---
fstring_start: f' [2843,2845]
fstring_start: f' [2874,2876]
===
match
---
name: execution_date [2888,2902]
name: execution_date [2919,2933]
===
match
---
atom_expr [6232,6241]
atom_expr [6263,6272]
===
match
---
name: dagrun [11939,11945]
name: dagrun [11970,11976]
===
match
---
simple_stmt [10012,10028]
simple_stmt [10043,10059]
===
match
---
fstring [13836,13878]
fstring [13867,13909]
===
match
---
name: BaseXCom [14118,14126]
name: BaseXCom [14149,14157]
===
match
---
trailer [9711,9760]
trailer [9742,9791]
===
match
---
name: COLLATION_ARGS [2077,2091]
name: COLLATION_ARGS [2077,2091]
===
match
---
name: str [6612,6615]
name: str [6643,6646]
===
match
---
name: run_id [11554,11560]
name: run_id [11585,11591]
===
match
---
fstring [13983,14071]
fstring [14014,14102]
===
match
---
argument [2022,2038]
argument [2022,2038]
===
match
---
simple_stmt [9318,9371]
simple_stmt [9349,9402]
===
match
---
param [6427,6431]
param [6458,6462]
===
match
---
name: DagRun [11953,11959]
name: DagRun [11984,11990]
===
match
---
simple_stmt [10225,10242]
simple_stmt [10256,10273]
===
match
---
atom_expr [1988,2020]
atom_expr [1988,2020]
===
match
---
suite [10501,12068]
suite [10532,12099]
===
match
---
operator: , [6490,6491]
operator: , [6521,6522]
===
match
---
name: logging_mixin [1286,1299]
name: logging_mixin [1286,1299]
===
match
---
name: join [11987,11991]
name: join [12018,12022]
===
match
---
trailer [10129,10183]
trailer [10160,10214]
===
match
---
suite [10097,10184]
suite [10128,10215]
===
match
---
name: loads [12926,12931]
name: loads [12957,12962]
===
match
---
atom_expr [2883,2902]
atom_expr [2914,2933]
===
match
---
comparison [12012,12035]
comparison [12043,12066]
===
match
---
name: UnpicklingError [12972,12987]
name: UnpicklingError [13003,13018]
===
match
---
atom_expr [11675,11781]
atom_expr [11706,11812]
===
match
---
string: "Exactly one of execution_date or run_id must be passed" [3206,3262]
string: "Exactly one of execution_date or run_id must be passed" [3237,3293]
===
match
---
param [3994,4045]
param [4025,4076]
===
match
---
simple_stmt [11919,11960]
simple_stmt [11950,11991]
===
match
---
name: value [12276,12281]
name: value [12307,12312]
===
match
---
trailer [11463,11509]
trailer [11494,11540]
===
match
---
param [12732,12746]
param [12763,12777]
===
match
---
operator: = [2469,2470]
operator: = [2500,2501]
===
match
---
atom_expr [9697,9760]
atom_expr [9728,9791]
===
match
---
funcdef [3960,6362]
funcdef [3991,6393]
===
match
---
name: dag_ids [6635,6642]
name: dag_ids [6666,6673]
===
match
---
atom_expr [13012,13052]
atom_expr [13043,13083]
===
match
---
simple_stmt [5895,6274]
simple_stmt [5926,6305]
===
match
---
decorated [9862,10242]
decorated [9893,10273]
===
match
---
operator: = [10361,10362]
operator: = [10392,10393]
===
match
---
trailer [12332,12339]
trailer [12363,12370]
===
match
---
name: execution_date [3441,3455]
name: execution_date [3472,3486]
===
match
---
tfpdef [6739,6759]
tfpdef [6770,6790]
===
match
---
raise_stmt [13950,14085]
raise_stmt [13981,14116]
===
match
---
name: MAX_XCOM_SIZE [1546,1559]
name: MAX_XCOM_SIZE [1546,1559]
===
match
---
simple_stmt [1370,1419]
simple_stmt [1370,1419]
===
match
---
name: str [4165,4168]
name: str [4196,4199]
===
match
---
operator: , [12852,12853]
operator: , [12883,12884]
===
match
---
name: deserialize_value [12714,12731]
name: deserialize_value [12745,12762]
===
match
---
name: session [10225,10232]
name: session [10256,10263]
===
match
---
name: run_id [3276,3282]
name: run_id [3307,3313]
===
match
---
suite [8727,8784]
suite [8758,8815]
===
match
---
decorated [12073,12687]
decorated [12104,12718]
===
match
---
suite [13937,14086]
suite [13968,14117]
===
match
---
name: task_id [1971,1978]
name: task_id [1971,1978]
===
match
---
name: str [4151,4154]
name: str [4182,4185]
===
match
---
fstring_string: Your custom XCom class ` [13985,14009]
fstring_string: Your custom XCom class ` [14016,14040]
===
match
---
string: "xcom" [1699,1705]
string: "xcom" [1699,1705]
===
match
---
simple_stmt [12401,12669]
simple_stmt [12432,12700]
===
match
---
return_stmt [12308,12348]
return_stmt [12339,12379]
===
match
---
name: ValueError [8440,8450]
name: ValueError [8471,8481]
===
match
---
name: str [6598,6601]
name: str [6629,6632]
===
match
---
atom_expr [13234,13260]
atom_expr [13265,13291]
===
match
---
operator: = [3809,3810]
operator: = [3840,3841]
===
match
---
return_stmt [14094,14106]
return_stmt [14125,14137]
===
match
---
name: filters [8859,8866]
name: filters [8890,8897]
===
match
---
simple_stmt [9616,9680]
simple_stmt [9647,9711]
===
match
---
trailer [10210,10216]
trailer [10241,10247]
===
match
---
name: dag_run [3350,3357]
name: dag_run [3381,3388]
===
match
---
suite [9779,9818]
suite [9810,9849]
===
match
---
trailer [6672,6677]
trailer [6703,6708]
===
match
---
trailer [9332,9370]
trailer [9363,9401]
===
match
---
expr_stmt [1777,1804]
expr_stmt [1777,1804]
===
match
---
trailer [11700,11781]
trailer [11731,11812]
===
match
---
atom_expr [3627,3645]
atom_expr [3658,3676]
===
match
---
operator: , [3813,3814]
operator: , [3844,3845]
===
match
---
fstring_string: )> [2903,2905]
fstring_string: )> [2934,2936]
===
match
---
atom_expr [13956,14085]
atom_expr [13987,14116]
===
match
---
simple_stmt [13950,14086]
simple_stmt [13981,14117]
===
match
---
fstring_expr [10156,10181]
fstring_expr [10187,10212]
===
match
---
string: 'core' [12846,12852]
string: 'core' [12877,12883]
===
match
---
name: staticmethod [12693,12705]
name: staticmethod [12724,12736]
===
match
---
trailer [9336,9351]
trailer [9367,9382]
===
match
---
argument [3392,3405]
argument [3423,3436]
===
match
---
name: value [3815,3820]
name: value [3846,3851]
===
match
---
operator: , [2001,2002]
operator: , [2001,2002]
===
match
---
name: run_id [3013,3019]
name: run_id [3044,3050]
===
match
---
subscriptlist [6659,6677]
subscriptlist [6690,6708]
===
match
---
tfpdef [6440,6483]
tfpdef [6471,6514]
===
match
---
name: bool [4269,4273]
name: bool [4300,4304]
===
match
---
name: base [1140,1144]
name: base [1140,1144]
===
match
---
decorator [6367,6380]
decorator [6398,6411]
===
match
---
tfpdef [4291,4307]
tfpdef [4322,4338]
===
match
---
name: query [9799,9804]
name: query [9830,9835]
===
match
---
simple_stmt [3738,3754]
simple_stmt [3769,3785]
===
match
---
if_stmt [13884,14107]
if_stmt [13915,14138]
===
match
---
operator: = [1819,1820]
operator: = [1819,1820]
===
match
---
comparison [11855,11891]
comparison [11886,11922]
===
match
---
name: run_id [12019,12025]
name: run_id [12050,12056]
===
match
---
return_stmt [14111,14126]
return_stmt [14142,14157]
===
match
---
name: task_ids [8603,8611]
name: task_ids [8634,8642]
===
match
---
simple_stmt [880,896]
simple_stmt [880,896]
===
match
---
name: session [3360,3367]
name: session [3391,3398]
===
match
---
simple_stmt [947,1009]
simple_stmt [947,1009]
===
match
---
param [4127,4179]
param [4158,4210]
===
match
---
name: cls [2958,2961]
name: cls [2989,2992]
===
match
---
name: limit [9805,9810]
name: limit [9836,9841]
===
match
---
string: 'UTF-8' [13138,13145]
string: 'UTF-8' [13169,13176]
===
match
---
name: task_ids [8699,8707]
name: task_ids [8730,8738]
===
match
---
operator: @ [6367,6368]
operator: @ [6398,6399]
===
match
---
name: DateTime [10351,10359]
name: DateTime [10382,10390]
===
match
---
name: cls [9739,9742]
name: cls [9770,9773]
===
match
---
fstring_expr [2852,2862]
fstring_expr [2883,2893]
===
match
---
name: execution_date [10317,10331]
name: execution_date [10348,10362]
===
match
---
name: key [2963,2966]
name: key [2994,2997]
===
match
---
name: resolve_xcom_backend [14136,14156]
name: resolve_xcom_backend [14167,14187]
===
match
---
name: UnicodeDecodeError [13190,13208]
name: UnicodeDecodeError [13221,13239]
===
match
---
name: session [10196,10203]
name: session [10227,10234]
===
match
---
trailer [2887,2902]
trailer [2918,2933]
===
match
---
name: isinstance [10074,10084]
name: isinstance [10105,10115]
===
match
---
atom_expr [9424,9476]
atom_expr [9455,9507]
===
match
---
simple_stmt [3049,3117]
simple_stmt [3080,3148]
===
match
---
if_stmt [11420,11510]
if_stmt [11451,11541]
===
match
---
atom_expr [10157,10180]
atom_expr [10188,10211]
===
match
---
name: filter [9513,9519]
name: filter [9544,9550]
===
match
---
trailer [9442,9457]
trailer [9473,9488]
===
match
---
fstring_string: <XCom " [2845,2852]
fstring_string: <XCom " [2876,2883]
===
match
---
if_stmt [8600,8784]
if_stmt [8631,8815]
===
match
---
funcdef [12091,12687]
funcdef [12122,12718]
===
match
---
name: filters [9424,9431]
name: filters [9455,9462]
===
match
---
trailer [5930,6204]
trailer [5961,6235]
===
match
---
comparison [8759,8782]
comparison [8790,8813]
===
match
---
import_as_names [1152,1180]
import_as_names [1152,1180]
===
match
---
simple_stmt [3789,3892]
simple_stmt [3820,3923]
===
match
---
operator: @ [12692,12693]
operator: @ [12723,12724]
===
match
---
simple_stmt [11351,11412]
simple_stmt [11382,11443]
===
match
---
name: cls [3689,3692]
name: cls [3720,3723]
===
match
---
atom_expr [13909,13936]
atom_expr [13940,13967]
===
match
---
comparison [9019,9041]
comparison [9050,9072]
===
match
---
name: classmethod [6368,6379]
name: classmethod [6399,6410]
===
match
---
trailer [3391,3421]
trailer [3422,3452]
===
match
---
operator: = [3006,3007]
operator: = [3037,3038]
===
match
---
operator: @ [9879,9880]
operator: @ [9910,9911]
===
match
---
trailer [4224,4229]
trailer [4255,4260]
===
match
---
name: __name__ [1444,1452]
name: __name__ [1444,1452]
===
match
---
simple_stmt [11667,11782]
simple_stmt [11698,11813]
===
match
---
name: Optional [6543,6551]
name: Optional [6574,6582]
===
match
---
string: 'core' [12211,12217]
string: 'core' [12242,12248]
===
match
---
name: pickle [12919,12925]
name: pickle [12950,12956]
===
match
---
trailer [8578,8582]
trailer [8609,8613]
===
match
---
tfpdef [6776,6792]
tfpdef [6807,6823]
===
match
---
operator: = [13786,13787]
operator: = [13817,13818]
===
match
---
name: cls [3611,3614]
name: cls [3642,3645]
===
match
---
atom_expr [12263,12282]
atom_expr [12294,12313]
===
match
---
fstring_end: ' [10181,10182]
fstring_end: ' [10212,10213]
===
match
---
operator: , [4281,4282]
operator: , [4312,4313]
===
match
---
fstring_expr [13858,13877]
fstring_expr [13889,13908]
===
match
---
comparison [8405,8419]
comparison [8436,8450]
===
match
---
argument [13827,13878]
argument [13858,13909]
===
match
---
operator: , [6008,6009]
operator: , [6039,6040]
===
match
---
name: query [9851,9856]
name: query [9882,9887]
===
match
---
operator: = [2772,2773]
operator: = [2803,2804]
===
match
---
name: self [2853,2857]
name: self [2884,2888]
===
match
---
name: result [13247,13253]
name: result [13278,13284]
===
match
---
operator: , [6625,6626]
operator: , [6656,6657]
===
match
---
operator: = [4232,4233]
operator: = [4263,4264]
===
match
---
operator: , [3405,3406]
operator: , [3436,3437]
===
match
---
name: self [13292,13296]
name: self [13323,13327]
===
match
---
string: "Using include_prior_dates needs an execution_date to be passed" [9240,9304]
string: "Using include_prior_dates needs an execution_date to be passed" [9271,9335]
===
match
---
name: query [11834,11839]
name: query [11865,11870]
===
match
---
operator: = [3866,3867]
operator: = [3897,3898]
===
match
---
string: 'enable_xcom_pickling' [12219,12241]
string: 'enable_xcom_pickling' [12250,12272]
===
match
---
name: cls [3586,3589]
name: cls [3617,3620]
===
match
---
decorator [2515,2530]
decorator [2546,2561]
===
match
---
name: cls [6427,6430]
name: cls [6458,6461]
===
match
---
name: pendulum [887,895]
name: pendulum [887,895]
===
match
---
name: orm [1025,1028]
name: orm [1025,1028]
===
match
---
atom_expr [6746,6759]
atom_expr [6777,6790]
===
match
---
name: pendulum [10342,10350]
name: pendulum [10373,10381]
===
match
---
name: execution_date [9716,9730]
name: execution_date [9747,9761]
===
match
---
atom [10020,10027]
atom [10051,10058]
===
match
---
name: cls [9508,9511]
name: cls [9539,9542]
===
match
---
name: value [12111,12116]
name: value [12142,12147]
===
match
---
name: COLLATION_ARGS [1152,1166]
name: COLLATION_ARGS [1152,1166]
===
match
---
name: filter [12005,12011]
name: filter [12036,12042]
===
match
---
trailer [3805,3890]
trailer [3836,3921]
===
match
---
atom_expr [13676,13708]
atom_expr [13707,13739]
===
match
---
name: session [3026,3033]
name: session [3057,3064]
===
match
---
decorated [12692,13261]
decorated [12723,13292]
===
match
---
name: Iterable [6603,6611]
name: Iterable [6634,6642]
===
match
---
if_stmt [8980,9477]
if_stmt [9011,9508]
===
match
---
name: Column [1903,1909]
name: Column [1903,1909]
===
match
---
trailer [8884,8888]
trailer [8915,8919]
===
match
---
suite [9042,9306]
suite [9073,9337]
===
match
---
simple_stmt [11973,12037]
simple_stmt [12004,12068]
===
match
---
string: "Exactly one of execution_date or run_id must be passed" [5828,5884]
string: "Exactly one of execution_date or run_id must be passed" [5859,5915]
===
match
---
trailer [14156,14158]
trailer [14187,14189]
===
match
---
name: isinstance [9975,9985]
name: isinstance [10006,10016]
===
match
---
operator: = [3033,3034]
operator: = [3064,3065]
===
match
---
name: XCom [3498,3502]
name: XCom [3529,3533]
===
match
---
trailer [12325,12332]
trailer [12356,12363]
===
match
---
atom_expr [10333,10360]
atom_expr [10364,10391]
===
match
---
name: Column [1981,1987]
name: Column [1981,1987]
===
match
---
name: get_many [5922,5930]
name: get_many [5953,5961]
===
match
---
import_from [3296,3336]
import_from [3327,3367]
===
match
---
name: getboolean [12200,12210]
name: getboolean [12231,12241]
===
match
---
name: dag_id [11718,11724]
name: dag_id [11749,11755]
===
match
---
name: conf [13788,13792]
name: conf [13819,13823]
===
match
---
argument [5948,5977]
argument [5979,6008]
===
match
---
name: key [8579,8582]
name: key [8610,8613]
===
match
---
name: xcom [10157,10161]
name: xcom [10188,10192]
===
match
---
name: Column [2053,2059]
name: Column [2053,2059]
===
match
---
operator: = [6059,6060]
operator: = [6090,6091]
===
match
---
trailer [13042,13051]
trailer [13073,13082]
===
match
---
trailer [3726,3728]
trailer [3757,3759]
===
match
---
name: XCom [3801,3805]
name: XCom [3832,3836]
===
match
---
name: dag_id [6093,6099]
name: dag_id [6124,6130]
===
match
---
import_from [1263,1319]
import_from [1263,1319]
===
match
---
trailer [12404,12410]
trailer [12435,12441]
===
match
---
argument [1866,1880]
argument [1866,1880]
===
match
---
atom_expr [2853,2861]
atom_expr [2884,2892]
===
match
---
name: DagRun [12012,12018]
name: DagRun [12043,12049]
===
match
---
atom_expr [12401,12668]
atom_expr [12432,12699]
===
match
---
name: key [2858,2861]
name: key [2889,2892]
===
match
---
name: session [10462,10469]
name: session [10493,10500]
===
match
---
name: cls [8948,8951]
name: cls [8979,8982]
===
match
---
simple_stmt [12912,12946]
simple_stmt [12943,12977]
===
match
---
atom_expr [6583,6618]
atom_expr [6614,6649]
===
match
---
operator: , [10089,10090]
operator: , [10120,10121]
===
match
---
name: airflow [1221,1228]
name: airflow [1221,1228]
===
match
---
name: in_ [8695,8698]
name: in_ [8726,8729]
===
match
---
name: airflow [1325,1332]
name: airflow [1325,1332]
===
match
---
dotted_name [1014,1028]
dotted_name [1014,1028]
===
match
---
operator: <= [9352,9354]
operator: <= [9383,9385]
===
match
---
name: Any [12751,12754]
name: Any [12782,12785]
===
match
---
string: """Resolves custom XCom class""" [13743,13775]
string: """Resolves custom XCom class""" [13774,13806]
===
match
---
operator: = [10479,10480]
operator: = [10510,10511]
===
match
---
name: orm_deserialize_value [2779,2800]
name: orm_deserialize_value [2810,2831]
===
match
---
testlist_comp [13168,13208]
testlist_comp [13199,13239]
===
match
---
name: Union [4205,4210]
name: Union [4236,4241]
===
match
---
suite [11338,11412]
suite [11369,11443]
===
match
---
fstring_expr [14049,14068]
fstring_expr [14080,14099]
===
match
---
name: timestamp [1809,1818]
name: timestamp [1809,1818]
===
match
---
trailer [13792,13802]
trailer [13823,13833]
===
match
---
atom_expr [9333,9351]
atom_expr [9364,9382]
===
match
---
expr_stmt [11834,11892]
expr_stmt [11865,11923]
===
match
---
name: cls [10304,10307]
name: cls [10335,10338]
===
match
---
atom_expr [11981,12036]
atom_expr [12012,12067]
===
match
---
trailer [10239,10241]
trailer [10270,10272]
===
match
---
name: task_id [8763,8770]
name: task_id [8794,8801]
===
match
---
simple_stmt [13005,13053]
simple_stmt [13036,13084]
===
match
---
if_stmt [11324,11412]
if_stmt [11355,11443]
===
match
---
import_name [788,799]
import_name [788,799]
===
match
---
if_stmt [8793,8971]
if_stmt [8824,9002]
===
match
---
name: add [3797,3800]
name: add [3828,3831]
===
match
---
decorator [10264,10281]
decorator [10295,10312]
===
match
---
comparison [3611,3625]
comparison [3642,3656]
===
match
---
if_stmt [8817,8971]
if_stmt [8848,9002]
===
match
---
suite [8842,8899]
suite [8873,8930]
===
match
---
name: resolve_xcom_backend [13715,13735]
name: resolve_xcom_backend [13746,13766]
===
match
---
simple_stmt [8744,8784]
simple_stmt [8775,8815]
===
match
---
trailer [8940,8947]
trailer [8971,8978]
===
match
---
trailer [11717,11724]
trailer [11748,11755]
===
match
---
trailer [3381,3391]
trailer [3412,3422]
===
match
---
operator: = [1783,1784]
operator: = [1783,1784]
===
match
---
arglist [11714,11771]
arglist [11745,11802]
===
match
---
trailer [5921,5930]
trailer [5952,5961]
===
match
---
suite [11570,11658]
suite [11601,11689]
===
match
---
param [9911,9915]
param [9942,9946]
===
match
---
atom_expr [8933,8970]
atom_expr [8964,9001]
===
match
---
name: task_id [3859,3866]
name: task_id [3890,3897]
===
match
---
simple_stmt [1263,1320]
simple_stmt [1263,1320]
===
match
---
name: UtcDateTime [1407,1418]
name: UtcDateTime [1407,1418]
===
match
---
if_stmt [5747,5886]
if_stmt [5778,5917]
===
match
---
simple_stmt [3441,3481]
simple_stmt [3472,3512]
===
match
---
simple_stmt [12308,12349]
simple_stmt [12339,12380]
===
match
---
name: models [9575,9581]
name: models [9606,9612]
===
match
---
name: staticmethod [12074,12086]
name: staticmethod [12105,12117]
===
match
---
name: TypeError [13956,13965]
name: TypeError [13987,13996]
===
match
---
decorator [12692,12706]
decorator [12723,12737]
===
match
---
operator: , [10307,10308]
operator: , [10338,10339]
===
match
---
operator: = [10018,10019]
operator: = [10049,10050]
===
match
---
if_stmt [3273,3481]
if_stmt [3304,3512]
===
match
---
atom_expr [11714,11724]
atom_expr [11745,11755]
===
match
---
atom_expr [14010,14024]
atom_expr [14041,14055]
===
match
---
name: value [13125,13130]
name: value [13156,13161]
===
match
---
name: self [2774,2778]
name: self [2805,2809]
===
match
---
trailer [6597,6617]
trailer [6628,6648]
===
match
---
name: log [1420,1423]
name: log [1420,1423]
===
match
---
simple_stmt [1809,1882]
simple_stmt [1809,1882]
===
match
---
trailer [13130,13137]
trailer [13161,13168]
===
match
---
name: execution_date [11859,11873]
name: execution_date [11890,11904]
===
match
---
fstring [10130,10182]
fstring [10161,10213]
===
match
---
trailer [3914,3916]
trailer [3945,3947]
===
match
---
name: query [11981,11986]
name: query [12012,12017]
===
match
---
atom_expr [10225,10241]
atom_expr [10256,10272]
===
match
---
name: get_one [3964,3971]
name: get_one [3995,4002]
===
match
---
except_clause [13160,13209]
except_clause [13191,13240]
===
match
---
name: cls [6312,6315]
name: cls [6343,6346]
===
match
---
trailer [12845,12877]
trailer [12876,12908]
===
match
---
import_from [11919,11959]
import_from [11950,11990]
===
match
---
dotted_name [1086,1107]
dotted_name [1086,1107]
===
match
---
name: dag_id [11331,11337]
name: dag_id [11362,11368]
===
match
---
decorated [2515,2803]
decorated [2546,2834]
===
match
---
expr_stmt [14129,14158]
expr_stmt [14160,14189]
===
match
---
suite [9937,10242]
suite [9968,10273]
===
match
---
name: xcom [10040,10044]
name: xcom [10071,10075]
===
match
---
comp_op [11809,11815]
comp_op [11840,11846]
===
match
---
operator: , [6156,6157]
operator: , [6187,6188]
===
match
---
simple_stmt [3189,3264]
simple_stmt [3220,3295]
===
match
---
name: session [6776,6783]
name: session [6807,6814]
===
match
---
trailer [11858,11873]
trailer [11889,11904]
===
match
---
operator: , [13809,13810]
operator: , [13840,13841]
===
match
---
operator: , [6099,6100]
operator: , [6130,6131]
===
match
---
operator: = [9622,9623]
operator: = [9653,9654]
===
match
---
trailer [8951,8958]
trailer [8982,8989]
===
match
---
trailer [1443,1453]
trailer [1443,1453]
===
match
---
name: value [3519,3524]
name: value [3550,3555]
===
match
---
name: provide_session [9880,9895]
name: provide_session [9911,9926]
===
match
---
trailer [9507,9512]
trailer [9538,9543]
===
match
---
arglist [3806,3889]
arglist [3837,3920]
===
match
---
trailer [6333,6341]
trailer [6364,6372]
===
match
---
arglist [3392,3420]
arglist [3423,3451]
===
match
---
trailer [9752,9757]
trailer [9783,9788]
===
match
---
trailer [8762,8770]
trailer [8793,8801]
===
match
---
atom_expr [3901,3916]
atom_expr [3932,3947]
===
match
---
simple_stmt [1546,1568]
simple_stmt [1546,1568]
===
match
---
trailer [11682,11688]
trailer [11713,11719]
===
match
---
atom_expr [11454,11509]
atom_expr [11485,11540]
===
match
---
operator: , [4117,4118]
operator: , [4148,4149]
===
match
---
dotted_name [3301,3322]
dotted_name [3332,3353]
===
match
---
operator: , [12375,12376]
operator: , [12406,12407]
===
match
---
name: clazz [13780,13785]
name: clazz [13811,13816]
===
match
---
tfpdef [6696,6721]
tfpdef [6727,6752]
===
match
---
expr_stmt [8518,8530]
expr_stmt [8549,8561]
===
match
---
param [4248,4282]
param [4279,4313]
===
match
---
operator: , [6067,6068]
operator: , [6098,6099]
===
match
---
name: dag_ids [6085,6092]
name: dag_ids [6116,6123]
===
match
---
atom_expr [12965,12987]
atom_expr [12996,13018]
===
match
---
simple_stmt [1711,1773]
simple_stmt [1711,1773]
===
match
---
simple_stmt [2462,2510]
simple_stmt [2493,2541]
===
match
---
name: filter [9648,9654]
name: filter [9679,9685]
===
match
---
raise_stmt [11351,11411]
raise_stmt [11382,11442]
===
match
---
name: xcoms [9986,9991]
name: xcoms [10017,10022]
===
match
---
trailer [13702,13708]
trailer [13733,13739]
===
match
---
operator: , [4238,4239]
operator: , [4269,4270]
===
match
---
name: Iterable [4156,4164]
name: Iterable [4187,4195]
===
match
---
atom_expr [6543,6556]
atom_expr [6574,6587]
===
match
---
name: relationship [1067,1079]
name: relationship [1067,1079]
===
match
---
name: primary_key [2022,2033]
name: primary_key [2022,2033]
===
match
---
fstring [2843,2906]
fstring [2874,2937]
===
match
---
name: filters [8668,8675]
name: filters [8699,8706]
===
match
---
atom_expr [8759,8770]
atom_expr [8790,8801]
===
match
---
trailer [9742,9752]
trailer [9773,9783]
===
match
---
name: log [1282,1285]
name: log [1282,1285]
===
match
---
if_stmt [10067,10184]
if_stmt [10098,10215]
===
match
---
trailer [3796,3800]
trailer [3827,3831]
===
match
---
name: serialize_value [3503,3518]
name: serialize_value [3534,3549]
===
match
---
suite [11435,11510]
suite [11466,11541]
===
match
---
operator: , [1174,1175]
operator: , [1174,1175]
===
match
---
atom_expr [6508,6521]
atom_expr [6539,6552]
===
match
---
operator: , [938,939]
operator: , [938,939]
===
match
---
suite [3040,3917]
suite [3071,3948]
===
match
---
trailer [13035,13042]
trailer [13066,13073]
===
match
---
name: run_id [2462,2468]
name: run_id [2493,2499]
===
match
---
name: logging [807,814]
name: logging [807,814]
===
match
---
funcdef [13266,13709]
funcdef [13297,13740]
===
match
---
operator: @ [6384,6385]
operator: @ [6415,6416]
===
match
---
atom_expr [3689,3699]
atom_expr [3720,3730]
===
match
---
name: Column [1785,1791]
name: Column [1785,1791]
===
match
---
import_from [829,878]
import_from [829,878]
===
match
---
operator: , [871,872]
operator: , [871,872]
===
match
---
trailer [8450,8508]
trailer [8481,8539]
===
match
---
atom_expr [3665,3676]
atom_expr [3696,3707]
===
match
---
operator: = [6484,6485]
operator: = [6515,6516]
===
match
---
name: limit [9773,9778]
name: limit [9804,9809]
===
match
---
operator: = [13835,13836]
operator: = [13866,13867]
===
match
---
atom [11553,11569]
atom [11584,11600]
===
match
---
atom_expr [6644,6679]
atom_expr [6675,6710]
===
match
---
operator: @ [12073,12074]
operator: @ [12104,12105]
===
match
---
trailer [2488,2509]
trailer [2519,2540]
===
match
---
name: query [11842,11847]
name: query [11873,11878]
===
match
---
expr_stmt [3441,3480]
expr_stmt [3472,3511]
===
match
---
name: key [6538,6541]
name: key [6569,6572]
===
match
---
comp_op [9399,9405]
comp_op [9430,9436]
===
match
---
name: utcnow [1858,1864]
name: utcnow [1858,1864]
===
match
---
name: task_id [3669,3676]
name: task_id [3700,3707]
===
match
---
name: key [8586,8589]
name: key [8617,8620]
===
match
---
atom_expr [4325,4338]
atom_expr [4356,4369]
===
match
---
argument [1841,1864]
argument [1841,1864]
===
match
---
argument [3876,3889]
argument [3907,3920]
===
match
---
simple_stmt [1081,1120]
simple_stmt [1081,1120]
===
match
---
operator: , [1734,1735]
operator: , [1734,1735]
===
match
---
trailer [4204,4231]
trailer [4235,4262]
===
match
---
operator: = [3358,3359]
operator: = [3389,3390]
===
match
---
operator: = [6557,6558]
operator: = [6588,6589]
===
match
---
trailer [6652,6679]
trailer [6683,6710]
===
match
---
simple_stmt [1120,1181]
simple_stmt [1120,1181]
===
match
---
name: first [6256,6261]
name: first [6287,6292]
===
match
---
name: filters [9521,9528]
name: filters [9552,9559]
===
match
---
name: run_id [3414,3420]
name: run_id [3445,3451]
===
match
---
operator: , [3857,3858]
operator: , [3888,3889]
===
match
---
name: Optional [10333,10341]
name: Optional [10364,10372]
===
match
---
suite [6292,6342]
suite [6323,6373]
===
match
---
name: Any [12118,12121]
name: Any [12149,12152]
===
match
---
argument [6085,6099]
argument [6116,6130]
===
match
---
trailer [3421,3425]
trailer [3452,3456]
===
match
---
atom_expr [6456,6483]
atom_expr [6487,6514]
===
match
---
name: xcoms [9916,9921]
name: xcoms [9947,9952]
===
match
---
name: BaseXCom [13859,13867]
name: BaseXCom [13890,13898]
===
match
---
raise_stmt [5811,5885]
raise_stmt [5842,5916]
===
match
---
operator: = [6181,6182]
operator: = [6212,6213]
===
match
---
comparison [9439,9475]
comparison [9470,9506]
===
match
---
param [2958,2962]
param [2989,2993]
===
match
---
name: provide_session [10265,10280]
name: provide_session [10296,10311]
===
match
---
trailer [13867,13876]
trailer [13898,13907]
===
match
---
subscriptlist [6598,6616]
subscriptlist [6629,6647]
===
match
---
parameters [13735,13737]
parameters [13766,13768]
===
match
---
name: cls [11748,11751]
name: cls [11779,11782]
===
match
---
raise_stmt [11583,11657]
raise_stmt [11614,11688]
===
match
---
comparison [11748,11770]
comparison [11779,11801]
===
match
---
param [9916,9922]
param [9947,9953]
===
match
---
name: value [3821,3826]
name: value [3852,3857]
===
match
---
arglist [1995,2019]
arglist [1995,2019]
===
match
---
name: value [2968,2973]
name: value [2999,3004]
===
match
---
atom_expr [3458,3480]
atom_expr [3489,3511]
===
match
---
string: "xcom_backend" [13811,13825]
string: "xcom_backend" [13842,13856]
===
match
---
arglist [10085,10095]
arglist [10116,10126]
===
match
---
trailer [11751,11759]
trailer [11782,11790]
===
match
---
string: 'return_value' [1586,1600]
string: 'return_value' [1586,1600]
===
match
---
operator: , [6563,6564]
operator: , [6594,6595]
===
match
---
name: query [9697,9702]
name: query [9728,9733]
===
match
---
name: UtcDateTime [1910,1921]
name: UtcDateTime [1910,1921]
===
match
---
operator: , [2498,2499]
operator: , [2529,2530]
===
match
---
param [6776,6800]
param [6807,6831]
===
match
---
param [4188,4239]
param [4219,4270]
===
match
---
name: cls [3981,3984]
name: cls [4012,4015]
===
match
---
operator: = [3882,3883]
operator: = [3913,3914]
===
match
---
not_test [10070,10096]
not_test [10101,10127]
===
match
---
name: delete [12059,12065]
name: delete [12090,12096]
===
match
---
operator: , [10424,10425]
operator: , [10455,10456]
===
match
---
trailer [4210,4230]
trailer [4241,4261]
===
match
---
trailer [12931,12945]
trailer [12962,12976]
===
match
---
suite [13305,13709]
suite [13336,13740]
===
match
---
name: self [2866,2870]
name: self [2897,2901]
===
match
---
operator: = [6001,6002]
operator: = [6032,6033]
===
match
---
operator: } [2861,2862]
operator: } [2892,2893]
===
match
---
trailer [2059,2111]
trailer [2059,2111]
===
match
---
operator: = [2105,2106]
operator: = [2105,2106]
===
match
---
operator: = [6522,6523]
operator: = [6553,6554]
===
match
---
operator: == [8583,8585]
operator: == [8614,8616]
===
match
---
suite [8547,8591]
suite [8578,8622]
===
match
---
trailer [8758,8783]
trailer [8789,8814]
===
match
---
atom_expr [11992,12003]
atom_expr [12023,12034]
===
insert-node
---
name: BaseXCom [1609,1617]
to
classdef [1603,13709]
at 0
===
insert-tree
---
arglist [1618,1636]
    name: Base [1618,1622]
    operator: , [1622,1623]
    name: LoggingMixin [1624,1636]
to
classdef [1603,13709]
at 1
===
insert-tree
---
simple_stmt [1643,1678]
    string: """Base class for XCom objects.""" [1643,1677]
to
suite [1638,13709]
at 0
===
insert-tree
---
simple_stmt [2219,2489]
    expr_stmt [2219,2488]
        name: dag_run [2219,2226]
        operator: = [2227,2228]
        atom_expr [2229,2488]
            name: relationship [2229,2241]
            trailer [2241,2488]
                arglist [2251,2482]
                    string: "DagRun" [2251,2259]
                    operator: , [2259,2260]
                    argument [2269,2427]
                        name: primaryjoin [2269,2280]
                        operator: = [2280,2281]
                        string: """and_(             BaseXCom.dag_id == foreign(DagRun.dag_id),             BaseXCom.execution_date == foreign(DagRun.execution_date)         )""" [2281,2427]
                    operator: , [2427,2428]
                    argument [2437,2450]
                        name: uselist [2437,2444]
                        operator: = [2444,2445]
                    operator: , [2450,2451]
                    argument [2460,2481]
                        name: passive_deletes [2460,2475]
                        operator: = [2475,2476]
                        string: "all" [2476,2481]
                    operator: , [2481,2482]
to
suite [1638,13709]
at 9
===
delete-node
---
name: BaseXCom [1609,1617]
===
===
delete-tree
---
arglist [1618,1636]
    name: Base [1618,1622]
    operator: , [1622,1623]
    name: LoggingMixin [1624,1636]
===
delete-tree
---
simple_stmt [1643,1678]
    string: """Base class for XCom objects.""" [1643,1677]
===
delete-tree
---
simple_stmt [2219,2458]
    expr_stmt [2219,2457]
        name: dag_run [2219,2226]
        operator: = [2227,2228]
        atom_expr [2229,2457]
            name: relationship [2229,2241]
            trailer [2241,2457]
                arglist [2251,2451]
                    string: "DagRun" [2251,2259]
                    operator: , [2259,2260]
                    argument [2269,2427]
                        name: primaryjoin [2269,2280]
                        operator: = [2280,2281]
                        string: """and_(             BaseXCom.dag_id == foreign(DagRun.dag_id),             BaseXCom.execution_date == foreign(DagRun.execution_date)         )""" [2281,2427]
                    operator: , [2427,2428]
                    argument [2437,2450]
                        name: uselist [2437,2444]
                        operator: = [2444,2445]
                    operator: , [2450,2451]
