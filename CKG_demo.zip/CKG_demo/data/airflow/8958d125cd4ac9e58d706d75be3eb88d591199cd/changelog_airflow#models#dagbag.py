===
match
---
fstring_start: f" [9106,9108]
fstring_start: f" [9135,9137]
===
match
---
atom_expr [11701,11757]
atom_expr [11730,11786]
===
match
---
trailer [11790,11795]
trailer [11819,11824]
===
match
---
expr_stmt [11847,11897]
expr_stmt [11876,11926]
===
match
---
funcdef [21203,24021]
funcdef [21232,24050]
===
match
---
trailer [11246,11251]
trailer [11275,11280]
===
match
---
name: dag_id [7644,7650]
name: dag_id [7673,7679]
===
match
---
name: root_dag_id [7630,7641]
name: root_dag_id [7659,7670]
===
match
---
name: file_last_changed_on_disk [10669,10694]
name: file_last_changed_on_disk [10698,10723]
===
match
---
operator: = [4597,4598]
operator: = [4597,4598]
===
match
---
trailer [19961,19975]
trailer [19990,20004]
===
match
---
name: hashlib [795,802]
name: hashlib [795,802]
===
match
---
simple_stmt [20293,20325]
simple_stmt [20322,20354]
===
match
---
operator: , [1051,1052]
operator: , [1051,1052]
===
match
---
name: len [19176,19179]
name: len [19205,19208]
===
match
---
trailer [22385,22396]
trailer [22414,22425]
===
match
---
operator: { [20916,20917]
operator: { [20945,20946]
===
match
---
name: self [8763,8767]
name: self [8792,8796]
===
match
---
trailer [9402,9411]
trailer [9431,9440]
===
match
---
trailer [7457,7489]
trailer [7486,7518]
===
match
---
name: warnings [945,953]
name: warnings [945,953]
===
match
---
expr_stmt [10470,10526]
expr_stmt [10499,10555]
===
match
---
name: filepath [10886,10894]
name: filepath [10915,10923]
===
match
---
name: dag_folder [18225,18235]
name: dag_folder [18254,18264]
===
match
---
name: subdag [17165,17171]
name: subdag [17194,17200]
===
match
---
name: self [7510,7514]
name: self [7539,7543]
===
match
---
name: mods [12558,12562]
name: mods [12587,12591]
===
match
---
operator: } [21075,21076]
operator: } [21104,21105]
===
match
---
name: insert [13703,13709]
name: insert [13732,13738]
===
match
---
operator: = [20182,20183]
operator: = [20211,20212]
===
match
---
name: sqlalchemy [1225,1235]
name: sqlalchemy [1225,1235]
===
match
---
expr_stmt [7695,7718]
expr_stmt [7724,7747]
===
match
---
trailer [3361,3372]
trailer [3361,3372]
===
match
---
file_input [788,24021]
file_input [788,24050]
===
match
---
trailer [11314,11321]
trailer [11343,11350]
===
match
---
name: warn [3828,3832]
name: warn [3828,3832]
===
match
---
name: is_subdag [16551,16560]
name: is_subdag [16580,16589]
===
match
---
parameters [20385,20391]
parameters [20414,20420]
===
match
---
atom_expr [8763,8780]
atom_expr [8792,8809]
===
match
---
name: current_zip_file [12645,12661]
name: current_zip_file [12674,12690]
===
match
---
fstring_string: Invalid Cron expression:  [15394,15419]
fstring_string: Invalid Cron expression:  [15423,15448]
===
match
---
operator: = [7642,7643]
operator: = [7671,7672]
===
match
---
atom_expr [22091,22134]
atom_expr [22120,22163]
===
match
---
expr_stmt [12686,12728]
expr_stmt [12715,12757]
===
match
---
name: CroniterBadCronError [1100,1120]
name: CroniterBadCronError [1100,1120]
===
match
---
name: self [4697,4701]
name: self [4697,4701]
===
match
---
trailer [22890,22905]
trailer [22919,22934]
===
match
---
name: orm_dag [8200,8207]
name: orm_dag [8229,8236]
===
match
---
name: dag_folder [18258,18268]
name: dag_folder [18287,18297]
===
match
---
except_clause [15171,15255]
except_clause [15200,15284]
===
match
---
name: sum [19171,19174]
name: sum [19200,19203]
===
match
---
simple_stmt [14983,15026]
simple_stmt [15012,15055]
===
match
---
name: subdag [16601,16607]
name: subdag [16630,16636]
===
match
---
trailer [4460,4478]
trailer [4460,4478]
===
match
---
expr_stmt [4846,4947]
expr_stmt [4846,4947]
===
match
---
trailer [18936,19307]
trailer [18965,19336]
===
match
---
simple_stmt [10553,10609]
simple_stmt [10582,10638]
===
match
---
name: fileloc [8443,8450]
name: fileloc [8472,8479]
===
match
---
expr_stmt [14446,14487]
expr_stmt [14475,14516]
===
match
---
name: dag_folder [3290,3300]
name: dag_folder [3290,3300]
===
match
---
name: dag_folder [18473,18483]
name: dag_folder [18502,18512]
===
match
---
trailer [23221,23233]
trailer [23250,23262]
===
match
---
operator: , [13958,13959]
operator: , [13987,13988]
===
match
---
name: dagbag_import_error_tracebacks [4747,4777]
name: dagbag_import_error_tracebacks [4747,4777]
===
match
---
atom_expr [16470,16487]
atom_expr [16499,16516]
===
match
---
name: has_logged [13373,13383]
name: has_logged [13402,13412]
===
match
---
name: filepath [14325,14333]
name: filepath [14354,14362]
===
match
---
trailer [4428,4439]
trailer [4428,4439]
===
match
---
suite [15906,17280]
suite [15935,17309]
===
match
---
name: dag [21581,21584]
name: dag [21610,21613]
===
match
---
name: importlib [11701,11710]
name: importlib [11730,11739]
===
match
---
import_from [1010,1061]
import_from [1010,1061]
===
match
---
trailer [20779,20786]
trailer [20808,20815]
===
match
---
expr_stmt [8187,8271]
expr_stmt [8216,8300]
===
match
---
atom_expr [12116,12168]
atom_expr [12145,12197]
===
match
---
string: 'dagbag_import_error_traceback_depth' [4909,4946]
string: 'dagbag_import_error_traceback_depth' [4909,4946]
===
match
---
operator: = [7480,7481]
operator: = [7509,7510]
===
match
---
simple_stmt [1063,1079]
simple_stmt [1063,1079]
===
match
---
fstring_start: f' [11363,11365]
fstring_start: f' [11392,11394]
===
match
---
name: CroniterNotAlphaError [1144,1165]
name: CroniterNotAlphaError [1144,1165]
===
match
---
if_stmt [3781,4112]
if_stmt [3781,4112]
===
match
---
trailer [4893,4900]
trailer [4893,4900]
===
match
---
atom_expr [5269,5278]
atom_expr [5269,5278]
===
match
---
atom_expr [4956,5154]
atom_expr [4956,5154]
===
match
---
operator: } [9120,9121]
operator: } [9149,9150]
===
match
---
import_from [1255,1284]
import_from [1255,1284]
===
match
---
trailer [15320,15334]
trailer [15349,15363]
===
match
---
simple_stmt [20762,21155]
simple_stmt [20791,21184]
===
match
---
parameters [12521,12548]
parameters [12550,12577]
===
match
---
trailer [14239,14253]
trailer [14268,14282]
===
match
---
name: utcnow [18697,18703]
name: utcnow [18726,18732]
===
match
---
name: airflow [8935,8942]
name: airflow [8964,8971]
===
match
---
operator: = [4887,4888]
operator: = [4887,4888]
===
match
---
trailer [23644,23661]
trailer [23673,23690]
===
match
---
suite [17192,17246]
suite [17221,17275]
===
match
---
name: os [891,893]
name: os [891,893]
===
match
---
name: self [12116,12120]
name: self [12145,12149]
===
match
---
if_stmt [13122,13577]
if_stmt [13151,13606]
===
match
---
name: found_dags [15133,15143]
name: found_dags [15162,15172]
===
match
---
name: mod_name [11473,11481]
name: mod_name [11502,11510]
===
match
---
name: Optional [3639,3647]
name: Optional [3639,3647]
===
match
---
import_as_names [990,1009]
import_as_names [990,1009]
===
match
---
name: dags [9234,9238]
name: dags [9263,9267]
===
match
---
simple_stmt [6082,6122]
simple_stmt [6082,6122]
===
match
---
simple_stmt [14815,14838]
simple_stmt [14844,14867]
===
match
---
trailer [16510,16521]
trailer [16539,16550]
===
match
---
name: str [19245,19248]
name: str [19274,19277]
===
match
---
operator: , [15221,15222]
operator: , [15250,15251]
===
match
---
name: values [23516,23522]
name: values [23545,23551]
===
match
---
operator: = [7939,7940]
operator: = [7968,7969]
===
match
---
trailer [14818,14826]
trailer [14847,14855]
===
match
---
name: safe_mode [10841,10850]
name: safe_mode [10870,10879]
===
match
---
name: sum [20541,20544]
name: sum [20570,20573]
===
match
---
name: reraise [22997,23004]
name: reraise [23026,23033]
===
match
---
import_name [894,904]
import_name [894,904]
===
match
---
operator: , [19284,19285]
operator: , [19313,19314]
===
match
---
name: org_mod_name [11209,11221]
name: org_mod_name [11238,11250]
===
match
---
operator: = [11033,11034]
operator: = [11062,11063]
===
match
---
atom_expr [18967,19009]
atom_expr [18996,19038]
===
match
---
operator: = [19941,19942]
operator: = [19970,19971]
===
match
---
name: self [18272,18276]
name: self [18301,18305]
===
match
---
trailer [20586,20600]
trailer [20615,20629]
===
match
---
name: retry [22689,22694]
name: retry [22718,22723]
===
match
---
trailer [3519,3530]
trailer [3519,3530]
===
match
---
trailer [3310,3315]
trailer [3310,3315]
===
match
---
name: os [11244,11246]
name: os [11273,11275]
===
match
---
simple_stmt [18245,18288]
simple_stmt [18274,18317]
===
match
---
fstring [20800,21144]
fstring [20829,21173]
===
match
---
name: _process_modules [10636,10652]
name: _process_modules [10665,10681]
===
match
---
name: get_dag [5841,5848]
name: get_dag [5841,5848]
===
match
---
atom_expr [22933,22983]
atom_expr [22962,23012]
===
match
---
trailer [8767,8772]
trailer [8796,8801]
===
match
---
name: DEBUG [22977,22982]
name: DEBUG [23006,23011]
===
match
---
name: module_from_spec [11875,11891]
name: module_from_spec [11904,11920]
===
match
---
tfpdef [8850,8861]
tfpdef [8879,8890]
===
match
---
name: import_errors [14240,14253]
name: import_errors [14269,14282]
===
match
---
name: CroniterBadDateError [1122,1142]
name: CroniterBadDateError [1122,1142]
===
match
---
name: self [6516,6520]
name: self [6516,6520]
===
match
---
name: textwrap [912,920]
name: textwrap [912,920]
===
match
---
trailer [20624,20652]
trailer [20653,20681]
===
match
---
operator: @ [5816,5817]
operator: @ [5816,5817]
===
match
---
name: Optional [1053,1061]
name: Optional [1053,1061]
===
match
---
trailer [10372,10376]
trailer [10401,10405]
===
match
---
name: import_errors [14051,14064]
name: import_errors [14080,14093]
===
match
---
expr_stmt [18245,18287]
expr_stmt [18274,18316]
===
match
---
classdef [1989,24021]
classdef [1989,24050]
===
match
---
trailer [6361,6366]
trailer [6361,6366]
===
match
---
name: log [13416,13419]
name: log [13445,13448]
===
match
---
atom_expr [11244,11271]
atom_expr [11273,11300]
===
match
---
suite [10266,10293]
suite [10295,10322]
===
match
---
simple_stmt [14281,14293]
simple_stmt [14310,14322]
===
match
---
decorated [21182,24021]
decorated [21211,24050]
===
match
---
simple_stmt [5680,5773]
simple_stmt [5680,5773]
===
match
---
atom_expr [13080,13097]
atom_expr [13109,13126]
===
match
---
name: str [1983,1986]
name: str [1983,1986]
===
match
---
trailer [16332,16344]
trailer [16361,16373]
===
match
---
atom [20676,20703]
atom [20705,20732]
===
match
---
trailer [20263,20271]
trailer [20292,20300]
===
match
---
name: safe_mode [18806,18815]
name: safe_mode [18835,18844]
===
match
---
atom_expr [20546,20556]
atom_expr [20575,20585]
===
match
---
atom_expr [9399,9411]
atom_expr [9428,9440]
===
match
---
name: x [19485,19486]
name: x [19514,19515]
===
match
---
atom_expr [22969,22982]
atom_expr [22998,23011]
===
match
---
if_stmt [10078,10293]
if_stmt [10107,10322]
===
match
---
name: stats [20645,20650]
name: stats [20674,20679]
===
match
---
name: subdags [17133,17140]
name: subdags [17162,17169]
===
match
---
name: read_dags_from_db [3575,3592]
name: read_dags_from_db [3575,3592]
===
match
---
trailer [19489,19498]
trailer [19518,19527]
===
match
---
suite [13195,13577]
suite [13224,13606]
===
match
---
name: e [12065,12066]
name: e [12094,12095]
===
match
---
suite [5182,5280]
suite [5182,5280]
===
match
---
name: conf [17397,17401]
name: conf [17426,17430]
===
match
---
trailer [13709,13722]
trailer [13738,13751]
===
match
---
name: m [14544,14545]
name: m [14573,14574]
===
match
---
arglist [4901,4946]
arglist [4901,4946]
===
match
---
name: filepath [13713,13721]
name: filepath [13742,13750]
===
match
---
return_stmt [21163,21176]
return_stmt [21192,21205]
===
match
---
name: filepath [13020,13028]
name: filepath [13049,13057]
===
match
---
name: str [4718,4721]
name: str [4718,4721]
===
match
---
simple_stmt [14871,14893]
simple_stmt [14900,14922]
===
match
---
name: filename [13521,13529]
name: filename [13550,13558]
===
match
---
trailer [16304,16310]
trailer [16333,16339]
===
match
---
name: only_if_updated [9450,9465]
name: only_if_updated [9479,9494]
===
match
---
atom_expr [19180,19189]
atom_expr [19209,19218]
===
match
---
string: "Reading %s from %s" [13058,13078]
string: "Reading %s from %s" [13087,13107]
===
match
---
atom_expr [7202,7337]
atom_expr [7202,7337]
===
match
---
suite [5339,5621]
suite [5339,5621]
===
match
---
trailer [19466,19513]
trailer [19495,19542]
===
match
---
name: settings [22091,22099]
name: settings [22120,22128]
===
match
---
name: _ [11223,11224]
name: _ [11252,11253]
===
match
---
suite [12673,14273]
suite [12702,14302]
===
match
---
name: import_errors [4381,4394]
name: import_errors [4381,4394]
===
match
---
name: self [15445,15449]
name: self [15474,15478]
===
match
---
trailer [4850,4886]
trailer [4850,4886]
===
match
---
suite [6367,6538]
suite [6367,6538]
===
match
---
trailer [18186,18191]
trailer [18215,18220]
===
match
---
simple_stmt [21268,21319]
simple_stmt [21297,21348]
===
match
---
argument [19500,19512]
argument [19529,19541]
===
match
---
trailer [3200,3248]
trailer [3200,3248]
===
match
---
trailer [9028,9045]
trailer [9057,9074]
===
match
---
name: might_contain_dag [10868,10885]
name: might_contain_dag [10897,10914]
===
match
---
atom_expr [4780,4837]
atom_expr [4780,4837]
===
match
---
fstring_string:          DagBag parsing time:  [21076,21106]
fstring_string:          DagBag parsing time:  [21105,21135]
===
match
---
atom [22362,22446]
atom [22391,22475]
===
match
---
name: dag [15317,15320]
name: dag [15346,15349]
===
match
---
argument [22813,22827]
argument [22842,22856]
===
match
---
atom_expr [9344,9361]
atom_expr [9373,9390]
===
match
---
simple_stmt [14446,14488]
simple_stmt [14475,14517]
===
match
---
atom_expr [5793,5809]
atom_expr [5793,5809]
===
match
---
return_stmt [5781,5810]
return_stmt [5781,5810]
===
match
---
dotted_name [1501,1514]
dotted_name [1501,1514]
===
match
---
name: safe_mode [9472,9481]
name: safe_mode [9501,9510]
===
match
---
testlist_comp [22363,22445]
testlist_comp [22392,22474]
===
match
---
name: only_if_updated [18763,18778]
name: only_if_updated [18792,18807]
===
match
---
name: SourceFileLoader [11721,11737]
name: SourceFileLoader [11750,11766]
===
match
---
atom_expr [12963,13029]
atom_expr [12992,13058]
===
match
---
dotted_name [19607,19636]
dotted_name [19636,19665]
===
match
---
if_stmt [14748,14838]
if_stmt [14777,14867]
===
match
---
name: bool [5334,5338]
name: bool [5334,5338]
===
match
---
name: replace [18976,18983]
name: replace [19005,19012]
===
match
---
name: os [12696,12698]
name: os [12725,12727]
===
match
---
name: dags [8174,8178]
name: dags [8203,8207]
===
match
---
argument [6461,6474]
argument [6461,6474]
===
match
---
atom_expr [10015,10065]
atom_expr [10044,10094]
===
match
---
operator: = [7310,7311]
operator: = [7310,7311]
===
match
---
arglist [14923,14960]
arglist [14952,14989]
===
match
---
name: croniter [1084,1092]
name: croniter [1084,1092]
===
match
---
suite [3806,4112]
suite [3806,4112]
===
match
---
arglist [12980,13028]
arglist [13009,13057]
===
match
---
simple_stmt [18890,19326]
simple_stmt [18919,19355]
===
match
---
operator: -> [5331,5333]
operator: -> [5331,5333]
===
match
---
trailer [16453,16467]
trailer [16482,16496]
===
match
---
name: path [11247,11251]
name: path [11276,11280]
===
match
---
name: int [1951,1954]
name: int [1951,1954]
===
match
---
string: 'scheduler_zombie_task_threshold' [3214,3247]
string: 'scheduler_zombie_task_threshold' [3214,3247]
===
match
---
name: dag_folder [4987,4997]
name: dag_folder [4987,4997]
===
match
---
name: provide_session [1767,1782]
name: provide_session [1767,1782]
===
match
---
expr_stmt [1959,1972]
expr_stmt [1959,1972]
===
match
---
name: datetime [4353,4361]
name: datetime [4353,4361]
===
match
---
operator: == [17090,17092]
operator: == [17119,17121]
===
match
---
atom_expr [4553,4575]
atom_expr [4553,4575]
===
match
---
name: correct_maybe_zipped [8414,8434]
name: correct_maybe_zipped [8443,8463]
===
match
---
operator: , [15062,15063]
operator: , [15091,15092]
===
match
---
name: values [20220,20226]
name: values [20249,20255]
===
match
---
name: self [13368,13372]
name: self [13397,13401]
===
match
---
testlist_star_expr [11209,11224]
testlist_star_expr [11238,11253]
===
match
---
string: """         Given a path to a python module or zip file, this method imports         the module and look for dag objects within it.         """ [9497,9640]
string: """         Given a path to a python module or zip file, this method imports         the module and look for dag objects within it.         """ [9526,9669]
===
match
---
atom [4365,4367]
atom [4365,4367]
===
match
---
argument [7268,7281]
argument [7268,7281]
===
match
---
argument [7303,7318]
argument [7303,7318]
===
match
---
trailer [14926,14955]
trailer [14955,14984]
===
match
---
simple_stmt [23971,24021]
simple_stmt [24000,24050]
===
match
---
name: min_serialized_dag_fetch_secs [6881,6910]
name: min_serialized_dag_fetch_secs [6881,6910]
===
match
---
atom_expr [3819,4057]
atom_expr [3819,4057]
===
match
---
simple_stmt [4956,5155]
simple_stmt [4956,5155]
===
match
---
name: dag [9178,9181]
name: dag [9207,9210]
===
match
---
name: self [4214,4218]
name: self [4214,4218]
===
match
---
trailer [4784,4795]
trailer [4784,4795]
===
match
---
param [10831,10840]
param [10860,10869]
===
match
---
name: read_all_dags [19962,19975]
name: read_all_dags [19991,20004]
===
match
---
simple_stmt [6439,6493]
simple_stmt [6439,6493]
===
match
---
name: file_last_changed_on_disk [14341,14366]
name: file_last_changed_on_disk [14370,14395]
===
match
---
operator: , [15664,15665]
operator: , [15693,15694]
===
match
---
name: m [14520,14521]
name: m [14549,14550]
===
match
---
name: dags [23667,23671]
name: dags [23696,23700]
===
match
---
name: zipfile [961,968]
name: zipfile [961,968]
===
match
---
name: Session [21242,21249]
name: Session [21271,21278]
===
match
---
name: dag_num [21030,21037]
name: dag_num [21059,21066]
===
match
---
atom_expr [19440,19457]
atom_expr [19469,19486]
===
match
---
operator: = [20539,20540]
operator: = [20568,20569]
===
match
---
operator: , [1039,1040]
operator: , [1039,1040]
===
match
---
atom_expr [19677,19707]
atom_expr [19706,19736]
===
match
---
name: parent_dag [16511,16521]
name: parent_dag [16540,16550]
===
match
---
trailer [3108,3117]
trailer [3108,3117]
===
match
---
name: self [20467,20471]
name: self [20496,20500]
===
match
---
expr_stmt [12434,12471]
expr_stmt [12463,12500]
===
match
---
trailer [5268,5279]
trailer [5268,5279]
===
match
---
name: dag [16524,16527]
name: dag [16553,16556]
===
match
---
trailer [17186,17191]
trailer [17215,17220]
===
match
---
fstring_string: DAG ' [9108,9113]
fstring_string: DAG ' [9137,9142]
===
match
---
operator: = [13754,13755]
operator: = [13783,13784]
===
match
---
name: list_py_file_paths [18441,18459]
name: list_py_file_paths [18470,18488]
===
match
---
atom_expr [4846,4886]
atom_expr [4846,4886]
===
match
---
decorated [5816,8818]
decorated [5816,8847]
===
match
---
operator: = [9004,9005]
operator: = [9033,9034]
===
match
---
name: filepath [12159,12167]
name: filepath [12188,12196]
===
match
---
name: dag_id [7662,7668]
name: dag_id [7691,7697]
===
match
---
expr_stmt [18351,18361]
expr_stmt [18380,18390]
===
match
---
string: 'scheduler' [3201,3212]
string: 'scheduler' [3201,3212]
===
match
---
comp_op [6350,6356]
comp_op [6350,6356]
===
match
---
operator: = [20744,20745]
operator: = [20773,20774]
===
match
---
fstring_expr [21029,21038]
fstring_expr [21058,21067]
===
match
---
trailer [15111,15116]
trailer [15140,15145]
===
match
---
import_from [1464,1495]
import_from [1464,1495]
===
match
---
expr_stmt [11492,11581]
expr_stmt [11521,11610]
===
match
---
name: timedelta [1000,1009]
name: timedelta [1000,1009]
===
match
---
name: Dict [4343,4347]
name: Dict [4343,4347]
===
match
---
name: append [15105,15111]
name: append [15134,15140]
===
match
---
name: filepath [9440,9448]
name: filepath [9469,9477]
===
match
---
trailer [8736,8741]
trailer [8765,8770]
===
match
---
suite [8742,8781]
suite [8771,8810]
===
match
---
name: loader [11823,11829]
name: loader [11852,11858]
===
match
---
name: airflow [6087,6094]
name: airflow [6087,6094]
===
match
---
name: DAGS_FOLDER [18993,19004]
name: DAGS_FOLDER [19022,19033]
===
match
---
name: dag_id [9114,9120]
name: dag_id [9143,9149]
===
match
---
trailer [22408,22444]
trailer [22437,22473]
===
match
---
decorator [5285,5295]
decorator [5285,5295]
===
match
---
operator: = [15814,15815]
operator: = [15843,15844]
===
match
---
expr_stmt [19440,19513]
expr_stmt [19469,19542]
===
match
---
name: self [9370,9374]
name: self [9399,9403]
===
match
---
atom_expr [15622,15684]
atom_expr [15651,15713]
===
match
---
import_name [803,819]
import_name [803,819]
===
match
---
trailer [22812,22835]
trailer [22841,22864]
===
match
---
atom_expr [7384,7414]
atom_expr [7413,7443]
===
match
---
name: self [15885,15889]
name: self [15914,15918]
===
match
---
name: normalized_schedule_interval [14927,14955]
name: normalized_schedule_interval [14956,14984]
===
match
---
name: self [5652,5656]
name: self [5652,5656]
===
match
---
trailer [14671,14685]
trailer [14700,14714]
===
match
---
name: subdag [9194,9200]
name: subdag [9223,9229]
===
match
---
name: CroniterBadDateError [15201,15221]
name: CroniterBadDateError [15230,15250]
===
match
---
expr_stmt [4177,4205]
expr_stmt [4177,4205]
===
match
---
atom_expr [10631,10695]
atom_expr [10660,10724]
===
match
---
trailer [19688,19707]
trailer [19717,19736]
===
match
---
name: self [16584,16588]
name: self [16613,16617]
===
match
---
trailer [20786,21154]
trailer [20815,21183]
===
match
---
param [10841,10850]
param [10870,10879]
===
match
---
name: session [7983,7990]
name: session [8012,8019]
===
match
---
atom [23083,23085]
atom [23112,23114]
===
match
---
suite [14962,15026]
suite [14991,15055]
===
match
---
trailer [6520,6525]
trailer [6520,6525]
===
match
---
name: orm_dag [7931,7938]
name: orm_dag [7960,7967]
===
match
---
simple_stmt [21433,21468]
simple_stmt [21462,21497]
===
match
---
operator: = [4440,4441]
operator: = [4440,4441]
===
match
---
name: Exception [19345,19354]
name: Exception [19374,19383]
===
match
---
operator: } [20927,20928]
operator: } [20956,20957]
===
match
---
simple_stmt [13806,13834]
simple_stmt [13835,13863]
===
match
---
string: """         Adds the DAG into the bag, recurses into sub dags.         Throws AirflowDagCycleException if a cycle is detected in this dag or its subdags         """ [15915,16079]
string: """         Adds the DAG into the bag, recurses into sub dags.         Throws AirflowDagCycleException if a cycle is detected in this dag or its subdags         """ [15944,16108]
===
match
---
trailer [10635,10652]
trailer [10664,10681]
===
match
---
expr_stmt [10553,10608]
expr_stmt [10582,10637]
===
match
---
name: found_dags [10618,10628]
name: found_dags [10647,10657]
===
match
---
dotted_name [6087,6105]
dotted_name [6087,6105]
===
match
---
name: get [7520,7523]
name: get [7549,7552]
===
match
---
suite [5671,5811]
suite [5671,5811]
===
match
---
trailer [17554,17589]
trailer [17583,17618]
===
match
---
return_stmt [22207,22216]
return_stmt [22236,22245]
===
match
---
trailer [4746,4777]
trailer [4746,4777]
===
match
---
if_stmt [12185,12472]
if_stmt [12214,12501]
===
match
---
suite [11658,12472]
suite [11687,12501]
===
match
---
name: self [13323,13327]
name: self [13352,13356]
===
match
---
simple_stmt [1531,1585]
simple_stmt [1531,1585]
===
match
---
name: self [16875,16879]
name: self [16904,16908]
===
match
---
trailer [14064,14074]
trailer [14093,14103]
===
match
---
trailer [6939,6973]
trailer [6939,6973]
===
match
---
name: logging [876,883]
name: logging [876,883]
===
match
---
name: conf [3104,3108]
name: conf [3104,3108]
===
match
---
argument [19474,19498]
argument [19503,19527]
===
match
---
simple_stmt [9307,9362]
simple_stmt [9336,9391]
===
match
---
expr_stmt [6881,6974]
expr_stmt [6881,6974]
===
match
---
name: dags [8692,8696]
name: dags [8721,8725]
===
match
---
simple_stmt [1315,1354]
simple_stmt [1315,1354]
===
match
---
atom [20184,20186]
atom [20213,20215]
===
match
---
trailer [10481,10505]
trailer [10510,10534]
===
match
---
trailer [10505,10526]
trailer [10534,10555]
===
match
---
name: exception [15595,15604]
name: exception [15624,15633]
===
match
---
name: subdags [16360,16367]
name: subdags [16389,16396]
===
match
---
name: session [7303,7310]
name: session [7303,7310]
===
match
---
try_stmt [18643,19431]
try_stmt [18672,19460]
===
match
---
trailer [8048,8056]
trailer [8077,8085]
===
match
---
simple_stmt [884,894]
simple_stmt [884,894]
===
match
---
atom_expr [4424,4439]
atom_expr [4424,4439]
===
match
---
name: loader [11692,11698]
name: loader [11721,11727]
===
match
---
trailer [7388,7406]
trailer [7417,7435]
===
match
---
name: filepath [12528,12536]
name: filepath [12557,12565]
===
match
---
trailer [16344,16350]
trailer [16373,16379]
===
match
---
name: filepath [13099,13107]
name: filepath [13128,13136]
===
match
---
atom_expr [7436,7489]
atom_expr [7465,7518]
===
match
---
arglist [10886,10905]
arglist [10915,10934]
===
match
---
trailer [22788,22812]
trailer [22817,22841]
===
match
---
name: getboolean [17402,17412]
name: getboolean [17431,17441]
===
match
---
name: log [13048,13051]
name: log [13077,13080]
===
match
---
parameters [3266,3667]
parameters [3266,3667]
===
match
---
atom_expr [20621,20652]
atom_expr [20650,20681]
===
match
---
expr_stmt [4070,4111]
expr_stmt [4070,4111]
===
match
---
argument [5022,5055]
argument [5022,5055]
===
match
---
name: exception [10377,10386]
name: exception [10406,10415]
===
match
---
name: Dict [1029,1033]
name: Dict [1029,1033]
===
match
---
string: "Failed to bag_dag: %s" [15292,15315]
string: "Failed to bag_dag: %s" [15321,15344]
===
match
---
operator: , [17589,17590]
operator: , [17618,17619]
===
match
---
name: logging_mixin [1699,1712]
name: logging_mixin [1699,1712]
===
match
---
name: models [8943,8949]
name: models [8972,8978]
===
match
---
try_stmt [14850,15842]
try_stmt [14879,15871]
===
match
---
trailer [6138,6156]
trailer [6138,6156]
===
match
---
param [5855,5862]
param [5855,5862]
===
match
---
atom [8616,8662]
atom [8645,8691]
===
match
---
trailer [23678,23680]
trailer [23707,23709]
===
match
---
name: self [19544,19548]
name: self [19573,19577]
===
match
---
param [9434,9439]
param [9463,9468]
===
match
---
name: read_dags_from_db [5603,5620]
name: read_dags_from_db [5603,5620]
===
match
---
and_test [8591,8662]
and_test [8620,8691]
===
match
---
fstring_string:          -------------------------------------------------------------------         Number of DAGs:  [20928,21029]
fstring_string:          -------------------------------------------------------------------         Number of DAGs:  [20957,21058]
===
match
---
simple_stmt [15701,15756]
simple_stmt [15730,15785]
===
match
---
trailer [13935,13969]
trailer [13964,13998]
===
match
---
name: normalized_schedule_interval [14996,15024]
name: normalized_schedule_interval [15025,15053]
===
match
---
operator: = [12327,12328]
operator: = [12356,12357]
===
match
---
dotted_name [6271,6300]
dotted_name [6271,6300]
===
match
---
trailer [8772,8780]
trailer [8801,8809]
===
match
---
trailer [4973,5154]
trailer [4973,5154]
===
match
---
simple_stmt [788,803]
simple_stmt [788,803]
===
match
---
name: timeout_msg [11492,11503]
name: timeout_msg [11521,11532]
===
match
---
atom_expr [18924,19307]
atom_expr [18953,19336]
===
match
---
name: last_loaded [8237,8248]
name: last_loaded [8266,8277]
===
match
---
name: DAG [14408,14411]
name: DAG [14437,14440]
===
match
---
suite [14025,14193]
suite [14054,14222]
===
match
---
trailer [9832,9842]
trailer [9861,9871]
===
match
---
name: format_exc [14087,14097]
name: format_exc [14116,14126]
===
match
---
operator: , [22134,22135]
operator: , [22163,22164]
===
match
---
name: timezone [7061,7069]
name: timezone [7061,7069]
===
match
---
name: loader [11966,11972]
name: loader [11995,12001]
===
match
---
name: seconds [6923,6930]
name: seconds [6923,6930]
===
match
---
decorated [5285,5621]
decorated [5285,5621]
===
match
---
trailer [14269,14272]
trailer [14298,14301]
===
match
---
tfpdef [3407,3433]
tfpdef [3407,3433]
===
match
---
operator: , [3537,3538]
operator: , [3537,3538]
===
match
---
simple_stmt [22270,22276]
simple_stmt [22299,22305]
===
match
---
name: file_last_changed [10152,10169]
name: file_last_changed [10181,10198]
===
match
---
name: subdags [16422,16429]
name: subdags [16451,16458]
===
match
---
trailer [13641,13649]
trailer [13670,13678]
===
match
---
except_clause [13846,13867]
except_clause [13875,13896]
===
match
---
atom_expr [8200,8220]
atom_expr [8229,8249]
===
match
---
name: include_smart_sensor [3407,3427]
name: include_smart_sensor [3407,3427]
===
match
---
argument [12322,12369]
argument [12351,12398]
===
match
---
atom_expr [16875,16934]
atom_expr [16904,16963]
===
match
---
or_test [9794,9842]
or_test [9823,9871]
===
match
---
trailer [12610,12620]
trailer [12639,12649]
===
match
---
name: self [3276,3280]
name: self [3276,3280]
===
match
---
name: dag_id [7407,7413]
name: dag_id [7436,7442]
===
match
---
atom_expr [23329,23385]
atom_expr [23358,23414]
===
match
---
trailer [10709,10727]
trailer [10738,10756]
===
match
---
expr_stmt [16360,16381]
expr_stmt [16389,16410]
===
match
---
and_test [14751,14793]
and_test [14780,14822]
===
match
---
operator: , [19009,19010]
operator: , [19038,19039]
===
match
---
atom_expr [20506,20521]
atom_expr [20535,20550]
===
match
---
string: 'smart_sensor' [17484,17498]
string: 'smart_sensor' [17513,17527]
===
match
---
name: self [13917,13921]
name: self [13946,13950]
===
match
---
trailer [19729,19734]
trailer [19758,19763]
===
match
---
argument [7473,7488]
argument [7502,7517]
===
match
---
not_test [9057,9064]
not_test [9086,9093]
===
match
---
argument [19240,19284]
argument [19269,19313]
===
match
---
name: dag_hash [9403,9411]
name: dag_hash [9432,9440]
===
match
---
name: _load_modules_from_zip [12499,12521]
name: _load_modules_from_zip [12528,12550]
===
match
---
testlist_comp [20546,20571]
testlist_comp [20575,20600]
===
match
---
trailer [10564,10587]
trailer [10593,10616]
===
match
---
name: stats [19467,19472]
name: stats [19496,19501]
===
match
---
arglist [9029,9044]
arglist [9058,9073]
===
match
---
trailer [20547,20556]
trailer [20576,20585]
===
match
---
annassign [1981,1986]
annassign [1981,1986]
===
match
---
operator: = [22163,22164]
operator: = [22192,22193]
===
match
---
trailer [13921,13925]
trailer [13950,13954]
===
match
---
atom_expr [4343,4362]
atom_expr [4343,4362]
===
match
---
trailer [15723,15737]
trailer [15752,15766]
===
match
---
atom_expr [19245,19284]
atom_expr [19274,19313]
===
match
---
trailer [14253,14263]
trailer [14282,14292]
===
match
---
atom_expr [22959,22967]
atom_expr [22988,22996]
===
match
---
name: file_parse_end_dttm [18834,18853]
name: file_parse_end_dttm [18863,18882]
===
match
---
testlist_comp [15535,15590]
testlist_comp [15564,15619]
===
match
---
name: include_examples [18530,18546]
name: include_examples [18559,18575]
===
match
---
name: self [10477,10481]
name: self [10506,10510]
===
match
---
trailer [11984,11996]
trailer [12013,12025]
===
match
---
name: os [9818,9820]
name: os [9847,9849]
===
match
---
operator: , [1142,1143]
operator: , [1142,1143]
===
match
---
operator: , [13510,13511]
operator: , [13539,13540]
===
match
---
simple_stmt [6509,6538]
simple_stmt [6509,6538]
===
match
---
string: ".py" [12820,12825]
string: ".py" [12849,12854]
===
match
---
name: self [4177,4181]
name: self [4177,4181]
===
match
---
name: file_last_changed [15450,15467]
name: file_last_changed [15479,15496]
===
match
---
name: __init__ [3258,3266]
name: __init__ [3258,3266]
===
match
---
operator: } [11405,11406]
operator: } [11434,11435]
===
match
---
simple_stmt [3753,3772]
simple_stmt [3753,3772]
===
match
---
parameters [14318,14367]
parameters [14347,14396]
===
match
---
simple_stmt [3080,3151]
simple_stmt [3080,3151]
===
match
---
arglist [20730,20751]
arglist [20759,20780]
===
match
---
trailer [8696,8704]
trailer [8725,8733]
===
match
---
parameters [21580,21594]
parameters [21609,21623]
===
match
---
name: self [5849,5853]
name: self [5849,5853]
===
match
---
name: self [7384,7388]
name: self [7413,7417]
===
match
---
simple_stmt [921,938]
simple_stmt [921,938]
===
match
---
trailer [8258,8271]
trailer [8287,8300]
===
match
---
name: modules [13642,13649]
name: modules [13671,13678]
===
match
---
name: airflow [21438,21445]
name: airflow [21467,21474]
===
match
---
trailer [10151,10169]
trailer [10180,10198]
===
match
---
name: error_message [11631,11644]
name: error_message [11660,11673]
===
match
---
name: str [12465,12468]
name: str [12494,12497]
===
match
---
name: log [12121,12124]
name: log [12150,12153]
===
match
---
atom_expr [14815,14826]
atom_expr [14844,14855]
===
match
---
simple_stmt [11692,11758]
simple_stmt [11721,11787]
===
match
---
for_stmt [20246,20325]
for_stmt [20275,20354]
===
match
---
name: duration [19490,19498]
name: duration [19519,19527]
===
match
---
simple_stmt [1464,1496]
simple_stmt [1464,1496]
===
match
---
name: modules [11918,11925]
name: modules [11947,11954]
===
match
---
name: dags_last_fetched [7389,7406]
name: dags_last_fetched [7418,7435]
===
match
---
trailer [3530,3565]
trailer [3530,3565]
===
match
---
name: subdags [20354,20361]
name: subdags [20383,20390]
===
match
---
operator: = [12694,12695]
operator: = [12723,12724]
===
match
---
atom_expr [16301,16310]
atom_expr [16330,16339]
===
match
---
name: update [23990,23996]
name: update [24019,24025]
===
match
---
name: headers [20737,20744]
name: headers [20766,20773]
===
match
---
param [3290,3323]
param [3290,3323]
===
match
---
name: dag_folder [20917,20927]
name: dag_folder [20946,20956]
===
match
---
trailer [12979,13029]
trailer [13008,13058]
===
match
---
name: dag [16713,16716]
name: dag [16742,16745]
===
match
---
name: airflow [1681,1688]
name: airflow [1681,1688]
===
match
---
trailer [23510,23515]
trailer [23539,23544]
===
match
---
trailer [13993,14024]
trailer [14022,14053]
===
match
---
name: write_dag [22015,22024]
name: write_dag [22044,22053]
===
match
---
for_stmt [12629,14273]
for_stmt [12658,14302]
===
match
---
param [5169,5173]
param [5169,5173]
===
match
---
name: mod_name [13593,13601]
name: mod_name [13622,13630]
===
match
---
atom [19249,19283]
atom [19278,19312]
===
match
---
name: safe_mode [10896,10905]
name: safe_mode [10925,10934]
===
match
---
name: dag_id [7794,7800]
name: dag_id [7823,7829]
===
match
---
except_clause [15527,15604]
except_clause [15556,15633]
===
match
---
fstring_string:           [21116,21125]
fstring_string:           [21145,21154]
===
match
---
name: is_subdag [7738,7747]
name: is_subdag [7767,7776]
===
match
---
if_stmt [18123,18169]
if_stmt [18152,18198]
===
match
---
name: dag [9168,9171]
name: dag [9197,9200]
===
match
---
name: current_zip_file [12576,12592]
name: current_zip_file [12605,12621]
===
match
---
simple_stmt [20493,20522]
simple_stmt [20522,20551]
===
match
---
argument [19113,19136]
argument [19142,19165]
===
match
---
suite [8015,8057]
suite [8044,8086]
===
match
---
funcdef [5299,5621]
funcdef [5299,5621]
===
match
---
trailer [8236,8248]
trailer [8265,8277]
===
match
---
name: dict [23997,24001]
name: dict [24026,24030]
===
match
---
comparison [14751,14774]
comparison [14780,14803]
===
match
---
trailer [19725,19729]
trailer [19754,19758]
===
match
---
operator: , [7471,7472]
operator: , [7500,7501]
===
match
---
expr_stmt [1942,1954]
expr_stmt [1942,1954]
===
match
---
name: session [6484,6491]
name: session [6484,6491]
===
match
---
expr_stmt [12576,12620]
expr_stmt [12605,12649]
===
match
---
arglist [19467,19512]
arglist [19496,19541]
===
match
---
name: dags [19240,19244]
name: dags [19269,19273]
===
match
---
operator: , [13018,13019]
operator: , [13047,13048]
===
match
---
operator: = [16561,16562]
operator: = [16590,16591]
===
match
---
operator: = [20670,20671]
operator: = [20699,20700]
===
match
---
trailer [19413,19417]
trailer [19442,19446]
===
match
---
simple_stmt [3819,4058]
simple_stmt [3819,4058]
===
match
---
simple_stmt [14377,14437]
simple_stmt [14406,14466]
===
match
---
name: getboolean [17544,17554]
name: getboolean [17573,17583]
===
match
---
name: dags [19936,19940]
name: dags [19965,19969]
===
match
---
name: file [18962,18966]
name: file [18991,18995]
===
match
---
name: dag_id [6343,6349]
name: dag_id [6343,6349]
===
match
---
operator: , [23293,23294]
operator: , [23322,23323]
===
match
---
name: OperationalError [23722,23738]
name: OperationalError [23751,23767]
===
match
---
name: DAGS_FOLDER [4157,4168]
name: DAGS_FOLDER [4157,4168]
===
match
---
operator: = [10738,10739]
operator: = [10767,10768]
===
match
---
trailer [6922,6974]
trailer [6922,6974]
===
match
---
operator: { [4599,4600]
operator: { [4599,4600]
===
match
---
name: dag [16470,16473]
name: dag [16499,16502]
===
match
---
name: conf [17468,17472]
name: conf [17497,17501]
===
match
---
if_stmt [9791,9866]
if_stmt [9820,9895]
===
match
---
arglist [11813,11829]
arglist [11842,11858]
===
match
---
param [3407,3488]
param [3407,3488]
===
match
---
trailer [5802,5807]
trailer [5802,5807]
===
match
---
name: Session [8872,8879]
name: Session [8901,8908]
===
match
---
atom_expr [8370,8488]
atom_expr [8399,8517]
===
match
---
name: self [12329,12333]
name: self [12358,12362]
===
match
---
name: self [10368,10372]
name: self [10397,10401]
===
match
---
arglist [10506,10525]
arglist [10535,10554]
===
match
---
name: file_last_changed [10710,10727]
name: file_last_changed [10739,10756]
===
match
---
operator: = [4778,4779]
operator: = [4778,4779]
===
match
---
name: ext [12808,12811]
name: ext [12837,12840]
===
match
---
name: CroniterNotAlphaError [15223,15244]
name: CroniterNotAlphaError [15252,15273]
===
match
---
trailer [18983,19009]
trailer [19012,19038]
===
match
---
simple_stmt [16088,16139]
simple_stmt [16117,16168]
===
match
---
trailer [19183,19189]
trailer [19212,19218]
===
match
---
name: getboolean [3520,3530]
name: getboolean [3520,3530]
===
match
---
dotted_name [1359,1377]
dotted_name [1359,1377]
===
match
---
trailer [6529,6537]
trailer [6529,6537]
===
match
---
name: utils [1746,1751]
name: utils [1746,1751]
===
match
---
name: os [10038,10040]
name: os [10067,10069]
===
match
---
tfpdef [3616,3653]
tfpdef [3616,3653]
===
match
---
name: filepath [14766,14774]
name: filepath [14795,14803]
===
match
---
name: dag [16148,16151]
name: dag [16177,16180]
===
match
---
name: attempt [23214,23221]
name: attempt [23243,23250]
===
match
---
trailer [23337,23343]
trailer [23366,23372]
===
match
---
name: timezone [18856,18864]
name: timezone [18885,18893]
===
match
---
trailer [9388,9395]
trailer [9417,9424]
===
match
---
name: models [3722,3728]
name: models [3722,3728]
===
match
---
name: store_serialized_dags [5303,5324]
name: store_serialized_dags [5303,5324]
===
match
---
trailer [10040,10045]
trailer [10069,10074]
===
match
---
name: orm [1236,1239]
name: orm [1236,1239]
===
match
---
import_as_names [1029,1061]
import_as_names [1029,1061]
===
match
---
expr_stmt [14871,14892]
expr_stmt [14900,14921]
===
match
---
operator: = [18686,18687]
operator: = [18715,18716]
===
match
---
atom_expr [6931,6973]
atom_expr [6931,6973]
===
match
---
operator: , [5853,5854]
operator: , [5853,5854]
===
match
---
name: dags_hash [9375,9384]
name: dags_hash [9404,9413]
===
match
---
simple_stmt [12852,12861]
simple_stmt [12881,12890]
===
match
---
name: self [11017,11021]
name: self [11046,11050]
===
match
---
fstring_string: \n         -------------------------------------------------------------------         DagBag loading stats for  [20804,20916]
fstring_string: \n         -------------------------------------------------------------------         DagBag loading stats for  [20833,20945]
===
match
---
name: attempt [22647,22654]
name: attempt [22676,22683]
===
match
---
name: models [6279,6285]
name: models [6279,6285]
===
match
---
return_stmt [5591,5620]
return_stmt [5591,5620]
===
match
---
trailer [8044,8048]
trailer [8073,8077]
===
match
---
param [17311,17316]
param [17340,17345]
===
match
---
atom_expr [7941,7991]
atom_expr [7970,8020]
===
match
---
argument [18763,18794]
argument [18792,18823]
===
match
---
atom_expr [16923,16933]
atom_expr [16952,16962]
===
match
---
name: e [13866,13867]
name: e [13895,13896]
===
match
---
simple_stmt [15133,15159]
simple_stmt [15162,15188]
===
match
---
name: session [7473,7480]
name: session [7502,7509]
===
match
---
atom_expr [10705,10737]
atom_expr [10734,10766]
===
match
---
name: info [11065,11069]
name: info [11094,11098]
===
match
---
atom_expr [16324,16350]
atom_expr [16353,16379]
===
match
---
or_test [4134,4168]
or_test [4134,4168]
===
match
---
name: exception [15282,15291]
name: exception [15311,15320]
===
match
---
trailer [11602,11657]
trailer [11631,11686]
===
match
---
atom_expr [18178,18236]
atom_expr [18207,18265]
===
match
---
atom_expr [11293,11343]
atom_expr [11322,11372]
===
match
---
atom_expr [12276,12391]
atom_expr [12305,12420]
===
match
---
argument [22071,22134]
argument [22100,22163]
===
match
---
operator: , [12536,12537]
operator: , [12565,12566]
===
match
---
atom_expr [23214,23248]
atom_expr [23243,23277]
===
match
---
operator: = [9172,9173]
operator: = [9201,9202]
===
match
---
name: utils [1544,1549]
name: utils [1544,1549]
===
match
---
import_name [820,846]
import_name [820,846]
===
match
---
name: session [1752,1759]
name: session [1752,1759]
===
match
---
fstring_end: " [11580,11581]
fstring_end: " [11609,11610]
===
match
---
trailer [11164,11168]
trailer [11193,11197]
===
match
---
name: log [10373,10376]
name: log [10402,10405]
===
match
---
operator: , [9438,9439]
operator: , [9467,9468]
===
match
---
name: root_dag [15064,15072]
name: root_dag [15093,15101]
===
match
---
name: dags [8737,8741]
name: dags [8766,8770]
===
match
---
name: debug [23111,23116]
name: debug [23140,23145]
===
match
---
trailer [15281,15291]
trailer [15310,15320]
===
match
---
suite [7682,7817]
suite [7711,7846]
===
match
---
operator: , [23192,23193]
operator: , [23221,23222]
===
match
---
name: table [21126,21131]
name: table [21155,21160]
===
match
---
trailer [11869,11874]
trailer [11898,11903]
===
match
---
operator: , [23009,23010]
operator: , [23038,23039]
===
match
---
expr_stmt [1918,1937]
expr_stmt [1918,1937]
===
match
---
name: dag_id [6530,6536]
name: dag_id [6530,6536]
===
match
---
string: 'Loaded DAG %s' [16696,16711]
string: 'Loaded DAG %s' [16725,16740]
===
match
---
simple_stmt [4214,4245]
simple_stmt [4214,4245]
===
match
---
operator: , [3660,3661]
operator: , [3660,3661]
===
match
---
name: airflow [1501,1508]
name: airflow [1501,1508]
===
match
---
argument [6923,6973]
argument [6923,6973]
===
match
---
atom_expr [16447,16467]
atom_expr [16476,16496]
===
match
---
name: stats [1477,1482]
name: stats [1477,1482]
===
match
---
name: dag [16370,16373]
name: dag [16399,16402]
===
match
---
atom [18359,18361]
atom [18388,18390]
===
match
---
dotted_name [3714,3732]
dotted_name [3714,3732]
===
match
---
name: str [14957,14960]
name: str [14986,14989]
===
match
---
name: task_num [1959,1967]
name: task_num [1959,1967]
===
match
---
argument [5559,5571]
argument [5559,5571]
===
match
---
operator: = [6911,6912]
operator: = [6911,6912]
===
match
---
name: stop_after_attempt [22863,22881]
name: stop_after_attempt [22892,22910]
===
match
---
atom_expr [20301,20314]
atom_expr [20330,20343]
===
match
---
trailer [7519,7523]
trailer [7548,7552]
===
match
---
expr_stmt [11281,11343]
expr_stmt [11310,11372]
===
match
---
name: row [9399,9402]
name: row [9428,9431]
===
match
---
trailer [3827,3832]
trailer [3827,3832]
===
match
---
name: safe_mode [5134,5143]
name: safe_mode [5134,5143]
===
match
---
import_as_names [1616,1675]
import_as_names [1616,1675]
===
match
---
operator: , [10596,10597]
operator: , [10625,10626]
===
match
---
parameters [19543,19549]
parameters [19572,19578]
===
match
---
trailer [16211,16218]
trailer [16240,16247]
===
match
---
name: len [19121,19124]
name: len [19150,19153]
===
match
---
name: NamedTuple [1846,1856]
name: NamedTuple [1846,1856]
===
match
---
name: update [20347,20353]
name: update [20376,20382]
===
match
---
operator: = [17467,17468]
operator: = [17496,17497]
===
match
---
name: o [14514,14515]
name: o [14543,14544]
===
match
---
expr_stmt [4319,4367]
expr_stmt [4319,4367]
===
match
---
simple_stmt [1942,1955]
simple_stmt [1942,1955]
===
match
---
trailer [4323,4341]
trailer [4323,4341]
===
match
---
trailer [20583,20585]
trailer [20612,20614]
===
match
---
atom_expr [14544,14563]
atom_expr [14573,14592]
===
match
---
name: serialize_errors [23064,23080]
name: serialize_errors [23093,23109]
===
match
---
expr_stmt [16544,16567]
expr_stmt [16573,16596]
===
match
---
name: dags [20215,20219]
name: dags [20244,20248]
===
match
---
name: settings [18984,18992]
name: settings [19013,19021]
===
match
---
name: split [11252,11257]
name: split [11281,11286]
===
match
---
fstring_expr [15419,15427]
fstring_expr [15448,15456]
===
match
---
simple_stmt [16324,16351]
simple_stmt [16353,16380]
===
match
---
not_test [9814,9842]
not_test [9843,9871]
===
match
---
simple_stmt [11141,11151]
simple_stmt [11170,11180]
===
match
---
trailer [11251,11257]
trailer [11280,11286]
===
match
---
operator: @ [5626,5627]
operator: @ [5626,5627]
===
match
---
arglist [13450,13529]
arglist [13479,13558]
===
match
---
operator: = [12755,12756]
operator: = [12784,12785]
===
match
---
name: dag [16099,16102]
name: dag [16128,16131]
===
match
---
decorator [5816,5833]
decorator [5816,5833]
===
match
---
fstring_string: DagBag import timeout for  [11508,11534]
fstring_string: DagBag import timeout for  [11537,11563]
===
match
---
name: self [21218,21222]
name: self [21247,21251]
===
match
---
trailer [12759,12764]
trailer [12788,12793]
===
match
---
atom_expr [12188,12223]
atom_expr [12217,12252]
===
match
---
trailer [23996,24020]
trailer [24025,24049]
===
match
---
name: datetime [990,998]
name: datetime [990,998]
===
match
---
operator: , [22761,22762]
operator: , [22790,22791]
===
match
---
expr_stmt [9307,9361]
expr_stmt [9336,9390]
===
match
---
operator: , [15315,15316]
operator: , [15344,15345]
===
match
---
name: Exception [12052,12061]
name: Exception [12081,12090]
===
match
---
funcdef [8823,9412]
funcdef [8852,9441]
===
match
---
name: dag_id [17172,17178]
name: dag_id [17201,17207]
===
match
---
name: dags_last_fetched [7086,7103]
name: dags_last_fetched [7086,7103]
===
match
---
trailer [15104,15111]
trailer [15133,15140]
===
match
---
atom_expr [14703,14720]
atom_expr [14732,14749]
===
match
---
operator: , [22835,22836]
operator: , [22864,22865]
===
match
---
trailer [7220,7246]
trailer [7220,7246]
===
match
---
subscriptlist [4401,4409]
subscriptlist [4401,4409]
===
match
---
name: dags [8768,8772]
name: dags [8797,8801]
===
match
---
name: sd_last_updated_datetime [7357,7381]
name: sd_last_updated_datetime [7386,7410]
===
match
---
name: dags [5798,5802]
name: dags [5798,5802]
===
match
---
name: dag [15720,15723]
name: dag [15749,15752]
===
match
---
operator: = [7615,7616]
operator: = [7644,7645]
===
match
---
name: serialized_dag [8950,8964]
name: serialized_dag [8979,8993]
===
match
---
trailer [19935,19940]
trailer [19964,19969]
===
match
---
name: read_dags_from_db [18131,18148]
name: read_dags_from_db [18160,18177]
===
match
---
trailer [6525,6529]
trailer [6525,6529]
===
match
---
trailer [4218,4223]
trailer [4218,4223]
===
match
---
name: zipfile [14459,14466]
name: zipfile [14488,14495]
===
match
---
trailer [23767,23776]
trailer [23796,23805]
===
match
---
name: filepath [10728,10736]
name: filepath [10757,10765]
===
match
---
trailer [17237,17244]
trailer [17266,17273]
===
match
---
return_stmt [21860,21869]
return_stmt [21889,21898]
===
match
---
trailer [17472,17483]
trailer [17501,17512]
===
match
---
name: airflow [3714,3721]
name: airflow [3714,3721]
===
match
---
expr_stmt [8137,8178]
expr_stmt [8166,8207]
===
match
---
name: List [5661,5665]
name: List [5661,5665]
===
match
---
operator: = [16663,16664]
operator: = [16692,16693]
===
match
---
name: found_dags [19272,19282]
name: found_dags [19301,19311]
===
match
---
atom [4730,4732]
atom [4730,4732]
===
match
---
string: 'core' [3118,3124]
string: 'core' [3118,3124]
===
match
---
comparison [7662,7681]
comparison [7691,7710]
===
match
---
name: include_examples [18547,18563]
name: include_examples [18576,18592]
===
match
---
atom_expr [9307,9341]
atom_expr [9336,9370]
===
match
---
name: dag_policy [16264,16274]
name: dag_policy [16293,16303]
===
match
---
name: safe_mode [12538,12547]
name: safe_mode [12567,12576]
===
match
---
name: orm_dag [8251,8258]
name: orm_dag [8280,8287]
===
match
---
name: dag_folder [4195,4205]
name: dag_folder [4195,4205]
===
match
---
name: MIN_SERIALIZED_DAG_FETCH_INTERVAL [6940,6973]
name: MIN_SERIALIZED_DAG_FETCH_INTERVAL [6940,6973]
===
match
---
operator: + [7112,7113]
operator: + [7112,7113]
===
match
---
trailer [7246,7337]
trailer [7246,7337]
===
match
---
operator: = [4132,4133]
operator: = [4132,4133]
===
match
---
name: serialized_dag [19622,19636]
name: serialized_dag [19651,19665]
===
match
---
name: models [21489,21495]
name: models [21518,21524]
===
match
---
expr_stmt [18664,18705]
expr_stmt [18693,18734]
===
match
---
name: self [15042,15046]
name: self [15071,15075]
===
match
---
trailer [14578,14586]
trailer [14607,14615]
===
match
---
name: task [16293,16297]
name: task [16322,16326]
===
match
---
argument [23682,23697]
argument [23711,23726]
===
match
---
operator: , [18794,18795]
operator: , [18823,18824]
===
match
---
expr_stmt [12558,12567]
expr_stmt [12587,12596]
===
match
---
operator: = [19170,19171]
operator: = [19199,19200]
===
match
---
atom_expr [19250,19260]
atom_expr [19279,19289]
===
match
---
atom_expr [13605,13616]
atom_expr [13634,13645]
===
match
---
simple_stmt [16875,16935]
simple_stmt [16904,16964]
===
match
---
name: croniter [1167,1175]
name: croniter [1167,1175]
===
match
---
expr_stmt [15701,15755]
expr_stmt [15730,15784]
===
match
---
argument [22156,22171]
argument [22185,22200]
===
match
---
operator: = [4363,4364]
operator: = [4363,4364]
===
match
---
operator: , [14323,14324]
operator: , [14352,14353]
===
match
---
argument [22849,22906]
argument [22878,22935]
===
match
---
name: duration [21107,21115]
name: duration [21136,21144]
===
match
---
try_stmt [21882,22448]
try_stmt [21911,22477]
===
match
---
name: dag [19265,19268]
name: dag [19294,19297]
===
match
---
atom_expr [19721,19773]
atom_expr [19750,19802]
===
match
---
trailer [15719,15738]
trailer [15748,15767]
===
match
---
name: DAGBAG_IMPORT_TIMEOUT [11608,11629]
name: DAGBAG_IMPORT_TIMEOUT [11637,11658]
===
match
---
trailer [12124,12134]
trailer [12153,12163]
===
match
---
argument [18497,18516]
argument [18526,18545]
===
match
---
expr_stmt [10705,10765]
expr_stmt [10734,10794]
===
match
---
simple_stmt [13917,13970]
simple_stmt [13946,13999]
===
match
---
name: dag_id [5855,5861]
name: dag_id [5855,5861]
===
match
---
simple_stmt [9370,9412]
simple_stmt [9399,9441]
===
match
---
name: dagbag_import_error_traceback_depth [22409,22444]
name: dagbag_import_error_traceback_depth [22438,22473]
===
match
---
atom_expr [19176,19190]
atom_expr [19205,19219]
===
match
---
trailer [3769,3771]
trailer [3769,3771]
===
match
---
name: dag [15147,15150]
name: dag [15176,15179]
===
match
---
try_stmt [23402,23805]
try_stmt [23431,23834]
===
match
---
argument [18962,19009]
argument [18991,19038]
===
match
---
trailer [13810,13817]
trailer [13839,13846]
===
match
---
atom_expr [11595,11657]
atom_expr [11624,11686]
===
match
---
name: spec_from_loader [11796,11812]
name: spec_from_loader [11825,11841]
===
match
---
del_stmt [17217,17245]
del_stmt [17246,17274]
===
match
---
argument [22728,22760]
argument [22757,22789]
===
match
---
suite [10540,10609]
suite [10569,10638]
===
match
---
arglist [10653,10694]
arglist [10682,10723]
===
match
---
simple_stmt [16360,16382]
simple_stmt [16389,16411]
===
match
---
name: self [8169,8173]
name: self [8198,8202]
===
match
---
atom_expr [15352,15389]
atom_expr [15381,15418]
===
match
---
name: utils [1689,1694]
name: utils [1689,1694]
===
match
---
simple_stmt [1354,1464]
simple_stmt [1354,1464]
===
match
---
except_clause [10301,10322]
except_clause [10330,10351]
===
match
---
number: 5 [22833,22834]
number: 5 [22862,22863]
===
match
---
atom_expr [18126,18148]
atom_expr [18155,18177]
===
match
---
trailer [16893,16934]
trailer [16922,16963]
===
match
---
atom [14513,14587]
atom [14542,14616]
===
match
---
param [15891,15895]
param [15920,15924]
===
match
---
fstring_string:          Total task number:  [21038,21066]
fstring_string:          Total task number:  [21067,21095]
===
match
---
operator: } [11543,11544]
operator: } [11572,11573]
===
match
---
simple_stmt [15352,15429]
simple_stmt [15381,15458]
===
match
---
name: tabulate [20721,20729]
name: tabulate [20750,20758]
===
match
---
name: airflow [1536,1543]
name: airflow [1536,1543]
===
match
---
import_from [1176,1219]
import_from [1176,1219]
===
match
---
atom_expr [13917,13969]
atom_expr [13946,13998]
===
match
---
atom_expr [17397,17437]
atom_expr [17426,17466]
===
match
---
name: dag_id [17238,17244]
name: dag_id [17267,17273]
===
match
---
operator: , [12157,12158]
operator: , [12186,12187]
===
match
---
comparison [13593,13616]
comparison [13622,13645]
===
match
---
atom_expr [22658,23020]
atom_expr [22687,23049]
===
match
---
sync_comp_for [20636,20650]
sync_comp_for [20665,20679]
===
match
---
param [3276,3281]
param [3276,3281]
===
match
---
expr_stmt [7931,7991]
expr_stmt [7960,8020]
===
match
---
or_test [18258,18287]
or_test [18287,18316]
===
match
---
name: extend [23567,23573]
name: extend [23596,23602]
===
match
---
trailer [20471,20484]
trailer [20500,20513]
===
match
---
param [5849,5854]
param [5849,5854]
===
match
---
name: traceback [22376,22385]
name: traceback [22405,22414]
===
match
---
atom_expr [8251,8271]
atom_expr [8280,8300]
===
match
---
arglist [17484,17518]
arglist [17513,17547]
===
match
---
name: sys [13605,13608]
name: sys [13634,13637]
===
match
---
simple_stmt [3709,3744]
simple_stmt [3709,3744]
===
match
---
name: dag [15059,15062]
name: dag [15088,15091]
===
match
---
name: dags [6362,6366]
name: dags [6362,6366]
===
match
---
string: "You should pass the read_dags_from_db parameter." [3926,3976]
string: "You should pass the read_dags_from_db parameter." [3926,3976]
===
match
---
suite [23406,23699]
suite [23435,23728]
===
match
---
name: provide_session [21183,21198]
name: provide_session [21212,21227]
===
match
---
name: name [11931,11935]
name: name [11960,11964]
===
match
---
name: self [6357,6361]
name: self [6357,6361]
===
match
---
sync_comp_for [14516,14586]
sync_comp_for [14545,14615]
===
match
---
name: read_dags_from_db [6139,6156]
name: read_dags_from_db [6139,6156]
===
match
---
import_name [938,953]
import_name [938,953]
===
match
---
arglist [3531,3564]
arglist [3531,3564]
===
match
---
not_test [8003,8014]
not_test [8032,8043]
===
match
---
name: path_hash [11381,11390]
name: path_hash [11410,11419]
===
match
---
operator: - [12328,12329]
operator: - [12357,12358]
===
match
---
fstring_start: f" [11506,11508]
fstring_start: f" [11535,11537]
===
match
---
trailer [4181,4192]
trailer [4181,4192]
===
match
---
simple_stmt [15915,16080]
simple_stmt [15944,16109]
===
match
---
simple_stmt [8028,8057]
simple_stmt [8057,8086]
===
match
---
atom_expr [23760,23778]
atom_expr [23789,23807]
===
match
---
name: min_update_interval [22071,22090]
name: min_update_interval [22100,22119]
===
match
---
tfpdef [3332,3354]
tfpdef [3332,3354]
===
match
---
number: 2 [4041,4042]
number: 2 [4041,4042]
===
match
---
operator: } [11390,11391]
operator: } [11419,11420]
===
match
---
annassign [4341,4367]
annassign [4341,4367]
===
match
---
suite [19708,20363]
suite [19737,20392]
===
match
---
name: filename [12719,12727]
name: filename [12748,12756]
===
match
---
return_stmt [12013,12032]
return_stmt [12042,12061]
===
match
---
operator: = [22779,22780]
operator: = [22808,22809]
===
match
---
trailer [7076,7078]
trailer [7076,7078]
===
match
---
name: dag_id [16927,16933]
name: dag_id [16956,16962]
===
match
---
atom_expr [8035,8056]
atom_expr [8064,8085]
===
match
---
name: full_filepath [14672,14685]
name: full_filepath [14701,14714]
===
match
---
name: serialized_dag [6286,6300]
name: serialized_dag [6286,6300]
===
match
---
arith_expr [19044,19087]
arith_expr [19073,19116]
===
match
---
atom_expr [14235,14263]
atom_expr [14264,14292]
===
match
---
trailer [15277,15281]
trailer [15306,15310]
===
match
---
atom_expr [11461,11482]
atom_expr [11490,11511]
===
match
---
operator: , [11117,11118]
operator: , [11146,11147]
===
match
---
name: limit [12322,12327]
name: limit [12351,12356]
===
match
---
operator: , [19087,19088]
operator: , [19116,19117]
===
match
---
name: dag_id [7465,7471]
name: dag_id [7494,7500]
===
match
---
simple_stmt [1220,1255]
simple_stmt [1220,1255]
===
match
---
name: dags [7706,7710]
name: dags [7735,7739]
===
match
---
simple_stmt [17606,18115]
simple_stmt [17635,18144]
===
match
---
arglist [13147,13193]
arglist [13176,13222]
===
match
---
suite [7158,7490]
suite [7158,7519]
===
match
---
not_test [13319,13338]
not_test [13348,13367]
===
match
---
simple_stmt [1010,1062]
simple_stmt [1010,1062]
===
match
---
name: zip_info [12710,12718]
name: zip_info [12739,12747]
===
match
---
operator: = [22932,22933]
operator: = [22961,22962]
===
match
---
atom_expr [7081,7111]
atom_expr [7081,7111]
===
match
---
simple_stmt [1863,1899]
simple_stmt [1863,1899]
===
match
---
operator: = [14721,14722]
operator: = [14750,14751]
===
match
---
name: found_dags [14597,14607]
name: found_dags [14626,14636]
===
match
---
expr_stmt [20713,20752]
expr_stmt [20742,20781]
===
match
---
name: file_last_changed_on_disk [9987,10012]
name: file_last_changed_on_disk [10016,10041]
===
match
---
operator: = [3513,3514]
operator: = [3513,3514]
===
match
---
arglist [17555,17588]
arglist [17584,17617]
===
match
---
expr_stmt [14496,14587]
expr_stmt [14525,14616]
===
match
---
trailer [15794,15813]
trailer [15823,15842]
===
match
---
operator: { [21125,21126]
operator: { [21154,21155]
===
match
---
name: Session [1247,1254]
name: Session [1247,1254]
===
match
---
name: include_examples [3332,3348]
name: include_examples [3332,3348]
===
match
---
trailer [20341,20346]
trailer [20370,20375]
===
match
---
name: dag_folder [18371,18381]
name: dag_folder [18400,18410]
===
match
---
name: mod_name [11352,11360]
name: mod_name [11381,11389]
===
match
---
operator: = [22823,22824]
operator: = [22852,22853]
===
match
---
operator: , [14580,14581]
operator: , [14609,14610]
===
match
---
arglist [11175,11199]
arglist [11204,11228]
===
match
---
name: import_module [13766,13779]
name: import_module [13795,13808]
===
match
---
expr_stmt [9000,9045]
expr_stmt [9029,9074]
===
match
---
name: self [13043,13047]
name: self [13072,13076]
===
match
---
name: dag [21829,21832]
name: dag [21858,21861]
===
match
---
atom_expr [4577,4596]
atom_expr [4577,4596]
===
match
---
trailer [5792,5810]
trailer [5792,5810]
===
match
---
trailer [19174,19214]
trailer [19203,19243]
===
match
---
name: dag [9281,9284]
name: dag [9310,9313]
===
match
---
operator: = [11937,11938]
operator: = [11966,11967]
===
match
---
name: dag_id [7524,7530]
name: dag_id [7553,7559]
===
match
---
name: log [11165,11168]
name: log [11194,11197]
===
match
---
argument [16597,16607]
argument [16626,16636]
===
match
---
name: str [1910,1913]
name: str [1910,1913]
===
match
---
arglist [20545,20585]
arglist [20574,20614]
===
match
---
expr_stmt [4214,4244]
expr_stmt [4214,4244]
===
match
---
simple_stmt [1918,1938]
simple_stmt [1918,1938]
===
match
---
simple_stmt [13368,13391]
simple_stmt [13397,13420]
===
match
---
simple_stmt [13739,13790]
simple_stmt [13768,13819]
===
match
---
operator: > [7382,7383]
operator: > [7411,7412]
===
match
---
name: machinery [837,846]
name: machinery [837,846]
===
match
---
atom_expr [18984,19004]
atom_expr [19013,19033]
===
match
---
name: DeprecationWarning [5527,5545]
name: DeprecationWarning [5527,5545]
===
match
---
trailer [15798,15812]
trailer [15827,15841]
===
match
---
atom [21867,21869]
atom [21896,21898]
===
match
---
atom_expr [10868,10906]
atom_expr [10897,10935]
===
match
---
name: MAX_DB_RETRIES [22891,22905]
name: MAX_DB_RETRIES [22920,22934]
===
match
---
atom_expr [3753,3771]
atom_expr [3753,3771]
===
match
---
parameters [10824,10851]
parameters [10853,10880]
===
match
---
name: self [13989,13993]
name: self [14018,14022]
===
match
---
arglist [11603,11656]
arglist [11632,11685]
===
match
---
operator: = [9397,9398]
operator: = [9426,9427]
===
match
---
simple_stmt [4424,4448]
simple_stmt [4424,4448]
===
match
---
testlist_comp [14514,14586]
testlist_comp [14543,14615]
===
match
---
suite [9488,10792]
suite [9517,10821]
===
match
---
trailer [9333,9340]
trailer [9362,9369]
===
match
---
atom_expr [12645,12672]
atom_expr [12674,12701]
===
match
---
name: retry_if_exception_type [22704,22727]
name: retry_if_exception_type [22733,22756]
===
match
---
fstring [11506,11581]
fstring [11535,11610]
===
match
---
atom_expr [19460,19513]
atom_expr [19489,19542]
===
match
---
simple_stmt [16584,16628]
simple_stmt [16613,16657]
===
match
---
atom_expr [22376,22445]
atom_expr [22405,22474]
===
match
---
trailer [12120,12124]
trailer [12149,12153]
===
match
---
name: property [5627,5635]
name: property [5627,5635]
===
match
---
name: dag [14871,14874]
name: dag [14900,14903]
===
match
---
name: Optional [21233,21241]
name: Optional [21262,21270]
===
match
---
trailer [13372,13383]
trailer [13401,13412]
===
match
---
argument [18577,18618]
argument [18606,18647]
===
match
---
subscriptlist [4718,4726]
subscriptlist [4718,4726]
===
match
---
name: file_parse_start_dttm [19066,19087]
name: file_parse_start_dttm [19095,19116]
===
match
---
operator: } [21131,21132]
operator: } [21160,21161]
===
match
---
name: Stats [19677,19682]
name: Stats [19706,19711]
===
match
---
name: ext [12751,12754]
name: ext [12780,12783]
===
match
---
trailer [14706,14720]
trailer [14735,14749]
===
match
---
import_from [1079,1175]
import_from [1079,1175]
===
match
---
arglist [10588,10607]
arglist [10617,10636]
===
match
---
trailer [11021,11032]
trailer [11050,11061]
===
match
---
parameters [5848,5887]
parameters [5848,5887]
===
match
---
name: settings [6931,6939]
name: settings [6931,6939]
===
match
---
name: full_filepath [15321,15334]
name: full_filepath [15350,15363]
===
match
---
and_test [10099,10251]
and_test [10128,10280]
===
match
---
name: collect_dags [4961,4973]
name: collect_dags [4961,4973]
===
match
---
name: collect_dags [17289,17301]
name: collect_dags [17318,17330]
===
match
---
trailer [15449,15467]
trailer [15478,15496]
===
match
---
name: size [5164,5168]
name: size [5164,5168]
===
match
---
suite [23739,23805]
suite [23768,23834]
===
match
---
name: self [8687,8691]
name: self [8716,8720]
===
match
---
operator: = [12593,12594]
operator: = [12622,12623]
===
match
---
simple_stmt [19559,19594]
simple_stmt [19588,19623]
===
match
---
arglist [11738,11756]
arglist [11767,11785]
===
match
---
name: self [14235,14239]
name: self [14264,14268]
===
match
---
simple_stmt [19931,19978]
simple_stmt [19960,20007]
===
match
---
trailer [23566,23573]
trailer [23595,23602]
===
match
---
name: include_examples [17380,17396]
name: include_examples [17409,17425]
===
match
---
trailer [18864,18871]
trailer [18893,18900]
===
match
---
string: 'DAG_DISCOVERY_SAFE_MODE' [17563,17588]
string: 'DAG_DISCOVERY_SAFE_MODE' [17592,17617]
===
match
---
tfpdef [3290,3315]
tfpdef [3290,3315]
===
match
---
name: dedent [20780,20786]
name: dedent [20809,20815]
===
match
---
trailer [23233,23248]
trailer [23262,23277]
===
match
---
atom_expr [11914,11936]
atom_expr [11943,11965]
===
match
---
suite [10907,11151]
suite [10936,11180]
===
match
---
operator: , [10894,10895]
operator: , [10923,10924]
===
match
---
name: datetime [974,982]
name: datetime [974,982]
===
match
---
argument [22689,22761]
argument [22718,22790]
===
match
---
atom_expr [3104,3150]
atom_expr [3104,3150]
===
match
---
trailer [6460,6492]
trailer [6460,6492]
===
match
---
operator: = [16522,16523]
operator: = [16551,16552]
===
match
---
name: info [19730,19734]
name: info [19759,19763]
===
match
---
name: stats [20697,20702]
name: stats [20726,20731]
===
match
---
atom_expr [14912,14961]
atom_expr [14941,14990]
===
match
---
name: last_expired [8259,8271]
name: last_expired [8288,8300]
===
match
---
trailer [9329,9341]
trailer [9358,9370]
===
match
---
trailer [11243,11272]
trailer [11272,11301]
===
match
---
trailer [19975,19977]
trailer [20004,20006]
===
match
---
simple_stmt [19440,19514]
simple_stmt [19469,19543]
===
match
---
operator: { [4413,4414]
operator: { [4413,4414]
===
match
---
name: exception [15745,15754]
name: exception [15774,15783]
===
match
---
fstring_string:  after  [11544,11551]
fstring_string:  after  [11573,11580]
===
match
---
expr_stmt [3080,3150]
expr_stmt [3080,3150]
===
match
---
name: found_dags [18722,18732]
name: found_dags [18751,18761]
===
match
---
name: dagbag_stats [20472,20484]
name: dagbag_stats [20501,20513]
===
match
---
atom [12487,12489]
atom [12516,12518]
===
match
---
simple_stmt [20530,20603]
simple_stmt [20559,20632]
===
match
---
argument [20737,20751]
argument [20766,20780]
===
match
---
name: isfile [9826,9832]
name: isfile [9855,9861]
===
match
---
name: dags [9276,9280]
name: dags [9305,9309]
===
match
---
name: spec [11926,11930]
name: spec [11955,11959]
===
match
---
dotted_name [14382,14400]
dotted_name [14411,14429]
===
match
---
string: """Collects DAGs from database.""" [19559,19593]
string: """Collects DAGs from database.""" [19588,19622]
===
match
---
string: """             Try to serialize the dag to the DB, but make a note of any errors.              We can't place them directly in import_errors, as this may be retried, and work the next time             """ [21608,21813]
string: """             Try to serialize the dag to the DB, but make a note of any errors.              We can't place them directly in import_errors, as this may be retried, and work the next time             """ [21637,21842]
===
match
---
operator: = [16201,16202]
operator: = [16230,16231]
===
match
---
try_stmt [13673,14273]
try_stmt [13702,14302]
===
match
---
operator: , [8861,8862]
operator: , [8890,8891]
===
match
---
name: str [8858,8861]
name: str [8887,8890]
===
match
---
simple_stmt [22207,22217]
simple_stmt [22236,22246]
===
match
---
atom_expr [16370,16381]
atom_expr [16399,16410]
===
match
---
name: dag [9295,9298]
name: dag [9324,9327]
===
match
---
name: dag [15073,15076]
name: dag [15102,15105]
===
match
---
operator: , [5110,5111]
operator: , [5110,5111]
===
match
---
name: machinery [11711,11720]
name: machinery [11740,11749]
===
match
---
name: dag_id [8850,8856]
name: dag_id [8879,8885]
===
match
---
operator: } [21115,21116]
operator: } [21144,21145]
===
match
---
name: log [23334,23337]
name: log [23363,23366]
===
match
---
trailer [9825,9832]
trailer [9854,9861]
===
match
---
parameters [5651,5657]
parameters [5651,5657]
===
match
---
operator: { [11534,11535]
operator: { [11563,11564]
===
match
---
operator: = [22832,22833]
operator: = [22861,22862]
===
match
---
trailer [10376,10386]
trailer [10405,10415]
===
match
---
atom_expr [9204,9215]
atom_expr [9233,9244]
===
match
---
atom_expr [7018,7040]
atom_expr [7018,7040]
===
match
---
operator: > [7079,7080]
operator: > [7079,7080]
===
match
---
trailer [13047,13051]
trailer [13076,13080]
===
match
---
name: retry_state [23222,23233]
name: retry_state [23251,23262]
===
match
---
operator: = [18733,18734]
operator: = [18762,18763]
===
match
---
dotted_name [21438,21456]
dotted_name [21467,21485]
===
match
---
operator: - [22403,22404]
operator: - [22432,22433]
===
match
---
name: session [23690,23697]
name: session [23719,23726]
===
match
---
name: dag [22046,22049]
name: dag [22075,22078]
===
match
---
simple_stmt [23102,23313]
simple_stmt [23131,23342]
===
match
---
name: include_smart_sensor [18598,18618]
name: include_smart_sensor [18627,18647]
===
match
---
simple_stmt [13694,13723]
simple_stmt [13723,13752]
===
match
---
operator: = [20465,20466]
operator: = [20494,20495]
===
match
---
name: dag [7695,7698]
name: dag [7724,7727]
===
match
---
trailer [23776,23778]
trailer [23805,23807]
===
match
---
name: dagbag_import_error_traceback_depth [12334,12369]
name: dagbag_import_error_traceback_depth [12363,12398]
===
match
---
trailer [11064,11069]
trailer [11093,11098]
===
match
---
simple_stmt [18178,18237]
simple_stmt [18207,18266]
===
match
---
trailer [23661,23698]
trailer [23690,23727]
===
match
---
atom_expr [11926,11935]
atom_expr [11955,11964]
===
match
---
name: sum [20621,20624]
name: sum [20650,20653]
===
match
---
trailer [22366,22374]
trailer [22395,22403]
===
match
---
arglist [11070,11127]
arglist [11099,11156]
===
match
---
name: filepath [11306,11314]
name: filepath [11335,11343]
===
match
---
name: dag [19250,19253]
name: dag [19279,19282]
===
match
---
if_stmt [14661,14838]
if_stmt [14690,14867]
===
match
---
name: LoggingMixin [1720,1732]
name: LoggingMixin [1720,1732]
===
match
---
name: modules [11436,11443]
name: modules [11465,11472]
===
match
---
expr_stmt [15445,15514]
expr_stmt [15474,15543]
===
match
---
name: DAG [14582,14585]
name: DAG [14611,14614]
===
match
---
name: self [4456,4460]
name: self [4456,4460]
===
match
---
simple_stmt [23799,23805]
simple_stmt [23828,23834]
===
match
---
argument [19162,19214]
argument [19191,19243]
===
match
---
trailer [7022,7040]
trailer [7022,7040]
===
match
---
name: subdags [20174,20181]
name: subdags [20203,20210]
===
match
---
trailer [4960,4973]
trailer [4960,4973]
===
match
---
operator: , [13175,13176]
operator: , [13204,13205]
===
match
---
trailer [10223,10241]
trailer [10252,10270]
===
match
---
name: subdags [9208,9215]
name: subdags [9237,9244]
===
match
---
name: log [13922,13925]
name: log [13951,13954]
===
match
---
expr_stmt [4121,4168]
expr_stmt [4121,4168]
===
match
---
name: stats [20566,20571]
name: stats [20595,20600]
===
match
---
name: dag_num [20628,20635]
name: dag_num [20657,20664]
===
match
---
name: self [12245,12249]
name: self [12274,12278]
===
match
---
name: task_num [19162,19170]
name: task_num [19191,19199]
===
match
---
string: """         Gets the DAG out of the dictionary, and refreshes it if expired          :param dag_id: DAG Id         :type dag_id: str         """ [5897,6041]
string: """         Gets the DAG out of the dictionary, and refreshes it if expired          :param dag_id: DAG Id         :type dag_id: str         """ [5897,6041]
===
match
---
simple_stmt [7765,7817]
simple_stmt [7794,7846]
===
match
---
operator: = [3316,3317]
operator: = [3316,3317]
===
match
---
trailer [11556,11578]
trailer [11585,11607]
===
match
---
arglist [22959,22982]
arglist [22988,23011]
===
match
---
simple_stmt [1783,1825]
simple_stmt [1783,1825]
===
match
---
name: bulk_write_to_db [23645,23661]
name: bulk_write_to_db [23674,23690]
===
match
---
atom_expr [15371,15388]
atom_expr [15400,15417]
===
match
---
operator: , [7318,7319]
operator: , [7318,7319]
===
match
---
trailer [13702,13709]
trailer [13731,13738]
===
match
---
trailer [15669,15683]
trailer [15698,15712]
===
match
---
atom_expr [16088,16103]
atom_expr [16117,16132]
===
match
---
trailer [7103,7111]
trailer [7103,7111]
===
match
---
arglist [17413,17436]
arglist [17442,17465]
===
match
---
atom_expr [17182,17191]
atom_expr [17211,17220]
===
match
---
operator: < [8249,8250]
operator: < [8278,8279]
===
match
---
trailer [11069,11128]
trailer [11098,11157]
===
match
---
operator: = [10475,10476]
operator: = [10504,10505]
===
match
---
import_from [1733,1782]
import_from [1733,1782]
===
match
---
param [19485,19486]
param [19514,19515]
===
match
---
subscriptlist [4348,4361]
subscriptlist [4348,4361]
===
match
---
operator: , [20735,20736]
operator: , [20764,20765]
===
match
---
argument [4030,4042]
argument [4030,4042]
===
match
---
trailer [4557,4575]
trailer [4557,4575]
===
match
---
name: sys [11914,11917]
name: sys [11943,11946]
===
match
---
except_clause [22229,22252]
except_clause [22258,22281]
===
match
---
name: limit [22397,22402]
name: limit [22426,22431]
===
match
---
name: dags [7515,7519]
name: dags [7544,7548]
===
match
---
operator: = [22743,22744]
operator: = [22772,22773]
===
match
---
trailer [13424,13551]
trailer [13453,13580]
===
match
---
expr_stmt [14046,14192]
expr_stmt [14075,14221]
===
match
---
name: self [20506,20510]
name: self [20535,20539]
===
match
---
atom_expr [9370,9396]
atom_expr [9399,9425]
===
match
---
argument [22997,23009]
argument [23026,23038]
===
match
---
trailer [20510,20521]
trailer [20539,20550]
===
match
---
import_from [1531,1584]
import_from [1531,1584]
===
match
---
param [17325,17341]
param [17354,17370]
===
match
---
trailer [8691,8696]
trailer [8720,8725]
===
match
---
trailer [18992,19004]
trailer [19021,19033]
===
match
---
name: safe_mode [3497,3506]
name: safe_mode [3497,3506]
===
match
---
suite [15605,15842]
suite [15634,15871]
===
match
---
trailer [22881,22906]
trailer [22910,22935]
===
match
---
name: settings [16255,16263]
name: settings [16284,16292]
===
match
---
string: "Failed to import: %s" [13936,13958]
string: "Failed to import: %s" [13965,13987]
===
match
---
fstring_expr [11380,11391]
fstring_expr [11409,11420]
===
match
---
atom [19175,19213]
atom [19204,19242]
===
match
---
name: file_last_changed [10224,10241]
name: file_last_changed [10253,10270]
===
match
---
parameters [17301,17596]
parameters [17330,17625]
===
match
---
name: dag_folder [18277,18287]
name: dag_folder [18306,18316]
===
match
---
name: dag [3729,3732]
name: dag [3729,3732]
===
match
---
atom_expr [6516,6537]
atom_expr [6516,6537]
===
match
---
suite [19392,19431]
suite [19421,19460]
===
match
---
name: dag_num [1942,1949]
name: dag_num [1942,1949]
===
match
---
name: dag_ids [5644,5651]
name: dag_ids [5644,5651]
===
match
---
atom_expr [8169,8178]
atom_expr [8198,8207]
===
match
---
atom_expr [17468,17519]
atom_expr [17497,17548]
===
match
---
name: root_dag_id [7765,7776]
name: root_dag_id [7794,7805]
===
match
---
name: is_zipfile [14467,14477]
name: is_zipfile [14496,14506]
===
match
---
operator: , [21584,21585]
operator: , [21613,21614]
===
match
---
operator: , [17315,17316]
operator: , [17344,17345]
===
match
---
operator: = [18357,18358]
operator: = [18386,18387]
===
match
---
name: getboolean [3441,3451]
name: getboolean [3441,3451]
===
match
---
simple_stmt [4456,4499]
simple_stmt [4456,4499]
===
match
---
if_stmt [13316,13552]
if_stmt [13345,13581]
===
match
---
atom_expr [11781,11830]
atom_expr [11810,11859]
===
match
---
name: test_cycle [16088,16098]
name: test_cycle [16117,16127]
===
match
---
atom [4242,4244]
atom [4242,4244]
===
match
---
trailer [7782,7793]
trailer [7811,7822]
===
match
---
funcdef [17285,19514]
funcdef [17314,19543]
===
match
---
arglist [18984,19008]
arglist [19013,19037]
===
match
---
name: Dict [4225,4229]
name: Dict [4225,4229]
===
match
---
param [17529,17590]
param [17558,17619]
===
match
---
operator: = [12274,12275]
operator: = [12303,12304]
===
match
---
trailer [7069,7076]
trailer [7069,7076]
===
match
---
suite [21843,21870]
suite [21872,21899]
===
match
---
testlist_comp [20677,20702]
testlist_comp [20706,20731]
===
match
---
trailer [13765,13779]
trailer [13794,13808]
===
match
---
name: dag_id [7275,7281]
name: dag_id [7275,7281]
===
match
---
trailer [8442,8450]
trailer [8471,8479]
===
match
---
operator: = [6483,6484]
operator: = [6483,6484]
===
match
---
atom_expr [20467,20484]
atom_expr [20496,20513]
===
match
---
name: utils [1598,1603]
name: utils [1598,1603]
===
match
---
param [15885,15890]
param [15914,15919]
===
match
---
operator: = [4193,4194]
operator: = [4193,4194]
===
match
---
name: dags [7677,7681]
name: dags [7706,7710]
===
match
---
operator: , [5513,5514]
operator: , [5513,5514]
===
match
---
name: filepath [14478,14486]
name: filepath [14507,14515]
===
match
---
atom_expr [18688,18705]
atom_expr [18717,18734]
===
match
---
atom [11148,11150]
atom [11177,11179]
===
match
---
trailer [17543,17554]
trailer [17572,17583]
===
match
---
name: exception [16884,16893]
name: exception [16913,16922]
===
match
---
funcdef [9417,10792]
funcdef [9446,10821]
===
match
---
name: report [20762,20768]
name: report [20791,20797]
===
match
---
name: settings [22882,22890]
name: settings [22911,22919]
===
match
---
arglist [7962,7990]
arglist [7991,8019]
===
match
---
trailer [10037,10065]
trailer [10066,10094]
===
match
---
trailer [22024,22190]
trailer [22053,22219]
===
match
---
name: serialize_errors [23550,23566]
name: serialize_errors [23579,23595]
===
match
---
name: filepath [10242,10250]
name: filepath [10271,10279]
===
match
---
name: sorted [19460,19466]
name: sorted [19489,19495]
===
match
---
name: min_serialized_dag_fetch_secs [7114,7143]
name: min_serialized_dag_fetch_secs [7114,7143]
===
match
---
name: dag_id [16655,16661]
name: dag_id [16684,16690]
===
match
---
operator: , [4404,4405]
operator: , [4404,4405]
===
match
---
name: session [7311,7318]
name: session [7311,7318]
===
match
---
sync_comp_for [14530,14586]
sync_comp_for [14559,14615]
===
match
---
simple_stmt [11914,11950]
simple_stmt [11943,11979]
===
match
---
name: task_num [21067,21075]
name: task_num [21096,21104]
===
match
---
if_stmt [10421,10609]
if_stmt [10450,10638]
===
match
---
atom_expr [18441,18629]
atom_expr [18470,18658]
===
match
---
operator: = [14827,14828]
operator: = [14856,14857]
===
match
---
trailer [10023,10037]
trailer [10052,10066]
===
match
---
trailer [7085,7103]
trailer [7085,7103]
===
match
---
argument [18796,18815]
argument [18825,18844]
===
match
---
raise_stmt [9078,9158]
raise_stmt [9107,9187]
===
match
---
atom_expr [4456,4478]
atom_expr [4456,4478]
===
match
---
name: limit [14123,14128]
name: limit [14152,14157]
===
match
---
annassign [1926,1937]
annassign [1926,1937]
===
match
---
name: getboolean [3362,3372]
name: getboolean [3362,3372]
===
match
---
operator: = [22853,22854]
operator: = [22882,22883]
===
match
---
name: ZipFile [12603,12610]
name: ZipFile [12632,12639]
===
match
---
operator: == [12932,12934]
operator: == [12961,12963]
===
match
---
arglist [5425,5572]
arglist [5425,5572]
===
match
---
fstring_end: ' [11406,11407]
fstring_end: ' [11435,11436]
===
match
---
comp_if [14565,14586]
comp_if [14594,14615]
===
match
---
simple_stmt [15094,15117]
simple_stmt [15123,15146]
===
match
---
name: str [3311,3314]
name: str [3311,3314]
===
match
---
name: self [14319,14323]
name: self [14348,14352]
===
match
---
trailer [9233,9238]
trailer [9262,9267]
===
match
---
arglist [23662,23697]
arglist [23691,23726]
===
match
---
trailer [13697,13702]
trailer [13726,13731]
===
match
---
expr_stmt [18371,18416]
expr_stmt [18400,18445]
===
match
---
trailer [3451,3487]
trailer [3451,3487]
===
match
---
atom_expr [10038,10064]
atom_expr [10067,10093]
===
match
---
simple_stmt [5191,5250]
simple_stmt [5191,5250]
===
match
---
suite [23047,24021]
suite [23076,24050]
===
match
---
operator: } [4731,4732]
operator: } [4731,4732]
===
match
---
operator: , [17561,17562]
operator: , [17590,17591]
===
match
---
operator: = [6930,6931]
operator: = [6930,6931]
===
match
---
trailer [11917,11925]
trailer [11946,11954]
===
match
---
operator: = [6467,6468]
operator: = [6467,6468]
===
match
---
suite [11000,11129]
suite [11029,11158]
===
match
---
trailer [16274,16279]
trailer [16303,16308]
===
match
---
param [20386,20390]
param [20415,20419]
===
match
---
atom [6990,7157]
atom [6990,7157]
===
match
---
name: file [1904,1908]
name: file [1904,1908]
===
match
---
name: self [5793,5797]
name: self [5793,5797]
===
match
---
name: dag_id [8606,8612]
name: dag_id [8635,8641]
===
match
---
operator: = [8468,8469]
operator: = [8497,8498]
===
match
---
return_stmt [11141,11150]
return_stmt [11170,11179]
===
match
---
simple_stmt [23064,23086]
simple_stmt [23093,23115]
===
match
---
atom_expr [11860,11897]
atom_expr [11889,11926]
===
match
---
comparison [7061,7143]
comparison [7061,7143]
===
match
---
expr_stmt [16447,16487]
expr_stmt [16476,16516]
===
match
---
argument [19035,19087]
argument [19064,19116]
===
match
---
expr_stmt [9987,10065]
expr_stmt [10016,10094]
===
match
---
simple_stmt [12245,12392]
simple_stmt [12274,12421]
===
match
---
atom_expr [4376,4394]
atom_expr [4376,4394]
===
match
---
import_from [969,1009]
import_from [969,1009]
===
match
---
name: exceptions [1367,1377]
name: exceptions [1367,1377]
===
match
---
string: 'core' [17413,17419]
string: 'core' [17442,17448]
===
match
---
trailer [4347,4362]
trailer [4347,4362]
===
match
---
simple_stmt [11457,11483]
simple_stmt [11486,11512]
===
match
---
name: file [1604,1608]
name: file [1604,1608]
===
match
---
trailer [9177,9181]
trailer [9206,9210]
===
match
---
name: safe_mode [13166,13175]
name: safe_mode [13195,13204]
===
match
---
expr_stmt [9271,9298]
expr_stmt [9300,9327]
===
match
---
trailer [18703,18705]
trailer [18732,18734]
===
match
---
suite [5888,8818]
suite [5888,8847]
===
match
---
name: session [21224,21231]
name: session [21253,21260]
===
match
---
trailer [8207,8220]
trailer [8236,8249]
===
match
---
string: """:return: the amount of dags contained in this dagbag""" [5191,5249]
string: """:return: the amount of dags contained in this dagbag""" [5191,5249]
===
match
---
atom_expr [9385,9395]
atom_expr [9414,9424]
===
match
---
trailer [12764,12773]
trailer [12793,12802]
===
match
---
dotted_name [1681,1712]
dotted_name [1681,1712]
===
match
---
operator: = [7274,7275]
operator: = [7274,7275]
===
match
---
operator: , [8848,8849]
operator: , [8877,8878]
===
match
---
name: self [7018,7022]
name: self [7018,7022]
===
match
---
name: values [14555,14561]
name: values [14584,14590]
===
match
---
atom_expr [16641,16662]
atom_expr [16670,16691]
===
match
---
name: dags [4219,4223]
name: dags [4219,4223]
===
match
---
string: "Calling the DAG.bulk_sync_to_db method" [23344,23384]
string: "Calling the DAG.bulk_sync_to_db method" [23373,23413]
===
match
---
return_stmt [7503,7531]
return_stmt [7532,7560]
===
match
---
trailer [19253,19260]
trailer [19282,19289]
===
match
---
operator: = [10013,10014]
operator: = [10042,10043]
===
match
---
suite [17102,17246]
suite [17131,17275]
===
match
---
not_test [10980,10999]
not_test [11009,11028]
===
match
---
trailer [12703,12709]
trailer [12732,12738]
===
match
---
name: o [20692,20693]
name: o [20721,20722]
===
match
---
trailer [22666,22675]
trailer [22695,22704]
===
match
---
suite [14794,14838]
suite [14823,14867]
===
match
---
funcdef [21546,22448]
funcdef [21575,22477]
===
match
---
atom_expr [20771,21154]
atom_expr [20800,21183]
===
match
---
argument [22775,22835]
argument [22804,22864]
===
match
---
name: str [4406,4409]
name: str [4406,4409]
===
match
---
trailer [12782,12791]
trailer [12811,12820]
===
match
---
atom_expr [16651,16661]
atom_expr [16680,16690]
===
match
---
trailer [10045,10054]
trailer [10074,10083]
===
match
---
atom_expr [3639,3653]
atom_expr [3639,3653]
===
match
---
string: "File %s:%s assumed to contain no DAGs. Skipping." [13450,13500]
string: "File %s:%s assumed to contain no DAGs. Skipping." [13479,13529]
===
match
---
name: filepath [13502,13510]
name: filepath [13531,13539]
===
match
---
name: Exception [22295,22304]
name: Exception [22324,22333]
===
match
---
arglist [23605,23617]
arglist [23634,23646]
===
match
---
name: tasks [16305,16310]
name: tasks [16334,16339]
===
match
---
trailer [15705,15719]
trailer [15734,15748]
===
match
---
name: safe_mode [5124,5133]
name: safe_mode [5124,5133]
===
match
---
atom_expr [15147,15158]
atom_expr [15176,15187]
===
match
---
operator: = [20719,20720]
operator: = [20748,20749]
===
match
---
name: airflow [21481,21488]
name: airflow [21510,21517]
===
match
---
atom_expr [8796,8817]
atom_expr [8825,8846]
===
match
---
name: dag [14751,14754]
name: dag [14780,14783]
===
match
---
name: dag_folder [4121,4131]
name: dag_folder [4121,4131]
===
match
---
suite [15256,15515]
suite [15285,15544]
===
match
---
atom_expr [11966,11996]
atom_expr [11995,12025]
===
match
---
name: self [18126,18130]
name: self [18155,18159]
===
match
---
trailer [3193,3200]
trailer [3193,3200]
===
match
---
sync_comp_for [19261,19282]
sync_comp_for [19290,19311]
===
match
---
name: dag_id [6461,6467]
name: dag_id [6461,6467]
===
match
---
operator: { [11551,11552]
operator: { [11580,11581]
===
match
---
operator: = [21251,21252]
operator: = [21280,21281]
===
match
---
simple_stmt [5258,5280]
simple_stmt [5258,5280]
===
match
---
suite [6157,7532]
suite [6157,7561]
===
match
---
name: dag [15055,15058]
name: dag [15084,15087]
===
match
---
atom_expr [17231,17244]
atom_expr [17260,17273]
===
match
---
not_test [10424,10456]
not_test [10453,10485]
===
match
---
simple_stmt [12963,13030]
simple_stmt [12992,13059]
===
match
---
trailer [12698,12703]
trailer [12727,12732]
===
match
---
operator: , [14333,14334]
operator: , [14362,14363]
===
match
---
trailer [16695,16717]
trailer [16724,16746]
===
match
---
trailer [23573,23619]
trailer [23602,23648]
===
match
---
name: encode [11315,11321]
name: encode [11344,11350]
===
match
---
argument [18530,18563]
argument [18559,18592]
===
match
---
atom_expr [5661,5670]
atom_expr [5661,5670]
===
match
---
name: sum [20672,20675]
name: sum [20701,20704]
===
match
---
expr_stmt [20762,21154]
expr_stmt [20791,21183]
===
match
---
name: dag [16301,16304]
name: dag [16330,16333]
===
match
---
arglist [15641,15683]
arglist [15670,15712]
===
match
---
name: airflow [1359,1366]
name: airflow [1359,1366]
===
match
---
trailer [11257,11267]
trailer [11286,11296]
===
match
---
comparison [9794,9810]
comparison [9823,9839]
===
match
---
name: cron_e [15420,15426]
name: cron_e [15449,15455]
===
match
---
atom_expr [10368,10389]
atom_expr [10397,10418]
===
match
---
param [14335,14340]
param [14364,14369]
===
match
---
param [12522,12527]
param [12551,12556]
===
match
---
simple_stmt [10470,10527]
simple_stmt [10499,10556]
===
match
---
atom_expr [10984,10999]
atom_expr [11013,11028]
===
match
---
name: zipfile [12595,12602]
name: zipfile [12624,12631]
===
match
---
string: """Prints a report around DagBag loading stats""" [20401,20450]
string: """Prints a report around DagBag loading stats""" [20430,20479]
===
match
---
name: head [12686,12690]
name: head [12715,12719]
===
match
---
import_from [1585,1675]
import_from [1585,1675]
===
match
---
trailer [15471,15485]
trailer [15500,15514]
===
match
---
trailer [9105,9158]
trailer [9134,9187]
===
match
---
name: dags_hash [4702,4711]
name: dags_hash [4702,4711]
===
match
---
name: get_current [7950,7961]
name: get_current [7979,7990]
===
match
---
name: NamedTuple [1041,1051]
name: NamedTuple [1041,1051]
===
match
---
atom_expr [14983,15025]
atom_expr [15012,15054]
===
match
---
name: dags [8801,8805]
name: dags [8830,8834]
===
match
---
trailer [20544,20586]
trailer [20573,20615]
===
match
---
except_clause [22288,22304]
except_clause [22317,22333]
===
match
---
trailer [12452,12462]
trailer [12481,12491]
===
match
---
operator: = [7699,7700]
operator: = [7728,7729]
===
match
---
testlist_star_expr [12686,12693]
testlist_star_expr [12715,12722]
===
match
---
name: dags [23511,23515]
name: dags [23540,23544]
===
match
---
name: sync_to_db [21207,21217]
name: sync_to_db [21236,21246]
===
match
---
name: new_module [12021,12031]
name: new_module [12050,12060]
===
match
---
import_from [3709,3743]
import_from [3709,3743]
===
match
---
operator: , [5571,5572]
operator: , [5571,5572]
===
match
---
for_stmt [22643,24021]
for_stmt [22672,24050]
===
match
---
import_from [1286,1314]
import_from [1286,1314]
===
match
---
trailer [22941,22958]
trailer [22970,22987]
===
match
---
name: timeout [1802,1809]
name: timeout [1802,1809]
===
match
---
arglist [22689,23010]
arglist [22718,23039]
===
match
---
string: '' [19006,19008]
string: '' [19035,19037]
===
match
---
atom_expr [10219,10251]
atom_expr [10248,10280]
===
match
---
atom_expr [16544,16560]
atom_expr [16573,16589]
===
match
---
name: traceback [928,937]
name: traceback [928,937]
===
match
---
name: subdag [20318,20324]
name: subdag [20347,20353]
===
match
---
name: found_dags [19202,19212]
name: found_dags [19231,19241]
===
match
---
name: found_dag [8638,8647]
name: found_dag [8667,8676]
===
match
---
expr_stmt [14235,14272]
expr_stmt [14264,14301]
===
match
---
name: _add_dag_from_db [6444,6460]
name: _add_dag_from_db [6444,6460]
===
match
---
trailer [16188,16200]
trailer [16217,16229]
===
match
---
name: self [14046,14050]
name: self [14075,14079]
===
match
---
name: dag_id [9334,9340]
name: dag_id [9363,9369]
===
match
---
atom_expr [7779,7800]
atom_expr [7808,7829]
===
match
---
string: "keys" [20745,20751]
string: "keys" [20774,20780]
===
match
---
return_stmt [12480,12489]
return_stmt [12509,12518]
===
match
---
return_stmt [15850,15867]
return_stmt [15879,15896]
===
match
---
expr_stmt [11209,11272]
expr_stmt [11238,11301]
===
match
---
suite [12881,12907]
suite [12910,12936]
===
match
---
name: bag_dag [15047,15054]
name: bag_dag [15076,15083]
===
match
---
trailer [12134,12168]
trailer [12163,12197]
===
match
---
not_test [14779,14793]
not_test [14808,14822]
===
match
---
operator: , [11221,11222]
operator: , [11250,11251]
===
match
---
atom_expr [9006,9045]
atom_expr [9035,9074]
===
match
---
name: found_dags [19125,19135]
name: found_dags [19154,19164]
===
match
---
simple_stmt [9856,9866]
simple_stmt [9885,9895]
===
match
---
name: path_hash [11281,11290]
name: path_hash [11310,11319]
===
match
---
with_stmt [19672,20363]
with_stmt [19701,20392]
===
match
---
name: bool [3648,3652]
name: bool [3648,3652]
===
match
---
name: log [16880,16883]
name: log [16909,16912]
===
match
---
name: __dict__ [14546,14554]
name: __dict__ [14575,14583]
===
match
---
atom_expr [13411,13551]
atom_expr [13440,13580]
===
match
---
param [8844,8849]
param [8873,8878]
===
match
---
try_stmt [16391,17280]
try_stmt [16420,17309]
===
match
---
simple_stmt [11281,11344]
simple_stmt [11310,11373]
===
match
---
atom [14610,14612]
atom [14639,14641]
===
match
---
operator: = [19477,19478]
operator: = [19506,19507]
===
match
---
name: self [11603,11607]
name: self [11632,11636]
===
match
---
operator: , [19214,19215]
operator: , [19243,19244]
===
match
---
name: importlib [854,863]
name: importlib [854,863]
===
match
---
simple_stmt [12558,12568]
simple_stmt [12587,12597]
===
match
---
tfpdef [21224,21250]
tfpdef [21253,21279]
===
match
---
atom_expr [16504,16521]
atom_expr [16533,16550]
===
match
---
atom_expr [10147,10169]
atom_expr [10176,10198]
===
match
---
operator: = [14128,14129]
operator: = [14157,14158]
===
match
---
atom_expr [4396,4410]
atom_expr [4396,4410]
===
match
---
expr_stmt [8357,8488]
expr_stmt [8386,8517]
===
match
---
simple_stmt [16255,16280]
simple_stmt [16284,16309]
===
match
---
trailer [12192,12223]
trailer [12221,12252]
===
match
---
name: dagbag_report [20372,20385]
name: dagbag_report [20401,20414]
===
match
---
operator: , [22906,22907]
operator: , [22935,22936]
===
match
---
name: dag_id [8049,8055]
name: dag_id [8078,8084]
===
match
---
string: "Filling up the DagBag from %s" [18192,18223]
string: "Filling up the DagBag from %s" [18221,18252]
===
match
---
argument [4987,5008]
argument [4987,5008]
===
match
---
suite [13617,13660]
suite [13646,13689]
===
match
---
name: include_smart_sensor [18577,18597]
name: include_smart_sensor [18606,18626]
===
match
---
name: self [15352,15356]
name: self [15381,15385]
===
match
---
funcdef [3254,5155]
funcdef [3254,5155]
===
match
---
import_from [6082,6121]
import_from [6082,6121]
===
match
---
expr_stmt [20611,20652]
expr_stmt [20640,20681]
===
match
---
name: filepath [10135,10143]
name: filepath [10164,10172]
===
match
---
atom_expr [6913,6974]
atom_expr [6913,6974]
===
match
---
simple_stmt [13043,13109]
simple_stmt [13072,13138]
===
match
---
suite [19550,20363]
suite [19579,20392]
===
match
---
operator: = [9254,9255]
operator: = [9283,9284]
===
match
---
operator: } [4414,4415]
operator: } [4414,4415]
===
match
---
operator: = [9465,9466]
operator: = [9494,9495]
===
match
---
name: sys [13638,13641]
name: sys [13667,13670]
===
match
---
name: conf [4780,4784]
name: conf [4780,4784]
===
match
---
name: DagModel [7941,7949]
name: DagModel [7970,7978]
===
match
---
operator: = [18382,18383]
operator: = [18411,18412]
===
match
---
name: dag [15371,15374]
name: dag [15400,15403]
===
match
---
trailer [4156,4168]
trailer [4156,4168]
===
match
---
name: get [8806,8809]
name: get [8835,8838]
===
match
---
simple_stmt [4177,4206]
simple_stmt [4177,4206]
===
match
---
atom_expr [8687,8704]
atom_expr [8716,8733]
===
match
---
trailer [9238,9253]
trailer [9267,9282]
===
match
---
trailer [9024,9028]
trailer [9053,9057]
===
match
---
trailer [23975,23989]
trailer [24004,24018]
===
match
---
name: self [8370,8374]
name: self [8399,8403]
===
match
---
fstring_start: f""" [20800,20804]
fstring_start: f""" [20829,20833]
===
match
---
trailer [12602,12610]
trailer [12631,12639]
===
match
---
trailer [11305,11331]
trailer [11334,11360]
===
match
---
name: e [19428,19429]
name: e [19457,19458]
===
match
---
name: full_filepath [14707,14720]
name: full_filepath [14736,14749]
===
match
---
for_stmt [18425,19431]
for_stmt [18454,19460]
===
match
---
fstring_expr [11551,11579]
fstring_expr [11580,11608]
===
match
---
trailer [14561,14563]
trailer [14590,14592]
===
match
---
name: subdag [20301,20307]
name: subdag [20330,20336]
===
match
---
name: mod_name [12923,12931]
name: mod_name [12952,12960]
===
match
---
string: "Importing %s" [11175,11189]
string: "Importing %s" [11204,11218]
===
match
---
operator: , [15199,15200]
operator: , [15228,15229]
===
match
---
name: is_missing [8283,8293]
name: is_missing [8312,8322]
===
match
---
name: table [20713,20718]
name: table [20742,20747]
===
match
---
name: tenacity [22658,22666]
name: tenacity [22687,22695]
===
match
---
name: session [23682,23689]
name: session [23711,23718]
===
match
---
atom_expr [8617,8633]
atom_expr [8646,8662]
===
match
---
if_stmt [9054,9159]
if_stmt [9083,9188]
===
match
---
expr_stmt [4697,4732]
expr_stmt [4697,4732]
===
match
---
trailer [13608,13616]
trailer [13637,13645]
===
match
---
if_stmt [8280,8781]
if_stmt [8309,8810]
===
match
---
trailer [16654,16661]
trailer [16683,16690]
===
match
---
operator: @ [21182,21183]
operator: @ [21211,21212]
===
match
---
atom [22214,22216]
atom [22243,22245]
===
match
---
name: self [11056,11060]
name: self [11085,11089]
===
match
---
trailer [11174,11200]
trailer [11203,11229]
===
match
---
name: importlib [11860,11869]
name: importlib [11889,11898]
===
match
---
atom_expr [19409,19430]
atom_expr [19438,19459]
===
match
---
name: dagbag_import_error_traceback_depth [14135,14170]
name: dagbag_import_error_traceback_depth [14164,14199]
===
match
---
operator: , [4907,4908]
operator: , [4907,4908]
===
match
---
name: dag [16651,16654]
name: dag [16680,16683]
===
match
---
operator: - [14129,14130]
operator: - [14158,14159]
===
match
---
simple_stmt [8930,8991]
simple_stmt [8959,9020]
===
match
---
name: filepath [12611,12619]
name: filepath [12640,12648]
===
match
---
name: len [5265,5268]
name: len [5265,5268]
===
match
---
name: MAX_DB_RETRIES [23279,23293]
name: MAX_DB_RETRIES [23308,23322]
===
match
---
if_stmt [17083,17246]
if_stmt [17112,17275]
===
match
---
name: dag_id [19254,19260]
name: dag_id [19283,19289]
===
match
---
name: Session [5872,5879]
name: Session [5872,5879]
===
match
---
name: read_dags_from_db [4461,4478]
name: read_dags_from_db [4461,4478]
===
match
---
name: importlib [827,836]
name: importlib [827,836]
===
match
---
argument [14123,14170]
argument [14152,14199]
===
match
---
operator: = [18506,18507]
operator: = [18535,18536]
===
match
---
trailer [15776,15794]
trailer [15805,15823]
===
match
---
name: dag [17086,17089]
name: dag [17115,17118]
===
match
---
name: file_last_changed_on_disk [15816,15841]
name: file_last_changed_on_disk [15845,15870]
===
match
---
name: self [10825,10829]
name: self [10854,10858]
===
match
---
atom_expr [12595,12620]
atom_expr [12624,12649]
===
match
---
name: str [4348,4351]
name: str [4348,4351]
===
match
---
simple_stmt [23641,23699]
simple_stmt [23670,23728]
===
match
---
operator: } [4366,4367]
operator: } [4366,4367]
===
match
---
param [21224,21257]
param [21253,21286]
===
match
---
import_from [1496,1530]
import_from [1496,1530]
===
match
---
param [19544,19548]
param [19573,19577]
===
match
---
name: dag_id [7104,7110]
name: dag_id [7104,7110]
===
match
---
name: debug [23338,23343]
name: debug [23367,23372]
===
match
---
trailer [11435,11443]
trailer [11464,11472]
===
match
---
simple_stmt [5897,6042]
simple_stmt [5897,6042]
===
match
---
atom_expr [3302,3315]
atom_expr [3302,3315]
===
match
---
trailer [20600,20602]
trailer [20629,20631]
===
match
---
name: orm_dag [8435,8442]
name: orm_dag [8464,8471]
===
match
---
expr_stmt [20293,20324]
expr_stmt [20322,20353]
===
match
---
trailer [18902,19325]
trailer [18931,19354]
===
match
---
name: filepath [18753,18761]
name: filepath [18782,18790]
===
match
---
name: self [20337,20341]
name: self [20366,20370]
===
match
---
atom [9863,9865]
atom [9892,9894]
===
match
---
name: subdags [15151,15158]
name: subdags [15180,15187]
===
match
---
suite [13677,13834]
suite [13706,13863]
===
match
---
trailer [7406,7414]
trailer [7435,7443]
===
match
---
classdef [1827,1987]
classdef [1827,1987]
===
match
---
atom_expr [12245,12273]
atom_expr [12274,12302]
===
match
---
and_test [8200,8271]
and_test [8229,8300]
===
match
---
name: dag [20203,20206]
name: dag [20232,20235]
===
match
---
name: root_dag [17093,17101]
name: root_dag [17122,17130]
===
match
---
simple_stmt [10402,10412]
simple_stmt [10431,10441]
===
match
---
expr_stmt [4376,4415]
expr_stmt [4376,4415]
===
match
---
name: modules [13609,13616]
name: modules [13638,13645]
===
match
---
suite [8663,8705]
suite [8692,8734]
===
match
---
name: found_dags [8357,8367]
name: found_dags [8386,8396]
===
match
---
fstring_expr [20916,20928]
fstring_expr [20945,20957]
===
match
---
name: modules [11465,11472]
name: modules [11494,11501]
===
match
---
simple_stmt [6266,6327]
simple_stmt [6266,6327]
===
match
---
string: "Failed to import: %s" [12135,12157]
string: "Failed to import: %s" [12164,12186]
===
match
---
simple_stmt [12741,12793]
simple_stmt [12770,12822]
===
match
---
atom_expr [20677,20687]
atom_expr [20706,20716]
===
match
---
name: tenacity [22780,22788]
name: tenacity [22809,22817]
===
match
---
atom_expr [23550,23619]
atom_expr [23579,23648]
===
match
---
parameters [8843,8880]
parameters [8872,8909]
===
match
---
argument [5069,5110]
argument [5069,5110]
===
match
---
name: self [10147,10151]
name: self [10176,10180]
===
match
---
expr_stmt [4424,4447]
expr_stmt [4424,4447]
===
match
---
operator: = [18778,18779]
operator: = [18807,18808]
===
match
---
suite [13347,13552]
suite [13376,13581]
===
match
---
name: dag [23499,23502]
name: dag [23528,23531]
===
match
---
trailer [16151,16174]
trailer [16180,16203]
===
match
---
name: tabulate [1276,1284]
name: tabulate [1276,1284]
===
match
---
operator: , [4233,4234]
operator: , [4233,4234]
===
match
---
name: found_dags [10781,10791]
name: found_dags [10810,10820]
===
match
---
trailer [20300,20315]
trailer [20329,20344]
===
match
---
trailer [3372,3397]
trailer [3372,3397]
===
match
---
trailer [18696,18703]
trailer [18725,18732]
===
match
---
trailer [7949,7961]
trailer [7978,7990]
===
match
---
operator: , [9448,9449]
operator: , [9477,9478]
===
match
---
operator: , [7281,7282]
operator: , [7281,7282]
===
match
---
trailer [13146,13194]
trailer [13175,13223]
===
match
---
simple_stmt [20174,20187]
simple_stmt [20203,20216]
===
match
---
name: dag_id [7711,7717]
name: dag_id [7740,7746]
===
match
---
name: dag [22363,22366]
name: dag [22392,22395]
===
match
---
name: e [19358,19359]
name: e [19387,19388]
===
match
---
comparison [12923,12945]
comparison [12952,12974]
===
match
---
atom_expr [13129,13194]
atom_expr [13158,13223]
===
match
---
name: full_filepath [15472,15485]
name: full_filepath [15501,15514]
===
match
---
fstring_end: """ [21141,21144]
fstring_end: """ [21170,21173]
===
match
---
atom_expr [12696,12728]
atom_expr [12725,12757]
===
match
---
name: self [10984,10988]
name: self [11013,11017]
===
match
---
name: e [10387,10388]
name: e [10416,10417]
===
match
---
trailer [11168,11174]
trailer [11197,11203]
===
match
---
dotted_name [854,868]
dotted_name [854,868]
===
match
---
import_from [21433,21467]
import_from [21462,21496]
===
match
---
operator: , [3487,3488]
operator: , [3487,3488]
===
match
---
trailer [16473,16487]
trailer [16502,16516]
===
match
---
suite [9879,10293]
suite [9908,10322]
===
match
---
name: max [22829,22832]
name: max [22858,22861]
===
match
---
name: self [4956,4960]
name: self [4956,4960]
===
match
---
simple_stmt [1286,1315]
simple_stmt [1286,1315]
===
match
---
name: SerializedDagModel [6308,6326]
name: SerializedDagModel [6308,6326]
===
match
---
name: self [5169,5173]
name: self [5169,5173]
===
match
---
trailer [5602,5620]
trailer [5602,5620]
===
match
---
name: Dict [4713,4717]
name: Dict [4713,4717]
===
match
---
suite [22337,22448]
suite [22366,22477]
===
match
---
name: tabulate [1260,1268]
name: tabulate [1260,1268]
===
match
---
atom_expr [21233,21250]
atom_expr [21262,21279]
===
match
---
name: session [8863,8870]
name: session [8892,8899]
===
match
---
operator: , [10514,10515]
operator: , [10543,10544]
===
match
---
atom_expr [19121,19136]
atom_expr [19150,19165]
===
match
---
simple_stmt [11774,11831]
simple_stmt [11803,11860]
===
match
---
trailer [22099,22134]
trailer [22128,22163]
===
match
---
with_stmt [23034,24021]
with_stmt [23063,24050]
===
match
---
name: hashlib [11293,11300]
name: hashlib [11322,11329]
===
match
---
name: fileloc [22367,22374]
name: fileloc [22396,22403]
===
match
---
operator: = [7464,7465]
operator: = [7493,7494]
===
match
---
name: bool [3350,3354]
name: bool [3350,3354]
===
match
---
operator: = [4040,4041]
operator: = [4040,4041]
===
match
---
trailer [13327,13338]
trailer [13356,13367]
===
match
---
except_clause [23715,23738]
except_clause [23744,23767]
===
match
---
name: zipfile [10428,10435]
name: zipfile [10457,10464]
===
match
---
name: dagbag_import_error_tracebacks [13994,14024]
name: dagbag_import_error_tracebacks [14023,14053]
===
match
---
name: path [12760,12764]
name: path [12789,12793]
===
match
---
trailer [8173,8178]
trailer [8202,8207]
===
match
---
arglist [3452,3486]
arglist [3452,3486]
===
match
---
name: self [4553,4557]
name: self [4553,4557]
===
match
---
simple_stmt [14235,14273]
simple_stmt [14264,14302]
===
match
---
expr_stmt [1977,1986]
expr_stmt [1977,1986]
===
match
---
name: is_subdag [21833,21842]
name: is_subdag [21862,21871]
===
match
---
name: subdag [16412,16418]
name: subdag [16441,16447]
===
match
---
trailer [22014,22024]
trailer [22043,22053]
===
match
---
expr_stmt [18834,18873]
expr_stmt [18863,18902]
===
match
---
suite [14214,14273]
suite [14243,14302]
===
match
---
fstring_expr [11534,11544]
fstring_expr [11563,11573]
===
match
---
atom_expr [23574,23618]
atom_expr [23603,23647]
===
match
---
dotted_name [1320,1341]
dotted_name [1320,1341]
===
match
---
atom_expr [21829,21842]
atom_expr [21858,21871]
===
match
---
suite [3668,5155]
suite [3668,5155]
===
match
---
name: duration [20548,20556]
name: duration [20577,20585]
===
match
---
arith_expr [7081,7143]
arith_expr [7081,7143]
===
match
---
expr_stmt [4456,4498]
expr_stmt [4456,4498]
===
match
---
trailer [9820,9825]
trailer [9849,9854]
===
match
---
simple_stmt [18722,18817]
simple_stmt [18751,18846]
===
match
---
name: self [4319,4323]
name: self [4319,4323]
===
match
---
argument [5124,5143]
argument [5124,5143]
===
match
---
atom_expr [9229,9253]
atom_expr [9258,9282]
===
match
---
atom_expr [13694,13722]
atom_expr [13723,13751]
===
match
---
name: models [21446,21452]
name: models [21475,21481]
===
match
---
name: self [22959,22963]
name: self [22988,22992]
===
match
---
atom_expr [6134,6156]
atom_expr [6134,6156]
===
match
---
name: row [9000,9003]
name: row [9029,9032]
===
match
---
name: filepath [10588,10596]
name: filepath [10617,10625]
===
match
---
atom [10081,10265]
atom [10110,10294]
===
match
---
trailer [15744,15755]
trailer [15773,15784]
===
match
---
name: self [23662,23666]
name: self [23691,23695]
===
match
---
name: dags [8040,8044]
name: dags [8069,8073]
===
match
---
trailer [14545,14554]
trailer [14574,14583]
===
match
---
atom_expr [23506,23524]
atom_expr [23535,23553]
===
match
---
operator: = [16368,16369]
operator: = [16397,16398]
===
match
---
atom_expr [15317,15334]
atom_expr [15346,15363]
===
match
---
arglist [23138,23294]
arglist [23167,23323]
===
match
---
trailer [16685,16689]
trailer [16714,16718]
===
match
---
if_stmt [7354,7490]
if_stmt [7354,7519]
===
match
---
suite [14368,15868]
suite [14397,15897]
===
match
---
atom_expr [13323,13338]
atom_expr [13352,13367]
===
match
---
sync_comp_for [20688,20702]
sync_comp_for [20717,20731]
===
match
---
name: Dict [4577,4581]
name: Dict [4577,4581]
===
match
---
name: getmtime [10046,10054]
name: getmtime [10075,10083]
===
match
---
for_stmt [9190,9263]
for_stmt [9219,9292]
===
match
---
name: full_filepath [15799,15812]
name: full_filepath [15828,15841]
===
match
---
operator: = [15487,15488]
operator: = [15516,15517]
===
match
---
name: mod_name [11813,11821]
name: mod_name [11842,11850]
===
match
---
atom_expr [20293,20315]
atom_expr [20322,20344]
===
match
---
operator: , [19472,19473]
operator: , [19501,19502]
===
match
---
name: test_cycle [1574,1584]
name: test_cycle [1574,1584]
===
match
---
name: import_errors [15706,15719]
name: import_errors [15735,15748]
===
match
---
name: file_last_changed [4324,4341]
name: file_last_changed [4324,4341]
===
match
---
name: self [4376,4380]
name: self [4376,4380]
===
match
---
name: filepath [9794,9802]
name: filepath [9823,9831]
===
match
---
name: info [13420,13424]
name: info [13449,13453]
===
match
---
name: Retrying [22667,22675]
name: Retrying [22696,22704]
===
match
---
string: "File %s assumed to contain no DAGs. Skipping." [11070,11117]
string: "File %s assumed to contain no DAGs. Skipping." [11099,11146]
===
match
---
atom [4413,4415]
atom [4413,4415]
===
match
---
trailer [3832,4057]
trailer [3832,4057]
===
match
---
expr_stmt [7765,7800]
expr_stmt [7794,7829]
===
match
---
name: o [20677,20678]
name: o [20706,20707]
===
match
---
trailer [11267,11271]
trailer [11296,11300]
===
match
---
name: utils [1509,1514]
name: utils [1509,1514]
===
match
---
trailer [18459,18629]
trailer [18488,18658]
===
match
---
suite [12549,14293]
suite [12578,14322]
===
match
---
atom_expr [16584,16627]
atom_expr [16613,16656]
===
match
---
trailer [11234,11243]
trailer [11263,11272]
===
match
---
decorated [5626,5811]
decorated [5626,5811]
===
match
---
operator: , [7973,7974]
operator: , [8002,8003]
===
match
---
dotted_name [1181,1195]
dotted_name [1181,1195]
===
match
---
name: dag_id [7458,7464]
name: dag_id [7487,7493]
===
match
---
operator: , [1033,1034]
operator: , [1033,1034]
===
match
---
trailer [11737,11757]
trailer [11766,11786]
===
match
---
name: include_smart_sensor [17447,17467]
name: include_smart_sensor [17476,17496]
===
match
---
operator: = [5038,5039]
operator: = [5038,5039]
===
match
---
simple_stmt [20611,20653]
simple_stmt [20640,20682]
===
match
---
name: session [6476,6483]
name: session [6476,6483]
===
match
---
operator: , [4012,4013]
operator: , [4012,4013]
===
match
---
name: filepath [10653,10661]
name: filepath [10682,10690]
===
match
---
suite [12224,12392]
suite [12253,12421]
===
match
---
name: cycle_exception [17264,17279]
name: cycle_exception [17293,17308]
===
match
---
suite [8881,9412]
suite [8910,9441]
===
match
---
atom_expr [20541,20602]
atom_expr [20570,20631]
===
match
---
return_stmt [5258,5279]
return_stmt [5258,5279]
===
match
---
dotted_name [827,846]
dotted_name [827,846]
===
match
---
name: dag_id [7268,7274]
name: dag_id [7268,7274]
===
match
---
import_from [1220,1254]
import_from [1220,1254]
===
match
---
name: duration [20530,20538]
name: duration [20559,20567]
===
match
---
name: self [4424,4428]
name: self [4424,4428]
===
match
---
name: o [20546,20547]
name: o [20575,20576]
===
match
---
name: log [19726,19729]
name: log [19755,19758]
===
match
---
trailer [10386,10389]
trailer [10415,10418]
===
match
---
funcdef [15873,17280]
funcdef [15902,17309]
===
match
---
atom_expr [7701,7718]
atom_expr [7730,7747]
===
match
---
atom_expr [19171,19214]
atom_expr [19200,19243]
===
match
---
simple_stmt [10283,10293]
simple_stmt [10312,10322]
===
match
---
simple_stmt [11209,11273]
simple_stmt [11238,11302]
===
match
---
name: stacklevel [4030,4040]
name: stacklevel [4030,4040]
===
match
---
name: dag [20260,20263]
name: dag [20289,20292]
===
match
---
name: models [14390,14396]
name: models [14419,14425]
===
match
---
operator: - [11268,11269]
operator: - [11297,11298]
===
match
---
expr_stmt [10618,10695]
expr_stmt [10647,10724]
===
match
---
operator: = [19043,19044]
operator: = [19072,19073]
===
match
---
operator: , [20572,20573]
operator: , [20601,20602]
===
match
---
name: dag [14815,14818]
name: dag [14844,14847]
===
match
---
name: dag [15468,15471]
name: dag [15497,15500]
===
match
---
operator: , [12526,12527]
operator: , [12555,12556]
===
match
---
suite [16430,16628]
suite [16459,16657]
===
match
---
param [14319,14324]
param [14348,14353]
===
match
---
operator: , [15894,15895]
operator: , [15923,15924]
===
match
---
trailer [19124,19136]
trailer [19153,19165]
===
match
---
operator: = [9481,9482]
operator: = [9510,9511]
===
match
---
trailer [17401,17412]
trailer [17430,17441]
===
match
---
name: filepath [18967,18975]
name: filepath [18996,19004]
===
match
---
operator: , [22374,22375]
operator: , [22403,22404]
===
match
---
operator: , [4802,4803]
operator: , [4802,4803]
===
match
---
simple_stmt [18834,18874]
simple_stmt [18863,18903]
===
match
---
name: safe_mode [10598,10607]
name: safe_mode [10627,10636]
===
match
---
trailer [4795,4837]
trailer [4795,4837]
===
match
---
name: path [13698,13702]
name: path [13727,13731]
===
match
---
name: row [9061,9064]
name: row [9090,9093]
===
match
---
simple_stmt [1585,1676]
simple_stmt [1585,1676]
===
match
---
name: filepath [11258,11266]
name: filepath [11287,11295]
===
match
---
simple_stmt [9987,10066]
simple_stmt [10016,10095]
===
match
---
name: self [4846,4850]
name: self [4846,4850]
===
match
---
trailer [15467,15486]
trailer [15496,15515]
===
match
---
operator: , [19004,19005]
operator: , [19033,19034]
===
match
---
name: dag [15795,15798]
name: dag [15824,15827]
===
match
---
name: settings [4148,4156]
name: settings [4148,4156]
===
match
---
simple_stmt [8187,8272]
simple_stmt [8216,8301]
===
match
---
name: fileloc [14819,14826]
name: fileloc [14848,14855]
===
match
---
name: bool [3594,3598]
name: bool [3594,3598]
===
match
---
simple_stmt [1904,1914]
simple_stmt [1904,1914]
===
match
---
not_test [13125,13194]
not_test [13154,13223]
===
match
---
import_from [1315,1353]
import_from [1315,1353]
===
match
---
suite [12413,12472]
suite [12442,12501]
===
match
---
name: timeout_msg [11645,11656]
name: timeout_msg [11674,11685]
===
match
---
name: importlib [13756,13765]
name: importlib [13785,13794]
===
match
---
suite [20392,21177]
suite [20421,21206]
===
match
---
trailer [20307,20314]
trailer [20336,20343]
===
match
---
testlist_comp [20626,20650]
testlist_comp [20655,20679]
===
match
---
fstring_expr [21125,21132]
fstring_expr [21154,21161]
===
match
---
expr_stmt [18722,18816]
expr_stmt [18751,18845]
===
match
---
name: getint [4894,4900]
name: getint [4894,4900]
===
match
---
atom_expr [14871,14884]
atom_expr [14900,14913]
===
match
---
if_stmt [6131,7532]
if_stmt [6131,7561]
===
match
---
operator: = [22694,22695]
operator: = [22723,22724]
===
match
---
name: log [15278,15281]
name: log [15307,15310]
===
match
---
name: self [9271,9275]
name: self [9300,9304]
===
match
---
expr_stmt [14815,14837]
expr_stmt [14844,14866]
===
match
---
name: isinstance [14912,14922]
name: isinstance [14941,14951]
===
match
---
param [14341,14366]
param [14370,14395]
===
match
---
name: isinstance [14568,14578]
name: isinstance [14597,14607]
===
match
---
arglist [4987,5144]
arglist [4987,5144]
===
match
---
expr_stmt [19931,19977]
expr_stmt [19960,20006]
===
match
---
name: str [15741,15744]
name: str [15770,15773]
===
match
---
operator: , [14955,14956]
operator: , [14984,14985]
===
match
---
simple_stmt [10705,10766]
simple_stmt [10734,10795]
===
match
---
fstring [11363,11407]
fstring [11392,11436]
===
match
---
name: get [6526,6529]
name: get [6526,6529]
===
match
---
number: 0 [13710,13711]
number: 0 [13739,13740]
===
match
---
name: mod_name [11420,11428]
name: mod_name [11449,11457]
===
match
---
simple_stmt [19721,19774]
simple_stmt [19750,19803]
===
match
---
arglist [13936,13968]
arglist [13965,13997]
===
match
---
name: configuration [1328,1341]
name: configuration [1328,1341]
===
match
---
trailer [5807,5809]
trailer [5807,5809]
===
match
---
name: timer [19683,19688]
name: timer [19712,19717]
===
match
---
operator: = [9342,9343]
operator: = [9371,9372]
===
match
---
name: dag_id [9246,9252]
name: dag_id [9275,9281]
===
match
---
atom_expr [4697,4711]
atom_expr [4697,4711]
===
match
---
name: get [9025,9028]
name: get [9054,9057]
===
match
---
name: dag [9204,9207]
name: dag [9233,9236]
===
match
---
name: tenacity [1070,1078]
name: tenacity [1070,1078]
===
match
---
name: only_if_updated [17350,17365]
name: only_if_updated [17379,17394]
===
match
---
raise_stmt [17258,17279]
raise_stmt [17287,17308]
===
match
---
name: subdags [20264,20271]
name: subdags [20293,20300]
===
match
---
trailer [16588,16596]
trailer [16617,16625]
===
match
---
atom_expr [19488,19498]
atom_expr [19517,19527]
===
match
---
operator: { [4730,4731]
operator: { [4730,4731]
===
match
---
expr_stmt [20459,20484]
expr_stmt [20488,20513]
===
match
---
atom [22361,22447]
atom [22390,22476]
===
match
---
atom_expr [11603,11629]
atom_expr [11632,11658]
===
match
---
operator: = [7982,7983]
operator: = [8011,8012]
===
match
---
name: str [4582,4585]
name: str [4582,4585]
===
match
---
name: exception [13926,13935]
name: exception [13955,13964]
===
match
---
trailer [21241,21250]
trailer [21270,21279]
===
match
---
operator: = [5569,5570]
operator: = [5569,5570]
===
match
---
name: dag [8225,8228]
name: dag [8254,8257]
===
match
---
name: dag [7779,7782]
name: dag [7808,7811]
===
match
---
operator: { [11392,11393]
operator: { [11421,11422]
===
match
---
atom_expr [13147,13164]
atom_expr [13176,13193]
===
match
---
trailer [11874,11891]
trailer [11903,11920]
===
match
---
name: dag [16665,16668]
name: dag [16694,16697]
===
match
---
comparison [7008,7040]
comparison [7008,7040]
===
match
---
name: dag [14397,14400]
name: dag [14426,14429]
===
match
---
name: zip_info [12774,12782]
name: zip_info [12803,12811]
===
match
---
trailer [9374,9384]
trailer [9403,9413]
===
match
---
simple_stmt [17217,17246]
simple_stmt [17246,17275]
===
match
---
suite [20229,20325]
suite [20258,20354]
===
match
---
name: int [1969,1972]
name: int [1969,1972]
===
match
---
name: DAGBAG_IMPORT_TIMEOUT [11557,11578]
name: DAGBAG_IMPORT_TIMEOUT [11586,11607]
===
match
---
trailer [23515,23522]
trailer [23544,23551]
===
match
---
operator: = [15739,15740]
operator: = [15768,15769]
===
match
---
atom_expr [9239,9252]
atom_expr [9268,9281]
===
match
---
trailer [11472,11482]
trailer [11501,11511]
===
match
---
param [8850,8862]
param [8879,8891]
===
match
---
name: SerializedDagModel [7202,7220]
name: SerializedDagModel [7202,7220]
===
match
---
name: getfloat [3109,3117]
name: getfloat [3109,3117]
===
match
---
string: 'DAGBAG_IMPORT_TIMEOUT' [3126,3149]
string: 'DAGBAG_IMPORT_TIMEOUT' [3126,3149]
===
match
---
name: dag_id [8697,8703]
name: dag_id [8726,8732]
===
match
---
name: log [1695,1698]
name: log [1695,1698]
===
match
---
name: session [21586,21593]
name: session [21615,21622]
===
match
---
name: mods [14288,14292]
name: mods [14317,14321]
===
match
---
operator: { [21029,21030]
operator: { [21058,21059]
===
match
---
name: SerializedDagModel [19943,19961]
name: SerializedDagModel [19972,19990]
===
match
---
if_stmt [7731,7817]
if_stmt [7760,7846]
===
match
---
name: format_exc [12286,12296]
name: format_exc [12315,12325]
===
match
---
simple_stmt [15273,15336]
simple_stmt [15302,15365]
===
match
---
suite [21886,22217]
suite [21915,22246]
===
match
---
name: self [8796,8800]
name: self [8825,8829]
===
match
---
name: filepath [14723,14731]
name: filepath [14752,14760]
===
match
---
atom_expr [8732,8741]
atom_expr [8761,8770]
===
match
---
atom_expr [14751,14762]
atom_expr [14780,14791]
===
match
---
argument [8453,8474]
argument [8482,8503]
===
match
---
name: resolve_template_files [16152,16174]
name: resolve_template_files [16181,16203]
===
match
---
suite [13900,14273]
suite [13929,14302]
===
match
---
name: self [8035,8039]
name: self [8064,8068]
===
match
---
operator: , [22171,22172]
operator: , [22200,22201]
===
match
---
operator: = [8368,8369]
operator: = [8397,8398]
===
match
---
trailer [9280,9292]
trailer [9309,9321]
===
match
---
operator: = [14075,14076]
operator: = [14104,14105]
===
match
---
simple_stmt [16544,16568]
simple_stmt [16573,16597]
===
match
---
import_from [8930,8990]
import_from [8959,9019]
===
match
---
operator: = [11225,11226]
operator: = [11254,11255]
===
match
---
expr_stmt [4553,4601]
expr_stmt [4553,4601]
===
match
---
operator: , [10839,10840]
operator: , [10868,10869]
===
match
---
trailer [10885,10906]
trailer [10914,10935]
===
match
---
suite [1858,1987]
suite [1858,1987]
===
match
---
name: store_serialized_dags [3784,3805]
name: store_serialized_dags [3784,3805]
===
match
---
operator: , [1636,1637]
operator: , [1636,1637]
===
match
---
operator: , [16921,16922]
operator: , [16950,16951]
===
match
---
operator: = [19120,19121]
operator: = [19149,19150]
===
match
---
operator: = [9293,9294]
operator: = [9322,9323]
===
match
---
except_clause [12045,12066]
except_clause [12074,12095]
===
match
---
simple_stmt [894,905]
simple_stmt [894,905]
===
match
---
atom_expr [16203,16220]
atom_expr [16232,16249]
===
match
---
name: airflow [19607,19614]
name: airflow [19636,19643]
===
match
---
name: dag [15891,15894]
name: dag [15920,15923]
===
match
---
name: self [9307,9311]
name: self [9336,9340]
===
match
---
expr_stmt [11774,11830]
expr_stmt [11803,11859]
===
match
---
arglist [3201,3247]
arglist [3201,3247]
===
match
---
name: self [6439,6443]
name: self [6439,6443]
===
match
---
name: reverse [19500,19507]
name: reverse [19529,19536]
===
match
---
arglist [16894,16933]
arglist [16923,16962]
===
match
---
name: parent_dag [7783,7793]
name: parent_dag [7812,7822]
===
match
---
name: filepath [10055,10063]
name: filepath [10084,10092]
===
match
---
atom_expr [6357,6366]
atom_expr [6357,6366]
===
match
---
operator: = [10629,10630]
operator: = [10658,10659]
===
match
---
operator: , [10661,10662]
operator: , [10690,10691]
===
match
---
name: getboolean [4785,4795]
name: getboolean [4785,4795]
===
match
---
operator: = [11699,11700]
operator: = [11728,11729]
===
match
---
return_stmt [6509,6537]
return_stmt [6509,6537]
===
match
---
name: self [19409,19413]
name: self [19438,19442]
===
match
---
param [8863,8879]
param [8892,8908]
===
match
---
import_name [1063,1078]
import_name [1063,1078]
===
match
---
operator: , [15559,15560]
operator: , [15588,15589]
===
match
---
trailer [19427,19430]
trailer [19456,19459]
===
match
---
atom_expr [21996,22190]
atom_expr [22025,22219]
===
match
---
name: sys [11432,11435]
name: sys [11461,11464]
===
match
---
name: self [5325,5329]
name: self [5325,5329]
===
match
---
trailer [8434,8451]
trailer [8463,8480]
===
match
---
trailer [12296,12391]
trailer [12325,12420]
===
match
---
trailer [11321,11330]
trailer [11350,11359]
===
match
---
name: dags [16646,16650]
name: dags [16675,16679]
===
match
---
string: 'Exception bagging dag: %s' [16894,16921]
string: 'Exception bagging dag: %s' [16923,16950]
===
match
---
name: utils [1796,1801]
name: utils [1796,1801]
===
match
---
argument [7975,7990]
argument [8004,8019]
===
match
---
trailer [13088,13097]
trailer [13117,13126]
===
match
---
atom_expr [4148,4168]
atom_expr [4148,4168]
===
match
---
operator: , [21222,21223]
operator: , [21251,21252]
===
match
---
name: self [12434,12438]
name: self [12463,12467]
===
match
---
trailer [4229,4239]
trailer [4229,4239]
===
match
---
atom_expr [14568,14586]
atom_expr [14597,14615]
===
match
---
atom_expr [14077,14192]
atom_expr [14106,14221]
===
match
---
name: timedelta [20574,20583]
name: timedelta [20603,20612]
===
match
---
operator: = [14885,14886]
operator: = [14914,14915]
===
match
---
name: dag [7611,7614]
name: dag [7640,7643]
===
match
---
name: zip_info [13080,13088]
name: zip_info [13109,13117]
===
match
---
trailer [18739,18752]
trailer [18768,18781]
===
match
---
name: utcnow [18865,18871]
name: utcnow [18894,18900]
===
match
---
atom_expr [11056,11128]
atom_expr [11085,11157]
===
match
---
atom_expr [11306,11330]
atom_expr [11335,11359]
===
match
---
name: SerializedDagModel [8972,8990]
name: SerializedDagModel [9001,9019]
===
match
---
name: dag [8233,8236]
name: dag [8262,8265]
===
match
---
name: session [5863,5870]
name: session [5863,5870]
===
match
---
name: property [5286,5294]
name: property [5286,5294]
===
match
---
simple_stmt [11966,11997]
simple_stmt [11995,12026]
===
match
---
name: dag [19180,19183]
name: dag [19209,19212]
===
match
---
dotted_name [8935,8964]
dotted_name [8964,8993]
===
match
---
trailer [11341,11343]
trailer [11370,11372]
===
match
---
operator: , [19136,19137]
operator: , [19165,19166]
===
match
---
trailer [12438,12452]
trailer [12467,12481]
===
match
---
param [15896,15904]
param [15925,15933]
===
match
---
operator: = [14264,14265]
operator: = [14293,14294]
===
match
---
name: Stats [1490,1495]
name: Stats [1490,1495]
===
match
---
trailer [15374,15388]
trailer [15403,15417]
===
match
---
name: head [12876,12880]
name: head [12905,12909]
===
match
---
operator: , [10667,10668]
operator: , [10696,10697]
===
match
---
name: spec [11774,11778]
name: spec [11803,11807]
===
match
---
name: dag [9385,9388]
name: dag [9414,9417]
===
match
---
name: DAG [21464,21467]
name: DAG [21493,21496]
===
match
---
operator: , [13078,13079]
operator: , [13107,13108]
===
match
---
trailer [8809,8817]
trailer [8838,8846]
===
match
---
simple_stmt [7436,7490]
simple_stmt [7465,7519]
===
match
---
name: path [9821,9825]
name: path [9850,9854]
===
match
---
trailer [14995,15024]
trailer [15024,15053]
===
match
---
operator: , [17340,17341]
operator: , [17369,17370]
===
match
---
suite [17597,19514]
suite [17626,19543]
===
match
---
simple_stmt [18371,18417]
simple_stmt [18400,18446]
===
match
---
atom_expr [6439,6492]
atom_expr [6439,6492]
===
match
---
simple_stmt [16185,16221]
simple_stmt [16214,16250]
===
match
---
operator: = [8148,8149]
operator: = [8177,8178]
===
match
---
name: zip_info [12633,12641]
name: zip_info [12662,12670]
===
match
---
trailer [19417,19427]
trailer [19446,19456]
===
match
---
trailer [5406,5411]
trailer [5406,5411]
===
match
---
operator: } [20185,20186]
operator: } [20214,20215]
===
match
---
name: infolist [12662,12670]
name: infolist [12691,12699]
===
match
---
number: 1 [11269,11270]
number: 1 [11298,11299]
===
match
---
if_stmt [13986,14273]
if_stmt [14015,14302]
===
match
---
name: e [10321,10322]
name: e [10350,10351]
===
match
---
arglist [12135,12167]
arglist [12164,12196]
===
match
---
name: o [14579,14580]
name: o [14608,14609]
===
match
---
trailer [9245,9252]
trailer [9274,9281]
===
match
---
operator: , [12690,12691]
operator: , [12719,12720]
===
match
---
name: DAG [4235,4238]
name: DAG [4235,4238]
===
match
---
name: dag_id [7008,7014]
name: dag_id [7008,7014]
===
match
---
if_stmt [12805,12861]
if_stmt [12834,12890]
===
match
---
name: log [11061,11064]
name: log [11090,11093]
===
match
---
name: sys [13694,13697]
name: sys [13723,13726]
===
match
---
operator: , [23608,23609]
operator: , [23637,23638]
===
match
---
simple_stmt [16504,16528]
simple_stmt [16533,16557]
===
match
---
import_name [954,968]
import_name [954,968]
===
match
---
operator: = [15390,15391]
operator: = [15419,15420]
===
match
---
expr_stmt [4742,4837]
expr_stmt [4742,4837]
===
match
---
simple_stmt [12898,12907]
simple_stmt [12927,12936]
===
match
---
name: self [12963,12967]
name: self [12992,12996]
===
match
---
if_stmt [10861,11151]
if_stmt [10890,11180]
===
match
---
name: stacklevel [5559,5569]
name: stacklevel [5559,5569]
===
match
---
simple_stmt [1496,1531]
simple_stmt [1496,1531]
===
match
---
arglist [13058,13107]
arglist [13087,13136]
===
match
---
name: current_module [13818,13832]
name: current_module [13847,13861]
===
match
---
name: typing [1015,1021]
name: typing [1015,1021]
===
match
---
string: """Add DAG to DagBag from DB""" [8890,8921]
string: """Add DAG to DagBag from DB""" [8919,8950]
===
match
---
trailer [23604,23618]
trailer [23633,23647]
===
match
---
name: airflow [14382,14389]
name: airflow [14411,14418]
===
match
---
param [14325,14334]
param [14354,14363]
===
match
---
name: _serialze_dag_capturing_errors [21550,21580]
name: _serialze_dag_capturing_errors [21579,21609]
===
match
---
operator: = [11361,11362]
operator: = [11390,11391]
===
match
---
fstring [9106,9157]
fstring [9135,9186]
===
match
---
simple_stmt [7175,7338]
simple_stmt [7175,7338]
===
match
---
trailer [11930,11935]
trailer [11959,11964]
===
match
---
operator: = [4411,4412]
operator: = [4411,4412]
===
match
---
operator: = [16600,16601]
operator: = [16629,16630]
===
match
---
name: dagbag_import_error_tracebacks [12193,12223]
name: dagbag_import_error_tracebacks [12222,12252]
===
match
---
string: 'core' [3373,3379]
string: 'core' [3373,3379]
===
match
---
suite [9843,9866]
suite [9872,9895]
===
match
---
atom_expr [23102,23312]
atom_expr [23131,23341]
===
match
---
annassign [1949,1954]
annassign [1949,1954]
===
match
---
operator: , [5055,5056]
operator: , [5055,5056]
===
match
---
trailer [15291,15335]
trailer [15320,15364]
===
match
---
atom_expr [15468,15485]
atom_expr [15497,15514]
===
match
---
name: conf [3436,3440]
name: conf [3436,3440]
===
match
---
string: """         Given a file path or a folder, this method looks for python modules,         imports them and adds them to the dagbag collection.          Note that if a ``.airflowignore`` file is found while processing         the directory, it will behave much like a ``.gitignore``,         ignoring files that match any of the regex patterns specified         in the file.          **Note**: The patterns in .airflowignore are treated as         un-anchored regexes, not shell-like glob patterns.         """ [17606,18114]
string: """         Given a file path or a folder, this method looks for python modules,         imports them and adds them to the dagbag collection.          Note that if a ``.airflowignore`` file is found while processing         the directory, it will behave much like a ``.gitignore``,         ignoring files that match any of the regex patterns specified         in the file.          **Note**: The patterns in .airflowignore are treated as         un-anchored regexes, not shell-like glob patterns.         """ [17635,18143]
===
match
---
trailer [4400,4410]
trailer [4400,4410]
===
match
---
name: filepath [11191,11199]
name: filepath [11220,11228]
===
match
---
trailer [7523,7531]
trailer [7552,7560]
===
match
---
trailer [14922,14961]
trailer [14951,14990]
===
match
---
atom_expr [14539,14564]
atom_expr [14568,14593]
===
match
---
atom_expr [7734,7747]
atom_expr [7763,7776]
===
match
---
trailer [13925,13935]
trailer [13954,13964]
===
match
---
annassign [1967,1972]
annassign [1967,1972]
===
match
---
name: airflow [1320,1327]
name: airflow [1320,1327]
===
match
---
for_stmt [20199,20325]
for_stmt [20228,20354]
===
match
---
fstring_start: f" [15392,15394]
fstring_start: f" [15421,15423]
===
match
---
string: 'collect_db_dags' [19689,19706]
string: 'collect_db_dags' [19718,19735]
===
match
---
name: found_dag [8617,8626]
name: found_dag [8646,8655]
===
match
---
atom_expr [10477,10526]
atom_expr [10506,10555]
===
match
---
atom_expr [13368,13383]
atom_expr [13397,13412]
===
match
---
name: self [10631,10635]
name: self [10660,10664]
===
match
---
trailer [22958,22983]
trailer [22987,23012]
===
match
---
atom_expr [23662,23680]
atom_expr [23691,23709]
===
match
---
name: exec_module [11973,11984]
name: exec_module [12002,12013]
===
match
---
simple_stmt [20713,20753]
simple_stmt [20742,20782]
===
match
---
operator: , [3466,3467]
operator: , [3466,3467]
===
match
---
name: timezone [16203,16211]
name: timezone [16232,16240]
===
match
---
operator: , [18223,18224]
operator: , [18252,18253]
===
match
---
name: session [9037,9044]
name: session [9066,9073]
===
match
---
name: full_filepath [15670,15683]
name: full_filepath [15699,15712]
===
match
---
operator: = [18966,18967]
operator: = [18995,18996]
===
match
---
name: timezone [9344,9352]
name: timezone [9373,9381]
===
match
---
simple_stmt [5348,5390]
simple_stmt [5348,5390]
===
match
---
operator: , [5861,5862]
operator: , [5861,5862]
===
match
---
arglist [7268,7319]
arglist [7268,7319]
===
match
---
arglist [6461,6491]
arglist [6461,6491]
===
match
---
arglist [4796,4836]
arglist [4796,4836]
===
match
---
atom_expr [18735,18816]
atom_expr [18764,18845]
===
match
---
tfpdef [3497,3512]
tfpdef [3497,3512]
===
match
---
name: traceback [12276,12285]
name: traceback [12305,12314]
===
match
---
simple_stmt [10618,10696]
simple_stmt [10647,10725]
===
match
---
operator: = [20769,20770]
operator: = [20798,20799]
===
match
---
name: dag_cycle_tester [1550,1566]
name: dag_cycle_tester [1550,1566]
===
match
---
fstring_expr [9113,9121]
fstring_expr [9142,9150]
===
match
---
name: mods [14525,14529]
name: mods [14554,14558]
===
match
---
atom_expr [5598,5620]
atom_expr [5598,5620]
===
match
---
funcdef [20368,21177]
funcdef [20397,21206]
===
match
---
operator: { [21106,21107]
operator: { [21135,21136]
===
match
---
dotted_name [21481,21510]
dotted_name [21510,21539]
===
match
---
atom_expr [12757,12792]
atom_expr [12786,12821]
===
match
---
name: _load_modules_from_zip [10565,10587]
name: _load_modules_from_zip [10594,10616]
===
match
---
name: log [15627,15630]
name: log [15656,15659]
===
match
---
name: root_dag_id [8150,8161]
name: root_dag_id [8179,8190]
===
match
---
simple_stmt [803,820]
simple_stmt [803,820]
===
match
---
argument [8405,8451]
argument [8434,8480]
===
match
---
simple_stmt [9497,9641]
simple_stmt [9526,9670]
===
match
---
name: self [16681,16685]
name: self [16710,16714]
===
match
---
operator: = [3599,3600]
operator: = [3599,3600]
===
match
---
name: bag_dag [16589,16596]
name: bag_dag [16618,16625]
===
match
---
operator: , [17419,17420]
operator: , [17448,17449]
===
match
---
name: mods [10470,10474]
name: mods [10499,10503]
===
match
---
simple_stmt [16148,16177]
simple_stmt [16177,16206]
===
match
---
import_as_names [1385,1463]
import_as_names [1385,1463]
===
match
---
name: DAG [3740,3743]
name: DAG [3740,3743]
===
match
---
operator: , [3212,3213]
operator: , [3212,3213]
===
match
---
operator: = [4728,4729]
operator: = [4728,4729]
===
match
---
name: CroniterBadCronError [15179,15199]
name: CroniterBadCronError [15208,15228]
===
match
---
comparison [17165,17191]
comparison [17194,17220]
===
match
---
operator: -> [5658,5660]
operator: -> [5658,5660]
===
match
---
arglist [8405,8474]
arglist [8434,8503]
===
match
---
trailer [16689,16695]
trailer [16718,16724]
===
match
---
trailer [12249,12263]
trailer [12278,12292]
===
match
---
trailer [12285,12296]
trailer [12314,12325]
===
match
---
simple_stmt [7503,7532]
simple_stmt [7532,7561]
===
match
---
simple_stmt [5398,5583]
simple_stmt [5398,5583]
===
match
---
trailer [11607,11629]
trailer [11636,11658]
===
match
---
operator: , [8451,8452]
operator: , [8480,8481]
===
match
---
atom_expr [15701,15738]
atom_expr [15730,15767]
===
match
---
name: found_dags [15857,15867]
name: found_dags [15886,15896]
===
match
---
simple_stmt [7931,7992]
simple_stmt [7960,8021]
===
match
---
trailer [16645,16650]
trailer [16674,16679]
===
match
---
name: dag_folder [18405,18415]
name: dag_folder [18434,18444]
===
match
---
simple_stmt [17258,17280]
simple_stmt [17287,17309]
===
match
---
name: conf [3515,3519]
name: conf [3515,3519]
===
match
---
trailer [17171,17178]
trailer [17200,17207]
===
match
---
name: conf [3189,3193]
name: conf [3189,3193]
===
match
---
atom [12565,12567]
atom [12594,12596]
===
match
---
expr_stmt [7611,7621]
expr_stmt [7640,7650]
===
match
---
name: getboolean [17473,17483]
name: getboolean [17502,17512]
===
match
---
name: timedelta [1928,1937]
name: timedelta [1928,1937]
===
match
---
name: self [7436,7440]
name: self [7465,7469]
===
match
---
name: dag [15112,15115]
name: dag [15141,15144]
===
match
---
simple_stmt [16641,16669]
simple_stmt [16670,16698]
===
match
---
operator: , [9470,9471]
operator: , [9499,9500]
===
match
---
name: subdag [16447,16453]
name: subdag [16476,16482]
===
match
---
name: file_parse_end_dttm [19044,19063]
name: file_parse_end_dttm [19073,19092]
===
match
---
name: only_if_updated [8453,8468]
name: only_if_updated [8482,8497]
===
match
---
argument [11631,11656]
argument [11660,11685]
===
match
---
atom_expr [9818,9842]
atom_expr [9847,9871]
===
match
---
trailer [18895,18902]
trailer [18924,18931]
===
match
---
atom_expr [12434,12462]
atom_expr [12463,12491]
===
match
---
name: current_zip_file [13177,13193]
name: current_zip_file [13206,13222]
===
match
---
annassign [1908,1913]
annassign [1908,1913]
===
match
---
operator: , [4721,4722]
operator: , [4721,4722]
===
match
---
atom_expr [7061,7078]
atom_expr [7061,7078]
===
match
---
param [21581,21585]
param [21610,21614]
===
match
---
atom_expr [17165,17178]
atom_expr [17194,17207]
===
match
---
name: multiplier [22813,22823]
name: multiplier [22842,22852]
===
match
---
operator: , [13164,13165]
operator: , [13193,13194]
===
match
---
simple_stmt [954,969]
simple_stmt [954,969]
===
match
---
fstring_expr [21106,21116]
fstring_expr [21135,21145]
===
match
---
atom [12020,12032]
atom [12049,12061]
===
match
---
return_stmt [8680,8704]
return_stmt [8709,8733]
===
match
---
trailer [18191,18236]
trailer [18220,18265]
===
match
---
operator: , [4042,4043]
operator: , [4042,4043]
===
match
---
name: might_contain_dag [1658,1675]
name: might_contain_dag [1658,1675]
===
match
---
import_from [19602,19662]
import_from [19631,19691]
===
match
---
expr_stmt [9229,9262]
expr_stmt [9258,9291]
===
match
---
name: full_filepath [15375,15388]
name: full_filepath [15404,15417]
===
match
---
suite [12099,12472]
suite [12128,12501]
===
match
---
name: self [12522,12526]
name: self [12551,12555]
===
match
---
name: self [23102,23106]
name: self [23131,23135]
===
match
---
operator: , [1656,1657]
operator: , [1656,1657]
===
match
---
name: self [16641,16645]
name: self [16670,16674]
===
match
---
trailer [9311,9329]
trailer [9340,9358]
===
match
---
tfpdef [3575,3598]
tfpdef [3575,3598]
===
match
---
suite [9065,9159]
suite [9094,9188]
===
match
---
simple_stmt [1959,1973]
simple_stmt [1959,1973]
===
match
---
atom_expr [5788,5810]
atom_expr [5788,5810]
===
match
---
operator: { [11380,11381]
operator: { [11409,11410]
===
match
---
suite [23525,23620]
suite [23554,23649]
===
match
---
name: dags_last_fetched [9312,9329]
name: dags_last_fetched [9341,9358]
===
match
---
simple_stmt [11056,11129]
simple_stmt [11085,11158]
===
match
---
simple_stmt [18162,18169]
simple_stmt [18191,18198]
===
match
---
fstring_string: ' not found in serialized_dag table [9121,9156]
fstring_string: ' not found in serialized_dag table [9150,9185]
===
match
---
simple_stmt [1733,1783]
simple_stmt [1733,1783]
===
match
---
atom_expr [14668,14685]
atom_expr [14697,14714]
===
match
---
name: task_policy [16333,16344]
name: task_policy [16362,16373]
===
match
---
name: timedelta [6913,6922]
name: timedelta [6913,6922]
===
match
---
simple_stmt [8680,8705]
simple_stmt [8709,8734]
===
match
---
import_name [847,868]
import_name [847,868]
===
match
---
parameters [5324,5330]
parameters [5324,5330]
===
match
---
trailer [9352,9359]
trailer [9381,9388]
===
match
---
operator: = [10558,10559]
operator: = [10587,10588]
===
match
---
name: self [18735,18739]
name: self [18764,18768]
===
match
---
simple_stmt [9078,9159]
simple_stmt [9107,9188]
===
match
---
name: is_zipfile [10436,10446]
name: is_zipfile [10465,10475]
===
match
---
expr_stmt [3155,3248]
expr_stmt [3155,3248]
===
match
---
operator: = [14608,14609]
operator: = [14637,14638]
===
match
---
trailer [7737,7747]
trailer [7766,7776]
===
match
---
simple_stmt [7695,7719]
simple_stmt [7724,7748]
===
match
---
atom_expr [14046,14074]
atom_expr [14075,14103]
===
match
---
trailer [10727,10737]
trailer [10756,10766]
===
match
---
operator: = [22090,22091]
operator: = [22119,22120]
===
match
---
atom_expr [20210,20228]
atom_expr [20239,20257]
===
match
---
atom_expr [23270,23293]
atom_expr [23299,23322]
===
match
---
name: wait_random_exponential [22789,22812]
name: wait_random_exponential [22818,22841]
===
match
---
operator: = [23689,23690]
operator: = [23718,23719]
===
match
---
parameters [21217,21258]
parameters [21246,21287]
===
match
---
name: log [22964,22967]
name: log [22993,22996]
===
match
---
operator: = [3102,3103]
operator: = [3102,3103]
===
match
---
operator: , [17437,17438]
operator: , [17466,17467]
===
match
---
or_test [8283,8307]
or_test [8312,8336]
===
match
---
name: self [6134,6138]
name: self [6134,6138]
===
match
---
if_stmt [8000,8057]
if_stmt [8029,8086]
===
match
---
atom_expr [9084,9158]
atom_expr [9113,9187]
===
match
---
name: util [11791,11795]
name: util [11820,11824]
===
match
---
name: bag_dag [15877,15884]
name: bag_dag [15906,15913]
===
match
---
name: textwrap [20771,20779]
name: textwrap [20800,20808]
===
match
---
trailer [18130,18148]
trailer [18159,18177]
===
match
---
name: self [19440,19444]
name: self [19469,19473]
===
match
---
arglist [15055,15076]
arglist [15084,15105]
===
match
---
name: conf [1349,1353]
name: conf [1349,1353]
===
match
---
name: self [10219,10223]
name: self [10248,10252]
===
match
---
name: include_examples [5039,5055]
name: include_examples [5039,5055]
===
match
---
simple_stmt [15622,15685]
simple_stmt [15651,15714]
===
match
---
operator: , [22967,22968]
operator: , [22996,22997]
===
match
---
name: file_last_changed [15777,15794]
name: file_last_changed [15806,15823]
===
match
---
trailer [12263,12273]
trailer [12292,12302]
===
match
---
operator: = [16468,16469]
operator: = [16497,16498]
===
match
---
name: debug [16690,16695]
name: debug [16719,16724]
===
match
---
atom_expr [14992,15024]
atom_expr [15021,15053]
===
match
---
suite [9216,9263]
suite [9245,9292]
===
match
---
string: """Information about single file""" [1863,1898]
string: """Information about single file""" [1863,1898]
===
match
---
trailer [17225,17230]
trailer [17254,17259]
===
match
---
atom_expr [3357,3397]
atom_expr [3357,3397]
===
match
---
atom_expr [14459,14487]
atom_expr [14488,14516]
===
match
---
trailer [15370,15389]
trailer [15399,15418]
===
match
---
factor [12328,12369]
factor [12357,12398]
===
match
---
string: 'utf-8' [11322,11329]
string: 'utf-8' [11351,11358]
===
match
---
name: filepath [10447,10455]
name: filepath [10476,10484]
===
match
---
name: dag_id [8722,8728]
name: dag_id [8751,8757]
===
match
---
factor [11268,11270]
factor [11297,11299]
===
match
---
name: splitext [12765,12773]
name: splitext [12794,12802]
===
match
---
atom_expr [11017,11032]
atom_expr [11046,11061]
===
match
---
arglist [18473,18619]
arglist [18502,18648]
===
match
---
name: dag_folder [18245,18255]
name: dag_folder [18274,18284]
===
match
---
name: exc [1192,1195]
name: exc [1192,1195]
===
match
---
atom_expr [15772,15813]
atom_expr [15801,15842]
===
match
---
trailer [13520,13529]
trailer [13549,13558]
===
match
---
string: 'LOAD_EXAMPLES' [3381,3396]
string: 'LOAD_EXAMPLES' [3381,3396]
===
match
---
simple_stmt [9168,9182]
simple_stmt [9197,9211]
===
match
---
simple_stmt [9271,9299]
simple_stmt [9300,9328]
===
match
---
name: dag_id [9389,9395]
name: dag_id [9418,9424]
===
match
---
simple_stmt [820,847]
simple_stmt [820,847]
===
match
---
name: mods [10553,10557]
name: mods [10582,10586]
===
match
---
name: wait [22775,22779]
name: wait [22804,22808]
===
match
---
param [3497,3566]
param [3497,3566]
===
match
---
atom_expr [15273,15335]
atom_expr [15302,15364]
===
match
---
operator: = [20619,20620]
operator: = [20648,20649]
===
match
---
trailer [22396,22445]
trailer [22425,22474]
===
match
---
trailer [14086,14097]
trailer [14115,14126]
===
match
---
trailer [16098,16103]
trailer [16127,16132]
===
match
---
name: AirflowDagCycleException [15535,15559]
name: AirflowDagCycleException [15564,15588]
===
match
---
dotted_name [1738,1759]
dotted_name [1738,1759]
===
match
---
string: "The store_serialized_dags parameter has been deprecated. " [3850,3909]
string: "The store_serialized_dags parameter has been deprecated. " [3850,3909]
===
match
---
decorator [5626,5636]
decorator [5626,5636]
===
match
---
atom_expr [23641,23698]
atom_expr [23670,23727]
===
match
---
operator: , [3606,3607]
operator: , [3606,3607]
===
match
---
atom_expr [23997,24019]
atom_expr [24026,24048]
===
match
---
simple_stmt [10368,10390]
simple_stmt [10397,10419]
===
match
---
name: safe_mode [18796,18805]
name: safe_mode [18825,18834]
===
match
---
argument [22920,22983]
argument [22949,23012]
===
match
---
name: self [17221,17225]
name: self [17250,17254]
===
match
---
atom_expr [15042,15077]
atom_expr [15071,15106]
===
match
---
comparison [17086,17101]
comparison [17115,17130]
===
match
---
trailer [12967,12971]
trailer [12996,13000]
===
match
---
name: is_expired [8187,8197]
name: is_expired [8216,8226]
===
match
---
name: log [16686,16689]
name: log [16715,16718]
===
match
---
arglist [15292,15334]
arglist [15321,15363]
===
match
---
atom_expr [15795,15812]
atom_expr [15824,15841]
===
match
---
name: FileLoadStat [1833,1845]
name: FileLoadStat [1833,1845]
===
match
---
simple_stmt [21476,21537]
simple_stmt [21505,21566]
===
match
---
name: tenacity [22933,22941]
name: tenacity [22962,22970]
===
match
---
simple_stmt [1676,1733]
simple_stmt [1676,1733]
===
match
---
if_stmt [8588,8781]
if_stmt [8617,8810]
===
match
---
name: correct_maybe_zipped [1616,1636]
name: correct_maybe_zipped [1616,1636]
===
match
---
trailer [16373,16381]
trailer [16402,16410]
===
match
---
trailer [13155,13164]
trailer [13184,13193]
===
match
---
for_stmt [16408,16628]
for_stmt [16437,16657]
===
match
---
name: root_dag_id [7962,7973]
name: root_dag_id [7991,8002]
===
match
---
atom_expr [14130,14170]
atom_expr [14159,14199]
===
match
---
atom_expr [12774,12791]
atom_expr [12803,12820]
===
match
---
operator: -> [5175,5177]
operator: -> [5175,5177]
===
match
---
trailer [23110,23116]
trailer [23139,23145]
===
match
---
suite [8308,8781]
suite [8337,8810]
===
match
---
operator: , [17519,17520]
operator: , [17548,17549]
===
match
---
operator: = [11504,11505]
operator: = [11533,11534]
===
match
---
return_stmt [8028,8056]
return_stmt [8057,8085]
===
match
---
atom_expr [5265,5279]
atom_expr [5265,5279]
===
match
---
operator: = [11291,11292]
operator: = [11320,11321]
===
match
---
atom_expr [12465,12471]
atom_expr [12494,12500]
===
match
---
trailer [14554,14561]
trailer [14583,14590]
===
match
---
atom_expr [16681,16717]
atom_expr [16710,16746]
===
match
---
trailer [14991,15025]
trailer [15020,15054]
===
match
---
number: 0.5 [22824,22827]
number: 0.5 [22853,22856]
===
match
---
operator: = [14457,14458]
operator: = [14486,14487]
===
match
---
name: bool [3508,3512]
name: bool [3508,3512]
===
match
---
name: dags [17187,17191]
name: dags [17216,17220]
===
match
---
testlist_comp [12820,12833]
testlist_comp [12849,12862]
===
match
---
name: self [17311,17315]
name: self [17340,17344]
===
match
---
name: self [7701,7705]
name: self [7730,7734]
===
match
---
not_test [14664,14685]
not_test [14693,14714]
===
match
---
simple_stmt [969,1010]
simple_stmt [969,1010]
===
match
---
name: dags [6521,6525]
name: dags [6521,6525]
===
match
---
operator: = [5880,5881]
operator: = [5880,5881]
===
match
---
name: conf [4889,4893]
name: conf [4889,4893]
===
match
---
name: settings [1306,1314]
name: settings [1306,1314]
===
match
---
name: _load_modules_from_file [10801,10824]
name: _load_modules_from_file [10830,10853]
===
match
---
name: subdag [16544,16550]
name: subdag [16573,16579]
===
match
---
atom [10409,10411]
atom [10438,10440]
===
match
---
atom_expr [22363,22374]
atom_expr [22392,22403]
===
match
---
trailer [3758,3760]
trailer [3758,3760]
===
match
---
expr_stmt [20493,20521]
expr_stmt [20522,20550]
===
match
---
name: filepath [11535,11543]
name: filepath [11564,11572]
===
match
---
name: dag_id [8773,8779]
name: dag_id [8802,8808]
===
match
---
trailer [20353,20362]
trailer [20382,20391]
===
match
---
simple_stmt [6881,6975]
simple_stmt [6881,6975]
===
match
---
name: import_errors [12439,12452]
name: import_errors [12468,12481]
===
match
---
decorator [21182,21199]
decorator [21211,21228]
===
match
---
operator: , [1440,1441]
operator: , [1440,1441]
===
match
---
name: self [15273,15277]
name: self [15302,15306]
===
match
---
name: serialized_dag [21496,21510]
name: serialized_dag [21525,21539]
===
match
---
name: exception [12125,12134]
name: exception [12154,12163]
===
match
---
return_stmt [10774,10791]
return_stmt [10803,10820]
===
match
---
string: 'smart_sensor' [3452,3466]
string: 'smart_sensor' [3452,3466]
===
match
---
argument [22829,22834]
argument [22858,22863]
===
match
---
string: 'core' [4901,4907]
string: 'core' [4901,4907]
===
match
---
name: self [20210,20214]
name: self [20239,20243]
===
match
---
name: filepath [14829,14837]
name: filepath [14858,14866]
===
match
---
name: filepath [11748,11756]
name: filepath [11777,11785]
===
match
---
name: Dict [4396,4400]
name: Dict [4396,4400]
===
match
---
name: self [10560,10564]
name: self [10589,10593]
===
match
---
name: dag_num [19113,19120]
name: dag_num [19142,19149]
===
match
---
if_stmt [11417,11483]
if_stmt [11446,11512]
===
match
---
name: subdag [16504,16510]
name: subdag [16533,16539]
===
match
---
string: 'USE_SMART_SENSOR' [3468,3486]
string: 'USE_SMART_SENSOR' [3468,3486]
===
match
---
name: self [15772,15776]
name: self [15801,15805]
===
match
---
parameters [5168,5174]
parameters [5168,5174]
===
match
---
operator: = [4088,4089]
operator: = [4088,4089]
===
match
---
atom_expr [13989,14024]
atom_expr [14018,14053]
===
match
---
string: ".pyc" [12827,12833]
string: ".pyc" [12856,12862]
===
match
---
name: collect_dags_from_db [19523,19543]
name: collect_dags_from_db [19552,19572]
===
match
---
name: exception [15631,15640]
name: exception [15660,15669]
===
match
---
simple_stmt [1255,1285]
simple_stmt [1255,1285]
===
match
---
name: duration [1918,1926]
name: duration [1918,1926]
===
match
---
expr_stmt [20530,20602]
expr_stmt [20559,20631]
===
match
---
expr_stmt [13739,13789]
expr_stmt [13768,13818]
===
match
---
name: debug [13052,13057]
name: debug [13081,13086]
===
match
---
name: sys [901,904]
name: sys [901,904]
===
match
---
import_from [6266,6326]
import_from [6266,6326]
===
match
---
name: mod_name [11738,11746]
name: mod_name [11767,11775]
===
match
---
suite [18149,18169]
suite [18178,18198]
===
match
---
suite [11675,12033]
suite [11704,12062]
===
match
---
atom_expr [9271,9292]
atom_expr [9300,9321]
===
match
---
name: warnings [5398,5406]
name: warnings [5398,5406]
===
match
---
atom_expr [11432,11443]
atom_expr [11461,11472]
===
match
---
operator: , [15889,15890]
operator: , [15918,15919]
===
match
---
trailer [16650,16662]
trailer [16679,16691]
===
match
---
fstring_end: " [15427,15428]
fstring_end: " [15456,15457]
===
match
---
trailer [11891,11897]
trailer [11920,11926]
===
match
---
trailer [15054,15077]
trailer [15083,15106]
===
match
---
trailer [14543,14564]
trailer [14572,14593]
===
match
---
name: dag [7734,7737]
name: dag [7763,7766]
===
match
---
name: e [14270,14271]
name: e [14299,14300]
===
match
---
import_name [788,802]
import_name [788,802]
===
match
---
trailer [17483,17519]
trailer [17512,17548]
===
match
---
simple_stmt [12576,12621]
simple_stmt [12605,12650]
===
match
---
atom_expr [16255,16279]
atom_expr [16284,16308]
===
match
---
atom_expr [11160,11200]
atom_expr [11189,11229]
===
match
---
trailer [12661,12670]
trailer [12690,12699]
===
match
---
trailer [23522,23524]
trailer [23551,23553]
===
match
---
trailer [14050,14064]
trailer [14079,14093]
===
match
---
operator: , [23680,23681]
operator: , [23709,23710]
===
match
---
trailer [20678,20687]
trailer [20707,20716]
===
match
---
operator: = [18805,18806]
operator: = [18834,18835]
===
match
---
trailer [19734,19773]
trailer [19763,19802]
===
match
---
name: top_level_dags [14633,14647]
name: top_level_dags [14662,14676]
===
match
---
operator: = [17396,17397]
operator: = [17425,17426]
===
match
---
name: stats [18351,18356]
name: stats [18380,18385]
===
match
---
name: dag [16185,16188]
name: dag [16214,16217]
===
match
---
expr_stmt [9370,9411]
expr_stmt [9399,9440]
===
match
---
return_stmt [14281,14292]
return_stmt [14310,14321]
===
match
---
if_stmt [6987,7490]
if_stmt [6987,7519]
===
match
---
subscriptlist [4230,4238]
subscriptlist [4230,4238]
===
match
---
arglist [18962,19285]
arglist [18991,19314]
===
match
---
param [9472,9486]
param [9501,9515]
===
match
---
name: dags_last_fetched [4558,4575]
name: dags_last_fetched [4558,4575]
===
match
---
operator: , [18516,18517]
operator: , [18545,18546]
===
match
---
name: dag_folder [4182,4192]
name: dag_folder [4182,4192]
===
match
---
param [3616,3661]
param [3616,3661]
===
match
---
trailer [20219,20226]
trailer [20248,20255]
===
match
---
suite [18630,19431]
suite [18659,19460]
===
match
---
simple_stmt [12013,12033]
simple_stmt [12042,12062]
===
match
---
trailer [14134,14170]
trailer [14163,14199]
===
match
---
name: dag [15666,15669]
name: dag [15695,15698]
===
match
---
param [9440,9449]
param [9469,9478]
===
match
---
simple_stmt [7611,7622]
simple_stmt [7640,7651]
===
match
---
operator: , [19498,19499]
operator: , [19527,19528]
===
match
---
atom_expr [10560,10608]
atom_expr [10589,10637]
===
match
---
simple_stmt [10774,10792]
simple_stmt [10803,10821]
===
match
---
name: new_module [11847,11857]
name: new_module [11876,11886]
===
match
---
name: fileloc [14755,14762]
name: fileloc [14784,14791]
===
match
---
name: utcnow [16212,16218]
name: utcnow [16241,16247]
===
match
---
dotted_name [1590,1608]
dotted_name [1590,1608]
===
match
---
name: self [15622,15626]
name: self [15651,15655]
===
match
---
trailer [5665,5670]
trailer [5665,5670]
===
match
---
param [21218,21223]
param [21247,21252]
===
match
---
atom_expr [13806,13833]
atom_expr [13835,13862]
===
match
---
trailer [23333,23337]
trailer [23362,23366]
===
match
---
fstring_expr [21066,21076]
fstring_expr [21095,21105]
===
match
---
trailer [23989,23996]
trailer [24018,24025]
===
match
---
name: stats [20459,20464]
name: stats [20488,20493]
===
match
---
name: os [12757,12759]
name: os [12786,12788]
===
match
---
trailer [15630,15640]
trailer [15659,15669]
===
match
---
expr_stmt [20174,20186]
expr_stmt [20203,20215]
===
match
---
simple_stmt [938,954]
simple_stmt [938,954]
===
match
---
name: task_num [20679,20687]
name: task_num [20708,20716]
===
match
---
operator: } [4600,4601]
operator: } [4600,4601]
===
match
---
operator: { [9113,9114]
operator: { [9142,9143]
===
match
---
operator: == [10216,10218]
operator: == [10245,10247]
===
match
---
operator: , [3124,3125]
operator: , [3124,3125]
===
match
---
operator: , [17498,17499]
operator: , [17527,17528]
===
match
---
if_stmt [21826,21870]
if_stmt [21855,21899]
===
match
---
name: full_filepath [16474,16487]
name: full_filepath [16503,16516]
===
match
---
operator: , [10829,10830]
operator: , [10858,10859]
===
match
---
trailer [3647,3653]
trailer [3647,3653]
===
match
---
name: o [20640,20641]
name: o [20669,20670]
===
match
---
name: traceback [14077,14086]
name: traceback [14106,14115]
===
match
---
simple_stmt [19602,19663]
simple_stmt [19631,19692]
===
match
---
name: path [11230,11234]
name: path [11259,11263]
===
match
---
name: dag [14992,14995]
name: dag [15021,15024]
===
match
---
return_stmt [10402,10411]
return_stmt [10431,10440]
===
match
---
operator: = [7777,7778]
operator: = [7806,7807]
===
match
---
trailer [16218,16220]
trailer [16247,16249]
===
match
---
name: is_subdag [14875,14884]
name: is_subdag [14904,14913]
===
match
---
trailer [16263,16274]
trailer [16292,16303]
===
match
---
import_name [884,893]
import_name [884,893]
===
match
---
name: DeprecationWarning [3994,4012]
name: DeprecationWarning [3994,4012]
===
match
---
simple_stmt [3155,3249]
simple_stmt [3155,3249]
===
match
---
string: "Found __init__.%s at root of %s" [12980,13013]
string: "Found __init__.%s at root of %s" [13009,13042]
===
match
---
trailer [11060,11064]
trailer [11089,11093]
===
match
---
simple_stmt [8890,8922]
simple_stmt [8919,8951]
===
match
---
operator: = [23004,23005]
operator: = [23033,23034]
===
match
---
name: OperationalError [22744,22760]
name: OperationalError [22773,22789]
===
match
---
name: dagbag_import_error_traceback_depth [4851,4886]
name: dagbag_import_error_traceback_depth [4851,4886]
===
match
---
trailer [20214,20219]
trailer [20243,20248]
===
match
---
operator: , [18618,18619]
operator: , [18647,18648]
===
match
---
name: store_serialized_dags [4090,4111]
name: store_serialized_dags [4090,4111]
===
match
---
trailer [11464,11472]
trailer [11493,11501]
===
match
---
dotted_name [1469,1482]
dotted_name [1469,1482]
===
match
---
operator: = [3187,3188]
operator: = [3187,3188]
===
match
---
atom_expr [22882,22905]
atom_expr [22911,22934]
===
match
---
operator: { [20184,20185]
operator: { [20213,20214]
===
match
---
trailer [8039,8044]
trailer [8068,8073]
===
match
---
name: report [21170,21176]
name: report [21199,21205]
===
match
---
arglist [16597,16626]
arglist [16626,16655]
===
match
---
annassign [4223,4244]
annassign [4223,4244]
===
match
---
atom_expr [11227,11272]
atom_expr [11256,11301]
===
match
---
name: sqlalchemy [1181,1191]
name: sqlalchemy [1181,1191]
===
match
---
name: root_dag [16609,16617]
name: root_dag [16638,16646]
===
match
---
param [21586,21593]
param [21615,21622]
===
match
---
string: 'DAG_DISCOVERY_SAFE_MODE' [3539,3564]
string: 'DAG_DISCOVERY_SAFE_MODE' [3539,3564]
===
match
---
simple_stmt [20401,20451]
simple_stmt [20430,20480]
===
match
---
trailer [11812,11830]
trailer [11841,11859]
===
match
---
atom [10290,10292]
atom [10319,10321]
===
match
---
name: self [5598,5602]
name: self [5598,5602]
===
match
---
name: process_file [9421,9433]
name: process_file [9450,9462]
===
match
---
operator: = [11858,11859]
operator: = [11887,11888]
===
match
---
suite [11444,11483]
suite [11473,11512]
===
match
---
tfpdef [5863,5879]
tfpdef [5863,5879]
===
match
---
fstring_string:           [21132,21141]
fstring_string:           [21161,21170]
===
match
---
operator: } [4243,4244]
operator: } [4243,4244]
===
match
---
name: mods [10663,10667]
name: mods [10692,10696]
===
match
---
string: "The store_serialized_dags property has been deprecated. Use read_dags_from_db instead." [5425,5513]
string: "The store_serialized_dags property has been deprecated. Use read_dags_from_db instead." [5425,5513]
===
match
---
trailer [24001,24019]
trailer [24030,24048]
===
match
---
operator: { [4365,4366]
operator: { [4365,4366]
===
match
---
trailer [23278,23293]
trailer [23307,23322]
===
match
---
simple_stmt [8759,8781]
simple_stmt [8788,8810]
===
match
---
arglist [18192,18235]
arglist [18221,18264]
===
match
---
name: full_filepath [16454,16467]
name: full_filepath [16483,16496]
===
match
---
name: has_logged [11022,11032]
name: has_logged [11051,11061]
===
match
---
operator: , [9035,9036]
operator: , [9064,9065]
===
match
---
trailer [10241,10251]
trailer [10270,10280]
===
match
---
suite [14854,15159]
suite [14883,15188]
===
match
---
name: settings [23270,23278]
name: settings [23299,23307]
===
match
---
expr_stmt [11017,11039]
expr_stmt [11046,11068]
===
match
---
name: root_dag [15896,15904]
name: root_dag [15925,15933]
===
match
---
name: read_dags_from_db [4070,4087]
name: read_dags_from_db [4070,4087]
===
match
---
operator: , [16607,16608]
operator: , [16636,16637]
===
match
---
atom_expr [18890,19325]
atom_expr [18919,19354]
===
match
---
name: dagbag_stats [19445,19457]
name: dagbag_stats [19474,19486]
===
match
---
name: filepath [8405,8413]
name: filepath [8434,8442]
===
match
---
operator: , [5008,5009]
operator: , [5008,5009]
===
match
---
trailer [15150,15158]
trailer [15179,15187]
===
match
---
expr_stmt [11352,11407]
expr_stmt [11381,11436]
===
match
---
fstring_end: " [9156,9157]
fstring_end: " [9185,9186]
===
match
---
name: get [8045,8048]
name: get [8074,8077]
===
match
---
expr_stmt [15772,15841]
expr_stmt [15801,15870]
===
match
---
trailer [11972,11984]
trailer [12001,12013]
===
match
---
arglist [7458,7488]
arglist [7487,7517]
===
match
---
import_from [1676,1732]
import_from [1676,1732]
===
match
---
atom_expr [20626,20635]
atom_expr [20655,20664]
===
match
---
name: dags_last_fetched [7023,7040]
name: dags_last_fetched [7023,7040]
===
match
---
operator: , [3379,3380]
operator: , [3379,3380]
===
match
---
operator: , [18483,18484]
operator: , [18512,18513]
===
match
---
for_stmt [16289,16351]
for_stmt [16318,16380]
===
match
---
operator: , [4585,4586]
operator: , [4585,4586]
===
match
---
name: os [11227,11229]
name: os [11256,11258]
===
match
---
trailer [11300,11305]
trailer [11329,11334]
===
match
---
operator: , [3280,3281]
operator: , [3280,3281]
===
match
---
string: 'dagbag_import_error_tracebacks' [4804,4836]
string: 'dagbag_import_error_tracebacks' [4804,4836]
===
match
---
name: dag_folder [20511,20521]
name: dag_folder [20540,20550]
===
match
---
simple_stmt [15850,15868]
simple_stmt [15879,15897]
===
match
---
name: info [18187,18191]
name: info [18216,18220]
===
match
---
name: file_parse_start_dttm [18664,18685]
name: file_parse_start_dttm [18693,18714]
===
match
---
simple_stmt [9229,9263]
simple_stmt [9258,9292]
===
match
---
name: rollback [23768,23776]
name: rollback [23797,23805]
===
match
---
string: 'core' [4796,4802]
string: 'core' [4796,4802]
===
match
---
name: mods [13806,13810]
name: mods [13835,13839]
===
match
---
trailer [4701,4711]
trailer [4701,4711]
===
match
---
trailer [20346,20353]
trailer [20375,20382]
===
match
---
string: """Save attributes about list of DAG to the DB.""" [21268,21318]
string: """Save attributes about list of DAG to the DB.""" [21297,21347]
===
match
---
atom_expr [4889,4947]
atom_expr [4889,4947]
===
match
---
name: found_dags [8651,8661]
name: found_dags [8680,8690]
===
match
---
string: 'core' [17555,17561]
string: 'core' [17584,17590]
===
match
---
name: session [22156,22163]
name: session [22185,22192]
===
match
---
if_stmt [10977,11129]
if_stmt [11006,11158]
===
match
---
name: airflow [1738,1745]
name: airflow [1738,1745]
===
match
---
simple_stmt [5591,5621]
simple_stmt [5591,5621]
===
match
---
strings [3850,3976]
strings [3850,3976]
===
match
---
try_stmt [9875,10412]
try_stmt [9904,10441]
===
match
---
param [5863,5886]
param [5863,5886]
===
match
---
expr_stmt [16185,16220]
expr_stmt [16214,16249]
===
match
---
operator: , [1414,1415]
operator: , [1414,1415]
===
match
---
name: stats [20730,20735]
name: stats [20759,20764]
===
match
---
simple_stmt [19409,19431]
simple_stmt [19438,19460]
===
match
---
funcdef [5640,5811]
funcdef [5640,5811]
===
match
---
trailer [4717,4727]
trailer [4717,4727]
===
match
---
comparison [12808,12834]
comparison [12837,12863]
===
match
---
name: filepath [14065,14073]
name: filepath [14094,14102]
===
match
---
operator: = [3434,3435]
operator: = [3434,3435]
===
match
---
trailer [14466,14477]
trailer [14495,14506]
===
match
---
simple_stmt [18664,18706]
simple_stmt [18693,18735]
===
match
---
trailer [22976,22982]
trailer [23005,23011]
===
match
---
simple_stmt [4319,4368]
simple_stmt [4319,4368]
===
match
---
simple_stmt [847,869]
simple_stmt [847,869]
===
match
---
import_from [1354,1463]
import_from [1354,1463]
===
match
---
trailer [15640,15684]
trailer [15669,15713]
===
match
---
param [3332,3398]
param [3332,3398]
===
match
---
atom_expr [16148,16176]
atom_expr [16177,16205]
===
match
---
suite [20272,20325]
suite [20301,20354]
===
match
---
name: _add_dag_from_db [7441,7457]
name: _add_dag_from_db [7470,7486]
===
match
---
name: datetime [10015,10023]
name: datetime [10044,10052]
===
match
---
name: timeout [11595,11602]
name: timeout [11624,11631]
===
match
---
operator: , [1120,1121]
operator: , [1120,1121]
===
match
---
trailer [7961,7991]
trailer [7990,8020]
===
match
---
name: safe_mode [17529,17538]
name: safe_mode [17558,17567]
===
match
---
name: store_serialized_dags [3616,3637]
name: store_serialized_dags [3616,3637]
===
match
---
trailer [12971,12979]
trailer [13000,13008]
===
match
---
param [3575,3607]
param [3575,3607]
===
match
---
operator: = [7200,7201]
operator: = [7200,7201]
===
match
---
name: dag [14668,14671]
name: dag [14697,14700]
===
match
---
simple_stmt [11847,11898]
simple_stmt [11876,11927]
===
match
---
trailer [3117,3150]
trailer [3117,3150]
===
match
---
name: filepath [13960,13968]
name: filepath [13989,13997]
===
match
---
testlist_comp [19250,19282]
testlist_comp [19279,19311]
===
match
---
name: sys [11461,11464]
name: sys [11490,11493]
===
match
---
expr_stmt [11692,11757]
expr_stmt [11721,11786]
===
match
---
with_stmt [11590,12472]
with_stmt [11619,12501]
===
match
---
suite [14686,14838]
suite [14715,14867]
===
match
---
atom_expr [12329,12369]
atom_expr [12358,12398]
===
match
---
trailer [19248,19284]
trailer [19277,19313]
===
match
---
name: include_examples [5022,5038]
name: include_examples [5022,5038]
===
match
---
trailer [19179,19190]
trailer [19208,19219]
===
match
---
operator: = [17365,17366]
operator: = [17394,17395]
===
match
---
trailer [9275,9280]
trailer [9304,9309]
===
match
---
name: orm_dag [8007,8014]
name: orm_dag [8036,8043]
===
match
---
name: file_last_changed_on_disk [10190,10215]
name: file_last_changed_on_disk [10219,10244]
===
match
---
name: dag [19195,19198]
name: dag [19224,19227]
===
match
---
simple_stmt [21860,21870]
simple_stmt [21889,21899]
===
match
---
simple_stmt [21996,22191]
simple_stmt [22025,22220]
===
match
---
name: serialize_errors [24002,24018]
name: serialize_errors [24031,24047]
===
match
---
number: 2 [5570,5571]
number: 2 [5570,5571]
===
match
---
operator: = [4479,4480]
operator: = [4479,4480]
===
match
---
name: mod_name [13780,13788]
name: mod_name [13809,13817]
===
match
---
string: "Failed to bag_dag: %s" [15641,15664]
string: "Failed to bag_dag: %s" [15670,15693]
===
match
---
name: task_num [20661,20669]
name: task_num [20690,20698]
===
match
---
name: mod_name [13650,13658]
name: mod_name [13679,13687]
===
match
---
name: import_errors [23976,23989]
name: import_errors [24005,24018]
===
match
---
trailer [11720,11737]
trailer [11749,11766]
===
match
---
name: new_module [11985,11995]
name: new_module [12014,12024]
===
match
---
name: Exception [13853,13862]
name: Exception [13882,13891]
===
match
---
operator: } [11578,11579]
operator: } [11607,11608]
===
match
---
name: AirflowDagCycleException [16733,16757]
name: AirflowDagCycleException [16762,16786]
===
match
---
string: 'USE_SMART_SENSOR' [17500,17518]
string: 'USE_SMART_SENSOR' [17529,17547]
===
match
---
name: self [20386,20390]
name: self [20415,20419]
===
match
---
atom_expr [22695,22761]
atom_expr [22724,22790]
===
match
---
name: str [4401,4404]
name: str [4401,4404]
===
match
---
simple_stmt [23329,23386]
simple_stmt [23358,23415]
===
match
---
trailer [22963,22967]
trailer [22992,22996]
===
match
---
name: fromtimestamp [10024,10037]
name: fromtimestamp [10053,10066]
===
match
---
name: getint [3194,3200]
name: getint [3194,3200]
===
match
---
suite [18647,19326]
suite [18676,19355]
===
match
---
name: dag_folder [4134,4144]
name: dag_folder [4134,4144]
===
match
---
suite [16777,17280]
suite [16806,17309]
===
match
---
import_from [14377,14411]
import_from [14406,14440]
===
match
---
operator: , [11746,11747]
operator: , [11775,11776]
===
match
---
operator: = [11779,11780]
operator: = [11808,11809]
===
match
---
operator: , [3322,3323]
operator: , [3322,3323]
===
match
---
annassign [4711,4732]
annassign [4711,4732]
===
match
---
operator: , [6474,6475]
operator: , [6474,6475]
===
match
---
simple_stmt [1977,1987]
simple_stmt [1977,1987]
===
match
---
name: int [5178,5181]
name: int [5178,5181]
===
match
---
funcdef [14298,15868]
funcdef [14327,15897]
===
match
---
name: attempt [23039,23046]
name: attempt [23068,23075]
===
match
---
atom_expr [20672,20704]
atom_expr [20701,20733]
===
match
---
operator: , [13711,13712]
operator: , [13740,13741]
===
match
---
name: might_contain_dag [13129,13146]
name: might_contain_dag [13158,13175]
===
match
---
simple_stmt [14496,14588]
simple_stmt [14525,14617]
===
match
---
operator: = [16617,16618]
operator: = [16646,16647]
===
match
---
operator: , [3397,3398]
operator: , [3397,3398]
===
match
---
dotted_name [1788,1809]
dotted_name [1788,1809]
===
match
---
param [12528,12537]
param [12557,12566]
===
match
---
import_from [1783,1824]
import_from [1783,1824]
===
match
---
simple_stmt [16681,16718]
simple_stmt [16710,16747]
===
match
---
testlist_star_expr [12741,12754]
testlist_star_expr [12770,12783]
===
match
---
trailer [20729,20752]
trailer [20758,20781]
===
match
---
name: only_if_updated [10099,10114]
name: only_if_updated [10128,10143]
===
match
---
name: self [13411,13415]
name: self [13440,13444]
===
match
---
name: Optional [3302,3310]
name: Optional [3302,3310]
===
match
---
funcdef [10797,12490]
funcdef [10826,12519]
===
match
---
operator: = [12563,12564]
operator: = [12592,12593]
===
match
---
name: before_sleep [22920,22932]
name: before_sleep [22949,22961]
===
match
---
name: is_zipfile [14783,14793]
name: is_zipfile [14812,14822]
===
match
---
argument [16609,16626]
argument [16638,16655]
===
match
---
simple_stmt [12686,12729]
simple_stmt [12715,12758]
===
match
---
name: sd_last_updated_datetime [7175,7199]
name: sd_last_updated_datetime [7175,7199]
===
match
---
try_stmt [11671,12472]
try_stmt [11700,12501]
===
match
---
simple_stmt [7630,7651]
simple_stmt [7659,7680]
===
match
---
suite [2016,24021]
suite [2016,24050]
===
match
---
operator: , [4351,4352]
operator: , [4351,4352]
===
match
---
simple_stmt [14046,14193]
simple_stmt [14075,14222]
===
match
---
parameters [9433,9487]
parameters [9462,9516]
===
match
---
sync_comp_for [19191,19212]
sync_comp_for [19220,19241]
===
match
---
fstring_string: _ [11391,11392]
fstring_string: _ [11420,11421]
===
match
---
trailer [18404,18416]
trailer [18433,18445]
===
match
---
trailer [16596,16627]
trailer [16625,16656]
===
match
---
name: str [4723,4726]
name: str [4723,4726]
===
match
---
operator: = [4997,4998]
operator: = [4997,4998]
===
match
---
atom_expr [3515,3565]
atom_expr [3515,3565]
===
match
---
trailer [4900,4947]
trailer [4900,4947]
===
match
---
del_stmt [13634,13659]
del_stmt [13663,13688]
===
match
---
name: Exception [10308,10317]
name: Exception [10337,10346]
===
match
---
name: SerializedDagModel [21518,21536]
name: SerializedDagModel [21547,21565]
===
match
---
name: dag [23605,23608]
name: dag [23634,23637]
===
match
---
operator: = [17335,17336]
operator: = [17364,17365]
===
match
---
operator: = [19244,19245]
operator: = [19273,19274]
===
match
---
name: self [7672,7676]
name: self [7701,7705]
===
match
---
comparison [8150,8178]
comparison [8179,8207]
===
match
---
name: get_last_updated_datetime [7221,7246]
name: get_last_updated_datetime [7221,7246]
===
match
---
name: filepath [10506,10514]
name: filepath [10535,10543]
===
match
---
operator: @ [5285,5286]
operator: @ [5285,5286]
===
match
---
atom_expr [4214,4223]
atom_expr [4214,4223]
===
match
---
simple_stmt [12480,12490]
simple_stmt [12509,12519]
===
match
---
comparison [8722,8741]
comparison [8751,8770]
===
match
---
comparison [10135,10169]
comparison [10164,10198]
===
match
---
operator: , [12749,12750]
operator: , [12778,12779]
===
match
---
name: log [19414,19417]
name: log [19443,19446]
===
match
---
trailer [12670,12672]
trailer [12699,12701]
===
match
---
arglist [16696,16716]
arglist [16725,16745]
===
match
---
suite [10355,10412]
suite [10384,10441]
===
match
---
name: values [23672,23678]
name: values [23701,23707]
===
match
---
name: self [10705,10709]
name: self [10734,10738]
===
match
---
name: correct_maybe_zipped [18384,18404]
name: correct_maybe_zipped [18413,18433]
===
match
---
simple_stmt [20337,20363]
simple_stmt [20366,20392]
===
match
---
expr_stmt [16641,16668]
expr_stmt [16670,16697]
===
match
---
if_stmt [12920,13030]
if_stmt [12949,13059]
===
match
---
name: DagModel [6113,6121]
name: DagModel [6113,6121]
===
match
---
operator: = [5133,5134]
operator: = [5133,5134]
===
match
---
atom_expr [13756,13789]
atom_expr [13785,13818]
===
match
---
testlist_comp [19176,19212]
testlist_comp [19205,19241]
===
match
---
import_name [869,883]
import_name [869,883]
===
match
---
expr_stmt [20661,20704]
expr_stmt [20690,20733]
===
match
---
name: SerializedDagModel [19644,19662]
name: SerializedDagModel [19673,19691]
===
match
---
name: self [15701,15705]
name: self [15730,15734]
===
match
---
name: conf [3357,3361]
name: conf [3357,3361]
===
match
---
atom [20625,20651]
atom [20654,20680]
===
match
---
trailer [11331,11341]
trailer [11360,11370]
===
match
---
atom_expr [11552,11578]
atom_expr [11581,11607]
===
match
---
trailer [7514,7519]
trailer [7543,7548]
===
match
---
simple_stmt [4553,4602]
simple_stmt [4553,4602]
===
match
---
trailer [12773,12792]
trailer [12802,12821]
===
match
---
name: airflow [6271,6278]
name: airflow [6271,6278]
===
match
---
arglist [3850,4043]
arglist [3850,4043]
===
match
---
name: zip_info [13512,13520]
name: zip_info [13541,13549]
===
match
---
name: self [19721,19725]
name: self [19750,19754]
===
match
---
name: full_filepath [15724,15737]
name: full_filepath [15753,15766]
===
match
---
name: dags [5274,5278]
name: dags [5274,5278]
===
match
---
atom_expr [4225,4239]
atom_expr [4225,4239]
===
match
---
simple_stmt [21163,21177]
simple_stmt [21192,21206]
===
match
---
operator: != [14763,14765]
operator: != [14792,14794]
===
match
---
operator: = [20316,20317]
operator: = [20345,20346]
===
match
---
atom_expr [18384,18416]
atom_expr [18413,18445]
===
match
---
name: self [23506,23510]
name: self [23535,23539]
===
match
---
trailer [17412,17437]
trailer [17441,17466]
===
match
---
simple_stmt [13634,13660]
simple_stmt [13663,13689]
===
match
---
operator: = [20504,20505]
operator: = [20533,20534]
===
match
---
name: e [12469,12470]
name: e [12498,12499]
===
match
---
name: dags [20342,20346]
name: dags [20371,20375]
===
match
---
atom [4599,4601]
atom [4599,4601]
===
match
---
simple_stmt [14703,14732]
simple_stmt [14732,14761]
===
match
---
simple_stmt [12434,12472]
simple_stmt [12463,12501]
===
match
---
name: filepath [14254,14262]
name: filepath [14283,14291]
===
match
---
suite [23021,24021]
suite [23050,24050]
===
match
---
name: AirflowClusterPolicyViolation [15561,15590]
name: AirflowClusterPolicyViolation [15590,15619]
===
match
---
atom_expr [10428,10456]
atom_expr [10457,10485]
===
match
---
name: session [22164,22171]
name: session [22193,22200]
===
match
---
name: DAGBAG_IMPORT_TIMEOUT [3080,3101]
name: DAGBAG_IMPORT_TIMEOUT [3080,3101]
===
match
---
funcdef [5837,8818]
funcdef [5837,8847]
===
match
---
name: before_sleep_log [22942,22958]
name: before_sleep_log [22971,22987]
===
match
---
param [5652,5656]
param [5652,5656]
===
match
---
arglist [3373,3396]
arglist [3373,3396]
===
match
---
atom_expr [20260,20271]
atom_expr [20289,20300]
===
match
---
suite [12835,12861]
suite [12864,12890]
===
match
---
name: airflow [1291,1298]
name: airflow [1291,1298]
===
match
---
expr_stmt [11914,11949]
expr_stmt [11943,11978]
===
match
---
operator: , [13097,13098]
operator: , [13126,13127]
===
match
---
comp_op [12812,12818]
comp_op [12841,12847]
===
match
---
name: self [11160,11164]
name: self [11189,11193]
===
match
---
trailer [14754,14762]
trailer [14783,14791]
===
match
---
name: include_smart_sensor [5090,5110]
name: include_smart_sensor [5090,5110]
===
match
---
name: self [4742,4746]
name: self [4742,4746]
===
match
---
simple_stmt [11017,11040]
simple_stmt [11046,11069]
===
match
---
name: OperationalError [1203,1219]
name: OperationalError [1203,1219]
===
match
---
testlist_comp [15179,15244]
testlist_comp [15208,15273]
===
match
---
operator: , [18761,18762]
operator: , [18790,18791]
===
match
---
trailer [23666,23671]
trailer [23695,23700]
===
match
---
name: x [19488,19489]
name: x [19517,19518]
===
match
---
trailer [15356,15370]
trailer [15385,15399]
===
match
---
name: MIN_SERIALIZED_DAG_UPDATE_INTERVAL [22100,22134]
name: MIN_SERIALIZED_DAG_UPDATE_INTERVAL [22129,22163]
===
match
---
atom_expr [15094,15116]
atom_expr [15123,15145]
===
match
---
simple_stmt [8789,8818]
simple_stmt [8818,8847]
===
match
---
atom_expr [13512,13529]
atom_expr [13541,13558]
===
match
---
trailer [13779,13789]
trailer [13808,13818]
===
match
---
suite [16395,16718]
suite [16424,16747]
===
match
---
atom [15534,15591]
atom [15563,15620]
===
match
---
funcdef [19519,20363]
funcdef [19548,20392]
===
match
---
operator: = [22402,22403]
operator: = [22431,22432]
===
match
---
annassign [4394,4415]
annassign [4394,4415]
===
match
---
name: str [5666,5669]
name: str [5666,5669]
===
match
---
name: filepath [12453,12461]
name: filepath [12482,12490]
===
match
---
name: file_last_changed_on_disk [15489,15514]
name: file_last_changed_on_disk [15518,15543]
===
match
---
trailer [7793,7800]
trailer [7822,7829]
===
match
---
name: AirflowClusterPolicyViolation [1385,1414]
name: AirflowClusterPolicyViolation [1385,1414]
===
match
---
suite [10852,12490]
suite [10881,12519]
===
match
---
trailer [8374,8387]
trailer [8403,8416]
===
match
---
name: is_expired [8297,8307]
name: is_expired [8326,8336]
===
match
---
name: SerializedDagNotFound [9084,9105]
name: SerializedDagNotFound [9113,9134]
===
match
---
trailer [11795,11812]
trailer [11824,11841]
===
match
---
name: _serialze_dag_capturing_errors [23574,23604]
name: _serialze_dag_capturing_errors [23603,23633]
===
match
---
name: SerializedDagModel [9006,9024]
name: SerializedDagModel [9035,9053]
===
match
---
trailer [9284,9291]
trailer [9313,9320]
===
match
---
trailer [4581,4596]
trailer [4581,4596]
===
match
---
name: self [18178,18182]
name: self [18207,18211]
===
match
---
string: 'core' [3531,3537]
string: 'core' [3531,3537]
===
match
---
trailer [23106,23110]
trailer [23135,23139]
===
match
---
operator: = [8413,8414]
operator: = [8442,8443]
===
match
---
trailer [4380,4394]
trailer [4380,4394]
===
match
---
trailer [12468,12471]
trailer [12497,12500]
===
match
---
operator: , [23248,23249]
operator: , [23277,23278]
===
match
---
atom_expr [9281,9291]
atom_expr [9310,9320]
===
match
---
trailer [7710,7718]
trailer [7739,7747]
===
match
---
name: format_exc [22386,22396]
name: format_exc [22415,22425]
===
match
---
name: self [8732,8736]
name: self [8761,8765]
===
match
---
name: self [17182,17186]
name: self [17211,17215]
===
match
---
trailer [10587,10608]
trailer [10616,10637]
===
match
---
name: has_logged [4429,4439]
name: has_logged [4429,4439]
===
match
---
trailer [13419,13424]
trailer [13448,13453]
===
match
---
atom_expr [20337,20362]
atom_expr [20366,20391]
===
match
---
name: filepath [18429,18437]
name: filepath [18458,18466]
===
match
---
operator: , [5545,5546]
operator: , [5545,5546]
===
match
---
param [17380,17438]
param [17409,17467]
===
match
---
trailer [13415,13419]
trailer [13444,13448]
===
match
---
trailer [5273,5278]
trailer [5273,5278]
===
match
---
atom_expr [18856,18873]
atom_expr [18885,18902]
===
match
---
suite [10457,10527]
suite [10486,10556]
===
match
---
name: airflow [1590,1597]
name: airflow [1590,1597]
===
match
---
name: session [23610,23617]
name: session [23639,23646]
===
match
---
and_test [7008,7143]
and_test [7008,7143]
===
match
---
trailer [18871,18873]
trailer [18900,18902]
===
match
---
name: log [18183,18186]
name: log [18212,18215]
===
match
---
name: str [14266,14269]
name: str [14295,14298]
===
match
---
name: process_file [18740,18752]
name: process_file [18769,18781]
===
match
---
name: dag [14626,14629]
name: dag [14655,14658]
===
match
---
operator: = [18597,18598]
operator: = [18626,18627]
===
match
---
simple_stmt [23760,23779]
simple_stmt [23789,23808]
===
match
---
parameters [15884,15905]
parameters [15913,15934]
===
match
---
atom_expr [22854,22906]
atom_expr [22883,22935]
===
match
---
simple_stmt [12116,12169]
simple_stmt [12145,12198]
===
match
---
operator: = [5089,5090]
operator: = [5089,5090]
===
match
---
string: 'LOAD_EXAMPLES' [17421,17436]
string: 'LOAD_EXAMPLES' [17450,17465]
===
match
---
atom_expr [4177,4192]
atom_expr [4177,4192]
===
match
---
name: warning [12972,12979]
name: warning [13001,13008]
===
match
---
name: stop [22849,22853]
name: stop [22878,22882]
===
match
---
operator: { [21066,21067]
operator: { [21095,21096]
===
match
---
simple_stmt [20661,20705]
simple_stmt [20690,20734]
===
match
---
name: SCHEDULER_ZOMBIE_TASK_THRESHOLD [3155,3186]
name: SCHEDULER_ZOMBIE_TASK_THRESHOLD [3155,3186]
===
match
---
simple_stmt [21608,21814]
simple_stmt [21637,21843]
===
match
---
param [10825,10830]
param [10854,10859]
===
match
---
operator: , [998,999]
operator: , [998,999]
===
match
---
argument [15064,15076]
argument [15093,15105]
===
match
---
name: logging [22969,22976]
name: logging [22998,23005]
===
match
---
name: splitext [11235,11243]
name: splitext [11264,11272]
===
match
---
operator: , [11629,11630]
operator: , [11658,11659]
===
match
---
operator: = [17538,17539]
operator: = [17567,17568]
===
match
---
atom_expr [9174,9181]
atom_expr [9203,9210]
===
match
---
testlist_comp [8617,8661]
testlist_comp [8646,8690]
===
match
---
simple_stmt [13568,13577]
simple_stmt [13597,13606]
===
match
---
name: _load_modules_from_file [10482,10505]
name: _load_modules_from_file [10511,10534]
===
match
---
trailer [20627,20635]
trailer [20656,20664]
===
match
---
trailer [23671,23678]
trailer [23700,23707]
===
match
---
name: subdags [20293,20300]
name: subdags [20322,20329]
===
match
---
fstring_expr [11392,11406]
fstring_expr [11421,11435]
===
match
---
operator: } [15426,15427]
operator: } [15455,15456]
===
match
---
operator: , [18563,18564]
operator: , [18592,18593]
===
match
---
operator: = [15072,15073]
operator: = [15101,15102]
===
match
---
factor [22403,22444]
factor [22432,22473]
===
match
---
suite [12946,13030]
suite [12975,13059]
===
match
---
trailer [17230,17245]
trailer [17259,17274]
===
match
---
name: dags [1977,1981]
name: dags [1977,1981]
===
match
---
name: keys [5803,5807]
name: keys [5803,5807]
===
match
---
name: tenacity [22854,22862]
name: tenacity [22883,22891]
===
match
---
name: subdag [9239,9245]
name: subdag [9268,9274]
===
match
---
trailer [16926,16933]
trailer [16955,16962]
===
match
---
name: bool [3429,3433]
name: bool [3429,3433]
===
match
---
trailer [7676,7681]
trailer [7705,7710]
===
match
---
trailer [20675,20704]
trailer [20704,20733]
===
match
---
atom_expr [4319,4341]
atom_expr [4319,4341]
===
match
---
except_clause [16726,16776]
except_clause [16755,16805]
===
match
---
name: __init__ [3761,3769]
name: __init__ [3761,3769]
===
match
---
trailer [3760,3769]
trailer [3760,3769]
===
match
---
argument [7458,7471]
argument [7487,7500]
===
match
---
trailer [23116,23312]
trailer [23145,23341]
===
match
---
atom_expr [13638,13659]
atom_expr [13667,13688]
===
match
---
atom_expr [18272,18287]
atom_expr [18301,18316]
===
match
---
name: append [13811,13817]
name: append [13840,13846]
===
match
---
name: subdag [17123,17129]
name: subdag [17152,17158]
===
match
---
name: filepath [9833,9841]
name: filepath [9862,9870]
===
match
---
name: croniter [14983,14991]
name: croniter [15012,15020]
===
match
---
arglist [22813,22834]
arglist [22842,22863]
===
match
---
trailer [10435,10446]
trailer [10464,10475]
===
match
---
name: timeout [1817,1824]
name: timeout [1817,1824]
===
match
---
name: safe_mode [18507,18516]
name: safe_mode [18536,18545]
===
match
---
operator: = [19507,19508]
operator: = [19536,19537]
===
match
---
name: cycle_exception [16761,16776]
name: cycle_exception [16790,16805]
===
match
---
sync_comp_for [8634,8661]
sync_comp_for [8663,8690]
===
match
---
operator: , [22983,22984]
operator: , [23012,23013]
===
match
---
simple_stmt [1079,1176]
simple_stmt [1079,1176]
===
match
---
name: list [14539,14543]
name: list [14568,14572]
===
match
---
name: airflow [1469,1476]
name: airflow [1469,1476]
===
match
---
param [17350,17371]
param [17379,17400]
===
match
---
name: utcnow [9353,9359]
name: utcnow [9382,9388]
===
match
---
name: dag_folder [17325,17335]
name: dag_folder [17354,17364]
===
match
---
name: append [18896,18902]
name: append [18925,18931]
===
match
---
trailer [13051,13057]
trailer [13080,13086]
===
match
---
comparison [7357,7414]
comparison [7386,7443]
===
match
---
trailer [11925,11936]
trailer [11954,11965]
===
match
---
name: provide_session [5817,5832]
name: provide_session [5817,5832]
===
match
---
trailer [16883,16893]
trailer [16912,16922]
===
match
---
name: models [6095,6101]
name: models [6095,6101]
===
match
---
trailer [8626,8633]
trailer [8655,8662]
===
match
---
name: filepath [12264,12272]
name: filepath [12293,12301]
===
match
---
suite [22253,22276]
suite [22282,22305]
===
match
---
name: util [864,868]
name: util [864,868]
===
match
---
operator: = [18546,18547]
operator: = [18575,18576]
===
match
---
name: timezone [18688,18696]
name: timezone [18717,18725]
===
match
---
simple_stmt [869,884]
simple_stmt [869,884]
===
match
---
operator: { [15419,15420]
operator: { [15448,15449]
===
match
---
operator: , [1165,1166]
operator: , [1165,1166]
===
match
---
trailer [19444,19457]
trailer [19473,19486]
===
match
---
name: list_py_file_paths [1638,1656]
name: list_py_file_paths [1638,1656]
===
match
---
argument [22397,22444]
argument [22426,22473]
===
match
---
name: last_expired [8208,8220]
name: last_expired [8237,8249]
===
match
---
name: zip_info [13147,13155]
name: zip_info [13176,13184]
===
match
---
name: dag_id [20308,20314]
name: dag_id [20337,20343]
===
match
---
name: subdags [16374,16381]
name: subdags [16403,16410]
===
match
---
operator: , [14339,14340]
operator: , [14368,14369]
===
match
---
return_stmt [10283,10292]
return_stmt [10312,10321]
===
match
---
operator: , [5143,5144]
operator: , [5143,5144]
===
match
---
name: self [11552,11556]
name: self [11581,11585]
===
match
---
simple_stmt [11492,11582]
simple_stmt [11521,11611]
===
match
---
simple_stmt [16447,16488]
simple_stmt [16476,16517]
===
match
---
name: OperationalError [22236,22252]
name: OperationalError [22265,22281]
===
match
---
name: root_dag [16618,16626]
name: root_dag [16647,16655]
===
match
---
simple_stmt [9000,9046]
simple_stmt [9029,9075]
===
match
---
atom_expr [3436,3487]
atom_expr [3436,3487]
===
match
---
name: has_logged [10989,10999]
name: has_logged [11018,11028]
===
match
---
del_stmt [11457,11482]
del_stmt [11486,11511]
===
match
---
name: debug [11169,11174]
name: debug [11198,11203]
===
match
---
simple_stmt [15042,15078]
simple_stmt [15071,15107]
===
match
---
trailer [5411,5582]
trailer [5411,5582]
===
match
---
operator: , [3976,3977]
operator: , [3976,3977]
===
match
---
trailer [8805,8809]
trailer [8834,8838]
===
match
---
arglist [18753,18815]
arglist [18782,18844]
===
match
---
name: dag [14923,14926]
name: dag [14952,14955]
===
match
---
name: dag [16275,16278]
name: dag [16304,16307]
===
match
---
operator: , [22827,22828]
operator: , [22856,22857]
===
match
---
name: hexdigest [11332,11341]
name: hexdigest [11361,11370]
===
match
---
expr_stmt [23064,23085]
expr_stmt [23093,23114]
===
match
---
name: subdag [9256,9262]
name: subdag [9285,9291]
===
match
---
name: _process_modules [14302,14318]
name: _process_modules [14331,14347]
===
match
---
import_from [21476,21536]
import_from [21505,21565]
===
match
---
trailer [5797,5802]
trailer [5797,5802]
===
match
---
trailer [7705,7710]
trailer [7734,7739]
===
match
---
name: self [23971,23975]
name: self [24000,24004]
===
match
---
name: dags [17226,17230]
name: dags [17255,17259]
===
match
---
trailer [6443,6460]
trailer [6443,6460]
===
match
---
string: "Filling up the DagBag from database" [19735,19772]
string: "Filling up the DagBag from database" [19764,19801]
===
match
---
atom_expr [8435,8450]
atom_expr [8464,8479]
===
match
---
arglist [3118,3149]
arglist [3118,3149]
===
match
---
trailer [22727,22761]
trailer [22756,22790]
===
match
---
name: new_module [11939,11949]
name: new_module [11968,11978]
===
match
---
operator: , [13500,13501]
operator: , [13529,13530]
===
match
---
expr_stmt [15352,15428]
expr_stmt [15381,15457]
===
match
---
expr_stmt [9168,9181]
expr_stmt [9197,9210]
===
match
---
simple_stmt [4070,4112]
simple_stmt [4070,4112]
===
match
---
import_name [905,920]
import_name [905,920]
===
match
---
name: safe_mode [10516,10525]
name: safe_mode [10545,10554]
===
match
---
name: path [12699,12703]
name: path [12728,12732]
===
match
---
tfpdef [8863,8879]
tfpdef [8892,8908]
===
match
---
arglist [14579,14585]
arglist [14608,14614]
===
match
---
operator: = [19458,19459]
operator: = [19487,19488]
===
match
---
name: dag_folder [20493,20503]
name: dag_folder [20522,20532]
===
match
---
fstring_string: unusual_prefix_ [11365,11380]
fstring_string: unusual_prefix_ [11394,11409]
===
match
---
atom_expr [20574,20585]
atom_expr [20603,20614]
===
match
---
simple_stmt [4742,4838]
simple_stmt [4742,4838]
===
match
---
name: self [14130,14134]
name: self [14159,14163]
===
match
---
name: log [23107,23110]
name: log [23136,23139]
===
match
---
name: session [23760,23767]
name: session [23789,23796]
===
match
---
name: import_errors [12250,12263]
name: import_errors [12279,12292]
===
match
---
simple_stmt [4376,4416]
simple_stmt [4376,4416]
===
match
---
operator: , [11821,11822]
operator: , [11850,11851]
===
match
---
trailer [16550,16560]
trailer [16579,16589]
===
match
---
name: filename [13089,13097]
name: filename [13118,13126]
===
match
---
trailer [9207,9215]
trailer [9236,9244]
===
match
---
name: dag_folder [4998,5008]
name: dag_folder [4998,5008]
===
match
---
trailer [10446,10456]
trailer [10475,10485]
===
match
---
comparison [8606,8662]
comparison [8635,8691]
===
match
---
atom_expr [15741,15755]
atom_expr [15770,15784]
===
match
---
trailer [14097,14192]
trailer [14126,14221]
===
match
---
funcdef [12495,14293]
funcdef [12524,14322]
===
match
---
trailer [7440,7457]
trailer [7469,7486]
===
match
---
simple_stmt [4121,4169]
simple_stmt [4121,4169]
===
match
---
simple_stmt [11352,11408]
simple_stmt [11381,11437]
===
match
---
operator: = [3355,3356]
operator: = [3355,3356]
===
match
---
suite [16311,16351]
suite [16340,16380]
===
match
---
expr_stmt [14703,14731]
expr_stmt [14732,14760]
===
match
---
trailer [21832,21842]
trailer [21861,21871]
===
match
---
expr_stmt [12245,12391]
expr_stmt [12274,12420]
===
match
---
name: SerializedDagNotFound [1442,1463]
name: SerializedDagNotFound [1442,1463]
===
match
---
name: top_level_dags [14496,14510]
name: top_level_dags [14525,14539]
===
match
---
name: dag [21453,21456]
name: dag [21482,21485]
===
match
---
trailer [22675,23020]
trailer [22704,23049]
===
match
---
comparison [6343,6366]
comparison [6343,6366]
===
match
---
atom_expr [14266,14272]
atom_expr [14295,14301]
===
match
---
argument [15055,15062]
argument [15084,15091]
===
match
---
name: is_missing [8137,8147]
name: is_missing [8166,8176]
===
match
---
operator: , [22049,22050]
operator: , [22078,22079]
===
match
---
atom_expr [5398,5582]
atom_expr [5398,5582]
===
match
---
return_stmt [8789,8817]
return_stmt [8818,8846]
===
match
---
arglist [22046,22172]
arglist [22075,22201]
===
match
---
simple_stmt [22354,22448]
simple_stmt [22383,22477]
===
match
---
name: total_seconds [20587,20600]
name: total_seconds [20616,20629]
===
match
---
name: sha1 [11301,11305]
name: sha1 [11330,11334]
===
match
---
comparison [10190,10251]
comparison [10219,10280]
===
match
---
name: self [9229,9233]
name: self [9258,9262]
===
match
---
operator: , [13013,13014]
operator: , [13042,13043]
===
match
---
dotted_name [1225,1239]
dotted_name [1225,1239]
===
match
---
name: filepath [11119,11127]
name: filepath [11148,11156]
===
match
---
atom_expr [3189,3248]
atom_expr [3189,3248]
===
match
---
comparison [11420,11443]
comparison [11449,11472]
===
match
---
name: key [19474,19477]
name: key [19503,19506]
===
match
---
operator: = [12463,12464]
operator: = [12492,12493]
===
match
---
name: import_errors [15357,15370]
name: import_errors [15386,15399]
===
match
---
atom_expr [16185,16200]
atom_expr [16214,16229]
===
match
---
name: self [19931,19935]
name: self [19960,19964]
===
match
---
name: dag_id [9029,9035]
name: dag_id [9058,9064]
===
match
---
name: org_mod_name [11393,11405]
name: org_mod_name [11422,11434]
===
match
---
name: ext [13015,13018]
name: ext [13044,13047]
===
match
---
atom_expr [17539,17589]
atom_expr [17568,17618]
===
match
---
name: safe_mode [18497,18506]
name: safe_mode [18526,18535]
===
match
---
name: self [12188,12192]
name: self [12217,12221]
===
match
---
if_stmt [12873,12907]
if_stmt [12902,12936]
===
match
---
operator: , [11189,11190]
operator: , [11218,11219]
===
match
---
name: read_dags_from_db [4481,4498]
name: read_dags_from_db [4481,4498]
===
match
---
name: utcnow [7070,7076]
name: utcnow [7070,7076]
===
match
---
operator: = [13384,13385]
operator: = [13413,13414]
===
match
---
atom_expr [4742,4777]
atom_expr [4742,4777]
===
match
---
string: '__init__' [12935,12945]
string: '__init__' [12964,12974]
===
match
---
trailer [11229,11234]
trailer [11258,11263]
===
match
---
atom_expr [22404,22444]
atom_expr [22433,22473]
===
match
---
simple_stmt [11160,11201]
simple_stmt [11189,11230]
===
match
---
operator: , [12825,12826]
operator: , [12854,12855]
===
match
---
simple_stmt [15445,15515]
simple_stmt [15474,15544]
===
match
---
atom [12819,12834]
atom [12848,12863]
===
match
---
operator: += [15144,15146]
operator: += [15173,15175]
===
match
---
simple_stmt [20459,20485]
simple_stmt [20488,20514]
===
match
---
simple_stmt [8137,8179]
simple_stmt [8166,8208]
===
match
---
trailer [18752,18816]
trailer [18781,18845]
===
match
---
name: airflow [1788,1795]
name: airflow [1788,1795]
===
match
---
suite [21595,22448]
suite [21624,22477]
===
match
---
operator: = [18256,18257]
operator: = [18285,18286]
===
match
---
operator: = [4240,4241]
operator: = [4240,4241]
===
match
---
trailer [22862,22881]
trailer [22891,22910]
===
match
---
trailer [9359,9361]
trailer [9388,9390]
===
match
---
param [17447,17520]
param [17476,17549]
===
match
---
expr_stmt [7630,7650]
expr_stmt [7659,7679]
===
match
---
name: log [12968,12971]
name: log [12997,13000]
===
match
---
operator: { [4242,4243]
operator: { [4242,4243]
===
match
---
name: _ [12692,12693]
name: _ [12721,12722]
===
match
---
atom_expr [4713,4727]
atom_expr [4713,4727]
===
match
---
if_stmt [13590,13660]
if_stmt [13619,13689]
===
match
---
name: warn [5407,5411]
name: warn [5407,5411]
===
match
---
operator: , [17370,17371]
operator: , [17399,17400]
===
match
---
trailer [14477,14487]
trailer [14506,14516]
===
match
---
trailer [19682,19688]
trailer [19711,19717]
===
match
---
name: mod_name [12741,12749]
name: mod_name [12770,12778]
===
match
---
name: current_module [13739,13753]
name: current_module [13768,13782]
===
match
---
name: include_smart_sensor [5069,5089]
name: include_smart_sensor [5069,5089]
===
match
---
import_name [921,937]
import_name [921,937]
===
match
---
name: task [16345,16349]
name: task [16374,16378]
===
match
---
argument [6476,6491]
argument [6476,6491]
===
match
---
name: conf [17539,17543]
name: conf [17568,17572]
===
match
---
simple_stmt [23550,23620]
simple_stmt [23579,23649]
===
match
---
name: duration [19035,19043]
name: duration [19064,19072]
===
match
---
name: cron_e [15249,15255]
name: cron_e [15278,15284]
===
match
---
name: _add_dag_from_db [8827,8843]
name: _add_dag_from_db [8856,8872]
===
match
---
name: dag [9330,9333]
name: dag [9359,9362]
===
match
---
atom_expr [20721,20752]
atom_expr [20750,20781]
===
match
---
trailer [10652,10695]
trailer [10681,10724]
===
match
---
trailer [18182,18186]
trailer [18211,18215]
===
match
---
trailer [18975,18983]
trailer [19004,19012]
===
match
---
name: session [7975,7982]
name: session [8004,8011]
===
match
---
or_test [13319,13346]
or_test [13348,13375]
===
match
---
name: exception [19418,19427]
name: exception [19447,19456]
===
match
---
del_stmt [8759,8780]
del_stmt [8788,8809]
===
match
---
name: dag_id [6468,6474]
name: dag_id [6468,6474]
===
match
---
import_as_names [1100,1175]
import_as_names [1100,1175]
===
match
---
name: dag [6102,6105]
name: dag [6102,6105]
===
match
---
for_stmt [17119,17246]
for_stmt [17148,17275]
===
match
---
name: self [9434,9438]
name: self [9463,9467]
===
match
---
atom_expr [7672,7681]
atom_expr [7701,7710]
===
match
---
atom_expr [8233,8248]
atom_expr [8262,8277]
===
match
---
name: subdag [20250,20256]
name: subdag [20279,20285]
===
match
---
arglist [13710,13721]
arglist [13739,13750]
===
match
---
trailer [16879,16883]
trailer [16908,16912]
===
match
---
fstring [15392,15428]
fstring [15421,15457]
===
match
---
funcdef [5160,5280]
funcdef [5160,5280]
===
match
---
name: self [8844,8848]
name: self [8873,8877]
===
match
---
name: is_zipfile [14446,14456]
name: is_zipfile [14475,14485]
===
match
---
name: models [19615,19621]
name: models [19644,19650]
===
match
---
name: tenacity [22695,22703]
name: tenacity [22724,22732]
===
match
---
operator: = [11644,11645]
operator: = [11673,11674]
===
match
---
name: str [4230,4233]
name: str [4230,4233]
===
match
---
name: only_if_updated [18779,18794]
name: only_if_updated [18808,18823]
===
match
---
operator: = [15058,15059]
operator: = [15087,15088]
===
match
---
simple_stmt [4846,4948]
simple_stmt [4846,4948]
===
match
---
name: util [11870,11874]
name: util [11899,11903]
===
match
---
simple_stmt [1176,1220]
simple_stmt [1176,1220]
===
match
---
trailer [13649,13659]
trailer [13678,13688]
===
match
---
expr_stmt [7175,7337]
expr_stmt [7175,7337]
===
match
---
operator: = [14511,14512]
operator: = [14540,14541]
===
match
---
name: SerializedDagModel [21996,22014]
name: SerializedDagModel [22025,22043]
===
match
---
operator: , [16711,16712]
operator: , [16740,16741]
===
match
---
simple_stmt [8357,8489]
simple_stmt [8386,8518]
===
match
---
trailer [3440,3451]
trailer [3440,3451]
===
match
---
trailer [13057,13108]
trailer [13086,13137]
===
match
---
name: filepath [10831,10839]
name: filepath [10860,10868]
===
match
---
comparison [8233,8271]
comparison [8262,8300]
===
match
---
name: dag_id [8810,8816]
name: dag_id [8839,8845]
===
match
---
param [12538,12547]
param [12567,12576]
===
match
---
name: tasks [19184,19189]
name: tasks [19213,19218]
===
match
---
suite [7748,7817]
suite [7777,7846]
===
match
---
trailer [10054,10064]
trailer [10083,10093]
===
match
---
trailer [16174,16176]
trailer [16203,16205]
===
match
---
expr_stmt [1904,1913]
expr_stmt [1904,1913]
===
match
---
if_stmt [6340,6538]
if_stmt [6340,6538]
===
match
---
name: file_last_changed_on_disk [10740,10765]
name: file_last_changed_on_disk [10769,10794]
===
match
---
trailer [11710,11720]
trailer [11739,11749]
===
match
---
simple_stmt [15772,15842]
simple_stmt [15801,15871]
===
match
---
trailer [23343,23385]
trailer [23372,23414]
===
match
---
simple_stmt [4697,4733]
simple_stmt [4697,4733]
===
match
---
trailer [9384,9396]
trailer [9413,9425]
===
match
---
return_stmt [9856,9865]
return_stmt [9885,9894]
===
match
---
comp_op [8162,8168]
comp_op [8191,8197]
===
match
---
trailer [15046,15054]
trailer [15075,15083]
===
match
---
simple_stmt [5781,5811]
simple_stmt [5781,5811]
===
match
---
atom_expr [7510,7531]
atom_expr [7539,7560]
===
match
---
name: dag [14703,14706]
name: dag [14732,14735]
===
match
---
trailer [13817,13833]
trailer [13846,13862]
===
match
---
name: dag [16923,16926]
name: dag [16952,16955]
===
match
---
name: filename [13156,13164]
name: filename [13185,13193]
===
match
---
name: mods [14335,14339]
name: mods [14364,14368]
===
match
---
name: List [1035,1039]
name: List [1035,1039]
===
match
---
name: self [5269,5273]
name: self [5269,5273]
===
match
---
if_stmt [7659,7817]
if_stmt [7688,7846]
===
match
---
operator: - [19064,19065]
operator: - [19093,19094]
===
match
---
operator: = [23081,23082]
operator: = [23110,23111]
===
match
---
atom_expr [14923,14955]
atom_expr [14952,14984]
===
match
---
atom_expr [15445,15486]
atom_expr [15474,15515]
===
match
---
name: timezone [1522,1530]
name: timezone [1522,1530]
===
match
---
expr_stmt [13368,13390]
expr_stmt [13397,13419]
===
match
---
trailer [14874,14884]
trailer [14903,14913]
===
match
---
operator: = [8198,8199]
operator: = [8227,8228]
===
match
---
name: attempt_number [23234,23248]
name: attempt_number [23263,23277]
===
match
---
name: spec [11892,11896]
name: spec [11921,11925]
===
match
---
atom_expr [12710,12727]
atom_expr [12739,12756]
===
match
---
name: exception_types [22728,22743]
name: exception_types [22757,22772]
===
match
---
atom_expr [19943,19977]
atom_expr [19972,20006]
===
match
---
name: warnings [3819,3827]
name: warnings [3819,3827]
===
match
---
name: row [9174,9177]
name: row [9203,9206]
===
match
---
name: importlib [810,819]
name: importlib [810,819]
===
match
---
name: settings [16324,16332]
name: settings [16353,16361]
===
match
---
for_stmt [14622,15842]
for_stmt [14651,15871]
===
match
---
string: """Whether or not to read dags from DB""" [5348,5389]
string: """Whether or not to read dags from DB""" [5348,5389]
===
match
---
if_stmt [14909,15026]
if_stmt [14938,15055]
===
match
---
trailer [10988,10999]
trailer [11017,11028]
===
match
---
dotted_name [1536,1566]
dotted_name [1536,1566]
===
match
---
trailer [12718,12727]
trailer [12747,12756]
===
match
---
name: AirflowDagCycleException [1416,1440]
name: AirflowDagCycleException [1416,1440]
===
match
---
except_clause [19338,19359]
except_clause [19367,19388]
===
match
---
operator: , [3565,3566]
operator: , [3565,3566]
===
match
---
name: stats [18890,18895]
name: stats [18919,18924]
===
match
---
param [5325,5329]
param [5325,5329]
===
match
---
name: session [7481,7488]
name: session [7510,7517]
===
match
---
suite [7415,7490]
suite [7444,7519]
===
match
---
atom_expr [8414,8451]
atom_expr [8443,8480]
===
match
---
name: o [14534,14535]
name: o [14563,14564]
===
match
---
for_stmt [23495,23620]
for_stmt [23524,23649]
===
match
---
name: dag [16597,16600]
name: dag [16626,16629]
===
match
---
name: DAG [23641,23644]
name: DAG [23670,23673]
===
match
---
name: process_file [8375,8387]
name: process_file [8404,8416]
===
match
---
fstring_string: s [11579,11580]
fstring_string: s [11608,11609]
===
match
---
simple_stmt [14597,14613]
simple_stmt [14626,14642]
===
match
---
expr_stmt [15133,15158]
expr_stmt [15162,15187]
===
match
---
name: dag_id [9285,9291]
name: dag_id [9314,9320]
===
match
---
suite [21259,24021]
suite [21288,24050]
===
match
---
trailer [18276,18287]
trailer [18305,18316]
===
match
---
expr_stmt [16504,16527]
expr_stmt [16533,16556]
===
match
---
simple_stmt [13411,13552]
simple_stmt [13440,13581]
===
match
---
name: list [5788,5792]
name: list [5788,5792]
===
match
---
name: FileLoadStat [18924,18936]
name: FileLoadStat [18953,18965]
===
match
---
expr_stmt [14597,14612]
expr_stmt [14626,14641]
===
match
---
operator: = [3654,3655]
operator: = [3654,3655]
===
match
---
string: "Running dagbag.sync_to_db with retries. Try %d of %d" [23138,23192]
string: "Running dagbag.sync_to_db with retries. Try %d of %d" [23167,23221]
===
match
---
trailer [20226,20228]
trailer [20255,20257]
===
match
---
atom_expr [17221,17245]
atom_expr [17250,17274]
===
match
---
name: last_loaded [16189,16200]
name: last_loaded [16218,16229]
===
match
---
atom_expr [22780,22835]
atom_expr [22809,22864]
===
match
---
name: subdag [17231,17237]
name: subdag [17260,17266]
===
match
---
name: dag_num [20611,20618]
name: dag_num [20640,20647]
===
match
---
annassign [4575,4601]
annassign [4575,4601]
===
match
---
name: filename [12783,12791]
name: filename [12812,12820]
===
match
---
simple_stmt [18351,18362]
simple_stmt [18380,18391]
===
match
---
name: split [12704,12709]
name: split [12733,12738]
===
match
---
name: self [22404,22408]
name: self [22433,22437]
===
match
---
if_stmt [17162,17246]
if_stmt [17191,17275]
===
match
---
factor [14129,14170]
factor [14158,14199]
===
match
---
operator: } [21037,21038]
operator: } [21066,21067]
===
match
---
trailer [8800,8805]
trailer [8829,8834]
===
match
---
atom_expr [19931,19940]
atom_expr [19960,19969]
===
match
---
name: found_dags [15094,15104]
name: found_dags [15123,15133]
===
match
---
lambdef [19478,19498]
lambdef [19507,19527]
===
match
---
trailer [8387,8488]
trailer [8416,8517]
===
match
---
name: super [3753,3758]
name: super [3753,3758]
===
match
---
simple_stmt [905,921]
simple_stmt [905,921]
===
match
---
param [9450,9471]
param [9479,9500]
===
match
---
subscriptlist [4582,4595]
subscriptlist [4582,4595]
===
match
---
suite [14648,15842]
suite [14677,15871]
===
match
---
trailer [22703,22727]
trailer [22732,22756]
===
match
---
suite [17141,17246]
suite [17170,17275]
===
match
---
name: importlib [11781,11790]
name: importlib [11810,11819]
===
match
---
atom_expr [15666,15683]
atom_expr [15695,15712]
===
match
---
name: has_logged [13328,13338]
name: has_logged [13357,13367]
===
match
---
atom [20545,20572]
atom [20574,20601]
===
match
---
atom_expr [23971,24020]
atom_expr [24000,24049]
===
match
---
name: o [20561,20562]
name: o [20590,20591]
===
match
---
name: path [10041,10045]
name: path [10070,10074]
===
match
---
name: dag_id [8627,8633]
name: dag_id [8656,8662]
===
match
---
name: datetime [4587,4595]
name: datetime [4587,4595]
===
match
---
string: """         :return: a list of DAG IDs in this bag         :rtype: List[unicode]         """ [5680,5772]
string: """         :return: a list of DAG IDs in this bag         :rtype: List[unicode]         """ [5680,5772]
===
match
---
sync_comp_for [20557,20571]
sync_comp_for [20586,20600]
===
match
---
atom [15178,15245]
atom [15207,15274]
===
match
---
trailer [12333,12369]
trailer [12362,12398]
===
match
---
atom_expr [9330,9340]
atom_expr [9359,9369]
===
match
---
trailer [12709,12728]
trailer [12738,12757]
===
match
---
atom_expr [15720,15737]
atom_expr [15749,15766]
===
match
---
name: o [20626,20627]
name: o [20655,20656]
===
match
---
name: found_dags [8591,8601]
name: found_dags [8620,8630]
===
match
---
expr_stmt [12741,12792]
expr_stmt [12770,12821]
===
match
---
name: self [7081,7085]
name: self [7081,7085]
===
match
---
return_stmt [22354,22447]
return_stmt [22383,22476]
===
match
---
atom_expr [13043,13108]
atom_expr [13072,13137]
===
match
---
trailer [15626,15630]
trailer [15655,15659]
===
match
---
name: self [23329,23333]
name: self [23358,23362]
===
match
---
not_test [10864,10906]
not_test [10893,10935]
===
match
---
operator: = [18854,18855]
operator: = [18883,18884]
===
insert-node
---
name: DagBag [1995,2001]
to
classdef [1989,24021]
at 0
===
insert-node
---
name: LoggingMixin [2002,2014]
to
classdef [1989,24021]
at 1
===
insert-tree
---
simple_stmt [2021,3075]
    string: """     A dagbag is a collection of dags, parsed out of a folder tree and has high     level configuration settings, like what database to use as a backend and     what executor to use to fire off tasks. This makes it easier to run     distinct environments for say production and development, tests, or for     different teams or security profiles. What would have been system level     settings are now dagbag level so that one system can run multiple,     independent settings sets.      :param dag_folder: the folder to scan to find DAGs     :type dag_folder: unicode     :param include_examples: whether to include the examples that ship         with airflow or not     :type include_examples: bool     :param include_smart_sensor: whether to include the smart sensor native         DAGs that create the smart sensor operators for whole cluster     :type include_smart_sensor: bool     :param read_dags_from_db: Read DAGs from DB if ``True`` is passed.         If ``False`` DAGs are read from python files.     :type read_dags_from_db: bool     """ [2021,3074]
to
suite [2016,24021]
at 0
===
insert-node
---
and_test [7357,7443]
to
if_stmt [7354,7490]
at 0
===
move-tree
---
comparison [7357,7414]
    name: sd_last_updated_datetime [7357,7381]
    operator: > [7382,7383]
    atom_expr [7384,7414]
        name: self [7384,7388]
        trailer [7388,7406]
            name: dags_last_fetched [7389,7406]
        trailer [7406,7414]
            name: dag_id [7407,7413]
to
and_test [7357,7443]
at 1
===
delete-node
---
name: DagBag [1995,2001]
===
===
delete-node
---
name: LoggingMixin [2002,2014]
===
===
delete-tree
---
simple_stmt [2021,3075]
    string: """     A dagbag is a collection of dags, parsed out of a folder tree and has high     level configuration settings, like what database to use as a backend and     what executor to use to fire off tasks. This makes it easier to run     distinct environments for say production and development, tests, or for     different teams or security profiles. What would have been system level     settings are now dagbag level so that one system can run multiple,     independent settings sets.      :param dag_folder: the folder to scan to find DAGs     :type dag_folder: unicode     :param include_examples: whether to include the examples that ship         with airflow or not     :type include_examples: bool     :param include_smart_sensor: whether to include the smart sensor native         DAGs that create the smart sensor operators for whole cluster     :type include_smart_sensor: bool     :param read_dags_from_db: Read DAGs from DB if ``True`` is passed.         If ``False`` DAGs are read from python files.     :type read_dags_from_db: bool     """ [2021,3074]
