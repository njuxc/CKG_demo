===
match
---
name: airflow [1189,1196]
name: airflow [1189,1196]
===
match
---
trailer [6709,6724]
trailer [7066,7081]
===
match
---
name: start_date [7908,7918]
name: start_date [8265,8275]
===
match
---
expr_stmt [16674,16687]
expr_stmt [17031,17044]
===
match
---
string: 'json' [14417,14423]
string: 'json' [14774,14780]
===
match
---
operator: , [3391,3392]
operator: , [3391,3392]
===
match
---
expr_stmt [16722,16750]
expr_stmt [17079,17107]
===
match
---
trailer [1710,1819]
trailer [1710,1819]
===
match
---
argument [10729,10735]
argument [11086,11092]
===
match
---
simple_stmt [11893,11984]
simple_stmt [12250,12341]
===
match
---
trailer [4393,4404]
trailer [4393,4404]
===
match
---
name: parser [7819,7825]
name: parser [8176,8182]
===
match
---
name: out [6200,6203]
name: out [6557,6560]
===
match
---
atom [9663,9910]
atom [10020,10267]
===
match
---
operator: , [8902,8903]
operator: , [9259,9260]
===
match
---
trailer [5300,5302]
trailer [5657,5659]
===
match
---
string: "my_dag_id" [17349,17360]
string: "my_dag_id" [17706,17717]
===
match
---
name: now [11054,11057]
name: now [11411,11414]
===
match
---
simple_stmt [1982,2025]
simple_stmt [1982,2025]
===
match
---
operator: = [1438,1439]
operator: = [1438,1439]
===
match
---
name: split [1476,1481]
name: split [1476,1481]
===
match
---
name: isoformat [13875,13884]
name: isoformat [14232,14241]
===
match
---
param [8441,8449]
param [8798,8806]
===
match
---
name: dag_command [13381,13392]
name: dag_command [13738,13749]
===
match
---
name: dag [7848,7851]
name: dag [8205,8208]
===
match
---
operator: , [18506,18507]
operator: , [18863,18864]
===
match
---
trailer [18568,18574]
trailer [18925,18931]
===
match
---
name: test_delete_dag [16643,16658]
name: test_delete_dag [17000,17015]
===
match
---
operator: , [8283,8284]
operator: , [8640,8641]
===
match
---
operator: = [9134,9135]
operator: = [9491,9492]
===
match
---
expr_stmt [7425,7463]
expr_stmt [7782,7820]
===
match
---
name: path [1608,1612]
name: path [1608,1612]
===
match
---
parameters [18217,18252]
parameters [18574,18609]
===
match
---
trailer [18782,19012]
trailer [19139,19369]
===
match
---
operator: = [10657,10658]
operator: = [11014,11015]
===
match
---
name: dag_command [13070,13081]
name: dag_command [13427,13438]
===
match
---
string: 'test_depends_on_past' [8583,8605]
string: 'test_depends_on_past' [8940,8962]
===
match
---
operator: = [8625,8626]
operator: = [8982,8983]
===
match
---
operator: = [2809,2810]
operator: = [2809,2810]
===
match
---
name: out [13114,13117]
name: out [13471,13474]
===
match
---
trailer [1750,1755]
trailer [1750,1755]
===
match
---
name: redirect_stdout [11652,11667]
name: redirect_stdout [12009,12024]
===
match
---
trailer [19671,19673]
trailer [20028,20030]
===
match
---
operator: , [1542,1543]
operator: , [1542,1543]
===
match
---
trailer [3159,3172]
trailer [3159,3172]
===
match
---
atom [14145,14438]
atom [14502,14795]
===
match
---
operator: , [4247,4248]
operator: , [4247,4248]
===
match
---
trailer [20359,20394]
trailer [20716,20751]
===
match
---
name: ValueError [16202,16212]
name: ValueError [16559,16569]
===
match
---
name: self [7752,7756]
name: self [8109,8113]
===
match
---
name: mock_run [2511,2519]
name: mock_run [2511,2519]
===
match
---
simple_stmt [5839,5982]
simple_stmt [6196,6339]
===
match
---
atom [17955,18023]
atom [18312,18380]
===
match
---
atom_expr [11900,11983]
atom_expr [12257,12340]
===
match
---
atom_expr [11357,11377]
atom_expr [11714,11734]
===
match
---
operator: = [8127,8128]
operator: = [8484,8485]
===
match
---
atom_expr [1748,1791]
atom_expr [1748,1791]
===
match
---
argument [8203,8212]
argument [8560,8569]
===
match
---
suite [14093,14489]
suite [14450,14846]
===
match
---
trailer [1700,1705]
trailer [1700,1705]
===
match
---
atom [20349,20395]
atom [20706,20752]
===
match
---
operator: = [10785,10786]
operator: = [11142,11143]
===
match
---
atom_expr [12606,12619]
atom_expr [12963,12976]
===
match
---
operator: = [9565,9566]
operator: = [9922,9923]
===
match
---
name: self [17857,17861]
name: self [18214,18218]
===
match
---
operator: , [8097,8098]
operator: , [8454,8455]
===
match
---
atom_expr [13954,13966]
atom_expr [14311,14323]
===
match
---
operator: , [18336,18337]
operator: , [18693,18694]
===
match
---
name: DagRun [10054,10060]
name: DagRun [10411,10417]
===
match
---
name: dag_command [3895,3906]
name: dag_command [3895,3906]
===
match
---
simple_stmt [7103,7123]
simple_stmt [7460,7480]
===
match
---
string: 'dags' [1639,1645]
string: 'dags' [1639,1645]
===
match
---
name: dag_command [12075,12086]
name: dag_command [12432,12443]
===
match
---
name: conf [2629,2633]
name: conf [2629,2633]
===
match
---
operator: , [7927,7928]
operator: , [8284,8285]
===
match
---
string: 'backfill' [3292,3302]
string: 'backfill' [3292,3302]
===
match
---
param [19361,19376]
param [19718,19733]
===
match
---
name: DEFAULT_DATE [19476,19488]
name: DEFAULT_DATE [19833,19845]
===
match
---
name: cli [982,985]
name: cli [982,985]
===
match
---
name: tests [1319,1324]
name: tests [1319,1324]
===
match
---
simple_stmt [13213,13236]
simple_stmt [13570,13593]
===
match
---
name: StringIO [11671,11679]
name: StringIO [12028,12036]
===
match
---
string: "seconds" [15752,15761]
string: "seconds" [16109,16118]
===
match
---
trailer [2336,2501]
trailer [2336,2501]
===
match
---
name: run_backwards [8264,8277]
name: run_backwards [8621,8634]
===
match
---
name: dag_backfill [9088,9100]
name: dag_backfill [9445,9457]
===
match
---
name: assert_has_calls [19696,19712]
name: assert_has_calls [20053,20069]
===
match
---
comparison [13220,13235]
comparison [13577,13592]
===
match
---
argument [20074,20109]
argument [20431,20466]
===
match
---
name: session [17369,17376]
name: session [17726,17733]
===
match
---
trailer [11015,11024]
trailer [11372,11381]
===
match
---
trailer [5272,5288]
trailer [5629,5645]
===
match
---
operator: = [9037,9038]
operator: = [9394,9395]
===
match
---
operator: , [20000,20001]
operator: , [20357,20358]
===
match
---
argument [5064,5073]
argument [5064,5073]
===
match
---
name: dagbag [2037,2043]
name: dagbag [2037,2043]
===
match
---
arglist [4761,5172]
arglist [4761,5172]
===
match
---
name: os [1764,1766]
name: os [1764,1766]
===
match
---
simple_stmt [17801,17833]
simple_stmt [18158,18190]
===
match
---
atom_expr [1509,1573]
atom_expr [1509,1573]
===
match
---
trailer [10038,10046]
trailer [10395,10403]
===
match
---
name: run_type [15555,15563]
name: run_type [15912,15920]
===
match
---
operator: + [7496,7497]
operator: + [7853,7854]
===
match
---
trailer [14824,14836]
trailer [15181,15193]
===
match
---
name: cli_args [18394,18402]
name: cli_args [18751,18759]
===
match
---
trailer [17566,17624]
trailer [17923,17981]
===
match
---
argument [9459,9477]
argument [9816,9834]
===
match
---
atom_expr [15366,15382]
atom_expr [15723,15739]
===
match
---
operator: = [19760,19761]
operator: = [20117,20118]
===
match
---
atom_expr [6791,6868]
atom_expr [7148,7225]
===
match
---
name: contextlib [12001,12011]
name: contextlib [12358,12368]
===
match
---
operator: { [15654,15655]
operator: { [16011,16012]
===
match
---
operator: = [9237,9238]
operator: = [9594,9595]
===
match
---
operator: , [4078,4079]
operator: , [4078,4079]
===
match
---
dotted_name [6279,6289]
dotted_name [6636,6646]
===
match
---
name: session [9999,10006]
name: session [10356,10363]
===
match
---
trailer [3201,3212]
trailer [3201,3212]
===
match
---
operator: = [18660,18661]
operator: = [19017,19018]
===
match
---
simple_stmt [14457,14489]
simple_stmt [14814,14846]
===
match
---
atom_expr [17893,18038]
atom_expr [18250,18395]
===
match
---
operator: , [4111,4112]
operator: , [4111,4112]
===
match
---
name: DM [17471,17473]
name: DM [17828,17830]
===
match
---
trailer [14747,14758]
trailer [15104,15115]
===
match
---
name: parse_args [10186,10196]
name: parse_args [10543,10553]
===
match
---
name: f [17444,17445]
name: f [17801,17802]
===
match
---
name: out [5505,5508]
name: out [5862,5865]
===
match
---
trailer [19753,19809]
trailer [20110,20166]
===
match
---
name: run_backwards [2922,2935]
name: run_backwards [2922,2935]
===
match
---
simple_stmt [7008,7067]
simple_stmt [7365,7424]
===
match
---
operator: = [9264,9265]
operator: = [9621,9622]
===
match
---
trailer [2372,2491]
trailer [2372,2491]
===
match
---
string: 'backfill' [2399,2409]
string: 'backfill' [2399,2409]
===
match
---
with_stmt [17406,17697]
with_stmt [17763,18054]
===
match
---
name: mock_get_dag [19683,19695]
name: mock_get_dag [20040,20052]
===
match
---
operator: , [10801,10802]
operator: , [11158,11159]
===
match
---
string: "airflow/example_dags" [1795,1817]
string: "airflow/example_dags" [1795,1817]
===
match
---
name: DagBag [1124,1130]
name: DagBag [1124,1130]
===
match
---
string: 'dags' [4444,4450]
string: 'dags' [4444,4450]
===
match
---
operator: = [11441,11442]
operator: = [11798,11799]
===
match
---
operator: == [15997,15999]
operator: == [16354,16356]
===
match
---
simple_stmt [5599,5641]
simple_stmt [5956,5998]
===
match
---
name: self [5353,5357]
name: self [5710,5714]
===
match
---
operator: , [8018,8019]
operator: , [8375,8376]
===
match
---
name: key [16696,16699]
name: key [17053,17056]
===
match
---
name: utils [1197,1202]
name: utils [1197,1202]
===
match
---
name: self [7226,7230]
name: self [7583,7587]
===
match
---
name: DagRunType [11357,11367]
name: DagRunType [11714,11724]
===
match
---
simple_stmt [14102,14449]
simple_stmt [14459,14806]
===
match
---
expr_stmt [6549,6602]
expr_stmt [6906,6959]
===
match
---
operator: = [2076,2077]
operator: = [2076,2077]
===
match
---
name: enumerate [11169,11178]
name: enumerate [11526,11535]
===
match
---
trailer [11794,11796]
trailer [12151,12153]
===
match
---
name: parser [17752,17758]
name: parser [18109,18115]
===
match
---
import_from [1271,1313]
import_from [1271,1313]
===
match
---
atom [16866,16898]
atom [17223,17255]
===
match
---
arglist [18804,18994]
arglist [19161,19351]
===
match
---
trailer [13029,13038]
trailer [13386,13395]
===
match
---
operator: + [8690,8691]
operator: + [9047,9048]
===
match
---
name: key [17343,17346]
name: key [17700,17703]
===
match
---
name: patch [19245,19250]
name: patch [19602,19607]
===
match
---
atom_expr [13070,13101]
atom_expr [13427,13458]
===
match
---
string: "OUT" [7082,7087]
string: "OUT" [7439,7444]
===
match
---
name: dag [11201,11204]
name: dag [11558,11561]
===
match
---
name: dag_ids [12345,12352]
name: dag_ids [12702,12709]
===
match
---
operator: = [5994,5995]
operator: = [6351,6352]
===
match
---
simple_stmt [14642,14720]
simple_stmt [14999,15077]
===
match
---
string: 'true' [12448,12454]
string: 'true' [12805,12811]
===
match
---
name: format [6986,6992]
name: format [7343,7349]
===
match
---
expr_stmt [11768,11796]
expr_stmt [12125,12153]
===
match
---
operator: @ [7128,7129]
operator: @ [7485,7486]
===
match
---
operator: , [4784,4785]
operator: , [4784,4785]
===
match
---
name: test_cli_list_dag_runs [13343,13365]
name: test_cli_list_dag_runs [13700,13722]
===
match
---
trailer [1594,1599]
trailer [1594,1599]
===
match
---
name: parser [10179,10185]
name: parser [10536,10542]
===
match
---
atom [18456,19027]
atom [18813,19384]
===
match
---
atom_expr [13381,13605]
atom_expr [13738,13962]
===
match
---
trailer [9993,9995]
trailer [10350,10352]
===
match
---
name: self [2287,2291]
name: self [2287,2291]
===
match
---
string: "foo" [15655,15660]
string: "foo" [16012,16017]
===
match
---
string: 'png' [6141,6146]
string: 'png' [6498,6503]
===
match
---
funcdef [5218,5641]
funcdef [5575,5998]
===
match
---
argument [19754,19776]
argument [20111,20133]
===
match
---
operator: = [2602,2603]
operator: = [2602,2603]
===
match
---
simple_stmt [3819,3886]
simple_stmt [3819,3886]
===
match
---
operator: , [4527,4528]
operator: , [4527,4528]
===
match
---
name: pool [5064,5068]
name: pool [5064,5068]
===
match
---
name: test_next_execution [9618,9637]
name: test_next_execution [9975,9994]
===
match
---
suite [7242,8322]
suite [7599,8679]
===
match
---
assert_stmt [13181,13204]
assert_stmt [13538,13561]
===
match
---
name: airflow [1054,1061]
name: airflow [1054,1061]
===
match
---
trailer [13140,13142]
trailer [13497,13499]
===
match
---
name: out [12200,12203]
name: out [12557,12560]
===
match
---
simple_stmt [3679,3768]
simple_stmt [3679,3768]
===
match
---
name: state [1252,1257]
name: state [1252,1257]
===
match
---
operator: = [2671,2672]
operator: = [2671,2672]
===
match
---
name: parser [13423,13429]
name: parser [13780,13786]
===
match
---
testlist_comp [16867,16897]
testlist_comp [17224,17254]
===
match
---
name: executor [20074,20082]
name: executor [20431,20439]
===
match
---
trailer [6570,6583]
trailer [6927,6940]
===
match
---
operator: = [10172,10173]
operator: = [10529,10530]
===
match
---
simple_stmt [15541,15585]
simple_stmt [15898,15942]
===
match
---
string: 'json' [12557,12563]
string: 'json' [12914,12920]
===
match
---
operator: = [12296,12297]
operator: = [12653,12654]
===
match
---
trailer [16929,16933]
trailer [17286,17290]
===
match
---
operator: , [16618,16619]
operator: , [16975,16976]
===
match
---
trailer [3751,3753]
trailer [3751,3753]
===
match
---
atom_expr [1698,1819]
atom_expr [1698,1819]
===
match
---
operator: , [7595,7596]
operator: , [7952,7953]
===
match
---
assert_stmt [5465,5508]
assert_stmt [5822,5865]
===
match
---
trailer [2036,2043]
trailer [2036,2043]
===
match
---
name: test_delete_dag_existing_file [17165,17194]
name: test_delete_dag_existing_file [17522,17551]
===
match
---
name: dag_trigger [14983,14994]
name: dag_trigger [15340,15351]
===
match
---
atom_expr [19827,20019]
atom_expr [20184,20376]
===
match
---
dictorsetmaker [19114,19145]
dictorsetmaker [19471,19502]
===
match
---
trailer [18277,18284]
trailer [18634,18641]
===
match
---
number: 1 [1489,1490]
number: 1 [1489,1490]
===
match
---
atom_expr [6491,6507]
atom_expr [6848,6864]
===
match
---
simple_stmt [15593,15624]
simple_stmt [15950,15981]
===
match
---
trailer [3109,3124]
trailer [3109,3124]
===
match
---
argument [4856,4879]
argument [4856,4879]
===
match
---
trailer [13404,13605]
trailer [13761,13962]
===
match
---
name: hours [11070,11075]
name: hours [11427,11432]
===
match
---
name: DagRun [12327,12333]
name: DagRun [12684,12690]
===
match
---
name: pool [9491,9495]
name: pool [9848,9852]
===
match
---
parameters [19325,19377]
parameters [19682,19734]
===
match
---
string: '--output' [14389,14399]
string: '--output' [14746,14756]
===
match
---
name: self [15008,15012]
name: self [15365,15369]
===
match
---
trailer [5795,5810]
trailer [6152,6167]
===
match
---
name: run_type [11348,11356]
name: run_type [11705,11713]
===
match
---
atom_expr [12134,12156]
atom_expr [12491,12513]
===
match
---
simple_stmt [1676,1820]
simple_stmt [1676,1820]
===
match
---
name: max [13963,13966]
name: max [14320,14323]
===
match
---
name: args [9124,9128]
name: args [9481,9485]
===
match
---
name: StringIO [3113,3121]
name: StringIO [3113,3121]
===
match
---
name: cleanup [6100,6107]
name: cleanup [6457,6464]
===
match
---
suite [5319,5420]
suite [5676,5777]
===
match
---
operator: , [16428,16429]
operator: , [16785,16786]
===
match
---
expr_stmt [11201,11231]
expr_stmt [11558,11588]
===
match
---
trailer [11223,11231]
trailer [11580,11588]
===
match
---
name: call [20042,20046]
name: call [20399,20403]
===
match
---
argument [6114,6132]
argument [6471,6489]
===
match
---
trailer [17466,17470]
trailer [17823,17827]
===
match
---
string: 'show' [5909,5915]
string: 'show' [6266,6272]
===
match
---
testlist_comp [14555,14595]
testlist_comp [14912,14952]
===
match
---
trailer [14869,14874]
trailer [15226,15231]
===
match
---
operator: , [4001,4002]
operator: , [4001,4002]
===
match
---
trailer [1599,1604]
trailer [1599,1604]
===
match
---
atom [14759,14803]
atom [15116,15160]
===
match
---
argument [4833,4842]
argument [4833,4842]
===
match
---
atom [12949,12985]
atom [13306,13342]
===
match
---
argument [8702,8708]
argument [9059,9065]
===
match
---
operator: , [2790,2791]
operator: , [2790,2791]
===
match
---
string: "File awesome.png saved" [6172,6196]
string: "File awesome.png saved" [6529,6553]
===
match
---
operator: , [14198,14199]
operator: , [14555,14556]
===
match
---
arith_expr [10764,10788]
arith_expr [11121,11145]
===
match
---
operator: , [1405,1406]
operator: , [1405,1406]
===
match
---
atom_expr [15008,15341]
atom_expr [15365,15698]
===
match
---
name: timespec [15977,15985]
name: timespec [16334,16342]
===
match
---
name: __file__ [1781,1789]
name: __file__ [1781,1789]
===
match
---
operator: + [10933,10934]
operator: + [11290,11291]
===
match
---
name: settings [17379,17387]
name: settings [17736,17744]
===
match
---
trailer [6505,6507]
trailer [6862,6864]
===
match
---
trailer [5288,5303]
trailer [5645,5660]
===
match
---
name: test_show_dag_print [5222,5241]
name: test_show_dag_print [5579,5598]
===
match
---
name: test_dag_test [18204,18217]
name: test_dag_test [18561,18574]
===
match
---
simple_stmt [8614,8660]
simple_stmt [8971,9017]
===
match
---
name: get_dag [9051,9058]
name: get_dag [9408,9415]
===
match
---
trailer [9112,9123]
trailer [9469,9480]
===
match
---
simple_stmt [16759,16787]
simple_stmt [17116,17144]
===
match
---
simple_stmt [898,924]
simple_stmt [898,924]
===
match
---
name: reset_mock [2997,3007]
name: reset_mock [2997,3007]
===
match
---
parameters [2286,2302]
parameters [2286,2302]
===
match
---
name: os [1592,1594]
name: os [1592,1594]
===
match
---
expr_stmt [10167,10236]
expr_stmt [10524,10593]
===
match
---
atom_expr [19990,20000]
atom_expr [20347,20357]
===
match
---
testlist_comp [18297,18362]
testlist_comp [18654,18719]
===
match
---
import_as_names [1392,1420]
import_as_names [1392,1420]
===
match
---
trailer [15976,15996]
trailer [16333,16353]
===
match
---
suite [12280,12404]
suite [12637,12761]
===
match
---
name: models [1110,1116]
name: models [1110,1116]
===
match
---
decorated [1936,2102]
decorated [1936,2102]
===
match
---
trailer [15012,15019]
trailer [15369,15376]
===
match
---
trailer [7678,7680]
trailer [8035,8037]
===
match
---
name: conf_vars [12830,12839]
name: conf_vars [13187,13196]
===
match
---
operator: , [2580,2581]
operator: , [2580,2581]
===
match
---
operator: , [11445,11446]
operator: , [11802,11803]
===
match
---
name: dag_id [7425,7431]
name: dag_id [7782,7788]
===
match
---
atom [10895,10920]
atom [11252,11277]
===
match
---
trailer [4355,4368]
trailer [4355,4368]
===
match
---
simple_stmt [18262,18365]
simple_stmt [18619,18722]
===
match
---
trailer [20204,20219]
trailer [20561,20576]
===
match
---
trailer [10747,10749]
trailer [11104,11106]
===
match
---
name: dagbag [3029,3035]
name: dagbag [3029,3035]
===
match
---
name: dag_command [17027,17038]
name: dag_command [17384,17395]
===
match
---
name: out [12780,12783]
name: out [13137,13140]
===
match
---
trailer [14874,14899]
trailer [15231,15256]
===
match
---
operator: , [3594,3595]
operator: , [3594,3595]
===
match
---
string: 'unpause' [14768,14777]
string: 'unpause' [15125,15134]
===
match
---
atom_expr [11816,11834]
atom_expr [12173,12191]
===
match
---
name: dag_show [6765,6773]
name: dag_show [7122,7130]
===
match
---
testlist_comp [15070,15308]
testlist_comp [15427,15665]
===
match
---
expr_stmt [10653,10671]
expr_stmt [11010,11028]
===
match
---
operator: , [14267,14268]
operator: , [14624,14625]
===
match
---
argument [2557,2580]
argument [2557,2580]
===
match
---
comparison [6172,6203]
comparison [6529,6560]
===
match
---
string: 'trigger_dag_xxx' [16490,16507]
string: 'trigger_dag_xxx' [16847,16864]
===
match
---
suite [5248,5641]
suite [5605,5998]
===
match
---
comparison [13251,13299]
comparison [13608,13656]
===
match
---
atom_expr [10094,10130]
atom_expr [10451,10487]
===
match
---
name: days [8702,8706]
name: days [9059,9063]
===
match
---
comparison [15639,15668]
comparison [15996,16025]
===
match
---
trailer [14994,15352]
trailer [15351,15709]
===
match
---
name: dag_next_execution [12087,12105]
name: dag_next_execution [12444,12462]
===
match
---
string: 'yaml' [12978,12984]
string: 'yaml' [13335,13341]
===
match
---
string: '--run-id=test_trigger_dag' [15174,15201]
string: '--run-id=test_trigger_dag' [15531,15558]
===
match
---
operator: = [18871,18872]
operator: = [19228,19229]
===
match
---
funcdef [17838,18069]
funcdef [18195,18426]
===
match
---
name: isoformat [11026,11035]
name: isoformat [11383,11392]
===
match
---
name: NamedTemporaryFile [17420,17438]
name: NamedTemporaryFile [17777,17795]
===
match
---
simple_stmt [17872,18069]
simple_stmt [18229,18426]
===
match
---
trailer [17589,17623]
trailer [17946,17980]
===
match
---
string: "None" [10547,10553]
string: "None" [10904,10910]
===
match
---
name: parser [5358,5364]
name: parser [5715,5721]
===
match
---
operator: = [1993,1994]
operator: = [1993,1994]
===
match
---
string: 'list-jobs' [17779,17790]
string: 'list-jobs' [18136,18147]
===
match
---
operator: , [18895,18896]
operator: , [19252,19253]
===
match
---
operator: , [15341,15342]
operator: , [15698,15699]
===
match
---
string: 'load_examples' [12430,12445]
string: 'load_examples' [12787,12802]
===
match
---
trailer [14758,14804]
trailer [15115,15161]
===
match
---
trailer [12507,12514]
trailer [12864,12871]
===
match
---
trailer [11316,11330]
trailer [11673,11687]
===
match
---
trailer [16238,16250]
trailer [16595,16607]
===
match
---
name: args [10351,10355]
name: args [10708,10712]
===
match
---
with_item [13000,13056]
with_item [13357,13413]
===
match
---
arith_expr [10896,10919]
arith_expr [11253,11276]
===
match
---
funcdef [12881,13334]
funcdef [13238,13691]
===
match
---
simple_stmt [10094,10131]
simple_stmt [10451,10488]
===
match
---
name: DEFAULT_DATE [2603,2615]
name: DEFAULT_DATE [2603,2615]
===
match
---
name: mock [6210,6214]
name: mock [6567,6571]
===
match
---
trailer [6634,6644]
trailer [6991,7001]
===
match
---
simple_stmt [13244,13300]
simple_stmt [13601,13657]
===
match
---
expr_stmt [6611,6669]
expr_stmt [6968,7026]
===
match
---
string: "airflow.cli.commands.dag_command.get_dag" [18152,18194]
string: "airflow.cli.commands.dag_command.get_dag" [18509,18551]
===
match
---
string: 'dags' [11924,11930]
string: 'dags' [12281,12287]
===
match
---
name: isoformat [3742,3751]
name: isoformat [3742,3751]
===
match
---
argument [18917,18949]
argument [19274,19306]
===
match
---
name: self [9101,9105]
name: self [9458,9462]
===
match
---
trailer [4294,4296]
trailer [4294,4296]
===
match
---
name: mock_run [3819,3827]
name: mock_run [3819,3827]
===
match
---
name: mock_run [2988,2996]
name: mock_run [2988,2996]
===
match
---
testlist_comp [17956,18022]
testlist_comp [18313,18379]
===
match
---
string: 'dags' [18297,18303]
string: 'dags' [18654,18660]
===
match
---
trailer [6802,6813]
trailer [7159,7170]
===
match
---
simple_stmt [4715,5183]
simple_stmt [4715,5183]
===
match
---
simple_stmt [10020,10082]
simple_stmt [10377,10439]
===
match
---
simple_stmt [2988,3010]
simple_stmt [2988,3010]
===
match
---
arith_expr [11000,11024]
arith_expr [11357,11381]
===
match
---
operator: @ [18140,18141]
operator: @ [18497,18498]
===
match
---
trailer [16854,16865]
trailer [17211,17222]
===
match
---
argument [20187,20219]
argument [20544,20576]
===
match
---
trailer [1486,1491]
trailer [1486,1491]
===
match
---
simple_stmt [10320,10357]
simple_stmt [10677,10714]
===
match
---
atom_expr [3024,3068]
atom_expr [3024,3068]
===
match
---
name: dag_delete [17556,17566]
name: dag_delete [17913,17923]
===
match
---
trailer [19568,19583]
trailer [19925,19940]
===
match
---
operator: , [10204,10205]
operator: , [10561,10562]
===
match
---
simple_stmt [8460,8566]
simple_stmt [8817,8923]
===
match
---
trailer [10331,10350]
trailer [10688,10707]
===
match
---
name: temp_stdout [12696,12707]
name: temp_stdout [13053,13064]
===
match
---
name: in_ [12341,12344]
name: in_ [12698,12701]
===
match
---
name: donot_pickle [2689,2701]
name: donot_pickle [2689,2701]
===
match
---
name: dag_backfill [3907,3919]
name: dag_backfill [3907,3919]
===
match
---
operator: , [4694,4695]
operator: , [4694,4695]
===
match
---
trailer [1734,1739]
trailer [1734,1739]
===
match
---
trailer [2996,3007]
trailer [2996,3007]
===
match
---
simple_stmt [5517,5591]
simple_stmt [5874,5948]
===
match
---
comparison [12176,12203]
comparison [12533,12560]
===
match
---
argument [4925,4958]
argument [4925,4958]
===
match
---
arglist [15048,15327]
arglist [15405,15684]
===
match
---
name: DEFAULT_DATE [17998,18010]
name: DEFAULT_DATE [18355,18367]
===
match
---
trailer [11178,11187]
trailer [11535,11544]
===
match
---
dotted_name [1009,1029]
dotted_name [1009,1029]
===
match
---
suite [3135,3635]
suite [3135,3635]
===
match
---
operator: , [19441,19442]
operator: , [19798,19799]
===
match
---
name: subdir [19754,19760]
name: subdir [20111,20117]
===
match
---
suite [6401,7123]
suite [6758,7480]
===
match
---
name: mock [6491,6495]
name: mock [6848,6852]
===
match
---
atom_expr [7862,8321]
atom_expr [8219,8678]
===
match
---
name: stdout [3653,3659]
name: stdout [3653,3659]
===
match
---
string: 'list-jobs' [14187,14198]
string: 'list-jobs' [14544,14555]
===
match
---
string: '--no-backfill' [13797,13812]
string: '--no-backfill' [14154,14169]
===
match
---
expr_stmt [2065,2101]
expr_stmt [2065,2101]
===
match
---
simple_stmt [12919,12987]
simple_stmt [13276,13344]
===
match
---
string: "airflow.cli.commands.dag_command.DAG.run" [7140,7182]
string: "airflow.cli.commands.dag_command.DAG.run" [7497,7539]
===
match
---
simple_stmt [12496,12566]
simple_stmt [12853,12923]
===
match
---
name: cli_parser [993,1003]
name: cli_parser [993,1003]
===
match
---
name: self [13621,13625]
name: self [13978,13982]
===
match
---
name: dag_test [18385,18393]
name: dag_test [18742,18750]
===
match
---
atom_expr [1764,1790]
atom_expr [1764,1790]
===
match
---
trailer [16748,16750]
trailer [17105,17107]
===
match
---
operator: = [8277,8278]
operator: = [8634,8635]
===
match
---
operator: = [6122,6123]
operator: = [6479,6480]
===
match
---
name: temp_stdout [13120,13131]
name: temp_stdout [13477,13488]
===
match
---
name: add [17467,17470]
name: add [17824,17827]
===
match
---
operator: , [19954,19955]
operator: , [20311,20312]
===
match
---
name: call [19749,19753]
name: call [20106,20110]
===
match
---
operator: @ [2107,2108]
operator: @ [2107,2108]
===
match
---
name: data_interval_start [15947,15966]
name: data_interval_start [16304,16323]
===
match
---
name: isoformat [18011,18020]
name: isoformat [18368,18377]
===
match
---
trailer [7894,8321]
trailer [8251,8678]
===
match
---
atom_expr [6611,6657]
atom_expr [6968,7014]
===
match
---
name: dag_command [7789,7800]
name: dag_command [8146,8157]
===
match
---
comparison [20412,20430]
comparison [20769,20787]
===
match
---
name: dag_ids [11179,11186]
name: dag_ids [11536,11543]
===
match
---
argument [4687,4694]
argument [4687,4694]
===
match
---
trailer [5807,5809]
trailer [6164,6166]
===
match
---
name: db [1382,1384]
name: db [1382,1384]
===
match
---
trailer [5454,5456]
trailer [5811,5813]
===
match
---
trailer [12660,12671]
trailer [13017,13028]
===
match
---
string: 'example_bash_operator' [3044,3067]
string: 'example_bash_operator' [3044,3067]
===
match
---
operator: , [11481,11482]
operator: , [11838,11839]
===
match
---
argument [9491,9500]
argument [9848,9857]
===
match
---
string: """         Test that CLI respects -B argument and raises on interaction with depends_on_past         """ [8460,8565]
string: """         Test that CLI respects -B argument and raises on interaction with depends_on_past         """ [8817,8922]
===
match
---
dictorsetmaker [15655,15667]
dictorsetmaker [16012,16024]
===
match
---
string: 'dags' [17771,17777]
string: 'dags' [18128,18134]
===
match
---
name: execution_date [18616,18630]
name: execution_date [18973,18987]
===
match
---
name: start_date [2557,2567]
name: start_date [2557,2567]
===
match
---
name: start_date [8854,8864]
name: start_date [9211,9221]
===
match
---
trailer [12154,12156]
trailer [12511,12513]
===
match
---
operator: = [4806,4807]
operator: = [4806,4807]
===
match
---
string: 'next-execution' [10206,10222]
string: 'next-execution' [10563,10579]
===
match
---
operator: , [12555,12556]
operator: , [12912,12913]
===
match
---
atom_expr [17471,17501]
atom_expr [17828,17858]
===
match
---
expr_stmt [6891,6919]
expr_stmt [7248,7276]
===
match
---
funcdef [5709,6204]
funcdef [6066,6561]
===
match
---
operator: , [3266,3267]
operator: , [3266,3267]
===
match
---
trailer [6956,6961]
trailer [7313,7318]
===
match
---
operator: , [5736,5737]
operator: , [6093,6094]
===
match
---
operator: = [8044,8045]
operator: = [8401,8402]
===
match
---
operator: = [5044,5045]
operator: = [5044,5045]
===
match
---
name: self [14736,14740]
name: self [15093,15097]
===
match
---
operator: = [2935,2936]
operator: = [2935,2936]
===
match
---
trailer [1780,1790]
trailer [1780,1790]
===
match
---
name: self [17932,17936]
name: self [18289,18293]
===
match
---
simple_stmt [8574,8606]
simple_stmt [8931,8963]
===
match
---
argument [12377,12402]
argument [12734,12759]
===
match
---
name: path [1701,1705]
name: path [1701,1705]
===
match
---
name: DagRunType [1303,1313]
name: DagRunType [1303,1313]
===
match
---
param [6389,6399]
param [6746,6756]
===
match
---
atom_expr [14013,14048]
atom_expr [14370,14405]
===
match
---
dotted_name [1054,1072]
dotted_name [1054,1072]
===
match
---
testlist_comp [12842,12865]
testlist_comp [13199,13222]
===
match
---
number: 0 [17695,17696]
number: 0 [18052,18053]
===
match
---
name: classmethod [2108,2119]
name: classmethod [2108,2119]
===
match
---
atom_expr [13621,14004]
atom_expr [13978,14361]
===
match
---
number: 0 [16967,16968]
number: 0 [17324,17325]
===
match
---
testlist_comp [14920,14928]
testlist_comp [15277,15285]
===
match
---
argument [10912,10918]
argument [11269,11275]
===
match
---
trailer [7756,7763]
trailer [8113,8120]
===
match
---
name: parse_args [5365,5375]
name: parse_args [5722,5732]
===
match
---
suite [12910,13334]
suite [13267,13691]
===
match
---
trailer [18934,18949]
trailer [19291,19306]
===
match
---
string: '--exec-date=2021-06-04T09:00:00+08:00' [15223,15262]
string: '--exec-date=2021-06-04T09:00:00+08:00' [15580,15619]
===
match
---
name: call [18479,18483]
name: call [18836,18840]
===
match
---
name: dags [14661,14665]
name: dags [15018,15022]
===
match
---
trailer [5357,5364]
trailer [5714,5721]
===
match
---
trailer [15606,15623]
trailer [15963,15980]
===
match
---
name: i [11832,11833]
name: i [12189,12190]
===
match
---
name: end_date [18652,18660]
name: end_date [19009,19017]
===
match
---
argument [8171,8189]
argument [8528,8546]
===
match
---
operator: == [17692,17694]
operator: == [18049,18051]
===
match
---
operator: = [13619,13620]
operator: = [13976,13977]
===
match
---
name: test_trigger_dag [14939,14955]
name: test_trigger_dag [15296,15312]
===
match
---
trailer [18725,18730]
trailer [19082,19087]
===
match
---
expr_stmt [1574,1646]
expr_stmt [1574,1646]
===
match
---
param [6372,6388]
param [6729,6745]
===
match
---
operator: , [10222,10223]
operator: , [10579,10580]
===
match
---
atom_expr [12028,12041]
atom_expr [12385,12398]
===
match
---
arith_expr [7483,7515]
arith_expr [7840,7872]
===
match
---
trailer [18425,18442]
trailer [18782,18799]
===
match
---
arglist [7814,7851]
arglist [8171,8208]
===
match
---
dotted_name [8328,8338]
dotted_name [8685,8695]
===
match
---
trailer [14665,14690]
trailer [15022,15047]
===
match
---
name: out [13296,13299]
name: out [13653,13656]
===
match
---
trailer [18384,18393]
trailer [18741,18750]
===
match
---
atom_expr [15445,15458]
atom_expr [15802,15815]
===
match
---
expr_stmt [18262,18364]
expr_stmt [18619,18721]
===
match
---
atom_expr [10375,10397]
atom_expr [10732,10754]
===
match
---
with_stmt [12247,12404]
with_stmt [12604,12761]
===
match
---
operator: , [6112,6113]
operator: , [6469,6470]
===
match
---
operator: , [18303,18304]
operator: , [18660,18661]
===
match
---
string: 'awesome' [6123,6132]
string: 'awesome' [6480,6489]
===
match
---
param [17857,17861]
param [18214,18218]
===
match
---
trailer [5779,5795]
trailer [6136,6152]
===
match
---
name: self [14087,14091]
name: self [14444,14448]
===
match
---
name: temp_stdout [5814,5825]
name: temp_stdout [6171,6182]
===
match
---
operator: , [4673,4674]
operator: , [4673,4674]
===
match
---
trailer [7017,7029]
trailer [7374,7386]
===
match
---
operator: , [15307,15308]
operator: , [15664,15665]
===
match
---
trailer [1568,1572]
trailer [1568,1572]
===
match
---
name: redirect_stdout [12012,12027]
name: redirect_stdout [12369,12384]
===
match
---
name: dag_state [17905,17914]
name: dag_state [18262,18271]
===
match
---
trailer [16847,16854]
trailer [17204,17211]
===
match
---
atom_expr [5769,5810]
atom_expr [6126,6167]
===
match
---
operator: { [19113,19114]
operator: { [19470,19471]
===
match
---
operator: = [11205,11206]
operator: = [11562,11563]
===
match
---
operator: , [2754,2755]
operator: , [2754,2755]
===
match
---
operator: , [3302,3303]
operator: , [3302,3303]
===
match
---
name: now [11000,11003]
name: now [11357,11360]
===
match
---
trailer [17438,17440]
trailer [17795,17797]
===
match
---
name: DM [17321,17323]
name: DM [17678,17680]
===
match
---
param [17725,17729]
param [18082,18086]
===
match
---
name: self [18273,18277]
name: self [18630,18634]
===
match
---
name: patch [19049,19054]
name: patch [19406,19411]
===
match
---
operator: = [3651,3652]
operator: = [3651,3652]
===
match
---
expr_stmt [19647,19673]
expr_stmt [20004,20030]
===
match
---
name: session [17515,17522]
name: session [17872,17879]
===
match
---
name: temp_stdout [10375,10386]
name: temp_stdout [10732,10743]
===
match
---
name: cli_args [18926,18934]
name: cli_args [19283,19291]
===
match
---
trailer [1517,1528]
trailer [1517,1528]
===
match
---
atom_expr [7660,7680]
atom_expr [8017,8037]
===
match
---
parameters [16658,16664]
parameters [17015,17021]
===
match
---
atom_expr [20350,20394]
atom_expr [20707,20751]
===
match
---
trailer [7800,7813]
trailer [8157,8170]
===
match
---
name: delay_on_limit_secs [4856,4875]
name: delay_on_limit_secs [4856,4875]
===
match
---
name: mock_run [7862,7870]
name: mock_run [8219,8227]
===
match
---
suite [2303,5213]
suite [2303,5213]
===
match
---
atom_expr [2065,2075]
atom_expr [2065,2075]
===
match
---
operator: , [6854,6855]
operator: , [7211,7212]
===
match
---
simple_stmt [6410,6471]
simple_stmt [6767,6828]
===
match
---
name: test_cli_backfill_depends_on_past [7192,7225]
name: test_cli_backfill_depends_on_past [7549,7582]
===
match
---
trailer [19488,19498]
trailer [19845,19855]
===
match
---
string: "None" [10815,10821]
string: "None" [11172,11178]
===
match
---
expr_stmt [11893,11983]
expr_stmt [12250,12340]
===
match
---
dotted_name [1189,1210]
dotted_name [1189,1210]
===
match
---
string: """         Test that CLI respects -I argument          We just check we call dag.run() right. The behaviour of that kwarg is         tested in test_jobs         """ [7251,7416]
string: """         Test that CLI respects -I argument          We just check we call dag.run() right. The behaviour of that kwarg is         tested in test_jobs         """ [7608,7773]
===
match
---
operator: , [4450,4451]
operator: , [4450,4451]
===
match
---
arglist [18596,18731]
arglist [18953,19088]
===
match
---
with_item [3083,3134]
with_item [3083,3134]
===
match
---
atom_expr [2033,2056]
atom_expr [2033,2056]
===
match
---
name: dagrun [16043,16049]
name: dagrun [16400,16406]
===
match
---
string: "SOURCE" [20412,20420]
string: "SOURCE" [20769,20777]
===
match
---
atom_expr [11207,11231]
atom_expr [11564,11588]
===
match
---
operator: = [8183,8184]
operator: = [8540,8541]
===
match
---
trailer [12514,12525]
trailer [12871,12882]
===
match
---
name: args [13614,13618]
name: args [13971,13975]
===
match
---
operator: , [19776,19777]
operator: , [20133,20134]
===
match
---
operator: , [11131,11132]
operator: , [11488,11489]
===
match
---
with_stmt [16977,17156]
with_stmt [17334,17513]
===
match
---
string: "airflow.cli.commands.dag_command.render_dag" [5658,5703]
string: "airflow.cli.commands.dag_command.render_dag" [6015,6060]
===
match
---
name: mock [2210,2214]
name: mock [2210,2214]
===
match
---
operator: @ [12409,12410]
operator: @ [12766,12767]
===
match
---
name: dag_delete [17039,17049]
name: dag_delete [17396,17406]
===
match
---
name: TestCase [1921,1929]
name: TestCase [1921,1929]
===
match
---
atom [13458,13581]
atom [13815,13938]
===
match
---
trailer [1763,1791]
trailer [1763,1791]
===
match
---
assert_stmt [3679,3767]
assert_stmt [3679,3767]
===
match
---
trailer [12145,12154]
trailer [12502,12511]
===
match
---
name: redirect_stdout [5273,5288]
name: redirect_stdout [5630,5645]
===
match
---
name: expected_output [10680,10695]
name: expected_output [11037,11052]
===
match
---
operator: , [7842,7843]
operator: , [8199,8200]
===
match
---
trailer [14862,14869]
trailer [15219,15226]
===
match
---
string: '--run-id' [16454,16464]
string: '--run-id' [16811,16821]
===
match
---
arglist [17067,17141]
arglist [17424,17498]
===
match
---
testlist_comp [10895,11132]
testlist_comp [11252,11489]
===
match
---
name: parse_args [17579,17589]
name: parse_args [17936,17946]
===
match
---
simple_stmt [13308,13334]
simple_stmt [13665,13691]
===
match
---
assert_stmt [16909,16968]
assert_stmt [17266,17325]
===
match
---
name: session [12298,12305]
name: session [12655,12662]
===
match
---
atom_expr [10224,10234]
atom_expr [10581,10591]
===
match
---
number: 2 [10970,10971]
number: 2 [11327,11328]
===
match
---
simple_stmt [6753,6883]
simple_stmt [7110,7240]
===
match
---
operator: , [15107,15108]
operator: , [15464,15465]
===
match
---
string: '--end-date' [13904,13916]
string: '--end-date' [14261,14273]
===
match
---
atom_expr [19542,19583]
atom_expr [19899,19940]
===
match
---
name: patch [18080,18085]
name: patch [18437,18442]
===
match
---
operator: = [10916,10917]
operator: = [11273,11274]
===
match
---
operator: , [7551,7552]
operator: , [7908,7909]
===
match
---
name: tearDownClass [2128,2141]
name: tearDownClass [2128,2141]
===
match
---
name: filter [10047,10053]
name: filter [10404,10410]
===
match
---
name: parse_args [3202,3212]
name: parse_args [3202,3212]
===
match
---
string: "None" [11105,11111]
string: "None" [11462,11468]
===
match
---
param [12904,12908]
param [13261,13265]
===
match
---
name: dag_backfill [7801,7813]
name: dag_backfill [8158,8170]
===
match
---
name: now [10653,10656]
name: now [11010,11013]
===
match
---
string: 'example_bash_operator' [5917,5940]
string: 'example_bash_operator' [6274,6297]
===
match
---
name: dag_folder_path [1621,1636]
name: dag_folder_path [1621,1636]
===
match
---
assert_stmt [15497,15532]
assert_stmt [15854,15889]
===
match
---
operator: , [2968,2969]
operator: , [2968,2969]
===
match
---
atom_expr [3819,3847]
atom_expr [3819,3847]
===
match
---
with_item [12579,12635]
with_item [12936,12992]
===
match
---
name: timedelta [10902,10911]
name: timedelta [11259,11268]
===
match
---
string: 'pause' [14563,14570]
string: 'pause' [14920,14927]
===
match
---
string: '--start-date' [7632,7646]
string: '--start-date' [7989,8003]
===
match
---
trailer [11785,11794]
trailer [12142,12151]
===
match
---
name: getvalue [11786,11794]
name: getvalue [12143,12151]
===
match
---
simple_stmt [15497,15533]
simple_stmt [15854,15890]
===
match
---
operator: , [13517,13518]
operator: , [13874,13875]
===
match
---
trailer [16802,16809]
trailer [17159,17166]
===
match
---
argument [18484,18506]
argument [18841,18863]
===
match
---
dictorsetmaker [12421,12454]
dictorsetmaker [12778,12811]
===
match
---
string: '--conf' [16533,16541]
string: '--conf' [16890,16898]
===
match
---
atom_expr [10719,10736]
atom_expr [11076,11093]
===
match
---
name: i [11156,11157]
name: i [11513,11514]
===
match
---
simple_stmt [2312,2502]
simple_stmt [2312,2502]
===
match
---
trailer [2474,2476]
trailer [2474,2476]
===
match
---
name: isoformat [10790,10799]
name: isoformat [11147,11156]
===
match
---
atom_expr [17067,17140]
atom_expr [17424,17497]
===
match
---
name: self [3190,3194]
name: self [3190,3194]
===
match
---
suite [16174,16634]
suite [16531,16991]
===
match
---
operator: = [6489,6490]
operator: = [6846,6847]
===
match
---
string: "my_dag_id" [16702,16713]
string: "my_dag_id" [17059,17070]
===
match
---
string: '--num-executions' [11958,11976]
string: '--num-executions' [12315,12333]
===
match
---
number: 1 [7513,7514]
number: 1 [7870,7871]
===
match
---
trailer [11089,11091]
trailer [11446,11448]
===
match
---
dotted_name [974,985]
dotted_name [974,985]
===
match
---
number: 1 [8657,8658]
number: 1 [9014,9015]
===
match
---
name: isoformat [15733,15742]
name: isoformat [16090,16099]
===
match
---
name: self [14858,14862]
name: self [15215,15219]
===
match
---
param [16659,16663]
param [17016,17020]
===
match
---
name: parse_args [4394,4404]
name: parse_args [4394,4404]
===
match
---
name: end_date [7941,7949]
name: end_date [8298,8306]
===
match
---
comparison [5524,5590]
comparison [5881,5947]
===
match
---
name: mock_popen [6611,6621]
name: mock_popen [6968,6978]
===
match
---
trailer [6693,6709]
trailer [7050,7066]
===
match
---
argument [18804,18839]
argument [19161,19196]
===
match
---
operator: , [3463,3464]
operator: , [3463,3464]
===
match
---
operator: , [13486,13487]
operator: , [13843,13844]
===
match
---
trailer [17914,18038]
trailer [18271,18395]
===
match
---
operator: , [2908,2909]
operator: , [2908,2909]
===
match
---
operator: , [1130,1131]
operator: , [1130,1131]
===
match
---
atom [14710,14719]
atom [15067,15076]
===
match
---
trailer [16077,16097]
trailer [16434,16454]
===
match
---
expr_stmt [15407,15487]
expr_stmt [15764,15844]
===
match
---
suite [13372,14049]
suite [13729,14406]
===
match
---
dotted_name [1319,1342]
dotted_name [1319,1342]
===
match
---
operator: , [8840,8841]
operator: , [9197,9198]
===
match
---
operator: , [7726,7727]
operator: , [8083,8084]
===
match
---
trailer [1443,1448]
trailer [1443,1448]
===
match
---
operator: = [6457,6458]
operator: = [6814,6815]
===
match
---
decorator [19043,19169]
decorator [19400,19526]
===
match
---
atom [13657,13994]
atom [14014,14351]
===
match
---
operator: , [5383,5384]
operator: , [5740,5741]
===
match
---
operator: , [15326,15327]
operator: , [15683,15684]
===
match
---
name: parse_args [14748,14758]
name: parse_args [15105,15115]
===
match
---
assert_stmt [3776,3809]
assert_stmt [3776,3809]
===
match
---
name: output [20424,20430]
name: output [20781,20787]
===
match
---
trailer [17661,17671]
trailer [18018,18028]
===
match
---
name: create_session [9979,9993]
name: create_session [10336,10350]
===
match
---
name: days [10912,10916]
name: days [11269,11273]
===
match
---
dotted_name [18141,18151]
dotted_name [18498,18508]
===
match
---
trailer [3112,3121]
trailer [3112,3121]
===
match
---
trailer [18020,18022]
trailer [18377,18379]
===
match
---
name: MANUAL [15578,15584]
name: MANUAL [15935,15941]
===
match
---
name: join [1600,1604]
name: join [1600,1604]
===
match
---
operator: , [16888,16889]
operator: , [17245,17246]
===
match
---
name: synchronize_session [10104,10123]
name: synchronize_session [10461,10480]
===
match
---
name: redirect_stdout [5780,5795]
name: redirect_stdout [6137,6152]
===
match
---
string: 'example_bash_operator' [14244,14267]
string: 'example_bash_operator' [14601,14624]
===
match
---
trailer [9180,9608]
trailer [9537,9965]
===
match
---
string: 'dags' [17591,17597]
string: 'dags' [17948,17954]
===
match
---
with_item [15366,15393]
with_item [15723,15750]
===
match
---
argument [19922,19954]
argument [20279,20311]
===
match
---
name: cli_args [19877,19885]
name: cli_args [20234,20242]
===
match
---
name: now [10896,10899]
name: now [11253,11256]
===
match
---
atom_expr [13120,13142]
atom_expr [13477,13499]
===
match
---
name: dag_next_execution [10332,10350]
name: dag_next_execution [10689,10707]
===
match
---
argument [7908,7927]
argument [8265,8284]
===
match
---
operator: , [5950,5951]
operator: , [6307,6308]
===
match
---
operator: , [9597,9598]
operator: , [9954,9955]
===
match
---
operator: , [7646,7647]
operator: , [8003,8004]
===
match
---
param [19346,19360]
param [19703,19717]
===
match
---
argument [15743,15761]
argument [16100,16118]
===
match
---
operator: , [5111,5112]
operator: , [5111,5112]
===
match
---
number: 1.0 [2672,2675]
number: 1.0 [2672,2675]
===
match
---
operator: = [7512,7513]
operator: = [7869,7870]
===
match
---
atom_expr [3729,3753]
atom_expr [3729,3753]
===
match
---
string: 'state' [17964,17971]
string: 'state' [18321,18328]
===
match
---
atom_expr [2452,2476]
atom_expr [2452,2476]
===
match
---
atom_expr [12298,12354]
atom_expr [12655,12711]
===
match
---
atom_expr [12367,12403]
atom_expr [12724,12760]
===
match
---
name: io [5796,5798]
name: io [6153,6155]
===
match
---
operator: , [13779,13780]
operator: , [14136,14137]
===
match
---
trailer [10067,10071]
trailer [10424,10428]
===
match
---
trailer [11679,11681]
trailer [12036,12038]
===
match
---
name: patch [8333,8338]
name: patch [8690,8695]
===
match
---
comparison [16916,16968]
comparison [17273,17325]
===
match
---
name: dags [14870,14874]
name: dags [15227,15231]
===
match
---
trailer [16201,16213]
trailer [16558,16570]
===
match
---
simple_stmt [12792,12824]
simple_stmt [13149,13181]
===
match
---
atom [10948,10973]
atom [11305,11330]
===
match
---
simple_stmt [825,841]
simple_stmt [825,841]
===
match
---
simple_stmt [841,857]
simple_stmt [841,857]
===
match
---
atom_expr [4169,4193]
atom_expr [4169,4193]
===
match
---
simple_stmt [20405,20431]
simple_stmt [20762,20788]
===
match
---
operator: , [7230,7231]
operator: , [7587,7588]
===
match
---
atom_expr [11715,11751]
atom_expr [12072,12108]
===
match
---
testlist_comp [19435,19517]
testlist_comp [19792,19874]
===
match
---
name: parser [16273,16279]
name: parser [16630,16636]
===
match
---
argument [11431,11445]
argument [11788,11802]
===
match
---
name: temp_stdout [13045,13056]
name: temp_stdout [13402,13413]
===
match
---
trailer [7668,7678]
trailer [8025,8035]
===
match
---
argument [9584,9597]
argument [9941,9954]
===
match
---
name: patch [5652,5657]
name: patch [6009,6014]
===
match
---
string: 'example_bash_operator' [14779,14802]
string: 'example_bash_operator' [15136,15159]
===
match
---
name: self [9638,9642]
name: self [9995,9999]
===
match
---
name: session [17459,17466]
name: session [17816,17823]
===
match
---
trailer [6721,6723]
trailer [7078,7080]
===
match
---
assert_stmt [13213,13235]
assert_stmt [13570,13592]
===
match
---
name: pipe [6957,6961]
name: pipe [7314,7318]
===
match
---
atom_expr [11006,11024]
atom_expr [11363,11381]
===
match
---
name: patch [2215,2220]
name: patch [2215,2220]
===
match
---
name: dirname [1724,1731]
name: dirname [1724,1731]
===
match
---
trailer [17395,17397]
trailer [17752,17754]
===
match
---
name: call [19832,19836]
name: call [20189,20193]
===
match
---
atom_expr [19931,19954]
atom_expr [20288,20311]
===
match
---
assert_stmt [14851,14929]
assert_stmt [15208,15286]
===
match
---
name: delay_on_limit_secs [7995,8014]
name: delay_on_limit_secs [8352,8371]
===
match
---
operator: , [12428,12429]
operator: , [12785,12786]
===
match
---
simple_stmt [787,805]
simple_stmt [787,805]
===
match
---
argument [2861,2870]
argument [2861,2870]
===
match
---
name: get_dag [3036,3043]
name: get_dag [3036,3043]
===
match
---
string: "paused" [13220,13228]
string: "paused" [13577,13585]
===
match
---
string: 'example_bash_operator' [17973,17996]
string: 'example_bash_operator' [18330,18353]
===
match
---
funcdef [14494,14930]
funcdef [14851,15287]
===
match
---
name: mock_run [4268,4276]
name: mock_run [4268,4276]
===
match
---
name: key [16781,16784]
name: key [17138,17141]
===
match
---
operator: , [11111,11112]
operator: , [11468,11469]
===
match
---
operator: , [18539,18540]
operator: , [18896,18897]
===
match
---
name: query [16924,16929]
name: query [17281,17286]
===
match
---
param [14509,14513]
param [14866,14870]
===
match
---
trailer [6795,6802]
trailer [7152,7159]
===
match
---
operator: , [14925,14926]
operator: , [15282,15283]
===
match
---
testlist_comp [3260,3554]
testlist_comp [3260,3554]
===
match
---
argument [9194,9215]
argument [9551,9572]
===
match
---
atom_expr [20083,20109]
atom_expr [20440,20466]
===
match
---
name: DagRun [10039,10045]
name: DagRun [10396,10402]
===
match
---
operator: , [18630,18631]
operator: , [18987,18988]
===
match
---
name: data_interval_end [16050,16067]
name: data_interval_end [16407,16424]
===
match
---
name: mock [18075,18079]
name: mock [18432,18436]
===
match
---
trailer [15645,15650]
trailer [16002,16007]
===
match
---
argument [15977,15995]
argument [16334,16352]
===
match
---
atom_expr [2078,2101]
atom_expr [2078,2101]
===
match
---
argument [10965,10971]
argument [11322,11328]
===
match
---
trailer [4628,4638]
trailer [4628,4638]
===
match
---
operator: + [10768,10769]
operator: + [11125,11126]
===
match
---
name: start_date [4761,4771]
name: start_date [4761,4771]
===
match
---
name: getvalue [12146,12154]
name: getvalue [12503,12511]
===
match
---
name: parser [3195,3201]
name: parser [3195,3201]
===
match
---
name: dag [3616,3619]
name: dag [3616,3619]
===
match
---
trailer [7507,7515]
trailer [7864,7872]
===
match
---
argument [6100,6112]
argument [6457,6469]
===
match
---
name: dag_backfill [3160,3172]
name: dag_backfill [3160,3172]
===
match
---
expr_stmt [17321,17334]
expr_stmt [17678,17691]
===
match
---
trailer [13010,13026]
trailer [13367,13383]
===
match
---
trailer [2001,2024]
trailer [2001,2024]
===
match
---
string: 'dags' [17956,17962]
string: 'dags' [18313,18319]
===
match
---
import_from [1184,1232]
import_from [1184,1232]
===
match
---
operator: , [20385,20386]
operator: , [20742,20743]
===
match
---
trailer [1448,1492]
trailer [1448,1492]
===
match
---
operator: , [15201,15202]
operator: , [15558,15559]
===
match
---
trailer [1739,1747]
trailer [1739,1747]
===
match
---
simple_stmt [17544,17625]
simple_stmt [17901,17982]
===
match
---
name: dag_command [14013,14024]
name: dag_command [14370,14381]
===
match
---
atom_expr [10955,10972]
atom_expr [11312,11329]
===
match
---
trailer [12340,12344]
trailer [12697,12701]
===
match
---
suite [5826,5982]
suite [6183,6339]
===
match
---
operator: , [8812,8813]
operator: , [9169,9170]
===
match
---
atom [12841,12866]
atom [13198,13223]
===
match
---
number: 0 [6539,6540]
number: 0 [6896,6897]
===
match
---
trailer [4386,4393]
trailer [4386,4393]
===
match
---
operator: = [15751,15752]
operator: = [16108,16109]
===
match
---
name: State [11469,11474]
name: State [11826,11831]
===
match
---
name: mock_executor [19346,19359]
name: mock_executor [19703,19716]
===
match
---
name: mock_run [7232,7240]
name: mock_run [7589,7597]
===
match
---
operator: == [15651,15653]
operator: == [16008,16010]
===
match
---
name: dag_ids [10224,10231]
name: dag_ids [10581,10588]
===
match
---
trailer [11576,11587]
trailer [11933,11944]
===
match
---
name: parse_args [18285,18295]
name: parse_args [18642,18652]
===
match
---
atom_expr [9076,9139]
atom_expr [9433,9496]
===
match
---
arglist [20360,20393]
arglist [20717,20750]
===
match
---
testlist_comp [18474,19013]
testlist_comp [18831,19370]
===
match
---
operator: = [1507,1508]
operator: = [1507,1508]
===
match
---
name: parse_args [15020,15030]
name: parse_args [15377,15387]
===
match
---
atom_expr [16227,16633]
atom_expr [16584,16990]
===
match
---
import_name [825,840]
import_name [825,840]
===
match
---
trailer [1456,1465]
trailer [1456,1465]
===
match
---
atom_expr [16820,16900]
atom_expr [17177,17257]
===
match
---
name: tempfile [832,840]
name: tempfile [832,840]
===
match
---
name: clear_db_dags [2188,2201]
name: clear_db_dags [2188,2201]
===
match
---
arglist [3933,4248]
arglist [3933,4248]
===
match
---
trailer [13026,13041]
trailer [13383,13398]
===
match
---
trailer [3028,3035]
trailer [3028,3035]
===
match
---
arglist [1529,1572]
arglist [1529,1572]
===
match
---
argument [2002,2023]
argument [2002,2023]
===
match
---
argument [6986,6998]
argument [7343,7355]
===
match
---
trailer [13884,13886]
trailer [14241,14243]
===
match
---
name: mock [20350,20354]
name: mock [20707,20711]
===
match
---
operator: , [4226,4227]
operator: , [4226,4227]
===
match
---
operator: , [4879,4880]
operator: , [4879,4880]
===
match
---
expr_stmt [17740,17792]
expr_stmt [18097,18149]
===
match
---
assert_stmt [7103,7122]
assert_stmt [7460,7479]
===
match
---
trailer [13625,13632]
trailer [13982,13989]
===
match
---
simple_stmt [5428,5457]
simple_stmt [5785,5814]
===
match
---
trailer [10920,10930]
trailer [11277,11287]
===
match
---
operator: , [16541,16542]
operator: , [16898,16899]
===
match
---
operator: , [19500,19501]
operator: , [19857,19858]
===
match
---
name: args [17740,17744]
name: args [18097,18101]
===
match
---
name: mock [19240,19244]
name: mock [19597,19601]
===
match
---
name: conf [4833,4837]
name: conf [4833,4837]
===
match
---
name: dagrun [15407,15413]
name: dagrun [15764,15770]
===
match
---
trailer [16988,16995]
trailer [17345,17352]
===
match
---
operator: , [1793,1794]
operator: , [1793,1794]
===
match
---
operator: = [1659,1660]
operator: = [1659,1660]
===
match
---
simple_stmt [19647,19674]
simple_stmt [20004,20031]
===
match
---
trailer [16961,16963]
trailer [17318,17320]
===
match
---
expr_stmt [10861,11142]
expr_stmt [11218,11499]
===
match
---
name: self [17195,17199]
name: self [17552,17556]
===
match
---
argument [19866,19900]
argument [20223,20257]
===
match
---
operator: = [18719,18720]
operator: = [19076,19077]
===
match
---
simple_stmt [2065,2102]
simple_stmt [2065,2102]
===
match
---
atom_expr [12579,12620]
atom_expr [12936,12977]
===
match
---
trailer [5210,5212]
trailer [5210,5212]
===
match
---
trailer [17522,17529]
trailer [17879,17886]
===
match
---
trailer [10973,10983]
trailer [11330,11340]
===
match
---
trailer [17470,17502]
trailer [17827,17859]
===
match
---
operator: , [19474,19475]
operator: , [19831,19832]
===
match
---
atom_expr [7008,7066]
atom_expr [7365,7423]
===
match
---
name: args [14102,14106]
name: args [14459,14463]
===
match
---
name: DEFAULT_DATE [13862,13874]
name: DEFAULT_DATE [14219,14231]
===
match
---
name: verbose [8297,8304]
name: verbose [8654,8661]
===
match
---
decorated [6209,7123]
decorated [6566,7480]
===
match
---
operator: , [7958,7959]
operator: , [8315,8316]
===
match
---
trailer [16809,16811]
trailer [17166,17168]
===
match
---
atom_expr [11469,11481]
atom_expr [11826,11838]
===
match
---
operator: = [16086,16087]
operator: = [16443,16444]
===
match
---
expr_stmt [7746,7779]
expr_stmt [8103,8136]
===
match
---
trailer [1755,1763]
trailer [1755,1763]
===
match
---
suite [17201,17697]
suite [17558,18054]
===
match
---
trailer [11904,11911]
trailer [12261,12268]
===
match
---
trailer [3541,3551]
trailer [3541,3551]
===
match
---
decorated [7128,8322]
decorated [7485,8679]
===
match
---
trailer [14120,14131]
trailer [14477,14488]
===
match
---
trailer [18360,18362]
trailer [18717,18719]
===
match
---
comparison [17893,18058]
comparison [18250,18415]
===
match
---
operator: , [12956,12957]
operator: , [13313,13314]
===
match
---
name: contextlib [19542,19552]
name: contextlib [19899,19909]
===
match
---
argument [11395,11413]
argument [11752,11770]
===
match
---
name: now [10713,10716]
name: now [11070,11073]
===
match
---
param [8435,8440]
param [8792,8797]
===
match
---
with_item [5262,5318]
with_item [5619,5675]
===
match
---
trailer [12027,12042]
trailer [12384,12399]
===
match
---
trailer [1747,1792]
trailer [1747,1792]
===
match
---
with_item [12001,12057]
with_item [12358,12414]
===
match
---
name: patch [6284,6289]
name: patch [6641,6646]
===
match
---
trailer [7813,7852]
trailer [8170,8209]
===
match
---
name: parser [14741,14747]
name: parser [15098,15104]
===
match
---
name: DagRunType [15567,15577]
name: DagRunType [15924,15934]
===
match
---
operator: = [18490,18491]
operator: = [18847,18848]
===
match
---
name: rerun_failed_tasks [2884,2902]
name: rerun_failed_tasks [2884,2902]
===
match
---
trailer [14468,14482]
trailer [14825,14839]
===
match
---
argument [16944,16954]
argument [17301,17311]
===
match
---
atom_expr [16982,17013]
atom_expr [17339,17370]
===
match
---
name: dag_id [10061,10067]
name: dag_id [10418,10424]
===
match
---
operator: == [16964,16966]
operator: == [17321,17323]
===
match
---
name: now [10949,10952]
name: now [11306,11309]
===
match
---
trailer [10930,10932]
trailer [11287,11289]
===
match
---
operator: = [11468,11469]
operator: = [11825,11826]
===
match
---
trailer [13632,13643]
trailer [13989,14000]
===
match
---
name: getvalue [12708,12716]
name: getvalue [13065,13073]
===
match
---
atom_expr [17747,17792]
atom_expr [18104,18149]
===
match
---
expr_stmt [1647,1673]
expr_stmt [1647,1673]
===
match
---
trailer [1451,1456]
trailer [1451,1456]
===
match
---
argument [9352,9385]
argument [9709,9742]
===
match
---
import_name [805,814]
import_name [805,814]
===
match
---
simple_stmt [1422,1493]
simple_stmt [1422,1493]
===
match
---
name: rerun_failed_tasks [5087,5105]
name: rerun_failed_tasks [5087,5105]
===
match
---
operator: @ [1936,1937]
operator: @ [1936,1937]
===
match
---
operator: , [11595,11596]
operator: , [11952,11953]
===
match
---
name: mock [18767,18771]
name: mock [19124,19128]
===
match
---
name: test_utils [1325,1335]
name: test_utils [1325,1335]
===
match
---
name: dag_id [7772,7778]
name: dag_id [8129,8135]
===
match
---
trailer [20348,20396]
trailer [20705,20753]
===
match
---
operator: , [20282,20283]
operator: , [20639,20640]
===
match
---
operator: , [16577,16578]
operator: , [16934,16935]
===
match
---
string: 'dags' [7545,7551]
string: 'dags' [7902,7908]
===
match
---
comparison [7082,7094]
comparison [7439,7451]
===
match
---
name: dag_command [3148,3159]
name: dag_command [3148,3159]
===
match
---
operator: , [14777,14778]
operator: , [15134,15135]
===
match
---
atom_expr [18813,18839]
atom_expr [19170,19196]
===
match
---
name: dag_ids [10072,10079]
name: dag_ids [10429,10436]
===
match
---
expr_stmt [10369,10397]
expr_stmt [10726,10754]
===
match
---
name: dagrun [15504,15510]
name: dagrun [15861,15867]
===
match
---
decorator [8327,8383]
decorator [8684,8740]
===
match
---
trailer [13038,13040]
trailer [13395,13397]
===
match
---
name: dag_unpause [14825,14836]
name: dag_unpause [15182,15193]
===
match
---
assert_stmt [12728,12783]
assert_stmt [13085,13140]
===
match
---
atom_expr [3190,3594]
atom_expr [3190,3594]
===
match
---
name: dag_run_state [18706,18719]
name: dag_run_state [19063,19076]
===
match
---
atom [17770,17791]
atom [18127,18148]
===
match
---
trailer [9087,9100]
trailer [9444,9457]
===
match
---
trailer [17049,17155]
trailer [17406,17512]
===
match
---
name: redirect_stdout [19553,19568]
name: redirect_stdout [19910,19925]
===
match
---
name: parse_args [6803,6813]
name: parse_args [7160,7170]
===
match
---
simple_stmt [19387,19529]
simple_stmt [19744,19886]
===
match
---
trailer [6917,6919]
trailer [7274,7276]
===
match
---
comparison [16043,16128]
comparison [16400,16485]
===
match
---
name: self [12904,12908]
name: self [13261,13265]
===
match
---
name: start_date [19866,19876]
name: start_date [20223,20233]
===
match
---
trailer [12305,12311]
trailer [12662,12668]
===
match
---
name: filter [12320,12326]
name: filter [12677,12683]
===
match
---
operator: = [10023,10024]
operator: = [10380,10381]
===
match
---
name: dag_command [16820,16831]
name: dag_command [17177,17188]
===
match
---
with_item [11641,11697]
with_item [11998,12054]
===
match
---
number: 1.0 [8015,8018]
number: 1.0 [8372,8375]
===
match
---
simple_stmt [11201,11232]
simple_stmt [11558,11589]
===
match
---
trailer [14542,14553]
trailer [14899,14910]
===
match
---
name: expected_output_2 [10861,10878]
name: expected_output_2 [11218,11235]
===
match
---
trailer [8864,8874]
trailer [9221,9231]
===
match
---
operator: , [19012,19013]
operator: , [19369,19370]
===
match
---
operator: , [11413,11414]
operator: , [11770,11771]
===
match
---
with_item [12252,12279]
with_item [12609,12636]
===
match
---
expr_stmt [17343,17360]
expr_stmt [17700,17717]
===
match
---
simple_stmt [14729,14805]
simple_stmt [15086,15162]
===
match
---
atom_expr [16843,16899]
atom_expr [17200,17256]
===
match
---
name: isoformat [15967,15976]
name: isoformat [16324,16333]
===
match
---
string: 'example_bash_operator' [18313,18336]
string: 'example_bash_operator' [18670,18693]
===
match
---
name: args [12496,12500]
name: args [12853,12857]
===
match
---
name: execution_date [20205,20219]
name: execution_date [20562,20576]
===
match
---
trailer [11069,11078]
trailer [11426,11435]
===
match
---
trailer [15742,15762]
trailer [16099,16119]
===
match
---
name: parse_args [16855,16865]
name: parse_args [17212,17222]
===
match
---
with_stmt [11996,12157]
with_stmt [12353,12514]
===
match
---
atom_expr [17379,17397]
atom_expr [17736,17754]
===
match
---
operator: = [2749,2750]
operator: = [2749,2750]
===
match
---
name: start_date [9194,9204]
name: start_date [9551,9561]
===
match
---
name: test_pause [14498,14508]
name: test_pause [14855,14865]
===
match
---
decorated [2107,2204]
decorated [2107,2204]
===
match
---
operator: , [4558,4559]
operator: , [4558,4559]
===
match
---
operator: = [4905,4906]
operator: = [4905,4906]
===
match
---
number: 0 [10232,10233]
number: 0 [10589,10590]
===
match
---
atom_expr [12252,12268]
atom_expr [12609,12625]
===
match
---
operator: = [8014,8015]
operator: = [8371,8372]
===
match
---
name: join [1444,1448]
name: join [1444,1448]
===
match
---
operator: = [10123,10124]
operator: = [10480,10481]
===
match
---
name: DagModel [17326,17334]
name: DagModel [17683,17691]
===
match
---
name: run_date [7919,7927]
name: run_date [8276,8284]
===
match
---
trailer [6495,6505]
trailer [6852,6862]
===
match
---
comparison [12735,12783]
comparison [13092,13140]
===
match
---
trailer [17089,17140]
trailer [17446,17497]
===
match
---
name: test_cli_report [12465,12480]
name: test_cli_report [12822,12837]
===
match
---
operator: , [16873,16874]
operator: , [17230,17231]
===
match
---
name: args [14524,14528]
name: args [14881,14885]
===
match
---
operator: , [9500,9501]
operator: , [9857,9858]
===
match
---
trailer [14113,14120]
trailer [14470,14477]
===
match
---
fstring [3686,3757]
fstring [3686,3757]
===
match
---
arglist [15008,15342]
arglist [15365,15699]
===
match
---
operator: , [5915,5916]
operator: , [6272,6273]
===
match
---
string: "example_complex" [12799,12816]
string: "example_complex" [13156,13173]
===
match
---
name: self [10174,10178]
name: self [10531,10535]
===
match
---
trailer [12039,12041]
trailer [12396,12398]
===
match
---
simple_stmt [815,825]
simple_stmt [815,825]
===
match
---
atom_expr [14649,14706]
atom_expr [15006,15063]
===
match
---
simple_stmt [940,969]
simple_stmt [940,969]
===
match
---
operator: = [2902,2903]
operator: = [2902,2903]
===
match
---
trailer [1705,1710]
trailer [1705,1710]
===
match
---
trailer [17657,17661]
trailer [18014,18018]
===
match
---
trailer [16773,16785]
trailer [17130,17142]
===
match
---
atom_expr [1449,1491]
atom_expr [1449,1491]
===
match
---
operator: , [19109,19110]
operator: , [19466,19467]
===
match
---
name: self [2350,2354]
name: self [2350,2354]
===
match
---
operator: , [12964,12965]
operator: , [13321,13322]
===
match
---
name: timezone [1175,1183]
name: timezone [1175,1183]
===
match
---
simple_stmt [13614,14005]
simple_stmt [13971,14362]
===
match
---
name: end_date [4798,4806]
name: end_date [4798,4806]
===
match
---
atom_expr [6897,6919]
atom_expr [7254,7276]
===
match
---
argument [18971,18993]
argument [19328,19350]
===
match
---
name: dagbag [7757,7763]
name: dagbag [8114,8120]
===
match
---
trailer [12086,12105]
trailer [12443,12462]
===
match
---
string: '--yes' [17614,17621]
string: '--yes' [17971,17978]
===
match
---
name: dag_list_dag_runs [14025,14042]
name: dag_list_dag_runs [14382,14399]
===
match
---
string: "airflow.cli.commands.dag_command.get_dag" [19251,19293]
string: "airflow.cli.commands.dag_command.get_dag" [19608,19650]
===
match
---
atom_expr [19683,20307]
atom_expr [20040,20664]
===
match
---
trailer [13953,13967]
trailer [14310,14324]
===
match
---
name: timedelta [11006,11015]
name: timedelta [11363,11372]
===
match
---
parameters [2141,2146]
parameters [2141,2146]
===
match
---
simple_stmt [6891,6920]
simple_stmt [7248,7277]
===
match
---
operator: = [9471,9472]
operator: = [9828,9829]
===
match
---
trailer [18284,18295]
trailer [18641,18652]
===
match
---
atom_expr [9979,9995]
atom_expr [10336,10352]
===
match
---
argument [8264,8283]
argument [8621,8640]
===
match
---
testlist_comp [9677,9900]
testlist_comp [10034,10257]
===
match
---
name: pool [8203,8207]
name: pool [8560,8564]
===
match
---
operator: = [5138,5139]
operator: = [5138,5139]
===
match
---
number: 1.0 [9303,9306]
number: 1.0 [9660,9663]
===
match
---
operator: = [10879,10880]
operator: = [11236,11237]
===
match
---
string: '--start-date' [8826,8840]
string: '--start-date' [9183,9197]
===
match
---
arglist [1538,1548]
arglist [1538,1548]
===
match
---
trailer [14482,14488]
trailer [14839,14845]
===
match
---
trailer [1475,1481]
trailer [1475,1481]
===
match
---
string: 'backfill' [4472,4482]
string: 'backfill' [4472,4482]
===
match
---
name: parse_args [7826,7836]
name: parse_args [8183,8193]
===
match
---
atom [10698,10852]
atom [11055,11209]
===
match
---
name: ignore_first_depends_on_past [4925,4953]
name: ignore_first_depends_on_past [4925,4953]
===
match
---
arglist [9101,9138]
arglist [9458,9495]
===
match
---
dotted_name [5647,5657]
dotted_name [6004,6014]
===
match
---
name: dag_command [5839,5850]
name: dag_command [6196,6207]
===
match
---
operator: , [19809,19810]
operator: , [20166,20167]
===
match
---
trailer [11587,11623]
trailer [11944,11980]
===
match
---
assert_stmt [13151,13172]
assert_stmt [13508,13529]
===
match
---
param [7226,7231]
param [7583,7588]
===
match
---
simple_stmt [16036,16129]
simple_stmt [16393,16486]
===
match
---
name: DEFAULT_DATE [2568,2580]
name: DEFAULT_DATE [2568,2580]
===
match
---
string: "Task runme_0\n" [3783,3799]
string: "Task runme_0\n" [3783,3799]
===
match
---
name: path [1452,1456]
name: path [1452,1456]
===
match
---
simple_stmt [1494,1574]
simple_stmt [1494,1574]
===
match
---
trailer [19939,19954]
trailer [20296,20311]
===
match
---
trailer [14042,14048]
trailer [14399,14405]
===
match
---
name: DM [16674,16676]
name: DM [17031,17033]
===
match
---
testlist_comp [11924,11981]
testlist_comp [12281,12338]
===
match
---
string: 'example_bash_operator' [4504,4527]
string: 'example_bash_operator' [4504,4527]
===
match
---
name: dag_pause [14618,14627]
name: dag_pause [14975,14984]
===
match
---
atom [3234,3576]
atom [3234,3576]
===
match
---
assert_stmt [20405,20430]
assert_stmt [20762,20787]
===
match
---
name: local [5008,5013]
name: local [5008,5013]
===
match
---
param [18224,18237]
param [18581,18594]
===
match
---
operator: + [10900,10901]
operator: + [11257,11258]
===
match
---
dotted_name [1365,1384]
dotted_name [1365,1384]
===
match
---
string: "airflow.cli.commands.dag_command.subprocess.Popen" [6221,6272]
string: "airflow.cli.commands.dag_command.subprocess.Popen" [6578,6629]
===
match
---
name: path [1751,1755]
name: path [1751,1755]
===
match
---
name: cli_args [19761,19769]
name: cli_args [20118,20126]
===
match
---
trailer [10737,10747]
trailer [11094,11104]
===
match
---
name: temp_stdout [11686,11697]
name: temp_stdout [12043,12054]
===
match
---
simple_stmt [14813,14843]
simple_stmt [15170,15200]
===
match
---
simple_stmt [12075,12112]
simple_stmt [12432,12469]
===
match
---
simple_stmt [7472,7516]
simple_stmt [7829,7873]
===
match
---
name: subdir [19770,19776]
name: subdir [20127,20133]
===
match
---
name: DagRun [15430,15436]
name: DagRun [15787,15793]
===
match
---
string: 'example_bash_operator' [13539,13562]
string: 'example_bash_operator' [13896,13919]
===
match
---
import_from [940,968]
import_from [940,968]
===
match
---
operator: , [9763,9764]
operator: , [10120,10121]
===
match
---
trailer [14690,14704]
trailer [15047,15061]
===
match
---
funcdef [6341,7123]
funcdef [6698,7480]
===
match
---
name: io [812,814]
name: io [812,814]
===
match
---
expr_stmt [3644,3670]
expr_stmt [3644,3670]
===
match
---
string: 'example_bash_operator' [6831,6854]
string: 'example_bash_operator' [7188,7211]
===
match
---
operator: = [18925,18926]
operator: = [19282,19283]
===
match
---
trailer [12376,12403]
trailer [12733,12760]
===
match
---
simple_stmt [14524,14598]
simple_stmt [14881,14955]
===
match
---
name: isoformat [16068,16077]
name: isoformat [16425,16434]
===
match
---
fstring_string: \n [3754,3756]
fstring_string: \n [3754,3756]
===
match
---
trailer [6961,6985]
trailer [7318,7342]
===
match
---
testlist_comp [14163,14424]
testlist_comp [14520,14781]
===
match
---
operator: } [12874,12875]
operator: } [13231,13232]
===
match
---
operator: @ [2209,2210]
operator: @ [2209,2210]
===
match
---
atom_expr [5191,5212]
atom_expr [5191,5212]
===
match
---
operator: , [2815,2816]
operator: , [2815,2816]
===
match
---
simple_stmt [5191,5213]
simple_stmt [5191,5213]
===
match
---
trailer [10728,10736]
trailer [11085,11093]
===
match
---
atom_expr [3083,3124]
atom_expr [3083,3124]
===
match
---
atom_expr [9101,9129]
atom_expr [9458,9486]
===
match
---
name: dag_command [14813,14824]
name: dag_command [15170,15181]
===
match
---
import_from [1097,1148]
import_from [1097,1148]
===
match
---
operator: = [16950,16951]
operator: = [17307,17308]
===
match
---
name: parser [3938,3944]
name: parser [3938,3944]
===
match
---
trailer [4404,4673]
trailer [4404,4673]
===
match
---
suite [15394,15488]
suite [15751,15845]
===
match
---
trailer [3212,3594]
trailer [3212,3594]
===
match
---
name: isoformat [11080,11089]
name: isoformat [11437,11446]
===
match
---
argument [18652,18684]
argument [19009,19041]
===
match
---
argument [17474,17484]
argument [17831,17841]
===
match
---
trailer [15717,15732]
trailer [16074,16089]
===
match
---
name: raises [16989,16995]
name: raises [17346,17352]
===
match
---
trailer [10350,10356]
trailer [10707,10713]
===
match
---
name: conf_vars [12410,12419]
name: conf_vars [12767,12776]
===
match
---
string: 'dags' [10198,10204]
string: 'dags' [10555,10561]
===
match
---
trailer [12011,12027]
trailer [12368,12384]
===
match
---
name: timedelta [10719,10728]
name: timedelta [11076,11085]
===
match
---
import_name [787,804]
import_name [787,804]
===
match
---
suite [17446,17697]
suite [17803,18054]
===
match
---
name: path [1595,1599]
name: path [1595,1599]
===
match
---
operator: = [9332,9333]
operator: = [9689,9690]
===
match
---
number: 1 [1544,1545]
number: 1 [1544,1545]
===
match
---
name: return_value [6944,6956]
name: return_value [7301,7313]
===
match
---
dotted_name [19174,19184]
dotted_name [19531,19541]
===
match
---
atom [5900,5966]
atom [6257,6323]
===
match
---
operator: , [5050,5051]
operator: , [5050,5051]
===
match
---
operator: = [2865,2866]
operator: = [2865,2866]
===
match
---
atom_expr [12327,12353]
atom_expr [12684,12710]
===
match
---
expr_stmt [16696,16713]
expr_stmt [17053,17070]
===
match
---
name: return_value [20097,20109]
name: return_value [20454,20466]
===
match
---
operator: = [6584,6585]
operator: = [6941,6942]
===
match
---
testlist_comp [16338,16578]
testlist_comp [16695,16935]
===
match
---
name: dag_list_jobs [17813,17826]
name: dag_list_jobs [18170,18183]
===
match
---
trailer [19580,19582]
trailer [19937,19939]
===
match
---
trailer [20048,20052]
trailer [20405,20409]
===
match
---
argument [2955,2968]
argument [2955,2968]
===
match
---
suite [17014,17156]
suite [17371,17513]
===
match
---
trailer [14627,14633]
trailer [14984,14990]
===
match
---
name: start_date [11431,11441]
name: start_date [11788,11798]
===
match
---
simple_stmt [1097,1149]
simple_stmt [1097,1149]
===
match
---
assert_stmt [15593,15623]
assert_stmt [15950,15980]
===
match
---
operator: , [8769,8770]
operator: , [9126,9127]
===
match
---
param [16168,16172]
param [16525,16529]
===
match
---
name: external_trigger [15607,15623]
name: external_trigger [15964,15980]
===
match
---
argument [11070,11077]
argument [11427,11434]
===
match
---
name: DEFAULT_DATE [8627,8639]
name: DEFAULT_DATE [8984,8996]
===
match
---
name: io [5289,5291]
name: io [5646,5648]
===
match
---
string: 'load_examples' [12850,12865]
string: 'load_examples' [13207,13222]
===
match
---
name: dag_command [14457,14468]
name: dag_command [14814,14825]
===
match
---
name: parse_args [11577,11587]
name: parse_args [11934,11944]
===
match
---
name: query [12306,12311]
name: query [12663,12668]
===
match
---
simple_stmt [3644,3671]
simple_stmt [3644,3671]
===
match
---
operator: , [6387,6388]
operator: , [6744,6745]
===
match
---
name: execution_date [19886,19900]
name: execution_date [20243,20257]
===
match
---
atom_expr [16043,16097]
atom_expr [16400,16454]
===
match
---
expr_stmt [14524,14597]
expr_stmt [14881,14954]
===
match
---
string: "owner" [13158,13165]
string: "owner" [13515,13522]
===
match
---
name: out [12128,12131]
name: out [12485,12488]
===
match
---
operator: = [2784,2785]
operator: = [2784,2785]
===
match
---
name: mock_render_dag [6410,6425]
name: mock_render_dag [6767,6782]
===
match
---
name: airflow [1238,1245]
name: airflow [1238,1245]
===
match
---
name: os [822,824]
name: os [822,824]
===
match
---
operator: @ [19239,19240]
operator: @ [19596,19597]
===
match
---
import_from [969,1003]
import_from [969,1003]
===
match
---
classdef [1894,20431]
classdef [1894,20788]
===
match
---
simple_stmt [14971,15353]
simple_stmt [15328,15710]
===
match
---
name: dag_command [5332,5343]
name: dag_command [5689,5700]
===
match
---
trailer [9043,9050]
trailer [9400,9407]
===
match
---
string: 'example_bash_operator' [9677,9700]
string: 'example_bash_operator' [10034,10057]
===
match
---
name: conf [9260,9264]
name: conf [9617,9621]
===
match
---
argument [9399,9421]
argument [9756,9778]
===
match
---
param [19326,19331]
param [19683,19688]
===
match
---
atom_expr [5289,5302]
atom_expr [5646,5659]
===
match
---
operator: , [13562,13563]
operator: , [13919,13920]
===
match
---
param [7232,7240]
param [7589,7597]
===
match
---
atom [15048,15326]
atom [15405,15683]
===
match
---
atom_expr [15416,15487]
atom_expr [15773,15844]
===
match
---
trailer [6813,6868]
trailer [7170,7225]
===
match
---
operator: , [3351,3352]
operator: , [3351,3352]
===
match
---
trailer [14913,14915]
trailer [15270,15272]
===
match
---
argument [20387,20393]
argument [20744,20750]
===
match
---
trailer [6943,6956]
trailer [7300,7313]
===
match
---
name: assert_has_calls [20332,20348]
name: assert_has_calls [20689,20705]
===
match
---
simple_stmt [16227,16634]
simple_stmt [16584,16991]
===
match
---
trailer [2099,2101]
trailer [2099,2101]
===
match
---
string: '--dry-run' [3452,3463]
string: '--dry-run' [3452,3463]
===
match
---
operator: = [5432,5433]
operator: = [5789,5790]
===
match
---
name: conf [15646,15650]
name: conf [16003,16007]
===
match
---
name: airflow [1102,1109]
name: airflow [1102,1109]
===
match
---
name: out [13169,13172]
name: out [13526,13529]
===
match
---
name: mock_proc [6479,6488]
name: mock_proc [6836,6845]
===
match
---
operator: = [7949,7950]
operator: = [8306,8307]
===
match
---
operator: , [18236,18237]
operator: , [18593,18594]
===
match
---
operator: + [10953,10954]
operator: + [11310,11311]
===
match
---
trailer [6985,6999]
trailer [7342,7356]
===
match
---
trailer [9058,9066]
trailer [9415,9423]
===
match
---
simple_stmt [925,939]
simple_stmt [925,939]
===
match
---
testlist_comp [5901,5965]
testlist_comp [6258,6322]
===
match
---
name: dag_id [19778,19784]
name: dag_id [20135,20141]
===
match
---
trailer [12311,12319]
trailer [12668,12676]
===
match
---
simple_stmt [14606,14634]
simple_stmt [14963,14991]
===
match
---
string: '--start-date' [4580,4594]
string: '--start-date' [4580,4594]
===
match
---
trailer [11911,11922]
trailer [12268,12279]
===
match
---
trailer [1481,1486]
trailer [1481,1486]
===
match
---
name: end_date [8668,8676]
name: end_date [9025,9033]
===
match
---
expr_stmt [1422,1492]
expr_stmt [1422,1492]
===
match
---
atom_expr [13862,13886]
atom_expr [14219,14243]
===
match
---
name: getvalue [6909,6917]
name: getvalue [7266,7274]
===
match
---
atom_expr [7498,7515]
atom_expr [7855,7872]
===
match
---
operator: , [9215,9216]
operator: , [9572,9573]
===
match
---
trailer [1766,1771]
trailer [1766,1771]
===
match
---
name: contextlib [12579,12589]
name: contextlib [12936,12946]
===
match
---
arglist [19866,20001]
arglist [20223,20358]
===
match
---
name: os [1716,1718]
name: os [1716,1718]
===
match
---
trailer [19885,19900]
trailer [20242,20257]
===
match
---
name: run_date [7472,7480]
name: run_date [7829,7837]
===
match
---
trailer [5364,5375]
trailer [5721,5732]
===
match
---
name: return_value [6426,6438]
name: return_value [6783,6795]
===
match
---
name: unittest [1912,1920]
name: unittest [1912,1920]
===
match
---
name: parser [14536,14542]
name: parser [14893,14899]
===
match
---
operator: , [6821,6822]
operator: , [7178,7179]
===
match
---
name: os [1605,1607]
name: os [1605,1607]
===
match
---
name: parse_args [17079,17089]
name: parse_args [17436,17446]
===
match
---
name: self [17567,17571]
name: self [17924,17928]
===
match
---
operator: , [15510,15511]
operator: , [15867,15868]
===
match
---
name: session [15386,15393]
name: session [15743,15750]
===
match
---
trailer [8874,8876]
trailer [9231,9233]
===
match
---
arglist [17474,17500]
arglist [17831,17857]
===
match
---
with_item [10250,10306]
with_item [10607,10663]
===
match
---
trailer [10964,10972]
trailer [11321,11329]
===
match
---
operator: , [4994,4995]
operator: , [4994,4995]
===
match
---
string: 'trigger' [16370,16379]
string: 'trigger' [16727,16736]
===
match
---
trailer [3955,4226]
trailer [3955,4226]
===
match
---
simple_stmt [19683,20308]
simple_stmt [20040,20665]
===
match
---
operator: = [11898,11899]
operator: = [12255,12256]
===
match
---
simple_stmt [4268,4335]
simple_stmt [4268,4335]
===
match
---
operator: = [5105,5106]
operator: = [5105,5106]
===
match
---
name: parse_args [12938,12948]
name: parse_args [13295,13305]
===
match
---
simple_stmt [5990,6019]
simple_stmt [6347,6376]
===
match
---
name: dagrun [15639,15645]
name: dagrun [15996,16002]
===
match
---
operator: = [12694,12695]
operator: = [13051,13052]
===
match
---
trailer [4723,4747]
trailer [4723,4747]
===
match
---
trailer [13967,13977]
trailer [14324,14334]
===
match
---
trailer [1607,1612]
trailer [1607,1612]
===
match
---
name: count [16956,16961]
name: count [17313,17318]
===
match
---
operator: = [8244,8245]
operator: = [8601,8602]
===
match
---
name: return_value [6444,6456]
name: return_value [6801,6813]
===
match
---
name: out [5637,5640]
name: out [5994,5997]
===
match
---
operator: , [18749,18750]
operator: , [19106,19107]
===
match
---
argument [9260,9269]
argument [9617,9626]
===
match
---
atom_expr [12001,12042]
atom_expr [12358,12399]
===
match
---
name: query [17652,17657]
name: query [18009,18014]
===
match
---
simple_stmt [1184,1233]
simple_stmt [1184,1233]
===
match
---
name: dag_trigger [13393,13404]
name: dag_trigger [13750,13761]
===
match
---
argument [2884,2908]
argument [2884,2908]
===
match
---
name: args [12672,12676]
name: args [13029,13033]
===
match
---
operator: , [11157,11158]
operator: , [11514,11515]
===
match
---
trailer [6042,6055]
trailer [6399,6412]
===
match
---
trailer [15451,15458]
trailer [15808,15815]
===
match
---
trailer [18778,18782]
trailer [19135,19139]
===
match
---
testlist_comp [7545,7727]
testlist_comp [7902,8084]
===
match
---
param [5738,5753]
param [6095,6110]
===
match
---
operator: = [11563,11564]
operator: = [11920,11921]
===
match
---
argument [9229,9246]
argument [9586,9603]
===
match
---
operator: , [12848,12849]
operator: , [13205,13206]
===
match
---
atom_expr [15639,15650]
atom_expr [15996,16007]
===
match
---
name: make_aware [13943,13953]
name: make_aware [14300,14310]
===
match
---
operator: , [9246,9247]
operator: , [9603,9604]
===
match
---
atom_expr [19877,19900]
atom_expr [20234,20257]
===
match
---
expr_stmt [8574,8605]
expr_stmt [8931,8962]
===
match
---
operator: , [20165,20166]
operator: , [20522,20523]
===
match
---
trailer [16740,16748]
trailer [17097,17105]
===
match
---
argument [9131,9138]
argument [9488,9495]
===
match
---
expr_stmt [12293,12354]
expr_stmt [12650,12711]
===
match
---
name: getvalue [5446,5454]
name: getvalue [5803,5811]
===
match
---
trailer [12608,12617]
trailer [12965,12974]
===
match
---
trailer [12326,12354]
trailer [12683,12711]
===
match
---
name: return_value [6645,6657]
name: return_value [7002,7014]
===
match
---
trailer [10983,10985]
trailer [11340,11342]
===
match
---
for_stmt [11152,12204]
for_stmt [11509,12561]
===
match
---
decorated [12829,13334]
decorated [13186,13691]
===
match
---
name: self [17067,17071]
name: self [17424,17428]
===
match
---
atom_expr [7814,7842]
atom_expr [8171,8199]
===
match
---
name: redirect_stdout [13011,13026]
name: redirect_stdout [13368,13383]
===
match
---
name: getvalue [3660,3668]
name: getvalue [3660,3668]
===
match
---
simple_stmt [6479,6508]
simple_stmt [6836,6865]
===
match
---
operator: , [2847,2848]
operator: , [2847,2848]
===
match
---
simple_stmt [15632,15669]
simple_stmt [15989,16026]
===
match
---
operator: = [7976,7977]
operator: = [8333,8334]
===
match
---
operator: , [16883,16884]
operator: , [17240,17241]
===
match
---
atom_expr [13027,13040]
atom_expr [13384,13397]
===
match
---
param [18218,18223]
param [18575,18580]
===
match
---
operator: , [4033,4034]
operator: , [4033,4034]
===
match
---
simple_stmt [11313,11497]
simple_stmt [11670,11854]
===
match
---
assert_stmt [7075,7094]
assert_stmt [7432,7451]
===
match
---
name: args [14483,14487]
name: args [14840,14844]
===
match
---
string: '--end-date' [8890,8902]
string: '--end-date' [9247,9259]
===
match
---
name: dag_id [18508,18514]
name: dag_id [18865,18871]
===
match
---
string: '--start-date' [2436,2450]
string: '--start-date' [2436,2450]
===
match
---
with_stmt [15361,15488]
with_stmt [15718,15845]
===
match
---
name: self [12926,12930]
name: self [13283,13287]
===
match
---
trailer [15019,15030]
trailer [15376,15387]
===
match
---
name: return_value [20373,20385]
name: return_value [20730,20742]
===
match
---
operator: = [11075,11076]
operator: = [11432,11433]
===
match
---
trailer [4638,4640]
trailer [4638,4640]
===
match
---
trailer [12266,12268]
trailer [12623,12625]
===
match
---
name: pytest [932,938]
name: pytest [932,938]
===
match
---
name: parser [6796,6802]
name: parser [7153,7159]
===
match
---
string: 'example_bash_operator' [13756,13779]
string: 'example_bash_operator' [14113,14136]
===
match
---
simple_stmt [5332,5420]
simple_stmt [5689,5777]
===
match
---
string: 'dags' [16338,16344]
string: 'dags' [16695,16701]
===
match
---
trailer [19662,19671]
trailer [20019,20028]
===
match
---
atom_expr [12503,12565]
atom_expr [12860,12922]
===
match
---
argument [20241,20263]
argument [20598,20620]
===
match
---
atom_expr [16268,16618]
atom_expr [16625,16975]
===
match
---
operator: , [9013,9014]
operator: , [9370,9371]
===
match
---
operator: + [11051,11052]
operator: + [11408,11409]
===
match
---
arglist [1605,1645]
arglist [1605,1645]
===
match
---
operator: , [2409,2410]
operator: , [2409,2410]
===
match
---
trailer [17826,17832]
trailer [18183,18189]
===
match
---
name: __file__ [1466,1474]
name: __file__ [1466,1474]
===
match
---
operator: , [2291,2292]
operator: , [2291,2292]
===
match
---
operator: , [18222,18223]
operator: , [18579,18580]
===
match
---
operator: , [11091,11092]
operator: , [11448,11449]
===
match
---
trailer [2054,2056]
trailer [2054,2056]
===
match
---
trailer [11670,11679]
trailer [12027,12036]
===
match
---
atom_expr [11668,11681]
atom_expr [12025,12038]
===
match
---
operator: == [16098,16100]
operator: == [16455,16457]
===
match
---
operator: , [2638,2639]
operator: , [2638,2639]
===
match
---
parameters [9637,9643]
parameters [9994,10000]
===
match
---
trailer [6908,6917]
trailer [7265,7274]
===
match
---
operator: = [17347,17348]
operator: = [17704,17705]
===
match
---
trailer [1771,1780]
trailer [1771,1780]
===
match
---
atom [12840,12875]
atom [13197,13232]
===
match
---
name: test_show_dag_imgcat [6345,6365]
name: test_show_dag_imgcat [6702,6722]
===
match
---
atom_expr [18373,18403]
atom_expr [18730,18760]
===
match
---
simple_stmt [3776,3810]
simple_stmt [3776,3810]
===
match
---
simple_stmt [17515,17532]
simple_stmt [17872,17889]
===
match
---
name: self [19398,19402]
name: self [19755,19759]
===
match
---
with_stmt [11636,11797]
with_stmt [11993,12154]
===
match
---
trailer [17555,17566]
trailer [17912,17923]
===
match
---
trailer [9156,9180]
trailer [9513,9537]
===
match
---
argument [5125,5144]
argument [5125,5144]
===
match
---
name: cli_args [18262,18270]
name: cli_args [18619,18627]
===
match
---
name: executor [18804,18812]
name: executor [19161,19169]
===
match
---
name: TEST_DAG_ID [1647,1658]
name: TEST_DAG_ID [1647,1658]
===
match
---
name: AirflowException [1080,1096]
name: AirflowException [1080,1096]
===
match
---
operator: = [1590,1591]
operator: = [1590,1591]
===
match
---
operator: , [19344,19345]
operator: , [19701,19702]
===
match
---
name: self [11900,11904]
name: self [12257,12261]
===
match
---
argument [5032,5050]
argument [5032,5050]
===
match
---
operator: == [15763,15765]
operator: == [16120,16122]
===
match
---
operator: @ [19043,19044]
operator: @ [19400,19401]
===
match
---
comparison [12799,12823]
comparison [13156,13180]
===
match
---
trailer [6644,6657]
trailer [7001,7014]
===
match
---
trailer [6007,6016]
trailer [6364,6373]
===
match
---
name: TEST_DAG_FOLDER [1574,1589]
name: TEST_DAG_FOLDER [1574,1589]
===
match
---
trailer [18499,18506]
trailer [18856,18863]
===
match
---
atom [6814,6867]
atom [7171,7224]
===
match
---
trailer [13081,13095]
trailer [13438,13452]
===
match
---
trailer [13643,14004]
trailer [14000,14361]
===
match
---
name: include_examples [2002,2018]
name: include_examples [2002,2018]
===
match
---
name: parser [12508,12514]
name: parser [12865,12871]
===
match
---
name: dagbag [11212,11218]
name: dagbag [11569,11575]
===
match
---
atom_expr [10277,10290]
atom_expr [10634,10647]
===
match
---
trailer [12605,12620]
trailer [12962,12977]
===
match
---
name: args [7837,7841]
name: args [8194,8198]
===
match
---
operator: , [2870,2871]
operator: , [2870,2871]
===
match
---
string: "runme_2 -> run_after_loop" [5606,5633]
string: "runme_2 -> run_after_loop" [5963,5990]
===
match
---
atom_expr [16916,16963]
atom_expr [17273,17320]
===
match
---
trailer [3007,3009]
trailer [3007,3009]
===
match
---
string: '--output' [12966,12976]
string: '--output' [13323,13333]
===
match
---
comparison [15940,16027]
comparison [16297,16384]
===
match
---
atom_expr [16759,16786]
atom_expr [17116,17143]
===
match
---
string: '--start-date' [4133,4147]
string: '--start-date' [4133,4147]
===
match
---
name: mock_get_dag [20360,20372]
name: mock_get_dag [20717,20729]
===
match
---
trailer [15429,15437]
trailer [15786,15794]
===
match
---
operator: , [17971,17972]
operator: , [18328,18329]
===
match
---
import_name [815,824]
import_name [815,824]
===
match
---
string: '--local' [7609,7618]
string: '--local' [7966,7975]
===
match
---
atom [20391,20393]
atom [20748,20750]
===
match
---
name: State [18720,18725]
name: State [19077,19082]
===
match
---
name: out [10369,10372]
name: out [10726,10729]
===
match
---
name: dag_command [17544,17555]
name: dag_command [17901,17912]
===
match
---
trailer [14024,14042]
trailer [14381,14399]
===
match
---
operator: , [8745,8746]
operator: , [9102,9103]
===
match
---
atom [15654,15668]
atom [16011,16025]
===
match
---
dotted_name [18075,18085]
dotted_name [18432,18442]
===
match
---
funcdef [13339,14049]
funcdef [13696,14406]
===
match
---
name: parser [16848,16854]
name: parser [17205,17211]
===
match
---
trailer [2088,2099]
trailer [2088,2099]
===
match
---
trailer [10060,10067]
trailer [10417,10424]
===
match
---
atom_expr [6027,6156]
atom_expr [6384,6513]
===
match
---
name: pool [2861,2865]
name: pool [2861,2865]
===
match
---
trailer [15485,15487]
trailer [15842,15844]
===
match
---
name: dagbag [1986,1992]
name: dagbag [1986,1992]
===
match
---
operator: = [9495,9496]
operator: = [9852,9853]
===
match
---
operator: , [10985,10986]
operator: , [11342,11343]
===
match
---
operator: = [17678,17679]
operator: = [18035,18036]
===
match
---
trailer [8924,8934]
trailer [9281,9291]
===
match
---
atom_expr [1529,1549]
atom_expr [1529,1549]
===
match
---
name: mock [19827,19831]
name: mock [20184,20188]
===
match
---
name: unittest [903,911]
name: unittest [903,911]
===
match
---
atom_expr [1440,1492]
atom_expr [1440,1492]
===
match
---
trailer [17769,17792]
trailer [18126,18149]
===
match
---
string: 'backfill' [7565,7575]
string: 'backfill' [7922,7932]
===
match
---
name: parser [2355,2361]
name: parser [2355,2361]
===
match
---
string: 'example_bash_operator' [5393,5416]
string: 'example_bash_operator' [5750,5773]
===
match
---
trailer [11042,11050]
trailer [11399,11407]
===
match
---
name: io [11668,11670]
name: io [12025,12027]
===
match
---
string: 'example_bash_operator' [2411,2434]
string: 'example_bash_operator' [2411,2434]
===
match
---
string: 'png' [6993,6998]
string: 'png' [7350,7355]
===
match
---
with_item [19542,19593]
with_item [19899,19950]
===
match
---
name: communicate [6559,6570]
name: communicate [6916,6927]
===
match
---
atom_expr [3148,3634]
atom_expr [3148,3634]
===
match
---
trailer [2464,2474]
trailer [2464,2474]
===
match
---
operator: , [3503,3504]
operator: , [3503,3504]
===
match
---
name: dag_id [17474,17480]
name: dag_id [17831,17837]
===
match
---
operator: , [17140,17141]
operator: , [17497,17498]
===
match
---
argument [19976,20000]
argument [20333,20357]
===
match
---
atom_expr [17644,17691]
atom_expr [18001,18048]
===
match
---
name: timezone [1551,1559]
name: timezone [1551,1559]
===
match
---
name: dag_command [19607,19618]
name: dag_command [19964,19975]
===
match
---
name: end_date [19922,19930]
name: end_date [20279,20287]
===
match
---
atom_expr [10712,10749]
atom_expr [11069,11106]
===
match
---
trailer [11474,11481]
trailer [11831,11838]
===
match
---
name: local [8147,8152]
name: local [8504,8509]
===
match
---
parameters [16167,16173]
parameters [16524,16530]
===
match
---
name: out [5428,5431]
name: out [5785,5788]
===
match
---
name: dag [4691,4694]
name: dag [4691,4694]
===
match
---
operator: , [7680,7681]
operator: , [8037,8038]
===
match
---
name: cli_args [19387,19395]
name: cli_args [19744,19752]
===
match
---
name: delete [10097,10103]
name: delete [10454,10460]
===
match
---
name: datetime [878,886]
name: datetime [878,886]
===
match
---
name: dag_command [11715,11726]
name: dag_command [12072,12083]
===
match
---
name: temp_stdout [5434,5445]
name: temp_stdout [5791,5802]
===
match
---
operator: = [20390,20391]
operator: = [20747,20748]
===
match
---
simple_stmt [3148,3635]
simple_stmt [3148,3635]
===
match
---
simple_stmt [3895,4259]
simple_stmt [3895,4259]
===
match
---
param [5732,5737]
param [6089,6094]
===
match
---
name: dag_delete [16832,16842]
name: dag_delete [17189,17199]
===
match
---
suite [17731,17833]
suite [18088,18190]
===
match
---
operator: , [13886,13887]
operator: , [14243,14244]
===
match
---
name: test_dag_state [17842,17856]
name: test_dag_state [18199,18213]
===
match
---
simple_stmt [17369,17398]
simple_stmt [17726,17755]
===
match
---
number: 0 [14927,14928]
number: 0 [15284,15285]
===
match
---
atom_expr [13000,13041]
atom_expr [13357,13398]
===
match
---
operator: , [6370,6371]
operator: , [6727,6728]
===
match
---
import_from [1314,1359]
import_from [1314,1359]
===
match
---
atom_expr [2188,2203]
atom_expr [2188,2203]
===
match
---
name: session [16722,16729]
name: session [17079,17086]
===
match
---
name: self [14956,14960]
name: self [15313,15317]
===
match
---
name: start_date [18596,18606]
name: start_date [18953,18963]
===
match
---
argument [16078,16096]
argument [16435,16453]
===
match
---
trailer [5343,5352]
trailer [5700,5709]
===
match
---
trailer [20331,20348]
trailer [20688,20705]
===
match
---
name: cls [2142,2145]
name: cls [2142,2145]
===
match
---
trailer [2201,2203]
trailer [2201,2203]
===
match
---
trailer [7836,7842]
trailer [8193,8199]
===
match
---
trailer [10276,10291]
trailer [10633,10648]
===
match
---
name: dag [3018,3021]
name: dag [3018,3021]
===
match
---
name: cli_args [18491,18499]
name: cli_args [18848,18856]
===
match
---
operator: = [9380,9381]
operator: = [9737,9738]
===
match
---
name: cli_args [19931,19939]
name: cli_args [20288,20296]
===
match
---
name: parse_args [16280,16290]
name: parse_args [16637,16647]
===
match
---
name: utils [1162,1167]
name: utils [1162,1167]
===
match
---
trailer [10178,10185]
trailer [10535,10542]
===
match
---
name: conf [7972,7976]
name: conf [8329,8333]
===
match
---
string: 'example_python_operator' [9820,9845]
string: 'example_python_operator' [10177,10202]
===
match
---
name: isoformat [4629,4638]
name: isoformat [4629,4638]
===
match
---
name: mock_render_dag [20316,20331]
name: mock_render_dag [20673,20688]
===
match
---
atom [14919,14929]
atom [15276,15286]
===
match
---
simple_stmt [4344,4706]
simple_stmt [4344,4706]
===
match
---
name: session [15416,15423]
name: session [15773,15780]
===
match
---
simple_stmt [17343,17361]
simple_stmt [17700,17718]
===
match
---
string: "seconds" [16087,16096]
string: "seconds" [16444,16453]
===
match
---
name: return_value [6622,6634]
name: return_value [6979,6991]
===
match
---
atom [17590,17622]
atom [17947,17979]
===
match
---
assert_stmt [5517,5590]
assert_stmt [5874,5947]
===
match
---
trailer [17904,17914]
trailer [18261,18271]
===
match
---
name: delete [12370,12376]
name: delete [12727,12733]
===
match
---
with_stmt [12995,13143]
with_stmt [13352,13500]
===
match
---
param [1968,1971]
param [1968,1971]
===
match
---
simple_stmt [6611,6670]
simple_stmt [6968,7027]
===
match
---
trailer [3121,3123]
trailer [3121,3123]
===
match
---
name: DagRun [12312,12318]
name: DagRun [12669,12675]
===
match
---
operator: = [4243,4244]
operator: = [4243,4244]
===
match
---
name: datetime [1529,1537]
name: datetime [1529,1537]
===
match
---
name: NONE [19996,20000]
name: NONE [20353,20357]
===
match
---
string: 'example_bash_operator' [19451,19474]
string: 'example_bash_operator' [19808,19831]
===
match
---
comparison [10547,10560]
comparison [10904,10917]
===
match
---
operator: , [14169,14170]
operator: , [14526,14527]
===
match
---
name: io [12028,12030]
name: io [12385,12387]
===
match
---
atom_expr [6410,6456]
atom_expr [6767,6813]
===
match
---
name: start_date [18861,18871]
name: start_date [19218,19228]
===
match
---
comparison [3783,3809]
comparison [3783,3809]
===
match
---
testlist_comp [5377,5416]
testlist_comp [5734,5773]
===
match
---
name: parser [12931,12937]
name: parser [13288,13294]
===
match
---
name: contextlib [10250,10260]
name: contextlib [10607,10617]
===
match
---
atom [11588,11622]
atom [11945,11979]
===
match
---
operator: = [17745,17746]
operator: = [18102,18103]
===
match
---
arglist [4382,4695]
arglist [4382,4695]
===
match
---
name: self [5732,5736]
name: self [6089,6093]
===
match
---
operator: = [8304,8305]
operator: = [8661,8662]
===
match
---
trailer [6443,6456]
trailer [6800,6813]
===
match
---
name: dag [4240,4243]
name: dag [4240,4243]
===
match
---
name: Session [17388,17395]
name: Session [17745,17752]
===
match
---
name: isoformat [8925,8934]
name: isoformat [9282,9291]
===
match
---
operator: = [8092,8093]
operator: = [8449,8450]
===
match
---
name: temp_stdout [6897,6908]
name: temp_stdout [7254,7265]
===
match
---
operator: , [8157,8158]
operator: , [8514,8515]
===
match
---
trailer [14836,14842]
trailer [15193,15199]
===
match
---
trailer [18478,18483]
trailer [18835,18840]
===
match
---
with_item [5769,5825]
with_item [6126,6182]
===
match
---
name: test_trigger_dag_invalid_conf [16138,16167]
name: test_trigger_dag_invalid_conf [16495,16524]
===
match
---
trailer [17758,17769]
trailer [18115,18126]
===
match
---
trailer [12716,12718]
trailer [13073,13075]
===
match
---
operator: , [14766,14767]
operator: , [15123,15124]
===
match
---
name: classmethod [1937,1948]
name: classmethod [1937,1948]
===
match
---
operator: , [14423,14424]
operator: , [14780,14781]
===
match
---
name: mock_render_dag [6372,6387]
name: mock_render_dag [6729,6744]
===
match
---
name: self [18218,18222]
name: self [18575,18579]
===
match
---
operator: = [11021,11022]
operator: = [11378,11379]
===
match
---
string: 'delete' [16875,16883]
string: 'delete' [17232,17240]
===
match
---
name: start_date [20131,20141]
name: start_date [20488,20498]
===
match
---
string: 'dags' [14163,14169]
string: 'dags' [14520,14526]
===
match
---
atom [19726,20297]
atom [20083,20654]
===
match
---
trailer [10185,10196]
trailer [10542,10553]
===
match
---
parameters [14086,14092]
parameters [14443,14449]
===
match
---
operator: = [6140,6141]
operator: = [6497,6498]
===
match
---
operator: , [5073,5074]
operator: , [5073,5074]
===
match
---
simple_stmt [15407,15488]
simple_stmt [15764,15845]
===
match
---
name: dag_command [17893,17904]
name: dag_command [18250,18261]
===
match
---
number: 1 [10917,10918]
number: 1 [11274,11275]
===
match
---
name: isoformat [10921,10930]
name: isoformat [11278,11287]
===
match
---
name: mock [7129,7133]
name: mock [7486,7490]
===
match
---
expr_stmt [6479,6507]
expr_stmt [6836,6864]
===
match
---
operator: -> [2147,2149]
operator: -> [2147,2149]
===
match
---
argument [11463,11481]
argument [11820,11838]
===
match
---
simple_stmt [8668,8710]
simple_stmt [9025,9067]
===
match
---
name: self [5242,5246]
name: self [5599,5603]
===
match
---
string: '2' [11978,11981]
string: '2' [12335,12338]
===
match
---
simple_stmt [2188,2204]
simple_stmt [2188,2204]
===
match
---
argument [3612,3619]
argument [3612,3619]
===
match
---
atom_expr [15548,15563]
atom_expr [15905,15920]
===
match
---
operator: , [4911,4912]
operator: , [4911,4912]
===
match
---
atom_expr [5353,5418]
atom_expr [5710,5775]
===
match
---
argument [9435,9445]
argument [9792,9802]
===
match
---
name: mock [19044,19048]
name: mock [19401,19405]
===
match
---
import_from [898,923]
import_from [898,923]
===
match
---
name: isoformat [18351,18360]
name: isoformat [18708,18717]
===
match
---
string: "SOURCE" [19137,19145]
string: "SOURCE" [19494,19502]
===
match
---
name: dag_list_jobs [14469,14482]
name: dag_list_jobs [14826,14839]
===
match
---
fstring_string: Dry run of DAG example_bash_operator on  [3688,3728]
fstring_string: Dry run of DAG example_bash_operator on  [3688,3728]
===
match
---
string: 'trigger' [15098,15107]
string: 'trigger' [15455,15464]
===
match
---
name: raises [16195,16201]
name: raises [16552,16558]
===
match
---
trailer [18442,19037]
trailer [18799,19394]
===
match
---
trailer [13422,13429]
trailer [13779,13786]
===
match
---
operator: , [18949,18950]
operator: , [19306,19307]
===
match
---
name: verbose [2955,2962]
name: verbose [2955,2962]
===
match
---
expr_stmt [12690,12718]
expr_stmt [13047,13075]
===
match
---
simple_stmt [857,898]
simple_stmt [857,898]
===
match
---
name: DagModel [16679,16687]
name: DagModel [17036,17044]
===
match
---
string: '--save' [5942,5950]
string: '--save' [6299,6307]
===
match
---
arith_expr [11054,11078]
arith_expr [11411,11435]
===
match
---
operator: , [9129,9130]
operator: , [9486,9487]
===
match
---
decorator [19173,19235]
decorator [19530,19592]
===
match
---
string: 'dags' [8739,8745]
string: 'dags' [9096,9102]
===
match
---
funcdef [19299,20431]
funcdef [19656,20788]
===
match
---
name: os [11040,11042]
name: os [11397,11399]
===
match
---
trailer [12344,12353]
trailer [12701,12710]
===
match
---
name: dag [4244,4247]
name: dag [4244,4247]
===
match
---
name: join [1706,1710]
name: join [1706,1710]
===
match
---
simple_stmt [13070,13102]
simple_stmt [13427,13459]
===
match
---
operator: , [12543,12544]
operator: , [12900,12901]
===
match
---
operator: = [8723,8724]
operator: = [9080,9081]
===
match
---
name: out [13330,13333]
name: out [13687,13690]
===
match
---
name: get_dag [7764,7771]
name: get_dag [8121,8128]
===
match
---
expr_stmt [9033,9066]
expr_stmt [9390,9423]
===
match
---
suite [1973,2102]
suite [1973,2102]
===
match
---
operator: = [11356,11357]
operator: = [11713,11714]
===
match
---
operator: , [11613,11614]
operator: , [11970,11971]
===
match
---
name: mark_success [5032,5044]
name: mark_success [5032,5044]
===
match
---
name: isoformat [4182,4191]
name: isoformat [4182,4191]
===
match
---
atom_expr [7752,7779]
atom_expr [8109,8136]
===
match
---
assert_stmt [15704,15793]
assert_stmt [16061,16150]
===
match
---
simple_stmt [6928,7000]
simple_stmt [7285,7357]
===
match
---
simple_stmt [805,815]
simple_stmt [805,815]
===
match
---
name: DEFAULT_DATE [7483,7495]
name: DEFAULT_DATE [7840,7852]
===
match
---
name: end_date [8916,8924]
name: end_date [9273,9281]
===
match
---
operator: , [6132,6133]
operator: , [6489,6490]
===
match
---
trailer [19769,19776]
trailer [20126,20133]
===
match
---
name: io [3110,3112]
name: io [3110,3112]
===
match
---
trailer [17495,17500]
trailer [17852,17857]
===
match
---
name: dag_id [12334,12340]
name: dag_id [12691,12697]
===
match
---
name: donot_pickle [8032,8044]
name: donot_pickle [8389,8401]
===
match
---
atom_expr [11040,11050]
atom_expr [11397,11407]
===
match
---
operator: = [12132,12133]
operator: = [12489,12490]
===
match
---
simple_stmt [16696,16714]
simple_stmt [17053,17071]
===
match
---
name: getvalue [10387,10395]
name: getvalue [10744,10752]
===
match
---
name: timedelta [10770,10779]
name: timedelta [11127,11136]
===
match
---
name: out [5587,5590]
name: out [5944,5947]
===
match
---
trailer [12105,12111]
trailer [12462,12468]
===
match
---
trailer [13874,13884]
trailer [14231,14241]
===
match
---
name: StringIO [12609,12617]
name: StringIO [12966,12974]
===
match
---
name: StringIO [19572,19580]
name: StringIO [19929,19937]
===
match
---
name: now [10764,10767]
name: now [11121,11124]
===
match
---
operator: } [15667,15668]
operator: } [16024,16025]
===
match
---
operator: , [16507,16508]
operator: , [16864,16865]
===
match
---
assert_stmt [5599,5640]
assert_stmt [5956,5997]
===
match
---
name: airflow [974,981]
name: airflow [974,981]
===
match
---
operator: = [16730,16731]
operator: = [17087,17088]
===
match
---
name: mock_run [4715,4723]
name: mock_run [4715,4723]
===
match
---
atom [12526,12564]
atom [12883,12921]
===
match
---
name: dag_command [14606,14617]
name: dag_command [14963,14974]
===
match
---
simple_stmt [10653,10672]
simple_stmt [11010,11029]
===
match
---
string: 'list-runs' [13699,13710]
string: 'list-runs' [14056,14067]
===
match
---
name: airflow [945,952]
name: airflow [945,952]
===
match
---
atom_expr [11053,11091]
atom_expr [11410,11448]
===
match
---
trailer [6712,6721]
trailer [7069,7078]
===
match
---
name: execution_date [20151,20165]
name: execution_date [20508,20522]
===
match
---
operator: = [4690,4691]
operator: = [4690,4691]
===
match
---
decorator [12829,12877]
decorator [13186,13234]
===
match
---
trailer [7053,7066]
trailer [7410,7423]
===
match
---
argument [9320,9338]
argument [9677,9695]
===
match
---
simple_stmt [16909,16969]
simple_stmt [17266,17326]
===
match
---
trailer [14131,14448]
trailer [14488,14805]
===
match
---
atom_expr [14858,14915]
atom_expr [15215,15272]
===
match
---
name: temp_stdout [12134,12145]
name: temp_stdout [12491,12502]
===
match
---
name: args [11893,11897]
name: args [12250,12254]
===
match
---
name: isoformat [10974,10983]
name: isoformat [11331,11340]
===
match
---
operator: = [8677,8678]
operator: = [9034,9035]
===
match
---
operator: , [5907,5908]
operator: , [6264,6265]
===
match
---
operator: @ [19173,19174]
operator: @ [19530,19531]
===
match
---
trailer [6773,6882]
trailer [7130,7239]
===
match
---
trailer [15030,15341]
trailer [15387,15698]
===
match
---
operator: , [9306,9307]
operator: , [9663,9664]
===
match
---
trailer [5899,5967]
trailer [6256,6324]
===
match
---
argument [9552,9570]
argument [9909,9927]
===
match
---
assert_stmt [17872,18068]
assert_stmt [18229,18425]
===
match
---
name: test_cli_list_jobs_with_args [14058,14086]
name: test_cli_list_jobs_with_args [14415,14443]
===
match
---
trailer [13095,13101]
trailer [13452,13458]
===
match
---
trailer [11035,11037]
trailer [11392,11394]
===
match
---
name: start_date [8614,8624]
name: start_date [8971,8981]
===
match
---
trailer [5291,5300]
trailer [5648,5657]
===
match
---
name: SCHEDULED [11368,11377]
name: SCHEDULED [11725,11734]
===
match
---
name: assert_called_once_with [6962,6985]
name: assert_called_once_with [7319,7342]
===
match
---
string: 'dags' [14760,14766]
string: 'dags' [15117,15123]
===
match
---
name: synchronize_session [12377,12396]
name: synchronize_session [12734,12753]
===
match
---
operator: , [4958,4959]
operator: , [4958,4959]
===
match
---
string: "airflow" [13188,13197]
string: "airflow" [13545,13554]
===
match
---
comparison [15445,15480]
comparison [15802,15837]
===
match
---
trailer [14653,14660]
trailer [15010,15017]
===
match
---
name: local [9435,9440]
name: local [9792,9797]
===
match
---
suite [14515,14930]
suite [14872,15287]
===
match
---
trailer [7818,7825]
trailer [8175,8182]
===
match
---
simple_stmt [16795,16812]
simple_stmt [17152,17169]
===
match
---
atom_expr [19744,19809]
atom_expr [20101,20166]
===
match
---
name: isoformat [3542,3551]
name: isoformat [3542,3551]
===
match
---
name: path [1767,1771]
name: path [1767,1771]
===
match
---
name: execution_date [18935,18949]
name: execution_date [19292,19306]
===
match
---
name: dagrun [15548,15554]
name: dagrun [15905,15911]
===
match
---
operator: , [2434,2435]
operator: , [2434,2435]
===
match
---
operator: = [4988,4989]
operator: = [4988,4989]
===
match
---
suite [17863,18069]
suite [18220,18426]
===
match
---
name: parse_args [3945,3955]
name: parse_args [3945,3955]
===
match
---
argument [18706,18730]
argument [19063,19087]
===
match
---
arglist [3190,3620]
arglist [3190,3620]
===
match
---
atom_expr [17515,17531]
atom_expr [17872,17888]
===
match
---
name: realpath [1457,1465]
name: realpath [1457,1465]
===
match
---
testlist_comp [12422,12445]
testlist_comp [12779,12802]
===
match
---
string: b"DOT_DATA" [6459,6470]
string: b"DOT_DATA" [6816,6827]
===
match
---
string: "airflow.cli.commands.dag_command.render_dag" [19064,19109]
string: "airflow.cli.commands.dag_command.render_dag" [19421,19466]
===
match
---
operator: = [7432,7433]
operator: = [7789,7790]
===
match
---
simple_stmt [7075,7095]
simple_stmt [7432,7452]
===
match
---
parameters [12480,12486]
parameters [12837,12843]
===
match
---
trailer [14553,14597]
trailer [14910,14954]
===
match
---
decorator [2209,2265]
decorator [2209,2265]
===
match
---
name: timedelta [7498,7507]
name: timedelta [7855,7864]
===
match
---
suite [18253,19038]
suite [18610,19395]
===
match
---
trailer [16995,17013]
trailer [17352,17370]
===
match
---
name: redirect_stdout [12590,12605]
name: redirect_stdout [12947,12962]
===
match
---
name: commands [1021,1029]
name: commands [1021,1029]
===
match
---
trailer [17812,17826]
trailer [18169,18183]
===
match
---
name: mock_proc [6549,6558]
name: mock_proc [6906,6915]
===
match
---
expr_stmt [7472,7515]
expr_stmt [7829,7872]
===
match
---
string: b"OUT" [6587,6593]
string: b"OUT" [6944,6950]
===
match
---
fstring_end: " [3756,3757]
fstring_end: " [3756,3757]
===
match
---
operator: = [13118,13119]
operator: = [13475,13476]
===
match
---
simple_stmt [16820,16901]
simple_stmt [17177,17258]
===
match
---
operator: , [1549,1550]
operator: , [1549,1550]
===
match
---
string: 'dags' [19435,19441]
string: 'dags' [19792,19798]
===
match
---
name: args [13096,13100]
name: args [13453,13457]
===
match
---
operator: , [8250,8251]
operator: , [8607,8608]
===
match
---
argument [11016,11023]
argument [11373,11380]
===
match
---
name: cls [1968,1971]
name: cls [1968,1971]
===
match
---
param [12481,12485]
param [12838,12842]
===
match
---
trailer [10789,10799]
trailer [11146,11156]
===
match
---
name: dag_id [11615,11621]
name: dag_id [11972,11978]
===
match
---
trailer [10386,10395]
trailer [10743,10752]
===
match
---
name: temp_stdout [12046,12057]
name: temp_stdout [12403,12414]
===
match
---
operator: = [2841,2842]
operator: = [2841,2842]
===
match
---
operator: = [20195,20196]
operator: = [20552,20553]
===
match
---
trailer [16842,16900]
trailer [17199,17257]
===
match
---
assert_stmt [12169,12203]
assert_stmt [12526,12560]
===
match
---
funcdef [1953,2102]
funcdef [1953,2102]
===
match
---
name: dag_id [8783,8789]
name: dag_id [9140,9146]
===
match
---
trailer [5199,5210]
trailer [5199,5210]
===
match
---
argument [6134,6146]
argument [6491,6503]
===
match
---
trailer [1612,1620]
trailer [1612,1620]
===
match
---
parameters [14508,14514]
parameters [14865,14871]
===
match
---
name: assert_called_once_with [7030,7053]
name: assert_called_once_with [7387,7410]
===
match
---
string: 'dags' [2391,2397]
string: 'dags' [2391,2397]
===
match
---
expr_stmt [12128,12156]
expr_stmt [12485,12513]
===
match
---
operator: = [7481,7482]
operator: = [7838,7839]
===
match
---
name: filter_by [17662,17671]
name: filter_by [18019,18028]
===
match
---
simple_stmt [13114,13143]
simple_stmt [13471,13500]
===
match
---
name: out [13201,13204]
name: out [13558,13561]
===
match
---
name: get_parser [2089,2099]
name: get_parser [2089,2099]
===
match
---
name: dag_folder_path [1422,1437]
name: dag_folder_path [1422,1437]
===
match
---
arglist [2557,2969]
arglist [2557,2969]
===
match
---
name: test_cli_list_dags [12885,12903]
name: test_cli_list_dags [13242,13260]
===
match
---
assert_stmt [15632,15668]
assert_stmt [15989,16025]
===
match
---
simple_stmt [2033,2057]
simple_stmt [2033,2057]
===
match
---
operator: , [12533,12534]
operator: , [12890,12891]
===
match
---
name: dr [12293,12295]
name: dr [12650,12652]
===
match
---
atom_expr [5996,6018]
atom_expr [6353,6375]
===
match
---
name: pytest [16982,16988]
name: pytest [17339,17345]
===
match
---
atom_expr [14531,14597]
atom_expr [14888,14954]
===
match
---
name: io [6710,6712]
name: io [7067,7069]
===
match
---
operator: , [1140,1141]
operator: , [1140,1141]
===
match
---
simple_stmt [1360,1421]
simple_stmt [1360,1421]
===
match
---
operator: = [2633,2634]
operator: = [2633,2634]
===
match
---
trailer [18350,18360]
trailer [18707,18717]
===
match
---
trailer [13977,13979]
trailer [14334,14336]
===
match
---
name: StringIO [12031,12039]
name: StringIO [12388,12396]
===
match
---
operator: = [1559,1560]
operator: = [1559,1560]
===
match
---
name: cli [1017,1020]
name: cli [1017,1020]
===
match
---
testlist_comp [2391,2476]
testlist_comp [2391,2476]
===
match
---
operator: , [19359,19360]
operator: , [19716,19717]
===
match
---
operator: + [11038,11039]
operator: + [11395,11396]
===
match
---
arglist [1716,1817]
arglist [1716,1817]
===
match
---
string: 'example_bash_operator' [16405,16428]
string: 'example_bash_operator' [16762,16785]
===
match
---
operator: , [4147,4148]
operator: , [4147,4148]
===
match
---
simple_stmt [1233,1271]
simple_stmt [1233,1271]
===
match
---
trailer [3741,3751]
trailer [3741,3751]
===
match
---
arglist [7908,8311]
arglist [8265,8668]
===
match
---
trailer [9050,9058]
trailer [9407,9415]
===
match
---
name: temp_stdout [6728,6739]
name: temp_stdout [7085,7096]
===
match
---
name: output [3803,3809]
name: output [3803,3809]
===
match
---
name: out [11838,11841]
name: out [12195,12198]
===
match
---
operator: , [11948,11949]
operator: , [12305,12306]
===
match
---
trailer [17689,17691]
trailer [18046,18048]
===
match
---
simple_stmt [5465,5509]
simple_stmt [5822,5866]
===
match
---
operator: , [17612,17613]
operator: , [17969,17970]
===
match
---
operator: , [8310,8311]
operator: , [8667,8668]
===
match
---
name: dag_show [5851,5859]
name: dag_show [6208,6216]
===
match
---
operator: = [3615,3616]
operator: = [3615,3616]
===
match
---
name: out [11768,11771]
name: out [12125,12128]
===
match
---
operator: = [17493,17494]
operator: = [17850,17851]
===
match
---
trailer [18483,18539]
trailer [18840,18896]
===
match
---
name: cli_parser [2078,2088]
name: cli_parser [2078,2088]
===
match
---
operator: , [13844,13845]
operator: , [14201,14202]
===
match
---
operator: , [14371,14372]
operator: , [14728,14729]
===
match
---
atom [10999,11025]
atom [11356,11382]
===
match
---
dotted_name [1102,1116]
dotted_name [1102,1116]
===
match
---
decorator [6278,6337]
decorator [6635,6694]
===
match
---
atom [5376,5417]
atom [5733,5774]
===
match
---
dotted_name [6210,6220]
dotted_name [6567,6577]
===
match
---
expr_stmt [14729,14804]
expr_stmt [15086,15161]
===
match
---
operator: = [2567,2568]
operator: = [2567,2568]
===
match
---
assert_stmt [14642,14719]
assert_stmt [14999,15076]
===
match
---
string: 'core' [12422,12428]
string: 'core' [12779,12785]
===
match
---
trailer [10279,10288]
trailer [10636,10645]
===
match
---
name: isoformat [8865,8874]
name: isoformat [9222,9231]
===
match
---
name: args [14837,14841]
name: args [15194,15198]
===
match
---
import_from [1004,1048]
import_from [1004,1048]
===
match
---
expr_stmt [13114,13142]
expr_stmt [13471,13499]
===
match
---
string: 'example_bash_operator' [18515,18538]
string: 'example_bash_operator' [18872,18895]
===
match
---
operator: , [17597,17598]
operator: , [17954,17955]
===
match
---
argument [5158,5171]
argument [5158,5171]
===
match
---
name: assert_called_once_with [6063,6086]
name: assert_called_once_with [6420,6443]
===
match
---
name: get_is_paused [14900,14913]
name: get_is_paused [15257,15270]
===
match
---
name: mock_get_dag [18224,18236]
name: mock_get_dag [18581,18593]
===
match
---
simple_stmt [14851,14930]
simple_stmt [15208,15287]
===
match
---
atom_expr [5262,5303]
atom_expr [5619,5660]
===
match
---
operator: = [10733,10734]
operator: = [11090,11091]
===
match
---
trailer [10799,10801]
trailer [11156,11158]
===
match
---
operator: = [5068,5069]
operator: = [5068,5069]
===
match
---
name: now [11442,11445]
name: now [11799,11802]
===
match
---
operator: = [17480,17481]
operator: = [17837,17838]
===
match
---
argument [8111,8133]
argument [8468,8490]
===
match
---
name: parser [9106,9112]
name: parser [9463,9469]
===
match
---
name: io [10277,10279]
name: io [10634,10636]
===
match
---
simple_stmt [1149,1184]
simple_stmt [1149,1184]
===
match
---
name: execution_date [18881,18895]
name: execution_date [19238,19252]
===
match
---
string: "2021-06-04T00:00:00+00:00" [16101,16128]
string: "2021-06-04T00:00:00+00:00" [16458,16485]
===
match
---
name: get_is_paused [14691,14704]
name: get_is_paused [15048,15061]
===
match
---
atom_expr [16795,16811]
atom_expr [17152,17168]
===
match
---
name: return_value [6043,6055]
name: return_value [6400,6412]
===
match
---
name: tis [20387,20390]
name: tis [20744,20747]
===
match
---
string: 'example_bash_operator' [14572,14595]
string: 'example_bash_operator' [14929,14952]
===
match
---
name: out [12690,12693]
name: out [13047,13050]
===
match
---
trailer [2354,2361]
trailer [2354,2361]
===
match
---
name: args [12919,12923]
name: args [13276,13280]
===
match
---
string: "graph [label=example_bash_operator labelloc=t rankdir=LR]" [5524,5583]
string: "graph [label=example_bash_operator labelloc=t rankdir=LR]" [5881,5940]
===
match
---
string: '/' [1440,1443]
string: '/' [1440,1443]
===
match
---
name: self [13418,13422]
name: self [13775,13779]
===
match
---
string: '--dag-id' [13728,13738]
string: '--dag-id' [14085,14095]
===
match
---
name: self [19326,19330]
name: self [19683,19687]
===
match
---
name: path [1735,1739]
name: path [1735,1739]
===
match
---
comparison [13315,13333]
comparison [13672,13690]
===
match
---
import_as_names [1124,1148]
import_as_names [1124,1148]
===
match
---
operator: = [8152,8153]
operator: = [8509,8510]
===
match
---
name: StringIO [5799,5807]
name: StringIO [6156,6164]
===
match
---
name: parser [17937,17943]
name: parser [18294,18300]
===
match
---
atom_expr [9039,9066]
atom_expr [9396,9423]
===
match
---
trailer [16194,16201]
trailer [16551,16558]
===
match
---
name: mock_render_dag [5738,5753]
name: mock_render_dag [6095,6110]
===
match
---
trailer [4276,4294]
trailer [4276,4294]
===
match
---
name: DM [17658,17660]
name: DM [18015,18017]
===
match
---
atom_expr [12696,12718]
atom_expr [13053,13075]
===
match
---
simple_stmt [16722,16751]
simple_stmt [17079,17108]
===
match
---
name: State [19990,19995]
name: State [20347,20352]
===
match
---
atom_expr [18413,19037]
atom_expr [18770,19394]
===
match
---
name: test_show_dag_dave [5713,5731]
name: test_show_dag_dave [6070,6088]
===
match
---
name: name [17496,17500]
name: name [17853,17857]
===
match
---
assert_stmt [13244,13299]
assert_stmt [13601,13656]
===
match
---
string: 'report' [12535,12543]
string: 'report' [12892,12900]
===
match
---
operator: = [10696,10697]
operator: = [11053,11054]
===
match
---
name: out [12820,12823]
name: out [13177,13180]
===
match
---
trailer [19571,19580]
trailer [19928,19937]
===
match
---
testlist_comp [10198,10234]
testlist_comp [10555,10591]
===
match
---
string: 'runme_0' [3417,3426]
string: 'runme_0' [3417,3426]
===
match
---
argument [2768,2790]
argument [2768,2790]
===
match
---
name: clear [18569,18574]
name: clear [18926,18931]
===
match
---
expr_stmt [8718,9024]
expr_stmt [9075,9381]
===
match
---
trailer [12589,12605]
trailer [12946,12962]
===
match
---
name: parser [2069,2075]
name: parser [2069,2075]
===
match
---
simple_stmt [12690,12719]
simple_stmt [13047,13076]
===
match
---
trailer [11651,11667]
trailer [12008,12024]
===
match
---
string: "airflow.cli.commands.dag_command.render_dag" [6290,6335]
string: "airflow.cli.commands.dag_command.render_dag" [6647,6692]
===
match
---
expr_stmt [8614,8659]
expr_stmt [8971,9016]
===
match
---
trailer [17671,17683]
trailer [18028,18040]
===
match
---
string: 'dags' [16867,16873]
string: 'dags' [17224,17230]
===
match
---
name: AirflowException [16996,17012]
name: AirflowException [17353,17369]
===
match
---
string: 'dags' [15070,15076]
string: 'dags' [15427,15433]
===
match
---
operator: , [14348,14349]
operator: , [14705,14706]
===
match
---
name: dag_id [11159,11165]
name: dag_id [11516,11522]
===
match
---
simple_stmt [7862,8322]
simple_stmt [8219,8679]
===
match
---
name: args [11558,11562]
name: args [11915,11919]
===
match
---
atom [10712,10737]
atom [11069,11094]
===
match
---
string: 'test_dagrun_states_deadlock' [7434,7463]
string: 'test_dagrun_states_deadlock' [7791,7820]
===
match
---
name: DEFAULT_DATE [10659,10671]
name: DEFAULT_DATE [11016,11028]
===
match
---
operator: = [14529,14530]
operator: = [14886,14887]
===
match
---
argument [8147,8157]
argument [8504,8514]
===
match
---
name: mark_success [8171,8183]
name: mark_success [8528,8540]
===
match
---
name: settings [960,968]
name: settings [960,968]
===
match
---
operator: , [13812,13813]
operator: , [14169,14170]
===
match
---
parameters [17724,17730]
parameters [18081,18087]
===
match
---
operator: = [20082,20083]
operator: = [20439,20440]
===
match
---
name: assert_not_called [4277,4294]
name: assert_not_called [4277,4294]
===
match
---
atom_expr [16188,16213]
atom_expr [16545,16570]
===
match
---
operator: @ [6278,6279]
operator: @ [6635,6636]
===
match
---
trailer [17683,17689]
trailer [18040,18046]
===
match
---
trailer [19748,19753]
trailer [20105,20110]
===
match
---
operator: = [4875,4876]
operator: = [4875,4876]
===
match
---
expr_stmt [1676,1819]
expr_stmt [1676,1819]
===
match
---
name: airflow [1154,1161]
name: airflow [1154,1161]
===
match
---
import_from [1049,1096]
import_from [1049,1096]
===
match
---
trailer [16831,16842]
trailer [17188,17199]
===
match
---
name: dag_report [12661,12671]
name: dag_report [13018,13028]
===
match
---
trailer [20052,20282]
trailer [20409,20639]
===
match
---
atom [18296,18363]
atom [18653,18720]
===
match
---
name: mock_get_dag [18413,18425]
name: mock_get_dag [18770,18782]
===
match
---
name: self [4382,4386]
name: self [4382,4386]
===
match
---
string: 'dags' [5901,5907]
string: 'dags' [6258,6264]
===
match
---
funcdef [2269,5213]
funcdef [2269,5213]
===
match
---
atom_expr [1912,1929]
atom_expr [1912,1929]
===
match
---
atom_expr [19656,19673]
atom_expr [20013,20030]
===
match
---
name: self [16168,16172]
name: self [16525,16529]
===
match
---
name: patch [19179,19184]
name: patch [19536,19541]
===
match
---
trailer [16279,16290]
trailer [16636,16647]
===
match
---
string: "bar" [15662,15667]
string: "bar" [16019,16024]
===
match
---
operator: , [11956,11957]
operator: , [12313,12314]
===
match
---
operator: = [6537,6538]
operator: = [6894,6895]
===
match
---
trailer [15966,15976]
trailer [16323,16333]
===
match
---
trailer [1465,1475]
trailer [1465,1475]
===
match
---
operator: , [1545,1546]
operator: , [1545,1546]
===
match
---
funcdef [18200,19038]
funcdef [18557,19395]
===
match
---
name: os [1698,1700]
name: os [1698,1700]
===
match
---
string: 'dags' [14555,14561]
string: 'dags' [14912,14918]
===
match
---
operator: , [2707,2708]
operator: , [2707,2708]
===
match
---
name: exceptions [1062,1072]
name: exceptions [1062,1072]
===
match
---
operator: , [19449,19450]
operator: , [19806,19807]
===
match
---
operator: = [8706,8707]
operator: = [9063,9064]
===
match
---
name: now [11410,11413]
name: now [11767,11770]
===
match
---
operator: , [9338,9339]
operator: , [9695,9696]
===
match
---
atom_expr [18661,18684]
atom_expr [19018,19041]
===
match
---
trailer [9100,9139]
trailer [9457,9496]
===
match
---
atom_expr [7789,7852]
atom_expr [8146,8209]
===
match
---
atom [3973,4212]
atom [3973,4212]
===
match
---
operator: , [9538,9539]
operator: , [9895,9896]
===
match
---
name: dirname [1740,1747]
name: dirname [1740,1747]
===
match
---
simple_stmt [17459,17503]
simple_stmt [17816,17860]
===
match
---
operator: = [14734,14735]
operator: = [15091,15092]
===
match
---
import_name [925,938]
import_name [925,938]
===
match
---
name: self [16659,16663]
name: self [17016,17020]
===
match
---
suite [10307,10561]
suite [10664,10918]
===
match
---
string: '/' [1482,1485]
string: '/' [1482,1485]
===
match
---
argument [9283,9306]
argument [9640,9663]
===
match
---
string: 'example_bash_operator' [14666,14689]
string: 'example_bash_operator' [15023,15046]
===
match
---
dictorsetmaker [12841,12874]
dictorsetmaker [13198,13231]
===
match
---
trailer [16770,16786]
trailer [17127,17143]
===
match
---
trailer [12193,12196]
trailer [12550,12553]
===
match
---
funcdef [17161,17697]
funcdef [17518,18054]
===
match
---
name: dag [9135,9138]
name: dag [9492,9495]
===
match
---
trailer [5850,5859]
trailer [6207,6216]
===
match
---
string: "airflow.cli.commands.dag_command.DAG.run" [2221,2263]
string: "airflow.cli.commands.dag_command.DAG.run" [2221,2263]
===
match
---
atom_expr [12176,12196]
atom_expr [12533,12553]
===
match
---
name: MagicMock [6496,6505]
name: MagicMock [6853,6862]
===
match
---
atom_expr [5839,5981]
atom_expr [6196,6338]
===
match
---
name: dag_id [7589,7595]
name: dag_id [7946,7952]
===
match
---
string: "None" [11125,11131]
string: "None" [11482,11488]
===
match
---
name: dag_backfill [4356,4368]
name: dag_backfill [4356,4368]
===
match
---
operator: , [4842,4843]
operator: , [4842,4843]
===
match
---
name: assert_not_called [3828,3845]
name: assert_not_called [3828,3845]
===
match
---
trailer [8701,8709]
trailer [9058,9066]
===
match
---
name: mock [5647,5651]
name: mock [6004,6008]
===
match
---
name: fileloc [17486,17493]
name: fileloc [17843,17850]
===
match
---
atom_expr [4382,4673]
atom_expr [4382,4673]
===
match
---
trailer [4747,5182]
trailer [4747,5182]
===
match
---
name: parse_args [13430,13440]
name: parse_args [13787,13797]
===
match
---
name: self [14509,14513]
name: self [14866,14870]
===
match
---
argument [2652,2675]
argument [2652,2675]
===
match
---
trailer [10395,10397]
trailer [10752,10754]
===
match
---
name: hours [10780,10785]
name: hours [11137,11142]
===
match
---
suite [6740,6883]
suite [7097,7240]
===
match
---
trailer [13429,13440]
trailer [13786,13797]
===
match
---
decorators [19043,19295]
decorators [19400,19652]
===
match
---
expr_stmt [14102,14448]
expr_stmt [14459,14805]
===
match
---
name: self [6791,6795]
name: self [7148,7152]
===
match
---
name: args [11746,11750]
name: args [12103,12107]
===
match
---
decorators [18074,18196]
decorators [18431,18553]
===
match
---
atom_expr [18926,18949]
atom_expr [19283,19306]
===
match
---
trailer [19844,20019]
trailer [20201,20376]
===
match
---
decorated [18074,19038]
decorated [18431,19395]
===
match
---
trailer [11025,11035]
trailer [11382,11392]
===
match
---
operator: , [15152,15153]
operator: , [15509,15510]
===
match
---
name: dagbag [9044,9050]
name: dagbag [9401,9407]
===
match
---
fstring_expr [3728,3754]
fstring_expr [3728,3754]
===
match
---
name: dag_command [14971,14982]
name: dag_command [15328,15339]
===
match
---
assert_stmt [12792,12823]
assert_stmt [13149,13180]
===
match
---
trailer [2519,2543]
trailer [2519,2543]
===
match
---
expr_stmt [17369,17397]
expr_stmt [17726,17754]
===
match
---
assert_stmt [6165,6203]
assert_stmt [6522,6560]
===
match
---
argument [2594,2615]
argument [2594,2615]
===
match
---
atom_expr [17801,17832]
atom_expr [18158,18189]
===
match
---
trailer [2177,2179]
trailer [2177,2179]
===
match
---
trailer [12617,12619]
trailer [12974,12976]
===
match
---
string: 'next-execution' [11932,11948]
string: 'next-execution' [12289,12305]
===
match
---
trailer [3906,3919]
trailer [3906,3919]
===
match
---
name: self [12481,12485]
name: self [12838,12842]
===
match
---
decorator [5646,5705]
decorator [6003,6062]
===
match
---
name: linesep [10938,10945]
name: linesep [11295,11302]
===
match
---
string: '--limit' [14339,14348]
string: '--limit' [14696,14705]
===
match
---
string: 'delete' [17099,17107]
string: 'delete' [17456,17464]
===
match
---
param [19332,19345]
param [19689,19702]
===
match
---
name: args [10167,10171]
name: args [10524,10528]
===
match
---
name: hours [11016,11021]
name: hours [11373,11378]
===
match
---
suite [11188,12204]
suite [11545,12561]
===
match
---
trailer [10032,10038]
trailer [10389,10395]
===
match
---
name: stdout [3128,3134]
name: stdout [3128,3134]
===
match
---
name: DEFAULT_DATE [3729,3741]
name: DEFAULT_DATE [3729,3741]
===
match
---
name: mock [20037,20041]
name: mock [20394,20398]
===
match
---
operator: , [7981,7982]
operator: , [8338,8339]
===
match
---
atom_expr [6753,6882]
atom_expr [7110,7239]
===
match
---
operator: = [9591,9592]
operator: = [9948,9949]
===
match
---
operator: , [20109,20110]
operator: , [20466,20467]
===
match
---
operator: = [16780,16781]
operator: = [17137,17138]
===
match
---
trailer [11079,11089]
trailer [11436,11446]
===
match
---
atom_expr [17459,17502]
atom_expr [17816,17859]
===
match
---
atom_expr [13934,13979]
atom_expr [14291,14336]
===
match
---
simple_stmt [7746,7780]
simple_stmt [8103,8137]
===
match
---
name: ignore_first_depends_on_past [8064,8092]
name: ignore_first_depends_on_past [8421,8449]
===
match
---
simple_stmt [18373,18404]
simple_stmt [18730,18761]
===
match
---
operator: , [11930,11931]
operator: , [12287,12288]
===
match
---
string: 'trigger' [13508,13517]
string: 'trigger' [13865,13874]
===
match
---
name: dag [4687,4690]
name: dag [4687,4690]
===
match
---
name: mock [8328,8332]
name: mock [8685,8689]
===
match
---
atom [11053,11079]
atom [11410,11436]
===
match
---
name: expected_output [11816,11831]
name: expected_output [12173,12188]
===
match
---
operator: == [15459,15461]
operator: == [15816,15818]
===
match
---
string: 'dags' [17091,17097]
string: 'dags' [17448,17454]
===
match
---
name: timedelta [11060,11069]
name: timedelta [11417,11426]
===
match
---
string: 'example_bash_operator' [4055,4078]
string: 'example_bash_operator' [4055,4078]
===
match
---
trailer [6558,6570]
trailer [6915,6927]
===
match
---
name: create_session [1218,1232]
name: create_session [1218,1232]
===
match
---
argument [19778,19808]
argument [20135,20165]
===
match
---
atom [14554,14596]
atom [14911,14953]
===
match
---
param [5242,5246]
param [5599,5603]
===
match
---
name: out [13232,13235]
name: out [13589,13592]
===
match
---
operator: , [9385,9386]
operator: , [9742,9743]
===
match
---
name: cli_args [20142,20150]
name: cli_args [20499,20507]
===
match
---
name: dag_command [18373,18384]
name: dag_command [18730,18741]
===
match
---
number: 8 [11076,11077]
number: 8 [11433,11434]
===
match
---
trailer [1528,1573]
trailer [1528,1573]
===
match
---
name: self [11565,11569]
name: self [11922,11926]
===
match
---
name: io [12606,12608]
name: io [12963,12965]
===
match
---
operator: + [10717,10718]
operator: + [11074,11075]
===
match
---
name: args [7524,7528]
name: args [7881,7885]
===
match
---
atom_expr [8916,8936]
atom_expr [9273,9293]
===
match
---
name: parse_args [19410,19420]
name: parse_args [19767,19777]
===
match
---
operator: , [10841,10842]
operator: , [11198,11199]
===
match
---
name: run_date [7660,7668]
name: run_date [8017,8025]
===
match
---
trailer [18771,18776]
trailer [19128,19133]
===
match
---
name: parse_args [11912,11922]
name: parse_args [12269,12279]
===
match
---
argument [2922,2941]
argument [2922,2941]
===
match
---
operator: , [3426,3427]
operator: , [3426,3427]
===
match
---
name: self [17747,17751]
name: self [18104,18108]
===
match
---
operator: , [9269,9270]
operator: , [9626,9627]
===
match
---
operator: = [7918,7919]
operator: = [8275,8276]
===
match
---
argument [8652,8658]
argument [9009,9015]
===
match
---
trailer [19402,19409]
trailer [19759,19766]
===
match
---
number: 2015 [1538,1542]
number: 2015 [1538,1542]
===
match
---
string: 'return_value.source' [19114,19135]
string: 'return_value.source' [19471,19492]
===
match
---
string: '--show-dagrun' [19502,19517]
string: '--show-dagrun' [19859,19874]
===
match
---
argument [8226,8250]
argument [8583,8607]
===
match
---
name: parse_args [14543,14553]
name: parse_args [14900,14910]
===
match
---
arglist [9194,9598]
arglist [9551,9955]
===
match
---
name: contextlib [794,804]
name: contextlib [794,804]
===
match
---
string: "None" [10835,10841]
string: "None" [11192,11198]
===
match
---
atom [12420,12455]
atom [12777,12812]
===
match
---
simple_stmt [12649,12678]
simple_stmt [13006,13035]
===
match
---
atom_expr [11313,11496]
atom_expr [11670,11853]
===
match
---
string: 'test' [19443,19449]
string: 'test' [19800,19806]
===
match
---
operator: = [11772,11773]
operator: = [12129,12130]
===
match
---
name: parse_args [14121,14131]
name: parse_args [14478,14488]
===
match
---
import_from [1360,1420]
import_from [1360,1420]
===
match
---
string: 'unit_tests' [1661,1673]
string: 'unit_tests' [1661,1673]
===
match
---
arglist [18484,18538]
arglist [18841,18895]
===
match
---
name: datetime [13954,13962]
name: datetime [14311,14319]
===
match
---
atom_expr [1560,1572]
atom_expr [1560,1572]
===
match
---
atom_expr [19607,19637]
atom_expr [19964,19994]
===
match
---
trailer [18010,18020]
trailer [18367,18377]
===
match
---
atom_expr [17027,17155]
atom_expr [17384,17512]
===
match
---
string: 'awesome.png' [5952,5965]
string: 'awesome.png' [6309,6322]
===
match
---
name: delay_on_limit_secs [2652,2671]
name: delay_on_limit_secs [2652,2671]
===
match
---
expr_stmt [1494,1573]
expr_stmt [1494,1573]
===
match
---
string: 'core' [12842,12848]
string: 'core' [13199,13205]
===
match
---
testlist_comp [17771,17790]
testlist_comp [18128,18147]
===
match
---
name: self [13366,13370]
name: self [13723,13727]
===
match
---
name: dag_id [16774,16780]
name: dag_id [17131,17137]
===
match
---
operator: = [8581,8582]
operator: = [8938,8939]
===
match
---
parameters [1967,1972]
parameters [1967,1972]
===
match
---
suite [14962,16129]
suite [15319,16486]
===
match
---
name: out [5990,5993]
name: out [6347,6350]
===
match
---
suite [10007,10131]
suite [10364,10488]
===
match
---
parameters [6365,6400]
parameters [6722,6757]
===
match
---
operator: , [1637,1638]
operator: , [1637,1638]
===
match
---
trailer [19836,19838]
trailer [20193,20195]
===
match
---
name: timedelta [888,897]
name: timedelta [888,897]
===
match
---
trailer [17651,17657]
trailer [18008,18014]
===
match
---
name: mark_success [9459,9471]
name: mark_success [9816,9828]
===
match
---
trailer [20150,20165]
trailer [20507,20522]
===
match
---
atom_expr [20196,20219]
atom_expr [20553,20576]
===
match
---
decorator [1936,1949]
decorator [1936,1949]
===
match
---
atom_expr [10763,10801]
atom_expr [11120,11158]
===
match
---
trailer [6764,6773]
trailer [7121,7130]
===
match
---
name: parser [19403,19409]
name: parser [19760,19766]
===
match
---
trailer [18776,18778]
trailer [19133,19135]
===
match
---
operator: , [16379,16380]
operator: , [16736,16737]
===
match
---
trailer [12525,12565]
trailer [12882,12922]
===
match
---
name: __enter__ [6635,6644]
name: __enter__ [6992,7001]
===
match
---
name: dr [10020,10022]
name: dr [10377,10379]
===
match
---
name: dagrun [15940,15946]
name: dagrun [16297,16303]
===
match
---
testlist_comp [17091,17138]
testlist_comp [17448,17495]
===
match
---
name: StringIO [13030,13038]
name: StringIO [13387,13395]
===
match
---
string: 'delete' [17599,17607]
string: 'delete' [17956,17964]
===
match
---
name: temp_stdout [11774,11785]
name: temp_stdout [12131,12142]
===
match
---
argument [17672,17682]
argument [18029,18039]
===
match
---
trailer [17943,17954]
trailer [18300,18311]
===
match
---
trailer [17038,17049]
trailer [17395,17406]
===
match
---
string: 'dags' [11589,11595]
string: 'dags' [11946,11952]
===
match
---
name: dag [9131,9134]
name: dag [9488,9491]
===
match
---
name: timezone [1560,1568]
name: timezone [1560,1568]
===
match
---
atom [10197,10235]
atom [10554,10592]
===
match
---
trailer [16049,16067]
trailer [16406,16424]
===
match
---
name: dag [11313,11316]
name: dag [11670,11673]
===
match
---
name: isoformat [2465,2474]
name: isoformat [2465,2474]
===
match
---
operator: @ [8327,8328]
operator: @ [8684,8685]
===
match
---
name: mock_popen [6389,6399]
name: mock_popen [6746,6756]
===
match
---
operator: @ [5646,5647]
operator: @ [6003,6004]
===
match
---
atom_expr [5332,5419]
atom_expr [5689,5776]
===
match
---
simple_stmt [9076,9140]
simple_stmt [9433,9497]
===
match
---
name: StringIO [10280,10288]
name: StringIO [10637,10645]
===
match
---
atom_expr [1982,1992]
atom_expr [1982,1992]
===
match
---
name: query [10033,10038]
name: query [10390,10395]
===
match
---
operator: , [6593,6594]
operator: , [6950,6951]
===
match
---
with_stmt [3078,3635]
with_stmt [3078,3635]
===
match
---
atom [7531,7737]
atom [7888,8094]
===
match
---
operator: , [14561,14562]
operator: , [14918,14919]
===
match
---
trailer [6425,6438]
trailer [6782,6795]
===
match
---
simple_stmt [20316,20397]
simple_stmt [20673,20754]
===
match
---
trailer [10103,10130]
trailer [10460,10487]
===
match
---
trailer [16943,16955]
trailer [17300,17312]
===
match
---
decorator [7128,7184]
decorator [7485,7541]
===
match
---
name: add [16767,16770]
name: add [17124,17127]
===
match
---
name: dag_command [12649,12660]
name: dag_command [13006,13017]
===
match
---
name: StringIO [6713,6721]
name: StringIO [7070,7078]
===
match
---
name: dag_command [9076,9087]
name: dag_command [9433,9444]
===
match
---
name: args [12106,12110]
name: args [12463,12467]
===
match
---
simple_stmt [1647,1674]
simple_stmt [1647,1674]
===
match
---
param [14087,14091]
param [14444,14448]
===
match
---
operator: @ [6209,6210]
operator: @ [6566,6567]
===
match
---
string: 'show' [5385,5391]
string: 'show' [5742,5748]
===
match
---
atom_expr [4715,5182]
atom_expr [4715,5182]
===
match
---
atom_expr [1995,2024]
atom_expr [1995,2024]
===
match
---
trailer [12319,12326]
trailer [12676,12683]
===
match
---
name: mock_render_dag [6027,6042]
name: mock_render_dag [6384,6399]
===
match
---
param [14956,14960]
param [15313,15317]
===
match
---
name: State [1265,1270]
name: State [1265,1270]
===
match
---
operator: = [2962,2963]
operator: = [2962,2963]
===
match
---
arglist [19754,19808]
arglist [20111,20165]
===
match
---
name: execution_date [15718,15732]
name: execution_date [16075,16089]
===
match
---
comparison [14858,14929]
comparison [15215,15286]
===
match
---
param [2287,2292]
param [2287,2292]
===
match
---
name: parse_args [5889,5899]
name: parse_args [6246,6256]
===
match
---
name: cli_args [19628,19636]
name: cli_args [19985,19993]
===
match
---
atom_expr [15567,15584]
atom_expr [15924,15941]
===
match
---
operator: ** [19111,19113]
operator: ** [19468,19470]
===
match
---
name: return_value [6571,6583]
name: return_value [6928,6940]
===
match
---
name: utils [1284,1289]
name: utils [1284,1289]
===
match
---
param [6366,6371]
param [6723,6728]
===
match
---
decorators [6209,6337]
decorators [6566,6694]
===
match
---
name: contextlib [13000,13010]
name: contextlib [13357,13367]
===
match
---
atom_expr [2312,2501]
atom_expr [2312,2501]
===
match
---
operator: } [19145,19146]
operator: } [19502,19503]
===
match
---
name: timedelta [10955,10964]
name: timedelta [11312,11321]
===
match
---
suite [2155,2204]
suite [2155,2204]
===
match
---
trailer [16290,16618]
trailer [16647,16975]
===
match
---
simple_stmt [17740,17793]
simple_stmt [18097,18150]
===
match
---
name: os [1748,1750]
name: os [1748,1750]
===
match
---
name: timezone [1509,1517]
name: timezone [1509,1517]
===
match
---
atom_expr [4616,4640]
atom_expr [4616,4640]
===
match
---
simple_stmt [6516,6541]
simple_stmt [6873,6898]
===
match
---
atom_expr [15711,15762]
atom_expr [16068,16119]
===
match
---
argument [8297,8310]
argument [8654,8667]
===
match
---
name: local [2804,2809]
name: local [2804,2809]
===
match
---
operator: , [3553,3554]
operator: , [3553,3554]
===
match
---
trailer [15481,15485]
trailer [15838,15842]
===
match
---
comparison [14649,14719]
comparison [15006,15076]
===
match
---
suite [16214,16634]
suite [16571,16991]
===
match
---
simple_stmt [1004,1049]
simple_stmt [1004,1049]
===
match
---
trailer [12333,12340]
trailer [12690,12697]
===
match
---
expr_stmt [5990,6018]
expr_stmt [6347,6375]
===
match
---
simple_stmt [18413,19038]
simple_stmt [18770,19395]
===
match
---
trailer [11726,11745]
trailer [12083,12102]
===
match
---
assert_stmt [16036,16128]
assert_stmt [16393,16485]
===
match
---
funcdef [9614,12404]
funcdef [9971,12761]
===
match
---
name: timedelta [8642,8651]
name: timedelta [8999,9008]
===
match
---
operator: + [11058,11059]
operator: + [11415,11416]
===
match
---
simple_stmt [19607,19638]
simple_stmt [19964,19995]
===
match
---
name: mock_proc [6516,6525]
name: mock_proc [6873,6882]
===
match
---
arith_expr [10949,10972]
arith_expr [11306,11329]
===
match
---
name: parser [17072,17078]
name: parser [17429,17435]
===
match
---
operator: + [10946,10947]
operator: + [11303,11304]
===
match
---
string: "2021-06-03T00:00:00+00:00" [16000,16027]
string: "2021-06-03T00:00:00+00:00" [16357,16384]
===
match
---
parameters [7225,7241]
parameters [7582,7598]
===
match
---
simple_stmt [13181,13205]
simple_stmt [13538,13562]
===
match
---
atom_expr [5796,5809]
atom_expr [6153,6166]
===
match
---
atom_expr [10250,10291]
atom_expr [10607,10648]
===
match
---
expr_stmt [10020,10081]
expr_stmt [10377,10438]
===
match
---
name: end_date [2594,2602]
name: end_date [2594,2602]
===
match
---
atom_expr [6516,6536]
atom_expr [6873,6893]
===
match
---
atom_expr [16771,16785]
atom_expr [17128,17142]
===
match
---
simple_stmt [10680,10853]
simple_stmt [11037,11210]
===
match
---
funcdef [8387,9609]
funcdef [8744,9966]
===
match
---
atom_expr [8642,8659]
atom_expr [8999,9016]
===
match
---
operator: , [16464,16465]
operator: , [16821,16822]
===
match
---
trailer [19618,19627]
trailer [19975,19984]
===
match
---
name: execution_date [19940,19954]
name: execution_date [20297,20311]
===
match
---
trailer [18295,18364]
trailer [18652,18721]
===
match
---
testlist_comp [8739,9014]
testlist_comp [9096,9371]
===
match
---
atom [10881,11142]
atom [11238,11499]
===
match
---
arglist [11348,11482]
arglist [11705,11839]
===
match
---
trailer [2068,2075]
trailer [2068,2075]
===
match
---
trailer [9123,9129]
trailer [9480,9486]
===
match
---
name: dag_id [11224,11230]
name: dag_id [11581,11587]
===
match
---
operator: = [10969,10970]
operator: = [11326,11327]
===
match
---
operator: , [12976,12977]
operator: , [13333,13334]
===
match
---
operator: = [16677,16678]
operator: = [17034,17035]
===
match
---
trailer [16067,16077]
trailer [16424,16434]
===
match
---
string: '--local' [4549,4558]
string: '--local' [4549,4558]
===
match
---
operator: , [9570,9571]
operator: , [9927,9928]
===
match
---
operator: + [11004,11005]
operator: + [11361,11362]
===
match
---
string: "airflow.cli.commands.dag_command.DebugExecutor" [19185,19233]
string: "airflow.cli.commands.dag_command.DebugExecutor" [19542,19590]
===
match
---
operator: , [11976,11977]
operator: , [12333,12334]
===
match
---
string: 'dags' [3995,4001]
string: 'dags' [3995,4001]
===
match
---
simple_stmt [13151,13173]
simple_stmt [13508,13530]
===
match
---
simple_stmt [9033,9067]
simple_stmt [9390,9424]
===
match
---
comparison [5472,5508]
comparison [5829,5865]
===
match
---
name: redirect_stdout [3094,3109]
name: redirect_stdout [3094,3109]
===
match
---
funcdef [12461,12824]
funcdef [12818,13181]
===
match
---
number: 1 [10734,10735]
number: 1 [11091,11092]
===
match
---
trailer [4368,4705]
trailer [4368,4705]
===
match
---
trailer [2043,2054]
trailer [2043,2054]
===
match
---
operator: = [9204,9205]
operator: = [9561,9562]
===
match
---
name: dag_test [19619,19627]
name: dag_test [19976,19984]
===
match
---
trailer [18615,18630]
trailer [18972,18987]
===
match
---
trailer [10911,10919]
trailer [11268,11276]
===
match
---
name: run_at_least_once [20241,20258]
name: run_at_least_once [20598,20615]
===
match
---
operator: { [12840,12841]
operator: { [13197,13198]
===
match
---
trailer [10260,10276]
trailer [10617,10633]
===
match
---
expr_stmt [5428,5456]
expr_stmt [5785,5813]
===
match
---
operator: = [5165,5166]
operator: = [5165,5166]
===
match
---
atom [17090,17139]
atom [17447,17496]
===
match
---
trailer [3551,3553]
trailer [3551,3553]
===
match
---
operator: = [9302,9303]
operator: = [9659,9660]
===
match
---
string: "airflow/example_dags/example_complex.py" [13251,13292]
string: "airflow/example_dags/example_complex.py" [13608,13649]
===
match
---
simple_stmt [11715,11752]
simple_stmt [12072,12109]
===
match
---
operator: = [7750,7751]
operator: = [8107,8108]
===
match
---
name: stdout [19656,19662]
name: stdout [20013,20019]
===
match
---
name: mock_executor [20083,20096]
name: mock_executor [20440,20453]
===
match
---
arglist [20074,20264]
arglist [20431,20621]
===
match
---
operator: , [13979,13980]
operator: , [14336,14337]
===
match
---
arith_expr [8627,8659]
arith_expr [8984,9016]
===
match
---
trailer [19712,20307]
trailer [20069,20664]
===
match
---
atom_expr [10025,10081]
atom_expr [10382,10438]
===
match
---
dotted_name [7129,7139]
dotted_name [7486,7496]
===
match
---
operator: , [19330,19331]
operator: , [19687,19688]
===
match
---
name: key [17481,17484]
name: key [17838,17841]
===
match
---
trailer [20372,20385]
trailer [20729,20742]
===
match
---
name: clear_db_runs [1407,1420]
name: clear_db_runs [1407,1420]
===
match
---
name: stdout [19587,19593]
name: stdout [19944,19950]
===
match
---
argument [8032,8050]
argument [8389,8407]
===
match
---
atom [19113,19146]
atom [19470,19503]
===
match
---
expr_stmt [3018,3068]
expr_stmt [3018,3068]
===
match
---
operator: , [13738,13739]
operator: , [14095,14096]
===
match
---
with_item [9979,10006]
with_item [10336,10363]
===
match
---
name: self [6366,6370]
name: self [6723,6727]
===
match
---
param [13366,13370]
param [13723,13727]
===
match
---
suite [16665,17156]
suite [17022,17513]
===
match
---
trailer [20354,20359]
trailer [20711,20716]
===
match
---
name: setUpClass [1957,1967]
name: setUpClass [1957,1967]
===
match
---
name: state [11463,11468]
name: state [11820,11825]
===
match
---
import_from [1233,1270]
import_from [1233,1270]
===
match
---
argument [18596,18630]
argument [18953,18987]
===
match
---
name: out [7119,7122]
name: out [7476,7479]
===
match
---
funcdef [7188,8322]
funcdef [7545,8679]
===
match
---
trailer [14899,14913]
trailer [15256,15270]
===
match
---
name: mock_executor [18813,18826]
name: mock_executor [19170,19183]
===
match
---
decorated [2209,5213]
decorated [2209,5213]
===
match
---
name: EXAMPLE_DAGS_FOLDER [1676,1695]
name: EXAMPLE_DAGS_FOLDER [1676,1695]
===
match
---
argument [11348,11377]
argument [11705,11734]
===
match
---
atom_expr [18607,18630]
atom_expr [18964,18987]
===
match
---
trailer [16955,16961]
trailer [17312,17318]
===
match
---
operator: , [8133,8134]
operator: , [8490,8491]
===
match
---
import_name [841,856]
import_name [841,856]
===
match
---
comparison [17644,17696]
comparison [18001,18053]
===
match
---
name: return_value [18827,18839]
name: return_value [19184,19196]
===
match
---
number: 1 [1547,1548]
number: 1 [1547,1548]
===
match
---
operator: , [4819,4820]
operator: , [4819,4820]
===
match
---
string: '--ignore-first-depends-on-past' [8950,8982]
string: '--ignore-first-depends-on-past' [9307,9339]
===
match
---
trailer [16865,16899]
trailer [17222,17256]
===
match
---
operator: @ [12829,12830]
operator: @ [13186,13187]
===
match
---
simple_stmt [1049,1097]
simple_stmt [1049,1097]
===
match
---
trailer [14617,14627]
trailer [14974,14984]
===
match
---
name: parser [11905,11911]
name: parser [12262,12268]
===
match
---
trailer [13942,13953]
trailer [14299,14310]
===
match
---
operator: , [13710,13711]
operator: , [14067,14068]
===
match
---
operator: , [20263,20264]
operator: , [20620,20621]
===
match
---
operator: = [2018,2019]
operator: = [2018,2019]
===
match
---
argument [17486,17500]
argument [17843,17857]
===
match
---
trailer [6016,6018]
trailer [6373,6375]
===
match
---
operator: , [2450,2451]
operator: , [2450,2451]
===
match
---
funcdef [16134,16634]
funcdef [16491,16991]
===
match
---
trailer [8934,8936]
trailer [9291,9293]
===
match
---
string: 'dags' [5377,5383]
string: 'dags' [5734,5740]
===
match
---
name: contextlib [11641,11651]
name: contextlib [11998,12008]
===
match
---
operator: , [14570,14571]
operator: , [14927,14928]
===
match
---
name: dag [9033,9036]
name: dag [9390,9393]
===
match
---
trailer [7763,7771]
trailer [8120,8128]
===
match
---
operator: = [8207,8208]
operator: = [8564,8565]
===
match
---
name: run [18779,18782]
name: run [19136,19139]
===
match
---
argument [8064,8097]
argument [8421,8454]
===
match
---
suite [5755,6204]
suite [6112,6561]
===
match
---
operator: = [9532,9533]
operator: = [9889,9890]
===
match
---
operator: , [7618,7619]
operator: , [7975,7976]
===
match
---
dotted_name [1276,1295]
dotted_name [1276,1295]
===
match
---
atom [4422,4659]
atom [4422,4659]
===
match
---
atom_expr [3529,3553]
atom_expr [3529,3553]
===
match
---
name: test_utils [1371,1381]
name: test_utils [1371,1381]
===
match
---
name: DagRun [15445,15451]
name: DagRun [15802,15808]
===
match
---
simple_stmt [11809,11842]
simple_stmt [12166,12199]
===
match
---
string: b'DOT_DATA' [7054,7065]
string: b'DOT_DATA' [7411,7422]
===
match
---
trailer [18880,18895]
trailer [19237,19252]
===
match
---
name: run_backwards [5125,5138]
name: run_backwards [5125,5138]
===
match
---
trailer [9105,9112]
trailer [9462,9469]
===
match
---
simple_stmt [6165,6204]
simple_stmt [6522,6561]
===
match
---
simple_stmt [12728,12784]
simple_stmt [13085,13141]
===
match
---
name: config [1336,1342]
name: config [1336,1342]
===
match
---
simple_stmt [6549,6603]
simple_stmt [6906,6960]
===
match
---
simple_stmt [11768,11797]
simple_stmt [12125,12154]
===
match
---
operator: , [20219,20220]
operator: , [20576,20577]
===
match
---
atom_expr [18273,18364]
atom_expr [18630,18721]
===
match
---
name: commit [17523,17529]
name: commit [17880,17886]
===
match
---
trailer [16766,16770]
trailer [17123,17127]
===
match
---
name: mock [18557,18561]
name: mock [18914,18918]
===
match
---
name: assert_called_once_with [4724,4747]
name: assert_called_once_with [4724,4747]
===
match
---
name: dag_command [1037,1048]
name: dag_command [1037,1048]
===
match
---
trailer [12948,12986]
trailer [13305,13343]
===
match
---
name: dr [12367,12369]
name: dr [12724,12726]
===
match
---
name: make_aware [1518,1528]
name: make_aware [1518,1528]
===
match
---
operator: , [14226,14227]
operator: , [14583,14584]
===
match
---
decorator [2107,2120]
decorator [2107,2120]
===
match
---
suite [12487,12824]
suite [12844,13181]
===
match
---
assert_stmt [15933,16027]
assert_stmt [16290,16384]
===
match
---
name: mock_render_dag [19361,19376]
name: mock_render_dag [19718,19733]
===
match
---
name: out [7091,7094]
name: out [7448,7451]
===
match
---
operator: , [10749,10750]
operator: , [11106,11107]
===
match
---
name: parser [15013,15019]
name: parser [15370,15376]
===
match
---
name: run_id [15452,15458]
name: run_id [15809,15815]
===
match
---
trailer [8651,8659]
trailer [9008,9016]
===
match
---
arith_expr [10999,11091]
arith_expr [11356,11448]
===
match
---
name: contextlib [6683,6693]
name: contextlib [7040,7050]
===
match
---
operator: = [4953,4954]
operator: = [4953,4954]
===
match
---
name: parser [14114,14120]
name: parser [14471,14477]
===
match
---
simple_stmt [11558,11624]
simple_stmt [11915,11981]
===
match
---
operator: , [8982,8983]
operator: , [9339,9340]
===
match
---
trailer [4191,4193]
trailer [4191,4193]
===
match
---
operator: , [8936,8937]
operator: , [9293,9294]
===
match
---
argument [20131,20165]
argument [20488,20522]
===
match
---
name: timezone [13934,13942]
name: timezone [14291,14299]
===
match
---
operator: , [13681,13682]
operator: , [14038,14039]
===
match
---
operator: = [12501,12502]
operator: = [12858,12859]
===
match
---
trailer [17578,17589]
trailer [17935,17946]
===
match
---
string: "test_trigger_dag" [15462,15480]
string: "test_trigger_dag" [15819,15837]
===
match
---
operator: , [18730,18731]
operator: , [19087,19088]
===
match
---
atom_expr [11774,11796]
atom_expr [12131,12153]
===
match
---
name: verbose [5158,5165]
name: verbose [5158,5165]
===
match
---
trailer [5445,5454]
trailer [5802,5811]
===
match
---
trailer [18574,18749]
trailer [18931,19106]
===
match
---
operator: = [18812,18813]
operator: = [19169,19170]
===
match
---
trailer [18826,18839]
trailer [19183,19196]
===
match
---
trailer [17387,17395]
trailer [17744,17752]
===
match
---
atom_expr [18557,18749]
atom_expr [18914,19106]
===
match
---
name: DEFAULT_DATE [1494,1506]
name: DEFAULT_DATE [1494,1506]
===
match
---
trailer [6438,6443]
trailer [6795,6800]
===
match
---
name: linesep [11043,11050]
name: linesep [11400,11407]
===
match
---
trailer [6525,6536]
trailer [6882,6893]
===
match
---
name: end_date [9229,9237]
name: end_date [9586,9594]
===
match
---
operator: = [4771,4772]
operator: = [4771,4772]
===
match
---
atom_expr [11060,11078]
atom_expr [11417,11435]
===
match
---
name: args [14729,14733]
name: args [15086,15090]
===
match
---
name: dag_command [6753,6764]
name: dag_command [7110,7121]
===
match
---
subscript [1487,1490]
subscript [1487,1490]
===
match
---
simple_stmt [9148,9609]
simple_stmt [9505,9966]
===
match
---
trailer [14740,14747]
trailer [15097,15104]
===
match
---
atom_expr [10320,10356]
atom_expr [10677,10713]
===
match
---
name: self [3933,3937]
name: self [3933,3937]
===
match
---
name: unittest [848,856]
name: unittest [848,856]
===
match
---
simple_stmt [10861,11143]
simple_stmt [11218,11500]
===
match
---
atom_expr [10895,10932]
atom_expr [11252,11289]
===
match
---
name: DM [16771,16773]
name: DM [17128,17130]
===
match
---
trailer [15380,15382]
trailer [15737,15739]
===
match
---
atom_expr [8854,8876]
atom_expr [9211,9233]
===
match
---
string: 'dags' [13480,13486]
string: 'dags' [13837,13843]
===
match
---
string: 'dags' [12950,12956]
string: 'dags' [13307,13313]
===
match
---
trailer [19552,19568]
trailer [19909,19925]
===
match
---
name: assert_called_once_with [2520,2543]
name: assert_called_once_with [2520,2543]
===
match
---
trailer [3827,3845]
trailer [3827,3845]
===
match
---
name: mock [19744,19748]
name: mock [20101,20105]
===
match
---
argument [18508,18538]
argument [18865,18895]
===
match
---
operator: , [2941,2942]
operator: , [2941,2942]
===
match
---
name: parse_args [9113,9123]
name: parse_args [9470,9480]
===
match
---
trailer [5888,5899]
trailer [6245,6256]
===
match
---
simple_stmt [1271,1314]
simple_stmt [1271,1314]
===
match
---
atom_expr [17544,17624]
atom_expr [17901,17981]
===
match
---
decorator [18074,18136]
decorator [18431,18493]
===
match
---
funcdef [14054,14489]
funcdef [14411,14846]
===
match
---
trailer [14535,14542]
trailer [14892,14899]
===
match
---
name: call [18562,18566]
name: call [18919,18923]
===
match
---
testlist_comp [10712,10842]
testlist_comp [11069,11199]
===
match
---
funcdef [2124,2204]
funcdef [2124,2204]
===
match
---
name: path [1719,1723]
name: path [1719,1723]
===
match
---
operator: = [6895,6896]
operator: = [7252,7253]
===
match
---
atom_expr [12926,12986]
atom_expr [13283,13343]
===
match
---
string: 'dags' [6815,6821]
string: 'dags' [7172,7178]
===
match
---
param [17195,17199]
param [17552,17556]
===
match
---
argument [16774,16784]
argument [17131,17141]
===
match
---
operator: , [9899,9900]
operator: , [10256,10257]
===
match
---
simple_stmt [7524,7738]
simple_stmt [7881,8095]
===
match
---
name: getvalue [6008,6016]
name: getvalue [6365,6373]
===
match
---
operator: , [9845,9846]
operator: , [10202,10203]
===
match
---
atom_expr [9148,9608]
atom_expr [9505,9965]
===
match
---
name: key [16951,16954]
name: key [17308,17311]
===
match
---
atom_expr [16732,16750]
atom_expr [17089,17107]
===
match
---
operator: , [11377,11378]
operator: , [11734,11735]
===
match
---
parameters [8434,8450]
parameters [8791,8807]
===
match
---
argument [2689,2707]
argument [2689,2707]
===
match
---
trailer [2323,2336]
trailer [2323,2336]
===
match
---
name: self [3024,3028]
name: self [3024,3028]
===
match
---
name: os [10935,10937]
name: os [11292,11294]
===
match
---
atom [6586,6602]
atom [6943,6959]
===
match
---
name: DM [16930,16932]
name: DM [17287,17289]
===
match
---
atom_expr [6928,6999]
atom_expr [7285,7356]
===
match
---
simple_stmt [17321,17335]
simple_stmt [17678,17692]
===
match
---
string: "2021-06-04T01:00:00+00:00" [15766,15793]
string: "2021-06-04T01:00:00+00:00" [16123,16150]
===
match
---
argument [10104,10129]
argument [10461,10486]
===
match
---
operator: , [7575,7576]
operator: , [7932,7933]
===
match
---
name: cli_args [20196,20204]
name: cli_args [20553,20561]
===
match
---
operator: + [8640,8641]
operator: + [8997,8998]
===
match
---
suite [9644,12404]
suite [10001,12761]
===
match
---
simple_stmt [10167,10237]
simple_stmt [10524,10594]
===
match
---
operator: = [18271,18272]
operator: = [18628,18629]
===
match
---
name: call [18772,18776]
name: call [19129,19133]
===
match
---
trailer [20041,20046]
trailer [20398,20403]
===
match
---
arith_expr [10895,10985]
arith_expr [11252,11342]
===
match
---
trailer [12937,12948]
trailer [13294,13305]
===
match
---
testlist_comp [12527,12563]
testlist_comp [12884,12920]
===
match
---
argument [5008,5018]
argument [5008,5018]
===
match
---
argument [10780,10787]
argument [11137,11144]
===
match
---
trailer [17419,17438]
trailer [17776,17795]
===
match
---
dotted_name [19044,19054]
dotted_name [19401,19411]
===
match
---
name: mock_render_dag [6928,6943]
name: mock_render_dag [7285,7300]
===
match
---
operator: = [20141,20142]
operator: = [20498,20499]
===
match
---
atom_expr [12649,12677]
atom_expr [13006,13034]
===
match
---
with_stmt [12574,12719]
with_stmt [12931,13076]
===
match
---
string: 'test' [18305,18311]
string: 'test' [18662,18668]
===
match
---
name: test_cli_backfill_depends_on_past_backwards [8391,8434]
name: test_cli_backfill_depends_on_past_backwards [8748,8791]
===
match
---
name: dag_command [4344,4355]
name: dag_command [4344,4355]
===
match
---
trailer [11211,11218]
trailer [11568,11575]
===
match
---
name: out [10557,10560]
name: out [10914,10917]
===
match
---
operator: = [5013,5014]
operator: = [5013,5014]
===
match
---
name: parser [5882,5888]
name: parser [6239,6245]
===
match
---
suite [11698,11797]
suite [12055,12154]
===
match
---
operator: = [7847,7848]
operator: = [8204,8205]
===
match
---
string: 'dags' [12527,12533]
string: 'dags' [12884,12890]
===
match
---
import_as_names [878,897]
import_as_names [878,897]
===
match
---
atom_expr [18720,18730]
atom_expr [19077,19087]
===
match
---
trailer [1718,1723]
trailer [1718,1723]
===
match
---
name: render [6056,6062]
name: render [6413,6419]
===
match
---
factor [1488,1490]
factor [1488,1490]
===
match
---
operator: = [15414,15415]
operator: = [15771,15772]
===
match
---
atom_expr [14457,14488]
atom_expr [14814,14845]
===
match
---
trailer [3035,3043]
trailer [3035,3043]
===
match
---
string: 'dags' [13675,13681]
string: 'dags' [14032,14038]
===
match
---
operator: , [17129,17130]
operator: , [17486,17487]
===
match
---
string: '--conf={"foo": "bar"}' [15284,15307]
string: '--conf={"foo": "bar"}' [15641,15664]
===
match
---
operator: , [8876,8877]
operator: , [9233,9234]
===
match
---
name: in_ [10068,10071]
name: in_ [10425,10428]
===
match
---
operator: { [12420,12421]
operator: { [12777,12778]
===
match
---
name: mock_run [9148,9156]
name: mock_run [9505,9513]
===
match
---
trailer [10071,10080]
trailer [10428,10437]
===
match
---
operator: , [6829,6830]
operator: , [7186,7187]
===
match
---
string: 'dags' [3260,3266]
string: 'dags' [3260,3266]
===
match
---
operator: @ [18074,18075]
operator: @ [18431,18432]
===
match
---
name: dag_command [10320,10331]
name: dag_command [10677,10688]
===
match
---
name: redirect_stdout [6694,6709]
name: redirect_stdout [7051,7066]
===
match
---
trailer [17571,17578]
trailer [17928,17935]
===
match
---
operator: = [17377,17378]
operator: = [17734,17735]
===
match
---
operator: = [19784,19785]
operator: = [20141,20142]
===
match
---
trailer [14704,14706]
trailer [15061,15063]
===
match
---
trailer [5352,5419]
trailer [5709,5776]
===
match
---
name: mock [18141,18145]
name: mock [18498,18502]
===
match
---
name: test_dag_test_show_dag [19303,19325]
name: test_dag_test_show_dag [19660,19682]
===
match
---
operator: , [9421,9422]
operator: , [9778,9779]
===
match
---
atom_expr [1732,1792]
atom_expr [1732,1792]
===
match
---
name: run_date [7950,7958]
name: run_date [8307,8315]
===
match
---
simple_stmt [2164,2180]
simple_stmt [2164,2180]
===
match
---
name: isoformat [13968,13977]
name: isoformat [14325,14334]
===
match
---
trailer [5859,5981]
trailer [6216,6338]
===
match
---
number: 4 [10786,10787]
number: 4 [11143,11144]
===
match
---
import_from [1149,1183]
import_from [1149,1183]
===
match
---
argument [2804,2815]
argument [2804,2815]
===
match
---
trailer [10288,10290]
trailer [10645,10647]
===
match
---
name: session [12272,12279]
name: session [12629,12636]
===
match
---
trailer [1985,1992]
trailer [1985,1992]
===
match
---
name: start_date [8679,8689]
name: start_date [9036,9046]
===
match
---
name: tests [1365,1370]
name: tests [1365,1370]
===
match
---
trailer [14982,14994]
trailer [15339,15351]
===
match
---
operator: = [14107,14108]
operator: = [14464,14465]
===
match
---
argument [7995,8018]
argument [8352,8375]
===
match
---
string: '--dry-run' [4100,4111]
string: '--dry-run' [4100,4111]
===
match
---
atom_expr [10935,10945]
atom_expr [11292,11302]
===
match
---
name: cls [1982,1985]
name: cls [1982,1985]
===
match
---
simple_stmt [3018,3069]
simple_stmt [3018,3069]
===
match
---
name: end_date [20187,20195]
name: end_date [20544,20552]
===
match
---
atom_expr [14736,14804]
atom_expr [15093,15161]
===
match
---
trailer [3668,3670]
trailer [3668,3670]
===
match
---
string: 'backfill' [8759,8769]
string: 'backfill' [9116,9126]
===
match
---
parameters [5731,5754]
parameters [6088,6111]
===
match
---
name: subdir [18500,18506]
name: subdir [18857,18863]
===
match
---
name: args [8718,8722]
name: args [9075,9079]
===
match
---
string: b"ERR" [6595,6601]
string: b"ERR" [6952,6958]
===
match
---
name: mock_executor [18238,18251]
name: mock_executor [18595,18608]
===
match
---
name: DEFAULT_DATE [4807,4819]
name: DEFAULT_DATE [4807,4819]
===
match
---
name: pytest [16188,16194]
name: pytest [16545,16551]
===
match
---
name: session [16795,16802]
name: session [17152,17159]
===
match
---
name: run_at_least_once [18971,18988]
name: run_at_least_once [19328,19345]
===
match
---
operator: , [17962,17963]
operator: , [18319,18320]
===
match
---
trailer [12930,12937]
trailer [13287,13294]
===
match
---
operator: = [3022,3023]
operator: = [3022,3023]
===
match
---
trailer [11831,11834]
trailer [12188,12191]
===
match
---
name: cls [2033,2036]
name: cls [2033,2036]
===
match
---
simple_stmt [15704,15794]
simple_stmt [16061,16151]
===
match
---
operator: , [8439,8440]
operator: , [8796,8797]
===
match
---
name: isoformat [7669,7678]
name: isoformat [8026,8035]
===
match
---
trailer [6621,6634]
trailer [6978,6991]
===
match
---
name: verbose [9584,9591]
name: verbose [9941,9948]
===
match
---
testlist_comp [14711,14718]
testlist_comp [15068,15075]
===
match
---
name: getvalue [13132,13140]
name: getvalue [13489,13497]
===
match
---
operator: , [4193,4194]
operator: , [4193,4194]
===
match
---
trailer [7029,7053]
trailer [7386,7410]
===
match
---
testlist_comp [17591,17621]
testlist_comp [17948,17978]
===
match
---
operator: = [6658,6659]
operator: = [7015,7016]
===
match
---
trailer [17751,17758]
trailer [18108,18115]
===
match
---
operator: } [12454,12455]
operator: } [12811,12812]
===
match
---
atom_expr [11641,11682]
atom_expr [11998,12039]
===
match
---
trailer [19498,19500]
trailer [19855,19857]
===
match
---
string: '--task-regex' [3377,3391]
string: '--task-regex' [3377,3391]
===
match
---
name: parser [18278,18284]
name: parser [18635,18641]
===
match
---
comparison [15548,15584]
comparison [15905,15941]
===
match
---
operator: , [9700,9701]
operator: , [10057,10058]
===
match
---
string: '--start-date' [3489,3503]
string: '--start-date' [3489,3503]
===
match
---
expr_stmt [9653,9910]
expr_stmt [10010,10267]
===
match
---
argument [7972,7981]
argument [8329,8338]
===
match
---
name: parse_args [17944,17954]
name: parse_args [18301,18311]
===
match
---
parameters [14955,14961]
parameters [15312,15318]
===
match
---
name: dagrun [15600,15606]
name: dagrun [15957,15963]
===
match
---
name: start_date [9205,9215]
name: start_date [9562,9572]
===
match
---
param [18238,18251]
param [18595,18608]
===
match
---
atom_expr [14109,14448]
atom_expr [14466,14805]
===
match
---
name: commit [16803,16809]
name: commit [17160,17166]
===
match
---
simple_stmt [7789,7853]
simple_stmt [8146,8210]
===
match
---
argument [1551,1572]
argument [1551,1572]
===
match
---
name: dag_id [16944,16950]
name: dag_id [17301,17307]
===
match
---
name: mock_proc [7008,7017]
name: mock_proc [7365,7374]
===
match
---
comparison [3686,3767]
comparison [3686,3767]
===
match
---
name: ignore_task_deps [4972,4988]
name: ignore_task_deps [4972,4988]
===
match
---
atom_expr [10054,10080]
atom_expr [10411,10437]
===
match
---
name: DEFAULT_DATE [3529,3541]
name: DEFAULT_DATE [3529,3541]
===
match
---
operator: = [16700,16701]
operator: = [17057,17058]
===
match
---
operator: = [19989,19990]
operator: = [20346,20347]
===
match
---
name: donot_pickle [4893,4905]
name: donot_pickle [4893,4905]
===
match
---
dotted_name [2210,2220]
dotted_name [2210,2220]
===
match
---
suite [12636,12719]
suite [12993,13076]
===
match
---
trailer [11367,11377]
trailer [11724,11734]
===
match
---
comparison [13158,13172]
comparison [13515,13529]
===
match
---
trailer [7870,7894]
trailer [8227,8251]
===
match
---
name: clear_db_runs [2164,2177]
name: clear_db_runs [2164,2177]
===
match
---
string: '100' [14366,14371]
string: '100' [14723,14728]
===
match
---
operator: - [1488,1489]
operator: - [1488,1489]
===
match
---
trailer [19695,19712]
trailer [20052,20069]
===
match
---
name: filter [15438,15444]
name: filter [15795,15801]
===
match
---
string: "- dag_id:" [13315,13326]
string: "- dag_id:" [13672,13683]
===
match
---
operator: , [17777,17778]
operator: , [18134,18135]
===
match
---
with_item [17411,17445]
with_item [17768,17802]
===
match
---
trailer [10046,10053]
trailer [10403,10410]
===
match
---
decorated [19043,20431]
decorated [19400,20788]
===
match
---
name: run_backwards [9552,9565]
name: run_backwards [9909,9922]
===
match
---
decorator [12409,12457]
decorator [12766,12814]
===
match
---
argument [4761,4784]
argument [4761,4784]
===
match
---
name: types [1290,1295]
name: types [1290,1295]
===
match
---
name: test_cli_list_jobs [17706,17724]
name: test_cli_list_jobs [18063,18081]
===
match
---
name: DagBag [1995,2001]
name: DagBag [1995,2001]
===
match
---
atom_expr [1592,1646]
atom_expr [1592,1646]
===
match
---
string: 'list' [12958,12964]
string: 'list' [13315,13321]
===
match
---
atom [12421,12446]
atom [12778,12803]
===
match
---
trailer [19627,19637]
trailer [19984,19994]
===
match
---
string: 'example_bash_operator' [14875,14898]
string: 'example_bash_operator' [15232,15255]
===
match
---
trailer [3659,3668]
trailer [3659,3668]
===
match
---
simple_stmt [15933,16028]
simple_stmt [16290,16385]
===
match
---
operator: , [19900,19901]
operator: , [20257,20258]
===
match
---
operator: } [3753,3754]
operator: } [3753,3754]
===
match
---
atom_expr [17411,17440]
atom_expr [17768,17797]
===
match
---
name: dag_id [17672,17678]
name: dag_id [18029,18035]
===
match
---
name: ignore_task_deps [8111,8127]
name: ignore_task_deps [8468,8484]
===
match
---
trailer [16933,16943]
trailer [17290,17300]
===
match
---
trailer [10937,10945]
trailer [11294,11302]
===
match
---
operator: , [5391,5392]
operator: , [5748,5749]
===
match
---
operator: { [3728,3729]
operator: { [3728,3729]
===
match
---
name: datetime [862,870]
name: datetime [862,870]
===
match
---
trailer [12030,12039]
trailer [12387,12396]
===
match
---
atom_expr [17494,17500]
atom_expr [17851,17857]
===
match
---
argument [7941,7958]
argument [8298,8315]
===
match
---
atom_expr [19398,19528]
atom_expr [19755,19885]
===
match
---
atom_expr [8692,8709]
atom_expr [9049,9066]
===
match
---
operator: , [886,887]
operator: , [886,887]
===
match
---
operator: , [14321,14322]
operator: , [14678,14679]
===
match
---
string: '--imgcat' [6856,6866]
string: '--imgcat' [7213,7223]
===
match
---
atom_expr [5877,5967]
atom_expr [6234,6324]
===
match
---
atom_expr [20142,20165]
atom_expr [20499,20522]
===
match
---
name: ignore_first_depends_on_past [2721,2749]
name: ignore_first_depends_on_past [2721,2749]
===
match
---
operator: = [15985,15986]
operator: = [16342,16343]
===
match
---
name: dag_id [11950,11956]
name: dag_id [12307,12313]
===
match
---
name: dag_command [16227,16238]
name: dag_command [16584,16595]
===
match
---
simple_stmt [10540,10561]
simple_stmt [10897,10918]
===
match
---
simple_stmt [7425,7464]
simple_stmt [7782,7821]
===
match
---
name: create_session [15366,15380]
name: create_session [15723,15737]
===
match
---
name: out [6891,6894]
name: out [7248,7251]
===
match
---
name: mock [18474,18478]
name: mock [18831,18835]
===
match
---
trailer [10096,10103]
trailer [10453,10460]
===
match
---
trailer [15437,15444]
trailer [15794,15801]
===
match
---
name: self [16268,16272]
name: self [16625,16629]
===
match
---
string: '--ignore-first-depends-on-past' [7694,7726]
string: '--ignore-first-depends-on-past' [8051,8083]
===
match
---
name: patch [6215,6220]
name: patch [6572,6577]
===
match
---
trailer [10196,10236]
trailer [10553,10593]
===
match
---
operator: = [11409,11410]
operator: = [11766,11767]
===
match
---
name: pipe [6439,6443]
name: pipe [6796,6800]
===
match
---
name: rerun_failed_tasks [8226,8244]
name: rerun_failed_tasks [8583,8601]
===
match
---
name: parse_args [13633,13643]
name: parse_args [13990,14000]
===
match
---
name: self [8435,8439]
name: self [8792,8796]
===
match
---
operator: , [14399,14400]
operator: , [14756,14757]
===
match
---
string: 'next-execution' [11597,11613]
string: 'next-execution' [11954,11970]
===
match
---
atom_expr [10174,10236]
atom_expr [10531,10593]
===
match
---
testlist_comp [19744,20283]
testlist_comp [20101,20640]
===
match
---
operator: , [8212,8213]
operator: , [8569,8570]
===
match
---
name: mock_run [8441,8449]
name: mock_run [8798,8806]
===
match
---
trailer [17071,17078]
trailer [17428,17435]
===
match
---
name: dirname [1613,1620]
name: dirname [1613,1620]
===
match
---
trailer [13962,13966]
trailer [14319,14323]
===
match
---
operator: , [18993,18994]
operator: , [19350,19351]
===
match
---
operator: , [9477,9478]
operator: , [9834,9835]
===
match
---
name: contextlib [3083,3093]
name: contextlib [3083,3093]
===
match
---
name: communicate [7018,7029]
name: communicate [7375,7386]
===
match
---
name: run [20049,20052]
name: run [20406,20409]
===
match
---
trailer [7825,7836]
trailer [8182,8193]
===
match
---
operator: = [9661,9662]
operator: = [10018,10019]
===
match
---
name: temp_stdout [5996,6007]
name: temp_stdout [6353,6364]
===
match
---
name: self [16843,16847]
name: self [17200,17204]
===
match
---
trailer [7771,7779]
trailer [8128,8136]
===
match
---
atom [17879,18068]
atom [18236,18425]
===
match
---
atom_expr [11169,11187]
atom_expr [11526,11544]
===
match
---
with_stmt [9974,10131]
with_stmt [10331,10488]
===
match
---
name: self [12503,12507]
name: self [12860,12864]
===
match
---
string: '--start-date' [13830,13844]
string: '--start-date' [14187,14201]
===
match
---
expr_stmt [8668,8709]
expr_stmt [9025,9066]
===
match
---
trailer [17078,17089]
trailer [17435,17446]
===
match
---
number: 1.0 [4876,4879]
number: 1.0 [4876,4879]
===
match
---
name: dagrun [15711,15717]
name: dagrun [16068,16074]
===
match
---
operator: = [7529,7530]
operator: = [7886,7887]
===
match
---
name: dagbag [14654,14660]
name: dagbag [15011,15017]
===
match
---
string: 'does_not_exist_dag' [17109,17129]
string: 'does_not_exist_dag' [17466,17486]
===
match
---
param [2142,2145]
param [2142,2145]
===
match
---
trailer [10231,10234]
trailer [10588,10591]
===
match
---
name: dag_id [9059,9065]
name: dag_id [9416,9422]
===
match
---
with_stmt [6678,6883]
with_stmt [7035,7240]
===
match
---
testlist_comp [13480,13563]
testlist_comp [13837,13920]
===
match
---
name: output [3644,3650]
name: output [3644,3650]
===
match
---
name: timedelta [8692,8701]
name: timedelta [9049,9058]
===
match
---
testlist_comp [3995,4194]
testlist_comp [3995,4194]
===
match
---
operator: = [2701,2702]
operator: = [2701,2702]
===
match
---
expr_stmt [12496,12565]
expr_stmt [12853,12922]
===
match
---
comparison [11816,11841]
comparison [12173,12198]
===
match
---
name: dag_command [2312,2323]
name: dag_command [2312,2323]
===
match
---
name: isoformat [19489,19498]
name: isoformat [19846,19855]
===
match
---
trailer [11922,11983]
trailer [12279,12340]
===
match
---
name: session [16916,16923]
name: session [17273,17280]
===
match
---
operator: = [18606,18607]
operator: = [18963,18964]
===
match
---
with_stmt [10245,10561]
with_stmt [10602,10918]
===
match
---
name: output [19647,19653]
name: output [20004,20010]
===
match
---
atom_expr [20316,20396]
atom_expr [20673,20753]
===
match
---
arglist [6100,6146]
arglist [6457,6503]
===
match
---
name: patch [7134,7139]
name: patch [7491,7496]
===
match
---
atom_expr [2350,2491]
atom_expr [2350,2491]
===
match
---
operator: , [5171,5172]
operator: , [5171,5172]
===
match
---
name: parse_args [2362,2372]
name: parse_args [2362,2372]
===
match
---
operator: , [17097,17098]
operator: , [17454,17455]
===
match
---
name: days [10965,10969]
name: days [11322,11326]
===
match
---
argument [4893,4911]
argument [4893,4911]
===
match
---
name: DagRun [1142,1148]
name: DagRun [1142,1148]
===
match
---
operator: = [6107,6108]
operator: = [6464,6465]
===
match
---
decorator [18140,18196]
decorator [18497,18553]
===
match
---
name: dag_backfill [2324,2336]
name: dag_backfill [2324,2336]
===
match
---
name: query [15424,15429]
name: query [15781,15786]
===
match
---
atom [11923,11982]
atom [12280,12339]
===
match
---
name: key [16885,16888]
name: key [17242,17245]
===
match
---
atom_expr [14971,15352]
atom_expr [15328,15709]
===
match
---
name: filename [6114,6122]
name: filename [6471,6479]
===
match
---
name: format [6134,6140]
name: format [6491,6497]
===
match
---
name: mock_proc [6660,6669]
name: mock_proc [7017,7026]
===
match
---
atom_expr [3110,3123]
atom_expr [3110,3123]
===
match
---
atom_expr [1716,1793]
atom_expr [1716,1793]
===
match
---
name: days [8652,8656]
name: days [9009,9013]
===
match
---
atom_expr [17932,18024]
atom_expr [18289,18381]
===
match
---
simple_stmt [12367,12404]
simple_stmt [12724,12761]
===
match
---
simple_stmt [6027,6157]
simple_stmt [6384,6514]
===
match
---
assert_stmt [11809,11841]
assert_stmt [12166,12198]
===
match
---
atom_expr [1605,1637]
atom_expr [1605,1637]
===
match
---
atom_expr [18474,18539]
atom_expr [18831,18896]
===
match
---
operator: = [19396,19397]
operator: = [19753,19754]
===
match
---
atom_expr [17567,17623]
atom_expr [17924,17980]
===
match
---
atom_expr [6683,6724]
atom_expr [7040,7081]
===
match
---
atom_expr [15940,15996]
atom_expr [16297,16353]
===
match
---
suite [19378,20431]
suite [19735,20788]
===
match
---
import_from [857,897]
import_from [857,897]
===
match
---
decorator [19239,19295]
decorator [19596,19652]
===
match
---
trailer [11569,11576]
trailer [11926,11933]
===
match
---
atom_expr [2988,3009]
atom_expr [2988,3009]
===
match
---
string: 'show' [6823,6829]
string: 'show' [7180,7186]
===
match
---
trailer [19831,19836]
trailer [20188,20193]
===
match
---
trailer [1604,1646]
trailer [1604,1646]
===
match
---
atom_expr [18491,18506]
atom_expr [18848,18863]
===
match
---
assert_stmt [15541,15584]
assert_stmt [15898,15941]
===
match
---
simple_stmt [969,1004]
simple_stmt [969,1004]
===
match
---
trailer [13440,13595]
trailer [13797,13952]
===
match
---
atom_expr [14813,14842]
atom_expr [15170,15199]
===
match
---
simple_stmt [17637,17697]
simple_stmt [17994,18054]
===
match
---
operator: , [8050,8051]
operator: , [8407,8408]
===
match
---
trailer [12707,12716]
trailer [13064,13073]
===
match
---
suite [12058,12157]
suite [12415,12514]
===
match
---
string: '--state' [14285,14294]
string: '--state' [14642,14651]
===
match
---
name: session [10025,10032]
name: session [10382,10389]
===
match
---
name: dag [7844,7847]
name: dag [8201,8204]
===
match
---
string: '--run-backwards' [8996,9013]
string: '--run-backwards' [9353,9370]
===
match
---
operator: = [12396,12397]
operator: = [12753,12754]
===
match
---
operator: , [18684,18685]
operator: , [19041,19042]
===
match
---
name: conf_vars [1350,1359]
name: conf_vars [1350,1359]
===
match
---
name: isoformat [10738,10747]
name: isoformat [11095,11104]
===
match
---
operator: , [4640,4641]
operator: , [4640,4641]
===
match
---
testlist_comp [13675,13980]
testlist_comp [14032,14337]
===
match
---
trailer [16923,16929]
trailer [17280,17286]
===
match
---
operator: = [1696,1697]
operator: = [1696,1697]
===
match
---
name: dag_run_state [19976,19989]
name: dag_run_state [20333,20346]
===
match
---
operator: , [17484,17485]
operator: , [17841,17842]
===
match
---
expr_stmt [19387,19528]
expr_stmt [19744,19885]
===
match
---
operator: , [10821,10822]
operator: , [11178,11179]
===
match
---
atom_expr [11565,11623]
atom_expr [11922,11980]
===
match
---
name: self [9039,9043]
name: self [9396,9400]
===
match
---
argument [7508,7514]
argument [7865,7871]
===
match
---
name: mark_success [2829,2841]
name: mark_success [2829,2841]
===
match
---
assert_stmt [13308,13333]
assert_stmt [13665,13690]
===
match
---
testlist_comp [12950,12984]
testlist_comp [13307,13341]
===
match
---
name: FAILED [11475,11481]
name: FAILED [11832,11838]
===
match
---
operator: , [2615,2616]
operator: , [2615,2616]
===
match
---
trailer [13131,13140]
trailer [13488,13497]
===
match
---
comparison [15711,15793]
comparison [16068,16150]
===
match
---
argument [9514,9538]
argument [9871,9895]
===
match
---
operator: , [18311,18312]
operator: , [18668,18669]
===
match
---
simple_stmt [12128,12157]
simple_stmt [12485,12514]
===
match
---
simple_stmt [12293,12355]
simple_stmt [12650,12712]
===
match
---
name: temp_stdout [5307,5318]
name: temp_stdout [5664,5675]
===
match
---
funcdef [16639,17156]
funcdef [16996,17513]
===
match
---
name: days [7508,7512]
name: days [7865,7869]
===
match
---
name: cli_args [18607,18615]
name: cli_args [18964,18972]
===
match
---
operator: , [3619,3620]
operator: , [3619,3620]
===
match
---
name: io [19569,19571]
name: io [19926,19928]
===
match
---
name: dirname [1756,1763]
name: dirname [1756,1763]
===
match
---
trailer [20096,20109]
trailer [20453,20466]
===
match
---
atom_expr [15600,15623]
atom_expr [15957,15980]
===
match
---
operator: = [19654,19655]
operator: = [20011,20012]
===
match
---
operator: = [20258,20259]
operator: = [20615,20616]
===
match
---
trailer [12369,12376]
trailer [12726,12733]
===
match
---
name: call [20355,20359]
name: call [20712,20716]
===
match
---
name: parser [11570,11576]
name: parser [11927,11933]
===
match
---
simple_stmt [12169,12204]
simple_stmt [12526,12561]
===
match
---
atom_expr [18872,18895]
atom_expr [19229,19252]
===
match
---
operator: = [10373,10374]
operator: = [10730,10731]
===
match
---
expr_stmt [7524,7737]
expr_stmt [7881,8094]
===
match
---
with_stmt [5257,5420]
with_stmt [5614,5777]
===
match
---
trailer [3845,3847]
trailer [3845,3847]
===
match
---
operator: , [13916,13917]
operator: , [14273,14274]
===
match
---
suite [19594,19638]
suite [19951,19995]
===
match
---
string: 'backfill' [4023,4033]
string: 'backfill' [4023,4033]
===
match
---
trailer [15732,15742]
trailer [16089,16099]
===
match
---
atom_expr [18767,19012]
atom_expr [19124,19369]
===
match
---
suite [13057,13143]
suite [13414,13500]
===
match
---
name: subdir [18484,18490]
name: subdir [18841,18847]
===
match
---
expr_stmt [12919,12986]
expr_stmt [13276,13343]
===
match
---
name: execution_date [11395,11409]
name: execution_date [11752,11766]
===
match
---
operator: , [17107,17108]
operator: , [17464,17465]
===
match
---
arith_expr [10713,10736]
arith_expr [11070,11093]
===
match
---
operator: = [18988,18989]
operator: = [19345,19346]
===
match
---
funcdef [14935,16129]
funcdef [15292,16486]
===
match
---
name: timespec [15743,15751]
name: timespec [16100,16108]
===
match
---
operator: = [19876,19877]
operator: = [20233,20234]
===
match
---
trailer [19995,20000]
trailer [20352,20357]
===
match
---
name: self [11207,11211]
name: self [11564,11568]
===
match
---
trailer [3093,3109]
trailer [3093,3109]
===
match
---
atom_expr [19476,19500]
atom_expr [19833,19857]
===
match
---
param [9638,9642]
param [9995,9999]
===
match
---
testlist_comp [6587,6601]
testlist_comp [6944,6958]
===
match
---
atom [16312,16600]
atom [16669,16957]
===
match
---
simple_stmt [2511,2980]
simple_stmt [2511,2980]
===
match
---
trailer [17473,17501]
trailer [17830,17858]
===
match
---
name: mock_run [2293,2301]
name: mock_run [2293,2301]
===
match
---
expr_stmt [6516,6540]
expr_stmt [6873,6897]
===
match
---
name: ignore_task_deps [2768,2784]
name: ignore_task_deps [2768,2784]
===
match
---
operator: , [5018,5019]
operator: , [5018,5019]
===
match
---
name: reset_mock [5200,5210]
name: reset_mock [5200,5210]
===
match
---
dotted_name [1154,1167]
dotted_name [1154,1167]
===
match
---
atom_expr [19569,19582]
atom_expr [19926,19939]
===
match
---
number: 4 [11022,11023]
number: 4 [11379,11380]
===
match
---
suite [1931,20431]
suite [1931,20788]
===
match
---
number: 1 [8707,8708]
number: 1 [9064,9065]
===
match
---
string: '--dag-id' [14216,14226]
string: '--dag-id' [14573,14583]
===
match
---
trailer [3172,3634]
trailer [3172,3634]
===
match
---
trailer [16272,16279]
trailer [16629,16636]
===
match
---
string: "airflow/example_dags/example_complex.py" [12735,12776]
string: "airflow/example_dags/example_complex.py" [13092,13133]
===
match
---
trailer [1620,1637]
trailer [1620,1637]
===
match
---
name: dag_show [5344,5352]
name: dag_show [5701,5709]
===
match
---
atom_expr [2511,2979]
atom_expr [2511,2979]
===
match
---
fstring_start: f" [3686,3688]
fstring_start: f" [3686,3688]
===
match
---
name: count [17684,17689]
name: count [18041,18046]
===
match
---
string: 'example_bash_operator' [19785,19808]
string: 'example_bash_operator' [20142,20165]
===
match
---
file_input [787,20431]
file_input [787,20788]
===
match
---
name: temp_stdout [12624,12635]
name: temp_stdout [12981,12992]
===
match
---
trailer [15444,15481]
trailer [15801,15838]
===
match
---
name: contextlib [5262,5272]
name: contextlib [5619,5629]
===
match
---
expr_stmt [11558,11623]
expr_stmt [11915,11980]
===
match
---
operator: , [5144,5145]
operator: , [5144,5145]
===
match
---
name: parser [17572,17578]
name: parser [17929,17935]
===
match
---
name: Session [16741,16748]
name: Session [17098,17105]
===
match
---
argument [4798,4819]
argument [4798,4819]
===
match
---
trailer [6086,6156]
trailer [6443,6513]
===
match
---
name: self [14109,14113]
name: self [14466,14470]
===
match
---
trailer [15577,15584]
trailer [15934,15941]
===
match
---
simple_stmt [1314,1360]
simple_stmt [1314,1360]
===
match
---
name: mock_get_dag [19332,19344]
name: mock_get_dag [19689,19701]
===
match
---
comparison [5606,5640]
comparison [5963,5997]
===
match
---
argument [19111,19146]
argument [19468,19503]
===
match
---
name: self [14531,14535]
name: self [14888,14892]
===
match
---
name: f [17494,17495]
name: f [17851,17852]
===
match
---
operator: , [8189,8190]
operator: , [8546,8547]
===
match
---
argument [2829,2847]
argument [2829,2847]
===
match
---
atom_expr [4268,4296]
atom_expr [4268,4296]
===
match
---
operator: = [18514,18515]
operator: = [18871,18872]
===
match
---
trailer [2543,2979]
trailer [2543,2979]
===
match
---
expr_stmt [10680,10852]
expr_stmt [11037,11209]
===
match
---
arith_expr [8679,8709]
arith_expr [9036,9066]
===
match
---
trailer [1537,1549]
trailer [1537,1549]
===
match
---
name: contextlib [5769,5779]
name: contextlib [6126,6136]
===
match
---
name: dag [3612,3615]
name: dag [3612,3615]
===
match
---
number: 1 [14717,14718]
number: 1 [15074,15075]
===
match
---
argument [4240,4247]
argument [4240,4247]
===
match
---
name: DEFAULT_DATE [4772,4784]
name: DEFAULT_DATE [4772,4784]
===
match
---
name: dag_trigger [16239,16250]
name: dag_trigger [16596,16607]
===
match
---
atom_expr [6710,6723]
atom_expr [7067,7080]
===
match
---
assert_stmt [10540,10560]
assert_stmt [10897,10917]
===
match
---
operator: , [2397,2398]
operator: , [2397,2398]
===
match
---
atom_expr [10999,11037]
atom_expr [11356,11394]
===
match
---
comparison [7110,7122]
comparison [7467,7479]
===
match
---
arglist [16268,16619]
arglist [16625,16976]
===
match
---
name: args [14043,14047]
name: args [14400,14404]
===
match
---
name: mock [6279,6283]
name: mock [6636,6640]
===
match
---
name: dag_list_dags [13082,13095]
name: dag_list_dags [13439,13452]
===
match
---
name: DEFAULT_DATE [4169,4181]
name: DEFAULT_DATE [4169,4181]
===
match
---
decorated [5646,6204]
decorated [6003,6561]
===
match
---
decorated [12409,12824]
decorated [12766,13181]
===
match
---
name: session [1203,1210]
name: session [1203,1210]
===
match
---
string: '--yes' [17131,17138]
string: '--yes' [17488,17495]
===
match
---
operator: = [19930,19931]
operator: = [20287,20288]
===
match
---
name: dag_command [17801,17812]
name: dag_command [18158,18169]
===
match
---
operator: , [14715,14716]
operator: , [15072,15073]
===
match
---
atom_expr [14606,14633]
atom_expr [14963,14990]
===
match
---
operator: = [9415,9416]
operator: = [9772,9773]
===
match
---
parameters [12903,12909]
parameters [13260,13266]
===
match
---
name: self [7814,7818]
name: self [8171,8175]
===
match
---
string: "label=example_bash_operator" [5472,5501]
string: "label=example_bash_operator" [5829,5858]
===
match
---
atom_expr [6549,6583]
atom_expr [6906,6940]
===
match
---
trailer [18393,18403]
trailer [18750,18760]
===
match
---
string: "airflow.cli.commands.dag_command.DAG.run" [8339,8381]
string: "airflow.cli.commands.dag_command.DAG.run" [8696,8738]
===
match
---
operator: , [5940,5941]
operator: , [6297,6298]
===
match
---
trailer [17936,17943]
trailer [18293,18300]
===
match
---
trailer [6062,6086]
trailer [6419,6443]
===
match
---
name: settings [16732,16740]
name: settings [17089,17097]
===
match
---
operator: = [4837,4838]
operator: = [4837,4838]
===
match
---
name: dag [7746,7749]
name: dag [8103,8106]
===
match
---
trailer [18566,18568]
trailer [18923,18925]
===
match
---
operator: , [20019,20020]
operator: , [20376,20377]
===
match
---
trailer [3937,3944]
trailer [3937,3944]
===
match
---
trailer [15423,15429]
trailer [15780,15786]
===
match
---
with_item [6683,6739]
with_item [7040,7096]
===
match
---
name: execution_date [18670,18684]
name: execution_date [19027,19041]
===
match
---
trailer [11330,11496]
trailer [11687,11853]
===
match
---
name: cls [2065,2068]
name: cls [2065,2068]
===
match
---
name: key [17679,17682]
name: key [18036,18039]
===
match
---
atom_expr [3933,4226]
atom_expr [3933,4226]
===
match
---
atom_expr [3653,3670]
atom_expr [3653,3670]
===
match
---
arglist [19064,19146]
arglist [19421,19503]
===
match
---
trailer [1920,1929]
trailer [1920,1929]
===
match
---
name: donot_pickle [9320,9332]
name: donot_pickle [9677,9689]
===
match
---
trailer [5375,5418]
trailer [5732,5775]
===
match
---
name: tempfile [17411,17419]
name: tempfile [17768,17776]
===
match
---
simple_stmt [7251,7417]
simple_stmt [7608,7774]
===
match
---
name: cli_args [18872,18880]
name: cli_args [19229,19237]
===
match
---
operator: , [4482,4483]
operator: , [4482,4483]
===
match
---
parameters [13365,13371]
parameters [13722,13728]
===
match
---
atom_expr [13418,13595]
atom_expr [13775,13952]
===
match
---
decorated [8327,9609]
decorated [8684,9966]
===
match
---
name: os [1732,1734]
name: os [1732,1734]
===
match
---
name: assert_called_once_with [9157,9180]
name: assert_called_once_with [9514,9537]
===
match
---
operator: , [15262,15263]
operator: , [15619,15620]
===
match
---
trailer [15946,15966]
trailer [16303,16323]
===
match
---
name: args [17827,17831]
name: args [18184,18188]
===
match
---
name: DagModel [1132,1140]
name: DagModel [1132,1140]
===
match
---
with_stmt [5764,5982]
with_stmt [6121,6339]
===
match
---
operator: , [15076,15077]
operator: , [15433,15434]
===
match
---
atom_expr [17998,18022]
atom_expr [18355,18379]
===
match
---
name: delay_on_limit_secs [9283,9302]
name: delay_on_limit_secs [9640,9659]
===
match
---
name: session [16759,16766]
name: session [17116,17123]
===
match
---
name: dr [10094,10096]
name: dr [10451,10453]
===
match
---
string: "ERR" [7110,7115]
string: "ERR" [7467,7472]
===
match
---
atom [8725,9024]
atom [9082,9381]
===
match
---
name: mock [19174,19178]
name: mock [19531,19535]
===
match
---
dotted_name [1238,1257]
dotted_name [1238,1257]
===
match
---
trailer [18669,18684]
trailer [19026,19041]
===
match
---
argument [7844,7851]
argument [8201,8208]
===
match
---
simple_stmt [13381,13606]
simple_stmt [13738,13963]
===
match
---
operator: , [18839,18840]
operator: , [19196,19197]
===
match
---
expr_stmt [6410,6470]
expr_stmt [6767,6827]
===
match
---
with_stmt [19537,19638]
with_stmt [19894,19995]
===
match
---
name: temp_stdout [10295,10306]
name: temp_stdout [10652,10663]
===
match
---
string: 'latest_only' [9750,9763]
string: 'latest_only' [10107,10120]
===
match
---
assert_stmt [17637,17696]
assert_stmt [17994,18053]
===
match
---
trailer [11218,11223]
trailer [11575,11580]
===
match
---
name: create_session [12252,12266]
name: create_session [12609,12623]
===
match
---
name: ignore_task_deps [9399,9415]
name: ignore_task_deps [9756,9772]
===
match
---
name: parse_args [12515,12525]
name: parse_args [12872,12882]
===
match
---
name: dag_ids [9653,9660]
name: dag_ids [10010,10017]
===
match
---
name: parser [13626,13632]
name: parser [13983,13989]
===
match
---
string: 'example_bash_operator' [15129,15152]
string: 'example_bash_operator' [15486,15509]
===
match
---
trailer [5881,5888]
trailer [6238,6245]
===
match
---
name: create_dagrun [11317,11330]
name: create_dagrun [11674,11687]
===
match
---
name: airflow [1009,1016]
name: airflow [1009,1016]
===
match
---
testlist_comp [14760,14802]
testlist_comp [15117,15159]
===
match
---
argument [2721,2754]
argument [2721,2754]
===
match
---
name: days [10729,10733]
name: days [11086,11090]
===
match
---
name: i [12194,12195]
name: i [12551,12552]
===
match
---
decorator [6209,6274]
decorator [6566,6631]
===
match
---
expr_stmt [13614,14004]
expr_stmt [13971,14361]
===
match
---
trailer [15554,15563]
trailer [15911,15920]
===
match
---
funcdef [17702,17833]
funcdef [18059,18190]
===
match
---
trailer [18561,18566]
trailer [18918,18923]
===
match
---
name: os [1449,1451]
name: os [1449,1451]
===
match
---
name: self [14649,14653]
name: self [15006,15010]
===
match
---
name: dags [11219,11223]
name: dags [11576,11580]
===
match
---
trailer [17529,17531]
trailer [17886,17888]
===
match
---
simple_stmt [9653,9940]
simple_stmt [10010,10297]
===
match
---
name: patch [18146,18151]
name: patch [18503,18508]
===
match
---
name: airflow [1276,1283]
name: airflow [1276,1283]
===
match
---
operator: = [9440,9441]
operator: = [9797,9798]
===
match
---
trailer [17954,18024]
trailer [18311,18381]
===
match
---
trailer [3919,4258]
trailer [3919,4258]
===
match
---
trailer [10053,10081]
trailer [10410,10438]
===
match
---
trailer [10779,10788]
trailer [11136,11145]
===
match
---
argument [4972,4994]
argument [4972,4994]
===
match
---
name: utils [1246,1251]
name: utils [1246,1251]
===
match
---
trailer [1723,1731]
trailer [1723,1731]
===
match
---
expr_stmt [1982,2024]
expr_stmt [1982,2024]
===
match
---
simple_stmt [1574,1647]
simple_stmt [1574,1647]
===
match
---
string: 'NOT JSON' [16567,16577]
string: 'NOT JSON' [16924,16934]
===
match
---
trailer [12671,12677]
trailer [13028,13034]
===
match
---
operator: , [2675,2676]
operator: , [2675,2676]
===
match
---
operator: , [17607,17608]
operator: , [17964,17965]
===
match
---
string: "DagRun not created" [15512,15532]
string: "DagRun not created" [15869,15889]
===
match
---
name: filter_by [16934,16943]
name: filter_by [17291,17300]
===
match
---
parameters [5241,5247]
parameters [5598,5604]
===
match
---
string: 'true' [12868,12874]
string: 'true' [13225,13231]
===
match
---
name: assert_called_once_with [7871,7894]
name: assert_called_once_with [8228,8251]
===
match
---
name: io [13027,13029]
name: io [13384,13386]
===
match
---
atom_expr [18338,18362]
atom_expr [18695,18719]
===
match
---
name: realpath [1772,1780]
name: realpath [1772,1780]
===
match
---
parameters [17856,17862]
parameters [18213,18219]
===
match
---
argument [5087,5111]
argument [5087,5111]
===
match
---
trailer [16250,16633]
trailer [16607,16990]
===
match
---
string: 'example_bash_operator' [3328,3351]
string: 'example_bash_operator' [3328,3351]
===
match
---
name: key [17609,17612]
name: key [17966,17969]
===
match
---
name: end_date [9238,9246]
name: end_date [9595,9603]
===
match
---
trailer [11667,11682]
trailer [12024,12039]
===
match
---
name: clear [19839,19844]
name: clear [20196,20201]
===
match
---
name: end_date [18917,18925]
name: end_date [19274,19282]
===
match
---
operator: , [8789,8790]
operator: , [9146,9147]
===
match
---
string: 'example_xcom' [9885,9899]
string: 'example_xcom' [10242,10256]
===
match
---
operator: , [4594,4595]
operator: , [4594,4595]
===
match
---
name: dagbag [14863,14869]
name: dagbag [15220,15226]
===
match
---
param [2293,2301]
param [2293,2301]
===
match
---
name: parser [4387,4393]
name: parser [4387,4393]
===
match
---
operator: , [16344,16345]
operator: , [16701,16702]
===
match
---
trailer [11745,11751]
trailer [12102,12108]
===
match
---
string: '--output' [12545,12555]
string: '--output' [12902,12912]
===
match
---
atom_expr [2164,2179]
atom_expr [2164,2179]
===
match
---
name: expected_output_2 [12176,12193]
name: expected_output_2 [12533,12550]
===
match
---
parameters [17194,17200]
parameters [17551,17557]
===
match
---
string: '--yes' [16890,16897]
string: '--yes' [17247,17254]
===
match
---
string: '--local' [8803,8812]
string: '--local' [9160,9169]
===
match
---
name: rerun_failed_tasks [9514,9532]
name: rerun_failed_tasks [9871,9889]
===
match
---
operator: = [8656,8657]
operator: = [9013,9014]
===
match
---
operator: , [17996,17997]
operator: , [18353,18354]
===
match
---
trailer [2361,2372]
trailer [2361,2372]
===
match
---
testlist_comp [6815,6866]
testlist_comp [7172,7223]
===
match
---
operator: , [14294,14295]
operator: , [14651,14652]
===
match
---
string: "airflow.cli.commands.dag_command.DebugExecutor" [18086,18134]
string: "airflow.cli.commands.dag_command.DebugExecutor" [18443,18491]
===
match
---
trailer [19420,19528]
trailer [19777,19885]
===
match
---
dotted_name [19240,19250]
dotted_name [19597,19607]
===
match
---
trailer [19409,19420]
trailer [19766,19777]
===
match
---
trailer [19838,19844]
trailer [20195,20201]
===
match
---
name: one [15482,15485]
name: one [15839,15842]
===
match
---
atom [10763,10789]
atom [11120,11146]
===
match
---
operator: = [12924,12925]
operator: = [13281,13282]
===
match
---
atom_expr [5434,5456]
atom_expr [5791,5813]
===
match
---
trailer [3043,3068]
trailer [3043,3068]
===
match
---
trailer [4181,4191]
trailer [4181,4191]
===
match
---
atom_expr [4344,4705]
atom_expr [4344,4705]
===
match
---
operator: = [17324,17325]
operator: = [17681,17682]
===
match
---
atom_expr [10902,10919]
atom_expr [11259,11276]
===
match
---
name: session [17644,17651]
name: session [18001,18008]
===
match
---
simple_stmt [8718,9025]
simple_stmt [9075,9382]
===
match
---
trailer [20046,20048]
trailer [20403,20405]
===
match
---
operator: = [6992,6993]
operator: = [7349,7350]
===
match
---
atom_expr [10770,10788]
atom_expr [11127,11145]
===
match
---
atom [19434,19518]
atom [19791,19875]
===
match
---
name: StringIO [5292,5300]
name: StringIO [5649,5657]
===
match
---
name: test_backfill [2273,2286]
name: test_backfill [2273,2286]
===
match
---
testlist_comp [4444,4641]
testlist_comp [4444,4641]
===
match
---
name: mock [919,923]
name: mock [919,923]
===
match
---
name: mock_run [5191,5199]
name: mock_run [5191,5199]
===
match
---
name: sync_to_db [2044,2054]
name: sync_to_db [2044,2054]
===
match
---
operator: , [9445,9446]
operator: , [9802,9803]
===
match
---
simple_stmt [16674,16688]
simple_stmt [17031,17045]
===
match
---
name: self [17725,17729]
name: self [18082,18086]
===
match
---
name: dag_next_execution [11727,11745]
name: dag_next_execution [12084,12102]
===
match
---
name: NONE [18726,18730]
name: NONE [19083,19087]
===
match
---
trailer [3944,3955]
trailer [3944,3955]
===
match
---
trailer [13392,13404]
trailer [13749,13761]
===
match
---
name: utc [1569,1572]
name: utc [1569,1572]
===
match
---
name: assert_has_calls [18426,18442]
name: assert_has_calls [18783,18799]
===
match
---
string: 'success' [14312,14321]
string: 'success' [14669,14678]
===
match
---
name: redirect_stdout [10261,10276]
name: redirect_stdout [10618,10633]
===
match
---
name: DEFAULT_DATE [2452,2464]
name: DEFAULT_DATE [2452,2464]
===
match
---
name: args [14628,14632]
name: args [14985,14989]
===
match
---
name: returncode [6526,6536]
name: returncode [6883,6893]
===
match
---
name: DEFAULT_DATE [18338,18350]
name: DEFAULT_DATE [18695,18707]
===
match
---
testlist_comp [11589,11621]
testlist_comp [11946,11978]
===
match
---
atom_expr [20360,20385]
atom_expr [20717,20742]
===
match
---
atom_expr [3895,4258]
atom_expr [3895,4258]
===
match
---
name: cli_args [18661,18669]
name: cli_args [19018,19026]
===
match
---
atom_expr [12075,12111]
atom_expr [12432,12468]
===
match
---
operator: == [15564,15566]
operator: == [15921,15923]
===
match
---
atom_expr [20037,20282]
atom_expr [20394,20639]
===
match
---
trailer [1731,1793]
trailer [1731,1793]
===
match
---
atom_expr [19761,19776]
atom_expr [20118,20133]
===
match
---
simple_stmt [17027,17156]
simple_stmt [17384,17513]
===
match
---
trailer [14660,14665]
trailer [15017,15022]
===
match
---
simple_stmt [14013,14049]
simple_stmt [14370,14406]
===
match
---
comparison [13188,13204]
comparison [13545,13561]
===
match
---
name: output [3761,3767]
name: output [3761,3767]
===
match
---
name: parse_args [17759,17769]
name: parse_args [18116,18126]
===
match
---
name: dag_id [8574,8580]
name: dag_id [8931,8937]
===
match
---
name: clear_db_dags [1392,1405]
name: clear_db_dags [1392,1405]
===
match
---
atom_expr [10948,10985]
atom_expr [11305,11342]
===
match
---
trailer [3194,3201]
trailer [3194,3201]
===
match
---
name: DEFAULT_DATE [4616,4628]
name: DEFAULT_DATE [4616,4628]
===
match
---
with_stmt [16183,16634]
with_stmt [16540,16991]
===
match
---
simple_stmt [10369,10398]
simple_stmt [10726,10755]
===
match
---
suite [8451,9609]
suite [8808,9966]
===
match
---
string: "seconds" [15986,15995]
string: "seconds" [16343,16352]
===
match
---
exprlist [11156,11165]
exprlist [11513,11522]
===
match
---
argument [18861,18895]
argument [19218,19252]
===
match
---
name: timespec [16078,16086]
name: timespec [16435,16443]
===
match
---
name: ignore_first_depends_on_past [9352,9380]
name: ignore_first_depends_on_past [9709,9737]
===
match
---
atom [2390,2477]
atom [2390,2477]
===
match
---
name: self [5877,5881]
name: self [6234,6238]
===
match
---
trailer [5798,5807]
trailer [6155,6164]
===
match
---
trailer [6055,6062]
trailer [6412,6419]
===
match
---
name: getvalue [19663,19671]
name: getvalue [20020,20028]
===
match
---
argument [2629,2638]
argument [2629,2638]
===
insert-node
---
name: TestCliDags [1900,1911]
to
classdef [1894,20431]
at 0
===
insert-tree
---
decorated [5218,5570]
    decorator [5218,5274]
        operator: @ [5218,5219]
        dotted_name [5219,5229]
            name: mock [5219,5223]
            name: patch [5224,5229]
        string: "airflow.cli.commands.dag_command.get_dag" [5230,5272]
    funcdef [5278,5570]
        name: test_backfill_fails_without_loading_dags [5282,5322]
        parameters [5322,5342]
            param [5323,5328]
                name: self [5323,5327]
                operator: , [5327,5328]
            param [5329,5341]
                name: mock_get_dag [5329,5341]
        suite [5343,5570]
            simple_stmt [5353,5434]
                expr_stmt [5353,5433]
                    name: cli_args [5353,5361]
                    operator: = [5362,5363]
                    atom_expr [5364,5433]
                        name: self [5364,5368]
                        trailer [5368,5375]
                            name: parser [5369,5375]
                        trailer [5375,5386]
                            name: parse_args [5376,5386]
                        trailer [5386,5433]
                            atom [5387,5432]
                                testlist_comp [5388,5431]
                                    string: 'dags' [5388,5394]
                                    operator: , [5394,5395]
                                    string: 'backfill' [5396,5406]
                                    operator: , [5406,5407]
                                    string: 'example_bash_operator' [5408,5431]
            with_stmt [5443,5528]
                atom_expr [5448,5479]
                    name: pytest [5448,5454]
                    trailer [5454,5461]
                        name: raises [5455,5461]
                    trailer [5461,5479]
                        name: AirflowException [5462,5478]
                suite [5480,5528]
                    simple_stmt [5493,5528]
                        atom_expr [5493,5527]
                            name: dag_command [5493,5504]
                            trailer [5504,5517]
                                name: dag_backfill [5505,5517]
                            trailer [5517,5527]
                                name: cli_args [5518,5526]
            simple_stmt [5537,5570]
                atom_expr [5537,5569]
                    name: mock_get_dag [5537,5549]
                    trailer [5549,5567]
                        name: assert_not_called [5550,5567]
                    trailer [5567,5569]
to
suite [1931,20431]
at 3
===
delete-node
---
name: TestCliDags [1900,1911]
===
