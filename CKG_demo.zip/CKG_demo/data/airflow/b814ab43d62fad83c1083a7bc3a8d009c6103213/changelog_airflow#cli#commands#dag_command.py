===
match
---
argument [12171,12207]
argument [12171,12207]
===
match
---
name: session [8499,8506]
name: session [8499,8506]
===
match
---
atom_expr [12262,12321]
atom_expr [12262,12321]
===
match
---
operator: , [4443,4444]
operator: , [4443,4444]
===
match
---
operator: @ [4545,4546]
operator: @ [4545,4546]
===
match
---
param [12287,12288]
param [12287,12288]
===
match
---
name: out [7952,7955]
name: out [7952,7955]
===
match
---
atom [11455,11526]
atom [11455,11526]
===
match
---
operator: = [8409,8410]
operator: = [8409,8410]
===
match
---
name: args [11771,11775]
name: args [11771,11775]
===
match
---
name: end_date [2592,2600]
name: end_date [2592,2600]
===
match
---
atom_expr [9180,9353]
atom_expr [9180,9353]
===
match
---
suite [6962,7106]
suite [6962,7106]
===
match
---
name: cli_utils [12777,12786]
name: cli_utils [12777,12786]
===
match
---
atom_expr [10880,10891]
atom_expr [10880,10891]
===
match
---
if_stmt [6210,6550]
if_stmt [6210,6550]
===
match
---
name: filename [6409,6417]
name: filename [6409,6417]
===
match
---
simple_stmt [3067,3100]
simple_stmt [3067,3100]
===
match
---
name: DagRun [8773,8779]
name: DagRun [8773,8779]
===
match
---
simple_stmt [6532,6550]
simple_stmt [6532,6550]
===
match
---
trailer [8446,8448]
trailer [8446,8448]
===
match
---
try_stmt [3753,4543]
try_stmt [3753,4543]
===
match
---
operator: = [3805,3806]
operator: = [3805,3806]
===
match
---
atom_expr [12236,12249]
atom_expr [12236,12249]
===
match
---
trailer [8736,8743]
trailer [8736,8743]
===
match
---
name: args [9458,9462]
name: args [9458,9462]
===
match
---
dotted_name [1251,1283]
dotted_name [1251,1283]
===
match
---
if_stmt [11824,11991]
if_stmt [11824,11991]
===
match
---
operator: = [3399,3400]
operator: = [3399,3400]
===
match
---
name: args [3975,3979]
name: args [3975,3979]
===
match
---
operator: = [7897,7898]
operator: = [7897,7898]
===
match
---
name: max_date [8814,8822]
name: max_date [8814,8822]
===
match
---
if_stmt [8870,9049]
if_stmt [8870,9049]
===
match
---
operator: = [2797,2798]
operator: = [2797,2798]
===
match
---
name: query [11282,11287]
name: query [11282,11287]
===
match
---
operator: } [10612,10613]
operator: } [10612,10613]
===
match
---
name: print_as [9830,9838]
name: print_as [9830,9838]
===
match
---
import_from [1448,1490]
import_from [1448,1490]
===
match
---
argument [4320,4333]
argument [4320,4333]
===
match
---
name: dot_renderer [1658,1670]
name: dot_renderer [1658,1670]
===
match
---
name: err [6747,6750]
name: err [6747,6750]
===
match
---
name: dag_id [8301,8307]
name: dag_id [8301,8307]
===
match
---
fstring_expr [5954,5967]
fstring_expr [5954,5967]
===
match
---
operator: , [9992,9993]
operator: , [9992,9993]
===
match
---
operator: , [3220,3221]
operator: , [3220,3221]
===
match
---
dictorsetmaker [11457,11504]
dictorsetmaker [11457,11504]
===
match
---
simple_stmt [11087,11131]
simple_stmt [11087,11131]
===
match
---
trailer [8604,8611]
trailer [8604,8611]
===
match
---
name: Optional [8669,8677]
name: Optional [8669,8677]
===
match
---
name: args [4245,4249]
name: args [4245,4249]
===
match
---
name: ast [816,819]
name: ast [816,819]
===
match
---
name: dumps [8003,8008]
name: dumps [8003,8008]
===
match
---
atom_expr [12026,12036]
atom_expr [12026,12036]
===
match
---
name: dag_list_dags [9673,9686]
name: dag_list_dags [9673,9686]
===
match
---
atom_expr [3171,3186]
atom_expr [3171,3186]
===
match
---
operator: == [8598,8600]
operator: == [8598,8600]
===
match
---
name: args [3089,3093]
name: args [3089,3093]
===
match
---
atom_expr [3548,3563]
atom_expr [3548,3563]
===
match
---
import_name [833,844]
import_name [833,844]
===
match
---
atom_expr [4820,4834]
atom_expr [4820,4834]
===
match
---
name: dag_id [11832,11838]
name: dag_id [11832,11838]
===
match
---
atom_expr [11597,11608]
atom_expr [11597,11608]
===
match
---
name: task_regex [2688,2698]
name: task_regex [2688,2698]
===
match
---
trailer [8512,8563]
trailer [8512,8563]
===
match
---
trailer [2021,2029]
trailer [2021,2029]
===
match
---
trailer [10346,10359]
trailer [10346,10359]
===
match
---
trailer [10437,10442]
trailer [10437,10442]
===
match
---
name: dot [7162,7165]
name: dot [7162,7165]
===
match
---
name: exit [4535,4539]
name: exit [4535,4539]
===
match
---
trailer [11316,11326]
trailer [11316,11326]
===
match
---
name: _save_dot_to_file [14044,14061]
name: _save_dot_to_file [14044,14061]
===
match
---
operator: { [5846,5847]
operator: { [5846,5847]
===
match
---
trailer [8715,8723]
trailer [8715,8723]
===
match
---
trailer [9409,9422]
trailer [9409,9422]
===
match
---
name: cli_utils [4934,4943]
name: cli_utils [4934,4943]
===
match
---
trailer [5411,5416]
trailer [5411,5416]
===
match
---
name: dag_test [12806,12814]
name: dag_test [12806,12814]
===
match
---
trailer [10814,10821]
trailer [10814,10821]
===
match
---
trailer [6939,6945]
trailer [6939,6945]
===
match
---
name: stderr [9336,9342]
name: stderr [9336,9342]
===
match
---
name: print [5331,5336]
name: print [5331,5336]
===
match
---
expr_stmt [6133,6154]
expr_stmt [6133,6154]
===
match
---
name: process_subdir [9780,9794]
name: process_subdir [9780,9794]
===
match
---
import_from [1087,1138]
import_from [1087,1138]
===
match
---
name: dag_id [13830,13836]
name: dag_id [13830,13836]
===
match
---
name: sql [977,980]
name: sql [977,980]
===
match
---
trailer [6610,6624]
trailer [6610,6624]
===
match
---
operator: , [3603,3604]
operator: , [3603,3604]
===
match
---
argument [13037,13065]
argument [13037,13065]
===
match
---
atom_expr [2661,2674]
atom_expr [2661,2674]
===
match
---
name: imgcat_dagrun [13621,13634]
name: imgcat_dagrun [13621,13634]
===
match
---
name: api_client [5047,5057]
name: api_client [5047,5057]
===
match
---
trailer [11546,11548]
trailer [11546,11548]
===
match
---
name: render_dag [13970,13980]
name: render_dag [13970,13980]
===
match
---
trailer [9530,9544]
trailer [9530,9544]
===
match
---
suite [5502,5556]
suite [5502,5556]
===
match
---
name: signal [2001,2007]
name: signal [2001,2007]
===
match
---
argument [3879,3909]
argument [3879,3909]
===
match
---
name: ValueError [4474,4484]
name: ValueError [4474,4484]
===
match
---
simple_stmt [3198,3254]
simple_stmt [3198,3254]
===
match
---
name: args [12958,12962]
name: args [12958,12962]
===
match
---
param [6580,6588]
param [6580,6588]
===
match
---
atom_expr [7724,7757]
atom_expr [7724,7757]
===
match
---
operator: = [12941,12942]
operator: = [12941,12942]
===
match
---
trailer [3135,3189]
trailer [3135,3189]
===
match
---
simple_stmt [4985,5043]
simple_stmt [4985,5043]
===
match
---
atom_expr [2885,3019]
atom_expr [2885,3019]
===
match
---
operator: = [9556,9557]
operator: = [9556,9557]
===
match
---
fstring_end: " [5889,5890]
fstring_end: " [5889,5890]
===
match
---
name: set_is_paused [5901,5914]
name: set_is_paused [5901,5914]
===
match
---
operator: = [12828,12829]
operator: = [12828,12829]
===
match
---
operator: @ [4933,4934]
operator: @ [4933,4934]
===
match
---
number: 0 [8012,8013]
number: 0 [8012,8013]
===
match
---
name: args [6170,6174]
name: args [6170,6174]
===
match
---
atom_expr [11119,11129]
atom_expr [11119,11129]
===
match
---
simple_stmt [14185,14209]
simple_stmt [14185,14209]
===
match
---
atom_expr [3154,3165]
atom_expr [3154,3165]
===
match
---
dotted_name [1183,1201]
dotted_name [1183,1201]
===
match
---
trailer [8576,8583]
trailer [8576,8583]
===
match
---
argument [12276,12306]
argument [12276,12306]
===
match
---
name: execution_start_date [12171,12191]
name: execution_start_date [12171,12191]
===
match
---
operator: = [1967,1968]
operator: = [1967,1968]
===
match
---
atom_expr [11087,11130]
atom_expr [11087,11130]
===
match
---
trailer [4249,4264]
trailer [4249,4264]
===
match
---
atom_expr [10973,11004]
atom_expr [10973,11004]
===
match
---
trailer [11399,11405]
trailer [11399,11405]
===
match
---
name: args [6103,6107]
name: args [6103,6107]
===
match
---
operator: = [4197,4198]
operator: = [4197,4198]
===
match
---
string: "dag_id" [12444,12452]
string: "dag_id" [12444,12452]
===
match
---
trailer [3979,3992]
trailer [3979,3992]
===
match
---
name: stderr [8998,9004]
name: stderr [8998,9004]
===
match
---
operator: @ [12776,12777]
operator: @ [12776,12777]
===
match
---
name: subdir [10287,10293]
name: subdir [10287,10293]
===
match
---
name: queries [11013,11020]
name: queries [11013,11020]
===
match
---
name: args [5694,5698]
name: args [5694,5698]
===
match
---
name: get_current_api_client [1064,1086]
name: get_current_api_client [1064,1086]
===
match
---
operator: , [7292,7293]
operator: , [7292,7293]
===
match
---
suite [11886,11991]
suite [11886,11991]
===
match
---
name: desc [11368,11372]
name: desc [11368,11372]
===
match
---
name: level [1931,1936]
name: level [1931,1936]
===
match
---
suite [6476,6514]
suite [6476,6514]
===
match
---
trailer [11788,11795]
trailer [11788,11795]
===
match
---
name: dag [7718,7721]
name: dag [7718,7721]
===
match
---
trailer [3644,3648]
trailer [3644,3648]
===
match
---
suite [6523,6550]
suite [6523,6550]
===
match
---
name: args [5496,5500]
name: args [5496,5500]
===
match
---
suite [5813,5892]
suite [5813,5892]
===
match
---
arglist [13981,13993]
arglist [13981,13993]
===
match
---
name: dag [11758,11761]
name: dag [11758,11761]
===
match
---
if_stmt [2680,3020]
if_stmt [2680,3020]
===
match
---
simple_stmt [5047,5085]
simple_stmt [5047,5085]
===
match
---
fstring_end: " [5988,5989]
fstring_end: " [5988,5989]
===
match
---
atom_expr [4794,4803]
atom_expr [4794,4803]
===
match
---
atom_expr [2571,2584]
atom_expr [2571,2584]
===
match
---
name: SIMPLE_LOG_FORMAT [1977,1994]
name: SIMPLE_LOG_FORMAT [1977,1994]
===
match
---
name: start_date [12197,12207]
name: start_date [12197,12207]
===
match
---
operator: @ [1795,1796]
operator: @ [1795,1796]
===
match
---
name: trigger_dag [4724,4735]
name: trigger_dag [4724,4735]
===
match
---
operator: = [9771,9772]
operator: = [9771,9772]
===
match
---
operator: = [2712,2713]
operator: = [2712,2713]
===
match
---
name: source [6542,6548]
name: source [6542,6548]
===
match
---
atom_expr [12454,12463]
atom_expr [12454,12463]
===
match
---
name: err [5412,5415]
name: err [5412,5415]
===
match
---
name: subdir [7702,7708]
name: subdir [7702,7708]
===
match
---
trailer [13814,13821]
trailer [13814,13821]
===
match
---
test [12004,12046]
test [12004,12046]
===
match
---
atom_expr [2418,2431]
atom_expr [2366,2379]
===
match
---
name: state [12522,12527]
name: state [12522,12527]
===
match
---
trailer [6891,6900]
trailer [6891,6900]
===
match
---
name: run_id [4769,4775]
name: run_id [4769,4775]
===
match
---
simple_stmt [8114,8265]
simple_stmt [8114,8265]
===
match
---
simple_stmt [3130,3190]
simple_stmt [3130,3190]
===
match
---
simple_stmt [892,903]
simple_stmt [892,903]
===
match
---
operator: = [13492,13493]
operator: = [13492,13493]
===
match
---
name: yes [5107,5110]
name: yes [5107,5110]
===
match
---
string: """Displays dagbag stats at the command line""" [10199,10246]
string: """Displays dagbag stats at the command line""" [10199,10246]
===
match
---
atom_expr [3482,3743]
atom_expr [3482,3743]
===
match
---
name: dot [6445,6448]
name: dot [6445,6448]
===
match
---
name: execution_date [13867,13881]
name: execution_date [13867,13881]
===
match
---
name: args [2237,2241]
name: args [2237,2241]
===
match
---
trailer [6537,6549]
trailer [6537,6549]
===
match
---
expr_stmt [10905,10954]
expr_stmt [10905,10954]
===
match
---
name: set_is_paused [5669,5682]
name: set_is_paused [5669,5682]
===
match
---
decorator [9616,9642]
decorator [9616,9642]
===
match
---
trailer [10314,10316]
trailer [10314,10316]
===
match
---
trailer [4429,4443]
trailer [4429,4443]
===
match
---
name: e [13542,13543]
name: e [13542,13543]
===
match
---
atom [9960,10110]
atom [9960,10110]
===
match
---
name: state [11072,11077]
name: state [11072,11077]
===
match
---
name: cli [1510,1513]
name: cli [1510,1513]
===
match
---
decorated [4933,5454]
decorated [4933,5454]
===
match
---
import_from [1305,1346]
import_from [1305,1346]
===
match
---
arglist [9455,9477]
arglist [9455,9477]
===
match
---
simple_stmt [2289,2330]
simple_stmt [2289,2330]
===
match
---
parameters [11692,11708]
parameters [11692,11708]
===
match
---
raise_stmt [6975,7105]
raise_stmt [6975,7105]
===
match
---
suite [6858,6902]
suite [6858,6902]
===
match
---
atom_expr [11013,11058]
atom_expr [11013,11058]
===
match
---
name: dag_id [11036,11042]
name: dag_id [11036,11042]
===
match
---
name: err [5372,5375]
name: err [5372,5375]
===
match
---
operator: , [11697,11698]
operator: , [11697,11698]
===
match
---
argument [12951,12969]
argument [12951,12969]
===
match
---
name: get_is_paused [10084,10097]
name: get_is_paused [10084,10097]
===
match
---
trailer [7242,7247]
trailer [7242,7247]
===
match
---
trailer [6657,6663]
trailer [6657,6663]
===
match
---
atom_expr [4909,4930]
atom_expr [4909,4930]
===
match
---
simple_stmt [11801,11819]
simple_stmt [11801,11819]
===
match
---
name: Dot [6585,6588]
name: Dot [6585,6588]
===
match
---
trailer [9023,9029]
trailer [9023,9029]
===
match
---
operator: , [2779,2780]
operator: , [2779,2780]
===
match
---
atom_expr [11771,11782]
atom_expr [11771,11782]
===
match
---
argument [4351,4393]
argument [4351,4393]
===
match
---
name: conf_out [7980,7988]
name: conf_out [7980,7988]
===
match
---
name: BackfillUnfinished [13520,13538]
name: BackfillUnfinished [13520,13538]
===
match
---
if_stmt [14157,14209]
if_stmt [14157,14209]
===
match
---
name: args [10694,10698]
name: args [10694,10698]
===
match
---
name: args [12815,12819]
name: args [12815,12819]
===
match
---
operator: == [6946,6948]
operator: == [6946,6948]
===
match
---
string: 'utf-8' [6892,6899]
string: 'utf-8' [6892,6899]
===
match
---
name: dag_run [3391,3398]
name: dag_run [3391,3398]
===
match
---
trailer [8836,8848]
trailer [8836,8848]
===
match
---
simple_stmt [9382,9389]
simple_stmt [9382,9389]
===
match
---
atom_expr [9449,9478]
atom_expr [9449,9478]
===
match
---
name: reverse [12308,12315]
name: reverse [12308,12315]
===
match
---
name: task_regex [2958,2968]
name: task_regex [2958,2968]
===
match
---
simple_stmt [820,833]
simple_stmt [820,833]
===
match
---
not_test [5805,5812]
not_test [5805,5812]
===
match
---
name: dag [11785,11788]
name: dag [11785,11788]
===
match
---
name: args [7697,7701]
name: args [7697,7701]
===
match
---
trailer [5310,5317]
trailer [5310,5317]
===
match
---
atom [3514,3519]
atom [3514,3519]
===
match
---
trailer [14137,14148]
trailer [14137,14148]
===
match
---
name: args [2394,2398]
name: args [2342,2346]
===
match
---
operator: = [6168,6169]
operator: = [6168,6169]
===
match
---
simple_stmt [2001,2047]
simple_stmt [2001,2047]
===
match
---
suite [13544,13567]
suite [13544,13567]
===
match
---
arglist [8283,8307]
arglist [8283,8307]
===
match
---
operator: { [5977,5978]
operator: { [5977,5978]
===
match
---
trailer [11123,11129]
trailer [11123,11129]
===
match
---
name: airflow [1251,1258]
name: airflow [1251,1258]
===
match
---
name: conf_out [8042,8050]
name: conf_out [8042,8050]
===
match
---
atom_expr [3450,3468]
atom_expr [3450,3468]
===
match
---
simple_stmt [5636,5663]
simple_stmt [5636,5663]
===
match
---
name: conf [7966,7970]
name: conf [7966,7970]
===
match
---
name: models [1360,1366]
name: models [1360,1366]
===
match
---
string: '' [12664,12666]
string: '' [12664,12666]
===
match
---
argument [12132,12161]
argument [12132,12161]
===
match
---
trailer [6663,6720]
trailer [6663,6720]
===
match
---
expr_stmt [4648,4685]
expr_stmt [4648,4685]
===
match
---
name: data [6595,6599]
name: data [6595,6599]
===
match
---
trailer [11423,11425]
trailer [11423,11425]
===
match
---
trailer [13562,13565]
trailer [13562,13565]
===
match
---
expr_stmt [7893,7926]
expr_stmt [7893,7926]
===
match
---
name: args [4370,4374]
name: args [4370,4374]
===
match
---
name: dag_id [5960,5966]
name: dag_id [5960,5966]
===
match
---
expr_stmt [11771,11795]
expr_stmt [11771,11795]
===
match
---
name: print [6875,6880]
name: print [6875,6880]
===
match
---
suite [6926,7138]
suite [6926,7138]
===
match
---
name: dag_state [7388,7397]
name: dag_state [7388,7397]
===
match
---
simple_stmt [9042,9049]
simple_stmt [9042,9049]
===
match
---
name: all [13933,13936]
name: all [13933,13936]
===
match
---
operator: , [13497,13498]
operator: , [13497,13498]
===
match
---
trailer [11601,11608]
trailer [11601,11608]
===
match
---
name: args [13586,13590]
name: args [13586,13590]
===
match
---
operator: , [4036,4037]
operator: , [4036,4037]
===
match
---
decorated [8054,9614]
decorated [8054,9614]
===
match
---
operator: = [10838,10839]
operator: = [10838,10839]
===
match
---
expr_stmt [12937,12990]
expr_stmt [12937,12990]
===
match
---
trailer [3175,3186]
trailer [3175,3186]
===
match
---
operator: , [13065,13066]
operator: , [13065,13066]
===
match
---
trailer [7872,7887]
trailer [7872,7887]
===
match
---
name: exceptions [1191,1201]
name: exceptions [1191,1201]
===
match
---
simple_stmt [6133,6155]
simple_stmt [6133,6155]
===
match
---
name: args [4083,4087]
name: args [4083,4087]
===
match
---
atom_expr [13616,13634]
atom_expr [13616,13634]
===
match
---
name: dags [11881,11885]
name: dags [11881,11885]
===
match
---
name: dot [6580,6583]
name: dot [6580,6583]
===
match
---
operator: } [11932,11933]
operator: } [11932,11933]
===
match
---
name: dag_id [11051,11057]
name: dag_id [11051,11057]
===
match
---
name: communicate [6758,6769]
name: communicate [6758,6769]
===
match
---
name: find [7836,7840]
name: find [7836,7840]
===
match
---
decorators [10623,10676]
decorators [10623,10676]
===
match
---
funcdef [7384,8052]
funcdef [7384,8052]
===
match
---
atom_expr [2683,2698]
atom_expr [2683,2698]
===
match
---
name: ti [3388,3390]
name: ti [3388,3390]
===
match
---
trailer [11484,11487]
trailer [11484,11487]
===
match
---
argument [4769,4787]
argument [4769,4787]
===
match
---
trailer [4087,4116]
trailer [4087,4116]
===
match
---
trailer [9432,9434]
trailer [9432,9434]
===
match
---
trailer [4798,4803]
trailer [4798,4803]
===
match
---
name: args [2953,2957]
name: args [2953,2957]
===
match
---
argument [3222,3252]
argument [3222,3252]
===
match
---
name: dag [3515,3518]
name: dag [3515,3518]
===
match
---
string: """Pauses a DAG""" [5507,5525]
string: """Pauses a DAG""" [5507,5525]
===
match
---
operator: { [2952,2953]
operator: { [2952,2953]
===
match
---
trailer [10795,10802]
trailer [10795,10802]
===
match
---
operator: = [3369,3370]
operator: = [3369,3370]
===
match
---
atom [12430,12749]
atom [12430,12749]
===
match
---
param [5600,5604]
param [5600,5604]
===
match
---
atom_expr [6427,6459]
atom_expr [6427,6459]
===
match
---
expr_stmt [7824,7888]
expr_stmt [7824,7888]
===
match
---
import_from [1347,1412]
import_from [1347,1412]
===
match
---
operator: , [13035,13036]
operator: , [13035,13036]
===
match
---
trailer [10504,10512]
trailer [10504,10512]
===
match
---
name: args [7732,7736]
name: args [7732,7736]
===
match
---
operator: == [8795,8797]
operator: == [8795,8797]
===
match
---
atom_expr [7829,7888]
atom_expr [7829,7888]
===
match
---
trailer [12094,12101]
trailer [12094,12101]
===
match
---
operator: , [5692,5693]
operator: , [5692,5693]
===
match
---
name: partial_subset [2718,2732]
name: partial_subset [2718,2732]
===
match
---
trailer [4824,4834]
trailer [4824,4834]
===
match
---
trailer [2957,2968]
trailer [2957,2968]
===
match
---
fstring [3136,3188]
fstring [3136,3188]
===
match
---
operator: , [1584,1585]
operator: , [1584,1585]
===
match
---
atom_expr [13559,13565]
atom_expr [13559,13565]
===
match
---
name: task [3266,3270]
name: task [3266,3270]
===
match
---
name: AirflowException [10973,10989]
name: AirflowException [10973,10989]
===
match
---
name: str [4510,4513]
name: str [4510,4513]
===
match
---
name: args [2289,2293]
name: args [2289,2293]
===
match
---
atom [10414,10613]
atom [10414,10613]
===
match
---
expr_stmt [5047,5084]
expr_stmt [5047,5084]
===
match
---
suite [8460,9049]
suite [8460,9049]
===
match
---
operator: = [4711,4712]
operator: = [4711,4712]
===
match
---
operator: , [4333,4334]
operator: , [4333,4334]
===
match
---
trailer [2373,2380]
trailer [2495,2502]
===
match
---
trailer [1945,1959]
trailer [1945,1959]
===
match
---
fstring_expr [11920,11933]
fstring_expr [11920,11933]
===
match
---
name: Dot [7167,7170]
name: Dot [7167,7170]
===
match
---
expr_stmt [2335,2381]
expr_stmt [2457,2503]
===
match
---
trailer [3594,3603]
trailer [3594,3603]
===
match
---
argument [12308,12320]
argument [12308,12320]
===
match
---
name: DagRun [8716,8722]
name: DagRun [8716,8722]
===
match
---
name: dag [11699,11702]
name: dag [11699,11702]
===
match
---
name: subdir [12951,12957]
name: subdir [12951,12957]
===
match
---
name: dag_id [5299,5305]
name: dag_id [5299,5305]
===
match
---
suite [4980,5454]
suite [4980,5454]
===
match
---
suite [3284,3429]
suite [3284,3429]
===
match
---
simple_stmt [14114,14149]
simple_stmt [14114,14149]
===
match
---
name: dag [3274,3277]
name: dag [3274,3277]
===
match
---
operator: = [8483,8484]
operator: = [8483,8484]
===
match
---
atom_expr [8346,8421]
atom_expr [8346,8421]
===
match
---
name: PendingDeprecationWarning [2196,2221]
name: PendingDeprecationWarning [2196,2221]
===
match
---
trailer [10989,11004]
trailer [10989,11004]
===
match
---
name: x [9984,9985]
name: x [9984,9985]
===
match
---
name: dry_run [3113,3120]
name: dry_run [3113,3120]
===
match
---
trailer [12068,12073]
trailer [12068,12073]
===
match
---
name: DagModel [1382,1390]
name: DagModel [1382,1390]
===
match
---
string: 'dag_id' [11146,11154]
string: 'dag_id' [11146,11154]
===
match
---
decorators [9616,9669]
decorators [9616,9669]
===
match
---
atom_expr [8798,8822]
atom_expr [8798,8822]
===
match
---
trailer [13980,13994]
trailer [13980,13994]
===
match
---
trailer [6120,6127]
trailer [6120,6127]
===
match
---
name: args [3848,3852]
name: args [3848,3852]
===
match
---
operator: } [5966,5967]
operator: } [5966,5967]
===
match
---
operator: = [9138,9139]
operator: = [9138,9139]
===
match
---
name: get_dag_by_file_location [1540,1564]
name: get_dag_by_file_location [1540,1564]
===
match
---
trailer [7736,7743]
trailer [7736,7743]
===
match
---
operator: = [12002,12003]
operator: = [12002,12003]
===
match
---
atom_expr [12958,12969]
atom_expr [12958,12969]
===
match
---
operator: , [9905,9906]
operator: , [9905,9906]
===
match
---
name: signal [2015,2021]
name: signal [2015,2021]
===
match
---
name: args [9922,9926]
name: args [9922,9926]
===
match
---
comparison [8584,8611]
comparison [8584,8611]
===
match
---
name: subprocess [881,891]
name: subprocess [881,891]
===
match
---
name: AirflowException [2885,2901]
name: AirflowException [2885,2901]
===
match
---
trailer [3209,3253]
trailer [3209,3253]
===
match
---
name: max_date_subq [8798,8811]
name: max_date_subq [8798,8811]
===
match
---
operator: = [5760,5761]
operator: = [5760,5761]
===
match
---
operator: , [4207,4208]
operator: , [4207,4208]
===
match
---
atom_expr [1911,1995]
atom_expr [1911,1995]
===
match
---
trailer [12196,12207]
trailer [12196,12207]
===
match
---
name: execution_date [13185,13199]
name: execution_date [13185,13199]
===
match
---
simple_stmt [3297,3327]
simple_stmt [3297,3327]
===
match
---
name: signal [867,873]
name: signal [867,873]
===
match
---
atom_expr [12616,12641]
atom_expr [12616,12641]
===
match
---
operator: = [6680,6681]
operator: = [6680,6681]
===
match
---
decorator [10649,10676]
decorator [10649,10676]
===
match
---
if_stmt [8314,8422]
if_stmt [8314,8422]
===
match
---
name: AirflowException [1209,1225]
name: AirflowException [1209,1225]
===
match
---
operator: = [4150,4151]
operator: = [4150,4151]
===
match
---
name: show_dagrun [13591,13602]
name: show_dagrun [13591,13602]
===
match
---
operator: = [3681,3682]
operator: = [3681,3682]
===
match
---
operator: = [7313,7314]
operator: = [7313,7314]
===
match
---
name: airflow [1183,1190]
name: airflow [1183,1190]
===
match
---
trailer [13889,13904]
trailer [13889,13904]
===
match
---
name: all_jobs [11444,11452]
name: all_jobs [11444,11452]
===
match
---
operator: , [3861,3862]
operator: , [3861,3862]
===
match
---
expr_stmt [8655,8860]
expr_stmt [8655,8860]
===
match
---
trailer [13184,13199]
trailer [13184,13199]
===
match
---
import_name [860,873]
import_name [860,873]
===
match
---
name: end_date [13213,13221]
name: end_date [13213,13221]
===
match
---
atom_expr [3933,3943]
atom_expr [3933,3943]
===
match
---
trailer [11775,11782]
trailer [11775,11782]
===
match
---
name: subdir [7737,7743]
name: subdir [7737,7743]
===
match
---
arglist [11567,11609]
arglist [11567,11609]
===
match
---
dotted_name [966,990]
dotted_name [966,990]
===
match
---
not_test [3636,3648]
not_test [3636,3648]
===
match
---
string: "[INFO] Please be reminded this DAG is PAUSED now." [8352,8403]
string: "[INFO] Please be reminded this DAG is PAUSED now." [8352,8403]
===
match
---
trailer [8750,8757]
trailer [8750,8757]
===
match
---
simple_stmt [7324,7356]
simple_stmt [7324,7356]
===
match
---
name: args [3590,3594]
name: args [3590,3594]
===
match
---
atom [13723,13948]
atom [13723,13948]
===
match
---
name: args [3450,3454]
name: args [3450,3454]
===
match
---
trailer [7844,7851]
trailer [7844,7851]
===
match
---
dotted_name [1796,1820]
dotted_name [1796,1820]
===
match
---
name: args [11693,11697]
name: args [11693,11697]
===
match
---
operator: , [3519,3520]
operator: , [3519,3520]
===
match
---
operator: = [11702,11703]
operator: = [11702,11703]
===
match
---
operator: { [3170,3171]
operator: { [3170,3171]
===
match
---
param [9957,9958]
param [9957,9958]
===
match
---
atom_expr [4245,4264]
atom_expr [4245,4264]
===
match
---
trailer [9985,9992]
trailer [9985,9992]
===
match
---
name: imgcat [13607,13613]
name: imgcat [13607,13613]
===
match
---
atom_expr [9860,9880]
atom_expr [9860,9880]
===
match
---
name: print_as [11549,11557]
name: print_as [11549,11557]
===
match
---
operator: = [3201,3202]
operator: = [3201,3202]
===
match
---
param [12426,12428]
param [12426,12428]
===
match
---
operator: = [9949,9950]
operator: = [9949,9950]
===
match
---
simple_stmt [10199,10247]
simple_stmt [10199,10247]
===
match
---
trailer [11020,11027]
trailer [11020,11027]
===
match
---
atom_expr [2764,2779]
atom_expr [2764,2779]
===
match
---
name: SIGTERM [2022,2029]
name: SIGTERM [2022,2029]
===
match
---
name: dag_id [10796,10802]
name: dag_id [10796,10802]
===
match
---
name: dag [12937,12940]
name: dag [12937,12940]
===
match
---
decorators [12759,12802]
decorators [12759,12802]
===
match
---
string: """Displays DAG or saves it's graphic representation to the file""" [6017,6084]
string: """Displays DAG or saves it's graphic representation to the file""" [6017,6084]
===
match
---
simple_stmt [3482,3744]
simple_stmt [3482,3744]
===
match
---
name: suppress_logs_and_warning [10147,10172]
name: suppress_logs_and_warning [10147,10172]
===
match
---
expr_stmt [4703,4844]
expr_stmt [4703,4844]
===
match
---
name: literal_eval [10581,10593]
name: literal_eval [10581,10593]
===
match
---
arglist [13005,13091]
arglist [13005,13091]
===
match
---
name: dag_id [7845,7851]
name: dag_id [7845,7851]
===
match
---
name: ignore_task_deps [4134,4150]
name: ignore_task_deps [4134,4150]
===
match
---
atom_expr [9795,9806]
atom_expr [9795,9806]
===
match
---
operator: = [8273,8274]
operator: = [8273,8274]
===
match
---
name: args [12236,12240]
name: args [12236,12240]
===
match
---
import_from [1639,1688]
import_from [1639,1688]
===
match
---
name: print [8346,8351]
name: print [8346,8351]
===
match
---
simple_stmt [8469,8647]
simple_stmt [8469,8647]
===
match
---
name: SystemExit [5828,5838]
name: SystemExit [5828,5838]
===
match
---
operator: , [1959,1960]
operator: , [1959,1960]
===
match
---
name: file [10438,10442]
name: file [10438,10442]
===
match
---
trailer [8014,8019]
trailer [8014,8019]
===
match
---
testlist_comp [11456,11525]
testlist_comp [11456,11525]
===
match
---
operator: , [12161,12162]
operator: , [12161,12162]
===
match
---
name: sys [899,902]
name: sys [899,902]
===
match
---
trailer [3810,3821]
trailer [3810,3821]
===
match
---
name: DagRun [1392,1398]
name: DagRun [1392,1398]
===
match
---
trailer [14200,14207]
trailer [14200,14207]
===
match
---
operator: , [2221,2222]
operator: , [2221,2222]
===
match
---
name: append [11021,11027]
name: append [11021,11027]
===
match
---
annassign [8667,8860]
annassign [8667,8860]
===
match
---
fstring_end: " [11943,11944]
fstring_end: " [11943,11944]
===
match
---
operator: = [3034,3035]
operator: = [3034,3035]
===
match
---
if_stmt [5089,5454]
if_stmt [5089,5454]
===
match
---
trailer [10935,10942]
trailer [10935,10942]
===
match
---
name: dr [12616,12618]
name: dr [12616,12618]
===
match
---
name: dag_id [9898,9904]
name: dag_id [9898,9904]
===
match
---
atom_expr [5784,5795]
atom_expr [5784,5795]
===
match
---
comparison [11855,11885]
comparison [11855,11885]
===
match
---
string: "end_date" [12680,12690]
string: "end_date" [12680,12690]
===
match
---
name: imgcat [6469,6475]
name: imgcat [6469,6475]
===
match
---
param [1844,1852]
param [1844,1852]
===
match
---
trailer [4735,4844]
trailer [4735,4844]
===
match
---
name: get_dag [1527,1534]
name: get_dag [1527,1534]
===
match
---
name: errno [6940,6945]
name: errno [6940,6945]
===
match
---
trailer [7901,7904]
trailer [7901,7904]
===
match
---
with_stmt [8427,9049]
with_stmt [8427,9049]
===
match
---
atom_expr [6647,6720]
atom_expr [6647,6720]
===
match
---
simple_stmt [6875,6902]
simple_stmt [6875,6902]
===
match
---
atom_expr [12692,12715]
atom_expr [12692,12715]
===
match
---
trailer [8034,8039]
trailer [8034,8039]
===
match
---
name: execution_date [13051,13065]
name: execution_date [13051,13065]
===
match
---
name: run_id [12490,12496]
name: run_id [12490,12496]
===
match
---
trailer [2422,2431]
trailer [2370,2379]
===
match
---
operator: , [7743,7744]
operator: , [7743,7744]
===
match
---
expr_stmt [10778,10802]
expr_stmt [10778,10802]
===
match
---
name: show_dagrun [13572,13583]
name: show_dagrun [13572,13583]
===
match
---
operator: = [3076,3077]
operator: = [3076,3077]
===
match
---
operator: , [10478,10479]
operator: , [10478,10479]
===
match
---
operator: , [3361,3362]
operator: , [3361,3362]
===
match
---
name: suppress_logs_and_warning [10650,10675]
name: suppress_logs_and_warning [10650,10675]
===
match
---
parameters [8102,8108]
parameters [8102,8108]
===
match
---
name: print [3297,3302]
name: print [3297,3302]
===
match
---
name: cli [1100,1103]
name: cli [1100,1103]
===
match
---
trailer [2007,2014]
trailer [2007,2014]
===
match
---
operator: { [10930,10931]
operator: { [10930,10931]
===
match
---
trailer [8351,8421]
trailer [8351,8421]
===
match
---
name: out [7893,7896]
name: out [7893,7896]
===
match
---
operator: , [10099,10100]
operator: , [10099,10100]
===
match
---
name: args [11827,11831]
name: args [11827,11831]
===
match
---
arglist [13802,13905]
arglist [13802,13905]
===
match
---
fstring_expr [2952,2969]
fstring_expr [2952,2969]
===
match
---
name: args [4794,4798]
name: args [4794,4798]
===
match
---
name: args [12004,12008]
name: args [12004,12008]
===
match
---
name: cli_utils [10624,10633]
name: cli_utils [10624,10633]
===
match
---
atom_expr [7252,7319]
atom_expr [7252,7319]
===
match
---
expr_stmt [8269,8308]
expr_stmt [8269,8308]
===
match
---
atom_expr [11395,11405]
atom_expr [11395,11405]
===
match
---
name: args [11395,11399]
name: args [11395,11399]
===
match
---
trailer [13784,13919]
trailer [13784,13919]
===
match
---
name: airflow [1144,1151]
name: airflow [1144,1151]
===
match
---
name: output [12384,12390]
name: output [12384,12390]
===
match
---
name: dag_run_state [3704,3717]
name: dag_run_state [3704,3717]
===
match
---
name: dag_id [11860,11866]
name: dag_id [11860,11866]
===
match
---
atom_expr [6881,6900]
atom_expr [6881,6900]
===
match
---
string: '' [7942,7944]
string: '' [7942,7944]
===
match
---
fstring_string:  not found [10943,10953]
fstring_string:  not found [10943,10953]
===
match
---
trailer [5838,5891]
trailer [5838,5891]
===
match
---
fstring [5947,5989]
fstring [5947,5989]
===
match
---
name: dr [8009,8011]
name: dr [8009,8011]
===
match
---
name: dr [12692,12694]
name: dr [12692,12694]
===
match
---
name: cli [1474,1477]
name: cli [1474,1477]
===
match
---
name: proc [6724,6728]
name: proc [6724,6728]
===
match
---
operator: = [12279,12280]
operator: = [12279,12280]
===
match
---
sync_comp_for [11506,11525]
sync_comp_for [11506,11525]
===
match
---
name: Dot [957,960]
name: Dot [957,960]
===
match
---
fstring_string: Dag id  [10923,10930]
fstring_string: Dag id  [10923,10930]
===
match
---
param [7162,7171]
param [7162,7171]
===
match
---
operator: , [8987,8988]
operator: , [8987,8988]
===
match
---
if_stmt [14019,14083]
if_stmt [14019,14083]
===
match
---
with_item [6647,6728]
with_item [6647,6728]
===
match
---
trailer [12240,12249]
trailer [12240,12249]
===
match
---
name: func [8513,8517]
name: func [8513,8517]
===
match
---
fstring_string: Dry run of DAG  [3138,3153]
fstring_string: Dry run of DAG  [3138,3153]
===
match
---
name: donot_pickle [3980,3992]
name: donot_pickle [3980,3992]
===
match
---
funcdef [4571,4931]
funcdef [4571,4931]
===
match
---
import_from [1139,1177]
import_from [1139,1177]
===
match
---
atom_expr [3203,3253]
atom_expr [3203,3253]
===
match
---
simple_stmt [2879,3020]
simple_stmt [2879,3020]
===
match
---
trailer [6174,6179]
trailer [6174,6179]
===
match
---
fstring_start: f" [7330,7332]
fstring_start: f" [7330,7332]
===
match
---
import_from [1004,1032]
import_from [1004,1032]
===
match
---
name: args [13650,13654]
name: args [13650,13654]
===
match
---
trailer [6508,6513]
trailer [6508,6513]
===
match
---
trailer [4534,4539]
trailer [4534,4539]
===
match
---
argument [9128,9144]
argument [9128,9144]
===
match
---
trailer [8287,8294]
trailer [8287,8294]
===
match
---
name: imgcat [6226,6232]
name: imgcat [6226,6232]
===
match
---
name: cli_utils [10121,10130]
name: cli_utils [10121,10130]
===
match
---
name: get_dag [2348,2355]
name: get_dag [2470,2477]
===
match
---
name: airflow [1694,1701]
name: airflow [1694,1701]
===
match
---
operator: = [13614,13615]
operator: = [13614,13615]
===
match
---
tfpdef [6580,6588]
tfpdef [6580,6588]
===
match
---
operator: , [4787,4788]
operator: , [4787,4788]
===
match
---
name: _save_dot_to_file [7144,7161]
name: _save_dot_to_file [7144,7161]
===
match
---
operator: = [13139,13140]
operator: = [13139,13140]
===
match
---
param [5496,5500]
param [5496,5500]
===
match
---
operator: @ [10649,10650]
operator: @ [10649,10650]
===
match
---
simple_stmt [3388,3404]
simple_stmt [3388,3404]
===
match
---
suite [2280,2330]
suite [2280,2330]
===
match
---
trailer [3277,3283]
trailer [3277,3283]
===
match
---
trailer [13866,13881]
trailer [13866,13881]
===
match
---
expr_stmt [11801,11818]
expr_stmt [11801,11818]
===
match
---
atom_expr [12487,12496]
atom_expr [12487,12496]
===
match
---
string: """     Returns the state (and conf if exists) of a DagRun at the command line.     >>> airflow dags state tutorial 2015-01-01T00:00:00.000000     running     >>> airflow dags state a_dag_with_conf_passed 2015-01-01T00:00:00.000000     failed, {"name": "bob", "age": "42"}     """ [7409,7689]
string: """     Returns the state (and conf if exists) of a DagRun at the command line.     >>> airflow dags state tutorial 2015-01-01T00:00:00.000000     running     >>> airflow dags state a_dag_with_conf_passed 2015-01-01T00:00:00.000000     failed, {"name": "bob", "age": "42"}     """ [7409,7689]
===
match
---
name: x [9957,9958]
name: x [9957,9958]
===
match
---
atom_expr [4370,4393]
atom_expr [4370,4393]
===
match
---
operator: = [9498,9499]
operator: = [9498,9499]
===
match
---
operator: = [13080,13081]
operator: = [13080,13081]
===
match
---
trailer [13620,13634]
trailer [13620,13634]
===
match
---
operator: = [5275,5276]
operator: = [5275,5276]
===
match
---
suite [5254,5346]
suite [5254,5346]
===
match
---
decorator [10623,10649]
decorator [10623,10649]
===
match
---
name: DagRun [7829,7835]
name: DagRun [7829,7835]
===
match
---
atom_expr [8499,8636]
atom_expr [8499,8636]
===
match
---
import_from [1033,1086]
import_from [1033,1086]
===
match
---
simple_stmt [9698,9760]
simple_stmt [9698,9760]
===
match
---
name: dag [8269,8272]
name: dag [8269,8272]
===
match
---
operator: = [10339,10340]
operator: = [10339,10340]
===
match
---
suite [14031,14083]
suite [14031,14083]
===
match
---
atom_expr [2714,2836]
atom_expr [2714,2836]
===
match
---
name: dot [946,949]
name: dot [946,949]
===
match
---
trailer [4760,4767]
trailer [4760,4767]
===
match
---
atom_expr [3237,3252]
atom_expr [3237,3252]
===
match
---
simple_stmt [5941,5991]
simple_stmt [5941,5991]
===
match
---
name: args [2418,2422]
name: args [2366,2370]
===
match
---
simple_stmt [5705,5752]
simple_stmt [5705,5752]
===
match
---
dictorsetmaker [9974,10100]
dictorsetmaker [9974,10100]
===
match
---
name: args [2369,2373]
name: args [2491,2495]
===
match
---
operator: @ [7358,7359]
operator: @ [7358,7359]
===
match
---
argument [11317,11325]
argument [11317,11325]
===
match
---
operator: == [8758,8760]
operator: == [8758,8760]
===
match
---
operator: , [12496,12497]
operator: , [12496,12497]
===
match
---
name: Popen [6658,6663]
name: Popen [6658,6663]
===
match
---
operator: , [6745,6746]
operator: , [6745,6746]
===
match
---
name: no_backfills [12132,12144]
name: no_backfills [12132,12144]
===
match
---
string: """Lists latest n jobs""" [10715,10740]
string: """Lists latest n jobs""" [10715,10740]
===
match
---
simple_stmt [1755,1793]
simple_stmt [1755,1793]
===
match
---
simple_stmt [809,820]
simple_stmt [809,820]
===
match
---
name: category [2187,2195]
name: category [2187,2195]
===
match
---
atom_expr [1968,1994]
atom_expr [1968,1994]
===
match
---
name: order_by [11340,11348]
name: order_by [11340,11348]
===
match
---
param [10411,10412]
param [10411,10412]
===
match
---
atom_expr [6812,6838]
atom_expr [6812,6838]
===
match
---
name: state [11110,11115]
name: state [11110,11115]
===
match
---
name: get_dag [8275,8282]
name: get_dag [8275,8282]
===
match
---
param [9687,9691]
param [9687,9691]
===
match
---
trailer [9897,9904]
trailer [9897,9904]
===
match
---
atom_expr [6602,6624]
atom_expr [6602,6624]
===
match
---
name: end_date [2576,2584]
name: end_date [2576,2584]
===
match
---
arglist [12951,12989]
arglist [12951,12989]
===
match
---
atom_expr [10810,10821]
atom_expr [10810,10821]
===
match
---
name: args [5784,5788]
name: args [5784,5788]
===
match
---
name: session [12821,12828]
name: session [12821,12828]
===
match
---
name: input [5122,5127]
name: input [5122,5127]
===
match
---
trailer [5287,5298]
trailer [5287,5298]
===
match
---
try_stmt [6629,7138]
try_stmt [6629,7138]
===
match
---
name: label [8545,8550]
name: label [8545,8550]
===
match
---
trailer [11880,11885]
trailer [11880,11885]
===
match
---
simple_stmt [1491,1639]
simple_stmt [1491,1639]
===
match
---
if_stmt [2845,3020]
if_stmt [2845,3020]
===
match
---
name: DagBag [1374,1380]
name: DagBag [1374,1380]
===
match
---
trailer [3241,3252]
trailer [3241,3252]
===
match
---
if_stmt [2387,2504]
if_stmt [2335,2452]
===
match
---
operator: = [12365,12366]
operator: = [12365,12366]
===
match
---
atom_expr [10931,10942]
atom_expr [10931,10942]
===
match
---
trailer [3773,3777]
trailer [3773,3777]
===
match
---
trailer [12521,12527]
trailer [12521,12527]
===
match
---
name: str [7182,7185]
name: str [7182,7185]
===
match
---
atom_expr [6681,6696]
atom_expr [6681,6696]
===
match
---
arglist [2015,2045]
arglist [2015,2045]
===
match
---
name: dag [9500,9503]
name: dag [9500,9503]
===
match
---
simple_stmt [5435,5454]
simple_stmt [5435,5454]
===
match
---
dotted_name [1092,1116]
dotted_name [1092,1116]
===
match
---
trailer [3852,3861]
trailer [3852,3861]
===
match
---
import_from [903,930]
import_from [903,930]
===
match
---
name: task [3357,3361]
name: task [3357,3361]
===
match
---
expr_stmt [13958,13994]
expr_stmt [13958,13994]
===
match
---
name: dot_graph [14138,14147]
name: dot_graph [14138,14147]
===
match
---
name: dag [10765,10768]
name: dag [10765,10768]
===
match
---
file_input [786,14209]
file_input [786,14209]
===
match
---
arith_expr [7991,8020]
arith_expr [7991,8020]
===
match
---
operator: , [1534,1535]
operator: , [1534,1535]
===
match
---
atom_expr [2001,2046]
atom_expr [2001,2046]
===
match
---
name: get_current_api_client [4661,4683]
name: get_current_api_client [4661,4683]
===
match
---
import_from [932,960]
import_from [932,960]
===
match
---
name: dag_list_dag_runs [11675,11692]
name: dag_list_dag_runs [11675,11692]
===
match
---
dotted_name [1453,1466]
dotted_name [1453,1466]
===
match
---
simple_stmt [3025,3041]
simple_stmt [3025,3041]
===
match
---
name: execution_date [3222,3236]
name: execution_date [3222,3236]
===
match
---
name: no_backfill [12150,12161]
name: no_backfill [12150,12161]
===
match
---
trailer [2086,2228]
trailer [2086,2228]
===
match
---
simple_stmt [6242,6400]
simple_stmt [6242,6400]
===
match
---
trailer [13590,13602]
trailer [13590,13602]
===
match
---
atom_expr [13016,13035]
atom_expr [13016,13035]
===
match
---
name: logging [1911,1918]
name: logging [1911,1918]
===
match
---
operator: = [10753,10754]
operator: = [10753,10754]
===
match
---
name: is_paused [5683,5692]
name: is_paused [5683,5692]
===
match
---
name: dag_id [9986,9992]
name: dag_id [9986,9992]
===
match
---
name: max_date_run [9113,9125]
name: max_date_run [9113,9125]
===
match
---
atom_expr [14044,14082]
atom_expr [14044,14082]
===
match
---
operator: = [11143,11144]
operator: = [11143,11144]
===
match
---
atom_expr [10340,10359]
atom_expr [10340,10359]
===
match
---
trailer [1976,1994]
trailer [1976,1994]
===
match
---
operator: = [13968,13969]
operator: = [13968,13969]
===
match
---
atom_expr [7745,7756]
atom_expr [7745,7756]
===
match
---
with_stmt [11207,11527]
with_stmt [11207,11527]
===
match
---
name: clear_dags [3486,3496]
name: clear_dags [3486,3496]
===
match
---
trailer [9399,9435]
trailer [9399,9435]
===
match
---
name: render_dag [1678,1688]
name: render_dag [1678,1688]
===
match
---
name: yes [3645,3648]
name: yes [3645,3648]
===
match
---
atom_expr [9780,9807]
atom_expr [9780,9807]
===
match
---
name: print [13553,13558]
name: print [13553,13558]
===
match
---
name: proc [6753,6757]
name: proc [6753,6757]
===
match
---
arglist [6272,6389]
arglist [6272,6389]
===
match
---
trailer [12395,12402]
trailer [12395,12402]
===
match
---
fstring_end: " [3324,3325]
fstring_end: " [3324,3325]
===
match
---
simple_stmt [4853,4868]
simple_stmt [4853,4868]
===
match
---
name: airflow [1352,1359]
name: airflow [1352,1359]
===
match
---
name: subdir [9800,9806]
name: subdir [9800,9806]
===
match
---
expr_stmt [3067,3099]
expr_stmt [3067,3099]
===
match
---
dotted_name [1644,1670]
dotted_name [1644,1670]
===
match
---
operator: = [6093,6094]
operator: = [6093,6094]
===
match
---
name: dag [2335,2338]
name: dag [2457,2460]
===
match
---
name: create_session [1723,1737]
name: create_session [1723,1737]
===
match
---
name: dag_list_jobs [10680,10693]
name: dag_list_jobs [10680,10693]
===
match
---
name: err [6881,6884]
name: err [6881,6884]
===
match
---
atom_expr [10468,10478]
atom_expr [10468,10478]
===
match
---
atom_expr [6095,6128]
atom_expr [6095,6128]
===
match
---
trailer [10286,10293]
trailer [10286,10293]
===
match
---
trailer [13654,13666]
trailer [13654,13666]
===
match
---
trailer [12629,12639]
trailer [12629,12639]
===
match
---
atom_expr [6193,6204]
atom_expr [6193,6204]
===
match
---
trailer [10580,10593]
trailer [10580,10593]
===
match
---
string: "start_date" [12602,12614]
string: "start_date" [12602,12614]
===
match
---
trailer [8030,8051]
trailer [8030,8051]
===
match
---
decorator [1795,1821]
decorator [1795,1821]
===
match
---
operator: == [5228,5230]
operator: == [5228,5230]
===
match
---
argument [3927,3943]
argument [3927,3943]
===
match
---
trailer [12008,12014]
trailer [12008,12014]
===
match
---
argument [13005,13035]
argument [13005,13035]
===
match
---
atom_expr [10778,10789]
atom_expr [10778,10789]
===
match
---
operator: = [12957,12958]
operator: = [12957,12958]
===
match
---
atom_expr [10436,10442]
atom_expr [10436,10442]
===
match
---
operator: , [4264,4265]
operator: , [4264,4265]
===
match
---
name: conf [3053,3057]
name: conf [3053,3057]
===
match
---
trailer [8743,8823]
trailer [8743,8823]
===
match
---
decorated [4545,4931]
decorated [4545,4931]
===
match
---
trailer [8521,8544]
trailer [8521,8544]
===
match
---
atom_expr [12391,12402]
atom_expr [12391,12402]
===
match
---
name: fields [11136,11142]
name: fields [11136,11142]
===
match
---
name: dag_show [5997,6005]
name: dag_show [5997,6005]
===
match
---
operator: , [8294,8295]
operator: , [8294,8295]
===
match
---
parameters [1837,1853]
parameters [1837,1853]
===
match
---
atom_expr [11460,11488]
atom_expr [11460,11488]
===
match
---
suite [4593,4931]
suite [4593,4931]
===
match
---
simple_stmt [2335,2382]
simple_stmt [2457,2504]
===
match
---
trailer [4294,4302]
trailer [4294,4302]
===
match
---
argument [3581,3603]
argument [3581,3603]
===
match
---
fstring_end: " [3187,3188]
fstring_end: " [3187,3188]
===
match
---
string: "dag_num" [10492,10501]
string: "dag_num" [10492,10501]
===
match
---
trailer [11101,11130]
trailer [11101,11130]
===
match
---
name: conf_out [7931,7939]
name: conf_out [7931,7939]
===
match
---
operator: , [8771,8772]
operator: , [8771,8772]
===
match
---
comparison [6938,6961]
comparison [6938,6961]
===
match
---
trailer [11557,11615]
trailer [11557,11615]
===
match
---
atom_expr [11532,11615]
atom_expr [11532,11615]
===
match
---
arglist [8352,8420]
arglist [8352,8420]
===
match
---
parameters [6579,6589]
parameters [6579,6589]
===
match
---
atom_expr [13854,13881]
atom_expr [13854,13881]
===
match
---
atom_expr [3718,3728]
atom_expr [3718,3728]
===
match
---
name: task_dict [2856,2865]
name: task_dict [2856,2865]
===
match
---
simple_stmt [4504,4519]
simple_stmt [4504,4519]
===
match
---
trailer [12561,12576]
trailer [12561,12576]
===
match
---
trailer [12618,12629]
trailer [12618,12629]
===
match
---
decorator [7358,7384]
decorator [7358,7384]
===
match
---
test [12616,12666]
test [12616,12666]
===
match
---
expr_stmt [10745,10757]
expr_stmt [10745,10757]
===
match
---
param [10694,10699]
param [10694,10699]
===
match
---
expr_stmt [11136,11202]
expr_stmt [11136,11202]
===
match
---
or_test [2341,2381]
or_test [2463,2503]
===
match
---
operator: , [12101,12102]
operator: , [12101,12102]
===
match
---
trailer [6102,6128]
trailer [6102,6128]
===
match
---
name: imgcat [6184,6190]
name: imgcat [6184,6190]
===
match
---
name: SystemExit [6248,6258]
name: SystemExit [6248,6258]
===
match
---
trailer [9610,9612]
trailer [9610,9612]
===
match
---
operator: , [13199,13200]
operator: , [13199,13200]
===
match
---
funcdef [7140,7356]
funcdef [7140,7356]
===
match
---
suite [11240,11527]
suite [11240,11527]
===
match
---
argument [3961,4036]
argument [3961,4036]
===
match
---
trailer [4539,4542]
trailer [4539,4542]
===
match
---
trailer [8334,8336]
trailer [8334,8336]
===
match
---
import_name [809,819]
import_name [809,819]
===
match
---
import_from [1755,1792]
import_from [1755,1792]
===
match
---
name: decode [6885,6891]
name: decode [6885,6891]
===
match
---
name: dag_next_execution [8084,8102]
name: dag_next_execution [8084,8102]
===
match
---
operator: = [2323,2324]
operator: = [2323,2324]
===
match
---
operator: = [6600,6601]
operator: = [6600,6601]
===
match
---
trailer [4000,4011]
trailer [4000,4011]
===
match
---
name: action_logging [7369,7383]
name: action_logging [7369,7383]
===
match
---
arglist [7841,7887]
arglist [7841,7887]
===
match
---
comparison [13802,13836]
comparison [13802,13836]
===
match
---
atom_expr [8744,8757]
atom_expr [8744,8757]
===
match
---
funcdef [1821,4543]
funcdef [1821,4543]
===
match
---
argument [6611,6623]
argument [6611,6623]
===
match
---
operator: = [12116,12117]
operator: = [12116,12117]
===
match
---
import_as_name [1474,1490]
import_as_name [1474,1490]
===
match
---
operator: , [3909,3910]
operator: , [3909,3910]
===
match
---
atom_expr [6116,6127]
atom_expr [6116,6127]
===
match
---
name: next_info [9400,9409]
name: next_info [9400,9409]
===
match
---
test [12692,12738]
test [12692,12738]
===
match
---
name: x [10503,10504]
name: x [10503,10504]
===
match
---
argument [10369,10387]
argument [10369,10387]
===
match
---
atom_expr [14191,14207]
atom_expr [14191,14207]
===
match
---
string: "Y" [5231,5234]
string: "Y" [5231,5234]
===
match
---
name: end_date [2423,2431]
name: end_date [2371,2379]
===
match
---
name: AirflowException [2447,2463]
name: AirflowException [2395,2411]
===
match
---
name: set_is_paused [5530,5543]
name: set_is_paused [5530,5543]
===
match
---
name: output [12396,12402]
name: output [12396,12402]
===
match
---
atom [11260,11435]
atom [11260,11435]
===
match
---
string: "max_date" [8551,8561]
string: "max_date" [8551,8561]
===
match
---
simple_stmt [11013,11059]
simple_stmt [11013,11059]
===
match
---
atom_expr [7223,7247]
atom_expr [7223,7247]
===
match
---
arith_expr [8031,8050]
arith_expr [8031,8050]
===
match
---
if_stmt [9150,9389]
if_stmt [9150,9389]
===
match
---
name: pool [4193,4197]
name: pool [4193,4197]
===
match
---
trailer [11109,11115]
trailer [11109,11115]
===
match
---
name: cli_utils [1796,1805]
name: cli_utils [1796,1805]
===
match
---
decorator [12776,12802]
decorator [12776,12802]
===
match
---
name: filename [7338,7346]
name: filename [7338,7346]
===
match
---
operator: = [12418,12419]
operator: = [12418,12419]
===
match
---
name: _display_dot_via_imgcat [14114,14137]
name: _display_dot_via_imgcat [14114,14137]
===
match
---
operator: = [3547,3548]
operator: = [3547,3548]
===
match
---
atom_expr [11921,11932]
atom_expr [11921,11932]
===
match
---
atom_expr [5636,5662]
atom_expr [5636,5662]
===
match
---
suite [10892,11005]
suite [10892,11005]
===
match
---
name: filename [14022,14030]
name: filename [14022,14030]
===
match
---
operator: { [12430,12431]
operator: { [12430,12431]
===
match
---
simple_stmt [11532,11616]
simple_stmt [11532,11616]
===
match
---
param [12815,12820]
param [12815,12820]
===
match
---
operator: = [2763,2764]
operator: = [2763,2764]
===
match
---
trailer [9503,9520]
trailer [9503,9520]
===
match
---
simple_stmt [2624,2675]
simple_stmt [2624,2675]
===
match
---
tfpdef [7172,7185]
tfpdef [7172,7185]
===
match
---
trailer [7749,7756]
trailer [7749,7756]
===
match
---
name: action_logging [1806,1820]
name: action_logging [1806,1820]
===
match
---
trailer [8550,8562]
trailer [8550,8562]
===
match
---
suite [6233,6400]
suite [6233,6400]
===
match
---
if_stmt [7694,7820]
if_stmt [7694,7820]
===
match
---
operator: @ [12759,12760]
operator: @ [12759,12760]
===
match
---
name: query [8507,8512]
name: query [8507,8512]
===
match
---
name: state [12117,12122]
name: state [12117,12122]
===
match
---
atom_expr [12719,12730]
atom_expr [12719,12730]
===
match
---
name: error_message [11895,11908]
name: error_message [11895,11908]
===
match
---
trailer [12456,12463]
trailer [12456,12463]
===
match
---
name: filename_without_ext [7192,7212]
name: filename_without_ext [7192,7212]
===
match
---
dotted_name [9617,9641]
dotted_name [9617,9641]
===
match
---
atom_expr [4290,4302]
atom_expr [4290,4302]
===
match
---
argument [4749,4767]
argument [4749,4767]
===
match
---
except_clause [13513,13543]
except_clause [13513,13543]
===
match
---
trailer [10097,10099]
trailer [10097,10099]
===
match
---
name: args [12145,12149]
name: args [12145,12149]
===
match
---
simple_stmt [7718,7758]
simple_stmt [7718,7758]
===
match
---
name: all_jobs [11572,11580]
name: all_jobs [11572,11580]
===
match
---
operator: = [7300,7301]
operator: = [7300,7301]
===
match
---
simple_stmt [1689,1755]
simple_stmt [1689,1755]
===
match
---
simple_stmt [845,860]
simple_stmt [845,860]
===
match
---
suite [2866,3020]
suite [2866,3020]
===
match
---
argument [13131,13155]
argument [13131,13155]
===
match
---
trailer [12351,12756]
trailer [12351,12756]
===
match
---
raise_stmt [6242,6399]
raise_stmt [6242,6399]
===
match
---
parameters [10187,10193]
parameters [10187,10193]
===
match
---
name: args [5847,5851]
name: args [5847,5851]
===
match
---
trailer [9878,9880]
trailer [9878,9880]
===
match
---
expr_stmt [3025,3040]
expr_stmt [3025,3040]
===
match
---
trailer [4155,4175]
trailer [4155,4175]
===
match
---
atom_expr [8317,8336]
atom_expr [8317,8336]
===
match
---
name: args [11597,11601]
name: args [11597,11601]
===
match
---
suite [13101,13509]
suite [13101,13509]
===
match
---
name: basicConfig [1919,1930]
name: basicConfig [1919,1930]
===
match
---
simple_stmt [10300,10621]
simple_stmt [10300,10621]
===
match
---
decorator [4933,4959]
decorator [4933,4959]
===
match
---
atom_expr [3089,3098]
atom_expr [3089,3098]
===
match
---
name: args [10810,10814]
name: args [10810,10814]
===
match
---
trailer [3302,3326]
trailer [3302,3326]
===
match
---
trailer [2665,2674]
trailer [2665,2674]
===
match
---
trailer [3485,3496]
trailer [3485,3496]
===
match
---
parameters [5495,5501]
parameters [5495,5501]
===
match
---
name: query [8710,8715]
name: query [8710,8715]
===
match
---
atom_expr [2604,2619]
atom_expr [2604,2619]
===
match
---
trailer [8677,8685]
trailer [8677,8685]
===
match
---
atom_expr [9578,9612]
atom_expr [9578,9612]
===
match
---
atom_expr [8031,8039]
atom_expr [8031,8039]
===
match
---
operator: , [9126,9127]
operator: , [9126,9127]
===
match
---
trailer [9827,9829]
trailer [9827,9829]
===
match
---
name: print [4504,4509]
name: print [4504,4509]
===
match
---
operator: , [6388,6389]
operator: , [6388,6389]
===
match
---
name: sys [8410,8413]
name: sys [8410,8413]
===
match
---
trailer [7904,7910]
trailer [7904,7910]
===
match
---
trailer [9422,9432]
trailer [9422,9432]
===
match
---
atom_expr [9896,9904]
atom_expr [9896,9904]
===
match
---
atom_expr [10018,10028]
atom_expr [10018,10028]
===
match
---
trailer [5106,5110]
trailer [5106,5110]
===
match
---
atom_expr [11212,11228]
atom_expr [11212,11228]
===
match
---
name: format [1961,1967]
name: format [1961,1967]
===
match
---
name: print [14185,14190]
name: print [14185,14190]
===
match
---
fstring_expr [5977,5988]
fstring_expr [5977,5988]
===
match
---
name: conf [4789,4793]
name: conf [4789,4793]
===
match
---
trailer [6258,6399]
trailer [6258,6399]
===
match
---
simple_stmt [1911,1996]
simple_stmt [1911,1996]
===
match
---
trailer [5298,5318]
trailer [5298,5318]
===
match
---
trailer [1930,1995]
trailer [1930,1995]
===
match
---
name: dag_runs [12262,12270]
name: dag_runs [12262,12270]
===
match
---
name: __getattribute__ [11468,11484]
name: __getattribute__ [11468,11484]
===
match
---
name: filename [7263,7271]
name: filename [7263,7271]
===
match
---
trailer [2014,2046]
trailer [2014,2046]
===
match
---
operator: = [2195,2196]
operator: = [2195,2196]
===
match
---
name: ti [3416,3418]
name: ti [3416,3418]
===
match
---
operator: @ [10623,10624]
operator: @ [10623,10624]
===
match
---
atom_expr [5060,5084]
atom_expr [5060,5084]
===
match
---
number: 0 [7963,7964]
number: 0 [7963,7964]
===
match
---
operator: * [11317,11318]
operator: * [11317,11318]
===
match
---
name: dot [6602,6605]
name: dot [6602,6605]
===
match
---
name: output [11590,11596]
name: output [11590,11596]
===
match
---
name: DebugExecutor [1291,1304]
name: DebugExecutor [1291,1304]
===
match
---
trailer [5082,5084]
trailer [5082,5084]
===
match
---
suite [13708,14209]
suite [13708,14209]
===
match
---
name: configuration [1152,1165]
name: configuration [1152,1165]
===
match
---
name: key [9882,9885]
name: key [9882,9885]
===
match
---
decorator [5456,5482]
decorator [5456,5482]
===
match
---
name: print [7324,7329]
name: print [7324,7329]
===
match
---
argument [13213,13241]
argument [13213,13241]
===
match
---
suite [4694,4868]
suite [4694,4868]
===
match
---
operator: , [4116,4117]
operator: , [4116,4117]
===
match
---
name: dag [5756,5759]
name: dag [5756,5759]
===
match
---
expr_stmt [7192,7247]
expr_stmt [7192,7247]
===
match
---
name: Optional [922,930]
name: Optional [922,930]
===
match
---
atom_expr [4776,4787]
atom_expr [4776,4787]
===
match
---
name: conf [4320,4324]
name: conf [4320,4324]
===
match
---
name: get_dagmodel [5771,5783]
name: get_dagmodel [5771,5783]
===
match
---
not_test [2798,2826]
not_test [2798,2826]
===
match
---
and_test [7952,7970]
and_test [7952,7970]
===
match
---
operator: , [1398,1399]
operator: , [1398,1399]
===
match
---
name: isoformat [9423,9432]
name: isoformat [9423,9432]
===
match
---
name: pipe [6606,6610]
name: pipe [6606,6610]
===
match
---
simple_stmt [6159,6180]
simple_stmt [6159,6180]
===
match
---
trailer [12576,12586]
trailer [12576,12586]
===
match
---
name: message [4859,4866]
name: message [4859,4866]
===
match
---
operator: = [13648,13649]
operator: = [13648,13649]
===
match
---
name: signal [2008,2014]
name: signal [2008,2014]
===
match
---
fstring_start: f" [10921,10923]
fstring_start: f" [10921,10923]
===
match
---
name: end_date [3853,3861]
name: end_date [3853,3861]
===
match
---
operator: , [12969,12970]
operator: , [12969,12970]
===
match
---
atom_expr [14003,14010]
atom_expr [14003,14010]
===
match
---
name: isoformat [12630,12639]
name: isoformat [12630,12639]
===
match
---
trailer [7835,7840]
trailer [7835,7840]
===
match
---
atom_expr [11855,11866]
atom_expr [11855,11866]
===
match
---
atom_expr [7732,7743]
atom_expr [7732,7743]
===
match
---
trailer [11548,11557]
trailer [11548,11557]
===
match
---
if_stmt [7949,8021]
if_stmt [7949,8021]
===
match
---
operator: , [7170,7171]
operator: , [7170,7171]
===
match
---
atom_expr [12943,12990]
atom_expr [12943,12990]
===
match
---
name: dag_id [11789,11795]
name: dag_id [11789,11795]
===
match
---
trailer [9600,9610]
trailer [9600,9610]
===
match
---
trailer [9838,10117]
trailer [9838,10117]
===
match
---
name: DagBag [10260,10266]
name: DagBag [10260,10266]
===
match
---
string: "paused" [10072,10080]
string: "paused" [10072,10080]
===
match
---
atom_expr [2852,2865]
atom_expr [2852,2865]
===
match
---
string: "Provide a start_date and/or end_date" [2464,2502]
string: "Provide a start_date and/or end_date" [2412,2450]
===
match
---
arglist [12276,12320]
arglist [12276,12320]
===
match
---
trailer [5440,5453]
trailer [5440,5453]
===
match
---
trailer [6821,6828]
trailer [6821,6828]
===
match
---
name: render_dag [6139,6149]
name: render_dag [6139,6149]
===
match
---
name: x [10538,10539]
name: x [10538,10539]
===
match
---
simple_stmt [5389,5417]
simple_stmt [5389,5417]
===
match
---
fstring [2919,3005]
fstring [2919,3005]
===
match
---
name: dr [12645,12647]
name: dr [12645,12647]
===
match
---
operator: = [7271,7272]
operator: = [7271,7272]
===
match
---
operator: == [11116,11118]
operator: == [11116,11118]
===
match
---
simple_stmt [1139,1178]
simple_stmt [1139,1178]
===
match
---
operator: == [13882,13884]
operator: == [13882,13884]
===
match
---
name: dag [9087,9090]
name: dag [9087,9090]
===
match
---
trailer [6714,6719]
trailer [6714,6719]
===
match
---
name: execution_date [13890,13904]
name: execution_date [13890,13904]
===
match
---
simple_stmt [10905,10955]
simple_stmt [10905,10955]
===
match
---
name: max_date_run [8873,8885]
name: max_date_run [8873,8885]
===
match
---
name: errno [6949,6954]
name: errno [6949,6954]
===
match
---
suite [4491,4543]
suite [4491,4543]
===
match
---
with_item [11212,11239]
with_item [11212,11239]
===
match
---
suite [2432,2504]
suite [2380,2452]
===
match
---
try_stmt [4690,4931]
try_stmt [4690,4931]
===
match
---
expr_stmt [5267,5318]
expr_stmt [5267,5318]
===
match
---
name: dot_graph [14191,14200]
name: dot_graph [14191,14200]
===
match
---
testlist_star_expr [7192,7220]
testlist_star_expr [7192,7220]
===
match
---
name: airflow [1496,1503]
name: airflow [1496,1503]
===
match
---
name: task_regex [2769,2779]
name: task_regex [2769,2779]
===
match
---
expr_stmt [9764,9808]
expr_stmt [9764,9808]
===
match
---
argument [9882,9904]
argument [9882,9904]
===
match
---
atom_expr [10282,10293]
atom_expr [10282,10293]
===
match
---
parameters [7161,7186]
parameters [7161,7186]
===
match
---
name: execution_date [13227,13241]
name: execution_date [13227,13241]
===
match
---
trailer [6991,7105]
trailer [6991,7105]
===
match
---
atom_expr [9362,9373]
atom_expr [9362,9373]
===
match
---
name: args [2604,2608]
name: args [2604,2608]
===
match
---
name: restricted [9546,9556]
name: restricted [9546,9556]
===
match
---
trailer [2628,2639]
trailer [2628,2639]
===
match
---
trailer [10316,10325]
trailer [10316,10325]
===
match
---
atom_expr [6949,6961]
atom_expr [6949,6961]
===
match
---
name: conf [1173,1177]
name: conf [1173,1177]
===
match
---
name: settings [1968,1976]
name: settings [1968,1976]
===
match
---
name: str [13559,13562]
name: str [13559,13562]
===
match
---
if_stmt [13671,14209]
if_stmt [13671,14209]
===
match
---
name: sigint_handler [2031,2045]
name: sigint_handler [2031,2045]
===
match
---
argument [6674,6696]
argument [6674,6696]
===
match
---
arglist [2096,2222]
arglist [2096,2222]
===
match
---
name: State [1787,1792]
name: State [1787,1792]
===
match
---
atom_expr [6753,6775]
atom_expr [6753,6775]
===
match
---
name: action_logging [4556,4570]
name: action_logging [4556,4570]
===
match
---
import_name [845,859]
import_name [845,859]
===
match
---
name: dot_graph [13958,13967]
name: dot_graph [13958,13967]
===
match
---
name: filename [6159,6167]
name: filename [6159,6167]
===
match
---
trailer [8517,8521]
trailer [8517,8521]
===
match
---
name: dry_run [3419,3426]
name: dry_run [3419,3426]
===
match
---
name: queries [10745,10752]
name: queries [10745,10752]
===
match
---
simple_stmt [9394,9436]
simple_stmt [9394,9436]
===
match
---
simple_stmt [833,845]
simple_stmt [833,845]
===
match
---
atom_expr [10082,10099]
atom_expr [10082,10099]
===
match
---
or_test [5102,5234]
or_test [5102,5234]
===
match
---
simple_stmt [2441,2504]
simple_stmt [2389,2452]
===
match
---
name: render [7256,7262]
name: render [7256,7262]
===
match
---
trailer [11463,11488]
trailer [11463,11488]
===
match
---
suite [6418,6460]
suite [6418,6460]
===
match
---
operator: = [8993,8994]
operator: = [8993,8994]
===
match
---
trailer [6197,6204]
trailer [6197,6204]
===
match
---
trailer [3052,3057]
trailer [3052,3057]
===
match
---
name: functions [981,990]
name: functions [981,990]
===
match
---
arglist [9521,9562]
arglist [9521,9562]
===
match
---
name: state [12009,12014]
name: state [12009,12014]
===
match
---
trailer [5217,5219]
trailer [5217,5219]
===
match
---
simple_stmt [5267,5319]
simple_stmt [5267,5319]
===
match
---
name: warnings [2059,2067]
name: warnings [2059,2067]
===
match
---
import_as_names [1209,1245]
import_as_names [1209,1245]
===
match
---
operator: , [6448,6449]
operator: , [6448,6449]
===
match
---
operator: = [7221,7222]
operator: = [7221,7222]
===
match
---
name: DagBag [11810,11816]
name: DagBag [11810,11816]
===
match
---
trailer [12713,12715]
trailer [12713,12715]
===
match
---
operator: = [13045,13046]
operator: = [13045,13046]
===
match
---
atom_expr [13802,13821]
atom_expr [13802,13821]
===
match
---
name: filename [13639,13647]
name: filename [13639,13647]
===
match
---
name: next_info [9153,9162]
name: next_info [9153,9162]
===
match
---
name: subdir [12963,12969]
name: subdir [12963,12969]
===
match
---
suite [7767,7820]
suite [7767,7820]
===
match
---
if_stmt [10762,10803]
if_stmt [10762,10803]
===
match
---
string: 'utf-8' [6829,6836]
string: 'utf-8' [6829,6836]
===
match
---
name: err [4890,4893]
name: err [4890,4893]
===
match
---
operator: , [10613,10614]
operator: , [10613,10614]
===
match
---
operator: { [11456,11457]
operator: { [11456,11457]
===
match
---
name: airflow [1038,1045]
name: airflow [1038,1045]
===
match
---
simple_stmt [13958,13995]
simple_stmt [13958,13995]
===
match
---
atom_expr [12090,12101]
atom_expr [12090,12101]
===
match
---
dotted_name [1310,1331]
dotted_name [1310,1331]
===
match
---
trailer [11816,11818]
trailer [11816,11818]
===
match
---
operator: , [12588,12589]
operator: , [12588,12589]
===
match
---
name: session [8702,8709]
name: session [8702,8709]
===
match
---
operator: } [3165,3166]
operator: } [3165,3166]
===
match
---
name: local [3938,3943]
name: local [3938,3943]
===
match
---
argument [9546,9562]
argument [9546,9562]
===
match
---
name: AirflowConsole [11532,11546]
name: AirflowConsole [11532,11546]
===
match
---
arglist [13131,13498]
arglist [13131,13498]
===
match
---
simple_stmt [1246,1305]
simple_stmt [1246,1305]
===
match
---
name: print [6532,6537]
name: print [6532,6537]
===
match
---
trailer [2855,2865]
trailer [2855,2865]
===
match
---
arglist [12083,12250]
arglist [12083,12250]
===
match
---
fstring_end: " [10953,10954]
fstring_end: " [10953,10954]
===
match
---
operator: @ [11618,11619]
operator: @ [11618,11619]
===
match
---
name: session [13737,13744]
name: session [13737,13744]
===
match
---
or_test [3975,4035]
or_test [3975,4035]
===
match
---
funcdef [8080,9614]
funcdef [8080,9614]
===
match
---
trailer [9926,9933]
trailer [9926,9933]
===
match
---
string: 'job_type' [11165,11175]
string: 'job_type' [11165,11175]
===
match
---
atom_expr [9521,9544]
atom_expr [9521,9544]
===
match
---
trailer [13936,13938]
trailer [13936,13938]
===
match
---
trailer [3088,3099]
trailer [3088,3099]
===
match
---
operator: , [9544,9545]
operator: , [9544,9545]
===
match
---
try_stmt [5250,5417]
try_stmt [5250,5417]
===
match
---
trailer [8811,8813]
trailer [8811,8813]
===
match
---
parameters [5599,5605]
parameters [5599,5605]
===
match
---
name: execution_date [12292,12306]
name: execution_date [12292,12306]
===
match
---
operator: , [9456,9457]
operator: , [9456,9457]
===
match
---
name: start_date [2399,2409]
name: start_date [2347,2357]
===
match
---
trailer [3112,3120]
trailer [3112,3120]
===
match
---
trailer [12030,12036]
trailer [12030,12036]
===
match
---
trailer [2463,2503]
trailer [2411,2451]
===
match
---
trailer [10782,10789]
trailer [10782,10789]
===
match
---
name: dag_id [10936,10942]
name: dag_id [10936,10942]
===
match
---
decorated [5558,5663]
decorated [5558,5663]
===
match
---
trailer [12694,12703]
trailer [12694,12703]
===
match
---
operator: , [8403,8404]
operator: , [8403,8404]
===
match
---
name: api_client [4713,4723]
name: api_client [4713,4723]
===
match
---
name: ignore_dependencies [2807,2826]
name: ignore_dependencies [2807,2826]
===
match
---
operator: , [13904,13905]
operator: , [13904,13905]
===
match
---
trailer [8528,8543]
trailer [8528,8543]
===
match
---
operator: , [12463,12464]
operator: , [12463,12464]
===
match
---
name: dr [3401,3403]
name: dr [3401,3403]
===
match
---
trailer [4925,4930]
trailer [4925,4930]
===
match
---
atom_expr [11046,11057]
atom_expr [11046,11057]
===
match
---
trailer [4509,4518]
trailer [4509,4518]
===
match
---
simple_stmt [9180,9354]
simple_stmt [9180,9354]
===
match
---
simple_stmt [3770,4459]
simple_stmt [3770,4459]
===
match
---
operator: = [5924,5925]
operator: = [5924,5925]
===
match
---
name: args [13616,13620]
name: args [13616,13620]
===
match
---
atom_expr [13553,13566]
atom_expr [13553,13566]
===
match
---
name: warn [2082,2086]
name: warn [2082,2086]
===
match
---
name: error_message [10905,10918]
name: error_message [10905,10918]
===
match
---
not_test [2390,2409]
not_test [2338,2357]
===
match
---
operator: = [12235,12236]
operator: = [12235,12236]
===
match
---
atom_expr [2369,2380]
atom_expr [2491,2502]
===
match
---
atom_expr [6981,7105]
atom_expr [6981,7105]
===
match
---
name: decode [6822,6828]
name: decode [6822,6828]
===
match
---
name: dags [10596,10600]
name: dags [10596,10600]
===
match
---
trailer [11925,11932]
trailer [11925,11932]
===
match
---
trailer [5649,5662]
trailer [5649,5662]
===
match
---
name: out [6791,6794]
name: out [6791,6794]
===
match
---
operator: = [9331,9332]
operator: = [9331,9332]
===
match
---
name: args [10861,10865]
name: args [10861,10865]
===
match
---
operator: = [11808,11809]
operator: = [11808,11809]
===
match
---
trailer [5914,5935]
trailer [5914,5935]
===
match
---
trailer [6149,6154]
trailer [6149,6154]
===
match
---
string: "Please remove one option to execute the command." [6338,6388]
string: "Please remove one option to execute the command." [6338,6388]
===
match
---
simple_stmt [5822,5892]
simple_stmt [5822,5892]
===
match
---
atom_expr [3416,3428]
atom_expr [3416,3428]
===
match
---
fstring_expr [10930,10943]
fstring_expr [10930,10943]
===
match
---
name: filter [11310,11316]
name: filter [11310,11316]
===
match
---
name: BaseJob [11288,11295]
name: BaseJob [11288,11295]
===
match
---
param [6006,6010]
param [6006,6010]
===
match
---
simple_stmt [2708,2837]
simple_stmt [2708,2837]
===
match
---
name: args [2571,2575]
name: args [2571,2575]
===
match
---
dotted_name [12777,12801]
dotted_name [12777,12801]
===
match
---
operator: = [3589,3590]
operator: = [3589,3590]
===
match
---
name: run_id [4781,4787]
name: run_id [4781,4787]
===
match
---
name: clear [12999,13004]
name: clear [12999,13004]
===
match
---
trailer [10380,10387]
trailer [10380,10387]
===
match
---
operator: = [11258,11259]
operator: = [11258,11259]
===
match
---
name: execution_date [13021,13035]
name: execution_date [13021,13035]
===
match
---
expr_stmt [9488,9563]
expr_stmt [9488,9563]
===
match
---
trailer [3454,3468]
trailer [3454,3468]
===
match
---
atom_expr [3996,4035]
atom_expr [3996,4035]
===
match
---
operator: = [6191,6192]
operator: = [6191,6192]
===
match
---
argument [12217,12249]
argument [12217,12249]
===
match
---
operator: = [11783,11784]
operator: = [11783,11784]
===
match
---
name: data [10335,10339]
name: data [10335,10339]
===
match
---
name: f [11457,11458]
name: f [11457,11458]
===
match
---
trailer [14061,14082]
trailer [14061,14082]
===
match
---
name: action_logging [10131,10145]
name: action_logging [10131,10145]
===
match
---
atom_expr [12145,12161]
atom_expr [12145,12161]
===
match
---
name: airflow [1418,1425]
name: airflow [1418,1425]
===
match
---
name: dag_id [11776,11782]
name: dag_id [11776,11782]
===
match
---
name: NONE [3724,3728]
name: NONE [3724,3728]
===
match
---
atom_expr [2348,2381]
atom_expr [2470,2503]
===
match
---
fstring_string:  not found [11933,11943]
fstring_string:  not found [11933,11943]
===
match
---
atom_expr [11028,11042]
atom_expr [11028,11042]
===
match
---
name: get_dag_by_file_location [7782,7806]
name: get_dag_by_file_location [7782,7806]
===
match
---
trailer [12020,12022]
trailer [12020,12022]
===
match
---
name: stderr [8414,8420]
name: stderr [8414,8420]
===
match
---
name: dag [2852,2855]
name: dag [2852,2855]
===
match
---
name: dag_id [3159,3165]
name: dag_id [3159,3165]
===
match
---
string: "state" [12510,12517]
string: "state" [12510,12517]
===
match
---
operator: } [2968,2969]
operator: } [2968,2969]
===
match
---
name: filename [14073,14081]
name: filename [14073,14081]
===
match
---
operator: = [12315,12316]
operator: = [12315,12316]
===
match
---
name: warnings [2073,2081]
name: warnings [2073,2081]
===
match
---
name: filename [13699,13707]
name: filename [13699,13707]
===
match
---
name: args [3237,3241]
name: args [3237,3241]
===
match
---
operator: , [9880,9881]
operator: , [9880,9881]
===
match
---
string: """     Returns the next execution datetime of a DAG at the command line.     >>> airflow dags next-execution tutorial     2018-08-31 10:38:00     """ [8114,8264]
string: """     Returns the next execution datetime of a DAG at the command line.     >>> airflow dags next-execution tutorial     2018-08-31 10:38:00     """ [8114,8264]
===
match
---
argument [2187,2221]
argument [2187,2221]
===
match
---
operator: = [3932,3933]
operator: = [3932,3933]
===
match
---
atom_expr [7841,7851]
atom_expr [7841,7851]
===
match
---
trailer [13020,13035]
trailer [13020,13035]
===
match
---
trailer [1918,1930]
trailer [1918,1930]
===
match
---
arglist [9087,9144]
arglist [9087,9144]
===
match
---
atom_expr [13970,13994]
atom_expr [13970,13994]
===
match
---
arglist [3357,3374]
arglist [3357,3374]
===
match
---
name: dr [12426,12428]
name: dr [12426,12428]
===
match
---
funcdef [6552,7138]
funcdef [6552,7138]
===
match
---
name: json [840,844]
name: json [840,844]
===
match
---
decorators [11618,11671]
decorators [11618,11671]
===
match
---
not_test [2848,2865]
not_test [2848,2865]
===
match
---
name: filter [13778,13784]
name: filter [13778,13784]
===
match
---
operator: @ [9616,9617]
operator: @ [9616,9617]
===
match
---
name: dag_id [10783,10789]
name: dag_id [10783,10789]
===
match
---
argument [13169,13199]
argument [13169,13199]
===
match
---
arglist [9199,9343]
arglist [9199,9343]
===
match
---
simple_stmt [9813,10118]
simple_stmt [9813,10118]
===
match
---
comparison [5122,5234]
comparison [5122,5234]
===
match
---
name: ti [3339,3341]
name: ti [3339,3341]
===
match
---
and_test [6213,6232]
and_test [6213,6232]
===
match
---
operator: , [6114,6115]
operator: , [6114,6115]
===
match
---
param [8103,8107]
param [8103,8107]
===
match
---
name: dag_id [5852,5858]
name: dag_id [5852,5858]
===
match
---
import_as_names [1723,1754]
import_as_names [1723,1754]
===
match
---
comparison [10861,10891]
comparison [10861,10891]
===
match
---
trailer [11309,11316]
trailer [11309,11316]
===
match
---
argument [5915,5934]
argument [5915,5934]
===
match
---
name: duration [10470,10478]
name: duration [10470,10478]
===
match
---
name: ignore_first_depends_on_past [2294,2322]
name: ignore_first_depends_on_past [2294,2322]
===
match
---
name: print [5941,5946]
name: print [5941,5946]
===
match
---
parameters [4586,4592]
parameters [4586,4592]
===
match
---
argument [12971,12989]
argument [12971,12989]
===
match
---
operator: @ [10120,10121]
operator: @ [10120,10121]
===
match
---
operator: = [5305,5306]
operator: = [5305,5306]
===
match
---
trailer [13113,13117]
trailer [13113,13117]
===
match
---
atom_expr [9853,9905]
atom_expr [9853,9905]
===
match
---
atom_expr [10570,10602]
atom_expr [10570,10602]
===
match
---
atom_expr [5277,5318]
atom_expr [5277,5318]
===
match
---
name: dr [7914,7916]
name: dr [7914,7916]
===
match
---
atom [11145,11202]
atom [11145,11202]
===
match
---
name: subquery [8626,8634]
name: subquery [8626,8634]
===
match
---
name: subprocess [6704,6714]
name: subprocess [6704,6714]
===
match
---
name: provide_session [1739,1754]
name: provide_session [1739,1754]
===
match
---
atom_expr [8283,8294]
atom_expr [8283,8294]
===
match
---
operator: = [10375,10376]
operator: = [10375,10376]
===
match
---
name: args [7398,7402]
name: args [7398,7402]
===
match
---
argument [6698,6719]
argument [6698,6719]
===
match
---
trailer [11348,11375]
trailer [11348,11375]
===
match
---
atom_expr [3108,3120]
atom_expr [3108,3120]
===
match
---
operator: , [2177,2178]
operator: , [2177,2178]
===
match
---
trailer [2293,2322]
trailer [2293,2322]
===
match
---
name: execution_date [4805,4819]
name: execution_date [4805,4819]
===
match
---
operator: = [9921,9922]
operator: = [9921,9922]
===
match
---
argument [12412,12749]
argument [12412,12749]
===
match
---
expr_stmt [6089,6128]
expr_stmt [6089,6128]
===
match
---
name: run_conf [3067,3075]
name: run_conf [3067,3075]
===
match
---
fstring_string:  on  [3166,3170]
fstring_string:  on  [3166,3170]
===
match
---
name: action_logging [12787,12801]
name: action_logging [12787,12801]
===
match
---
name: subprocess [6681,6691]
name: subprocess [6681,6691]
===
match
---
name: sys [4531,4534]
name: sys [4531,4534]
===
match
---
operator: } [3323,3324]
operator: } [3323,3324]
===
match
---
name: x [12287,12288]
name: x [12287,12288]
===
match
---
name: args [13222,13226]
name: args [13222,13226]
===
match
---
operator: , [3821,3822]
operator: , [3821,3822]
===
match
---
name: airflow [1009,1016]
name: airflow [1009,1016]
===
match
---
string: "Failed to execute. Make sure the imgcat executables are on your systems \'PATH\'" [7009,7091]
string: "Failed to execute. Make sure the imgcat executables are on your systems \'PATH\'" [7009,7091]
===
match
---
name: state [1774,1779]
name: state [1774,1779]
===
match
---
fstring_start: f" [3303,3305]
fstring_start: f" [3303,3305]
===
match
---
simple_stmt [3339,3376]
simple_stmt [3339,3376]
===
match
---
trailer [8413,8420]
trailer [8413,8420]
===
match
---
atom_expr [7782,7819]
atom_expr [7782,7819]
===
match
---
import_name [820,832]
import_name [820,832]
===
match
---
trailer [3723,3728]
trailer [3723,3728]
===
match
---
atom_expr [2624,2639]
atom_expr [2624,2639]
===
match
---
name: delete_dag [5288,5298]
name: delete_dag [5288,5298]
===
match
---
trailer [6817,6838]
trailer [6817,6838]
===
match
---
name: values [9872,9878]
name: values [9872,9878]
===
match
---
expr_stmt [7718,7757]
expr_stmt [7718,7757]
===
match
---
name: DagRun [8522,8528]
name: DagRun [8522,8528]
===
match
---
operator: @ [5456,5457]
operator: @ [5456,5457]
===
match
---
name: utils [1768,1773]
name: utils [1768,1773]
===
match
---
name: stdout [6674,6680]
name: stdout [6674,6680]
===
match
---
or_test [13674,13707]
or_test [13674,13707]
===
match
---
name: provide_session [12760,12775]
name: provide_session [12760,12775]
===
match
---
parameters [6005,6011]
parameters [6005,6011]
===
match
---
argument [13067,13091]
argument [13067,13091]
===
match
---
fstring_start: f" [3136,3138]
fstring_start: f" [3136,3138]
===
match
---
name: dr [3198,3200]
name: dr [3198,3200]
===
match
---
expr_stmt [5756,5796]
expr_stmt [5756,5796]
===
match
---
expr_stmt [2289,2329]
expr_stmt [2289,2329]
===
match
---
raise_stmt [2441,2503]
raise_stmt [2389,2451]
===
match
---
atom_expr [9813,10117]
atom_expr [9813,10117]
===
match
---
atom_expr [5331,5345]
atom_expr [5331,5345]
===
match
---
string: "file" [10428,10434]
string: "file" [10428,10434]
===
match
---
name: args [7868,7872]
name: args [7868,7872]
===
match
---
name: run_conf [4325,4333]
name: run_conf [4325,4333]
===
match
---
argument [11567,11580]
argument [11567,11580]
===
match
---
string: 'donot_pickle' [4020,4034]
string: 'donot_pickle' [4020,4034]
===
match
---
argument [4789,4803]
argument [4789,4803]
===
match
---
import_from [1689,1754]
import_from [1689,1754]
===
match
---
expr_stmt [7776,7819]
expr_stmt [7776,7819]
===
match
---
name: create_session [11212,11226]
name: create_session [11212,11226]
===
match
---
name: get_dag [6095,6102]
name: get_dag [6095,6102]
===
match
---
atom_expr [9922,9933]
atom_expr [9922,9933]
===
match
---
arglist [8744,8822]
arglist [8744,8822]
===
match
---
param [12821,12833]
param [12821,12833]
===
match
---
strings [9199,9313]
strings [9199,9313]
===
match
---
name: dag_id [8591,8597]
name: dag_id [8591,8597]
===
match
---
simple_stmt [8655,8861]
simple_stmt [8655,8861]
===
match
---
name: format [6611,6617]
name: format [6611,6617]
===
match
---
name: include_subdags [3666,3681]
name: include_subdags [3666,3681]
===
match
---
name: mapper [9943,9949]
name: mapper [9943,9949]
===
match
---
atom_expr [6704,6719]
atom_expr [6704,6719]
===
match
---
trailer [6107,6114]
trailer [6107,6114]
===
match
---
argument [12111,12122]
argument [12111,12122]
===
match
---
expr_stmt [6595,6624]
expr_stmt [6595,6624]
===
match
---
except_clause [4467,4490]
except_clause [4467,4490]
===
match
---
simple_stmt [3416,3429]
simple_stmt [3416,3429]
===
match
---
simple_stmt [10831,10849]
simple_stmt [10831,10849]
===
match
---
name: dag_id [12457,12463]
name: dag_id [12457,12463]
===
match
---
operator: @ [5558,5559]
operator: @ [5558,5559]
===
match
---
operator: = [4324,4325]
operator: = [4324,4325]
===
match
---
funcdef [4959,5454]
funcdef [4959,5454]
===
match
---
operator: = [7722,7723]
operator: = [7722,7723]
===
match
---
name: delay_on_limit_secs [4225,4244]
name: delay_on_limit_secs [4225,4244]
===
match
---
if_stmt [11755,11796]
if_stmt [11755,11796]
===
match
---
atom_expr [13650,13666]
atom_expr [13650,13666]
===
match
---
expr_stmt [3198,3253]
expr_stmt [3198,3253]
===
match
---
funcdef [10676,11616]
funcdef [10676,11616]
===
match
---
parameters [10693,10709]
parameters [10693,10709]
===
match
---
atom_expr [1937,1959]
atom_expr [1937,1959]
===
match
---
fstring_string: Task  [3305,3310]
fstring_string: Task  [3305,3310]
===
match
---
name: state [11124,11129]
name: state [11124,11129]
===
match
---
argument [8989,9004]
argument [8989,9004]
===
match
---
name: e [6924,6925]
name: e [6924,6925]
===
match
---
name: all_jobs [11517,11525]
name: all_jobs [11517,11525]
===
match
---
name: task_id [3316,3323]
name: task_id [3316,3323]
===
match
---
name: api_client [4648,4658]
name: api_client [4648,4658]
===
match
---
atom_expr [13825,13836]
atom_expr [13825,13836]
===
match
---
import_from [1178,1245]
import_from [1178,1245]
===
match
---
atom_expr [2642,2657]
atom_expr [2642,2657]
===
match
---
operator: @ [10146,10147]
operator: @ [10146,10147]
===
match
---
expr_stmt [3339,3375]
expr_stmt [3339,3375]
===
match
---
operator: , [3563,3564]
operator: , [3563,3564]
===
match
---
expr_stmt [10251,10295]
expr_stmt [10251,10295]
===
match
---
atom_expr [4504,4518]
atom_expr [4504,4518]
===
match
---
operator: = [4755,4756]
operator: = [4755,4756]
===
match
---
expr_stmt [13572,13602]
expr_stmt [13572,13602]
===
match
---
name: out [6742,6745]
name: out [6742,6745]
===
match
---
name: args [3640,3644]
name: args [3640,3644]
===
match
---
trailer [6541,6548]
trailer [6541,6548]
===
match
---
name: args [4151,4155]
name: args [4151,4155]
===
match
---
fstring_start: f" [2919,2921]
fstring_start: f" [2919,2921]
===
match
---
name: dag_id [12083,12089]
name: dag_id [12083,12089]
===
match
---
simple_stmt [932,961]
simple_stmt [932,961]
===
match
---
name: sort [12271,12275]
name: sort [12271,12275]
===
match
---
operator: , [10110,10111]
operator: , [10110,10111]
===
match
---
comp_op [10873,10879]
comp_op [10873,10879]
===
match
---
number: 1 [9455,9456]
number: 1 [9455,9456]
===
match
---
operator: = [10258,10259]
operator: = [10258,10259]
===
match
---
trailer [9086,9145]
trailer [9086,9145]
===
match
---
atom_expr [10300,10620]
atom_expr [10300,10620]
===
match
---
if_stmt [10858,11005]
if_stmt [10858,11005]
===
match
---
param [5694,5698]
param [5694,5698]
===
match
---
expr_stmt [11996,12046]
expr_stmt [11996,12046]
===
match
---
name: dag [9066,9069]
name: dag [9066,9069]
===
match
---
trailer [8320,8334]
trailer [8320,8334]
===
match
---
name: sys [9332,9335]
name: sys [9332,9335]
===
match
---
suite [11078,11131]
suite [11078,11131]
===
match
---
expr_stmt [11249,11435]
expr_stmt [11249,11435]
===
match
---
trailer [8300,8307]
trailer [8300,8307]
===
match
---
name: tis [13986,13989]
name: tis [13986,13989]
===
match
---
simple_stmt [1639,1689]
simple_stmt [1639,1689]
===
match
---
name: sqlalchemy [966,976]
name: sqlalchemy [966,976]
===
match
---
trailer [9185,9353]
trailer [9185,9353]
===
match
---
suite [11709,12757]
suite [11709,12757]
===
match
---
name: get_current_api_client [5060,5082]
name: get_current_api_client [5060,5082]
===
match
---
name: ignore_first_depends_on_past [2242,2270]
name: ignore_first_depends_on_past [2242,2270]
===
match
---
name: dag [12995,12998]
name: dag [12995,12998]
===
match
---
param [5683,5693]
param [5683,5693]
===
match
---
trailer [8583,8612]
trailer [8583,8612]
===
match
---
trailer [10846,10848]
trailer [10846,10848]
===
match
---
name: utils [1504,1509]
name: utils [1504,1509]
===
match
---
trailer [12275,12321]
trailer [12275,12321]
===
match
---
argument [7853,7887]
argument [7853,7887]
===
match
---
operator: + [7996,7997]
operator: + [7996,7997]
===
match
---
operator: { [3153,3154]
operator: { [3153,3154]
===
match
---
name: output [11602,11608]
name: output [11602,11608]
===
match
---
suite [3058,3100]
suite [3058,3100]
===
match
---
name: state [12031,12036]
name: state [12031,12036]
===
match
---
atom_expr [10538,10548]
atom_expr [10538,10548]
===
match
---
operator: = [7989,7990]
operator: = [7989,7990]
===
match
---
operator: , [13984,13985]
operator: , [13984,13985]
===
match
---
trailer [6880,6901]
trailer [6880,6901]
===
match
---
name: args [3154,3158]
name: args [3154,3158]
===
match
---
tfpdef [7162,7170]
tfpdef [7162,7170]
===
match
---
atom_expr [12290,12306]
atom_expr [12290,12306]
===
match
---
atom_expr [11959,11990]
atom_expr [11959,11990]
===
match
---
arglist [7263,7318]
arglist [7263,7318]
===
match
---
simple_stmt [7893,7927]
simple_stmt [7893,7927]
===
match
---
name: args [2356,2360]
name: args [2478,2482]
===
match
---
operator: = [9885,9886]
operator: = [9885,9886]
===
match
---
trailer [10865,10872]
trailer [10865,10872]
===
match
---
name: dag_unpause [5588,5599]
name: dag_unpause [5588,5599]
===
match
---
trailer [9587,9600]
trailer [9587,9600]
===
match
---
trailer [12489,12496]
trailer [12489,12496]
===
match
---
operator: , [4302,4303]
operator: , [4302,4303]
===
match
---
with_stmt [6642,6902]
with_stmt [6642,6902]
===
match
---
import_as_names [1527,1636]
import_as_names [1527,1636]
===
match
---
atom [11456,11505]
atom [11456,11505]
===
match
---
name: args [10778,10782]
name: args [10778,10782]
===
match
---
atom_expr [8994,9004]
atom_expr [8994,9004]
===
match
---
trailer [10083,10097]
trailer [10083,10097]
===
match
---
atom_expr [10260,10295]
atom_expr [10260,10295]
===
match
---
trailer [13558,13566]
trailer [13558,13566]
===
match
---
name: next_info [9578,9587]
name: next_info [9578,9587]
===
match
---
operator: , [10058,10059]
operator: , [10058,10059]
===
match
---
name: suppress_logs_and_warning [9643,9668]
name: suppress_logs_and_warning [9643,9668]
===
match
---
name: start_date [3176,3186]
name: start_date [3176,3186]
===
match
---
argument [4225,4264]
argument [4225,4264]
===
match
---
atom_expr [10840,10848]
atom_expr [10840,10848]
===
match
---
trailer [8848,8850]
trailer [8848,8850]
===
match
---
trailer [6954,6961]
trailer [6954,6961]
===
match
---
trailer [11094,11101]
trailer [11094,11101]
===
match
---
simple_stmt [6595,6625]
simple_stmt [6595,6625]
===
match
---
atom_expr [5762,5796]
atom_expr [5762,5796]
===
match
---
operator: = [13721,13722]
operator: = [13721,13722]
===
match
---
operator: , [7304,7305]
operator: , [7304,7305]
===
match
---
name: args [2642,2646]
name: args [2642,2646]
===
match
---
simple_stmt [7192,7248]
simple_stmt [7192,7248]
===
match
---
name: file [8405,8409]
name: file [8405,8409]
===
match
---
name: dag_runs [12366,12374]
name: dag_runs [12366,12374]
===
match
---
parameters [4973,4979]
parameters [4973,4979]
===
match
---
simple_stmt [4598,4644]
simple_stmt [4598,4644]
===
match
---
atom_expr [4151,4175]
atom_expr [4151,4175]
===
match
---
name: args [13825,13829]
name: args [13825,13829]
===
match
---
name: is_paused [5915,5924]
name: is_paused [5915,5924]
===
match
---
name: args [3171,3175]
name: args [3171,3175]
===
match
---
name: OSError [4879,4886]
name: OSError [4879,4886]
===
match
---
name: mark_success [3897,3909]
name: mark_success [3897,3909]
===
match
---
name: utils [1461,1466]
name: utils [1461,1466]
===
match
---
trailer [13004,13092]
trailer [13004,13092]
===
match
---
strings [6272,6388]
strings [6272,6388]
===
match
---
atom_expr [11874,11885]
atom_expr [11874,11885]
===
match
---
name: dag_report [10177,10187]
name: dag_report [10177,10187]
===
match
---
name: executors [1259,1268]
name: executors [1259,1268]
===
match
---
operator: = [11909,11910]
operator: = [11909,11910]
===
match
---
trailer [7231,7242]
trailer [7231,7242]
===
match
---
trailer [5770,5783]
trailer [5770,5783]
===
match
---
name: func [998,1002]
name: func [998,1002]
===
match
---
if_stmt [3447,3744]
if_stmt [3447,3744]
===
match
---
trailer [12639,12641]
trailer [12639,12641]
===
match
---
name: lower [12015,12020]
name: lower [12015,12020]
===
match
---
simple_stmt [4531,4543]
simple_stmt [4531,4543]
===
match
---
atom_expr [6139,6154]
atom_expr [6139,6154]
===
match
---
import_name [2052,2067]
import_name [2052,2067]
===
match
---
name: args [4776,4780]
name: args [4776,4780]
===
match
---
name: args [12391,12395]
name: args [12391,12395]
===
match
---
name: data [9848,9852]
name: data [9848,9852]
===
match
---
name: x [10411,10412]
name: x [10411,10412]
===
match
---
trailer [8709,8715]
trailer [8709,8715]
===
match
---
name: dag_id [10815,10821]
name: dag_id [10815,10821]
===
match
---
fstring [11911,11944]
fstring [11911,11944]
===
match
---
atom_expr [8009,8019]
atom_expr [8009,8019]
===
match
---
name: all_jobs [11249,11257]
name: all_jobs [11249,11257]
===
match
---
operator: , [7851,7852]
operator: , [7851,7852]
===
match
---
operator: , [11580,11581]
operator: , [11580,11581]
===
match
---
trailer [2806,2826]
trailer [2806,2826]
===
match
---
suite [5606,5663]
suite [5606,5663]
===
match
---
name: mapper [12412,12418]
name: mapper [12412,12418]
===
match
---
name: process_subdir [1570,1584]
name: process_subdir [1570,1584]
===
match
---
trailer [9090,9112]
trailer [9090,9112]
===
match
---
simple_stmt [11714,11751]
simple_stmt [11714,11751]
===
match
---
and_test [11827,11885]
and_test [11827,11885]
===
match
---
name: filename [7172,7180]
name: filename [7172,7180]
===
match
---
name: dag [5897,5900]
name: dag [5897,5900]
===
match
---
dotted_name [1496,1513]
dotted_name [1496,1513]
===
match
---
import_from [961,1002]
import_from [961,1002]
===
match
---
atom_expr [13140,13155]
atom_expr [13140,13155]
===
match
---
name: imgcat [6198,6204]
name: imgcat [6198,6204]
===
match
---
trailer [5959,5966]
trailer [5959,5966]
===
match
---
trailer [13932,13936]
trailer [13932,13936]
===
match
---
name: error_message [11976,11989]
name: error_message [11976,11989]
===
match
---
not_test [2414,2431]
not_test [2362,2379]
===
match
---
import_from [1413,1447]
import_from [1413,1447]
===
match
---
name: start_date [12619,12629]
name: start_date [12619,12629]
===
match
---
name: _ [7214,7215]
name: _ [7214,7215]
===
match
---
simple_stmt [6184,6205]
simple_stmt [6184,6205]
===
match
---
simple_stmt [1448,1491]
simple_stmt [1448,1491]
===
match
---
suite [2699,3020]
suite [2699,3020]
===
match
---
name: start_date [3553,3563]
name: start_date [3553,3563]
===
match
---
name: jobs [1318,1322]
name: jobs [1318,1322]
===
match
---
operator: = [11571,11572]
operator: = [11571,11572]
===
match
---
name: sorted [9853,9859]
name: sorted [9853,9859]
===
match
---
name: vr [4514,4516]
name: vr [4514,4516]
===
match
---
atom_expr [5897,5935]
atom_expr [5897,5935]
===
match
---
name: dagbag [10340,10346]
name: dagbag [10340,10346]
===
match
---
name: DagBag [10840,10846]
name: DagBag [10840,10846]
===
match
---
name: err [6854,6857]
name: err [6854,6857]
===
match
---
simple_stmt [1305,1347]
simple_stmt [1305,1347]
===
match
---
operator: , [4767,4768]
operator: , [4767,4768]
===
match
---
atom [8485,8646]
atom [8485,8646]
===
match
---
trailer [9367,9373]
trailer [9367,9373]
===
match
---
operator: = [4793,4794]
operator: = [4793,4794]
===
match
---
operator: = [11453,11454]
operator: = [11453,11454]
===
match
---
name: f [11493,11494]
name: f [11493,11494]
===
match
---
name: args [13180,13184]
name: args [13180,13184]
===
match
---
suite [3121,3429]
suite [3121,3429]
===
match
---
try_stmt [13097,13567]
try_stmt [13097,13567]
===
match
---
comparison [8744,8771]
comparison [8744,8771]
===
match
---
trailer [10019,10028]
trailer [10019,10028]
===
match
---
atom_expr [4661,4685]
atom_expr [4661,4685]
===
match
---
trailer [11372,11374]
trailer [11372,11374]
===
match
---
name: dag_id [12983,12989]
name: dag_id [12983,12989]
===
match
---
operator: , [3686,3687]
operator: , [3686,3687]
===
match
---
name: args [3048,3052]
name: args [3048,3052]
===
match
---
name: args [4425,4429]
name: args [4425,4429]
===
match
---
name: dag [10792,10795]
name: dag [10792,10795]
===
match
---
expr_stmt [6159,6179]
expr_stmt [6159,6179]
===
match
---
name: BackfillUnfinished [1227,1245]
name: BackfillUnfinished [1227,1245]
===
match
---
operator: } [7346,7347]
operator: } [7346,7347]
===
match
---
fstring_string: , paused:  [5967,5977]
fstring_string: , paused:  [5967,5977]
===
match
---
argument [7294,7304]
argument [7294,7304]
===
match
---
name: dagbag [11874,11880]
name: dagbag [11874,11880]
===
match
---
atom_expr [7807,7818]
atom_expr [7807,7818]
===
match
---
comparison [9153,9170]
comparison [9153,9170]
===
match
---
operator: = [6617,6618]
operator: = [6617,6618]
===
match
---
atom_expr [4510,4517]
atom_expr [4510,4517]
===
match
---
name: dag [3770,3773]
name: dag [3770,3773]
===
match
---
atom_expr [13081,13091]
atom_expr [13081,13091]
===
match
---
operator: @ [11644,11645]
operator: @ [11644,11645]
===
match
---
operator: , [6672,6673]
operator: , [6672,6673]
===
match
---
trailer [3418,3426]
trailer [3418,3426]
===
match
---
string: 'png' [6618,6623]
string: 'png' [6618,6623]
===
match
---
atom_expr [6938,6945]
atom_expr [6938,6945]
===
match
---
name: dr [7960,7962]
name: dr [7960,7962]
===
match
---
trailer [8011,8014]
trailer [8011,8014]
===
match
---
name: args [11119,11123]
name: args [11119,11123]
===
match
---
name: dag_id [12971,12977]
name: dag_id [12971,12977]
===
match
---
atom_expr [8601,8611]
atom_expr [8601,8611]
===
match
---
name: _ [9444,9445]
name: _ [9444,9445]
===
match
---
trailer [7806,7819]
trailer [7806,7819]
===
match
---
simple_stmt [1178,1246]
simple_stmt [1178,1246]
===
match
---
atom_expr [4083,4116]
atom_expr [4083,4116]
===
match
---
name: args [6006,6010]
name: args [6006,6010]
===
match
---
trailer [7329,7355]
trailer [7329,7355]
===
match
---
operator: , [12374,12375]
operator: , [12374,12375]
===
match
---
dotted_name [11619,11643]
dotted_name [11619,11643]
===
match
---
string: '--ignore-first-depends-on-past is deprecated as the value is always set to True' [2096,2177]
string: '--ignore-first-depends-on-past is deprecated as the value is always set to True' [2096,2177]
===
match
---
trailer [7255,7262]
trailer [7255,7262]
===
match
---
operator: = [12089,12090]
operator: = [12089,12090]
===
match
---
trailer [5851,5858]
trailer [5851,5858]
===
match
---
fstring_expr [3153,3166]
fstring_expr [3153,3166]
===
match
---
name: filename [6213,6221]
name: filename [6213,6221]
===
match
---
name: dot [6538,6541]
name: dot [6538,6541]
===
match
---
name: subdir [2361,2367]
name: subdir [2483,2489]
===
match
---
name: print_as [10317,10325]
name: print_as [10317,10325]
===
match
---
atom_expr [6170,6179]
atom_expr [6170,6179]
===
match
---
trailer [8634,8636]
trailer [8634,8636]
===
match
---
atom_expr [9984,9992]
atom_expr [9984,9992]
===
match
---
atom_expr [3210,3220]
atom_expr [3210,3220]
===
match
---
operator: , [9342,9343]
operator: , [9342,9343]
===
match
---
testlist_star_expr [6742,6750]
testlist_star_expr [6742,6750]
===
match
---
name: output [9927,9933]
name: output [9927,9933]
===
match
---
name: executor [13131,13139]
name: executor [13131,13139]
===
match
---
name: args [12090,12094]
name: args [12090,12094]
===
match
---
lambdef [12280,12306]
lambdef [12280,12306]
===
match
---
name: dag_id [5311,5317]
name: dag_id [5311,5317]
===
match
---
name: confirm_prompt [3621,3635]
name: confirm_prompt [3621,3635]
===
match
---
argument [9915,9933]
argument [9915,9933]
===
match
---
trailer [12998,13004]
trailer [12998,13004]
===
match
---
simple_stmt [11996,12047]
simple_stmt [11996,12047]
===
match
---
number: 0 [7902,7903]
number: 0 [7902,7903]
===
match
---
trailer [12149,12161]
trailer [12149,12161]
===
match
---
string: "task_num" [10526,10536]
string: "task_num" [10526,10536]
===
match
---
arglist [7732,7756]
arglist [7732,7756]
===
match
---
dotted_name [4546,4570]
dotted_name [4546,4570]
===
match
---
name: args [2764,2768]
name: args [2764,2768]
===
match
---
atom_expr [3806,3821]
atom_expr [3806,3821]
===
match
---
operator: = [9064,9065]
operator: = [9064,9065]
===
match
---
trailer [12014,12020]
trailer [12014,12020]
===
match
---
argument [12083,12101]
argument [12083,12101]
===
match
---
trailer [11281,11287]
trailer [11281,11287]
===
match
---
name: one_or_none [8837,8848]
name: one_or_none [8837,8848]
===
match
---
name: DebugExecutor [13140,13153]
name: DebugExecutor [13140,13153]
===
match
---
name: dr [12454,12456]
name: dr [12454,12456]
===
match
---
atom_expr [12645,12658]
atom_expr [12645,12658]
===
match
---
name: e [13563,13564]
name: e [13563,13564]
===
match
---
operator: = [4424,4425]
operator: = [4424,4425]
===
match
---
simple_stmt [10967,11005]
simple_stmt [10967,11005]
===
match
---
name: session [8452,8459]
name: session [8452,8459]
===
match
---
operator: , [11163,11164]
operator: , [11163,11164]
===
match
---
simple_stmt [7931,7945]
simple_stmt [7931,7945]
===
match
---
name: debug_executor [1269,1283]
name: debug_executor [1269,1283]
===
match
---
test [7899,7926]
test [7899,7926]
===
match
---
operator: , [7212,7213]
operator: , [7212,7213]
===
match
---
trailer [8625,8634]
trailer [8625,8634]
===
match
---
name: max_date_run [8655,8667]
name: max_date_run [8655,8667]
===
match
---
lambdef [9886,9904]
lambdef [9886,9904]
===
match
---
name: dag_id [2374,2380]
name: dag_id [2496,2502]
===
match
---
simple_stmt [6017,6085]
simple_stmt [6017,6085]
===
match
---
suite [5426,5454]
suite [5426,5454]
===
match
---
simple_stmt [6742,6776]
simple_stmt [6742,6776]
===
match
---
suite [1854,4543]
suite [1854,4543]
===
match
---
operator: = [13179,13180]
operator: = [13179,13180]
===
match
---
name: args [4974,4978]
name: args [4974,4978]
===
match
---
trailer [9871,9878]
trailer [9871,9878]
===
match
---
name: args [12192,12196]
name: args [12192,12196]
===
match
---
operator: , [12402,12403]
operator: , [12402,12403]
===
match
---
name: find [12069,12073]
name: find [12069,12073]
===
match
---
atom_expr [5395,5416]
atom_expr [5395,5416]
===
match
---
arglist [3514,3729]
arglist [3514,3729]
===
match
---
operator: = [3635,3636]
operator: = [3635,3636]
===
match
---
name: x [10082,10083]
name: x [10082,10083]
===
match
---
name: dag_id [5789,5795]
name: dag_id [5789,5795]
===
match
---
simple_stmt [874,892]
simple_stmt [874,892]
===
match
---
name: x [10594,10595]
name: x [10594,10595]
===
match
---
name: PIPE [6715,6719]
name: PIPE [6715,6719]
===
match
---
atom_expr [10267,10294]
atom_expr [10267,10294]
===
match
---
name: print [6812,6817]
name: print [6812,6817]
===
match
---
name: dag [13981,13984]
name: dag [13981,13984]
===
match
---
operator: } [11504,11505]
operator: } [11504,11505]
===
match
---
atom_expr [14114,14148]
atom_expr [14114,14148]
===
match
---
string: "Option --save and --imgcat are mutually exclusive. " [6272,6325]
string: "Option --save and --imgcat are mutually exclusive. " [6272,6325]
===
match
---
arglist [9848,10111]
arglist [9848,10111]
===
match
---
trailer [3390,3398]
trailer [3390,3398]
===
match
---
string: '.' [7243,7246]
string: '.' [7243,7246]
===
match
---
arglist [2746,2826]
arglist [2746,2826]
===
match
---
operator: , [12207,12208]
operator: , [12207,12208]
===
match
---
dictorsetmaker [10428,10603]
dictorsetmaker [10428,10603]
===
match
---
simple_stmt [9054,9146]
simple_stmt [9054,9146]
===
match
---
name: BaseJob [11102,11109]
name: BaseJob [11102,11109]
===
match
---
name: isoformat [9601,9610]
name: isoformat [9601,9610]
===
match
---
name: mark_success [3879,3891]
name: mark_success [3879,3891]
===
match
---
name: logical_date [9410,9422]
name: logical_date [9410,9422]
===
match
---
simple_stmt [8346,8422]
simple_stmt [8346,8422]
===
match
---
suite [4894,4931]
suite [4894,4931]
===
match
---
operator: @ [9642,9643]
operator: @ [9642,9643]
===
match
---
name: get_dag [12943,12950]
name: get_dag [12943,12950]
===
match
---
fstring_end: " [7353,7354]
fstring_end: " [7353,7354]
===
match
---
name: execution_end_date [12217,12235]
name: execution_end_date [12217,12235]
===
match
---
name: end_date [12241,12249]
name: end_date [12241,12249]
===
match
---
simple_stmt [7824,7889]
simple_stmt [7824,7889]
===
match
---
simple_stmt [6427,6460]
simple_stmt [6427,6460]
===
match
---
atom_expr [9572,9613]
atom_expr [9572,9613]
===
match
---
atom_expr [7324,7355]
atom_expr [7324,7355]
===
match
---
trailer [12340,12342]
trailer [12340,12342]
===
match
---
name: suppress_logs_and_warning [1610,1635]
name: suppress_logs_and_warning [1610,1635]
===
match
---
decorated [12759,14209]
decorated [12759,14209]
===
match
---
trailer [9462,9477]
trailer [9462,9477]
===
match
---
name: x [10018,10019]
name: x [10018,10019]
===
match
---
trailer [5788,5795]
trailer [5788,5795]
===
match
---
name: sigint_handler [1590,1604]
name: sigint_handler [1590,1604]
===
match
---
string: "filepath" [10006,10016]
string: "filepath" [10006,10016]
===
match
---
suite [8109,9614]
suite [8109,9614]
===
match
---
name: args [10931,10935]
name: args [10931,10935]
===
match
---
operator: , [4803,4804]
operator: , [4803,4804]
===
match
---
name: print [9018,9023]
name: print [9018,9023]
===
match
---
name: d [9896,9897]
name: d [9896,9897]
===
match
---
trailer [12982,12989]
trailer [12982,12989]
===
match
---
name: args [1838,1842]
name: args [1838,1842]
===
match
---
suite [7187,7356]
suite [7187,7356]
===
match
---
expr_stmt [2708,2836]
expr_stmt [2708,2836]
===
match
---
name: execution_date [7853,7867]
name: execution_date [7853,7867]
===
match
---
trailer [8002,8008]
trailer [8002,8008]
===
match
---
param [1838,1843]
param [1838,1843]
===
match
---
dotted_name [10121,10145]
dotted_name [10121,10145]
===
match
---
name: delay_on_limit [4250,4264]
name: delay_on_limit [4250,4264]
===
match
---
name: start_date [11357,11367]
name: start_date [11357,11367]
===
match
---
atom_expr [3344,3375]
atom_expr [3344,3375]
===
match
---
argument [4134,4175]
argument [4134,4175]
===
match
---
name: upper [5212,5217]
name: upper [5212,5217]
===
match
---
decorated [9616,10118]
decorated [9616,10118]
===
match
---
name: dagbag [10831,10837]
name: dagbag [10831,10837]
===
match
---
atom_expr [13586,13602]
atom_expr [13586,13602]
===
match
---
name: print [9362,9367]
name: print [9362,9367]
===
match
---
atom_expr [4756,4767]
atom_expr [4756,4767]
===
match
---
argument [13475,13497]
argument [13475,13497]
===
match
---
operator: = [12144,12145]
operator: = [12144,12145]
===
match
---
operator: { [5954,5955]
operator: { [5954,5955]
===
match
---
funcdef [12802,14209]
funcdef [12802,14209]
===
match
---
simple_stmt [11771,11796]
simple_stmt [11771,11796]
===
match
---
name: is_paused [5978,5987]
name: is_paused [5978,5987]
===
match
---
name: dot [6133,6136]
name: dot [6133,6136]
===
match
---
trailer [3315,3323]
trailer [3315,3323]
===
match
---
simple_stmt [12051,12257]
simple_stmt [12051,12257]
===
match
---
sync_comp_for [11489,11504]
sync_comp_for [11489,11504]
===
match
---
name: args [4820,4824]
name: args [4820,4824]
===
match
---
fstring_start: f" [11911,11913]
fstring_start: f" [11911,11913]
===
match
---
param [9893,9894]
param [9893,9894]
===
match
---
operator: = [10703,10704]
operator: = [10703,10704]
===
match
---
name: run_backwards [4411,4424]
name: run_backwards [4411,4424]
===
match
---
operator: , [12738,12739]
operator: , [12738,12739]
===
match
---
arglist [10335,10614]
arglist [10335,10614]
===
match
---
trailer [7701,7708]
trailer [7701,7708]
===
match
---
suite [10822,11059]
suite [10822,11059]
===
match
---
name: error_message [10990,11003]
name: error_message [10990,11003]
===
match
---
operator: , [5548,5549]
operator: , [5548,5549]
===
match
---
atom_expr [2289,2322]
atom_expr [2289,2322]
===
match
---
name: dag_id [4761,4767]
name: dag_id [4761,4767]
===
match
---
except_clause [5354,5375]
except_clause [5354,5375]
===
match
---
name: execution_date [8529,8543]
name: execution_date [8529,8543]
===
match
---
suite [9693,10118]
suite [9693,10118]
===
match
---
string: "Cancelled" [5441,5452]
string: "Cancelled" [5441,5452]
===
match
---
name: data [12361,12365]
name: data [12361,12365]
===
match
---
fstring [10921,10954]
fstring [10921,10954]
===
match
---
trailer [12950,12990]
trailer [12950,12990]
===
match
---
name: json [3078,3082]
name: json [3078,3082]
===
match
---
name: subdir [8288,8294]
name: subdir [8288,8294]
===
match
---
trailer [8590,8597]
trailer [8590,8597]
===
match
---
name: end_date [3581,3589]
name: end_date [3581,3589]
===
match
---
name: f [11485,11486]
name: f [11485,11486]
===
match
---
dotted_name [1144,1165]
dotted_name [1144,1165]
===
match
---
name: dag_id [8751,8757]
name: dag_id [8751,8757]
===
match
---
name: dag_id [10866,10872]
name: dag_id [10866,10872]
===
match
---
simple_stmt [11444,11527]
simple_stmt [11444,11527]
===
match
---
name: query [13745,13750]
name: query [13745,13750]
===
match
---
name: end_date [12722,12730]
name: end_date [12722,12730]
===
match
---
name: dags [10887,10891]
name: dags [10887,10891]
===
match
---
name: err [4926,4929]
name: err [4926,4929]
===
match
---
atom_expr [12192,12207]
atom_expr [12192,12207]
===
match
---
atom [5092,5240]
atom [5092,5240]
===
match
---
name: rpartition [7232,7242]
name: rpartition [7232,7242]
===
match
---
name: OSError [6913,6920]
name: OSError [6913,6920]
===
match
---
name: args [2624,2628]
name: args [2624,2628]
===
match
---
name: action_logging [5569,5583]
name: action_logging [5569,5583]
===
match
---
atom_expr [3590,3603]
atom_expr [3590,3603]
===
match
---
operator: = [10919,10920]
operator: = [10919,10920]
===
match
---
trailer [9799,9806]
trailer [9799,9806]
===
match
---
string: 'start_date' [11177,11189]
string: 'start_date' [11177,11189]
===
match
---
name: args [12026,12030]
name: args [12026,12030]
===
match
---
operator: = [7940,7941]
operator: = [7940,7941]
===
match
---
dotted_name [8055,8079]
dotted_name [8055,8079]
===
match
---
name: print [9180,9185]
name: print [9180,9185]
===
match
---
name: mapper [10397,10403]
name: mapper [10397,10403]
===
match
---
atom_expr [8025,8051]
atom_expr [8025,8051]
===
match
---
atom_expr [8275,8308]
atom_expr [8275,8308]
===
match
---
name: donot_pickle [3961,3973]
name: donot_pickle [3961,3973]
===
match
---
atom_expr [11464,11487]
atom_expr [11464,11487]
===
match
---
raise_stmt [2879,3019]
raise_stmt [2879,3019]
===
match
---
name: cli_utils [4546,4555]
name: cli_utils [4546,4555]
===
match
---
arglist [6103,6127]
arglist [6103,6127]
===
match
---
simple_stmt [9572,9614]
simple_stmt [9572,9614]
===
match
---
trailer [8506,8512]
trailer [8506,8512]
===
match
---
trailer [8912,9005]
trailer [8912,9005]
===
match
---
name: output [10381,10387]
name: output [10381,10387]
===
match
---
trailer [9829,9838]
trailer [9829,9838]
===
match
---
simple_stmt [10251,10296]
simple_stmt [10251,10296]
===
match
---
name: x [10468,10469]
name: x [10468,10469]
===
match
---
atom [8688,8860]
atom [8688,8860]
===
match
---
name: filename [7223,7231]
name: filename [7223,7231]
===
match
---
atom_expr [9500,9563]
atom_expr [9500,9563]
===
match
---
param [7172,7185]
param [7172,7185]
===
match
---
simple_stmt [8025,8052]
simple_stmt [8025,8052]
===
match
---
name: args [11855,11859]
name: args [11855,11859]
===
match
---
operator: = [12060,12061]
operator: = [12060,12061]
===
match
---
name: args [11046,11050]
name: args [11046,11050]
===
match
---
operator: { [10414,10415]
operator: { [10414,10415]
===
match
---
trailer [11388,11394]
trailer [11388,11394]
===
match
---
name: verbose [4295,4302]
name: verbose [4295,4302]
===
match
---
name: args [6193,6197]
name: args [6193,6197]
===
match
---
argument [3704,3728]
argument [3704,3728]
===
match
---
trailer [3093,3098]
trailer [3093,3098]
===
match
---
trailer [9859,9905]
trailer [9859,9905]
===
match
---
string: "dags" [10562,10568]
string: "dags" [10562,10568]
===
match
---
atom_expr [3274,3283]
atom_expr [3274,3283]
===
match
---
name: start_date [12648,12658]
name: start_date [12648,12658]
===
match
---
dotted_name [1038,1056]
dotted_name [1038,1056]
===
match
---
name: dag [2708,2711]
name: dag [2708,2711]
===
match
---
name: DagBag [9773,9779]
name: DagBag [9773,9779]
===
match
---
name: args [6116,6120]
name: args [6116,6120]
===
match
---
name: _display_dot_via_imgcat [6485,6508]
name: _display_dot_via_imgcat [6485,6508]
===
match
---
argument [12361,12374]
argument [12361,12374]
===
match
---
trailer [8813,8822]
trailer [8813,8822]
===
match
---
trailer [13226,13241]
trailer [13226,13241]
===
match
---
name: client [1050,1056]
name: client [1050,1056]
===
match
---
simple_stmt [5507,5526]
simple_stmt [5507,5526]
===
match
---
trailer [11831,11838]
trailer [11831,11838]
===
match
---
trailer [5127,5211]
trailer [5127,5211]
===
match
---
operator: = [6703,6704]
operator: = [6703,6704]
===
match
---
trailer [13117,13508]
trailer [13117,13508]
===
match
---
name: args [2661,2665]
name: args [2661,2665]
===
match
---
funcdef [5584,5663]
funcdef [5584,5663]
===
match
---
simple_stmt [5611,5632]
simple_stmt [5611,5632]
===
match
---
simple_stmt [7980,8021]
simple_stmt [7980,8021]
===
match
---
operator: , [10387,10388]
operator: , [10387,10388]
===
match
---
atom [3974,4036]
atom [3974,4036]
===
match
---
if_stmt [6851,6902]
if_stmt [6851,6902]
===
match
---
raise_stmt [11953,11990]
raise_stmt [11953,11990]
===
match
---
atom_expr [5530,5555]
atom_expr [5530,5555]
===
match
---
name: imgcat [14094,14100]
name: imgcat [14094,14100]
===
match
---
trailer [12721,12730]
trailer [12721,12730]
===
match
---
name: State [13081,13086]
name: State [13081,13086]
===
match
---
trailer [11394,11406]
trailer [11394,11406]
===
match
---
trailer [13153,13155]
trailer [13153,13155]
===
match
---
name: dag [3210,3213]
name: dag [3210,3213]
===
match
---
operator: , [12666,12667]
operator: , [12666,12667]
===
match
---
name: session [11232,11239]
name: session [11232,11239]
===
match
---
atom_expr [9458,9477]
atom_expr [9458,9477]
===
match
---
arglist [9860,9904]
arglist [9860,9904]
===
match
---
trailer [7731,7757]
trailer [7731,7757]
===
match
---
name: source [14201,14207]
name: source [14201,14207]
===
match
---
trailer [11050,11057]
trailer [11050,11057]
===
match
---
trailer [5946,5990]
trailer [5946,5990]
===
match
---
name: DagRun [8744,8750]
name: DagRun [8744,8750]
===
match
---
name: d [9893,9894]
name: d [9893,9894]
===
match
---
name: SystemExit [6981,6991]
name: SystemExit [6981,6991]
===
match
---
name: print [9394,9399]
name: print [9394,9399]
===
match
---
decorated [1795,4543]
decorated [1795,4543]
===
match
---
name: args [7807,7811]
name: args [7807,7811]
===
match
---
name: args [5550,5554]
name: args [5550,5554]
===
match
---
operator: , [1390,1391]
operator: , [1390,1391]
===
match
---
name: action_logging [8065,8079]
name: action_logging [8065,8079]
===
match
---
simple_stmt [7252,7320]
simple_stmt [7252,7320]
===
match
---
dotted_name [1760,1779]
dotted_name [1760,1779]
===
match
---
suite [7404,8052]
suite [7404,8052]
===
match
---
name: dr [12559,12561]
name: dr [12559,12561]
===
match
---
argument [1931,1959]
argument [1931,1959]
===
match
---
name: AirflowConsole [12326,12340]
name: AirflowConsole [12326,12340]
===
match
---
name: DagRun [12062,12068]
name: DagRun [12062,12068]
===
match
---
atom_expr [9400,9434]
atom_expr [9400,9434]
===
match
---
operator: , [11608,11609]
operator: , [11608,11609]
===
match
---
simple_stmt [860,874]
simple_stmt [860,874]
===
match
---
operator: = [4244,4245]
operator: = [4244,4245]
===
match
---
name: utils [1702,1707]
name: utils [1702,1707]
===
match
---
atom_expr [2447,2503]
atom_expr [2395,2451]
===
match
---
decorator [11618,11644]
decorator [11618,11644]
===
match
---
atom_expr [13222,13241]
atom_expr [13222,13241]
===
match
---
atom_expr [9773,9808]
atom_expr [9773,9808]
===
match
---
fstring_string: There are no tasks that match ' [2921,2952]
fstring_string: There are no tasks that match ' [2921,2952]
===
match
---
string: """Deletes all DB records related to the specified dag""" [4985,5042]
string: """Deletes all DB records related to the specified dag""" [4985,5042]
===
match
---
name: print [14003,14008]
name: print [14003,14008]
===
match
---
suite [6633,6902]
suite [6633,6902]
===
match
---
name: dag [5809,5812]
name: dag [5809,5812]
===
match
---
name: owner [10053,10058]
name: owner [10053,10058]
===
match
---
name: ast [10577,10580]
name: ast [10577,10580]
===
match
---
comparison [13854,13904]
comparison [13854,13904]
===
match
---
name: args [10188,10192]
name: args [10188,10192]
===
match
---
trailer [4202,4207]
trailer [4202,4207]
===
match
---
fstring [5839,5890]
fstring [5839,5890]
===
match
---
name: dagbag [10251,10257]
name: dagbag [10251,10257]
===
match
---
atom [10755,10757]
atom [10755,10757]
===
match
---
fstring_expr [3310,3324]
fstring_expr [3310,3324]
===
match
---
atom_expr [6818,6837]
atom_expr [6818,6837]
===
match
---
name: dag [6089,6092]
name: dag [6089,6092]
===
match
---
trailer [9794,9807]
trailer [9794,9807]
===
match
---
name: tis [13990,13993]
name: tis [13990,13993]
===
match
---
name: filter [8737,8743]
name: filter [8737,8743]
===
match
---
name: include_upstream [2781,2797]
name: include_upstream [2781,2797]
===
match
---
simple_stmt [4648,4686]
simple_stmt [4648,4686]
===
match
---
name: TaskInstance [13751,13763]
name: TaskInstance [13751,13763]
===
match
---
name: format [7294,7300]
name: format [7294,7300]
===
match
---
operator: = [6751,6752]
operator: = [6751,6752]
===
match
---
simple_stmt [1033,1087]
simple_stmt [1033,1087]
===
match
---
parameters [5682,5699]
parameters [5682,5699]
===
match
---
name: api [1046,1049]
name: api [1046,1049]
===
match
---
argument [3621,3648]
argument [3621,3648]
===
match
---
atom_expr [11349,11374]
atom_expr [11349,11374]
===
match
---
trailer [14190,14208]
trailer [14190,14208]
===
match
---
decorated [11618,12757]
decorated [11618,12757]
===
match
---
atom_expr [8907,9005]
atom_expr [8907,9005]
===
match
---
name: dagbag [10880,10886]
name: dagbag [10880,10886]
===
match
---
operator: , [10548,10549]
operator: , [10548,10549]
===
match
---
simple_stmt [10745,10758]
simple_stmt [10745,10758]
===
match
---
trailer [12703,12713]
trailer [12703,12713]
===
match
---
suite [10710,11616]
suite [10710,11616]
===
match
---
atom_expr [14185,14208]
atom_expr [14185,14208]
===
match
---
argument [1961,1994]
argument [1961,1994]
===
match
---
operator: { [9960,9961]
operator: { [9960,9961]
===
match
---
simple_stmt [7776,7820]
simple_stmt [7776,7820]
===
match
---
simple_stmt [5530,5556]
simple_stmt [5530,5556]
===
match
---
operator: } [5987,5988]
operator: } [5987,5988]
===
match
---
trailer [12342,12351]
trailer [12342,12351]
===
match
---
atom_expr [7899,7910]
atom_expr [7899,7910]
===
match
---
name: dag [8761,8764]
name: dag [8761,8764]
===
match
---
simple_stmt [8907,9006]
simple_stmt [8907,9006]
===
match
---
atom_expr [6875,6901]
atom_expr [6875,6901]
===
match
---
name: sorted [10570,10576]
name: sorted [10570,10576]
===
match
---
argument [5299,5317]
argument [5299,5317]
===
match
---
trailer [3496,3743]
trailer [3496,3743]
===
match
---
name: next_dagrun_info [9070,9086]
name: next_dagrun_info [9070,9086]
===
match
---
name: str [8031,8034]
name: str [8031,8034]
===
match
---
name: args [11067,11071]
name: args [11067,11071]
===
match
---
trailer [9454,9478]
trailer [9454,9478]
===
match
---
operator: == [11043,11045]
operator: == [11043,11045]
===
match
---
simple_stmt [10778,10803]
simple_stmt [10778,10803]
===
match
---
trailer [12270,12275]
trailer [12270,12275]
===
match
---
name: typing [908,914]
name: typing [908,914]
===
match
---
parameters [9686,9692]
parameters [9686,9692]
===
match
---
if_stmt [10807,11059]
if_stmt [10807,11059]
===
match
---
name: process_subdir [10267,10281]
name: process_subdir [10267,10281]
===
match
---
name: job [11510,11513]
name: job [11510,11513]
===
match
---
raise_stmt [4903,4930]
raise_stmt [4903,4930]
===
match
---
atom_expr [9332,9342]
atom_expr [9332,9342]
===
match
---
atom_expr [3130,3189]
atom_expr [3130,3189]
===
match
---
atom_expr [2237,2270]
atom_expr [2237,2270]
===
match
---
expr_stmt [11895,11944]
expr_stmt [11895,11944]
===
match
---
trailer [7962,7965]
trailer [7962,7965]
===
match
---
name: next_dagrun_info [9504,9520]
name: next_dagrun_info [9504,9520]
===
match
---
trailer [10576,10602]
trailer [10576,10602]
===
match
---
atom_expr [3848,3861]
atom_expr [3848,3861]
===
match
---
name: action_logging [10634,10648]
name: action_logging [10634,10648]
===
match
---
arglist [5650,5661]
arglist [5650,5661]
===
match
---
name: dag [7776,7779]
name: dag [7776,7779]
===
match
---
operator: , [1737,1738]
operator: , [1737,1738]
===
match
---
name: dr [12719,12721]
name: dr [12719,12721]
===
match
---
string: """Creates a dag run for the specified dag""" [4598,4643]
string: """Creates a dag run for the specified dag""" [4598,4643]
===
match
---
trailer [9577,9613]
trailer [9577,9613]
===
match
---
trailer [11339,11348]
trailer [11339,11348]
===
match
---
name: args [8296,8300]
name: args [8296,8300]
===
match
---
trailer [10595,10600]
trailer [10595,10600]
===
match
---
atom_expr [5435,5453]
atom_expr [5435,5453]
===
match
---
name: AirflowException [5395,5411]
name: AirflowException [5395,5411]
===
match
---
name: base_job [1323,1331]
name: base_job [1323,1331]
===
match
---
comparison [8873,8893]
comparison [8873,8893]
===
match
---
name: action_logging [4944,4958]
name: action_logging [4944,4958]
===
match
---
trailer [5543,5555]
trailer [5543,5555]
===
match
---
operator: = [1936,1937]
operator: = [1936,1937]
===
match
---
trailer [10325,10620]
trailer [10325,10620]
===
match
---
operator: = [12977,12978]
operator: = [12977,12978]
===
match
---
trailer [2081,2086]
trailer [2081,2086]
===
match
---
trailer [10539,10548]
trailer [10539,10548]
===
match
---
name: filter [8577,8583]
name: filter [8577,8583]
===
match
---
suite [10194,10621]
suite [10194,10621]
===
match
---
fstring_end: " [3004,3005]
fstring_end: " [3004,3005]
===
match
---
operator: , [2367,2368]
operator: , [2489,2490]
===
match
---
name: dag_pause [5486,5495]
name: dag_pause [5486,5495]
===
match
---
atom_expr [6485,6513]
atom_expr [6485,6513]
===
match
---
operator: , [12249,12250]
operator: , [12249,12250]
===
match
---
name: airflow [1644,1651]
name: airflow [1644,1651]
===
match
---
simple_stmt [11136,11203]
simple_stmt [11136,11203]
===
match
---
string: """Displays dags with or without stats at the command line""" [9698,9759]
string: """Displays dags with or without stats at the command line""" [9698,9759]
===
match
---
name: start_date [3811,3821]
name: start_date [3811,3821]
===
match
---
name: LOGGING_LEVEL [1946,1959]
name: LOGGING_LEVEL [1946,1959]
===
match
---
string: "imgcat" [6664,6672]
string: "imgcat" [6664,6672]
===
match
---
decorated [10120,10621]
decorated [10120,10621]
===
match
---
name: getboolean [4001,4011]
name: getboolean [4001,4011]
===
match
---
trailer [11071,11077]
trailer [11071,11077]
===
match
---
name: end_date [3839,3847]
name: end_date [3839,3847]
===
match
---
trailer [12586,12588]
trailer [12586,12588]
===
match
---
name: dag_id [8605,8611]
name: dag_id [8605,8611]
===
match
---
name: dag [13110,13113]
name: dag [13110,13113]
===
match
---
arglist [4012,4034]
arglist [4012,4034]
===
match
---
argument [9848,9905]
argument [9848,9905]
===
match
---
operator: , [9313,9314]
operator: , [9313,9314]
===
match
---
dictorsetmaker [12444,12739]
dictorsetmaker [12444,12739]
===
match
---
argument [7263,7292]
argument [7263,7292]
===
match
---
simple_stmt [1087,1139]
simple_stmt [1087,1139]
===
match
---
name: str [11460,11463]
name: str [11460,11463]
===
match
---
name: loads [3083,3088]
name: loads [3083,3088]
===
match
---
trailer [2360,2367]
trailer [2482,2489]
===
match
---
name: args [5657,5661]
name: args [5657,5661]
===
match
---
name: args [12978,12982]
name: args [12978,12982]
===
match
---
name: dag [1433,1436]
name: dag [1433,1436]
===
match
---
name: is_paused [5925,5934]
name: is_paused [5925,5934]
===
match
---
funcdef [5665,5991]
funcdef [5665,5991]
===
match
---
string: "[WARN] No following schedule can be found. " [9199,9244]
string: "[WARN] No following schedule can be found. " [9199,9244]
===
match
---
dotted_name [1694,1715]
dotted_name [1694,1715]
===
match
---
name: session [11274,11281]
name: session [11274,11281]
===
match
---
name: dot [7252,7255]
name: dot [7252,7255]
===
match
---
trailer [9335,9342]
trailer [9335,9342]
===
match
---
name: dag [8317,8320]
name: dag [8317,8320]
===
match
---
name: DagRun [8678,8684]
name: DagRun [8678,8684]
===
match
---
atom_expr [3975,3992]
atom_expr [3975,3992]
===
match
---
name: DagRun [8584,8590]
name: DagRun [8584,8590]
===
match
---
operator: , [9933,9934]
operator: , [9933,9934]
===
match
---
decorator [9642,9669]
decorator [9642,9669]
===
match
---
simple_stmt [8269,8309]
simple_stmt [8269,8309]
===
match
---
atom_expr [4198,4207]
atom_expr [4198,4207]
===
match
---
param [4587,4591]
param [4587,4591]
===
match
---
atom_expr [13737,13938]
atom_expr [13737,13938]
===
match
---
name: limit [11400,11405]
name: limit [11400,11405]
===
match
---
operator: = [4082,4083]
operator: = [4082,4083]
===
match
---
for_stmt [9440,9614]
for_stmt [9440,9614]
===
match
---
suite [11762,11796]
suite [11762,11796]
===
match
---
name: state [12111,12116]
name: state [12111,12116]
===
match
---
number: 1 [4540,4541]
number: 1 [4540,4541]
===
match
---
trailer [11367,11372]
trailer [11367,11372]
===
match
---
name: set_is_paused [5636,5649]
name: set_is_paused [5636,5649]
===
match
---
suite [3469,3744]
suite [3469,3744]
===
match
---
name: start_date [13005,13015]
name: start_date [13005,13015]
===
match
---
atom_expr [12326,12756]
atom_expr [12326,12756]
===
match
---
trailer [3777,4458]
trailer [3777,4458]
===
match
---
atom_expr [4531,4542]
atom_expr [4531,4542]
===
match
---
string: """Sets is_paused for DAG by a given dag_id""" [5705,5751]
string: """Sets is_paused for DAG by a given dag_id""" [5705,5751]
===
match
---
name: args [9795,9799]
name: args [9795,9799]
===
match
---
operator: = [4369,4370]
operator: = [4369,4370]
===
match
---
name: tasks [3278,3283]
name: tasks [3278,3283]
===
match
---
fstring_string: Dag id  [11913,11920]
fstring_string: Dag id  [11913,11920]
===
match
---
operator: , [14071,14072]
operator: , [14071,14072]
===
match
---
name: dagbag_stats [10347,10359]
name: dagbag_stats [10347,10359]
===
match
---
suite [7971,8021]
suite [7971,8021]
===
match
---
simple_stmt [13553,13567]
simple_stmt [13553,13567]
===
match
---
trailer [13744,13750]
trailer [13744,13750]
===
match
---
name: print [8907,8912]
name: print [8907,8912]
===
match
---
operator: = [10790,10791]
operator: = [10790,10791]
===
match
---
name: args [4290,4294]
name: args [4290,4294]
===
match
---
operator: , [11154,11155]
operator: , [11154,11155]
===
match
---
argument [9327,9342]
argument [9327,9342]
===
match
---
name: dag_backfill [1825,1837]
name: dag_backfill [1825,1837]
===
match
---
string: "This DAG may have schedule interval '@once' or `None`." [9257,9313]
string: "This DAG may have schedule interval '@once' or `None`." [9257,9313]
===
match
---
decorator [5558,5584]
decorator [5558,5584]
===
match
---
trailer [3082,3088]
trailer [3082,3088]
===
match
---
atom_expr [2356,2367]
atom_expr [2478,2489]
===
match
---
name: args [11921,11925]
name: args [11921,11925]
===
match
---
trailer [13050,13065]
trailer [13050,13065]
===
match
---
trailer [13750,13764]
trailer [13750,13764]
===
match
---
trailer [3937,3943]
trailer [3937,3943]
===
match
---
name: limit [11389,11394]
name: limit [11389,11394]
===
match
---
name: args [3108,3112]
name: args [3108,3112]
===
match
---
name: args [3806,3810]
name: args [3806,3810]
===
match
---
name: conf [3996,4000]
name: conf [3996,4000]
===
match
---
trailer [4011,4035]
trailer [4011,4035]
===
match
---
operator: , [12819,12820]
operator: , [12819,12820]
===
match
---
name: run [3774,3777]
name: run [3774,3777]
===
match
---
trailer [9779,9808]
trailer [9779,9808]
===
match
---
atom_expr [10861,10872]
atom_expr [10861,10872]
===
match
---
name: next_info [9521,9530]
name: next_info [9521,9530]
===
match
---
trailer [10886,10891]
trailer [10886,10891]
===
match
---
fstring_string:  saved [7347,7353]
fstring_string:  saved [7347,7353]
===
match
---
name: _save_dot_to_file [6427,6444]
name: _save_dot_to_file [6427,6444]
===
match
---
name: num_executions [9463,9477]
name: num_executions [9463,9477]
===
match
---
name: _display_dot_via_imgcat [6556,6579]
name: _display_dot_via_imgcat [6556,6579]
===
match
---
name: dr [7824,7826]
name: dr [7824,7826]
===
match
---
name: print [4853,4858]
name: print [4853,4858]
===
match
---
name: print [8025,8030]
name: print [8025,8030]
===
match
---
operator: + [8040,8041]
operator: + [8040,8041]
===
match
---
name: print_as [12343,12351]
name: print_as [12343,12351]
===
match
---
expr_stmt [13639,13666]
expr_stmt [13639,13666]
===
match
---
name: restricted [9128,9138]
name: restricted [9128,9138]
===
match
---
operator: = [1847,1848]
operator: = [1847,1848]
===
match
---
atom_expr [10503,10512]
atom_expr [10503,10512]
===
match
---
atom_expr [5955,5966]
atom_expr [5955,5966]
===
match
---
name: conf [4799,4803]
name: conf [4799,4803]
===
match
---
param [4974,4978]
param [4974,4978]
===
match
---
suite [3757,4459]
suite [3757,4459]
===
match
---
trailer [2901,3019]
trailer [2901,3019]
===
match
---
name: range [9449,9454]
name: range [9449,9454]
===
match
---
trailer [10052,10058]
trailer [10052,10058]
===
match
---
simple_stmt [1347,1413]
simple_stmt [1347,1413]
===
match
---
name: args [13016,13020]
name: args [13016,13020]
===
match
---
name: TaskInstance [3344,3356]
name: TaskInstance [3344,3356]
===
match
---
if_stmt [2234,2330]
if_stmt [2234,2330]
===
match
---
name: ext [7217,7220]
name: ext [7217,7220]
===
match
---
argument [3795,3821]
argument [3795,3821]
===
match
---
name: state [7905,7910]
name: state [7905,7910]
===
match
---
atom_expr [3297,3326]
atom_expr [3297,3326]
===
match
---
simple_stmt [1004,1033]
simple_stmt [1004,1033]
===
match
---
arglist [12361,12750]
arglist [12361,12750]
===
match
---
name: action_logging [5467,5481]
name: action_logging [5467,5481]
===
match
---
decorator [8054,8080]
decorator [8054,8080]
===
match
---
name: models [1426,1432]
name: models [1426,1432]
===
match
---
dotted_name [5457,5481]
dotted_name [5457,5481]
===
match
---
suite [9479,9614]
suite [9479,9614]
===
match
---
name: isoformat [12577,12586]
name: isoformat [12577,12586]
===
match
---
name: x [12290,12291]
name: x [12290,12291]
===
match
---
name: append [11095,11101]
name: append [11095,11101]
===
match
---
name: dag_id [8765,8771]
name: dag_id [8765,8771]
===
match
---
trailer [2717,2732]
trailer [2717,2732]
===
match
---
fstring_string: DAG:  [5841,5846]
fstring_string: DAG:  [5841,5846]
===
match
---
dotted_name [1352,1366]
dotted_name [1352,1366]
===
match
---
param [10700,10708]
param [10700,10708]
===
match
---
operator: , [12527,12528]
operator: , [12527,12528]
===
match
---
simple_stmt [2052,2068]
simple_stmt [2052,2068]
===
match
---
arglist [14062,14081]
arglist [14062,14081]
===
match
---
simple_stmt [7409,7690]
simple_stmt [7409,7690]
===
match
---
name: args [8103,8107]
name: args [8103,8107]
===
match
---
string: """Unpauses a DAG""" [5611,5631]
string: """Unpauses a DAG""" [5611,5631]
===
match
---
suite [8894,9049]
suite [8894,9049]
===
match
---
operator: = [2585,2586]
operator: = [2585,2586]
===
match
---
atom_expr [7697,7708]
atom_expr [7697,7708]
===
match
---
name: reset_dagruns [3455,3468]
name: reset_dagruns [3455,3468]
===
match
---
operator: = [3973,3974]
operator: = [3973,3974]
===
match
---
name: OSError [5361,5368]
name: OSError [5361,5368]
===
match
---
name: out [8035,8038]
name: out [8035,8038]
===
match
---
name: AirflowException [11959,11975]
name: AirflowException [11959,11975]
===
match
---
name: json [7998,8002]
name: json [7998,8002]
===
match
---
simple_stmt [12937,12991]
simple_stmt [12937,12991]
===
match
---
decorator [10146,10173]
decorator [10146,10173]
===
match
---
dotted_name [5559,5583]
dotted_name [5559,5583]
===
match
---
atom_expr [12062,12256]
atom_expr [12062,12256]
===
match
---
atom_expr [12004,12022]
atom_expr [12004,12022]
===
match
---
argument [3537,3563]
argument [3537,3563]
===
match
---
trailer [8764,8771]
trailer [8764,8771]
===
match
---
comparison [11028,11057]
comparison [11028,11057]
===
match
---
name: execution_date [7873,7887]
name: execution_date [7873,7887]
===
match
---
name: x [10051,10052]
name: x [10051,10052]
===
match
---
name: queries [11318,11325]
name: queries [11318,11325]
===
match
---
name: create_session [8432,8446]
name: create_session [8432,8446]
===
match
---
trailer [11975,11990]
trailer [11975,11990]
===
match
---
operator: , [6696,6697]
operator: , [6696,6697]
===
match
---
name: local [3927,3932]
name: local [3927,3932]
===
match
---
name: action_logging [11629,11643]
name: action_logging [11629,11643]
===
match
---
trailer [6444,6459]
trailer [6444,6459]
===
match
---
name: save_dagrun [13655,13666]
name: save_dagrun [13655,13666]
===
match
---
name: vr [4488,4490]
name: vr [4488,4490]
===
match
---
import_as_names [1374,1412]
import_as_names [1374,1412]
===
match
---
arglist [2356,2380]
arglist [2478,2502]
===
match
---
decorators [10120,10173]
decorators [10120,10173]
===
match
---
expr_stmt [13607,13634]
expr_stmt [13607,13634]
===
match
---
suite [9171,9389]
suite [9171,9389]
===
match
---
dotted_name [7359,7383]
dotted_name [7359,7383]
===
match
---
trailer [11859,11866]
trailer [11859,11866]
===
match
---
simple_stmt [9488,9564]
simple_stmt [9488,9564]
===
match
---
name: cli_utils [7359,7368]
name: cli_utils [7359,7368]
===
match
---
atom_expr [2015,2029]
atom_expr [2015,2029]
===
match
---
trailer [3356,3375]
trailer [3356,3375]
===
match
---
operator: = [7827,7828]
operator: = [7827,7828]
===
match
---
atom_expr [13046,13065]
atom_expr [13046,13065]
===
match
---
parameters [12814,12834]
parameters [12814,12834]
===
match
---
atom_expr [5102,5110]
atom_expr [5102,5110]
===
match
---
fstring [7330,7354]
fstring [7330,7354]
===
match
---
simple_stmt [7132,7138]
simple_stmt [7132,7138]
===
match
---
expr_stmt [3388,3403]
expr_stmt [3388,3403]
===
match
---
name: AirflowConsole [10300,10314]
name: AirflowConsole [10300,10314]
===
match
---
or_test [2642,2674]
or_test [2642,2674]
===
match
---
name: max [8518,8521]
name: max [8518,8521]
===
match
---
operator: { [3310,3311]
operator: { [3310,3311]
===
match
---
name: airflow [1310,1317]
name: airflow [1310,1317]
===
match
---
name: filepath [10020,10028]
name: filepath [10020,10028]
===
match
---
trailer [8008,8020]
trailer [8008,8020]
===
match
---
trailer [9866,9871]
trailer [9866,9871]
===
match
---
argument [2781,2826]
argument [2781,2826]
===
match
---
trailer [7811,7818]
trailer [7811,7818]
===
match
---
atom_expr [2394,2409]
atom_expr [2342,2357]
===
match
---
trailer [8997,9004]
trailer [8997,9004]
===
match
---
name: run_at_least_once [13475,13492]
name: run_at_least_once [13475,13492]
===
match
---
argument [4282,4302]
argument [4282,4302]
===
match
---
trailer [8544,8550]
trailer [8544,8550]
===
match
---
operator: , [10698,10699]
operator: , [10698,10699]
===
match
---
fstring_string: ' regex. Nothing to run, exiting... [2969,3004]
fstring_string: ' regex. Nothing to run, exiting... [2969,3004]
===
match
---
name: args [5600,5604]
name: args [5600,5604]
===
match
---
import_name [874,891]
import_name [874,891]
===
match
---
trailer [4723,4735]
trailer [4723,4735]
===
match
---
atom_expr [9087,9126]
atom_expr [9087,9126]
===
match
---
name: output [9915,9921]
name: output [9915,9921]
===
match
---
operator: , [3728,3729]
operator: , [3728,3729]
===
match
---
atom_expr [9066,9145]
atom_expr [9066,9145]
===
match
---
suite [3438,4543]
suite [3438,4543]
===
match
---
expr_stmt [6742,6775]
expr_stmt [6742,6775]
===
match
---
argument [12384,12402]
argument [12384,12402]
===
match
---
name: ignore_dependencies [4156,4175]
name: ignore_dependencies [4156,4175]
===
match
---
operator: = [3236,3237]
operator: = [3236,3237]
===
match
---
name: errno [827,832]
name: errno [827,832]
===
match
---
expr_stmt [11444,11526]
expr_stmt [11444,11526]
===
match
---
argument [13986,13993]
argument [13986,13993]
===
match
---
atom_expr [8773,8794]
atom_expr [8773,8794]
===
match
---
trailer [8282,8308]
trailer [8282,8308]
===
match
---
name: args [9687,9691]
name: args [9687,9691]
===
match
---
fstring_string: File  [7332,7337]
fstring_string: File  [7332,7337]
===
match
---
simple_stmt [1859,1907]
simple_stmt [1859,1907]
===
match
---
name: dag_run_state [13067,13080]
name: dag_run_state [13067,13080]
===
match
---
atom_expr [6103,6114]
atom_expr [6103,6114]
===
match
---
simple_stmt [11895,11945]
simple_stmt [11895,11945]
===
match
---
atom_expr [11274,11425]
atom_expr [11274,11425]
===
match
---
string: "duration" [10456,10466]
string: "duration" [10456,10466]
===
match
---
decorator [4545,4571]
decorator [4545,4571]
===
match
---
name: DAG [3482,3485]
name: DAG [3482,3485]
===
match
---
operator: == [13822,13824]
operator: == [13822,13824]
===
match
---
trailer [2608,2619]
trailer [2608,2619]
===
match
---
name: dag_trigger [4575,4586]
name: dag_trigger [4575,4586]
===
match
---
atom_expr [2587,2600]
atom_expr [2587,2600]
===
match
---
atom_expr [8522,8543]
atom_expr [8522,8543]
===
match
---
trailer [3213,3220]
trailer [3213,3220]
===
match
---
operator: = [13221,13222]
operator: = [13221,13222]
===
match
---
name: args [13885,13889]
name: args [13885,13889]
===
match
---
trailer [9520,9563]
trailer [9520,9563]
===
match
---
trailer [3426,3428]
trailer [3426,3428]
===
match
---
name: verbose [4282,4289]
name: verbose [4282,4289]
===
match
---
operator: = [12390,12391]
operator: = [12390,12391]
===
match
---
suite [8337,8422]
suite [8337,8422]
===
match
---
operator: = [9852,9853]
operator: = [9852,9853]
===
match
---
name: execution_date [12562,12576]
name: execution_date [12562,12576]
===
match
---
arglist [4749,4834]
arglist [4749,4834]
===
match
---
name: AirflowConsole [1124,1138]
name: AirflowConsole [1124,1138]
===
match
---
name: args [4587,4591]
name: args [4587,4591]
===
match
---
name: key [12276,12279]
name: key [12276,12279]
===
match
---
name: args [5306,5310]
name: args [5306,5310]
===
match
---
trailer [5783,5796]
trailer [5783,5796]
===
match
---
name: dag_runs [12051,12059]
name: dag_runs [12051,12059]
===
match
---
name: queries [11087,11094]
name: queries [11087,11094]
===
match
---
expr_stmt [8469,8646]
expr_stmt [8469,8646]
===
match
---
name: task [3311,3315]
name: task [3311,3315]
===
match
---
atom_expr [4425,4443]
atom_expr [4425,4443]
===
match
---
arglist [6445,6458]
arglist [6445,6458]
===
match
---
dotted_name [4934,4958]
dotted_name [4934,4958]
===
match
---
expr_stmt [13717,13948]
expr_stmt [13717,13948]
===
match
---
name: dag_id [6121,6127]
name: dag_id [6121,6127]
===
match
---
suite [12835,14209]
suite [12835,14209]
===
match
---
name: airflow [1092,1099]
name: airflow [1092,1099]
===
match
---
decorated [10623,11616]
decorated [10623,11616]
===
match
---
funcdef [9669,10118]
funcdef [9669,10118]
===
match
---
comp_op [11839,11845]
comp_op [11839,11845]
===
match
---
name: pool [4203,4207]
name: pool [4203,4207]
===
match
---
suite [6012,6550]
suite [6012,6550]
===
match
---
atom_expr [11785,11795]
atom_expr [11785,11795]
===
match
---
comp_op [11867,11873]
comp_op [11867,11873]
===
match
---
atom_expr [10577,10601]
atom_expr [10577,10601]
===
match
---
arglist [6664,6719]
arglist [6664,6719]
===
match
---
atom_expr [4713,4844]
atom_expr [4713,4844]
===
match
---
name: dot_graph [14062,14071]
name: dot_graph [14062,14071]
===
match
---
name: message [5267,5274]
name: message [5267,5274]
===
match
---
operator: = [4775,4776]
operator: = [4775,4776]
===
match
---
simple_stmt [12840,12933]
simple_stmt [12840,12933]
===
match
---
operator: , [13155,13156]
operator: , [13155,13156]
===
match
---
name: dag [8601,8604]
name: dag [8601,8604]
===
match
---
string: "execution_date" [12541,12557]
string: "execution_date" [12541,12557]
===
match
---
name: dag [10700,10703]
name: dag [10700,10703]
===
match
---
name: session [1708,1715]
name: session [1708,1715]
===
match
---
name: args [4756,4760]
name: args [4756,4760]
===
match
---
name: PIPE [6692,6696]
name: PIPE [6692,6696]
===
match
---
name: data [11567,11571]
name: data [11567,11571]
===
match
---
simple_stmt [12995,13093]
simple_stmt [12995,13093]
===
match
---
atom_expr [8513,8562]
atom_expr [8513,8562]
===
match
---
name: args [10376,10380]
name: args [10376,10380]
===
match
---
simple_stmt [9018,9030]
simple_stmt [9018,9030]
===
match
---
name: stdin [6698,6703]
name: stdin [6698,6703]
===
match
---
argument [4411,4443]
argument [4411,4443]
===
match
---
operator: , [10028,10029]
operator: , [10028,10029]
===
match
---
name: cli_utils [5559,5568]
name: cli_utils [5559,5568]
===
match
---
name: task_ids_or_regex [2746,2763]
name: task_ids_or_regex [2746,2763]
===
match
---
name: show_dagrun [14160,14171]
name: show_dagrun [14160,14171]
===
match
---
name: fields [11498,11504]
name: fields [11498,11504]
===
match
---
trailer [6757,6769]
trailer [6757,6769]
===
match
---
operator: = [7867,7868]
operator: = [7867,7868]
===
match
---
import_from [1246,1304]
import_from [1246,1304]
===
match
---
simple_stmt [13639,13667]
simple_stmt [13639,13667]
===
match
---
argument [3666,3686]
argument [3666,3686]
===
match
---
param [7398,7402]
param [7398,7402]
===
match
---
simple_stmt [13717,13949]
simple_stmt [13717,13949]
===
match
---
suite [6795,6839]
suite [6795,6839]
===
match
---
name: args [8283,8287]
name: args [8283,8287]
===
match
---
name: get_dag [7724,7731]
name: get_dag [7724,7731]
===
match
---
atom_expr [11102,11115]
atom_expr [11102,11115]
===
match
---
atom_expr [8702,8850]
atom_expr [8702,8850]
===
match
---
name: dag [2341,2344]
name: dag [2463,2466]
===
match
---
comparison [8773,8822]
comparison [8773,8822]
===
match
---
name: run_backwards [4430,4443]
name: run_backwards [4430,4443]
===
match
---
simple_stmt [11249,11436]
simple_stmt [11249,11436]
===
match
---
suite [7709,7758]
suite [7709,7758]
===
match
---
name: dag_delete [4963,4973]
name: dag_delete [4963,4973]
===
match
---
operator: = [8686,8687]
operator: = [8686,8687]
===
match
---
trailer [8779,8794]
trailer [8779,8794]
===
match
---
name: end_date [12695,12703]
name: end_date [12695,12703]
===
match
---
comparison [11827,11850]
comparison [11827,11850]
===
match
---
name: conf [3094,3098]
name: conf [3094,3098]
===
match
---
argument [4193,4207]
argument [4193,4207]
===
match
---
name: end_date [2666,2674]
name: end_date [2666,2674]
===
match
---
name: TaskInstance [1400,1412]
name: TaskInstance [1400,1412]
===
match
---
raise_stmt [5389,5416]
raise_stmt [5389,5416]
===
match
---
atom_expr [8410,8420]
atom_expr [8410,8420]
===
match
---
trailer [2591,2600]
trailer [2591,2600]
===
match
---
dotted_name [1418,1436]
dotted_name [1418,1436]
===
match
---
lambdef [12419,12749]
lambdef [12419,12749]
===
match
---
name: get_is_paused [8321,8334]
name: get_is_paused [8321,8334]
===
match
---
operator: } [3186,3187]
operator: } [3186,3187]
===
match
---
raise_stmt [10967,11004]
raise_stmt [10967,11004]
===
match
---
funcdef [5482,5556]
funcdef [5482,5556]
===
match
---
name: dag_id [11926,11932]
name: dag_id [11926,11932]
===
match
---
atom_expr [3048,3057]
atom_expr [3048,3057]
===
match
---
name: file [8989,8993]
name: file [8989,8993]
===
match
---
name: isoformat [12704,12713]
name: isoformat [12704,12713]
===
match
---
simple_stmt [14003,14011]
simple_stmt [14003,14011]
===
match
---
name: cli_utils [8055,8064]
name: cli_utils [8055,8064]
===
match
---
argument [7306,7318]
argument [7306,7318]
===
match
---
operator: , [12749,12750]
operator: , [12749,12750]
===
match
---
fstring [3303,3325]
fstring [3303,3325]
===
match
---
name: args [7745,7749]
name: args [7745,7749]
===
match
---
atom_expr [9394,9435]
atom_expr [9394,9435]
===
match
---
name: dag [1844,1847]
name: dag [1844,1847]
===
match
---
simple_stmt [4703,4845]
simple_stmt [4703,4845]
===
match
---
atom_expr [9018,9029]
atom_expr [9018,9029]
===
match
---
simple_stmt [4903,4931]
simple_stmt [4903,4931]
===
match
---
trailer [2732,2836]
trailer [2732,2836]
===
match
---
operator: { [11920,11921]
operator: { [11920,11921]
===
match
---
name: all [11420,11423]
name: all [11420,11423]
===
match
---
fstring_start: f" [5839,5841]
fstring_start: f" [5839,5841]
===
match
---
operator: , [10442,10443]
operator: , [10442,10443]
===
match
---
name: job [11464,11467]
name: job [11464,11467]
===
match
---
atom_expr [12519,12527]
atom_expr [12519,12527]
===
match
---
argument [3839,3861]
argument [3839,3861]
===
match
---
name: dag_id [7750,7756]
name: dag_id [7750,7756]
===
match
---
trailer [10593,10601]
trailer [10593,10601]
===
match
---
name: airflow [1760,1767]
name: airflow [1760,1767]
===
match
---
funcdef [11671,12757]
funcdef [11671,12757]
===
match
---
name: settings [1937,1945]
name: settings [1937,1945]
===
match
---
atom_expr [5847,5858]
atom_expr [5847,5858]
===
match
---
fstring_string:  does not exist in 'dag' table [5859,5889]
fstring_string:  does not exist in 'dag' table [5859,5889]
===
match
---
string: '' [12736,12738]
string: '' [12736,12738]
===
match
---
suite [10769,10803]
suite [10769,10803]
===
match
---
expr_stmt [6184,6204]
expr_stmt [6184,6204]
===
match
---
param [11693,11698]
param [11693,11698]
===
match
---
name: run_id [3363,3369]
name: run_id [3363,3369]
===
match
---
fstring_expr [5846,5859]
fstring_expr [5846,5859]
===
match
---
name: imgcat [13689,13695]
name: imgcat [13689,13695]
===
match
---
trailer [11467,11484]
trailer [11467,11484]
===
match
---
string: "run_id" [12477,12485]
string: "run_id" [12477,12485]
===
match
---
operator: , [13241,13242]
operator: , [13241,13242]
===
match
---
param [11699,11707]
param [11699,11707]
===
match
---
string: """Lists dag runs for a given DAG""" [11714,11750]
string: """Lists dag runs for a given DAG""" [11714,11750]
===
match
---
trailer [2241,2270]
trailer [2241,2270]
===
match
---
arglist [8913,9004]
arglist [8913,9004]
===
match
---
name: DagRun [3203,3209]
name: DagRun [3203,3209]
===
match
---
suite [5700,5991]
suite [5700,5991]
===
match
---
name: DAG [1444,1447]
name: DAG [1444,1447]
===
match
---
trailer [11419,11423]
trailer [11419,11423]
===
match
---
atom_expr [11810,11818]
atom_expr [11810,11818]
===
match
---
operator: , [3648,3649]
operator: , [3648,3649]
===
match
---
atom_expr [10376,10387]
atom_expr [10376,10387]
===
match
---
name: end_date [13037,13045]
name: end_date [13037,13045]
===
match
---
if_stmt [14091,14149]
if_stmt [14091,14149]
===
match
---
operator: , [10359,10360]
operator: , [10359,10360]
===
match
---
trailer [6691,6696]
trailer [6691,6696]
===
match
---
trailer [10281,10294]
trailer [10281,10294]
===
match
---
operator: , [11189,11190]
operator: , [11189,11190]
===
match
---
atom_expr [2953,2968]
atom_expr [2953,2968]
===
match
---
atom_expr [5122,5219]
atom_expr [5122,5219]
===
match
---
name: dagbag [11801,11807]
name: dagbag [11801,11807]
===
match
---
name: State [3718,3723]
name: State [3718,3723]
===
match
---
name: dag_id [13815,13821]
name: dag_id [13815,13821]
===
match
---
simple_stmt [961,1003]
simple_stmt [961,1003]
===
match
---
operator: , [1842,1843]
operator: , [1842,1843]
===
match
---
trailer [6605,6610]
trailer [6605,6610]
===
match
---
simple_stmt [13110,13509]
simple_stmt [13110,13509]
===
match
---
atom_expr [8584,8597]
atom_expr [8584,8597]
===
match
---
name: dag_id [12095,12101]
name: dag_id [12095,12101]
===
match
---
argument [11590,11608]
argument [11590,11608]
===
match
---
trailer [4374,4393]
trailer [4374,4393]
===
match
---
arglist [5544,5554]
arglist [5544,5554]
===
match
---
atom_expr [8432,8448]
atom_expr [8432,8448]
===
match
---
name: file [9327,9331]
name: file [9327,9331]
===
match
---
name: DagModel [5762,5770]
name: DagModel [5762,5770]
===
match
---
trailer [3896,3909]
trailer [3896,3909]
===
match
---
expr_stmt [2571,2619]
expr_stmt [2571,2619]
===
match
---
trailer [7965,7970]
trailer [7965,7970]
===
match
---
trailer [2355,2381]
trailer [2477,2503]
===
match
---
name: dr [12519,12521]
name: dr [12519,12521]
===
match
---
atom_expr [5306,5317]
atom_expr [5306,5317]
===
match
---
atom_expr [12978,12989]
atom_expr [12978,12989]
===
match
---
name: output [10369,10375]
name: output [10369,10375]
===
match
---
name: conf [8015,8019]
name: conf [8015,8019]
===
match
---
operator: , [11175,11176]
operator: , [11175,11176]
===
match
---
simple_stmt [9362,9374]
simple_stmt [9362,9374]
===
match
---
dotted_name [937,949]
dotted_name [937,949]
===
match
---
name: args [2802,2806]
name: args [2802,2806]
===
match
---
testlist_comp [11146,11201]
testlist_comp [11146,11201]
===
match
---
name: args [2683,2687]
name: args [2683,2687]
===
match
---
operator: = [13989,13990]
operator: = [13989,13990]
===
match
---
name: cli_utils [9617,9626]
name: cli_utils [9617,9626]
===
match
---
name: start_date [3537,3547]
name: start_date [3537,3547]
===
match
---
import_from [1491,1638]
import_from [1491,1638]
===
match
---
trailer [2398,2409]
trailer [2346,2357]
===
match
---
simple_stmt [6975,7106]
simple_stmt [6975,7106]
===
match
---
decorated [7358,8052]
decorated [7358,8052]
===
match
---
name: graphviz [937,945]
name: graphviz [937,945]
===
match
---
operator: = [3847,3848]
operator: = [3847,3848]
===
match
---
trailer [4683,4685]
trailer [4683,4685]
===
match
---
operator: , [10512,10513]
operator: , [10512,10513]
===
match
---
name: print [5435,5440]
name: print [5435,5440]
===
match
---
atom_expr [13885,13904]
atom_expr [13885,13904]
===
match
---
atom_expr [10594,10600]
atom_expr [10594,10600]
===
match
---
operator: , [5655,5656]
operator: , [5655,5656]
===
match
---
simple_stmt [5756,5797]
simple_stmt [5756,5797]
===
match
---
name: utils [1652,1657]
name: utils [1652,1657]
===
match
---
string: 'end_date' [11191,11201]
string: 'end_date' [11191,11201]
===
match
---
operator: , [1564,1565]
operator: , [1564,1565]
===
match
---
argument [4054,4116]
argument [4054,4116]
===
match
---
name: dag [7841,7844]
name: dag [7841,7844]
===
match
---
operator: @ [8054,8055]
operator: @ [8054,8055]
===
match
---
if_stmt [6935,7138]
if_stmt [6935,7138]
===
match
---
argument [4805,4834]
argument [4805,4834]
===
match
---
atom_expr [3078,3099]
atom_expr [3078,3099]
===
match
---
name: task_num [10540,10548]
name: task_num [10540,10548]
===
match
---
name: AirflowException [4909,4925]
name: AirflowException [4909,4925]
===
match
---
trailer [14008,14010]
trailer [14008,14010]
===
match
---
operator: , [3943,3944]
operator: , [3943,3944]
===
match
---
operator: = [3717,3718]
operator: = [3717,3718]
===
match
---
comparison [11102,11129]
comparison [11102,11129]
===
match
---
operator: } [12748,12749]
operator: } [12748,12749]
===
match
---
expr_stmt [7931,7944]
expr_stmt [7931,7944]
===
match
---
operator: , [4175,4176]
operator: , [4175,4176]
===
match
---
simple_stmt [14044,14083]
simple_stmt [14044,14083]
===
match
---
funcdef [5993,6550]
funcdef [5993,6550]
===
match
---
suite [5241,5417]
suite [5241,5417]
===
match
---
simple_stmt [5331,5346]
simple_stmt [5331,5346]
===
match
---
trailer [11027,11058]
trailer [11027,11058]
===
match
---
comparison [2237,2279]
comparison [2237,2279]
===
match
---
name: x [10436,10437]
name: x [10436,10437]
===
match
---
trailer [2575,2584]
trailer [2575,2584]
===
match
---
name: out [6818,6821]
name: out [6818,6821]
===
match
---
fstring_start: f" [5947,5949]
fstring_start: f" [5947,5949]
===
match
---
trailer [12962,12969]
trailer [12962,12969]
===
match
---
atom_expr [5828,5891]
atom_expr [5828,5891]
===
match
---
trailer [2768,2779]
trailer [2768,2779]
===
match
---
name: dags [9867,9871]
name: dags [9867,9871]
===
match
---
name: dag_num [10505,10512]
name: dag_num [10505,10512]
===
match
---
expr_stmt [10831,10848]
expr_stmt [10831,10848]
===
match
---
expr_stmt [9054,9145]
expr_stmt [9054,9145]
===
match
---
name: rerun_failed_tasks [4351,4369]
name: rerun_failed_tasks [4351,4369]
===
match
---
name: airflow [1453,1460]
name: airflow [1453,1460]
===
match
---
simple_stmt [6812,6839]
simple_stmt [6812,6839]
===
match
---
operator: , [12122,12123]
operator: , [12122,12123]
===
match
---
atom_expr [11827,11838]
atom_expr [11827,11838]
===
match
---
suite [7119,7138]
suite [7119,7138]
===
match
---
fstring_string: Dag:  [5949,5954]
fstring_string: Dag:  [5949,5954]
===
match
---
name: dag_id [4749,4755]
name: dag_id [4749,4755]
===
match
---
atom_expr [13180,13199]
atom_expr [13180,13199]
===
match
---
name: args [5102,5106]
name: args [5102,5106]
===
match
---
expr_stmt [12051,12256]
expr_stmt [12051,12256]
===
match
---
name: tis [13717,13720]
name: tis [13717,13720]
===
match
---
name: e [6938,6939]
name: e [6938,6939]
===
match
---
string: 'state' [11156,11163]
string: 'state' [11156,11163]
===
match
---
name: args [13046,13050]
name: args [13046,13050]
===
match
---
operator: , [12306,12307]
operator: , [12306,12307]
===
match
---
name: suppress_logs_and_warning [11645,11670]
name: suppress_logs_and_warning [11645,11670]
===
match
---
operator: = [4289,4290]
operator: = [4289,4290]
===
match
---
name: TaskInstance [13854,13866]
name: TaskInstance [13854,13866]
===
match
---
simple_stmt [1413,1448]
simple_stmt [1413,1448]
===
match
---
string: """Creates backfill job or dry run for a DAG""" [1859,1906]
string: """Creates backfill job or dry run for a DAG""" [1859,1906]
===
match
---
argument [10335,10359]
argument [10335,10359]
===
match
---
trailer [3158,3165]
trailer [3158,3165]
===
match
---
param [10188,10192]
param [10188,10192]
===
match
---
operator: , [7215,7216]
operator: , [7215,7216]
===
match
---
atom_expr [12995,13092]
atom_expr [12995,13092]
===
match
---
atom_expr [8669,8685]
atom_expr [8669,8685]
===
match
---
atom_expr [2802,2826]
atom_expr [2802,2826]
===
match
---
atom_expr [3770,4458]
atom_expr [3770,4458]
===
match
---
name: args [5955,5959]
name: args [5955,5959]
===
match
---
name: dr [7899,7901]
name: dr [7899,7901]
===
match
---
name: sys [8994,8997]
name: sys [8994,8997]
===
match
---
name: AirflowConsole [9813,9827]
name: AirflowConsole [9813,9827]
===
match
---
lambdef [9950,10110]
lambdef [9950,10110]
===
match
---
operator: = [4659,4660]
operator: = [4659,4660]
===
match
---
operator: { [7337,7338]
operator: { [7337,7338]
===
match
---
trailer [6769,6775]
trailer [6769,6775]
===
match
---
atom_expr [7868,7887]
atom_expr [7868,7887]
===
match
---
trailer [5900,5914]
trailer [5900,5914]
===
match
---
atom_expr [10792,10802]
atom_expr [10792,10802]
===
match
---
if_stmt [6788,6839]
if_stmt [6788,6839]
===
match
---
arglist [1931,1994]
arglist [1931,1994]
===
match
---
if_stmt [3105,4543]
if_stmt [3105,4543]
===
match
---
decorated [5456,5556]
decorated [5456,5556]
===
match
---
operator: = [12191,12192]
operator: = [12191,12192]
===
match
---
decorator [10120,10146]
decorator [10120,10146]
===
match
---
name: api_client [5277,5287]
name: api_client [5277,5287]
===
match
---
operator: = [6137,6138]
operator: = [6137,6138]
===
match
---
fstring_expr [7337,7347]
fstring_expr [7337,7347]
===
match
---
trailer [7262,7319]
trailer [7262,7319]
===
match
---
operator: = [2640,2641]
operator: = [2640,2641]
===
match
---
argument [8405,8420]
argument [8405,8420]
===
match
---
name: print [3130,3135]
name: print [3130,3135]
===
match
---
name: end_date [3595,3603]
name: end_date [3595,3603]
===
match
---
atom_expr [8761,8771]
atom_expr [8761,8771]
===
match
---
operator: } [10109,10110]
operator: } [10109,10110]
===
match
---
arglist [3210,3252]
arglist [3210,3252]
===
match
---
decorator [11644,11671]
decorator [11644,11671]
===
match
---
trailer [12291,12306]
trailer [12291,12306]
===
match
---
atom_expr [8296,8307]
atom_expr [8296,8307]
===
match
---
name: start_date [3795,3805]
name: start_date [3795,3805]
===
match
---
trailer [5336,5345]
trailer [5336,5345]
===
match
---
trailer [4858,4867]
trailer [4858,4867]
===
match
---
name: show_dagrun [13674,13685]
name: show_dagrun [13674,13685]
===
match
---
name: args [3892,3896]
name: args [3892,3896]
===
match
---
atom_expr [11067,11077]
atom_expr [11067,11077]
===
match
---
name: start_date [13169,13179]
name: start_date [13169,13179]
===
match
---
atom_expr [4853,4867]
atom_expr [4853,4867]
===
match
---
name: message [4703,4710]
name: message [4703,4710]
===
match
---
funcdef [10173,10621]
funcdef [10173,10621]
===
match
---
name: filename [6450,6458]
name: filename [6450,6458]
===
match
---
name: logical_date [9588,9600]
name: logical_date [9588,9600]
===
match
---
operator: , [1225,1226]
operator: , [1225,1226]
===
match
---
string: """Execute one single DagRun for a given DAG and execution date, using the DebugExecutor.""" [12840,12932]
string: """Execute one single DagRun for a given DAG and execution date, using the DebugExecutor.""" [12840,12932]
===
match
---
import_name [892,902]
import_name [892,902]
===
match
---
name: ignore_first_depends_on_past [4054,4082]
name: ignore_first_depends_on_past [4054,4082]
===
match
---
simple_stmt [6485,6514]
simple_stmt [6485,6514]
===
match
---
atom_expr [6538,6548]
atom_expr [6538,6548]
===
match
---
if_stmt [3045,3100]
if_stmt [3045,3100]
===
match
---
name: next_info [9488,9497]
name: next_info [9488,9497]
===
match
---
simple_stmt [13607,13635]
simple_stmt [13607,13635]
===
match
---
suite [14101,14149]
suite [14101,14149]
===
match
---
name: dag [6150,6153]
name: dag [6150,6153]
===
match
---
name: save [6175,6179]
name: save [6175,6179]
===
match
---
argument [9943,10110]
argument [9943,10110]
===
match
---
simple_stmt [13572,13603]
simple_stmt [13572,13603]
===
match
---
for_stmt [3262,3429]
for_stmt [3262,3429]
===
match
---
name: print [9572,9577]
name: print [9572,9577]
===
match
---
simple_stmt [12326,12757]
simple_stmt [12326,12757]
===
match
---
parameters [7397,7403]
parameters [7397,7403]
===
match
---
trailer [9069,9086]
trailer [9069,9086]
===
match
---
trailer [10266,10295]
trailer [10266,10295]
===
match
---
simple_stmt [9764,9809]
simple_stmt [9764,9809]
===
match
---
atom_expr [3892,3909]
atom_expr [3892,3909]
===
match
---
with_item [8432,8459]
with_item [8432,8459]
===
match
---
name: dot [6509,6512]
name: dot [6509,6512]
===
match
---
string: 'core' [4012,4018]
string: 'core' [4012,4018]
===
match
---
trailer [10469,10478]
trailer [10469,10478]
===
match
---
name: dag_id [7812,7818]
name: dag_id [7812,7818]
===
match
---
name: start_date [2609,2619]
name: start_date [2609,2619]
===
match
---
atom_expr [13110,13508]
atom_expr [13110,13508]
===
match
---
name: BaseJob [11028,11035]
name: BaseJob [11028,11035]
===
match
---
and_test [2390,2431]
and_test [2338,2379]
===
match
---
name: start_date [2629,2639]
name: start_date [2629,2639]
===
match
---
simple_stmt [11953,11991]
simple_stmt [11953,11991]
===
match
---
name: args [2587,2591]
name: args [2587,2591]
===
match
---
operator: = [2339,2340]
operator: = [2461,2462]
===
match
---
operator: = [13584,13585]
operator: = [13584,13585]
===
match
---
atom_expr [10051,10058]
atom_expr [10051,10058]
===
match
---
if_stmt [11064,11131]
if_stmt [11064,11131]
===
match
---
trailer [4513,4517]
trailer [4513,4517]
===
match
---
suite [6590,7138]
suite [6590,7138]
===
match
---
argument [2746,2779]
argument [2746,2779]
===
match
---
atom_expr [7960,7970]
atom_expr [7960,7970]
===
match
---
operator: , [1635,1636]
operator: , [1635,1636]
===
match
---
name: run_conf [3025,3033]
name: run_conf [3025,3033]
===
match
---
trailer [13829,13836]
trailer [13829,13836]
===
match
---
simple_stmt [2073,2229]
simple_stmt [2073,2229]
===
match
---
arglist [3795,4444]
arglist [3795,4444]
===
match
---
atom_expr [6248,6399]
atom_expr [6248,6399]
===
match
---
name: ext [7301,7304]
name: ext [7301,7304]
===
match
---
trailer [11035,11042]
trailer [11035,11042]
===
match
---
operator: = [13015,13016]
operator: = [13015,13016]
===
match
---
or_test [2587,2619]
or_test [2587,2619]
===
match
---
atom_expr [3388,3398]
atom_expr [3388,3398]
===
match
---
name: args [4198,4202]
name: args [4198,4202]
===
match
---
trailer [2646,2657]
trailer [2646,2657]
===
match
---
name: dag_id [3214,3220]
name: dag_id [3214,3220]
===
match
---
name: exec_date [4825,4834]
name: exec_date [4825,4834]
===
match
---
name: simple_table [1104,1116]
name: simple_table [1104,1116]
===
match
---
atom_expr [7998,8020]
atom_expr [7998,8020]
===
match
---
name: dagbag [9764,9770]
name: dagbag [9764,9770]
===
match
---
trailer [6884,6891]
trailer [6884,6891]
===
match
---
simple_stmt [2571,2620]
simple_stmt [2571,2620]
===
match
---
trailer [12073,12256]
trailer [12073,12256]
===
match
---
name: dag [2714,2717]
name: dag [2714,2717]
===
match
---
trailer [13086,13091]
trailer [13086,13091]
===
match
---
name: TaskInstance [13802,13814]
name: TaskInstance [13802,13814]
===
match
---
atom_expr [12559,12588]
atom_expr [12559,12588]
===
match
---
except_clause [6906,6925]
except_clause [6906,6925]
===
match
---
name: max_date_subq [8469,8482]
name: max_date_subq [8469,8482]
===
match
---
name: args [3548,3552]
name: args [3548,3552]
===
match
---
fstring_expr [3170,3187]
fstring_expr [3170,3187]
===
match
---
name: data [6770,6774]
name: data [6770,6774]
===
match
---
operator: , [2029,2030]
operator: , [2029,2030]
===
match
---
name: NONE [13087,13091]
name: NONE [13087,13091]
===
match
---
name: data_interval [9531,9544]
name: data_interval [9531,9544]
===
match
---
trailer [11287,11296]
trailer [11287,11296]
===
match
---
trailer [5211,5217]
trailer [5211,5217]
===
match
---
name: ignore_first_depends_on_past [4088,4116]
name: ignore_first_depends_on_past [4088,4116]
===
match
---
name: get_run_data_interval [9091,9112]
name: get_run_data_interval [9091,9112]
===
match
---
name: cli_utils [5457,5466]
name: cli_utils [5457,5466]
===
match
---
name: subprocess [6647,6657]
name: subprocess [6647,6657]
===
match
---
raise_stmt [5822,5891]
raise_stmt [5822,5891]
===
match
---
trailer [6828,6837]
trailer [6828,6837]
===
match
---
trailer [11356,11367]
trailer [11356,11367]
===
match
---
name: state [11996,12001]
name: state [11996,12001]
===
match
---
atom_expr [3311,3323]
atom_expr [3311,3323]
===
match
---
operator: , [1604,1605]
operator: , [1604,1605]
===
match
---
simple_stmt [903,931]
simple_stmt [903,931]
===
match
---
name: dr [12487,12489]
name: dr [12487,12489]
===
match
---
trailer [9112,9126]
trailer [9112,9126]
===
match
---
name: action_logging [9627,9641]
name: action_logging [9627,9641]
===
match
---
string: "[WARN] Only applicable when there is execution record found for the DAG." [8913,8987]
string: "[WARN] Only applicable when there is execution record found for the DAG." [8913,8987]
===
match
---
name: start_date [3242,3252]
name: start_date [3242,3252]
===
match
---
operator: } [5858,5859]
operator: } [5858,5859]
===
match
---
name: rerun_failed_tasks [4375,4393]
name: rerun_failed_tasks [4375,4393]
===
match
---
argument [3363,3374]
argument [3363,3374]
===
match
---
operator: = [10403,10404]
operator: = [10403,10404]
===
match
---
name: args [10282,10286]
name: args [10282,10286]
===
match
---
argument [10397,10613]
argument [10397,10613]
===
match
---
string: "This will drop all existing records related to the specified DAG. Proceed? (y/n)" [5128,5210]
string: "This will drop all existing records related to the specified DAG. Proceed? (y/n)" [5128,5210]
===
match
---
trailer [13777,13784]
trailer [13777,13784]
===
match
---
expr_stmt [7980,8020]
expr_stmt [7980,8020]
===
match
---
name: logging [852,859]
name: logging [852,859]
===
match
---
operator: , [1380,1381]
operator: , [1380,1381]
===
match
---
decorator [12759,12776]
decorator [12759,12776]
===
match
---
dotted_name [10624,10648]
dotted_name [10624,10648]
===
match
---
name: run [13114,13117]
name: run [13114,13117]
===
match
---
name: next_info [9054,9063]
name: next_info [9054,9063]
===
match
---
suite [5376,5417]
suite [5376,5417]
===
match
---
string: ', ' [7991,7995]
string: ', ' [7991,7995]
===
match
---
lambdef [10404,10613]
lambdef [10404,10613]
===
match
---
name: ENOENT [6955,6961]
name: ENOENT [6955,6961]
===
match
---
if_stmt [5802,5892]
if_stmt [5802,5892]
===
match
---
operator: = [3342,3343]
operator: = [3342,3343]
===
match
---
name: start_date [2647,2657]
name: start_date [2647,2657]
===
match
---
simple_stmt [12262,12322]
simple_stmt [12262,12322]
===
match
---
simple_stmt [6089,6129]
simple_stmt [6089,6129]
===
match
---
name: BaseJob [11349,11356]
name: BaseJob [11349,11356]
===
match
---
name: args [3933,3937]
name: args [3933,3937]
===
match
---
except_clause [4872,4893]
except_clause [4872,4893]
===
match
---
atom_expr [6532,6549]
atom_expr [6532,6549]
===
match
---
name: dagbag [9860,9866]
name: dagbag [9860,9866]
===
match
---
atom_expr [3640,3648]
atom_expr [3640,3648]
===
match
---
operator: , [4393,4394]
operator: , [4393,4394]
===
match
---
operator: = [7780,7781]
operator: = [7780,7781]
===
match
---
atom_expr [5941,5990]
atom_expr [5941,5990]
===
match
---
name: filename_without_ext [7272,7292]
name: filename_without_ext [7272,7292]
===
match
---
trailer [3552,3563]
trailer [3552,3563]
===
match
---
trailer [11226,11228]
trailer [11226,11228]
===
match
---
atom_expr [2073,2228]
atom_expr [2073,2228]
===
match
---
operator: = [4819,4820]
operator: = [4819,4820]
===
match
---
operator: = [3891,3892]
operator: = [3891,3892]
===
match
---
operator: = [11596,11597]
operator: = [11596,11597]
===
match
---
operator: , [13836,13837]
operator: , [13836,13837]
===
match
---
name: message [5337,5344]
name: message [5337,5344]
===
match
---
operator: = [5058,5059]
operator: = [5058,5059]
===
match
---
trailer [12647,12658]
trailer [12647,12658]
===
match
---
name: cleanup [7306,7313]
name: cleanup [7306,7313]
===
match
---
name: BaseJob [1339,1346]
name: BaseJob [1339,1346]
===
match
---
trailer [4780,4787]
trailer [4780,4787]
===
match
---
name: subdir [6108,6114]
name: subdir [6108,6114]
===
match
---
name: c [8812,8813]
name: c [8812,8813]
===
match
---
simple_stmt [10715,10741]
simple_stmt [10715,10741]
===
match
---
name: cli_utils [1481,1490]
name: cli_utils [1481,1490]
===
match
---
suite [6729,6902]
suite [6729,6902]
===
match
---
trailer [7840,7888]
trailer [7840,7888]
===
match
---
name: execution_date [8780,8794]
name: execution_date [8780,8794]
===
match
---
suite [14172,14209]
suite [14172,14209]
===
match
---
operator: } [10942,10943]
operator: } [10942,10943]
===
match
---
operator: , [4018,4019]
operator: , [4018,4019]
===
match
---
name: settings [1024,1032]
name: settings [1024,1032]
===
match
---
expr_stmt [2624,2674]
expr_stmt [2624,2674]
===
match
---
simple_stmt [5897,5936]
simple_stmt [5897,5936]
===
match
---
string: "owner" [10042,10049]
string: "owner" [10042,10049]
===
match
---
string: "dag_id" [9974,9982]
string: "dag_id" [9974,9982]
===
match
---
name: cli_utils [11619,11628]
name: cli_utils [11619,11628]
===
match
---
operator: , [10602,10603]
operator: , [10602,10603]
===
match
---
trailer [2687,2698]
trailer [2687,2698]
===
insert-tree
---
simple_stmt [786,809]
    string: """Dag sub-commands""" [786,808]
to
file_input [786,14209]
at 0
===
delete-tree
---
simple_stmt [786,809]
    string: """Dag sub-commands""" [786,808]
