===
match
---
name: os [15772,15774]
name: os [15772,15774]
===
match
---
name: pickle_dags [2443,2454]
name: pickle_dags [2443,2454]
===
match
---
operator: = [14548,14549]
operator: = [14548,14549]
===
match
---
argument [2599,2611]
argument [2599,2611]
===
match
---
atom_expr [11323,11530]
atom_expr [11323,11530]
===
match
---
simple_stmt [2650,2667]
simple_stmt [2650,2667]
===
match
---
expr_stmt [8501,8558]
expr_stmt [8501,8558]
===
match
---
atom_expr [9631,9663]
atom_expr [9631,9663]
===
match
---
simple_stmt [12080,12097]
simple_stmt [12080,12097]
===
match
---
atom_expr [18083,18119]
atom_expr [18083,18119]
===
match
---
atom_expr [20625,20755]
atom_expr [20625,20755]
===
match
---
expr_stmt [7765,7793]
expr_stmt [7765,7793]
===
match
---
operator: = [13819,13820]
operator: = [13819,13820]
===
match
---
atom [6831,6833]
atom [6831,6833]
===
match
---
expr_stmt [6914,6942]
expr_stmt [6914,6942]
===
match
---
string: 'False' [15213,15220]
string: 'False' [15213,15220]
===
match
---
funcdef [17367,17514]
funcdef [17367,17514]
===
match
---
operator: = [7150,7151]
operator: = [7150,7151]
===
match
---
trailer [8394,8396]
trailer [8394,8396]
===
match
---
name: mock_kill [13551,13560]
name: mock_kill [13551,13560]
===
match
---
name: log_file_loc [18905,18917]
name: log_file_loc [18905,18917]
===
match
---
simple_stmt [10809,10852]
simple_stmt [10809,10852]
===
match
---
name: callback_requests [13000,13017]
name: callback_requests [13000,13017]
===
match
---
atom_expr [11189,11198]
atom_expr [11189,11198]
===
match
---
trailer [7459,7755]
trailer [7459,7755]
===
match
---
name: close [4860,4865]
name: close [4860,4865]
===
match
---
atom_expr [10604,10630]
atom_expr [10604,10630]
===
match
---
simple_stmt [20199,20271]
simple_stmt [20199,20271]
===
match
---
name: manager [5821,5828]
name: manager [5821,5828]
===
match
---
trailer [9155,9229]
trailer [9155,9229]
===
match
---
param [15296,15300]
param [15296,15300]
===
match
---
funcdef [7341,8120]
funcdef [7341,8120]
===
match
---
comparison [12894,12919]
comparison [12894,12919]
===
match
---
suite [3911,3947]
suite [3911,3947]
===
match
---
number: 3 [16680,16681]
number: 3 [16680,16681]
===
match
---
suite [17193,17278]
suite [17193,17278]
===
match
---
comp_op [11737,11743]
comp_op [11737,11743]
===
match
---
operator: , [14942,14943]
operator: , [14942,14943]
===
match
---
operator: = [15986,15987]
operator: = [15986,15987]
===
match
---
operator: , [20726,20727]
operator: , [20726,20727]
===
match
---
trailer [9822,9830]
trailer [9822,9830]
===
match
---
string: 'directory' [13679,13690]
string: 'directory' [13679,13690]
===
match
---
parameters [22168,22174]
parameters [22168,22174]
===
match
---
operator: = [21539,21540]
operator: = [21539,21540]
===
match
---
string: 'load_examples' [10445,10460]
string: 'load_examples' [10445,10460]
===
match
---
name: processor_agent [18579,18594]
name: processor_agent [18579,18594]
===
match
---
argument [13704,13714]
argument [13704,13714]
===
match
---
name: processor_agent [19226,19241]
name: processor_agent [19226,19241]
===
match
---
atom_expr [3665,3692]
atom_expr [3665,3692]
===
match
---
operator: = [13908,13909]
operator: = [13908,13909]
===
match
---
operator: , [12323,12324]
operator: , [12323,12324]
===
match
---
trailer [21245,21251]
trailer [21245,21251]
===
match
---
atom_expr [20986,21003]
atom_expr [20986,21003]
===
match
---
arglist [22200,22249]
arglist [22200,22249]
===
match
---
atom_expr [7836,7899]
atom_expr [7836,7899]
===
match
---
operator: = [6983,6984]
operator: = [6983,6984]
===
match
---
name: processor_timeout [7592,7609]
name: processor_timeout [7592,7609]
===
match
---
name: _file_path_queue [5687,5703]
name: _file_path_queue [5687,5703]
===
match
---
dotted_name [1701,1722]
dotted_name [1701,1722]
===
match
---
atom [15186,15211]
atom [15186,15211]
===
match
---
simple_stmt [5592,5613]
simple_stmt [5592,5613]
===
match
---
funcdef [3402,3443]
funcdef [3402,3443]
===
match
---
operator: = [14860,14861]
operator: = [14860,14861]
===
match
---
suite [19527,19653]
suite [19527,19653]
===
match
---
operator: = [10493,10494]
operator: = [10493,10494]
===
match
---
trailer [14999,15013]
trailer [14999,15013]
===
match
---
name: os [2074,2076]
name: os [2074,2076]
===
match
---
argument [22705,22713]
argument [22705,22713]
===
match
---
decorated [22720,23336]
decorated [22720,23516]
===
match
---
expr_stmt [5621,5641]
expr_stmt [5621,5641]
===
match
---
simple_stmt [18410,18567]
simple_stmt [18410,18567]
===
match
---
operator: , [2454,2455]
operator: , [2454,2455]
===
match
---
trailer [17330,17338]
trailer [17330,17338]
===
match
---
argument [9173,9215]
argument [9173,9215]
===
match
---
name: test_set_file_paths_when_processor_file_path_is_in_new_file_paths [7345,7410]
name: test_set_file_paths_when_processor_file_path_is_in_new_file_paths [7345,7410]
===
match
---
operator: = [14321,14322]
operator: = [14321,14322]
===
match
---
trailer [16557,16562]
trailer [16557,16562]
===
match
---
comparison [16654,16681]
comparison [16654,16681]
===
match
---
name: self [2805,2809]
name: self [2805,2809]
===
match
---
trailer [22193,22199]
trailer [22193,22199]
===
match
---
name: mock_processor [7152,7166]
name: mock_processor [7152,7166]
===
match
---
funcdef [13505,14234]
funcdef [13505,14234]
===
match
---
simple_stmt [15120,15169]
simple_stmt [15120,15169]
===
match
---
name: airflow [1406,1413]
name: airflow [1406,1413]
===
match
---
name: dirname [2037,2044]
name: dirname [2037,2044]
===
match
---
param [13551,13561]
param [13551,13561]
===
match
---
operator: , [14938,14939]
operator: , [14938,14939]
===
match
---
operator: = [10306,10307]
operator: = [10306,10307]
===
match
---
suite [20814,20869]
suite [20814,20869]
===
match
---
operator: , [14836,14837]
operator: , [14836,14837]
===
match
---
string: "Detected as zombie" [9521,9541]
string: "Detected as zombie" [9521,9541]
===
match
---
name: models [1259,1265]
name: models [1259,1265]
===
match
---
name: correct_maybe_zipped [1656,1676]
name: correct_maybe_zipped [1656,1676]
===
match
---
name: test_utils [1875,1885]
name: test_utils [1875,1885]
===
match
---
operator: = [7834,7835]
operator: = [7834,7835]
===
match
---
operator: , [16265,16266]
operator: , [16265,16266]
===
match
---
suite [21414,21603]
suite [21414,21603]
===
match
---
name: Pipe [11696,11700]
name: Pipe [11696,11700]
===
match
---
arglist [12161,12466]
arglist [12161,12466]
===
match
---
argument [7698,7715]
argument [7698,7715]
===
match
---
arglist [13665,13944]
arglist [13665,13944]
===
match
---
simple_stmt [13618,13955]
simple_stmt [13618,13955]
===
match
---
trailer [9939,9945]
trailer [9939,9945]
===
match
---
operator: = [11576,11577]
operator: = [11576,11577]
===
match
---
trailer [19828,19835]
trailer [19828,19835]
===
match
---
name: dag [10714,10717]
name: dag [10714,10717]
===
match
---
operator: = [22910,22911]
operator: = [22970,22971]
===
match
---
suite [2811,2840]
suite [2811,2840]
===
match
---
name: manager [8069,8076]
name: manager [8069,8076]
===
match
---
simple_stmt [21212,21252]
simple_stmt [21212,21252]
===
match
---
name: tests [1788,1793]
name: tests [1788,1793]
===
match
---
atom_expr [15120,15168]
atom_expr [15120,15168]
===
match
---
name: MagicMock [5235,5244]
name: MagicMock [5235,5244]
===
match
---
simple_stmt [11654,11703]
simple_stmt [11654,11703]
===
match
---
simple_stmt [16469,16497]
simple_stmt [16469,16497]
===
match
---
simple_stmt [12887,12920]
simple_stmt [12887,12920]
===
match
---
name: test_reload_module [17523,17541]
name: test_reload_module [17523,17541]
===
match
---
trailer [16053,16372]
trailer [16053,16372]
===
match
---
name: os [2016,2018]
name: os [2016,2018]
===
match
---
number: 1 [2136,2137]
number: 1 [2136,2137]
===
match
---
name: dag_ids [3217,3224]
name: dag_ids [3217,3224]
===
match
---
suite [6566,7336]
suite [6566,7336]
===
match
---
atom_expr [16551,16562]
atom_expr [16551,16562]
===
match
---
name: assert_called_once_with [14208,14231]
name: assert_called_once_with [14208,14231]
===
match
---
operator: == [21279,21281]
operator: == [21279,21281]
===
match
---
argument [12444,12465]
argument [12444,12465]
===
match
---
name: done [19736,19740]
name: done [19736,19740]
===
match
---
name: utils [1758,1763]
name: utils [1758,1763]
===
match
---
testlist_star_expr [15962,15985]
testlist_star_expr [15962,15985]
===
match
---
string: 'test_task_start_date_scheduling' [20118,20151]
string: 'test_task_start_date_scheduling' [20118,20151]
===
match
---
atom_expr [9146,9229]
atom_expr [9146,9229]
===
match
---
operator: , [19345,19346]
operator: , [19345,19346]
===
match
---
name: self [4995,4999]
name: self [4995,4999]
===
match
---
atom_expr [9062,9078]
atom_expr [9062,9078]
===
match
---
trailer [9099,9123]
trailer [9099,9123]
===
match
---
while_stmt [3706,3947]
while_stmt [3706,3947]
===
match
---
name: os [20452,20454]
name: os [20452,20454]
===
match
---
name: async_mode [20279,20289]
name: async_mode [20279,20289]
===
match
---
name: TemporaryDirectory [4214,4232]
name: TemporaryDirectory [4214,4232]
===
match
---
argument [4670,4680]
argument [4670,4680]
===
match
---
name: mark [15235,15239]
name: mark [15235,15239]
===
match
---
funcdef [11828,12097]
funcdef [11828,12097]
===
match
---
argument [12409,12426]
argument [12409,12426]
===
match
---
simple_stmt [19012,19039]
simple_stmt [19012,19039]
===
match
---
name: task_id [10767,10774]
name: task_id [10767,10774]
===
match
---
operator: = [20623,20624]
operator: = [20623,20624]
===
match
---
string: 'directory' [7487,7498]
string: 'directory' [7487,7498]
===
match
---
name: _start_time [14966,14977]
name: _start_time [14966,14977]
===
match
---
comparison [13078,13259]
comparison [13078,13259]
===
match
---
decorator [14239,14336]
decorator [14239,14336]
===
match
---
name: keys [6425,6429]
name: keys [6425,6429]
===
match
---
operator: = [15683,15684]
operator: = [15683,15684]
===
match
---
name: test_dag_path [19279,19292]
name: test_dag_path [19279,19292]
===
match
---
name: max [19338,19341]
name: max [19338,19341]
===
match
---
atom_expr [2675,2696]
atom_expr [2675,2696]
===
match
---
dictorsetmaker [10395,10470]
dictorsetmaker [10395,10470]
===
match
---
comparison [8069,8119]
comparison [8069,8119]
===
match
---
name: DagFileProcessorManager [6585,6608]
name: DagFileProcessorManager [6585,6608]
===
match
---
simple_stmt [9971,9998]
simple_stmt [9971,9998]
===
match
---
simple_stmt [15709,15809]
simple_stmt [15709,15809]
===
match
---
name: settings_context [17801,17817]
name: settings_context [17801,17817]
===
match
---
trailer [9249,9263]
trailer [9249,9263]
===
match
---
name: _processor_factory [17371,17389]
name: _processor_factory [17371,17389]
===
match
---
name: get_dag [8665,8672]
name: get_dag [8665,8672]
===
match
---
name: _file_path_queue [6467,6483]
name: _file_path_queue [6467,6483]
===
match
---
simple_stmt [10952,10975]
simple_stmt [10952,10975]
===
match
---
operator: = [4677,4678]
operator: = [4677,4678]
===
match
---
name: normpath [15733,15741]
name: normpath [15733,15741]
===
match
---
name: simple_task_instance [11425,11445]
name: simple_task_instance [11425,11445]
===
match
---
name: FakeDagFileProcessorRunner [4509,4535]
name: FakeDagFileProcessorRunner [4509,4535]
===
match
---
operator: = [14634,14635]
operator: = [14634,14635]
===
match
---
atom_expr [8385,8396]
atom_expr [8385,8396]
===
match
---
operator: = [7520,7521]
operator: = [7520,7521]
===
match
---
name: LJ [10618,10620]
name: LJ [10618,10620]
===
match
---
name: processor_agent [20607,20622]
name: processor_agent [20607,20622]
===
match
---
string: """         Test that when a processor already exist with a filepath, a new processor won't be created         with that filepath. The filepath will just be removed from the list.         """ [5010,5201]
string: """         Test that when a processor already exist with a filepath, a new processor won't be created         with that filepath. The filepath will just be removed from the list.         """ [5010,5201]
===
match
---
operator: = [5263,5264]
operator: = [5263,5264]
===
match
---
argument [13728,13770]
argument [13728,13770]
===
match
---
name: DagFileStat [7217,7228]
name: DagFileStat [7217,7228]
===
match
---
classdef [16794,20955]
classdef [16794,20955]
===
match
---
expr_stmt [5679,5730]
expr_stmt [5679,5730]
===
match
---
name: timedelta [5437,5446]
name: timedelta [5437,5446]
===
match
---
number: 0 [7232,7233]
number: 0 [7232,7233]
===
match
---
name: timezone [9126,9134]
name: timezone [9126,9134]
===
match
---
name: MagicMock [8290,8299]
name: MagicMock [8290,8299]
===
match
---
trailer [8672,8699]
trailer [8672,8699]
===
match
---
name: result [13218,13224]
name: result [13218,13224]
===
match
---
simple_stmt [8018,8054]
simple_stmt [8018,8054]
===
match
---
number: 1 [13713,13714]
number: 1 [13713,13714]
===
match
---
param [14459,14483]
param [14459,14483]
===
match
---
name: result [16551,16557]
name: result [16551,16557]
===
match
---
trailer [9706,9713]
trailer [9706,9713]
===
match
---
atom_expr [19328,19341]
atom_expr [19328,19341]
===
match
---
name: args [11998,12002]
name: args [11998,12002]
===
match
---
simple_stmt [11715,11781]
simple_stmt [11715,11781]
===
match
---
trailer [6608,6904]
trailer [6608,6904]
===
match
---
name: processor_timeout [12292,12309]
name: processor_timeout [12292,12309]
===
match
---
trailer [7850,7899]
trailer [7850,7899]
===
match
---
trailer [10882,10886]
trailer [10882,10886]
===
match
---
name: _run_parsing_loop [16390,16407]
name: _run_parsing_loop [16390,16407]
===
match
---
expr_stmt [8855,8873]
expr_stmt [8855,8873]
===
match
---
name: file_2 [6395,6401]
name: file_2 [6395,6401]
===
match
---
trailer [22199,22250]
trailer [22199,22250]
===
match
---
name: start_time [2794,2804]
name: start_time [2794,2804]
===
match
---
name: unittest [934,942]
name: unittest [934,942]
===
match
---
number: 1 [8257,8258]
number: 1 [8257,8258]
===
match
---
name: State [10921,10926]
name: State [10921,10926]
===
match
---
operator: , [1215,1216]
operator: , [1215,1216]
===
match
---
name: kill [15144,15148]
name: kill [15144,15148]
===
match
---
argument [12292,12323]
argument [12292,12323]
===
match
---
expr_stmt [10903,10935]
expr_stmt [10903,10935]
===
match
---
expr_stmt [5592,5612]
expr_stmt [5592,5612]
===
match
---
trailer [9903,9918]
trailer [9903,9918]
===
match
---
name: run_processor_manager_one_loop [12499,12529]
name: run_processor_manager_one_loop [12499,12529]
===
match
---
name: jobs [1132,1136]
name: jobs [1132,1136]
===
match
---
parameters [22463,22469]
parameters [22463,22469]
===
match
---
trailer [14231,14233]
trailer [14231,14233]
===
match
---
operator: = [7486,7487]
operator: = [7486,7487]
===
match
---
operator: , [13943,13944]
operator: , [13943,13944]
===
match
---
name: conf_vars [15175,15184]
name: conf_vars [15175,15184]
===
match
---
trailer [13283,13289]
trailer [13283,13289]
===
match
---
name: self [16860,16864]
name: self [16860,16864]
===
match
---
factor [13036,13038]
factor [13036,13038]
===
match
---
trailer [18594,18600]
trailer [18594,18600]
===
match
---
name: remove [20455,20461]
name: remove [20455,20461]
===
match
---
name: return_value [13590,13602]
name: return_value [13590,13602]
===
match
---
suite [22264,22403]
suite [22264,22403]
===
match
---
simple_stmt [3619,3632]
simple_stmt [3619,3632]
===
match
---
operator: == [21595,21597]
operator: == [21595,21597]
===
match
---
name: tempfile [894,902]
name: tempfile [894,902]
===
match
---
trailer [18151,18155]
trailer [18151,18155]
===
match
---
string: 'test_scheduler_dags.py' [18016,18040]
string: 'test_scheduler_dags.py' [18016,18040]
===
match
---
testlist_comp [4063,4086]
testlist_comp [4063,4086]
===
match
---
name: processor_factory [12234,12251]
name: processor_factory [12234,12251]
===
match
---
param [20184,20188]
param [20184,20188]
===
match
---
name: manager [9331,9338]
name: manager [9331,9338]
===
match
---
assert_stmt [18879,18918]
assert_stmt [18879,18918]
===
match
---
name: mocked_is_zipfile [21395,21412]
name: mocked_is_zipfile [21395,21412]
===
match
---
operator: , [19116,19117]
operator: , [19116,19117]
===
match
---
number: 0 [9880,9881]
number: 0 [9880,9881]
===
match
---
operator: = [12388,12389]
operator: = [12388,12389]
===
match
---
atom_expr [16245,16265]
atom_expr [16245,16265]
===
match
---
import_from [1696,1744]
import_from [1696,1744]
===
match
---
name: seconds [14734,14741]
name: seconds [14734,14741]
===
match
---
operator: = [14802,14803]
operator: = [14802,14803]
===
match
---
trailer [12693,12710]
trailer [12693,12710]
===
match
---
simple_stmt [10868,10887]
simple_stmt [10868,10887]
===
match
---
assert_stmt [13071,13259]
assert_stmt [13071,13259]
===
match
---
operator: , [16142,16143]
operator: , [16142,16143]
===
match
---
name: file_2 [5715,5721]
name: file_2 [5715,5721]
===
match
---
not_test [18886,18918]
not_test [18886,18918]
===
match
---
trailer [10320,10370]
trailer [10320,10370]
===
match
---
atom_expr [12894,12914]
atom_expr [12894,12914]
===
match
---
atom_expr [16174,16213]
atom_expr [16174,16213]
===
match
---
simple_stmt [2557,2613]
simple_stmt [2557,2613]
===
match
---
name: result [13182,13188]
name: result [13182,13188]
===
match
---
name: DEFAULT_DATE [2094,2106]
name: DEFAULT_DATE [2094,2106]
===
match
---
param [16860,16864]
param [16860,16864]
===
match
---
operator: , [4715,4716]
operator: , [4715,4716]
===
match
---
trailer [17988,17993]
trailer [17988,17993]
===
match
---
name: max [5447,5450]
name: max [5447,5450]
===
match
---
name: child_pipe [13273,13283]
name: child_pipe [13273,13283]
===
match
---
atom_expr [7259,7294]
atom_expr [7259,7294]
===
match
---
expr_stmt [22925,22964]
expr_stmt [23046,23085]
===
match
---
string: 'core' [4329,4335]
string: 'core' [4329,4335]
===
match
---
parameters [16859,16865]
parameters [16859,16865]
===
match
---
trailer [7081,7093]
trailer [7081,7093]
===
match
---
name: DagFileProcessorAgent [20625,20646]
name: DagFileProcessorAgent [20625,20646]
===
match
---
param [8147,8151]
param [8147,8151]
===
match
---
trailer [9778,9786]
trailer [9778,9786]
===
match
---
operator: = [18065,18066]
operator: = [18065,18066]
===
match
---
operator: = [13745,13746]
operator: = [13745,13746]
===
match
---
operator: = [6702,6703]
operator: = [6702,6703]
===
match
---
name: mocked_is_zipfile [21096,21113]
name: mocked_is_zipfile [21096,21113]
===
match
---
funcdef [6489,7336]
funcdef [6489,7336]
===
match
---
argument [8328,8359]
argument [8328,8359]
===
match
---
atom_expr [20452,20475]
atom_expr [20452,20475]
===
match
---
arglist [6622,6894]
arglist [6622,6894]
===
match
---
atom_expr [22936,22964]
atom_expr [23057,23085]
===
match
---
expr_stmt [19977,20052]
expr_stmt [19977,20052]
===
match
---
atom_expr [9776,9786]
atom_expr [9776,9786]
===
match
---
testlist_comp [5707,5729]
testlist_comp [5707,5729]
===
match
---
operator: , [20113,20114]
operator: , [20113,20114]
===
match
---
trailer [10757,10766]
trailer [10757,10766]
===
match
---
expr_stmt [11264,11548]
expr_stmt [11264,11548]
===
match
---
name: local_job [8855,8864]
name: local_job [8855,8864]
===
match
---
name: pytest [1013,1019]
name: pytest [1013,1019]
===
match
---
name: return_value [21796,21808]
name: return_value [21796,21808]
===
match
---
name: self [6560,6564]
name: self [6560,6564]
===
match
---
atom_expr [3129,3258]
atom_expr [3129,3258]
===
match
---
operator: = [11497,11498]
operator: = [11497,11498]
===
match
---
operator: = [16140,16141]
operator: = [16140,16141]
===
match
---
name: TemporaryDirectory [910,928]
name: TemporaryDirectory [910,928]
===
match
---
name: taskinstance [1327,1339]
name: taskinstance [1327,1339]
===
match
---
name: all [19856,19859]
name: all [19856,19859]
===
match
---
simple_stmt [17557,17788]
simple_stmt [17557,17788]
===
match
---
simple_stmt [3932,3947]
simple_stmt [3932,3947]
===
match
---
operator: = [18145,18146]
operator: = [18145,18146]
===
match
---
simple_stmt [13964,14026]
simple_stmt [13964,14026]
===
match
---
name: timedelta [14724,14733]
name: timedelta [14724,14733]
===
match
---
atom [14122,14144]
atom [14122,14144]
===
match
---
operator: @ [17349,17350]
operator: @ [17349,17350]
===
match
---
operator: , [13883,13884]
operator: , [13883,13884]
===
match
---
argument [16346,16361]
argument [16346,16361]
===
match
---
atom_expr [9009,9021]
atom_expr [9009,9021]
===
match
---
name: TEST_DAG_FOLDER [15755,15770]
name: TEST_DAG_FOLDER [15755,15770]
===
match
---
name: all [20047,20050]
name: all [20047,20050]
===
match
---
atom_expr [3001,3013]
atom_expr [3001,3013]
===
match
---
import_as_names [1656,1695]
import_as_names [1656,1695]
===
match
---
trailer [13035,13039]
trailer [13035,13039]
===
match
---
name: requests [9871,9879]
name: requests [9871,9879]
===
match
---
operator: = [8417,8418]
operator: = [8417,8418]
===
match
---
suite [5001,6484]
suite [5001,6484]
===
match
---
name: open_maybe_zipped [22277,22294]
name: open_maybe_zipped [22277,22294]
===
match
---
atom_expr [8658,8699]
atom_expr [8658,8699]
===
match
---
name: pid [2863,2866]
name: pid [2863,2866]
===
match
---
string: 'core' [15187,15193]
string: 'core' [15187,15193]
===
match
---
string: 'directory' [14601,14612]
string: 'directory' [14601,14612]
===
match
---
atom [17159,17161]
atom [17159,17161]
===
match
---
operator: , [15770,15771]
operator: , [15770,15771]
===
match
---
name: processor_factory_mock [6252,6274]
name: processor_factory_mock [6252,6274]
===
match
---
simple_stmt [7961,8009]
simple_stmt [7961,8009]
===
match
---
simple_stmt [11230,11247]
simple_stmt [11230,11247]
===
match
---
trailer [8999,9006]
trailer [8999,9006]
===
match
---
simple_stmt [13273,13292]
simple_stmt [13273,13292]
===
match
---
expr_stmt [18054,18119]
expr_stmt [18054,18119]
===
match
---
name: MagicMock [8385,8394]
name: MagicMock [8385,8394]
===
match
---
name: mocked_is_zipfile [21164,21181]
name: mocked_is_zipfile [21164,21181]
===
match
---
name: LJ [10880,10882]
name: LJ [10880,10882]
===
match
---
name: test_logging_config [1799,1818]
name: test_logging_config [1799,1818]
===
match
---
name: dag [8712,8715]
name: dag [8712,8715]
===
match
---
name: prefix [4233,4239]
name: prefix [4233,4239]
===
match
---
name: self [17542,17546]
name: self [17542,17546]
===
match
---
trailer [9569,9572]
trailer [9569,9572]
===
match
---
atom_expr [21164,21194]
atom_expr [21164,21194]
===
match
---
trailer [15754,15807]
trailer [15754,15807]
===
match
---
expr_stmt [5210,5246]
expr_stmt [5210,5246]
===
match
---
operator: = [8475,8476]
operator: = [8475,8476]
===
match
---
operator: , [10434,10435]
operator: , [10434,10435]
===
match
---
trailer [2634,2641]
trailer [2634,2641]
===
match
---
atom_expr [17448,17513]
atom_expr [17448,17513]
===
match
---
string: 'False' [4089,4096]
string: 'False' [4089,4096]
===
match
---
string: 'core' [18937,18943]
string: 'core' [18937,18943]
===
match
---
operator: = [4641,4642]
operator: = [4641,4642]
===
match
---
return_stmt [12080,12096]
return_stmt [12080,12096]
===
match
---
comparison [16744,16791]
comparison [16744,16791]
===
match
---
operator: = [5599,5600]
operator: = [5599,5600]
===
match
---
operator: , [14482,14483]
operator: , [14482,14483]
===
match
---
name: manager [16382,16389]
name: manager [16382,16389]
===
match
---
name: TestDagFileProcessorAgent [16800,16825]
name: TestDagFileProcessorAgent [16800,16825]
===
match
---
name: file_1 [5707,5713]
name: file_1 [5707,5713]
===
match
---
number: 0 [21973,21974]
number: 0 [21973,21974]
===
match
---
operator: = [4377,4378]
operator: = [4377,4378]
===
match
---
expr_stmt [21718,21769]
expr_stmt [21718,21769]
===
match
---
dotted_name [1869,1892]
dotted_name [1869,1892]
===
match
---
argument [7674,7684]
argument [7674,7684]
===
match
---
arglist [19101,19142]
arglist [19101,19142]
===
match
---
name: mocked_zip_file [22834,22849]
name: mocked_zip_file [22894,22909]
===
match
---
name: dag_folder [22041,22051]
name: dag_folder [22041,22051]
===
match
---
name: _kill_timed_out_processors [14161,14187]
name: _kill_timed_out_processors [14161,14187]
===
match
---
name: pickle_dags [3100,3111]
name: pickle_dags [3100,3111]
===
match
---
atom_expr [5476,5487]
atom_expr [5476,5487]
===
match
---
name: mocked_zip_file [22936,22951]
name: mocked_zip_file [23057,23072]
===
match
---
number: 1 [4472,4473]
number: 1 [4472,4473]
===
match
---
operator: = [11678,11679]
operator: = [11678,11679]
===
match
---
operator: , [4069,4070]
operator: , [4069,4070]
===
match
---
trailer [23006,23016]
trailer [23009,23019]
===
match
---
name: side_effect [7822,7833]
name: side_effect [7822,7833]
===
match
---
trailer [8726,8728]
trailer [8726,8728]
===
match
---
trailer [5908,5928]
trailer [5908,5928]
===
match
---
name: dag_folder [21268,21278]
name: dag_folder [21268,21278]
===
match
---
testlist_comp [20118,20152]
testlist_comp [20118,20152]
===
match
---
name: max_runs [7512,7520]
name: max_runs [7512,7520]
===
match
---
name: async_mode [19422,19432]
name: async_mode [19422,19432]
===
match
---
name: TestCorrectMaybeZipped [20963,20985]
name: TestCorrectMaybeZipped [20963,20985]
===
match
---
string: 'example_branch_operator' [8673,8698]
string: 'example_branch_operator' [8673,8698]
===
match
---
trailer [13589,13602]
trailer [13589,13602]
===
match
---
operator: = [8289,8290]
operator: = [8289,8290]
===
match
---
trailer [18155,18204]
trailer [18155,18204]
===
match
---
name: utils [1478,1483]
name: utils [1478,1483]
===
match
---
trailer [10717,10728]
trailer [10717,10728]
===
match
---
return_stmt [17441,17513]
return_stmt [17441,17513]
===
match
---
arglist [11591,11639]
arglist [11591,11639]
===
match
---
suite [15302,16792]
suite [15302,16792]
===
match
---
with_item [10559,10586]
with_item [10559,10586]
===
match
---
trailer [9984,9988]
trailer [9984,9988]
===
match
---
trailer [7980,7991]
trailer [7980,7991]
===
match
---
name: full_filepath [9469,9482]
name: full_filepath [9469,9482]
===
match
---
trailer [18665,18689]
trailer [18665,18689]
===
match
---
parameters [2866,2872]
parameters [2866,2872]
===
match
---
name: dag_ids [4670,4677]
name: dag_ids [4670,4677]
===
match
---
trailer [2420,2422]
trailer [2420,2422]
===
match
---
string: 'run_this_first' [8769,8785]
string: 'run_this_first' [8769,8785]
===
match
---
decorator [22720,22754]
decorator [22720,22754]
===
match
---
name: kwargs [11864,11870]
name: kwargs [11864,11870]
===
match
---
dictorsetmaker [4062,4096]
dictorsetmaker [4062,4096]
===
match
---
atom [16116,16118]
atom [16116,16118]
===
match
---
atom_expr [9502,9517]
atom_expr [9502,9517]
===
match
---
number: 1 [9214,9215]
number: 1 [9214,9215]
===
match
---
param [13545,13550]
param [13545,13550]
===
match
---
with_stmt [17796,18919]
with_stmt [17796,18919]
===
match
---
trailer [20046,20050]
trailer [20046,20050]
===
match
---
operator: , [7715,7716]
operator: , [7715,7716]
===
match
---
operator: , [13690,13691]
operator: , [13690,13691]
===
match
---
name: conf_vars [10384,10393]
name: conf_vars [10384,10393]
===
match
---
simple_stmt [929,955]
simple_stmt [929,955]
===
match
---
name: mocked_is_zipfile [22851,22868]
name: mocked_is_zipfile [22911,22928]
===
match
---
trailer [10816,10851]
trailer [10816,10851]
===
match
---
arglist [11997,12012]
arglist [11997,12012]
===
match
---
name: job_id [9000,9006]
name: job_id [9000,9006]
===
match
---
operator: , [6864,6865]
operator: , [6864,6865]
===
match
---
trailer [11237,11244]
trailer [11237,11244]
===
match
---
number: 0.01 [3737,3741]
number: 0.01 [3737,3741]
===
match
---
name: side_effect [7933,7944]
name: side_effect [7933,7944]
===
match
---
name: mocked_is_zipfile [21690,21707]
name: mocked_is_zipfile [21690,21707]
===
match
---
trailer [8807,8842]
trailer [8807,8842]
===
match
---
name: max_runs [12206,12214]
name: max_runs [12206,12214]
===
match
---
with_stmt [8567,9998]
with_stmt [8567,9998]
===
match
---
trailer [9879,9882]
trailer [9879,9882]
===
match
---
trailer [11464,11468]
trailer [11464,11468]
===
match
---
name: pickle_dags [17419,17430]
name: pickle_dags [17419,17430]
===
match
---
name: ti [11189,11191]
name: ti [11189,11191]
===
match
---
arglist [2029,2091]
arglist [2029,2091]
===
match
---
operator: @ [13430,13431]
operator: @ [13430,13431]
===
match
---
operator: , [13859,13860]
operator: , [13859,13860]
===
match
---
name: _processors [5829,5840]
name: _processors [5829,5840]
===
match
---
name: file_path [2432,2441]
name: file_path [2432,2441]
===
match
---
decorator [4050,4099]
decorator [4050,4099]
===
match
---
string: '/path/to/archive.zip' [22055,22077]
string: '/path/to/archive.zip' [22055,22077]
===
match
---
name: SchedulerJob [15654,15666]
name: SchedulerJob [15654,15666]
===
match
---
atom_expr [22277,22320]
atom_expr [22277,22320]
===
match
---
simple_stmt [10292,10371]
simple_stmt [10292,10371]
===
match
---
suite [20190,20955]
suite [20190,20955]
===
match
---
name: join [19096,19100]
name: join [19096,19100]
===
match
---
name: mod [17339,17342]
name: mod [17339,17342]
===
match
---
name: self [21389,21393]
name: self [21389,21393]
===
match
---
assert_stmt [9391,9416]
assert_stmt [9391,9416]
===
match
---
name: manager [6575,6582]
name: manager [6575,6582]
===
match
---
dotted_name [1124,1150]
dotted_name [1124,1150]
===
match
---
operator: , [14016,14017]
operator: , [14016,14017]
===
match
---
name: db [1932,1934]
name: db [1932,1934]
===
match
---
assert_stmt [6336,6379]
assert_stmt [6336,6379]
===
match
---
name: get [11749,11752]
name: get [11749,11752]
===
match
---
name: mock [13431,13435]
name: mock [13431,13435]
===
match
---
name: SHUTDOWN [10927,10935]
name: SHUTDOWN [10927,10935]
===
match
---
assert_stmt [19874,19963]
assert_stmt [19874,19963]
===
match
---
name: remove_list [17145,17156]
name: remove_list [17145,17156]
===
match
---
expr_stmt [11930,12013]
expr_stmt [11930,12013]
===
match
---
argument [5501,5511]
argument [5501,5511]
===
match
---
name: processor_factory_mock [5210,5232]
name: processor_factory_mock [5210,5232]
===
match
---
name: _create_dag_file_processor [16187,16213]
name: _create_dag_file_processor [16187,16213]
===
match
---
with_item [22541,22615]
with_item [22541,22615]
===
match
---
operator: = [21836,21837]
operator: = [21836,21837]
===
match
---
suite [3304,3342]
suite [3304,3342]
===
match
---
name: airflow [1251,1258]
name: airflow [1251,1258]
===
match
---
operator: @ [21010,21011]
operator: @ [21010,21011]
===
match
---
name: property [2955,2963]
name: property [2955,2963]
===
match
---
atom_expr [16512,16546]
atom_expr [16512,16546]
===
match
---
atom_expr [22017,22024]
atom_expr [22017,22024]
===
match
---
trailer [22646,22652]
trailer [22646,22652]
===
match
---
trailer [2023,2028]
trailer [2023,2028]
===
match
---
atom_expr [3527,3546]
atom_expr [3527,3546]
===
match
---
name: mock_processor [7057,7071]
name: mock_processor [7057,7071]
===
match
---
import_as_names [1826,1863]
import_as_names [1826,1863]
===
match
---
name: PropertyMock [992,1004]
name: PropertyMock [992,1004]
===
match
---
simple_stmt [22479,22528]
simple_stmt [22479,22528]
===
match
---
if_stmt [18615,18692]
if_stmt [18615,18692]
===
match
---
name: dag_directory [15709,15722]
name: dag_directory [15709,15722]
===
match
---
name: start [2745,2750]
name: start [2745,2750]
===
match
---
expr_stmt [9320,9378]
expr_stmt [9320,9378]
===
match
---
atom_expr [13020,13058]
atom_expr [13020,13058]
===
match
---
name: manager [15022,15029]
name: manager [15022,15029]
===
match
---
operator: , [9663,9664]
operator: , [9663,9664]
===
match
---
simple_stmt [1021,1060]
simple_stmt [1021,1060]
===
match
---
operator: = [7434,7435]
operator: = [7434,7435]
===
match
---
number: 1 [6670,6671]
number: 1 [6670,6671]
===
match
---
trailer [5686,5703]
trailer [5686,5703]
===
match
---
trailer [22551,22602]
trailer [22551,22602]
===
match
---
atom_expr [9181,9211]
atom_expr [9181,9211]
===
match
---
name: processor_agent [18705,18720]
name: processor_agent [18705,18720]
===
match
---
name: DagFileProcessorManager [5265,5288]
name: DagFileProcessorManager [5265,5288]
===
match
---
name: test_dag_path [12974,12987]
name: test_dag_path [12974,12987]
===
match
---
operator: , [10835,10836]
operator: , [10835,10836]
===
match
---
name: timedelta [7610,7619]
name: timedelta [7610,7619]
===
match
---
decorator [2954,2964]
decorator [2954,2964]
===
match
---
name: path [15745,15749]
name: path [15745,15749]
===
match
---
atom_expr [8748,8786]
atom_expr [8748,8786]
===
match
---
name: tests [1915,1920]
name: tests [1915,1920]
===
match
---
simple_stmt [19625,19653]
simple_stmt [19625,19653]
===
match
---
operator: = [2107,2108]
operator: = [2107,2108]
===
match
---
operator: = [16356,16357]
operator: = [16356,16357]
===
match
---
atom_expr [12739,12768]
atom_expr [12739,12768]
===
match
---
atom_expr [7110,7149]
atom_expr [7110,7149]
===
match
---
name: done [3906,3910]
name: done [3906,3910]
===
match
---
name: append [3869,3875]
name: append [3869,3875]
===
match
---
operator: , [14931,14932]
operator: , [14931,14932]
===
match
---
expr_stmt [11189,11213]
expr_stmt [11189,11213]
===
match
---
if_stmt [16509,16586]
if_stmt [16509,16586]
===
match
---
name: mock_processor [7994,8008]
name: mock_processor [7994,8008]
===
match
---
trailer [8301,8314]
trailer [8301,8314]
===
match
---
suite [18633,18692]
suite [18633,18692]
===
match
---
atom_expr [4599,4612]
atom_expr [4599,4612]
===
match
---
name: mocked_is_zipfile [21881,21898]
name: mocked_is_zipfile [21881,21898]
===
match
---
trailer [19301,19307]
trailer [19301,19307]
===
match
---
string: 'builtins.open' [22552,22567]
string: 'builtins.open' [22552,22567]
===
match
---
name: MagicMock [14668,14677]
name: MagicMock [14668,14677]
===
match
---
operator: , [1562,1563]
operator: , [1562,1563]
===
match
---
param [21684,21689]
param [21684,21689]
===
match
---
expr_stmt [7908,7951]
expr_stmt [7908,7951]
===
match
---
name: self [2751,2755]
name: self [2751,2755]
===
match
---
atom_expr [9436,9461]
atom_expr [9436,9461]
===
match
---
name: timeout [16442,16449]
name: timeout [16442,16449]
===
match
---
trailer [9945,9949]
trailer [9945,9949]
===
match
---
arglist [4420,4755]
arglist [4420,4755]
===
match
---
atom_expr [16478,16496]
atom_expr [16478,16496]
===
match
---
decorated [21608,22078]
decorated [21608,22078]
===
match
---
operator: = [6635,6636]
operator: = [6635,6636]
===
match
---
trailer [20893,20902]
trailer [20893,20902]
===
match
---
atom_expr [8967,8983]
atom_expr [8967,8983]
===
match
---
operator: @ [22720,22721]
operator: @ [22720,22721]
===
match
---
funcdef [22793,23336]
funcdef [22829,23516]
===
match
---
trailer [9749,9756]
trailer [9749,9756]
===
match
---
name: realpath [2053,2061]
name: realpath [2053,2061]
===
match
---
simple_stmt [1783,1864]
simple_stmt [1783,1864]
===
match
---
name: dag_directory [12161,12174]
name: dag_directory [12161,12174]
===
match
---
expr_stmt [8162,8491]
expr_stmt [8162,8491]
===
match
---
name: TI [9946,9948]
name: TI [9946,9948]
===
match
---
operator: , [16213,16214]
operator: , [16213,16214]
===
match
---
suite [18290,18312]
suite [18290,18312]
===
match
---
operator: == [22052,22054]
operator: == [22052,22054]
===
match
---
trailer [2031,2036]
trailer [2031,2036]
===
match
---
operator: , [18165,18166]
operator: , [18165,18166]
===
match
---
atom_expr [15902,15917]
atom_expr [15902,15917]
===
match
---
decorated [14239,15169]
decorated [14239,15169]
===
match
---
simple_stmt [2415,2476]
simple_stmt [2415,2476]
===
match
---
name: _fake_dag_processor_factory [3041,3068]
name: _fake_dag_processor_factory [3041,3068]
===
match
---
return_stmt [2820,2839]
return_stmt [2820,2839]
===
match
---
trailer [11580,11585]
trailer [11580,11585]
===
match
---
dotted_name [1750,1769]
dotted_name [1750,1769]
===
match
---
trailer [2431,2475]
trailer [2431,2475]
===
match
---
name: _processors [8077,8088]
name: _processors [8077,8088]
===
match
---
name: requests [9790,9798]
name: requests [9790,9798]
===
match
---
atom_expr [22106,22123]
atom_expr [22106,22123]
===
match
---
name: conf [4320,4324]
name: conf [4320,4324]
===
match
---
atom_expr [10837,10850]
atom_expr [10837,10850]
===
match
---
atom_expr [2716,2728]
atom_expr [2716,2728]
===
match
---
import_from [1910,1996]
import_from [1910,1996]
===
match
---
arglist [3169,3248]
arglist [3169,3248]
===
match
---
operator: } [10470,10471]
operator: } [10470,10471]
===
match
---
atom_expr [16696,16712]
atom_expr [16696,16712]
===
match
---
trailer [16757,16767]
trailer [16757,16767]
===
match
---
arglist [13341,13424]
arglist [13341,13424]
===
match
---
name: query [19995,20000]
name: query [19995,20000]
===
match
---
operator: , [14744,14745]
operator: , [14744,14745]
===
match
---
name: task_id [9823,9830]
name: task_id [9823,9830]
===
match
---
name: mock_file [22254,22263]
name: mock_file [22254,22263]
===
match
---
operator: , [22703,22704]
operator: , [22703,22704]
===
match
---
operator: , [22215,22216]
operator: , [22215,22216]
===
match
---
argument [14734,14743]
argument [14734,14743]
===
match
---
atom_expr [19720,19740]
atom_expr [19720,19740]
===
match
---
expr_stmt [6575,6904]
expr_stmt [6575,6904]
===
match
---
name: max [18526,18529]
name: max [18526,18529]
===
match
---
name: _file_path [12758,12768]
name: _file_path [12758,12768]
===
match
---
name: dag [8652,8655]
name: dag [8652,8655]
===
match
---
name: max [7620,7623]
name: max [7620,7623]
===
match
---
expr_stmt [16020,16372]
expr_stmt [16020,16372]
===
match
---
name: clear_db_runs [1957,1970]
name: clear_db_runs [1957,1970]
===
match
---
atom_expr [12120,12480]
atom_expr [12120,12480]
===
match
---
operator: , [8420,8421]
operator: , [8420,8421]
===
match
---
name: serialized_dag [1266,1280]
name: serialized_dag [1266,1280]
===
match
---
name: parent_pipe [16478,16489]
name: parent_pipe [16478,16489]
===
match
---
name: test_dag_path [20199,20212]
name: test_dag_path [20199,20212]
===
match
---
name: manager [13618,13625]
name: manager [13618,13625]
===
match
---
name: sys [17327,17330]
name: sys [17327,17330]
===
match
---
name: test_correct_maybe_zipped_archive [21650,21683]
name: test_correct_maybe_zipped_archive [21650,21683]
===
match
---
trailer [10628,10630]
trailer [10628,10630]
===
match
---
name: multiprocessing [11680,11695]
name: multiprocessing [11680,11695]
===
match
---
trailer [17265,17272]
trailer [17265,17272]
===
match
---
trailer [12143,12480]
trailer [12143,12480]
===
match
---
simple_stmt [8712,8729]
simple_stmt [8712,8729]
===
match
---
trailer [14043,14055]
trailer [14043,14055]
===
match
---
name: pytest [15228,15234]
name: pytest [15228,15234]
===
match
---
name: DagBag [8510,8516]
name: DagBag [8510,8516]
===
match
---
operator: , [4563,4564]
operator: , [4563,4564]
===
match
---
name: file_path [17390,17399]
name: file_path [17390,17399]
===
match
---
name: clear_db_runs [3427,3440]
name: clear_db_runs [3427,3440]
===
match
---
trailer [16834,16843]
trailer [16834,16843]
===
match
---
name: SerializedDagModel [20001,20019]
name: SerializedDagModel [20001,20019]
===
match
---
trailer [7791,7793]
trailer [7791,7793]
===
match
---
trailer [14077,14091]
trailer [14077,14091]
===
match
---
atom_expr [2109,2138]
atom_expr [2109,2138]
===
match
---
argument [11494,11507]
argument [11494,11507]
===
match
---
arglist [7473,7745]
arglist [7473,7745]
===
match
---
trailer [16389,16407]
trailer [16389,16407]
===
match
---
name: fake_processors [12809,12824]
name: fake_processors [12809,12824]
===
match
---
expr_stmt [10809,10851]
expr_stmt [10809,10851]
===
match
---
atom_expr [12809,12846]
atom_expr [12809,12846]
===
match
---
simple_stmt [10991,11008]
simple_stmt [10991,11008]
===
match
---
name: max_runs [16132,16140]
name: max_runs [16132,16140]
===
match
---
name: processor_timeout [4581,4598]
name: processor_timeout [4581,4598]
===
match
---
name: processor [12087,12096]
name: processor [12087,12096]
===
match
---
expr_stmt [8997,9021]
expr_stmt [8997,9021]
===
match
---
trailer [16664,16675]
trailer [16664,16675]
===
match
---
trailer [6970,6982]
trailer [6970,6982]
===
match
---
dotted_name [960,973]
dotted_name [960,973]
===
match
---
name: wait_until_finished [19591,19610]
name: wait_until_finished [19591,19610]
===
match
---
testlist_comp [19894,19923]
testlist_comp [19894,19923]
===
match
---
name: dag_ids [14795,14802]
name: dag_ids [14795,14802]
===
match
---
assert_stmt [16647,16681]
assert_stmt [16647,16681]
===
match
---
name: task [10817,10821]
name: task [10817,10821]
===
match
---
name: self [10092,10096]
name: self [10092,10096]
===
match
---
name: writable [2621,2629]
name: writable [2621,2629]
===
match
---
operator: , [4929,4930]
operator: , [4929,4930]
===
match
---
name: parent_pipe [3712,3723]
name: parent_pipe [3712,3723]
===
match
---
trailer [16489,16494]
trailer [16489,16494]
===
match
---
param [2979,2983]
param [2979,2983]
===
match
---
operator: = [4302,4303]
operator: = [4302,4303]
===
match
---
simple_stmt [9242,9308]
simple_stmt [9242,9308]
===
match
---
name: path [21282,21286]
name: path [21282,21286]
===
match
---
trailer [4818,4840]
trailer [4818,4840]
===
match
---
name: session [8967,8974]
name: session [8967,8974]
===
match
---
trailer [13209,13213]
trailer [13209,13213]
===
match
---
comparison [9398,9416]
comparison [9398,9416]
===
match
---
name: delete [9989,9995]
name: delete [9989,9995]
===
match
---
name: manager [14100,14107]
name: manager [14100,14107]
===
match
---
atom_expr [3560,3609]
atom_expr [3560,3609]
===
match
---
operator: , [4161,4162]
operator: , [4161,4162]
===
match
---
argument [10767,10790]
argument [10767,10790]
===
match
---
number: 2016 [2127,2131]
number: 2016 [2127,2131]
===
match
---
operator: = [5382,5383]
operator: = [5382,5383]
===
match
---
dotted_name [1406,1437]
dotted_name [1406,1437]
===
match
---
name: done [19522,19526]
name: done [19522,19526]
===
match
---
name: heartbeat [19641,19650]
name: heartbeat [19641,19650]
===
match
---
string: 'directory' [5316,5327]
string: 'directory' [5316,5327]
===
match
---
name: TestCase [16835,16843]
name: TestCase [16835,16843]
===
match
---
atom_expr [22217,22249]
atom_expr [22217,22249]
===
match
---
trailer [17338,17343]
trailer [17338,17343]
===
match
---
name: scheduler_job [1137,1150]
name: scheduler_job [1137,1150]
===
match
---
trailer [22294,22320]
trailer [22294,22320]
===
match
---
operator: = [11299,11300]
operator: = [11299,11300]
===
match
---
name: pickle_dags [4698,4709]
name: pickle_dags [4698,4709]
===
match
---
trailer [3905,3910]
trailer [3905,3910]
===
match
---
operator: , [14009,14010]
operator: , [14009,14010]
===
match
---
argument [16279,16301]
argument [16279,16301]
===
match
---
name: mock_kill [14198,14207]
name: mock_kill [14198,14207]
===
match
---
operator: == [6456,6458]
operator: == [6456,6458]
===
match
---
string: 'test_scheduler_dags.py' [20245,20269]
string: 'test_scheduler_dags.py' [20245,20269]
===
match
---
name: run_processor_manager_one_loop [3452,3482]
name: run_processor_manager_one_loop [3452,3482]
===
match
---
name: dags_folder [4266,4277]
name: dags_folder [4266,4277]
===
match
---
simple_stmt [15902,15918]
simple_stmt [15902,15918]
===
match
---
argument [16442,16454]
argument [16442,16454]
===
match
---
string: 'False' [18963,18970]
string: 'False' [18963,18970]
===
match
---
trailer [22021,22024]
trailer [22021,22024]
===
match
---
name: self [16991,16995]
name: self [16991,16995]
===
match
---
operator: = [14769,14770]
operator: = [14769,14770]
===
match
---
operator: , [17417,17418]
operator: , [17417,17418]
===
match
---
number: 1 [13037,13038]
number: 1 [13037,13038]
===
match
---
not_test [3523,3546]
not_test [3523,3546]
===
match
---
simple_stmt [12933,12988]
simple_stmt [12933,12988]
===
match
---
simple_stmt [3560,3610]
simple_stmt [3560,3610]
===
match
---
operator: } [14143,14144]
operator: } [14143,14144]
===
match
---
argument [14706,14744]
argument [14706,14744]
===
match
---
name: return_value [21182,21194]
name: return_value [21182,21194]
===
match
---
expr_stmt [11794,11814]
expr_stmt [11794,11814]
===
match
---
number: 0 [9640,9641]
number: 0 [9640,9641]
===
match
---
trailer [20312,20316]
trailer [20312,20316]
===
match
---
name: test_correct_maybe_zipped_normal_file_with_zip_in_name [21334,21388]
name: test_correct_maybe_zipped_normal_file_with_zip_in_name [21334,21388]
===
match
---
name: pickle_dags [2373,2384]
name: pickle_dags [2373,2384]
===
match
---
operator: , [20707,20708]
operator: , [20707,20708]
===
match
---
name: self [2922,2926]
name: self [2922,2926]
===
match
---
name: async_mode [18542,18552]
name: async_mode [18542,18552]
===
match
---
trailer [14160,14187]
trailer [14160,14187]
===
match
---
simple_stmt [5650,5671]
simple_stmt [5650,5671]
===
match
---
simple_stmt [7110,7167]
simple_stmt [7110,7167]
===
match
---
trailer [19521,19526]
trailer [19521,19526]
===
match
---
expr_stmt [22879,22916]
expr_stmt [22939,22976]
===
match
---
param [2362,2372]
param [2362,2372]
===
match
---
name: conf [20369,20373]
name: conf [20369,20373]
===
match
---
simple_stmt [21124,21156]
simple_stmt [21124,21156]
===
match
---
assert_stmt [16737,16791]
assert_stmt [16737,16791]
===
match
---
trailer [19485,19487]
trailer [19485,19487]
===
match
---
name: simple_task_instance [13189,13209]
name: simple_task_instance [13189,13209]
===
match
---
funcdef [21330,21603]
funcdef [21330,21603]
===
match
---
trailer [17184,17192]
trailer [17184,17192]
===
match
---
name: processor_agent [19506,19521]
name: processor_agent [19506,19521]
===
match
---
trailer [2664,2666]
trailer [2664,2666]
===
match
---
name: async_mode [19354,19364]
name: async_mode [19354,19364]
===
match
---
param [10092,10096]
param [10092,10096]
===
match
---
operator: , [22832,22833]
operator: , [22868,22869]
===
match
---
atom_expr [14503,14524]
atom_expr [14503,14524]
===
match
---
name: local_job [9009,9018]
name: local_job [9009,9018]
===
match
---
name: instance [22973,22981]
name: instance [23094,23102]
===
match
---
name: patch [13436,13441]
name: patch [13436,13441]
===
match
---
operator: = [9124,9125]
operator: = [9124,9125]
===
match
---
operator: = [10534,10535]
operator: = [10534,10535]
===
match
---
name: return_value [22952,22964]
name: return_value [23073,23085]
===
match
---
decorated [4050,4896]
decorated [4050,4896]
===
match
---
name: commit [8975,8981]
name: commit [8975,8981]
===
match
---
number: 1 [12215,12216]
number: 1 [12215,12216]
===
match
---
operator: = [14667,14668]
operator: = [14667,14668]
===
match
---
trailer [16963,16971]
trailer [16963,16971]
===
match
---
argument [5365,5405]
argument [5365,5405]
===
match
---
string: "postgres" [4931,4941]
string: "postgres" [4931,4941]
===
match
---
simple_stmt [3861,3881]
simple_stmt [3861,3881]
===
match
---
decorator [4901,4943]
decorator [4901,4943]
===
match
---
operator: , [19196,19197]
operator: , [19196,19197]
===
match
---
name: self [20683,20687]
name: self [20683,20687]
===
match
---
operator: , [10515,10516]
operator: , [10515,10516]
===
match
---
name: join [15750,15754]
name: join [15750,15754]
===
match
---
string: 'scheduler' [10396,10407]
string: 'scheduler' [10396,10407]
===
match
---
name: ti [8997,8999]
name: ti [8997,8999]
===
match
---
name: async_mode [13928,13938]
name: async_mode [13928,13938]
===
match
---
operator: == [9462,9464]
operator: == [9462,9464]
===
match
---
name: assert_called_once_with [23207,23230]
name: assert_called_once_with [23387,23410]
===
match
---
string: 'test_example_bash_operator' [10668,10696]
string: 'test_example_bash_operator' [10668,10696]
===
match
---
name: pickle_dags [7698,7709]
name: pickle_dags [7698,7709]
===
match
---
name: signal_conn [14758,14769]
name: signal_conn [14758,14769]
===
match
---
name: _callback_requests [13040,13058]
name: _callback_requests [13040,13058]
===
match
---
atom [13164,13259]
atom [13164,13259]
===
match
---
atom_expr [14078,14090]
atom_expr [14078,14090]
===
match
---
name: parent_pipe [11666,11677]
name: parent_pipe [11666,11677]
===
match
---
name: airflow [1312,1319]
name: airflow [1312,1319]
===
match
---
name: DagBag [1209,1215]
name: DagBag [1209,1215]
===
match
---
if_stmt [19415,19488]
if_stmt [19415,19488]
===
match
---
name: mock_dag_file_processor [15120,15143]
name: mock_dag_file_processor [15120,15143]
===
match
---
expr_stmt [7175,7249]
expr_stmt [7175,7249]
===
match
---
arglist [20660,20745]
arglist [20660,20745]
===
match
---
name: simple_task_instance [9643,9663]
name: simple_task_instance [9643,9663]
===
match
---
atom_expr [12690,12710]
atom_expr [12690,12710]
===
match
---
atom_expr [21541,21567]
atom_expr [21541,21567]
===
match
---
expr_stmt [14503,14531]
expr_stmt [14503,14531]
===
match
---
atom [15185,15221]
atom [15185,15221]
===
match
---
string: 'sql_alchemy_conn' [20325,20343]
string: 'sql_alchemy_conn' [20325,20343]
===
match
---
trailer [20646,20755]
trailer [20646,20755]
===
match
---
trailer [14679,14692]
trailer [14679,14692]
===
match
---
operator: , [13560,13561]
operator: , [13560,13561]
===
match
---
name: dag_ids [13873,13880]
name: dag_ids [13873,13880]
===
match
---
expr_stmt [9092,9229]
expr_stmt [9092,9229]
===
match
---
name: dag_directory [8209,8222]
name: dag_directory [8209,8222]
===
match
---
operator: @ [22758,22759]
operator: @ [22758,22759]
===
match
---
trailer [18091,18119]
trailer [18091,18119]
===
match
---
operator: , [10821,10822]
operator: , [10821,10822]
===
match
---
string: 'file_2.py' [5630,5641]
string: 'file_2.py' [5630,5641]
===
match
---
param [2867,2871]
param [2867,2871]
===
match
---
name: local_job [10903,10912]
name: local_job [10903,10912]
===
match
---
name: assert_not_called [15149,15166]
name: assert_not_called [15149,15166]
===
match
---
trailer [20000,20027]
trailer [20000,20027]
===
match
---
parameters [17541,17547]
parameters [17541,17547]
===
match
---
name: terminate [7072,7081]
name: terminate [7072,7081]
===
match
---
name: return_value [8302,8314]
name: return_value [8302,8314]
===
match
---
operator: = [19086,19087]
operator: = [19086,19087]
===
match
---
string: 'r' [23260,23263]
string: 'r' [23440,23443]
===
match
---
operator: , [21393,21394]
operator: , [21393,21394]
===
match
---
name: keys [6373,6377]
name: keys [6373,6377]
===
match
---
operator: @ [15174,15175]
operator: @ [15174,15175]
===
match
---
simple_stmt [1182,1246]
simple_stmt [1182,1246]
===
match
---
funcdef [2790,2840]
funcdef [2790,2840]
===
match
---
arglist [10817,10850]
arglist [10817,10850]
===
match
---
expr_stmt [21164,21202]
expr_stmt [21164,21202]
===
match
---
operator: = [23026,23027]
operator: = [23029,23030]
===
match
---
atom_expr [19181,19217]
atom_expr [19181,19217]
===
match
---
param [3489,3497]
param [3489,3497]
===
match
---
assert_stmt [22034,22077]
assert_stmt [22034,22077]
===
match
---
atom_expr [21881,21909]
atom_expr [21881,21909]
===
match
---
operator: , [17503,17504]
operator: , [17503,17504]
===
match
---
trailer [8909,8918]
trailer [8909,8918]
===
match
---
argument [10517,10540]
argument [10517,10540]
===
match
---
trailer [22545,22551]
trailer [22545,22551]
===
match
---
dotted_name [14341,14351]
dotted_name [14341,14351]
===
match
---
simple_stmt [11189,11214]
simple_stmt [11189,11214]
===
match
---
name: create_session [10559,10573]
name: create_session [10559,10573]
===
match
---
name: create_session [1730,1744]
name: create_session [1730,1744]
===
match
---
expr_stmt [3619,3631]
expr_stmt [3619,3631]
===
match
---
name: patch [22194,22199]
name: patch [22194,22199]
===
match
---
testlist_comp [19927,19961]
testlist_comp [19927,19961]
===
match
---
name: send [3572,3576]
name: send [3572,3576]
===
match
---
operator: = [9329,9330]
operator: = [9329,9330]
===
match
---
simple_stmt [15022,15067]
simple_stmt [15022,15067]
===
match
---
trailer [18489,18495]
trailer [18489,18495]
===
match
---
name: run_processor_manager_one_loop [4788,4818]
name: run_processor_manager_one_loop [4788,4818]
===
match
---
operator: = [5508,5509]
operator: = [5508,5509]
===
match
---
operator: , [12274,12275]
operator: , [12274,12275]
===
match
---
trailer [17817,17838]
trailer [17817,17838]
===
match
---
name: set_file_paths [8026,8040]
name: set_file_paths [8026,8040]
===
match
---
simple_stmt [4783,4841]
simple_stmt [4783,4841]
===
match
---
argument [5525,5542]
argument [5525,5542]
===
match
---
argument [16132,16142]
argument [16132,16142]
===
match
---
comparison [11728,11780]
comparison [11728,11780]
===
match
---
comparison [20072,20154]
comparison [20072,20154]
===
match
---
operator: = [17157,17158]
operator: = [17157,17158]
===
match
---
expr_stmt [5650,5670]
expr_stmt [5650,5670]
===
match
---
simple_stmt [14100,14145]
simple_stmt [14100,14145]
===
match
---
simple_stmt [6336,6380]
simple_stmt [6336,6380]
===
match
---
name: processor_factory_mock [5383,5405]
name: processor_factory_mock [5383,5405]
===
match
---
trailer [6298,6326]
trailer [6298,6326]
===
match
---
argument [8209,8234]
argument [8209,8234]
===
match
---
argument [6823,6833]
argument [6823,6833]
===
match
---
name: backend [4914,4921]
name: backend [4914,4921]
===
match
---
operator: @ [15227,15228]
operator: @ [15227,15228]
===
match
---
name: TestOpenMaybeZipped [22086,22105]
name: TestOpenMaybeZipped [22086,22105]
===
match
---
name: remove [18242,18248]
name: remove [18242,18248]
===
match
---
operator: = [12214,12215]
operator: = [12214,12215]
===
match
---
name: patch [21016,21021]
name: patch [21016,21021]
===
match
---
name: mock_pid [14484,14492]
name: mock_pid [14484,14492]
===
match
---
operator: , [15781,15782]
operator: , [15781,15782]
===
match
---
name: configuration [1034,1047]
name: configuration [1034,1047]
===
match
---
atom [5706,5730]
atom [5706,5730]
===
match
---
name: new_callable [13399,13411]
name: new_callable [13399,13411]
===
match
---
funcdef [10003,13324]
funcdef [10003,13324]
===
match
---
simple_stmt [22333,22403]
simple_stmt [22333,22403]
===
match
---
atom_expr [11942,12013]
atom_expr [11942,12013]
===
match
---
suite [22125,23336]
suite [22125,23516]
===
match
---
name: dag_ids [19881,19888]
name: dag_ids [19881,19888]
===
match
---
simple_stmt [3665,3693]
simple_stmt [3665,3693]
===
match
---
name: dag_directory [7473,7486]
name: dag_directory [7473,7486]
===
match
---
name: task_id [9779,9786]
name: task_id [9779,9786]
===
match
---
dictorsetmaker [14123,14143]
dictorsetmaker [14123,14143]
===
match
---
name: assert_called_once_with [22343,22366]
name: assert_called_once_with [22343,22366]
===
match
---
atom_expr [11680,11702]
atom_expr [11680,11702]
===
match
---
name: signal_conn [5464,5475]
name: signal_conn [5464,5475]
===
match
---
name: DagFileProcessorManager [8172,8195]
name: DagFileProcessorManager [8172,8195]
===
match
---
operator: == [9400,9402]
operator: == [9400,9402]
===
match
---
atom_expr [21838,21864]
atom_expr [21838,21864]
===
match
---
not_test [18618,18632]
not_test [18618,18632]
===
match
---
name: manager [14153,14160]
name: manager [14153,14160]
===
match
---
operator: = [11940,11941]
operator: = [11940,11941]
===
match
---
operator: , [2072,2073]
operator: , [2072,2073]
===
match
---
name: conf [19181,19185]
name: conf [19181,19185]
===
match
---
trailer [18495,18514]
trailer [18495,18514]
===
match
---
name: mocked_zip_file [23191,23206]
name: mocked_zip_file [23371,23386]
===
match
---
operator: , [6772,6773]
operator: , [6772,6773]
===
match
---
assert_stmt [21874,21914]
assert_stmt [21874,21914]
===
match
---
param [2395,2404]
param [2395,2404]
===
match
---
atom_expr [4509,4563]
atom_expr [4509,4563]
===
match
---
name: processor_timeout [13784,13801]
name: processor_timeout [13784,13801]
===
match
---
argument [7592,7623]
argument [7592,7623]
===
match
---
assert_stmt [6440,6483]
assert_stmt [6440,6483]
===
match
---
name: DEFAULT_DATE [2827,2839]
name: DEFAULT_DATE [2827,2839]
===
match
---
atom_expr [15742,15807]
atom_expr [15742,15807]
===
match
---
operator: { [8092,8093]
operator: { [8092,8093]
===
match
---
atom [7333,7335]
atom [7333,7335]
===
match
---
assert_stmt [12732,12785]
assert_stmt [12732,12785]
===
match
---
operator: = [5704,5705]
operator: = [5704,5705]
===
match
---
atom_expr [14198,14233]
atom_expr [14198,14233]
===
match
---
arglist [6299,6325]
arglist [6299,6325]
===
match
---
trailer [15109,15111]
trailer [15109,15111]
===
match
---
operator: , [18943,18944]
operator: , [18943,18944]
===
match
---
name: manager [5255,5262]
name: manager [5255,5262]
===
match
---
operator: , [6318,6319]
operator: , [6318,6319]
===
match
---
operator: = [11445,11446]
operator: = [11445,11446]
===
match
---
operator: = [21223,21224]
operator: = [21223,21224]
===
match
---
name: processor_timeout [5419,5436]
name: processor_timeout [5419,5436]
===
match
---
atom_expr [19669,19704]
atom_expr [19669,19704]
===
match
---
return_stmt [3122,3258]
return_stmt [3122,3258]
===
match
---
name: file_1 [6343,6349]
name: file_1 [6343,6349]
===
match
---
name: callbacks [3238,3247]
name: callbacks [3238,3247]
===
match
---
trailer [7619,7623]
trailer [7619,7623]
===
match
---
trailer [11585,11590]
trailer [11585,11590]
===
match
---
name: child_pipe [4849,4859]
name: child_pipe [4849,4859]
===
match
---
operator: = [6758,6759]
operator: = [6758,6759]
===
match
---
string: '/path/to/archive.zip' [23231,23253]
string: '/path/to/archive.zip' [23411,23433]
===
match
---
trailer [7266,7281]
trailer [7266,7281]
===
match
---
operator: = [10878,10879]
operator: = [10878,10879]
===
match
---
operator: , [2371,2372]
operator: , [2371,2372]
===
match
---
simple_stmt [2621,2642]
simple_stmt [2621,2642]
===
match
---
name: DagFileProcessorManager [16030,16053]
name: DagFileProcessorManager [16030,16053]
===
match
---
name: query [16752,16757]
name: query [16752,16757]
===
match
---
with_item [22189,22263]
with_item [22189,22263]
===
match
---
decorated [3264,3342]
decorated [3264,3342]
===
match
---
atom_expr [3320,3341]
atom_expr [3320,3341]
===
match
---
name: FakeDagFileProcessorRunner [11942,11968]
name: FakeDagFileProcessorRunner [11942,11968]
===
match
---
operator: , [13549,13550]
operator: , [13549,13550]
===
match
---
name: _processors [15030,15041]
name: _processors [15030,15041]
===
match
---
trailer [19060,19062]
trailer [19060,19062]
===
match
---
name: len [12690,12693]
name: len [12690,12693]
===
match
---
atom_expr [17986,18041]
atom_expr [17986,18041]
===
match
---
operator: = [21428,21429]
operator: = [21428,21429]
===
match
---
simple_stmt [1006,1020]
simple_stmt [1006,1020]
===
match
---
comp_op [19174,19180]
comp_op [19174,19180]
===
match
---
atom_expr [3427,3442]
atom_expr [3427,3442]
===
match
---
import_from [1307,1365]
import_from [1307,1365]
===
match
---
string: """         Check that the same set of failure callback with zombies are passed to the dag         file processors until the next zombie detection logic is invoked.         """ [10107,10283]
string: """         Check that the same set of failure callback with zombies are passed to the dag         file processors until the next zombie detection logic is invoked.         """ [10107,10283]
===
match
---
atom_expr [8904,8918]
atom_expr [8904,8918]
===
match
---
name: execution_date [9853,9867]
name: execution_date [9853,9867]
===
match
---
atom_expr [8572,8588]
atom_expr [8572,8588]
===
match
---
simple_stmt [5621,5642]
simple_stmt [5621,5642]
===
match
---
string: "zipfile.ZipFile" [22770,22787]
string: "zipfile.ZipFile" [22770,22787]
===
match
---
operator: = [8551,8552]
operator: = [8551,8552]
===
match
---
expr_stmt [21423,21471]
expr_stmt [21423,21471]
===
match
---
name: file_2 [5621,5627]
name: file_2 [5621,5627]
===
match
---
if_stmt [3801,3947]
if_stmt [3801,3947]
===
match
---
name: expected_failure_callback_requests [13125,13159]
name: expected_failure_callback_requests [13125,13159]
===
match
---
funcdef [2859,2894]
funcdef [2859,2894]
===
match
---
name: DagFileProcessorManager [7436,7459]
name: DagFileProcessorManager [7436,7459]
===
match
---
operator: } [18970,18971]
operator: } [18970,18971]
===
match
---
suite [19783,20155]
suite [19783,20155]
===
match
---
name: mock_pid [13562,13570]
name: mock_pid [13562,13570]
===
match
---
trailer [18904,18918]
trailer [18904,18918]
===
match
---
operator: = [9180,9181]
operator: = [9180,9181]
===
match
---
operator: = [4508,4509]
operator: = [4508,4509]
===
match
---
simple_stmt [16020,16373]
simple_stmt [16020,16373]
===
match
---
arglist [10321,10369]
arglist [10321,10369]
===
match
---
name: path [15728,15732]
name: path [15728,15732]
===
match
---
param [21096,21113]
param [21096,21113]
===
match
---
name: _kill_timed_out_processors [15083,15109]
name: _kill_timed_out_processors [15083,15109]
===
match
---
name: get [4325,4328]
name: get [4325,4328]
===
match
---
name: processor_agent [19669,19684]
name: processor_agent [19669,19684]
===
match
---
comp_op [18076,18082]
comp_op [18076,18082]
===
match
---
testlist_star_expr [2731,2735]
testlist_star_expr [2731,2735]
===
match
---
trailer [13039,13058]
trailer [13039,13058]
===
match
---
name: manager [7259,7266]
name: manager [7259,7266]
===
match
---
if_stmt [12565,12920]
if_stmt [12565,12920]
===
match
---
simple_stmt [5679,5731]
simple_stmt [5679,5731]
===
match
---
simple_stmt [11794,11815]
simple_stmt [11794,11815]
===
match
---
expr_stmt [7057,7100]
expr_stmt [7057,7100]
===
match
---
name: models [1320,1326]
name: models [1320,1326]
===
match
---
import_as_names [1942,1996]
import_as_names [1942,1996]
===
match
---
trailer [14187,14189]
trailer [14187,14189]
===
match
---
expr_stmt [22973,23034]
expr_stmt [22985,23037]
===
match
---
parameters [17389,17431]
parameters [17389,17431]
===
match
---
trailer [20842,20866]
trailer [20842,20866]
===
match
---
trailer [6466,6483]
trailer [6466,6483]
===
match
---
name: result [2972,2978]
name: result [2972,2978]
===
match
---
name: settings_context [1847,1863]
name: settings_context [1847,1863]
===
match
---
name: MagicMock [7649,7658]
name: MagicMock [7649,7658]
===
match
---
operator: , [17399,17400]
operator: , [17399,17400]
===
match
---
name: mock_pid [13581,13589]
name: mock_pid [13581,13589]
===
match
---
operator: , [19924,19925]
operator: , [19924,19925]
===
match
---
suite [13572,14234]
suite [13572,14234]
===
match
---
simple_stmt [18579,18603]
simple_stmt [18579,18603]
===
match
---
argument [13812,13821]
argument [13812,13821]
===
match
---
name: run_single_parsing_loop [20843,20866]
name: run_single_parsing_loop [20843,20866]
===
match
---
atom_expr [8613,8639]
atom_expr [8613,8639]
===
match
---
operator: = [8345,8346]
operator: = [8345,8346]
===
match
---
trailer [9798,9801]
trailer [9798,9801]
===
match
---
atom_expr [10814,10851]
atom_expr [10814,10851]
===
match
---
trailer [3818,3839]
trailer [3818,3839]
===
match
---
decorated [2776,2840]
decorated [2776,2840]
===
match
---
name: simple_task_instance [9883,9903]
name: simple_task_instance [9883,9903]
===
match
---
operator: = [13801,13802]
operator: = [13801,13802]
===
match
---
trailer [19090,19095]
trailer [19090,19095]
===
match
---
number: 0 [12825,12826]
number: 0 [12825,12826]
===
match
---
suite [4141,4896]
suite [4141,4896]
===
match
---
atom_expr [15988,16010]
atom_expr [15988,16010]
===
match
---
name: zombies [17401,17408]
name: zombies [17401,17408]
===
match
---
name: mock_open [23007,23016]
name: mock_open [23010,23019]
===
match
---
simple_stmt [13581,13610]
simple_stmt [13581,13610]
===
match
---
string: 'abc.txt' [14000,14009]
string: 'abc.txt' [14000,14009]
===
match
---
number: 0 [22022,22023]
number: 0 [22022,22023]
===
match
---
name: patch [21298,21303]
name: patch [21298,21303]
===
match
---
atom [13881,13883]
atom [13881,13883]
===
match
---
name: isfile [20934,20940]
name: isfile [20934,20940]
===
match
---
string: 'core' [20317,20323]
string: 'core' [20317,20323]
===
match
---
operator: @ [2954,2955]
operator: @ [2954,2955]
===
match
---
name: DagFileProcessorManager [14550,14573]
name: DagFileProcessorManager [14550,14573]
===
match
---
trailer [16710,16712]
trailer [16710,16712]
===
match
---
simple_stmt [889,929]
simple_stmt [889,929]
===
match
---
trailer [10667,10697]
trailer [10667,10697]
===
match
---
name: max_runs [6661,6669]
name: max_runs [6661,6669]
===
match
---
name: self [17220,17224]
name: self [17220,17224]
===
match
---
name: test_dag_with_system_exit [15270,15295]
name: test_dag_with_system_exit [15270,15295]
===
match
---
atom_expr [7649,7660]
atom_expr [7649,7660]
===
match
---
name: DagBag [10495,10501]
name: DagBag [10495,10501]
===
match
---
operator: == [12915,12917]
operator: == [12915,12917]
===
match
---
operator: ** [11862,11864]
operator: ** [11862,11864]
===
match
---
simple_stmt [811,821]
simple_stmt [811,821]
===
match
---
arglist [19279,19364]
arglist [19279,19364]
===
match
---
name: dag_directory [14587,14600]
name: dag_directory [14587,14600]
===
match
---
trailer [11695,11700]
trailer [11695,11700]
===
match
---
arglist [9631,9683]
arglist [9631,9683]
===
match
---
name: TestCase [22115,22123]
name: TestCase [22115,22123]
===
match
---
import_as_name [1100,1118]
import_as_name [1100,1118]
===
match
---
name: SimpleTaskInstance [11446,11464]
name: SimpleTaskInstance [11446,11464]
===
match
---
simple_stmt [9554,9601]
simple_stmt [9554,9601]
===
match
---
name: assert_called_once_with [23287,23310]
name: assert_called_once_with [23467,23490]
===
match
---
atom_expr [21940,21975]
atom_expr [21940,21975]
===
match
---
name: _start_time [14044,14055]
name: _start_time [14044,14055]
===
match
---
argument [5464,5487]
argument [5464,5487]
===
match
---
expr_stmt [14034,14091]
expr_stmt [14034,14091]
===
match
---
comp_op [4313,4319]
comp_op [4313,4319]
===
match
---
if_stmt [20796,20869]
if_stmt [20796,20869]
===
match
---
string: 'directory' [8223,8234]
string: 'directory' [8223,8234]
===
match
---
simple_stmt [19152,19218]
simple_stmt [19152,19218]
===
match
---
argument [7637,7660]
argument [7637,7660]
===
match
---
expr_stmt [13581,13609]
expr_stmt [13581,13609]
===
match
---
operator: = [6858,6859]
operator: = [6858,6859]
===
match
---
dotted_name [1065,1092]
dotted_name [1065,1092]
===
match
---
name: test_dag_path [12772,12785]
name: test_dag_path [12772,12785]
===
match
---
string: 'logging' [20378,20387]
string: 'logging' [20378,20387]
===
match
---
argument [4698,4715]
argument [4698,4715]
===
match
---
trailer [5288,5582]
trailer [5288,5582]
===
match
---
operator: = [8508,8509]
operator: = [8508,8509]
===
match
---
name: manager [9242,9249]
name: manager [9242,9249]
===
match
---
operator: , [18480,18481]
operator: , [18480,18481]
===
match
---
operator: = [8222,8223]
operator: = [8222,8223]
===
match
---
operator: , [7230,7231]
operator: , [7230,7231]
===
match
---
number: 0 [2731,2732]
number: 0 [2731,2732]
===
match
---
simple_stmt [15311,15410]
simple_stmt [15311,15410]
===
match
---
trailer [20373,20377]
trailer [20373,20377]
===
match
---
trailer [15082,15109]
trailer [15082,15109]
===
match
---
name: conf_vars [4051,4060]
name: conf_vars [4051,4060]
===
match
---
string: "empty-airflow-dags-" [4240,4261]
string: "empty-airflow-dags-" [4240,4261]
===
match
---
suite [10473,13324]
suite [10473,13324]
===
match
---
comparison [22041,22077]
comparison [22041,22077]
===
match
---
classdef [22080,23336]
classdef [22080,23516]
===
match
---
trailer [22896,22909]
trailer [22956,22969]
===
match
---
atom_expr [16960,16971]
atom_expr [16960,16971]
===
match
---
trailer [12959,12970]
trailer [12959,12970]
===
match
---
trailer [13755,13757]
trailer [13755,13757]
===
match
---
dotted_name [22721,22731]
dotted_name [22721,22731]
===
match
---
name: call_args_list [21958,21972]
name: call_args_list [21958,21972]
===
match
---
name: self [18490,18494]
name: self [18490,18494]
===
match
---
parameters [20183,20189]
parameters [20183,20189]
===
match
---
operator: = [19242,19243]
operator: = [19242,19243]
===
match
---
testlist_comp [20084,20153]
testlist_comp [20084,20153]
===
match
---
argument [11997,12002]
argument [11997,12002]
===
match
---
operator: , [2384,2385]
operator: , [2384,2385]
===
match
---
name: return_value [6715,6727]
name: return_value [6715,6727]
===
match
---
dotted_name [1312,1339]
dotted_name [1312,1339]
===
match
---
atom [8418,8420]
atom [8418,8420]
===
match
---
operator: , [23253,23254]
operator: , [23433,23434]
===
match
---
name: get_task [10758,10766]
name: get_task [10758,10766]
===
match
---
name: mock_processor [6914,6928]
name: mock_processor [6914,6928]
===
match
---
atom_expr [19047,19062]
atom_expr [19047,19062]
===
match
---
operator: , [1845,1846]
operator: , [1845,1846]
===
match
---
operator: = [13974,13975]
operator: = [13974,13975]
===
match
---
operator: = [16244,16245]
operator: = [16244,16245]
===
match
---
name: isfile [18898,18904]
name: isfile [18898,18904]
===
match
---
name: async_mode [16346,16356]
name: async_mode [16346,16356]
===
match
---
simple_stmt [2820,2840]
simple_stmt [2820,2840]
===
match
---
import_name [788,810]
import_name [788,810]
===
match
---
expr_stmt [18132,18204]
expr_stmt [18132,18204]
===
match
---
trailer [9359,9378]
trailer [9359,9378]
===
match
---
operator: = [8445,8446]
operator: = [8445,8446]
===
match
---
operator: = [4175,4176]
operator: = [4175,4176]
===
match
---
simple_stmt [22277,22321]
simple_stmt [22277,22321]
===
match
---
name: parent_pipe [4828,4839]
name: parent_pipe [4828,4839]
===
match
---
param [22169,22173]
param [22169,22173]
===
match
---
operator: = [14056,14057]
operator: = [14056,14057]
===
match
---
name: unittest [22106,22114]
name: unittest [22106,22114]
===
match
---
name: TestCase [3387,3395]
name: TestCase [3387,3395]
===
match
---
operator: = [12454,12455]
operator: = [12454,12455]
===
match
---
name: append [12046,12052]
name: append [12046,12052]
===
match
---
simple_stmt [20279,20345]
simple_stmt [20279,20345]
===
match
---
atom_expr [2016,2092]
atom_expr [2016,2092]
===
match
---
name: mock_file [22665,22674]
name: mock_file [22665,22674]
===
match
---
simple_stmt [21423,21472]
simple_stmt [21423,21472]
===
match
---
operator: , [14307,14308]
operator: , [14307,14308]
===
match
---
name: path [21598,21602]
name: path [21598,21602]
===
match
---
name: clear_db_dags [1942,1955]
name: clear_db_dags [1942,1955]
===
match
---
string: 'test_start_date_scheduling' [19894,19922]
string: 'test_start_date_scheduling' [19894,19922]
===
match
---
trailer [6424,6429]
trailer [6424,6429]
===
match
---
assert_stmt [12887,12919]
assert_stmt [12887,12919]
===
match
---
name: task [10747,10751]
name: task [10747,10751]
===
match
---
testlist_star_expr [2557,2575]
testlist_star_expr [2557,2575]
===
match
---
atom_expr [6985,7048]
atom_expr [6985,7048]
===
match
---
name: session [19775,19782]
name: session [19775,19782]
===
match
---
operator: = [4433,4434]
operator: = [4433,4434]
===
match
---
not_test [19543,19557]
not_test [19543,19557]
===
match
---
string: 'sql_alchemy_conn' [4337,4355]
string: 'sql_alchemy_conn' [4337,4355]
===
match
---
name: readable [2699,2707]
name: readable [2699,2707]
===
match
---
atom_expr [9932,9958]
atom_expr [9932,9958]
===
match
---
operator: = [20213,20214]
operator: = [20213,20214]
===
match
---
trailer [10393,10472]
trailer [10393,10472]
===
match
---
name: execution_date [9904,9918]
name: execution_date [9904,9918]
===
match
---
decorators [14239,14406]
decorators [14239,14406]
===
match
---
expr_stmt [20199,20270]
expr_stmt [20199,20270]
===
match
---
funcdef [17519,18919]
funcdef [17519,18919]
===
match
---
operator: = [9007,9008]
operator: = [9007,9008]
===
match
---
suite [19003,20155]
suite [19003,20155]
===
match
---
string: "dag_id" [20037,20045]
string: "dag_id" [20037,20045]
===
match
---
expr_stmt [4151,4199]
expr_stmt [4151,4199]
===
match
---
simple_stmt [10714,10731]
simple_stmt [10714,10731]
===
match
---
name: timedelta [8346,8355]
name: timedelta [8346,8355]
===
match
---
operator: = [14600,14601]
operator: = [14600,14601]
===
match
---
param [3100,3111]
param [3100,3111]
===
match
---
trailer [16436,16441]
trailer [16436,16441]
===
match
---
trailer [6360,6372]
trailer [6360,6372]
===
match
---
number: 0 [7247,7248]
number: 0 [7247,7248]
===
match
---
if_stmt [3520,3610]
if_stmt [3520,3610]
===
match
---
name: local_job [8886,8895]
name: local_job [8886,8895]
===
match
---
name: assert_called_once_with [23135,23158]
name: assert_called_once_with [23315,23338]
===
match
---
name: join [11586,11590]
name: join [11586,11590]
===
match
---
name: session [10604,10611]
name: session [10604,10611]
===
match
---
expr_stmt [20607,20755]
expr_stmt [20607,20755]
===
match
---
expr_stmt [21923,21975]
expr_stmt [21923,21975]
===
match
---
atom [6316,6318]
atom [6316,6318]
===
match
---
name: FakeDagFileProcessorRunner [2147,2173]
name: FakeDagFileProcessorRunner [2147,2173]
===
match
---
operator: == [9714,9716]
operator: == [9714,9716]
===
match
---
atom_expr [11744,11780]
atom_expr [11744,11780]
===
match
---
trailer [20027,20036]
trailer [20027,20036]
===
match
---
operator: = [7553,7554]
operator: = [7553,7554]
===
match
---
param [3080,3090]
param [3080,3090]
===
match
---
simple_stmt [8886,8919]
simple_stmt [8886,8919]
===
match
---
trailer [7922,7932]
trailer [7922,7932]
===
match
---
name: TEST_DAG_FOLDER [11591,11606]
name: TEST_DAG_FOLDER [11591,11606]
===
match
---
name: _result [2721,2728]
name: _result [2721,2728]
===
match
---
simple_stmt [8997,9022]
simple_stmt [8997,9022]
===
match
---
name: mock [969,973]
name: mock [969,973]
===
match
---
trailer [18449,18566]
trailer [18449,18566]
===
match
---
operator: , [6671,6672]
operator: , [6671,6672]
===
match
---
name: dag_id [9707,9713]
name: dag_id [9707,9713]
===
match
---
name: processor_agent [18650,18665]
name: processor_agent [18650,18665]
===
match
---
argument [23255,23263]
argument [23435,23443]
===
match
---
name: path [21124,21128]
name: path [21124,21128]
===
match
---
simple_stmt [8967,8984]
simple_stmt [8967,8984]
===
match
---
param [11855,11861]
param [11855,11861]
===
match
---
operator: , [2463,2464]
operator: , [2463,2464]
===
match
---
atom_expr [4214,4262]
atom_expr [4214,4262]
===
match
---
expr_stmt [5255,5582]
expr_stmt [5255,5582]
===
match
---
operator: = [13712,13713]
operator: = [13712,13713]
===
match
---
trailer [19640,19650]
trailer [19640,19650]
===
match
---
param [22828,22833]
param [22864,22869]
===
match
---
suite [16456,16586]
suite [16456,16586]
===
match
---
name: mock [22759,22763]
name: mock [22759,22763]
===
match
---
name: async_mode [8465,8475]
name: async_mode [8465,8475]
===
match
---
string: 'sqlite' [19165,19173]
string: 'sqlite' [19165,19173]
===
match
---
trailer [10842,10850]
trailer [10842,10850]
===
match
---
trailer [11342,11530]
trailer [11342,11530]
===
match
---
if_stmt [19540,19613]
if_stmt [19540,19613]
===
match
---
string: 'logging' [18156,18165]
string: 'logging' [18156,18165]
===
match
---
dictorsetmaker [18936,18970]
dictorsetmaker [18936,18970]
===
match
---
operator: , [1621,1622]
operator: , [1621,1622]
===
match
---
testlist_comp [19893,19962]
testlist_comp [19893,19962]
===
match
---
operator: , [18533,18534]
operator: , [18533,18534]
===
match
---
with_stmt [4209,4841]
with_stmt [4209,4841]
===
match
---
suite [19433,19488]
suite [19433,19488]
===
match
---
trailer [8630,8637]
trailer [8630,8637]
===
match
---
param [22464,22468]
param [22464,22468]
===
match
---
atom_expr [7436,7755]
atom_expr [7436,7755]
===
match
---
operator: = [22241,22242]
operator: = [22241,22242]
===
match
---
if_stmt [17206,17278]
if_stmt [17206,17278]
===
match
---
operator: , [19960,19961]
operator: , [19960,19961]
===
match
---
string: "data" [22594,22600]
string: "data" [22594,22600]
===
match
---
atom_expr [5901,5930]
atom_expr [5901,5930]
===
match
---
suite [2985,3014]
suite [2985,3014]
===
match
---
name: conf [20308,20312]
name: conf [20308,20312]
===
match
---
atom_expr [10714,10730]
atom_expr [10714,10730]
===
match
---
trailer [19836,19845]
trailer [19836,19845]
===
match
---
trailer [2720,2728]
trailer [2720,2728]
===
match
---
trailer [18892,18897]
trailer [18892,18897]
===
match
---
name: timedelta [13802,13811]
name: timedelta [13802,13811]
===
match
---
trailer [20316,20344]
trailer [20316,20344]
===
match
---
name: AttributeError [7836,7850]
name: AttributeError [7836,7850]
===
match
---
atom [20724,20726]
atom [20724,20726]
===
match
---
name: self [4783,4787]
name: self [4783,4787]
===
match
---
name: airflow [1371,1378]
name: airflow [1371,1378]
===
match
---
arglist [3819,3838]
arglist [3819,3838]
===
match
---
name: max_runs [14626,14634]
name: max_runs [14626,14634]
===
match
---
name: _processors [7118,7129]
name: _processors [7118,7129]
===
match
---
parameters [4994,5000]
parameters [4994,5000]
===
match
---
name: file_paths [16665,16675]
name: file_paths [16665,16675]
===
match
---
name: os [20926,20928]
name: os [20926,20928]
===
match
---
simple_stmt [7908,7952]
simple_stmt [7908,7952]
===
match
---
comparison [21584,21602]
comparison [21584,21602]
===
match
---
name: test_kill_timed_out_processors_kill [13509,13544]
name: test_kill_timed_out_processors_kill [13509,13544]
===
match
---
name: airflow [1065,1072]
name: airflow [1065,1072]
===
match
---
simple_stmt [5821,5863]
simple_stmt [5821,5863]
===
match
---
simple_stmt [19977,20053]
simple_stmt [19977,20053]
===
match
---
atom_expr [9126,9143]
atom_expr [9126,9143]
===
match
---
trailer [10573,10575]
trailer [10573,10575]
===
match
---
name: processor_factory [5365,5382]
name: processor_factory [5365,5382]
===
match
---
operator: , [8234,8235]
operator: , [8234,8235]
===
match
---
name: terminate [7923,7932]
name: terminate [7923,7932]
===
match
---
param [14453,14458]
param [14453,14458]
===
match
---
argument [4233,4261]
argument [4233,4261]
===
match
---
name: processor [14134,14143]
name: processor [14134,14143]
===
match
---
trailer [3875,3880]
trailer [3875,3880]
===
match
---
operator: @ [2899,2900]
operator: @ [2899,2900]
===
match
---
number: 10 [15258,15260]
number: 10 [15258,15260]
===
match
---
trailer [17272,17277]
trailer [17272,17277]
===
match
---
parameters [2355,2405]
parameters [2355,2405]
===
match
---
name: mock [22189,22193]
name: mock [22189,22193]
===
match
---
name: type [19297,19301]
name: type [19297,19301]
===
match
---
operator: = [2014,2015]
operator: = [2014,2015]
===
match
---
name: MagicMock [5476,5485]
name: MagicMock [5476,5485]
===
match
---
name: dag_id [19829,19835]
name: dag_id [19829,19835]
===
match
---
atom_expr [10880,10886]
atom_expr [10880,10886]
===
match
---
name: setUp [3406,3411]
name: setUp [3406,3411]
===
match
---
name: mocked_is_zipfile [21480,21497]
name: mocked_is_zipfile [21480,21497]
===
match
---
argument [4630,4652]
argument [4630,4652]
===
match
---
trailer [16771,16779]
trailer [16771,16779]
===
match
---
name: patch [14346,14351]
name: patch [14346,14351]
===
match
---
trailer [14086,14090]
trailer [14086,14090]
===
match
---
operator: , [14020,14021]
operator: , [14020,14021]
===
match
---
operator: , [3247,3248]
operator: , [3247,3248]
===
match
---
atom_expr [8805,8842]
atom_expr [8805,8842]
===
match
---
arglist [4922,4941]
arglist [4922,4941]
===
match
---
expr_stmt [21825,21864]
expr_stmt [21825,21864]
===
match
---
operator: , [12188,12189]
operator: , [12188,12189]
===
match
---
operator: @ [14239,14240]
operator: @ [14239,14240]
===
match
---
trailer [4865,4867]
trailer [4865,4867]
===
match
---
name: get [20313,20316]
name: get [20313,20316]
===
match
---
trailer [6714,6727]
trailer [6714,6727]
===
match
---
trailer [9510,9513]
trailer [9510,9513]
===
match
---
trailer [8943,8954]
trailer [8943,8954]
===
match
---
operator: = [22593,22594]
operator: = [22593,22594]
===
match
---
name: patch [14245,14250]
name: patch [14245,14250]
===
match
---
simple_stmt [8800,8843]
simple_stmt [8800,8843]
===
match
---
string: 'DagFileProcessor object has no attribute stop' [7851,7898]
string: 'DagFileProcessor object has no attribute stop' [7851,7898]
===
match
---
name: mock [14240,14244]
name: mock [14240,14244]
===
match
---
simple_stmt [2716,2736]
simple_stmt [2716,2736]
===
match
---
argument [8410,8420]
argument [8410,8420]
===
match
---
and_test [16512,16562]
and_test [16512,16562]
===
match
---
trailer [18689,18691]
trailer [18689,18691]
===
match
---
name: conf_vars [18925,18934]
name: conf_vars [18925,18934]
===
match
---
name: self [15296,15300]
name: self [15296,15300]
===
match
---
name: AGENT_RUN_ONCE [3594,3608]
name: AGENT_RUN_ONCE [3594,3608]
===
match
---
operator: = [6583,6584]
operator: = [6583,6584]
===
match
---
expr_stmt [19072,19143]
expr_stmt [19072,19143]
===
match
---
operator: = [8656,8657]
operator: = [8656,8657]
===
match
---
atom [19343,19345]
atom [19343,19345]
===
match
---
name: _last_zombie_query_time [9100,9123]
name: _last_zombie_query_time [9100,9123]
===
match
---
name: self [22828,22832]
name: self [22864,22868]
===
match
---
name: task [8808,8812]
name: task [8808,8812]
===
match
---
operator: , [13397,13398]
operator: , [13397,13398]
===
match
---
suite [21709,22078]
suite [21709,22078]
===
match
---
argument [12161,12188]
argument [12161,12188]
===
match
---
name: os [15742,15744]
name: os [15742,15744]
===
match
---
atom [11812,11814]
atom [11812,11814]
===
match
---
expr_stmt [13618,13954]
expr_stmt [13618,13954]
===
match
---
string: 'sql_alchemy_conn' [19198,19216]
string: 'sql_alchemy_conn' [19198,19216]
===
match
---
atom_expr [20827,20868]
atom_expr [20827,20868]
===
match
---
arglist [22367,22401]
arglist [22367,22401]
===
match
---
operator: , [13914,13915]
operator: , [13914,13915]
===
match
---
trailer [22221,22231]
trailer [22221,22231]
===
match
---
operator: { [13164,13165]
operator: { [13164,13165]
===
match
---
trailer [8195,8491]
trailer [8195,8491]
===
match
---
name: dag_ids [5501,5508]
name: dag_ids [5501,5508]
===
match
---
assert_stmt [12802,12852]
assert_stmt [12802,12852]
===
match
---
operator: , [11399,11400]
operator: , [11399,11400]
===
match
---
atom_expr [15725,15808]
atom_expr [15725,15808]
===
match
---
operator: = [17984,17985]
operator: = [17984,17985]
===
match
---
for_stmt [17287,17344]
for_stmt [17287,17344]
===
match
---
name: instance [23273,23281]
name: instance [23453,23461]
===
match
---
name: zombie [13115,13121]
name: zombie [13115,13121]
===
match
---
operator: , [16094,16095]
operator: , [16094,16095]
===
match
---
expr_stmt [18410,18566]
expr_stmt [18410,18566]
===
match
---
name: pickle_dags [3192,3203]
name: pickle_dags [3192,3203]
===
match
---
name: state [10913,10918]
name: state [10913,10918]
===
match
---
name: Pipe [2594,2598]
name: Pipe [2594,2598]
===
match
---
trailer [9263,9265]
trailer [9263,9265]
===
match
---
name: MagicMock [6931,6940]
name: MagicMock [6931,6940]
===
match
---
atom_expr [14956,14977]
atom_expr [14956,14977]
===
match
---
simple_stmt [17323,17344]
simple_stmt [17323,17344]
===
match
---
classdef [3344,16792]
classdef [3344,16792]
===
match
---
trailer [7182,7194]
trailer [7182,7194]
===
match
---
atom [12850,12852]
atom [12850,12852]
===
match
---
operator: - [9144,9145]
operator: - [9144,9145]
===
match
---
expr_stmt [6951,7048]
expr_stmt [6951,7048]
===
match
---
param [2922,2926]
param [2922,2926]
===
match
---
atom_expr [18485,18514]
atom_expr [18485,18514]
===
match
---
name: processor [14956,14965]
name: processor [14956,14965]
===
match
---
trailer [7194,7214]
trailer [7194,7214]
===
match
---
operator: , [12391,12392]
operator: , [12391,12392]
===
match
---
simple_stmt [23117,23183]
simple_stmt [23297,23363]
===
match
---
name: SimpleTaskInstance [9665,9683]
name: SimpleTaskInstance [9665,9683]
===
match
---
name: sys [17181,17184]
name: sys [17181,17184]
===
match
---
trailer [16959,16972]
trailer [16959,16972]
===
match
---
trailer [3868,3875]
trailer [3868,3875]
===
match
---
name: open [23282,23286]
name: open [23462,23466]
===
match
---
expr_stmt [20354,20426]
expr_stmt [20354,20426]
===
match
---
trailer [22342,22366]
trailer [22342,22366]
===
match
---
simple_stmt [22879,22917]
simple_stmt [22939,22977]
===
match
---
trailer [9444,9447]
trailer [9444,9447]
===
match
---
operator: = [4239,4240]
operator: = [4239,4240]
===
match
---
expr_stmt [19226,19374]
expr_stmt [19226,19374]
===
match
---
operator: , [18529,18530]
operator: , [18529,18530]
===
match
---
trailer [19769,19771]
trailer [19769,19771]
===
match
---
simple_stmt [12110,12481]
simple_stmt [12110,12481]
===
match
---
atom_expr [11382,11399]
atom_expr [11382,11399]
===
match
---
trailer [13085,13106]
trailer [13085,13106]
===
match
---
trailer [14921,14947]
trailer [14921,14947]
===
match
---
number: 0 [7229,7230]
number: 0 [7229,7230]
===
match
---
trailer [12757,12768]
trailer [12757,12768]
===
match
---
atom [7682,7684]
atom [7682,7684]
===
match
---
operator: == [9518,9520]
operator: == [9518,9520]
===
match
---
suite [3840,3881]
suite [3840,3881]
===
match
---
import_from [1182,1245]
import_from [1182,1245]
===
match
---
name: _waitable_handle [2680,2696]
name: _waitable_handle [2680,2696]
===
match
---
name: async_mode [6878,6888]
name: async_mode [6878,6888]
===
match
---
trailer [10310,10315]
trailer [10310,10315]
===
match
---
name: TEST_DAG_FOLDER [8517,8532]
name: TEST_DAG_FOLDER [8517,8532]
===
match
---
name: State [1777,1782]
name: State [1777,1782]
===
match
---
arglist [12530,12550]
arglist [12530,12550]
===
match
---
name: fake_processors [11898,11913]
name: fake_processors [11898,11913]
===
match
---
name: get [19186,19189]
name: get [19186,19189]
===
match
---
atom_expr [16955,16972]
atom_expr [16955,16972]
===
match
---
name: _process [20894,20902]
name: _process [20894,20902]
===
match
---
import_from [1021,1059]
import_from [1021,1059]
===
match
---
operator: = [21129,21130]
operator: = [21129,21130]
===
match
---
simple_stmt [12802,12853]
simple_stmt [12802,12853]
===
match
---
atom_expr [7175,7214]
atom_expr [7175,7214]
===
match
---
name: _file_stats [7183,7194]
name: _file_stats [7183,7194]
===
match
---
name: __file__ [2062,2070]
name: __file__ [2062,2070]
===
match
---
name: order_by [19837,19845]
name: order_by [19837,19845]
===
match
---
simple_stmt [14153,14190]
simple_stmt [14153,14190]
===
match
---
arglist [14251,14334]
arglist [14251,14334]
===
match
---
operator: = [12352,12353]
operator: = [12352,12353]
===
match
---
name: dag_directory [4420,4433]
name: dag_directory [4420,4433]
===
match
---
argument [14626,14636]
argument [14626,14636]
===
match
---
name: mock [950,954]
name: mock [950,954]
===
match
---
trailer [19398,19404]
trailer [19398,19404]
===
match
---
argument [4463,4473]
argument [4463,4473]
===
match
---
operator: , [8258,8259]
operator: , [8258,8259]
===
match
---
expr_stmt [2716,2735]
expr_stmt [2716,2735]
===
match
---
simple_stmt [22973,23035]
simple_stmt [22985,23038]
===
match
---
dotted_name [13330,13340]
dotted_name [13330,13340]
===
match
---
expr_stmt [11715,11780]
expr_stmt [11715,11780]
===
match
---
trailer [3386,3395]
trailer [3386,3395]
===
match
---
atom_expr [16654,16676]
atom_expr [16654,16676]
===
match
---
operator: , [6833,6834]
operator: , [6833,6834]
===
match
---
expr_stmt [10868,10886]
expr_stmt [10868,10886]
===
match
---
trailer [20227,20270]
trailer [20227,20270]
===
match
---
simple_stmt [1465,1625]
simple_stmt [1465,1625]
===
match
---
trailer [4192,4197]
trailer [4192,4197]
===
match
---
operator: , [6893,6894]
operator: , [6893,6894]
===
match
---
argument [8434,8451]
argument [8434,8451]
===
match
---
comparison [12940,12987]
comparison [12940,12987]
===
match
---
number: 5 [14742,14743]
number: 5 [14742,14743]
===
match
---
operator: , [14692,14693]
operator: , [14692,14693]
===
match
---
simple_stmt [20354,20427]
simple_stmt [20354,20427]
===
match
---
name: start [19399,19404]
name: start [19399,19404]
===
match
---
trailer [2658,2664]
trailer [2658,2664]
===
match
---
arith_expr [9181,9215]
arith_expr [9181,9215]
===
match
---
trailer [10728,10730]
trailer [10728,10730]
===
match
---
string: 'core' [10437,10443]
string: 'core' [10437,10443]
===
match
---
name: Pipe [16004,16008]
name: Pipe [16004,16008]
===
match
---
funcdef [14410,15169]
funcdef [14410,15169]
===
match
---
number: 1234 [2889,2893]
number: 1234 [2889,2893]
===
match
---
trailer [14779,14781]
trailer [14779,14781]
===
match
---
name: parent_pipe [15974,15985]
name: parent_pipe [15974,15985]
===
match
---
atom [8041,8052]
atom [8041,8052]
===
match
---
name: zombies [17505,17512]
name: zombies [17505,17512]
===
match
---
parameters [6559,6565]
parameters [6559,6565]
===
match
---
trailer [3690,3692]
trailer [3690,3692]
===
match
---
operator: = [23000,23001]
operator: = [23003,23004]
===
match
---
name: path [20929,20933]
name: path [20929,20933]
===
match
---
suite [12579,12853]
suite [12579,12853]
===
match
---
trailer [8586,8588]
trailer [8586,8588]
===
match
---
simple_stmt [3122,3259]
simple_stmt [3122,3259]
===
match
---
atom_expr [16382,16409]
atom_expr [16382,16409]
===
match
---
operator: , [14781,14782]
operator: , [14781,14782]
===
match
---
name: parent_pipe [3766,3777]
name: parent_pipe [3766,3777]
===
match
---
argument [6622,6647]
argument [6622,6647]
===
match
---
simple_stmt [9092,9230]
simple_stmt [9092,9230]
===
match
---
string: 'sql_alchemy_conn' [18100,18118]
string: 'sql_alchemy_conn' [18100,18118]
===
match
---
operator: , [4754,4755]
operator: , [4754,4755]
===
match
---
import_from [1625,1695]
import_from [1625,1695]
===
match
---
operator: = [7609,7610]
operator: = [7609,7610]
===
match
---
atom_expr [10952,10974]
atom_expr [10952,10974]
===
match
---
param [3091,3099]
param [3091,3099]
===
match
---
atom_expr [16744,16779]
atom_expr [16744,16779]
===
match
---
operator: = [7992,7993]
operator: = [7992,7993]
===
match
---
operator: = [14723,14724]
operator: = [14723,14724]
===
match
---
trailer [6372,6377]
trailer [6372,6377]
===
match
---
argument [8272,8314]
argument [8272,8314]
===
match
---
name: TaskInstance [1227,1239]
name: TaskInstance [1227,1239]
===
match
---
trailer [15148,15166]
trailer [15148,15166]
===
match
---
name: manager [4369,4376]
name: manager [4369,4376]
===
match
---
assert_stmt [19662,19704]
assert_stmt [19662,19704]
===
match
---
parameters [15295,15301]
parameters [15295,15301]
===
match
---
operator: , [6310,6311]
operator: , [6310,6311]
===
match
---
name: os [20215,20217]
name: os [20215,20217]
===
match
---
simple_stmt [8613,8640]
simple_stmt [8613,8640]
===
match
---
argument [8248,8258]
argument [8248,8258]
===
match
---
suite [16563,16586]
suite [16563,16586]
===
match
---
trailer [9956,9958]
trailer [9956,9958]
===
match
---
name: test_parse_once [18981,18996]
name: test_parse_once [18981,18996]
===
match
---
name: zombie [13079,13085]
name: zombie [13079,13085]
===
match
---
operator: , [2134,2135]
operator: , [2134,2135]
===
match
---
name: self [7411,7415]
name: self [7411,7415]
===
match
---
except_clause [18275,18289]
except_clause [18275,18289]
===
match
---
name: args [11856,11860]
name: args [11856,11860]
===
match
---
decorators [15174,15262]
decorators [15174,15262]
===
match
---
trailer [10912,10918]
trailer [10912,10918]
===
match
---
atom_expr [19088,19143]
atom_expr [19088,19143]
===
match
---
operator: = [6830,6831]
operator: = [6830,6831]
===
match
---
name: self [14453,14457]
name: self [14453,14457]
===
match
---
simple_stmt [4849,4868]
simple_stmt [4849,4868]
===
match
---
name: isinstance [9620,9630]
name: isinstance [9620,9630]
===
match
---
name: _process [18721,18729]
name: _process [18721,18729]
===
match
---
operator: = [15723,15724]
operator: = [15723,15724]
===
match
---
atom_expr [19806,19861]
atom_expr [19806,19861]
===
match
---
atom_expr [4379,4769]
atom_expr [4379,4769]
===
match
---
number: 1234 [13605,13609]
number: 1234 [13605,13609]
===
match
---
simple_stmt [11930,12014]
simple_stmt [11930,12014]
===
match
---
operator: = [14896,14897]
operator: = [14896,14897]
===
match
---
name: path [21859,21863]
name: path [21859,21863]
===
match
---
with_stmt [22536,22715]
with_stmt [22536,22715]
===
match
---
atom [11301,11548]
atom [11301,11548]
===
match
---
simple_stmt [6575,6905]
simple_stmt [6575,6905]
===
match
---
name: dag_folder [21212,21222]
name: dag_folder [21212,21222]
===
match
---
name: full_filepath [11368,11381]
name: full_filepath [11368,11381]
===
match
---
operator: = [7739,7740]
operator: = [7739,7740]
===
match
---
trailer [18241,18248]
trailer [18241,18248]
===
match
---
expr_stmt [5821,5862]
expr_stmt [5821,5862]
===
match
---
string: """         Test to check that a DAG with a system.exit() doesn't break the scheduler.         """ [15311,15409]
string: """         Test to check that a DAG with a system.exit() doesn't break the scheduler.         """ [15311,15409]
===
match
---
trailer [2117,2126]
trailer [2117,2126]
===
match
---
decorator [21292,21326]
decorator [21292,21326]
===
match
---
atom_expr [6459,6483]
atom_expr [6459,6483]
===
match
---
suite [7417,8120]
suite [7417,8120]
===
match
---
name: test_open_maybe_zipped_archive [22797,22827]
name: test_open_maybe_zipped_archive [22833,22863]
===
match
---
name: processor [15056,15065]
name: processor [15056,15065]
===
match
---
funcdef [2741,2771]
funcdef [2741,2771]
===
match
---
name: TEST_DAG_FOLDER [17999,18014]
name: TEST_DAG_FOLDER [17999,18014]
===
match
---
atom_expr [7961,7991]
atom_expr [7961,7991]
===
match
---
name: dag [11382,11385]
name: dag [11382,11385]
===
match
---
operator: = [3627,3628]
operator: = [3627,3628]
===
match
---
atom_expr [12494,12551]
atom_expr [12494,12551]
===
match
---
suite [2199,3342]
suite [2199,3342]
===
match
---
name: seconds [9173,9180]
name: seconds [9173,9180]
===
match
---
operator: = [13626,13627]
operator: = [13626,13627]
===
match
---
atom_expr [18147,18204]
atom_expr [18147,18204]
===
match
---
operator: , [6314,6315]
operator: , [6314,6315]
===
match
---
name: MagicMock [7554,7563]
name: MagicMock [7554,7563]
===
match
---
dotted_name [1630,1648]
dotted_name [1630,1648]
===
match
---
funcdef [15266,16792]
funcdef [15266,16792]
===
match
---
operator: = [16173,16174]
operator: = [16173,16174]
===
match
---
name: self [21090,21094]
name: self [21090,21094]
===
match
---
trailer [2076,2083]
trailer [2076,2083]
===
match
---
simple_stmt [19796,19862]
simple_stmt [19796,19862]
===
match
---
operator: , [20733,20734]
operator: , [20733,20734]
===
match
---
argument [12341,12363]
argument [12341,12363]
===
match
---
name: mocked_is_zipfile [21778,21795]
name: mocked_is_zipfile [21778,21795]
===
match
---
trailer [13857,13859]
trailer [13857,13859]
===
match
---
name: test_dag_path [20660,20673]
name: test_dag_path [20660,20673]
===
match
---
name: patch [13335,13340]
name: patch [13335,13340]
===
match
---
name: SchedulerJob [16174,16186]
name: SchedulerJob [16174,16186]
===
match
---
atom_expr [22629,22652]
atom_expr [22629,22652]
===
match
---
trailer [21561,21567]
trailer [21561,21567]
===
match
---
name: parent_pipe [3560,3571]
name: parent_pipe [3560,3571]
===
match
---
name: pardir [2077,2083]
name: pardir [2077,2083]
===
match
---
name: async_mode [4744,4754]
name: async_mode [4744,4754]
===
match
---
dictorsetmaker [15186,15220]
dictorsetmaker [15186,15220]
===
match
---
operator: , [1601,1602]
operator: , [1601,1602]
===
match
---
atom_expr [4783,4840]
atom_expr [4783,4840]
===
match
---
trailer [14733,14744]
trailer [14733,14744]
===
match
---
trailer [20217,20222]
trailer [20217,20222]
===
match
---
trailer [3777,3782]
trailer [3777,3782]
===
match
---
name: mock [21609,21613]
name: mock [21609,21613]
===
match
---
name: requests [9717,9725]
name: requests [9717,9725]
===
match
---
name: parent_pipe [4876,4887]
name: parent_pipe [4876,4887]
===
match
---
name: staticmethod [17350,17362]
name: staticmethod [17350,17362]
===
match
---
name: unittest [20986,20994]
name: unittest [20986,20994]
===
match
---
name: max [6769,6772]
name: max [6769,6772]
===
match
---
operator: @ [4901,4902]
operator: @ [4901,4902]
===
match
---
name: processor [14034,14043]
name: processor [14034,14043]
===
match
---
name: multiprocessing [15988,16003]
name: multiprocessing [15988,16003]
===
match
---
string: 'abc.txt' [8093,8102]
string: 'abc.txt' [8093,8102]
===
match
---
trailer [9188,9211]
trailer [9188,9211]
===
match
---
atom_expr [14153,14189]
atom_expr [14153,14189]
===
match
---
trailer [18720,18729]
trailer [18720,18729]
===
match
---
name: return_value [7566,7578]
name: return_value [7566,7578]
===
match
---
name: requests [9407,9415]
name: requests [9407,9415]
===
match
---
decorator [3019,3033]
decorator [3019,3033]
===
match
---
comparison [17209,17236]
comparison [17209,17236]
===
match
---
trailer [16441,16455]
trailer [16441,16455]
===
match
---
name: processor_agent [19720,19735]
name: processor_agent [19720,19735]
===
match
---
name: conf [18083,18087]
name: conf [18083,18087]
===
match
---
simple_stmt [7765,7794]
simple_stmt [7765,7794]
===
match
---
operator: @ [2776,2777]
operator: @ [2776,2777]
===
match
---
trailer [7816,7821]
trailer [7816,7821]
===
match
---
parameters [16990,16996]
parameters [16990,16996]
===
match
---
string: 'load_examples' [18945,18960]
string: 'load_examples' [18945,18960]
===
match
---
name: async_mode [12455,12465]
name: async_mode [12455,12465]
===
match
---
name: file_path [17472,17481]
name: file_path [17472,17481]
===
match
---
trailer [4328,4356]
trailer [4328,4356]
===
match
---
operator: , [3089,3090]
operator: , [3089,3090]
===
match
---
simple_stmt [8162,8492]
simple_stmt [8162,8492]
===
match
---
number: 1 [19294,19295]
number: 1 [19294,19295]
===
match
---
operator: , [877,878]
operator: , [877,878]
===
match
---
name: msg [11494,11497]
name: msg [11494,11497]
===
match
---
name: self [18997,19001]
name: self [18997,19001]
===
match
---
expr_stmt [10747,10791]
expr_stmt [10747,10791]
===
match
---
testlist_comp [10437,10460]
testlist_comp [10437,10460]
===
match
---
string: '/path/to/fakearchive.zip.other/file.txt' [22486,22527]
string: '/path/to/fakearchive.zip.other/file.txt' [22486,22527]
===
match
---
simple_stmt [22665,22715]
simple_stmt [22665,22715]
===
match
---
name: remove_list [17298,17309]
name: remove_list [17298,17309]
===
match
---
string: 'False' [10463,10470]
string: 'False' [10463,10470]
===
match
---
comparison [12809,12852]
comparison [12809,12852]
===
match
---
operator: , [3078,3079]
operator: , [3078,3079]
===
match
---
arglist [8808,8841]
arglist [8808,8841]
===
match
---
comparison [21991,22024]
comparison [21991,22024]
===
match
---
simple_stmt [20452,20476]
simple_stmt [20452,20476]
===
match
---
comparison [6395,6431]
comparison [6395,6431]
===
match
---
operator: , [10443,10444]
operator: , [10443,10444]
===
match
---
funcdef [21048,21287]
funcdef [21048,21287]
===
match
---
atom_expr [9704,9713]
atom_expr [9704,9713]
===
match
---
decorator [2845,2855]
decorator [2845,2855]
===
match
---
operator: , [2131,2132]
operator: , [2131,2132]
===
match
---
trailer [20454,20461]
trailer [20454,20461]
===
match
---
trailer [14511,14524]
trailer [14511,14524]
===
match
---
name: is_failure_callback [9573,9592]
name: is_failure_callback [9573,9592]
===
match
---
trailer [20688,20707]
trailer [20688,20707]
===
match
---
trailer [6768,6772]
trailer [6768,6772]
===
match
---
name: DagParsingSignal [1585,1601]
name: DagParsingSignal [1585,1601]
===
match
---
operator: , [1225,1226]
operator: , [1225,1226]
===
match
---
number: 1234 [14527,14531]
number: 1234 [14527,14531]
===
match
---
name: full_filepath [9364,9377]
name: full_filepath [9364,9377]
===
match
---
name: manager [3489,3496]
name: manager [3489,3496]
===
match
---
trailer [20682,20688]
trailer [20682,20688]
===
match
---
operator: , [6809,6810]
operator: , [6809,6810]
===
match
---
argument [4581,4612]
argument [4581,4612]
===
match
---
name: LJ [1116,1118]
name: LJ [1116,1118]
===
match
---
name: dag_ids [2386,2393]
name: dag_ids [2386,2393]
===
match
---
number: 1 [7521,7522]
number: 1 [7521,7522]
===
match
---
operator: , [18098,18099]
operator: , [18098,18099]
===
match
---
trailer [8516,8558]
trailer [8516,8558]
===
match
---
suite [2873,2894]
suite [2873,2894]
===
match
---
name: results [3619,3626]
name: results [3619,3626]
===
match
---
name: dag [9360,9363]
name: dag [9360,9363]
===
match
---
atom_expr [19244,19374]
atom_expr [19244,19374]
===
match
---
suite [17432,17514]
suite [17432,17514]
===
match
---
operator: = [10812,10813]
operator: = [10812,10813]
===
match
---
name: MagicMock [13746,13755]
name: MagicMock [13746,13755]
===
match
---
operator: @ [13329,13330]
operator: @ [13329,13330]
===
match
---
operator: = [13603,13604]
operator: = [13603,13604]
===
match
---
string: '/path/to/fakearchive.zip.other/file.txt' [21430,21471]
string: '/path/to/fakearchive.zip.other/file.txt' [21430,21471]
===
match
---
name: dag_directory [6622,6635]
name: dag_directory [6622,6635]
===
match
---
suite [22175,22403]
suite [22175,22403]
===
match
---
number: 1 [5350,5351]
number: 1 [5350,5351]
===
match
---
simple_stmt [22925,22965]
simple_stmt [23046,23086]
===
match
---
simple_stmt [17441,17514]
simple_stmt [17441,17514]
===
match
---
name: ti [11465,11467]
name: ti [11465,11467]
===
match
---
name: mock [22569,22573]
name: mock [22569,22573]
===
match
---
operator: , [16301,16302]
operator: , [16301,16302]
===
match
---
atom_expr [22665,22714]
atom_expr [22665,22714]
===
match
---
name: results [3861,3868]
name: results [3861,3868]
===
match
---
name: path [10311,10315]
name: path [10311,10315]
===
match
---
simple_stmt [9391,9417]
simple_stmt [9391,9417]
===
match
---
trailer [7228,7249]
trailer [7228,7249]
===
match
---
operator: , [8314,8315]
operator: , [8314,8315]
===
match
---
trailer [14988,14999]
trailer [14988,14999]
===
match
---
name: read_data [22584,22593]
name: read_data [22584,22593]
===
match
---
name: fake_processor_factory [11832,11854]
name: fake_processor_factory [11832,11854]
===
match
---
trailer [21497,21510]
trailer [21497,21510]
===
match
---
expr_stmt [7110,7166]
expr_stmt [7110,7166]
===
match
---
name: MagicMock [6798,6807]
name: MagicMock [6798,6807]
===
match
---
name: close [13284,13289]
name: close [13284,13289]
===
match
---
name: callbacks [3080,3089]
name: callbacks [3080,3089]
===
match
---
operator: , [8451,8452]
operator: , [8451,8452]
===
match
---
name: get [16768,16771]
name: get [16768,16771]
===
match
---
atom [7282,7293]
atom [7282,7293]
===
match
---
trailer [3534,3546]
trailer [3534,3546]
===
match
---
suite [3652,4045]
suite [3652,4045]
===
match
---
name: session [10991,10998]
name: session [10991,10998]
===
match
---
name: test_kill_timed_out_processors_no_kill [14414,14452]
name: test_kill_timed_out_processors_no_kill [14414,14452]
===
match
---
string: "mysql" [4922,4929]
string: "mysql" [4922,4929]
===
match
---
suite [10587,11549]
suite [10587,11549]
===
match
---
trailer [10766,10791]
trailer [10766,10791]
===
match
---
comparison [12690,12715]
comparison [12690,12715]
===
match
---
atom_expr [19987,20052]
atom_expr [19987,20052]
===
match
---
atom_expr [22569,22601]
atom_expr [22569,22601]
===
match
---
operator: , [16332,16333]
operator: , [16332,16333]
===
match
---
dotted_name [4902,4921]
dotted_name [4902,4921]
===
match
---
name: max [20719,20722]
name: max [20719,20722]
===
match
---
operator: , [5405,5406]
operator: , [5405,5406]
===
match
---
name: path [11581,11585]
name: path [11581,11585]
===
match
---
trailer [22114,22123]
trailer [22114,22123]
===
match
---
name: DagFileProcessorProcess [2174,2197]
name: DagFileProcessorProcess [2174,2197]
===
match
---
name: _callback_to_execute [9339,9359]
name: _callback_to_execute [9339,9359]
===
match
---
operator: == [12769,12771]
operator: == [12769,12771]
===
match
---
name: TI [1243,1245]
name: TI [1243,1245]
===
match
---
argument [12381,12391]
argument [12381,12391]
===
match
---
operator: , [20387,20388]
operator: , [20387,20388]
===
match
---
simple_stmt [7426,7756]
simple_stmt [7426,7756]
===
match
---
comparison [21268,21286]
comparison [21268,21286]
===
match
---
name: file_path [3169,3178]
name: file_path [3169,3178]
===
match
---
name: multiprocessing [4177,4192]
name: multiprocessing [4177,4192]
===
match
---
name: query [10612,10617]
name: query [10612,10617]
===
match
---
name: dag_ids [8410,8417]
name: dag_ids [8410,8417]
===
match
---
funcdef [18977,20155]
funcdef [18977,20155]
===
match
---
operator: == [19889,19891]
operator: == [19889,19891]
===
match
---
name: processor [11930,11939]
name: processor [11930,11939]
===
match
---
name: child_pipe [12353,12363]
name: child_pipe [12353,12363]
===
match
---
name: close [4888,4893]
name: close [4888,4893]
===
match
---
name: max [8356,8359]
name: max [8356,8359]
===
match
---
arglist [10502,10540]
arglist [10502,10540]
===
match
---
simple_stmt [14956,15014]
simple_stmt [14956,15014]
===
match
---
decorated [4901,6484]
decorated [4901,6484]
===
match
---
name: timezone [14058,14066]
name: timezone [14058,14066]
===
match
---
name: processor_factory [16156,16173]
name: processor_factory [16156,16173]
===
match
---
suite [11872,12097]
suite [11872,12097]
===
match
---
simple_stmt [2094,2139]
simple_stmt [2094,2139]
===
match
---
argument [16108,16118]
argument [16108,16118]
===
match
---
suite [4278,4841]
suite [4278,4841]
===
match
---
operator: } [13258,13259]
operator: } [13258,13259]
===
match
---
string: 'sqlite' [18067,18075]
string: 'sqlite' [18067,18075]
===
match
---
name: PropertyMock [14322,14334]
name: PropertyMock [14322,14334]
===
match
---
name: run_single_parsing_loop [18666,18689]
name: run_single_parsing_loop [18666,18689]
===
match
---
string: 'sqlite' [20292,20300]
string: 'sqlite' [20292,20300]
===
match
---
arglist [20378,20425]
arglist [20378,20425]
===
match
---
name: close [2659,2664]
name: close [2659,2664]
===
match
---
name: manager [3665,3672]
name: manager [3665,3672]
===
match
---
string: 'core' [11753,11759]
string: 'core' [11753,11759]
===
match
---
operator: = [14525,14526]
operator: = [14525,14526]
===
match
---
string: 'DagFileProcessor object has no attribute stop' [7000,7047]
string: 'DagFileProcessor object has no attribute stop' [7000,7047]
===
match
---
name: utcnow [9135,9141]
name: utcnow [9135,9141]
===
match
---
expr_stmt [13964,14025]
expr_stmt [13964,14025]
===
match
---
name: FakeDagFileProcessorRunner [3129,3155]
name: FakeDagFileProcessorRunner [3129,3155]
===
match
---
name: file [1644,1648]
name: file [1644,1648]
===
match
---
trailer [19590,19610]
trailer [19590,19610]
===
match
---
operator: , [5450,5451]
operator: , [5450,5451]
===
match
---
arglist [7229,7248]
arglist [7229,7248]
===
match
---
name: DagFileProcessorManager [12120,12143]
name: DagFileProcessorManager [12120,12143]
===
match
---
name: mocked_is_zipfile [22879,22896]
name: mocked_is_zipfile [22939,22956]
===
match
---
operator: - [12956,12957]
operator: - [12956,12957]
===
match
---
name: kwargs [21930,21936]
name: kwargs [21930,21936]
===
match
---
simple_stmt [21984,22025]
simple_stmt [21984,22025]
===
match
---
testlist_comp [20085,20114]
testlist_comp [20085,20114]
===
match
---
trailer [5860,5862]
trailer [5860,5862]
===
match
---
expr_stmt [14956,15013]
expr_stmt [14956,15013]
===
match
---
name: property [3265,3273]
name: property [3265,3273]
===
match
---
trailer [19819,19836]
trailer [19819,19836]
===
match
---
string: 'core' [18092,18098]
string: 'core' [18092,18098]
===
match
---
name: mock [22541,22545]
name: mock [22541,22545]
===
match
---
name: MagicMock [7782,7791]
name: MagicMock [7782,7791]
===
match
---
argument [16255,16264]
argument [16255,16264]
===
match
---
atom_expr [9092,9123]
atom_expr [9092,9123]
===
match
---
trailer [19650,19652]
trailer [19650,19652]
===
match
---
atom_expr [20926,20954]
atom_expr [20926,20954]
===
match
---
operator: = [7648,7649]
operator: = [7648,7649]
===
match
---
name: processor_factory [4491,4508]
name: processor_factory [4491,4508]
===
match
---
argument [22393,22401]
argument [22393,22401]
===
match
---
name: session [9932,9939]
name: session [9932,9939]
===
match
---
name: correct_maybe_zipped [21225,21245]
name: correct_maybe_zipped [21225,21245]
===
match
---
dotted_name [1915,1934]
dotted_name [1915,1934]
===
match
---
trailer [4324,4328]
trailer [4324,4328]
===
match
---
name: manager [9092,9099]
name: manager [9092,9099]
===
match
---
name: async_mode [7729,7739]
name: async_mode [7729,7739]
===
match
---
atom_expr [7310,7329]
atom_expr [7310,7329]
===
match
---
atom_expr [5821,5848]
atom_expr [5821,5848]
===
match
---
trailer [11748,11752]
trailer [11748,11752]
===
match
---
operator: , [12537,12538]
operator: , [12537,12538]
===
match
---
trailer [22986,22999]
trailer [23107,23120]
===
match
---
atom_expr [12940,12970]
atom_expr [12940,12970]
===
match
---
number: 5 [13820,13821]
number: 5 [13820,13821]
===
match
---
simple_stmt [1745,1783]
simple_stmt [1745,1783]
===
match
---
decorator [2899,2909]
decorator [2899,2909]
===
match
---
simple_stmt [5255,5583]
simple_stmt [5255,5583]
===
match
---
name: key [13210,13213]
name: key [13210,13213]
===
match
---
simple_stmt [15962,16011]
simple_stmt [15962,16011]
===
match
---
string: "airflow.jobs.scheduler_job.DagFileProcessorProcess.kill" [13442,13499]
string: "airflow.jobs.scheduler_job.DagFileProcessorProcess.kill" [13442,13499]
===
match
---
operator: , [6647,6648]
operator: , [6647,6648]
===
match
---
simple_stmt [13071,13260]
simple_stmt [13071,13260]
===
match
---
name: file_3 [5650,5656]
name: file_3 [5650,5656]
===
match
---
comparison [12739,12785]
comparison [12739,12785]
===
match
---
trailer [4893,4895]
trailer [4893,4895]
===
match
---
name: expected_failure_callback_requests [11264,11298]
name: expected_failure_callback_requests [11264,11298]
===
match
---
operator: , [7239,7240]
operator: , [7239,7240]
===
match
---
name: test_dag_path [12175,12188]
name: test_dag_path [12175,12188]
===
match
---
operator: , [10407,10408]
operator: , [10407,10408]
===
match
---
name: processor [12053,12062]
name: processor [12053,12062]
===
match
---
import_from [1783,1863]
import_from [1783,1863]
===
match
---
trailer [2018,2023]
trailer [2018,2023]
===
match
---
name: property [2846,2854]
name: property [2846,2854]
===
match
---
trailer [19095,19100]
trailer [19095,19100]
===
match
---
name: create_session [19755,19769]
name: create_session [19755,19769]
===
match
---
name: MagicMock [5851,5860]
name: MagicMock [5851,5860]
===
match
---
name: return_value [14680,14692]
name: return_value [14680,14692]
===
match
---
operator: , [7522,7523]
operator: , [7522,7523]
===
match
---
name: self [3298,3302]
name: self [3298,3302]
===
match
---
name: open_maybe_zipped [23044,23061]
name: open_maybe_zipped [23150,23167]
===
match
---
name: parent_pipe [3498,3509]
name: parent_pipe [3498,3509]
===
match
---
argument [8534,8557]
argument [8534,8557]
===
match
---
simple_stmt [13304,13324]
simple_stmt [13304,13324]
===
match
---
trailer [10959,10963]
trailer [10959,10963]
===
match
---
simple_stmt [11889,11914]
simple_stmt [11889,11914]
===
match
---
with_item [8572,8599]
with_item [8572,8599]
===
match
---
operator: { [10394,10395]
operator: { [10394,10395]
===
match
---
expr_stmt [12110,12480]
expr_stmt [12110,12480]
===
match
---
trailer [12824,12827]
trailer [12824,12827]
===
match
---
argument [13928,13943]
argument [13928,13943]
===
match
---
name: all_files_processed [19685,19704]
name: all_files_processed [19685,19704]
===
match
---
number: 0 [9511,9512]
number: 0 [9511,9512]
===
match
---
string: 'sql_alchemy_conn' [11761,11779]
string: 'sql_alchemy_conn' [11761,11779]
===
match
---
name: conf_vars [1900,1909]
name: conf_vars [1900,1909]
===
match
---
name: processor_timeout [6741,6758]
name: processor_timeout [6741,6758]
===
match
---
arglist [8209,8481]
arglist [8209,8481]
===
match
---
atom_expr [10559,10575]
atom_expr [10559,10575]
===
match
---
comparison [4304,4356]
comparison [4304,4356]
===
match
---
string: "airflow.jobs.scheduler_job.DagFileProcessorProcess.pid" [14251,14307]
string: "airflow.jobs.scheduler_job.DagFileProcessorProcess.pid" [14251,14307]
===
match
---
name: AttributeError [6985,6999]
name: AttributeError [6985,6999]
===
match
---
trailer [3672,3690]
trailer [3672,3690]
===
match
---
arglist [4329,4355]
arglist [4329,4355]
===
match
---
name: old_modules [17225,17236]
name: old_modules [17225,17236]
===
match
---
argument [13665,13690]
argument [13665,13690]
===
match
---
operator: , [11664,11665]
operator: , [11664,11665]
===
match
---
name: os [18890,18892]
name: os [18890,18892]
===
match
---
name: key [13107,13110]
name: key [13107,13110]
===
match
---
decorated [15174,16792]
decorated [15174,16792]
===
match
---
operator: , [4826,4827]
operator: , [4826,4827]
===
match
---
trailer [8299,8301]
trailer [8299,8301]
===
match
---
name: patch [21614,21619]
name: patch [21614,21619]
===
match
---
trailer [9018,9021]
trailer [9018,9021]
===
match
---
atom_expr [10495,10541]
atom_expr [10495,10541]
===
match
---
name: path [20218,20222]
name: path [20218,20222]
===
match
---
name: get [20374,20377]
name: get [20374,20377]
===
match
---
trailer [22698,22714]
trailer [22698,22714]
===
match
---
arglist [18156,18203]
arglist [18156,18203]
===
match
---
operator: , [7578,7579]
operator: , [7578,7579]
===
match
---
name: fake_processors [12898,12913]
name: fake_processors [12898,12913]
===
match
---
comparison [19165,19217]
comparison [19165,19217]
===
match
---
operator: = [5349,5350]
operator: = [5349,5350]
===
match
---
atom_expr [2045,2071]
atom_expr [2045,2071]
===
match
---
name: add [8940,8943]
name: add [8940,8943]
===
match
---
simple_stmt [22034,22078]
simple_stmt [22034,22078]
===
match
---
operator: , [1970,1971]
operator: , [1970,1971]
===
match
---
expr_stmt [17145,17161]
expr_stmt [17145,17161]
===
match
---
trailer [18729,18734]
trailer [18729,18734]
===
match
---
name: config [1886,1892]
name: config [1886,1892]
===
match
---
simple_stmt [18132,18205]
simple_stmt [18132,18205]
===
match
---
operator: = [2576,2577]
operator: = [2576,2577]
===
match
---
name: start [18595,18600]
name: start [18595,18600]
===
match
---
atom_expr [19383,19406]
atom_expr [19383,19406]
===
match
---
atom_expr [20709,20722]
atom_expr [20709,20722]
===
match
---
trailer [6429,6431]
trailer [6429,6431]
===
match
---
import_from [1246,1306]
import_from [1246,1306]
===
match
---
name: path [18893,18897]
name: path [18893,18897]
===
match
---
atom_expr [13581,13602]
atom_expr [13581,13602]
===
match
---
trailer [9447,9461]
trailer [9447,9461]
===
match
---
arglist [22699,22713]
arglist [22699,22713]
===
match
---
atom [19893,19924]
atom [19893,19924]
===
match
---
trailer [11968,11996]
trailer [11968,11996]
===
match
---
operator: , [16529,16530]
operator: , [16529,16530]
===
match
---
raise_stmt [3959,4044]
raise_stmt [3959,4044]
===
match
---
name: os [17986,17988]
name: os [17986,17988]
===
match
---
trailer [9642,9663]
trailer [9642,9663]
===
match
---
operator: , [18483,18484]
operator: , [18483,18484]
===
match
---
simple_stmt [13000,13059]
simple_stmt [13000,13059]
===
match
---
trailer [18525,18529]
trailer [18525,18529]
===
match
---
name: child_pipe [16291,16301]
name: child_pipe [16291,16301]
===
match
---
suite [8600,9998]
suite [8600,9998]
===
match
---
dotted_name [22759,22769]
dotted_name [22759,22769]
===
match
---
expr_stmt [19796,19861]
expr_stmt [19796,19861]
===
match
---
string: 'file_3.py' [5659,5670]
string: 'file_3.py' [5659,5670]
===
match
---
name: test_dag_path [18467,18480]
name: test_dag_path [18467,18480]
===
match
---
string: 'directory' [6636,6647]
string: 'directory' [6636,6647]
===
match
---
name: manager [7961,7968]
name: manager [7961,7968]
===
match
---
name: jobs [15628,15632]
name: jobs [15628,15632]
===
match
---
name: get_dag [10660,10667]
name: get_dag [10660,10667]
===
match
---
number: 5 [16263,16264]
number: 5 [16263,16264]
===
match
---
string: 'DAG_PROCESSOR_MANAGER_LOG_LOCATION' [18167,18203]
string: 'DAG_PROCESSOR_MANAGER_LOG_LOCATION' [18167,18203]
===
match
---
simple_stmt [11264,11549]
simple_stmt [11264,11549]
===
match
---
name: DagFileProcessorAgent [1512,1533]
name: DagFileProcessorAgent [1512,1533]
===
match
---
name: path [22479,22483]
name: path [22479,22483]
===
match
---
funcdef [4103,4896]
funcdef [4103,4896]
===
match
---
name: dag_ids [7674,7681]
name: dag_ids [7674,7681]
===
match
---
trailer [9468,9482]
trailer [9468,9482]
===
match
---
name: self [19302,19306]
name: self [19302,19306]
===
match
---
operator: = [22709,22710]
operator: = [22709,22710]
===
match
---
argument [3729,3741]
argument [3729,3741]
===
match
---
name: path [2048,2052]
name: path [2048,2052]
===
match
---
trailer [8869,8873]
trailer [8869,8873]
===
match
---
argument [5302,5327]
argument [5302,5327]
===
match
---
operator: == [12711,12713]
operator: == [12711,12713]
===
match
---
operator: - [13036,13037]
operator: - [13036,13037]
===
match
---
simple_stmt [21923,21976]
simple_stmt [21923,21976]
===
match
---
string: "dag_id" [19846,19854]
string: "dag_id" [19846,19854]
===
match
---
trailer [7932,7944]
trailer [7932,7944]
===
match
---
name: dag_ids [17410,17417]
name: dag_ids [17410,17417]
===
match
---
operator: = [4598,4599]
operator: = [4598,4599]
===
match
---
trailer [6712,6714]
trailer [6712,6714]
===
match
---
name: DagModel [1217,1225]
name: DagModel [1217,1225]
===
match
---
with_stmt [22184,22403]
with_stmt [22184,22403]
===
match
---
simple_stmt [19713,19741]
simple_stmt [19713,19741]
===
match
---
name: self [3412,3416]
name: self [3412,3416]
===
match
---
operator: , [14636,14637]
operator: , [14636,14637]
===
match
---
assert_stmt [9769,9830]
assert_stmt [9769,9830]
===
match
---
atom_expr [14980,15013]
atom_expr [14980,15013]
===
match
---
param [21395,21412]
param [21395,21412]
===
match
---
not_test [19502,19526]
not_test [19502,19526]
===
match
---
operator: * [11855,11856]
operator: * [11855,11856]
===
match
---
arglist [16067,16362]
arglist [16067,16362]
===
match
---
atom_expr [14058,14091]
atom_expr [14058,14091]
===
match
---
trailer [22366,22402]
trailer [22366,22402]
===
match
---
name: id [11211,11213]
name: id [11211,11213]
===
match
---
operator: , [11860,11861]
operator: , [11860,11861]
===
match
---
operator: = [4471,4472]
operator: = [4471,4472]
===
match
---
dictorsetmaker [8093,8118]
dictorsetmaker [8093,8118]
===
match
---
import_from [955,1004]
import_from [955,1004]
===
match
---
name: RUNNING [10843,10850]
name: RUNNING [10843,10850]
===
match
---
name: test_dag_path [10502,10515]
name: test_dag_path [10502,10515]
===
match
---
name: query [8621,8626]
name: query [8621,8626]
===
match
---
operator: { [13078,13079]
operator: { [13078,13079]
===
match
---
trailer [21972,21975]
trailer [21972,21975]
===
match
---
name: manager [12110,12117]
name: manager [12110,12117]
===
match
---
atom_expr [9242,9265]
atom_expr [9242,9265]
===
match
---
string: "zipfile.is_zipfile" [21620,21640]
string: "zipfile.is_zipfile" [21620,21640]
===
match
---
operator: = [5436,5437]
operator: = [5436,5437]
===
match
---
trailer [2629,2634]
trailer [2629,2634]
===
match
---
atom_expr [13976,14025]
atom_expr [13976,14025]
===
match
---
trailer [9041,9045]
trailer [9041,9045]
===
match
---
number: 0 [9570,9571]
number: 0 [9570,9571]
===
match
---
simple_stmt [21874,21915]
simple_stmt [21874,21915]
===
match
---
assert_stmt [7303,7335]
assert_stmt [7303,7335]
===
match
---
arglist [16523,16545]
arglist [16523,16545]
===
match
---
parameters [18996,19002]
parameters [18996,19002]
===
match
---
simple_stmt [3313,3342]
simple_stmt [3313,3342]
===
match
---
name: session [9062,9069]
name: session [9062,9069]
===
match
---
arglist [20317,20343]
arglist [20317,20343]
===
match
---
string: 'sqlite' [4304,4312]
string: 'sqlite' [4304,4312]
===
match
---
name: mod [17273,17276]
name: mod [17273,17276]
===
match
---
operator: , [12363,12364]
operator: , [12363,12364]
===
match
---
number: 0 [20675,20676]
number: 0 [20675,20676]
===
match
---
atom [8092,8119]
atom [8092,8119]
===
match
---
atom_expr [6759,6772]
atom_expr [6759,6772]
===
match
---
testlist_comp [10396,10428]
testlist_comp [10396,10428]
===
match
---
simple_stmt [20512,20517]
simple_stmt [20512,20517]
===
match
---
simple_stmt [848,889]
simple_stmt [848,889]
===
match
---
parameters [3411,3417]
parameters [3411,3417]
===
match
---
operator: = [10651,10652]
operator: = [10651,10652]
===
match
---
number: 2 [12714,12715]
number: 2 [12714,12715]
===
match
---
decorated [17349,17514]
decorated [17349,17514]
===
match
---
expr_stmt [2557,2612]
expr_stmt [2557,2612]
===
match
---
name: timeout [3729,3736]
name: timeout [3729,3736]
===
match
---
name: mock [14341,14345]
name: mock [14341,14345]
===
match
---
name: query [9979,9984]
name: query [9979,9984]
===
match
---
return_stmt [2882,2893]
return_stmt [2882,2893]
===
match
---
name: async_mode [5556,5566]
name: async_mode [5556,5566]
===
match
---
name: pickle_dags [13897,13908]
name: pickle_dags [13897,13908]
===
match
---
trailer [15749,15754]
trailer [15749,15754]
===
match
---
trailer [16407,16409]
trailer [16407,16409]
===
match
---
operator: , [3487,3488]
operator: , [3487,3488]
===
match
---
name: airflow [1630,1637]
name: airflow [1630,1637]
===
match
---
name: commit [10999,11005]
name: commit [10999,11005]
===
match
---
name: mock [22217,22221]
name: mock [22217,22221]
===
match
---
atom_expr [22879,22909]
atom_expr [22939,22969]
===
match
---
trailer [8974,8981]
trailer [8974,8981]
===
match
---
suite [10098,13324]
suite [10098,13324]
===
match
---
trailer [3324,3341]
trailer [3324,3341]
===
match
---
trailer [7565,7578]
trailer [7565,7578]
===
match
---
operator: == [9868,9870]
operator: == [9868,9870]
===
match
---
funcdef [22130,22403]
funcdef [22130,22403]
===
match
---
name: mod [17209,17212]
name: mod [17209,17212]
===
match
---
name: session [11157,11164]
name: session [11157,11164]
===
match
---
suite [20439,20476]
suite [20439,20476]
===
match
---
operator: , [5351,5352]
operator: , [5351,5352]
===
match
---
operator: = [15042,15043]
operator: = [15042,15043]
===
match
---
name: MagicMock [981,990]
name: MagicMock [981,990]
===
match
---
atom_expr [20678,20707]
atom_expr [20678,20707]
===
match
---
argument [4491,4563]
argument [4491,4563]
===
match
---
decorator [13329,13426]
decorator [13329,13426]
===
match
---
name: timezone [14980,14988]
name: timezone [14980,14988]
===
match
---
name: read_dags_from_db [8534,8551]
name: read_dags_from_db [8534,8551]
===
match
---
sync_comp_for [13111,13159]
sync_comp_for [13111,13159]
===
match
---
name: airflow [1750,1757]
name: airflow [1750,1757]
===
match
---
dotted_name [21609,21619]
dotted_name [21609,21619]
===
match
---
name: dag [8748,8751]
name: dag [8748,8751]
===
match
---
name: pickle_dags [16315,16326]
name: pickle_dags [16315,16326]
===
match
---
trailer [2061,2071]
trailer [2061,2071]
===
match
---
suite [22870,23336]
suite [22930,23516]
===
match
---
operator: = [5315,5316]
operator: = [5315,5316]
===
match
---
operator: = [16326,16327]
operator: = [16326,16327]
===
match
---
trailer [5244,5246]
trailer [5244,5246]
===
match
---
trailer [22981,22986]
trailer [23102,23107]
===
match
---
trailer [18897,18904]
trailer [18897,18904]
===
match
---
decorator [22758,22789]
decorator [22758,22789]
===
match
---
atom_expr [10903,10918]
atom_expr [10903,10918]
===
match
---
operator: , [20673,20674]
operator: , [20673,20674]
===
match
---
atom [3629,3631]
atom [3629,3631]
===
match
---
operator: } [15220,15221]
operator: } [15220,15221]
===
match
---
trailer [13106,13110]
trailer [13106,13110]
===
match
---
decorator [21608,21642]
decorator [21608,21642]
===
match
---
trailer [21957,21972]
trailer [21957,21972]
===
match
---
simple_stmt [1401,1465]
simple_stmt [1401,1465]
===
match
---
name: state [1764,1769]
name: state [1764,1769]
===
match
---
operator: == [13161,13163]
operator: == [13161,13163]
===
match
---
simple_stmt [10647,10698]
simple_stmt [10647,10698]
===
match
---
name: kwargs [12006,12012]
name: kwargs [12006,12012]
===
match
---
operator: , [3822,3823]
operator: , [3822,3823]
===
match
---
arglist [8517,8557]
arglist [8517,8557]
===
match
---
simple_stmt [2994,3014]
simple_stmt [2994,3014]
===
match
---
name: super [2415,2420]
name: super [2415,2420]
===
match
---
with_stmt [16691,16792]
with_stmt [16691,16792]
===
match
---
assert_stmt [9613,9684]
assert_stmt [9613,9684]
===
match
---
name: DagFileProcessorProcess [1158,1181]
name: DagFileProcessorProcess [1158,1181]
===
match
---
atom_expr [8018,8053]
atom_expr [8018,8053]
===
match
---
atom_expr [19012,19038]
atom_expr [19012,19038]
===
match
---
trailer [16522,16546]
trailer [16522,16546]
===
match
---
string: "zipfile.is_zipfile" [21304,21324]
string: "zipfile.is_zipfile" [21304,21324]
===
match
---
import_from [1745,1782]
import_from [1745,1782]
===
match
---
simple_stmt [9843,9919]
simple_stmt [9843,9919]
===
match
---
argument [13399,13424]
argument [13399,13424]
===
match
---
trailer [23158,23182]
trailer [23338,23362]
===
match
---
trailer [8895,8901]
trailer [8895,8901]
===
match
---
import_name [1006,1019]
import_name [1006,1019]
===
match
---
name: airflow [1026,1033]
name: airflow [1026,1033]
===
match
---
argument [8373,8396]
argument [8373,8396]
===
match
---
atom_expr [13848,13859]
atom_expr [13848,13859]
===
match
---
number: 1 [21913,21914]
number: 1 [21913,21914]
===
match
---
trailer [22951,22964]
trailer [23072,23085]
===
match
---
name: async_mode [20803,20813]
name: async_mode [20803,20813]
===
match
---
operator: , [4473,4474]
operator: , [4473,4474]
===
match
---
trailer [20907,20909]
trailer [20907,20909]
===
match
---
trailer [4887,4893]
trailer [4887,4893]
===
match
---
operator: = [13411,13412]
operator: = [13411,13412]
===
match
---
atom_expr [10653,10697]
atom_expr [10653,10697]
===
match
---
atom_expr [14034,14055]
atom_expr [14034,14055]
===
match
---
suite [14494,15169]
suite [14494,15169]
===
match
---
name: _processors [6413,6424]
name: _processors [6413,6424]
===
match
---
string: 'test_example_bash_operator.py' [11608,11639]
string: 'test_example_bash_operator.py' [11608,11639]
===
match
---
operator: , [7233,7234]
operator: , [7233,7234]
===
match
---
simple_stmt [10903,10936]
simple_stmt [10903,10936]
===
match
---
trailer [5828,5840]
trailer [5828,5840]
===
match
---
atom_expr [14668,14692]
atom_expr [14668,14692]
===
match
---
atom_expr [3808,3839]
atom_expr [3808,3839]
===
match
---
operator: , [22567,22568]
operator: , [22567,22568]
===
match
---
name: test_find_zombies [8129,8146]
name: test_find_zombies [8129,8146]
===
match
---
simple_stmt [18879,18919]
simple_stmt [18879,18919]
===
match
---
name: processor_factory [8272,8289]
name: processor_factory [8272,8289]
===
match
---
name: timedelta [16245,16254]
name: timedelta [16245,16254]
===
match
---
param [2386,2394]
param [2386,2394]
===
match
---
expr_stmt [10292,10370]
expr_stmt [10292,10370]
===
match
---
simple_stmt [10747,10792]
simple_stmt [10747,10792]
===
match
---
name: conf [11744,11748]
name: conf [11744,11748]
===
match
---
number: 1 [12957,12958]
number: 1 [12957,12958]
===
match
---
simple_stmt [5901,5931]
simple_stmt [5901,5931]
===
match
---
name: add [9042,9045]
name: add [9042,9045]
===
match
---
name: signal_conn [7637,7648]
name: signal_conn [7637,7648]
===
match
---
trailer [11168,11172]
trailer [11168,11172]
===
match
---
param [3412,3416]
param [3412,3416]
===
match
---
operator: = [14120,14121]
operator: = [14120,14121]
===
match
---
name: log_file_loc [18132,18144]
name: log_file_loc [18132,18144]
===
match
---
operator: , [11507,11508]
operator: , [11507,11508]
===
match
---
funcdef [16978,17344]
funcdef [16978,17344]
===
match
---
suite [17310,17344]
suite [17310,17344]
===
match
---
atom_expr [20878,20909]
atom_expr [20878,20909]
===
match
---
name: test_max_runs_when_no_files [4107,4134]
name: test_max_runs_when_no_files [4107,4134]
===
match
---
atom_expr [6703,6727]
atom_expr [6703,6727]
===
match
---
expr_stmt [2675,2707]
expr_stmt [2675,2707]
===
match
---
operator: , [990,991]
operator: , [990,991]
===
match
---
suite [3397,16792]
suite [3397,16792]
===
match
---
trailer [5928,5930]
trailer [5928,5930]
===
match
---
name: manager [5901,5908]
name: manager [5901,5908]
===
match
---
name: mock_dag_file_processor [14459,14482]
name: mock_dag_file_processor [14459,14482]
===
match
---
trailer [9045,9049]
trailer [9045,9049]
===
match
---
string: "data" [22242,22248]
string: "data" [22242,22248]
===
match
---
name: datetime [15000,15008]
name: datetime [15000,15008]
===
match
---
name: simple_task_instance [13086,13106]
name: simple_task_instance [13086,13106]
===
match
---
name: clear_db_serialized_dags [15926,15950]
name: clear_db_serialized_dags [15926,15950]
===
match
---
operator: , [5542,5543]
operator: , [5542,5543]
===
match
---
param [2356,2361]
param [2356,2361]
===
match
---
name: add [10960,10963]
name: add [10960,10963]
===
match
---
trailer [19735,19740]
trailer [19735,19740]
===
match
---
name: call_count [21899,21909]
name: call_count [21899,21909]
===
match
---
trailer [6965,6970]
trailer [6965,6970]
===
match
---
trailer [10621,10628]
trailer [10621,10628]
===
match
---
parameters [8146,8152]
parameters [8146,8152]
===
match
---
dotted_name [1788,1818]
dotted_name [1788,1818]
===
match
---
trailer [20050,20052]
trailer [20050,20052]
===
match
---
trailer [11244,11246]
trailer [11244,11246]
===
match
---
operator: == [20080,20082]
operator: == [20080,20082]
===
match
---
operator: = [18426,18427]
operator: = [18426,18427]
===
match
---
operator: , [4445,4446]
operator: , [4445,4446]
===
match
---
name: _processors [7318,7329]
name: _processors [7318,7329]
===
match
---
trailer [14107,14119]
trailer [14107,14119]
===
match
---
suite [17237,17278]
suite [17237,17278]
===
match
---
simple_stmt [6252,6327]
simple_stmt [6252,6327]
===
match
---
return_stmt [2937,2948]
return_stmt [2937,2948]
===
match
---
name: sync_to_db [8716,8726]
name: sync_to_db [8716,8726]
===
match
---
name: self [22169,22173]
name: self [22169,22173]
===
match
---
argument [6786,6809]
argument [6786,6809]
===
match
---
atom_expr [5437,5450]
atom_expr [5437,5450]
===
match
---
operator: @ [21292,21293]
operator: @ [21292,21293]
===
match
---
trailer [9630,9684]
trailer [9630,9684]
===
match
---
name: side_effect [6971,6982]
name: side_effect [6971,6982]
===
match
---
name: _processor_factory [18496,18514]
name: _processor_factory [18496,18514]
===
match
---
expr_stmt [2094,2138]
expr_stmt [2094,2138]
===
match
---
name: timezone [2109,2117]
name: timezone [2109,2117]
===
match
---
string: 'load_examples' [15195,15210]
string: 'load_examples' [15195,15210]
===
match
---
expr_stmt [14100,14144]
expr_stmt [14100,14144]
===
match
---
operator: , [17408,17409]
operator: , [17408,17409]
===
match
---
argument [6741,6772]
argument [6741,6772]
===
match
---
atom_expr [18650,18691]
atom_expr [18650,18691]
===
match
---
operator: , [4335,4336]
operator: , [4335,4336]
===
match
---
name: query [9940,9945]
name: query [9940,9945]
===
match
---
trailer [20461,20475]
trailer [20461,20475]
===
match
---
name: utils [1414,1419]
name: utils [1414,1419]
===
match
---
operator: = [5657,5658]
operator: = [5657,5658]
===
match
---
atom [20117,20153]
atom [20117,20153]
===
match
---
operator: } [7334,7335]
operator: } [7334,7335]
===
match
---
name: self [20184,20188]
name: self [20184,20188]
===
match
---
argument [12234,12274]
argument [12234,12274]
===
match
---
expr_stmt [14886,14947]
expr_stmt [14886,14947]
===
match
---
name: property [2777,2785]
name: property [2777,2785]
===
match
---
operator: , [3203,3204]
operator: , [3203,3204]
===
match
---
trailer [9069,9076]
trailer [9069,9076]
===
match
---
atom_expr [2029,2072]
atom_expr [2029,2072]
===
match
---
name: path [22647,22651]
name: path [22647,22651]
===
match
---
name: processor_timeout [8328,8345]
name: processor_timeout [8328,8345]
===
match
---
simple_stmt [7259,7295]
simple_stmt [7259,7295]
===
match
---
atom_expr [2578,2612]
atom_expr [2578,2612]
===
match
---
simple_stmt [18054,18120]
simple_stmt [18054,18120]
===
match
---
name: async_mode [12444,12454]
name: async_mode [12444,12454]
===
match
---
string: '1' [10431,10434]
string: '1' [10431,10434]
===
match
---
del_stmt [17323,17343]
del_stmt [17323,17343]
===
match
---
operator: = [22484,22485]
operator: = [22484,22485]
===
match
---
trailer [8626,8630]
trailer [8626,8630]
===
match
---
name: requests [9631,9639]
name: requests [9631,9639]
===
match
---
operator: , [2441,2442]
operator: , [2441,2442]
===
match
---
operator: = [12118,12119]
operator: = [12118,12119]
===
match
---
atom_expr [6931,6942]
atom_expr [6931,6942]
===
match
---
name: local_job [10964,10973]
name: local_job [10964,10973]
===
match
---
operator: , [21688,21689]
operator: , [21688,21689]
===
match
---
trailer [16003,16008]
trailer [16003,16008]
===
match
---
string: 'core' [4063,4069]
string: 'core' [4063,4069]
===
match
---
name: commit [9070,9076]
name: commit [9070,9076]
===
match
---
atom_expr [18516,18529]
atom_expr [18516,18529]
===
match
---
assert_stmt [20919,20954]
assert_stmt [20919,20954]
===
match
---
name: setUp [16854,16859]
name: setUp [16854,16859]
===
match
---
trailer [3440,3442]
trailer [3440,3442]
===
match
---
decorated [2954,3014]
decorated [2954,3014]
===
match
---
atom_expr [10384,10472]
atom_expr [10384,10472]
===
match
---
name: async_mode [20735,20745]
name: async_mode [20735,20745]
===
match
---
string: 'r' [22398,22401]
string: 'r' [22398,22401]
===
match
---
name: datetime [869,877]
name: datetime [869,877]
===
match
---
atom_expr [11578,11640]
atom_expr [11578,11640]
===
match
---
simple_stmt [16382,16410]
simple_stmt [16382,16410]
===
match
---
name: dag_directory [5302,5315]
name: dag_directory [5302,5315]
===
match
---
arglist [18092,18118]
arglist [18092,18118]
===
match
---
name: child_pipe [4642,4652]
name: child_pipe [4642,4652]
===
match
---
trailer [3005,3013]
trailer [3005,3013]
===
match
---
dotted_name [1026,1047]
dotted_name [1026,1047]
===
match
---
atom_expr [13746,13770]
atom_expr [13746,13770]
===
match
---
name: LJ [9985,9987]
name: LJ [9985,9987]
===
match
---
name: self [8147,8151]
name: self [8147,8151]
===
match
---
operator: , [8812,8813]
operator: , [8812,8813]
===
match
---
name: mocked_is_zipfile [23117,23134]
name: mocked_is_zipfile [23297,23314]
===
match
---
name: patch [22546,22551]
name: patch [22546,22551]
===
match
---
simple_stmt [6388,6432]
simple_stmt [6388,6432]
===
match
---
simple_stmt [8741,8787]
simple_stmt [8741,8787]
===
match
---
name: dag_ids [17496,17503]
name: dag_ids [17496,17503]
===
match
---
trailer [15741,15808]
trailer [15741,15808]
===
match
---
comparison [20292,20344]
comparison [20292,20344]
===
match
---
operator: , [20722,20723]
operator: , [20722,20723]
===
match
---
trailer [11700,11702]
trailer [11700,11702]
===
match
---
name: requests [9561,9569]
name: requests [9561,9569]
===
match
---
name: unittest [16826,16834]
name: unittest [16826,16834]
===
match
---
number: 0 [2734,2735]
number: 0 [2734,2735]
===
match
---
atom_expr [6798,6809]
atom_expr [6798,6809]
===
match
---
trailer [20779,20785]
trailer [20779,20785]
===
match
---
name: id [9019,9021]
name: id [9019,9021]
===
match
---
name: session [10579,10586]
name: session [10579,10586]
===
match
---
operator: = [16449,16450]
operator: = [16449,16450]
===
match
---
name: session [8613,8620]
name: session [8613,8620]
===
match
---
name: _result [3006,3013]
name: _result [3006,3013]
===
match
---
operator: = [16262,16263]
operator: = [16262,16263]
===
match
---
atom_expr [11201,11213]
atom_expr [11201,11213]
===
match
---
name: manager [4819,4826]
name: manager [4819,4826]
===
match
---
trailer [14207,14231]
trailer [14207,14231]
===
match
---
number: 0 [9726,9727]
number: 0 [9726,9727]
===
match
---
atom_expr [8997,9006]
atom_expr [8997,9006]
===
match
---
name: return_value [21498,21510]
name: return_value [21498,21510]
===
match
---
name: multiprocessing [2578,2593]
name: multiprocessing [2578,2593]
===
match
---
suite [18222,18263]
suite [18222,18263]
===
match
---
expr_stmt [14540,14876]
expr_stmt [14540,14876]
===
match
---
simple_stmt [7175,7250]
simple_stmt [7175,7250]
===
match
---
argument [11368,11399]
argument [11368,11399]
===
match
---
name: State [10837,10842]
name: State [10837,10842]
===
match
---
dotted_name [15620,15646]
dotted_name [15620,15646]
===
match
---
decorator [21010,21044]
decorator [21010,21044]
===
match
---
suite [17839,18919]
suite [17839,18919]
===
match
---
trailer [16186,16213]
trailer [16186,16213]
===
match
---
trailer [16940,16952]
trailer [16940,16952]
===
match
---
string: 'exit_test_dag' [15685,15700]
string: 'exit_test_dag' [15685,15700]
===
match
---
atom_expr [6405,6431]
atom_expr [6405,6431]
===
match
---
atom_expr [11157,11172]
atom_expr [11157,11172]
===
match
---
name: type [20678,20682]
name: type [20678,20682]
===
match
---
operator: { [15185,15186]
operator: { [15185,15186]
===
match
---
operator: @ [2845,2846]
operator: @ [2845,2846]
===
match
---
string: 'abc.txt' [8042,8051]
string: 'abc.txt' [8042,8051]
===
match
---
atom_expr [23191,23264]
atom_expr [23371,23444]
===
match
---
import_from [1060,1118]
import_from [1060,1118]
===
match
---
trailer [3571,3576]
trailer [3571,3576]
===
match
---
trailer [16494,16496]
trailer [16494,16496]
===
match
---
suite [3547,3610]
suite [3547,3610]
===
match
---
atom_expr [20308,20344]
atom_expr [20308,20344]
===
match
---
trailer [19813,19819]
trailer [19813,19819]
===
match
---
trailer [15744,15749]
trailer [15744,15749]
===
match
---
suite [17548,18919]
suite [17548,18919]
===
match
---
simple_stmt [21528,21568]
simple_stmt [21528,21568]
===
match
---
trailer [12754,12757]
trailer [12754,12757]
===
match
---
trailer [16657,16676]
trailer [16657,16676]
===
match
---
name: file_1 [5841,5847]
name: file_1 [5841,5847]
===
match
---
name: os [10308,10310]
name: os [10308,10310]
===
match
---
funcdef [20160,20955]
funcdef [20160,20955]
===
match
---
name: modules [16964,16971]
name: modules [16964,16971]
===
match
---
trailer [4859,4865]
trailer [4859,4865]
===
match
---
atom_expr [22973,22999]
atom_expr [23094,23120]
===
match
---
operator: = [22397,22398]
operator: = [22397,22398]
===
match
---
parameters [22827,22869]
parameters [22863,22929]
===
match
---
name: modules [17331,17338]
name: modules [17331,17338]
===
match
---
name: unittest [839,847]
name: unittest [839,847]
===
match
---
name: pytest [4902,4908]
name: pytest [4902,4908]
===
match
---
name: mock_open [22222,22231]
name: mock_open [22222,22231]
===
match
---
operator: = [19804,19805]
operator: = [19804,19805]
===
match
---
name: _fake_dag_processor_factory [4536,4563]
name: _fake_dag_processor_factory [4536,4563]
===
match
---
import_as_names [981,1004]
import_as_names [981,1004]
===
match
---
argument [14587,14612]
argument [14587,14612]
===
match
---
atom [14803,14805]
atom [14803,14805]
===
match
---
atom_expr [8867,8873]
atom_expr [8867,8873]
===
match
---
name: fake_processors [12940,12955]
name: fake_processors [12940,12955]
===
match
---
atom_expr [2074,2083]
atom_expr [2074,2083]
===
match
---
operator: , [3496,3497]
operator: , [3496,3497]
===
match
---
atom_expr [3577,3608]
atom_expr [3577,3608]
===
match
---
operator: , [4612,4613]
operator: , [4612,4613]
===
match
---
name: OSError [18282,18289]
name: OSError [18282,18289]
===
match
---
not_test [20799,20813]
not_test [20799,20813]
===
match
---
arglist [15755,15806]
arglist [15755,15806]
===
match
---
name: session [10952,10959]
name: session [10952,10959]
===
match
---
name: max_runs [13704,13712]
name: max_runs [13704,13712]
===
match
---
atom_expr [5851,5862]
atom_expr [5851,5862]
===
match
---
simple_stmt [1625,1696]
simple_stmt [1625,1696]
===
match
---
operator: = [2729,2730]
operator: = [2729,2730]
===
match
---
simple_stmt [2882,2894]
simple_stmt [2882,2894]
===
match
---
simple_stmt [4151,4200]
simple_stmt [4151,4200]
===
match
---
name: processor_factory [14650,14667]
name: processor_factory [14650,14667]
===
match
---
argument [4733,4754]
argument [4733,4754]
===
match
---
simple_stmt [19446,19488]
simple_stmt [19446,19488]
===
match
---
name: stop [6966,6970]
name: stop [6966,6970]
===
match
---
trailer [16254,16265]
trailer [16254,16265]
===
match
---
trailer [6377,6379]
trailer [6377,6379]
===
match
---
parameters [21388,21413]
parameters [21388,21413]
===
match
---
operator: @ [21608,21609]
operator: @ [21608,21609]
===
match
---
name: DagFileProcessorProcess [13976,13999]
name: DagFileProcessorProcess [13976,13999]
===
match
---
name: signal_conn [12341,12352]
name: signal_conn [12341,12352]
===
match
---
trailer [11210,11213]
trailer [11210,11213]
===
match
---
try_stmt [20435,20517]
try_stmt [20435,20517]
===
match
---
string: '/path/to/archive.zip' [23159,23181]
string: '/path/to/archive.zip' [23339,23361]
===
match
---
name: _file_path [12960,12970]
name: _file_path [12960,12970]
===
match
---
name: airflow [1187,1194]
name: airflow [1187,1194]
===
match
---
simple_stmt [17254,17278]
simple_stmt [17254,17278]
===
match
---
operator: = [8803,8804]
operator: = [8803,8804]
===
match
---
atom_expr [13182,13213]
atom_expr [13182,13213]
===
match
---
argument [14309,14334]
argument [14309,14334]
===
match
---
trailer [12052,12063]
trailer [12052,12063]
===
match
---
name: dag_folder [21528,21538]
name: dag_folder [21528,21538]
===
match
---
name: mock_file [22333,22342]
name: mock_file [22333,22342]
===
match
---
name: requests [9320,9328]
name: requests [9320,9328]
===
match
---
name: dag_processing [1484,1498]
name: dag_processing [1484,1498]
===
match
---
suite [8153,9998]
suite [8153,9998]
===
match
---
atom_expr [19297,19326]
atom_expr [19297,19326]
===
match
---
atom_expr [3965,4044]
atom_expr [3965,4044]
===
match
---
name: timedelta [6759,6768]
name: timedelta [6759,6768]
===
match
---
operator: = [14978,14979]
operator: = [14978,14979]
===
match
---
trailer [19845,19855]
trailer [19845,19855]
===
match
---
atom_expr [4876,4895]
atom_expr [4876,4895]
===
match
---
param [2751,2755]
param [2751,2755]
===
match
---
atom [14018,14020]
atom [14018,14020]
===
match
---
operator: = [16290,16291]
operator: = [16290,16291]
===
match
---
argument [13873,13883]
argument [13873,13883]
===
match
---
operator: = [14830,14831]
operator: = [14830,14831]
===
match
---
return_stmt [3932,3946]
return_stmt [3932,3946]
===
match
---
operator: , [12465,12466]
operator: , [12465,12466]
===
match
---
operator: = [16476,16477]
operator: = [16476,16477]
===
match
---
name: dag_folder [21825,21835]
name: dag_folder [21825,21835]
===
match
---
atom [14944,14946]
atom [14944,14946]
===
match
---
suite [16866,16973]
suite [16866,16973]
===
match
---
name: task [8741,8745]
name: task [8741,8745]
===
match
---
trailer [23230,23264]
trailer [23410,23444]
===
match
---
name: pickle_dags [12409,12420]
name: pickle_dags [12409,12420]
===
match
---
atom [13078,13160]
atom [13078,13160]
===
match
---
simple_stmt [15676,15701]
simple_stmt [15676,15701]
===
match
---
suite [2928,2949]
suite [2928,2949]
===
match
---
simple_stmt [8652,8700]
simple_stmt [8652,8700]
===
match
---
operator: = [13938,13939]
operator: = [13938,13939]
===
match
---
name: _callback_requests [12828,12846]
name: _callback_requests [12828,12846]
===
match
---
name: SimpleTaskInstance [1347,1365]
name: SimpleTaskInstance [1347,1365]
===
match
---
name: DEFAULT_DATE [8814,8826]
name: DEFAULT_DATE [8814,8826]
===
match
---
operator: , [14865,14866]
operator: , [14865,14866]
===
match
---
param [7411,7415]
param [7411,7415]
===
match
---
suite [16997,17344]
suite [16997,17344]
===
match
---
expr_stmt [15022,15066]
expr_stmt [15022,15066]
===
match
---
simple_stmt [23191,23265]
simple_stmt [23371,23445]
===
match
---
name: os [18239,18241]
name: os [18239,18241]
===
match
---
string: '/path/to/archive.zip/deep/path/to/file.txt' [21725,21769]
string: '/path/to/archive.zip/deep/path/to/file.txt' [21725,21769]
===
match
---
expr_stmt [17970,18041]
expr_stmt [17970,18041]
===
match
---
name: join [2024,2028]
name: join [2024,2028]
===
match
---
trailer [11385,11399]
trailer [11385,11399]
===
match
---
name: mock [13330,13334]
name: mock [13330,13334]
===
match
---
argument [8465,8480]
argument [8465,8480]
===
match
---
name: ti [9776,9778]
name: ti [9776,9778]
===
match
---
param [22834,22850]
param [22894,22910]
===
match
---
name: dag_id [9750,9756]
name: dag_id [9750,9756]
===
match
---
trailer [14066,14077]
trailer [14066,14077]
===
match
---
expr_stmt [15709,15808]
expr_stmt [15709,15808]
===
match
---
name: async_mode [18054,18064]
name: async_mode [18054,18064]
===
match
---
name: max_runs [4463,4471]
name: max_runs [4463,4471]
===
match
---
assert_stmt [21261,21286]
assert_stmt [21261,21286]
===
match
---
trailer [6807,6809]
trailer [6807,6809]
===
match
---
name: property [2900,2908]
name: property [2900,2908]
===
match
---
name: _processors [7969,7980]
name: _processors [7969,7980]
===
match
---
simple_stmt [2937,2949]
simple_stmt [2937,2949]
===
match
---
expr_stmt [8800,8842]
expr_stmt [8800,8842]
===
match
---
simple_stmt [9320,9379]
simple_stmt [9320,9379]
===
match
---
expr_stmt [16936,16972]
expr_stmt [16936,16972]
===
match
---
operator: , [2393,2394]
operator: , [2393,2394]
===
match
---
name: correct_maybe_zipped [21838,21858]
name: correct_maybe_zipped [21838,21858]
===
match
---
string: '/path/to/archive.zip' [21991,22013]
string: '/path/to/archive.zip' [21991,22013]
===
match
---
simple_stmt [1307,1366]
simple_stmt [1307,1366]
===
match
---
argument [13784,13822]
argument [13784,13822]
===
match
---
trailer [9406,9416]
trailer [9406,9416]
===
match
---
operator: = [7681,7682]
operator: = [7681,7682]
===
match
---
name: return_value [22987,22999]
name: return_value [23108,23120]
===
match
---
arglist [17999,18040]
arglist [17999,18040]
===
match
---
operator: , [16118,16119]
operator: , [16118,16119]
===
match
---
atom_expr [5235,5246]
atom_expr [5235,5246]
===
match
---
operator: , [17494,17495]
operator: , [17494,17495]
===
match
---
trailer [4535,4563]
trailer [4535,4563]
===
match
---
name: manager [7175,7182]
name: manager [7175,7182]
===
match
---
trailer [21181,21194]
trailer [21181,21194]
===
match
---
name: scheduler_job [15633,15646]
name: scheduler_job [15633,15646]
===
match
---
parameters [13544,13571]
parameters [13544,13571]
===
match
---
suite [2406,2736]
suite [2406,2736]
===
match
---
operator: = [11199,11200]
operator: = [11199,11200]
===
match
---
atom_expr [7057,7093]
atom_expr [7057,7093]
===
match
---
name: self [3001,3005]
name: self [3001,3005]
===
match
---
atom_expr [14770,14781]
atom_expr [14770,14781]
===
match
---
atom_expr [13273,13291]
atom_expr [13273,13291]
===
match
---
name: create_session [16696,16710]
name: create_session [16696,16710]
===
match
---
name: manager [3527,3534]
name: manager [3527,3534]
===
match
---
trailer [9988,9995]
trailer [9988,9995]
===
match
---
parameters [10091,10097]
parameters [10091,10097]
===
match
---
simple_stmt [18307,18312]
simple_stmt [18307,18312]
===
match
---
simple_stmt [9062,9079]
simple_stmt [9062,9079]
===
match
---
trailer [4197,4199]
trailer [4197,4199]
===
match
---
expr_stmt [8652,8699]
expr_stmt [8652,8699]
===
match
---
string: 'test_scheduler_dags.py' [19118,19142]
string: 'test_scheduler_dags.py' [19118,19142]
===
match
---
simple_stmt [7303,7336]
simple_stmt [7303,7336]
===
match
---
operator: + [9212,9213]
operator: + [9212,9213]
===
match
---
trailer [2036,2044]
trailer [2036,2044]
===
match
---
decorator [2776,2786]
decorator [2776,2786]
===
match
---
name: DagParsingStat [3824,3838]
name: DagParsingStat [3824,3838]
===
match
---
operator: = [21511,21512]
operator: = [21511,21512]
===
match
---
parameters [2804,2810]
parameters [2804,2810]
===
match
---
name: dag [10754,10757]
name: dag [10754,10757]
===
match
---
atom_expr [19446,19487]
atom_expr [19446,19487]
===
match
---
name: self [4135,4139]
name: self [4135,4139]
===
match
---
name: self [12494,12498]
name: self [12494,12498]
===
match
---
simple_stmt [8062,8120]
simple_stmt [8062,8120]
===
match
---
name: processor_agent [20827,20842]
name: processor_agent [20827,20842]
===
match
---
name: parent_pipe [4163,4174]
name: parent_pipe [4163,4174]
===
match
---
with_item [19755,19782]
with_item [19755,19782]
===
match
---
expr_stmt [7426,7755]
expr_stmt [7426,7755]
===
match
---
operator: = [20290,20291]
operator: = [20290,20291]
===
match
---
name: TEST_DAG_FOLDER [1998,2013]
name: TEST_DAG_FOLDER [1998,2013]
===
match
---
name: len [12894,12897]
name: len [12894,12897]
===
match
---
name: timezone [1392,1400]
name: timezone [1392,1400]
===
match
---
suite [16845,20955]
suite [16845,20955]
===
match
---
name: dag_ids [12381,12388]
name: dag_ids [12381,12388]
===
match
---
simple_stmt [16647,16682]
simple_stmt [16647,16682]
===
match
---
name: set_file_paths [7267,7281]
name: set_file_paths [7267,7281]
===
match
---
name: path [17989,17993]
name: path [17989,17993]
===
match
---
atom_expr [15022,15041]
atom_expr [15022,15041]
===
match
---
name: LocalTaskJob [1100,1112]
name: LocalTaskJob [1100,1112]
===
match
---
name: remove_list [17254,17265]
name: remove_list [17254,17265]
===
match
---
return_stmt [3313,3341]
return_stmt [3313,3341]
===
match
---
name: modules [17185,17192]
name: modules [17185,17192]
===
match
---
name: LJ [8867,8869]
name: LJ [8867,8869]
===
match
---
trailer [6274,6298]
trailer [6274,6298]
===
match
---
name: TaskCallbackRequest [1445,1464]
name: TaskCallbackRequest [1445,1464]
===
match
---
trailer [7821,7833]
trailer [7821,7833]
===
match
---
atom_expr [18579,18602]
atom_expr [18579,18602]
===
match
---
expr_stmt [15962,16010]
expr_stmt [15962,16010]
===
match
---
name: mock_processor [7765,7779]
name: mock_processor [7765,7779]
===
match
---
simple_stmt [19575,19613]
simple_stmt [19575,19613]
===
match
---
trailer [19100,19143]
trailer [19100,19143]
===
match
---
atom [19892,19963]
atom [19892,19963]
===
match
---
trailer [18087,18091]
trailer [18087,18091]
===
match
---
trailer [12529,12551]
trailer [12529,12551]
===
match
---
name: _processor_factory [19308,19326]
name: _processor_factory [19308,19326]
===
match
---
trailer [20036,20046]
trailer [20036,20046]
===
match
---
name: self [3483,3487]
name: self [3483,3487]
===
match
---
number: 1 [9398,9399]
number: 1 [9398,9399]
===
match
---
while_stmt [16419,16586]
while_stmt [16419,16586]
===
match
---
name: make_aware [14989,14999]
name: make_aware [14989,14999]
===
match
---
simple_stmt [1366,1401]
simple_stmt [1366,1401]
===
match
---
name: test_utils [1921,1931]
name: test_utils [1921,1931]
===
match
---
trailer [3593,3608]
trailer [3593,3608]
===
match
---
name: duplex [2599,2605]
name: duplex [2599,2605]
===
match
---
name: ti [9704,9706]
name: ti [9704,9706]
===
match
---
name: async_mode [4291,4301]
name: async_mode [4291,4301]
===
match
---
name: session [11230,11237]
name: session [11230,11237]
===
match
---
atom [4062,4087]
atom [4062,4087]
===
match
---
simple_stmt [12683,12716]
simple_stmt [12683,12716]
===
match
---
atom [6447,6455]
atom [6447,6455]
===
match
---
name: callback_requests [1420,1437]
name: callback_requests [1420,1437]
===
match
---
atom_expr [13079,13110]
atom_expr [13079,13110]
===
match
---
operator: = [13018,13019]
operator: = [13018,13019]
===
match
---
simple_stmt [3427,3443]
simple_stmt [3427,3443]
===
match
---
simple_stmt [9495,9542]
simple_stmt [9495,9542]
===
match
---
trailer [9801,9822]
trailer [9801,9822]
===
match
---
parameters [21089,21114]
parameters [21089,21114]
===
match
---
simple_stmt [4369,4770]
simple_stmt [4369,4770]
===
match
---
atom_expr [14724,14744]
atom_expr [14724,14744]
===
match
---
operator: , [7245,7246]
operator: , [7245,7246]
===
match
---
name: join [10316,10320]
name: join [10316,10320]
===
match
---
name: child_pipe [4151,4161]
name: child_pipe [4151,4161]
===
match
---
simple_stmt [21718,21770]
simple_stmt [21718,21770]
===
match
---
testlist_star_expr [11654,11677]
testlist_star_expr [11654,11677]
===
match
---
operator: , [14805,14806]
operator: , [14805,14806]
===
match
---
sync_comp_for [13214,13245]
sync_comp_for [13214,13245]
===
match
---
string: 'test_example_bash_operator.py' [10338,10369]
string: 'test_example_bash_operator.py' [10338,10369]
===
match
---
simple_stmt [8501,8559]
simple_stmt [8501,8559]
===
match
---
operator: , [19326,19327]
operator: , [19326,19327]
===
match
---
operator: = [21938,21939]
operator: = [21938,21939]
===
match
---
name: done [2917,2921]
name: done [2917,2921]
===
match
---
operator: , [11759,11760]
operator: , [11759,11760]
===
match
---
suite [21005,22078]
suite [21005,22078]
===
match
---
atom_expr [11230,11246]
atom_expr [11230,11246]
===
match
---
atom_expr [16030,16372]
atom_expr [16030,16372]
===
match
---
name: session [1715,1722]
name: session [1715,1722]
===
match
---
atom_expr [21480,21510]
atom_expr [21480,21510]
===
match
---
funcdef [2968,3014]
funcdef [2968,3014]
===
match
---
atom_expr [8290,8314]
atom_expr [8290,8314]
===
match
---
simple_stmt [20764,20788]
simple_stmt [20764,20788]
===
match
---
funcdef [8125,9998]
funcdef [8125,9998]
===
match
---
comparison [9776,9830]
comparison [9776,9830]
===
match
---
operator: , [8480,8481]
operator: , [8480,8481]
===
match
---
parameters [4134,4140]
parameters [4134,4140]
===
match
---
name: read_data [22232,22241]
name: read_data [22232,22241]
===
match
---
operator: , [20676,20677]
operator: , [20676,20677]
===
match
---
operator: @ [3264,3265]
operator: @ [3264,3265]
===
match
---
trailer [16008,16010]
trailer [16008,16010]
===
match
---
testlist_comp [15187,15210]
testlist_comp [15187,15210]
===
match
---
operator: , [20243,20244]
operator: , [20243,20244]
===
match
---
name: fake_processors [12694,12709]
name: fake_processors [12694,12709]
===
match
---
operator: { [15044,15045]
operator: { [15044,15045]
===
match
---
expr_stmt [3760,3784]
expr_stmt [3760,3784]
===
match
---
string: "airflow.jobs.scheduler_job.DagFileProcessorProcess" [14352,14404]
string: "airflow.jobs.scheduler_job.DagFileProcessorProcess" [14352,14404]
===
match
---
name: args [21924,21928]
name: args [21924,21928]
===
match
---
trailer [22583,22601]
trailer [22583,22601]
===
match
---
name: local_job [10868,10877]
name: local_job [10868,10877]
===
match
---
simple_stmt [23273,23336]
simple_stmt [23453,23516]
===
match
---
name: os [19088,19090]
name: os [19088,19090]
===
match
---
atom [15044,15066]
atom [15044,15066]
===
match
---
dotted_name [21293,21303]
dotted_name [21293,21303]
===
match
---
decorator [18924,18973]
decorator [18924,18973]
===
match
---
operator: , [5327,5328]
operator: , [5327,5328]
===
match
---
atom_expr [7610,7623]
atom_expr [7610,7623]
===
match
---
operator: , [11468,11469]
operator: , [11468,11469]
===
match
---
name: self [21684,21688]
name: self [21684,21688]
===
match
---
atom_expr [13628,13954]
atom_expr [13628,13954]
===
match
---
trailer [9852,9867]
trailer [9852,9867]
===
match
---
string: 'abc.txt' [14123,14132]
string: 'abc.txt' [14123,14132]
===
match
---
atom_expr [19820,19835]
atom_expr [19820,19835]
===
match
---
atom_expr [20001,20026]
atom_expr [20001,20026]
===
match
---
param [3298,3302]
param [3298,3302]
===
match
---
string: 'load_examples' [4071,4086]
string: 'load_examples' [4071,4086]
===
match
---
name: DagFileProcessorAgent [19244,19265]
name: DagFileProcessorAgent [19244,19265]
===
match
---
operator: = [7780,7781]
operator: = [7780,7781]
===
match
---
name: _waitable_handle [3325,3341]
name: _waitable_handle [3325,3341]
===
match
---
name: mock [21011,21015]
name: mock [21011,21015]
===
match
---
trailer [14677,14679]
trailer [14677,14679]
===
match
---
operator: @ [4050,4051]
operator: @ [4050,4051]
===
match
---
argument [14795,14805]
argument [14795,14805]
===
match
---
simple_stmt [4876,4896]
simple_stmt [4876,4896]
===
match
---
arglist [11368,11508]
arglist [11368,11508]
===
match
---
atom [5509,5511]
atom [5509,5511]
===
match
---
name: result [16658,16664]
name: result [16658,16664]
===
match
---
param [21389,21394]
param [21389,21394]
===
match
---
name: mocked_is_zipfile [21940,21957]
name: mocked_is_zipfile [21940,21957]
===
match
---
name: DagFileProcessorManager [13628,13651]
name: DagFileProcessorManager [13628,13651]
===
match
---
simple_stmt [18239,18263]
simple_stmt [18239,18263]
===
match
---
name: ti [8800,8802]
name: ti [8800,8802]
===
match
---
name: pickle_dags [14819,14830]
name: pickle_dags [14819,14830]
===
match
---
expr_stmt [1998,2092]
expr_stmt [1998,2092]
===
match
---
operator: , [19292,19293]
operator: , [19292,19293]
===
match
---
number: 1 [16141,16142]
number: 1 [16141,16142]
===
match
---
trailer [9995,9997]
trailer [9995,9997]
===
match
---
atom_expr [15772,15781]
atom_expr [15772,15781]
===
match
---
operator: = [12174,12175]
operator: = [12174,12175]
===
match
---
suite [16724,16792]
suite [16724,16792]
===
match
---
simple_stmt [9697,9757]
simple_stmt [9697,9757]
===
match
---
name: clear_db_serialized_dags [1972,1996]
name: clear_db_serialized_dags [1972,1996]
===
match
---
name: run_single_parsing_loop [19462,19485]
name: run_single_parsing_loop [19462,19485]
===
match
---
name: SETTINGS_FILE_VALID [1826,1845]
name: SETTINGS_FILE_VALID [1826,1845]
===
match
---
param [17401,17409]
param [17401,17409]
===
match
---
trailer [5446,5450]
trailer [5446,5450]
===
match
---
name: signal_conn [16279,16290]
name: signal_conn [16279,16290]
===
match
---
name: utils [1638,1643]
name: utils [1638,1643]
===
match
---
name: Pipe [4193,4197]
name: Pipe [4193,4197]
===
match
---
name: _processor_factory [20689,20707]
name: _processor_factory [20689,20707]
===
match
---
funcdef [3037,3259]
funcdef [3037,3259]
===
match
---
import_as_name [1227,1245]
import_as_name [1227,1245]
===
match
---
name: TestCase [20995,21003]
name: TestCase [20995,21003]
===
match
---
expr_stmt [19152,19217]
expr_stmt [19152,19217]
===
match
---
name: result [16469,16475]
name: result [16469,16475]
===
match
---
name: utils [1709,1714]
name: utils [1709,1714]
===
match
---
operator: = [8170,8171]
operator: = [8170,8171]
===
match
---
name: TI [8805,8807]
name: TI [8805,8807]
===
match
---
name: async_mode [12568,12578]
name: async_mode [12568,12578]
===
match
---
name: test_start_new_processes_with_same_filepath [4951,4994]
name: test_start_new_processes_with_same_filepath [4951,4994]
===
match
---
name: path [22699,22703]
name: path [22699,22703]
===
match
---
name: _fake_dag_processor_factory [11969,11996]
name: _fake_dag_processor_factory [11969,11996]
===
match
---
name: fake_processors [12739,12754]
name: fake_processors [12739,12754]
===
match
---
decorated [13329,14234]
decorated [13329,14234]
===
match
---
name: timedelta [12310,12319]
name: timedelta [12310,12319]
===
match
---
comp_op [17213,17219]
comp_op [17213,17219]
===
match
---
trailer [22231,22249]
trailer [22231,22249]
===
match
---
simple_stmt [9769,9831]
simple_stmt [9769,9831]
===
match
---
name: utils [1379,1384]
name: utils [1379,1384]
===
match
---
simple_stmt [788,811]
simple_stmt [788,811]
===
match
---
name: DEFAULT_DATE [10823,10835]
name: DEFAULT_DATE [10823,10835]
===
match
---
simple_stmt [9034,9050]
simple_stmt [9034,9050]
===
match
---
trailer [7129,7149]
trailer [7129,7149]
===
match
---
name: DagModel [16758,16766]
name: DagModel [16758,16766]
===
match
---
name: pickle_dags [17483,17494]
name: pickle_dags [17483,17494]
===
match
---
atom [20083,20154]
atom [20083,20154]
===
match
---
atom_expr [9360,9377]
atom_expr [9360,9377]
===
match
---
name: _async_mode [3535,3546]
name: _async_mode [3535,3546]
===
match
---
atom_expr [18890,18918]
atom_expr [18890,18918]
===
match
---
not_test [3804,3839]
not_test [3804,3839]
===
match
---
name: session [9971,9978]
name: session [9971,9978]
===
match
---
operator: = [5536,5537]
operator: = [5536,5537]
===
match
---
name: patch [22764,22769]
name: patch [22764,22769]
===
match
---
atom_expr [8828,8841]
atom_expr [8828,8841]
===
match
---
simple_stmt [1246,1307]
simple_stmt [1246,1307]
===
match
---
decorated [3019,3259]
decorated [3019,3259]
===
match
---
comparison [18067,18119]
comparison [18067,18119]
===
match
---
dotted_name [13431,13441]
dotted_name [13431,13441]
===
match
---
expr_stmt [11562,11640]
expr_stmt [11562,11640]
===
match
---
simple_stmt [14198,14234]
simple_stmt [14198,14234]
===
match
---
name: TI [10814,10816]
name: TI [10814,10816]
===
match
---
name: mock [21293,21297]
name: mock [21293,21297]
===
match
---
trailer [18248,18262]
trailer [18248,18262]
===
match
---
decorated [2845,2894]
decorated [2845,2894]
===
match
---
simple_stmt [6440,6484]
simple_stmt [6440,6484]
===
match
---
parameters [11854,11871]
parameters [11854,11871]
===
match
---
string: 'abc.txt' [14922,14931]
string: 'abc.txt' [14922,14931]
===
match
---
operator: , [7623,7624]
operator: , [7623,7624]
===
match
---
operator: = [19163,19164]
operator: = [19163,19164]
===
match
---
argument [6847,6864]
argument [6847,6864]
===
match
---
name: parent_pipe [13304,13315]
name: parent_pipe [13304,13315]
===
match
---
import_from [1119,1181]
import_from [1119,1181]
===
match
---
name: delete [9950,9956]
name: delete [9950,9956]
===
match
---
name: writable [2567,2575]
name: writable [2567,2575]
===
match
---
atom_expr [15000,15012]
atom_expr [15000,15012]
===
match
---
name: assert_called_once_with [22675,22698]
name: assert_called_once_with [22675,22698]
===
match
---
trailer [20902,20907]
trailer [20902,20907]
===
match
---
simple_stmt [8932,8955]
simple_stmt [8932,8955]
===
match
---
operator: , [21928,21929]
operator: , [21928,21929]
===
match
---
operator: , [1955,1956]
operator: , [1955,1956]
===
match
---
comparison [6447,6483]
comparison [6447,6483]
===
match
---
name: dag [9465,9468]
name: dag [9465,9468]
===
match
---
expr_stmt [21778,21815]
expr_stmt [21778,21815]
===
match
---
trailer [2044,2072]
trailer [2044,2072]
===
match
---
string: "zipfile.is_zipfile" [22732,22752]
string: "zipfile.is_zipfile" [22732,22752]
===
match
---
argument [6685,6727]
argument [6685,6727]
===
match
---
operator: , [15193,15194]
operator: , [15193,15194]
===
match
---
name: DagParsingStat [1607,1621]
name: DagParsingStat [1607,1621]
===
match
---
comparison [9436,9482]
comparison [9436,9482]
===
match
---
number: 0 [12755,12756]
number: 0 [12755,12756]
===
match
---
operator: = [16115,16116]
operator: = [16115,16116]
===
match
---
name: test_set_file_paths_when_processor_file_path_not_in_new_file_paths [6493,6559]
name: test_set_file_paths_when_processor_file_path_not_in_new_file_paths [6493,6559]
===
match
---
operator: == [22014,22016]
operator: == [22014,22016]
===
match
---
name: readable [2557,2565]
name: readable [2557,2565]
===
match
---
name: airflow [1470,1477]
name: airflow [1470,1477]
===
match
---
suite [3113,3259]
suite [3113,3259]
===
match
---
name: __init__ [2423,2431]
name: __init__ [2423,2431]
===
match
---
name: dag_ids [6823,6830]
name: dag_ids [6823,6830]
===
match
---
name: self [16936,16940]
name: self [16936,16940]
===
match
---
simple_stmt [20919,20955]
simple_stmt [20919,20955]
===
match
---
string: "airflow.jobs.scheduler_job.DagFileProcessorProcess.pid" [13341,13397]
string: "airflow.jobs.scheduler_job.DagFileProcessorProcess.pid" [13341,13397]
===
match
---
simple_stmt [21577,21603]
simple_stmt [21577,21603]
===
match
---
name: self [2675,2679]
name: self [2675,2679]
===
match
---
param [11862,11870]
param [11862,11870]
===
match
---
trailer [3977,4044]
trailer [3977,4044]
===
match
---
name: test_correct_maybe_zipped_normal_file [21052,21089]
name: test_correct_maybe_zipped_normal_file [21052,21089]
===
match
---
operator: = [5849,5850]
operator: = [5849,5850]
===
match
---
operator: { [4061,4062]
operator: { [4061,4062]
===
match
---
import_as_names [1209,1245]
import_as_names [1209,1245]
===
match
---
atom_expr [17254,17277]
atom_expr [17254,17277]
===
match
---
arglist [14000,14024]
arglist [14000,14024]
===
match
---
trailer [7968,7980]
trailer [7968,7980]
===
match
---
operator: = [20367,20368]
operator: = [20367,20368]
===
match
---
operator: = [13847,13848]
operator: = [13847,13848]
===
match
---
with_stmt [19750,20155]
with_stmt [19750,20155]
===
match
---
name: State [8828,8833]
name: State [8828,8833]
===
match
---
comparison [19881,19963]
comparison [19881,19963]
===
match
---
atom_expr [6353,6379]
atom_expr [6353,6379]
===
match
---
atom_expr [15926,15952]
atom_expr [15926,15952]
===
match
---
simple_stmt [10486,10542]
simple_stmt [10486,10542]
===
match
---
name: execution_timeout [15240,15257]
name: execution_timeout [15240,15257]
===
match
---
operator: , [5487,5488]
operator: , [5487,5488]
===
match
---
atom_expr [9465,9482]
atom_expr [9465,9482]
===
match
---
name: async_mode [14850,14860]
name: async_mode [14850,14860]
===
match
---
operator: = [11381,11382]
operator: = [11381,11382]
===
match
---
operator: , [3098,3099]
operator: , [3098,3099]
===
match
---
import_from [1366,1400]
import_from [1366,1400]
===
match
---
name: dag_id [16772,16778]
name: dag_id [16772,16778]
===
match
---
name: mock_file [22606,22615]
name: mock_file [22606,22615]
===
match
---
name: pickle_dags [8434,8445]
name: pickle_dags [8434,8445]
===
match
---
operator: , [1579,1580]
operator: , [1579,1580]
===
match
---
name: requests [9502,9510]
name: requests [9502,9510]
===
match
---
atom [4061,4097]
atom [4061,4097]
===
match
---
name: ti [11169,11171]
name: ti [11169,11171]
===
match
---
simple_stmt [2766,2771]
simple_stmt [2766,2771]
===
match
---
simple_stmt [21825,21865]
simple_stmt [21825,21865]
===
match
---
name: os [2045,2047]
name: os [2045,2047]
===
match
---
name: async_mode [4733,4743]
name: async_mode [4733,4743]
===
match
---
name: PropertyMock [13412,13424]
name: PropertyMock [13412,13424]
===
match
---
operator: , [7660,7661]
operator: , [7660,7661]
===
match
---
atom_expr [2650,2666]
atom_expr [2650,2666]
===
match
---
string: 'builtins.open' [22200,22215]
string: 'builtins.open' [22200,22215]
===
match
---
trailer [2126,2138]
trailer [2126,2138]
===
match
---
trailer [6940,6942]
trailer [6940,6942]
===
match
---
name: test_open_maybe_zipped_normal_file [22134,22168]
name: test_open_maybe_zipped_normal_file [22134,22168]
===
match
---
name: path [21718,21722]
name: path [21718,21722]
===
match
---
name: obj [3902,3905]
name: obj [3902,3905]
===
match
---
comparison [6343,6379]
comparison [6343,6379]
===
match
---
name: get [18088,18091]
name: get [18088,18091]
===
match
---
operator: = [10919,10920]
operator: = [10919,10920]
===
match
---
name: processor_agent [19625,19640]
name: processor_agent [19625,19640]
===
match
---
name: DagParsingSignal [3577,3593]
name: DagParsingSignal [3577,3593]
===
match
---
trailer [19994,20000]
trailer [19994,20000]
===
match
---
operator: == [8089,8091]
operator: == [8089,8091]
===
match
---
simple_stmt [7802,7900]
simple_stmt [7802,7900]
===
match
---
atom_expr [3902,3910]
atom_expr [3902,3910]
===
match
---
operator: = [4709,4710]
operator: = [4709,4710]
===
match
---
operator: , [12002,12003]
operator: , [12002,12003]
===
match
---
name: path [2032,2036]
name: path [2032,2036]
===
match
---
simple_stmt [21778,21816]
simple_stmt [21778,21816]
===
match
---
name: file_1 [5592,5598]
name: file_1 [5592,5598]
===
match
---
trailer [10315,10320]
trailer [10315,10320]
===
match
---
trailer [13811,13822]
trailer [13811,13822]
===
match
---
operator: , [14457,14458]
operator: , [14457,14458]
===
match
---
trailer [11164,11168]
trailer [11164,11168]
===
match
---
suite [22470,22715]
suite [22470,22715]
===
match
---
operator: , [8359,8360]
operator: , [8359,8360]
===
match
---
atom_expr [7217,7249]
atom_expr [7217,7249]
===
match
---
name: close [13316,13321]
name: close [13316,13321]
===
match
---
name: fake_processors [12030,12045]
name: fake_processors [12030,12045]
===
match
---
name: dag_ids [20072,20079]
name: dag_ids [20072,20079]
===
match
---
arglist [18467,18552]
arglist [18467,18552]
===
match
---
argument [14758,14781]
argument [14758,14781]
===
match
---
name: timedelta [4599,4608]
name: timedelta [4599,4608]
===
match
---
string: 'test_start_date_scheduling' [20085,20113]
string: 'test_start_date_scheduling' [20085,20113]
===
match
---
trailer [4787,4818]
trailer [4787,4818]
===
match
---
name: mode [22393,22397]
name: mode [22393,22397]
===
match
---
atom_expr [14100,14119]
atom_expr [14100,14119]
===
match
---
expr_stmt [8886,8918]
expr_stmt [8886,8918]
===
match
---
atom_expr [3766,3784]
atom_expr [3766,3784]
===
match
---
argument [7473,7498]
argument [7473,7498]
===
match
---
trailer [15732,15741]
trailer [15732,15741]
===
match
---
name: TestDagFileProcessorManager [3350,3377]
name: TestDagFileProcessorManager [3350,3377]
===
match
---
suite [20499,20517]
suite [20499,20517]
===
match
---
decorated [21010,21287]
decorated [21010,21287]
===
match
---
expr_stmt [8741,8786]
expr_stmt [8741,8786]
===
match
---
operator: = [8746,8747]
operator: = [8746,8747]
===
match
---
name: mod [17291,17294]
name: mod [17291,17294]
===
match
---
name: _find_zombies [9250,9263]
name: _find_zombies [9250,9263]
===
match
---
name: result [16523,16529]
name: result [16523,16529]
===
match
---
name: simple_task_instance [9729,9749]
name: simple_task_instance [9729,9749]
===
match
---
trailer [12498,12529]
trailer [12498,12529]
===
match
---
operator: = [6669,6670]
operator: = [6669,6670]
===
match
---
atom_expr [23117,23182]
atom_expr [23297,23362]
===
match
---
name: return_value [22897,22909]
name: return_value [22957,22969]
===
match
---
simple_stmt [1864,1910]
simple_stmt [1864,1910]
===
match
---
comp_op [20301,20307]
comp_op [20301,20307]
===
match
---
trailer [8939,8943]
trailer [8939,8943]
===
match
---
operator: , [19352,19353]
operator: , [19352,19353]
===
match
---
name: test_dag_path [19072,19085]
name: test_dag_path [19072,19085]
===
match
---
name: State [8904,8909]
name: State [8904,8909]
===
match
---
name: test_dag_path [10292,10305]
name: test_dag_path [10292,10305]
===
match
---
trailer [12897,12914]
trailer [12897,12914]
===
match
---
name: log_file_loc [20941,20953]
name: log_file_loc [20941,20953]
===
match
---
name: return_value [13758,13770]
name: return_value [13758,13770]
===
match
---
name: join [17994,17998]
name: join [17994,17998]
===
match
---
simple_stmt [19226,19375]
simple_stmt [19226,19375]
===
match
---
name: seconds [13812,13819]
name: seconds [13812,13819]
===
match
---
name: timedelta [9146,9155]
name: timedelta [9146,9155]
===
match
---
simple_stmt [9429,9483]
simple_stmt [9429,9483]
===
match
---
nonlocal_stmt [11889,11913]
nonlocal_stmt [11889,11913]
===
match
---
name: MagicMock [14770,14779]
name: MagicMock [14770,14779]
===
match
---
param [17410,17418]
param [17410,17418]
===
match
---
name: log_file_loc [20462,20474]
name: log_file_loc [20462,20474]
===
match
---
simple_stmt [11157,11173]
simple_stmt [11157,11173]
===
match
---
name: processor_agent [18410,18425]
name: processor_agent [18410,18425]
===
match
---
atom_expr [2621,2641]
atom_expr [2621,2641]
===
match
---
atom_expr [8346,8359]
atom_expr [8346,8359]
===
match
---
assert_stmt [9843,9918]
assert_stmt [9843,9918]
===
match
---
simple_stmt [17145,17162]
simple_stmt [17145,17162]
===
match
---
name: mock_open [22574,22583]
name: mock_open [22574,22583]
===
match
---
simple_stmt [5210,5247]
simple_stmt [5210,5247]
===
match
---
operator: } [4096,4097]
operator: } [4096,4097]
===
match
---
name: writable [2650,2658]
name: writable [2650,2658]
===
match
---
atom_expr [12310,12323]
atom_expr [12310,12323]
===
match
---
trailer [20928,20933]
trailer [20928,20933]
===
match
---
simple_stmt [4291,4357]
simple_stmt [4291,4357]
===
match
---
operator: = [8384,8385]
operator: = [8384,8385]
===
match
---
name: dict [16955,16959]
name: dict [16955,16959]
===
match
---
trailer [20019,20026]
trailer [20019,20026]
===
match
---
atom_expr [8932,8954]
atom_expr [8932,8954]
===
match
---
trailer [14573,14876]
trailer [14573,14876]
===
match
---
name: fake_processor_factory [12252,12274]
name: fake_processor_factory [12252,12274]
===
match
---
name: DagFileProcessorProcess [14898,14921]
name: DagFileProcessorProcess [14898,14921]
===
match
---
name: processor_agent [19575,19590]
name: processor_agent [19575,19590]
===
match
---
name: signal_conn [4630,4641]
name: signal_conn [4630,4641]
===
match
---
atom_expr [9871,9918]
atom_expr [9871,9918]
===
match
---
trailer [9639,9642]
trailer [9639,9642]
===
match
---
decorator [15174,15223]
decorator [15174,15223]
===
match
---
operator: , [8826,8827]
operator: , [8826,8827]
===
match
---
expr_stmt [20279,20344]
expr_stmt [20279,20344]
===
match
---
decorator [3264,3274]
decorator [3264,3274]
===
match
---
number: 1 [14635,14636]
number: 1 [14635,14636]
===
match
---
name: airflow [1124,1131]
name: airflow [1124,1131]
===
match
---
atom_expr [19575,19612]
atom_expr [19575,19612]
===
match
---
name: TEST_DAG_FOLDER [20228,20243]
name: TEST_DAG_FOLDER [20228,20243]
===
match
---
atom_expr [5679,5703]
atom_expr [5679,5703]
===
match
---
operator: == [7330,7332]
operator: == [7330,7332]
===
match
---
name: state [8896,8901]
name: state [8896,8901]
===
match
---
argument [5341,5351]
argument [5341,5351]
===
match
---
argument [14819,14836]
argument [14819,14836]
===
match
---
name: manager [12530,12537]
name: manager [12530,12537]
===
match
---
name: dag_directory [13665,13678]
name: dag_directory [13665,13678]
===
match
---
testlist_star_expr [4151,4174]
testlist_star_expr [4151,4174]
===
match
---
name: unittest [3378,3386]
name: unittest [3378,3386]
===
match
---
name: full_filepath [11386,11399]
name: full_filepath [11386,11399]
===
match
---
atom_expr [21225,21251]
atom_expr [21225,21251]
===
match
---
name: read_dags_from_db [10517,10534]
name: read_dags_from_db [10517,10534]
===
match
---
name: job_id [11192,11198]
name: job_id [11192,11198]
===
match
---
trailer [20785,20787]
trailer [20785,20787]
===
match
---
trailer [3155,3258]
trailer [3155,3258]
===
match
---
decorator [15227,15262]
decorator [15227,15262]
===
match
---
arglist [14922,14946]
arglist [14922,14946]
===
match
---
with_item [4214,4277]
with_item [4214,4277]
===
match
---
operator: , [10336,10337]
operator: , [10336,10337]
===
match
---
param [17419,17430]
param [17419,17430]
===
match
---
testlist_comp [21924,21936]
testlist_comp [21924,21936]
===
match
---
decorator [14340,14406]
decorator [14340,14406]
===
match
---
parameters [14452,14493]
parameters [14452,14493]
===
match
---
name: child_pipe [11654,11664]
name: child_pipe [11654,11664]
===
match
---
operator: = [16028,16029]
operator: = [16028,16029]
===
match
---
parameters [2750,2756]
parameters [2750,2756]
===
match
---
name: test_open_maybe_zipped_normal_file_with_zip_in_name [22412,22463]
name: test_open_maybe_zipped_normal_file_with_zip_in_name [22412,22463]
===
match
---
name: ti [8870,8872]
name: ti [8870,8872]
===
match
---
assert_stmt [9429,9482]
assert_stmt [9429,9482]
===
match
---
name: isinstance [16512,16522]
name: isinstance [16512,16522]
===
match
---
with_item [16696,16723]
with_item [16696,16723]
===
match
---
except_clause [20484,20498]
except_clause [20484,20498]
===
match
---
name: timedelta [20709,20718]
name: timedelta [20709,20718]
===
match
---
atom_expr [14898,14947]
atom_expr [14898,14947]
===
match
---
trailer [10501,10541]
trailer [10501,10541]
===
match
---
name: ti [9850,9852]
name: ti [9850,9852]
===
match
---
operator: = [13678,13679]
operator: = [13678,13679]
===
match
---
name: dag_directory [16067,16080]
name: dag_directory [16067,16080]
===
match
---
trailer [10617,10621]
trailer [10617,10621]
===
match
---
name: callback_requests [13228,13245]
name: callback_requests [13228,13245]
===
match
---
trailer [9978,9984]
trailer [9978,9984]
===
match
---
atom_expr [4177,4199]
atom_expr [4177,4199]
===
match
---
assert_stmt [21984,22024]
assert_stmt [21984,22024]
===
match
---
atom_expr [9790,9830]
atom_expr [9790,9830]
===
match
---
name: dag_directory [16081,16094]
name: dag_directory [16081,16094]
===
match
---
string: 'test_task_start_date_scheduling' [19927,19960]
string: 'test_task_start_date_scheduling' [19927,19960]
===
match
---
import_as_names [1512,1622]
import_as_names [1512,1622]
===
match
---
operator: = [8902,8903]
operator: = [8902,8903]
===
match
---
param [4995,4999]
param [4995,4999]
===
match
---
operator: , [11606,11607]
operator: , [11606,11607]
===
match
---
name: get [18152,18155]
name: get [18152,18155]
===
match
---
atom_expr [9717,9756]
atom_expr [9717,9756]
===
match
---
argument [5556,5571]
argument [5556,5571]
===
match
---
name: async_mode [18622,18632]
name: async_mode [18622,18632]
===
match
---
atom_expr [20215,20270]
atom_expr [20215,20270]
===
match
---
name: signal_conn [6786,6797]
name: signal_conn [6786,6797]
===
match
---
trailer [13999,14025]
trailer [13999,14025]
===
match
---
param [16991,16995]
param [16991,16995]
===
match
---
trailer [7563,7565]
trailer [7563,7565]
===
match
---
simple_stmt [8855,8874]
simple_stmt [8855,8874]
===
match
---
argument [4420,4445]
argument [4420,4445]
===
match
---
name: delete [10622,10628]
name: delete [10622,10628]
===
match
---
trailer [4608,4612]
trailer [4608,4612]
===
match
---
name: file_3 [6448,6454]
name: file_3 [6448,6454]
===
match
---
name: max [4609,4612]
name: max [4609,4612]
===
match
---
argument [16227,16265]
argument [16227,16265]
===
match
---
trailer [8620,8626]
trailer [8620,8626]
===
match
---
simple_stmt [12732,12786]
simple_stmt [12732,12786]
===
match
---
atom_expr [23273,23335]
atom_expr [23453,23515]
===
match
---
trailer [19337,19341]
trailer [19337,19341]
===
match
---
atom_expr [23002,23034]
atom_expr [23005,23037]
===
match
---
atom_expr [21778,21808]
atom_expr [21778,21808]
===
match
---
expr_stmt [4369,4769]
expr_stmt [4369,4769]
===
match
---
param [2373,2385]
param [2373,2385]
===
match
---
trailer [13289,13291]
trailer [13289,13291]
===
match
---
string: 'file_1.py' [5601,5612]
string: 'file_1.py' [5601,5612]
===
match
---
decorators [22720,22789]
decorators [22720,22825]
===
match
---
import_name [821,831]
import_name [821,831]
===
match
---
name: file_3 [5723,5729]
name: file_3 [5723,5729]
===
match
---
atom_expr [4849,4867]
atom_expr [4849,4867]
===
match
---
name: mock [23002,23006]
name: mock [23005,23009]
===
match
---
string: 'abc' [2635,2640]
string: 'abc' [2635,2640]
===
match
---
while_stmt [3641,4045]
while_stmt [3641,4045]
===
match
---
simple_stmt [20065,20155]
simple_stmt [20065,20155]
===
match
---
operator: , [13714,13715]
operator: , [13714,13715]
===
match
---
trailer [20940,20954]
trailer [20940,20954]
===
match
---
arglist [2432,2474]
arglist [2432,2474]
===
match
---
trailer [22573,22583]
trailer [22573,22583]
===
match
---
operator: } [8118,8119]
operator: } [8118,8119]
===
match
---
name: TaskCallbackRequest [11323,11342]
name: TaskCallbackRequest [11323,11342]
===
match
---
name: file_path [2362,2371]
name: file_path [2362,2371]
===
match
---
number: 0 [9445,9446]
number: 0 [9445,9446]
===
match
---
name: make_aware [14067,14077]
name: make_aware [14067,14077]
===
match
---
trailer [23016,23034]
trailer [23019,23037]
===
match
---
parameters [2978,2984]
parameters [2978,2984]
===
match
---
atom_expr [7554,7578]
atom_expr [7554,7578]
===
match
---
atom_expr [9034,9049]
atom_expr [9034,9049]
===
match
---
param [17390,17400]
param [17390,17400]
===
match
---
operator: , [8396,8397]
operator: , [8396,8397]
===
match
---
name: type [18485,18489]
name: type [18485,18489]
===
match
---
operator: , [18514,18515]
operator: , [18514,18515]
===
match
---
name: dag_id [20020,20026]
name: dag_id [20020,20026]
===
match
---
name: tearDown [16982,16990]
name: tearDown [16982,16990]
===
match
---
trailer [21795,21808]
trailer [21795,21808]
===
match
---
operator: = [3736,3737]
operator: = [3736,3737]
===
match
---
operator: * [11997,11998]
operator: * [11997,11998]
===
match
---
operator: == [12847,12849]
operator: == [12847,12849]
===
match
---
name: session [19987,19994]
name: session [19987,19994]
===
match
---
name: callbacks [2465,2474]
name: callbacks [2465,2474]
===
match
---
suite [2757,2771]
suite [2757,2771]
===
match
---
name: self [2356,2360]
name: self [2356,2360]
===
match
---
name: poll [3724,3728]
name: poll [3724,3728]
===
match
---
atom_expr [6585,6904]
atom_expr [6585,6904]
===
match
---
arglist [23231,23263]
arglist [23411,23443]
===
match
---
operator: , [6727,6728]
operator: , [6727,6728]
===
match
---
atom [10394,10471]
atom [10394,10471]
===
match
---
arglist [4819,4839]
arglist [4819,4839]
===
match
---
funcdef [3278,3342]
funcdef [3278,3342]
===
match
---
name: mark [4909,4913]
name: mark [4909,4913]
===
match
---
trailer [9725,9728]
trailer [9725,9728]
===
match
---
name: airflow [15620,15627]
name: airflow [15620,15627]
===
match
---
trailer [4232,4262]
trailer [4232,4262]
===
match
---
name: self [22464,22468]
name: self [22464,22468]
===
match
---
name: clear_db_serialized_dags [19012,19036]
name: clear_db_serialized_dags [19012,19036]
===
match
---
name: _zombie_threshold_secs [9189,9211]
name: _zombie_threshold_secs [9189,9211]
===
match
---
trailer [19610,19612]
trailer [19610,19612]
===
match
---
trailer [19307,19326]
trailer [19307,19326]
===
match
---
operator: , [18014,18015]
operator: , [18014,18015]
===
match
---
name: fake_processors [11794,11809]
name: fake_processors [11794,11809]
===
match
---
operator: == [12971,12973]
operator: == [12971,12973]
===
match
---
name: unittest [960,968]
name: unittest [960,968]
===
match
---
trailer [15008,15012]
trailer [15008,15012]
===
match
---
operator: , [2565,2566]
operator: , [2565,2566]
===
match
---
trailer [2593,2598]
trailer [2593,2598]
===
match
---
argument [16156,16213]
argument [16156,16213]
===
match
---
operator: = [8256,8257]
operator: = [8256,8257]
===
match
---
import_from [929,954]
import_from [929,954]
===
match
---
dictorsetmaker [13182,13245]
dictorsetmaker [13182,13245]
===
match
---
simple_stmt [1998,2093]
simple_stmt [1998,2093]
===
match
---
name: processor_agent [19383,19398]
name: processor_agent [19383,19398]
===
match
---
simple_stmt [12030,12064]
simple_stmt [12030,12064]
===
match
---
operator: , [12426,12427]
operator: , [12426,12427]
===
match
---
name: async_mode [11715,11725]
name: async_mode [11715,11725]
===
match
---
trailer [23286,23310]
trailer [23466,23490]
===
match
---
trailer [12045,12052]
trailer [12045,12052]
===
match
---
name: max [12320,12323]
name: max [12320,12323]
===
match
---
name: datetime [853,861]
name: datetime [853,861]
===
match
---
name: session [8592,8599]
name: session [8592,8599]
===
match
---
import_from [848,888]
import_from [848,888]
===
match
---
parameters [7410,7416]
parameters [7410,7416]
===
match
---
argument [14650,14692]
argument [14650,14692]
===
match
---
name: msg [9514,9517]
name: msg [9514,9517]
===
match
---
classdef [2141,3342]
classdef [2141,3342]
===
match
---
trailer [19265,19374]
trailer [19265,19374]
===
match
---
number: 1 [2133,2134]
number: 1 [2133,2134]
===
match
---
argument [16067,16094]
argument [16067,16094]
===
match
---
trailer [2422,2431]
trailer [2422,2431]
===
match
---
trailer [2047,2052]
trailer [2047,2052]
===
match
---
operator: , [15972,15973]
operator: , [15972,15973]
===
match
---
expr_stmt [10647,10697]
expr_stmt [10647,10697]
===
match
---
simple_stmt [15075,15112]
simple_stmt [15075,15112]
===
match
---
trailer [20866,20868]
trailer [20866,20868]
===
match
---
atom_expr [22189,22250]
atom_expr [22189,22250]
===
match
---
argument [8761,8785]
argument [8761,8785]
===
match
---
name: max [15009,15012]
name: max [15009,15012]
===
match
---
import_from [1465,1624]
import_from [1465,1624]
===
match
---
atom_expr [8069,8088]
atom_expr [8069,8088]
===
match
---
name: ti [9046,9048]
name: ti [9046,9048]
===
match
---
name: add [11165,11168]
name: add [11165,11168]
===
match
---
name: _run_parsing_loop [3673,3690]
name: _run_parsing_loop [3673,3690]
===
match
---
name: log_file_loc [18249,18261]
name: log_file_loc [18249,18261]
===
match
---
operator: , [14612,14613]
operator: , [14612,14613]
===
match
---
name: session [19806,19813]
name: session [19806,19813]
===
match
---
name: obj [3760,3763]
name: obj [3760,3763]
===
match
---
name: mod [17174,17177]
name: mod [17174,17177]
===
match
---
simple_stmt [17970,18042]
simple_stmt [17970,18042]
===
match
---
operator: } [15065,15066]
operator: } [15065,15066]
===
match
---
atom_expr [16826,16843]
atom_expr [16826,16843]
===
match
---
operator: = [12251,12252]
operator: = [12251,12252]
===
match
---
name: session [8932,8939]
name: session [8932,8939]
===
match
---
atom_expr [9620,9684]
atom_expr [9620,9684]
===
match
---
name: file_path [3069,3078]
name: file_path [3069,3078]
===
match
---
operator: @ [14340,14341]
operator: @ [14340,14341]
===
match
---
funcdef [3448,4045]
funcdef [3448,4045]
===
match
---
name: recv [3778,3782]
name: recv [3778,3782]
===
match
---
name: processor_factory [6685,6702]
name: processor_factory [6685,6702]
===
match
---
trailer [8981,8983]
trailer [8981,8983]
===
match
---
simple_stmt [19874,19964]
simple_stmt [19874,19964]
===
match
---
trailer [9363,9377]
trailer [9363,9377]
===
match
---
arglist [17472,17512]
arglist [17472,17512]
===
match
---
trailer [23061,23107]
trailer [23167,23213]
===
match
---
name: delete [8631,8637]
name: delete [8631,8637]
===
match
---
string: """         Configure the context to have logging.logging_config_class set to a fake logging         class path, thus when reloading logging module the airflow.processor_manager         logger should not be configured.         """ [17557,17787]
string: """         Configure the context to have logging.logging_config_class set to a fake logging         class path, thus when reloading logging module the airflow.processor_manager         logger should not be configured.         """ [17557,17787]
===
match
---
name: manager [7110,7117]
name: manager [7110,7117]
===
match
---
assert_stmt [9697,9756]
assert_stmt [9697,9756]
===
match
---
trailer [21858,21864]
trailer [21858,21864]
===
match
---
operator: , [3224,3225]
operator: , [3224,3225]
===
match
---
atom_expr [22541,22602]
atom_expr [22541,22602]
===
match
---
param [4135,4139]
param [4135,4139]
===
match
---
atom_expr [20764,20787]
atom_expr [20764,20787]
===
match
---
funcdef [2343,2736]
funcdef [2343,2736]
===
match
---
arith_expr [9126,9229]
arith_expr [9126,9229]
===
match
---
assert_stmt [9554,9600]
assert_stmt [9554,9600]
===
match
---
dictorsetmaker [13079,13159]
dictorsetmaker [13079,13159]
===
match
---
name: args [22017,22021]
name: args [22017,22021]
===
match
---
operator: = [6797,6798]
operator: = [6797,6798]
===
match
---
name: session [16716,16723]
name: session [16716,16723]
===
match
---
import_from [1401,1464]
import_from [1401,1464]
===
match
---
trailer [13188,13209]
trailer [13188,13209]
===
match
---
trailer [21898,21909]
trailer [21898,21909]
===
match
---
import_from [1864,1909]
import_from [1864,1909]
===
match
---
arglist [2127,2137]
arglist [2127,2137]
===
match
---
name: datetime [14078,14086]
name: datetime [14078,14086]
===
match
---
param [3498,3509]
param [3498,3509]
===
match
---
assert_stmt [19713,19740]
assert_stmt [19713,19740]
===
match
---
trailer [3782,3784]
trailer [3782,3784]
===
match
---
operator: , [13770,13771]
operator: , [13770,13771]
===
match
---
operator: , [8532,8533]
operator: , [8532,8533]
===
match
---
atom_expr [23044,23107]
atom_expr [23150,23213]
===
match
---
simple_stmt [14503,14532]
simple_stmt [14503,14532]
===
match
---
param [3069,3079]
param [3069,3079]
===
match
---
atom_expr [9561,9592]
atom_expr [9561,9592]
===
match
---
dotted_name [15228,15257]
dotted_name [15228,15257]
===
match
---
string: '/path/to/some/file.txt' [22295,22319]
string: '/path/to/some/file.txt' [22295,22319]
===
match
---
argument [23017,23033]
argument [23020,23036]
===
match
---
return_stmt [2994,3013]
return_stmt [2994,3013]
===
match
---
name: len [9403,9406]
name: len [9403,9406]
===
match
---
simple_stmt [19383,19407]
simple_stmt [19383,19407]
===
match
---
name: mock_processor [8104,8118]
name: mock_processor [8104,8118]
===
match
---
param [21690,21707]
param [21690,21707]
===
match
---
simple_stmt [18650,18692]
simple_stmt [18650,18692]
===
match
---
name: _processors [14108,14119]
name: _processors [14108,14119]
===
match
---
name: order_by [20028,20036]
name: order_by [20028,20036]
===
match
---
name: child_pipe [15962,15972]
name: child_pipe [15962,15972]
===
match
---
operator: , [19295,19296]
operator: , [19295,19296]
===
match
---
operator: , [13822,13823]
operator: , [13822,13823]
===
match
---
name: os [15725,15727]
name: os [15725,15727]
===
match
---
trailer [10963,10974]
trailer [10963,10974]
===
match
---
operator: , [17481,17482]
operator: , [17481,17482]
===
match
---
trailer [8040,8053]
trailer [8040,8053]
===
match
---
operator: = [2697,2698]
operator: = [2697,2698]
===
match
---
arglist [14587,14866]
arglist [14587,14866]
===
match
---
name: patch [22726,22731]
name: patch [22726,22731]
===
match
---
comparison [9850,9918]
comparison [9850,9918]
===
match
---
operator: { [7333,7334]
operator: { [7333,7334]
===
match
---
simple_stmt [14034,14092]
simple_stmt [14034,14092]
===
match
---
operator: = [12309,12310]
operator: = [12309,12310]
===
match
---
name: MagicMock [13848,13857]
name: MagicMock [13848,13857]
===
match
---
name: test_handle_failure_callback_with_zombies_are_correctly_passed_to_dag_file_processor [10007,10091]
name: test_handle_failure_callback_with_zombies_are_correctly_passed_to_dag_file_processor [10007,10091]
===
match
---
atom_expr [20369,20426]
atom_expr [20369,20426]
===
match
---
name: datetime [2118,2126]
name: datetime [2118,2126]
===
match
---
atom [10395,10429]
atom [10395,10429]
===
match
---
arglist [20228,20269]
arglist [20228,20269]
===
match
---
name: open_maybe_zipped [22629,22646]
name: open_maybe_zipped [22629,22646]
===
match
---
simple_stmt [21261,21287]
simple_stmt [21261,21287]
===
match
---
operator: , [3178,3179]
operator: , [3178,3179]
===
match
---
name: manager [7310,7317]
name: manager [7310,7317]
===
match
---
decorator [13430,13501]
decorator [13430,13501]
===
match
---
atom [10436,10461]
atom [10436,10461]
===
match
---
string: 'file_2.py' [6299,6310]
string: 'file_2.py' [6299,6310]
===
match
---
expr_stmt [13000,13058]
expr_stmt [13000,13058]
===
match
---
trailer [19855,19859]
trailer [19855,19859]
===
match
---
simple_stmt [21480,21519]
simple_stmt [21480,21519]
===
match
---
trailer [18600,18602]
trailer [18600,18602]
===
match
---
string: 'run_this_last' [10775,10790]
string: 'run_this_last' [10775,10790]
===
match
---
argument [11425,11468]
argument [11425,11468]
===
match
---
string: '/path/to/some/file.txt' [21131,21155]
string: '/path/to/some/file.txt' [21131,21155]
===
match
---
atom_expr [4320,4356]
atom_expr [4320,4356]
===
match
---
simple_stmt [23044,23108]
simple_stmt [23150,23214]
===
match
---
simple_stmt [10107,10284]
simple_stmt [10107,10284]
===
match
---
trailer [15774,15781]
trailer [15774,15781]
===
match
---
parameters [21683,21708]
parameters [21683,21708]
===
match
---
funcdef [22408,22715]
funcdef [22408,22715]
===
match
---
atom [18935,18971]
atom [18935,18971]
===
match
---
operator: @ [3019,3020]
operator: @ [3019,3020]
===
match
---
name: task_id [8761,8768]
name: task_id [8761,8768]
===
match
---
funcdef [21646,22078]
funcdef [21646,22078]
===
match
---
atom_expr [17327,17343]
atom_expr [17327,17343]
===
match
---
trailer [13651,13954]
trailer [13651,13954]
===
match
---
expr_stmt [15676,15700]
expr_stmt [15676,15700]
===
match
---
operator: , [20151,20152]
operator: , [20151,20152]
===
match
---
atom_expr [8172,8491]
atom_expr [8172,8491]
===
match
---
name: dag [10647,10650]
name: dag [10647,10650]
===
match
---
operator: = [23259,23260]
operator: = [23439,23440]
===
match
---
simple_stmt [5010,5202]
simple_stmt [5010,5202]
===
match
---
suite [22616,22715]
suite [22616,22715]
===
match
---
trailer [9141,9143]
trailer [9141,9143]
===
match
---
name: processor [13964,13973]
name: processor [13964,13973]
===
match
---
operator: = [2605,2606]
operator: = [2605,2606]
===
match
---
name: dag_ids [19796,19803]
name: dag_ids [19796,19803]
===
match
---
operator: = [8865,8866]
operator: = [8865,8866]
===
match
---
name: waitable_handle [3282,3297]
name: waitable_handle [3282,3297]
===
match
---
trailer [9728,9749]
trailer [9728,9749]
===
match
---
operator: = [5566,5567]
operator: = [5566,5567]
===
match
---
trailer [10998,11005]
trailer [10998,11005]
===
match
---
atom_expr [8510,8558]
atom_expr [8510,8558]
===
match
---
atom_expr [12030,12063]
atom_expr [12030,12063]
===
match
---
name: processor_agent [19446,19461]
name: processor_agent [19446,19461]
===
match
---
simple_stmt [22629,22653]
simple_stmt [22629,22653]
===
match
---
name: mock_processor [6951,6965]
name: mock_processor [6951,6965]
===
match
---
trailer [8715,8726]
trailer [8715,8726]
===
match
---
atom_expr [3861,3880]
atom_expr [3861,3880]
===
match
---
parameters [3068,3112]
parameters [3068,3112]
===
match
---
suite [19558,19613]
suite [19558,19613]
===
match
---
name: processor_factory [13728,13745]
name: processor_factory [13728,13745]
===
match
---
comparison [9502,9541]
comparison [9502,9541]
===
match
---
trailer [22674,22698]
trailer [22674,22698]
===
match
---
name: dag_ids [16108,16115]
name: dag_ids [16108,16115]
===
match
---
suite [3743,3947]
suite [3743,3947]
===
match
---
trailer [3728,3742]
trailer [3728,3742]
===
match
---
trailer [17224,17236]
trailer [17224,17236]
===
match
---
decorated [18924,20155]
decorated [18924,20155]
===
match
---
string: 'r' [22710,22713]
string: 'r' [22710,22713]
===
match
---
atom_expr [7908,7944]
atom_expr [7908,7944]
===
match
---
name: sys [828,831]
name: sys [828,831]
===
match
---
string: "Shouldn't get here - nothing to read, but manager not finished!" [3978,4043]
string: "Shouldn't get here - nothing to read, but manager not finished!" [3978,4043]
===
match
---
argument [22584,22600]
argument [22584,22600]
===
match
---
name: sys [16960,16963]
name: sys [16960,16963]
===
match
---
name: stop [7817,7821]
name: stop [7817,7821]
===
match
---
name: min [14087,14090]
name: min [14087,14090]
===
match
---
name: open_maybe_zipped [1678,1695]
name: open_maybe_zipped [1678,1695]
===
match
---
name: results [3939,3946]
name: results [3939,3946]
===
match
---
atom_expr [13802,13822]
atom_expr [13802,13822]
===
match
---
name: query [19814,19819]
name: query [19814,19819]
===
match
---
operator: , [4680,4681]
operator: , [4680,4681]
===
match
---
trailer [16767,16771]
trailer [16767,16771]
===
match
---
name: os [818,820]
name: os [818,820]
===
match
---
operator: , [19922,19923]
operator: , [19922,19923]
===
match
---
trailer [19189,19217]
trailer [19189,19217]
===
match
---
param [2805,2809]
param [2805,2809]
===
match
---
operator: } [13159,13160]
operator: } [13159,13160]
===
match
---
expr_stmt [4291,4356]
expr_stmt [4291,4356]
===
match
---
operator: = [13880,13881]
operator: = [13880,13881]
===
match
---
file_input [788,23336]
file_input [788,23516]
===
match
---
with_stmt [10554,11549]
with_stmt [10554,11549]
===
match
---
trailer [19185,19189]
trailer [19185,19189]
===
match
---
operator: = [5475,5476]
operator: = [5475,5476]
===
match
---
trailer [17993,17998]
trailer [17993,17998]
===
match
---
string: 'missing_file.txt' [7130,7148]
string: 'missing_file.txt' [7130,7148]
===
match
---
name: DagFileProcessorAgent [18428,18449]
name: DagFileProcessorAgent [18428,18449]
===
match
---
atom [20084,20115]
atom [20084,20115]
===
match
---
name: parent_pipe [16425,16436]
name: parent_pipe [16425,16436]
===
match
---
param [17542,17546]
param [17542,17546]
===
match
---
comparison [7310,7335]
comparison [7310,7335]
===
match
---
suite [21115,21287]
suite [21115,21287]
===
match
---
trailer [9572,9592]
trailer [9572,9592]
===
match
---
name: manager [15075,15082]
name: manager [15075,15082]
===
match
---
name: timedelta [19328,19337]
name: timedelta [19328,19337]
===
match
---
simple_stmt [20607,20756]
simple_stmt [20607,20756]
===
match
---
name: callbacks [2395,2404]
name: callbacks [2395,2404]
===
match
---
name: new_callable [14309,14321]
name: new_callable [14309,14321]
===
match
---
param [6560,6564]
param [6560,6564]
===
match
---
expr_stmt [16469,16496]
expr_stmt [16469,16496]
===
match
---
trailer [12319,12323]
trailer [12319,12323]
===
match
---
trailer [7658,7660]
trailer [7658,7660]
===
match
---
decorators [13329,13501]
decorators [13329,13501]
===
match
---
simple_stmt [16737,16792]
simple_stmt [16737,16792]
===
match
---
trailer [19859,19861]
trailer [19859,19861]
===
match
---
argument [7512,7522]
argument [7512,7522]
===
match
---
name: start_new_processes [5909,5928]
name: start_new_processes [5909,5928]
===
match
---
simple_stmt [20878,20910]
simple_stmt [20878,20910]
===
match
---
name: path [21562,21566]
name: path [21562,21566]
===
match
---
operator: , [1533,1534]
operator: , [1533,1534]
===
match
---
atom [14940,14942]
atom [14940,14942]
===
match
---
expr_stmt [21124,21155]
expr_stmt [21124,21155]
===
match
---
operator: { [18935,18936]
operator: { [18935,18936]
===
match
---
string: 'abc.txt' [15045,15054]
string: 'abc.txt' [15045,15054]
===
match
---
atom_expr [22333,22402]
atom_expr [22333,22402]
===
match
---
trailer [8833,8841]
trailer [8833,8841]
===
match
---
simple_stmt [14540,14877]
simple_stmt [14540,14877]
===
match
---
name: manager [7426,7433]
name: manager [7426,7433]
===
match
---
trailer [9338,9359]
trailer [9338,9359]
===
match
---
arglist [19190,19216]
arglist [19190,19216]
===
match
---
name: seconds [16255,16262]
name: seconds [16255,16262]
===
match
---
name: session [16744,16751]
name: session [16744,16751]
===
match
---
operator: = [3764,3765]
operator: = [3764,3765]
===
match
---
name: done [16558,16562]
name: done [16558,16562]
===
match
---
atom_expr [17181,17192]
atom_expr [17181,17192]
===
match
---
operator: = [7094,7095]
operator: = [7094,7095]
===
match
---
comparison [9561,9600]
comparison [9561,9600]
===
match
---
name: pickle_dags [5525,5536]
name: pickle_dags [5525,5536]
===
match
---
operator: = [6929,6930]
operator: = [6929,6930]
===
match
---
argument [6878,6893]
argument [6878,6893]
===
match
---
name: SHUTDOWN [8910,8918]
name: SHUTDOWN [8910,8918]
===
match
---
while_stmt [19496,19653]
while_stmt [19496,19653]
===
match
---
name: local_job [8944,8953]
name: local_job [8944,8953]
===
match
---
arglist [11753,11779]
arglist [11753,11779]
===
match
---
trailer [14965,14977]
trailer [14965,14977]
===
match
---
atom_expr [15075,15111]
atom_expr [15075,15111]
===
match
---
trailer [8637,8639]
trailer [8637,8639]
===
match
---
trailer [8664,8672]
trailer [8664,8672]
===
match
---
trailer [20994,21003]
trailer [20994,21003]
===
match
---
name: TEST_DAG_FOLDER [19101,19116]
name: TEST_DAG_FOLDER [19101,19116]
===
match
---
name: timedelta [879,888]
name: timedelta [879,888]
===
match
---
arglist [22552,22601]
arglist [22552,22601]
===
match
---
trailer [10611,10617]
trailer [10611,10617]
===
match
---
name: processor_timeout [16227,16244]
name: processor_timeout [16227,16244]
===
match
---
operator: , [19341,19342]
operator: , [19341,19342]
===
match
---
simple_stmt [821,832]
simple_stmt [821,832]
===
match
---
name: models [1195,1201]
name: models [1195,1201]
===
match
---
name: _processors [6361,6372]
name: _processors [6361,6372]
===
match
---
atom_expr [6252,6326]
atom_expr [6252,6326]
===
match
---
atom_expr [13304,13323]
atom_expr [13304,13323]
===
match
---
name: path [2019,2023]
name: path [2019,2023]
===
match
---
name: self [2716,2720]
name: self [2716,2720]
===
match
---
name: dag_id [15676,15682]
name: dag_id [15676,15682]
===
match
---
simple_stmt [15926,15953]
simple_stmt [15926,15953]
===
match
---
name: mock_processor [7802,7816]
name: mock_processor [7802,7816]
===
match
---
name: DagFileProcessorProcess [17448,17471]
name: DagFileProcessorProcess [17448,17471]
===
match
---
expr_stmt [7802,7899]
expr_stmt [7802,7899]
===
match
---
parameters [2921,2927]
parameters [2921,2927]
===
match
---
atom_expr [18705,18736]
atom_expr [18705,18736]
===
match
---
trailer [10926,10935]
trailer [10926,10935]
===
match
---
trailer [15950,15952]
trailer [15950,15952]
===
match
---
name: get_task [8752,8760]
name: get_task [8752,8760]
===
match
---
trailer [2028,2092]
trailer [2028,2092]
===
match
---
name: correct_maybe_zipped [21541,21561]
name: correct_maybe_zipped [21541,21561]
===
match
---
name: obj [3819,3822]
name: obj [3819,3822]
===
match
---
operator: @ [18924,18925]
operator: @ [18924,18925]
===
match
---
argument [7729,7744]
argument [7729,7744]
===
match
---
assert_stmt [8062,8119]
assert_stmt [8062,8119]
===
match
---
trailer [7117,7129]
trailer [7117,7129]
===
match
---
name: dagbag [8658,8664]
name: dagbag [8658,8664]
===
match
---
trailer [13321,13323]
trailer [13321,13323]
===
match
---
string: '/path/to/some/file.txt' [22367,22391]
string: '/path/to/some/file.txt' [22367,22391]
===
match
---
string: 'dags' [2085,2091]
string: 'dags' [2085,2091]
===
match
---
name: __init__ [2347,2355]
name: __init__ [2347,2355]
===
match
---
name: core [1794,1798]
name: core [1794,1798]
===
match
---
simple_stmt [18705,18737]
simple_stmt [18705,18737]
===
match
---
operator: ** [12004,12006]
operator: ** [12004,12006]
===
match
---
string: "dags_with_system_exit" [15783,15806]
string: "dags_with_system_exit" [15783,15806]
===
match
---
name: mock [22721,22725]
name: mock [22721,22725]
===
match
---
name: signal_conn [8373,8384]
name: signal_conn [8373,8384]
===
match
---
assert_stmt [12683,12715]
assert_stmt [12683,12715]
===
match
---
name: join [20223,20227]
name: join [20223,20227]
===
match
---
assert_stmt [9495,9541]
assert_stmt [9495,9541]
===
match
---
trailer [20933,20940]
trailer [20933,20940]
===
match
---
trailer [7071,7081]
trailer [7071,7081]
===
match
---
assert_stmt [12933,12987]
assert_stmt [12933,12987]
===
match
---
trailer [20377,20426]
trailer [20377,20426]
===
match
---
dotted_name [21011,21021]
dotted_name [21011,21021]
===
match
---
operator: , [22849,22850]
operator: , [22909,22910]
===
match
---
operator: = [16953,16954]
operator: = [16953,16954]
===
match
---
import_from [15615,15666]
import_from [15615,15666]
===
match
---
argument [16315,16332]
argument [16315,16332]
===
match
---
operator: = [22934,22935]
operator: = [23055,23056]
===
match
---
name: async_mode [19152,19162]
name: async_mode [19152,19162]
===
match
---
string: 'abc.txt' [7981,7990]
string: 'abc.txt' [7981,7990]
===
match
---
name: processor_agent [20764,20779]
name: processor_agent [20764,20779]
===
match
---
trailer [19404,19406]
trailer [19404,19406]
===
match
---
name: commit [11238,11244]
name: commit [11238,11244]
===
match
---
name: manager [14540,14547]
name: manager [14540,14547]
===
match
---
trailer [2052,2061]
trailer [2052,2061]
===
match
---
parameters [3482,3510]
parameters [3482,3510]
===
match
---
argument [5419,5450]
argument [5419,5450]
===
match
---
name: manager [6405,6412]
name: manager [6405,6412]
===
match
---
name: self [3320,3324]
name: self [3320,3324]
===
match
---
factor [12956,12958]
factor [12956,12958]
===
match
---
atom_expr [18239,18262]
atom_expr [18239,18262]
===
match
---
atom_expr [17220,17236]
atom_expr [17220,17236]
===
match
---
operator: = [19985,19986]
operator: = [19985,19986]
===
match
---
operator: = [10774,10775]
operator: = [10774,10775]
===
match
---
name: signal_conn [13836,13847]
name: signal_conn [13836,13847]
===
match
---
trailer [15029,15041]
trailer [15029,15041]
===
match
---
trailer [15915,15917]
trailer [15915,15917]
===
match
---
trailer [8751,8760]
trailer [8751,8760]
===
match
---
argument [13836,13859]
argument [13836,13859]
===
match
---
simple_stmt [16580,16586]
simple_stmt [16580,16586]
===
match
---
name: isinstance [3808,3818]
name: isinstance [3808,3818]
===
match
---
name: dags_folder [4434,4445]
name: dags_folder [4434,4445]
===
match
---
name: test_dag_path [11562,11575]
name: test_dag_path [11562,11575]
===
match
---
assert_stmt [20065,20154]
assert_stmt [20065,20154]
===
match
---
name: clear_db_dags [19047,19060]
name: clear_db_dags [19047,19060]
===
match
---
name: manager [6459,6466]
name: manager [6459,6466]
===
match
---
atom [12389,12391]
atom [12389,12391]
===
match
---
operator: , [2732,2733]
operator: , [2732,2733]
===
match
---
trailer [7281,7294]
trailer [7281,7294]
===
match
---
trailer [5840,5848]
trailer [5840,5848]
===
match
---
trailer [13315,13321]
trailer [13315,13321]
===
match
---
atom_expr [10921,10935]
atom_expr [10921,10935]
===
match
---
argument [13897,13914]
argument [13897,13914]
===
match
---
name: path [21423,21427]
name: path [21423,21427]
===
match
---
name: manager [16020,16027]
name: manager [16020,16027]
===
match
---
atom_expr [17801,17838]
atom_expr [17801,17838]
===
match
---
param [14484,14492]
param [14484,14492]
===
match
---
name: conf [1055,1059]
name: conf [1055,1059]
===
match
---
name: mock_pid [14503,14511]
name: mock_pid [14503,14511]
===
match
---
simple_stmt [20827,20869]
simple_stmt [20827,20869]
===
match
---
name: requests [9436,9444]
name: requests [9436,9444]
===
match
---
atom_expr [7782,7793]
atom_expr [7782,7793]
===
match
---
trailer [19461,19485]
trailer [19461,19485]
===
match
---
atom [19926,19962]
atom [19926,19962]
===
match
---
funcdef [2913,2949]
funcdef [2913,2949]
===
match
---
simple_stmt [14886,14948]
simple_stmt [14886,14948]
===
match
---
name: os [11578,11580]
name: os [11578,11580]
===
match
---
name: parent_pipe [12539,12550]
name: parent_pipe [12539,12550]
===
match
---
name: send [2630,2634]
name: send [2630,2634]
===
match
---
with_stmt [10379,13324]
with_stmt [10379,13324]
===
match
---
name: mode [22705,22709]
name: mode [22705,22709]
===
match
---
trailer [13757,13770]
trailer [13757,13770]
===
match
---
atom_expr [16425,16455]
atom_expr [16425,16455]
===
match
---
operator: == [21910,21912]
operator: == [21910,21912]
===
match
---
operator: = [7945,7946]
operator: = [7945,7946]
===
match
---
classdef [20957,22078]
classdef [20957,22078]
===
match
---
trailer [7317,7329]
trailer [7317,7329]
===
match
---
name: start [20780,20785]
name: start [20780,20785]
===
match
---
atom [4678,4680]
atom [4678,4680]
===
match
---
simple_stmt [11562,11641]
simple_stmt [11562,11641]
===
match
---
expr_stmt [11654,11702]
expr_stmt [11654,11702]
===
match
---
name: read_data [23017,23026]
name: read_data [23020,23029]
===
match
---
number: 0 [18482,18483]
number: 0 [18482,18483]
===
match
---
decorated [2899,2949]
decorated [2899,2949]
===
match
---
trailer [8760,8786]
trailer [8760,8786]
===
match
---
trailer [5485,5487]
trailer [5485,5487]
===
match
---
trailer [11590,11640]
trailer [11590,11640]
===
match
---
operator: == [9787,9789]
operator: == [9787,9789]
===
match
---
trailer [23310,23335]
trailer [23490,23515]
===
match
---
try_stmt [18218,18312]
try_stmt [18218,18312]
===
match
---
param [18997,19001]
param [18997,19001]
===
match
---
name: processor_factory [7536,7553]
name: processor_factory [7536,7553]
===
match
---
atom_expr [10754,10791]
atom_expr [10754,10791]
===
match
---
trailer [8355,8359]
trailer [8355,8359]
===
match
---
operator: = [14741,14742]
operator: = [14741,14742]
===
match
---
trailer [8025,8040]
trailer [8025,8040]
===
match
---
param [21090,21095]
param [21090,21095]
===
match
---
name: SETTINGS_FILE_VALID [17818,17837]
name: SETTINGS_FILE_VALID [17818,17837]
===
match
---
operator: , [18540,18541]
operator: , [18540,18541]
===
match
---
atom_expr [16936,16952]
atom_expr [16936,16952]
===
match
---
trailer [8076,8088]
trailer [8076,8088]
===
match
---
atom_expr [3378,3395]
atom_expr [3378,3395]
===
match
---
atom [18531,18533]
atom [18531,18533]
===
match
---
name: join [18730,18734]
name: join [18730,18734]
===
match
---
trailer [20718,20722]
trailer [20718,20722]
===
match
---
string: 'abc.txt' [7283,7292]
string: 'abc.txt' [7283,7292]
===
match
---
atom_expr [10991,11007]
atom_expr [10991,11007]
===
match
---
name: processor [14886,14895]
name: processor [14886,14895]
===
match
---
trailer [3723,3728]
trailer [3723,3728]
===
match
---
operator: , [20323,20324]
operator: , [20323,20324]
===
match
---
trailer [17998,18041]
trailer [17998,18041]
===
match
---
name: manager [5679,5686]
name: manager [5679,5686]
===
match
---
name: session [9034,9041]
name: session [9034,9041]
===
match
---
name: join [20903,20907]
name: join [20903,20907]
===
match
---
name: staticmethod [3020,3032]
name: staticmethod [3020,3032]
===
match
---
expr_stmt [21480,21518]
expr_stmt [21480,21518]
===
match
---
name: assert_called_once_with [6275,6298]
name: assert_called_once_with [6275,6298]
===
match
---
name: return_value [14512,14524]
name: return_value [14512,14524]
===
match
---
name: poll [16437,16441]
name: poll [16437,16441]
===
match
---
operator: = [11810,11811]
operator: = [11810,11811]
===
match
---
name: SerializedDagModel [1288,1306]
name: SerializedDagModel [1288,1306]
===
match
---
name: processor_agent [20878,20893]
name: processor_agent [20878,20893]
===
match
---
simple_stmt [9613,9685]
simple_stmt [9613,9685]
===
match
---
comparison [9704,9756]
comparison [9704,9756]
===
match
---
name: self [2867,2871]
name: self [2867,2871]
===
match
---
simple_stmt [6951,7049]
simple_stmt [6951,7049]
===
match
---
name: manager [8162,8169]
name: manager [8162,8169]
===
match
---
name: obj [3876,3879]
name: obj [3876,3879]
===
match
---
string: 'DAG_PROCESSOR_MANAGER_LOG_LOCATION' [20389,20425]
string: 'DAG_PROCESSOR_MANAGER_LOG_LOCATION' [20389,20425]
===
match
---
name: dagbag [10486,10492]
name: dagbag [10486,10492]
===
match
---
simple_stmt [12494,12552]
simple_stmt [12494,12552]
===
match
---
trailer [15143,15148]
trailer [15143,15148]
===
match
---
name: OSError [20491,20498]
name: OSError [20491,20498]
===
match
---
trailer [11005,11007]
trailer [11005,11007]
===
match
---
number: 1 [12918,12919]
number: 1 [12918,12919]
===
match
---
atom [18936,18961]
atom [18936,18961]
===
match
---
operator: , [5713,5714]
operator: , [5713,5714]
===
match
---
atom_expr [10308,10370]
atom_expr [10308,10370]
===
match
---
name: log_file_loc [20354,20366]
name: log_file_loc [20354,20366]
===
match
---
trailer [15166,15168]
trailer [15166,15168]
===
match
---
assert_stmt [21577,21602]
assert_stmt [21577,21602]
===
match
---
name: DagFileProcessorManager [1539,1562]
name: DagFileProcessorManager [1539,1562]
===
match
---
operator: = [4743,4744]
operator: = [4743,4744]
===
match
---
parameters [3297,3303]
parameters [3297,3303]
===
match
---
name: ti [10883,10885]
name: ti [10883,10885]
===
match
---
name: processor_timeout [14706,14723]
name: processor_timeout [14706,14723]
===
match
---
name: pardir [15775,15781]
name: pardir [15775,15781]
===
match
---
trailer [23206,23230]
trailer [23386,23410]
===
match
---
expr_stmt [21212,21251]
expr_stmt [21212,21251]
===
match
---
simple_stmt [1910,1997]
simple_stmt [1910,1997]
===
match
---
import_as_names [869,888]
import_as_names [869,888]
===
match
---
atom_expr [18428,18566]
atom_expr [18428,18566]
===
match
---
number: 0 [9799,9800]
number: 0 [9799,9800]
===
match
---
name: mock_processor [7908,7922]
name: mock_processor [7908,7922]
===
match
---
string: 'core' [19190,19196]
string: 'core' [19190,19196]
===
match
---
name: TEST_DAG_FOLDER [10321,10336]
name: TEST_DAG_FOLDER [10321,10336]
===
match
---
simple_stmt [7057,7101]
simple_stmt [7057,7101]
===
match
---
operator: , [7684,7685]
operator: , [7684,7685]
===
match
---
operator: , [12216,12217]
operator: , [12216,12217]
===
match
---
name: len [16654,16657]
name: len [16654,16657]
===
match
---
name: old_modules [16941,16952]
name: old_modules [16941,16952]
===
match
---
suite [12870,12920]
suite [12870,12920]
===
match
---
trailer [23281,23286]
trailer [23461,23466]
===
match
---
name: DagFileStat [1568,1579]
name: DagFileStat [1568,1579]
===
match
---
name: LJ [8627,8629]
name: LJ [8627,8629]
===
match
---
atom_expr [9331,9378]
atom_expr [9331,9378]
===
match
---
name: dagbag [10653,10659]
name: dagbag [10653,10659]
===
match
---
atom_expr [19755,19771]
atom_expr [19755,19771]
===
match
---
atom_expr [9850,9867]
atom_expr [9850,9867]
===
match
---
atom_expr [9971,9997]
atom_expr [9971,9997]
===
match
---
atom_expr [6951,6982]
atom_expr [6951,6982]
===
match
---
name: fake_processors [13020,13035]
name: fake_processors [13020,13035]
===
match
---
simple_stmt [3760,3785]
simple_stmt [3760,3785]
===
match
---
decorated [21292,21603]
decorated [21292,21603]
===
match
---
simple_stmt [3959,4045]
simple_stmt [3959,4045]
===
match
---
trailer [9882,9903]
trailer [9882,9903]
===
match
---
trailer [17471,17513]
trailer [17471,17513]
===
match
---
atom_expr [5265,5582]
atom_expr [5265,5582]
===
match
---
operator: = [11726,11727]
operator: = [11726,11727]
===
match
---
for_stmt [17170,17278]
for_stmt [17170,17278]
===
match
---
name: self [13545,13549]
name: self [13545,13549]
===
match
---
name: manager [9181,9188]
name: manager [9181,9188]
===
match
---
comp_op [16780,16786]
comp_op [16780,16786]
===
match
---
simple_stmt [955,1005]
simple_stmt [955,1005]
===
match
---
expr_stmt [21528,21567]
expr_stmt [21528,21567]
===
match
---
trailer [9076,9078]
trailer [9076,9078]
===
match
---
expr_stmt [22479,22527]
expr_stmt [22479,22527]
===
match
---
operator: = [7709,7710]
operator: = [7709,7710]
===
match
---
name: airflow [1701,1708]
name: airflow [1701,1708]
===
match
---
string: 'parsing_processes' [10409,10428]
string: 'parsing_processes' [10409,10428]
===
match
---
dotted_name [14240,14250]
dotted_name [14240,14250]
===
match
---
trailer [12827,12846]
trailer [12827,12846]
===
match
---
atom_expr [8886,8901]
atom_expr [8886,8901]
===
match
---
import_from [889,928]
import_from [889,928]
===
match
---
trailer [19036,19038]
trailer [19036,19038]
===
match
---
operator: , [7498,7499]
operator: , [7498,7499]
===
match
---
trailer [11191,11198]
trailer [11191,11198]
===
match
---
atom_expr [2415,2475]
atom_expr [2415,2475]
===
match
---
simple_stmt [10604,10631]
simple_stmt [10604,10631]
===
match
---
param [3483,3488]
param [3483,3488]
===
match
---
operator: , [22391,22392]
operator: , [22391,22392]
===
match
---
operator: , [21094,21095]
operator: , [21094,21095]
===
match
---
arglist [5302,5572]
arglist [5302,5572]
===
match
---
argument [22232,22248]
argument [22232,22248]
===
match
---
simple_stmt [2675,2708]
simple_stmt [2675,2708]
===
match
---
dictorsetmaker [15045,15065]
dictorsetmaker [15045,15065]
===
match
---
simple_stmt [832,848]
simple_stmt [832,848]
===
match
---
dotted_name [1470,1498]
dotted_name [1470,1498]
===
match
---
operator: = [5628,5629]
operator: = [5628,5629]
===
match
---
string: 'deep/path/to/file.txt' [23311,23334]
string: 'deep/path/to/file.txt' [23491,23514]
===
match
---
name: timedelta [18516,18525]
name: timedelta [18516,18525]
===
match
---
name: ti [10809,10811]
name: ti [10809,10811]
===
match
---
trailer [11996,12013]
trailer [11996,12013]
===
match
---
name: pickle_dags [6847,6858]
name: pickle_dags [6847,6858]
===
match
---
operator: , [20115,20116]
operator: , [20115,20116]
===
match
---
atom_expr [11446,11468]
atom_expr [11446,11468]
===
match
---
trailer [4402,4769]
trailer [4402,4769]
===
match
---
atom_expr [14550,14876]
atom_expr [14550,14876]
===
match
---
name: RUNNING [8834,8841]
name: RUNNING [8834,8841]
===
match
---
name: append [17266,17272]
name: append [17266,17272]
===
match
---
param [13562,13570]
param [13562,13570]
===
match
---
name: clear_db_dags [15902,15915]
name: clear_db_dags [15902,15915]
===
match
---
simple_stmt [1119,1182]
simple_stmt [1119,1182]
===
match
---
name: dag_ids [2456,2463]
name: dag_ids [2456,2463]
===
match
---
name: dag_ids [3091,3098]
name: dag_ids [3091,3098]
===
match
---
trailer [3576,3609]
trailer [3576,3609]
===
match
---
atom [21923,21937]
atom [21923,21937]
===
match
---
name: DagFileProcessorManager [4379,4402]
name: DagFileProcessorManager [4379,4402]
===
match
---
simple_stmt [19662,19705]
simple_stmt [19662,19705]
===
match
---
operator: , [5571,5572]
operator: , [5571,5572]
===
match
---
name: MagicMock [6703,6712]
name: MagicMock [6703,6712]
===
match
---
operator: , [5721,5722]
operator: , [5721,5722]
===
match
---
operator: = [12420,12421]
operator: = [12420,12421]
===
match
---
name: test_dag_path [17970,17983]
name: test_dag_path [17970,17983]
===
match
---
simple_stmt [6914,6943]
simple_stmt [6914,6943]
===
match
---
atom_expr [16658,16675]
atom_expr [16658,16675]
===
match
---
string: "zipfile.is_zipfile" [21022,21042]
string: "zipfile.is_zipfile" [21022,21042]
===
match
---
string: "data" [23027,23033]
string: "data" [23030,23036]
===
match
---
trailer [11752,11780]
trailer [11752,11780]
===
match
---
param [22851,22868]
param [22911,22928]
===
match
---
string: "Message" [11498,11507]
string: "Message" [11498,11507]
===
match
---
operator: , [2083,2084]
operator: , [2083,2084]
===
match
---
decorator [17349,17363]
decorator [17349,17363]
===
match
---
operator: , [1676,1677]
operator: , [1676,1677]
===
match
---
simple_stmt [1060,1119]
simple_stmt [1060,1119]
===
match
---
trailer [16751,16757]
trailer [16751,16757]
===
match
---
name: mode [23255,23259]
name: mode [23435,23439]
===
match
---
not_test [19418,19432]
not_test [19418,19432]
===
match
---
name: recv [16490,16494]
name: recv [16490,16494]
===
match
---
name: instance [22925,22933]
name: instance [23046,23054]
===
match
---
name: dag_folder [21584,21594]
name: dag_folder [21584,21594]
===
match
---
name: multiprocessing [795,810]
name: multiprocessing [795,810]
===
match
---
trailer [15727,15732]
trailer [15727,15732]
===
match
---
name: async_mode [19547,19557]
name: async_mode [19547,19557]
===
match
---
trailer [2679,2696]
trailer [2679,2696]
===
match
---
name: manager [8018,8025]
name: manager [8018,8025]
===
match
---
simple_stmt [19072,19144]
simple_stmt [19072,19144]
===
match
---
trailer [6999,7048]
trailer [6999,7048]
===
match
---
name: tests [1869,1874]
name: tests [1869,1874]
===
match
---
string: 'missing_file.txt' [7195,7213]
string: 'missing_file.txt' [7195,7213]
===
match
---
operator: { [14122,14123]
operator: { [14122,14123]
===
match
---
name: max_runs [8248,8256]
name: max_runs [8248,8256]
===
match
---
import_name [811,820]
import_name [811,820]
===
match
---
operator: == [16677,16679]
operator: == [16677,16679]
===
match
---
trailer [9949,9956]
trailer [9949,9956]
===
match
---
operator: , [7744,7745]
operator: , [7744,7745]
===
match
---
simple_stmt [16936,16973]
simple_stmt [16936,16973]
===
match
---
trailer [23134,23158]
trailer [23314,23338]
===
match
---
trailer [20222,20227]
trailer [20222,20227]
===
match
---
trailer [9134,9141]
trailer [9134,9141]
===
match
---
operator: = [10752,10753]
operator: = [10752,10753]
===
match
---
name: dagbag [8501,8507]
name: dagbag [8501,8507]
===
match
---
atom [14022,14024]
atom [14022,14024]
===
match
---
funcdef [16850,16973]
funcdef [16850,16973]
===
match
---
simple_stmt [1696,1745]
simple_stmt [1696,1745]
===
match
---
operator: = [6888,6889]
operator: = [6888,6889]
===
match
---
dotted_name [1187,1201]
dotted_name [1187,1201]
===
match
---
trailer [6412,6424]
trailer [6412,6424]
===
match
---
trailer [19684,19704]
trailer [19684,19704]
===
match
---
expr_stmt [7961,8008]
expr_stmt [7961,8008]
===
match
---
name: create_session [8572,8586]
name: create_session [8572,8586]
===
match
---
name: DagModel [19820,19828]
name: DagModel [19820,19828]
===
match
---
operator: = [5233,5234]
operator: = [5233,5234]
===
match
---
operator: , [2360,2361]
operator: , [2360,2361]
===
match
---
name: sync_to_db [10718,10728]
name: sync_to_db [10718,10728]
===
match
---
name: jobs [1073,1077]
name: jobs [1073,1077]
===
match
---
operator: = [21195,21196]
operator: = [21195,21196]
===
match
---
name: conf [18147,18151]
name: conf [18147,18151]
===
match
---
name: local_task_job [1078,1092]
name: local_task_job [1078,1092]
===
match
---
atom_expr [19506,19526]
atom_expr [19506,19526]
===
match
---
name: open [22982,22986]
name: open [23103,23107]
===
match
---
name: full_filepath [9448,9461]
name: full_filepath [9448,9461]
===
match
---
suite [3511,4045]
suite [3511,4045]
===
match
---
name: path [19091,19095]
name: path [19091,19095]
===
match
---
atom_expr [7802,7833]
atom_expr [7802,7833]
===
match
---
operator: , [4652,4653]
operator: , [4652,4653]
===
match
---
funcdef [4947,6484]
funcdef [4947,6484]
===
match
---
trailer [9513,9517]
trailer [9513,9517]
===
match
---
atom [6312,6314]
atom [6312,6314]
===
match
---
simple_stmt [9932,9959]
simple_stmt [9932,9959]
===
match
---
dotted_name [1251,1280]
dotted_name [1251,1280]
===
match
---
operator: , [16361,16362]
operator: , [16361,16362]
===
match
---
testlist_comp [18937,18960]
testlist_comp [18937,18960]
===
match
---
expr_stmt [10486,10541]
expr_stmt [10486,10541]
===
match
---
simple_stmt [15615,15667]
simple_stmt [15615,15667]
===
match
---
assert_stmt [6388,6431]
assert_stmt [6388,6431]
===
match
---
string: '/path/to/archive.zip/deep/path/to/file.txt' [23062,23106]
string: '/path/to/archive.zip/deep/path/to/file.txt' [23168,23212]
===
match
---
simple_stmt [21164,21203]
simple_stmt [21164,21203]
===
match
---
operator: , [5511,5512]
operator: , [5511,5512]
===
match
---
argument [12004,12012]
argument [12004,12012]
===
match
---
name: os [2029,2031]
name: os [2029,2031]
===
match
---
atom_expr [8712,8728]
atom_expr [8712,8728]
===
match
---
dotted_name [1371,1384]
dotted_name [1371,1384]
===
match
---
simple_stmt [19047,19063]
simple_stmt [19047,19063]
===
match
---
atom_expr [3712,3742]
atom_expr [3712,3742]
===
match
---
argument [14850,14865]
argument [14850,14865]
===
match
---
import_name [832,847]
import_name [832,847]
===
match
---
name: max_runs [5341,5349]
name: max_runs [5341,5349]
===
match
---
name: manager [6353,6360]
name: manager [6353,6360]
===
match
---
trailer [2598,2612]
trailer [2598,2612]
===
match
---
operator: = [21809,21810]
operator: = [21809,21810]
===
match
---
name: side_effect [7082,7093]
name: side_effect [7082,7093]
===
match
---
name: dag_ids [19977,19984]
name: dag_ids [19977,19984]
===
match
---
argument [7536,7578]
argument [7536,7578]
===
match
---
argument [6661,6671]
argument [6661,6671]
===
match
---
atom_expr [9403,9416]
atom_expr [9403,9416]
===
match
---
name: RuntimeError [3965,3977]
name: RuntimeError [3965,3977]
===
match
---
string: 'sqlite' [11728,11736]
string: 'sqlite' [11728,11736]
===
match
---
name: simple_task_instance [9802,9822]
name: simple_task_instance [9802,9822]
===
match
---
name: path [21246,21250]
name: path [21246,21250]
===
match
---
trailer [12955,12959]
trailer [12955,12959]
===
match
---
suite [3418,3443]
suite [3418,3443]
===
match
---
name: self [2979,2983]
name: self [2979,2983]
===
match
---
comparison [21881,21914]
comparison [21881,21914]
===
match
---
operator: = [8768,8769]
operator: = [8768,8769]
===
match
---
name: DagParsingStat [16531,16545]
name: DagParsingStat [16531,16545]
===
match
---
operator: = [16080,16081]
operator: = [16080,16081]
===
match
---
name: local_job [11201,11210]
name: local_job [11201,11210]
===
match
---
argument [12206,12216]
argument [12206,12216]
===
match
---
trailer [18734,18736]
trailer [18734,18736]
===
match
---
operator: = [7215,7216]
operator: = [7215,7216]
===
match
---
operator: = [21723,21724]
operator: = [21723,21724]
===
match
---
atom_expr [19625,19652]
atom_expr [19625,19652]
===
match
---
name: test_launch_process [20164,20183]
name: test_launch_process [20164,20183]
===
match
---
trailer [10659,10667]
trailer [10659,10667]
===
insert-tree
---
decorator [22793,22825]
    operator: @ [22793,22794]
    dotted_name [22794,22804]
        name: mock [22794,22798]
        name: patch [22799,22804]
    string: "io.TextIOWrapper" [22805,22823]
to
decorators [22720,22789]
at 2
===
insert-tree
---
param [22870,22893]
    name: mocked_text_io_wrapper [22870,22892]
    operator: , [22892,22893]
to
parameters [22827,22869]
at 1
===
insert-node
---
simple_stmt [23094,23141]
to
suite [22870,23336]
at 2
===
insert-tree
---
simple_stmt [23223,23289]
    atom_expr [23223,23288]
        name: mocked_text_io_wrapper [23223,23245]
        trailer [23245,23269]
            name: assert_called_once_with [23246,23269]
        trailer [23269,23288]
            name: open_return_value [23270,23287]
to
suite [22870,23336]
at 5
===
insert-node
---
expr_stmt [23094,23140]
to
simple_stmt [23094,23141]
at 0
===
insert-node
---
name: open_return_value [22985,23002]
to
expr_stmt [22973,23034]
at 0
===
move-tree
---
atom_expr [22973,22999]
    name: instance [22973,22981]
    trailer [22981,22986]
        name: open [22982,22986]
    trailer [22986,22999]
        name: return_value [22987,22999]
to
expr_stmt [23094,23140]
at 0
