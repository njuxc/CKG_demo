===
match
---
atom [5860,5871]
atom [5888,5899]
===
match
---
operator: , [6180,6181]
operator: , [6208,6209]
===
match
---
arglist [6398,6446]
arglist [6426,6474]
===
match
---
name: mode [1437,1441]
name: mode [1447,1451]
===
match
---
name: lines_no_comments [3718,3735]
name: lines_no_comments [3746,3763]
===
match
---
string: b'airflow' [8093,8103]
string: b'airflow' [8121,8131]
===
match
---
atom_expr [4622,4640]
atom_expr [4650,4668]
===
match
---
param [2984,3005]
param [3012,3033]
===
match
---
trailer [3429,3434]
trailer [3457,3462]
===
match
---
name: ignore_file_name [4320,4336]
name: ignore_file_name [4348,4364]
===
match
---
trailer [5819,5826]
trailer [5847,5854]
===
match
---
operator: , [912,913]
operator: , [922,923]
===
match
---
simple_stmt [4375,4421]
simple_stmt [4403,4449]
===
match
---
and_test [2320,2359]
and_test [2330,2369]
===
match
---
name: open [2868,2872]
name: open [2895,2899]
===
match
---
arglist [6961,6981]
arglist [6989,7009]
===
match
---
trailer [5696,5721]
trailer [5724,5749]
===
match
---
return_stmt [7729,7740]
return_stmt [7757,7768]
===
match
---
name: path [1867,1871]
name: path [1877,1881]
===
match
---
testlist_comp [8085,8103]
testlist_comp [8113,8131]
===
match
---
trailer [4879,4915]
trailer [4907,4943]
===
match
---
suite [1443,2000]
suite [1453,2010]
===
match
---
trailer [4187,4194]
trailer [4215,4222]
===
match
---
trailer [6150,6195]
trailer [6178,6223]
===
match
---
expr_stmt [7991,8016]
expr_stmt [8019,8044]
===
match
---
operator: , [3755,3756]
operator: , [3783,3784]
===
match
---
trailer [6639,6668]
trailer [6667,6696]
===
match
---
trailer [5826,5837]
trailer [5854,5865]
===
match
---
comparison [4312,4336]
comparison [4340,4364]
===
match
---
trailer [2795,2806]
trailer [2805,2816]
===
match
---
testlist_star_expr [2262,2275]
testlist_star_expr [2272,2285]
===
match
---
atom_expr [2332,2359]
atom_expr [2342,2369]
===
match
---
suite [7113,7179]
suite [7141,7207]
===
match
---
name: kwargs [1031,1037]
name: kwargs [1041,1047]
===
match
---
name: str [2979,2982]
name: str [3007,3010]
===
match
---
atom_expr [6114,6196]
atom_expr [6142,6224]
===
match
---
name: lines_no_comments [3862,3879]
name: lines_no_comments [3890,3907]
===
match
---
for_stmt [4262,4641]
for_stmt [4290,4669]
===
match
---
name: path [1431,1435]
name: path [1441,1445]
===
match
---
simple_stmt [2262,2313]
simple_stmt [2272,2323]
===
match
---
name: smart_sensor_dags [6254,6271]
name: smart_sensor_dags [6282,6299]
===
match
---
simple_stmt [7327,7699]
simple_stmt [7355,7727]
===
match
---
name: directory [4671,4680]
name: directory [4699,4708]
===
match
---
simple_stmt [3345,3397]
simple_stmt [3373,3425]
===
match
---
atom_expr [7771,7795]
atom_expr [7799,7823]
===
match
---
parameters [4665,4918]
parameters [4693,4946]
===
match
---
return_stmt [6453,6470]
return_stmt [6481,6498]
===
match
---
name: safe_mode [7261,7270]
name: safe_mode [7289,7298]
===
match
---
with_item [7944,7977]
with_item [7972,8005]
===
match
---
operator: = [8029,8030]
operator: = [8057,8058]
===
match
---
trailer [3438,3453]
trailer [3466,3481]
===
match
---
name: warn [1240,1244]
name: warn [1250,1254]
===
match
---
name: file [4312,4316]
name: file [4340,4344]
===
match
---
param [4780,4820]
param [4808,4848]
===
match
---
simple_stmt [1176,1226]
simple_stmt [1186,1236]
===
match
---
argument [4047,4138]
argument [4075,4166]
===
match
---
name: archive [2351,2358]
name: archive [2361,2368]
===
match
---
name: re [3833,3835]
name: re [3861,3863]
===
match
---
testlist_star_expr [2711,2731]
testlist_star_expr [2721,2741]
===
match
---
name: bool [6542,6546]
name: bool [6570,6574]
===
match
---
trailer [3835,3843]
trailer [3863,3871]
===
match
---
operator: = [2732,2733]
operator: = [2742,2743]
===
match
---
atom_expr [7944,7965]
atom_expr [7972,7993]
===
match
---
trailer [2287,2294]
trailer [2297,2304]
===
match
---
trailer [2867,2872]
trailer [2894,2899]
===
match
---
with_stmt [7939,8017]
with_stmt [7967,8045]
===
match
---
operator: , [2263,2264]
operator: , [2273,2274]
===
match
---
parameters [1021,1038]
parameters [1031,1048]
===
match
---
name: Optional [4798,4806]
name: Optional [4826,4834]
===
match
---
simple_stmt [4616,4641]
simple_stmt [4644,4669]
===
match
---
name: s [8062,8063]
name: s [8090,8091]
===
match
---
expr_stmt [3820,3888]
expr_stmt [3848,3916]
===
match
---
name: content [7991,7998]
name: content [8019,8026]
===
match
---
suite [4296,4641]
suite [4324,4669]
===
match
---
if_stmt [4528,4604]
if_stmt [4556,4632]
===
match
---
trailer [2066,2070]
trailer [2076,2080]
===
match
---
operator: , [4089,4090]
operator: , [4117,4118]
===
match
---
param [2450,2458]
param [2460,2468]
===
match
---
name: patterns [3905,3913]
name: patterns [3933,3941]
===
match
---
simple_stmt [6002,6035]
simple_stmt [6030,6063]
===
match
---
operator: = [2454,2455]
operator: = [2464,2465]
===
match
---
atom_expr [4864,4915]
atom_expr [4892,4943]
===
match
---
arglist [5697,5720]
arglist [5725,5748]
===
match
---
operator: = [7833,7834]
operator: = [7861,7862]
===
match
---
trailer [4543,4558]
trailer [4571,4586]
===
match
---
argument [4535,4576]
argument [4563,4604]
===
match
---
name: path [4199,4203]
name: path [4227,4231]
===
match
---
operator: , [2920,2921]
operator: , [2948,2949]
===
match
---
atom_expr [2014,2073]
atom_expr [2024,2083]
===
match
---
trailer [2016,2024]
trailer [2026,2034]
===
match
---
atom_expr [1231,1382]
atom_expr [1241,1392]
===
match
---
simple_stmt [923,962]
simple_stmt [933,972]
===
match
---
trailer [1244,1382]
trailer [1254,1392]
===
match
---
atom_expr [6379,6447]
atom_expr [6407,6475]
===
match
---
simple_stmt [7126,7179]
simple_stmt [7154,7207]
===
match
---
name: str [3367,3370]
name: str [3395,3398]
===
match
---
trailer [2839,2847]
trailer [2866,2874]
===
match
---
atom_expr [7297,7312]
atom_expr [7325,7340]
===
match
---
name: patterns_by_dir [3513,3528]
name: patterns_by_dir [3541,3556]
===
match
---
atom_expr [3739,3766]
atom_expr [3767,3794]
===
match
---
name: rel_file_path [4433,4446]
name: rel_file_path [4461,4474]
===
match
---
param [2441,2449]
param [2451,2459]
===
match
---
if_stmt [6201,6449]
if_stmt [6229,6477]
===
match
---
name: file_paths [6460,6470]
name: file_paths [6488,6498]
===
match
---
trailer [4461,4515]
trailer [4489,4543]
===
match
---
number: 1 [6823,6824]
number: 1 [6851,6852]
===
match
---
arglist [4462,4514]
arglist [4490,4542]
===
match
---
name: os [3571,3573]
name: os [3599,3601]
===
match
---
operator: , [3588,3589]
operator: , [3616,3617]
===
match
---
name: current_file [7835,7847]
name: current_file [7863,7875]
===
match
---
import_from [923,961]
import_from [933,971]
===
match
---
name: example_dag_folder [6151,6169]
name: example_dag_folder [6179,6197]
===
match
---
atom_expr [7022,7050]
atom_expr [7050,7078]
===
match
---
operator: , [7259,7260]
operator: , [7287,7288]
===
match
---
name: patterns [3925,3933]
name: patterns [3953,3961]
===
match
---
trailer [2872,2882]
trailer [2899,2909]
===
match
---
name: kwargs [1410,1416]
name: kwargs [1420,1426]
===
match
---
arglist [1810,1932]
arglist [1820,1942]
===
match
---
operator: = [6063,6064]
operator: = [6091,6092]
===
match
---
operator: = [7314,7315]
operator: = [7342,7343]
===
match
---
simple_stmt [2901,2933]
simple_stmt [2929,2961]
===
match
---
name: file_ext [6842,6850]
name: file_ext [6870,6878]
===
match
---
name: warnings [1787,1795]
name: warnings [1797,1805]
===
match
---
operator: , [2721,2722]
operator: , [2731,2732]
===
match
---
name: path [5815,5819]
name: path [5843,5847]
===
match
---
if_stmt [7703,7741]
if_stmt [7731,7769]
===
match
---
if_stmt [7745,8017]
if_stmt [7773,8045]
===
match
---
trailer [6810,6821]
trailer [6838,6849]
===
match
---
trailer [4203,4208]
trailer [4231,4236]
===
match
---
simple_stmt [2825,2883]
simple_stmt [2835,2911]
===
match
---
name: str [4682,4685]
name: str [4710,4713]
===
match
---
name: List [3492,3496]
name: List [3520,3524]
===
match
---
funcdef [2935,4641]
funcdef [2963,4669]
===
match
---
annassign [3490,3542]
annassign [3518,3570]
===
match
---
tfpdef [2964,2982]
tfpdef [2992,3010]
===
match
---
operator: , [4213,4214]
operator: , [4241,4242]
===
match
---
simple_stmt [4595,4604]
simple_stmt [4623,4632]
===
match
---
operator: , [1435,1436]
operator: , [1445,1446]
===
match
---
simple_stmt [787,802]
simple_stmt [797,812]
===
match
---
name: file_path [7895,7904]
name: file_path [7923,7932]
===
match
---
name: re [7199,7201]
name: re [7227,7229]
===
match
---
suite [5838,5872]
suite [5866,5900]
===
match
---
name: splitext [6788,6796]
name: splitext [6816,6824]
===
match
---
trailer [4477,4503]
trailer [4505,4531]
===
match
---
operator: , [5956,5957]
operator: , [5984,5985]
===
match
---
name: conf [5681,5685]
name: conf [5709,5713]
===
match
---
simple_stmt [6114,6197]
simple_stmt [6142,6225]
===
match
---
operator: , [8091,8092]
operator: , [8119,8120]
===
match
---
atom_expr [4535,4558]
atom_expr [4563,4586]
===
match
---
string: """This function is deprecated. Please use `tempfile.TemporaryDirectory`""" [1076,1151]
string: """This function is deprecated. Please use `tempfile.TemporaryDirectory`""" [1086,1161]
===
match
---
trailer [3949,3952]
trailer [3977,3980]
===
match
---
simple_stmt [2115,2258]
simple_stmt [2125,2268]
===
match
---
param [4825,4916]
param [4853,4944]
===
match
---
name: might_contain_dag [6943,6960]
name: might_contain_dag [6971,6988]
===
match
---
operator: += [3829,3831]
operator: += [3857,3859]
===
match
---
name: path [1948,1952]
name: path [1958,1962]
===
match
---
name: os [6797,6799]
name: os [6825,6827]
===
match
---
arglist [3533,3541]
arglist [3561,3569]
===
match
---
name: TmpDir [1219,1225]
name: TmpDir [1229,1235]
===
match
---
name: directory [5861,5870]
name: directory [5889,5898]
===
match
---
simple_stmt [3552,3608]
simple_stmt [3580,3636]
===
match
---
trailer [3583,3607]
trailer [3611,3635]
===
match
---
trailer [4398,4403]
trailer [4426,4431]
===
match
---
simple_stmt [6915,6924]
simple_stmt [6943,6952]
===
match
---
trailer [3924,3934]
trailer [3952,3962]
===
match
---
name: dag_file [7969,7977]
name: dag_file [7997,8005]
===
match
---
trailer [6333,6336]
trailer [6361,6364]
===
match
---
simple_stmt [4924,5621]
simple_stmt [4952,5649]
===
match
---
trailer [3376,3390]
trailer [3404,3418]
===
match
---
operator: { [4195,4196]
operator: { [4223,4224]
===
match
---
trailer [3578,3583]
trailer [3606,3611]
===
match
---
try_stmt [6678,7179]
try_stmt [6706,7207]
===
match
---
atom_expr [6943,6982]
atom_expr [6971,7010]
===
match
---
operator: , [3370,3371]
operator: , [3398,3399]
===
match
---
suite [7906,7931]
suite [7934,7959]
===
match
---
trailer [2046,2053]
trailer [2056,2063]
===
match
---
atom_expr [6797,6825]
atom_expr [6825,6853]
===
match
---
name: logging [794,801]
name: logging [804,811]
===
match
---
trailer [4071,4076]
trailer [4099,4104]
===
match
---
name: Optional [4847,4855]
name: Optional [4875,4883]
===
match
---
operator: = [5798,5799]
operator: = [5826,5827]
===
match
---
trailer [2750,2759]
trailer [2760,2769]
===
match
---
string: r'((.*\.zip){})?(.*)' [2025,2046]
string: r'((.*\.zip){})?(.*)' [2035,2056]
===
match
---
comp_if [3880,3887]
comp_if [3908,3915]
===
match
---
arglist [4069,4118]
arglist [4097,4146]
===
match
---
fstring_expr [1866,1872]
fstring_expr [1876,1882]
===
match
---
subscriptlist [3367,3390]
subscriptlist [3395,3418]
===
match
---
funcdef [999,1418]
funcdef [1009,1428]
===
match
---
name: os [3427,3429]
name: os [3455,3457]
===
match
---
name: dag_file [8001,8009]
name: dag_file [8029,8037]
===
match
---
arglist [1401,1416]
arglist [1411,1426]
===
match
---
import_from [862,921]
import_from [872,931]
===
match
---
name: sep [2067,2070]
name: sep [2077,2080]
===
match
---
name: is_zipfile [7884,7894]
name: is_zipfile [7912,7922]
===
match
---
name: archive [2714,2721]
name: archive [2724,2731]
===
match
---
name: Exception [7066,7075]
name: Exception [7094,7103]
===
match
---
name: join [4399,4403]
name: join [4427,4431]
===
match
---
suite [4578,4604]
suite [4606,4632]
===
match
---
name: bool [7272,7276]
name: bool [7300,7304]
===
match
---
name: ZIP_REGEX [2002,2011]
name: ZIP_REGEX [2012,2021]
===
match
---
name: dirs [4002,4006]
name: dirs [4030,4034]
===
match
---
simple_stmt [4433,4516]
simple_stmt [4461,4544]
===
match
---
trailer [3790,3796]
trailer [3818,3824]
===
match
---
name: line [3883,3887]
name: line [3911,3915]
===
match
---
name: extend [6125,6131]
name: extend [6153,6159]
===
match
---
name: find_dag_file_paths [5915,5934]
name: find_dag_file_paths [5943,5962]
===
match
---
name: copy [4229,4233]
name: copy [4257,4261]
===
match
---
fstring_string: ).mkdir` [1872,1880]
fstring_string: ).mkdir` [1882,1890]
===
match
---
operator: , [6432,6433]
operator: , [6460,6461]
===
match
---
operator: , [902,903]
operator: , [912,913]
===
match
---
name: safe_mode [5958,5967]
name: safe_mode [5986,5995]
===
match
---
simple_stmt [1156,1172]
simple_stmt [1166,1182]
===
match
---
trailer [8009,8014]
trailer [8037,8042]
===
match
---
arglist [4880,4914]
arglist [4908,4942]
===
match
---
trailer [3532,3542]
trailer [3560,3570]
===
match
---
atom_expr [6702,6727]
atom_expr [6730,6755]
===
match
---
trailer [6875,6886]
trailer [6903,6914]
===
match
---
operator: = [4389,4390]
operator: = [4417,4418]
===
match
---
testlist_comp [3833,3887]
testlist_comp [3861,3915]
===
match
---
trailer [2350,2359]
trailer [2360,2369]
===
match
---
name: bool [4856,4860]
name: bool [4884,4888]
===
match
---
if_stmt [5973,6197]
if_stmt [6001,6225]
===
match
---
simple_stmt [8021,8047]
simple_stmt [8049,8075]
===
match
---
atom_expr [2054,2071]
atom_expr [2064,2081]
===
match
---
name: ignore_file_path [3552,3568]
name: ignore_file_path [3580,3596]
===
match
---
string: "" [3757,3759]
string: "" [3785,3787]
===
match
---
for_stmt [6598,7179]
for_stmt [6626,7207]
===
match
---
trailer [6077,6086]
trailer [6105,6114]
===
match
---
simple_stmt [3820,3889]
simple_stmt [3848,3917]
===
match
---
name: file_path [7949,7958]
name: file_path [7977,7986]
===
match
---
name: os [4391,4393]
name: os [4419,4421]
===
match
---
name: root [4404,4408]
name: root [4432,4436]
===
match
---
trailer [3504,3509]
trailer [3532,3537]
===
match
---
number: 2 [1374,1375]
number: 2 [1384,1385]
===
match
---
operator: = [1993,1994]
operator: = [2003,2004]
===
match
---
suite [6682,7051]
suite [6710,7079]
===
match
---
string: """     Creates the directory specified by path, creating intermediate directories     as necessary. If directory already exists, this is a no-op.      :param path: The directory to create     :type path: str     :param mode: The mode to give to the directory e.g. 0o755, ignores umask     :type mode: int     """ [1448,1761]
string: """     Creates the directory specified by path, creating intermediate directories     as necessary. If directory already exists, this is a no-op.      :param path: The directory to create     :type path: str     :param mode: The mode to give to the directory e.g. 0o755, ignores umask     :type mode: int     """ [1458,1771]
===
match
---
name: example_dags [6065,6077]
name: example_dags [6093,6105]
===
match
---
operator: = [4707,4708]
operator: = [4735,4736]
===
match
---
operator: = [3736,3737]
operator: = [3764,3765]
===
match
---
trailer [4464,4469]
trailer [4492,4497]
===
match
---
operator: , [6970,6971]
operator: , [6998,6999]
===
match
---
name: isdir [5889,5894]
name: isdir [5917,5922]
===
match
---
name: mode [1965,1969]
name: mode [1975,1979]
===
match
---
name: content [7825,7832]
name: content [7853,7860]
===
match
---
atom_expr [3497,3509]
atom_expr [3525,3537]
===
match
---
name: ZipFile [2840,2847]
name: ZipFile [2867,2874]
===
match
---
operator: = [3511,3512]
operator: = [3539,3540]
===
match
---
operator: , [885,886]
operator: , [895,896]
===
match
---
name: rel_file_path [4544,4557]
name: rel_file_path [4572,4585]
===
match
---
operator: , [4731,4732]
operator: , [4759,4760]
===
match
---
atom [5750,5752]
atom [5778,5780]
===
match
---
atom [3539,3541]
atom [3567,3569]
===
match
---
name: patterns [4220,4228]
name: patterns [4248,4256]
===
match
---
operator: ** [1408,1410]
operator: ** [1418,1420]
===
match
---
name: COMMENT_PATTERN [7181,7196]
name: COMMENT_PATTERN [7209,7224]
===
match
---
name: directory [6497,6506]
name: directory [6525,6534]
===
match
---
for_stmt [3402,4641]
for_stmt [3430,4669]
===
match
---
annassign [3360,3396]
annassign [3388,3424]
===
match
---
name: getboolean [5686,5696]
name: getboolean [5714,5724]
===
match
---
simple_stmt [5662,5722]
simple_stmt [5690,5750]
===
match
---
trailer [3783,3788]
trailer [3811,3816]
===
match
---
trailer [4029,4152]
trailer [4057,4180]
===
match
---
simple_stmt [2402,2417]
simple_stmt [2412,2427]
===
match
---
name: s [8079,8080]
name: s [8107,8108]
===
match
---
name: content [8021,8028]
name: content [8049,8056]
===
match
---
name: file [4509,4513]
name: file [4537,4541]
===
match
---
fstring_start: f" [1810,1812]
fstring_start: f" [1820,1822]
===
match
---
operator: = [7197,7198]
operator: = [7225,7226]
===
match
---
operator: -> [3007,3009]
operator: -> [3035,3037]
===
match
---
simple_stmt [6281,6353]
simple_stmt [6309,6381]
===
match
---
name: file_path [6811,6820]
name: file_path [6839,6848]
===
match
---
string: """     Opens the given file. If the path contains a folder with a .zip suffix, then     the folder is treated as a zip archive, opening the file inside the archive.      :return: a file object, as in `open`, or as in `ZipFile.open`.     """ [2465,2706]
string: """     Opens the given file. If the path contains a folder with a .zip suffix, then     the folder is treated as a zip archive, opening the file inside the archive.      :return: a file object, as in `open`, or as in `ZipFile.open`.     """ [2475,2716]
===
match
---
operator: , [3410,3411]
operator: , [3438,3439]
===
match
---
name: warnings [1773,1781]
name: warnings [1783,1791]
===
match
---
name: mkdirs [1424,1430]
name: mkdirs [1434,1440]
===
match
---
name: os [2064,2066]
name: os [2074,2076]
===
match
---
atom_expr [2908,2932]
atom_expr [2936,2960]
===
match
---
name: open [3670,3674]
name: open [3698,3702]
===
match
---
trailer [3626,3633]
trailer [3654,3661]
===
match
---
atom_expr [8001,8016]
atom_expr [8029,8044]
===
match
---
atom_expr [8058,8105]
atom_expr [8086,8133]
===
match
---
comp_if [4019,4152]
comp_if [4047,4180]
===
match
---
atom [3955,4162]
atom [3983,4190]
===
match
---
name: root [4085,4089]
name: root [4113,4117]
===
match
---
name: fallback [4760,4768]
name: fallback [4788,4796]
===
match
---
name: bool [4702,4706]
name: bool [4730,4734]
===
match
---
expr_stmt [3718,3803]
expr_stmt [3746,3831]
===
match
---
import_from [837,861]
import_from [847,871]
===
match
---
comparison [5628,5652]
comparison [5656,5680]
===
match
---
trailer [1400,1417]
trailer [1410,1427]
===
match
---
operator: , [4503,4504]
operator: , [4531,4532]
===
match
---
name: os [4069,4071]
name: os [4097,4099]
===
match
---
name: getLogger [977,986]
name: getLogger [987,996]
===
match
---
name: DeprecationWarning [1891,1909]
name: DeprecationWarning [1901,1919]
===
match
---
operator: } [1871,1872]
operator: } [1881,1882]
===
match
---
arglist [4209,4217]
arglist [4237,4245]
===
match
---
name: archive [2376,2383]
name: archive [2386,2393]
===
match
---
operator: - [6822,6823]
operator: - [6850,6851]
===
match
---
name: sd [4215,4217]
name: sd [4243,4245]
===
match
---
trailer [3920,3935]
trailer [3948,3963]
===
match
---
trailer [8044,8046]
trailer [8072,8074]
===
match
---
not_test [7706,7719]
not_test [7734,7747]
===
match
---
operator: , [4774,4775]
operator: , [4802,4803]
===
match
---
trailer [5814,5819]
trailer [5842,5847]
===
match
---
name: find_path_from_directory [2939,2963]
name: find_path_from_directory [2967,2991]
===
match
---
simple_stmt [6044,6106]
simple_stmt [6072,6134]
===
match
---
atom_expr [3435,3453]
atom_expr [3463,3481]
===
match
---
name: List [898,902]
name: List [908,912]
===
match
---
simple_stmt [7729,7741]
simple_stmt [7757,7769]
===
match
---
name: os [4462,4464]
name: os [4490,4492]
===
match
---
simple_stmt [7181,7221]
simple_stmt [7209,7249]
===
match
---
name: log [7126,7129]
name: log [7154,7157]
===
match
---
atom_expr [2064,2070]
atom_expr [2074,2080]
===
match
---
trailer [1800,1938]
trailer [1810,1948]
===
match
---
operator: = [1929,1930]
operator: = [1939,1940]
===
match
---
simple_stmt [7919,7931]
simple_stmt [7947,7959]
===
match
---
suite [5778,5803]
suite [5806,5831]
===
match
---
trailer [2303,2310]
trailer [2313,2320]
===
match
---
expr_stmt [8021,8046]
expr_stmt [8049,8074]
===
match
---
trailer [3741,3745]
trailer [3769,3773]
===
match
---
name: include_examples [5976,5992]
name: include_examples [6004,6020]
===
match
---
name: split [6805,6810]
name: split [6833,6838]
===
match
---
operator: * [1022,1023]
operator: * [1032,1033]
===
match
---
name: is_zipfile [2796,2806]
name: is_zipfile [2806,2816]
===
match
---
atom_expr [6780,6826]
atom_expr [6808,6854]
===
match
---
atom_expr [7126,7178]
atom_expr [7154,7206]
===
match
---
operator: = [1978,1979]
operator: = [1988,1989]
===
match
---
trailer [4469,4477]
trailer [4497,4505]
===
match
---
name: smart_sensor_dag_folder [6281,6304]
name: smart_sensor_dag_folder [6309,6332]
===
match
---
import_name [1766,1781]
import_name [1776,1791]
===
match
---
operator: , [1881,1882]
operator: , [1891,1892]
===
match
---
trailer [4534,4577]
trailer [4562,4605]
===
match
---
suite [3473,4641]
suite [3501,4669]
===
match
---
atom_expr [5738,5747]
atom_expr [5766,5775]
===
match
---
arglist [3584,3606]
arglist [3612,3634]
===
match
---
string: "This function is deprecated. Please use `tempfile.TemporaryDirectory`" [1254,1325]
string: "This function is deprecated. Please use `tempfile.TemporaryDirectory`" [1264,1335]
===
match
---
suite [2393,2417]
suite [2403,2427]
===
match
---
operator: = [1964,1965]
operator: = [1974,1975]
===
match
---
operator: = [967,968]
operator: = [977,978]
===
match
---
atom_expr [3492,3510]
atom_expr [3520,3538]
===
match
---
number: 0 [6334,6335]
number: 0 [6362,6363]
===
match
---
if_stmt [4309,4363]
if_stmt [4337,4391]
===
match
---
name: pathlib [842,849]
name: pathlib [852,859]
===
match
---
operator: == [4317,4319]
operator: == [4345,4347]
===
match
---
name: str [4622,4625]
name: str [4650,4653]
===
match
---
arglist [7949,7964]
arglist [7977,7992]
===
match
---
trailer [7948,7965]
trailer [7976,7993]
===
match
---
name: filename [2873,2881]
name: filename [2900,2908]
===
match
---
sync_comp_for [4121,4138]
sync_comp_for [4149,4166]
===
match
---
name: str [3505,3508]
name: str [3533,3536]
===
match
---
name: file_path [6717,6726]
name: file_path [6745,6754]
===
match
---
name: file_paths [6361,6371]
name: file_paths [6389,6399]
===
match
---
atom_expr [6307,6336]
atom_expr [6335,6364]
===
match
---
name: lower [8039,8044]
name: lower [8067,8072]
===
match
---
name: search [2744,2750]
name: search [2754,2760]
===
match
---
atom_expr [8031,8046]
atom_expr [8059,8074]
===
match
---
atom_expr [6868,6897]
atom_expr [6896,6925]
===
match
---
name: dirs [4246,4250]
name: dirs [4274,4278]
===
match
---
trailer [6716,6727]
trailer [6744,6755]
===
match
---
suite [3037,4641]
suite [3065,4669]
===
match
---
name: safe_mode [6531,6540]
name: safe_mode [6559,6568]
===
match
---
operator: != [6851,6853]
operator: != [6879,6881]
===
match
---
name: warn [1796,1800]
name: warn [1806,1810]
===
match
---
name: format [2047,2053]
name: format [2057,2063]
===
match
---
name: _ [6766,6767]
name: _ [6794,6795]
===
match
---
operator: = [6778,6779]
operator: = [6806,6807]
===
match
---
name: root [4209,4213]
name: root [4237,4241]
===
match
---
param [2101,2108]
param [2111,2118]
===
match
---
name: search [4049,4055]
name: search [4077,4083]
===
match
---
suite [5653,5722]
suite [5681,5750]
===
match
---
dictorsetmaker [4196,4250]
dictorsetmaker [4224,4278]
===
match
---
simple_stmt [2369,2384]
simple_stmt [2379,2394]
===
match
---
param [7261,7277]
param [7289,7305]
===
match
---
param [6531,6546]
param [6559,6574]
===
match
---
name: ignore_file_name [3590,3606]
name: ignore_file_name [3618,3634]
===
match
---
name: archive [2776,2783]
name: archive [2786,2793]
===
match
---
operator: = [2012,2013]
operator: = [2022,2023]
===
match
---
trailer [3843,3849]
trailer [3871,3877]
===
match
---
suite [7757,7855]
suite [7785,7883]
===
match
---
trailer [5934,5968]
trailer [5962,5996]
===
match
---
name: directory [5935,5944]
name: directory [5963,5972]
===
match
---
import_as_name [1197,1225]
import_as_name [1207,1235]
===
match
---
simple_stmt [3718,3804]
simple_stmt [3746,3832]
===
match
---
name: file_paths [6114,6124]
name: file_paths [6142,6152]
===
match
---
name: zipfile [829,836]
name: zipfile [839,846]
===
match
---
name: tempfile [1181,1189]
name: tempfile [1191,1199]
===
match
---
and_test [2776,2815]
and_test [2786,2825]
===
match
---
name: mode [2862,2866]
name: mode [2889,2893]
===
match
---
name: ZIP_REGEX [2734,2743]
name: ZIP_REGEX [2744,2753]
===
match
---
name: patterns_by_dir [4172,4187]
name: patterns_by_dir [4200,4215]
===
match
---
name: list [3916,3920]
name: list [3944,3948]
===
match
---
string: '.py' [6854,6859]
string: '.py' [6882,6887]
===
match
---
name: safe_mode [6423,6432]
name: safe_mode [6451,6460]
===
match
---
atom_expr [2788,2815]
atom_expr [2798,2825]
===
match
---
name: line [3854,3858]
name: line [3882,3886]
===
match
---
trailer [6704,6709]
trailer [6732,6737]
===
match
---
simple_stmt [5847,5872]
simple_stmt [5875,5900]
===
match
---
trailer [6378,6448]
trailer [6406,6476]
===
match
---
trailer [4068,4119]
trailer [4096,4147]
===
match
---
import_name [1156,1171]
import_name [1166,1181]
===
match
---
string: 'core' [5697,5703]
string: 'core' [5725,5731]
===
match
---
name: list_py_file_paths [6132,6150]
name: list_py_file_paths [6160,6178]
===
match
---
operator: , [4915,4916]
operator: , [4943,4944]
===
match
---
name: current_file [7799,7811]
name: current_file [7827,7839]
===
match
---
operator: , [6169,6170]
operator: , [6197,6198]
===
match
---
simple_stmt [812,822]
simple_stmt [822,832]
===
match
---
atom_expr [1787,1938]
atom_expr [1797,1948]
===
match
---
name: os [3619,3621]
name: os [3647,3649]
===
match
---
name: zipfile [2832,2839]
name: zipfile [2859,2866]
===
match
---
return_stmt [2402,2416]
return_stmt [2412,2426]
===
match
---
trailer [8038,8044]
trailer [8066,8072]
===
match
---
atom [5800,5802]
atom [5828,5830]
===
match
---
tfpdef [7278,7313]
tfpdef [7306,7341]
===
match
---
file_input [787,8106]
file_input [787,8134]
===
match
---
string: 'DAG_DISCOVERY_SAFE_MODE' [4733,4758]
string: 'DAG_DISCOVERY_SAFE_MODE' [4761,4786]
===
match
---
operator: , [2448,2449]
operator: , [2458,2459]
===
match
---
operator: , [6649,6650]
operator: , [6677,6678]
===
match
---
name: isfile [3627,3633]
name: isfile [3655,3661]
===
match
---
if_stmt [5625,5722]
if_stmt [5653,5750]
===
match
---
param [7278,7320]
param [7306,7348]
===
match
---
name: bool [4807,4811]
name: bool [4835,4839]
===
match
---
name: file_ext [6769,6777]
name: file_ext [6797,6805]
===
match
---
operator: = [4813,4814]
operator: = [4841,4842]
===
match
---
trailer [7894,7905]
trailer [7922,7933]
===
match
---
if_stmt [6936,7009]
if_stmt [6964,7037]
===
match
---
name: any [4026,4029]
name: any [4054,4057]
===
match
---
return_stmt [1387,1417]
return_stmt [1397,1427]
===
match
---
param [6513,6530]
param [6541,6558]
===
match
---
with_stmt [3665,3936]
with_stmt [3693,3964]
===
match
---
atom_expr [7288,7313]
atom_expr [7316,7341]
===
match
---
name: os [6780,6782]
name: os [6808,6810]
===
match
---
tfpdef [4671,4685]
tfpdef [4699,4713]
===
match
---
simple_stmt [3905,3936]
simple_stmt [3933,3964]
===
match
---
name: fileloc [2101,2108]
name: fileloc [2111,2118]
===
match
---
name: archive [2320,2327]
name: archive [2330,2337]
===
match
---
name: Dict [3362,3366]
name: Dict [3390,3394]
===
match
---
param [4691,4775]
param [4719,4803]
===
match
---
name: isfile [6710,6716]
name: isfile [6738,6744]
===
match
---
trailer [6131,6196]
trailer [6159,6224]
===
match
---
trailer [1795,1800]
trailer [1805,1810]
===
match
---
parameters [1430,1442]
parameters [1440,1452]
===
match
---
name: ignore_file_path [3675,3691]
name: ignore_file_path [3703,3719]
===
match
---
string: 'LOAD_EXAMPLES' [5705,5720]
string: 'LOAD_EXAMPLES' [5733,5748]
===
match
---
operator: , [1406,1407]
operator: , [1416,1417]
===
match
---
trailer [2847,2867]
trailer [2874,2894]
===
match
---
import_name [812,821]
import_name [822,831]
===
match
---
atom [4195,4251]
atom [4223,4279]
===
match
---
name: str [4484,4487]
name: str [4512,4515]
===
match
---
name: file_path [7040,7049]
name: file_path [7068,7077]
===
match
---
string: 'rb' [7960,7964]
string: 'rb' [7988,7992]
===
match
---
name: __path__ [6325,6333]
name: __path__ [6353,6361]
===
match
---
name: safe_mode [6972,6981]
name: safe_mode [7000,7009]
===
match
---
expr_stmt [5726,5752]
expr_stmt [5754,5780]
===
match
---
trailer [3366,3391]
trailer [3394,3419]
===
match
---
name: str [4091,4094]
name: str [4119,4122]
===
match
---
name: safe_mode [7710,7719]
name: safe_mode [7738,7747]
===
match
---
funcdef [2076,2417]
funcdef [2086,2427]
===
match
---
return_stmt [2825,2882]
return_stmt [2835,2910]
===
match
---
name: mkdir [1954,1959]
name: mkdir [1964,1969]
===
match
---
trailer [6821,6825]
trailer [6849,6853]
===
match
---
operator: , [4685,4686]
operator: , [4713,4714]
===
match
---
name: p [4125,4126]
name: p [4153,4154]
===
match
---
name: filename [2723,2731]
name: filename [2733,2741]
===
match
---
string: """     Heuristic that guesses whether a Python file contains an Airflow DAG definition.      :param file_path: Path to the file to be checked.     :param safe_mode: Is safe mode active?. If no, this function always returns True.     :param zip_file: if passed, checks the archive. Otherwise, check local filesystem.     :return: True, if file might contain DAGS.     """ [7327,7698]
string: """     Heuristic that guesses whether a Python file contains an Airflow DAG definition.      :param file_path: Path to the file to be checked.     :param safe_mode: Is safe mode active?. If no, this function always returns True.     :param zip_file: if passed, checks the archive. Otherwise, check local filesystem.     :return: True, if file might contain DAGS.     """ [7355,7726]
===
match
---
operator: , [2272,2273]
operator: , [2282,2283]
===
match
---
import_name [822,836]
import_name [832,846]
===
match
---
return_stmt [8051,8105]
return_stmt [8079,8133]
===
match
---
trailer [2806,2815]
trailer [2816,2825]
===
match
---
name: open_maybe_zipped [2423,2440]
name: open_maybe_zipped [2433,2450]
===
match
---
name: list [6525,6529]
name: list [6553,6557]
===
match
---
arglist [4404,4419]
arglist [4432,4447]
===
match
---
suite [2892,2933]
suite [2920,2961]
===
match
---
atom_expr [4391,4420]
atom_expr [4419,4448]
===
match
---
name: search [4537,4543]
name: search [4565,4571]
===
match
---
operator: , [1909,1910]
operator: , [1919,1920]
===
match
---
expr_stmt [4375,4420]
expr_stmt [4403,4448]
===
match
---
name: read [8010,8014]
name: read [8038,8042]
===
match
---
name: followlinks [3455,3466]
name: followlinks [3483,3494]
===
match
---
operator: = [2276,2277]
operator: = [2286,2287]
===
match
---
trailer [3384,3389]
trailer [3412,3417]
===
match
---
and_test [6842,6897]
and_test [6870,6925]
===
match
---
suite [2110,2417]
suite [2120,2427]
===
match
---
name: file_path [7168,7177]
name: file_path [7196,7205]
===
match
---
simple_stmt [963,997]
simple_stmt [973,1007]
===
match
---
name: _ [2711,2712]
name: _ [2721,2722]
===
match
---
simple_stmt [7991,8017]
simple_stmt [8019,8045]
===
match
---
trailer [6709,6716]
trailer [6737,6744]
===
match
---
atom [8084,8104]
atom [8112,8132]
===
match
---
funcdef [7223,8106]
funcdef [7251,8134]
===
match
---
argument [8062,8104]
argument [8090,8132]
===
match
---
name: file_path [6887,6896]
name: file_path [6915,6924]
===
match
---
name: root [3584,3588]
name: root [3612,3616]
===
match
---
tfpdef [7245,7259]
tfpdef [7273,7287]
===
match
---
trailer [1959,1999]
trailer [1969,2009]
===
match
---
trailer [3796,3802]
trailer [3824,3830]
===
match
---
operator: , [1969,1970]
operator: , [1979,1980]
===
match
---
trailer [4084,4110]
trailer [4112,4138]
===
match
---
import_name [787,801]
import_name [797,811]
===
match
---
operator: , [4482,4483]
operator: , [4510,4511]
===
match
---
expr_stmt [7181,7220]
expr_stmt [7209,7248]
===
match
---
simple_stmt [2711,2769]
simple_stmt [2721,2779]
===
match
---
string: b'dag' [8085,8091]
string: b'dag' [8113,8119]
===
match
---
arglist [1254,1376]
arglist [1264,1386]
===
match
---
name: groups [2304,2310]
name: groups [2314,2320]
===
match
---
name: root [3533,3537]
name: root [3561,3565]
===
match
---
name: zip_file [7771,7779]
name: zip_file [7799,7807]
===
match
---
name: root [3406,3410]
name: root [3434,3438]
===
match
---
expr_stmt [3945,4162]
expr_stmt [3973,4190]
===
match
---
operator: = [2861,2862]
operator: = [2888,2889]
===
match
---
import_from [1176,1225]
import_from [1186,1235]
===
match
---
arglist [6640,6667]
arglist [6668,6695]
===
match
---
sync_comp_for [8075,8104]
sync_comp_for [8103,8132]
===
match
---
name: search [2288,2294]
name: search [2298,2304]
===
match
---
sync_comp_for [4559,4576]
sync_comp_for [4587,4604]
===
match
---
name: safe_mode [6171,6180]
name: safe_mode [6199,6208]
===
match
---
atom_expr [4220,4235]
atom_expr [4248,4263]
===
match
---
string: 'use_smart_sensor' [4896,4914]
string: 'use_smart_sensor' [4924,4942]
===
match
---
atom_expr [5812,5837]
atom_expr [5840,5865]
===
match
---
name: directory [5895,5904]
name: directory [5923,5932]
===
match
---
trailer [7201,7209]
trailer [7229,7237]
===
match
---
simple_stmt [1076,1152]
simple_stmt [1086,1162]
===
match
---
return_stmt [2369,2383]
return_stmt [2379,2393]
===
match
---
name: zipfile [7876,7883]
name: zipfile [7904,7911]
===
match
---
operator: * [1401,1402]
operator: * [1411,1412]
===
match
---
param [4671,4686]
param [4699,4714]
===
match
---
name: file [4414,4418]
name: file [4442,4446]
===
match
---
simple_stmt [1787,1939]
simple_stmt [1797,1949]
===
match
---
operator: , [4408,4409]
operator: , [4436,4437]
===
match
---
tfpdef [6497,6511]
tfpdef [6525,6539]
===
match
---
name: smart_sensor_dags [6307,6324]
name: smart_sensor_dags [6335,6352]
===
match
---
trailer [4094,4109]
trailer [4122,4137]
===
match
---
argument [1401,1406]
argument [1411,1416]
===
match
---
string: """     Traverse a directory and look for Python files.      :param directory: the directory to traverse     :type directory: unicode     :param safe_mode: whether to use a heuristic to determine whether a file         contains Airflow DAG definitions. If not provided, use the         core.DAG_DISCOVERY_SAFE_MODE configuration setting. If not set, default         to safe.     :type safe_mode: bool     :param include_examples: include example DAGs     :type include_examples: bool     :param include_smart_sensor: include smart sensor native control DAGs     :type include_examples: bool     :return: a list of paths to Python files in the specified directory     :rtype: list[unicode]     """ [4924,5620]
string: """     Traverse a directory and look for Python files.      :param directory: the directory to traverse     :type directory: unicode     :param safe_mode: whether to use a heuristic to determine whether a file         contains Airflow DAG definitions. If not provided, use the         core.DAG_DISCOVERY_SAFE_MODE configuration setting. If not set, default         to safe.     :type safe_mode: bool     :param include_examples: include example DAGs     :type include_examples: bool     :param include_smart_sensor: include smart sensor native control DAGs     :type include_examples: bool     :return: a list of paths to Python files in the specified directory     :rtype: list[unicode]     """ [4952,5648]
===
match
---
trailer [6397,6447]
trailer [6425,6475]
===
match
---
name: p [4563,4564]
name: p [4591,4592]
===
match
---
trailer [4208,4218]
trailer [4236,4246]
===
match
---
atom_expr [6615,6668]
atom_expr [6643,6696]
===
match
---
suite [2816,2883]
suite [2826,2911]
===
match
---
trailer [5685,5696]
trailer [5713,5724]
===
match
---
dotted_name [928,949]
dotted_name [938,959]
===
match
---
operator: , [4758,4759]
operator: , [4786,4787]
===
match
---
name: abs_file_path [4626,4639]
name: abs_file_path [4654,4667]
===
match
---
factor [6822,6824]
factor [6850,6852]
===
match
---
import_from [6002,6034]
import_from [6030,6062]
===
match
---
simple_stmt [3482,3543]
simple_stmt [3510,3571]
===
match
---
name: find_dag_file_paths [6477,6496]
name: find_dag_file_paths [6505,6524]
===
match
---
argument [1919,1931]
argument [1929,1941]
===
match
---
name: path [4072,4076]
name: path [4100,4104]
===
match
---
simple_stmt [6234,6272]
simple_stmt [6262,6300]
===
match
---
trailer [3434,3472]
trailer [3462,3500]
===
match
---
not_test [6698,6727]
not_test [6726,6755]
===
match
---
trailer [4058,4063]
trailer [4086,4091]
===
match
---
name: List [5738,5742]
name: List [5766,5770]
===
match
---
name: example_dags [6022,6034]
name: example_dags [6050,6062]
===
match
---
atom [3832,3888]
atom [3860,3916]
===
match
---
name: path [4452,4456]
name: path [4480,4484]
===
match
---
trailer [3019,3036]
trailer [3047,3064]
===
match
---
name: sub [3742,3745]
name: sub [3770,3773]
===
match
---
name: re [2014,2016]
name: re [2024,2026]
===
match
---
name: extend [6372,6378]
name: extend [6400,6406]
===
match
---
atom_expr [4798,4812]
atom_expr [4826,4840]
===
match
---
operator: = [5858,5859]
operator: = [5886,5887]
===
match
---
trailer [2759,2766]
trailer [2769,2776]
===
match
---
with_stmt [7766,7855]
with_stmt [7794,7883]
===
match
---
argument [3455,3471]
argument [3483,3499]
===
match
---
name: mode [1960,1964]
name: mode [1970,1974]
===
match
---
operator: = [4447,4448]
operator: = [4475,4476]
===
match
---
name: ignore_file_name [2984,3000]
name: ignore_file_name [3012,3028]
===
match
---
comparison [8062,8074]
comparison [8090,8102]
===
match
---
name: Optional [904,912]
name: Optional [914,922]
===
match
---
name: ZIP_REGEX [2278,2287]
name: ZIP_REGEX [2288,2297]
===
match
---
trailer [1953,1959]
trailer [1963,1969]
===
match
---
simple_stmt [4354,4363]
simple_stmt [4382,4391]
===
match
---
trailer [5888,5894]
trailer [5916,5922]
===
match
---
operator: , [3023,3024]
operator: , [3051,3052]
===
match
---
name: p [4535,4536]
name: p [4563,4564]
===
match
---
atom_expr [4847,4861]
atom_expr [4875,4889]
===
match
---
name: append [7033,7039]
name: append [7061,7067]
===
match
---
atom_expr [4196,4218]
atom_expr [4224,4246]
===
match
---
simple_stmt [862,922]
simple_stmt [872,932]
===
match
---
arglist [5935,5967]
arglist [5963,5995]
===
match
---
expr_stmt [2002,2073]
expr_stmt [2012,2083]
===
match
---
tfpdef [4825,4861]
tfpdef [4853,4889]
===
match
---
trailer [8014,8016]
trailer [8042,8044]
===
match
---
tfpdef [7261,7276]
tfpdef [7289,7304]
===
match
---
suite [2360,2384]
suite [2370,2394]
===
match
---
param [6497,6512]
param [6525,6540]
===
match
---
operator: , [2712,2713]
operator: , [2722,2723]
===
match
---
name: archive [2848,2855]
name: archive [2875,2882]
===
match
---
parameters [2440,2459]
parameters [2450,2469]
===
match
---
arglist [2848,2866]
arglist [2875,2893]
===
match
---
trailer [7129,7139]
trailer [7157,7167]
===
match
---
trailer [986,996]
trailer [996,1006]
===
match
---
name: conf [4864,4868]
name: conf [4892,4896]
===
match
---
trailer [5883,5888]
trailer [5911,5916]
===
match
---
name: update [4188,4194]
name: update [4216,4222]
===
match
---
name: p [4047,4048]
name: p [4075,4076]
===
match
---
operator: , [5944,5945]
operator: , [5972,5973]
===
match
---
name: TemporaryDirectory [1197,1215]
name: TemporaryDirectory [1207,1225]
===
match
---
atom_expr [1394,1417]
atom_expr [1404,1427]
===
match
---
name: dirs [3412,3416]
name: dirs [3440,3444]
===
match
---
trailer [6324,6333]
trailer [6352,6361]
===
match
---
name: directory [5827,5836]
name: directory [5855,5864]
===
match
---
suite [6548,7179]
suite [6576,7207]
===
match
---
simple_stmt [3945,4163]
simple_stmt [3973,4191]
===
match
---
if_stmt [3616,3936]
if_stmt [3644,3964]
===
match
---
name: Generator [3010,3019]
name: Generator [3038,3047]
===
match
---
simple_stmt [8051,8106]
simple_stmt [8079,8134]
===
match
---
trailer [1947,1953]
trailer [1957,1963]
===
match
---
trailer [6782,6787]
trailer [6810,6815]
===
match
---
atom_expr [4449,4515]
atom_expr [4477,4543]
===
match
---
trailer [3633,3651]
trailer [3661,3679]
===
match
---
name: join [3579,3583]
name: join [3607,3611]
===
match
---
name: read [7848,7852]
name: read [7876,7880]
===
match
---
simple_stmt [7000,7009]
simple_stmt [7028,7037]
===
match
---
name: file_paths [6513,6523]
name: file_paths [6541,6551]
===
match
---
name: os [5881,5883]
name: os [5909,5911]
===
match
---
yield_expr [4616,4640]
yield_expr [4644,4668]
===
match
---
parameters [2963,3006]
parameters [2991,3034]
===
match
---
name: stacklevel [1919,1929]
name: stacklevel [1929,1939]
===
match
---
suite [3652,3936]
suite [3680,3964]
===
match
---
name: DeprecationWarning [1335,1353]
name: DeprecationWarning [1345,1363]
===
match
---
operator: , [6767,6768]
operator: , [6795,6796]
===
match
---
trailer [2766,2768]
trailer [2776,2778]
===
match
---
expr_stmt [6766,6826]
expr_stmt [6794,6854]
===
match
---
trailer [4076,4084]
trailer [4104,4112]
===
match
---
name: archive [2265,2272]
name: archive [2275,2282]
===
match
---
funcdef [1420,2000]
funcdef [1430,2010]
===
match
---
tfpdef [4691,4706]
tfpdef [4719,4734]
===
match
---
suite [5906,5969]
suite [5934,5997]
===
match
---
operator: } [3395,3396]
operator: } [3423,3424]
===
match
---
simple_stmt [1766,1782]
simple_stmt [1776,1792]
===
match
---
trailer [3788,3790]
trailer [3816,3818]
===
match
---
atom_expr [2025,2072]
atom_expr [2035,2082]
===
match
---
trailer [2063,2071]
trailer [2073,2081]
===
match
---
atom_expr [3921,3934]
atom_expr [3949,3962]
===
match
---
trailer [4456,4461]
trailer [4484,4489]
===
match
---
sync_comp_for [3988,4152]
sync_comp_for [4016,4180]
===
match
---
name: exist_ok [1985,1993]
name: exist_ok [1995,2003]
===
match
---
atom_expr [5881,5905]
atom_expr [5909,5933]
===
match
---
operator: , [4819,4820]
operator: , [4847,4848]
===
match
---
simple_stmt [5787,5803]
simple_stmt [5815,5831]
===
match
---
atom_expr [4709,4774]
atom_expr [4737,4802]
===
match
---
name: airflow [6239,6246]
name: airflow [6267,6274]
===
match
---
trailer [2743,2750]
trailer [2753,2760]
===
match
---
name: zip_file [7278,7286]
name: zip_file [7306,7314]
===
match
---
operator: = [6305,6306]
operator: = [6333,6334]
===
match
---
suite [7322,8106]
suite [7350,8134]
===
match
---
string: r"\s*#.*" [7210,7219]
string: r"\s*#.*" [7238,7247]
===
match
---
name: str [3002,3005]
name: str [3030,3033]
===
match
---
name: fileloc [2295,2302]
name: fileloc [2305,2312]
===
match
---
trailer [4536,4543]
trailer [4564,4571]
===
match
---
trailer [2024,2073]
trailer [2034,2083]
===
match
---
name: line [3761,3765]
name: line [3789,3793]
===
match
---
name: read [3784,3788]
name: read [3812,3816]
===
match
---
name: str [6508,6511]
name: str [6536,6539]
===
match
---
name: compile [7202,7209]
name: compile [7230,7237]
===
match
---
name: args [1402,1406]
name: args [1412,1416]
===
match
---
argument [2857,2866]
argument [2884,2893]
===
match
---
name: fileloc [2409,2416]
name: fileloc [2419,2426]
===
match
---
name: patterns [3482,3490]
name: patterns [3510,3518]
===
match
---
operator: , [7166,7167]
operator: , [7194,7195]
===
match
---
atom_expr [3010,3036]
atom_expr [3038,3064]
===
match
---
operator: , [3537,3538]
operator: , [3565,3566]
===
match
---
trailer [4393,4398]
trailer [4421,4426]
===
match
---
name: ZipFile [7305,7312]
name: ZipFile [7333,7340]
===
match
---
name: Dict [881,885]
name: Dict [891,895]
===
match
---
operator: , [896,897]
operator: , [906,907]
===
match
---
name: dirs [3945,3949]
name: dirs [3973,3977]
===
match
---
name: str [4410,4413]
name: str [4438,4441]
===
match
---
atom_expr [4462,4503]
atom_expr [4490,4531]
===
match
---
trailer [2310,2312]
trailer [2320,2322]
===
match
---
name: sd [4240,4242]
name: sd [4268,4270]
===
match
---
name: __name__ [987,995]
name: __name__ [997,1005]
===
match
---
suite [7812,7855]
suite [7840,7883]
===
match
---
parameters [6496,6547]
parameters [6524,6575]
===
match
---
name: airflow [6007,6014]
name: airflow [6035,6042]
===
match
---
expr_stmt [6281,6336]
expr_stmt [6309,6364]
===
match
---
name: subdir [4112,4118]
name: subdir [4140,4146]
===
match
---
name: path [4394,4398]
name: path [4422,4426]
===
match
---
fstring_end: " [1880,1881]
fstring_end: " [1890,1891]
===
match
---
argument [4760,4773]
argument [4788,4801]
===
match
---
name: include_examples [4780,4796]
name: include_examples [4808,4824]
===
match
---
simple_stmt [2465,2707]
simple_stmt [2475,2717]
===
match
---
atom_expr [4026,4152]
atom_expr [4054,4180]
===
match
---
name: zipfile [2788,2795]
name: zipfile [2798,2805]
===
match
---
return_stmt [7919,7930]
return_stmt [7947,7958]
===
match
---
trailer [6799,6804]
trailer [6827,6832]
===
match
---
atom_expr [5681,5721]
atom_expr [5709,5749]
===
match
---
name: patterns [4568,4576]
name: patterns [4596,4604]
===
match
---
testlist_comp [3739,3802]
testlist_comp [3767,3830]
===
match
---
operator: , [6529,6530]
operator: , [6557,6558]
===
match
---
parameters [7244,7321]
parameters [7272,7349]
===
match
---
testlist_star_expr [6766,6777]
testlist_star_expr [6794,6805]
===
match
---
name: file_paths [5946,5956]
name: file_paths [5974,5984]
===
match
---
atom_expr [3571,3607]
atom_expr [3599,3635]
===
match
---
expr_stmt [6044,6089]
expr_stmt [6072,6117]
===
match
---
atom_expr [7835,7854]
atom_expr [7863,7882]
===
match
---
atom_expr [7876,7905]
atom_expr [7904,7933]
===
match
---
name: stacklevel [1363,1373]
name: stacklevel [1373,1383]
===
match
---
trailer [6960,6982]
trailer [6988,7010]
===
match
---
sync_comp_for [4236,4250]
sync_comp_for [4264,4278]
===
match
---
name: str [3020,3023]
name: str [3048,3051]
===
match
---
atom_expr [4056,4119]
atom_expr [4084,4147]
===
match
---
name: is_zipfile [2340,2350]
name: is_zipfile [2350,2360]
===
match
---
name: open [2908,2912]
name: open [2936,2940]
===
match
---
name: log [963,966]
name: log [973,976]
===
match
---
atom_expr [3779,3802]
atom_expr [3807,3830]
===
match
---
testlist_comp [3969,4152]
testlist_comp [3997,4180]
===
match
---
comparison [6842,6859]
comparison [6870,6887]
===
match
---
operator: , [6421,6422]
operator: , [6449,6450]
===
match
---
atom_expr [6065,6089]
atom_expr [6093,6117]
===
match
---
annassign [5736,5752]
annassign [5764,5780]
===
match
---
operator: ** [1029,1031]
operator: ** [1039,1041]
===
match
---
name: zipfile [7297,7304]
name: zipfile [7325,7332]
===
match
---
expr_stmt [3552,3607]
expr_stmt [3580,3635]
===
match
---
trailer [2912,2932]
trailer [2940,2960]
===
match
---
operator: , [3759,3760]
operator: , [3787,3788]
===
match
---
simple_stmt [1448,1762]
simple_stmt [1458,1772]
===
match
---
name: patterns [4130,4138]
name: patterns [4158,4166]
===
match
---
if_stmt [2317,2417]
if_stmt [2327,2427]
===
match
---
number: 0 [6087,6088]
number: 0 [6115,6116]
===
match
---
operator: = [3392,3393]
operator: = [3420,3421]
===
match
---
operator: , [1027,1028]
operator: , [1037,1038]
===
match
---
with_item [3670,3700]
with_item [3698,3728]
===
match
---
atom [3738,3803]
atom [3766,3831]
===
match
---
if_stmt [6839,6924]
if_stmt [6867,6952]
===
match
---
trailer [2056,2063]
trailer [2066,2073]
===
match
---
import_from [6234,6271]
import_from [6262,6299]
===
match
---
operator: = [3914,3915]
operator: = [3942,3943]
===
match
---
name: path [6800,6804]
name: path [6828,6832]
===
match
---
atom_expr [4410,4419]
atom_expr [4438,4447]
===
match
---
name: configuration [936,949]
name: configuration [946,959]
===
match
---
name: path [6705,6709]
name: path [6733,6737]
===
match
---
expr_stmt [5662,5721]
expr_stmt [5690,5749]
===
match
---
name: airflow [928,935]
name: airflow [938,945]
===
match
---
operator: = [2926,2927]
operator: = [2954,2955]
===
match
---
trailer [4228,4233]
trailer [4256,4261]
===
match
---
expr_stmt [963,996]
expr_stmt [973,1006]
===
match
---
atom_expr [6361,6448]
atom_expr [6389,6476]
===
match
---
name: getboolean [4714,4724]
name: getboolean [4742,4752]
===
match
---
operator: = [3569,3570]
operator: = [3597,3598]
===
match
---
name: file_path [6961,6970]
name: file_path [6989,6998]
===
match
---
simple_stmt [1231,1383]
simple_stmt [1241,1393]
===
match
---
import_as_names [881,921]
import_as_names [891,931]
===
match
---
trailer [4194,4252]
trailer [4222,4280]
===
match
---
if_stmt [2773,2933]
if_stmt [2783,2961]
===
match
---
name: Generator [887,896]
name: Generator [897,906]
===
match
---
param [1437,1441]
param [1447,1451]
===
match
---
name: groups [2760,2766]
name: groups [2770,2776]
===
match
---
atom_expr [3945,3952]
atom_expr [3973,3980]
===
match
---
trailer [5742,5747]
trailer [5770,5775]
===
match
---
fstring_string: This function is deprecated. Please use `pathlib.Path( [1812,1866]
fstring_string: This function is deprecated. Please use `pathlib.Path( [1822,1876]
===
match
---
atom_expr [4484,4502]
atom_expr [4512,4530]
===
match
---
name: line [3844,3848]
name: line [3872,3876]
===
match
---
simple_stmt [822,837]
simple_stmt [832,847]
===
match
---
arglist [7140,7177]
arglist [7168,7205]
===
match
---
name: re [2054,2056]
name: re [2064,2066]
===
match
---
trailer [6086,6089]
trailer [6114,6117]
===
match
---
trailer [4487,4502]
trailer [4515,4530]
===
match
---
funcdef [6473,7179]
funcdef [6501,7207]
===
match
---
trailer [5894,5905]
trailer [5922,5933]
===
match
---
trailer [4508,4514]
trailer [4536,4542]
===
match
---
atom_expr [3427,3472]
atom_expr [3455,3500]
===
match
---
name: logging [969,976]
name: logging [979,986]
===
match
---
name: compile [3836,3843]
name: compile [3864,3871]
===
match
---
suite [6728,6754]
suite [6756,6782]
===
match
---
trailer [2053,2072]
trailer [2063,2082]
===
match
---
param [7245,7260]
param [7273,7288]
===
match
---
name: file_path [6602,6611]
name: file_path [6630,6639]
===
match
---
operator: , [4894,4895]
operator: , [4922,4923]
===
match
---
suite [5993,6197]
suite [6021,6225]
===
match
---
name: str [3435,3438]
name: str [3463,3466]
===
match
---
trailer [7779,7784]
trailer [7807,7812]
===
match
---
name: conf [957,961]
name: conf [967,971]
===
match
---
name: open [7944,7948]
name: open [7972,7976]
===
match
---
name: Path [857,861]
name: Path [867,871]
===
match
---
name: find_path_from_directory [6615,6639]
name: find_path_from_directory [6643,6667]
===
match
---
simple_stmt [802,812]
simple_stmt [812,822]
===
match
---
name: get [3529,3532]
name: get [3557,3560]
===
match
---
trailer [4625,4640]
trailer [4653,4668]
===
match
---
atom_expr [6132,6195]
atom_expr [6160,6223]
===
match
---
name: TemporaryDirectory [1003,1021]
name: TemporaryDirectory [1013,1031]
===
match
---
name: correct_maybe_zipped [2080,2100]
name: correct_maybe_zipped [2090,2110]
===
match
---
name: zipfile [6868,6875]
name: zipfile [6896,6903]
===
match
---
import_name [802,811]
import_name [812,821]
===
match
---
trailer [6371,6378]
trailer [6399,6406]
===
match
---
trailer [4713,4724]
trailer [4741,4752]
===
match
---
name: file_path [7785,7794]
name: file_path [7813,7822]
===
match
---
string: """Finds file paths of all DAG files.""" [6553,6593]
string: """Finds file paths of all DAG files.""" [6581,6621]
===
match
---
string: """     If the path contains a folder with a .zip suffix, then     the folder is treated as a zip archive and path to zip is returned.     """ [2115,2257]
string: """     If the path contains a folder with a .zip suffix, then     the folder is treated as a zip archive and path to zip is returned.     """ [2125,2267]
===
match
---
atom_expr [7199,7220]
atom_expr [7227,7248]
===
match
---
simple_stmt [837,862]
simple_stmt [847,872]
===
match
---
name: fileloc [2913,2920]
name: fileloc [2941,2948]
===
match
---
simple_stmt [5726,5753]
simple_stmt [5754,5781]
===
match
---
trailer [7209,7220]
trailer [7237,7248]
===
match
---
name: example_dag_folder [6044,6062]
name: example_dag_folder [6072,6090]
===
match
---
operator: , [7958,7959]
operator: , [7986,7987]
===
match
---
trailer [4403,4420]
trailer [4431,4448]
===
match
---
name: str [4505,4508]
name: str [4533,4536]
===
match
---
name: compile [2017,2024]
name: compile [2027,2034]
===
match
---
operator: { [1866,1867]
operator: { [1876,1877]
===
match
---
simple_stmt [1943,2000]
simple_stmt [1953,2010]
===
match
---
name: content [8031,8038]
name: content [8059,8066]
===
match
---
atom_expr [3513,3542]
atom_expr [3541,3570]
===
match
---
name: _ [2262,2263]
name: _ [2272,2273]
===
match
---
operator: } [4250,4251]
operator: } [4278,4279]
===
match
---
name: list_py_file_paths [6379,6397]
name: list_py_file_paths [6407,6425]
===
match
---
atom_expr [3670,3692]
atom_expr [3698,3720]
===
match
---
name: relpath [4077,4084]
name: relpath [4105,4112]
===
match
---
atom_expr [4531,4577]
atom_expr [4559,4605]
===
match
---
expr_stmt [3482,3542]
expr_stmt [3510,3570]
===
match
---
funcdef [4643,6471]
funcdef [4671,6499]
===
match
---
name: base_dir_path [4488,4501]
name: base_dir_path [4516,4529]
===
match
---
name: subdir [3969,3975]
name: subdir [3997,4003]
===
match
---
argument [1960,1969]
argument [1970,1979]
===
match
---
name: all [8058,8061]
name: all [8086,8089]
===
match
---
name: might_contain_dag [7227,7244]
name: might_contain_dag [7255,7272]
===
match
---
tfpdef [4780,4812]
tfpdef [4808,4840]
===
match
---
suite [2460,2933]
suite [2470,2961]
===
match
---
string: ".airflowignore" [6651,6667]
string: ".airflowignore" [6679,6695]
===
match
---
name: line [3771,3775]
name: line [3799,3803]
===
match
---
name: file [3696,3700]
name: file [3724,3728]
===
match
---
atom_expr [3916,3935]
atom_expr [3944,3963]
===
match
---
string: 'smart_sensor' [4880,4894]
string: 'smart_sensor' [4908,4922]
===
match
---
except_clause [7059,7075]
except_clause [7087,7103]
===
match
---
simple_stmt [2002,2074]
simple_stmt [2012,2084]
===
match
---
operator: = [4768,4769]
operator: = [4796,4797]
===
match
---
name: base_dir_path [3439,3452]
name: base_dir_path [3467,3480]
===
match
---
name: files [4274,4279]
name: files [4302,4307]
===
match
---
trailer [2294,2303]
trailer [2304,2313]
===
match
---
trailer [6804,6810]
trailer [6832,6838]
===
match
---
name: list_py_file_paths [4647,4665]
name: list_py_file_paths [4675,4693]
===
match
---
atom_expr [2832,2882]
atom_expr [2859,2909]
===
match
---
name: os [6702,6704]
name: os [6730,6732]
===
match
---
param [1431,1436]
param [1441,1446]
===
match
---
name: zip_file [7748,7756]
name: zip_file [7776,7784]
===
match
---
name: ignore_file_path [3634,3650]
name: ignore_file_path [3662,3678]
===
match
---
trailer [4724,4774]
trailer [4752,4802]
===
match
---
atom_expr [1943,1999]
atom_expr [1953,2009]
===
match
---
atom_expr [4505,4514]
atom_expr [4533,4542]
===
match
---
argument [1985,1998]
argument [1995,2008]
===
match
---
name: List [3372,3376]
name: List [3400,3404]
===
match
---
name: os [4449,4451]
name: os [4477,4479]
===
match
---
not_test [6939,6982]
not_test [6967,7010]
===
match
---
name: args [1023,1027]
name: args [1033,1037]
===
match
---
trailer [6886,6897]
trailer [6914,6925]
===
match
---
suite [6983,7009]
suite [7011,7037]
===
match
---
suite [4337,4363]
suite [4365,4391]
===
match
---
subscriptlist [3020,3035]
subscriptlist [3048,3063]
===
match
---
name: file_paths [7022,7032]
name: file_paths [7050,7060]
===
match
---
trailer [7032,7039]
trailer [7060,7067]
===
match
---
expr_stmt [7825,7854]
expr_stmt [7853,7882]
===
match
---
trailer [3674,3692]
trailer [3702,3720]
===
match
---
if_stmt [7873,7931]
if_stmt [7901,7959]
===
match
---
name: re [819,821]
name: re [829,831]
===
match
---
string: 'r' [2455,2458]
string: 'r' [2465,2468]
===
match
---
trailer [3496,3510]
trailer [3524,3538]
===
match
---
arglist [4085,4109]
arglist [4113,4137]
===
match
---
arglist [4725,4773]
arglist [4753,4801]
===
match
---
trailer [4198,4203]
trailer [4226,4231]
===
match
---
operator: = [5679,5680]
operator: = [5707,5708]
===
match
---
trailer [4233,4235]
trailer [4261,4263]
===
match
---
expr_stmt [2711,2768]
expr_stmt [2721,2778]
===
match
---
name: __path__ [6078,6086]
name: __path__ [6106,6114]
===
match
---
atom_expr [4091,4109]
atom_expr [4119,4137]
===
match
---
param [1029,1037]
param [1039,1047]
===
match
---
atom_expr [3833,3849]
atom_expr [3861,3877]
===
match
---
operator: , [3416,3417]
operator: , [3444,3445]
===
match
---
name: base_dir_path [4095,4108]
name: base_dir_path [4123,4136]
===
match
---
name: path [4465,4469]
name: path [4493,4497]
===
match
---
name: warnings [1163,1171]
name: warnings [1173,1181]
===
match
---
name: path [3622,3626]
name: path [3650,3654]
===
match
---
if_stmt [5757,5969]
if_stmt [5785,5997]
===
match
---
name: path [6783,6787]
name: path [6811,6815]
===
match
---
expr_stmt [5787,5802]
expr_stmt [5815,5830]
===
match
---
operator: , [3453,3454]
operator: , [3481,3482]
===
match
---
trailer [3573,3578]
trailer [3601,3606]
===
match
---
name: Path [1943,1947]
name: Path [1953,1957]
===
match
---
trailer [4413,4419]
trailer [4441,4447]
===
match
---
trailer [6787,6796]
trailer [6815,6824]
===
match
---
operator: , [1325,1326]
operator: , [1335,1336]
===
match
---
name: mode [2922,2926]
name: mode [2950,2954]
===
match
---
operator: , [2855,2856]
operator: , [2882,2883]
===
match
---
parameters [2100,2109]
parameters [2110,2119]
===
match
---
operator: , [2982,2983]
operator: , [3010,3011]
===
match
---
name: str [3385,3388]
name: str [3413,3416]
===
match
---
name: patterns_by_dir [3345,3360]
name: patterns_by_dir [3373,3388]
===
match
---
atom_expr [3619,3651]
atom_expr [3647,3679]
===
match
---
name: smart_sensor_dag_folder [6398,6421]
name: smart_sensor_dag_folder [6426,6449]
===
match
---
name: _ [2274,2275]
name: _ [2284,2285]
===
match
---
argument [1971,1983]
argument [1981,1993]
===
match
---
trailer [4048,4055]
trailer [4076,4083]
===
match
---
name: open [7780,7784]
name: open [7808,7812]
===
match
---
name: file [4266,4270]
name: file [4294,4298]
===
match
---
trailer [2339,2350]
trailer [2349,2360]
===
match
---
simple_stmt [6766,6827]
simple_stmt [6794,6855]
===
match
---
name: directory [5760,5769]
name: directory [5788,5797]
===
match
---
string: "Error while examining %s" [7140,7166]
string: "Error while examining %s" [7168,7194]
===
match
---
argument [1363,1375]
argument [1373,1385]
===
match
---
tfpdef [2984,3005]
tfpdef [3012,3033]
===
match
---
arglist [4478,4502]
arglist [4506,4530]
===
match
---
atom [3394,3396]
atom [3422,3424]
===
match
---
trailer [7039,7050]
trailer [7067,7078]
===
match
---
arglist [3746,3765]
arglist [3774,3793]
===
match
---
atom_expr [4047,4120]
atom_expr [4075,4148]
===
match
---
operator: , [6187,6188]
operator: , [6215,6216]
===
match
---
trailer [7847,7852]
trailer [7875,7880]
===
match
---
operator: , [5703,5704]
operator: , [5731,5732]
===
match
---
tfpdef [6531,6546]
tfpdef [6559,6574]
===
match
---
trailer [7296,7313]
trailer [7324,7341]
===
match
---
name: join [4204,4208]
name: join [4232,4236]
===
match
---
suite [6225,6449]
suite [6253,6477]
===
match
---
name: include_examples [5628,5644]
name: include_examples [5656,5672]
===
match
---
simple_stmt [6453,6471]
simple_stmt [6481,6499]
===
match
---
param [2964,2983]
param [2992,3011]
===
match
---
operator: , [6439,6440]
operator: , [6467,6468]
===
match
---
simple_stmt [1387,1418]
simple_stmt [1397,1428]
===
match
---
name: path [4059,4063]
name: path [4087,4091]
===
match
---
simple_stmt [6745,6754]
simple_stmt [6773,6782]
===
match
---
name: set [3921,3924]
name: set [3949,3952]
===
match
---
operator: , [1983,1984]
operator: , [1993,1994]
===
match
---
with_item [7771,7811]
with_item [7799,7839]
===
match
---
trailer [1239,1244]
trailer [1249,1254]
===
match
---
simple_stmt [6553,6594]
simple_stmt [6581,6622]
===
match
---
trailer [976,986]
trailer [986,996]
===
match
---
operator: = [1373,1374]
operator: = [1383,1384]
===
match
---
name: conf [4709,4713]
name: conf [4737,4741]
===
match
---
name: root [4478,4482]
name: root [4506,4510]
===
match
---
name: patterns [3820,3828]
name: patterns [3848,3856]
===
match
---
name: re [3739,3741]
name: re [3767,3769]
===
match
---
trailer [6796,6826]
trailer [6824,6854]
===
match
---
atom_expr [3377,3389]
atom_expr [3405,3417]
===
match
---
name: os [5812,5814]
name: os [5840,5842]
===
match
---
trailer [4055,4120]
trailer [4083,4148]
===
match
---
operator: , [4110,4111]
operator: , [4138,4139]
===
match
---
atom_expr [4172,4252]
atom_expr [4200,4280]
===
match
---
string: r"\s*#.*" [3746,3755]
string: r"\s*#.*" [3774,3783]
===
match
---
name: relpath [4470,4477]
name: relpath [4498,4505]
===
match
---
name: mode [2450,2454]
name: mode [2460,2464]
===
match
---
arglist [3435,3471]
arglist [3463,3499]
===
match
---
operator: , [1353,1354]
operator: , [1363,1364]
===
match
---
operator: , [1375,1376]
operator: , [1385,1386]
===
match
---
suite [1071,1418]
suite [1081,1428]
===
match
---
name: os [809,811]
name: os [819,821]
===
match
---
operator: , [3029,3030]
operator: , [3057,3058]
===
match
---
suite [7864,8017]
suite [7892,8045]
===
match
---
name: warnings [1231,1239]
name: warnings [1241,1249]
===
match
---
string: """     Search the file and return the path of the file that should not be ignored.     :param base_dir_path: the base path to be searched for.     :param ignore_file_name: the file name in which specifies a regular expression pattern is written.      :return : file path not to be ignored.     """ [3042,3340]
string: """     Search the file and return the path of the file that should not be ignored.     :param base_dir_path: the base path to be searched for.     :param ignore_file_name: the file name in which specifies a regular expression pattern is written.      :return : file path not to be ignored.     """ [3070,3368]
===
match
---
not_test [4022,4152]
not_test [4050,4180]
===
match
---
argument [2922,2931]
argument [2950,2959]
===
match
---
name: file_paths [5726,5736]
name: file_paths [5754,5764]
===
match
---
return_stmt [2901,2932]
return_stmt [2929,2960]
===
match
---
name: join [4064,4068]
name: join [4092,4096]
===
match
---
trailer [4806,4812]
trailer [4834,4840]
===
match
---
arglist [6151,6194]
arglist [6179,6222]
===
match
---
string: "\n" [3797,3801]
string: "\n" [3825,3829]
===
match
---
string: 'core' [4725,4731]
string: 'core' [4753,4759]
===
match
---
expr_stmt [5847,5871]
expr_stmt [5875,5899]
===
match
---
suite [6669,7179]
suite [6697,7207]
===
match
---
sync_comp_for [3850,3887]
sync_comp_for [3878,3915]
===
match
---
argument [1408,1416]
argument [1418,1426]
===
match
---
param [1022,1028]
param [1032,1038]
===
match
---
trailer [3528,3532]
trailer [3556,3560]
===
match
---
fstring [1810,1881]
fstring [1820,1891]
===
match
---
name: content [8067,8074]
name: content [8095,8102]
===
match
---
name: Pattern [914,921]
name: Pattern [924,931]
===
match
---
name: include_examples [5662,5678]
name: include_examples [5690,5706]
===
match
---
name: path [3574,3578]
name: path [3602,3606]
===
match
---
operator: = [7999,8000]
operator: = [8027,8028]
===
match
---
simple_stmt [6361,6449]
simple_stmt [6389,6477]
===
match
---
name: walk [3430,3434]
name: walk [3458,3462]
===
match
---
name: is_zipfile [6876,6886]
name: is_zipfile [6904,6914]
===
match
---
expr_stmt [2262,2312]
expr_stmt [2272,2322]
===
match
---
name: subdir [3992,3998]
name: subdir [4020,4026]
===
match
---
funcdef [2419,2933]
funcdef [2429,2961]
===
match
---
atom_expr [2278,2312]
atom_expr [2288,2322]
===
match
---
name: directory [6640,6649]
name: directory [6668,6677]
===
match
---
suite [6898,6924]
suite [6926,6952]
===
match
---
name: safe_mode [4691,4700]
name: safe_mode [4719,4728]
===
match
---
name: TmpDir [1394,1400]
name: TmpDir [1404,1410]
===
match
---
simple_stmt [7825,7855]
simple_stmt [7853,7883]
===
match
---
sync_comp_for [3767,3802]
sync_comp_for [3795,3830]
===
match
---
trailer [7852,7854]
trailer [7880,7882]
===
match
---
name: archive [2807,2814]
name: archive [2817,2824]
===
match
---
name: fileloc [2751,2758]
name: fileloc [2761,2768]
===
match
---
trailer [3745,3766]
trailer [3773,3794]
===
match
---
name: file [3779,3783]
name: file [3807,3811]
===
match
---
operator: = [3953,3954]
operator: = [3981,3982]
===
match
---
name: file_paths [5847,5857]
name: file_paths [5875,5885]
===
match
---
suite [7720,7741]
suite [7748,7769]
===
match
---
name: split [3791,3796]
name: split [3819,3824]
===
match
---
trailer [7139,7178]
trailer [7167,7206]
===
match
---
name: Pattern [3497,3504]
name: Pattern [3525,3532]
===
match
---
simple_stmt [5915,5969]
simple_stmt [5943,5997]
===
match
---
name: join [4457,4461]
name: join [4485,4489]
===
match
---
number: 2 [1930,1931]
number: 2 [1940,1941]
===
match
---
simple_stmt [3042,3341]
simple_stmt [3070,3369]
===
match
---
arglist [1960,1998]
arglist [1970,2008]
===
match
---
operator: = [4862,4863]
operator: = [4890,4891]
===
match
---
trailer [7304,7312]
trailer [7332,7340]
===
match
---
suite [7978,8017]
suite [8006,8045]
===
match
---
operator: , [6511,6512]
operator: , [6539,6540]
===
match
---
operator: = [5748,5749]
operator: = [5776,5777]
===
match
---
name: path [5884,5888]
name: path [5912,5916]
===
match
---
name: parents [1971,1978]
name: parents [1981,1988]
===
match
---
comparison [5760,5777]
comparison [5788,5805]
===
match
---
name: isfile [5820,5826]
name: isfile [5848,5854]
===
match
---
name: mode [2927,2931]
name: mode [2955,2959]
===
match
---
name: exception [7130,7139]
name: exception [7158,7167]
===
match
---
name: include_smart_sensor [4825,4845]
name: include_smart_sensor [4853,4873]
===
match
---
if_stmt [6695,6754]
if_stmt [6723,6782]
===
match
---
not_test [6864,6897]
not_test [6892,6925]
===
match
---
name: escape [2057,2063]
name: escape [2067,2073]
===
match
---
trailer [3621,3626]
trailer [3649,3654]
===
match
---
tfpdef [6513,6529]
tfpdef [6541,6557]
===
match
---
trailer [7784,7795]
trailer [7812,7823]
===
match
---
operator: , [1931,1932]
operator: , [1941,1942]
===
match
---
name: mode [2857,2861]
name: mode [2884,2888]
===
match
---
trailer [4451,4456]
trailer [4479,4484]
===
match
---
expr_stmt [4433,4515]
expr_stmt [4461,4543]
===
match
---
name: file_paths [5787,5797]
name: file_paths [5815,5825]
===
match
---
name: any [4531,4534]
name: any [4559,4562]
===
match
---
expr_stmt [3345,3396]
expr_stmt [3373,3424]
===
match
---
name: files [3418,3423]
name: files [3446,3451]
===
match
---
simple_stmt [4172,4253]
simple_stmt [4200,4281]
===
match
---
name: str [5743,5746]
name: str [5771,5774]
===
match
---
name: typing [867,873]
name: typing [877,883]
===
match
---
name: fileloc [2441,2448]
name: fileloc [2451,2458]
===
match
---
name: include_smart_sensor [6204,6224]
name: include_smart_sensor [6232,6252]
===
match
---
arglist [2913,2931]
arglist [2941,2959]
===
match
---
atom_expr [5915,5968]
atom_expr [5943,5996]
===
match
---
trailer [6124,6131]
trailer [6152,6159]
===
match
---
trailer [4868,4879]
trailer [4896,4907]
===
match
---
atom_expr [2734,2768]
atom_expr [2744,2778]
===
match
---
name: getboolean [4869,4879]
name: getboolean [4897,4907]
===
match
---
name: os [4196,4198]
name: os [4224,4226]
===
match
---
name: os [4056,4058]
name: os [4084,4086]
===
match
---
operator: , [7276,7277]
operator: , [7304,7305]
===
match
---
trailer [7883,7894]
trailer [7911,7922]
===
match
---
exprlist [3406,3423]
exprlist [3434,3451]
===
match
---
operator: = [3466,3467]
operator: = [3494,3495]
===
match
---
name: Optional [7288,7296]
name: Optional [7316,7324]
===
match
---
name: str [7256,7259]
name: str [7284,7287]
===
match
---
suite [4919,6471]
suite [4947,6499]
===
match
---
name: base_dir_path [2964,2977]
name: base_dir_path [2992,3005]
===
match
---
suite [3701,3936]
suite [3729,3964]
===
match
---
trailer [8061,8105]
trailer [8089,8133]
===
match
---
atom_expr [4069,4110]
atom_expr [4097,4138]
===
match
---
operator: { [3394,3395]
operator: { [3422,3423]
===
match
---
atom_expr [969,996]
atom_expr [979,1006]
===
match
---
simple_stmt [7022,7051]
simple_stmt [7050,7079]
===
match
---
name: abs_file_path [4375,4388]
name: abs_file_path [4403,4416]
===
match
---
atom_expr [3372,3390]
atom_expr [3400,3418]
===
match
---
expr_stmt [3905,3935]
expr_stmt [3933,3963]
===
match
---
name: file_path [7245,7254]
name: file_path [7273,7282]
===
match
---
name: Pattern [3377,3384]
name: Pattern [3405,3412]
===
match
---
trailer [4063,4068]
trailer [4091,4096]
===
match
---
atom_expr [3362,3391]
atom_expr [3390,3419]
===
match
---
trailer [4855,4861]
trailer [4883,4889]
===
match
---
name: zipfile [2332,2339]
name: zipfile [2342,2349]
===
insert-tree
---
simple_stmt [787,797]
    import_name [787,796]
        name: io [794,796]
to
file_input [787,8106]
at 0
===
insert-node
---
atom_expr [2842,2910]
to
return_stmt [2825,2882]
at 0
===
insert-node
---
trailer [2858,2910]
to
atom_expr [2842,2910]
at 2
===
move-tree
---
atom_expr [2832,2882]
    name: zipfile [2832,2839]
    trailer [2839,2847]
        name: ZipFile [2840,2847]
    trailer [2847,2867]
        arglist [2848,2866]
            name: archive [2848,2855]
            operator: , [2855,2856]
            argument [2857,2866]
                name: mode [2857,2861]
                operator: = [2861,2862]
                name: mode [2862,2866]
    trailer [2867,2872]
        name: open [2868,2872]
    trailer [2872,2882]
        name: filename [2873,2881]
to
trailer [2858,2910]
at 0
