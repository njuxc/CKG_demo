===
match
---
name: ignore_ti_state [15252,15267]
name: ignore_ti_state [15252,15267]
===
match
---
atom_expr [27784,27833]
atom_expr [27784,27833]
===
match
---
name: VariableJsonAccessor [65752,65772]
name: VariableJsonAccessor [65886,65906]
===
match
---
expr_stmt [3168,3187]
expr_stmt [3168,3187]
===
match
---
expr_stmt [25931,25947]
expr_stmt [25931,25947]
===
match
---
name: is_container [2492,2504]
name: is_container [2492,2504]
===
match
---
string: """         Checks on whether the task instance is in the right state and timeframe         to be retried.         """ [34801,34919]
string: """         Checks on whether the task instance is in the right state and timeframe         to be retried.         """ [34801,34919]
===
match
---
atom_expr [35339,35477]
atom_expr [35339,35477]
===
match
---
atom_expr [8264,8275]
atom_expr [8264,8275]
===
match
---
name: TemplateAssertionError [67318,67340]
name: TemplateAssertionError [67452,67474]
===
match
---
operator: , [53696,53697]
operator: , [53696,53697]
===
match
---
name: count [77358,77363]
name: count [77492,77497]
===
match
---
string: 'next_execution_date' [64739,64760]
string: 'next_execution_date' [64873,64894]
===
match
---
trailer [7414,7418]
trailer [7414,7418]
===
match
---
name: _run_finished_callback [59199,59221]
name: _run_finished_callback [59333,59355]
===
match
---
trailer [5381,5390]
trailer [5381,5390]
===
match
---
operator: = [15739,15740]
operator: = [15739,15740]
===
match
---
operator: = [19576,19577]
operator: = [19576,19577]
===
match
---
name: dep_context [39794,39805]
name: dep_context [39794,39805]
===
match
---
trailer [82090,82092]
trailer [82224,82226]
===
match
---
comparison [24857,24885]
comparison [24857,24885]
===
match
---
name: init_run_context [77602,77618]
name: init_run_context [77736,77752]
===
match
---
name: v [49267,49268]
name: v [49267,49268]
===
match
---
import_from [1275,1364]
import_from [1275,1364]
===
match
---
operator: = [61601,61602]
operator: = [61735,61736]
===
match
---
string: '%Y%m%dT%H%M%S' [58402,58417]
string: '%Y%m%dT%H%M%S' [58536,58551]
===
match
---
annassign [8088,8098]
annassign [8088,8098]
===
match
---
name: test_mode [55098,55107]
name: test_mode [55098,55107]
===
match
---
name: task [11095,11099]
name: task [11095,11099]
===
match
---
name: set_duration [56708,56720]
name: set_duration [56842,56854]
===
match
---
name: property [80686,80694]
name: property [80820,80828]
===
match
---
name: SIGTERM [48527,48534]
name: SIGTERM [48527,48534]
===
match
---
trailer [43108,43114]
trailer [43108,43114]
===
match
---
name: try_number [80784,80794]
name: try_number [80918,80928]
===
match
---
atom_expr [41366,41385]
atom_expr [41366,41385]
===
match
---
trailer [39899,39903]
trailer [39899,39903]
===
match
---
name: UtcDateTime [9719,9730]
name: UtcDateTime [9719,9730]
===
match
---
tfpdef [58979,59004]
tfpdef [59113,59138]
===
match
---
name: self [71442,71446]
name: self [71576,71580]
===
match
---
atom_expr [54657,54682]
atom_expr [54657,54682]
===
match
---
trailer [52762,52771]
trailer [52762,52771]
===
match
---
name: ti [26023,26025]
name: ti [26023,26025]
===
match
---
argument [70700,70724]
argument [70834,70858]
===
match
---
expr_stmt [20218,20502]
expr_stmt [20218,20502]
===
match
---
for_stmt [47244,47436]
for_stmt [47244,47436]
===
match
---
param [58941,58970]
param [59075,59104]
===
match
---
simple_stmt [48410,48430]
simple_stmt [48410,48430]
===
match
---
trailer [10001,10029]
trailer [10001,10029]
===
match
---
atom_expr [22797,22803]
atom_expr [22797,22803]
===
match
---
trailer [55902,55906]
trailer [55902,55906]
===
match
---
name: merge [50861,50866]
name: merge [50861,50866]
===
match
---
if_stmt [41085,41298]
if_stmt [41085,41298]
===
match
---
trailer [79631,79639]
trailer [79765,79773]
===
match
---
operator: = [61414,61415]
operator: = [61548,61549]
===
match
---
name: self [44354,44358]
name: self [44354,44358]
===
match
---
import_name [862,871]
import_name [862,871]
===
match
---
atom_expr [26540,26564]
atom_expr [26540,26564]
===
match
---
trailer [6113,6125]
trailer [6113,6125]
===
match
---
return_stmt [26371,26416]
return_stmt [26371,26416]
===
match
---
simple_stmt [42646,42684]
simple_stmt [42646,42684]
===
match
---
name: execution_date [8296,8310]
name: execution_date [8296,8310]
===
match
---
name: timezone [2406,2414]
name: timezone [2406,2414]
===
match
---
trailer [20382,20390]
trailer [20382,20390]
===
match
---
expr_stmt [26346,26362]
expr_stmt [26346,26362]
===
match
---
operator: , [40543,40544]
operator: , [40543,40544]
===
match
---
decorator [80984,80994]
decorator [81118,81128]
===
match
---
name: dag_id [78557,78563]
name: dag_id [78691,78697]
===
match
---
atom_expr [5282,5307]
atom_expr [5282,5307]
===
match
---
name: job [82408,82411]
name: job [82542,82545]
===
match
---
name: datetime [72978,72986]
name: datetime [73112,73120]
===
match
---
operator: , [20458,20459]
operator: , [20458,20459]
===
match
---
operator: = [12132,12133]
operator: = [12132,12133]
===
match
---
atom_expr [82509,82529]
atom_expr [82643,82663]
===
match
---
factor [82203,82205]
factor [82337,82339]
===
match
---
operator: -> [80635,80637]
operator: -> [80769,80771]
===
match
---
operator: = [46143,46144]
operator: = [46143,46144]
===
match
---
name: str [29781,29784]
name: str [29781,29784]
===
match
---
name: self [68452,68456]
name: self [68586,68590]
===
match
---
operator: , [49220,49221]
operator: , [49220,49221]
===
match
---
trailer [4384,4402]
trailer [4384,4402]
===
match
---
simple_stmt [29505,29558]
simple_stmt [29505,29558]
===
match
---
name: self [52139,52143]
name: self [52139,52143]
===
match
---
trailer [20366,20374]
trailer [20366,20374]
===
match
---
atom_expr [82563,82584]
atom_expr [82697,82718]
===
match
---
operator: , [30914,30915]
operator: , [30914,30915]
===
match
---
trailer [7771,7786]
trailer [7771,7786]
===
match
---
name: task [62190,62194]
name: task [62324,62328]
===
match
---
name: dr [35504,35506]
name: dr [35504,35506]
===
match
---
string: '\n' [49238,49242]
string: '\n' [49238,49242]
===
match
---
name: relationship [1451,1463]
name: relationship [1451,1463]
===
match
---
name: self [68240,68244]
name: self [68374,68378]
===
match
---
simple_stmt [41011,41053]
simple_stmt [41011,41053]
===
match
---
name: max_tries [71483,71492]
name: max_tries [71617,71626]
===
match
---
name: queue [22617,22622]
name: queue [22617,22622]
===
match
---
operator: == [77529,77531]
operator: == [77663,77665]
===
match
---
name: debug [31730,31735]
name: debug [31730,31735]
===
match
---
param [15946,15964]
param [15946,15964]
===
match
---
name: self [58257,58261]
name: self [58391,58395]
===
match
---
operator: == [79193,79195]
operator: == [79327,79329]
===
match
---
name: xcom_push [51759,51768]
name: xcom_push [51759,51768]
===
match
---
atom_expr [41118,41195]
atom_expr [41118,41195]
===
match
---
atom_expr [24332,24351]
atom_expr [24332,24351]
===
match
---
name: Optional [68094,68102]
name: Optional [68228,68236]
===
match
---
parameters [20645,20665]
parameters [20645,20665]
===
match
---
operator: = [78202,78203]
operator: = [78336,78337]
===
match
---
operator: , [1059,1060]
operator: , [1059,1060]
===
match
---
operator: , [1347,1348]
operator: , [1347,1348]
===
match
---
name: self [59092,59096]
name: self [59226,59230]
===
match
---
arglist [43570,43899]
arglist [43570,43899]
===
match
---
name: self [50774,50778]
name: self [50774,50778]
===
match
---
name: self [56703,56707]
name: self [56837,56841]
===
match
---
expr_stmt [14577,14596]
expr_stmt [14577,14596]
===
match
---
name: self [11525,11529]
name: self [11525,11529]
===
match
---
suite [27205,27238]
suite [27205,27238]
===
match
---
atom_expr [12029,12044]
atom_expr [12029,12044]
===
match
---
trailer [82127,82133]
trailer [82261,82267]
===
match
---
dotted_name [82400,82420]
dotted_name [82534,82554]
===
match
---
name: conditions [6600,6610]
name: conditions [6600,6610]
===
match
---
string: 'subject_template' [71927,71945]
string: 'subject_template' [72061,72079]
===
match
---
name: sqlalchemy [1370,1380]
name: sqlalchemy [1370,1380]
===
match
---
name: SimpleTaskInstance [79400,79418]
name: SimpleTaskInstance [79534,79552]
===
match
---
atom_expr [26144,26194]
atom_expr [26144,26194]
===
match
---
operator: , [24002,24003]
operator: , [24002,24003]
===
match
---
string: 'webserver' [19587,19598]
string: 'webserver' [19587,19598]
===
match
---
name: context [51600,51607]
name: context [51600,51607]
===
match
---
name: session [32288,32295]
name: session [32288,32295]
===
match
---
simple_stmt [62100,62150]
simple_stmt [62234,62284]
===
match
---
trailer [65772,65774]
trailer [65906,65908]
===
match
---
atom_expr [81217,81226]
atom_expr [81351,81360]
===
match
---
name: airflow [1974,1981]
name: airflow [1974,1981]
===
match
---
atom_expr [57638,57665]
atom_expr [57772,57799]
===
match
---
name: task_reschedule [39056,39071]
name: task_reschedule [39056,39071]
===
match
---
trailer [29252,29271]
trailer [29252,29271]
===
match
---
operator: , [35822,35823]
operator: , [35822,35823]
===
match
---
name: with_row_locks [2772,2786]
name: with_row_locks [2772,2786]
===
match
---
name: self [47069,47073]
name: self [47069,47073]
===
match
---
suite [56846,56896]
suite [56980,57030]
===
match
---
name: self [48946,48950]
name: self [48946,48950]
===
match
---
simple_stmt [27089,27158]
simple_stmt [27089,27158]
===
match
---
name: bool [15688,15692]
name: bool [15688,15692]
===
match
---
expr_stmt [24657,24689]
expr_stmt [24657,24689]
===
match
---
sync_comp_for [7709,7722]
sync_comp_for [7709,7722]
===
match
---
trailer [29054,29070]
trailer [29054,29070]
===
match
---
name: init_on_load [12180,12192]
name: init_on_load [12180,12192]
===
match
---
funcdef [32863,32983]
funcdef [32863,32983]
===
match
---
name: self [43867,43871]
name: self [43867,43871]
===
match
---
trailer [81931,81940]
trailer [82065,82074]
===
match
---
atom_expr [54332,54578]
atom_expr [54332,54578]
===
match
---
parameters [52263,52316]
parameters [52263,52316]
===
match
---
name: exc [52090,52093]
name: exc [52090,52093]
===
match
---
name: dag_id [78422,78428]
name: dag_id [78556,78562]
===
match
---
name: self [47389,47393]
name: self [47389,47393]
===
match
---
name: dag_id [10737,10743]
name: dag_id [10737,10743]
===
match
---
simple_stmt [52553,52570]
simple_stmt [52553,52570]
===
match
---
param [80795,80799]
param [80929,80933]
===
match
---
operator: = [61053,61054]
operator: = [61187,61188]
===
match
---
name: date_attr [59422,59431]
name: date_attr [59556,59565]
===
match
---
atom [60123,60288]
atom [60257,60422]
===
match
---
name: test_mode [37483,37492]
name: test_mode [37483,37492]
===
match
---
atom_expr [72076,72133]
atom_expr [72210,72267]
===
match
---
name: task_tries [7062,7072]
name: task_tries [7062,7072]
===
match
---
if_stmt [40658,40726]
if_stmt [40658,40726]
===
match
---
trailer [26301,26309]
trailer [26301,26309]
===
match
---
atom_expr [52286,52307]
atom_expr [52286,52307]
===
match
---
operator: = [49131,49132]
operator: = [49131,49132]
===
match
---
atom_expr [40700,40724]
atom_expr [40700,40724]
===
match
---
tfpdef [41681,41702]
tfpdef [41681,41702]
===
match
---
trailer [23863,23885]
trailer [23863,23885]
===
match
---
simple_stmt [51505,51525]
simple_stmt [51505,51525]
===
match
---
name: info [40599,40603]
name: info [40599,40603]
===
match
---
name: self [63807,63811]
name: self [63941,63945]
===
match
---
parameters [33011,33017]
parameters [33011,33017]
===
match
---
suite [23668,24148]
suite [23668,24148]
===
match
---
trailer [6097,6108]
trailer [6097,6108]
===
match
---
atom_expr [81903,81923]
atom_expr [82037,82057]
===
match
---
trailer [28275,28280]
trailer [28275,28280]
===
match
---
trailer [43205,43208]
trailer [43205,43208]
===
match
---
name: task [59958,59962]
name: task [60092,60096]
===
match
---
string: """         This attribute is deprecated.         Please use `airflow.models.taskinstance.TaskInstance.get_previous_start_date` method.         """ [30364,30511]
string: """         This attribute is deprecated.         Please use `airflow.models.taskinstance.TaskInstance.get_previous_start_date` method.         """ [30364,30511]
===
match
---
expr_stmt [27089,27157]
expr_stmt [27089,27157]
===
match
---
name: get [19038,19041]
name: get [19038,19041]
===
match
---
suite [67569,67800]
suite [67703,67934]
===
match
---
simple_stmt [59566,59576]
simple_stmt [59700,59710]
===
match
---
trailer [48350,48397]
trailer [48350,48397]
===
match
---
operator: , [61781,61782]
operator: , [61915,61916]
===
match
---
parameters [4268,4315]
parameters [4268,4315]
===
match
---
name: DagRun [35353,35359]
name: DagRun [35353,35359]
===
match
---
operator: = [54850,54851]
operator: = [54850,54851]
===
match
---
simple_stmt [82156,82176]
simple_stmt [82290,82310]
===
match
---
operator: , [14203,14204]
operator: , [14203,14204]
===
match
---
name: start_date [79739,79749]
name: start_date [79873,79883]
===
match
---
name: expected_state [3624,3638]
name: expected_state [3624,3638]
===
match
---
string: """Handle Failure for the TaskInstance""" [56229,56270]
string: """Handle Failure for the TaskInstance""" [56229,56270]
===
match
---
name: with_for_update [21829,21844]
name: with_for_update [21829,21844]
===
match
---
name: t [78482,78483]
name: t [78616,78617]
===
match
---
name: _try_number [13216,13227]
name: _try_number [13216,13227]
===
match
---
name: try_number [5567,5577]
name: try_number [5567,5577]
===
match
---
atom_expr [72627,72640]
atom_expr [72761,72774]
===
match
---
name: self [68490,68494]
name: self [68624,68628]
===
match
---
name: self [77704,77708]
name: self [77838,77842]
===
match
---
name: _try_number [13184,13195]
name: _try_number [13184,13195]
===
match
---
atom_expr [60005,60020]
atom_expr [60139,60154]
===
match
---
trailer [40699,40725]
trailer [40699,40725]
===
match
---
operator: , [26258,26259]
operator: , [26258,26259]
===
match
---
atom_expr [11241,11253]
atom_expr [11241,11253]
===
match
---
dotted_name [2510,2541]
dotted_name [2510,2541]
===
match
---
atom_expr [43731,43743]
atom_expr [43731,43743]
===
match
---
name: self [63681,63685]
name: self [63815,63819]
===
match
---
name: key [76302,76305]
name: key [76436,76439]
===
match
---
name: self [80459,80463]
name: self [80593,80597]
===
match
---
name: task [58519,58523]
name: task [58653,58657]
===
match
---
tfpdef [3919,3932]
tfpdef [3919,3932]
===
match
---
argument [44807,44828]
argument [44807,44828]
===
match
---
name: dr [27882,27884]
name: dr [27882,27884]
===
match
---
name: context_to_airflow_vars [2648,2671]
name: context_to_airflow_vars [2648,2671]
===
match
---
fstring_expr [19100,19113]
fstring_expr [19100,19113]
===
match
---
expr_stmt [79570,79599]
expr_stmt [79704,79733]
===
match
---
atom_expr [32045,32062]
atom_expr [32045,32062]
===
match
---
name: dag [5424,5427]
name: dag [5424,5427]
===
match
---
argument [31816,31831]
argument [31816,31831]
===
match
---
trailer [11210,11217]
trailer [11210,11217]
===
match
---
expr_stmt [57903,57942]
expr_stmt [58037,58076]
===
match
---
name: task [64606,64610]
name: task [64740,64744]
===
match
---
string: 'conf' [64381,64387]
string: 'conf' [64515,64521]
===
match
---
name: State [25340,25345]
name: State [25340,25345]
===
match
---
expr_stmt [31846,31859]
expr_stmt [31846,31859]
===
match
---
name: REQUEUEABLE_DEPS [38156,38172]
name: REQUEUEABLE_DEPS [38156,38172]
===
match
---
classdef [62445,63354]
classdef [62579,63488]
===
match
---
operator: , [15163,15164]
operator: , [15163,15164]
===
match
---
trailer [33230,33242]
trailer [33230,33242]
===
match
---
name: session [4722,4729]
name: session [4722,4729]
===
match
---
suite [51488,51547]
suite [51488,51547]
===
match
---
name: bool [58999,59003]
name: bool [59133,59137]
===
match
---
simple_stmt [26811,26831]
simple_stmt [26811,26831]
===
match
---
simple_stmt [13854,13878]
simple_stmt [13854,13878]
===
match
---
trailer [48666,48672]
trailer [48666,48672]
===
match
---
operator: -> [77825,77827]
operator: -> [77959,77961]
===
match
---
atom_expr [14809,14826]
atom_expr [14809,14826]
===
match
---
operator: , [32062,32063]
operator: , [32062,32063]
===
match
---
atom_expr [80968,80978]
atom_expr [81102,81112]
===
match
---
name: value [13316,13321]
name: value [13316,13321]
===
match
---
trailer [26035,26041]
trailer [26035,26041]
===
match
---
arglist [73979,74173]
arglist [74113,74307]
===
match
---
fstring_end: " [32981,32982]
fstring_end: " [32981,32982]
===
match
---
name: self [63003,63007]
name: self [63137,63141]
===
match
---
name: t [78723,78724]
name: t [78857,78858]
===
match
---
operator: , [45708,45709]
operator: , [45708,45709]
===
match
---
suite [52126,52232]
suite [52126,52232]
===
match
---
name: provide_session [55008,55023]
name: provide_session [55008,55023]
===
match
---
operator: = [35851,35852]
operator: = [35851,35852]
===
match
---
atom_expr [40379,40395]
atom_expr [40379,40395]
===
match
---
arglist [71339,71508]
arglist [71473,71642]
===
match
---
atom_expr [68546,68589]
atom_expr [68680,68723]
===
match
---
simple_stmt [8471,8571]
simple_stmt [8471,8571]
===
match
---
operator: = [42674,42675]
operator: = [42674,42675]
===
match
---
name: task_id [78657,78664]
name: task_id [78791,78798]
===
match
---
trailer [78419,78491]
trailer [78553,78625]
===
match
---
string: '%Y%m%dT%H%M%S' [58460,58475]
string: '%Y%m%dT%H%M%S' [58594,58609]
===
match
---
simple_stmt [79570,79600]
simple_stmt [79704,79734]
===
match
---
operator: = [54192,54193]
operator: = [54192,54193]
===
match
---
simple_stmt [61616,61638]
simple_stmt [61750,61772]
===
match
---
name: AirflowTaskTimeout [1806,1824]
name: AirflowTaskTimeout [1806,1824]
===
match
---
parameters [13916,13922]
parameters [13916,13922]
===
match
---
operator: = [14581,14582]
operator: = [14581,14582]
===
match
---
name: dag_id [58262,58268]
name: dag_id [58396,58402]
===
match
---
trailer [43706,43713]
trailer [43706,43713]
===
match
---
name: _pool [80082,80087]
name: _pool [80216,80221]
===
match
---
name: task [25931,25935]
name: task [25931,25935]
===
match
---
name: format [73890,73896]
name: format [74024,74030]
===
match
---
and_test [14629,14650]
and_test [14629,14650]
===
match
---
atom_expr [23402,23428]
atom_expr [23402,23428]
===
match
---
trailer [45327,45342]
trailer [45327,45342]
===
match
---
trailer [11707,11712]
trailer [11707,11712]
===
match
---
suite [3969,4248]
suite [3969,4248]
===
match
---
and_test [27709,27752]
and_test [27709,27752]
===
match
---
operator: = [68305,68306]
operator: = [68439,68440]
===
match
---
arith_expr [34065,34100]
arith_expr [34065,34100]
===
match
---
operator: = [71492,71493]
operator: = [71626,71627]
===
match
---
if_stmt [67192,67469]
if_stmt [67326,67603]
===
match
---
operator: , [18145,18146]
operator: , [18145,18146]
===
match
---
tfpdef [59021,59037]
tfpdef [59155,59171]
===
match
---
name: dep_status [31748,31758]
name: dep_status [31748,31758]
===
match
---
name: next_ds_nodash [64711,64725]
name: next_ds_nodash [64845,64859]
===
match
---
testlist_comp [49249,49300]
testlist_comp [49249,49300]
===
match
---
operator: - [8565,8566]
operator: - [8565,8566]
===
match
---
decorators [45618,45661]
decorators [45618,45661]
===
match
---
name: __file__ [70866,70874]
name: __file__ [71000,71008]
===
match
---
testlist_comp [18641,18655]
testlist_comp [18641,18655]
===
match
---
name: airflow [7531,7538]
name: airflow [7531,7538]
===
match
---
simple_stmt [51812,51826]
simple_stmt [51812,51826]
===
match
---
name: error [20855,20860]
name: error [20855,20860]
===
match
---
atom_expr [15013,15032]
atom_expr [15013,15032]
===
match
---
atom_expr [56875,56887]
atom_expr [57009,57021]
===
match
---
atom_expr [67772,67799]
atom_expr [67906,67933]
===
match
---
name: __init__ [79528,79536]
name: __init__ [79662,79670]
===
match
---
atom_expr [54982,55001]
atom_expr [54982,55001]
===
match
---
trailer [44216,44231]
trailer [44216,44231]
===
match
---
name: self [56889,56893]
name: self [57023,57027]
===
match
---
name: jinja_context [71218,71231]
name: jinja_context [71352,71365]
===
match
---
name: all [7831,7834]
name: all [7831,7834]
===
match
---
simple_stmt [28639,28779]
simple_stmt [28639,28779]
===
match
---
name: DepContext [2292,2302]
name: DepContext [2292,2302]
===
match
---
name: Optional [56085,56093]
name: Optional [56085,56093]
===
match
---
simple_stmt [52826,52843]
simple_stmt [52826,52843]
===
match
---
tfpdef [15579,15591]
tfpdef [15579,15591]
===
match
---
name: datetime [80638,80646]
name: datetime [80772,80780]
===
match
---
name: context [3595,3602]
name: context [3595,3602]
===
match
---
trailer [49247,49302]
trailer [49247,49302]
===
match
---
simple_stmt [50361,50409]
simple_stmt [50361,50409]
===
match
---
dotted_name [1974,2003]
dotted_name [1974,2003]
===
match
---
name: dag_run [82499,82506]
name: dag_run [82633,82640]
===
match
---
operator: { [19090,19091]
operator: { [19090,19091]
===
match
---
name: str [62999,63002]
name: str [63133,63136]
===
match
---
string: """Return Number of running TIs from the DB""" [77229,77275]
string: """Return Number of running TIs from the DB""" [77363,77409]
===
match
---
name: task_id [45204,45211]
name: task_id [45204,45211]
===
match
---
operator: , [80176,80177]
operator: , [80310,80311]
===
match
---
trailer [7428,7432]
trailer [7428,7432]
===
match
---
name: start_date [72650,72660]
name: start_date [72784,72794]
===
match
---
operator: , [71358,71359]
operator: , [71492,71493]
===
match
---
operator: , [78626,78627]
operator: , [78760,78761]
===
match
---
operator: , [1065,1066]
operator: , [1065,1066]
===
match
---
trailer [33586,33600]
trailer [33586,33600]
===
match
---
tfpdef [35832,35850]
tfpdef [35832,35850]
===
match
---
name: lock_for_update [43070,43085]
name: lock_for_update [43070,43085]
===
match
---
name: rendered_value [66286,66300]
name: rendered_value [66420,66434]
===
match
---
operator: , [24330,24331]
operator: , [24330,24331]
===
match
---
trailer [81915,81923]
trailer [82049,82057]
===
match
---
simple_stmt [40502,40582]
simple_stmt [40502,40582]
===
match
---
name: ti [7769,7771]
name: ti [7769,7771]
===
match
---
param [66966,66970]
param [67100,67104]
===
match
---
atom_expr [14987,14999]
atom_expr [14987,14999]
===
match
---
atom_expr [40887,40903]
atom_expr [40887,40903]
===
match
---
name: self [58308,58312]
name: self [58442,58446]
===
match
---
name: _update_ti_state_for_sensing [50653,50681]
name: _update_ti_state_for_sensing [50653,50681]
===
match
---
trailer [77789,77822]
trailer [77923,77956]
===
match
---
name: task_id [80451,80458]
name: task_id [80585,80592]
===
match
---
operator: = [38473,38474]
operator: = [38473,38474]
===
match
---
name: TaskInstance [14919,14931]
name: TaskInstance [14919,14931]
===
match
---
operator: , [35929,35930]
operator: , [35929,35930]
===
match
---
name: task_id [77485,77492]
name: task_id [77619,77626]
===
match
---
operator: * [33603,33604]
operator: * [33603,33604]
===
match
---
argument [54135,54148]
argument [54135,54148]
===
match
---
name: self [68273,68277]
name: self [68407,68411]
===
match
---
atom_expr [5251,5265]
atom_expr [5251,5265]
===
match
---
arglist [11559,11673]
arglist [11559,11673]
===
match
---
test [31691,31735]
test [31691,31735]
===
match
---
atom_expr [12148,12161]
atom_expr [12148,12161]
===
match
---
trailer [58998,59004]
trailer [59132,59138]
===
match
---
operator: = [30192,30193]
operator: = [30192,30193]
===
match
---
operator: , [74077,74078]
operator: , [74211,74212]
===
match
---
trailer [55346,55350]
trailer [55346,55350]
===
match
---
atom_expr [44630,44686]
atom_expr [44630,44686]
===
match
---
simple_stmt [50853,50873]
simple_stmt [50853,50873]
===
match
---
atom_expr [61204,61223]
atom_expr [61338,61357]
===
match
---
trailer [62194,62202]
trailer [62328,62336]
===
match
---
name: Tuple [8159,8164]
name: Tuple [8159,8164]
===
match
---
trailer [19256,19266]
trailer [19256,19266]
===
match
---
operator: , [49112,49113]
operator: , [49112,49113]
===
match
---
string: 'Log file: {{ti.log_filepath}}<br>' [70153,70188]
string: 'Log file: {{ti.log_filepath}}<br>' [70287,70322]
===
match
---
atom_expr [56731,56786]
atom_expr [56865,56920]
===
match
---
trailer [22583,22594]
trailer [22583,22594]
===
match
---
name: self [60229,60233]
name: self [60363,60367]
===
match
---
operator: @ [28558,28559]
operator: @ [28558,28559]
===
match
---
name: state [24416,24421]
name: state [24416,24421]
===
match
---
operator: = [76330,76331]
operator: = [76464,76465]
===
match
---
name: reconstructor [12468,12481]
name: reconstructor [12468,12481]
===
match
---
trailer [62014,62022]
trailer [62148,62156]
===
match
---
atom_expr [31873,32077]
atom_expr [31873,32077]
===
match
---
atom_expr [9747,9760]
atom_expr [9747,9760]
===
match
---
name: Column [9968,9974]
name: Column [9968,9974]
===
match
---
operator: == [77477,77479]
operator: == [77611,77613]
===
match
---
operator: = [11148,11149]
operator: = [11148,11149]
===
match
---
atom_expr [20302,20321]
atom_expr [20302,20321]
===
match
---
trailer [40782,40789]
trailer [40782,40789]
===
match
---
name: task [11241,11245]
name: task [11241,11245]
===
match
---
name: airflow [1833,1840]
name: airflow [1833,1840]
===
match
---
simple_stmt [52139,52196]
simple_stmt [52139,52196]
===
match
---
operator: = [14292,14293]
operator: = [14292,14293]
===
match
---
trailer [53017,53023]
trailer [53017,53023]
===
match
---
operator: = [7209,7210]
operator: = [7209,7210]
===
match
---
trailer [50860,50866]
trailer [50860,50866]
===
match
---
name: self [41598,41602]
name: self [41598,41602]
===
match
---
operator: = [60121,60122]
operator: = [60255,60256]
===
match
---
name: str [80395,80398]
name: str [80529,80532]
===
match
---
operator: = [54111,54112]
operator: = [54111,54112]
===
match
---
name: path [14734,14738]
name: path [14734,14738]
===
match
---
name: task [11267,11271]
name: task [11267,11271]
===
match
---
parameters [77769,77824]
parameters [77903,77958]
===
match
---
name: BooleanClauseList [1543,1560]
name: BooleanClauseList [1543,1560]
===
match
---
trailer [29519,29557]
trailer [29519,29557]
===
match
---
name: content [71800,71807]
name: content [71934,71941]
===
match
---
trailer [33575,33580]
trailer [33575,33580]
===
match
---
operator: = [28038,28039]
operator: = [28038,28039]
===
match
---
name: deps [32422,32426]
name: deps [32422,32426]
===
match
---
simple_stmt [40688,40726]
simple_stmt [40688,40726]
===
match
---
trailer [62273,62280]
trailer [62407,62414]
===
match
---
import_from [2672,2721]
import_from [2672,2721]
===
match
---
name: first [39128,39133]
name: first [39128,39133]
===
match
---
trailer [52700,52713]
trailer [52700,52713]
===
match
---
import_from [916,951]
import_from [916,951]
===
match
---
simple_stmt [69885,70274]
simple_stmt [70019,70408]
===
match
---
name: VariableAccessor [65801,65817]
name: VariableAccessor [65935,65951]
===
match
---
suite [4775,7953]
suite [4775,7953]
===
match
---
name: task_id [48709,48716]
name: task_id [48709,48716]
===
match
---
name: self [19462,19466]
name: self [19462,19466]
===
match
---
atom_expr [20972,20988]
atom_expr [20972,20988]
===
match
---
name: XCom [24016,24020]
name: XCom [24016,24020]
===
match
---
operator: , [45262,45263]
operator: , [45262,45263]
===
match
---
name: replace [61884,61891]
name: replace [62018,62025]
===
match
---
trailer [67778,67785]
trailer [67912,67919]
===
match
---
name: task [59734,59738]
name: task [59868,59872]
===
match
---
arglist [78534,78693]
arglist [78668,78827]
===
match
---
simple_stmt [22975,23250]
simple_stmt [22975,23250]
===
match
---
suite [80558,80595]
suite [80692,80729]
===
match
---
trailer [73961,73965]
trailer [74095,74099]
===
match
---
trailer [41697,41702]
trailer [41697,41702]
===
match
---
operator: = [12602,12603]
operator: = [12602,12603]
===
match
---
trailer [57663,57665]
trailer [57797,57799]
===
match
---
suite [72228,72549]
suite [72362,72683]
===
match
---
if_stmt [79991,80069]
if_stmt [80125,80203]
===
match
---
name: timezone [11757,11765]
name: timezone [11757,11765]
===
match
---
name: previous_schedule [61186,61203]
name: previous_schedule [61320,61337]
===
match
---
trailer [79369,79391]
trailer [79503,79525]
===
match
---
argument [53912,53957]
argument [53912,53957]
===
match
---
expr_stmt [57748,57816]
expr_stmt [57882,57950]
===
match
---
simple_stmt [77108,77144]
simple_stmt [77242,77278]
===
match
---
trailer [61925,61940]
trailer [62059,62074]
===
match
---
import_from [2125,2185]
import_from [2125,2185]
===
match
---
number: 1 [13230,13231]
number: 1 [13230,13231]
===
match
---
name: ignore_depends_on_past [38288,38310]
name: ignore_depends_on_past [38288,38310]
===
match
---
simple_stmt [53197,53226]
simple_stmt [53197,53226]
===
match
---
trailer [72695,72704]
trailer [72829,72838]
===
match
---
trailer [6882,6886]
trailer [6882,6886]
===
match
---
expr_stmt [59895,59909]
expr_stmt [60029,60043]
===
match
---
string: """Is task instance is eligible for retry""" [59280,59324]
string: """Is task instance is eligible for retry""" [59414,59458]
===
match
---
name: str [80274,80277]
name: str [80408,80411]
===
match
---
suite [72585,72852]
suite [72719,72986]
===
match
---
simple_stmt [30784,30841]
simple_stmt [30784,30841]
===
match
---
trailer [4446,4457]
trailer [4446,4457]
===
match
---
if_stmt [38412,38610]
if_stmt [38412,38610]
===
match
---
name: DeprecationWarning [30720,30738]
name: DeprecationWarning [30720,30738]
===
match
---
trailer [26156,26164]
trailer [26156,26164]
===
match
---
name: ignore_depends_on_past [38311,38333]
name: ignore_depends_on_past [38311,38333]
===
match
---
name: self [46144,46148]
name: self [46144,46148]
===
match
---
atom_expr [8291,8310]
atom_expr [8291,8310]
===
match
---
trailer [68324,68331]
trailer [68458,68465]
===
match
---
name: str [74322,74325]
name: str [74456,74459]
===
match
---
trailer [44887,44943]
trailer [44887,44943]
===
match
---
name: ignore_all_deps [53883,53898]
name: ignore_all_deps [53883,53898]
===
match
---
atom_expr [25010,25023]
atom_expr [25010,25023]
===
match
---
name: _task_id [79613,79621]
name: _task_id [79747,79755]
===
match
---
name: load_error_file [3903,3918]
name: load_error_file [3903,3918]
===
match
---
name: pod_template_file [68767,68784]
name: pod_template_file [68901,68918]
===
match
---
name: execution_date [78910,78924]
name: execution_date [79044,79058]
===
match
---
atom_expr [6872,6896]
atom_expr [6872,6896]
===
match
---
operator: , [15895,15896]
operator: , [15895,15896]
===
match
---
name: TemplateAssertionError [1236,1258]
name: TemplateAssertionError [1236,1258]
===
match
---
trailer [64131,64162]
trailer [64265,64296]
===
match
---
argument [46085,46103]
argument [46085,46103]
===
match
---
comparison [81854,81889]
comparison [81988,82023]
===
match
---
atom_expr [33221,33242]
atom_expr [33221,33242]
===
match
---
atom_expr [11983,12002]
atom_expr [11983,12002]
===
match
---
name: provide_session [29702,29717]
name: provide_session [29702,29717]
===
match
---
name: mark_success [18032,18044]
name: mark_success [18032,18044]
===
match
---
param [55057,55075]
param [55057,55075]
===
match
---
name: execution_date [18969,18983]
name: execution_date [18969,18983]
===
match
---
atom_expr [42554,42568]
atom_expr [42554,42568]
===
match
---
simple_stmt [60418,60464]
simple_stmt [60552,60598]
===
match
---
and_test [72627,72660]
and_test [72761,72794]
===
match
---
name: jinja2 [70826,70832]
name: jinja2 [70960,70966]
===
match
---
suite [21807,21855]
suite [21807,21855]
===
match
---
string: "Marking task as UP_FOR_RETRY." [58027,58058]
string: "Marking task as UP_FOR_RETRY." [58161,58192]
===
match
---
name: ti [79736,79738]
name: ti [79870,79872]
===
match
---
operator: = [15995,15996]
operator: = [15995,15996]
===
match
---
tfpdef [79543,79559]
tfpdef [79677,79693]
===
match
---
name: get [63827,63830]
name: get [63961,63964]
===
match
---
name: pool_override [42618,42631]
name: pool_override [42618,42631]
===
match
---
operator: = [61819,61820]
operator: = [61953,61954]
===
match
---
name: ti [22797,22799]
name: ti [22797,22799]
===
match
---
name: context [49445,49452]
name: context [49445,49452]
===
match
---
name: property [80917,80925]
name: property [81051,81059]
===
match
---
atom_expr [50787,50800]
atom_expr [50787,50800]
===
match
---
atom_expr [41230,41297]
atom_expr [41230,41297]
===
match
---
name: dag_id [79593,79599]
name: dag_id [79727,79733]
===
match
---
name: self [40242,40246]
name: self [40242,40246]
===
match
---
name: tis [7797,7800]
name: tis [7797,7800]
===
match
---
name: operator_helpers [2624,2640]
name: operator_helpers [2624,2640]
===
match
---
expr_stmt [71976,72044]
expr_stmt [72110,72178]
===
match
---
name: Optional [81027,81035]
name: Optional [81161,81169]
===
match
---
expr_stmt [61593,61607]
expr_stmt [61727,61741]
===
match
---
expr_stmt [39192,39236]
expr_stmt [39192,39236]
===
match
---
arglist [47318,47340]
arglist [47318,47340]
===
match
---
if_stmt [39749,40425]
if_stmt [39749,40425]
===
match
---
name: Stats [37742,37747]
name: Stats [37742,37747]
===
match
---
trailer [49348,49370]
trailer [49348,49370]
===
match
---
trailer [35373,35380]
trailer [35373,35380]
===
match
---
trailer [68176,68178]
trailer [68310,68312]
===
match
---
operator: } [19127,19128]
operator: } [19127,19128]
===
match
---
expr_stmt [27770,27833]
expr_stmt [27770,27833]
===
match
---
simple_stmt [12439,12462]
simple_stmt [12439,12462]
===
match
---
operator: = [51440,51441]
operator: = [51440,51441]
===
match
---
name: mark_success [37927,37939]
name: mark_success [37927,37939]
===
match
---
operator: , [21653,21654]
operator: , [21653,21654]
===
match
---
name: set_error_file [56593,56607]
name: set_error_file [56727,56741]
===
match
---
funcdef [80699,80761]
funcdef [80833,80895]
===
match
---
atom_expr [48625,48647]
atom_expr [48625,48647]
===
match
---
operator: = [9468,9469]
operator: = [9468,9469]
===
match
---
trailer [7432,7434]
trailer [7432,7434]
===
match
---
atom_expr [23934,23945]
atom_expr [23934,23945]
===
match
---
name: orm [1425,1428]
name: orm [1425,1428]
===
match
---
simple_stmt [67251,67298]
simple_stmt [67385,67432]
===
match
---
name: PickleType [10328,10338]
name: PickleType [10328,10338]
===
match
---
name: Column [10283,10289]
name: Column [10283,10289]
===
match
---
simple_stmt [40887,40904]
simple_stmt [40887,40904]
===
match
---
name: log [21502,21505]
name: log [21502,21505]
===
match
---
trailer [50866,50872]
trailer [50866,50872]
===
match
---
suite [52895,53000]
suite [52895,53000]
===
match
---
operator: , [71945,71946]
operator: , [72079,72080]
===
match
---
trailer [9683,9696]
trailer [9683,9696]
===
match
---
operator: = [61355,61356]
operator: = [61489,61490]
===
match
---
name: last_dagrun [27770,27781]
name: last_dagrun [27770,27781]
===
match
---
return_stmt [30210,30266]
return_stmt [30210,30266]
===
match
---
argument [10935,10987]
argument [10935,10987]
===
match
---
simple_stmt [32542,32778]
simple_stmt [32542,32778]
===
match
---
operator: , [33830,33831]
operator: , [33830,33831]
===
match
---
name: XCom [76835,76839]
name: XCom [76969,76973]
===
match
---
operator: = [14096,14097]
operator: = [14096,14097]
===
match
---
atom_expr [61921,61966]
atom_expr [62055,62100]
===
match
---
not_test [67195,67216]
not_test [67329,67350]
===
match
---
string: 'dag' [59935,59940]
string: 'dag' [60069,60074]
===
match
---
except_clause [72464,72480]
except_clause [72598,72614]
===
match
---
operator: = [53654,53655]
operator: = [53654,53655]
===
match
---
and_test [7491,7516]
and_test [7491,7516]
===
match
---
operator: , [59933,59934]
operator: , [60067,60068]
===
match
---
arglist [70819,70893]
arglist [70953,71027]
===
match
---
string: 'ti_state' [10687,10697]
string: 'ti_state' [10687,10697]
===
match
---
trailer [52517,52523]
trailer [52517,52523]
===
match
---
name: params [67552,67558]
name: params [67686,67692]
===
match
---
trailer [55350,55621]
trailer [55350,55621]
===
match
---
name: base_url [19278,19286]
name: base_url [19278,19286]
===
match
---
atom_expr [30327,30354]
atom_expr [30327,30354]
===
match
---
name: file_path [15905,15914]
name: file_path [15905,15914]
===
match
---
atom_expr [45276,45309]
atom_expr [45276,45309]
===
match
---
name: and_ [78512,78516]
name: and_ [78646,78650]
===
match
---
name: property [28559,28567]
name: property [28559,28567]
===
match
---
operator: = [74065,74066]
operator: = [74199,74200]
===
match
---
string: '%Y-%m-%d' [61721,61731]
string: '%Y-%m-%d' [61855,61865]
===
match
---
trailer [62403,62435]
trailer [62537,62569]
===
match
---
arglist [10792,10831]
arglist [10792,10831]
===
match
---
name: iso [19225,19228]
name: iso [19225,19228]
===
match
---
trailer [77363,77365]
trailer [77497,77499]
===
match
---
parameters [24174,24180]
parameters [24174,24180]
===
match
---
operator: = [39655,39656]
operator: = [39655,39656]
===
match
---
operator: = [32281,32282]
operator: = [32281,32282]
===
match
---
if_stmt [53088,53274]
if_stmt [53088,53274]
===
match
---
operator: , [59479,59480]
operator: , [59613,59614]
===
match
---
name: first_task_id [78188,78201]
name: first_task_id [78322,78335]
===
match
---
trailer [23262,23268]
trailer [23262,23268]
===
match
---
atom_expr [37581,37592]
atom_expr [37581,37592]
===
match
---
operator: , [10859,10860]
operator: , [10859,10860]
===
match
---
atom_expr [15916,15929]
atom_expr [15916,15929]
===
match
---
annassign [79862,79878]
annassign [79996,80012]
===
match
---
trailer [60365,60377]
trailer [60499,60511]
===
match
---
trailer [76758,76776]
trailer [76892,76910]
===
match
---
trailer [38118,38399]
trailer [38118,38399]
===
match
---
operator: , [59144,59145]
operator: , [59278,59279]
===
match
---
name: error [58581,58586]
name: error [58715,58720]
===
match
---
operator: , [73027,73028]
operator: , [73161,73162]
===
match
---
operator: == [81874,81876]
operator: == [82008,82010]
===
match
---
operator: = [39831,39832]
operator: = [39831,39832]
===
match
---
tfpdef [15946,15955]
tfpdef [15946,15955]
===
match
---
name: __getattr__ [62788,62799]
name: __getattr__ [62922,62933]
===
match
---
lambdef [5094,5139]
lambdef [5094,5139]
===
match
---
simple_stmt [5549,5597]
simple_stmt [5549,5597]
===
match
---
name: conf [71711,71715]
name: conf [71845,71849]
===
match
---
name: log [49882,49885]
name: log [49882,49885]
===
match
---
trailer [44197,44199]
trailer [44197,44199]
===
match
---
name: execution_date [21753,21767]
name: execution_date [21753,21767]
===
match
---
trailer [67793,67798]
trailer [67927,67932]
===
match
---
trailer [7921,7932]
trailer [7921,7932]
===
match
---
trailer [59745,59750]
trailer [59879,59884]
===
match
---
operator: = [23300,23301]
operator: = [23300,23301]
===
match
---
trailer [34585,34619]
trailer [34585,34619]
===
match
---
trailer [43547,43552]
trailer [43547,43552]
===
match
---
operator: , [1054,1055]
operator: , [1054,1055]
===
match
---
suite [81201,81227]
suite [81335,81361]
===
match
---
name: render_templates [67809,67825]
name: render_templates [67943,67959]
===
match
---
operator: , [32500,32501]
operator: , [32500,32501]
===
match
---
trailer [60004,60021]
trailer [60138,60155]
===
match
---
name: Iterable [77775,77783]
name: Iterable [77909,77917]
===
match
---
atom_expr [12175,12194]
atom_expr [12175,12194]
===
match
---
subscriptlist [52292,52306]
subscriptlist [52292,52306]
===
match
---
trailer [71719,71733]
trailer [71853,71867]
===
match
---
parameters [8595,8618]
parameters [8595,8618]
===
match
---
atom [18134,18162]
atom [18134,18162]
===
match
---
suite [64186,64351]
suite [64320,64485]
===
match
---
param [59021,59046]
param [59155,59180]
===
match
---
operator: , [3849,3850]
operator: , [3849,3850]
===
match
---
name: task [53091,53095]
name: task [53091,53095]
===
match
---
suite [41213,41298]
suite [41213,41298]
===
match
---
operator: == [52524,52526]
operator: == [52524,52526]
===
match
---
atom_expr [19526,19557]
atom_expr [19526,19557]
===
match
---
trailer [78724,78731]
trailer [78858,78865]
===
match
---
import_from [59759,59785]
import_from [59893,59919]
===
match
---
trailer [72368,72379]
trailer [72502,72513]
===
match
---
simple_stmt [11324,11370]
simple_stmt [11324,11370]
===
match
---
name: task_copy [54870,54879]
name: task_copy [54870,54879]
===
match
---
atom_expr [19115,19127]
atom_expr [19115,19127]
===
match
---
expr_stmt [5334,5354]
expr_stmt [5334,5354]
===
match
---
simple_stmt [68152,68179]
simple_stmt [68286,68313]
===
match
---
atom_expr [71653,71682]
atom_expr [71787,71816]
===
match
---
trailer [6116,6124]
trailer [6116,6124]
===
match
---
param [74476,74500]
param [74610,74634]
===
match
---
simple_stmt [3624,3664]
simple_stmt [3624,3664]
===
match
---
string: """Fetch rendered template fields from DB""" [66981,67025]
string: """Fetch rendered template fields from DB""" [67115,67159]
===
match
---
trailer [62022,62031]
trailer [62156,62165]
===
match
---
operator: = [38106,38107]
operator: = [38106,38107]
===
match
---
if_stmt [45534,45613]
if_stmt [45534,45613]
===
match
---
funcdef [12666,13232]
funcdef [12666,13232]
===
match
---
suite [76697,76998]
suite [76831,77132]
===
match
---
operator: @ [3287,3288]
operator: @ [3287,3288]
===
match
---
atom_expr [21993,22006]
atom_expr [21993,22006]
===
match
---
param [51056,51061]
param [51056,51061]
===
match
---
and_test [5370,5399]
and_test [5370,5399]
===
match
---
trailer [42558,42568]
trailer [42558,42568]
===
match
---
operator: , [44805,44806]
operator: , [44805,44806]
===
match
---
trailer [58725,58731]
trailer [58859,58865]
===
match
---
trailer [69269,69277]
trailer [69403,69411]
===
match
---
name: sentry [2199,2205]
name: sentry [2199,2205]
===
match
---
name: context [68047,68054]
name: context [68181,68188]
===
match
---
name: mark_success [53563,53575]
name: mark_success [53563,53575]
===
match
---
expr_stmt [70920,70992]
expr_stmt [71054,71126]
===
match
---
trailer [21505,21511]
trailer [21505,21511]
===
match
---
atom_expr [43104,43114]
atom_expr [43104,43114]
===
match
---
operator: , [47588,47589]
operator: , [47588,47589]
===
match
---
simple_stmt [44028,44104]
simple_stmt [44028,44104]
===
match
---
decorated [29701,30267]
decorated [29701,30267]
===
match
---
operator: + [34753,34754]
operator: + [34753,34754]
===
match
---
name: log [22862,22865]
name: log [22862,22865]
===
match
---
name: self [28017,28021]
name: self [28017,28021]
===
match
---
operator: , [48958,48959]
operator: , [48958,48959]
===
match
---
name: get_dagrun [35049,35059]
name: get_dagrun [35049,35059]
===
match
---
atom_expr [4022,4045]
atom_expr [4022,4045]
===
match
---
simple_stmt [68805,68837]
simple_stmt [68939,68971]
===
match
---
name: ti [6065,6067]
name: ti [6065,6067]
===
match
---
name: self [54782,54786]
name: self [54782,54786]
===
match
---
operator: = [42704,42705]
operator: = [42704,42705]
===
match
---
name: exec2 [58768,58773]
name: exec2 [58902,58907]
===
match
---
suite [13159,13196]
suite [13159,13196]
===
match
---
name: try_number [13238,13248]
name: try_number [13238,13248]
===
match
---
name: bool [35998,36002]
name: bool [35998,36002]
===
match
---
suite [78787,79009]
suite [78921,79143]
===
match
---
parameters [64008,64185]
parameters [64142,64319]
===
match
---
name: from_obj [68559,68567]
name: from_obj [68693,68701]
===
match
---
atom_expr [49238,49302]
atom_expr [49238,49302]
===
match
---
name: test_mode [54421,54430]
name: test_mode [54421,54430]
===
match
---
suite [7989,8799]
suite [7989,8799]
===
match
---
name: TaskInstance [20251,20263]
name: TaskInstance [20251,20263]
===
match
---
operator: = [15779,15780]
operator: = [15779,15780]
===
match
---
name: commit [24095,24101]
name: commit [24095,24101]
===
match
---
operator: == [81924,81926]
operator: == [82058,82060]
===
match
---
operator: = [5056,5057]
operator: = [5056,5057]
===
match
---
expr_stmt [12587,12609]
expr_stmt [12587,12609]
===
match
---
suite [33290,34724]
suite [33290,34724]
===
match
---
name: task_id [32935,32942]
name: task_id [32935,32942]
===
match
---
name: session [77211,77218]
name: session [77345,77352]
===
match
---
tfpdef [74476,74492]
tfpdef [74610,74626]
===
match
---
suite [66542,66935]
suite [66676,67069]
===
match
---
simple_stmt [76970,76998]
simple_stmt [77104,77132]
===
match
---
name: self [72837,72841]
name: self [72971,72975]
===
match
---
arglist [29597,29625]
arglist [29597,29625]
===
match
---
trailer [33836,33851]
trailer [33836,33851]
===
match
---
name: Tuple [1105,1110]
name: Tuple [1105,1110]
===
match
---
name: merge [25075,25080]
name: merge [25075,25080]
===
match
---
trailer [10586,10617]
trailer [10586,10617]
===
match
---
operator: , [19309,19310]
operator: , [19309,19310]
===
match
---
simple_stmt [60358,60380]
simple_stmt [60492,60514]
===
match
---
operator: , [2118,2119]
operator: , [2118,2119]
===
match
---
atom_expr [9773,9791]
atom_expr [9773,9791]
===
match
---
argument [68265,68285]
argument [68399,68419]
===
match
---
comparison [77456,77492]
comparison [77590,77626]
===
match
---
fstring_string: Unable to render a k8s spec for this taskinstance:  [67405,67456]
fstring_string: Unable to render a k8s spec for this taskinstance:  [67539,67590]
===
match
---
suite [18798,18848]
suite [18798,18848]
===
match
---
atom_expr [82534,82560]
atom_expr [82668,82694]
===
match
---
trailer [11172,11181]
trailer [11172,11181]
===
match
---
name: deps [39488,39492]
name: deps [39488,39492]
===
match
---
name: in_ [78904,78907]
name: in_ [79038,79041]
===
match
---
decorated [25092,25390]
decorated [25092,25390]
===
match
---
trailer [48926,48945]
trailer [48926,48945]
===
match
---
suite [32444,32858]
suite [32444,32858]
===
match
---
operator: , [11016,11017]
operator: , [11016,11017]
===
match
---
atom [7607,7846]
atom [7607,7846]
===
match
---
string: 'json' [65744,65750]
string: 'json' [65878,65884]
===
match
---
name: dag [27353,27356]
name: dag [27353,27356]
===
match
---
atom_expr [10328,10352]
atom_expr [10328,10352]
===
match
---
operator: = [68658,68659]
operator: = [68792,68793]
===
match
---
trailer [47871,47881]
trailer [47871,47881]
===
match
---
name: get [64293,64296]
name: get [64427,64430]
===
match
---
simple_stmt [14912,15467]
simple_stmt [14912,15467]
===
match
---
funcdef [81246,81310]
funcdef [81380,81444]
===
match
---
trailer [81221,81226]
trailer [81355,81360]
===
match
---
operator: = [15446,15447]
operator: = [15446,15447]
===
match
---
name: try_number [12034,12044]
name: try_number [12034,12044]
===
match
---
atom_expr [54919,54928]
atom_expr [54919,54928]
===
match
---
simple_stmt [43500,43527]
simple_stmt [43500,43527]
===
match
---
name: XCom [23934,23938]
name: XCom [23934,23938]
===
match
---
operator: = [79783,79784]
operator: = [79917,79918]
===
match
---
name: Exception [4473,4482]
name: Exception [4473,4482]
===
match
---
simple_stmt [51754,51804]
simple_stmt [51754,51804]
===
match
---
trailer [61562,61583]
trailer [61696,61717]
===
match
---
name: should_pass_filepath [14606,14626]
name: should_pass_filepath [14606,14626]
===
match
---
simple_stmt [60113,60289]
simple_stmt [60247,60423]
===
match
---
operator: , [53428,53429]
operator: , [53428,53429]
===
match
---
name: end_date [72632,72640]
name: end_date [72766,72774]
===
match
---
trailer [7701,7708]
trailer [7701,7708]
===
match
---
name: values_ordered_by_id [76977,76997]
name: values_ordered_by_id [77111,77131]
===
match
---
operator: = [24780,24781]
operator: = [24780,24781]
===
match
---
param [59627,59632]
param [59761,59766]
===
match
---
trailer [60617,60632]
trailer [60751,60766]
===
match
---
operator: } [47881,47882]
operator: } [47881,47882]
===
match
---
expr_stmt [71800,71818]
expr_stmt [71934,71952]
===
match
---
name: session [37534,37541]
name: session [37534,37541]
===
match
---
import_from [82350,82389]
import_from [82484,82523]
===
match
---
operator: = [34684,34685]
operator: = [34684,34685]
===
match
---
trailer [42957,42959]
trailer [42957,42959]
===
match
---
trailer [48945,48972]
trailer [48945,48972]
===
match
---
trailer [33616,33627]
trailer [33616,33627]
===
match
---
suite [57666,57943]
suite [57800,58077]
===
match
---
trailer [45486,45492]
trailer [45486,45492]
===
match
---
if_stmt [51692,51804]
if_stmt [51692,51804]
===
match
---
name: item [63831,63835]
name: item [63965,63969]
===
match
---
name: local [14244,14249]
name: local [14244,14249]
===
match
---
fstring_string: . [42842,42843]
fstring_string: . [42842,42843]
===
match
---
name: provide_session [77150,77165]
name: provide_session [77284,77299]
===
match
---
name: dag [46560,46563]
name: dag [46560,46563]
===
match
---
trailer [22103,22109]
trailer [22103,22109]
===
match
---
suite [5400,5597]
suite [5400,5597]
===
match
---
operator: , [20650,20651]
operator: , [20650,20651]
===
match
---
simple_stmt [18123,18164]
simple_stmt [18123,18164]
===
match
---
name: TaskInstance [78956,78968]
name: TaskInstance [79090,79102]
===
match
---
operator: , [68973,68974]
operator: , [69107,69108]
===
match
---
expr_stmt [59831,59842]
expr_stmt [59965,59976]
===
match
---
trailer [10395,10421]
trailer [10395,10421]
===
match
---
atom_expr [5240,5248]
atom_expr [5240,5248]
===
match
---
operator: , [31968,31969]
operator: , [31968,31969]
===
match
---
number: 1 [60565,60566]
number: 1 [60699,60700]
===
match
---
return_stmt [13204,13231]
return_stmt [13204,13231]
===
match
---
strings [45050,45160]
strings [45050,45160]
===
match
---
param [55051,55056]
param [55051,55056]
===
match
---
return_stmt [8471,8570]
return_stmt [8471,8570]
===
match
---
trailer [76231,76240]
trailer [76365,76374]
===
match
---
name: first [78121,78126]
name: first [78255,78260]
===
match
---
name: state [20604,20609]
name: state [20604,20609]
===
match
---
name: get_hostname [37626,37638]
name: get_hostname [37626,37638]
===
match
---
operator: , [65326,65327]
operator: , [65460,65461]
===
match
---
name: dag_id [35403,35409]
name: dag_id [35403,35409]
===
match
---
trailer [68872,68899]
trailer [69006,69033]
===
match
---
name: context [67967,67974]
name: context [68101,68108]
===
match
---
simple_stmt [10164,10196]
simple_stmt [10164,10196]
===
match
---
name: session [40688,40695]
name: session [40688,40695]
===
match
---
name: airflow [2830,2837]
name: airflow [2830,2837]
===
match
---
expr_stmt [19514,19558]
expr_stmt [19514,19558]
===
match
---
name: TaskInstance [82486,82498]
name: TaskInstance [82620,82632]
===
match
---
name: merge [20952,20957]
name: merge [20952,20957]
===
match
---
atom_expr [76912,76932]
atom_expr [77046,77066]
===
match
---
decorator [20994,21011]
decorator [20994,21011]
===
match
---
atom_expr [70659,70674]
atom_expr [70793,70808]
===
match
---
operator: , [10609,10610]
operator: , [10609,10610]
===
match
---
name: session [20944,20951]
name: session [20944,20951]
===
match
---
number: 2 [30763,30764]
number: 2 [30763,30764]
===
match
---
name: signal_handler [48536,48550]
name: signal_handler [48536,48550]
===
match
---
suite [53734,54765]
suite [53734,54765]
===
match
---
trailer [55887,55889]
trailer [55887,55889]
===
match
---
name: Stats [56795,56800]
name: Stats [56929,56934]
===
match
---
funcdef [11076,12462]
funcdef [11076,12462]
===
match
---
string: "Failed to load task run error" [4216,4247]
string: "Failed to load task run error" [4216,4247]
===
match
---
decorated [80361,80428]
decorated [80495,80562]
===
match
---
atom [72690,72723]
atom [72824,72857]
===
match
---
simple_stmt [40769,40792]
simple_stmt [40769,40792]
===
match
---
operator: { [7768,7769]
operator: { [7768,7769]
===
match
---
string: "wb" [4397,4401]
string: "wb" [4397,4401]
===
match
---
name: ignore_ti_state [14213,14228]
name: ignore_ti_state [14213,14228]
===
match
---
simple_stmt [12587,12647]
simple_stmt [12587,12647]
===
match
---
trailer [22114,22120]
trailer [22114,22120]
===
match
---
name: start_date [56989,56999]
name: start_date [57123,57133]
===
match
---
simple_stmt [62255,62282]
simple_stmt [62389,62416]
===
match
---
atom_expr [40188,40202]
atom_expr [40188,40202]
===
match
---
suite [18563,18600]
suite [18563,18600]
===
match
---
name: dag_run [46855,46862]
name: dag_run [46855,46862]
===
match
---
operator: = [39492,39493]
operator: = [39492,39493]
===
match
---
expr_stmt [11740,11816]
expr_stmt [11740,11816]
===
match
---
name: exception_html [69238,69252]
name: exception_html [69372,69386]
===
match
---
simple_stmt [7601,7847]
simple_stmt [7601,7847]
===
match
---
trailer [59111,59185]
trailer [59245,59319]
===
match
---
name: self [13179,13183]
name: self [13179,13183]
===
match
---
simple_stmt [40379,40396]
simple_stmt [40379,40396]
===
match
---
name: commit [58850,58856]
name: commit [58984,58990]
===
match
---
expr_stmt [51406,51449]
expr_stmt [51406,51449]
===
match
---
name: non_requeueable_dep_context [38474,38501]
name: non_requeueable_dep_context [38474,38501]
===
match
---
name: setter [13249,13255]
name: setter [13249,13255]
===
match
---
simple_stmt [73957,74184]
simple_stmt [74091,74318]
===
match
---
simple_stmt [65997,66042]
simple_stmt [66131,66176]
===
match
---
operator: , [46629,46630]
operator: , [46629,46630]
===
match
---
simple_stmt [4435,4458]
simple_stmt [4435,4458]
===
match
---
name: self [50867,50871]
name: self [50867,50871]
===
match
---
operator: = [42569,42570]
operator: = [42569,42570]
===
match
---
name: value [74006,74011]
name: value [74140,74145]
===
match
---
name: e [44232,44233]
name: e [44232,44233]
===
match
---
atom_expr [60613,60632]
atom_expr [60747,60766]
===
match
---
simple_stmt [47612,47629]
simple_stmt [47612,47629]
===
match
---
name: default_var [63329,63340]
name: default_var [63463,63474]
===
match
---
trailer [56048,56064]
trailer [56048,56064]
===
match
---
operator: , [71676,71677]
operator: , [71810,71811]
===
match
---
arglist [59464,59485]
arglist [59598,59619]
===
match
---
atom_expr [8542,8569]
atom_expr [8542,8569]
===
match
---
number: 20 [9787,9789]
number: 20 [9787,9789]
===
match
---
trailer [39080,39104]
trailer [39080,39104]
===
match
---
trailer [48227,48232]
trailer [48227,48232]
===
match
---
trailer [55852,55858]
trailer [55852,55858]
===
match
---
name: merge [40351,40356]
name: merge [40351,40356]
===
match
---
simple_stmt [16107,17916]
simple_stmt [16107,17916]
===
match
---
operator: = [22795,22796]
operator: = [22795,22796]
===
match
---
trailer [4659,4664]
trailer [4659,4664]
===
match
---
expr_stmt [42761,42798]
expr_stmt [42761,42798]
===
match
---
name: Session [26516,26523]
name: Session [26516,26523]
===
match
---
arglist [33805,33868]
arglist [33805,33868]
===
match
---
atom_expr [10389,10421]
atom_expr [10389,10421]
===
match
---
comparison [6652,6671]
comparison [6652,6671]
===
match
---
argument [68526,68589]
argument [68660,68723]
===
match
---
arglist [72416,72454]
arglist [72550,72588]
===
match
---
trailer [24069,24076]
trailer [24069,24076]
===
match
---
atom_expr [20846,20901]
atom_expr [20846,20901]
===
match
---
name: session [20237,20244]
name: session [20237,20244]
===
match
---
name: task_id [78210,78217]
name: task_id [78344,78351]
===
match
---
trailer [29509,29513]
trailer [29509,29513]
===
match
---
name: airflow [2420,2427]
name: airflow [2420,2427]
===
match
---
operator: = [23353,23354]
operator: = [23353,23354]
===
match
---
comparison [52785,52812]
comparison [52785,52812]
===
match
---
name: ts [60472,60474]
name: ts [60606,60608]
===
match
---
operator: , [6940,6941]
operator: , [6940,6941]
===
match
---
name: start_date [39226,39236]
name: start_date [39226,39236]
===
match
---
name: _queue [80266,80272]
name: _queue [80400,80406]
===
match
---
dotted_name [2830,2851]
dotted_name [2830,2851]
===
match
---
name: self [62969,62973]
name: self [63103,63107]
===
match
---
fstring_expr [42829,42842]
fstring_expr [42829,42842]
===
match
---
argument [78669,78691]
argument [78803,78825]
===
match
---
string: 'start_date' [43836,43848]
string: 'start_date' [43836,43848]
===
match
---
name: FileSystemLoader [70833,70849]
name: FileSystemLoader [70967,70983]
===
match
---
operator: = [47387,47388]
operator: = [47387,47388]
===
match
---
name: ignore_all_deps [38206,38221]
name: ignore_all_deps [38206,38221]
===
match
---
name: xcom_push [72882,72891]
name: xcom_push [73016,73025]
===
match
---
atom_expr [10786,10832]
atom_expr [10786,10832]
===
match
---
simple_stmt [80567,80595]
simple_stmt [80701,80729]
===
match
---
name: List [1077,1081]
name: List [1077,1081]
===
match
---
funcdef [21015,22907]
funcdef [21015,22907]
===
match
---
operator: = [53507,53508]
operator: = [53507,53508]
===
match
---
name: pid [10277,10280]
name: pid [10277,10280]
===
match
---
trailer [52947,52949]
trailer [52947,52949]
===
match
---
simple_stmt [11287,11316]
simple_stmt [11287,11316]
===
match
---
name: strftime [59544,59552]
name: strftime [59678,59686]
===
match
---
name: external_executor_id [10359,10379]
name: external_executor_id [10359,10379]
===
match
---
atom_expr [4293,4314]
atom_expr [4293,4314]
===
match
---
expr_stmt [80297,80315]
expr_stmt [80431,80449]
===
match
---
param [20646,20651]
param [20646,20651]
===
match
---
name: execution_date [60234,60248]
name: execution_date [60368,60382]
===
match
---
name: state [24754,24759]
name: state [24754,24759]
===
match
---
name: ti [82151,82153]
name: ti [82285,82287]
===
match
---
name: total_seconds [25043,25056]
name: total_seconds [25043,25056]
===
match
---
operator: , [10987,10988]
operator: , [10987,10988]
===
match
---
name: state [40739,40744]
name: state [40739,40744]
===
match
---
name: state [79873,79878]
name: state [80007,80012]
===
match
---
name: _CURRENT_CONTEXT [3214,3230]
name: _CURRENT_CONTEXT [3214,3230]
===
match
---
atom_expr [77427,77438]
atom_expr [77561,77572]
===
match
---
string: "exception" [52701,52712]
string: "exception" [52701,52712]
===
match
---
trailer [20244,20250]
trailer [20244,20250]
===
match
---
trailer [28534,28550]
trailer [28534,28550]
===
match
---
name: pool [54167,54171]
name: pool [54167,54171]
===
match
---
simple_stmt [2991,3064]
simple_stmt [2991,3064]
===
match
---
name: self [20646,20650]
name: self [20646,20650]
===
match
---
trailer [18639,18657]
trailer [18639,18657]
===
match
---
atom_expr [45432,45466]
atom_expr [45432,45466]
===
match
---
simple_stmt [10359,10423]
simple_stmt [10359,10423]
===
match
---
name: SUCCESS [29083,29090]
name: SUCCESS [29083,29090]
===
match
---
operator: = [40778,40779]
operator: = [40778,40779]
===
match
---
name: session [27817,27824]
name: session [27817,27824]
===
match
---
trailer [50051,50055]
trailer [50051,50055]
===
match
---
simple_stmt [42529,42546]
simple_stmt [42529,42546]
===
match
---
name: task_id [5437,5444]
name: task_id [5437,5444]
===
match
---
trailer [21695,21703]
trailer [21695,21703]
===
match
---
name: jinja_context [71882,71895]
name: jinja_context [72016,72029]
===
match
---
suite [8369,8571]
suite [8369,8571]
===
match
---
trailer [26220,26235]
trailer [26220,26235]
===
match
---
name: dag [4763,4766]
name: dag [4763,4766]
===
match
---
string: """Returns TaskInstanceKey with provided ``try_number``""" [8649,8707]
string: """Returns TaskInstanceKey with provided ``try_number``""" [8649,8707]
===
match
---
name: execution_date [11496,11510]
name: execution_date [11496,11510]
===
match
---
atom_expr [34521,34550]
atom_expr [34521,34550]
===
match
---
name: pool [9988,9992]
name: pool [9988,9992]
===
match
---
atom [47152,47227]
atom [47152,47227]
===
match
---
decorator [59581,59598]
decorator [59715,59732]
===
match
---
operator: { [65726,65727]
operator: { [65860,65861]
===
match
---
simple_stmt [70771,70908]
simple_stmt [70905,71042]
===
match
---
name: dag_id [78547,78553]
name: dag_id [78681,78687]
===
match
---
fstring_expr [47869,47882]
fstring_expr [47869,47882]
===
match
---
trailer [11529,11533]
trailer [11529,11533]
===
match
---
operator: = [43481,43482]
operator: = [43481,43482]
===
match
---
operator: , [22944,22945]
operator: , [22944,22945]
===
match
---
name: int [33567,33570]
name: int [33567,33570]
===
match
---
name: self [34972,34976]
name: self [34972,34976]
===
match
---
name: session [42667,42674]
name: session [42667,42674]
===
match
---
operator: = [9771,9772]
operator: = [9771,9772]
===
match
---
operator: , [981,982]
operator: , [981,982]
===
match
---
atom_expr [63952,63960]
atom_expr [64086,64094]
===
match
---
name: convert_to_utc [11943,11957]
name: convert_to_utc [11943,11957]
===
match
---
expr_stmt [53197,53225]
expr_stmt [53197,53225]
===
match
---
name: bool [15734,15738]
name: bool [15734,15738]
===
match
---
name: _queue [81142,81148]
name: _queue [81276,81282]
===
match
---
argument [54018,54049]
argument [54018,54049]
===
match
---
trailer [22419,22428]
trailer [22419,22428]
===
match
---
trailer [24336,24351]
trailer [24336,24351]
===
match
---
param [28596,28600]
param [28596,28600]
===
match
---
argument [15085,15116]
argument [15085,15116]
===
match
---
operator: = [71394,71395]
operator: = [71528,71529]
===
match
---
parameters [41588,41816]
parameters [41588,41816]
===
match
---
name: context [53197,53204]
name: context [53197,53204]
===
match
---
simple_stmt [63681,63697]
simple_stmt [63815,63831]
===
match
---
trailer [72631,72640]
trailer [72765,72774]
===
match
---
operator: , [71461,71462]
operator: , [71595,71596]
===
match
---
param [45710,45722]
param [45710,45722]
===
match
---
simple_stmt [11165,11184]
simple_stmt [11165,11184]
===
match
---
name: signal_handler [48258,48272]
name: signal_handler [48258,48272]
===
match
---
name: self [58828,58832]
name: self [58962,58966]
===
match
---
name: test_mode [55196,55205]
name: test_mode [55196,55205]
===
match
---
name: session [20652,20659]
name: session [20652,20659]
===
match
---
arglist [9629,9658]
arglist [9629,9658]
===
match
---
name: dates [7076,7081]
name: dates [7076,7081]
===
match
---
operator: @ [72857,72858]
operator: @ [72991,72992]
===
match
---
suite [24442,25087]
suite [24442,25087]
===
match
---
name: item [64297,64301]
name: item [64431,64435]
===
match
---
atom_expr [49150,49317]
atom_expr [49150,49317]
===
match
---
atom_expr [61545,61583]
atom_expr [61679,61717]
===
match
---
test [60310,60345]
test [60444,60479]
===
match
---
name: close [54704,54709]
name: close [54704,54709]
===
match
---
trailer [61493,61501]
trailer [61627,61635]
===
match
---
trailer [55911,55967]
trailer [55911,55967]
===
match
---
operator: , [44091,44092]
operator: , [44091,44092]
===
match
---
return_stmt [4092,4103]
return_stmt [4092,4103]
===
match
---
atom_expr [8752,8764]
atom_expr [8752,8764]
===
match
---
name: task [27275,27279]
name: task [27275,27279]
===
match
---
trailer [39760,39781]
trailer [39760,39781]
===
match
---
arglist [5938,5975]
arglist [5938,5975]
===
match
---
param [80459,80463]
param [80593,80597]
===
match
---
atom_expr [29827,29854]
atom_expr [29827,29854]
===
match
---
tfpdef [35901,35922]
tfpdef [35901,35922]
===
match
---
name: error [59228,59233]
name: error [59362,59367]
===
match
---
simple_stmt [34477,34556]
simple_stmt [34477,34556]
===
match
---
name: pool [16011,16015]
name: pool [16011,16015]
===
match
---
simple_stmt [886,900]
simple_stmt [886,900]
===
match
---
expr_stmt [72057,72133]
expr_stmt [72191,72267]
===
match
---
name: _key [81222,81226]
name: _key [81356,81360]
===
match
---
atom_expr [69208,69229]
atom_expr [69342,69363]
===
match
---
name: Integer [9975,9982]
name: Integer [9975,9982]
===
match
---
atom_expr [30084,30132]
atom_expr [30084,30132]
===
match
---
comparison [73703,73739]
comparison [73837,73873]
===
match
---
string: """         Call callback defined for finished state change.          NOTE: Only invoke this function from caller of self._run_raw_task or         self.run         """ [52334,52501]
string: """         Call callback defined for finished state change.          NOTE: Only invoke this function from caller of self._run_raw_task or         self.run         """ [52334,52501]
===
match
---
operator: , [15116,15117]
operator: , [15116,15117]
===
match
---
suite [48323,48497]
suite [48323,48497]
===
match
---
name: self [33254,33258]
name: self [33254,33258]
===
match
---
name: frame [48281,48286]
name: frame [48281,48286]
===
match
---
name: log [11530,11533]
name: log [11530,11533]
===
match
---
trailer [76919,76923]
trailer [77053,77057]
===
match
---
atom_expr [33704,33979]
atom_expr [33704,33979]
===
match
---
operator: = [52920,52921]
operator: = [52920,52921]
===
match
---
trailer [23341,23352]
trailer [23341,23352]
===
match
---
operator: } [32942,32943]
operator: } [32942,32943]
===
match
---
operator: = [69529,69530]
operator: = [69663,69664]
===
match
---
trailer [30528,30533]
trailer [30528,30533]
===
match
---
name: TemplateAssertionError [66497,66519]
name: TemplateAssertionError [66631,66653]
===
match
---
operator: , [3206,3207]
operator: , [3206,3207]
===
match
---
operator: , [10776,10777]
operator: , [10776,10777]
===
match
---
operator: , [1339,1340]
operator: , [1339,1340]
===
match
---
simple_stmt [35245,35311]
simple_stmt [35245,35311]
===
match
---
operator: = [68272,68273]
operator: = [68406,68407]
===
match
---
trailer [40598,40603]
trailer [40598,40603]
===
match
---
trailer [31729,31735]
trailer [31729,31735]
===
match
---
name: qry [82124,82127]
name: qry [82258,82261]
===
match
---
name: execution_date [26244,26258]
name: execution_date [26244,26258]
===
match
---
trailer [12152,12161]
trailer [12152,12161]
===
match
---
trailer [12080,12088]
trailer [12080,12088]
===
match
---
simple_stmt [9765,9792]
simple_stmt [9765,9792]
===
match
---
name: getpass [12073,12080]
name: getpass [12073,12080]
===
match
---
operator: = [5518,5519]
operator: = [5518,5519]
===
match
---
decorator [26422,26439]
decorator [26422,26439]
===
match
---
name: try_number [13264,13274]
name: try_number [13264,13274]
===
match
---
name: Context [3188,3195]
name: Context [3188,3195]
===
match
---
name: info [40511,40515]
name: info [40511,40515]
===
match
---
name: tis [78487,78490]
name: tis [78621,78624]
===
match
---
atom_expr [32945,32964]
atom_expr [32945,32964]
===
match
---
comparison [52858,52894]
comparison [52858,52894]
===
match
---
atom_expr [55423,55442]
atom_expr [55423,55442]
===
match
---
param [68969,68974]
param [69103,69108]
===
match
---
atom_expr [68490,68512]
atom_expr [68624,68646]
===
match
---
atom_expr [54288,54319]
atom_expr [54288,54319]
===
match
---
trailer [18283,18314]
trailer [18283,18314]
===
match
---
operator: , [14361,14362]
operator: , [14361,14362]
===
match
---
name: property [80985,80993]
name: property [81119,81127]
===
match
---
name: self [79537,79541]
name: self [79671,79675]
===
match
---
simple_stmt [11983,12020]
simple_stmt [11983,12020]
===
match
---
operator: , [77804,77805]
operator: , [77938,77939]
===
match
---
name: ignore_depends_on_past [39599,39621]
name: ignore_depends_on_past [39599,39621]
===
match
---
simple_stmt [14577,14597]
simple_stmt [14577,14597]
===
match
---
name: downstream_task_ids [26174,26193]
name: downstream_task_ids [26174,26193]
===
match
---
name: sqlalchemy [1414,1424]
name: sqlalchemy [1414,1424]
===
match
---
operator: = [23585,23586]
operator: = [23585,23586]
===
match
---
name: Column [10175,10181]
name: Column [10175,10181]
===
match
---
expr_stmt [22646,22687]
expr_stmt [22646,22687]
===
match
---
name: try_number [71431,71441]
name: try_number [71565,71575]
===
match
---
name: execution_date [8771,8785]
name: execution_date [8771,8785]
===
match
---
suite [39171,39237]
suite [39171,39237]
===
match
---
atom_expr [44558,44570]
atom_expr [44558,44570]
===
match
---
atom_expr [24112,24147]
atom_expr [24112,24147]
===
match
---
operator: == [21639,21641]
operator: == [21639,21641]
===
match
---
param [22934,22939]
param [22934,22939]
===
match
---
decorator [53279,53296]
decorator [53279,53296]
===
match
---
trailer [44374,44376]
trailer [44374,44376]
===
match
---
param [56150,56183]
param [56150,56183]
===
match
---
name: session [29210,29217]
name: session [29210,29217]
===
match
---
trailer [78164,78179]
trailer [78298,78313]
===
match
---
name: task [51986,51990]
name: task [51986,51990]
===
match
---
name: verbose_aware_logger [31668,31688]
name: verbose_aware_logger [31668,31688]
===
match
---
atom_expr [23481,23495]
atom_expr [23481,23495]
===
match
---
arglist [9484,9508]
arglist [9484,9508]
===
match
---
name: namespace [68649,68658]
name: namespace [68783,68792]
===
match
---
string: 'Marking task as SUCCESS. ' [45050,45077]
string: 'Marking task as SUCCESS. ' [45050,45077]
===
match
---
fstring_end: ' [48726,48727]
fstring_end: ' [48726,48727]
===
match
---
name: jobs [7325,7329]
name: jobs [7325,7329]
===
match
---
operator: , [38501,38502]
operator: , [38501,38502]
===
match
---
name: state [30820,30825]
name: state [30820,30825]
===
match
---
arglist [19587,19610]
arglist [19587,19610]
===
match
---
name: register_in_sensor_service [49776,49802]
name: register_in_sensor_service [49776,49802]
===
match
---
simple_stmt [8716,8799]
simple_stmt [8716,8799]
===
match
---
simple_stmt [5989,6011]
simple_stmt [5989,6011]
===
match
---
expr_stmt [22563,22599]
expr_stmt [22563,22599]
===
match
---
name: make_aware [11877,11887]
name: make_aware [11877,11887]
===
match
---
operator: == [35433,35435]
operator: == [35433,35435]
===
match
---
tfpdef [16047,16070]
tfpdef [16047,16070]
===
match
---
operator: , [38221,38222]
operator: , [38221,38222]
===
match
---
trailer [52564,52569]
trailer [52564,52569]
===
match
---
name: dag_id [7702,7708]
name: dag_id [7702,7708]
===
match
---
trailer [13301,13313]
trailer [13301,13313]
===
match
---
name: tis [77770,77773]
name: tis [77904,77907]
===
match
---
name: bool [35846,35850]
name: bool [35846,35850]
===
match
---
simple_stmt [24657,24690]
simple_stmt [24657,24690]
===
match
---
trailer [78516,78707]
trailer [78650,78841]
===
match
---
atom_expr [11757,11816]
atom_expr [11757,11816]
===
match
---
name: self [81018,81022]
name: self [81152,81156]
===
match
---
name: instance [61554,61562]
name: instance [61688,61696]
===
match
---
param [59633,59645]
param [59767,59779]
===
match
---
name: count [26378,26383]
name: count [26378,26383]
===
match
---
trailer [10338,10352]
trailer [10338,10352]
===
match
---
name: BooleanClauseList [77837,77854]
name: BooleanClauseList [77971,77988]
===
match
---
name: try_number [33858,33868]
name: try_number [33858,33868]
===
match
---
atom_expr [20923,20935]
atom_expr [20923,20935]
===
match
---
name: error [4669,4674]
name: error [4669,4674]
===
match
---
name: prev_attempted_tries [5955,5975]
name: prev_attempted_tries [5955,5975]
===
match
---
arglist [49540,49553]
arglist [49540,49553]
===
match
---
operator: , [59431,59432]
operator: , [59565,59566]
===
match
---
atom_expr [29836,29853]
atom_expr [29836,29853]
===
match
---
parameters [68968,68985]
parameters [69102,69119]
===
match
---
atom [10571,10875]
atom [10571,10875]
===
match
---
fstring [14741,14770]
fstring [14741,14770]
===
match
---
name: pool [35939,35943]
name: pool [35939,35943]
===
match
---
name: _state [80904,80910]
name: _state [81038,81044]
===
match
---
name: deps [38136,38140]
name: deps [38136,38140]
===
match
---
name: sqlalchemy [2741,2751]
name: sqlalchemy [2741,2751]
===
match
---
name: TaskInstance [26053,26065]
name: TaskInstance [26053,26065]
===
match
---
atom_expr [7468,7482]
atom_expr [7468,7482]
===
match
---
simple_stmt [45834,45900]
simple_stmt [45834,45900]
===
match
---
trailer [42696,42703]
trailer [42696,42703]
===
match
---
atom [64367,65943]
atom [64501,66077]
===
match
---
trailer [22499,22506]
trailer [22499,22506]
===
match
---
name: dag_id [46085,46091]
name: dag_id [46085,46091]
===
match
---
trailer [37720,37728]
trailer [37720,37728]
===
match
---
name: hasattr [80166,80173]
name: hasattr [80300,80307]
===
match
---
name: dag_id [11197,11203]
name: dag_id [11197,11203]
===
match
---
argument [27817,27832]
argument [27817,27832]
===
match
---
operator: , [26309,26310]
operator: , [26309,26310]
===
match
---
name: state [39006,39011]
name: state [39006,39011]
===
match
---
name: params [62404,62410]
name: params [62538,62544]
===
match
---
trailer [68831,68836]
trailer [68965,68970]
===
match
---
expr_stmt [61317,61331]
expr_stmt [61451,61465]
===
match
---
atom_expr [50596,50622]
atom_expr [50596,50622]
===
match
---
operator: = [61690,61691]
operator: = [61824,61825]
===
match
---
atom_expr [46600,46629]
atom_expr [46600,46629]
===
match
---
atom_expr [26169,26193]
atom_expr [26169,26193]
===
match
---
name: clear_xcom_data [48630,48645]
name: clear_xcom_data [48630,48645]
===
match
---
name: pool [22536,22540]
name: pool [22536,22540]
===
match
---
operator: , [11093,11094]
operator: , [11093,11094]
===
match
---
raise_stmt [48442,48496]
raise_stmt [48442,48496]
===
match
---
expr_stmt [9533,9600]
expr_stmt [9533,9600]
===
match
---
simple_stmt [22563,22600]
simple_stmt [22563,22600]
===
match
---
operator: , [70678,70679]
operator: , [70812,70813]
===
match
---
trailer [46578,46788]
trailer [46578,46788]
===
match
---
atom_expr [50559,50578]
atom_expr [50559,50578]
===
match
---
if_stmt [59955,60022]
if_stmt [60089,60156]
===
match
---
operator: ** [9564,9566]
operator: ** [9564,9566]
===
match
---
name: dag [64419,64422]
name: dag [64553,64556]
===
match
---
name: models [60047,60053]
name: models [60181,60187]
===
match
---
trailer [18205,18232]
trailer [18205,18232]
===
match
---
name: path [71764,71768]
name: path [71898,71902]
===
match
---
operator: , [64880,64881]
operator: , [65014,65015]
===
match
---
trailer [21584,21598]
trailer [21584,21598]
===
match
---
trailer [49881,49885]
trailer [49881,49885]
===
match
---
name: integrate_macros_plugins [2161,2185]
name: integrate_macros_plugins [2161,2185]
===
match
---
name: pop [3658,3661]
name: pop [3658,3661]
===
match
---
string: "run" [17992,17997]
string: "run" [17992,17997]
===
match
---
operator: , [79385,79386]
operator: , [79519,79520]
===
match
---
atom_expr [64544,64582]
atom_expr [64678,64716]
===
match
---
operator: = [59903,59904]
operator: = [60037,60038]
===
match
---
name: key [24171,24174]
name: key [24171,24174]
===
match
---
name: fd [4022,4024]
name: fd [4022,4024]
===
match
---
fstring_string: .duration [48717,48726]
fstring_string: .duration [48717,48726]
===
match
---
name: local [15835,15840]
name: local [15835,15840]
===
match
---
expr_stmt [61406,61456]
expr_stmt [61540,61590]
===
match
---
trailer [82206,82212]
trailer [82340,82346]
===
match
---
atom_expr [34935,34945]
atom_expr [34935,34945]
===
match
---
expr_stmt [8041,8052]
expr_stmt [8041,8052]
===
match
---
atom_expr [74327,74340]
atom_expr [74461,74474]
===
match
---
trailer [50388,50408]
trailer [50388,50408]
===
match
---
trailer [43871,43886]
trailer [43871,43886]
===
match
---
atom_expr [66565,66927]
atom_expr [66699,67061]
===
match
---
atom_expr [39078,39135]
atom_expr [39078,39135]
===
match
---
suite [41825,45613]
suite [41825,45613]
===
match
---
atom_expr [6652,6661]
atom_expr [6652,6661]
===
match
---
fstring_string: &dag_id= [19399,19407]
fstring_string: &dag_id= [19399,19407]
===
match
---
name: construct_task_instance [81340,81363]
name: construct_task_instance [81474,81497]
===
match
---
arith_expr [70659,70678]
arith_expr [70793,70812]
===
match
---
trailer [9476,9528]
trailer [9476,9528]
===
match
---
trailer [40473,40478]
trailer [40473,40478]
===
match
---
name: self [68371,68375]
name: self [68505,68509]
===
match
---
name: self [40627,40631]
name: self [40627,40631]
===
match
---
trailer [8281,8289]
trailer [8281,8289]
===
match
---
operator: = [74381,74382]
operator: = [74515,74516]
===
match
---
atom_expr [54624,54634]
atom_expr [54624,54634]
===
match
---
name: raw [15946,15949]
name: raw [15946,15949]
===
match
---
simple_stmt [59759,59786]
simple_stmt [59893,59920]
===
match
---
name: data [4141,4145]
name: data [4141,4145]
===
match
---
operator: -> [28602,28604]
operator: -> [28602,28604]
===
match
---
except_clause [66489,66541]
except_clause [66623,66675]
===
match
---
name: TaskInstance [77456,77468]
name: TaskInstance [77590,77602]
===
match
---
atom_expr [40780,40791]
atom_expr [40780,40791]
===
match
---
trailer [50536,50587]
trailer [50536,50587]
===
match
---
simple_stmt [20944,20964]
simple_stmt [20944,20964]
===
match
---
trailer [61286,61307]
trailer [61420,61441]
===
match
---
string: "Updating task params (%s) with DagRun.conf (%s)" [67687,67736]
string: "Updating task params (%s) with DagRun.conf (%s)" [67821,67870]
===
match
---
name: task_instance_scheduling_decisions [46863,46897]
name: task_instance_scheduling_decisions [46863,46897]
===
match
---
name: settings [41011,41019]
name: settings [41011,41019]
===
match
---
name: e [43206,43207]
name: e [43206,43207]
===
match
---
operator: , [64848,64849]
operator: , [64982,64983]
===
match
---
operator: = [54614,54615]
operator: = [54614,54615]
===
match
---
name: ignore_schedule [27737,27752]
name: ignore_schedule [27737,27752]
===
match
---
argument [54479,54488]
argument [54479,54488]
===
match
---
name: priority_weight [80237,80252]
name: priority_weight [80371,80386]
===
match
---
name: job [7456,7459]
name: job [7456,7459]
===
match
---
name: UndefinedError [66521,66535]
name: UndefinedError [66655,66669]
===
match
---
trailer [82212,82214]
trailer [82346,82348]
===
match
---
operator: = [5342,5343]
operator: = [5342,5343]
===
match
---
name: task_id [15579,15586]
name: task_id [15579,15586]
===
match
---
string: 'ti' [70328,70332]
string: 'ti' [70462,70466]
===
match
---
name: log [24703,24706]
name: log [24703,24706]
===
match
---
try_stmt [45913,47973]
try_stmt [45913,47973]
===
match
---
operator: = [15315,15316]
operator: = [15315,15316]
===
match
---
name: self [45564,45568]
name: self [45564,45568]
===
match
---
operator: = [54757,54758]
operator: = [54757,54758]
===
match
---
operator: } [32927,32928]
operator: } [32927,32928]
===
match
---
trailer [24101,24103]
trailer [24101,24103]
===
match
---
argument [59169,59184]
argument [59303,59318]
===
match
---
with_stmt [48656,50517]
with_stmt [48656,50517]
===
match
---
operator: { [48698,48699]
operator: { [48698,48699]
===
match
---
operator: , [74172,74173]
operator: , [74306,74307]
===
match
---
operator: { [32915,32916]
operator: { [32915,32916]
===
match
---
simple_stmt [49753,49818]
simple_stmt [49753,49818]
===
match
---
simple_stmt [44703,44709]
simple_stmt [44703,44709]
===
match
---
param [67826,67831]
param [67960,67965]
===
match
---
name: XCom [76227,76231]
name: XCom [76361,76365]
===
match
---
name: jinja_env [71554,71563]
name: jinja_env [71688,71697]
===
match
---
atom_expr [16088,16097]
atom_expr [16088,16097]
===
match
---
simple_stmt [1033,1118]
simple_stmt [1033,1118]
===
match
---
string: 'outlets' [64795,64804]
string: 'outlets' [64929,64938]
===
match
---
atom_expr [48186,48214]
atom_expr [48186,48214]
===
match
---
operator: @ [8124,8125]
operator: @ [8124,8125]
===
match
---
tfpdef [29794,29810]
tfpdef [29794,29810]
===
match
---
name: end_date [24940,24948]
name: end_date [24940,24948]
===
match
---
simple_stmt [7882,7907]
simple_stmt [7882,7907]
===
match
---
if_stmt [27174,27238]
if_stmt [27174,27238]
===
match
---
operator: , [64781,64782]
operator: , [64915,64916]
===
match
---
operator: - [82203,82204]
operator: - [82337,82338]
===
match
---
name: get_previous_ti [29055,29070]
name: get_previous_ti [29055,29070]
===
match
---
name: environ [49334,49341]
name: environ [49334,49341]
===
match
---
name: RUNNING_DEPS [2367,2379]
name: RUNNING_DEPS [2367,2379]
===
match
---
funcdef [74210,77144]
funcdef [74344,77278]
===
match
---
operator: = [9896,9897]
operator: = [9896,9897]
===
match
---
simple_stmt [32311,32341]
simple_stmt [32311,32341]
===
match
---
trailer [79027,79264]
trailer [79161,79398]
===
match
---
name: debug [21506,21511]
name: debug [21506,21511]
===
match
---
power [33606,33632]
power [33606,33632]
===
match
---
trailer [27118,27136]
trailer [27118,27136]
===
match
---
name: self [14987,14991]
name: self [14987,14991]
===
match
---
string: '' [61783,61785]
string: '' [61917,61919]
===
match
---
name: models [67047,67053]
name: models [67181,67187]
===
match
---
name: airflow [2996,3003]
name: airflow [2996,3003]
===
match
---
simple_stmt [62755,62771]
simple_stmt [62889,62905]
===
match
---
operator: , [24752,24753]
operator: , [24752,24753]
===
match
---
atom_expr [26028,26337]
atom_expr [26028,26337]
===
match
---
suite [57956,58109]
suite [58090,58243]
===
match
---
name: Session [29219,29226]
name: Session [29219,29226]
===
match
---
expr_stmt [60113,60288]
expr_stmt [60247,60422]
===
match
---
simple_stmt [20576,20589]
simple_stmt [20576,20589]
===
match
---
trailer [27141,27156]
trailer [27141,27156]
===
match
---
trailer [5921,5931]
trailer [5921,5931]
===
match
---
operator: , [2770,2771]
operator: , [2770,2771]
===
match
---
simple_stmt [40290,40327]
simple_stmt [40290,40327]
===
match
---
name: exception [58758,58767]
name: exception [58892,58901]
===
match
---
name: task [59929,59933]
name: task [60063,60067]
===
match
---
atom [18587,18598]
atom [18587,18598]
===
match
---
arglist [41132,41194]
arglist [41132,41194]
===
match
---
simple_stmt [62881,62911]
simple_stmt [63015,63045]
===
match
---
suite [18616,18658]
suite [18616,18658]
===
match
---
trailer [22511,22518]
trailer [22511,22518]
===
match
---
simple_stmt [60598,60670]
simple_stmt [60732,60804]
===
match
---
name: task_id [20367,20374]
name: task_id [20367,20374]
===
match
---
name: State [55664,55669]
name: State [55664,55669]
===
match
---
suite [80472,80502]
suite [80606,80636]
===
match
---
name: task_id [23979,23986]
name: task_id [23979,23986]
===
match
---
expr_stmt [82176,82223]
expr_stmt [82310,82357]
===
match
---
return_stmt [30784,30840]
return_stmt [30784,30840]
===
match
---
name: dag_id [43707,43713]
name: dag_id [43707,43713]
===
match
---
param [19892,19897]
param [19892,19897]
===
match
---
name: task_ids [47022,47030]
name: task_ids [47022,47030]
===
match
---
operator: , [66376,66377]
operator: , [66510,66511]
===
match
---
operator: = [74005,74006]
operator: = [74139,74140]
===
match
---
trailer [33779,33898]
trailer [33779,33898]
===
match
---
name: self [43049,43053]
name: self [43049,43053]
===
match
---
name: pool_slots [22584,22594]
name: pool_slots [22584,22594]
===
match
---
name: cmd [18441,18444]
name: cmd [18441,18444]
===
match
---
name: __repr__ [63909,63917]
name: __repr__ [64043,64051]
===
match
---
param [53369,53390]
param [53369,53390]
===
match
---
name: dag [26842,26845]
name: dag [26842,26845]
===
match
---
atom_expr [7156,7178]
atom_expr [7156,7178]
===
match
---
name: TaskInstance [20302,20314]
name: TaskInstance [20302,20314]
===
match
---
atom_expr [40688,40725]
atom_expr [40688,40725]
===
match
---
name: execution_date [78165,78179]
name: execution_date [78299,78313]
===
match
---
atom_expr [5102,5139]
atom_expr [5102,5139]
===
match
---
expr_stmt [62159,62217]
expr_stmt [62293,62351]
===
match
---
expr_stmt [23481,23510]
expr_stmt [23481,23510]
===
match
---
name: jinja_context [71275,71288]
name: jinja_context [71409,71422]
===
match
---
trailer [77484,77492]
trailer [77618,77626]
===
match
---
atom_expr [39868,39878]
atom_expr [39868,39878]
===
match
---
simple_stmt [18522,18546]
simple_stmt [18522,18546]
===
match
---
name: error [56036,56041]
name: error [56036,56041]
===
match
---
atom_expr [80234,80252]
atom_expr [80368,80386]
===
match
---
name: task [23456,23460]
name: task [23456,23460]
===
match
---
operator: , [35858,35859]
operator: , [35858,35859]
===
match
---
trailer [19390,19398]
trailer [19390,19398]
===
match
---
name: task_id [28022,28029]
name: task_id [28022,28029]
===
match
---
name: key [72915,72918]
name: key [73049,73052]
===
match
---
name: self [43192,43196]
name: self [43192,43196]
===
match
---
name: refresh_from_db [37518,37533]
name: refresh_from_db [37518,37533]
===
match
---
name: dep_status [32008,32018]
name: dep_status [32008,32018]
===
match
---
name: self [52922,52926]
name: self [52922,52926]
===
match
---
name: next_ds_nodash [61340,61354]
name: next_ds_nodash [61474,61488]
===
match
---
simple_stmt [32349,32391]
simple_stmt [32349,32391]
===
match
---
operator: = [9540,9541]
operator: = [9540,9541]
===
match
---
operator: = [74164,74165]
operator: = [74298,74299]
===
match
---
name: State [57692,57697]
name: State [57826,57831]
===
match
---
name: self [32635,32639]
name: self [32635,32639]
===
match
---
operator: , [67744,67745]
operator: , [67878,67879]
===
match
---
name: task_id [5347,5354]
name: task_id [5347,5354]
===
match
---
name: key [73979,73982]
name: key [74113,74116]
===
match
---
import_from [7312,7353]
import_from [7312,7353]
===
match
---
trailer [10720,10776]
trailer [10720,10776]
===
match
---
name: self [80034,80038]
name: self [80168,80172]
===
match
---
name: state [11127,11132]
name: state [11127,11132]
===
match
---
name: state [20576,20581]
name: state [20576,20581]
===
match
---
name: Column [10102,10108]
name: Column [10102,10108]
===
match
---
operator: , [30928,30929]
operator: , [30928,30929]
===
match
---
comparison [78420,78438]
comparison [78554,78572]
===
match
---
name: log [72800,72803]
name: log [72934,72937]
===
match
---
trailer [37407,37412]
trailer [37407,37412]
===
match
---
name: self [23571,23575]
name: self [23571,23575]
===
match
---
name: file_path [18719,18728]
name: file_path [18719,18728]
===
match
---
trailer [82082,82084]
trailer [82216,82218]
===
match
---
trailer [24800,24811]
trailer [24800,24811]
===
match
---
operator: = [15394,15395]
operator: = [15394,15395]
===
match
---
trailer [62074,62082]
trailer [62208,62216]
===
match
---
atom_expr [77456,77476]
atom_expr [77590,77610]
===
match
---
name: raw [14289,14292]
name: raw [14289,14292]
===
match
---
name: rollback [47962,47970]
name: rollback [47962,47970]
===
match
---
name: job_id [18223,18229]
name: job_id [18223,18229]
===
match
---
simple_stmt [1828,1889]
simple_stmt [1828,1889]
===
match
---
operator: , [20336,20337]
operator: , [20336,20337]
===
match
---
operator: , [46163,46164]
operator: , [46163,46164]
===
match
---
simple_stmt [4653,4681]
simple_stmt [4653,4681]
===
match
---
name: verbose [35638,35645]
name: verbose [35638,35645]
===
match
---
simple_stmt [29043,29092]
simple_stmt [29043,29092]
===
match
---
expr_stmt [10881,11070]
expr_stmt [10881,11070]
===
match
---
simple_stmt [54277,54320]
simple_stmt [54277,54320]
===
match
---
name: pickler [10339,10346]
name: pickler [10339,10346]
===
match
---
trailer [68870,68872]
trailer [69004,69006]
===
match
---
operator: , [78692,78693]
operator: , [78826,78827]
===
match
---
suite [12108,12140]
suite [12108,12140]
===
match
---
param [72211,72216]
param [72345,72350]
===
match
---
trailer [40894,40901]
trailer [40894,40901]
===
match
---
trailer [25056,25058]
trailer [25056,25058]
===
match
---
argument [63837,63858]
argument [63971,63992]
===
match
---
atom_expr [35909,35922]
atom_expr [35909,35922]
===
match
---
name: session [38564,38571]
name: session [38564,38571]
===
match
---
simple_stmt [18273,18315]
simple_stmt [18273,18315]
===
match
---
name: job_id [41681,41687]
name: job_id [41681,41687]
===
match
---
param [56074,56107]
param [56074,56107]
===
match
---
trailer [20443,20458]
trailer [20443,20458]
===
match
---
name: ignore_depends_on_past [53912,53934]
name: ignore_depends_on_past [53912,53934]
===
match
---
param [71624,71631]
param [71758,71765]
===
match
---
except_clause [49834,49855]
except_clause [49834,49855]
===
match
---
trailer [29580,29596]
trailer [29580,29596]
===
match
---
name: str [81117,81120]
name: str [81251,81254]
===
match
---
suite [81423,82154]
suite [81557,82288]
===
match
---
atom_expr [67786,67798]
atom_expr [67920,67932]
===
match
---
trailer [8511,8519]
trailer [8511,8519]
===
match
---
operator: } [32964,32965]
operator: } [32964,32965]
===
match
---
name: self [49877,49881]
name: self [49877,49881]
===
match
---
name: get_num_running_task_instances [77174,77204]
name: get_num_running_task_instances [77308,77338]
===
match
---
operator: = [62170,62171]
operator: = [62304,62305]
===
match
---
name: task [37396,37400]
name: task [37396,37400]
===
match
---
suite [24922,25059]
suite [24922,25059]
===
match
---
trailer [43429,43432]
trailer [43429,43432]
===
match
---
arglist [71998,72043]
arglist [72132,72177]
===
match
---
suite [18673,18708]
suite [18673,18708]
===
match
---
name: value [51790,51795]
name: value [51790,51795]
===
match
---
trailer [23323,23328]
trailer [23323,23328]
===
match
---
name: key [71729,71732]
name: key [71863,71866]
===
match
---
operator: , [44261,44262]
operator: , [44261,44262]
===
match
---
atom_expr [59092,59185]
atom_expr [59226,59319]
===
match
---
suite [32820,32858]
suite [32820,32858]
===
match
---
param [80712,80716]
param [80846,80850]
===
match
---
atom_expr [27709,27720]
atom_expr [27709,27720]
===
match
---
operator: , [28445,28446]
operator: , [28445,28446]
===
match
---
operator: , [41162,41163]
operator: , [41162,41163]
===
match
---
trailer [11495,11511]
trailer [11495,11511]
===
match
---
param [58927,58932]
param [59061,59066]
===
match
---
atom_expr [26296,26309]
atom_expr [26296,26309]
===
match
---
simple_stmt [43192,43209]
simple_stmt [43192,43209]
===
match
---
simple_stmt [6023,6041]
simple_stmt [6023,6041]
===
match
---
atom_expr [48223,48232]
atom_expr [48223,48232]
===
match
---
trailer [82498,82506]
trailer [82632,82640]
===
match
---
name: self [55898,55902]
name: self [55898,55902]
===
match
---
name: execution_date [78594,78608]
name: execution_date [78728,78742]
===
match
---
name: log [32547,32550]
name: log [32547,32550]
===
match
---
name: generate_command [15494,15510]
name: generate_command [15494,15510]
===
match
---
simple_stmt [58675,58733]
simple_stmt [58809,58867]
===
match
---
trailer [39859,39865]
trailer [39859,39865]
===
match
---
and_test [67634,67658]
and_test [67768,67792]
===
match
---
argument [38190,38221]
argument [38190,38221]
===
match
---
arglist [10633,10670]
arglist [10633,10670]
===
match
---
trailer [59966,59973]
trailer [60100,60107]
===
match
---
name: state [12134,12139]
name: state [12134,12139]
===
match
---
name: generate_command [14932,14948]
name: generate_command [14932,14948]
===
match
---
trailer [20486,20490]
trailer [20486,20490]
===
match
---
atom_expr [28787,29034]
atom_expr [28787,29034]
===
match
---
name: test_mode [45409,45418]
name: test_mode [45409,45418]
===
match
---
trailer [21846,21852]
trailer [21846,21852]
===
match
---
trailer [47961,47970]
trailer [47961,47970]
===
match
---
operator: = [5932,5933]
operator: = [5932,5933]
===
match
---
expr_stmt [58071,58108]
expr_stmt [58205,58242]
===
match
---
simple_stmt [7994,8036]
simple_stmt [7994,8036]
===
match
---
atom_expr [6805,6998]
atom_expr [6805,6998]
===
match
---
funcdef [8138,8311]
funcdef [8138,8311]
===
match
---
name: TaskReschedule [3173,3187]
name: TaskReschedule [3173,3187]
===
match
---
name: e [43177,43178]
name: e [43177,43178]
===
match
---
sync_comp_for [78925,78937]
sync_comp_for [79059,79071]
===
match
---
name: last_dagrun [27951,27962]
name: last_dagrun [27951,27962]
===
match
---
string: 'ti_failures' [56806,56819]
string: 'ti_failures' [56940,56953]
===
match
---
name: TaskInstanceKey [24184,24199]
name: TaskInstanceKey [24184,24199]
===
match
---
name: bool [74454,74458]
name: bool [74588,74592]
===
match
---
trailer [9786,9790]
trailer [9786,9790]
===
match
---
return_stmt [20597,20609]
return_stmt [20597,20609]
===
match
---
expr_stmt [11983,12019]
expr_stmt [11983,12019]
===
match
---
name: self [48960,48964]
name: self [48960,48964]
===
match
---
operator: = [26862,26863]
operator: = [26862,26863]
===
match
---
atom_expr [24087,24103]
atom_expr [24087,24103]
===
match
---
expr_stmt [82534,82584]
expr_stmt [82668,82718]
===
match
---
atom_expr [43867,43898]
atom_expr [43867,43898]
===
match
---
fstring_string: . [32928,32929]
fstring_string: . [32928,32929]
===
match
---
fstring_start: f' [56742,56744]
fstring_start: f' [56876,56878]
===
match
---
name: query [60149,60154]
name: query [60283,60288]
===
match
---
atom_expr [32930,32942]
atom_expr [32930,32942]
===
match
---
comparison [78829,78858]
comparison [78963,78992]
===
match
---
name: schedulable_tis [47171,47186]
name: schedulable_tis [47171,47186]
===
match
---
suite [80883,80911]
suite [81017,81045]
===
match
---
dotted_name [7317,7338]
dotted_name [7317,7338]
===
match
---
parameters [30891,30944]
parameters [30891,30944]
===
match
---
name: self [71234,71238]
name: self [71368,71372]
===
match
---
trailer [66371,66376]
trailer [66505,66510]
===
match
---
operator: = [54075,54076]
operator: = [54075,54076]
===
match
---
name: _execute_task [51042,51055]
name: _execute_task [51042,51055]
===
match
---
operator: { [67456,67457]
operator: { [67590,67591]
===
match
---
name: dag_id [32921,32927]
name: dag_id [32921,32927]
===
match
---
trailer [80173,80196]
trailer [80307,80330]
===
match
---
param [32288,32300]
param [32288,32300]
===
match
---
comparison [24889,24921]
comparison [24889,24921]
===
match
---
name: TR [7211,7213]
name: TR [7211,7213]
===
match
---
atom_expr [11934,11973]
atom_expr [11934,11973]
===
match
---
name: execution_date [78463,78477]
name: execution_date [78597,78611]
===
match
---
name: ti_key_str [65426,65436]
name: ti_key_str [65560,65570]
===
match
---
name: session [60141,60148]
name: session [60275,60282]
===
match
---
operator: = [32295,32296]
operator: = [32295,32296]
===
match
---
trailer [72977,72987]
trailer [73111,73121]
===
match
---
funcdef [8330,8571]
funcdef [8330,8571]
===
match
---
name: with_entities [76821,76834]
name: with_entities [76955,76968]
===
match
---
name: schedulable_ti [47248,47262]
name: schedulable_ti [47248,47262]
===
match
---
trailer [19525,19558]
trailer [19525,19558]
===
match
---
atom_expr [78090,78102]
atom_expr [78224,78236]
===
match
---
name: task [59345,59349]
name: task [59479,59483]
===
match
---
name: jinja_context [70978,70991]
name: jinja_context [71112,71125]
===
match
---
simple_stmt [80892,80911]
simple_stmt [81026,81045]
===
match
---
operator: = [70781,70782]
operator: = [70915,70916]
===
match
---
name: ti [22716,22718]
name: ti [22716,22718]
===
match
---
suite [71775,71819]
suite [71909,71953]
===
match
---
operator: } [48696,48697]
operator: } [48696,48697]
===
match
---
trailer [21501,21505]
trailer [21501,21505]
===
match
---
param [58979,59012]
param [59113,59146]
===
match
---
trailer [68670,68689]
trailer [68804,68823]
===
match
---
trailer [12061,12070]
trailer [12061,12070]
===
match
---
name: send_email [2447,2457]
name: send_email [2447,2457]
===
match
---
fstring_string:   [32943,32944]
fstring_string:   [32943,32944]
===
match
---
operator: = [62410,62411]
operator: = [62544,62545]
===
match
---
with_stmt [4375,4681]
with_stmt [4375,4681]
===
match
---
name: State [44543,44548]
name: State [44543,44548]
===
match
---
operator: } [19773,19774]
operator: } [19773,19774]
===
match
---
param [63743,63748]
param [63877,63882]
===
match
---
trailer [43543,43547]
trailer [43543,43547]
===
match
---
name: airflow_context_vars [49058,49078]
name: airflow_context_vars [49058,49078]
===
match
---
name: priority_weight [81002,81017]
name: priority_weight [81136,81151]
===
match
---
decorator [13237,13256]
decorator [13237,13256]
===
match
---
name: self [71566,71570]
name: self [71700,71704]
===
match
---
suite [81272,81310]
suite [81406,81444]
===
match
---
trailer [62309,62350]
trailer [62443,62484]
===
match
---
name: self [56984,56988]
name: self [57118,57122]
===
match
---
name: execution_date [11958,11972]
name: execution_date [11958,11972]
===
match
---
expr_stmt [40800,40820]
expr_stmt [40800,40820]
===
match
---
name: self [42589,42593]
name: self [42589,42593]
===
match
---
operator: = [54380,54381]
operator: = [54380,54381]
===
match
---
return_stmt [80892,80910]
return_stmt [81026,81044]
===
match
---
comparison [13131,13158]
comparison [13131,13158]
===
match
---
simple_stmt [59895,59910]
simple_stmt [60029,60044]
===
match
---
name: pool_override [22946,22959]
name: pool_override [22946,22959]
===
match
---
fstring_end: " [19737,19738]
fstring_end: " [19737,19738]
===
match
---
name: fallback [45806,45814]
name: fallback [45806,45814]
===
match
---
string: 'dag_id=%s, task_id=%s, execution_date=%s, start_date=%s, end_date=%s' [43614,43684]
string: 'dag_id=%s, task_id=%s, execution_date=%s, start_date=%s, end_date=%s' [43614,43684]
===
match
---
simple_stmt [43539,43914]
simple_stmt [43539,43914]
===
match
---
trailer [48645,48647]
trailer [48645,48647]
===
match
---
or_test [32363,32390]
or_test [32363,32390]
===
match
---
name: self [34690,34694]
name: self [34690,34694]
===
match
---
name: self [43731,43735]
name: self [43731,43735]
===
match
---
trailer [49885,49893]
trailer [49885,49893]
===
match
---
simple_stmt [9959,9984]
simple_stmt [9959,9984]
===
match
---
name: self [20325,20329]
name: self [20325,20329]
===
match
---
expr_stmt [61616,61637]
expr_stmt [61750,61771]
===
match
---
name: State [65115,65120]
name: State [65249,65254]
===
match
---
name: self [72571,72575]
name: self [72705,72709]
===
match
---
trailer [21631,21638]
trailer [21631,21638]
===
match
---
name: execution_date [29680,29694]
name: execution_date [29680,29694]
===
match
---
operator: , [65352,65353]
operator: , [65486,65487]
===
match
---
name: test_mode [59125,59134]
name: test_mode [59259,59268]
===
match
---
dotted_name [2076,2095]
dotted_name [2076,2095]
===
match
---
trailer [18632,18639]
trailer [18632,18639]
===
match
---
param [41681,41710]
param [41681,41710]
===
match
---
name: expected_state [3675,3689]
name: expected_state [3675,3689]
===
match
---
suite [3701,3897]
suite [3701,3897]
===
match
---
name: self [20910,20914]
name: self [20910,20914]
===
match
---
operator: = [49079,49080]
operator: = [49079,49080]
===
match
---
name: task [5483,5487]
name: task [5483,5487]
===
match
---
name: k [49264,49265]
name: k [49264,49265]
===
match
---
operator: , [3955,3956]
operator: , [3955,3956]
===
match
---
name: str [79623,79626]
name: str [79757,79760]
===
match
---
atom_expr [53242,53273]
atom_expr [53242,53273]
===
match
---
testlist_star_expr [72296,72335]
testlist_star_expr [72430,72469]
===
match
---
name: staticmethod [15473,15485]
name: staticmethod [15473,15485]
===
match
---
expr_stmt [67114,67183]
expr_stmt [67248,67317]
===
match
---
simple_stmt [12148,12167]
simple_stmt [12148,12167]
===
match
---
name: TR [6652,6654]
name: TR [6652,6654]
===
match
---
argument [53971,54004]
argument [53971,54004]
===
match
---
argument [71071,71086]
argument [71205,71220]
===
match
---
name: self [80111,80115]
name: self [80245,80249]
===
match
---
atom_expr [19237,19268]
atom_expr [19237,19268]
===
match
---
decorated [81154,81227]
decorated [81288,81361]
===
match
---
param [21035,21040]
param [21035,21040]
===
match
---
operator: , [54121,54122]
operator: , [54121,54122]
===
match
---
operator: } [49257,49258]
operator: } [49257,49258]
===
match
---
name: self [62755,62759]
name: self [62889,62893]
===
match
---
atom_expr [48336,48397]
atom_expr [48336,48397]
===
match
---
name: job_id [37586,37592]
name: job_id [37586,37592]
===
match
---
atom_expr [49081,49137]
atom_expr [49081,49137]
===
match
---
atom_expr [9941,9953]
atom_expr [9941,9953]
===
match
---
name: tis [78688,78691]
name: tis [78822,78825]
===
match
---
name: self [79608,79612]
name: self [79742,79746]
===
match
---
operator: , [68689,68690]
operator: , [68823,68824]
===
match
---
return_stmt [71835,71896]
return_stmt [71969,72030]
===
match
---
comparison [51722,51740]
comparison [51722,51740]
===
match
---
atom_expr [80077,80087]
atom_expr [80211,80221]
===
match
---
trailer [80972,80978]
trailer [81106,81112]
===
match
---
name: update [49342,49348]
name: update [49342,49348]
===
match
---
atom_expr [26354,26362]
atom_expr [26354,26362]
===
match
---
operator: , [18835,18836]
operator: , [18835,18836]
===
match
---
atom [69531,69875]
atom [69665,70009]
===
match
---
name: is_eligible_to_retry [59244,59264]
name: is_eligible_to_retry [59378,59398]
===
match
---
comparison [21619,21653]
comparison [21619,21653]
===
match
---
decorator [24153,24163]
decorator [24153,24163]
===
match
---
decorated [19145,19422]
decorated [19145,19422]
===
match
---
name: error [54752,54757]
name: error [54752,54757]
===
match
---
name: task [27285,27289]
name: task [27285,27289]
===
match
---
name: Optional [15916,15924]
name: Optional [15916,15924]
===
match
---
name: duration [9736,9744]
name: duration [9736,9744]
===
match
---
suite [54595,54765]
suite [54595,54765]
===
match
---
name: uselist [11026,11033]
name: uselist [11026,11033]
===
match
---
trailer [56736,56741]
trailer [56870,56875]
===
match
---
funcdef [72554,72852]
funcdef [72688,72986]
===
match
---
name: context [50493,50500]
name: context [50493,50500]
===
match
---
name: contextlib [3288,3298]
name: contextlib [3288,3298]
===
match
---
operator: = [40745,40746]
operator: = [40745,40746]
===
match
---
name: self [25938,25942]
name: self [25938,25942]
===
match
---
name: ti [79137,79139]
name: ti [79271,79273]
===
match
---
operator: = [53690,53691]
operator: = [53690,53691]
===
match
---
simple_stmt [835,850]
simple_stmt [835,850]
===
match
---
simple_stmt [2186,2220]
simple_stmt [2186,2220]
===
match
---
atom_expr [60532,60589]
atom_expr [60666,60723]
===
match
---
suite [49610,50266]
suite [49610,50266]
===
match
---
argument [10014,10028]
argument [10014,10028]
===
match
---
trailer [18993,18995]
trailer [18993,18995]
===
match
---
name: context_to_airflow_vars [49081,49104]
name: context_to_airflow_vars [49081,49104]
===
match
---
arith_expr [19338,19421]
arith_expr [19338,19421]
===
match
---
operator: , [26130,26131]
operator: , [26130,26131]
===
match
---
atom_expr [72837,72850]
atom_expr [72971,72984]
===
match
---
simple_stmt [56593,56627]
simple_stmt [56727,56761]
===
match
---
arglist [71720,71732]
arglist [71854,71866]
===
match
---
simple_stmt [1969,2026]
simple_stmt [1969,2026]
===
match
---
trailer [42650,42666]
trailer [42650,42666]
===
match
---
atom_expr [64562,64581]
atom_expr [64696,64715]
===
match
---
name: priority_weight_total [23407,23428]
name: priority_weight_total [23407,23428]
===
match
---
atom_expr [79829,79842]
atom_expr [79963,79976]
===
match
---
name: UndefinedError [67342,67356]
name: UndefinedError [67476,67490]
===
match
---
name: task [58089,58093]
name: task [58223,58227]
===
match
---
string: 'Exception:<br>Failed attempt to attach error logs<br>' [69988,70043]
string: 'Exception:<br>Failed attempt to attach error logs<br>' [70122,70177]
===
match
---
suite [20666,20989]
suite [20666,20989]
===
match
---
arglist [62141,62148]
arglist [62275,62282]
===
match
---
fstring_expr [32915,32928]
fstring_expr [32915,32928]
===
match
---
name: ti [20514,20516]
name: ti [20514,20516]
===
match
---
operator: , [43684,43685]
operator: , [43684,43685]
===
match
---
name: str [52292,52295]
name: str [52292,52295]
===
match
---
operator: , [56887,56888]
operator: , [57021,57022]
===
match
---
atom_expr [45564,45612]
atom_expr [45564,45612]
===
match
---
trailer [77685,77689]
trailer [77819,77823]
===
match
---
atom_expr [4033,4044]
atom_expr [4033,4044]
===
match
---
name: pendulum [64544,64552]
name: pendulum [64678,64686]
===
match
---
not_test [26971,26977]
not_test [26971,26977]
===
match
---
atom_expr [22857,22906]
atom_expr [22857,22906]
===
match
---
name: self [25367,25371]
name: self [25367,25371]
===
match
---
name: Sentry [45640,45646]
name: Sentry [45640,45646]
===
match
---
name: all [78719,78722]
name: all [78853,78856]
===
match
---
trailer [7943,7950]
trailer [7943,7950]
===
match
---
operator: , [45309,45310]
operator: , [45309,45310]
===
match
---
fstring [19675,19701]
fstring [19675,19701]
===
match
---
fstring_expr [32967,32979]
fstring_expr [32967,32979]
===
match
---
name: get_task [5428,5436]
name: get_task [5428,5436]
===
match
---
name: log_message [57851,57862]
name: log_message [57985,57996]
===
match
---
expr_stmt [60598,60669]
expr_stmt [60732,60803]
===
match
---
simple_stmt [26023,26338]
simple_stmt [26023,26338]
===
match
---
decorator [20615,20632]
decorator [20615,20632]
===
match
---
trailer [55239,55248]
trailer [55239,55248]
===
match
---
suite [11156,12462]
suite [11156,12462]
===
match
---
trailer [61267,61286]
trailer [61401,61420]
===
match
---
simple_stmt [77681,77696]
simple_stmt [77815,77830]
===
match
---
name: signal [48513,48519]
name: signal [48513,48519]
===
match
---
name: XCom [23974,23978]
name: XCom [23974,23978]
===
match
---
trailer [39225,39236]
trailer [39225,39236]
===
match
---
atom_expr [64284,64350]
atom_expr [64418,64484]
===
match
---
name: item [62905,62909]
name: item [63039,63043]
===
match
---
name: session [39815,39822]
name: session [39815,39822]
===
match
---
simple_stmt [80961,80979]
simple_stmt [81095,81113]
===
match
---
import_as_names [1667,1825]
import_as_names [1667,1825]
===
match
---
if_stmt [40829,40879]
if_stmt [40829,40879]
===
match
---
name: Any [64117,64120]
name: Any [64251,64254]
===
match
---
suite [77220,77593]
suite [77354,77727]
===
match
---
testlist [72150,72189]
testlist [72284,72323]
===
match
---
trailer [26065,26073]
trailer [26065,26073]
===
match
---
arglist [24713,24759]
arglist [24713,24759]
===
match
---
string: 'Host: {{ti.hostname}}<br>' [70113,70140]
string: 'Host: {{ti.hostname}}<br>' [70247,70274]
===
match
---
name: self [33221,33225]
name: self [33221,33225]
===
match
---
operator: = [82507,82508]
operator: = [82641,82642]
===
match
---
string: 'end_date' [43887,43897]
string: 'end_date' [43887,43897]
===
match
---
name: sqlalchemy [1280,1290]
name: sqlalchemy [1280,1290]
===
match
---
funcdef [62719,62771]
funcdef [62853,62905]
===
match
---
name: task [65348,65352]
name: task [65482,65486]
===
match
---
name: e [43430,43431]
name: e [43430,43431]
===
match
---
simple_stmt [49513,49555]
simple_stmt [49513,49555]
===
match
---
decorator [41524,41541]
decorator [41524,41541]
===
match
---
name: bool [15842,15846]
name: bool [15842,15846]
===
match
---
tfpdef [16011,16030]
tfpdef [16011,16030]
===
match
---
operator: = [59640,59641]
operator: = [59774,59775]
===
match
---
trailer [62005,62014]
trailer [62139,62148]
===
match
---
number: 1000 [10189,10193]
number: 1000 [10189,10193]
===
match
---
atom_expr [6000,6010]
atom_expr [6000,6010]
===
match
---
atom_expr [54852,54861]
atom_expr [54852,54861]
===
match
---
expr_stmt [5989,6010]
expr_stmt [5989,6010]
===
match
---
arglist [6843,6896]
arglist [6843,6896]
===
match
---
atom_expr [41767,41780]
atom_expr [41767,41780]
===
match
---
trailer [44548,44556]
trailer [44548,44556]
===
match
---
simple_stmt [40465,40494]
simple_stmt [40465,40494]
===
match
---
atom_expr [22455,22468]
atom_expr [22455,22468]
===
match
---
simple_stmt [805,820]
simple_stmt [805,820]
===
match
---
name: plugins_manager [2138,2153]
name: plugins_manager [2138,2153]
===
match
---
name: ignore_all_deps [37657,37672]
name: ignore_all_deps [37657,37672]
===
match
---
name: filter [35374,35380]
name: filter [35374,35380]
===
match
---
name: result [51722,51728]
name: result [51722,51728]
===
match
---
atom_expr [77353,77365]
atom_expr [77487,77499]
===
match
---
operator: { [64367,64368]
operator: { [64501,64502]
===
match
---
name: Column [9995,10001]
name: Column [9995,10001]
===
match
---
funcdef [71608,71897]
funcdef [71742,72031]
===
match
---
funcdef [72195,72549]
funcdef [72329,72683]
===
match
---
name: context [43022,43029]
name: context [43022,43029]
===
match
---
atom_expr [13211,13227]
atom_expr [13211,13227]
===
match
---
atom_expr [60141,60274]
atom_expr [60275,60408]
===
match
---
name: exc_info [50069,50077]
name: exc_info [50069,50077]
===
match
---
param [73004,73028]
param [73138,73162]
===
match
---
name: self [63883,63887]
name: self [64017,64021]
===
match
---
string: 'logging' [19042,19051]
string: 'logging' [19042,19051]
===
match
---
trailer [39196,39207]
trailer [39196,39207]
===
match
---
atom_expr [32802,32819]
atom_expr [32802,32819]
===
match
---
name: qry [82063,82066]
name: qry [82197,82200]
===
match
---
operator: -> [73035,73037]
operator: -> [73169,73171]
===
match
---
simple_stmt [33213,33243]
simple_stmt [33213,33243]
===
match
---
name: engine [41020,41026]
name: engine [41020,41026]
===
match
---
operator: , [65819,65820]
operator: , [65953,65954]
===
match
---
suite [78492,78708]
suite [78626,78842]
===
match
---
import_from [1464,1506]
import_from [1464,1506]
===
match
---
expr_stmt [57851,57890]
expr_stmt [57985,58024]
===
match
---
name: and_ [1349,1353]
name: and_ [1349,1353]
===
match
---
trailer [40258,40273]
trailer [40258,40273]
===
match
---
name: utils [2575,2580]
name: utils [2575,2580]
===
match
---
atom_expr [6630,7122]
atom_expr [6630,7122]
===
match
---
name: task [72421,72425]
name: task [72555,72559]
===
match
---
atom_expr [63310,63353]
atom_expr [63444,63487]
===
match
---
trailer [5346,5354]
trailer [5346,5354]
===
match
---
trailer [40866,40872]
trailer [40866,40872]
===
match
---
name: AirflowRescheduleException [43929,43955]
name: AirflowRescheduleException [43929,43955]
===
match
---
trailer [24076,24078]
trailer [24076,24078]
===
match
---
operator: , [64301,64302]
operator: , [64435,64436]
===
match
---
trailer [7411,7414]
trailer [7411,7414]
===
match
---
suite [7869,7953]
suite [7869,7953]
===
match
---
arglist [64297,64349]
arglist [64431,64483]
===
match
---
atom_expr [81854,81873]
atom_expr [81988,82007]
===
match
---
trailer [30246,30266]
trailer [30246,30266]
===
match
---
name: models [2039,2045]
name: models [2039,2045]
===
match
---
operator: , [39805,39806]
operator: , [39805,39806]
===
match
---
name: log [40470,40473]
name: log [40470,40473]
===
match
---
name: dag_run [62427,62434]
name: dag_run [62561,62568]
===
match
---
trailer [40752,40760]
trailer [40752,40760]
===
match
---
atom_expr [10047,10089]
atom_expr [10047,10089]
===
match
---
name: self [25123,25127]
name: self [25123,25127]
===
match
---
try_stmt [58543,58775]
try_stmt [58677,58909]
===
match
---
operator: = [67132,67133]
operator: = [67266,67267]
===
match
---
name: execution_date [8074,8088]
name: execution_date [8074,8088]
===
match
---
name: email_on_failure [57926,57942]
name: email_on_failure [58060,58076]
===
match
---
param [11095,11100]
param [11095,11100]
===
match
---
trailer [21752,21767]
trailer [21752,21767]
===
match
---
operator: -= [55831,55833]
operator: -= [55831,55833]
===
match
---
name: task_copy [51071,51080]
name: task_copy [51071,51080]
===
match
---
name: self [51754,51758]
name: self [51754,51758]
===
match
---
operator: , [46103,46104]
operator: , [46103,46104]
===
match
---
return_stmt [59530,59557]
return_stmt [59664,59691]
===
match
---
atom [18206,18231]
atom [18206,18231]
===
match
---
trailer [25042,25056]
trailer [25042,25056]
===
match
---
atom_expr [9867,9882]
atom_expr [9867,9882]
===
match
---
name: self [45199,45203]
name: self [45199,45203]
===
match
---
atom_expr [40465,40493]
atom_expr [40465,40493]
===
match
---
trailer [22535,22540]
trailer [22535,22540]
===
match
---
trailer [23994,24002]
trailer [23994,24002]
===
match
---
operator: } [47115,47116]
operator: } [47115,47116]
===
match
---
simple_stmt [55651,55688]
simple_stmt [55651,55688]
===
match
---
string: "task" [47334,47340]
string: "task" [47334,47340]
===
match
---
name: load_error_file [54657,54672]
name: load_error_file [54657,54672]
===
match
---
name: self [23849,23853]
name: self [23849,23853]
===
match
---
string: "%s dependency '%s' PASSED: %s, %s" [32578,32613]
string: "%s dependency '%s' PASSED: %s, %s" [32578,32613]
===
match
---
trailer [24893,24899]
trailer [24893,24899]
===
match
---
name: ignore_ti_state [18493,18508]
name: ignore_ti_state [18493,18508]
===
match
---
operator: , [10807,10808]
operator: , [10807,10808]
===
match
---
name: ti [79785,79787]
name: ti [79919,79921]
===
match
---
param [59055,59068]
param [59189,59202]
===
match
---
trailer [52804,52812]
trailer [52804,52812]
===
match
---
trailer [26395,26415]
trailer [26395,26415]
===
match
---
name: SHUTDOWN [7474,7482]
name: SHUTDOWN [7474,7482]
===
match
---
operator: , [1093,1094]
operator: , [1093,1094]
===
match
---
name: log [31726,31729]
name: log [31726,31729]
===
match
---
trailer [34548,34550]
trailer [34548,34550]
===
match
---
name: _task_id [81932,81940]
name: _task_id [82066,82074]
===
match
---
trailer [29679,29694]
trailer [29679,29694]
===
match
---
operator: = [30762,30763]
operator: = [30762,30763]
===
match
---
simple_stmt [20675,20838]
simple_stmt [20675,20838]
===
match
---
name: self [50809,50813]
name: self [50809,50813]
===
match
---
expr_stmt [31645,31659]
expr_stmt [31645,31659]
===
match
---
name: XCOM_RETURN_KEY [74408,74423]
name: XCOM_RETURN_KEY [74542,74557]
===
match
---
simple_stmt [7312,7354]
simple_stmt [7312,7354]
===
match
---
try_stmt [51306,51547]
try_stmt [51306,51547]
===
match
---
operator: = [15348,15349]
operator: = [15348,15349]
===
match
---
name: queued_by_job [82547,82560]
name: queued_by_job [82681,82694]
===
match
---
expr_stmt [78112,78133]
expr_stmt [78246,78267]
===
match
---
name: actual_start_date [55057,55074]
name: actual_start_date [55057,55074]
===
match
---
name: Context [3347,3354]
name: Context [3347,3354]
===
match
---
atom_expr [59921,59941]
atom_expr [60055,60075]
===
match
---
return_stmt [34732,34760]
return_stmt [34732,34760]
===
match
---
trailer [72415,72455]
trailer [72549,72589]
===
match
---
comparison [20408,20458]
comparison [20408,20458]
===
match
---
name: PodGenerator [68193,68205]
name: PodGenerator [68327,68339]
===
match
---
atom_expr [25340,25358]
atom_expr [25340,25358]
===
match
---
name: self [70710,70714]
name: self [70844,70848]
===
match
---
trailer [81813,81819]
trailer [81947,81953]
===
match
---
decorated [80600,80680]
decorated [80734,80814]
===
match
---
classdef [63363,64351]
classdef [63497,64485]
===
match
---
atom_expr [43761,43798]
atom_expr [43761,43798]
===
match
---
suite [12509,12647]
suite [12509,12647]
===
match
---
atom_expr [25964,25988]
atom_expr [25964,25988]
===
match
---
name: task_id [11231,11238]
name: task_id [11231,11238]
===
match
---
trailer [71657,71668]
trailer [71791,71802]
===
match
---
name: Optional [41689,41697]
name: Optional [41689,41697]
===
match
---
operator: , [65387,65388]
operator: , [65521,65522]
===
match
---
trailer [67295,67297]
trailer [67429,67431]
===
match
---
name: execution_date [80525,80539]
name: execution_date [80659,80673]
===
match
---
atom_expr [50774,50784]
atom_expr [50774,50784]
===
match
---
operator: , [62848,62849]
operator: , [62982,62983]
===
match
---
tfpdef [8602,8617]
tfpdef [8602,8617]
===
match
---
name: self [68014,68018]
name: self [68148,68152]
===
match
---
return_stmt [81281,81309]
return_stmt [81415,81443]
===
match
---
name: self [11226,11230]
name: self [11226,11230]
===
match
---
atom_expr [33571,33634]
atom_expr [33571,33634]
===
match
---
name: provide_session [29098,29113]
name: provide_session [29098,29113]
===
match
---
name: ti [22035,22037]
name: ti [22035,22037]
===
match
---
simple_stmt [63876,63892]
simple_stmt [64010,64026]
===
match
---
simple_stmt [19081,19140]
simple_stmt [19081,19140]
===
match
---
trailer [77836,77855]
trailer [77970,77989]
===
match
---
operator: } [62186,62187]
operator: } [62320,62321]
===
match
---
param [63155,63214]
param [63289,63348]
===
match
---
name: Integer [10290,10297]
name: Integer [10290,10297]
===
match
---
simple_stmt [52966,53000]
simple_stmt [52966,53000]
===
match
---
operator: = [76225,76226]
operator: = [76359,76360]
===
match
---
trailer [11876,11887]
trailer [11876,11887]
===
match
---
operator: , [58969,58970]
operator: , [59103,59104]
===
match
---
operator: @ [81154,81155]
operator: @ [81288,81289]
===
match
---
trailer [11309,11315]
trailer [11309,11315]
===
match
---
name: executor_config [10303,10318]
name: executor_config [10303,10318]
===
match
---
name: self [31691,31695]
name: self [31691,31695]
===
match
---
expr_stmt [53143,53180]
expr_stmt [53143,53180]
===
match
---
simple_stmt [11226,11254]
simple_stmt [11226,11254]
===
match
---
atom_expr [61416,61456]
atom_expr [61550,61590]
===
match
---
arglist [32496,32522]
arglist [32496,32522]
===
match
---
trailer [7387,7396]
trailer [7387,7396]
===
match
---
trailer [64418,64422]
trailer [64552,64556]
===
match
---
name: var [63812,63815]
name: var [63946,63949]
===
match
---
name: List [16088,16092]
name: List [16088,16092]
===
match
---
parameters [77618,77635]
parameters [77752,77769]
===
match
---
name: int [15884,15887]
name: int [15884,15887]
===
match
---
atom_expr [11262,11271]
atom_expr [11262,11271]
===
match
---
name: Dict [1061,1065]
name: Dict [1061,1065]
===
match
---
name: pool_override [37450,37463]
name: pool_override [37450,37463]
===
match
---
name: run_as_user [23461,23472]
name: run_as_user [23461,23472]
===
match
---
simple_stmt [2505,2562]
simple_stmt [2505,2562]
===
match
---
atom_expr [5989,5997]
atom_expr [5989,5997]
===
match
---
atom_expr [67977,68004]
atom_expr [68111,68138]
===
match
---
operator: , [30764,30765]
operator: , [30764,30765]
===
match
---
expr_stmt [30141,30201]
expr_stmt [30141,30201]
===
match
---
name: result [50509,50515]
name: result [50509,50515]
===
match
---
name: configuration [1604,1617]
name: configuration [1604,1617]
===
match
---
expr_stmt [69238,69291]
expr_stmt [69372,69425]
===
match
---
name: task_type [23592,23601]
name: task_type [23592,23601]
===
match
---
atom_expr [9810,9850]
atom_expr [9810,9850]
===
match
---
name: Any [3208,3211]
name: Any [3208,3211]
===
match
---
name: self [39192,39196]
name: self [39192,39196]
===
match
---
operator: = [60228,60229]
operator: = [60362,60363]
===
match
---
trailer [48950,48958]
trailer [48950,48958]
===
match
---
operator: = [18962,18963]
operator: = [18962,18963]
===
match
---
simple_stmt [2026,2071]
simple_stmt [2026,2071]
===
match
---
name: dag_id [45179,45185]
name: dag_id [45179,45185]
===
match
---
name: task_id [68265,68272]
name: task_id [68399,68406]
===
match
---
operator: , [14074,14075]
operator: , [14074,14075]
===
match
---
name: value [72933,72938]
name: value [73067,73072]
===
match
---
comparison [78581,78626]
comparison [78715,78760]
===
match
---
name: self [63918,63922]
name: self [64052,64056]
===
match
---
trailer [46041,46049]
trailer [46041,46049]
===
match
---
atom_expr [47069,47098]
atom_expr [47069,47098]
===
match
---
name: BaseJob [7346,7353]
name: BaseJob [7346,7353]
===
match
---
arglist [8739,8797]
arglist [8739,8797]
===
match
---
atom_expr [54638,54651]
atom_expr [54638,54651]
===
match
---
trailer [18451,18481]
trailer [18451,18481]
===
match
---
name: prev_ti [30141,30148]
name: prev_ti [30141,30148]
===
match
---
name: ti [6095,6097]
name: ti [6095,6097]
===
match
---
expr_stmt [68845,68904]
expr_stmt [68979,69038]
===
match
---
trailer [10115,10120]
trailer [10115,10120]
===
match
---
operator: , [72923,72924]
operator: , [73057,73058]
===
match
---
subscriptlist [74322,74340]
subscriptlist [74456,74474]
===
match
---
trailer [50334,50343]
trailer [50334,50343]
===
match
---
atom_expr [15981,15994]
atom_expr [15981,15994]
===
match
---
name: dep_context [38462,38473]
name: dep_context [38462,38473]
===
match
---
trailer [71238,71259]
trailer [71372,71393]
===
match
---
except_clause [43922,43979]
except_clause [43922,43979]
===
match
---
name: task_id_by_key [6050,6064]
name: task_id_by_key [6050,6064]
===
match
---
name: e [49854,49855]
name: e [49854,49855]
===
match
---
expr_stmt [22786,22803]
expr_stmt [22786,22803]
===
match
---
name: self [27280,27284]
name: self [27280,27284]
===
match
---
trailer [61501,61510]
trailer [61635,61644]
===
match
---
name: test_mode [65468,65477]
name: test_mode [65602,65611]
===
match
---
name: State [5183,5188]
name: State [5183,5188]
===
match
---
operator: = [82561,82562]
operator: = [82695,82696]
===
match
---
name: self [19386,19390]
name: self [19386,19390]
===
match
---
number: 1 [70677,70678]
number: 1 [70811,70812]
===
match
---
trailer [51381,51383]
trailer [51381,51383]
===
match
---
name: prev_ti [29566,29573]
name: prev_ti [29566,29573]
===
match
---
atom_expr [33581,33602]
atom_expr [33581,33602]
===
match
---
name: self [42976,42980]
name: self [42976,42980]
===
match
---
argument [78420,78490]
argument [78554,78624]
===
match
---
name: quote [19231,19236]
name: quote [19231,19236]
===
match
---
name: unixname [22460,22468]
name: unixname [22460,22468]
===
match
---
name: dag_id [14967,14973]
name: dag_id [14967,14973]
===
match
---
trailer [17944,17954]
trailer [17944,17954]
===
match
---
operator: , [29763,29764]
operator: , [29763,29764]
===
match
---
name: cfg_path [15447,15455]
name: cfg_path [15447,15455]
===
match
---
simple_stmt [3361,3535]
simple_stmt [3361,3535]
===
match
---
operator: { [19686,19687]
operator: { [19686,19687]
===
match
---
atom_expr [79590,79599]
atom_expr [79724,79733]
===
match
---
name: extend [18277,18283]
name: extend [18277,18283]
===
match
---
operator: , [39672,39673]
operator: , [39672,39673]
===
match
---
name: task [49549,49553]
name: task [49549,49553]
===
match
---
operator: , [50758,50759]
operator: , [50758,50759]
===
match
---
name: session [45432,45439]
name: session [45432,45439]
===
match
---
name: first [21847,21852]
name: first [21847,21852]
===
match
---
atom_expr [66162,66215]
atom_expr [66296,66349]
===
match
---
annassign [80132,80154]
annassign [80266,80288]
===
match
---
arglist [51769,51802]
arglist [51769,51802]
===
match
---
name: exception [72369,72378]
name: exception [72503,72512]
===
match
---
param [19898,19910]
param [19898,19910]
===
match
---
trailer [80115,80132]
trailer [80249,80266]
===
match
---
trailer [58679,58683]
trailer [58813,58817]
===
match
---
atom_expr [80134,80147]
atom_expr [80268,80281]
===
match
---
atom_expr [47190,47200]
atom_expr [47190,47200]
===
match
---
name: exception [50056,50065]
name: exception [50056,50065]
===
match
---
name: DagRun [7635,7641]
name: DagRun [7635,7641]
===
match
---
name: jinja2 [1169,1175]
name: jinja2 [1169,1175]
===
match
---
atom_expr [26391,26415]
atom_expr [26391,26415]
===
match
---
expr_stmt [23519,23562]
expr_stmt [23519,23562]
===
match
---
operator: , [64422,64423]
operator: , [64556,64557]
===
match
---
name: test_mode [53599,53608]
name: test_mode [53599,53608]
===
match
---
name: warning [39952,39959]
name: warning [39952,39959]
===
match
---
if_stmt [51983,52062]
if_stmt [51983,52062]
===
match
---
name: default_subject [70952,70967]
name: default_subject [71086,71101]
===
match
---
trailer [72504,72548]
trailer [72638,72682]
===
match
---
operator: , [56064,56065]
operator: , [56064,56065]
===
match
---
name: ignore_all_deps [15101,15116]
name: ignore_all_deps [15101,15116]
===
match
---
name: kube_config [68755,68766]
name: kube_config [68889,68900]
===
match
---
simple_stmt [66130,66216]
simple_stmt [66264,66350]
===
match
---
atom_expr [47367,47386]
atom_expr [47367,47386]
===
match
---
tfpdef [74297,74342]
tfpdef [74431,74476]
===
match
---
name: on_kill [51515,51522]
name: on_kill [51515,51522]
===
match
---
string: "exception" [53205,53216]
string: "exception" [53205,53216]
===
match
---
name: String [10389,10395]
name: String [10389,10395]
===
match
---
trailer [62234,62241]
trailer [62368,62375]
===
match
---
suite [62351,62436]
suite [62485,62570]
===
match
---
atom_expr [5297,5306]
atom_expr [5297,5306]
===
match
---
name: execution_date [27291,27305]
name: execution_date [27291,27305]
===
match
---
simple_stmt [41463,41501]
simple_stmt [41463,41501]
===
match
---
name: ti [22581,22583]
name: ti [22581,22583]
===
match
---
atom_expr [72645,72660]
atom_expr [72779,72794]
===
match
---
name: session [35339,35346]
name: session [35339,35346]
===
match
---
dotted_name [2938,2968]
dotted_name [2938,2968]
===
match
---
import_from [2252,2302]
import_from [2252,2302]
===
match
---
name: session [40343,40350]
name: session [40343,40350]
===
match
---
atom_expr [11192,11203]
atom_expr [11192,11203]
===
match
---
operator: = [15889,15890]
operator: = [15889,15890]
===
match
---
name: self [29050,29054]
name: self [29050,29054]
===
match
---
name: var [63008,63011]
name: var [63142,63145]
===
match
---
operator: = [55107,55108]
operator: = [55107,55108]
===
match
---
name: add [56944,56947]
name: add [57078,57081]
===
match
---
name: execution_date [7046,7060]
name: execution_date [7046,7060]
===
match
---
name: qry [81800,81803]
name: qry [81934,81937]
===
match
---
name: property [30273,30281]
name: property [30273,30281]
===
match
---
fstring_expr [19724,19737]
fstring_expr [19724,19737]
===
match
---
name: State [37715,37720]
name: State [37715,37720]
===
match
---
operator: == [77424,77426]
operator: == [77558,77560]
===
match
---
trailer [40510,40515]
trailer [40510,40515]
===
match
---
name: append [3556,3562]
name: append [3556,3562]
===
match
---
operator: = [70709,70710]
operator: = [70843,70844]
===
match
---
simple_stmt [49150,49318]
simple_stmt [49150,49318]
===
match
---
name: Variable [62892,62900]
name: Variable [63026,63034]
===
match
---
name: html_content [72305,72317]
name: html_content [72439,72451]
===
match
---
operator: = [65114,65115]
operator: = [65248,65249]
===
match
---
atom_expr [79870,79878]
atom_expr [80004,80012]
===
match
---
atom_expr [23974,23986]
atom_expr [23974,23986]
===
match
---
funcdef [24396,25087]
funcdef [24396,25087]
===
match
---
param [41612,41639]
param [41612,41639]
===
match
---
name: self [35398,35402]
name: self [35398,35402]
===
match
---
parameters [19170,19176]
parameters [19170,19176]
===
match
---
atom_expr [24353,24368]
atom_expr [24353,24368]
===
match
---
name: self [50711,50715]
name: self [50711,50715]
===
match
---
name: are_dependencies_met [39761,39781]
name: are_dependencies_met [39761,39781]
===
match
---
atom_expr [48699,48716]
atom_expr [48699,48716]
===
match
---
name: ignore_depends_on_past [35707,35729]
name: ignore_depends_on_past [35707,35729]
===
match
---
name: get_template_context [52927,52947]
name: get_template_context [52927,52947]
===
match
---
name: self [53066,53070]
name: self [53066,53070]
===
match
---
operator: = [57760,57761]
operator: = [57894,57895]
===
match
---
atom_expr [52139,52195]
atom_expr [52139,52195]
===
match
---
name: refresh_from_task [42594,42611]
name: refresh_from_task [42594,42611]
===
match
---
trailer [56685,56692]
trailer [56819,56826]
===
match
---
string: "Starting attempt %s of %s" [40516,40543]
string: "Starting attempt %s of %s" [40516,40543]
===
match
---
operator: == [52796,52798]
operator: == [52796,52798]
===
match
---
name: modded_hash [34051,34062]
name: modded_hash [34051,34062]
===
match
---
operator: , [58294,58295]
operator: , [58428,58429]
===
match
---
operator: , [8505,8506]
operator: , [8505,8506]
===
match
---
trailer [8498,8505]
trailer [8498,8505]
===
match
---
string: 'Log: <a href="{{ti.log_url}}">Link</a><br>' [69658,69702]
string: 'Log: <a href="{{ti.log_url}}">Link</a><br>' [69792,69836]
===
match
---
trailer [58447,58476]
trailer [58581,58610]
===
match
---
name: task_id [8757,8764]
name: task_id [8757,8764]
===
match
---
name: task [11708,11712]
name: task [11708,11712]
===
match
---
simple_stmt [57969,58001]
simple_stmt [58103,58135]
===
match
---
string: '-' [61502,61505]
string: '-' [61636,61639]
===
match
---
arglist [28814,29024]
arglist [28814,29024]
===
match
---
name: task [55401,55405]
name: task [55401,55405]
===
match
---
simple_stmt [42589,42638]
simple_stmt [42589,42638]
===
match
---
name: dag_id [48690,48696]
name: dag_id [48690,48696]
===
match
---
name: qry [21825,21828]
name: qry [21825,21828]
===
match
---
name: info [45032,45036]
name: info [45032,45036]
===
match
---
name: debug [23858,23863]
name: debug [23858,23863]
===
match
---
operator: ** [33608,33610]
operator: ** [33608,33610]
===
match
---
atom_expr [50711,50765]
atom_expr [50711,50765]
===
match
---
name: base_url [19567,19575]
name: base_url [19567,19575]
===
match
---
parameters [53307,53725]
parameters [53307,53725]
===
match
---
name: str [79584,79587]
name: str [79718,79721]
===
match
---
trailer [71816,71818]
trailer [71950,71952]
===
match
---
expr_stmt [61523,61583]
expr_stmt [61657,61717]
===
match
---
name: add [56867,56870]
name: add [57001,57004]
===
match
---
funcdef [4683,7953]
funcdef [4683,7953]
===
match
---
trailer [48344,48350]
trailer [48344,48350]
===
match
---
name: str [15588,15591]
name: str [15588,15591]
===
match
---
except_clause [52070,52093]
except_clause [52070,52093]
===
match
---
name: dag_id [79076,79082]
name: dag_id [79210,79216]
===
match
---
atom_expr [52208,52231]
atom_expr [52208,52231]
===
match
---
name: iso [19514,19517]
name: iso [19514,19517]
===
match
---
simple_stmt [26574,26803]
simple_stmt [26574,26803]
===
match
---
trailer [80081,80087]
trailer [80215,80221]
===
match
---
name: execution_date [11658,11672]
name: execution_date [11658,11672]
===
match
---
name: self [45323,45327]
name: self [45323,45327]
===
match
---
trailer [74321,74341]
trailer [74455,74475]
===
match
---
name: self [42932,42936]
name: self [42932,42936]
===
match
---
trailer [6030,6036]
trailer [6030,6036]
===
match
---
name: TaskInstance [79547,79559]
name: TaskInstance [79681,79693]
===
match
---
trailer [68510,68512]
trailer [68644,68646]
===
match
---
decorated [3287,3897]
decorated [3287,3897]
===
match
---
name: quote [1143,1148]
name: quote [1143,1148]
===
match
---
simple_stmt [43416,43433]
simple_stmt [43416,43433]
===
match
---
name: queued_dttm [22762,22773]
name: queued_dttm [22762,22773]
===
match
---
operator: @ [25395,25396]
operator: @ [25395,25396]
===
match
---
if_stmt [18241,18315]
if_stmt [18241,18315]
===
match
---
atom_expr [37715,37728]
atom_expr [37715,37728]
===
match
---
name: default_html_content_err [72108,72132]
name: default_html_content_err [72242,72266]
===
match
---
trailer [42666,42683]
trailer [42666,42683]
===
match
---
atom_expr [25367,25389]
atom_expr [25367,25389]
===
match
---
expr_stmt [6600,7188]
expr_stmt [6600,7188]
===
match
---
name: get [62901,62904]
name: get [63035,63038]
===
match
---
parameters [68084,68090]
parameters [68218,68224]
===
match
---
name: log [58680,58683]
name: log [58814,58817]
===
match
---
name: __repr__ [32867,32875]
name: __repr__ [32867,32875]
===
match
---
name: hr_line_break [40604,40617]
name: hr_line_break [40604,40617]
===
match
---
simple_stmt [54950,54974]
simple_stmt [54950,54974]
===
match
---
name: provide_session [19854,19869]
name: provide_session [19854,19869]
===
match
---
name: filter [77380,77386]
name: filter [77514,77520]
===
match
---
operator: @ [23607,23608]
operator: @ [23607,23608]
===
match
---
name: dag_id [11010,11016]
name: dag_id [11010,11016]
===
match
---
tfpdef [29765,29785]
tfpdef [29765,29785]
===
match
---
param [26507,26530]
param [26507,26530]
===
match
---
name: FAILED [56881,56887]
name: FAILED [57015,57021]
===
match
---
funcdef [48254,48497]
funcdef [48254,48497]
===
match
---
name: ignore_all_deps [14112,14127]
name: ignore_all_deps [14112,14127]
===
match
---
param [53632,53661]
param [53632,53661]
===
match
---
argument [39111,39126]
argument [39111,39126]
===
match
---
atom_expr [79648,79668]
atom_expr [79782,79802]
===
match
---
name: self [50682,50686]
name: self [50682,50686]
===
match
---
name: executor_namespace [68671,68689]
name: executor_namespace [68805,68823]
===
match
---
trailer [50715,50719]
trailer [50715,50719]
===
match
---
name: State [34949,34954]
name: State [34949,34954]
===
match
---
simple_stmt [10238,10273]
simple_stmt [10238,10273]
===
match
---
name: duration [72842,72850]
name: duration [72976,72984]
===
match
---
trailer [35469,35475]
trailer [35469,35475]
===
match
---
except_clause [43139,43178]
except_clause [43139,43178]
===
match
---
name: _run_raw_task [54337,54350]
name: _run_raw_task [54337,54350]
===
match
---
atom_expr [81954,81981]
atom_expr [82088,82115]
===
match
---
param [81018,81022]
param [81152,81156]
===
match
---
simple_stmt [44298,44304]
simple_stmt [44298,44304]
===
match
---
atom_expr [67386,67461]
atom_expr [67520,67595]
===
match
---
name: get_template_context [59606,59626]
name: get_template_context [59740,59760]
===
match
---
name: delete [7224,7230]
name: delete [7224,7230]
===
match
---
name: total_seconds [51368,51381]
name: total_seconds [51368,51381]
===
match
---
atom [5058,5060]
atom [5058,5060]
===
match
---
trailer [19241,19256]
trailer [19241,19256]
===
match
---
trailer [78670,78678]
trailer [78804,78812]
===
match
---
string: 'Failed to send email to: %s' [58690,58719]
string: 'Failed to send email to: %s' [58824,58853]
===
match
---
argument [15281,15292]
argument [15281,15292]
===
match
---
operator: = [16071,16072]
operator: = [16071,16072]
===
match
---
simple_stmt [12370,12387]
simple_stmt [12370,12387]
===
match
---
name: pool [15420,15424]
name: pool [15420,15424]
===
match
---
atom_expr [68805,68836]
atom_expr [68939,68970]
===
match
---
simple_stmt [26002,26014]
simple_stmt [26002,26014]
===
match
---
name: execution_date [20444,20458]
name: execution_date [20444,20458]
===
match
---
name: execution_date [10754,10768]
name: execution_date [10754,10768]
===
match
---
name: values_ordered_by_id [76888,76908]
name: values_ordered_by_id [77022,77042]
===
match
---
name: self [37478,37482]
name: self [37478,37482]
===
match
---
atom_expr [39943,40225]
atom_expr [39943,40225]
===
match
---
operator: , [14165,14166]
operator: , [14165,14166]
===
match
---
name: task [61259,61263]
name: task [61393,61397]
===
match
---
simple_stmt [30141,30202]
simple_stmt [30141,30202]
===
match
---
name: hasattr [59921,59928]
name: hasattr [60055,60062]
===
match
---
param [56116,56141]
param [56116,56141]
===
match
---
trailer [24043,24058]
trailer [24043,24058]
===
match
---
name: jinja2 [1222,1228]
name: jinja2 [1222,1228]
===
match
---
name: session [56859,56866]
name: session [56993,57000]
===
match
---
atom_expr [41266,41275]
atom_expr [41266,41275]
===
match
---
name: task_retries [5580,5592]
name: task_retries [5580,5592]
===
match
---
name: session [40887,40894]
name: session [40887,40894]
===
match
---
operator: = [63816,63817]
operator: = [63950,63951]
===
match
---
name: self [81266,81270]
name: self [81400,81404]
===
match
---
simple_stmt [49877,50027]
simple_stmt [49877,50027]
===
match
---
operator: , [50067,50068]
operator: , [50067,50068]
===
match
---
simple_stmt [56313,56340]
simple_stmt [56313,56340]
===
match
---
name: Context [3237,3244]
name: Context [3237,3244]
===
match
---
trailer [77537,77545]
trailer [77671,77679]
===
match
---
operator: = [69202,69203]
operator: = [69336,69337]
===
match
---
name: queue [23276,23281]
name: queue [23276,23281]
===
match
---
operator: = [50508,50509]
operator: = [50508,50509]
===
match
---
trailer [60657,60669]
trailer [60791,60803]
===
match
---
name: self [23290,23294]
name: self [23290,23294]
===
match
---
if_stmt [25957,26014]
if_stmt [25957,26014]
===
match
---
operator: , [15786,15787]
operator: , [15786,15787]
===
match
---
name: self [66966,66970]
name: self [67100,67104]
===
match
---
suite [8185,8311]
suite [8185,8311]
===
match
---
expr_stmt [79943,79982]
expr_stmt [80077,80116]
===
match
---
atom_expr [80309,80315]
atom_expr [80443,80449]
===
match
---
atom_expr [34972,34998]
atom_expr [34972,34998]
===
match
---
operator: , [7145,7146]
operator: , [7145,7146]
===
match
---
operator: = [11058,11059]
operator: = [11058,11059]
===
match
---
operator: + [40203,40204]
operator: + [40203,40204]
===
match
---
atom_expr [40562,40576]
atom_expr [40562,40576]
===
match
---
name: self [34635,34639]
name: self [34635,34639]
===
match
---
simple_stmt [44116,44123]
simple_stmt [44116,44123]
===
match
---
expr_stmt [22455,22482]
expr_stmt [22455,22482]
===
match
---
comp_op [52610,52616]
comp_op [52610,52616]
===
match
---
operator: = [37541,37542]
operator: = [37541,37542]
===
match
---
arglist [72810,72850]
arglist [72944,72984]
===
match
---
name: self [24796,24800]
name: self [24796,24800]
===
match
---
expr_stmt [79758,79796]
expr_stmt [79892,79930]
===
match
---
name: deserialize_json [64328,64344]
name: deserialize_json [64462,64478]
===
match
---
operator: = [43115,43116]
operator: = [43115,43116]
===
match
---
atom_expr [40590,40618]
atom_expr [40590,40618]
===
match
---
atom_expr [25326,25336]
atom_expr [25326,25336]
===
match
---
operator: = [67269,67270]
operator: = [67403,67404]
===
match
---
name: AirflowException [48448,48464]
name: AirflowException [48448,48464]
===
match
---
simple_stmt [70492,70758]
simple_stmt [70626,70892]
===
match
---
param [11089,11094]
param [11089,11094]
===
match
---
operator: { [50558,50559]
operator: { [50558,50559]
===
match
---
name: property [80767,80775]
name: property [80901,80909]
===
match
---
name: log [23854,23857]
name: log [23854,23857]
===
match
---
trailer [11142,11147]
trailer [11142,11147]
===
match
---
param [63077,63087]
param [63211,63221]
===
match
---
and_test [34935,35018]
and_test [34935,35018]
===
match
---
trailer [52674,52676]
trailer [52674,52676]
===
match
---
name: self [24112,24116]
name: self [24112,24116]
===
match
---
operator: = [54516,54517]
operator: = [54516,54517]
===
match
---
name: Union [74316,74321]
name: Union [74450,74455]
===
match
---
name: session [47954,47961]
name: session [47954,47961]
===
match
---
name: failed [31846,31852]
name: failed [31846,31852]
===
match
---
trailer [20420,20435]
trailer [20420,20435]
===
match
---
suite [28110,28553]
suite [28110,28553]
===
match
---
arglist [61778,61785]
arglist [61912,61919]
===
match
---
suite [43269,43914]
suite [43269,43914]
===
match
---
name: self [37581,37585]
name: self [37581,37585]
===
match
---
simple_stmt [45508,45525]
simple_stmt [45508,45525]
===
match
---
string: """Set TI duration""" [72594,72615]
string: """Set TI duration""" [72728,72749]
===
match
---
atom_expr [47010,47030]
atom_expr [47010,47030]
===
match
---
argument [65262,65281]
argument [65396,65415]
===
match
---
name: result [51573,51579]
name: result [51573,51579]
===
match
---
operator: } [67458,67459]
operator: } [67592,67593]
===
match
---
name: execution_date [68457,68471]
name: execution_date [68591,68605]
===
match
---
atom_expr [43445,43487]
atom_expr [43445,43487]
===
match
---
if_stmt [21788,21898]
if_stmt [21788,21898]
===
match
---
operator: = [35690,35691]
operator: = [35690,35691]
===
match
---
name: date_attr [59470,59479]
name: date_attr [59604,59613]
===
match
---
name: hr_line_break [40479,40492]
name: hr_line_break [40479,40492]
===
match
---
name: Optional [77828,77836]
name: Optional [77962,77970]
===
match
---
trailer [22704,22713]
trailer [22704,22713]
===
match
---
expr_stmt [24796,24845]
expr_stmt [24796,24845]
===
match
---
param [41648,41672]
param [41648,41672]
===
match
---
simple_stmt [72674,72740]
simple_stmt [72808,72874]
===
match
---
decorated [55973,58859]
decorated [55973,58993]
===
match
---
operator: = [13314,13315]
operator: = [13314,13315]
===
match
---
operator: , [24058,24059]
operator: , [24058,24059]
===
match
---
name: ignore_task_deps [15130,15146]
name: ignore_task_deps [15130,15146]
===
match
---
suite [3356,3897]
suite [3356,3897]
===
match
---
operator: , [2365,2366]
operator: , [2365,2366]
===
match
---
name: math [857,861]
name: math [857,861]
===
match
---
operator: = [14159,14160]
operator: = [14159,14160]
===
match
---
name: get [76920,76923]
name: get [77054,77057]
===
match
---
atom_expr [44877,44943]
atom_expr [44877,44943]
===
match
---
string: '%Y-%m-%d' [60658,60668]
string: '%Y-%m-%d' [60792,60802]
===
match
---
trailer [30819,30840]
trailer [30819,30840]
===
match
---
name: task_id [47193,47200]
name: task_id [47193,47200]
===
match
---
arglist [30172,30200]
arglist [30172,30200]
===
match
---
string: """Initialize the attributes that aren't stored in the DB""" [12518,12578]
string: """Initialize the attributes that aren't stored in the DB""" [12518,12578]
===
match
---
operator: - [33628,33629]
operator: - [33628,33629]
===
match
---
operator: , [6671,6672]
operator: , [6671,6672]
===
match
---
operator: == [21745,21747]
operator: == [21745,21747]
===
match
---
name: self [51056,51060]
name: self [51056,51060]
===
match
---
string: "Rescheduling due to concurrency limits reached " [39981,40030]
string: "Rescheduling due to concurrency limits reached " [39981,40030]
===
match
---
operator: == [35395,35397]
operator: == [35395,35397]
===
match
---
dictorsetmaker [46967,47098]
dictorsetmaker [46967,47098]
===
match
---
name: self [52513,52517]
name: self [52513,52517]
===
match
---
param [80870,80874]
param [81004,81008]
===
match
---
param [24175,24179]
param [24175,24179]
===
match
---
decorator [28074,28084]
decorator [28074,28084]
===
match
---
name: DagRun [7680,7686]
name: DagRun [7680,7686]
===
match
---
simple_stmt [23849,23886]
simple_stmt [23849,23886]
===
match
---
trailer [50563,50568]
trailer [50563,50568]
===
match
---
name: task_id [74025,74032]
name: task_id [74159,74166]
===
match
---
trailer [35917,35922]
trailer [35917,35922]
===
match
---
simple_stmt [54982,55002]
simple_stmt [54982,55002]
===
match
---
simple_stmt [1409,1464]
simple_stmt [1409,1464]
===
match
---
simple_stmt [19004,19073]
simple_stmt [19004,19073]
===
match
---
name: AirflowSmartSensorException [50956,50983]
name: AirflowSmartSensorException [50956,50983]
===
match
---
name: job_id [10861,10867]
name: job_id [10861,10867]
===
match
---
name: dag [27115,27118]
name: dag [27115,27118]
===
match
---
string: """             Wrapper around Variable. This way you can get variables in             templates by using ``{{ var.json.variable_name }}`` or             ``{{ var.json.get('variable_name', {'fall': 'back'}) }}``.             """ [63403,63631]
string: """             Wrapper around Variable. This way you can get variables in             templates by using ``{{ var.json.variable_name }}`` or             ``{{ var.json.get('variable_name', {'fall': 'back'}) }}``.             """ [63537,63765]
===
match
---
name: finished [24877,24885]
name: finished [24877,24885]
===
match
---
param [8602,8617]
param [8602,8617]
===
match
---
except_clause [4151,4167]
except_clause [4151,4167]
===
match
---
name: debug [32551,32556]
name: debug [32551,32556]
===
match
---
suite [7303,7483]
suite [7303,7483]
===
match
---
name: default_var [64303,64314]
name: default_var [64437,64448]
===
match
---
simple_stmt [8103,8119]
simple_stmt [8103,8119]
===
match
---
trailer [26108,26115]
trailer [26108,26115]
===
match
---
trailer [32152,32189]
trailer [32152,32189]
===
match
---
suite [82260,82585]
suite [82394,82719]
===
match
---
name: taskreschedule [1989,2003]
name: taskreschedule [1989,2003]
===
match
---
operator: , [29200,29201]
operator: , [29200,29201]
===
match
---
argument [42667,42682]
argument [42667,42682]
===
match
---
fstring_string: dag. [48675,48679]
fstring_string: dag. [48675,48679]
===
match
---
name: _run_as_user [79948,79960]
name: _run_as_user [80082,80094]
===
match
---
name: self [80574,80578]
name: self [80708,80712]
===
match
---
trailer [9753,9760]
trailer [9753,9760]
===
match
---
trailer [47466,47479]
trailer [47466,47479]
===
match
---
trailer [32972,32978]
trailer [32972,32978]
===
match
---
atom_expr [27137,27156]
atom_expr [27137,27156]
===
match
---
trailer [71140,71166]
trailer [71274,71300]
===
match
---
trailer [44934,44940]
trailer [44934,44940]
===
match
---
param [80939,80943]
param [81073,81077]
===
match
---
name: query [7382,7387]
name: query [7382,7387]
===
match
---
expr_stmt [62755,62770]
expr_stmt [62889,62904]
===
match
---
name: default_subject [69301,69316]
name: default_subject [69435,69450]
===
match
---
name: self [40734,40738]
name: self [40734,40738]
===
match
---
name: context [50335,50342]
name: context [50335,50342]
===
match
---
atom_expr [23498,23510]
atom_expr [23498,23510]
===
match
---
operator: , [43798,43799]
operator: , [43798,43799]
===
match
---
name: conf [19033,19037]
name: conf [19033,19037]
===
match
---
trailer [53032,53045]
trailer [53032,53045]
===
match
---
number: 2 [29022,29023]
number: 2 [29022,29023]
===
match
---
name: params [62255,62261]
name: params [62389,62395]
===
match
---
operator: = [57690,57691]
operator: = [57824,57825]
===
match
---
name: log_url [19163,19170]
name: log_url [19163,19170]
===
match
---
name: item [63765,63769]
name: item [63899,63903]
===
match
---
atom_expr [19014,19072]
atom_expr [19014,19072]
===
match
---
trailer [7697,7724]
trailer [7697,7724]
===
match
---
name: str [26494,26497]
name: str [26494,26497]
===
match
---
trailer [45036,45365]
trailer [45036,45365]
===
match
---
name: commit [47620,47626]
name: commit [47620,47626]
===
match
---
name: clear_xcom_data [23632,23647]
name: clear_xcom_data [23632,23647]
===
match
---
name: State [53027,53032]
name: State [53027,53032]
===
match
---
name: self [22099,22103]
name: self [22099,22103]
===
match
---
name: dag [59963,59966]
name: dag [60097,60100]
===
match
---
trailer [7655,7662]
trailer [7655,7662]
===
match
---
name: self [29159,29163]
name: self [29159,29163]
===
match
---
operator: , [68285,68286]
operator: , [68419,68420]
===
match
---
name: yesterday_ds [62062,62074]
name: yesterday_ds [62196,62208]
===
match
---
simple_stmt [27344,27357]
simple_stmt [27344,27357]
===
match
---
trailer [52532,52539]
trailer [52532,52539]
===
match
---
name: dag [60010,60013]
name: dag [60144,60147]
===
match
---
trailer [58953,58969]
trailer [59087,59103]
===
match
---
trailer [80265,80272]
trailer [80399,80406]
===
match
---
name: end_date [24956,24964]
name: end_date [24956,24964]
===
match
---
trailer [35016,35018]
trailer [35016,35018]
===
match
---
simple_stmt [61909,61967]
simple_stmt [62043,62101]
===
match
---
name: Optional [29827,29835]
name: Optional [29827,29835]
===
match
---
operator: , [33964,33965]
operator: , [33964,33965]
===
match
---
simple_stmt [22612,22634]
simple_stmt [22612,22634]
===
match
---
name: dag_id [15520,15526]
name: dag_id [15520,15526]
===
match
---
operator: , [10925,10926]
operator: , [10925,10926]
===
match
---
name: self [49150,49154]
name: self [49150,49154]
===
match
---
trailer [5390,5399]
trailer [5390,5399]
===
match
---
arglist [32578,32759]
arglist [32578,32759]
===
match
---
operator: = [59062,59063]
operator: = [59196,59197]
===
match
---
name: pod_mutation_hook [68814,68831]
name: pod_mutation_hook [68948,68965]
===
match
---
atom_expr [79736,79749]
atom_expr [79870,79883]
===
match
---
if_stmt [60980,61308]
if_stmt [61114,61442]
===
match
---
trailer [27284,27289]
trailer [27284,27289]
===
match
---
return_stmt [28057,28068]
return_stmt [28057,28068]
===
match
---
operator: = [59882,59883]
operator: = [60016,60017]
===
match
---
trailer [56379,56389]
trailer [56511,56517]
===
match
---
trailer [58436,58447]
trailer [58570,58581]
===
match
---
name: set_current_context [3318,3337]
name: set_current_context [3318,3337]
===
match
---
name: start_date [9664,9674]
name: start_date [9664,9674]
===
match
---
and_test [78420,78477]
and_test [78554,78611]
===
match
---
return_stmt [4209,4247]
return_stmt [4209,4247]
===
match
---
atom_expr [65027,65143]
atom_expr [65161,65277]
===
match
---
atom_expr [77532,77545]
atom_expr [77666,77679]
===
match
---
atom_expr [72338,72379]
atom_expr [72472,72513]
===
match
---
argument [74000,74011]
argument [74134,74145]
===
match
---
subscriptlist [8165,8183]
subscriptlist [8165,8183]
===
match
---
atom_expr [64806,64818]
atom_expr [64940,64952]
===
match
---
operator: = [48856,48857]
operator: = [48856,48857]
===
match
---
name: collections [921,932]
name: collections [921,932]
===
match
---
operator: , [30706,30707]
operator: , [30706,30707]
===
match
---
param [77625,77634]
param [77759,77768]
===
match
---
name: render_k8s_pod_yaml [68065,68084]
name: render_k8s_pod_yaml [68199,68218]
===
match
---
param [41598,41603]
param [41598,41603]
===
match
---
name: dag_id [60206,60212]
name: dag_id [60340,60346]
===
match
---
name: exception [68975,68984]
name: exception [69109,69118]
===
match
---
name: previous_scheduled_date [27181,27204]
name: previous_scheduled_date [27181,27204]
===
match
---
trailer [79762,79772]
trailer [79896,79906]
===
match
---
name: utils [2838,2843]
name: utils [2838,2843]
===
match
---
operator: , [44069,44070]
operator: , [44069,44070]
===
match
---
trailer [23460,23472]
trailer [23460,23472]
===
match
---
string: """Load and return error from error file""" [3974,4017]
string: """Load and return error from error file""" [3974,4017]
===
match
---
name: operator [22705,22713]
name: operator [22705,22713]
===
match
---
name: TaskInstance [78829,78841]
name: TaskInstance [78963,78975]
===
match
---
expr_stmt [19225,19269]
expr_stmt [19225,19269]
===
match
---
funcdef [55994,58859]
funcdef [55994,58993]
===
match
---
trailer [23523,23539]
trailer [23523,23539]
===
match
---
atom_expr [72766,72779]
atom_expr [72900,72913]
===
match
---
name: os [70850,70852]
name: os [70984,70986]
===
match
---
if_stmt [71650,71819]
if_stmt [71784,71953]
===
match
---
name: context [3842,3849]
name: context [3842,3849]
===
match
---
atom_expr [76815,76860]
atom_expr [76949,76994]
===
match
---
operator: , [44233,44234]
operator: , [44233,44234]
===
match
---
trailer [71166,71173]
trailer [71300,71307]
===
match
---
atom_expr [79758,79772]
atom_expr [79892,79906]
===
match
---
atom_expr [41689,41702]
atom_expr [41689,41702]
===
match
---
atom_expr [38108,38399]
atom_expr [38108,38399]
===
match
---
operator: , [28477,28478]
operator: , [28477,28478]
===
match
---
trailer [5566,5577]
trailer [5566,5577]
===
match
---
atom_expr [49877,50026]
atom_expr [49877,50026]
===
match
---
suite [59083,59235]
suite [59217,59369]
===
match
---
atom_expr [31691,31704]
atom_expr [31691,31704]
===
match
---
atom_expr [20378,20390]
atom_expr [20378,20390]
===
match
---
suite [13288,13322]
suite [13288,13322]
===
match
---
name: task_id [21680,21687]
name: task_id [21680,21687]
===
match
---
operator: , [29023,29024]
operator: , [29023,29024]
===
match
---
operator: , [8600,8601]
operator: , [8600,8601]
===
match
---
expr_stmt [63681,63696]
expr_stmt [63815,63830]
===
match
---
atom_expr [18123,18163]
atom_expr [18123,18163]
===
match
---
string: 'Submitting %s to sensor service' [50725,50758]
string: 'Submitting %s to sensor service' [50725,50758]
===
match
---
name: job_id [15388,15394]
name: job_id [15388,15394]
===
match
---
string: '%Y%m%dT%H%M%S' [61950,61965]
string: '%Y%m%dT%H%M%S' [62084,62099]
===
match
---
trailer [59198,59221]
trailer [59332,59355]
===
match
---
name: dump [4660,4664]
name: dump [4660,4664]
===
match
---
if_stmt [32087,32123]
if_stmt [32087,32123]
===
match
---
simple_stmt [17924,17957]
simple_stmt [17924,17957]
===
match
---
operator: = [46548,46549]
operator: = [46548,46549]
===
match
---
name: dry_run [54992,54999]
name: dry_run [54992,54999]
===
match
---
atom_expr [3714,3896]
atom_expr [3714,3896]
===
match
---
name: execution_date [78142,78156]
name: execution_date [78276,78290]
===
match
---
name: state [26285,26290]
name: state [26285,26290]
===
match
---
fstring_string: / [19113,19114]
fstring_string: / [19113,19114]
===
match
---
name: execution_date [61292,61306]
name: execution_date [61426,61440]
===
match
---
atom_expr [25026,25041]
atom_expr [25026,25041]
===
match
---
name: DagRun [82474,82480]
name: DagRun [82608,82614]
===
match
---
name: unixname [12062,12070]
name: unixname [12062,12070]
===
match
---
operator: , [44244,44245]
operator: , [44244,44245]
===
match
---
name: result [76738,76744]
name: result [76872,76878]
===
match
---
name: execution_date [21730,21744]
name: execution_date [21730,21744]
===
match
---
operator: = [71564,71565]
operator: = [71698,71699]
===
match
---
string: "--pickle" [18135,18145]
string: "--pickle" [18135,18145]
===
match
---
suite [61142,61308]
suite [61276,61442]
===
match
---
trailer [11765,11776]
trailer [11765,11776]
===
match
---
name: kube_config [68659,68670]
name: kube_config [68793,68804]
===
match
---
or_test [57620,57665]
or_test [57754,57799]
===
match
---
trailer [19119,19127]
trailer [19119,19127]
===
match
---
trailer [44181,44197]
trailer [44181,44197]
===
match
---
name: error_file [54506,54516]
name: error_file [54506,54516]
===
match
---
funcdef [55028,55968]
funcdef [55028,55968]
===
match
---
name: execution_date [73918,73932]
name: execution_date [74052,74066]
===
match
---
trailer [53204,53217]
trailer [53204,53217]
===
match
---
name: property [19428,19436]
name: property [19428,19436]
===
match
---
name: String [10182,10188]
name: String [10182,10188]
===
match
---
expr_stmt [7456,7482]
expr_stmt [7456,7482]
===
match
---
operator: = [82122,82123]
operator: = [82256,82257]
===
match
---
operator: , [37775,37776]
operator: , [37775,37776]
===
match
---
operator: = [15818,15819]
operator: = [15818,15819]
===
match
---
trailer [20250,20264]
trailer [20250,20264]
===
match
---
atom_expr [22390,22402]
atom_expr [22390,22402]
===
match
---
arglist [10915,11064]
arglist [10915,11064]
===
match
---
string: '' [61507,61509]
string: '' [61641,61643]
===
match
---
trailer [54525,54530]
trailer [54525,54530]
===
match
---
atom_expr [21717,21744]
atom_expr [21717,21744]
===
match
---
name: get_templated_fields [66189,66209]
name: get_templated_fields [66323,66343]
===
match
---
simple_stmt [55898,55968]
simple_stmt [55898,55968]
===
match
---
name: dep_status [32741,32751]
name: dep_status [32741,32751]
===
match
---
name: int [80143,80146]
name: int [80277,80280]
===
match
---
atom_expr [54517,54530]
atom_expr [54517,54530]
===
match
---
trailer [6718,7021]
trailer [6718,7021]
===
match
---
operator: , [72943,72944]
operator: , [73077,73078]
===
match
---
simple_stmt [1201,1217]
simple_stmt [1201,1217]
===
match
---
trailer [64610,64617]
trailer [64744,64751]
===
match
---
name: context [50389,50396]
name: context [50389,50396]
===
match
---
comparison [78443,78477]
comparison [78577,78611]
===
match
---
atom_expr [78723,78731]
atom_expr [78857,78865]
===
match
---
string: """Filepath for TaskInstance""" [18918,18949]
string: """Filepath for TaskInstance""" [18918,18949]
===
match
---
dotted_name [2996,3042]
dotted_name [2996,3042]
===
match
---
expr_stmt [72766,72786]
expr_stmt [72900,72920]
===
match
---
arglist [81854,82006]
arglist [81988,82140]
===
match
---
simple_stmt [50462,50517]
simple_stmt [50462,50517]
===
match
---
param [4763,4772]
param [4763,4772]
===
match
---
if_stmt [70283,72134]
if_stmt [70417,72268]
===
match
---
name: bool [53416,53420]
name: bool [53416,53420]
===
match
---
name: job_id [22512,22518]
name: job_id [22512,22518]
===
match
---
expr_stmt [10034,10089]
expr_stmt [10034,10089]
===
match
---
name: State [39015,39020]
name: State [39015,39020]
===
match
---
param [77770,77823]
param [77904,77957]
===
match
---
name: self [23337,23341]
name: self [23337,23341]
===
match
---
argument [29071,29090]
argument [29071,29090]
===
match
---
name: end_date [80703,80711]
name: end_date [80837,80845]
===
match
---
name: self [55277,55281]
name: self [55277,55281]
===
match
---
comp_op [52883,52889]
comp_op [52883,52889]
===
match
---
name: orm [82366,82369]
name: orm [82500,82503]
===
match
---
name: force_fail [59021,59031]
name: force_fail [59155,59165]
===
match
---
trailer [52862,52882]
trailer [52862,52882]
===
match
---
arglist [68320,68345]
arglist [68454,68479]
===
match
---
trailer [41131,41195]
trailer [41131,41195]
===
match
---
operator: -> [41817,41819]
operator: -> [41817,41819]
===
match
---
simple_stmt [67380,67469]
simple_stmt [67514,67603]
===
match
---
trailer [42725,42734]
trailer [42725,42734]
===
match
---
name: TaskInstance [81954,81966]
name: TaskInstance [82088,82100]
===
match
---
name: log [3251,3254]
name: log [3251,3254]
===
match
---
arglist [21512,21554]
arglist [21512,21554]
===
match
---
number: 1 [22598,22599]
number: 1 [22598,22599]
===
match
---
atom_expr [74033,74045]
atom_expr [74167,74179]
===
match
---
name: SHUTDOWN [5257,5265]
name: SHUTDOWN [5257,5265]
===
match
---
name: handle_failure [44778,44792]
name: handle_failure [44778,44792]
===
match
---
name: instance [30238,30246]
name: instance [30238,30246]
===
match
---
name: Optional [35909,35917]
name: Optional [35909,35917]
===
match
---
if_stmt [5168,6041]
if_stmt [5168,6041]
===
match
---
name: staticmethod [77734,77746]
name: staticmethod [77868,77880]
===
match
---
trailer [11230,11238]
trailer [11230,11238]
===
match
---
or_test [74106,74143]
or_test [74240,74277]
===
match
---
trailer [60154,60162]
trailer [60288,60296]
===
match
---
trailer [24309,24316]
trailer [24309,24316]
===
match
---
if_stmt [52510,53274]
if_stmt [52510,53274]
===
match
---
expr_stmt [10200,10233]
expr_stmt [10200,10233]
===
match
---
trailer [67686,67759]
trailer [67820,67893]
===
match
---
not_test [40832,40845]
not_test [40832,40845]
===
match
---
simple_stmt [12175,12195]
simple_stmt [12175,12195]
===
match
---
funcdef [68939,72190]
funcdef [69073,72324]
===
match
---
operator: % [34087,34088]
operator: % [34087,34088]
===
match
---
name: self [22287,22291]
name: self [22287,22291]
===
match
---
operator: = [7605,7606]
operator: = [7605,7606]
===
match
---
name: log_message [57748,57759]
name: log_message [57882,57893]
===
match
---
simple_stmt [59447,59487]
simple_stmt [59581,59621]
===
match
---
operator: , [8540,8541]
operator: , [8540,8541]
===
match
---
name: ti [22390,22392]
name: ti [22390,22392]
===
match
---
trailer [22761,22773]
trailer [22761,22773]
===
match
---
trailer [54350,54578]
trailer [54350,54578]
===
match
---
name: self [44630,44634]
name: self [44630,44634]
===
match
---
operator: = [53421,53422]
operator: = [53421,53422]
===
match
---
name: Optional [74307,74315]
name: Optional [74441,74449]
===
match
---
name: state [44533,44538]
name: state [44533,44538]
===
match
---
name: timezone [11474,11482]
name: timezone [11474,11482]
===
match
---
name: State [56875,56880]
name: State [57009,57014]
===
match
---
expr_stmt [8103,8118]
expr_stmt [8103,8118]
===
match
---
name: renderedtifields [67054,67070]
name: renderedtifields [67188,67204]
===
match
---
tfpdef [35868,35883]
tfpdef [35868,35883]
===
match
---
name: jinja_context [70311,70324]
name: jinja_context [70445,70458]
===
match
---
atom_expr [71991,72044]
atom_expr [72125,72178]
===
match
---
import_name [850,861]
import_name [850,861]
===
match
---
if_stmt [78413,78708]
if_stmt [78547,78842]
===
match
---
name: _date_or_empty [45281,45295]
name: _date_or_empty [45281,45295]
===
match
---
name: delay [34717,34722]
name: delay [34717,34722]
===
match
---
name: str [79387,79390]
name: str [79521,79524]
===
match
---
name: task_id_by_key [7156,7170]
name: task_id_by_key [7156,7170]
===
match
---
atom_expr [72795,72851]
atom_expr [72929,72985]
===
match
---
atom_expr [26119,26130]
atom_expr [26119,26130]
===
match
---
operator: = [48772,48773]
operator: = [48772,48773]
===
match
---
trailer [20860,20901]
trailer [20860,20901]
===
match
---
trailer [21729,21744]
trailer [21729,21744]
===
match
---
atom_expr [56643,56652]
atom_expr [56777,56786]
===
match
---
trailer [31790,31832]
trailer [31790,31832]
===
match
---
name: self [22612,22616]
name: self [22612,22616]
===
match
---
name: dag_id [6665,6671]
name: dag_id [6665,6671]
===
match
---
name: operator [23576,23584]
name: operator [23576,23584]
===
match
---
number: 80 [37893,37895]
number: 80 [37893,37895]
===
match
---
trailer [33225,33230]
trailer [33225,33230]
===
match
---
operator: = [48184,48185]
operator: = [48184,48185]
===
match
---
name: exception [70556,70565]
name: exception [70690,70699]
===
match
---
operator: , [41709,41710]
operator: , [41709,41710]
===
match
---
name: DepContext [38108,38118]
name: DepContext [38108,38118]
===
match
---
operator: = [24812,24813]
operator: = [24812,24813]
===
match
---
name: _start_date [80668,80679]
name: _start_date [80802,80813]
===
match
---
atom [44724,44754]
atom [44724,44754]
===
match
---
name: merge [45487,45492]
name: merge [45487,45492]
===
match
---
parameters [45703,45723]
parameters [45703,45723]
===
match
---
atom_expr [29505,29557]
atom_expr [29505,29557]
===
match
---
trailer [30335,30354]
trailer [30335,30354]
===
match
---
simple_stmt [43104,43131]
simple_stmt [43104,43131]
===
match
---
atom_expr [67746,67758]
atom_expr [67880,67892]
===
match
---
atom_expr [6714,7021]
atom_expr [6714,7021]
===
match
---
not_test [11470,11511]
not_test [11470,11511]
===
match
---
string: 'test_mode' [65450,65461]
string: 'test_mode' [65584,65595]
===
match
---
suite [25460,26417]
suite [25460,26417]
===
match
---
name: bool [41626,41630]
name: bool [41626,41630]
===
match
---
operator: , [73986,73987]
operator: , [74120,74121]
===
match
---
name: UP_FOR_RESCHEDULE [55670,55687]
name: UP_FOR_RESCHEDULE [55670,55687]
===
match
---
trailer [29671,29695]
trailer [29671,29695]
===
match
---
name: ti [79916,79918]
name: ti [80050,80052]
===
match
---
operator: = [53383,53384]
operator: = [53383,53384]
===
match
---
parameters [48272,48287]
parameters [48272,48287]
===
match
---
simple_stmt [1464,1507]
simple_stmt [1464,1507]
===
match
---
name: value [76854,76859]
name: value [76988,76993]
===
match
---
trailer [78909,78924]
trailer [79043,79058]
===
match
---
subscriptlist [58954,58968]
subscriptlist [59088,59102]
===
match
---
param [41797,41810]
param [41797,41810]
===
match
---
suite [40846,40879]
suite [40846,40879]
===
match
---
name: update [59998,60004]
name: update [60132,60138]
===
match
---
comparison [25326,25358]
comparison [25326,25358]
===
match
---
atom_expr [9968,9983]
atom_expr [9968,9983]
===
match
---
atom_expr [29672,29694]
atom_expr [29672,29694]
===
match
---
name: context [53265,53272]
name: context [53265,53272]
===
match
---
expr_stmt [46848,46906]
expr_stmt [46848,46906]
===
match
---
name: State [40704,40709]
name: State [40704,40709]
===
match
---
name: error_fd [54673,54681]
name: error_fd [54673,54681]
===
match
---
return_stmt [18856,18866]
return_stmt [18856,18866]
===
match
---
name: include_prior_dates [76402,76421]
name: include_prior_dates [76536,76555]
===
match
---
name: RUNNING [77538,77545]
name: RUNNING [77672,77679]
===
match
---
arglist [32153,32188]
arglist [32153,32188]
===
match
---
name: session [29618,29625]
name: session [29618,29625]
===
match
---
operator: = [23540,23541]
operator: = [23540,23541]
===
match
---
name: RenderedTaskInstanceFields [67134,67160]
name: RenderedTaskInstanceFields [67268,67294]
===
match
---
expr_stmt [54608,54682]
expr_stmt [54608,54682]
===
match
---
trailer [26548,26564]
trailer [26548,26564]
===
match
---
arglist [47820,47919]
arglist [47820,47919]
===
match
---
name: registered [49693,49703]
name: registered [49693,49703]
===
match
---
name: _try_number [55819,55830]
name: _try_number [55819,55830]
===
match
---
simple_stmt [28057,28069]
simple_stmt [28057,28069]
===
match
---
name: render [71612,71618]
name: render [71746,71752]
===
match
---
name: self [44212,44216]
name: self [44212,44216]
===
match
---
name: self [47513,47517]
name: self [47513,47517]
===
match
---
suite [80952,80979]
suite [81086,81113]
===
match
---
operator: , [32182,32183]
operator: , [32182,32183]
===
match
---
trailer [35387,35394]
trailer [35387,35394]
===
match
---
arglist [44052,44102]
arglist [44052,44102]
===
match
---
atom_expr [18964,18995]
atom_expr [18964,18995]
===
match
---
trailer [48747,48764]
trailer [48747,48764]
===
match
---
trailer [43735,43743]
trailer [43735,43743]
===
match
---
suite [50115,50266]
suite [50115,50266]
===
match
---
name: ignore_ti_state [38255,38270]
name: ignore_ti_state [38255,38270]
===
match
---
name: task [62230,62234]
name: task [62364,62368]
===
match
---
string: 'dag' [64407,64412]
string: 'dag' [64541,64546]
===
match
---
return_stmt [8257,8310]
return_stmt [8257,8310]
===
match
---
trailer [64561,64582]
trailer [64695,64716]
===
match
---
name: self [52264,52268]
name: self [52264,52268]
===
match
---
operator: = [54880,54881]
operator: = [54880,54881]
===
match
---
operator: = [22623,22624]
operator: = [22623,22624]
===
match
---
trailer [34689,34723]
trailer [34689,34723]
===
match
---
name: exc [1381,1384]
name: exc [1381,1384]
===
match
---
param [35793,35823]
param [35793,35823]
===
match
---
operator: = [49452,49453]
operator: = [49452,49453]
===
match
---
trailer [79592,79599]
trailer [79726,79733]
===
match
---
tfpdef [11127,11147]
tfpdef [11127,11147]
===
match
---
string: """             This attribute is deprecated.             Please use `airflow.models.taskinstance.TaskInstance.get_previous_start_date` method.             """ [30547,30706]
string: """             This attribute is deprecated.             Please use `airflow.models.taskinstance.TaskInstance.get_previous_start_date` method.             """ [30547,30706]
===
match
---
name: on_execute_callback [51991,52010]
name: on_execute_callback [51991,52010]
===
match
---
name: partial_subset [46564,46578]
name: partial_subset [46564,46578]
===
match
---
parameters [55050,55128]
parameters [55050,55128]
===
match
---
name: provide_session [23608,23623]
name: provide_session [23608,23623]
===
match
---
simple_stmt [21820,21855]
simple_stmt [21820,21855]
===
match
---
simple_stmt [78188,78218]
simple_stmt [78322,78352]
===
match
---
name: item [63323,63327]
name: item [63457,63461]
===
match
---
trailer [56880,56887]
trailer [57014,57021]
===
match
---
operator: , [41173,41174]
operator: , [41173,41174]
===
match
---
name: read [71812,71816]
name: read [71946,71950]
===
match
---
atom_expr [42932,42959]
atom_expr [42932,42959]
===
match
---
simple_stmt [61087,61129]
simple_stmt [61221,61263]
===
match
---
atom_expr [80034,80051]
atom_expr [80168,80185]
===
match
---
name: signal [48506,48512]
name: signal [48506,48512]
===
match
---
name: UP_FOR_RETRY [24909,24921]
name: UP_FOR_RETRY [24909,24921]
===
match
---
atom_expr [79629,79639]
atom_expr [79763,79773]
===
match
---
operator: -> [29824,29826]
operator: -> [29824,29826]
===
match
---
atom_expr [79608,79621]
atom_expr [79742,79755]
===
match
---
name: self [52208,52212]
name: self [52208,52212]
===
match
---
atom_expr [64123,64162]
atom_expr [64257,64296]
===
match
---
name: str [41776,41779]
name: str [41776,41779]
===
match
---
number: 1 [40205,40206]
number: 1 [40205,40206]
===
match
---
name: timezone [56677,56685]
name: timezone [56811,56819]
===
match
---
funcdef [13897,13998]
funcdef [13897,13998]
===
match
---
name: get_dep_statuses [32479,32495]
name: get_dep_statuses [32479,32495]
===
match
---
name: Optional [30327,30335]
name: Optional [30327,30335]
===
match
---
expr_stmt [21881,21897]
expr_stmt [21881,21897]
===
match
---
param [4722,4730]
param [4722,4730]
===
match
---
simple_stmt [63807,63860]
simple_stmt [63941,63994]
===
match
---
atom_expr [61995,62031]
atom_expr [62129,62165]
===
match
---
operator: , [74499,74500]
operator: , [74633,74634]
===
match
---
param [74297,74350]
param [74431,74484]
===
match
---
name: incr [56737,56741]
name: incr [56871,56875]
===
match
---
operator: = [9847,9848]
operator: = [9847,9848]
===
match
---
name: log [29510,29513]
name: log [29510,29513]
===
match
---
atom_expr [56936,57016]
atom_expr [57070,57150]
===
match
---
name: pool [37464,37468]
name: pool [37464,37468]
===
match
---
sync_comp_for [78679,78691]
sync_comp_for [78813,78825]
===
match
---
atom_expr [46806,46817]
atom_expr [46806,46817]
===
match
---
param [24410,24415]
param [24410,24415]
===
match
---
operator: , [55113,55114]
operator: , [55113,55114]
===
match
---
suite [59974,60022]
suite [60108,60156]
===
match
---
trailer [6845,6856]
trailer [6845,6856]
===
match
---
import_from [2415,2457]
import_from [2415,2457]
===
match
---
simple_stmt [35320,35488]
simple_stmt [35320,35488]
===
match
---
arith_expr [60613,60647]
arith_expr [60747,60781]
===
match
---
operator: , [39822,39823]
operator: , [39822,39823]
===
match
---
name: session [56936,56943]
name: session [57070,57077]
===
match
---
operator: , [10743,10744]
operator: , [10743,10744]
===
match
---
operator: = [39866,39867]
operator: = [39866,39867]
===
match
---
trailer [24687,24689]
trailer [24687,24689]
===
match
---
name: task_id [46967,46974]
name: task_id [46967,46974]
===
match
---
atom_expr [49272,49300]
atom_expr [49272,49300]
===
match
---
operator: , [71727,71728]
operator: , [71861,71862]
===
match
---
expr_stmt [21565,21778]
expr_stmt [21565,21778]
===
match
---
string: """Overwrite Task Params with DagRun.conf""" [67578,67622]
string: """Overwrite Task Params with DagRun.conf""" [67712,67756]
===
match
---
atom_expr [20237,20492]
atom_expr [20237,20492]
===
match
---
trailer [45748,45759]
trailer [45748,45759]
===
match
---
trailer [72678,72687]
trailer [72812,72821]
===
match
---
trailer [54971,54973]
trailer [54971,54973]
===
match
---
name: attr [41380,41384]
name: attr [41380,41384]
===
match
---
expr_stmt [32349,32390]
expr_stmt [32349,32390]
===
match
---
atom_expr [23542,23562]
atom_expr [23542,23562]
===
match
---
trailer [33857,33868]
trailer [33857,33868]
===
match
---
operator: , [41671,41672]
operator: , [41671,41672]
===
match
---
atom_expr [5344,5354]
atom_expr [5344,5354]
===
match
---
name: state [44935,44940]
name: state [44935,44940]
===
match
---
operator: - [70675,70676]
operator: - [70809,70810]
===
match
---
name: ignore_ti_state [37681,37696]
name: ignore_ti_state [37681,37696]
===
match
---
operator: , [55476,55477]
operator: , [55476,55477]
===
match
---
name: signal [893,899]
name: signal [893,899]
===
match
---
name: email [72426,72431]
name: email [72560,72565]
===
match
---
trailer [41243,41297]
trailer [41243,41297]
===
match
---
name: self [23990,23994]
name: self [23990,23994]
===
match
---
name: pool [54479,54483]
name: pool [54479,54483]
===
match
---
trailer [77357,77363]
trailer [77491,77497]
===
match
---
operator: = [68859,68860]
operator: = [68993,68994]
===
match
---
name: self [55814,55818]
name: self [55814,55818]
===
match
---
operator: = [9745,9746]
operator: = [9745,9746]
===
match
---
if_stmt [58496,58775]
if_stmt [58630,58909]
===
match
---
parameters [8149,8155]
parameters [8149,8155]
===
match
---
operator: , [14338,14339]
operator: , [14338,14339]
===
match
---
argument [68299,68346]
argument [68433,68480]
===
match
---
name: add [40696,40699]
name: add [40696,40699]
===
match
---
param [35668,35698]
param [35668,35698]
===
match
---
operator: , [51879,51880]
operator: , [51879,51880]
===
match
---
name: var [62760,62763]
name: var [62894,62897]
===
match
---
funcdef [63710,63892]
funcdef [63844,64026]
===
match
---
trailer [32478,32495]
trailer [32478,32495]
===
match
---
atom_expr [24903,24921]
atom_expr [24903,24921]
===
match
---
name: String [9549,9555]
name: String [9549,9555]
===
match
---
atom_expr [14756,14768]
atom_expr [14756,14768]
===
match
---
name: bool [59033,59037]
name: bool [59167,59171]
===
match
---
suite [80808,80841]
suite [80942,80975]
===
match
---
decorator [30846,30863]
decorator [30846,30863]
===
match
---
name: end_date [22038,22046]
name: end_date [22038,22046]
===
match
---
simple_stmt [48794,48888]
simple_stmt [48794,48888]
===
match
---
suite [30355,30841]
suite [30355,30841]
===
match
---
if_stmt [18490,18546]
if_stmt [18490,18546]
===
match
---
simple_stmt [33694,33980]
simple_stmt [33694,33980]
===
match
---
name: sanitize_for_serialization [68873,68899]
name: sanitize_for_serialization [69007,69033]
===
match
---
trailer [9904,9918]
trailer [9904,9918]
===
match
---
trailer [54923,54928]
trailer [54923,54928]
===
match
---
operator: , [32027,32028]
operator: , [32027,32028]
===
match
---
string: 'Marking task as SKIPPED. ' [43570,43597]
string: 'Marking task as SKIPPED. ' [43570,43597]
===
match
---
name: execute [51425,51432]
name: execute [51425,51432]
===
match
---
name: log [47518,47521]
name: log [47518,47521]
===
match
---
operator: , [68512,68513]
operator: , [68646,68647]
===
match
---
simple_stmt [40734,40761]
simple_stmt [40734,40761]
===
match
---
operator: , [10832,10833]
operator: , [10832,10833]
===
match
---
name: pool [41719,41723]
name: pool [41719,41723]
===
match
---
atom_expr [68240,68251]
atom_expr [68374,68385]
===
match
---
atom_expr [52858,52882]
atom_expr [52858,52882]
===
match
---
fstring_expr [67456,67459]
fstring_expr [67590,67593]
===
match
---
name: property [13328,13336]
name: property [13328,13336]
===
match
---
name: job_id [54448,54454]
name: job_id [54448,54454]
===
match
---
name: dep_context [39446,39457]
name: dep_context [39446,39457]
===
match
---
simple_stmt [48336,48398]
simple_stmt [48336,48398]
===
match
---
trailer [6075,6094]
trailer [6075,6094]
===
match
---
atom_expr [18441,18481]
atom_expr [18441,18481]
===
match
---
atom_expr [12587,12601]
atom_expr [12587,12601]
===
match
---
funcdef [80860,80911]
funcdef [80994,81045]
===
match
---
name: total_seconds [72724,72737]
name: total_seconds [72858,72871]
===
match
---
name: relationship [82377,82389]
name: relationship [82511,82523]
===
match
---
name: state [54629,54634]
name: state [54629,54634]
===
match
---
name: warning [3718,3725]
name: warning [3718,3725]
===
match
---
operator: , [1882,1883]
operator: , [1882,1883]
===
match
---
name: prepare_for_execution [54887,54908]
name: prepare_for_execution [54887,54908]
===
match
---
name: ignore_ti_state [39690,39705]
name: ignore_ti_state [39690,39705]
===
match
---
argument [50069,50082]
argument [50069,50082]
===
match
---
fstring_string: ti.start. [42820,42829]
fstring_string: ti.start. [42820,42829]
===
match
---
operator: , [1353,1354]
operator: , [1353,1354]
===
match
---
operator: = [29021,29022]
operator: = [29021,29022]
===
match
---
name: construct_pod [68206,68219]
name: construct_pod [68340,68353]
===
match
---
name: start_date [39197,39207]
name: start_date [39197,39207]
===
match
---
name: TaskInstance [26144,26156]
name: TaskInstance [26144,26156]
===
match
---
simple_stmt [30954,31587]
simple_stmt [30954,31587]
===
match
---
simple_stmt [11192,11218]
simple_stmt [11192,11218]
===
match
---
atom_expr [34576,34619]
atom_expr [34576,34619]
===
match
---
arglist [10587,10616]
arglist [10587,10616]
===
match
---
name: dr [7919,7921]
name: dr [7919,7921]
===
match
---
atom_expr [68094,68108]
atom_expr [68228,68242]
===
match
---
operator: = [38367,38368]
operator: = [38367,38368]
===
match
---
param [41342,41347]
param [41342,41347]
===
match
---
operator: = [38205,38206]
operator: = [38205,38206]
===
match
---
expr_stmt [60301,60345]
expr_stmt [60435,60479]
===
match
---
name: AirflowException [66565,66581]
name: AirflowException [66699,66715]
===
match
---
operator: , [54563,54564]
operator: , [54563,54564]
===
match
---
name: add [55347,55350]
name: add [55347,55350]
===
match
---
trailer [51424,51432]
trailer [51424,51432]
===
match
---
name: _run_finished_callback [52241,52263]
name: _run_finished_callback [52241,52263]
===
match
---
name: args [43394,43398]
name: args [43394,43398]
===
match
---
expr_stmt [71704,71733]
expr_stmt [71838,71867]
===
match
---
decorated [80984,81079]
decorated [81118,81213]
===
match
---
arglist [62023,62030]
arglist [62157,62164]
===
match
---
name: self [19408,19412]
name: self [19408,19412]
===
match
---
simple_stmt [8649,8708]
simple_stmt [8649,8708]
===
match
---
operator: = [50695,50696]
operator: = [50695,50696]
===
match
---
atom_expr [42536,42545]
atom_expr [42536,42545]
===
match
---
string: """             This attribute is deprecated.             Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.             """ [28814,28965]
string: """             This attribute is deprecated.             Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.             """ [28814,28965]
===
match
---
name: log [24117,24120]
name: log [24117,24120]
===
match
---
name: debug [67681,67686]
name: debug [67815,67820]
===
match
---
trailer [82183,82185]
trailer [82317,82319]
===
match
---
decorated [58864,59235]
decorated [58998,59369]
===
match
---
trailer [60644,60647]
trailer [60778,60781]
===
match
---
operator: + [37884,37885]
operator: + [37884,37885]
===
match
---
operator: , [18217,18218]
operator: , [18217,18218]
===
match
---
atom_expr [61055,61074]
atom_expr [61189,61208]
===
match
---
name: replace [61998,62005]
name: replace [62132,62139]
===
match
---
name: upper [82207,82212]
name: upper [82341,82346]
===
match
---
atom_expr [7882,7890]
atom_expr [7882,7890]
===
match
---
name: yesterday_ds [65864,65876]
name: yesterday_ds [65998,66010]
===
match
---
name: task_id [62195,62202]
name: task_id [62329,62336]
===
match
---
funcdef [63052,63354]
funcdef [63186,63488]
===
match
---
operator: = [68489,68490]
operator: = [68623,68624]
===
match
---
operator: , [41809,41810]
operator: , [41809,41810]
===
match
---
operator: , [8289,8290]
operator: , [8289,8290]
===
match
---
operator: == [6662,6664]
operator: == [6662,6664]
===
match
---
operator: = [14739,14740]
operator: = [14739,14740]
===
match
---
expr_stmt [9701,9731]
expr_stmt [9701,9731]
===
match
---
name: Iterable [74327,74335]
name: Iterable [74461,74469]
===
match
---
name: task [47394,47398]
name: task [47394,47398]
===
match
---
name: job_id [5216,5222]
name: job_id [5216,5222]
===
match
---
expr_stmt [80111,80154]
expr_stmt [80245,80288]
===
match
---
trailer [49104,49137]
trailer [49104,49137]
===
match
---
atom_expr [41725,41738]
atom_expr [41725,41738]
===
match
---
name: actual_start_date [55494,55511]
name: actual_start_date [55494,55511]
===
match
---
return_stmt [63876,63891]
return_stmt [64010,64025]
===
match
---
trailer [11328,11333]
trailer [11328,11333]
===
match
---
name: on_success_callback [52971,52990]
name: on_success_callback [52971,52990]
===
match
---
simple_stmt [52028,52062]
simple_stmt [52028,52062]
===
match
---
simple_stmt [22830,22848]
simple_stmt [22830,22848]
===
match
---
comparison [26096,26130]
comparison [26096,26130]
===
match
---
arith_expr [40562,40580]
arith_expr [40562,40580]
===
match
---
operator: <= [59378,59380]
operator: <= [59512,59514]
===
match
---
strings [69545,69865]
strings [69679,69999]
===
match
---
trailer [77721,77727]
trailer [77855,77861]
===
match
---
name: signal [48520,48526]
name: signal [48520,48526]
===
match
---
suite [59438,59576]
suite [59572,59710]
===
match
---
name: date [41470,41474]
name: date [41470,41474]
===
match
---
operator: , [63747,63748]
operator: , [63881,63882]
===
match
---
trailer [62140,62149]
trailer [62274,62283]
===
match
---
operator: = [57980,57981]
operator: = [58114,58115]
===
match
---
if_stmt [20511,20589]
if_stmt [20511,20589]
===
match
---
name: self [72674,72678]
name: self [72808,72812]
===
match
---
trailer [31893,32077]
trailer [31893,32077]
===
match
---
name: session [1484,1491]
name: session [1484,1491]
===
match
---
trailer [14850,14864]
trailer [14850,14864]
===
match
---
name: execution_date [10656,10670]
name: execution_date [10656,10670]
===
match
---
name: dag [27347,27350]
name: dag [27347,27350]
===
match
---
name: helpers [2477,2484]
name: helpers [2477,2484]
===
match
---
operator: } [44940,44941]
operator: } [44940,44941]
===
match
---
name: __init__ [11080,11088]
name: __init__ [11080,11088]
===
match
---
operator: = [14228,14229]
operator: = [14228,14229]
===
match
---
param [15973,16002]
param [15973,16002]
===
match
---
argument [54752,54763]
argument [54752,54763]
===
match
---
param [59422,59432]
param [59556,59566]
===
match
---
suite [31833,32078]
suite [31833,32078]
===
match
---
fstring_start: f" [14741,14743]
fstring_start: f" [14741,14743]
===
match
---
simple_stmt [22099,22121]
simple_stmt [22099,22121]
===
match
---
argument [59146,59167]
argument [59280,59301]
===
match
---
operator: , [76288,76289]
operator: , [76422,76423]
===
match
---
tfpdef [53563,53581]
tfpdef [53563,53581]
===
match
---
atom_expr [53091,53113]
atom_expr [53091,53113]
===
match
---
name: state [55656,55661]
name: state [55656,55661]
===
match
---
name: task [37444,37448]
name: task [37444,37448]
===
match
---
name: self [58749,58753]
name: self [58883,58887]
===
match
---
name: lock_for_update [81384,81399]
name: lock_for_update [81518,81533]
===
match
---
name: content [71864,71871]
name: content [71998,72005]
===
match
---
funcdef [67805,68056]
funcdef [67939,68190]
===
match
---
parameters [80628,80634]
parameters [80762,80768]
===
match
---
expr_stmt [40769,40791]
expr_stmt [40769,40791]
===
match
---
trailer [48212,48214]
trailer [48212,48214]
===
match
---
trailer [48629,48645]
trailer [48629,48645]
===
match
---
name: execution_date [60482,60496]
name: execution_date [60616,60630]
===
match
---
name: pool_slots [23342,23352]
name: pool_slots [23342,23352]
===
match
---
atom_expr [72707,72722]
atom_expr [72841,72856]
===
match
---
operator: , [45185,45186]
operator: , [45185,45186]
===
match
---
simple_stmt [1217,1275]
simple_stmt [1217,1275]
===
match
---
name: dag_id [24310,24316]
name: dag_id [24310,24316]
===
match
---
name: self [63658,63662]
name: self [63792,63796]
===
match
---
name: str [16066,16069]
name: str [16066,16069]
===
match
---
atom_expr [32132,32189]
atom_expr [32132,32189]
===
match
---
name: Stats [50526,50531]
name: Stats [50526,50531]
===
match
---
name: dag [26811,26814]
name: dag [26811,26814]
===
match
---
name: dag_run [60113,60120]
name: dag_run [60247,60254]
===
match
---
name: _Variable__NO_DEFAULT_SENTINEL [63183,63213]
name: _Variable__NO_DEFAULT_SENTINEL [63317,63347]
===
match
---
decorator [55973,55990]
decorator [55973,55990]
===
match
---
arith_expr [34739,34760]
arith_expr [34739,34760]
===
match
---
simple_stmt [27980,28048]
simple_stmt [27980,28048]
===
match
---
name: task_id [26066,26073]
name: task_id [26066,26073]
===
match
---
suite [18909,19140]
suite [18909,19140]
===
match
---
name: provide_session [24376,24391]
name: provide_session [24376,24391]
===
match
---
name: partial_dag [47010,47021]
name: partial_dag [47010,47021]
===
match
---
if_stmt [3672,3897]
if_stmt [3672,3897]
===
match
---
name: task_id [33823,33830]
name: task_id [33823,33830]
===
match
---
name: end_date [79788,79796]
name: end_date [79922,79930]
===
match
---
name: hr_line_break [39912,39925]
name: hr_line_break [39912,39925]
===
match
---
name: self [34739,34743]
name: self [34739,34743]
===
match
---
trailer [38444,38546]
trailer [38444,38546]
===
match
---
trailer [78421,78428]
trailer [78555,78562]
===
match
---
trailer [7748,7763]
trailer [7748,7763]
===
match
---
annassign [80087,80102]
annassign [80221,80236]
===
match
---
trailer [26356,26359]
trailer [26356,26359]
===
match
---
name: State [13145,13150]
name: State [13145,13150]
===
match
---
name: self [80629,80633]
name: self [80763,80767]
===
match
---
trailer [23853,23857]
trailer [23853,23857]
===
match
---
name: test_mode [58791,58800]
name: test_mode [58925,58934]
===
match
---
name: self [60533,60537]
name: self [60667,60671]
===
match
---
arglist [77404,77546]
arglist [77538,77680]
===
match
---
param [4269,4285]
param [4269,4285]
===
match
---
name: is_container [76674,76686]
name: is_container [76808,76820]
===
match
---
param [34786,34790]
param [34786,34790]
===
match
---
simple_stmt [81210,81227]
simple_stmt [81344,81361]
===
match
---
name: end_date [44986,44994]
name: end_date [44986,44994]
===
match
---
operator: , [53660,53661]
operator: , [53660,53661]
===
match
---
comp_op [51729,51735]
comp_op [51729,51735]
===
match
---
trailer [21895,21897]
trailer [21895,21897]
===
match
---
import_from [2562,2604]
import_from [2562,2604]
===
match
---
name: dag_run [64447,64454]
name: dag_run [64581,64588]
===
match
---
arglist [80002,80019]
arglist [80136,80153]
===
match
---
operator: , [58268,58269]
operator: , [58402,58403]
===
match
---
parameters [12680,12686]
parameters [12680,12686]
===
match
---
atom_expr [32916,32927]
atom_expr [32916,32927]
===
match
---
name: render [71167,71173]
name: render [71301,71307]
===
match
---
name: warnings [28787,28795]
name: warnings [28787,28795]
===
match
---
operator: , [15625,15626]
operator: , [15625,15626]
===
match
---
atom_expr [58118,58487]
atom_expr [58252,58621]
===
match
---
name: execution_date [6079,6093]
name: execution_date [6079,6093]
===
match
---
suite [72753,72787]
suite [72887,72921]
===
match
---
argument [43466,43486]
argument [43466,43486]
===
match
---
atom_expr [81288,81309]
atom_expr [81422,81443]
===
match
---
trailer [43997,44013]
trailer [43997,44013]
===
match
---
operator: , [54461,54462]
operator: , [54461,54462]
===
match
---
name: next_ds [64672,64679]
name: next_ds [64806,64813]
===
match
---
name: session [29610,29617]
name: session [29610,29617]
===
match
---
decorated [72857,74184]
decorated [72991,74318]
===
match
---
param [13281,13286]
param [13281,13286]
===
match
---
name: self [54724,54728]
name: self [54724,54728]
===
match
---
name: hostname [12153,12161]
name: hostname [12153,12161]
===
match
---
simple_stmt [48223,48245]
simple_stmt [48223,48245]
===
match
---
name: next_execution_date [61563,61582]
name: next_execution_date [61697,61716]
===
match
---
trailer [11942,11957]
trailer [11942,11957]
===
match
---
name: TR [6872,6874]
name: TR [6872,6874]
===
match
---
trailer [65817,65819]
trailer [65951,65953]
===
match
---
testlist_comp [10581,10869]
testlist_comp [10581,10869]
===
match
---
trailer [47192,47200]
trailer [47192,47200]
===
match
---
name: self [35624,35628]
name: self [35624,35628]
===
match
---
operator: = [20659,20660]
operator: = [20659,20660]
===
match
---
name: XCom [77051,77055]
name: XCom [77185,77189]
===
match
---
funcdef [8576,8799]
funcdef [8576,8799]
===
match
---
import_from [2787,2824]
import_from [2787,2824]
===
match
---
name: dag_id [78432,78438]
name: dag_id [78566,78572]
===
match
---
import_as_names [1236,1274]
import_as_names [1236,1274]
===
match
---
simple_stmt [44842,44848]
simple_stmt [44842,44848]
===
match
---
name: self [43761,43765]
name: self [43761,43765]
===
match
---
not_test [54223,54230]
not_test [54223,54230]
===
match
---
trailer [3925,3932]
trailer [3925,3932]
===
match
---
return_stmt [77108,77143]
return_stmt [77242,77277]
===
match
---
import_from [2026,2070]
import_from [2026,2070]
===
match
---
trailer [18366,18393]
trailer [18366,18393]
===
match
---
name: execution_date [74106,74120]
name: execution_date [74240,74254]
===
match
---
name: contextlib [794,804]
name: contextlib [794,804]
===
match
---
name: context [52912,52919]
name: context [52912,52919]
===
match
---
import_from [1365,1408]
import_from [1365,1408]
===
match
---
name: self [23648,23652]
name: self [23648,23652]
===
match
---
parameters [32263,32301]
parameters [32263,32301]
===
match
---
trailer [18696,18707]
trailer [18696,18707]
===
match
---
trailer [40393,40395]
trailer [40393,40395]
===
match
---
param [15601,15626]
param [15601,15626]
===
match
---
not_test [27733,27752]
not_test [27733,27752]
===
match
---
name: self [52560,52564]
name: self [52560,52564]
===
match
---
operator: , [67830,67831]
operator: , [67964,67965]
===
match
---
name: models [35258,35264]
name: models [35258,35264]
===
match
---
name: jinja_context [71176,71189]
name: jinja_context [71310,71323]
===
match
---
atom_expr [29050,29091]
atom_expr [29050,29091]
===
match
---
name: AirflowFailException [44138,44158]
name: AirflowFailException [44138,44158]
===
match
---
atom_expr [58749,58774]
atom_expr [58883,58908]
===
match
---
fstring_end: ' [44941,44942]
fstring_end: ' [44941,44942]
===
match
---
atom_expr [33725,33944]
atom_expr [33725,33944]
===
match
---
simple_stmt [58071,58109]
simple_stmt [58205,58243]
===
match
---
operator: , [24351,24352]
operator: , [24351,24352]
===
match
---
trailer [55655,55661]
trailer [55655,55661]
===
match
---
name: execution_date [61060,61074]
name: execution_date [61194,61208]
===
match
---
trailer [66474,66476]
trailer [66608,66610]
===
match
---
operator: -> [59075,59077]
operator: -> [59209,59211]
===
match
---
parameters [81363,81406]
parameters [81497,81540]
===
match
---
atom_expr [42807,42859]
atom_expr [42807,42859]
===
match
---
operator: = [58025,58026]
operator: = [58159,58160]
===
match
---
trailer [76923,76932]
trailer [77057,77066]
===
match
---
trailer [24939,24948]
trailer [24939,24948]
===
match
---
decorated [26422,28069]
decorated [26422,28069]
===
match
---
operator: , [1800,1801]
operator: , [1800,1801]
===
match
---
name: KeyboardInterrupt [44736,44753]
name: KeyboardInterrupt [44736,44753]
===
match
---
operator: , [64582,64583]
operator: , [64716,64717]
===
match
---
arglist [67687,67758]
arglist [67821,67892]
===
match
---
name: instance [29663,29671]
name: instance [29663,29671]
===
match
---
operator: , [70724,70725]
operator: , [70858,70859]
===
match
---
simple_stmt [10034,10090]
simple_stmt [10034,10090]
===
match
---
name: pool_override [23302,23315]
name: pool_override [23302,23315]
===
match
---
trailer [48853,48886]
trailer [48853,48886]
===
match
---
operator: = [26815,26816]
operator: = [26815,26816]
===
match
---
name: try_number [12670,12680]
name: try_number [12670,12680]
===
match
---
trailer [7403,7428]
trailer [7403,7428]
===
match
---
suite [77636,77728]
suite [77770,77862]
===
match
---
fstring [67403,67460]
fstring [67537,67594]
===
match
---
trailer [48689,48696]
trailer [48689,48696]
===
match
---
trailer [12374,12378]
trailer [12374,12378]
===
match
---
operator: @ [59581,59582]
operator: @ [59715,59716]
===
match
---
name: session [31816,31823]
name: session [31816,31823]
===
match
---
name: str [80468,80471]
name: str [80602,80605]
===
match
---
string: """Fetch rendered template fields from DB""" [65997,66041]
string: """Fetch rendered template fields from DB""" [66131,66175]
===
match
---
name: result [59447,59453]
name: result [59581,59587]
===
match
---
name: self [24814,24818]
name: self [24814,24818]
===
match
---
suite [56300,56340]
suite [56300,56340]
===
match
---
simple_stmt [9988,10030]
simple_stmt [9988,10030]
===
match
---
string: 'previously_succeeded' [37753,37775]
string: 'previously_succeeded' [37753,37775]
===
match
---
operator: = [59454,59455]
operator: = [59588,59589]
===
match
---
simple_stmt [67578,67623]
simple_stmt [67712,67757]
===
match
---
trailer [24680,24687]
trailer [24680,24687]
===
match
---
name: is_localized [11483,11495]
name: is_localized [11483,11495]
===
match
---
string: 'ti_state_lkp' [10721,10735]
string: 'ti_state_lkp' [10721,10735]
===
match
---
trailer [62298,62309]
trailer [62432,62443]
===
match
---
name: self [76198,76202]
name: self [76332,76336]
===
match
---
name: schedulable_tis [47134,47149]
name: schedulable_tis [47134,47149]
===
match
---
simple_stmt [18918,18950]
simple_stmt [18918,18950]
===
match
---
comparison [23934,23960]
comparison [23934,23960]
===
match
---
simple_stmt [54845,54862]
simple_stmt [54845,54862]
===
match
---
operator: = [5080,5081]
operator: = [5080,5081]
===
match
---
trailer [3661,3663]
trailer [3661,3663]
===
match
---
expr_stmt [22612,22633]
expr_stmt [22612,22633]
===
match
---
simple_stmt [5919,5977]
simple_stmt [5919,5977]
===
match
---
arith_expr [60533,60567]
arith_expr [60667,60701]
===
match
---
funcdef [59602,65944]
funcdef [59736,66078]
===
match
---
trailer [70505,70512]
trailer [70639,70646]
===
match
---
name: State [5251,5256]
name: State [5251,5256]
===
match
---
simple_stmt [70920,70993]
simple_stmt [71054,71127]
===
match
---
operator: @ [45618,45619]
operator: @ [45618,45619]
===
match
---
trailer [40549,40560]
trailer [40549,40560]
===
match
---
trailer [22744,22756]
trailer [22744,22756]
===
match
---
raise_stmt [67380,67468]
raise_stmt [67514,67602]
===
match
---
trailer [6842,6897]
trailer [6842,6897]
===
match
---
name: Optional [16057,16065]
name: Optional [16057,16065]
===
match
---
expr_stmt [5549,5596]
expr_stmt [5549,5596]
===
match
---
name: session [59633,59640]
name: session [59767,59774]
===
match
---
trailer [41019,41026]
trailer [41019,41026]
===
match
---
funcdef [28088,28553]
funcdef [28088,28553]
===
match
---
name: VariableAccessor [62451,62467]
name: VariableAccessor [62585,62601]
===
match
---
name: ID_LEN [10396,10402]
name: ID_LEN [10396,10402]
===
match
---
atom_expr [72505,72520]
atom_expr [72639,72654]
===
match
---
name: render_templates [48863,48879]
name: render_templates [48863,48879]
===
match
---
atom_expr [52922,52949]
atom_expr [52922,52949]
===
match
---
raise_stmt [50950,51032]
raise_stmt [50950,51032]
===
match
---
arglist [66367,66404]
arglist [66501,66538]
===
match
---
simple_stmt [58118,58488]
simple_stmt [58252,58622]
===
match
---
atom_expr [8739,8750]
atom_expr [8739,8750]
===
match
---
simple_stmt [1630,1828]
simple_stmt [1630,1828]
===
match
---
expr_stmt [46806,46831]
expr_stmt [46806,46831]
===
match
---
atom_expr [78420,78428]
atom_expr [78554,78562]
===
match
---
name: dag_id [78725,78731]
name: dag_id [78859,78865]
===
match
---
name: task [54882,54886]
name: task [54882,54886]
===
match
---
trailer [60481,60496]
trailer [60615,60630]
===
match
---
name: cmd [18356,18359]
name: cmd [18356,18359]
===
match
---
trailer [65108,65129]
trailer [65242,65263]
===
match
---
or_test [23302,23328]
or_test [23302,23328]
===
match
---
trailer [20914,20920]
trailer [20914,20920]
===
match
---
name: SEEK_SET [4036,4044]
name: SEEK_SET [4036,4044]
===
match
---
lambdef [65225,65282]
lambdef [65359,65416]
===
match
---
trailer [43765,43780]
trailer [43765,43780]
===
match
---
testlist_comp [17972,18019]
testlist_comp [17972,18019]
===
match
---
atom_expr [72405,72455]
atom_expr [72539,72589]
===
match
---
simple_stmt [48900,48973]
simple_stmt [48900,48973]
===
match
---
atom_expr [45479,45498]
atom_expr [45479,45498]
===
match
---
name: run_as_user [80057,80068]
name: run_as_user [80191,80202]
===
match
---
suite [82045,82093]
suite [82179,82227]
===
match
---
argument [68485,68512]
argument [68619,68646]
===
match
---
name: default_subject [71947,71962]
name: default_subject [72081,72096]
===
match
---
name: self [50370,50374]
name: self [50370,50374]
===
match
---
file_input [787,82585]
file_input [787,82719]
===
match
---
string: '' [41516,41518]
string: '' [41516,41518]
===
match
---
not_test [32798,32819]
not_test [32798,32819]
===
match
---
expr_stmt [9855,9882]
expr_stmt [9855,9882]
===
match
---
expr_stmt [5065,5140]
expr_stmt [5065,5140]
===
match
---
trailer [46035,46041]
trailer [46035,46041]
===
match
---
name: self [41277,41281]
name: self [41277,41281]
===
match
---
return_stmt [41306,41317]
return_stmt [41306,41317]
===
match
---
trailer [33600,33602]
trailer [33600,33602]
===
match
---
if_stmt [77083,77144]
if_stmt [77217,77278]
===
match
---
name: deps [32439,32443]
name: deps [32439,32443]
===
match
---
name: email [58726,58731]
name: email [58860,58865]
===
match
---
funcdef [19159,19422]
funcdef [19159,19422]
===
match
---
operator: @ [80916,80917]
operator: @ [81050,81051]
===
match
---
name: self [79570,79574]
name: self [79704,79708]
===
match
---
suite [7443,7483]
suite [7443,7483]
===
match
---
operator: = [41781,41782]
operator: = [41781,41782]
===
match
---
trailer [78722,78786]
trailer [78856,78920]
===
match
---
expr_stmt [22287,22319]
expr_stmt [22287,22319]
===
match
---
number: 2 [28502,28503]
number: 2 [28502,28503]
===
match
---
fstring_expr [14755,14769]
fstring_expr [14755,14769]
===
match
---
suite [5614,5977]
suite [5614,5977]
===
match
---
name: try_number [40550,40560]
name: try_number [40550,40560]
===
match
---
trailer [79683,79698]
trailer [79817,79832]
===
match
---
operator: , [65595,65596]
operator: , [65729,65730]
===
match
---
name: task [44901,44905]
name: task [44901,44905]
===
match
---
name: log [50716,50719]
name: log [50716,50719]
===
match
---
operator: = [74105,74106]
operator: = [74239,74240]
===
match
---
simple_stmt [33027,33205]
simple_stmt [33027,33205]
===
match
---
name: dag_id [78127,78133]
name: dag_id [78261,78267]
===
match
---
simple_stmt [41834,42521]
simple_stmt [41834,42521]
===
match
---
name: str [72920,72923]
name: str [73054,73057]
===
match
---
name: pendulum [30336,30344]
name: pendulum [30336,30344]
===
match
---
name: __name__ [3275,3283]
name: __name__ [3275,3283]
===
match
---
trailer [32495,32523]
trailer [32495,32523]
===
match
---
name: error [59118,59123]
name: error [59252,59257]
===
match
---
atom_expr [22471,22482]
atom_expr [22471,22482]
===
match
---
arglist [62006,62013]
arglist [62140,62147]
===
match
---
atom_expr [34504,34555]
atom_expr [34504,34555]
===
match
---
param [14308,14320]
param [14308,14320]
===
match
---
name: UP_FOR_RESCHEDULE [39021,39038]
name: UP_FOR_RESCHEDULE [39021,39038]
===
match
---
trailer [39873,39878]
trailer [39873,39878]
===
match
---
name: self [61287,61291]
name: self [61421,61425]
===
match
---
trailer [20979,20986]
trailer [20979,20986]
===
match
---
name: Optional [15875,15883]
name: Optional [15875,15883]
===
match
---
name: self [47785,47789]
name: self [47785,47789]
===
match
---
argument [71380,71409]
argument [71514,71543]
===
match
---
trailer [5427,5436]
trailer [5427,5436]
===
match
---
operator: @ [25092,25093]
operator: @ [25092,25093]
===
match
---
name: state [12102,12107]
name: state [12102,12107]
===
match
---
operator: { [32967,32968]
operator: { [32967,32968]
===
match
---
name: end_date [72696,72704]
name: end_date [72830,72838]
===
match
---
simple_stmt [69190,69230]
simple_stmt [69324,69364]
===
match
---
name: self [79943,79947]
name: self [80077,80081]
===
match
---
trailer [72342,72368]
trailer [72476,72502]
===
match
---
trailer [45229,45244]
trailer [45229,45244]
===
match
---
operator: , [35658,35659]
operator: , [35658,35659]
===
match
---
operator: , [32509,32510]
operator: , [32509,32510]
===
match
---
trailer [40192,40202]
trailer [40192,40202]
===
match
---
name: self [32496,32500]
name: self [32496,32500]
===
match
---
string: "--local" [18588,18597]
string: "--local" [18588,18597]
===
match
---
parameters [79536,79560]
parameters [79670,79694]
===
match
---
name: Index [10581,10586]
name: Index [10581,10586]
===
match
---
operator: , [11039,11040]
operator: , [11039,11040]
===
match
---
operator: = [71989,71990]
operator: = [72123,72124]
===
match
---
operator: -> [81024,81026]
operator: -> [81158,81160]
===
match
---
name: error [52270,52275]
name: error [52270,52275]
===
match
---
string: """Returns SQLAlchemy filter to query selected task instances""" [77865,77929]
string: """Returns SQLAlchemy filter to query selected task instances""" [77999,78063]
===
match
---
expr_stmt [50361,50408]
expr_stmt [50361,50408]
===
match
---
param [16047,16078]
param [16047,16078]
===
match
---
name: task_id [9460,9467]
name: task_id [9460,9467]
===
match
---
atom_expr [43702,43713]
atom_expr [43702,43713]
===
match
---
trailer [71811,71816]
trailer [71945,71950]
===
match
---
trailer [26826,26830]
trailer [26826,26830]
===
match
---
operator: { [48679,48680]
operator: { [48679,48680]
===
match
---
expr_stmt [27868,27934]
expr_stmt [27868,27934]
===
match
---
trailer [50835,50842]
trailer [50835,50842]
===
match
---
atom_expr [60477,60508]
atom_expr [60611,60642]
===
match
---
name: error_fd [54695,54703]
name: error_fd [54695,54703]
===
match
---
return_stmt [32110,32122]
return_stmt [32110,32122]
===
match
---
param [72933,72944]
param [73067,73078]
===
match
---
operator: , [28503,28504]
operator: , [28503,28504]
===
match
---
atom_expr [37610,37623]
atom_expr [37610,37623]
===
match
---
name: SUCCESS [65274,65281]
name: SUCCESS [65408,65415]
===
match
---
operator: = [3639,3640]
operator: = [3639,3640]
===
match
---
operator: = [23661,23662]
operator: = [23661,23662]
===
match
---
name: _try_number [13302,13313]
name: _try_number [13302,13313]
===
match
---
tfpdef [64026,64035]
tfpdef [64160,64169]
===
match
---
simple_stmt [71218,71262]
simple_stmt [71352,71396]
===
match
---
name: task_id [18007,18014]
name: task_id [18007,18014]
===
match
---
trailer [10791,10832]
trailer [10791,10832]
===
match
---
argument [9564,9580]
argument [9564,9580]
===
match
---
name: state [30178,30183]
name: state [30178,30183]
===
match
---
operator: = [68239,68240]
operator: = [68373,68374]
===
match
---
name: set_duration [45379,45391]
name: set_duration [45379,45391]
===
match
---
name: job_ids [7419,7426]
name: job_ids [7419,7426]
===
match
---
arglist [69278,69290]
arglist [69412,69424]
===
match
---
name: handle_failure_with_callback [58889,58917]
name: handle_failure_with_callback [59023,59051]
===
match
---
funcdef [80998,81079]
funcdef [81132,81213]
===
match
---
name: next_ds_nodash [61469,61483]
name: next_ds_nodash [61603,61617]
===
match
---
funcdef [20636,20989]
funcdef [20636,20989]
===
match
---
simple_stmt [80656,80680]
simple_stmt [80790,80814]
===
match
---
name: dag_id [19413,19419]
name: dag_id [19413,19419]
===
match
---
param [35060,35065]
param [35060,35065]
===
match
---
name: tis [79251,79254]
name: tis [79385,79388]
===
match
---
name: self [37701,37705]
name: self [37701,37705]
===
match
---
operator: , [15825,15826]
operator: , [15825,15826]
===
match
---
name: self [24305,24309]
name: self [24305,24309]
===
match
---
name: e [43392,43393]
name: e [43392,43393]
===
match
---
trailer [72770,72779]
trailer [72904,72913]
===
match
---
if_stmt [18666,18708]
if_stmt [18666,18708]
===
match
---
name: str [53685,53688]
name: str [53685,53688]
===
match
---
name: airflow [2610,2617]
name: airflow [2610,2617]
===
match
---
return_stmt [79017,79264]
return_stmt [79151,79398]
===
match
---
name: task_copy [49766,49775]
name: task_copy [49766,49775]
===
match
---
trailer [72723,72737]
trailer [72857,72871]
===
match
---
name: DagRun [45868,45874]
name: DagRun [45868,45874]
===
match
---
atom_expr [79887,79908]
atom_expr [80021,80042]
===
match
---
argument [15367,15374]
argument [15367,15374]
===
match
---
operator: , [41745,41746]
operator: , [41745,41746]
===
match
---
name: Optional [11134,11142]
name: Optional [11134,11142]
===
match
---
expr_stmt [71218,71261]
expr_stmt [71352,71395]
===
match
---
comparison [24016,24058]
comparison [24016,24058]
===
match
---
if_stmt [13128,13196]
if_stmt [13128,13196]
===
match
---
name: job_ids [5282,5289]
name: job_ids [5282,5289]
===
match
---
atom_expr [52277,52308]
atom_expr [52277,52308]
===
match
---
name: pool [54162,54166]
name: pool [54162,54166]
===
match
---
name: on_failure_callback [52590,52609]
name: on_failure_callback [52590,52609]
===
match
---
trailer [79738,79749]
trailer [79872,79883]
===
match
---
operator: , [64617,64618]
operator: , [64751,64752]
===
match
---
name: current_time [24657,24669]
name: current_time [24657,24669]
===
match
---
name: prev_ti [30247,30254]
name: prev_ti [30247,30254]
===
match
---
name: dep_context [32349,32360]
name: dep_context [32349,32360]
===
match
---
operator: , [64162,64163]
operator: , [64296,64297]
===
match
---
trailer [64292,64296]
trailer [64426,64430]
===
match
---
name: Optional [26485,26493]
name: Optional [26485,26493]
===
match
---
name: Column [10214,10220]
name: Column [10214,10220]
===
match
---
simple_stmt [13932,13962]
simple_stmt [13932,13962]
===
match
---
name: conf [45744,45748]
name: conf [45744,45748]
===
match
---
trailer [37517,37533]
trailer [37517,37533]
===
match
---
operator: = [39598,39599]
operator: = [39598,39599]
===
match
---
expr_stmt [20576,20588]
expr_stmt [20576,20588]
===
match
---
simple_stmt [80739,80761]
simple_stmt [80873,80895]
===
match
---
param [21041,21054]
param [21041,21054]
===
match
---
not_test [38415,38546]
not_test [38415,38546]
===
match
---
name: dependencies_deps [2324,2341]
name: dependencies_deps [2324,2341]
===
match
---
name: job [7367,7370]
name: job [7367,7370]
===
match
---
name: Index [10786,10791]
name: Index [10786,10791]
===
match
---
name: path [14840,14844]
name: path [14840,14844]
===
match
---
funcdef [51831,52232]
funcdef [51831,52232]
===
match
---
atom_expr [68166,68178]
atom_expr [68300,68312]
===
match
---
name: cfg_path [16047,16055]
name: cfg_path [16047,16055]
===
match
---
simple_stmt [67114,67184]
simple_stmt [67248,67318]
===
match
---
string: """Get the email subject content for exceptions.""" [68995,69046]
string: """Get the email subject content for exceptions.""" [69129,69180]
===
match
---
operator: , [72171,72172]
operator: , [72305,72306]
===
match
---
name: RUNNING_DEPS [38141,38153]
name: RUNNING_DEPS [38141,38153]
===
match
---
simple_stmt [14378,14569]
simple_stmt [14378,14569]
===
match
---
operator: , [48027,48028]
operator: , [48027,48028]
===
match
---
name: pool [54484,54488]
name: pool [54484,54488]
===
match
---
trailer [20854,20860]
trailer [20854,20860]
===
match
---
trailer [58849,58856]
trailer [58983,58990]
===
match
---
name: nullable [10074,10082]
name: nullable [10074,10082]
===
match
---
name: result [76777,76783]
name: result [76911,76917]
===
match
---
param [30892,30897]
param [30892,30897]
===
match
---
param [14070,14075]
param [14070,14075]
===
match
---
suite [58801,58834]
suite [58935,58968]
===
match
---
operator: } [7800,7801]
operator: } [7800,7801]
===
match
---
operator: , [26326,26327]
operator: , [26326,26327]
===
match
---
trailer [79891,79908]
trailer [80025,80042]
===
match
---
decorated [80916,80979]
decorated [81050,81113]
===
match
---
name: state [29173,29178]
name: state [29173,29178]
===
match
---
trailer [40804,40813]
trailer [40804,40813]
===
match
---
name: conditions [7239,7249]
name: conditions [7239,7249]
===
match
---
trailer [52789,52795]
trailer [52789,52795]
===
match
---
operator: , [10012,10013]
operator: , [10012,10013]
===
match
---
import_as_names [2349,2379]
import_as_names [2349,2379]
===
match
---
fstring_expr [62174,62187]
fstring_expr [62308,62321]
===
match
---
name: dep_context [30898,30909]
name: dep_context [30898,30909]
===
match
---
trailer [8164,8184]
trailer [8164,8184]
===
match
---
import_from [2380,2414]
import_from [2380,2414]
===
match
---
funcdef [28572,29092]
funcdef [28572,29092]
===
match
---
parameters [59264,59270]
parameters [59398,59404]
===
match
---
trailer [21605,21778]
trailer [21605,21778]
===
match
---
operator: , [70575,70576]
operator: , [70709,70710]
===
match
---
atom_expr [17930,17956]
atom_expr [17930,17956]
===
match
---
return_stmt [29043,29091]
return_stmt [29043,29091]
===
match
---
param [24416,24427]
param [24416,24427]
===
match
---
name: execution_date [61114,61128]
name: execution_date [61248,61262]
===
match
---
and_test [14784,14826]
and_test [14784,14826]
===
match
---
name: should_pass_filepath [14784,14804]
name: should_pass_filepath [14784,14804]
===
match
---
arglist [72083,72132]
arglist [72217,72266]
===
match
---
string: """         Immediately runs the task (without checking or changing db state         before execution) and then sets the appropriate final state after         completion and runs any post-execute callbacks. Meant to be called         only after another function changes the state to running.          :param mark_success: Don't run the task, mark its state as success         :type mark_success: bool         :param test_mode: Doesn't record success or failure in the DB         :type test_mode: bool         :param pool: specifies the pool to use to run the task instance         :type pool: str         :param session: SQLAlchemy ORM Session         :type session: Session         """ [41834,42520]
string: """         Immediately runs the task (without checking or changing db state         before execution) and then sets the appropriate final state after         completion and runs any post-execute callbacks. Meant to be called         only after another function changes the state to running.          :param mark_success: Don't run the task, mark its state as success         :type mark_success: bool         :param test_mode: Doesn't record success or failure in the DB         :type test_mode: bool         :param pool: specifies the pool to use to run the task instance         :type pool: str         :param session: SQLAlchemy ORM Session         :type session: Session         """ [41834,42520]
===
match
---
operator: , [34519,34520]
operator: , [34519,34520]
===
match
---
trailer [18222,18230]
trailer [18222,18230]
===
match
---
operator: , [58243,58244]
operator: , [58377,58378]
===
match
---
trailer [68244,68251]
trailer [68378,68385]
===
match
---
atom_expr [58721,58731]
atom_expr [58855,58865]
===
match
---
simple_stmt [67672,67760]
simple_stmt [67806,67894]
===
match
---
name: end_date [25015,25023]
name: end_date [25015,25023]
===
match
---
trailer [5133,5138]
trailer [5133,5138]
===
match
---
operator: = [61993,61994]
operator: = [62127,62128]
===
match
---
operator: == [78977,78979]
operator: == [79111,79113]
===
match
---
trailer [37752,37782]
trailer [37752,37782]
===
match
---
trailer [79139,79147]
trailer [79273,79281]
===
match
---
param [52264,52269]
param [52264,52269]
===
match
---
atom_expr [69255,69291]
atom_expr [69389,69425]
===
match
---
operator: = [71117,71118]
operator: = [71251,71252]
===
match
---
name: ignore_all_deps [15085,15100]
name: ignore_all_deps [15085,15100]
===
match
---
parameters [18902,18908]
parameters [18902,18908]
===
match
---
atom_expr [71920,71963]
atom_expr [72054,72097]
===
match
---
suite [54231,54251]
suite [54231,54251]
===
match
---
name: error [20640,20645]
name: error [20640,20645]
===
match
---
atom_expr [68568,68588]
atom_expr [68702,68722]
===
match
---
trailer [55266,55268]
trailer [55266,55268]
===
match
---
return_stmt [28523,28552]
return_stmt [28523,28552]
===
match
---
name: task [42541,42545]
name: task [42541,42545]
===
match
---
suite [43399,43433]
suite [43399,43433]
===
match
---
operator: @ [19427,19428]
operator: @ [19427,19428]
===
match
---
name: prev_execution_date [64963,64982]
name: prev_execution_date [65097,65116]
===
match
---
return_stmt [80817,80840]
return_stmt [80951,80974]
===
match
---
if_stmt [34632,34724]
if_stmt [34632,34724]
===
match
---
param [13366,13370]
param [13366,13370]
===
match
---
simple_stmt [80481,80502]
simple_stmt [80615,80636]
===
match
---
name: ti [79590,79592]
name: ti [79724,79726]
===
match
---
name: self [26119,26123]
name: self [26119,26123]
===
match
---
name: try_number [59367,59377]
name: try_number [59501,59511]
===
match
---
operator: = [61175,61176]
operator: = [61309,61310]
===
match
---
simple_stmt [55845,55865]
simple_stmt [55845,55865]
===
match
---
name: COLLATION_ARGS [9566,9580]
name: COLLATION_ARGS [9566,9580]
===
match
---
simple_stmt [72795,72852]
simple_stmt [72929,72986]
===
match
---
simple_stmt [19514,19559]
simple_stmt [19514,19559]
===
match
---
name: test_mode [45541,45550]
name: test_mode [45541,45550]
===
match
---
atom_expr [35945,35958]
atom_expr [35945,35958]
===
match
---
trailer [66581,66927]
trailer [66715,67061]
===
match
---
trailer [59552,59557]
trailer [59686,59691]
===
match
---
name: dag [5370,5373]
name: dag [5370,5373]
===
match
---
name: TaskInstance [21667,21679]
name: TaskInstance [21667,21679]
===
match
---
name: key [76306,76309]
name: key [76440,76443]
===
match
---
atom_expr [33818,33830]
atom_expr [33818,33830]
===
match
---
atom [18069,18087]
atom [18069,18087]
===
match
---
name: orm [1480,1483]
name: orm [1480,1483]
===
match
---
atom_expr [81027,81040]
atom_expr [81161,81174]
===
match
---
argument [53838,53853]
argument [53838,53853]
===
match
---
string: 'ti_dag_date' [10633,10646]
string: 'ti_dag_date' [10633,10646]
===
match
---
name: _try_number [13982,13993]
name: _try_number [13982,13993]
===
match
---
operator: , [66519,66520]
operator: , [66653,66654]
===
match
---
name: exception [72217,72226]
name: exception [72351,72360]
===
match
---
try_stmt [4108,4248]
try_stmt [4108,4248]
===
match
---
trailer [72082,72133]
trailer [72216,72267]
===
match
---
name: base_job [82412,82420]
name: base_job [82546,82554]
===
match
---
operator: , [79213,79214]
operator: , [79347,79348]
===
match
---
number: 1 [10071,10072]
number: 1 [10071,10072]
===
match
---
name: dag [14756,14759]
name: dag [14756,14759]
===
match
---
return_stmt [76970,76997]
return_stmt [77104,77131]
===
match
---
name: e [43267,43268]
name: e [43267,43268]
===
match
---
atom_expr [11336,11369]
atom_expr [11336,11369]
===
match
---
operator: = [76401,76402]
operator: = [76535,76536]
===
match
---
atom_expr [54882,54910]
atom_expr [54882,54910]
===
match
---
name: self [44930,44934]
name: self [44930,44934]
===
match
---
string: "TaskInstance" [77790,77804]
string: "TaskInstance" [77924,77938]
===
match
---
not_test [77941,77948]
not_test [78075,78082]
===
match
---
operator: , [11791,11792]
operator: , [11791,11792]
===
match
---
name: dag_id [8744,8750]
name: dag_id [8744,8750]
===
match
---
name: self [15013,15017]
name: self [15013,15017]
===
match
---
name: dag_id [9533,9539]
name: dag_id [9533,9539]
===
match
---
name: next_execution_date [61237,61256]
name: next_execution_date [61371,61390]
===
match
---
if_stmt [37920,40425]
if_stmt [37920,40425]
===
match
---
suite [77949,77974]
suite [78083,78108]
===
match
---
trailer [46862,46897]
trailer [46862,46897]
===
match
---
expr_stmt [20530,20549]
expr_stmt [20530,20549]
===
match
---
atom_expr [42781,42798]
atom_expr [42781,42798]
===
match
---
or_test [27643,27693]
or_test [27643,27693]
===
match
---
name: info [58127,58131]
name: info [58261,58265]
===
match
---
name: reason [32752,32758]
name: reason [32752,32758]
===
match
---
name: sha1 [33733,33737]
name: sha1 [33733,33737]
===
match
---
name: dag_id [78842,78848]
name: dag_id [78976,78982]
===
match
---
string: 'params' [64832,64840]
string: 'params' [64966,64974]
===
match
---
simple_stmt [28119,28259]
simple_stmt [28119,28259]
===
match
---
name: render_template_fields [68024,68046]
name: render_template_fields [68158,68180]
===
match
---
operator: @ [29097,29098]
operator: @ [29097,29098]
===
match
---
name: ti [5344,5346]
name: ti [5344,5346]
===
match
---
name: self [22563,22567]
name: self [22563,22567]
===
match
---
trailer [79652,79668]
trailer [79786,79802]
===
match
---
simple_stmt [1924,1969]
simple_stmt [1924,1969]
===
match
---
trailer [55533,55542]
trailer [55533,55542]
===
match
---
operator: == [26116,26118]
operator: == [26116,26118]
===
match
---
atom_expr [8723,8798]
atom_expr [8723,8798]
===
match
---
expr_stmt [68152,68178]
expr_stmt [68286,68312]
===
match
---
operator: == [53024,53026]
operator: == [53024,53026]
===
match
---
operator: , [63774,63775]
operator: , [63908,63909]
===
match
---
trailer [78907,78938]
trailer [79041,79072]
===
match
---
trailer [39959,40225]
trailer [39959,40225]
===
match
---
simple_stmt [18195,18233]
simple_stmt [18195,18233]
===
match
---
trailer [27712,27720]
trailer [27712,27720]
===
match
---
name: XCOM_RETURN_KEY [51773,51788]
name: XCOM_RETURN_KEY [51773,51788]
===
match
---
trailer [7834,7836]
trailer [7834,7836]
===
match
---
name: RUNNING [40753,40760]
name: RUNNING [40753,40760]
===
match
---
name: Any [72940,72943]
name: Any [73074,73077]
===
match
---
arith_expr [37879,37896]
arith_expr [37879,37896]
===
match
---
trailer [41238,41243]
trailer [41238,41243]
===
match
---
simple_stmt [64277,64351]
simple_stmt [64411,64485]
===
match
---
atom_expr [61287,61306]
atom_expr [61421,61440]
===
match
---
trailer [6616,7188]
trailer [6616,7188]
===
match
---
operator: -> [81407,81409]
operator: -> [81541,81543]
===
match
---
name: task [72510,72514]
name: task [72644,72648]
===
match
---
if_stmt [41061,41298]
if_stmt [41061,41298]
===
match
---
name: pendulum [29836,29844]
name: pendulum [29836,29844]
===
match
---
name: task_copy [51415,51424]
name: task_copy [51415,51424]
===
match
---
fstring_expr [19371,19376]
fstring_expr [19371,19376]
===
match
---
name: self [22059,22063]
name: self [22059,22063]
===
match
---
expr_stmt [23571,23601]
expr_stmt [23571,23601]
===
match
---
name: cfg_path [14348,14356]
name: cfg_path [14348,14356]
===
match
---
import_from [2722,2786]
import_from [2722,2786]
===
match
---
simple_stmt [46806,46832]
simple_stmt [46806,46832]
===
match
---
name: Exception [44725,44734]
name: Exception [44725,44734]
===
match
---
atom_expr [76835,76847]
atom_expr [76969,76981]
===
match
---
tfpdef [63765,63774]
tfpdef [63899,63908]
===
match
---
arglist [8546,8568]
arglist [8546,8568]
===
match
---
expr_stmt [8074,8098]
expr_stmt [8074,8098]
===
match
---
name: AirflowSmartSensorException [1773,1800]
name: AirflowSmartSensorException [1773,1800]
===
match
---
arglist [50725,50764]
arglist [50725,50764]
===
match
---
atom_expr [23849,23885]
atom_expr [23849,23885]
===
match
---
trailer [66333,66339]
trailer [66467,66473]
===
match
---
string: "Task received SIGTERM signal" [48465,48495]
string: "Task received SIGTERM signal" [48465,48495]
===
match
---
operator: = [15930,15931]
operator: = [15930,15931]
===
match
---
trailer [52970,52990]
trailer [52970,52990]
===
match
---
name: pool_slots [23360,23370]
name: pool_slots [23360,23370]
===
match
---
string: '-' [62083,62086]
string: '-' [62217,62220]
===
match
---
or_test [24857,24921]
or_test [24857,24921]
===
match
---
name: has_task [5382,5390]
name: has_task [5382,5390]
===
match
---
atom_expr [6065,6074]
atom_expr [6065,6074]
===
match
---
decorated [19853,20610]
decorated [19853,20610]
===
match
---
name: default [9840,9847]
name: default [9840,9847]
===
match
---
operator: -> [8619,8621]
operator: -> [8619,8621]
===
match
---
string: "Refreshing TaskInstance %s from DB" [21512,21548]
string: "Refreshing TaskInstance %s from DB" [21512,21548]
===
match
---
param [25123,25127]
param [25123,25127]
===
match
---
name: incr [50532,50536]
name: incr [50532,50536]
===
match
---
atom_expr [71493,71507]
atom_expr [71627,71641]
===
match
---
name: timezone [42781,42789]
name: timezone [42781,42789]
===
match
---
simple_stmt [38597,38610]
simple_stmt [38597,38610]
===
match
---
name: session [7259,7266]
name: session [7259,7266]
===
match
---
name: dagrun [60054,60060]
name: dagrun [60188,60194]
===
match
---
name: first [60267,60272]
name: first [60401,60406]
===
match
---
operator: = [15693,15694]
operator: = [15693,15694]
===
match
---
atom_expr [32008,32027]
atom_expr [32008,32027]
===
match
---
name: State [77532,77537]
name: State [77666,77671]
===
match
---
atom_expr [80280,80288]
atom_expr [80414,80422]
===
match
---
name: KubeConfig [68166,68176]
name: KubeConfig [68300,68310]
===
match
---
import_name [805,819]
import_name [805,819]
===
match
---
trailer [53264,53273]
trailer [53264,53273]
===
match
---
parameters [54781,54787]
parameters [54781,54787]
===
match
---
name: utcnow [42790,42796]
name: utcnow [42790,42796]
===
match
---
return_stmt [35497,35506]
return_stmt [35497,35506]
===
match
---
expr_stmt [59734,59750]
expr_stmt [59868,59884]
===
match
---
trailer [48519,48551]
trailer [48519,48551]
===
match
---
operator: = [61484,61485]
operator: = [61618,61619]
===
match
---
simple_stmt [56636,56653]
simple_stmt [56770,56787]
===
match
---
trailer [8553,8564]
trailer [8553,8564]
===
match
---
name: str [3952,3955]
name: str [3952,3955]
===
match
---
operator: , [38172,38173]
operator: , [38172,38173]
===
match
---
name: Optional [3937,3945]
name: Optional [3937,3945]
===
match
---
operator: = [50077,50078]
operator: = [50077,50078]
===
match
---
tfpdef [41755,41780]
tfpdef [41755,41780]
===
match
---
name: e [44650,44651]
name: e [44650,44651]
===
match
---
atom_expr [16017,16030]
atom_expr [16017,16030]
===
match
---
suite [56358,56627]
suite [56358,56761]
===
match
---
tfpdef [67832,67858]
tfpdef [67966,67992]
===
match
---
name: dill [10347,10351]
name: dill [10347,10351]
===
match
---
name: conf [19578,19582]
name: conf [19578,19582]
===
match
---
operator: , [53359,53360]
operator: , [53359,53360]
===
match
---
trailer [9779,9791]
trailer [9779,9791]
===
match
---
name: ti [21993,21995]
name: ti [21993,21995]
===
match
---
trailer [13150,13158]
trailer [13150,13158]
===
match
---
name: get_previous_start_date [29726,29749]
name: get_previous_start_date [29726,29749]
===
match
---
atom_expr [28530,28552]
atom_expr [28530,28552]
===
match
---
expr_stmt [11917,11973]
expr_stmt [11917,11973]
===
match
---
name: dep_context [39782,39793]
name: dep_context [39782,39793]
===
match
---
trailer [6109,6113]
trailer [6109,6113]
===
match
---
parameters [62968,62974]
parameters [63102,63108]
===
match
---
name: start_date [24819,24829]
name: start_date [24819,24829]
===
match
---
name: isoformat [18984,18993]
name: isoformat [18984,18993]
===
match
---
expr_stmt [22830,22847]
expr_stmt [22830,22847]
===
match
---
simple_stmt [72766,72787]
simple_stmt [72900,72921]
===
match
---
name: pool [18651,18655]
name: pool [18651,18655]
===
match
---
trailer [11712,11720]
trailer [11712,11720]
===
match
---
string: """         The start date from property previous_ti_success.          :param state: If passed, it only take into account instances of a specific state.         :param session: SQLAlchemy ORM Session         """ [29864,30075]
string: """         The start date from property previous_ti_success.          :param state: If passed, it only take into account instances of a specific state.         :param session: SQLAlchemy ORM Session         """ [29864,30075]
===
match
---
name: provide_session [20995,21010]
name: provide_session [20995,21010]
===
match
---
name: self [52785,52789]
name: self [52785,52789]
===
match
---
operator: , [49547,49548]
operator: , [49547,49548]
===
match
---
string: """         Pull XComs that optionally meet certain criteria.          The default value for `key` limits the search to XComs         that were returned by other tasks (as opposed to those that were pushed         manually). To remove this filter, pass key=None (or any desired value).          If a single task_id string is provided, the result is the value of the         most recent matching XCom from that task_id. If multiple task_ids are         provided, a tuple of matching values is returned. None is returned         whenever no matches are found.          :param key: A key for the XCom. If provided, only XComs with matching             keys will be returned. The default key is 'return_value', also             available as a constant XCOM_RETURN_KEY. This key is automatically             given to XComs returned by tasks (as opposed to being pushed             manually). To remove the filter, pass key=None.         :type key: str         :param task_ids: Only XComs from tasks with matching ids will be             pulled. Can pass None to remove the filter.         :type task_ids: str or iterable of strings (representing task_ids)         :param dag_id: If provided, only pulls XComs from this DAG.             If None (default), the DAG of the calling task is used.         :type dag_id: str         :param include_prior_dates: If False, only XComs from the current             execution_date are returned. If True, XComs from previous dates             are returned as well.         :type include_prior_dates: bool         :param session: Sqlalchemy ORM Session         :type session: Session         """ [74523,76149]
string: """         Pull XComs that optionally meet certain criteria.          The default value for `key` limits the search to XComs         that were returned by other tasks (as opposed to those that were pushed         manually). To remove this filter, pass key=None (or any desired value).          If a single task_id string is provided, the result is the value of the         most recent matching XCom from that task_id. If multiple task_ids are         provided, a tuple of matching values is returned. None is returned         whenever no matches are found.          :param key: A key for the XCom. If provided, only XComs with matching             keys will be returned. The default key is 'return_value', also             available as a constant XCOM_RETURN_KEY. This key is automatically             given to XComs returned by tasks (as opposed to being pushed             manually). To remove the filter, pass key=None.         :type key: str         :param task_ids: Only XComs from tasks with matching ids will be             pulled. Can pass None to remove the filter.         :type task_ids: str or iterable of strings (representing task_ids)         :param dag_id: If provided, only pulls XComs from this DAG.             If None (default), the DAG of the calling task is used.         :type dag_id: str         :param include_prior_dates: If False, only XComs from the current             execution_date are returned. If True, XComs from previous dates             are returned as well.         :type include_prior_dates: bool         :param session: Sqlalchemy ORM Session         :type session: Session         """ [74657,76283]
===
match
---
operator: - [71458,71459]
operator: - [71592,71593]
===
match
---
suite [73043,74184]
suite [73177,74318]
===
match
---
operator: = [47913,47914]
operator: = [47913,47914]
===
match
---
param [26472,26477]
param [26472,26477]
===
match
---
simple_stmt [37863,37911]
simple_stmt [37863,37911]
===
match
---
trailer [22799,22803]
trailer [22799,22803]
===
match
---
operator: , [48036,48037]
operator: , [48036,48037]
===
match
---
atom_expr [71711,71733]
atom_expr [71845,71867]
===
match
---
argument [15177,15222]
argument [15177,15222]
===
match
---
string: "\n" [37879,37883]
string: "\n" [37879,37883]
===
match
---
trailer [11797,11802]
trailer [11797,11802]
===
match
---
fstring [47820,47883]
fstring [47820,47883]
===
match
---
name: _prepare_and_execute_task_with_callbacks [47982,48022]
name: _prepare_and_execute_task_with_callbacks [47982,48022]
===
match
---
trailer [26052,26074]
trailer [26052,26074]
===
match
---
name: ID_LEN [9484,9490]
name: ID_LEN [9484,9490]
===
match
---
trailer [11720,11722]
trailer [11720,11722]
===
match
---
simple_stmt [27625,27694]
simple_stmt [27625,27694]
===
match
---
name: TaskInstance [21585,21597]
name: TaskInstance [21585,21597]
===
match
---
name: merge [58822,58827]
name: merge [58956,58961]
===
match
---
parameters [81265,81271]
parameters [81399,81405]
===
match
---
operator: , [46675,46676]
operator: , [46675,46676]
===
match
---
atom_expr [58372,58418]
atom_expr [58506,58552]
===
match
---
name: log [40507,40510]
name: log [40507,40510]
===
match
---
if_stmt [66224,66935]
if_stmt [66358,67069]
===
match
---
simple_stmt [10200,10234]
simple_stmt [10200,10234]
===
match
---
name: next_ds [61317,61324]
name: next_ds [61451,61458]
===
match
---
simple_stmt [7526,7592]
simple_stmt [7526,7592]
===
match
---
trailer [51522,51524]
trailer [51522,51524]
===
match
---
suite [26846,28048]
suite [26846,28048]
===
match
---
atom_expr [7935,7952]
atom_expr [7935,7952]
===
match
---
expr_stmt [19278,19322]
expr_stmt [19278,19322]
===
match
---
atom_expr [62062,62091]
atom_expr [62196,62225]
===
match
---
name: from_string [70940,70951]
name: from_string [71074,71085]
===
match
---
operator: , [10646,10647]
operator: , [10646,10647]
===
match
---
name: ds_nodash [61869,61878]
name: ds_nodash [62003,62012]
===
match
---
number: 0 [9848,9849]
number: 0 [9848,9849]
===
match
---
param [56036,56065]
param [56036,56065]
===
match
---
simple_stmt [9533,9601]
simple_stmt [9533,9601]
===
match
---
name: stacklevel [29011,29021]
name: stacklevel [29011,29021]
===
match
---
name: path [71704,71708]
name: path [71838,71842]
===
match
---
trailer [26046,26052]
trailer [26046,26052]
===
match
---
simple_stmt [34051,34101]
simple_stmt [34051,34101]
===
match
---
operator: -> [67867,67869]
operator: -> [68001,68003]
===
match
---
simple_stmt [18629,18658]
simple_stmt [18629,18658]
===
match
---
expr_stmt [78142,78179]
expr_stmt [78276,78313]
===
match
---
operator: } [19736,19737]
operator: } [19736,19737]
===
match
---
name: COLLATION_ARGS [1860,1874]
name: COLLATION_ARGS [1860,1874]
===
match
---
atom_expr [10581,10617]
atom_expr [10581,10617]
===
match
---
name: ti [48854,48856]
name: ti [48854,48856]
===
match
---
dictorsetmaker [76738,76860]
dictorsetmaker [76872,76994]
===
match
---
name: render_k8s_pod_yaml [67276,67295]
name: render_k8s_pod_yaml [67410,67429]
===
match
---
name: stats [2233,2238]
name: stats [2233,2238]
===
match
---
name: bool [35731,35735]
name: bool [35731,35735]
===
match
---
trailer [42749,42751]
trailer [42749,42751]
===
match
---
name: lock_for_update [37551,37566]
name: lock_for_update [37551,37566]
===
match
---
string: "DagModel" [10915,10925]
string: "DagModel" [10915,10925]
===
match
---
operator: , [10814,10815]
operator: , [10814,10815]
===
match
---
operator: = [49704,49705]
operator: = [49704,49705]
===
match
---
name: state [27643,27648]
name: state [27643,27648]
===
match
---
trailer [23294,23299]
trailer [23294,23299]
===
match
---
name: try_number [68376,68386]
name: try_number [68510,68520]
===
match
---
name: full_filepath [14851,14864]
name: full_filepath [14851,14864]
===
match
---
expr_stmt [71554,71594]
expr_stmt [71688,71728]
===
match
---
operator: { [19407,19408]
operator: { [19407,19408]
===
match
---
atom_expr [82186,82214]
atom_expr [82320,82348]
===
match
---
testlist_comp [18207,18230]
testlist_comp [18207,18230]
===
match
---
suite [45551,45613]
suite [45551,45613]
===
match
---
simple_stmt [3589,3603]
simple_stmt [3589,3603]
===
match
---
argument [68400,68433]
argument [68534,68567]
===
match
---
expr_stmt [66130,66215]
expr_stmt [66264,66349]
===
match
---
decorated [81315,82154]
decorated [81449,82288]
===
match
---
atom_expr [38564,38580]
atom_expr [38564,38580]
===
match
---
operator: , [55511,55512]
operator: , [55511,55512]
===
match
---
atom_expr [11206,11217]
atom_expr [11206,11217]
===
match
---
param [53355,53360]
param [53355,53360]
===
match
---
name: ts [65615,65617]
name: ts [65749,65751]
===
match
---
comp_op [47201,47207]
comp_op [47201,47207]
===
match
---
atom_expr [6023,6040]
atom_expr [6023,6040]
===
match
---
name: start_date [30255,30265]
name: start_date [30255,30265]
===
match
---
name: timedelta [60555,60564]
name: timedelta [60689,60698]
===
match
---
name: log [41235,41238]
name: log [41235,41238]
===
match
---
expr_stmt [82058,82092]
expr_stmt [82192,82226]
===
match
---
operator: = [80307,80308]
operator: = [80441,80442]
===
match
---
argument [76302,76309]
argument [76436,76443]
===
match
---
atom_expr [80574,80594]
atom_expr [80708,80728]
===
match
---
return_stmt [38597,38609]
return_stmt [38597,38609]
===
match
---
expr_stmt [17965,18020]
expr_stmt [17965,18020]
===
match
---
name: force_fail [59146,59156]
name: force_fail [59280,59290]
===
match
---
simple_stmt [24698,24761]
simple_stmt [24698,24761]
===
match
---
string: '' [61897,61899]
string: '' [62031,62033]
===
match
---
return_stmt [8716,8798]
return_stmt [8716,8798]
===
match
---
trailer [28021,28029]
trailer [28021,28029]
===
match
---
name: dag_run [67560,67567]
name: dag_run [67694,67701]
===
match
---
arith_expr [8549,8568]
arith_expr [8549,8568]
===
match
---
trailer [61769,61777]
trailer [61903,61911]
===
match
---
operator: @ [80766,80767]
operator: @ [80900,80901]
===
match
---
operator: , [74143,74144]
operator: , [74277,74278]
===
match
---
trailer [20850,20854]
trailer [20850,20854]
===
match
---
simple_stmt [55235,55269]
simple_stmt [55235,55269]
===
match
---
name: self [81364,81368]
name: self [81498,81502]
===
match
---
param [23648,23653]
param [23648,23653]
===
match
---
suite [59942,60409]
suite [60076,60543]
===
match
---
argument [68603,68635]
argument [68737,68769]
===
match
---
operator: = [27351,27352]
operator: = [27351,27352]
===
match
---
name: read [4060,4064]
name: read [4060,4064]
===
match
---
name: task_id [48951,48958]
name: task_id [48951,48958]
===
match
---
trailer [35417,35432]
trailer [35417,35432]
===
match
---
atom_expr [79137,79147]
atom_expr [79271,79281]
===
match
---
atom_expr [18742,18777]
atom_expr [18742,18777]
===
match
---
name: execution_date [12005,12019]
name: execution_date [12005,12019]
===
match
---
name: ts_nodash [65644,65653]
name: ts_nodash [65778,65787]
===
match
---
operator: , [33816,33817]
operator: , [33816,33817]
===
match
---
name: AirflowException [1667,1683]
name: AirflowException [1667,1683]
===
match
---
name: TaskInstanceStateType [79340,79361]
name: TaskInstanceStateType [79474,79495]
===
match
---
expr_stmt [72296,72379]
expr_stmt [72430,72513]
===
match
---
string: 'scheduler' [45760,45771]
string: 'scheduler' [45760,45771]
===
match
---
comparison [21667,21703]
comparison [21667,21703]
===
match
---
simple_stmt [79017,79265]
simple_stmt [79151,79399]
===
match
---
name: result [51819,51825]
name: result [51819,51825]
===
match
---
expr_stmt [47367,47435]
expr_stmt [47367,47435]
===
match
---
import_from [1828,1888]
import_from [1828,1888]
===
match
---
name: Stats [50596,50601]
name: Stats [50596,50601]
===
match
---
name: task_copy [51505,51514]
name: task_copy [51505,51514]
===
match
---
name: NamedTuple [7977,7987]
name: NamedTuple [7977,7987]
===
match
---
trailer [48764,48781]
trailer [48764,48781]
===
match
---
name: timedelta [983,992]
name: timedelta [983,992]
===
match
---
name: airflow [2076,2083]
name: airflow [2076,2083]
===
match
---
trailer [44358,44374]
trailer [44358,44374]
===
match
---
simple_stmt [54244,54251]
simple_stmt [54244,54251]
===
match
---
name: filter [20278,20284]
name: filter [20278,20284]
===
match
---
operator: = [44273,44274]
operator: = [44273,44274]
===
match
---
string: '' [62088,62090]
string: '' [62222,62224]
===
match
---
annassign [8113,8118]
annassign [8113,8118]
===
match
---
operator: = [51413,51414]
operator: = [51413,51414]
===
match
---
trailer [25330,25336]
trailer [25330,25336]
===
match
---
trailer [58827,58833]
trailer [58961,58967]
===
match
---
operator: != [14705,14707]
operator: != [14705,14707]
===
match
---
name: session [41797,41804]
name: session [41797,41804]
===
match
---
name: _prepare_and_execute_task_with_callbacks [42981,43021]
name: _prepare_and_execute_task_with_callbacks [42981,43021]
===
match
---
trailer [57005,57014]
trailer [57139,57148]
===
match
---
operator: { [46945,46946]
operator: { [46945,46946]
===
match
---
atom_expr [9905,9917]
atom_expr [9905,9917]
===
match
---
name: self [21035,21039]
name: self [21035,21039]
===
match
---
trailer [79711,79723]
trailer [79845,79857]
===
match
---
operator: , [68331,68332]
operator: , [68465,68466]
===
match
---
name: queued_dttm [22745,22756]
name: queued_dttm [22745,22756]
===
match
---
operator: @ [80846,80847]
operator: @ [80980,80981]
===
match
---
name: dag_id [60190,60196]
name: dag_id [60324,60330]
===
match
---
trailer [51432,51449]
trailer [51432,51449]
===
match
---
operator: = [37877,37878]
operator: = [37877,37878]
===
match
---
operator: , [21053,21054]
operator: , [21053,21054]
===
match
---
operator: = [33219,33220]
operator: = [33219,33220]
===
match
---
name: default_var [63155,63166]
name: default_var [63289,63300]
===
match
---
arglist [58690,58731]
arglist [58824,58865]
===
match
---
argument [44664,44685]
argument [44664,44685]
===
match
---
name: is_premature [25110,25122]
name: is_premature [25110,25122]
===
match
---
arglist [39488,39722]
arglist [39488,39722]
===
match
---
suite [48044,50623]
suite [48044,50623]
===
match
---
name: error [52148,52153]
name: error [52148,52153]
===
match
---
name: TaskInstance [26208,26220]
name: TaskInstance [26208,26220]
===
match
---
simple_stmt [44773,44830]
simple_stmt [44773,44830]
===
match
---
string: """         This attribute is deprecated.         Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.         """ [28119,28258]
string: """         This attribute is deprecated.         Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.         """ [28119,28258]
===
match
---
name: self [43993,43997]
name: self [43993,43997]
===
match
---
trailer [79045,79228]
trailer [79179,79362]
===
match
---
name: isoformat [19546,19555]
name: isoformat [19546,19555]
===
match
---
atom_expr [65115,65128]
atom_expr [65249,65262]
===
match
---
parameters [80458,80464]
parameters [80592,80598]
===
match
---
operator: = [4766,4767]
operator: = [4766,4767]
===
match
---
simple_stmt [25319,25390]
simple_stmt [25319,25390]
===
match
---
atom_expr [42692,42703]
atom_expr [42692,42703]
===
match
---
trailer [73769,73947]
trailer [73903,74081]
===
match
---
param [8596,8601]
param [8596,8601]
===
match
---
comp_if [47187,47226]
comp_if [47187,47226]
===
match
---
name: conf [64389,64393]
name: conf [64523,64527]
===
match
---
operator: - [38154,38155]
operator: - [38154,38155]
===
match
---
atom_expr [72494,72548]
atom_expr [72628,72682]
===
match
---
name: _date_or_empty [43766,43780]
name: _date_or_empty [43766,43780]
===
match
---
simple_stmt [2605,2672]
simple_stmt [2605,2672]
===
match
---
number: 1 [71460,71461]
number: 1 [71594,71595]
===
match
---
operator: + [19636,19637]
operator: + [19636,19637]
===
match
---
name: self [31721,31725]
name: self [31721,31725]
===
match
---
trailer [3562,3571]
trailer [3562,3571]
===
match
---
name: XCom [73957,73961]
name: XCom [74091,74095]
===
match
---
name: relationship [10893,10905]
name: relationship [10893,10905]
===
match
---
parameters [72210,72227]
parameters [72344,72361]
===
match
---
param [12681,12685]
param [12681,12685]
===
match
---
trailer [47479,47496]
trailer [47479,47496]
===
match
---
atom_expr [8478,8570]
atom_expr [8478,8570]
===
match
---
name: State [52527,52532]
name: State [52527,52532]
===
match
---
name: scalar [77574,77580]
name: scalar [77708,77714]
===
match
---
expr_stmt [3188,3212]
expr_stmt [3188,3212]
===
match
---
name: task [56636,56640]
name: task [56770,56774]
===
match
---
trailer [11533,11541]
trailer [11533,11541]
===
match
---
name: Exception [4304,4313]
name: Exception [4304,4313]
===
match
---
name: the_log [19091,19098]
name: the_log [19091,19098]
===
match
---
operator: , [45804,45805]
operator: , [45804,45805]
===
match
---
name: provide_session [35513,35528]
name: provide_session [35513,35528]
===
match
---
trailer [40631,40643]
trailer [40631,40643]
===
match
---
simple_stmt [26859,26897]
simple_stmt [26859,26897]
===
match
---
if_stmt [18608,18658]
if_stmt [18608,18658]
===
match
---
simple_stmt [2220,2252]
simple_stmt [2220,2252]
===
match
---
name: on_execute_callback [52033,52052]
name: on_execute_callback [52033,52052]
===
match
---
name: items [66334,66339]
name: items [66468,66473]
===
match
---
name: dag_id [26109,26115]
name: dag_id [26109,26115]
===
match
---
atom_expr [32542,32777]
atom_expr [32542,32777]
===
match
---
expr_stmt [56313,56339]
expr_stmt [56313,56339]
===
match
---
atom_expr [24672,24689]
atom_expr [24672,24689]
===
match
---
argument [31791,31814]
argument [31791,31814]
===
match
---
atom_expr [62190,62202]
atom_expr [62324,62336]
===
match
---
atom_expr [51415,51449]
atom_expr [51415,51449]
===
match
---
trailer [59221,59234]
trailer [59355,59368]
===
match
---
name: TaskInstance [78581,78593]
name: TaskInstance [78715,78727]
===
match
---
name: get [63319,63322]
name: get [63453,63456]
===
match
---
funcdef [62784,62943]
funcdef [62918,63077]
===
match
---
name: self [20846,20850]
name: self [20846,20850]
===
match
---
operator: = [35884,35885]
operator: = [35884,35885]
===
match
---
argument [15046,15071]
argument [15046,15071]
===
match
---
dotted_name [2420,2439]
dotted_name [2420,2439]
===
match
---
name: _start_date [79712,79723]
name: _start_date [79846,79857]
===
match
---
name: str [79971,79974]
name: str [80105,80108]
===
match
---
operator: { [70327,70328]
operator: { [70461,70462]
===
match
---
funcdef [80375,80428]
funcdef [80509,80562]
===
match
---
simple_stmt [18856,18867]
simple_stmt [18856,18867]
===
match
---
trailer [4664,4680]
trailer [4664,4680]
===
match
---
simple_stmt [48094,48165]
simple_stmt [48094,48165]
===
match
---
name: Union [3946,3951]
name: Union [3946,3951]
===
match
---
return_stmt [62992,63012]
return_stmt [63126,63146]
===
match
---
trailer [42936,42957]
trailer [42936,42957]
===
match
---
funcdef [64001,64351]
funcdef [64135,64485]
===
match
---
tfpdef [53438,53466]
tfpdef [53438,53466]
===
match
---
operator: , [58418,58419]
operator: , [58552,58553]
===
match
---
comp_op [59505,59511]
comp_op [59639,59645]
===
match
---
name: default_html_content [69508,69528]
name: default_html_content [69642,69662]
===
match
---
atom_expr [5122,5138]
atom_expr [5122,5138]
===
match
---
name: self [60613,60617]
name: self [60747,60751]
===
match
---
name: dag_id [7687,7693]
name: dag_id [7687,7693]
===
match
---
name: TR [3168,3170]
name: TR [3168,3170]
===
match
---
atom_expr [24871,24885]
atom_expr [24871,24885]
===
match
---
if_stmt [7488,7953]
if_stmt [7488,7953]
===
match
---
name: bool [35771,35775]
name: bool [35771,35775]
===
match
---
yield_expr [32841,32857]
yield_expr [32841,32857]
===
match
---
fstring_start: f' [48673,48675]
fstring_start: f' [48673,48675]
===
match
---
operator: , [48534,48535]
operator: , [48534,48535]
===
match
---
import_from [2877,2927]
import_from [2877,2927]
===
match
---
name: unixname [22474,22482]
name: unixname [22474,22482]
===
match
---
name: bool [53577,53581]
name: bool [53577,53581]
===
match
---
name: seek [4025,4029]
name: seek [4025,4029]
===
match
---
arith_expr [13977,13997]
arith_expr [13977,13997]
===
match
---
name: on_retry_callback [53247,53264]
name: on_retry_callback [53247,53264]
===
match
---
trailer [7634,7642]
trailer [7634,7642]
===
match
---
name: activate_dag_runs [7491,7508]
name: activate_dag_runs [7491,7508]
===
match
---
name: task [52565,52569]
name: task [52565,52569]
===
match
---
trailer [52052,52061]
trailer [52052,52061]
===
match
---
operator: = [9865,9866]
operator: = [9865,9866]
===
match
---
fstring [56742,56779]
fstring [56876,56913]
===
match
---
simple_stmt [25138,25254]
simple_stmt [25138,25254]
===
match
---
name: session [60358,60365]
name: session [60492,60499]
===
match
---
operator: -> [80945,80947]
operator: -> [81079,81081]
===
match
---
funcdef [26443,28069]
funcdef [26443,28069]
===
match
---
name: session [46208,46215]
name: session [46208,46215]
===
match
---
trailer [35346,35352]
trailer [35346,35352]
===
match
---
not_test [4074,4082]
not_test [4074,4082]
===
match
---
name: state [10809,10814]
name: state [10809,10814]
===
match
---
argument [54411,54430]
argument [54411,54430]
===
match
---
trailer [71173,71190]
trailer [71307,71324]
===
match
---
trailer [79809,79821]
trailer [79943,79955]
===
match
---
atom_expr [43816,43849]
atom_expr [43816,43849]
===
match
---
operator: = [57919,57920]
operator: = [58053,58054]
===
match
---
trailer [72509,72514]
trailer [72643,72648]
===
match
---
testlist_comp [67318,67356]
testlist_comp [67452,67490]
===
match
---
string: 'TaskInstance' [28614,28628]
string: 'TaskInstance' [28614,28628]
===
match
---
if_stmt [39152,39237]
if_stmt [39152,39237]
===
match
---
name: dag_id [20315,20321]
name: dag_id [20315,20321]
===
match
---
name: session [21571,21578]
name: session [21571,21578]
===
match
---
arglist [34690,34722]
arglist [34690,34722]
===
match
---
trailer [41122,41126]
trailer [41122,41126]
===
match
---
name: integrate_macros_plugins [59795,59819]
name: integrate_macros_plugins [59929,59953]
===
match
---
atom_expr [33832,33851]
atom_expr [33832,33851]
===
match
---
operator: = [71232,71233]
operator: = [71366,71367]
===
match
---
param [50688,50700]
param [50688,50700]
===
match
---
name: utcnow [45006,45012]
name: utcnow [45006,45012]
===
match
---
fstring_expr [19407,19420]
fstring_expr [19407,19420]
===
match
---
arglist [69216,69228]
arglist [69350,69362]
===
match
---
arglist [4385,4401]
arglist [4385,4401]
===
match
---
name: _executor_config [81293,81309]
name: _executor_config [81427,81443]
===
match
---
if_stmt [56279,56340]
if_stmt [56279,56340]
===
match
---
name: filter_by [60180,60189]
name: filter_by [60314,60323]
===
match
---
arglist [20302,20459]
arglist [20302,20459]
===
match
---
simple_stmt [67034,67105]
simple_stmt [67168,67239]
===
match
---
name: task_retries [5505,5517]
name: task_retries [5505,5517]
===
match
---
operator: = [53882,53883]
operator: = [53882,53883]
===
match
---
arglist [4030,4044]
arglist [4030,4044]
===
match
---
name: property [25093,25101]
name: property [25093,25101]
===
match
---
arglist [39782,39836]
arglist [39782,39836]
===
match
---
name: outlets [64811,64818]
name: outlets [64945,64952]
===
match
---
decorator [80507,80517]
decorator [80641,80651]
===
match
---
string: 'end_date' [58448,58458]
string: 'end_date' [58582,58592]
===
match
---
atom_expr [7374,7434]
atom_expr [7374,7434]
===
match
---
simple_stmt [27226,27238]
simple_stmt [27226,27238]
===
match
---
if_stmt [82026,82136]
if_stmt [82160,82270]
===
match
---
suite [4409,4681]
suite [4409,4681]
===
match
---
name: FAILED [44564,44570]
name: FAILED [44564,44570]
===
match
---
trailer [26868,26879]
trailer [26868,26879]
===
match
---
expr_stmt [55651,55687]
expr_stmt [55651,55687]
===
match
---
operator: , [15222,15223]
operator: , [15222,15223]
===
match
---
trailer [79125,79133]
trailer [79259,79267]
===
match
---
simple_stmt [22700,22728]
simple_stmt [22700,22728]
===
match
---
atom_expr [81137,81148]
atom_expr [81271,81282]
===
match
---
atom_expr [51986,52010]
atom_expr [51986,52010]
===
match
---
funcdef [23628,24148]
funcdef [23628,24148]
===
match
---
name: render_templates [54955,54971]
name: render_templates [54955,54971]
===
match
---
trailer [50263,50265]
trailer [50263,50265]
===
match
---
name: pool [80934,80938]
name: pool [81068,81072]
===
match
---
trailer [71715,71719]
trailer [71849,71853]
===
match
---
trailer [82200,82206]
trailer [82334,82340]
===
match
---
simple_stmt [60517,60590]
simple_stmt [60651,60724]
===
match
---
name: content [71624,71631]
name: content [71758,71765]
===
match
---
name: extend [18127,18133]
name: extend [18127,18133]
===
match
---
name: State [26311,26316]
name: State [26311,26316]
===
match
---
dotted_name [2463,2484]
dotted_name [2463,2484]
===
match
---
trailer [79831,79842]
trailer [79965,79976]
===
match
---
fstring_start: f" [19714,19716]
fstring_start: f" [19714,19716]
===
match
---
simple_stmt [35100,35237]
simple_stmt [35100,35237]
===
match
---
atom_expr [62755,62763]
atom_expr [62889,62897]
===
match
---
simple_stmt [18811,18848]
simple_stmt [18811,18848]
===
match
---
name: self [26864,26868]
name: self [26864,26868]
===
match
---
operator: = [15847,15848]
operator: = [15847,15848]
===
match
---
trailer [45342,45354]
trailer [45342,45354]
===
match
---
operator: = [12379,12380]
operator: = [12379,12380]
===
match
---
name: params [60014,60020]
name: params [60148,60154]
===
match
---
param [30930,30943]
param [30930,30943]
===
match
---
annassign [79582,79599]
annassign [79716,79733]
===
match
---
operator: , [62316,62317]
operator: , [62450,62451]
===
match
---
fstring_expr [32929,32943]
fstring_expr [32929,32943]
===
match
---
name: handle_failure [59097,59111]
name: handle_failure [59231,59245]
===
match
---
name: ti [5564,5566]
name: ti [5564,5566]
===
match
---
arglist [39105,39126]
arglist [39105,39126]
===
match
---
name: min_backoff [34089,34100]
name: min_backoff [34089,34100]
===
match
---
suite [8871,79265]
suite [8871,79399]
===
match
---
trailer [49154,49158]
trailer [49154,49158]
===
match
---
operator: , [15746,15747]
operator: , [15746,15747]
===
match
---
name: mark_success [54063,54075]
name: mark_success [54063,54075]
===
match
---
trailer [30237,30246]
trailer [30237,30246]
===
match
---
name: Exception [49841,49850]
name: Exception [49841,49850]
===
match
---
atom_expr [41277,41296]
atom_expr [41277,41296]
===
match
---
parameters [81175,81181]
parameters [81309,81315]
===
match
---
name: qry [21886,21889]
name: qry [21886,21889]
===
match
---
string: "Refreshed TaskInstance %s" [22872,22899]
string: "Refreshed TaskInstance %s" [22872,22899]
===
match
---
dotted_name [45839,45860]
dotted_name [45839,45860]
===
match
---
return_stmt [62927,62942]
return_stmt [63061,63076]
===
match
---
simple_stmt [57851,57891]
simple_stmt [57985,58025]
===
match
---
dotted_name [2882,2910]
dotted_name [2882,2910]
===
match
---
name: kube_config [68152,68163]
name: kube_config [68286,68297]
===
match
---
name: task_reschedule [39210,39225]
name: task_reschedule [39210,39225]
===
match
---
expr_stmt [21975,22006]
expr_stmt [21975,22006]
===
match
---
suite [52813,53000]
suite [52813,53000]
===
match
---
trailer [78841,78848]
trailer [78975,78982]
===
match
---
name: self [45174,45178]
name: self [45174,45178]
===
match
---
operator: -> [80546,80548]
operator: -> [80680,80682]
===
match
---
operator: @ [19145,19146]
operator: @ [19145,19146]
===
match
---
atom_expr [18811,18847]
atom_expr [18811,18847]
===
match
---
number: 1 [55834,55835]
number: 1 [55834,55835]
===
match
---
name: str [74402,74405]
name: str [74536,74539]
===
match
---
operator: , [7107,7108]
operator: , [7107,7108]
===
match
---
dotted_name [1469,1491]
dotted_name [1469,1491]
===
match
---
name: ti [5919,5921]
name: ti [5919,5921]
===
match
---
name: self [30892,30896]
name: self [30892,30896]
===
match
---
operator: , [14319,14320]
operator: , [14319,14320]
===
match
---
name: xcom [77024,77028]
name: xcom [77158,77162]
===
match
---
trailer [33932,33942]
trailer [33932,33942]
===
match
---
trailer [3657,3661]
trailer [3657,3661]
===
match
---
name: str [3203,3206]
name: str [3203,3206]
===
match
---
atom [60532,60568]
atom [60666,60702]
===
match
---
if_stmt [52855,53000]
if_stmt [52855,53000]
===
match
---
atom_expr [57982,58000]
atom_expr [58116,58134]
===
match
---
trailer [40789,40791]
trailer [40789,40791]
===
match
---
name: dry_run [54774,54781]
name: dry_run [54774,54781]
===
match
---
atom_expr [40242,40273]
atom_expr [40242,40273]
===
match
---
atom_expr [41406,41425]
atom_expr [41406,41425]
===
match
---
name: info [47522,47526]
name: info [47522,47526]
===
match
---
argument [39576,39621]
argument [39576,39621]
===
match
---
funcdef [41323,41519]
funcdef [41323,41519]
===
match
---
annassign [79821,79842]
annassign [79955,79976]
===
match
---
trailer [73889,73896]
trailer [74023,74030]
===
match
---
suite [54264,54579]
suite [54264,54579]
===
match
---
operator: = [27782,27783]
operator: = [27782,27783]
===
match
---
decorator [80916,80926]
decorator [81050,81060]
===
match
---
name: self [77427,77431]
name: self [77561,77565]
===
match
---
operator: , [76847,76848]
operator: , [76981,76982]
===
match
---
name: job_id [42697,42703]
name: job_id [42697,42703]
===
match
---
name: self [69216,69220]
name: self [69350,69354]
===
match
---
expr_stmt [69885,70273]
expr_stmt [70019,70407]
===
match
---
string: """Run TaskInstance""" [53743,53765]
string: """Run TaskInstance""" [53743,53765]
===
match
---
operator: = [41404,41405]
operator: = [41404,41405]
===
match
---
name: self [42692,42696]
name: self [42692,42696]
===
match
---
atom_expr [63174,63213]
atom_expr [63308,63347]
===
match
---
trailer [56805,56820]
trailer [56939,56954]
===
match
---
name: prev_execution_date [61649,61668]
name: prev_execution_date [61783,61802]
===
match
---
param [59433,59436]
param [59567,59570]
===
match
---
dotted_name [2792,2811]
dotted_name [2792,2811]
===
match
---
tfpdef [72953,72987]
tfpdef [73087,73121]
===
match
---
funcdef [13341,13878]
funcdef [13341,13878]
===
match
---
name: dag_id [20330,20336]
name: dag_id [20330,20336]
===
match
---
name: State [39868,39873]
name: State [39868,39873]
===
match
---
name: self [25326,25330]
name: self [25326,25330]
===
match
---
name: self [21691,21695]
name: self [21691,21695]
===
match
---
parameters [35059,35090]
parameters [35059,35090]
===
match
---
operator: , [56182,56183]
operator: , [56182,56183]
===
match
---
simple_stmt [1365,1409]
simple_stmt [1365,1409]
===
match
---
trailer [46049,46059]
trailer [46049,46059]
===
match
---
atom_expr [59795,59821]
atom_expr [59929,59955]
===
match
---
name: RenderedTaskInstanceFields [66162,66188]
name: RenderedTaskInstanceFields [66296,66322]
===
match
---
name: RenderedTaskInstanceFields [48138,48164]
name: RenderedTaskInstanceFields [48138,48164]
===
match
---
name: task [52738,52742]
name: task [52738,52742]
===
match
---
trailer [23591,23601]
trailer [23591,23601]
===
match
---
operator: = [53151,53152]
operator: = [53151,53152]
===
match
---
trailer [50983,51032]
trailer [50983,51032]
===
match
---
name: self [22415,22419]
name: self [22415,22419]
===
match
---
operator: , [77209,77210]
operator: , [77343,77344]
===
match
---
trailer [35352,35360]
trailer [35352,35360]
===
match
---
decorator [12467,12482]
decorator [12467,12482]
===
match
---
comparison [26208,26258]
comparison [26208,26258]
===
match
---
name: log [41123,41126]
name: log [41123,41126]
===
match
---
operator: = [14197,14198]
operator: = [14197,14198]
===
match
---
trailer [50778,50784]
trailer [50778,50784]
===
match
---
name: super [11165,11170]
name: super [11165,11170]
===
match
---
trailer [24357,24368]
trailer [24357,24368]
===
match
---
simple_stmt [51091,51163]
simple_stmt [51091,51163]
===
match
---
decorated [55007,55968]
decorated [55007,55968]
===
match
---
name: self [58675,58679]
name: self [58809,58813]
===
match
---
name: session [45604,45611]
name: session [45604,45611]
===
match
---
strings [66603,66909]
strings [66737,67043]
===
match
---
trailer [71851,71863]
trailer [71985,71997]
===
match
---
operator: = [9620,9621]
operator: = [9620,9621]
===
match
---
argument [46208,46223]
argument [46208,46223]
===
match
---
param [77619,77624]
param [77753,77758]
===
match
---
name: Optional [29180,29188]
name: Optional [29180,29188]
===
match
---
simple_stmt [24209,24274]
simple_stmt [24209,24274]
===
match
---
operator: , [8750,8751]
operator: , [8750,8751]
===
match
---
name: default_var [64104,64115]
name: default_var [64238,64249]
===
match
---
trailer [79075,79082]
trailer [79209,79216]
===
match
---
trailer [7459,7465]
trailer [7459,7465]
===
match
---
expr_stmt [71910,71963]
expr_stmt [72044,72097]
===
match
---
simple_stmt [14891,14903]
simple_stmt [14891,14903]
===
match
---
trailer [18579,18586]
trailer [18579,18586]
===
match
---
name: context [51062,51069]
name: context [51062,51069]
===
match
---
name: dag_id [81867,81873]
name: dag_id [82001,82007]
===
match
---
trailer [22545,22550]
trailer [22545,22550]
===
match
---
name: params [62274,62280]
name: params [62408,62414]
===
match
---
trailer [22718,22727]
trailer [22718,22727]
===
match
---
name: _try_number [9796,9807]
name: _try_number [9796,9807]
===
match
---
operator: , [54200,54201]
operator: , [54200,54201]
===
match
---
name: provide_session [32216,32231]
name: provide_session [32216,32231]
===
match
---
trailer [40773,40777]
trailer [40773,40777]
===
match
---
trailer [52653,52674]
trailer [52653,52674]
===
match
---
suite [18260,18315]
suite [18260,18315]
===
match
---
operator: { [44900,44901]
operator: { [44900,44901]
===
match
---
name: execution_date [17930,17944]
name: execution_date [17930,17944]
===
match
---
funcdef [51038,51826]
funcdef [51038,51826]
===
match
---
tfpdef [15905,15929]
tfpdef [15905,15929]
===
match
---
operator: = [46215,46216]
operator: = [46215,46216]
===
match
---
name: strftime [41475,41483]
name: strftime [41475,41483]
===
match
---
trailer [34507,34555]
trailer [34507,34555]
===
match
---
name: self [11089,11093]
name: self [11089,11093]
===
match
---
name: replace [62075,62082]
name: replace [62209,62216]
===
match
---
operator: , [39558,39559]
operator: , [39558,39559]
===
match
---
name: passed [32813,32819]
name: passed [32813,32819]
===
match
---
operator: , [39721,39722]
operator: , [39721,39722]
===
match
---
name: session [26507,26514]
name: session [26507,26514]
===
match
---
name: item [62839,62843]
name: item [62973,62977]
===
match
---
operator: , [68589,68590]
operator: , [68723,68724]
===
match
---
trailer [6746,6761]
trailer [6746,6761]
===
match
---
name: or_ [6805,6808]
name: or_ [6805,6808]
===
match
---
string: "Task Duration set to %s" [72810,72835]
string: "Task Duration set to %s" [72944,72969]
===
match
---
name: filter_for_tis [77755,77769]
name: filter_for_tis [77889,77903]
===
match
---
name: and_ [78807,78811]
name: and_ [78941,78945]
===
match
---
operator: = [19518,19519]
operator: = [19518,19519]
===
match
---
parameters [59626,59646]
parameters [59760,59780]
===
match
---
atom_expr [55814,55830]
atom_expr [55814,55830]
===
match
---
argument [54185,54200]
argument [54185,54200]
===
match
---
name: task [26822,26826]
name: task [26822,26826]
===
match
---
atom_expr [29576,29626]
atom_expr [29576,29626]
===
match
---
name: KubeConfig [2976,2986]
name: KubeConfig [2976,2986]
===
match
---
funcdef [3314,3897]
funcdef [3314,3897]
===
match
---
name: Proxy [65202,65207]
name: Proxy [65336,65341]
===
match
---
import_from [35245,35285]
import_from [35245,35285]
===
match
---
name: primary [8142,8149]
name: primary [8142,8149]
===
match
---
operator: , [66388,66389]
operator: , [66522,66523]
===
match
---
string: """Sets the log context.""" [77645,77672]
string: """Sets the log context.""" [77779,77806]
===
match
---
name: airflow [2385,2392]
name: airflow [2385,2392]
===
match
---
name: debug [24121,24126]
name: debug [24121,24126]
===
match
---
expr_stmt [60517,60589]
expr_stmt [60651,60723]
===
match
---
atom_expr [60635,60647]
atom_expr [60769,60781]
===
match
---
argument [74025,74045]
argument [74159,74179]
===
match
---
simple_stmt [32841,32858]
simple_stmt [32841,32858]
===
match
---
name: airflow [45839,45846]
name: airflow [45839,45846]
===
match
---
name: ti [6037,6039]
name: ti [6037,6039]
===
match
---
name: key [71619,71622]
name: key [71753,71756]
===
match
---
operator: , [15374,15375]
operator: , [15374,15375]
===
match
---
trailer [35380,35456]
trailer [35380,35456]
===
match
---
name: query [46036,46041]
name: query [46036,46041]
===
match
---
name: session [60392,60399]
name: session [60526,60533]
===
match
---
operator: , [18014,18015]
operator: , [18014,18015]
===
match
---
funcdef [34766,35019]
funcdef [34766,35019]
===
match
---
name: self [24769,24773]
name: self [24769,24773]
===
match
---
name: task [71571,71575]
name: task [71705,71709]
===
match
---
name: api_client [2900,2910]
name: api_client [2900,2910]
===
match
---
name: xcom [77086,77090]
name: xcom [77220,77224]
===
match
---
name: bool [53502,53506]
name: bool [53502,53506]
===
match
---
name: pod [68187,68190]
name: pod [68321,68324]
===
match
---
atom_expr [78956,78976]
atom_expr [79090,79110]
===
match
---
atom_expr [51505,51524]
atom_expr [51505,51524]
===
match
---
atom_expr [28017,28029]
atom_expr [28017,28029]
===
match
---
string: "Recording the task instance as FAILED" [20861,20900]
string: "Recording the task instance as FAILED" [20861,20900]
===
match
---
simple_stmt [72594,72616]
simple_stmt [72728,72750]
===
match
---
operator: } [65833,65834]
operator: } [65967,65968]
===
match
---
trailer [23907,23913]
trailer [23907,23913]
===
match
---
operator: , [21767,21768]
operator: , [21767,21768]
===
match
---
param [51857,51862]
param [51857,51862]
===
match
---
name: error [58684,58689]
name: error [58818,58823]
===
match
---
operator: , [74349,74350]
operator: , [74483,74484]
===
match
---
atom [65726,65834]
atom [65860,65968]
===
match
---
expr_stmt [61237,61307]
expr_stmt [61371,61441]
===
match
---
atom_expr [65233,65282]
atom_expr [65367,65416]
===
match
---
name: provide_session [55974,55989]
name: provide_session [55974,55989]
===
match
---
string: "Executing %s on %s" [41244,41264]
string: "Executing %s on %s" [41244,41264]
===
match
---
name: str [8066,8069]
name: str [8066,8069]
===
match
---
operator: ** [9492,9494]
operator: ** [9492,9494]
===
match
---
name: cmd [17965,17968]
name: cmd [17965,17968]
===
match
---
name: State [44558,44563]
name: State [44558,44563]
===
match
---
name: task [42844,42848]
name: task [42844,42848]
===
match
---
if_stmt [77938,77974]
if_stmt [78072,78108]
===
match
---
argument [60214,60248]
argument [60348,60382]
===
match
---
trailer [34743,34752]
trailer [34743,34752]
===
match
---
atom_expr [32475,32523]
atom_expr [32475,32523]
===
match
---
operator: = [11204,11205]
operator: = [11204,11205]
===
match
---
name: State [30826,30831]
name: State [30826,30831]
===
match
---
funcdef [77751,79265]
funcdef [77885,79399]
===
match
---
argument [15306,15325]
argument [15306,15325]
===
match
---
name: schedulable_tis [47266,47281]
name: schedulable_tis [47266,47281]
===
match
---
atom_expr [39895,39926]
atom_expr [39895,39926]
===
match
---
name: _run_execute_callback [49518,49539]
name: _run_execute_callback [49518,49539]
===
match
---
dotted_name [2191,2205]
dotted_name [2191,2205]
===
match
---
atom_expr [13297,13313]
atom_expr [13297,13313]
===
match
---
operator: = [68164,68165]
operator: = [68298,68299]
===
match
---
trailer [49298,49300]
trailer [49298,49300]
===
match
---
arglist [41414,41424]
arglist [41414,41424]
===
match
---
trailer [56720,56722]
trailer [56854,56856]
===
match
---
name: self [24935,24939]
name: self [24935,24939]
===
match
---
atom [26295,26325]
atom [26295,26325]
===
match
---
name: self [55051,55055]
name: self [55051,55055]
===
match
---
param [29765,29793]
param [29765,29793]
===
match
---
operator: = [38510,38511]
operator: = [38510,38511]
===
match
---
trailer [63685,63689]
trailer [63819,63823]
===
match
---
atom_expr [40343,40362]
atom_expr [40343,40362]
===
match
---
simple_stmt [27868,27935]
simple_stmt [27868,27935]
===
match
---
name: dep_context [31791,31802]
name: dep_context [31791,31802]
===
match
---
atom_expr [78908,78924]
atom_expr [79042,79058]
===
match
---
expr_stmt [79608,79639]
expr_stmt [79742,79773]
===
match
---
argument [54548,54563]
argument [54548,54563]
===
match
---
name: try_number [70664,70674]
name: try_number [70798,70808]
===
match
---
atom_expr [23990,24002]
atom_expr [23990,24002]
===
match
---
trailer [17954,17956]
trailer [17954,17956]
===
match
---
fstring_expr [42843,42857]
fstring_expr [42843,42857]
===
match
---
atom_expr [18195,18232]
atom_expr [18195,18232]
===
match
---
suite [2872,3126]
suite [2872,3126]
===
match
---
param [26478,26506]
param [26478,26506]
===
match
---
name: TaskInstanceKey [81185,81200]
name: TaskInstanceKey [81319,81334]
===
match
---
parameters [72891,73034]
parameters [73025,73168]
===
match
---
trailer [47393,47398]
trailer [47393,47398]
===
match
---
suite [14878,14903]
suite [14878,14903]
===
match
---
name: is_eligible_to_retry [57643,57663]
name: is_eligible_to_retry [57777,57797]
===
match
---
operator: = [39208,39209]
operator: = [39208,39209]
===
match
---
simple_stmt [29864,30076]
simple_stmt [29864,30076]
===
match
---
name: self [21748,21752]
name: self [21748,21752]
===
match
---
arglist [8494,8569]
arglist [8494,8569]
===
match
---
simple_stmt [44354,44377]
simple_stmt [44354,44377]
===
match
---
simple_stmt [2415,2458]
simple_stmt [2415,2458]
===
match
---
name: hr_line_break [37863,37876]
name: hr_line_break [37863,37876]
===
match
---
atom_expr [24289,24369]
atom_expr [24289,24369]
===
match
---
atom_expr [67271,67297]
atom_expr [67405,67431]
===
match
---
funcdef [80930,80979]
funcdef [81064,81113]
===
match
---
atom_expr [7680,7724]
atom_expr [7680,7724]
===
match
---
name: SKIPPED [43519,43526]
name: SKIPPED [43519,43526]
===
match
---
name: self [25440,25444]
name: self [25440,25444]
===
match
---
atom_expr [45444,45465]
atom_expr [45444,45465]
===
match
---
name: jinja_env [71020,71029]
name: jinja_env [71154,71163]
===
match
---
fstring_start: f" [19751,19753]
fstring_start: f" [19751,19753]
===
match
---
expr_stmt [82486,82529]
expr_stmt [82620,82663]
===
match
---
expr_stmt [20910,20935]
expr_stmt [20910,20935]
===
match
---
funcdef [29722,30267]
funcdef [29722,30267]
===
match
---
operator: = [79827,79828]
operator: = [79961,79962]
===
match
---
suite [3580,3603]
suite [3580,3603]
===
match
---
name: format [33773,33779]
name: format [33773,33779]
===
match
---
name: session [55115,55122]
name: session [55115,55122]
===
match
---
operator: , [50686,50687]
operator: , [50686,50687]
===
match
---
name: t [78929,78930]
name: t [79063,79064]
===
match
---
parameters [21034,21077]
parameters [21034,21077]
===
match
---
name: ds [60418,60420]
name: ds [60552,60554]
===
match
---
name: UtcDateTime [10221,10232]
name: UtcDateTime [10221,10232]
===
match
---
name: log [43421,43424]
name: log [43421,43424]
===
match
---
operator: = [15370,15371]
operator: = [15370,15371]
===
match
---
atom_expr [6050,6125]
atom_expr [6050,6125]
===
match
---
operator: = [73982,73983]
operator: = [74116,74117]
===
match
---
name: refresh_from_task [11292,11309]
name: refresh_from_task [11292,11309]
===
match
---
trailer [23441,23453]
trailer [23441,23453]
===
match
---
atom_expr [48900,48972]
atom_expr [48900,48972]
===
match
---
funcdef [59240,59396]
funcdef [59374,59530]
===
match
---
operator: , [72529,72530]
operator: , [72663,72664]
===
match
---
name: test_mode [59135,59144]
name: test_mode [59269,59278]
===
match
---
simple_stmt [34928,35019]
simple_stmt [34928,35019]
===
match
---
name: self [24332,24336]
name: self [24332,24336]
===
match
---
or_test [31609,31636]
or_test [31609,31636]
===
match
---
name: exception_html [71395,71409]
name: exception_html [71529,71543]
===
match
---
atom_expr [47954,47972]
atom_expr [47954,47972]
===
match
---
name: Float [1306,1311]
name: Float [1306,1311]
===
match
---
atom_expr [11703,11722]
atom_expr [11703,11722]
===
match
---
expr_stmt [78082,78102]
expr_stmt [78216,78236]
===
match
---
name: expunge_all [60366,60377]
name: expunge_all [60500,60511]
===
match
---
return_stmt [78505,78707]
return_stmt [78639,78841]
===
match
---
trailer [22790,22794]
trailer [22790,22794]
===
match
---
atom_expr [32661,32680]
atom_expr [32661,32680]
===
match
---
operator: == [6857,6859]
operator: == [6857,6859]
===
match
---
expr_stmt [61975,62031]
expr_stmt [62109,62165]
===
match
---
name: ti [5938,5940]
name: ti [5938,5940]
===
match
---
expr_stmt [68187,68796]
expr_stmt [68321,68930]
===
match
---
trailer [63951,63961]
trailer [64085,64095]
===
match
---
atom_expr [31721,31735]
atom_expr [31721,31735]
===
match
---
simple_stmt [79608,79640]
simple_stmt [79742,79774]
===
match
---
operator: , [47918,47919]
operator: , [47918,47919]
===
match
---
simple_stmt [19477,19506]
simple_stmt [19477,19506]
===
match
---
operator: = [52309,52310]
operator: = [52309,52310]
===
match
---
atom_expr [18058,18088]
atom_expr [18058,18088]
===
match
---
trailer [12591,12601]
trailer [12591,12601]
===
match
---
name: self [22786,22790]
name: self [22786,22790]
===
match
---
simple_stmt [77318,77593]
simple_stmt [77452,77727]
===
match
---
name: force_fail [44246,44256]
name: force_fail [44246,44256]
===
match
---
operator: == [6762,6764]
operator: == [6762,6764]
===
match
---
param [74283,74288]
param [74417,74422]
===
match
---
name: dep_context [32270,32281]
name: dep_context [32270,32281]
===
match
---
arglist [54368,54564]
arglist [54368,54564]
===
match
---
atom_expr [33759,33914]
atom_expr [33759,33914]
===
match
---
argument [46651,46675]
argument [46651,46675]
===
match
---
suite [18509,18546]
suite [18509,18546]
===
match
---
trailer [51349,51367]
trailer [51349,51367]
===
match
---
trailer [7176,7178]
trailer [7176,7178]
===
match
---
atom_expr [79024,79264]
atom_expr [79158,79398]
===
match
---
name: ti [22075,22077]
name: ti [22075,22077]
===
match
---
name: self [24857,24861]
name: self [24857,24861]
===
match
---
name: Optional [16017,16025]
name: Optional [16017,16025]
===
match
---
expr_stmt [40734,40760]
expr_stmt [40734,40760]
===
match
---
expr_stmt [14734,14770]
expr_stmt [14734,14770]
===
match
---
arglist [56875,56893]
arglist [57009,57027]
===
match
---
name: query [77347,77352]
name: query [77481,77486]
===
match
---
expr_stmt [5240,5265]
expr_stmt [5240,5265]
===
match
---
param [64104,64163]
param [64238,64297]
===
match
---
name: operator [10164,10172]
name: operator [10164,10172]
===
match
---
operator: , [11125,11126]
operator: , [11125,11126]
===
match
---
name: replace [62133,62140]
name: replace [62267,62274]
===
match
---
name: include_downstream [46651,46669]
name: include_downstream [46651,46669]
===
match
---
number: 1 [50585,50586]
number: 1 [50585,50586]
===
match
---
atom_expr [23355,23370]
atom_expr [23355,23370]
===
match
---
atom_expr [47412,47434]
atom_expr [47412,47434]
===
match
---
simple_stmt [23481,23511]
simple_stmt [23481,23511]
===
match
---
name: self [24410,24414]
name: self [24410,24414]
===
match
---
comp_if [47051,47098]
comp_if [47051,47098]
===
match
---
trailer [49775,49802]
trailer [49775,49802]
===
match
---
name: info [41127,41131]
name: info [41127,41131]
===
match
---
name: self [22700,22704]
name: self [22700,22704]
===
match
---
name: pickle_id [15864,15873]
name: pickle_id [15864,15873]
===
match
---
atom_expr [58990,59004]
atom_expr [59124,59138]
===
match
---
name: Optional [52277,52285]
name: Optional [52277,52285]
===
match
---
arglist [9477,9527]
arglist [9477,9527]
===
match
---
trailer [40594,40598]
trailer [40594,40598]
===
match
---
name: self [12681,12685]
name: self [12681,12685]
===
match
---
operator: , [19051,19052]
operator: , [19051,19052]
===
match
---
decorated [80433,80502]
decorated [80567,80636]
===
match
---
string: '%Y%m%dT%H%M%S' [41484,41499]
string: '%Y%m%dT%H%M%S' [41484,41499]
===
match
---
trailer [43424,43429]
trailer [43424,43429]
===
match
---
string: 'next_ds' [64661,64670]
string: 'next_ds' [64795,64804]
===
match
---
trailer [8268,8275]
trailer [8268,8275]
===
match
---
param [65982,65986]
param [66116,66120]
===
match
---
operator: = [39542,39543]
operator: = [39542,39543]
===
match
---
trailer [55464,55476]
trailer [55464,55476]
===
match
---
name: dag [47399,47402]
name: dag [47399,47402]
===
match
---
simple_stmt [11917,11974]
simple_stmt [11917,11974]
===
match
---
simple_stmt [37421,37470]
simple_stmt [37421,37470]
===
match
---
name: expanduser [19022,19032]
name: expanduser [19022,19032]
===
match
---
name: Context [59650,59657]
name: Context [59784,59791]
===
match
---
name: TR [6744,6746]
name: TR [6744,6746]
===
match
---
name: next_execution_date [61087,61106]
name: next_execution_date [61221,61240]
===
match
---
param [80386,80390]
param [80520,80524]
===
match
---
name: self [42554,42558]
name: self [42554,42558]
===
match
---
with_item [4380,4408]
with_item [4380,4408]
===
match
---
trailer [37533,37572]
trailer [37533,37572]
===
match
---
name: dill [1157,1161]
name: dill [1157,1161]
===
match
---
funcdef [65949,66935]
funcdef [66083,67069]
===
match
---
name: self [80488,80492]
name: self [80622,80626]
===
match
---
except_clause [47641,47669]
except_clause [47641,47669]
===
match
---
trailer [43465,43487]
trailer [43465,43487]
===
match
---
decorator [63026,63040]
decorator [63160,63174]
===
match
---
atom_expr [76849,76859]
atom_expr [76983,76993]
===
match
---
trailer [71446,71457]
trailer [71580,71591]
===
match
---
and_test [78723,78772]
and_test [78857,78906]
===
match
---
name: __table_args__ [10554,10568]
name: __table_args__ [10554,10568]
===
match
---
name: current_state [19878,19891]
name: current_state [19878,19891]
===
match
---
name: task [66372,66376]
name: task [66506,66510]
===
match
---
simple_stmt [52334,52502]
simple_stmt [52334,52502]
===
match
---
simple_stmt [5334,5355]
simple_stmt [5334,5355]
===
match
---
expr_stmt [5505,5532]
expr_stmt [5505,5532]
===
match
---
trailer [48419,48427]
trailer [48419,48427]
===
match
---
trailer [56093,56099]
trailer [56093,56099]
===
match
---
trailer [71668,71682]
trailer [71802,71816]
===
match
---
name: items [7082,7087]
name: items [7082,7087]
===
match
---
name: State [65268,65273]
name: State [65402,65407]
===
match
---
string: '-' [61892,61895]
string: '-' [62026,62029]
===
match
---
trailer [62900,62904]
trailer [63034,63038]
===
match
---
name: self [72416,72420]
name: self [72550,72554]
===
match
---
tfpdef [53484,53506]
tfpdef [53484,53506]
===
match
---
trailer [50601,50606]
trailer [50601,50606]
===
match
---
operator: = [42735,42736]
operator: = [42735,42736]
===
match
---
operator: , [15401,15402]
operator: , [15401,15402]
===
match
---
name: dag_id [8499,8505]
name: dag_id [8499,8505]
===
match
---
trailer [19582,19586]
trailer [19582,19586]
===
match
---
if_stmt [18402,18482]
if_stmt [18402,18482]
===
match
---
string: """         Returns a command that can be executed anywhere where airflow is         installed. This command is part of the message sent to executors by         the orchestrator.         """ [14378,14568]
string: """         Returns a command that can be executed anywhere where airflow is         installed. This command is part of the message sent to executors by         the orchestrator.         """ [14378,14568]
===
match
---
suite [51970,52062]
suite [51970,52062]
===
match
---
expr_stmt [79648,79698]
expr_stmt [79782,79832]
===
match
---
trailer [33732,33737]
trailer [33732,33737]
===
match
---
atom_expr [5082,5140]
atom_expr [5082,5140]
===
match
---
name: self [72338,72342]
name: self [72472,72476]
===
match
---
name: tomorrow_ds_nodash [62100,62118]
name: tomorrow_ds_nodash [62234,62252]
===
match
---
suite [47342,47436]
suite [47342,47436]
===
match
---
name: ready_for_retry [34770,34785]
name: ready_for_retry [34770,34785]
===
match
---
name: rendered_k8s_spec [67114,67131]
name: rendered_k8s_spec [67248,67265]
===
match
---
suite [18343,18394]
suite [18343,18394]
===
match
---
operator: = [54033,54034]
operator: = [54033,54034]
===
match
---
trailer [11957,11973]
trailer [11957,11973]
===
match
---
name: items [6965,6970]
name: items [6965,6970]
===
match
---
trailer [10008,10012]
trailer [10008,10012]
===
match
---
name: context [3338,3345]
name: context [3338,3345]
===
match
---
string: 'kcah_acitats' [82186,82200]
string: 'kcah_acitats' [82320,82334]
===
match
---
param [67552,67559]
param [67686,67693]
===
match
---
name: task [57921,57925]
name: task [58055,58059]
===
match
---
name: self [22901,22905]
name: self [22901,22905]
===
match
---
string: "TaskInstance.dag_id == DagModel.dag_id" [10947,10987]
string: "TaskInstance.dag_id == DagModel.dag_id" [10947,10987]
===
match
---
atom_expr [77510,77528]
atom_expr [77644,77662]
===
match
---
operator: = [26026,26027]
operator: = [26026,26027]
===
match
---
trailer [65261,65282]
trailer [65395,65416]
===
match
---
simple_stmt [79887,79935]
simple_stmt [80021,80069]
===
match
---
simple_stmt [24087,24104]
simple_stmt [24087,24104]
===
match
---
atom_expr [24935,24948]
atom_expr [24935,24948]
===
match
---
string: "Current context is not equal to the state at context stack. Expected=%s, got=%s" [3743,3824]
string: "Current context is not equal to the state at context stack. Expected=%s, got=%s" [3743,3824]
===
match
---
trailer [61263,61267]
trailer [61397,61401]
===
match
---
decorated [63975,64351]
decorated [64109,64485]
===
match
---
argument [50485,50500]
argument [50485,50500]
===
match
---
name: self [77480,77484]
name: self [77614,77618]
===
match
---
operator: , [26505,26506]
operator: , [26505,26506]
===
match
---
trailer [55427,55442]
trailer [55427,55442]
===
match
---
arglist [63323,63352]
arglist [63457,63486]
===
match
---
atom_expr [35436,35455]
atom_expr [35436,35455]
===
match
---
expr_stmt [23379,23428]
expr_stmt [23379,23428]
===
match
---
atom [20223,20502]
atom [20223,20502]
===
match
---
name: self [27137,27141]
name: self [27137,27141]
===
match
---
name: session [74165,74172]
name: session [74299,74306]
===
match
---
and_test [73684,73739]
and_test [73818,73873]
===
match
---
name: self [30318,30322]
name: self [30318,30322]
===
match
---
name: execution_date [78445,78459]
name: execution_date [78579,78593]
===
match
---
trailer [40703,40724]
trailer [40703,40724]
===
match
---
atom_expr [50526,50587]
atom_expr [50526,50587]
===
match
---
simple_stmt [19620,19848]
simple_stmt [19620,19848]
===
match
---
fstring_expr [19114,19128]
fstring_expr [19114,19128]
===
match
---
trailer [63322,63353]
trailer [63456,63487]
===
match
---
operator: -> [35995,35997]
operator: -> [35995,35997]
===
match
---
trailer [79855,79862]
trailer [79989,79996]
===
match
---
expr_stmt [54919,54940]
expr_stmt [54919,54940]
===
match
---
atom_expr [66367,66376]
atom_expr [66501,66510]
===
match
---
name: refresh_from_db [42651,42666]
name: refresh_from_db [42651,42666]
===
match
---
trailer [47521,47526]
trailer [47521,47526]
===
match
---
name: self [20378,20382]
name: self [20378,20382]
===
match
---
parameters [15510,16084]
parameters [15510,16084]
===
match
---
number: 0 [4030,4031]
number: 0 [4030,4031]
===
match
---
operator: @ [30272,30273]
operator: @ [30272,30273]
===
match
---
dotted_name [48099,48130]
dotted_name [48099,48130]
===
match
---
arglist [14962,15456]
arglist [14962,15456]
===
match
---
atom_expr [26239,26258]
atom_expr [26239,26258]
===
match
---
name: session [55845,55852]
name: session [55845,55852]
===
match
---
operator: == [78554,78556]
operator: == [78688,78690]
===
match
---
operator: = [68545,68546]
operator: = [68679,68680]
===
match
---
decorator [80766,80776]
decorator [80900,80910]
===
match
---
simple_stmt [22455,22483]
simple_stmt [22455,22483]
===
match
---
name: int [8115,8118]
name: int [8115,8118]
===
match
---
atom_expr [50827,50844]
atom_expr [50827,50844]
===
match
---
suite [51082,51826]
suite [51082,51826]
===
match
---
argument [29610,29625]
argument [29610,29625]
===
match
---
atom_expr [56661,56674]
atom_expr [56795,56808]
===
match
---
expr_stmt [34051,34100]
expr_stmt [34051,34100]
===
match
---
name: params [59967,59973]
name: params [60101,60107]
===
match
---
comparison [54624,54651]
comparison [54624,54651]
===
match
---
name: dag_id [33810,33816]
name: dag_id [33810,33816]
===
match
---
operator: == [25337,25339]
operator: == [25337,25339]
===
match
---
arglist [70556,70725]
arglist [70690,70859]
===
match
---
atom_expr [25938,25947]
atom_expr [25938,25947]
===
match
---
param [4713,4717]
param [4713,4717]
===
match
---
trailer [58126,58131]
trailer [58260,58265]
===
match
---
trailer [40324,40326]
trailer [40324,40326]
===
match
---
name: datetime [79725,79733]
name: datetime [79859,79867]
===
match
---
name: self [56325,56329]
name: self [56325,56329]
===
match
---
name: job_ids [7295,7302]
name: job_ids [7295,7302]
===
match
---
operator: = [34574,34575]
operator: = [34574,34575]
===
match
---
trailer [30795,30819]
trailer [30795,30819]
===
match
---
operator: @ [20994,20995]
operator: @ [20994,20995]
===
match
---
name: state [9765,9770]
name: state [9765,9770]
===
match
---
name: airflow [2792,2799]
name: airflow [2792,2799]
===
match
---
simple_stmt [45564,45613]
simple_stmt [45564,45613]
===
match
---
atom_expr [40545,40560]
atom_expr [40545,40560]
===
match
---
tfpdef [41648,41663]
tfpdef [41648,41663]
===
match
---
arglist [10396,10420]
arglist [10396,10420]
===
match
---
name: jinja_context [71073,71086]
name: jinja_context [71207,71220]
===
match
---
name: cmd [18742,18745]
name: cmd [18742,18745]
===
match
---
dotted_name [2567,2584]
dotted_name [2567,2584]
===
match
---
atom_expr [5549,5561]
atom_expr [5549,5561]
===
match
---
operator: = [26499,26500]
operator: = [26499,26500]
===
match
---
name: iso [17924,17927]
name: iso [17924,17927]
===
match
---
argument [54063,54088]
argument [54063,54088]
===
match
---
string: "Exporting the following env vars:\n%s" [49181,49220]
string: "Exporting the following env vars:\n%s" [49181,49220]
===
match
---
suite [5197,5308]
suite [5197,5308]
===
match
---
atom_expr [27987,28047]
atom_expr [27987,28047]
===
match
---
simple_stmt [54695,54712]
simple_stmt [54695,54712]
===
match
---
name: self [8507,8511]
name: self [8507,8511]
===
match
---
string: "--cfg-path" [18823,18835]
string: "--cfg-path" [18823,18835]
===
match
---
atom_expr [80166,80196]
atom_expr [80300,80330]
===
match
---
atom_expr [68755,68784]
atom_expr [68889,68918]
===
match
---
name: include_prior_dates [76382,76401]
name: include_prior_dates [76516,76535]
===
match
---
if_stmt [54220,54251]
if_stmt [54220,54251]
===
match
---
if_stmt [4071,4104]
if_stmt [4071,4104]
===
match
---
and_test [25326,25389]
and_test [25326,25389]
===
match
---
operator: , [72021,72022]
operator: , [72155,72156]
===
match
---
trailer [71128,71140]
trailer [71262,71274]
===
match
---
atom_expr [24889,24899]
atom_expr [24889,24899]
===
match
---
operator: } [44927,44928]
operator: } [44927,44928]
===
match
---
trailer [27998,28016]
trailer [27998,28016]
===
match
---
name: task_id [81916,81923]
name: task_id [82050,82057]
===
match
---
parameters [63917,63923]
parameters [64051,64057]
===
match
---
operator: = [15146,15147]
operator: = [15146,15147]
===
match
---
trailer [81866,81873]
trailer [82000,82007]
===
match
---
trailer [21995,22006]
trailer [21995,22006]
===
match
---
operator: = [10891,10892]
operator: = [10891,10892]
===
match
---
name: overwrite_params_with_dag_run_conf [67511,67545]
name: overwrite_params_with_dag_run_conf [67645,67679]
===
match
---
operator: { [32944,32945]
operator: { [32944,32945]
===
match
---
operator: - [34551,34552]
operator: - [34551,34552]
===
match
---
name: self [81057,81061]
name: self [81191,81195]
===
match
---
return_stmt [13172,13195]
return_stmt [13172,13195]
===
match
---
name: Integer [10054,10061]
name: Integer [10054,10061]
===
match
---
name: check_and_change_state_before_execution [53785,53824]
name: check_and_change_state_before_execution [53785,53824]
===
match
---
arglist [11777,11815]
arglist [11777,11815]
===
match
---
simple_stmt [77645,77673]
simple_stmt [77779,77807]
===
match
---
atom_expr [79851,79862]
atom_expr [79985,79996]
===
match
---
name: render [72076,72082]
name: render [72210,72216]
===
match
---
name: job_id [18175,18181]
name: job_id [18175,18181]
===
match
---
operator: , [66284,66285]
operator: , [66418,66419]
===
match
---
name: try_number [8554,8564]
name: try_number [8554,8564]
===
match
---
trailer [81141,81148]
trailer [81275,81282]
===
match
---
name: query [20245,20250]
name: query [20245,20250]
===
match
---
trailer [20986,20988]
trailer [20986,20988]
===
match
---
trailer [58376,58387]
trailer [58510,58521]
===
match
---
operator: = [50825,50826]
operator: = [50825,50826]
===
match
---
name: self [51857,51861]
name: self [51857,51861]
===
match
---
trailer [23275,23281]
trailer [23275,23281]
===
match
---
trailer [54703,54709]
trailer [54703,54709]
===
match
---
name: self [80540,80544]
name: self [80674,80678]
===
match
---
atom_expr [55664,55687]
atom_expr [55664,55687]
===
match
---
import_name [1150,1161]
import_name [1150,1161]
===
match
---
param [80629,80633]
param [80763,80767]
===
match
---
name: task [23355,23359]
name: task [23355,23359]
===
match
---
simple_stmt [76219,76462]
simple_stmt [76353,76596]
===
match
---
testlist_comp [44725,44753]
testlist_comp [44725,44753]
===
match
---
param [72901,72906]
param [73035,73040]
===
match
---
trailer [45203,45211]
trailer [45203,45211]
===
match
---
trailer [44634,44649]
trailer [44634,44649]
===
match
---
name: local [18557,18562]
name: local [18557,18562]
===
match
---
name: SENSING [50793,50800]
name: SENSING [50793,50800]
===
match
---
name: dep_status [32847,32857]
name: dep_status [32847,32857]
===
match
---
param [15835,15855]
param [15835,15855]
===
match
---
trailer [11181,11183]
trailer [11181,11183]
===
match
---
trailer [23359,23370]
trailer [23359,23370]
===
match
---
name: sqlalchemy [1512,1522]
name: sqlalchemy [1512,1522]
===
match
---
trailer [55906,55911]
trailer [55906,55911]
===
match
---
comparison [20302,20336]
comparison [20302,20336]
===
match
---
expr_stmt [48223,48244]
expr_stmt [48223,48244]
===
match
---
atom_expr [47389,47435]
atom_expr [47389,47435]
===
match
---
if_stmt [56562,56627]
if_stmt [56696,56761]
===
match
---
simple_stmt [11262,11279]
simple_stmt [11262,11279]
===
match
---
decorated [30846,32210]
decorated [30846,32210]
===
match
---
operator: = [29811,29812]
operator: = [29811,29812]
===
match
---
trailer [9548,9600]
trailer [9548,9600]
===
match
---
trailer [60399,60406]
trailer [60533,60540]
===
match
---
atom_expr [23258,23268]
atom_expr [23258,23268]
===
match
---
suite [4083,4104]
suite [4083,4104]
===
match
---
operator: = [11272,11273]
operator: = [11272,11273]
===
match
---
name: self [12175,12179]
name: self [12175,12179]
===
match
---
simple_stmt [51573,51617]
simple_stmt [51573,51617]
===
match
---
simple_stmt [29635,29696]
simple_stmt [29635,29696]
===
match
---
simple_stmt [80034,80069]
simple_stmt [80168,80203]
===
match
---
name: self [59265,59269]
name: self [59399,59403]
===
match
---
operator: , [65541,65542]
operator: , [65675,65676]
===
match
---
atom_expr [79570,79582]
atom_expr [79704,79716]
===
match
---
name: Stats [42807,42812]
name: Stats [42807,42812]
===
match
---
expr_stmt [52639,52676]
expr_stmt [52639,52676]
===
match
---
name: session [73004,73011]
name: session [73138,73145]
===
match
---
suite [32882,32983]
suite [32882,32983]
===
match
---
trailer [68277,68285]
trailer [68411,68419]
===
match
---
trailer [24116,24120]
trailer [24116,24120]
===
match
---
name: lock_for_update [82029,82044]
name: lock_for_update [82163,82178]
===
match
---
atom_expr [10214,10233]
atom_expr [10214,10233]
===
match
---
trailer [41474,41483]
trailer [41474,41483]
===
match
---
name: property [80434,80442]
name: property [80568,80576]
===
match
---
name: session [46216,46223]
name: session [46216,46223]
===
match
---
name: getattr [41406,41413]
name: getattr [41406,41413]
===
match
---
parameters [80711,80717]
parameters [80845,80851]
===
match
---
atom_expr [32429,32443]
atom_expr [32429,32443]
===
match
---
parameters [74223,74506]
parameters [74357,74640]
===
match
---
name: os [19014,19016]
name: os [19014,19016]
===
match
---
trailer [6094,6109]
trailer [6094,6109]
===
match
---
name: Exception [52077,52086]
name: Exception [52077,52086]
===
match
---
name: update [70506,70512]
name: update [70640,70646]
===
match
---
trailer [40709,40717]
trailer [40709,40717]
===
match
---
atom_expr [13179,13195]
atom_expr [13179,13195]
===
match
---
name: task [52585,52589]
name: task [52585,52589]
===
match
---
trailer [30098,30132]
trailer [30098,30132]
===
match
---
name: lock_for_update [43466,43481]
name: lock_for_update [43466,43481]
===
match
---
name: item [64026,64030]
name: item [64160,64164]
===
match
---
if_stmt [44525,44709]
if_stmt [44525,44709]
===
match
---
simple_stmt [39056,39136]
simple_stmt [39056,39136]
===
match
---
atom_expr [65268,65281]
atom_expr [65402,65415]
===
match
---
suite [51310,51450]
suite [51310,51450]
===
match
---
dictorsetmaker [65744,65820]
dictorsetmaker [65878,65954]
===
match
---
operator: , [25444,25445]
operator: , [25444,25445]
===
match
---
operator: , [82005,82006]
operator: , [82139,82140]
===
match
---
name: stacklevel [28491,28501]
name: stacklevel [28491,28501]
===
match
---
trailer [20957,20963]
trailer [20957,20963]
===
match
---
expr_stmt [12121,12139]
expr_stmt [12121,12139]
===
match
---
string: 'tomorrow_ds' [65515,65528]
string: 'tomorrow_ds' [65649,65662]
===
match
---
tfpdef [53524,53545]
tfpdef [53524,53545]
===
match
---
trailer [31699,31704]
trailer [31699,31704]
===
match
---
dictorsetmaker [70328,70338]
dictorsetmaker [70462,70472]
===
match
---
name: session [59055,59062]
name: session [59189,59196]
===
match
---
atom_expr [45374,45393]
atom_expr [45374,45393]
===
match
---
expr_stmt [80210,80252]
expr_stmt [80344,80386]
===
match
---
trailer [24094,24101]
trailer [24094,24101]
===
match
---
name: prev_ds_nodash [61616,61630]
name: prev_ds_nodash [61750,61764]
===
match
---
name: in_ [7694,7697]
name: in_ [7694,7697]
===
match
---
simple_stmt [45479,45499]
simple_stmt [45479,45499]
===
match
---
argument [76323,76337]
argument [76457,76471]
===
match
---
arglist [58324,58357]
arglist [58458,58491]
===
match
---
decorator [63975,63989]
decorator [64109,64123]
===
match
---
operator: , [10671,10672]
operator: , [10671,10672]
===
match
---
atom_expr [56703,56722]
atom_expr [56837,56856]
===
match
---
simple_stmt [77229,77276]
simple_stmt [77363,77410]
===
match
---
operator: @ [80361,80362]
operator: @ [80495,80496]
===
match
---
trailer [46148,46163]
trailer [46148,46163]
===
match
---
name: task_copy [54982,54991]
name: task_copy [54982,54991]
===
match
---
decorator [41545,41567]
decorator [41545,41567]
===
match
---
name: str [63948,63951]
name: str [64082,64085]
===
match
---
trailer [26316,26324]
trailer [26316,26324]
===
match
---
atom_expr [5919,5931]
atom_expr [5919,5931]
===
match
---
string: 'ti' [65491,65495]
string: 'ti' [65625,65629]
===
match
---
name: self [72645,72649]
name: self [72779,72783]
===
match
---
name: State [57982,57987]
name: State [58116,58121]
===
match
---
atom_expr [58282,58294]
atom_expr [58416,58428]
===
match
---
trailer [7950,7952]
trailer [7950,7952]
===
match
---
operator: = [43511,43512]
operator: = [43511,43512]
===
match
---
name: State [26296,26301]
name: State [26296,26301]
===
match
---
name: self [23481,23485]
name: self [23481,23485]
===
match
---
name: ti [21881,21883]
name: ti [21881,21883]
===
match
---
decorator [80846,80856]
decorator [80980,80990]
===
match
---
name: info [55907,55911]
name: info [55907,55911]
===
match
---
suite [30945,32210]
suite [30945,32210]
===
match
---
trailer [41281,41296]
trailer [41281,41296]
===
match
---
atom_expr [24951,24964]
atom_expr [24951,24964]
===
match
---
operator: = [14274,14275]
operator: = [14274,14275]
===
match
---
operator: @ [13237,13238]
operator: @ [13237,13238]
===
match
---
trailer [27346,27350]
trailer [27346,27350]
===
match
---
name: dag_id [6068,6074]
name: dag_id [6068,6074]
===
match
---
or_test [24951,24980]
or_test [24951,24980]
===
match
---
name: job_id [15395,15401]
name: job_id [15395,15401]
===
match
---
arglist [40704,40723]
arglist [40704,40723]
===
match
---
atom_expr [22075,22086]
atom_expr [22075,22086]
===
match
---
name: self [57001,57005]
name: self [57135,57139]
===
match
---
operator: = [9437,9438]
operator: = [9437,9438]
===
match
---
simple_stmt [32891,32983]
simple_stmt [32891,32983]
===
match
---
argument [63329,63352]
argument [63463,63486]
===
match
---
name: task [34695,34699]
name: task [34695,34699]
===
match
---
tfpdef [15710,15738]
tfpdef [15710,15738]
===
match
---
parameters [81017,81023]
parameters [81151,81157]
===
match
---
simple_stmt [68118,68144]
simple_stmt [68252,68278]
===
match
---
name: str [69255,69258]
name: str [69389,69392]
===
match
---
name: DagRun [35411,35417]
name: DagRun [35411,35417]
===
match
---
simple_stmt [9796,9851]
simple_stmt [9796,9851]
===
match
---
name: dag [26827,26830]
name: dag [26827,26830]
===
match
---
operator: , [72440,72441]
operator: , [72574,72575]
===
match
---
name: _set_context [77709,77721]
name: _set_context [77843,77855]
===
match
---
name: self [42646,42650]
name: self [42646,42650]
===
match
---
name: and_ [6630,6634]
name: and_ [6630,6634]
===
match
---
operator: , [56782,56783]
operator: , [56916,56917]
===
match
---
name: self [54919,54923]
name: self [54919,54923]
===
match
---
argument [47905,47918]
argument [47905,47918]
===
match
---
name: task_copy [48699,48708]
name: task_copy [48699,48708]
===
match
---
suite [52325,53274]
suite [52325,53274]
===
match
---
decorated [59581,65944]
decorated [59715,66078]
===
match
---
trailer [78209,78217]
trailer [78343,78351]
===
match
---
name: self [11262,11266]
name: self [11262,11266]
===
match
---
name: get [63056,63059]
name: get [63190,63193]
===
match
---
name: getLogger [11344,11353]
name: getLogger [11344,11353]
===
match
---
comp_op [53114,53120]
comp_op [53114,53120]
===
match
---
name: task_id [76745,76752]
name: task_id [76879,76886]
===
match
---
name: self [19687,19691]
name: self [19687,19691]
===
match
---
trailer [58323,58358]
trailer [58457,58492]
===
match
---
name: self [77722,77726]
name: self [77856,77860]
===
match
---
operator: == [5180,5182]
operator: == [5180,5182]
===
match
---
trailer [9974,9983]
trailer [9974,9983]
===
match
---
name: self [45276,45280]
name: self [45276,45280]
===
match
---
string: 'Host: {{ti.hostname}}<br>' [69715,69742]
string: 'Host: {{ti.hostname}}<br>' [69849,69876]
===
match
---
trailer [34639,34644]
trailer [34639,34644]
===
match
---
atom_expr [58564,58587]
atom_expr [58698,58721]
===
match
---
simple_stmt [79340,79392]
simple_stmt [79474,79526]
===
match
---
name: state [77523,77528]
name: state [77657,77662]
===
match
---
trailer [11245,11253]
trailer [11245,11253]
===
match
---
atom_expr [50853,50872]
atom_expr [50853,50872]
===
match
---
operator: , [76421,76422]
operator: , [76555,76556]
===
match
---
name: exception_html [70597,70611]
name: exception_html [70731,70745]
===
match
---
operator: , [55442,55443]
operator: , [55442,55443]
===
match
---
operator: = [82216,82217]
operator: = [82350,82351]
===
match
---
name: _safe_date [58437,58447]
name: _safe_date [58571,58581]
===
match
---
atom_expr [61109,61128]
atom_expr [61243,61262]
===
match
---
name: self [44528,44532]
name: self [44528,44532]
===
match
---
param [16011,16038]
param [16011,16038]
===
match
---
name: path [15349,15353]
name: path [15349,15353]
===
match
---
name: dag_id [44906,44912]
name: dag_id [44906,44912]
===
match
---
operator: , [53622,53623]
operator: , [53622,53623]
===
match
---
name: set_error_file [4254,4268]
name: set_error_file [4254,4268]
===
match
---
trailer [5524,5532]
trailer [5524,5532]
===
match
---
name: render [71064,71070]
name: render [71198,71204]
===
match
---
operator: = [57863,57864]
operator: = [57997,57998]
===
match
---
operator: , [18764,18765]
operator: , [18764,18765]
===
match
---
suite [72481,72549]
suite [72615,72683]
===
match
---
simple_stmt [1562,1591]
simple_stmt [1562,1591]
===
match
---
operator: , [74325,74326]
operator: , [74459,74460]
===
match
---
return_stmt [27980,28047]
return_stmt [27980,28047]
===
match
---
atom_expr [79113,79133]
atom_expr [79247,79267]
===
match
---
name: get_previous_dagrun [27885,27904]
name: get_previous_dagrun [27885,27904]
===
match
---
funcdef [59401,59576]
funcdef [59535,59710]
===
match
---
simple_stmt [46536,46789]
simple_stmt [46536,46789]
===
match
---
simple_stmt [54724,54765]
simple_stmt [54724,54765]
===
match
---
operator: , [80004,80005]
operator: , [80138,80139]
===
match
---
simple_stmt [45982,46249]
simple_stmt [45982,46249]
===
match
---
trailer [40603,40618]
trailer [40603,40618]
===
match
---
operator: = [26887,26888]
operator: = [26887,26888]
===
match
---
name: session [19898,19905]
name: session [19898,19905]
===
match
---
name: SUCCESS [65121,65128]
name: SUCCESS [65255,65262]
===
match
---
atom_expr [8277,8289]
atom_expr [8277,8289]
===
match
---
name: ignore_all_deps [18244,18259]
name: ignore_all_deps [18244,18259]
===
match
---
atom_expr [24318,24330]
atom_expr [24318,24330]
===
match
---
atom_expr [30520,30775]
atom_expr [30520,30775]
===
match
---
operator: = [5998,5999]
operator: = [5998,5999]
===
match
---
name: airflow [66055,66062]
name: airflow [66189,66196]
===
match
---
if_stmt [26839,28048]
if_stmt [26839,28048]
===
match
---
operator: , [4395,4396]
operator: , [4395,4396]
===
match
---
name: warnings [28267,28275]
name: warnings [28267,28275]
===
match
---
import_from [2303,2379]
import_from [2303,2379]
===
match
---
string: "{}#{}#{}#{}" [33759,33772]
string: "{}#{}#{}#{}" [33759,33772]
===
match
---
trailer [62082,62091]
trailer [62216,62225]
===
match
---
name: str [63771,63774]
name: str [63905,63908]
===
match
---
trailer [18745,18752]
trailer [18745,18752]
===
match
---
fstring_string: operator_failures_ [56744,56762]
fstring_string: operator_failures_ [56878,56896]
===
match
---
trailer [41413,41425]
trailer [41413,41425]
===
match
---
strings [39981,40129]
strings [39981,40129]
===
match
---
trailer [19266,19268]
trailer [19266,19268]
===
match
---
name: next_execution_date [61373,61392]
name: next_execution_date [61507,61526]
===
match
---
expr_stmt [61869,61900]
expr_stmt [62003,62034]
===
match
---
name: session [26880,26887]
name: session [26880,26887]
===
match
---
name: self [81877,81881]
name: self [82011,82015]
===
match
---
dotted_name [3288,3313]
dotted_name [3288,3313]
===
match
---
operator: = [35776,35777]
operator: = [35776,35777]
===
match
---
atom_expr [77480,77492]
atom_expr [77614,77626]
===
match
---
simple_stmt [80210,80253]
simple_stmt [80344,80387]
===
match
---
trailer [39005,39011]
trailer [39005,39011]
===
match
---
name: execution_date [41180,41194]
name: execution_date [41180,41194]
===
match
---
argument [30820,30839]
argument [30820,30839]
===
match
---
name: airflow [2567,2574]
name: airflow [2567,2574]
===
match
---
simple_stmt [58564,58588]
simple_stmt [58698,58722]
===
match
---
argument [79041,79254]
argument [79175,79388]
===
match
---
name: self [22495,22499]
name: self [22495,22499]
===
match
---
trailer [8295,8310]
trailer [8295,8310]
===
match
---
expr_stmt [11851,11903]
expr_stmt [11851,11903]
===
match
---
operator: = [22714,22715]
operator: = [22714,22715]
===
match
---
name: self [72691,72695]
name: self [72825,72829]
===
match
---
name: start_date [25031,25041]
name: start_date [25031,25041]
===
match
---
suite [51293,51547]
suite [51293,51547]
===
match
---
string: 'execution_date' [45245,45261]
string: 'execution_date' [45245,45261]
===
match
---
name: prev_ds_nodash [61745,61759]
name: prev_ds_nodash [61879,61893]
===
match
---
trailer [68731,68754]
trailer [68865,68888]
===
match
---
trailer [80578,80594]
trailer [80712,80728]
===
match
---
atom_expr [61821,61859]
atom_expr [61955,61993]
===
match
---
dotted_name [1596,1617]
dotted_name [1596,1617]
===
match
---
trailer [50813,50824]
trailer [50813,50824]
===
match
---
operator: = [76909,76910]
operator: = [77043,77044]
===
match
---
simple_stmt [74523,76150]
simple_stmt [74657,76284]
===
match
---
trailer [21844,21846]
trailer [21844,21846]
===
match
---
name: state [22104,22109]
name: state [22104,22109]
===
match
---
name: Proxy [65045,65050]
name: Proxy [65179,65184]
===
match
---
name: self [65463,65467]
name: self [65597,65601]
===
match
---
atom_expr [56948,57015]
atom_expr [57082,57149]
===
match
---
decorator [19427,19437]
decorator [19427,19437]
===
match
---
trailer [14991,14999]
trailer [14991,14999]
===
match
---
fstring [48673,48727]
fstring [48673,48727]
===
match
---
atom_expr [18576,18599]
atom_expr [18576,18599]
===
match
---
operator: = [72780,72781]
operator: = [72914,72915]
===
match
---
operator: @ [24153,24154]
operator: @ [24153,24154]
===
match
---
string: """         Set TaskInstance state.          :param state: State to set for the TI         :type state: str         :param session: SQLAlchemy ORM Session         :type session: Session         """ [24451,24648]
string: """         Set TaskInstance state.          :param state: State to set for the TI         :type state: str         :param session: SQLAlchemy ORM Session         :type session: Session         """ [24451,24648]
===
match
---
name: self [8277,8281]
name: self [8277,8281]
===
match
---
trailer [30831,30839]
trailer [30831,30839]
===
match
---
operator: = [60475,60476]
operator: = [60609,60610]
===
match
---
simple_stmt [61033,61075]
simple_stmt [61167,61209]
===
match
---
operator: = [39458,39459]
operator: = [39458,39459]
===
match
---
name: delete_qry [7198,7208]
name: delete_qry [7198,7208]
===
match
---
name: reschedule_exception [44071,44091]
name: reschedule_exception [44071,44091]
===
match
---
name: dag_id [10648,10654]
name: dag_id [10648,10654]
===
match
---
name: info [43201,43205]
name: info [43201,43205]
===
match
---
atom_expr [22716,22727]
atom_expr [22716,22727]
===
match
---
name: pod [68900,68903]
name: pod [69034,69037]
===
match
---
fstring_expr [49255,49258]
fstring_expr [49255,49258]
===
match
---
sync_comp_for [76801,76860]
sync_comp_for [76935,76994]
===
match
---
atom_expr [9470,9528]
atom_expr [9470,9528]
===
match
---
trailer [78888,78903]
trailer [79022,79037]
===
match
---
name: self [80261,80265]
name: self [80395,80399]
===
match
---
number: 0 [12047,12048]
number: 0 [12047,12048]
===
match
---
trailer [22037,22046]
trailer [22037,22046]
===
match
---
annassign [79621,79639]
annassign [79755,79773]
===
match
---
name: log [3714,3717]
name: log [3714,3717]
===
match
---
trailer [25074,25080]
trailer [25074,25080]
===
match
---
argument [10339,10351]
argument [10339,10351]
===
match
---
name: session [40859,40866]
name: session [40859,40866]
===
match
---
simple_stmt [56703,56723]
simple_stmt [56837,56857]
===
match
---
operator: = [53467,53468]
operator: = [53467,53468]
===
match
---
name: staticmethod [63027,63039]
name: staticmethod [63161,63173]
===
match
---
trailer [71288,71295]
trailer [71422,71429]
===
match
---
name: dict [71313,71317]
name: dict [71447,71451]
===
match
---
name: dag_run [60328,60335]
name: dag_run [60462,60469]
===
match
---
operator: , [14133,14134]
operator: , [14133,14134]
===
match
---
operator: , [51861,51862]
operator: , [51861,51862]
===
match
---
trailer [9718,9731]
trailer [9718,9731]
===
match
---
operator: } [62215,62216]
operator: } [62349,62350]
===
match
---
arglist [49803,49816]
arglist [49803,49816]
===
match
---
name: __repr__ [62960,62968]
name: __repr__ [63094,63102]
===
match
---
name: airflow_context_vars [49272,49292]
name: airflow_context_vars [49272,49292]
===
match
---
simple_stmt [53059,53076]
simple_stmt [53059,53076]
===
match
---
simple_stmt [20846,20902]
simple_stmt [20846,20902]
===
match
---
name: dag [27664,27667]
name: dag [27664,27667]
===
match
---
operator: , [7724,7725]
operator: , [7724,7725]
===
match
---
trailer [67981,68002]
trailer [68115,68136]
===
match
---
name: task [26169,26173]
name: task [26169,26173]
===
match
---
atom_expr [61762,61786]
atom_expr [61896,61920]
===
match
---
trailer [13135,13141]
trailer [13135,13141]
===
match
---
name: delete [24070,24076]
name: delete [24070,24076]
===
match
---
name: self [28104,28108]
name: self [28104,28108]
===
match
---
trailer [70857,70865]
trailer [70991,70999]
===
match
---
name: session [39807,39814]
name: session [39807,39814]
===
match
---
name: execution_date [73703,73717]
name: execution_date [73837,73851]
===
match
---
simple_stmt [67884,67931]
simple_stmt [68018,68065]
===
match
---
trailer [5954,5975]
trailer [5954,5975]
===
match
---
atom_expr [78416,78491]
atom_expr [78550,78625]
===
match
---
name: context [50485,50492]
name: context [50485,50492]
===
match
---
simple_stmt [57903,57943]
simple_stmt [58037,58077]
===
match
---
name: ignore_ti_state [54034,54049]
name: ignore_ti_state [54034,54049]
===
match
---
name: info [43425,43429]
name: info [43425,43429]
===
match
---
name: self [58927,58931]
name: self [59061,59065]
===
match
---
atom_expr [3937,3968]
atom_expr [3937,3968]
===
match
---
atom_expr [49571,49609]
atom_expr [49571,49609]
===
match
---
trailer [4441,4446]
trailer [4441,4446]
===
match
---
string: 'execution_date' [64526,64542]
string: 'execution_date' [64660,64676]
===
match
---
param [55076,55097]
param [55076,55097]
===
match
---
except_clause [44312,44340]
except_clause [44312,44340]
===
match
---
trailer [7628,7634]
trailer [7628,7634]
===
match
---
operator: , [4675,4676]
operator: , [4675,4676]
===
match
---
suite [47282,47436]
suite [47282,47436]
===
match
---
import_from [2825,2866]
import_from [2825,2866]
===
match
---
trailer [22377,22387]
trailer [22377,22387]
===
match
---
suite [77856,79265]
suite [77990,79399]
===
match
---
name: in_ [7764,7767]
name: in_ [7764,7767]
===
match
---
name: provide_session [58865,58880]
name: provide_session [58999,59014]
===
match
---
expr_stmt [39855,39878]
expr_stmt [39855,39878]
===
match
---
argument [54506,54530]
argument [54506,54530]
===
match
---
trailer [32550,32556]
trailer [32550,32556]
===
match
---
param [52270,52315]
param [52270,52315]
===
match
---
simple_stmt [80111,80155]
simple_stmt [80245,80289]
===
match
---
name: tis [77945,77948]
name: tis [78079,78082]
===
match
---
trailer [63826,63830]
trailer [63960,63964]
===
match
---
simple_stmt [82350,82390]
simple_stmt [82484,82524]
===
match
---
suite [41354,41519]
suite [41354,41519]
===
match
---
if_stmt [18786,18848]
if_stmt [18786,18848]
===
match
---
atom_expr [12121,12131]
atom_expr [12121,12131]
===
match
---
operator: = [34063,34064]
operator: = [34063,34064]
===
match
---
operator: , [51788,51789]
operator: , [51788,51789]
===
match
---
trailer [59928,59941]
trailer [60062,60075]
===
match
---
string: "previous_start_date was called" [30099,30131]
string: "previous_start_date was called" [30099,30131]
===
match
---
name: self [41164,41168]
name: self [41164,41168]
===
match
---
name: task [22940,22944]
name: task [22940,22944]
===
match
---
trailer [29070,29091]
trailer [29070,29091]
===
match
---
trailer [54306,54319]
trailer [54306,54319]
===
match
---
decorated [77149,77593]
decorated [77283,77727]
===
match
---
name: dr [27784,27786]
name: dr [27784,27786]
===
match
---
simple_stmt [19186,19217]
simple_stmt [19186,19217]
===
match
---
operator: , [29233,29234]
operator: , [29233,29234]
===
match
---
if_stmt [55193,55226]
if_stmt [55193,55226]
===
match
---
name: self [37610,37614]
name: self [37610,37614]
===
match
---
operator: , [10072,10073]
operator: , [10072,10073]
===
match
---
trailer [70663,70674]
trailer [70797,70808]
===
match
---
simple_stmt [62364,62436]
simple_stmt [62498,62570]
===
match
---
name: self [40719,40723]
name: self [40719,40723]
===
match
---
argument [30752,30764]
argument [30752,30764]
===
match
---
argument [15438,15455]
argument [15438,15455]
===
match
---
operator: = [60308,60309]
operator: = [60442,60443]
===
match
---
operator: = [61543,61544]
operator: = [61677,61678]
===
match
---
expr_stmt [10094,10121]
expr_stmt [10094,10121]
===
match
---
expr_stmt [12148,12166]
expr_stmt [12148,12166]
===
match
---
simple_stmt [45023,45366]
simple_stmt [45023,45366]
===
match
---
name: self [24748,24752]
name: self [24748,24752]
===
match
---
simple_stmt [57679,57705]
simple_stmt [57813,57839]
===
match
---
trailer [14690,14704]
trailer [14690,14704]
===
match
---
name: self [67546,67550]
name: self [67680,67684]
===
match
---
expr_stmt [22373,22402]
expr_stmt [22373,22402]
===
match
---
suite [52622,52772]
suite [52622,52772]
===
match
---
operator: = [7933,7934]
operator: = [7933,7934]
===
match
---
name: context [49453,49460]
name: context [49453,49460]
===
match
---
atom_expr [40290,40306]
atom_expr [40290,40306]
===
match
---
trailer [57642,57663]
trailer [57776,57797]
===
match
---
name: vals_kv [76710,76717]
name: vals_kv [76844,76851]
===
match
---
simple_stmt [8041,8053]
simple_stmt [8041,8053]
===
match
---
atom_expr [13131,13141]
atom_expr [13131,13141]
===
match
---
expr_stmt [5048,5060]
expr_stmt [5048,5060]
===
match
---
name: Stats [2246,2251]
name: Stats [2246,2251]
===
match
---
operator: = [3171,3172]
operator: = [3171,3172]
===
match
---
funcdef [79524,80316]
funcdef [79658,80450]
===
match
---
operator: , [10752,10753]
operator: , [10752,10753]
===
match
---
operator: = [21884,21885]
operator: = [21884,21885]
===
match
---
name: verbose [53838,53845]
name: verbose [53838,53845]
===
match
---
param [32264,32269]
param [32264,32269]
===
match
---
name: log [2524,2527]
name: log [2524,2527]
===
match
---
arglist [33725,33965]
arglist [33725,33965]
===
match
---
trailer [77346,77352]
trailer [77480,77486]
===
match
---
name: info [31700,31704]
name: info [31700,31704]
===
match
---
name: subject [71910,71917]
name: subject [72044,72051]
===
match
---
simple_stmt [51896,51958]
simple_stmt [51896,51958]
===
match
---
name: isoformat [19257,19266]
name: isoformat [19257,19266]
===
match
---
name: Any [63168,63171]
name: Any [63302,63305]
===
match
---
name: ignore_task_deps [15756,15772]
name: ignore_task_deps [15756,15772]
===
match
---
atom_expr [22373,22387]
atom_expr [22373,22387]
===
match
---
name: ti [22759,22761]
name: ti [22759,22761]
===
match
---
name: task_id [78671,78678]
name: task_id [78805,78812]
===
match
---
trailer [47793,47798]
trailer [47793,47798]
===
match
---
trailer [29261,29270]
trailer [29261,29270]
===
match
---
expr_stmt [70771,70907]
expr_stmt [70905,71041]
===
match
---
name: context [52991,52998]
name: context [52991,52998]
===
match
---
name: ignore_all_deps [35668,35683]
name: ignore_all_deps [35668,35683]
===
match
---
trailer [63318,63322]
trailer [63452,63456]
===
match
---
fstring [49249,49259]
fstring [49249,49259]
===
match
---
name: pendulum [1208,1216]
name: pendulum [1208,1216]
===
match
---
name: fd [4057,4059]
name: fd [4057,4059]
===
match
---
name: taskfail [1944,1952]
name: taskfail [1944,1952]
===
match
---
expr_stmt [41399,41425]
expr_stmt [41399,41425]
===
match
---
operator: = [76442,76443]
operator: = [76576,76577]
===
match
---
trailer [22650,22666]
trailer [22650,22666]
===
match
---
name: ti [80095,80097]
name: ti [80229,80231]
===
match
---
name: self [81137,81141]
name: self [81271,81275]
===
match
---
string: 'core' [62310,62316]
string: 'core' [62444,62450]
===
match
---
name: ti [22431,22433]
name: ti [22431,22433]
===
match
---
suite [19919,20610]
suite [19919,20610]
===
match
---
atom_expr [41175,41194]
atom_expr [41175,41194]
===
match
---
name: self [21975,21979]
name: self [21975,21979]
===
match
---
operator: , [35891,35892]
operator: , [35891,35892]
===
match
---
simple_stmt [76888,76958]
simple_stmt [77022,77092]
===
match
---
trailer [22834,22840]
trailer [22834,22840]
===
match
---
atom_expr [22305,22319]
atom_expr [22305,22319]
===
match
---
simple_stmt [73753,73948]
simple_stmt [73887,74082]
===
match
---
trailer [5551,5561]
trailer [5551,5561]
===
match
---
param [15756,15787]
param [15756,15787]
===
match
---
atom_expr [13145,13158]
atom_expr [13145,13158]
===
match
---
name: following_schedule [61268,61286]
name: following_schedule [61402,61420]
===
match
---
operator: = [49764,49765]
operator: = [49764,49765]
===
match
---
name: self [45448,45452]
name: self [45448,45452]
===
match
---
simple_stmt [72405,72456]
simple_stmt [72539,72590]
===
match
---
trailer [78546,78553]
trailer [78680,78687]
===
match
---
suite [63790,63892]
suite [63924,64026]
===
match
---
trailer [68023,68046]
trailer [68157,68180]
===
match
---
suite [12687,13232]
suite [12687,13232]
===
match
---
operator: = [29076,29077]
operator: = [29076,29077]
===
match
---
name: first [78082,78087]
name: first [78216,78221]
===
match
---
string: """Returns a tuple that identifies the task instance uniquely""" [24209,24273]
string: """Returns a tuple that identifies the task instance uniquely""" [24209,24273]
===
match
---
trailer [29188,29193]
trailer [29188,29193]
===
match
---
simple_stmt [72237,72288]
simple_stmt [72371,72422]
===
match
---
string: """Only Renders Templates for the TI""" [54797,54836]
string: """Only Renders Templates for the TI""" [54797,54836]
===
match
---
except_clause [51462,51487]
except_clause [51462,51487]
===
match
---
simple_stmt [2380,2415]
simple_stmt [2380,2415]
===
match
---
name: str [56049,56052]
name: str [56049,56052]
===
match
---
name: self [43104,43108]
name: self [43104,43108]
===
match
---
trailer [18525,18532]
trailer [18525,18532]
===
match
---
trailer [62885,62889]
trailer [63019,63023]
===
match
---
atom_expr [81985,82005]
atom_expr [82119,82139]
===
match
---
fstring_string: . [48697,48698]
fstring_string: . [48697,48698]
===
match
---
name: AirflowException [44319,44335]
name: AirflowException [44319,44335]
===
match
---
operator: @ [45639,45640]
operator: @ [45639,45640]
===
match
---
operator: , [1449,1450]
operator: , [1449,1450]
===
match
---
name: html_content_err [72173,72189]
name: html_content_err [72307,72323]
===
match
---
operator: = [7466,7467]
operator: = [7466,7467]
===
match
---
name: test_mode [56313,56322]
name: test_mode [56313,56322]
===
match
---
param [14175,14204]
param [14175,14204]
===
match
---
name: dag_id [17999,18005]
name: dag_id [17999,18005]
===
match
---
operator: { [44914,44915]
operator: { [44914,44915]
===
match
---
name: command_as_list [14007,14022]
name: command_as_list [14007,14022]
===
match
---
atom_expr [46028,46186]
atom_expr [46028,46186]
===
match
---
simple_stmt [19331,19422]
simple_stmt [19331,19422]
===
match
---
suite [29272,29696]
suite [29272,29696]
===
match
---
operator: = [78088,78089]
operator: = [78222,78223]
===
match
---
operator: = [64121,64122]
operator: = [64255,64256]
===
match
---
name: __init__ [11173,11181]
name: __init__ [11173,11181]
===
match
---
name: dag [14847,14850]
name: dag [14847,14850]
===
match
---
decorator [58864,58881]
decorator [58998,59015]
===
match
---
trailer [7767,7802]
trailer [7767,7802]
===
match
---
argument [46741,46769]
argument [46741,46769]
===
match
---
name: dag_run [59895,59902]
name: dag_run [60029,60036]
===
match
---
import_name [886,899]
import_name [886,899]
===
match
---
if_stmt [26968,27331]
if_stmt [26968,27331]
===
match
---
name: timezone [11934,11942]
name: timezone [11934,11942]
===
match
---
string: 'Mark success: <a href="{{ti.mark_success_url}}">Link</a><br>' [69803,69865]
string: 'Mark success: <a href="{{ti.mark_success_url}}">Link</a><br>' [69937,69999]
===
match
---
name: NONE [39874,39878]
name: NONE [39874,39878]
===
match
---
if_stmt [72624,72787]
if_stmt [72758,72921]
===
match
---
trailer [19530,19545]
trailer [19530,19545]
===
match
---
parameters [4707,4774]
parameters [4707,4774]
===
match
---
name: base [1848,1852]
name: base [1848,1852]
===
match
---
return_stmt [59566,59575]
return_stmt [59700,59709]
===
match
---
operator: = [59134,59135]
operator: = [59268,59269]
===
match
---
simple_stmt [29566,29627]
simple_stmt [29566,29627]
===
match
---
trailer [52926,52947]
trailer [52926,52947]
===
match
---
simple_stmt [41399,41426]
simple_stmt [41399,41426]
===
match
---
funcdef [24167,24370]
funcdef [24167,24370]
===
match
---
name: context [3563,3570]
name: context [3563,3570]
===
match
---
operator: , [59011,59012]
operator: , [59145,59146]
===
match
---
trailer [78664,78668]
trailer [78798,78802]
===
match
---
atom_expr [71810,71818]
atom_expr [71944,71952]
===
match
---
name: dag_id [26124,26130]
name: dag_id [26124,26130]
===
match
---
fstring_expr [19129,19134]
fstring_expr [19129,19134]
===
match
---
trailer [19729,19736]
trailer [19729,19736]
===
match
---
simple_stmt [22019,22047]
simple_stmt [22019,22047]
===
match
---
name: Column [10144,10150]
name: Column [10144,10150]
===
match
---
trailer [71317,71526]
trailer [71451,71660]
===
match
---
trailer [79088,79095]
trailer [79222,79229]
===
match
---
funcdef [80521,80595]
funcdef [80655,80729]
===
match
---
if_stmt [59918,60409]
if_stmt [60052,60543]
===
match
---
operator: = [10346,10347]
operator: = [10346,10347]
===
match
---
name: _end_date [80751,80760]
name: _end_date [80885,80894]
===
match
---
name: Base [1884,1888]
name: Base [1884,1888]
===
match
---
name: ti [79829,79831]
name: ti [79963,79965]
===
match
---
name: self [68320,68324]
name: self [68454,68458]
===
match
---
operator: , [58957,58958]
operator: , [59091,59092]
===
match
---
name: num [47590,47593]
name: num [47590,47593]
===
match
---
name: bool [53378,53382]
name: bool [53378,53382]
===
match
---
name: self [79707,79711]
name: self [79841,79845]
===
match
---
atom_expr [51582,51616]
atom_expr [51582,51616]
===
match
---
name: self [59416,59420]
name: self [59550,59554]
===
match
---
name: self [24175,24179]
name: self [24175,24179]
===
match
---
name: actual_start_date [44052,44069]
name: actual_start_date [44052,44069]
===
match
---
name: airflow [2031,2038]
name: airflow [2031,2038]
===
match
---
param [74359,74388]
param [74493,74522]
===
match
---
atom_expr [22700,22713]
atom_expr [22700,22713]
===
match
---
string: "worker-config" [68620,68635]
string: "worker-config" [68754,68769]
===
match
---
name: AirflowRescheduleException [1715,1741]
name: AirflowRescheduleException [1715,1741]
===
match
---
name: self [11703,11707]
name: self [11703,11707]
===
match
---
annassign [39071,39135]
annassign [39071,39135]
===
match
---
string: '\n' [69278,69282]
string: '\n' [69412,69416]
===
match
---
operator: } [14768,14769]
operator: } [14768,14769]
===
match
---
name: max_tries [59386,59395]
name: max_tries [59520,59529]
===
match
---
simple_stmt [81432,81792]
simple_stmt [81566,81926]
===
match
---
operator: @ [32215,32216]
operator: @ [32215,32216]
===
match
---
param [81108,81112]
param [81242,81246]
===
match
---
trailer [47619,47626]
trailer [47619,47626]
===
match
---
name: try_number [6930,6940]
name: try_number [6930,6940]
===
match
---
trailer [45391,45393]
trailer [45391,45393]
===
match
---
trailer [52742,52762]
trailer [52742,52762]
===
match
---
name: extend [18199,18205]
name: extend [18199,18205]
===
match
---
name: ignore_all_deps [39527,39542]
name: ignore_all_deps [39527,39542]
===
match
---
suite [4422,4458]
suite [4422,4458]
===
match
---
trailer [72841,72850]
trailer [72975,72984]
===
match
---
if_stmt [45402,45499]
if_stmt [45402,45499]
===
match
---
name: Column [9934,9940]
name: Column [9934,9940]
===
match
---
simple_stmt [11740,11817]
simple_stmt [11740,11817]
===
match
---
trailer [18198,18205]
trailer [18198,18205]
===
match
---
trailer [37443,37469]
trailer [37443,37469]
===
match
---
atom_expr [79086,79095]
atom_expr [79220,79229]
===
match
---
name: sanitized_pod [68845,68858]
name: sanitized_pod [68979,68992]
===
match
---
name: min [34686,34689]
name: min [34686,34689]
===
match
---
operator: , [10601,10602]
operator: , [10601,10602]
===
match
---
string: """         The task instance for the task that ran before this task instance.          :param state: If passed, it only take into account instances of a specific state.         :param session: SQLAlchemy ORM Session         """ [26574,26802]
string: """         The task instance for the task that ran before this task instance.          :param state: If passed, it only take into account instances of a specific state.         :param session: SQLAlchemy ORM Session         """ [26574,26802]
===
match
---
name: execution_date [19531,19545]
name: execution_date [19531,19545]
===
match
---
argument [76351,76368]
argument [76485,76502]
===
match
---
name: session [26888,26895]
name: session [26888,26895]
===
match
---
name: utcnow [56686,56692]
name: utcnow [56820,56826]
===
match
---
trailer [58821,58827]
trailer [58955,58961]
===
match
---
name: ti_deps [2265,2272]
name: ti_deps [2265,2272]
===
match
---
name: dag_id [74059,74065]
name: dag_id [74193,74199]
===
match
---
operator: , [58476,58477]
operator: , [58610,58611]
===
match
---
simple_stmt [59795,59822]
simple_stmt [59929,59956]
===
match
---
name: or_ [79024,79027]
name: or_ [79158,79161]
===
match
---
name: session [76435,76442]
name: session [76569,76576]
===
match
---
name: expected_state [3867,3881]
name: expected_state [3867,3881]
===
match
---
trailer [54672,54682]
trailer [54672,54682]
===
match
---
suite [45821,47973]
suite [45821,47973]
===
match
---
simple_stmt [76189,76210]
simple_stmt [76323,76344]
===
match
---
trailer [54999,55001]
trailer [54999,55001]
===
match
---
trailer [63007,63011]
trailer [63141,63145]
===
match
---
trailer [80301,80306]
trailer [80435,80440]
===
match
---
name: skippable_task_ids [46924,46942]
name: skippable_task_ids [46924,46942]
===
match
---
operator: , [58218,58219]
operator: , [58352,58353]
===
match
---
name: TaskInstance [26096,26108]
name: TaskInstance [26096,26108]
===
match
---
trailer [79574,79582]
trailer [79708,79716]
===
match
---
trailer [9940,9954]
trailer [9940,9954]
===
match
---
simple_stmt [56661,56695]
simple_stmt [56795,56829]
===
match
---
name: RUNNING [40710,40717]
name: RUNNING [40710,40717]
===
match
---
suite [32524,32858]
suite [32524,32858]
===
match
---
name: refresh_from_task [37426,37443]
name: refresh_from_task [37426,37443]
===
match
---
name: self [43539,43543]
name: self [43539,43543]
===
match
---
simple_stmt [28787,29035]
simple_stmt [28787,29035]
===
match
---
operator: = [31853,31854]
operator: = [31853,31854]
===
match
---
argument [15415,15424]
argument [15415,15424]
===
match
---
trailer [34976,34996]
trailer [34976,34996]
===
match
---
name: ignore_schedule [27625,27640]
name: ignore_schedule [27625,27640]
===
match
---
simple_stmt [82176,82224]
simple_stmt [82310,82358]
===
match
---
atom_expr [74307,74342]
atom_expr [74441,74476]
===
match
---
name: self [44773,44777]
name: self [44773,44777]
===
match
---
import_from [1033,1117]
import_from [1033,1117]
===
match
---
operator: , [8785,8786]
operator: , [8785,8786]
===
match
---
operator: = [3160,3161]
operator: = [3160,3161]
===
match
---
argument [51769,51788]
argument [51769,51788]
===
match
---
name: STATICA_HACK [82156,82168]
name: STATICA_HACK [82290,82302]
===
match
---
trailer [26164,26168]
trailer [26164,26168]
===
match
---
atom_expr [29772,29785]
atom_expr [29772,29785]
===
match
---
trailer [21578,21584]
trailer [21578,21584]
===
match
---
name: t [78669,78670]
name: t [78803,78804]
===
match
---
name: defaultdict [5102,5113]
name: defaultdict [5102,5113]
===
match
---
name: Exception [72471,72480]
name: Exception [72605,72614]
===
match
---
name: cfg_path [15438,15446]
name: cfg_path [15438,15446]
===
match
---
name: pickle_id [15306,15315]
name: pickle_id [15306,15315]
===
match
---
trailer [12179,12192]
trailer [12179,12192]
===
match
---
funcdef [30867,32210]
funcdef [30867,32210]
===
match
---
decorated [12652,13232]
decorated [12652,13232]
===
match
---
trailer [60205,60212]
trailer [60339,60346]
===
match
---
trailer [7087,7089]
trailer [7087,7089]
===
match
---
trailer [52589,52609]
trailer [52589,52609]
===
match
---
name: on_success_callback [52863,52882]
name: on_success_callback [52863,52882]
===
match
---
atom [18697,18706]
atom [18697,18706]
===
match
---
name: state [39860,39865]
name: state [39860,39865]
===
match
---
name: self [22740,22744]
name: self [22740,22744]
===
match
---
name: execution_timeout [51275,51292]
name: execution_timeout [51275,51292]
===
match
---
name: airflow [1596,1603]
name: airflow [1596,1603]
===
match
---
name: dep_context [31609,31620]
name: dep_context [31609,31620]
===
match
---
name: self [35060,35064]
name: self [35060,35064]
===
match
---
name: dict [68103,68107]
name: dict [68237,68241]
===
match
---
name: set_state [24400,24409]
name: set_state [24400,24409]
===
match
---
trailer [51367,51381]
trailer [51367,51381]
===
match
---
name: max_tries [40567,40576]
name: max_tries [40567,40576]
===
match
---
trailer [13981,13993]
trailer [13981,13993]
===
match
---
simple_stmt [43221,43228]
simple_stmt [43221,43228]
===
match
---
atom_expr [78829,78848]
atom_expr [78963,78982]
===
match
---
decorated [50628,51033]
decorated [50628,51033]
===
match
---
name: xcom [77138,77142]
name: xcom [77272,77276]
===
match
---
string: "--pool" [18641,18649]
string: "--pool" [18641,18649]
===
match
---
operator: -> [80718,80720]
operator: -> [80852,80854]
===
match
---
operator: { [56762,56763]
operator: { [56896,56897]
===
match
---
name: BaseJob [7404,7411]
name: BaseJob [7404,7411]
===
match
---
name: Optional [29244,29252]
name: Optional [29244,29252]
===
match
---
tfpdef [52270,52308]
tfpdef [52270,52308]
===
match
---
tfpdef [35707,35735]
tfpdef [35707,35735]
===
match
---
atom_expr [9898,9918]
atom_expr [9898,9918]
===
match
---
trailer [65467,65477]
trailer [65601,65611]
===
match
---
operator: = [30909,30910]
operator: = [30909,30910]
===
match
---
argument [9492,9508]
argument [9492,9508]
===
match
---
simple_stmt [59333,59396]
simple_stmt [59467,59530]
===
match
---
trailer [56707,56720]
trailer [56841,56854]
===
match
---
trailer [27816,27833]
trailer [27816,27833]
===
match
---
expr_stmt [24769,24787]
expr_stmt [24769,24787]
===
match
---
trailer [3264,3274]
trailer [3264,3274]
===
match
---
name: context [67832,67839]
name: context [67966,67973]
===
match
---
trailer [67177,67183]
trailer [67311,67317]
===
match
---
expr_stmt [9664,9696]
expr_stmt [9664,9696]
===
match
---
name: state [65262,65267]
name: state [65396,65401]
===
match
---
atom_expr [79364,79391]
atom_expr [79498,79525]
===
match
---
atom_expr [48448,48496]
atom_expr [48448,48496]
===
match
---
name: log [43544,43547]
name: log [43544,43547]
===
match
---
trailer [20543,20549]
trailer [20543,20549]
===
match
---
atom_expr [5378,5399]
atom_expr [5378,5399]
===
match
---
expr_stmt [59447,59486]
expr_stmt [59581,59620]
===
match
---
tfpdef [62839,62848]
tfpdef [62973,62982]
===
match
---
operator: { [19724,19725]
operator: { [19724,19725]
===
match
---
name: Sentry [2213,2219]
name: Sentry [2213,2219]
===
match
---
expr_stmt [67967,68004]
expr_stmt [68101,68138]
===
match
---
name: dag_id [68233,68239]
name: dag_id [68367,68373]
===
match
---
tfpdef [63077,63086]
tfpdef [63211,63220]
===
match
---
name: execution_date [33837,33851]
name: execution_date [33837,33851]
===
match
---
operator: , [55096,55097]
operator: , [55096,55097]
===
match
---
suite [41101,41196]
suite [41101,41196]
===
match
---
name: job_id [22500,22506]
name: job_id [22500,22506]
===
match
---
operator: , [32758,32759]
operator: , [32758,32759]
===
match
---
trailer [53178,53180]
trailer [53178,53180]
===
match
---
simple_stmt [79805,79843]
simple_stmt [79939,79977]
===
match
---
name: self [46550,46554]
name: self [46550,46554]
===
match
---
trailer [61444,61456]
trailer [61578,61590]
===
match
---
operator: = [69910,69911]
operator: = [70044,70045]
===
match
---
name: extend [18062,18068]
name: extend [18062,18068]
===
match
---
operator: , [43898,43899]
operator: , [43898,43899]
===
match
---
name: retry_delay [33231,33242]
name: retry_delay [33231,33242]
===
match
---
operator: { [7698,7699]
operator: { [7698,7699]
===
match
---
name: refresh_from_db [43054,43069]
name: refresh_from_db [43054,43069]
===
match
---
name: path [14891,14895]
name: path [14891,14895]
===
match
---
name: items [49293,49298]
name: items [49293,49298]
===
match
---
name: dr [26859,26861]
name: dr [26859,26861]
===
match
---
name: SKIPPED [26302,26309]
name: SKIPPED [26302,26309]
===
match
---
name: session [27825,27832]
name: session [27825,27832]
===
match
---
name: hasattr [69208,69215]
name: hasattr [69342,69349]
===
match
---
name: pickle_id [15316,15325]
name: pickle_id [15316,15325]
===
match
---
name: raw [77625,77628]
name: raw [77759,77762]
===
match
---
trailer [43021,43036]
trailer [43021,43036]
===
match
---
simple_stmt [66050,66121]
simple_stmt [66184,66255]
===
match
---
name: TaskReschedule [2011,2025]
name: TaskReschedule [2011,2025]
===
match
---
name: test_mode [56282,56291]
name: test_mode [56282,56291]
===
match
---
simple_stmt [22740,22774]
simple_stmt [22740,22774]
===
match
---
expr_stmt [23290,23328]
expr_stmt [23290,23328]
===
match
---
operator: = [25007,25008]
operator: = [25007,25008]
===
match
---
operator: = [71918,71919]
operator: = [72052,72053]
===
match
---
trailer [7238,7250]
trailer [7238,7250]
===
match
---
name: ti [5462,5464]
name: ti [5462,5464]
===
match
---
param [72571,72575]
param [72705,72709]
===
match
---
operator: = [56641,56642]
operator: = [56775,56776]
===
match
---
name: Exception [52297,52306]
name: Exception [52297,52306]
===
match
---
for_stmt [32457,32858]
for_stmt [32457,32858]
===
match
---
trailer [48820,48826]
trailer [48820,48826]
===
match
---
trailer [18532,18545]
trailer [18532,18545]
===
match
---
name: airflow_context_vars [49349,49369]
name: airflow_context_vars [49349,49369]
===
match
---
name: task [52826,52830]
name: task [52826,52830]
===
match
---
expr_stmt [9959,9983]
expr_stmt [9959,9983]
===
match
---
name: _execution_date [79653,79668]
name: _execution_date [79787,79802]
===
match
---
operator: , [15292,15293]
operator: , [15292,15293]
===
match
---
tfpdef [29210,29226]
tfpdef [29210,29226]
===
match
---
name: partial_dag [46820,46831]
name: partial_dag [46820,46831]
===
match
---
atom_expr [44901,44912]
atom_expr [44901,44912]
===
match
---
atom_expr [77784,77822]
atom_expr [77918,77956]
===
match
---
tfpdef [4269,4284]
tfpdef [4269,4284]
===
match
---
name: self [58432,58436]
name: self [58566,58570]
===
match
---
arglist [50389,50407]
arglist [50389,50407]
===
match
---
operator: , [44734,44735]
operator: , [44734,44735]
===
match
---
name: Optional [15981,15989]
name: Optional [15981,15989]
===
match
---
name: query [77031,77036]
name: query [77165,77170]
===
match
---
name: session [25446,25453]
name: session [25446,25453]
===
match
---
name: String [9941,9947]
name: String [9941,9947]
===
match
---
name: error [59222,59227]
name: error [59356,59361]
===
match
---
trailer [20284,20473]
trailer [20284,20473]
===
match
---
string: 'schedule_after_task_execution' [45773,45804]
string: 'schedule_after_task_execution' [45773,45804]
===
match
---
fstring_string: . [44928,44929]
fstring_string: . [44928,44929]
===
match
---
trailer [5991,5997]
trailer [5991,5997]
===
match
---
trailer [82521,82529]
trailer [82655,82663]
===
match
---
operator: = [63172,63173]
operator: = [63306,63307]
===
match
---
operator: = [70611,70612]
operator: = [70745,70746]
===
match
---
funcdef [63905,63962]
funcdef [64039,64096]
===
match
---
name: task_ids [76351,76359]
name: task_ids [76485,76493]
===
match
---
atom_expr [26485,26498]
atom_expr [26485,26498]
===
match
---
arith_expr [34521,34554]
arith_expr [34521,34554]
===
match
---
name: deserialize_value [77120,77137]
name: deserialize_value [77254,77271]
===
match
---
param [30318,30322]
param [30318,30322]
===
match
---
name: self [34786,34790]
name: self [34786,34790]
===
match
---
name: self [24889,24893]
name: self [24889,24893]
===
match
---
simple_stmt [37610,37641]
simple_stmt [37610,37641]
===
match
---
name: test_mode [54411,54420]
name: test_mode [54411,54420]
===
match
---
suite [70298,71191]
suite [70432,71325]
===
match
---
trailer [45452,45458]
trailer [45452,45458]
===
match
---
operator: , [43029,43030]
operator: , [43029,43030]
===
match
---
atom_expr [73720,73739]
atom_expr [73854,73873]
===
match
---
trailer [44032,44051]
trailer [44032,44051]
===
match
---
name: self [68085,68089]
name: self [68219,68223]
===
match
---
operator: } [49253,49254]
operator: } [49253,49254]
===
match
---
suite [59517,59558]
suite [59651,59692]
===
match
---
operator: , [1110,1111]
operator: , [1110,1111]
===
match
---
trailer [78668,78692]
trailer [78802,78826]
===
match
---
name: task_id [76840,76847]
name: task_id [76974,76981]
===
match
---
expr_stmt [76219,76461]
expr_stmt [76353,76595]
===
match
---
simple_stmt [40590,40619]
simple_stmt [40590,40619]
===
match
---
funcdef [58885,59235]
funcdef [59019,59369]
===
match
---
operator: == [26236,26238]
operator: == [26236,26238]
===
match
---
trailer [4140,4146]
trailer [4140,4146]
===
match
---
trailer [35440,35455]
trailer [35440,35455]
===
match
---
name: log_message [58013,58024]
name: log_message [58147,58158]
===
match
---
fstring_expr [32944,32965]
fstring_expr [32944,32965]
===
match
---
name: task [23402,23406]
name: task [23402,23406]
===
match
---
funcdef [15490,18867]
funcdef [15490,18867]
===
match
---
name: execution_date [76274,76288]
name: execution_date [76408,76422]
===
match
---
string: '-' [62141,62144]
string: '-' [62275,62278]
===
match
---
simple_stmt [19278,19323]
simple_stmt [19278,19323]
===
match
---
expr_stmt [10238,10272]
expr_stmt [10238,10272]
===
match
---
trailer [34534,34548]
trailer [34534,34548]
===
match
---
operator: , [76368,76369]
operator: , [76502,76503]
===
match
---
simple_stmt [3251,3285]
simple_stmt [3251,3285]
===
match
---
if_stmt [51262,51617]
if_stmt [51262,51617]
===
match
---
name: models [1841,1847]
name: models [1841,1847]
===
match
---
simple_stmt [43993,44016]
simple_stmt [43993,44016]
===
match
---
name: Stats [56731,56736]
name: Stats [56865,56870]
===
match
---
name: self [55460,55464]
name: self [55460,55464]
===
match
---
name: state [43505,43510]
name: state [43505,43510]
===
match
---
fstring [19751,19775]
fstring [19751,19775]
===
match
---
name: getboolean [45749,45759]
name: getboolean [45749,45759]
===
match
---
trailer [41234,41238]
trailer [41234,41238]
===
match
---
tfpdef [15864,15888]
tfpdef [15864,15888]
===
match
---
operator: , [35697,35698]
operator: , [35697,35698]
===
match
---
suite [18182,18233]
suite [18182,18233]
===
match
---
trailer [51758,51768]
trailer [51758,51768]
===
match
---
suite [67954,68005]
suite [68088,68139]
===
match
---
operator: , [6998,6999]
operator: , [6998,6999]
===
match
---
name: BaseJob [82576,82583]
name: BaseJob [82710,82717]
===
match
---
name: commit [20980,20986]
name: commit [20980,20986]
===
match
---
name: task_id [46999,47006]
name: task_id [46999,47006]
===
match
---
expr_stmt [51573,51616]
expr_stmt [51573,51616]
===
match
---
operator: == [20322,20324]
operator: == [20322,20324]
===
match
---
simple_stmt [61237,61308]
simple_stmt [61371,61442]
===
match
---
parameters [71618,71632]
parameters [71752,71766]
===
match
---
name: property [80847,80855]
name: property [80981,80989]
===
match
---
name: warn [28276,28280]
name: warn [28276,28280]
===
match
---
trailer [82084,82090]
trailer [82218,82224]
===
match
---
operator: = [20536,20537]
operator: = [20536,20537]
===
match
---
trailer [47626,47628]
trailer [47626,47628]
===
match
---
name: update [62262,62268]
name: update [62396,62402]
===
match
---
argument [38503,38518]
argument [38503,38518]
===
match
---
expr_stmt [11324,11369]
expr_stmt [11324,11369]
===
match
---
trailer [80214,80231]
trailer [80348,80365]
===
match
---
name: int [33704,33707]
name: int [33704,33707]
===
match
---
trailer [26493,26498]
trailer [26493,26498]
===
match
---
string: """Render templates in the operator fields.""" [67884,67930]
string: """Render templates in the operator fields.""" [68018,68064]
===
match
---
name: airflow [2727,2734]
name: airflow [2727,2734]
===
match
---
string: 'ds' [64468,64472]
string: 'ds' [64602,64606]
===
match
---
name: log [58754,58757]
name: log [58888,58891]
===
match
---
operator: , [61895,61896]
operator: , [62029,62030]
===
match
---
operator: } [19699,19700]
operator: } [19699,19700]
===
match
---
atom_expr [14919,15466]
atom_expr [14919,15466]
===
match
---
trailer [65207,65296]
trailer [65341,65430]
===
match
---
name: self [41118,41122]
name: self [41118,41122]
===
match
---
trailer [60179,60189]
trailer [60313,60323]
===
match
---
name: task_id [79632,79639]
name: task_id [79766,79773]
===
match
---
name: self [70659,70663]
name: self [70793,70797]
===
match
---
name: relationship [82563,82575]
name: relationship [82697,82709]
===
match
---
fstring [32898,32982]
fstring [32898,32982]
===
match
---
name: self [32542,32546]
name: self [32542,32546]
===
match
---
suite [5321,6041]
suite [5321,6041]
===
match
---
atom_expr [59537,59557]
atom_expr [59671,59691]
===
match
---
operator: , [10654,10655]
operator: , [10654,10655]
===
match
---
operator: = [10022,10023]
operator: = [10022,10023]
===
match
---
suite [73740,73948]
suite [73874,74082]
===
match
---
trailer [59366,59377]
trailer [59500,59511]
===
match
---
simple_stmt [24451,24649]
simple_stmt [24451,24649]
===
match
---
operator: , [8764,8765]
operator: , [8764,8765]
===
match
---
atom_expr [65184,65296]
atom_expr [65318,65430]
===
match
---
string: "-" [37887,37890]
string: "-" [37887,37890]
===
match
---
comparison [47190,47226]
comparison [47190,47226]
===
match
---
operator: @ [41545,41546]
operator: @ [41545,41546]
===
match
---
operator: , [45458,45459]
operator: , [45458,45459]
===
match
---
operator: = [9993,9994]
operator: = [9993,9994]
===
match
---
name: hashlib [827,834]
name: hashlib [827,834]
===
match
---
simple_stmt [19567,19612]
simple_stmt [19567,19612]
===
match
---
operator: , [44556,44557]
operator: , [44556,44557]
===
match
---
operator: = [46764,46765]
operator: = [46764,46765]
===
match
---
dictorsetmaker [7699,7722]
dictorsetmaker [7699,7722]
===
match
---
operator: , [1311,1312]
operator: , [1311,1312]
===
match
---
operator: , [56618,56619]
operator: , [56752,56753]
===
match
---
name: get_previous_ti [28535,28550]
name: get_previous_ti [28535,28550]
===
match
---
trailer [64566,64581]
trailer [64700,64715]
===
match
---
name: send_email [72494,72504]
name: send_email [72628,72638]
===
match
---
operator: -> [30324,30326]
operator: -> [30324,30326]
===
match
---
name: _try_number [13866,13877]
name: _try_number [13866,13877]
===
match
---
operator: = [27113,27114]
operator: = [27113,27114]
===
match
---
trailer [70951,70968]
trailer [71085,71102]
===
match
---
name: self [80415,80419]
name: self [80549,80553]
===
match
---
name: XCom [76849,76853]
name: XCom [76983,76987]
===
match
---
trailer [13215,13227]
trailer [13215,13227]
===
match
---
name: self [80968,80972]
name: self [81102,81106]
===
match
---
operator: @ [18872,18873]
operator: @ [18872,18873]
===
match
---
operator: , [64647,64648]
operator: , [64781,64782]
===
match
---
name: hashlib [33725,33732]
name: hashlib [33725,33732]
===
match
---
trailer [62368,62403]
trailer [62502,62537]
===
match
---
trailer [32421,32426]
trailer [32421,32426]
===
match
---
name: self [54332,54336]
name: self [54332,54336]
===
match
---
param [72217,72226]
param [72351,72360]
===
match
---
trailer [38983,38985]
trailer [38983,38985]
===
match
---
comparison [59362,59395]
comparison [59496,59529]
===
match
---
operator: , [71622,71623]
operator: , [71756,71757]
===
match
---
comparison [78746,78772]
comparison [78880,78906]
===
match
---
name: Session [35075,35082]
name: Session [35075,35082]
===
match
---
name: filter [7397,7403]
name: filter [7397,7403]
===
match
---
suite [4515,4681]
suite [4515,4681]
===
match
---
string: 'execution_date can not be in the past (current ' [73787,73836]
string: 'execution_date can not be in the past (current ' [73921,73970]
===
match
---
name: execution_date [60214,60228]
name: execution_date [60348,60362]
===
match
---
name: context [51441,51448]
name: context [51441,51448]
===
match
---
trailer [20329,20336]
trailer [20329,20336]
===
match
---
name: total_seconds [33587,33600]
name: total_seconds [33587,33600]
===
match
---
expr_stmt [46924,47116]
expr_stmt [46924,47116]
===
match
---
trailer [27786,27816]
trailer [27786,27816]
===
match
---
argument [39639,39672]
argument [39639,39672]
===
match
---
trailer [6964,6970]
trailer [6964,6970]
===
match
---
trailer [24702,24706]
trailer [24702,24706]
===
match
---
trailer [59962,59966]
trailer [60096,60100]
===
match
---
return_stmt [4121,4146]
return_stmt [4121,4146]
===
match
---
argument [30185,30200]
argument [30185,30200]
===
match
---
trailer [61113,61128]
trailer [61247,61262]
===
match
---
name: extend [18445,18451]
name: extend [18445,18451]
===
match
---
raise_stmt [73753,73947]
raise_stmt [73887,74081]
===
match
---
trailer [58568,58580]
trailer [58702,58714]
===
match
---
name: ignore_task_deps [53971,53987]
name: ignore_task_deps [53971,53987]
===
match
---
name: NamedTuple [1083,1093]
name: NamedTuple [1083,1093]
===
match
---
comparison [47054,47098]
comparison [47054,47098]
===
match
---
name: do_xcom_push [51705,51717]
name: do_xcom_push [51705,51717]
===
match
---
name: self [44028,44032]
name: self [44028,44032]
===
match
---
trailer [79198,79213]
trailer [79332,79347]
===
match
---
operator: = [62890,62891]
operator: = [63024,63025]
===
match
---
name: mark_success [54381,54393]
name: mark_success [54381,54393]
===
match
---
funcdef [80614,80680]
funcdef [80748,80814]
===
match
---
parameters [29749,29823]
parameters [29749,29823]
===
match
---
name: or_ [1361,1364]
name: or_ [1361,1364]
===
match
---
trailer [76776,76784]
trailer [76910,76918]
===
match
---
atom_expr [44997,45014]
atom_expr [44997,45014]
===
match
---
trailer [81035,81040]
trailer [81169,81174]
===
match
---
decorator [74189,74206]
decorator [74323,74340]
===
match
---
name: str [18147,18150]
name: str [18147,18150]
===
match
---
name: Dict [3198,3202]
name: Dict [3198,3202]
===
match
---
name: log [52144,52147]
name: log [52144,52147]
===
match
---
name: AirflowSkipException [1747,1767]
name: AirflowSkipException [1747,1767]
===
match
---
expr_stmt [3150,3166]
expr_stmt [3150,3166]
===
match
---
simple_stmt [50881,50898]
simple_stmt [50881,50898]
===
match
---
arglist [45050,45355]
arglist [45050,45355]
===
match
---
simple_stmt [77704,77728]
simple_stmt [77838,77862]
===
match
---
operator: = [70565,70566]
operator: = [70699,70700]
===
match
---
operator: , [72106,72107]
operator: , [72240,72241]
===
match
---
operator: = [10212,10213]
operator: = [10212,10213]
===
match
---
operator: , [69282,69283]
operator: , [69416,69417]
===
match
---
atom_expr [19101,19112]
atom_expr [19101,19112]
===
match
---
name: self [40562,40566]
name: self [40562,40566]
===
match
---
operator: = [19287,19288]
operator: = [19287,19288]
===
match
---
simple_stmt [14734,14771]
simple_stmt [14734,14771]
===
match
---
tfpdef [53369,53382]
tfpdef [53369,53382]
===
match
---
atom_expr [11165,11183]
atom_expr [11165,11183]
===
match
---
arglist [43022,43035]
arglist [43022,43035]
===
match
---
operator: = [63690,63691]
operator: = [63824,63825]
===
match
---
operator: , [54049,54050]
operator: , [54049,54050]
===
match
---
name: incr [56801,56805]
name: incr [56935,56939]
===
match
---
name: self [46600,46604]
name: self [46600,46604]
===
match
---
trailer [28795,28800]
trailer [28795,28800]
===
match
---
argument [71339,71358]
argument [71473,71492]
===
match
---
param [30916,30929]
param [30916,30929]
===
match
---
for_stmt [31744,32078]
for_stmt [31744,32078]
===
match
---
trailer [77055,77061]
trailer [77189,77195]
===
match
---
name: ti [7713,7715]
name: ti [7713,7715]
===
match
---
atom_expr [7919,7932]
atom_expr [7919,7932]
===
match
---
trailer [46559,46563]
trailer [46559,46563]
===
match
---
atom_expr [67646,67658]
atom_expr [67780,67792]
===
match
---
if_stmt [61370,61584]
if_stmt [61504,61718]
===
match
---
name: start_date [38955,38965]
name: start_date [38955,38965]
===
match
---
arglist [39981,40207]
arglist [39981,40207]
===
match
---
name: in_ [7415,7418]
name: in_ [7415,7418]
===
match
---
operator: , [56999,57000]
operator: , [57133,57134]
===
match
---
trailer [10150,10159]
trailer [10150,10159]
===
match
---
atom_expr [60197,60212]
atom_expr [60331,60346]
===
match
---
name: REQUEUEABLE_DEPS [2349,2365]
name: REQUEUEABLE_DEPS [2349,2365]
===
match
---
classdef [79394,82154]
classdef [79528,82288]
===
match
---
name: duration [22078,22086]
name: duration [22078,22086]
===
match
---
trailer [3951,3967]
trailer [3951,3967]
===
match
---
simple_stmt [38564,38581]
simple_stmt [38564,38581]
===
match
---
name: ImportError [3133,3144]
name: ImportError [3133,3144]
===
match
---
arglist [23934,24059]
arglist [23934,24059]
===
match
---
trailer [50065,50083]
trailer [50065,50083]
===
match
---
name: setattr [66359,66366]
name: setattr [66493,66500]
===
match
---
name: error [4447,4452]
name: error [4447,4452]
===
match
---
tfpdef [24416,24426]
tfpdef [24416,24426]
===
match
---
name: task_id [6117,6124]
name: task_id [6117,6124]
===
match
---
if_stmt [11448,11974]
if_stmt [11448,11974]
===
match
---
name: self [72505,72509]
name: self [72639,72643]
===
match
---
operator: = [59005,59006]
operator: = [59139,59140]
===
match
---
trailer [33809,33816]
trailer [33809,33816]
===
match
---
name: self [39943,39947]
name: self [39943,39947]
===
match
---
operator: , [39109,39110]
operator: , [39109,39110]
===
match
---
name: ti [80002,80004]
name: ti [80136,80138]
===
match
---
name: info [43548,43552]
name: info [43548,43552]
===
match
---
parameters [19891,19911]
parameters [19891,19911]
===
match
---
string: 'ts_nodash_with_tz' [65667,65686]
string: 'ts_nodash_with_tz' [65801,65820]
===
match
---
atom_expr [10175,10195]
atom_expr [10175,10195]
===
match
---
name: execution_date [74129,74143]
name: execution_date [74263,74277]
===
match
---
operator: = [22507,22508]
operator: = [22507,22508]
===
match
---
name: task [26391,26395]
name: task [26391,26395]
===
match
---
suite [51887,52232]
suite [51887,52232]
===
match
---
operator: , [30896,30897]
operator: , [30896,30897]
===
match
---
tfpdef [56150,56175]
tfpdef [56150,56175]
===
match
---
parameters [24409,24441]
parameters [24409,24441]
===
match
---
name: try_number [24358,24368]
name: try_number [24358,24368]
===
match
---
name: self [34935,34939]
name: self [34935,34939]
===
match
---
name: try_number [8602,8612]
name: try_number [8602,8612]
===
match
---
trailer [70852,70857]
trailer [70986,70991]
===
match
---
name: airflow [2225,2232]
name: airflow [2225,2232]
===
match
---
atom_expr [6095,6108]
atom_expr [6095,6108]
===
match
---
name: session [30193,30200]
name: session [30193,30200]
===
match
---
name: get_dagrun [26869,26879]
name: get_dagrun [26869,26879]
===
match
---
param [77211,77218]
param [77345,77352]
===
match
---
name: self [30084,30088]
name: self [30084,30088]
===
match
---
name: send_email [72405,72415]
name: send_email [72539,72549]
===
match
---
atom_expr [37701,37711]
atom_expr [37701,37711]
===
match
---
name: task [52553,52557]
name: task [52553,52557]
===
match
---
trailer [50484,50516]
trailer [50484,50516]
===
match
---
name: field_name [66274,66284]
name: field_name [66408,66418]
===
match
---
string: "&downstream=false" [19818,19837]
string: "&downstream=false" [19818,19837]
===
match
---
operator: = [76359,76360]
operator: = [76493,76494]
===
match
---
simple_stmt [31873,32078]
simple_stmt [31873,32078]
===
match
---
name: replace [61494,61501]
name: replace [61628,61635]
===
match
---
atom_expr [53066,53075]
atom_expr [53066,53075]
===
match
---
expr_stmt [49058,49137]
expr_stmt [49058,49137]
===
match
---
name: str [8049,8052]
name: str [8049,8052]
===
match
---
name: task_id [19120,19127]
name: task_id [19120,19127]
===
match
---
decorated [41524,45613]
decorated [41524,45613]
===
match
---
name: str [16026,16029]
name: str [16026,16029]
===
match
---
param [67832,67865]
param [67966,67999]
===
match
---
atom_expr [73897,73916]
atom_expr [74031,74050]
===
match
---
name: UtcDateTime [9629,9640]
name: UtcDateTime [9629,9640]
===
match
---
simple_stmt [7919,7953]
simple_stmt [7919,7953]
===
match
---
expr_stmt [45982,46248]
expr_stmt [45982,46248]
===
match
---
atom_expr [21748,21767]
atom_expr [21748,21767]
===
match
---
name: error [52716,52721]
name: error [52716,52721]
===
match
---
simple_stmt [63403,63632]
simple_stmt [63537,63766]
===
match
---
expr_stmt [52912,52949]
expr_stmt [52912,52949]
===
match
---
name: dag_id [78852,78858]
name: dag_id [78986,78992]
===
match
---
operator: - [72705,72706]
operator: - [72839,72840]
===
match
---
trailer [58312,58323]
trailer [58446,58457]
===
match
---
param [80540,80544]
param [80674,80678]
===
match
---
parameters [48022,48043]
parameters [48022,48043]
===
match
---
operator: = [61879,61880]
operator: = [62013,62014]
===
match
---
name: NamedTemporaryFile [1014,1032]
name: NamedTemporaryFile [1014,1032]
===
match
---
operator: , [38333,38334]
operator: , [38333,38334]
===
match
---
name: datetime [79670,79678]
name: datetime [79804,79812]
===
match
---
trailer [23920,24069]
trailer [23920,24069]
===
match
---
simple_stmt [787,805]
simple_stmt [787,805]
===
match
---
name: UtcDateTime [2759,2770]
name: UtcDateTime [2759,2770]
===
match
---
name: session [42675,42682]
name: session [42675,42682]
===
match
---
atom_expr [6114,6124]
atom_expr [6114,6124]
===
match
---
operator: - [25024,25025]
operator: - [25024,25025]
===
match
---
name: self [80297,80301]
name: self [80431,80435]
===
match
---
parameters [30317,30323]
parameters [30317,30323]
===
match
---
name: str [11143,11146]
name: str [11143,11146]
===
match
---
name: subject [72296,72303]
name: subject [72430,72437]
===
match
---
fstring [19088,19139]
fstring [19088,19139]
===
match
---
simple_stmt [61593,61608]
simple_stmt [61727,61742]
===
match
---
name: airflow [35250,35257]
name: airflow [35250,35257]
===
match
---
decorated [32215,32858]
decorated [32215,32858]
===
match
---
name: self [12587,12591]
name: self [12587,12591]
===
match
---
simple_stmt [50774,50801]
simple_stmt [50774,50801]
===
match
---
name: state [10770,10775]
name: state [10770,10775]
===
match
---
name: timeout [51332,51339]
name: timeout [51332,51339]
===
match
---
operator: = [19012,19013]
operator: = [19012,19013]
===
match
---
trailer [40350,40356]
trailer [40350,40356]
===
match
---
trailer [78903,78907]
trailer [79037,79041]
===
match
---
operator: -> [59647,59649]
operator: -> [59781,59783]
===
match
---
trailer [27667,27685]
trailer [27667,27685]
===
match
---
name: tis [78095,78098]
name: tis [78229,78232]
===
match
---
name: info [50720,50724]
name: info [50720,50724]
===
match
---
name: func [1355,1359]
name: func [1355,1359]
===
match
---
name: Log [56871,56874]
name: Log [57005,57008]
===
match
---
name: get_rendered_k8s_spec [66944,66965]
name: get_rendered_k8s_spec [67078,67099]
===
match
---
operator: , [58358,58359]
operator: , [58492,58493]
===
match
---
simple_stmt [2303,2380]
simple_stmt [2303,2380]
===
match
---
import_from [952,992]
import_from [952,992]
===
match
---
simple_stmt [78800,79009]
simple_stmt [78934,79143]
===
match
---
name: ti [80174,80176]
name: ti [80308,80310]
===
match
---
name: state [5992,5997]
name: state [5992,5997]
===
match
---
name: self [59194,59198]
name: self [59328,59332]
===
match
---
name: context [52053,52060]
name: context [52053,52060]
===
match
---
operator: = [15251,15252]
operator: = [15251,15252]
===
match
---
atom_expr [76738,76752]
atom_expr [76872,76886]
===
match
---
simple_stmt [59702,59726]
simple_stmt [59836,59860]
===
match
---
suite [71633,71897]
suite [71767,72031]
===
match
---
name: filepath [14712,14720]
name: filepath [14712,14720]
===
match
---
simple_stmt [71910,71964]
simple_stmt [72044,72098]
===
match
---
operator: , [55542,55543]
operator: , [55542,55543]
===
match
---
trailer [19236,19269]
trailer [19236,19269]
===
match
---
trailer [45522,45524]
trailer [45522,45524]
===
match
---
if_stmt [49568,50266]
if_stmt [49568,50266]
===
match
---
name: task_id [26157,26164]
name: task_id [26157,26164]
===
match
---
name: dag [61182,61185]
name: dag [61316,61319]
===
match
---
atom_expr [58089,58108]
atom_expr [58223,58242]
===
match
---
trailer [16065,16070]
trailer [16065,16070]
===
match
---
comparison [53013,53045]
comparison [53013,53045]
===
match
---
name: provide_session [41525,41540]
name: provide_session [41525,41540]
===
match
---
decorated [24375,25087]
decorated [24375,25087]
===
match
---
name: hasattr [47310,47317]
name: hasattr [47310,47317]
===
match
---
import_from [993,1032]
import_from [993,1032]
===
match
---
atom_expr [7769,7786]
atom_expr [7769,7786]
===
match
---
name: UP_FOR_RETRY [53033,53045]
name: UP_FOR_RETRY [53033,53045]
===
match
---
string: "--job-id" [18207,18217]
string: "--job-id" [18207,18217]
===
match
---
name: state [24774,24779]
name: state [24774,24779]
===
match
---
atom_expr [53197,53217]
atom_expr [53197,53217]
===
match
---
name: executor_config [81250,81265]
name: executor_config [81384,81399]
===
match
---
import_name [835,849]
import_name [835,849]
===
match
---
name: _execution_date [80579,80594]
name: _execution_date [80713,80728]
===
match
---
name: get_hostname [42737,42749]
name: get_hostname [42737,42749]
===
match
---
atom_expr [59958,59973]
atom_expr [60092,60107]
===
match
---
name: log [58123,58126]
name: log [58257,58260]
===
match
---
param [29210,29234]
param [29210,29234]
===
match
---
argument [68233,68251]
argument [68367,68385]
===
match
---
string: '' [62011,62013]
string: '' [62145,62147]
===
match
---
trailer [4064,4066]
trailer [4064,4066]
===
match
---
operator: , [63213,63214]
operator: , [63347,63348]
===
match
---
name: utcnow [24681,24687]
name: utcnow [24681,24687]
===
match
---
expr_stmt [54870,54910]
expr_stmt [54870,54910]
===
match
---
atom_expr [20325,20336]
atom_expr [20325,20336]
===
match
---
trailer [62759,62763]
trailer [62893,62897]
===
match
---
param [15520,15532]
param [15520,15532]
===
match
---
string: 'BASE_URL' [19311,19321]
string: 'BASE_URL' [19311,19321]
===
match
---
dotted_name [3073,3105]
dotted_name [3073,3105]
===
match
---
trailer [45280,45295]
trailer [45280,45295]
===
match
---
arglist [45448,45464]
arglist [45448,45464]
===
match
---
strings [19652,19837]
strings [19652,19837]
===
match
---
trailer [39133,39135]
trailer [39133,39135]
===
match
---
trailer [32556,32777]
trailer [32556,32777]
===
match
---
trailer [26359,26362]
trailer [26359,26362]
===
match
---
name: job_ids [5048,5055]
name: job_ids [5048,5055]
===
match
---
trailer [50842,50844]
trailer [50842,50844]
===
match
---
name: State [43117,43122]
name: State [43117,43122]
===
match
---
dotted_name [2727,2751]
dotted_name [2727,2751]
===
match
---
name: self [32876,32880]
name: self [32876,32880]
===
match
---
import_from [1924,1968]
import_from [1924,1968]
===
match
---
simple_stmt [44981,45015]
simple_stmt [44981,45015]
===
match
---
name: self [59464,59468]
name: self [59598,59602]
===
match
---
name: t [78908,78909]
name: t [79042,79043]
===
match
---
trailer [47970,47972]
trailer [47970,47972]
===
match
---
name: overwrite_params_with_dag_run_conf [62369,62403]
name: overwrite_params_with_dag_run_conf [62503,62537]
===
match
---
name: session [54548,54555]
name: session [54548,54555]
===
match
---
name: task [25943,25947]
name: task [25943,25947]
===
match
---
trailer [81989,82005]
trailer [82123,82139]
===
match
---
testlist_comp [47153,47226]
testlist_comp [47153,47226]
===
match
---
argument [68447,68471]
argument [68581,68605]
===
match
---
atom_expr [78204,78217]
atom_expr [78338,78351]
===
match
---
operator: { [19100,19101]
operator: { [19100,19101]
===
match
---
sync_comp_for [46995,47098]
sync_comp_for [46995,47098]
===
match
---
funcdef [3899,4248]
funcdef [3899,4248]
===
match
---
name: airflow [1894,1901]
name: airflow [1894,1901]
===
match
---
name: DagRun [7742,7748]
name: DagRun [7742,7748]
===
match
---
trailer [41373,41385]
trailer [41373,41385]
===
match
---
not_test [45405,45418]
not_test [45405,45418]
===
match
---
name: first [35470,35475]
name: first [35470,35475]
===
match
---
name: task_id [68278,68285]
name: task_id [68412,68419]
===
match
---
atom_expr [22059,22072]
atom_expr [22059,22072]
===
match
---
trailer [80903,80910]
trailer [81037,81044]
===
match
---
name: dep_name [32672,32680]
name: dep_name [32672,32680]
===
match
---
fstring_string: Skipping mini scheduling run due to exception:  [47822,47869]
fstring_string: Skipping mini scheduling run due to exception:  [47822,47869]
===
match
---
if_stmt [42885,43037]
if_stmt [42885,43037]
===
match
---
expr_stmt [12057,12090]
expr_stmt [12057,12090]
===
match
---
dotted_name [35250,35271]
dotted_name [35250,35271]
===
match
---
operator: , [81889,81890]
operator: , [82023,82024]
===
match
---
expr_stmt [60418,60463]
expr_stmt [60552,60597]
===
match
---
subscriptlist [79370,79390]
subscriptlist [79504,79524]
===
match
---
string: "Immediate failure requested. Marking task as FAILED." [57762,57816]
string: "Immediate failure requested. Marking task as FAILED." [57896,57950]
===
match
---
suite [77011,77144]
suite [77145,77278]
===
match
---
operator: , [15032,15033]
operator: , [15032,15033]
===
match
---
simple_stmt [63941,63962]
simple_stmt [64075,64096]
===
match
---
operator: = [59038,59039]
operator: = [59172,59173]
===
match
---
name: State [7468,7473]
name: State [7468,7473]
===
match
---
operator: == [78732,78734]
operator: == [78866,78868]
===
match
---
operator: , [8519,8520]
operator: , [8519,8520]
===
match
---
operator: , [55055,55056]
operator: , [55055,55056]
===
match
---
trailer [12125,12131]
trailer [12125,12131]
===
match
---
simple_stmt [47785,47938]
simple_stmt [47785,47938]
===
match
---
trailer [20490,20492]
trailer [20490,20492]
===
match
---
operator: == [26384,26386]
operator: == [26384,26386]
===
match
---
name: job_id [9959,9965]
name: job_id [9959,9965]
===
match
---
trailer [29835,29854]
trailer [29835,29854]
===
match
---
simple_stmt [73052,73673]
simple_stmt [73186,73807]
===
match
---
suite [13923,13998]
suite [13923,13998]
===
match
---
name: duration [72679,72687]
name: duration [72813,72821]
===
match
---
name: bool [53462,53466]
name: bool [53462,53466]
===
match
---
name: ignore_task_deps [53988,54004]
name: ignore_task_deps [53988,54004]
===
match
---
name: ti [6076,6078]
name: ti [6076,6078]
===
match
---
name: dag_id [80379,80385]
name: dag_id [80513,80519]
===
match
---
name: from_string [71852,71863]
name: from_string [71986,71997]
===
match
---
operator: , [47883,47884]
operator: , [47883,47884]
===
match
---
argument [37450,37468]
argument [37450,37468]
===
match
---
atom_expr [21642,21653]
atom_expr [21642,21653]
===
match
---
name: self [40502,40506]
name: self [40502,40506]
===
match
---
operator: , [52295,52296]
operator: , [52295,52296]
===
match
---
string: 'Log file: {{ti.log_filepath}}<br>' [69755,69790]
string: 'Log file: {{ti.log_filepath}}<br>' [69889,69924]
===
match
---
simple_stmt [60472,60509]
simple_stmt [60606,60643]
===
match
---
operator: = [10173,10174]
operator: = [10173,10174]
===
match
---
name: renderedtifields [66070,66086]
name: renderedtifields [66204,66220]
===
match
---
name: last_dagrun [27987,27998]
name: last_dagrun [27987,27998]
===
match
---
param [14265,14280]
param [14265,14280]
===
match
---
operator: , [77438,77439]
operator: , [77572,77573]
===
match
---
trailer [44532,44538]
trailer [44532,44538]
===
match
---
trailer [62268,62281]
trailer [62402,62415]
===
match
---
name: TaskInstanceKey [77806,77821]
name: TaskInstanceKey [77940,77955]
===
match
---
trailer [60377,60379]
trailer [60511,60513]
===
match
---
string: 'run_as_user' [80006,80019]
string: 'run_as_user' [80140,80153]
===
match
---
atom_expr [44981,44994]
atom_expr [44981,44994]
===
match
---
simple_stmt [17965,18021]
simple_stmt [17965,18021]
===
match
---
name: primary_key [9642,9653]
name: primary_key [9642,9653]
===
match
---
operator: == [79083,79085]
operator: == [79217,79219]
===
match
---
name: end_date [40805,40813]
name: end_date [40805,40813]
===
match
---
name: State [6000,6005]
name: State [6000,6005]
===
match
---
name: post_execute [50472,50484]
name: post_execute [50472,50484]
===
match
---
expr_stmt [50809,50844]
expr_stmt [50809,50844]
===
match
---
name: encode [33899,33905]
name: encode [33899,33905]
===
match
---
name: open [71759,71763]
name: open [71893,71897]
===
match
---
trailer [47426,47434]
trailer [47426,47434]
===
match
---
if_stmt [18554,18600]
if_stmt [18554,18600]
===
match
---
trailer [61949,61966]
trailer [62083,62100]
===
match
---
operator: = [53064,53065]
operator: = [53064,53065]
===
match
---
trailer [68422,68433]
trailer [68556,68567]
===
match
---
name: exec2 [58620,58625]
name: exec2 [58754,58759]
===
match
---
name: TR [39073,39075]
name: TR [39073,39075]
===
match
---
name: reduced [8334,8341]
name: reduced [8334,8341]
===
match
---
operator: != [3690,3692]
operator: != [3690,3692]
===
match
---
name: info [46848,46852]
name: info [46848,46852]
===
match
---
simple_stmt [12057,12091]
simple_stmt [12057,12091]
===
match
---
trailer [76202,76209]
trailer [76336,76343]
===
match
---
trailer [43820,43835]
trailer [43820,43835]
===
match
---
trailer [72809,72851]
trailer [72943,72985]
===
match
---
suite [80399,80428]
suite [80533,80562]
===
match
---
arglist [38136,38385]
arglist [38136,38385]
===
match
---
atom_expr [27262,27330]
atom_expr [27262,27330]
===
match
---
name: refresh_from_db [44359,44374]
name: refresh_from_db [44359,44374]
===
match
---
string: "Task successfully registered in smart sensor." [50984,51031]
string: "Task successfully registered in smart sensor." [50984,51031]
===
match
---
name: session [81370,81377]
name: session [81504,81511]
===
match
---
simple_stmt [52912,52950]
simple_stmt [52912,52950]
===
match
---
string: 'Try {{try_number}} out of {{max_tries + 1}}<br>' [69545,69594]
string: 'Try {{try_number}} out of {{max_tries + 1}}<br>' [69679,69728]
===
match
---
name: test_mode [56836,56845]
name: test_mode [56970,56979]
===
match
---
name: rendered_k8s_spec [67199,67216]
name: rendered_k8s_spec [67333,67350]
===
match
---
name: dag_id [48965,48971]
name: dag_id [48965,48971]
===
match
---
name: date [68447,68451]
name: date [68581,68585]
===
match
---
trailer [31695,31699]
trailer [31695,31699]
===
match
---
name: state [5243,5248]
name: state [5243,5248]
===
match
---
name: attr [41348,41352]
name: attr [41348,41352]
===
match
---
operator: @ [55973,55974]
operator: @ [55973,55974]
===
match
---
arglist [62310,62349]
arglist [62444,62483]
===
match
---
name: queue [80283,80288]
name: queue [80417,80422]
===
match
---
argument [9583,9599]
argument [9583,9599]
===
match
---
atom_expr [33254,33289]
atom_expr [33254,33289]
===
match
---
simple_stmt [40627,40649]
simple_stmt [40627,40649]
===
match
---
atom_expr [33805,33816]
atom_expr [33805,33816]
===
match
---
operator: = [15286,15287]
operator: = [15286,15287]
===
match
---
atom_expr [26096,26115]
atom_expr [26096,26115]
===
match
---
operator: = [11009,11010]
operator: = [11009,11010]
===
match
---
trailer [26082,26337]
trailer [26082,26337]
===
match
---
simple_stmt [23519,23563]
simple_stmt [23519,23563]
===
match
---
trailer [64296,64350]
trailer [64430,64484]
===
match
---
trailer [32438,32443]
trailer [32438,32443]
===
match
---
trailer [45568,45603]
trailer [45568,45603]
===
match
---
trailer [74037,74045]
trailer [74171,74179]
===
match
---
name: execution_date [56968,56982]
name: execution_date [57102,57116]
===
match
---
name: error_file [4269,4279]
name: error_file [4269,4279]
===
match
---
if_stmt [24854,25059]
if_stmt [24854,25059]
===
match
---
operator: = [74493,74494]
operator: = [74627,74628]
===
match
---
parameters [3337,3355]
parameters [3337,3355]
===
match
---
argument [27291,27329]
argument [27291,27329]
===
match
---
name: reschedule_date [55581,55596]
name: reschedule_date [55581,55596]
===
match
---
name: test_mode [12444,12453]
name: test_mode [12444,12453]
===
match
---
operator: , [14255,14256]
operator: , [14255,14256]
===
match
---
suite [81121,81149]
suite [81255,81283]
===
match
---
name: datetime [957,965]
name: datetime [957,965]
===
match
---
except_clause [44717,44759]
except_clause [44717,44759]
===
match
---
atom_expr [56371,56396]
atom_expr [56503,56530]
===
match
---
name: task [11274,11278]
name: task [11274,11278]
===
match
---
suite [34661,34724]
suite [34661,34724]
===
match
---
arglist [27905,27933]
arglist [27905,27933]
===
match
---
arglist [56608,56625]
arglist [56742,56759]
===
match
---
string: 'prev_execution_date_success' [64996,65025]
string: 'prev_execution_date_success' [65130,65159]
===
match
---
operator: , [54004,54005]
operator: , [54004,54005]
===
match
---
trailer [41270,41275]
trailer [41270,41275]
===
match
---
operator: = [44256,44257]
operator: = [44256,44257]
===
match
---
operator: = [81399,81400]
operator: = [81533,81534]
===
match
---
name: session [23654,23661]
name: session [23654,23661]
===
match
---
atom_expr [28605,28629]
atom_expr [28605,28629]
===
match
---
simple_stmt [39855,39879]
simple_stmt [39855,39879]
===
match
---
suite [77091,77144]
suite [77225,77278]
===
match
---
name: self [11324,11328]
name: self [11324,11328]
===
match
---
atom_expr [7621,7836]
atom_expr [7621,7836]
===
match
---
arglist [24305,24368]
arglist [24305,24368]
===
match
---
operator: , [15591,15592]
operator: , [15591,15592]
===
match
---
name: state [7885,7890]
name: state [7885,7890]
===
match
---
trailer [60201,60205]
trailer [60335,60339]
===
match
---
name: error_fd [54517,54525]
name: error_fd [54517,54525]
===
match
---
operator: = [12162,12163]
operator: = [12162,12163]
===
match
---
suite [68109,68934]
suite [68243,69068]
===
match
---
trailer [44905,44912]
trailer [44905,44912]
===
match
---
name: dag_id [23954,23960]
name: dag_id [23954,23960]
===
match
---
decorator [18872,18882]
decorator [18872,18882]
===
match
---
name: provide_session [72858,72873]
name: provide_session [72992,73007]
===
match
---
trailer [6692,7107]
trailer [6692,7107]
===
match
---
trailer [62904,62910]
trailer [63038,63044]
===
match
---
trailer [53246,53264]
trailer [53246,53264]
===
match
---
name: ignore_depends_on_past [15200,15222]
name: ignore_depends_on_past [15200,15222]
===
match
---
atom_expr [49423,49461]
atom_expr [49423,49461]
===
match
---
simple_stmt [20910,20936]
simple_stmt [20910,20936]
===
match
---
suite [43179,43228]
suite [43179,43228]
===
match
---
atom_expr [79196,79213]
atom_expr [79330,79347]
===
match
---
simple_stmt [59991,60022]
simple_stmt [60125,60156]
===
match
---
param [81266,81270]
param [81400,81404]
===
match
---
operator: = [11932,11933]
operator: = [11932,11933]
===
match
---
arglist [35381,35455]
arglist [35381,35455]
===
match
---
suite [14721,14771]
suite [14721,14771]
===
match
---
name: max_tries [5552,5561]
name: max_tries [5552,5561]
===
match
---
argument [51600,51615]
argument [51600,51615]
===
match
---
operator: = [31802,31803]
operator: = [31802,31803]
===
match
---
name: airflow [59764,59771]
name: airflow [59898,59905]
===
match
---
operator: = [41631,41632]
operator: = [41631,41632]
===
match
---
atom_expr [5934,5976]
atom_expr [5934,5976]
===
match
---
simple_stmt [5065,5141]
simple_stmt [5065,5141]
===
match
---
name: state [24782,24787]
name: state [24782,24787]
===
match
---
trailer [47526,47594]
trailer [47526,47594]
===
match
---
name: self [53153,53157]
name: self [53153,53157]
===
match
---
name: provide_session [20616,20631]
name: provide_session [20616,20631]
===
match
---
operator: == [78429,78431]
operator: == [78563,78565]
===
match
---
for_stmt [32399,32858]
for_stmt [32399,32858]
===
match
---
name: execution_date [11917,11931]
name: execution_date [11917,11931]
===
match
---
funcdef [54770,55002]
funcdef [54770,55002]
===
match
---
name: e [47668,47669]
name: e [47668,47669]
===
match
---
name: self [77619,77623]
name: self [77753,77757]
===
match
---
operator: , [32268,32269]
operator: , [32268,32269]
===
match
---
name: get_previous_start_date [30796,30819]
name: get_previous_start_date [30796,30819]
===
match
---
trailer [22459,22468]
trailer [22459,22468]
===
match
---
tfpdef [26478,26498]
tfpdef [26478,26498]
===
match
---
atom_expr [14583,14596]
atom_expr [14583,14596]
===
match
---
name: AirflowTaskTimeout [51469,51487]
name: AirflowTaskTimeout [51469,51487]
===
match
---
simple_stmt [63303,63354]
simple_stmt [63437,63488]
===
match
---
name: session [54556,54563]
name: session [54556,54563]
===
match
---
trailer [7170,7176]
trailer [7170,7176]
===
match
---
trailer [26821,26826]
trailer [26821,26826]
===
match
---
name: hostname [22420,22428]
name: hostname [22420,22428]
===
match
---
decorated [13237,13322]
decorated [13237,13322]
===
match
---
simple_stmt [55219,55226]
simple_stmt [55219,55226]
===
match
---
parameters [29149,29240]
parameters [29149,29240]
===
match
---
name: include_upstream [46697,46713]
name: include_upstream [46697,46713]
===
match
---
name: pendulum [61545,61553]
name: pendulum [61679,61687]
===
match
---
operator: , [56982,56983]
operator: , [57116,57117]
===
match
---
atom_expr [18219,18230]
atom_expr [18219,18230]
===
match
---
tfpdef [58941,58969]
tfpdef [59075,59103]
===
match
---
name: registered [50104,50114]
name: registered [50104,50114]
===
match
---
operator: = [79914,79915]
operator: = [80048,80049]
===
match
---
operator: = [3196,3197]
operator: = [3196,3197]
===
match
---
operator: = [52558,52559]
operator: = [52558,52559]
===
match
---
trailer [40294,40306]
trailer [40294,40306]
===
match
---
name: ID_LEN [9556,9562]
name: ID_LEN [9556,9562]
===
match
---
name: lock_for_update [21055,21070]
name: lock_for_update [21055,21070]
===
match
---
trailer [24322,24330]
trailer [24322,24330]
===
match
---
name: set [73962,73965]
name: set [74096,74099]
===
match
---
operator: , [15455,15456]
operator: , [15455,15456]
===
match
---
trailer [48964,48971]
trailer [48964,48971]
===
match
---
operator: = [26524,26525]
operator: = [26524,26525]
===
match
---
arglist [72505,72547]
arglist [72639,72681]
===
match
---
name: PodGenerator [68546,68558]
name: PodGenerator [68680,68692]
===
match
---
argument [65109,65128]
argument [65243,65262]
===
match
---
name: self [26472,26476]
name: self [26472,26476]
===
match
---
tfpdef [53632,53653]
tfpdef [53632,53653]
===
match
---
decorated [8124,8311]
decorated [8124,8311]
===
match
---
name: Column [9773,9779]
name: Column [9773,9779]
===
match
---
name: warn [30529,30533]
name: warn [30529,30533]
===
match
---
trailer [43780,43798]
trailer [43780,43798]
===
match
---
operator: = [24435,24436]
operator: = [24435,24436]
===
match
---
trailer [61002,61019]
trailer [61136,61153]
===
match
---
comparison [6843,6870]
comparison [6843,6870]
===
match
---
argument [70819,70876]
argument [70953,71010]
===
match
---
name: Any [1056,1059]
name: Any [1056,1059]
===
match
---
suite [5159,6126]
suite [5159,6126]
===
match
---
name: utils [2685,2690]
name: utils [2685,2690]
===
match
---
operator: , [15936,15937]
operator: , [15936,15937]
===
match
---
name: airflow [2938,2945]
name: airflow [2938,2945]
===
match
---
fstring_expr [19686,19700]
fstring_expr [19686,19700]
===
match
---
name: delay_backoff_in_seconds [34594,34618]
name: delay_backoff_in_seconds [34594,34618]
===
match
---
trailer [71575,71592]
trailer [71709,71726]
===
match
---
name: dag_id [77417,77423]
name: dag_id [77551,77557]
===
match
---
name: warning [11534,11541]
name: warning [11534,11541]
===
match
---
arglist [55396,55597]
arglist [55396,55597]
===
match
---
name: State [40747,40752]
name: State [40747,40752]
===
match
---
operator: , [59167,59168]
operator: , [59301,59302]
===
match
---
trailer [44013,44015]
trailer [44013,44015]
===
match
---
trailer [37425,37443]
trailer [37425,37443]
===
match
---
name: info [49159,49163]
name: info [49159,49163]
===
match
---
name: task [42612,42616]
name: task [42612,42616]
===
match
---
name: tis [7719,7722]
name: tis [7719,7722]
===
match
---
argument [54162,54171]
argument [54162,54171]
===
match
---
name: modded_hash [34508,34519]
name: modded_hash [34508,34519]
===
match
---
name: filter [7656,7662]
name: filter [7656,7662]
===
match
---
operator: = [61107,61108]
operator: = [61241,61242]
===
match
---
operator: = [21070,21071]
operator: = [21070,21071]
===
match
---
operator: , [65296,65297]
operator: , [65430,65431]
===
match
---
atom_expr [7211,7250]
atom_expr [7211,7250]
===
match
---
simple_stmt [34568,34620]
simple_stmt [34568,34620]
===
match
---
name: self [28596,28600]
name: self [28596,28600]
===
match
---
suite [18110,18164]
suite [18110,18164]
===
match
---
number: 1 [82204,82205]
number: 1 [82338,82339]
===
match
---
trailer [57697,57704]
trailer [57831,57838]
===
match
---
expr_stmt [12029,12048]
expr_stmt [12029,12048]
===
match
---
suite [27963,28048]
suite [27963,28048]
===
match
---
operator: = [35652,35653]
operator: = [35652,35653]
===
match
---
atom_expr [37742,37782]
atom_expr [37742,37782]
===
match
---
if_stmt [56829,56896]
if_stmt [56963,57030]
===
match
---
name: _dag_id [81882,81889]
name: _dag_id [82016,82023]
===
match
---
name: self [74124,74128]
name: self [74258,74262]
===
match
---
if_stmt [7292,7483]
if_stmt [7292,7483]
===
match
---
import_from [1969,2025]
import_from [1969,2025]
===
match
---
parameters [80385,80391]
parameters [80519,80525]
===
match
---
atom_expr [50047,50083]
atom_expr [50047,50083]
===
match
---
atom_expr [45508,45524]
atom_expr [45508,45524]
===
match
---
name: test_mode [56330,56339]
name: test_mode [56330,56339]
===
match
---
name: self [48023,48027]
name: self [48023,48027]
===
match
---
operator: , [35743,35744]
operator: , [35743,35744]
===
match
---
expr_stmt [76710,76874]
expr_stmt [76844,77008]
===
match
---
subscriptlist [4299,4313]
subscriptlist [4299,4313]
===
match
---
parameters [14022,14368]
parameters [14022,14368]
===
match
---
arglist [38462,38532]
arglist [38462,38532]
===
match
---
name: _dag_id [79575,79582]
name: _dag_id [79709,79716]
===
match
---
name: email_for_state [57903,57918]
name: email_for_state [58037,58052]
===
match
---
name: hasattr [79994,80001]
name: hasattr [80128,80135]
===
match
---
name: provide_session [59582,59597]
name: provide_session [59716,59731]
===
match
---
simple_stmt [64203,64261]
simple_stmt [64337,64395]
===
match
---
name: self [56963,56967]
name: self [57097,57101]
===
match
---
name: session [7621,7628]
name: session [7621,7628]
===
match
---
decorated [63026,63354]
decorated [63160,63488]
===
match
---
name: execution_date [11888,11902]
name: execution_date [11888,11902]
===
match
---
argument [37534,37549]
argument [37534,37549]
===
match
---
trailer [6886,6896]
trailer [6886,6896]
===
match
---
parameters [67545,67568]
parameters [67679,67702]
===
match
---
name: airflow [2308,2315]
name: airflow [2308,2315]
===
match
---
trailer [56943,56947]
trailer [57077,57081]
===
match
---
name: self [29759,29763]
name: self [29759,29763]
===
match
---
name: queue [22628,22633]
name: queue [22628,22633]
===
match
---
name: priority_weight [23384,23399]
name: priority_weight [23384,23399]
===
match
---
operator: = [27279,27280]
operator: = [27279,27280]
===
match
---
name: task_copy [51340,51349]
name: task_copy [51340,51349]
===
match
---
operator: , [34715,34716]
operator: , [34715,34716]
===
match
---
parameters [19461,19467]
parameters [19461,19467]
===
match
---
name: settings [1582,1590]
name: settings [1582,1590]
===
match
---
trailer [68319,68346]
trailer [68453,68480]
===
match
---
operator: , [78563,78564]
operator: , [78697,78698]
===
match
---
operator: , [64725,64726]
operator: , [64859,64860]
===
match
---
operator: = [11334,11335]
operator: = [11334,11335]
===
match
---
name: session [46898,46905]
name: session [46898,46905]
===
match
---
atom_expr [68306,68346]
atom_expr [68440,68480]
===
match
---
trailer [50055,50065]
trailer [50055,50065]
===
match
---
trailer [19037,19041]
trailer [19037,19041]
===
match
---
name: dep_status [32802,32812]
name: dep_status [32802,32812]
===
match
---
atom_expr [29654,29695]
atom_expr [29654,29695]
===
match
---
operator: = [27641,27642]
operator: = [27641,27642]
===
match
---
comparison [37701,37728]
comparison [37701,37728]
===
match
---
trailer [62938,62942]
trailer [63072,63076]
===
match
---
name: state [29597,29602]
name: state [29597,29602]
===
match
---
operator: , [8275,8276]
operator: , [8275,8276]
===
match
---
import_from [3068,3125]
import_from [3068,3125]
===
match
---
name: self [79648,79652]
name: self [79782,79786]
===
match
---
name: state [34940,34945]
name: state [34940,34945]
===
match
---
suite [76176,76210]
suite [76310,76344]
===
match
---
string: """Functions that need to be run before a Task is executed""" [51896,51957]
string: """Functions that need to be run before a Task is executed""" [51896,51957]
===
match
---
operator: = [54454,54455]
operator: = [54454,54455]
===
match
---
atom_expr [13861,13877]
atom_expr [13861,13877]
===
match
---
import_from [1118,1148]
import_from [1118,1148]
===
match
---
atom_expr [28267,28514]
atom_expr [28267,28514]
===
match
---
expr_stmt [52826,52842]
expr_stmt [52826,52842]
===
match
---
name: self [43445,43449]
name: self [43445,43449]
===
match
---
atom_expr [45199,45211]
atom_expr [45199,45211]
===
match
---
operator: = [42779,42780]
operator: = [42779,42780]
===
match
---
trailer [72649,72660]
trailer [72783,72794]
===
match
---
simple_stmt [18441,18482]
simple_stmt [18441,18482]
===
match
---
decorator [72857,72874]
decorator [72991,73008]
===
match
---
comparison [27643,27660]
comparison [27643,27660]
===
match
---
trailer [5113,5139]
trailer [5113,5139]
===
match
---
name: instance [61830,61838]
name: instance [61964,61972]
===
match
---
funcdef [53300,54765]
funcdef [53300,54765]
===
match
---
name: dep_context [2273,2284]
name: dep_context [2273,2284]
===
match
---
operator: -> [72577,72579]
operator: -> [72711,72713]
===
match
---
name: task_ids [76948,76956]
name: task_ids [77082,77090]
===
match
---
name: check_and_change_state_before_execution [35537,35576]
name: check_and_change_state_before_execution [35537,35576]
===
match
---
name: extend [18526,18532]
name: extend [18526,18532]
===
match
---
name: t [78683,78684]
name: t [78817,78818]
===
match
---
name: ignore_depends_on_past [14175,14197]
name: ignore_depends_on_past [14175,14197]
===
match
---
fstring_string: . [44913,44914]
fstring_string: . [44913,44914]
===
match
---
trailer [68558,68567]
trailer [68692,68701]
===
match
---
name: try_number [33617,33627]
name: try_number [33617,33627]
===
match
---
name: State [50787,50792]
name: State [50787,50792]
===
match
---
return_stmt [81050,81078]
return_stmt [81184,81212]
===
match
---
name: max_tries [40193,40202]
name: max_tries [40193,40202]
===
match
---
name: task_ids [76687,76695]
name: task_ids [76821,76829]
===
match
---
name: ignore_all_deps [38190,38205]
name: ignore_all_deps [38190,38205]
===
match
---
trailer [42789,42796]
trailer [42789,42796]
===
match
---
name: pool [23324,23328]
name: pool [23324,23328]
===
match
---
simple_stmt [50526,50588]
simple_stmt [50526,50588]
===
match
---
operator: = [80052,80053]
operator: = [80186,80187]
===
match
---
atom_expr [54695,54711]
atom_expr [54695,54711]
===
match
---
name: DagRun [7560,7566]
name: DagRun [7560,7566]
===
match
---
operator: , [67550,67551]
operator: , [67684,67685]
===
match
---
name: dag_run [67634,67641]
name: dag_run [67768,67775]
===
match
---
atom_expr [71442,71457]
atom_expr [71576,71591]
===
match
---
arith_expr [38141,38172]
arith_expr [38141,38172]
===
match
---
name: _run_mini_scheduler_on_child_tasks [45569,45603]
name: _run_mini_scheduler_on_child_tasks [45569,45603]
===
match
---
return_stmt [80739,80760]
return_stmt [80873,80894]
===
match
---
comparison [81954,82005]
comparison [82088,82139]
===
match
---
name: utils [2393,2398]
name: utils [2393,2398]
===
match
---
suite [71205,72134]
suite [71339,72268]
===
match
---
decorated [45618,47973]
decorated [45618,47973]
===
match
---
name: dep_context [32363,32374]
name: dep_context [32363,32374]
===
match
---
trailer [11291,11309]
trailer [11291,11309]
===
match
---
trailer [68046,68055]
trailer [68180,68189]
===
match
---
atom_expr [7259,7286]
atom_expr [7259,7286]
===
match
---
atom_expr [56763,56777]
atom_expr [56897,56911]
===
match
---
trailer [32018,32027]
trailer [32018,32027]
===
match
---
atom_expr [12439,12453]
atom_expr [12439,12453]
===
match
---
trailer [56956,57015]
trailer [57090,57149]
===
match
---
sync_comp_for [79241,79254]
sync_comp_for [79375,79388]
===
match
---
arglist [44650,44685]
arglist [44650,44685]
===
match
---
suite [20563,20589]
suite [20563,20589]
===
match
---
atom_expr [82176,82215]
atom_expr [82310,82349]
===
match
---
expr_stmt [9796,9850]
expr_stmt [9796,9850]
===
match
---
import_from [67034,67104]
import_from [67168,67238]
===
match
---
suite [52011,52062]
suite [52011,52062]
===
match
---
atom_expr [48743,48781]
atom_expr [48743,48781]
===
match
---
operator: = [69317,69318]
operator: = [69451,69452]
===
match
---
name: property [28075,28083]
name: property [28075,28083]
===
match
---
name: _handle_reschedule [55032,55050]
name: _handle_reschedule [55032,55050]
===
match
---
atom_expr [53780,54211]
atom_expr [53780,54211]
===
match
---
operator: = [77690,77691]
operator: = [77824,77825]
===
match
---
atom_expr [34635,34660]
atom_expr [34635,34660]
===
match
---
name: task_type [56768,56777]
name: task_type [56902,56911]
===
match
---
operator: = [10045,10046]
operator: = [10045,10046]
===
match
---
name: state [13136,13141]
name: state [13136,13141]
===
match
---
name: schedulable_ti [47412,47426]
name: schedulable_ti [47412,47426]
===
match
---
trailer [29513,29519]
trailer [29513,29519]
===
match
---
operator: , [77492,77493]
operator: , [77626,77627]
===
match
---
trailer [52291,52307]
trailer [52291,52307]
===
match
---
comparison [59498,59516]
comparison [59632,59650]
===
match
---
decorators [41524,41567]
decorators [41524,41567]
===
match
---
name: refresh_from_db [43998,44013]
name: refresh_from_db [43998,44013]
===
match
---
trailer [32751,32758]
trailer [32751,32758]
===
match
---
operator: = [15956,15957]
operator: = [15956,15957]
===
match
---
name: ignore_all_deps [15671,15686]
name: ignore_all_deps [15671,15686]
===
match
---
operator: = [21048,21049]
operator: = [21048,21049]
===
match
---
name: strftime [60649,60657]
name: strftime [60783,60791]
===
match
---
atom_expr [33612,33627]
atom_expr [33612,33627]
===
match
---
name: execution_date [32950,32964]
name: execution_date [32950,32964]
===
match
---
name: pod_override_object [68526,68545]
name: pod_override_object [68660,68679]
===
match
---
trailer [3717,3725]
trailer [3717,3725]
===
match
---
name: key [73983,73986]
name: key [74117,74120]
===
match
---
simple_stmt [1118,1149]
simple_stmt [1118,1149]
===
match
---
atom_expr [44528,44538]
atom_expr [44528,44538]
===
match
---
atom_expr [27115,27157]
atom_expr [27115,27157]
===
match
---
argument [10074,10088]
argument [10074,10088]
===
match
---
name: dirname [70858,70865]
name: dirname [70992,70999]
===
match
---
name: use_default [69190,69201]
name: use_default [69324,69335]
===
match
---
atom_expr [68861,68904]
atom_expr [68995,69038]
===
match
---
param [32270,32287]
param [32270,32287]
===
match
---
string: """Prepare Task for Execution""" [48053,48085]
string: """Prepare Task for Execution""" [48053,48085]
===
match
---
operator: , [59631,59632]
operator: , [59765,59766]
===
match
---
name: get [19583,19586]
name: get [19583,19586]
===
match
---
name: self [40151,40155]
name: self [40151,40155]
===
match
---
return_stmt [29635,29695]
return_stmt [29635,29695]
===
match
---
name: duration [22064,22072]
name: duration [22064,22072]
===
match
---
name: self [50047,50051]
name: self [50047,50051]
===
match
---
trailer [80419,80427]
trailer [80553,80561]
===
match
---
trailer [57973,57979]
trailer [58107,58113]
===
match
---
atom_expr [47310,47341]
atom_expr [47310,47341]
===
match
---
name: TaskInstance [20408,20420]
name: TaskInstance [20408,20420]
===
match
---
argument [49445,49460]
argument [49445,49460]
===
match
---
name: execution_date [27142,27156]
name: execution_date [27142,27156]
===
match
---
name: context [48765,48772]
name: context [48765,48772]
===
match
---
trailer [24997,25006]
trailer [24997,25006]
===
match
---
lambdef [5114,5138]
lambdef [5114,5138]
===
match
---
name: self [48625,48629]
name: self [48625,48629]
===
match
---
trailer [5256,5265]
trailer [5256,5265]
===
match
---
atom [35325,35487]
atom [35325,35487]
===
match
---
decorator [80685,80695]
decorator [80819,80829]
===
match
---
name: inlets [64611,64617]
name: inlets [64745,64751]
===
match
---
name: Column [10321,10327]
name: Column [10321,10327]
===
match
---
simple_stmt [8194,8249]
simple_stmt [8194,8249]
===
match
---
name: defaultdict [5082,5093]
name: defaultdict [5082,5093]
===
match
---
suite [54788,55002]
suite [54788,55002]
===
match
---
atom [46945,47116]
atom [46945,47116]
===
match
---
suite [35091,35507]
suite [35091,35507]
===
match
---
simple_stmt [13297,13322]
simple_stmt [13297,13322]
===
match
---
name: dag_id [76189,76195]
name: dag_id [76323,76329]
===
match
---
parameters [32875,32881]
parameters [32875,32881]
===
match
---
name: date [41399,41403]
name: date [41399,41403]
===
match
---
name: try_number [40156,40166]
name: try_number [40156,40166]
===
match
---
name: self [25026,25030]
name: self [25026,25030]
===
match
---
number: 1 [37777,37778]
number: 1 [37777,37778]
===
match
---
name: Optional [72969,72977]
name: Optional [73103,73111]
===
match
---
name: ts_nodash [61909,61918]
name: ts_nodash [62043,62052]
===
match
---
name: debug [22866,22871]
name: debug [22866,22871]
===
match
---
expr_stmt [55814,55835]
expr_stmt [55814,55835]
===
match
---
operator: @ [12652,12653]
operator: @ [12652,12653]
===
match
---
name: timeout [2844,2851]
name: timeout [2844,2851]
===
match
---
trailer [5173,5179]
trailer [5173,5179]
===
match
---
name: Variable [64284,64292]
name: Variable [64418,64426]
===
match
---
name: deserialize_model_file [68732,68754]
name: deserialize_model_file [68866,68888]
===
match
---
dotted_name [1833,1852]
dotted_name [1833,1852]
===
match
---
param [56022,56027]
param [56022,56027]
===
match
---
name: verbose [53369,53376]
name: verbose [53369,53376]
===
match
---
operator: , [55074,55075]
operator: , [55074,55075]
===
match
---
name: task [62269,62273]
name: task [62403,62407]
===
match
---
name: session [45710,45717]
name: session [45710,45717]
===
match
---
param [62817,62822]
param [62951,62956]
===
match
---
trailer [77580,77582]
trailer [77714,77716]
===
match
---
trailer [54886,54908]
trailer [54886,54908]
===
match
---
operator: , [40206,40207]
operator: , [40206,40207]
===
match
---
operator: = [35959,35960]
operator: = [35959,35960]
===
match
---
fstring_end: ' [50579,50580]
fstring_end: ' [50579,50580]
===
match
---
simple_stmt [10881,11071]
simple_stmt [10881,11071]
===
match
---
operator: @ [26422,26423]
operator: @ [26422,26423]
===
match
---
operator: , [10617,10618]
operator: , [10617,10618]
===
match
---
trailer [48190,48212]
trailer [48190,48212]
===
match
---
name: Stats [48661,48666]
name: Stats [48661,48666]
===
match
---
simple_stmt [7198,7251]
simple_stmt [7198,7251]
===
match
---
trailer [71295,71540]
trailer [71429,71674]
===
match
---
name: Session [73013,73020]
name: Session [73147,73154]
===
match
---
trailer [44649,44686]
trailer [44649,44686]
===
match
---
name: mark_success [54368,54380]
name: mark_success [54368,54380]
===
match
---
name: mark_success [15059,15071]
name: mark_success [15059,15071]
===
match
---
atom_expr [48410,48429]
atom_expr [48410,48429]
===
match
---
trailer [5215,5222]
trailer [5215,5222]
===
match
---
name: _end_date [79763,79772]
name: _end_date [79897,79906]
===
match
---
operator: , [46769,46770]
operator: , [46769,46770]
===
match
---
simple_stmt [862,872]
simple_stmt [862,872]
===
match
---
name: base_job [7330,7338]
name: base_job [7330,7338]
===
match
---
suite [45917,47629]
suite [45917,47629]
===
match
---
trailer [61203,61224]
trailer [61337,61358]
===
match
---
atom_expr [23437,23453]
atom_expr [23437,23453]
===
match
---
argument [48765,48780]
argument [48765,48780]
===
match
---
trailer [7213,7223]
trailer [7213,7223]
===
match
---
trailer [9873,9882]
trailer [9873,9882]
===
match
---
argument [39690,39721]
argument [39690,39721]
===
match
---
name: pid [40774,40777]
name: pid [40774,40777]
===
match
---
param [35975,35988]
param [35975,35988]
===
match
---
name: str [18219,18222]
name: str [18219,18222]
===
match
---
name: ti [6114,6116]
name: ti [6114,6116]
===
match
---
name: verbose_aware_logger [31873,31893]
name: verbose_aware_logger [31873,31893]
===
match
---
name: next_execution_date [64762,64781]
name: next_execution_date [64896,64915]
===
match
---
simple_stmt [28523,28553]
simple_stmt [28523,28553]
===
match
---
param [15864,15896]
param [15864,15896]
===
match
---
name: task [5417,5421]
name: task [5417,5421]
===
match
---
atom_expr [30151,30201]
atom_expr [30151,30201]
===
match
---
operator: , [68785,68786]
operator: , [68919,68920]
===
match
---
name: ti [79245,79247]
name: ti [79379,79381]
===
match
---
fstring_start: f" [49249,49251]
fstring_start: f" [49249,49251]
===
match
---
atom [18367,18392]
atom [18367,18392]
===
match
---
trailer [18752,18777]
trailer [18752,18777]
===
match
---
operator: = [52714,52715]
operator: = [52714,52715]
===
match
---
simple_stmt [31846,31860]
simple_stmt [31846,31860]
===
match
---
trailer [50719,50724]
trailer [50719,50724]
===
match
---
atom_expr [52693,52713]
atom_expr [52693,52713]
===
match
---
name: session [55339,55346]
name: session [55339,55346]
===
match
---
name: RenderedTaskInstanceFields [67078,67104]
name: RenderedTaskInstanceFields [67212,67238]
===
match
---
name: session [30185,30192]
name: session [30185,30192]
===
match
---
atom_expr [64606,64617]
atom_expr [64740,64751]
===
match
---
suite [72661,72740]
suite [72795,72874]
===
match
---
dotted_name [2610,2640]
dotted_name [2610,2640]
===
match
---
argument [38351,38384]
argument [38351,38384]
===
match
---
simple_stmt [78082,78103]
simple_stmt [78216,78237]
===
match
---
parameters [8341,8347]
parameters [8341,8347]
===
match
---
name: TR [6843,6845]
name: TR [6843,6845]
===
match
---
name: debug [29514,29519]
name: debug [29514,29519]
===
match
---
atom_expr [55396,55405]
atom_expr [55396,55405]
===
match
---
name: self [59741,59745]
name: self [59875,59879]
===
match
---
suite [63924,63962]
suite [64058,64096]
===
match
---
name: self [59381,59385]
name: self [59515,59519]
===
match
---
name: query [23902,23907]
name: query [23902,23907]
===
match
---
name: max_tries [71498,71507]
name: max_tries [71632,71641]
===
match
---
operator: , [58458,58459]
operator: , [58592,58593]
===
match
---
name: task_id [8057,8064]
name: task_id [8057,8064]
===
match
---
atom_expr [32410,32426]
atom_expr [32410,32426]
===
match
---
name: with_entities [77037,77050]
name: with_entities [77171,77184]
===
match
---
name: Index [10627,10632]
name: Index [10627,10632]
===
match
---
name: self [32968,32972]
name: self [32968,32972]
===
match
---
operator: @ [50628,50629]
operator: @ [50628,50629]
===
match
---
simple_stmt [4050,4067]
simple_stmt [4050,4067]
===
match
---
trailer [71592,71594]
trailer [71726,71728]
===
match
---
trailer [30533,30775]
trailer [30533,30775]
===
match
---
name: self [33853,33857]
name: self [33853,33857]
===
match
---
atom_expr [66304,66341]
atom_expr [66438,66475]
===
match
---
if_stmt [82224,82585]
if_stmt [82358,82719]
===
match
---
atom_expr [10182,10194]
atom_expr [10182,10194]
===
match
---
name: jinja2 [70783,70789]
name: jinja2 [70917,70923]
===
match
---
operator: -> [8348,8350]
operator: -> [8348,8350]
===
match
---
operator: , [68251,68252]
operator: , [68385,68386]
===
match
---
name: delay_backoff_in_seconds [34477,34501]
name: delay_backoff_in_seconds [34477,34501]
===
match
---
suite [44760,44848]
suite [44760,44848]
===
match
---
argument [28031,28046]
argument [28031,28046]
===
match
---
parameters [81107,81113]
parameters [81241,81247]
===
match
---
name: ti [5213,5215]
name: ti [5213,5215]
===
match
---
name: str [24423,24426]
name: str [24423,24426]
===
match
---
simple_stmt [10126,10160]
simple_stmt [10126,10160]
===
match
---
name: utcnow [38977,38983]
name: utcnow [38977,38983]
===
match
---
name: conf [19289,19293]
name: conf [19289,19293]
===
match
---
trailer [52226,52231]
trailer [52226,52231]
===
match
---
string: '-' [62006,62009]
string: '-' [62140,62143]
===
match
---
operator: } [32978,32979]
operator: } [32978,32979]
===
match
---
trailer [50568,50578]
trailer [50568,50578]
===
match
---
operator: , [49807,49808]
operator: , [49807,49808]
===
match
---
name: dagrun [35265,35271]
name: dagrun [35265,35271]
===
match
---
name: PodGenerator [3113,3125]
name: PodGenerator [3113,3125]
===
match
---
atom_expr [47870,47881]
atom_expr [47870,47881]
===
match
---
name: os [40780,40782]
name: os [40780,40782]
===
match
---
trailer [10220,10233]
trailer [10220,10233]
===
match
---
simple_stmt [7456,7483]
simple_stmt [7456,7483]
===
match
---
param [35939,35966]
param [35939,35966]
===
match
---
trailer [41483,41500]
trailer [41483,41500]
===
match
---
operator: @ [8316,8317]
operator: @ [8316,8317]
===
match
---
expr_stmt [7198,7250]
expr_stmt [7198,7250]
===
match
---
import_from [2991,3063]
import_from [2991,3063]
===
match
---
operator: , [74423,74424]
operator: , [74557,74558]
===
match
---
return_stmt [80481,80501]
return_stmt [80615,80635]
===
match
---
name: TaskInstance [81854,81866]
name: TaskInstance [81988,82000]
===
match
---
name: _pool [80973,80978]
name: _pool [81107,81112]
===
match
---
name: args [68485,68489]
name: args [68619,68623]
===
match
---
name: String [9780,9786]
name: String [9780,9786]
===
match
---
sync_comp_for [76933,76956]
sync_comp_for [77067,77090]
===
match
---
operator: = [14627,14628]
operator: = [14627,14628]
===
match
---
trailer [73896,73933]
trailer [74030,74067]
===
match
---
simple_stmt [6050,6126]
simple_stmt [6050,6126]
===
match
---
param [3919,3932]
param [3919,3932]
===
match
---
name: provide_session [74190,74205]
name: provide_session [74324,74339]
===
match
---
string: '<br>' [69284,69290]
string: '<br>' [69418,69424]
===
match
---
simple_stmt [50809,50845]
simple_stmt [50809,50845]
===
match
---
name: getattr [59456,59463]
name: getattr [59590,59597]
===
match
---
raise_stmt [66559,66934]
raise_stmt [66693,67068]
===
match
---
name: self [79887,79891]
name: self [80021,80025]
===
match
---
return_stmt [80408,80427]
return_stmt [80542,80561]
===
match
---
trailer [68899,68904]
trailer [69033,69038]
===
match
---
param [64026,64036]
param [64160,64170]
===
match
---
atom_expr [80899,80910]
atom_expr [81033,81044]
===
match
---
name: dag_run [60995,61002]
name: dag_run [61129,61136]
===
match
---
name: warn [28796,28800]
name: warn [28796,28800]
===
match
---
name: AirflowSkipException [43243,43263]
name: AirflowSkipException [43243,43263]
===
match
---
name: Any [79910,79913]
name: Any [80044,80047]
===
match
---
operator: = [9808,9809]
operator: = [9808,9809]
===
match
---
name: self [80824,80828]
name: self [80958,80962]
===
match
---
operator: , [79541,79542]
operator: , [79675,79676]
===
match
---
argument [54102,54121]
argument [54102,54121]
===
match
---
param [67546,67551]
param [67680,67685]
===
match
---
operator: = [5249,5250]
operator: = [5249,5250]
===
match
---
name: incr [44883,44887]
name: incr [44883,44887]
===
match
---
dotted_name [2257,2284]
dotted_name [2257,2284]
===
match
---
trailer [25942,25947]
trailer [25942,25947]
===
match
---
return_stmt [27226,27237]
return_stmt [27226,27237]
===
match
---
name: try_number [6860,6870]
name: try_number [6860,6870]
===
match
---
tfpdef [77770,77823]
tfpdef [77904,77957]
===
match
---
name: reschedule_exception [43959,43979]
name: reschedule_exception [43959,43979]
===
match
---
argument [50502,50515]
argument [50502,50515]
===
match
---
operator: } [42841,42842]
operator: } [42841,42842]
===
match
---
decorator [77733,77747]
decorator [77867,77881]
===
match
---
name: self [39105,39109]
name: self [39105,39109]
===
match
---
name: Union [1112,1117]
name: Union [1112,1117]
===
match
---
name: e [66540,66541]
name: e [66674,66675]
===
match
---
name: render_templates [48748,48764]
name: render_templates [48748,48764]
===
match
---
name: task_copy [51265,51274]
name: task_copy [51265,51274]
===
match
---
trailer [40738,40744]
trailer [40738,40744]
===
match
---
name: dag_id [79089,79095]
name: dag_id [79223,79229]
===
match
---
atom_expr [31624,31636]
atom_expr [31624,31636]
===
match
---
trailer [5937,5976]
trailer [5937,5976]
===
match
---
name: delay [33581,33586]
name: delay [33581,33586]
===
match
---
trailer [40356,40362]
trailer [40356,40362]
===
match
---
name: ValueError [73759,73769]
name: ValueError [73893,73903]
===
match
---
trailer [47398,47402]
trailer [47398,47402]
===
match
---
name: run_id [65320,65326]
name: run_id [65454,65460]
===
match
---
name: start_date [7922,7932]
name: start_date [7922,7932]
===
match
---
name: models [1902,1908]
name: models [1902,1908]
===
match
---
atom_expr [47513,47594]
atom_expr [47513,47594]
===
match
---
not_test [25363,25389]
not_test [25363,25389]
===
match
---
trailer [57987,58000]
trailer [58121,58134]
===
match
---
param [51881,51885]
param [51881,51885]
===
match
---
expr_stmt [61799,61859]
expr_stmt [61933,61993]
===
match
---
operator: = [71018,71019]
operator: = [71152,71153]
===
match
---
name: execution_date [24044,24058]
name: execution_date [24044,24058]
===
match
---
operator: , [1683,1684]
operator: , [1683,1684]
===
match
---
string: """         Construct a TaskInstance from the database based on the primary key          :param session: DB session.         :param lock_for_update: if True, indicates that the database should             lock the TaskInstance (issuing a FOR UPDATE clause) until the             session is committed.         :return: the task instance constructed         """ [81432,81791]
string: """         Construct a TaskInstance from the database based on the primary key          :param session: DB session.         :param lock_for_update: if True, indicates that the database should             lock the TaskInstance (issuing a FOR UPDATE clause) until the             session is committed.         :return: the task instance constructed         """ [81566,81925]
===
match
---
suite [27753,27834]
suite [27753,27834]
===
match
---
trailer [45005,45012]
trailer [45005,45012]
===
match
---
decorator [19145,19155]
decorator [19145,19155]
===
match
---
except_clause [67310,67362]
except_clause [67444,67496]
===
match
---
operator: , [54488,54489]
operator: , [54488,54489]
===
match
---
parameters [23647,23667]
parameters [23647,23667]
===
match
---
name: partial_dag [46536,46547]
name: partial_dag [46536,46547]
===
match
---
simple_stmt [8057,8070]
simple_stmt [8057,8070]
===
match
---
trailer [52212,52216]
trailer [52212,52216]
===
match
---
suite [34792,35019]
suite [34792,35019]
===
match
---
trailer [47517,47521]
trailer [47517,47521]
===
match
---
operator: , [22899,22900]
operator: , [22899,22900]
===
match
---
trailer [54991,54999]
trailer [54991,54999]
===
match
---
name: session [74157,74164]
name: session [74291,74298]
===
match
---
argument [29597,29608]
argument [29597,29608]
===
match
---
atom_expr [23379,23399]
atom_expr [23379,23399]
===
match
---
trailer [18814,18821]
trailer [18814,18821]
===
match
---
name: self [81176,81180]
name: self [81310,81314]
===
match
---
simple_stmt [76710,76875]
simple_stmt [76844,77009]
===
match
---
name: self [8521,8525]
name: self [8521,8525]
===
match
---
operator: = [38140,38141]
operator: = [38140,38141]
===
match
---
name: result [50361,50367]
name: result [50361,50367]
===
match
---
operator: } [44912,44913]
operator: } [44912,44913]
===
match
---
name: bool [35810,35814]
name: bool [35810,35814]
===
match
---
expr_stmt [61155,61224]
expr_stmt [61289,61358]
===
match
---
name: dep_context [32410,32421]
name: dep_context [32410,32421]
===
match
---
trailer [60537,60552]
trailer [60671,60686]
===
match
---
operator: -> [56212,56214]
operator: -> [56212,56214]
===
match
---
simple_stmt [12696,12953]
simple_stmt [12696,12953]
===
match
---
import_from [45834,45874]
import_from [45834,45874]
===
match
---
expr_stmt [61033,61074]
expr_stmt [61167,61208]
===
match
---
simple_stmt [24993,25059]
simple_stmt [24993,25059]
===
match
---
for_stmt [7855,7953]
for_stmt [7855,7953]
===
match
---
name: tomorrow_ds [60598,60609]
name: tomorrow_ds [60732,60743]
===
match
---
arglist [9549,9599]
arglist [9549,9599]
===
match
---
trailer [10181,10195]
trailer [10181,10195]
===
match
---
operator: , [43849,43850]
operator: , [43849,43850]
===
match
---
name: hr_line_break [40259,40272]
name: hr_line_break [40259,40272]
===
match
---
name: downstream_task_ids [47079,47098]
name: downstream_task_ids [47079,47098]
===
match
---
return_stmt [32891,32982]
return_stmt [32891,32982]
===
match
---
arglist [22872,22905]
arglist [22872,22905]
===
match
---
and_test [51695,51740]
and_test [51695,51740]
===
match
---
atom_expr [68333,68345]
atom_expr [68467,68479]
===
match
---
trailer [43393,43398]
trailer [43393,43398]
===
match
---
simple_stmt [2722,2787]
simple_stmt [2722,2787]
===
match
---
name: self [44177,44181]
name: self [44177,44181]
===
match
---
name: get_rendered_template_fields [65953,65981]
name: get_rendered_template_fields [66087,66115]
===
match
---
name: dag_id [8041,8047]
name: dag_id [8041,8047]
===
match
---
name: full_filepath [14813,14826]
name: full_filepath [14813,14826]
===
match
---
trailer [24955,24964]
trailer [24955,24964]
===
match
---
fstring_string: / [19099,19100]
fstring_string: / [19099,19100]
===
match
---
trailer [10686,10705]
trailer [10686,10705]
===
match
---
string: 'TaskInstanceKey' [8351,8368]
string: 'TaskInstanceKey' [8351,8368]
===
match
---
operator: , [63086,63087]
operator: , [63220,63221]
===
match
---
name: test_mode [40665,40674]
name: test_mode [40665,40674]
===
match
---
trailer [76240,76461]
trailer [76374,76595]
===
match
---
import_from [1889,1923]
import_from [1889,1923]
===
match
---
simple_stmt [82534,82585]
simple_stmt [82668,82719]
===
match
---
name: context [49105,49112]
name: context [49105,49112]
===
match
---
simple_stmt [81800,82017]
simple_stmt [81934,82151]
===
match
---
operator: = [56176,56177]
operator: = [56176,56177]
===
match
---
string: 'ti_dag_state' [10587,10601]
string: 'ti_dag_state' [10587,10601]
===
match
---
atom_expr [52785,52795]
atom_expr [52785,52795]
===
match
---
operator: = [43085,43086]
operator: = [43085,43086]
===
match
---
param [33012,33016]
param [33012,33016]
===
match
---
name: ti [47153,47155]
name: ti [47153,47155]
===
match
---
trailer [6970,6972]
trailer [6970,6972]
===
match
---
name: self [38419,38423]
name: self [38419,38423]
===
match
---
trailer [61720,61732]
trailer [61854,61866]
===
match
---
name: total_seconds [34535,34548]
name: total_seconds [34535,34548]
===
match
---
operator: = [27305,27306]
operator: = [27305,27306]
===
match
---
trailer [54628,54634]
trailer [54628,54634]
===
match
---
name: res [54227,54230]
name: res [54227,54230]
===
match
---
operator: = [15654,15655]
operator: = [15654,15655]
===
match
---
atom_expr [79994,80020]
atom_expr [80128,80154]
===
match
---
arglist [41374,41384]
arglist [41374,41384]
===
match
---
tfpdef [15635,15653]
tfpdef [15635,15653]
===
match
---
expr_stmt [76189,76209]
expr_stmt [76323,76343]
===
match
---
if_stmt [56349,56627]
if_stmt [56349,56761]
===
match
---
name: jinja_env [71842,71851]
name: jinja_env [71976,71985]
===
match
---
atom_expr [62230,62241]
atom_expr [62364,62375]
===
match
---
operator: = [23400,23401]
operator: = [23400,23401]
===
match
---
operator: , [65705,65706]
operator: , [65839,65840]
===
match
---
name: RenderedTaskInstanceFields [66094,66120]
name: RenderedTaskInstanceFields [66228,66254]
===
match
---
if_stmt [18097,18164]
if_stmt [18097,18164]
===
match
---
param [14244,14256]
param [14244,14256]
===
match
---
name: self [46092,46096]
name: self [46092,46096]
===
match
---
param [53599,53623]
param [53599,53623]
===
match
---
name: end_date [57006,57014]
name: end_date [57140,57148]
===
match
---
name: pendulum [61821,61829]
name: pendulum [61955,61963]
===
match
---
simple_stmt [69238,69292]
simple_stmt [69372,69426]
===
match
---
operator: == [20436,20438]
operator: == [20436,20438]
===
match
---
strings [73787,73889]
strings [73921,74023]
===
match
---
atom_expr [43513,43526]
atom_expr [43513,43526]
===
match
---
operator: , [23652,23653]
operator: , [23652,23653]
===
match
---
operator: , [15267,15268]
operator: , [15267,15268]
===
match
---
operator: = [41804,41805]
operator: = [41804,41805]
===
match
---
parameters [51055,51081]
parameters [51055,51081]
===
match
---
operator: = [59176,59177]
operator: = [59310,59311]
===
match
---
operator: , [4452,4453]
operator: , [4452,4453]
===
match
---
operator: } [76873,76874]
operator: } [77007,77008]
===
match
---
trailer [80750,80760]
trailer [80884,80894]
===
match
---
atom_expr [68273,68285]
atom_expr [68407,68419]
===
match
---
name: _executor_config [79892,79908]
name: _executor_config [80026,80042]
===
match
---
name: context [67946,67953]
name: context [68080,68087]
===
match
---
name: key [74397,74400]
name: key [74531,74534]
===
match
---
decorated [23607,24148]
decorated [23607,24148]
===
match
---
simple_stmt [4022,4046]
simple_stmt [4022,4046]
===
match
---
name: pool [80098,80102]
name: pool [80232,80236]
===
match
---
number: 1 [5595,5596]
number: 1 [5595,5596]
===
match
---
name: self [11287,11291]
name: self [11287,11291]
===
match
---
string: "%s. State set to NONE." [40105,40129]
string: "%s. State set to NONE." [40105,40129]
===
match
---
name: ti [22669,22671]
name: ti [22669,22671]
===
match
---
expr_stmt [9460,9528]
expr_stmt [9460,9528]
===
match
---
name: property [18873,18881]
name: property [18873,18881]
===
match
---
operator: , [72431,72432]
operator: , [72565,72566]
===
match
---
fstring_start: f" [47820,47822]
fstring_start: f" [47820,47822]
===
match
---
name: task [37408,37412]
name: task [37408,37412]
===
match
---
trailer [66188,66209]
trailer [66322,66343]
===
match
---
param [8150,8154]
param [8150,8154]
===
match
---
simple_stmt [37742,37783]
simple_stmt [37742,37783]
===
match
---
operator: , [26194,26195]
operator: , [26194,26195]
===
match
---
name: test_mode [54102,54111]
name: test_mode [54102,54111]
===
match
---
name: TR [39078,39080]
name: TR [39078,39080]
===
match
---
decorator [15472,15486]
decorator [15472,15486]
===
match
---
name: ti_hash [34079,34086]
name: ti_hash [34079,34086]
===
match
---
name: prev_execution_date [61692,61711]
name: prev_execution_date [61826,61845]
===
match
---
if_stmt [14659,14903]
if_stmt [14659,14903]
===
match
---
trailer [38578,38580]
trailer [38578,38580]
===
match
---
name: self [33805,33809]
name: self [33805,33809]
===
match
---
fstring_string: ?task_id= [19677,19686]
fstring_string: ?task_id= [19677,19686]
===
match
---
name: os [49331,49333]
name: os [49331,49333]
===
match
---
trailer [23938,23945]
trailer [23938,23945]
===
match
---
operator: = [22841,22842]
operator: = [22841,22842]
===
match
---
atom_expr [60612,60669]
atom_expr [60746,60803]
===
match
---
trailer [40469,40473]
trailer [40469,40473]
===
match
---
atom [19638,19847]
atom [19638,19847]
===
match
---
operator: , [35965,35966]
operator: , [35965,35966]
===
match
---
atom_expr [38419,38546]
atom_expr [38419,38546]
===
match
---
name: delete [54307,54313]
name: delete [54307,54313]
===
match
---
operator: = [39814,39815]
operator: = [39814,39815]
===
match
---
operator: = [62764,62765]
operator: = [62898,62899]
===
match
---
name: filter_by [46050,46059]
name: filter_by [46050,46059]
===
match
---
tfpdef [35066,35082]
tfpdef [35066,35082]
===
match
---
operator: , [68471,68472]
operator: , [68605,68606]
===
match
---
atom_expr [41011,41036]
atom_expr [41011,41036]
===
match
---
name: session [25067,25074]
name: session [25067,25074]
===
match
---
atom_expr [7742,7802]
atom_expr [7742,7802]
===
match
---
fstring_start: f" [19675,19677]
fstring_start: f" [19675,19677]
===
match
---
name: email [72515,72520]
name: email [72649,72654]
===
match
---
simple_stmt [80817,80841]
simple_stmt [80951,80975]
===
match
---
name: hasattr [41366,41373]
name: hasattr [41366,41373]
===
match
---
trailer [82546,82560]
trailer [82680,82694]
===
match
---
atom_expr [35381,35394]
atom_expr [35381,35394]
===
match
---
decorated [81084,81149]
decorated [81218,81283]
===
match
---
trailer [59344,59349]
trailer [59478,59483]
===
match
---
name: set [5134,5137]
name: set [5134,5137]
===
match
---
and_test [29642,29695]
and_test [29642,29695]
===
match
---
name: context [49540,49547]
name: context [49540,49547]
===
match
---
name: TaskInstanceKey [7961,7976]
name: TaskInstanceKey [7961,7976]
===
match
---
param [29759,29764]
param [29759,29764]
===
match
---
trailer [3945,3968]
trailer [3945,3968]
===
match
---
string: "Clearing XCom data" [23864,23884]
string: "Clearing XCom data" [23864,23884]
===
match
---
comparison [78723,78741]
comparison [78857,78875]
===
match
---
argument [68703,68785]
argument [68837,68919]
===
match
---
operator: , [32639,32640]
operator: , [32639,32640]
===
match
---
trailer [53095,53113]
trailer [53095,53113]
===
match
---
trailer [42817,42859]
trailer [42817,42859]
===
match
---
trailer [45603,45612]
trailer [45603,45612]
===
match
---
atom_expr [79165,79192]
atom_expr [79299,79326]
===
match
---
operator: = [51580,51581]
operator: = [51580,51581]
===
match
---
expr_stmt [61340,61361]
expr_stmt [61474,61495]
===
match
---
name: html_content [71005,71017]
name: html_content [71139,71151]
===
match
---
simple_stmt [30520,30776]
simple_stmt [30520,30776]
===
match
---
operator: = [10255,10256]
operator: = [10255,10256]
===
match
---
operator: , [67558,67559]
operator: , [67692,67693]
===
match
---
import_from [1507,1560]
import_from [1507,1560]
===
match
---
name: self [67977,67981]
name: self [68111,68115]
===
match
---
trailer [69258,69269]
trailer [69392,69403]
===
match
---
trailer [81292,81309]
trailer [81426,81443]
===
match
---
trailer [8738,8798]
trailer [8738,8798]
===
match
---
name: self [60423,60427]
name: self [60557,60561]
===
match
---
name: first [21890,21895]
name: first [21890,21895]
===
match
---
name: session [24428,24435]
name: session [24428,24435]
===
match
---
name: self [12370,12374]
name: self [12370,12374]
===
match
---
atom_expr [21619,21638]
atom_expr [21619,21638]
===
match
---
import_from [1217,1274]
import_from [1217,1274]
===
match
---
name: self [72901,72905]
name: self [73035,73039]
===
match
---
name: max_tries [22378,22387]
name: max_tries [22378,22387]
===
match
---
name: fd [4406,4408]
name: fd [4406,4408]
===
match
---
expr_stmt [39446,39736]
expr_stmt [39446,39736]
===
match
---
simple_stmt [9460,9529]
simple_stmt [9460,9529]
===
match
---
operator: = [22541,22542]
operator: = [22541,22542]
===
match
---
argument [9511,9527]
argument [9511,9527]
===
match
---
argument [43070,43090]
argument [43070,43090]
===
match
---
operator: = [79362,79363]
operator: = [79496,79497]
===
match
---
expr_stmt [42554,42580]
expr_stmt [42554,42580]
===
match
---
trailer [18061,18068]
trailer [18061,18068]
===
match
---
expr_stmt [42721,42751]
expr_stmt [42721,42751]
===
match
---
dotted_name [2677,2698]
dotted_name [2677,2698]
===
match
---
simple_stmt [68845,68905]
simple_stmt [68979,69039]
===
match
---
trailer [22077,22086]
trailer [22077,22086]
===
match
---
fstring_string: __ [62203,62205]
fstring_string: __ [62337,62339]
===
match
---
comp_op [27649,27655]
comp_op [27649,27655]
===
match
---
name: self [53355,53359]
name: self [53355,53359]
===
match
---
name: self [57638,57642]
name: self [57772,57776]
===
match
---
expr_stmt [14606,14650]
expr_stmt [14606,14650]
===
match
---
name: dagrun [45854,45860]
name: dagrun [45854,45860]
===
match
---
name: queued_dttm [40295,40306]
name: queued_dttm [40295,40306]
===
match
---
expr_stmt [26859,26896]
expr_stmt [26859,26896]
===
match
---
name: start_date [50814,50824]
name: start_date [50814,50824]
===
match
---
simple_stmt [13172,13196]
simple_stmt [13172,13196]
===
match
---
name: info [40474,40478]
name: info [40474,40478]
===
match
---
name: property [81155,81163]
name: property [81289,81297]
===
match
---
trailer [7830,7834]
trailer [7830,7834]
===
match
---
name: Exception [58959,58968]
name: Exception [59093,59102]
===
match
---
trailer [20314,20321]
trailer [20314,20321]
===
match
---
trailer [71926,71963]
trailer [72060,72097]
===
match
---
operator: = [29574,29575]
operator: = [29574,29575]
===
match
---
trailer [32388,32390]
trailer [32388,32390]
===
match
---
name: render [71873,71879]
name: render [72007,72013]
===
match
---
atom_expr [3232,3245]
atom_expr [3232,3245]
===
match
---
name: models [7539,7545]
name: models [7539,7545]
===
match
---
operator: = [77628,77629]
operator: = [77762,77763]
===
match
---
and_test [14662,14720]
and_test [14662,14720]
===
match
---
name: dag_run [67646,67653]
name: dag_run [67780,67787]
===
match
---
name: ignore_depends_on_past [18405,18427]
name: ignore_depends_on_past [18405,18427]
===
match
---
funcdef [19874,20610]
funcdef [19874,20610]
===
match
---
atom_expr [4057,4066]
atom_expr [4057,4066]
===
match
---
atom_expr [48520,48534]
atom_expr [48520,48534]
===
match
---
number: 1 [8567,8568]
number: 1 [8567,8568]
===
match
---
name: dag [5378,5381]
name: dag [5378,5381]
===
match
---
atom [3248,3250]
atom [3248,3250]
===
match
---
trailer [74128,74143]
trailer [74262,74277]
===
match
---
name: OperationalError [47648,47664]
name: OperationalError [47648,47664]
===
match
---
atom_expr [33567,33635]
atom_expr [33567,33635]
===
match
---
return_stmt [41509,41518]
return_stmt [41509,41518]
===
match
---
name: dag_id [42835,42841]
name: dag_id [42835,42841]
===
match
---
string: "airflow.task" [11354,11368]
string: "airflow.task" [11354,11368]
===
match
---
import_name [787,804]
import_name [787,804]
===
match
---
arglist [3743,3882]
arglist [3743,3882]
===
match
---
trailer [81061,81078]
trailer [81195,81212]
===
match
---
arglist [21619,21768]
arglist [21619,21768]
===
match
---
atom_expr [8766,8785]
atom_expr [8766,8785]
===
match
---
sync_comp_for [6926,6972]
sync_comp_for [6926,6972]
===
match
---
name: Index [10842,10847]
name: Index [10842,10847]
===
match
---
string: """Log URL for TaskInstance""" [19186,19216]
string: """Log URL for TaskInstance""" [19186,19216]
===
match
---
trailer [4134,4140]
trailer [4134,4140]
===
match
---
name: catchup [27713,27720]
name: catchup [27713,27720]
===
match
---
atom_expr [26272,26326]
atom_expr [26272,26326]
===
match
---
atom_expr [10002,10012]
atom_expr [10002,10012]
===
match
---
simple_stmt [4121,4147]
simple_stmt [4121,4147]
===
match
---
expr_stmt [3214,3250]
expr_stmt [3214,3250]
===
match
---
name: state [30172,30177]
name: state [30172,30177]
===
match
---
trailer [20928,20935]
trailer [20928,20935]
===
match
---
string: 'try_number' [9817,9829]
string: 'try_number' [9817,9829]
===
match
---
simple_stmt [872,886]
simple_stmt [872,886]
===
match
---
simple_stmt [8257,8311]
simple_stmt [8257,8311]
===
match
---
name: Exception [4158,4167]
name: Exception [4158,4167]
===
match
---
name: max_tries [5941,5950]
name: max_tries [5941,5950]
===
match
---
atom_expr [18273,18314]
atom_expr [18273,18314]
===
match
---
name: self [13861,13865]
name: self [13861,13865]
===
match
---
name: test_mode [44796,44805]
name: test_mode [44796,44805]
===
match
---
name: default_html_content [71042,71062]
name: default_html_content [71176,71196]
===
match
---
import_from [1591,1629]
import_from [1591,1629]
===
match
---
trailer [72420,72425]
trailer [72554,72559]
===
match
---
simple_stmt [22786,22804]
simple_stmt [22786,22804]
===
match
---
name: warnings [30520,30528]
name: warnings [30520,30528]
===
match
---
operator: = [77029,77030]
operator: = [77163,77164]
===
match
---
operator: @ [28074,28075]
operator: @ [28074,28075]
===
match
---
name: airflow [67039,67046]
name: airflow [67173,67180]
===
match
---
name: task_id [79126,79133]
name: task_id [79260,79267]
===
match
---
name: ds_nodash [62206,62215]
name: ds_nodash [62340,62349]
===
match
---
trailer [46604,46609]
trailer [46604,46609]
===
match
---
param [72953,72995]
param [73087,73129]
===
match
---
atom_expr [46144,46163]
atom_expr [46144,46163]
===
match
---
trailer [78747,78755]
trailer [78881,78889]
===
match
---
param [35832,35859]
param [35832,35859]
===
match
---
suite [44164,44304]
suite [44164,44304]
===
match
---
name: refresh_from_db [43450,43465]
name: refresh_from_db [43450,43465]
===
match
---
operator: , [14298,14299]
operator: , [14298,14299]
===
match
---
string: "%d downstream tasks scheduled from follow-on schedule check" [47527,47588]
string: "%d downstream tasks scheduled from follow-on schedule check" [47527,47588]
===
match
---
simple_stmt [22287,22361]
simple_stmt [22287,22361]
===
match
---
name: timezone [55251,55259]
name: timezone [55251,55259]
===
match
---
name: self [35436,35440]
name: self [35436,35440]
===
match
---
param [4735,4758]
param [4735,4758]
===
match
---
fstring [50537,50580]
fstring [50537,50580]
===
match
---
atom_expr [22019,22032]
atom_expr [22019,22032]
===
match
---
name: dag_run [60310,60317]
name: dag_run [60444,60451]
===
match
---
name: commit [55881,55887]
name: commit [55881,55887]
===
match
---
string: "Failed when executing execute callback" [52154,52194]
string: "Failed when executing execute callback" [52154,52194]
===
match
---
number: 0 [78100,78101]
number: 0 [78234,78235]
===
match
---
name: prev_ti [30217,30224]
name: prev_ti [30217,30224]
===
match
---
suite [47670,47973]
suite [47670,47973]
===
match
---
atom_expr [51754,51803]
atom_expr [51754,51803]
===
match
---
return_stmt [19081,19139]
return_stmt [19081,19139]
===
match
---
name: dag_id [19106,19112]
name: dag_id [19106,19112]
===
match
---
operator: = [54166,54167]
operator: = [54166,54167]
===
match
---
name: task [23271,23275]
name: task [23271,23275]
===
match
---
atom_expr [72674,72687]
atom_expr [72808,72821]
===
match
---
name: priority_weight [10816,10831]
name: priority_weight [10816,10831]
===
match
---
name: lazy_object_proxy [65184,65201]
name: lazy_object_proxy [65318,65335]
===
match
---
operator: , [9581,9582]
operator: , [9581,9582]
===
match
---
trailer [66457,66474]
trailer [66591,66608]
===
match
---
trailer [5482,5488]
trailer [5482,5488]
===
match
---
operator: { [19129,19130]
operator: { [19129,19130]
===
match
---
name: verbose [53846,53853]
name: verbose [53846,53853]
===
match
---
simple_stmt [56936,57017]
simple_stmt [57070,57151]
===
match
---
decorated [53279,54765]
decorated [53279,54765]
===
match
---
name: Index [10681,10686]
name: Index [10681,10686]
===
match
---
operator: = [70888,70889]
operator: = [71022,71023]
===
match
---
name: queue [81102,81107]
name: queue [81236,81241]
===
match
---
not_test [45537,45550]
not_test [45537,45550]
===
match
---
dotted_name [1512,1535]
dotted_name [1512,1535]
===
match
---
operator: , [62086,62087]
operator: , [62220,62221]
===
match
---
arglist [42612,42636]
arglist [42612,42636]
===
match
---
operator: = [60610,60611]
operator: = [60744,60745]
===
match
---
name: self [68568,68572]
name: self [68702,68706]
===
match
---
name: schedule_tis [47467,47479]
name: schedule_tis [47467,47479]
===
match
---
operator: , [62026,62027]
operator: , [62160,62161]
===
match
---
atom_expr [30229,30266]
atom_expr [30229,30266]
===
match
---
name: sanitized_pod [68920,68933]
name: sanitized_pod [69054,69067]
===
match
---
simple_stmt [12121,12140]
simple_stmt [12121,12140]
===
match
---
operator: , [65653,65654]
operator: , [65787,65788]
===
match
---
atom_expr [5952,5975]
atom_expr [5952,5975]
===
match
---
suite [21086,22907]
suite [21086,22907]
===
match
---
not_test [69204,69229]
not_test [69338,69363]
===
match
---
name: previous_start_date_success [30290,30317]
name: previous_start_date_success [30290,30317]
===
match
---
comparison [78534,78563]
comparison [78668,78697]
===
match
---
name: os [4033,4035]
name: os [4033,4035]
===
match
---
expr_stmt [10277,10298]
expr_stmt [10277,10298]
===
match
---
trailer [14592,14596]
trailer [14592,14596]
===
match
---
atom_expr [40627,40643]
atom_expr [40627,40643]
===
match
---
simple_stmt [41509,41519]
simple_stmt [41509,41519]
===
match
---
name: mark_success_url [19445,19461]
name: mark_success_url [19445,19461]
===
match
---
operator: , [17981,17982]
operator: , [17981,17982]
===
match
---
name: str [15990,15993]
name: str [15990,15993]
===
match
---
trailer [28280,28514]
trailer [28280,28514]
===
match
---
operator: , [53957,53958]
operator: , [53957,53958]
===
match
---
decorated [28558,29092]
decorated [28558,29092]
===
match
---
atom [60612,60648]
atom [60746,60782]
===
match
---
name: ti [21820,21822]
name: ti [21820,21822]
===
match
---
operator: -> [19912,19914]
operator: -> [19912,19914]
===
match
---
name: name [54526,54530]
name: name [54526,54530]
===
match
---
suite [24200,24370]
suite [24200,24370]
===
match
---
simple_stmt [3150,3167]
simple_stmt [3150,3167]
===
match
---
operator: = [73021,73022]
operator: = [73155,73156]
===
match
---
name: self [48857,48861]
name: self [48857,48861]
===
match
---
name: Session [1499,1506]
name: Session [1499,1506]
===
match
---
name: cmd [18686,18689]
name: cmd [18686,18689]
===
match
---
name: task [54845,54849]
name: task [54845,54849]
===
match
---
operator: , [50583,50584]
operator: , [50583,50584]
===
match
---
operator: = [68619,68620]
operator: = [68753,68754]
===
match
---
atom_expr [10321,10353]
atom_expr [10321,10353]
===
match
---
operator: , [20390,20391]
operator: , [20390,20391]
===
match
---
fstring_end: " [47882,47883]
fstring_end: " [47882,47883]
===
match
---
operator: , [1824,1825]
operator: , [1824,1825]
===
match
---
name: log [40595,40598]
name: log [40595,40598]
===
match
---
operator: = [39076,39077]
operator: = [39076,39077]
===
match
---
operator: = [55662,55663]
operator: = [55662,55663]
===
match
---
name: _safe_date [58377,58387]
name: _safe_date [58511,58521]
===
match
---
operator: } [50578,50579]
operator: } [50578,50579]
===
match
---
trailer [15883,15888]
trailer [15883,15888]
===
match
---
trailer [68572,68588]
trailer [68706,68722]
===
match
---
atom_expr [78669,78678]
atom_expr [78803,78812]
===
match
---
name: task [62175,62179]
name: task [62309,62313]
===
match
---
name: primary_key [9583,9594]
name: primary_key [9583,9594]
===
match
---
simple_stmt [5240,5266]
simple_stmt [5240,5266]
===
match
---
argument [59112,59123]
argument [59246,59257]
===
match
---
name: state [27922,27927]
name: state [27922,27927]
===
match
---
name: first_task_id [78759,78772]
name: first_task_id [78893,78906]
===
match
---
name: timedelta [60635,60644]
name: timedelta [60769,60778]
===
match
---
atom_expr [77404,77423]
atom_expr [77538,77557]
===
match
---
string: "execution date %s has no timezone information. Using default from dag or system" [11559,11640]
string: "execution date %s has no timezone information. Using default from dag or system" [11559,11640]
===
match
---
simple_stmt [79758,79797]
simple_stmt [79892,79931]
===
match
---
name: rendered_k8s_spec [67251,67268]
name: rendered_k8s_spec [67385,67402]
===
match
---
simple_stmt [46924,47117]
simple_stmt [46924,47117]
===
match
---
operator: , [10801,10802]
operator: , [10801,10802]
===
match
---
operator: = [10380,10381]
operator: = [10380,10381]
===
match
---
name: Optional [28605,28613]
name: Optional [28605,28613]
===
match
---
atom_expr [46855,46906]
atom_expr [46855,46906]
===
match
---
funcdef [18886,19140]
funcdef [18886,19140]
===
match
---
name: seconds [34586,34593]
name: seconds [34586,34593]
===
match
---
trailer [77416,77423]
trailer [77550,77557]
===
match
---
if_stmt [18172,18233]
if_stmt [18172,18233]
===
match
---
name: exception_html [70612,70626]
name: exception_html [70746,70760]
===
match
---
dotted_name [1894,1912]
dotted_name [1894,1912]
===
match
---
operator: , [56026,56027]
operator: , [56026,56027]
===
match
---
trailer [49607,49609]
trailer [49607,49609]
===
match
---
trailer [46246,46248]
trailer [46246,46248]
===
match
---
suite [67363,67469]
suite [67497,67603]
===
match
---
operator: , [14999,15000]
operator: , [14999,15000]
===
match
---
atom_expr [23337,23352]
atom_expr [23337,23352]
===
match
---
dictorsetmaker [44543,44570]
dictorsetmaker [44543,44570]
===
match
---
operator: = [61631,61632]
operator: = [61765,61766]
===
match
---
expr_stmt [22495,22518]
expr_stmt [22495,22518]
===
match
---
name: airflow [3073,3080]
name: airflow [3073,3080]
===
match
---
atom_expr [61177,61224]
atom_expr [61311,61358]
===
match
---
atom_expr [56043,56064]
atom_expr [56043,56064]
===
match
---
name: var [63957,63960]
name: var [64091,64094]
===
match
---
name: context [3693,3700]
name: context [3693,3700]
===
match
---
suite [49732,49818]
suite [49732,49818]
===
match
---
name: force_fail [57720,57730]
name: force_fail [57854,57864]
===
match
---
trailer [47073,47078]
trailer [47073,47078]
===
match
---
import_from [2933,2986]
import_from [2933,2986]
===
match
---
trailer [30088,30092]
trailer [30088,30092]
===
match
---
trailer [5289,5296]
trailer [5289,5296]
===
match
---
atom_expr [72969,72987]
atom_expr [73103,73121]
===
match
---
name: test_mode [58979,58988]
name: test_mode [59113,59122]
===
match
---
trailer [11170,11172]
trailer [11170,11172]
===
match
---
if_stmt [59495,59558]
if_stmt [59629,59692]
===
match
---
argument [45806,45819]
argument [45806,45819]
===
match
---
operator: @ [41524,41525]
operator: @ [41524,41525]
===
match
---
name: task_copy [51695,51704]
name: task_copy [51695,51704]
===
match
---
name: _date_or_empty [43872,43886]
name: _date_or_empty [43872,43886]
===
match
---
operator: , [35409,35410]
operator: , [35409,35410]
===
match
---
operator: , [28029,28030]
operator: , [28029,28030]
===
match
---
name: cmd [18576,18579]
name: cmd [18576,18579]
===
match
---
name: self [80939,80943]
name: self [81073,81077]
===
match
---
trailer [77379,77386]
trailer [77513,77520]
===
match
---
name: kube_config [2957,2968]
name: kube_config [2957,2968]
===
match
---
or_test [24814,24845]
or_test [24814,24845]
===
match
---
name: loader [70819,70825]
name: loader [70953,70959]
===
match
---
return_stmt [80961,80978]
return_stmt [81095,81112]
===
match
---
trailer [29780,29785]
trailer [29780,29785]
===
match
---
decorator [35512,35529]
decorator [35512,35529]
===
match
---
name: exception [70566,70575]
name: exception [70700,70709]
===
match
---
name: self [50760,50764]
name: self [50760,50764]
===
match
---
operator: , [28997,28998]
operator: , [28997,28998]
===
match
---
decorator [80433,80443]
decorator [80567,80577]
===
match
---
param [25440,25445]
param [25440,25445]
===
match
---
name: filter [26076,26082]
name: filter [26076,26082]
===
match
---
operator: , [63327,63328]
operator: , [63461,63462]
===
match
---
atom_expr [63883,63891]
atom_expr [64017,64025]
===
match
---
trailer [30344,30353]
trailer [30344,30353]
===
match
---
name: SUCCESS [52805,52812]
name: SUCCESS [52805,52812]
===
match
---
name: test_mode [42571,42580]
name: test_mode [42571,42580]
===
match
---
operator: , [9838,9839]
operator: , [9838,9839]
===
match
---
name: logging [11336,11343]
name: logging [11336,11343]
===
match
---
name: ti [47160,47162]
name: ti [47160,47162]
===
match
---
expr_stmt [33553,33635]
expr_stmt [33553,33635]
===
match
---
trailer [24126,24147]
trailer [24126,24147]
===
match
---
name: execution_date [6747,6761]
name: execution_date [6747,6761]
===
match
---
name: with_row_locks [45992,46006]
name: with_row_locks [45992,46006]
===
match
---
atom_expr [11868,11903]
atom_expr [11868,11903]
===
match
---
parameters [34785,34791]
parameters [34785,34791]
===
match
---
trailer [68766,68784]
trailer [68900,68918]
===
match
---
name: DeprecationWarning [28979,28997]
name: DeprecationWarning [28979,28997]
===
match
---
trailer [70534,70743]
trailer [70668,70877]
===
match
---
simple_stmt [37396,37413]
simple_stmt [37396,37413]
===
match
---
operator: = [37566,37567]
operator: = [37566,37567]
===
match
---
fstring_string: &dag_id= [19716,19724]
fstring_string: &dag_id= [19716,19724]
===
match
---
string: 'start_date' [58388,58400]
string: 'start_date' [58522,58534]
===
match
---
atom_expr [80297,80306]
atom_expr [80431,80440]
===
match
---
atom_expr [10382,10422]
atom_expr [10382,10422]
===
match
---
operator: , [74011,74012]
operator: , [74145,74146]
===
match
---
name: task [60005,60009]
name: task [60139,60143]
===
match
---
name: _run_as_user [80039,80051]
name: _run_as_user [80173,80185]
===
match
---
name: render_templates [66458,66474]
name: render_templates [66592,66608]
===
match
---
atom_expr [30336,30353]
atom_expr [30336,30353]
===
match
---
operator: , [6870,6871]
operator: , [6870,6871]
===
match
---
trailer [45244,45262]
trailer [45244,45262]
===
match
---
trailer [14587,14592]
trailer [14587,14592]
===
match
---
comparison [56282,56299]
comparison [56282,56299]
===
match
---
simple_stmt [26371,26417]
simple_stmt [26371,26417]
===
match
---
param [53438,53475]
param [53438,53475]
===
match
---
atom_expr [41470,41500]
atom_expr [41470,41500]
===
match
---
param [81370,81383]
param [81504,81517]
===
match
---
try_stmt [54260,54765]
try_stmt [54260,54765]
===
match
---
fstring_string: DAGS_FOLDER/ [14743,14755]
fstring_string: DAGS_FOLDER/ [14743,14755]
===
match
---
name: ti [79196,79198]
name: ti [79330,79332]
===
match
---
string: """         Returns whether a task is in UP_FOR_RETRY state and its retry interval         has elapsed.         """ [25138,25253]
string: """         Returns whether a task is in UP_FOR_RETRY state and its retry interval         has elapsed.         """ [25138,25253]
===
match
---
name: context [53143,53150]
name: context [53143,53150]
===
match
---
simple_stmt [18742,18778]
simple_stmt [18742,18778]
===
match
---
operator: , [15661,15662]
operator: , [15661,15662]
===
match
---
name: ignore_ti_state [15796,15811]
name: ignore_ti_state [15796,15811]
===
match
---
name: task [33226,33230]
name: task [33226,33230]
===
match
---
fstring_expr [44929,44941]
fstring_expr [44929,44941]
===
match
---
atom_expr [80488,80501]
atom_expr [80622,80635]
===
match
---
operator: = [31607,31608]
operator: = [31607,31608]
===
match
---
param [15905,15937]
param [15905,15937]
===
match
---
dotted_name [13238,13255]
dotted_name [13238,13255]
===
match
---
trailer [19297,19322]
trailer [19297,19322]
===
match
---
dotted_name [2225,2238]
dotted_name [2225,2238]
===
match
---
name: params [67738,67744]
name: params [67872,67878]
===
match
---
simple_stmt [1176,1201]
simple_stmt [1176,1201]
===
match
---
string: """Get Airflow Variable value""" [63254,63286]
string: """Get Airflow Variable value""" [63388,63420]
===
match
---
operator: , [45771,45772]
operator: , [45771,45772]
===
match
---
name: dispose [41027,41034]
name: dispose [41027,41034]
===
match
---
name: VariableJsonAccessor [63369,63389]
name: VariableJsonAccessor [63503,63523]
===
match
---
name: task_id [68338,68345]
name: task_id [68472,68479]
===
match
---
name: dagrun [7546,7552]
name: dagrun [7546,7552]
===
match
---
tfpdef [74359,74380]
tfpdef [74493,74514]
===
match
---
trailer [72425,72431]
trailer [72559,72565]
===
match
---
name: self [67672,67676]
name: self [67806,67810]
===
match
---
name: task [61177,61181]
name: task [61311,61315]
===
match
---
name: execution_date [24337,24351]
name: execution_date [24337,24351]
===
match
---
trailer [71259,71261]
trailer [71393,71395]
===
match
---
simple_stmt [53242,53274]
simple_stmt [53242,53274]
===
match
---
atom_expr [42721,42734]
atom_expr [42721,42734]
===
match
---
simple_stmt [23437,23473]
simple_stmt [23437,23473]
===
match
---
name: pid [22791,22794]
name: pid [22791,22794]
===
match
---
operator: = [26352,26353]
operator: = [26352,26353]
===
match
---
arglist [40516,40580]
arglist [40516,40580]
===
match
---
name: dag_id [7139,7145]
name: dag_id [7139,7145]
===
match
---
string: "Failed to register in sensor service.Continue to run task in non smart sensor mode." [49919,50004]
string: "Failed to register in sensor service.Continue to run task in non smart sensor mode." [49919,50004]
===
match
---
name: set_duration [72558,72570]
name: set_duration [72692,72704]
===
match
---
trailer [3725,3896]
trailer [3725,3896]
===
match
---
name: iso [19130,19133]
name: iso [19130,19133]
===
match
---
name: task [68019,68023]
name: task [68153,68157]
===
match
---
name: job_id [5300,5306]
name: job_id [5300,5306]
===
match
---
trailer [25371,25387]
trailer [25371,25387]
===
match
---
simple_stmt [82144,82154]
simple_stmt [82278,82288]
===
match
---
trailer [43886,43898]
trailer [43886,43898]
===
match
---
name: DagRun [82522,82528]
name: DagRun [82656,82662]
===
match
---
name: provide_session [45619,45634]
name: provide_session [45619,45634]
===
match
---
trailer [59543,59552]
trailer [59677,59686]
===
match
---
name: file_path [18766,18775]
name: file_path [18766,18775]
===
match
---
name: strftime [60569,60577]
name: strftime [60703,60711]
===
match
---
operator: = [20221,20222]
operator: = [20221,20222]
===
match
---
atom_expr [55651,55661]
atom_expr [55651,55661]
===
match
---
name: self [32184,32188]
name: self [32184,32188]
===
match
---
string: """Render k8s pod yaml""" [68118,68143]
string: """Render k8s pod yaml""" [68252,68277]
===
match
---
name: command_as_list [68495,68510]
name: command_as_list [68629,68644]
===
match
---
expr_stmt [42922,42959]
expr_stmt [42922,42959]
===
match
---
suite [49856,50084]
suite [49856,50084]
===
match
---
name: dr [35320,35322]
name: dr [35320,35322]
===
match
---
name: str [4665,4668]
name: str [4665,4668]
===
match
---
operator: = [31689,31690]
operator: = [31689,31690]
===
match
---
comparison [35381,35409]
comparison [35381,35409]
===
match
---
trailer [34694,34699]
trailer [34694,34699]
===
match
---
operator: = [53713,53714]
operator: = [53713,53714]
===
match
---
name: self [68969,68973]
name: self [69103,69107]
===
match
---
string: 'tomorrow_ds_nodash' [65555,65575]
string: 'tomorrow_ds_nodash' [65689,65709]
===
match
---
trailer [25968,25988]
trailer [25968,25988]
===
match
---
name: test_mode [35868,35877]
name: test_mode [35868,35877]
===
match
---
fstring_expr [62189,62203]
fstring_expr [62323,62337]
===
match
---
dotted_name [1635,1653]
dotted_name [1635,1653]
===
match
---
operator: { [44929,44930]
operator: { [44929,44930]
===
match
---
string: """Get failed Dependencies""" [32311,32340]
string: """Get failed Dependencies""" [32311,32340]
===
match
---
atom_expr [56325,56339]
atom_expr [56325,56339]
===
match
---
simple_stmt [63254,63287]
simple_stmt [63388,63421]
===
match
---
name: COLLATION_ARGS [9494,9508]
name: COLLATION_ARGS [9494,9508]
===
match
---
operator: , [28965,28966]
operator: , [28965,28966]
===
match
---
name: self [29505,29509]
name: self [29505,29509]
===
match
---
trailer [61059,61074]
trailer [61193,61208]
===
match
---
name: self [19101,19105]
name: self [19101,19105]
===
match
---
operator: , [65501,65502]
operator: , [65635,65636]
===
match
---
atom_expr [80824,80840]
atom_expr [80958,80974]
===
match
---
trailer [41733,41738]
trailer [41733,41738]
===
match
---
name: context [52693,52700]
name: context [52693,52700]
===
match
---
with_item [71759,71774]
with_item [71893,71908]
===
match
---
trailer [29082,29090]
trailer [29082,29090]
===
match
---
name: Variable [63174,63182]
name: Variable [63308,63316]
===
match
---
suite [56576,56627]
suite [56710,56761]
===
match
---
atom [18284,18313]
atom [18284,18313]
===
match
---
trailer [76744,76752]
trailer [76878,76886]
===
match
---
name: airflow [60039,60046]
name: airflow [60173,60180]
===
match
---
operator: = [41664,41665]
operator: = [41664,41665]
===
match
---
trailer [45378,45391]
trailer [45378,45391]
===
match
---
suite [63237,63354]
suite [63371,63488]
===
match
---
operator: @ [63026,63027]
operator: @ [63160,63161]
===
match
---
atom_expr [55277,55296]
atom_expr [55277,55296]
===
match
---
operator: = [54286,54287]
operator: = [54286,54287]
===
match
---
decorator [81084,81094]
decorator [81218,81228]
===
match
---
name: current_time [24968,24980]
name: current_time [24968,24980]
===
match
---
name: self [55651,55655]
name: self [55651,55655]
===
match
---
name: jinja_env [71119,71128]
name: jinja_env [71253,71262]
===
match
---
name: datetime [79774,79782]
name: datetime [79908,79916]
===
match
---
trailer [39781,39837]
trailer [39781,39837]
===
match
---
string: """         Return the try number that this task number will be when it is actually         run.          If the TaskInstance is currently running, this will match the column in the         database, in all other cases this will be incremented.         """ [12696,12952]
string: """         Return the try number that this task number will be when it is actually         run.          If the TaskInstance is currently running, this will match the column in the         database, in all other cases this will be incremented.         """ [12696,12952]
===
match
---
name: relationship [82509,82521]
name: relationship [82643,82655]
===
match
---
trailer [72514,72520]
trailer [72648,72654]
===
match
---
name: email_alert [72199,72210]
name: email_alert [72333,72344]
===
match
---
name: timezone [24672,24680]
name: timezone [24672,24680]
===
match
---
name: DateTime [29845,29853]
name: DateTime [29845,29853]
===
match
---
arglist [48946,48971]
arglist [48946,48971]
===
match
---
name: DagRun [35381,35387]
name: DagRun [35381,35387]
===
match
---
simple_stmt [51541,51547]
simple_stmt [51541,51547]
===
match
---
trailer [56947,57016]
trailer [57081,57150]
===
match
---
name: log [39900,39903]
name: log [39900,39903]
===
match
---
operator: = [30177,30178]
operator: = [30177,30178]
===
match
---
name: ignore_ti_state [39706,39721]
name: ignore_ti_state [39706,39721]
===
match
---
trailer [32949,32964]
trailer [32949,32964]
===
match
---
trailer [24120,24126]
trailer [24120,24126]
===
match
---
decorator [30272,30282]
decorator [30272,30282]
===
match
---
param [29173,29201]
param [29173,29201]
===
match
---
name: self [79805,79809]
name: self [79939,79943]
===
match
---
name: state [22835,22840]
name: state [22835,22840]
===
match
---
simple_stmt [39192,39237]
simple_stmt [39192,39237]
===
match
---
operator: == [78756,78758]
operator: == [78890,78892]
===
match
---
trailer [41026,41034]
trailer [41026,41034]
===
match
---
atom_expr [23587,23601]
atom_expr [23587,23601]
===
match
---
atom_expr [22759,22773]
atom_expr [22759,22773]
===
match
---
operator: , [45211,45212]
operator: , [45211,45212]
===
match
---
trailer [23546,23562]
trailer [23546,23562]
===
match
---
suite [53126,53274]
suite [53126,53274]
===
match
---
trailer [43420,43424]
trailer [43420,43424]
===
match
---
atom_expr [62892,62910]
atom_expr [63026,63044]
===
match
---
atom_expr [29077,29090]
atom_expr [29077,29090]
===
match
---
if_stmt [52582,52772]
if_stmt [52582,52772]
===
match
---
operator: -> [80392,80394]
operator: -> [80526,80528]
===
match
---
operator: = [37401,37402]
operator: = [37401,37402]
===
match
---
name: pre_execute [49433,49444]
name: pre_execute [49433,49444]
===
match
---
trailer [8756,8764]
trailer [8756,8764]
===
match
---
operator: = [53546,53547]
operator: = [53546,53547]
===
match
---
name: str [56171,56174]
name: str [56171,56174]
===
match
---
name: email [58524,58529]
name: email [58658,58663]
===
match
---
name: _run_execute_callback [51835,51856]
name: _run_execute_callback [51835,51856]
===
match
---
argument [71880,71895]
argument [72014,72029]
===
match
---
expr_stmt [37396,37412]
expr_stmt [37396,37412]
===
match
---
simple_stmt [50596,50623]
simple_stmt [50596,50623]
===
match
---
trailer [6874,6882]
trailer [6874,6882]
===
match
---
expr_stmt [56661,56694]
expr_stmt [56795,56828]
===
match
---
operator: , [78938,78939]
operator: , [79072,79073]
===
match
---
parameters [80869,80875]
parameters [81003,81009]
===
match
---
name: timedelta [34576,34585]
name: timedelta [34576,34585]
===
match
---
simple_stmt [9855,9883]
simple_stmt [9855,9883]
===
match
---
operator: , [1258,1259]
operator: , [1258,1259]
===
match
---
name: _date_or_empty [41327,41341]
name: _date_or_empty [41327,41341]
===
match
---
name: item [63077,63081]
name: item [63211,63215]
===
match
---
name: previous_scheduled_date [27089,27112]
name: previous_scheduled_date [27089,27112]
===
match
---
trailer [53157,53178]
trailer [53157,53178]
===
match
---
atom_expr [56859,56895]
atom_expr [56993,57029]
===
match
---
operator: -> [53726,53728]
operator: -> [53726,53728]
===
match
---
name: dag [60202,60205]
name: dag [60336,60339]
===
match
---
name: cmd [18863,18866]
name: cmd [18863,18866]
===
match
---
name: and_ [79041,79045]
name: and_ [79175,79179]
===
match
---
operator: , [4031,4032]
operator: , [4031,4032]
===
match
---
name: _execute_task [50375,50388]
name: _execute_task [50375,50388]
===
match
---
trailer [3555,3562]
trailer [3555,3562]
===
match
---
name: ds [64474,64476]
name: ds [64608,64610]
===
match
---
suite [18045,18089]
suite [18045,18089]
===
match
---
fstring_string: operator_successes_ [50539,50558]
fstring_string: operator_successes_ [50539,50558]
===
match
---
simple_stmt [71554,71595]
simple_stmt [71688,71729]
===
match
---
simple_stmt [49058,49138]
simple_stmt [49058,49138]
===
match
---
operator: , [68433,68434]
operator: , [68567,68568]
===
match
---
arglist [31791,31831]
arglist [31791,31831]
===
match
---
name: self [8150,8154]
name: self [8150,8154]
===
match
---
name: pickle [4653,4659]
name: pickle [4653,4659]
===
match
---
trailer [10108,10121]
trailer [10108,10121]
===
match
---
string: 'task_instance' [65366,65381]
string: 'task_instance' [65500,65515]
===
match
---
name: ts_nodash_with_tz [61975,61992]
name: ts_nodash_with_tz [62109,62126]
===
match
---
name: min_backoff [33553,33564]
name: min_backoff [33553,33564]
===
match
---
fstring_end: " [19774,19775]
fstring_end: " [19774,19775]
===
match
---
dotted_name [82355,82369]
dotted_name [82489,82503]
===
match
---
trailer [37638,37640]
trailer [37638,37640]
===
match
---
operator: , [9829,9830]
operator: , [9829,9830]
===
match
---
import_as_names [2103,2124]
import_as_names [2103,2124]
===
match
---
operator: = [79734,79735]
operator: = [79868,79869]
===
match
---
simple_stmt [52738,52772]
simple_stmt [52738,52772]
===
match
---
name: log_message [58232,58243]
name: log_message [58366,58377]
===
match
---
operator: = [11033,11034]
operator: = [11033,11034]
===
match
---
name: self [63952,63956]
name: self [64086,64090]
===
match
---
name: Tuple [79364,79369]
name: Tuple [79498,79503]
===
match
---
name: self [30791,30795]
name: self [30791,30795]
===
match
---
name: Variable [2062,2070]
name: Variable [2062,2070]
===
match
---
trailer [44051,44103]
trailer [44051,44103]
===
match
---
atom_expr [9622,9659]
atom_expr [9622,9659]
===
match
---
trailer [23901,23907]
trailer [23901,23907]
===
match
---
name: int [79823,79826]
name: int [79957,79960]
===
match
---
trailer [32712,32719]
trailer [32712,32719]
===
match
---
name: session [21041,21048]
name: session [21041,21048]
===
match
---
decorated [25395,26417]
decorated [25395,26417]
===
match
---
expr_stmt [7919,7952]
expr_stmt [7919,7952]
===
match
---
operator: { [19371,19372]
operator: { [19371,19372]
===
match
---
simple_stmt [33553,33636]
simple_stmt [33553,33636]
===
match
---
operator: = [9932,9933]
operator: = [9932,9933]
===
match
---
simple_stmt [58842,58859]
simple_stmt [58976,58993]
===
match
---
name: Column [9810,9816]
name: Column [9810,9816]
===
match
---
atom_expr [11525,11687]
atom_expr [11525,11687]
===
match
---
operator: @ [29701,29702]
operator: @ [29701,29702]
===
match
---
expr_stmt [60472,60508]
expr_stmt [60606,60642]
===
match
---
trailer [61777,61786]
trailer [61911,61920]
===
match
---
operator: == [37712,37714]
operator: == [37712,37714]
===
match
---
tfpdef [41612,41630]
tfpdef [41612,41630]
===
match
---
name: LoggingMixin [2549,2561]
name: LoggingMixin [2549,2561]
===
match
---
trailer [81966,81981]
trailer [82100,82115]
===
match
---
trailer [9628,9659]
trailer [9628,9659]
===
match
---
trailer [58757,58767]
trailer [58891,58901]
===
match
---
test [54616,54682]
test [54616,54682]
===
match
---
name: self [8549,8553]
name: self [8549,8553]
===
match
---
atom_expr [22112,22120]
atom_expr [22112,22120]
===
match
---
name: self [50230,50234]
name: self [50230,50234]
===
match
---
name: on_failure_callback [52743,52762]
name: on_failure_callback [52743,52762]
===
match
---
operator: == [54635,54637]
operator: == [54635,54637]
===
match
---
atom_expr [24857,24867]
atom_expr [24857,24867]
===
match
---
name: should_pass_filepath [14662,14682]
name: should_pass_filepath [14662,14682]
===
match
---
if_stmt [57617,58109]
if_stmt [57751,58243]
===
match
---
name: datetime [80721,80729]
name: datetime [80855,80863]
===
match
---
name: self [29576,29580]
name: self [29576,29580]
===
match
---
return_stmt [13970,13997]
return_stmt [13970,13997]
===
match
---
atom_expr [59362,59377]
atom_expr [59496,59511]
===
match
---
name: open [4380,4384]
name: open [4380,4384]
===
match
---
name: task_id [24323,24330]
name: task_id [24323,24330]
===
match
---
name: int [8614,8617]
name: int [8614,8617]
===
match
---
trailer [22567,22578]
trailer [22567,22578]
===
match
---
name: execute [7267,7274]
name: execute [7267,7274]
===
match
---
name: test_mode [37495,37504]
name: test_mode [37495,37504]
===
match
---
name: TaskInstance [82534,82546]
name: TaskInstance [82668,82680]
===
match
---
operator: = [69253,69254]
operator: = [69387,69388]
===
match
---
name: Column [10257,10263]
name: Column [10257,10263]
===
match
---
operator: , [41602,41603]
operator: , [41602,41603]
===
match
---
name: commit [40387,40393]
name: commit [40387,40393]
===
match
---
string: 'html_content_template' [71998,72021]
string: 'html_content_template' [72132,72155]
===
match
---
trailer [80038,80051]
trailer [80172,80185]
===
match
---
trailer [61838,61859]
trailer [61972,61993]
===
match
---
name: dict [70530,70534]
name: dict [70664,70668]
===
match
---
param [28104,28108]
param [28104,28108]
===
match
---
name: task [11206,11210]
name: task [11206,11210]
===
match
---
decorator [32215,32232]
decorator [32215,32232]
===
match
---
trailer [34644,34660]
trailer [34644,34660]
===
match
---
operator: , [64035,64036]
operator: , [64169,64170]
===
match
---
name: context [52763,52770]
name: context [52763,52770]
===
match
---
atom_expr [11226,11238]
atom_expr [11226,11238]
===
match
---
atom_expr [49766,49817]
atom_expr [49766,49817]
===
match
---
trailer [14966,14973]
trailer [14966,14973]
===
match
---
name: error_file [44807,44817]
name: error_file [44807,44817]
===
match
---
name: models [1937,1943]
name: models [1937,1943]
===
match
---
operator: = [14314,14315]
operator: = [14314,14315]
===
match
---
name: verbose [39824,39831]
name: verbose [39824,39831]
===
match
---
suite [80197,80253]
suite [80331,80387]
===
match
---
trailer [32546,32550]
trailer [32546,32550]
===
match
---
operator: = [5562,5563]
operator: = [5562,5563]
===
match
---
operator: = [3255,3256]
operator: = [3255,3256]
===
match
---
arglist [27275,27329]
arglist [27275,27329]
===
match
---
name: property [12653,12661]
name: property [12653,12661]
===
match
---
trailer [38976,38983]
trailer [38976,38983]
===
match
---
trailer [45439,45443]
trailer [45439,45443]
===
match
---
atom_expr [68193,68796]
atom_expr [68327,68930]
===
match
---
name: email_on_retry [58094,58108]
name: email_on_retry [58228,58242]
===
match
---
name: reschedule_exception [55076,55096]
name: reschedule_exception [55076,55096]
===
match
---
name: cfg_path [18837,18845]
name: cfg_path [18837,18845]
===
match
---
string: '%s dag_id=%s, task_id=%s, execution_date=%s, start_date=%s, end_date=%s' [58145,58218]
string: '%s dag_id=%s, task_id=%s, execution_date=%s, start_date=%s, end_date=%s' [58279,58352]
===
match
---
funcdef [12486,12647]
funcdef [12486,12647]
===
match
---
atom [59840,59842]
atom [59974,59976]
===
match
---
atom_expr [50370,50408]
atom_expr [50370,50408]
===
match
---
name: get_previous_scheduled_dagrun [27787,27816]
name: get_previous_scheduled_dagrun [27787,27816]
===
match
---
simple_stmt [58013,58059]
simple_stmt [58147,58193]
===
match
---
string: 'BASE_URL' [19600,19610]
string: 'BASE_URL' [19600,19610]
===
match
---
operator: , [6779,6780]
operator: , [6779,6780]
===
match
---
name: state [7460,7465]
name: state [7460,7465]
===
match
---
expr [32410,32443]
expr [32410,32443]
===
match
---
name: pickle [879,885]
name: pickle [879,885]
===
match
---
operator: = [48879,48880]
operator: = [48879,48880]
===
match
---
atom_expr [6613,7188]
atom_expr [6613,7188]
===
match
---
parameters [77204,77219]
parameters [77338,77353]
===
match
---
name: task [43031,43035]
name: task [43031,43035]
===
match
---
operator: , [76337,76338]
operator: , [76471,76472]
===
match
---
operator: = [68718,68719]
operator: = [68852,68853]
===
match
---
param [23654,23666]
param [23654,23666]
===
match
---
name: email_for_state [58071,58086]
name: email_for_state [58205,58220]
===
match
---
name: str [80879,80882]
name: str [81013,81016]
===
match
---
trailer [22616,22622]
trailer [22616,22622]
===
match
---
string: 'dag_id=%s, task_id=%s, execution_date=%s, start_date=%s, end_date=%s' [45090,45160]
string: 'dag_id=%s, task_id=%s, execution_date=%s, start_date=%s, end_date=%s' [45090,45160]
===
match
---
number: 0 [26360,26361]
number: 0 [26360,26361]
===
match
---
name: Optional [58990,58998]
name: Optional [59124,59132]
===
match
---
operator: , [8168,8169]
operator: , [8168,8169]
===
match
---
expr_stmt [40290,40326]
expr_stmt [40290,40326]
===
match
---
operator: @ [24375,24376]
operator: @ [24375,24376]
===
match
---
argument [34586,34618]
argument [34586,34618]
===
match
---
fstring_string: /log?execution_date= [19351,19371]
fstring_string: /log?execution_date= [19351,19371]
===
match
---
name: dag_run [45982,45989]
name: dag_run [45982,45989]
===
match
---
name: cmd [18058,18061]
name: cmd [18058,18061]
===
match
---
name: queue [10094,10099]
name: queue [10094,10099]
===
match
---
name: ignore_depends_on_past [53438,53460]
name: ignore_depends_on_past [53438,53460]
===
match
---
expr_stmt [9736,9760]
expr_stmt [9736,9760]
===
match
---
trailer [60427,60442]
trailer [60561,60576]
===
match
---
atom_expr [44930,44940]
atom_expr [44930,44940]
===
match
---
fstring_expr [62205,62216]
fstring_expr [62339,62350]
===
match
---
operator: = [30825,30826]
operator: = [30825,30826]
===
match
---
expr_stmt [62881,62910]
expr_stmt [63015,63044]
===
match
---
simple_stmt [10554,10876]
simple_stmt [10554,10876]
===
match
---
trailer [45492,45498]
trailer [45492,45498]
===
match
---
if_stmt [80163,80253]
if_stmt [80297,80387]
===
match
---
name: self [24698,24702]
name: self [24698,24702]
===
match
---
atom_expr [19687,19699]
atom_expr [19687,19699]
===
match
---
name: self [72766,72770]
name: self [72900,72904]
===
match
---
expr_stmt [53059,53075]
expr_stmt [53059,53075]
===
match
---
decorator [23607,23624]
decorator [23607,23624]
===
match
---
expr_stmt [78188,78217]
expr_stmt [78322,78351]
===
match
---
string: '%Y-%m-%d' [60452,60462]
string: '%Y-%m-%d' [60586,60596]
===
match
---
operator: , [65617,65618]
operator: , [65751,65752]
===
match
---
name: v [49256,49257]
name: v [49256,49257]
===
match
---
argument [74059,74077]
argument [74193,74211]
===
match
---
name: log [56376,56379]
name: log [56508,56511]
===
match
---
simple_stmt [21095,21489]
simple_stmt [21095,21489]
===
match
---
funcdef [25416,26417]
funcdef [25416,26417]
===
match
---
name: dag_id [68245,68251]
name: dag_id [68379,68385]
===
match
---
name: task_id [8512,8519]
name: task_id [8512,8519]
===
match
---
name: self [8596,8600]
name: self [8596,8600]
===
match
---
operator: = [14249,14250]
operator: = [14249,14250]
===
match
---
atom_expr [11474,11511]
atom_expr [11474,11511]
===
match
---
atom [7768,7801]
atom [7768,7801]
===
match
---
name: dep [32403,32406]
name: dep [32403,32406]
===
match
---
string: "previous_execution_date was called" [29520,29556]
string: "previous_execution_date was called" [29520,29556]
===
match
---
expr_stmt [11262,11278]
expr_stmt [11262,11278]
===
match
---
trailer [31634,31636]
trailer [31634,31636]
===
match
---
trailer [49893,50026]
trailer [49893,50026]
===
match
---
suite [26978,27331]
suite [26978,27331]
===
match
---
arglist [62404,62434]
arglist [62538,62568]
===
match
---
operator: , [32613,32614]
operator: , [32613,32614]
===
match
---
name: min_backoff [34065,34076]
name: min_backoff [34065,34076]
===
match
---
name: ti [5240,5242]
name: ti [5240,5242]
===
match
---
operator: @ [80984,80985]
operator: @ [81118,81119]
===
match
---
trailer [67753,67758]
trailer [67887,67892]
===
match
---
trailer [5242,5248]
trailer [5242,5248]
===
match
---
funcdef [63645,63697]
funcdef [63779,63831]
===
match
---
name: lock_for_update [21791,21806]
name: lock_for_update [21791,21806]
===
match
---
name: dep_status [32661,32671]
name: dep_status [32661,32671]
===
match
---
atom_expr [5424,5445]
atom_expr [5424,5445]
===
match
---
arglist [59112,59184]
arglist [59246,59318]
===
match
---
trailer [34530,34534]
trailer [34530,34534]
===
match
---
trailer [14948,15466]
trailer [14948,15466]
===
match
---
trailer [7381,7387]
trailer [7381,7387]
===
match
---
fstring_start: f" [32898,32900]
fstring_start: f" [32898,32900]
===
match
---
trailer [23502,23510]
trailer [23502,23510]
===
match
---
trailer [72737,72739]
trailer [72871,72873]
===
match
---
trailer [24712,24760]
trailer [24712,24760]
===
match
---
expr_stmt [56636,56652]
expr_stmt [56770,56786]
===
match
---
name: error_file [4385,4395]
name: error_file [4385,4395]
===
match
---
name: get_template_context [52654,52674]
name: get_template_context [52654,52674]
===
match
---
trailer [79918,79934]
trailer [80052,80068]
===
match
---
term [33581,33633]
term [33581,33633]
===
match
---
name: tomorrow_ds [65530,65541]
name: tomorrow_ds [65664,65675]
===
match
---
annassign [79772,79796]
annassign [79906,79930]
===
match
---
atom_expr [79707,79723]
atom_expr [79841,79857]
===
match
---
trailer [39947,39951]
trailer [39947,39951]
===
match
---
string: 'execution_date is {}; received {})' [73853,73889]
string: 'execution_date is {}; received {})' [73987,74023]
===
match
---
operator: , [24316,24317]
operator: , [24316,24317]
===
match
---
operator: = [56100,56101]
operator: = [56100,56101]
===
match
---
atom_expr [80054,80068]
atom_expr [80188,80202]
===
match
---
trailer [21852,21854]
trailer [21852,21854]
===
match
---
name: ti [21909,21911]
name: ti [21909,21911]
===
match
---
name: executor_config [68573,68588]
name: executor_config [68707,68722]
===
match
---
name: or_ [6689,6692]
name: or_ [6689,6692]
===
match
---
param [77205,77210]
param [77339,77344]
===
match
---
parameters [62731,62737]
parameters [62865,62871]
===
match
---
name: task [52838,52842]
name: task [52838,52842]
===
match
---
operator: = [71348,71349]
operator: = [71482,71483]
===
match
---
simple_stmt [78142,78180]
simple_stmt [78276,78314]
===
match
---
name: task [48186,48190]
name: task [48186,48190]
===
match
---
operator: = [74406,74407]
operator: = [74540,74541]
===
match
---
name: ds [61881,61883]
name: ds [62015,62017]
===
match
---
simple_stmt [18058,18089]
simple_stmt [18058,18089]
===
match
---
decorated [24153,24370]
decorated [24153,24370]
===
match
---
decorator [13883,13893]
decorator [13883,13893]
===
match
---
suite [62864,62943]
suite [62998,63077]
===
match
---
name: execution_date [7749,7763]
name: execution_date [7749,7763]
===
match
---
tfpdef [35793,35814]
tfpdef [35793,35814]
===
match
---
simple_stmt [22495,22519]
simple_stmt [22495,22519]
===
match
---
name: first_task_id [78980,78993]
name: first_task_id [79114,79127]
===
match
---
argument [54307,54318]
argument [54307,54318]
===
match
---
simple_stmt [9701,9732]
simple_stmt [9701,9732]
===
match
---
name: commit [50889,50895]
name: commit [50889,50895]
===
match
---
string: """Send alert email with exception information.""" [72237,72287]
string: """Send alert email with exception information.""" [72371,72421]
===
match
---
trailer [11541,11687]
trailer [11541,11687]
===
match
---
expr_stmt [10164,10195]
expr_stmt [10164,10195]
===
match
---
comparison [78956,78993]
comparison [79090,79127]
===
match
---
arglist [79063,79214]
arglist [79197,79348]
===
match
---
name: try_number [8787,8797]
name: try_number [8787,8797]
===
match
---
argument [38520,38532]
argument [38520,38532]
===
match
---
name: _date_or_empty [45230,45244]
name: _date_or_empty [45230,45244]
===
match
---
fstring_start: f" [67403,67405]
fstring_start: f" [67537,67539]
===
match
---
decorator [25395,25412]
decorator [25395,25412]
===
match
---
decorator [81315,81332]
decorator [81449,81466]
===
match
---
operator: = [38527,38528]
operator: = [38527,38528]
===
match
---
funcdef [72878,74184]
funcdef [73012,74318]
===
match
---
operator: , [37549,37550]
operator: , [37549,37550]
===
match
---
name: execution_date [78612,78626]
name: execution_date [78746,78760]
===
match
---
atom_expr [71119,71190]
atom_expr [71253,71324]
===
match
---
arglist [73897,73932]
arglist [74031,74066]
===
match
---
operator: = [35083,35084]
operator: = [35083,35084]
===
match
---
name: FAILED [20929,20935]
name: FAILED [20929,20935]
===
match
---
name: task [47074,47078]
name: task [47074,47078]
===
match
---
tfpdef [15756,15778]
tfpdef [15756,15778]
===
match
---
name: self [80712,80716]
name: self [80846,80850]
===
match
---
decorator [81154,81164]
decorator [81288,81298]
===
match
---
fstring_string: &execution_date= [19753,19769]
fstring_string: &execution_date= [19753,19769]
===
match
---
name: queued_dttm [10200,10211]
name: queued_dttm [10200,10211]
===
match
---
suite [42905,43037]
suite [42905,43037]
===
match
---
name: append [5290,5296]
name: append [5290,5296]
===
match
---
trailer [26294,26326]
trailer [26294,26326]
===
match
---
trailer [58387,58418]
trailer [58521,58552]
===
match
---
atom_expr [14847,14864]
atom_expr [14847,14864]
===
match
---
name: ignore_ti_state [38239,38254]
name: ignore_ti_state [38239,38254]
===
match
---
name: task [23319,23323]
name: task [23319,23323]
===
match
---
argument [27922,27933]
argument [27922,27933]
===
match
---
name: subject [72150,72157]
name: subject [72284,72291]
===
match
---
name: schedule_interval [27668,27685]
name: schedule_interval [27668,27685]
===
match
---
name: models [82453,82459]
name: models [82587,82593]
===
match
---
name: task [41271,41275]
name: task [41271,41275]
===
match
---
name: logging [3257,3264]
name: logging [3257,3264]
===
match
---
name: ignore_task_deps [39656,39672]
name: ignore_task_deps [39656,39672]
===
match
---
name: dr [26975,26977]
name: dr [26975,26977]
===
match
---
expr_stmt [3624,3663]
expr_stmt [3624,3663]
===
match
---
argument [39782,39805]
argument [39782,39805]
===
match
---
simple_stmt [41118,41196]
simple_stmt [41118,41196]
===
match
---
trailer [37614,37623]
trailer [37614,37623]
===
match
---
name: schedulable_ti [47367,47381]
name: schedulable_ti [47367,47381]
===
match
---
name: self [37403,37407]
name: self [37403,37407]
===
match
---
name: __init__ [63649,63657]
name: __init__ [63783,63791]
===
match
---
name: strftime [61941,61949]
name: strftime [62075,62083]
===
match
---
atom_expr [35001,35018]
atom_expr [35001,35018]
===
match
---
argument [68360,68386]
argument [68494,68520]
===
match
---
trailer [25014,25023]
trailer [25014,25023]
===
match
---
name: utils [2518,2523]
name: utils [2518,2523]
===
match
---
name: Integer [9874,9881]
name: Integer [9874,9881]
===
match
---
funcdef [81336,82154]
funcdef [81470,82288]
===
match
---
name: self [11983,11987]
name: self [11983,11987]
===
match
---
arglist [37534,37571]
arglist [37534,37571]
===
match
---
atom_expr [9995,10029]
atom_expr [9995,10029]
===
match
---
name: renderedtifields [48114,48130]
name: renderedtifields [48114,48130]
===
match
---
expr_stmt [79340,79391]
expr_stmt [79474,79525]
===
match
---
atom_expr [74124,74143]
atom_expr [74258,74277]
===
match
---
name: execution_date [60618,60632]
name: execution_date [60752,60766]
===
match
---
atom_expr [80663,80679]
atom_expr [80797,80813]
===
match
---
suite [82106,82136]
suite [82240,82270]
===
match
---
name: Column [9712,9718]
name: Column [9712,9718]
===
match
---
atom_expr [44212,44285]
atom_expr [44212,44285]
===
match
---
operator: , [78993,78994]
operator: , [79127,79128]
===
match
---
name: execution_date [7772,7786]
name: execution_date [7772,7786]
===
match
---
if_stmt [61646,61860]
if_stmt [61780,61994]
===
match
---
arglist [49105,49136]
arglist [49105,49136]
===
match
---
arglist [31911,32063]
arglist [31911,32063]
===
match
---
trailer [50895,50897]
trailer [50895,50897]
===
match
---
name: var [63888,63891]
name: var [64022,64025]
===
match
---
name: ti [79086,79088]
name: ti [79220,79222]
===
match
---
atom_expr [58308,58358]
atom_expr [58442,58492]
===
match
---
name: error_file [44675,44685]
name: error_file [44675,44685]
===
match
---
operator: { [62189,62190]
operator: { [62323,62324]
===
match
---
operator: = [3246,3247]
operator: = [3246,3247]
===
match
---
name: handle_failure [44635,44649]
name: handle_failure [44635,44649]
===
match
---
operator: , [31814,31815]
operator: , [31814,31815]
===
match
---
trailer [65120,65128]
trailer [65254,65262]
===
match
---
trailer [77137,77143]
trailer [77271,77277]
===
match
---
return_stmt [67477,67501]
return_stmt [67611,67635]
===
match
---
arglist [58388,58417]
arglist [58522,58551]
===
match
---
import_name [900,915]
import_name [900,915]
===
match
---
name: max [5934,5937]
name: max [5934,5937]
===
match
---
simple_stmt [11525,11688]
simple_stmt [11525,11688]
===
match
---
trailer [33263,33289]
trailer [33263,33289]
===
match
---
expr_stmt [22740,22773]
expr_stmt [22740,22773]
===
match
---
arglist [37444,37468]
arglist [37444,37468]
===
match
---
atom_expr [20408,20435]
atom_expr [20408,20435]
===
match
---
expr_stmt [71005,71087]
expr_stmt [71139,71221]
===
match
---
simple_stmt [79648,79699]
simple_stmt [79782,79833]
===
match
---
trailer [29844,29853]
trailer [29844,29853]
===
match
---
parameters [25122,25128]
parameters [25122,25128]
===
match
---
argument [27905,27920]
argument [27905,27920]
===
match
---
funcdef [35045,35507]
funcdef [35045,35507]
===
match
---
trailer [58093,58108]
trailer [58227,58242]
===
match
---
name: get_previous_ti [29581,29596]
name: get_previous_ti [29581,29596]
===
match
---
suite [61669,61860]
suite [61803,61994]
===
match
---
simple_stmt [2787,2825]
simple_stmt [2787,2825]
===
match
---
trailer [49539,49554]
trailer [49539,49554]
===
match
---
atom_expr [78581,78608]
atom_expr [78715,78742]
===
match
---
trailer [60577,60589]
trailer [60711,60723]
===
match
---
import_from [60034,60074]
import_from [60168,60208]
===
match
---
suite [79561,80316]
suite [79695,80450]
===
match
---
trailer [40155,40166]
trailer [40155,40166]
===
match
---
operator: = [65267,65268]
operator: = [65401,65402]
===
match
---
trailer [80492,80501]
trailer [80626,80635]
===
match
---
param [15710,15747]
param [15710,15747]
===
match
---
operator: , [64454,64455]
operator: , [64588,64589]
===
match
---
arglist [50485,50515]
arglist [50485,50515]
===
match
---
operator: } [42856,42857]
operator: } [42856,42857]
===
match
---
name: job_id [15973,15979]
name: job_id [15973,15979]
===
match
---
try_stmt [42868,44944]
try_stmt [42868,44944]
===
match
---
operator: = [72688,72689]
operator: = [72822,72823]
===
match
---
string: '%Y-%m-%d' [61445,61455]
string: '%Y-%m-%d' [61579,61589]
===
match
---
trailer [15017,15032]
trailer [15017,15032]
===
match
---
argument [59125,59144]
argument [59259,59278]
===
match
---
trailer [48427,48429]
trailer [48427,48429]
===
match
---
name: subject [70920,70927]
name: subject [71054,71061]
===
match
---
name: end_date [34744,34752]
name: end_date [34744,34752]
===
match
---
operator: = [51607,51608]
operator: = [51607,51608]
===
match
---
number: 1 [37780,37781]
number: 1 [37780,37781]
===
match
---
name: self [62934,62938]
name: self [63068,63072]
===
match
---
operator: = [11755,11756]
operator: = [11755,11756]
===
match
---
except_clause [4466,4482]
except_clause [4466,4482]
===
match
---
arglist [10721,10775]
arglist [10721,10775]
===
match
---
name: prev_attempted_tries [13345,13365]
name: prev_attempted_tries [13345,13365]
===
match
---
operator: = [34593,34594]
operator: = [34593,34594]
===
match
---
name: pendulum [29654,29662]
name: pendulum [29654,29662]
===
match
---
name: self [8766,8770]
name: self [8766,8770]
===
match
---
operator: = [41739,41740]
operator: = [41739,41740]
===
match
---
fstring_start: f' [44888,44890]
fstring_start: f' [44888,44890]
===
match
---
trailer [43835,43849]
trailer [43835,43849]
===
match
---
string: 'webserver' [19298,19309]
string: 'webserver' [19298,19309]
===
match
---
term [34079,34100]
term [34079,34100]
===
match
---
name: job_id [53632,53638]
name: job_id [53632,53638]
===
match
---
param [68085,68089]
param [68219,68223]
===
match
---
expr_stmt [4050,4066]
expr_stmt [4050,4066]
===
match
---
if_stmt [58784,58834]
if_stmt [58918,58968]
===
match
---
name: RUNNING [5189,5196]
name: RUNNING [5189,5196]
===
match
---
trailer [45515,45522]
trailer [45515,45522]
===
match
---
name: ignore_depends_on_past [15177,15199]
name: ignore_depends_on_past [15177,15199]
===
match
---
param [35868,35892]
param [35868,35892]
===
match
---
name: log [45028,45031]
name: log [45028,45031]
===
match
---
trailer [67785,67799]
trailer [67919,67933]
===
match
---
name: task_copy [49571,49580]
name: task_copy [49571,49580]
===
match
---
name: ignore_task_deps [15147,15163]
name: ignore_task_deps [15147,15163]
===
match
---
name: max_tries [5922,5931]
name: max_tries [5922,5931]
===
match
---
param [22940,22945]
param [22940,22945]
===
match
---
tfpdef [56116,56132]
tfpdef [56116,56132]
===
match
---
name: task_id [14992,14999]
name: task_id [14992,14999]
===
match
---
trailer [79970,79975]
trailer [80104,80109]
===
match
---
operator: = [52831,52832]
operator: = [52831,52832]
===
match
---
trailer [65080,65108]
trailer [65214,65242]
===
match
---
name: String [10109,10115]
name: String [10109,10115]
===
match
---
operator: , [62821,62822]
operator: , [62955,62956]
===
match
---
operator: = [35923,35924]
operator: = [35923,35924]
===
match
---
name: dag_id [74071,74077]
name: dag_id [74205,74211]
===
match
---
atom_expr [68320,68331]
atom_expr [68454,68465]
===
match
---
operator: = [59117,59118]
operator: = [59251,59252]
===
match
---
name: airflow [1635,1642]
name: airflow [1635,1642]
===
match
---
atom_expr [40859,40878]
atom_expr [40859,40878]
===
match
---
operator: , [17990,17991]
operator: , [17990,17991]
===
match
---
except_clause [3126,3144]
except_clause [3126,3144]
===
match
---
param [48273,48280]
param [48273,48280]
===
match
---
name: all [7429,7432]
name: all [7429,7432]
===
match
---
name: result [76805,76811]
name: result [76939,76945]
===
match
---
simple_stmt [44589,44596]
simple_stmt [44589,44596]
===
match
---
trailer [68754,68785]
trailer [68888,68919]
===
match
---
trailer [67653,67658]
trailer [67787,67792]
===
match
---
simple_stmt [25931,25948]
simple_stmt [25931,25948]
===
match
---
param [35066,35089]
param [35066,35089]
===
match
---
suite [11723,11817]
suite [11723,11817]
===
match
---
string: 'end_date' [45343,45353]
string: 'end_date' [45343,45353]
===
match
---
name: pool [15415,15419]
name: pool [15415,15419]
===
match
---
atom_expr [79943,79960]
atom_expr [80077,80094]
===
match
---
name: provide_session [53280,53295]
name: provide_session [53280,53295]
===
match
---
trailer [71863,71872]
trailer [71997,72006]
===
match
---
operator: = [12071,12072]
operator: = [12071,12072]
===
match
---
name: verbose [41064,41071]
name: verbose [41064,41071]
===
match
---
atom_expr [10109,10120]
atom_expr [10109,10120]
===
match
---
name: execution_date [73725,73739]
name: execution_date [73859,73873]
===
match
---
name: dr [7882,7884]
name: dr [7882,7884]
===
match
---
trailer [71763,71769]
trailer [71897,71903]
===
match
---
name: TaskInstance [81410,81422]
name: TaskInstance [81544,81556]
===
match
---
name: timezone [35001,35009]
name: timezone [35001,35009]
===
match
---
name: previous_scheduled_date [27306,27329]
name: previous_scheduled_date [27306,27329]
===
match
---
name: dag [14708,14711]
name: dag [14708,14711]
===
match
---
atom_expr [56795,56820]
atom_expr [56929,56954]
===
match
---
atom_expr [78443,78459]
atom_expr [78577,78593]
===
match
---
operator: , [10768,10769]
operator: , [10768,10769]
===
match
---
operator: , [54530,54531]
operator: , [54530,54531]
===
match
---
atom_expr [76269,76288]
atom_expr [76403,76422]
===
match
---
name: ignore_task_deps [38368,38384]
name: ignore_task_deps [38368,38384]
===
match
---
expr_stmt [31668,31735]
expr_stmt [31668,31735]
===
match
---
name: update [71289,71295]
name: update [71423,71429]
===
match
---
name: execution_date [11777,11791]
name: execution_date [11777,11791]
===
match
---
operator: , [58400,58401]
operator: , [58534,58535]
===
match
---
simple_stmt [50950,51033]
simple_stmt [50950,51033]
===
match
---
expr_stmt [61087,61128]
expr_stmt [61221,61262]
===
match
---
not_test [37923,37939]
not_test [37923,37939]
===
match
---
atom_expr [30247,30265]
atom_expr [30247,30265]
===
match
---
name: k [49252,49253]
name: k [49252,49253]
===
match
---
simple_stmt [24769,24788]
simple_stmt [24769,24788]
===
match
---
atom_expr [60533,60552]
atom_expr [60667,60686]
===
match
---
name: ti_key_str [62159,62169]
name: ti_key_str [62293,62303]
===
match
---
name: self [8494,8498]
name: self [8494,8498]
===
match
---
name: self [80899,80903]
name: self [81033,81037]
===
match
---
arglist [30547,30765]
arglist [30547,30765]
===
match
---
name: ignore_task_deps [39639,39655]
name: ignore_task_deps [39639,39655]
===
match
---
argument [10063,10072]
argument [10063,10072]
===
match
---
name: tomorrow_ds_nodash [65577,65595]
name: tomorrow_ds_nodash [65711,65729]
===
match
---
trailer [72711,72722]
trailer [72845,72856]
===
match
---
trailer [26123,26130]
trailer [26123,26130]
===
match
---
atom_expr [47166,47186]
atom_expr [47166,47186]
===
match
---
simple_stmt [9736,9761]
simple_stmt [9736,9761]
===
match
---
name: mark_success [41612,41624]
name: mark_success [41612,41624]
===
match
---
atom_expr [40309,40326]
atom_expr [40309,40326]
===
match
---
expr_stmt [67251,67297]
expr_stmt [67385,67431]
===
match
---
operator: = [35323,35324]
operator: = [35323,35324]
===
match
---
name: _try_number [40632,40643]
name: _try_number [40632,40643]
===
match
---
simple_stmt [3974,4018]
simple_stmt [3974,4018]
===
match
---
expr_stmt [3251,3284]
expr_stmt [3251,3284]
===
match
---
name: task [54857,54861]
name: task [54857,54861]
===
match
---
comparison [79063,79095]
comparison [79197,79229]
===
match
---
name: execution_date [76254,76268]
name: execution_date [76388,76402]
===
match
---
operator: , [56140,56141]
operator: , [56140,56141]
===
match
---
name: elements [1527,1535]
name: elements [1527,1535]
===
match
---
operator: , [68635,68636]
operator: , [68769,68770]
===
match
---
name: getboolean [62299,62309]
name: getboolean [62433,62443]
===
match
---
trailer [59463,59486]
trailer [59597,59620]
===
match
---
operator: -> [21078,21080]
operator: -> [21078,21080]
===
match
---
operator: = [15199,15200]
operator: = [15199,15200]
===
match
---
argument [76382,76421]
argument [76516,76555]
===
match
---
trailer [43069,43091]
trailer [43069,43091]
===
match
---
operator: , [53389,53390]
operator: , [53389,53390]
===
match
---
name: downstream_task_ids [46610,46629]
name: downstream_task_ids [46610,46629]
===
match
---
name: self [67271,67275]
name: self [67405,67409]
===
match
---
name: self [18903,18907]
name: self [18903,18907]
===
match
---
trailer [42540,42545]
trailer [42540,42545]
===
match
---
return_stmt [25319,25389]
return_stmt [25319,25389]
===
match
---
trailer [10327,10353]
trailer [10327,10353]
===
match
---
tfpdef [56036,56064]
tfpdef [56036,56064]
===
match
---
operator: , [46186,46187]
operator: , [46186,46187]
===
match
---
operator: -> [81114,81116]
operator: -> [81248,81250]
===
match
---
name: ti [80054,80056]
name: ti [80188,80190]
===
match
---
operator: @ [77733,77734]
operator: @ [77867,77868]
===
match
---
name: task_id [19391,19398]
name: task_id [19391,19398]
===
match
---
import_name [1162,1175]
import_name [1162,1175]
===
match
---
suite [81041,81079]
suite [81175,81213]
===
match
---
operator: = [23496,23497]
operator: = [23496,23497]
===
match
---
atom_expr [24305,24316]
atom_expr [24305,24316]
===
match
---
trailer [40246,40250]
trailer [40246,40250]
===
match
---
name: session [56192,56199]
name: session [56192,56199]
===
match
---
trailer [68219,68796]
trailer [68353,68930]
===
match
---
simple_stmt [49693,49712]
simple_stmt [49693,49712]
===
match
---
name: state [53018,53023]
name: state [53018,53023]
===
match
---
trailer [7230,7232]
trailer [7230,7232]
===
match
---
arglist [68233,68786]
arglist [68367,68920]
===
match
---
simple_stmt [40412,40425]
simple_stmt [40412,40425]
===
match
---
param [48029,48037]
param [48029,48037]
===
match
---
name: key [51769,51772]
name: key [51769,51772]
===
match
---
simple_stmt [68187,68797]
simple_stmt [68321,68931]
===
match
---
name: has_option [71658,71668]
name: has_option [71792,71802]
===
match
---
name: Exception [58607,58616]
name: Exception [58741,58750]
===
match
---
trailer [51591,51599]
trailer [51591,51599]
===
match
---
name: str [15528,15531]
name: str [15528,15531]
===
match
---
trailer [22392,22402]
trailer [22392,22402]
===
match
---
expr_stmt [58013,58058]
expr_stmt [58147,58192]
===
match
---
name: add [6110,6113]
name: add [6110,6113]
===
match
---
trailer [70714,70724]
trailer [70848,70858]
===
match
---
name: session [2691,2698]
name: session [2691,2698]
===
match
---
trailer [60233,60248]
trailer [60367,60382]
===
match
---
operator: + [60633,60634]
operator: + [60767,60768]
===
match
---
string: "Received SIGTERM. Terminating subprocesses." [48351,48396]
string: "Received SIGTERM. Terminating subprocesses." [48351,48396]
===
match
---
fstring_expr [19769,19774]
fstring_expr [19769,19774]
===
match
---
name: self [43816,43820]
name: self [43816,43820]
===
match
---
name: self [39756,39760]
name: self [39756,39760]
===
match
---
trailer [26075,26082]
trailer [26075,26082]
===
match
---
name: t [78746,78747]
name: t [78880,78881]
===
match
---
name: Column [10047,10053]
name: Column [10047,10053]
===
match
---
if_stmt [73681,73948]
if_stmt [73815,74082]
===
match
---
trailer [20540,20543]
trailer [20540,20543]
===
match
---
parameters [63725,63789]
parameters [63859,63923]
===
match
---
operator: = [40814,40815]
operator: = [40814,40815]
===
match
---
simple_stmt [23290,23329]
simple_stmt [23290,23329]
===
match
---
name: int [81036,81039]
name: int [81170,81173]
===
match
---
atom_expr [4380,4402]
atom_expr [4380,4402]
===
match
---
simple_stmt [44877,44944]
simple_stmt [44877,44944]
===
match
---
name: session [39111,39118]
name: session [39111,39118]
===
match
---
operator: , [14234,14235]
operator: , [14234,14235]
===
match
---
atom_expr [9712,9731]
atom_expr [9712,9731]
===
match
---
simple_stmt [23258,23282]
simple_stmt [23258,23282]
===
match
---
name: self [12503,12507]
name: self [12503,12507]
===
match
---
name: UP_FOR_RETRY [34955,34967]
name: UP_FOR_RETRY [34955,34967]
===
match
---
name: job_id [54142,54148]
name: job_id [54142,54148]
===
match
---
name: end_date [55240,55248]
name: end_date [55240,55248]
===
match
---
operator: = [54929,54930]
operator: = [54929,54930]
===
match
---
parameters [28595,28601]
parameters [28595,28601]
===
match
---
operator: , [18649,18650]
operator: , [18649,18650]
===
match
---
operator: , [54430,54431]
operator: , [54430,54431]
===
match
---
name: warning [39904,39911]
name: warning [39904,39911]
===
match
---
name: job_id [54135,54141]
name: job_id [54135,54141]
===
match
---
name: log [50052,50055]
name: log [50052,50055]
===
match
---
string: '-' [61778,61781]
string: '-' [61912,61915]
===
match
---
atom_expr [81806,82016]
atom_expr [81940,82150]
===
match
---
operator: = [9675,9676]
operator: = [9675,9676]
===
match
---
simple_stmt [66559,66935]
simple_stmt [66693,67069]
===
match
---
operator: , [41638,41639]
operator: , [41638,41639]
===
match
---
operator: = [35736,35737]
operator: = [35736,35737]
===
match
---
name: self [52649,52653]
name: self [52649,52653]
===
match
---
name: get [64005,64008]
name: get [64139,64142]
===
match
---
name: task [47382,47386]
name: task [47382,47386]
===
match
---
operator: , [15353,15354]
operator: , [15353,15354]
===
match
---
name: error [54758,54763]
name: error [54758,54763]
===
match
---
operator: , [50500,50501]
operator: , [50500,50501]
===
match
---
return_stmt [19331,19421]
return_stmt [19331,19421]
===
match
---
annassign [80272,80288]
annassign [80406,80422]
===
match
---
operator: = [39793,39794]
operator: = [39793,39794]
===
match
---
operator: -> [80465,80467]
operator: -> [80599,80601]
===
match
---
string: """         Make an XCom available for tasks to pull.          :param key: A key for the XCom         :type key: str         :param value: A value for the XCom. The value is pickled and stored             in the database.         :type value: any picklable object         :param execution_date: if provided, the XCom will not be visible until             this date. This can be used, for example, to send a message to a             task on a future date without it being immediately visible.         :type execution_date: datetime         :param session: Sqlalchemy ORM Session         :type session: Session         """ [73052,73672]
string: """         Make an XCom available for tasks to pull.          :param key: A key for the XCom         :type key: str         :param value: A value for the XCom. The value is pickled and stored             in the database.         :type value: any picklable object         :param execution_date: if provided, the XCom will not be visible until             this date. This can be used, for example, to send a message to a             task on a future date without it being immediately visible.         :type execution_date: datetime         :param session: Sqlalchemy ORM Session         :type session: Session         """ [73186,73806]
===
match
---
string: """         Checks whether the immediate dependents of this task instance have succeeded or have been skipped.         This is meant to be used by wait_for_downstream.          This is useful when you do not want to start processing the next         schedule of a task until the dependents are done. For instance,         if the task DROPs and recreates a table.          :param session: SQLAlchemy ORM Session         :type session: Session         """ [25469,25922]
string: """         Checks whether the immediate dependents of this task instance have succeeded or have been skipped.         This is meant to be used by wait_for_downstream.          This is useful when you do not want to start processing the next         schedule of a task until the dependents are done. For instance,         if the task DROPs and recreates a table.          :param session: SQLAlchemy ORM Session         :type session: Session         """ [25469,25922]
===
match
---
operator: , [32680,32681]
operator: , [32680,32681]
===
match
---
name: _safe_date [58313,58323]
name: _safe_date [58447,58457]
===
match
---
simple_stmt [40242,40274]
simple_stmt [40242,40274]
===
match
---
trailer [66366,66405]
trailer [66500,66539]
===
match
---
string: """Return TI Context""" [59702,59725]
string: """Return TI Context""" [59836,59859]
===
match
---
name: max [34531,34534]
name: max [34531,34534]
===
match
---
name: task [46605,46609]
name: task [46605,46609]
===
match
---
name: parse [1130,1135]
name: parse [1130,1135]
===
match
---
atom_expr [43539,43913]
atom_expr [43539,43913]
===
match
---
trailer [4024,4029]
trailer [4024,4029]
===
match
---
trailer [19555,19557]
trailer [19555,19557]
===
match
---
trailer [80056,80068]
trailer [80190,80202]
===
match
---
name: task_id [43736,43743]
name: task_id [43736,43743]
===
match
---
string: 'next_ds_nodash' [64693,64709]
string: 'next_ds_nodash' [64827,64843]
===
match
---
param [14084,14103]
param [14084,14103]
===
match
---
trailer [78444,78459]
trailer [78578,78593]
===
match
---
atom_expr [39756,39837]
atom_expr [39756,39837]
===
match
---
name: default_html_content [72023,72043]
name: default_html_content [72157,72177]
===
match
---
name: self [81108,81112]
name: self [81242,81246]
===
match
---
atom_expr [55364,55611]
atom_expr [55364,55611]
===
match
---
trailer [11987,12002]
trailer [11987,12002]
===
match
---
trailer [7473,7482]
trailer [7473,7482]
===
match
---
trailer [60496,60506]
trailer [60630,60640]
===
match
---
operator: , [65436,65437]
operator: , [65570,65571]
===
match
---
name: Integer [9831,9838]
name: Integer [9831,9838]
===
match
---
operator: @ [15472,15473]
operator: @ [15472,15473]
===
match
---
trailer [53784,53824]
trailer [53784,53824]
===
match
---
simple_stmt [34678,34724]
simple_stmt [34678,34724]
===
match
---
operator: @ [63975,63976]
operator: @ [64109,64110]
===
match
---
name: airflow [82445,82452]
name: airflow [82579,82586]
===
match
---
name: ignore_depends_on_past [39576,39598]
name: ignore_depends_on_past [39576,39598]
===
match
---
atom_expr [52513,52523]
atom_expr [52513,52523]
===
match
---
name: TaskInstance [21717,21729]
name: TaskInstance [21717,21729]
===
match
---
trailer [42812,42817]
trailer [42812,42817]
===
match
---
simple_stmt [66359,66406]
simple_stmt [66493,66540]
===
match
---
argument [68649,68689]
argument [68783,68823]
===
match
---
trailer [32934,32942]
trailer [32934,32942]
===
match
---
param [41348,41352]
param [41348,41352]
===
match
---
comparison [35411,35455]
comparison [35411,35455]
===
match
---
trailer [34996,34998]
trailer [34996,34998]
===
match
---
operator: , [10735,10736]
operator: , [10735,10736]
===
match
---
testlist_comp [66497,66535]
testlist_comp [66631,66669]
===
match
---
trailer [26290,26294]
trailer [26290,26294]
===
match
---
simple_stmt [9887,9919]
simple_stmt [9887,9919]
===
match
---
name: dag_id [19730,19736]
name: dag_id [19730,19736]
===
match
---
atom_expr [20944,20963]
atom_expr [20944,20963]
===
match
---
trailer [62132,62140]
trailer [62266,62274]
===
match
---
name: exc_info [47905,47913]
name: exc_info [47905,47913]
===
match
---
arith_expr [72691,72722]
arith_expr [72825,72856]
===
match
---
operator: , [72317,72318]
operator: , [72451,72452]
===
match
---
name: self [53780,53784]
name: self [53780,53784]
===
match
---
simple_stmt [7259,7287]
simple_stmt [7259,7287]
===
match
---
if_stmt [62227,62282]
if_stmt [62361,62416]
===
match
---
string: "Setting task state for %s to %s" [24713,24746]
string: "Setting task state for %s to %s" [24713,24746]
===
match
---
name: XCom [76754,76758]
name: XCom [76888,76892]
===
match
---
name: self [66453,66457]
name: self [66587,66591]
===
match
---
trailer [7686,7693]
trailer [7686,7693]
===
match
---
string: 'value' [65792,65799]
string: 'value' [65926,65933]
===
match
---
not_test [40661,40674]
not_test [40661,40674]
===
match
---
name: str [74336,74339]
name: str [74470,74473]
===
match
---
if_stmt [67631,67800]
if_stmt [67765,67934]
===
match
---
name: join [49243,49247]
name: join [49243,49247]
===
match
---
atom_expr [5520,5532]
atom_expr [5520,5532]
===
match
---
name: fmt [59553,59556]
name: fmt [59687,59690]
===
match
---
operator: , [41418,41419]
operator: , [41418,41419]
===
match
---
name: skippable_task_ids [47208,47226]
name: skippable_task_ids [47208,47226]
===
match
---
operator: = [76305,76306]
operator: = [76439,76440]
===
match
---
name: Column [9470,9476]
name: Column [9470,9476]
===
match
---
operator: , [29792,29793]
operator: , [29792,29793]
===
match
---
atom_expr [71275,71540]
atom_expr [71409,71674]
===
match
---
trailer [68567,68589]
trailer [68701,68723]
===
match
---
string: 'utf-8' [33906,33913]
string: 'utf-8' [33906,33913]
===
match
---
return_stmt [63303,63353]
return_stmt [63437,63487]
===
match
---
atom_expr [55251,55268]
atom_expr [55251,55268]
===
match
---
operator: = [41703,41704]
operator: = [41703,41704]
===
match
---
trailer [42796,42798]
trailer [42796,42798]
===
match
---
atom_expr [42976,43036]
atom_expr [42976,43036]
===
match
---
name: test_mode [44235,44244]
name: test_mode [44235,44244]
===
match
---
string: ':' [62023,62026]
string: ':' [62157,62160]
===
match
---
parameters [41341,41353]
parameters [41341,41353]
===
match
---
name: self [62364,62368]
name: self [62498,62502]
===
match
---
atom_expr [71759,71769]
atom_expr [71893,71903]
===
match
---
name: ti [80234,80236]
name: ti [80368,80370]
===
match
---
name: subject [72522,72529]
name: subject [72656,72663]
===
match
---
name: with_try_number [8580,8595]
name: with_try_number [8580,8595]
===
match
---
name: state [25331,25336]
name: state [25331,25336]
===
match
---
atom_expr [58814,58833]
atom_expr [58948,58967]
===
match
---
expr_stmt [77024,77070]
expr_stmt [77158,77204]
===
match
---
name: tis [4713,4716]
name: tis [4713,4716]
===
match
---
operator: = [22073,22074]
operator: = [22073,22074]
===
match
---
string: """         Clears all XCom data from the database for the task instance          :param session: SQLAlchemy ORM Session         :type session: Session         """ [23677,23840]
string: """         Clears all XCom data from the database for the task instance          :param session: SQLAlchemy ORM Session         :type session: Session         """ [23677,23840]
===
match
---
decorated [8316,8571]
decorated [8316,8571]
===
match
---
trailer [40515,40581]
trailer [40515,40581]
===
match
---
operator: -> [8156,8158]
operator: -> [8156,8158]
===
match
---
name: SUCCESS [43123,43130]
name: SUCCESS [43123,43130]
===
match
---
trailer [24020,24035]
trailer [24020,24035]
===
match
---
atom_expr [37403,37412]
atom_expr [37403,37412]
===
match
---
param [63918,63922]
param [64052,64056]
===
match
---
name: _try_number [22308,22319]
name: _try_number [22308,22319]
===
match
---
trailer [45447,45465]
trailer [45447,45465]
===
match
---
name: ApiClient [68861,68870]
name: ApiClient [68995,69004]
===
match
---
name: self [21642,21646]
name: self [21642,21646]
===
match
---
name: non_requeueable_dep_context [38078,38105]
name: non_requeueable_dep_context [38078,38105]
===
match
---
name: next_retry_datetime [32992,33011]
name: next_retry_datetime [32992,33011]
===
match
---
import_from [82395,82435]
import_from [82529,82569]
===
match
---
trailer [26284,26290]
trailer [26284,26290]
===
match
---
name: self [41414,41418]
name: self [41414,41418]
===
match
---
simple_stmt [20972,20989]
simple_stmt [20972,20989]
===
match
---
trailer [45178,45185]
trailer [45178,45185]
===
match
---
name: next_retry_datetime [34977,34996]
name: next_retry_datetime [34977,34996]
===
match
---
atom_expr [62294,62350]
atom_expr [62428,62484]
===
match
---
sync_comp_for [49260,49300]
sync_comp_for [49260,49300]
===
match
---
string: 'dag_run' [64436,64445]
string: 'dag_run' [64570,64579]
===
match
---
trailer [59349,59357]
trailer [59483,59491]
===
match
---
operator: , [64982,64983]
operator: , [65116,65117]
===
match
---
simple_stmt [44212,44286]
simple_stmt [44212,44286]
===
match
---
atom_expr [22740,22756]
atom_expr [22740,22756]
===
match
---
operator: = [10569,10570]
operator: = [10569,10570]
===
match
---
trailer [56741,56786]
trailer [56875,56920]
===
match
---
name: execution_date [35418,35432]
name: execution_date [35418,35432]
===
match
---
name: provide_session [35025,35040]
name: provide_session [35025,35040]
===
match
---
name: get_previous_start_date [65238,65261]
name: get_previous_start_date [65372,65395]
===
match
---
operator: , [1075,1076]
operator: , [1075,1076]
===
match
---
simple_stmt [42922,42960]
simple_stmt [42922,42960]
===
match
---
name: self [32429,32433]
name: self [32429,32433]
===
match
---
trailer [51768,51803]
trailer [51768,51803]
===
match
---
name: dag_id [76161,76167]
name: dag_id [76295,76301]
===
match
---
operator: = [37593,37594]
operator: = [37593,37594]
===
match
---
name: TaskFail [56948,56956]
name: TaskFail [57082,57090]
===
match
---
name: datetime [8090,8098]
name: datetime [8090,8098]
===
match
---
operator: , [67736,67737]
operator: , [67870,67871]
===
match
---
expr_stmt [17924,17956]
expr_stmt [17924,17956]
===
match
---
operator: , [15424,15425]
operator: , [15424,15425]
===
match
---
name: provide_session [50629,50644]
name: provide_session [50629,50644]
===
match
---
operator: = [7891,7892]
operator: = [7891,7892]
===
match
---
name: task [53242,53246]
name: task [53242,53246]
===
match
---
name: Optional [1095,1103]
name: Optional [1095,1103]
===
match
---
name: UP_FOR_RETRY [25346,25358]
name: UP_FOR_RETRY [25346,25358]
===
match
---
name: qry [21565,21568]
name: qry [21565,21568]
===
match
---
name: downstream_task_ids [26396,26415]
name: downstream_task_ids [26396,26415]
===
match
---
atom_expr [76754,76784]
atom_expr [76888,76918]
===
match
---
param [35753,35784]
param [35753,35784]
===
match
---
trailer [41168,41173]
trailer [41168,41173]
===
match
---
name: path [70853,70857]
name: path [70987,70991]
===
match
---
simple_stmt [31645,31660]
simple_stmt [31645,31660]
===
match
---
name: self [24318,24322]
name: self [24318,24322]
===
match
---
param [62969,62973]
param [63103,63107]
===
match
---
funcdef [67507,67800]
funcdef [67641,67934]
===
match
---
name: State [52799,52804]
name: State [52799,52804]
===
match
---
name: result [51796,51802]
name: result [51796,51802]
===
match
---
name: conf [67794,67798]
name: conf [67928,67932]
===
match
---
trailer [56170,56175]
trailer [56170,56175]
===
match
---
trailer [24908,24921]
trailer [24908,24921]
===
match
---
trailer [77068,77070]
trailer [77202,77204]
===
match
---
param [51062,51070]
param [51062,51070]
===
match
---
name: state [29765,29770]
name: state [29765,29770]
===
match
---
string: 'execution_date' [58324,58340]
string: 'execution_date' [58458,58474]
===
match
---
name: str [41698,41701]
name: str [41698,41701]
===
match
---
name: self [8342,8346]
name: self [8342,8346]
===
match
---
param [45704,45709]
param [45704,45709]
===
match
---
trailer [63811,63815]
trailer [63945,63949]
===
match
---
expr_stmt [47134,47227]
expr_stmt [47134,47227]
===
match
---
name: task [52028,52032]
name: task [52028,52032]
===
match
---
atom_expr [44543,44556]
atom_expr [44543,44556]
===
match
---
name: count [26346,26351]
name: count [26346,26351]
===
match
---
trailer [60189,60249]
trailer [60323,60383]
===
match
---
simple_stmt [23379,23429]
simple_stmt [23379,23429]
===
match
---
return_stmt [24282,24369]
return_stmt [24282,24369]
===
match
---
name: _update_ti_state_for_sensing [50235,50263]
name: _update_ti_state_for_sensing [50235,50263]
===
match
---
arglist [44793,44828]
arglist [44793,44828]
===
match
---
name: registered [49753,49763]
name: registered [49753,49763]
===
match
---
name: session [23894,23901]
name: session [23894,23901]
===
match
---
argument [38136,38172]
argument [38136,38172]
===
match
---
name: Stats [44877,44882]
name: Stats [44877,44882]
===
match
---
trailer [23575,23584]
trailer [23575,23584]
===
match
---
operator: = [60421,60422]
operator: = [60555,60556]
===
match
---
name: dag_id [77432,77438]
name: dag_id [77566,77572]
===
match
---
name: extend [18815,18821]
name: extend [18815,18821]
===
match
---
name: timezone [50827,50835]
name: timezone [50827,50835]
===
match
---
operator: , [71507,71508]
operator: , [71641,71642]
===
match
---
atom_expr [79681,79698]
atom_expr [79815,79832]
===
match
---
name: self [72707,72711]
name: self [72841,72845]
===
match
---
trailer [38571,38578]
trailer [38571,38578]
===
match
---
simple_stmt [66453,66477]
simple_stmt [66587,66611]
===
match
---
name: self [43500,43504]
name: self [43500,43504]
===
match
---
name: self [80795,80799]
name: self [80929,80933]
===
match
---
trailer [22307,22319]
trailer [22307,22319]
===
match
---
name: e [50066,50067]
name: e [50066,50067]
===
match
---
trailer [56767,56777]
trailer [56901,56911]
===
match
---
name: context [51608,51615]
name: context [51608,51615]
===
match
---
name: self [68333,68337]
name: self [68467,68471]
===
match
---
trailer [58122,58126]
trailer [58256,58260]
===
match
---
trailer [68002,68004]
trailer [68136,68138]
===
match
---
operator: , [81368,81369]
operator: , [81502,81503]
===
match
---
name: session [45508,45515]
name: session [45508,45515]
===
match
---
name: Iterable [1067,1075]
name: Iterable [1067,1075]
===
match
---
arglist [50066,50082]
arglist [50066,50082]
===
match
---
simple_stmt [69508,69876]
simple_stmt [69642,70010]
===
match
---
atom [69912,70273]
atom [70046,70407]
===
match
---
name: datetime [15617,15625]
name: datetime [15617,15625]
===
match
---
comparison [34972,35018]
comparison [34972,35018]
===
match
---
try_stmt [67230,67469]
try_stmt [67364,67603]
===
match
---
not_test [47306,47341]
not_test [47306,47341]
===
match
---
fstring_end: " [14769,14770]
fstring_end: " [14769,14770]
===
match
---
trailer [37482,37492]
trailer [37482,37492]
===
match
---
return_stmt [26002,26013]
return_stmt [26002,26013]
===
match
---
name: ti [5989,5991]
name: ti [5989,5991]
===
match
---
name: self [62732,62736]
name: self [62866,62870]
===
match
---
expr_stmt [69508,69875]
expr_stmt [69642,70009]
===
match
---
param [74397,74424]
param [74531,74558]
===
match
---
name: Exception [3957,3966]
name: Exception [3957,3966]
===
match
---
string: 'priority_weight' [80178,80195]
string: 'priority_weight' [80312,80329]
===
match
---
atom_expr [6689,7107]
atom_expr [6689,7107]
===
match
---
trailer [66209,66215]
trailer [66343,66349]
===
match
---
argument [48863,48885]
argument [48863,48885]
===
match
---
trailer [44231,44285]
trailer [44231,44285]
===
match
---
trailer [37747,37752]
trailer [37747,37752]
===
match
---
name: from_string [71129,71140]
name: from_string [71263,71274]
===
match
---
name: _CURRENT_CONTEXT [3641,3657]
name: _CURRENT_CONTEXT [3641,3657]
===
match
---
atom_expr [60358,60379]
atom_expr [60492,60513]
===
match
---
name: dag [27709,27712]
name: dag [27709,27712]
===
match
---
name: max_retry_delay [34700,34715]
name: max_retry_delay [34700,34715]
===
match
---
name: loads [4135,4140]
name: loads [4135,4140]
===
match
---
name: get [71716,71719]
name: get [71850,71853]
===
match
---
strings [43570,43684]
strings [43570,43684]
===
match
---
name: task_copy [49423,49432]
name: task_copy [49423,49432]
===
match
---
trailer [68813,68831]
trailer [68947,68965]
===
match
---
trailer [70968,70975]
trailer [71102,71109]
===
match
---
import_as_names [2759,2786]
import_as_names [2759,2786]
===
match
---
string: 'BASE_LOG_FOLDER' [19053,19070]
string: 'BASE_LOG_FOLDER' [19053,19070]
===
match
---
operator: = [10100,10101]
operator: = [10100,10101]
===
match
---
name: state [43109,43114]
name: state [43109,43114]
===
match
---
atom_expr [10257,10272]
atom_expr [10257,10272]
===
match
---
name: getLogger [3265,3274]
name: getLogger [3265,3274]
===
match
---
simple_stmt [19928,20210]
simple_stmt [19928,20210]
===
match
---
operator: , [48279,48280]
operator: , [48279,48280]
===
match
---
name: utcnow [7944,7950]
name: utcnow [7944,7950]
===
match
---
name: error_file [56150,56160]
name: error_file [56150,56160]
===
match
---
trailer [57683,57689]
trailer [57817,57823]
===
match
---
operator: = [31823,31824]
operator: = [31823,31824]
===
match
---
atom_expr [27664,27685]
atom_expr [27664,27685]
===
match
---
name: end_date [55534,55542]
name: end_date [55534,55542]
===
match
---
trailer [30254,30265]
trailer [30254,30265]
===
match
---
name: _priority_weight [81062,81078]
name: _priority_weight [81196,81212]
===
match
---
operator: = [68410,68411]
operator: = [68544,68545]
===
match
---
atom_expr [61881,61900]
atom_expr [62015,62034]
===
match
---
expr_stmt [29566,29626]
expr_stmt [29566,29626]
===
match
---
name: session [38503,38510]
name: session [38503,38510]
===
match
---
name: self [45460,45464]
name: self [45460,45464]
===
match
---
name: dag [14577,14580]
name: dag [14577,14580]
===
match
---
atom_expr [3539,3571]
atom_expr [3539,3571]
===
match
---
operator: = [46853,46854]
operator: = [46853,46854]
===
match
---
operator: @ [35024,35025]
operator: @ [35024,35025]
===
match
---
try_stmt [2868,3167]
try_stmt [2868,3167]
===
match
---
name: OperationalError [1392,1408]
name: OperationalError [1392,1408]
===
match
---
name: get_task_instance [27999,28016]
name: get_task_instance [27999,28016]
===
match
---
expr_stmt [62100,62149]
expr_stmt [62234,62283]
===
match
---
name: self [23949,23953]
name: self [23949,23953]
===
match
---
simple_stmt [50711,50766]
simple_stmt [50711,50766]
===
match
---
trailer [53070,53075]
trailer [53070,53075]
===
match
---
atom_expr [77031,77070]
atom_expr [77165,77204]
===
match
---
param [11101,11126]
param [11101,11126]
===
match
---
operator: , [65932,65933]
operator: , [66066,66067]
===
match
---
name: Index [10715,10720]
name: Index [10715,10720]
===
match
---
operator: , [1304,1305]
operator: , [1304,1305]
===
match
---
argument [15339,15353]
argument [15339,15353]
===
match
---
suite [26565,28069]
suite [26565,28069]
===
match
---
trailer [7223,7230]
trailer [7223,7230]
===
match
---
name: self [76269,76273]
name: self [76403,76407]
===
match
---
decorator [12652,12662]
decorator [12652,12662]
===
match
---
name: session [24087,24094]
name: session [24087,24094]
===
match
---
atom_expr [73759,73947]
atom_expr [73893,74081]
===
match
---
atom_expr [56963,56982]
atom_expr [57097,57116]
===
match
---
name: Index [1313,1318]
name: Index [1313,1318]
===
match
---
name: RUNNING [7899,7906]
name: RUNNING [7899,7906]
===
match
---
if_stmt [43389,43433]
if_stmt [43389,43433]
===
match
---
name: query [21579,21584]
name: query [21579,21584]
===
match
---
string: '' [62146,62148]
string: '' [62280,62282]
===
match
---
arith_expr [71442,71461]
arith_expr [71576,71595]
===
match
---
atom_expr [74066,74077]
atom_expr [74200,74211]
===
match
---
operator: , [39621,39622]
operator: , [39621,39622]
===
match
---
atom_expr [56871,56894]
atom_expr [57005,57028]
===
match
---
name: downstream_task_ids [25969,25988]
name: downstream_task_ids [25969,25988]
===
match
---
name: raw [77686,77689]
name: raw [77820,77823]
===
match
---
simple_stmt [47134,47228]
simple_stmt [47134,47228]
===
match
---
sync_comp_for [7135,7178]
sync_comp_for [7135,7178]
===
match
---
atom [25009,25042]
atom [25009,25042]
===
match
---
name: airflow [1567,1574]
name: airflow [1567,1574]
===
match
---
trailer [19032,19072]
trailer [19032,19072]
===
match
---
operator: , [14102,14103]
operator: , [14102,14103]
===
match
---
string: 'execution_date' [43781,43797]
string: 'execution_date' [43781,43797]
===
match
---
name: kubernetes [2946,2956]
name: kubernetes [2946,2956]
===
match
---
name: extend [18580,18586]
name: extend [18580,18586]
===
match
---
simple_stmt [53743,53766]
simple_stmt [53743,53766]
===
match
---
simple_stmt [61406,61457]
simple_stmt [61540,61591]
===
match
---
name: ti [5149,5151]
name: ti [5149,5151]
===
match
---
operator: = [72988,72989]
operator: = [73122,73123]
===
match
---
name: dag [61264,61267]
name: dag [61398,61401]
===
match
---
simple_stmt [18576,18600]
simple_stmt [18576,18600]
===
match
---
atom_expr [12057,12070]
atom_expr [12057,12070]
===
match
---
simple_stmt [3214,3251]
simple_stmt [3214,3251]
===
match
---
name: ApiClient [3150,3159]
name: ApiClient [3150,3159]
===
match
---
atom_expr [9780,9790]
atom_expr [9780,9790]
===
match
---
string: 'ds_nodash' [64490,64501]
string: 'ds_nodash' [64624,64635]
===
match
---
name: execution_date [26221,26235]
name: execution_date [26221,26235]
===
match
---
decorator [24375,24392]
decorator [24375,24392]
===
match
---
decorated [35512,41318]
decorated [35512,41318]
===
match
---
simple_stmt [72143,72190]
simple_stmt [72277,72324]
===
match
---
trailer [81840,82016]
trailer [81974,82150]
===
match
---
param [53524,53554]
param [53524,53554]
===
match
---
trailer [80097,80102]
trailer [80231,80236]
===
match
---
name: property [8317,8325]
name: property [8317,8325]
===
match
---
trailer [62179,62186]
trailer [62313,62320]
===
match
---
name: __getattr__ [63714,63725]
name: __getattr__ [63848,63859]
===
match
---
tfpdef [41719,41738]
tfpdef [41719,41738]
===
match
---
suite [58658,58775]
suite [58792,58909]
===
match
---
name: key [71678,71681]
name: key [71812,71815]
===
match
---
testlist_comp [18135,18161]
testlist_comp [18135,18161]
===
match
---
name: job_id [35901,35907]
name: job_id [35901,35907]
===
match
---
number: 16 [33962,33964]
number: 16 [33962,33964]
===
match
---
fstring_expr [48679,48697]
fstring_expr [48679,48697]
===
match
---
name: self [26239,26243]
name: self [26239,26243]
===
match
---
return_stmt [41463,41500]
return_stmt [41463,41500]
===
match
---
name: force_fail [57620,57630]
name: force_fail [57754,57764]
===
match
---
trailer [44882,44887]
trailer [44882,44887]
===
match
---
trailer [23857,23863]
trailer [23857,23863]
===
match
---
simple_stmt [30364,30512]
simple_stmt [30364,30512]
===
match
---
comparison [79165,79213]
comparison [79299,79347]
===
match
---
operator: = [59156,59157]
operator: = [59290,59291]
===
match
---
operator: = [22757,22758]
operator: = [22757,22758]
===
match
---
trailer [11482,11495]
trailer [11482,11495]
===
match
---
name: session [39119,39126]
name: session [39119,39126]
===
match
---
name: force_fail [56116,56126]
name: force_fail [56116,56126]
===
match
---
param [81176,81180]
param [81310,81314]
===
match
---
name: query [76815,76820]
name: query [76949,76954]
===
match
---
trailer [68205,68219]
trailer [68339,68353]
===
match
---
name: provide_session [25396,25411]
name: provide_session [25396,25411]
===
match
---
name: get_template_context [53158,53178]
name: get_template_context [53158,53178]
===
match
---
simple_stmt [35497,35507]
simple_stmt [35497,35507]
===
match
---
import_from [48094,48164]
import_from [48094,48164]
===
match
---
name: airflow [1929,1936]
name: airflow [1929,1936]
===
match
---
atom_expr [39001,39011]
atom_expr [39001,39011]
===
match
---
suite [80730,80761]
suite [80864,80895]
===
match
---
operator: = [46669,46670]
operator: = [46669,46670]
===
match
---
decorator [77149,77166]
decorator [77283,77300]
===
match
---
trailer [18133,18163]
trailer [18133,18163]
===
match
---
name: self [62881,62885]
name: self [63015,63019]
===
match
---
atom_expr [7893,7906]
atom_expr [7893,7906]
===
match
---
name: DepContext [39460,39470]
name: DepContext [39460,39470]
===
match
---
name: _execution_date [81990,82005]
name: _execution_date [82124,82139]
===
match
---
trailer [65201,65207]
trailer [65335,65341]
===
match
---
simple_stmt [1507,1561]
simple_stmt [1507,1561]
===
match
---
if_stmt [78716,79009]
if_stmt [78850,79143]
===
match
---
and_test [37653,37728]
and_test [37653,37728]
===
match
---
name: signum [48273,48279]
name: signum [48273,48279]
===
match
---
trailer [56870,56895]
trailer [57004,57029]
===
match
---
simple_stmt [10303,10354]
simple_stmt [10303,10354]
===
match
---
name: file_path [15339,15348]
name: file_path [15339,15348]
===
match
---
decorator [45639,45661]
decorator [45639,45661]
===
match
---
trailer [43449,43465]
trailer [43449,43465]
===
match
---
operator: = [37624,37625]
operator: = [37624,37625]
===
match
---
trailer [6036,6040]
trailer [6036,6040]
===
match
---
name: _handle_reschedule [44033,44051]
name: _handle_reschedule [44033,44051]
===
match
---
name: str [35918,35921]
name: str [35918,35921]
===
match
---
trailer [40250,40258]
trailer [40250,40258]
===
match
---
parameters [63059,63236]
parameters [63193,63370]
===
match
---
decorator [29097,29114]
decorator [29097,29114]
===
match
---
param [71619,71623]
param [71753,71757]
===
match
---
funcdef [41571,45613]
funcdef [41571,45613]
===
match
---
operator: , [4284,4285]
operator: , [4284,4285]
===
match
---
expr_stmt [81800,82016]
expr_stmt [81934,82150]
===
match
---
trailer [6005,6010]
trailer [6005,6010]
===
match
---
tfpdef [72915,72923]
tfpdef [73049,73057]
===
match
---
operator: -> [80801,80803]
operator: -> [80935,80937]
===
match
---
name: prev_ti [29672,29679]
name: prev_ti [29672,29679]
===
match
---
operator: == [23946,23948]
operator: == [23946,23948]
===
match
---
arith_expr [25010,25041]
arith_expr [25010,25041]
===
match
---
name: primary_key [9511,9522]
name: primary_key [9511,9522]
===
match
---
argument [48854,48861]
argument [48854,48861]
===
match
---
simple_stmt [47367,47436]
simple_stmt [47367,47436]
===
match
---
atom_expr [26311,26324]
atom_expr [26311,26324]
===
match
---
atom_expr [52799,52812]
atom_expr [52799,52812]
===
match
---
name: extend [18360,18366]
name: extend [18360,18366]
===
match
---
fstring_string: / [19128,19129]
fstring_string: / [19128,19129]
===
match
---
name: include_prior_dates [74433,74452]
name: include_prior_dates [74567,74586]
===
match
---
name: Log [45444,45447]
name: Log [45444,45447]
===
match
---
atom_expr [3198,3212]
atom_expr [3198,3212]
===
match
---
operator: = [14333,14334]
operator: = [14333,14334]
===
match
---
name: ceil [33576,33580]
name: ceil [33576,33580]
===
match
---
suite [44341,44709]
suite [44341,44709]
===
match
---
decorated [19427,19848]
decorated [19427,19848]
===
match
---
if_stmt [41363,41501]
if_stmt [41363,41501]
===
match
---
trailer [40478,40493]
trailer [40478,40493]
===
match
---
name: tempfile [998,1006]
name: tempfile [998,1006]
===
match
---
name: self [12057,12061]
name: self [12057,12061]
===
match
---
name: pool [42632,42636]
name: pool [42632,42636]
===
match
---
name: task [53071,53075]
name: task [53071,53075]
===
match
---
if_stmt [67939,68005]
if_stmt [68073,68139]
===
match
---
number: 1 [50582,50583]
number: 1 [50582,50583]
===
match
---
simple_stmt [20530,20550]
simple_stmt [20530,20550]
===
match
---
param [55115,55127]
param [55115,55127]
===
match
---
name: utils [2618,2623]
name: utils [2618,2623]
===
match
---
string: """         Generates the shell command required to execute this task instance.          :param dag_id: DAG ID         :type dag_id: str         :param task_id: Task ID         :type task_id: str         :param execution_date: Execution date for the task         :type execution_date: datetime         :param mark_success: Whether to mark the task as successful         :type mark_success: bool         :param ignore_all_deps: Ignore all ignorable dependencies.             Overrides the other ignore_* parameters.         :type ignore_all_deps: bool         :param ignore_depends_on_past: Ignore depends_on_past parameter of DAGs             (e.g. for Backfills)         :type ignore_depends_on_past: bool         :param ignore_task_deps: Ignore task-specific dependencies such as depends_on_past             and trigger rule         :type ignore_task_deps: bool         :param ignore_ti_state: Ignore the task instance's previous failure/success         :type ignore_ti_state: bool         :param local: Whether to run the task locally         :type local: bool         :param pickle_id: If the DAG was serialized to the DB, the ID             associated with the pickled DAG         :type pickle_id: Optional[int]         :param file_path: path to the file containing the DAG definition         :type file_path: Optional[str]         :param raw: raw mode (needs more details)         :type raw: Optional[bool]         :param job_id: job ID (needs more details)         :type job_id: Optional[int]         :param pool: the Airflow pool that the task should run in         :type pool: Optional[str]         :param cfg_path: the Path to the configuration file         :type cfg_path: Optional[str]         :return: shell command that can be used to run the task instance         :rtype: list[str]         """ [16107,17915]
string: """         Generates the shell command required to execute this task instance.          :param dag_id: DAG ID         :type dag_id: str         :param task_id: Task ID         :type task_id: str         :param execution_date: Execution date for the task         :type execution_date: datetime         :param mark_success: Whether to mark the task as successful         :type mark_success: bool         :param ignore_all_deps: Ignore all ignorable dependencies.             Overrides the other ignore_* parameters.         :type ignore_all_deps: bool         :param ignore_depends_on_past: Ignore depends_on_past parameter of DAGs             (e.g. for Backfills)         :type ignore_depends_on_past: bool         :param ignore_task_deps: Ignore task-specific dependencies such as depends_on_past             and trigger rule         :type ignore_task_deps: bool         :param ignore_ti_state: Ignore the task instance's previous failure/success         :type ignore_ti_state: bool         :param local: Whether to run the task locally         :type local: bool         :param pickle_id: If the DAG was serialized to the DB, the ID             associated with the pickled DAG         :type pickle_id: Optional[int]         :param file_path: path to the file containing the DAG definition         :type file_path: Optional[str]         :param raw: raw mode (needs more details)         :type raw: Optional[bool]         :param job_id: job ID (needs more details)         :type job_id: Optional[int]         :param pool: the Airflow pool that the task should run in         :type pool: Optional[str]         :param cfg_path: the Path to the configuration file         :type cfg_path: Optional[str]         :return: shell command that can be used to run the task instance         :rtype: list[str]         """ [16107,17915]
===
match
---
tfpdef [72933,72943]
tfpdef [73067,73077]
===
match
---
name: client [2893,2899]
name: client [2893,2899]
===
match
---
operator: , [40129,40130]
operator: , [40129,40130]
===
match
---
operator: , [64476,64477]
operator: , [64610,64611]
===
match
---
name: task [41169,41173]
name: task [41169,41173]
===
match
---
expr_stmt [35320,35487]
expr_stmt [35320,35487]
===
match
---
trailer [71997,72044]
trailer [72131,72178]
===
match
---
name: cmd [18629,18632]
name: cmd [18629,18632]
===
match
---
trailer [56988,56999]
trailer [57122,57133]
===
match
---
suite [33018,34761]
suite [33018,34761]
===
match
---
trailer [20951,20957]
trailer [20951,20957]
===
match
---
atom_expr [55873,55889]
atom_expr [55873,55889]
===
match
---
name: session [27913,27920]
name: session [27913,27920]
===
match
---
trailer [46059,46186]
trailer [46059,46186]
===
match
---
with_stmt [50310,50409]
with_stmt [50310,50409]
===
match
---
simple_stmt [47453,47497]
simple_stmt [47453,47497]
===
match
---
trailer [79177,79192]
trailer [79311,79326]
===
match
---
name: self [58282,58286]
name: self [58416,58420]
===
match
---
name: self [21550,21554]
name: self [21550,21554]
===
match
---
name: incr [50602,50606]
name: incr [50602,50606]
===
match
---
trailer [27904,27934]
trailer [27904,27934]
===
match
---
name: self [30151,30155]
name: self [30151,30155]
===
match
---
name: start_date [24801,24811]
name: start_date [24801,24811]
===
match
---
param [14348,14362]
param [14348,14362]
===
match
---
name: incr [37748,37752]
name: incr [37748,37752]
===
match
---
atom_expr [5564,5577]
atom_expr [5564,5577]
===
match
---
trailer [22627,22633]
trailer [22627,22633]
===
match
---
name: datetime [11117,11125]
name: datetime [11117,11125]
===
match
---
operator: , [9490,9491]
operator: , [9490,9491]
===
match
---
trailer [5188,5196]
trailer [5188,5196]
===
match
---
name: self [24993,24997]
name: self [24993,24997]
===
match
---
name: state [32973,32978]
name: state [32973,32978]
===
match
---
atom_expr [25009,25058]
atom_expr [25009,25058]
===
match
---
expr_stmt [47453,47496]
expr_stmt [47453,47496]
===
match
---
trailer [7081,7087]
trailer [7081,7087]
===
match
---
simple_stmt [48174,48215]
simple_stmt [48174,48215]
===
match
---
simple_stmt [30084,30133]
simple_stmt [30084,30133]
===
match
---
name: get_previous_ti [30156,30171]
name: get_previous_ti [30156,30171]
===
match
---
simple_stmt [24112,24148]
simple_stmt [24112,24148]
===
match
---
simple_stmt [26346,26363]
simple_stmt [26346,26363]
===
match
---
name: first [77063,77068]
name: first [77197,77202]
===
match
---
trailer [50606,50622]
trailer [50606,50622]
===
match
---
simple_stmt [32198,32210]
simple_stmt [32198,32210]
===
match
---
trailer [45443,45466]
trailer [45443,45466]
===
match
---
name: kube_config [68411,68422]
name: kube_config [68545,68556]
===
match
---
operator: } [44570,44571]
operator: } [44570,44571]
===
match
---
name: self [41266,41270]
name: self [41266,41270]
===
match
---
param [35624,35629]
param [35624,35629]
===
match
---
name: cmd [18195,18198]
name: cmd [18195,18198]
===
match
---
decorated [81232,81310]
decorated [81366,81444]
===
match
---
trailer [61997,62005]
trailer [62131,62139]
===
match
---
atom_expr [68014,68055]
atom_expr [68148,68189]
===
match
---
trailer [68018,68023]
trailer [68152,68157]
===
match
---
atom_expr [23456,23472]
atom_expr [23456,23472]
===
match
---
trailer [80142,80147]
trailer [80276,80281]
===
match
---
trailer [43518,43526]
trailer [43518,43526]
===
match
---
trailer [59096,59111]
trailer [59230,59245]
===
match
---
operator: = [78119,78120]
operator: = [78253,78254]
===
match
---
and_test [30217,30266]
and_test [30217,30266]
===
match
---
if_stmt [38998,39237]
if_stmt [38998,39237]
===
match
---
atom_expr [59340,59357]
atom_expr [59474,59491]
===
match
---
name: SUCCESS [26317,26324]
name: SUCCESS [26317,26324]
===
match
---
name: dep_status [32702,32712]
name: dep_status [32702,32712]
===
match
---
suite [66972,67502]
suite [67106,67636]
===
match
---
name: self [23258,23262]
name: self [23258,23262]
===
match
---
trailer [78656,78664]
trailer [78790,78798]
===
match
---
operator: = [9653,9654]
operator: = [9653,9654]
===
match
---
operator: , [35628,35629]
operator: , [35628,35629]
===
match
---
operator: , [27289,27290]
operator: , [27289,27290]
===
match
---
strings [69926,70263]
strings [70060,70397]
===
match
---
operator: , [4716,4717]
operator: , [4716,4717]
===
match
---
simple_stmt [67477,67502]
simple_stmt [67611,67636]
===
match
---
atom_expr [43049,43091]
atom_expr [43049,43091]
===
match
---
name: self [40357,40361]
name: self [40357,40361]
===
match
---
number: 256 [10116,10119]
number: 256 [10116,10119]
===
match
---
name: session [54185,54192]
name: session [54185,54192]
===
match
---
operator: , [62417,62418]
operator: , [62551,62552]
===
match
---
atom_expr [19578,19611]
atom_expr [19578,19611]
===
match
---
simple_stmt [3168,3188]
simple_stmt [3168,3188]
===
match
---
name: Union [58948,58953]
name: Union [59082,59087]
===
match
---
arglist [62083,62090]
arglist [62217,62224]
===
match
---
trailer [77708,77721]
trailer [77842,77855]
===
match
---
trailer [35953,35958]
trailer [35953,35958]
===
match
---
atom_expr [34739,34752]
atom_expr [34739,34752]
===
match
---
expr_stmt [57969,58000]
expr_stmt [58103,58134]
===
match
---
number: 2 [33606,33607]
number: 2 [33606,33607]
===
match
---
exprlist [7139,7152]
exprlist [7139,7152]
===
match
---
name: first [78204,78209]
name: first [78338,78343]
===
match
---
name: ti [79681,79683]
name: ti [79815,79817]
===
match
---
name: debug [72804,72809]
name: debug [72938,72943]
===
match
---
simple_stmt [71800,71819]
simple_stmt [71934,71953]
===
match
---
name: String [9905,9911]
name: String [9905,9911]
===
match
---
operator: = [70928,70929]
operator: = [71062,71063]
===
match
---
trailer [53684,53689]
trailer [53684,53689]
===
match
---
arglist [41244,41296]
arglist [41244,41296]
===
match
---
comparison [27664,27693]
comparison [27664,27693]
===
match
---
name: on_retry_callback [53096,53113]
name: on_retry_callback [53096,53113]
===
match
---
parameters [67825,67866]
parameters [67959,68000]
===
match
---
arglist [9556,9580]
arglist [9556,9580]
===
match
---
expr_stmt [24935,24980]
expr_stmt [24935,24980]
===
match
---
name: execution_date [55428,55442]
name: execution_date [55428,55442]
===
match
---
name: queue [23263,23268]
name: queue [23263,23268]
===
match
---
name: in_env_var_format [49114,49131]
name: in_env_var_format [49114,49131]
===
match
---
operator: @ [77149,77150]
operator: @ [77283,77284]
===
match
---
name: self [8739,8743]
name: self [8739,8743]
===
match
---
name: _run_raw_task [41575,41588]
name: _run_raw_task [41575,41588]
===
match
---
name: strftime [60443,60451]
name: strftime [60577,60585]
===
match
---
trailer [46554,46559]
trailer [46554,46559]
===
match
---
operator: = [6611,6612]
operator: = [6611,6612]
===
match
---
name: bool [56128,56132]
name: bool [56128,56132]
===
match
---
if_stmt [18029,18089]
if_stmt [18029,18089]
===
match
---
trailer [33898,33905]
trailer [33898,33905]
===
match
---
name: self [72627,72631]
name: self [72761,72765]
===
match
---
trailer [33942,33944]
trailer [33942,33944]
===
match
---
atom_expr [59194,59234]
atom_expr [59328,59368]
===
match
---
name: ti [79870,79872]
name: ti [80004,80006]
===
match
---
trailer [32433,32438]
trailer [32433,32438]
===
match
---
simple_stmt [916,952]
simple_stmt [916,952]
===
match
---
operator: , [41346,41347]
operator: , [41346,41347]
===
match
---
parameters [72570,72576]
parameters [72704,72710]
===
match
---
decorator [50628,50645]
decorator [50628,50645]
===
match
---
argument [26880,26895]
argument [26880,26895]
===
match
---
operator: } [19133,19134]
operator: } [19133,19134]
===
match
---
trailer [45012,45014]
trailer [45012,45014]
===
match
---
name: logging [842,849]
name: logging [842,849]
===
match
---
name: ti [82058,82060]
name: ti [82192,82194]
===
match
---
name: task [48038,48042]
name: task [48038,48042]
===
match
---
atom_expr [65463,65477]
atom_expr [65597,65611]
===
match
---
atom_expr [56984,56999]
atom_expr [57118,57133]
===
match
---
trailer [74315,74342]
trailer [74449,74476]
===
match
---
operator: , [62009,62010]
operator: , [62143,62144]
===
match
---
name: try_number [6098,6108]
name: try_number [6098,6108]
===
match
---
operator: , [56779,56780]
operator: , [56913,56914]
===
match
---
operator: = [71441,71442]
operator: = [71575,71576]
===
match
---
if_stmt [37650,37783]
if_stmt [37650,37783]
===
match
---
name: get_task [47403,47411]
name: get_task [47403,47411]
===
match
---
trailer [8770,8785]
trailer [8770,8785]
===
match
---
name: self [56022,56026]
name: self [56022,56026]
===
match
---
decorated [13327,13878]
decorated [13327,13878]
===
match
---
name: execution_date [11988,12002]
name: execution_date [11988,12002]
===
match
---
operator: = [24949,24950]
operator: = [24949,24950]
===
match
---
trailer [11887,11903]
trailer [11887,11903]
===
match
---
name: self [63743,63747]
name: self [63877,63881]
===
match
---
atom_expr [7456,7465]
atom_expr [7456,7465]
===
match
---
operator: , [55596,55597]
operator: , [55596,55597]
===
match
---
name: pickle_id [18151,18160]
name: pickle_id [18151,18160]
===
match
---
name: commit [60400,60406]
name: commit [60534,60540]
===
match
---
atom_expr [49331,49370]
atom_expr [49331,49370]
===
match
---
argument [44246,44261]
argument [44246,44261]
===
match
---
name: self [22373,22377]
name: self [22373,22377]
===
match
---
atom_expr [35411,35432]
atom_expr [35411,35432]
===
match
---
parameters [13274,13287]
parameters [13274,13287]
===
match
---
operator: , [51069,51070]
operator: , [51069,51070]
===
match
---
atom_expr [22563,22578]
atom_expr [22563,22578]
===
match
---
name: e [44758,44759]
name: e [44758,44759]
===
match
---
name: SUCCESS [44549,44556]
name: SUCCESS [44549,44556]
===
match
---
decorated [20615,20989]
decorated [20615,20989]
===
match
---
operator: = [23454,23455]
operator: = [23454,23455]
===
match
---
operator: = [22033,22034]
operator: = [22033,22034]
===
match
---
trailer [55858,55864]
trailer [55858,55864]
===
match
---
name: session [7374,7381]
name: session [7374,7381]
===
match
---
name: task_type [50569,50578]
name: task_type [50569,50578]
===
match
---
atom_expr [56593,56626]
atom_expr [56727,56760]
===
match
---
operator: = [64314,64315]
operator: = [64448,64449]
===
match
---
suite [5223,5308]
suite [5223,5308]
===
match
---
operator: = [9966,9967]
operator: = [9966,9967]
===
match
---
name: first [78159,78164]
name: first [78293,78298]
===
match
---
simple_stmt [60301,60346]
simple_stmt [60435,60480]
===
match
---
trailer [53824,54211]
trailer [53824,54211]
===
match
---
trailer [19691,19699]
trailer [19691,19699]
===
match
---
atom_expr [10715,10776]
atom_expr [10715,10776]
===
match
---
name: prev_ds [61593,61600]
name: prev_ds [61727,61734]
===
match
---
name: macros [59779,59785]
name: macros [59913,59919]
===
match
---
expr_stmt [19004,19072]
expr_stmt [19004,19072]
===
match
---
argument [30172,30183]
argument [30172,30183]
===
match
---
simple_stmt [81050,81079]
simple_stmt [81184,81213]
===
match
---
suite [39039,39237]
suite [39039,39237]
===
match
---
name: executor_config [23547,23562]
name: executor_config [23547,23562]
===
match
---
name: are_dependencies_met [30871,30891]
name: are_dependencies_met [30871,30891]
===
match
---
name: is_smart_sensor_compatible [49581,49607]
name: is_smart_sensor_compatible [49581,49607]
===
match
---
name: session [27905,27912]
name: session [27905,27912]
===
match
---
atom_expr [57001,57014]
atom_expr [57135,57148]
===
match
---
name: info [47166,47170]
name: info [47166,47170]
===
match
---
name: tis [5155,5158]
name: tis [5155,5158]
===
match
---
name: error_file [44274,44284]
name: error_file [44274,44284]
===
match
---
atom_expr [62255,62281]
atom_expr [62389,62415]
===
match
---
param [53484,53515]
param [53484,53515]
===
match
---
trailer [44985,44994]
trailer [44985,44994]
===
match
---
operator: , [72215,72216]
operator: , [72349,72350]
===
match
---
name: next_execution_date [61416,61435]
name: next_execution_date [61550,61569]
===
match
---
name: result [59537,59543]
name: result [59671,59677]
===
match
---
name: state [24862,24867]
name: state [24862,24867]
===
match
---
name: mark_success [15046,15058]
name: mark_success [15046,15058]
===
match
---
name: self [74066,74070]
name: self [74200,74204]
===
match
---
atom_expr [10893,11070]
atom_expr [10893,11070]
===
match
---
parameters [80938,80944]
parameters [81072,81078]
===
match
---
operator: , [21039,21040]
operator: , [21039,21040]
===
match
---
name: state [57684,57689]
name: state [57818,57823]
===
match
---
suite [53046,53274]
suite [53046,53274]
===
match
---
string: """         Checks dependencies and then sets state to RUNNING if they are met. Returns         True if and only if state is set to RUNNING, which implies that task should be         executed, in preparation for _run_raw_task          :param verbose: whether to turn on more verbose logging         :type verbose: bool         :param ignore_all_deps: Ignore all of the non-critical dependencies, just runs         :type ignore_all_deps: bool         :param ignore_depends_on_past: Ignore depends_on_past DAG attribute         :type ignore_depends_on_past: bool         :param ignore_task_deps: Don't check the dependencies of this TaskInstance's task         :type ignore_task_deps: bool         :param ignore_ti_state: Disregards previous task instance state         :type ignore_ti_state: bool         :param mark_success: Don't run the task, mark its state as success         :type mark_success: bool         :param test_mode: Doesn't record success or failure in the DB         :type test_mode: bool         :param job_id: Job (BackfillJob / LocalTaskJob / SchedulerJob) ID         :type job_id: str         :param pool: specifies the pool to use to run the task instance         :type pool: str         :param session: SQLAlchemy ORM Session         :type session: Session         :return: whether the state was changed to running or not         :rtype: bool         """ [36012,37387]
string: """         Checks dependencies and then sets state to RUNNING if they are met. Returns         True if and only if state is set to RUNNING, which implies that task should be         executed, in preparation for _run_raw_task          :param verbose: whether to turn on more verbose logging         :type verbose: bool         :param ignore_all_deps: Ignore all of the non-critical dependencies, just runs         :type ignore_all_deps: bool         :param ignore_depends_on_past: Ignore depends_on_past DAG attribute         :type ignore_depends_on_past: bool         :param ignore_task_deps: Don't check the dependencies of this TaskInstance's task         :type ignore_task_deps: bool         :param ignore_ti_state: Disregards previous task instance state         :type ignore_ti_state: bool         :param mark_success: Don't run the task, mark its state as success         :type mark_success: bool         :param test_mode: Doesn't record success or failure in the DB         :type test_mode: bool         :param job_id: Job (BackfillJob / LocalTaskJob / SchedulerJob) ID         :type job_id: str         :param pool: specifies the pool to use to run the task instance         :type pool: str         :param session: SQLAlchemy ORM Session         :type session: Session         :return: whether the state was changed to running or not         :rtype: bool         """ [36012,37387]
===
match
---
name: typing [1038,1044]
name: typing [1038,1044]
===
match
---
argument [62404,62417]
argument [62538,62551]
===
match
---
name: context [48029,48036]
name: context [48029,48036]
===
match
---
name: Log [40700,40703]
name: Log [40700,40703]
===
match
---
operator: = [61760,61761]
operator: = [61894,61895]
===
match
---
testlist_comp [18754,18775]
testlist_comp [18754,18775]
===
match
---
and_test [58499,58529]
and_test [58633,58663]
===
match
---
name: get [19294,19297]
name: get [19294,19297]
===
match
---
operator: = [22959,22960]
operator: = [22959,22960]
===
match
---
trailer [26173,26193]
trailer [26173,26193]
===
match
---
name: self [28530,28534]
name: self [28530,28534]
===
match
---
simple_stmt [14840,14865]
simple_stmt [14840,14865]
===
match
---
simple_stmt [82119,82136]
simple_stmt [82253,82270]
===
match
---
funcdef [62956,63013]
funcdef [63090,63147]
===
match
---
expr_stmt [34477,34555]
expr_stmt [34477,34555]
===
match
---
operator: = [62426,62427]
operator: = [62560,62561]
===
match
---
string: """         Get datetime of the next retry if the task instance fails. For exponential         backoff, retry_delay is used as base and will be converted to seconds.         """ [33027,33204]
string: """         Get datetime of the next retry if the task instance fails. For exponential         backoff, retry_delay is used as base and will be converted to seconds.         """ [33027,33204]
===
match
---
trailer [40566,40576]
trailer [40566,40576]
===
match
---
name: self [40590,40594]
name: self [40590,40594]
===
match
---
expr_stmt [7601,7846]
expr_stmt [7601,7846]
===
match
---
operator: , [41787,41788]
operator: , [41787,41788]
===
match
---
atom_expr [74316,74341]
atom_expr [74450,74475]
===
match
---
operator: { [32929,32930]
operator: { [32929,32930]
===
match
---
atom_expr [22099,22109]
atom_expr [22099,22109]
===
match
---
name: ID_LEN [1876,1882]
name: ID_LEN [1876,1882]
===
match
---
string: "Marking task as FAILED." [57865,57890]
string: "Marking task as FAILED." [57999,58024]
===
match
---
tfpdef [74433,74458]
tfpdef [74567,74592]
===
match
---
name: len [26387,26390]
name: len [26387,26390]
===
match
---
name: _try_number [80829,80840]
name: _try_number [80963,80974]
===
match
---
operator: = [70825,70826]
operator: = [70959,70960]
===
match
---
name: airflow [2463,2470]
name: airflow [2463,2470]
===
match
---
simple_stmt [71275,71541]
simple_stmt [71409,71675]
===
match
---
trailer [46897,46906]
trailer [46897,46906]
===
match
---
operator: = [81377,81378]
operator: = [81511,81512]
===
match
---
name: state [45453,45458]
name: state [45453,45458]
===
match
---
param [48281,48286]
param [48281,48286]
===
match
---
operator: == [24900,24902]
operator: == [24900,24902]
===
match
---
atom_expr [32968,32978]
atom_expr [32968,32978]
===
match
---
atom_expr [60555,60567]
atom_expr [60689,60701]
===
match
---
string: 'inlets' [64596,64604]
string: 'inlets' [64730,64738]
===
match
---
name: merge [40867,40872]
name: merge [40867,40872]
===
match
---
arglist [47527,47593]
arglist [47527,47593]
===
match
---
operator: } [59841,59842]
operator: } [59975,59976]
===
match
---
name: res [53774,53777]
name: res [53774,53777]
===
match
---
simple_stmt [21497,21556]
simple_stmt [21497,21556]
===
match
---
trailer [26168,26194]
trailer [26168,26194]
===
match
---
name: variable [2046,2054]
name: variable [2046,2054]
===
match
---
operator: = [47457,47458]
operator: = [47457,47458]
===
match
---
atom [37886,37896]
atom [37886,37896]
===
match
---
operator: , [30738,30739]
operator: , [30738,30739]
===
match
---
name: self [39895,39899]
name: self [39895,39899]
===
match
---
name: ignore_ti_state [35793,35808]
name: ignore_ti_state [35793,35808]
===
match
---
argument [39527,39558]
argument [39527,39558]
===
match
---
name: XCom [23908,23912]
name: XCom [23908,23912]
===
match
---
tfpdef [53670,53689]
tfpdef [53670,53689]
===
match
---
string: 'prev_ds' [64862,64871]
string: 'prev_ds' [64996,65005]
===
match
---
name: dag_id [35388,35394]
name: dag_id [35388,35394]
===
match
---
name: jinja_env [70930,70939]
name: jinja_env [71064,71073]
===
match
---
name: end_date [22024,22032]
name: end_date [22024,22032]
===
match
---
operator: = [44674,44675]
operator: = [44674,44675]
===
match
---
simple_stmt [1275,1365]
simple_stmt [1275,1365]
===
match
---
name: self [12029,12033]
name: self [12029,12033]
===
match
---
comparison [53091,53125]
comparison [53091,53125]
===
match
---
operator: , [40717,40718]
operator: , [40717,40718]
===
match
---
trailer [26243,26258]
trailer [26243,26258]
===
match
---
simple_stmt [79707,79750]
simple_stmt [79841,79884]
===
match
---
operator: , [68386,68387]
operator: , [68520,68521]
===
match
---
name: params [64842,64848]
name: params [64976,64982]
===
match
---
atom_expr [26053,26073]
atom_expr [26053,26073]
===
match
---
trailer [72799,72803]
trailer [72933,72937]
===
match
---
name: list [78090,78094]
name: list [78224,78228]
===
match
---
name: self [32930,32934]
name: self [32930,32934]
===
match
---
trailer [7232,7238]
trailer [7232,7238]
===
match
---
simple_stmt [2252,2303]
simple_stmt [2252,2303]
===
match
---
name: self [80746,80750]
name: self [80880,80884]
===
match
---
string: 'ts' [65609,65613]
string: 'ts' [65743,65747]
===
match
---
name: pendulum [29253,29261]
name: pendulum [29253,29261]
===
match
---
simple_stmt [36012,37388]
simple_stmt [36012,37388]
===
match
---
name: duration [24998,25006]
name: duration [24998,25006]
===
match
---
name: ts [61995,61997]
name: ts [62129,62131]
===
match
---
name: default_html_content_err [71141,71165]
name: default_html_content_err [71275,71299]
===
match
---
parameters [35576,35994]
parameters [35576,35994]
===
match
---
name: state [5174,5179]
name: state [5174,5179]
===
match
---
name: ignore_task_deps [35753,35769]
name: ignore_task_deps [35753,35769]
===
match
---
name: task [54924,54928]
name: task [54924,54928]
===
match
---
param [32876,32880]
param [32876,32880]
===
match
---
tfpdef [53399,53420]
tfpdef [53399,53420]
===
match
---
simple_stmt [62927,62943]
simple_stmt [63061,63077]
===
match
---
operator: = [11239,11240]
operator: = [11239,11240]
===
match
---
trailer [42834,42841]
trailer [42834,42841]
===
match
---
trailer [61711,61720]
trailer [61845,61854]
===
match
---
tfpdef [15520,15531]
tfpdef [15520,15531]
===
match
---
name: task [33259,33263]
name: task [33259,33263]
===
match
---
atom_expr [38950,38965]
atom_expr [38950,38965]
===
match
---
operator: { [49251,49252]
operator: { [49251,49252]
===
match
---
name: merge [55853,55858]
name: merge [55853,55858]
===
match
---
arglist [48854,48885]
arglist [48854,48885]
===
match
---
operator: , [37778,37779]
operator: , [37778,37779]
===
match
---
operator: @ [20615,20616]
operator: @ [20615,20616]
===
match
---
argument [49114,49136]
argument [49114,49136]
===
match
---
name: in_ [26165,26168]
name: in_ [26165,26168]
===
match
---
expr_stmt [72674,72739]
expr_stmt [72808,72873]
===
match
---
name: _try_number [55465,55476]
name: _try_number [55465,55476]
===
match
---
import_name [1201,1216]
import_name [1201,1216]
===
match
---
name: cfg_path [18789,18797]
name: cfg_path [18789,18797]
===
match
---
atom_expr [23949,23960]
atom_expr [23949,23960]
===
match
---
name: dag [14687,14690]
name: dag [14687,14690]
===
match
---
fstring_string: ]> [32979,32981]
fstring_string: ]> [32979,32981]
===
match
---
operator: = [70325,70326]
operator: = [70459,70460]
===
match
---
atom_expr [45744,45820]
atom_expr [45744,45820]
===
match
---
name: strftime [61712,61720]
name: strftime [61846,61854]
===
match
---
funcdef [30286,30841]
funcdef [30286,30841]
===
match
---
name: ignore_depends_on_past [15710,15732]
name: ignore_depends_on_past [15710,15732]
===
match
---
trailer [16025,16030]
trailer [16025,16030]
===
match
---
atom_expr [51332,51384]
atom_expr [51332,51384]
===
match
---
simple_stmt [52693,52722]
simple_stmt [52693,52722]
===
match
---
operator: + [5578,5579]
operator: + [5578,5579]
===
match
---
name: func [26042,26046]
name: func [26042,26046]
===
match
---
operator: = [74459,74460]
operator: = [74593,74594]
===
match
---
name: ignore_all_deps [39543,39558]
name: ignore_all_deps [39543,39558]
===
match
---
name: execution_date [79684,79698]
name: execution_date [79818,79832]
===
match
---
atom_expr [26817,26830]
atom_expr [26817,26830]
===
match
---
name: ti [22305,22307]
name: ti [22305,22307]
===
match
---
expr_stmt [43104,43130]
expr_stmt [43104,43130]
===
match
---
arglist [60190,60248]
arglist [60324,60382]
===
match
---
atom_expr [59381,59395]
atom_expr [59515,59529]
===
match
---
simple_stmt [18686,18708]
simple_stmt [18686,18708]
===
match
---
trailer [11353,11369]
trailer [11353,11369]
===
match
---
operator: = [51795,51796]
operator: = [51795,51796]
===
match
---
atom_expr [6954,6972]
atom_expr [6954,6972]
===
match
---
operator: = [29617,29618]
operator: = [29617,29618]
===
match
---
name: self [80870,80874]
name: self [81004,81008]
===
match
---
name: task [53059,53063]
name: task [53059,53063]
===
match
---
trailer [67275,67295]
trailer [67409,67429]
===
match
---
operator: , [44662,44663]
operator: , [44662,44663]
===
match
---
simple_stmt [24282,24370]
simple_stmt [24282,24370]
===
match
---
name: self [41342,41346]
name: self [41342,41346]
===
match
---
name: dag_run [47459,47466]
name: dag_run [47459,47466]
===
match
---
name: ti [22543,22545]
name: ti [22543,22545]
===
match
---
trailer [33707,33979]
trailer [33707,33979]
===
match
---
atom_expr [50315,50343]
atom_expr [50315,50343]
===
match
---
tfpdef [4286,4314]
tfpdef [4286,4314]
===
match
---
operator: = [46943,46944]
operator: = [46943,46944]
===
match
---
operator: , [77623,77624]
operator: , [77757,77758]
===
match
---
trailer [54643,54651]
trailer [54643,54651]
===
match
---
name: get_email_subject_content [68943,68968]
name: get_email_subject_content [69077,69102]
===
match
---
name: query [81814,81819]
name: query [81948,81953]
===
match
---
trailer [25030,25041]
trailer [25030,25041]
===
match
---
atom_expr [70783,70907]
atom_expr [70917,71041]
===
match
---
argument [38239,38270]
argument [38239,38270]
===
match
---
atom_expr [63948,63961]
atom_expr [64082,64095]
===
match
---
atom_expr [22287,22302]
atom_expr [22287,22302]
===
match
---
name: task [56763,56767]
name: task [56897,56901]
===
match
---
name: the_log [19004,19011]
name: the_log [19004,19011]
===
match
---
atom_expr [59456,59486]
atom_expr [59590,59620]
===
match
---
operator: = [19905,19906]
operator: = [19905,19906]
===
match
---
argument [73979,73986]
argument [74113,74120]
===
match
---
name: session [20972,20979]
name: session [20972,20979]
===
match
---
operator: { [76720,76721]
operator: { [76854,76855]
===
match
---
simple_stmt [23571,23602]
simple_stmt [23571,23602]
===
match
---
name: value [13281,13286]
name: value [13281,13286]
===
match
---
name: self [45704,45708]
name: self [45704,45708]
===
match
---
string: 'prev_execution_date' [64940,64961]
string: 'prev_execution_date' [65074,65095]
===
match
---
name: timedelta [34521,34530]
name: timedelta [34521,34530]
===
match
---
simple_stmt [820,835]
simple_stmt [820,835]
===
match
---
string: """Setting Next Try Number""" [13932,13961]
string: """Setting Next Try Number""" [13932,13961]
===
match
---
trailer [42593,42611]
trailer [42593,42611]
===
match
---
name: drs [7601,7604]
name: drs [7601,7604]
===
match
---
trailer [44563,44570]
trailer [44563,44570]
===
match
---
atom_expr [10681,10705]
atom_expr [10681,10705]
===
match
---
trailer [24876,24885]
trailer [24876,24885]
===
match
---
trailer [24861,24867]
trailer [24861,24867]
===
match
---
name: iso [19372,19375]
name: iso [19372,19375]
===
match
---
trailer [77573,77580]
trailer [77707,77714]
===
match
---
name: self [64562,64566]
name: self [64696,64700]
===
match
---
operator: = [21823,21824]
operator: = [21823,21824]
===
match
---
name: get_many [76232,76240]
name: get_many [76366,76374]
===
match
---
operator: == [78609,78611]
operator: == [78743,78745]
===
match
---
trailer [82575,82584]
trailer [82709,82718]
===
match
---
operator: = [35815,35816]
operator: = [35815,35816]
===
match
---
suite [67234,67298]
suite [67368,67432]
===
match
---
name: Any [74510,74513]
name: Any [74644,74647]
===
match
---
name: params [62411,62417]
name: params [62545,62551]
===
match
---
name: deserialize_json [63837,63853]
name: deserialize_json [63971,63987]
===
match
---
atom_expr [51695,51717]
atom_expr [51695,51717]
===
match
---
name: use_default [70286,70297]
name: use_default [70420,70431]
===
match
---
name: iso [18016,18019]
name: iso [18016,18019]
===
match
---
name: in_ [26291,26294]
name: in_ [26291,26294]
===
match
---
name: email [2434,2439]
name: email [2434,2439]
===
match
---
funcdef [77170,77593]
funcdef [77304,77727]
===
match
---
return_stmt [80567,80594]
return_stmt [80701,80728]
===
match
---
operator: , [3824,3825]
operator: , [3824,3825]
===
match
---
operator: = [79627,79628]
operator: = [79761,79762]
===
match
---
trailer [77062,77068]
trailer [77196,77202]
===
match
---
argument [39807,39822]
argument [39807,39822]
===
match
---
name: task [23542,23546]
name: task [23542,23546]
===
match
---
name: task_id [47054,47061]
name: task_id [47054,47061]
===
match
---
name: self [20958,20962]
name: self [20958,20962]
===
match
---
name: pool [18611,18615]
name: pool [18611,18615]
===
match
---
expr_stmt [79805,79842]
expr_stmt [79939,79976]
===
match
---
name: delay [34755,34760]
name: delay [34755,34760]
===
match
---
operator: = [44995,44996]
operator: = [44995,44996]
===
match
---
decorated [74189,77144]
decorated [74323,77278]
===
match
---
name: id [7412,7414]
name: id [7412,7414]
===
match
---
name: airflow [2130,2137]
name: airflow [2130,2137]
===
match
---
trailer [28016,28047]
trailer [28016,28047]
===
match
---
name: dag_id [74359,74365]
name: dag_id [74493,74499]
===
match
---
if_stmt [76671,77144]
if_stmt [76805,77278]
===
match
---
operator: += [40644,40646]
operator: += [40644,40646]
===
match
---
name: ready_for_retry [25372,25387]
name: ready_for_retry [25372,25387]
===
match
---
name: Optional [35945,35953]
name: Optional [35945,35953]
===
match
---
operator: { [42843,42844]
operator: { [42843,42844]
===
match
---
trailer [61940,61949]
trailer [62074,62083]
===
match
---
simple_stmt [39446,39737]
simple_stmt [39446,39737]
===
match
---
operator: , [9562,9563]
operator: , [9562,9563]
===
match
---
comparison [34935,34967]
comparison [34935,34967]
===
match
---
simple_stmt [79943,79983]
simple_stmt [80077,80117]
===
match
---
yield_expr [3589,3602]
yield_expr [3589,3602]
===
match
---
atom_expr [43993,44015]
atom_expr [43993,44015]
===
match
---
trailer [25080,25086]
trailer [25080,25086]
===
match
---
name: task_copy [50398,50407]
name: task_copy [50398,50407]
===
match
---
operator: , [1359,1360]
operator: , [1359,1360]
===
match
---
name: task [56957,56961]
name: task [57091,57095]
===
match
---
simple_stmt [69301,69343]
simple_stmt [69435,69477]
===
match
---
name: filter [23914,23920]
name: filter [23914,23920]
===
match
---
atom [76720,76874]
atom [76854,77008]
===
match
---
name: error_file [56608,56618]
name: error_file [56742,56752]
===
match
---
subscriptlist [56049,56063]
subscriptlist [56049,56063]
===
match
---
expr_stmt [80261,80288]
expr_stmt [80395,80422]
===
match
---
name: utcnow [50836,50842]
name: utcnow [50836,50842]
===
match
---
atom_expr [50881,50897]
atom_expr [50881,50897]
===
match
---
atom_expr [60995,61019]
atom_expr [61129,61153]
===
match
---
name: ti [5549,5551]
name: ti [5549,5551]
===
match
---
name: task_id [8282,8289]
name: task_id [8282,8289]
===
match
---
name: html_content_err [72531,72547]
name: html_content_err [72665,72681]
===
match
---
arith_expr [19627,19847]
arith_expr [19627,19847]
===
match
---
name: self [58118,58122]
name: self [58252,58256]
===
match
---
name: log [30089,30092]
name: log [30089,30092]
===
match
---
name: update [67779,67785]
name: update [67913,67919]
===
match
---
trailer [71029,71041]
trailer [71163,71175]
===
match
---
name: TaskInstance [77404,77416]
name: TaskInstance [77538,77550]
===
match
---
arglist [19042,19070]
arglist [19042,19070]
===
match
---
name: yesterday_ds [60517,60529]
name: yesterday_ds [60651,60663]
===
match
---
return_stmt [59333,59395]
return_stmt [59467,59529]
===
match
---
name: execution_date [60538,60552]
name: execution_date [60672,60686]
===
match
---
argument [78723,78785]
argument [78857,78919]
===
match
---
name: IO [3923,3925]
name: IO [3923,3925]
===
match
---
trailer [39127,39133]
trailer [39127,39133]
===
match
---
string: 'TaskInstance' [26549,26563]
string: 'TaskInstance' [26549,26563]
===
match
---
expr_stmt [57679,57704]
expr_stmt [57813,57838]
===
match
---
argument [15236,15267]
argument [15236,15267]
===
match
---
name: Environment [70790,70801]
name: Environment [70924,70935]
===
match
---
name: e [47870,47871]
name: e [47870,47871]
===
match
---
operator: = [22110,22111]
operator: = [22110,22111]
===
match
---
expr_stmt [82119,82135]
expr_stmt [82253,82269]
===
match
---
operator: = [59227,59228]
operator: = [59361,59362]
===
match
---
param [59416,59421]
param [59550,59555]
===
match
---
name: has_dag [11713,11720]
name: has_dag [11713,11720]
===
match
---
import_from [1630,1827]
import_from [1630,1827]
===
match
---
suite [63390,64351]
suite [63524,64485]
===
match
---
trailer [65237,65261]
trailer [65371,65395]
===
match
---
operator: , [38384,38385]
operator: , [38384,38385]
===
match
---
atom_expr [6744,6761]
atom_expr [6744,6761]
===
match
---
operator: , [59123,59124]
operator: , [59257,59258]
===
match
---
atom_expr [23319,23328]
atom_expr [23319,23328]
===
match
---
operator: = [76196,76197]
operator: = [76330,76331]
===
match
---
trailer [79787,79796]
trailer [79921,79930]
===
match
---
name: self [24951,24955]
name: self [24951,24955]
===
match
---
operator: , [11640,11641]
operator: , [11640,11641]
===
match
---
name: TaskReschedule [55364,55378]
name: TaskReschedule [55364,55378]
===
match
---
atom [18452,18480]
atom [18452,18480]
===
match
---
simple_stmt [55814,55836]
simple_stmt [55814,55836]
===
match
---
operator: , [54148,54149]
operator: , [54148,54149]
===
match
---
name: test_mode [12592,12601]
name: test_mode [12592,12601]
===
match
---
suite [8640,8799]
suite [8640,8799]
===
match
---
name: dates [7147,7152]
name: dates [7147,7152]
===
match
---
name: dep_name [32019,32027]
name: dep_name [32019,32027]
===
match
---
atom [17971,18020]
atom [17971,18020]
===
match
---
string: '%Y%m%dT%H%M%S' [58342,58357]
string: '%Y%m%dT%H%M%S' [58476,58491]
===
match
---
operator: , [15700,15701]
operator: , [15700,15701]
===
match
---
trailer [20277,20284]
trailer [20277,20284]
===
match
---
param [22946,22964]
param [22946,22964]
===
match
---
name: STATICA_HACK [82227,82239]
name: STATICA_HACK [82361,82373]
===
match
---
atom_expr [5171,5179]
atom_expr [5171,5179]
===
match
---
simple_stmt [59194,59235]
simple_stmt [59328,59369]
===
match
---
param [51863,51880]
param [51863,51880]
===
match
---
fstring [19349,19421]
fstring [19349,19421]
===
match
---
operator: @ [58864,58865]
operator: @ [58998,58999]
===
match
---
name: task [32434,32438]
name: task [32434,32438]
===
match
---
name: delay [34678,34683]
name: delay [34678,34683]
===
match
---
atom_expr [45225,45262]
atom_expr [45225,45262]
===
match
---
name: airflow [48099,48106]
name: airflow [48099,48106]
===
match
---
name: refresh_from_task [5465,5482]
name: refresh_from_task [5465,5482]
===
match
---
atom_expr [43117,43130]
atom_expr [43117,43130]
===
match
---
trailer [48464,48496]
trailer [48464,48496]
===
match
---
decorated [35024,35507]
decorated [35024,35507]
===
match
---
operator: { [14755,14756]
operator: { [14755,14756]
===
match
---
suite [80021,80069]
suite [80155,80203]
===
match
---
name: self [18964,18968]
name: self [18964,18968]
===
match
---
operator: = [16031,16032]
operator: = [16031,16032]
===
match
---
simple_stmt [30210,30267]
simple_stmt [30210,30267]
===
match
---
suite [48729,50517]
suite [48729,50517]
===
match
---
operator: = [27880,27881]
operator: = [27880,27881]
===
match
---
atom_expr [48946,48958]
atom_expr [48946,48958]
===
match
---
name: task_id [20383,20390]
name: task_id [20383,20390]
===
match
---
atom_expr [48661,48728]
atom_expr [48661,48728]
===
match
---
operator: , [58340,58341]
operator: , [58474,58475]
===
match
---
name: self [48223,48227]
name: self [48223,48227]
===
match
---
simple_stmt [55277,55297]
simple_stmt [55277,55297]
===
match
---
operator: -> [68091,68093]
operator: -> [68225,68227]
===
match
---
name: self [13977,13981]
name: self [13977,13981]
===
match
---
simple_stmt [5282,5308]
simple_stmt [5282,5308]
===
match
---
trailer [9483,9509]
trailer [9483,9509]
===
match
---
name: max_tries [9855,9864]
name: max_tries [9855,9864]
===
match
---
trailer [77431,77438]
trailer [77565,77572]
===
match
---
operator: == [81982,81984]
operator: == [82116,82118]
===
match
---
name: next_try_number [13901,13916]
name: next_try_number [13901,13916]
===
match
---
name: html_content_err [72057,72073]
name: html_content_err [72191,72207]
===
match
---
string: 'html_content_template' [72083,72106]
string: 'html_content_template' [72217,72240]
===
match
---
name: TaskInstance [81903,81915]
name: TaskInstance [82037,82049]
===
match
---
name: self [73897,73901]
name: self [74031,74035]
===
match
---
operator: , [16077,16078]
operator: , [16077,16078]
===
match
---
name: self [14070,14074]
name: self [14070,14074]
===
match
---
trailer [65273,65281]
trailer [65407,65415]
===
match
---
tfpdef [3338,3354]
tfpdef [3338,3354]
===
match
---
name: self [21497,21501]
name: self [21497,21501]
===
match
---
trailer [71497,71507]
trailer [71631,71641]
===
match
---
atom_expr [71020,71087]
atom_expr [71154,71221]
===
match
---
name: self [13211,13215]
name: self [13211,13215]
===
match
---
name: task_id [5391,5398]
name: task_id [5391,5398]
===
match
---
name: ti [7699,7701]
name: ti [7699,7701]
===
match
---
name: timezone [11807,11815]
name: timezone [11807,11815]
===
match
---
not_test [67942,67953]
not_test [68076,68087]
===
match
---
tfpdef [56074,56099]
tfpdef [56074,56099]
===
match
---
name: state [52518,52523]
name: state [52518,52523]
===
match
---
fstring_expr [50558,50579]
fstring_expr [50558,50579]
===
match
---
name: set_duration [55282,55294]
name: set_duration [55282,55294]
===
match
---
name: DepContext [31624,31634]
name: DepContext [31624,31634]
===
match
---
trailer [32920,32927]
trailer [32920,32927]
===
match
---
operator: { [44542,44543]
operator: { [44542,44543]
===
match
---
trailer [21889,21895]
trailer [21889,21895]
===
match
---
atom_expr [22531,22540]
atom_expr [22531,22540]
===
match
---
trailer [67402,67461]
trailer [67536,67595]
===
match
---
string: """         Returns whether or not all the conditions are met for this task instance to be run         given the context for the dependencies (e.g. a task instance being force run from         the UI will ignore some dependencies).          :param dep_context: The execution context that determines the dependencies that             should be evaluated.         :type dep_context: DepContext         :param session: database session         :type session: sqlalchemy.orm.session.Session         :param verbose: whether log details on failed dependencies on             info or debug log level         :type verbose: bool         """ [30954,31586]
string: """         Returns whether or not all the conditions are met for this task instance to be run         given the context for the dependencies (e.g. a task instance being force run from         the UI will ignore some dependencies).          :param dep_context: The execution context that determines the dependencies that             should be evaluated.         :type dep_context: DepContext         :param session: database session         :type session: sqlalchemy.orm.session.Session         :param verbose: whether log details on failed dependencies on             info or debug log level         :type verbose: bool         """ [30954,31586]
===
match
---
import_name [1176,1200]
import_name [1176,1200]
===
match
---
simple_stmt [57748,57817]
simple_stmt [57882,57951]
===
match
---
operator: = [82061,82062]
operator: = [82195,82196]
===
match
---
name: task [25964,25968]
name: task [25964,25968]
===
match
---
expr_stmt [70311,70339]
expr_stmt [70445,70473]
===
match
---
name: session [58842,58849]
name: session [58976,58983]
===
match
---
dotted_name [41546,41566]
dotted_name [41546,41566]
===
match
---
name: TaskInstanceKey [8478,8493]
name: TaskInstanceKey [8478,8493]
===
match
---
name: utcnow [55260,55266]
name: utcnow [55260,55266]
===
match
---
trailer [81881,81889]
trailer [82015,82023]
===
match
---
trailer [26041,26075]
trailer [26041,26075]
===
match
---
trailer [77386,77560]
trailer [77520,77694]
===
match
---
trailer [18586,18599]
trailer [18586,18599]
===
match
---
trailer [49432,49444]
trailer [49432,49444]
===
match
---
param [63658,63662]
param [63792,63796]
===
match
---
name: commit [45516,45522]
name: commit [45516,45522]
===
match
---
name: bool [53610,53614]
name: bool [53610,53614]
===
match
---
atom_expr [34690,34715]
atom_expr [34690,34715]
===
match
---
name: self [61055,61059]
name: self [61189,61193]
===
match
---
suite [58530,58775]
suite [58664,58909]
===
match
---
name: task [5520,5524]
name: task [5520,5524]
===
match
---
arglist [76254,76451]
arglist [76388,76585]
===
match
---
trailer [37585,37592]
trailer [37585,37592]
===
match
---
dotted_name [2031,2054]
dotted_name [2031,2054]
===
match
---
sliceop [82202,82205]
sliceop [82336,82339]
===
match
---
atom_expr [10102,10121]
atom_expr [10102,10121]
===
match
---
name: error [56620,56625]
name: error [56754,56759]
===
match
---
trailer [57925,57942]
trailer [58059,58076]
===
match
---
name: one [46243,46246]
name: one [46243,46246]
===
match
---
name: self [22934,22938]
name: self [22934,22938]
===
match
---
name: self [55859,55863]
name: self [55859,55863]
===
match
---
trailer [55580,55596]
trailer [55580,55596]
===
match
---
trailer [44919,44927]
trailer [44919,44927]
===
match
---
name: self [40290,40294]
name: self [40290,40294]
===
match
---
argument [15130,15163]
argument [15130,15163]
===
match
---
atom_expr [22625,22633]
atom_expr [22625,22633]
===
match
---
name: scheduler_job_id [68603,68619]
name: scheduler_job_id [68737,68753]
===
match
---
suite [22966,23602]
suite [22966,23602]
===
match
---
expr_stmt [61469,61510]
expr_stmt [61603,61644]
===
match
---
trailer [49163,49317]
trailer [49163,49317]
===
match
---
trailer [18150,18161]
trailer [18150,18161]
===
match
---
name: prev_ti [29642,29649]
name: prev_ti [29642,29649]
===
match
---
if_stmt [62291,62436]
if_stmt [62425,62570]
===
match
---
name: task_copy [48680,48689]
name: task_copy [48680,48689]
===
match
---
fstring [19714,19738]
fstring [19714,19738]
===
match
---
name: globals [82176,82183]
name: globals [82310,82317]
===
match
---
decorator [80361,80371]
decorator [80495,80505]
===
match
---
dotted_name [7531,7552]
dotted_name [7531,7552]
===
match
---
trailer [27136,27157]
trailer [27136,27157]
===
match
---
name: property [80508,80516]
name: property [80642,80650]
===
match
---
try_stmt [51966,52232]
try_stmt [51966,52232]
===
match
---
name: max_tries [23486,23495]
name: max_tries [23486,23495]
===
match
---
simple_stmt [13970,13998]
simple_stmt [13970,13998]
===
match
---
name: session [47612,47619]
name: session [47612,47619]
===
match
---
string: "at task runtime. Attempt %s of " [40051,40084]
string: "at task runtime. Attempt %s of " [40051,40084]
===
match
---
dotted_name [67039,67070]
dotted_name [67173,67204]
===
match
---
comparison [44528,44571]
comparison [44528,44571]
===
match
---
name: default_var [64315,64326]
name: default_var [64449,64460]
===
match
---
name: self [25010,25014]
name: self [25010,25014]
===
match
---
trailer [52837,52842]
trailer [52837,52842]
===
match
---
operator: , [1874,1875]
operator: , [1874,1875]
===
match
---
trailer [64552,64561]
trailer [64686,64695]
===
match
---
expr_stmt [22415,22442]
expr_stmt [22415,22442]
===
match
---
trailer [71879,71896]
trailer [72013,72030]
===
match
---
name: bool [35879,35883]
name: bool [35879,35883]
===
match
---
fstring_start: f" [19349,19351]
fstring_start: f" [19349,19351]
===
match
---
simple_stmt [59092,59186]
simple_stmt [59226,59320]
===
match
---
name: on_kill [48420,48427]
name: on_kill [48420,48427]
===
match
---
name: self [56371,56375]
name: self [56503,56507]
===
match
---
expr_stmt [54845,54861]
expr_stmt [54845,54861]
===
match
---
trailer [4029,4045]
trailer [4029,4045]
===
match
---
operator: * [37891,37892]
operator: * [37891,37892]
===
match
---
name: str [62845,62848]
name: str [62979,62982]
===
match
---
name: render [71991,71997]
name: render [72125,72131]
===
match
---
name: session [35975,35982]
name: session [35975,35982]
===
match
---
suite [66436,66477]
suite [66570,66611]
===
match
---
string: '%Y-%m-%d' [60578,60588]
string: '%Y-%m-%d' [60712,60722]
===
match
---
simple_stmt [61340,61362]
simple_stmt [61474,61496]
===
match
---
simple_stmt [77962,77974]
simple_stmt [78096,78108]
===
match
---
trailer [62261,62268]
trailer [62395,62402]
===
match
---
atom_expr [58257,58268]
atom_expr [58391,58402]
===
match
---
operator: @ [12467,12468]
operator: @ [12467,12468]
===
match
---
name: SUCCESS [37721,37728]
name: SUCCESS [37721,37728]
===
match
---
name: commit [38572,38578]
name: commit [38572,38578]
===
match
---
string: 'prev_ds_nodash' [64894,64910]
string: 'prev_ds_nodash' [65028,65044]
===
match
---
trailer [32812,32819]
trailer [32812,32819]
===
match
---
operator: = [11866,11867]
operator: = [11866,11867]
===
match
---
name: property [19146,19154]
name: property [19146,19154]
===
match
---
trailer [30171,30201]
trailer [30171,30201]
===
match
---
operator: , [24426,24427]
operator: , [24426,24427]
===
match
---
name: max_tries [70700,70709]
name: max_tries [70834,70843]
===
match
---
name: dag_id [76203,76209]
name: dag_id [76337,76343]
===
match
---
atom_expr [24039,24058]
atom_expr [24039,24058]
===
match
---
atom_expr [37626,37640]
atom_expr [37626,37640]
===
match
---
name: conf [62294,62298]
name: conf [62428,62432]
===
match
---
tfpdef [73004,73020]
tfpdef [73138,73154]
===
match
---
simple_stmt [44177,44200]
simple_stmt [44177,44200]
===
match
---
trailer [55818,55830]
trailer [55818,55830]
===
match
---
operator: , [29608,29609]
operator: , [29608,29609]
===
match
---
name: ignore_ti_state [53524,53539]
name: ignore_ti_state [53524,53539]
===
match
---
param [8342,8346]
param [8342,8346]
===
match
---
atom_expr [22415,22428]
atom_expr [22415,22428]
===
match
---
operator: == [78460,78462]
operator: == [78594,78596]
===
match
---
name: self [77205,77209]
name: self [77339,77343]
===
match
---
operator: ** [10404,10406]
operator: ** [10404,10406]
===
match
---
atom_expr [6843,6856]
atom_expr [6843,6856]
===
match
---
trailer [61883,61891]
trailer [62017,62025]
===
match
---
operator: , [53718,53719]
operator: , [53718,53719]
===
match
---
operator: = [81804,81805]
operator: = [81938,81939]
===
match
---
name: utils [2428,2433]
name: utils [2428,2433]
===
match
---
trailer [14759,14768]
trailer [14759,14768]
===
match
---
argument [39824,39836]
argument [39824,39836]
===
match
---
operator: , [62144,62145]
operator: , [62278,62279]
===
match
---
trailer [16092,16097]
trailer [16092,16097]
===
match
---
param [13917,13921]
param [13917,13921]
===
match
---
name: mark_success [14084,14096]
name: mark_success [14084,14096]
===
match
---
import_from [2220,2251]
import_from [2220,2251]
===
match
---
atom_expr [62175,62186]
atom_expr [62309,62320]
===
match
---
name: timezone [40309,40317]
name: timezone [40309,40317]
===
match
---
trailer [40506,40510]
trailer [40506,40510]
===
match
---
name: e [67467,67468]
name: e [67601,67602]
===
match
---
expr_stmt [40627,40648]
expr_stmt [40627,40648]
===
match
---
arglist [58448,58475]
arglist [58582,58609]
===
match
---
name: self [65383,65387]
name: self [65517,65521]
===
match
---
name: dump [4442,4446]
name: dump [4442,4446]
===
match
---
operator: = [32361,32362]
operator: = [32361,32362]
===
match
---
import_from [2186,2219]
import_from [2186,2219]
===
match
---
trailer [5299,5306]
trailer [5299,5306]
===
match
---
name: pendulum [30229,30237]
name: pendulum [30229,30237]
===
match
---
name: State [24871,24876]
name: State [24871,24876]
===
match
---
string: "--force" [18534,18543]
string: "--force" [18534,18543]
===
match
---
annassign [79668,79698]
annassign [79802,79832]
===
match
---
atom_expr [55235,55248]
atom_expr [55235,55248]
===
match
---
trailer [39903,39911]
trailer [39903,39911]
===
match
---
trailer [45295,45309]
trailer [45295,45309]
===
match
---
simple_stmt [42807,42860]
simple_stmt [42807,42860]
===
match
---
operator: = [4752,4753]
operator: = [4752,4753]
===
match
---
name: are_dependencies_met [38424,38444]
name: are_dependencies_met [38424,38444]
===
match
---
expr_stmt [55235,55268]
expr_stmt [55235,55268]
===
match
---
operator: , [45160,45161]
operator: , [45160,45161]
===
match
---
expr_stmt [69301,69342]
expr_stmt [69435,69476]
===
match
---
return_stmt [77962,77973]
return_stmt [78096,78107]
===
match
---
name: data [4078,4082]
name: data [4078,4082]
===
match
---
string: '' [62028,62030]
string: '' [62162,62164]
===
match
---
atom_expr [33853,33868]
atom_expr [33853,33868]
===
match
---
name: timezone [44997,45005]
name: timezone [44997,45005]
===
match
---
operator: , [9640,9641]
operator: , [9640,9641]
===
match
---
name: start_date [21996,22006]
name: start_date [21996,22006]
===
match
---
decorator [25092,25102]
decorator [25092,25102]
===
match
---
atom_expr [57969,57979]
atom_expr [58103,58113]
===
match
---
expr_stmt [12370,12386]
expr_stmt [12370,12386]
===
match
---
name: end_date [56666,56674]
name: end_date [56800,56808]
===
match
---
name: state [50779,50784]
name: state [50779,50784]
===
match
---
suite [62975,63013]
suite [63109,63147]
===
match
---
atom_expr [22431,22442]
atom_expr [22431,22442]
===
match
---
name: dep_context [31595,31606]
name: dep_context [31595,31606]
===
match
---
trailer [70789,70801]
trailer [70923,70935]
===
match
---
name: priority_weight [22651,22666]
name: priority_weight [22651,22666]
===
match
---
simple_stmt [44630,44687]
simple_stmt [44630,44687]
===
match
---
trailer [66339,66341]
trailer [66473,66475]
===
match
---
simple_stmt [2877,2928]
simple_stmt [2877,2928]
===
match
---
funcdef [35533,41318]
funcdef [35533,41318]
===
match
---
suite [67659,67800]
suite [67793,67934]
===
match
---
name: execution_date [11851,11865]
name: execution_date [11851,11865]
===
match
---
name: Variable [63818,63826]
name: Variable [63952,63960]
===
match
---
atom_expr [58675,58732]
atom_expr [58809,58866]
===
match
---
operator: , [1103,1104]
operator: , [1103,1104]
===
match
---
name: prev_ds [61682,61689]
name: prev_ds [61816,61823]
===
match
---
trailer [43122,43130]
trailer [43122,43130]
===
match
---
name: ti [22471,22473]
name: ti [22471,22473]
===
match
---
name: ignore_all_deps [53867,53882]
name: ignore_all_deps [53867,53882]
===
match
---
atom_expr [82124,82135]
atom_expr [82258,82269]
===
match
---
suite [18428,18482]
suite [18428,18482]
===
match
---
name: _dag_id [80420,80427]
name: _dag_id [80554,80561]
===
match
---
atom_expr [3923,3932]
atom_expr [3923,3932]
===
match
---
fstring [44888,44942]
fstring [44888,44942]
===
match
---
expr_stmt [49693,49711]
expr_stmt [49693,49711]
===
match
---
name: jinja_env [70771,70780]
name: jinja_env [70905,70914]
===
match
---
name: _date_or_empty [45328,45342]
name: _date_or_empty [45328,45342]
===
match
---
name: pool [23295,23299]
name: pool [23295,23299]
===
match
---
atom_expr [43392,43398]
atom_expr [43392,43398]
===
match
---
name: DeprecationWarning [28459,28477]
name: DeprecationWarning [28459,28477]
===
match
---
simple_stmt [55873,55890]
simple_stmt [55873,55890]
===
match
---
simple_stmt [9605,9660]
simple_stmt [9605,9660]
===
match
---
name: math [33571,33575]
name: math [33571,33575]
===
match
---
simple_stmt [37513,37573]
simple_stmt [37513,37573]
===
match
---
atom_expr [11134,11147]
atom_expr [11134,11147]
===
match
---
string: """     Sets the current execution context to the provided context object.     This method should be called once per Task execution, before calling operator.execute.     """ [3361,3534]
string: """     Sets the current execution context to the provided context object.     This method should be called once per Task execution, before calling operator.execute.     """ [3361,3534]
===
match
---
name: error [54608,54613]
name: error [54608,54613]
===
match
---
trailer [48672,48728]
trailer [48672,48728]
===
match
---
trailer [11196,11203]
trailer [11196,11203]
===
match
---
string: """     Simplified Task Instance.      Used to send data between processes via Queues.     """ [79424,79518]
string: """     Simplified Task Instance.      Used to send data between processes via Queues.     """ [79558,79652]
===
match
---
operator: @ [53279,53280]
operator: @ [53279,53280]
===
match
---
name: run_id [60301,60307]
name: run_id [60435,60441]
===
match
---
name: dag_run [46806,46813]
name: dag_run [46806,46813]
===
match
---
name: conf [67754,67758]
name: conf [67888,67892]
===
match
---
atom [18753,18776]
atom [18753,18776]
===
match
---
trailer [46242,46246]
trailer [46242,46246]
===
match
---
atom_expr [49513,49554]
atom_expr [49513,49554]
===
match
---
string: "started running, please use 'airflow tasks render' for debugging the " [66786,66857]
string: "started running, please use 'airflow tasks render' for debugging the " [66920,66991]
===
match
---
string: "--ignore-dependencies" [18368,18391]
string: "--ignore-dependencies" [18368,18391]
===
match
---
trailer [60451,60463]
trailer [60585,60597]
===
match
---
name: task [56648,56652]
name: task [56782,56786]
===
match
---
argument [70878,70893]
argument [71012,71027]
===
match
---
operator: , [10402,10403]
operator: , [10402,10403]
===
match
---
argument [62419,62434]
argument [62553,62568]
===
match
---
name: SUCCESS [30832,30839]
name: SUCCESS [30832,30839]
===
match
---
name: ti_deps [2316,2323]
name: ti_deps [2316,2323]
===
match
---
name: test_mode [56074,56083]
name: test_mode [56074,56083]
===
match
---
name: List [3232,3236]
name: List [3232,3236]
===
match
---
operator: , [22938,22939]
operator: , [22938,22939]
===
match
---
simple_stmt [52208,52232]
simple_stmt [52208,52232]
===
match
---
simple_stmt [12518,12579]
simple_stmt [12518,12579]
===
match
---
operator: = [53218,53219]
operator: = [53218,53219]
===
match
---
arglist [61502,61509]
arglist [61636,61643]
===
match
---
simple_stmt [54919,54941]
simple_stmt [54919,54941]
===
match
---
operator: , [77545,77546]
operator: , [77679,77680]
===
match
---
trailer [41179,41194]
trailer [41179,41194]
===
match
---
trailer [64810,64818]
trailer [64944,64952]
===
match
---
operator: = [44817,44818]
operator: = [44817,44818]
===
match
---
string: """             This attribute is deprecated.             Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.             """ [28294,28445]
string: """             This attribute is deprecated.             Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.             """ [28294,28445]
===
match
---
argument [70648,70678]
argument [70782,70812]
===
match
---
name: getpass [812,819]
name: getpass [812,819]
===
match
---
name: FAILED [52533,52539]
name: FAILED [52533,52539]
===
match
---
atom_expr [40747,40760]
atom_expr [40747,40760]
===
match
---
if_stmt [57717,57891]
if_stmt [57851,58025]
===
match
---
operator: = [22469,22470]
operator: = [22469,22470]
===
match
---
simple_stmt [81281,81310]
simple_stmt [81415,81444]
===
match
---
trailer [45031,45036]
trailer [45031,45036]
===
match
---
atom_expr [31762,31832]
atom_expr [31762,31832]
===
match
---
simple_stmt [82395,82436]
simple_stmt [82529,82570]
===
match
---
name: init_on_load [12490,12502]
name: init_on_load [12490,12502]
===
match
---
trailer [77783,77823]
trailer [77917,77957]
===
match
---
trailer [80311,80315]
trailer [80445,80449]
===
match
---
simple_stmt [23677,23841]
simple_stmt [23677,23841]
===
match
---
expr_stmt [42692,42712]
expr_stmt [42692,42712]
===
match
---
operator: = [22667,22668]
operator: = [22667,22668]
===
match
---
trailer [50234,50263]
trailer [50234,50263]
===
match
---
name: xcom_pull [74214,74223]
name: xcom_pull [74348,74357]
===
match
---
atom_expr [8521,8540]
atom_expr [8521,8540]
===
match
---
trailer [5093,5140]
trailer [5093,5140]
===
match
---
trailer [51599,51616]
trailer [51599,51616]
===
match
---
operator: , [21548,21549]
operator: , [21548,21549]
===
match
---
name: exceptions [1643,1653]
name: exceptions [1643,1653]
===
match
---
simple_stmt [49423,49462]
simple_stmt [49423,49462]
===
match
---
atom_expr [40502,40581]
atom_expr [40502,40581]
===
match
---
suite [58547,58588]
suite [58681,58722]
===
match
---
name: result [59498,59504]
name: result [59632,59638]
===
match
---
atom_expr [73957,74183]
atom_expr [74091,74317]
===
match
---
operator: , [39509,39510]
operator: , [39509,39510]
===
match
---
name: ti [22509,22511]
name: ti [22509,22511]
===
match
---
name: self [81217,81221]
name: self [81351,81355]
===
match
---
string: 'ti_job_id' [10848,10859]
string: 'ti_job_id' [10848,10859]
===
match
---
and_test [60983,61019]
and_test [61117,61153]
===
match
---
name: drs [7865,7868]
name: drs [7865,7868]
===
match
---
atom_expr [70826,70876]
atom_expr [70960,71010]
===
match
---
name: count [26047,26052]
name: count [26047,26052]
===
match
---
argument [11026,11039]
argument [11026,11039]
===
match
---
operator: , [11063,11064]
operator: , [11063,11064]
===
match
---
name: attr [41420,41424]
name: attr [41420,41424]
===
match
---
atom_expr [5183,5196]
atom_expr [5183,5196]
===
match
---
name: NamedTemporaryFile [54288,54306]
name: NamedTemporaryFile [54288,54306]
===
match
---
simple_stmt [21975,22007]
simple_stmt [21975,22007]
===
match
---
name: tis [78934,78937]
name: tis [79068,79071]
===
match
---
trailer [7274,7286]
trailer [7274,7286]
===
match
---
trailer [10905,11070]
trailer [10905,11070]
===
match
---
simple_stmt [4209,4248]
simple_stmt [4209,4248]
===
match
---
arglist [10002,10028]
arglist [10002,10028]
===
match
---
name: mark_success [54076,54088]
name: mark_success [54076,54088]
===
match
---
argument [46129,46163]
argument [46129,46163]
===
match
---
trailer [61435,61444]
trailer [61569,61578]
===
match
---
trailer [33737,33932]
trailer [33737,33932]
===
match
---
trailer [78811,79008]
trailer [78945,79142]
===
match
---
atom_expr [58519,58529]
atom_expr [58653,58663]
===
match
---
simple_stmt [4092,4104]
simple_stmt [4092,4104]
===
match
---
argument [78908,78937]
argument [79042,79071]
===
match
---
argument [6630,7178]
argument [6630,7178]
===
match
---
atom_expr [26864,26896]
atom_expr [26864,26896]
===
match
---
exprlist [7046,7072]
exprlist [7046,7072]
===
match
---
atom_expr [79785,79796]
atom_expr [79919,79930]
===
match
---
decorator [8124,8134]
decorator [8124,8134]
===
match
---
simple_stmt [5505,5533]
simple_stmt [5505,5533]
===
match
---
operator: , [55405,55406]
operator: , [55405,55406]
===
match
---
operator: , [64818,64819]
operator: , [64952,64953]
===
match
---
name: Union [77784,77789]
name: Union [77918,77923]
===
match
---
operator: + [40577,40578]
operator: + [40577,40578]
===
match
---
atom_expr [44354,44376]
atom_expr [44354,44376]
===
match
---
trailer [60272,60274]
trailer [60406,60408]
===
match
---
simple_stmt [29281,29497]
simple_stmt [29281,29497]
===
match
---
name: self [42536,42540]
name: self [42536,42540]
===
match
---
simple_stmt [20218,20503]
simple_stmt [20218,20503]
===
match
---
atom_expr [67672,67759]
atom_expr [67806,67893]
===
match
---
arith_expr [13211,13231]
arith_expr [13211,13231]
===
match
---
atom_expr [6076,6093]
atom_expr [6076,6093]
===
match
---
import_from [2458,2504]
import_from [2458,2504]
===
match
---
atom [33605,33633]
atom [33605,33633]
===
match
---
trailer [70865,70875]
trailer [70999,71009]
===
match
---
decorated [30272,30841]
decorated [30272,30841]
===
match
---
name: task [64806,64810]
name: task [64940,64944]
===
match
---
name: handle_failure [44217,44231]
name: handle_failure [44217,44231]
===
match
---
name: state [20544,20549]
name: state [20544,20549]
===
match
---
string: """     Clears a set of task instances, but makes sure the running ones     get killed.      :param tis: a list of task instances     :param session: current session     :param activate_dag_runs: flag to check for active dag run     :param dag: DAG object     """ [4780,5043]
string: """     Clears a set of task instances, but makes sure the running ones     get killed.      :param tis: a list of task instances     :param session: current session     :param activate_dag_runs: flag to check for active dag run     :param dag: DAG object     """ [4780,5043]
===
match
---
name: job_id [37595,37601]
name: job_id [37595,37601]
===
match
---
name: TaskInstance [27262,27274]
name: TaskInstance [27262,27274]
===
match
---
simple_stmt [68995,69047]
simple_stmt [69129,69181]
===
match
---
name: try_number [79832,79842]
name: try_number [79966,79976]
===
match
---
atom_expr [48680,48696]
atom_expr [48680,48696]
===
match
---
fstring_end: " [19700,19701]
fstring_end: " [19700,19701]
===
match
---
trailer [60266,60272]
trailer [60400,60406]
===
match
---
trailer [40695,40699]
trailer [40695,40699]
===
match
---
decorated [15472,18867]
decorated [15472,18867]
===
match
---
fstring_expr [48698,48717]
fstring_expr [48698,48717]
===
match
---
trailer [54709,54711]
trailer [54709,54711]
===
match
---
name: dag [14647,14650]
name: dag [14647,14650]
===
match
---
name: start_date [80618,80628]
name: start_date [80752,80762]
===
match
---
atom_expr [77339,77582]
atom_expr [77473,77716]
===
match
---
name: task [44915,44919]
name: task [44915,44919]
===
match
---
trailer [21646,21653]
trailer [21646,21653]
===
match
---
name: self [13917,13921]
name: self [13917,13921]
===
match
---
name: ts_nodash_with_tz [65688,65705]
name: ts_nodash_with_tz [65822,65839]
===
match
---
simple_stmt [72296,72380]
simple_stmt [72430,72514]
===
match
---
name: str [74376,74379]
name: str [74510,74513]
===
match
---
trailer [58689,58732]
trailer [58823,58866]
===
match
---
import_as_names [973,992]
import_as_names [973,992]
===
match
---
suite [25989,26014]
suite [25989,26014]
===
match
---
tfpdef [29173,29193]
tfpdef [29173,29193]
===
match
---
atom_expr [53676,53689]
atom_expr [53676,53689]
===
match
---
simple_stmt [59280,59325]
simple_stmt [59414,59459]
===
match
---
atom_expr [78159,78179]
atom_expr [78293,78313]
===
match
---
atom_expr [7404,7427]
atom_expr [7404,7427]
===
match
---
suite [74514,77144]
suite [74648,77278]
===
match
---
name: task_ids [76360,76368]
name: task_ids [76494,76502]
===
match
---
name: self [19526,19530]
name: self [19526,19530]
===
match
---
suite [4324,4681]
suite [4324,4681]
===
match
---
operator: , [4757,4758]
operator: , [4757,4758]
===
match
---
operator: = [79868,79869]
operator: = [80002,80003]
===
match
---
name: self [80210,80214]
name: self [80344,80348]
===
match
---
atom_expr [40734,40744]
atom_expr [40734,40744]
===
match
---
name: self [12439,12443]
name: self [12439,12443]
===
match
---
dotted_name [60039,60060]
dotted_name [60173,60194]
===
match
---
simple_stmt [9423,9455]
simple_stmt [9423,9455]
===
match
---
name: ignore_ti_state [54018,54033]
name: ignore_ti_state [54018,54033]
===
match
---
trailer [19586,19611]
trailer [19586,19611]
===
match
---
operator: } [19375,19376]
operator: } [19375,19376]
===
match
---
simple_stmt [59734,59751]
simple_stmt [59868,59885]
===
match
---
name: in_ [78665,78668]
name: in_ [78799,78802]
===
match
---
name: State [2819,2824]
name: State [2819,2824]
===
match
---
name: get_k8s_pod_yaml [67161,67177]
name: get_k8s_pod_yaml [67295,67311]
===
match
---
name: innerjoin [11049,11058]
name: innerjoin [11049,11058]
===
match
---
simple_stmt [43049,43092]
simple_stmt [43049,43092]
===
match
---
operator: , [49302,49303]
operator: , [49302,49303]
===
match
---
name: task [59746,59750]
name: task [59880,59884]
===
match
---
name: Column [9542,9548]
name: Column [9542,9548]
===
match
---
name: ti [5297,5299]
name: ti [5297,5299]
===
match
---
name: executor_config [23524,23539]
name: executor_config [23524,23539]
===
match
---
expr_stmt [80077,80102]
expr_stmt [80211,80236]
===
match
---
decorator [55007,55024]
decorator [55007,55024]
===
match
---
name: enrich_errors [41553,41566]
name: enrich_errors [41553,41566]
===
match
---
name: TaskFail [1960,1968]
name: TaskFail [1960,1968]
===
match
---
trailer [54728,54751]
trailer [54728,54751]
===
match
---
trailer [49580,49607]
trailer [49580,49607]
===
match
---
trailer [68375,68386]
trailer [68509,68520]
===
match
---
operator: , [10697,10698]
operator: , [10697,10698]
===
match
---
simple_stmt [46848,46907]
simple_stmt [46848,46907]
===
match
---
simple_stmt [82486,82530]
simple_stmt [82620,82664]
===
match
---
name: bool [41659,41663]
name: bool [41659,41663]
===
match
---
number: 1 [34553,34554]
number: 1 [34553,34554]
===
match
---
operator: = [10281,10282]
operator: = [10281,10282]
===
match
---
sync_comp_for [78773,78785]
sync_comp_for [78907,78919]
===
match
---
atom [70327,70339]
atom [70461,70473]
===
match
---
operator: = [72074,72075]
operator: = [72208,72209]
===
match
---
arglist [50537,50586]
arglist [50537,50586]
===
match
---
name: query [35347,35352]
name: query [35347,35352]
===
match
---
trailer [78968,78976]
trailer [79102,79110]
===
match
---
name: task_id [78748,78755]
name: task_id [78882,78889]
===
match
---
number: 1000 [9948,9952]
number: 1000 [9948,9952]
===
match
---
trailer [58580,58587]
trailer [58714,58721]
===
match
---
name: operator [22719,22727]
name: operator [22719,22727]
===
match
---
name: UP_FOR_RETRY [57988,58000]
name: UP_FOR_RETRY [58122,58134]
===
match
---
simple_stmt [3714,3897]
simple_stmt [3714,3897]
===
match
---
operator: @ [81232,81233]
operator: @ [81366,81367]
===
match
---
name: extend [18633,18639]
name: extend [18633,18639]
===
match
---
atom_expr [68659,68689]
atom_expr [68793,68823]
===
match
---
trailer [80282,80288]
trailer [80416,80422]
===
match
---
atom_expr [62269,62280]
atom_expr [62403,62414]
===
match
---
atom_expr [51340,51383]
atom_expr [51340,51383]
===
match
---
simple_stmt [66981,67026]
simple_stmt [67115,67160]
===
match
---
name: _safe_date [59405,59415]
name: _safe_date [59539,59549]
===
match
---
name: execution_date [46129,46143]
name: execution_date [46129,46143]
===
match
---
trailer [71063,71070]
trailer [71197,71204]
===
match
---
operator: = [54313,54314]
operator: = [54313,54314]
===
match
---
name: self [19237,19241]
name: self [19237,19241]
===
match
---
atom_expr [37513,37572]
atom_expr [37513,37572]
===
match
---
expr_stmt [34678,34723]
expr_stmt [34678,34723]
===
match
---
trailer [48512,48519]
trailer [48512,48519]
===
match
---
simple_stmt [58749,58775]
simple_stmt [58883,58909]
===
match
---
simple_stmt [67967,68005]
simple_stmt [68101,68139]
===
match
---
string: "rendering of template_fields." [66878,66909]
string: "rendering of template_fields." [67012,67043]
===
match
---
trailer [7662,7817]
trailer [7662,7817]
===
match
---
trailer [33772,33779]
trailer [33772,33779]
===
match
---
name: self [49803,49807]
name: self [49803,49807]
===
match
---
operator: , [72905,72906]
operator: , [73039,73040]
===
match
---
atom_expr [40151,40166]
atom_expr [40151,40166]
===
match
---
name: raw [15371,15374]
name: raw [15371,15374]
===
match
---
if_stmt [18716,18778]
if_stmt [18716,18778]
===
match
---
name: pickle [4128,4134]
name: pickle [4128,4134]
===
match
---
simple_stmt [61523,61584]
simple_stmt [61657,61718]
===
match
---
string: 'prev_start_date_success' [65157,65182]
string: 'prev_start_date_success' [65291,65316]
===
match
---
name: base_url [19627,19635]
name: base_url [19627,19635]
===
match
---
if_stmt [47303,47436]
if_stmt [47303,47436]
===
match
---
trailer [34939,34945]
trailer [34939,34945]
===
match
---
atom_expr [52585,52609]
atom_expr [52585,52609]
===
match
---
simple_stmt [80261,80289]
simple_stmt [80395,80423]
===
match
---
simple_stmt [10094,10122]
simple_stmt [10094,10122]
===
match
---
atom_expr [70530,70743]
atom_expr [70664,70877]
===
match
---
name: self [22455,22459]
name: self [22455,22459]
===
match
---
simple_stmt [82440,82481]
simple_stmt [82574,82615]
===
match
---
trailer [40901,40903]
trailer [40901,40903]
===
match
---
atom_expr [77828,77855]
atom_expr [77962,77989]
===
match
---
name: Optional [74367,74375]
name: Optional [74501,74509]
===
match
---
operator: , [70876,70877]
operator: , [71010,71011]
===
match
---
simple_stmt [42554,42581]
simple_stmt [42554,42581]
===
match
---
with_stmt [51327,51450]
with_stmt [51327,51450]
===
match
---
atom_expr [8507,8519]
atom_expr [8507,8519]
===
match
---
operator: , [30183,30184]
operator: , [30183,30184]
===
match
---
simple_stmt [68014,68056]
simple_stmt [68148,68190]
===
match
---
name: e [66933,66934]
name: e [67067,67068]
===
match
---
name: extend [18746,18752]
name: extend [18746,18752]
===
match
---
operator: , [7060,7061]
operator: , [7060,7061]
===
match
---
name: debug [30093,30098]
name: debug [30093,30098]
===
match
---
name: self [19171,19175]
name: self [19171,19175]
===
match
---
operator: = [10319,10320]
operator: = [10319,10320]
===
match
---
for_stmt [7363,7483]
for_stmt [7363,7483]
===
match
---
atom_expr [57921,57942]
atom_expr [58055,58076]
===
match
---
funcdef [32236,32858]
funcdef [32236,32858]
===
match
---
argument [42618,42636]
argument [42618,42636]
===
match
---
operator: , [65477,65478]
operator: , [65611,65612]
===
match
---
expr_stmt [33694,33979]
expr_stmt [33694,33979]
===
match
---
name: str [80089,80092]
name: str [80223,80226]
===
match
---
atom_expr [63681,63689]
atom_expr [63815,63823]
===
match
---
operator: , [1327,1328]
operator: , [1327,1328]
===
match
---
decorator [8316,8326]
decorator [8316,8326]
===
match
---
atom_expr [20538,20549]
atom_expr [20538,20549]
===
match
---
argument [76254,76288]
argument [76388,76422]
===
match
---
atom_expr [40769,40777]
atom_expr [40769,40777]
===
match
---
atom_expr [24016,24035]
atom_expr [24016,24035]
===
match
---
operator: = [38966,38967]
operator: = [38966,38967]
===
match
---
operator: , [33851,33852]
operator: , [33851,33852]
===
match
---
tfpdef [64104,64120]
tfpdef [64238,64254]
===
match
---
and_test [11451,11511]
and_test [11451,11511]
===
match
---
operator: = [62119,62120]
operator: = [62253,62254]
===
match
---
atom_expr [23290,23299]
atom_expr [23290,23299]
===
match
---
fstring_end: " [19420,19421]
fstring_end: " [19420,19421]
===
match
---
fstring_expr [19385,19399]
fstring_expr [19385,19399]
===
match
---
trailer [49802,49817]
trailer [49802,49817]
===
match
---
name: task_reschedule [39155,39170]
name: task_reschedule [39155,39170]
===
match
---
name: pickle_id [14265,14274]
name: pickle_id [14265,14274]
===
match
---
trailer [52147,52153]
trailer [52147,52153]
===
match
---
suite [28630,29092]
suite [28630,29092]
===
match
---
name: dep_context [32511,32522]
name: dep_context [32511,32522]
===
match
---
name: email_alert [58569,58580]
name: email_alert [58703,58714]
===
match
---
name: filter [21599,21605]
name: filter [21599,21605]
===
match
---
name: Log [1920,1923]
name: Log [1920,1923]
===
match
---
atom_expr [79805,79821]
atom_expr [79939,79955]
===
match
---
operator: , [72303,72304]
operator: , [72437,72438]
===
match
---
trailer [14711,14720]
trailer [14711,14720]
===
match
---
simple_stmt [67772,67800]
simple_stmt [67906,67934]
===
match
---
trailer [60013,60020]
trailer [60147,60154]
===
match
---
number: 1 [40579,40580]
number: 1 [40579,40580]
===
match
---
name: stacklevel [30752,30762]
name: stacklevel [30752,30762]
===
match
---
name: String [1341,1347]
name: String [1341,1347]
===
match
---
fstring [62172,62217]
fstring [62306,62351]
===
match
---
string: "tasks" [17983,17990]
string: "tasks" [17983,17990]
===
match
---
param [35707,35744]
param [35707,35744]
===
match
---
simple_stmt [850,862]
simple_stmt [850,862]
===
match
---
simple_stmt [900,916]
simple_stmt [900,916]
===
match
---
return_stmt [27255,27330]
return_stmt [27255,27330]
===
match
---
operator: , [17997,17998]
operator: , [17997,17998]
===
match
---
trailer [77036,77050]
trailer [77170,77184]
===
match
---
operator: = [15100,15101]
operator: = [15100,15101]
===
match
---
funcdef [80447,80502]
funcdef [80581,80636]
===
match
---
subscriptlist [77790,77821]
subscriptlist [77924,77955]
===
match
---
operator: , [74466,74467]
operator: , [74600,74601]
===
match
---
simple_stmt [61682,61733]
simple_stmt [61816,61867]
===
match
---
suite [3145,3167]
suite [3145,3167]
===
match
---
suite [3615,3897]
suite [3615,3897]
===
match
---
atom_expr [4653,4680]
atom_expr [4653,4680]
===
match
---
name: XCom [77115,77119]
name: XCom [77249,77253]
===
match
---
except_clause [58600,58625]
except_clause [58734,58759]
===
match
---
trailer [45759,45820]
trailer [45759,45820]
===
match
---
fstring_end: " [62216,62217]
fstring_end: " [62350,62351]
===
match
---
string: """         Copy common attributes from the given task.          :param task: The task object to copy from         :type task: airflow.models.BaseOperator         :param pool_override: Use the pool_override instead of task's pool         :type pool_override: str         """ [22975,23249]
string: """         Copy common attributes from the given task.          :param task: The task object to copy from         :type task: airflow.models.BaseOperator         :param pool_override: Use the pool_override instead of task's pool         :type pool_override: str         """ [22975,23249]
===
match
---
suite [44572,44596]
suite [44572,44596]
===
match
---
name: TaskInstanceKey [8723,8738]
name: TaskInstanceKey [8723,8738]
===
match
---
trailer [82066,82082]
trailer [82200,82216]
===
match
---
atom_expr [5938,5950]
atom_expr [5938,5950]
===
match
---
name: bool [15951,15955]
name: bool [15951,15955]
===
match
---
trailer [8493,8570]
trailer [8493,8570]
===
match
---
expr_stmt [38078,38399]
expr_stmt [38078,38399]
===
match
---
name: property [81233,81241]
name: property [81367,81375]
===
match
---
name: mark_success [15635,15647]
name: mark_success [15635,15647]
===
match
---
operator: = [56133,56134]
operator: = [56133,56134]
===
match
---
operator: , [58931,58932]
operator: , [59065,59066]
===
match
---
operator: , [18005,18006]
operator: , [18005,18006]
===
match
---
name: task_id [77469,77476]
name: task_id [77603,77610]
===
match
---
name: session [31824,31831]
name: session [31824,31831]
===
match
---
name: dag [14809,14812]
name: dag [14809,14812]
===
match
---
name: str [4281,4284]
name: str [4281,4284]
===
match
---
name: task [42830,42834]
name: task [42830,42834]
===
match
---
trailer [21828,21844]
trailer [21828,21844]
===
match
---
atom_expr [29253,29270]
atom_expr [29253,29270]
===
match
---
operator: , [58719,58720]
operator: , [58853,58854]
===
match
---
atom_expr [42830,42841]
atom_expr [42830,42841]
===
match
---
operator: = [22388,22389]
operator: = [22388,22389]
===
match
---
suite [37729,37783]
suite [37729,37783]
===
match
---
name: str [41734,41737]
name: str [41734,41737]
===
match
---
name: Column [9867,9873]
name: Column [9867,9873]
===
match
---
operator: , [65876,65877]
operator: , [66010,66011]
===
match
---
name: raw [12375,12378]
name: raw [12375,12378]
===
match
---
operator: = [61919,61920]
operator: = [62053,62054]
===
match
---
name: iso [18958,18961]
name: iso [18958,18961]
===
match
---
operator: = [39705,39706]
operator: = [39705,39706]
===
match
---
name: State [20923,20928]
name: State [20923,20928]
===
match
---
name: verbose [38520,38527]
name: verbose [38520,38527]
===
match
---
operator: , [56052,56053]
operator: , [56052,56053]
===
match
---
name: next_execution_date [61523,61542]
name: next_execution_date [61657,61676]
===
match
---
trailer [6808,6998]
trailer [6808,6998]
===
match
---
name: primaryjoin [10935,10946]
name: primaryjoin [10935,10946]
===
match
---
name: os [869,871]
name: os [869,871]
===
match
---
operator: = [80232,80233]
operator: = [80366,80367]
===
match
---
name: Column [9898,9904]
name: Column [9898,9904]
===
match
---
name: state [2806,2811]
name: state [2806,2811]
===
match
---
expr_stmt [22099,22120]
expr_stmt [22099,22120]
===
match
---
expr_stmt [9423,9454]
expr_stmt [9423,9454]
===
match
---
param [53706,53719]
param [53706,53719]
===
match
---
atom_expr [65752,65774]
atom_expr [65886,65908]
===
match
---
suite [40675,40726]
suite [40675,40726]
===
match
---
comparison [77404,77438]
comparison [77538,77572]
===
match
---
name: Column [1298,1304]
name: Column [1298,1304]
===
match
---
operator: = [33702,33703]
operator: = [33702,33703]
===
match
---
name: run_id [60318,60324]
name: run_id [60452,60458]
===
match
---
operator: = [27912,27913]
operator: = [27912,27913]
===
match
---
trailer [22871,22906]
trailer [22871,22906]
===
match
---
operator: = [30923,30924]
operator: = [30923,30924]
===
match
---
name: self [65233,65237]
name: self [65367,65371]
===
match
---
trailer [61185,61203]
trailer [61319,61337]
===
match
---
atom_expr [22495,22506]
atom_expr [22495,22506]
===
match
---
trailer [50888,50895]
trailer [50888,50895]
===
match
---
comparison [20354,20390]
comparison [20354,20390]
===
match
---
arglist [45760,45819]
arglist [45760,45819]
===
match
---
name: ti [82119,82121]
name: ti [82253,82255]
===
match
---
operator: = [54420,54421]
operator: = [54420,54421]
===
match
---
name: lazy_object_proxy [65027,65044]
name: lazy_object_proxy [65161,65178]
===
match
---
name: session [45479,45486]
name: session [45479,45486]
===
match
---
name: Union [52286,52291]
name: Union [52286,52291]
===
match
---
string: 'ti_pool' [10792,10801]
string: 'ti_pool' [10792,10801]
===
match
---
import_name [820,834]
import_name [820,834]
===
match
---
operator: , [59468,59469]
operator: , [59602,59603]
===
match
---
name: self [12121,12125]
name: self [12121,12125]
===
match
---
name: self [23379,23383]
name: self [23379,23383]
===
match
---
atom_expr [70710,70724]
atom_expr [70844,70858]
===
match
---
trailer [29662,29671]
trailer [29662,29671]
===
match
---
atom_expr [21667,21687]
atom_expr [21667,21687]
===
match
---
operator: = [68191,68192]
operator: = [68325,68326]
===
match
---
simple_stmt [39943,40226]
simple_stmt [39943,40226]
===
match
---
simple_stmt [1591,1630]
simple_stmt [1591,1630]
===
match
---
fstring_expr [49251,49254]
fstring_expr [49251,49254]
===
match
---
annassign [79723,79749]
annassign [79857,79883]
===
match
---
trailer [12088,12090]
trailer [12088,12090]
===
match
---
annassign [79908,79934]
annassign [80042,80068]
===
match
---
name: pool [10803,10807]
name: pool [10803,10807]
===
match
---
name: self [66210,66214]
name: self [66344,66348]
===
match
---
suite [59693,65944]
suite [59827,66078]
===
match
---
name: ti [22112,22114]
name: ti [22112,22114]
===
match
---
operator: , [32719,32720]
operator: , [32719,32720]
===
match
---
operator: , [8173,8174]
operator: , [8173,8174]
===
match
---
name: dag_id [11211,11217]
name: dag_id [11211,11217]
===
match
---
trailer [30092,30098]
trailer [30092,30098]
===
match
---
parameters [65981,65987]
parameters [66115,66121]
===
match
---
suite [19468,19848]
suite [19468,19848]
===
match
---
name: replace [61770,61777]
name: replace [61904,61911]
===
match
---
comparison [27709,27728]
comparison [27709,27728]
===
match
---
operator: , [11099,11100]
operator: , [11099,11100]
===
match
---
name: dag_id [8269,8275]
name: dag_id [8269,8275]
===
match
---
operator: { [19114,19115]
operator: { [19114,19115]
===
match
---
name: test_mode [42559,42568]
name: test_mode [42559,42568]
===
match
---
argument [9642,9658]
argument [9642,9658]
===
match
---
suite [56220,58859]
suite [56220,58993]
===
match
---
operator: , [64393,64394]
operator: , [64527,64528]
===
match
---
atom_expr [4128,4146]
atom_expr [4128,4146]
===
match
---
trailer [68337,68345]
trailer [68471,68479]
===
match
---
name: utils [2735,2740]
name: utils [2735,2740]
===
match
---
operator: = [42930,42931]
operator: = [42930,42931]
===
match
---
number: 1000 [9912,9916]
number: 1000 [9912,9916]
===
match
---
atom_expr [43192,43208]
atom_expr [43192,43208]
===
match
---
name: dep_status [32045,32055]
name: dep_status [32045,32055]
===
match
---
param [74433,74467]
param [74567,74601]
===
match
---
fstring_expr [44900,44913]
fstring_expr [44900,44913]
===
match
---
trailer [24818,24829]
trailer [24818,24829]
===
match
---
trailer [73724,73739]
trailer [73858,73873]
===
match
---
name: str [53649,53652]
name: str [53649,53652]
===
match
---
name: test_mode [44093,44102]
name: test_mode [44093,44102]
===
match
---
trailer [78099,78102]
trailer [78233,78236]
===
match
---
name: utcnow [35010,35016]
name: utcnow [35010,35016]
===
match
---
operator: @ [80433,80434]
operator: @ [80567,80568]
===
match
---
name: first [82085,82090]
name: first [82219,82224]
===
match
---
comparison [3675,3700]
comparison [3675,3700]
===
match
---
name: TaskInstance [20354,20366]
name: TaskInstance [20354,20366]
===
match
---
lambdef [65068,65129]
lambdef [65202,65263]
===
match
---
if_stmt [5210,5308]
if_stmt [5210,5308]
===
match
---
name: State [54638,54643]
name: State [54638,54643]
===
match
---
param [30898,30915]
param [30898,30915]
===
match
---
name: rendered_k8s_spec [67484,67501]
name: rendered_k8s_spec [67618,67635]
===
match
---
atom_expr [9677,9696]
atom_expr [9677,9696]
===
match
---
return_stmt [32198,32209]
return_stmt [32198,32209]
===
match
---
operator: , [59420,59421]
operator: , [59554,59555]
===
match
---
trailer [23485,23495]
trailer [23485,23495]
===
match
---
simple_stmt [50047,50084]
simple_stmt [50047,50084]
===
match
---
operator: = [80278,80279]
operator: = [80412,80413]
===
match
---
atom_expr [76674,76696]
atom_expr [76808,76830]
===
match
---
argument [60190,60212]
argument [60324,60346]
===
match
---
name: cmd [18123,18126]
name: cmd [18123,18126]
===
match
---
expr_stmt [79851,79878]
expr_stmt [79985,80012]
===
match
---
string: 'yesterday_ds_nodash' [65890,65911]
string: 'yesterday_ds_nodash' [66024,66045]
===
match
---
atom_expr [58842,58858]
atom_expr [58976,58992]
===
match
---
atom_expr [72416,72431]
atom_expr [72550,72565]
===
match
---
atom_expr [71234,71261]
atom_expr [71368,71395]
===
match
---
expr_stmt [62040,62091]
expr_stmt [62174,62225]
===
match
---
trailer [18983,18993]
trailer [18983,18993]
===
match
---
trailer [68456,68471]
trailer [68590,68605]
===
match
---
name: e [44339,44340]
name: e [44339,44340]
===
match
---
name: task_copy [50462,50471]
name: task_copy [50462,50471]
===
match
---
not_test [14629,14642]
not_test [14629,14642]
===
match
---
name: task [58721,58725]
name: task [58855,58859]
===
match
---
simple_stmt [56859,56896]
simple_stmt [56993,57030]
===
match
---
operator: = [25936,25937]
operator: = [25936,25937]
===
match
---
name: hexdigest [33933,33942]
name: hexdigest [33933,33942]
===
match
---
trailer [33570,33635]
trailer [33570,33635]
===
match
---
name: dr [27344,27346]
name: dr [27344,27346]
===
match
---
trailer [23953,23960]
trailer [23953,23960]
===
match
---
simple_stmt [8378,8463]
simple_stmt [8378,8463]
===
match
---
atom_expr [5213,5222]
atom_expr [5213,5222]
===
match
---
tfpdef [74397,74405]
tfpdef [74531,74539]
===
match
---
name: self [40873,40877]
name: self [40873,40877]
===
match
---
simple_stmt [59831,59867]
simple_stmt [59965,60001]
===
match
---
simple_stmt [71005,71088]
simple_stmt [71139,71222]
===
match
---
simple_stmt [61869,61901]
simple_stmt [62003,62035]
===
match
---
operator: , [81382,81383]
operator: , [81516,81517]
===
match
---
simple_stmt [42721,42752]
simple_stmt [42721,42752]
===
match
---
name: defaultdict [940,951]
name: defaultdict [940,951]
===
match
---
atom_expr [30826,30839]
atom_expr [30826,30839]
===
match
---
atom_expr [45323,45354]
atom_expr [45323,45354]
===
match
---
atom_expr [74367,74380]
atom_expr [74501,74514]
===
match
---
name: error [4286,4291]
name: error [4286,4291]
===
match
---
name: str [29189,29192]
name: str [29189,29192]
===
match
---
name: UndefinedError [1260,1274]
name: UndefinedError [1260,1274]
===
match
---
name: execution_timeout [51350,51367]
name: execution_timeout [51350,51367]
===
match
---
name: pod_generator [3092,3105]
name: pod_generator [3092,3105]
===
match
---
trailer [47078,47098]
trailer [47078,47098]
===
match
---
name: airflow [2510,2517]
name: airflow [2510,2517]
===
match
---
not_test [27177,27204]
not_test [27177,27204]
===
match
---
atom_expr [21497,21555]
atom_expr [21497,21555]
===
match
---
number: 1 [40647,40648]
number: 1 [40647,40648]
===
match
---
name: _key [80302,80306]
name: _key [80436,80440]
===
match
---
argument [29011,29023]
argument [29011,29023]
===
match
---
trailer [39911,39926]
trailer [39911,39926]
===
match
---
atom_expr [24698,24760]
atom_expr [24698,24760]
===
match
---
name: session [29794,29801]
name: session [29794,29801]
===
match
---
trailer [7763,7767]
trailer [7763,7767]
===
match
---
name: self [32916,32920]
name: self [32916,32920]
===
match
---
simple_stmt [14606,14651]
simple_stmt [14606,14651]
===
match
---
param [50682,50687]
param [50682,50687]
===
match
---
name: self [53013,53017]
name: self [53013,53017]
===
match
---
name: _state [79856,79862]
name: _state [79990,79996]
===
match
---
name: html_content_err [72319,72335]
name: html_content_err [72453,72469]
===
match
---
trailer [10388,10422]
trailer [10388,10422]
===
match
---
trailer [23978,23986]
trailer [23978,23986]
===
match
---
name: pool [22546,22550]
name: pool [22546,22550]
===
match
---
not_test [57634,57665]
not_test [57768,57799]
===
match
---
atom_expr [82063,82092]
atom_expr [82197,82226]
===
match
---
atom_expr [6838,6897]
atom_expr [6838,6897]
===
match
---
name: self [67826,67830]
name: self [67960,67964]
===
match
---
name: task [64414,64418]
name: task [64548,64552]
===
match
---
number: 1 [56784,56785]
number: 1 [56918,56919]
===
match
---
atom [18822,18846]
atom [18822,18846]
===
match
---
name: prev_execution_date [61799,61818]
name: prev_execution_date [61933,61952]
===
match
---
operator: = [60196,60197]
operator: = [60330,60331]
===
match
---
operator: = [48233,48234]
operator: = [48233,48234]
===
match
---
atom_expr [11287,11315]
atom_expr [11287,11315]
===
match
---
trailer [3202,3212]
trailer [3202,3212]
===
match
---
operator: = [42534,42535]
operator: = [42534,42535]
===
match
---
string: 'TaskInstanceKey' [8622,8639]
string: 'TaskInstanceKey' [8622,8639]
===
match
---
name: self [38950,38954]
name: self [38950,38954]
===
match
---
trailer [7884,7890]
trailer [7884,7890]
===
match
---
name: dep_status [32461,32471]
name: dep_status [32461,32471]
===
match
---
trailer [54336,54350]
trailer [54336,54350]
===
match
---
name: test_mode [44653,44662]
name: test_mode [44653,44662]
===
match
---
name: exception [71349,71358]
name: exception [71483,71492]
===
match
---
name: state [20915,20920]
name: state [20915,20920]
===
match
---
name: self [13297,13301]
name: self [13297,13301]
===
match
---
name: task [42529,42533]
name: task [42529,42533]
===
match
---
name: retries [23503,23510]
name: retries [23503,23510]
===
match
---
name: str [15925,15928]
name: str [15925,15928]
===
match
---
operator: , [43713,43714]
operator: , [43713,43714]
===
match
---
decorated [29097,29696]
decorated [29097,29696]
===
match
---
argument [74157,74172]
argument [74291,74306]
===
match
---
operator: , [24414,24415]
operator: , [24414,24415]
===
match
---
suite [14827,14865]
suite [14827,14865]
===
match
---
operator: { [19385,19386]
operator: { [19385,19386]
===
match
---
trailer [61553,61562]
trailer [61687,61696]
===
match
---
atom_expr [45174,45185]
atom_expr [45174,45185]
===
match
---
expr_stmt [10126,10159]
expr_stmt [10126,10159]
===
match
---
trailer [52143,52147]
trailer [52143,52147]
===
match
---
trailer [19021,19032]
trailer [19021,19032]
===
match
---
fstring_start: f' [42818,42820]
fstring_start: f' [42818,42820]
===
match
---
name: self [24353,24357]
name: self [24353,24357]
===
match
---
trailer [8743,8750]
trailer [8743,8750]
===
match
---
expr_stmt [23337,23370]
expr_stmt [23337,23370]
===
match
---
name: dag_id [46097,46103]
name: dag_id [46097,46103]
===
match
---
operator: = [50492,50493]
operator: = [50492,50493]
===
match
---
trailer [12192,12194]
trailer [12192,12194]
===
match
---
simple_stmt [9923,9955]
simple_stmt [9923,9955]
===
match
---
name: provide_session [26423,26438]
name: provide_session [26423,26438]
===
match
---
operator: , [56204,56205]
operator: , [56204,56205]
===
match
---
decorated [12467,12647]
decorated [12467,12647]
===
match
---
simple_stmt [22531,22551]
simple_stmt [22531,22551]
===
match
---
operator: = [22579,22580]
operator: = [22579,22580]
===
match
---
name: get_previous_execution_date [65081,65108]
name: get_previous_execution_date [65215,65242]
===
match
---
expr_stmt [19567,19611]
expr_stmt [19567,19611]
===
match
---
expr_stmt [37863,37896]
expr_stmt [37863,37896]
===
match
---
simple_stmt [27770,27834]
simple_stmt [27770,27834]
===
match
---
name: retries [5525,5532]
name: retries [5525,5532]
===
match
---
number: 2 [33630,33631]
number: 2 [33630,33631]
===
match
---
trailer [49242,49247]
trailer [49242,49247]
===
match
---
name: dep [32475,32478]
name: dep [32475,32478]
===
match
---
operator: < [34999,35000]
operator: < [34999,35000]
===
match
---
trailer [47789,47793]
trailer [47789,47793]
===
match
---
name: task_id [74038,74045]
name: task_id [74172,74179]
===
match
---
argument [38462,38501]
argument [38462,38501]
===
match
---
name: str [80948,80951]
name: str [81082,81085]
===
match
---
name: log [47790,47793]
name: log [47790,47793]
===
match
---
name: self [79851,79855]
name: self [79985,79989]
===
match
---
name: self [23437,23441]
name: self [23437,23441]
===
match
---
name: airflow [2677,2684]
name: airflow [2677,2684]
===
match
---
tfpdef [63155,63171]
tfpdef [63289,63305]
===
match
---
name: default [10063,10070]
name: default [10063,10070]
===
match
---
atom_expr [57679,57689]
atom_expr [57813,57823]
===
match
---
trailer [54908,54910]
trailer [54908,54910]
===
match
---
expr_stmt [14840,14864]
expr_stmt [14840,14864]
===
match
---
name: PickleType [1329,1339]
name: PickleType [1329,1339]
===
match
---
parameters [59415,59437]
parameters [59549,59571]
===
match
---
name: passed [32713,32719]
name: passed [32713,32719]
===
match
---
name: session [76443,76450]
name: session [76577,76584]
===
match
---
trailer [35402,35409]
trailer [35402,35409]
===
match
---
name: self [49513,49517]
name: self [49513,49517]
===
match
---
atom_expr [76227,76461]
atom_expr [76361,76595]
===
match
---
trailer [33822,33830]
trailer [33822,33830]
===
match
---
name: html_content [71976,71988]
name: html_content [72110,72122]
===
match
---
name: execution_date [64567,64581]
name: execution_date [64701,64715]
===
match
---
import_from [2071,2124]
import_from [2071,2124]
===
match
---
decorated [80846,80911]
decorated [80980,81045]
===
match
---
fstring_start: f" [19088,19090]
fstring_start: f" [19088,19090]
===
match
---
name: self [13131,13135]
name: self [13131,13135]
===
match
---
param [79537,79542]
param [79671,79676]
===
match
---
name: self [59340,59344]
name: self [59474,59478]
===
match
---
operator: = [66160,66161]
operator: = [66294,66295]
===
match
---
trailer [48708,48716]
trailer [48708,48716]
===
match
---
atom_expr [77681,77689]
atom_expr [77815,77823]
===
match
---
operator: , [37448,37449]
operator: , [37448,37449]
===
match
---
name: urllib [1123,1129]
name: urllib [1123,1129]
===
match
---
expr_stmt [37610,37640]
expr_stmt [37610,37640]
===
match
---
atom_expr [8549,8564]
atom_expr [8549,8564]
===
match
---
atom_expr [55529,55542]
atom_expr [55529,55542]
===
match
---
name: base_url [19338,19346]
name: base_url [19338,19346]
===
match
---
name: func [77353,77357]
name: func [77487,77491]
===
match
---
name: task [60197,60201]
name: task [60331,60335]
===
match
---
if_stmt [41438,41501]
if_stmt [41438,41501]
===
match
---
trailer [51339,51384]
trailer [51339,51384]
===
match
---
suite [68986,72190]
suite [69120,72324]
===
match
---
name: execution_date [74091,74105]
name: execution_date [74225,74239]
===
match
---
expr_stmt [26811,26830]
expr_stmt [26811,26830]
===
match
---
atom_expr [63818,63859]
atom_expr [63952,63993]
===
match
---
name: self [23519,23523]
name: self [23519,23523]
===
match
---
name: result [51406,51412]
name: result [51406,51412]
===
match
---
name: pickle_id [14633,14642]
name: pickle_id [14633,14642]
===
match
---
name: fmt [59433,59436]
name: fmt [59567,59570]
===
match
---
name: _priority_weight [80215,80231]
name: _priority_weight [80349,80365]
===
match
---
simple_stmt [70311,70340]
simple_stmt [70445,70474]
===
match
---
atom_expr [78644,78692]
atom_expr [78778,78826]
===
match
---
name: query [7629,7634]
name: query [7629,7634]
===
match
---
trailer [77119,77137]
trailer [77253,77271]
===
match
---
name: session [81806,81813]
name: session [81940,81947]
===
match
---
operator: , [44794,44795]
operator: , [44794,44795]
===
match
---
trailer [49333,49341]
trailer [49333,49341]
===
match
---
atom_expr [55560,55596]
atom_expr [55560,55596]
===
match
---
atom_expr [47459,47496]
atom_expr [47459,47496]
===
match
---
expr_stmt [10359,10422]
expr_stmt [10359,10422]
===
match
---
atom_expr [60423,60463]
atom_expr [60557,60597]
===
match
---
name: Optional [26540,26548]
name: Optional [26540,26548]
===
match
---
param [35638,35659]
param [35638,35659]
===
match
---
simple_stmt [80408,80428]
simple_stmt [80542,80562]
===
match
---
name: self [61204,61208]
name: self [61338,61342]
===
match
---
name: self [65982,65986]
name: self [66116,66120]
===
match
---
trailer [55259,55266]
trailer [55259,55266]
===
match
---
trailer [24706,24712]
trailer [24706,24712]
===
match
---
name: self [74033,74037]
name: self [74167,74171]
===
match
---
name: self [37421,37425]
name: self [37421,37425]
===
match
---
name: ti [47190,47192]
name: ti [47190,47192]
===
match
---
name: timer [48667,48672]
name: timer [48667,48672]
===
match
---
name: TaskInstance [79113,79125]
name: TaskInstance [79247,79259]
===
match
---
if_stmt [5367,5977]
if_stmt [5367,5977]
===
match
---
trailer [43053,43069]
trailer [43053,43069]
===
match
---
expr_stmt [9988,10029]
expr_stmt [9988,10029]
===
match
---
name: running [13151,13158]
name: running [13151,13158]
===
match
---
trailer [49444,49461]
trailer [49444,49461]
===
match
---
operator: @ [81315,81316]
operator: @ [81449,81450]
===
match
---
trailer [48340,48344]
trailer [48340,48344]
===
match
---
argument [6714,7089]
argument [6714,7089]
===
match
---
name: state [26478,26483]
name: state [26478,26483]
===
match
---
atom_expr [58948,58969]
atom_expr [59082,59103]
===
match
---
string: """Remake the key by subtracting 1 from try number to match in memory information""" [8378,8462]
string: """Remake the key by subtracting 1 from try number to match in memory information""" [8378,8462]
===
match
---
atom_expr [42737,42751]
atom_expr [42737,42751]
===
match
---
decorated [77733,79265]
decorated [77867,79399]
===
match
---
operator: , [73916,73917]
operator: , [74050,74051]
===
match
---
atom_expr [76198,76209]
atom_expr [76332,76343]
===
match
---
simple_stmt [60392,60409]
simple_stmt [60526,60543]
===
match
---
string: 'email' [71720,71727]
string: 'email' [71854,71861]
===
match
---
operator: , [46223,46224]
operator: , [46223,46224]
===
match
---
trailer [70939,70951]
trailer [71073,71085]
===
match
---
funcdef [50649,51033]
funcdef [50649,51033]
===
match
---
import_name [872,885]
import_name [872,885]
===
match
---
name: Union [56043,56048]
name: Union [56043,56048]
===
match
---
name: key [80312,80315]
name: key [80446,80449]
===
match
---
operator: , [53898,53899]
operator: , [53898,53899]
===
match
---
trailer [50792,50800]
trailer [50792,50800]
===
match
---
dotted_name [1370,1384]
dotted_name [1370,1384]
===
match
---
operator: , [42616,42617]
operator: , [42616,42617]
===
match
---
expr_stmt [24993,25058]
expr_stmt [24993,25058]
===
match
---
operator: , [53853,53854]
operator: , [53853,53854]
===
match
---
name: self [61921,61925]
name: self [62055,62059]
===
match
---
operator: , [9509,9510]
operator: , [9509,9510]
===
match
---
not_test [37677,37696]
not_test [37677,37696]
===
match
---
trailer [59997,60004]
trailer [60131,60138]
===
match
---
name: self [72795,72799]
name: self [72929,72933]
===
match
---
tfpdef [51863,51879]
tfpdef [51863,51879]
===
match
---
name: timezone [38968,38976]
name: timezone [38968,38976]
===
match
---
name: conf [71653,71657]
name: conf [71787,71791]
===
match
---
name: dag [11803,11806]
name: dag [11803,11806]
===
match
---
fstring_expr [56762,56778]
fstring_expr [56896,56912]
===
match
---
operator: = [21569,21570]
operator: = [21569,21570]
===
match
---
name: airflow [2191,2198]
name: airflow [2191,2198]
===
match
---
trailer [21598,21605]
trailer [21598,21605]
===
match
---
atom_expr [18147,18161]
atom_expr [18147,18161]
===
match
---
name: execution_date [81967,81981]
name: execution_date [82101,82115]
===
match
---
fstring_expr [44914,44928]
fstring_expr [44914,44928]
===
match
---
name: exception [56380,56389]
name: error [56512,56517]
===
match
---
trailer [7898,7906]
trailer [7898,7906]
===
match
---
name: info [41239,41243]
name: info [41239,41243]
===
match
---
name: execution_date [61209,61223]
name: execution_date [61343,61357]
===
match
---
name: failed [31645,31651]
name: failed [31645,31651]
===
match
---
suite [59271,59396]
suite [59405,59530]
===
match
---
atom_expr [50956,51032]
atom_expr [50956,51032]
===
match
---
operator: , [15071,15072]
operator: , [15071,15072]
===
match
---
atom [76911,76957]
atom [77045,77091]
===
match
---
sync_comp_for [7787,7800]
sync_comp_for [7787,7800]
===
match
---
name: execution_date [60428,60442]
name: execution_date [60562,60576]
===
match
---
operator: , [13279,13280]
operator: , [13279,13280]
===
match
---
funcdef [68061,68934]
funcdef [68195,69068]
===
match
---
operator: ** [70976,70978]
operator: ** [71110,71112]
===
match
---
param [41755,41788]
param [41755,41788]
===
match
---
atom_expr [52560,52569]
atom_expr [52560,52569]
===
match
---
param [11127,11154]
param [11127,11154]
===
match
---
name: try_number [8103,8113]
name: try_number [8103,8113]
===
match
---
operator: { [49255,49256]
operator: { [49255,49256]
===
match
---
name: first [82128,82133]
name: first [82262,82267]
===
match
---
operator: -> [52317,52319]
operator: -> [52317,52319]
===
match
---
operator: , [53474,53475]
operator: , [53474,53475]
===
match
---
name: retries [59350,59357]
name: retries [59484,59491]
===
match
---
name: statement [47872,47881]
name: statement [47872,47881]
===
match
---
atom_expr [8494,8505]
atom_expr [8494,8505]
===
match
---
simple_stmt [71835,71897]
simple_stmt [71969,72031]
===
match
---
operator: = [42631,42632]
operator: = [42631,42632]
===
match
---
string: 'Airflow alert: {{ti}}' [69319,69342]
string: 'Airflow alert: {{ti}}' [69453,69476]
===
match
---
name: self [42721,42725]
name: self [42721,42725]
===
match
---
name: self [40188,40192]
name: self [40188,40192]
===
match
---
simple_stmt [23337,23371]
simple_stmt [23337,23371]
===
match
---
trailer [56866,56870]
trailer [57000,57004]
===
match
---
atom_expr [37421,37469]
atom_expr [37421,37469]
===
match
---
operator: , [46719,46720]
operator: , [46719,46720]
===
match
---
trailer [47411,47435]
trailer [47411,47435]
===
match
---
decorated [80685,80761]
decorated [80819,80895]
===
match
---
fstring_string: <TaskInstance:  [32900,32915]
fstring_string: <TaskInstance:  [32900,32915]
===
match
---
name: provide_session [2706,2721]
name: provide_session [2706,2721]
===
match
---
name: DateTime [30345,30353]
name: DateTime [30345,30353]
===
match
---
name: str [16093,16096]
name: str [16093,16096]
===
match
---
name: DagRun [46042,46048]
name: DagRun [46042,46048]
===
match
---
operator: = [45990,45991]
operator: = [45990,45991]
===
match
---
operator: = [79679,79680]
operator: = [79813,79814]
===
match
---
name: bool [35685,35689]
name: bool [35685,35689]
===
match
---
name: execution_date [11740,11754]
name: execution_date [11740,11754]
===
match
---
name: state [24894,24899]
name: state [24894,24899]
===
match
---
atom_expr [70930,70992]
atom_expr [71064,71126]
===
match
---
name: pod [68832,68835]
name: pod [68966,68969]
===
match
---
trailer [19041,19071]
trailer [19041,19071]
===
match
---
atom_expr [10627,10671]
atom_expr [10627,10671]
===
match
---
arglist [19298,19321]
arglist [19298,19321]
===
match
---
name: t [78443,78444]
name: t [78577,78578]
===
match
---
atom_expr [22543,22550]
atom_expr [22543,22550]
===
match
---
name: error_fd [54277,54285]
name: error_fd [54277,54285]
===
match
---
name: Column [9622,9628]
name: Column [9622,9628]
===
match
---
fstring_string: ti.finish. [44890,44900]
fstring_string: ti.finish. [44890,44900]
===
match
---
trailer [76686,76696]
trailer [76820,76830]
===
match
---
name: self [41374,41378]
name: self [41374,41378]
===
match
---
sync_comp_for [47156,47226]
sync_comp_for [47156,47226]
===
match
---
dotted_name [2308,2341]
dotted_name [2308,2341]
===
match
---
atom_expr [25067,25086]
atom_expr [25067,25086]
===
match
---
name: session [26028,26035]
name: session [26028,26035]
===
match
---
comp_op [47062,47068]
comp_op [47062,47068]
===
match
---
not_test [37653,37672]
not_test [37653,37672]
===
match
---
name: self [62817,62821]
name: self [62951,62955]
===
match
---
trailer [56647,56652]
trailer [56781,56786]
===
match
---
return_stmt [19620,19847]
return_stmt [19620,19847]
===
match
---
operator: , [79095,79096]
operator: , [79229,79230]
===
match
---
name: timezone [11868,11876]
name: timezone [11868,11876]
===
match
---
operator: = [30149,30150]
operator: = [30149,30150]
===
match
---
arglist [46085,46164]
arglist [46085,46164]
===
match
---
decorated [28074,28553]
decorated [28074,28553]
===
match
---
operator: = [14896,14897]
operator: = [14896,14897]
===
match
---
arglist [71927,71962]
arglist [72061,72096]
===
match
---
name: property [81085,81093]
name: property [81219,81227]
===
match
---
name: TaskInstance [81820,81832]
name: TaskInstance [81954,81966]
===
match
---
name: where [7233,7238]
name: where [7233,7238]
===
match
---
name: query [76219,76224]
name: query [76353,76358]
===
match
---
fstring_end: ' [42857,42858]
fstring_end: ' [42857,42858]
===
match
---
name: job_id [14308,14314]
name: job_id [14308,14314]
===
match
---
operator: , [7802,7803]
operator: , [7802,7803]
===
match
---
operator: , [23960,23961]
operator: , [23960,23961]
===
match
---
expr_stmt [9605,9659]
expr_stmt [9605,9659]
===
match
---
argument [37551,37571]
argument [37551,37571]
===
match
---
suite [16098,18867]
suite [16098,18867]
===
match
---
name: TaskInstance [26272,26284]
name: TaskInstance [26272,26284]
===
match
---
trailer [43196,43200]
trailer [43196,43200]
===
match
---
expr_stmt [80034,80068]
expr_stmt [80168,80202]
===
match
---
name: var [63686,63689]
name: var [63820,63823]
===
match
---
name: log [40247,40250]
name: log [40247,40250]
===
match
---
name: str [58954,58957]
name: str [59088,59091]
===
match
---
simple_stmt [31595,31637]
simple_stmt [31595,31637]
===
match
---
name: exception_html [71380,71394]
name: exception_html [71514,71528]
===
match
---
name: task_copy [48410,48419]
name: task_copy [48410,48419]
===
match
---
funcdef [52237,53274]
funcdef [52237,53274]
===
match
---
argument [74091,74143]
argument [74225,74277]
===
match
---
simple_stmt [2933,2987]
simple_stmt [2933,2987]
===
match
---
operator: , [40560,40561]
operator: , [40560,40561]
===
match
---
name: pickle_id [18100,18109]
name: pickle_id [18100,18109]
===
match
---
operator: } [56777,56778]
operator: } [56911,56912]
===
match
---
trailer [61181,61185]
trailer [61315,61319]
===
match
---
name: self [81985,81989]
name: self [82119,82123]
===
match
---
trailer [39951,39959]
trailer [39951,39959]
===
match
---
trailer [61891,61900]
trailer [62025,62034]
===
match
---
name: next_ds [61486,61493]
name: next_ds [61620,61627]
===
match
---
if_stmt [21906,22848]
if_stmt [21906,22848]
===
match
---
operator: = [38310,38311]
operator: = [38310,38311]
===
match
---
name: next_ds [61406,61413]
name: next_ds [61540,61547]
===
match
---
param [19171,19175]
param [19171,19175]
===
match
---
expr_stmt [31595,31636]
expr_stmt [31595,31636]
===
match
---
name: ti [80309,80311]
name: ti [80443,80445]
===
match
---
name: IO [1052,1054]
name: IO [1052,1054]
===
match
---
atom_expr [78876,78938]
atom_expr [79010,79072]
===
match
---
atom_expr [27882,27934]
atom_expr [27882,27934]
===
match
---
name: self [12148,12152]
name: self [12148,12152]
===
match
---
operator: , [74287,74288]
operator: , [74421,74422]
===
match
---
operator: = [63853,63854]
operator: = [63987,63988]
===
match
---
name: ignore_task_deps [18326,18342]
name: ignore_task_deps [18326,18342]
===
match
---
simple_stmt [61975,62032]
simple_stmt [62109,62166]
===
match
---
trailer [58286,58294]
trailer [58420,58428]
===
match
---
argument [71174,71189]
argument [71308,71323]
===
match
---
atom_expr [14962,14973]
atom_expr [14962,14973]
===
match
---
atom_expr [22509,22518]
atom_expr [22509,22518]
===
match
---
name: TaskInstance [78534,78546]
name: TaskInstance [78668,78680]
===
match
---
atom_expr [77051,77061]
atom_expr [77185,77195]
===
match
---
name: self [26817,26821]
name: self [26817,26821]
===
match
---
atom_expr [22581,22594]
atom_expr [22581,22594]
===
match
---
trailer [78593,78608]
trailer [78727,78742]
===
match
---
funcdef [4250,4681]
funcdef [4250,4681]
===
match
---
simple_stmt [45432,45467]
simple_stmt [45432,45467]
===
match
---
operator: = [53778,53779]
operator: = [53778,53779]
===
match
---
trailer [18689,18696]
trailer [18689,18696]
===
match
---
argument [39488,39509]
argument [39488,39509]
===
match
---
parameters [22933,22965]
parameters [22933,22965]
===
match
---
name: self [33832,33836]
name: self [33832,33836]
===
match
---
name: models [2084,2090]
name: models [2084,2090]
===
match
---
trailer [22865,22871]
trailer [22865,22871]
===
match
---
name: verbose [30930,30937]
name: verbose [30930,30937]
===
match
---
name: fd [3919,3921]
name: fd [3919,3921]
===
match
---
expr_stmt [48174,48214]
expr_stmt [48174,48214]
===
match
---
operator: = [24670,24671]
operator: = [24670,24671]
===
match
---
name: kubernetes [3004,3014]
name: kubernetes [3004,3014]
===
match
---
atom_expr [26387,26416]
atom_expr [26387,26416]
===
match
---
expr_stmt [8057,8069]
expr_stmt [8057,8069]
===
match
---
trailer [39020,39038]
trailer [39020,39038]
===
match
---
trailer [56389,56396]
trailer [56517,56530]
===
match
---
name: foreign_keys [10997,11009]
name: foreign_keys [10997,11009]
===
match
---
trailer [52285,52308]
trailer [52285,52308]
===
match
---
trailer [51274,51292]
trailer [51274,51292]
===
match
---
classdef [8801,79265]
classdef [8801,79399]
===
match
---
trailer [79612,79621]
trailer [79746,79755]
===
match
---
name: task_id [44920,44927]
name: task_id [44920,44927]
===
match
---
atom_expr [3641,3663]
atom_expr [3641,3663]
===
match
---
operator: = [53987,53988]
operator: = [53987,53988]
===
match
---
expr_stmt [59875,59886]
expr_stmt [60009,60020]
===
match
---
expr_stmt [23258,23281]
expr_stmt [23258,23281]
===
match
---
name: task [50564,50568]
name: task [50564,50568]
===
match
---
return_stmt [81130,81148]
return_stmt [81264,81282]
===
match
---
atom_expr [4435,4457]
atom_expr [4435,4457]
===
match
---
tfpdef [15835,15846]
tfpdef [15835,15846]
===
match
---
atom_expr [23894,24078]
atom_expr [23894,24078]
===
match
---
argument [54368,54393]
argument [54368,54393]
===
match
---
not_test [25960,25988]
not_test [25960,25988]
===
match
---
name: task_id [78969,78976]
name: task_id [79103,79110]
===
match
---
name: delay [34568,34573]
name: delay [34568,34573]
===
match
---
name: create_pod_id [68306,68319]
name: create_pod_id [68440,68453]
===
match
---
atom_expr [9477,9509]
atom_expr [9477,9509]
===
match
---
atom_expr [79063,79082]
atom_expr [79197,79216]
===
match
---
simple_stmt [48743,48782]
simple_stmt [48743,48782]
===
match
---
name: jinja_context [70492,70505]
name: jinja_context [70626,70639]
===
match
---
expr_stmt [79887,79934]
expr_stmt [80021,80068]
===
match
---
name: commit [40895,40901]
name: commit [40895,40901]
===
match
---
operator: = [10070,10071]
operator: = [10070,10071]
===
match
---
simple_stmt [53143,53181]
simple_stmt [53143,53181]
===
match
---
name: getpid [40783,40789]
name: getpid [40783,40789]
===
match
---
suite [45419,45499]
suite [45419,45499]
===
match
---
atom_expr [62999,63012]
atom_expr [63133,63146]
===
match
---
string: 'Log: <a href="{{ti.log_url}}">Link</a><br>' [70056,70100]
string: 'Log: <a href="{{ti.log_url}}">Link</a><br>' [70190,70234]
===
match
---
operator: = [60530,60531]
operator: = [60664,60665]
===
match
---
name: max [8542,8545]
name: max [8542,8545]
===
match
---
funcdef [81098,81149]
funcdef [81232,81283]
===
match
---
if_stmt [27948,28048]
if_stmt [27948,28048]
===
match
---
sync_comp_for [78478,78490]
sync_comp_for [78612,78624]
===
match
---
operator: , [15325,15326]
operator: , [15325,15326]
===
match
---
return_stmt [51812,51825]
return_stmt [51812,51825]
===
match
---
name: TaskInstance [21619,21631]
name: TaskInstance [21619,21631]
===
match
---
operator: , [72157,72158]
operator: , [72291,72292]
===
match
---
name: __tablename__ [9423,9436]
name: __tablename__ [9423,9436]
===
match
---
trailer [65044,65050]
trailer [65178,65184]
===
match
---
operator: = [28501,28502]
operator: = [28501,28502]
===
match
---
name: t [78420,78421]
name: t [78554,78555]
===
match
---
atom [67317,67357]
atom [67451,67491]
===
match
---
expr_stmt [10303,10353]
expr_stmt [10303,10353]
===
match
---
atom_expr [45023,45365]
atom_expr [45023,45365]
===
match
---
simple_stmt [21881,21898]
simple_stmt [21881,21898]
===
match
---
operator: , [27920,27921]
operator: , [27920,27921]
===
match
---
name: e [44162,44163]
name: e [44162,44163]
===
match
---
return_stmt [64360,65943]
return_stmt [64494,66077]
===
match
---
name: prepare_for_execution [48191,48212]
name: prepare_for_execution [48191,48212]
===
match
---
atom_expr [11793,11815]
atom_expr [11793,11815]
===
match
---
atom_expr [7699,7708]
atom_expr [7699,7708]
===
match
---
name: self [11192,11196]
name: self [11192,11196]
===
match
---
simple_stmt [38078,38400]
simple_stmt [38078,38400]
===
match
---
name: vals_kv [76912,76919]
name: vals_kv [77046,77053]
===
match
---
trailer [4668,4675]
trailer [4668,4675]
===
match
---
name: state [52790,52795]
name: state [52790,52795]
===
match
---
atom_expr [39192,39207]
atom_expr [39192,39207]
===
match
---
trailer [10847,10868]
trailer [10847,10868]
===
match
---
name: task_id [42849,42856]
name: task_id [42849,42856]
===
match
---
argument [70556,70575]
argument [70690,70709]
===
match
---
name: mark_success [41088,41100]
name: mark_success [41088,41100]
===
match
---
operator: = [76268,76269]
operator: = [76402,76403]
===
match
---
operator: = [22303,22304]
operator: = [22303,22304]
===
match
---
trailer [12443,12453]
trailer [12443,12453]
===
match
---
trailer [33580,33634]
trailer [33580,33634]
===
match
---
import_as_names [1860,1888]
import_as_names [1860,1888]
===
match
---
parameters [3918,3933]
parameters [3918,3933]
===
match
---
operator: = [10946,10947]
operator: = [10946,10947]
===
match
---
decorated [20994,22907]
decorated [20994,22907]
===
match
---
name: State [29077,29082]
name: State [29077,29082]
===
match
---
operator: + [13994,13995]
operator: + [13994,13995]
===
match
---
atom_expr [39460,39736]
atom_expr [39460,39736]
===
match
---
name: warning [40251,40258]
name: warning [40251,40258]
===
match
---
trailer [67676,67680]
trailer [67810,67814]
===
match
---
name: items [7171,7176]
name: items [7171,7176]
===
match
---
name: task_id [76937,76944]
name: task_id [77071,77078]
===
match
---
simple_stmt [11851,11904]
simple_stmt [11851,11904]
===
match
---
simple_stmt [42692,42713]
simple_stmt [42692,42713]
===
match
---
fstring_end: ' [56778,56779]
fstring_end: ' [56912,56913]
===
match
---
trailer [6067,6074]
trailer [6067,6074]
===
match
---
operator: = [46818,46819]
operator: = [46818,46819]
===
match
---
tfpdef [35638,35651]
tfpdef [35638,35651]
===
match
---
name: str [8170,8173]
name: str [8170,8173]
===
match
---
trailer [60317,60324]
trailer [60451,60458]
===
match
---
operator: = [79588,79589]
operator: = [79722,79723]
===
match
---
atom_expr [44915,44927]
atom_expr [44915,44927]
===
match
---
trailer [12033,12044]
trailer [12033,12044]
===
match
---
operator: , [41275,41276]
operator: , [41275,41276]
===
match
---
trailer [68494,68510]
trailer [68628,68644]
===
match
---
simple_stmt [39895,39927]
simple_stmt [39895,39927]
===
match
---
name: _priority_weight [80116,80132]
name: _priority_weight [80250,80266]
===
match
---
expr_stmt [63807,63859]
expr_stmt [63941,63993]
===
match
---
trailer [63956,63960]
trailer [64090,64094]
===
match
---
name: pool [14329,14333]
name: pool [14329,14333]
===
match
---
name: enrich_errors [45647,45660]
name: enrich_errors [45647,45660]
===
match
---
argument [59222,59233]
argument [59356,59367]
===
match
---
name: state [37706,37711]
name: state [37706,37711]
===
match
---
arglist [71669,71681]
arglist [71803,71815]
===
match
---
operator: = [37493,37494]
operator: = [37493,37494]
===
match
---
trailer [76273,76288]
trailer [76407,76422]
===
match
---
name: raw [18669,18672]
name: raw [18669,18672]
===
match
---
name: _CURRENT_CONTEXT [3539,3555]
name: _CURRENT_CONTEXT [3539,3555]
===
match
---
name: execution_date [46149,46163]
name: execution_date [46149,46163]
===
match
---
trailer [5296,5307]
trailer [5296,5307]
===
match
---
trailer [3236,3245]
trailer [3236,3245]
===
match
---
suite [51560,51617]
suite [51560,51617]
===
match
---
operator: = [59838,59839]
operator: = [59972,59973]
===
match
---
fstring_string:  [ [32965,32967]
fstring_string:  [ [32965,32967]
===
match
---
fstring_start: f' [50537,50539]
fstring_start: f' [50537,50539]
===
match
---
decorator [81232,81242]
decorator [81366,81376]
===
match
---
suite [71683,71819]
suite [71817,71953]
===
match
---
suite [42872,43131]
suite [42872,43131]
===
match
---
atom_expr [71842,71896]
atom_expr [71976,72030]
===
match
---
simple_stmt [22857,22907]
simple_stmt [22857,22907]
===
match
---
operator: @ [55007,55008]
operator: @ [55007,55008]
===
match
---
expr_stmt [18958,18995]
expr_stmt [18958,18995]
===
match
---
string: 'ti_successes' [50607,50621]
string: 'ti_successes' [50607,50621]
===
match
---
trailer [14931,14948]
trailer [14931,14948]
===
match
---
atom_expr [23519,23539]
atom_expr [23519,23539]
===
match
---
return_stmt [82144,82153]
return_stmt [82278,82287]
===
match
---
operator: , [72994,72995]
operator: , [73128,73129]
===
match
---
trailer [10263,10272]
trailer [10263,10272]
===
match
---
trailer [46006,46242]
trailer [46006,46242]
===
match
---
name: DagRun [60068,60074]
name: DagRun [60202,60208]
===
match
---
simple_stmt [79424,79519]
simple_stmt [79558,79653]
===
match
---
name: deserialize_value [76759,76776]
name: deserialize_value [76893,76910]
===
match
---
name: log [49155,49158]
name: log [49155,49158]
===
match
---
name: yesterday_ds_nodash [62040,62059]
name: yesterday_ds_nodash [62174,62193]
===
match
---
name: rendered_task_instance_fields [66130,66159]
name: rendered_task_instance_fields [66264,66293]
===
match
---
suite [41072,41298]
suite [41072,41298]
===
match
---
term [37887,37895]
term [37887,37895]
===
match
---
name: self [14583,14587]
name: self [14583,14587]
===
match
---
trailer [56329,56339]
trailer [56329,56339]
===
match
---
simple_stmt [37581,37602]
simple_stmt [37581,37602]
===
match
---
name: session [40379,40386]
name: session [40379,40386]
===
match
---
parameters [26462,26536]
parameters [26462,26536]
===
match
---
name: var [62939,62942]
name: var [63073,63076]
===
match
---
trailer [47317,47341]
trailer [47317,47341]
===
match
---
name: schedulable_tis [47480,47495]
name: schedulable_tis [47480,47495]
===
match
---
name: XCom [2120,2124]
name: XCom [2120,2124]
===
match
---
name: session [28031,28038]
name: session [28031,28038]
===
match
---
name: create_pod_id [3050,3063]
name: create_pod_id [3050,3063]
===
match
---
import_from [2605,2671]
import_from [2605,2671]
===
match
---
trailer [54856,54861]
trailer [54856,54861]
===
match
---
param [41719,41746]
param [41719,41746]
===
match
---
name: property [24154,24162]
name: property [24154,24162]
===
match
---
name: self [8264,8268]
name: self [8264,8268]
===
match
---
operator: = [15419,15420]
operator: = [15419,15420]
===
match
---
dotted_name [1123,1135]
dotted_name [1123,1135]
===
match
---
operator: , [8547,8548]
operator: , [8547,8548]
===
match
---
atom [18640,18656]
atom [18640,18656]
===
match
---
suite [32097,32123]
suite [32097,32123]
===
match
---
number: 1 [60645,60646]
number: 1 [60779,60780]
===
match
---
operator: } [19112,19113]
operator: } [19112,19113]
===
match
---
name: state [10699,10704]
name: state [10699,10704]
===
match
---
name: kube_image [68423,68433]
name: kube_image [68557,68567]
===
match
---
operator: , [40166,40167]
operator: , [40166,40167]
===
match
---
string: 'task' [65340,65346]
string: 'task' [65474,65480]
===
match
---
trailer [5464,5482]
trailer [5464,5482]
===
match
---
name: priority_weight [10126,10141]
name: priority_weight [10126,10141]
===
match
---
name: params [67772,67778]
name: params [67906,67912]
===
match
---
name: execution_date [15601,15615]
name: execution_date [15601,15615]
===
match
---
name: dag_run [60983,60990]
name: dag_run [61117,61124]
===
match
---
atom_expr [42589,42637]
atom_expr [42589,42637]
===
match
---
name: prev_ds [64873,64880]
name: prev_ds [65007,65014]
===
match
---
name: sqlalchemy [1469,1479]
name: sqlalchemy [1469,1479]
===
match
---
param [62839,62849]
param [62973,62983]
===
match
---
string: '' [59573,59575]
string: '' [59707,59709]
===
match
---
trailer [28550,28552]
trailer [28550,28552]
===
match
---
parameters [56012,56211]
parameters [56012,56211]
===
match
---
trailer [74335,74340]
trailer [74469,74474]
===
match
---
annassign [79960,79982]
annassign [80094,80116]
===
match
---
param [59265,59269]
param [59399,59403]
===
match
---
name: task [48228,48232]
name: task [48228,48232]
===
match
---
atom_expr [48827,48886]
atom_expr [48827,48886]
===
match
---
tfpdef [15973,15994]
tfpdef [15973,15994]
===
match
---
arglist [10054,10088]
arglist [10054,10088]
===
match
---
name: TaskInstance [77510,77522]
name: TaskInstance [77644,77656]
===
match
---
operator: @ [80685,80686]
operator: @ [80819,80820]
===
match
---
operator: = [39118,39119]
operator: = [39118,39119]
===
match
---
name: strftime [61436,61444]
name: strftime [61570,61578]
===
match
---
argument [53867,53898]
argument [53867,53898]
===
match
---
name: Union [4293,4298]
name: Union [4293,4298]
===
match
---
operator: = [50785,50786]
operator: = [50785,50786]
===
match
---
simple_stmt [2562,2605]
simple_stmt [2562,2605]
===
match
---
name: error_file [56565,56575]
name: error_file [56699,56709]
===
match
---
name: timeout [2859,2866]
name: timeout [2859,2866]
===
match
---
operator: = [33565,33566]
operator: = [33565,33566]
===
match
---
trailer [47798,47937]
trailer [47798,47937]
===
match
---
name: session [74476,74483]
name: session [74610,74617]
===
match
---
not_test [42888,42904]
not_test [42888,42904]
===
match
---
trailer [44777,44792]
trailer [44777,44792]
===
match
---
name: conf [1625,1629]
name: conf [1625,1629]
===
match
---
param [25446,25458]
param [25446,25458]
===
match
---
name: prev_ds [61762,61769]
name: prev_ds [61896,61903]
===
match
---
name: datetime [8175,8183]
name: datetime [8175,8183]
===
match
---
param [53399,53429]
param [53399,53429]
===
match
---
suite [37940,40425]
suite [37940,40425]
===
match
---
trailer [19412,19419]
trailer [19412,19419]
===
match
---
argument [71483,71507]
argument [71617,71641]
===
match
---
decorator [29701,29718]
decorator [29701,29718]
===
match
---
operator: = [14356,14357]
operator: = [14356,14357]
===
match
---
string: 'task_instance_key_str' [65401,65424]
string: 'task_instance_key_str' [65535,65558]
===
match
---
name: dag [46814,46817]
name: dag [46814,46817]
===
match
---
suite [66257,66406]
suite [66391,66540]
===
match
---
if_stmt [45741,47973]
if_stmt [45741,47973]
===
match
---
trailer [21679,21687]
trailer [21679,21687]
===
match
---
name: execution_date [61926,61940]
name: execution_date [62060,62074]
===
match
---
name: delete_old_records [48927,48945]
name: delete_old_records [48927,48945]
===
match
---
name: warning [49886,49893]
name: warning [49886,49893]
===
match
---
atom_expr [71313,71526]
atom_expr [71447,71660]
===
match
---
comparison [52513,52539]
comparison [52513,52539]
===
match
---
name: error_file [44664,44674]
name: error_file [44664,44674]
===
match
---
name: retry_exponential_backoff [33264,33289]
name: retry_exponential_backoff [33264,33289]
===
match
---
simple_stmt [60034,60100]
simple_stmt [60168,60234]
===
match
---
string: """         Refreshes the task instance from the database based on the primary key          :param session: SQLAlchemy ORM Session         :type session: Session         :param lock_for_update: if True, indicates that the database should             lock the TaskInstance (issuing a FOR UPDATE clause) until the             session is committed.         :type lock_for_update: bool         """ [21095,21488]
string: """         Refreshes the task instance from the database based on the primary key          :param session: SQLAlchemy ORM Session         :type session: Session         :param lock_for_update: if True, indicates that the database should             lock the TaskInstance (issuing a FOR UPDATE clause) until the             session is committed.         :type lock_for_update: bool         """ [21095,21488]
===
match
---
name: settings [68805,68813]
name: settings [68939,68947]
===
match
---
simple_stmt [34732,34761]
simple_stmt [34732,34761]
===
match
---
atom_expr [78719,78786]
atom_expr [78853,78920]
===
match
---
name: error [59112,59117]
name: error [59246,59251]
===
match
---
atom_expr [19386,19398]
atom_expr [19386,19398]
===
match
---
name: task_id [6875,6882]
name: task_id [6875,6882]
===
match
---
string: """Key used to identify task instance.""" [7994,8035]
string: """Key used to identify task instance.""" [7994,8035]
===
match
---
name: self [58564,58568]
name: self [58698,58702]
===
match
---
simple_stmt [24935,24981]
simple_stmt [24935,24981]
===
match
---
name: RenderedTaskInstanceFields [48794,48820]
name: RenderedTaskInstanceFields [48794,48820]
===
match
---
trailer [9947,9953]
trailer [9947,9953]
===
match
---
string: 'yesterday_ds' [65848,65862]
string: 'yesterday_ds' [65982,65996]
===
match
---
simple_stmt [22415,22443]
simple_stmt [22415,22443]
===
match
---
name: execution_date [24021,24035]
name: execution_date [24021,24035]
===
match
---
atom_expr [73787,73933]
atom_expr [73921,74067]
===
match
---
atom [7698,7723]
atom [7698,7723]
===
match
---
param [53563,53590]
param [53563,53590]
===
match
---
trailer [10053,10089]
trailer [10053,10089]
===
match
---
operator: ** [71174,71176]
operator: ** [71308,71310]
===
match
---
operator: = [71709,71710]
operator: = [71843,71844]
===
match
---
atom_expr [39855,39865]
atom_expr [39855,39865]
===
match
---
operator: , [71409,71410]
operator: , [71543,71544]
===
match
---
trailer [76839,76847]
trailer [76973,76981]
===
match
---
atom_expr [72691,72704]
atom_expr [72825,72838]
===
match
---
name: cmd [18273,18276]
name: cmd [18273,18276]
===
match
---
simple_stmt [27255,27331]
simple_stmt [27255,27331]
===
match
---
name: Column [9677,9683]
name: Column [9677,9683]
===
match
---
atom_expr [22035,22046]
atom_expr [22035,22046]
===
match
---
name: task_copy [48235,48244]
name: task_copy [48235,48244]
===
match
---
name: self [80386,80390]
name: self [80520,80524]
===
match
---
expr_stmt [13297,13321]
expr_stmt [13297,13321]
===
match
---
string: "--subdir" [18754,18764]
string: "--subdir" [18754,18764]
===
match
---
trailer [60564,60567]
trailer [60698,60701]
===
match
---
operator: = [21991,21992]
operator: = [21991,21992]
===
match
---
atom_expr [26042,26074]
atom_expr [26042,26074]
===
match
---
atom_expr [18629,18657]
atom_expr [18629,18657]
===
match
---
trailer [14812,14826]
trailer [14812,14826]
===
match
---
trailer [72803,72809]
trailer [72937,72943]
===
match
---
annassign [8047,8052]
annassign [8047,8052]
===
match
---
expr_stmt [71100,71190]
expr_stmt [71234,71324]
===
match
---
trailer [9816,9850]
trailer [9816,9850]
===
match
---
testlist [8264,8310]
testlist [8264,8310]
===
match
---
name: ignore_task_deps [14143,14159]
name: ignore_task_deps [14143,14159]
===
match
---
suite [52540,52772]
suite [52540,52772]
===
match
---
param [79543,79559]
param [79677,79693]
===
match
---
trailer [70832,70849]
trailer [70966,70983]
===
match
---
name: utils [2471,2476]
name: utils [2471,2476]
===
match
---
tfpdef [35939,35958]
tfpdef [35939,35958]
===
match
---
funcdef [45665,47973]
funcdef [45665,47973]
===
match
---
operator: , [48861,48862]
operator: , [48861,48862]
===
match
---
operator: == [34946,34948]
operator: == [34946,34948]
===
match
---
name: self [22830,22834]
name: self [22830,22834]
===
match
---
simple_stmt [59875,59887]
simple_stmt [60009,60021]
===
match
---
param [54782,54786]
param [54782,54786]
===
match
---
trailer [22861,22865]
trailer [22861,22865]
===
match
---
atom_expr [61486,61510]
atom_expr [61620,61644]
===
match
---
simple_stmt [952,993]
simple_stmt [952,993]
===
match
---
name: in_ [6883,6886]
name: in_ [6883,6886]
===
match
---
simple_stmt [71976,72045]
simple_stmt [72110,72179]
===
match
---
trailer [31725,31729]
trailer [31725,31729]
===
match
---
trailer [11266,11271]
trailer [11266,11271]
===
match
---
testlist_comp [18823,18845]
testlist_comp [18823,18845]
===
match
---
expr_stmt [9923,9954]
expr_stmt [9923,9954]
===
match
---
operator: , [64512,64513]
operator: , [64646,64647]
===
match
---
name: getuser [12081,12088]
name: getuser [12081,12088]
===
match
---
name: execution_date [73684,73698]
name: execution_date [73818,73832]
===
match
---
name: render [70969,70975]
name: render [71103,71109]
===
match
---
operator: , [14973,14974]
operator: , [14973,14974]
===
match
---
atom_expr [47612,47628]
atom_expr [47612,47628]
===
match
---
comparison [81903,81940]
comparison [82037,82074]
===
match
---
for_stmt [66270,66406]
for_stmt [66404,66540]
===
match
---
trailer [11776,11816]
trailer [11776,11816]
===
match
---
operator: , [63835,63836]
operator: , [63969,63970]
===
match
---
trailer [32671,32680]
trailer [32671,32680]
===
match
---
expr_stmt [50774,50800]
expr_stmt [50774,50800]
===
match
---
name: dag_id [6655,6661]
name: dag_id [6655,6661]
===
match
---
trailer [42848,42856]
trailer [42848,42856]
===
match
---
atom_expr [57692,57704]
atom_expr [57826,57838]
===
match
---
atom_expr [27280,27289]
atom_expr [27280,27289]
===
match
---
name: queued_by_job_id [10238,10254]
name: queued_by_job_id [10238,10254]
===
match
---
operator: , [53553,53554]
operator: , [53553,53554]
===
match
---
trailer [78126,78133]
trailer [78260,78267]
===
match
---
parameters [25439,25459]
parameters [25439,25459]
===
match
---
operator: , [33944,33945]
operator: , [33944,33945]
===
match
---
name: unixname [9923,9931]
name: unixname [9923,9931]
===
match
---
operator: = [71808,71809]
operator: = [71942,71943]
===
match
---
trailer [56607,56626]
trailer [56741,56760]
===
match
---
simple_stmt [22373,22403]
simple_stmt [22373,22403]
===
match
---
return_stmt [14912,15466]
return_stmt [14912,15466]
===
match
---
name: execute [51592,51599]
name: execute [51592,51599]
===
match
---
name: self [54852,54856]
name: self [54852,54856]
===
match
---
simple_stmt [42761,42799]
simple_stmt [42761,42799]
===
match
---
arglist [76835,76859]
arglist [76969,76993]
===
match
---
operator: = [14845,14846]
operator: = [14845,14846]
===
match
---
name: ti [5171,5173]
name: ti [5171,5173]
===
match
---
trailer [22023,22032]
trailer [22023,22032]
===
match
---
tfpdef [53599,53614]
tfpdef [53599,53614]
===
match
---
name: self [22857,22861]
name: self [22857,22861]
===
match
---
param [72915,72924]
param [73049,73058]
===
match
---
name: Sentry [41546,41552]
name: Sentry [41546,41552]
===
match
---
operator: , [43743,43744]
operator: , [43743,43744]
===
match
---
trailer [24304,24369]
trailer [24304,24369]
===
match
---
name: task [52858,52862]
name: task [52858,52862]
===
match
---
simple_stmt [1150,1162]
simple_stmt [1150,1162]
===
match
---
operator: , [11672,11673]
operator: , [11672,11673]
===
match
---
simple_stmt [41230,41298]
simple_stmt [41230,41298]
===
match
---
suite [13372,13878]
suite [13372,13878]
===
match
---
trailer [18276,18283]
trailer [18276,18283]
===
match
---
atom_expr [80095,80102]
atom_expr [80229,80236]
===
match
---
trailer [71570,71575]
trailer [71704,71709]
===
match
---
atom [33611,33632]
atom [33611,33632]
===
match
---
trailer [46563,46578]
trailer [46563,46578]
===
match
---
decorator [45618,45635]
decorator [45618,45635]
===
match
---
name: default_var [63341,63352]
name: default_var [63475,63486]
===
match
---
param [4286,4314]
param [4286,4314]
===
match
---
name: Optional [29772,29780]
name: Optional [29772,29780]
===
match
---
or_test [22581,22599]
or_test [22581,22599]
===
match
---
trailer [10289,10298]
trailer [10289,10298]
===
match
---
argument [9840,9849]
argument [9840,9849]
===
match
---
arglist [28294,28504]
arglist [28294,28504]
===
match
---
name: property [8125,8133]
name: property [8125,8133]
===
match
---
arglist [58145,58477]
arglist [58279,58611]
===
match
---
suite [41386,41501]
suite [41386,41501]
===
match
---
name: extend [18690,18696]
name: extend [18690,18696]
===
match
---
expr_stmt [82156,82175]
expr_stmt [82290,82309]
===
match
---
trailer [18444,18451]
trailer [18444,18451]
===
match
---
trailer [19293,19297]
trailer [19293,19297]
===
match
---
expr_stmt [23437,23472]
expr_stmt [23437,23472]
===
match
---
name: error_file [41755,41765]
name: error_file [41755,41765]
===
match
---
atom_expr [60392,60408]
atom_expr [60526,60542]
===
match
---
trailer [81833,81840]
trailer [81967,81974]
===
match
---
decorated [13883,13998]
decorated [13883,13998]
===
match
---
name: get_template_context [67982,68002]
name: get_template_context [68116,68136]
===
match
---
exprlist [49264,49268]
exprlist [49264,49268]
===
match
---
suite [50344,50409]
suite [50344,50409]
===
match
---
operator: , [3881,3882]
operator: , [3881,3882]
===
match
---
trailer [58131,58487]
trailer [58265,58621]
===
match
---
trailer [76820,76834]
trailer [76954,76968]
===
match
---
simple_stmt [20597,20610]
simple_stmt [20597,20610]
===
match
---
simple_stmt [25067,25087]
simple_stmt [25067,25087]
===
match
---
name: handle_failure [55998,56012]
name: handle_failure [55998,56012]
===
match
---
trailer [67160,67177]
trailer [67294,67311]
===
match
---
simple_stmt [3068,3126]
simple_stmt [3068,3126]
===
match
---
string: """         Forces the task instance's state to FAILED in the database.          :param session: SQLAlchemy ORM Session         :type session: Session         """ [20675,20837]
string: """         Forces the task instance's state to FAILED in the database.          :param session: SQLAlchemy ORM Session         :type session: Session         """ [20675,20837]
===
match
---
expr_stmt [37581,37601]
expr_stmt [37581,37601]
===
match
---
name: write [48821,48826]
name: write [48821,48826]
===
match
---
name: self [14962,14966]
name: self [14962,14966]
===
match
---
operator: = [35982,35983]
operator: = [35982,35983]
===
match
---
trailer [40386,40393]
trailer [40386,40393]
===
match
---
simple_stmt [25469,25923]
simple_stmt [25469,25923]
===
match
---
operator: = [58087,58088]
operator: = [58221,58222]
===
match
---
name: Variable [64123,64131]
name: Variable [64257,64265]
===
match
---
argument [70976,70991]
argument [71110,71125]
===
match
---
trailer [6078,6093]
trailer [6078,6093]
===
match
---
operator: = [19229,19230]
operator: = [19229,19230]
===
match
---
atom_expr [66359,66405]
atom_expr [66493,66539]
===
match
---
name: ApiClient [2918,2927]
name: ApiClient [2918,2927]
===
match
---
decorator [3287,3314]
decorator [3287,3314]
===
match
---
if_stmt [27706,27935]
if_stmt [27706,27935]
===
match
---
simple_stmt [72057,72134]
simple_stmt [72191,72268]
===
match
---
trailer [22433,22442]
trailer [22433,22442]
===
match
---
name: bool [35647,35651]
name: bool [35647,35651]
===
match
---
atom_expr [53153,53180]
atom_expr [53153,53180]
===
match
---
operator: = [9522,9523]
operator: = [9522,9523]
===
match
---
name: state [57974,57979]
name: state [58108,58113]
===
match
---
trailer [59819,59821]
trailer [59953,59955]
===
match
---
trailer [52990,52999]
trailer [52990,52999]
===
match
---
operator: = [56675,56676]
operator: = [56809,56810]
===
match
---
suite [65988,66935]
suite [66122,67069]
===
match
---
operator: , [61505,61506]
operator: , [61639,61640]
===
match
---
name: run [53304,53307]
name: run [53304,53307]
===
match
---
atom_expr [54950,54973]
atom_expr [54950,54973]
===
match
---
argument [10404,10420]
argument [10404,10420]
===
match
---
name: execution_date [19242,19256]
name: execution_date [19242,19256]
===
match
---
operator: = [53845,53846]
operator: = [53845,53846]
===
match
---
simple_stmt [48053,48086]
simple_stmt [48053,48086]
===
match
---
operator: , [45354,45355]
operator: , [45354,45355]
===
match
---
suite [57834,57891]
suite [57968,58025]
===
match
---
atom_expr [72690,72739]
atom_expr [72824,72873]
===
match
---
name: error [56390,56395]
name: error [56524,56529]
===
match
---
operator: , [1767,1768]
operator: , [1767,1768]
===
match
---
atom_expr [68452,68471]
atom_expr [68586,68605]
===
match
---
simple_stmt [18958,18996]
simple_stmt [18958,18996]
===
match
---
operator: , [35987,35988]
operator: , [35987,35988]
===
match
---
arglist [46028,46224]
arglist [46028,46224]
===
match
---
trailer [4059,4064]
trailer [4059,4064]
===
match
---
tfpdef [15796,15817]
tfpdef [15796,15817]
===
match
---
suite [4112,4147]
suite [4112,4147]
===
match
---
name: task_id [79140,79147]
name: task_id [79274,79281]
===
match
---
trailer [28800,29034]
trailer [28800,29034]
===
match
---
operator: < [73718,73719]
operator: < [73852,73853]
===
match
---
operator: , [78858,78859]
operator: , [78992,78993]
===
match
---
trailer [82133,82135]
trailer [82267,82269]
===
match
---
atom_expr [64414,64422]
atom_expr [64548,64556]
===
match
---
try_stmt [66432,66935]
try_stmt [66566,67069]
===
match
---
operator: = [46091,46092]
operator: = [46091,46092]
===
match
---
suite [62738,62771]
suite [62872,62905]
===
match
---
arglist [56742,56785]
arglist [56876,56919]
===
match
---
expr_stmt [52693,52721]
expr_stmt [52693,52721]
===
match
---
simple_stmt [54332,54579]
simple_stmt [54332,54579]
===
match
---
name: execution_date [11101,11115]
name: execution_date [11101,11115]
===
match
---
param [18903,18907]
param [18903,18907]
===
match
---
atom_expr [12370,12378]
atom_expr [12370,12378]
===
match
---
fstring_string: = [49254,49255]
fstring_string: = [49254,49255]
===
match
---
operator: , [49265,49266]
operator: , [49265,49266]
===
match
---
expr_stmt [10554,10875]
expr_stmt [10554,10875]
===
match
---
trailer [56967,56982]
trailer [57101,57116]
===
match
---
name: lazy_object_proxy [1183,1200]
name: lazy_object_proxy [1183,1200]
===
match
---
name: task [11310,11314]
name: task [11310,11314]
===
match
---
operator: , [5950,5951]
operator: , [5950,5951]
===
match
---
trailer [29596,29626]
trailer [29596,29626]
===
match
---
name: String [9477,9483]
name: String [9477,9483]
===
match
---
operator: -> [81182,81184]
operator: -> [81316,81318]
===
match
---
expr_stmt [61682,61732]
expr_stmt [61816,61866]
===
match
---
atom_expr [81057,81078]
atom_expr [81191,81212]
===
match
---
param [3338,3354]
param [3338,3354]
===
match
---
string: 'macros' [64631,64639]
string: 'macros' [64765,64773]
===
match
---
name: filter [81834,81840]
name: filter [81968,81974]
===
match
---
name: kubernetes_helper_functions [3015,3042]
name: kubernetes_helper_functions [3015,3042]
===
match
---
trailer [5940,5950]
trailer [5940,5950]
===
match
---
name: pool_slots [10034,10044]
name: pool_slots [10034,10044]
===
match
---
param [15796,15826]
param [15796,15826]
===
match
---
trailer [80236,80252]
trailer [80370,80386]
===
match
---
trailer [6654,6661]
trailer [6654,6661]
===
match
---
tfpdef [15601,15625]
tfpdef [15601,15625]
===
match
---
operator: = [61325,61326]
operator: = [61459,61460]
===
match
---
simple_stmt [71100,71191]
simple_stmt [71234,71325]
===
match
---
name: self [13366,13370]
name: self [13366,13370]
===
match
---
name: try_number [22292,22302]
name: try_number [22292,22302]
===
match
---
simple_stmt [56371,56397]
simple_stmt [56503,56531]
===
match
---
trailer [51704,51717]
trailer [51704,51717]
===
match
---
name: task_id [10745,10752]
name: task_id [10745,10752]
===
match
---
return_stmt [34928,35018]
return_stmt [34928,35018]
===
match
---
decorator [13327,13337]
decorator [13327,13337]
===
match
---
trailer [45027,45031]
trailer [45027,45031]
===
match
---
atom_expr [10283,10298]
atom_expr [10283,10298]
===
match
---
trailer [25387,25389]
trailer [25387,25389]
===
match
---
name: self [67178,67182]
name: self [67312,67316]
===
match
---
name: DagRun [35279,35285]
name: DagRun [35279,35285]
===
match
---
operator: = [29786,29787]
operator: = [29786,29787]
===
match
---
parameters [80794,80800]
parameters [80928,80934]
===
match
---
name: rendered_value [66390,66404]
name: rendered_value [66524,66538]
===
match
---
name: task [14588,14592]
name: task [14588,14592]
===
match
---
atom_expr [11324,11333]
atom_expr [11324,11333]
===
match
---
atom_expr [46550,46788]
atom_expr [46550,46788]
===
match
---
expr_stmt [9765,9791]
expr_stmt [9765,9791]
===
match
---
trailer [18068,18088]
trailer [18068,18088]
===
match
---
funcdef [81168,81227]
funcdef [81302,81361]
===
match
---
name: task_id_by_key [6134,6148]
name: task_id_by_key [6134,6148]
===
match
---
atom_expr [18356,18393]
atom_expr [18356,18393]
===
match
---
name: get_template_context [71239,71259]
name: get_template_context [71373,71393]
===
match
---
operator: , [54088,54089]
operator: , [54088,54089]
===
match
---
operator: , [10061,10062]
operator: , [10061,10062]
===
match
---
name: session [53706,53713]
name: session [53706,53713]
===
match
---
name: rendered_task_instance_fields [66227,66256]
name: rendered_task_instance_fields [66361,66390]
===
match
---
simple_stmt [12029,12049]
simple_stmt [12029,12049]
===
match
---
dictorsetmaker [64381,65933]
dictorsetmaker [64515,66067]
===
match
---
suite [21868,21898]
suite [21868,21898]
===
match
---
parameters [80539,80545]
parameters [80673,80679]
===
match
---
name: self [59627,59631]
name: self [59761,59765]
===
match
---
name: mark_success [42892,42904]
name: mark_success [42892,42904]
===
match
---
simple_stmt [64360,65944]
simple_stmt [64494,66078]
===
match
---
atom_expr [32378,32390]
atom_expr [32378,32390]
===
match
---
parameters [58917,59074]
parameters [59051,59208]
===
match
---
operator: = [29194,29195]
operator: = [29194,29195]
===
match
---
name: log [67677,67680]
name: log [67811,67814]
===
match
---
name: execution_date [41282,41296]
name: execution_date [41282,41296]
===
match
---
suite [19177,19422]
suite [19177,19422]
===
match
---
name: get_previous_ti [26447,26462]
name: get_previous_ti [26447,26462]
===
match
---
suite [55206,55226]
suite [55206,55226]
===
match
---
operator: = [52647,52648]
operator: = [52647,52648]
===
match
---
arglist [49181,49303]
arglist [49181,49303]
===
match
---
name: provide_session [81316,81331]
name: provide_session [81450,81465]
===
match
---
name: contextmanager [3299,3313]
name: contextmanager [3299,3313]
===
match
---
operator: = [9710,9711]
operator: = [9710,9711]
===
match
---
expr_stmt [52553,52569]
expr_stmt [52553,52569]
===
match
---
suite [25129,25390]
suite [25129,25390]
===
match
---
name: refresh_from_db [44182,44197]
name: refresh_from_db [44182,44197]
===
match
---
name: executor_config [79919,79934]
name: executor_config [80053,80068]
===
match
---
operator: -> [74507,74509]
operator: -> [74641,74643]
===
match
---
string: "--ignore-all-dependencies" [18285,18312]
string: "--ignore-all-dependencies" [18285,18312]
===
match
---
parameters [50681,50701]
parameters [50681,50701]
===
match
---
decorated [80507,80595]
decorated [80641,80729]
===
match
---
trailer [30155,30171]
trailer [30155,30171]
===
match
---
simple_stmt [80077,80103]
simple_stmt [80211,80237]
===
match
---
name: session [50688,50695]
name: session [50688,50695]
===
match
---
name: self [65076,65080]
name: self [65210,65214]
===
match
---
expr_stmt [43500,43526]
expr_stmt [43500,43526]
===
match
---
suite [44864,44944]
suite [44864,44944]
===
match
---
expr_stmt [21820,21854]
expr_stmt [21820,21854]
===
match
---
trailer [27274,27330]
trailer [27274,27330]
===
match
---
tfpdef [26507,26523]
tfpdef [26507,26523]
===
match
---
atom_expr [78746,78755]
atom_expr [78880,78889]
===
match
---
operator: , [54393,54394]
operator: , [54393,54394]
===
match
---
atom_expr [61692,61732]
atom_expr [61826,61866]
===
match
---
name: delete_qry [7275,7285]
name: delete_qry [7275,7285]
===
match
---
trailer [60506,60508]
trailer [60640,60642]
===
match
---
simple_stmt [50230,50266]
simple_stmt [50230,50266]
===
match
---
name: set_current_context [50315,50334]
name: set_current_context [50315,50334]
===
match
---
string: """         Returns the DagRun for this TaskInstance          :param session: SQLAlchemy ORM Session         :return: DagRun         """ [35100,35236]
string: """         Returns the DagRun for this TaskInstance          :param session: SQLAlchemy ORM Session         :return: DagRun         """ [35100,35236]
===
match
---
name: state [27928,27933]
name: state [27928,27933]
===
match
---
name: get_failed_dep_statuses [31767,31790]
name: get_failed_dep_statuses [31767,31790]
===
match
---
operator: , [41264,41265]
operator: , [41264,41265]
===
match
---
trailer [22063,22072]
trailer [22063,22072]
===
match
---
suite [66342,66406]
suite [66476,66540]
===
match
---
atom_expr [24796,24811]
atom_expr [24796,24811]
===
match
---
operator: = [80148,80149]
operator: = [80282,80283]
===
match
---
name: ignore_task_deps [53484,53500]
name: ignore_task_deps [53484,53500]
===
match
---
name: datetime [973,981]
name: datetime [973,981]
===
match
---
atom_expr [81877,81889]
atom_expr [82011,82023]
===
match
---
name: html_content_err [71100,71116]
name: html_content_err [71234,71250]
===
match
---
funcdef [80780,80841]
funcdef [80914,80975]
===
match
---
operator: == [23987,23989]
operator: == [23987,23989]
===
match
---
operator: - [5593,5594]
operator: - [5593,5594]
===
match
---
operator: } [19098,19099]
operator: } [19098,19099]
===
match
---
suite [6149,7287]
suite [6149,7287]
===
match
---
name: log [55903,55906]
name: log [55903,55906]
===
match
---
suite [20517,20550]
suite [20517,20550]
===
match
---
atom_expr [53013,53023]
atom_expr [53013,53023]
===
match
---
simple_stmt [41306,41318]
simple_stmt [41306,41318]
===
match
---
name: execution_date [73902,73916]
name: execution_date [74036,74050]
===
match
---
name: bool [15813,15817]
name: bool [15813,15817]
===
match
---
name: macros [64641,64647]
name: macros [64775,64781]
===
match
---
name: prev_ds_nodash [64912,64926]
name: prev_ds_nodash [65046,65060]
===
match
---
simple_stmt [54608,54683]
simple_stmt [54608,54683]
===
match
---
simple_stmt [79851,79879]
simple_stmt [79985,80013]
===
match
---
operator: = [15058,15059]
operator: = [15058,15059]
===
match
---
simple_stmt [71704,71734]
simple_stmt [71838,71868]
===
match
---
name: subject [72433,72440]
name: subject [72567,72574]
===
match
---
trailer [56375,56379]
trailer [56507,56511]
===
match
---
operator: = [12045,12046]
operator: = [12045,12046]
===
match
---
name: self [48743,48747]
name: self [48743,48747]
===
match
---
atom_expr [53027,53045]
atom_expr [53027,53045]
===
match
---
atom_expr [80111,80132]
atom_expr [80245,80266]
===
match
---
atom_expr [80210,80231]
atom_expr [80344,80365]
===
match
---
atom_expr [78807,79008]
atom_expr [78941,79142]
===
match
---
simple_stmt [77024,77071]
simple_stmt [77158,77205]
===
match
---
trailer [69277,69291]
trailer [69411,69425]
===
match
---
suite [14369,15467]
suite [14369,15467]
===
match
---
string: "Dependencies not met for %s, dependency '%s' FAILED: %s" [31911,31968]
string: "Dependencies not met for %s, dependency '%s' FAILED: %s" [31911,31968]
===
match
---
operator: - [60553,60554]
operator: - [60687,60688]
===
match
---
param [20652,20664]
param [20652,20664]
===
match
---
import_from [2505,2561]
import_from [2505,2561]
===
match
---
operator: = [40307,40308]
operator: = [40307,40308]
===
match
---
operator: = [80093,80094]
operator: = [80227,80228]
===
match
---
name: ignore_depends_on_past [53935,53957]
name: ignore_depends_on_past [53935,53957]
===
match
---
name: self [25081,25085]
name: self [25081,25085]
===
match
---
simple_stmt [77865,77930]
simple_stmt [77999,78064]
===
match
---
name: query_for_task_instance [39081,39104]
name: query_for_task_instance [39081,39104]
===
match
---
operator: } [19398,19399]
operator: } [19398,19399]
===
match
---
arglist [7680,7803]
arglist [7680,7803]
===
match
---
name: render [71920,71926]
name: render [72054,72060]
===
match
---
name: context [51433,51440]
name: context [51433,51440]
===
match
---
trailer [13183,13195]
trailer [13183,13195]
===
match
---
name: self [32945,32949]
name: self [32945,32949]
===
match
---
name: self [66367,66371]
name: self [66501,66505]
===
match
---
name: self [55396,55400]
name: self [55396,55400]
===
match
---
atom_expr [19231,19269]
atom_expr [19231,19269]
===
match
---
operator: = [55249,55250]
operator: = [55249,55250]
===
match
---
name: BaseJob [82428,82435]
name: BaseJob [82562,82569]
===
match
---
name: exc [52227,52230]
name: exc [52227,52230]
===
match
---
name: replace [62015,62022]
name: replace [62149,62156]
===
match
---
name: self [43702,43706]
name: self [43702,43706]
===
match
---
name: get_failed_dep_statuses [32240,32263]
name: get_failed_dep_statuses [32240,32263]
===
match
---
operator: { [62205,62206]
operator: { [62339,62340]
===
match
---
operator: = [10082,10083]
operator: = [10082,10083]
===
match
---
name: tis [78782,78785]
name: tis [78916,78919]
===
match
---
dotted_name [1414,1428]
dotted_name [1414,1428]
===
match
---
argument [64303,64326]
argument [64437,64460]
===
match
---
trailer [52032,52052]
trailer [52032,52052]
===
match
---
operator: = [47150,47151]
operator: = [47150,47151]
===
match
---
name: duration [72771,72779]
name: duration [72905,72913]
===
match
---
trailer [49517,49539]
trailer [49517,49539]
===
match
---
operator: = [25453,25454]
operator: = [25453,25454]
===
match
---
simple_stmt [61317,61332]
simple_stmt [61451,61466]
===
match
---
operator: , [59067,59068]
operator: , [59201,59202]
===
match
---
name: ti [26354,26356]
name: ti [26354,26356]
===
match
---
name: exception [52217,52226]
name: exception [52217,52226]
===
match
---
name: task_id [47427,47434]
name: task_id [47427,47434]
===
match
---
operator: = [45717,45718]
operator: = [45717,45718]
===
match
---
trailer [18126,18133]
trailer [18126,18133]
===
match
---
name: incr [42813,42817]
name: incr [42813,42817]
===
match
---
name: execution_date [78889,78903]
name: execution_date [79023,79037]
===
match
---
name: _run_mini_scheduler_on_child_tasks [45669,45703]
name: _run_mini_scheduler_on_child_tasks [45669,45703]
===
match
---
name: get_template_env [71576,71592]
name: get_template_env [71710,71726]
===
match
---
name: add [45440,45443]
name: add [45440,45443]
===
match
---
name: all [78416,78419]
name: all [78550,78553]
===
match
---
fstring_string: &task_id= [19376,19385]
fstring_string: &task_id= [19376,19385]
===
match
---
trailer [42611,42637]
trailer [42611,42637]
===
match
---
decorator [19853,19870]
decorator [19853,19870]
===
match
---
operator: , [41378,41379]
operator: , [41378,41379]
===
match
---
not_test [58787,58800]
not_test [58921,58934]
===
match
---
name: email_for_state [58499,58514]
name: email_for_state [58633,58648]
===
match
---
name: fd [4677,4679]
name: fd [4677,4679]
===
match
---
suite [7517,7953]
suite [7517,7953]
===
match
---
atom_expr [78121,78133]
atom_expr [78255,78267]
===
match
---
atom_expr [63003,63011]
atom_expr [63137,63145]
===
match
---
name: task [11798,11802]
name: task [11798,11802]
===
match
---
name: log [31696,31699]
name: log [31696,31699]
===
match
---
name: self [57679,57683]
name: self [57813,57817]
===
match
---
name: dr [7859,7861]
name: dr [7859,7861]
===
match
---
name: TaskInstance [79165,79177]
name: TaskInstance [79299,79311]
===
match
---
param [14329,14339]
param [14329,14339]
===
match
---
trailer [56800,56805]
trailer [56934,56939]
===
match
---
trailer [50724,50765]
trailer [50724,50765]
===
match
---
name: TaskInstance [79063,79075]
name: TaskInstance [79197,79209]
===
match
---
name: or_ [6613,6616]
name: or_ [6613,6616]
===
match
---
atom_expr [52738,52771]
atom_expr [52738,52771]
===
match
---
name: sqlalchemy [82355,82365]
name: sqlalchemy [82489,82499]
===
match
---
operator: = [17928,17929]
operator: = [17928,17929]
===
match
---
trailer [78094,78099]
trailer [78228,78233]
===
match
---
name: reason [32056,32062]
name: reason [32056,32062]
===
match
---
name: Integer [10151,10158]
name: Integer [10151,10158]
===
match
---
name: context [48773,48780]
name: context [48773,48780]
===
match
---
operator: , [32286,32287]
operator: , [32286,32287]
===
match
---
simple_stmt [6600,7189]
simple_stmt [6600,7189]
===
match
---
simple_stmt [45374,45394]
simple_stmt [45374,45394]
===
match
---
name: self [71493,71497]
name: self [71627,71631]
===
match
---
name: self [54950,54954]
name: self [54950,54954]
===
match
---
name: reschedule_exception [55560,55580]
name: reschedule_exception [55560,55580]
===
match
---
atom_expr [21975,21990]
atom_expr [21975,21990]
===
match
---
atom_expr [14687,14704]
atom_expr [14687,14704]
===
match
---
name: property [13884,13892]
name: property [13884,13892]
===
match
---
name: value [77056,77061]
name: value [77190,77195]
===
match
---
expr_stmt [77681,77695]
expr_stmt [77815,77829]
===
match
---
return_stmt [40412,40424]
return_stmt [40412,40424]
===
match
---
name: task [23498,23502]
name: task [23498,23502]
===
match
---
trailer [3274,3284]
trailer [3274,3284]
===
match
---
name: error_file [44263,44273]
name: error_file [44263,44273]
===
match
---
trailer [18821,18847]
trailer [18821,18847]
===
match
---
atom_expr [79916,79934]
atom_expr [80050,80068]
===
match
---
simple_stmt [24796,24846]
simple_stmt [24796,24846]
===
match
---
simple_stmt [2672,2722]
simple_stmt [2672,2722]
===
match
---
param [14112,14134]
param [14112,14134]
===
match
---
simple_stmt [34801,34920]
simple_stmt [34801,34920]
===
match
---
atom_expr [22612,22622]
atom_expr [22612,22622]
===
match
---
trailer [23913,23920]
trailer [23913,23920]
===
match
---
name: self [81288,81292]
name: self [81422,81426]
===
match
---
param [51071,51080]
param [51071,51080]
===
match
---
name: hostname [42726,42734]
name: hostname [42726,42734]
===
match
---
atom [49248,49301]
atom [49248,49301]
===
match
---
trailer [58261,58268]
trailer [58395,58402]
===
match
---
atom_expr [9549,9581]
atom_expr [9549,9581]
===
match
---
name: task_id_by_key [5065,5079]
name: task_id_by_key [5065,5079]
===
match
---
atom_expr [10842,10868]
atom_expr [10842,10868]
===
match
---
operator: , [35783,35784]
operator: , [35783,35784]
===
match
---
string: """         Get the very latest state from the database, if a session is passed,         we use and looking up the state becomes part of the session, otherwise         a new session is used.          :param session: SQLAlchemy ORM Session         :type session: Session         """ [19928,20209]
string: """         Get the very latest state from the database, if a session is passed,         we use and looking up the state becomes part of the session, otherwise         a new session is used.          :param session: SQLAlchemy ORM Session         :type session: Session         """ [19928,20209]
===
match
---
trailer [22291,22302]
trailer [22291,22302]
===
match
---
name: filepath [14760,14768]
name: filepath [14760,14768]
===
match
---
atom_expr [80415,80427]
atom_expr [80549,80561]
===
match
---
atom_expr [5462,5488]
atom_expr [5462,5488]
===
match
---
trailer [33905,33914]
trailer [33905,33914]
===
match
---
operator: ** [71071,71073]
operator: ** [71205,71207]
===
match
---
name: tis [7513,7516]
name: tis [7513,7516]
===
match
---
trailer [81819,81833]
trailer [81953,81967]
===
match
---
try_stmt [49728,50084]
try_stmt [49728,50084]
===
match
---
name: dag_id [21632,21638]
name: dag_id [21632,21638]
===
match
---
atom_expr [24814,24829]
atom_expr [24814,24829]
===
match
---
simple_stmt [2825,2867]
simple_stmt [2825,2867]
===
match
---
string: "Webserver does not have access to User-defined Macros or Filters " [66603,66670]
string: "Webserver does not have access to User-defined Macros or Filters " [66737,66804]
===
match
---
atom_expr [40704,40717]
atom_expr [40704,40717]
===
match
---
name: self [41175,41179]
name: self [41175,41179]
===
match
---
name: kubernetes [2882,2892]
name: kubernetes [2882,2892]
===
match
---
suite [67217,67469]
suite [67351,67603]
===
match
---
trailer [41126,41131]
trailer [41126,41131]
===
match
---
operator: , [4729,4730]
operator: , [4729,4730]
===
match
---
simple_stmt [62159,62218]
simple_stmt [62293,62352]
===
match
---
fstring_start: f" [62172,62174]
fstring_start: f" [62306,62308]
===
match
---
param [68975,68984]
param [69109,69118]
===
match
---
trailer [61291,61306]
trailer [61425,61440]
===
match
---
operator: , [44651,44652]
operator: , [44651,44652]
===
match
---
operator: = [70658,70659]
operator: = [70792,70793]
===
match
---
trailer [60406,60408]
trailer [60540,60542]
===
match
---
string: "&upstream=false" [19788,19805]
string: "&upstream=false" [19788,19805]
===
match
---
atom_expr [22669,22687]
atom_expr [22669,22687]
===
match
---
atom_expr [8159,8184]
atom_expr [8159,8184]
===
match
---
operator: @ [81084,81085]
operator: @ [81218,81219]
===
match
---
name: with_for_update [82067,82082]
name: with_for_update [82201,82216]
===
match
---
name: self [45374,45378]
name: self [45374,45378]
===
match
---
name: log [48341,48344]
name: log [48341,48344]
===
match
---
atom_expr [7076,7089]
atom_expr [7076,7089]
===
match
---
name: dagrun [82460,82466]
name: dagrun [82594,82600]
===
match
---
atom_expr [65801,65819]
atom_expr [65935,65953]
===
match
---
trailer [73965,74183]
trailer [74099,74317]
===
match
---
name: refresh_from_db [21019,21034]
name: refresh_from_db [21019,21034]
===
match
---
name: self [22646,22650]
name: self [22646,22650]
===
match
---
name: debug [24707,24712]
name: debug [24707,24712]
===
match
---
name: start_date [72712,72722]
name: start_date [72846,72856]
===
match
---
atom_expr [20354,20374]
atom_expr [20354,20374]
===
match
---
argument [54448,54461]
argument [54448,54461]
===
match
---
atom_expr [23571,23584]
atom_expr [23571,23584]
===
match
---
dotted_name [1929,1952]
dotted_name [1929,1952]
===
match
---
name: e [44793,44794]
name: e [44793,44794]
===
match
---
arglist [53838,54201]
arglist [53838,54201]
===
match
---
atom_expr [13977,13993]
atom_expr [13977,13993]
===
match
---
name: self [70334,70338]
name: self [70468,70472]
===
match
---
name: pod_id [68299,68305]
name: pod_id [68433,68439]
===
match
---
name: self [20439,20443]
name: self [20439,20443]
===
match
---
atom_expr [42646,42683]
atom_expr [42646,42683]
===
match
---
trailer [58523,58529]
trailer [58657,58663]
===
match
---
parameters [51856,51886]
parameters [51856,51886]
===
match
---
name: try_number [71447,71457]
name: try_number [71581,71591]
===
match
---
trailer [25345,25358]
trailer [25345,25358]
===
match
---
param [19462,19466]
param [19462,19466]
===
match
---
simple_stmt [19225,19270]
simple_stmt [19225,19270]
===
match
---
string: 'Try {{try_number}} out of {{max_tries + 1}}<br>' [69926,69975]
string: 'Try {{try_number}} out of {{max_tries + 1}}<br>' [70060,70109]
===
match
---
operator: = [74343,74344]
operator: = [74477,74478]
===
match
---
suite [62468,63354]
suite [62602,63488]
===
match
---
name: context [52639,52646]
name: context [52639,52646]
===
match
---
name: self [41230,41234]
name: self [41230,41234]
===
match
---
trailer [47402,47411]
trailer [47402,47411]
===
match
---
simple_stmt [62992,63013]
simple_stmt [63126,63147]
===
match
---
expr_stmt [61909,61966]
expr_stmt [62043,62100]
===
match
---
suite [57731,57817]
suite [57865,57951]
===
match
---
arglist [48520,48550]
arglist [48520,48550]
===
match
---
trailer [52216,52226]
trailer [52216,52226]
===
match
---
if_stmt [18323,18394]
if_stmt [18323,18394]
===
match
---
operator: = [12003,12004]
operator: = [12003,12004]
===
match
---
operator: , [65834,65835]
operator: , [65968,65969]
===
match
---
name: yesterday_ds_nodash [65913,65932]
name: yesterday_ds_nodash [66047,66066]
===
match
---
name: session [28039,28046]
name: session [28039,28046]
===
match
---
operator: = [29602,29603]
operator: = [29602,29603]
===
match
---
simple_stmt [52639,52677]
simple_stmt [52639,52677]
===
match
---
trailer [52153,52195]
trailer [52153,52195]
===
match
---
parameters [66965,66971]
parameters [67099,67105]
===
match
---
trailer [60648,60657]
trailer [60782,60791]
===
match
---
name: date [41441,41445]
name: date [41441,41445]
===
match
---
name: kubernetes [3081,3091]
name: kubernetes [3081,3091]
===
match
---
name: error [53220,53225]
name: error [53220,53225]
===
match
---
simple_stmt [43445,43488]
simple_stmt [43445,43488]
===
match
---
trailer [51990,52010]
trailer [51990,52010]
===
match
---
string: """Executes Task (optionally with a Timeout) and pushes Xcom results""" [51091,51162]
string: """Executes Task (optionally with a Timeout) and pushes Xcom results""" [51091,51162]
===
match
---
argument [51433,51448]
argument [51433,51448]
===
match
---
name: _log [11329,11333]
name: _log [11329,11333]
===
match
---
trailer [55669,55687]
trailer [55669,55687]
===
match
---
operator: ** [71880,71882]
operator: ** [72014,72016]
===
match
---
name: session [77339,77346]
name: session [77473,77480]
===
match
---
param [48023,48028]
param [48023,48028]
===
match
---
name: state [12126,12131]
name: state [12126,12131]
===
match
---
trailer [77352,77366]
trailer [77486,77500]
===
match
---
name: self [61109,61113]
name: self [61243,61247]
===
match
---
suite [18729,18778]
suite [18729,18778]
===
match
---
and_test [59340,59395]
and_test [59474,59529]
===
match
---
name: dep_context [31803,31814]
name: dep_context [31803,31814]
===
match
---
funcdef [19441,19848]
funcdef [19441,19848]
===
match
---
trailer [74070,74077]
trailer [74204,74211]
===
match
---
fstring_end: " [67459,67460]
fstring_end: " [67593,67594]
===
match
---
operator: , [70626,70627]
operator: , [70760,70761]
===
match
---
name: task_id [58287,58294]
name: task_id [58421,58428]
===
match
---
name: error [58941,58946]
name: error [59075,59080]
===
match
---
try_stmt [3576,3897]
try_stmt [3576,3897]
===
match
---
name: self [57969,57973]
name: self [58103,58107]
===
match
---
trailer [50531,50536]
trailer [50531,50536]
===
match
---
name: Optional [80134,80142]
name: Optional [80268,80276]
===
match
---
name: execution_date [6765,6779]
name: execution_date [6765,6779]
===
match
---
name: utils [2800,2805]
name: utils [2800,2805]
===
match
---
name: state [29071,29076]
name: state [29071,29076]
===
match
---
try_stmt [72388,72549]
try_stmt [72522,72683]
===
match
---
name: airflow [7317,7324]
name: airflow [7317,7324]
===
match
---
operator: = [68370,68371]
operator: = [68504,68505]
===
match
---
operator: , [56106,56107]
operator: , [56106,56107]
===
match
---
simple_stmt [5417,5446]
simple_stmt [5417,5446]
===
match
---
funcdef [32988,34761]
funcdef [32988,34761]
===
match
---
simple_stmt [47513,47595]
simple_stmt [47513,47595]
===
match
---
atom_expr [62934,62942]
atom_expr [63068,63076]
===
match
---
string: 'var' [65719,65724]
string: 'var' [65853,65858]
===
match
---
trailer [79872,79878]
trailer [80006,80012]
===
match
---
name: state [29603,29608]
name: state [29603,29608]
===
match
---
atom_expr [47785,47937]
atom_expr [47785,47937]
===
match
---
name: max_tries [70715,70724]
name: max_tries [70849,70858]
===
match
---
name: test_mode [41648,41657]
name: test_mode [41648,41657]
===
match
---
name: self [44981,44985]
name: self [44981,44985]
===
match
---
name: path [19017,19021]
name: path [19017,19021]
===
match
---
trailer [21979,21990]
trailer [21979,21990]
===
match
---
expr_stmt [12439,12461]
expr_stmt [12439,12461]
===
match
---
param [15635,15662]
param [15635,15662]
===
match
---
operator: = [17969,17970]
operator: = [17969,17970]
===
match
---
name: ti [22625,22627]
name: ti [22625,22627]
===
match
---
name: result [50502,50508]
name: result [50502,50508]
===
match
---
string: "--raw" [18698,18705]
string: "--raw" [18698,18705]
===
match
---
param [14289,14299]
param [14289,14299]
===
match
---
expr_stmt [22700,22727]
expr_stmt [22700,22727]
===
match
---
atom_expr [26208,26235]
atom_expr [26208,26235]
===
match
---
operator: = [56323,56324]
operator: = [56323,56324]
===
match
---
string: "airflow" [17972,17981]
string: "airflow" [17972,17981]
===
match
---
atom_expr [81927,81940]
atom_expr [82061,82074]
===
match
---
name: session [37542,37549]
name: session [37542,37549]
===
match
---
atom_expr [18686,18707]
atom_expr [18686,18707]
===
match
---
operator: , [16037,16038]
operator: , [16037,16038]
===
match
---
name: prev_execution_date [61155,61174]
name: prev_execution_date [61289,61308]
===
match
---
trailer [56692,56694]
trailer [56826,56828]
===
match
---
trailer [70849,70876]
trailer [70983,71010]
===
match
---
suite [66419,66935]
suite [66553,67069]
===
match
---
name: Optional [53676,53684]
name: Optional [53676,53684]
===
match
---
name: are_dependents_done [25420,25439]
name: are_dependents_done [25420,25439]
===
match
---
tfpdef [11101,11125]
tfpdef [11101,11125]
===
match
---
atom_expr [44028,44103]
atom_expr [44028,44103]
===
match
---
operator: = [12454,12455]
operator: = [12454,12455]
===
match
---
atom_expr [4665,4675]
atom_expr [4665,4675]
===
match
---
comparison [21717,21767]
comparison [21717,21767]
===
match
---
expr_stmt [46536,46788]
expr_stmt [46536,46788]
===
match
---
atom_expr [50230,50265]
atom_expr [50230,50265]
===
match
---
argument [71431,71461]
argument [71565,71595]
===
match
---
name: TaskInstance [78644,78656]
name: TaskInstance [78778,78790]
===
match
---
operator: , [19598,19599]
operator: , [19598,19599]
===
match
---
param [81364,81369]
param [81498,81503]
===
match
---
atom [66496,66536]
atom [66630,66670]
===
match
---
arglist [63831,63858]
arglist [63965,63992]
===
match
---
name: ignore_all_deps [53399,53414]
name: ignore_all_deps [53399,53414]
===
match
---
name: dag_id [68325,68331]
name: dag_id [68459,68465]
===
match
---
trailer [24773,24779]
trailer [24773,24779]
===
match
---
trailer [15989,15994]
trailer [15989,15994]
===
match
---
comparison [39001,39038]
comparison [39001,39038]
===
match
---
name: session [30916,30923]
name: session [30916,30923]
===
match
---
simple_stmt [22059,22087]
simple_stmt [22059,22087]
===
match
---
name: session [58814,58821]
name: session [58948,58955]
===
match
---
name: AirflowSmartSensorException [43146,43173]
name: AirflowSmartSensorException [43146,43173]
===
match
---
expr_stmt [38950,38985]
expr_stmt [38950,38985]
===
match
---
atom_expr [55339,55621]
atom_expr [55339,55621]
===
match
---
name: bytes [3926,3931]
name: bytes [3926,3931]
===
match
---
except_clause [44131,44163]
except_clause [44131,44163]
===
match
---
simple_stmt [53774,54212]
simple_stmt [53774,54212]
===
match
---
operator: } [7722,7723]
operator: } [7722,7723]
===
match
---
name: error_file [44818,44828]
name: error_file [44818,44828]
===
match
---
atom_expr [78512,78707]
atom_expr [78646,78841]
===
match
---
simple_stmt [47954,47973]
simple_stmt [47954,47973]
===
match
---
trailer [60442,60451]
trailer [60576,60585]
===
match
---
name: failed [32090,32096]
name: failed [32090,32096]
===
match
---
trailer [70975,70992]
trailer [71109,71126]
===
match
---
name: self [74283,74287]
name: self [74417,74421]
===
match
---
name: isoformat [17945,17954]
name: isoformat [17945,17954]
===
match
---
funcdef [25106,25390]
funcdef [25106,25390]
===
match
---
name: state [20530,20535]
name: state [20530,20535]
===
match
---
atom_expr [53640,53653]
atom_expr [53640,53653]
===
match
---
atom_expr [50809,50824]
atom_expr [50809,50824]
===
match
---
trailer [60568,60577]
trailer [60702,60711]
===
match
---
atom_expr [56162,56175]
atom_expr [56162,56175]
===
match
---
name: State [7893,7898]
name: State [7893,7898]
===
match
---
operator: , [76309,76310]
operator: , [76443,76444]
===
match
---
operator: } [48716,48717]
operator: } [48716,48717]
===
match
---
operator: = [76718,76719]
operator: = [76852,76853]
===
match
---
trailer [13865,13877]
trailer [13865,13877]
===
match
---
simple_stmt [1162,1176]
simple_stmt [1162,1176]
===
match
---
expr_stmt [49753,49817]
expr_stmt [49753,49817]
===
match
---
expr_stmt [22531,22550]
expr_stmt [22531,22550]
===
match
---
suite [63664,63697]
suite [63798,63831]
===
match
---
name: property [80362,80370]
name: property [80496,80504]
===
match
---
trailer [31766,31790]
trailer [31766,31790]
===
match
---
atom_expr [52527,52539]
atom_expr [52527,52539]
===
match
---
name: AirflowException [67386,67402]
name: AirflowException [67520,67536]
===
match
---
not_test [39752,39837]
not_test [39752,39837]
===
match
---
name: log [52213,52216]
name: log [52213,52216]
===
match
---
tfpdef [15671,15692]
tfpdef [15671,15692]
===
match
---
operator: = [10142,10143]
operator: = [10142,10143]
===
match
---
decorator [28558,28568]
decorator [28558,28568]
===
match
---
trailer [50374,50388]
trailer [50374,50388]
===
match
---
atom_expr [35398,35409]
atom_expr [35398,35409]
===
match
---
operator: , [21703,21704]
operator: , [21703,21704]
===
match
---
argument [51790,51802]
argument [51790,51802]
===
match
---
trailer [53648,53653]
trailer [53648,53653]
===
match
---
argument [27275,27289]
argument [27275,27289]
===
match
---
expr_stmt [9887,9918]
expr_stmt [9887,9918]
===
match
---
param [29159,29164]
param [29159,29164]
===
match
---
arglist [6652,7108]
arglist [6652,7108]
===
match
---
simple_stmt [37478,37505]
simple_stmt [37478,37505]
===
match
---
trailer [19545,19555]
trailer [19545,19555]
===
match
---
operator: = [67859,67860]
operator: = [67993,67994]
===
match
---
name: dag_id [21647,21653]
name: dag_id [21647,21653]
===
match
---
name: defaultdict [5122,5133]
name: defaultdict [5122,5133]
===
match
---
name: REQUEUEABLE_DEPS [39493,39509]
name: REQUEUEABLE_DEPS [39493,39509]
===
match
---
argument [28491,28503]
argument [28491,28503]
===
match
---
operator: = [20921,20922]
operator: = [20921,20922]
===
match
---
return_stmt [68913,68933]
return_stmt [69047,69067]
===
match
---
simple_stmt [68913,68934]
simple_stmt [69047,69068]
===
match
---
atom_expr [46092,46103]
atom_expr [46092,46103]
===
match
---
name: context [42922,42929]
name: context [42922,42929]
===
match
---
name: staticmethod [63976,63988]
name: staticmethod [64110,64122]
===
match
---
trailer [27884,27904]
trailer [27884,27904]
===
match
---
if_stmt [6131,7287]
if_stmt [6131,7287]
===
match
---
name: query [26036,26041]
name: query [26036,26041]
===
match
---
atom_expr [39015,39038]
atom_expr [39015,39038]
===
match
---
arglist [10848,10867]
arglist [10848,10867]
===
match
---
name: self [58372,58376]
name: self [58506,58510]
===
match
---
fstring_expr [19090,19099]
fstring_expr [19090,19099]
===
match
---
operator: = [51772,51773]
operator: = [51772,51773]
===
match
---
operator: -> [29241,29243]
operator: -> [29241,29243]
===
match
---
atom_expr [52649,52676]
atom_expr [52649,52676]
===
match
---
name: ti [5952,5954]
name: ti [5952,5954]
===
match
---
fstring [42818,42858]
fstring [42818,42858]
===
match
---
name: ti_hash [33694,33701]
name: ti_hash [33694,33701]
===
match
---
operator: , [4302,4303]
operator: , [4302,4303]
===
match
---
trailer [8525,8540]
trailer [8525,8540]
===
match
---
name: _try_number [79810,79821]
name: _try_number [79944,79955]
===
match
---
trailer [11343,11353]
trailer [11343,11353]
===
match
---
parameters [11088,11155]
parameters [11088,11155]
===
match
---
operator: = [4055,4056]
operator: = [4055,4056]
===
match
---
name: self [19892,19896]
name: self [19892,19896]
===
match
---
trailer [34954,34967]
trailer [34954,34967]
===
match
---
argument [44263,44284]
argument [44263,44284]
===
match
---
atom_expr [24769,24779]
atom_expr [24769,24779]
===
match
---
atom_expr [68411,68433]
atom_expr [68545,68567]
===
match
---
funcdef [29118,29696]
funcdef [29118,29696]
===
match
---
param [15671,15701]
param [15671,15701]
===
match
---
name: self [39855,39859]
name: self [39855,39859]
===
match
---
arglist [44232,44284]
arglist [44232,44284]
===
match
---
comparison [77510,77545]
comparison [77644,77679]
===
match
---
simple_stmt [49331,49371]
simple_stmt [49331,49371]
===
match
---
expr_stmt [54277,54319]
expr_stmt [54277,54319]
===
match
---
simple_stmt [993,1033]
simple_stmt [993,1033]
===
match
---
string: 'Exception:<br>{{exception_html}}<br>' [69607,69645]
string: 'Exception:<br>{{exception_html}}<br>' [69741,69779]
===
match
---
suite [55129,55968]
suite [55129,55968]
===
match
---
atom_expr [77115,77143]
atom_expr [77249,77277]
===
match
---
name: job_id [54455,54461]
name: job_id [54455,54461]
===
match
---
operator: = [64344,64345]
operator: = [64478,64479]
===
match
---
atom_expr [29180,29193]
atom_expr [29180,29193]
===
match
---
name: params [59991,59997]
name: params [60125,60131]
===
match
---
atom_expr [21825,21854]
atom_expr [21825,21854]
===
match
---
operator: + [13228,13229]
operator: + [13228,13229]
===
match
---
name: provide_session [30847,30862]
name: provide_session [30847,30862]
===
match
---
name: RenderedTaskInstanceFields [48900,48926]
name: RenderedTaskInstanceFields [48900,48926]
===
match
---
name: hostname [9887,9895]
name: hostname [9887,9895]
===
match
---
comparison [23974,24002]
comparison [23974,24002]
===
match
---
trailer [39104,39127]
trailer [39104,39127]
===
match
---
funcdef [13260,13322]
funcdef [13260,13322]
===
match
---
name: _task_id [80493,80501]
name: _task_id [80627,80635]
===
match
---
trailer [43200,43205]
trailer [43200,43205]
===
match
---
operator: , [74045,74046]
operator: , [74179,74180]
===
match
---
trailer [48526,48534]
trailer [48526,48534]
===
match
---
name: NONE [6006,6010]
name: NONE [6006,6010]
===
match
---
name: DagRun [60155,60161]
name: DagRun [60289,60295]
===
match
---
operator: } [62202,62203]
operator: } [62336,62337]
===
match
---
if_stmt [33251,34724]
if_stmt [33251,34724]
===
match
---
trailer [58683,58689]
trailer [58817,58823]
===
match
---
expr_stmt [11226,11253]
expr_stmt [11226,11253]
===
match
---
atom_expr [41164,41173]
atom_expr [41164,41173]
===
match
---
operator: , [35064,35065]
operator: , [35064,35065]
===
match
---
trailer [7418,7427]
trailer [7418,7427]
===
match
---
atom_expr [60310,60324]
atom_expr [60444,60458]
===
match
---
funcdef [47978,50623]
funcdef [47978,50623]
===
match
---
testlist_comp [76912,76956]
testlist_comp [77046,77090]
===
match
---
param [35901,35930]
param [35901,35930]
===
match
---
trailer [79947,79960]
trailer [80081,80094]
===
match
---
trailer [46609,46629]
trailer [46609,46629]
===
match
---
operator: , [16001,16002]
operator: , [16001,16002]
===
match
---
atom_expr [68719,68785]
atom_expr [68853,68919]
===
match
---
name: Optional [79962,79970]
name: Optional [80096,80104]
===
match
---
name: task_ids [74297,74305]
name: task_ids [74431,74439]
===
match
---
operator: , [79147,79148]
operator: , [79281,79282]
===
match
---
simple_stmt [81130,81149]
simple_stmt [81264,81283]
===
match
---
trailer [56665,56674]
trailer [56799,56808]
===
match
---
operator: == [21688,21690]
operator: == [21688,21690]
===
match
---
name: models [66063,66069]
name: models [66197,66203]
===
match
---
atom_expr [30791,30840]
atom_expr [30791,30840]
===
match
---
name: Optional [41767,41775]
name: Optional [41767,41775]
===
match
---
trailer [49158,49163]
trailer [49158,49163]
===
match
---
expr_stmt [27625,27693]
expr_stmt [27625,27693]
===
match
---
string: """Get Airflow Variable after deserializing JSON value""" [64203,64260]
string: """Get Airflow Variable after deserializing JSON value""" [64337,64394]
===
match
---
atom_expr [54724,54764]
atom_expr [54724,54764]
===
match
---
for_stmt [5145,6126]
for_stmt [5145,6126]
===
match
---
name: self [39001,39005]
name: self [39001,39005]
===
match
---
param [29794,29817]
param [29794,29817]
===
match
---
name: dag_id [10603,10609]
name: dag_id [10603,10609]
===
match
---
operator: , [56961,56962]
operator: , [57095,57096]
===
match
---
decorated [80766,80841]
decorated [80900,80975]
===
match
---
name: job_id [42706,42712]
name: job_id [42706,42712]
===
match
---
simple_stmt [38950,38986]
simple_stmt [38950,38986]
===
match
---
return_stmt [13854,13877]
return_stmt [13854,13877]
===
match
---
dotted_name [2385,2398]
dotted_name [2385,2398]
===
match
---
name: verbose_aware_logger [32132,32152]
name: verbose_aware_logger [32132,32152]
===
match
---
param [63765,63775]
param [63899,63909]
===
match
---
name: rendered_task_instance_fields [66304,66333]
name: rendered_task_instance_fields [66438,66467]
===
match
---
comparison [14687,14720]
comparison [14687,14720]
===
match
---
name: execution_date [79178,79192]
name: execution_date [79312,79326]
===
match
---
atom_expr [77704,77727]
atom_expr [77838,77861]
===
match
---
atom_expr [68371,68386]
atom_expr [68505,68520]
===
match
---
trailer [11806,11815]
trailer [11806,11815]
===
match
---
name: self [45023,45027]
name: self [45023,45027]
===
match
---
operator: , [31990,31991]
operator: , [31990,31991]
===
match
---
name: e [67361,67362]
name: e [67495,67496]
===
match
---
name: Integer [1320,1327]
name: Integer [1320,1327]
===
match
---
name: log [1909,1912]
name: log [1909,1912]
===
match
---
atom_expr [43500,43510]
atom_expr [43500,43510]
===
match
---
operator: @ [80507,80508]
operator: @ [80641,80642]
===
match
---
name: kube_image [68400,68410]
name: kube_image [68534,68544]
===
match
---
operator: = [30937,30938]
operator: = [30937,30938]
===
match
---
name: task_id [76924,76931]
name: task_id [77058,77065]
===
match
---
comparison [26378,26416]
comparison [26378,26416]
===
match
---
name: task_id [21696,21703]
name: task_id [21696,21703]
===
match
---
atom_expr [56677,56694]
atom_expr [56811,56828]
===
match
---
name: previous_ti_success [28576,28595]
name: previous_ti_success [28576,28595]
===
match
---
name: warnings [907,915]
name: warnings [907,915]
===
match
---
operator: , [53589,53590]
operator: , [53589,53590]
===
match
---
name: int [80804,80807]
name: int [80938,80941]
===
match
---
operator: = [37463,37464]
operator: = [37463,37464]
===
match
---
name: raw [15367,15370]
name: raw [15367,15370]
===
match
---
name: max_tries [22393,22402]
name: max_tries [22393,22402]
===
match
---
arglist [28017,28046]
arglist [28017,28046]
===
match
---
trailer [22671,22687]
trailer [22671,22687]
===
match
---
simple_stmt [61469,61511]
simple_stmt [61603,61645]
===
match
---
name: State [24903,24908]
name: State [24903,24908]
===
match
---
arglist [4447,4456]
arglist [4447,4456]
===
match
---
operator: , [1081,1082]
operator: , [1081,1082]
===
match
---
trailer [73901,73916]
trailer [74035,74050]
===
match
---
name: end_date [9701,9709]
name: end_date [9701,9709]
===
match
---
param [15579,15592]
param [15579,15592]
===
match
---
name: Float [9754,9759]
name: Float [9754,9759]
===
match
---
name: self [19115,19119]
name: self [19115,19119]
===
match
---
name: local [15287,15292]
name: local [15287,15292]
===
match
---
name: info [47794,47798]
name: info [47794,47798]
===
match
---
simple_stmt [78505,78708]
simple_stmt [78639,78842]
===
match
---
atom_expr [9542,9600]
atom_expr [9542,9600]
===
match
---
name: get_hostname [2592,2604]
name: get_hostname [2592,2604]
===
match
---
operator: , [29163,29164]
operator: , [29163,29164]
===
match
---
trailer [41775,41780]
trailer [41775,41780]
===
match
---
name: ti [20218,20220]
name: ti [20218,20220]
===
match
---
name: Optional [67841,67849]
name: Optional [67975,67983]
===
match
---
import_as_names [1052,1117]
import_as_names [1052,1117]
===
match
---
operator: { [19769,19770]
operator: { [19769,19770]
===
match
---
atom_expr [79041,79228]
atom_expr [79175,79362]
===
match
---
argument [70597,70626]
argument [70731,70760]
===
match
---
suite [61020,61129]
suite [61154,61263]
===
match
---
name: pid [22800,22803]
name: pid [22800,22803]
===
match
---
fstring_end: " [49258,49259]
fstring_end: " [49258,49259]
===
match
---
name: current_time [24833,24845]
name: current_time [24833,24845]
===
match
---
trailer [80667,80679]
trailer [80801,80813]
===
match
---
name: task_id [11246,11253]
name: task_id [11246,11253]
===
match
---
name: net [2581,2584]
name: net [2581,2584]
===
match
---
argument [11049,11063]
argument [11049,11063]
===
match
---
trailer [23406,23428]
trailer [23406,23428]
===
match
---
operator: = [56199,56200]
operator: = [56199,56200]
===
match
---
atom_expr [79962,79975]
atom_expr [80096,80109]
===
match
---
expr_stmt [37478,37504]
expr_stmt [37478,37504]
===
match
---
suite [36003,41318]
suite [36003,41318]
===
match
---
expr_stmt [26023,26337]
expr_stmt [26023,26337]
===
match
---
suite [72392,72456]
suite [72526,72590]
===
match
---
number: 1 [13996,13997]
number: 1 [13996,13997]
===
match
---
arglist [10687,10704]
arglist [10687,10704]
===
match
---
name: activate_dag_runs [4735,4752]
name: activate_dag_runs [4735,4752]
===
match
---
simple_stmt [42976,43037]
simple_stmt [42976,43037]
===
match
---
trailer [63887,63891]
trailer [64021,64025]
===
match
---
trailer [15924,15929]
trailer [15924,15929]
===
match
---
operator: = [9594,9595]
operator: = [9594,9595]
===
match
---
import_from [82440,82480]
import_from [82574,82614]
===
match
---
param [21055,21076]
param [21055,21076]
===
match
---
name: ignore_ti_state [15236,15251]
name: ignore_ti_state [15236,15251]
===
match
---
name: self [11793,11797]
name: self [11793,11797]
===
match
---
trailer [74375,74380]
trailer [74509,74514]
===
match
---
tfpdef [35668,35689]
tfpdef [35668,35689]
===
match
---
name: refresh_from_task [22916,22933]
name: refresh_from_task [22916,22933]
===
match
---
trailer [49341,49348]
trailer [49341,49348]
===
match
---
testlist_comp [26296,26324]
testlist_comp [26296,26324]
===
match
---
name: self [77681,77685]
name: self [77815,77819]
===
match
---
name: self [54624,54628]
name: self [54624,54628]
===
match
---
atom_expr [62881,62889]
atom_expr [63015,63023]
===
match
---
name: dag_run [67786,67793]
name: dag_run [67920,67927]
===
match
---
name: task_copy [51582,51591]
name: task_copy [51582,51591]
===
match
---
name: self [73720,73724]
name: self [73854,73858]
===
match
---
name: schedulable_ti [47318,47332]
name: schedulable_ti [47318,47332]
===
match
---
arglist [61892,61899]
arglist [62026,62033]
===
match
---
not_test [56832,56845]
not_test [56966,56979]
===
match
---
name: tomorrow_ds [62121,62132]
name: tomorrow_ds [62255,62266]
===
match
---
expr_stmt [5919,5976]
expr_stmt [5919,5976]
===
match
---
atom_expr [77775,77823]
atom_expr [77909,77957]
===
match
---
name: Column [9747,9753]
name: Column [9747,9753]
===
match
---
name: task_copy [54931,54940]
name: task_copy [54931,54940]
===
match
---
simple_stmt [59530,59558]
simple_stmt [59664,59692]
===
match
---
simple_stmt [61799,61860]
simple_stmt [61933,61994]
===
match
---
trailer [26390,26416]
trailer [26390,26416]
===
match
---
param [53670,53697]
param [53670,53697]
===
match
---
trailer [63002,63012]
trailer [63136,63146]
===
match
---
name: session [46028,46035]
name: session [46028,46035]
===
match
---
operator: , [64679,64680]
operator: , [64813,64814]
===
match
---
string: 'ts_nodash' [65631,65642]
string: 'ts_nodash' [65765,65776]
===
match
---
suite [11834,11904]
suite [11834,11904]
===
match
---
if_stmt [50101,50266]
if_stmt [50101,50266]
===
match
---
trailer [71070,71087]
trailer [71204,71221]
===
match
---
trailer [77522,77528]
trailer [77656,77662]
===
match
---
operator: = [29227,29228]
operator: = [29227,29228]
===
match
---
atom_expr [44177,44199]
atom_expr [44177,44199]
===
match
---
name: RenderedTaskInstanceFields [48827,48853]
name: RenderedTaskInstanceFields [48827,48853]
===
match
---
operator: { [47869,47870]
operator: { [47869,47870]
===
match
---
suite [80647,80680]
suite [80781,80814]
===
match
---
trailer [58856,58858]
trailer [58990,58992]
===
match
---
decorator [35024,35041]
decorator [35024,35041]
===
match
---
trailer [63830,63859]
trailer [63964,63993]
===
match
---
operator: , [15854,15855]
operator: , [15854,15855]
===
match
---
trailer [51514,51522]
trailer [51514,51522]
===
match
---
name: session [32502,32509]
name: session [32502,32509]
===
match
---
operator: , [65143,65144]
operator: , [65277,65278]
===
match
---
string: '' [12164,12166]
string: '' [12164,12166]
===
match
---
atom_expr [19520,19558]
atom_expr [19520,19558]
===
match
---
operator: , [60212,60213]
operator: , [60346,60347]
===
match
---
operator: -> [26537,26539]
operator: -> [26537,26539]
===
match
---
atom_expr [62364,62435]
atom_expr [62498,62569]
===
match
---
trailer [26879,26896]
trailer [26879,26896]
===
match
---
trailer [11802,11806]
trailer [11802,11806]
===
match
---
exprlist [66274,66300]
exprlist [66408,66434]
===
match
---
name: Optional [41725,41733]
name: Optional [41725,41733]
===
match
---
trailer [47021,47030]
trailer [47021,47030]
===
match
---
atom_expr [50462,50516]
atom_expr [50462,50516]
===
match
---
simple_stmt [55339,55622]
simple_stmt [55339,55622]
===
match
---
name: self [8291,8295]
name: self [8291,8295]
===
match
---
simple_stmt [82058,82093]
simple_stmt [82192,82227]
===
match
---
name: var [62886,62889]
name: var [63020,63023]
===
match
---
comparison [52585,52621]
comparison [52585,52621]
===
match
---
name: models [1982,1988]
name: models [1982,1988]
===
match
---
suite [61393,61584]
suite [61527,61718]
===
match
---
operator: , [69220,69221]
operator: , [69354,69355]
===
match
---
name: html_content [72159,72171]
name: html_content [72293,72305]
===
match
---
name: TaskInstance [78876,78888]
name: TaskInstance [79010,79022]
===
match
---
atom_expr [56085,56099]
atom_expr [56085,56099]
===
match
---
atom_expr [51265,51292]
atom_expr [51265,51292]
===
match
---
trailer [80001,80020]
trailer [80135,80154]
===
match
---
argument [46697,46719]
argument [46697,46719]
===
match
---
name: TaskInstanceKey [79370,79385]
name: TaskInstanceKey [79504,79519]
===
match
---
name: session [50853,50860]
name: session [50853,50860]
===
match
---
name: Optional [53640,53648]
name: Optional [53640,53648]
===
match
---
import_as_names [1298,1364]
import_as_names [1298,1364]
===
match
---
atom_expr [67841,67858]
atom_expr [67975,67992]
===
match
---
string: "task_instance" [9439,9454]
string: "task_instance" [9439,9454]
===
match
---
param [56192,56205]
param [56192,56205]
===
match
---
comparison [76161,76175]
comparison [76295,76309]
===
match
---
simple_stmt [54870,54911]
simple_stmt [54870,54911]
===
match
---
atom_expr [70492,70757]
atom_expr [70626,70891]
===
match
---
simple_stmt [78112,78134]
simple_stmt [78246,78268]
===
match
---
string: """         The execution date from property previous_ti_success.          :param state: If passed, it only take into account instances of a specific state.         :param session: SQLAlchemy ORM Session         """ [29281,29496]
string: """         The execution date from property previous_ti_success.          :param state: If passed, it only take into account instances of a specific state.         :param session: SQLAlchemy ORM Session         """ [29281,29496]
===
match
---
name: field_name [66378,66388]
name: field_name [66512,66522]
===
match
---
simple_stmt [5462,5489]
simple_stmt [5462,5489]
===
match
---
trailer [63182,63213]
trailer [63316,63347]
===
match
---
operator: , [76450,76451]
operator: , [76584,76585]
===
match
---
atom_expr [20910,20920]
atom_expr [20910,20920]
===
match
---
atom_expr [66453,66476]
atom_expr [66587,66610]
===
match
---
string: """         Based on this instance's try_number, this will calculate         the number of previously attempted tries, defaulting to 0.         """ [13381,13528]
string: """         Based on this instance's try_number, this will calculate         the number of previously attempted tries, defaulting to 0.         """ [13381,13528]
===
match
---
expr_stmt [5417,5445]
expr_stmt [5417,5445]
===
match
---
name: self [59362,59366]
name: self [59496,59500]
===
match
---
trailer [40317,40324]
trailer [40317,40324]
===
match
---
name: timezone [7935,7943]
name: timezone [7935,7943]
===
match
---
atom_expr [38968,38985]
atom_expr [38968,38985]
===
match
---
import_as_names [1436,1463]
import_as_names [1436,1463]
===
match
---
trailer [6064,6075]
trailer [6064,6075]
===
match
---
simple_stmt [5048,5061]
simple_stmt [5048,5061]
===
match
---
name: Session [29803,29810]
name: Session [29803,29810]
===
match
---
name: task_id [5334,5341]
name: task_id [5334,5341]
===
match
---
string: """Write error into error file by path""" [4329,4370]
string: """Write error into error file by path""" [4329,4370]
===
match
---
parameters [62799,62863]
parameters [62933,62997]
===
match
---
operator: = [20582,20583]
operator: = [20582,20583]
===
match
---
operator: + [19347,19348]
operator: + [19347,19348]
===
match
---
name: self [24039,24043]
name: self [24039,24043]
===
match
---
simple_stmt [61155,61225]
simple_stmt [61289,61359]
===
match
---
name: execution_date [79199,79213]
name: execution_date [79333,79347]
===
match
---
operator: @ [74189,74190]
operator: @ [74323,74324]
===
match
---
name: state [22115,22120]
name: state [22115,22120]
===
match
---
name: sql [1523,1526]
name: sql [1523,1526]
===
match
---
funcdef [14003,15467]
funcdef [14003,15467]
===
match
---
atom_expr [32702,32719]
atom_expr [32702,32719]
===
match
---
name: dag_id [78735,78741]
name: dag_id [78869,78875]
===
match
---
operator: { [42829,42830]
operator: { [42829,42830]
===
match
---
string: """         This attribute is deprecated.         Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.         """ [28639,28778]
string: """         This attribute is deprecated.         Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.         """ [28639,28778]
===
match
---
name: ti [20538,20540]
name: ti [20538,20540]
===
match
---
atom_expr [48794,48887]
atom_expr [48794,48887]
===
match
---
suite [27851,27935]
suite [27851,27935]
===
match
---
suite [79419,82154]
suite [79553,82288]
===
match
---
trailer [47381,47386]
trailer [47381,47386]
===
match
---
simple_stmt [61745,61787]
simple_stmt [61879,61921]
===
match
---
name: cmd [18522,18525]
name: cmd [18522,18525]
===
match
---
suite [62242,62282]
suite [62376,62416]
===
match
---
name: ti [7791,7793]
name: ti [7791,7793]
===
match
---
name: self [33612,33616]
name: self [33612,33616]
===
match
---
name: last_dagrun [27868,27879]
name: last_dagrun [27868,27879]
===
match
---
import_from [66050,66120]
import_from [66184,66254]
===
match
---
operator: , [1741,1742]
operator: , [1741,1742]
===
match
---
atom_expr [80746,80760]
atom_expr [80880,80894]
===
match
---
annassign [8064,8069]
annassign [8064,8069]
===
match
---
atom_expr [15875,15888]
atom_expr [15875,15888]
===
match
---
name: str [4299,4302]
name: str [4299,4302]
===
match
---
string: 'dag_run_conf_overrides_params' [62318,62349]
string: 'dag_run_conf_overrides_params' [62452,62483]
===
match
---
name: session [59177,59184]
name: session [59311,59318]
===
match
---
simple_stmt [28267,28515]
simple_stmt [28267,28515]
===
match
---
name: full_filepath [14691,14704]
name: full_filepath [14691,14704]
===
match
---
name: airflow [2257,2264]
name: airflow [2257,2264]
===
match
---
trailer [48826,48887]
trailer [48826,48887]
===
match
---
name: log [43197,43200]
name: log [43197,43200]
===
match
---
atom_expr [45992,46248]
atom_expr [45992,46248]
===
match
---
operator: , [19896,19897]
operator: , [19896,19897]
===
match
---
name: self [13275,13279]
name: self [13275,13279]
===
match
---
simple_stmt [31668,31736]
simple_stmt [31668,31736]
===
match
---
name: base_worker_pod [68703,68718]
name: base_worker_pod [68837,68852]
===
match
---
name: execution_date [15018,15032]
name: execution_date [15018,15032]
===
match
---
simple_stmt [13381,13529]
simple_stmt [13381,13529]
===
match
---
suite [41446,41501]
suite [41446,41501]
===
match
---
name: and_ [6838,6842]
name: and_ [6838,6842]
===
match
---
name: f [71773,71774]
name: f [71907,71908]
===
match
---
trailer [71872,71879]
trailer [72006,72013]
===
match
---
name: utcnow [40318,40324]
name: utcnow [40318,40324]
===
match
---
operator: } [19419,19420]
operator: } [19419,19420]
===
match
---
name: self [37513,37517]
name: self [37513,37517]
===
match
---
operator: = [79976,79977]
operator: = [80110,80111]
===
match
---
suite [43980,44123]
suite [43980,44123]
===
match
---
comparison [79113,79147]
comparison [79247,79281]
===
match
---
string: 'run_id' [65310,65318]
string: 'run_id' [65444,65452]
===
match
---
name: params [62235,62241]
name: params [62369,62375]
===
match
---
atom [77325,77592]
atom [77459,77726]
===
match
---
trailer [82185,82215]
trailer [82319,82349]
===
match
---
name: value [74000,74005]
name: value [74134,74139]
===
match
---
name: task_copy [48174,48183]
name: task_copy [48174,48183]
===
match
---
atom_expr [43416,43432]
atom_expr [43416,43432]
===
match
---
return_stmt [81210,81226]
return_stmt [81344,81360]
===
match
---
argument [64328,64349]
argument [64462,64483]
===
match
---
operator: = [53582,53583]
operator: = [53582,53583]
===
match
---
name: self [31986,31990]
name: self [31986,31990]
===
match
---
name: instance [64553,64561]
name: instance [64687,64695]
===
match
---
name: params [59831,59837]
name: params [59965,59971]
===
match
---
name: self [55235,55239]
name: self [55235,55239]
===
match
---
atom_expr [61259,61307]
atom_expr [61393,61441]
===
match
---
atom_expr [27344,27350]
atom_expr [27344,27350]
===
match
---
name: clear_task_instances [4687,4707]
name: clear_task_instances [4687,4707]
===
match
---
atom_expr [59741,59750]
atom_expr [59875,59884]
===
match
---
trailer [7266,7274]
trailer [7266,7274]
===
match
---
suite [11512,11974]
suite [11512,11974]
===
match
---
trailer [65050,65143]
trailer [65184,65277]
===
match
---
expr_stmt [11192,11217]
expr_stmt [11192,11217]
===
match
---
name: raw [77692,77695]
name: raw [77826,77829]
===
match
---
trailer [50471,50484]
trailer [50471,50484]
===
match
---
suite [67875,68056]
suite [68009,68190]
===
match
---
name: self [56661,56665]
name: self [56795,56799]
===
match
---
simple_stmt [56731,56787]
simple_stmt [56865,56921]
===
match
---
name: BaseJob [7388,7395]
name: BaseJob [7388,7395]
===
match
---
name: dag_run [67746,67753]
name: dag_run [67880,67887]
===
match
---
suite [21912,22804]
suite [21912,22804]
===
match
---
if_stmt [12099,12140]
if_stmt [12099,12140]
===
match
---
trailer [38954,38965]
trailer [38954,38965]
===
match
---
atom_expr [48506,48551]
atom_expr [48506,48551]
===
match
---
operator: = [62060,62061]
operator: = [62194,62195]
===
match
---
arglist [26096,26327]
arglist [26096,26327]
===
match
---
param [12503,12507]
param [12503,12507]
===
match
---
return_stmt [63941,63961]
return_stmt [64075,64095]
===
match
---
simple_stmt [32110,32123]
simple_stmt [32110,32123]
===
match
---
name: context [51863,51870]
name: context [51863,51870]
===
match
---
atom_expr [39210,39236]
atom_expr [39210,39236]
===
match
---
trailer [49292,49298]
trailer [49292,49298]
===
match
---
arith_expr [40188,40206]
arith_expr [40188,40206]
===
match
---
arglist [34508,34554]
arglist [34508,34554]
===
match
---
atom_expr [19289,19322]
atom_expr [19289,19322]
===
match
---
name: str [64032,64035]
name: str [64166,64169]
===
match
---
trailer [19105,19112]
trailer [19105,19112]
===
match
---
name: __init__ [62723,62731]
name: __init__ [62857,62865]
===
match
---
name: datetime [80549,80557]
name: datetime [80683,80691]
===
match
---
name: DateTime [29262,29270]
name: DateTime [29262,29270]
===
match
---
import_from [1562,1590]
import_from [1562,1590]
===
match
---
trailer [35009,35016]
trailer [35009,35016]
===
match
---
annassign [3230,3250]
annassign [3230,3250]
===
match
---
arith_expr [33612,33631]
arith_expr [33612,33631]
===
match
---
string: "Marking success for %s on %s" [41132,41162]
string: "Marking success for %s on %s" [41132,41162]
===
match
---
trailer [60148,60154]
trailer [60282,60288]
===
match
---
name: execution_date [9605,9619]
name: execution_date [9605,9619]
===
match
---
operator: == [24036,24038]
operator: == [24036,24038]
===
match
---
operator: = [27927,27928]
operator: = [27927,27928]
===
match
---
trailer [61829,61838]
trailer [61963,61972]
===
match
---
operator: = [50368,50369]
operator: = [50368,50369]
===
match
---
atom_expr [16057,16070]
atom_expr [16057,16070]
===
match
---
name: dag_id [76331,76337]
name: dag_id [76465,76471]
===
match
---
string: 'task' [69222,69228]
string: 'task' [69356,69362]
===
match
---
simple_stmt [1889,1924]
simple_stmt [1889,1924]
===
match
---
trailer [4035,4044]
trailer [4035,4044]
===
match
---
name: session [38511,38518]
name: session [38511,38518]
===
match
---
operator: @ [13327,13328]
operator: @ [13327,13328]
===
match
---
name: include_direct_upstream [46741,46764]
name: include_direct_upstream [46741,46764]
===
match
---
name: state [65109,65114]
name: state [65243,65248]
===
match
---
operator: , [53514,53515]
operator: , [53514,53515]
===
match
---
operator: -> [45724,45726]
operator: -> [45724,45726]
===
match
---
trailer [5436,5445]
trailer [5436,5445]
===
match
---
name: reconstructor [1436,1449]
name: reconstructor [1436,1449]
===
match
---
name: Context [51872,51879]
name: Context [51872,51879]
===
match
---
name: make_aware [11766,11776]
name: make_aware [11766,11776]
===
match
---
trailer [32055,32062]
trailer [32055,32062]
===
match
---
name: self [45493,45497]
name: self [45493,45497]
===
match
---
operator: @ [19853,19854]
operator: @ [19853,19854]
===
match
---
name: _date_or_empty [43821,43835]
name: _date_or_empty [43821,43835]
===
match
---
suite [39838,40425]
suite [39838,40425]
===
match
---
atom_expr [21571,21778]
atom_expr [21571,21778]
===
match
---
name: nullable [10014,10022]
name: nullable [10014,10022]
===
match
---
name: log [20851,20854]
name: log [20851,20854]
===
match
---
string: 'Rescheduling task, marking task as UP_FOR_RESCHEDULE' [55912,55966]
string: 'Rescheduling task, marking task as UP_FOR_RESCHEDULE' [55912,55966]
===
match
---
name: models [48107,48113]
name: models [48107,48113]
===
match
---
name: self [55423,55427]
name: self [55423,55427]
===
match
---
comparison [5171,5196]
comparison [5171,5196]
===
match
---
name: session [50881,50888]
name: session [50881,50888]
===
match
---
name: session [55873,55880]
name: session [55873,55880]
===
match
---
trailer [70801,70907]
trailer [70935,71041]
===
match
---
operator: = [22429,22430]
operator: = [22429,22430]
===
match
---
param [14213,14235]
param [14213,14235]
===
match
---
name: self [79758,79762]
name: self [79892,79896]
===
match
---
name: try_number [70648,70658]
name: try_number [70782,70792]
===
match
---
trailer [58753,58757]
trailer [58887,58891]
===
match
---
parameters [12502,12508]
parameters [12502,12508]
===
match
---
name: self [60477,60481]
name: self [60611,60615]
===
match
---
atom_expr [3257,3284]
atom_expr [3257,3284]
===
match
---
arglist [46600,46770]
arglist [46600,46770]
===
match
---
name: try_number [68360,68370]
name: try_number [68494,68504]
===
match
---
name: XCOM_RETURN_KEY [2103,2118]
name: XCOM_RETURN_KEY [2103,2118]
===
match
---
name: self [19725,19729]
name: self [19725,19729]
===
match
---
classdef [7955,8799]
classdef [7955,8799]
===
match
---
name: f [71810,71811]
name: f [71944,71945]
===
match
---
atom_expr [12073,12090]
atom_expr [12073,12090]
===
match
---
string: "--mark-success" [18070,18086]
string: "--mark-success" [18070,18086]
===
match
---
simple_stmt [80297,80316]
simple_stmt [80431,80450]
===
match
---
atom_expr [65076,65129]
atom_expr [65210,65263]
===
match
---
trailer [7693,7697]
trailer [7693,7697]
===
match
---
name: self [40465,40469]
name: self [40465,40469]
===
match
---
name: min [34504,34507]
name: min [34504,34507]
===
match
---
simple_stmt [54797,54837]
simple_stmt [54797,54837]
===
match
---
expr_stmt [34568,34619]
expr_stmt [34568,34619]
===
match
---
simple_stmt [21565,21779]
simple_stmt [21565,21779]
===
match
---
dotted_name [66055,66086]
dotted_name [66189,66220]
===
match
---
simple_stmt [56795,56821]
simple_stmt [56929,56955]
===
match
---
operator: = [53934,53935]
operator: = [53934,53935]
===
match
---
atom_expr [80261,80272]
atom_expr [80395,80406]
===
match
---
simple_stmt [40859,40879]
simple_stmt [40859,40879]
===
match
---
atom_expr [19408,19419]
atom_expr [19408,19419]
===
match
---
simple_stmt [62040,62092]
simple_stmt [62174,62226]
===
match
---
name: dag_run [62419,62426]
name: dag_run [62553,62560]
===
match
---
operator: , [59045,59046]
operator: , [59179,59180]
===
match
---
expr_stmt [79707,79749]
expr_stmt [79841,79883]
===
match
---
trailer [43552,43913]
trailer [43552,43913]
===
match
---
arglist [4665,4679]
arglist [4665,4679]
===
match
---
name: self [72211,72215]
name: self [72345,72349]
===
match
---
name: delay [33213,33218]
name: delay [33213,33218]
===
match
---
atom_expr [55898,55967]
atom_expr [55898,55967]
===
match
---
simple_stmt [23894,24079]
simple_stmt [23894,24079]
===
match
---
expr_stmt [44981,45014]
expr_stmt [44981,45014]
===
match
---
atom_expr [67134,67183]
atom_expr [67268,67317]
===
match
---
name: execution_date [35441,35455]
name: execution_date [35441,35455]
===
match
---
trailer [55294,55296]
trailer [55294,55296]
===
match
---
operator: , [50580,50581]
operator: , [50580,50581]
===
match
---
atom_expr [10144,10159]
atom_expr [10144,10159]
===
match
---
trailer [43504,43510]
trailer [43504,43510]
===
match
---
parameters [28103,28109]
parameters [28103,28109]
===
match
---
decorator [80600,80610]
decorator [80734,80744]
===
match
---
name: run_id [59875,59881]
name: run_id [60009,60015]
===
match
---
atom_expr [52028,52061]
atom_expr [52028,52061]
===
match
---
name: prev_execution_date [61839,61858]
name: prev_execution_date [61973,61992]
===
match
---
arglist [80174,80195]
arglist [80308,80329]
===
match
---
trailer [10632,10671]
trailer [10632,10671]
===
match
---
name: local [15281,15286]
name: local [15281,15286]
===
match
---
fstring_string: __ [62187,62189]
fstring_string: __ [62321,62323]
===
match
---
operator: , [81940,81941]
operator: , [82074,82075]
===
match
---
name: hostname [22434,22442]
name: hostname [22434,22442]
===
match
---
name: dag_id [62180,62186]
name: dag_id [62314,62320]
===
match
---
operator: , [64926,64927]
operator: , [65060,65061]
===
match
---
name: self [56643,56647]
name: self [56777,56781]
===
match
---
return_stmt [72143,72189]
return_stmt [72277,72323]
===
match
---
operator: , [10705,10706]
operator: , [10705,10706]
===
match
---
name: task [52966,52970]
name: task [52966,52970]
===
match
---
number: 50 [10009,10011]
number: 50 [10009,10011]
===
match
---
trailer [46813,46817]
trailer [46813,46817]
===
match
---
import_from [1409,1463]
import_from [1409,1463]
===
match
---
atom_expr [22646,22666]
atom_expr [22646,22666]
===
match
---
return_stmt [80656,80679]
return_stmt [80790,80813]
===
match
---
trailer [35475,35477]
trailer [35475,35477]
===
match
---
name: self [52833,52837]
name: self [52833,52837]
===
match
---
operator: , [51060,51061]
operator: , [51060,51061]
===
match
---
trailer [80828,80840]
trailer [80962,80974]
===
match
---
atom_expr [40800,40813]
atom_expr [40800,40813]
===
match
---
operator: } [70338,70339]
operator: } [70472,70473]
===
match
---
name: dag [14593,14596]
name: dag [14593,14596]
===
match
---
name: DepContext [32378,32388]
name: DepContext [32378,32388]
===
match
---
string: "when Dag Serialization is enabled. Hence for the task that have not yet " [66691,66765]
string: "when Dag Serialization is enabled. Hence for the task that have not yet " [66825,66899]
===
match
---
atom_expr [20439,20458]
atom_expr [20439,20458]
===
match
---
name: ignore_task_deps [38351,38367]
name: ignore_task_deps [38351,38367]
===
match
---
atom_expr [21691,21703]
atom_expr [21691,21703]
===
match
---
argument [10997,11016]
argument [10997,11016]
===
match
---
atom_expr [19725,19736]
atom_expr [19725,19736]
===
match
---
name: pickle [4435,4441]
name: pickle [4435,4441]
===
match
---
operator: @ [35512,35513]
operator: @ [35512,35513]
===
match
---
operator: , [50396,50397]
operator: , [50396,50397]
===
match
---
name: self [8752,8756]
name: self [8752,8756]
===
match
---
name: self [80663,80667]
name: self [80797,80801]
===
match
---
trailer [34699,34715]
trailer [34699,34715]
===
match
---
param [55098,55114]
param [55098,55114]
===
match
---
simple_stmt [72494,72549]
simple_stmt [72628,72683]
===
match
---
arith_expr [5564,5596]
arith_expr [5564,5596]
===
match
---
name: Context [67850,67857]
name: Context [67984,67991]
===
match
---
operator: @ [80600,80601]
operator: @ [80734,80735]
===
match
---
name: pool [53670,53674]
name: pool [53670,53674]
===
match
---
name: log [39948,39951]
name: log [39948,39951]
===
match
---
name: task [51881,51885]
name: task [51881,51885]
===
match
---
expr_stmt [53774,54211]
expr_stmt [53774,54211]
===
match
---
trailer [21511,21555]
trailer [21511,21555]
===
match
---
atom_expr [9934,9954]
atom_expr [9934,9954]
===
match
---
name: execution_date [11451,11465]
name: execution_date [11451,11465]
===
match
---
atom_expr [22786,22794]
atom_expr [22786,22794]
===
match
---
if_stmt [76158,76210]
if_stmt [76292,76344]
===
match
---
string: """URL to mark TI success""" [19477,19505]
string: """URL to mark TI success""" [19477,19505]
===
match
---
operator: = [54555,54556]
operator: = [54555,54556]
===
match
---
suite [38547,38610]
suite [38547,38610]
===
match
---
param [48038,48042]
param [48038,48042]
===
match
---
operator: = [74032,74033]
operator: = [74166,74167]
===
match
---
with_stmt [71754,71819]
with_stmt [71888,71953]
===
match
---
name: ti [80280,80282]
name: ti [80414,80416]
===
match
---
name: xcom [2091,2095]
name: xcom [2091,2095]
===
match
---
name: execution_date [8526,8540]
name: execution_date [8526,8540]
===
match
---
fstring_string: .log [19134,19138]
fstring_string: .log [19134,19138]
===
match
---
trailer [38423,38444]
trailer [38423,38444]
===
match
---
operator: , [47332,47333]
operator: , [47332,47333]
===
match
---
trailer [42980,43021]
trailer [42980,43021]
===
match
---
simple_stmt [48442,48497]
simple_stmt [48442,48497]
===
match
---
name: session [35066,35073]
name: session [35066,35073]
===
match
---
name: key [81172,81175]
name: key [81306,81309]
===
match
---
operator: -> [3934,3936]
operator: -> [3934,3936]
===
match
---
name: ds_nodash [64503,64512]
name: ds_nodash [64637,64646]
===
match
---
name: State [43513,43518]
name: State [43513,43518]
===
match
---
name: test_mode [40836,40845]
name: test_mode [40836,40845]
===
match
---
name: autoescape [70878,70888]
name: autoescape [71012,71022]
===
match
---
name: previous_schedule [27119,27136]
name: previous_schedule [27119,27136]
===
match
---
expr_stmt [22019,22046]
expr_stmt [22019,22046]
===
match
---
name: run_as_user [23442,23453]
name: run_as_user [23442,23453]
===
match
---
atom_expr [21886,21897]
atom_expr [21886,21897]
===
match
---
arglist [78829,78994]
arglist [78963,79128]
===
match
---
operator: , [10868,10869]
operator: , [10868,10869]
===
match
---
name: log_filepath [18890,18902]
name: log_filepath [18890,18902]
===
match
---
name: actual_start_date [42761,42778]
name: actual_start_date [42761,42778]
===
match
---
name: default_html_content_err [69885,69909]
name: default_html_content_err [70019,70043]
===
match
---
comparison [6744,6779]
comparison [6744,6779]
===
match
---
name: self [50559,50563]
name: self [50559,50563]
===
match
---
name: ti [79629,79631]
name: ti [79763,79765]
===
match
---
name: str [35954,35957]
name: str [35954,35957]
===
match
---
name: str [8165,8168]
name: str [8165,8168]
===
match
---
name: task_id [23995,24002]
name: task_id [23995,24002]
===
match
---
operator: , [38518,38519]
operator: , [38518,38519]
===
match
---
simple_stmt [8074,8099]
simple_stmt [8074,8099]
===
match
---
funcdef [66940,67502]
funcdef [67074,67636]
===
match
---
name: task_ids [6942,6950]
name: task_ids [6942,6950]
===
match
---
atom_expr [62121,62149]
atom_expr [62255,62283]
===
match
---
atom_expr [58432,58476]
atom_expr [58566,58610]
===
match
---
name: dag_ids [76323,76330]
name: dag_ids [76457,76464]
===
match
---
expr_stmt [14891,14902]
expr_stmt [14891,14902]
===
match
---
name: exception [69259,69268]
name: exception [69393,69402]
===
match
---
name: bool [15649,15653]
name: bool [15649,15653]
===
match
---
simple_stmt [13204,13232]
simple_stmt [13204,13232]
===
match
---
name: force_fail [59157,59167]
name: force_fail [59291,59301]
===
match
---
trailer [77468,77476]
trailer [77602,77610]
===
match
---
simple_stmt [32132,32190]
simple_stmt [32132,32190]
===
match
---
operator: = [61257,61258]
operator: = [61391,61392]
===
match
---
name: error [48345,48350]
name: error [48345,48350]
===
match
---
operator: = [38254,38255]
operator: = [38254,38255]
===
match
---
simple_stmt [3188,3213]
simple_stmt [3188,3213]
===
match
---
name: self [22019,22023]
name: self [22019,22023]
===
match
---
trailer [10188,10194]
trailer [10188,10194]
===
match
---
simple_stmt [58814,58834]
simple_stmt [58948,58968]
===
match
---
name: task_ids [6887,6895]
name: task_ids [6887,6895]
===
match
---
name: verbose [31708,31715]
name: verbose [31708,31715]
===
match
---
trailer [18968,18983]
trailer [18968,18983]
===
match
---
atom_expr [29244,29271]
atom_expr [29244,29271]
===
match
---
simple_stmt [4780,5044]
simple_stmt [4780,5044]
===
match
---
trailer [7396,7403]
trailer [7396,7403]
===
match
---
name: _run_finished_callback [54729,54751]
name: _run_finished_callback [54729,54751]
===
match
---
trailer [40872,40878]
trailer [40872,40878]
===
match
---
name: session [54193,54200]
name: session [54193,54200]
===
match
---
name: execution_date [20421,20435]
name: execution_date [20421,20435]
===
match
---
operator: , [1318,1319]
operator: , [1318,1319]
===
match
---
simple_stmt [48625,48648]
simple_stmt [48625,48648]
===
match
---
name: priority_weight [22672,22687]
name: priority_weight [22672,22687]
===
match
---
trailer [60009,60013]
trailer [60143,60147]
===
match
---
name: hostname [37615,37623]
name: hostname [37615,37623]
===
match
---
trailer [8545,8569]
trailer [8545,8569]
===
match
---
suite [22817,22848]
suite [22817,22848]
===
match
---
name: execution_date [72953,72967]
name: execution_date [73087,73101]
===
match
---
name: test_mode [54112,54121]
name: test_mode [54112,54121]
===
match
---
name: quote [19520,19525]
name: quote [19520,19525]
===
match
---
expr_stmt [61745,61786]
expr_stmt [61879,61920]
===
match
---
atom_expr [55845,55864]
atom_expr [55845,55864]
===
match
---
trailer [77050,77062]
trailer [77184,77196]
===
match
---
name: self [81927,81931]
name: self [82061,82065]
===
match
---
name: task [34640,34644]
name: task [34640,34644]
===
match
---
atom_expr [3946,3967]
atom_expr [3946,3967]
===
match
---
atom_expr [48960,48971]
atom_expr [48960,48971]
===
match
---
suite [4200,4248]
suite [4200,4248]
===
match
---
name: TaskInstanceKey [24289,24304]
name: TaskInstanceKey [24289,24304]
===
match
---
expr_stmt [39056,39135]
expr_stmt [39056,39135]
===
match
---
trailer [55281,55294]
trailer [55281,55294]
===
match
---
name: session [59169,59176]
name: session [59303,59310]
===
match
---
name: bool [15774,15778]
name: bool [15774,15778]
===
match
---
trailer [69215,69229]
trailer [69349,69363]
===
match
---
operator: = [54483,54484]
operator: = [54483,54484]
===
match
---
number: 1 [8546,8547]
number: 1 [8546,8547]
===
match
---
funcdef [77598,77728]
funcdef [77732,77862]
===
match
---
string: "/success" [19652,19662]
string: "/success" [19652,19662]
===
match
---
name: self [48336,48340]
name: self [48336,48340]
===
match
---
operator: -> [80876,80878]
operator: -> [81010,81012]
===
match
---
try_stmt [4418,4681]
try_stmt [4418,4681]
===
match
---
operator: == [20375,20377]
operator: == [20375,20377]
===
match
---
operator: = [45814,45815]
operator: = [45814,45815]
===
match
---
dotted_name [45640,45660]
dotted_name [45640,45660]
===
match
---
operator: = [5422,5423]
operator: = [5422,5423]
===
match
---
number: 0 [20541,20542]
number: 0 [20541,20542]
===
match
---
simple_stmt [62481,62706]
simple_stmt [62615,62840]
===
match
---
atom_expr [52833,52842]
atom_expr [52833,52842]
===
match
---
expr_stmt [42529,42545]
expr_stmt [42529,42545]
===
match
---
string: 'email' [71669,71676]
string: 'email' [71803,71810]
===
match
---
string: 'Mark success: <a href="{{ti.mark_success_url}}">Link</a><br>' [70201,70263]
string: 'Mark success: <a href="{{ti.mark_success_url}}">Link</a><br>' [70335,70397]
===
match
---
sync_comp_for [7042,7089]
sync_comp_for [7042,7089]
===
match
---
name: SUCCESS [54644,54651]
name: SUCCESS [54644,54651]
===
match
---
simple_stmt [4329,4371]
simple_stmt [4329,4371]
===
match
---
string: '' [59884,59886]
string: '' [60018,60020]
===
match
---
atom_expr [37478,37492]
atom_expr [37478,37492]
===
match
---
simple_stmt [40343,40363]
simple_stmt [40343,40363]
===
match
---
trailer [19016,19021]
trailer [19016,19021]
===
match
---
name: conf [67654,67658]
name: conf [67788,67792]
===
match
---
atom [44542,44571]
atom [44542,44571]
===
match
---
arglist [37753,37781]
arglist [37753,37781]
===
match
---
name: self [55529,55533]
name: self [55529,55533]
===
match
---
operator: = [31652,31653]
operator: = [31652,31653]
===
match
---
decorated [18872,19140]
decorated [18872,19140]
===
match
---
name: start_date [21980,21990]
name: start_date [21980,21990]
===
match
---
suite [32302,32858]
suite [32302,32858]
===
match
---
suite [51385,51450]
suite [51385,51450]
===
match
---
simple_stmt [9664,9697]
simple_stmt [9664,9697]
===
match
---
operator: { [62174,62175]
operator: { [62308,62309]
===
match
---
trailer [33258,33263]
trailer [33258,33263]
===
match
---
operator: , [72835,72836]
operator: , [72969,72970]
===
match
---
name: _Variable__NO_DEFAULT_SENTINEL [64132,64162]
name: _Variable__NO_DEFAULT_SENTINEL [64266,64296]
===
match
---
param [14143,14166]
param [14143,14166]
===
match
---
suite [50702,51033]
suite [50702,51033]
===
match
---
operator: + [34077,34078]
operator: + [34077,34078]
===
match
---
atom_expr [23271,23281]
atom_expr [23271,23281]
===
match
---
trailer [9911,9917]
trailer [9911,9917]
===
match
---
name: Exception [56054,56063]
name: Exception [56054,56063]
===
match
---
operator: , [15531,15532]
operator: , [15531,15532]
===
match
---
atom_expr [42844,42856]
atom_expr [42844,42856]
===
match
---
name: replace [69270,69277]
name: replace [69404,69411]
===
match
---
number: 0 [26357,26358]
number: 0 [26357,26358]
===
match
---
expr_stmt [69190,69229]
expr_stmt [69324,69363]
===
match
---
simple_stmt [18356,18394]
simple_stmt [18356,18394]
===
match
---
trailer [59385,59395]
trailer [59519,59529]
===
match
---
name: html_content [72442,72454]
name: html_content [72576,72588]
===
match
---
operator: = [27824,27825]
operator: = [27824,27825]
===
match
---
name: session [6023,6030]
name: session [6023,6030]
===
match
---
name: str [19915,19918]
name: str [19915,19918]
===
match
---
return_stmt [78800,79008]
return_stmt [78934,79142]
===
match
---
name: get_template_context [42937,42957]
name: get_template_context [42937,42957]
===
match
---
operator: , [65774,65775]
operator: , [65908,65909]
===
match
---
name: pool_slots [22568,22578]
name: pool_slots [22568,22578]
===
match
---
name: isoformat [60497,60506]
name: isoformat [60631,60640]
===
match
---
operator: , [14279,14280]
operator: , [14279,14280]
===
match
---
operator: = [23269,23270]
operator: = [23269,23270]
===
match
---
name: task_tries [6954,6964]
name: task_tries [6954,6964]
===
match
---
name: self [32264,32268]
name: self [32264,32268]
===
match
---
operator: | [32427,32428]
operator: | [32427,32428]
===
match
---
trailer [55400,55405]
trailer [55400,55405]
===
match
---
name: property [80601,80609]
name: property [80735,80743]
===
match
---
name: iso [19770,19773]
name: iso [19770,19773]
===
match
---
operator: == [78849,78851]
operator: == [78983,78985]
===
match
---
name: state [80864,80869]
name: state [80998,81003]
===
match
---
dotted_name [82445,82466]
dotted_name [82579,82600]
===
match
---
subscriptlist [3203,3211]
subscriptlist [3203,3211]
===
match
---
suite [51741,51804]
suite [51741,51804]
===
match
---
operator: { [59840,59841]
operator: { [59974,59975]
===
match
---
simple_stmt [51406,51450]
simple_stmt [51406,51450]
===
match
---
operator: , [15963,15964]
operator: , [15963,15964]
===
match
---
trailer [70512,70757]
trailer [70646,70891]
===
match
---
atom_expr [34686,34723]
atom_expr [34686,34723]
===
match
---
name: Optional [56162,56170]
name: Optional [56162,56170]
===
match
---
atom_expr [24993,25006]
atom_expr [24993,25006]
===
match
---
string: """Return task instance primary key part of the key""" [8194,8248]
string: """Return task instance primary key part of the key""" [8194,8248]
===
match
---
name: error [56352,56357]
name: error [56352,56357]
===
match
---
operator: = [34502,34503]
operator: = [34502,34503]
===
match
---
operator: , [72520,72521]
operator: , [72654,72655]
===
match
---
argument [38288,38333]
argument [38288,38333]
===
match
---
name: PodGenerator [68719,68731]
name: PodGenerator [68853,68865]
===
match
---
funcdef [22912,23602]
funcdef [22912,23602]
===
match
---
operator: = [78157,78158]
operator: = [78291,78292]
===
match
---
name: try_number [6846,6856]
name: try_number [6846,6856]
===
match
---
name: external_trigger [61003,61019]
name: external_trigger [61137,61153]
===
match
---
operator: -> [24181,24183]
operator: -> [24181,24183]
===
match
---
trailer [46096,46103]
trailer [46096,46103]
===
match
---
name: from_string [71030,71041]
name: from_string [71164,71175]
===
match
---
operator: , [24746,24747]
operator: , [24746,24747]
===
match
---
name: str [63083,63086]
name: str [63217,63220]
===
match
---
name: Column [10382,10388]
name: Column [10382,10388]
===
match
---
operator: = [59739,59740]
operator: = [59873,59874]
===
match
---
atom_expr [60229,60248]
atom_expr [60363,60382]
===
match
---
arglist [6744,6999]
arglist [6744,6999]
===
match
---
atom_expr [45448,45458]
atom_expr [45448,45458]
===
match
---
name: state [10611,10616]
name: state [10611,10616]
===
match
---
trailer [44792,44829]
trailer [44792,44829]
===
match
---
expr_stmt [76888,76957]
expr_stmt [77022,77091]
===
match
---
name: Variable [63310,63318]
name: Variable [63444,63452]
===
match
---
atom_expr [34949,34967]
atom_expr [34949,34967]
===
match
---
name: previous_ti [28092,28103]
name: previous_ti [28092,28103]
===
match
---
simple_stmt [40800,40821]
simple_stmt [40800,40821]
===
match
---
param [62732,62736]
param [62866,62870]
===
match
---
operator: @ [30846,30847]
operator: @ [30846,30847]
===
match
---
atom_expr [82486,82506]
atom_expr [82620,82640]
===
match
---
atom_expr [55460,55476]
atom_expr [55460,55476]
===
match
---
arglist [9817,9849]
arglist [9817,9849]
===
match
---
name: prev_execution_date [61033,61052]
name: prev_execution_date [61167,61186]
===
match
---
name: context [49809,49816]
name: context [49809,49816]
===
match
---
operator: == [39012,39014]
operator: == [39012,39014]
===
match
---
operator: = [14127,14128]
operator: = [14127,14128]
===
match
---
name: str [79864,79867]
name: str [79998,80001]
===
match
---
param [81384,81405]
param [81518,81539]
===
match
---
name: Session [74485,74492]
name: Session [74619,74626]
===
match
---
simple_stmt [56229,56271]
simple_stmt [56229,56271]
===
match
---
operator: , [54171,54172]
operator: , [54171,54172]
===
match
---
trailer [6634,7122]
trailer [6634,7122]
===
match
---
atom_expr [78534,78553]
atom_expr [78668,78687]
===
match
---
string: "--ignore-depends-on-past" [18453,18479]
string: "--ignore-depends-on-past" [18453,18479]
===
match
---
atom [18533,18544]
atom [18533,18544]
===
match
---
trailer [61208,61223]
trailer [61342,61357]
===
match
---
name: num [47453,47456]
name: num [47453,47456]
===
match
---
operator: , [64326,64327]
operator: , [64460,64461]
===
match
---
arglist [56957,57014]
arglist [57091,57148]
===
match
---
name: get_email_subject_content [72343,72368]
name: get_email_subject_content [72477,72502]
===
match
---
name: fd [4454,4456]
name: fd [4454,4456]
===
match
---
name: data [4050,4054]
name: data [4050,4054]
===
match
---
trailer [76853,76859]
trailer [76987,76993]
===
match
---
name: self [45225,45229]
name: self [45225,45229]
===
match
---
expr_stmt [33213,33242]
expr_stmt [33213,33242]
===
match
---
operator: , [67340,67341]
operator: , [67474,67475]
===
match
---
trailer [9555,9581]
trailer [9555,9581]
===
match
---
atom_expr [18522,18545]
atom_expr [18522,18545]
===
match
---
name: t [78777,78778]
name: t [78911,78912]
===
match
---
parameters [13365,13371]
parameters [13365,13371]
===
match
---
simple_stmt [10277,10299]
simple_stmt [10277,10299]
===
match
---
if_stmt [32795,32858]
if_stmt [32795,32858]
===
match
---
parameters [63657,63663]
parameters [63791,63797]
===
match
---
atom_expr [52966,52999]
atom_expr [52966,52999]
===
match
---
name: e [67457,67458]
name: e [67591,67592]
===
match
---
name: all [20487,20490]
name: all [20487,20490]
===
match
---
atom_expr [63807,63815]
atom_expr [63941,63949]
===
match
---
suite [29855,30267]
suite [29855,30267]
===
match
---
operator: @ [13883,13884]
operator: @ [13883,13884]
===
match
---
param [67560,67567]
param [67694,67701]
===
match
---
name: self [65497,65501]
name: self [65631,65635]
===
match
---
name: self [33012,33016]
name: self [33012,33016]
===
match
---
simple_stmt [2071,2125]
simple_stmt [2071,2125]
===
match
---
operator: , [74387,74388]
operator: , [74521,74522]
===
match
---
atom_expr [44773,44829]
atom_expr [44773,44829]
===
match
---
simple_stmt [3539,3572]
simple_stmt [3539,3572]
===
match
---
trailer [18359,18366]
trailer [18359,18366]
===
match
---
operator: = [68451,68452]
operator: = [68585,68586]
===
match
---
name: exception [71339,71348]
name: exception [71473,71482]
===
match
---
name: self [40545,40549]
name: self [40545,40549]
===
match
---
simple_stmt [2125,2186]
simple_stmt [2125,2186]
===
match
---
name: bool [53541,53545]
name: bool [53541,53545]
===
match
---
name: self [22531,22535]
name: self [22531,22535]
===
match
---
name: UtcDateTime [9684,9695]
name: UtcDateTime [9684,9695]
===
match
---
suite [44613,44709]
suite [44613,44709]
===
match
---
trailer [28613,28629]
trailer [28613,28629]
===
match
---
name: dag_id [23939,23945]
name: dag_id [23939,23945]
===
match
---
operator: = [82169,82170]
operator: = [82303,82304]
===
match
---
name: self [31762,31766]
name: self [31762,31766]
===
match
---
name: task [46555,46559]
name: task [46555,46559]
===
match
---
subscript [82201,82205]
subscript [82335,82339]
===
match
---
trailer [37705,37711]
trailer [37705,37711]
===
match
---
trailer [23383,23399]
trailer [23383,23399]
===
match
---
name: task [23587,23591]
name: task [23587,23591]
===
match
---
operator: = [53615,53616]
operator: = [53615,53616]
===
match
---
operator: = [54141,54142]
operator: = [54141,54142]
===
match
---
operator: , [68346,68347]
operator: , [68480,68481]
===
match
---
param [24428,24440]
param [24428,24440]
===
match
---
name: logging_mixin [2528,2541]
name: logging_mixin [2528,2541]
===
match
---
name: FAILED [57698,57704]
name: FAILED [57832,57838]
===
match
---
argument [6838,6972]
argument [6838,6972]
===
match
---
operator: = [46713,46714]
operator: = [46713,46714]
===
match
---
dictorsetmaker [7769,7800]
dictorsetmaker [7769,7800]
===
match
---
name: self [80077,80081]
name: self [80211,80215]
===
match
---
tfpdef [35753,35775]
tfpdef [35753,35775]
===
match
---
name: and_ [6714,6718]
name: and_ [6714,6718]
===
match
---
operator: == [79134,79136]
operator: == [79268,79270]
===
match
---
name: get_previous_execution_date [29122,29149]
name: get_previous_execution_date [29122,29149]
===
match
---
suite [45732,47973]
suite [45732,47973]
===
match
---
operator: , [38270,38271]
operator: , [38270,38271]
===
match
---
expr_stmt [27344,27356]
expr_stmt [27344,27356]
===
match
---
trailer [55378,55611]
trailer [55378,55611]
===
match
---
atom_expr [32741,32758]
atom_expr [32741,32758]
===
match
---
expr_stmt [22059,22086]
expr_stmt [22059,22086]
===
match
---
trailer [58767,58774]
trailer [58901,58908]
===
match
---
trailer [76834,76860]
trailer [76968,76994]
===
match
---
arglist [59929,59940]
arglist [60063,60074]
===
match
---
name: Integer [10264,10271]
name: Integer [10264,10271]
===
match
---
return_stmt [77318,77592]
return_stmt [77452,77726]
===
match
---
name: __table__ [7214,7223]
name: __table__ [7214,7223]
===
match
---
trailer [71041,71063]
trailer [71175,71197]
===
match
---
trailer [67849,67858]
trailer [67983,67992]
===
match
---
atom_expr [14708,14720]
atom_expr [14708,14720]
===
match
---
name: bool [56094,56098]
name: bool [56094,56098]
===
match
---
simple_stmt [2458,2505]
simple_stmt [2458,2505]
===
match
---
string: """             Wrapper around Variable. This way you can get variables in             templates by using ``{{ var.value.variable_name }}`` or             ``{{ var.value.get('variable_name', 'fallback') }}``.             """ [62481,62705]
string: """             Wrapper around Variable. This way you can get variables in             templates by using ``{{ var.value.variable_name }}`` or             ``{{ var.value.get('variable_name', 'fallback') }}``.             """ [62615,62839]
===
match
---
simple_stmt [22646,22688]
simple_stmt [22646,22688]
===
match
---
operator: -> [16085,16087]
operator: -> [16085,16087]
===
match
---
operator: , [26476,26477]
operator: , [26476,26477]
===
match
---
name: airflow [82400,82407]
name: airflow [82534,82541]
===
match
---
operator: , [52268,52269]
operator: , [52268,52269]
===
match
---
number: 1 [56781,56782]
number: 1 [56915,56916]
===
match
---
argument [15388,15401]
argument [15388,15401]
===
match
---
trailer [67680,67686]
trailer [67814,67820]
===
match
---
atom_expr [70850,70875]
atom_expr [70984,71009]
===
match
---
operator: = [55122,55123]
operator: = [55122,55123]
===
match
---
if_stmt [11700,11904]
if_stmt [11700,11904]
===
match
---
string: "XCom data cleared" [24127,24146]
string: "XCom data cleared" [24127,24146]
===
match
---
operator: } [65942,65943]
operator: } [66076,66077]
===
match
---
name: dag_id [78112,78118]
name: dag_id [78246,78252]
===
match
---
operator: = [72336,72337]
operator: = [72470,72471]
===
match
---
trailer [68102,68108]
trailer [68236,68242]
===
match
---
name: mark_success [35832,35844]
name: mark_success [35832,35844]
===
match
---
trailer [54954,54971]
trailer [54954,54971]
===
match
---
trailer [39470,39736]
trailer [39470,39736]
===
match
---
name: dag_model [10881,10890]
name: dag_model [10881,10890]
===
match
---
name: self [40800,40804]
name: self [40800,40804]
===
match
---
name: task_id [19692,19699]
name: task_id [19692,19699]
===
match
---
import_from [7526,7566]
import_from [7526,7566]
===
match
---
dotted_name [2130,2153]
dotted_name [2130,2153]
===
match
---
name: AirflowFailException [1689,1709]
name: AirflowFailException [1689,1709]
===
match
---
name: ti [79543,79545]
name: ti [79677,79679]
===
match
---
trailer [47170,47186]
trailer [47170,47186]
===
match
---
name: String [10002,10008]
name: String [10002,10008]
===
match
---
trailer [41034,41036]
trailer [41034,41036]
===
match
---
atom_expr [71566,71594]
atom_expr [71700,71728]
===
match
---
atom_expr [22830,22840]
atom_expr [22830,22840]
===
match
---
name: max_retry_delay [34645,34660]
name: max_retry_delay [34645,34660]
===
match
---
operator: -> [4316,4318]
operator: -> [4316,4318]
===
match
---
name: models [45847,45853]
name: models [45847,45853]
===
match
---
operator: , [1709,1710]
operator: , [1709,1710]
===
match
---
argument [76435,76450]
argument [76569,76584]
===
match
---
fstring_end: " [19138,19139]
fstring_end: " [19138,19139]
===
match
---
string: "Dependencies all met for %s" [32153,32182]
string: "Dependencies all met for %s" [32153,32182]
===
match
---
atom_expr [59991,60021]
atom_expr [60125,60155]
===
match
---
simple_stmt [48506,48552]
simple_stmt [48506,48552]
===
match
---
trailer [22473,22482]
trailer [22473,22482]
===
match
---
name: merge [6031,6036]
name: merge [6031,6036]
===
match
---
exprlist [6930,6950]
exprlist [6930,6950]
===
match
---
name: cmd [18811,18814]
name: cmd [18811,18814]
===
match
---
expr_stmt [7882,7906]
expr_stmt [7882,7906]
===
match
---
param [13275,13280]
param [13275,13280]
===
match
---
atom_expr [19033,19071]
atom_expr [19033,19071]
===
match
---
name: COLLATION_ARGS [10406,10420]
name: COLLATION_ARGS [10406,10420]
===
match
---
subscriptlist [3952,3966]
subscriptlist [3952,3966]
===
match
---
name: self [43416,43420]
name: self [43416,43420]
===
match
---
name: self [33818,33822]
name: self [33818,33822]
===
match
---
trailer [55880,55887]
trailer [55880,55887]
===
match
---
operator: , [4771,4772]
operator: , [4771,4772]
===
match
---
name: self [40769,40773]
name: self [40769,40773]
===
match
---
operator: = [67975,67976]
operator: = [68109,68110]
===
match
---
except_clause [43236,43268]
except_clause [43236,43268]
===
match
---
trailer [56874,56894]
trailer [57008,57028]
===
match
---
operator: = [63340,63341]
operator: = [63474,63475]
===
match
---
string: 'start_date' [45296,45308]
string: 'start_date' [45296,45308]
===
match
---
trailer [4298,4314]
trailer [4298,4314]
===
match
---
return_stmt [64277,64350]
return_stmt [64411,64484]
===
match
---
trailer [54751,54764]
trailer [54751,54764]
===
insert-node
---
name: TaskInstance [8807,8819]
to
classdef [8801,79265]
at 0
===
insert-tree
---
arglist [8820,8838]
    name: Base [8820,8824]
    operator: , [8824,8825]
    name: LoggingMixin [8826,8838]
to
classdef [8801,79265]
at 1
===
insert-tree
---
simple_stmt [8876,9418]
    string: """     Task instances store the state of a task instance. This table is the     authority and single source of truth around what tasks have run and the     state they are in.      The SqlAlchemy model doesn't have a SqlAlchemy foreign key to the task or     dag model deliberately to have more control over transactions.      Database transactions on this table should insure double triggers and     any confusion around what task instances are or aren't ready to run     even while multiple schedulers may be firing task instances.     """ [8876,9417]
to
suite [8871,79265]
at 0
===
insert-node
---
if_stmt [56371,56531]
to
suite [56358,56627]
at 0
===
insert-node
---
suite [56486,56531]
to
if_stmt [56371,56531]
at 2
===
move-tree
---
simple_stmt [56371,56397]
    atom_expr [56371,56396]
        name: self [56371,56375]
        trailer [56375,56379]
            name: log [56376,56379]
        trailer [56379,56389]
            name: exception [56380,56389]
        trailer [56389,56396]
            name: error [56390,56395]
to
suite [56486,56531]
at 0
===
update-node
---
name: exception [56380,56389]
replace exception by error
===
insert-node
---
arglist [56518,56529]
to
trailer [56389,56396]
at 0
===
move-tree
---
name: error [56390,56395]
to
arglist [56518,56529]
at 2
===
delete-node
---
name: TaskInstance [8807,8819]
===
===
delete-tree
---
arglist [8820,8838]
    name: Base [8820,8824]
    operator: , [8824,8825]
    name: LoggingMixin [8826,8838]
===
delete-tree
---
simple_stmt [8876,9418]
    string: """     Task instances store the state of a task instance. This table is the     authority and single source of truth around what tasks have run and the     state they are in.      The SqlAlchemy model doesn't have a SqlAlchemy foreign key to the task or     dag model deliberately to have more control over transactions.      Database transactions on this table should insure double triggers and     any confusion around what task instances are or aren't ready to run     even while multiple schedulers may be firing task instances.     """ [8876,9417]
