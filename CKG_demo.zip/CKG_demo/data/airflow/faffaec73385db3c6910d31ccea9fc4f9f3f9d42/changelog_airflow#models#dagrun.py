===
match
---
name: filter [9907,9913]
name: filter [9610,9616]
===
match
---
trailer [26292,26299]
trailer [25995,26002]
===
match
---
name: self [4927,4931]
name: self [4868,4872]
===
match
---
trailer [26345,26353]
trailer [26048,26056]
===
match
---
operator: = [18027,18028]
operator: = [17730,17731]
===
match
---
return_stmt [28156,28420]
return_stmt [27859,28123]
===
match
---
name: query [7833,7838]
name: query [7536,7541]
===
match
---
comp_op [26395,26401]
comp_op [26098,26104]
===
match
---
name: fresh_tis [21121,21130]
name: fresh_tis [20824,20833]
===
match
---
name: callback_requests [14269,14286]
name: callback_requests [13972,13989]
===
match
---
sync_comp_for [16289,16312]
sync_comp_for [15992,16015]
===
match
---
name: str [13193,13196]
name: str [12896,12899]
===
match
---
name: DagRun [13986,13992]
name: DagRun [13689,13695]
===
match
---
operator: = [25697,25698]
operator: = [25400,25401]
===
match
---
trailer [20680,20686]
trailer [20383,20389]
===
match
---
expr_stmt [12037,12108]
expr_stmt [11740,11811]
===
match
---
trailer [2844,2857]
trailer [2785,2798]
===
match
---
name: str [4396,4399]
name: str [4337,4340]
===
match
---
trailer [29039,29041]
trailer [28742,28744]
===
match
---
funcdef [11258,12321]
funcdef [10961,12024]
===
match
---
name: datetime [8513,8521]
name: datetime [8216,8224]
===
match
---
name: Optional [884,892]
name: Optional [884,892]
===
match
---
atom_expr [20466,20474]
atom_expr [20169,20177]
===
match
---
atom_expr [13112,13120]
atom_expr [12815,12823]
===
match
---
name: query [11465,11470]
name: query [11168,11173]
===
match
---
name: bool [14223,14227]
name: bool [13926,13930]
===
match
---
atom_expr [4180,4198]
atom_expr [4121,4139]
===
match
---
simple_stmt [23513,23586]
simple_stmt [23216,23289]
===
match
---
trailer [3645,3660]
trailer [3586,3601]
===
match
---
name: self [24911,24915]
name: self [24614,24618]
===
match
---
arglist [17446,17650]
arglist [17149,17353]
===
match
---
name: TI [1559,1561]
name: TI [1500,1502]
===
match
---
name: execution_date [3664,3678]
name: execution_date [3605,3619]
===
match
---
name: set_state [17920,17929]
name: set_state [17623,17632]
===
match
---
suite [21999,22028]
suite [21702,21731]
===
match
---
name: id [2609,2611]
name: id [2550,2552]
===
match
---
trailer [11678,11684]
trailer [11381,11387]
===
match
---
atom_expr [23095,23105]
atom_expr [22798,22808]
===
match
---
trailer [7473,7603]
trailer [7176,7306]
===
match
---
name: first [28403,28408]
name: first [28106,28111]
===
match
---
comparison [19763,19794]
comparison [19466,19497]
===
match
---
name: execute_callbacks [17205,17222]
name: execute_callbacks [16908,16925]
===
match
---
trailer [2333,2337]
trailer [2274,2278]
===
match
---
return_stmt [5397,5415]
return_stmt [5338,5356]
===
match
---
name: t [15654,15655]
name: t [15357,15358]
===
match
---
operator: , [20363,20364]
operator: , [20066,20067]
===
match
---
name: dag_id [28253,28259]
name: dag_id [27956,27962]
===
match
---
name: state [5618,5623]
name: state [5559,5564]
===
match
---
atom_expr [2838,2857]
atom_expr [2779,2798]
===
match
---
expr_stmt [9754,9765]
expr_stmt [9457,9468]
===
match
---
simple_stmt [11659,11695]
simple_stmt [11362,11398]
===
match
---
trailer [2985,2994]
trailer [2926,2935]
===
match
---
name: task_instances [3554,3568]
name: task_instances [3495,3509]
===
match
---
trailer [19067,19076]
trailer [18770,18779]
===
match
---
name: DR [10566,10568]
name: DR [10269,10271]
===
match
---
name: provide_session [1858,1873]
name: provide_session [1799,1814]
===
match
---
operator: , [18429,18430]
operator: , [18132,18133]
===
match
---
trailer [8198,8208]
trailer [7901,7911]
===
match
---
trailer [9978,9985]
trailer [9681,9688]
===
match
---
name: finished_tasks [21902,21916]
name: finished_tasks [21605,21619]
===
match
---
trailer [25799,25807]
trailer [25502,25510]
===
match
---
argument [16490,16503]
argument [16193,16206]
===
match
---
trailer [21669,21690]
trailer [21372,21393]
===
match
---
operator: -> [21442,21444]
operator: -> [21145,21147]
===
match
---
atom_expr [24240,24316]
atom_expr [23943,24019]
===
match
---
param [4300,4328]
param [4241,4269]
===
match
---
name: state [10666,10671]
name: state [10369,10374]
===
match
---
try_stmt [23253,24439]
try_stmt [22956,24142]
===
match
---
trailer [30947,30962]
trailer [30650,30665]
===
match
---
name: leaf_tis [17076,17084]
name: leaf_tis [16779,16787]
===
match
---
name: end_date [24719,24727]
name: end_date [24422,24430]
===
match
---
sync_comp_for [21237,21256]
sync_comp_for [20940,20959]
===
match
---
name: state [4300,4305]
name: state [4241,4246]
===
match
---
operator: == [7510,7512]
operator: == [7213,7215]
===
match
---
operator: = [3262,3263]
operator: = [3203,3204]
===
match
---
suite [18905,20254]
suite [18608,19957]
===
match
---
name: ready_tis [20889,20898]
name: ready_tis [20592,20601]
===
match
---
trailer [4475,4482]
trailer [4416,4423]
===
match
---
comparison [13379,13422]
comparison [13082,13125]
===
match
---
name: synchronize_session [30626,30645]
name: synchronize_session [30329,30348]
===
match
---
comp_if [23568,23584]
comp_if [23271,23287]
===
match
---
name: filter [21151,21157]
name: filter [20854,20860]
===
match
---
arglist [23629,23672]
arglist [23332,23375]
===
match
---
operator: , [30435,30436]
operator: , [30138,30139]
===
match
---
name: qry [10732,10735]
name: qry [10435,10438]
===
match
---
name: LoggingMixin [1811,1823]
name: LoggingMixin [1752,1764]
===
match
---
name: state [12061,12066]
name: state [11764,11769]
===
match
---
trailer [11320,11339]
trailer [11023,11042]
===
match
---
operator: = [20786,20787]
operator: = [20489,20490]
===
match
---
name: tis [11885,11888]
name: tis [11588,11591]
===
match
---
trailer [3483,3541]
trailer [3424,3482]
===
match
---
name: TI [29177,29179]
name: TI [28880,28882]
===
match
---
tfpdef [8484,8522]
tfpdef [8187,8225]
===
match
---
name: _state [3361,3367]
name: _state [3302,3308]
===
match
---
trailer [27442,27469]
trailer [27145,27172]
===
match
---
param [8136,8165]
param [7839,7868]
===
match
---
operator: = [5329,5330]
operator: = [5270,5271]
===
match
---
trailer [17107,17112]
trailer [16810,16815]
===
match
---
name: session [7968,7975]
name: session [7671,7678]
===
match
---
param [8262,8302]
param [7965,8005]
===
match
---
operator: } [27399,27400]
operator: } [27102,27103]
===
match
---
atom_expr [6336,6347]
atom_expr [6077,6088]
===
match
---
operator: = [2641,2642]
operator: = [2582,2583]
===
match
---
string: 'dag_id' [3395,3403]
string: 'dag_id' [3336,3344]
===
match
---
name: State [24520,24525]
name: State [24223,24228]
===
match
---
name: dag_id [26293,26299]
name: dag_id [25996,26002]
===
match
---
name: Any [851,854]
name: Any [851,854]
===
match
---
name: unfinished_tasks [15659,15675]
name: unfinished_tasks [15362,15378]
===
match
---
expr_stmt [11659,11694]
expr_stmt [11362,11397]
===
match
---
name: timezone [4780,4788]
name: timezone [4721,4729]
===
match
---
operator: >= [10479,10481]
operator: >= [10182,10184]
===
match
---
name: qry [10549,10552]
name: qry [10252,10255]
===
match
---
fstring_start: f" [11188,11190]
fstring_start: f" [10891,10893]
===
match
---
atom_expr [26630,26640]
atom_expr [26333,26343]
===
match
---
name: qry [10726,10729]
name: qry [10429,10432]
===
match
---
trailer [11470,11474]
trailer [11173,11177]
===
match
---
trailer [4141,4151]
trailer [4082,4092]
===
match
---
param [8394,8418]
param [8097,8121]
===
match
---
atom_expr [10913,10924]
atom_expr [10616,10627]
===
match
---
name: start_date [4168,4178]
name: start_date [4109,4119]
===
match
---
atom_expr [8190,8208]
atom_expr [7893,7911]
===
match
---
simple_stmt [1767,1824]
simple_stmt [1708,1765]
===
match
---
trailer [24364,24368]
trailer [24067,24071]
===
match
---
trailer [16782,16797]
trailer [16485,16500]
===
match
---
atom_expr [25873,25897]
atom_expr [25576,25600]
===
match
---
name: str [8113,8116]
name: str [7816,7819]
===
match
---
and_test [16223,16313]
and_test [15926,16016]
===
match
---
operator: } [24435,24436]
operator: } [24138,24139]
===
match
---
name: qry [10902,10905]
name: qry [10605,10608]
===
match
---
atom_expr [12417,12429]
atom_expr [12120,12132]
===
match
---
trailer [5689,5691]
trailer [5630,5632]
===
match
---
simple_stmt [11181,11232]
simple_stmt [10884,10935]
===
match
---
string: """         Returns the task instance specified by task_id for this dag run          :param task_id: the task id         :type task_id: str         :param session: Sqlalchemy ORM Session         :type session: Session         """ [12439,12668]
string: """         Returns the task instance specified by task_id for this dag run          :param task_id: the task id         :type task_id: str         :param session: Sqlalchemy ORM Session         :type session: Session         """ [12142,12371]
===
match
---
trailer [12060,12066]
trailer [11763,11769]
===
match
---
name: filter [10199,10205]
name: filter [9902,9908]
===
match
---
trailer [30878,30885]
trailer [30581,30588]
===
match
---
argument [18357,18381]
argument [18060,18084]
===
match
---
trailer [7581,7586]
trailer [7284,7289]
===
match
---
name: Optional [13234,13242]
name: Optional [12937,12945]
===
match
---
name: List [21400,21404]
name: List [21103,21107]
===
match
---
atom [11989,12012]
atom [11692,11715]
===
match
---
dotted_name [1278,1292]
dotted_name [1219,1233]
===
match
---
trailer [4278,4283]
trailer [4219,4224]
===
match
---
operator: = [4248,4249]
operator: = [4189,4190]
===
match
---
operator: = [16616,16617]
operator: = [16319,16320]
===
match
---
operator: = [18227,18228]
operator: = [17930,17931]
===
match
---
dotted_name [1718,1731]
dotted_name [1659,1672]
===
match
---
name: session [17298,17305]
name: session [17001,17008]
===
match
---
trailer [12711,12715]
trailer [12414,12418]
===
match
---
name: dag [26630,26633]
name: dag [26333,26336]
===
match
---
trailer [12205,12209]
trailer [11908,11912]
===
match
---
name: State [30608,30613]
name: State [30311,30316]
===
match
---
atom_expr [26074,26084]
atom_expr [25777,25787]
===
match
---
tfpdef [8394,8410]
tfpdef [8097,8113]
===
match
---
trailer [19952,19967]
trailer [19655,19670]
===
match
---
name: dag_id [18273,18279]
name: dag_id [17976,17982]
===
match
---
arglist [10354,10394]
arglist [10057,10097]
===
match
---
atom_expr [2979,2994]
atom_expr [2920,2935]
===
match
---
suite [24219,24317]
suite [23922,24020]
===
match
---
atom [13806,14120]
atom [13509,13823]
===
match
---
suite [10033,10243]
suite [9736,9946]
===
match
---
simple_stmt [1119,1172]
simple_stmt [1060,1113]
===
match
---
name: query [21141,21146]
name: query [20844,20849]
===
match
---
number: 0 [30275,30276]
number: 0 [29978,29979]
===
match
---
fstring_string: task_instance_created- [26976,26998]
fstring_string: task_instance_created- [26679,26701]
===
match
---
name: cls [28816,28819]
name: cls [28519,28522]
===
match
---
trailer [10463,10478]
trailer [10166,10181]
===
match
---
atom_expr [4734,4749]
atom_expr [4675,4690]
===
match
---
expr_stmt [30786,31383]
expr_stmt [30489,31086]
===
match
---
suite [13463,13514]
suite [13166,13217]
===
match
---
param [21348,21375]
param [21051,21078]
===
match
---
name: utils [1978,1983]
name: utils [1919,1924]
===
match
---
simple_stmt [30321,30667]
simple_stmt [30024,30370]
===
match
---
name: qry [9969,9972]
name: qry [9672,9675]
===
match
---
annassign [2300,2306]
annassign [2241,2247]
===
match
---
name: task_concurrency [15625,15641]
name: task_concurrency [15328,15344]
===
match
---
name: ready_tis [21274,21283]
name: ready_tis [20977,20986]
===
match
---
name: dag_id [5201,5207]
name: dag_id [5142,5148]
===
match
---
name: first_start_date [23760,23776]
name: first_start_date [23463,23479]
===
match
---
operator: = [23632,23633]
operator: = [23335,23336]
===
match
---
simple_stmt [19917,20013]
simple_stmt [19620,19716]
===
match
---
trailer [15534,15550]
trailer [15237,15253]
===
match
---
atom_expr [15614,15676]
atom_expr [15317,15379]
===
match
---
atom_expr [18932,18940]
atom_expr [18635,18643]
===
match
---
operator: = [25590,25591]
operator: = [25293,25294]
===
match
---
name: verify_integrity [25164,25180]
name: verify_integrity [24867,24883]
===
match
---
except_clause [19276,19295]
except_clause [18979,18998]
===
match
---
name: t [19622,19623]
name: t [19325,19326]
===
match
---
trailer [8544,8554]
trailer [8247,8257]
===
match
---
trailer [18589,18642]
trailer [18292,18345]
===
match
---
trailer [23646,23657]
trailer [23349,23360]
===
match
---
if_stmt [13442,13514]
if_stmt [13145,13217]
===
match
---
atom_expr [24992,25003]
atom_expr [24695,24706]
===
match
---
trailer [17405,17424]
trailer [17108,17127]
===
match
---
name: task_ids [25688,25696]
name: task_ids [25391,25399]
===
match
---
if_stmt [11789,12189]
if_stmt [11492,11892]
===
match
---
atom_expr [8232,8245]
atom_expr [7935,7948]
===
match
---
trailer [2809,2822]
trailer [2750,2763]
===
match
---
suite [4750,4833]
suite [4691,4774]
===
match
---
name: true_delay [24093,24103]
name: true_delay [23796,23806]
===
match
---
atom_expr [28740,28792]
atom_expr [28443,28495]
===
match
---
name: DagRun [28277,28283]
name: DagRun [27980,27986]
===
match
---
expr_stmt [9807,9864]
expr_stmt [9510,9567]
===
match
---
trailer [3277,3281]
trailer [3218,3222]
===
match
---
trailer [5187,5362]
trailer [5128,5303]
===
match
---
name: State [26424,26429]
name: State [26127,26132]
===
match
---
argument [17023,17084]
argument [16726,16787]
===
match
---
atom_expr [12201,12209]
atom_expr [11904,11912]
===
match
---
name: TI [20411,20413]
name: TI [20114,20116]
===
match
---
arglist [7383,7439]
arglist [7086,7142]
===
match
---
simple_stmt [28870,29102]
simple_stmt [28573,28805]
===
match
---
argument [16676,16701]
argument [16379,16404]
===
match
---
operator: = [9815,9816]
operator: = [9518,9519]
===
match
---
trailer [13861,14037]
trailer [13564,13740]
===
match
---
name: schedulable_tis [15854,15869]
name: schedulable_tis [15557,15572]
===
match
---
operator: , [892,893]
operator: , [892,893]
===
match
---
atom_expr [15104,15157]
atom_expr [14807,14860]
===
match
---
trailer [28774,28792]
trailer [28477,28495]
===
match
---
name: unfinished_tasks [17739,17755]
name: unfinished_tasks [17442,17458]
===
match
---
atom [28163,28420]
atom [27866,28123]
===
match
---
name: t [19628,19629]
name: t [19331,19332]
===
match
---
operator: , [9846,9847]
operator: , [9549,9550]
===
match
---
trailer [18103,18127]
trailer [17806,17830]
===
match
---
name: tis [19560,19563]
name: tis [19263,19266]
===
match
---
name: creating_job_id [4983,4998]
name: creating_job_id [4924,4939]
===
match
---
atom_expr [7513,7531]
atom_expr [7216,7234]
===
match
---
tfpdef [14204,14227]
tfpdef [13907,13930]
===
match
---
if_stmt [11827,12109]
if_stmt [11530,11812]
===
match
---
trailer [17243,17259]
trailer [16946,16962]
===
match
---
name: ti [23571,23573]
name: ti [23274,23276]
===
match
---
expr_stmt [25688,25704]
expr_stmt [25391,25407]
===
match
---
name: schedulable_tis [19917,19932]
name: schedulable_tis [19620,19635]
===
match
---
operator: , [19986,19987]
operator: , [19689,19690]
===
match
---
operator: = [4321,4322]
operator: = [4262,4263]
===
match
---
name: filter [7467,7473]
name: filter [7170,7176]
===
match
---
param [6539,6556]
param [6242,6259]
===
match
---
name: cls [7287,7290]
name: cls [6990,6993]
===
match
---
operator: == [11505,11507]
operator: == [11208,11210]
===
match
---
decorated [25139,27598]
decorated [24842,27301]
===
match
---
string: 'run_id' [3459,3467]
string: 'run_id' [3400,3408]
===
match
---
operator: , [20152,20153]
operator: , [19855,19856]
===
match
---
trailer [23733,23744]
trailer [23436,23447]
===
match
---
operator: , [11519,11520]
operator: , [11222,11223]
===
match
---
atom_expr [15618,15641]
atom_expr [15321,15344]
===
match
---
operator: == [7297,7299]
operator: == [7000,7002]
===
match
---
decorator [14126,14143]
decorator [13829,13846]
===
match
---
arglist [24253,24315]
arglist [23956,24018]
===
match
---
name: Stats [15104,15109]
name: Stats [14807,14812]
===
match
---
name: self [3975,3979]
name: self [3916,3920]
===
match
---
fstring_expr [13071,13077]
fstring_expr [12774,12780]
===
match
---
atom_expr [12168,12187]
atom_expr [11871,11890]
===
match
---
trailer [20410,20414]
trailer [20113,20117]
===
match
---
trailer [4315,4320]
trailer [4256,4261]
===
match
---
atom_expr [4859,4873]
atom_expr [4800,4814]
===
match
---
name: execution_date [10464,10478]
name: execution_date [10167,10181]
===
match
---
string: 'Marking run %s failed' [16342,16365]
string: 'Marking run %s failed' [16045,16068]
===
match
---
string: '<DagRun {dag_id} @ {execution_date}: {run_id}, externally triggered: {external_trigger}>' [5080,5170]
string: '<DagRun {dag_id} @ {execution_date}: {run_id}, externally triggered: {external_trigger}>' [5021,5111]
===
match
---
funcdef [13147,13615]
funcdef [12850,13318]
===
match
---
operator: = [18376,18377]
operator: = [18079,18080]
===
match
---
trailer [2912,2919]
trailer [2853,2860]
===
match
---
return_stmt [28870,29101]
return_stmt [28573,28804]
===
match
---
name: DagModel [7409,7417]
name: DagModel [7112,7120]
===
match
---
operator: == [13351,13353]
operator: == [13054,13056]
===
match
---
name: sql [1289,1292]
name: sql [1230,1233]
===
match
---
name: in_ [12067,12070]
name: in_ [11770,11773]
===
match
---
trailer [17552,17567]
trailer [17255,17270]
===
match
---
atom_expr [10317,10396]
atom_expr [10020,10099]
===
match
---
operator: = [15277,15278]
operator: = [14980,14981]
===
match
---
arglist [28728,28792]
arglist [28431,28495]
===
match
---
atom_expr [10732,10783]
atom_expr [10435,10486]
===
match
---
fstring_string: task_restored_to_dag. [26608,26629]
fstring_string: task_restored_to_dag. [26311,26332]
===
match
---
name: str [12384,12387]
name: str [12087,12090]
===
match
---
return_stmt [12304,12320]
return_stmt [12007,12023]
===
match
---
string: 'success' [17640,17649]
string: 'success' [17343,17352]
===
match
---
suite [29948,30258]
suite [29651,29961]
===
match
---
operator: = [8411,8412]
operator: = [8114,8115]
===
match
---
name: dag_id [13344,13350]
name: dag_id [13047,13053]
===
match
---
operator: , [27649,27650]
operator: , [27352,27353]
===
match
---
name: str [6526,6529]
name: str [6229,6232]
===
match
---
name: fallback [3929,3937]
name: fallback [3870,3878]
===
match
---
argument [17589,17614]
argument [17292,17317]
===
match
---
operator: , [3368,3369]
operator: , [3309,3310]
===
match
---
name: has_on_failure_callback [16566,16589]
name: has_on_failure_callback [16269,16292]
===
match
---
name: DagRun [13491,13497]
name: DagRun [13194,13200]
===
match
---
name: session [30348,30355]
name: session [30051,30058]
===
match
---
string: "@once" [23371,23378]
string: "@once" [23074,23081]
===
match
---
name: flush [27188,27193]
name: flush [26891,26896]
===
match
---
name: self [4734,4738]
name: self [4675,4679]
===
match
---
suite [11712,12189]
suite [11415,11892]
===
match
---
expr_stmt [4500,4520]
expr_stmt [4441,4461]
===
match
---
name: datetime [8458,8466]
name: datetime [8161,8169]
===
match
---
name: Optional [3997,4005]
name: Optional [3938,3946]
===
match
---
name: self [5786,5790]
name: self [5727,5731]
===
match
---
comparison [12762,12802]
comparison [12465,12505]
===
match
---
name: dep_context [1615,1626]
name: dep_context [1556,1567]
===
match
---
expr_stmt [21121,21175]
expr_stmt [20824,20878]
===
match
---
suite [24736,24848]
suite [24439,24551]
===
match
---
name: self [25592,25596]
name: self [25295,25299]
===
match
---
name: Optional [4233,4241]
name: Optional [4174,4182]
===
match
---
name: self [5435,5439]
name: self [5376,5380]
===
match
---
suite [10804,10859]
suite [10507,10562]
===
match
---
operator: , [18854,18855]
operator: , [18557,18558]
===
match
---
trailer [30998,31012]
trailer [30701,30715]
===
match
---
name: true_delay [24188,24198]
name: true_delay [23891,23901]
===
match
---
trailer [21039,21054]
trailer [20742,20757]
===
match
---
simple_stmt [10896,10953]
simple_stmt [10599,10656]
===
match
---
operator: , [3742,3743]
operator: , [3683,3684]
===
match
---
name: execution_date [14067,14081]
name: execution_date [13770,13784]
===
match
---
name: Column [2871,2877]
name: Column [2812,2818]
===
match
---
name: reverse [23659,23666]
name: reverse [23362,23369]
===
match
---
operator: < [13947,13948]
operator: < [13650,13651]
===
match
---
trailer [19155,19160]
trailer [18858,18863]
===
match
---
comparison [13337,13365]
comparison [13040,13068]
===
match
---
annassign [2327,2337]
annassign [2268,2278]
===
match
---
name: changed_tis [20574,20585]
name: changed_tis [20277,20288]
===
match
---
operator: , [15933,15934]
operator: , [15636,15637]
===
match
---
name: end_date [24873,24881]
name: end_date [24576,24584]
===
match
---
name: TI [30876,30878]
name: TI [30579,30581]
===
match
---
name: Stats [25070,25075]
name: Stats [24773,24778]
===
match
---
atom_expr [16562,16589]
atom_expr [16265,16292]
===
match
---
trailer [13407,13422]
trailer [13110,13125]
===
match
---
simple_stmt [10189,10243]
simple_stmt [9892,9946]
===
match
---
trailer [29176,29180]
trailer [28879,28883]
===
match
---
name: provide_session [8042,8057]
name: provide_session [7745,7760]
===
match
---
subscriptlist [8103,8117]
subscriptlist [7806,7820]
===
match
---
name: filter [13551,13557]
name: filter [13254,13260]
===
match
---
trailer [7852,7867]
trailer [7555,7570]
===
match
---
operator: , [17511,17512]
operator: , [17214,17215]
===
match
---
name: Column [2803,2809]
name: Column [2744,2750]
===
match
---
trailer [10108,10115]
trailer [9811,9818]
===
match
---
name: get_state [5372,5381]
name: get_state [5313,5322]
===
match
---
operator: - [24882,24883]
operator: - [24585,24586]
===
match
---
name: BACKFILL_JOB [7334,7346]
name: BACKFILL_JOB [7037,7049]
===
match
---
name: TI [20326,20328]
name: TI [20029,20031]
===
match
---
argument [16865,16883]
argument [16568,16586]
===
match
---
name: Integer [2986,2993]
name: Integer [2927,2934]
===
match
---
name: DR [10116,10118]
name: DR [9819,9821]
===
match
---
simple_stmt [2088,2123]
simple_stmt [2029,2064]
===
match
---
number: 1 [26303,26304]
number: 1 [26006,26007]
===
match
---
name: timezone [2769,2777]
name: timezone [2710,2718]
===
match
---
name: schedulable_ti_ids [30220,30238]
name: schedulable_ti_ids [29923,29941]
===
match
---
operator: , [12760,12761]
operator: , [12463,12464]
===
match
---
trailer [19641,19647]
trailer [19344,19350]
===
match
---
trailer [13900,13907]
trailer [13603,13610]
===
match
---
name: unfinished_tasks [20166,20182]
name: unfinished_tasks [19869,19885]
===
match
---
atom_expr [3997,4010]
atom_expr [3938,3951]
===
match
---
operator: == [11551,11553]
operator: == [11254,11256]
===
match
---
name: TI [30411,30413]
name: TI [30114,30116]
===
match
---
expr_stmt [19463,19487]
expr_stmt [19166,19190]
===
match
---
name: dag_id [12754,12760]
name: dag_id [12457,12463]
===
match
---
name: TI [11380,11382]
name: TI [11083,11085]
===
match
---
operator: = [23666,23667]
operator: = [23369,23370]
===
match
---
atom_expr [25699,25704]
atom_expr [25402,25407]
===
match
---
atom_expr [12250,12295]
atom_expr [11953,11998]
===
match
---
simple_stmt [16464,16545]
simple_stmt [16167,16248]
===
match
---
name: execution_date [13954,13968]
name: execution_date [13657,13671]
===
match
---
file_input [787,31406]
file_input [787,31109]
===
match
---
param [4337,4368]
param [4278,4309]
===
match
---
operator: = [20807,20808]
operator: = [20510,20511]
===
match
---
param [20339,20364]
param [20042,20067]
===
match
---
atom_expr [28971,29057]
atom_expr [28674,28760]
===
match
---
name: ti [23644,23646]
name: ti [23347,23349]
===
match
---
name: schedulable_ti_ids [30534,30552]
name: schedulable_ti_ids [30237,30255]
===
match
---
name: List [20321,20325]
name: List [20024,20028]
===
match
---
string: 'execution_date' [28775,28791]
string: 'execution_date' [28478,28494]
===
match
---
parameters [14163,14240]
parameters [13866,13943]
===
match
---
name: tis [25586,25589]
name: tis [25289,25292]
===
match
---
atom [28877,29101]
atom [28580,28804]
===
match
---
name: fresh_tis [21247,21256]
name: fresh_tis [20950,20959]
===
match
---
name: airflow [1317,1324]
name: airflow [1258,1265]
===
match
---
operator: == [30421,30423]
operator: == [30124,30126]
===
match
---
arglist [3070,3096]
arglist [3011,3037]
===
match
---
trailer [7529,7531]
trailer [7232,7234]
===
match
---
name: execute_callbacks [16429,16446]
name: execute_callbacks [16132,16149]
===
match
---
trailer [5806,5816]
trailer [5747,5757]
===
match
---
operator: , [3514,3515]
operator: , [3455,3456]
===
match
---
name: TI [2281,2283]
name: TI [2222,2224]
===
match
---
trailer [7586,7588]
trailer [7289,7291]
===
match
---
name: callback [17377,17385]
name: callback [17080,17088]
===
match
---
name: self [18014,18018]
name: self [17717,17721]
===
match
---
atom_expr [15279,15287]
atom_expr [14982,14990]
===
match
---
parameters [29144,29206]
parameters [28847,28909]
===
match
---
operator: = [5672,5673]
operator: = [5613,5614]
===
match
---
operator: , [31184,31185]
operator: , [30887,30888]
===
match
---
atom_expr [28816,28826]
atom_expr [28519,28529]
===
match
---
funcdef [6469,8018]
funcdef [6172,7721]
===
match
---
atom_expr [26963,27022]
atom_expr [26666,26725]
===
match
---
trailer [18173,18192]
trailer [17876,17895]
===
match
---
atom_expr [10105,10154]
atom_expr [9808,9857]
===
match
---
expr_stmt [10896,10952]
expr_stmt [10599,10655]
===
match
---
simple_stmt [29890,29914]
simple_stmt [29593,29617]
===
match
---
import_from [1396,1457]
import_from [1337,1398]
===
match
---
trailer [13833,13841]
trailer [13536,13544]
===
match
---
name: SHUTDOWN [19068,19076]
name: SHUTDOWN [18771,18779]
===
match
---
atom_expr [14060,14088]
atom_expr [13763,13791]
===
match
---
atom_expr [4500,4511]
atom_expr [4441,4452]
===
match
---
name: staticmethod [8024,8036]
name: staticmethod [7727,7739]
===
match
---
or_test [4672,4682]
or_test [4613,4623]
===
match
---
if_stmt [21082,21258]
if_stmt [20785,20961]
===
match
---
testlist [21274,21296]
testlist [20977,20999]
===
match
---
atom_expr [7979,8007]
atom_expr [7682,7710]
===
match
---
name: Column [3229,3235]
name: Column [3170,3176]
===
match
---
name: NamedTuple [872,882]
name: NamedTuple [872,882]
===
match
---
expr_stmt [4471,4491]
expr_stmt [4412,4432]
===
match
---
trailer [21146,21150]
trailer [20849,20853]
===
match
---
trailer [13049,13095]
trailer [12752,12798]
===
match
---
and_test [10254,10297]
and_test [9957,10000]
===
match
---
expr_stmt [15497,15577]
expr_stmt [15200,15280]
===
match
---
atom_expr [9903,9937]
atom_expr [9606,9640]
===
match
---
annassign [2244,2254]
annassign [2185,2195]
===
match
---
name: task [26812,26816]
name: task [26515,26519]
===
match
---
operator: , [21880,21881]
operator: , [21583,21584]
===
match
---
operator: -> [12414,12416]
operator: -> [12117,12119]
===
match
---
name: ti_deps [1607,1614]
name: ti_deps [1548,1555]
===
match
---
atom_expr [24263,24273]
atom_expr [23966,23976]
===
match
---
operator: = [16535,16536]
operator: = [16238,16239]
===
match
---
name: Tuple [14244,14249]
name: Tuple [13947,13952]
===
match
---
expr_stmt [19917,20012]
expr_stmt [19620,19715]
===
match
---
name: qry [10817,10820]
name: qry [10520,10523]
===
match
---
argument [21799,21826]
argument [21502,21529]
===
match
---
operator: = [15078,15079]
operator: = [14781,14782]
===
match
---
simple_stmt [26666,26688]
simple_stmt [26369,26391]
===
match
---
name: query [28185,28190]
name: query [27888,27893]
===
match
---
atom_expr [8504,8522]
atom_expr [8207,8225]
===
match
---
annassign [20464,20479]
annassign [20167,20182]
===
match
---
name: self [4960,4964]
name: self [4901,4905]
===
match
---
operator: , [7975,7976]
operator: , [7678,7679]
===
match
---
name: conf [1375,1379]
name: conf [1316,1320]
===
match
---
name: qry [9903,9906]
name: qry [9606,9609]
===
match
---
param [22117,22129]
param [21820,21832]
===
match
---
parameters [28589,28608]
parameters [28292,28311]
===
match
---
suite [12130,12189]
suite [11833,11892]
===
match
---
simple_stmt [17994,18083]
simple_stmt [17697,17786]
===
match
---
trailer [15466,15483]
trailer [15169,15186]
===
match
---
tfpdef [3989,4010]
tfpdef [3930,3951]
===
match
---
name: self [13949,13953]
name: self [13652,13656]
===
match
---
name: execute_callbacks [14204,14221]
name: execute_callbacks [13907,13924]
===
match
---
name: dag [23316,23319]
name: dag [23019,23022]
===
match
---
name: TI [30598,30600]
name: TI [30301,30303]
===
match
---
name: self [17548,17552]
name: self [17251,17255]
===
match
---
trailer [26078,26084]
trailer [25781,25787]
===
match
---
fstring [15116,15156]
fstring [14819,14859]
===
match
---
simple_stmt [19313,19447]
simple_stmt [19016,19150]
===
match
---
trailer [13827,13833]
trailer [13530,13536]
===
match
---
if_stmt [7087,7166]
if_stmt [6790,6869]
===
match
---
argument [16252,16312]
argument [15955,16015]
===
match
---
atom_expr [30598,30606]
atom_expr [30301,30309]
===
match
---
name: utcnow [5683,5689]
name: utcnow [5624,5630]
===
match
---
name: qry [9897,9900]
name: qry [9600,9603]
===
match
---
tfpdef [11072,11096]
tfpdef [10775,10799]
===
match
---
name: changed_tis [19934,19945]
name: changed_tis [19637,19648]
===
match
---
name: Optional [14260,14268]
name: Optional [13963,13971]
===
match
---
name: State [17040,17045]
name: State [16743,16748]
===
match
---
trailer [24198,24212]
trailer [23901,23915]
===
match
---
comparison [26390,26406]
comparison [26093,26109]
===
match
---
name: Session [13690,13697]
name: Session [13393,13400]
===
match
---
name: tis [19180,19183]
name: tis [18883,18886]
===
match
---
atom_expr [24952,25016]
atom_expr [24655,24719]
===
match
---
operator: = [19619,19620]
operator: = [19322,19323]
===
match
---
operator: = [13198,13199]
operator: = [12901,12902]
===
match
---
name: qry [10637,10640]
name: qry [10340,10343]
===
match
---
name: UniqueConstraint [3378,3394]
name: UniqueConstraint [3319,3335]
===
match
---
trailer [4863,4873]
trailer [4804,4814]
===
match
---
trailer [20704,20725]
trailer [20407,20428]
===
match
---
name: qry [10311,10314]
name: qry [10014,10017]
===
match
---
atom_expr [12736,12745]
atom_expr [12439,12448]
===
match
---
name: last_scheduling_decision [3516,3540]
name: last_scheduling_decision [3457,3481]
===
match
---
operator: , [1206,1207]
operator: , [1147,1148]
===
match
---
atom_expr [19474,19487]
atom_expr [19177,19190]
===
match
---
atom_expr [31152,31165]
atom_expr [30855,30868]
===
match
---
suite [12430,12858]
suite [12133,12561]
===
match
---
suite [11947,12109]
suite [11650,11812]
===
match
---
simple_stmt [25070,25134]
simple_stmt [24773,24837]
===
match
---
name: property [5777,5785]
name: property [5718,5726]
===
match
---
not_test [7775,7811]
not_test [7478,7514]
===
match
---
atom_expr [2595,2603]
atom_expr [2536,2544]
===
match
---
name: state [4696,4701]
name: state [4637,4642]
===
match
---
comp_op [26930,26936]
comp_op [26633,26639]
===
match
---
name: finished_tasks [20213,20227]
name: finished_tasks [19916,19930]
===
match
---
atom_expr [30424,30435]
atom_expr [30127,30138]
===
match
---
operator: = [19546,19547]
operator: = [19249,19250]
===
match
---
name: self [18316,18320]
name: self [18019,18023]
===
match
---
for_stmt [19170,19520]
for_stmt [18873,19223]
===
match
---
name: dummy_ti_ids [30154,30166]
name: dummy_ti_ids [29857,29869]
===
match
---
name: TI [12058,12060]
name: TI [11761,11763]
===
match
---
fstring_expr [15142,15155]
fstring_expr [14845,14858]
===
match
---
decorator [28549,28566]
decorator [28252,28269]
===
match
---
simple_stmt [30786,31384]
simple_stmt [30489,31087]
===
match
---
name: expression [1300,1310]
name: expression [1241,1251]
===
match
---
trailer [7787,7811]
trailer [7490,7514]
===
match
---
name: descriptor [5766,5776]
name: descriptor [5707,5717]
===
match
---
name: changed_tis [2289,2300]
name: changed_tis [2230,2241]
===
match
---
suite [11806,12109]
suite [11509,11812]
===
match
---
arglist [20743,20857]
arglist [20446,20560]
===
match
---
name: self [5248,5252]
name: self [5189,5193]
===
match
---
name: datetime [11088,11096]
name: datetime [10791,10799]
===
match
---
name: dag_id [30429,30435]
name: dag_id [30132,30138]
===
match
---
name: cls [7655,7658]
name: cls [7358,7361]
===
match
---
trailer [15109,15115]
trailer [14812,14818]
===
match
---
atom_expr [4233,4247]
atom_expr [4174,4188]
===
match
---
name: all [12315,12318]
name: all [12018,12021]
===
match
---
name: desc [14082,14086]
name: desc [13785,13789]
===
match
---
name: session [20373,20380]
name: session [20076,20083]
===
match
---
trailer [27057,27072]
trailer [26760,26775]
===
match
---
operator: = [17305,17306]
operator: = [17008,17009]
===
match
---
name: session [13681,13688]
name: session [13384,13391]
===
match
---
operator: = [18267,18268]
operator: = [17970,17971]
===
match
---
operator: = [9757,9758]
operator: = [9460,9461]
===
match
---
name: set_state [17165,17174]
name: set_state [16868,16877]
===
match
---
trailer [16693,16701]
trailer [16396,16404]
===
match
---
name: dag [13010,13013]
name: dag [12713,12716]
===
match
---
name: tis [12157,12160]
name: tis [11860,11863]
===
match
---
name: foreign_keys [3705,3717]
name: foreign_keys [3646,3658]
===
match
---
atom_expr [7899,8017]
atom_expr [7602,7720]
===
match
---
sync_comp_for [16093,16137]
sync_comp_for [15796,15840]
===
match
---
tfpdef [6565,6590]
tfpdef [6268,6293]
===
match
---
string: 'Failed to record duration of %s: end_date is not set.' [24766,24821]
string: 'Failed to record duration of %s: end_date is not set.' [24469,24524]
===
match
---
expr_stmt [26666,26687]
expr_stmt [26369,26390]
===
match
---
sync_comp_for [19624,19665]
sync_comp_for [19327,19368]
===
match
---
fstring [26264,26301]
fstring [25967,26004]
===
match
---
atom_expr [15177,15191]
atom_expr [14880,14894]
===
match
---
simple_stmt [3102,3128]
simple_stmt [3043,3069]
===
match
---
trailer [18711,18713]
trailer [18414,18416]
===
match
---
atom_expr [19152,19160]
atom_expr [18855,18863]
===
match
---
simple_stmt [10099,10155]
simple_stmt [9802,9858]
===
match
---
comparison [16110,16137]
comparison [15813,15840]
===
match
---
name: are_runnable_tasks [15811,15829]
name: are_runnable_tasks [15514,15532]
===
match
---
operator: , [4158,4159]
operator: , [4099,4100]
===
match
---
trailer [20957,20961]
trailer [20660,20664]
===
match
---
trailer [13854,13861]
trailer [13557,13564]
===
match
---
suite [12890,13121]
suite [12593,12824]
===
match
---
name: tis [2241,2244]
name: tis [2182,2185]
===
match
---
sync_comp_for [11992,12011]
sync_comp_for [11695,11714]
===
match
---
tfpdef [4300,4320]
tfpdef [4241,4261]
===
match
---
name: unfinished_tasks [16998,17014]
name: unfinished_tasks [16701,16717]
===
match
---
simple_stmt [2688,2720]
simple_stmt [2629,2661]
===
match
---
trailer [17463,17471]
trailer [17166,17174]
===
match
---
decorator [13126,13143]
decorator [12829,12846]
===
match
---
name: unfinished_tasks [15467,15483]
name: unfinished_tasks [15170,15186]
===
match
---
trailer [29085,29089]
trailer [28788,28792]
===
match
---
trailer [17997,18013]
trailer [17700,17716]
===
match
---
operator: = [18966,18967]
operator: = [18669,18670]
===
match
---
name: is_ [12097,12100]
name: is_ [11800,11803]
===
match
---
argument [2899,2919]
argument [2840,2860]
===
match
---
trailer [31118,31126]
trailer [30821,30829]
===
match
---
name: session [5871,5878]
name: session [5812,5819]
===
match
---
name: info [15204,15208]
name: info [14907,14911]
===
match
---
expr_stmt [13313,13433]
expr_stmt [13016,13136]
===
match
---
trailer [14954,14992]
trailer [14657,14695]
===
match
---
name: id [6406,6408]
name: id [6109,6111]
===
match
---
name: session [16536,16543]
name: session [16239,16246]
===
match
---
expr_stmt [18145,18448]
expr_stmt [17848,18151]
===
match
---
operator: , [13679,13680]
operator: , [13382,13383]
===
match
---
trailer [17929,17943]
trailer [17632,17646]
===
match
---
simple_stmt [1458,1503]
simple_stmt [1399,1444]
===
match
---
param [4117,4159]
param [4058,4100]
===
match
---
name: int [4443,4446]
name: int [4384,4387]
===
match
---
name: self [5404,5408]
name: self [5345,5349]
===
match
---
trailer [23099,23105]
trailer [22802,22808]
===
match
---
atom_expr [26289,26299]
atom_expr [25992,26002]
===
match
---
arglist [19104,19160]
arglist [18807,18863]
===
match
---
trailer [2601,2603]
trailer [2542,2544]
===
match
---
name: query [9789,9794]
name: query [9492,9497]
===
match
---
expr_stmt [10817,10858]
expr_stmt [10520,10561]
===
match
---
operator: = [16777,16778]
operator: = [16480,16481]
===
match
---
name: List [2329,2333]
name: List [2270,2274]
===
match
---
name: FAILED [25050,25056]
name: FAILED [24753,24759]
===
match
---
name: tis_filter [21024,21034]
name: tis_filter [20727,20737]
===
match
---
number: 50 [2894,2896]
number: 50 [2835,2837]
===
match
---
operator: , [864,865]
operator: , [864,865]
===
match
---
operator: , [3679,3680]
operator: , [3620,3621]
===
match
---
arglist [30876,31013]
arglist [30579,30716]
===
match
---
atom [16038,16069]
atom [15741,15772]
===
match
---
name: tis_filter [21158,21168]
name: tis_filter [20861,20871]
===
match
---
trailer [28840,28849]
trailer [28543,28552]
===
match
---
name: logging_mixin [1790,1803]
name: logging_mixin [1731,1744]
===
match
---
atom [30330,30666]
atom [30033,30369]
===
match
---
trailer [4533,4548]
trailer [4474,4489]
===
match
---
name: get_task_instance [12351,12368]
name: get_task_instance [12054,12071]
===
match
---
name: DagRun [7846,7852]
name: DagRun [7549,7555]
===
match
---
suite [28627,29102]
suite [28330,28805]
===
match
---
argument [20743,20823]
argument [20446,20526]
===
match
---
name: self [18546,18550]
name: self [18249,18253]
===
match
---
name: execution_date [4117,4131]
name: execution_date [4058,4072]
===
match
---
and_test [17739,17833]
and_test [17442,17536]
===
match
---
name: exceptions [1409,1419]
name: exceptions [1350,1360]
===
match
---
name: configuration [1354,1367]
name: configuration [1295,1308]
===
match
---
trailer [18736,18742]
trailer [18439,18445]
===
match
---
name: DagModel [7069,7077]
name: DagModel [6772,6780]
===
match
---
expr_stmt [3304,3548]
expr_stmt [3245,3489]
===
match
---
operator: = [19946,19947]
operator: = [19649,19650]
===
match
---
trailer [10133,10137]
trailer [9836,9840]
===
match
---
name: log [27251,27254]
name: log [26954,26957]
===
match
---
name: self [13005,13009]
name: self [12708,12712]
===
match
---
atom_expr [31223,31240]
atom_expr [30926,30943]
===
match
---
simple_stmt [27039,27074]
simple_stmt [26742,26777]
===
match
---
atom_expr [10902,10952]
atom_expr [10605,10655]
===
match
---
name: getint [3848,3854]
name: getint [3789,3795]
===
match
---
atom_expr [30478,30497]
atom_expr [30181,30200]
===
match
---
name: task_dict [26777,26786]
name: task_dict [26480,26489]
===
match
---
name: qry [10450,10453]
name: qry [10153,10156]
===
match
---
operator: = [23703,23704]
operator: = [23406,23407]
===
match
---
name: sqlalchemy [1235,1245]
name: sqlalchemy [1176,1186]
===
match
---
name: dag [27365,27368]
name: dag [27068,27071]
===
match
---
simple_stmt [1273,1311]
simple_stmt [1214,1252]
===
match
---
trailer [28490,28499]
trailer [28193,28202]
===
match
---
atom_expr [11371,11383]
atom_expr [11074,11086]
===
match
---
name: state [26079,26084]
name: state [25782,25787]
===
match
---
atom_expr [21202,21257]
atom_expr [20905,20960]
===
match
---
name: Iterable [29168,29176]
name: Iterable [28871,28879]
===
match
---
name: err [27229,27232]
name: err [26932,26935]
===
match
---
name: self [24749,24753]
name: self [24452,24456]
===
match
---
atom [9817,9825]
atom [9520,9528]
===
match
---
operator: , [26572,26573]
operator: , [26275,26276]
===
match
---
name: _state [5568,5574]
name: _state [5509,5515]
===
match
---
name: _are_premature_tis [15898,15916]
name: _are_premature_tis [15601,15619]
===
match
---
dotted_name [1599,1626]
dotted_name [1540,1567]
===
match
---
operator: , [8301,8302]
operator: , [8004,8005]
===
match
---
name: self [16327,16331]
name: self [16030,16034]
===
match
---
decorated [13620,14121]
decorated [13323,13824]
===
match
---
comparison [11676,11693]
comparison [11379,11396]
===
match
---
trailer [28927,29072]
trailer [28630,28775]
===
match
---
name: session [7960,7967]
name: session [7663,7670]
===
match
---
name: Index [3478,3483]
name: Index [3419,3424]
===
match
---
trailer [7932,7938]
trailer [7635,7641]
===
match
---
name: str [27260,27263]
name: str [26963,26966]
===
match
---
name: none_depends_on_past [15714,15734]
name: none_depends_on_past [15417,15437]
===
match
---
expr_stmt [24857,24899]
expr_stmt [24560,24602]
===
match
---
operator: , [20002,20003]
operator: , [19705,19706]
===
match
---
name: taskinstance [1523,1535]
name: taskinstance [1464,1476]
===
match
---
string: """         Returns the Dag associated with this DagRun.          :return: DAG         """ [12899,12989]
string: """         Returns the Dag associated with this DagRun.          :return: DAG         """ [12602,12692]
===
match
---
operator: = [17499,17500]
operator: = [17202,17203]
===
match
---
expr_stmt [3806,3947]
expr_stmt [3747,3888]
===
match
---
name: tis [11891,11894]
name: tis [11594,11597]
===
match
---
expr_stmt [20944,20974]
expr_stmt [20647,20677]
===
match
---
name: dag [26773,26776]
name: dag [26476,26479]
===
match
---
suite [9884,9938]
suite [9587,9641]
===
match
---
name: dag_id [15148,15154]
name: dag_id [14851,14857]
===
match
---
tfpdef [21348,21374]
tfpdef [21051,21077]
===
match
---
atom_expr [3571,3800]
atom_expr [3512,3741]
===
match
---
name: provide_session [12327,12342]
name: provide_session [12030,12045]
===
match
---
name: declared_attr [1158,1171]
name: declared_attr [1099,1112]
===
match
---
trailer [30238,30245]
trailer [29941,29948]
===
match
---
name: session [7693,7700]
name: session [7396,7403]
===
match
---
name: execution_end_date [10279,10297]
name: execution_end_date [9982,10000]
===
match
---
trailer [13576,13606]
trailer [13279,13309]
===
match
---
name: max_number [7122,7132]
name: max_number [6825,6835]
===
match
---
expr_stmt [11451,11584]
expr_stmt [11154,11287]
===
match
---
name: State [19062,19067]
name: State [18765,18770]
===
match
---
trailer [19046,19058]
trailer [18749,18761]
===
match
---
name: execution_date [8174,8188]
name: execution_date [7877,7891]
===
match
---
trailer [17919,17929]
trailer [17622,17632]
===
match
---
operator: = [10448,10449]
operator: = [10151,10152]
===
match
---
trailer [12167,12188]
trailer [11870,11891]
===
match
---
name: provide_session [14127,14142]
name: provide_session [13830,13845]
===
match
---
trailer [24757,24765]
trailer [24460,24468]
===
match
---
atom_expr [19578,19594]
atom_expr [19281,19297]
===
match
---
tfpdef [20373,20389]
tfpdef [20076,20092]
===
match
---
name: duration [31269,31277]
name: duration [30972,30980]
===
match
---
suite [5050,5363]
suite [4991,5304]
===
match
---
name: err [27264,27267]
name: err [26967,26970]
===
match
---
operator: != [21215,21217]
operator: != [20918,20920]
===
match
---
trailer [5023,5025]
trailer [4964,4966]
===
match
---
name: ti [27118,27120]
name: ti [26821,26823]
===
match
---
trailer [31105,31111]
trailer [30808,30814]
===
match
---
parameters [6496,6604]
parameters [6199,6307]
===
match
---
operator: , [12086,12087]
operator: , [11789,11790]
===
match
---
atom_expr [26595,26649]
atom_expr [26298,26352]
===
match
---
trailer [16061,16068]
trailer [15764,15771]
===
match
---
name: flag_upstream_failed [21752,21772]
name: flag_upstream_failed [21455,21475]
===
match
---
name: changed_tis [20488,20499]
name: changed_tis [20191,20202]
===
match
---
trailer [10345,10353]
trailer [10048,10056]
===
match
---
name: callback_requests [16618,16635]
name: callback_requests [16321,16338]
===
match
---
simple_stmt [19504,19520]
simple_stmt [19207,19223]
===
match
---
name: execution_start_date [10410,10430]
name: execution_start_date [10113,10133]
===
match
---
operator: , [31012,31013]
operator: , [30715,30716]
===
match
---
trailer [28898,28904]
trailer [28601,28607]
===
match
---
name: AirflowException [25917,25933]
name: AirflowException [25620,25636]
===
match
---
name: info [15411,15415]
name: info [15114,15118]
===
match
---
name: all [11001,11004]
name: all [10704,10707]
===
match
---
operator: , [2885,2886]
operator: , [2826,2827]
===
match
---
string: """         This is a helper method to emit the true scheduling delay stats, which is defined as         the time when the first task in DAG starts minus the expected DAG run datetime.         This method will be used in the update_state method when the state of the DagRun         is updated to a completed status (either success or failure). The method will find the first         started task within the DAG and calculate the expected DagRun start time (based on         dag.execution_date & dag.schedule_interval), and minus these two values to get the delay.         The emitted data may contains outlier (e.g. when the first task was cleared, so         the second task's start_date will be used), but we can get rid of the outliers         on the stats side through the dashboards tooling built.         Note, the stat will only be emitted if the DagRun is a scheduler triggered one         (i.e. external_trigger is False).         """ [22140,23083]
string: """         This is a helper method to emit the true scheduling delay stats, which is defined as         the time when the first task in DAG starts minus the expected DAG run datetime.         This method will be used in the update_state method when the state of the DagRun         is updated to a completed status (either success or failure). The method will find the first         started task within the DAG and calculate the expected DagRun start time (based on         dag.execution_date & dag.schedule_interval), and minus these two values to get the delay.         The emitted data may contains outlier (e.g. when the first task was cleared, so         the second task's start_date will be used), but we can get rid of the outliers         on the stats side through the dashboards tooling built.         Note, the stat will only be emitted if the DagRun is a scheduler triggered one         (i.e. external_trigger is False).         """ [21843,22786]
===
match
---
atom_expr [16400,16412]
atom_expr [16103,16115]
===
match
---
simple_stmt [787,817]
simple_stmt [787,817]
===
match
---
decorated [28426,28527]
decorated [28129,28230]
===
match
---
string: 'DagRun' [13243,13251]
string: 'DagRun' [12946,12954]
===
match
---
operator: , [6555,6556]
operator: , [6258,6259]
===
match
---
operator: , [20329,20330]
operator: , [20032,20033]
===
match
---
trailer [12260,12295]
trailer [11963,11998]
===
match
---
trailer [16635,16654]
trailer [16338,16357]
===
match
---
name: in_ [10134,10137]
name: in_ [9837,9840]
===
match
---
operator: == [24517,24519]
operator: == [24220,24222]
===
match
---
name: object [2595,2601]
name: object [2536,2542]
===
match
---
simple_stmt [1594,1645]
simple_stmt [1535,1586]
===
match
---
operator: { [24433,24434]
operator: { [24136,24137]
===
match
---
name: first [14103,14108]
name: first [13806,13811]
===
match
---
trailer [9923,9927]
trailer [9626,9630]
===
match
---
trailer [4738,4749]
trailer [4679,4690]
===
match
---
name: incr [26259,26263]
name: incr [25962,25966]
===
match
---
atom_expr [26858,26874]
atom_expr [26561,26577]
===
match
---
operator: , [7950,7951]
operator: , [7653,7654]
===
match
---
name: dag_id [26634,26640]
name: dag_id [26337,26343]
===
match
---
trailer [6413,6416]
trailer [6116,6119]
===
match
---
number: 20 [3938,3940]
number: 20 [3879,3881]
===
match
---
trailer [18231,18239]
trailer [17934,17942]
===
match
---
expr_stmt [3288,3298]
expr_stmt [3229,3239]
===
match
---
argument [21752,21777]
argument [21455,21480]
===
match
---
name: UtcDateTime [3236,3247]
name: UtcDateTime [3177,3188]
===
match
---
name: schedulable_ti_ids [30289,30307]
name: schedulable_ti_ids [29992,30010]
===
match
---
fstring_expr [26288,26300]
fstring_expr [25991,26003]
===
match
---
expr_stmt [5657,5691]
expr_stmt [5598,5632]
===
match
---
atom_expr [12214,12230]
atom_expr [11917,11933]
===
match
---
name: handle_callback [16468,16483]
name: handle_callback [16171,16186]
===
match
---
atom_expr [19419,19428]
atom_expr [19122,19131]
===
match
---
simple_stmt [2827,2858]
simple_stmt [2768,2799]
===
match
---
atom_expr [17500,17511]
atom_expr [17203,17214]
===
match
---
name: self [26490,26494]
name: self [26193,26197]
===
match
---
decorator [12326,12343]
decorator [12029,12046]
===
match
---
name: incr [26969,26973]
name: incr [26672,26676]
===
match
---
simple_stmt [17099,17148]
simple_stmt [16802,16851]
===
match
---
operator: <= [10584,10586]
operator: <= [10287,10289]
===
match
---
name: filter [10647,10653]
name: filter [10350,10356]
===
match
---
name: queued_at [4065,4074]
name: queued_at [4006,4015]
===
match
---
argument [3082,3096]
argument [3023,3037]
===
match
---
name: finished_tasks [20808,20822]
name: finished_tasks [20511,20525]
===
match
---
parameters [8070,8536]
parameters [7773,8239]
===
match
---
name: success [16490,16497]
name: success [16193,16200]
===
match
---
name: run_type [10795,10803]
name: run_type [10498,10506]
===
match
---
name: execution_date [27385,27399]
name: execution_date [27088,27102]
===
match
---
name: filter [10736,10742]
name: filter [10439,10445]
===
match
---
number: 0 [24217,24218]
number: 0 [23920,23921]
===
match
---
operator: == [7425,7427]
operator: == [7128,7130]
===
match
---
operator: @ [8041,8042]
operator: @ [7744,7745]
===
match
---
argument [20841,20856]
argument [20544,20559]
===
match
---
import_from [1965,2021]
import_from [1906,1962]
===
match
---
name: dag_id [28820,28826]
name: dag_id [28523,28529]
===
match
---
trailer [7499,7509]
trailer [7202,7212]
===
match
---
operator: , [24676,24677]
operator: , [24379,24380]
===
match
---
trailer [13598,13603]
trailer [13301,13306]
===
match
---
trailer [15052,15077]
trailer [14755,14780]
===
match
---
name: filter [11895,11901]
name: filter [11598,11604]
===
match
---
name: run_id [9989,9995]
name: run_id [9692,9698]
===
match
---
operator: , [12373,12374]
operator: , [12076,12077]
===
match
---
operator: = [13223,13224]
operator: = [12926,12927]
===
match
---
subscriptlist [14250,14306]
subscriptlist [13953,14009]
===
match
---
trailer [10905,10912]
trailer [10608,10615]
===
match
---
suite [10431,10504]
suite [10134,10207]
===
match
---
name: Stats [24240,24245]
name: Stats [23943,23948]
===
match
---
simple_stmt [2342,2367]
simple_stmt [2283,2308]
===
match
---
param [4264,4291]
param [4205,4232]
===
match
---
operator: , [849,850]
operator: , [849,850]
===
match
---
atom_expr [31103,31111]
atom_expr [30806,30814]
===
match
---
arglist [17260,17313]
arglist [16963,17016]
===
match
---
name: execution_date [18321,18335]
name: execution_date [18024,18038]
===
match
---
name: airflow [1463,1470]
name: airflow [1404,1411]
===
match
---
atom_expr [13234,13252]
atom_expr [12937,12955]
===
match
---
name: utcnow [5551,5557]
name: utcnow [5492,5498]
===
match
---
name: timer [15110,15115]
name: timer [14813,14818]
===
match
---
trailer [4578,4589]
trailer [4519,4530]
===
match
---
name: List [8540,8544]
name: List [8243,8247]
===
match
---
simple_stmt [14317,14873]
simple_stmt [14020,14576]
===
match
---
atom_expr [19567,19574]
atom_expr [19270,19277]
===
match
---
name: Union [901,906]
name: Union [901,906]
===
match
---
decorator [28426,28436]
decorator [28129,28139]
===
match
---
name: dag_id [12739,12745]
name: dag_id [12442,12448]
===
match
---
name: TISchedulingDecision [2131,2151]
name: TISchedulingDecision [2072,2092]
===
match
---
trailer [12046,12053]
trailer [11749,11756]
===
match
---
name: self [4611,4615]
name: self [4552,4556]
===
match
---
name: append [30239,30245]
name: append [29942,29948]
===
match
---
atom_expr [18156,18448]
atom_expr [17859,18151]
===
match
---
operator: , [3940,3941]
operator: , [3881,3882]
===
match
---
name: state [11679,11684]
name: state [11382,11387]
===
match
---
operator: = [10315,10316]
operator: = [10018,10019]
===
match
---
tfpdef [11050,11070]
tfpdef [10753,10773]
===
match
---
dotted_name [2027,2046]
dotted_name [1968,1987]
===
match
---
name: any [21202,21205]
name: any [20905,20908]
===
match
---
argument [17446,17471]
argument [17149,17174]
===
match
---
import_from [2022,2064]
import_from [1963,2005]
===
match
---
atom_expr [17847,17902]
atom_expr [17550,17605]
===
match
---
operator: = [10103,10104]
operator: = [9806,9807]
===
match
---
name: TI [20471,20473]
name: TI [20174,20176]
===
match
---
trailer [19568,19574]
trailer [19271,19277]
===
match
---
operator: , [13204,13205]
operator: , [12907,12908]
===
match
---
fstring_end: " [13093,13094]
fstring_end: " [12796,12797]
===
match
---
name: String [2941,2947]
name: String [2882,2888]
===
match
---
operator: = [15460,15461]
operator: = [15163,15164]
===
match
---
decorator [6452,6465]
decorator [6155,6168]
===
match
---
trailer [10565,10606]
trailer [10268,10309]
===
match
---
atom_expr [11312,11339]
atom_expr [11015,11042]
===
match
---
operator: = [5540,5541]
operator: = [5481,5482]
===
match
---
atom_expr [21055,21072]
atom_expr [20758,20775]
===
match
---
name: finished_tis [23555,23567]
name: finished_tis [23258,23270]
===
match
---
operator: , [21338,21339]
operator: , [21041,21042]
===
match
---
name: self [29145,29149]
name: self [28848,28852]
===
match
---
fstring_end: ' [24302,24303]
fstring_end: ' [24005,24006]
===
match
---
name: datetime [27680,27688]
name: datetime [27383,27391]
===
match
---
trailer [28402,28408]
trailer [28105,28111]
===
match
---
name: ext [1135,1138]
name: ext [1076,1079]
===
match
---
name: airflow [1567,1574]
name: airflow [1508,1515]
===
match
---
trailer [8102,8118]
trailer [7805,7821]
===
match
---
expr_stmt [10549,10606]
expr_stmt [10252,10309]
===
match
---
atom_expr [20406,20414]
atom_expr [20109,20117]
===
match
---
atom [20444,20446]
atom [20147,20149]
===
match
---
operator: , [17471,17472]
operator: , [17174,17175]
===
match
---
name: airflow_conf [3835,3847]
name: airflow_conf [3776,3788]
===
match
---
name: dag_id [16735,16741]
name: dag_id [16438,16444]
===
match
---
operator: = [26387,26388]
operator: = [26090,26091]
===
match
---
trailer [6405,6408]
trailer [6108,6111]
===
match
---
fstring_string: .first_task_scheduling_delay [24274,24302]
fstring_string: .first_task_scheduling_delay [23977,24005]
===
match
---
expr_stmt [5526,5602]
expr_stmt [5467,5543]
===
match
---
name: self [19874,19878]
name: self [19577,19581]
===
match
---
trailer [18936,18940]
trailer [18639,18643]
===
match
---
simple_stmt [10444,10504]
simple_stmt [10147,10207]
===
match
---
name: dag_id [7432,7438]
name: dag_id [7135,7141]
===
match
---
suite [26796,27154]
suite [26499,26857]
===
match
---
arglist [19351,19428]
arglist [19054,19131]
===
match
---
operator: = [15830,15831]
operator: = [15533,15534]
===
match
---
name: count [30786,30791]
name: count [30489,30494]
===
match
---
name: schedule_interval [23350,23367]
name: schedule_interval [23053,23070]
===
match
---
name: scheduleable_tasks [19708,19726]
name: scheduleable_tasks [19411,19429]
===
match
---
trailer [15415,15430]
trailer [15118,15133]
===
match
---
name: __init__ [3957,3965]
name: __init__ [3898,3906]
===
match
---
name: ut [21667,21669]
name: ut [21370,21372]
===
match
---
operator: { [16038,16039]
operator: { [15741,15742]
===
match
---
expr_stmt [3202,3248]
expr_stmt [3143,3189]
===
match
---
argument [16723,16741]
argument [16426,16444]
===
match
---
name: self [4660,4664]
name: self [4601,4605]
===
match
---
name: BACKFILL_JOB [28514,28526]
name: BACKFILL_JOB [28217,28229]
===
match
---
name: self [19228,19232]
name: self [18931,18935]
===
match
---
arglist [20766,20822]
arglist [20469,20525]
===
match
---
name: callback_requests [17388,17405]
name: callback_requests [17091,17108]
===
match
---
trailer [21208,21214]
trailer [20911,20917]
===
match
---
atom_expr [23311,23337]
atom_expr [23014,23040]
===
match
---
name: run_type [11191,11199]
name: run_type [10894,10902]
===
match
---
simple_stmt [30267,30277]
simple_stmt [29970,29980]
===
match
---
operator: = [20099,20100]
operator: = [19802,19803]
===
match
---
comparison [10913,10951]
comparison [10616,10654]
===
match
---
name: external_trigger [5313,5329]
name: external_trigger [5254,5270]
===
match
---
name: utils [1887,1892]
name: utils [1828,1833]
===
match
---
trailer [20049,20253]
trailer [19752,19956]
===
match
---
operator: == [12746,12748]
operator: == [12449,12451]
===
match
---
trailer [10742,10783]
trailer [10445,10486]
===
match
---
trailer [7310,7319]
trailer [7013,7022]
===
match
---
name: Iterable [856,864]
name: Iterable [856,864]
===
match
---
trailer [30355,30361]
trailer [30058,30064]
===
match
---
trailer [21690,21998]
trailer [21393,21701]
===
match
---
suite [20872,20910]
suite [20575,20613]
===
match
---
operator: = [10821,10822]
operator: = [10524,10525]
===
match
---
argument [18020,18033]
argument [17723,17736]
===
match
---
atom_expr [19640,19647]
atom_expr [19343,19350]
===
match
---
atom_expr [19062,19076]
atom_expr [18765,18779]
===
match
---
name: self [4529,4533]
name: self [4470,4474]
===
match
---
trailer [10205,10242]
trailer [9908,9945]
===
match
---
suite [21450,22049]
suite [21153,21752]
===
match
---
atom_expr [3835,3947]
atom_expr [3776,3888]
===
match
---
comparison [4721,4749]
comparison [4662,4690]
===
match
---
trailer [28752,28767]
trailer [28455,28470]
===
match
---
name: execution_date [28342,28356]
name: execution_date [28045,28059]
===
match
---
operator: @ [25139,25140]
operator: @ [24842,24843]
===
match
---
funcdef [28440,28527]
funcdef [28143,28230]
===
match
---
trailer [19317,19321]
trailer [19020,19024]
===
match
---
name: dag_id [9917,9923]
name: dag_id [9620,9626]
===
match
---
name: TI [21405,21407]
name: TI [21108,21110]
===
match
---
name: execution_date [10331,10345]
name: execution_date [10034,10048]
===
match
---
name: timing [24958,24964]
name: timing [24661,24667]
===
match
---
name: session [1250,1257]
name: session [1191,1198]
===
match
---
trailer [12845,12847]
trailer [12548,12550]
===
match
---
name: dag_id [8080,8086]
name: dag_id [7783,7789]
===
match
---
param [13675,13680]
param [13378,13383]
===
match
---
expr_stmt [6401,6416]
expr_stmt [6104,6119]
===
match
---
expr_stmt [2790,2822]
expr_stmt [2731,2763]
===
match
---
name: self [28486,28490]
name: self [28189,28193]
===
match
---
trailer [3115,3127]
trailer [3056,3068]
===
match
---
name: execution_date [24153,24167]
name: execution_date [23856,23870]
===
match
---
trailer [28513,28526]
trailer [28216,28229]
===
match
---
comparison [5618,5639]
comparison [5559,5580]
===
match
---
simple_stmt [4691,4710]
simple_stmt [4632,4651]
===
match
---
name: IntegrityError [1104,1118]
name: IntegrityError [1045,1059]
===
match
---
suite [21108,21258]
suite [20811,20961]
===
match
---
name: state [30601,30606]
name: state [30304,30309]
===
match
---
operator: == [23368,23370]
operator: == [23071,23073]
===
match
---
trailer [21157,21169]
trailer [20860,20872]
===
match
---
name: RUNNING [18567,18574]
name: RUNNING [18270,18277]
===
match
---
suite [16314,16903]
suite [16017,16606]
===
match
---
name: session [25187,25194]
name: session [24890,24897]
===
match
---
trailer [3847,3854]
trailer [3788,3795]
===
match
---
trailer [30847,30854]
trailer [30550,30557]
===
match
---
operator: , [26222,26223]
operator: , [25925,25926]
===
match
---
arglist [28236,28375]
arglist [27939,28078]
===
match
---
name: filter [7839,7845]
name: filter [7542,7548]
===
match
---
atom_expr [25784,25808]
atom_expr [25487,25511]
===
match
---
trailer [26713,26717]
trailer [26416,26420]
===
match
---
atom_expr [24714,24727]
atom_expr [24417,24430]
===
match
---
trailer [4695,4701]
trailer [4636,4642]
===
match
---
atom_expr [3432,3468]
atom_expr [3373,3409]
===
match
---
string: """Returns the task instances for this dag run""" [11393,11442]
string: """Returns the task instances for this dag run""" [11096,11145]
===
match
---
argument [5313,5351]
argument [5254,5292]
===
match
---
operator: } [24273,24274]
operator: } [23976,23977]
===
match
---
atom [12684,12857]
atom [12387,12560]
===
match
---
name: warning [26152,26159]
name: warning [25855,25862]
===
match
---
simple_stmt [25557,25578]
simple_stmt [25260,25281]
===
match
---
trailer [30589,30596]
trailer [30292,30299]
===
match
---
expr_stmt [10637,10672]
expr_stmt [10340,10375]
===
match
---
trailer [20325,20329]
trailer [20028,20032]
===
match
---
operator: = [7831,7832]
operator: = [7534,7535]
===
match
---
fstring_expr [24433,24436]
fstring_expr [24136,24139]
===
match
---
atom_expr [5288,5299]
atom_expr [5229,5240]
===
match
---
name: utcnow [2778,2784]
name: utcnow [2719,2725]
===
match
---
argument [21848,21880]
argument [21551,21583]
===
match
---
name: TI [30827,30829]
name: TI [30530,30532]
===
match
---
name: utils [1837,1842]
name: utils [1778,1783]
===
match
---
operator: , [5299,5300]
operator: , [5240,5241]
===
match
---
name: state [26415,26420]
name: state [26118,26123]
===
match
---
atom_expr [5208,5219]
atom_expr [5149,5160]
===
match
---
trailer [16734,16741]
trailer [16437,16444]
===
match
---
atom_expr [5777,5817]
atom_expr [5718,5758]
===
match
---
atom_expr [4894,4907]
atom_expr [4835,4848]
===
match
---
name: none_depends_on_past [15497,15517]
name: none_depends_on_past [15200,15220]
===
match
---
name: session [7248,7255]
name: session [6951,6958]
===
match
---
operator: != [10925,10927]
operator: != [10628,10630]
===
match
---
trailer [5567,5574]
trailer [5508,5515]
===
match
---
atom_expr [4133,4151]
atom_expr [4074,4092]
===
match
---
trailer [21169,21173]
trailer [20872,20876]
===
match
---
trailer [15617,15676]
trailer [15320,15379]
===
match
---
name: self [17160,17164]
name: self [16863,16867]
===
match
---
trailer [30428,30435]
trailer [30131,30138]
===
match
---
trailer [19103,19161]
trailer [18806,18864]
===
match
---
simple_stmt [24240,24317]
simple_stmt [23943,24020]
===
match
---
simple_stmt [15443,15484]
simple_stmt [15146,15187]
===
match
---
operator: = [13321,13322]
operator: = [13024,13025]
===
match
---
trailer [5014,5023]
trailer [4955,4964]
===
match
---
trailer [12806,12814]
trailer [12509,12517]
===
match
---
argument [20084,20115]
argument [19787,19818]
===
match
---
operator: , [19878,19879]
operator: , [19581,19582]
===
match
---
operator: = [19040,19041]
operator: = [18743,18744]
===
match
---
trailer [19812,19816]
trailer [19515,19519]
===
match
---
atom_expr [20755,20823]
atom_expr [20458,20526]
===
match
---
operator: , [25122,25123]
operator: , [24825,24826]
===
match
---
trailer [25767,25771]
trailer [25470,25474]
===
match
---
fstring_start: f' [24377,24379]
fstring_start: f' [24080,24082]
===
match
---
name: self [17142,17146]
name: self [16845,16849]
===
match
---
fstring_string: __ [11200,11202]
fstring_string: __ [10903,10905]
===
match
---
expr_stmt [9897,9937]
expr_stmt [9600,9640]
===
match
---
name: leaf_ti [17023,17030]
name: leaf_ti [16726,16733]
===
match
---
name: info [15462,15466]
name: info [15165,15169]
===
match
---
name: dag_id [4485,4491]
name: dag_id [4426,4432]
===
match
---
operator: = [16087,16088]
operator: = [15790,15791]
===
match
---
name: state [5475,5480]
name: state [5416,5421]
===
match
---
name: qry [10969,10972]
name: qry [10672,10675]
===
match
---
trailer [7938,7950]
trailer [7641,7653]
===
match
---
string: 'success' [17287,17296]
string: 'success' [16990,16999]
===
match
---
testlist_comp [11990,12011]
testlist_comp [11693,11714]
===
match
---
tfpdef [8080,8119]
tfpdef [7783,7822]
===
match
---
operator: = [2801,2802]
operator: = [2742,2743]
===
match
---
argument [2761,2784]
argument [2702,2725]
===
match
---
trailer [4615,4632]
trailer [4556,4573]
===
match
---
atom_expr [18316,18335]
atom_expr [18019,18038]
===
match
---
operator: = [29877,29878]
operator: = [29580,29581]
===
match
---
operator: == [3632,3634]
operator: == [3573,3575]
===
match
---
name: DagModel [7549,7557]
name: DagModel [7252,7260]
===
match
---
name: schedulable_tis [29932,29947]
name: schedulable_tis [29635,29650]
===
match
---
operator: = [5247,5248]
operator: = [5188,5189]
===
match
---
name: session [8394,8401]
name: session [8097,8104]
===
match
---
operator: , [20791,20792]
operator: , [20494,20495]
===
match
---
trailer [11474,11481]
trailer [11177,11184]
===
match
---
trailer [25702,25704]
trailer [25405,25407]
===
match
---
atom_expr [16327,16372]
atom_expr [16030,16075]
===
match
---
name: DagRun [13543,13549]
name: DagRun [13246,13252]
===
match
---
name: execution_date [30948,30962]
name: execution_date [30651,30665]
===
match
---
trailer [5755,5818]
trailer [5696,5759]
===
match
---
expr_stmt [4894,4918]
expr_stmt [4835,4859]
===
match
---
operator: = [8468,8469]
operator: = [8171,8172]
===
match
---
simple_stmt [25491,25548]
simple_stmt [25194,25251]
===
match
---
name: set [25699,25702]
name: set [25402,25405]
===
match
---
dotted_name [1082,1096]
dotted_name [1023,1037]
===
match
---
comparison [7549,7588]
comparison [7252,7291]
===
match
---
name: log [24365,24368]
name: log [24068,24071]
===
match
---
name: Optional [4180,4188]
name: Optional [4121,4129]
===
match
---
operator: , [4454,4455]
operator: , [4395,4396]
===
match
---
expr_stmt [15590,15676]
expr_stmt [15293,15379]
===
match
---
trailer [23623,23628]
trailer [23326,23331]
===
match
---
atom_expr [12276,12293]
atom_expr [11979,11996]
===
match
---
name: and_ [3617,3621]
name: and_ [3558,3562]
===
match
---
trailer [26093,26101]
trailer [25796,25804]
===
match
---
atom_expr [14005,14022]
atom_expr [13708,13725]
===
match
---
argument [17493,17511]
argument [17196,17214]
===
match
---
operator: , [3422,3423]
operator: , [3363,3364]
===
match
---
param [5871,5894]
param [5812,5835]
===
match
---
name: finished_tasks [20339,20353]
name: finished_tasks [20042,20056]
===
match
---
atom_expr [26666,26674]
atom_expr [26369,26377]
===
match
---
operator: = [17608,17609]
operator: = [17311,17312]
===
match
---
atom_expr [23109,23122]
atom_expr [22812,22825]
===
match
---
param [8427,8475]
param [8130,8178]
===
match
---
name: nullable [3082,3090]
name: nullable [3023,3031]
===
match
---
atom_expr [13820,14110]
atom_expr [13523,13813]
===
match
---
trailer [11379,11383]
trailer [11082,11086]
===
match
---
funcdef [14147,18785]
funcdef [13850,18488]
===
match
---
trailer [25034,25040]
trailer [24737,24743]
===
match
---
trailer [11000,11004]
trailer [10703,10707]
===
match
---
comparison [28277,28309]
comparison [27980,28012]
===
match
---
comparison [30876,30900]
comparison [30579,30603]
===
match
---
atom_expr [28714,28851]
atom_expr [28417,28554]
===
match
---
trailer [8457,8467]
trailer [8160,8170]
===
match
---
fstring_start: f" [26606,26608]
fstring_start: f" [26309,26311]
===
match
---
decorated [8023,11007]
decorated [7726,10710]
===
match
---
name: fileloc [17464,17471]
name: fileloc [17167,17174]
===
match
---
dictorsetmaker [30598,30623]
dictorsetmaker [30301,30326]
===
match
---
name: ti [30174,30176]
name: ti [29877,29879]
===
match
---
operator: { [25108,25109]
operator: { [24811,24812]
===
match
---
operator: -> [28462,28464]
operator: -> [28165,28167]
===
match
---
name: __NO_VALUE [2582,2592]
name: __NO_VALUE [2523,2533]
===
match
---
trailer [31268,31277]
trailer [30971,30980]
===
match
---
string: """The previous, SCHEDULED DagRun, if there is one""" [13737,13790]
string: """The previous, SCHEDULED DagRun, if there is one""" [13440,13493]
===
match
---
operator: = [15363,15364]
operator: = [15066,15067]
===
match
---
simple_stmt [17160,17190]
simple_stmt [16863,16893]
===
match
---
trailer [27259,27269]
trailer [26962,26972]
===
match
---
comparison [4801,4822]
comparison [4742,4763]
===
match
---
name: TI [20360,20362]
name: TI [20063,20065]
===
match
---
name: self [17915,17919]
name: self [17618,17622]
===
match
---
atom_expr [17175,17188]
atom_expr [16878,16891]
===
match
---
name: UtcDateTime [2845,2856]
name: UtcDateTime [2786,2797]
===
match
---
name: session [29182,29189]
name: session [28885,28892]
===
match
---
param [18856,18879]
param [18559,18582]
===
match
---
operator: = [10730,10731]
operator: = [10433,10434]
===
match
---
operator: = [3061,3062]
operator: = [3002,3003]
===
match
---
name: provide_session [18791,18806]
name: provide_session [18494,18509]
===
match
---
arglist [15917,15958]
arglist [15620,15661]
===
match
---
trailer [8288,8294]
trailer [7991,7997]
===
match
---
name: self [24602,24606]
name: self [24305,24309]
===
match
---
if_stmt [12998,13096]
if_stmt [12701,12799]
===
match
---
expr_stmt [19708,19795]
expr_stmt [19411,19498]
===
match
---
operator: = [3319,3320]
operator: = [3260,3261]
===
match
---
atom_expr [7323,7346]
atom_expr [7026,7049]
===
match
---
trailer [13343,13350]
trailer [13046,13053]
===
match
---
arglist [13879,14023]
arglist [13582,13726]
===
match
---
simple_stmt [5526,5603]
simple_stmt [5467,5544]
===
match
---
trailer [12176,12180]
trailer [11879,11883]
===
match
---
if_stmt [19675,20013]
if_stmt [19378,19716]
===
match
---
atom_expr [3331,3368]
atom_expr [3272,3309]
===
match
---
name: qry [10099,10102]
name: qry [9802,9805]
===
match
---
operator: = [18406,18407]
operator: = [18109,18110]
===
match
---
name: TI [2251,2253]
name: TI [2192,2194]
===
match
---
param [20373,20390]
param [20076,20093]
===
match
---
number: 0 [23731,23732]
number: 0 [23434,23435]
===
match
---
atom [20477,20479]
atom [20180,20182]
===
match
---
import_as_name [1375,1395]
import_as_name [1316,1336]
===
match
---
name: UniqueConstraint [3432,3448]
name: UniqueConstraint [3373,3389]
===
match
---
simple_stmt [4660,4683]
simple_stmt [4601,4624]
===
match
---
string: 'DagRun' [28617,28625]
string: 'DagRun' [28320,28328]
===
match
---
name: schedulable_tis [20100,20115]
name: schedulable_tis [19803,19818]
===
match
---
operator: , [28593,28594]
operator: , [28296,28297]
===
match
---
trailer [12275,12294]
trailer [11978,11997]
===
match
---
name: dag [23270,23273]
name: dag [22973,22976]
===
match
---
operator: == [29028,29030]
operator: == [28731,28733]
===
match
---
arglist [19823,19903]
arglist [19526,19606]
===
match
---
operator: -> [8537,8539]
operator: -> [8240,8242]
===
match
---
name: Column [2934,2940]
name: Column [2875,2881]
===
match
---
comparison [24506,24533]
comparison [24209,24236]
===
match
---
name: filters [13313,13320]
name: filters [13016,13023]
===
match
---
name: execution_date [30483,30497]
name: execution_date [30186,30200]
===
match
---
operator: = [4874,4875]
operator: = [4815,4816]
===
match
---
name: DR [9914,9916]
name: DR [9617,9619]
===
match
---
name: inherits_from_dummy_operator [29990,30018]
name: inherits_from_dummy_operator [29693,29721]
===
match
---
string: 'idx_last_scheduling_decision' [3484,3514]
string: 'idx_last_scheduling_decision' [3425,3455]
===
match
---
name: datetime [4085,4093]
name: datetime [4026,4034]
===
match
---
suite [24347,24439]
suite [24050,24142]
===
match
---
simple_stmt [22016,22028]
simple_stmt [21719,21731]
===
match
---
operator: = [16729,16730]
operator: = [16432,16433]
===
match
---
name: qry [10823,10826]
name: qry [10526,10529]
===
match
---
return_stmt [18752,18784]
return_stmt [18455,18487]
===
match
---
atom_expr [2887,2897]
atom_expr [2828,2838]
===
match
---
name: AirflowException [1427,1443]
name: AirflowException [1368,1384]
===
match
---
name: TISchedulingDecision [18884,18904]
name: TISchedulingDecision [18587,18607]
===
match
---
atom_expr [21667,21998]
atom_expr [21370,21701]
===
match
---
name: state [11688,11693]
name: state [11391,11396]
===
match
---
atom_expr [16464,16544]
atom_expr [16167,16247]
===
match
---
name: nulls_first [7643,7654]
name: nulls_first [7346,7357]
===
match
---
atom [4680,4682]
atom [4621,4623]
===
match
---
comparison [10834,10857]
comparison [10537,10560]
===
match
---
trailer [18320,18335]
trailer [18023,18038]
===
match
---
operator: , [20199,20200]
operator: , [19902,19903]
===
match
---
name: task_id [12264,12271]
name: task_id [11967,11974]
===
match
---
atom_expr [16039,16048]
atom_expr [15742,15751]
===
match
---
name: timezone [31223,31231]
name: timezone [30926,30934]
===
match
---
trailer [24753,24757]
trailer [24456,24460]
===
match
---
name: self [4691,4695]
name: self [4632,4636]
===
match
---
simple_stmt [18752,18785]
simple_stmt [18455,18488]
===
match
---
atom_expr [25109,25120]
atom_expr [24812,24823]
===
match
---
simple_stmt [3288,3299]
simple_stmt [3229,3240]
===
match
---
name: log [24607,24610]
name: log [24310,24313]
===
match
---
return_stmt [10962,11006]
return_stmt [10665,10709]
===
match
---
name: self [5726,5730]
name: self [5667,5671]
===
match
---
trailer [29000,29007]
trailer [28703,28710]
===
match
---
atom_expr [20678,20686]
atom_expr [20381,20389]
===
match
---
name: session [7999,8006]
name: session [7702,7709]
===
match
---
atom_expr [31266,31277]
atom_expr [30969,30980]
===
match
---
atom_expr [26253,26308]
atom_expr [25956,26011]
===
match
---
name: t [19555,19556]
name: t [19258,19259]
===
match
---
operator: , [4367,4368]
operator: , [4308,4309]
===
match
---
expr_stmt [7825,7882]
expr_stmt [7528,7585]
===
match
---
expr_stmt [11885,11921]
expr_stmt [11588,11624]
===
match
---
name: max [28745,28748]
name: max [28448,28451]
===
match
---
operator: } [26640,26641]
operator: } [26343,26344]
===
match
---
name: dag_id [9858,9864]
name: dag_id [9561,9567]
===
match
---
param [27664,27688]
param [27367,27391]
===
match
---
name: dag [12219,12222]
name: dag [11922,11925]
===
match
---
operator: , [11635,11636]
operator: , [11338,11339]
===
match
---
name: finished_tasks [21384,21398]
name: finished_tasks [21087,21101]
===
match
---
trailer [13567,13576]
trailer [13270,13279]
===
match
---
arglist [3484,3540]
arglist [3425,3481]
===
match
---
name: schedule_interval [23320,23337]
name: schedule_interval [23023,23040]
===
match
---
if_stmt [4718,4886]
if_stmt [4659,4827]
===
match
---
param [28595,28607]
param [28298,28310]
===
match
---
operator: , [8384,8385]
operator: , [8087,8088]
===
match
---
name: Stats [24952,24957]
name: Stats [24655,24660]
===
match
---
name: scheduleable_tasks [19968,19986]
name: scheduleable_tasks [19671,19689]
===
match
---
trailer [28616,28626]
trailer [28319,28329]
===
match
---
name: has_on_failure_callback [18104,18127]
name: has_on_failure_callback [17807,17830]
===
match
---
operator: } [30623,30624]
operator: } [30326,30327]
===
match
---
name: changed_tis [20129,20140]
name: changed_tis [19832,19843]
===
match
---
operator: , [1922,1923]
operator: , [1863,1864]
===
match
---
simple_stmt [26963,27023]
simple_stmt [26666,26726]
===
match
---
string: """Returns the latest DagRun for each DAG""" [28636,28680]
string: """Returns the latest DagRun for each DAG""" [28339,28383]
===
match
---
fstring_string: dagrun. [24255,24262]
fstring_string: dagrun. [23958,23965]
===
match
---
operator: { [26998,26999]
operator: { [26701,26702]
===
match
---
trailer [11894,11901]
trailer [11597,11604]
===
match
---
operator: , [18239,18240]
operator: , [17942,17943]
===
match
---
name: unfinished_tasks [19743,19759]
name: unfinished_tasks [19446,19462]
===
match
---
operator: == [28987,28989]
operator: == [28690,28692]
===
match
---
trailer [10981,11000]
trailer [10684,10703]
===
match
---
name: self [11554,11558]
name: self [11257,11261]
===
match
---
param [20301,20330]
param [20004,20033]
===
match
---
operator: = [17547,17548]
operator: = [17250,17251]
===
match
---
arglist [26160,26231]
arglist [25863,25934]
===
match
---
expr_stmt [26367,26437]
expr_stmt [26070,26140]
===
match
---
name: execution_date [10018,10032]
name: execution_date [9721,9735]
===
match
---
trailer [10646,10653]
trailer [10349,10356]
===
match
---
suite [10713,10784]
suite [10416,10487]
===
match
---
name: task [26999,27003]
name: task [26702,26706]
===
match
---
operator: = [27042,27043]
operator: = [26745,26746]
===
match
---
testlist [18759,18784]
testlist [18462,18487]
===
match
---
tfpdef [4168,4198]
tfpdef [4109,4139]
===
match
---
tfpdef [8311,8329]
tfpdef [8014,8032]
===
match
---
name: duration [25007,25015]
name: duration [24710,24718]
===
match
---
name: old_states [20431,20441]
name: old_states [20134,20144]
===
match
---
comparison [7409,7438]
comparison [7112,7141]
===
match
---
trailer [13550,13557]
trailer [13253,13260]
===
match
---
atom_expr [13896,13907]
atom_expr [13599,13610]
===
match
---
name: self [30889,30893]
name: self [30592,30596]
===
match
---
simple_stmt [2790,2823]
simple_stmt [2731,2764]
===
match
---
fstring_expr [25108,25121]
fstring_expr [24811,24824]
===
match
---
trailer [27595,27597]
trailer [27298,27300]
===
match
---
suite [23176,23196]
suite [22879,22899]
===
match
---
expr_stmt [29864,29881]
expr_stmt [29567,29584]
===
match
---
name: execution_date [16763,16777]
name: execution_date [16466,16480]
===
match
---
comparison [7307,7346]
comparison [7010,7049]
===
match
---
expr_stmt [15351,15381]
expr_stmt [15054,15084]
===
match
---
operator: , [16526,16527]
operator: , [16229,16230]
===
match
---
name: callback_requests [14955,14972]
name: callback_requests [14658,14675]
===
match
---
arglist [3395,3421]
arglist [3336,3362]
===
match
---
name: dr [6438,6440]
name: dr [6141,6143]
===
match
---
name: dag [26110,26113]
name: dag [25813,25816]
===
match
---
name: Optional [14946,14954]
name: Optional [14649,14657]
===
match
---
operator: == [30886,30888]
operator: == [30589,30591]
===
match
---
operator: , [3403,3404]
operator: , [3344,3345]
===
match
---
name: dag_id [27651,27657]
name: dag_id [27354,27360]
===
match
---
name: airflow [7043,7050]
name: airflow [6746,6753]
===
match
---
trailer [5661,5671]
trailer [5602,5612]
===
match
---
atom_expr [7248,7752]
atom_expr [6951,7455]
===
match
---
name: get_task_instances [18999,19017]
name: get_task_instances [18702,18720]
===
match
---
comparison [7846,7881]
comparison [7549,7584]
===
match
---
arglist [2748,2784]
arglist [2689,2725]
===
match
---
name: TI [21037,21039]
name: TI [20740,20742]
===
match
---
number: 1 [26647,26648]
number: 1 [26350,26351]
===
match
---
name: TI [11676,11678]
name: TI [11379,11381]
===
match
---
trailer [24964,25016]
trailer [24667,24719]
===
match
---
name: external_trigger [2999,3015]
name: external_trigger [2940,2956]
===
match
---
name: datetime [4189,4197]
name: datetime [4130,4138]
===
match
---
operator: , [21374,21375]
operator: , [21077,21078]
===
match
---
operator: == [7568,7570]
operator: == [7271,7273]
===
match
---
atom_expr [24911,24921]
atom_expr [24614,24624]
===
match
---
and_test [15693,15760]
and_test [15396,15463]
===
match
---
sync_comp_for [19551,19594]
sync_comp_for [19254,19297]
===
match
---
trailer [9988,9995]
trailer [9691,9698]
===
match
---
name: msg [16865,16868]
name: msg [16568,16571]
===
match
---
arglist [9840,9851]
arglist [9543,9554]
===
match
---
trailer [30533,30553]
trailer [30236,30256]
===
match
---
operator: = [8378,8379]
operator: = [8081,8082]
===
match
---
trailer [19421,19428]
trailer [19124,19131]
===
match
---
name: nulls_first [1924,1935]
name: nulls_first [1865,1876]
===
match
---
atom_expr [13986,14001]
atom_expr [13689,13704]
===
match
---
trailer [26503,26578]
trailer [26206,26281]
===
match
---
expr_stmt [2862,2920]
expr_stmt [2803,2861]
===
match
---
name: start_date [2790,2800]
name: start_date [2731,2741]
===
match
---
atom_expr [11554,11573]
atom_expr [11257,11276]
===
match
---
operator: = [3292,3293]
operator: = [3233,3234]
===
match
---
return_stmt [13522,13614]
return_stmt [13225,13317]
===
match
---
operator: , [3457,3458]
operator: , [3398,3399]
===
match
---
trailer [18566,18574]
trailer [18269,18277]
===
match
---
operator: = [11356,11357]
operator: = [11059,11060]
===
match
---
atom [29879,29881]
atom [29582,29584]
===
match
---
parameters [12368,12413]
parameters [12071,12116]
===
match
---
operator: = [4702,4703]
operator: = [4643,4644]
===
match
---
name: Tuple [894,899]
name: Tuple [894,899]
===
match
---
trailer [25885,25897]
trailer [25588,25600]
===
match
---
name: label [28769,28774]
name: label [28472,28477]
===
match
---
name: values [26787,26793]
name: values [26490,26496]
===
match
---
name: State [26088,26093]
name: State [25791,25796]
===
match
---
trailer [11910,11914]
trailer [11613,11617]
===
match
---
name: session [21976,21983]
name: session [21679,21686]
===
match
---
name: changed_tis [21285,21296]
name: changed_tis [20988,20999]
===
match
---
decorator [13620,13637]
decorator [13323,13340]
===
match
---
name: external_trigger [4215,4231]
name: external_trigger [4156,4172]
===
match
---
expr_stmt [23686,23744]
expr_stmt [23389,23447]
===
match
---
expr_stmt [3052,3097]
expr_stmt [2993,3038]
===
match
---
operator: = [4199,4200]
operator: = [4140,4141]
===
match
---
name: self [24714,24718]
name: self [24417,24421]
===
match
---
name: Optional [4387,4395]
name: Optional [4328,4336]
===
match
---
name: key [23629,23632]
name: key [23332,23335]
===
match
---
atom_expr [25886,25896]
atom_expr [25589,25599]
===
match
---
name: start_dttm [15009,15019]
name: start_dttm [14712,14722]
===
match
---
simple_stmt [20889,20910]
simple_stmt [20592,20613]
===
match
---
name: self [14173,14177]
name: self [13876,13880]
===
match
---
trailer [16483,16544]
trailer [16186,16247]
===
match
---
atom_expr [17460,17471]
atom_expr [17163,17174]
===
match
---
name: session [19018,19025]
name: session [18721,18728]
===
match
---
trailer [7138,7165]
trailer [6841,6868]
===
match
---
name: incr [26601,26605]
name: incr [26304,26308]
===
match
---
trailer [16565,16589]
trailer [16268,16292]
===
match
---
param [4377,4408]
param [4318,4349]
===
match
---
atom_expr [25044,25056]
atom_expr [24747,24759]
===
match
---
name: utils [2035,2040]
name: utils [1976,1981]
===
match
---
name: dag [7058,7061]
name: dag [6761,6764]
===
match
---
name: ti [19218,19220]
name: ti [18921,18923]
===
match
---
name: filter [9979,9985]
name: filter [9682,9688]
===
match
---
name: st [20955,20957]
name: st [20658,20660]
===
match
---
name: provide_session [13621,13636]
name: provide_session [13324,13339]
===
match
---
trailer [30166,30173]
trailer [29869,29876]
===
match
---
operator: , [4205,4206]
operator: , [4146,4147]
===
match
---
atom_expr [4529,4548]
atom_expr [4470,4489]
===
match
---
name: Session [1265,1272]
name: Session [1206,1213]
===
match
---
simple_stmt [7892,8018]
simple_stmt [7595,7721]
===
match
---
name: query [30821,30826]
name: query [30524,30529]
===
match
---
simple_stmt [4471,4492]
simple_stmt [4412,4433]
===
match
---
for_stmt [21624,22028]
for_stmt [21327,21731]
===
match
---
name: REMOVED [25972,25979]
name: REMOVED [25675,25682]
===
match
---
simple_stmt [25221,25483]
simple_stmt [24924,25186]
===
match
---
simple_stmt [13105,13121]
simple_stmt [12808,12824]
===
match
---
trailer [26776,26786]
trailer [26479,26489]
===
match
---
name: dag_hash [4932,4940]
name: dag_hash [4873,4881]
===
match
---
if_stmt [10615,10673]
if_stmt [10318,10376]
===
match
---
if_stmt [2066,2123]
if_stmt [2007,2064]
===
match
---
operator: = [17286,17287]
operator: = [16989,16990]
===
match
---
trailer [28922,28927]
trailer [28625,28630]
===
match
---
trailer [2667,2683]
trailer [2608,2624]
===
match
---
string: """         Returns a set of dag runs for the given search criteria.          :param dag_id: the dag_id or list of dag_id to find dag runs for         :type dag_id: str or list[str]         :param run_id: defines the run id for this dag run         :type run_id: str         :param run_type: type of DagRun         :type run_type: airflow.utils.types.DagRunType         :param execution_date: the execution date         :type execution_date: datetime.datetime or list[datetime.datetime]         :param state: the state of the dag run         :type state: str         :param external_trigger: whether this dag run is externally triggered         :type external_trigger: bool         :param no_backfills: return no backfills (True), return all (False).             Defaults to False         :type no_backfills: bool         :param session: database session         :type session: sqlalchemy.orm.session.Session         :param execution_start_date: dag run that was executed from this date         :type execution_start_date: datetime.datetime         :param execution_end_date: dag run that was executed until this date         :type execution_end_date: datetime.datetime         """ [8564,9745]
string: """         Returns a set of dag runs for the given search criteria.          :param dag_id: the dag_id or list of dag_id to find dag runs for         :type dag_id: str or list[str]         :param run_id: defines the run id for this dag run         :type run_id: str         :param run_type: type of DagRun         :type run_type: airflow.utils.types.DagRunType         :param execution_date: the execution date         :type execution_date: datetime.datetime or list[datetime.datetime]         :param state: the state of the dag run         :type state: str         :param external_trigger: whether this dag run is externally triggered         :type external_trigger: bool         :param no_backfills: return no backfills (True), return all (False).             Defaults to False         :type no_backfills: bool         :param session: database session         :type session: sqlalchemy.orm.session.Session         :param execution_start_date: dag run that was executed from this date         :type execution_start_date: datetime.datetime         :param execution_end_date: dag run that was executed until this date         :type execution_end_date: datetime.datetime         """ [8267,9448]
===
match
---
name: state [11905,11910]
name: state [11608,11613]
===
match
---
trailer [17112,17147]
trailer [16815,16850]
===
match
---
atom_expr [3109,3127]
atom_expr [3050,3068]
===
match
---
operator: == [23106,23108]
operator: == [22809,22811]
===
match
---
name: max_number [6565,6575]
name: max_number [6268,6278]
===
match
---
name: _emit_duration_stats_for_finished_state [18672,18711]
name: _emit_duration_stats_for_finished_state [18375,18414]
===
match
---
simple_stmt [3253,3283]
simple_stmt [3194,3224]
===
match
---
name: String [3271,3277]
name: String [3212,3218]
===
match
---
expr_stmt [4960,4998]
expr_stmt [4901,4939]
===
match
---
operator: , [18335,18336]
operator: , [18038,18039]
===
match
---
trailer [28184,28190]
trailer [27887,27893]
===
match
---
name: failed_states [16275,16288]
name: failed_states [15978,15991]
===
match
---
simple_stmt [30220,30258]
simple_stmt [29923,29961]
===
match
---
name: on_execute_callback [30051,30070]
name: on_execute_callback [29754,29773]
===
match
---
simple_stmt [18145,18449]
simple_stmt [17848,18152]
===
match
---
not_test [16223,16243]
not_test [15926,15946]
===
match
---
simple_stmt [29223,29697]
simple_stmt [28926,29400]
===
match
---
dotted_name [1177,1191]
dotted_name [1118,1132]
===
match
---
name: start_date [4579,4589]
name: start_date [4520,4530]
===
match
---
name: unfinished_tasks [20183,20199]
name: unfinished_tasks [19886,19902]
===
match
---
expr_stmt [4574,4602]
expr_stmt [4515,4543]
===
match
---
name: ti [19415,19417]
name: ti [19118,19120]
===
match
---
name: bool [20416,20420]
name: bool [20119,20123]
===
match
---
operator: , [3595,3596]
operator: , [3536,3537]
===
match
---
expr_stmt [25866,25897]
expr_stmt [25569,25600]
===
match
---
trailer [12280,12284]
trailer [11983,11987]
===
match
---
name: timing [25076,25082]
name: timing [24779,24785]
===
match
---
atom_expr [11902,11920]
atom_expr [11605,11623]
===
match
---
param [4215,4255]
param [4156,4196]
===
match
---
name: primary_key [2630,2641]
name: primary_key [2571,2582]
===
match
---
operator: , [29057,29058]
operator: , [28760,28761]
===
match
---
name: ignore_in_reschedule_period [21848,21875]
name: ignore_in_reschedule_period [21551,21578]
===
match
---
name: ALLOW_FUTURE_EXEC_DATES [7788,7811]
name: ALLOW_FUTURE_EXEC_DATES [7491,7514]
===
match
---
name: ti [30043,30045]
name: ti [29746,29748]
===
match
---
trailer [13603,13605]
trailer [13306,13308]
===
match
---
name: self [25563,25567]
name: self [25266,25270]
===
match
---
comparison [19640,19665]
comparison [19343,19368]
===
match
---
name: session [20004,20011]
name: session [19707,19714]
===
match
---
simple_stmt [28156,28421]
simple_stmt [27859,28124]
===
match
---
expr_stmt [21024,21073]
expr_stmt [20727,20776]
===
match
---
name: DagCallbackRequest [14287,14305]
name: DagCallbackRequest [13990,14008]
===
match
---
name: set_state [5425,5434]
name: set_state [5366,5375]
===
match
---
or_test [15854,15994]
or_test [15557,15697]
===
match
---
trailer [24569,24580]
trailer [24272,24283]
===
match
---
arglist [7927,8007]
arglist [7630,7710]
===
match
---
name: self [12276,12280]
name: self [11979,11983]
===
match
---
decorator [11012,11026]
decorator [10715,10729]
===
match
---
name: dag_id [11513,11519]
name: dag_id [11216,11222]
===
match
---
trailer [7838,7845]
trailer [7541,7548]
===
match
---
arglist [26504,26577]
arglist [26207,26280]
===
match
---
name: DagRun [9759,9765]
name: DagRun [9462,9468]
===
match
---
expr_stmt [25557,25577]
expr_stmt [25260,25280]
===
match
---
name: DagRunType [8366,8376]
name: DagRunType [8069,8079]
===
match
---
operator: , [19144,19145]
operator: , [18847,18848]
===
match
---
name: self [19313,19317]
name: self [19016,19020]
===
match
---
atom_expr [17099,17147]
atom_expr [16802,16850]
===
match
---
trailer [23349,23367]
trailer [23052,23070]
===
match
---
trailer [7333,7346]
trailer [7036,7049]
===
match
---
operator: = [2593,2594]
operator: = [2534,2535]
===
match
---
name: dag_id [28243,28249]
name: dag_id [27946,27952]
===
match
---
trailer [12705,12711]
trailer [12408,12414]
===
match
---
atom_expr [12804,12814]
atom_expr [12507,12517]
===
match
---
dotted_name [1508,1535]
dotted_name [1449,1476]
===
match
---
atom_expr [4347,4360]
atom_expr [4288,4301]
===
match
---
trailer [11004,11006]
trailer [10707,10709]
===
match
---
import_as_names [1199,1229]
import_as_names [1140,1170]
===
match
---
trailer [24606,24610]
trailer [24309,24313]
===
match
---
name: unfinished_tasks [2311,2327]
name: unfinished_tasks [2252,2268]
===
match
---
atom_expr [3264,3282]
atom_expr [3205,3223]
===
match
---
annassign [2274,2284]
annassign [2215,2225]
===
match
---
operator: @ [13126,13127]
operator: @ [12829,12830]
===
match
---
parameters [27632,27689]
parameters [27335,27392]
===
match
---
name: ti [26224,26226]
name: ti [25927,25929]
===
match
---
atom_expr [28976,28986]
atom_expr [28679,28689]
===
match
---
operator: , [2628,2629]
operator: , [2569,2570]
===
match
---
operator: == [28357,28359]
operator: == [28060,28062]
===
match
---
name: dummy_ti_ids [29864,29876]
name: dummy_ti_ids [29567,29579]
===
match
---
trailer [14249,14307]
trailer [13952,14010]
===
match
---
atom_expr [10982,10999]
atom_expr [10685,10702]
===
match
---
simple_stmt [21121,21176]
simple_stmt [20824,20879]
===
match
---
param [5435,5440]
param [5376,5381]
===
match
---
operator: = [17386,17387]
operator: = [17089,17090]
===
match
---
name: get_task_instances [11262,11280]
name: get_task_instances [10965,10983]
===
match
---
fstring_end: ' [25004,25005]
fstring_end: ' [24707,24708]
===
match
---
atom_expr [26088,26101]
atom_expr [25791,25804]
===
match
---
name: run_id [4505,4511]
name: run_id [4446,4452]
===
match
---
suite [10172,10243]
suite [9875,9946]
===
match
---
comparison [24911,24938]
comparison [24614,24641]
===
match
---
name: execution_start_date [10254,10274]
name: execution_start_date [9957,9977]
===
match
---
trailer [26633,26640]
trailer [26336,26343]
===
match
---
trailer [30361,30365]
trailer [30064,30068]
===
match
---
name: order_by [14051,14059]
name: order_by [13754,13762]
===
match
---
name: session [15951,15958]
name: session [15654,15661]
===
match
---
trailer [14254,14258]
trailer [13957,13961]
===
match
---
name: get_dag [19233,19240]
name: get_dag [18936,18943]
===
match
---
simple_stmt [10817,10859]
simple_stmt [10520,10562]
===
match
---
name: ut [19730,19732]
name: ut [19433,19435]
===
match
---
if_stmt [10681,10784]
if_stmt [10384,10487]
===
match
---
operator: = [4590,4591]
operator: = [4531,4532]
===
match
---
for_stmt [20624,20975]
for_stmt [20327,20678]
===
match
---
name: task_id [30177,30184]
name: task_id [29880,29887]
===
match
---
trailer [27437,27442]
trailer [27140,27145]
===
match
---
atom_expr [13476,13513]
atom_expr [13179,13216]
===
match
---
operator: , [7683,7684]
operator: , [7386,7387]
===
match
---
name: TI [21147,21149]
name: TI [20850,20852]
===
match
---
atom_expr [13184,13197]
atom_expr [12887,12900]
===
match
---
name: provide_session [25140,25155]
name: provide_session [24843,24858]
===
match
---
expr_stmt [3554,3800]
expr_stmt [3495,3741]
===
match
---
simple_stmt [1077,1119]
simple_stmt [1018,1060]
===
match
---
operator: , [7588,7589]
operator: , [7291,7292]
===
match
---
fstring_string:  -  [27376,27379]
fstring_string:  -  [27079,27082]
===
match
---
name: dag_id [30879,30885]
name: dag_id [30582,30588]
===
match
---
operator: = [4778,4779]
operator: = [4719,4720]
===
match
---
name: QUEUED [5633,5639]
name: QUEUED [5574,5580]
===
match
---
name: dummy_ti_ids [30999,31011]
name: dummy_ti_ids [30702,30714]
===
match
---
param [12369,12374]
param [12072,12077]
===
match
---
name: stats [1575,1580]
name: stats [1516,1521]
===
match
---
operator: , [28738,28739]
operator: , [28441,28442]
===
match
---
name: Column [2979,2985]
name: Column [2920,2926]
===
match
---
operator: , [28374,28375]
operator: , [28077,28078]
===
match
---
name: has_on_success_callback [17336,17359]
name: has_on_success_callback [17039,17062]
===
match
---
number: 1 [26306,26307]
number: 1 [26009,26010]
===
match
---
name: TaskInstanceState [11321,11338]
name: TaskInstanceState [11024,11041]
===
match
---
decorator [27603,27617]
decorator [27306,27320]
===
match
---
expr_stmt [2999,3047]
expr_stmt [2940,2988]
===
match
---
trailer [19511,19517]
trailer [19214,19220]
===
match
---
operator: = [21975,21976]
operator: = [21678,21679]
===
match
---
name: self [5330,5334]
name: self [5271,5275]
===
match
---
name: ti [19463,19465]
name: ti [19166,19168]
===
match
---
suite [26473,26688]
suite [26176,26391]
===
match
---
expr_stmt [16607,16902]
expr_stmt [16310,16605]
===
match
---
operator: > [24215,24216]
operator: > [23918,23919]
===
match
---
expr_stmt [2342,2366]
expr_stmt [2283,2307]
===
match
---
atom_expr [17019,17085]
atom_expr [16722,16788]
===
match
---
suite [16590,16903]
suite [16293,16606]
===
match
---
name: __NO_VALUE [4739,4749]
name: __NO_VALUE [4680,4690]
===
match
---
name: TI [2334,2336]
name: TI [2275,2277]
===
match
---
return_stmt [13799,14120]
return_stmt [13502,13823]
===
match
---
simple_stmt [15497,15578]
simple_stmt [15200,15281]
===
match
---
name: self [20287,20291]
name: self [19990,19994]
===
match
---
operator: { [24991,24992]
operator: { [24694,24695]
===
match
---
expr_stmt [2241,2254]
expr_stmt [2182,2195]
===
match
---
name: QUEUED [2913,2919]
name: QUEUED [2854,2860]
===
match
---
name: task [19221,19225]
name: task [18924,18928]
===
match
---
operator: , [17296,17297]
operator: , [16999,17000]
===
match
---
param [14179,14203]
param [13882,13906]
===
match
---
atom_expr [4960,4980]
atom_expr [4901,4921]
===
match
---
name: task_id [26922,26929]
name: task_id [26625,26632]
===
match
---
atom_expr [10328,10395]
atom_expr [10031,10098]
===
match
---
string: 'state' [2878,2885]
string: 'state' [2819,2826]
===
match
---
string: """         Get a single DAG Run          :param session: Sqlalchemy ORM Session         :type session: Session         :param dag_id: DAG ID         :type dag_id: unicode         :param execution_date: execution date         :type execution_date: datetime         :return: DagRun corresponding to the given dag_id and execution date             if one exists. None otherwise.         :rtype: airflow.models.DagRun         """ [27721,28147]
string: """         Get a single DAG Run          :param session: Sqlalchemy ORM Session         :type session: Session         :param dag_id: DAG ID         :type dag_id: unicode         :param execution_date: execution date         :type execution_date: datetime         :return: DagRun corresponding to the given dag_id and execution date             if one exists. None otherwise.         :rtype: airflow.models.DagRun         """ [27424,27850]
===
match
---
name: subquery [28689,28697]
name: subquery [28392,28400]
===
match
---
trailer [11535,11550]
trailer [11238,11253]
===
match
---
atom_expr [28486,28499]
atom_expr [28189,28202]
===
match
---
name: info [15318,15322]
name: info [15021,15025]
===
match
---
arglist [30411,30554]
arglist [30114,30257]
===
match
---
argument [18261,18279]
argument [17964,17982]
===
match
---
suite [17223,17315]
suite [16926,17018]
===
match
---
simple_stmt [25688,25705]
simple_stmt [25391,25408]
===
match
---
name: synchronize_session [31325,31344]
name: synchronize_session [31028,31047]
===
match
---
name: List [28612,28616]
name: List [28315,28319]
===
match
---
trailer [26113,26121]
trailer [25816,25824]
===
match
---
decorator [5697,5712]
decorator [5638,5653]
===
match
---
name: self [16367,16371]
name: self [16070,16074]
===
match
---
suite [18533,18576]
suite [18236,18279]
===
match
---
simple_stmt [2169,2236]
simple_stmt [2110,2177]
===
match
---
comparison [11834,11843]
comparison [11537,11546]
===
match
---
operator: , [11070,11071]
operator: , [10773,10774]
===
match
---
subscriptlist [20406,20420]
subscriptlist [20109,20123]
===
match
---
simple_stmt [26892,26901]
simple_stmt [26595,26604]
===
match
---
name: schedulable_tis [15300,15315]
name: schedulable_tis [15003,15018]
===
match
---
trailer [21730,21950]
trailer [21433,21653]
===
match
---
trailer [12090,12096]
trailer [11793,11799]
===
match
---
name: ti [23549,23551]
name: ti [23252,23254]
===
match
---
atom_expr [18268,18279]
atom_expr [17971,17982]
===
match
---
name: TI [3643,3645]
name: TI [3584,3586]
===
match
---
trailer [21205,21257]
trailer [20908,20960]
===
match
---
trailer [26498,26503]
trailer [26201,26206]
===
match
---
name: unfinished_tasks [15443,15459]
name: unfinished_tasks [15146,15162]
===
match
---
param [29151,29181]
param [28854,28884]
===
match
---
trailer [21370,21374]
trailer [21073,21077]
===
match
---
atom_expr [23341,23367]
atom_expr [23044,23070]
===
match
---
comparison [24565,24588]
comparison [24268,24291]
===
match
---
arglist [28945,29058]
arglist [28648,28761]
===
match
---
operator: , [16365,16366]
operator: , [16068,16069]
===
match
---
arglist [24766,24827]
arglist [24469,24530]
===
match
---
name: DR [10982,10984]
name: DR [10685,10687]
===
match
---
trailer [30596,30652]
trailer [30299,30355]
===
match
---
atom_expr [15411,15430]
atom_expr [15114,15133]
===
match
---
name: finished_tasks [18643,18657]
name: finished_tasks [18346,18360]
===
match
---
fstring_end: " [26300,26301]
fstring_end: " [26003,26004]
===
match
---
name: task_id [19255,19262]
name: task_id [18958,18965]
===
match
---
trailer [5632,5639]
trailer [5573,5580]
===
match
---
arglist [19968,20011]
arglist [19671,19714]
===
match
---
name: Optional [4307,4315]
name: Optional [4248,4256]
===
match
---
name: airflow [1879,1886]
name: airflow [1820,1827]
===
match
---
trailer [10353,10395]
trailer [10056,10098]
===
match
---
arglist [3768,3792]
arglist [3709,3733]
===
match
---
name: filter [28212,28218]
name: filter [27915,27921]
===
match
---
name: last_scheduling_decision [7659,7683]
name: last_scheduling_decision [7362,7386]
===
match
---
not_test [26106,26121]
not_test [25809,25824]
===
match
---
atom_expr [14260,14306]
atom_expr [13963,14009]
===
match
---
fstring_string: dagrun.duration.failed. [25085,25108]
fstring_string: dagrun.duration.failed. [24788,24811]
===
match
---
operator: != [7320,7322]
operator: != [7023,7025]
===
match
---
trailer [17504,17511]
trailer [17207,17214]
===
match
---
argument [18035,18064]
argument [17738,17767]
===
match
---
atom_expr [5330,5351]
atom_expr [5271,5292]
===
match
---
trailer [14102,14108]
trailer [13805,13811]
===
match
---
name: dag_id [3635,3641]
name: dag_id [3576,3582]
===
match
---
name: SUCCESS [24931,24938]
name: SUCCESS [24634,24641]
===
match
---
trailer [27149,27153]
trailer [26852,26856]
===
match
---
atom_expr [7833,7882]
atom_expr [7536,7585]
===
match
---
import_from [1562,1593]
import_from [1503,1534]
===
match
---
if_stmt [24711,24848]
if_stmt [24414,24551]
===
match
---
name: ti [19252,19254]
name: ti [18955,18957]
===
match
---
trailer [5252,5267]
trailer [5193,5208]
===
match
---
trailer [15037,15039]
trailer [14740,14742]
===
match
---
operator: = [21821,21822]
operator: = [21524,21525]
===
match
---
operator: = [20500,20501]
operator: = [20203,20204]
===
match
---
trailer [27193,27195]
trailer [26896,26898]
===
match
---
atom_expr [11676,11684]
atom_expr [11379,11387]
===
match
---
name: external_trigger [10766,10782]
name: external_trigger [10469,10485]
===
match
---
simple_stmt [23493,23500]
simple_stmt [23196,23203]
===
match
---
trailer [20765,20823]
trailer [20468,20526]
===
match
---
expr_stmt [2652,2683]
expr_stmt [2593,2624]
===
match
---
name: Column [3063,3069]
name: Column [3004,3010]
===
match
---
string: 'Hit IntegrityError while creating the TIs for ' [27313,27361]
string: 'Hit IntegrityError while creating the TIs for ' [27016,27064]
===
match
---
operator: @ [28532,28533]
operator: @ [28235,28236]
===
match
---
and_test [26812,26874]
and_test [26515,26577]
===
match
---
tfpdef [25187,25203]
tfpdef [24890,24906]
===
match
---
argument [17298,17313]
argument [17001,17016]
===
match
---
name: utils [1726,1731]
name: utils [1667,1672]
===
match
---
atom_expr [21366,21374]
atom_expr [21069,21077]
===
match
---
trailer [3767,3793]
trailer [3708,3734]
===
match
---
name: log [26495,26498]
name: log [26198,26201]
===
match
---
trailer [24888,24899]
trailer [24591,24602]
===
match
---
name: dag_hash [4377,4385]
name: dag_hash [4318,4326]
===
match
---
operator: = [25204,25205]
operator: = [24907,24908]
===
match
---
trailer [12066,12070]
trailer [11769,11773]
===
match
---
name: ti [25797,25799]
name: ti [25500,25502]
===
match
---
suite [19695,20013]
suite [19398,19716]
===
match
---
name: on_success_callback [30103,30122]
name: on_success_callback [29806,29825]
===
match
---
operator: = [19025,19026]
operator: = [18728,18729]
===
match
---
operator: = [4981,4982]
operator: = [4922,4923]
===
match
---
atom_expr [11457,11584]
atom_expr [11160,11287]
===
match
---
name: ti [21206,21208]
name: ti [20909,20911]
===
match
---
atom_expr [20955,20961]
atom_expr [20658,20664]
===
match
---
simple_stmt [12899,12990]
simple_stmt [12602,12693]
===
match
---
trailer [19883,19903]
trailer [19586,19606]
===
match
---
comparison [10566,10605]
comparison [10269,10308]
===
match
---
operator: == [25963,25965]
operator: == [25666,25668]
===
match
---
name: not_none_state [12071,12085]
name: not_none_state [11774,11788]
===
match
---
trailer [30994,30998]
trailer [30697,30701]
===
match
---
name: datetime [4142,4150]
name: datetime [4083,4091]
===
match
---
trailer [30045,30050]
trailer [29748,29753]
===
match
---
name: self [5382,5386]
name: self [5323,5327]
===
match
---
trailer [3069,3097]
trailer [3010,3038]
===
match
---
comparison [15618,15649]
comparison [15321,15352]
===
match
---
name: State [17175,17180]
name: State [16878,16883]
===
match
---
name: schedulable_tis [20084,20099]
name: schedulable_tis [19787,19802]
===
match
---
name: dag [12281,12284]
name: dag [11984,11987]
===
match
---
atom_expr [20889,20909]
atom_expr [20592,20612]
===
match
---
name: state [12091,12096]
name: state [11794,11799]
===
match
---
suite [4846,4886]
suite [4787,4827]
===
match
---
atom_expr [7307,7319]
atom_expr [7010,7022]
===
match
---
suite [19296,19520]
suite [18999,19223]
===
match
---
operator: } [4681,4682]
operator: } [4622,4623]
===
match
---
name: task_states [19047,19058]
name: task_states [18750,18761]
===
match
---
name: NONE [26683,26687]
name: NONE [26386,26390]
===
match
---
suite [8555,11007]
suite [8258,10710]
===
match
---
arglist [21752,21932]
arglist [21455,21635]
===
match
---
name: base [1478,1482]
name: base [1419,1423]
===
match
---
tfpdef [6519,6529]
tfpdef [6222,6232]
===
match
---
comparison [23341,23378]
comparison [23044,23081]
===
match
---
name: self [26143,26147]
name: self [25846,25850]
===
match
---
expr_stmt [10726,10783]
expr_stmt [10429,10486]
===
match
---
name: self [5044,5048]
name: self [4985,4989]
===
match
---
simple_stmt [817,907]
simple_stmt [817,907]
===
match
---
trailer [20405,20421]
trailer [20108,20124]
===
match
---
operator: = [20227,20228]
operator: = [19930,19931]
===
match
---
if_stmt [5615,5692]
if_stmt [5556,5633]
===
match
---
parameters [5725,5731]
parameters [5666,5672]
===
match
---
name: airflow [1718,1725]
name: airflow [1659,1666]
===
match
---
atom_expr [17548,17567]
atom_expr [17251,17270]
===
match
---
string: 'Doing session rollback.' [27443,27468]
string: 'Doing session rollback.' [27146,27171]
===
match
---
name: bool [21445,21449]
name: bool [21148,21152]
===
match
---
atom_expr [30922,30939]
atom_expr [30625,30642]
===
match
---
expr_stmt [19604,19666]
expr_stmt [19307,19369]
===
match
---
name: DR [10654,10656]
name: DR [10357,10359]
===
match
---
operator: == [4807,4809]
operator: == [4748,4750]
===
match
---
operator: = [4633,4634]
operator: = [4574,4575]
===
match
---
operator: = [4549,4550]
operator: = [4490,4491]
===
match
---
atom_expr [26999,27013]
atom_expr [26702,26716]
===
match
---
simple_stmt [15204,15260]
simple_stmt [14907,14963]
===
match
---
string: "number of scheduleable tasks for %s: %s task(s)" [19823,19872]
string: "number of scheduleable tasks for %s: %s task(s)" [19526,19575]
===
match
---
trailer [31212,31221]
trailer [30915,30924]
===
match
---
string: """The previous DagRun, if there is one""" [13262,13304]
string: """The previous DagRun, if there is one""" [12965,13007]
===
match
---
simple_stmt [4763,4833]
simple_stmt [4704,4774]
===
match
---
atom_expr [21720,21950]
atom_expr [21423,21653]
===
match
---
operator: , [7531,7532]
operator: , [7234,7235]
===
match
---
atom_expr [19763,19771]
atom_expr [19466,19474]
===
match
---
name: Session [25196,25203]
name: Session [24899,24906]
===
match
---
comparison [28976,29007]
comparison [28679,28710]
===
match
---
name: ti [16110,16112]
name: ti [15813,15815]
===
match
---
name: finished_tasks [15394,15408]
name: finished_tasks [15097,15111]
===
match
---
suite [6605,8018]
suite [6308,7721]
===
match
---
strings [27313,27402]
strings [27016,27105]
===
match
---
name: self [4763,4767]
name: self [4704,4708]
===
match
---
name: self [15177,15181]
name: self [14880,14884]
===
match
---
operator: = [20848,20849]
operator: = [20551,20552]
===
match
---
trailer [12070,12086]
trailer [11773,11789]
===
match
---
atom_expr [4763,4777]
atom_expr [4704,4718]
===
match
---
name: self [13072,13076]
name: self [12775,12779]
===
match
---
name: models [2101,2107]
name: models [2042,2048]
===
match
---
simple_stmt [26490,26579]
simple_stmt [26193,26282]
===
match
---
operator: -> [14241,14243]
operator: -> [13944,13946]
===
match
---
atom_expr [10450,10503]
atom_expr [10153,10206]
===
match
---
name: self [24823,24827]
name: self [24526,24530]
===
match
---
atom_expr [24925,24938]
atom_expr [24628,24641]
===
match
---
name: DR [9754,9756]
name: DR [9457,9459]
===
match
---
trailer [28242,28249]
trailer [27945,27952]
===
match
---
operator: = [3786,3787]
operator: = [3727,3728]
===
match
---
name: self [18850,18854]
name: self [18553,18557]
===
match
---
name: subquery [28841,28849]
name: subquery [28544,28552]
===
match
---
operator: = [21131,21132]
operator: = [20834,20835]
===
match
---
atom_expr [25030,25040]
atom_expr [24733,24743]
===
match
---
name: last_scheduling_decision [15053,15077]
name: last_scheduling_decision [14756,14780]
===
match
---
operator: } [13076,13077]
operator: } [12779,12780]
===
match
---
name: self [24360,24364]
name: self [24063,24067]
===
match
---
argument [5201,5219]
argument [5142,5160]
===
match
---
name: all [15614,15617]
name: all [15317,15320]
===
match
---
atom_expr [15211,15259]
atom_expr [14914,14962]
===
match
---
name: Optional [4076,4084]
name: Optional [4017,4025]
===
match
---
name: query [7256,7261]
name: query [6959,6964]
===
match
---
name: SUCCESS [31119,31126]
name: SUCCESS [30822,30829]
===
match
---
trailer [13242,13252]
trailer [12945,12955]
===
match
---
if_stmt [9873,9938]
if_stmt [9576,9641]
===
match
---
name: self [18585,18589]
name: self [18288,18292]
===
match
---
atom_expr [5627,5639]
atom_expr [5568,5580]
===
match
---
operator: , [4254,4255]
operator: , [4195,4196]
===
match
---
name: duration [25124,25132]
name: duration [24827,24835]
===
match
---
name: settings [7779,7787]
name: settings [7482,7490]
===
match
---
trailer [25876,25885]
trailer [25579,25588]
===
match
---
name: DR [10834,10836]
name: DR [10537,10539]
===
match
---
name: dag_id [4476,4482]
name: dag_id [4417,4423]
===
match
---
name: changed_tis [21188,21199]
name: changed_tis [20891,20902]
===
match
---
atom_expr [10743,10762]
atom_expr [10446,10465]
===
match
---
simple_stmt [6614,7030]
simple_stmt [6317,6733]
===
match
---
name: default [2761,2768]
name: default [2702,2709]
===
match
---
trailer [12271,12275]
trailer [11974,11978]
===
match
---
name: __table_args__ [3304,3318]
name: __table_args__ [3245,3259]
===
match
---
expr_stmt [20488,20507]
expr_stmt [20191,20210]
===
match
---
if_stmt [20699,20975]
if_stmt [20402,20678]
===
match
---
name: first [13607,13612]
name: first [13310,13315]
===
match
---
param [23640,23642]
param [23343,23345]
===
match
---
atom_expr [20400,20421]
atom_expr [20103,20124]
===
match
---
atom_expr [18100,18127]
atom_expr [17803,17830]
===
match
---
atom_expr [9829,9852]
atom_expr [9532,9555]
===
match
---
operator: == [13893,13895]
operator: == [13596,13598]
===
match
---
trailer [13116,13120]
trailer [12819,12823]
===
match
---
name: ID_LEN [1490,1496]
name: ID_LEN [1431,1437]
===
match
---
trailer [24266,24273]
trailer [23969,23976]
===
match
---
trailer [20954,20962]
trailer [20657,20665]
===
match
---
operator: = [29199,29200]
operator: = [28902,28903]
===
match
---
trailer [2747,2785]
trailer [2688,2726]
===
match
---
name: execution_date [10060,10074]
name: execution_date [9763,9777]
===
match
---
trailer [24525,24533]
trailer [24228,24236]
===
match
---
fstring [26974,27015]
fstring [26677,26718]
===
match
---
atom_expr [20702,20871]
atom_expr [20405,20574]
===
match
---
argument [17636,17649]
argument [17339,17352]
===
match
---
atom_expr [26340,26353]
atom_expr [26043,26056]
===
match
---
name: self [15893,15897]
name: self [15596,15600]
===
match
---
name: self [11290,11294]
name: self [10993,10997]
===
match
---
name: now [7876,7879]
name: now [7579,7582]
===
match
---
param [8225,8253]
param [7928,7956]
===
match
---
name: typing [822,828]
name: typing [822,828]
===
match
---
decorated [11237,12321]
decorated [10940,12024]
===
match
---
arglist [11495,11574]
arglist [11198,11277]
===
match
---
name: creating_job_id [2961,2976]
name: creating_job_id [2902,2917]
===
match
---
trailer [15624,15641]
trailer [15327,15344]
===
match
---
tfpdef [11296,11340]
tfpdef [10999,11043]
===
match
---
name: merge [26708,26713]
name: merge [26411,26416]
===
match
---
simple_stmt [24602,24684]
simple_stmt [24305,24387]
===
match
---
trailer [7466,7473]
trailer [7169,7176]
===
match
---
tfpdef [8225,8245]
tfpdef [7928,7948]
===
match
---
atom_expr [11495,11504]
atom_expr [11198,11207]
===
match
---
comparison [28236,28259]
comparison [27939,27962]
===
match
---
atom_expr [5802,5816]
atom_expr [5743,5757]
===
match
---
operator: , [13422,13423]
operator: , [13125,13126]
===
match
---
simple_stmt [2609,2648]
simple_stmt [2550,2589]
===
match
---
trailer [16331,16335]
trailer [16034,16038]
===
match
---
name: airflow [1829,1836]
name: airflow [1770,1777]
===
match
---
comparison [12804,12825]
comparison [12507,12528]
===
match
---
name: State [19041,19046]
name: State [18744,18749]
===
match
---
name: str [27659,27662]
name: str [27362,27365]
===
match
---
name: int [29210,29213]
name: int [28913,28916]
===
match
---
dotted_name [25496,25512]
dotted_name [25199,25215]
===
match
---
name: id [6414,6416]
name: id [6117,6119]
===
match
---
trailer [10833,10858]
trailer [10536,10561]
===
match
---
funcdef [20259,21297]
funcdef [19962,21000]
===
match
---
operator: } [16068,16069]
operator: } [15771,15772]
===
match
---
atom_expr [19313,19446]
atom_expr [19016,19149]
===
match
---
name: dag_hash [3253,3261]
name: dag_hash [3194,3202]
===
match
---
name: self [24678,24682]
name: self [24381,24385]
===
match
---
name: TaskInstanceState [2004,2021]
name: TaskInstanceState [1945,1962]
===
match
---
operator: , [7701,7702]
operator: , [7404,7405]
===
match
---
param [13206,13229]
param [12909,12932]
===
match
---
argument [18066,18081]
argument [17769,17784]
===
match
---
expr_stmt [2724,2785]
expr_stmt [2665,2726]
===
match
---
param [21334,21339]
param [21037,21042]
===
match
---
name: self [23095,23099]
name: self [22798,22802]
===
match
---
operator: , [3793,3794]
operator: , [3734,3735]
===
match
---
operator: , [8164,8165]
operator: , [7867,7868]
===
match
---
trailer [11512,11519]
trailer [11215,11222]
===
match
---
name: execution_date [13584,13598]
name: execution_date [13287,13301]
===
match
---
name: not_none_state [11972,11986]
name: not_none_state [11675,11689]
===
match
---
if_stmt [16220,18576]
if_stmt [15923,18279]
===
match
---
name: state [19035,19040]
name: state [18738,18743]
===
match
---
name: schedulable_ti_ids [29890,29908]
name: schedulable_ti_ids [29593,29611]
===
match
---
if_stmt [26450,26688]
if_stmt [26153,26391]
===
match
---
trailer [29089,29091]
trailer [28792,28794]
===
match
---
trailer [21228,21236]
trailer [20931,20939]
===
match
---
argument [16819,16843]
argument [16522,16546]
===
match
---
operator: , [27662,27663]
operator: , [27365,27366]
===
match
---
argument [20793,20822]
argument [20496,20525]
===
match
---
expr_stmt [14936,14999]
expr_stmt [14639,14702]
===
match
---
trailer [21231,21235]
trailer [20934,20938]
===
match
---
name: count [30321,30326]
name: count [30024,30029]
===
match
---
name: state [13498,13503]
name: state [13201,13206]
===
match
---
trailer [18730,18736]
trailer [18433,18439]
===
match
---
name: DagRun [28236,28242]
name: DagRun [27939,27945]
===
match
---
trailer [25113,25120]
trailer [24816,24823]
===
match
---
name: execution_date [12788,12802]
name: execution_date [12491,12505]
===
match
---
suite [25934,26354]
suite [25637,26057]
===
match
---
trailer [29984,29989]
trailer [29687,29692]
===
match
---
arglist [30597,30651]
arglist [30300,30354]
===
match
---
trailer [13606,13612]
trailer [13309,13315]
===
match
---
name: filter [11475,11481]
name: filter [11178,11184]
===
match
---
comparison [11495,11519]
comparison [11198,11222]
===
match
---
simple_stmt [2551,2577]
simple_stmt [2492,2518]
===
match
---
import_as_names [1739,1766]
import_as_names [1680,1707]
===
match
---
expr_stmt [4691,4709]
expr_stmt [4632,4650]
===
match
---
trailer [4767,4777]
trailer [4708,4718]
===
match
---
trailer [13385,13400]
trailer [13088,13103]
===
match
---
operator: = [3937,3938]
operator: = [3878,3879]
===
match
---
name: session [19504,19511]
name: session [19207,19214]
===
match
---
name: creating_job_id [4965,4980]
name: creating_job_id [4906,4921]
===
match
---
operator: , [12387,12388]
operator: , [12090,12091]
===
match
---
operator: , [5219,5220]
operator: , [5160,5161]
===
match
---
simple_stmt [19529,19596]
simple_stmt [19232,19299]
===
match
---
name: DagRun [28191,28197]
name: DagRun [27894,27900]
===
match
---
atom_expr [12311,12320]
atom_expr [12014,12023]
===
match
---
trailer [7625,7752]
trailer [7328,7455]
===
match
---
atom_expr [26490,26578]
atom_expr [26193,26281]
===
match
---
name: self [5802,5806]
name: self [5743,5747]
===
match
---
operator: , [4055,4056]
operator: , [3996,3997]
===
match
---
operator: , [21408,21409]
operator: , [21111,21112]
===
match
---
suite [23123,23143]
suite [22826,22846]
===
match
---
name: Tuple [20400,20405]
name: Tuple [20103,20108]
===
match
---
operator: , [18381,18382]
operator: , [18084,18085]
===
match
---
name: log [27434,27437]
name: log [27137,27140]
===
match
---
operator: = [10553,10554]
operator: = [10256,10257]
===
match
---
name: isoformat [11218,11227]
name: isoformat [10921,10930]
===
match
---
name: c [29040,29041]
name: c [28743,28744]
===
match
---
atom_expr [2934,2956]
atom_expr [2875,2897]
===
match
---
argument [17533,17567]
argument [17236,17270]
===
match
---
import_from [787,816]
import_from [787,816]
===
match
---
funcdef [12863,13121]
funcdef [12566,12824]
===
match
---
name: get_task [19243,19251]
name: get_task [18946,18954]
===
match
---
operator: == [3661,3663]
operator: == [3602,3604]
===
match
---
operator: @ [11237,11238]
operator: @ [10940,10941]
===
match
---
atom_expr [14250,14258]
atom_expr [13953,13961]
===
match
---
import_from [1645,1712]
import_from [1586,1653]
===
match
---
name: st [20702,20704]
name: st [20405,20407]
===
match
---
name: find [8066,8070]
name: find [7769,7773]
===
match
---
expr_stmt [5494,5513]
expr_stmt [5435,5454]
===
match
---
name: exc [1093,1096]
name: exc [1034,1037]
===
match
---
return_stmt [21267,21296]
return_stmt [20970,20999]
===
match
---
import_from [25491,25547]
import_from [25194,25250]
===
match
---
argument [5233,5267]
argument [5174,5208]
===
match
---
comp_op [21096,21102]
comp_op [20799,20805]
===
match
---
operator: = [7998,7999]
operator: = [7701,7702]
===
match
---
name: ti [26412,26414]
name: ti [26115,26117]
===
match
---
name: unfinished_tasks [15693,15709]
name: unfinished_tasks [15396,15412]
===
match
---
tfpdef [20301,20329]
tfpdef [20004,20032]
===
match
---
atom_expr [17332,17359]
atom_expr [17035,17062]
===
match
---
sync_comp_for [17061,17084]
sync_comp_for [16764,16787]
===
match
---
atom_expr [9986,9995]
atom_expr [9689,9698]
===
match
---
name: State [4810,4815]
name: State [4751,4756]
===
match
---
name: start_date [23647,23657]
name: start_date [23350,23360]
===
match
---
atom_expr [26677,26687]
atom_expr [26380,26390]
===
match
---
trailer [8096,8119]
trailer [7799,7822]
===
match
---
name: qry [9975,9978]
name: qry [9678,9681]
===
match
---
trailer [2940,2956]
trailer [2881,2897]
===
match
---
trailer [12180,12187]
trailer [11883,11890]
===
match
---
simple_stmt [13799,14121]
simple_stmt [13502,13824]
===
match
---
name: group_by [28807,28815]
name: group_by [28510,28518]
===
match
---
annassign [18930,18945]
annassign [18633,18648]
===
match
---
atom_expr [5786,5800]
atom_expr [5727,5741]
===
match
---
operator: , [5800,5801]
operator: , [5741,5742]
===
match
---
name: State [25966,25971]
name: State [25669,25674]
===
match
---
name: session [13529,13536]
name: session [13232,13239]
===
match
---
name: DagCallbackRequest [14973,14991]
name: DagCallbackRequest [14676,14694]
===
match
---
operator: , [21434,21435]
operator: , [21137,21138]
===
match
---
suite [26946,27154]
suite [26649,26857]
===
match
---
expr_stmt [10311,10396]
expr_stmt [10014,10099]
===
match
---
atom_expr [8097,8118]
atom_expr [7800,7821]
===
match
---
trailer [18993,19080]
trailer [18696,18783]
===
match
---
name: run_id [2925,2931]
name: run_id [2866,2872]
===
match
---
if_stmt [24185,24317]
if_stmt [23888,24020]
===
match
---
atom_expr [28891,29091]
atom_expr [28594,28794]
===
match
---
simple_stmt [15590,15677]
simple_stmt [15293,15380]
===
match
---
operator: , [14022,14023]
operator: , [13725,13726]
===
match
---
name: finished [19657,19665]
name: finished [19360,19368]
===
match
---
param [12389,12412]
param [12092,12115]
===
match
---
operator: = [11889,11890]
operator: = [11592,11593]
===
match
---
name: none_depends_on_past [17760,17780]
name: none_depends_on_past [17463,17483]
===
match
---
atom_expr [26917,26929]
atom_expr [26620,26632]
===
match
---
simple_stmt [21188,21258]
simple_stmt [20891,20961]
===
match
---
param [11072,11096]
param [10775,10799]
===
match
---
operator: = [10641,10642]
operator: = [10344,10345]
===
match
---
name: filter [12161,12167]
name: filter [11864,11870]
===
match
---
decorator [8023,8037]
decorator [7726,7740]
===
match
---
name: session [21418,21425]
name: session [21121,21128]
===
match
---
atom [28700,28861]
atom [28403,28564]
===
match
---
name: tis [12311,12314]
name: tis [12014,12017]
===
match
---
atom_expr [29982,30018]
atom_expr [29685,29721]
===
match
---
operator: , [8417,8418]
operator: , [8120,8121]
===
match
---
operator: = [19472,19473]
operator: = [19175,19176]
===
match
---
name: UtcDateTime [1911,1922]
name: UtcDateTime [1852,1863]
===
match
---
atom_expr [6438,6446]
atom_expr [6141,6149]
===
match
---
simple_stmt [9754,9766]
simple_stmt [9457,9469]
===
match
---
operator: = [28602,28603]
operator: = [28305,28306]
===
match
---
name: dag [2108,2111]
name: dag [2049,2052]
===
match
---
annassign [2356,2366]
annassign [2297,2307]
===
match
---
expr_stmt [15009,15039]
expr_stmt [14712,14742]
===
match
---
atom_expr [2614,2647]
atom_expr [2555,2588]
===
match
---
trailer [24147,24168]
trailer [23850,23871]
===
match
---
trailer [12284,12293]
trailer [11987,11996]
===
match
---
name: execution_end_date [10517,10535]
name: execution_end_date [10220,10238]
===
match
---
arglist [16676,16884]
arglist [16379,16587]
===
match
---
fstring [24965,25005]
fstring [24668,24708]
===
match
---
string: "dag_run" [2567,2576]
string: "dag_run" [2508,2517]
===
match
---
operator: = [30273,30274]
operator: = [29976,29977]
===
match
---
atom_expr [11665,11694]
atom_expr [11368,11397]
===
match
---
trailer [24510,24516]
trailer [24213,24219]
===
match
---
atom_expr [18667,18713]
atom_expr [18370,18416]
===
match
---
atom_expr [8449,8467]
atom_expr [8152,8170]
===
match
---
trailer [7261,7266]
trailer [6964,6969]
===
match
---
operator: , [17614,17615]
operator: , [17317,17318]
===
match
---
name: state [25035,25040]
name: state [24738,24743]
===
match
---
name: subquery [29031,29039]
name: subquery [28734,28742]
===
match
---
fstring_string: The DAG (.dag) for  [13052,13071]
fstring_string: The DAG (.dag) for  [12755,12774]
===
match
---
atom_expr [7846,7867]
atom_expr [7549,7570]
===
match
---
simple_stmt [4859,4886]
simple_stmt [4800,4827]
===
match
---
sync_comp_for [19733,19794]
sync_comp_for [19436,19497]
===
match
---
name: TI [3622,3624]
name: TI [3563,3565]
===
match
---
simple_stmt [20666,20687]
simple_stmt [20369,20390]
===
match
---
atom_expr [6577,6590]
atom_expr [6280,6293]
===
match
---
name: State [16269,16274]
name: State [15972,15977]
===
match
---
name: Exception [24332,24341]
name: Exception [24035,24044]
===
match
---
operator: = [24866,24867]
operator: = [24569,24570]
===
match
---
name: dag_id [9818,9824]
name: dag_id [9521,9527]
===
match
---
name: dep_context [20743,20754]
name: dep_context [20446,20457]
===
match
---
simple_stmt [5741,5819]
simple_stmt [5682,5760]
===
match
---
arglist [3025,3046]
arglist [2966,2987]
===
match
---
name: State [19474,19479]
name: State [19177,19182]
===
match
---
name: bool [4242,4246]
name: bool [4183,4187]
===
match
---
name: merge [18731,18736]
name: merge [18434,18439]
===
match
---
trailer [8152,8157]
trailer [7855,7860]
===
match
---
trailer [31238,31240]
trailer [30941,30943]
===
match
---
suite [20653,20975]
suite [20356,20678]
===
match
---
trailer [27250,27254]
trailer [26953,26957]
===
match
---
name: success [18020,18027]
name: success [17723,17730]
===
match
---
trailer [28819,28826]
trailer [28522,28529]
===
match
---
name: SCHEDULED [30614,30623]
name: SCHEDULED [30317,30326]
===
match
---
string: 'all_tasks_deadlocked' [18042,18064]
string: 'all_tasks_deadlocked' [17745,17767]
===
match
---
comp_if [12007,12011]
comp_if [11710,11714]
===
match
---
if_stmt [24503,24554]
if_stmt [24206,24257]
===
match
---
suite [5388,5416]
suite [5329,5357]
===
match
---
simple_stmt [9775,9799]
simple_stmt [9478,9502]
===
match
---
atom_expr [30246,30256]
atom_expr [29949,29959]
===
match
---
suite [11105,11232]
suite [10808,10935]
===
match
---
atom_expr [3643,3660]
atom_expr [3584,3601]
===
match
---
atom [30795,31383]
atom [30498,31086]
===
match
---
name: execution_date [28753,28767]
name: execution_date [28456,28470]
===
match
---
name: tis [11665,11668]
name: tis [11368,11371]
===
match
---
operator: = [5776,5777]
operator: = [5717,5718]
===
match
---
tfpdef [8347,8377]
tfpdef [8050,8080]
===
match
---
name: ti [26570,26572]
name: ti [26273,26275]
===
match
---
trailer [13931,13946]
trailer [13634,13649]
===
match
---
expr_stmt [12151,12188]
expr_stmt [11854,11891]
===
match
---
name: session [18066,18073]
name: session [17769,17776]
===
match
---
name: session [18856,18863]
name: session [18559,18566]
===
match
---
trailer [13490,13513]
trailer [13193,13216]
===
match
---
suite [26122,26354]
suite [25825,26057]
===
match
---
operator: , [22115,22116]
operator: , [21818,21819]
===
match
---
if_stmt [15690,16013]
if_stmt [15393,15716]
===
match
---
tfpdef [4264,4283]
tfpdef [4205,4224]
===
match
---
name: DagRun [14060,14066]
name: DagRun [13763,13769]
===
match
---
atom_expr [28612,28626]
atom_expr [28315,28329]
===
match
---
sync_comp_for [11844,11858]
sync_comp_for [11547,11561]
===
match
---
tfpdef [12389,12405]
tfpdef [12092,12108]
===
match
---
simple_stmt [8564,9746]
simple_stmt [8267,9449]
===
match
---
atom_expr [10116,10153]
atom_expr [9819,9856]
===
match
---
operator: , [7438,7439]
operator: , [7141,7142]
===
match
---
trailer [30529,30533]
trailer [30232,30236]
===
match
---
decorator [29107,29124]
decorator [28810,28827]
===
match
---
arglist [5756,5817]
arglist [5697,5758]
===
match
---
operator: = [3016,3017]
operator: = [2957,2958]
===
match
---
name: task_id [25800,25807]
name: task_id [25503,25510]
===
match
---
atom_expr [13379,13400]
atom_expr [13082,13103]
===
match
---
name: utcnow [31176,31182]
name: utcnow [30879,30885]
===
match
---
trailer [4442,4447]
trailer [4383,4388]
===
match
---
for_stmt [25713,26718]
for_stmt [25416,26421]
===
match
---
tfpdef [4065,4094]
tfpdef [4006,4035]
===
match
---
trailer [10118,10133]
trailer [9821,9836]
===
match
---
operator: { [27364,27365]
operator: { [27067,27068]
===
match
---
argument [21206,21256]
argument [20909,20959]
===
match
---
atom_expr [30984,31012]
atom_expr [30687,30715]
===
match
---
decorator [18790,18807]
decorator [18493,18510]
===
match
---
operator: @ [29107,29108]
operator: @ [28810,28811]
===
match
---
arglist [3864,3941]
arglist [3805,3882]
===
match
---
trailer [19656,19665]
trailer [19359,19368]
===
match
---
param [8484,8530]
param [8187,8233]
===
match
---
trailer [27145,27149]
trailer [26848,26852]
===
match
---
name: unfinished_tasks [19678,19694]
name: unfinished_tasks [19381,19397]
===
match
---
decorator [8041,8058]
decorator [7744,7761]
===
match
---
operator: = [21875,21876]
operator: = [21578,21579]
===
match
---
atom_expr [2358,2366]
atom_expr [2299,2307]
===
match
---
atom_expr [18994,19079]
atom_expr [18697,18782]
===
match
---
arglist [31077,31351]
arglist [30780,31054]
===
match
---
atom_expr [16385,16413]
atom_expr [16088,16116]
===
match
---
name: state [19766,19771]
name: state [19469,19474]
===
match
---
operator: , [882,883]
operator: , [882,883]
===
match
---
comparison [30457,30497]
comparison [30160,30200]
===
match
---
name: c [28999,29000]
name: c [28702,28703]
===
match
---
operator: , [6509,6510]
operator: , [6212,6213]
===
match
---
name: log [19813,19816]
name: log [19516,19519]
===
match
---
atom_expr [7655,7683]
atom_expr [7358,7386]
===
match
---
name: external_trigger [23159,23175]
name: external_trigger [22862,22878]
===
match
---
name: self [4574,4578]
name: self [4515,4519]
===
match
---
trailer [9985,10006]
trailer [9688,9709]
===
match
---
trailer [7279,7286]
trailer [6982,6989]
===
match
---
name: partial [12223,12230]
name: partial [11926,11933]
===
match
---
suite [15761,16013]
suite [15464,15716]
===
match
---
atom_expr [4691,4701]
atom_expr [4632,4642]
===
match
---
name: duration [24857,24865]
name: duration [24560,24568]
===
match
---
suite [11860,11922]
suite [11563,11625]
===
match
---
sync_comp_for [16049,16068]
sync_comp_for [15752,15771]
===
match
---
suite [23379,23500]
suite [23082,23203]
===
match
---
name: self [26830,26834]
name: self [26533,26537]
===
match
---
name: dag_id [2652,2658]
name: dag_id [2593,2599]
===
match
---
trailer [10330,10345]
trailer [10033,10048]
===
match
---
name: self [6425,6429]
name: self [6128,6132]
===
match
---
name: e [24345,24346]
name: e [24048,24049]
===
match
---
dotted_name [1970,1989]
dotted_name [1911,1930]
===
match
---
return_stmt [22036,22048]
return_stmt [21739,21751]
===
match
---
trailer [13992,14001]
trailer [13695,13704]
===
match
---
simple_stmt [12037,12109]
simple_stmt [11740,11812]
===
match
---
arglist [26606,26648]
arglist [26309,26351]
===
match
---
operator: = [24104,24105]
operator: = [23807,23808]
===
match
---
name: old_state [20666,20675]
name: old_state [20369,20378]
===
match
---
trailer [12057,12107]
trailer [11760,11810]
===
match
---
name: List [21366,21370]
name: List [21069,21073]
===
match
---
trailer [12839,12845]
trailer [12542,12548]
===
match
---
trailer [24957,24964]
trailer [24660,24667]
===
match
---
name: filters [13476,13483]
name: filters [13179,13186]
===
match
---
atom_expr [2871,2920]
atom_expr [2812,2861]
===
match
---
name: Optional [13709,13717]
name: Optional [13412,13420]
===
match
---
name: dag_id [19422,19428]
name: dag_id [19125,19131]
===
match
---
name: self [6401,6405]
name: self [6104,6108]
===
match
---
comparison [26917,26945]
comparison [26620,26648]
===
match
---
name: filter [12254,12260]
name: filter [11957,11963]
===
match
---
name: __repr__ [5035,5043]
name: __repr__ [4976,4984]
===
match
---
trailer [7557,7567]
trailer [7260,7270]
===
match
---
arglist [12736,12825]
arglist [12439,12528]
===
match
---
name: callback_requests [18156,18173]
name: callback_requests [17859,17876]
===
match
---
fstring_expr [24991,25004]
fstring_expr [24694,24707]
===
match
---
trailer [17335,17359]
trailer [17038,17062]
===
match
---
name: success_states [17046,17060]
name: success_states [16749,16763]
===
match
---
name: self [27246,27250]
name: self [26949,26953]
===
match
---
name: session [20841,20848]
name: session [20544,20551]
===
match
---
name: dep_context [21708,21719]
name: dep_context [21411,21422]
===
match
---
operator: @ [6452,6453]
operator: @ [6155,6156]
===
match
---
name: run_type [7311,7319]
name: run_type [7014,7022]
===
match
---
name: dag_id [27369,27375]
name: dag_id [27072,27078]
===
match
---
param [22111,22116]
param [21814,21819]
===
match
---
name: Base [1498,1502]
name: Base [1439,1443]
===
match
---
suite [17086,17669]
suite [16789,17372]
===
match
---
trailer [13612,13614]
trailer [13315,13317]
===
match
---
name: declared_attr [5698,5711]
name: declared_attr [5639,5652]
===
match
---
suite [26875,26901]
suite [26578,26604]
===
match
---
operator: = [15209,15210]
operator: = [14912,14913]
===
match
---
name: synonym [1222,1229]
name: synonym [1163,1170]
===
match
---
expr_stmt [25586,25632]
expr_stmt [25289,25335]
===
match
---
trailer [28727,28793]
trailer [28430,28496]
===
match
---
name: leaf_ti [17065,17072]
name: leaf_ti [16768,16775]
===
match
---
atom_expr [30519,30553]
atom_expr [30222,30256]
===
match
---
trailer [16341,16372]
trailer [16044,16075]
===
match
---
operator: , [26642,26643]
operator: , [26345,26346]
===
match
---
name: dag_id [6230,6236]
name: dag_id [6052,6058]
===
match
---
expr_stmt [30267,30276]
expr_stmt [29970,29979]
===
match
---
atom_expr [25592,25632]
atom_expr [25295,25335]
===
match
---
trailer [4898,4907]
trailer [4839,4848]
===
match
---
name: leaf_ti [16252,16259]
name: leaf_ti [15955,15962]
===
match
---
name: ti [25768,25770]
name: ti [25471,25473]
===
match
---
trailer [21173,21175]
trailer [20876,20878]
===
match
---
trailer [28998,29000]
trailer [28701,28703]
===
match
---
trailer [6585,6590]
trailer [6288,6293]
===
match
---
name: session [27138,27145]
name: session [26841,26848]
===
match
---
atom [29964,30136]
atom [29667,29839]
===
match
---
name: run_type [4910,4918]
name: run_type [4851,4859]
===
match
---
name: are_dependencies_met [20705,20725]
name: are_dependencies_met [20408,20428]
===
match
---
param [5441,5446]
param [5382,5387]
===
match
---
name: leaf_task_ids [16022,16035]
name: leaf_task_ids [15725,15738]
===
match
---
name: self [21334,21338]
name: self [21037,21041]
===
match
---
name: bool [28465,28469]
name: bool [28168,28172]
===
match
---
atom_expr [2907,2919]
atom_expr [2848,2860]
===
match
---
name: task_instance_mutation_hook [25740,25767]
name: task_instance_mutation_hook [25443,25470]
===
match
---
trailer [28341,28356]
trailer [28044,28059]
===
match
---
name: execution_date [29013,29027]
name: execution_date [28716,28730]
===
match
---
name: t [19567,19568]
name: t [19270,19271]
===
match
---
atom_expr [30095,30122]
atom_expr [29798,29825]
===
match
---
name: warning [24369,24376]
name: warning [24072,24079]
===
match
---
name: dag [26228,26231]
name: dag [25931,25934]
===
match
---
name: ready_tis [20455,20464]
name: ready_tis [20158,20167]
===
match
---
atom_expr [11830,11859]
atom_expr [11533,11562]
===
match
---
trailer [5790,5800]
trailer [5731,5741]
===
match
---
name: MANUAL [14016,14022]
name: MANUAL [13719,13725]
===
match
---
simple_stmt [20455,20480]
simple_stmt [20158,20183]
===
match
---
name: cls [7262,7265]
name: cls [6965,6968]
===
match
---
string: """         Determines the overall state of the DagRun based on the state         of its TaskInstances.          :param session: Sqlalchemy ORM Session         :type session: Session         :param execute_callbacks: Should dag callbacks (success/failure, SLA etc) be invoked             directly (default: true) or recorded as a pending request in the ``callback`` property         :type execute_callbacks: bool         :return: Tuple containing tis that can be scheduled in the current loop & `callback` that             needs to be executed         """ [14317,14872]
string: """         Determines the overall state of the DagRun based on the state         of its TaskInstances.          :param session: Sqlalchemy ORM Session         :type session: Session         :param execute_callbacks: Should dag callbacks (success/failure, SLA etc) be invoked             directly (default: true) or recorded as a pending request in the ``callback`` property         :type execute_callbacks: bool         :return: Tuple containing tis that can be scheduled in the current loop & `callback` that             needs to be executed         """ [14020,14575]
===
match
---
trailer [26668,26674]
trailer [26371,26377]
===
match
---
tfpdef [18856,18872]
tfpdef [18559,18575]
===
match
---
simple_stmt [16022,16070]
simple_stmt [15725,15773]
===
match
---
name: Column [3264,3270]
name: Column [3205,3211]
===
match
---
param [13681,13704]
param [13384,13407]
===
match
---
operator: = [17459,17460]
operator: = [17162,17163]
===
match
---
name: run_type [4337,4345]
name: run_type [4278,4286]
===
match
---
operator: = [4049,4050]
operator: = [3990,3991]
===
match
---
trailer [4241,4247]
trailer [4182,4188]
===
match
---
trailer [6229,6236]
trailer [6051,6058]
===
match
---
trailer [30893,30900]
trailer [30596,30603]
===
match
---
name: session [28891,28898]
name: session [28594,28601]
===
match
---
name: external_trigger [10684,10700]
name: external_trigger [10387,10403]
===
match
---
name: run_type [11050,11058]
name: run_type [10753,10761]
===
match
---
name: tis [20067,20070]
name: tis [19770,19773]
===
match
---
funcdef [21302,22049]
funcdef [21005,21752]
===
match
---
name: self [5460,5464]
name: self [5401,5405]
===
match
---
tfpdef [13681,13697]
tfpdef [13384,13400]
===
match
---
name: callback [18145,18153]
name: callback [17848,17856]
===
match
---
name: self [27282,27286]
name: self [26985,26989]
===
match
---
trailer [10208,10223]
trailer [9911,9926]
===
match
---
name: scheduleable_tasks [20301,20319]
name: scheduleable_tasks [20004,20022]
===
match
---
operator: } [27375,27376]
operator: } [27078,27079]
===
match
---
atom_expr [19041,19058]
atom_expr [18744,18761]
===
match
---
name: is_failure_callback [16819,16838]
name: is_failure_callback [16522,16541]
===
match
---
operator: , [28309,28310]
operator: , [28012,28013]
===
match
---
operator: = [16036,16037]
operator: = [15739,15740]
===
match
---
atom_expr [11508,11519]
atom_expr [11211,11222]
===
match
---
name: update_state [14151,14163]
name: update_state [13854,13866]
===
match
---
atom_expr [5460,5471]
atom_expr [5401,5412]
===
match
---
argument [7991,8006]
argument [7694,7709]
===
match
---
operator: = [8246,8247]
operator: = [7949,7950]
===
match
---
trailer [27295,27416]
trailer [26998,27119]
===
match
---
name: _emit_true_scheduling_delay_stats_for_finished_state [18590,18642]
name: _emit_true_scheduling_delay_stats_for_finished_state [18293,18345]
===
match
---
name: TI [30922,30924]
name: TI [30625,30627]
===
match
---
simple_stmt [11451,11585]
simple_stmt [11154,11288]
===
match
---
name: cls [29009,29012]
name: cls [28712,28715]
===
match
---
arglist [2621,2646]
arglist [2562,2587]
===
match
---
trailer [4005,4010]
trailer [3946,3951]
===
match
---
if_stmt [26914,27154]
if_stmt [26617,26857]
===
match
---
name: st [20678,20680]
name: st [20381,20383]
===
match
---
name: TI [14255,14257]
name: TI [13958,13960]
===
match
---
atom_expr [10654,10662]
atom_expr [10357,10365]
===
match
---
comparison [3643,3678]
comparison [3584,3619]
===
match
---
operator: , [11573,11574]
operator: , [11276,11277]
===
match
---
name: ordered_tis_by_start_date [23598,23623]
name: ordered_tis_by_start_date [23301,23326]
===
match
---
operator: == [28500,28502]
operator: == [28203,28205]
===
match
---
operator: -> [18881,18883]
operator: -> [18584,18586]
===
match
---
trailer [17851,17855]
trailer [17554,17558]
===
match
---
trailer [4815,4822]
trailer [4756,4763]
===
match
---
operator: , [19872,19873]
operator: , [19575,19576]
===
match
---
name: SUCCESS [17181,17188]
name: SUCCESS [16884,16891]
===
match
---
operator: = [3833,3834]
operator: = [3774,3775]
===
match
---
trailer [2877,2920]
trailer [2818,2861]
===
match
---
atom_expr [17388,17668]
atom_expr [17091,17371]
===
match
---
trailer [13542,13550]
trailer [13245,13253]
===
match
---
name: queued_at [5662,5671]
name: queued_at [5603,5612]
===
match
---
trailer [3076,3080]
trailer [3017,3021]
===
match
---
atom_expr [27282,27416]
atom_expr [26985,27119]
===
match
---
trailer [5530,5539]
trailer [5471,5480]
===
match
---
if_stmt [10251,10607]
if_stmt [9954,10310]
===
match
---
atom_expr [2941,2955]
atom_expr [2882,2896]
===
match
---
trailer [19816,19822]
trailer [19519,19525]
===
match
---
trailer [25796,25808]
trailer [25499,25511]
===
match
---
operator: , [20115,20116]
operator: , [19818,19819]
===
match
---
name: fileloc [18232,18239]
name: fileloc [17935,17942]
===
match
---
suite [30203,30258]
suite [29906,29961]
===
match
---
name: partial [26114,26121]
name: partial [25817,25824]
===
match
---
suite [27712,28421]
suite [27415,28124]
===
match
---
operator: = [6436,6437]
operator: = [6139,6140]
===
match
---
operator: , [15949,15950]
operator: , [15652,15653]
===
match
---
name: desc [13599,13603]
name: desc [13302,13306]
===
match
---
atom_expr [6425,6435]
atom_expr [6128,6138]
===
match
---
name: ti [29982,29984]
name: ti [29685,29687]
===
match
---
atom_expr [13403,13422]
atom_expr [13106,13125]
===
match
---
trailer [25567,25575]
trailer [25270,25278]
===
match
---
trailer [11668,11675]
trailer [11371,11378]
===
match
---
suite [30773,31384]
suite [30476,31087]
===
match
---
trailer [26973,27022]
trailer [26676,26725]
===
match
---
trailer [19242,19251]
trailer [18945,18954]
===
match
---
trailer [20905,20909]
trailer [20608,20612]
===
match
---
atom_expr [17240,17314]
atom_expr [16943,17017]
===
match
---
atom_expr [14244,14307]
atom_expr [13947,14010]
===
match
---
arglist [24965,25015]
arglist [24668,24718]
===
match
---
operator: , [1443,1444]
operator: , [1384,1385]
===
match
---
name: state [5441,5446]
name: state [5382,5387]
===
match
---
name: TI [21371,21373]
name: TI [21074,21076]
===
match
---
name: self [18737,18741]
name: self [18440,18444]
===
match
---
name: execution_date [13386,13400]
name: execution_date [13089,13103]
===
match
---
atom_expr [24148,24167]
atom_expr [23851,23870]
===
match
---
simple_stmt [19808,19905]
simple_stmt [19511,19608]
===
match
---
name: session [14179,14186]
name: session [13882,13889]
===
match
---
string: 'Marking run %s successful' [17113,17140]
string: 'Marking run %s successful' [16816,16843]
===
match
---
operator: = [8209,8210]
operator: = [7912,7913]
===
match
---
name: self [19808,19812]
name: self [19511,19515]
===
match
---
simple_stmt [4611,4652]
simple_stmt [4552,4593]
===
match
---
trailer [10115,10154]
trailer [9818,9857]
===
match
---
trailer [7616,7625]
trailer [7319,7328]
===
match
---
simple_stmt [18723,18743]
simple_stmt [18426,18446]
===
match
---
decorated [5697,5819]
decorated [5638,5760]
===
match
---
trailer [24152,24167]
trailer [23855,23870]
===
match
---
operator: , [10074,10075]
operator: , [9777,9778]
===
match
---
name: all [21170,21173]
name: all [20873,20876]
===
match
---
name: log [19318,19321]
name: log [19021,19024]
===
match
---
param [3989,4018]
param [3930,3959]
===
match
---
comparison [13986,14022]
comparison [13689,13725]
===
match
---
trailer [4788,4795]
trailer [4729,4736]
===
match
---
operator: , [24821,24822]
operator: , [24524,24525]
===
match
---
name: self [25181,25185]
name: self [24884,24888]
===
match
---
suite [2402,31406]
suite [2343,31109]
===
match
---
atom_expr [25563,25577]
atom_expr [25266,25280]
===
match
---
trailer [26414,26420]
trailer [26117,26123]
===
match
---
expr_stmt [2688,2719]
expr_stmt [2629,2660]
===
match
---
simple_stmt [18915,18946]
simple_stmt [18618,18649]
===
match
---
name: default [2899,2906]
name: default [2840,2847]
===
match
---
trailer [18560,18575]
trailer [18263,18278]
===
match
---
operator: = [4908,4909]
operator: = [4849,4850]
===
match
---
param [11349,11361]
param [11052,11064]
===
match
---
trailer [15619,15624]
trailer [15322,15327]
===
match
---
fstring [13050,13094]
fstring [12753,12797]
===
match
---
name: self [4500,4504]
name: self [4441,4445]
===
match
---
operator: = [21916,21917]
operator: = [21619,21620]
===
match
---
name: Stats [26963,26968]
name: Stats [26666,26671]
===
match
---
operator: = [12406,12407]
operator: = [12109,12110]
===
match
---
name: sqlalchemy [1124,1134]
name: sqlalchemy [1065,1075]
===
match
---
operator: = [20182,20183]
operator: = [19885,19886]
===
match
---
suite [7109,7166]
suite [6812,6869]
===
match
---
name: self [11508,11512]
name: self [11211,11215]
===
match
---
operator: -> [13231,13233]
operator: -> [12934,12936]
===
match
---
trailer [7875,7879]
trailer [7578,7582]
===
match
---
name: session [12698,12705]
name: session [12401,12408]
===
match
---
name: SCHEDULEABLE_STATES [1693,1712]
name: SCHEDULEABLE_STATES [1634,1653]
===
match
---
param [5726,5730]
param [5667,5671]
===
match
---
name: count [31400,31405]
name: count [31103,31108]
===
match
---
name: relationship [1208,1220]
name: relationship [1149,1161]
===
match
---
name: List [2276,2280]
name: List [2217,2221]
===
match
---
decorators [28532,28566]
decorators [28235,28269]
===
match
---
operator: , [8215,8216]
operator: , [7918,7919]
===
match
---
operator: } [27013,27014]
operator: } [26716,26717]
===
match
---
name: default [3034,3041]
name: default [2975,2982]
===
match
---
name: timezone [5674,5682]
name: timezone [5615,5623]
===
match
---
trailer [14015,14022]
trailer [13718,13725]
===
match
---
name: info [27255,27259]
name: info [26958,26962]
===
match
---
name: tis [12043,12046]
name: tis [11746,11749]
===
match
---
operator: = [10193,10194]
operator: = [9896,9897]
===
match
---
name: none_task_concurrency [15590,15611]
name: none_task_concurrency [15293,15314]
===
match
---
name: sqlalchemy [1893,1903]
name: sqlalchemy [1834,1844]
===
match
---
name: state [25957,25962]
name: state [25660,25665]
===
match
---
trailer [11904,11910]
trailer [11607,11613]
===
match
---
name: t [19549,19550]
name: t [19252,19253]
===
match
---
argument [5766,5817]
argument [5707,5758]
===
match
---
operator: == [10846,10848]
operator: == [10549,10551]
===
match
---
name: callback [16607,16615]
name: callback [16310,16318]
===
match
---
argument [30626,30651]
argument [30329,30354]
===
match
---
name: start_date [23734,23744]
name: start_date [23437,23447]
===
match
---
name: tis_filter [21085,21095]
name: tis_filter [20788,20798]
===
match
---
operator: @ [12326,12327]
operator: @ [12029,12030]
===
match
---
name: ti [19419,19421]
name: ti [19122,19124]
===
match
---
operator: = [15612,15613]
operator: = [15315,15316]
===
match
---
name: state [12001,12006]
name: state [11704,11709]
===
match
---
atom_expr [11619,11641]
atom_expr [11322,11344]
===
match
---
simple_stmt [5397,5416]
simple_stmt [5338,5357]
===
match
---
atom_expr [18546,18575]
atom_expr [18249,18278]
===
match
---
name: state [13507,13512]
name: state [13210,13215]
===
match
---
trailer [10938,10951]
trailer [10641,10654]
===
match
---
dotted_name [1650,1685]
dotted_name [1591,1626]
===
match
---
operator: = [4401,4402]
operator: = [4342,4343]
===
match
---
simple_stmt [7825,7883]
simple_stmt [7528,7586]
===
match
---
simple_stmt [2862,2921]
simple_stmt [2803,2862]
===
match
---
trailer [26682,26687]
trailer [26385,26390]
===
match
---
trailer [19967,20012]
trailer [19670,19715]
===
match
---
parameters [3965,4461]
parameters [3906,4402]
===
match
---
simple_stmt [9969,10007]
simple_stmt [9672,9710]
===
match
---
name: Optional [4133,4141]
name: Optional [4074,4082]
===
match
---
trailer [28904,28909]
trailer [28607,28612]
===
match
---
atom_expr [2803,2822]
atom_expr [2744,2763]
===
match
---
testlist_comp [3719,3741]
testlist_comp [3660,3682]
===
match
---
trailer [3448,3468]
trailer [3389,3409]
===
match
---
name: order_by [13568,13576]
name: order_by [13271,13279]
===
match
---
atom_expr [19808,19904]
atom_expr [19511,19607]
===
match
---
operator: , [18018,18019]
operator: , [17721,17722]
===
match
---
name: finished [5584,5592]
name: finished [5525,5533]
===
match
---
atom_expr [11533,11550]
atom_expr [11236,11253]
===
match
---
simple_stmt [13262,13305]
simple_stmt [12965,13008]
===
match
---
trailer [17030,17036]
trailer [16733,16739]
===
match
---
trailer [13192,13197]
trailer [12895,12900]
===
match
---
and_test [26074,26121]
and_test [25777,25824]
===
match
---
simple_stmt [1172,1230]
simple_stmt [1113,1171]
===
match
---
operator: , [26645,26646]
operator: , [26348,26349]
===
match
---
name: false [7524,7529]
name: false [7227,7232]
===
match
---
comparison [7090,7108]
comparison [6793,6811]
===
match
---
trailer [25049,25056]
trailer [24752,24759]
===
match
---
operator: , [2002,2003]
operator: , [1943,1944]
===
match
---
name: run_id [6341,6347]
name: run_id [6082,6088]
===
match
---
funcdef [5716,5819]
funcdef [5657,5760]
===
match
---
name: execution_date [11072,11086]
name: execution_date [10775,10789]
===
match
---
name: sqlalchemy [1082,1092]
name: sqlalchemy [1023,1033]
===
match
---
name: all [11830,11833]
name: all [11533,11536]
===
match
---
trailer [23319,23337]
trailer [23022,23040]
===
match
---
if_stmt [23151,23196]
if_stmt [22854,22899]
===
match
---
number: 1 [27020,27021]
number: 1 [26723,26724]
===
match
---
try_stmt [27163,27598]
try_stmt [26866,27301]
===
match
---
return_stmt [28479,28526]
return_stmt [28182,28229]
===
match
---
annassign [14944,14999]
annassign [14647,14702]
===
match
---
operator: = [4011,4012]
operator: = [3952,3953]
===
match
---
trailer [23288,23290]
trailer [22991,22993]
===
match
---
not_test [17811,17833]
not_test [17514,17536]
===
match
---
atom_expr [18723,18742]
atom_expr [18426,18445]
===
match
---
comparison [3622,3641]
comparison [3563,3582]
===
match
---
trailer [28218,28389]
trailer [27921,28092]
===
match
---
if_stmt [23757,24317]
if_stmt [23460,24020]
===
match
---
comparison [5460,5480]
comparison [5401,5421]
===
match
---
suite [20927,20975]
suite [20630,20678]
===
match
---
operator: { [20444,20445]
operator: { [20147,20148]
===
match
---
atom_expr [14955,14991]
atom_expr [14658,14694]
===
match
---
name: external_trigger [28284,28300]
name: external_trigger [27987,28003]
===
match
---
trailer [17022,17085]
trailer [16725,16788]
===
match
---
tfpdef [13206,13222]
tfpdef [12909,12925]
===
match
---
name: airflow [2027,2034]
name: airflow [1968,1975]
===
match
---
operator: = [4483,4484]
operator: = [4424,4425]
===
match
---
name: skip_locked [1937,1948]
name: skip_locked [1878,1889]
===
match
---
trailer [16112,16120]
trailer [15815,15823]
===
match
---
name: State [18561,18566]
name: State [18264,18269]
===
match
---
return_stmt [12677,12857]
return_stmt [12380,12560]
===
match
---
name: dag_id [28980,28986]
name: dag_id [28683,28689]
===
match
---
name: in_ [12272,12275]
name: in_ [11975,11978]
===
match
---
operator: , [21931,21932]
operator: , [21634,21635]
===
match
---
trailer [17174,17189]
trailer [16877,16892]
===
match
---
string: "Failed to get task '%s' for dag '%s'. Marking it as removed." [19351,19413]
string: "Failed to get task '%s' for dag '%s'. Marking it as removed." [19054,19116]
===
match
---
name: queued_at [4768,4777]
name: queued_at [4709,4718]
===
match
---
operator: = [11341,11342]
operator: = [11044,11045]
===
match
---
except_clause [24325,24346]
except_clause [24028,24049]
===
match
---
expr_stmt [18915,18945]
expr_stmt [18618,18648]
===
match
---
import_from [1312,1340]
import_from [1253,1281]
===
match
---
name: get_dag [23281,23288]
name: get_dag [22984,22991]
===
match
---
simple_stmt [19463,19488]
simple_stmt [19166,19191]
===
match
---
name: String [2668,2674]
name: String [2609,2615]
===
match
---
name: Any [4279,4282]
name: Any [4220,4223]
===
match
---
operator: = [18315,18316]
operator: = [18018,18019]
===
match
---
name: self [24884,24888]
name: self [24587,24591]
===
match
---
atom_expr [2741,2785]
atom_expr [2682,2726]
===
match
---
name: execution_start_date [8427,8447]
name: execution_start_date [8130,8150]
===
match
---
operator: , [3641,3642]
operator: , [3582,3583]
===
match
---
testlist_comp [19730,19794]
testlist_comp [19433,19497]
===
match
---
operator: @ [14126,14127]
operator: @ [13829,13830]
===
match
---
atom [31077,31303]
atom [30780,31006]
===
match
---
operator: = [15518,15519]
operator: = [15221,15222]
===
match
---
name: info [17108,17112]
name: info [16811,16815]
===
match
---
name: List [2358,2362]
name: List [2299,2303]
===
match
---
name: set_state [5807,5816]
name: set_state [5748,5757]
===
match
---
expr_stmt [20431,20446]
expr_stmt [20134,20149]
===
match
---
name: e [24434,24435]
name: e [24137,24138]
===
match
---
name: dag [25557,25560]
name: dag [25260,25263]
===
match
---
atom_expr [27380,27399]
atom_expr [27083,27102]
===
match
---
name: limit [7933,7938]
name: limit [7636,7641]
===
match
---
trailer [7722,7737]
trailer [7425,7440]
===
match
---
trailer [14086,14088]
trailer [13789,13791]
===
match
---
simple_stmt [11885,11922]
simple_stmt [11588,11625]
===
match
---
operator: = [3107,3108]
operator: = [3048,3049]
===
match
---
fstring_start: f' [25083,25085]
fstring_start: f' [24786,24788]
===
match
---
name: dag_id [24267,24273]
name: dag_id [23970,23976]
===
match
---
name: session [7991,7998]
name: session [7694,7701]
===
match
---
operator: = [20066,20067]
operator: = [19769,19770]
===
match
---
simple_stmt [1874,1965]
simple_stmt [1815,1906]
===
match
---
expr_stmt [15394,15430]
expr_stmt [15097,15133]
===
match
---
expr_stmt [2582,2603]
expr_stmt [2523,2544]
===
match
---
param [12375,12388]
param [12078,12091]
===
match
---
name: airflow [1346,1353]
name: airflow [1287,1294]
===
match
---
arith_expr [24868,24899]
arith_expr [24571,24602]
===
match
---
simple_stmt [12677,12858]
simple_stmt [12380,12561]
===
match
---
trailer [14050,14059]
trailer [13753,13762]
===
match
---
name: ti [26329,26331]
name: ti [26032,26034]
===
match
---
simple_stmt [24749,24829]
simple_stmt [24452,24532]
===
match
---
trailer [5212,5219]
trailer [5153,5160]
===
match
---
name: task_ids [25784,25792]
name: task_ids [25487,25495]
===
match
---
name: func [28740,28744]
name: func [28443,28447]
===
match
---
name: qry [10896,10899]
name: qry [10599,10602]
===
match
---
operator: == [5624,5626]
operator: == [5565,5567]
===
match
---
operator: , [21950,21951]
operator: , [21653,21654]
===
match
---
name: start_date [24889,24899]
name: start_date [24592,24602]
===
match
---
tfpdef [4215,4247]
tfpdef [4156,4188]
===
match
---
expr_stmt [16078,16138]
expr_stmt [15781,15841]
===
match
---
name: self [27380,27384]
name: self [27083,27087]
===
match
---
dotted_name [1567,1580]
dotted_name [1508,1521]
===
match
---
suite [20543,20586]
suite [20246,20289]
===
match
---
name: schedulable_tis [18759,18774]
name: schedulable_tis [18462,18477]
===
match
---
atom_expr [10461,10478]
atom_expr [10164,10181]
===
match
---
name: self [19089,19093]
name: self [18792,18796]
===
match
---
name: self [13896,13900]
name: self [13599,13603]
===
match
---
expr_stmt [2609,2647]
expr_stmt [2550,2588]
===
match
---
simple_stmt [16327,16373]
simple_stmt [16030,16076]
===
match
---
return_stmt [13105,13120]
return_stmt [12808,12823]
===
match
---
suite [24589,24703]
suite [24292,24406]
===
match
---
import_as_name [1543,1561]
import_as_name [1484,1502]
===
match
---
string: 'Failed to record duration of %s: start_date is not set.' [24619,24676]
string: 'Failed to record duration of %s: start_date is not set.' [24322,24379]
===
match
---
name: DR [10206,10208]
name: DR [9909,9911]
===
match
---
name: last_scheduling_decision [3202,3226]
name: last_scheduling_decision [3143,3167]
===
match
---
simple_stmt [15009,15040]
simple_stmt [14712,14743]
===
match
---
name: RUNNING [26094,26101]
name: RUNNING [25797,25804]
===
match
---
atom_expr [3018,3047]
atom_expr [2959,2988]
===
match
---
string: 'dag_id' [3449,3457]
string: 'dag_id' [3390,3398]
===
match
---
name: self [24565,24569]
name: self [24268,24272]
===
match
---
name: query [28899,28904]
name: query [28602,28607]
===
match
---
simple_stmt [23686,23745]
simple_stmt [23389,23448]
===
match
---
name: tis [12151,12154]
name: tis [11854,11857]
===
match
---
name: state [6430,6435]
name: state [6133,6138]
===
match
---
name: session [9781,9788]
name: session [9484,9491]
===
match
---
fstring_start: f" [13050,13052]
fstring_start: f" [12753,12755]
===
match
---
name: reason [17280,17286]
name: reason [16983,16989]
===
match
---
trailer [10198,10205]
trailer [9901,9908]
===
match
---
atom_expr [23644,23657]
atom_expr [23347,23360]
===
match
---
trailer [14108,14110]
trailer [13811,13813]
===
match
---
arglist [18014,18081]
arglist [17717,17784]
===
match
---
atom_expr [27090,27121]
atom_expr [26793,26824]
===
match
---
simple_stmt [27246,27270]
simple_stmt [26949,26973]
===
match
---
try_stmt [19197,19520]
try_stmt [18900,19223]
===
match
---
simple_stmt [11972,12013]
simple_stmt [11675,11716]
===
match
---
name: ti [16090,16092]
name: ti [15793,15795]
===
match
---
simple_stmt [5059,5363]
simple_stmt [5000,5304]
===
match
---
fstring_end: ' [27401,27402]
fstring_end: ' [27104,27105]
===
match
---
not_test [23307,23337]
not_test [23010,23040]
===
match
---
trailer [20725,20871]
trailer [20428,20574]
===
match
---
atom_expr [5674,5691]
atom_expr [5615,5632]
===
match
---
simple_stmt [18954,18974]
simple_stmt [18657,18677]
===
match
---
atom_expr [7927,7950]
atom_expr [7630,7653]
===
match
---
simple_stmt [2582,2604]
simple_stmt [2523,2545]
===
match
---
simple_stmt [15300,15339]
simple_stmt [15003,15042]
===
match
---
return_stmt [20022,20253]
return_stmt [19725,19956]
===
match
---
argument [13558,13566]
argument [13261,13269]
===
match
---
name: DepContext [1634,1644]
name: DepContext [1575,1585]
===
match
---
argument [31325,31350]
argument [31028,31053]
===
match
---
operator: , [1756,1757]
operator: , [1697,1698]
===
match
---
trailer [12096,12100]
trailer [11799,11803]
===
match
---
parameters [13674,13705]
parameters [13377,13408]
===
match
---
name: state [19569,19574]
name: state [19272,19277]
===
match
---
arglist [28976,29056]
arglist [28679,28759]
===
match
---
if_stmt [29961,30258]
if_stmt [29664,29961]
===
match
---
comp_op [10701,10707]
comp_op [10404,10410]
===
match
---
operator: , [1948,1949]
operator: , [1889,1890]
===
match
---
trailer [24128,24147]
trailer [23831,23850]
===
match
---
name: session [27579,27586]
name: session [27282,27289]
===
match
---
atom_expr [5007,5025]
atom_expr [4948,4966]
===
match
---
name: FAILED [16406,16412]
name: FAILED [16109,16115]
===
match
---
trailer [8240,8245]
trailer [7943,7948]
===
match
---
atom_expr [30876,30885]
atom_expr [30579,30588]
===
match
---
trailer [5292,5299]
trailer [5233,5240]
===
match
---
simple_stmt [18667,18714]
simple_stmt [18370,18417]
===
match
---
if_stmt [10046,10243]
if_stmt [9749,9946]
===
match
---
name: execution_date [28360,28374]
name: execution_date [28063,28077]
===
match
---
name: start_date [4592,4602]
name: start_date [4533,4543]
===
match
---
atom_expr [10834,10845]
atom_expr [10537,10548]
===
match
---
name: self [5657,5661]
name: self [5598,5602]
===
match
---
suite [17977,18083]
suite [17680,17786]
===
match
---
name: self [18667,18671]
name: self [18370,18374]
===
match
---
name: unfinished_tasks [19529,19545]
name: unfinished_tasks [19232,19248]
===
match
---
trailer [12222,12230]
trailer [11925,11933]
===
match
---
param [29145,29150]
param [28848,28853]
===
match
---
name: dag_id [17505,17511]
name: dag_id [17208,17214]
===
match
---
name: unfinished_tasks [21634,21650]
name: unfinished_tasks [21337,21353]
===
match
---
operator: , [17140,17141]
operator: , [16843,16844]
===
match
---
name: timezone [15022,15030]
name: timezone [14725,14733]
===
match
---
expr_stmt [2551,2576]
expr_stmt [2492,2517]
===
match
---
name: backref [1199,1206]
name: backref [1140,1147]
===
match
---
name: session [13206,13213]
name: session [12909,12916]
===
match
---
atom [15832,16012]
atom [15535,15715]
===
match
---
operator: { [31077,31078]
operator: { [30780,30781]
===
match
---
operator: = [20140,20141]
operator: = [19843,19844]
===
match
---
and_test [26389,26437]
and_test [26092,26140]
===
match
---
operator: = [4512,4513]
operator: = [4453,4454]
===
match
---
not_test [15524,15550]
not_test [15227,15253]
===
match
---
comparison [16252,16288]
comparison [15955,15991]
===
match
---
operator: , [31240,31241]
operator: , [30943,30944]
===
match
---
suite [11603,12189]
suite [11306,11892]
===
match
---
name: session [6539,6546]
name: session [6242,6249]
===
match
---
trailer [10460,10503]
trailer [10163,10206]
===
match
---
fstring_start: f' [24965,24967]
fstring_start: f' [24668,24670]
===
match
---
expr_stmt [27039,27073]
expr_stmt [26742,26776]
===
match
---
name: depends_on_past [15535,15550]
name: depends_on_past [15238,15253]
===
match
---
suite [25212,27598]
suite [24915,27301]
===
match
---
operator: , [19413,19414]
operator: , [19116,19117]
===
match
---
name: session [20849,20856]
name: session [20552,20559]
===
match
---
import_as_names [1490,1502]
import_as_names [1431,1443]
===
match
---
name: filter [7280,7286]
name: filter [6983,6989]
===
match
---
operator: < [13401,13402]
operator: < [13104,13105]
===
match
---
name: tis [25723,25726]
name: tis [25426,25429]
===
match
---
fstring_expr [24262,24274]
fstring_expr [23965,23977]
===
match
---
trailer [12218,12222]
trailer [11921,11925]
===
match
---
atom_expr [28990,29007]
atom_expr [28693,28710]
===
match
---
comparison [5563,5592]
comparison [5504,5533]
===
match
---
atom_expr [17023,17036]
atom_expr [16726,16739]
===
match
---
simple_stmt [11114,11173]
simple_stmt [10817,10876]
===
match
---
operator: = [25623,25624]
operator: = [25326,25327]
===
match
---
simple_stmt [3554,3801]
simple_stmt [3495,3742]
===
match
---
simple_stmt [27579,27598]
simple_stmt [27282,27301]
===
match
---
name: success [17266,17273]
name: success [16969,16976]
===
match
---
trailer [23573,23584]
trailer [23276,23287]
===
match
---
operator: * [13558,13559]
operator: * [13261,13262]
===
match
---
name: List [866,870]
name: List [866,870]
===
match
---
operator: , [26304,26305]
operator: , [26007,26008]
===
match
---
expr_stmt [18954,18973]
expr_stmt [18657,18676]
===
match
---
name: state [4801,4806]
name: state [4742,4747]
===
match
---
name: dag [16690,16693]
name: dag [16393,16396]
===
match
---
operator: = [26675,26676]
operator: = [26378,26379]
===
match
---
trailer [20470,20474]
trailer [20173,20177]
===
match
---
operator: , [3351,3352]
operator: , [3292,3293]
===
match
---
name: self [4471,4475]
name: self [4412,4416]
===
match
---
simple_stmt [9897,9938]
simple_stmt [9600,9641]
===
match
---
operator: { [11190,11191]
operator: { [10893,10894]
===
match
---
name: qry [10317,10320]
name: qry [10020,10023]
===
match
---
name: self [28456,28460]
name: self [28159,28163]
===
match
---
trailer [21070,21072]
trailer [20773,20775]
===
match
---
atom_expr [7287,7296]
atom_expr [6990,6999]
===
match
---
atom_expr [24360,24438]
atom_expr [24063,24141]
===
match
---
name: session [12389,12396]
name: session [12092,12099]
===
match
---
name: classmethod [6453,6464]
name: classmethod [6156,6167]
===
match
---
atom_expr [28335,28356]
atom_expr [28038,28059]
===
match
---
name: state [23100,23105]
name: state [22803,22808]
===
match
---
trailer [17855,17861]
trailer [17558,17564]
===
match
---
comparison [10743,10782]
comparison [10446,10485]
===
match
---
simple_stmt [23136,23143]
simple_stmt [22839,22846]
===
match
---
atom_expr [12698,12847]
atom_expr [12401,12550]
===
match
---
string: 'dag_run' [3768,3777]
string: 'dag_run' [3709,3718]
===
match
---
name: finished_tasks [15416,15430]
name: finished_tasks [15119,15133]
===
match
---
operator: , [16741,16742]
operator: , [16444,16445]
===
match
---
name: TI [27044,27046]
name: TI [26747,26749]
===
match
---
name: state [11853,11858]
name: state [11556,11561]
===
match
---
name: synonym [5748,5755]
name: synonym [5689,5696]
===
match
---
parameters [22110,22130]
parameters [21813,21833]
===
match
---
operator: = [3569,3570]
operator: = [3510,3511]
===
match
---
argument [16528,16543]
argument [16231,16246]
===
match
---
decorated [14126,18785]
decorated [13829,18488]
===
match
---
operator: = [2659,2660]
operator: = [2600,2601]
===
match
---
string: 'Deadlock; marking run %s failed' [17862,17895]
string: 'Deadlock; marking run %s failed' [17565,17598]
===
match
---
simple_stmt [25586,25633]
simple_stmt [25289,25336]
===
match
---
operator: , [20070,20071]
operator: , [19773,19774]
===
match
---
name: no_backfills [8311,8323]
name: no_backfills [8014,8026]
===
match
---
simple_stmt [5657,5692]
simple_stmt [5598,5633]
===
match
---
name: schedulable_tis [29151,29166]
name: schedulable_tis [28854,28869]
===
match
---
simple_stmt [25740,25772]
simple_stmt [25443,25475]
===
match
---
testlist_comp [19549,19594]
testlist_comp [19252,19297]
===
match
---
name: str [4044,4047]
name: str [3985,3988]
===
match
---
name: str [8241,8244]
name: str [7944,7947]
===
match
---
atom_expr [14946,14992]
atom_expr [14649,14695]
===
match
---
name: Column [2741,2747]
name: Column [2682,2688]
===
match
---
suite [30308,30667]
suite [30011,30370]
===
match
---
trailer [31055,31369]
trailer [30758,31072]
===
match
---
lambdef [23633,23657]
lambdef [23336,23360]
===
match
---
operator: } [15154,15155]
operator: } [14857,14858]
===
match
---
operator: == [10224,10226]
operator: == [9927,9929]
===
match
---
name: ID_LEN [2948,2954]
name: ID_LEN [2889,2895]
===
match
---
simple_stmt [1312,1341]
simple_stmt [1253,1282]
===
match
---
name: TISchedulingDecision [20029,20049]
name: TISchedulingDecision [19732,19752]
===
match
---
name: execution_date [10227,10241]
name: execution_date [9930,9944]
===
match
---
name: _get_ready_tis [19953,19967]
name: _get_ready_tis [19656,19670]
===
match
---
atom_expr [10928,10951]
atom_expr [10631,10654]
===
match
---
if_stmt [24908,25134]
if_stmt [24611,24837]
===
match
---
name: is_failure_callback [17589,17608]
name: is_failure_callback [17292,17311]
===
match
---
simple_stmt [3202,3249]
simple_stmt [3143,3190]
===
match
---
operator: , [6529,6530]
operator: , [6232,6233]
===
match
---
name: ti [25717,25719]
name: ti [25420,25422]
===
match
---
name: Session [18865,18872]
name: Session [18568,18575]
===
match
---
operator: = [8523,8524]
operator: = [8226,8227]
===
match
---
operator: , [3875,3876]
operator: , [3816,3817]
===
match
---
operator: = [2739,2740]
operator: = [2680,2681]
===
match
---
trailer [31048,31055]
trailer [30751,30758]
===
match
---
name: orm [1188,1191]
name: orm [1129,1132]
===
match
---
funcdef [5421,5692]
funcdef [5362,5633]
===
match
---
expr_stmt [30321,30666]
expr_stmt [30024,30369]
===
match
---
operator: , [2759,2760]
operator: , [2700,2701]
===
match
---
trailer [5498,5505]
trailer [5439,5446]
===
match
---
name: self [17260,17264]
name: self [16963,16967]
===
match
---
param [6565,6598]
param [6268,6301]
===
match
---
name: self [13171,13175]
name: self [12874,12878]
===
match
---
operator: , [19033,19034]
operator: , [18736,18737]
===
match
---
simple_stmt [14936,15000]
simple_stmt [14639,14703]
===
match
---
comparison [26812,26849]
comparison [26515,26552]
===
match
---
arglist [26264,26307]
arglist [25967,26010]
===
match
---
trailer [10568,10583]
trailer [10271,10286]
===
match
---
atom_expr [28236,28249]
atom_expr [27939,27952]
===
match
---
name: state [16260,16265]
name: state [15963,15968]
===
match
---
name: query [30356,30361]
name: query [30059,30064]
===
match
---
name: TI [12168,12170]
name: TI [11871,11873]
===
match
---
name: self [24992,24996]
name: self [24695,24699]
===
match
---
name: filter [10454,10460]
name: filter [10157,10163]
===
match
---
trailer [30826,30830]
trailer [30529,30533]
===
match
---
if_stmt [30286,30667]
if_stmt [29989,30370]
===
match
---
operator: = [16497,16498]
operator: = [16200,16201]
===
match
---
trailer [4084,4094]
trailer [4025,4035]
===
match
---
comparison [30411,30435]
comparison [30114,30138]
===
match
---
operator: = [20475,20476]
operator: = [20178,20179]
===
match
---
trailer [15322,15338]
trailer [15025,15041]
===
match
---
name: schedule_tis [29132,29144]
name: schedule_tis [28835,28847]
===
match
---
trailer [29989,30018]
trailer [29692,29721]
===
match
---
operator: = [14196,14197]
operator: = [13899,13900]
===
match
---
name: RUNNING [23115,23122]
name: RUNNING [22818,22825]
===
match
---
atom_expr [4434,4447]
atom_expr [4375,4388]
===
match
---
operator: , [31303,31304]
operator: , [31006,31007]
===
match
---
name: self [30424,30428]
name: self [30127,30131]
===
match
---
operator: = [25871,25872]
operator: = [25574,25575]
===
match
---
atom [19548,19595]
atom [19251,19298]
===
match
---
atom_expr [25954,25962]
atom_expr [25657,25665]
===
match
---
name: SCHEDULEABLE_STATES [19775,19794]
name: SCHEDULEABLE_STATES [19478,19497]
===
match
---
operator: = [4095,4096]
operator: = [4036,4037]
===
match
---
argument [7977,8007]
argument [7680,7710]
===
match
---
operator: = [17273,17274]
operator: = [16976,16977]
===
match
---
atom_expr [4574,4589]
atom_expr [4515,4530]
===
match
---
name: queued_at [4876,4885]
name: queued_at [4817,4826]
===
match
---
name: DEFAULT_DAGRUNS_TO_EXAMINE [3806,3832]
name: DEFAULT_DAGRUNS_TO_EXAMINE [3747,3773]
===
match
---
name: dag_id [28732,28738]
name: dag_id [28435,28441]
===
match
---
trailer [18272,18279]
trailer [17975,17982]
===
match
---
comparison [11533,11573]
comparison [11236,11276]
===
match
---
operator: = [21772,21773]
operator: = [21475,21476]
===
match
---
trailer [5464,5471]
trailer [5405,5412]
===
match
---
operator: , [17567,17568]
operator: , [17270,17271]
===
match
---
atom_expr [5404,5415]
atom_expr [5345,5356]
===
match
---
name: __init__ [5015,5023]
name: __init__ [4956,4964]
===
match
---
name: session [21133,21140]
name: session [20836,20843]
===
match
---
arglist [19018,19078]
arglist [18721,18781]
===
match
---
simple_stmt [27282,27417]
simple_stmt [26985,27120]
===
match
---
name: tis [12244,12247]
name: tis [11947,11950]
===
match
---
trailer [24872,24881]
trailer [24575,24584]
===
match
---
trailer [12314,12318]
trailer [12017,12021]
===
match
---
expr_stmt [10189,10242]
expr_stmt [9892,9945]
===
match
---
operator: , [26226,26227]
operator: , [25929,25930]
===
match
---
operator: = [7133,7134]
operator: = [6836,6837]
===
match
---
atom_expr [16778,16797]
atom_expr [16481,16500]
===
match
---
name: dag [17332,17335]
name: dag [17035,17038]
===
match
---
simple_stmt [18546,18576]
simple_stmt [18249,18279]
===
match
---
import_from [1503,1561]
import_from [1444,1502]
===
match
---
decorator [28532,28545]
decorator [28235,28248]
===
match
---
atom_expr [15528,15550]
atom_expr [15231,15253]
===
match
---
name: TI [11902,11904]
name: TI [11605,11607]
===
match
---
simple_stmt [17915,17944]
simple_stmt [17618,17647]
===
match
---
atom_expr [27579,27597]
atom_expr [27282,27300]
===
match
---
operator: = [4670,4671]
operator: = [4611,4612]
===
match
---
trailer [14059,14089]
trailer [13762,13792]
===
match
---
trailer [18192,18448]
trailer [17895,18151]
===
match
---
operator: == [12815,12817]
operator: == [12518,12520]
===
match
---
trailer [7417,7424]
trailer [7120,7127]
===
match
---
import_from [817,906]
import_from [817,906]
===
match
---
name: task_id [25889,25896]
name: task_id [25592,25599]
===
match
---
suite [19201,19264]
suite [18904,18967]
===
match
---
name: and_ [28971,28975]
name: and_ [28674,28678]
===
match
---
operator: , [3919,3920]
operator: , [3860,3861]
===
match
---
atom_expr [26424,26437]
atom_expr [26127,26140]
===
match
---
operator: { [11202,11203]
operator: { [10905,10906]
===
match
---
atom_expr [29168,29180]
atom_expr [28871,28883]
===
match
---
name: state [5508,5513]
name: state [5449,5454]
===
match
---
name: info [27438,27442]
name: info [27141,27145]
===
match
---
name: provide_session [28550,28565]
name: provide_session [28253,28268]
===
match
---
name: classmethod [28533,28544]
name: classmethod [28236,28247]
===
match
---
name: State [23109,23114]
name: State [22812,22817]
===
match
---
tfpdef [6539,6555]
tfpdef [6242,6258]
===
match
---
trailer [7990,8007]
trailer [7693,7710]
===
match
---
name: Column [2700,2706]
name: Column [2641,2647]
===
match
---
name: self [4859,4863]
name: self [4800,4804]
===
match
---
name: t [15528,15529]
name: t [15231,15232]
===
match
---
name: func [7871,7875]
name: func [7574,7578]
===
match
---
if_stmt [10792,10859]
if_stmt [10495,10562]
===
match
---
name: external_trigger [8262,8278]
name: external_trigger [7965,7981]
===
match
---
name: execution_date [2724,2738]
name: execution_date [2665,2679]
===
match
---
name: run_id [9949,9955]
name: run_id [9652,9658]
===
match
---
arglist [3337,3367]
arglist [3278,3308]
===
match
---
trailer [26147,26151]
trailer [25850,25854]
===
match
---
name: are_runnable_tasks [17815,17833]
name: are_runnable_tasks [17518,17536]
===
match
---
name: airflow [1970,1977]
name: airflow [1911,1918]
===
match
---
operator: , [31280,31281]
operator: , [30983,30984]
===
match
---
name: Optional [11303,11311]
name: Optional [11006,11014]
===
match
---
name: handle_callback [17244,17259]
name: handle_callback [16947,16962]
===
match
---
atom_expr [24125,24168]
atom_expr [23828,23871]
===
match
---
operator: = [12248,12249]
operator: = [11951,11952]
===
match
---
comparison [26074,26101]
comparison [25777,25804]
===
match
---
atom_expr [2246,2254]
atom_expr [2187,2195]
===
match
---
trailer [18013,18082]
trailer [17716,17785]
===
match
---
trailer [7290,7296]
trailer [6993,6999]
===
match
---
expr_stmt [2259,2284]
expr_stmt [2200,2225]
===
match
---
suite [24534,24554]
suite [24237,24257]
===
match
---
trailer [19517,19519]
trailer [19220,19222]
===
match
---
raise_stmt [13027,13095]
raise_stmt [12730,12798]
===
match
---
arglist [11630,11640]
arglist [11333,11343]
===
match
---
trailer [4664,4669]
trailer [4605,4610]
===
match
---
trailer [2674,2682]
trailer [2615,2623]
===
match
---
trailer [24252,24316]
trailer [23955,24019]
===
match
---
funcdef [28570,29102]
funcdef [28273,28805]
===
match
---
operator: = [20963,20964]
operator: = [20666,20667]
===
match
---
name: task [26765,26769]
name: task [26468,26472]
===
match
---
fstring_string: dagrun.dependency-check. [15118,15142]
fstring_string: dagrun.dependency-check. [14821,14845]
===
match
---
comparison [10684,10712]
comparison [10387,10415]
===
match
---
name: dag_id [29001,29007]
name: dag_id [28704,28710]
===
match
---
name: changed_tis [20141,20152]
name: changed_tis [19844,19855]
===
match
---
atom_expr [30813,31369]
atom_expr [30516,31072]
===
match
---
trailer [16274,16288]
trailer [15977,15991]
===
match
---
name: Iterable [11312,11320]
name: Iterable [11015,11023]
===
match
---
trailer [24610,24618]
trailer [24313,24321]
===
match
---
simple_stmt [21267,21297]
simple_stmt [20970,21000]
===
match
---
atom_expr [30220,30257]
atom_expr [29923,29960]
===
match
---
trailer [30245,30257]
trailer [29948,29960]
===
match
---
trailer [8512,8522]
trailer [8215,8225]
===
match
---
expr_stmt [4660,4682]
expr_stmt [4601,4623]
===
match
---
funcdef [13641,14121]
funcdef [13344,13824]
===
match
---
trailer [28979,28986]
trailer [28682,28689]
===
match
---
trailer [24765,24828]
trailer [24468,24531]
===
match
---
atom_expr [19463,19471]
atom_expr [19166,19174]
===
match
---
name: state [7291,7296]
name: state [6994,6999]
===
match
---
trailer [2706,2719]
trailer [2647,2660]
===
match
---
atom_expr [16618,16902]
atom_expr [16321,16605]
===
match
---
trailer [11217,11227]
trailer [10920,10930]
===
match
---
trailer [25596,25615]
trailer [25299,25318]
===
match
---
name: DR [10913,10915]
name: DR [10616,10618]
===
match
---
arglist [3449,3467]
arglist [3390,3408]
===
match
---
expr_stmt [2289,2306]
expr_stmt [2230,2247]
===
match
---
suite [11642,11695]
suite [11345,11398]
===
match
---
atom_expr [2329,2337]
atom_expr [2270,2278]
===
match
---
testlist_comp [13337,13423]
testlist_comp [13040,13126]
===
match
---
atom_expr [8144,8157]
atom_expr [7847,7860]
===
match
---
name: ti [23640,23642]
name: ti [23343,23345]
===
match
---
fstring [26606,26642]
fstring [26309,26345]
===
match
---
fstring_start: f" [26974,26976]
fstring_start: f" [26677,26679]
===
match
---
sync_comp_for [15551,15576]
sync_comp_for [15254,15279]
===
match
---
simple_stmt [1503,1562]
simple_stmt [1444,1503]
===
match
---
trailer [27368,27375]
trailer [27071,27078]
===
match
---
param [14173,14178]
param [13876,13881]
===
match
---
string: 'max_dagruns_per_loop_to_schedule' [3885,3919]
string: 'max_dagruns_per_loop_to_schedule' [3826,3860]
===
match
---
name: execution_date [11536,11550]
name: execution_date [11239,11253]
===
match
---
trailer [26331,26337]
trailer [26034,26040]
===
match
---
atom_expr [13949,13968]
atom_expr [13652,13671]
===
match
---
simple_stmt [13476,13514]
simple_stmt [13179,13217]
===
match
---
atom_expr [17040,17060]
atom_expr [16743,16763]
===
match
---
simple_stmt [20944,20975]
simple_stmt [20647,20678]
===
match
---
import_as_names [836,906]
import_as_names [836,906]
===
match
---
param [27651,27663]
param [27354,27366]
===
match
---
simple_stmt [23189,23196]
simple_stmt [22892,22899]
===
match
---
name: finished_tis [22117,22129]
name: finished_tis [21820,21832]
===
match
---
arglist [3622,3678]
arglist [3563,3619]
===
match
---
atom_expr [27246,27269]
atom_expr [26949,26972]
===
match
---
trailer [15030,15037]
trailer [14733,14740]
===
match
---
name: leaf_ti [16293,16300]
name: leaf_ti [15996,16003]
===
match
---
name: Session [21427,21434]
name: Session [21130,21137]
===
match
---
name: dag [26289,26292]
name: dag [25992,25995]
===
match
---
name: Session [13215,13222]
name: Session [12918,12925]
===
match
---
param [11290,11295]
param [10993,10998]
===
match
---
simple_stmt [17847,17903]
simple_stmt [17550,17606]
===
match
---
operator: , [20389,20390]
operator: , [20092,20093]
===
match
---
atom_expr [31113,31126]
atom_expr [30816,30829]
===
match
---
comparison [9986,10005]
comparison [9689,9708]
===
match
---
name: tis [19156,19159]
name: tis [18859,18862]
===
match
---
name: TI [3593,3595]
name: TI [3534,3536]
===
match
---
name: t [15555,15556]
name: t [15258,15259]
===
match
---
expr_stmt [23270,23290]
expr_stmt [22973,22993]
===
match
---
trailer [24618,24683]
trailer [24321,24386]
===
match
---
trailer [25956,25962]
trailer [25659,25665]
===
match
---
suite [23224,23244]
suite [22927,22947]
===
match
---
trailer [12753,12760]
trailer [12456,12463]
===
match
---
operator: @ [28426,28427]
operator: @ [28129,28130]
===
match
---
name: total_seconds [24199,24212]
name: total_seconds [23902,23915]
===
match
---
atom_expr [26773,26795]
atom_expr [26476,26498]
===
match
---
test [5542,5602]
test [5483,5543]
===
match
---
not_test [16994,17014]
not_test [16697,16717]
===
match
---
simple_stmt [25821,25833]
simple_stmt [25524,25536]
===
match
---
simple_stmt [24360,24439]
simple_stmt [24063,24142]
===
match
---
name: no_backfills [10870,10882]
name: no_backfills [10573,10585]
===
match
---
trailer [12735,12826]
trailer [12438,12529]
===
match
---
name: sqlalchemy [1278,1288]
name: sqlalchemy [1219,1229]
===
match
---
atom_expr [18228,18239]
atom_expr [17931,17942]
===
match
---
simple_stmt [10311,10397]
simple_stmt [10014,10100]
===
match
---
atom_expr [20029,20253]
atom_expr [19732,19956]
===
match
---
name: _state [2862,2868]
name: _state [2803,2809]
===
match
---
name: DagRunType [14005,14015]
name: DagRunType [13708,13718]
===
match
---
atom [19621,19666]
atom [19324,19369]
===
match
---
name: State [5627,5632]
name: State [5568,5573]
===
match
---
name: start_date [26817,26827]
name: start_date [26520,26530]
===
match
---
fstring_end: ' [24436,24437]
fstring_end: ' [24139,24140]
===
match
---
not_test [13001,13013]
not_test [12704,12716]
===
match
---
atom [7234,7762]
atom [6937,7465]
===
match
---
name: task [29985,29989]
name: task [29688,29692]
===
match
---
tfpdef [4337,4360]
tfpdef [4278,4301]
===
match
---
operator: , [7958,7959]
operator: , [7661,7662]
===
match
---
name: fileloc [16694,16701]
name: fileloc [16397,16404]
===
match
---
name: tis [12250,12253]
name: tis [11953,11956]
===
match
---
name: self [15211,15215]
name: self [14914,14918]
===
match
---
name: filter [30383,30389]
name: filter [30086,30092]
===
match
---
atom_expr [27260,27268]
atom_expr [26963,26971]
===
match
---
trailer [28721,28727]
trailer [28424,28430]
===
match
---
operator: { [15142,15143]
operator: { [14845,14846]
===
match
---
simple_stmt [13737,13791]
simple_stmt [13440,13494]
===
match
---
name: str [9848,9851]
name: str [9551,9554]
===
match
---
param [25181,25186]
param [24884,24889]
===
match
---
atom_expr [25797,25807]
atom_expr [25500,25510]
===
match
---
name: is_failure_callback [18357,18376]
name: is_failure_callback [18060,18079]
===
match
---
name: dag_id [3625,3631]
name: dag_id [3566,3572]
===
match
---
suite [23777,24317]
suite [23480,24020]
===
match
---
name: Integer [2621,2628]
name: Integer [2562,2569]
===
match
---
expr_stmt [2827,2857]
expr_stmt [2768,2798]
===
match
---
trailer [16251,16313]
trailer [15954,16016]
===
match
---
trailer [12738,12745]
trailer [12441,12448]
===
match
---
operator: , [26568,26569]
operator: , [26271,26272]
===
match
---
atom_expr [29009,29027]
atom_expr [28712,28730]
===
match
---
try_stmt [25845,26354]
try_stmt [25548,26057]
===
match
---
atom_expr [15520,15577]
atom_expr [15223,15280]
===
match
---
trailer [17180,17188]
trailer [16883,16891]
===
match
---
name: finished_tis [23211,23223]
name: finished_tis [22914,22926]
===
match
---
name: between [10346,10353]
name: between [10049,10056]
===
match
---
operator: = [15020,15021]
operator: = [14723,14724]
===
match
---
operator: > [26828,26829]
operator: > [26531,26532]
===
match
---
comparison [24188,24218]
comparison [23891,23921]
===
match
---
name: qry [10195,10198]
name: qry [9898,9901]
===
match
---
name: FAILED [17936,17942]
name: FAILED [17639,17645]
===
match
---
atom [19729,19795]
atom [19432,19498]
===
match
---
name: queued_at [4721,4730]
name: queued_at [4662,4671]
===
match
---
trailer [16389,16399]
trailer [16092,16102]
===
match
---
atom_expr [15462,15483]
atom_expr [15165,15186]
===
match
---
trailer [30924,30939]
trailer [30627,30642]
===
match
---
name: state [26332,26337]
name: state [26035,26040]
===
match
---
name: st [20906,20908]
name: st [20609,20611]
===
match
---
operator: , [7305,7306]
operator: , [7008,7009]
===
match
---
parameters [24487,24493]
parameters [24190,24196]
===
match
---
name: session [27633,27640]
name: session [27336,27343]
===
match
---
expr_stmt [4927,4951]
expr_stmt [4868,4892]
===
match
---
name: TI [11471,11473]
name: TI [11174,11176]
===
match
---
atom_expr [28177,28410]
atom_expr [27880,28113]
===
match
---
operator: = [18041,18042]
operator: = [17744,17745]
===
match
---
name: self [17500,17504]
name: self [17203,17207]
===
match
---
operator: = [9779,9780]
operator: = [9482,9483]
===
match
---
operator: == [30475,30477]
operator: == [30178,30180]
===
match
---
name: models [7051,7057]
name: models [6754,6760]
===
match
---
atom_expr [13879,13892]
atom_expr [13582,13595]
===
match
---
name: execution_date [10119,10133]
name: execution_date [9822,9836]
===
match
---
atom_expr [12783,12802]
atom_expr [12486,12505]
===
match
---
name: dag_ids [9807,9814]
name: dag_ids [9510,9517]
===
match
---
atom_expr [28728,28738]
atom_expr [28431,28441]
===
match
---
arglist [17862,17901]
arglist [17565,17604]
===
match
---
atom_expr [25740,25771]
atom_expr [25443,25474]
===
match
---
operator: , [8474,8475]
operator: , [8177,8178]
===
match
---
number: 1 [26644,26645]
number: 1 [26347,26348]
===
match
---
name: state [12181,12186]
name: state [11884,11889]
===
match
---
operator: , [24303,24304]
operator: , [24006,24007]
===
match
---
simple_stmt [10962,11007]
simple_stmt [10665,10710]
===
match
---
atom_expr [30043,30070]
atom_expr [29746,29773]
===
match
---
operator: @ [18790,18791]
operator: @ [18493,18494]
===
match
---
operator: , [20572,20573]
operator: , [20275,20276]
===
match
---
name: qry [10444,10447]
name: qry [10147,10150]
===
match
---
name: DagRunType [28503,28513]
name: DagRunType [28206,28216]
===
match
---
trailer [2620,2647]
trailer [2561,2588]
===
match
---
name: st [20628,20630]
name: st [20331,20333]
===
match
---
param [25187,25210]
param [24890,24913]
===
match
---
operator: , [3032,3033]
operator: , [2973,2974]
===
match
---
name: dag_ids [9876,9883]
name: dag_ids [9579,9586]
===
match
---
name: query [13828,13833]
name: query [13531,13536]
===
match
---
operator: == [30940,30942]
operator: == [30643,30645]
===
match
---
name: DagRun [13577,13583]
name: DagRun [13280,13286]
===
match
---
name: qry [10555,10558]
name: qry [10258,10261]
===
match
---
name: _state [5409,5415]
name: _state [5350,5356]
===
match
---
operator: , [16797,16798]
operator: , [16500,16501]
===
match
---
simple_stmt [2311,2338]
simple_stmt [2252,2279]
===
match
---
atom_expr [7409,7424]
atom_expr [7112,7127]
===
match
---
name: task_id [12807,12814]
name: task_id [12510,12517]
===
match
---
comp_if [19760,19794]
comp_if [19463,19497]
===
match
---
simple_stmt [2961,2995]
simple_stmt [2902,2936]
===
match
---
if_stmt [10867,10953]
if_stmt [10570,10656]
===
match
---
operator: , [854,855]
operator: , [854,855]
===
match
---
name: session [27180,27187]
name: session [26883,26890]
===
match
---
name: debug [19817,19822]
name: debug [19520,19525]
===
match
---
name: DR [10743,10745]
name: DR [10446,10448]
===
match
---
trailer [3024,3047]
trailer [2965,2988]
===
match
---
comparison [19567,19594]
comparison [19270,19297]
===
match
---
tfpdef [29151,29180]
tfpdef [28854,28883]
===
match
---
simple_stmt [4960,4999]
simple_stmt [4901,4940]
===
match
---
name: str [8103,8106]
name: str [7806,7809]
===
match
---
trailer [15283,15287]
trailer [14986,14990]
===
match
---
name: airflow [1650,1657]
name: airflow [1591,1598]
===
match
---
name: scheduleable_tasks [20524,20542]
name: scheduleable_tasks [20227,20245]
===
match
---
atom_expr [6225,6236]
atom_expr [6047,6058]
===
match
---
suite [28470,28527]
suite [28173,28230]
===
match
---
name: task_instance_scheduling_decisions [18815,18849]
name: task_instance_scheduling_decisions [18518,18552]
===
match
---
simple_stmt [19604,19667]
simple_stmt [19307,19370]
===
match
---
name: state [24511,24516]
name: state [24214,24219]
===
match
---
name: task [25866,25870]
name: task [25569,25573]
===
match
---
name: Column [2838,2844]
name: Column [2779,2785]
===
match
---
operator: = [9901,9902]
operator: = [9604,9605]
===
match
---
name: none_task_concurrency [17785,17806]
name: none_task_concurrency [17488,17509]
===
match
---
atom_expr [4307,4320]
atom_expr [4248,4261]
===
match
---
trailer [6340,6347]
trailer [6081,6088]
===
match
---
decorated [11012,11232]
decorated [10715,10935]
===
match
---
name: info [26499,26503]
name: info [26202,26206]
===
match
---
name: state [26669,26674]
name: state [26372,26377]
===
match
---
trailer [19220,19225]
trailer [18923,18928]
===
match
---
trailer [5012,5014]
trailer [4953,4955]
===
match
---
name: state [19642,19647]
name: state [19345,19350]
===
match
---
name: expression [7513,7523]
name: expression [7216,7226]
===
match
---
name: execution_date [5253,5267]
name: execution_date [5194,5208]
===
match
---
param [27633,27650]
param [27336,27353]
===
match
---
trailer [11311,11340]
trailer [11014,11043]
===
match
---
name: qry [10189,10192]
name: qry [9892,9895]
===
match
---
name: session [28714,28721]
name: session [28417,28424]
===
match
---
name: filter [30848,30854]
name: filter [30551,30557]
===
match
---
name: update [31049,31055]
name: update [30752,30758]
===
match
---
operator: = [21200,21201]
operator: = [20903,20904]
===
match
---
name: run_id [4514,4520]
name: run_id [4455,4461]
===
match
---
trailer [23730,23733]
trailer [23433,23436]
===
match
---
name: DagRun [13379,13385]
name: DagRun [13082,13088]
===
match
---
name: execute_callbacks [17959,17976]
name: execute_callbacks [17662,17679]
===
match
---
name: skip_locked [7979,7990]
name: skip_locked [7682,7693]
===
match
---
trailer [25575,25577]
trailer [25278,25280]
===
match
---
name: append [20899,20905]
name: append [20602,20608]
===
match
---
operator: , [21283,21284]
operator: , [20986,20987]
===
match
---
name: key [21232,21235]
name: key [20935,20938]
===
match
---
atom_expr [30411,30420]
atom_expr [30114,30123]
===
match
---
name: airflow [1508,1515]
name: airflow [1449,1456]
===
match
---
atom [29911,29913]
atom [29614,29616]
===
match
---
name: ID_LEN [2675,2681]
name: ID_LEN [2616,2622]
===
match
---
trailer [15189,15191]
trailer [14892,14894]
===
match
---
atom_expr [2769,2784]
atom_expr [2710,2725]
===
match
---
test [4780,4832]
test [4721,4773]
===
match
---
name: Optional [13184,13192]
name: Optional [12887,12895]
===
match
---
name: self [30943,30947]
name: self [30646,30650]
===
match
---
name: filter [10827,10833]
name: filter [10530,10536]
===
match
---
trailer [15916,15959]
trailer [15619,15662]
===
match
---
name: execution_date [27058,27072]
name: execution_date [26761,26775]
===
match
---
trailer [12253,12260]
trailer [11956,11963]
===
match
---
operator: , [3777,3778]
operator: , [3718,3719]
===
match
---
string: 'scheduler' [3864,3875]
string: 'scheduler' [3805,3816]
===
match
---
param [5044,5048]
param [4985,4989]
===
match
---
name: end_date [2827,2835]
name: end_date [2768,2776]
===
match
---
trailer [19093,19097]
trailer [18796,18800]
===
match
---
name: subquery [28990,28998]
name: subquery [28693,28701]
===
match
---
name: Optional [8232,8240]
name: Optional [7935,7943]
===
match
---
name: callback_requests [1739,1756]
name: callback_requests [1680,1697]
===
match
---
trailer [19765,19771]
trailer [19468,19474]
===
match
---
simple_stmt [26595,26650]
simple_stmt [26298,26353]
===
match
---
name: Session [20382,20389]
name: Session [20085,20092]
===
match
---
name: execution_date [4534,4548]
name: execution_date [4475,4489]
===
match
---
atom_expr [10206,10223]
atom_expr [9909,9926]
===
match
---
if_stmt [5457,5692]
if_stmt [5398,5633]
===
match
---
atom_expr [7491,7509]
atom_expr [7194,7212]
===
match
---
operator: = [4448,4449]
operator: = [4389,4390]
===
match
---
trailer [8112,8117]
trailer [7815,7820]
===
match
---
operator: , [19076,19077]
operator: , [18779,18780]
===
match
---
trailer [13483,13490]
trailer [13186,13193]
===
match
---
name: execution_end_date [10376,10394]
name: execution_end_date [10079,10097]
===
match
---
name: end_date [31213,31221]
name: end_date [30916,30924]
===
match
---
name: datetime [8199,8207]
name: datetime [7902,7910]
===
match
---
if_stmt [7772,7883]
if_stmt [7475,7586]
===
match
---
atom_expr [12762,12779]
atom_expr [12465,12482]
===
match
---
name: self [15143,15147]
name: self [14846,14850]
===
match
---
trailer [10972,10981]
trailer [10675,10684]
===
match
---
comparison [13445,13462]
comparison [13148,13165]
===
match
---
name: DagRun [28335,28341]
name: DagRun [28038,28044]
===
match
---
name: UtcDateTime [2810,2821]
name: UtcDateTime [2751,2762]
===
match
---
trailer [9794,9798]
trailer [9497,9501]
===
match
---
name: ti [26714,26716]
name: ti [26417,26419]
===
match
---
atom_expr [15048,15077]
atom_expr [14751,14780]
===
match
---
operator: = [5888,5889]
operator: = [5829,5830]
===
match
---
simple_stmt [4500,4521]
simple_stmt [4441,4462]
===
match
---
name: DagRunType [2054,2064]
name: DagRunType [1995,2005]
===
match
---
expr_stmt [29890,29913]
expr_stmt [29593,29616]
===
match
---
trailer [15215,15250]
trailer [14918,14953]
===
match
---
tfpdef [8136,8157]
tfpdef [7839,7860]
===
match
---
operator: = [11663,11664]
operator: = [11366,11367]
===
match
---
import_from [1341,1395]
import_from [1282,1336]
===
match
---
name: bool [8289,8293]
name: bool [7992,7996]
===
match
---
decorated [6452,8018]
decorated [6155,7721]
===
match
---
suite [24494,25134]
suite [24197,24837]
===
match
---
operator: = [6591,6592]
operator: = [6294,6295]
===
match
---
name: start_date [31155,31165]
name: start_date [30858,30868]
===
match
---
trailer [13885,13892]
trailer [13588,13595]
===
match
---
simple_stmt [1341,1396]
simple_stmt [1282,1337]
===
match
---
name: true_delay [24305,24315]
name: true_delay [24008,24018]
===
match
---
name: execution_date [7723,7737]
name: execution_date [7426,7440]
===
match
---
comparison [28335,28374]
comparison [28038,28077]
===
match
---
suite [7812,7883]
suite [7515,7586]
===
match
---
operator: = [18073,18074]
operator: = [17776,17777]
===
match
---
name: int [6586,6589]
name: int [6289,6292]
===
match
---
param [4065,4108]
param [4006,4049]
===
match
---
operator: , [14258,14259]
operator: , [13961,13962]
===
match
---
suite [16447,16545]
suite [16150,16248]
===
match
---
name: self [22111,22115]
name: self [21814,21818]
===
match
---
trailer [5785,5817]
trailer [5726,5758]
===
match
---
name: State [16400,16405]
name: State [16103,16108]
===
match
---
expr_stmt [4611,4651]
expr_stmt [4552,4592]
===
match
---
test [9817,9864]
test [9520,9567]
===
match
---
trailer [13953,13968]
trailer [13656,13671]
===
match
---
expr_stmt [19529,19595]
expr_stmt [19232,19298]
===
match
---
name: dummy_ti_ids [30760,30772]
name: dummy_ti_ids [30463,30475]
===
match
---
trailer [29012,29027]
trailer [28715,28730]
===
match
---
atom_expr [7549,7567]
atom_expr [7252,7270]
===
match
---
trailer [7658,7683]
trailer [7361,7386]
===
match
---
simple_stmt [26700,26718]
simple_stmt [26403,26421]
===
match
---
atom_expr [12157,12188]
atom_expr [11860,11891]
===
match
---
for_stmt [26761,27154]
for_stmt [26464,26857]
===
match
---
trailer [15181,15189]
trailer [14884,14892]
===
match
---
trailer [15897,15916]
trailer [15600,15619]
===
match
---
trailer [12764,12779]
trailer [12467,12482]
===
match
---
simple_stmt [26253,26309]
simple_stmt [25956,26012]
===
match
---
name: self [23341,23345]
name: self [23044,23048]
===
match
---
trailer [31231,31238]
trailer [30934,30941]
===
match
---
import_from [1230,1272]
import_from [1171,1213]
===
match
---
funcdef [3953,5026]
funcdef [3894,4967]
===
match
---
dotted_name [7043,7061]
dotted_name [6746,6764]
===
match
---
fstring_expr [11190,11200]
fstring_expr [10893,10903]
===
match
---
operator: = [4361,4362]
operator: = [4302,4303]
===
match
---
name: generate_run_id [11034,11049]
name: generate_run_id [10737,10752]
===
match
---
name: task_id [16041,16048]
name: task_id [15744,15751]
===
match
---
expr_stmt [11972,12012]
expr_stmt [11675,11715]
===
match
---
name: BACKFILL_JOB [10939,10951]
name: BACKFILL_JOB [10642,10654]
===
match
---
name: DagRun [13925,13931]
name: DagRun [13628,13634]
===
match
---
trailer [7879,7881]
trailer [7582,7584]
===
match
---
expr_stmt [10099,10154]
expr_stmt [9802,9857]
===
match
---
operator: { [13071,13072]
operator: { [12774,12775]
===
match
---
name: self [19948,19952]
name: self [19651,19655]
===
match
---
suite [13728,14121]
suite [13431,13824]
===
match
---
comp_if [19564,19594]
comp_if [19267,19297]
===
match
---
trailer [11481,11584]
trailer [11184,11287]
===
match
---
trailer [30600,30606]
trailer [30303,30309]
===
match
---
trailer [9788,9794]
trailer [9491,9497]
===
match
---
operator: = [4152,4153]
operator: = [4093,4094]
===
match
---
atom_expr [21206,21214]
atom_expr [20909,20917]
===
match
---
trailer [26258,26263]
trailer [25961,25966]
===
match
---
trailer [17935,17942]
trailer [17638,17645]
===
match
---
operator: -> [11368,11370]
operator: -> [11071,11073]
===
match
---
trailer [26816,26827]
trailer [26519,26530]
===
match
---
operator: @ [5697,5698]
operator: @ [5638,5639]
===
match
---
name: Optional [6577,6585]
name: Optional [6280,6288]
===
match
---
atom_expr [8088,8119]
atom_expr [7791,7822]
===
match
---
name: dag_id [3989,3995]
name: dag_id [3930,3936]
===
match
---
name: execution_end_date [10587,10605]
name: execution_end_date [10290,10308]
===
match
---
param [5865,5870]
param [5806,5811]
===
match
---
name: run_type [28491,28499]
name: run_type [28194,28202]
===
match
---
operator: , [16701,16702]
operator: , [16404,16405]
===
match
---
name: self [16730,16734]
name: self [16433,16437]
===
match
---
operator: = [3717,3718]
operator: = [3658,3659]
===
match
---
atom_expr [24520,24533]
atom_expr [24223,24236]
===
match
---
name: task [15530,15534]
name: task [15233,15237]
===
match
---
trailer [2893,2897]
trailer [2834,2838]
===
match
---
atom_expr [19252,19262]
atom_expr [18955,18965]
===
match
---
name: self [15048,15052]
name: self [14751,14755]
===
match
---
atom_expr [28277,28300]
atom_expr [27980,28003]
===
match
---
trailer [25075,25082]
trailer [24778,24785]
===
match
---
name: state [11597,11602]
name: state [11300,11305]
===
match
---
expr_stmt [15811,16012]
expr_stmt [15514,15715]
===
match
---
simple_stmt [1713,1767]
simple_stmt [1654,1708]
===
match
---
atom_expr [3622,3631]
atom_expr [3563,3572]
===
match
---
trailer [26605,26649]
trailer [26308,26352]
===
match
---
operator: = [7967,7968]
operator: = [7670,7671]
===
match
---
argument [19035,19078]
argument [18738,18781]
===
match
---
name: execution_date [30925,30939]
name: execution_date [30628,30642]
===
match
---
fstring_expr [26629,26641]
fstring_expr [26332,26344]
===
match
---
expr_stmt [17377,17668]
expr_stmt [17080,17371]
===
match
---
operator: , [5267,5268]
operator: , [5208,5209]
===
match
---
atom_expr [19218,19225]
atom_expr [18921,18928]
===
match
---
comparison [13491,13512]
comparison [13194,13215]
===
match
---
name: dr [6411,6413]
name: dr [6114,6116]
===
match
---
if_stmt [12198,12296]
if_stmt [11901,11999]
===
match
---
name: unfinished_tasks [21348,21364]
name: unfinished_tasks [21051,21067]
===
match
---
name: get_task [25877,25885]
name: get_task [25580,25588]
===
match
---
trailer [19232,19240]
trailer [18935,18943]
===
match
---
import_as_names [1997,2021]
import_as_names [1938,1962]
===
match
---
name: filter [11669,11675]
name: filter [11372,11378]
===
match
---
parameters [25180,25211]
parameters [24883,24914]
===
match
---
if_stmt [23304,23500]
if_stmt [23007,23203]
===
match
---
name: dag_id [7418,7424]
name: dag_id [7121,7127]
===
match
---
expr_stmt [3102,3127]
expr_stmt [3043,3068]
===
match
---
simple_stmt [6425,6447]
simple_stmt [6128,6150]
===
match
---
simple_stmt [30154,30186]
simple_stmt [29857,29889]
===
match
---
name: DagModel [7491,7499]
name: DagModel [7194,7202]
===
match
---
name: ti [23542,23544]
name: ti [23245,23247]
===
match
---
name: _emit_true_scheduling_delay_stats_for_finished_state [22058,22110]
name: _emit_true_scheduling_delay_stats_for_finished_state [21761,21813]
===
match
---
atom_expr [12749,12760]
atom_expr [12452,12463]
===
match
---
name: str [11101,11104]
name: str [10804,10807]
===
match
---
name: self [13403,13407]
name: self [13106,13110]
===
match
---
simple_stmt [10549,10607]
simple_stmt [10252,10310]
===
match
---
trailer [11558,11573]
trailer [11261,11276]
===
match
---
name: dag_id [13901,13907]
name: dag_id [13604,13610]
===
match
---
operator: = [8295,8296]
operator: = [7998,7999]
===
match
---
not_test [30091,30122]
not_test [29794,29825]
===
match
---
dotted_name [1463,1482]
dotted_name [1404,1423]
===
match
---
name: ti [27039,27041]
name: ti [26742,26744]
===
match
---
name: session [1843,1850]
name: session [1784,1791]
===
match
---
name: tis [15284,15287]
name: tis [14987,14990]
===
match
---
name: Column [2614,2620]
name: Column [2555,2561]
===
match
---
param [28590,28594]
param [28293,28297]
===
match
---
or_test [23307,23378]
or_test [23010,23081]
===
match
---
name: run_type [10916,10924]
name: run_type [10619,10627]
===
match
---
name: sort [23624,23628]
name: sort [23327,23331]
===
match
---
atom_expr [12058,12086]
atom_expr [11761,11789]
===
match
---
trailer [24718,24727]
trailer [24421,24430]
===
match
---
expr_stmt [9969,10006]
expr_stmt [9672,9709]
===
match
---
name: tis [12037,12040]
name: tis [11740,11743]
===
match
---
operator: , [5351,5352]
operator: , [5292,5293]
===
match
---
suite [25057,25134]
suite [24760,24837]
===
match
---
name: TaskNotFound [1445,1457]
name: TaskNotFound [1386,1398]
===
match
---
name: run_type [13993,14001]
name: run_type [13696,13704]
===
match
---
name: _state [5465,5471]
name: _state [5406,5412]
===
match
---
arglist [7287,7346]
arglist [6990,7049]
===
match
---
trailer [13497,13503]
trailer [13200,13206]
===
match
---
atom_expr [5066,5362]
atom_expr [5007,5303]
===
match
---
simple_stmt [2241,2255]
simple_stmt [2182,2196]
===
match
---
param [28456,28460]
param [28159,28163]
===
match
---
dictorsetmaker [16039,16068]
dictorsetmaker [15742,15771]
===
match
---
trailer [10320,10327]
trailer [10023,10030]
===
match
---
fstring_string:  needs to be set [13077,13093]
fstring_string:  needs to be set [12780,12796]
===
match
---
operator: , [8252,8253]
operator: , [7955,7956]
===
match
---
funcdef [12347,12858]
funcdef [12050,12561]
===
match
---
funcdef [5031,5363]
funcdef [4972,5304]
===
match
---
param [18850,18855]
param [18553,18558]
===
match
---
name: REMOVED [26346,26353]
name: REMOVED [26049,26056]
===
match
---
arglist [16342,16371]
arglist [16045,16074]
===
match
---
trailer [19329,19446]
trailer [19032,19149]
===
match
---
name: dag [17994,17997]
name: dag [17697,17700]
===
match
---
trailer [6429,6435]
trailer [6132,6138]
===
match
---
name: self [5865,5869]
name: self [5806,5810]
===
match
---
name: len [19152,19155]
name: len [18855,18858]
===
match
---
atom_expr [23276,23290]
atom_expr [22979,22993]
===
match
---
trailer [13536,13542]
trailer [13239,13245]
===
match
---
atom_expr [28749,28767]
atom_expr [28452,28470]
===
match
---
trailer [10915,10924]
trailer [10618,10627]
===
match
---
operator: = [2565,2566]
operator: = [2506,2507]
===
match
---
import_from [1594,1644]
import_from [1535,1585]
===
match
---
argument [21708,21950]
argument [21411,21653]
===
match
---
comparison [23095,23122]
comparison [22798,22825]
===
match
---
name: rollback [27587,27595]
name: rollback [27290,27298]
===
match
---
import_from [1273,1310]
import_from [1214,1251]
===
match
---
name: ti [16097,16099]
name: ti [15800,15802]
===
match
---
name: self [16484,16488]
name: self [16187,16191]
===
match
---
trailer [20898,20905]
trailer [20601,20608]
===
match
---
trailer [30521,30529]
trailer [30224,30232]
===
match
---
operator: } [11199,11200]
operator: } [10902,10903]
===
match
---
trailer [19465,19471]
trailer [19168,19174]
===
match
---
operator: @ [8023,8024]
operator: @ [7726,7727]
===
match
---
name: TI [11533,11535]
name: TI [11236,11238]
===
match
---
operator: , [16843,16844]
operator: , [16546,16547]
===
match
---
trailer [28211,28218]
trailer [27914,27921]
===
match
---
atom_expr [19228,19263]
atom_expr [18931,18966]
===
match
---
operator: , [31126,31127]
operator: , [30829,30830]
===
match
---
argument [18301,18335]
argument [18004,18038]
===
match
---
operator: , [8106,8107]
operator: , [7809,7810]
===
match
---
atom_expr [21133,21175]
atom_expr [20836,20878]
===
match
---
param [3975,3980]
param [3916,3921]
===
match
---
name: self [5494,5498]
name: self [5435,5439]
===
match
---
operator: , [16883,16884]
operator: , [16586,16587]
===
match
---
trailer [7286,7347]
trailer [6989,7050]
===
match
---
tfpdef [27633,27649]
tfpdef [27336,27352]
===
match
---
name: DepContext [20755,20765]
name: DepContext [20458,20468]
===
match
---
atom_expr [14269,14305]
atom_expr [13972,14008]
===
match
---
name: timing [24246,24252]
name: timing [23949,23955]
===
match
---
atom [5066,5180]
atom [5007,5121]
===
match
---
parameters [5434,5447]
parameters [5375,5388]
===
match
---
import_from [1172,1229]
import_from [1113,1170]
===
match
---
name: session [26700,26707]
name: session [26403,26410]
===
match
---
atom_expr [18561,18574]
atom_expr [18264,18277]
===
match
---
trailer [30459,30474]
trailer [30162,30177]
===
match
---
atom_expr [17994,18082]
atom_expr [17697,17785]
===
match
---
if_stmt [10015,10243]
if_stmt [9718,9946]
===
match
---
name: state [7300,7305]
name: state [7003,7008]
===
match
---
param [12875,12879]
param [12578,12582]
===
match
---
tfpdef [29182,29198]
tfpdef [28885,28901]
===
match
---
comparison [30922,30962]
comparison [30625,30665]
===
match
---
trailer [26786,26793]
trailer [26489,26496]
===
match
---
trailer [12318,12320]
trailer [12021,12023]
===
match
---
expr_stmt [25821,25832]
expr_stmt [25524,25535]
===
match
---
expr_stmt [12244,12295]
expr_stmt [11947,11998]
===
match
---
if_stmt [16426,16903]
if_stmt [16129,16606]
===
match
---
trailer [14268,14306]
trailer [13971,14009]
===
match
---
simple_stmt [19218,19264]
simple_stmt [18921,18967]
===
match
---
operator: == [10763,10765]
operator: == [10466,10468]
===
match
---
suite [25727,26718]
suite [25430,26421]
===
match
---
name: task_type [27004,27013]
name: task_type [26707,26716]
===
match
---
name: DR [9986,9988]
name: DR [9689,9691]
===
match
---
name: execution_end_date [8484,8502]
name: execution_end_date [8187,8205]
===
match
---
decorator [25139,25156]
decorator [24842,24859]
===
match
---
trailer [13557,13567]
trailer [13260,13270]
===
match
---
operator: = [8330,8331]
operator: = [8033,8034]
===
match
---
operator: -> [20397,20399]
operator: -> [20100,20102]
===
match
---
name: tis [18983,18986]
name: tis [18686,18689]
===
match
---
atom_expr [4810,4822]
atom_expr [4751,4763]
===
match
---
name: self [5526,5530]
name: self [5467,5471]
===
match
---
atom_expr [7779,7811]
atom_expr [7482,7514]
===
match
---
simple_stmt [31393,31406]
simple_stmt [31096,31109]
===
match
---
trailer [27290,27295]
trailer [26993,26998]
===
match
---
trailer [7654,7701]
trailer [7357,7404]
===
match
---
name: execution_date [17533,17547]
name: execution_date [17236,17250]
===
match
---
param [21418,21435]
param [21121,21138]
===
match
---
suite [22131,24439]
suite [21834,24142]
===
match
---
simple_stmt [2652,2684]
simple_stmt [2593,2625]
===
match
---
fstring_string: Failed to record first_task_scheduling_delay metric:\n [24379,24433]
fstring_string: Failed to record first_task_scheduling_delay metric:\n [24082,24136]
===
match
---
name: filter_for_tis [21040,21054]
name: filter_for_tis [20743,20757]
===
match
---
operator: == [25041,25043]
operator: == [24744,24746]
===
match
---
name: bool [8325,8329]
name: bool [8028,8032]
===
match
---
name: session [30813,30820]
name: session [30516,30523]
===
match
---
operator: = [23274,23275]
operator: = [22977,22978]
===
match
---
name: state [24916,24921]
name: state [24619,24624]
===
match
---
arglist [20063,20243]
arglist [19766,19946]
===
match
---
atom_expr [11891,11921]
atom_expr [11594,11624]
===
match
---
operator: = [18154,18155]
operator: = [17857,17858]
===
match
---
name: state [31106,31111]
name: state [30809,30814]
===
match
---
name: conf [4264,4268]
name: conf [4205,4209]
===
match
---
string: 'task_failure' [16512,16526]
string: 'task_failure' [16215,16229]
===
match
---
operator: { [4680,4681]
operator: { [4621,4622]
===
match
---
operator: = [3041,3042]
operator: = [2982,2983]
===
match
---
operator: = [3090,3091]
operator: = [3031,3032]
===
match
---
operator: , [27018,27019]
operator: , [26721,26722]
===
match
---
name: ti [19174,19176]
name: ti [18877,18879]
===
match
---
trailer [3270,3282]
trailer [3211,3223]
===
match
---
operator: = [12041,12042]
operator: = [11744,11745]
===
match
---
name: session [7685,7692]
name: session [7388,7395]
===
match
---
trailer [27046,27073]
trailer [26749,26776]
===
match
---
name: List [20406,20410]
name: List [20109,20113]
===
match
---
trailer [30482,30497]
trailer [30185,30200]
===
match
---
import_from [1077,1118]
import_from [1018,1059]
===
match
---
atom_expr [7719,7737]
atom_expr [7422,7440]
===
match
---
return_stmt [7892,8017]
return_stmt [7595,7720]
===
match
---
string: "number of tis tasks for %s: %s task(s)" [19104,19144]
string: "number of tis tasks for %s: %s task(s)" [18807,18847]
===
match
---
if_stmt [23204,23244]
if_stmt [22907,22947]
===
match
---
name: Union [8097,8102]
name: Union [7800,7805]
===
match
---
name: ut [19763,19765]
name: ut [19466,19468]
===
match
---
name: reason [18035,18041]
name: reason [17738,17744]
===
match
---
atom [3321,3548]
atom [3262,3489]
===
match
---
name: filter [10559,10565]
name: filter [10262,10268]
===
match
---
trailer [30854,31031]
trailer [30557,30734]
===
match
---
name: sqlalchemy [1177,1187]
name: sqlalchemy [1118,1128]
===
match
---
operator: = [20442,20443]
operator: = [20145,20146]
===
match
---
atom_expr [4270,4283]
atom_expr [4211,4224]
===
match
---
param [24488,24492]
param [24191,24195]
===
match
---
name: get_dag [15182,15189]
name: get_dag [14885,14892]
===
match
---
name: backref [3752,3759]
name: backref [3693,3700]
===
match
---
name: List [8108,8112]
name: List [7811,7815]
===
match
---
number: 32 [3278,3280]
number: 32 [3219,3221]
===
match
---
simple_stmt [6401,6417]
simple_stmt [6104,6120]
===
match
---
name: Session [5880,5887]
name: Session [5821,5828]
===
match
---
name: qry [10105,10108]
name: qry [9808,9811]
===
match
---
name: dag_id [16723,16729]
name: dag_id [16426,16432]
===
match
---
trailer [9906,9913]
trailer [9609,9616]
===
match
---
name: ti [21241,21243]
name: ti [20944,20946]
===
match
---
suite [13253,13615]
suite [12956,13318]
===
match
---
suite [10624,10673]
suite [10327,10376]
===
match
---
name: self [12875,12879]
name: self [12578,12582]
===
match
---
import_from [2088,2122]
import_from [2029,2063]
===
match
---
name: first_start_date [24106,24122]
name: first_start_date [23809,23825]
===
match
---
name: log [16332,16335]
name: log [16035,16038]
===
match
---
argument [3752,3793]
argument [3693,3734]
===
match
---
tfpdef [12375,12387]
tfpdef [12078,12090]
===
match
---
operator: = [5287,5288]
operator: = [5228,5229]
===
match
---
operator: != [26085,26087]
operator: != [25788,25790]
===
match
---
operator: @ [13620,13621]
operator: @ [13323,13324]
===
match
---
argument [20166,20199]
argument [19869,19902]
===
match
---
comparison [10206,10241]
comparison [9909,9944]
===
match
---
name: Session [12398,12405]
name: Session [12101,12108]
===
match
---
trailer [19251,19263]
trailer [18954,18966]
===
match
---
simple_stmt [25784,25809]
simple_stmt [25487,25512]
===
match
---
not_test [26854,26874]
not_test [26557,26577]
===
match
---
name: key [20958,20961]
name: key [20661,20664]
===
match
---
and_test [29982,30122]
and_test [29685,29825]
===
match
---
name: TI [30457,30459]
name: TI [30160,30162]
===
match
---
trailer [25082,25133]
trailer [24785,24836]
===
match
---
operator: , [10374,10375]
operator: , [10077,10078]
===
match
---
param [29182,29205]
param [28885,28908]
===
match
---
name: TI [12261,12263]
name: TI [11964,11966]
===
match
---
expr_stmt [15204,15259]
expr_stmt [14907,14962]
===
match
---
atom_expr [13529,13614]
atom_expr [13232,13317]
===
match
---
name: List [20355,20359]
name: List [20058,20062]
===
match
---
name: len [19880,19883]
name: len [19583,19586]
===
match
---
argument [20766,20791]
argument [20469,20494]
===
match
---
trailer [27384,27399]
trailer [27087,27102]
===
match
---
operator: , [18774,18775]
operator: , [18477,18478]
===
match
---
atom_expr [13577,13605]
atom_expr [13280,13308]
===
match
---
name: Optional [4035,4043]
name: Optional [3976,3984]
===
match
---
trailer [21140,21146]
trailer [20843,20849]
===
match
---
name: staticmethod [27604,27616]
name: staticmethod [27307,27319]
===
match
---
operator: = [6409,6410]
operator: = [6112,6113]
===
match
---
trailer [13358,13365]
trailer [13061,13068]
===
match
---
atom_expr [2661,2683]
atom_expr [2602,2624]
===
match
---
trailer [10745,10762]
trailer [10448,10465]
===
match
---
trailer [16405,16412]
trailer [16108,16115]
===
match
---
suite [30137,30186]
suite [29840,29889]
===
match
---
simple_stmt [2999,3048]
simple_stmt [2940,2989]
===
match
---
operator: , [21826,21827]
operator: , [21529,21530]
===
match
---
name: dag_id [17493,17499]
name: dag_id [17196,17202]
===
match
---
name: all [15520,15523]
name: all [15223,15226]
===
match
---
name: with_row_locks [7899,7913]
name: with_row_locks [7602,7616]
===
match
---
name: session [11457,11464]
name: session [11160,11167]
===
match
---
name: Optional [27693,27701]
name: Optional [27396,27404]
===
match
---
trailer [10653,10672]
trailer [10356,10375]
===
match
---
string: 'DagRun' [13718,13726]
string: 'DagRun' [13421,13429]
===
match
---
name: schedulable_tis [2259,2274]
name: schedulable_tis [2200,2215]
===
match
---
name: changed_tis [15983,15994]
name: changed_tis [15686,15697]
===
match
---
name: of [7952,7954]
name: of [7655,7657]
===
match
---
atom_expr [28503,28526]
atom_expr [28206,28229]
===
match
---
atom_expr [24884,24899]
atom_expr [24587,24602]
===
match
---
trailer [19017,19079]
trailer [18720,18782]
===
match
---
name: is_paused [7500,7509]
name: is_paused [7203,7212]
===
match
---
operator: = [16689,16690]
operator: = [16392,16393]
===
match
---
trailer [3336,3368]
trailer [3277,3309]
===
match
---
atom_expr [26110,26121]
atom_expr [25813,25824]
===
match
---
operator: , [20291,20292]
operator: , [19994,19995]
===
match
---
trailer [15250,15259]
trailer [14953,14962]
===
match
---
decorated [13126,13615]
decorated [12829,13318]
===
match
---
atom_expr [26830,26849]
atom_expr [26533,26552]
===
match
---
operator: , [13968,13969]
operator: , [13671,13672]
===
match
---
tfpdef [4117,4151]
tfpdef [4058,4092]
===
match
---
atom_expr [3229,3248]
atom_expr [3170,3189]
===
match
---
argument [18214,18239]
argument [17917,17942]
===
match
---
name: state [4704,4709]
name: state [4645,4650]
===
match
---
trailer [7360,7365]
trailer [7063,7068]
===
match
---
name: DagRunType [11060,11070]
name: DagRunType [10763,10773]
===
match
---
name: dag [17460,17463]
name: dag [17163,17166]
===
match
---
trailer [30820,30826]
trailer [30523,30529]
===
match
---
atom_expr [24506,24516]
atom_expr [24209,24219]
===
match
---
fstring_end: " [26641,26642]
fstring_end: " [26344,26345]
===
match
---
trailer [28744,28748]
trailer [28447,28451]
===
match
---
trailer [18642,18658]
trailer [18345,18361]
===
match
---
tfpdef [8174,8208]
tfpdef [7877,7911]
===
match
---
trailer [11901,11921]
trailer [11604,11624]
===
match
---
fstring [25083,25122]
fstring [24786,24825]
===
match
---
trailer [29041,29056]
trailer [28744,28759]
===
match
---
suite [5732,5819]
suite [5673,5760]
===
match
---
param [4027,4056]
param [3968,3997]
===
match
---
operator: += [30327,30329]
operator: += [30030,30032]
===
match
---
trailer [16654,16902]
trailer [16357,16605]
===
match
---
atom_expr [26329,26337]
atom_expr [26032,26040]
===
match
---
tfpdef [8262,8294]
tfpdef [7965,7997]
===
match
---
operator: { [27379,27380]
operator: { [27082,27083]
===
match
---
if_stmt [25951,26354]
if_stmt [25654,26057]
===
match
---
name: old_states [21055,21065]
name: old_states [20758,20768]
===
match
---
name: info [15365,15369]
name: info [15068,15072]
===
match
---
return_stmt [31393,31405]
return_stmt [31096,31108]
===
match
---
name: self [12369,12373]
name: self [12072,12076]
===
match
---
trailer [28748,28768]
trailer [28451,28471]
===
match
---
testlist_comp [16090,16137]
testlist_comp [15793,15840]
===
match
---
arglist [7643,7738]
arglist [7346,7441]
===
match
---
operator: @ [27603,27604]
operator: @ [27306,27307]
===
match
---
trailer [21150,21157]
trailer [20853,20860]
===
match
---
comparison [7287,7305]
comparison [6990,7008]
===
match
---
name: timezone [31167,31175]
name: timezone [30870,30878]
===
match
---
simple_stmt [1824,1874]
simple_stmt [1765,1815]
===
match
---
operator: , [7737,7738]
operator: , [7440,7441]
===
match
---
name: airflow [1772,1779]
name: airflow [1713,1720]
===
match
---
name: cls [7428,7431]
name: cls [7131,7134]
===
match
---
name: subquery [28945,28953]
name: subquery [28648,28656]
===
match
---
name: Optional [8504,8512]
name: Optional [8207,8215]
===
match
---
name: expression [7571,7581]
name: expression [7274,7284]
===
match
---
name: add [27146,27149]
name: add [26849,26852]
===
match
---
name: dag [16058,16061]
name: dag [15761,15764]
===
match
---
trailer [13583,13598]
trailer [13286,13301]
===
match
---
suite [10082,10155]
suite [9785,9858]
===
match
---
trailer [28806,28815]
trailer [28509,28518]
===
match
---
dotted_name [1235,1257]
dotted_name [1176,1198]
===
match
---
simple_stmt [26329,26354]
simple_stmt [26032,26057]
===
match
---
name: self [27053,27057]
name: self [26756,26760]
===
match
---
operator: == [28301,28303]
operator: == [28004,28006]
===
match
---
name: task_ids [26937,26945]
name: task_ids [26640,26648]
===
match
---
fstring_string: task_removed_from_dag. [26266,26288]
fstring_string: task_removed_from_dag. [25969,25991]
===
match
---
atom_expr [29031,29056]
atom_expr [28734,28759]
===
match
---
name: query [7226,7231]
name: query [6929,6934]
===
match
---
operator: == [12780,12782]
operator: == [12483,12485]
===
match
---
name: ti [25954,25956]
name: ti [25657,25659]
===
match
---
string: """Generate Run ID based on Run Type and Execution Date""" [11114,11172]
string: """Generate Run ID based on Run Type and Execution Date""" [10817,10875]
===
match
---
name: next_dagruns_to_examine [6473,6496]
name: next_dagruns_to_examine [6176,6199]
===
match
---
atom_expr [4076,4094]
atom_expr [4017,4035]
===
match
---
trailer [30986,30994]
trailer [30689,30697]
===
match
---
trailer [26429,26437]
trailer [26132,26140]
===
match
---
trailer [18671,18711]
trailer [18374,18414]
===
match
---
trailer [19097,19103]
trailer [18800,18806]
===
match
---
name: TI [30519,30521]
name: TI [30222,30224]
===
match
---
name: self [6336,6340]
name: self [6077,6081]
===
match
---
operator: , [19150,19151]
operator: , [18853,18854]
===
match
---
name: ti [29926,29928]
name: ti [29629,29631]
===
match
---
import_from [1458,1502]
import_from [1399,1443]
===
match
---
operator: ** [7977,7979]
operator: ** [7680,7682]
===
match
---
sync_comp_for [23545,23584]
sync_comp_for [23248,23287]
===
match
---
expr_stmt [4529,4565]
expr_stmt [4470,4506]
===
match
---
operator: = [12155,12156]
operator: = [11858,11859]
===
match
---
name: settings [25504,25512]
name: settings [25207,25215]
===
match
---
name: creating_job_id [4417,4432]
name: creating_job_id [4358,4373]
===
match
---
name: backref [3760,3767]
name: backref [3701,3708]
===
match
---
string: """         Return the next DagRuns that the scheduler should attempt to schedule.          This will return zero or more DagRun rows that are row-level-locked with a "SELECT ... FOR UPDATE"         query, you should ensure that any scheduling decisions are made in a single transaction -- as soon as         the transaction is committed it will be unlocked.          :rtype: list[airflow.models.DagRun]         """ [6614,7029]
string: """         Return the next DagRuns that the scheduler should attempt to schedule.          This will return zero or more DagRun rows that are row-level-locked with a "SELECT ... FOR UPDATE"         query, you should ensure that any scheduling decisions are made in a single transaction -- as soon as         the transaction is committed it will be unlocked.          :rtype: list[airflow.models.DagRun]         """ [6317,6732]
===
match
---
atom_expr [5748,5818]
atom_expr [5689,5759]
===
match
---
param [21384,21409]
param [21087,21112]
===
match
---
name: state [1984,1989]
name: state [1925,1930]
===
match
---
name: session [15251,15258]
name: session [14954,14961]
===
match
---
import_as_names [1427,1457]
import_as_names [1368,1398]
===
match
---
simple_stmt [28689,28862]
simple_stmt [28392,28565]
===
match
---
if_stmt [9946,10007]
if_stmt [9649,9710]
===
match
---
trailer [23628,23673]
trailer [23331,23376]
===
match
---
name: self [17099,17103]
name: self [16802,16806]
===
match
---
trailer [5583,5592]
trailer [5524,5533]
===
match
---
string: "DagRun" [8545,8553]
string: "DagRun" [8248,8256]
===
match
---
operator: , [20242,20243]
operator: , [19945,19946]
===
match
---
atom [16089,16138]
atom [15792,15841]
===
match
---
operator: , [8126,8127]
operator: , [7829,7830]
===
match
---
name: execution_date [27664,27678]
name: execution_date [27367,27381]
===
match
---
operator: , [18064,18065]
operator: , [17767,17768]
===
match
---
trailer [26921,26929]
trailer [26624,26632]
===
match
---
name: execution_date [7853,7867]
name: execution_date [7556,7570]
===
match
---
name: task [30098,30102]
name: task [29801,29805]
===
match
---
trailer [10656,10662]
trailer [10359,10365]
===
match
---
argument [21902,21931]
argument [21605,21634]
===
match
---
fstring [27362,27402]
fstring [27065,27105]
===
match
---
name: List [14250,14254]
name: List [13953,13957]
===
match
---
operator: -> [27690,27692]
operator: -> [27393,27395]
===
match
---
name: max_number [7090,7100]
name: max_number [6793,6803]
===
match
---
atom_expr [27138,27153]
atom_expr [26841,26856]
===
match
---
atom_expr [16110,16120]
atom_expr [15813,15823]
===
match
---
name: self [19146,19150]
name: self [18849,18853]
===
match
---
atom_expr [17915,17943]
atom_expr [17618,17646]
===
match
---
trailer [26600,26605]
trailer [26303,26308]
===
match
---
name: TI [31210,31212]
name: TI [30913,30915]
===
match
---
simple_stmt [1965,2022]
simple_stmt [1906,1963]
===
match
---
atom_expr [19651,19665]
atom_expr [19354,19368]
===
match
---
name: __NO_VALUE [4097,4107]
name: __NO_VALUE [4038,4048]
===
match
---
trailer [11914,11920]
trailer [11617,11623]
===
match
---
comparison [26412,26437]
comparison [26115,26140]
===
match
---
trailer [10735,10742]
trailer [10438,10445]
===
match
---
name: self [23311,23315]
name: self [23014,23018]
===
match
---
atom_expr [7428,7438]
atom_expr [7131,7141]
===
match
---
trailer [30248,30256]
trailer [29951,29959]
===
match
---
operator: , [11294,11295]
operator: , [10997,10998]
===
match
---
operator: == [10663,10665]
operator: == [10366,10368]
===
match
---
operator: } [20445,20446]
operator: } [20148,20149]
===
match
---
name: TI [31152,31154]
name: TI [30855,30857]
===
match
---
testlist_comp [19062,19077]
testlist_comp [18765,18780]
===
match
---
atom_expr [7571,7588]
atom_expr [7274,7291]
===
match
---
simple_stmt [28636,28681]
simple_stmt [28339,28384]
===
match
---
operator: != [14002,14004]
operator: != [13705,13707]
===
match
---
name: msg [17636,17639]
name: msg [17339,17342]
===
match
---
dotted_name [1879,1903]
dotted_name [1820,1844]
===
match
---
parameters [18849,18880]
parameters [18552,18583]
===
match
---
name: ignore_in_retry_period [21799,21821]
name: ignore_in_retry_period [21502,21524]
===
match
---
operator: , [3080,3081]
operator: , [3021,3022]
===
match
---
testlist_comp [23542,23584]
testlist_comp [23245,23287]
===
match
---
name: self [12214,12218]
name: self [11917,11921]
===
match
---
funcdef [11030,11232]
funcdef [10733,10935]
===
match
---
name: dag_id [3719,3725]
name: dag_id [3660,3666]
===
match
---
name: filter [12047,12053]
name: filter [11750,11756]
===
match
---
atom [19061,19078]
atom [18764,18781]
===
match
---
name: t [19640,19641]
name: t [19343,19344]
===
match
---
name: get_previous_dagrun [13151,13170]
name: get_previous_dagrun [12854,12873]
===
match
---
atom_expr [31167,31184]
atom_expr [30870,30887]
===
match
---
simple_stmt [1645,1713]
simple_stmt [1586,1654]
===
match
---
atom_expr [3378,3422]
atom_expr [3319,3363]
===
match
---
operator: = [16838,16839]
operator: = [16541,16542]
===
match
---
atom_expr [4387,4400]
atom_expr [4328,4341]
===
match
---
expr_stmt [4859,4885]
expr_stmt [4800,4826]
===
match
---
operator: , [17895,17896]
operator: , [17598,17599]
===
match
---
name: String [2887,2893]
name: String [2828,2834]
===
match
---
name: IntegrityError [27211,27225]
name: IntegrityError [26914,26928]
===
match
---
name: Session [14188,14195]
name: Session [13891,13898]
===
match
---
expr_stmt [6425,6446]
expr_stmt [6128,6149]
===
match
---
name: dag_id [11498,11504]
name: dag_id [11201,11207]
===
match
---
name: run_id [4027,4033]
name: run_id [3968,3974]
===
match
---
tfpdef [13177,13197]
tfpdef [12880,12900]
===
match
---
simple_stmt [2259,2285]
simple_stmt [2200,2226]
===
match
---
atom_expr [24565,24580]
atom_expr [24268,24283]
===
match
---
param [8080,8127]
param [7783,7830]
===
match
---
simple_stmt [27721,28148]
simple_stmt [27424,27851]
===
match
---
name: State [19578,19583]
name: State [19281,19286]
===
match
---
trailer [2280,2284]
trailer [2221,2225]
===
match
---
simple_stmt [19708,19796]
simple_stmt [19411,19499]
===
match
---
name: run_type [10849,10857]
name: run_type [10552,10560]
===
match
---
import_from [7038,7077]
import_from [6741,6780]
===
match
---
atom_expr [4660,4669]
atom_expr [4601,4610]
===
match
---
operator: = [15316,15317]
operator: = [15019,15020]
===
match
---
name: list [18989,18993]
name: list [18692,18696]
===
match
---
operator: == [11685,11687]
operator: == [11388,11390]
===
match
---
name: dag_id [9840,9846]
name: dag_id [9543,9549]
===
match
---
name: UtcDateTime [2707,2718]
name: UtcDateTime [2648,2659]
===
match
---
atom_expr [27429,27469]
atom_expr [27132,27172]
===
match
---
name: flag_upstream_failed [20766,20786]
name: flag_upstream_failed [20469,20489]
===
match
---
trailer [3235,3248]
trailer [3176,3189]
===
match
---
name: session [25616,25623]
name: session [25319,25326]
===
match
---
name: execution_date [30460,30474]
name: execution_date [30163,30177]
===
match
---
simple_stmt [20556,20586]
simple_stmt [20259,20289]
===
match
---
atom_expr [15143,15154]
atom_expr [14846,14857]
===
match
---
trailer [15147,15154]
trailer [14850,14857]
===
match
---
operator: , [1496,1497]
operator: , [1437,1438]
===
match
---
atom_expr [15893,15959]
atom_expr [15596,15662]
===
match
---
comparison [10461,10502]
comparison [10164,10205]
===
match
---
trailer [16399,16413]
trailer [16102,16116]
===
match
---
atom_expr [13491,13503]
atom_expr [13194,13206]
===
match
---
name: join [28923,28927]
name: join [28626,28630]
===
match
---
trailer [30382,30389]
trailer [30085,30092]
===
match
---
name: query [12706,12711]
name: query [12409,12414]
===
match
---
classdef [2125,2367]
classdef [2066,2308]
===
match
---
name: dag [24263,24266]
name: dag [23966,23969]
===
match
---
operator: , [25185,25186]
operator: , [24888,24889]
===
match
---
simple_stmt [15394,15431]
simple_stmt [15097,15134]
===
match
---
operator: = [5207,5208]
operator: = [5148,5149]
===
match
---
arglist [7491,7589]
arglist [7194,7292]
===
match
---
name: self [25030,25034]
name: self [24733,24737]
===
match
---
name: changed_tis [15351,15362]
name: changed_tis [15054,15065]
===
match
---
param [11050,11071]
param [10753,10774]
===
match
---
atom_expr [20321,20329]
atom_expr [20024,20032]
===
match
---
name: self [16778,16782]
name: self [16481,16485]
===
match
---
name: conf [3102,3106]
name: conf [3043,3047]
===
match
---
argument [7685,7700]
argument [7388,7403]
===
match
---
simple_stmt [26001,26053]
simple_stmt [25704,25756]
===
match
---
trailer [4355,4360]
trailer [4296,4301]
===
match
---
comparison [13925,13968]
comparison [13628,13671]
===
match
---
expr_stmt [3253,3282]
expr_stmt [3194,3223]
===
match
---
trailer [4395,4400]
trailer [4336,4341]
===
match
---
sync_comp_for [15650,15675]
sync_comp_for [15353,15378]
===
match
---
name: t [16053,16054]
name: t [15756,15757]
===
match
---
name: session [18723,18730]
name: session [18426,18433]
===
match
---
name: Optional [8088,8096]
name: Optional [7791,7799]
===
match
---
name: get_previous_scheduled_dagrun [13645,13674]
name: get_previous_scheduled_dagrun [13348,13377]
===
match
---
name: get_task_instances [25597,25615]
name: get_task_instances [25300,25318]
===
match
---
trailer [17861,17902]
trailer [17564,17605]
===
match
---
name: RUNNING [24526,24533]
name: RUNNING [24229,24236]
===
match
---
name: State [2907,2912]
name: State [2848,2853]
===
match
---
name: should_restore_task [26367,26386]
name: should_restore_task [26070,26089]
===
match
---
operator: , [14177,14178]
operator: , [13880,13881]
===
match
---
operator: , [16503,16504]
operator: , [16206,16207]
===
match
---
dotted_name [1346,1367]
dotted_name [1287,1308]
===
match
---
trailer [3583,3800]
trailer [3524,3741]
===
match
---
expr_stmt [7226,7762]
expr_stmt [6929,7465]
===
match
---
name: log [27287,27290]
name: log [26990,26993]
===
match
---
operator: , [19932,19933]
operator: , [19635,19636]
===
match
---
suite [19184,19520]
suite [18887,19223]
===
match
---
simple_stmt [22140,23084]
simple_stmt [21843,22787]
===
match
---
atom_expr [26412,26420]
atom_expr [26115,26123]
===
match
---
name: self [13354,13358]
name: self [13057,13061]
===
match
---
operator: , [28259,28260]
operator: , [27962,27963]
===
match
---
atom_expr [25966,25979]
atom_expr [25669,25682]
===
match
---
operator: , [21777,21778]
operator: , [21480,21481]
===
match
---
trailer [19321,19329]
trailer [19024,19032]
===
match
---
param [14204,14234]
param [13907,13937]
===
match
---
comparison [21085,21107]
comparison [20788,20810]
===
match
---
return_stmt [5741,5818]
return_stmt [5682,5759]
===
match
---
operator: , [12802,12803]
operator: , [12505,12506]
===
match
---
name: NamedTuple [2152,2162]
name: NamedTuple [2093,2103]
===
match
---
trailer [15369,15381]
trailer [15072,15084]
===
match
---
operator: = [4941,4942]
operator: = [4882,4883]
===
match
---
name: DagRun [13337,13343]
name: DagRun [13040,13046]
===
match
---
operator: = [8158,8159]
operator: = [7861,7862]
===
match
---
dotted_name [1124,1150]
dotted_name [1065,1091]
===
match
---
name: state [21209,21214]
name: state [20912,20917]
===
match
---
name: finished_tasks [19604,19618]
name: finished_tasks [19307,19321]
===
match
---
name: cls [7307,7310]
name: cls [7010,7013]
===
match
---
name: session [16528,16535]
name: session [16231,16238]
===
match
---
name: get_run [27625,27632]
name: get_run [27328,27335]
===
match
---
name: leaf_tis [16304,16312]
name: leaf_tis [16007,16015]
===
match
---
name: Optional [8449,8457]
name: Optional [8152,8160]
===
match
---
name: task_instance_scheduling_decisions [15216,15250]
name: task_instance_scheduling_decisions [14919,14953]
===
match
---
funcdef [25160,27598]
funcdef [24863,27301]
===
match
---
trailer [27003,27013]
trailer [26706,26716]
===
match
---
simple_stmt [5007,5026]
simple_stmt [4948,4967]
===
match
---
atom_expr [30348,30652]
atom_expr [30051,30355]
===
match
---
import_from [1119,1171]
import_from [1060,1112]
===
match
---
name: datetime [808,816]
name: datetime [808,816]
===
match
---
operator: , [3468,3469]
operator: , [3409,3410]
===
match
---
name: state [11630,11635]
name: state [11333,11338]
===
match
---
name: schedulable_tis [15323,15338]
name: schedulable_tis [15026,15041]
===
match
---
argument [20063,20070]
argument [19766,19773]
===
match
---
atom_expr [8108,8117]
atom_expr [7811,7820]
===
match
---
parameters [20277,20396]
parameters [19980,20099]
===
match
---
operator: == [13504,13506]
operator: == [13207,13209]
===
match
---
operator: = [4284,4285]
operator: = [4225,4226]
===
match
---
parameters [21324,21441]
parameters [21027,21144]
===
match
---
name: session [21968,21975]
name: session [21671,21678]
===
match
---
return_stmt [11181,11231]
return_stmt [10884,10934]
===
match
---
operator: = [19226,19227]
operator: = [18929,18930]
===
match
---
trailer [27433,27437]
trailer [27136,27140]
===
match
---
name: session [18074,18081]
name: session [17777,17784]
===
match
---
operator: , [30624,30625]
operator: , [30327,30328]
===
match
---
atom_expr [17160,17189]
atom_expr [16863,16892]
===
match
---
name: State [17930,17935]
name: State [17633,17638]
===
match
---
simple_stmt [25866,25898]
simple_stmt [25569,25601]
===
match
---
trailer [26968,26973]
trailer [26671,26676]
===
match
---
operator: , [8529,8530]
operator: , [8232,8233]
===
match
---
param [8174,8216]
param [7877,7919]
===
match
---
trailer [19254,19262]
trailer [18957,18965]
===
match
---
string: 'task_failure' [16869,16883]
string: 'task_failure' [16572,16586]
===
match
---
name: self [13675,13679]
name: self [13378,13382]
===
match
---
atom_expr [5526,5539]
atom_expr [5467,5480]
===
match
---
name: session [28177,28184]
name: session [27880,27887]
===
match
---
operator: , [31350,31351]
operator: , [31053,31054]
===
match
---
name: utcnow [4789,4795]
name: utcnow [4730,4736]
===
match
---
name: QUEUED [4816,4822]
name: QUEUED [4757,4763]
===
match
---
name: execution_date [18301,18315]
name: execution_date [18004,18018]
===
match
---
trailer [21054,21073]
trailer [20757,20776]
===
match
---
name: run_id [9999,10005]
name: run_id [9702,9708]
===
match
---
atom_expr [23598,23673]
atom_expr [23301,23376]
===
match
---
name: dag [26574,26577]
name: dag [26277,26280]
===
match
---
trailer [27187,27193]
trailer [26890,26896]
===
match
---
expr_stmt [15300,15338]
expr_stmt [15003,15041]
===
match
---
operator: = [2932,2933]
operator: = [2873,2874]
===
match
---
atom_expr [16058,16068]
atom_expr [15761,15771]
===
match
---
trailer [10453,10460]
trailer [10156,10163]
===
match
---
name: execution_date [10569,10583]
name: execution_date [10272,10286]
===
match
---
simple_stmt [7226,7763]
simple_stmt [6929,7466]
===
match
---
operator: = [7232,7233]
operator: = [6935,6936]
===
match
---
name: ready_tis [20563,20572]
name: ready_tis [20266,20275]
===
match
---
trailer [25615,25632]
trailer [25318,25335]
===
match
---
trailer [25792,25796]
trailer [25495,25499]
===
match
---
name: str [8153,8156]
name: str [7856,7859]
===
match
---
arglist [17113,17146]
arglist [16816,16849]
===
match
---
operator: = [16511,16512]
operator: = [16214,16215]
===
match
---
operator: , [4290,4291]
operator: , [4231,4232]
===
match
---
name: isinstance [10049,10059]
name: isinstance [9752,9762]
===
match
---
name: cls [7719,7722]
name: cls [7422,7425]
===
match
---
name: dag [17240,17243]
name: dag [16943,16946]
===
match
---
operator: , [3979,3980]
operator: , [3920,3921]
===
match
---
name: scheduleable_tasks [20634,20652]
name: scheduleable_tasks [20337,20355]
===
match
---
atom_expr [16690,16701]
atom_expr [16393,16404]
===
match
---
simple_stmt [13027,13096]
simple_stmt [12730,12799]
===
match
---
name: first_start_date [23686,23702]
name: first_start_date [23389,23405]
===
match
---
trailer [19240,19242]
trailer [18943,18945]
===
match
---
operator: , [1220,1221]
operator: , [1161,1162]
===
match
---
trailer [7255,7261]
trailer [6958,6964]
===
match
---
trailer [6440,6446]
trailer [6143,6149]
===
match
---
trailer [16467,16483]
trailer [16170,16186]
===
match
---
arglist [10060,10080]
arglist [9763,9783]
===
match
---
operator: = [2906,2907]
operator: = [2847,2848]
===
match
---
atom_expr [3063,3097]
atom_expr [3004,3038]
===
match
---
argument [7960,7975]
argument [7663,7678]
===
match
---
simple_stmt [27090,27122]
simple_stmt [26793,26825]
===
match
---
simple_stmt [15351,15382]
simple_stmt [15054,15085]
===
match
---
simple_stmt [22036,22049]
simple_stmt [21739,21752]
===
match
---
name: scheduleable_tasks [19884,19902]
name: scheduleable_tasks [19587,19605]
===
match
---
name: self [18268,18272]
name: self [17971,17975]
===
match
---
trailer [14081,14086]
trailer [13784,13789]
===
match
---
funcdef [27621,28421]
funcdef [27324,28124]
===
match
---
simple_stmt [16385,16414]
simple_stmt [16088,16117]
===
match
---
string: 'dag_id_state' [3337,3351]
string: 'dag_id_state' [3278,3292]
===
match
---
name: log [24754,24757]
name: log [24457,24460]
===
match
---
tfpdef [27651,27662]
tfpdef [27354,27365]
===
match
---
name: finished_tasks [2342,2356]
name: finished_tasks [2283,2297]
===
match
---
operator: , [29007,29008]
operator: , [28710,28711]
===
match
---
simple_stmt [4529,4566]
simple_stmt [4470,4507]
===
match
---
string: 'DagRun' [27702,27710]
string: 'DagRun' [27405,27413]
===
match
---
name: first [12840,12845]
name: first [12543,12548]
===
match
---
name: x [11848,11849]
name: x [11551,11552]
===
match
---
name: tis [15273,15276]
name: tis [14976,14979]
===
match
---
name: ut [21628,21630]
name: ut [21331,21333]
===
match
---
atom_expr [19504,19519]
atom_expr [19207,19222]
===
match
---
trailer [17259,17314]
trailer [16962,17017]
===
match
---
name: true [7582,7586]
name: true [7285,7289]
===
match
---
trailer [19583,19594]
trailer [19286,19297]
===
match
---
name: cls [28749,28752]
name: cls [28452,28455]
===
match
---
name: unfinished [19584,19594]
name: unfinished [19287,19297]
===
match
---
trailer [10137,10153]
trailer [9840,9856]
===
match
---
atom [3718,3742]
atom [3659,3683]
===
match
---
atom_expr [15022,15039]
atom_expr [14725,14742]
===
match
---
name: filters [13559,13566]
name: filters [13262,13269]
===
match
---
name: Session [29191,29198]
name: Session [28894,28901]
===
match
---
name: format [5181,5187]
name: format [5122,5128]
===
match
---
simple_stmt [2925,2957]
simple_stmt [2866,2898]
===
match
---
expr_stmt [23513,23585]
expr_stmt [23216,23288]
===
match
---
trailer [31175,31182]
trailer [30878,30885]
===
match
---
name: state [19466,19471]
name: state [19169,19174]
===
match
---
string: "Failed to get task '%s' for dag '%s'. Marking it as removed." [26160,26222]
string: "Failed to get task '%s' for dag '%s'. Marking it as removed." [25863,25925]
===
match
---
atom_expr [20355,20363]
atom_expr [20058,20066]
===
match
---
expr_stmt [24093,24168]
expr_stmt [23796,23871]
===
match
---
fstring_end: " [11230,11231]
fstring_end: " [10933,10934]
===
match
---
name: str [4006,4009]
name: str [3947,3950]
===
match
---
trailer [3394,3422]
trailer [3335,3363]
===
match
---
operator: = [3227,3228]
operator: = [3168,3169]
===
match
---
trailer [7523,7529]
trailer [7226,7232]
===
match
---
arglist [27047,27072]
arglist [26750,26775]
===
match
---
operator: = [3759,3760]
operator: = [3700,3701]
===
match
---
param [5382,5386]
param [5323,5327]
===
match
---
name: ut [19737,19739]
name: ut [19440,19442]
===
match
---
name: _state [5499,5505]
name: _state [5440,5446]
===
match
---
expr_stmt [2925,2956]
expr_stmt [2866,2897]
===
match
---
atom_expr [30154,30185]
atom_expr [29857,29888]
===
match
---
name: task [26390,26394]
name: task [26093,26097]
===
match
---
operator: = [18873,18874]
operator: = [18576,18577]
===
match
---
atom_expr [11203,11229]
atom_expr [10906,10932]
===
match
---
name: List [2246,2250]
name: List [2187,2191]
===
match
---
name: str [4316,4319]
name: str [4257,4260]
===
match
---
suite [25980,26053]
suite [25683,25756]
===
match
---
operator: { [26288,26289]
operator: { [25991,25992]
===
match
---
atom_expr [27693,27711]
atom_expr [27396,27414]
===
match
---
trailer [27286,27290]
trailer [26989,26993]
===
match
---
simple_stmt [12244,12296]
simple_stmt [11947,11999]
===
match
---
operator: , [18033,18034]
operator: , [17736,17737]
===
match
---
name: DEFAULT_DAGRUNS_TO_EXAMINE [7139,7165]
name: DEFAULT_DAGRUNS_TO_EXAMINE [6842,6868]
===
match
---
trailer [26159,26232]
trailer [25862,25935]
===
match
---
simple_stmt [16078,16139]
simple_stmt [15781,15842]
===
match
---
atom_expr [4611,4632]
atom_expr [4552,4573]
===
match
---
name: ordered_tis_by_start_date [23513,23538]
name: ordered_tis_by_start_date [23216,23241]
===
match
---
name: append [30167,30173]
name: append [29870,29876]
===
match
---
trailer [26793,26795]
trailer [26496,26498]
===
match
---
trailer [2947,2955]
trailer [2888,2896]
===
match
---
operator: != [5472,5474]
operator: != [5413,5415]
===
match
---
name: x [11834,11835]
name: x [11537,11538]
===
match
---
trailer [15523,15577]
trailer [15226,15280]
===
match
---
operator: , [899,900]
operator: , [899,900]
===
match
---
operator: = [14228,14229]
operator: = [13931,13932]
===
match
---
atom_expr [24602,24683]
atom_expr [24305,24386]
===
match
---
name: warning [24611,24618]
name: warning [24314,24321]
===
match
---
trailer [3854,3947]
trailer [3795,3888]
===
match
---
suite [2164,2367]
suite [2105,2308]
===
match
---
name: task_id [12818,12825]
name: task_id [12521,12528]
===
match
---
name: self [5563,5567]
name: self [5504,5508]
===
match
---
trailer [31182,31184]
trailer [30885,30887]
===
match
---
name: changed_tis [18954,18965]
name: changed_tis [18657,18668]
===
match
---
name: provide_session [13127,13142]
name: provide_session [12830,12845]
===
match
---
expr_stmt [2961,2994]
expr_stmt [2902,2935]
===
match
---
number: 50 [3077,3079]
number: 50 [3018,3020]
===
match
---
tfpdef [21418,21434]
tfpdef [21121,21137]
===
match
---
operator: , [26301,26302]
operator: , [26004,26005]
===
match
---
name: Stats [26595,26600]
name: Stats [26298,26303]
===
match
---
name: log [26148,26151]
name: log [25851,25854]
===
match
---
operator: = [18941,18942]
operator: = [18644,18645]
===
match
---
trailer [28849,28851]
trailer [28552,28554]
===
match
---
name: order_by [10973,10981]
name: order_by [10676,10684]
===
match
---
name: cls [28976,28979]
name: cls [28679,28682]
===
match
---
name: all [17019,17022]
name: all [16722,16725]
===
match
---
atom_expr [21400,21408]
atom_expr [21103,21111]
===
match
---
operator: = [19727,19728]
operator: = [19430,19431]
===
match
---
fstring_end: " [27014,27015]
fstring_end: " [26717,26718]
===
match
---
trailer [19822,19904]
trailer [19525,19607]
===
match
---
trailer [23280,23288]
trailer [22983,22991]
===
match
---
operator: , [5764,5765]
operator: , [5705,5706]
===
match
---
name: self [16385,16389]
name: self [16088,16092]
===
match
---
suite [5481,5692]
suite [5422,5633]
===
match
---
atom_expr [9781,9798]
atom_expr [9484,9501]
===
match
---
comparison [7491,7531]
comparison [7194,7234]
===
match
---
name: TaskNotFound [19283,19295]
name: TaskNotFound [18986,18998]
===
match
---
string: '_state' [5756,5764]
string: '_state' [5697,5705]
===
match
---
name: DAG [2119,2122]
name: DAG [2060,2063]
===
match
---
except_clause [27204,27232]
except_clause [26907,26935]
===
match
---
trailer [24996,25003]
trailer [24699,24706]
===
match
---
simple_stmt [15811,16013]
simple_stmt [15514,15716]
===
match
---
name: _get_ready_tis [20263,20277]
name: _get_ready_tis [19966,19980]
===
match
---
name: declarative [1139,1150]
name: declarative [1080,1091]
===
match
---
return_stmt [5059,5362]
return_stmt [5000,5303]
===
match
---
name: execution_date [13932,13946]
name: execution_date [13635,13649]
===
match
---
simple_stmt [18585,18659]
simple_stmt [18288,18362]
===
match
---
name: models [1516,1522]
name: models [1457,1463]
===
match
---
atom_expr [13005,13013]
atom_expr [12708,12716]
===
match
---
operator: , [29149,29150]
operator: , [28852,28853]
===
match
---
comparison [21206,21236]
comparison [20909,20939]
===
match
---
atom_expr [8280,8294]
atom_expr [7983,7997]
===
match
---
expr_stmt [26329,26353]
expr_stmt [26032,26056]
===
match
---
operator: = [26338,26339]
operator: = [26041,26042]
===
match
---
name: filter [10109,10115]
name: filter [9812,9818]
===
match
---
operator: } [11229,11230]
operator: } [10932,10933]
===
match
---
simple_stmt [12304,12321]
simple_stmt [12007,12024]
===
match
---
name: task_id [12375,12382]
name: task_id [12078,12085]
===
match
---
argument [3779,3792]
argument [3720,3733]
===
match
---
operator: = [2768,2769]
operator: = [2709,2710]
===
match
---
parameters [11049,11097]
parameters [10752,10800]
===
match
---
decorated [29107,31406]
decorated [28810,31109]
===
match
---
operator: , [20856,20857]
operator: , [20559,20560]
===
match
---
name: dag_id [5213,5219]
name: dag_id [5154,5160]
===
match
---
operator: = [20754,20755]
operator: = [20457,20458]
===
match
---
name: max_number [7939,7949]
name: max_number [7642,7652]
===
match
---
operator: , [13175,13176]
operator: , [12878,12879]
===
match
---
comp_op [13451,13457]
comp_op [13154,13160]
===
match
---
name: dag [13117,13120]
name: dag [12820,12823]
===
match
---
argument [18403,18429]
argument [18106,18132]
===
match
---
suite [29214,31406]
suite [28917,31109]
===
match
---
name: state [13177,13182]
name: state [12880,12885]
===
match
---
operator: , [13365,13366]
operator: , [13068,13069]
===
match
---
trailer [12728,12735]
trailer [12431,12438]
===
match
---
argument [23629,23657]
argument [23332,23360]
===
match
---
name: timezone [5542,5550]
name: timezone [5483,5491]
===
match
---
operator: = [14993,14994]
operator: = [14696,14697]
===
match
---
trailer [5557,5559]
trailer [5498,5500]
===
match
---
name: TI [12712,12714]
name: TI [12415,12417]
===
match
---
name: tis [11659,11662]
name: tis [11362,11365]
===
match
---
name: super [5007,5012]
name: super [4948,4953]
===
match
---
trailer [24376,24438]
trailer [24079,24141]
===
match
---
name: leaf_task_ids [16124,16137]
name: leaf_task_ids [15827,15840]
===
match
---
decorated [18790,20254]
decorated [18493,19957]
===
match
---
atom_expr [7135,7165]
atom_expr [6838,6868]
===
match
---
atom_expr [3271,3281]
atom_expr [3212,3222]
===
match
---
name: count [30267,30272]
name: count [29970,29975]
===
match
---
atom_expr [10049,10081]
atom_expr [9752,9784]
===
match
---
fstring_start: f" [26264,26266]
fstring_start: f" [25967,25969]
===
match
---
simple_stmt [2022,2065]
simple_stmt [1963,2006]
===
match
---
atom_expr [9975,10006]
atom_expr [9678,9709]
===
match
---
operator: , [17264,17265]
operator: , [16967,16968]
===
match
---
atom_expr [8357,8377]
atom_expr [8060,8080]
===
match
---
name: ti [25886,25888]
name: ti [25589,25591]
===
match
---
simple_stmt [10726,10784]
simple_stmt [10429,10487]
===
match
---
expr_stmt [15171,15191]
expr_stmt [14874,14894]
===
match
---
name: Optional [8280,8288]
name: Optional [7983,7991]
===
match
---
suite [5640,5692]
suite [5581,5633]
===
match
---
operator: , [27051,27052]
operator: , [26754,26755]
===
match
---
name: self [12201,12205]
name: self [11904,11908]
===
match
---
trailer [15529,15534]
trailer [15232,15237]
===
match
---
name: self [17897,17901]
name: self [17600,17604]
===
match
---
name: schedulable_tis [18915,18930]
name: schedulable_tis [18618,18633]
===
match
---
name: self [24506,24510]
name: self [24209,24213]
===
match
---
trailer [4964,4980]
trailer [4905,4921]
===
match
---
name: Boolean [3025,3032]
name: Boolean [2966,2973]
===
match
---
operator: = [18987,18988]
operator: = [18690,18691]
===
match
---
atom_expr [6411,6416]
atom_expr [6114,6119]
===
match
---
atom_expr [3760,3793]
atom_expr [3701,3734]
===
match
---
import_from [1824,1873]
import_from [1765,1814]
===
match
---
name: DagRun [13879,13885]
name: DagRun [13582,13588]
===
match
---
name: run_type [8347,8355]
name: run_type [8050,8058]
===
match
---
name: TI [12736,12738]
name: TI [12439,12441]
===
match
---
atom_expr [13337,13350]
atom_expr [13040,13053]
===
match
---
param [6506,6510]
param [6209,6213]
===
match
---
name: changed_tis [15370,15381]
name: changed_tis [15073,15084]
===
match
---
atom_expr [16269,16288]
atom_expr [15972,15991]
===
match
---
tfpdef [27664,27688]
tfpdef [27367,27391]
===
match
---
name: is_backfill [26863,26874]
name: is_backfill [26566,26577]
===
match
---
trailer [4795,4797]
trailer [4736,4738]
===
match
---
trailer [7431,7438]
trailer [7134,7141]
===
match
---
name: property [28427,28435]
name: property [28130,28138]
===
match
---
name: self [18994,18998]
name: self [18697,18701]
===
match
---
operator: , [28953,28954]
operator: , [28656,28657]
===
match
---
expr_stmt [15443,15483]
expr_stmt [15146,15186]
===
match
---
name: airflow [1401,1408]
name: airflow [1342,1349]
===
match
---
expr_stmt [16022,16069]
expr_stmt [15725,15772]
===
match
---
arglist [2878,2919]
arglist [2819,2860]
===
match
---
name: utils [1780,1785]
name: utils [1721,1726]
===
match
---
atom_expr [13709,13727]
atom_expr [13412,13430]
===
match
---
simple_stmt [23270,23291]
simple_stmt [22973,22994]
===
match
---
suite [27167,27196]
suite [26870,26899]
===
match
---
simple_stmt [15048,15091]
simple_stmt [14751,14794]
===
match
---
name: DagRun [13834,13840]
name: DagRun [13537,13543]
===
match
---
name: tis [11451,11454]
name: tis [11154,11157]
===
match
---
trailer [16335,16341]
trailer [16038,16044]
===
match
---
name: utcnow [31232,31238]
name: utcnow [30935,30941]
===
match
---
arith_expr [24106,24168]
arith_expr [23809,23871]
===
match
---
simple_stmt [7038,7078]
simple_stmt [6741,6781]
===
match
---
fstring_expr [26998,27014]
fstring_expr [26701,26717]
===
match
---
trailer [27254,27259]
trailer [26957,26962]
===
match
---
expr_stmt [19218,19263]
expr_stmt [18921,18966]
===
match
---
name: task [25821,25825]
name: task [25524,25528]
===
match
---
simple_stmt [26143,26233]
simple_stmt [25846,25936]
===
match
---
argument [15618,15675]
argument [15321,15378]
===
match
---
name: unfinished_tasks [16227,16243]
name: unfinished_tasks [15930,15946]
===
match
---
name: __tablename__ [2551,2564]
name: __tablename__ [2492,2505]
===
match
---
name: orm [1246,1249]
name: orm [1187,1190]
===
match
---
comparison [29009,29056]
comparison [28712,28759]
===
match
---
name: state [10618,10623]
name: state [10321,10326]
===
match
---
trailer [10912,10952]
trailer [10615,10655]
===
match
---
trailer [2777,2784]
trailer [2718,2725]
===
match
---
number: 0 [31279,31280]
number: 0 [30982,30983]
===
match
---
name: TI [12426,12428]
name: TI [12129,12131]
===
match
---
name: task_id [30249,30256]
name: task_id [29952,29959]
===
match
---
name: external_trigger [4616,4632]
name: external_trigger [4557,4573]
===
match
---
simple_stmt [28479,28527]
simple_stmt [28182,28230]
===
match
---
name: with_row_locks [1950,1964]
name: with_row_locks [1891,1905]
===
match
---
trailer [18998,19017]
trailer [18701,18720]
===
match
---
name: str [4356,4359]
name: str [4297,4300]
===
match
---
simple_stmt [23598,23674]
simple_stmt [23301,23377]
===
match
---
operator: -> [11098,11100]
operator: -> [10801,10803]
===
match
---
name: callback [14936,14944]
name: callback [14639,14647]
===
match
---
name: ti [27150,27152]
name: ti [26853,26855]
===
match
---
atom_expr [24188,24214]
atom_expr [23891,23917]
===
match
---
simple_stmt [4894,4919]
simple_stmt [4835,4860]
===
match
---
operator: , [2897,2898]
operator: , [2838,2839]
===
match
---
expr_stmt [21188,21257]
expr_stmt [20891,20960]
===
match
---
trailer [26862,26874]
trailer [26565,26577]
===
match
---
name: any [16248,16251]
name: any [15951,15954]
===
match
---
atom_expr [8540,8554]
atom_expr [8243,8257]
===
match
---
atom_expr [10823,10858]
atom_expr [10526,10561]
===
match
---
operator: = [3616,3617]
operator: = [3557,3558]
===
match
---
trailer [30173,30185]
trailer [29876,29888]
===
match
---
atom_expr [26812,26827]
atom_expr [26515,26530]
===
match
---
trailer [16040,16048]
trailer [15743,15751]
===
match
---
name: self [5208,5212]
name: self [5149,5153]
===
match
---
suite [12231,12296]
suite [11934,11999]
===
match
---
name: DagRunType [7323,7333]
name: DagRunType [7026,7036]
===
match
---
name: join [7361,7365]
name: join [7064,7068]
===
match
---
name: State [31113,31118]
name: State [30816,30821]
===
match
---
operator: , [21983,21984]
operator: , [21686,21687]
===
match
---
name: warning [24758,24765]
name: warning [24461,24468]
===
match
---
name: conf [4665,4669]
name: conf [4606,4610]
===
match
---
string: """Type of return for DagRun.task_instance_scheduling_decisions""" [2169,2235]
string: """Type of return for DagRun.task_instance_scheduling_decisions""" [2110,2176]
===
match
---
operator: = [9973,9974]
operator: = [9676,9677]
===
match
---
parameters [5043,5049]
parameters [4984,4990]
===
match
---
operator: , [4407,4408]
operator: , [4348,4349]
===
match
---
operator: = [20676,20677]
operator: = [20379,20380]
===
match
---
trailer [28283,28300]
trailer [27986,28003]
===
match
---
name: isinstance [9829,9839]
name: isinstance [9532,9542]
===
match
---
atom_expr [6401,6408]
atom_expr [6104,6111]
===
match
---
param [20287,20292]
param [19990,19995]
===
match
---
suite [17834,18449]
suite [17537,18152]
===
match
---
trailer [13717,13727]
trailer [13420,13430]
===
match
---
name: in_ [12177,12180]
name: in_ [11880,11883]
===
match
---
name: state [6519,6524]
name: state [6222,6227]
===
match
---
name: should_restore_task [26453,26472]
name: should_restore_task [26156,26175]
===
match
---
name: dag_hash [4943,4951]
name: dag_hash [4884,4892]
===
match
---
dotted_name [1772,1803]
dotted_name [1713,1744]
===
match
---
argument [16505,16526]
argument [16208,16229]
===
match
---
name: str [11637,11640]
name: str [11340,11343]
===
match
---
simple_stmt [4574,4603]
simple_stmt [4515,4544]
===
match
---
atom_expr [13354,13365]
atom_expr [13057,13068]
===
match
---
name: Optional [4434,4442]
name: Optional [4375,4383]
===
match
---
atom_expr [16730,16741]
atom_expr [16433,16444]
===
match
---
name: task_instance_mutation_hook [25520,25547]
name: task_instance_mutation_hook [25223,25250]
===
match
---
name: ti [30246,30248]
name: ti [29949,29951]
===
match
---
name: self [13112,13116]
name: self [12815,12819]
===
match
---
comparison [17023,17060]
comparison [16726,16763]
===
match
---
name: datetime [792,800]
name: datetime [792,800]
===
match
---
atom_expr [27365,27375]
atom_expr [27068,27078]
===
match
---
if_stmt [30757,31384]
if_stmt [30460,31087]
===
match
---
arglist [26974,27021]
arglist [26677,26724]
===
match
---
name: isinstance [11619,11629]
name: isinstance [11322,11332]
===
match
---
name: self [23154,23158]
name: self [22857,22861]
===
match
---
operator: , [4107,4108]
operator: , [4048,4049]
===
match
---
trailer [17045,17060]
trailer [16748,16763]
===
match
---
atom_expr [3617,3679]
atom_expr [3558,3620]
===
match
---
name: session [28595,28602]
name: session [28298,28305]
===
match
---
operator: = [2698,2699]
operator: = [2639,2640]
===
match
---
name: TaskInstance [1543,1555]
name: TaskInstance [1484,1496]
===
match
---
name: timezone [1758,1766]
name: timezone [1699,1707]
===
match
---
name: dag_id [30894,30900]
name: dag_id [30597,30603]
===
match
---
atom_expr [24749,24828]
atom_expr [24452,24531]
===
match
---
name: execution_date [3646,3660]
name: execution_date [3587,3601]
===
match
---
trailer [17424,17668]
trailer [17127,17371]
===
match
---
name: dag [18100,18103]
name: dag [17803,17806]
===
match
---
atom [30597,30624]
atom [30300,30327]
===
match
---
operator: , [19417,19418]
operator: , [19120,19121]
===
match
---
trailer [24368,24376]
trailer [24071,24079]
===
match
---
simple_stmt [3304,3549]
simple_stmt [3245,3490]
===
match
---
argument [16763,16797]
argument [16466,16500]
===
match
---
trailer [9913,9937]
trailer [9616,9640]
===
match
---
simple_stmt [21024,21074]
simple_stmt [20727,20777]
===
match
---
name: TI [31103,31105]
name: TI [30806,30808]
===
match
---
decorated [28532,29102]
decorated [28235,28805]
===
match
---
name: Session [27642,27649]
name: Session [27345,27352]
===
match
---
name: State [5578,5583]
name: State [5519,5524]
===
match
---
name: State [24925,24930]
name: State [24628,24633]
===
match
---
trailer [26834,26849]
trailer [26537,26552]
===
match
---
name: dag [15171,15174]
name: dag [14874,14877]
===
match
---
dictorsetmaker [31103,31281]
dictorsetmaker [30806,30984]
===
match
---
name: TYPE_CHECKING [836,849]
name: TYPE_CHECKING [836,849]
===
match
---
name: Optional [4270,4278]
name: Optional [4211,4219]
===
match
---
name: DR [9795,9797]
name: DR [9498,9500]
===
match
---
name: bool [2302,2306]
name: bool [2243,2247]
===
match
---
trailer [12263,12271]
trailer [11966,11974]
===
match
---
argument [17266,17278]
argument [16969,16981]
===
match
---
name: execution_date [10985,10999]
name: execution_date [10688,10702]
===
match
---
testlist_star_expr [19917,19945]
testlist_star_expr [19620,19648]
===
match
---
fstring_start: f' [27362,27364]
fstring_start: f' [27065,27067]
===
match
---
trailer [11227,11229]
trailer [10930,10932]
===
match
---
name: task [15620,15624]
name: task [15323,15327]
===
match
---
trailer [4504,4511]
trailer [4445,4452]
===
match
---
simple_stmt [26367,26438]
simple_stmt [26070,26141]
===
match
---
name: following_schedule [24129,24147]
name: following_schedule [23832,23850]
===
match
---
name: Column [3018,3024]
name: Column [2959,2965]
===
match
---
name: info [15279,15283]
name: info [14982,14986]
===
match
---
operator: , [27015,27016]
operator: , [26718,26719]
===
match
---
name: set_state [16390,16399]
name: set_state [16093,16102]
===
match
---
name: dag_id [3353,3359]
name: dag_id [3294,3300]
===
match
---
name: log [17852,17855]
name: log [17555,17558]
===
match
---
name: ordered_tis_by_start_date [23705,23730]
name: ordered_tis_by_start_date [23408,23433]
===
match
---
suite [14308,18785]
suite [14011,18488]
===
match
---
param [13177,13205]
param [12880,12908]
===
match
---
operator: = [23539,23540]
operator: = [23242,23243]
===
match
---
operator: = [7954,7955]
operator: = [7657,7658]
===
match
---
argument [5281,5299]
argument [5222,5240]
===
match
---
fstring_expr [27364,27376]
fstring_expr [27067,27079]
===
match
---
atom_expr [11303,11340]
atom_expr [11006,11043]
===
match
---
fstring_start: f" [15116,15118]
fstring_start: f" [14819,14821]
===
match
---
arith_expr [19041,19078]
arith_expr [18744,18781]
===
match
---
atom_expr [5657,5671]
atom_expr [5598,5612]
===
match
---
return_stmt [20556,20585]
return_stmt [20259,20288]
===
match
---
name: self [23276,23280]
name: self [22979,22983]
===
match
---
name: are_dependencies_met [21670,21690]
name: are_dependencies_met [21373,21393]
===
match
---
name: self [26858,26862]
name: self [26561,26565]
===
match
---
name: external_trigger [5335,5351]
name: external_trigger [5276,5292]
===
match
---
operator: , [4327,4328]
operator: , [4268,4269]
===
match
---
trailer [24212,24214]
trailer [23915,23917]
===
match
---
comp_if [16107,16137]
comp_if [15810,15840]
===
match
---
fstring_expr [27379,27400]
fstring_expr [27082,27103]
===
match
---
name: list [10076,10080]
name: list [9779,9783]
===
match
---
simple_stmt [18983,19081]
simple_stmt [18686,18784]
===
match
---
name: execution_date [3727,3741]
name: execution_date [3668,3682]
===
match
---
atom [18943,18945]
atom [18646,18648]
===
match
---
atom_expr [2668,2682]
atom_expr [2609,2623]
===
match
---
trailer [24915,24921]
trailer [24618,24624]
===
match
---
simple_stmt [27429,27470]
simple_stmt [27132,27173]
===
match
---
name: state [5720,5725]
name: state [5661,5666]
===
match
---
atom_expr [12088,12106]
atom_expr [11791,11809]
===
match
---
argument [21968,21983]
argument [21671,21686]
===
match
---
name: task [27047,27051]
name: task [26750,26754]
===
match
---
name: debug [19098,19103]
name: debug [18801,18806]
===
match
---
name: info [27291,27295]
name: info [26994,26998]
===
match
---
name: TI [12804,12806]
name: TI [12507,12509]
===
match
---
arglist [12058,12106]
arglist [11761,11809]
===
match
---
name: external_trigger [4635,4651]
name: external_trigger [4576,4592]
===
match
---
atom_expr [5542,5559]
atom_expr [5483,5500]
===
match
---
trailer [12425,12429]
trailer [12128,12132]
===
match
---
simple_stmt [19089,19162]
simple_stmt [18792,18865]
===
match
---
tfpdef [4377,4400]
tfpdef [4318,4341]
===
match
---
operator: = [2836,2837]
operator: = [2777,2778]
===
match
---
trailer [23114,23122]
trailer [22817,22825]
===
match
---
argument [3034,3046]
argument [2975,2987]
===
match
---
comp_if [19637,19665]
comp_if [19340,19368]
===
match
---
fstring [24377,24437]
fstring [24080,24140]
===
match
---
comparison [10654,10671]
comparison [10357,10374]
===
match
---
trailer [30097,30102]
trailer [29800,29805]
===
match
---
operator: == [28250,28252]
operator: == [27953,27955]
===
match
---
name: Stats [1588,1593]
name: Stats [1529,1534]
===
match
---
name: dag_id [25114,25120]
name: dag_id [24817,24823]
===
match
---
operator: { [26629,26630]
operator: { [26332,26333]
===
match
---
name: UtcDateTime [2748,2759]
name: UtcDateTime [2689,2700]
===
match
---
name: warning [19322,19329]
name: warning [19025,19032]
===
match
---
suite [4462,5026]
suite [4403,4967]
===
match
---
tfpdef [21384,21408]
tfpdef [21087,21111]
===
match
---
trailer [17164,17174]
trailer [16867,16877]
===
match
---
name: self [25109,25113]
name: self [24812,24816]
===
match
---
argument [20213,20242]
argument [19916,19945]
===
match
---
operator: , [13907,13908]
operator: , [13610,13611]
===
match
---
trailer [11464,11470]
trailer [11167,11173]
===
match
---
if_stmt [24562,24703]
if_stmt [24265,24406]
===
match
---
atom_expr [2276,2284]
atom_expr [2217,2225]
===
match
---
trailer [10327,10396]
trailer [10030,10099]
===
match
---
name: session [13820,13827]
name: session [13523,13530]
===
match
---
if_stmt [11616,12189]
if_stmt [11319,11892]
===
match
---
operator: = [21719,21720]
operator: = [21422,21423]
===
match
---
operator: , [30553,30554]
operator: , [30256,30257]
===
match
---
atom_expr [16252,16265]
atom_expr [15955,15968]
===
match
---
trailer [8365,8377]
trailer [8068,8080]
===
match
---
trailer [5180,5187]
trailer [5121,5128]
===
match
---
name: session [25624,25631]
name: session [25327,25334]
===
match
---
name: Stats [26253,26258]
name: Stats [25956,25961]
===
match
---
suite [2083,2123]
suite [2024,2064]
===
match
---
atom_expr [4780,4797]
atom_expr [4721,4738]
===
match
---
trailer [28815,28827]
trailer [28518,28530]
===
match
---
name: cls [7135,7138]
name: cls [6838,6841]
===
match
---
name: execution_start_date [10354,10374]
name: execution_start_date [10057,10077]
===
match
---
name: dag_id [13359,13365]
name: dag_id [13062,13068]
===
match
---
name: is_ [11911,11914]
name: is_ [11614,11617]
===
match
---
trailer [4043,4048]
trailer [3984,3989]
===
match
---
simple_stmt [20488,20508]
simple_stmt [20191,20211]
===
match
---
atom_expr [20944,20962]
atom_expr [20647,20665]
===
match
---
operator: , [3725,3726]
operator: , [3666,3667]
===
match
---
simple_stmt [10637,10673]
simple_stmt [10340,10376]
===
match
---
name: old_states [20944,20954]
name: old_states [20647,20657]
===
match
---
dotted_name [1401,1419]
dotted_name [1342,1360]
===
match
---
name: state [11800,11805]
name: state [11503,11508]
===
match
---
operator: @ [28549,28550]
operator: @ [28252,28253]
===
match
---
operator: <= [7868,7870]
operator: <= [7571,7573]
===
match
---
trailer [25888,25896]
trailer [25591,25599]
===
match
---
argument [2630,2646]
argument [2571,2587]
===
match
---
name: TI [30984,30986]
name: TI [30687,30689]
===
match
---
name: task_instance_mutation_hook [27090,27117]
name: task_instance_mutation_hook [26793,26820]
===
match
---
name: Optional [8190,8198]
name: Optional [7893,7901]
===
match
---
trailer [7365,7453]
trailer [7068,7156]
===
match
---
name: update [30590,30596]
name: update [30293,30299]
===
match
---
trailer [24930,24938]
trailer [24633,24641]
===
match
---
param [8347,8385]
param [8050,8088]
===
match
---
trailer [10826,10833]
trailer [10529,10536]
===
match
---
simple_stmt [15273,15288]
simple_stmt [14976,14991]
===
match
---
simple_stmt [4927,4952]
simple_stmt [4868,4893]
===
match
---
trailer [11675,11694]
trailer [11378,11397]
===
match
---
name: finished_tasks [15935,15949]
name: finished_tasks [15638,15652]
===
match
---
operator: } [25120,25121]
operator: } [24823,24824]
===
match
---
atom_expr [10195,10242]
atom_expr [9898,9945]
===
match
---
atom_expr [10643,10672]
atom_expr [10346,10375]
===
match
---
fstring_expr [11202,11230]
fstring_expr [10905,10933]
===
match
---
atom_expr [18989,19080]
atom_expr [18692,18783]
===
match
---
name: execution_start_date [10482,10502]
name: execution_start_date [10185,10205]
===
match
---
dotted_name [1829,1850]
dotted_name [1770,1791]
===
match
---
operator: -> [12881,12883]
operator: -> [12584,12586]
===
match
---
atom_expr [13033,13095]
atom_expr [12736,12798]
===
match
---
simple_stmt [11393,11443]
simple_stmt [11096,11146]
===
match
---
atom_expr [16248,16313]
atom_expr [15951,16016]
===
match
---
name: Index [3331,3336]
name: Index [3272,3277]
===
match
---
trailer [20359,20363]
trailer [20062,20066]
===
match
---
parameters [11280,11367]
parameters [10983,11070]
===
match
---
name: all [29086,29089]
name: all [28789,28792]
===
match
---
atom_expr [5494,5505]
atom_expr [5435,5446]
===
match
---
atom_expr [15365,15381]
atom_expr [15068,15084]
===
match
---
name: self [5288,5292]
name: self [5229,5233]
===
match
---
operator: = [15409,15410]
operator: = [15112,15113]
===
match
---
name: set_state [18551,18560]
name: set_state [18254,18263]
===
match
---
name: state [8225,8230]
name: state [7928,7933]
===
match
---
name: Optional [8357,8365]
name: Optional [8060,8068]
===
match
---
expr_stmt [15048,15090]
expr_stmt [14751,14793]
===
match
---
with_stmt [15099,16013]
with_stmt [14802,15716]
===
match
---
atom_expr [30457,30474]
atom_expr [30160,30177]
===
match
---
atom_expr [25070,25133]
atom_expr [24773,24836]
===
match
---
comparison [12736,12760]
comparison [12439,12463]
===
match
---
classdef [2369,31406]
classdef [2310,31109]
===
match
---
trailer [27263,27268]
trailer [26966,26971]
===
match
---
simple_stmt [17240,17315]
simple_stmt [16943,17018]
===
match
---
name: execution_date [10138,10152]
name: execution_date [9841,9855]
===
match
---
arglist [5201,5352]
arglist [5142,5293]
===
match
---
simple_stmt [3806,3948]
simple_stmt [3747,3889]
===
match
---
operator: = [2612,2613]
operator: = [2553,2554]
===
match
---
for_stmt [29922,30258]
for_stmt [29625,29961]
===
match
---
operator: = [28698,28699]
operator: = [28401,28402]
===
match
---
name: get_latest_runs [28574,28589]
name: get_latest_runs [28277,28292]
===
match
---
fstring [24253,24303]
fstring [23956,24006]
===
match
---
fstring_start: f' [24253,24255]
fstring_start: f' [23956,23958]
===
match
---
operator: , [23657,23658]
operator: , [23360,23361]
===
match
---
operator: , [4017,4018]
operator: , [3958,3959]
===
match
---
simple_stmt [1230,1273]
simple_stmt [1171,1214]
===
match
---
trailer [26494,26498]
trailer [26197,26201]
===
match
---
simple_stmt [9807,9865]
simple_stmt [9510,9568]
===
match
---
name: dag_ids [9928,9935]
name: dag_ids [9631,9638]
===
match
---
name: or_ [12054,12057]
name: or_ [11757,11760]
===
match
---
operator: = [13698,13699]
operator: = [13401,13402]
===
match
---
trailer [12053,12108]
trailer [11756,11811]
===
match
---
name: self [6225,6229]
name: self [6047,6051]
===
match
---
trailer [26707,26713]
trailer [26410,26416]
===
match
---
simple_stmt [24857,24900]
simple_stmt [24560,24603]
===
match
---
operator: , [17649,17650]
operator: , [17352,17353]
===
match
---
suite [9956,10007]
suite [9659,9710]
===
match
---
suite [15158,16013]
suite [14861,15716]
===
match
---
simple_stmt [1396,1458]
simple_stmt [1337,1399]
===
match
---
trailer [23158,23175]
trailer [22861,22878]
===
match
---
operator: , [30962,30963]
operator: , [30665,30666]
===
match
---
name: execution_date [11203,11217]
name: execution_date [10906,10920]
===
match
---
expr_stmt [20455,20479]
expr_stmt [20158,20182]
===
match
---
name: session [19026,19033]
name: session [18729,18736]
===
match
---
operator: == [24922,24924]
operator: == [24625,24627]
===
match
---
name: s [11996,11997]
name: s [11699,11700]
===
match
---
and_test [12201,12230]
and_test [11904,11933]
===
match
---
operator: = [11455,11456]
operator: = [11158,11159]
===
match
---
name: start_dttm [15080,15090]
name: start_dttm [14783,14793]
===
match
---
atom_expr [4035,4048]
atom_expr [3976,3989]
===
match
---
trailer [23315,23319]
trailer [23018,23022]
===
match
---
name: old_state [20965,20974]
name: old_state [20668,20677]
===
match
---
name: dag [23346,23349]
name: dag [23049,23052]
===
match
---
trailer [10836,10845]
trailer [10539,10548]
===
match
---
name: uselist [3779,3786]
name: uselist [3720,3727]
===
match
---
trailer [7845,7882]
trailer [7548,7585]
===
match
---
funcdef [29128,31406]
funcdef [28831,31109]
===
match
---
name: query [7927,7932]
name: query [7630,7635]
===
match
---
atom_expr [2700,2719]
atom_expr [2641,2660]
===
match
---
trailer [3621,3679]
trailer [3562,3620]
===
match
---
atom_expr [26143,26232]
atom_expr [25846,25935]
===
match
---
simple_stmt [23237,23244]
simple_stmt [22940,22947]
===
match
---
name: self [26074,26078]
name: self [25777,25781]
===
match
---
simple_stmt [24841,24848]
simple_stmt [24544,24551]
===
match
---
param [13171,13176]
param [12874,12879]
===
match
---
trailer [9916,9923]
trailer [9619,9626]
===
match
---
import_from [1767,1823]
import_from [1708,1764]
===
match
---
operator: , [14202,14203]
operator: , [13905,13906]
===
match
---
name: query [13537,13542]
name: query [13240,13245]
===
match
---
name: TI [2363,2365]
name: TI [2304,2306]
===
match
---
name: tis [16103,16106]
name: tis [15806,15809]
===
match
---
trailer [25971,25979]
trailer [25674,25682]
===
match
---
name: Iterable [11371,11379]
name: Iterable [11074,11082]
===
match
---
name: PickleType [3116,3126]
name: PickleType [3057,3067]
===
match
---
atom_expr [23705,23744]
atom_expr [23408,23447]
===
match
---
operator: = [25561,25562]
operator: = [25264,25265]
===
match
---
name: self [30478,30482]
name: self [30181,30185]
===
match
---
trailer [12787,12802]
trailer [12490,12505]
===
match
---
name: qry [9775,9778]
name: qry [9478,9481]
===
match
---
name: execution_date [10209,10223]
name: execution_date [9912,9926]
===
match
---
name: dag_id [30414,30420]
name: dag_id [30117,30123]
===
match
---
arglist [25083,25132]
arglist [24786,24835]
===
match
---
trailer [12160,12167]
trailer [11863,11870]
===
match
---
operator: = [25826,25827]
operator: = [25529,25530]
===
match
---
name: execution_date [5233,5247]
name: execution_date [5174,5188]
===
match
---
name: handle_callback [17998,18013]
name: handle_callback [17701,17716]
===
match
---
atom_expr [4927,4940]
atom_expr [4868,4881]
===
match
---
parameters [5864,5895]
parameters [5805,5836]
===
match
---
name: is_backfill [28444,28455]
name: is_backfill [28147,28158]
===
match
---
argument [20129,20152]
argument [19832,19855]
===
match
---
name: cls [28728,28731]
name: cls [28431,28434]
===
match
---
atom_expr [27044,27073]
atom_expr [26747,26776]
===
match
---
name: finished_tasks [20793,20807]
name: finished_tasks [20496,20510]
===
match
---
name: dependencies_states [1666,1685]
name: dependencies_states [1607,1626]
===
match
---
name: self [24488,24492]
name: self [24191,24195]
===
match
---
trailer [28408,28410]
trailer [28111,28113]
===
match
---
name: Column [2661,2667]
name: Column [2602,2608]
===
match
---
name: airflow [2093,2100]
name: airflow [2034,2041]
===
match
---
name: String [3070,3076]
name: String [3011,3017]
===
match
---
name: DagCallbackRequest [17406,17424]
name: DagCallbackRequest [17109,17127]
===
match
---
operator: - [24123,24124]
operator: - [23826,23827]
===
match
---
tfpdef [4417,4447]
tfpdef [4358,4388]
===
match
---
param [8311,8338]
param [8014,8041]
===
match
---
trailer [21404,21408]
trailer [21107,21111]
===
match
---
trailer [9927,9936]
trailer [9630,9639]
===
match
---
name: get_dag [12867,12874]
name: get_dag [12570,12577]
===
match
---
fstring_end: " [15155,15156]
fstring_end: " [14858,14859]
===
match
---
param [4417,4455]
param [4358,4396]
===
match
---
suite [10536,10607]
suite [10239,10310]
===
match
---
argument [19018,19033]
argument [18721,18736]
===
match
---
name: flush [19512,19517]
name: flush [19215,19220]
===
match
---
name: full_filepath [18214,18227]
name: full_filepath [17917,17930]
===
match
---
trailer [2250,2254]
trailer [2191,2195]
===
match
---
name: get_state [5791,5800]
name: get_state [5732,5741]
===
match
---
name: cls [7955,7958]
name: cls [7658,7661]
===
match
---
operator: , [25005,25006]
operator: , [24708,24709]
===
match
---
trailer [28768,28774]
trailer [28471,28477]
===
match
---
name: execution_date [13408,13422]
name: execution_date [13111,13125]
===
match
---
string: "Restoring task '%s' which was previously removed from DAG '%s'" [26504,26568]
string: "Restoring task '%s' which was previously removed from DAG '%s'" [26207,26271]
===
match
---
name: execution_date [11559,11573]
name: execution_date [11262,11276]
===
match
---
name: staticmethod [11013,11025]
name: staticmethod [10716,10728]
===
match
---
trailer [5408,5415]
trailer [5349,5356]
===
match
---
tfpdef [4027,4048]
tfpdef [3968,3989]
===
match
---
operator: = [17639,17640]
operator: = [17342,17343]
===
match
---
atom_expr [4471,4482]
atom_expr [4412,4423]
===
match
---
atom_expr [30889,30900]
atom_expr [30592,30603]
===
match
---
operator: , [20414,20415]
operator: , [20117,20118]
===
match
---
operator: == [9996,9998]
operator: == [9699,9701]
===
match
---
name: filter [13855,13861]
name: filter [13558,13564]
===
match
---
name: queued_at [4864,4873]
name: queued_at [4805,4814]
===
match
---
string: "DAG" [12884,12889]
string: "DAG" [12587,12592]
===
match
---
not_test [30039,30070]
not_test [29742,29773]
===
match
---
name: self [4894,4898]
name: self [4835,4839]
===
match
---
name: dag [25873,25876]
name: dag [25576,25579]
===
match
---
name: leaves [16062,16068]
name: leaves [15765,15771]
===
match
---
trailer [27701,27711]
trailer [27404,27414]
===
match
---
atom_expr [12043,12108]
atom_expr [11746,11811]
===
match
---
simple_stmt [24093,24169]
simple_stmt [23796,23872]
===
match
---
name: run_id [5281,5287]
name: run_id [5222,5228]
===
match
---
trailer [5550,5557]
trailer [5491,5498]
===
match
---
name: run_type [3052,3060]
name: run_type [2993,3001]
===
match
---
atom_expr [26700,26717]
atom_expr [26403,26420]
===
match
---
argument [3605,3679]
argument [3546,3620]
===
match
---
name: run_id [8136,8142]
name: run_id [7839,7845]
===
match
---
name: dag [18228,18231]
name: dag [17931,17934]
===
match
---
simple_stmt [13522,13615]
simple_stmt [13225,13318]
===
match
---
atom [26389,26407]
atom [26092,26110]
===
match
---
name: state [6441,6446]
name: state [6144,6149]
===
match
---
and_test [16994,17085]
and_test [16697,16788]
===
match
---
suite [5448,5692]
suite [5389,5633]
===
match
---
trailer [5682,5689]
trailer [5623,5630]
===
match
---
fstring_string: . [27400,27401]
fstring_string: . [27103,27104]
===
match
---
atom_expr [5563,5574]
atom_expr [5504,5515]
===
match
---
name: Optional [4347,4355]
name: Optional [4288,4296]
===
match
---
name: filter [10321,10327]
name: filter [10024,10030]
===
match
---
operator: } [31302,31303]
operator: } [31005,31006]
===
match
---
trailer [12100,12106]
trailer [11803,11809]
===
match
---
tfpdef [5871,5887]
tfpdef [5812,5828]
===
match
---
funcdef [22054,24439]
funcdef [21757,24142]
===
match
---
atom_expr [7871,7881]
atom_expr [7574,7584]
===
match
---
trailer [11629,11641]
trailer [11332,11344]
===
match
---
name: _are_premature_tis [21306,21324]
name: _are_premature_tis [21009,21027]
===
match
---
suite [25849,25898]
suite [25552,25601]
===
match
---
atom_expr [21218,21236]
atom_expr [20921,20939]
===
match
---
name: tis [19633,19636]
name: tis [19336,19339]
===
match
---
arglist [18214,18430]
arglist [17917,18133]
===
match
---
operator: , [18279,18280]
operator: , [17982,17983]
===
match
---
atom_expr [30174,30184]
atom_expr [29877,29887]
===
match
---
name: start_date [24570,24580]
name: start_date [24273,24283]
===
match
---
name: State [26677,26682]
name: State [26380,26385]
===
match
---
simple_stmt [15171,15192]
simple_stmt [14874,14895]
===
match
---
name: finished_tasks [20228,20242]
name: finished_tasks [19931,19945]
===
match
---
name: dag_id [18261,18267]
name: dag_id [17964,17970]
===
match
---
name: dag [16464,16467]
name: dag [16167,16170]
===
match
---
string: """         Set the given task instances in to the scheduled state.          Each element of ``schedulable_tis`` should have it's ``task`` attribute already set.          Any DummyOperator without callbacks is instead set straight to the success state.          All the TIs should belong to this DagRun, but this code is in the hot-path, this is not checked -- it         is the caller's responsibility to call this function only with TIs from a single dag run.         """ [29223,29696]
string: """         Set the given task instances in to the scheduled state.          Each element of ``schedulable_tis`` should have it's ``task`` attribute already set.          Any DummyOperator without callbacks is instead set straight to the success state.          All the TIs should belong to this DagRun, but this code is in the hot-path, this is not checked -- it         is the caller's responsibility to call this function only with TIs from a single dag run.         """ [28926,29399]
===
match
---
name: _emit_duration_stats_for_finished_state [24448,24487]
name: _emit_duration_stats_for_finished_state [24151,24190]
===
match
---
fstring_string: dagrun.duration.success. [24967,24991]
fstring_string: dagrun.duration.success. [24670,24694]
===
match
---
argument [11834,11858]
argument [11537,11561]
===
match
---
simple_stmt [17377,17669]
simple_stmt [17080,17372]
===
match
---
tfpdef [14179,14195]
tfpdef [13882,13898]
===
match
---
name: old_states [21218,21228]
name: old_states [20921,20931]
===
match
---
funcdef [8062,11007]
funcdef [7765,10710]
===
match
---
name: state [12171,12176]
name: state [11874,11879]
===
match
---
name: task_id [30522,30529]
name: task_id [30225,30232]
===
match
---
comparison [13879,13907]
comparison [13582,13610]
===
match
---
comparison [24714,24735]
comparison [24417,24438]
===
match
---
name: execution_date [12765,12779]
name: execution_date [12468,12482]
===
match
---
name: order_by [7617,7625]
name: order_by [7320,7328]
===
match
---
name: dag [12206,12209]
name: dag [11909,11912]
===
match
---
name: self [27429,27433]
name: self [27132,27136]
===
match
---
simple_stmt [24696,24703]
simple_stmt [24399,24406]
===
match
---
atom_expr [24868,24881]
atom_expr [24571,24584]
===
match
---
name: add [25793,25796]
name: add [25496,25499]
===
match
---
if_stmt [11594,12189]
if_stmt [11297,11892]
===
match
---
not_test [20520,20542]
not_test [20223,20245]
===
match
---
arglist [3593,3794]
arglist [3534,3735]
===
match
---
name: self [17847,17851]
name: self [17550,17554]
===
match
---
name: Optional [8144,8152]
name: Optional [7847,7855]
===
match
---
name: TI [18937,18939]
name: TI [18640,18642]
===
match
---
name: ti [21229,21231]
name: ti [20932,20934]
===
match
---
simple_stmt [20431,20447]
simple_stmt [20134,20150]
===
match
---
string: """         Verifies the DagRun by checking for removed tasks or tasks that are not in the         database yet. It will set state to removed or add the task if required.          :param session: Sqlalchemy ORM Session         :type session: Session         """ [25221,25482]
string: """         Verifies the DagRun by checking for removed tasks or tasks that are not in the         database yet. It will set state to removed or add the task if required.          :param session: Sqlalchemy ORM Session         :type session: Session         """ [24924,25185]
===
match
---
simple_stmt [5494,5514]
simple_stmt [5435,5455]
===
match
---
atom_expr [13925,13946]
atom_expr [13628,13649]
===
match
---
atom_expr [3478,3541]
atom_expr [3419,3482]
===
match
---
argument [15524,15576]
argument [15227,15279]
===
match
---
comparison [25954,25979]
comparison [25657,25682]
===
match
---
name: execution_date [26835,26849]
name: execution_date [26538,26552]
===
match
---
if_stmt [23092,23143]
if_stmt [22795,22846]
===
match
---
operator: , [30900,30901]
operator: , [30603,30604]
===
match
---
atom_expr [5578,5592]
atom_expr [5519,5533]
===
match
---
name: cls [28590,28593]
name: cls [28293,28296]
===
match
---
name: run_type [4899,4907]
name: run_type [4840,4848]
===
match
---
name: DR [10328,10330]
name: DR [10031,10033]
===
match
---
atom_expr [18585,18658]
atom_expr [18288,18361]
===
match
---
name: primaryjoin [3605,3616]
name: primaryjoin [3546,3557]
===
match
---
name: filter [10906,10912]
name: filter [10609,10615]
===
match
---
except_clause [25910,25933]
except_clause [25613,25636]
===
match
---
trailer [16259,16265]
trailer [15962,15968]
===
match
---
name: dag [3288,3291]
name: dag [3229,3232]
===
match
---
name: error [16336,16341]
name: error [16039,16044]
===
match
---
name: ti [26666,26668]
name: ti [26369,26371]
===
match
---
param [11296,11348]
param [10999,11051]
===
match
---
name: finished_tasks [21917,21931]
name: finished_tasks [21620,21634]
===
match
---
atom_expr [12261,12294]
atom_expr [11964,11997]
===
match
---
operator: + [19059,19060]
operator: + [18762,18763]
===
match
---
name: get_dag [25568,25575]
name: get_dag [25271,25278]
===
match
---
name: log [17104,17107]
name: log [16807,16810]
===
match
---
name: append [13484,13490]
name: append [13187,13193]
===
match
---
name: Session [8403,8410]
name: Session [8106,8113]
===
match
---
operator: , [6597,6598]
operator: , [6300,6301]
===
match
---
name: query [7825,7830]
name: query [7528,7533]
===
match
---
operator: , [5869,5870]
operator: , [5810,5811]
===
match
---
argument [25616,25631]
argument [25319,25334]
===
match
---
name: error [17856,17861]
name: error [17559,17564]
===
match
---
name: Column [3109,3115]
name: Column [3050,3056]
===
match
---
suite [24939,25017]
suite [24642,24720]
===
match
---
operator: = [21035,21036]
operator: = [20738,20739]
===
match
---
operator: , [3541,3542]
operator: , [3482,3483]
===
match
---
name: execution_date [16783,16797]
name: execution_date [16486,16500]
===
match
---
name: airflow [25496,25503]
name: airflow [25199,25206]
===
match
---
atom_expr [7643,7701]
atom_expr [7346,7404]
===
match
---
atom_expr [21037,21073]
atom_expr [20740,20776]
===
match
---
name: Session [6548,6555]
name: Session [6251,6258]
===
match
---
tfpdef [8427,8467]
tfpdef [8130,8170]
===
match
---
name: task_id [30987,30994]
name: task_id [30690,30697]
===
match
---
trailer [27117,27121]
trailer [26820,26824]
===
match
---
name: State [19651,19656]
name: State [19354,19359]
===
match
---
number: 1 [27017,27018]
number: 1 [26720,26721]
===
match
---
dotted_name [2093,2111]
dotted_name [2034,2052]
===
match
---
name: execution_date [17553,17567]
name: execution_date [17256,17270]
===
match
---
decorators [8023,8058]
decorators [7726,7761]
===
match
---
atom_expr [9914,9936]
atom_expr [9617,9639]
===
match
---
atom_expr [10969,11006]
atom_expr [10672,10709]
===
match
---
trailer [30613,30623]
trailer [30316,30326]
===
match
---
simple_stmt [3052,3098]
simple_stmt [2993,3039]
===
match
---
name: filter [12729,12735]
name: filter [12432,12438]
===
match
---
simple_stmt [24547,24554]
simple_stmt [24250,24257]
===
match
---
arglist [16484,16543]
arglist [16187,16246]
===
match
---
trailer [13009,13013]
trailer [12712,12716]
===
match
---
name: TI [12088,12090]
name: TI [11791,11793]
===
match
---
fstring_end: ' [25121,25122]
fstring_end: ' [24824,24825]
===
match
---
operator: = [16868,16869]
operator: = [16571,16572]
===
match
---
name: session [11349,11356]
name: session [11052,11059]
===
match
---
operator: = [11987,11988]
operator: = [11690,11691]
===
match
---
atom [13323,13433]
atom [13026,13136]
===
match
---
atom_expr [10555,10606]
atom_expr [10258,10309]
===
match
---
name: dag [24125,24128]
name: dag [23828,23831]
===
match
---
name: self [12783,12787]
name: self [12486,12490]
===
match
---
operator: = [2977,2978]
operator: = [2918,2919]
===
match
---
operator: -> [29207,29209]
operator: -> [28910,28912]
===
match
---
simple_stmt [27138,27154]
simple_stmt [26841,26857]
===
match
---
name: utcnow [15031,15037]
name: utcnow [14734,14740]
===
match
---
atom [23541,23585]
atom [23244,23288]
===
match
---
name: end_date [5531,5539]
name: end_date [5472,5480]
===
match
---
name: AirflowException [13033,13049]
name: AirflowException [12736,12752]
===
match
---
name: unfinished_tasks [15917,15933]
name: unfinished_tasks [15620,15636]
===
match
---
operator: , [17278,17279]
operator: , [16981,16982]
===
match
---
name: State [1997,2002]
name: State [1938,1943]
===
match
---
name: reason [16505,16511]
name: reason [16208,16214]
===
match
---
name: full_filepath [16676,16689]
name: full_filepath [16379,16392]
===
match
---
name: state [11296,11301]
name: state [10999,11004]
===
match
---
name: airflow [1599,1606]
name: airflow [1540,1547]
===
match
---
expr_stmt [18983,19080]
expr_stmt [18686,18783]
===
match
---
operator: += [30792,30794]
operator: += [30495,30497]
===
match
---
operator: { [24262,24263]
operator: { [23965,23966]
===
match
---
name: DagModel [7383,7391]
name: DagModel [7086,7094]
===
match
---
suite [23257,24317]
suite [22960,24020]
===
match
---
atom_expr [23571,23584]
atom_expr [23274,23287]
===
match
---
atom_expr [19089,19161]
atom_expr [18792,18864]
===
match
---
name: dag [16562,16565]
name: dag [16265,16268]
===
match
---
operator: -> [13706,13708]
operator: -> [13409,13411]
===
match
---
name: finished_tasks [19988,20002]
name: finished_tasks [19691,19705]
===
match
---
name: msg [18403,18406]
name: msg [18106,18109]
===
match
---
name: airflow_conf [1383,1395]
name: airflow_conf [1324,1336]
===
match
---
param [4168,4206]
param [4109,4147]
===
match
---
name: none_task_concurrency [15739,15760]
name: none_task_concurrency [15442,15463]
===
match
---
name: state [10657,10662]
name: state [10360,10365]
===
match
---
atom_expr [30943,30962]
atom_expr [30646,30665]
===
match
---
decorated [12326,12858]
decorated [12029,12561]
===
match
---
name: unfinished_tasks [15560,15576]
name: unfinished_tasks [15263,15279]
===
match
---
suite [27233,27598]
suite [26936,27301]
===
match
---
name: s [11990,11991]
name: s [11693,11694]
===
match
---
parameters [12874,12880]
parameters [12577,12583]
===
match
---
operator: , [29180,29181]
operator: , [28883,28884]
===
match
---
name: state [17031,17036]
name: state [16734,16739]
===
match
---
expr_stmt [4763,4832]
expr_stmt [4704,4773]
===
match
---
name: types [2041,2046]
name: types [1982,1987]
===
match
---
atom_expr [15318,15338]
atom_expr [15021,15041]
===
match
---
suite [10883,10953]
suite [10586,10656]
===
match
---
name: dag_id [24997,25003]
name: dag_id [24700,24706]
===
match
---
suite [20422,21297]
suite [20125,21000]
===
match
---
comparison [11792,11805]
comparison [11495,11508]
===
match
---
atom_expr [17930,17942]
atom_expr [17633,17645]
===
match
---
operator: = [7692,7693]
operator: = [7395,7396]
===
match
---
operator: , [5439,5440]
operator: , [5380,5381]
===
match
---
trailer [26263,26308]
trailer [25966,26011]
===
match
---
if_stmt [17202,17669]
if_stmt [16905,17372]
===
match
---
parameters [28455,28461]
parameters [28158,28164]
===
match
---
name: DepContext [21720,21730]
name: DepContext [21423,21433]
===
match
---
not_test [23207,23223]
not_test [22910,22926]
===
match
---
name: run_type [10837,10845]
name: run_type [10540,10548]
===
match
---
name: in_ [30530,30533]
name: in_ [30233,30236]
===
match
---
simple_stmt [20022,20254]
simple_stmt [19725,19957]
===
match
---
name: external_trigger [10746,10762]
name: external_trigger [10449,10465]
===
match
---
operator: == [26421,26423]
operator: == [26124,26126]
===
match
---
param [6519,6530]
param [6222,6233]
===
match
---
operator: , [8337,8338]
operator: , [8040,8041]
===
match
---
funcdef [5368,5416]
funcdef [5309,5357]
===
match
---
trailer [23345,23349]
trailer [23048,23052]
===
match
---
atom_expr [27053,27072]
atom_expr [26756,26775]
===
match
---
string: 'execution_date' [3405,3421]
string: 'execution_date' [3346,3362]
===
match
---
simple_stmt [29864,29882]
simple_stmt [29567,29585]
===
match
---
arglist [24619,24682]
arglist [24322,24385]
===
match
---
name: full_filepath [17446,17459]
name: full_filepath [17149,17162]
===
match
---
name: callback [18776,18784]
name: callback [18479,18487]
===
match
---
name: execution_date [29042,29056]
name: execution_date [28745,28759]
===
match
---
simple_stmt [2289,2307]
simple_stmt [2230,2248]
===
match
---
suite [18128,18449]
suite [17831,18152]
===
match
---
fstring [11188,11231]
fstring [10891,10934]
===
match
---
name: REMOVED [19480,19487]
name: REMOVED [19183,19190]
===
match
---
trailer [3624,3631]
trailer [3565,3572]
===
match
---
trailer [4931,4940]
trailer [4872,4881]
===
match
---
suite [13014,13096]
suite [12717,12799]
===
match
---
expr_stmt [15273,15287]
expr_stmt [14976,14990]
===
match
---
argument [23659,23672]
argument [23362,23375]
===
match
---
suite [21651,22028]
suite [21354,21731]
===
match
---
name: models [1471,1477]
name: models [1412,1418]
===
match
---
name: state [20681,20686]
name: state [20384,20389]
===
match
---
argument [3929,3940]
argument [3870,3881]
===
match
---
trailer [4188,4198]
trailer [4129,4139]
===
match
---
name: in_ [9924,9927]
name: in_ [9627,9630]
===
match
---
decorated [27603,28421]
decorated [27306,28124]
===
match
---
operator: } [26299,26300]
operator: } [26002,26003]
===
match
---
name: task [26917,26921]
name: task [26620,26624]
===
match
---
funcdef [18811,20254]
funcdef [18514,19957]
===
match
---
operator: = [31344,31345]
operator: = [31047,31048]
===
match
---
trailer [19479,19487]
trailer [19182,19190]
===
match
---
tfpdef [20339,20363]
tfpdef [20042,20066]
===
match
---
import_as_names [1911,1964]
import_as_names [1852,1905]
===
match
---
operator: , [3359,3360]
operator: , [3300,3301]
===
match
---
name: List [20466,20470]
name: List [20169,20173]
===
match
---
trailer [28975,29057]
trailer [28678,28760]
===
match
---
parameters [5381,5387]
parameters [5322,5328]
===
match
---
name: state [13445,13450]
name: state [13148,13153]
===
match
---
name: dag_id [13886,13892]
name: dag_id [13589,13595]
===
match
---
name: provide_session [11238,11253]
name: provide_session [10941,10956]
===
match
---
trailer [10558,10565]
trailer [10261,10268]
===
match
---
operator: , [30497,30498]
operator: , [30200,30201]
===
match
---
operator: = [5506,5507]
operator: = [5447,5448]
===
match
---
trailer [30176,30184]
trailer [29879,29887]
===
match
---
trailer [18550,18560]
trailer [18253,18263]
===
match
---
arglist [5786,5816]
arglist [5727,5757]
===
match
---
name: DagCallbackRequest [18174,18192]
name: DagCallbackRequest [17877,17895]
===
match
---
operator: = [2869,2870]
operator: = [2810,2811]
===
match
---
name: provide_session [29108,29123]
name: provide_session [28811,28826]
===
match
---
operator: , [870,871]
operator: , [870,871]
===
match
---
name: keys [21066,21070]
name: keys [20769,20773]
===
match
---
name: Optional [12417,12425]
name: Optional [12120,12128]
===
match
---
funcdef [24444,25134]
funcdef [24147,24837]
===
match
---
name: qry [10643,10646]
name: qry [10346,10349]
===
match
---
simple_stmt [7122,7166]
simple_stmt [6825,6869]
===
match
---
trailer [10984,10999]
trailer [10687,10702]
===
match
---
atom_expr [5248,5267]
atom_expr [5189,5208]
===
match
---
expr_stmt [10444,10503]
expr_stmt [10147,10206]
===
match
---
trailer [30413,30420]
trailer [30116,30123]
===
match
---
name: in_ [30995,30998]
name: in_ [30698,30701]
===
match
---
name: TI [30362,30364]
name: TI [30065,30067]
===
match
---
trailer [9839,9852]
trailer [9542,9555]
===
match
---
trailer [5334,5351]
trailer [5275,5292]
===
match
---
name: REMOVED [26430,26437]
name: REMOVED [26133,26140]
===
match
---
trailer [12170,12176]
trailer [11873,11879]
===
match
---
comparison [25030,25056]
comparison [24733,24759]
===
match
---
atom_expr [23154,23175]
atom_expr [22857,22878]
===
match
---
operator: , [11347,11348]
operator: , [11050,11051]
===
match
---
simple_stmt [12439,12669]
simple_stmt [12142,12372]
===
match
---
name: TI [11495,11497]
name: TI [11198,11200]
===
match
---
name: conf [4672,4676]
name: conf [4613,4617]
===
match
---
name: task_ids [12285,12293]
name: task_ids [11988,11996]
===
match
---
name: ti [30095,30097]
name: ti [29798,29800]
===
match
---
atom_expr [10566,10583]
atom_expr [10269,10286]
===
match
---
name: DagCallbackRequest [16636,16654]
name: DagCallbackRequest [16339,16357]
===
match
---
name: s [12010,12011]
name: s [11713,11714]
===
match
---
name: TI [12762,12764]
name: TI [12465,12467]
===
match
---
trailer [30389,30572]
trailer [30092,30275]
===
match
---
trailer [2362,2366]
trailer [2303,2307]
===
match
---
name: t [15618,15619]
name: t [15321,15322]
===
match
---
arglist [7655,7700]
arglist [7358,7403]
===
match
---
argument [7952,7958]
argument [7655,7661]
===
match
---
suite [17360,17669]
suite [17063,17372]
===
match
---
trailer [14286,14305]
trailer [13989,14008]
===
match
---
name: execution_date [4551,4565]
name: execution_date [4492,4506]
===
match
---
name: settings [1332,1340]
name: settings [1273,1281]
===
match
---
name: self [12749,12753]
name: self [12452,12456]
===
match
---
testlist [20563,20585]
testlist [20266,20288]
===
match
---
simple_stmt [2724,2786]
simple_stmt [2665,2727]
===
match
---
decorator [11237,11254]
decorator [10940,10957]
===
match
---
expr_stmt [20666,20686]
expr_stmt [20369,20389]
===
match
---
operator: = [29909,29910]
operator: = [29612,29613]
===
match
---
name: log [1786,1789]
name: log [1727,1730]
===
match
---
trailer [28731,28738]
trailer [28434,28441]
===
match
---
operator: , [20823,20824]
operator: , [20526,20527]
===
match
---
operator: , [1935,1936]
operator: , [1876,1877]
===
match
---
if_stmt [20517,20586]
if_stmt [20220,20289]
===
match
---
simple_stmt [12151,12189]
simple_stmt [11854,11892]
===
match
---
trailer [14972,14991]
trailer [14675,14694]
===
match
---
import_from [1713,1766]
import_from [1654,1707]
===
match
---
atom_expr [19948,20012]
atom_expr [19651,19715]
===
match
---
trailer [26151,26159]
trailer [25854,25862]
===
match
---
name: session [17306,17313]
name: session [17009,17016]
===
match
---
name: task [30046,30050]
name: task [29749,29753]
===
match
---
atom_expr [30608,30623]
atom_expr [30311,30326]
===
match
---
trailer [14066,14081]
trailer [13769,13784]
===
match
---
operator: , [7391,7392]
operator: , [7094,7095]
===
match
---
trailer [30050,30070]
trailer [29753,29773]
===
match
---
name: run_id [5293,5299]
name: run_id [5234,5240]
===
match
---
name: DagRunType [10928,10938]
name: DagRunType [10631,10641]
===
match
---
name: leaf_tis [16078,16086]
name: leaf_tis [15781,15789]
===
match
---
comparison [28486,28526]
comparison [28189,28229]
===
match
---
trailer [24245,24252]
trailer [23948,23955]
===
match
---
name: State [25044,25049]
name: State [24747,24752]
===
match
---
atom_expr [12054,12107]
atom_expr [11757,11810]
===
match
---
name: start_date [23574,23584]
name: start_date [23277,23287]
===
match
---
testlist_comp [19622,19665]
testlist_comp [19325,19368]
===
match
---
atom_expr [19880,19903]
atom_expr [19583,19606]
===
match
---
name: task_id [16113,16120]
name: task_id [15816,15823]
===
match
---
operator: -> [28609,28611]
operator: -> [28312,28314]
===
match
---
simple_stmt [16607,16903]
simple_stmt [16310,16606]
===
match
---
if_stmt [21664,22028]
if_stmt [21367,21731]
===
match
---
operator: = [10900,10901]
operator: = [10603,10604]
===
match
---
suite [10298,10397]
suite [10001,10100]
===
match
---
simple_stmt [24952,25017]
simple_stmt [24655,24720]
===
match
---
trailer [17103,17107]
trailer [16806,16810]
===
match
---
trailer [28190,28198]
trailer [27893,27901]
===
match
---
expr_stmt [9775,9798]
expr_stmt [9478,9501]
===
match
---
name: query [28722,28727]
name: query [28425,28430]
===
match
---
simple_stmt [27180,27196]
simple_stmt [26883,26899]
===
match
---
operator: { [30597,30598]
operator: { [30300,30301]
===
match
---
testlist_comp [3331,3542]
testlist_comp [3272,3483]
===
match
---
parameters [13170,13230]
parameters [12873,12933]
===
match
---
simple_stmt [1562,1594]
simple_stmt [1503,1535]
===
match
---
expr_stmt [7122,7165]
expr_stmt [6825,6868]
===
match
---
trailer [15115,15157]
trailer [14818,14860]
===
match
---
trailer [30102,30122]
trailer [29805,29825]
===
match
---
operator: } [25003,25004]
operator: } [24706,24707]
===
match
---
name: List [18932,18936]
name: List [18635,18639]
===
match
---
operator: = [8120,8121]
operator: = [7823,7824]
===
match
---
argument [3705,3742]
argument [3646,3683]
===
match
---
name: queued_at [2688,2697]
name: queued_at [2629,2638]
===
match
---
atom_expr [21229,21235]
atom_expr [20932,20938]
===
match
---
atom_expr [27180,27195]
atom_expr [26883,26898]
===
match
---
name: tis [20063,20066]
name: tis [19766,19769]
===
match
---
name: cls [6506,6509]
name: cls [6209,6212]
===
match
---
expr_stmt [28689,28861]
expr_stmt [28392,28564]
===
match
---
trailer [21065,21070]
trailer [20768,20773]
===
match
---
name: State [26340,26345]
name: State [26043,26048]
===
match
---
atom_expr [31210,31221]
atom_expr [30913,30924]
===
match
---
suite [11384,12321]
suite [11087,12024]
===
match
---
atom_expr [3070,3080]
atom_expr [3011,3021]
===
match
---
trailer [11833,11859]
trailer [11536,11562]
===
match
---
arglist [21708,21984]
arglist [21411,21687]
===
match
---
return_stmt [22016,22027]
return_stmt [21719,21730]
===
match
---
name: relationship [3571,3583]
name: relationship [3512,3524]
===
match
---
name: cls [28905,28908]
name: cls [28608,28611]
===
match
---
name: is_active [7558,7567]
name: is_active [7261,7270]
===
match
---
name: t [16039,16040]
name: t [15742,15743]
===
match
---
name: log [19094,19097]
name: log [18797,18800]
===
match
---
string: 'all_tasks_deadlocked' [18407,18429]
string: 'all_tasks_deadlocked' [18110,18132]
===
match
---
operator: , [16488,16489]
operator: , [16191,16192]
===
match
---
name: self [24148,24152]
name: self [23851,23855]
===
match
---
operator: = [30645,30646]
operator: = [30348,30349]
===
match
---
name: ti_deps [1658,1665]
name: ti_deps [1599,1606]
===
match
---
trailer [27586,27595]
trailer [27289,27298]
===
match
---
trailer [7913,8017]
trailer [7616,7720]
===
match
---
if_stmt [26809,26901]
if_stmt [26512,26604]
===
match
---
operator: @ [11012,11013]
operator: @ [10715,10716]
===
match
---
name: TYPE_CHECKING [2069,2082]
name: TYPE_CHECKING [2010,2023]
===
match
---
name: TI [31266,31268]
name: TI [30969,30971]
===
match
---
operator: = [15175,15176]
operator: = [14878,14879]
===
match
---
name: DR [10461,10463]
name: DR [10164,10166]
===
match
---
trailer [10059,10081]
trailer [9762,9784]
===
match
---
if_stmt [17956,18449]
if_stmt [17659,18152]
===
match
---
simple_stmt [13313,13434]
simple_stmt [13016,13137]
===
match
---
name: self [24868,24872]
name: self [24571,24575]
===
match
---
trailer [11497,11504]
trailer [11200,11207]
===
match
---
trailer [31154,31165]
trailer [30857,30868]
===
match
---
import_from [1874,1964]
import_from [1815,1905]
===
match
---
expr_stmt [2311,2337]
expr_stmt [2252,2278]
===
match
---
argument [17280,17296]
argument [16983,16999]
===
insert-tree
---
simple_stmt [908,1018]
    import_from [908,1017]
        name: sqlalchemy [913,923]
        import_as_names [931,1017]
            name: Boolean [931,938]
            operator: , [938,939]
            name: Column [940,946]
            operator: , [946,947]
            name: Index [948,953]
            operator: , [953,954]
            name: Integer [955,962]
            operator: , [962,963]
            name: PickleType [964,974]
            operator: , [974,975]
            name: String [976,982]
            operator: , [982,983]
            name: UniqueConstraint [984,1000]
            operator: , [1000,1001]
            name: and_ [1002,1006]
            operator: , [1006,1007]
            name: func [1008,1012]
            operator: , [1012,1013]
            name: or_ [1014,1017]
to
file_input [787,31406]
at 2
===
insert-node
---
name: DagRun [2316,2322]
to
classdef [2369,31406]
at 0
===
insert-tree
---
arglist [2323,2341]
    name: Base [2323,2327]
    operator: , [2327,2328]
    name: LoggingMixin [2329,2341]
to
classdef [2369,31406]
at 1
===
insert-tree
---
simple_stmt [2348,2487]
    string: """     DagRun describes an instance of a Dag. It can be created     by the scheduler (for regular runs) or by an external trigger     """ [2348,2486]
to
suite [2402,31406]
at 0
===
insert-node
---
decorated [5765,6150]
to
suite [2402,31406]
at 27
===
insert-node
---
funcdef [5786,6150]
to
decorated [5765,6150]
at 1
===
move-tree
---
parameters [5864,5895]
    param [5865,5870]
        name: self [5865,5869]
        operator: , [5869,5870]
    param [5871,5894]
        tfpdef [5871,5887]
            name: session [5871,5878]
            name: Session [5880,5887]
        operator: = [5888,5889]
to
funcdef [5786,6150]
at 1
===
insert-node
---
suite [5837,6150]
to
funcdef [5786,6150]
at 2
===
insert-node
---
simple_stmt [5996,6096]
to
suite [5837,6150]
at 1
===
move-tree
---
simple_stmt [6401,6417]
    expr_stmt [6401,6416]
        atom_expr [6401,6408]
            name: self [6401,6405]
            trailer [6405,6408]
                name: id [6406,6408]
        operator: = [6409,6410]
        atom_expr [6411,6416]
            name: dr [6411,6413]
            trailer [6413,6416]
                name: id [6414,6416]
to
suite [5837,6150]
at 2
===
move-tree
---
simple_stmt [6425,6447]
    expr_stmt [6425,6446]
        atom_expr [6425,6435]
            name: self [6425,6429]
            trailer [6429,6435]
                name: state [6430,6435]
        operator: = [6436,6437]
        atom_expr [6438,6446]
            name: dr [6438,6440]
            trailer [6440,6446]
                name: state [6441,6446]
to
suite [5837,6150]
at 3
===
insert-node
---
expr_stmt [5996,6095]
to
simple_stmt [5996,6096]
at 0
===
insert-node
---
atom_expr [6001,6095]
to
expr_stmt [5996,6095]
at 2
===
insert-node
---
trailer [6029,6089]
to
atom_expr [6001,6095]
at 4
===
insert-node
---
arglist [6030,6088]
to
trailer [6029,6089]
at 0
===
insert-node
---
comparison [6030,6058]
to
arglist [6030,6088]
at 0
===
insert-node
---
comparison [6060,6088]
to
arglist [6030,6088]
at 2
===
move-tree
---
atom_expr [6225,6236]
    name: self [6225,6229]
    trailer [6229,6236]
        name: dag_id [6230,6236]
to
comparison [6030,6058]
at 2
===
move-tree
---
atom_expr [6336,6347]
    name: self [6336,6340]
    trailer [6340,6347]
        name: run_id [6341,6347]
to
comparison [6060,6088]
at 2
===
delete-tree
---
simple_stmt [908,1077]
    import_from [908,1076]
        name: sqlalchemy [913,923]
        import_as_names [937,1074]
            name: Boolean [937,944]
            operator: , [944,945]
            name: Column [950,956]
            operator: , [956,957]
            name: DateTime [962,970]
            operator: , [970,971]
            name: Index [976,981]
            operator: , [981,982]
            name: Integer [987,994]
            operator: , [994,995]
            name: PickleType [1000,1010]
            operator: , [1010,1011]
            name: String [1016,1022]
            operator: , [1022,1023]
            name: UniqueConstraint [1028,1044]
            operator: , [1044,1045]
            name: and_ [1050,1054]
            operator: , [1054,1055]
            name: func [1060,1064]
            operator: , [1064,1065]
            name: or_ [1070,1073]
            operator: , [1073,1074]
===
delete-node
---
name: DagRun [2375,2381]
===
===
delete-tree
---
arglist [2382,2400]
    name: Base [2382,2386]
    operator: , [2386,2387]
    name: LoggingMixin [2388,2400]
===
delete-tree
---
simple_stmt [2407,2546]
    string: """     DagRun describes an instance of a Dag. It can be created     by the scheduler (for regular runs) or by an external trigger     """ [2407,2545]
===
delete-node
---
comparison [6212,6236]
===
===
delete-node
---
comparison [6323,6347]
===
===
delete-node
---
arglist [6212,6348]
===
===
delete-node
---
trailer [6194,6362]
===
===
delete-node
---
atom_expr [6157,6381]
===
===
delete-node
---
atom [6143,6391]
===
===
delete-node
---
expr_stmt [6138,6391]
===
===
delete-node
---
simple_stmt [6138,6392]
===
===
delete-node
---
suite [5896,6447]
===
===
delete-node
---
funcdef [5845,6447]
===
===
delete-node
---
decorated [5824,6447]
===
