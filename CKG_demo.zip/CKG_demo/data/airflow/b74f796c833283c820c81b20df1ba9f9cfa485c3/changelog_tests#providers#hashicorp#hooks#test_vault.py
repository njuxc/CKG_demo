===
match
---
argument [19833,19841]
argument [19851,19859]
===
match
---
atom_expr [5425,5454]
atom_expr [5425,5454]
===
match
---
simple_stmt [11846,11890]
simple_stmt [11864,11908]
===
match
---
operator: } [20924,20925]
operator: } [20942,20943]
===
match
---
name: password [36115,36123]
name: password [36133,36141]
===
match
---
simple_stmt [17597,17649]
simple_stmt [17615,17667]
===
match
---
trailer [15148,15166]
trailer [15166,15184]
===
match
---
atom_expr [41476,41495]
atom_expr [41494,41513]
===
match
---
operator: = [48750,48751]
operator: = [48768,48769]
===
match
---
simple_stmt [27558,27611]
simple_stmt [27576,27629]
===
match
---
operator: = [7260,7261]
operator: = [7260,7261]
===
match
---
atom_expr [24303,24335]
atom_expr [24321,24353]
===
match
---
operator: = [47014,47015]
operator: = [47032,47033]
===
match
---
name: mock_hvac [8366,8375]
name: mock_hvac [8372,8381]
===
match
---
simple_stmt [28317,28373]
simple_stmt [28335,28391]
===
match
---
string: "airflow.providers.google.cloud.utils.credentials_provider.get_credentials_and_project_id" [18783,18873]
string: "airflow.providers.google.cloud.utils.credentials_provider.get_credentials_and_project_id" [18801,18891]
===
match
---
name: connection_dict [5590,5605]
name: connection_dict [5590,5605]
===
match
---
name: schema [1750,1756]
name: schema [1750,1756]
===
match
---
name: mock_client [2930,2941]
name: mock_client [2930,2941]
===
match
---
operator: ** [45489,45491]
operator: ** [45507,45509]
===
match
---
string: 'value' [49358,49365]
string: 'value' [49376,49383]
===
match
---
string: 'lease_duration' [44842,44858]
string: 'lease_duration' [44860,44876]
===
match
---
name: VaultHook [21133,21142]
name: VaultHook [21151,21160]
===
match
---
name: role [26380,26384]
name: role [26398,26402]
===
match
---
name: get [20998,21001]
name: get [21016,21019]
===
match
---
operator: , [18318,18319]
operator: , [18336,18337]
===
match
---
name: mock_file [26215,26224]
name: mock_file [26233,26242]
===
match
---
trailer [20719,20729]
trailer [20737,20747]
===
match
---
name: mock [48475,48479]
name: mock [48493,48497]
===
match
---
operator: , [6198,6199]
operator: , [6198,6199]
===
match
---
simple_stmt [17887,17954]
simple_stmt [17905,17972]
===
match
---
trailer [1308,1318]
trailer [1308,1318]
===
match
---
operator: , [2898,2899]
operator: , [2898,2899]
===
match
---
simple_stmt [2032,2063]
simple_stmt [2032,2063]
===
match
---
name: get [43116,43119]
name: get [43134,43137]
===
match
---
operator: , [43440,43441]
operator: , [43458,43459]
===
match
---
expr_stmt [12011,12072]
expr_stmt [12029,12090]
===
match
---
name: MagicMock [4549,4558]
name: MagicMock [4549,4558]
===
match
---
simple_stmt [37794,37815]
simple_stmt [37812,37833]
===
match
---
atom [41116,41419]
atom [41134,41437]
===
match
---
argument [46319,46331]
argument [46337,46349]
===
match
---
trailer [30808,30813]
trailer [30826,30831]
===
match
---
name: return_value [46669,46681]
name: return_value [46687,46699]
===
match
---
name: return_value [8571,8583]
name: return_value [8577,8589]
===
match
---
operator: { [37885,37886]
operator: { [37903,37904]
===
match
---
string: "azure_resource" [13296,13312]
string: "azure_resource" [13314,13330]
===
match
---
decorator [1126,1140]
decorator [1126,1140]
===
match
---
name: mock [16926,16930]
name: mock [16944,16948]
===
match
---
atom_expr [23342,23369]
atom_expr [23360,23387]
===
match
---
simple_stmt [20935,21002]
simple_stmt [20953,21020]
===
match
---
name: kwargs [49096,49102]
name: kwargs [49114,49120]
===
match
---
trailer [34535,34548]
trailer [34553,34566]
===
match
---
decorator [40587,40667]
decorator [40605,40685]
===
match
---
trailer [44062,44086]
trailer [44080,44104]
===
match
---
atom_expr [37608,37634]
atom_expr [37626,37652]
===
match
---
name: return_value [19440,19452]
name: return_value [19458,19470]
===
match
---
trailer [48926,48930]
trailer [48944,48948]
===
match
---
name: patch [22606,22611]
name: patch [22624,22629]
===
match
---
operator: = [41114,41115]
operator: = [41132,41133]
===
match
---
operator: , [30439,30440]
operator: , [30457,30458]
===
match
---
name: vault_client [20424,20436]
name: vault_client [20442,20454]
===
match
---
name: mock_get_connection [32410,32429]
name: mock_get_connection [32428,32447]
===
match
---
trailer [12858,12868]
trailer [12876,12886]
===
match
---
name: mock_hvac [31211,31220]
name: mock_hvac [31229,31238]
===
match
---
trailer [37088,37107]
trailer [37106,37125]
===
match
---
argument [10198,10225]
argument [10210,10237]
===
match
---
param [32393,32398]
param [32411,32416]
===
match
---
trailer [31997,32007]
trailer [32015,32025]
===
match
---
operator: = [16549,16550]
operator: = [16567,16568]
===
match
---
operator: , [15036,15037]
operator: , [15054,15055]
===
match
---
assert_stmt [4213,4266]
assert_stmt [4213,4266]
===
match
---
expr_stmt [7500,7566]
expr_stmt [7500,7566]
===
match
---
number: 2 [9266,9267]
number: 2 [9278,9279]
===
match
---
string: "vault_conn_id" [19933,19948]
string: "vault_conn_id" [19951,19966]
===
match
---
trailer [28513,28518]
trailer [28531,28536]
===
match
---
operator: = [24266,24267]
operator: = [24284,24285]
===
match
---
suite [5377,5984]
suite [5377,5984]
===
match
---
expr_stmt [28982,29025]
expr_stmt [29000,29043]
===
match
---
simple_stmt [6374,6425]
simple_stmt [6374,6425]
===
match
---
simple_stmt [28381,28416]
simple_stmt [28399,28434]
===
match
---
trailer [46243,46267]
trailer [46261,46285]
===
match
---
name: assert_called_with [27251,27269]
name: assert_called_with [27269,27287]
===
match
---
simple_stmt [24489,24556]
simple_stmt [24507,24574]
===
match
---
name: cas [47285,47288]
name: cas [47303,47306]
===
match
---
name: parameterized [48282,48295]
name: parameterized [48300,48313]
===
match
---
trailer [33403,33423]
trailer [33421,33441]
===
match
---
name: mock [26787,26791]
name: mock [26805,26809]
===
match
---
name: access_key [12510,12520]
name: access_key [12528,12538]
===
match
---
trailer [2060,2062]
trailer [2060,2062]
===
match
---
operator: = [21833,21834]
operator: = [21851,21852]
===
match
---
string: "gcp_key_path" [16190,16204]
string: "gcp_key_path" [16208,16222]
===
match
---
trailer [35142,35155]
trailer [35160,35173]
===
match
---
trailer [8141,8159]
trailer [8147,8165]
===
match
---
trailer [38708,38719]
trailer [38726,38737]
===
match
---
name: mock_get_connection [11951,11970]
name: mock_get_connection [11969,11988]
===
match
---
atom_expr [46747,46776]
atom_expr [46765,46794]
===
match
---
operator: = [37810,37811]
operator: = [37828,37829]
===
match
---
string: "kubernetes_role" [24395,24412]
string: "kubernetes_role" [24413,24430]
===
match
---
operator: , [2860,2861]
operator: , [2860,2861]
===
match
---
name: get_mock_connection [22960,22979]
name: get_mock_connection [22978,22997]
===
match
---
name: port [29705,29709]
name: port [29723,29727]
===
match
---
name: mock_connection [1551,1566]
name: mock_connection [1551,1566]
===
match
---
trailer [37632,37634]
trailer [37650,37652]
===
match
---
atom [14341,14472]
atom [14359,14490]
===
match
---
name: mock_connection [8641,8656]
name: mock_connection [8647,8662]
===
match
---
operator: , [42798,42799]
operator: , [42816,42817]
===
match
---
operator: = [34479,34480]
operator: = [34497,34498]
===
match
---
simple_stmt [22990,23041]
simple_stmt [23008,23059]
===
match
---
name: self [15560,15564]
name: self [15578,15582]
===
match
---
param [44366,44376]
param [44384,44394]
===
match
---
string: "token" [40224,40231]
string: "token" [40242,40249]
===
match
---
simple_stmt [21470,21523]
simple_stmt [21488,21541]
===
match
---
string: '' [43655,43657]
string: '' [43673,43675]
===
match
---
atom_expr [19300,19332]
atom_expr [19318,19350]
===
match
---
atom_expr [25615,25647]
atom_expr [25633,25665]
===
match
---
atom [8725,8885]
atom [8731,8891]
===
match
---
atom_expr [20163,20227]
atom_expr [20181,20245]
===
match
---
operator: , [6922,6923]
operator: , [6922,6923]
===
match
---
argument [11106,11114]
argument [11124,11132]
===
match
---
atom_expr [8641,8685]
atom_expr [8647,8691]
===
match
---
name: mock_get_connection [25441,25460]
name: mock_get_connection [25459,25478]
===
match
---
expr_stmt [30230,30280]
expr_stmt [30248,30298]
===
match
---
string: 'auth' [40059,40065]
string: 'auth' [40077,40083]
===
match
---
argument [29423,29431]
argument [29441,29449]
===
match
---
funcdef [7159,8160]
funcdef [7159,8166]
===
match
---
operator: = [42114,42115]
operator: = [42132,42133]
===
match
---
operator: = [43135,43136]
operator: = [43153,43154]
===
match
---
atom_expr [18385,18449]
atom_expr [18403,18467]
===
match
---
parameters [32392,32430]
parameters [32410,32448]
===
match
---
simple_stmt [44519,44550]
simple_stmt [44537,44568]
===
match
---
atom_expr [39440,39498]
atom_expr [39458,39516]
===
match
---
suite [11798,12595]
suite [11816,12613]
===
match
---
name: extra_dejson [30336,30348]
name: extra_dejson [30354,30366]
===
match
---
name: side_effect [40125,40136]
name: side_effect [40143,40154]
===
match
---
trailer [46618,46638]
trailer [46636,46656]
===
match
---
trailer [32468,32470]
trailer [32486,32488]
===
match
---
name: url [24993,24996]
name: url [25011,25014]
===
match
---
argument [5845,5853]
argument [5845,5853]
===
match
---
atom_expr [29052,29078]
atom_expr [29070,29096]
===
match
---
operator: = [36856,36857]
operator: = [36874,36875]
===
match
---
operator: , [5343,5344]
operator: , [5343,5344]
===
match
---
param [28902,28912]
param [28920,28930]
===
match
---
trailer [37324,37342]
trailer [37342,37360]
===
match
---
operator: , [7630,7631]
operator: , [7630,7631]
===
match
---
comparison [32142,32187]
comparison [32160,32205]
===
match
---
operator: = [33302,33303]
operator: = [33320,33321]
===
match
---
string: "auth_type" [43172,43183]
string: "auth_type" [43190,43201]
===
match
---
argument [1519,1536]
argument [1519,1536]
===
match
---
operator: = [29012,29013]
operator: = [29030,29031]
===
match
---
name: connection_dict [25675,25690]
name: connection_dict [25693,25708]
===
match
---
name: mock_get_connection [31794,31813]
name: mock_get_connection [31812,31831]
===
match
---
name: mock_hvac [36533,36542]
name: mock_hvac [36551,36560]
===
match
---
name: mock_get_connection [4500,4519]
name: mock_get_connection [4500,4519]
===
match
---
name: test_hook [3367,3376]
name: test_hook [3367,3376]
===
match
---
name: vault_client [13848,13860]
name: vault_client [13866,13878]
===
match
---
name: test_client [9201,9212]
name: test_client [9213,9224]
===
match
---
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [29852,29918]
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [29870,29936]
===
match
---
arglist [46281,46331]
arglist [46299,46349]
===
match
---
decorator [34137,34217]
decorator [34155,34235]
===
match
---
string: 'created_time' [42619,42633]
string: 'created_time' [42637,42651]
===
match
---
string: 'http://localhost:8180' [12420,12443]
string: 'http://localhost:8180' [12438,12461]
===
match
---
parameters [31204,31242]
parameters [31222,31260]
===
match
---
string: "vault_conn_id" [47898,47913]
string: "vault_conn_id" [47916,47931]
===
match
---
operator: { [10901,10902]
operator: { [10919,10920]
===
match
---
operator: , [18546,18547]
operator: , [18564,18565]
===
match
---
dictorsetmaker [3315,3348]
dictorsetmaker [3315,3348]
===
match
---
name: assert_called_with [18266,18284]
name: assert_called_with [18284,18302]
===
match
---
arglist [36098,36130]
arglist [36116,36148]
===
match
---
operator: @ [16925,16926]
operator: @ [16943,16944]
===
match
---
name: mock_get_connection [48717,48736]
name: mock_get_connection [48735,48754]
===
match
---
name: kwargs [45491,45497]
name: kwargs [45509,45515]
===
match
---
trailer [47150,47153]
trailer [47168,47171]
===
match
---
name: return_value [7430,7442]
name: return_value [7430,7442]
===
match
---
trailer [28961,28971]
trailer [28979,28989]
===
match
---
name: assert_called_with [21371,21389]
name: assert_called_with [21389,21407]
===
match
---
argument [27458,27473]
argument [27476,27491]
===
match
---
trailer [26360,26379]
trailer [26378,26397]
===
match
---
atom_expr [4070,4089]
atom_expr [4070,4089]
===
match
---
operator: , [46079,46080]
operator: , [46097,46098]
===
match
---
name: patch [15178,15183]
name: patch [15196,15201]
===
match
---
name: mock_hvac [9513,9522]
name: mock_hvac [9525,9534]
===
match
---
trailer [29637,29644]
trailer [29655,29662]
===
match
---
operator: } [4012,4013]
operator: } [4012,4013]
===
match
---
parameters [6182,6220]
parameters [6182,6220]
===
match
---
expr_stmt [42098,42142]
expr_stmt [42116,42160]
===
match
---
name: host [29674,29678]
name: host [29692,29696]
===
match
---
name: mock_hvac [19076,19085]
name: mock_hvac [19094,19103]
===
match
---
dotted_name [6074,6084]
dotted_name [6074,6084]
===
match
---
simple_stmt [10235,10313]
simple_stmt [10247,10331]
===
match
---
name: test_custom_mount_point_dejson [3650,3680]
name: test_custom_mount_point_dejson [3650,3680]
===
match
---
operator: ** [36947,36949]
operator: ** [36965,36967]
===
match
---
operator: = [49197,49198]
operator: = [49215,49216]
===
match
---
string: 'secret_key' [45804,45816]
string: 'secret_key' [45822,45834]
===
match
---
parameters [46548,46586]
parameters [46566,46604]
===
match
---
simple_stmt [34576,34640]
simple_stmt [34594,34658]
===
match
---
simple_stmt [46708,46739]
simple_stmt [46726,46757]
===
match
---
simple_stmt [34411,34455]
simple_stmt [34429,34473]
===
match
---
string: 'http://localhost:8180' [29588,29611]
string: 'http://localhost:8180' [29606,29629]
===
match
---
name: patch [5139,5144]
name: patch [5139,5144]
===
match
---
operator: , [28911,28912]
operator: , [28929,28930]
===
match
---
suite [36485,37343]
suite [36503,37361]
===
match
---
funcdef [17288,18677]
funcdef [17306,18695]
===
match
---
name: get_conn [30705,30713]
name: get_conn [30723,30731]
===
match
---
name: mock [10522,10526]
name: mock [10540,10544]
===
match
---
name: mock_hvac [19195,19204]
name: mock_hvac [19213,19222]
===
match
---
simple_stmt [12337,12372]
simple_stmt [12355,12390]
===
match
---
atom_expr [5673,5717]
atom_expr [5673,5717]
===
match
---
trailer [24177,24187]
trailer [24195,24205]
===
match
---
name: mock_connection [42186,42201]
name: mock_connection [42204,42219]
===
match
---
name: mock_connection [2318,2333]
name: mock_connection [2318,2333]
===
match
---
name: mock [17408,17412]
name: mock [17426,17430]
===
match
---
trailer [22104,22108]
trailer [22122,22126]
===
match
---
operator: = [38558,38559]
operator: = [38576,38577]
===
match
---
operator: = [15878,15879]
operator: = [15896,15897]
===
match
---
operator: } [42321,42322]
operator: } [42339,42340]
===
match
---
simple_stmt [31678,31745]
simple_stmt [31696,31763]
===
match
---
operator: , [30510,30511]
operator: , [30528,30529]
===
match
---
string: 'deletion_time' [38241,38256]
string: 'deletion_time' [38259,38274]
===
match
---
operator: = [41049,41050]
operator: = [41067,41068]
===
match
---
trailer [19832,19842]
trailer [19850,19860]
===
match
---
trailer [12360,12369]
trailer [12378,12387]
===
match
---
name: assert_called_with [9059,9077]
name: assert_called_with [9065,9083]
===
match
---
dictorsetmaker [5771,5804]
dictorsetmaker [5771,5804]
===
match
---
name: get [2381,2384]
name: get [2381,2384]
===
match
---
decorator [18963,19041]
decorator [18981,19059]
===
match
---
operator: , [32697,32698]
operator: , [32715,32716]
===
match
---
operator: , [19639,19640]
operator: , [19657,19658]
===
match
---
expr_stmt [20701,20731]
expr_stmt [20719,20749]
===
match
---
param [36447,36452]
param [36465,36470]
===
match
---
param [26726,26731]
param [26744,26749]
===
match
---
trailer [1697,1714]
trailer [1697,1714]
===
match
---
operator: = [4892,4893]
operator: = [4892,4893]
===
match
---
name: get [27036,27039]
name: get [27054,27057]
===
match
---
simple_stmt [10988,11075]
simple_stmt [11006,11093]
===
match
---
string: "pass" [10305,10311]
string: "pass" [10323,10329]
===
match
---
trailer [16527,16619]
trailer [16545,16637]
===
match
---
atom_expr [22955,22981]
atom_expr [22973,22999]
===
match
---
name: VaultError [32962,32972]
name: VaultError [32980,32990]
===
match
---
operator: = [36935,36936]
operator: = [36953,36954]
===
match
---
name: kv_engine_version [29817,29834]
name: kv_engine_version [29835,29852]
===
match
---
atom_expr [26882,26908]
atom_expr [26900,26926]
===
match
---
name: get [22071,22074]
name: get [22089,22092]
===
match
---
operator: , [35379,35380]
operator: , [35397,35398]
===
match
---
name: VaultHook [8907,8916]
name: VaultHook [8913,8922]
===
match
---
operator: , [36904,36905]
operator: , [36922,36923]
===
match
---
trailer [3093,3106]
trailer [3093,3106]
===
match
---
name: test_hook [11524,11533]
name: test_hook [11542,11551]
===
match
---
name: host [32027,32031]
name: host [32045,32049]
===
match
---
name: vault_client [4242,4254]
name: vault_client [4242,4254]
===
match
---
simple_stmt [29252,29392]
simple_stmt [29270,29410]
===
match
---
name: mock_client [46708,46719]
name: mock_client [46726,46737]
===
match
---
name: configure [14876,14885]
name: configure [14894,14903]
===
match
---
string: "credentials" [18533,18546]
string: "credentials" [18551,18564]
===
match
---
name: return_value [2986,2998]
name: return_value [2986,2998]
===
match
---
name: test_create_or_update_secret_v1 [48560,48591]
name: test_create_or_update_secret_v1 [48578,48609]
===
match
---
argument [40336,40357]
argument [40354,40375]
===
match
---
trailer [22901,22914]
trailer [22919,22932]
===
match
---
expr_stmt [1408,1468]
expr_stmt [1408,1468]
===
match
---
operator: @ [31100,31101]
operator: @ [31118,31119]
===
match
---
trailer [29209,29221]
trailer [29227,29239]
===
match
---
operator: , [7191,7192]
operator: , [7191,7192]
===
match
---
decorator [47393,47471]
decorator [47411,47489]
===
match
---
operator: , [33639,33640]
operator: , [33657,33658]
===
match
---
name: mock_hvac [5425,5434]
name: mock_hvac [5425,5434]
===
match
---
dictorsetmaker [17764,17867]
dictorsetmaker [17782,17885]
===
match
---
name: mock_client [3001,3012]
name: mock_client [3001,3012]
===
match
---
argument [25095,25105]
argument [25113,25123]
===
match
---
string: "auth_type" [40211,40222]
string: "auth_type" [40229,40240]
===
match
---
operator: = [42318,42319]
operator: = [42336,42337]
===
match
---
atom_expr [24848,24903]
atom_expr [24866,24921]
===
match
---
dictorsetmaker [48983,49061]
dictorsetmaker [49001,49079]
===
match
---
name: kv [44661,44663]
name: kv [44679,44681]
===
match
---
name: mock_hvac [30125,30134]
name: mock_hvac [30143,30152]
===
match
---
trailer [41100,41113]
trailer [41118,41131]
===
match
---
operator: = [34592,34593]
operator: = [34610,34611]
===
match
---
expr_stmt [32867,32933]
expr_stmt [32885,32951]
===
match
---
param [35392,35411]
param [35410,35429]
===
match
---
comparison [37297,37342]
comparison [37315,37360]
===
match
---
simple_stmt [27850,27881]
simple_stmt [27868,27899]
===
match
---
name: assert_called_once_with [47181,47204]
name: assert_called_once_with [47199,47222]
===
match
---
name: mock [6074,6078]
name: mock [6074,6078]
===
match
---
expr_stmt [25615,25665]
expr_stmt [25633,25683]
===
match
---
trailer [31635,31647]
trailer [31653,31665]
===
match
---
atom_expr [35133,35173]
atom_expr [35151,35191]
===
match
---
name: test_hook [34097,34106]
name: test_hook [34115,34124]
===
match
---
atom [43768,43969]
atom [43786,43987]
===
match
---
string: "vault_conn_id" [46932,46947]
string: "vault_conn_id" [46950,46965]
===
match
---
simple_stmt [7858,7893]
simple_stmt [7858,7893]
===
match
---
atom_expr [46614,46640]
atom_expr [46632,46658]
===
match
---
operator: , [17866,17867]
operator: , [17884,17885]
===
match
---
atom_expr [23409,23428]
atom_expr [23427,23446]
===
match
---
operator: , [45930,45931]
operator: , [45948,45949]
===
match
---
trailer [35535,35555]
trailer [35553,35573]
===
match
---
name: TestCase [866,874]
name: TestCase [866,874]
===
match
---
operator: = [46777,46778]
operator: = [46795,46796]
===
match
---
operator: , [39595,39596]
operator: , [39613,39614]
===
match
---
expr_stmt [27889,27932]
expr_stmt [27907,27950]
===
match
---
name: mock_connection [37590,37605]
name: mock_connection [37608,37623]
===
match
---
dictorsetmaker [14355,14462]
dictorsetmaker [14373,14480]
===
match
---
operator: = [23781,23782]
operator: = [23799,23800]
===
match
---
name: kwargs [22217,22223]
name: kwargs [22235,22241]
===
match
---
string: "vault_conn_id" [43155,43170]
string: "vault_conn_id" [43173,43188]
===
match
---
number: 1 [42778,42779]
number: 1 [42796,42797]
===
match
---
name: mock_connection [23025,23040]
name: mock_connection [23043,23058]
===
match
---
dictorsetmaker [44991,45152]
dictorsetmaker [45009,45170]
===
match
---
expr_stmt [8895,8926]
expr_stmt [8901,8932]
===
match
---
operator: = [14819,14820]
operator: = [14837,14838]
===
match
---
atom [8629,8631]
atom [8635,8637]
===
match
---
param [2002,2021]
param [2002,2021]
===
match
---
name: cas [48089,48092]
name: cas [48107,48110]
===
match
---
operator: , [45246,45247]
operator: , [45264,45265]
===
match
---
operator: , [39876,39877]
operator: , [39894,39895]
===
match
---
operator: = [26785,26786]
operator: = [26803,26804]
===
match
---
name: test_approle_init_params [8335,8359]
name: test_approle_init_params [8341,8365]
===
match
---
name: providers [1040,1049]
name: providers [1040,1049]
===
match
---
argument [11267,11294]
argument [11285,11312]
===
match
---
name: assert_called_with [16444,16462]
name: assert_called_with [16462,16480]
===
match
---
expr_stmt [35422,35452]
expr_stmt [35440,35470]
===
match
---
param [1255,1270]
param [1255,1270]
===
match
---
name: kv_engine_version [27593,27610]
name: kv_engine_version [27611,27628]
===
match
---
name: mock [35180,35184]
name: mock [35198,35202]
===
match
---
argument [18320,18337]
argument [18338,18355]
===
match
---
string: "radius_port" [32749,32762]
string: "radius_port" [32767,32780]
===
match
---
argument [13665,13684]
argument [13683,13702]
===
match
---
operator: = [37215,37216]
operator: = [37233,37234]
===
match
---
string: "azure" [14368,14375]
string: "azure" [14386,14393]
===
match
---
trailer [20391,20393]
trailer [20409,20411]
===
match
---
atom_expr [11304,11445]
atom_expr [11322,11463]
===
match
---
operator: { [42816,42817]
operator: { [42834,42835]
===
match
---
name: test_hook [28656,28665]
name: test_hook [28674,28683]
===
match
---
atom_expr [1724,1757]
atom_expr [1724,1757]
===
match
---
trailer [34002,34008]
trailer [34020,34026]
===
match
---
operator: ** [14655,14657]
operator: ** [14673,14675]
===
match
---
atom_expr [22860,22876]
atom_expr [22878,22894]
===
match
---
name: vault_client [8129,8141]
name: vault_client [8135,8147]
===
match
---
trailer [25499,25501]
trailer [25517,25519]
===
match
---
trailer [24272,24292]
trailer [24290,24310]
===
match
---
trailer [6717,6727]
trailer [6717,6727]
===
match
---
name: mock_client [4530,4541]
name: mock_client [4530,4541]
===
match
---
operator: , [45833,45834]
operator: , [45851,45852]
===
match
---
name: v2 [40464,40466]
name: v2 [40482,40484]
===
match
---
name: assert_called_with [37261,37279]
name: assert_called_with [37279,37297]
===
match
---
dictorsetmaker [42838,42999]
dictorsetmaker [42856,43017]
===
match
---
trailer [32495,32508]
trailer [32513,32526]
===
match
---
name: VaultHook [19823,19832]
name: VaultHook [19841,19850]
===
match
---
operator: = [27957,27958]
operator: = [27975,27976]
===
match
---
operator: = [19333,19334]
operator: = [19351,19352]
===
match
---
string: "auth_type" [41548,41559]
string: "auth_type" [41566,41577]
===
match
---
name: mock_get_connection [34516,34535]
name: mock_get_connection [34534,34553]
===
match
---
string: 'metadata' [38140,38150]
string: 'metadata' [38158,38168]
===
match
---
name: mock [18964,18968]
name: mock [18982,18986]
===
match
---
operator: = [46682,46683]
operator: = [46700,46701]
===
match
---
name: return_value [8463,8475]
name: return_value [8469,8481]
===
match
---
name: mock_get_scopes [15849,15864]
name: mock_get_scopes [15867,15882]
===
match
---
name: patch [17020,17025]
name: patch [17038,17043]
===
match
---
name: test_hook [3434,3443]
name: test_hook [3434,3443]
===
match
---
operator: } [10004,10005]
operator: } [10016,10017]
===
match
---
atom [19512,19650]
atom [19530,19668]
===
match
---
simple_stmt [41504,41594]
simple_stmt [41522,41612]
===
match
---
atom_expr [22311,22331]
atom_expr [22329,22349]
===
match
---
trailer [8669,8673]
trailer [8675,8679]
===
match
---
number: 0 [38043,38044]
number: 0 [38061,38062]
===
match
---
trailer [10792,10812]
trailer [10810,10830]
===
match
---
testlist_comp [43549,43970]
testlist_comp [43567,43988]
===
match
---
name: self [40847,40851]
name: self [40865,40869]
===
match
---
atom_expr [20740,20769]
atom_expr [20758,20787]
===
match
---
parameters [44359,44397]
parameters [44377,44415]
===
match
---
expr_stmt [41603,41634]
expr_stmt [41621,41652]
===
match
---
atom_expr [5835,5854]
atom_expr [5835,5854]
===
match
---
name: return_value [31308,31320]
name: return_value [31326,31338]
===
match
---
operator: @ [18963,18964]
operator: @ [18981,18982]
===
match
---
simple_stmt [42332,43044]
simple_stmt [42350,43062]
===
match
---
trailer [21491,21504]
trailer [21509,21522]
===
match
---
name: assert_called_with [30741,30759]
name: assert_called_with [30759,30777]
===
match
---
name: Client [12889,12895]
name: Client [12907,12913]
===
match
---
simple_stmt [46800,46821]
simple_stmt [46818,46839]
===
match
---
operator: = [8476,8477]
operator: = [8482,8483]
===
match
---
name: patch [27706,27711]
name: patch [27724,27729]
===
match
---
name: MagicMock [11826,11835]
name: MagicMock [11844,11853]
===
match
---
expr_stmt [31252,31282]
expr_stmt [31270,31300]
===
match
---
string: 'wrap_info' [39998,40009]
string: 'wrap_info' [40016,40027]
===
match
---
dictorsetmaker [32890,32923]
dictorsetmaker [32908,32941]
===
match
---
name: mock [2046,2050]
name: mock [2046,2050]
===
match
---
name: MagicMock [42229,42238]
name: MagicMock [42247,42256]
===
match
---
atom_expr [5944,5983]
atom_expr [5944,5983]
===
match
---
trailer [14796,14815]
trailer [14814,14833]
===
match
---
string: "resource" [13674,13684]
string: "resource" [13692,13702]
===
match
---
trailer [25207,25225]
trailer [25225,25243]
===
match
---
operator: ** [2563,2565]
operator: ** [2563,2565]
===
match
---
operator: { [12166,12167]
operator: { [12184,12185]
===
match
---
operator: , [39984,39985]
operator: , [40002,40003]
===
match
---
name: mock_hvac [42249,42258]
name: mock_hvac [42267,42276]
===
match
---
name: Client [7911,7917]
name: Client [7911,7917]
===
match
---
name: match [32974,32979]
name: match [32992,32997]
===
match
---
string: "kv_engine_version" [49039,49058]
string: "kv_engine_version" [49057,49076]
===
match
---
string: "https" [6937,6944]
string: "https" [6937,6944]
===
match
---
expr_stmt [43267,43330]
expr_stmt [43285,43348]
===
match
---
name: test_hook [45467,45476]
name: test_hook [45485,45494]
===
match
---
trailer [2050,2060]
trailer [2050,2060]
===
match
---
atom_expr [45479,45498]
atom_expr [45497,45516]
===
match
---
operator: , [44364,44365]
operator: , [44382,44383]
===
match
---
operator: , [29296,29297]
operator: , [29314,29315]
===
match
---
name: v2 [42355,42357]
name: v2 [42373,42375]
===
match
---
atom [44702,45283]
atom [44720,45301]
===
match
---
name: secret [40426,40432]
name: secret [40444,40450]
===
match
---
param [2900,2919]
param [2900,2919]
===
match
---
atom_expr [25510,25539]
atom_expr [25528,25557]
===
match
---
name: MagicMock [25490,25499]
name: MagicMock [25508,25517]
===
match
---
trailer [28433,28440]
trailer [28451,28458]
===
match
---
expr_stmt [21803,21846]
expr_stmt [21821,21864]
===
match
---
name: version [38928,38935]
name: version [38946,38953]
===
match
---
trailer [13597,13616]
trailer [13615,13634]
===
match
---
number: 0 [39659,39660]
number: 0 [39677,39678]
===
match
---
name: kv_engine_version [36233,36250]
name: kv_engine_version [36251,36268]
===
match
---
name: mock_connection [19660,19675]
name: mock_connection [19678,19693]
===
match
---
simple_stmt [11951,12002]
simple_stmt [11969,12020]
===
match
---
trailer [40124,40136]
trailer [40142,40154]
===
match
---
operator: , [14612,14613]
operator: , [14630,14631]
===
match
---
operator: , [25915,25916]
operator: , [25933,25934]
===
match
---
operator: , [43032,43033]
operator: , [43050,43051]
===
match
---
name: patch [4278,4283]
name: patch [4278,4283]
===
match
---
trailer [38719,38742]
trailer [38737,38760]
===
match
---
string: "auth_type" [24587,24598]
string: "auth_type" [24605,24616]
===
match
---
operator: , [32771,32772]
operator: , [32789,32790]
===
match
---
name: self [48592,48596]
name: self [48610,48614]
===
match
---
atom [39682,39984]
atom [39700,40002]
===
match
---
decorators [10437,10599]
decorators [10455,10617]
===
match
---
trailer [1412,1429]
trailer [1412,1429]
===
match
---
name: get_mock_connection [48687,48706]
name: get_mock_connection [48705,48724]
===
match
---
operator: { [46818,46819]
operator: { [46836,46837]
===
match
---
string: 'wrap_info' [46093,46104]
string: 'wrap_info' [46111,46122]
===
match
---
operator: = [11914,11915]
operator: = [11932,11933]
===
match
---
simple_stmt [27994,28045]
simple_stmt [28012,28063]
===
match
---
operator: , [24658,24659]
operator: , [24676,24677]
===
match
---
simple_stmt [21225,21260]
simple_stmt [21243,21278]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [47405,47469]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [47423,47487]
===
match
---
operator: == [32144,32146]
operator: == [32162,32164]
===
match
---
comparison [38758,38798]
comparison [38776,38816]
===
match
---
simple_stmt [21855,21900]
simple_stmt [21873,21918]
===
match
---
trailer [36097,36131]
trailer [36115,36149]
===
match
---
trailer [36064,36078]
trailer [36082,36096]
===
match
---
name: get_mock_connection [17508,17527]
name: get_mock_connection [17526,17545]
===
match
---
trailer [12953,12973]
trailer [12971,12991]
===
match
---
atom_expr [12351,12371]
atom_expr [12369,12389]
===
match
---
string: "kv_engine_version" [46971,46990]
string: "kv_engine_version" [46989,47008]
===
match
---
dotted_name [880,893]
dotted_name [880,893]
===
match
---
atom_expr [12949,12975]
atom_expr [12967,12993]
===
match
---
decorators [37348,37510]
decorators [37366,37528]
===
match
---
trailer [5048,5060]
trailer [5048,5060]
===
match
---
string: "vault_conn_id" [34747,34762]
string: "vault_conn_id" [34765,34780]
===
match
---
string: "https://localhost:8180" [6850,6874]
string: "https://localhost:8180" [6850,6874]
===
match
---
assert_stmt [9259,9311]
assert_stmt [9271,9323]
===
match
---
argument [20199,20226]
argument [20217,20244]
===
match
---
string: 'http://localhost:8180' [9082,9105]
string: 'http://localhost:8180' [9088,9111]
===
match
---
operator: , [26741,26742]
operator: , [26759,26760]
===
match
---
simple_stmt [8107,8160]
simple_stmt [8113,8166]
===
match
---
name: patch [20466,20471]
name: patch [20484,20489]
===
match
---
trailer [27905,27918]
trailer [27923,27936]
===
match
---
expr_stmt [29034,29078]
expr_stmt [29052,29096]
===
match
---
comparison [4220,4266]
comparison [4220,4266]
===
match
---
operator: = [20921,20922]
operator: = [20939,20940]
===
match
---
comparison [34024,34069]
comparison [34042,34087]
===
match
---
simple_stmt [13449,13484]
simple_stmt [13467,13502]
===
match
---
expr_stmt [48717,48767]
expr_stmt [48735,48785]
===
match
---
name: patch [32283,32288]
name: patch [32301,32306]
===
match
---
operator: , [21721,21722]
operator: , [21739,21740]
===
match
---
simple_stmt [24761,24793]
simple_stmt [24779,24811]
===
match
---
name: connection_dict [44611,44626]
name: connection_dict [44629,44644]
===
match
---
atom_expr [24489,24533]
atom_expr [24507,24551]
===
match
---
operator: = [36714,36715]
operator: = [36732,36733]
===
match
---
simple_stmt [20845,20896]
simple_stmt [20863,20914]
===
match
---
name: mock_client [11807,11818]
name: mock_client [11825,11836]
===
match
---
trailer [13576,13581]
trailer [13594,13599]
===
match
---
string: "token" [45425,45432]
string: "token" [45443,45450]
===
match
---
name: mock_connection [25705,25720]
name: mock_connection [25723,25738]
===
match
---
trailer [4558,4560]
trailer [4558,4560]
===
match
---
expr_stmt [10883,10903]
expr_stmt [10901,10921]
===
match
---
string: "token" [43185,43192]
string: "token" [43203,43210]
===
match
---
atom_expr [33991,34008]
atom_expr [34009,34026]
===
match
---
decorator [25231,25311]
decorator [25249,25329]
===
match
---
string: 'secret_value' [40407,40421]
string: 'secret_value' [40425,40439]
===
match
---
assert_stmt [34017,34069]
assert_stmt [34035,34087]
===
match
---
operator: { [41711,41712]
operator: { [41729,41730]
===
match
---
simple_stmt [24848,24904]
simple_stmt [24866,24922]
===
match
---
string: "role" [8832,8838]
string: "role" [8838,8844]
===
match
---
atom [22126,22183]
atom [22144,22201]
===
match
---
name: mock_connection [43053,43068]
name: mock_connection [43071,43086]
===
match
---
name: patch [35185,35190]
name: patch [35203,35208]
===
match
---
expr_stmt [31456,31593]
expr_stmt [31474,31611]
===
match
---
name: patch [6079,6084]
name: patch [6079,6084]
===
match
---
operator: = [8514,8515]
operator: = [8520,8521]
===
match
---
simple_stmt [7575,7745]
simple_stmt [7575,7745]
===
match
---
name: host [1213,1217]
name: host [1213,1217]
===
match
---
argument [14986,15002]
argument [15004,15020]
===
match
---
simple_stmt [11084,11116]
simple_stmt [11102,11134]
===
match
---
name: test_client [11304,11315]
name: test_client [11322,11333]
===
match
---
name: kwargs [23155,23161]
name: kwargs [23173,23179]
===
match
---
expr_stmt [29177,29243]
expr_stmt [29195,29261]
===
match
---
dotted_name [48282,48302]
dotted_name [48300,48320]
===
match
---
atom_expr [9663,9689]
atom_expr [9675,9701]
===
match
---
string: "role" [9837,9843]
string: "role" [9849,9855]
===
match
---
name: mock [41854,41858]
name: mock [41872,41876]
===
match
---
assert_stmt [6736,6788]
assert_stmt [6736,6788]
===
match
---
simple_stmt [23856,23909]
simple_stmt [23874,23927]
===
match
---
testlist_comp [17694,17721]
testlist_comp [17712,17739]
===
match
---
name: mock_get_connection [48634,48653]
name: mock_get_connection [48652,48671]
===
match
---
trailer [46217,46220]
trailer [46235,46238]
===
match
---
name: side_effect [14515,14526]
name: side_effect [14533,14544]
===
match
---
string: "vault_conn_id" [40177,40192]
string: "vault_conn_id" [40195,40210]
===
match
---
atom_expr [13768,13817]
atom_expr [13786,13835]
===
match
---
name: port [1532,1536]
name: port [1532,1536]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [1890,1954]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [1890,1954]
===
match
---
assert_stmt [21470,21522]
assert_stmt [21488,21540]
===
match
---
trailer [39465,39485]
trailer [39483,39503]
===
match
---
atom_expr [32839,32858]
atom_expr [32857,32876]
===
match
---
trailer [9687,9689]
trailer [9699,9701]
===
match
---
expr_stmt [37029,37063]
expr_stmt [37047,37081]
===
match
---
atom_expr [3074,3106]
atom_expr [3074,3106]
===
match
---
operator: { [17971,17972]
operator: { [17989,17990]
===
match
---
atom_expr [45340,45359]
atom_expr [45358,45377]
===
match
---
arglist [12510,12584]
arglist [12528,12602]
===
match
---
name: mock [18880,18884]
name: mock [18898,18902]
===
match
---
name: test_hook [34918,34927]
name: test_hook [34936,34945]
===
match
---
operator: = [5493,5494]
operator: = [5493,5494]
===
match
---
simple_stmt [16014,16081]
simple_stmt [16032,16099]
===
match
---
name: patch [35269,35274]
name: patch [35287,35292]
===
match
---
trailer [10945,10957]
trailer [10963,10975]
===
match
---
string: "vault_conn_id" [28224,28239]
string: "vault_conn_id" [28242,28257]
===
match
---
name: get [45322,45325]
name: get [45340,45343]
===
match
---
atom [38758,38788]
atom [38776,38806]
===
match
---
string: 'user' [12521,12527]
string: 'user' [12539,12545]
===
match
---
name: pytest [32948,32954]
name: pytest [32966,32972]
===
match
---
trailer [36627,36629]
trailer [36645,36647]
===
match
---
string: 'secret_value' [39723,39737]
string: 'secret_value' [39741,39755]
===
match
---
simple_stmt [33434,33485]
simple_stmt [33452,33503]
===
match
---
name: connection_dict [28054,28069]
name: connection_dict [28072,28087]
===
match
---
operator: = [18424,18425]
operator: = [18442,18443]
===
match
---
name: test_client [18458,18469]
name: test_client [18476,18487]
===
match
---
trailer [12895,12908]
trailer [12913,12926]
===
match
---
name: v2 [37847,37849]
name: v2 [37865,37867]
===
match
---
string: "auth_type" [47915,47926]
string: "auth_type" [47933,47944]
===
match
---
param [1985,1990]
param [1985,1990]
===
match
---
trailer [9158,9192]
trailer [9170,9204]
===
match
---
atom_expr [25986,26037]
atom_expr [26004,26055]
===
match
---
atom_expr [7357,7401]
atom_expr [7357,7401]
===
match
---
trailer [30249,30262]
trailer [30267,30280]
===
match
---
trailer [35470,35477]
trailer [35488,35495]
===
match
---
name: get [13103,13106]
name: get [13121,13124]
===
match
---
trailer [33852,33859]
trailer [33870,33877]
===
match
---
argument [27374,27401]
argument [27392,27419]
===
match
---
operator: = [37714,37715]
operator: = [37732,37733]
===
match
---
param [2871,2888]
param [2871,2888]
===
match
---
name: mock_connection [20880,20895]
name: mock_connection [20898,20913]
===
match
---
name: self [30195,30199]
name: self [30213,30217]
===
match
---
string: "path.json" [16206,16217]
string: "path.json" [16224,16235]
===
match
---
operator: } [12071,12072]
operator: } [12089,12090]
===
match
---
simple_stmt [26064,26096]
simple_stmt [26082,26114]
===
match
---
decorated [32193,33045]
decorated [32211,33063]
===
match
---
name: password [27475,27483]
name: password [27493,27501]
===
match
---
name: test_client [11188,11199]
name: test_client [11206,11217]
===
match
---
name: mock_get_connection [30230,30249]
name: mock_get_connection [30248,30267]
===
match
---
number: 2 [7732,7733]
number: 2 [7732,7733]
===
match
---
atom_expr [19359,19387]
atom_expr [19377,19405]
===
match
---
trailer [35671,35684]
trailer [35689,35702]
===
match
---
operator: } [34638,34639]
operator: } [34656,34657]
===
match
---
param [48592,48597]
param [48610,48615]
===
match
---
operator: = [22203,22204]
operator: = [22221,22222]
===
match
---
expr_stmt [26977,26997]
expr_stmt [26995,27015]
===
match
---
simple_stmt [27191,27223]
simple_stmt [27209,27241]
===
match
---
name: get [16077,16080]
name: get [16095,16098]
===
match
---
string: "kubernetes_jwt_path" [25847,25868]
string: "kubernetes_jwt_path" [25865,25886]
===
match
---
trailer [47828,47840]
trailer [47846,47858]
===
match
---
trailer [11247,11266]
trailer [11265,11284]
===
match
---
name: hashicorp [1050,1059]
name: hashicorp [1050,1059]
===
match
---
decorator [13968,14046]
decorator [13986,14064]
===
match
---
name: kv_engine_version [30993,31010]
name: kv_engine_version [31011,31028]
===
match
---
string: "vault_conn_id" [13189,13204]
string: "vault_conn_id" [13207,13222]
===
match
---
string: "pass" [1264,1270]
string: "pass" [1264,1270]
===
match
---
expr_stmt [10823,10873]
expr_stmt [10841,10891]
===
match
---
expr_stmt [2123,2167]
expr_stmt [2123,2167]
===
match
---
atom_expr [25185,25225]
atom_expr [25203,25243]
===
match
---
name: patch [28792,28797]
name: patch [28810,28815]
===
match
---
operator: = [17748,17749]
operator: = [17766,17767]
===
match
---
operator: = [35434,35435]
operator: = [35452,35453]
===
match
---
import_from [840,874]
import_from [840,874]
===
match
---
decorator [5217,5295]
decorator [5217,5295]
===
match
---
trailer [36512,36522]
trailer [36530,36540]
===
match
---
name: mock [29925,29929]
name: mock [29943,29947]
===
match
---
trailer [9126,9139]
trailer [9137,9145]
===
match
---
name: get_mock_connection [11921,11940]
name: get_mock_connection [11939,11958]
===
match
---
decorator [17206,17284]
decorator [17224,17302]
===
match
---
name: test_client [16701,16712]
name: test_client [16719,16730]
===
match
---
atom [38092,38122]
atom [38110,38140]
===
match
---
operator: { [4107,4108]
operator: { [4107,4108]
===
match
---
simple_stmt [32867,32934]
simple_stmt [32885,32952]
===
match
---
trailer [46756,46763]
trailer [46774,46781]
===
match
---
trailer [27212,27222]
trailer [27230,27240]
===
match
---
atom [10901,10903]
atom [10919,10921]
===
match
---
name: patch [44158,44163]
name: patch [44176,44181]
===
match
---
string: "azure_tenant_id" [13252,13269]
string: "azure_tenant_id" [13270,13287]
===
match
---
operator: , [32056,32057]
operator: , [32074,32075]
===
match
---
string: "auth_type" [28086,28097]
string: "auth_type" [28104,28115]
===
match
---
simple_stmt [33597,33687]
simple_stmt [33615,33705]
===
match
---
name: get [48961,48964]
name: get [48979,48982]
===
match
---
name: return_value [33454,33466]
name: return_value [33472,33484]
===
match
---
name: test_client [29621,29632]
name: test_client [29639,29650]
===
match
---
dotted_name [5990,6000]
dotted_name [5990,6000]
===
match
---
param [21717,21722]
param [21735,21740]
===
match
---
operator: = [29050,29051]
operator: = [29068,29069]
===
match
---
name: MagicMock [24178,24187]
name: MagicMock [24196,24205]
===
match
---
name: test_hook [13838,13847]
name: test_hook [13856,13865]
===
match
---
operator: , [27807,27808]
operator: , [27825,27826]
===
match
---
name: Client [14790,14796]
name: Client [14808,14814]
===
match
---
operator: = [40550,40551]
operator: = [40568,40569]
===
match
---
operator: = [32062,32063]
operator: = [32080,32081]
===
match
---
operator: , [43170,43171]
operator: , [43188,43189]
===
match
---
name: username [27458,27466]
name: username [27476,27484]
===
match
---
operator: = [29517,29518]
operator: = [29535,29536]
===
match
---
param [19070,19075]
param [19088,19093]
===
match
---
expr_stmt [27994,28044]
expr_stmt [28012,28062]
===
match
---
name: mock_get_connection [46566,46585]
name: mock_get_connection [46584,46603]
===
match
---
name: return_value [29107,29119]
name: return_value [29125,29137]
===
match
---
name: kv [48125,48127]
name: kv [48143,48145]
===
match
---
operator: { [8629,8630]
operator: { [8635,8636]
===
match
---
trailer [1449,1468]
trailer [1449,1468]
===
match
---
operator: = [41821,41822]
operator: = [41839,41840]
===
match
---
trailer [9879,9892]
trailer [9891,9904]
===
match
---
trailer [23656,23675]
trailer [23674,23693]
===
match
---
operator: = [40347,40348]
operator: = [40365,40366]
===
match
---
name: secrets [46210,46217]
name: secrets [46228,46235]
===
match
---
argument [12572,12583]
argument [12590,12601]
===
match
---
operator: = [11427,11428]
operator: = [11445,11446]
===
match
---
trailer [33318,33320]
trailer [33336,33338]
===
match
---
operator: = [38660,38661]
operator: = [38678,38679]
===
match
---
operator: { [34733,34734]
operator: { [34751,34752]
===
match
---
atom_expr [10718,10747]
atom_expr [10736,10765]
===
match
---
name: assert_called_with [21285,21303]
name: assert_called_with [21303,21321]
===
match
---
trailer [25526,25539]
trailer [25544,25557]
===
match
---
name: return_value [37870,37882]
name: return_value [37888,37900]
===
match
---
name: connection_dict [26977,26992]
name: connection_dict [26995,27010]
===
match
---
trailer [28459,28488]
trailer [28477,28506]
===
match
---
name: mock_connection [35656,35671]
name: mock_connection [35674,35689]
===
match
---
trailer [19174,19184]
trailer [19192,19202]
===
match
---
atom [34733,34790]
atom [34751,34808]
===
match
---
trailer [39451,39459]
trailer [39469,39477]
===
match
---
expr_stmt [19156,19186]
expr_stmt [19174,19204]
===
match
---
operator: @ [6073,6074]
operator: @ [6073,6074]
===
match
---
name: Client [9603,9609]
name: Client [9615,9621]
===
match
---
name: mock_connection [4621,4636]
name: mock_connection [4621,4636]
===
match
---
atom_expr [28982,29011]
atom_expr [29000,29029]
===
match
---
atom_expr [14133,14149]
atom_expr [14151,14167]
===
match
---
simple_stmt [4810,4877]
simple_stmt [4810,4877]
===
match
---
name: extra_dejson [22058,22070]
name: extra_dejson [22076,22088]
===
match
---
argument [38672,38680]
argument [38690,38698]
===
match
---
trailer [46223,46243]
trailer [46241,46261]
===
match
---
trailer [22576,22594]
trailer [22594,22612]
===
match
---
name: metadata [46181,46189]
name: metadata [46199,46207]
===
match
---
decorator [15369,15449]
decorator [15387,15467]
===
match
---
trailer [18401,18420]
trailer [18419,18438]
===
match
---
operator: = [2400,2401]
operator: = [2400,2401]
===
match
---
atom [2609,2662]
atom [2609,2662]
===
match
---
name: test_client [27295,27306]
name: test_client [27313,27324]
===
match
---
name: mock_connection [7445,7460]
name: mock_connection [7445,7460]
===
match
---
trailer [19688,19692]
trailer [19706,19710]
===
match
---
trailer [2978,2985]
trailer [2978,2985]
===
match
---
name: cas [48259,48262]
name: cas [48277,48280]
===
match
---
trailer [48178,48275]
trailer [48196,48293]
===
match
---
name: get_mock_connection [3842,3861]
name: get_mock_connection [3842,3861]
===
match
---
trailer [26906,26908]
trailer [26924,26926]
===
match
---
atom_expr [32077,32126]
atom_expr [32095,32144]
===
match
---
trailer [37003,37020]
trailer [37021,37038]
===
match
---
assert_stmt [40385,40432]
assert_stmt [40403,40450]
===
match
---
trailer [38829,38832]
trailer [38847,38850]
===
match
---
atom_expr [42249,42278]
atom_expr [42267,42296]
===
match
---
trailer [29816,29834]
trailer [29834,29852]
===
match
---
number: 2 [47958,47959]
number: 2 [47976,47977]
===
match
---
name: mock [7078,7082]
name: mock [7078,7082]
===
match
---
trailer [31936,31965]
trailer [31954,31983]
===
match
---
string: 'renewable' [43454,43465]
string: 'renewable' [43472,43483]
===
match
---
operator: , [48257,48258]
operator: , [48275,48276]
===
match
---
name: mock_client [39389,39400]
name: mock_client [39407,39418]
===
match
---
name: patch [4362,4367]
name: patch [4362,4367]
===
match
---
atom [36716,36764]
atom [36734,36782]
===
match
---
string: 'request_id' [45610,45622]
string: 'request_id' [45628,45640]
===
match
---
operator: @ [46347,46348]
operator: @ [46365,46366]
===
match
---
operator: = [6299,6300]
operator: = [6299,6300]
===
match
---
simple_stmt [30681,30716]
simple_stmt [30699,30734]
===
match
---
name: mock_connection [2211,2226]
name: mock_connection [2211,2226]
===
match
---
operator: = [38916,38917]
operator: = [38934,38935]
===
match
---
name: assert_called_with [28525,28543]
name: assert_called_with [28543,28561]
===
match
---
name: mock_get_connection [36464,36483]
name: mock_get_connection [36482,36501]
===
match
---
name: client_id [13698,13707]
name: client_id [13716,13725]
===
match
---
suite [24150,25226]
suite [24168,25244]
===
match
---
dictorsetmaker [41712,41728]
dictorsetmaker [41730,41746]
===
match
---
name: kwargs [25780,25786]
name: kwargs [25798,25804]
===
match
---
parameters [21716,21754]
parameters [21734,21772]
===
match
---
operator: = [47743,47744]
operator: = [47761,47762]
===
match
---
name: test_client [23798,23809]
name: test_client [23816,23827]
===
match
---
name: get [38539,38542]
name: get [38557,38560]
===
match
---
name: kv_engine_version [32170,32187]
name: kv_engine_version [32188,32205]
===
match
---
string: "auth_type" [14355,14366]
string: "auth_type" [14373,14384]
===
match
---
expr_stmt [15790,15840]
expr_stmt [15808,15858]
===
match
---
suite [3719,4267]
suite [3719,4267]
===
match
---
name: mock_hvac [34947,34956]
name: mock_hvac [34965,34974]
===
match
---
name: mock [2674,2678]
name: mock [2674,2678]
===
match
---
expr_stmt [18078,18112]
expr_stmt [18096,18130]
===
match
---
operator: , [6489,6490]
operator: , [6489,6490]
===
match
---
decorators [22600,22762]
decorators [22618,22780]
===
match
---
operator: , [5632,5633]
operator: , [5632,5633]
===
match
---
name: vault_client [29804,29816]
name: vault_client [29822,29834]
===
match
---
name: MagicMock [48795,48804]
name: MagicMock [48813,48822]
===
match
---
name: mock_client [35422,35433]
name: mock_client [35440,35451]
===
match
---
name: password [28561,28569]
name: password [28579,28587]
===
match
---
name: patch [13890,13895]
name: patch [13908,13913]
===
match
---
name: test_hook [29519,29528]
name: test_hook [29537,29546]
===
match
---
name: VaultHook [2553,2562]
name: VaultHook [2553,2562]
===
match
---
atom_expr [26260,26324]
atom_expr [26278,26342]
===
match
---
atom_expr [23640,23704]
atom_expr [23658,23722]
===
match
---
trailer [16402,16419]
trailer [16420,16437]
===
match
---
argument [49368,49390]
argument [49386,49408]
===
match
---
operator: = [46816,46817]
operator: = [46834,46835]
===
match
---
name: self [40782,40786]
name: self [40800,40804]
===
match
---
atom [17693,17722]
atom [17711,17740]
===
match
---
expr_stmt [21855,21899]
expr_stmt [21873,21917]
===
match
---
name: assert_called_with [26447,26465]
name: assert_called_with [26465,26483]
===
match
---
trailer [25126,25143]
trailer [25144,25161]
===
match
---
operator: = [14131,14132]
operator: = [14149,14150]
===
match
---
operator: } [12222,12223]
operator: } [12240,12241]
===
match
---
operator: { [21019,21020]
operator: { [21037,21038]
===
match
---
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [3492,3558]
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [3492,3558]
===
match
---
decorator [12684,12762]
decorator [12702,12780]
===
match
---
name: mock [34222,34226]
name: mock [34240,34244]
===
match
---
string: 'auth' [46154,46160]
string: 'auth' [46172,46178]
===
match
---
name: mock_get_connection [9698,9717]
name: mock_get_connection [9710,9729]
===
match
---
name: mock_get_connection [24303,24322]
name: mock_get_connection [24321,24340]
===
match
---
name: mock_get_connection [35566,35585]
name: mock_get_connection [35584,35603]
===
match
---
operator: } [49061,49062]
operator: } [49079,49080]
===
match
---
operator: = [14188,14189]
operator: = [14206,14207]
===
match
---
operator: = [38901,38902]
operator: = [38919,38920]
===
match
---
dotted_name [46432,46442]
dotted_name [46450,46460]
===
match
---
trailer [21897,21899]
trailer [21915,21917]
===
match
---
expr_stmt [2930,2960]
expr_stmt [2930,2960]
===
match
---
name: kv [41768,41770]
name: kv [41786,41788]
===
match
---
dictorsetmaker [31701,31734]
dictorsetmaker [31719,31752]
===
match
---
atom_expr [14263,14295]
atom_expr [14281,14313]
===
match
---
trailer [4038,4051]
trailer [4038,4051]
===
match
---
name: self [47515,47519]
name: self [47533,47537]
===
match
---
trailer [35585,35598]
trailer [35603,35616]
===
match
---
expr_stmt [37794,37814]
expr_stmt [37812,37832]
===
match
---
string: "custom" [5654,5662]
string: "custom" [5654,5662]
===
match
---
name: return_value [39486,39498]
name: return_value [39504,39516]
===
match
---
trailer [34878,34895]
trailer [34896,34913]
===
match
---
dictorsetmaker [31488,31583]
dictorsetmaker [31506,31601]
===
match
---
expr_stmt [20905,20925]
expr_stmt [20923,20943]
===
match
---
simple_stmt [28126,28193]
simple_stmt [28144,28211]
===
match
---
name: connection_dict [30290,30305]
name: connection_dict [30308,30323]
===
match
---
trailer [24828,24837]
trailer [24846,24855]
===
match
---
operator: , [1989,1990]
operator: , [1989,1990]
===
match
---
decorators [29840,30002]
decorators [29858,30020]
===
match
---
name: schema [1715,1721]
name: schema [1715,1721]
===
match
---
dictorsetmaker [44716,45273]
dictorsetmaker [44734,45291]
===
match
---
operator: = [26074,26075]
operator: = [26092,26093]
===
match
---
argument [9159,9173]
argument [9171,9185]
===
match
---
expr_stmt [7754,7785]
expr_stmt [7754,7785]
===
match
---
name: url [23676,23679]
name: url [23694,23697]
===
match
---
name: VaultHook [29413,29422]
name: VaultHook [29431,29440]
===
match
---
name: kv_engine_version [8142,8159]
name: kv_engine_version [8148,8165]
===
match
---
decorators [40587,40749]
decorators [40605,40767]
===
match
---
name: kwargs [29252,29258]
name: kwargs [29270,29276]
===
match
---
atom_expr [11202,11222]
atom_expr [11220,11240]
===
match
---
operator: = [38731,38732]
operator: = [38749,38750]
===
match
---
trailer [29735,29752]
trailer [29753,29770]
===
match
---
name: mock_hvac [10638,10647]
name: mock_hvac [10656,10665]
===
match
---
suite [48655,49401]
suite [48673,49419]
===
match
---
operator: ** [49094,49096]
operator: ** [49112,49114]
===
match
---
string: "auth_type" [11032,11043]
string: "auth_type" [11050,11061]
===
match
---
name: parameterized [991,1004]
name: parameterized [991,1004]
===
match
---
name: vault_client [28666,28678]
name: vault_client [28684,28696]
===
match
---
atom_expr [48790,48806]
atom_expr [48808,48824]
===
match
---
name: test_client [21225,21236]
name: test_client [21243,21254]
===
match
---
name: test_github_init_params [20630,20653]
name: test_github_init_params [20648,20671]
===
match
---
operator: = [24996,24997]
operator: = [25014,25015]
===
match
---
string: 'warnings' [40029,40039]
string: 'warnings' [40047,40057]
===
match
---
operator: , [18355,18356]
operator: , [18373,18374]
===
match
---
trailer [21180,21199]
trailer [21198,21217]
===
match
---
simple_stmt [36140,36190]
simple_stmt [36158,36208]
===
match
---
operator: , [12052,12053]
operator: , [12070,12071]
===
match
---
atom_expr [22089,22108]
atom_expr [22107,22126]
===
match
---
name: kwargs [14557,14563]
name: kwargs [14575,14581]
===
match
---
comparison [43346,44007]
comparison [43364,44025]
===
match
---
atom [40176,40256]
atom [40194,40274]
===
match
---
name: test_approle_dejson [9487,9506]
name: test_approle_dejson [9499,9518]
===
match
---
simple_stmt [24250,24295]
simple_stmt [24268,24313]
===
match
---
argument [30850,30864]
argument [30868,30882]
===
match
---
operator: } [49188,49189]
operator: } [49206,49207]
===
match
---
operator: = [23162,23163]
operator: = [23180,23181]
===
match
---
comparison [35085,35112]
comparison [35103,35130]
===
match
---
dotted_name [1879,1889]
dotted_name [1879,1889]
===
match
---
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [2685,2751]
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [2685,2751]
===
match
---
name: Client [33853,33859]
name: Client [33871,33877]
===
match
---
simple_stmt [44407,44452]
simple_stmt [44425,44470]
===
match
---
atom [15945,15974]
atom [15963,15992]
===
match
---
name: self [27803,27807]
name: self [27821,27825]
===
match
---
operator: { [44969,44970]
operator: { [44987,44988]
===
match
---
comparison [35128,35173]
comparison [35146,35191]
===
match
---
funcdef [35345,36251]
funcdef [35363,36269]
===
match
---
operator: , [39916,39917]
operator: , [39934,39935]
===
match
---
assert_stmt [33974,34008]
assert_stmt [33992,34026]
===
match
---
trailer [40996,41009]
trailer [41014,41027]
===
match
---
operator: = [26028,26029]
operator: = [26046,26047]
===
match
---
expr_stmt [3367,3398]
expr_stmt [3367,3398]
===
match
---
operator: , [32922,32923]
operator: , [32940,32941]
===
match
---
operator: = [1235,1236]
operator: = [1235,1236]
===
match
---
trailer [33453,33466]
trailer [33471,33484]
===
match
---
assert_stmt [45589,46189]
assert_stmt [45607,46207]
===
match
---
operator: , [46166,46167]
operator: , [46184,46185]
===
match
---
simple_stmt [3947,4014]
simple_stmt [3947,4014]
===
match
---
operator: , [42705,42706]
operator: , [42723,42724]
===
match
---
operator: { [3152,3153]
operator: { [3152,3153]
===
match
---
name: self [14228,14232]
name: self [14246,14250]
===
match
---
argument [30599,30607]
argument [30617,30625]
===
match
---
name: self [27959,27963]
name: self [27977,27981]
===
match
---
name: MagicMock [46727,46736]
name: MagicMock [46745,46754]
===
match
---
argument [49146,49164]
argument [49164,49182]
===
match
---
string: 'secret_key' [44910,44922]
string: 'secret_key' [44928,44940]
===
match
---
atom_expr [3837,3878]
atom_expr [3837,3878]
===
match
---
atom [48326,48338]
atom [48344,48356]
===
match
---
operator: , [17782,17783]
operator: , [17800,17801]
===
match
---
name: is_authenticated [9213,9229]
name: is_authenticated [9225,9241]
===
match
---
atom_expr [31266,31282]
atom_expr [31284,31300]
===
match
---
trailer [18200,18219]
trailer [18218,18237]
===
match
---
string: 'data' [39674,39680]
string: 'data' [39692,39698]
===
match
---
atom_expr [19265,19291]
atom_expr [19283,19309]
===
match
---
atom_expr [47016,47035]
atom_expr [47034,47053]
===
match
---
string: 'renewable' [45704,45715]
string: 'renewable' [45722,45733]
===
match
---
name: mock_hvac [9042,9051]
name: mock_hvac [9048,9057]
===
match
---
operator: = [1202,1203]
operator: = [1202,1203]
===
match
---
string: "kv_engine_version" [8852,8871]
string: "kv_engine_version" [8858,8877]
===
match
---
name: mock_get_connection [42151,42170]
name: mock_get_connection [42169,42188]
===
match
---
expr_stmt [24564,24669]
expr_stmt [24582,24687]
===
match
---
simple_stmt [26260,26325]
simple_stmt [26278,26343]
===
match
---
name: test_get_secret_metadata_v2 [42023,42050]
name: test_get_secret_metadata_v2 [42041,42068]
===
match
---
simple_stmt [17962,18029]
simple_stmt [17980,18047]
===
match
---
expr_stmt [3021,3065]
expr_stmt [3021,3065]
===
match
---
operator: , [44828,44829]
operator: , [44846,44847]
===
match
---
operator: , [12583,12584]
operator: , [12601,12602]
===
match
---
name: side_effect [23113,23124]
name: side_effect [23131,23142]
===
match
---
string: "vault_conn_id" [7833,7848]
string: "vault_conn_id" [7833,7848]
===
match
---
string: 'http://localhost:8180' [36020,36043]
string: 'http://localhost:8180' [36038,36061]
===
match
---
dictorsetmaker [29275,29381]
dictorsetmaker [29293,29399]
===
match
---
name: get_mock_connection [10793,10812]
name: get_mock_connection [10811,10830]
===
match
---
trailer [36657,36670]
trailer [36675,36688]
===
match
---
operator: == [30967,30969]
operator: == [30985,30987]
===
match
---
atom_expr [45518,45580]
atom_expr [45536,45598]
===
match
---
atom_expr [42151,42183]
atom_expr [42169,42201]
===
match
---
operator: = [41613,41614]
operator: = [41631,41632]
===
match
---
operator: , [4789,4790]
operator: , [4789,4790]
===
match
---
name: Client [5435,5441]
name: Client [5435,5441]
===
match
---
operator: } [25971,25972]
operator: } [25989,25990]
===
match
---
dictorsetmaker [45610,46167]
dictorsetmaker [45628,46185]
===
match
---
operator: } [38367,38368]
operator: } [38385,38386]
===
match
---
param [39165,39175]
param [39183,39193]
===
match
---
name: return_value [4586,4598]
name: return_value [4586,4598]
===
match
---
trailer [10941,10945]
trailer [10959,10963]
===
match
---
expr_stmt [2969,3012]
expr_stmt [2969,3012]
===
match
---
name: patch [15459,15464]
name: patch [15477,15482]
===
match
---
name: v2 [44039,44041]
name: v2 [44057,44059]
===
match
---
name: test_client [26333,26344]
name: test_client [26351,26362]
===
match
---
trailer [35440,35450]
trailer [35458,35468]
===
match
---
operator: @ [17122,17123]
operator: @ [17140,17141]
===
match
---
operator: == [36207,36209]
operator: == [36225,36227]
===
match
---
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [7005,7071]
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [7005,7071]
===
match
---
operator: = [10786,10787]
operator: = [10804,10805]
===
match
---
dotted_name [34138,34148]
dotted_name [34156,34166]
===
match
---
trailer [43085,43097]
trailer [43103,43115]
===
match
---
dictorsetmaker [19758,19791]
dictorsetmaker [19776,19809]
===
match
---
argument [47260,47283]
argument [47278,47301]
===
match
---
trailer [16637,16644]
trailer [16655,16662]
===
match
---
argument [37190,37205]
argument [37208,37223]
===
match
---
param [17314,17324]
param [17332,17342]
===
match
---
operator: , [43697,43698]
operator: , [43715,43716]
===
match
---
string: "auth_type" [36730,36741]
string: "auth_type" [36748,36759]
===
match
---
decorators [15172,15531]
decorators [15190,15549]
===
match
---
simple_stmt [9554,9585]
simple_stmt [9566,9597]
===
match
---
param [34325,34330]
param [34343,34348]
===
match
---
string: "vault_conn_id" [40194,40209]
string: "vault_conn_id" [40212,40227]
===
match
---
comparison [20409,20454]
comparison [20427,20472]
===
match
---
expr_stmt [10988,11074]
expr_stmt [11006,11092]
===
match
---
trailer [20729,20731]
trailer [20747,20749]
===
match
---
operator: } [39983,39984]
operator: } [40001,40002]
===
match
---
simple_stmt [18385,18450]
simple_stmt [18403,18468]
===
match
---
trailer [30636,30655]
trailer [30654,30673]
===
match
---
name: test_hook [27570,27579]
name: test_hook [27588,27597]
===
match
---
operator: = [47648,47649]
operator: = [47666,47667]
===
match
---
expr_stmt [29087,29137]
expr_stmt [29105,29155]
===
match
---
comparison [21477,21522]
comparison [21495,21540]
===
match
---
name: conn_type [7382,7391]
name: conn_type [7382,7391]
===
match
---
operator: } [41728,41729]
operator: } [41746,41747]
===
match
---
name: mock_client [33290,33301]
name: mock_client [33308,33319]
===
match
---
string: 'warnings' [46124,46134]
string: 'warnings' [46142,46152]
===
match
---
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [23926,23992]
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [23944,24010]
===
match
---
testlist_comp [48326,48369]
testlist_comp [48344,48387]
===
match
---
name: kwargs [14657,14663]
name: kwargs [14675,14681]
===
match
---
number: 8123 [30506,30510]
number: 8123 [30524,30528]
===
match
---
trailer [17612,17625]
trailer [17630,17643]
===
match
---
name: get [28189,28192]
name: get [28207,28210]
===
match
---
atom_expr [6339,6365]
atom_expr [6339,6365]
===
match
---
operator: == [28653,28655]
operator: == [28671,28673]
===
match
---
operator: , [49321,49322]
operator: , [49339,49340]
===
match
---
trailer [36168,36187]
trailer [36186,36205]
===
match
---
atom_expr [4979,4998]
atom_expr [4979,4998]
===
match
---
expr_stmt [14263,14313]
expr_stmt [14281,14331]
===
match
---
atom_expr [2318,2362]
atom_expr [2318,2362]
===
match
---
argument [29705,29714]
argument [29723,29732]
===
match
---
name: connection_dict [6557,6572]
name: connection_dict [6557,6572]
===
match
---
expr_stmt [31396,31446]
expr_stmt [31414,31464]
===
match
---
operator: { [23164,23165]
operator: { [23182,23183]
===
match
---
trailer [37869,37882]
trailer [37887,37900]
===
match
---
expr_stmt [3728,3758]
expr_stmt [3728,3758]
===
match
---
name: assert_called_with [28441,28459]
name: assert_called_with [28459,28477]
===
match
---
trailer [37757,37770]
trailer [37775,37788]
===
match
---
simple_stmt [37072,37137]
simple_stmt [37090,37155]
===
match
---
name: return_value [1376,1388]
name: return_value [1376,1388]
===
match
---
string: "vault_conn_id" [41531,41546]
string: "vault_conn_id" [41549,41564]
===
match
---
atom_expr [30367,30386]
atom_expr [30385,30404]
===
match
---
atom_expr [1408,1434]
atom_expr [1408,1434]
===
match
---
expr_stmt [10015,10046]
expr_stmt [10027,10058]
===
match
---
trailer [2165,2167]
trailer [2165,2167]
===
match
---
atom_expr [39224,39250]
atom_expr [39242,39268]
===
match
---
name: mock_hvac [12799,12808]
name: mock_hvac [12817,12826]
===
match
---
trailer [22057,22070]
trailer [22075,22088]
===
match
---
operator: , [24704,24705]
operator: , [24722,24723]
===
match
---
operator: , [19106,19107]
operator: , [19124,19125]
===
match
---
simple_stmt [13149,13336]
simple_stmt [13167,13354]
===
match
---
operator: = [3037,3038]
operator: = [3037,3038]
===
match
---
operator: @ [40671,40672]
operator: @ [40689,40690]
===
match
---
dictorsetmaker [24587,24659]
dictorsetmaker [24605,24677]
===
match
---
atom_expr [31650,31669]
atom_expr [31668,31687]
===
match
---
string: "kubernetes" [23191,23203]
string: "kubernetes" [23209,23221]
===
match
---
name: secret_path [49146,49157]
name: secret_path [49164,49175]
===
match
---
trailer [32088,32105]
trailer [32106,32123]
===
match
---
trailer [12868,12870]
trailer [12886,12888]
===
match
---
operator: , [46553,46554]
operator: , [46571,46572]
===
match
---
simple_stmt [26917,26968]
simple_stmt [26935,26986]
===
match
---
operator: = [38935,38936]
operator: = [38953,38954]
===
match
---
operator: = [2139,2140]
operator: = [2139,2140]
===
match
---
operator: , [24468,24469]
operator: , [24486,24487]
===
match
---
decorator [1878,1956]
decorator [1878,1956]
===
match
---
simple_stmt [10770,10815]
simple_stmt [10788,10833]
===
match
---
number: 2 [37297,37298]
number: 2 [37315,37316]
===
match
---
dotted_name [5134,5144]
dotted_name [5134,5144]
===
match
---
trailer [33832,33834]
trailer [33850,33852]
===
match
---
arglist [49146,49204]
arglist [49164,49222]
===
match
---
trailer [38826,38829]
trailer [38844,38847]
===
match
---
name: mock_hvac [37072,37081]
name: mock_hvac [37090,37099]
===
match
---
simple_stmt [32135,32188]
simple_stmt [32153,32206]
===
match
---
simple_stmt [28982,29026]
simple_stmt [29000,29044]
===
match
---
dotted_name [4357,4367]
dotted_name [4357,4367]
===
match
---
trailer [47692,47702]
trailer [47710,47720]
===
match
---
name: Client [2081,2087]
name: Client [2081,2087]
===
match
---
simple_stmt [19247,19292]
simple_stmt [19265,19310]
===
match
---
string: "vault_conn_id" [32907,32922]
string: "vault_conn_id" [32925,32940]
===
match
---
name: mock_connection [31343,31358]
name: mock_connection [31361,31376]
===
match
---
argument [49323,49341]
argument [49341,49359]
===
match
---
string: "pass" [36124,36130]
string: "pass" [36142,36148]
===
match
---
name: vault_client [3444,3456]
name: vault_client [3444,3456]
===
match
---
atom_expr [19865,19885]
atom_expr [19883,19903]
===
match
---
simple_stmt [30395,30568]
simple_stmt [30413,30586]
===
match
---
param [1213,1230]
param [1213,1230]
===
match
---
name: url [21304,21307]
name: url [21322,21325]
===
match
---
name: secret_path [48214,48225]
name: secret_path [48232,48243]
===
match
---
name: mock [1879,1883]
name: mock [1879,1883]
===
match
---
operator: = [14339,14340]
operator: = [14357,14358]
===
match
---
trailer [18159,18176]
trailer [18177,18194]
===
match
---
decorator [18682,18767]
decorator [18700,18785]
===
match
---
simple_stmt [40092,40159]
simple_stmt [40110,40177]
===
match
---
string: "credentials" [20311,20324]
string: "credentials" [20329,20342]
===
match
---
simple_stmt [33329,33373]
simple_stmt [33347,33391]
===
match
---
trailer [18284,18376]
trailer [18302,18394]
===
match
---
trailer [9926,9930]
trailer [9938,9942]
===
match
---
name: test_client [37029,37040]
name: test_client [37047,37058]
===
match
---
atom_expr [11916,11942]
atom_expr [11934,11960]
===
match
---
trailer [1620,1637]
trailer [1620,1637]
===
match
---
trailer [10734,10747]
trailer [10752,10765]
===
match
---
name: vault_client [37312,37324]
name: vault_client [37330,37342]
===
match
---
expr_stmt [17433,17476]
expr_stmt [17451,17494]
===
match
---
operator: == [18633,18635]
operator: == [18651,18653]
===
match
---
name: Client [47723,47729]
name: Client [47741,47747]
===
match
---
trailer [11546,11564]
trailer [11564,11582]
===
match
---
trailer [35969,35971]
trailer [35987,35989]
===
match
---
name: kwargs [22117,22123]
name: kwargs [22135,22141]
===
match
---
operator: } [40255,40256]
operator: } [40273,40274]
===
match
---
simple_stmt [46198,46342]
simple_stmt [46216,46360]
===
match
---
name: VaultHook [49084,49093]
name: VaultHook [49102,49111]
===
match
---
name: vault_client [5098,5110]
name: vault_client [5098,5110]
===
match
---
name: mock [20545,20549]
name: mock [20563,20567]
===
match
---
operator: { [28072,28073]
operator: { [28090,28091]
===
match
---
operator: , [7697,7698]
operator: , [7697,7698]
===
match
---
name: mock_connection [9733,9748]
name: mock_connection [9745,9760]
===
match
---
expr_stmt [32792,32858]
expr_stmt [32810,32876]
===
match
---
name: mock_hvac [21803,21812]
name: mock_hvac [21821,21830]
===
match
---
atom_expr [15849,15877]
atom_expr [15867,15895]
===
match
---
atom [48982,49062]
atom [49000,49080]
===
match
---
operator: { [48071,48072]
operator: { [48089,48090]
===
match
---
name: VaultHook [36937,36946]
name: VaultHook [36955,36964]
===
match
---
operator: } [38787,38788]
operator: } [38805,38806]
===
match
---
simple_stmt [2236,2309]
simple_stmt [2236,2309]
===
match
---
trailer [18488,18507]
trailer [18506,18525]
===
match
---
string: "kv_engine_version" [40233,40252]
string: "kv_engine_version" [40251,40270]
===
match
---
expr_stmt [38650,38681]
expr_stmt [38668,38699]
===
match
---
name: side_effect [20968,20979]
name: side_effect [20986,20997]
===
match
---
trailer [48913,48926]
trailer [48931,48944]
===
match
---
name: assert_called_with [16838,16856]
name: assert_called_with [16856,16874]
===
match
---
number: 2 [34024,34025]
number: 2 [34042,34043]
===
match
---
operator: = [4068,4069]
operator: = [4068,4069]
===
match
---
name: self [20810,20814]
name: self [20828,20832]
===
match
---
operator: } [4163,4164]
operator: } [4163,4164]
===
match
---
param [46566,46585]
param [46584,46603]
===
match
---
trailer [38508,38520]
trailer [38526,38538]
===
match
---
atom_expr [11951,11983]
atom_expr [11969,12001]
===
match
---
name: extra_dejson [32808,32820]
name: extra_dejson [32826,32838]
===
match
---
string: "vault_conn_id" [21200,21215]
string: "vault_conn_id" [21218,21233]
===
match
---
atom_expr [19823,19842]
atom_expr [19841,19860]
===
match
---
param [31211,31221]
param [31229,31239]
===
match
---
operator: , [20084,20085]
operator: , [20102,20103]
===
match
---
trailer [5441,5454]
trailer [5441,5454]
===
match
---
operator: , [38044,38045]
operator: , [38062,38063]
===
match
---
operator: { [6452,6453]
operator: { [6452,6453]
===
match
---
trailer [21284,21303]
trailer [21302,21321]
===
match
---
arglist [18521,18547]
arglist [18539,18565]
===
match
---
atom [42579,43032]
atom [42597,43050]
===
match
---
trailer [15694,15701]
trailer [15712,15719]
===
match
---
simple_stmt [30577,30609]
simple_stmt [30595,30627]
===
match
---
number: 2764800 [41274,41281]
number: 2764800 [41292,41299]
===
match
---
string: '' [39874,39876]
string: '' [39892,39894]
===
match
---
decorators [32193,32355]
decorators [32211,32373]
===
match
---
string: 'secret_value' [45818,45832]
string: 'secret_value' [45836,45850]
===
match
---
atom_expr [30125,30154]
atom_expr [30143,30172]
===
match
---
operator: } [14471,14472]
operator: } [14489,14490]
===
match
---
string: "role" [7691,7697]
string: "role" [7691,7697]
===
match
---
trailer [42354,42357]
trailer [42372,42375]
===
match
---
dictorsetmaker [45804,45832]
dictorsetmaker [45822,45850]
===
match
---
name: mock [34386,34390]
name: mock [34404,34408]
===
match
---
name: mock [32194,32198]
name: mock [32212,32216]
===
match
---
name: type [1329,1333]
name: type [1329,1333]
===
match
---
name: patch [39046,39051]
name: patch [39064,39069]
===
match
---
name: extra_dejson [25721,25733]
name: extra_dejson [25739,25751]
===
match
---
trailer [29422,29432]
trailer [29440,29450]
===
match
---
name: mock [14133,14137]
name: mock [14151,14155]
===
match
---
name: mock [7262,7266]
name: mock [7262,7266]
===
match
---
expr_stmt [14633,14664]
expr_stmt [14651,14682]
===
match
---
trailer [37311,37324]
trailer [37329,37342]
===
match
---
name: mock_client [21835,21846]
name: mock_client [21853,21864]
===
match
---
name: secret [49343,49349]
name: secret [49361,49367]
===
match
---
name: MagicMock [27869,27878]
name: MagicMock [27887,27896]
===
match
---
name: get [2347,2350]
name: get [2347,2350]
===
match
---
name: kwargs [3292,3298]
name: kwargs [3292,3298]
===
match
---
operator: , [9522,9523]
operator: , [9534,9535]
===
match
---
operator: @ [2673,2674]
operator: @ [2673,2674]
===
match
---
name: login [1568,1573]
name: login [1568,1573]
===
match
---
operator: = [23453,23454]
operator: = [23471,23472]
===
match
---
dotted_name [15262,15272]
dotted_name [15280,15290]
===
match
---
atom [2645,2651]
atom [2645,2651]
===
match
---
parameters [47514,47552]
parameters [47532,47570]
===
match
---
operator: } [47785,47786]
operator: } [47803,47804]
===
match
---
expr_stmt [47766,47786]
expr_stmt [47784,47804]
===
match
---
name: pytest [2473,2479]
name: pytest [2473,2479]
===
match
---
dictorsetmaker [49174,49188]
dictorsetmaker [49192,49206]
===
match
---
trailer [37720,37730]
trailer [37738,37748]
===
match
---
operator: = [12852,12853]
operator: = [12870,12871]
===
match
---
operator: , [20324,20325]
operator: , [20342,20343]
===
match
---
simple_stmt [30617,30673]
simple_stmt [30635,30691]
===
match
---
name: self [20654,20658]
name: self [20672,20676]
===
match
---
operator: { [5757,5758]
operator: { [5757,5758]
===
match
---
name: mock_get_connection [40799,40818]
name: mock_get_connection [40817,40836]
===
match
---
string: "kv_engine_version" [41570,41589]
string: "kv_engine_version" [41588,41607]
===
match
---
string: "auth_mount_point" [5634,5652]
string: "auth_mount_point" [5634,5652]
===
match
---
string: "tenant_id" [13640,13651]
string: "tenant_id" [13658,13669]
===
match
---
trailer [26189,26206]
trailer [26207,26224]
===
match
---
operator: = [1361,1362]
operator: = [1361,1362]
===
match
---
name: mock [6994,6998]
name: mock [6994,6998]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [36352,36416]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [36370,36434]
===
match
---
name: get [25768,25771]
name: get [25786,25789]
===
match
---
atom_expr [15909,15942]
atom_expr [15927,15960]
===
match
---
simple_stmt [8498,8543]
simple_stmt [8504,8549]
===
match
---
name: mock_connection [1413,1428]
name: mock_connection [1413,1428]
===
match
---
name: assert_called_with [31918,31936]
name: assert_called_with [31936,31954]
===
match
---
simple_stmt [21161,21217]
simple_stmt [21179,21235]
===
match
---
decorated [36256,37343]
decorated [36274,37361]
===
match
---
name: create_or_update_secret [48131,48154]
name: create_or_update_secret [48149,48172]
===
match
---
atom_expr [5088,5127]
atom_expr [5088,5127]
===
match
---
name: mock_get_connection [10649,10668]
name: mock_get_connection [10667,10686]
===
match
---
decorator [26618,26696]
decorator [26636,26714]
===
match
---
operator: = [28208,28209]
operator: = [28226,28227]
===
match
---
param [42068,42087]
param [42086,42105]
===
match
---
decorated [33050,34132]
decorated [33068,34150]
===
match
---
simple_stmt [37741,37785]
simple_stmt [37759,37803]
===
match
---
operator: , [30477,30478]
operator: , [30495,30496]
===
match
---
name: Client [39367,39373]
name: Client [39385,39391]
===
match
---
trailer [48124,48127]
trailer [48142,48145]
===
match
---
atom_expr [39259,39291]
atom_expr [39277,39309]
===
match
---
string: "kv_engine_version" [38617,38636]
string: "kv_engine_version" [38635,38654]
===
match
---
simple_stmt [47871,47961]
simple_stmt [47889,47979]
===
match
---
suite [14110,15167]
suite [14128,15185]
===
match
---
name: mount_point [44100,44111]
name: mount_point [44118,44129]
===
match
---
name: mount_point [5049,5060]
name: mount_point [5049,5060]
===
match
---
trailer [38832,38852]
trailer [38850,38870]
===
match
---
name: mock_connection [19335,19350]
name: mock_connection [19353,19368]
===
match
---
name: mock_connection [24250,24265]
name: mock_connection [24268,24283]
===
match
---
operator: , [49015,49016]
operator: , [49033,49034]
===
match
---
argument [46303,46317]
argument [46321,46335]
===
match
---
dictorsetmaker [4766,4790]
dictorsetmaker [4766,4790]
===
match
---
name: MagicMock [33309,33318]
name: MagicMock [33327,33336]
===
match
---
name: MagicMock [31271,31280]
name: MagicMock [31289,31298]
===
match
---
name: test_client [33991,34002]
name: test_client [34009,34020]
===
match
---
atom_expr [9271,9311]
atom_expr [9283,9323]
===
match
---
dotted_name [33051,33061]
dotted_name [33069,33079]
===
match
---
name: mock_get_connection [33736,33755]
name: mock_get_connection [33754,33773]
===
match
---
name: get_mock_connection [39229,39248]
name: get_mock_connection [39247,39266]
===
match
---
expr_stmt [30577,30608]
expr_stmt [30595,30626]
===
match
---
string: "role_id" [12054,12063]
string: "role_id" [12072,12081]
===
match
---
string: "vault_conn_id" [11163,11178]
string: "vault_conn_id" [11181,11196]
===
match
---
operator: } [36914,36915]
operator: } [36932,36933]
===
match
---
operator: = [18090,18091]
operator: = [18108,18109]
===
match
---
name: assert_called_with [23827,23845]
name: assert_called_with [23845,23863]
===
match
---
name: mock_connection [3021,3036]
name: mock_connection [3021,3036]
===
match
---
name: vault_client [18646,18658]
name: vault_client [18664,18676]
===
match
---
name: get_mock_connection [24273,24292]
name: get_mock_connection [24291,24310]
===
match
---
dotted_name [29841,29851]
dotted_name [29859,29869]
===
match
---
name: mock_hvac [34331,34340]
name: mock_hvac [34349,34358]
===
match
---
expr_stmt [29401,29432]
expr_stmt [29419,29450]
===
match
---
simple_stmt [17394,17425]
simple_stmt [17412,17443]
===
match
---
name: Client [2979,2985]
name: Client [2979,2985]
===
match
---
simple_stmt [22413,22476]
simple_stmt [22431,22494]
===
match
---
trailer [7276,7278]
trailer [7276,7278]
===
match
---
string: "missing" [45570,45579]
string: "missing" [45588,45597]
===
match
---
name: test_hook [10133,10142]
name: test_hook [10145,10154]
===
match
---
trailer [9609,9622]
trailer [9621,9634]
===
match
---
simple_stmt [9864,9931]
simple_stmt [9876,9943]
===
match
---
simple_stmt [26773,26804]
simple_stmt [26791,26822]
===
match
---
operator: } [36763,36764]
operator: } [36781,36782]
===
match
---
expr_stmt [2176,2226]
expr_stmt [2176,2226]
===
match
---
atom [41303,41321]
atom [41321,41339]
===
match
---
name: assert_called_with [25058,25076]
name: assert_called_with [25076,25094]
===
match
---
expr_stmt [43128,43217]
expr_stmt [43146,43235]
===
match
---
name: secrets [44028,44035]
name: secrets [44046,44053]
===
match
---
name: parameterized [6795,6808]
name: parameterized [6795,6808]
===
match
---
operator: = [14296,14297]
operator: = [14314,14315]
===
match
---
name: return_value [27906,27918]
name: return_value [27924,27936]
===
match
---
string: "resource" [14962,14972]
string: "resource" [14980,14990]
===
match
---
trailer [10197,10226]
trailer [10209,10238]
===
match
---
operator: , [13651,13652]
operator: , [13669,13670]
===
match
---
operator: ** [47992,47994]
operator: ** [48010,48012]
===
match
---
name: mock_get_scopes [19359,19374]
name: mock_get_scopes [19377,19392]
===
match
---
operator: = [28552,28553]
operator: = [28570,28571]
===
match
---
expr_stmt [42151,42201]
expr_stmt [42169,42219]
===
match
---
operator: = [1504,1505]
operator: = [1504,1505]
===
match
---
simple_stmt [32479,32523]
simple_stmt [32497,32541]
===
match
---
argument [43249,43257]
argument [43267,43275]
===
match
---
operator: = [49374,49375]
operator: = [49392,49393]
===
match
---
atom [39501,40082]
atom [39519,40100]
===
match
---
simple_stmt [16089,16272]
simple_stmt [16107,16290]
===
match
---
string: "secret" [1203,1211]
string: "secret" [1203,1211]
===
match
---
atom_expr [26787,26803]
atom_expr [26805,26821]
===
match
---
trailer [12292,12311]
trailer [12310,12329]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [8261,8325]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [8267,8331]
===
match
---
decorator [23998,24076]
decorator [24016,24094]
===
match
---
trailer [24214,24227]
trailer [24232,24245]
===
match
---
trailer [31917,31936]
trailer [31935,31954]
===
match
---
trailer [38852,38876]
trailer [38870,38894]
===
match
---
simple_stmt [23484,23540]
simple_stmt [23502,23558]
===
match
---
operator: = [24336,24337]
operator: = [24354,24355]
===
match
---
trailer [24921,24940]
trailer [24939,24958]
===
match
---
string: 'missing' [44127,44136]
string: 'missing' [44145,44154]
===
match
---
name: parameterized [2579,2592]
name: parameterized [2579,2592]
===
match
---
name: mock_hvac [39357,39366]
name: mock_hvac [39375,39384]
===
match
---
expr_stmt [37590,37634]
expr_stmt [37608,37652]
===
match
---
expr_stmt [10679,10709]
expr_stmt [10697,10727]
===
match
---
name: mock_hvac [17314,17323]
name: mock_hvac [17332,17341]
===
match
---
atom_expr [33329,33358]
atom_expr [33347,33376]
===
match
---
trailer [13616,13759]
trailer [13634,13777]
===
match
---
trailer [36789,36802]
trailer [36807,36820]
===
match
---
name: connection_dict [20905,20920]
name: connection_dict [20923,20938]
===
match
---
name: mock_hvac [46555,46564]
name: mock_hvac [46573,46582]
===
match
---
operator: , [40231,40232]
operator: , [40249,40250]
===
match
---
atom [35644,35646]
atom [35662,35664]
===
match
---
operator: = [16575,16576]
operator: = [16593,16594]
===
match
---
expr_stmt [2318,2384]
expr_stmt [2318,2384]
===
match
---
name: mock_get_connection [22990,23009]
name: mock_get_connection [23008,23027]
===
match
---
name: extra_dejson [2334,2346]
name: extra_dejson [2334,2346]
===
match
---
expr_stmt [4810,4876]
expr_stmt [4810,4876]
===
match
---
name: path [38912,38916]
name: path [38930,38934]
===
match
---
name: mock_get_connection [36638,36657]
name: mock_get_connection [36656,36675]
===
match
---
name: keyfile_dict [18320,18332]
name: keyfile_dict [18338,18350]
===
match
---
file_input [814,49401]
file_input [814,49419]
===
match
---
string: "pass" [30873,30879]
string: "pass" [30891,30897]
===
match
---
operator: , [45410,45411]
operator: , [45428,45429]
===
match
---
operator: , [23293,23294]
operator: , [23311,23312]
===
match
---
trailer [3783,3796]
trailer [3783,3796]
===
match
---
operator: @ [18682,18683]
operator: @ [18700,18701]
===
match
---
comparison [34085,34131]
comparison [34103,34149]
===
match
---
simple_stmt [41643,41696]
simple_stmt [41661,41714]
===
match
---
trailer [27457,27491]
trailer [27475,27509]
===
match
---
decorator [9317,9397]
decorator [9329,9409]
===
match
---
trailer [25143,25162]
trailer [25161,25180]
===
match
---
name: test_client [16809,16820]
name: test_client [16827,16838]
===
match
---
operator: { [36858,36859]
operator: { [36876,36877]
===
match
---
simple_stmt [15849,15901]
simple_stmt [15867,15919]
===
match
---
simple_stmt [4885,4959]
simple_stmt [4885,4959]
===
match
---
string: 'pass' [12552,12558]
string: 'pass' [12570,12576]
===
match
---
simple_stmt [47713,47757]
simple_stmt [47731,47775]
===
match
---
name: mock_hvac [20163,20172]
name: mock_hvac [20181,20190]
===
match
---
param [30039,30044]
param [30057,30062]
===
match
---
operator: , [41321,41322]
operator: , [41339,41340]
===
match
---
name: read_secret_version [46224,46243]
name: read_secret_version [46242,46261]
===
match
---
string: "vault_conn_id" [12312,12327]
string: "vault_conn_id" [12330,12345]
===
match
---
name: mock_hvac [7207,7216]
name: mock_hvac [7207,7216]
===
match
---
name: return_value [24323,24335]
name: return_value [24341,24353]
===
match
---
name: mock_connection [3109,3124]
name: mock_connection [3109,3124]
===
match
---
name: mock_client [10750,10761]
name: mock_client [10768,10779]
===
match
---
trailer [4241,4254]
trailer [4241,4254]
===
match
---
expr_stmt [9939,10005]
expr_stmt [9951,10017]
===
match
---
trailer [30134,30141]
trailer [30152,30159]
===
match
---
operator: = [34441,34442]
operator: = [34459,34460]
===
match
---
name: url [12416,12419]
name: url [12434,12437]
===
match
---
trailer [16644,16663]
trailer [16662,16681]
===
match
---
trailer [47824,47828]
trailer [47842,47846]
===
match
---
argument [28544,28559]
argument [28562,28577]
===
match
---
param [10638,10648]
param [10656,10666]
===
match
---
operator: = [30155,30156]
operator: = [30173,30174]
===
match
---
trailer [13404,13423]
trailer [13422,13441]
===
match
---
name: return_value [11863,11875]
name: return_value [11881,11893]
===
match
---
name: test_hook [22311,22320]
name: test_hook [22329,22338]
===
match
---
string: "token" [38608,38615]
string: "token" [38626,38633]
===
match
---
name: gcp [18475,18478]
name: gcp [18493,18496]
===
match
---
operator: = [49349,49350]
operator: = [49367,49368]
===
match
---
operator: = [30193,30194]
operator: = [30211,30212]
===
match
---
atom_expr [30724,30788]
atom_expr [30742,30806]
===
match
---
trailer [10332,10349]
trailer [10350,10367]
===
match
---
trailer [10349,10368]
trailer [10367,10386]
===
match
---
atom_expr [8516,8542]
atom_expr [8522,8548]
===
match
---
trailer [9280,9293]
trailer [9292,9305]
===
match
---
trailer [7381,7401]
trailer [7381,7401]
===
match
---
operator: = [4542,4543]
operator: = [4542,4543]
===
match
---
atom_expr [30695,30715]
atom_expr [30713,30733]
===
match
---
trailer [19439,19452]
trailer [19457,19470]
===
match
---
string: "8123" [31576,31582]
string: "8123" [31594,31600]
===
match
---
trailer [35155,35173]
trailer [35173,35191]
===
match
---
argument [16664,16691]
argument [16682,16709]
===
match
---
arglist [13630,13749]
arglist [13648,13767]
===
match
---
dictorsetmaker [43790,43951]
dictorsetmaker [43808,43969]
===
match
---
trailer [30335,30348]
trailer [30353,30366]
===
match
---
name: mock_hvac [35461,35470]
name: mock_hvac [35479,35488]
===
match
---
trailer [44567,44574]
trailer [44585,44592]
===
match
---
simple_stmt [32440,32471]
simple_stmt [32458,32489]
===
match
---
string: "secret" [34085,34093]
string: "secret" [34103,34111]
===
match
---
name: test_hook [30577,30586]
name: test_hook [30595,30604]
===
match
---
trailer [3249,3261]
trailer [3249,3261]
===
match
---
name: is_authenticated [29736,29752]
name: is_authenticated [29754,29770]
===
match
---
name: token [21390,21395]
name: token [21408,21413]
===
match
---
expr_stmt [12082,12148]
expr_stmt [12100,12166]
===
match
---
number: 1 [39949,39950]
number: 1 [39967,39968]
===
match
---
operator: = [17969,17970]
operator: = [17987,17988]
===
match
---
name: extra_dejson [23096,23108]
name: extra_dejson [23114,23126]
===
match
---
operator: , [42488,42489]
operator: , [42506,42507]
===
match
---
operator: , [43017,43018]
operator: , [43035,43036]
===
match
---
expr_stmt [34463,34507]
expr_stmt [34481,34525]
===
match
---
trailer [21389,21403]
trailer [21407,21421]
===
match
---
number: 1 [6629,6630]
number: 1 [6629,6630]
===
match
---
atom_expr [35461,35490]
atom_expr [35479,35508]
===
match
---
expr_stmt [25705,25771]
expr_stmt [25723,25789]
===
match
---
name: vault_client [36220,36232]
name: vault_client [36238,36250]
===
match
---
name: assert_called_with [7918,7936]
name: assert_called_with [7918,7936]
===
match
---
operator: } [18027,18028]
operator: } [18045,18046]
===
match
---
trailer [6525,6538]
trailer [6525,6538]
===
match
---
trailer [2333,2346]
trailer [2333,2346]
===
match
---
name: assert_called_once_with [41786,41809]
name: assert_called_once_with [41804,41827]
===
match
---
trailer [9582,9584]
trailer [9594,9596]
===
match
---
operator: , [33258,33259]
operator: , [33276,33277]
===
match
---
name: MagicMock [37721,37730]
name: MagicMock [37739,37748]
===
match
---
operator: , [33247,33248]
operator: , [33265,33266]
===
match
---
decorator [23914,23994]
decorator [23932,24012]
===
match
---
trailer [23845,23847]
trailer [23863,23865]
===
match
---
operator: } [16003,16004]
operator: } [16021,16022]
===
match
---
trailer [47634,47647]
trailer [47652,47665]
===
match
---
operator: ** [34822,34824]
operator: ** [34840,34842]
===
match
---
name: Client [17443,17449]
name: Client [17461,17467]
===
match
---
trailer [32954,32961]
trailer [32972,32979]
===
match
---
string: 'scope2' [17639,17647]
string: 'scope2' [17657,17665]
===
match
---
expr_stmt [28943,28973]
expr_stmt [28961,28991]
===
match
---
name: VaultHook [11096,11105]
name: VaultHook [11114,11123]
===
match
---
name: is_authenticated [32089,32105]
name: is_authenticated [32107,32123]
===
match
---
expr_stmt [39318,39348]
expr_stmt [39336,39366]
===
match
---
trailer [44041,44062]
trailer [44059,44080]
===
match
---
atom_expr [10162,10226]
atom_expr [10174,10238]
===
match
---
trailer [46209,46217]
trailer [46227,46235]
===
match
---
trailer [34963,34982]
trailer [34981,35000]
===
match
---
param [33249,33259]
param [33267,33277]
===
match
---
trailer [40335,40376]
trailer [40353,40394]
===
match
---
operator: @ [15261,15262]
operator: @ [15279,15280]
===
match
---
trailer [39248,39250]
trailer [39266,39268]
===
match
---
atom_expr [24706,24733]
atom_expr [24724,24751]
===
match
---
string: "pass" [15030,15036]
string: "pass" [15048,15054]
===
match
---
trailer [31985,31990]
trailer [32003,32008]
===
match
---
with_stmt [25981,26143]
with_stmt [25999,26161]
===
match
---
trailer [8060,8077]
trailer [8066,8083]
===
match
---
atom_expr [22990,23022]
atom_expr [23008,23040]
===
match
---
argument [47078,47096]
argument [47096,47114]
===
match
---
name: test_ldap_init_params [26704,26725]
name: test_ldap_init_params [26722,26743]
===
match
---
name: mock [11571,11575]
name: mock [11589,11593]
===
match
---
operator: = [35701,35702]
operator: = [35719,35720]
===
match
---
name: return_value [3907,3919]
name: return_value [3907,3919]
===
match
---
operator: , [28105,28106]
operator: , [28123,28124]
===
match
---
expr_stmt [17485,17529]
expr_stmt [17503,17547]
===
match
---
expr_stmt [44460,44510]
expr_stmt [44478,44528]
===
match
---
operator: ** [27213,27215]
operator: ** [27231,27233]
===
match
---
operator: = [19863,19864]
operator: = [19881,19882]
===
match
---
name: get [14545,14548]
name: get [14563,14566]
===
match
---
simple_stmt [3134,3208]
simple_stmt [3134,3208]
===
match
---
atom_expr [1576,1607]
atom_expr [1576,1607]
===
match
---
operator: , [41382,41383]
operator: , [41400,41401]
===
match
---
name: get [38505,38508]
name: get [38523,38526]
===
match
---
string: 'value' [49181,49188]
string: 'value' [49199,49206]
===
match
---
simple_stmt [24363,24480]
simple_stmt [24381,24498]
===
match
---
simple_stmt [25562,25607]
simple_stmt [25580,25625]
===
match
---
name: mock_client [42210,42221]
name: mock_client [42228,42239]
===
match
---
atom_expr [9568,9584]
atom_expr [9580,9596]
===
match
---
argument [49191,49204]
argument [49209,49222]
===
match
---
string: "builtins.open" [25992,26007]
string: "builtins.open" [26010,26025]
===
match
---
operator: = [4183,4184]
operator: = [4183,4184]
===
match
---
operator: @ [35263,35264]
operator: @ [35281,35282]
===
match
---
name: extra_dejson [27023,27035]
name: extra_dejson [27041,27053]
===
match
---
string: "vault_conn_id" [24643,24658]
string: "vault_conn_id" [24661,24676]
===
match
---
name: mock_connection [21855,21870]
name: mock_connection [21873,21888]
===
match
---
string: "wrong" [32764,32771]
string: "wrong" [32782,32789]
===
match
---
name: kwargs [43251,43257]
name: kwargs [43269,43275]
===
match
---
name: connection_dict [33493,33508]
name: connection_dict [33511,33526]
===
match
---
name: username [28544,28552]
name: username [28562,28570]
===
match
---
operator: = [16059,16060]
operator: = [16077,16078]
===
match
---
trailer [37849,37869]
trailer [37867,37887]
===
match
---
simple_stmt [18185,18237]
simple_stmt [18203,18255]
===
match
---
operator: , [43616,43617]
operator: , [43634,43635]
===
match
---
operator: , [34779,34780]
operator: , [34797,34798]
===
match
---
trailer [35911,35928]
trailer [35929,35946]
===
match
---
operator: = [41511,41512]
operator: = [41529,41530]
===
match
---
arglist [47078,47121]
arglist [47096,47139]
===
match
---
argument [26380,26396]
argument [26398,26414]
===
match
---
testlist_comp [19456,19483]
testlist_comp [19474,19501]
===
match
---
atom [20124,20144]
atom [20142,20162]
===
match
---
atom [2623,2631]
atom [2623,2631]
===
match
---
number: 2 [29789,29790]
number: 2 [29807,29808]
===
match
---
trailer [14815,14844]
trailer [14833,14862]
===
match
---
trailer [3776,3783]
trailer [3776,3783]
===
match
---
trailer [8570,8583]
trailer [8576,8589]
===
match
---
name: mock_connection [14482,14497]
name: mock_connection [14500,14515]
===
match
---
simple_stmt [9115,9193]
simple_stmt [9121,9205]
===
match
---
trailer [17919,17931]
trailer [17937,17949]
===
match
---
name: mock_client [47745,47756]
name: mock_client [47763,47774]
===
match
---
name: return_value [34428,34440]
name: return_value [34446,34458]
===
match
---
name: patch [27622,27627]
name: patch [27640,27645]
===
match
---
name: mock_client [8407,8418]
name: mock_client [8413,8424]
===
match
---
simple_stmt [40941,40972]
simple_stmt [40959,40990]
===
match
---
name: test_client [28381,28392]
name: test_client [28399,28410]
===
match
---
atom_expr [11454,11503]
atom_expr [11472,11521]
===
match
---
trailer [27318,27327]
trailer [27336,27345]
===
match
---
param [17325,17345]
param [17343,17363]
===
match
---
operator: = [44700,44701]
operator: = [44718,44719]
===
match
---
expr_stmt [1477,1537]
expr_stmt [1477,1537]
===
match
---
atom_expr [1506,1537]
atom_expr [1506,1537]
===
match
---
name: return_value [1519,1531]
name: return_value [1519,1531]
===
match
---
simple_stmt [25705,25772]
simple_stmt [25723,25790]
===
match
---
string: "auth_type" [45412,45423]
string: "auth_type" [45430,45441]
===
match
---
operator: } [5813,5814]
operator: } [5813,5814]
===
match
---
operator: ** [18060,18062]
operator: ** [18078,18080]
===
match
---
param [14089,14108]
param [14107,14126]
===
match
---
name: mock_connection [1773,1788]
name: mock_connection [1773,1788]
===
match
---
param [6200,6219]
param [6200,6219]
===
match
---
atom [43531,43984]
atom [43549,44002]
===
match
---
operator: , [22021,22022]
operator: , [22039,22040]
===
match
---
operator: , [49366,49367]
operator: , [49384,49385]
===
match
---
trailer [37052,37061]
trailer [37070,37079]
===
match
---
decorators [9317,9479]
decorators [9329,9491]
===
match
---
atom [2254,2308]
atom [2254,2308]
===
match
---
trailer [5891,5904]
trailer [5891,5904]
===
match
---
trailer [7917,7936]
trailer [7917,7936]
===
match
---
number: 2 [46992,46993]
number: 2 [47010,47011]
===
match
---
atom_expr [35703,35722]
atom_expr [35721,35740]
===
match
---
atom_expr [4810,4854]
atom_expr [4810,4854]
===
match
---
name: return_value [42171,42183]
name: return_value [42189,42201]
===
match
---
suite [31243,32188]
suite [31261,32206]
===
match
---
operator: = [33467,33468]
operator: = [33485,33486]
===
match
---
operator: = [47578,47579]
operator: = [47596,47597]
===
match
---
string: 'http://localhost:8180' [18425,18448]
string: 'http://localhost:8180' [18443,18466]
===
match
---
operator: , [10293,10294]
operator: , [10311,10312]
===
match
---
operator: } [46078,46079]
operator: } [46096,46097]
===
match
---
name: kv_engine_version [20437,20454]
name: kv_engine_version [20455,20472]
===
match
---
operator: @ [40587,40588]
operator: @ [40605,40606]
===
match
---
name: test_hook [32147,32156]
name: test_hook [32165,32174]
===
match
---
trailer [36219,36232]
trailer [36237,36250]
===
match
---
import_from [1027,1088]
import_from [1027,1088]
===
match
---
operator: = [11200,11201]
operator: = [11218,11219]
===
match
---
operator: , [30043,30044]
operator: , [30061,30062]
===
match
---
name: test_hook [4967,4976]
name: test_hook [4967,4976]
===
match
---
name: test_client [12337,12348]
name: test_client [12355,12366]
===
match
---
name: vault_client [10401,10413]
name: vault_client [10419,10431]
===
match
---
argument [47240,47258]
argument [47258,47276]
===
match
---
name: get [46859,46862]
name: get [46877,46880]
===
match
---
simple_stmt [48717,48768]
simple_stmt [48735,48786]
===
match
---
number: 1 [2646,2647]
number: 1 [2646,2647]
===
match
---
argument [15016,15036]
argument [15034,15054]
===
match
---
name: self [26726,26730]
name: self [26744,26748]
===
match
---
assert_stmt [29782,29834]
assert_stmt [29800,29852]
===
match
---
operator: , [36462,36463]
operator: , [36480,36481]
===
match
---
name: MagicMock [3747,3756]
name: MagicMock [3747,3756]
===
match
---
decorated [41853,44147]
decorated [41871,44165]
===
match
---
name: kwargs [32867,32873]
name: kwargs [32885,32891]
===
match
---
simple_stmt [31858,31893]
simple_stmt [31876,31911]
===
match
---
trailer [14692,14711]
trailer [14710,14729]
===
match
---
operator: = [34731,34732]
operator: = [34749,34750]
===
match
---
comparison [5014,5060]
comparison [5014,5060]
===
match
---
atom_expr [2141,2167]
atom_expr [2141,2167]
===
match
---
trailer [20423,20436]
trailer [20441,20454]
===
match
---
operator: } [8630,8631]
operator: } [8636,8637]
===
match
---
trailer [41461,41473]
trailer [41479,41491]
===
match
---
simple_stmt [36965,37021]
simple_stmt [36983,37039]
===
match
---
simple_stmt [45293,45360]
simple_stmt [45311,45378]
===
match
---
name: access_key [11361,11371]
name: access_key [11379,11389]
===
match
---
trailer [6770,6788]
trailer [6770,6788]
===
match
---
string: "userpass" [5622,5632]
string: "userpass" [5622,5632]
===
match
---
operator: = [11094,11095]
operator: = [11112,11113]
===
match
---
trailer [4194,4204]
trailer [4194,4204]
===
match
---
operator: , [37547,37548]
operator: , [37565,37566]
===
match
---
simple_stmt [2969,3013]
simple_stmt [2969,3013]
===
match
---
decorated [27616,28697]
decorated [27634,28715]
===
match
---
name: MagicMock [32459,32468]
name: MagicMock [32477,32486]
===
match
---
simple_stmt [21803,21847]
simple_stmt [21821,21865]
===
match
---
name: test_hook [18092,18101]
name: test_hook [18110,18119]
===
match
---
trailer [5035,5048]
trailer [5035,5048]
===
match
---
operator: , [17707,17708]
operator: , [17725,17726]
===
match
---
dotted_name [20545,20555]
dotted_name [20563,20573]
===
match
---
atom_expr [10055,10110]
atom_expr [10067,10122]
===
match
---
trailer [29654,29673]
trailer [29672,29691]
===
match
---
name: secret [38690,38696]
name: secret [38708,38714]
===
match
---
name: get_conn [21249,21257]
name: get_conn [21267,21275]
===
match
---
expr_stmt [35566,35616]
expr_stmt [35584,35634]
===
match
---
atom [29261,29391]
atom [29279,29409]
===
match
---
name: test_hook [12351,12360]
name: test_hook [12369,12378]
===
match
---
trailer [35718,35722]
trailer [35736,35740]
===
match
---
name: kwargs [29425,29431]
name: kwargs [29443,29449]
===
match
---
simple_stmt [16809,16859]
simple_stmt [16827,16877]
===
match
---
name: self [46614,46618]
name: self [46632,46636]
===
match
---
name: conn_type [1351,1360]
name: conn_type [1351,1360]
===
match
---
name: assert_called_with [20039,20057]
name: assert_called_with [20057,20075]
===
match
---
dictorsetmaker [5609,5662]
dictorsetmaker [5609,5662]
===
match
---
name: version [3199,3206]
name: version [3199,3206]
===
match
---
operator: = [14927,14928]
operator: = [14945,14946]
===
match
---
expr_stmt [3767,3810]
expr_stmt [3767,3810]
===
match
---
trailer [25076,25106]
trailer [25094,25124]
===
match
---
operator: @ [36340,36341]
operator: @ [36358,36359]
===
match
---
trailer [18110,18112]
trailer [18128,18130]
===
match
---
name: test_get_existing_key_v2_version [39126,39158]
name: test_get_existing_key_v2_version [39144,39176]
===
match
---
atom [49173,49189]
atom [49191,49207]
===
match
---
name: secret_id [8023,8032]
name: secret_id [8029,8038]
===
match
---
trailer [2195,2208]
trailer [2195,2208]
===
match
---
simple_stmt [38807,38951]
simple_stmt [38825,38969]
===
match
---
operator: = [1263,1264]
operator: = [1263,1264]
===
match
---
name: mock_hvac [7287,7296]
name: mock_hvac [7287,7296]
===
match
---
operator: = [49157,49158]
operator: = [49175,49176]
===
match
---
operator: = [8014,8015]
operator: = [8020,8021]
===
match
---
name: expected_version [3414,3430]
name: expected_version [3414,3430]
===
match
---
simple_stmt [20018,20155]
simple_stmt [20036,20173]
===
match
---
operator: = [35843,35844]
operator: = [35861,35862]
===
match
---
simple_stmt [6736,6789]
simple_stmt [6736,6789]
===
match
---
trailer [31307,31320]
trailer [31325,31338]
===
match
---
trailer [39462,39465]
trailer [39480,39483]
===
match
---
string: "role" [11067,11073]
string: "role" [11085,11091]
===
match
---
operator: = [8905,8906]
operator: = [8911,8912]
===
match
---
atom_expr [37741,37770]
atom_expr [37759,37788]
===
match
---
operator: , [2627,2628]
operator: , [2627,2628]
===
match
---
name: mock_hvac [2889,2898]
name: mock_hvac [2889,2898]
===
match
---
name: mock_client [3728,3739]
name: mock_client [3728,3739]
===
match
---
param [25424,25429]
param [25442,25447]
===
match
---
dotted_name [44237,44247]
dotted_name [44255,44265]
===
match
---
operator: = [15029,15030]
operator: = [15047,15048]
===
match
---
operator: = [46875,46876]
operator: = [46893,46894]
===
match
---
name: get_conn [37053,37061]
name: get_conn [37071,37079]
===
match
---
name: mock_connection [6409,6424]
name: mock_connection [6409,6424]
===
match
---
atom_expr [23319,23370]
atom_expr [23337,23388]
===
match
---
operator: = [47878,47879]
operator: = [47896,47897]
===
match
---
operator: , [39950,39951]
operator: , [39968,39969]
===
match
---
name: mock_get_connection [47615,47634]
name: mock_get_connection [47633,47652]
===
match
---
argument [46281,46301]
argument [46299,46319]
===
match
---
string: "user" [13708,13714]
string: "user" [13726,13732]
===
match
---
operator: , [9994,9995]
operator: , [10006,10007]
===
match
---
string: "custom" [5932,5940]
string: "custom" [5932,5940]
===
match
---
operator: @ [29924,29925]
operator: @ [29942,29943]
===
match
---
operator: = [12419,12420]
operator: = [12437,12438]
===
match
---
name: mock_client [5457,5468]
name: mock_client [5457,5468]
===
match
---
name: test_azure_dejson [14054,14071]
name: test_azure_dejson [14072,14089]
===
match
---
argument [3389,3397]
argument [3389,3397]
===
match
---
suite [34363,35174]
suite [34381,35192]
===
match
---
atom_expr [35566,35598]
atom_expr [35584,35616]
===
match
---
string: '2020-03-16T21:01:43.331126Z' [43587,43616]
string: '2020-03-16T21:01:43.331126Z' [43605,43634]
===
match
---
dotted_name [40588,40598]
dotted_name [40606,40616]
===
match
---
name: mock [15454,15458]
name: mock [15472,15476]
===
match
---
simple_stmt [20905,20926]
simple_stmt [20923,20944]
===
match
---
expr_stmt [11951,12001]
expr_stmt [11969,12019]
===
match
---
trailer [25057,25076]
trailer [25075,25094]
===
match
---
string: '' [45969,45971]
string: '' [45987,45989]
===
match
---
name: raises [2480,2486]
name: raises [2480,2486]
===
match
---
dictorsetmaker [37899,38456]
dictorsetmaker [37917,38474]
===
match
---
operator: } [41418,41419]
operator: } [41436,41437]
===
match
---
name: secret_path [45558,45569]
name: secret_path [45576,45587]
===
match
---
dotted_name [37433,37443]
dotted_name [37451,37461]
===
match
---
trailer [49233,49236]
trailer [49251,49254]
===
match
---
operator: = [45338,45339]
operator: = [45356,45357]
===
match
---
operator: , [38910,38911]
operator: , [38928,38929]
===
match
---
name: mock [12685,12689]
name: mock [12703,12707]
===
match
---
argument [29690,29703]
argument [29708,29721]
===
match
---
name: assert_called_with [24868,24886]
name: assert_called_with [24886,24904]
===
match
---
name: test_aws_iam_init_params [10607,10631]
name: test_aws_iam_init_params [10625,10649]
===
match
---
string: 'secret' [49313,49321]
string: 'secret' [49331,49339]
===
match
---
name: VaultHook [28289,28298]
name: VaultHook [28307,28316]
===
match
---
expr_stmt [37702,37732]
expr_stmt [37720,37750]
===
match
---
string: "scope1,scope2" [16245,16260]
string: "scope1,scope2" [16263,16278]
===
match
---
trailer [31890,31892]
trailer [31908,31910]
===
match
---
param [40782,40787]
param [40800,40805]
===
match
---
name: mock [11655,11659]
name: mock [11673,11677]
===
match
---
trailer [47204,47303]
trailer [47222,47321]
===
match
---
atom_expr [9911,9930]
atom_expr [9923,9942]
===
match
---
operator: , [13238,13239]
operator: , [13256,13257]
===
match
---
trailer [48824,48831]
trailer [48842,48849]
===
match
---
name: test_create_or_update_secret_v2 [46517,46548]
name: test_create_or_update_secret_v2 [46535,46566]
===
match
---
trailer [30219,30221]
trailer [30237,30239]
===
match
---
string: "auth_type" [21033,21044]
string: "auth_type" [21051,21062]
===
match
---
atom [13062,13064]
atom [13080,13082]
===
match
---
string: "vault_conn_id" [4912,4927]
string: "vault_conn_id" [4912,4927]
===
match
---
param [48606,48622]
param [48624,48640]
===
match
---
string: "credentials" [17694,17707]
string: "credentials" [17712,17725]
===
match
---
operator: = [28569,28570]
operator: = [28587,28588]
===
match
---
atom_expr [26076,26095]
atom_expr [26094,26113]
===
match
---
name: mock [6244,6248]
name: mock [6244,6248]
===
match
---
name: mock_client [36494,36505]
name: mock_client [36512,36523]
===
match
---
funcdef [26700,27611]
funcdef [26718,27629]
===
match
---
simple_stmt [44558,44602]
simple_stmt [44576,44620]
===
match
---
name: host [1430,1434]
name: host [1430,1434]
===
match
---
operator: , [27818,27819]
operator: , [27836,27837]
===
match
---
string: "userpass" [3166,3176]
string: "userpass" [3166,3176]
===
match
---
string: "radhost" [31538,31547]
string: "radhost" [31556,31565]
===
match
---
name: assert_called_with [12478,12496]
name: assert_called_with [12496,12514]
===
match
---
name: method [49368,49374]
name: method [49386,49392]
===
match
---
name: mock_hvac [3687,3696]
name: mock_hvac [3687,3696]
===
match
---
argument [38912,38926]
argument [38930,38944]
===
match
---
atom_expr [37824,37882]
atom_expr [37842,37900]
===
match
---
expr_stmt [28381,28415]
expr_stmt [28399,28433]
===
match
---
name: get [3246,3249]
name: get [3246,3249]
===
match
---
string: '94011e25-f8dc-ec29-221b-1f9c1d9ad2ae' [44730,44768]
string: '94011e25-f8dc-ec29-221b-1f9c1d9ad2ae' [44748,44786]
===
match
---
decorator [35179,35259]
decorator [35197,35277]
===
match
---
expr_stmt [41643,41695]
expr_stmt [41661,41713]
===
match
---
name: login [21365,21370]
name: login [21383,21388]
===
match
---
argument [32974,33010]
argument [32992,33028]
===
match
---
trailer [25194,25207]
trailer [25212,25225]
===
match
---
operator: = [37676,37677]
operator: = [37694,37695]
===
match
---
suite [39197,40582]
suite [39215,40600]
===
match
---
trailer [8425,8435]
trailer [8431,8441]
===
match
---
trailer [15929,15942]
trailer [15947,15960]
===
match
---
name: test_hook [24819,24828]
name: test_hook [24837,24846]
===
match
---
simple_stmt [14673,14729]
simple_stmt [14691,14747]
===
match
---
trailer [32105,32124]
trailer [32123,32142]
===
match
---
operator: = [4105,4106]
operator: = [4105,4106]
===
match
---
string: 'renewable' [42502,42513]
string: 'renewable' [42520,42531]
===
match
---
atom_expr [8119,8159]
atom_expr [8125,8165]
===
match
---
string: "auth_type" [38595,38606]
string: "auth_type" [38613,38624]
===
match
---
name: mock_connection [10770,10785]
name: mock_connection [10788,10803]
===
match
---
atom [49350,49366]
atom [49368,49384]
===
match
---
simple_stmt [30958,31011]
simple_stmt [30976,31029]
===
match
---
trailer [8916,8926]
trailer [8922,8932]
===
match
---
trailer [29632,29637]
trailer [29650,29655]
===
match
---
trailer [26131,26140]
trailer [26149,26158]
===
match
---
trailer [33537,33550]
trailer [33555,33568]
===
match
---
trailer [6757,6770]
trailer [6757,6770]
===
match
---
string: "tenant_id" [14928,14939]
string: "tenant_id" [14946,14957]
===
match
---
name: test_hook [19811,19820]
name: test_hook [19829,19838]
===
match
---
string: "kv_engine_version" [43194,43213]
string: "kv_engine_version" [43212,43231]
===
match
---
string: 'http://localhost:8180' [37112,37135]
string: 'http://localhost:8180' [37130,37153]
===
match
---
atom [2402,2459]
atom [2402,2459]
===
match
---
trailer [11940,11942]
trailer [11958,11960]
===
match
---
trailer [22074,22086]
trailer [22092,22104]
===
match
---
string: "role" [9167,9173]
string: "role" [9179,9185]
===
match
---
operator: = [26299,26300]
operator: = [26317,26318]
===
match
---
argument [18339,18366]
argument [18357,18384]
===
match
---
trailer [30979,30992]
trailer [30997,31010]
===
match
---
trailer [19184,19186]
trailer [19202,19204]
===
match
---
operator: } [40081,40082]
operator: } [40099,40100]
===
match
---
operator: , [15889,15890]
operator: , [15907,15908]
===
match
---
assert_stmt [37290,37342]
assert_stmt [37308,37360]
===
match
---
atom_expr [13492,13556]
atom_expr [13510,13574]
===
match
---
simple_stmt [49214,49401]
simple_stmt [49232,49419]
===
match
---
trailer [11862,11875]
trailer [11880,11893]
===
match
---
name: connection_dict [40139,40154]
name: connection_dict [40157,40172]
===
match
---
name: get_mock_connection [29057,29076]
name: get_mock_connection [29075,29094]
===
match
---
operator: = [20202,20203]
operator: = [20220,20221]
===
match
---
name: kwargs [4098,4104]
name: kwargs [4098,4104]
===
match
---
expr_stmt [13345,13376]
expr_stmt [13363,13394]
===
match
---
dotted_name [28703,28713]
dotted_name [28721,28731]
===
match
---
decorator [36340,36418]
decorator [36358,36436]
===
match
---
atom_expr [16014,16058]
atom_expr [16032,16076]
===
match
---
operator: , [48359,48360]
operator: , [48377,48378]
===
match
---
trailer [49236,49239]
trailer [49254,49257]
===
match
---
trailer [12369,12371]
trailer [12387,12389]
===
match
---
operator: , [39835,39836]
operator: , [39853,39854]
===
match
---
name: mock_connection [20792,20807]
name: mock_connection [20810,20825]
===
match
---
dictorsetmaker [9790,9844]
dictorsetmaker [9802,9856]
===
match
---
string: 'key' [48072,48077]
string: 'key' [48090,48095]
===
match
---
name: VaultHook [23409,23418]
name: VaultHook [23427,23436]
===
match
---
name: self [3837,3841]
name: self [3837,3841]
===
match
---
name: mock_client [17394,17405]
name: mock_client [17412,17423]
===
match
---
trailer [11465,11482]
trailer [11483,11500]
===
match
---
expr_stmt [38690,38742]
expr_stmt [38708,38760]
===
match
---
trailer [22070,22074]
trailer [22088,22092]
===
match
---
dictorsetmaker [21033,21101]
dictorsetmaker [21051,21119]
===
match
---
operator: = [10899,10900]
operator: = [10917,10918]
===
match
---
param [47521,47531]
param [47539,47549]
===
match
---
atom_expr [35436,35452]
atom_expr [35454,35470]
===
match
---
atom_expr [40315,40376]
atom_expr [40333,40394]
===
match
---
string: "vault_conn_id" [35758,35773]
string: "vault_conn_id" [35776,35791]
===
match
---
trailer [19973,19992]
trailer [19991,20010]
===
match
---
trailer [23142,23146]
trailer [23160,23164]
===
match
---
with_stmt [23314,23476]
with_stmt [23332,23494]
===
match
---
string: 'lease_id' [37965,37975]
string: 'lease_id' [37983,37993]
===
match
---
suite [23384,23476]
suite [23402,23494]
===
match
---
name: test_hook [47970,47979]
name: test_hook [47988,47997]
===
match
---
trailer [25041,25057]
trailer [25059,25075]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [44248,44312]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [44266,44330]
===
match
---
decorator [22684,22762]
decorator [22702,22780]
===
match
---
comparison [29789,29834]
comparison [29807,29852]
===
match
---
trailer [3043,3063]
trailer [3043,3063]
===
match
---
name: secret [49166,49172]
name: secret [49184,49190]
===
match
---
operator: , [42055,42056]
operator: , [42073,42074]
===
match
---
trailer [36542,36549]
trailer [36560,36567]
===
match
---
operator: == [29791,29793]
operator: == [29809,29811]
===
match
---
trailer [3245,3249]
trailer [3245,3249]
===
match
---
operator: = [3868,3869]
operator: = [3868,3869]
===
match
---
name: patch [12690,12695]
name: patch [12708,12713]
===
match
---
operator: , [34628,34629]
operator: , [34646,34647]
===
match
---
name: get [47825,47828]
name: get [47843,47846]
===
match
---
string: "token" [49030,49037]
string: "token" [49048,49055]
===
match
---
trailer [19874,19883]
trailer [19892,19901]
===
match
---
name: Client [25520,25526]
name: Client [25538,25544]
===
match
---
name: mock_file [23374,23383]
name: mock_file [23392,23401]
===
match
---
name: Client [40990,40996]
name: Client [41008,41014]
===
match
---
name: mock_get_connection [28317,28336]
name: mock_get_connection [28335,28354]
===
match
---
name: kv_engine_version [28679,28696]
name: kv_engine_version [28697,28714]
===
match
---
name: side_effect [2351,2362]
name: side_effect [2351,2362]
===
match
---
name: mock_hvac [32399,32408]
name: mock_hvac [32417,32426]
===
match
---
name: assert_called_with [24922,24940]
name: assert_called_with [24940,24958]
===
match
---
trailer [1588,1607]
trailer [1588,1607]
===
match
---
operator: , [15564,15565]
operator: , [15582,15583]
===
match
---
operator: = [41010,41011]
operator: = [41028,41029]
===
match
---
trailer [35688,35700]
trailer [35706,35718]
===
match
---
simple_stmt [10913,10980]
simple_stmt [10931,10998]
===
match
---
operator: = [21017,21018]
operator: = [21035,21036]
===
match
---
simple_stmt [32792,32859]
simple_stmt [32810,32877]
===
match
---
name: connection_dict [4734,4749]
name: connection_dict [4734,4749]
===
match
---
name: return_value [25527,25539]
name: return_value [25545,25557]
===
match
---
operator: = [11371,11372]
operator: = [11389,11390]
===
match
---
operator: = [45375,45376]
operator: = [45393,45394]
===
match
---
name: url [30760,30763]
name: url [30778,30781]
===
match
---
name: mock_connection [21943,21958]
name: mock_connection [21961,21976]
===
match
---
trailer [26295,26324]
trailer [26313,26342]
===
match
---
trailer [27327,27329]
trailer [27345,27347]
===
match
---
simple_stmt [28644,28697]
simple_stmt [28662,28715]
===
match
---
name: kwargs [38674,38680]
name: kwargs [38692,38698]
===
match
---
atom_expr [11096,11115]
atom_expr [11114,11133]
===
match
---
expr_stmt [34649,34715]
expr_stmt [34667,34733]
===
match
---
simple_stmt [23713,23790]
simple_stmt [23731,23808]
===
match
---
name: secret [47098,47104]
name: secret [47116,47122]
===
match
---
expr_stmt [17597,17648]
expr_stmt [17615,17666]
===
match
---
name: test_gcp_dict_dejson [19049,19069]
name: test_gcp_dict_dejson [19067,19087]
===
match
---
dictorsetmaker [8739,8875]
dictorsetmaker [8745,8881]
===
match
---
operator: } [39429,39430]
operator: } [39447,39448]
===
match
---
trailer [11328,11347]
trailer [11346,11365]
===
match
---
operator: { [25789,25790]
operator: { [25807,25808]
===
match
---
string: 'secret' [47230,47238]
string: 'secret' [47248,47256]
===
match
---
name: vault_client [21492,21504]
name: vault_client [21510,21522]
===
match
---
assert_stmt [43339,44007]
assert_stmt [43357,44025]
===
match
---
name: return_value [35478,35490]
name: return_value [35496,35508]
===
match
---
name: side_effect [24522,24533]
name: side_effect [24540,24551]
===
match
---
trailer [26801,26803]
trailer [26819,26821]
===
match
---
name: secret [41733,41739]
name: secret [41751,41757]
===
match
---
atom_expr [49084,49103]
atom_expr [49102,49121]
===
match
---
name: github [21358,21364]
name: github [21376,21382]
===
match
---
name: secret_path [43308,43319]
name: secret_path [43326,43337]
===
match
---
name: mock_hvac [21723,21732]
name: mock_hvac [21741,21750]
===
match
---
name: get_mock_connection [1148,1167]
name: get_mock_connection [1148,1167]
===
match
---
string: "pass" [32050,32056]
string: "pass" [32068,32074]
===
match
---
dictorsetmaker [44901,45171]
dictorsetmaker [44919,45189]
===
match
---
name: mock_get_credentials [19108,19128]
name: mock_get_credentials [19126,19146]
===
match
---
simple_stmt [12011,12073]
simple_stmt [12029,12091]
===
match
---
operator: @ [27616,27617]
operator: @ [27634,27635]
===
match
---
simple_stmt [27411,27492]
simple_stmt [27429,27510]
===
match
---
dictorsetmaker [47881,47959]
dictorsetmaker [47899,47977]
===
match
---
simple_stmt [25173,25226]
simple_stmt [25191,25244]
===
match
---
param [34342,34361]
param [34360,34379]
===
match
---
atom_expr [10027,10046]
atom_expr [10039,10058]
===
match
---
operator: = [12027,12028]
operator: = [12045,12046]
===
match
---
operator: , [45077,45078]
operator: , [45095,45096]
===
match
---
string: "auth_type" [22000,22011]
string: "auth_type" [22018,22029]
===
match
---
atom [37885,38466]
atom [37903,38484]
===
match
---
name: return_value [36658,36670]
name: return_value [36676,36688]
===
match
---
operator: = [23023,23024]
operator: = [23041,23042]
===
match
---
trailer [26936,26949]
trailer [26954,26967]
===
match
---
name: jwt [26398,26401]
name: jwt [26416,26419]
===
match
---
trailer [31415,31428]
trailer [31433,31446]
===
match
---
simple_stmt [40266,40298]
simple_stmt [40284,40316]
===
match
---
name: auth_aws_iam [12465,12477]
name: auth_aws_iam [12483,12495]
===
match
---
decorated [47309,48276]
decorated [47327,48294]
===
match
---
operator: , [38429,38430]
operator: , [38447,38448]
===
match
---
trailer [16462,16479]
trailer [16480,16497]
===
match
---
operator: = [32452,32453]
operator: = [32470,32471]
===
match
---
simple_stmt [35656,35723]
simple_stmt [35674,35741]
===
match
---
expr_stmt [24159,24189]
expr_stmt [24177,24207]
===
match
---
name: is_authenticated [23810,23826]
name: is_authenticated [23828,23844]
===
match
---
arglist [20299,20325]
arglist [20317,20343]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [10533,10597]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [10551,10615]
===
match
---
trailer [44537,44547]
trailer [44555,44565]
===
match
---
atom_expr [32479,32508]
atom_expr [32497,32526]
===
match
---
simple_stmt [34724,34791]
simple_stmt [34742,34809]
===
match
---
param [35381,35391]
param [35399,35409]
===
match
---
name: mock_hvac [15566,15575]
name: mock_hvac [15584,15593]
===
match
---
simple_stmt [26977,26998]
simple_stmt [26995,27016]
===
match
---
name: connection_dict [2236,2251]
name: connection_dict [2236,2251]
===
match
---
operator: = [21237,21238]
operator: = [21255,21256]
===
match
---
trailer [31280,31282]
trailer [31298,31300]
===
match
---
atom [47880,47960]
atom [47898,47978]
===
match
---
dictorsetmaker [14580,14613]
dictorsetmaker [14598,14631]
===
match
---
name: mock_get_connection [12984,13003]
name: mock_get_connection [13002,13021]
===
match
---
argument [16582,16609]
argument [16600,16627]
===
match
---
name: kwargs [16305,16311]
name: kwargs [16323,16329]
===
match
---
string: "vault_conn_id" [14597,14612]
string: "vault_conn_id" [14615,14630]
===
match
---
string: "ldap" [28099,28105]
string: "ldap" [28117,28123]
===
match
---
string: "vault_conn_id" [45395,45410]
string: "vault_conn_id" [45413,45428]
===
match
---
argument [26019,26035]
argument [26037,26053]
===
match
---
expr_stmt [25780,25972]
expr_stmt [25798,25990]
===
match
---
name: mock_connection [17485,17500]
name: mock_connection [17503,17518]
===
match
---
name: token [34003,34008]
name: token [34021,34026]
===
match
---
name: kv_engine_version [21505,21522]
name: kv_engine_version [21523,21540]
===
match
---
operator: } [48256,48257]
operator: } [48274,48275]
===
match
---
atom [28072,28116]
atom [28090,28134]
===
match
---
name: mock_hvac [11231,11240]
name: mock_hvac [11249,11258]
===
match
---
expr_stmt [15984,16004]
expr_stmt [16002,16022]
===
match
---
name: get [9927,9930]
name: get [9939,9942]
===
match
---
name: secret_path [38720,38731]
name: secret_path [38738,38749]
===
match
---
param [27809,27819]
param [27827,27837]
===
match
---
operator: = [7317,7318]
operator: = [7317,7318]
===
match
---
name: Client [36543,36549]
name: Client [36561,36567]
===
match
---
name: mock [21529,21533]
name: mock [21547,21551]
===
match
---
operator: == [20411,20413]
operator: == [20429,20431]
===
match
---
argument [20071,20084]
argument [20089,20102]
===
match
---
string: 'path' [48226,48232]
string: 'path' [48244,48250]
===
match
---
atom [33606,33686]
atom [33624,33704]
===
match
---
operator: = [16588,16589]
operator: = [16606,16607]
===
match
---
simple_stmt [39206,39251]
simple_stmt [39224,39269]
===
match
---
operator: = [4707,4708]
operator: = [4707,4708]
===
match
---
operator: = [27862,27863]
operator: = [27880,27881]
===
match
---
name: auth_kubernetes [23725,23740]
name: auth_kubernetes [23743,23758]
===
match
---
name: get [40121,40124]
name: get [40139,40142]
===
match
---
name: mock_get_connection [27994,28013]
name: mock_get_connection [28012,28031]
===
match
---
name: patch [1884,1889]
name: patch [1884,1889]
===
match
---
expr_stmt [6510,6576]
expr_stmt [6510,6576]
===
match
---
string: '2020-03-16T21:01:43.331126Z' [45007,45036]
string: '2020-03-16T21:01:43.331126Z' [45025,45054]
===
match
---
expr_stmt [27941,27985]
expr_stmt [27959,28003]
===
match
---
number: 2 [38638,38639]
number: 2 [38656,38657]
===
match
---
trailer [3443,3456]
trailer [3443,3456]
===
match
---
param [24118,24128]
param [24136,24146]
===
match
---
expr_stmt [29147,29167]
expr_stmt [29165,29185]
===
match
---
trailer [45355,45359]
trailer [45373,45377]
===
match
---
string: "gcp_keyfile_dict" [19558,19576]
string: "gcp_keyfile_dict" [19576,19594]
===
match
---
name: mock [44153,44157]
name: mock [44171,44175]
===
match
---
simple_stmt [26215,26252]
simple_stmt [26233,26270]
===
match
---
trailer [48130,48154]
trailer [48148,48172]
===
match
---
name: side_effect [17920,17931]
name: side_effect [17938,17949]
===
match
---
name: mock [9568,9572]
name: mock [9580,9584]
===
match
---
dotted_name [22601,22611]
dotted_name [22619,22629]
===
match
---
suite [9545,10432]
suite [9557,10450]
===
match
---
name: client_secret [13728,13741]
name: client_secret [13746,13759]
===
match
---
name: assert_called_with [16384,16402]
name: assert_called_with [16402,16420]
===
match
---
name: secrets [48117,48124]
name: secrets [48135,48142]
===
match
---
operator: = [9011,9012]
operator: = [9017,9018]
===
match
---
simple_stmt [12380,12445]
simple_stmt [12398,12463]
===
match
---
trailer [4051,4055]
trailer [4051,4055]
===
match
---
name: test_client [22484,22495]
name: test_client [22502,22513]
===
match
---
expr_stmt [3134,3207]
expr_stmt [3134,3207]
===
match
---
name: Client [28434,28440]
name: Client [28452,28458]
===
match
---
atom_expr [1329,1360]
atom_expr [1329,1360]
===
match
---
simple_stmt [13826,13879]
simple_stmt [13844,13897]
===
match
---
operator: } [47120,47121]
operator: } [47138,47139]
===
match
---
operator: , [48212,48213]
operator: , [48230,48231]
===
match
---
trailer [10368,10370]
trailer [10386,10388]
===
match
---
name: is_authenticated [18578,18594]
name: is_authenticated [18596,18612]
===
match
---
atom_expr [24536,24555]
atom_expr [24554,24573]
===
match
---
trailer [18478,18488]
trailer [18496,18506]
===
match
---
name: vault_client [32157,32169]
name: vault_client [32175,32187]
===
match
---
name: ldap [27428,27432]
name: ldap [27446,27450]
===
match
---
name: test_client [27411,27422]
name: test_client [27429,27440]
===
match
---
trailer [21440,21459]
trailer [21458,21477]
===
match
---
trailer [17527,17529]
trailer [17545,17547]
===
match
---
simple_stmt [36698,36765]
simple_stmt [36716,36783]
===
match
---
name: assert_called_with [8078,8096]
name: assert_called_with [8084,8102]
===
match
---
name: patch [34227,34232]
name: patch [34245,34250]
===
match
---
dotted_name [10438,10448]
dotted_name [10456,10466]
===
match
---
simple_stmt [15056,15106]
simple_stmt [15074,15124]
===
match
---
simple_stmt [32584,32635]
simple_stmt [32602,32653]
===
match
---
atom_expr [31361,31387]
atom_expr [31379,31405]
===
match
---
name: mock_hvac [20660,20669]
name: mock_hvac [20678,20687]
===
match
---
argument [30881,30890]
argument [30899,30908]
===
match
---
name: mock_get_connection [12810,12829]
name: mock_get_connection [12828,12847]
===
match
---
trailer [29106,29119]
trailer [29124,29137]
===
match
---
operator: } [23303,23304]
operator: } [23321,23322]
===
match
---
trailer [13860,13878]
trailer [13878,13896]
===
match
---
operator: , [43192,43193]
operator: , [43210,43211]
===
match
---
argument [14816,14843]
argument [14834,14861]
===
match
---
string: 'http://localhost:8180' [20203,20226]
string: 'http://localhost:8180' [20221,20244]
===
match
---
name: test_client [14853,14864]
name: test_client [14871,14882]
===
match
---
name: kv_engine_version [34052,34069]
name: kv_engine_version [34070,34087]
===
match
---
name: Client [37751,37757]
name: Client [37769,37775]
===
match
---
operator: = [44126,44127]
operator: = [44144,44145]
===
match
---
simple_stmt [2930,2961]
simple_stmt [2930,2961]
===
match
---
operator: @ [41937,41938]
operator: @ [41955,41956]
===
match
---
trailer [7832,7849]
trailer [7832,7849]
===
match
---
dotted_name [29925,29935]
dotted_name [29943,29953]
===
match
---
name: assert_called_once_with [46244,46267]
name: assert_called_once_with [46262,46285]
===
match
---
name: VaultHook [18050,18059]
name: VaultHook [18068,18077]
===
match
---
name: VaultHook [30589,30598]
name: VaultHook [30607,30616]
===
match
---
atom_expr [31766,31785]
atom_expr [31784,31803]
===
match
---
argument [24993,25020]
argument [25011,25038]
===
match
---
name: VaultHook [6708,6717]
name: VaultHook [6708,6717]
===
match
---
name: VaultHook [16293,16302]
name: VaultHook [16311,16320]
===
match
---
atom_expr [40092,40136]
atom_expr [40110,40154]
===
match
---
string: "vault_conn_id" [12180,12195]
string: "vault_conn_id" [12198,12213]
===
match
---
operator: } [26996,26997]
operator: } [27014,27015]
===
match
---
atom_expr [13463,13483]
atom_expr [13481,13501]
===
match
---
string: "kv_engine_version" [3178,3197]
string: "kv_engine_version" [3178,3197]
===
match
---
name: kwargs [47994,48000]
name: kwargs [48012,48018]
===
match
---
atom_expr [26418,26467]
atom_expr [26436,26485]
===
match
---
name: kv_engine_version [3457,3474]
name: kv_engine_version [3457,3474]
===
match
---
name: auth_kubernetes [25042,25057]
name: auth_kubernetes [25060,25075]
===
match
---
name: test_version_one_dejson [6159,6182]
name: test_version_one_dejson [6159,6182]
===
match
---
atom_expr [32792,32836]
atom_expr [32810,32854]
===
match
---
atom_expr [36965,37020]
atom_expr [36983,37038]
===
match
---
operator: } [37813,37814]
operator: } [37831,37832]
===
match
---
name: mock_hvac [4569,4578]
name: mock_hvac [4569,4578]
===
match
---
operator: = [7545,7546]
operator: = [7545,7546]
===
match
---
param [20671,20690]
param [20689,20708]
===
match
---
trailer [16353,16355]
trailer [16371,16373]
===
match
---
simple_stmt [35833,35865]
simple_stmt [35851,35883]
===
match
---
name: patch [28708,28713]
name: patch [28726,28731]
===
match
---
name: auth [14865,14869]
name: auth [14883,14887]
===
match
---
operator: , [19085,19086]
operator: , [19103,19104]
===
match
---
name: mock_get_connection [26917,26936]
name: mock_get_connection [26935,26954]
===
match
---
operator: { [45377,45378]
operator: { [45395,45396]
===
match
---
string: 'destroyed' [45099,45110]
string: 'destroyed' [45117,45128]
===
match
---
operator: = [47686,47687]
operator: = [47704,47705]
===
match
---
operator: = [25540,25541]
operator: = [25558,25559]
===
match
---
funcdef [40753,41848]
funcdef [40771,41866]
===
match
---
trailer [20372,20391]
trailer [20390,20409]
===
match
---
comparison [11519,11564]
comparison [11537,11582]
===
match
---
funcdef [28868,29835]
funcdef [28886,29853]
===
match
---
atom_expr [33434,33466]
atom_expr [33452,33484]
===
match
---
atom_expr [12129,12148]
atom_expr [12147,12166]
===
match
---
name: kwargs [43128,43134]
name: kwargs [43146,43152]
===
match
---
name: get [4086,4089]
name: get [4086,4089]
===
match
---
name: test_hook [18636,18645]
name: test_hook [18654,18663]
===
match
---
operator: { [38560,38561]
operator: { [38578,38579]
===
match
---
name: test_hook [24761,24770]
name: test_hook [24779,24788]
===
match
---
name: side_effect [47829,47840]
name: side_effect [47847,47858]
===
match
---
return_stmt [1766,1788]
return_stmt [1766,1788]
===
match
---
expr_stmt [23080,23146]
expr_stmt [23098,23164]
===
match
---
atom_expr [35656,35700]
atom_expr [35674,35718]
===
match
---
operator: @ [6993,6994]
operator: @ [6993,6994]
===
match
---
name: mock_get_connection [8551,8570]
name: mock_get_connection [8557,8576]
===
match
---
name: get [19689,19692]
name: get [19707,19710]
===
match
---
atom_expr [34840,34895]
atom_expr [34858,34913]
===
match
---
expr_stmt [33434,33484]
expr_stmt [33452,33502]
===
match
---
name: Client [48825,48831]
name: Client [48843,48849]
===
match
---
name: get_conn [9023,9031]
name: get_conn [9029,9037]
===
match
---
operator: { [42597,42598]
operator: { [42615,42616]
===
match
---
name: mock_connection [15825,15840]
name: mock_connection [15843,15858]
===
match
---
operator: , [8807,8808]
operator: , [8813,8814]
===
match
---
name: side_effect [31636,31647]
name: side_effect [31654,31665]
===
match
---
operator: = [3835,3836]
operator: = [3835,3836]
===
match
---
name: assert_called_with [19974,19992]
name: assert_called_with [19992,20010]
===
match
---
simple_stmt [21908,21959]
simple_stmt [21926,21977]
===
match
---
atom_expr [33708,33727]
atom_expr [33726,33745]
===
match
---
trailer [36836,36840]
trailer [36854,36858]
===
match
---
trailer [27963,27983]
trailer [27981,28001]
===
match
---
trailer [4693,4706]
trailer [4693,4706]
===
match
---
atom_expr [33736,33791]
atom_expr [33754,33809]
===
match
---
operator: , [31509,31510]
operator: , [31527,31528]
===
match
---
operator: , [10647,10648]
operator: , [10665,10666]
===
match
---
name: create_or_update_secret [49240,49263]
name: create_or_update_secret [49258,49281]
===
match
---
atom_expr [21239,21259]
atom_expr [21257,21277]
===
match
---
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [26546,26612]
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [26564,26630]
===
match
---
operator: @ [15172,15173]
operator: @ [15190,15191]
===
match
---
string: "role" [11428,11434]
string: "role" [11446,11452]
===
match
---
name: test_client [13565,13576]
name: test_client [13583,13594]
===
match
---
atom_expr [48105,48275]
atom_expr [48123,48293]
===
match
---
operator: { [49173,49174]
operator: { [49191,49192]
===
match
---
simple_stmt [2123,2168]
simple_stmt [2123,2168]
===
match
---
operator: = [1531,1532]
operator: = [1531,1532]
===
match
---
trailer [33345,33358]
trailer [33363,33376]
===
match
---
name: mock_connection [13074,13089]
name: mock_connection [13092,13107]
===
match
---
trailer [34821,34831]
trailer [34839,34849]
===
match
---
expr_stmt [4098,4164]
expr_stmt [4098,4164]
===
match
---
name: mock [26535,26539]
name: mock [26553,26557]
===
match
---
operator: = [40373,40374]
operator: = [40391,40392]
===
match
---
name: mock_connection [29177,29192]
name: mock_connection [29195,29210]
===
match
---
operator: = [23407,23408]
operator: = [23425,23426]
===
match
---
name: Client [34957,34963]
name: Client [34975,34981]
===
match
---
name: get [41492,41495]
name: get [41510,41513]
===
match
---
atom_expr [7794,7849]
atom_expr [7794,7849]
===
match
---
expr_stmt [35513,35557]
expr_stmt [35531,35575]
===
match
---
expr_stmt [22990,23040]
expr_stmt [23008,23058]
===
match
---
simple_stmt [13345,13377]
simple_stmt [13363,13395]
===
match
---
operator: = [48943,48944]
operator: = [48961,48962]
===
match
---
simple_stmt [8716,8886]
simple_stmt [8722,8892]
===
match
---
simple_stmt [21412,21462]
simple_stmt [21430,21480]
===
match
---
trailer [35960,35969]
trailer [35978,35987]
===
match
---
assert_stmt [30958,31010]
assert_stmt [30976,31028]
===
match
---
operator: , [43657,43658]
operator: , [43675,43676]
===
match
---
operator: = [15823,15824]
operator: = [15841,15842]
===
match
---
simple_stmt [15790,15841]
simple_stmt [15808,15859]
===
match
---
argument [11423,11434]
argument [11441,11452]
===
match
---
name: mock_file [24738,24747]
name: mock_file [24756,24765]
===
match
---
param [12810,12829]
param [12828,12847]
===
match
---
name: self [6183,6187]
name: self [6183,6187]
===
match
---
name: get [8670,8673]
name: get [8676,8679]
===
match
---
operator: = [25787,25788]
operator: = [25805,25806]
===
match
---
decorator [28702,28782]
decorator [28720,28800]
===
match
---
name: mock_hvac [29548,29557]
name: mock_hvac [29566,29575]
===
match
---
operator: ** [12255,12257]
operator: ** [12273,12275]
===
match
---
name: self [10788,10792]
name: self [10806,10810]
===
match
---
name: extra_dejson [14498,14510]
name: extra_dejson [14516,14528]
===
match
---
param [26743,26762]
param [26761,26780]
===
match
---
name: assert_called_with [30831,30849]
name: assert_called_with [30849,30867]
===
match
---
operator: = [27307,27308]
operator: = [27325,27326]
===
match
---
name: get [30383,30386]
name: get [30401,30404]
===
match
---
name: mock [48391,48395]
name: mock [48409,48413]
===
match
---
atom_expr [10960,10979]
atom_expr [10978,10997]
===
match
---
name: self [33399,33403]
name: self [33417,33421]
===
match
---
name: assert_called_with [15085,15103]
name: assert_called_with [15103,15121]
===
match
---
trailer [29528,29537]
trailer [29546,29555]
===
match
---
atom_expr [12854,12870]
atom_expr [12872,12888]
===
match
---
dotted_name [48391,48401]
dotted_name [48409,48419]
===
match
---
operator: = [49082,49083]
operator: = [49100,49101]
===
match
---
string: 'user' [11372,11378]
string: 'user' [11390,11396]
===
match
---
name: kwargs [31678,31684]
name: kwargs [31696,31702]
===
match
---
trailer [27432,27438]
trailer [27450,27456]
===
match
---
trailer [27511,27528]
trailer [27529,27546]
===
match
---
expr_stmt [40829,40873]
expr_stmt [40847,40891]
===
match
---
name: get [25734,25737]
name: get [25752,25755]
===
match
---
dotted_name [9402,9412]
dotted_name [9414,9424]
===
match
---
simple_stmt [15646,15677]
simple_stmt [15664,15695]
===
match
---
argument [18421,18448]
argument [18439,18466]
===
match
---
string: 'deletion_time' [42905,42920]
string: 'deletion_time' [42923,42938]
===
match
---
simple_stmt [35461,35505]
simple_stmt [35479,35523]
===
match
---
simple_stmt [14780,14845]
simple_stmt [14798,14863]
===
match
---
trailer [23108,23112]
trailer [23126,23130]
===
match
---
atom_expr [48898,48942]
atom_expr [48916,48960]
===
match
---
name: self [24112,24116]
name: self [24130,24134]
===
match
---
name: Client [15695,15701]
name: Client [15713,15719]
===
match
---
trailer [20252,20256]
trailer [20270,20274]
===
match
---
name: assert_called_with [37089,37107]
name: assert_called_with [37107,37125]
===
match
---
decorator [40671,40749]
decorator [40689,40767]
===
match
---
operator: = [36019,36020]
operator: = [36037,36038]
===
match
---
simple_stmt [9593,9637]
simple_stmt [9605,9649]
===
match
---
operator: = [48884,48885]
operator: = [48902,48903]
===
match
---
name: patch [25321,25326]
name: patch [25339,25344]
===
match
---
operator: = [40569,40570]
operator: = [40587,40588]
===
match
---
atom_expr [10321,10370]
atom_expr [10339,10388]
===
match
---
operator: , [39174,39175]
operator: , [39192,39193]
===
match
---
trailer [41457,41461]
trailer [41475,41479]
===
match
---
operator: { [22126,22127]
operator: { [22144,22145]
===
match
---
name: connection_dict [19494,19509]
name: connection_dict [19512,19527]
===
match
---
operator: , [40209,40210]
operator: , [40227,40228]
===
match
---
assert_stmt [22542,22594]
assert_stmt [22560,22612]
===
match
---
funcdef [46513,47304]
funcdef [46531,47322]
===
match
---
name: test_hook [47044,47053]
name: test_hook [47062,47071]
===
match
---
simple_stmt [12233,12265]
simple_stmt [12251,12283]
===
match
---
name: test_hook [25185,25194]
name: test_hook [25203,25212]
===
match
---
atom_expr [36638,36670]
atom_expr [36656,36688]
===
match
---
operator: , [38593,38594]
operator: , [38611,38612]
===
match
---
simple_stmt [18458,18558]
simple_stmt [18476,18576]
===
match
---
operator: = [30854,30855]
operator: = [30872,30873]
===
match
---
argument [12510,12527]
argument [12528,12545]
===
match
---
expr_stmt [34800,34831]
expr_stmt [34818,34849]
===
match
---
atom_expr [17433,17462]
atom_expr [17451,17480]
===
match
---
name: self [44425,44429]
name: self [44443,44447]
===
match
---
operator: , [18337,18338]
operator: , [18355,18356]
===
match
---
expr_stmt [41504,41593]
expr_stmt [41522,41611]
===
match
---
simple_stmt [15909,15975]
simple_stmt [15927,15993]
===
match
---
trailer [33823,33832]
trailer [33841,33850]
===
match
---
name: v1 [49237,49239]
name: v1 [49255,49257]
===
match
---
string: "approle" [9803,9812]
string: "approle" [9815,9824]
===
match
---
string: "auth_type" [17764,17775]
string: "auth_type" [17782,17793]
===
match
---
string: "auth_type" [8785,8796]
string: "auth_type" [8791,8802]
===
match
---
name: connection_dict [20982,20997]
name: connection_dict [21000,21015]
===
match
---
param [24129,24148]
param [24147,24166]
===
match
---
trailer [26821,26828]
trailer [26839,26846]
===
match
---
trailer [9892,9896]
trailer [9904,9908]
===
match
---
operator: = [29709,29710]
operator: = [29727,29728]
===
match
---
name: test_client [10235,10246]
name: test_client [10247,10258]
===
match
---
atom_expr [30589,30608]
atom_expr [30607,30626]
===
match
---
expr_stmt [10718,10761]
expr_stmt [10736,10779]
===
match
---
operator: = [12520,12521]
operator: = [12538,12539]
===
match
---
arglist [49301,49390]
arglist [49319,49408]
===
match
---
operator: = [7870,7871]
operator: = [7870,7871]
===
match
---
trailer [5434,5441]
trailer [5434,5441]
===
match
---
operator: = [11270,11271]
operator: = [11288,11289]
===
match
---
name: VaultHook [10027,10036]
name: VaultHook [10039,10048]
===
match
---
string: '2020-03-16T21:01:43.331126Z' [42854,42883]
string: '2020-03-16T21:01:43.331126Z' [42872,42901]
===
match
---
trailer [13003,13016]
trailer [13021,13034]
===
match
---
name: PropertyMock [901,913]
name: PropertyMock [901,913]
===
match
---
decorated [48281,49401]
decorated [48299,49419]
===
match
---
trailer [19932,19949]
trailer [19950,19967]
===
match
---
operator: == [34026,34028]
operator: == [34044,34046]
===
match
---
simple_stmt [34649,34716]
simple_stmt [34667,34734]
===
match
---
name: mock_connection [10913,10928]
name: mock_connection [10931,10946]
===
match
---
name: patch [2679,2684]
name: patch [2679,2684]
===
match
---
simple_stmt [4967,4999]
simple_stmt [4967,4999]
===
match
---
expr_stmt [40941,40971]
expr_stmt [40959,40989]
===
match
---
operator: { [23068,23069]
operator: { [23086,23087]
===
match
---
operator: , [42779,42780]
operator: , [42797,42798]
===
match
---
trailer [5688,5701]
trailer [5688,5701]
===
match
---
operator: = [3797,3798]
operator: = [3797,3798]
===
match
---
argument [37207,37222]
argument [37225,37240]
===
match
---
atom_expr [47615,47647]
atom_expr [47633,47665]
===
match
---
simple_stmt [5477,5522]
simple_stmt [5477,5522]
===
match
---
atom [38152,38353]
atom [38170,38371]
===
match
---
decorator [7077,7155]
decorator [7077,7155]
===
match
---
name: VaultHook [47016,47025]
name: VaultHook [47034,47043]
===
match
---
decorators [33050,33212]
decorators [33068,33230]
===
match
---
trailer [13481,13483]
trailer [13499,13501]
===
match
---
atom_expr [12984,13016]
atom_expr [13002,13034]
===
match
---
atom_expr [33843,33907]
atom_expr [33861,33925]
===
match
---
assert_stmt [25173,25225]
assert_stmt [25191,25243]
===
match
---
decorators [35179,35341]
decorators [35197,35359]
===
match
---
name: patch [32199,32204]
name: patch [32217,32222]
===
match
---
operator: { [43549,43550]
operator: { [43567,43568]
===
match
---
dictorsetmaker [6608,6677]
dictorsetmaker [6608,6677]
===
match
---
simple_stmt [16321,16356]
simple_stmt [16339,16374]
===
match
---
name: client_id [14986,14995]
name: client_id [15004,15013]
===
match
---
name: return_value [17613,17625]
name: return_value [17631,17643]
===
match
---
trailer [28518,28524]
trailer [28536,28542]
===
match
---
number: 2 [35821,35822]
number: 2 [35839,35840]
===
match
---
atom_expr [2365,2384]
atom_expr [2365,2384]
===
match
---
decorated [25231,26529]
decorated [25249,26547]
===
match
---
name: radius [31991,31997]
name: radius [32009,32015]
===
match
---
operator: = [32509,32510]
operator: = [32527,32528]
===
match
---
operator: = [48240,48241]
operator: = [48258,48259]
===
match
---
operator: , [11434,11435]
operator: , [11452,11453]
===
match
---
trailer [6572,6576]
trailer [6572,6576]
===
match
---
trailer [8006,8040]
trailer [8012,8046]
===
match
---
name: self [11760,11764]
name: self [11778,11782]
===
match
---
decorator [47309,47389]
decorator [47327,47407]
===
match
---
operator: = [48262,48263]
operator: = [48280,48281]
===
match
---
operator: , [38334,38335]
operator: , [38352,38353]
===
match
---
name: secrets [39452,39459]
name: secrets [39470,39477]
===
match
---
trailer [24837,24839]
trailer [24855,24857]
===
match
---
simple_stmt [9939,10006]
simple_stmt [9951,10018]
===
match
---
argument [24716,24732]
argument [24734,24750]
===
match
---
trailer [33308,33318]
trailer [33326,33336]
===
match
---
simple_stmt [31974,32069]
simple_stmt [31992,32087]
===
match
---
operator: @ [29840,29841]
operator: @ [29858,29859]
===
match
---
name: secret [48064,48070]
name: secret [48082,48088]
===
match
---
atom [4894,4958]
atom [4894,4958]
===
match
---
trailer [31813,31832]
trailer [31831,31850]
===
match
---
simple_stmt [22885,22929]
simple_stmt [22903,22947]
===
match
---
trailer [22864,22874]
trailer [22882,22892]
===
match
---
trailer [27022,27035]
trailer [27040,27053]
===
match
---
name: mock_connection [35513,35528]
name: mock_connection [35531,35546]
===
match
---
param [30045,30055]
param [30063,30073]
===
match
---
simple_stmt [3367,3399]
simple_stmt [3367,3399]
===
match
---
name: test_hook [31872,31881]
name: test_hook [31890,31899]
===
match
---
operator: { [14566,14567]
operator: { [14584,14585]
===
match
---
argument [48044,48062]
argument [48062,48080]
===
match
---
name: kv [39460,39462]
name: kv [39478,39480]
===
match
---
trailer [45557,45580]
trailer [45575,45598]
===
match
---
expr_stmt [13044,13064]
expr_stmt [13062,13082]
===
match
---
dotted_name [26535,26545]
dotted_name [26553,26563]
===
match
---
name: test_client [27500,27511]
name: test_client [27518,27529]
===
match
---
name: mock [36257,36261]
name: mock [36275,36279]
===
match
---
name: kwargs [27082,27088]
name: kwargs [27100,27106]
===
match
---
operator: = [9909,9910]
operator: = [9921,9922]
===
match
---
argument [47098,47121]
argument [47116,47139]
===
match
---
operator: = [17571,17572]
operator: = [17589,17590]
===
match
---
name: mock_connection [4709,4724]
name: mock_connection [4709,4724]
===
match
---
name: mock_connection [38476,38491]
name: mock_connection [38494,38509]
===
match
---
atom_expr [10913,10957]
atom_expr [10931,10975]
===
match
---
expr_stmt [47713,47756]
expr_stmt [47731,47774]
===
match
---
operator: = [39499,39500]
operator: = [39517,39518]
===
match
---
dotted_name [41938,41948]
dotted_name [41956,41966]
===
match
---
string: 'lease_id' [42474,42484]
string: 'lease_id' [42492,42502]
===
match
---
name: mock_connection [6510,6525]
name: mock_connection [6510,6525]
===
match
---
name: kwargs [12157,12163]
name: kwargs [12175,12181]
===
match
---
atom_expr [44558,44587]
atom_expr [44576,44605]
===
match
---
param [30056,30075]
param [30074,30093]
===
match
---
operator: = [39222,39223]
operator: = [39240,39241]
===
match
---
number: 10 [48263,48265]
number: 10 [48281,48283]
===
match
---
name: return_value [23010,23022]
name: return_value [23028,23040]
===
match
---
argument [8917,8925]
argument [8923,8931]
===
match
---
operator: , [4487,4488]
operator: , [4487,4488]
===
match
---
atom [28210,28267]
atom [28228,28285]
===
match
---
argument [30866,30879]
argument [30884,30897]
===
match
---
name: version [40562,40569]
name: version [40580,40587]
===
match
---
operator: = [36123,36124]
operator: = [36141,36142]
===
match
---
operator: , [46140,46141]
operator: , [46158,46159]
===
match
---
name: side_effect [27040,27051]
name: side_effect [27058,27069]
===
match
---
atom_expr [36533,36562]
atom_expr [36551,36580]
===
match
---
simple_stmt [4023,4090]
simple_stmt [4023,4090]
===
match
---
atom_expr [7766,7785]
atom_expr [7766,7785]
===
match
---
trailer [27528,27547]
trailer [27546,27565]
===
match
---
testlist_comp [15946,15973]
testlist_comp [15964,15991]
===
match
---
name: test_get_existing_key_v2 [37518,37542]
name: test_get_existing_key_v2 [37536,37560]
===
match
---
operator: } [43968,43969]
operator: } [43986,43987]
===
match
---
parameters [24111,24149]
parameters [24129,24167]
===
match
---
testlist_comp [6937,6970]
testlist_comp [6937,6970]
===
match
---
name: kwargs [41504,41510]
name: kwargs [41522,41528]
===
match
---
trailer [36522,36524]
trailer [36540,36542]
===
match
---
operator: = [8032,8033]
operator: = [8038,8039]
===
match
---
trailer [44660,44663]
trailer [44678,44681]
===
match
---
name: test_hook [30970,30979]
name: test_hook [30988,30997]
===
match
---
import_name [933,946]
import_name [933,946]
===
match
---
trailer [44449,44451]
trailer [44467,44469]
===
match
---
name: mock_get_connection [3074,3093]
name: mock_get_connection [3074,3093]
===
match
---
name: test_hook [16879,16888]
name: test_hook [16897,16906]
===
match
---
string: 'data' [44875,44881]
string: 'data' [44893,44899]
===
match
---
operator: { [25693,25694]
operator: { [25711,25712]
===
match
---
name: return_value [10735,10747]
name: return_value [10753,10765]
===
match
---
name: kwargs [30601,30607]
name: kwargs [30619,30625]
===
match
---
atom_expr [4857,4876]
atom_expr [4857,4876]
===
match
---
name: get_mock_connection [20815,20834]
name: get_mock_connection [20833,20852]
===
match
---
operator: { [24381,24382]
operator: { [24399,24400]
===
match
---
name: get_mock_connection [4644,4663]
name: get_mock_connection [4644,4663]
===
match
---
expr_stmt [1286,1320]
expr_stmt [1286,1320]
===
match
---
string: "http://localhost:8180" [6898,6921]
string: "http://localhost:8180" [6898,6921]
===
match
---
simple_stmt [36585,36630]
simple_stmt [36603,36648]
===
match
---
argument [22376,22403]
argument [22394,22421]
===
match
---
trailer [46638,46640]
trailer [46656,46658]
===
match
---
suite [21755,22595]
suite [21773,22613]
===
match
---
operator: { [43346,43347]
operator: { [43364,43365]
===
match
---
param [11760,11765]
param [11778,11783]
===
match
---
atom_expr [27994,28026]
atom_expr [28012,28044]
===
match
---
name: test_hook [15126,15135]
name: test_hook [15144,15153]
===
match
---
trailer [34677,34681]
trailer [34695,34699]
===
match
---
simple_stmt [27231,27287]
simple_stmt [27249,27305]
===
match
---
comparison [5870,5916]
comparison [5870,5916]
===
match
---
trailer [2562,2572]
trailer [2562,2572]
===
match
---
operator: , [43835,43836]
operator: , [43853,43854]
===
match
---
operator: == [9268,9270]
operator: == [9280,9282]
===
match
---
operator: , [46947,46948]
operator: , [46965,46966]
===
match
---
name: secret_id [9175,9184]
name: secret_id [9187,9196]
===
match
---
trailer [22512,22531]
trailer [22530,22549]
===
match
---
name: mock_get_connection [37643,37662]
name: mock_get_connection [37661,37680]
===
match
---
simple_stmt [30724,30789]
simple_stmt [30742,30807]
===
match
---
trailer [24292,24294]
trailer [24310,24312]
===
match
---
trailer [47156,47180]
trailer [47174,47198]
===
match
---
trailer [23557,23576]
trailer [23575,23594]
===
match
---
operator: = [30587,30588]
operator: = [30605,30606]
===
match
---
name: create_or_update_secret [47054,47077]
name: create_or_update_secret [47072,47095]
===
match
---
name: assert_called_with [18489,18507]
name: assert_called_with [18507,18525]
===
match
---
name: mock_get_connection [19087,19106]
name: mock_get_connection [19105,19124]
===
match
---
expr_stmt [4621,4665]
expr_stmt [4621,4665]
===
match
---
name: get_mock_connection [7362,7381]
name: get_mock_connection [7362,7381]
===
match
---
name: test_hook [29794,29803]
name: test_hook [29812,29821]
===
match
---
name: type [1408,1412]
name: type [1408,1412]
===
match
---
simple_stmt [29441,29497]
simple_stmt [29459,29515]
===
match
---
trailer [32961,33011]
trailer [32979,33029]
===
match
---
name: kwargs [47871,47877]
name: kwargs [47889,47895]
===
match
---
string: 'version' [43938,43947]
string: 'version' [43956,43965]
===
match
---
expr_stmt [28277,28308]
expr_stmt [28295,28326]
===
match
---
simple_stmt [34463,34508]
simple_stmt [34481,34526]
===
match
---
dotted_name [27701,27711]
dotted_name [27719,27729]
===
match
---
param [27820,27839]
param [27838,27857]
===
match
---
operator: = [2209,2210]
operator: = [2209,2210]
===
match
---
operator: , [40560,40561]
operator: , [40578,40579]
===
match
---
name: mock [40955,40959]
name: mock [40973,40977]
===
match
---
argument [16563,16580]
argument [16581,16598]
===
match
---
name: mock_client [10679,10690]
name: mock_client [10697,10708]
===
match
---
string: "role_id" [7680,7689]
string: "role_id" [7680,7689]
===
match
---
string: "kube_role" [24414,24425]
string: "kube_role" [24432,24443]
===
match
---
name: mock_connection [5565,5580]
name: mock_connection [5565,5580]
===
match
---
atom_expr [27500,27549]
atom_expr [27518,27567]
===
match
---
operator: } [41320,41321]
operator: } [41338,41339]
===
match
---
name: mock_client [7319,7330]
name: mock_client [7319,7330]
===
match
---
name: extra_dejson [46846,46858]
name: extra_dejson [46864,46876]
===
match
---
dotted_name [32194,32204]
dotted_name [32212,32222]
===
match
---
dictorsetmaker [2255,2307]
dictorsetmaker [2255,2307]
===
match
---
name: return_value [1662,1674]
name: return_value [1662,1674]
===
match
---
with_stmt [2468,2573]
with_stmt [2468,2573]
===
match
---
operator: = [12551,12552]
operator: = [12569,12570]
===
match
---
trailer [32553,32573]
trailer [32571,32591]
===
match
---
param [1242,1254]
param [1242,1254]
===
match
---
name: self [42051,42055]
name: self [42069,42073]
===
match
---
simple_stmt [45467,45499]
simple_stmt [45485,45517]
===
match
---
trailer [34505,34507]
trailer [34523,34525]
===
match
---
name: mock_connection [45293,45308]
name: mock_connection [45311,45326]
===
match
---
string: 'metadata' [42567,42577]
string: 'metadata' [42585,42595]
===
match
---
name: assert_called_with [7814,7832]
name: assert_called_with [7814,7832]
===
match
---
name: patch [40677,40682]
name: patch [40695,40700]
===
match
---
atom_expr [27864,27880]
atom_expr [27882,27898]
===
match
---
name: Client [27348,27354]
name: Client [27366,27372]
===
match
---
name: is_authenticated [33928,33944]
name: is_authenticated [33946,33962]
===
match
---
expr_stmt [46905,46994]
expr_stmt [46923,47012]
===
match
---
argument [20299,20324]
argument [20317,20342]
===
match
---
name: Client [9052,9058]
name: Client [9058,9064]
===
match
---
simple_stmt [10883,10904]
simple_stmt [10901,10922]
===
match
---
name: test_hook [45518,45527]
name: test_hook [45536,45545]
===
match
---
operator: { [14341,14342]
operator: { [14359,14360]
===
match
---
trailer [5953,5966]
trailer [5953,5966]
===
match
---
param [37560,37579]
param [37578,37597]
===
match
---
trailer [7532,7544]
trailer [7532,7544]
===
match
---
decorators [25231,25393]
decorators [25249,25411]
===
match
---
name: get_mock_connection [27964,27983]
name: get_mock_connection [27982,28001]
===
match
---
name: mock_client [27850,27861]
name: mock_client [27868,27879]
===
match
---
name: url [31937,31940]
name: url [31955,31958]
===
match
---
suite [40820,41848]
suite [40838,41866]
===
match
---
operator: = [13355,13356]
operator: = [13373,13374]
===
match
---
decorator [46347,46427]
decorator [46365,46445]
===
match
---
operator: { [7488,7489]
operator: { [7488,7489]
===
match
---
atom [42320,42322]
atom [42338,42340]
===
match
---
operator: { [42394,42395]
operator: { [42412,42413]
===
match
---
name: connection_dict [21968,21983]
name: connection_dict [21986,22001]
===
match
---
name: mock_hvac [11846,11855]
name: mock_hvac [11864,11873]
===
match
---
trailer [1736,1757]
trailer [1736,1757]
===
match
---
name: mock_connection [24338,24353]
name: mock_connection [24356,24371]
===
match
---
trailer [24715,24733]
trailer [24733,24751]
===
match
---
operator: = [1722,1723]
operator: = [1722,1723]
===
match
---
operator: @ [8165,8166]
operator: @ [8171,8172]
===
match
---
trailer [34106,34119]
trailer [34124,34137]
===
match
---
string: '94011e25-f8dc-ec29-221b-1f9c1d9ad2ae' [42422,42460]
string: '94011e25-f8dc-ec29-221b-1f9c1d9ad2ae' [42440,42478]
===
match
---
name: mock [21778,21782]
name: mock [21796,21800]
===
match
---
dotted_name [40672,40682]
dotted_name [40690,40700]
===
match
---
name: patch [20550,20555]
name: patch [20568,20573]
===
match
---
name: auth_userpass [36065,36078]
name: auth_userpass [36083,36096]
===
match
---
name: return_value [15865,15877]
name: return_value [15883,15895]
===
match
---
atom_expr [8421,8437]
atom_expr [8427,8443]
===
match
---
name: extra_dejson [29193,29205]
name: extra_dejson [29211,29223]
===
match
---
dotted_name [21529,21539]
dotted_name [21547,21557]
===
match
---
testlist_comp [19391,19409]
testlist_comp [19409,19427]
===
match
---
simple_stmt [8407,8438]
simple_stmt [8413,8444]
===
match
---
simple_stmt [19851,19886]
simple_stmt [19869,19904]
===
match
---
operator: = [22467,22468]
operator: = [22485,22486]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [20556,20620]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [20574,20638]
===
match
---
atom [14566,14623]
atom [14584,14641]
===
match
---
name: Client [10172,10178]
name: Client [10184,10190]
===
match
---
name: method [49191,49197]
name: method [49209,49215]
===
match
---
simple_stmt [48105,48276]
simple_stmt [48123,48294]
===
match
---
operator: , [48596,48597]
operator: , [48614,48615]
===
match
---
name: assert_called_with [14693,14711]
name: assert_called_with [14711,14729]
===
match
---
name: kwargs [4197,4203]
name: kwargs [4197,4203]
===
match
---
trailer [27354,27373]
trailer [27372,27391]
===
match
---
atom_expr [19958,20009]
atom_expr [19976,20027]
===
match
---
name: vault_client [6758,6770]
name: vault_client [6758,6770]
===
match
---
operator: , [38353,38354]
operator: , [38371,38372]
===
match
---
name: return_value [17450,17462]
name: return_value [17468,17480]
===
match
---
name: patch [36346,36351]
name: patch [36364,36369]
===
match
---
expr_stmt [19735,19801]
expr_stmt [19753,19819]
===
match
---
operator: = [29120,29121]
operator: = [29138,29139]
===
match
---
operator: @ [12600,12601]
operator: @ [12618,12619]
===
match
---
name: vault_client [23878,23890]
name: vault_client [23896,23908]
===
match
---
atom_expr [13565,13759]
atom_expr [13583,13777]
===
match
---
string: "vault_conn_id" [31718,31733]
string: "vault_conn_id" [31736,31751]
===
match
---
operator: } [13063,13064]
operator: } [13081,13082]
===
match
---
operator: = [5833,5834]
operator: = [5833,5834]
===
match
---
number: 2 [21477,21478]
number: 2 [21495,21496]
===
match
---
name: kv [37844,37846]
name: kv [37862,37864]
===
match
---
name: mock [15173,15177]
name: mock [15191,15195]
===
match
---
operator: = [32031,32032]
operator: = [32049,32050]
===
match
---
trailer [21459,21461]
trailer [21477,21479]
===
match
---
operator: = [13531,13532]
operator: = [13549,13550]
===
match
---
name: PropertyMock [1724,1736]
name: PropertyMock [1724,1736]
===
match
---
atom_expr [24957,25021]
atom_expr [24975,25039]
===
match
---
name: mock_connection [33381,33396]
name: mock_connection [33399,33414]
===
match
---
string: '' [41208,41210]
string: '' [41226,41228]
===
match
---
name: mock [47310,47314]
name: mock [47328,47332]
===
match
---
trailer [21819,21832]
trailer [21837,21850]
===
match
---
decorator [9401,9479]
decorator [9413,9491]
===
match
---
operator: ** [13367,13369]
operator: ** [13385,13387]
===
match
---
name: mock_get_connection [16364,16383]
name: mock_get_connection [16382,16401]
===
match
---
name: mock [33135,33139]
name: mock [33153,33157]
===
match
---
string: "vault_conn_id" [16112,16127]
string: "vault_conn_id" [16130,16145]
===
match
---
string: 'secret_value' [44924,44938]
string: 'secret_value' [44942,44956]
===
match
---
expr_stmt [13449,13483]
expr_stmt [13467,13501]
===
match
---
arglist [28544,28576]
arglist [28562,28594]
===
match
---
name: url [18421,18424]
name: url [18439,18442]
===
match
---
name: mock_hvac [25430,25439]
name: mock_hvac [25448,25457]
===
match
---
string: 'http://localhost:8180' [23680,23703]
string: 'http://localhost:8180' [23698,23721]
===
match
---
argument [36115,36130]
argument [36133,36148]
===
match
---
trailer [11970,11983]
trailer [11988,12001]
===
match
---
simple_stmt [13044,13065]
simple_stmt [13062,13083]
===
match
---
simple_stmt [42249,42293]
simple_stmt [42267,42311]
===
match
---
name: mock_connection [48664,48679]
name: mock_connection [48682,48697]
===
match
---
name: assert_called_with [11483,11501]
name: assert_called_with [11501,11519]
===
match
---
name: mock_connection [33522,33537]
name: mock_connection [33540,33555]
===
match
---
name: side_effect [4843,4854]
name: side_effect [4843,4854]
===
match
---
operator: , [2651,2652]
operator: , [2651,2652]
===
match
---
name: mock_get_connection [21908,21927]
name: mock_get_connection [21926,21945]
===
match
---
operator: = [30306,30307]
operator: = [30324,30325]
===
match
---
string: "builtins.open" [23325,23340]
string: "builtins.open" [23343,23358]
===
match
---
operator: , [6630,6631]
operator: , [6630,6631]
===
match
---
decorator [21528,21608]
decorator [21546,21626]
===
match
---
string: '' [43874,43876]
string: '' [43892,43894]
===
match
---
expr_stmt [4569,4612]
expr_stmt [4569,4612]
===
match
---
simple_stmt [1329,1400]
simple_stmt [1329,1400]
===
match
---
simple_stmt [5673,5740]
simple_stmt [5673,5740]
===
match
---
argument [13528,13555]
argument [13546,13573]
===
match
---
string: "vault_conn_id" [10094,10109]
string: "vault_conn_id" [10106,10121]
===
match
---
trailer [23351,23369]
trailer [23369,23387]
===
match
---
string: "vault_conn_id" [27270,27285]
string: "vault_conn_id" [27288,27303]
===
match
---
operator: { [35740,35741]
operator: { [35758,35759]
===
match
---
atom_expr [19170,19186]
atom_expr [19188,19204]
===
match
---
operator: == [33988,33990]
operator: == [34006,34008]
===
match
---
operator: == [3431,3433]
operator: == [3431,3433]
===
match
---
trailer [39228,39248]
trailer [39246,39266]
===
match
---
operator: , [4153,4154]
operator: , [4153,4154]
===
match
---
trailer [41773,41785]
trailer [41791,41803]
===
match
---
simple_stmt [23397,23429]
simple_stmt [23415,23447]
===
match
---
expr_stmt [1329,1399]
expr_stmt [1329,1399]
===
match
---
decorator [6794,6989]
decorator [6794,6989]
===
match
---
expr_stmt [14737,14771]
expr_stmt [14755,14789]
===
match
---
operator: = [7443,7444]
operator: = [7443,7444]
===
match
---
name: secret_path [48044,48055]
name: secret_path [48062,48073]
===
match
---
trailer [41444,41457]
trailer [41462,41475]
===
match
---
expr_stmt [33290,33320]
expr_stmt [33308,33338]
===
match
---
trailer [47053,47077]
trailer [47071,47095]
===
match
---
string: "vault_conn_id" [22272,22287]
string: "vault_conn_id" [22290,22305]
===
match
---
operator: , [22814,22815]
operator: , [22832,22833]
===
match
---
operator: = [34916,34917]
operator: = [34934,34935]
===
match
---
operator: = [37198,37199]
operator: = [37216,37217]
===
match
---
trailer [29239,29243]
trailer [29257,29261]
===
match
---
operator: , [36451,36452]
operator: , [36469,36470]
===
match
---
name: connection_dict [41476,41491]
name: connection_dict [41494,41509]
===
match
---
name: mock [3742,3746]
name: mock [3742,3746]
===
match
---
trailer [18140,18159]
trailer [18158,18177]
===
match
---
name: configure [20257,20266]
name: configure [20275,20284]
===
match
---
trailer [28141,28154]
trailer [28159,28172]
===
match
---
param [11777,11796]
param [11795,11814]
===
match
---
trailer [25720,25733]
trailer [25738,25751]
===
match
---
assert_stmt [35121,35173]
assert_stmt [35139,35191]
===
match
---
atom [3965,4013]
atom [3965,4013]
===
match
---
string: '' [42922,42924]
string: '' [42940,42942]
===
match
---
with_item [24683,24747]
with_item [24701,24765]
===
match
---
operator: = [18345,18346]
operator: = [18363,18364]
===
match
---
name: is_authenticated [21424,21440]
name: is_authenticated [21442,21458]
===
match
---
operator: = [25098,25099]
operator: = [25116,25117]
===
match
---
string: "airflow.providers.google.cloud.utils.credentials_provider.get_credentials_and_project_id" [17026,17116]
string: "airflow.providers.google.cloud.utils.credentials_provider.get_credentials_and_project_id" [17044,17134]
===
match
---
name: mock_connection [36585,36600]
name: mock_connection [36603,36618]
===
match
---
string: "vault_conn_id" [4121,4136]
string: "vault_conn_id" [4121,4136]
===
match
---
funcdef [25397,26529]
funcdef [25415,26547]
===
match
---
trailer [30928,30947]
trailer [30946,30965]
===
match
---
name: read_data [24716,24725]
name: read_data [24734,24743]
===
match
---
trailer [11211,11220]
trailer [11229,11238]
===
match
---
decorated [10437,11565]
decorated [10455,11583]
===
match
---
operator: , [6187,6188]
operator: , [6187,6188]
===
match
---
simple_stmt [7901,7955]
simple_stmt [7901,7955]
===
match
---
name: test_client [22413,22424]
name: test_client [22431,22442]
===
match
---
operator: @ [9401,9402]
operator: @ [9413,9414]
===
match
---
operator: , [45662,45663]
operator: , [45680,45681]
===
match
---
string: "secret" [5870,5878]
string: "secret" [5870,5878]
===
match
---
trailer [9602,9609]
trailer [9614,9621]
===
match
---
simple_stmt [23080,23147]
simple_stmt [23098,23165]
===
match
---
operator: = [10304,10305]
operator: = [10322,10323]
===
match
---
operator: { [40176,40177]
operator: { [40194,40195]
===
match
---
simple_stmt [11304,11446]
simple_stmt [11322,11464]
===
match
---
param [5356,5375]
param [5356,5375]
===
match
---
operator: , [40357,40358]
operator: , [40375,40376]
===
match
---
name: patch [13974,13979]
name: patch [13992,13997]
===
match
---
operator: = [7391,7392]
operator: = [7391,7392]
===
match
---
arglist [14918,15037]
arglist [14936,15055]
===
match
---
expr_stmt [10913,10979]
expr_stmt [10931,10997]
===
match
---
atom_expr [11124,11179]
atom_expr [11142,11197]
===
match
---
argument [18521,18546]
argument [18539,18564]
===
match
---
simple_stmt [30797,30892]
simple_stmt [30815,30910]
===
match
---
name: secrets [41760,41767]
name: secrets [41778,41785]
===
match
---
string: '' [39593,39595]
string: '' [39611,39613]
===
match
---
string: "pass" [29697,29703]
string: "pass" [29715,29721]
===
match
---
name: url [37108,37111]
name: url [37126,37129]
===
match
---
param [39159,39164]
param [39177,39182]
===
match
---
name: patch [18969,18974]
name: patch [18987,18992]
===
match
---
name: vault_client [5954,5966]
name: vault_client [5954,5966]
===
match
---
operator: , [45722,45723]
operator: , [45740,45741]
===
match
---
argument [48214,48232]
argument [48232,48250]
===
match
---
name: is_authenticated [27512,27528]
name: is_authenticated [27530,27546]
===
match
---
atom_expr [1546,1573]
atom_expr [1546,1573]
===
match
---
name: kv_engine_version [10414,10431]
name: kv_engine_version [10432,10449]
===
match
---
trailer [1429,1434]
trailer [1429,1434]
===
match
---
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [4284,4350]
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [4284,4350]
===
match
---
atom_expr [36937,36956]
atom_expr [36955,36974]
===
match
---
trailer [26429,26446]
trailer [26447,26464]
===
match
---
expr_stmt [40980,41023]
expr_stmt [40998,41041]
===
match
---
simple_stmt [33522,33589]
simple_stmt [33540,33607]
===
match
---
trailer [1481,1498]
trailer [1481,1498]
===
match
---
trailer [17507,17527]
trailer [17525,17545]
===
match
---
simple_stmt [13768,13818]
simple_stmt [13786,13836]
===
match
---
string: "vault_conn_id" [19775,19790]
string: "vault_conn_id" [19793,19808]
===
match
---
trailer [29583,29612]
trailer [29601,29630]
===
match
---
operator: { [20099,20100]
operator: { [20117,20118]
===
match
---
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [32205,32271]
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [32223,32289]
===
match
---
operator: = [21984,21985]
operator: = [22002,22003]
===
match
---
name: mock_connection [9864,9879]
name: mock_connection [9876,9891]
===
match
---
simple_stmt [33381,33426]
simple_stmt [33399,33444]
===
match
---
funcdef [31182,32188]
funcdef [31200,32206]
===
match
---
parameters [17307,17384]
parameters [17325,17402]
===
match
---
atom_expr [31794,31849]
atom_expr [31812,31867]
===
match
---
trailer [44663,44666]
trailer [44681,44684]
===
match
---
string: "vault_conn_id" [30656,30671]
string: "vault_conn_id" [30674,30689]
===
match
---
operator: = [12576,12577]
operator: = [12594,12595]
===
match
---
operator: = [21307,21308]
operator: = [21325,21326]
===
match
---
name: MagicMock [9573,9582]
name: MagicMock [9585,9594]
===
match
---
string: '2020-03-16T21:01:43.331126Z' [45901,45930]
string: '2020-03-16T21:01:43.331126Z' [45919,45948]
===
match
---
operator: { [41513,41514]
operator: { [41531,41532]
===
match
---
atom [41513,41593]
atom [41531,41611]
===
match
---
name: read_secret_metadata [44042,44062]
name: read_secret_metadata [44060,44080]
===
match
---
name: mock_connection [36673,36688]
name: mock_connection [36691,36706]
===
match
---
simple_stmt [37232,37282]
simple_stmt [37250,37300]
===
match
---
atom_expr [16809,16858]
atom_expr [16827,16876]
===
match
---
name: return_value [32496,32508]
name: return_value [32514,32526]
===
match
---
atom_expr [20236,20335]
atom_expr [20254,20353]
===
match
---
simple_stmt [47796,47863]
simple_stmt [47814,47881]
===
match
---
name: mock_client [11878,11889]
name: mock_client [11896,11907]
===
match
---
name: mock_client [47674,47685]
name: mock_client [47692,47703]
===
match
---
funcdef [8331,9312]
funcdef [8337,9324]
===
match
---
param [44360,44365]
param [44378,44383]
===
match
---
name: assert_called_with [20373,20391]
name: assert_called_with [20391,20409]
===
match
---
funcdef [39122,40582]
funcdef [39140,40600]
===
match
---
operator: , [13282,13283]
operator: , [13300,13301]
===
match
---
atom_expr [19419,19452]
atom_expr [19437,19470]
===
match
---
expr_stmt [41063,41419]
expr_stmt [41081,41437]
===
match
---
expr_stmt [3074,3124]
expr_stmt [3074,3124]
===
match
---
name: v2 [48128,48130]
name: v2 [48146,48148]
===
match
---
name: test_hook [41652,41661]
name: test_hook [41670,41679]
===
match
---
name: secrets [38819,38826]
name: secrets [38837,38844]
===
match
---
name: mock_get_connection [23484,23503]
name: mock_get_connection [23502,23521]
===
match
---
trailer [36015,36044]
trailer [36033,36062]
===
match
---
expr_stmt [6321,6365]
expr_stmt [6321,6365]
===
match
---
name: return_value [9718,9730]
name: return_value [9730,9742]
===
match
---
simple_stmt [7500,7567]
simple_stmt [7500,7567]
===
match
---
operator: , [45185,45186]
operator: , [45203,45204]
===
match
---
simple_stmt [35422,35453]
simple_stmt [35440,35471]
===
match
---
simple_stmt [22542,22595]
simple_stmt [22560,22613]
===
match
---
name: url [22376,22379]
name: url [22394,22397]
===
match
---
name: get [46893,46896]
name: get [46911,46914]
===
match
---
testlist_comp [2623,2652]
testlist_comp [2623,2652]
===
match
---
name: assert_called_with [35893,35911]
name: assert_called_with [35911,35929]
===
match
---
trailer [12477,12496]
trailer [12495,12514]
===
match
---
string: "github" [21046,21054]
string: "github" [21064,21072]
===
match
---
trailer [14282,14295]
trailer [14300,14313]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [6085,6149]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [6085,6149]
===
match
---
operator: , [16598,16599]
operator: , [16616,16617]
===
match
---
atom_expr [20715,20731]
atom_expr [20733,20749]
===
match
---
operator: = [46720,46721]
operator: = [46738,46739]
===
match
---
import_from [947,985]
import_from [947,985]
===
match
---
operator: } [45184,45185]
operator: } [45202,45203]
===
match
---
name: mock_hvac [6269,6278]
name: mock_hvac [6269,6278]
===
match
---
atom_expr [24198,24227]
atom_expr [24216,24245]
===
match
---
name: patch [29930,29935]
name: patch [29948,29953]
===
match
---
trailer [25489,25499]
trailer [25507,25517]
===
match
---
operator: = [6555,6556]
operator: = [6555,6556]
===
match
---
atom_expr [9593,9622]
atom_expr [9605,9634]
===
match
---
string: "resource" [13314,13324]
string: "resource" [13332,13342]
===
match
---
atom_expr [45293,45337]
atom_expr [45311,45355]
===
match
---
trailer [40851,40871]
trailer [40869,40889]
===
match
---
string: "kv_engine_version" [33663,33682]
string: "kv_engine_version" [33681,33700]
===
match
---
expr_stmt [11084,11115]
expr_stmt [11102,11133]
===
match
---
name: patch [48396,48401]
name: patch [48414,48419]
===
match
---
operator: = [1435,1436]
operator: = [1435,1436]
===
match
---
expr_stmt [14119,14149]
expr_stmt [14137,14167]
===
match
---
name: mock [28787,28791]
name: mock [28805,28809]
===
match
---
operator: ** [24783,24785]
operator: ** [24801,24803]
===
match
---
trailer [48804,48806]
trailer [48822,48824]
===
match
---
name: connection_dict [34576,34591]
name: connection_dict [34594,34609]
===
match
---
name: connection_dict [30367,30382]
name: connection_dict [30385,30400]
===
match
---
string: "kube_role" [23236,23247]
string: "kube_role" [23254,23265]
===
match
---
operator: , [6944,6945]
operator: , [6944,6945]
===
match
---
simple_stmt [11188,11223]
simple_stmt [11206,11241]
===
match
---
operator: { [45596,45597]
operator: { [45614,45615]
===
match
---
trailer [40901,40914]
trailer [40919,40932]
===
match
---
name: vault_client [16889,16901]
name: vault_client [16907,16919]
===
match
---
name: test_hook [21121,21130]
name: test_hook [21139,21148]
===
match
---
name: get [5736,5739]
name: get [5736,5739]
===
match
---
operator: , [40015,40016]
operator: , [40033,40034]
===
match
---
name: test_client [33800,33811]
name: test_client [33818,33829]
===
match
---
comparison [26483,26528]
comparison [26501,26546]
===
match
---
decorator [29924,30002]
decorator [29942,30020]
===
match
---
trailer [15759,15779]
trailer [15777,15797]
===
match
---
trailer [8455,8462]
trailer [8461,8468]
===
match
---
trailer [45308,45321]
trailer [45326,45339]
===
match
---
decorator [8165,8245]
decorator [8171,8251]
===
match
---
atom [7584,7744]
atom [7584,7744]
===
match
---
operator: , [47530,47531]
operator: , [47548,47549]
===
match
---
name: assert_called_with [11248,11266]
name: assert_called_with [11266,11284]
===
match
---
atom_expr [8551,8583]
atom_expr [8557,8589]
===
match
---
string: "auth_type" [34608,34619]
string: "auth_type" [34626,34637]
===
match
---
expr_stmt [19494,19650]
expr_stmt [19512,19668]
===
match
---
atom_expr [37232,37281]
atom_expr [37250,37299]
===
match
---
name: mock [33051,33055]
name: mock [33069,33073]
===
match
---
name: mock_client [37702,37713]
name: mock_client [37720,37731]
===
match
---
string: "auth_type" [9790,9801]
string: "auth_type" [9802,9813]
===
match
---
name: get [8704,8707]
name: get [8710,8713]
===
match
---
atom_expr [37145,37223]
atom_expr [37163,37241]
===
match
---
name: mock [20715,20719]
name: mock [20733,20737]
===
match
---
name: get_mock_connection [47585,47604]
name: get_mock_connection [47603,47622]
===
match
---
operator: , [40786,40787]
operator: , [40804,40805]
===
match
---
atom_expr [34696,34715]
atom_expr [34714,34733]
===
match
---
trailer [24688,24734]
trailer [24706,24752]
===
match
---
atom [16098,16271]
atom [16116,16289]
===
match
---
simple_stmt [12984,13035]
simple_stmt [13002,13053]
===
match
---
atom_expr [43100,43119]
atom_expr [43118,43137]
===
match
---
string: "vault_conn_id" [45378,45393]
string: "vault_conn_id" [45396,45411]
===
match
---
name: mock_get_connection [17325,17344]
name: mock_get_connection [17343,17362]
===
match
---
atom_expr [30230,30262]
atom_expr [30248,30280]
===
match
---
simple_stmt [37590,37635]
simple_stmt [37608,37653]
===
match
---
atom_expr [34097,34131]
atom_expr [34115,34149]
===
match
---
trailer [6285,6298]
trailer [6285,6298]
===
match
---
name: mock_get_credentials [18245,18265]
name: mock_get_credentials [18263,18283]
===
match
---
trailer [44479,44492]
trailer [44497,44510]
===
match
---
argument [40288,40296]
argument [40306,40314]
===
match
---
atom_expr [1616,1646]
atom_expr [1616,1646]
===
match
---
name: get [23143,23146]
name: get [23161,23164]
===
match
---
operator: == [5941,5943]
operator: == [5941,5943]
===
match
---
operator: } [29166,29167]
operator: } [29184,29185]
===
match
---
argument [22462,22474]
argument [22480,22492]
===
match
---
string: "vault_conn_id" [12197,12212]
string: "vault_conn_id" [12215,12230]
===
match
---
expr_stmt [16281,16312]
expr_stmt [16299,16330]
===
match
---
string: '' [45688,45690]
string: '' [45706,45708]
===
match
---
decorator [28786,28864]
decorator [28804,28882]
===
match
---
name: patch [37354,37359]
name: patch [37372,37377]
===
match
---
param [33243,33248]
param [33261,33266]
===
match
---
trailer [20038,20057]
trailer [20056,20075]
===
match
---
simple_stmt [16281,16313]
simple_stmt [16299,16331]
===
match
---
atom_expr [32454,32470]
atom_expr [32472,32488]
===
match
---
atom [32876,32933]
atom [32894,32951]
===
match
---
operator: @ [31016,31017]
operator: @ [31034,31035]
===
match
---
operator: = [1302,1303]
operator: = [1302,1303]
===
match
---
operator: = [39330,39331]
operator: = [39348,39349]
===
match
---
name: get [22105,22108]
name: get [22123,22126]
===
match
---
name: mock [47688,47692]
name: mock [47706,47710]
===
match
---
operator: ** [28299,28301]
operator: ** [28317,28319]
===
match
---
trailer [11347,11445]
trailer [11365,11463]
===
match
---
trailer [33034,33044]
trailer [33052,33062]
===
match
---
trailer [17915,17919]
trailer [17933,17937]
===
match
---
atom_expr [8935,8990]
atom_expr [8941,8996]
===
match
---
trailer [35989,35996]
trailer [36007,36014]
===
match
---
simple_stmt [31603,31670]
simple_stmt [31621,31688]
===
match
---
operator: ** [35855,35857]
operator: ** [35873,35875]
===
match
---
string: "auth_type" [7644,7655]
string: "auth_type" [7644,7655]
===
match
---
name: mock_get_connection [39259,39278]
name: mock_get_connection [39277,39296]
===
match
---
param [3681,3686]
param [3681,3686]
===
match
---
simple_stmt [36774,36841]
simple_stmt [36792,36859]
===
match
---
parameters [36446,36484]
parameters [36464,36502]
===
match
---
trailer [30813,30820]
trailer [30831,30838]
===
match
---
trailer [19289,19291]
trailer [19307,19309]
===
match
---
trailer [4578,4585]
trailer [4578,4585]
===
match
---
trailer [19269,19289]
trailer [19287,19307]
===
match
---
dictorsetmaker [48072,48086]
dictorsetmaker [48090,48104]
===
match
---
trailer [20172,20179]
trailer [20190,20197]
===
match
---
operator: { [49350,49351]
operator: { [49368,49369]
===
match
---
name: get_secret_metadata [43288,43307]
name: get_secret_metadata [43306,43325]
===
match
---
atom_expr [16628,16692]
atom_expr [16646,16710]
===
match
---
param [8377,8396]
param [8383,8402]
===
match
---
string: "custom" [4949,4957]
string: "custom" [4949,4957]
===
match
---
operator: = [34986,34987]
operator: = [35004,35005]
===
match
---
string: 'created_time' [44991,45005]
string: 'created_time' [45009,45023]
===
match
---
decorator [48281,48386]
decorator [48299,48404]
===
match
---
atom_expr [35095,35112]
atom_expr [35113,35130]
===
match
---
name: MagicMock [21783,21792]
name: MagicMock [21801,21810]
===
match
---
simple_stmt [28943,28974]
simple_stmt [28961,28992]
===
match
---
expr_stmt [36849,36915]
expr_stmt [36867,36933]
===
match
---
simple_stmt [3767,3811]
simple_stmt [3767,3811]
===
match
---
string: "auth_type" [16158,16169]
string: "auth_type" [16176,16187]
===
match
---
name: assert_called_with [27529,27547]
name: assert_called_with [27547,27565]
===
match
---
name: side_effect [35689,35700]
name: side_effect [35707,35718]
===
match
---
operator: } [23069,23070]
operator: } [23087,23088]
===
match
---
operator: == [40423,40425]
operator: == [40441,40443]
===
match
---
name: mock [25485,25489]
name: mock [25503,25507]
===
match
---
operator: = [6592,6593]
operator: = [6592,6593]
===
match
---
decorator [15261,15365]
decorator [15279,15383]
===
match
---
operator: == [22551,22553]
operator: == [22569,22571]
===
match
---
operator: { [39708,39709]
operator: { [39726,39727]
===
match
---
atom_expr [44460,44492]
atom_expr [44478,44510]
===
match
---
trailer [24966,24973]
trailer [24984,24991]
===
match
---
parameters [8359,8397]
parameters [8365,8403]
===
match
---
operator: = [40276,40277]
operator: = [40294,40295]
===
match
---
string: 'value' [20107,20114]
string: 'value' [20125,20132]
===
match
---
simple_stmt [20163,20228]
simple_stmt [20181,20246]
===
match
---
simple_stmt [3021,3066]
simple_stmt [3021,3066]
===
match
---
simple_stmt [28424,28489]
simple_stmt [28442,28507]
===
match
---
param [9507,9512]
param [9519,9524]
===
match
---
trailer [16344,16353]
trailer [16362,16371]
===
match
---
trailer [47584,47604]
trailer [47602,47622]
===
match
---
name: Client [30135,30141]
name: Client [30153,30159]
===
match
---
atom_expr [10693,10709]
atom_expr [10711,10727]
===
match
---
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [9329,9395]
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [9341,9407]
===
match
---
decorator [1794,1874]
decorator [1794,1874]
===
match
---
string: 'lease_id' [41196,41206]
string: 'lease_id' [41214,41224]
===
match
---
dictorsetmaker [20100,20114]
dictorsetmaker [20118,20132]
===
match
---
name: self [31205,31209]
name: self [31223,31227]
===
match
---
operator: = [30402,30403]
operator: = [30420,30421]
===
match
---
name: protocol [7392,7400]
name: protocol [7392,7400]
===
match
---
trailer [32807,32820]
trailer [32825,32838]
===
match
---
operator: = [26880,26881]
operator: = [26898,26899]
===
match
---
dotted_name [13885,13895]
dotted_name [13903,13913]
===
match
---
name: is_authenticated [30912,30928]
name: is_authenticated [30930,30946]
===
match
---
string: "userpass" [2268,2278]
string: "userpass" [2268,2278]
===
match
---
operator: = [33509,33510]
operator: = [33527,33528]
===
match
---
atom_expr [29794,29834]
atom_expr [29812,29852]
===
match
---
trailer [44547,44549]
trailer [44565,44567]
===
match
---
string: "kubernetes_jwt_path" [24439,24460]
string: "kubernetes_jwt_path" [24457,24478]
===
match
---
name: get [40155,40158]
name: get [40173,40176]
===
match
---
name: get [33551,33554]
name: get [33569,33572]
===
match
---
operator: , [38455,38456]
operator: , [38473,38474]
===
match
---
name: return_value [1737,1749]
name: return_value [1737,1749]
===
match
---
operator: @ [10437,10438]
operator: @ [10455,10456]
===
match
---
string: "path" [47090,47096]
string: "path" [47108,47114]
===
match
---
name: kwargs [2565,2571]
name: kwargs [2565,2571]
===
match
---
trailer [27373,27402]
trailer [27391,27420]
===
match
---
operator: = [33397,33398]
operator: = [33415,33416]
===
match
---
atom_expr [21873,21899]
atom_expr [21891,21917]
===
match
---
operator: @ [48474,48475]
operator: @ [48492,48493]
===
match
---
argument [3862,3877]
argument [3862,3877]
===
match
---
string: 'http://localhost:8180' [34987,35010]
string: 'http://localhost:8180' [35005,35028]
===
match
---
operator: , [14461,14462]
operator: , [14479,14480]
===
match
---
name: mock_hvac [48815,48824]
name: mock_hvac [48833,48842]
===
match
---
operator: , [16789,16790]
operator: , [16807,16808]
===
match
---
simple_stmt [13492,13557]
simple_stmt [13510,13575]
===
match
---
string: "airflow.providers.google.cloud.utils.credentials_provider._get_scopes" [16937,17008]
string: "airflow.providers.google.cloud.utils.credentials_provider._get_scopes" [16955,17026]
===
match
---
trailer [29537,29539]
trailer [29555,29557]
===
match
---
argument [25077,25093]
argument [25095,25111]
===
match
---
param [36464,36483]
param [36482,36501]
===
match
---
operator: , [47519,47520]
operator: , [47537,47538]
===
match
---
string: "vault_conn_id" [35741,35756]
string: "vault_conn_id" [35759,35774]
===
match
---
name: is_authenticated [28598,28614]
name: is_authenticated [28616,28632]
===
match
---
name: VaultHook [7766,7775]
name: VaultHook [7766,7775]
===
match
---
trailer [31665,31669]
trailer [31683,31687]
===
match
---
string: "vault_conn_id" [9962,9977]
string: "vault_conn_id" [9974,9989]
===
match
---
atom_expr [47843,47862]
atom_expr [47861,47880]
===
match
---
name: mock_connection [34649,34664]
name: mock_connection [34667,34682]
===
match
---
name: mock [19170,19174]
name: mock [19188,19192]
===
match
---
operator: = [13060,13061]
operator: = [13078,13079]
===
match
---
trailer [40969,40971]
trailer [40987,40989]
===
match
---
decorator [41853,41933]
decorator [41871,41951]
===
match
---
string: "gcp" [16171,16176]
string: "gcp" [16189,16194]
===
match
---
simple_stmt [19958,20010]
simple_stmt [19976,20028]
===
match
---
atom_expr [26488,26528]
atom_expr [26506,26546]
===
match
---
name: patch [34143,34148]
name: patch [34161,34166]
===
match
---
simple_stmt [33290,33321]
simple_stmt [33308,33339]
===
match
---
dotted_name [9318,9328]
dotted_name [9330,9340]
===
match
---
comparison [22549,22594]
comparison [22567,22612]
===
match
---
operator: = [32979,32980]
operator: = [32997,32998]
===
match
---
trailer [9051,9058]
trailer [9057,9064]
===
match
---
name: get [29240,29243]
name: get [29258,29261]
===
match
---
operator: = [6242,6243]
operator: = [6242,6243]
===
match
---
simple_stmt [8895,8927]
simple_stmt [8901,8933]
===
match
---
name: mock [26619,26623]
name: mock [26637,26641]
===
match
---
name: read_data [26019,26028]
name: read_data [26037,26046]
===
match
---
expr_stmt [22193,22224]
expr_stmt [22211,22242]
===
match
---
dotted_name [23999,24009]
dotted_name [24017,24027]
===
match
---
simple_stmt [24159,24190]
simple_stmt [24177,24208]
===
match
---
trailer [27422,27427]
trailer [27440,27445]
===
match
---
operator: { [29261,29262]
operator: { [29279,29280]
===
match
---
trailer [30992,31010]
trailer [31010,31028]
===
match
---
trailer [48960,48964]
trailer [48978,48982]
===
match
---
trailer [37189,37223]
trailer [37207,37241]
===
match
---
name: assert_called_once_with [49264,49287]
name: assert_called_once_with [49282,49305]
===
match
---
name: mock_get_connection [39176,39195]
name: mock_get_connection [39194,39213]
===
match
---
name: MagicMock [7267,7276]
name: MagicMock [7267,7276]
===
match
---
trailer [8096,8098]
trailer [8102,8104]
===
match
---
trailer [22531,22533]
trailer [22549,22551]
===
match
---
atom [39708,39738]
atom [39726,39756]
===
match
---
name: mock_get_connection [14089,14108]
name: mock_get_connection [14107,14126]
===
match
---
name: mock_hvac [20740,20749]
name: mock_hvac [20758,20767]
===
match
---
name: mock_get_connection [30056,30075]
name: mock_get_connection [30074,30093]
===
match
---
simple_stmt [3074,3125]
simple_stmt [3074,3125]
===
match
---
atom_expr [20018,20154]
atom_expr [20036,20172]
===
match
---
name: configure [16722,16731]
name: configure [16740,16749]
===
match
---
name: patch [5995,6000]
name: patch [5995,6000]
===
match
---
name: mock_connection [30265,30280]
name: mock_connection [30283,30298]
===
match
---
dictorsetmaker [28086,28106]
dictorsetmaker [28104,28124]
===
match
---
atom_expr [5720,5739]
atom_expr [5720,5739]
===
match
---
name: key_path [18298,18306]
name: key_path [18316,18324]
===
match
---
name: mock [27617,27621]
name: mock [27635,27639]
===
match
---
operator: = [10995,10996]
operator: = [11013,11014]
===
match
---
dictorsetmaker [34747,34780]
dictorsetmaker [34765,34798]
===
match
---
decorated [31016,32188]
decorated [31034,32206]
===
match
---
name: VaultHook [1079,1088]
name: VaultHook [1079,1088]
===
match
---
atom_expr [25030,25106]
atom_expr [25048,25124]
===
match
---
operator: , [46110,46111]
operator: , [46128,46129]
===
match
---
simple_stmt [7963,8041]
simple_stmt [7963,8047]
===
match
---
operator: = [47104,47105]
operator: = [47122,47123]
===
match
---
trailer [21352,21357]
trailer [21370,21375]
===
match
---
simple_stmt [22937,22982]
simple_stmt [22955,23000]
===
match
---
simple_stmt [17433,17477]
simple_stmt [17451,17495]
===
match
---
name: role [11423,11427]
name: role [11441,11445]
===
match
---
name: mock [46432,46436]
name: mock [46450,46454]
===
match
---
atom_expr [22340,22404]
atom_expr [22358,22422]
===
match
---
name: connection_dict [36698,36713]
name: connection_dict [36716,36731]
===
match
---
name: test_hook [35833,35842]
name: test_hook [35851,35860]
===
match
---
argument [41810,41830]
argument [41828,41848]
===
match
---
name: mock [25232,25236]
name: mock [25250,25254]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [9413,9477]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [9425,9489]
===
match
---
operator: { [38066,38067]
operator: { [38084,38085]
===
match
---
name: MagicMock [5405,5414]
name: MagicMock [5405,5414]
===
match
---
name: metadata [45507,45515]
name: metadata [45525,45533]
===
match
---
operator: } [4799,4800]
operator: } [4799,4800]
===
match
---
operator: , [42745,42746]
operator: , [42763,42764]
===
match
---
operator: = [6337,6338]
operator: = [6337,6338]
===
match
---
decorated [2578,3475]
decorated [2578,3475]
===
match
---
name: mock_client [2103,2114]
name: mock_client [2103,2114]
===
match
---
string: "vault_conn_id" [30524,30539]
string: "vault_conn_id" [30542,30557]
===
match
---
operator: , [21100,21101]
operator: , [21118,21119]
===
match
---
trailer [16856,16858]
trailer [16874,16876]
===
match
---
dotted_name [17123,17133]
dotted_name [17141,17151]
===
match
---
argument [41673,41694]
argument [41691,41712]
===
match
---
arglist [25992,26036]
arglist [26010,26054]
===
match
---
assert_stmt [36198,36250]
assert_stmt [36216,36268]
===
match
---
operator: ** [29423,29425]
operator: ** [29441,29443]
===
match
---
param [14072,14077]
param [14090,14095]
===
match
---
atom_expr [11524,11564]
atom_expr [11542,11582]
===
match
---
name: patch [1800,1805]
name: patch [1800,1805]
===
match
---
operator: { [30308,30309]
operator: { [30326,30327]
===
match
---
name: v2 [39463,39465]
name: v2 [39481,39483]
===
match
---
simple_stmt [42302,42323]
simple_stmt [42320,42341]
===
match
---
dotted_name [3481,3491]
dotted_name [3481,3491]
===
match
---
atom_expr [28586,28635]
atom_expr [28604,28653]
===
match
---
operator: = [16333,16334]
operator: = [16351,16352]
===
match
---
trailer [1637,1646]
trailer [1637,1646]
===
match
---
trailer [35996,36015]
trailer [36014,36033]
===
match
---
operator: = [18532,18533]
operator: = [18550,18551]
===
match
---
decorators [27616,27778]
decorators [27634,27796]
===
match
---
atom_expr [14529,14548]
atom_expr [14547,14566]
===
match
---
trailer [12973,12975]
trailer [12991,12993]
===
match
---
operator: = [47229,47230]
operator: = [47247,47248]
===
match
---
argument [7776,7784]
argument [7776,7784]
===
match
---
trailer [33774,33791]
trailer [33792,33809]
===
match
---
name: vault_client [34039,34051]
name: vault_client [34057,34069]
===
match
---
atom_expr [8049,8098]
atom_expr [8055,8104]
===
match
---
name: secrets [40453,40460]
name: secrets [40471,40478]
===
match
---
name: test_client [16321,16332]
name: test_client [16339,16350]
===
match
---
operator: = [11402,11403]
operator: = [11420,11421]
===
match
---
trailer [3906,3919]
trailer [3906,3919]
===
match
---
name: return_value [15702,15714]
name: return_value [15720,15732]
===
match
---
simple_stmt [8551,8602]
simple_stmt [8557,8608]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [18975,19039]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [18993,19057]
===
match
---
operator: } [38121,38122]
operator: } [38139,38140]
===
match
---
operator: = [2942,2943]
operator: = [2942,2943]
===
match
---
simple_stmt [46747,46791]
simple_stmt [46765,46809]
===
match
---
atom_expr [25580,25606]
atom_expr [25598,25624]
===
match
---
comparison [23863,23908]
comparison [23881,23926]
===
match
---
name: side_effect [7533,7544]
name: side_effect [7533,7544]
===
match
---
name: mock [8250,8254]
name: mock [8256,8260]
===
match
---
expr_stmt [21010,21111]
expr_stmt [21028,21129]
===
match
---
atom_expr [24268,24294]
atom_expr [24286,24312]
===
match
---
decorator [31016,31096]
decorator [31034,31114]
===
match
---
name: mock_client [42281,42292]
name: mock_client [42299,42310]
===
match
---
atom_expr [21803,21832]
atom_expr [21821,21850]
===
match
---
name: return_value [36550,36562]
name: return_value [36568,36580]
===
match
---
name: MagicMock [1309,1318]
name: MagicMock [1309,1318]
===
match
---
string: "radius" [32689,32697]
string: "radius" [32707,32715]
===
match
---
trailer [40324,40335]
trailer [40342,40353]
===
match
---
suite [32431,33045]
suite [32449,33063]
===
match
---
number: 2 [8114,8115]
number: 2 [8120,8121]
===
match
---
name: return_value [46764,46776]
name: return_value [46782,46794]
===
match
---
expr_stmt [8407,8437]
expr_stmt [8413,8443]
===
match
---
name: return_value [15930,15942]
name: return_value [15948,15960]
===
match
---
suite [33281,34132]
suite [33299,34150]
===
match
---
string: 'http://localhost:8180' [28464,28487]
string: 'http://localhost:8180' [28482,28505]
===
match
---
operator: , [48338,48339]
operator: , [48356,48357]
===
match
---
atom_expr [12453,12594]
atom_expr [12471,12612]
===
match
---
atom [42816,43017]
atom [42834,43035]
===
match
---
name: extra_dejson [8657,8669]
name: extra_dejson [8663,8675]
===
match
---
name: get [31666,31669]
name: get [31684,31687]
===
match
---
parameters [4482,4520]
parameters [4482,4520]
===
match
---
assert_stmt [5925,5983]
assert_stmt [5925,5983]
===
match
---
atom_expr [27889,27918]
atom_expr [27907,27936]
===
match
---
trailer [28524,28543]
trailer [28542,28561]
===
match
---
name: mock_connection [39294,39309]
name: mock_connection [39312,39327]
===
match
---
expr_stmt [4885,4958]
expr_stmt [4885,4958]
===
match
---
name: mock_client [31252,31263]
name: mock_client [31270,31281]
===
match
---
operator: = [21941,21942]
operator: = [21959,21960]
===
match
---
atom_expr [40955,40971]
atom_expr [40973,40989]
===
match
---
name: host [1463,1467]
name: host [1463,1467]
===
match
---
name: get_mock_connection [3044,3063]
name: get_mock_connection [3044,3063]
===
match
---
operator: , [35390,35391]
operator: , [35408,35409]
===
match
---
simple_stmt [15114,15167]
simple_stmt [15132,15185]
===
match
---
trailer [31365,31385]
trailer [31383,31403]
===
match
---
name: test_hook [14633,14642]
name: test_hook [14651,14660]
===
match
---
name: return_value [14175,14187]
name: return_value [14193,14205]
===
match
---
simple_stmt [24912,24949]
simple_stmt [24930,24967]
===
match
---
operator: = [4599,4600]
operator: = [4599,4600]
===
match
---
simple_stmt [31456,31594]
simple_stmt [31474,31612]
===
match
---
name: read_secret_version [40467,40486]
name: read_secret_version [40485,40504]
===
match
---
name: kwargs [19835,19841]
name: kwargs [19853,19859]
===
match
---
operator: = [48788,48789]
operator: = [48806,48807]
===
match
---
simple_stmt [9042,9107]
simple_stmt [9048,9113]
===
match
---
operator: = [21776,21777]
operator: = [21794,21795]
===
match
---
name: Client [35990,35996]
name: Client [36008,36014]
===
match
---
simple_stmt [36198,36251]
simple_stmt [36216,36269]
===
match
---
name: side_effect [9897,9908]
name: side_effect [9909,9920]
===
match
---
param [37543,37548]
param [37561,37566]
===
match
---
simple_stmt [40441,40582]
simple_stmt [40459,40600]
===
match
---
simple_stmt [17657,17723]
simple_stmt [17675,17741]
===
match
---
expr_stmt [3217,3283]
expr_stmt [3217,3283]
===
match
---
name: exceptions [957,967]
name: exceptions [957,967]
===
match
---
string: "ldap" [27118,27124]
string: "ldap" [27136,27142]
===
match
---
argument [1662,1683]
argument [1662,1683]
===
match
---
suite [27841,28697]
suite [27859,28715]
===
match
---
name: extra_dejson [9880,9892]
name: extra_dejson [9892,9904]
===
match
---
simple_stmt [1286,1321]
simple_stmt [1286,1321]
===
match
---
string: 'renewable' [37993,38004]
string: 'renewable' [38011,38022]
===
match
---
operator: = [7940,7941]
operator: = [7940,7941]
===
match
---
simple_stmt [34840,34896]
simple_stmt [34858,34914]
===
match
---
trailer [23503,23522]
trailer [23521,23540]
===
match
---
name: test_hook [43278,43287]
name: test_hook [43296,43305]
===
match
---
atom_expr [6510,6554]
atom_expr [6510,6554]
===
match
---
atom_expr [18636,18676]
atom_expr [18654,18694]
===
match
---
funcdef [48556,49401]
funcdef [48574,49419]
===
match
---
operator: = [2999,3000]
operator: = [2999,3000]
===
match
---
decorator [22600,22680]
decorator [22618,22698]
===
match
---
argument [48089,48095]
argument [48107,48113]
===
match
---
operator: = [47841,47842]
operator: = [47859,47860]
===
match
---
operator: , [26007,26008]
operator: , [26025,26026]
===
match
---
comparison [3414,3474]
comparison [3414,3474]
===
match
---
name: Client [12390,12396]
name: Client [12408,12414]
===
match
---
name: mock_hvac [13492,13501]
name: mock_hvac [13510,13519]
===
match
---
name: get [35685,35688]
name: get [35703,35706]
===
match
---
operator: = [34694,34695]
operator: = [34712,34713]
===
match
---
name: get [5702,5705]
name: get [5702,5705]
===
match
---
name: gcp [20253,20256]
name: gcp [20271,20274]
===
match
---
trailer [5966,5983]
trailer [5966,5983]
===
match
---
name: get [29206,29209]
name: get [29224,29227]
===
match
---
trailer [22271,22288]
trailer [22289,22306]
===
match
---
operator: , [7181,7182]
operator: , [7181,7182]
===
match
---
operator: { [8725,8726]
operator: { [8731,8732]
===
match
---
expr_stmt [36698,36764]
expr_stmt [36716,36782]
===
match
---
expr_stmt [2071,2114]
expr_stmt [2071,2114]
===
match
---
argument [1376,1398]
argument [1376,1398]
===
match
---
atom_expr [2046,2062]
atom_expr [2046,2062]
===
match
---
name: mock_open [26009,26018]
name: mock_open [26027,26036]
===
match
---
operator: @ [18879,18880]
operator: @ [18897,18898]
===
match
---
operator: == [34094,34096]
operator: == [34112,34114]
===
match
---
trailer [16837,16856]
trailer [16855,16874]
===
match
---
string: "user" [37199,37205]
string: "user" [37217,37223]
===
match
---
name: mock_client [49214,49225]
name: mock_client [49232,49243]
===
match
---
operator: = [26401,26402]
operator: = [26419,26420]
===
match
---
expr_stmt [35833,35864]
expr_stmt [35851,35882]
===
match
---
testlist_comp [2624,2630]
testlist_comp [2624,2630]
===
match
---
atom_expr [8688,8707]
atom_expr [8694,8713]
===
match
---
trailer [49093,49103]
trailer [49111,49121]
===
match
---
trailer [29564,29583]
trailer [29582,29601]
===
match
---
string: "data" [26402,26408]
string: "data" [26420,26426]
===
match
---
trailer [40959,40969]
trailer [40977,40987]
===
match
---
dictorsetmaker [39515,40072]
dictorsetmaker [39533,40090]
===
match
---
operator: } [22031,22032]
operator: } [22049,22050]
===
match
---
atom_expr [35020,35069]
atom_expr [35038,35087]
===
match
---
atom_expr [48717,48749]
atom_expr [48735,48767]
===
match
---
name: VaultHook [13357,13366]
name: VaultHook [13375,13384]
===
match
---
name: auth_kubernetes [26345,26360]
name: auth_kubernetes [26363,26378]
===
match
---
expr_stmt [14482,14548]
expr_stmt [14500,14566]
===
match
---
decorated [20460,21523]
decorated [20478,21541]
===
match
---
string: "data" [23782,23788]
string: "data" [23800,23806]
===
match
---
trailer [11501,11503]
trailer [11519,11521]
===
match
---
operator: = [9184,9185]
operator: = [9196,9197]
===
match
---
trailer [21423,21440]
trailer [21441,21458]
===
match
---
name: url [10198,10201]
name: url [10210,10213]
===
match
---
name: return_value [22902,22914]
name: return_value [22920,22932]
===
match
---
trailer [4585,4598]
trailer [4585,4598]
===
match
---
name: mock_connection [31431,31446]
name: mock_connection [31449,31464]
===
match
---
name: connection_dict [14529,14544]
name: connection_dict [14547,14562]
===
match
---
operator: { [44909,44910]
operator: { [44927,44928]
===
match
---
string: "auth_type" [25890,25901]
string: "auth_type" [25908,25919]
===
match
---
name: mock_connection [32792,32807]
name: mock_connection [32810,32825]
===
match
---
operator: @ [1878,1879]
operator: @ [1878,1879]
===
match
---
name: mount_point [38890,38901]
name: mount_point [38908,38919]
===
match
---
atom_expr [14673,14728]
atom_expr [14691,14746]
===
match
---
name: github [22430,22436]
name: github [22448,22454]
===
match
---
trailer [8520,8540]
trailer [8526,8546]
===
match
---
trailer [14147,14149]
trailer [14165,14167]
===
match
---
name: extra_dejson [7516,7528]
name: extra_dejson [7516,7528]
===
match
---
name: mock_connection [47650,47665]
name: mock_connection [47668,47683]
===
match
---
name: test_hook [26064,26073]
name: test_hook [26082,26091]
===
match
---
operator: , [43750,43751]
operator: , [43768,43769]
===
match
---
name: mock_get_connection [17538,17557]
name: mock_get_connection [17556,17575]
===
match
---
string: 'wrap_info' [41335,41346]
string: 'wrap_info' [41353,41364]
===
match
---
name: self [25580,25584]
name: self [25598,25602]
===
match
---
simple_stmt [11512,11565]
simple_stmt [11530,11583]
===
match
---
dotted_name [35264,35274]
dotted_name [35282,35292]
===
match
---
name: mock [30100,30104]
name: mock [30118,30122]
===
match
---
operator: , [36113,36114]
operator: , [36131,36132]
===
match
---
trailer [34927,34936]
trailer [34945,34954]
===
match
---
atom_expr [14853,15047]
atom_expr [14871,15065]
===
match
---
expr_stmt [47615,47665]
expr_stmt [47633,47683]
===
match
---
name: VaultHook [45479,45488]
name: VaultHook [45497,45506]
===
match
---
arglist [16541,16609]
arglist [16559,16627]
===
match
---
atom_expr [1477,1503]
atom_expr [1477,1503]
===
match
---
simple_stmt [22233,22289]
simple_stmt [22251,22307]
===
match
---
operator: @ [27700,27701]
operator: @ [27718,27719]
===
match
---
operator: @ [44152,44153]
operator: @ [44170,44171]
===
match
---
decorator [18879,18959]
decorator [18897,18977]
===
match
---
simple_stmt [10679,10710]
simple_stmt [10697,10728]
===
match
---
operator: , [43950,43951]
operator: , [43968,43969]
===
match
---
trailer [47811,47824]
trailer [47829,47842]
===
match
---
atom_expr [47982,48001]
atom_expr [48000,48019]
===
match
---
atom_expr [43053,43097]
atom_expr [43071,43115]
===
match
---
name: mock [17123,17127]
name: mock [17141,17145]
===
match
---
dotted_name [10522,10532]
dotted_name [10540,10550]
===
match
---
atom_expr [9042,9106]
atom_expr [9048,9112]
===
match
---
simple_stmt [3887,3938]
simple_stmt [3887,3938]
===
match
---
operator: = [14527,14528]
operator: = [14545,14546]
===
match
---
expr_stmt [29252,29391]
expr_stmt [29270,29409]
===
match
---
operator: = [7582,7583]
operator: = [7582,7583]
===
match
---
name: mock [21613,21617]
name: mock [21631,21635]
===
match
---
funcdef [6155,6789]
funcdef [6155,6789]
===
match
---
string: 'wrap_info' [45199,45210]
string: 'wrap_info' [45217,45228]
===
match
---
name: token [35107,35112]
name: token [35125,35130]
===
match
---
name: connection_dict [23050,23065]
name: connection_dict [23068,23083]
===
match
---
expr_stmt [40092,40158]
expr_stmt [40110,40176]
===
match
---
trailer [37081,37088]
trailer [37099,37106]
===
match
---
expr_stmt [47796,47862]
expr_stmt [47814,47880]
===
match
---
simple_stmt [32531,32576]
simple_stmt [32549,32594]
===
match
---
trailer [49121,49145]
trailer [49139,49163]
===
match
---
with_stmt [24678,24840]
with_stmt [24696,24858]
===
match
---
operator: = [26120,26121]
operator: = [26138,26139]
===
match
---
name: assert_called_with [10075,10093]
name: assert_called_with [10087,10105]
===
match
---
name: Client [42259,42265]
name: Client [42277,42283]
===
match
---
trailer [30733,30740]
trailer [30751,30758]
===
match
---
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [36268,36334]
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [36286,36352]
===
match
---
operator: == [43996,43998]
operator: == [44014,44016]
===
match
---
param [25441,25460]
param [25459,25478]
===
match
---
trailer [21142,21152]
trailer [21160,21170]
===
match
---
operator: } [46176,46177]
operator: } [46194,46195]
===
match
---
operator: = [42222,42223]
operator: = [42240,42241]
===
match
---
operator: = [19263,19264]
operator: = [19281,19282]
===
match
---
operator: @ [13884,13885]
operator: @ [13902,13903]
===
match
---
simple_stmt [26476,26529]
simple_stmt [26494,26547]
===
match
---
expr_stmt [31343,31387]
expr_stmt [31361,31405]
===
match
---
operator: { [2402,2403]
operator: { [2402,2403]
===
match
---
simple_stmt [47044,47123]
simple_stmt [47062,47141]
===
match
---
operator: } [41052,41053]
operator: } [41070,41071]
===
match
---
name: mock_connection [22042,22057]
name: mock_connection [22060,22075]
===
match
---
name: v2 [46221,46223]
name: v2 [46239,46241]
===
match
---
operator: @ [34221,34222]
operator: @ [34239,34240]
===
match
---
argument [47285,47293]
argument [47303,47311]
===
match
---
atom_expr [13121,13140]
atom_expr [13139,13158]
===
match
---
name: mock_get_connection [5356,5375]
name: mock_get_connection [5356,5375]
===
match
---
name: kwargs [24564,24570]
name: kwargs [24582,24588]
===
match
---
name: self [33243,33247]
name: self [33261,33265]
===
match
---
trailer [37243,37260]
trailer [37261,37278]
===
match
---
dotted_name [31101,31111]
dotted_name [31119,31129]
===
match
---
expr_stmt [28201,28267]
expr_stmt [28219,28285]
===
match
---
trailer [28413,28415]
trailer [28431,28433]
===
match
---
operator: , [42066,42067]
operator: , [42084,42085]
===
match
---
dictorsetmaker [3979,4003]
dictorsetmaker [3979,4003]
===
match
---
name: MagicMock [40960,40969]
name: MagicMock [40978,40987]
===
match
---
operator: = [6706,6707]
operator: = [6706,6707]
===
match
---
operator: , [1240,1241]
operator: , [1240,1241]
===
match
---
atom [43346,43995]
atom [43364,44013]
===
match
---
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [22612,22678]
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [22630,22696]
===
match
---
string: "userpass" [4779,4789]
string: "userpass" [4779,4789]
===
match
---
operator: { [33511,33512]
operator: { [33529,33530]
===
match
---
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [1806,1872]
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [1806,1872]
===
match
---
trailer [41088,41100]
trailer [41106,41118]
===
match
---
name: get_mock_connection [8521,8540]
name: get_mock_connection [8527,8546]
===
match
---
argument [1589,1606]
argument [1589,1606]
===
match
---
name: PropertyMock [1649,1661]
name: PropertyMock [1649,1661]
===
match
---
simple_stmt [5069,5128]
simple_stmt [5069,5128]
===
match
---
name: assert_called_with [29753,29771]
name: assert_called_with [29771,29789]
===
match
---
name: mock [10693,10697]
name: mock [10711,10715]
===
match
---
string: 'metadata' [44957,44967]
string: 'metadata' [44975,44985]
===
match
---
atom_expr [34812,34831]
atom_expr [34830,34849]
===
match
---
operator: = [33812,33813]
operator: = [33830,33831]
===
match
---
simple_stmt [35513,35558]
simple_stmt [35531,35576]
===
match
---
trailer [41491,41495]
trailer [41509,41513]
===
match
---
trailer [24867,24886]
trailer [24885,24904]
===
match
---
atom_expr [15660,15676]
atom_expr [15678,15694]
===
match
---
name: mock_hvac [15685,15694]
name: mock_hvac [15703,15712]
===
match
---
trailer [21927,21940]
trailer [21945,21958]
===
match
---
atom_expr [3217,3261]
atom_expr [3217,3261]
===
match
---
operator: = [48680,48681]
operator: = [48698,48699]
===
match
---
string: "vault_conn_id" [21068,21083]
string: "vault_conn_id" [21086,21101]
===
match
---
atom_expr [38662,38681]
atom_expr [38680,38699]
===
match
---
operator: , [43412,43413]
operator: , [43430,43431]
===
match
---
name: mock [27864,27868]
name: mock [27882,27886]
===
match
---
name: test_hook [36210,36219]
name: test_hook [36228,36237]
===
match
---
name: get [13137,13140]
name: get [13155,13158]
===
match
---
name: connection_dict [47766,47781]
name: connection_dict [47784,47799]
===
match
---
string: 'version' [42986,42995]
string: 'version' [43004,43013]
===
match
---
operator: } [2458,2459]
operator: } [2458,2459]
===
match
---
expr_stmt [8641,8707]
expr_stmt [8647,8713]
===
match
---
dotted_name [13969,13979]
dotted_name [13987,13997]
===
match
---
decorators [38956,39118]
decorators [38974,39136]
===
match
---
operator: = [31472,31473]
operator: = [31490,31491]
===
match
---
decorated [29840,31011]
decorated [29858,31029]
===
match
---
trailer [24322,24335]
trailer [24340,24353]
===
match
---
atom [21019,21111]
atom [21037,21129]
===
match
---
name: role [25077,25081]
name: role [25095,25099]
===
match
---
trailer [40460,40463]
trailer [40478,40481]
===
match
---
string: "data" [24726,24732]
string: "data" [24744,24750]
===
match
---
simple_stmt [1766,1789]
simple_stmt [1766,1789]
===
match
---
atom_expr [41748,41847]
atom_expr [41766,41865]
===
match
---
string: 'secret' [46293,46301]
string: 'secret' [46311,46319]
===
match
---
string: "path" [26244,26250]
string: "path" [26262,26268]
===
match
---
name: get_mock_connection [21878,21897]
name: get_mock_connection [21896,21915]
===
match
---
trailer [4663,4665]
trailer [4663,4665]
===
match
---
atom_expr [48682,48708]
atom_expr [48700,48726]
===
match
---
atom_expr [21133,21152]
atom_expr [21151,21170]
===
match
---
dotted_name [7078,7088]
dotted_name [7078,7088]
===
match
---
name: get_mock_connection [35536,35555]
name: get_mock_connection [35554,35573]
===
match
---
trailer [37170,37189]
trailer [37188,37207]
===
match
---
simple_stmt [18245,18377]
simple_stmt [18263,18395]
===
match
---
name: mock_hvac [17433,17442]
name: mock_hvac [17451,17460]
===
match
---
dotted_name [18880,18890]
dotted_name [18898,18908]
===
match
---
name: mock [5134,5138]
name: mock [5134,5138]
===
match
---
string: "secret" [5014,5022]
string: "secret" [5014,5022]
===
match
---
param [19130,19145]
param [19148,19163]
===
match
---
name: return_value [28014,28026]
name: return_value [28032,28044]
===
match
---
parameters [1167,1276]
parameters [1167,1276]
===
match
---
trailer [26497,26510]
trailer [26515,26528]
===
match
---
name: mock_connection [15737,15752]
name: mock_connection [15755,15770]
===
match
---
name: mock_connection [40829,40844]
name: mock_connection [40847,40862]
===
match
---
operator: , [23776,23777]
operator: , [23794,23795]
===
match
---
expr_stmt [14158,14201]
expr_stmt [14176,14219]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [28798,28862]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [28816,28880]
===
match
---
number: 2 [27565,27566]
number: 2 [27583,27584]
===
match
---
simple_stmt [1693,1758]
simple_stmt [1693,1758]
===
match
---
name: MagicMock [28962,28971]
name: MagicMock [28980,28989]
===
match
---
trailer [42265,42278]
trailer [42283,42296]
===
match
---
name: mock [2758,2762]
name: mock [2758,2762]
===
match
---
name: mock_hvac [5345,5354]
name: mock_hvac [5345,5354]
===
match
---
operator: = [19168,19169]
operator: = [19186,19187]
===
match
---
atom [25693,25695]
atom [25711,25713]
===
match
---
atom_expr [16364,16419]
atom_expr [16382,16437]
===
match
---
name: mock_client [19156,19167]
name: mock_client [19174,19185]
===
match
---
atom [23068,23070]
atom [23086,23088]
===
match
---
trailer [3861,3878]
trailer [3861,3878]
===
match
---
name: mock_connection [4023,4038]
name: mock_connection [4023,4038]
===
match
---
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [27628,27694]
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [27646,27712]
===
match
---
simple_stmt [11807,11838]
simple_stmt [11825,11856]
===
match
---
number: 1 [43730,43731]
number: 1 [43748,43749]
===
match
---
operator: , [8874,8875]
operator: , [8880,8881]
===
match
---
assert_stmt [10379,10431]
assert_stmt [10397,10449]
===
match
---
atom_expr [15056,15105]
atom_expr [15074,15123]
===
match
---
param [28896,28901]
param [28914,28919]
===
match
---
operator: , [41182,41183]
operator: , [41200,41201]
===
match
---
trailer [38538,38542]
trailer [38556,38560]
===
match
---
operator: @ [11570,11571]
operator: @ [11588,11589]
===
match
---
name: configure [29645,29654]
name: configure [29663,29672]
===
match
---
atom_expr [20344,20393]
atom_expr [20362,20411]
===
match
---
name: mock_get_connection [2900,2919]
name: mock_get_connection [2900,2919]
===
match
---
trailer [32603,32616]
trailer [32621,32634]
===
match
---
name: mock_client [41748,41759]
name: mock_client [41766,41777]
===
match
---
expr_stmt [15646,15676]
expr_stmt [15664,15694]
===
match
---
expr_stmt [27191,27222]
expr_stmt [27209,27240]
===
match
---
trailer [1661,1684]
trailer [1661,1684]
===
match
---
name: test_client [29724,29735]
name: test_client [29742,29753]
===
match
---
name: auth_approle [10247,10259]
name: approle [10264,10271]
===
match
---
trailer [36802,36806]
trailer [36820,36824]
===
match
---
operator: , [24425,24426]
operator: , [24443,24444]
===
match
---
param [7207,7217]
param [7207,7217]
===
match
---
simple_stmt [5007,5061]
simple_stmt [5007,5061]
===
match
---
name: mock_client [15717,15728]
name: mock_client [15735,15746]
===
match
---
operator: } [43994,43995]
operator: } [44012,44013]
===
match
---
atom_expr [49214,49400]
atom_expr [49232,49418]
===
match
---
name: test_hook [47004,47013]
name: test_hook [47022,47031]
===
match
---
name: unittest [880,888]
name: unittest [880,888]
===
match
---
operator: = [33706,33707]
operator: = [33724,33725]
===
match
---
trailer [17557,17570]
trailer [17575,17588]
===
match
---
string: "vault_conn_id" [33624,33639]
string: "vault_conn_id" [33642,33657]
===
match
---
name: get [28155,28158]
name: get [28173,28176]
===
match
---
dictorsetmaker [4121,4154]
dictorsetmaker [4121,4154]
===
match
---
operator: , [11030,11031]
operator: , [11048,11049]
===
match
---
number: 0 [45754,45755]
number: 0 [45772,45773]
===
match
---
operator: = [9731,9732]
operator: = [9743,9744]
===
match
---
name: test_hook [13345,13354]
name: test_hook [13363,13372]
===
match
---
decorated [38956,40582]
decorated [38974,40600]
===
match
---
simple_stmt [38551,38641]
simple_stmt [38569,38659]
===
match
---
operator: = [27052,27053]
operator: = [27070,27071]
===
match
---
operator: = [1601,1602]
operator: = [1601,1602]
===
match
---
name: assert_called_with [10350,10368]
name: assert_called_with [10368,10386]
===
match
---
operator: = [5563,5564]
operator: = [5563,5564]
===
match
---
argument [2499,2538]
argument [2499,2538]
===
match
---
name: patch [26540,26545]
name: patch [26558,26563]
===
match
---
name: Client [30734,30740]
name: Client [30752,30758]
===
match
---
atom_expr [16335,16355]
atom_expr [16353,16373]
===
match
---
name: mock [38957,38961]
name: mock [38975,38979]
===
match
---
name: mock_connection [11986,12001]
name: mock_connection [12004,12019]
===
match
---
expr_stmt [23155,23304]
expr_stmt [23173,23322]
===
match
---
name: create_or_update_secret [49122,49145]
name: create_or_update_secret [49140,49163]
===
match
---
name: VaultHook [34812,34821]
name: VaultHook [34830,34839]
===
match
---
arglist [48192,48265]
arglist [48210,48283]
===
match
---
name: test_hook [38650,38659]
name: test_hook [38668,38677]
===
match
---
name: expand [2593,2599]
name: expand [2593,2599]
===
match
---
expr_stmt [10119,10153]
expr_stmt [10131,10165]
===
match
---
operator: { [35644,35645]
operator: { [35662,35663]
===
match
---
name: mock_get_connection [46649,46668]
name: mock_get_connection [46667,46686]
===
match
---
operator: = [36671,36672]
operator: = [36689,36690]
===
match
---
trailer [46267,46341]
trailer [46285,46359]
===
match
---
name: connection_dict [28173,28188]
name: connection_dict [28191,28206]
===
match
---
name: test_client [33916,33927]
name: test_client [33934,33945]
===
match
---
name: Client [28992,28998]
name: Client [29010,29016]
===
match
---
simple_stmt [39440,40083]
simple_stmt [39458,40101]
===
match
---
name: mock_client [40941,40952]
name: mock_client [40959,40970]
===
match
---
trailer [22429,22436]
trailer [22447,22454]
===
match
---
comparison [27565,27610]
comparison [27583,27628]
===
match
---
name: Client [24208,24214]
name: Client [24226,24232]
===
match
---
operator: = [9946,9947]
operator: = [9958,9959]
===
match
---
trailer [34400,34402]
trailer [34418,34420]
===
match
---
atom_expr [7872,7892]
atom_expr [7872,7892]
===
match
---
name: test_hook [27309,27318]
name: test_hook [27327,27336]
===
match
---
name: mock [35264,35268]
name: mock [35282,35286]
===
match
---
name: username [37190,37198]
name: username [37208,37216]
===
match
---
simple_stmt [5925,5984]
simple_stmt [5925,5984]
===
match
---
dictorsetmaker [48242,48256]
dictorsetmaker [48260,48274]
===
match
---
name: get_conn [11212,11220]
name: get_conn [11230,11238]
===
match
---
trailer [5701,5705]
trailer [5701,5705]
===
match
---
atom_expr [31291,31320]
atom_expr [31309,31338]
===
match
---
simple_stmt [23050,23071]
simple_stmt [23068,23089]
===
match
---
operator: , [20133,20134]
operator: , [20151,20152]
===
match
---
atom_expr [29724,29773]
atom_expr [29742,29791]
===
match
---
simple_stmt [14119,14150]
simple_stmt [14137,14168]
===
match
---
simple_stmt [24198,24242]
simple_stmt [24216,24260]
===
match
---
operator: = [26950,26951]
operator: = [26968,26969]
===
match
---
atom [35740,35823]
atom [35758,35841]
===
match
---
name: test_client [18078,18089]
name: test_client [18096,18107]
===
match
---
trailer [4842,4854]
trailer [4842,4854]
===
match
---
decorator [33134,33212]
decorator [33152,33230]
===
match
---
name: port [32058,32062]
name: port [32076,32080]
===
match
---
trailer [27579,27592]
trailer [27597,27610]
===
match
---
suite [26051,26143]
suite [26069,26161]
===
match
---
atom_expr [34386,34402]
atom_expr [34404,34420]
===
match
---
argument [14655,14663]
argument [14673,14681]
===
match
---
name: test_hook [5944,5953]
name: test_hook [5944,5953]
===
match
---
trailer [23473,23475]
trailer [23491,23493]
===
match
---
simple_stmt [33736,33792]
simple_stmt [33754,33810]
===
match
---
simple_stmt [33493,33514]
simple_stmt [33511,33532]
===
match
---
argument [23352,23368]
argument [23370,23386]
===
match
---
dotted_name [5218,5228]
dotted_name [5218,5228]
===
match
---
name: Client [29558,29564]
name: Client [29576,29582]
===
match
---
dictorsetmaker [35741,35822]
dictorsetmaker [35759,35840]
===
match
---
atom_expr [36140,36189]
atom_expr [36158,36207]
===
match
---
expr_stmt [31291,31334]
expr_stmt [31309,31352]
===
match
---
trailer [1550,1567]
trailer [1550,1567]
===
match
---
operator: = [4750,4751]
operator: = [4750,4751]
===
match
---
string: 'auth' [41396,41402]
string: 'auth' [41414,41420]
===
match
---
trailer [23112,23124]
trailer [23130,23142]
===
match
---
expr_stmt [27082,27181]
expr_stmt [27100,27199]
===
match
---
name: assert_called_with [32008,32026]
name: assert_called_with [32026,32044]
===
match
---
name: self [36447,36451]
name: self [36465,36469]
===
match
---
param [25430,25440]
param [25448,25458]
===
match
---
atom_expr [29519,29539]
atom_expr [29537,29557]
===
match
---
name: connection_dict [38523,38538]
name: connection_dict [38541,38556]
===
match
---
name: mount_point [34120,34131]
name: mount_point [34138,34149]
===
match
---
string: 'secret' [41822,41830]
string: 'secret' [41840,41848]
===
match
---
name: mock_connection [3922,3937]
name: mock_connection [3922,3937]
===
match
---
funcdef [42019,44147]
funcdef [42037,44165]
===
match
---
trailer [15067,15084]
trailer [15085,15102]
===
match
---
atom_expr [23548,23631]
atom_expr [23566,23649]
===
match
---
string: 'version' [42767,42776]
string: 'version' [42785,42794]
===
match
---
name: test_hook [29401,29410]
name: test_hook [29419,29428]
===
match
---
trailer [10928,10941]
trailer [10946,10959]
===
match
---
operator: = [25483,25484]
operator: = [25501,25502]
===
match
---
string: 'missing' [40551,40560]
string: 'missing' [40569,40578]
===
match
---
name: test_hook [10391,10400]
name: test_hook [10409,10418]
===
match
---
trailer [30104,30114]
trailer [30122,30132]
===
match
---
name: mock_get_connection [14673,14692]
name: mock_get_connection [14691,14710]
===
match
---
trailer [30830,30849]
trailer [30848,30867]
===
match
---
name: kv_engine_version [37325,37342]
name: kv_engine_version [37343,37360]
===
match
---
atom [46818,46820]
atom [46836,46838]
===
match
---
trailer [36946,36956]
trailer [36964,36974]
===
match
---
expr_stmt [4734,4800]
expr_stmt [4734,4800]
===
match
---
simple_stmt [31291,31335]
simple_stmt [31309,31353]
===
match
---
name: return_value [5442,5454]
name: return_value [5442,5454]
===
match
---
trailer [34664,34677]
trailer [34682,34695]
===
match
---
number: 10 [48093,48095]
number: 10 [48111,48113]
===
match
---
string: "vault_conn_id" [26190,26205]
string: "vault_conn_id" [26208,26223]
===
match
---
atom [48886,48888]
atom [48904,48906]
===
match
---
name: get [10942,10945]
name: get [10960,10963]
===
match
---
name: kwargs [8919,8925]
name: kwargs [8925,8931]
===
match
---
name: return_value [26937,26949]
name: return_value [26955,26967]
===
match
---
operator: , [43731,43732]
operator: , [43749,43750]
===
match
---
name: kwargs [34724,34730]
name: kwargs [34742,34748]
===
match
---
string: "vault_conn_id" [29348,29363]
string: "vault_conn_id" [29366,29381]
===
match
---
string: 'data' [38084,38090]
string: 'data' [38102,38108]
===
match
---
trailer [39346,39348]
trailer [39364,39366]
===
match
---
trailer [41770,41773]
trailer [41788,41791]
===
match
---
operator: = [27466,27467]
operator: = [27484,27485]
===
match
---
string: 'secret_key' [40393,40405]
string: 'secret_key' [40411,40423]
===
match
---
atom [46914,46994]
atom [46932,47012]
===
match
---
trailer [36232,36250]
trailer [36250,36268]
===
match
---
expr_stmt [6585,6687]
expr_stmt [6585,6687]
===
match
---
decorators [13884,14046]
decorators [13902,14064]
===
match
---
argument [23676,23703]
argument [23694,23721]
===
match
---
atom_expr [17503,17529]
atom_expr [17521,17547]
===
match
---
name: self [9663,9667]
name: self [9675,9679]
===
match
---
name: test_userpass_dejson [36426,36446]
name: test_userpass_dejson [36444,36464]
===
match
---
expr_stmt [19359,19410]
expr_stmt [19377,19428]
===
match
---
decorator [17014,17118]
decorator [17032,17136]
===
match
---
dotted_name [18772,18782]
dotted_name [18790,18800]
===
match
---
name: mock_connection [30320,30335]
name: mock_connection [30338,30353]
===
match
---
trailer [37156,37170]
trailer [37174,37188]
===
match
---
decorators [26534,26696]
decorators [26552,26714]
===
match
---
name: mount_point [48192,48203]
name: mount_point [48210,48221]
===
match
---
string: 'scope1' [15881,15889]
string: 'scope1' [15899,15907]
===
match
---
trailer [23095,23108]
trailer [23113,23126]
===
match
---
operator: = [8686,8687]
operator: = [8692,8693]
===
match
---
string: "token" [33654,33661]
string: "token" [33672,33679]
===
match
---
operator: = [8419,8420]
operator: = [8425,8426]
===
match
---
trailer [34038,34051]
trailer [34056,34069]
===
match
---
trailer [31631,31635]
trailer [31649,31653]
===
match
---
argument [26296,26323]
argument [26314,26341]
===
match
---
name: secret_path [47240,47251]
name: secret_path [47258,47269]
===
match
---
operator: , [20115,20116]
operator: , [20133,20134]
===
match
---
simple_stmt [2553,2573]
simple_stmt [2553,2573]
===
match
---
name: self [12793,12797]
name: self [12811,12815]
===
match
---
operator: } [39968,39969]
operator: } [39986,39987]
===
match
---
name: patch [46353,46358]
name: patch [46371,46376]
===
match
---
decorated [26534,27611]
decorated [26552,27629]
===
match
---
trailer [43081,43085]
trailer [43099,43103]
===
match
---
simple_stmt [22193,22225]
simple_stmt [22211,22243]
===
match
---
string: "auth_type" [32676,32687]
string: "auth_type" [32694,32705]
===
match
---
name: mock_connection [25562,25577]
name: mock_connection [25580,25595]
===
match
---
trailer [11143,11162]
trailer [11161,11180]
===
match
---
operator: , [42964,42965]
operator: , [42982,42983]
===
match
---
trailer [5404,5414]
trailer [5404,5414]
===
match
---
name: test_gcp_dejson [17292,17307]
name: test_gcp_dejson [17310,17325]
===
match
---
name: kwargs [6585,6591]
name: kwargs [6585,6591]
===
match
---
trailer [14885,14904]
trailer [14903,14922]
===
match
---
name: password [37207,37215]
name: password [37225,37233]
===
match
---
name: Client [16638,16644]
name: Client [16656,16662]
===
match
---
simple_stmt [40385,40433]
simple_stmt [40403,40451]
===
match
---
name: test_hook [28395,28404]
name: test_hook [28413,28422]
===
match
---
name: test_hook [6748,6757]
name: test_hook [6748,6757]
===
match
---
param [17346,17367]
param [17364,17385]
===
match
---
expr_stmt [6696,6727]
expr_stmt [6696,6727]
===
match
---
name: mock_client [19227,19238]
name: mock_client [19245,19256]
===
match
---
trailer [33717,33727]
trailer [33735,33745]
===
match
---
name: get [32821,32824]
name: get [32839,32842]
===
match
---
trailer [28013,28026]
trailer [28031,28044]
===
match
---
simple_stmt [41429,41496]
simple_stmt [41447,41514]
===
match
---
name: patch [44242,44247]
name: patch [44260,44265]
===
match
---
operator: = [34549,34550]
operator: = [34567,34568]
===
match
---
simple_stmt [29621,29716]
simple_stmt [29639,29734]
===
match
---
trailer [33878,33907]
trailer [33896,33925]
===
match
---
trailer [21504,21522]
trailer [21522,21540]
===
match
---
operator: = [44588,44589]
operator: = [44606,44607]
===
match
---
name: patch [31022,31027]
name: patch [31040,31045]
===
match
---
simple_stmt [6585,6688]
simple_stmt [6585,6688]
===
match
---
name: mock [24173,24177]
name: mock [24191,24195]
===
match
---
trailer [26224,26243]
trailer [26242,26261]
===
match
---
operator: , [45216,45217]
operator: , [45234,45235]
===
match
---
trailer [7936,7954]
trailer [7936,7954]
===
match
---
assert_stmt [35078,35112]
assert_stmt [35096,35130]
===
match
---
name: side_effect [32825,32836]
name: side_effect [32843,32854]
===
match
---
operator: = [28287,28288]
operator: = [28305,28306]
===
match
---
name: kv_engine_version [9294,9311]
name: kv_engine_version [9306,9323]
===
match
---
operator: = [13741,13742]
operator: = [13759,13760]
===
match
---
trailer [14875,14885]
trailer [14893,14903]
===
match
---
operator: } [19649,19650]
operator: } [19667,19668]
===
match
---
name: credentials [20299,20310]
name: credentials [20317,20328]
===
match
---
atom_expr [20414,20454]
atom_expr [20432,20472]
===
match
---
operator: , [8375,8376]
operator: , [8381,8382]
===
match
---
atom [43137,43217]
atom [43155,43235]
===
match
---
atom_expr [2473,2539]
atom_expr [2473,2539]
===
match
---
testlist_comp [16590,16608]
testlist_comp [16608,16626]
===
match
---
operator: , [47258,47259]
operator: , [47276,47277]
===
match
---
name: mock_hvac [26812,26821]
name: mock_hvac [26830,26839]
===
match
---
name: test_radius_init_params [28872,28895]
name: test_radius_init_params [28890,28913]
===
match
---
operator: = [1462,1463]
operator: = [1462,1463]
===
match
---
name: get [4873,4876]
name: get [4873,4876]
===
match
---
operator: { [31687,31688]
operator: { [31705,31706]
===
match
---
atom_expr [37643,37675]
atom_expr [37661,37693]
===
match
---
trailer [25584,25604]
trailer [25602,25622]
===
match
---
trailer [40989,40996]
trailer [41007,41014]
===
match
---
name: mock_open [24706,24715]
name: mock_open [24724,24733]
===
match
---
argument [27475,27490]
argument [27493,27508]
===
match
---
simple_stmt [30230,30281]
simple_stmt [30248,30299]
===
match
---
atom_expr [31603,31647]
atom_expr [31621,31665]
===
match
---
atom_expr [9864,9908]
atom_expr [9876,9920]
===
match
---
name: test_client [7963,7974]
name: test_client [7963,7974]
===
match
---
operator: = [49334,49335]
operator: = [49352,49353]
===
match
---
operator: = [39292,39293]
operator: = [39310,39311]
===
match
---
operator: = [46912,46913]
operator: = [46930,46931]
===
match
---
name: mock_hvac [18385,18394]
name: mock_hvac [18403,18412]
===
match
---
string: "kv_engine_version" [47937,47956]
string: "kv_engine_version" [47955,47974]
===
match
---
testlist_comp [48353,48367]
testlist_comp [48371,48385]
===
match
---
atom_expr [7262,7278]
atom_expr [7262,7278]
===
match
---
name: mock_connection [23080,23095]
name: mock_connection [23098,23113]
===
match
---
trailer [41082,41085]
trailer [41100,41103]
===
match
---
string: "auth_mount_point" [4929,4947]
string: "auth_mount_point" [4929,4947]
===
match
---
operator: , [25833,25834]
operator: , [25851,25852]
===
match
---
operator: } [14622,14623]
operator: } [14640,14641]
===
match
---
argument [23778,23788]
argument [23796,23806]
===
match
---
simple_stmt [13074,13141]
simple_stmt [13092,13159]
===
match
---
string: "role" [8015,8021]
string: "role" [8021,8027]
===
match
---
name: kwargs [41627,41633]
name: kwargs [41645,41651]
===
match
---
argument [16541,16561]
argument [16559,16579]
===
match
---
operator: } [34789,34790]
operator: } [34807,34808]
===
match
---
simple_stmt [34800,34832]
simple_stmt [34818,34850]
===
match
---
string: "vault_conn_id" [33775,33790]
string: "vault_conn_id" [33793,33808]
===
match
---
string: 'destroyed' [39898,39909]
string: 'destroyed' [39916,39927]
===
match
---
operator: , [32408,32409]
operator: , [32426,32427]
===
match
---
decorators [2578,2835]
decorators [2578,2835]
===
match
---
operator: , [17312,17313]
operator: , [17330,17331]
===
match
---
expr_stmt [44407,44451]
expr_stmt [44425,44469]
===
match
---
dotted_name [18683,18693]
dotted_name [18701,18711]
===
match
---
name: connection_dict [45340,45355]
name: connection_dict [45358,45373]
===
match
---
operator: = [29222,29223]
operator: = [29240,29241]
===
match
---
import_from [814,839]
import_from [814,839]
===
match
---
name: test_client [35937,35948]
name: test_client [35955,35966]
===
match
---
simple_stmt [3728,3759]
simple_stmt [3728,3759]
===
match
---
trailer [38504,38508]
trailer [38522,38526]
===
match
---
name: user [1242,1246]
name: user [1242,1246]
===
match
---
name: mock_get_connection [4674,4693]
name: mock_get_connection [4674,4693]
===
match
---
name: assert_called_with [11329,11347]
name: assert_called_with [11347,11365]
===
match
---
atom_expr [31396,31428]
atom_expr [31414,31446]
===
match
---
string: 'version' [39938,39947]
string: 'version' [39956,39965]
===
match
---
trailer [47604,47606]
trailer [47622,47624]
===
match
---
trailer [13847,13860]
trailer [13865,13878]
===
match
---
string: "kube_role" [26385,26396]
string: "kube_role" [26403,26414]
===
match
---
expr_stmt [20792,20836]
expr_stmt [20810,20854]
===
match
---
string: 'data' [45769,45775]
string: 'data' [45787,45793]
===
match
---
funcdef [37514,38951]
funcdef [37532,38969]
===
match
---
atom_expr [9115,9192]
atom_expr [9121,9204]
===
match
---
argument [4195,4203]
argument [4195,4203]
===
match
---
operator: = [44531,44532]
operator: = [44549,44550]
===
match
---
dotted_name [12685,12695]
dotted_name [12703,12713]
===
match
---
operator: = [30763,30764]
operator: = [30781,30782]
===
match
---
name: extra_dejson [41445,41457]
name: extra_dejson [41463,41475]
===
match
---
operator: @ [13968,13969]
operator: @ [13986,13987]
===
match
---
dotted_name [2579,2599]
dotted_name [2579,2599]
===
match
---
name: kwargs [38551,38557]
name: kwargs [38569,38575]
===
match
---
dotted_name [8250,8260]
dotted_name [8256,8266]
===
match
---
trailer [14769,14771]
trailer [14787,14789]
===
match
---
name: role_id [9159,9166]
name: role_id [9171,9178]
===
match
---
name: get_mock_connection [46619,46638]
name: get_mock_connection [46637,46656]
===
match
---
trailer [5705,5717]
trailer [5705,5717]
===
match
---
expr_stmt [14323,14472]
expr_stmt [14341,14490]
===
match
---
operator: = [33882,33883]
operator: = [33900,33901]
===
match
---
operator: = [17406,17407]
operator: = [17424,17425]
===
match
---
trailer [27898,27905]
trailer [27916,27923]
===
match
---
operator: { [34594,34595]
operator: { [34612,34613]
===
match
---
name: mock_connection [26952,26967]
name: mock_connection [26970,26985]
===
match
---
string: "vault_conn_id" [27155,27170]
string: "vault_conn_id" [27173,27188]
===
match
---
param [19108,19129]
param [19126,19147]
===
match
---
simple_stmt [4213,4267]
simple_stmt [4213,4267]
===
match
---
operator: ** [41625,41627]
operator: ** [41643,41645]
===
match
---
name: Client [35471,35477]
name: Client [35489,35495]
===
match
---
argument [20086,20115]
argument [20104,20133]
===
match
---
simple_stmt [18078,18113]
simple_stmt [18096,18131]
===
match
---
atom_expr [7901,7954]
atom_expr [7901,7954]
===
match
---
operator: , [46969,46970]
operator: , [46987,46988]
===
match
---
param [9524,9543]
param [9536,9555]
===
match
---
string: 'data' [39700,39706]
string: 'data' [39718,39724]
===
match
---
name: case [854,858]
name: case [854,858]
===
match
---
operator: = [16000,16001]
operator: = [16018,16019]
===
match
---
name: self [31361,31365]
name: self [31379,31383]
===
match
---
trailer [2145,2165]
trailer [2145,2165]
===
match
---
trailer [21782,21792]
trailer [21800,21810]
===
match
---
decorator [20460,20540]
decorator [20478,20558]
===
match
---
operator: , [7733,7734]
operator: , [7733,7734]
===
match
---
trailer [10151,10153]
trailer [10163,10165]
===
match
---
name: self [39159,39163]
name: self [39177,39181]
===
match
---
dictorsetmaker [44910,44938]
dictorsetmaker [44928,44956]
===
match
---
trailer [44666,44686]
trailer [44684,44704]
===
match
---
name: get [4839,4842]
name: get [4839,4842]
===
match
---
name: test_hook [43227,43236]
name: test_hook [43245,43254]
===
match
---
param [2889,2899]
param [2889,2899]
===
match
---
string: "vault_conn_id" [3315,3330]
string: "vault_conn_id" [3315,3330]
===
match
---
operator: , [15959,15960]
operator: , [15977,15978]
===
match
---
simple_stmt [7410,7461]
simple_stmt [7410,7461]
===
match
---
name: patch [25237,25242]
name: patch [25255,25260]
===
match
---
simple_stmt [45368,45458]
simple_stmt [45386,45476]
===
match
---
name: assert_called_with [16645,16663]
name: assert_called_with [16663,16681]
===
match
---
trailer [35067,35069]
trailer [35085,35087]
===
match
---
trailer [46668,46681]
trailer [46686,46699]
===
match
---
trailer [7429,7442]
trailer [7429,7442]
===
match
---
string: 'data' [44901,44907]
string: 'data' [44919,44925]
===
match
---
simple_stmt [31396,31447]
simple_stmt [31414,31465]
===
match
---
string: "radius" [31501,31509]
string: "radius" [31519,31527]
===
match
---
name: mock [835,839]
name: mock [835,839]
===
match
---
operator: , [38926,38927]
operator: , [38944,38945]
===
match
---
operator: , [19074,19075]
operator: , [19092,19093]
===
match
---
operator: = [40313,40314]
operator: = [40331,40332]
===
match
---
name: secrets [47143,47150]
name: secrets [47161,47168]
===
match
---
assert_stmt [18624,18676]
assert_stmt [18642,18694]
===
match
---
argument [11392,11409]
argument [11410,11427]
===
match
---
dotted_name [21613,21623]
dotted_name [21631,21641]
===
match
---
name: mock_get_connection [37560,37579]
name: mock_get_connection [37578,37597]
===
match
---
operator: , [22172,22173]
operator: , [22190,22191]
===
match
---
name: is_authenticated [11466,11482]
name: is_authenticated [11484,11500]
===
match
---
param [1196,1212]
param [1196,1212]
===
match
---
name: Client [19205,19211]
name: Client [19223,19229]
===
match
---
decorator [18771,18875]
decorator [18789,18893]
===
match
---
simple_stmt [7470,7491]
simple_stmt [7470,7491]
===
match
---
operator: , [15575,15576]
operator: , [15593,15594]
===
match
---
expr_stmt [34724,34790]
expr_stmt [34742,34808]
===
match
---
atom [9948,10005]
atom [9960,10017]
===
match
---
trailer [16042,16046]
trailer [16060,16064]
===
match
---
trailer [47991,48001]
trailer [48009,48019]
===
match
---
funcdef [1960,2573]
funcdef [1960,2573]
===
match
---
simple_stmt [47766,47787]
simple_stmt [47784,47805]
===
match
---
name: assert_called_with [9230,9248]
name: assert_called_with [9242,9260]
===
match
---
string: "vault_conn_id" [19758,19773]
string: "vault_conn_id" [19776,19791]
===
match
---
name: test_hook [28277,28286]
name: test_hook [28295,28304]
===
match
---
name: type [1477,1481]
name: type [1477,1481]
===
match
---
name: get [7529,7532]
name: get [7529,7532]
===
match
---
name: return_value [48832,48844]
name: return_value [48850,48862]
===
match
---
atom [33511,33513]
atom [33529,33531]
===
match
---
name: MagicMock [44538,44547]
name: MagicMock [44556,44565]
===
match
---
name: mock [47394,47398]
name: mock [47412,47416]
===
match
---
trailer [2380,2384]
trailer [2380,2384]
===
match
---
name: mock [37433,37437]
name: mock [37451,37455]
===
match
---
name: get [10976,10979]
name: get [10994,10997]
===
match
---
simple_stmt [20792,20837]
simple_stmt [20810,20855]
===
match
---
param [4483,4488]
param [4483,4488]
===
match
---
name: expected_url [7193,7205]
name: expected_url [7193,7205]
===
match
---
comparison [16874,16919]
comparison [16892,16937]
===
match
---
operator: , [45272,45273]
operator: , [45290,45291]
===
match
---
atom [42597,42798]
atom [42615,42816]
===
match
---
atom_expr [19195,19224]
atom_expr [19213,19242]
===
match
---
name: credentials [18521,18532]
name: credentials [18539,18550]
===
match
---
simple_stmt [36494,36525]
simple_stmt [36512,36543]
===
match
---
trailer [30911,30928]
trailer [30929,30946]
===
match
---
name: secret_path [49323,49334]
name: secret_path [49341,49352]
===
match
---
dictorsetmaker [17985,18018]
dictorsetmaker [18003,18036]
===
match
---
decorated [9317,10432]
decorated [9329,10450]
===
match
---
operator: ** [43249,43251]
operator: ** [43267,43269]
===
match
---
decorator [25315,25393]
decorator [25333,25411]
===
match
---
name: mock_get_connection [44377,44396]
name: mock_get_connection [44395,44414]
===
match
---
name: mock [1304,1308]
name: mock [1304,1308]
===
match
---
simple_stmt [34372,34403]
simple_stmt [34390,34421]
===
match
---
name: patch [2763,2768]
name: patch [2763,2768]
===
match
---
string: "pass" [21396,21402]
string: "pass" [21414,21420]
===
match
---
name: patch [21618,21623]
name: patch [21636,21641]
===
match
---
trailer [10812,10814]
trailer [10830,10832]
===
match
---
atom_expr [47131,47303]
atom_expr [47149,47321]
===
match
---
dictorsetmaker [38084,38354]
dictorsetmaker [38102,38372]
===
match
---
operator: = [28171,28172]
operator: = [28189,28190]
===
match
---
expr_stmt [43053,43119]
expr_stmt [43071,43137]
===
match
---
string: "vault_conn_id" [7615,7630]
string: "vault_conn_id" [7615,7630]
===
match
---
operator: } [38352,38353]
operator: } [38370,38371]
===
match
---
name: mock_hvac [22805,22814]
name: mock_hvac [22823,22832]
===
match
---
name: auth [27423,27427]
name: auth [27441,27445]
===
match
---
dictorsetmaker [42619,42780]
dictorsetmaker [42637,42798]
===
match
---
trailer [28633,28635]
trailer [28651,28653]
===
match
---
simple_stmt [18566,18616]
simple_stmt [18584,18634]
===
match
---
expr_stmt [12233,12264]
expr_stmt [12251,12282]
===
match
---
expr_stmt [15909,15974]
expr_stmt [15927,15992]
===
match
---
decorator [36256,36336]
decorator [36274,36354]
===
match
---
operator: = [36506,36507]
operator: = [36524,36525]
===
match
---
name: mock [5218,5222]
name: mock [5218,5222]
===
match
---
string: "radius_host" [29310,29323]
string: "radius_host" [29328,29341]
===
match
---
name: mock_hvac [22340,22349]
name: mock_hvac [22358,22367]
===
match
---
atom_expr [6557,6576]
atom_expr [6557,6576]
===
match
---
name: mock_connection [47562,47577]
name: mock_connection [47580,47595]
===
match
---
name: mock_client [32440,32451]
name: mock_client [32458,32469]
===
match
---
atom_expr [2553,2572]
atom_expr [2553,2572]
===
match
---
simple_stmt [44460,44511]
simple_stmt [44478,44529]
===
match
---
string: "approle" [7657,7666]
string: "approle" [7657,7666]
===
match
---
trailer [15864,15877]
trailer [15882,15895]
===
match
---
simple_stmt [16364,16420]
simple_stmt [16382,16438]
===
match
---
argument [48064,48087]
argument [48082,48105]
===
match
---
name: mock_get_connection [26151,26170]
name: mock_get_connection [26169,26188]
===
match
---
operator: , [924,925]
operator: , [924,925]
===
match
---
name: url [27374,27377]
name: url [27392,27395]
===
match
---
name: v1 [41771,41773]
name: v1 [41789,41791]
===
match
---
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [25243,25309]
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [25261,25327]
===
match
---
expr_stmt [36925,36956]
expr_stmt [36943,36974]
===
match
---
operator: = [21131,21132]
operator: = [21149,21150]
===
match
---
trailer [14544,14548]
trailer [14562,14566]
===
match
---
string: "vault_conn_id" [29480,29495]
string: "vault_conn_id" [29498,29513]
===
match
---
number: 2 [28651,28652]
number: 2 [28669,28670]
===
match
---
name: azure [13582,13587]
name: azure [13600,13605]
===
match
---
name: mock_client [32511,32522]
name: mock_client [32529,32540]
===
match
---
operator: = [46307,46308]
operator: = [46325,46326]
===
match
---
simple_stmt [13385,13441]
simple_stmt [13403,13459]
===
match
---
name: side_effect [22075,22086]
name: side_effect [22093,22104]
===
match
---
operator: } [21110,21111]
operator: } [21128,21129]
===
match
---
trailer [37061,37063]
trailer [37079,37081]
===
match
---
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [38968,39034]
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [38986,39052]
===
match
---
string: "vault_conn_id" [25946,25961]
string: "vault_conn_id" [25964,25979]
===
match
---
name: connection_dict [24363,24378]
name: connection_dict [24381,24396]
===
match
---
name: connection_dict [7547,7562]
name: connection_dict [7547,7562]
===
match
---
operator: = [19388,19389]
operator: = [19406,19407]
===
match
---
name: mock_get_connection [8935,8954]
name: mock_get_connection [8941,8960]
===
match
---
operator: , [27473,27474]
operator: , [27491,27492]
===
match
---
name: assert_called_with [28615,28633]
name: assert_called_with [28633,28651]
===
match
---
trailer [25162,25164]
trailer [25180,25182]
===
match
---
name: key_path [20071,20079]
name: key_path [20089,20097]
===
match
---
funcdef [11736,12595]
funcdef [11754,12613]
===
match
---
atom_expr [28424,28488]
atom_expr [28442,28506]
===
match
---
param [7183,7192]
param [7183,7192]
===
match
---
simple_stmt [47615,47666]
simple_stmt [47633,47684]
===
match
---
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [34149,34215]
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [34167,34233]
===
match
---
name: mock_connection [46684,46699]
name: mock_connection [46702,46717]
===
match
---
name: mock_client [17465,17476]
name: mock_client [17483,17494]
===
match
---
operator: @ [9317,9318]
operator: @ [9329,9330]
===
match
---
argument [9175,9191]
argument [9187,9203]
===
match
---
param [40788,40798]
param [40806,40816]
===
match
---
atom [41711,41729]
atom [41729,41747]
===
match
---
dotted_name [36341,36351]
dotted_name [36359,36369]
===
match
---
param [15598,15619]
param [15616,15637]
===
match
---
name: extra_dejson [35672,35684]
name: extra_dejson [35690,35702]
===
match
---
atom_expr [2969,2998]
atom_expr [2969,2998]
===
match
---
simple_stmt [3292,3359]
simple_stmt [3292,3359]
===
match
---
decorators [34137,34299]
decorators [34155,34317]
===
match
---
name: mock_client [37773,37784]
name: mock_client [37791,37802]
===
match
---
operator: , [48632,48633]
operator: , [48650,48651]
===
match
---
argument [33035,33043]
argument [33053,33061]
===
match
---
name: mock [27701,27705]
name: mock [27719,27723]
===
match
---
name: test_hook [40266,40275]
name: test_hook [40284,40293]
===
match
---
name: return_value [21928,21940]
name: return_value [21946,21958]
===
match
---
name: url [26296,26299]
name: url [26314,26317]
===
match
---
trailer [33927,33944]
trailer [33945,33962]
===
match
---
decorator [44152,44232]
decorator [44170,44250]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [46443,46507]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [46461,46525]
===
match
---
assert_stmt [41704,41739]
assert_stmt [41722,41757]
===
match
---
expr_stmt [26064,26095]
expr_stmt [26082,26113]
===
match
---
name: extra_dejson [5689,5701]
name: extra_dejson [5689,5701]
===
match
---
simple_stmt [20402,20455]
simple_stmt [20420,20473]
===
match
---
name: test_client [30900,30911]
name: test_client [30918,30929]
===
match
---
operator: = [15715,15716]
operator: = [15733,15734]
===
match
---
atom_expr [23798,23847]
atom_expr [23816,23865]
===
match
---
operator: = [31359,31360]
operator: = [31377,31378]
===
match
---
atom_expr [17597,17625]
atom_expr [17615,17643]
===
match
---
name: test_client [26418,26429]
name: test_client [26436,26447]
===
match
---
trailer [13587,13597]
trailer [13605,13615]
===
match
---
operator: = [23679,23680]
operator: = [23697,23698]
===
match
---
simple_stmt [10718,10762]
simple_stmt [10736,10780]
===
match
---
operator: = [34384,34385]
operator: = [34402,34403]
===
match
---
trailer [2346,2350]
trailer [2346,2350]
===
match
---
number: 2 [43215,43216]
number: 2 [43233,43234]
===
match
---
trailer [26791,26801]
trailer [26809,26819]
===
match
---
atom_expr [47713,47742]
atom_expr [47731,47760]
===
match
---
param [22816,22835]
param [22834,22853]
===
match
---
name: assert_called_with [23741,23759]
name: assert_called_with [23759,23777]
===
match
---
operator: , [17637,17638]
operator: , [17655,17656]
===
match
---
operator: } [48887,48888]
operator: } [48905,48906]
===
match
---
name: mock_connection [28029,28044]
name: mock_connection [28047,28062]
===
match
---
param [11766,11776]
param [11784,11794]
===
match
---
trailer [29076,29078]
trailer [29094,29096]
===
match
---
simple_stmt [5386,5417]
simple_stmt [5386,5417]
===
match
---
name: extra_dejson [43069,43081]
name: extra_dejson [43087,43099]
===
match
---
string: 'http://localhost:8180' [24997,25020]
string: 'http://localhost:8180' [25015,25038]
===
match
---
name: get_secret [40325,40335]
name: get_secret [40343,40353]
===
match
---
name: mock [12854,12858]
name: mock [12872,12876]
===
match
---
string: "path" [49158,49164]
string: "path" [49176,49182]
===
match
---
trailer [23649,23656]
trailer [23667,23674]
===
match
---
operator: = [3920,3921]
operator: = [3920,3921]
===
match
---
operator: , [40071,40072]
operator: , [40089,40090]
===
match
---
expr_stmt [17538,17588]
expr_stmt [17556,17606]
===
match
---
number: 2 [43949,43950]
number: 2 [43967,43968]
===
match
---
operator: , [31209,31210]
operator: , [31227,31228]
===
match
---
name: get [32855,32858]
name: get [32873,32876]
===
match
---
operator: { [20923,20924]
operator: { [20941,20942]
===
match
---
operator: = [42184,42185]
operator: = [42202,42203]
===
match
---
name: connection_dict [12129,12144]
name: connection_dict [12147,12162]
===
match
---
name: test_hook [20414,20423]
name: test_hook [20432,20441]
===
match
---
atom_expr [16428,16479]
atom_expr [16446,16497]
===
match
---
atom_expr [36821,36840]
atom_expr [36839,36858]
===
match
---
operator: } [7743,7744]
operator: } [7743,7744]
===
match
---
string: 'http://localhost:8180' [11271,11294]
string: 'http://localhost:8180' [11289,11312]
===
match
---
dotted_name [22685,22695]
dotted_name [22703,22713]
===
match
---
trailer [26886,26906]
trailer [26904,26924]
===
match
---
name: extra_dejson [12098,12110]
name: extra_dejson [12116,12128]
===
match
---
trailer [4872,4876]
trailer [4872,4876]
===
match
---
trailer [29803,29816]
trailer [29821,29834]
===
match
---
name: mock [33304,33308]
name: mock [33322,33326]
===
match
---
name: get_conn [23465,23473]
name: get_conn [23483,23491]
===
match
---
operator: = [47089,47090]
operator: = [47107,47108]
===
match
---
operator: == [13835,13837]
operator: == [13853,13855]
===
match
---
atom_expr [42332,42391]
atom_expr [42350,42409]
===
match
---
operator: @ [3564,3565]
operator: @ [3564,3565]
===
match
---
testlist_comp [2646,2650]
testlist_comp [2646,2650]
===
match
---
atom_expr [23080,23124]
atom_expr [23098,23142]
===
match
---
name: mock_client [33361,33372]
name: mock_client [33379,33390]
===
match
---
string: "pass" [8033,8039]
string: "pass" [8039,8045]
===
match
---
operator: , [46011,46012]
operator: , [46029,46030]
===
match
---
name: test_hook [5026,5035]
name: test_hook [5026,5035]
===
match
---
simple_stmt [31901,31966]
simple_stmt [31919,31984]
===
match
---
operator: , [10636,10637]
operator: , [10654,10655]
===
match
---
atom [48071,48087]
atom [48089,48105]
===
match
---
name: test_hook [33814,33823]
name: test_hook [33832,33841]
===
match
---
name: auth [21353,21357]
name: auth [21371,21375]
===
match
---
name: assert_called_with [31814,31832]
name: assert_called_with [31832,31850]
===
match
---
simple_stmt [3407,3475]
simple_stmt [3407,3475]
===
match
---
operator: , [26730,26731]
operator: , [26748,26749]
===
match
---
operator: @ [21528,21529]
operator: @ [21546,21547]
===
match
---
trailer [45488,45498]
trailer [45506,45516]
===
match
---
operator: , [45971,45972]
operator: , [45989,45990]
===
match
---
argument [34822,34830]
argument [34840,34848]
===
match
---
operator: = [37606,37607]
operator: = [37624,37625]
===
match
---
name: return_value [47730,47742]
name: return_value [47748,47760]
===
match
---
string: "auth_type" [6466,6477]
string: "auth_type" [6466,6477]
===
match
---
operator: { [42320,42321]
operator: { [42338,42339]
===
match
---
trailer [8435,8437]
trailer [8441,8443]
===
match
---
comparison [33981,34008]
comparison [33999,34026]
===
match
---
trailer [27039,27051]
trailer [27057,27069]
===
match
---
name: patch [23920,23925]
name: patch [23938,23943]
===
match
---
name: kwargs [40290,40296]
name: kwargs [40308,40314]
===
match
---
decorated [1794,2573]
decorated [1794,2573]
===
match
---
name: parameterized [1012,1025]
name: parameterized [1012,1025]
===
match
---
trailer [21364,21370]
trailer [21382,21388]
===
match
---
operator: , [16561,16562]
operator: , [16579,16580]
===
match
---
atom_expr [30617,30672]
atom_expr [30635,30690]
===
match
---
name: is_authenticated [26430,26446]
name: is_authenticated [26448,26464]
===
match
---
operator: @ [5989,5990]
operator: @ [5989,5990]
===
match
---
trailer [2486,2539]
trailer [2486,2539]
===
match
---
trailer [13779,13796]
trailer [13797,13814]
===
match
---
trailer [49225,49233]
trailer [49243,49251]
===
match
---
trailer [47858,47862]
trailer [47876,47880]
===
match
---
atom_expr [34649,34693]
atom_expr [34667,34711]
===
match
---
string: "vault_conn_id" [14712,14727]
string: "vault_conn_id" [14730,14745]
===
match
---
operator: = [31648,31649]
operator: = [31666,31667]
===
match
---
parameters [15559,15636]
parameters [15577,15654]
===
match
---
simple_stmt [5590,5664]
simple_stmt [5590,5664]
===
match
---
operator: = [48055,48056]
operator: = [48073,48074]
===
match
---
operator: } [24668,24669]
operator: } [24686,24687]
===
match
---
name: mock_hvac [26260,26269]
name: mock_hvac [26278,26287]
===
match
---
trailer [13527,13556]
trailer [13545,13574]
===
match
---
name: assert_called_with [13797,13815]
name: assert_called_with [13815,13833]
===
match
---
name: mock_hvac [3767,3776]
name: mock_hvac [3767,3776]
===
match
---
atom [15880,15900]
atom [15898,15918]
===
match
---
name: hooks [1060,1065]
name: hooks [1060,1065]
===
match
---
name: vault_client [22564,22576]
name: vault_client [22582,22594]
===
match
---
trailer [29771,29773]
trailer [29789,29791]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [13980,14044]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [13998,14062]
===
match
---
number: 2 [23863,23864]
number: 2 [23881,23882]
===
match
---
atom [3152,3207]
atom [3152,3207]
===
match
---
name: VaultHook [3379,3388]
name: VaultHook [3379,3388]
===
match
---
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [5145,5211]
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [5145,5211]
===
match
---
string: 'path' [49335,49341]
string: 'path' [49353,49359]
===
match
---
name: test_client [19851,19862]
name: test_client [19869,19880]
===
match
---
operator: = [24228,24229]
operator: = [24246,24247]
===
match
---
operator: , [32041,32042]
operator: , [32059,32060]
===
match
---
name: assert_called_with [20267,20285]
name: assert_called_with [20285,20303]
===
match
---
simple_stmt [35626,35647]
simple_stmt [35644,35665]
===
match
---
atom [20099,20115]
atom [20117,20133]
===
match
---
atom_expr [30195,30221]
atom_expr [30213,30239]
===
match
---
name: mock_connection [1286,1301]
name: mock_connection [1286,1301]
===
match
---
decorated [1126,1789]
decorated [1126,1789]
===
match
---
atom_expr [29177,29221]
atom_expr [29195,29239]
===
match
---
arglist [41810,41846]
arglist [41828,41864]
===
match
---
name: get_conn [18102,18110]
name: get_conn [18120,18128]
===
match
---
trailer [7881,7890]
trailer [7881,7890]
===
match
---
param [9513,9523]
param [9525,9535]
===
match
---
operator: @ [22600,22601]
operator: @ [22618,22619]
===
match
---
atom_expr [40980,41009]
atom_expr [40998,41027]
===
match
---
name: test_client [10321,10332]
name: test_client [10339,10350]
===
match
---
suite [12831,13879]
suite [12849,13897]
===
match
---
name: mock_get_connection [6374,6393]
name: mock_get_connection [6374,6393]
===
match
---
simple_stmt [41704,41740]
simple_stmt [41722,41758]
===
match
---
atom_expr [33916,33965]
atom_expr [33934,33983]
===
match
---
string: 'request_id' [44716,44728]
string: 'request_id' [44734,44746]
===
match
---
operator: = [35491,35492]
operator: = [35509,35510]
===
match
---
string: "vault_conn_id" [8756,8771]
string: "vault_conn_id" [8762,8777]
===
match
---
name: protocol [7183,7191]
name: protocol [7183,7191]
===
match
---
simple_stmt [27941,27986]
simple_stmt [27959,28004]
===
match
---
dotted_name [37349,37359]
dotted_name [37367,37377]
===
match
---
atom_expr [44016,44146]
atom_expr [44034,44164]
===
match
---
operator: = [18332,18333]
operator: = [18350,18351]
===
match
---
atom_expr [39357,39386]
atom_expr [39375,39404]
===
match
---
operator: == [6745,6747]
operator: == [6745,6747]
===
match
---
parameters [20653,20691]
parameters [20671,20709]
===
match
---
operator: { [43137,43138]
operator: { [43155,43156]
===
match
---
trailer [13366,13376]
trailer [13384,13394]
===
match
---
trailer [26379,26409]
trailer [26397,26427]
===
match
---
trailer [13136,13140]
trailer [13154,13158]
===
match
---
operator: , [17323,17324]
operator: , [17341,17342]
===
match
---
dictorsetmaker [19526,19640]
dictorsetmaker [19544,19658]
===
match
---
decorated [40587,41848]
decorated [40605,41866]
===
match
---
name: test_client [25030,25041]
name: test_client [25048,25059]
===
match
---
operator: , [2000,2001]
operator: , [2000,2001]
===
match
---
suite [15637,16920]
suite [15655,16938]
===
match
---
operator: { [39501,39502]
operator: { [39519,39520]
===
match
---
operator: { [37812,37813]
operator: { [37830,37831]
===
match
---
simple_stmt [23441,23476]
simple_stmt [23459,23494]
===
match
---
name: patch [6999,7004]
name: patch [6999,7004]
===
match
---
operator: = [36601,36602]
operator: = [36619,36620]
===
match
---
suite [4521,5128]
suite [4521,5128]
===
match
---
operator: , [14375,14376]
operator: , [14393,14394]
===
match
---
name: mock_connection [44407,44422]
name: mock_connection [44425,44440]
===
match
---
simple_stmt [3819,3879]
simple_stmt [3819,3879]
===
match
---
trailer [10413,10431]
trailer [10431,10449]
===
match
---
name: connection_dict [22089,22104]
name: connection_dict [22107,22122]
===
match
---
name: return_value [39279,39291]
name: return_value [39297,39309]
===
match
---
string: "aws_iam" [12043,12052]
string: "aws_iam" [12061,12070]
===
match
---
atom_expr [11846,11875]
atom_expr [11864,11893]
===
match
---
simple_stmt [41748,41848]
simple_stmt [41766,41866]
===
match
---
string: '94011e25-f8dc-ec29-221b-1f9c1d9ad2ae' [39529,39567]
string: '94011e25-f8dc-ec29-221b-1f9c1d9ad2ae' [39547,39585]
===
match
---
operator: = [28955,28956]
operator: = [28973,28974]
===
match
---
trailer [26140,26142]
trailer [26158,26160]
===
match
---
name: get [24552,24555]
name: get [24570,24573]
===
match
---
decorated [11570,12595]
decorated [11588,12613]
===
match
---
name: MagicMock [47693,47702]
name: MagicMock [47711,47720]
===
match
---
name: mock_hvac [8446,8455]
name: mock_hvac [8452,8461]
===
match
---
string: 'warnings' [45230,45240]
string: 'warnings' [45248,45258]
===
match
---
testlist_comp [6890,6921]
testlist_comp [6890,6921]
===
match
---
operator: , [41281,41282]
operator: , [41299,41300]
===
match
---
name: self [47580,47584]
name: self [47598,47602]
===
match
---
operator: , [40045,40046]
operator: , [40063,40064]
===
match
---
name: mock_get_connection [10055,10074]
name: mock_get_connection [10067,10086]
===
match
---
dotted_name [47394,47404]
dotted_name [47412,47422]
===
match
---
simple_stmt [22297,22332]
simple_stmt [22315,22350]
===
match
---
name: MagicMock [26792,26801]
name: MagicMock [26810,26819]
===
match
---
name: return_value [20757,20769]
name: return_value [20775,20787]
===
match
---
name: test_create_or_update_secret_v2_cas [47479,47514]
name: test_create_or_update_secret_v2_cas [47497,47532]
===
match
---
atom_expr [41063,41113]
atom_expr [41081,41131]
===
match
---
atom_expr [18458,18557]
atom_expr [18476,18575]
===
match
---
operator: = [20808,20809]
operator: = [20826,20827]
===
match
---
name: kv_engine_version [16902,16919]
name: kv_engine_version [16920,16937]
===
match
---
string: 'auth' [38443,38449]
string: 'auth' [38461,38467]
===
match
---
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [11582,11648]
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [11600,11666]
===
match
---
operator: , [9843,9844]
operator: , [9855,9856]
===
match
---
name: test_client [28586,28597]
name: test_client [28604,28615]
===
match
---
string: 'http://localhost:8180' [16668,16691]
string: 'http://localhost:8180' [16686,16709]
===
match
---
trailer [23576,23631]
trailer [23594,23649]
===
match
---
string: "scope1,scope2" [18220,18235]
string: "scope1,scope2" [18238,18253]
===
match
---
simple_stmt [8049,8099]
simple_stmt [8055,8105]
===
match
---
name: mock_hvac [6189,6198]
name: mock_hvac [6189,6198]
===
match
---
operator: , [18017,18018]
operator: , [18035,18036]
===
match
---
operator: = [10025,10026]
operator: = [10037,10038]
===
match
---
simple_stmt [34904,34939]
simple_stmt [34922,34957]
===
match
---
operator: = [17626,17627]
operator: = [17644,17645]
===
match
---
atom_expr [27411,27491]
atom_expr [27429,27509]
===
match
---
atom_expr [46649,46681]
atom_expr [46667,46699]
===
match
---
name: connection_dict [8688,8703]
name: connection_dict [8694,8709]
===
match
---
name: mock_connection [14298,14313]
name: mock_connection [14316,14331]
===
match
---
name: return_value [1589,1601]
name: return_value [1589,1601]
===
match
---
name: self [35375,35379]
name: self [35393,35397]
===
match
---
atom_expr [15126,15166]
atom_expr [15144,15184]
===
match
---
trailer [47180,47204]
trailer [47198,47222]
===
match
---
operator: = [36563,36564]
operator: = [36581,36582]
===
match
---
operator: = [9081,9082]
operator: = [9087,9088]
===
match
---
dictorsetmaker [24395,24469]
dictorsetmaker [24413,24487]
===
match
---
name: mock_client [20701,20712]
name: mock_client [20719,20730]
===
match
---
name: mock_hvac [9593,9602]
name: mock_hvac [9605,9614]
===
match
---
decorator [17122,17202]
decorator [17140,17220]
===
match
---
trailer [48127,48130]
trailer [48145,48148]
===
match
---
trailer [48686,48706]
trailer [48704,48724]
===
match
---
trailer [40466,40486]
trailer [40484,40504]
===
match
---
name: mock_get_connection [26743,26762]
name: mock_get_connection [26761,26780]
===
match
---
string: '2020-03-16T21:01:43.331126Z' [38190,38219]
string: '2020-03-16T21:01:43.331126Z' [38208,38237]
===
match
---
name: connection_dict [5720,5735]
name: connection_dict [5720,5735]
===
match
---
trailer [9248,9250]
trailer [9260,9262]
===
match
---
name: return_value [35586,35598]
name: return_value [35604,35616]
===
match
---
name: mock_file [26041,26050]
name: mock_file [26059,26068]
===
match
---
expr_stmt [45368,45457]
expr_stmt [45386,45475]
===
match
---
operator: @ [37348,37349]
operator: @ [37366,37367]
===
match
---
operator: , [38300,38301]
operator: , [38318,38319]
===
match
---
operator: = [40845,40846]
operator: = [40863,40864]
===
match
---
name: mock [23999,24003]
name: mock [24017,24021]
===
match
---
name: mock_hvac [46747,46756]
name: mock_hvac [46765,46774]
===
match
---
name: patch [16931,16936]
name: patch [16949,16954]
===
match
---
trailer [9717,9730]
trailer [9729,9742]
===
match
---
atom_expr [44641,44699]
atom_expr [44659,44717]
===
match
---
simple_stmt [5748,5815]
simple_stmt [5748,5815]
===
match
---
name: kwargs [23421,23427]
name: kwargs [23439,23445]
===
match
---
trailer [8128,8141]
trailer [8134,8147]
===
match
---
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [47321,47387]
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [47339,47405]
===
match
---
argument [40546,40560]
argument [40564,40578]
===
match
---
string: 'scope2' [16600,16608]
string: 'scope2' [16618,16626]
===
match
---
name: mock_connection [7500,7515]
name: mock_connection [7500,7515]
===
match
---
name: extra_dejson [38492,38504]
name: extra_dejson [38510,38522]
===
match
---
name: password [1675,1683]
name: password [1675,1683]
===
match
---
name: mock_connection [41429,41444]
name: mock_connection [41447,41462]
===
match
---
operator: , [12527,12528]
operator: , [12545,12546]
===
match
---
trailer [5904,5916]
trailer [5904,5916]
===
match
---
operator: @ [8249,8250]
operator: @ [8255,8256]
===
match
---
trailer [23826,23845]
trailer [23844,23863]
===
match
---
name: kwargs [13369,13375]
name: kwargs [13387,13393]
===
match
---
name: extra_dejson [47812,47824]
name: extra_dejson [47830,47842]
===
match
---
atom_expr [40441,40581]
atom_expr [40459,40599]
===
match
---
string: "scope1,scope2" [16463,16478]
string: "scope1,scope2" [16481,16496]
===
match
---
expr_stmt [13074,13140]
expr_stmt [13092,13158]
===
match
---
name: test_get_secret_including_metadata_v2 [44322,44359]
name: test_get_secret_including_metadata_v2 [44340,44377]
===
match
---
trailer [48831,48844]
trailer [48849,48862]
===
match
---
name: mock_client [48105,48116]
name: mock_client [48123,48134]
===
match
---
operator: , [8771,8772]
operator: , [8777,8778]
===
match
---
simple_stmt [6510,6577]
simple_stmt [6510,6577]
===
match
---
expr_stmt [20935,21001]
expr_stmt [20953,21019]
===
match
---
operator: , [41568,41569]
operator: , [41586,41587]
===
match
---
expr_stmt [4530,4560]
expr_stmt [4530,4560]
===
match
---
simple_stmt [10162,10227]
simple_stmt [10174,10239]
===
match
---
simple_stmt [4674,4725]
simple_stmt [4674,4725]
===
match
---
operator: = [24171,24172]
operator: = [24189,24190]
===
match
---
name: return_value [7304,7316]
name: return_value [7304,7316]
===
match
---
decorator [11570,11650]
decorator [11588,11668]
===
match
---
trailer [35031,35048]
trailer [35049,35066]
===
match
---
arglist [32027,32067]
arglist [32045,32085]
===
match
---
simple_stmt [38751,38799]
simple_stmt [38769,38817]
===
match
---
simple_stmt [36638,36689]
simple_stmt [36656,36707]
===
match
---
trailer [35892,35911]
trailer [35910,35929]
===
match
---
name: mock_client [12911,12922]
name: mock_client [12929,12940]
===
match
---
name: test_radius_dejson [31186,31204]
name: test_radius_dejson [31204,31222]
===
match
---
trailer [10697,10707]
trailer [10715,10725]
===
match
---
operator: , [23203,23204]
operator: , [23221,23222]
===
match
---
atom_expr [38807,38950]
atom_expr [38825,38968]
===
match
---
name: mock_get_connection [25615,25634]
name: mock_get_connection [25633,25652]
===
match
---
string: "2" [2624,2627]
string: "2" [2624,2627]
===
match
---
string: 'key' [47268,47273]
string: 'key' [47286,47291]
===
match
---
trailer [27035,27039]
trailer [27053,27057]
===
match
---
expr_stmt [42302,42322]
expr_stmt [42320,42340]
===
match
---
atom_expr [10235,10312]
atom_expr [10247,10330]
===
match
---
name: mock [12601,12605]
name: mock [12619,12623]
===
match
---
string: "tenant_id" [14408,14419]
string: "tenant_id" [14426,14437]
===
match
---
dictorsetmaker [12030,12071]
dictorsetmaker [12048,12089]
===
match
---
trailer [22349,22356]
trailer [22367,22374]
===
match
---
name: get_mock_connection [5500,5519]
name: get_mock_connection [5500,5519]
===
match
---
trailer [16901,16919]
trailer [16919,16937]
===
match
---
string: 'lease_duration' [43486,43502]
string: 'lease_duration' [43504,43520]
===
match
---
argument [45489,45497]
argument [45507,45515]
===
match
---
trailer [34956,34963]
trailer [34974,34981]
===
match
---
expr_stmt [40306,40376]
expr_stmt [40324,40394]
===
match
---
trailer [3746,3756]
trailer [3746,3756]
===
match
---
name: mock_hvac [28424,28433]
name: mock_hvac [28442,28451]
===
match
---
suite [28934,29835]
suite [28952,29853]
===
match
---
operator: , [15596,15597]
operator: , [15614,15615]
===
match
---
operator: { [41116,41117]
operator: { [41134,41135]
===
match
---
string: "data" [23362,23368]
string: "data" [23380,23386]
===
match
---
name: mock_get_connection [27820,27839]
name: mock_get_connection [27838,27857]
===
match
---
expr_stmt [37824,38466]
expr_stmt [37842,38484]
===
match
---
simple_stmt [12157,12224]
simple_stmt [12175,12242]
===
match
---
name: mock_connection [40092,40107]
name: mock_connection [40110,40125]
===
match
---
dictorsetmaker [43360,43985]
dictorsetmaker [43378,44003]
===
match
---
name: self [28896,28900]
name: self [28914,28918]
===
match
---
operator: { [39682,39683]
operator: { [39700,39701]
===
match
---
trailer [22424,22429]
trailer [22442,22447]
===
match
---
name: mock_hvac [22885,22894]
name: mock_hvac [22903,22912]
===
match
---
operator: , [13748,13749]
operator: , [13766,13767]
===
match
---
operator: = [15943,15944]
operator: = [15961,15962]
===
match
---
name: test_client [28497,28508]
name: test_client [28515,28526]
===
match
---
name: mock_connection [36774,36789]
name: mock_connection [36792,36807]
===
match
---
simple_stmt [29548,29613]
simple_stmt [29566,29631]
===
match
---
argument [31776,31784]
argument [31794,31802]
===
match
---
simple_stmt [35980,36045]
simple_stmt [35998,36063]
===
match
---
trailer [26344,26360]
trailer [26362,26378]
===
match
---
trailer [9058,9077]
trailer [9064,9083]
===
match
---
string: 'destroyed' [42946,42957]
string: 'destroyed' [42964,42975]
===
match
---
expr_stmt [45293,45359]
expr_stmt [45311,45377]
===
match
---
simple_stmt [933,947]
simple_stmt [933,947]
===
match
---
trailer [9212,9229]
trailer [9224,9241]
===
match
---
atom [41051,41053]
atom [41069,41071]
===
match
---
expr_stmt [34516,34566]
expr_stmt [34534,34584]
===
match
---
simple_stmt [31343,31388]
simple_stmt [31361,31406]
===
match
---
simple_stmt [16701,16801]
simple_stmt [16719,16819]
===
match
---
simple_stmt [22846,22877]
simple_stmt [22864,22895]
===
match
---
name: mock_get_connection [22233,22252]
name: mock_get_connection [22251,22270]
===
match
---
atom [19744,19801]
atom [19762,19819]
===
match
---
operator: = [14995,14996]
operator: = [15013,15014]
===
match
---
simple_stmt [947,986]
simple_stmt [947,986]
===
match
---
string: "kubernetes_role" [25803,25820]
string: "kubernetes_role" [25821,25838]
===
match
---
string: "gcp_key_path" [17796,17810]
string: "gcp_key_path" [17814,17828]
===
match
---
assert_stmt [11512,11564]
assert_stmt [11530,11582]
===
match
---
simple_stmt [49072,49104]
simple_stmt [49090,49122]
===
match
---
name: auth_approle [7975,7987]
name: approle [7980,7987]
===
match
---
name: connection_dict [17934,17949]
name: connection_dict [17952,17967]
===
match
---
operator: } [41592,41593]
operator: } [41610,41611]
===
match
---
operator: = [28027,28028]
operator: = [28045,28046]
===
match
---
name: assert_called_with [21181,21199]
name: assert_called_with [21199,21217]
===
match
---
comparison [10386,10431]
comparison [10404,10449]
===
match
---
trailer [37279,37281]
trailer [37297,37299]
===
match
---
expr_stmt [17732,17877]
expr_stmt [17750,17895]
===
match
---
name: return_value [33346,33358]
name: return_value [33364,33376]
===
match
---
expr_stmt [22937,22981]
expr_stmt [22955,22999]
===
match
---
simple_stmt [12840,12871]
simple_stmt [12858,12889]
===
match
---
simple_stmt [38690,38743]
simple_stmt [38708,38761]
===
match
---
name: connection_dict [23127,23142]
name: connection_dict [23145,23160]
===
match
---
arglist [27458,27490]
arglist [27476,27508]
===
match
---
string: "radius_host" [31523,31536]
string: "radius_host" [31541,31554]
===
match
---
comparison [30965,31010]
comparison [30983,31028]
===
match
---
name: test_hook [7754,7763]
name: test_hook [7754,7763]
===
match
---
dictorsetmaker [43571,43732]
dictorsetmaker [43589,43750]
===
match
---
atom_expr [37043,37063]
atom_expr [37061,37081]
===
match
---
name: patch [40593,40598]
name: patch [40611,40616]
===
match
---
name: mock_hvac [11766,11775]
name: mock_hvac [11784,11793]
===
match
---
trailer [49287,49400]
trailer [49305,49418]
===
match
---
operator: = [22915,22916]
operator: = [22933,22934]
===
match
---
dotted_name [11655,11665]
dotted_name [11673,11683]
===
match
---
name: connection_dict [3134,3149]
name: connection_dict [3134,3149]
===
match
---
trailer [20749,20756]
trailer [20767,20774]
===
match
---
operator: @ [26534,26535]
operator: @ [26552,26553]
===
match
---
name: get [24518,24521]
name: get [24536,24539]
===
match
---
expr_stmt [12879,12922]
expr_stmt [12897,12940]
===
match
---
name: vault_client [35143,35155]
name: vault_client [35161,35173]
===
match
---
expr_stmt [14210,14254]
expr_stmt [14228,14272]
===
match
---
name: test_hook [5882,5891]
name: test_hook [5882,5891]
===
match
---
operator: } [2307,2308]
operator: } [2307,2308]
===
match
---
operator: , [24116,24117]
operator: , [24134,24135]
===
match
---
string: "kv_engine_version" [2280,2299]
string: "kv_engine_version" [2280,2299]
===
match
---
trailer [48794,48804]
trailer [48812,48822]
===
match
---
simple_stmt [7287,7331]
simple_stmt [7287,7331]
===
match
---
string: "custom" [4220,4228]
string: "custom" [4220,4228]
===
match
---
param [2862,2870]
param [2862,2870]
===
match
---
operator: = [22309,22310]
operator: = [22327,22328]
===
match
---
number: 8123 [32063,32067]
number: 8123 [32081,32085]
===
match
---
atom [16589,16609]
atom [16607,16627]
===
match
---
trailer [8656,8669]
trailer [8662,8675]
===
match
---
name: kwargs [9939,9945]
name: kwargs [9951,9957]
===
match
---
operator: } [47282,47283]
operator: } [47300,47301]
===
match
---
string: "vault_conn_id" [28356,28371]
string: "vault_conn_id" [28374,28389]
===
match
---
expr_stmt [21225,21259]
expr_stmt [21243,21277]
===
match
---
trailer [39459,39462]
trailer [39477,39480]
===
match
---
operator: { [38152,38153]
operator: { [38170,38171]
===
match
---
simple_stmt [25471,25502]
simple_stmt [25489,25520]
===
match
---
argument [1737,1756]
argument [1737,1756]
===
match
---
operator: = [17691,17692]
operator: = [17709,17710]
===
match
---
simple_stmt [21010,21112]
simple_stmt [21028,21130]
===
match
---
name: mock_hvac [47713,47722]
name: mock_hvac [47731,47740]
===
match
---
param [31222,31241]
param [31240,31259]
===
match
---
string: "token" [46962,46969]
string: "token" [46980,46987]
===
match
---
operator: , [38368,38369]
operator: , [38386,38387]
===
match
---
name: test_radius_init_params_port [30010,30038]
name: test_radius_init_params_port [30028,30056]
===
match
---
name: mock_client [14119,14130]
name: mock_client [14137,14148]
===
match
---
name: kv [49234,49236]
name: kv [49252,49254]
===
match
---
trailer [16731,16750]
trailer [16749,16768]
===
match
---
argument [7382,7400]
argument [7382,7400]
===
match
---
trailer [1333,1350]
trailer [1333,1350]
===
match
---
argument [38720,38741]
argument [38738,38759]
===
match
---
name: side_effect [29210,29221]
name: side_effect [29228,29239]
===
match
---
expr_stmt [7248,7278]
expr_stmt [7248,7278]
===
match
---
operator: , [46564,46565]
operator: , [46582,46583]
===
match
---
trailer [13472,13481]
trailer [13490,13499]
===
match
---
atom [17971,18028]
atom [17989,18046]
===
match
---
trailer [37612,37632]
trailer [37630,37650]
===
match
---
operator: , [42553,42554]
operator: , [42571,42572]
===
match
---
operator: @ [47309,47310]
operator: @ [47327,47328]
===
match
---
trailer [41085,41088]
trailer [41103,41106]
===
match
---
atom_expr [34481,34507]
atom_expr [34499,34525]
===
match
---
assert_stmt [5863,5916]
assert_stmt [5863,5916]
===
match
---
name: test_radius_dejson_wrong_port [32363,32392]
name: test_radius_dejson_wrong_port [32381,32410]
===
match
---
expr_stmt [38476,38542]
expr_stmt [38494,38560]
===
match
---
operator: = [3740,3741]
operator: = [3740,3741]
===
match
---
string: "auth_type" [35775,35786]
string: "auth_type" [35793,35804]
===
match
---
operator: , [37205,37206]
operator: , [37223,37224]
===
match
---
expr_stmt [7287,7330]
expr_stmt [7287,7330]
===
match
---
string: "auth_type" [3979,3990]
string: "auth_type" [3979,3990]
===
match
---
atom_expr [27338,27402]
atom_expr [27356,27420]
===
match
---
param [31205,31210]
param [31223,31228]
===
match
---
atom_expr [18185,18236]
atom_expr [18203,18254]
===
match
---
expr_stmt [42332,43043]
expr_stmt [42350,43061]
===
match
---
name: patch [48480,48485]
name: patch [48498,48503]
===
match
---
expr_stmt [6434,6500]
expr_stmt [6434,6500]
===
match
---
atom_expr [26812,26841]
atom_expr [26830,26859]
===
match
---
operator: { [41303,41304]
operator: { [41321,41322]
===
match
---
trailer [41767,41770]
trailer [41785,41788]
===
match
---
argument [1450,1467]
argument [1450,1467]
===
match
---
name: get [35719,35722]
name: get [35737,35740]
===
match
---
atom_expr [17408,17424]
atom_expr [17426,17442]
===
match
---
string: "pass" [27484,27490]
string: "pass" [27502,27508]
===
match
---
decorated [44152,46342]
decorated [44170,46360]
===
match
---
decorator [37348,37428]
decorator [37366,37446]
===
match
---
comparison [41711,41739]
comparison [41729,41757]
===
match
---
trailer [23877,23890]
trailer [23895,23908]
===
match
---
name: expected_method [49375,49390]
name: expected_method [49393,49408]
===
match
---
atom_expr [11821,11837]
atom_expr [11839,11855]
===
match
---
name: extra_dejson [13090,13102]
name: extra_dejson [13108,13120]
===
match
---
operator: { [45777,45778]
operator: { [45795,45796]
===
match
---
name: mock_connection [5673,5688]
name: mock_connection [5673,5688]
===
match
---
atom_expr [29621,29715]
atom_expr [29639,29733]
===
match
---
string: "vault_conn_id" [17985,18000]
string: "vault_conn_id" [18003,18018]
===
match
---
number: 2 [18631,18632]
number: 2 [18649,18650]
===
match
---
atom [12166,12223]
atom [12184,12241]
===
match
---
trailer [4643,4663]
trailer [4643,4663]
===
match
---
trailer [34485,34505]
trailer [34503,34523]
===
match
---
string: 'renewable' [44810,44821]
string: 'renewable' [44828,44839]
===
match
---
name: mock_get_connection [21734,21753]
name: mock_get_connection [21752,21771]
===
match
---
atom_expr [1363,1399]
atom_expr [1363,1399]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [17218,17282]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [17236,17300]
===
match
---
name: connection_dict [35626,35641]
name: connection_dict [35644,35659]
===
match
---
operator: == [35092,35094]
operator: == [35110,35112]
===
match
---
trailer [28678,28696]
trailer [28696,28714]
===
match
---
name: test_hook [7872,7881]
name: test_hook [7872,7881]
===
match
---
param [12793,12798]
param [12811,12816]
===
match
---
operator: = [38521,38522]
operator: = [38539,38540]
===
match
---
string: "vault_conn_id" [8739,8754]
string: "vault_conn_id" [8745,8760]
===
match
---
name: extra_dejson [10929,10941]
name: extra_dejson [10947,10959]
===
match
---
trailer [1498,1503]
trailer [1498,1503]
===
match
---
trailer [48043,48096]
trailer [48061,48114]
===
match
---
name: get [36803,36806]
name: get [36821,36824]
===
match
---
name: mock_hvac [14158,14167]
name: mock_hvac [14176,14185]
===
match
---
name: mock [889,893]
name: mock [889,893]
===
match
---
string: 'created_time' [43790,43804]
string: 'created_time' [43808,43822]
===
match
---
name: mount_point [49301,49312]
name: mount_point [49319,49330]
===
match
---
decorated [8165,9312]
decorated [8171,9324]
===
match
---
operator: = [2044,2045]
operator: = [2044,2045]
===
match
---
simple_stmt [3217,3284]
simple_stmt [3217,3284]
===
match
---
expr_stmt [21764,21794]
expr_stmt [21782,21812]
===
match
---
name: mock_connection [29122,29137]
name: mock_connection [29140,29155]
===
match
---
name: mock_hvac [39165,39174]
name: mock_hvac [39183,39192]
===
match
---
simple_stmt [26333,26410]
simple_stmt [26351,26428]
===
match
---
name: test_version_not_int [1964,1984]
name: test_version_not_int [1964,1984]
===
match
---
atom_expr [27054,27073]
atom_expr [27072,27091]
===
match
---
argument [38890,38910]
argument [38908,38928]
===
match
---
simple_stmt [9645,9690]
simple_stmt [9657,9702]
===
match
---
dotted_name [33135,33145]
dotted_name [33153,33163]
===
match
---
trailer [23809,23826]
trailer [23827,23844]
===
match
---
funcdef [22766,23909]
funcdef [22784,23927]
===
match
---
trailer [39485,39498]
trailer [39503,39516]
===
match
---
atom_expr [24683,24734]
atom_expr [24701,24752]
===
match
---
name: patch [7083,7088]
name: patch [7083,7088]
===
match
---
atom [47105,47121]
atom [47123,47139]
===
match
---
string: "auth_type" [12030,12041]
string: "auth_type" [12048,12059]
===
match
---
expr_stmt [8446,8489]
expr_stmt [8452,8495]
===
match
---
atom_expr [23868,23908]
atom_expr [23886,23926]
===
match
---
operator: == [27567,27569]
operator: == [27585,27587]
===
match
---
operator: , [11409,11410]
operator: , [11427,11428]
===
match
---
name: test_github_dejson [21698,21716]
name: test_github_dejson [21716,21734]
===
match
---
name: self [15755,15759]
name: self [15773,15777]
===
match
---
name: read_data [23352,23361]
name: read_data [23370,23379]
===
match
---
trailer [44038,44041]
trailer [44056,44059]
===
match
---
operator: } [45832,45833]
operator: } [45850,45851]
===
match
---
atom_expr [30320,30364]
atom_expr [30338,30382]
===
match
---
name: expand [48296,48302]
name: expand [48314,48320]
===
match
---
atom_expr [21778,21794]
atom_expr [21796,21812]
===
match
---
name: test_client [26108,26119]
name: test_client [26126,26137]
===
match
---
name: pytest [940,946]
name: pytest [940,946]
===
match
---
simple_stmt [30125,30169]
simple_stmt [30143,30187]
===
match
---
name: mock_client [22846,22857]
name: mock_client [22864,22875]
===
match
---
simple_stmt [28201,28268]
simple_stmt [28219,28286]
===
match
---
name: mock_client [38807,38818]
name: mock_client [38825,38836]
===
match
---
name: connection_dict [7470,7485]
name: connection_dict [7470,7485]
===
match
---
expr_stmt [46649,46699]
expr_stmt [46667,46717]
===
match
---
name: secrets [42344,42351]
name: secrets [42362,42369]
===
match
---
name: mock_get_connection [5530,5549]
name: mock_get_connection [5530,5549]
===
match
---
trailer [33423,33425]
trailer [33441,33443]
===
match
---
simple_stmt [814,840]
simple_stmt [814,840]
===
match
---
operator: @ [37432,37433]
operator: @ [37450,37451]
===
match
---
name: mock [37349,37353]
name: mock [37367,37371]
===
match
---
simple_stmt [25780,25973]
simple_stmt [25798,25991]
===
match
---
name: mock_connection [20935,20950]
name: mock_connection [20953,20968]
===
match
---
simple_stmt [6230,6261]
simple_stmt [6230,6261]
===
match
---
trailer [7813,7832]
trailer [7813,7832]
===
match
---
trailer [20436,20454]
trailer [20454,20472]
===
match
---
argument [23760,23776]
argument [23778,23794]
===
match
---
trailer [25767,25771]
trailer [25785,25789]
===
match
---
operator: , [25876,25877]
operator: , [25894,25895]
===
match
---
atom_expr [3434,3474]
atom_expr [3434,3474]
===
match
---
name: return_value [39374,39386]
name: return_value [39392,39404]
===
match
---
trailer [13501,13508]
trailer [13519,13526]
===
match
---
name: test_client [7858,7869]
name: test_client [7858,7869]
===
match
---
trailer [31832,31849]
trailer [31850,31867]
===
match
---
name: get [30349,30352]
name: get [30367,30370]
===
match
---
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [35191,35257]
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [35209,35275]
===
match
---
name: self [7177,7181]
name: self [7177,7181]
===
match
---
string: "auth_type" [3153,3164]
string: "auth_type" [3153,3164]
===
match
---
atom [12029,12072]
atom [12047,12090]
===
match
---
operator: } [31743,31744]
operator: } [31761,31762]
===
match
---
param [32399,32409]
param [32417,32427]
===
match
---
string: "radius" [29288,29296]
string: "radius" [29306,29314]
===
match
---
string: 'lease_id' [45676,45686]
string: 'lease_id' [45694,45704]
===
match
---
expr_stmt [25675,25695]
expr_stmt [25693,25713]
===
match
---
expr_stmt [16014,16080]
expr_stmt [16032,16098]
===
match
---
operator: , [41352,41353]
operator: , [41370,41371]
===
match
---
operator: , [45690,45691]
operator: , [45708,45709]
===
match
---
simple_stmt [48868,48889]
simple_stmt [48886,48907]
===
match
---
operator: , [20669,20670]
operator: , [20687,20688]
===
match
---
trailer [15084,15103]
trailer [15102,15121]
===
match
---
operator: = [3262,3263]
operator: = [3262,3263]
===
match
---
arglist [11361,11435]
arglist [11379,11453]
===
match
---
expr_stmt [18038,18069]
expr_stmt [18056,18087]
===
match
---
atom_expr [33569,33588]
atom_expr [33587,33606]
===
match
---
trailer [8673,8685]
trailer [8679,8691]
===
match
---
name: mock_client [4601,4612]
name: mock_client [4601,4612]
===
match
---
string: "gcp" [19539,19544]
string: "gcp" [19557,19562]
===
match
---
operator: = [26384,26385]
operator: = [26402,26403]
===
match
---
expr_stmt [48664,48708]
expr_stmt [48682,48726]
===
match
---
expr_stmt [19660,19726]
expr_stmt [19678,19744]
===
match
---
simple_stmt [47562,47607]
simple_stmt [47580,47625]
===
match
---
simple_stmt [14853,15048]
simple_stmt [14871,15066]
===
match
---
string: 'lease_duration' [39641,39657]
string: 'lease_duration' [39659,39675]
===
match
---
expr_stmt [20845,20895]
expr_stmt [20863,20913]
===
match
---
operator: , [9511,9512]
operator: , [9523,9524]
===
match
---
trailer [48154,48178]
trailer [48172,48196]
===
match
---
trailer [22979,22981]
trailer [22997,22999]
===
match
---
param [17308,17313]
param [17326,17331]
===
match
---
atom_expr [44425,44451]
atom_expr [44443,44469]
===
match
---
trailer [41672,41695]
trailer [41690,41713]
===
match
---
operator: = [30885,30886]
operator: = [30903,30904]
===
match
---
operator: = [42279,42280]
operator: = [42297,42298]
===
match
---
simple_stmt [48898,48965]
simple_stmt [48916,48983]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [39052,39116]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [39070,39134]
===
match
---
string: 'key' [48242,48247]
string: 'key' [48260,48265]
===
match
---
operator: , [44120,44121]
operator: , [44138,44139]
===
match
---
atom_expr [42116,42142]
atom_expr [42134,42160]
===
match
---
name: mock_client [6301,6312]
name: mock_client [6301,6312]
===
match
---
string: 'secret_key' [38759,38771]
string: 'secret_key' [38777,38789]
===
match
---
expr_stmt [24250,24294]
expr_stmt [24268,24312]
===
match
---
name: mock_client [9625,9636]
name: mock_client [9637,9648]
===
match
---
decorator [21612,21690]
decorator [21630,21708]
===
match
---
number: 2 [16874,16875]
number: 2 [16892,16893]
===
match
---
trailer [46862,46874]
trailer [46880,46892]
===
match
---
trailer [28614,28633]
trailer [28632,28651]
===
match
---
operator: = [3377,3378]
operator: = [3377,3378]
===
match
---
string: '{"key": "value"}' [19578,19596]
string: '{"key": "value"}' [19596,19614]
===
match
---
name: kv_engine_version [13861,13878]
name: kv_engine_version [13879,13896]
===
match
---
operator: = [24571,24572]
operator: = [24589,24590]
===
match
---
name: is_authenticated [16821,16837]
name: is_authenticated [16839,16855]
===
match
---
name: mock_client [41012,41023]
name: mock_client [41030,41041]
===
match
---
name: mock_connection [48752,48767]
name: mock_connection [48770,48785]
===
match
---
operator: @ [5217,5218]
operator: @ [5217,5218]
===
match
---
decorator [4272,4352]
decorator [4272,4352]
===
match
---
operator: , [32972,32973]
operator: , [32990,32991]
===
match
---
operator: @ [15369,15370]
operator: @ [15387,15388]
===
match
---
trailer [22320,22329]
trailer [22338,22347]
===
match
---
name: connection_dict [3947,3962]
name: connection_dict [3947,3962]
===
match
---
simple_stmt [27082,27182]
simple_stmt [27100,27200]
===
match
---
trailer [22894,22901]
trailer [22912,22919]
===
match
---
simple_stmt [4098,4165]
simple_stmt [4098,4165]
===
match
---
string: "radius_port" [30491,30504]
string: "radius_port" [30509,30522]
===
match
---
operator: = [6407,6408]
operator: = [6407,6408]
===
match
---
expr_stmt [33696,33727]
expr_stmt [33714,33745]
===
match
---
operator: } [10902,10903]
operator: } [10920,10921]
===
match
---
string: "path" [25870,25876]
string: "path" [25888,25894]
===
match
---
argument [41832,41846]
argument [41850,41864]
===
match
---
operator: = [30693,30694]
operator: = [30711,30712]
===
match
---
name: vault_client [11534,11546]
name: vault_client [11552,11564]
===
match
---
string: "vault_conn_id" [36889,36904]
string: "vault_conn_id" [36907,36922]
===
match
---
name: mock [10438,10442]
name: mock [10456,10460]
===
match
---
name: VaultHook [4185,4194]
name: VaultHook [4185,4194]
===
match
---
atom_expr [42224,42240]
atom_expr [42242,42258]
===
match
---
atom [45803,45833]
atom [45821,45851]
===
match
---
name: get_mock_connection [40852,40871]
name: get_mock_connection [40870,40889]
===
match
---
operator: ** [38672,38674]
operator: ** [38690,38692]
===
match
---
operator: { [38758,38759]
operator: { [38776,38777]
===
match
---
atom [44909,44939]
atom [44927,44957]
===
match
---
name: kwargs [30395,30401]
name: kwargs [30413,30419]
===
match
---
name: side_effect [8674,8685]
name: side_effect [8680,8691]
===
match
---
arglist [18298,18366]
arglist [18316,18384]
===
match
---
expr_stmt [8999,9033]
expr_stmt [9005,9039]
===
match
---
simple_stmt [11454,11504]
simple_stmt [11472,11522]
===
match
---
name: mock_client [9554,9565]
name: mock_client [9566,9577]
===
match
---
expr_stmt [16321,16355]
expr_stmt [16339,16373]
===
match
---
operator: ** [7776,7778]
operator: ** [7776,7778]
===
match
---
dotted_name [8166,8176]
dotted_name [8172,8182]
===
match
---
operator: , [47096,47097]
operator: , [47114,47115]
===
match
---
name: assert_called_with [35049,35067]
name: assert_called_with [35067,35085]
===
match
---
parameters [35374,35412]
parameters [35392,35430]
===
match
---
name: kv_engine_version [25208,25225]
name: kv_engine_version [25226,25243]
===
match
---
operator: { [47267,47268]
operator: { [47285,47286]
===
match
---
name: mount_point [47218,47229]
name: mount_point [47236,47247]
===
match
---
operator: { [36716,36717]
operator: { [36734,36735]
===
match
---
operator: = [33604,33605]
operator: = [33622,33623]
===
match
---
name: url [28460,28463]
name: url [28478,28481]
===
match
---
name: test_hook [9013,9022]
name: test_hook [9019,9028]
===
match
---
atom_expr [31872,31892]
atom_expr [31890,31910]
===
match
---
name: mock_connection [12082,12097]
name: mock_connection [12100,12115]
===
match
---
name: side_effect [34682,34693]
name: side_effect [34700,34711]
===
match
---
operator: , [13684,13685]
operator: , [13702,13703]
===
match
---
name: side_effect [33555,33566]
name: side_effect [33573,33584]
===
match
---
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [21540,21606]
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [21558,21624]
===
match
---
operator: = [7764,7765]
operator: = [7764,7765]
===
match
---
simple_stmt [19300,19351]
simple_stmt [19318,19369]
===
match
---
name: kwargs [16089,16095]
name: kwargs [16107,16113]
===
match
---
trailer [11266,11295]
trailer [11284,11313]
===
match
---
dictorsetmaker [41304,41320]
dictorsetmaker [41322,41338]
===
match
---
name: self [3039,3043]
name: self [3039,3043]
===
match
---
string: "tenant_id" [13271,13282]
string: "tenant_id" [13289,13300]
===
match
---
expr_stmt [24198,24241]
expr_stmt [24216,24259]
===
match
---
dotted_name [25316,25326]
dotted_name [25334,25344]
===
match
---
name: mock [39332,39336]
name: mock [39350,39354]
===
match
---
trailer [44429,44449]
trailer [44447,44467]
===
match
---
trailer [36078,36097]
trailer [36096,36115]
===
match
---
name: test_client [20236,20247]
name: test_client [20254,20265]
===
match
---
name: vault_client [5892,5904]
name: vault_client [5892,5904]
===
match
---
trailer [22375,22404]
trailer [22393,22422]
===
match
---
name: Client [21278,21284]
name: Client [21296,21302]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [27712,27776]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [27730,27794]
===
match
---
name: mock_connection [28126,28141]
name: mock_connection [28144,28159]
===
match
---
name: mock_hvac [33843,33852]
name: mock_hvac [33861,33870]
===
match
---
operator: = [10748,10749]
operator: = [10766,10767]
===
match
---
atom_expr [18566,18615]
atom_expr [18584,18633]
===
match
---
operator: = [48845,48846]
operator: = [48863,48864]
===
match
---
name: assert_called_with [25144,25162]
name: assert_called_with [25162,25180]
===
match
---
operator: , [15002,15003]
operator: , [15020,15021]
===
match
---
name: return_value [15810,15822]
name: return_value [15828,15840]
===
match
---
string: "credentials" [19456,19469]
string: "credentials" [19474,19487]
===
match
---
name: mock_get_connection [19894,19913]
name: mock_get_connection [19912,19931]
===
match
---
string: "auth_type" [27105,27116]
string: "auth_type" [27123,27134]
===
match
---
name: MagicMock [12859,12868]
name: MagicMock [12877,12886]
===
match
---
atom_expr [35980,36044]
atom_expr [35998,36062]
===
match
---
simple_stmt [5823,5855]
simple_stmt [5823,5855]
===
match
---
operator: ** [33035,33037]
operator: ** [33053,33055]
===
match
---
arglist [25077,25105]
arglist [25095,25123]
===
match
---
suite [22837,23909]
suite [22855,23927]
===
match
---
name: kwargs [19735,19741]
name: kwargs [19753,19759]
===
match
---
name: self [32549,32553]
name: self [32567,32571]
===
match
---
name: assert_called_with [18141,18159]
name: assert_called_with [18159,18177]
===
match
---
name: metadata [43267,43275]
name: metadata [43285,43293]
===
match
---
param [15577,15597]
param [15595,15615]
===
match
---
name: PropertyMock [1363,1375]
name: PropertyMock [1363,1375]
===
match
---
name: mock_hvac [27338,27347]
name: mock_hvac [27356,27365]
===
match
---
atom_expr [26333,26409]
atom_expr [26351,26427]
===
match
---
operator: } [5662,5663]
operator: } [5662,5663]
===
match
---
name: get_conn [10143,10151]
name: get_conn [10155,10163]
===
match
---
decorators [6794,7155]
decorators [6794,7155]
===
match
---
trailer [26276,26295]
trailer [26294,26313]
===
match
---
name: VaultHook [12245,12254]
name: VaultHook [12263,12272]
===
match
---
name: kv [47151,47153]
name: kv [47169,47171]
===
match
---
expr_stmt [35937,35971]
expr_stmt [35955,35989]
===
match
---
argument [29674,29688]
argument [29692,29706]
===
match
---
comparison [6743,6788]
comparison [6743,6788]
===
match
---
atom [32662,32782]
atom [32680,32800]
===
match
---
operator: = [35949,35950]
operator: = [35967,35968]
===
match
---
trailer [43115,43119]
trailer [43133,43137]
===
match
---
atom_expr [19894,19949]
atom_expr [19912,19967]
===
match
---
decorators [3480,3642]
decorators [3480,3642]
===
match
---
expr_stmt [9593,9636]
expr_stmt [9605,9648]
===
match
---
name: auth [13577,13581]
name: auth [13595,13599]
===
match
---
number: 2 [2629,2630]
number: 2 [2629,2630]
===
match
---
trailer [16888,16901]
trailer [16906,16919]
===
match
---
trailer [20057,20154]
trailer [20075,20172]
===
match
---
expr_stmt [46800,46820]
expr_stmt [46818,46838]
===
match
---
name: return_value [13004,13016]
name: return_value [13022,13034]
===
match
---
operator: , [49037,49038]
operator: , [49055,49056]
===
match
---
simple_stmt [22117,22184]
simple_stmt [22135,22202]
===
match
---
decorator [26534,26614]
decorator [26552,26632]
===
match
---
expr_stmt [21121,21152]
expr_stmt [21139,21170]
===
match
---
comparison [8114,8159]
comparison [8120,8165]
===
match
---
operator: { [4894,4895]
operator: { [4894,4895]
===
match
---
name: Client [27899,27905]
name: Client [27917,27923]
===
match
---
operator: = [12243,12244]
operator: = [12261,12262]
===
match
---
operator: } [38465,38466]
operator: } [38483,38484]
===
match
---
atom_expr [26151,26206]
atom_expr [26169,26224]
===
match
---
dictorsetmaker [47106,47120]
dictorsetmaker [47124,47138]
===
match
---
operator: = [23066,23067]
operator: = [23084,23085]
===
match
---
dotted_name [6994,7004]
dotted_name [6994,7004]
===
match
---
string: "kv_engine_version" [35800,35819]
string: "kv_engine_version" [35818,35837]
===
match
---
string: "custom" [5076,5084]
string: "custom" [5076,5084]
===
match
---
name: mock_client [46198,46209]
name: mock_client [46216,46227]
===
match
---
trailer [6343,6363]
trailer [6343,6363]
===
match
---
trailer [36984,37003]
trailer [37002,37021]
===
match
---
suite [6221,6789]
suite [6221,6789]
===
match
---
name: mock [25316,25320]
name: mock [25334,25338]
===
match
---
argument [21304,21331]
argument [21322,21349]
===
match
---
operator: } [20114,20115]
operator: } [20132,20133]
===
match
---
name: assert_called_with [26277,26295]
name: assert_called_with [26295,26313]
===
match
---
expr_stmt [24303,24353]
expr_stmt [24321,24371]
===
match
---
simple_stmt [34078,34132]
simple_stmt [34096,34150]
===
match
---
operator: = [29411,29412]
operator: = [29429,29430]
===
match
---
operator: = [13639,13640]
operator: = [13657,13658]
===
match
---
number: 8180 [1236,1240]
number: 8180 [1236,1240]
===
match
---
name: mock_connection [1621,1636]
name: mock_connection [1621,1636]
===
match
---
trailer [40510,40581]
trailer [40528,40599]
===
match
---
atom_expr [27231,27286]
atom_expr [27249,27304]
===
match
---
operator: } [3206,3207]
operator: } [3206,3207]
===
match
---
string: "vault_conn_id" [24887,24902]
string: "vault_conn_id" [24905,24920]
===
match
---
expr_stmt [45507,45580]
expr_stmt [45525,45598]
===
match
---
name: test_hook [4232,4241]
name: test_hook [4232,4241]
===
match
---
simple_stmt [32644,32783]
simple_stmt [32662,32801]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [3576,3640]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [3576,3640]
===
match
---
expr_stmt [30290,30310]
expr_stmt [30308,30328]
===
match
---
name: connection_dict [10883,10898]
name: connection_dict [10901,10916]
===
match
---
trailer [23009,23022]
trailer [23027,23040]
===
match
---
string: "missing" [41685,41694]
string: "missing" [41703,41712]
===
match
---
string: 'deletion_time' [43638,43653]
string: 'deletion_time' [43656,43671]
===
match
---
simple_stmt [29034,29079]
simple_stmt [29052,29097]
===
match
---
operator: @ [2578,2579]
operator: @ [2578,2579]
===
match
---
name: VaultHook [31766,31775]
name: VaultHook [31784,31793]
===
match
---
simple_stmt [12453,12595]
simple_stmt [12471,12613]
===
match
---
atom_expr [27309,27329]
atom_expr [27327,27347]
===
match
---
name: secret_key [12541,12551]
name: secret_key [12559,12569]
===
match
---
param [1177,1195]
param [1177,1195]
===
match
---
name: patch [926,931]
name: patch [926,931]
===
match
---
operator: = [2504,2505]
operator: = [2504,2505]
===
match
---
expr_stmt [33522,33588]
expr_stmt [33540,33606]
===
match
---
name: assert_called_with [16509,16527]
name: assert_called_with [16527,16545]
===
match
---
name: mock_get_connection [7794,7813]
name: mock_get_connection [7794,7813]
===
match
---
name: test_hook [13463,13472]
name: test_hook [13481,13490]
===
match
---
atom_expr [6708,6727]
atom_expr [6708,6727]
===
match
---
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [13896,13962]
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [13914,13980]
===
match
---
name: MagicMock [14138,14147]
name: MagicMock [14156,14165]
===
match
---
name: mock_get_connection [11777,11796]
name: mock_get_connection [11795,11814]
===
match
---
operator: { [47784,47785]
operator: { [47802,47803]
===
match
---
trailer [9896,9908]
trailer [9908,9920]
===
match
---
simple_stmt [11898,11943]
simple_stmt [11916,11961]
===
match
---
expr_stmt [16089,16271]
expr_stmt [16107,16289]
===
match
---
trailer [47077,47122]
trailer [47095,47140]
===
match
---
name: mock_connection [6321,6336]
name: mock_connection [6321,6336]
===
match
---
expr_stmt [30125,30168]
expr_stmt [30143,30186]
===
match
---
simple_stmt [37824,38467]
simple_stmt [37842,38485]
===
match
---
argument [13367,13375]
argument [13385,13393]
===
match
---
operator: @ [46431,46432]
operator: @ [46449,46450]
===
match
---
atom_expr [9201,9250]
atom_expr [9213,9262]
===
match
---
name: get_conn [12361,12369]
name: get_conn [12379,12387]
===
match
---
expr_stmt [24805,24839]
expr_stmt [24823,24857]
===
match
---
trailer [13089,13102]
trailer [13107,13120]
===
match
---
string: "vault_conn_id" [5788,5803]
string: "vault_conn_id" [5788,5803]
===
match
---
name: mock [20461,20465]
name: mock [20479,20483]
===
match
---
expr_stmt [3887,3937]
expr_stmt [3887,3937]
===
match
---
expr_stmt [19811,19842]
expr_stmt [19829,19860]
===
match
---
atom_expr [6374,6406]
atom_expr [6374,6406]
===
match
---
name: patch [23319,23324]
name: patch [23337,23342]
===
match
---
trailer [46220,46223]
trailer [46238,46241]
===
match
---
name: mock [40672,40676]
name: mock [40690,40694]
===
match
---
name: test_client [36140,36151]
name: test_client [36158,36169]
===
match
---
operator: = [22124,22125]
operator: = [22142,22143]
===
match
---
operator: = [39387,39388]
operator: = [39405,39406]
===
match
---
name: get_conn [31882,31890]
name: get_conn [31900,31908]
===
match
---
param [46555,46565]
param [46573,46583]
===
match
---
dotted_name [2758,2768]
dotted_name [2758,2768]
===
match
---
operator: ** [4989,4991]
operator: ** [4989,4991]
===
match
---
name: version [2862,2869]
name: version [2862,2869]
===
match
---
funcdef [4438,5128]
funcdef [4438,5128]
===
match
---
trailer [15664,15674]
trailer [15682,15692]
===
match
---
dictorsetmaker [32676,32772]
dictorsetmaker [32694,32790]
===
match
---
name: mock_get_connection [21161,21180]
name: mock_get_connection [21179,21198]
===
match
---
name: patch [24683,24688]
name: patch [24701,24706]
===
match
---
trailer [10259,10278]
trailer [10277,10296]
===
match
---
number: 0 [44860,44861]
number: 0 [44878,44879]
===
match
---
atom_expr [23127,23146]
atom_expr [23145,23164]
===
match
---
operator: , [38219,38220]
operator: , [38237,38238]
===
match
---
name: assert_called_with [35997,36015]
name: assert_called_with [36015,36033]
===
match
---
operator: = [11876,11877]
operator: = [11894,11895]
===
match
---
param [19087,19107]
param [19105,19125]
===
match
---
name: mock_open [915,924]
name: mock_open [915,924]
===
match
---
decorators [44152,44314]
decorators [44170,44332]
===
match
---
operator: , [38260,38261]
operator: , [38278,38279]
===
match
---
dotted_name [17015,17025]
dotted_name [17033,17043]
===
match
---
atom [45777,46079]
atom [45795,46097]
===
match
---
expr_stmt [48898,48964]
expr_stmt [48916,48982]
===
match
---
name: return_value [30250,30262]
name: return_value [30268,30280]
===
match
---
argument [27213,27221]
argument [27231,27239]
===
match
---
atom [42394,43043]
atom [42412,43061]
===
match
---
dotted_name [2674,2684]
dotted_name [2674,2684]
===
match
---
operator: @ [11654,11655]
operator: @ [11672,11673]
===
match
---
expr_stmt [28126,28192]
expr_stmt [28144,28210]
===
match
---
name: url [9078,9081]
name: url [9084,9087]
===
match
---
simple_stmt [41033,41054]
simple_stmt [41051,41072]
===
match
---
operator: = [31685,31686]
operator: = [31703,31704]
===
match
---
expr_stmt [34411,34454]
expr_stmt [34429,34472]
===
match
---
dictorsetmaker [47268,47282]
dictorsetmaker [47286,47300]
===
match
---
atom [40392,40422]
atom [40410,40440]
===
match
---
name: return_value [41101,41113]
name: return_value [41119,41131]
===
match
---
name: return_value [11971,11983]
name: return_value [11989,12001]
===
match
---
trailer [31385,31387]
trailer [31403,31405]
===
match
---
simple_stmt [35937,35972]
simple_stmt [35955,35990]
===
match
---
atom_expr [7410,7442]
atom_expr [7410,7442]
===
match
---
trailer [35450,35452]
trailer [35468,35470]
===
match
---
name: get_mock_connection [37613,37632]
name: get_mock_connection [37631,37650]
===
match
---
trailer [24973,24992]
trailer [24991,25010]
===
match
---
trailer [9229,9248]
trailer [9241,9260]
===
match
---
simple_stmt [26864,26909]
simple_stmt [26882,26927]
===
match
---
operator: } [46063,46064]
operator: } [46081,46082]
===
match
---
name: type [1616,1620]
name: type [1616,1620]
===
match
---
name: VaultHook [5835,5844]
name: VaultHook [5835,5844]
===
match
---
simple_stmt [14633,14665]
simple_stmt [14651,14683]
===
match
---
trailer [11825,11835]
trailer [11843,11853]
===
match
---
atom_expr [33814,33834]
atom_expr [33832,33852]
===
match
---
operator: { [41051,41052]
operator: { [41069,41070]
===
match
---
name: return_value [14283,14295]
name: return_value [14301,14313]
===
match
---
atom [24381,24479]
atom [24399,24497]
===
match
---
atom_expr [32584,32616]
atom_expr [32602,32634]
===
match
---
simple_stmt [26108,26143]
simple_stmt [26126,26161]
===
match
---
decorated [13884,15167]
decorated [13902,15185]
===
match
---
name: get [4052,4055]
name: get [4052,4055]
===
match
---
operator: , [45432,45433]
operator: , [45450,45451]
===
match
---
name: test_kubernetes_dejson [25401,25423]
name: test_kubernetes_dejson [25419,25441]
===
match
---
string: "airflow.providers.google.cloud.utils.credentials_provider._get_scopes" [18694,18765]
string: "airflow.providers.google.cloud.utils.credentials_provider._get_scopes" [18712,18783]
===
match
---
expr_stmt [27850,27880]
expr_stmt [27868,27898]
===
match
---
name: mock_get_connection [36965,36984]
name: mock_get_connection [36983,37002]
===
match
---
operator: ** [8917,8919]
operator: ** [8923,8925]
===
match
---
name: Client [6279,6285]
name: Client [6279,6285]
===
match
---
operator: } [46819,46820]
operator: } [46837,46838]
===
match
---
name: mock_connection [25650,25665]
name: mock_connection [25668,25683]
===
match
---
name: patch [47315,47320]
name: patch [47333,47338]
===
match
---
operator: = [47251,47252]
operator: = [47269,47270]
===
match
---
name: mock_get_scopes [15620,15635]
name: mock_get_scopes [15638,15653]
===
match
---
name: mock_client [21764,21775]
name: mock_client [21782,21793]
===
match
---
simple_stmt [7754,7786]
simple_stmt [7754,7786]
===
match
---
simple_stmt [6696,6728]
simple_stmt [6696,6728]
===
match
---
simple_stmt [27889,27933]
simple_stmt [27907,27951]
===
match
---
expr_stmt [8498,8542]
expr_stmt [8504,8548]
===
match
---
name: test_hook [23397,23406]
name: test_hook [23415,23424]
===
match
---
operator: = [12909,12910]
operator: = [12927,12928]
===
match
---
name: patch [9407,9412]
name: patch [9419,9424]
===
match
---
name: port [1499,1503]
name: port [1499,1503]
===
match
---
atom [48241,48257]
atom [48259,48275]
===
match
---
name: self [19070,19074]
name: self [19088,19092]
===
match
---
assert_stmt [38751,38798]
assert_stmt [38769,38816]
===
match
---
operator: , [17823,17824]
operator: , [17841,17842]
===
match
---
name: jwt [23778,23781]
name: jwt [23796,23799]
===
match
---
operator: { [47880,47881]
operator: { [47898,47899]
===
match
---
expr_stmt [24363,24479]
expr_stmt [24381,24497]
===
match
---
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [46359,46425]
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [46377,46443]
===
match
---
operator: , [5354,5355]
operator: , [5354,5355]
===
match
---
atom_expr [9698,9730]
atom_expr [9710,9742]
===
match
---
string: "role" [10287,10293]
string: "role" [10305,10311]
===
match
---
atom_expr [3379,3398]
atom_expr [3379,3398]
===
match
---
operator: = [10856,10857]
operator: = [10874,10875]
===
match
---
name: mock_get_connection [47532,47551]
name: mock_get_connection [47550,47569]
===
match
---
atom_expr [30100,30116]
atom_expr [30118,30134]
===
match
---
trailer [33755,33774]
trailer [33773,33792]
===
match
---
operator: = [46612,46613]
operator: = [46630,46631]
===
match
---
argument [49343,49366]
argument [49361,49384]
===
match
---
arglist [23325,23369]
arglist [23343,23387]
===
match
---
parameters [40781,40819]
parameters [40799,40837]
===
match
---
atom [36858,36915]
atom [36876,36933]
===
match
---
string: "vault" [1187,1194]
string: "vault" [1187,1194]
===
match
---
name: mock_client [28943,28954]
name: mock_client [28961,28972]
===
match
---
name: mock_get_connection [33434,33453]
name: mock_get_connection [33452,33471]
===
match
---
name: get [33585,33588]
name: get [33603,33606]
===
match
---
operator: } [47959,47960]
operator: } [47977,47978]
===
match
---
name: patch [36262,36267]
name: patch [36280,36285]
===
match
---
trailer [5097,5110]
trailer [5097,5110]
===
match
---
suite [44398,46342]
suite [44416,46360]
===
match
---
name: connection_dict [25752,25767]
name: connection_dict [25770,25785]
===
match
---
string: "vault_conn_id" [23278,23293]
string: "vault_conn_id" [23296,23311]
===
match
---
simple_stmt [2176,2227]
simple_stmt [2176,2227]
===
match
---
atom [38066,38368]
atom [38084,38386]
===
match
---
name: mock [36341,36345]
name: mock [36359,36363]
===
match
---
funcdef [1144,1789]
funcdef [1144,1789]
===
match
---
simple_stmt [33800,33835]
simple_stmt [33818,33853]
===
match
---
trailer [37846,37849]
trailer [37864,37867]
===
match
---
dotted_name [16926,16936]
dotted_name [16944,16954]
===
match
---
atom_expr [5400,5416]
atom_expr [5400,5416]
===
match
---
simple_stmt [28054,28117]
simple_stmt [28072,28135]
===
match
---
name: mock [29841,29845]
name: mock [29859,29863]
===
match
---
atom_expr [21161,21216]
atom_expr [21179,21234]
===
match
---
trailer [36607,36627]
trailer [36625,36645]
===
match
---
operator: , [7666,7667]
operator: , [7666,7667]
===
match
---
operator: , [46045,46046]
operator: , [46063,46064]
===
match
---
string: "vault_conn_id" [23261,23276]
string: "vault_conn_id" [23279,23294]
===
match
---
name: assert_called_with [20180,20198]
name: assert_called_with [20198,20216]
===
match
---
operator: , [48621,48622]
operator: , [48639,48640]
===
match
---
trailer [28404,28413]
trailer [28422,28431]
===
match
---
operator: = [49172,49173]
operator: = [49190,49191]
===
match
---
param [32410,32429]
param [32428,32447]
===
match
---
argument [32058,32067]
argument [32076,32085]
===
match
---
name: Client [22350,22356]
name: Client [22368,22374]
===
match
---
string: "builtins.open" [24689,24704]
string: "builtins.open" [24707,24722]
===
match
---
name: vault_client [5036,5048]
name: vault_client [5036,5048]
===
match
---
operator: , [12797,12798]
operator: , [12815,12816]
===
match
---
param [4500,4519]
param [4500,4519]
===
match
---
simple_stmt [31794,31850]
simple_stmt [31812,31868]
===
match
---
string: 'data' [45795,45801]
string: 'data' [45813,45819]
===
match
---
trailer [16508,16527]
trailer [16526,16545]
===
match
---
string: "vault_conn_id" [14580,14595]
string: "vault_conn_id" [14598,14613]
===
match
---
name: assert_called_with [36169,36187]
name: assert_called_with [36187,36205]
===
match
---
name: return_value [20865,20877]
name: return_value [20883,20895]
===
match
---
operator: = [3107,3108]
operator: = [3107,3108]
===
match
---
trailer [22252,22271]
trailer [22270,22289]
===
match
---
trailer [10036,10046]
trailer [10048,10058]
===
match
---
operator: = [28070,28071]
operator: = [28088,28089]
===
match
---
operator: = [4977,4978]
operator: = [4977,4978]
===
match
---
operator: @ [10521,10522]
operator: @ [10539,10540]
===
match
---
simple_stmt [25675,25696]
simple_stmt [25693,25714]
===
match
---
name: return_value [19375,19387]
name: return_value [19393,19405]
===
match
---
trailer [7987,8006]
trailer [7993,8012]
===
match
---
name: MagicMock [15665,15674]
name: MagicMock [15683,15692]
===
match
---
trailer [5549,5562]
trailer [5549,5562]
===
match
---
simple_stmt [19811,19843]
simple_stmt [19829,19861]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [37444,37508]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [37462,37526]
===
match
---
simple_stmt [19359,19411]
simple_stmt [19377,19429]
===
match
---
atom_expr [21412,21461]
atom_expr [21430,21479]
===
match
---
param [8360,8365]
param [8366,8371]
===
match
---
string: 'version' [45139,45148]
string: 'version' [45157,45166]
===
match
---
operator: , [35773,35774]
operator: , [35791,35792]
===
match
---
atom_expr [35951,35971]
atom_expr [35969,35989]
===
match
---
trailer [36151,36168]
trailer [36169,36186]
===
match
---
expr_stmt [22846,22876]
expr_stmt [22864,22894]
===
match
---
operator: = [40137,40138]
operator: = [40155,40156]
===
match
---
string: "vault_conn_id" [31833,31848]
string: "vault_conn_id" [31851,31866]
===
match
---
expr_stmt [33800,33834]
expr_stmt [33818,33852]
===
match
---
string: "radhost" [32032,32041]
string: "radhost" [32050,32059]
===
match
---
atom [3301,3358]
atom [3301,3358]
===
match
---
name: get_conn [16345,16353]
name: get_conn [16363,16371]
===
match
---
parameters [27802,27840]
parameters [27820,27858]
===
match
---
parameters [3680,3718]
parameters [3680,3718]
===
match
---
trailer [19992,20009]
trailer [20010,20027]
===
match
---
atom_expr [34918,34938]
atom_expr [34936,34956]
===
match
---
trailer [33584,33588]
trailer [33602,33606]
===
match
---
atom [44969,45170]
atom [44987,45188]
===
match
---
expr_stmt [12157,12223]
expr_stmt [12175,12241]
===
match
---
name: mock_client [34443,34454]
name: mock_client [34461,34472]
===
match
---
operator: { [39428,39429]
operator: { [39446,39447]
===
match
---
expr_stmt [25510,25553]
expr_stmt [25528,25571]
===
match
---
dotted_name [6795,6815]
dotted_name [6795,6815]
===
match
---
dictorsetmaker [7598,7734]
dictorsetmaker [7598,7734]
===
match
---
string: 'lease_id' [44782,44792]
string: 'lease_id' [44800,44810]
===
match
---
operator: , [16217,16218]
operator: , [16235,16236]
===
match
---
simple_stmt [48010,48097]
simple_stmt [48028,48115]
===
match
---
operator: = [1388,1389]
operator: = [1388,1389]
===
match
---
expr_stmt [3947,4013]
expr_stmt [3947,4013]
===
match
---
param [27803,27808]
param [27821,27826]
===
match
---
atom_expr [2071,2100]
atom_expr [2071,2100]
===
match
---
expr_stmt [32440,32470]
expr_stmt [32458,32488]
===
match
---
trailer [33338,33345]
trailer [33356,33363]
===
match
---
name: assert_called_with [29565,29583]
name: assert_called_with [29583,29601]
===
match
---
trailer [12464,12477]
trailer [12482,12495]
===
match
---
decorator [48390,48470]
decorator [48408,48488]
===
match
---
name: connection_dict [48868,48883]
name: connection_dict [48886,48901]
===
match
---
name: connection_dict [41033,41048]
name: connection_dict [41051,41066]
===
match
---
expr_stmt [17887,17953]
expr_stmt [17905,17971]
===
match
---
argument [2563,2571]
argument [2563,2571]
===
match
---
trailer [41074,41082]
trailer [41092,41100]
===
match
---
atom [48312,48379]
atom [48330,48397]
===
match
---
trailer [21303,21332]
trailer [21321,21350]
===
match
---
name: VaultHook [41615,41624]
name: VaultHook [41633,41642]
===
match
---
operator: , [11054,11055]
operator: , [11072,11073]
===
match
---
simple_stmt [2318,2385]
simple_stmt [2318,2385]
===
match
---
trailer [30348,30352]
trailer [30366,30370]
===
match
---
expr_stmt [29505,29539]
expr_stmt [29523,29557]
===
match
---
atom_expr [28289,28308]
atom_expr [28307,28326]
===
match
---
name: return_value [5550,5562]
name: return_value [5550,5562]
===
match
---
param [28913,28932]
param [28931,28950]
===
match
---
expr_stmt [13149,13335]
expr_stmt [13167,13353]
===
match
---
atom_expr [17538,17570]
atom_expr [17556,17588]
===
match
---
name: mock_get_connection [30617,30636]
name: mock_get_connection [30635,30654]
===
match
---
name: mock_hvac [24957,24966]
name: mock_hvac [24975,24984]
===
match
---
name: mock_connection [4810,4825]
name: mock_connection [4810,4825]
===
match
---
name: get [31632,31635]
name: get [31650,31653]
===
match
---
operator: { [6594,6595]
operator: { [6594,6595]
===
match
---
name: test_hook [27191,27200]
name: test_hook [27209,27218]
===
match
---
name: get [16043,16046]
name: get [16061,16064]
===
match
---
decorator [3480,3560]
decorator [3480,3560]
===
match
---
operator: = [20079,20080]
operator: = [20097,20098]
===
match
---
name: mock [31017,31021]
name: mock [31035,31039]
===
match
---
operator: , [32735,32736]
operator: , [32753,32754]
===
match
---
string: "kubernetes" [25903,25915]
string: "kubernetes" [25921,25933]
===
match
---
name: PropertyMock [1506,1518]
name: PropertyMock [1506,1518]
===
match
---
operator: = [20980,20981]
operator: = [20998,20999]
===
match
---
trailer [24886,24903]
trailer [24904,24921]
===
match
---
name: kwargs [34824,34830]
name: kwargs [34842,34848]
===
match
---
name: mock_hvac [25510,25519]
name: mock_hvac [25528,25537]
===
match
---
string: "userpass" [35788,35798]
string: "userpass" [35806,35816]
===
match
---
operator: = [29163,29164]
operator: = [29181,29182]
===
match
---
operator: = [45477,45478]
operator: = [45495,45496]
===
match
---
simple_stmt [19894,19950]
simple_stmt [19912,19968]
===
match
---
operator: = [40174,40175]
operator: = [40192,40193]
===
match
---
name: read_secret_version [38833,38852]
name: read_secret_version [38851,38870]
===
match
---
dotted_name [25232,25242]
dotted_name [25250,25260]
===
match
---
operator: ** [5845,5847]
operator: ** [5845,5847]
===
match
---
expr_stmt [1546,1607]
expr_stmt [1546,1607]
===
match
---
trailer [22563,22576]
trailer [22581,22594]
===
match
---
name: VaultHook [14645,14654]
name: VaultHook [14663,14672]
===
match
---
trailer [20950,20963]
trailer [20968,20981]
===
match
---
operator: = [20878,20879]
operator: = [20896,20897]
===
match
---
simple_stmt [41063,41420]
simple_stmt [41081,41438]
===
match
---
expr_stmt [34372,34402]
expr_stmt [34390,34420]
===
match
---
argument [22215,22223]
argument [22233,22241]
===
match
---
trailer [26085,26095]
trailer [26103,26113]
===
match
---
string: "vault_conn_id" [22140,22155]
string: "vault_conn_id" [22158,22173]
===
match
---
name: get [6539,6542]
name: get [6539,6542]
===
match
---
operator: { [3965,3966]
operator: { [3965,3966]
===
match
---
simple_stmt [14263,14314]
simple_stmt [14281,14332]
===
match
---
name: mock_hvac [24118,24127]
name: mock_hvac [24136,24145]
===
match
---
name: extra_dejson [28142,28154]
name: extra_dejson [28160,28172]
===
match
---
simple_stmt [11124,11180]
simple_stmt [11142,11198]
===
match
---
operator: = [13156,13157]
operator: = [13174,13175]
===
match
---
trailer [33944,33963]
trailer [33962,33981]
===
match
---
atom_expr [20845,20877]
atom_expr [20863,20895]
===
match
---
name: return_value [4694,4706]
name: return_value [4694,4706]
===
match
---
operator: { [13062,13063]
operator: { [13080,13081]
===
match
---
name: return_value [6394,6406]
name: return_value [6394,6406]
===
match
---
name: mock_get_connection [32584,32603]
name: mock_get_connection [32602,32621]
===
match
---
name: MagicMock [34391,34400]
name: MagicMock [34409,34418]
===
match
---
trailer [9572,9582]
trailer [9584,9594]
===
match
---
operator: = [20310,20311]
operator: = [20328,20329]
===
match
---
string: "azure_tenant_id" [14389,14406]
string: "azure_tenant_id" [14407,14424]
===
match
---
decorator [33050,33130]
decorator [33068,33148]
===
match
---
name: mock_hvac [37549,37558]
name: mock_hvac [37567,37576]
===
match
---
operator: { [3301,3302]
operator: { [3301,3302]
===
match
---
operator: { [29165,29166]
operator: { [29183,29184]
===
match
---
trailer [34051,34069]
trailer [34069,34087]
===
match
---
atom [21986,22032]
atom [22004,22050]
===
match
---
string: 'http://localhost:8180' [31941,31964]
string: 'http://localhost:8180' [31959,31982]
===
match
---
trailer [29752,29771]
trailer [29770,29789]
===
match
---
string: "gcp" [17777,17782]
string: "gcp" [17795,17800]
===
match
---
name: mock [36508,36512]
name: mock [36526,36530]
===
match
---
name: return_value [2196,2208]
name: return_value [2196,2208]
===
match
---
expr_stmt [4967,4998]
expr_stmt [4967,4998]
===
match
---
name: mock [39041,39045]
name: mock [39059,39063]
===
match
---
name: get_conn [14761,14769]
name: get_conn [14779,14787]
===
match
---
atom_expr [14780,14844]
atom_expr [14798,14862]
===
match
---
name: test_client [34904,34915]
name: test_client [34922,34933]
===
match
---
trailer [22329,22331]
trailer [22347,22349]
===
match
---
name: test_client [31858,31869]
name: test_client [31876,31887]
===
match
---
name: secret [40306,40312]
name: secret [40324,40330]
===
match
---
operator: = [22087,22088]
operator: = [22105,22106]
===
match
---
trailer [29192,29205]
trailer [29210,29223]
===
match
---
operator: @ [12684,12685]
operator: @ [12702,12703]
===
match
---
trailer [26828,26841]
trailer [26846,26859]
===
match
---
atom_expr [23484,23539]
atom_expr [23502,23557]
===
match
---
name: mock [46722,46726]
name: mock [46740,46744]
===
match
---
name: self [21873,21877]
name: self [21891,21895]
===
match
---
name: mock_connection [42098,42113]
name: mock_connection [42116,42131]
===
match
---
name: assert_called_with [23504,23522]
name: assert_called_with [23522,23540]
===
match
---
name: mock_hvac [10162,10171]
name: mock_hvac [10174,10183]
===
match
---
operator: = [12349,12350]
operator: = [12367,12368]
===
match
---
operator: = [44627,44628]
operator: = [44645,44646]
===
match
---
operator: } [43042,43043]
operator: } [43060,43061]
===
match
---
name: get [41458,41461]
name: get [41476,41479]
===
match
---
name: auth_approle [9127,9139]
name: approle [9138,9145]
===
match
---
decorated [18682,20455]
decorated [18700,20473]
===
match
---
simple_stmt [37290,37343]
simple_stmt [37308,37361]
===
match
---
string: "scope1,scope2" [19624,19639]
string: "scope1,scope2" [19642,19657]
===
match
---
name: mock_hvac [37741,37750]
name: mock_hvac [37759,37768]
===
match
---
expr_stmt [34576,34639]
expr_stmt [34594,34657]
===
match
---
expr_stmt [39357,39400]
expr_stmt [39375,39418]
===
match
---
atom_expr [46722,46738]
atom_expr [46740,46756]
===
match
---
argument [14918,14939]
argument [14936,14957]
===
match
---
simple_stmt [45507,45581]
simple_stmt [45525,45599]
===
match
---
trailer [8462,8475]
trailer [8468,8481]
===
match
---
name: patch [37438,37443]
name: patch [37456,37461]
===
match
---
operator: , [3696,3697]
operator: , [3696,3697]
===
match
---
name: path [40546,40550]
name: path [40564,40568]
===
match
---
expr_stmt [36638,36688]
expr_stmt [36656,36706]
===
match
---
operator: = [32837,32838]
operator: = [32855,32856]
===
match
---
decorator [16925,17010]
decorator [16943,17028]
===
match
---
operator: , [4498,4499]
operator: , [4498,4499]
===
match
---
decorators [31016,31178]
decorators [31034,31196]
===
match
---
operator: = [5455,5456]
operator: = [5455,5456]
===
match
---
decorator [41937,42015]
decorator [41955,42033]
===
match
---
atom [19390,19410]
atom [19408,19428]
===
match
---
atom_expr [9013,9033]
atom_expr [9019,9039]
===
match
---
name: get_conn [19875,19883]
name: get_conn [19893,19901]
===
match
---
operator: { [48982,48983]
operator: { [49000,49001]
===
match
---
name: port [1231,1235]
name: port [1231,1235]
===
match
---
name: mock_client [24159,24170]
name: mock_client [24177,24188]
===
match
---
name: self [29052,29056]
name: self [29070,29074]
===
match
---
atom_expr [20810,20836]
atom_expr [20828,20854]
===
match
---
name: connection_dict [46800,46815]
name: connection_dict [46818,46833]
===
match
---
trailer [42228,42238]
trailer [42246,42256]
===
match
---
trailer [19675,19688]
trailer [19693,19706]
===
match
---
name: keyfile_dict [16563,16575]
name: keyfile_dict [16581,16593]
===
match
---
simple_stmt [34516,34567]
simple_stmt [34534,34585]
===
match
---
name: hvac [952,956]
name: hvac [952,956]
===
match
---
name: is_authenticated [22496,22512]
name: is_authenticated [22514,22530]
===
match
---
assert_stmt [32135,32187]
assert_stmt [32153,32205]
===
match
---
name: self [22799,22803]
name: self [22817,22821]
===
match
---
name: mock_get_connection [2002,2021]
name: mock_get_connection [2002,2021]
===
match
---
name: vault_client [26498,26510]
name: vault_client [26516,26528]
===
match
---
operator: { [16098,16099]
operator: { [16116,16117]
===
match
---
string: 'key' [49351,49356]
string: 'key' [49369,49374]
===
match
---
atom [44629,44631]
atom [44647,44649]
===
match
---
simple_stmt [22042,22109]
simple_stmt [22060,22127]
===
match
---
operator: = [13461,13462]
operator: = [13479,13480]
===
match
---
name: extra_dejson [48914,48926]
name: extra_dejson [48932,48944]
===
match
---
atom_expr [14645,14664]
atom_expr [14663,14682]
===
match
---
atom [20923,20925]
atom [20941,20943]
===
match
---
trailer [20355,20372]
trailer [20373,20390]
===
match
---
name: unittest [845,853]
name: unittest [845,853]
===
match
---
name: return_value [3784,3796]
name: return_value [3784,3796]
===
match
---
operator: , [30556,30557]
operator: , [30574,30575]
===
match
---
atom_expr [41652,41695]
atom_expr [41670,41713]
===
match
---
name: vault_client [27580,27592]
name: vault_client [27598,27610]
===
match
---
name: return_value [40997,41009]
name: return_value [41015,41027]
===
match
---
trailer [3756,3758]
trailer [3756,3758]
===
match
---
expr_stmt [14557,14623]
expr_stmt [14575,14641]
===
match
---
expr_stmt [48973,49062]
expr_stmt [48991,49080]
===
match
---
operator: = [29696,29697]
operator: = [29714,29715]
===
match
---
trailer [34119,34131]
trailer [34137,34149]
===
match
---
name: mock_connection [1334,1349]
name: mock_connection [1334,1349]
===
match
---
trailer [18577,18594]
trailer [18595,18612]
===
match
---
trailer [10142,10151]
trailer [10154,10163]
===
match
---
atom [31474,31593]
atom [31492,31611]
===
match
---
trailer [20256,20266]
trailer [20274,20284]
===
match
---
string: 'metadata' [39756,39766]
string: 'metadata' [39774,39784]
===
match
---
trailer [20247,20252]
trailer [20265,20270]
===
match
---
argument [48234,48257]
argument [48252,48275]
===
match
---
name: assert_called_with [26225,26243]
name: assert_called_with [26243,26261]
===
match
---
string: 'path' [47252,47258]
string: 'path' [47270,47276]
===
match
---
trailer [31990,31997]
trailer [32008,32015]
===
match
---
string: "scope1,scope2" [17851,17866]
string: "scope1,scope2" [17869,17884]
===
match
---
name: Client [20173,20179]
name: Client [20191,20197]
===
match
---
atom_expr [18092,18112]
atom_expr [18110,18130]
===
match
---
name: kv [41083,41085]
name: kv [41101,41103]
===
match
---
name: MagicMock [36513,36522]
name: MagicMock [36531,36540]
===
match
---
operator: , [17344,17345]
operator: , [17362,17363]
===
match
---
name: get [36837,36840]
name: get [36855,36858]
===
match
---
operator: { [2254,2255]
operator: { [2254,2255]
===
match
---
dotted_name [20461,20471]
dotted_name [20479,20489]
===
match
---
trailer [7890,7892]
trailer [7890,7892]
===
match
---
name: schema [1196,1202]
name: schema [1196,1202]
===
match
---
expr_stmt [37643,37693]
expr_stmt [37661,37711]
===
match
---
operator: , [1253,1254]
operator: , [1253,1254]
===
match
---
arglist [40524,40571]
arglist [40542,40589]
===
match
---
string: 'http://localhost:8180' [14820,14843]
string: 'http://localhost:8180' [14838,14861]
===
match
---
simple_stmt [840,875]
simple_stmt [840,875]
===
match
---
expr_stmt [9758,9854]
expr_stmt [9770,9866]
===
match
---
trailer [26446,26465]
trailer [26464,26483]
===
match
---
name: patch [25986,25991]
name: patch [26004,26009]
===
match
---
operator: = [29587,29588]
operator: = [29605,29606]
===
match
---
simple_stmt [17485,17530]
simple_stmt [17503,17548]
===
match
---
name: mock_connection [3819,3834]
name: mock_connection [3819,3834]
===
match
---
name: mock_connection [12931,12946]
name: mock_connection [12949,12964]
===
match
---
operator: , [40544,40545]
operator: , [40562,40563]
===
match
---
atom_expr [26009,26036]
atom_expr [26027,26054]
===
match
---
expr_stmt [19851,19885]
expr_stmt [19869,19903]
===
match
---
dictorsetmaker [12180,12213]
dictorsetmaker [12198,12231]
===
match
---
name: assert_called_with [13405,13423]
name: assert_called_with [13423,13441]
===
match
---
simple_stmt [30900,30950]
simple_stmt [30918,30968]
===
match
---
name: assert_called_with [34964,34982]
name: assert_called_with [34982,35000]
===
match
---
atom_expr [27203,27222]
atom_expr [27221,27240]
===
match
---
name: mock_hvac [2969,2978]
name: mock_hvac [2969,2978]
===
match
---
trailer [2948,2958]
trailer [2948,2958]
===
match
---
name: return_value [10843,10855]
name: return_value [10861,10873]
===
match
---
operator: , [32397,32398]
operator: , [32415,32416]
===
match
---
trailer [44686,44699]
trailer [44704,44717]
===
match
---
name: test_client [13449,13460]
name: test_client [13467,13478]
===
match
---
string: 'destroyed' [43898,43909]
string: 'destroyed' [43916,43927]
===
match
---
trailer [15674,15676]
trailer [15692,15694]
===
match
---
trailer [32026,32068]
trailer [32044,32086]
===
match
---
argument [29584,29611]
argument [29602,29629]
===
match
---
parameters [10631,10669]
parameters [10649,10687]
===
match
---
operator: , [12558,12559]
operator: , [12576,12577]
===
match
---
name: kwargs [31778,31784]
name: kwargs [31796,31802]
===
match
---
string: "auth_type" [13218,13229]
string: "auth_type" [13236,13247]
===
match
---
atom_expr [18121,18176]
atom_expr [18139,18194]
===
match
---
string: "vault_conn_id" [27138,27153]
string: "vault_conn_id" [27156,27171]
===
match
---
operator: @ [23998,23999]
operator: @ [24016,24017]
===
match
---
expr_stmt [42210,42240]
expr_stmt [42228,42258]
===
match
---
assert_stmt [20402,20454]
assert_stmt [20420,20472]
===
match
---
trailer [18469,18474]
trailer [18487,18492]
===
match
---
string: "vault_conn_id" [29365,29380]
string: "vault_conn_id" [29383,29398]
===
match
---
operator: = [43319,43320]
operator: = [43337,43338]
===
match
---
name: connection_dict [4070,4085]
name: connection_dict [4070,4085]
===
match
---
funcdef [15535,16920]
funcdef [15553,16938]
===
match
---
string: 'lease_duration' [41256,41272]
string: 'lease_duration' [41274,41290]
===
match
---
name: VaultHook [47982,47991]
name: VaultHook [48000,48009]
===
match
---
trailer [20756,20769]
trailer [20774,20787]
===
match
---
operator: = [1749,1750]
operator: = [1749,1750]
===
match
---
string: "vault_conn_id" [32890,32905]
string: "vault_conn_id" [32908,32923]
===
match
---
name: username [36098,36106]
name: username [36116,36124]
===
match
---
name: mock [32454,32458]
name: mock [32472,32476]
===
match
---
simple_stmt [7339,7402]
simple_stmt [7339,7402]
===
match
---
operator: = [35738,35739]
operator: = [35756,35757]
===
match
---
name: mock [28957,28961]
name: mock [28975,28979]
===
match
---
operator: @ [39040,39041]
operator: @ [39058,39059]
===
match
---
name: test_hook [18038,18047]
name: test_hook [18056,18065]
===
match
---
name: mock_connection [40917,40932]
name: mock_connection [40935,40950]
===
match
---
testlist_comp [15881,15899]
testlist_comp [15899,15917]
===
match
---
param [19076,19086]
param [19094,19104]
===
match
---
trailer [18658,18676]
trailer [18676,18694]
===
match
---
name: is_authenticated [8061,8077]
name: is_authenticated [8067,8083]
===
match
---
name: return_value [48737,48749]
name: return_value [48755,48767]
===
match
---
name: get [43082,43085]
name: get [43100,43103]
===
match
---
string: 'value' [48249,48256]
string: 'value' [48267,48274]
===
match
---
operator: = [32547,32548]
operator: = [32565,32566]
===
match
---
trailer [16820,16837]
trailer [16838,16855]
===
match
---
name: mock_hvac [32479,32488]
name: mock_hvac [32497,32506]
===
match
---
name: VaultHook [27203,27212]
name: VaultHook [27221,27230]
===
match
---
trailer [3063,3065]
trailer [3063,3065]
===
match
---
name: kwargs [4885,4891]
name: kwargs [4885,4891]
===
match
---
name: test_hook [36925,36934]
name: test_hook [36943,36952]
===
match
---
name: test_client [37232,37243]
name: test_client [37250,37261]
===
match
---
expr_stmt [47562,47606]
expr_stmt [47580,47624]
===
match
---
name: mock_get_connection [28913,28932]
name: mock_get_connection [28931,28950]
===
match
---
simple_stmt [11231,11296]
simple_stmt [11249,11314]
===
match
---
name: kwargs [47028,47034]
name: kwargs [47046,47052]
===
match
---
operator: = [41684,41685]
operator: = [41702,41703]
===
match
---
name: get_mock_connection [26887,26906]
name: get_mock_connection [26905,26924]
===
match
---
name: get [48927,48930]
name: get [48945,48948]
===
match
---
name: connection_dict [32839,32854]
name: connection_dict [32857,32872]
===
match
---
name: kv [46218,46220]
name: kv [46236,46238]
===
match
---
name: mock_connection [19247,19262]
name: mock_connection [19265,19280]
===
match
---
name: read_secret_version [37850,37869]
name: read_secret_version [37868,37887]
===
match
---
name: test_client [12453,12464]
name: test_client [12471,12482]
===
match
---
argument [4989,4997]
argument [4989,4997]
===
match
---
expr_stmt [26917,26967]
expr_stmt [26935,26985]
===
match
---
name: get_mock_connection [14233,14252]
name: get_mock_connection [14251,14270]
===
match
---
trailer [5844,5854]
trailer [5844,5854]
===
match
---
argument [48192,48212]
argument [48210,48230]
===
match
---
operator: = [8584,8585]
operator: = [8590,8591]
===
match
---
trailer [19211,19224]
trailer [19229,19242]
===
match
---
name: test_hook [41603,41612]
name: test_hook [41621,41630]
===
match
---
trailer [34420,34427]
trailer [34438,34445]
===
match
---
atom_expr [41615,41634]
atom_expr [41633,41652]
===
match
---
simple_stmt [5863,5917]
simple_stmt [5863,5917]
===
match
---
dotted_name [32278,32288]
dotted_name [32296,32306]
===
match
---
name: metadata [43999,44007]
name: metadata [44017,44025]
===
match
---
trailer [20997,21001]
trailer [21015,21019]
===
match
---
operator: @ [1126,1127]
operator: @ [1126,1127]
===
match
---
operator: , [5803,5804]
operator: , [5803,5804]
===
match
---
name: get_mock_connection [42121,42140]
name: get_mock_connection [42139,42158]
===
match
---
atom_expr [32549,32575]
atom_expr [32567,32593]
===
match
---
operator: = [48070,48071]
operator: = [48088,48089]
===
match
---
operator: } [46993,46994]
operator: } [47011,47012]
===
match
---
name: secret_id [10295,10304]
name: secret_id [10313,10322]
===
match
---
operator: , [46301,46302]
operator: , [46319,46320]
===
match
---
trailer [28154,28158]
trailer [28172,28176]
===
match
---
trailer [14510,14514]
trailer [14528,14532]
===
match
---
string: "radhost" [29679,29688]
string: "radhost" [29697,29706]
===
match
---
trailer [14789,14796]
trailer [14807,14814]
===
match
---
decorator [4356,4434]
decorator [4356,4434]
===
match
---
funcdef [2839,3475]
funcdef [2839,3475]
===
match
---
operator: = [3299,3300]
operator: = [3299,3300]
===
match
---
trailer [13508,13527]
trailer [13526,13545]
===
match
---
suite [2921,3475]
suite [2921,3475]
===
match
---
name: mock_client [5386,5397]
name: mock_client [5386,5397]
===
match
---
name: self [42116,42120]
name: self [42134,42138]
===
match
---
operator: = [5755,5756]
operator: = [5755,5756]
===
match
---
decorator [2673,2753]
decorator [2673,2753]
===
match
---
operator: , [3685,3686]
operator: , [3685,3686]
===
match
---
name: self [12949,12953]
name: self [12967,12971]
===
match
---
trailer [39336,39346]
trailer [39354,39364]
===
match
---
atom [4107,4164]
atom [4107,4164]
===
match
---
name: mock [15660,15664]
name: mock [15678,15682]
===
match
---
name: mock_hvac [31901,31910]
name: mock_hvac [31919,31928]
===
match
---
name: assert_called_with [27439,27457]
name: assert_called_with [27457,27475]
===
match
---
import_from [875,931]
import_from [875,931]
===
match
---
name: return_value [40902,40914]
name: return_value [40920,40932]
===
match
---
operator: @ [18771,18772]
operator: @ [18789,18790]
===
match
---
expr_stmt [40167,40256]
expr_stmt [40185,40274]
===
match
---
name: port [30881,30885]
name: port [30899,30903]
===
match
---
name: MagicMock [6249,6258]
name: MagicMock [6249,6258]
===
match
---
name: return_value [12896,12908]
name: return_value [12914,12926]
===
match
---
operator: @ [33134,33135]
operator: @ [33152,33153]
===
match
---
param [26732,26742]
param [26750,26760]
===
match
---
name: connection_dict [13121,13136]
name: connection_dict [13139,13154]
===
match
---
name: url [33879,33882]
name: url [33897,33900]
===
match
---
expr_stmt [23441,23475]
expr_stmt [23459,23493]
===
match
---
string: "vault_conn_id" [34879,34894]
string: "vault_conn_id" [34897,34912]
===
match
---
string: "radius_host" [30453,30466]
string: "radius_host" [30471,30484]
===
match
---
operator: = [19705,19706]
operator: = [19723,19724]
===
match
---
atom_expr [48945,48964]
atom_expr [48963,48982]
===
match
---
trailer [45527,45557]
trailer [45545,45575]
===
match
---
name: mock_connection [46830,46845]
name: mock_connection [46848,46863]
===
match
---
dictorsetmaker [36730,36754]
dictorsetmaker [36748,36772]
===
match
---
atom_expr [35531,35557]
atom_expr [35549,35575]
===
match
---
name: patch [38962,38967]
name: patch [38980,38985]
===
match
---
operator: = [19510,19511]
operator: = [19528,19529]
===
match
---
name: connection_dict [37794,37809]
name: connection_dict [37812,37827]
===
match
---
expr_stmt [47970,48001]
expr_stmt [47988,48019]
===
match
---
name: mock_connection [5477,5492]
name: mock_connection [5477,5492]
===
match
---
name: return_value [6286,6298]
name: return_value [6286,6298]
===
match
---
trailer [48116,48124]
trailer [48134,48142]
===
match
---
simple_stmt [18038,18070]
simple_stmt [18056,18088]
===
match
---
simple_stmt [2393,2460]
simple_stmt [2393,2460]
===
match
---
trailer [17422,17424]
trailer [17440,17442]
===
match
---
atom [27091,27181]
atom [27109,27199]
===
match
---
atom_expr [21482,21522]
atom_expr [21500,21540]
===
match
---
comparison [15121,15166]
comparison [15139,15184]
===
match
---
name: type [1693,1697]
name: type [1693,1697]
===
match
---
operator: = [36819,36820]
operator: = [36837,36838]
===
match
---
name: mock_hvac [2071,2080]
name: mock_hvac [2071,2080]
===
match
---
operator: { [48886,48887]
operator: { [48904,48905]
===
match
---
decorator [37432,37510]
decorator [37450,37528]
===
match
---
name: configure [31998,32007]
name: configure [32016,32025]
===
match
---
name: return_value [44575,44587]
name: return_value [44593,44605]
===
match
---
string: "auth_type" [33641,33652]
string: "auth_type" [33659,33670]
===
match
---
name: read_secret [41089,41100]
name: read_secret [41107,41118]
===
match
---
name: assert_called_with [19914,19932]
name: assert_called_with [19932,19950]
===
match
---
name: kwargs [33037,33043]
name: kwargs [33055,33061]
===
match
---
simple_stmt [25115,25165]
simple_stmt [25133,25183]
===
match
---
string: 'created_time' [38174,38188]
string: 'created_time' [38192,38206]
===
match
---
trailer [48736,48749]
trailer [48754,48767]
===
match
---
atom_expr [3742,3758]
atom_expr [3742,3758]
===
match
---
trailer [14654,14664]
trailer [14672,14682]
===
match
---
operator: , [47935,47936]
operator: , [47953,47954]
===
match
---
name: side_effect [6543,6554]
name: side_effect [6543,6554]
===
match
---
trailer [29205,29209]
trailer [29223,29227]
===
match
---
simple_stmt [45589,46190]
simple_stmt [45607,46208]
===
match
---
name: connection_dict [27054,27069]
name: connection_dict [27072,27087]
===
match
---
operator: , [8364,8365]
operator: , [8370,8371]
===
match
---
operator: = [32660,32661]
operator: = [32678,32679]
===
match
---
name: extra_dejson [33538,33550]
name: extra_dejson [33556,33568]
===
match
---
string: "kube_role" [25822,25833]
string: "kube_role" [25840,25851]
===
match
---
expr_stmt [31858,31892]
expr_stmt [31876,31910]
===
match
---
trailer [13815,13817]
trailer [13833,13835]
===
match
---
string: 'created_time' [43571,43585]
string: 'created_time' [43589,43603]
===
match
---
name: mock_get_connection [24129,24148]
name: mock_get_connection [24147,24166]
===
match
---
name: get_conn [7882,7890]
name: get_conn [7882,7890]
===
match
---
expr_stmt [27295,27329]
expr_stmt [27313,27347]
===
match
---
operator: , [44796,44797]
operator: , [44814,44815]
===
match
---
name: mock_hvac [10718,10727]
name: mock_hvac [10736,10745]
===
match
---
dotted_name [39041,39051]
dotted_name [39059,39069]
===
match
---
suite [35413,36251]
suite [35431,36269]
===
match
---
trailer [44652,44660]
trailer [44670,44678]
===
match
---
simple_stmt [47131,47304]
simple_stmt [47149,47322]
===
match
---
operator: , [23340,23341]
operator: , [23358,23359]
===
match
---
simple_stmt [15984,16005]
simple_stmt [16002,16023]
===
match
---
string: "pass" [9185,9191]
string: "pass" [9197,9203]
===
match
---
arglist [10279,10311]
arglist [10297,10329]
===
match
---
operator: } [25694,25695]
operator: } [25712,25713]
===
match
---
name: test_client [11454,11465]
name: test_client [11472,11483]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [21624,21688]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [21642,21706]
===
match
---
trailer [43068,43081]
trailer [43086,43099]
===
match
---
operator: } [24478,24479]
operator: } [24496,24497]
===
match
---
trailer [22356,22375]
trailer [22374,22393]
===
match
---
atom_expr [36210,36250]
atom_expr [36228,36268]
===
match
---
string: 'world' [41313,41320]
string: 'world' [41331,41338]
===
match
---
operator: , [19399,19400]
operator: , [19417,19418]
===
match
---
trailer [36549,36562]
trailer [36567,36580]
===
match
---
name: kwargs [2393,2399]
name: kwargs [2393,2399]
===
match
---
operator: @ [28702,28703]
operator: @ [28720,28721]
===
match
---
argument [47026,47034]
argument [47044,47052]
===
match
---
name: side_effect [12115,12126]
name: side_effect [12133,12144]
===
match
---
operator: } [30309,30310]
operator: } [30327,30328]
===
match
---
operator: , [6875,6876]
operator: , [6875,6876]
===
match
---
name: mock_get_connection [31396,31415]
name: mock_get_connection [31414,31433]
===
match
---
param [17368,17383]
param [17386,17401]
===
match
---
operator: , [43472,43473]
operator: , [43490,43491]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [22696,22760]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [22714,22778]
===
match
---
trailer [2958,2960]
trailer [2958,2960]
===
match
---
operator: @ [4272,4273]
operator: @ [4272,4273]
===
match
---
name: patch [18688,18693]
name: patch [18706,18711]
===
match
---
trailer [42357,42378]
trailer [42375,42396]
===
match
---
name: url [36016,36019]
name: url [36034,36037]
===
match
---
dictorsetmaker [13172,13325]
dictorsetmaker [13190,13343]
===
match
---
name: url [20199,20202]
name: url [20217,20220]
===
match
---
name: connection_dict [9911,9926]
name: connection_dict [9923,9938]
===
match
---
trailer [42140,42142]
trailer [42158,42160]
===
match
---
name: kwargs [24785,24791]
name: kwargs [24803,24809]
===
match
---
name: secret_path [40336,40347]
name: secret_path [40354,40365]
===
match
---
name: mock_connection [2123,2138]
name: mock_connection [2123,2138]
===
match
---
name: self [4483,4487]
name: self [4483,4487]
===
match
---
with_item [25986,26050]
with_item [26004,26068]
===
match
---
name: credentials [16764,16775]
name: credentials [16782,16793]
===
match
---
expr_stmt [36585,36629]
expr_stmt [36603,36647]
===
match
---
dotted_name [47310,47320]
dotted_name [47328,47338]
===
match
---
string: "vault_conn_id" [31701,31716]
string: "vault_conn_id" [31719,31734]
===
match
---
comparison [5076,5127]
comparison [5076,5127]
===
match
---
name: get_secret [38709,38719]
name: get_secret [38727,38737]
===
match
---
name: is_authenticated [13780,13796]
name: is_authenticated [13798,13814]
===
match
---
operator: { [17750,17751]
operator: { [17768,17769]
===
match
---
name: mock [9318,9322]
name: mock [9330,9334]
===
match
---
name: test_hook [10015,10024]
name: test_hook [10027,10036]
===
match
---
trailer [27983,27985]
trailer [28001,28003]
===
match
---
trailer [18219,18236]
trailer [18237,18254]
===
match
---
string: 'data' [41295,41301]
string: 'data' [41313,41319]
===
match
---
trailer [7775,7785]
trailer [7775,7785]
===
match
---
expr_stmt [41429,41495]
expr_stmt [41447,41513]
===
match
---
name: return_value [3094,3106]
name: return_value [3094,3106]
===
match
---
atom [6889,6922]
atom [6889,6922]
===
match
---
operator: = [8627,8628]
operator: = [8633,8634]
===
match
---
string: '' [43438,43440]
string: '' [43456,43458]
===
match
---
trailer [16443,16462]
trailer [16461,16480]
===
match
---
trailer [29056,29076]
trailer [29074,29094]
===
match
---
trailer [43287,43307]
trailer [43305,43325]
===
match
---
string: 'created_time' [45885,45899]
string: 'created_time' [45903,45917]
===
match
---
name: patch [10527,10532]
name: patch [10545,10550]
===
match
---
name: test_custom_auth_mount_point_init_params [4442,4482]
name: test_custom_auth_mount_point_init_params [4442,4482]
===
match
---
name: test_hook [26122,26131]
name: test_hook [26140,26149]
===
match
---
atom_expr [13357,13376]
atom_expr [13375,13394]
===
match
---
name: mock_get_credentials [17657,17677]
name: mock_get_credentials [17675,17695]
===
match
---
name: is_authenticated [10333,10349]
name: is_authenticated [10351,10367]
===
match
---
simple_stmt [46905,46995]
simple_stmt [46923,47013]
===
match
---
operator: , [39567,39568]
operator: , [39585,39586]
===
match
---
operator: = [37883,37884]
operator: = [37901,37902]
===
match
---
operator: , [41408,41409]
operator: , [41426,41427]
===
match
---
funcdef [3646,4267]
funcdef [3646,4267]
===
match
---
expr_stmt [44641,45283]
expr_stmt [44659,45301]
===
match
---
simple_stmt [46649,46700]
simple_stmt [46667,46718]
===
match
---
name: patch [21534,21539]
name: patch [21552,21557]
===
match
---
name: resource [14953,14961]
name: resource [14971,14979]
===
match
---
atom_expr [16293,16312]
atom_expr [16311,16330]
===
match
---
number: 1 [40570,40571]
number: 1 [40588,40589]
===
match
---
operator: = [7355,7356]
operator: = [7355,7356]
===
match
---
trailer [49145,49205]
trailer [49163,49223]
===
match
---
string: '94011e25-f8dc-ec29-221b-1f9c1d9ad2ae' [43374,43412]
string: '94011e25-f8dc-ec29-221b-1f9c1d9ad2ae' [43392,43430]
===
match
---
string: "http" [6890,6896]
string: "http" [6890,6896]
===
match
---
string: 'data' [38058,38064]
string: 'data' [38076,38082]
===
match
---
string: 'secret_value' [38107,38121]
string: 'secret_value' [38125,38139]
===
match
---
trailer [25733,25737]
trailer [25751,25755]
===
match
---
operator: @ [48390,48391]
operator: @ [48408,48409]
===
match
---
trailer [38671,38681]
trailer [38689,38699]
===
match
---
string: "radhost" [30468,30477]
string: "radhost" [30486,30495]
===
match
---
simple_stmt [8935,8991]
simple_stmt [8941,8997]
===
match
---
name: get_mock_connection [33404,33423]
name: get_mock_connection [33422,33441]
===
match
---
expr_stmt [9864,9930]
expr_stmt [9876,9942]
===
match
---
expr_stmt [21968,22032]
expr_stmt [21986,22050]
===
match
---
operator: { [26995,26996]
operator: { [27013,27014]
===
match
---
operator: , [13714,13715]
operator: , [13732,13733]
===
match
---
name: test_hook [49112,49121]
name: test_hook [49130,49139]
===
match
---
argument [21390,21402]
argument [21408,21420]
===
match
---
name: create_or_update_secret [47157,47180]
name: create_or_update_secret [47175,47198]
===
match
---
dictorsetmaker [22140,22173]
dictorsetmaker [22158,22191]
===
match
---
expr_stmt [44611,44631]
expr_stmt [44629,44649]
===
match
---
string: "vault_conn_id" [18002,18017]
string: "vault_conn_id" [18020,18035]
===
match
---
name: Client [11241,11247]
name: Client [11259,11265]
===
match
---
name: mock_hvac [16628,16637]
name: mock_hvac [16646,16655]
===
match
---
atom [18346,18366]
atom [18364,18384]
===
match
---
name: kv [38827,38829]
name: kv [38845,38847]
===
match
---
simple_stmt [46596,46641]
simple_stmt [46614,46659]
===
match
---
operator: @ [25231,25232]
operator: @ [25249,25250]
===
match
---
trailer [11482,11501]
trailer [11500,11519]
===
match
---
name: mock_get_scopes [17368,17383]
name: mock_get_scopes [17386,17401]
===
match
---
number: 1 [41591,41592]
number: 1 [41609,41610]
===
match
---
operator: ** [11106,11108]
operator: ** [11124,11126]
===
match
---
operator: = [1647,1648]
operator: = [1647,1648]
===
match
---
name: role [12572,12576]
name: role [12590,12594]
===
match
---
trailer [10727,10734]
trailer [10745,10752]
===
match
---
operator: , [35798,35799]
operator: , [35816,35817]
===
match
---
name: expected_method [48606,48621]
name: expected_method [48624,48639]
===
match
---
name: get_mock_connection [44430,44449]
name: get_mock_connection [44448,44467]
===
match
---
name: return_value [37663,37675]
name: return_value [37681,37693]
===
match
---
operator: @ [2757,2758]
operator: @ [2757,2758]
===
match
---
arglist [26380,26408]
arglist [26398,26426]
===
match
---
trailer [11835,11837]
trailer [11853,11855]
===
match
---
operator: , [31582,31583]
operator: , [31600,31601]
===
match
---
suite [46587,47304]
suite [46605,47322]
===
match
---
name: mock_connection [47796,47811]
name: mock_connection [47814,47829]
===
match
---
argument [44122,44136]
argument [44140,44154]
===
match
---
string: 'metadata' [43519,43529]
string: 'metadata' [43537,43547]
===
match
---
name: assert_called_once_with [44063,44086]
name: assert_called_once_with [44081,44104]
===
match
---
operator: = [31429,31430]
operator: = [31447,31448]
===
match
---
argument [16303,16311]
argument [16321,16329]
===
match
---
name: assert_called_with [26361,26379]
name: assert_called_with [26379,26397]
===
match
---
simple_stmt [27007,27074]
simple_stmt [27025,27092]
===
match
---
expr_stmt [34904,34938]
expr_stmt [34922,34956]
===
match
---
operator: , [38011,38012]
operator: , [38029,38030]
===
match
---
atom_expr [17934,17953]
atom_expr [17952,17971]
===
match
---
operator: , [33661,33662]
operator: , [33679,33680]
===
match
---
trailer [2479,2486]
trailer [2479,2486]
===
match
---
name: kwargs [18062,18068]
name: kwargs [18080,18086]
===
match
---
dotted_name [31017,31027]
dotted_name [31035,31045]
===
match
---
atom_expr [6244,6260]
atom_expr [6244,6260]
===
match
---
simple_stmt [30320,30387]
simple_stmt [30338,30405]
===
match
---
simple_stmt [38476,38543]
simple_stmt [38494,38561]
===
match
---
name: mock_connection [3217,3232]
name: mock_connection [3217,3232]
===
match
---
string: 'scope2' [20135,20143]
string: 'scope2' [20153,20161]
===
match
---
trailer [15701,15714]
trailer [15719,15732]
===
match
---
trailer [16712,16717]
trailer [16730,16735]
===
match
---
simple_stmt [36849,36916]
simple_stmt [36867,36934]
===
match
---
decorator [12600,12680]
decorator [12618,12698]
===
match
---
atom_expr [28957,28973]
atom_expr [28975,28991]
===
match
---
name: mock_connection [30177,30192]
name: mock_connection [30195,30210]
===
match
---
expr_stmt [4023,4089]
expr_stmt [4023,4089]
===
match
---
param [15620,15635]
param [15638,15653]
===
match
---
string: 'scope1' [17629,17637]
string: 'scope1' [17647,17655]
===
match
---
name: mock_connection [37678,37693]
name: mock_connection [37696,37711]
===
match
---
name: test_hook [11202,11211]
name: test_hook [11220,11229]
===
match
---
trailer [4548,4558]
trailer [4548,4558]
===
match
---
number: 1 [38333,38334]
number: 1 [38351,38352]
===
match
---
string: "pass" [37216,37222]
string: "pass" [37234,37240]
===
match
---
operator: == [41730,41732]
operator: == [41748,41750]
===
match
---
name: auth [31986,31990]
name: auth [32004,32008]
===
match
---
name: mount_point [46281,46292]
name: mount_point [46299,46310]
===
match
---
name: self [34481,34485]
name: self [34499,34503]
===
match
---
name: match [2499,2504]
name: match [2499,2504]
===
match
---
simple_stmt [7248,7279]
simple_stmt [7248,7279]
===
match
---
atom_expr [40847,40873]
atom_expr [40865,40891]
===
match
---
name: return_value [25635,25647]
name: return_value [25653,25665]
===
match
---
number: 2 [10386,10387]
number: 2 [10404,10405]
===
match
---
expr_stmt [7410,7460]
expr_stmt [7410,7460]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [48486,48550]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [48504,48568]
===
match
---
atom_expr [40278,40297]
atom_expr [40296,40315]
===
match
---
dotted_name [11571,11581]
dotted_name [11589,11599]
===
match
---
name: Client [46757,46763]
name: Client [46775,46781]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [12696,12760]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [12714,12778]
===
match
---
name: mock_get_connection [9524,9543]
name: mock_get_connection [9536,9555]
===
match
---
expr_stmt [46596,46640]
expr_stmt [46614,46658]
===
match
---
trailer [40486,40510]
trailer [40504,40528]
===
match
---
expr_stmt [7858,7892]
expr_stmt [7858,7892]
===
match
---
trailer [37750,37757]
trailer [37768,37775]
===
match
---
string: "vault_conn_id" [4895,4910]
string: "vault_conn_id" [4895,4910]
===
match
---
simple_stmt [20740,20784]
simple_stmt [20758,20802]
===
match
---
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [41865,41931]
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [41883,41949]
===
match
---
atom_expr [25485,25501]
atom_expr [25503,25519]
===
match
---
atom_expr [36508,36524]
atom_expr [36526,36542]
===
match
---
string: "role" [12065,12071]
string: "role" [12083,12089]
===
match
---
operator: } [44938,44939]
operator: } [44956,44957]
===
match
---
name: connection_dict [16061,16076]
name: connection_dict [16079,16094]
===
match
---
trailer [28336,28355]
trailer [28354,28373]
===
match
---
param [21734,21753]
param [21752,21771]
===
match
---
name: patch [11660,11665]
name: patch [11678,11683]
===
match
---
name: kwargs [10039,10045]
name: kwargs [10051,10057]
===
match
---
expr_stmt [46747,46790]
expr_stmt [46765,46808]
===
match
---
name: VaultHook [38662,38671]
name: VaultHook [38680,38689]
===
match
---
argument [30760,30787]
argument [30778,30805]
===
match
---
operator: = [29259,29260]
operator: = [29277,29278]
===
match
---
name: connection_dict [19707,19722]
name: connection_dict [19725,19740]
===
match
---
trailer [15103,15105]
trailer [15121,15123]
===
match
---
name: mock_get_connection [34342,34361]
name: mock_get_connection [34360,34379]
===
match
---
atom_expr [3767,3796]
atom_expr [3767,3796]
===
match
---
name: MagicMock [8426,8435]
name: MagicMock [8432,8441]
===
match
---
string: 'scope2' [15891,15899]
string: 'scope2' [15909,15917]
===
match
---
string: "radius" [30431,30439]
string: "radius" [30449,30457]
===
match
---
name: scopes [18339,18345]
name: scopes [18357,18363]
===
match
---
name: extra_dejson [36790,36802]
name: extra_dejson [36808,36820]
===
match
---
operator: , [42883,42884]
operator: , [42901,42902]
===
match
---
name: Client [26822,26828]
name: Client [26840,26846]
===
match
---
operator: { [38092,38093]
operator: { [38110,38111]
===
match
---
dictorsetmaker [38093,38121]
dictorsetmaker [38111,38139]
===
match
---
name: get [20964,20967]
name: get [20982,20985]
===
match
---
trailer [4085,4089]
trailer [4085,4089]
===
match
---
name: extra_dejson [6526,6538]
name: extra_dejson [6526,6538]
===
match
---
trailer [4838,4842]
trailer [4838,4842]
===
match
---
operator: = [31870,31871]
operator: = [31888,31889]
===
match
---
trailer [9293,9311]
trailer [9305,9323]
===
match
---
operator: } [40421,40422]
operator: } [40439,40440]
===
match
---
name: self [2856,2860]
name: self [2856,2860]
===
match
---
operator: @ [32277,32278]
operator: @ [32295,32296]
===
match
---
string: 'http://localhost:8180' [30764,30787]
string: 'http://localhost:8180' [30782,30805]
===
match
---
name: side_effect [48931,48942]
name: side_effect [48949,48960]
===
match
---
trailer [27250,27269]
trailer [27268,27287]
===
match
---
name: mock [18683,18687]
name: mock [18701,18705]
===
match
---
expr_stmt [47674,47704]
expr_stmt [47692,47722]
===
match
---
trailer [32007,32026]
trailer [32025,32044]
===
match
---
trailer [2087,2100]
trailer [2087,2100]
===
match
---
operator: , [1211,1212]
operator: , [1211,1212]
===
match
---
atom [17750,17877]
atom [17768,17895]
===
match
---
trailer [48930,48942]
trailer [48948,48960]
===
match
---
string: "vault_conn_id" [3332,3347]
string: "vault_conn_id" [3332,3347]
===
match
---
name: mock_get_connection [14263,14282]
name: mock_get_connection [14281,14300]
===
match
---
operator: = [9166,9167]
operator: = [9178,9179]
===
match
---
string: '94011e25-f8dc-ec29-221b-1f9c1d9ad2ae' [45624,45662]
string: '94011e25-f8dc-ec29-221b-1f9c1d9ad2ae' [45642,45680]
===
match
---
assert_stmt [26476,26528]
assert_stmt [26494,26546]
===
match
---
name: mock [5990,5994]
name: mock [5990,5994]
===
match
---
argument [47992,48000]
argument [48010,48018]
===
match
---
name: mock_hvac [40788,40797]
name: mock_hvac [40806,40815]
===
match
---
decorator [38956,39036]
decorator [38974,39054]
===
match
---
operator: , [28559,28560]
operator: , [28577,28578]
===
match
---
name: extra_dejson [4826,4838]
name: extra_dejson [4826,4838]
===
match
---
operator: = [31264,31265]
operator: = [31282,31283]
===
match
---
funcdef [14050,15167]
funcdef [14068,15185]
===
match
---
name: patch [15375,15380]
name: patch [15393,15398]
===
match
---
operator: , [48232,48233]
operator: , [48250,48251]
===
match
---
name: Client [37082,37088]
name: Client [37100,37106]
===
match
---
operator: = [21871,21872]
operator: = [21889,21890]
===
match
---
operator: , [7205,7206]
operator: , [7205,7206]
===
match
---
operator: } [43216,43217]
operator: } [43234,43235]
===
match
---
operator: = [14749,14750]
operator: = [14767,14768]
===
match
---
string: "auth_type" [5609,5620]
string: "auth_type" [5609,5620]
===
match
---
name: url [11267,11270]
name: url [11285,11288]
===
match
---
simple_stmt [35020,35070]
simple_stmt [35038,35088]
===
match
---
atom_expr [37716,37732]
atom_expr [37734,37750]
===
match
---
atom [38560,38640]
atom [38578,38658]
===
match
---
operator: = [27089,27090]
operator: = [27107,27108]
===
match
---
operator: @ [35179,35180]
operator: @ [35197,35198]
===
match
---
number: 1 [46044,46045]
number: 1 [46062,46063]
===
match
---
string: 'lease_duration' [38025,38041]
string: 'lease_duration' [38043,38059]
===
match
---
operator: = [13017,13018]
operator: = [13035,13036]
===
match
---
name: mock_get_connection [7218,7237]
name: mock_get_connection [7218,7237]
===
match
---
name: Client [7297,7303]
name: Client [7297,7303]
===
match
---
operator: = [14643,14644]
operator: = [14661,14662]
===
match
---
atom_expr [16061,16080]
atom_expr [16079,16098]
===
match
---
name: raises [32955,32961]
name: raises [32973,32979]
===
match
---
string: "vault_conn_id" [4138,4153]
string: "vault_conn_id" [4138,4153]
===
match
---
dotted_name [38957,38967]
dotted_name [38975,38985]
===
match
---
atom_expr [43239,43258]
atom_expr [43257,43276]
===
match
---
operator: { [32662,32663]
operator: { [32680,32681]
===
match
---
string: "auth_type" [31488,31499]
string: "auth_type" [31506,31517]
===
match
---
trailer [26465,26467]
trailer [26483,26485]
===
match
---
operator: } [6686,6687]
operator: } [6686,6687]
===
match
---
name: connection_dict [48945,48960]
name: connection_dict [48963,48978]
===
match
---
decorated [46347,47304]
decorated [46365,47322]
===
match
---
param [24112,24117]
param [24130,24135]
===
match
---
decorator [2757,2835]
decorator [2757,2835]
===
match
---
atom_expr [15790,15822]
atom_expr [15808,15840]
===
match
---
operator: = [37111,37112]
operator: = [37129,37130]
===
match
---
import_as_names [901,931]
import_as_names [901,931]
===
match
---
funcdef [21694,22595]
funcdef [21712,22613]
===
match
---
operator: = [19821,19822]
operator: = [19839,19840]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [32289,32353]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [32307,32371]
===
match
---
trailer [46845,46858]
trailer [46863,46876]
===
match
---
atom_expr [4232,4266]
atom_expr [4232,4266]
===
match
---
operator: = [1186,1187]
operator: = [1186,1187]
===
match
---
name: return_value [37758,37770]
name: return_value [37776,37788]
===
match
---
string: "vault_conn_id" [43138,43153]
string: "vault_conn_id" [43156,43171]
===
match
---
trailer [22495,22512]
trailer [22513,22530]
===
match
---
string: "auth_type" [2255,2266]
string: "auth_type" [2255,2266]
===
match
---
decorator [35263,35341]
decorator [35281,35359]
===
match
---
string: 'http://localhost:8180' [26300,26323]
string: 'http://localhost:8180' [26318,26341]
===
match
---
expr_stmt [30681,30715]
expr_stmt [30699,30733]
===
match
---
name: test_get_existing_key_v1 [40757,40781]
name: test_get_existing_key_v1 [40775,40799]
===
match
---
trailer [35555,35557]
trailer [35573,35575]
===
match
---
operator: = [2252,2253]
operator: = [2252,2253]
===
match
---
name: connection_dict [31650,31665]
name: connection_dict [31668,31683]
===
match
---
operator: @ [25315,25316]
operator: @ [25333,25334]
===
match
---
string: 'http://localhost:8180' [27378,27401]
string: 'http://localhost:8180' [27396,27419]
===
match
---
dotted_name [15173,15183]
dotted_name [15191,15201]
===
match
---
atom [45596,46177]
atom [45614,46195]
===
match
---
name: mock_hvac [7901,7910]
name: mock_hvac [7901,7910]
===
match
---
name: version [46319,46326]
name: version [46337,46344]
===
match
---
trailer [23740,23759]
trailer [23758,23777]
===
match
---
argument [13728,13748]
argument [13746,13766]
===
match
---
expr_stmt [39206,39250]
expr_stmt [39224,39268]
===
match
---
name: mock_get_scopes [19958,19973]
name: mock_get_scopes [19976,19991]
===
match
---
trailer [11240,11247]
trailer [11258,11265]
===
match
---
name: test_version [2843,2855]
name: test_version [2843,2855]
===
match
---
simple_stmt [10119,10154]
simple_stmt [10131,10166]
===
match
---
name: mock_connection [44495,44510]
name: mock_connection [44513,44528]
===
match
---
name: mock_client [7248,7259]
name: mock_client [7248,7259]
===
match
---
name: mock_connection [27007,27022]
name: mock_connection [27025,27040]
===
match
---
trailer [31270,31280]
trailer [31288,31298]
===
match
---
operator: } [16270,16271]
operator: } [16288,16289]
===
match
---
trailer [9031,9033]
trailer [9037,9039]
===
match
---
operator: = [12947,12948]
operator: = [12965,12966]
===
match
---
operator: { [7584,7585]
operator: { [7584,7585]
===
match
---
trailer [36806,36818]
trailer [36824,36836]
===
match
---
name: connection_dict [46877,46892]
name: connection_dict [46895,46910]
===
match
---
param [22805,22815]
param [22823,22833]
===
match
---
param [7193,7206]
param [7193,7206]
===
match
---
operator: @ [5133,5134]
operator: @ [5133,5134]
===
match
---
assert_stmt [5069,5127]
assert_stmt [5069,5127]
===
match
---
operator: @ [23914,23915]
operator: @ [23932,23933]
===
match
---
name: return_value [47635,47647]
name: return_value [47653,47665]
===
match
---
trailer [8540,8542]
trailer [8546,8548]
===
match
---
atom_expr [12082,12126]
atom_expr [12100,12144]
===
match
---
name: assert_called_with [7988,8006]
name: assert_called_with [7994,8012]
===
match
---
expr_stmt [22042,22108]
expr_stmt [22060,22126]
===
match
---
operator: } [13334,13335]
operator: } [13352,13353]
===
match
---
decorated [5989,6789]
decorated [5989,6789]
===
match
---
name: patch [24004,24009]
name: patch [24022,24027]
===
match
---
trailer [20179,20198]
trailer [20197,20216]
===
match
---
operator: , [2448,2449]
operator: , [2448,2449]
===
match
---
name: extra_dejson [45309,45321]
name: extra_dejson [45327,45339]
===
match
---
name: expected_version [2871,2887]
name: expected_version [2871,2887]
===
match
---
param [15560,15565]
param [15578,15583]
===
match
---
name: self [32393,32397]
name: self [32411,32415]
===
match
---
name: mock_get_connection [6200,6219]
name: mock_get_connection [6200,6219]
===
match
---
simple_stmt [7794,7850]
simple_stmt [7794,7850]
===
match
---
trailer [24517,24521]
trailer [24535,24539]
===
match
---
trailer [22214,22224]
trailer [22232,22242]
===
match
---
operator: = [12127,12128]
operator: = [12145,12146]
===
match
---
string: "vault_conn_id" [10998,11013]
string: "vault_conn_id" [11016,11031]
===
match
---
name: mock_connection [17887,17902]
name: mock_connection [17905,17920]
===
match
---
operator: = [35529,35530]
operator: = [35547,35548]
===
match
---
operator: == [8116,8118]
operator: == [8122,8124]
===
match
---
name: mount_point [41810,41821]
name: mount_point [41828,41839]
===
match
---
string: "role_id" [8821,8830]
string: "role_id" [8827,8836]
===
match
---
name: assert_called_with [10260,10278]
name: assert_called_with [10278,10296]
===
match
---
trailer [14869,14875]
trailer [14887,14893]
===
match
---
atom_expr [29224,29243]
atom_expr [29242,29261]
===
match
---
operator: = [43237,43238]
operator: = [43255,43256]
===
match
---
name: assert_called_with [30637,30655]
name: assert_called_with [30655,30673]
===
match
---
operator: { [5608,5609]
operator: { [5608,5609]
===
match
---
name: assert_called_with [14797,14815]
name: assert_called_with [14815,14833]
===
match
---
operator: , [8838,8839]
operator: , [8844,8845]
===
match
---
param [37549,37559]
param [37567,37577]
===
match
---
operator: = [44423,44424]
operator: = [44441,44442]
===
match
---
trailer [28998,29011]
trailer [29016,29029]
===
match
---
simple_stmt [29087,29138]
simple_stmt [29105,29156]
===
match
---
suite [47553,48276]
suite [47571,48294]
===
match
---
string: "post" [48361,48367]
string: "post" [48379,48385]
===
match
---
operator: , [16144,16145]
operator: , [16162,16163]
===
match
---
expr_stmt [7339,7401]
expr_stmt [7339,7401]
===
match
---
string: 'scope2' [18357,18365]
string: 'scope2' [18375,18383]
===
match
---
name: assert_called_with [13598,13616]
name: assert_called_with [13616,13634]
===
match
---
operator: ** [26086,26088]
operator: ** [26104,26106]
===
match
---
decorators [5133,5295]
decorators [5133,5295]
===
match
---
string: 'destroyed' [42727,42738]
string: 'destroyed' [42745,42756]
===
match
---
operator: = [37041,37042]
operator: = [37059,37060]
===
match
---
string: "vault_conn_id" [23523,23538]
string: "vault_conn_id" [23541,23556]
===
match
---
operator: == [46178,46180]
operator: == [46196,46198]
===
match
---
name: extra_dejson [16030,16042]
name: extra_dejson [16048,16060]
===
match
---
atom_expr [28497,28577]
atom_expr [28515,28595]
===
match
---
simple_stmt [47004,47036]
simple_stmt [47022,47054]
===
match
---
param [15566,15576]
param [15584,15594]
===
match
---
trailer [6538,6542]
trailer [6538,6542]
===
match
---
operator: { [12029,12030]
operator: { [12047,12048]
===
match
---
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [6001,6067]
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [6001,6067]
===
match
---
parameters [1984,2022]
parameters [1984,2022]
===
match
---
trailer [22461,22475]
trailer [22479,22493]
===
match
---
trailer [1518,1537]
trailer [1518,1537]
===
match
---
operator: = [13673,13674]
operator: = [13691,13692]
===
match
---
name: is_authenticated [37244,37260]
name: is_authenticated [37262,37278]
===
match
---
atom_expr [34411,34440]
atom_expr [34429,34458]
===
match
---
name: self [35531,35535]
name: self [35549,35553]
===
match
---
name: mock_get_connection [20671,20690]
name: mock_get_connection [20689,20708]
===
match
---
operator: = [5606,5607]
operator: = [5606,5607]
===
match
---
argument [23419,23427]
argument [23437,23445]
===
match
---
atom_expr [5530,5562]
atom_expr [5530,5562]
===
match
---
name: mock_hvac [36453,36462]
name: mock_hvac [36471,36480]
===
match
---
expr_stmt [39440,40082]
expr_stmt [39458,40100]
===
match
---
string: "auth_type" [29275,29286]
string: "auth_type" [29293,29304]
===
match
---
atom_expr [38699,38742]
atom_expr [38717,38760]
===
match
---
atom_expr [13838,13878]
atom_expr [13856,13896]
===
match
---
decorator [6993,7073]
decorator [6993,7073]
===
match
---
name: assert_called_with [23558,23576]
name: assert_called_with [23576,23594]
===
match
---
name: url [34983,34986]
name: url [35001,35004]
===
match
---
simple_stmt [22484,22534]
simple_stmt [22502,22552]
===
match
---
operator: = [35599,35600]
operator: = [35617,35618]
===
match
---
number: 2 [25180,25181]
number: 2 [25198,25199]
===
match
---
simple_stmt [14210,14255]
simple_stmt [14228,14273]
===
match
---
name: password [1638,1646]
name: password [1638,1646]
===
match
---
name: get_secret [41662,41672]
name: get_secret [41680,41690]
===
match
---
atom_expr [2944,2960]
atom_expr [2944,2960]
===
match
---
string: "vault_conn_id" [24626,24641]
string: "vault_conn_id" [24644,24659]
===
match
---
trailer [4254,4266]
trailer [4254,4266]
===
match
---
name: return_value [26829,26841]
name: return_value [26847,26859]
===
match
---
name: mock_client [26844,26855]
name: mock_client [26862,26873]
===
match
---
atom [6936,6971]
atom [6936,6971]
===
match
---
name: side_effect [46863,46874]
name: side_effect [46881,46892]
===
match
---
name: secrets [41075,41082]
name: secrets [41093,41100]
===
match
---
expr_stmt [5477,5521]
expr_stmt [5477,5521]
===
match
---
operator: , [25428,25429]
operator: , [25446,25447]
===
match
---
trailer [3841,3861]
trailer [3841,3861]
===
match
---
operator: = [40535,40536]
operator: = [40553,40554]
===
match
---
trailer [18474,18478]
trailer [18492,18496]
===
match
---
name: get [23109,23112]
name: get [23127,23130]
===
match
---
name: mock [23915,23919]
name: mock [23933,23937]
===
match
---
operator: = [24379,24380]
operator: = [24397,24398]
===
match
---
operator: } [38639,38640]
operator: } [38657,38658]
===
match
---
operator: = [30365,30366]
operator: = [30383,30384]
===
match
---
expr_stmt [39410,39430]
expr_stmt [39428,39448]
===
match
---
simple_stmt [14557,14624]
simple_stmt [14575,14642]
===
match
---
trailer [37260,37279]
trailer [37278,37297]
===
match
---
trailer [5110,5127]
trailer [5110,5127]
===
match
---
string: "user" [1247,1253]
string: "user" [1247,1253]
===
match
---
name: extra_dejson [19676,19688]
name: extra_dejson [19694,19706]
===
match
---
name: assert_called_with [11144,11162]
name: assert_called_with [11162,11180]
===
match
---
expr_stmt [2393,2459]
expr_stmt [2393,2459]
===
match
---
trailer [32124,32126]
trailer [32142,32144]
===
match
---
name: mock_get_connection [12273,12292]
name: mock_get_connection [12291,12310]
===
match
---
string: 'deletion_time' [45952,45967]
string: 'deletion_time' [45970,45985]
===
match
---
trailer [19883,19885]
trailer [19901,19903]
===
match
---
parameters [48591,48654]
parameters [48609,48672]
===
match
---
operator: = [24817,24818]
operator: = [24835,24836]
===
match
---
trailer [7361,7381]
trailer [7361,7381]
===
match
---
trailer [13796,13815]
trailer [13814,13833]
===
match
---
atom_expr [4023,4067]
atom_expr [4023,4067]
===
match
---
atom_expr [35845,35864]
atom_expr [35863,35882]
===
match
---
expr_stmt [8716,8885]
expr_stmt [8722,8891]
===
match
---
operator: = [3963,3964]
operator: = [3963,3964]
===
match
---
atom_expr [12245,12264]
atom_expr [12263,12282]
===
match
---
name: patch [33056,33061]
name: patch [33074,33079]
===
match
---
arglist [23760,23788]
arglist [23778,23806]
===
match
---
atom_expr [22554,22594]
atom_expr [22572,22612]
===
match
---
simple_stmt [1027,1089]
simple_stmt [1027,1089]
===
match
---
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [8177,8243]
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [8183,8249]
===
match
---
name: assert_called_with [29655,29673]
name: assert_called_with [29673,29691]
===
match
---
string: 'custom' [3869,3877]
string: 'custom' [3869,3877]
===
match
---
name: get_mock_connection [31366,31385]
name: get_mock_connection [31384,31403]
===
match
---
dotted_name [952,967]
dotted_name [952,967]
===
match
---
expr_stmt [38551,38640]
expr_stmt [38569,38658]
===
match
---
funcdef [36422,37343]
funcdef [36440,37361]
===
match
---
name: kv [40461,40463]
name: kv [40479,40481]
===
match
---
dictorsetmaker [30418,30557]
dictorsetmaker [30436,30575]
===
match
---
decorator [34221,34299]
decorator [34239,34317]
===
match
---
operator: = [1674,1675]
operator: = [1674,1675]
===
match
---
atom [30308,30310]
atom [30326,30328]
===
match
---
decorators [8165,8327]
decorators [8171,8333]
===
match
---
trailer [17902,17915]
trailer [17920,17933]
===
match
---
trailer [33859,33878]
trailer [33877,33896]
===
match
---
name: mock_get_connection [35873,35892]
name: mock_get_connection [35891,35910]
===
match
---
trailer [20266,20285]
trailer [20284,20303]
===
match
---
name: configure [30821,30830]
name: configure [30839,30848]
===
match
---
expr_stmt [17657,17722]
expr_stmt [17675,17740]
===
match
---
parameters [37542,37580]
parameters [37560,37598]
===
match
---
name: secret_version [40359,40373]
name: secret_version [40377,40391]
===
match
---
name: test_hook [21239,21248]
name: test_hook [21257,21266]
===
match
---
operator: , [8021,8022]
operator: , [8027,8028]
===
match
---
dictorsetmaker [39700,39970]
dictorsetmaker [39718,39988]
===
match
---
dictorsetmaker [38174,38335]
dictorsetmaker [38192,38353]
===
match
---
operator: , [47238,47239]
operator: , [47256,47257]
===
match
---
operator: , [13204,13205]
operator: , [13222,13223]
===
match
---
name: mock [3481,3485]
name: mock [3481,3485]
===
match
---
argument [26086,26094]
argument [26104,26112]
===
match
---
decorator [6073,6151]
decorator [6073,6151]
===
match
---
operator: { [48241,48242]
operator: { [48259,48260]
===
match
---
atom_expr [36603,36629]
atom_expr [36621,36647]
===
match
---
name: get [3280,3283]
name: get [3280,3283]
===
match
---
suite [1277,1789]
suite [1277,1789]
===
match
---
name: mock_get_connection [15577,15596]
name: mock_get_connection [15595,15614]
===
match
---
dictorsetmaker [41130,41409]
dictorsetmaker [41148,41427]
===
match
---
trailer [14252,14254]
trailer [14270,14272]
===
match
---
param [33260,33279]
param [33278,33297]
===
match
---
operator: , [3347,3348]
operator: , [3347,3348]
===
match
---
operator: == [25182,25184]
operator: == [25200,25202]
===
match
---
trailer [31881,31890]
trailer [31899,31908]
===
match
---
name: test_kubernetes_init_params [24084,24111]
name: test_kubernetes_init_params [24102,24129]
===
match
---
simple_stmt [16628,16693]
simple_stmt [16646,16711]
===
match
---
simple_stmt [22340,22405]
simple_stmt [22358,22423]
===
match
---
operator: = [32049,32050]
operator: = [32067,32068]
===
match
---
atom_expr [6748,6788]
atom_expr [6748,6788]
===
match
---
trailer [27438,27457]
trailer [27456,27475]
===
match
---
dictorsetmaker [45885,46046]
dictorsetmaker [45903,46064]
===
match
---
name: mock_hvac [30045,30054]
name: mock_hvac [30063,30072]
===
match
---
name: MagicMock [30105,30114]
name: MagicMock [30123,30132]
===
match
---
name: secrets [44653,44660]
name: secrets [44671,44678]
===
match
---
trailer [19204,19211]
trailer [19222,19229]
===
match
---
atom_expr [16701,16800]
atom_expr [16719,16818]
===
match
---
name: mock [34138,34142]
name: mock [34156,34160]
===
match
---
simple_stmt [8611,8632]
simple_stmt [8617,8638]
===
match
---
name: mock_get_connection [13385,13404]
name: mock_get_connection [13403,13422]
===
match
---
trailer [9077,9106]
trailer [9083,9112]
===
match
---
operator: { [39768,39769]
operator: { [39786,39787]
===
match
---
operator: } [8884,8885]
operator: } [8890,8891]
===
match
---
expr_stmt [11898,11942]
expr_stmt [11916,11960]
===
match
---
atom_expr [12380,12444]
atom_expr [12398,12462]
===
match
---
name: mock_client [6230,6241]
name: mock_client [6230,6241]
===
match
---
expr_stmt [4173,4204]
expr_stmt [4173,4204]
===
match
---
atom_expr [31974,32068]
atom_expr [31992,32086]
===
match
---
simple_stmt [26151,26207]
simple_stmt [26169,26225]
===
match
---
operator: = [3150,3151]
operator: = [3150,3151]
===
match
---
decorators [4272,4434]
decorators [4272,4434]
===
match
---
operator: = [14226,14227]
operator: = [14244,14245]
===
match
---
funcdef [47475,48276]
funcdef [47493,48294]
===
match
---
name: kwargs [5847,5853]
name: kwargs [5847,5853]
===
match
---
string: "post" [48353,48359]
string: "post" [48371,48377]
===
match
---
decorator [20544,20622]
decorator [20562,20640]
===
match
---
param [39176,39195]
param [39194,39213]
===
match
---
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [28714,28780]
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [28732,28798]
===
match
---
name: get_conn [26132,26140]
name: get_conn [26150,26158]
===
match
---
expr_stmt [30320,30386]
expr_stmt [30338,30404]
===
match
---
operator: } [22182,22183]
operator: } [22200,22201]
===
match
---
argument [36947,36955]
argument [36965,36973]
===
match
---
decorators [5989,6151]
decorators [5989,6151]
===
match
---
string: "kube_role" [25082,25093]
string: "kube_role" [25100,25111]
===
match
---
param [3687,3697]
param [3687,3697]
===
match
---
trailer [39278,39291]
trailer [39296,39309]
===
match
---
simple_stmt [1546,1608]
simple_stmt [1546,1608]
===
match
---
string: "auth_type" [23178,23189]
string: "auth_type" [23196,23207]
===
match
---
name: v2 [47154,47156]
name: v2 [47172,47174]
===
match
---
expr_stmt [22297,22331]
expr_stmt [22315,22349]
===
match
---
string: "azure" [13231,13238]
string: "azure" [13249,13256]
===
match
---
expr_stmt [35656,35722]
expr_stmt [35674,35740]
===
match
---
name: assert_called_with [14886,14904]
name: assert_called_with [14904,14922]
===
match
---
argument [49301,49321]
argument [49319,49339]
===
match
---
simple_stmt [30086,30117]
simple_stmt [30104,30135]
===
match
---
atom_expr [37072,37136]
atom_expr [37090,37154]
===
match
---
name: connection_dict [10960,10975]
name: connection_dict [10978,10993]
===
match
---
comparison [25180,25225]
comparison [25198,25243]
===
match
---
name: secret [29690,29696]
name: secret [29708,29714]
===
match
---
atom_expr [15685,15714]
atom_expr [15703,15732]
===
match
---
string: "userpass" [36743,36753]
string: "userpass" [36761,36771]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [31112,31176]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [31130,31194]
===
match
---
name: key_path [16541,16549]
name: key_path [16559,16567]
===
match
---
parameters [30038,30076]
parameters [30056,30094]
===
match
---
trailer [12396,12415]
trailer [12414,12433]
===
match
---
string: "token" [34621,34628]
string: "token" [34639,34646]
===
match
---
trailer [7528,7532]
trailer [7528,7532]
===
match
---
name: mock_hvac [27889,27898]
name: mock_hvac [27907,27916]
===
match
---
atom [17628,17648]
atom [17646,17666]
===
match
---
name: mock_get_connection [20845,20864]
name: mock_get_connection [20863,20882]
===
match
---
name: get_mock_connection [2146,2165]
name: get_mock_connection [2146,2165]
===
match
---
name: Client [26270,26276]
name: Client [26288,26294]
===
match
---
name: user [1602,1606]
name: user [1602,1606]
===
match
---
assert_stmt [34078,34131]
assert_stmt [34096,34149]
===
match
---
operator: = [14961,14962]
operator: = [14979,14980]
===
match
---
operator: { [13158,13159]
operator: { [13176,13177]
===
match
---
operator: = [22858,22859]
operator: = [22876,22877]
===
match
---
name: test_client [8999,9010]
name: test_client [9005,9016]
===
match
---
dictorsetmaker [2416,2449]
dictorsetmaker [2416,2449]
===
match
---
name: VaultHook [40278,40287]
name: VaultHook [40296,40305]
===
match
---
simple_stmt [10321,10371]
simple_stmt [10339,10389]
===
match
---
name: kwargs [36849,36855]
name: kwargs [36867,36873]
===
match
---
arglist [29674,29714]
arglist [29692,29732]
===
match
---
param [42057,42067]
param [42075,42085]
===
match
---
operator: , [25439,25440]
operator: , [25457,25458]
===
match
---
argument [8007,8021]
argument [8013,8027]
===
match
---
operator: @ [36256,36257]
operator: @ [36274,36275]
===
match
---
atom_expr [8907,8926]
atom_expr [8913,8932]
===
match
---
expr_stmt [44519,44549]
expr_stmt [44537,44567]
===
match
---
name: connection_dict [47843,47858]
name: connection_dict [47861,47876]
===
match
---
decorator [27616,27696]
decorator [27634,27714]
===
match
---
number: 1 [45150,45151]
number: 1 [45168,45169]
===
match
---
name: mock_client [2032,2043]
name: mock_client [2032,2043]
===
match
---
name: mock_hvac [12380,12389]
name: mock_hvac [12398,12407]
===
match
---
number: 2 [33684,33685]
number: 2 [33702,33703]
===
match
---
string: "aws_iam" [11045,11054]
string: "aws_iam" [11063,11072]
===
match
---
name: expected_url [7941,7953]
name: expected_url [7941,7953]
===
match
---
name: mock_get_connection [7410,7429]
name: mock_get_connection [7410,7429]
===
match
---
with_item [23319,23383]
with_item [23337,23401]
===
match
---
trailer [32824,32836]
trailer [32842,32854]
===
match
---
trailer [39366,39373]
trailer [39384,39391]
===
match
---
trailer [31300,31307]
trailer [31318,31325]
===
match
---
string: 'secret' [38902,38910]
string: 'secret' [38920,38928]
===
match
---
name: patch [12606,12611]
name: patch [12624,12629]
===
match
---
expr_stmt [36774,36840]
expr_stmt [36792,36858]
===
match
---
operator: , [30864,30865]
operator: , [30882,30883]
===
match
---
testlist_comp [6840,6874]
testlist_comp [6840,6874]
===
match
---
trailer [16046,16058]
trailer [16064,16076]
===
match
---
assert_stmt [16867,16919]
assert_stmt [16885,16937]
===
match
---
expr_stmt [1693,1757]
expr_stmt [1693,1757]
===
match
---
expr_stmt [33381,33425]
expr_stmt [33399,33443]
===
match
---
operator: } [6499,6500]
operator: } [6499,6500]
===
match
---
operator: } [9853,9854]
operator: } [9865,9866]
===
match
---
name: mock_connection [46596,46611]
name: mock_connection [46614,46629]
===
match
---
expr_stmt [11846,11889]
expr_stmt [11864,11907]
===
match
---
trailer [11920,11940]
trailer [11938,11958]
===
match
---
string: "vault_conn_id" [25929,25944]
string: "vault_conn_id" [25947,25962]
===
match
---
name: get_conn [33824,33832]
name: get_conn [33842,33850]
===
match
---
name: VaultHook [26076,26085]
name: VaultHook [26094,26103]
===
match
---
simple_stmt [40882,40933]
simple_stmt [40900,40951]
===
match
---
atom_expr [26917,26949]
atom_expr [26935,26967]
===
match
---
trailer [33554,33566]
trailer [33572,33584]
===
match
---
decorated [15172,16920]
decorated [15190,16938]
===
match
---
trailer [25737,25749]
trailer [25755,25767]
===
match
---
name: test_client [20344,20355]
name: test_client [20362,20373]
===
match
---
name: mock_client [27921,27932]
name: mock_client [27939,27950]
===
match
---
number: 0 [43504,43505]
number: 0 [43522,43523]
===
match
---
trailer [13102,13106]
trailer [13120,13124]
===
match
---
operator: } [3357,3358]
operator: } [3357,3358]
===
match
---
operator: , [43876,43877]
operator: , [43894,43895]
===
match
---
string: 'scope1' [18347,18355]
string: 'scope1' [18365,18373]
===
match
---
trailer [22959,22979]
trailer [22977,22997]
===
match
---
atom_expr [22484,22533]
atom_expr [22502,22551]
===
match
---
operator: , [9812,9813]
operator: , [9824,9825]
===
match
---
argument [28299,28307]
argument [28317,28325]
===
match
---
trailer [23324,23370]
trailer [23342,23388]
===
match
---
dictorsetmaker [33607,33685]
dictorsetmaker [33625,33703]
===
match
---
operator: = [28393,28394]
operator: = [28411,28412]
===
match
---
expr_stmt [5425,5468]
expr_stmt [5425,5468]
===
match
---
expr_stmt [6269,6312]
expr_stmt [6269,6312]
===
match
---
operator: , [2631,2632]
operator: , [2631,2632]
===
match
---
argument [10037,10045]
argument [10049,10057]
===
match
---
operator: , [20658,20659]
operator: , [20676,20677]
===
match
---
operator: = [5718,5719]
operator: = [5718,5719]
===
match
---
name: assert_called_with [32106,32124]
name: assert_called_with [32124,32142]
===
match
---
name: test_client [21341,21352]
name: test_client [21359,21370]
===
match
---
trailer [30947,30949]
trailer [30965,30967]
===
match
---
expr_stmt [10770,10814]
expr_stmt [10788,10832]
===
match
---
operator: = [27377,27378]
operator: = [27395,27396]
===
match
---
name: self [6339,6343]
name: self [6339,6343]
===
match
---
name: kv_engine_version [18659,18676]
name: kv_engine_version [18677,18694]
===
match
---
testlist_comp [42597,43018]
testlist_comp [42615,43036]
===
match
---
trailer [32458,32468]
trailer [32476,32486]
===
match
---
atom_expr [48010,48096]
atom_expr [48028,48114]
===
match
---
trailer [42258,42265]
trailer [42276,42283]
===
match
---
expr_stmt [3292,3358]
expr_stmt [3292,3358]
===
match
---
operator: = [48980,48981]
operator: = [48998,48999]
===
match
---
name: mock_client [47131,47142]
name: mock_client [47149,47160]
===
match
---
name: mock_connection [9645,9660]
name: mock_connection [9657,9672]
===
match
---
atom_expr [20935,20979]
atom_expr [20953,20997]
===
match
---
parameters [28895,28933]
parameters [28913,28951]
===
match
---
operator: = [24725,24726]
operator: = [24743,24744]
===
match
---
simple_stmt [34947,35012]
simple_stmt [34965,35030]
===
match
---
expr_stmt [17394,17424]
expr_stmt [17412,17442]
===
match
---
trailer [44035,44038]
trailer [44053,44056]
===
match
---
name: secret [47260,47266]
name: secret [47278,47284]
===
match
---
trailer [44027,44035]
trailer [44045,44053]
===
match
---
operator: , [48062,48063]
operator: , [48080,48081]
===
match
---
operator: = [49312,49313]
operator: = [49330,49331]
===
match
---
operator: , [38399,38400]
operator: , [38417,38418]
===
match
---
operator: } [45282,45283]
operator: } [45300,45301]
===
match
---
expr_stmt [4674,4724]
expr_stmt [4674,4724]
===
match
---
name: extra_dejson [31619,31631]
name: extra_dejson [31637,31649]
===
match
---
testlist_comp [48327,48337]
testlist_comp [48345,48355]
===
match
---
trailer [2350,2362]
trailer [2350,2362]
===
match
---
operator: { [4752,4753]
operator: { [4752,4753]
===
match
---
name: mock_client [35493,35504]
name: mock_client [35511,35522]
===
match
---
simple_stmt [24303,24354]
simple_stmt [24321,24372]
===
match
---
trailer [10400,10413]
trailer [10418,10431]
===
match
---
operator: = [17501,17502]
operator: = [17519,17520]
===
match
---
assert_stmt [8107,8159]
assert_stmt [8113,8165]
===
match
---
name: mock_get_connection [2176,2195]
name: mock_get_connection [2176,2195]
===
match
---
name: patch [3486,3491]
name: patch [3486,3491]
===
match
---
decorators [47309,47471]
decorators [47327,47489]
===
match
---
expr_stmt [3819,3878]
expr_stmt [3819,3878]
===
match
---
name: test_client [35020,35031]
name: test_client [35038,35049]
===
match
---
decorated [12600,13879]
decorated [12618,13897]
===
match
---
string: "vault_conn_id" [6644,6659]
string: "vault_conn_id" [6644,6659]
===
match
---
simple_stmt [25030,25107]
simple_stmt [25048,25125]
===
match
---
atom_expr [10391,10431]
atom_expr [10409,10449]
===
match
---
operator: @ [6794,6795]
operator: @ [6794,6795]
===
match
---
expr_stmt [32644,32782]
expr_stmt [32662,32800]
===
match
---
trailer [24521,24533]
trailer [24539,24551]
===
match
---
expr_stmt [41033,41053]
expr_stmt [41051,41071]
===
match
---
trailer [26243,26251]
trailer [26261,26269]
===
match
---
operator: , [49189,49190]
operator: , [49207,49208]
===
match
---
name: kwargs [10988,10994]
name: kwargs [11006,11012]
===
match
---
name: self [46549,46553]
name: self [46567,46571]
===
match
---
name: test_client [25115,25126]
name: test_client [25133,25144]
===
match
---
string: "missing" [38732,38741]
string: "missing" [38750,38759]
===
match
---
atom_expr [18245,18376]
atom_expr [18263,18394]
===
match
---
name: mock_client [46779,46790]
name: mock_client [46797,46808]
===
match
---
atom_expr [23455,23475]
atom_expr [23473,23493]
===
match
---
operator: } [17876,17877]
operator: } [17894,17895]
===
match
---
trailer [21357,21364]
trailer [21375,21382]
===
match
---
name: scopes [20117,20123]
name: scopes [20135,20141]
===
match
---
name: side_effect [19693,19704]
name: side_effect [19711,19722]
===
match
---
name: get_mock_connection [15760,15779]
name: get_mock_connection [15778,15797]
===
match
---
string: 'renewable' [41224,41235]
string: 'renewable' [41242,41253]
===
match
---
simple_stmt [4173,4205]
simple_stmt [4173,4205]
===
match
---
trailer [1318,1320]
trailer [1318,1320]
===
match
---
simple_stmt [19195,19239]
simple_stmt [19213,19257]
===
match
---
operator: ** [6718,6720]
operator: ** [6718,6720]
===
match
---
operator: , [14972,14973]
operator: , [14990,14991]
===
match
---
name: MagicMock [2949,2958]
name: MagicMock [2949,2958]
===
match
---
operator: , [2869,2870]
operator: , [2869,2870]
===
match
---
simple_stmt [42210,42241]
simple_stmt [42228,42259]
===
match
---
string: 'lease_id' [43426,43436]
string: 'lease_id' [43444,43454]
===
match
---
trailer [47722,47729]
trailer [47740,47747]
===
match
---
trailer [46892,46896]
trailer [46910,46914]
===
match
---
suite [26764,27611]
suite [26782,27629]
===
match
---
trailer [46726,46736]
trailer [46744,46754]
===
match
---
simple_stmt [14737,14772]
simple_stmt [14755,14790]
===
match
---
comparison [36205,36250]
comparison [36223,36268]
===
match
---
expr_stmt [2032,2062]
expr_stmt [2032,2062]
===
match
---
string: "radhost" [29325,29334]
string: "radhost" [29343,29352]
===
match
---
string: "vault_conn_id" [11015,11030]
string: "vault_conn_id" [11033,11048]
===
match
---
atom_expr [43278,43330]
atom_expr [43296,43348]
===
match
---
param [48623,48633]
param [48641,48651]
===
match
---
testlist_comp [18347,18365]
testlist_comp [18365,18383]
===
match
---
trailer [42120,42140]
trailer [42138,42158]
===
match
---
operator: = [46326,46327]
operator: = [46344,46345]
===
match
---
string: "role_id" [11056,11065]
string: "role_id" [11074,11083]
===
match
---
trailer [12254,12264]
trailer [12272,12282]
===
match
---
operator: = [27919,27920]
operator: = [27937,27938]
===
match
---
name: assert_called_with [8955,8973]
name: assert_called_with [8961,8979]
===
match
---
atom_expr [29413,29432]
atom_expr [29431,29450]
===
match
---
param [35375,35380]
param [35393,35398]
===
match
---
dotted_name [35180,35190]
dotted_name [35198,35208]
===
match
---
name: test_client [13768,13779]
name: test_client [13786,13797]
===
match
---
trailer [9022,9031]
trailer [9028,9037]
===
match
---
operator: , [12212,12213]
operator: , [12230,12231]
===
match
---
operator: } [43749,43750]
operator: } [43767,43768]
===
match
---
atom_expr [4544,4560]
atom_expr [4544,4560]
===
match
---
trailer [40871,40873]
trailer [40889,40891]
===
match
---
trailer [19374,19387]
trailer [19392,19405]
===
match
---
string: 'version' [43719,43728]
string: 'version' [43737,43746]
===
match
---
name: is_authenticated [25127,25143]
name: is_authenticated [25145,25161]
===
match
---
atom_expr [32147,32187]
atom_expr [32165,32205]
===
match
---
funcdef [30006,31011]
funcdef [30024,31029]
===
match
---
trailer [43248,43258]
trailer [43266,43276]
===
match
---
trailer [23724,23740]
trailer [23742,23758]
===
match
---
name: auth [18470,18474]
name: auth [18488,18492]
===
match
---
string: "scope1,scope2" [19993,20008]
string: "scope1,scope2" [20011,20026]
===
match
---
string: "vault_conn_id" [33607,33622]
string: "vault_conn_id" [33625,33640]
===
match
---
arglist [9159,9191]
arglist [9171,9203]
===
match
---
operator: , [40797,40798]
operator: , [40815,40816]
===
match
---
trailer [38876,38950]
trailer [38894,38968]
===
match
---
trailer [42238,42240]
trailer [42256,42258]
===
match
---
operator: } [35822,35823]
operator: } [35840,35841]
===
match
---
name: mock_client [34372,34383]
name: mock_client [34390,34401]
===
match
---
name: kv_engine_version [11547,11564]
name: kv_engine_version [11565,11582]
===
match
---
operator: { [44883,44884]
operator: { [44901,44902]
===
match
---
operator: , [48604,48605]
operator: , [48622,48623]
===
match
---
param [47532,47551]
param [47550,47569]
===
match
---
string: "path.json" [18307,18318]
string: "path.json" [18325,18336]
===
match
---
name: assert_called_with [18595,18613]
name: assert_called_with [18613,18631]
===
match
---
param [14078,14088]
param [14096,14106]
===
match
---
name: assert_called_with [22253,22271]
name: assert_called_with [22271,22289]
===
match
---
argument [12416,12443]
argument [12434,12461]
===
match
---
operator: == [37299,37301]
operator: == [37317,37319]
===
match
---
atom_expr [2176,2208]
atom_expr [2176,2208]
===
match
---
operator: { [32876,32877]
operator: { [32894,32895]
===
match
---
name: mock [22685,22689]
name: mock [22703,22707]
===
match
---
name: assert_called_with [10179,10197]
name: assert_called_with [10191,10209]
===
match
---
operator: = [31940,31941]
operator: = [31958,31959]
===
match
---
argument [12541,12558]
argument [12559,12576]
===
match
---
operator: , [26396,26397]
operator: , [26414,26415]
===
match
---
simple_stmt [12879,12923]
simple_stmt [12897,12941]
===
match
---
trailer [10171,10178]
trailer [10183,10190]
===
match
---
name: kwargs [21145,21151]
name: kwargs [21163,21169]
===
match
---
name: path [46303,46307]
name: path [46321,46325]
===
match
---
string: 'value' [41712,41719]
string: 'value' [41730,41737]
===
match
---
name: url [16664,16667]
name: url [16682,16685]
===
match
---
operator: { [10997,10998]
operator: { [11015,11016]
===
match
---
trailer [35854,35864]
trailer [35872,35882]
===
match
---
name: Client [3777,3783]
name: Client [3777,3783]
===
match
---
trailer [23522,23539]
trailer [23540,23557]
===
match
---
parameters [14071,14109]
parameters [14089,14127]
===
match
---
name: login [27433,27438]
name: login [27451,27456]
===
match
---
operator: , [45755,45756]
operator: , [45773,45774]
===
match
---
simple_stmt [36925,36957]
simple_stmt [36943,36975]
===
match
---
name: test_hook [22193,22202]
name: test_hook [22211,22220]
===
match
---
trailer [19722,19726]
trailer [19740,19744]
===
match
---
decorator [15453,15531]
decorator [15471,15549]
===
match
---
name: assert_called_with [24974,24992]
name: assert_called_with [24992,25010]
===
match
---
funcdef [9483,10432]
funcdef [9495,10450]
===
match
---
name: assert_called_with [34860,34878]
name: assert_called_with [34878,34896]
===
match
---
string: 'http://localhost:8180' [33883,33906]
string: 'http://localhost:8180' [33901,33924]
===
match
---
trailer [14232,14252]
trailer [14250,14270]
===
match
---
name: test_hook [11084,11093]
name: test_hook [11102,11111]
===
match
---
argument [18060,18068]
argument [18078,18086]
===
match
---
string: 'destroyed' [38282,38293]
string: 'destroyed' [38300,38311]
===
match
---
name: kwargs [26088,26094]
name: kwargs [26106,26112]
===
match
---
trailer [37730,37732]
trailer [37748,37750]
===
match
---
name: client_secret [15016,15029]
name: client_secret [15034,15047]
===
match
---
operator: , [31547,31548]
operator: , [31565,31566]
===
match
---
name: return_value [44480,44492]
name: return_value [44498,44510]
===
match
---
expr_stmt [27007,27073]
expr_stmt [27025,27091]
===
match
---
argument [9078,9105]
argument [9084,9111]
===
match
---
simple_stmt [29147,29168]
simple_stmt [29165,29186]
===
match
---
atom_expr [28317,28372]
atom_expr [28335,28390]
===
match
---
string: "token" [41561,41568]
string: "token" [41579,41586]
===
match
---
name: test_hook [21482,21491]
name: test_hook [21500,21509]
===
match
---
operator: = [35642,35643]
operator: = [35660,35661]
===
match
---
atom_expr [24819,24839]
atom_expr [24837,24857]
===
match
---
argument [49166,49189]
argument [49184,49207]
===
match
---
arglist [37190,37222]
arglist [37208,37240]
===
match
---
simple_stmt [17538,17589]
simple_stmt [17556,17607]
===
match
---
number: 1 [2649,2650]
number: 1 [2649,2650]
===
match
---
simple_stmt [15737,15782]
simple_stmt [15755,15800]
===
match
---
trailer [16717,16721]
trailer [16735,16739]
===
match
---
string: "userpass" [6479,6489]
string: "userpass" [6479,6489]
===
match
---
argument [47218,47238]
argument [47236,47256]
===
match
---
name: patch [41943,41948]
name: patch [41961,41966]
===
match
---
name: mock_hvac [26732,26741]
name: mock_hvac [26750,26759]
===
match
---
operator: ** [19833,19835]
operator: ** [19851,19853]
===
match
---
number: 2 [15121,15122]
number: 2 [15139,15140]
===
match
---
name: mock_connection [35601,35616]
name: mock_connection [35619,35634]
===
match
---
simple_stmt [13565,13760]
simple_stmt [13583,13778]
===
match
---
name: test_hook [35133,35142]
name: test_hook [35151,35160]
===
match
---
name: self [11916,11920]
name: self [11934,11938]
===
match
---
expr_stmt [33597,33686]
expr_stmt [33615,33704]
===
match
---
number: 1 [40374,40375]
number: 1 [40392,40393]
===
match
---
expr_stmt [40882,40932]
expr_stmt [40900,40950]
===
match
---
dictorsetmaker [46915,46993]
dictorsetmaker [46933,47011]
===
match
---
operator: = [19742,19743]
operator: = [19760,19761]
===
match
---
argument [48259,48265]
argument [48277,48283]
===
match
---
atom_expr [4674,4706]
atom_expr [4674,4706]
===
match
---
name: self [21717,21721]
name: self [21735,21739]
===
match
---
name: mock_get_credentials [15909,15929]
name: mock_get_credentials [15927,15947]
===
match
---
operator: } [49365,49366]
operator: } [49383,49384]
===
match
---
simple_stmt [16428,16480]
simple_stmt [16446,16498]
===
match
---
atom_expr [47796,47840]
atom_expr [47814,47858]
===
match
---
decorated [6794,8160]
decorated [6794,8166]
===
match
---
argument [44100,44120]
argument [44118,44138]
===
match
---
string: "token" [47928,47935]
string: "token" [47946,47953]
===
match
---
string: 'secret' [40536,40544]
string: 'secret' [40554,40562]
===
match
---
name: mock_hvac [14780,14789]
name: mock_hvac [14798,14807]
===
match
---
name: azure [14870,14875]
name: azure [14888,14893]
===
match
---
name: mock [35436,35440]
name: mock [35454,35458]
===
match
---
name: gcp [16718,16721]
name: gcp [16736,16739]
===
match
---
funcdef [33216,34132]
funcdef [33234,34150]
===
match
---
name: get [34712,34715]
name: get [34730,34733]
===
match
---
argument [14953,14972]
argument [14971,14990]
===
match
---
name: tenant_id [13630,13639]
name: tenant_id [13648,13657]
===
match
---
operator: , [14419,14420]
operator: , [14437,14438]
===
match
---
name: return_value [17678,17690]
name: return_value [17696,17708]
===
match
---
simple_stmt [33025,33045]
simple_stmt [33043,33063]
===
match
---
operator: == [10388,10390]
operator: == [10406,10408]
===
match
---
dictorsetmaker [38561,38639]
dictorsetmaker [38579,38657]
===
match
---
name: extra_dejson [20951,20963]
name: extra_dejson [20969,20981]
===
match
---
operator: = [31321,31322]
operator: = [31339,31340]
===
match
---
dictorsetmaker [23178,23294]
dictorsetmaker [23196,23312]
===
match
---
name: mock_client [29014,29025]
name: mock_client [29032,29043]
===
match
---
name: assert_called_with [22357,22375]
name: assert_called_with [22375,22393]
===
match
---
name: mock_hvac [48623,48632]
name: mock_hvac [48641,48650]
===
match
---
simple_stmt [21268,21333]
simple_stmt [21286,21351]
===
match
---
operator: ** [21143,21145]
operator: ** [21161,21163]
===
match
---
string: 'created_time' [42838,42852]
string: 'created_time' [42856,42870]
===
match
---
string: 'warnings' [38413,38423]
string: 'warnings' [38431,38441]
===
match
---
string: 'http://localhost:8180' [13532,13555]
string: 'http://localhost:8180' [13550,13573]
===
match
---
string: 'version' [46033,46042]
string: 'version' [46051,46060]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [5229,5293]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [5229,5293]
===
match
---
atom_expr [14482,14526]
atom_expr [14500,14544]
===
match
---
operator: = [36106,36107]
operator: = [36124,36125]
===
match
---
expr_stmt [36533,36576]
expr_stmt [36551,36594]
===
match
---
trailer [20834,20836]
trailer [20852,20854]
===
match
---
name: test_client [21412,21423]
name: test_client [21430,21441]
===
match
---
name: mock_get_connection [29441,29460]
name: mock_get_connection [29459,29478]
===
match
---
trailer [17412,17422]
trailer [17430,17440]
===
match
---
trailer [2985,2998]
trailer [2985,2998]
===
match
---
name: mock [46348,46352]
name: mock [46366,46370]
===
match
---
suite [8398,9312]
suite [8404,9324]
===
match
---
trailer [18059,18069]
trailer [18077,18087]
===
match
---
operator: = [37771,37772]
operator: = [37789,37790]
===
match
---
operator: , [38122,38123]
operator: , [38140,38141]
===
match
---
operator: } [32781,32782]
operator: } [32799,32800]
===
match
---
operator: @ [41853,41854]
operator: @ [41871,41872]
===
match
---
dictorsetmaker [16112,16261]
dictorsetmaker [16130,16279]
===
match
---
trailer [28158,28170]
trailer [28176,28188]
===
match
---
string: '' [38258,38260]
string: '' [38276,38278]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [4368,4432]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [4368,4432]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [2769,2833]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [2769,2833]
===
match
---
simple_stmt [35731,35824]
simple_stmt [35749,35842]
===
match
---
trailer [14497,14510]
trailer [14515,14528]
===
match
---
name: auth_aws_iam [11316,11328]
name: auth_aws_iam [11334,11346]
===
match
---
name: self [4639,4643]
name: self [4639,4643]
===
match
---
simple_stmt [1477,1538]
simple_stmt [1477,1538]
===
match
---
atom [47267,47283]
atom [47285,47301]
===
match
---
expr_stmt [12337,12371]
expr_stmt [12355,12389]
===
match
---
name: mock_client [44016,44027]
name: mock_client [44034,44045]
===
match
---
funcdef [5299,5984]
funcdef [5299,5984]
===
match
---
simple_stmt [42151,42202]
simple_stmt [42169,42220]
===
match
---
operator: , [6896,6897]
operator: , [6896,6897]
===
match
---
name: test_client [36053,36064]
name: test_client [36071,36082]
===
match
---
name: patch [41859,41864]
name: patch [41877,41882]
===
match
---
atom_expr [31901,31965]
atom_expr [31919,31983]
===
match
---
argument [40359,40375]
argument [40377,40393]
===
match
---
simple_stmt [23155,23305]
simple_stmt [23173,23323]
===
match
---
atom_expr [22205,22224]
atom_expr [22223,22242]
===
match
---
name: mock_client [48847,48858]
name: mock_client [48865,48876]
===
match
---
name: Client [21813,21819]
name: Client [21831,21837]
===
match
---
atom_expr [25752,25771]
atom_expr [25770,25789]
===
match
---
name: mock_get_connection [35392,35411]
name: mock_get_connection [35410,35429]
===
match
---
operator: @ [33050,33051]
operator: @ [33068,33069]
===
match
---
argument [28561,28576]
argument [28579,28594]
===
match
---
expr_stmt [31678,31744]
expr_stmt [31696,31762]
===
match
---
simple_stmt [36053,36132]
simple_stmt [36071,36150]
===
match
---
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [44164,44230]
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [44182,44248]
===
match
---
atom_expr [8446,8475]
atom_expr [8452,8481]
===
match
---
name: MagicMock [2051,2060]
name: MagicMock [2051,2060]
===
match
---
decorators [12600,12762]
decorators [12618,12780]
===
match
---
name: Client [22895,22901]
name: Client [22913,22919]
===
match
---
arglist [24689,24733]
arglist [24707,24751]
===
match
---
string: 'deletion_time' [43857,43872]
string: 'deletion_time' [43875,43890]
===
match
---
name: get_mock_connection [6344,6363]
name: get_mock_connection [6344,6363]
===
match
---
string: "missing" [40348,40357]
string: "missing" [40366,40375]
===
match
---
assert_stmt [3407,3474]
assert_stmt [3407,3474]
===
match
---
atom_expr [33399,33425]
atom_expr [33417,33443]
===
match
---
decorated [5133,5984]
decorated [5133,5984]
===
match
---
atom_expr [29087,29119]
atom_expr [29105,29137]
===
match
---
trailer [14167,14174]
trailer [14185,14192]
===
match
---
simple_stmt [33916,33966]
simple_stmt [33934,33984]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [29936,30000]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [29954,30018]
===
match
---
trailer [17677,17690]
trailer [17695,17708]
===
match
---
string: "vault_conn_id" [5771,5786]
string: "vault_conn_id" [5771,5786]
===
match
---
atom [5757,5814]
atom [5757,5814]
===
match
---
simple_stmt [29505,29540]
simple_stmt [29523,29558]
===
match
---
string: '94011e25-f8dc-ec29-221b-1f9c1d9ad2ae' [37913,37951]
string: '94011e25-f8dc-ec29-221b-1f9c1d9ad2ae' [37931,37969]
===
match
---
simple_stmt [28277,28309]
simple_stmt [28295,28327]
===
match
---
trailer [34711,34715]
trailer [34729,34733]
===
match
---
name: v2 [38830,38832]
name: v2 [38848,38850]
===
match
---
string: "radius_port" [31561,31574]
string: "radius_port" [31579,31592]
===
match
---
name: mock_connection [22937,22952]
name: mock_connection [22955,22970]
===
match
---
operator: = [2363,2364]
operator: = [2363,2364]
===
match
---
string: "path" [48056,48062]
string: "path" [48074,48080]
===
match
---
funcdef [34303,35174]
funcdef [34321,35192]
===
match
---
name: kwargs [40167,40173]
name: kwargs [40185,40191]
===
match
---
atom_expr [33522,33566]
atom_expr [33540,33584]
===
match
---
atom_expr [47580,47606]
atom_expr [47598,47624]
===
match
---
string: "auth_type" [19526,19537]
string: "auth_type" [19544,19555]
===
match
---
operator: = [15753,15754]
operator: = [15771,15772]
===
match
---
decorator [10437,10517]
decorator [10455,10535]
===
match
---
name: mock_client [39440,39451]
name: mock_client [39458,39469]
===
match
---
simple_stmt [19660,19727]
simple_stmt [19678,19745]
===
match
---
string: 'lease_id' [39581,39591]
string: 'lease_id' [39599,39609]
===
match
---
expr_stmt [30086,30116]
expr_stmt [30104,30134]
===
match
---
operator: = [24771,24772]
operator: = [24789,24790]
===
match
---
number: 2 [20409,20410]
number: 2 [20427,20428]
===
match
---
operator: = [7486,7487]
operator: = [7486,7487]
===
match
---
operator: , [39660,39661]
operator: , [39678,39679]
===
match
---
name: side_effect [3250,3261]
name: side_effect [3250,3261]
===
match
---
simple_stmt [46830,46897]
simple_stmt [46848,46915]
===
match
---
operator: @ [4356,4357]
operator: @ [4356,4357]
===
match
---
name: test_hook [19865,19874]
name: test_hook [19883,19892]
===
match
---
name: mock_get_connection [27231,27250]
name: mock_get_connection [27249,27268]
===
match
---
name: mock_client [24230,24241]
name: mock_client [24248,24259]
===
match
---
param [48598,48605]
param [48616,48623]
===
match
---
atom [48352,48368]
atom [48370,48386]
===
match
---
atom_expr [15755,15781]
atom_expr [15773,15799]
===
match
---
name: mock_get_connection [24848,24867]
name: mock_get_connection [24866,24885]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [25327,25391]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [25345,25409]
===
match
---
expr_stmt [5530,5580]
expr_stmt [5530,5580]
===
match
---
name: kv_engine_version [6771,6788]
name: kv_engine_version [6771,6788]
===
match
---
name: mock [4273,4277]
name: mock [4273,4277]
===
match
---
simple_stmt [20236,20336]
simple_stmt [20254,20354]
===
match
---
simple_stmt [12931,12976]
simple_stmt [12949,12994]
===
match
---
name: mock [44533,44537]
name: mock [44551,44555]
===
match
---
operator: @ [3480,3481]
operator: @ [3480,3481]
===
match
---
trailer [33963,33965]
trailer [33981,33983]
===
match
---
trailer [29479,29496]
trailer [29497,29514]
===
match
---
name: mock [22601,22605]
name: mock [22619,22623]
===
match
---
trailer [28543,28577]
trailer [28561,28595]
===
match
---
name: test_client [37145,37156]
name: test_client [37163,37174]
===
match
---
trailer [12114,12126]
trailer [12132,12144]
===
match
---
operator: , [22803,22804]
operator: , [22821,22822]
===
match
---
operator: , [37979,37980]
operator: , [37997,37998]
===
match
---
name: path [44122,44126]
name: path [44140,44144]
===
match
---
name: side_effect [41462,41473]
name: side_effect [41480,41491]
===
match
---
trailer [21277,21284]
trailer [21295,21302]
===
match
---
operator: = [1217,1218]
operator: = [1217,1218]
===
match
---
name: vault_client [25195,25207]
name: vault_client [25213,25225]
===
match
---
trailer [30114,30116]
trailer [30132,30134]
===
match
---
operator: = [12164,12165]
operator: = [12182,12183]
===
match
---
operator: , [30879,30880]
operator: , [30897,30898]
===
match
---
string: 'key' [20100,20105]
string: 'key' [20118,20123]
===
match
---
name: assert_called_with [18201,18219]
name: assert_called_with [18219,18237]
===
match
---
decorators [16925,17284]
decorators [16943,17302]
===
match
---
trailer [37835,37843]
trailer [37853,37861]
===
match
---
operator: { [19744,19745]
operator: { [19762,19763]
===
match
---
dictorsetmaker [34608,34629]
dictorsetmaker [34626,34647]
===
match
---
operator: @ [26618,26619]
operator: @ [26636,26637]
===
match
---
name: extra_dejson [3233,3245]
name: extra_dejson [3233,3245]
===
match
---
name: mock [8421,8425]
name: mock [8427,8431]
===
match
---
simple_stmt [16867,16920]
simple_stmt [16885,16938]
===
match
---
name: mock_connection [33469,33484]
name: mock_connection [33487,33502]
===
match
---
operator: { [44702,44703]
operator: { [44720,44721]
===
match
---
atom_expr [18050,18069]
atom_expr [18068,18087]
===
match
---
argument [26398,26408]
argument [26416,26426]
===
match
---
name: Client [20750,20756]
name: Client [20768,20774]
===
match
---
name: connection_dict [32644,32659]
name: connection_dict [32662,32677]
===
match
---
trailer [29460,29479]
trailer [29478,29497]
===
match
---
string: 'lease_duration' [45736,45752]
string: 'lease_duration' [45754,45770]
===
match
---
operator: = [43276,43277]
operator: = [43294,43295]
===
match
---
expr_stmt [5673,5739]
expr_stmt [5673,5739]
===
match
---
simple_stmt [43053,43120]
simple_stmt [43071,43138]
===
match
---
trailer [26018,26036]
trailer [26036,26054]
===
match
---
name: mock_client [44519,44530]
name: mock_client [44537,44548]
===
match
---
trailer [21370,21389]
trailer [21388,21407]
===
match
---
atom_expr [27570,27610]
atom_expr [27588,27628]
===
match
---
string: "kv_engine_version" [45434,45453]
string: "kv_engine_version" [45452,45471]
===
match
---
atom_expr [46198,46341]
atom_expr [46216,46359]
===
match
---
trailer [17949,17953]
trailer [17967,17971]
===
match
---
dictorsetmaker [38759,38787]
dictorsetmaker [38777,38805]
===
match
---
simple_stmt [4530,4561]
simple_stmt [4530,4561]
===
match
---
trailer [19319,19332]
trailer [19337,19350]
===
match
---
expr_stmt [47004,47035]
expr_stmt [47022,47053]
===
match
---
string: "credentials" [16776,16789]
string: "credentials" [16794,16807]
===
match
---
name: kwargs [6720,6726]
name: kwargs [6720,6726]
===
match
---
operator: , [1229,1230]
operator: , [1229,1230]
===
match
---
name: connection_dict [13044,13059]
name: connection_dict [13062,13077]
===
match
---
name: assert_called_with [26171,26189]
name: assert_called_with [26189,26207]
===
match
---
name: mount_point [4255,4266]
name: mount_point [4255,4266]
===
match
---
operator: = [16667,16668]
operator: = [16685,16686]
===
match
---
string: 'secret' [44112,44120]
string: 'secret' [44130,44138]
===
match
---
argument [34983,35010]
argument [35001,35028]
===
match
---
operator: , [2887,2888]
operator: , [2887,2888]
===
match
---
arglist [32962,33010]
arglist [32980,33028]
===
match
---
string: 'request_id' [42408,42420]
string: 'request_id' [42426,42438]
===
match
---
dotted_name [18964,18974]
dotted_name [18982,18992]
===
match
---
name: patch [29846,29851]
name: patch [29864,29869]
===
match
---
parameters [9506,9544]
parameters [9518,9556]
===
match
---
name: self [19265,19269]
name: self [19283,19287]
===
match
---
operator: , [48368,48369]
operator: , [48386,48387]
===
match
---
name: test_client [24805,24816]
name: test_client [24823,24834]
===
match
---
trailer [40154,40158]
trailer [40172,40176]
===
match
---
name: kv [42352,42354]
name: kv [42370,42372]
===
match
---
trailer [39373,39386]
trailer [39391,39404]
===
match
---
string: 'request_id' [41130,41142]
string: 'request_id' [41148,41160]
===
match
---
expr_stmt [15849,15900]
expr_stmt [15867,15918]
===
match
---
trailer [24551,24555]
trailer [24569,24573]
===
match
---
simple_stmt [39410,39431]
simple_stmt [39428,39449]
===
match
---
string: 'deletion_time' [42686,42701]
string: 'deletion_time' [42704,42719]
===
match
---
operator: , [19469,19470]
operator: , [19487,19488]
===
match
---
expr_stmt [21908,21958]
expr_stmt [21926,21976]
===
match
---
arglist [16764,16790]
arglist [16782,16808]
===
match
---
name: mock_connection [8586,8601]
name: mock_connection [8592,8607]
===
match
---
operator: { [33606,33607]
operator: { [33624,33625]
===
match
---
operator: = [27201,27202]
operator: = [27219,27220]
===
match
---
name: VaultHook [43239,43248]
name: VaultHook [43257,43266]
===
match
---
name: get [7563,7566]
name: get [7563,7566]
===
match
---
operator: , [45117,45118]
operator: , [45135,45136]
===
match
---
name: Client [44568,44574]
name: Client [44586,44592]
===
match
---
number: 2 [30965,30966]
number: 2 [30983,30984]
===
match
---
name: get_conn [22321,22329]
name: get_conn [22339,22347]
===
match
---
name: kwargs [36949,36955]
name: kwargs [36967,36973]
===
match
---
name: assert_called_with [21441,21459]
name: assert_called_with [21459,21477]
===
match
---
name: test_hook [30695,30704]
name: test_hook [30713,30722]
===
match
---
simple_stmt [25510,25554]
simple_stmt [25528,25572]
===
match
---
atom_expr [29441,29496]
atom_expr [29459,29514]
===
match
---
trailer [27868,27878]
trailer [27886,27896]
===
match
---
name: is_authenticated [15068,15084]
name: is_authenticated [15086,15102]
===
match
---
expr_stmt [5823,5854]
expr_stmt [5823,5854]
===
match
---
name: mock_get_scopes [18185,18200]
name: mock_get_scopes [18203,18218]
===
match
---
funcdef [20626,21523]
funcdef [20644,21541]
===
match
---
simple_stmt [44611,44632]
simple_stmt [44629,44650]
===
match
---
trailer [26269,26276]
trailer [26287,26294]
===
match
---
string: "vault_conn_id" [6661,6676]
string: "vault_conn_id" [6661,6676]
===
match
---
trailer [12311,12328]
trailer [12329,12346]
===
match
---
operator: , [24127,24128]
operator: , [24145,24146]
===
match
---
suite [33012,33045]
suite [33030,33063]
===
match
---
trailer [21812,21819]
trailer [21830,21837]
===
match
---
operator: { [44629,44630]
operator: { [44647,44648]
===
match
---
atom [45863,46064]
atom [45881,46082]
===
match
---
atom_expr [26215,26251]
atom_expr [26233,26269]
===
match
---
expr_stmt [35626,35646]
expr_stmt [35644,35664]
===
match
---
atom_expr [11231,11295]
atom_expr [11249,11313]
===
match
---
operator: { [45803,45804]
operator: { [45821,45822]
===
match
---
string: "user" [36107,36113]
string: "user" [36125,36131]
===
match
---
operator: = [25691,25692]
operator: = [25709,25710]
===
match
---
string: 'missing' [38917,38926]
string: 'missing' [38935,38944]
===
match
---
name: mock [22860,22864]
name: mock [22878,22882]
===
match
---
operator: , [46064,46065]
operator: , [46082,46083]
===
match
---
atom [6825,6982]
atom [6825,6982]
===
match
---
trailer [32169,32187]
trailer [32187,32205]
===
match
---
decorator [48474,48552]
decorator [48492,48570]
===
match
---
operator: = [21395,21396]
operator: = [21413,21414]
===
match
---
operator: , [44861,44862]
operator: , [44879,44880]
===
match
---
string: "localhost" [1218,1229]
string: "localhost" [1218,1229]
===
match
---
dictorsetmaker [40393,40421]
dictorsetmaker [40411,40439]
===
match
---
suite [30077,31011]
suite [30095,31029]
===
match
---
name: test_client [18566,18577]
name: test_client [18584,18595]
===
match
---
string: 'auth' [45260,45266]
string: 'auth' [45278,45284]
===
match
---
name: kwargs [7575,7581]
name: kwargs [7575,7581]
===
match
---
arglist [2487,2538]
arglist [2487,2538]
===
match
---
trailer [43307,43330]
trailer [43325,43348]
===
match
---
param [48634,48653]
param [48652,48671]
===
match
---
atom_expr [21268,21332]
atom_expr [21286,21350]
===
match
---
trailer [23890,23908]
trailer [23908,23926]
===
match
---
dotted_name [3565,3575]
dotted_name [3565,3575]
===
match
---
name: url [7937,7940]
name: url [7937,7940]
===
match
---
string: 'http://localhost:8180' [10202,10225]
string: 'http://localhost:8180' [10214,10237]
===
match
---
name: mock [8166,8170]
name: mock [8172,8176]
===
match
---
name: Client [18395,18401]
name: Client [18413,18419]
===
match
---
name: mock_connection [39206,39221]
name: mock_connection [39224,39239]
===
match
---
string: 'request_id' [39515,39527]
string: 'request_id' [39533,39545]
===
match
---
atom_expr [16879,16919]
atom_expr [16897,16937]
===
match
---
name: v1 [41086,41088]
name: v1 [41104,41106]
===
match
---
name: mock_connection [32619,32634]
name: mock_connection [32637,32652]
===
match
---
string: "role" [12577,12583]
string: "role" [12595,12601]
===
match
---
operator: = [41650,41651]
operator: = [41668,41669]
===
match
---
name: test_hook [26488,26497]
name: test_hook [26506,26515]
===
match
---
expr_stmt [31603,31669]
expr_stmt [31621,31687]
===
match
---
trailer [12389,12396]
trailer [12407,12414]
===
match
---
atom [34594,34639]
atom [34612,34657]
===
match
---
name: mock_get_credentials [17346,17366]
name: mock_get_credentials [17364,17384]
===
match
---
atom_expr [21341,21403]
atom_expr [21359,21421]
===
match
---
name: test_client [31974,31985]
name: test_client [31992,32003]
===
match
---
operator: = [11819,11820]
operator: = [11837,11838]
===
match
---
string: "user" [27467,27473]
string: "user" [27485,27491]
===
match
---
trailer [10707,10709]
trailer [10725,10727]
===
match
---
trailer [40287,40297]
trailer [40305,40315]
===
match
---
operator: , [44768,44769]
operator: , [44786,44787]
===
match
---
name: mock_client [42332,42343]
name: mock_client [42350,42361]
===
match
---
parameters [11759,11797]
parameters [11777,11815]
===
match
---
name: MagicMock [17413,17422]
name: MagicMock [17431,17440]
===
match
---
string: "Radius port was wrong: wrong" [32980,33010]
string: "Radius port was wrong: wrong" [32998,33028]
===
match
---
name: test_hook [23868,23877]
name: test_hook [23886,23895]
===
match
---
dictorsetmaker [25803,25962]
dictorsetmaker [25821,25980]
===
match
---
simple_stmt [21121,21153]
simple_stmt [21139,21171]
===
match
---
expr_stmt [35461,35504]
expr_stmt [35479,35522]
===
match
---
trailer [41661,41672]
trailer [41679,41690]
===
match
---
trailer [28597,28614]
trailer [28615,28632]
===
match
---
string: 'secret_key' [39709,39721]
string: 'secret_key' [39727,39739]
===
match
---
operator: == [5085,5087]
operator: == [5085,5087]
===
match
---
name: mock [31266,31270]
name: mock [31284,31288]
===
match
---
string: '2020-03-16T21:01:43.331126Z' [43806,43835]
string: '2020-03-16T21:01:43.331126Z' [43824,43853]
===
match
---
operator: = [11984,11985]
operator: = [12002,12003]
===
match
---
string: 'metadata' [45851,45861]
string: 'metadata' [45869,45879]
===
match
---
string: "path" [24462,24468]
string: "path" [24480,24486]
===
match
---
string: "vault_conn_id" [34764,34779]
string: "vault_conn_id" [34782,34797]
===
match
---
name: test_token_dejson [34307,34324]
name: test_token_dejson [34325,34342]
===
match
---
simple_stmt [48776,48807]
simple_stmt [48794,48825]
===
match
---
name: Client [34421,34427]
name: Client [34439,34445]
===
match
---
name: Client [13502,13508]
name: Client [13520,13526]
===
match
---
expr_stmt [7575,7744]
expr_stmt [7575,7744]
===
match
---
name: PropertyMock [1437,1449]
name: PropertyMock [1437,1449]
===
match
---
string: "vault_conn_id" [13172,13187]
string: "vault_conn_id" [13190,13205]
===
match
---
atom_expr [44533,44549]
atom_expr [44551,44567]
===
match
---
operator: = [41474,41475]
operator: = [41492,41493]
===
match
---
expr_stmt [9698,9748]
expr_stmt [9710,9760]
===
match
---
operator: , [43969,43970]
operator: , [43987,43988]
===
match
---
operator: @ [47393,47394]
operator: @ [47411,47412]
===
match
---
trailer [10178,10197]
trailer [10190,10209]
===
match
---
trailer [37662,37675]
trailer [37680,37693]
===
match
---
param [47515,47520]
param [47533,47538]
===
match
---
name: return_value [42266,42278]
name: return_value [42284,42296]
===
match
---
assert_stmt [13826,13878]
assert_stmt [13844,13896]
===
match
---
trailer [28188,28192]
trailer [28206,28210]
===
match
---
string: "/var/run/secrets/kubernetes.io/serviceaccount/token" [23577,23630]
string: "/var/run/secrets/kubernetes.io/serviceaccount/token" [23595,23648]
===
match
---
atom_expr [27007,27051]
atom_expr [27025,27069]
===
match
---
operator: ** [40288,40290]
operator: ** [40306,40308]
===
match
---
atom_expr [23713,23789]
atom_expr [23731,23807]
===
match
---
name: staticmethod [1127,1139]
name: staticmethod [1127,1139]
===
match
---
param [36453,36463]
param [36471,36481]
===
match
---
operator: == [4229,4231]
operator: == [4229,4231]
===
match
---
name: role [23760,23764]
name: role [23778,23782]
===
match
---
name: connection_dict [36821,36836]
name: connection_dict [36839,36854]
===
match
---
simple_stmt [12082,12149]
simple_stmt [12100,12167]
===
match
---
operator: == [23865,23867]
operator: == [23883,23885]
===
match
---
name: connection_dict [2365,2380]
name: connection_dict [2365,2380]
===
match
---
operator: } [27180,27181]
operator: } [27198,27199]
===
match
---
name: connection_dict [24536,24551]
name: connection_dict [24554,24569]
===
match
---
trailer [34390,34400]
trailer [34408,34418]
===
match
---
string: "project_id" [15961,15973]
string: "project_id" [15979,15991]
===
match
---
expr_stmt [47871,47960]
expr_stmt [47889,47978]
===
match
---
operator: , [41546,41547]
operator: , [41564,41565]
===
match
---
name: side_effect [5706,5717]
name: side_effect [5706,5717]
===
match
---
name: scopes [16582,16588]
name: scopes [16600,16606]
===
match
---
trailer [47025,47035]
trailer [47043,47053]
===
match
---
string: '' [42703,42705]
string: '' [42721,42723]
===
match
---
name: get [34678,34681]
name: get [34696,34699]
===
match
---
simple_stmt [10055,10111]
simple_stmt [10067,10123]
===
match
---
simple_stmt [37029,37064]
simple_stmt [37047,37082]
===
match
---
simple_stmt [875,932]
simple_stmt [875,932]
===
match
---
simple_stmt [35121,35174]
simple_stmt [35139,35192]
===
match
---
string: "pass" [28570,28576]
string: "pass" [28588,28594]
===
match
---
name: mock [18772,18776]
name: mock [18790,18794]
===
match
---
funcdef [44318,46342]
funcdef [44336,46360]
===
match
---
name: Client [24967,24973]
name: Client [24985,24991]
===
match
---
name: test_hook [9271,9280]
name: test_hook [9283,9292]
===
match
---
operator: = [18306,18307]
operator: = [18324,18325]
===
match
---
operator: , [14939,14940]
operator: , [14957,14958]
===
match
---
name: vault_client [9281,9293]
name: vault_client [9293,9305]
===
match
---
atom_expr [34947,35011]
atom_expr [34965,35029]
===
match
---
decorator [13884,13964]
decorator [13902,13982]
===
match
---
trailer [35477,35490]
trailer [35495,35508]
===
match
---
trailer [5414,5416]
trailer [5414,5416]
===
match
---
simple_stmt [47970,48002]
simple_stmt [47988,48020]
===
match
---
argument [10295,10311]
argument [10313,10329]
===
match
---
name: test_hook [5088,5097]
name: test_hook [5088,5097]
===
match
---
name: patch [33140,33145]
name: patch [33158,33163]
===
match
---
dictorsetmaker [49351,49365]
dictorsetmaker [49369,49383]
===
match
---
number: 0 [42552,42553]
number: 0 [42570,42571]
===
match
---
trailer [41624,41634]
trailer [41642,41652]
===
match
---
parameters [42050,42088]
parameters [42068,42106]
===
match
---
name: connection_dict [6434,6449]
name: connection_dict [6434,6449]
===
match
---
operator: } [33685,33686]
operator: } [33703,33704]
===
match
---
name: self [1985,1989]
name: self [1985,1989]
===
match
---
name: kwargs [27215,27221]
name: kwargs [27233,27239]
===
match
---
expr_stmt [46708,46738]
expr_stmt [46726,46756]
===
match
---
atom_expr [4569,4598]
atom_expr [4569,4598]
===
match
---
name: test_hook [34800,34809]
name: test_hook [34818,34827]
===
match
---
trailer [6258,6260]
trailer [6258,6260]
===
match
---
simple_stmt [18624,18677]
simple_stmt [18642,18695]
===
match
---
simple_stmt [40306,40377]
simple_stmt [40324,40395]
===
match
---
decorators [23914,24076]
decorators [23932,24094]
===
match
---
name: get [45356,45359]
name: get [45374,45377]
===
match
---
name: auth [30809,30813]
name: auth [30827,30831]
===
match
---
trailer [47153,47156]
trailer [47171,47174]
===
match
---
string: "vault_conn_id" [35912,35927]
string: "vault_conn_id" [35930,35945]
===
match
---
name: mock_client [26773,26784]
name: mock_client [26791,26802]
===
match
---
name: assert_called_with [36079,36097]
name: assert_called_with [36097,36115]
===
match
---
suite [17385,18677]
suite [17403,18695]
===
match
---
expr_stmt [19247,19291]
expr_stmt [19265,19309]
===
match
---
operator: , [38615,38616]
operator: , [38633,38634]
===
match
---
name: auth [28509,28513]
name: auth [28527,28531]
===
match
---
name: assert_called_with [18402,18420]
name: assert_called_with [18420,18438]
===
match
---
trailer [10278,10312]
trailer [10296,10330]
===
match
---
name: mock_hvac [1991,2000]
name: mock_hvac [1991,2000]
===
match
---
name: mock_get_credentials [16488,16508]
name: mock_get_credentials [16506,16526]
===
match
---
name: self [14072,14076]
name: self [14090,14094]
===
match
---
dotted_name [44153,44163]
dotted_name [44171,44181]
===
match
---
argument [24783,24791]
argument [24801,24809]
===
match
---
name: test_hook [8895,8904]
name: test_hook [8901,8910]
===
match
---
trailer [25519,25526]
trailer [25537,25544]
===
match
---
operator: = [16096,16097]
operator: = [16114,16115]
===
match
---
name: assert_called_once_with [40487,40510]
name: assert_called_once_with [40505,40528]
===
match
---
trailer [34936,34938]
trailer [34954,34956]
===
match
---
string: 'value' [41304,41311]
string: 'value' [41322,41329]
===
match
---
trailer [27592,27610]
trailer [27610,27628]
===
match
---
simple_stmt [40829,40874]
simple_stmt [40847,40892]
===
match
---
operator: = [47288,47289]
operator: = [47306,47307]
===
match
---
name: MagicMock [22865,22874]
name: MagicMock [22883,22892]
===
match
---
atom_expr [13385,13440]
atom_expr [13403,13458]
===
match
---
operator: } [31592,31593]
operator: } [31610,31611]
===
match
---
trailer [6248,6258]
trailer [6248,6258]
===
match
---
operator: , [14087,14088]
operator: , [14105,14106]
===
match
---
operator: , [30054,30055]
operator: , [30072,30073]
===
match
---
atom_expr [24773,24792]
atom_expr [24791,24810]
===
match
---
atom_expr [36053,36131]
atom_expr [36071,36149]
===
match
---
operator: = [38697,38698]
operator: = [38715,38716]
===
match
---
string: "airflow.providers.google.cloud.utils.credentials_provider.get_credentials_and_project_id" [15273,15363]
string: "airflow.providers.google.cloud.utils.credentials_provider.get_credentials_and_project_id" [15291,15381]
===
match
---
operator: , [28256,28257]
operator: , [28274,28275]
===
match
---
atom_expr [20982,21001]
atom_expr [21000,21019]
===
match
---
trailer [33550,33554]
trailer [33568,33572]
===
match
---
name: secret_path [47078,47089]
name: secret_path [47096,47107]
===
match
---
operator: ** [4195,4197]
operator: ** [4195,4197]
===
match
---
import_from [986,1025]
import_from [986,1025]
===
match
---
decorated [16925,18677]
decorated [16943,18695]
===
match
---
trailer [42378,42391]
trailer [42396,42409]
===
match
---
string: "gcp_scopes" [19610,19622]
string: "gcp_scopes" [19628,19640]
===
match
---
string: "vault_conn_id" [47881,47896]
string: "vault_conn_id" [47899,47914]
===
match
---
name: mock_client [40441,40452]
name: mock_client [40459,40470]
===
match
---
atom [13158,13335]
atom [13176,13353]
===
match
---
name: test_hook [5823,5832]
name: test_hook [5823,5832]
===
match
---
name: mock [1795,1799]
name: mock [1795,1799]
===
match
---
name: Client [14168,14174]
name: Client [14186,14192]
===
match
---
suite [2540,2573]
suite [2540,2573]
===
match
---
atom_expr [47688,47704]
atom_expr [47706,47722]
===
match
---
trailer [32573,32575]
trailer [32591,32593]
===
match
---
operator: , [41830,41831]
operator: , [41848,41849]
===
match
---
trailer [11855,11862]
trailer [11873,11880]
===
match
---
trailer [25634,25647]
trailer [25652,25665]
===
match
---
operator: , [4927,4928]
operator: , [4927,4928]
===
match
---
trailer [49263,49287]
trailer [49281,49305]
===
match
---
decorator [5133,5213]
decorator [5133,5213]
===
match
---
trailer [21877,21897]
trailer [21895,21915]
===
match
---
trailer [5499,5519]
trailer [5499,5519]
===
match
---
param [22799,22804]
param [22817,22822]
===
match
---
trailer [40120,40124]
trailer [40138,40142]
===
match
---
trailer [30740,30759]
trailer [30758,30777]
===
match
---
trailer [28665,28678]
trailer [28683,28696]
===
match
---
trailer [4055,4067]
trailer [4055,4067]
===
match
---
number: 2 [22549,22550]
number: 2 [22567,22568]
===
match
---
operator: , [29703,29704]
operator: , [29721,29722]
===
match
---
argument [49094,49102]
argument [49112,49120]
===
match
---
param [3698,3717]
param [3698,3717]
===
match
---
argument [40524,40544]
argument [40542,40562]
===
match
---
trailer [25604,25606]
trailer [25622,25624]
===
match
---
decorated [3480,4267]
decorated [3480,4267]
===
match
---
operator: , [19128,19129]
operator: , [19146,19147]
===
match
---
operator: = [40915,40916]
operator: = [40933,40934]
===
match
---
operator: @ [1794,1795]
operator: @ [1794,1795]
===
match
---
name: token [22462,22467]
name: token [22480,22485]
===
match
---
dictorsetmaker [3153,3206]
dictorsetmaker [3153,3206]
===
match
---
trailer [17442,17449]
trailer [17460,17467]
===
match
---
trailer [9667,9687]
trailer [9679,9699]
===
match
---
name: mock_hvac [31291,31300]
name: mock_hvac [31309,31318]
===
match
---
trailer [20814,20834]
trailer [20832,20852]
===
match
---
name: conn_type [1177,1186]
name: conn_type [1177,1186]
===
match
---
atom [43549,43750]
atom [43567,43768]
===
match
---
name: MagicMock [20720,20729]
name: MagicMock [20738,20747]
===
match
---
name: get_mock_connection [30200,30219]
name: get_mock_connection [30218,30237]
===
match
---
trailer [12496,12594]
trailer [12514,12612]
===
match
---
operator: = [25081,25082]
operator: = [25099,25100]
===
match
---
string: "vault_conn_id" [41514,41529]
string: "vault_conn_id" [41532,41547]
===
match
---
operator: , [2278,2279]
operator: , [2278,2279]
===
match
---
name: VaultHook [4979,4988]
name: VaultHook [4979,4988]
===
match
---
name: mock_connection [48898,48913]
name: mock_connection [48916,48931]
===
match
---
atom_expr [10788,10814]
atom_expr [10806,10832]
===
match
---
parameters [19069,19146]
parameters [19087,19164]
===
match
---
operator: = [8723,8724]
operator: = [8729,8730]
===
match
---
name: side_effect [28159,28170]
name: side_effect [28177,28188]
===
match
---
trailer [22442,22461]
trailer [22460,22479]
===
match
---
name: mock_hvac [35381,35390]
name: mock_hvac [35399,35408]
===
match
---
operator: ** [22215,22217]
operator: ** [22233,22235]
===
match
---
name: mock [2944,2948]
name: mock [2944,2948]
===
match
---
trailer [10246,10259]
trailer [10263,10271]
===
match
---
trailer [31910,31917]
trailer [31928,31935]
===
match
---
trailer [29673,29715]
trailer [29691,29733]
===
match
---
operator: , [34329,34330]
operator: , [34347,34348]
===
match
---
trailer [8077,8096]
trailer [8083,8102]
===
match
---
trailer [18265,18284]
trailer [18283,18302]
===
match
---
atom_expr [7963,8040]
atom_expr [7963,8046]
===
match
---
name: MagicMock [35441,35450]
name: MagicMock [35459,35468]
===
match
---
operator: , [42998,42999]
operator: , [43016,43017]
===
match
---
name: test_hook [31754,31763]
name: test_hook [31772,31781]
===
match
---
name: radius [30814,30820]
name: radius [30832,30838]
===
match
---
argument [33879,33906]
argument [33897,33924]
===
match
---
atom_expr [19660,19704]
atom_expr [19678,19722]
===
match
---
suite [1121,49401]
suite [1121,49419]
===
match
---
name: kv_engine_version [26511,26528]
name: kv_engine_version [26529,26546]
===
match
---
parameters [26725,26763]
parameters [26743,26781]
===
match
---
operator: = [45569,45570]
operator: = [45587,45588]
===
match
---
operator: } [48086,48087]
operator: } [48104,48105]
===
match
---
name: test_kubernetes_default_path [22770,22798]
name: test_kubernetes_default_path [22788,22816]
===
match
---
name: assert_called_with [13509,13527]
name: assert_called_with [13527,13545]
===
match
---
funcdef [32359,33045]
funcdef [32377,33063]
===
match
---
operator: = [30872,30873]
operator: = [30890,30891]
===
match
---
name: connection_dict [43100,43115]
name: connection_dict [43118,43133]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [26630,26694]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [26648,26712]
===
match
---
name: patch [47399,47404]
name: patch [47417,47422]
===
match
---
expr_stmt [24761,24792]
expr_stmt [24779,24810]
===
match
---
name: test_hook [8119,8128]
name: test_hook [8125,8134]
===
match
---
arglist [47218,47293]
arglist [47236,47311]
===
match
---
simple_stmt [8446,8490]
simple_stmt [8452,8496]
===
match
---
argument [16764,16789]
argument [16782,16807]
===
match
---
trailer [38818,38826]
trailer [38836,38844]
===
match
---
name: auth_mount_point [5967,5983]
name: auth_mount_point [5967,5983]
===
match
---
trailer [42343,42351]
trailer [42361,42369]
===
match
---
simple_stmt [17732,17878]
simple_stmt [17750,17896]
===
match
---
name: mock [31101,31105]
name: mock [31119,31123]
===
match
---
name: get [14511,14514]
name: get [14529,14532]
===
match
---
name: return_value [19320,19332]
name: return_value [19338,19350]
===
match
---
suite [37581,38951]
suite [37599,38969]
===
match
---
operator: } [44630,44631]
operator: } [44648,44649]
===
match
---
atom_expr [14158,14187]
atom_expr [14176,14205]
===
match
---
name: is_authenticated [20356,20372]
name: is_authenticated [20374,20390]
===
match
---
decorator [44236,44314]
decorator [44254,44332]
===
match
---
funcdef [24080,25226]
funcdef [24098,25244]
===
match
---
operator: = [47980,47981]
operator: = [47998,47999]
===
match
---
atom_expr [26122,26142]
atom_expr [26140,26160]
===
match
---
operator: { [28210,28211]
operator: { [28228,28229]
===
match
---
simple_stmt [44641,45284]
simple_stmt [44659,45302]
===
match
---
trailer [25991,26037]
trailer [26009,26055]
===
match
---
operator: = [2101,2102]
operator: = [2101,2102]
===
match
---
name: side_effect [36807,36818]
name: side_effect [36825,36836]
===
match
---
name: get [17916,17919]
name: get [17934,17937]
===
match
---
expr_stmt [26108,26142]
expr_stmt [26126,26160]
===
match
---
atom_expr [5495,5521]
atom_expr [5495,5521]
===
match
---
name: mock_hvac [44366,44375]
name: mock_hvac [44384,44393]
===
match
---
simple_stmt [10015,10047]
simple_stmt [10027,10059]
===
match
---
name: test_token_init_params [33220,33242]
name: test_token_init_params [33238,33260]
===
match
---
trailer [20864,20877]
trailer [20882,20895]
===
match
---
name: MagicMock [10698,10707]
name: MagicMock [10716,10725]
===
match
---
simple_stmt [15685,15729]
simple_stmt [15703,15747]
===
match
---
dictorsetmaker [45378,45456]
dictorsetmaker [45396,45474]
===
match
---
atom [44883,45185]
atom [44901,45203]
===
match
---
name: mock_get_connection [3698,3717]
name: mock_get_connection [3698,3717]
===
match
---
name: VaultHook [33025,33034]
name: VaultHook [33043,33052]
===
match
---
name: v2 [44664,44666]
name: v2 [44682,44684]
===
match
---
operator: @ [44236,44237]
operator: @ [44254,44255]
===
match
---
name: test_client [30797,30808]
name: test_client [30815,30826]
===
match
---
name: kwargs [11108,11114]
name: kwargs [11126,11132]
===
match
---
atom_expr [17657,17690]
atom_expr [17675,17708]
===
match
---
dictorsetmaker [10998,11073]
dictorsetmaker [11016,11091]
===
match
---
name: get_conn [27319,27327]
name: get_conn [27337,27345]
===
match
---
name: is_authenticated [36152,36168]
name: is_authenticated [36170,36186]
===
match
---
argument [43308,43329]
argument [43326,43347]
===
match
---
name: assert_called_with [37171,37189]
name: assert_called_with [37189,37207]
===
match
---
operator: == [26485,26487]
operator: == [26503,26505]
===
match
---
expr_stmt [24489,24555]
expr_stmt [24507,24573]
===
match
---
name: mock_connection [29034,29049]
name: mock_connection [29052,29067]
===
match
---
string: "pass" [35085,35091]
string: "pass" [35103,35109]
===
match
---
trailer [28298,28308]
trailer [28316,28326]
===
match
---
name: mock_file [24912,24921]
name: mock_file [24930,24939]
===
match
---
name: kwargs [8716,8722]
name: kwargs [8722,8728]
===
match
---
argument [10279,10293]
argument [10297,10311]
===
match
---
simple_stmt [9758,9855]
simple_stmt [9770,9867]
===
match
---
string: "path" [24941,24947]
string: "path" [24959,24965]
===
match
---
name: self [34325,34329]
name: self [34343,34347]
===
match
---
number: 2 [35128,35129]
number: 2 [35146,35147]
===
match
---
trailer [34982,35011]
trailer [35000,35029]
===
match
---
decorated [4272,5128]
decorated [4272,5128]
===
match
---
name: mock [44237,44241]
name: mock [44255,44259]
===
match
---
name: test_hook [38699,38708]
name: test_hook [38717,38726]
===
match
---
decorator [27700,27778]
decorator [27718,27796]
===
match
---
dotted_name [46348,46358]
dotted_name [46366,46376]
===
match
---
name: auth_mount_point [5111,5127]
name: auth_mount_point [5111,5127]
===
match
---
operator: , [42460,42461]
operator: , [42478,42479]
===
match
---
string: 'key' [47106,47111]
string: 'key' [47124,47129]
===
match
---
operator: @ [21612,21613]
operator: @ [21630,21631]
===
match
---
trailer [41809,41847]
trailer [41827,41865]
===
match
---
atom_expr [46877,46896]
atom_expr [46895,46914]
===
match
---
string: 'created_time' [39790,39804]
string: 'created_time' [39808,39822]
===
match
---
operator: , [42924,42925]
operator: , [42942,42943]
===
match
---
name: return_value [34536,34548]
name: return_value [34554,34566]
===
match
---
funcdef [12766,13879]
funcdef [12784,13897]
===
match
---
name: get_conn [34928,34936]
name: get_conn [34946,34954]
===
match
---
operator: ** [3389,3391]
operator: ** [3389,3391]
===
match
---
string: 'scope2' [19401,19409]
string: 'scope2' [19419,19427]
===
match
---
trailer [19913,19932]
trailer [19931,19950]
===
match
---
name: patch [3570,3575]
name: patch [3570,3575]
===
match
---
name: mock_get_connection [42068,42087]
name: mock_get_connection [42086,42105]
===
match
---
operator: } [28115,28116]
operator: } [28133,28134]
===
match
---
atom_expr [22233,22288]
atom_expr [22251,22306]
===
match
---
string: "radhost" [32726,32735]
string: "radhost" [32744,32753]
===
match
---
dotted_name [41854,41864]
dotted_name [41872,41882]
===
match
---
name: self [8360,8364]
name: self [8366,8370]
===
match
---
name: assert_called_with [33860,33878]
name: assert_called_with [33878,33896]
===
match
---
name: get_secret_including_metadata [45528,45557]
name: get_secret_including_metadata [45546,45575]
===
match
---
name: mock_client [20772,20783]
name: mock_client [20790,20801]
===
match
---
string: 'missing' [46308,46317]
string: 'missing' [46326,46335]
===
match
---
name: self [30039,30043]
name: self [30057,30061]
===
match
---
simple_stmt [35873,35929]
simple_stmt [35891,35947]
===
match
---
operator: } [45456,45457]
operator: } [45474,45475]
===
match
---
simple_stmt [23548,23632]
simple_stmt [23566,23650]
===
match
---
name: kwargs [46905,46911]
name: kwargs [46923,46929]
===
match
---
trailer [10093,10110]
trailer [10105,10122]
===
match
---
dotted_name [12601,12611]
dotted_name [12619,12629]
===
match
---
name: patch [5223,5228]
name: patch [5223,5228]
===
match
---
name: mock_hvac [30724,30733]
name: mock_hvac [30742,30751]
===
match
---
name: mock [15262,15266]
name: mock [15280,15284]
===
match
---
name: mock_client [31323,31334]
name: mock_client [31341,31352]
===
match
---
string: "vault_conn_id" [18160,18175]
string: "vault_conn_id" [18178,18193]
===
match
---
dotted_name [36257,36267]
dotted_name [36275,36285]
===
match
---
name: test_hook [34029,34038]
name: test_hook [34047,34056]
===
match
---
string: 'warnings' [41366,41376]
string: 'warnings' [41384,41394]
===
match
---
operator: == [5879,5881]
operator: == [5879,5881]
===
match
---
name: jwt [25095,25098]
name: jwt [25113,25116]
===
match
---
param [44377,44396]
param [44395,44414]
===
match
---
string: '' [44794,44796]
string: '' [44812,44814]
===
match
---
decorated [28702,29835]
decorated [28720,29853]
===
match
---
simple_stmt [20344,20394]
simple_stmt [20362,20412]
===
match
---
name: mock_hvac [35980,35989]
name: mock_hvac [35998,36007]
===
match
---
name: mock_hvac [14078,14087]
name: mock_hvac [14096,14105]
===
match
---
name: mock_hvac [28982,28991]
name: mock_hvac [29000,29009]
===
match
---
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [18891,18957]
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [18909,18975]
===
match
---
operator: { [40392,40393]
operator: { [40410,40411]
===
match
---
atom [6452,6500]
atom [6452,6500]
===
match
---
operator: , [44939,44940]
operator: , [44957,44958]
===
match
---
number: 2 [36205,36206]
number: 2 [36223,36224]
===
match
---
expr_stmt [2236,2308]
expr_stmt [2236,2308]
===
match
---
dotted_name [17207,17217]
dotted_name [17225,17235]
===
match
---
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [33062,33128]
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [33080,33146]
===
match
---
trailer [14174,14187]
trailer [14192,14205]
===
match
---
operator: , [15618,15619]
operator: , [15636,15637]
===
match
---
expr_stmt [8551,8601]
expr_stmt [8557,8607]
===
match
---
atom_expr [7287,7316]
atom_expr [7287,7316]
===
match
---
string: 'secret' [48204,48212]
string: 'secret' [48222,48230]
===
match
---
atom [10997,11074]
atom [11015,11092]
===
match
---
operator: = [20770,20771]
operator: = [20788,20789]
===
match
---
expr_stmt [12840,12870]
expr_stmt [12858,12888]
===
match
---
string: 'The version is not an int: text' [2505,2538]
string: 'The version is not an int: text' [2505,2538]
===
match
---
decorator [46431,46509]
decorator [46449,46527]
===
match
---
trailer [24940,24948]
trailer [24958,24966]
===
match
---
operator: , [39738,39739]
operator: , [39756,39757]
===
match
---
string: "path.json" [16550,16561]
string: "path.json" [16568,16579]
===
match
---
param [20660,20670]
param [20678,20688]
===
match
---
operator: = [23764,23765]
operator: = [23782,23783]
===
match
---
name: kwargs [5748,5754]
name: kwargs [5748,5754]
===
match
---
expr_stmt [19419,19484]
expr_stmt [19437,19502]
===
match
---
atom_expr [28395,28415]
atom_expr [28413,28433]
===
match
---
name: self [17308,17312]
name: self [17326,17330]
===
match
---
atom [37812,37814]
atom [37830,37832]
===
match
---
name: mock_connection [13019,13034]
name: mock_connection [13037,13052]
===
match
---
name: test_client [8049,8060]
name: test_client [8055,8066]
===
match
---
name: self [3681,3685]
name: self [3681,3685]
===
match
---
simple_stmt [25615,25666]
simple_stmt [25633,25684]
===
match
---
arglist [8007,8039]
arglist [8013,8045]
===
match
---
dictorsetmaker [40177,40255]
dictorsetmaker [40195,40273]
===
match
---
operator: = [45516,45517]
operator: = [45534,45535]
===
match
---
operator: , [48087,48088]
operator: , [48105,48106]
===
match
---
name: VaultHook [24773,24782]
name: VaultHook [24791,24800]
===
match
---
name: Client [8456,8462]
name: Client [8462,8468]
===
match
---
trailer [8954,8973]
trailer [8960,8979]
===
match
---
trailer [45321,45325]
trailer [45339,45343]
===
match
---
operator: , [37558,37559]
operator: , [37576,37577]
===
match
---
string: "vault_conn_id" [22157,22172]
string: "vault_conn_id" [22175,22190]
===
match
---
name: self [24268,24272]
name: self [24286,24290]
===
match
---
trailer [21257,21259]
trailer [21275,21277]
===
match
---
string: "data" [25099,25105]
string: "data" [25117,25123]
===
match
---
atom_expr [4185,4204]
atom_expr [4185,4204]
===
match
---
name: mock_file [23548,23557]
name: mock_file [23566,23575]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [24010,24074]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [24028,24092]
===
match
---
string: 'deletion_time' [45058,45073]
string: 'deletion_time' [45076,45091]
===
match
---
assert_stmt [5007,5060]
assert_stmt [5007,5060]
===
match
---
name: patch [9323,9328]
name: patch [9335,9340]
===
match
---
parameters [7176,7238]
parameters [7176,7238]
===
match
---
decorator [2578,2669]
decorator [2578,2669]
===
match
---
name: test_protocol [7163,7176]
name: test_protocol [7163,7176]
===
match
---
simple_stmt [10823,10874]
simple_stmt [10841,10892]
===
match
---
name: Client [23650,23656]
name: Client [23668,23674]
===
match
---
trailer [4825,4838]
trailer [4825,4838]
===
match
---
trailer [16076,16080]
trailer [16094,16098]
===
match
---
argument [20117,20144]
argument [20135,20162]
===
match
---
trailer [19692,19704]
trailer [19710,19722]
===
match
---
trailer [3279,3283]
trailer [3279,3283]
===
match
---
name: test_azure_init_params [12770,12792]
name: test_azure_init_params [12788,12810]
===
match
---
operator: @ [17014,17015]
operator: @ [17032,17033]
===
match
---
name: mock_client [39318,39329]
name: mock_client [39336,39347]
===
match
---
operator: = [9566,9567]
operator: = [9578,9579]
===
match
---
operator: , [49341,49342]
operator: , [49359,49360]
===
match
---
operator: } [43016,43017]
operator: } [43034,43035]
===
match
---
name: return_value [42379,42391]
name: return_value [42397,42409]
===
match
---
name: test_custom_auth_mount_point_dejson [5303,5338]
name: test_custom_auth_mount_point_dejson [5303,5338]
===
match
---
string: 'scope1' [19391,19399]
string: 'scope1' [19409,19417]
===
match
---
name: vault [1066,1071]
name: vault [1066,1071]
===
match
---
decorator [10521,10599]
decorator [10539,10617]
===
match
---
atom_expr [24912,24948]
atom_expr [24930,24966]
===
match
---
simple_stmt [14323,14473]
simple_stmt [14341,14491]
===
match
---
trailer [7515,7528]
trailer [7515,7528]
===
match
---
simple_stmt [43227,43259]
simple_stmt [43245,43277]
===
match
---
simple_stmt [40167,40257]
simple_stmt [40185,40275]
===
match
---
operator: = [30098,30099]
operator: = [30116,30117]
===
match
---
trailer [17449,17462]
trailer [17467,17480]
===
match
---
trailer [6393,6406]
trailer [6393,6406]
===
match
---
name: connection_dict [3264,3279]
name: connection_dict [3264,3279]
===
match
---
name: MagicMock [19175,19184]
name: MagicMock [19193,19202]
===
match
---
name: mock_get_connection [3887,3906]
name: mock_get_connection [3887,3906]
===
match
---
expr_stmt [36494,36524]
expr_stmt [36512,36542]
===
match
---
number: 2 [26483,26484]
number: 2 [26501,26502]
===
match
---
name: self [22955,22959]
name: self [22973,22977]
===
match
---
name: url [13528,13531]
name: url [13546,13549]
===
match
---
name: Client [4579,4585]
name: Client [4579,4585]
===
match
---
simple_stmt [34017,34070]
simple_stmt [34035,34088]
===
match
---
parameters [34324,34362]
parameters [34342,34380]
===
match
---
name: return_value [28999,29011]
name: return_value [29017,29029]
===
match
---
trailer [14904,15047]
trailer [14922,15065]
===
match
---
name: kwargs [3391,3397]
name: kwargs [3391,3397]
===
match
---
name: mock_connection [32531,32546]
name: mock_connection [32549,32564]
===
match
---
argument [31937,31964]
argument [31955,31982]
===
match
---
name: test_client [22297,22308]
name: test_client [22315,22326]
===
match
---
operator: , [14076,14077]
operator: , [14094,14095]
===
match
---
suite [24748,24840]
suite [24766,24858]
===
match
---
simple_stmt [29782,29835]
simple_stmt [29800,29853]
===
match
---
name: mock [5400,5404]
name: mock [5400,5404]
===
match
---
simple_stmt [27295,27330]
simple_stmt [27313,27348]
===
match
---
operator: , [28900,28901]
operator: , [28918,28919]
===
match
---
trailer [23675,23704]
trailer [23693,23722]
===
match
---
simple_stmt [48973,49063]
simple_stmt [48991,49081]
===
match
---
trailer [6278,6285]
trailer [6278,6285]
===
match
---
decorators [28702,28864]
decorators [28720,28882]
===
match
---
parameters [12792,12830]
parameters [12810,12848]
===
match
---
comparison [45596,46189]
comparison [45614,46207]
===
match
---
trailer [27069,27073]
trailer [27087,27091]
===
match
---
name: get_mock_connection [36608,36627]
name: get_mock_connection [36626,36645]
===
match
---
simple_stmt [49112,49206]
simple_stmt [49130,49224]
===
match
---
name: patch [17128,17133]
name: patch [17146,17151]
===
match
---
name: test_hook [37043,37052]
name: test_hook [37061,37070]
===
match
---
name: mock_client [41063,41074]
name: mock_client [41081,41092]
===
match
---
suite [2023,2573]
suite [2023,2573]
===
match
---
atom_expr [34516,34548]
atom_expr [34534,34566]
===
match
---
name: return_value [1450,1462]
name: return_value [1450,1462]
===
match
---
expr_stmt [44558,44601]
expr_stmt [44576,44619]
===
match
---
comparison [18631,18676]
comparison [18649,18694]
===
match
---
name: mock_get_credentials [15598,15618]
name: mock_get_credentials [15616,15636]
===
match
---
name: assert_called_with [12293,12311]
name: assert_called_with [12311,12329]
===
match
---
string: "pass" [22468,22474]
string: "pass" [22486,22492]
===
match
---
name: get_mock_connection [19270,19289]
name: get_mock_connection [19288,19307]
===
match
---
trailer [7296,7303]
trailer [7296,7303]
===
match
---
name: is_authenticated [35032,35048]
name: is_authenticated [35050,35066]
===
match
---
dictorsetmaker [39790,39951]
dictorsetmaker [39808,39969]
===
match
---
operator: , [39163,39164]
operator: , [39181,39182]
===
match
---
string: "vault_conn_id" [9979,9994]
string: "vault_conn_id" [9991,10006]
===
match
---
operator: = [27483,27484]
operator: = [27501,27502]
===
match
---
trailer [27547,27549]
trailer [27565,27567]
===
match
---
name: return_value [30142,30154]
name: return_value [30160,30172]
===
match
---
trailer [4988,4998]
trailer [4988,4998]
===
match
---
operator: , [23247,23248]
operator: , [23265,23266]
===
match
---
string: "github" [22013,22021]
string: "github" [22031,22039]
===
match
---
string: "vault_conn_id" [2416,2431]
string: "vault_conn_id" [2416,2431]
===
match
---
operator: = [20098,20099]
operator: = [20116,20117]
===
match
---
name: mock_client [30157,30168]
name: mock_client [30175,30186]
===
match
---
name: mock_open [23342,23351]
name: mock_open [23360,23369]
===
match
---
trailer [9139,9158]
trailer [9151,9170]
===
match
---
simple_stmt [27338,27403]
simple_stmt [27356,27421]
===
match
---
operator: = [10131,10132]
operator: = [10143,10144]
===
match
---
string: "vault_conn_id" [38561,38576]
string: "vault_conn_id" [38579,38594]
===
match
---
operator: = [9661,9662]
operator: = [9673,9674]
===
match
---
name: return_value [44687,44699]
name: return_value [44705,44717]
===
match
---
simple_stmt [27500,27550]
simple_stmt [27518,27568]
===
match
---
name: mock [41938,41942]
name: mock [41956,41960]
===
match
---
operator: @ [28786,28787]
operator: @ [28804,28805]
===
match
---
operator: = [24534,24535]
operator: = [24552,24553]
===
match
---
operator: , [47283,47284]
operator: , [47301,47302]
===
match
---
expr_stmt [48776,48806]
expr_stmt [48794,48824]
===
match
---
trailer [14711,14728]
trailer [14729,14746]
===
match
---
operator: , [43505,43506]
operator: , [43523,43524]
===
match
---
operator: ** [31776,31778]
operator: ** [31794,31796]
===
match
---
trailer [30655,30672]
trailer [30673,30690]
===
match
---
expr_stmt [15737,15781]
expr_stmt [15755,15799]
===
match
---
name: patch [11576,11581]
name: patch [11594,11599]
===
match
---
number: 1 [49060,49061]
number: 1 [49078,49079]
===
match
---
operator: == [11521,11523]
operator: == [11539,11541]
===
match
---
expr_stmt [1616,1684]
expr_stmt [1616,1684]
===
match
---
dotted_name [48475,48485]
dotted_name [48493,48503]
===
match
---
string: '' [42486,42488]
string: '' [42504,42506]
===
match
---
trailer [27427,27432]
trailer [27445,27450]
===
match
---
name: test_userpass_init_params [35349,35374]
name: test_userpass_init_params [35367,35392]
===
match
---
trailer [11220,11222]
trailer [11238,11240]
===
match
---
trailer [30199,30219]
trailer [30217,30237]
===
match
---
operator: = [39426,39427]
operator: = [39444,39445]
===
match
---
operator: { [21986,21987]
operator: { [22004,22005]
===
match
---
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [17134,17200]
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [17152,17218]
===
match
---
trailer [6542,6554]
trailer [6542,6554]
===
match
---
name: VaultError [2487,2497]
name: VaultError [2487,2497]
===
match
---
name: test_ldap_dejson [27786,27802]
name: test_ldap_dejson [27804,27820]
===
match
---
trailer [11105,11115]
trailer [11123,11133]
===
match
---
operator: == [38789,38791]
operator: == [38807,38809]
===
match
---
atom_expr [10133,10153]
atom_expr [10145,10165]
===
match
---
name: patch [46437,46442]
name: patch [46455,46460]
===
match
---
atom [5608,5663]
atom [5608,5663]
===
match
---
atom [24573,24669]
atom [24591,24687]
===
match
---
operator: @ [32193,32194]
operator: @ [32211,32212]
===
match
---
name: side_effect [25738,25749]
name: side_effect [25756,25767]
===
match
---
name: mock_connection [27941,27956]
name: mock_connection [27959,27974]
===
match
---
trailer [40452,40460]
trailer [40470,40478]
===
match
---
name: mock [4544,4548]
name: mock [4544,4548]
===
match
---
string: "vault_conn_id" [38578,38593]
string: "vault_conn_id" [38596,38611]
===
match
---
trailer [46736,46738]
trailer [46754,46756]
===
match
---
atom [30404,30567]
atom [30422,30585]
===
match
---
name: test_client [10119,10130]
name: test_client [10131,10142]
===
match
---
simple_stmt [35078,35113]
simple_stmt [35096,35131]
===
match
---
name: self [44360,44364]
name: self [44378,44382]
===
match
---
string: 'destroyed' [43679,43690]
string: 'destroyed' [43697,43708]
===
match
---
name: connection_dict [15984,15999]
name: connection_dict [16002,16017]
===
match
---
trailer [15809,15822]
trailer [15827,15840]
===
match
---
expr_stmt [49072,49103]
expr_stmt [49090,49121]
===
match
---
name: host [30850,30854]
name: host [30868,30872]
===
match
---
name: kwargs [28201,28207]
name: kwargs [28219,28225]
===
match
---
trailer [12415,12444]
trailer [12433,12462]
===
match
---
name: kwargs [4991,4997]
name: kwargs [4991,4997]
===
match
---
atom_expr [3264,3283]
atom_expr [3264,3283]
===
match
---
atom_expr [25115,25164]
atom_expr [25133,25182]
===
match
---
name: mock_connection [14210,14225]
name: mock_connection [14228,14243]
===
match
---
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [12612,12678]
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [12630,12696]
===
match
---
argument [37108,37135]
argument [37126,37153]
===
match
---
simple_stmt [24957,25022]
simple_stmt [24975,25040]
===
match
---
name: mock_hvac [24198,24207]
name: mock_hvac [24216,24225]
===
match
---
simple_stmt [5425,5469]
simple_stmt [5425,5469]
===
match
---
name: side_effect [38509,38520]
name: side_effect [38527,38538]
===
match
---
name: assert_called_with [27355,27373]
name: assert_called_with [27373,27391]
===
match
---
name: mock_connection [11898,11913]
name: mock_connection [11916,11931]
===
match
---
operator: , [16176,16177]
operator: , [16194,16195]
===
match
---
param [46549,46554]
param [46567,46572]
===
match
---
dictorsetmaker [39709,39737]
dictorsetmaker [39727,39755]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [34233,34297]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [34251,34315]
===
match
---
operator: = [13707,13708]
operator: = [13725,13726]
===
match
---
atom [9776,9854]
atom [9788,9866]
===
match
---
operator: = [30263,30264]
operator: = [30281,30282]
===
match
---
operator: ** [10037,10039]
operator: ** [10049,10051]
===
match
---
trailer [13581,13587]
trailer [13599,13605]
===
match
---
dictorsetmaker [22000,22022]
dictorsetmaker [22018,22040]
===
match
---
name: test_hook [33696,33705]
name: test_hook [33714,33723]
===
match
---
expr_stmt [9645,9689]
expr_stmt [9657,9701]
===
match
---
trailer [42351,42354]
trailer [42369,42372]
===
match
---
argument [7937,7953]
argument [7937,7953]
===
match
---
name: role_id [8007,8014]
name: role_id [8013,8020]
===
match
---
argument [6718,6726]
argument [6718,6726]
===
match
---
trailer [47142,47150]
trailer [47160,47168]
===
match
---
trailer [47729,47742]
trailer [47747,47760]
===
match
---
name: kwargs [13149,13155]
name: kwargs [13167,13173]
===
match
---
simple_stmt [4569,4613]
simple_stmt [4569,4613]
===
match
---
trailer [18645,18658]
trailer [18663,18676]
===
match
---
simple_stmt [5530,5581]
simple_stmt [5530,5581]
===
match
---
string: 'http://localhost:8180' [22380,22403]
string: 'http://localhost:8180' [22398,22421]
===
match
---
name: connection_dict [34696,34711]
name: connection_dict [34714,34729]
===
match
---
atom_expr [34029,34069]
atom_expr [34047,34087]
===
match
---
name: mock_hvac [40980,40989]
name: mock_hvac [40998,41007]
===
match
---
operator: , [37951,37952]
operator: , [37969,37970]
===
match
---
operator: } [33512,33513]
operator: } [33530,33531]
===
match
---
name: mock [42224,42228]
name: mock [42242,42246]
===
match
---
name: kwargs [35731,35737]
name: kwargs [35749,35755]
===
match
---
name: PropertyMock [1576,1588]
name: PropertyMock [1576,1588]
===
match
---
simple_stmt [21341,21404]
simple_stmt [21359,21422]
===
match
---
name: assert_called_once_with [38853,38876]
name: assert_called_once_with [38871,38894]
===
match
---
trailer [29557,29564]
trailer [29575,29582]
===
match
---
name: test_hook [14751,14760]
name: test_hook [14769,14778]
===
match
---
simple_stmt [6434,6501]
simple_stmt [6434,6501]
===
match
---
trailer [24992,25021]
trailer [25010,25039]
===
match
---
operator: = [48225,48226]
operator: = [48243,48244]
===
match
---
atom_expr [32948,33011]
atom_expr [32966,33029]
===
match
---
string: "vault_conn_id" [7598,7613]
string: "vault_conn_id" [7598,7613]
===
match
---
name: patch [31106,31111]
name: patch [31124,31129]
===
match
---
param [34331,34341]
param [34349,34359]
===
match
---
name: side_effect [4056,4067]
name: side_effect [4056,4067]
===
match
---
name: connection_dict [35703,35718]
name: connection_dict [35721,35736]
===
match
---
name: read_secret_version [39466,39485]
name: read_secret_version [39484,39503]
===
match
---
name: mock_connection [24489,24504]
name: mock_connection [24507,24522]
===
match
---
atom_expr [7547,7566]
atom_expr [7547,7566]
===
match
---
string: "pass" [13742,13748]
string: "pass" [13760,13766]
===
match
---
name: return_value [21820,21832]
name: return_value [21838,21850]
===
match
---
name: auth [16713,16717]
name: auth [16731,16735]
===
match
---
expr_stmt [30177,30221]
expr_stmt [30195,30239]
===
match
---
trailer [18394,18401]
trailer [18412,18419]
===
match
---
operator: , [6971,6972]
operator: , [6971,6972]
===
match
---
name: get_mock_connection [34486,34505]
name: get_mock_connection [34504,34523]
===
match
---
trailer [18613,18615]
trailer [18631,18633]
===
match
---
name: auth [22425,22429]
name: auth [22443,22447]
===
match
---
operator: , [25093,25094]
operator: , [25111,25112]
===
match
---
simple_stmt [31754,31786]
simple_stmt [31772,31804]
===
match
---
trailer [44086,44146]
trailer [44104,44164]
===
match
---
dotted_name [15454,15464]
dotted_name [15472,15482]
===
match
---
expr_stmt [30395,30567]
expr_stmt [30413,30585]
===
match
---
string: 'pass' [11403,11409]
string: 'pass' [11421,11427]
===
match
---
atom [19455,19484]
atom [19473,19502]
===
match
---
atom_expr [30900,30949]
atom_expr [30918,30967]
===
match
---
operator: , [44375,44376]
operator: , [44393,44394]
===
match
---
string: "missing" [43320,43329]
string: "missing" [43338,43347]
===
match
---
operator: @ [15453,15454]
operator: @ [15471,15472]
===
match
---
dotted_name [23915,23925]
dotted_name [23933,23943]
===
match
---
trailer [38491,38504]
trailer [38509,38522]
===
match
---
simple_stmt [37702,37733]
simple_stmt [37720,37751]
===
match
---
simple_stmt [44016,44147]
simple_stmt [44034,44165]
===
match
---
simple_stmt [33843,33908]
simple_stmt [33861,33926]
===
match
---
name: configure [13588,13597]
name: configure [13606,13615]
===
match
---
decorators [48281,48552]
decorators [48299,48570]
===
match
---
trailer [13106,13118]
trailer [13124,13136]
===
match
---
operator: = [18048,18049]
operator: = [18066,18067]
===
match
---
trailer [15135,15148]
trailer [15153,15166]
===
match
---
string: "vaults" [6840,6848]
string: "vaults" [6840,6848]
===
match
---
expr_stmt [22885,22928]
expr_stmt [22903,22946]
===
match
---
name: assert_called_with [16732,16750]
name: assert_called_with [16750,16768]
===
match
---
string: 'secret_key' [38093,38105]
string: 'secret_key' [38111,38123]
===
match
---
name: test_hook [16281,16290]
name: test_hook [16299,16308]
===
match
---
string: "radius_host" [32711,32724]
string: "radius_host" [32729,32742]
===
match
---
trailer [30849,30891]
trailer [30867,30909]
===
match
---
name: create_or_update_secret [48020,48043]
name: create_or_update_secret [48038,48061]
===
match
---
operator: = [47266,47267]
operator: = [47284,47285]
===
match
---
simple_stmt [26418,26468]
simple_stmt [26436,26486]
===
match
---
name: mock_connection [17573,17588]
name: mock_connection [17591,17606]
===
match
---
operator: { [31474,31475]
operator: { [31492,31493]
===
match
---
name: self [7357,7361]
name: self [7357,7361]
===
match
---
name: mock_get_connection [44460,44479]
name: mock_get_connection [44478,44497]
===
match
---
simple_stmt [30290,30311]
simple_stmt [30308,30329]
===
match
---
operator: @ [34137,34138]
operator: @ [34155,34156]
===
match
---
trailer [22874,22876]
trailer [22892,22894]
===
match
---
operator: , [27124,27125]
operator: , [27142,27143]
===
match
---
name: mock_client [22917,22928]
name: mock_client [22935,22946]
===
match
---
operator: , [24612,24613]
operator: , [24630,24631]
===
match
---
param [7218,7237]
param [7218,7237]
===
match
---
atom [45377,45457]
atom [45395,45475]
===
match
---
trailer [13423,13440]
trailer [13441,13458]
===
match
---
name: get [17950,17953]
name: get [17968,17971]
===
match
---
operator: , [19790,19791]
operator: , [19808,19809]
===
match
---
name: mock [15370,15374]
name: mock [15388,15392]
===
match
---
string: "resource" [14451,14461]
string: "resource" [14469,14479]
===
match
---
string: 'http://localhost:8180' [21308,21331]
string: 'http://localhost:8180' [21326,21349]
===
match
---
operator: = [25750,25751]
operator: = [25768,25769]
===
match
---
string: "approle" [8798,8807]
string: "approle" [8804,8813]
===
match
---
atom [7488,7490]
atom [7488,7490]
===
match
---
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [48402,48468]
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [48420,48486]
===
match
---
trailer [7303,7316]
trailer [7303,7316]
===
match
---
simple_stmt [48664,48709]
simple_stmt [48682,48727]
===
match
---
name: kwargs [48973,48979]
name: kwargs [48991,48997]
===
match
---
name: connection_dict [17732,17747]
name: connection_dict [17750,17765]
===
match
---
trailer [32156,32169]
trailer [32174,32187]
===
match
---
name: auth [29633,29637]
name: auth [29651,29655]
===
match
---
name: assert_called_with [30929,30947]
name: assert_called_with [30947,30965]
===
match
---
operator: , [41210,41211]
operator: , [41228,41229]
===
match
---
simple_stmt [42098,42143]
simple_stmt [42116,42161]
===
match
---
name: patch [22690,22695]
name: patch [22708,22713]
===
match
---
trailer [28440,28459]
trailer [28458,28477]
===
match
---
simple_stmt [23640,23705]
simple_stmt [23658,23723]
===
match
---
trailer [27347,27354]
trailer [27365,27372]
===
match
---
name: test_aws_iam_dejson [11740,11759]
name: test_aws_iam_dejson [11758,11777]
===
match
---
expr_stmt [46830,46896]
expr_stmt [46848,46914]
===
match
---
simple_stmt [48815,48859]
simple_stmt [48833,48877]
===
match
---
name: mock_client [12840,12851]
name: mock_client [12858,12869]
===
match
---
suite [7239,8160]
suite [7239,8166]
===
match
---
trailer [14760,14769]
trailer [14778,14787]
===
match
---
operator: = [42392,42393]
operator: = [42410,42411]
===
match
---
trailer [3388,3398]
trailer [3388,3398]
===
match
---
decorator [11654,11732]
decorator [11672,11750]
===
match
---
expr_stmt [11188,11222]
expr_stmt [11206,11240]
===
match
---
string: "vault_conn_id" [2433,2448]
string: "vault_conn_id" [2433,2448]
===
match
---
name: mock_get_connection [19300,19319]
name: mock_get_connection [19318,19337]
===
match
---
simple_stmt [2071,2115]
simple_stmt [2071,2115]
===
match
---
name: side_effect [43086,43097]
name: side_effect [43104,43115]
===
match
---
name: self [37608,37612]
name: self [37626,37630]
===
match
---
name: mock_connection [1698,1713]
name: mock_connection [1698,1713]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [40683,40747]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [40701,40765]
===
match
---
trailer [21248,21257]
trailer [21266,21275]
===
match
---
expr_stmt [25471,25501]
expr_stmt [25489,25519]
===
match
---
name: mock [40588,40592]
name: mock [40606,40610]
===
match
---
name: mock_client [14190,14201]
name: mock_client [14208,14219]
===
match
---
atom_expr [37302,37342]
atom_expr [37320,37360]
===
match
---
decorator [29840,29920]
decorator [29858,29938]
===
match
---
atom_expr [39332,39348]
atom_expr [39350,39366]
===
match
---
decorator [3564,3642]
decorator [3564,3642]
===
match
---
trailer [27269,27286]
trailer [27287,27304]
===
match
---
classdef [1091,49401]
classdef [1091,49419]
===
match
---
name: patch [10443,10448]
name: patch [10461,10466]
===
match
---
operator: = [10201,10202]
operator: = [10213,10214]
===
match
---
operator: } [11073,11074]
operator: } [11091,11092]
===
match
---
name: mock_get_connection [8377,8396]
name: mock_get_connection [8383,8402]
===
match
---
name: test_client [32077,32088]
name: test_client [32095,32106]
===
match
---
name: get [12111,12114]
name: get [12129,12132]
===
match
---
operator: , [6676,6677]
operator: , [6676,6677]
===
match
---
name: mock_get_connection [33260,33279]
name: mock_get_connection [33278,33297]
===
match
---
simple_stmt [18121,18177]
simple_stmt [18139,18195]
===
match
---
simple_stmt [19494,19651]
simple_stmt [19512,19669]
===
match
---
decorators [18682,19041]
decorators [18700,19059]
===
match
---
name: MagicMock [39337,39346]
name: MagicMock [39355,39364]
===
match
---
simple_stmt [32077,32127]
simple_stmt [32095,32145]
===
match
---
with_stmt [32943,33045]
with_stmt [32961,33063]
===
match
---
argument [32027,32041]
argument [32045,32059]
===
match
---
operator: , [42520,42521]
operator: , [42538,42539]
===
match
---
trailer [16302,16312]
trailer [16320,16330]
===
match
---
name: connection_dict [4857,4872]
name: connection_dict [4857,4872]
===
match
---
name: mock_hvac [44558,44567]
name: mock_hvac [44576,44585]
===
match
---
trailer [12097,12110]
trailer [12115,12128]
===
match
---
trailer [35684,35688]
trailer [35702,35706]
===
match
---
decorator [5989,6069]
decorator [5989,6069]
===
match
---
name: secret [32043,32049]
name: secret [32061,32067]
===
match
---
funcdef [19045,20455]
funcdef [19063,20473]
===
match
---
expr_stmt [5590,5663]
expr_stmt [5590,5663]
===
match
---
param [6189,6199]
param [6189,6199]
===
match
---
expr_stmt [42249,42292]
expr_stmt [42267,42310]
===
match
---
dotted_name [845,858]
dotted_name [845,858]
===
match
---
dictorsetmaker [27105,27171]
dictorsetmaker [27123,27189]
===
match
---
trailer [48706,48708]
trailer [48724,48726]
===
match
---
trailer [40463,40466]
trailer [40481,40484]
===
match
---
param [6183,6188]
param [6183,6188]
===
match
---
atom [26995,26997]
atom [27013,27015]
===
match
---
string: "vault_conn_id" [28241,28256]
string: "vault_conn_id" [28259,28274]
===
match
---
operator: { [9776,9777]
operator: { [9788,9789]
===
match
---
expr_stmt [12931,12975]
expr_stmt [12949,12993]
===
match
---
name: mock [32278,32282]
name: mock [32296,32300]
===
match
---
decorators [20460,20622]
decorators [20478,20640]
===
match
---
string: "gcp_scopes" [17837,17849]
string: "gcp_scopes" [17855,17867]
===
match
---
string: 'request_id' [37899,37911]
string: 'request_id' [37917,37929]
===
match
---
trailer [11162,11179]
trailer [11180,11197]
===
match
---
atom [16002,16004]
atom [16020,16022]
===
match
---
name: tenant_id [14918,14927]
name: tenant_id [14936,14945]
===
match
---
suite [19147,20455]
suite [19165,20473]
===
match
---
trailer [8703,8707]
trailer [8709,8713]
===
match
---
dotted_name [28787,28797]
dotted_name [28805,28815]
===
match
---
simple_stmt [35566,35617]
simple_stmt [35584,35635]
===
match
---
operator: , [48331,48332]
operator: , [48349,48350]
===
match
---
name: connection_dict [31456,31471]
name: connection_dict [31474,31489]
===
match
---
operator: = [14564,14565]
operator: = [14582,14583]
===
match
---
operator: @ [20460,20461]
operator: @ [20478,20479]
===
match
---
operator: { [24573,24574]
operator: { [24591,24592]
===
match
---
string: "kv_engine_version" [6608,6627]
string: "kv_engine_version" [6608,6627]
===
match
---
operator: = [46292,46293]
operator: = [46310,46311]
===
match
---
operator: @ [22684,22685]
operator: @ [22702,22703]
===
match
---
string: 'destroyed' [45993,46004]
string: 'destroyed' [46011,46022]
===
match
---
operator: = [10691,10692]
operator: = [10709,10710]
===
match
---
expr_stmt [12984,13034]
expr_stmt [13002,13052]
===
match
---
name: self [2141,2145]
name: self [2141,2145]
===
match
---
arglist [44100,44136]
arglist [44118,44154]
===
match
---
simple_stmt [9259,9312]
simple_stmt [9271,9324]
===
match
---
string: "vault_conn_id" [8974,8989]
string: "vault_conn_id" [8980,8995]
===
match
---
trailer [3232,3245]
trailer [3232,3245]
===
match
---
name: mock_get_connection [29087,29106]
name: mock_get_connection [29105,29124]
===
match
---
trailer [22436,22442]
trailer [22454,22460]
===
match
---
name: mock [13885,13889]
name: mock [13903,13907]
===
match
---
operator: ** [47026,47028]
operator: ** [47044,47046]
===
match
---
operator: @ [17206,17207]
operator: @ [17224,17225]
===
match
---
operator: = [10286,10287]
operator: = [10304,10305]
===
match
---
name: assert_called_with [22513,22531]
name: assert_called_with [22531,22549]
===
match
---
trailer [23464,23473]
trailer [23482,23491]
===
match
---
string: '2020-03-16T21:01:43.331126Z' [42635,42664]
string: '2020-03-16T21:01:43.331126Z' [42653,42682]
===
match
---
name: side_effect [16047,16058]
name: side_effect [16065,16076]
===
match
---
operator: = [9774,9775]
operator: = [9786,9787]
===
match
---
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [10449,10515]
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [10467,10533]
===
match
---
simple_stmt [26812,26856]
simple_stmt [26830,26874]
===
match
---
simple_stmt [1616,1685]
simple_stmt [1616,1685]
===
match
---
expr_stmt [5386,5416]
expr_stmt [5386,5416]
===
match
---
decorated [22600,23909]
decorated [22618,23927]
===
match
---
string: "kubernetes_role" [23217,23234]
string: "kubernetes_role" [23235,23252]
===
match
---
trailer [8973,8990]
trailer [8979,8996]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [33146,33210]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [33164,33228]
===
match
---
operator: { [43768,43769]
operator: { [43786,43787]
===
match
---
name: self [5339,5343]
name: self [5339,5343]
===
match
---
string: 'lease_duration' [42534,42550]
string: 'lease_duration' [42552,42568]
===
match
---
operator: = [23361,23362]
operator: = [23379,23380]
===
match
---
atom_expr [47044,47122]
atom_expr [47062,47140]
===
match
---
dotted_name [1795,1805]
dotted_name [1795,1805]
===
match
---
operator: , [1194,1195]
operator: , [1194,1195]
===
match
---
name: url [14816,14819]
name: url [14834,14837]
===
match
---
simple_stmt [12273,12329]
simple_stmt [12291,12347]
===
match
---
argument [32043,32056]
argument [32061,32074]
===
match
---
simple_stmt [1408,1469]
simple_stmt [1408,1469]
===
match
---
operator: = [47782,47783]
operator: = [47800,47801]
===
match
---
name: mock_connection [1482,1497]
name: mock_connection [1482,1497]
===
match
---
operator: = [22379,22380]
operator: = [22397,22398]
===
match
---
parameters [22798,22836]
parameters [22816,22854]
===
match
---
comparison [9266,9311]
comparison [9278,9323]
===
match
---
string: "gcp_scopes" [16231,16243]
string: "gcp_scopes" [16249,16261]
===
match
---
operator: = [22953,22954]
operator: = [22971,22972]
===
match
---
simple_stmt [8999,9034]
simple_stmt [9005,9040]
===
match
---
string: 'role_id' [9826,9835]
string: 'role_id' [9838,9847]
===
match
---
parameters [2855,2920]
parameters [2855,2920]
===
match
---
operator: = [41836,41837]
operator: = [41854,41855]
===
match
---
name: test_hook [35951,35960]
name: test_hook [35969,35978]
===
match
---
suite [10670,11565]
suite [10688,11583]
===
match
---
simple_stmt [43128,43218]
simple_stmt [43146,43236]
===
match
---
number: 2 [45455,45456]
number: 2 [45473,45474]
===
match
---
operator: } [35645,35646]
operator: } [35663,35664]
===
match
---
string: "text" [2301,2307]
string: "text" [2301,2307]
===
match
---
decorators [21528,21690]
decorators [21546,21708]
===
match
---
atom_expr [29548,29612]
atom_expr [29566,29630]
===
match
---
simple_stmt [24805,24840]
simple_stmt [24823,24858]
===
match
---
string: '182d0673-618c-9889-4cba-4e1f4cfe4b4b' [41144,41182]
string: '182d0673-618c-9889-4cba-4e1f4cfe4b4b' [41162,41200]
===
match
---
name: test_hook [22554,22563]
name: test_hook [22572,22581]
===
match
---
atom_expr [12879,12908]
atom_expr [12897,12926]
===
match
---
operator: , [4002,4003]
operator: , [4002,4003]
===
match
---
operator: = [20123,20124]
operator: = [20141,20142]
===
match
---
name: assert_called_with [22443,22461]
name: assert_called_with [22461,22479]
===
match
---
arglist [30850,30890]
arglist [30868,30908]
===
match
---
name: test_client [23713,23724]
name: test_client [23731,23742]
===
match
---
name: mock [11821,11825]
name: mock [11839,11843]
===
match
---
suite [25462,26529]
suite [25480,26547]
===
match
---
operator: = [17463,17464]
operator: = [17481,17482]
===
match
---
trailer [41785,41809]
trailer [41803,41827]
===
match
---
name: role_id [10279,10286]
name: role_id [10297,10304]
===
match
---
name: secret_path [41673,41684]
name: secret_path [41691,41702]
===
match
---
decorators [36256,36418]
decorators [36274,36436]
===
match
---
name: get [9893,9896]
name: get [9905,9908]
===
match
---
name: mount_point [40524,40535]
name: mount_point [40542,40553]
===
match
---
name: test_hook [48010,48019]
name: test_hook [48028,48037]
===
match
---
simple_stmt [8641,8708]
simple_stmt [8647,8714]
===
match
---
operator: , [46317,46318]
operator: , [46335,46336]
===
match
---
trailer [1714,1721]
trailer [1714,1721]
===
match
---
atom_expr [38476,38520]
atom_expr [38494,38538]
===
match
---
name: path [41832,41836]
name: path [41850,41854]
===
match
---
name: kwargs [33720,33726]
name: kwargs [33738,33744]
===
match
---
atom [29165,29167]
atom [29183,29185]
===
match
---
name: mock_get_connection [15790,15809]
name: mock_get_connection [15808,15827]
===
match
---
string: "azure_resource" [14433,14449]
string: "azure_resource" [14451,14467]
===
match
---
name: mock_connection [26864,26879]
name: mock_connection [26882,26897]
===
match
---
name: mock [4357,4361]
name: mock [4357,4361]
===
match
---
atom_expr [16488,16619]
atom_expr [16506,16637]
===
match
---
dictorsetmaker [42408,43033]
dictorsetmaker [42426,43051]
===
match
---
simple_stmt [40980,41024]
simple_stmt [40998,41042]
===
match
---
arglist [38890,38940]
arglist [38908,38958]
===
match
---
atom [39428,39430]
atom [39446,39448]
===
match
---
name: connection_dict [9758,9773]
name: connection_dict [9770,9785]
===
match
---
decorators [41853,42015]
decorators [41871,42033]
===
match
---
name: Client [32489,32495]
name: Client [32507,32513]
===
match
---
dictorsetmaker [4895,4957]
dictorsetmaker [4895,4957]
===
match
---
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [15381,15447]
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [15399,15465]
===
match
---
number: 2 [11519,11520]
number: 2 [11537,11538]
===
match
---
trailer [18594,18613]
trailer [18612,18631]
===
match
---
trailer [18420,18449]
trailer [18438,18467]
===
match
---
trailer [28991,28998]
trailer [29009,29016]
===
match
---
string: "auth_type" [4766,4777]
string: "auth_type" [4766,4777]
===
match
---
name: kv_engine_version [15149,15166]
name: kv_engine_version [15167,15184]
===
match
---
name: schema [3862,3868]
name: schema [3862,3868]
===
match
---
operator: = [17932,17933]
operator: = [17950,17951]
===
match
---
string: "auth_type" [49017,49028]
string: "auth_type" [49035,49046]
===
match
---
name: VaultHook [35845,35854]
name: VaultHook [35863,35872]
===
match
---
operator: = [19453,19454]
operator: = [19471,19472]
===
match
---
expr_stmt [32479,32522]
expr_stmt [32497,32540]
===
match
---
name: mock_client [3799,3810]
name: mock_client [3799,3810]
===
match
---
string: "kubernetes" [24600,24612]
string: "kubernetes" [24618,24630]
===
match
---
atom_expr [4639,4665]
atom_expr [4639,4665]
===
match
---
name: mock_get_credentials [20018,20038]
name: mock_get_credentials [20036,20056]
===
match
---
trailer [30704,30713]
trailer [30722,30731]
===
match
---
trailer [37107,37136]
trailer [37125,37154]
===
match
---
string: 'request_id' [43360,43372]
string: 'request_id' [43378,43390]
===
match
---
name: mock_hvac [23640,23649]
name: mock_hvac [23658,23667]
===
match
---
trailer [34681,34693]
trailer [34699,34711]
===
match
---
name: connection_dict [39410,39425]
name: connection_dict [39428,39443]
===
match
---
name: mock_get_connection [22816,22835]
name: mock_get_connection [22834,22853]
===
match
---
operator: , [11378,11379]
operator: , [11396,11397]
===
match
---
name: extra_dejson [40108,40120]
name: extra_dejson [40126,40138]
===
match
---
decorator [15172,15257]
decorator [15190,15275]
===
match
---
atom_expr [33304,33320]
atom_expr [33322,33338]
===
match
---
string: "project_id" [19471,19483]
string: "project_id" [19489,19501]
===
match
---
name: assert_called_once_with [48155,48178]
name: assert_called_once_with [48173,48196]
===
match
---
trailer [28508,28513]
trailer [28526,28531]
===
match
---
string: 'missing' [41837,41846]
string: 'missing' [41855,41864]
===
match
---
name: keyfile_dict [20086,20098]
name: keyfile_dict [20104,20116]
===
match
---
operator: = [19225,19226]
operator: = [19243,19244]
===
match
---
trailer [28971,28973]
trailer [28989,28991]
===
match
---
trailer [12110,12114]
trailer [12128,12132]
===
match
---
name: mock_client [25542,25553]
name: mock_client [25560,25571]
===
match
---
simple_stmt [21764,21795]
simple_stmt [21782,21813]
===
match
---
expr_stmt [40266,40297]
expr_stmt [40284,40315]
===
match
---
arglist [48044,48095]
arglist [48062,48113]
===
match
---
name: read_secret [41774,41785]
name: read_secret [41792,41803]
===
match
---
atom_expr [1693,1721]
atom_expr [1693,1721]
===
match
---
expr_stmt [26864,26908]
expr_stmt [26882,26926]
===
match
---
operator: { [27091,27092]
operator: { [27109,27110]
===
match
---
simple_stmt [10379,10432]
simple_stmt [10397,10450]
===
match
---
comparison [40392,40432]
comparison [40410,40450]
===
match
---
decorated [37348,38951]
decorated [37366,38969]
===
match
---
atom_expr [10823,10855]
atom_expr [10841,10873]
===
match
---
simple_stmt [29401,29433]
simple_stmt [29419,29451]
===
match
---
name: VaultError [975,985]
name: VaultError [975,985]
===
match
---
name: secret [30866,30872]
name: secret [30884,30890]
===
match
---
parameters [25423,25461]
parameters [25441,25479]
===
match
---
name: test_hook [12233,12242]
name: test_hook [12251,12260]
===
match
---
operator: , [21054,21055]
operator: , [21072,21073]
===
match
---
name: mock_hvac [33329,33338]
name: mock_hvac [33347,33356]
===
match
---
string: 'scope1' [16590,16598]
string: 'scope1' [16608,16616]
===
match
---
operator: , [45151,45152]
operator: , [45169,45170]
===
match
---
operator: @ [7077,7078]
operator: @ [7077,7078]
===
match
---
operator: , [45036,45037]
operator: , [45054,45055]
===
match
---
operator: = [40953,40954]
operator: = [40971,40972]
===
match
---
name: expand [6809,6815]
name: expand [6809,6815]
===
match
---
argument [33718,33726]
argument [33736,33744]
===
match
---
atom [6594,6687]
atom [6594,6687]
===
match
---
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [40599,40665]
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [40617,40683]
===
match
---
expr_stmt [17962,18028]
expr_stmt [17980,18046]
===
match
---
trailer [29644,29654]
trailer [29662,29672]
===
match
---
string: "path.json" [17812,17823]
string: "path.json" [17830,17841]
===
match
---
operator: , [11764,11765]
operator: , [11782,11783]
===
match
---
operator: == [15123,15125]
operator: == [15141,15143]
===
match
---
trailer [14137,14147]
trailer [14155,14165]
===
match
---
name: url [29584,29587]
name: url [29602,29605]
===
match
---
name: mock_connection [34551,34566]
name: mock_connection [34569,34584]
===
match
---
name: self [17503,17507]
name: self [17521,17525]
===
match
---
name: method [48598,48604]
name: method [48616,48622]
===
match
---
string: "vault_conn_id" [16129,16144]
string: "vault_conn_id" [16147,16162]
===
match
---
trailer [3456,3474]
trailer [3456,3474]
===
match
---
parameters [33242,33280]
parameters [33260,33298]
===
match
---
string: "airflow.providers.google.cloud.utils.credentials_provider._get_scopes" [15184,15255]
string: "airflow.providers.google.cloud.utils.credentials_provider._get_scopes" [15202,15273]
===
match
---
string: 'key' [49174,49179]
string: 'key' [49192,49197]
===
match
---
trailer [11315,11328]
trailer [11333,11346]
===
match
---
name: test_hook [49072,49081]
name: test_hook [49090,49099]
===
match
---
expr_stmt [43227,43258]
expr_stmt [43245,43276]
===
match
---
atom_expr [17887,17931]
atom_expr [17905,17949]
===
match
---
operator: , [41242,41243]
operator: , [41260,41261]
===
match
---
operator: = [43098,43099]
operator: = [43116,43117]
===
match
---
operator: = [16775,16776]
operator: = [16793,16794]
===
match
---
trailer [44574,44587]
trailer [44592,44605]
===
match
---
name: ldap [28514,28518]
name: ldap [28532,28536]
===
match
---
operator: = [48203,48204]
operator: = [48221,48222]
===
match
---
expr_stmt [48868,48888]
expr_stmt [48886,48906]
===
match
---
expr_stmt [45467,45498]
expr_stmt [45485,45516]
===
match
---
expr_stmt [20740,20783]
expr_stmt [20758,20801]
===
match
---
argument [36016,36043]
argument [36034,36061]
===
match
---
expr_stmt [9554,9584]
expr_stmt [9566,9596]
===
match
---
trailer [34859,34878]
trailer [34877,34896]
===
match
---
string: "user" [14996,15002]
string: "user" [15014,15020]
===
match
---
operator: , [913,914]
operator: , [913,914]
===
match
---
atom [6839,6875]
atom [6839,6875]
===
match
---
testlist_comp [17629,17647]
testlist_comp [17647,17665]
===
match
---
name: kwargs [28301,28307]
name: kwargs [28319,28325]
===
match
---
atom [4752,4800]
atom [4752,4800]
===
match
---
name: get [47859,47862]
name: get [47877,47880]
===
match
---
name: Client [31301,31307]
name: Client [31319,31325]
===
match
---
name: conn_type [1389,1398]
name: conn_type [1389,1398]
===
match
---
expr_stmt [26812,26855]
expr_stmt [26830,26873]
===
match
---
name: mock_connection [7339,7354]
name: mock_connection [7339,7354]
===
match
---
atom_expr [35873,35928]
atom_expr [35891,35946]
===
match
---
name: self [37543,37547]
name: self [37561,37565]
===
match
---
operator: , [31733,31734]
operator: , [31751,31752]
===
match
---
name: self [10632,10636]
name: self [10650,10654]
===
match
---
decorator [31100,31178]
decorator [31118,31196]
===
match
---
trailer [24207,24214]
trailer [24225,24232]
===
match
---
decorators [46347,46509]
decorators [46365,46527]
===
match
---
name: mock [9402,9406]
name: mock [9414,9418]
===
match
---
trailer [32488,32495]
trailer [32506,32513]
===
match
---
string: 'world' [41721,41728]
string: 'world' [41739,41746]
===
match
---
trailer [30141,30154]
trailer [30159,30172]
===
match
---
string: "vault_conn_id" [48983,48998]
string: "vault_conn_id" [49001,49016]
===
match
---
name: return_value [31416,31428]
name: return_value [31434,31446]
===
match
---
simple_stmt [16488,16620]
simple_stmt [16506,16638]
===
match
---
expr_stmt [28054,28116]
expr_stmt [28072,28134]
===
match
---
atom_expr [28656,28696]
atom_expr [28674,28714]
===
match
---
trailer [21792,21794]
trailer [21810,21812]
===
match
---
trailer [32854,32858]
trailer [32872,32876]
===
match
---
suite [42089,44147]
suite [42107,44165]
===
match
---
name: assert_called_with [29461,29479]
name: assert_called_with [29479,29497]
===
match
---
name: get [12145,12148]
name: get [12163,12166]
===
match
---
name: test_hook [37302,37311]
name: test_hook [37320,37329]
===
match
---
name: mock_get_credentials [19419,19439]
name: mock_get_credentials [19437,19457]
===
match
---
trailer [12888,12895]
trailer [12906,12913]
===
match
---
simple_stmt [6269,6313]
simple_stmt [6269,6313]
===
match
---
name: auth_userpass [37157,37170]
name: auth_userpass [37175,37188]
===
match
---
argument [18298,18318]
argument [18316,18336]
===
match
---
operator: , [19544,19545]
operator: , [19562,19563]
===
match
---
name: side_effect [30353,30364]
name: side_effect [30371,30382]
===
match
---
trailer [6363,6365]
trailer [6363,6365]
===
match
---
trailer [18507,18557]
trailer [18525,18575]
===
match
---
name: secret [38792,38798]
name: secret [38810,38816]
===
match
---
atom_expr [38523,38542]
atom_expr [38541,38560]
===
match
---
name: mock_client [8478,8489]
name: mock_client [8484,8495]
===
match
---
number: 1 [6743,6744]
number: 1 [6743,6744]
===
match
---
string: "vault_conn_id" [30541,30556]
string: "vault_conn_id" [30559,30574]
===
match
---
dictorsetmaker [36872,36905]
dictorsetmaker [36890,36923]
===
match
---
atom_expr [49112,49205]
atom_expr [49130,49223]
===
match
---
operator: = [1574,1575]
operator: = [1574,1575]
===
match
---
atom_expr [33025,33044]
atom_expr [33043,33062]
===
match
---
argument [8023,8039]
argument [8029,8045]
===
match
---
name: return_value [19212,19224]
name: return_value [19230,19242]
===
match
---
operator: == [5023,5025]
operator: == [5023,5025]
===
match
---
trailer [30352,30364]
trailer [30370,30382]
===
match
---
name: self [26882,26886]
name: self [26900,26904]
===
match
---
trailer [7562,7566]
trailer [7562,7566]
===
match
---
name: return_value [9610,9622]
name: return_value [9622,9634]
===
match
---
name: mock_hvac [28902,28911]
name: mock_hvac [28920,28929]
===
match
---
operator: == [16876,16878]
operator: == [16894,16896]
===
match
---
name: mock_client [36565,36576]
name: mock_client [36583,36594]
===
match
---
name: test_hook [40315,40324]
name: test_hook [40333,40342]
===
match
---
string: "radhost" [30855,30864]
string: "radhost" [30873,30882]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [11666,11730]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [11684,11748]
===
match
---
name: secret [48234,48240]
name: secret [48252,48258]
===
match
---
trailer [24187,24189]
trailer [24205,24207]
===
match
---
dictorsetmaker [43138,43216]
dictorsetmaker [43156,43234]
===
match
---
trailer [23759,23789]
trailer [23777,23807]
===
match
---
string: 'value' [47275,47282]
string: 'value' [47293,47300]
===
match
---
operator: , [17366,17367]
operator: , [17384,17385]
===
match
---
funcdef [27782,28697]
funcdef [27800,28715]
===
match
---
name: mock_get_connection [10823,10842]
name: mock_get_connection [10841,10860]
===
match
---
operator: , [29688,29689]
operator: , [29706,29707]
===
match
---
param [20654,20659]
param [20672,20677]
===
match
---
name: mock_hvac [12879,12888]
name: mock_hvac [12897,12906]
===
match
---
dictorsetmaker [28224,28257]
dictorsetmaker [28242,28275]
===
match
---
trailer [35106,35112]
trailer [35124,35130]
===
match
---
name: kv_engine_version [22577,22594]
name: kv_engine_version [22595,22612]
===
match
---
arglist [20071,20144]
arglist [20089,20162]
===
match
---
string: "vault_conn_id" [13424,13439]
string: "vault_conn_id" [13442,13457]
===
match
---
name: connection_dict [14323,14338]
name: connection_dict [14341,14356]
===
match
---
operator: @ [48281,48282]
operator: @ [48299,48300]
===
match
---
operator: { [19512,19513]
operator: { [19530,19531]
===
match
---
name: secret_key [11392,11402]
name: secret_key [11410,11420]
===
match
---
argument [21143,21151]
argument [21161,21169]
===
match
---
operator: , [31220,31221]
operator: , [31238,31239]
===
match
---
simple_stmt [20701,20732]
simple_stmt [20719,20750]
===
match
---
name: assert_called_with [12397,12415]
name: assert_called_with [12415,12433]
===
match
---
name: password [1255,1263]
name: password [1255,1263]
===
match
---
operator: , [29380,29381]
operator: , [29398,29399]
===
match
---
decorators [11570,11732]
decorators [11588,11750]
===
match
---
name: connection_dict [29147,29162]
name: connection_dict [29165,29180]
===
match
---
argument [35855,35863]
argument [35873,35881]
===
match
---
name: secrets [49226,49233]
name: secrets [49244,49251]
===
match
---
operator: { [16002,16003]
operator: { [16020,16021]
===
match
---
string: 'scope1' [20125,20133]
string: 'scope1' [20143,20151]
===
match
---
operator: ** [16303,16305]
operator: ** [16321,16323]
===
match
---
name: kwargs [45368,45374]
name: kwargs [45386,45392]
===
match
---
decorated [34137,35174]
decorated [34155,35192]
===
match
---
number: 8123 [30886,30890]
number: 8123 [30904,30908]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [7089,7153]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [7089,7153]
===
match
---
operator: = [4855,4856]
operator: = [4855,4856]
===
match
---
name: get [19723,19726]
name: get [19741,19744]
===
match
---
operator: = [31764,31765]
operator: = [31782,31783]
===
match
---
operator: = [44111,44112]
operator: = [44129,44130]
===
match
---
string: "pass" [33981,33987]
string: "pass" [33999,34005]
===
match
---
name: Client [33339,33345]
name: Client [33357,33363]
===
match
---
assert_stmt [23856,23908]
assert_stmt [23874,23926]
===
match
---
name: vault_client [30980,30992]
name: vault_client [30998,31010]
===
match
---
operator: @ [20544,20545]
operator: @ [20562,20563]
===
match
---
name: mock [17015,17019]
name: mock [17033,17037]
===
match
---
expr_stmt [8611,8631]
expr_stmt [8617,8637]
===
match
---
name: kwargs [33597,33603]
name: kwargs [33615,33621]
===
match
---
name: test_client [35095,35106]
name: test_client [35113,35124]
===
match
---
name: assert_called_with [9140,9158]
name: assert_called_with [9152,9170]
===
match
---
operator: ** [33718,33720]
operator: ** [33736,33738]
===
match
---
trailer [30820,30830]
trailer [30838,30848]
===
match
---
name: patch [8255,8260]
name: patch [8261,8266]
===
match
---
simple_stmt [19735,19802]
simple_stmt [19753,19820]
===
match
---
operator: , [12808,12809]
operator: , [12826,12827]
===
match
---
trailer [32820,32824]
trailer [32838,32842]
===
match
---
assert_stmt [28644,28696]
assert_stmt [28662,28714]
===
match
---
name: mock_client [30086,30097]
name: mock_client [30104,30115]
===
match
---
comparison [5932,5983]
comparison [5932,5983]
===
match
---
simple_stmt [37643,37694]
simple_stmt [37661,37712]
===
match
---
string: "vault_conn_id" [16403,16418]
string: "vault_conn_id" [16421,16436]
===
match
---
name: airflow [1032,1039]
name: airflow [1032,1039]
===
match
---
name: mock_client [37824,37835]
name: mock_client [37842,37853]
===
match
---
dotted_name [1032,1071]
dotted_name [1032,1071]
===
match
---
dotted_name [26619,26629]
dotted_name [26637,26647]
===
match
---
simple_stmt [4734,4801]
simple_stmt [4734,4801]
===
match
---
name: patch [15267,15272]
name: patch [15285,15290]
===
match
---
trailer [20198,20227]
trailer [20216,20245]
===
match
---
operator: { [47105,47106]
operator: { [47123,47124]
===
match
---
expr_stmt [19300,19350]
expr_stmt [19318,19368]
===
match
---
trailer [7974,7987]
trailer [7979,7987]
===
match
---
trailer [20285,20335]
trailer [20303,20353]
===
match
---
expr_stmt [35731,35823]
expr_stmt [35749,35841]
===
match
---
simple_stmt [28586,28636]
simple_stmt [28604,28654]
===
match
---
operator: , [11775,11776]
operator: , [11793,11794]
===
match
---
operator: = [23125,23126]
operator: = [23143,23144]
===
match
---
trailer [10842,10855]
trailer [10860,10873]
===
match
---
name: connection_dict [12011,12026]
name: connection_dict [12029,12044]
===
match
---
atom_expr [13074,13118]
atom_expr [13092,13136]
===
match
---
operator: = [5398,5399]
operator: = [5398,5399]
===
match
---
name: VaultHook [22205,22214]
name: VaultHook [22223,22232]
===
match
---
name: login [22437,22442]
name: login [22455,22460]
===
match
---
operator: == [21479,21481]
operator: == [21497,21499]
===
match
---
trailer [11533,11546]
trailer [11551,11564]
===
match
---
name: mock [13969,13973]
name: mock [13987,13991]
===
match
---
decorator [32277,32355]
decorator [32295,32373]
===
match
---
operator: } [39737,39738]
operator: } [39755,39756]
===
match
---
atom_expr [25705,25749]
atom_expr [25723,25767]
===
match
---
name: mock [28703,28707]
name: mock [28721,28725]
===
match
---
simple_stmt [14482,14549]
simple_stmt [14500,14567]
===
match
---
decorators [1794,1956]
decorators [1794,1956]
===
match
---
trailer [31618,31631]
trailer [31636,31649]
===
match
---
operator: , [39627,39628]
operator: , [39645,39646]
===
match
---
atom_expr [22042,22086]
atom_expr [22060,22104]
===
match
---
expr_stmt [15685,15728]
expr_stmt [15703,15746]
===
match
---
atom_expr [3887,3919]
atom_expr [3887,3919]
===
match
---
trailer [16029,16042]
trailer [16047,16060]
===
match
---
simple_stmt [9698,9749]
simple_stmt [9710,9761]
===
match
---
atom_expr [6269,6298]
atom_expr [6269,6298]
===
match
---
simple_stmt [37145,37224]
simple_stmt [37163,37242]
===
match
---
number: 2 [13833,13834]
number: 2 [13851,13852]
===
match
---
operator: , [9173,9174]
operator: , [9185,9186]
===
match
---
name: assert_called_with [28337,28355]
name: assert_called_with [28355,28373]
===
match
---
simple_stmt [29724,29774]
simple_stmt [29742,29792]
===
match
---
operator: = [32874,32875]
operator: = [32892,32893]
===
match
---
trailer [7910,7917]
trailer [7910,7917]
===
match
---
operator: { [45863,45864]
operator: { [45881,45882]
===
match
---
argument [41625,41633]
argument [41643,41651]
===
match
---
name: unittest [819,827]
name: unittest [819,827]
===
match
---
name: auth [20248,20252]
name: auth [20266,20270]
===
match
---
name: side_effect [10946,10957]
name: side_effect [10964,10975]
===
match
---
operator: ** [30599,30601]
operator: ** [30617,30619]
===
match
---
operator: = [26842,26843]
operator: = [26860,26861]
===
match
---
number: 2 [40254,40255]
number: 2 [40272,40273]
===
match
---
trailer [16750,16800]
trailer [16768,16818]
===
match
---
operator: = [15658,15659]
operator: = [15676,15677]
===
match
---
trailer [14514,14526]
trailer [14532,14544]
===
match
---
expr_stmt [6374,6424]
expr_stmt [6374,6424]
===
match
---
name: get_conn [35961,35969]
name: get_conn [35979,35987]
===
match
---
argument [28460,28487]
argument [28478,28505]
===
match
---
trailer [23418,23428]
trailer [23436,23446]
===
match
---
trailer [49239,49263]
trailer [49257,49281]
===
match
---
name: self [39224,39228]
name: self [39242,39246]
===
match
---
operator: , [34340,34341]
operator: , [34358,34359]
===
match
---
name: test_client [29505,29516]
name: test_client [29523,29534]
===
match
---
trailer [10074,10093]
trailer [10086,10105]
===
match
---
param [1991,2001]
param [1991,2001]
===
match
---
operator: } [7489,7490]
operator: } [7489,7490]
===
match
---
simple_stmt [33696,33728]
simple_stmt [33714,33746]
===
match
---
operator: } [32932,32933]
operator: } [32950,32951]
===
match
---
name: mock_get_scopes [16428,16443]
name: mock_get_scopes [16446,16461]
===
match
---
expr_stmt [25562,25606]
expr_stmt [25580,25624]
===
match
---
parameters [5338,5376]
parameters [5338,5376]
===
match
---
name: kwargs [12257,12263]
name: kwargs [12275,12281]
===
match
---
argument [13630,13651]
argument [13648,13669]
===
match
---
param [7177,7182]
param [7177,7182]
===
match
---
atom_expr [3039,3065]
atom_expr [3039,3065]
===
match
---
atom_expr [40882,40914]
atom_expr [40900,40932]
===
match
---
param [10632,10637]
param [10650,10655]
===
match
---
trailer [14864,14869]
trailer [14882,14887]
===
match
---
trailer [26170,26189]
trailer [26188,26207]
===
match
---
operator: = [33567,33568]
operator: = [33585,33586]
===
match
---
operator: , [2647,2648]
operator: , [2647,2648]
===
match
---
atom_expr [5882,5916]
atom_expr [5882,5916]
===
match
---
operator: } [42797,42798]
operator: } [42815,42816]
===
match
---
name: kv_engine_version [23891,23908]
name: kv_engine_version [23909,23926]
===
match
---
param [5339,5344]
param [5339,5344]
===
match
---
param [1231,1241]
param [1231,1241]
===
match
---
name: extra_dejson [34665,34677]
name: extra_dejson [34683,34695]
===
match
---
name: test_client [30681,30692]
name: test_client [30699,30710]
===
match
---
expr_stmt [23050,23070]
expr_stmt [23068,23088]
===
match
---
name: kwargs [35857,35863]
name: kwargs [35875,35881]
===
match
---
name: return_value [24215,24227]
name: return_value [24233,24245]
===
match
---
name: side_effect [45326,45337]
name: side_effect [45344,45355]
===
match
---
argument [40562,40571]
argument [40580,40589]
===
match
---
operator: } [19800,19801]
operator: } [19818,19819]
===
match
---
name: kv [44036,44038]
name: kv [44054,44056]
===
match
---
trailer [1375,1399]
trailer [1375,1399]
===
match
---
decorated [23914,25226]
decorated [23932,25244]
===
match
---
operator: } [30566,30567]
operator: } [30584,30585]
===
match
---
trailer [26510,26528]
trailer [26528,26546]
===
match
---
atom_expr [30797,30891]
atom_expr [30815,30909]
===
match
---
trailer [10975,10979]
trailer [10993,10997]
===
match
---
name: test_hook [4173,4182]
name: test_hook [4173,4182]
===
match
---
argument [13698,13714]
argument [13716,13732]
===
match
---
string: "vault_conn_id" [37004,37019]
string: "vault_conn_id" [37022,37037]
===
match
---
expr_stmt [33329,33372]
expr_stmt [33347,33390]
===
match
---
operator: } [29390,29391]
operator: } [29408,29409]
===
match
---
name: mock_get_scopes [17597,17612]
name: mock_get_scopes [17615,17630]
===
match
---
trailer [30382,30386]
trailer [30400,30404]
===
match
---
simple_stmt [39357,39401]
simple_stmt [39375,39419]
===
match
---
name: test_hook [6696,6705]
name: test_hook [6696,6705]
===
match
---
name: get [6573,6576]
name: get [6573,6576]
===
match
---
name: assert_called_with [36985,37003]
name: assert_called_with [37003,37021]
===
match
---
trailer [15779,15781]
trailer [15797,15799]
===
match
---
name: patch [18885,18890]
name: patch [18903,18908]
===
match
---
trailer [30713,30715]
trailer [30731,30733]
===
match
---
trailer [16663,16692]
trailer [16681,16710]
===
match
---
simple_stmt [36533,36577]
simple_stmt [36551,36595]
===
match
---
name: kwargs [17962,17968]
name: kwargs [17980,17986]
===
match
---
dictorsetmaker [45795,46065]
dictorsetmaker [45813,46083]
===
match
---
atom_expr [27959,27985]
atom_expr [27977,28003]
===
match
---
string: '2020-03-16T21:01:43.331126Z' [39806,39835]
string: '2020-03-16T21:01:43.331126Z' [39824,39853]
===
match
---
operator: = [10958,10959]
operator: = [10976,10977]
===
match
---
operator: = [25648,25649]
operator: = [25666,25667]
===
match
---
param [42051,42056]
param [42069,42074]
===
match
---
trailer [16383,16402]
trailer [16401,16420]
===
match
---
name: assert_called_with [33945,33963]
name: assert_called_with [33963,33981]
===
match
---
name: extra_dejson [17903,17915]
name: extra_dejson [17921,17933]
===
match
---
simple_stmt [30177,30222]
simple_stmt [30195,30240]
===
match
---
string: 'wrap_info' [38382,38393]
string: 'wrap_info' [38400,38411]
===
match
---
operator: , [19596,19597]
operator: , [19614,19615]
===
match
---
atom_expr [28173,28192]
atom_expr [28191,28210]
===
match
---
name: mock_hvac [47521,47530]
name: mock_hvac [47539,47548]
===
match
---
operator: = [44493,44494]
operator: = [44511,44512]
===
match
---
simple_stmt [23798,23848]
simple_stmt [23816,23866]
===
match
---
trailer [5735,5739]
trailer [5735,5739]
===
match
---
operator: = [9623,9624]
operator: = [9635,9636]
===
match
---
name: self [9507,9511]
name: self [9519,9523]
===
match
---
string: "auth_type" [46949,46960]
string: "auth_type" [46967,46978]
===
match
---
name: patch [18777,18782]
name: patch [18795,18800]
===
match
---
name: method [49198,49204]
name: method [49216,49222]
===
match
---
expr_stmt [33493,33513]
expr_stmt [33511,33531]
===
match
---
name: mock_client [25471,25482]
name: mock_client [25489,25500]
===
match
---
param [21723,21733]
param [21741,21751]
===
match
---
string: "user" [28553,28559]
string: "user" [28571,28577]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [15465,15529]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [15483,15547]
===
match
---
name: Client [11856,11862]
name: Client [11874,11880]
===
match
---
name: mock [17207,17211]
name: mock [17225,17229]
===
match
---
name: mock_hvac [4489,4498]
name: mock_hvac [4489,4498]
===
match
---
dictorsetmaker [6466,6490]
dictorsetmaker [6466,6490]
===
match
---
param [5345,5355]
param [5345,5355]
===
match
---
operator: , [7216,7217]
operator: , [7216,7217]
===
match
---
param [10649,10668]
param [10667,10686]
===
match
---
atom_expr [36774,36818]
atom_expr [36792,36836]
===
match
---
atom_expr [5026,5060]
atom_expr [5026,5060]
===
match
---
name: login [28519,28524]
name: login [28537,28542]
===
match
---
name: assert_called_with [33756,33774]
name: assert_called_with [33774,33792]
===
match
---
name: radius [29638,29644]
name: radius [29656,29662]
===
match
---
expr_stmt [48815,48858]
expr_stmt [48833,48876]
===
match
---
simple_stmt [47674,47705]
simple_stmt [47692,47723]
===
match
---
trailer [1350,1360]
trailer [1350,1360]
===
match
---
name: test_client [15056,15067]
name: test_client [15074,15085]
===
match
---
name: mock [37716,37720]
name: mock [37734,37738]
===
match
---
operator: = [6450,6451]
operator: = [6450,6451]
===
match
---
operator: , [16580,16581]
operator: , [16598,16599]
===
match
---
name: mock_connection [8498,8513]
name: mock_connection [8504,8519]
===
match
---
name: connection_dict [29224,29239]
name: connection_dict [29242,29257]
===
match
---
name: read_secret_metadata [42358,42378]
name: read_secret_metadata [42376,42396]
===
match
---
decorator [32193,32273]
decorator [32211,32291]
===
match
---
expr_stmt [7470,7490]
expr_stmt [7470,7490]
===
match
---
atom [25789,25972]
atom [25807,25990]
===
match
---
atom_expr [1649,1684]
atom_expr [1649,1684]
===
match
---
name: mock_connection [10858,10873]
name: mock_connection [10876,10891]
===
match
---
operator: = [13119,13120]
operator: = [13137,13138]
===
match
---
string: "vault_conn_id" [46915,46930]
string: "vault_conn_id" [46933,46948]
===
match
---
name: extra_dejson [24505,24517]
name: extra_dejson [24523,24535]
===
match
---
name: assert_called_with [23657,23675]
name: assert_called_with [23675,23693]
===
match
---
atom_expr [41429,41473]
atom_expr [41447,41491]
===
match
---
atom_expr [24173,24189]
atom_expr [24191,24207]
===
match
---
testlist_comp [20125,20143]
testlist_comp [20143,20161]
===
match
---
operator: , [13324,13325]
operator: , [13342,13343]
===
match
---
simple_stmt [24564,24670]
simple_stmt [24582,24688]
===
match
---
string: '' [37977,37979]
string: '' [37995,37997]
===
match
---
name: mock_connection [31603,31618]
name: mock_connection [31621,31636]
===
match
---
decorated [21528,22595]
decorated [21546,22613]
===
match
---
name: test_client [14737,14748]
name: test_client [14755,14766]
===
match
---
simple_stmt [28497,28578]
simple_stmt [28515,28596]
===
match
---
name: mock_get_connection [11124,11143]
name: mock_get_connection [11142,11161]
===
match
---
operator: , [16260,16261]
operator: , [16278,16279]
===
match
---
trailer [28355,28372]
trailer [28373,28390]
===
match
---
name: configure [18479,18488]
name: configure [18497,18506]
===
match
---
name: mock_connection [34463,34478]
name: mock_connection [34481,34496]
===
match
---
name: read_secret_version [44667,44686]
name: read_secret_version [44685,44704]
===
match
---
operator: } [4957,4958]
operator: } [4957,4958]
===
match
---
string: "kube_role" [23765,23776]
string: "kube_role" [23783,23794]
===
match
---
string: "auth_type" [30418,30429]
string: "auth_type" [30436,30447]
===
match
---
atom_expr [14751,14771]
atom_expr [14769,14789]
===
match
---
param [12799,12809]
param [12817,12827]
===
match
---
operator: , [47913,47914]
operator: , [47931,47932]
===
match
---
expr_stmt [23397,23428]
expr_stmt [23415,23446]
===
match
---
operator: == [35130,35132]
operator: == [35148,35150]
===
match
---
atom_expr [46830,46874]
atom_expr [46848,46892]
===
match
---
trailer [18101,18110]
trailer [18119,18128]
===
match
---
simple_stmt [9201,9251]
simple_stmt [9213,9263]
===
match
---
operator: @ [38956,38957]
operator: @ [38974,38975]
===
match
---
dotted_name [4273,4283]
dotted_name [4273,4283]
===
match
---
name: get [27070,27073]
name: get [27088,27091]
===
match
---
atom_expr [12273,12328]
atom_expr [12291,12346]
===
match
---
name: mock_client [48776,48787]
name: mock_client [48794,48805]
===
match
---
operator: = [33359,33360]
operator: = [33377,33378]
===
match
---
name: kwargs [21010,21016]
name: kwargs [21028,21034]
===
match
---
funcdef [10603,11565]
funcdef [10621,11583]
===
match
---
atom_expr [1437,1468]
atom_expr [1437,1468]
===
match
---
expr_stmt [22117,22183]
expr_stmt [22135,22201]
===
match
---
operator: , [25961,25962]
operator: , [25979,25980]
===
match
---
name: VaultHook [33708,33717]
name: VaultHook [33726,33735]
===
match
---
trailer [30598,30608]
trailer [30616,30626]
===
match
---
trailer [27878,27880]
trailer [27896,27898]
===
match
---
atom_expr [40139,40158]
atom_expr [40157,40176]
===
match
---
name: mock_client [44641,44652]
name: mock_client [44659,44670]
===
match
---
simple_stmt [38650,38682]
simple_stmt [38668,38700]
===
match
---
param [2856,2861]
param [2856,2861]
===
match
---
argument [36098,36113]
argument [36116,36131]
===
match
---
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [31028,31094]
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [31046,31112]
===
match
---
name: mock_hvac [21268,21277]
name: mock_hvac [21286,21295]
===
match
---
operator: , [2497,2498]
operator: , [2497,2498]
===
match
---
name: self [36603,36607]
name: self [36621,36625]
===
match
---
suite [20692,21523]
suite [20710,21541]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [35275,35339]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [35293,35357]
===
match
---
operator: = [25578,25579]
operator: = [25596,25597]
===
match
---
atom_expr [1304,1320]
atom_expr [1304,1320]
===
match
---
trailer [48019,48043]
trailer [48037,48061]
===
match
---
trailer [37843,37846]
trailer [37861,37864]
===
match
---
name: mock_hvac [34411,34420]
name: mock_hvac [34429,34438]
===
match
---
dictorsetmaker [9962,9995]
dictorsetmaker [9974,10007]
===
match
---
dotted_name [15370,15380]
dotted_name [15388,15398]
===
match
---
name: get_conn [28405,28413]
name: get_conn [28423,28431]
===
match
---
name: get_conn [24829,24837]
name: get_conn [24847,24855]
===
match
---
name: connection_dict [8611,8626]
name: connection_dict [8617,8632]
===
match
---
operator: = [4637,4638]
operator: = [4637,4638]
===
match
---
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [20472,20538]
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [20490,20556]
===
match
---
name: get_mock_connection [25585,25604]
name: get_mock_connection [25603,25622]
===
match
---
name: get_mock_connection [32554,32573]
name: get_mock_connection [32572,32591]
===
match
---
name: kv_engine_version [35156,35173]
name: kv_engine_version [35174,35191]
===
match
---
name: mock_hvac [27809,27818]
name: mock_hvac [27827,27836]
===
match
---
string: "credentials" [15946,15959]
string: "credentials" [15964,15977]
===
match
---
simple_stmt [986,1026]
simple_stmt [986,1026]
===
match
---
operator: , [49164,49165]
operator: , [49182,49183]
===
match
---
dictorsetmaker [41514,41592]
dictorsetmaker [41532,41610]
===
match
---
string: "kv_engine_version" [7711,7730]
string: "kv_engine_version" [7711,7730]
===
match
---
param [8366,8376]
param [8372,8382]
===
match
---
name: return_value [2088,2100]
name: return_value [2088,2100]
===
match
---
name: vault_client [34107,34119]
name: vault_client [34125,34137]
===
match
---
trailer [7266,7276]
trailer [7266,7276]
===
match
---
name: return_value [17558,17570]
name: return_value [17576,17588]
===
match
---
trailer [24782,24792]
trailer [24800,24810]
===
match
---
simple_stmt [19156,19187]
simple_stmt [19174,19205]
===
match
---
name: self [48682,48686]
name: self [48700,48704]
===
match
---
name: get_mock_connection [9668,9687]
name: get_mock_connection [9680,9699]
===
match
---
trailer [42170,42183]
trailer [42188,42201]
===
match
---
name: test_client [9115,9126]
name: test_client [9121,9132]
===
match
---
name: get_conn [29529,29537]
name: get_conn [29547,29555]
===
match
---
operator: , [3176,3177]
operator: , [3176,3177]
===
match
---
string: 'deletion_time' [39857,39872]
string: 'deletion_time' [39875,39890]
===
match
---
simple_stmt [43267,43331]
simple_stmt [43285,43349]
===
match
---
comparison [13833,13878]
comparison [13851,13896]
===
match
---
atom_expr [22885,22914]
atom_expr [22903,22932]
===
match
---
name: self [5495,5499]
name: self [5495,5499]
===
match
---
dotted_name [34222,34232]
dotted_name [34240,34250]
===
match
---
name: extra_dejson [4039,4051]
name: extra_dejson [4039,4051]
===
match
---
expr_stmt [32584,32634]
expr_stmt [32602,32652]
===
match
---
operator: = [26993,26994]
operator: = [27011,27012]
===
match
---
decorated [35179,36251]
decorated [35197,36269]
===
match
---
assert_stmt [27558,27610]
assert_stmt [27576,27628]
===
match
---
simple_stmt [33974,34009]
simple_stmt [33992,34027]
===
match
---
decorator [39040,39118]
decorator [39058,39136]
===
match
---
name: Client [10728,10734]
name: Client [10746,10752]
===
match
---
string: '' [45075,45077]
string: '' [45093,45095]
===
match
---
comparison [28651,28696]
comparison [28669,28714]
===
match
---
name: secrets [37836,37843]
name: secrets [37854,37861]
===
match
---
name: mock_hvac [42057,42066]
name: mock_hvac [42075,42084]
===
match
---
name: resource [13665,13673]
name: resource [13683,13691]
===
match
---
atom [23164,23304]
atom [23182,23322]
===
match
---
trailer [16721,16731]
trailer [16739,16749]
===
match
---
trailer [24504,24517]
trailer [24522,24535]
===
match
---
atom_expr [21908,21940]
atom_expr [21926,21958]
===
match
---
argument [45558,45579]
argument [45576,45597]
===
match
---
operator: = [32617,32618]
operator: = [32635,32636]
===
match
---
trailer [36187,36189]
trailer [36205,36207]
===
match
---
trailer [1567,1573]
trailer [1567,1573]
===
match
---
operator: , [43916,43917]
operator: , [43934,43935]
===
match
---
name: mock_get_scopes [19130,19145]
name: mock_get_scopes [19148,19163]
===
match
---
atom [39768,39969]
atom [39786,39987]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [41949,42013]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [41967,42031]
===
match
---
operator: , [27170,27171]
operator: , [27188,27189]
===
match
---
atom_expr [19707,19726]
atom_expr [19725,19744]
===
match
---
name: self [25424,25428]
name: self [25442,25446]
===
match
---
trailer [2080,2087]
trailer [2080,2087]
===
match
---
operator: { [30404,30405]
operator: { [30422,30423]
===
match
---
name: patch [26624,26629]
name: patch [26642,26647]
===
match
---
trailer [34427,34440]
trailer [34445,34458]
===
match
---
operator: , [29334,29335]
operator: , [29352,29353]
===
match
---
argument [38928,38940]
argument [38946,38958]
===
match
---
name: get_conn [13473,13481]
name: get_conn [13491,13499]
===
match
---
name: Client [31911,31917]
name: Client [31929,31935]
===
match
---
name: return_value [32604,32616]
name: return_value [32622,32634]
===
match
---
string: 'renewable' [39609,39620]
string: 'renewable' [39627,39638]
===
match
---
arglist [40336,40375]
arglist [40354,40393]
===
match
---
trailer [20963,20967]
trailer [20981,20985]
===
match
---
expr_stmt [32531,32575]
expr_stmt [32549,32593]
===
match
---
expr_stmt [26773,26803]
expr_stmt [26791,26821]
===
match
---
argument [12255,12263]
argument [12273,12281]
===
match
---
string: 'value' [47113,47120]
string: 'value' [47131,47138]
===
match
---
name: type [1546,1550]
name: type [1546,1550]
===
match
---
trailer [46858,46862]
trailer [46876,46880]
===
match
---
name: mock [3565,3569]
name: mock [3565,3569]
===
match
---
name: mock_get_connection [34840,34859]
name: mock_get_connection [34858,34877]
===
match
---
simple_stmt [19419,19485]
simple_stmt [19437,19503]
===
match
---
number: 2 [8873,8874]
number: 2 [8879,8880]
===
match
---
name: mock_get_connection [18121,18140]
name: mock_get_connection [18139,18158]
===
match
---
trailer [20967,20979]
trailer [20985,20997]
===
match
---
name: test_client [23441,23452]
name: test_client [23459,23470]
===
match
---
string: "vault_conn_id" [21085,21100]
string: "vault_conn_id" [21103,21118]
===
match
---
number: 2 [32142,32143]
number: 2 [32160,32161]
===
match
---
simple_stmt [14158,14202]
simple_stmt [14176,14220]
===
match
---
expr_stmt [31754,31785]
expr_stmt [31772,31803]
===
match
---
operator: = [34810,34811]
operator: = [34828,34829]
===
match
---
operator: { [9948,9949]
operator: { [9960,9961]
===
match
---
trailer [21199,21216]
trailer [21217,21234]
===
match
---
name: connection_dict [33569,33584]
name: connection_dict [33587,33602]
===
match
---
expr_stmt [6230,6260]
expr_stmt [6230,6260]
===
match
---
parameters [39158,39196]
parameters [39176,39214]
===
match
---
expr_stmt [5748,5814]
expr_stmt [5748,5814]
===
match
---
atom_expr [22413,22475]
atom_expr [22431,22493]
===
match
---
operator: } [45169,45170]
operator: } [45187,45188]
===
match
---
simple_stmt [6321,6366]
simple_stmt [6321,6366]
===
match
---
simple_stmt [39259,39310]
simple_stmt [39277,39328]
===
match
---
dotted_name [27617,27627]
dotted_name [27635,27645]
===
match
---
name: mock_client [44590,44601]
name: mock_client [44608,44619]
===
match
---
name: mock_get_connection [31222,31241]
name: mock_get_connection [31240,31259]
===
match
---
name: mock_connection [16014,16029]
name: mock_connection [16032,16047]
===
match
---
string: "vault_conn_id" [49000,49015]
string: "vault_conn_id" [49018,49033]
===
match
---
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [37360,37426]
string: "airflow.providers.hashicorp.hooks.vault.VaultHook.get_connection" [37378,37444]
===
match
---
operator: = [48092,48093]
operator: = [48110,48111]
===
match
---
trailer [31775,31785]
trailer [31793,31803]
===
match
---
name: mock [48790,48794]
name: mock [48808,48812]
===
match
---
operator: , [36753,36754]
operator: , [36771,36772]
===
match
---
expr_stmt [39259,39309]
expr_stmt [39277,39327]
===
match
---
atom_expr [14228,14254]
atom_expr [14246,14272]
===
match
---
string: "https://localhost:8180" [6946,6970]
string: "https://localhost:8180" [6946,6970]
===
match
---
simple_stmt [4621,4666]
simple_stmt [4621,4666]
===
match
---
simple_stmt [21968,22033]
simple_stmt [21986,22051]
===
match
---
atom_expr [30970,31010]
atom_expr [30988,31028]
===
match
---
assert_stmt [15114,15166]
assert_stmt [15132,15184]
===
match
---
atom_expr [28126,28170]
atom_expr [28144,28188]
===
match
---
string: "project_id" [17709,17721]
string: "project_id" [17727,17739]
===
match
---
name: mount_point [5905,5916]
name: mount_point [5905,5916]
===
match
---
simple_stmt [31252,31283]
simple_stmt [31270,31301]
===
match
---
operator: ** [23419,23421]
operator: ** [23437,23439]
===
match
---
operator: = [16291,16292]
operator: = [16309,16310]
===
match
---
expr_stmt [19195,19238]
expr_stmt [19213,19256]
===
match
---
name: connection_dict [42302,42317]
name: connection_dict [42320,42335]
===
match
---
operator: , [6848,6849]
operator: , [6848,6849]
===
match
---
name: test_hook [16335,16344]
name: test_hook [16353,16362]
===
match
---
operator: = [20713,20714]
operator: = [20731,20732]
===
match
---
simple_stmt [43339,44008]
simple_stmt [43357,44026]
===
match
---
atom_expr [7500,7544]
atom_expr [7500,7544]
===
match
---
name: mock_get_connection [40882,40901]
name: mock_get_connection [40900,40919]
===
match
---
string: 'secret_value' [38773,38787]
string: 'secret_value' [38791,38805]
===
match
---
operator: = [28463,28464]
operator: = [28481,28482]
===
match
---
name: secret [41643,41649]
name: secret [41661,41667]
===
match
---
param [4489,4499]
param [4489,4499]
===
match
---
operator: , [39969,39970]
operator: , [39987,39988]
===
match
---
operator: , [21732,21733]
operator: , [21750,21751]
===
match
---
operator: , [45170,45171]
operator: , [45188,45189]
===
match
---
trailer [47702,47704]
trailer [47720,47722]
===
match
---
trailer [12144,12148]
trailer [12162,12166]
===
match
---
operator: = [1246,1247]
operator: = [1246,1247]
===
match
---
name: patch [17212,17217]
name: patch [17230,17235]
===
match
---
simple_stmt [39318,39349]
simple_stmt [39336,39367]
===
match
---
trailer [41759,41767]
trailer [41777,41785]
===
match
---
name: mock_hvac [33249,33258]
name: mock_hvac [33267,33276]
===
match
---
string: "vault_conn_id" [36872,36887]
string: "vault_conn_id" [36890,36905]
===
match
---
number: 2 [42997,42998]
number: 2 [43015,43016]
===
match
---
name: side_effect [13107,13118]
name: side_effect [13125,13136]
===
match
---
operator: = [29678,29679]
operator: = [29696,29697]
===
match
---
trailer [30759,30788]
trailer [30777,30806]
===
match
---
name: test_gcp_init_params [15539,15559]
name: test_gcp_init_params [15557,15577]
===
match
---
string: 'value' [48079,48086]
string: 'value' [48097,48104]
===
match
---
testlist_comp [6839,6972]
testlist_comp [6839,6972]
===
match
---
string: 'version' [38322,38331]
string: 'version' [38340,38349]
===
match
---
operator: , [43984,43985]
operator: , [44002,44003]
===
match
---
simple_stmt [41603,41635]
simple_stmt [41621,41653]
===
match
---
name: mock_client [15646,15657]
name: mock_client [15664,15675]
===
match
---
name: patch [8171,8176]
name: patch [8177,8182]
===
match
---
name: vault_client [15136,15148]
name: vault_client [15154,15166]
===
match
---
trailer [46763,46776]
trailer [46781,46794]
===
match
---
operator: { [46914,46915]
operator: { [46932,46933]
===
match
---
name: get_mock_connection [12954,12973]
name: get_mock_connection [12972,12991]
===
match
---
string: "data" [26029,26035]
string: "data" [26047,26053]
===
match
---
name: kwargs [7778,7784]
name: kwargs [7778,7784]
===
match
---
simple_stmt [29177,29244]
simple_stmt [29195,29262]
===
match
---
decorator [8249,8327]
decorator [8255,8333]
===
match
---
trailer [40107,40120]
trailer [40125,40138]
===
match
---
operator: , [42664,42665]
operator: , [42682,42683]
===
match
---
string: "userpass" [3992,4002]
string: "userpass" [3992,4002]
===
match
---
trailer [5519,5521]
trailer [5519,5521]
===
match
---
param [40799,40818]
param [40817,40836]
===
match
---
atom [47784,47786]
atom [47802,47804]
===
match
---
atom_expr [48815,48844]
atom_expr [48833,48862]
===
match
---
trailer [45325,45337]
trailer [45343,45355]
===
match
---
name: test_hook [23455,23464]
name: test_hook [23473,23482]
===
match
---
name: self [8516,8520]
name: self [8522,8526]
===
match
---
expr_stmt [37741,37784]
expr_stmt [37759,37802]
===
match
---
expr_stmt [11807,11837]
expr_stmt [11825,11855]
===
match
---
operator: } [28266,28267]
operator: } [28284,28285]
===
match
---
argument [11361,11378]
argument [11379,11396]
===
match
---
trailer [35048,35067]
trailer [35066,35085]
===
match
---
atom [31687,31744]
atom [31705,31762]
===
insert-node
---
name: TestVaultHook [1097,1110]
to
classdef [1091,49401]
at 0
===
insert-node
---
name: TestCase [1111,1119]
to
classdef [1091,49401]
at 1
===
insert-tree
---
trailer [7974,7979]
    name: auth [7975,7979]
to
atom_expr [7963,8040]
at 1
===
insert-tree
---
trailer [7987,7993]
    name: login [7988,7993]
to
atom_expr [7963,8040]
at 3
===
insert-tree
---
trailer [9132,9137]
    name: auth [9133,9137]
to
atom_expr [9115,9192]
at 1
===
insert-tree
---
trailer [9145,9151]
    name: login [9146,9151]
to
atom_expr [9115,9192]
at 3
===
insert-tree
---
trailer [10258,10263]
    name: auth [10259,10263]
to
atom_expr [10235,10312]
at 1
===
insert-tree
---
trailer [10271,10277]
    name: login [10272,10277]
to
atom_expr [10235,10312]
at 3
===
update-node
---
name: auth_approle [7975,7987]
replace auth_approle by approle
===
update-node
---
name: auth_approle [9127,9139]
replace auth_approle by approle
===
update-node
---
name: auth_approle [10247,10259]
replace auth_approle by approle
===
delete-node
---
name: TestVaultHook [1097,1110]
===
===
delete-node
---
name: TestCase [1111,1119]
===
